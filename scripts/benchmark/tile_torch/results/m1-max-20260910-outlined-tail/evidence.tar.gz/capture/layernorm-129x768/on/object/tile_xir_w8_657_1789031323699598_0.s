	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_3:
	.long	5                               ; 0x5
	.long	4                               ; 0x4
	.long	7                               ; 0x7
	.long	6                               ; 0x6
lCPI0_4:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	3                               ; 0x3
	.long	2                               ; 0x2
lCPI0_5:
	.long	6                               ; 0x6
	.long	7                               ; 0x7
	.long	4                               ; 0x4
	.long	5                               ; 0x5
lCPI0_6:
	.long	2                               ; 0x2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	dup.4s	v1, w2
Lloh0:
	adrp	x8, lCPI0_1@PAGE
Lloh1:
	ldr	q4, [x8, lCPI0_1@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_2@PAGE
Lloh3:
	ldr	q5, [x8, lCPI0_2@PAGEOFF]
	cmhi.4s	v0, v1, v5
	cmhi.4s	v1, v1, v4
	uzp1.8h	v3, v1, v0
	umaxv.8h	h2, v3
	fmov	w8, s2
	tbz	w8, #0, LBB0_116
; %bb.1:                                ; %direct.activate
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #3, lsl #12             ; =12288
	sub	sp, sp, #992
	mov	x12, #0                         ; =0x0
	add	x11, sp, #160
	ldr	x13, [x0, #16]
	ldr	x8, [x0, #32]
	ldr	x9, [x0, #48]
Lloh4:
	adrp	x10, lCPI0_0@PAGE
Lloh5:
	ldr	q2, [x10, lCPI0_0@PAGEOFF]
	and.16b	v2, v3, v2
	addv.8h	h2, v2
	fmov	w10, s2
	and	w21, w10, #0xff
	ldr	x14, [x0]
	ldr	w10, [x1]
	ldr	w15, [x1, #36]
	add	w10, w15, w10, lsl #5
	lsr	w10, w10, #3
	fmov	s6, w10
	and.16b	v6, v1, v6
	fmov	w15, s6
	mov	w16, #3072                      ; =0xc00
	umull	x10, w15, w16
	umaddl	x14, w15, w16, x14
	fmov	w15, s2
	add	x16, sp, #2, lsl #12            ; =8192
	add	x16, x16, #2016
	b	LBB0_3
LBB0_2:                                 ; %else81
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x16, x12
	stp	q6, q7, [x17]
	add	x12, x12, #32
	cmp	x12, #3072
	b.eq	LBB0_19
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	add	x17, x14, x12
	add	x1, x16, x12
	ldr	q6, [x1]
	tbnz	w15, #0, LBB0_11
; %bb.4:                                ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w0, w15, #0xff
	tbnz	w0, #1, LBB0_12
LBB0_5:                                 ; %else63
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w0, #2, LBB0_13
LBB0_6:                                 ; %else66
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w0, #3, LBB0_14
LBB0_7:                                 ; %else69
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q7, [x1, #16]
	tbnz	w0, #4, LBB0_15
LBB0_8:                                 ; %else72
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w0, #5, LBB0_16
LBB0_9:                                 ; %else75
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w0, #6, LBB0_17
LBB0_10:                                ; %else78
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w0, #7, LBB0_2
	b	LBB0_18
LBB0_11:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	ld1.s	{ v6 }[0], [x17]
	and	w0, w15, #0xff
	tbz	w0, #1, LBB0_5
LBB0_12:                                ; %cond.load62
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x2, x17, #4
	ld1.s	{ v6 }[1], [x2]
	tbz	w0, #2, LBB0_6
LBB0_13:                                ; %cond.load65
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x2, x17, #8
	ld1.s	{ v6 }[2], [x2]
	tbz	w0, #3, LBB0_7
LBB0_14:                                ; %cond.load68
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x2, x17, #12
	ld1.s	{ v6 }[3], [x2]
	ldr	q7, [x1, #16]
	tbz	w0, #4, LBB0_8
LBB0_15:                                ; %cond.load71
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x17, #16
	ld1.s	{ v7 }[0], [x1]
	tbz	w0, #5, LBB0_9
LBB0_16:                                ; %cond.load74
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x17, #20
	ld1.s	{ v7 }[1], [x1]
	tbz	w0, #6, LBB0_10
LBB0_17:                                ; %cond.load77
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x17, #24
	ld1.s	{ v7 }[2], [x1]
	tbz	w0, #7, LBB0_2
LBB0_18:                                ; %cond.load80
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x17, #28
	ld1.s	{ v7 }[3], [x17]
	b	LBB0_2
LBB0_19:                                ; %direct.false
	ldr	q6, [x11, #10048]
	ldr	q7, [x11, #10064]
	ldr	q16, [x11, #10080]
	ldr	q17, [x11, #10096]
	ldr	q18, [x11, #10112]
	ldr	q21, [x11, #10128]
	ldr	q22, [x11, #10144]
	and.16b	v7, v0, v7
	and.16b	v6, v1, v6
	ldr	q23, [x11, #10160]
	and.16b	v20, v0, v17
	and.16b	v19, v1, v16
	and.16b	v16, v0, v21
	and.16b	v21, v1, v18
	and.16b	v18, v0, v23
	and.16b	v17, v1, v22
	add	x12, sp, #2, lsl #12            ; =8192
	add	x12, x12, #2016
	add	x12, x12, #224
	mov	w14, #4                         ; =0x4
LBB0_20:                                ; %direct.true66
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q23, q22, [x12, #-96]
	fadd.4s	v23, v6, v23
	fadd.4s	v22, v7, v22
	ldp	q25, q24, [x12, #-64]
	fadd.4s	v25, v19, v25
	fadd.4s	v24, v20, v24
	ldp	q27, q26, [x12, #-32]
	fadd.4s	v27, v21, v27
	fadd.4s	v26, v16, v26
	ldp	q29, q28, [x12], #128
	fadd.4s	v29, v17, v29
	fadd.4s	v28, v18, v28
	bit.16b	v7, v22, v0
	bit.16b	v6, v23, v1
	bit.16b	v20, v24, v0
	bit.16b	v19, v25, v1
	bit.16b	v16, v26, v0
	bit.16b	v21, v27, v1
	bit.16b	v18, v28, v0
	bit.16b	v17, v29, v1
	cmp	x14, #92
	add	x14, x14, #4
	b.lo	LBB0_20
; %bb.21:                               ; %direct.false67
	mov	x23, #0                         ; =0x0
	xtn.8b	v3, v3
	fadd.4s	v7, v7, v20
	fadd.4s	v6, v6, v19
	fadd.4s	v19, v6, v21
	fadd.4s	v6, v7, v16
	fadd.4s	v6, v6, v18
	fadd.4s	v7, v19, v17
	and.16b	v4, v1, v4
	and.16b	v5, v0, v5
	movi.4s	v16, #1
	eor.16b	v17, v5, v16
	eor.16b	v20, v4, v16
	umov.b	w12, v3[0]
	str	q7, [x11, #784]
	ldr	s16, [sp, #948]
	umov.b	w14, v3[1]
	ands	w3, w12, #0x1
	tst	w3, w14
	movi.2d	v4, #0000000000000000
	fcsel	s16, s16, s4, ne
	mov.s	w15, v20[1]
	add	x16, sp, #912
	orr	x16, x16, x15, lsl #2
	add	x4, sp, #616
	add	x17, sp, #616
	bfxil	x17, x15, #0, #3
	str	d3, [x11, #456]
	ldrb	w15, [x17]
	and	w15, w14, w15
	stp	q7, q6, [x11, #752]
	ldr	s18, [x16]
	tst	w15, #0x1
	fcsel	s18, s18, s4, ne
	mov.s	w15, v20[2]
	add	x16, sp, #880
	orr	x16, x16, x15, lsl #2
	add	x17, sp, #616
	bfxil	x17, x15, #0, #3
	umov.b	w15, v3[2]
	ldrb	w17, [x17]
	and	w17, w15, w17
	stp	q7, q6, [x11, #720]
	ldr	s19, [x16]
	tst	w17, #0x1
	fcsel	s19, s19, s4, ne
	mov.s	w16, v20[3]
	add	x17, sp, #848
	orr	x17, x17, x16, lsl #2
	add	x0, sp, #616
	bfxil	x0, x16, #0, #3
	ldrb	w0, [x0]
	umov.b	w16, v3[3]
	and	w0, w16, w0
	stp	q7, q6, [x11, #688]
	ldr	s20, [x17]
	tst	w0, #0x1
	fcsel	s20, s20, s4, ne
	fmov	w0, s17
	add	x17, sp, #616
	bfxil	x17, x0, #0, #3
	ldrb	w1, [x17]
	umov.b	w17, v3[4]
	and	w1, w17, w1
	stp	q7, q6, [x11, #656]
	add	x2, sp, #816
	ldr	s21, [x2, w0, uxtw #2]
	tst	w1, #0x1
	fcsel	s21, s21, s4, ne
	mov.s	w1, v17[1]
	add	x2, sp, #616
	bfxil	x2, x1, #0, #3
	umov.b	w0, v3[5]
	ldrb	w2, [x2]
	stp	q7, q6, [x11, #624]
	add	x5, sp, #784
	ldr	s22, [x5, w1, uxtw #2]
	and	w1, w0, w2
	tst	w1, #0x1
	fcsel	s22, s22, s4, ne
	mov.s	w2, v17[2]
	add	x1, sp, #616
	bfxil	x1, x2, #0, #3
	ldrb	w5, [x1]
	umov.b	w1, v3[6]
	and	w5, w1, w5
	stp	q7, q6, [x11, #592]
	add	x6, sp, #752
	ldr	s23, [x6, w2, uxtw #2]
	tst	w5, #0x1
	fcsel	s23, s23, s4, ne
	mov.s	w5, v17[3]
	add	x6, sp, #616
	bfxil	x6, x5, #0, #3
	umov.b	w2, v3[7]
	ldrb	w6, [x6]
	stp	q7, q6, [x11, #560]
	add	x7, sp, #720
	ldr	s17, [x7, w5, uxtw #2]
	and	w5, w2, w6
	tst	w5, #0x1
	mov.s	v16[1], v18[0]
	mov.s	v16[2], v19[0]
	mov.s	v16[3], v20[0]
	mov.s	v21[1], v22[0]
	mov.s	v21[2], v23[0]
	fcsel	s17, s17, s4, ne
	mov.s	v21[3], v17[0]
	fadd.4s	v6, v6, v21
	fadd.4s	v7, v7, v16
	movi.4s	v16, #2
	eor.16b	v5, v5, v16
	str	q7, [x11, #528]
	ldr	s16, [sp, #696]
	tst	w3, w15
	fcsel	s16, s16, s4, ne
	fmov	w3, s5
	bfxil	x4, x3, #0, #3
	ldrb	w4, [x4]
	and	w4, w17, w4
	stp	q7, q6, [x11, #496]
	add	x5, sp, #656
	ldr	s5, [x5, w3, uxtw #2]
	tst	w4, #0x1
	fcsel	s5, s5, s4, ne
	fadd.4s	v5, v6, v5
	and	w3, w12, w17
	tst	w3, #0x1
	fcsel	s5, s5, s4, ne
	ands	w4, w12, #0x1
	fadd.4s	v6, v7, v16
	fadd	s5, s6, s5
	fcsel	s6, s5, s4, ne
	tst	w3, #0x1
	and	w5, w14, w12
	fcsel	s7, s5, s4, ne
	tst	w5, #0x1
	and	w6, w15, w12
	fcsel	s16, s5, s4, ne
	tst	w6, #0x1
	and	w7, w16, w12
	fcsel	s17, s5, s4, ne
	tst	w7, #0x1
	fcsel	s18, s5, s4, ne
	and	w19, w0, w12
	tst	w19, #0x1
	fcsel	s19, s5, s4, ne
	and	w20, w1, w12
	tst	w20, #0x1
	fcsel	s20, s5, s4, ne
	and	w22, w2, w12
	tst	w22, #0x1
	fcsel	s5, s5, s4, ne
	mov.s	v6[1], v16[0]
	mov.s	v6[2], v17[0]
	mov.s	v6[3], v18[0]
	mov.s	v7[1], v19[0]
	mov.s	v7[2], v20[0]
	mov.s	v7[3], v5[0]
	rbit	w21, w21
	clz	w21, w21
	stp	q6, q7, [x11, #464]
	and	x24, x21, #0x7
	add	x25, sp, #624
	ldr	s5, [x25, x24, lsl #2]
	fadd	s4, s5, s4
	mov	w24, #1145044992                ; =0x44400000
	fmov	s5, w24
	fdiv	s4, s4, s5
	dup.4s	v4, v4[0]
	add	x24, sp, #2, lsl #12            ; =8192
	add	x24, x24, #2016
	add	x25, sp, #1, lsl #12            ; =4096
	add	x25, x25, #3040
LBB0_22:                                ; %direct.true103
                                        ; =>This Inner Loop Header: Depth=1
	add	x26, x24, x23
	ldp	q6, q5, [x26]
	fsub.4s	v6, v6, v4
	fsub.4s	v5, v5, v4
	add	x26, x25, x23
	ldp	q7, q16, [x26]
	bif.16b	v5, v16, v0
	bif.16b	v6, v7, v1
	stp	q6, q5, [x26]
	add	x23, x23, #32
	cmp	x23, #3072
	b.ne	LBB0_22
; %bb.23:                               ; %direct.false104
	ldr	q4, [x11, #6992]
	ldr	q5, [x11, #6976]
	fmul.4s	v5, v5, v5
	fmul.4s	v4, v4, v4
	ldr	q6, [x11, #7024]
	ldr	q7, [x11, #7008]
	fmul.4s	v7, v7, v7
	fmul.4s	v16, v6, v6
	ldr	q6, [x11, #7056]
	ldr	q17, [x11, #7040]
	fmul.4s	v17, v17, v17
	fmul.4s	v20, v6, v6
	ldr	q6, [x11, #7088]
	ldr	q18, [x11, #7072]
	fmul.4s	v21, v18, v18
	fmul.4s	v22, v6, v6
	and.16b	v6, v0, v4
	and.16b	v5, v1, v5
	and.16b	v19, v0, v16
	and.16b	v18, v1, v7
	and.16b	v7, v0, v20
	and.16b	v20, v1, v17
	and.16b	v17, v0, v22
	and.16b	v16, v1, v21
	add	x23, sp, #1, lsl #12            ; =4096
	add	x23, x23, #3040
	add	x23, x23, #224
	mov	w24, #4                         ; =0x4
LBB0_24:                                ; %direct.true134
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q21, q4, [x23, #-96]
	and.16b	v21, v1, v21
	and.16b	v4, v0, v4
	fmul.4s	v4, v4, v4
	fmul.4s	v21, v21, v21
	fadd.4s	v21, v5, v21
	fadd.4s	v4, v6, v4
	ldp	q23, q22, [x23, #-64]
	and.16b	v23, v1, v23
	and.16b	v22, v0, v22
	fmul.4s	v22, v22, v22
	fmul.4s	v23, v23, v23
	fadd.4s	v23, v18, v23
	fadd.4s	v22, v19, v22
	ldp	q25, q24, [x23, #-32]
	and.16b	v25, v1, v25
	and.16b	v24, v0, v24
	fmul.4s	v24, v24, v24
	fmul.4s	v25, v25, v25
	fadd.4s	v25, v20, v25
	fadd.4s	v24, v7, v24
	ldp	q27, q26, [x23], #128
	and.16b	v27, v1, v27
	and.16b	v26, v0, v26
	fmul.4s	v26, v26, v26
	fmul.4s	v27, v27, v27
	fadd.4s	v27, v16, v27
	fadd.4s	v26, v17, v26
	bit.16b	v6, v4, v0
	bit.16b	v5, v21, v1
	bit.16b	v19, v22, v0
	bit.16b	v18, v23, v1
	bit.16b	v7, v24, v0
	bit.16b	v20, v25, v1
	bit.16b	v17, v26, v0
	bit.16b	v16, v27, v1
	cmp	x24, #92
	add	x24, x24, #4
	b.lo	LBB0_24
; %bb.25:                               ; %direct.true173.preheader
	mov	x23, #0                         ; =0x0
	fmov	w24, s2
	add	x25, sp, #4064
	b	LBB0_27
LBB0_26:                                ; %else106
                                        ;   in Loop: Header=BB0_27 Depth=1
	add	x26, x25, x23
	stp	q4, q21, [x26]
	add	x23, x23, #32
	cmp	x23, #3072
	b.eq	LBB0_43
LBB0_27:                                ; %direct.true173
                                        ; =>This Inner Loop Header: Depth=1
	add	x26, x13, x23
	add	x28, x25, x23
	ldr	q4, [x28]
	tbnz	w24, #0, LBB0_35
; %bb.28:                               ; %else85
                                        ;   in Loop: Header=BB0_27 Depth=1
	and	w27, w24, #0xff
	tbnz	w27, #1, LBB0_36
LBB0_29:                                ; %else88
                                        ;   in Loop: Header=BB0_27 Depth=1
	tbnz	w27, #2, LBB0_37
LBB0_30:                                ; %else91
                                        ;   in Loop: Header=BB0_27 Depth=1
	tbnz	w27, #3, LBB0_38
LBB0_31:                                ; %else94
                                        ;   in Loop: Header=BB0_27 Depth=1
	ldr	q21, [x28, #16]
	tbnz	w27, #4, LBB0_39
LBB0_32:                                ; %else97
                                        ;   in Loop: Header=BB0_27 Depth=1
	tbnz	w27, #5, LBB0_40
LBB0_33:                                ; %else100
                                        ;   in Loop: Header=BB0_27 Depth=1
	tbnz	w27, #6, LBB0_41
LBB0_34:                                ; %else103
                                        ;   in Loop: Header=BB0_27 Depth=1
	tbz	w27, #7, LBB0_26
	b	LBB0_42
LBB0_35:                                ; %cond.load84
                                        ;   in Loop: Header=BB0_27 Depth=1
	ld1.s	{ v4 }[0], [x26]
	and	w27, w24, #0xff
	tbz	w27, #1, LBB0_29
LBB0_36:                                ; %cond.load87
                                        ;   in Loop: Header=BB0_27 Depth=1
	add	x30, x26, #4
	ld1.s	{ v4 }[1], [x30]
	tbz	w27, #2, LBB0_30
LBB0_37:                                ; %cond.load90
                                        ;   in Loop: Header=BB0_27 Depth=1
	add	x30, x26, #8
	ld1.s	{ v4 }[2], [x30]
	tbz	w27, #3, LBB0_31
LBB0_38:                                ; %cond.load93
                                        ;   in Loop: Header=BB0_27 Depth=1
	add	x30, x26, #12
	ld1.s	{ v4 }[3], [x30]
	ldr	q21, [x28, #16]
	tbz	w27, #4, LBB0_32
LBB0_39:                                ; %cond.load96
                                        ;   in Loop: Header=BB0_27 Depth=1
	add	x28, x26, #16
	ld1.s	{ v21 }[0], [x28]
	tbz	w27, #5, LBB0_33
LBB0_40:                                ; %cond.load99
                                        ;   in Loop: Header=BB0_27 Depth=1
	add	x28, x26, #20
	ld1.s	{ v21 }[1], [x28]
	tbz	w27, #6, LBB0_34
LBB0_41:                                ; %cond.load102
                                        ;   in Loop: Header=BB0_27 Depth=1
	add	x28, x26, #24
	ld1.s	{ v21 }[2], [x28]
	tbz	w27, #7, LBB0_26
LBB0_42:                                ; %cond.load105
                                        ;   in Loop: Header=BB0_27 Depth=1
	add	x26, x26, #28
	ld1.s	{ v21 }[3], [x26]
	b	LBB0_26
LBB0_43:                                ; %direct.false174
Lloh6:
	adrp	x13, lCPI0_3@PAGE
Lloh7:
	ldr	q4, [x13, lCPI0_3@PAGEOFF]
	and.16b	v23, v0, v4
Lloh8:
	adrp	x13, lCPI0_4@PAGE
Lloh9:
	ldr	q4, [x13, lCPI0_4@PAGEOFF]
	and.16b	v24, v1, v4
Lloh10:
	adrp	x13, lCPI0_5@PAGE
Lloh11:
	ldr	q4, [x13, lCPI0_5@PAGEOFF]
	and.16b	v21, v0, v4
Lloh12:
	adrp	x13, lCPI0_6@PAGE
Lloh13:
	ldr	q4, [x13, lCPI0_6@PAGEOFF]
	and.16b	v22, v1, v4
	movi.4s	v4, #4
	and.16b	v4, v1, v4
	fadd.4s	v6, v6, v19
	fadd.4s	v5, v5, v18
	fadd.4s	v18, v5, v20
	fadd.4s	v5, v6, v7
	fadd.4s	v5, v5, v17
	fadd.4s	v6, v18, v16
	fmov	w23, s24
	add	x13, sp, #24
	add	x24, sp, #24
	bfxil	x24, x23, #0, #3
	str	d3, [sp, #24]
	ldrb	w24, [x24]
	add	x25, sp, #576
	orr	x23, x25, x23, lsl #2
	stp	q6, q5, [x11, #416]
	ldr	s7, [x23]
	tst	w4, w24
	movi.2d	v3, #0000000000000000
	fcsel	s7, s7, s3, ne
	mov.s	w23, v24[1]
	add	x24, sp, #24
	bfxil	x24, x23, #0, #3
	ldrb	w23, [x24]
	and	w23, w14, w23
	str	q6, [x11, #384]
	ldr	s16, [sp, #544]
	tst	w23, #0x1
	mov.s	w23, v24[2]
	fcsel	s16, s16, s3, ne
	add	x24, sp, #512
	orr	x24, x24, x23, lsl #2
	add	x25, sp, #24
	bfxil	x25, x23, #0, #3
	ldrb	w23, [x25]
	and	w23, w15, w23
	stp	q6, q5, [x11, #352]
	ldr	s17, [x24]
	tst	w23, #0x1
	fcsel	s17, s17, s3, ne
	mov.s	w23, v24[3]
	add	x24, sp, #480
	orr	x24, x24, x23, lsl #2
	add	x25, sp, #24
	bfxil	x25, x23, #0, #3
	ldrb	w23, [x25]
	and	w23, w16, w23
	stp	q6, q5, [x11, #320]
	ldr	s18, [x24]
	tst	w23, #0x1
	fcsel	s18, s18, s3, ne
	fmov	w23, s23
	add	x24, sp, #24
	bfxil	x24, x23, #0, #3
	ldrb	w24, [x24]
	and	w24, w17, w24
	stp	q6, q5, [x11, #288]
	add	x25, sp, #448
	ldr	s19, [x25, w23, uxtw #2]
	tst	w24, #0x1
	fcsel	s19, s19, s3, ne
	mov.s	w23, v23[1]
	add	x24, sp, #24
	bfxil	x24, x23, #0, #3
	ldrb	w24, [x24]
	and	w24, w0, w24
	stp	q6, q5, [x11, #256]
	add	x25, sp, #416
	ldr	s20, [x25, w23, uxtw #2]
	tst	w24, #0x1
	fcsel	s20, s20, s3, ne
	mov.s	w23, v23[2]
	add	x24, sp, #24
	bfxil	x24, x23, #0, #3
	ldrb	w24, [x24]
	stp	q6, q5, [x11, #224]
	add	x25, sp, #384
	ldr	s24, [x25, w23, uxtw #2]
	and	w23, w1, w24
	tst	w23, #0x1
	fcsel	s24, s24, s3, ne
	mov.s	w23, v23[3]
	add	x24, sp, #24
	bfxil	x24, x23, #0, #3
	ldrb	w24, [x24]
	and	w24, w2, w24
	stp	q6, q5, [x11, #192]
	add	x25, sp, #352
	ldr	s23, [x25, w23, uxtw #2]
	tst	w24, #0x1
	fcsel	s23, s23, s3, ne
	mov.s	v7[1], v16[0]
	mov.s	v7[2], v17[0]
	mov.s	v7[3], v18[0]
	mov.s	v19[1], v20[0]
	mov.s	v19[2], v24[0]
	mov.s	v19[3], v23[0]
	fadd.4s	v5, v5, v19
	fadd.4s	v6, v6, v7
	fmov	w23, s22
	add	x24, sp, #24
	bfxil	x24, x23, #0, #3
	ldrb	w24, [x24]
	add	x25, sp, #320
	orr	x23, x25, x23, lsl #2
	stp	q6, q5, [x11, #160]
	ldr	s7, [x23]
	tst	w4, w24
	mov.s	w23, v22[1]
	fcsel	s7, s7, s3, ne
	add	x24, sp, #288
	orr	x24, x24, x23, lsl #2
	add	x25, sp, #24
	bfxil	x25, x23, #0, #3
	ldrb	w23, [x25]
	and	w14, w14, w23
	stp	q6, q5, [x11, #128]
	ldr	s16, [x24]
	tst	w14, #0x1
	fcsel	s16, s16, s3, ne
	mov.s	w14, v22[2]
	add	x23, sp, #24
	bfxil	x23, x14, #0, #3
	ldrb	w14, [x23]
	and	w14, w15, w14
	str	q6, [x11, #96]
	ldr	s17, [sp, #256]
	tst	w14, #0x1
	fcsel	s17, s17, s3, ne
	mov.s	w14, v22[3]
	add	x15, sp, #224
	orr	x15, x15, x14, lsl #2
	add	x23, sp, #24
	bfxil	x23, x14, #0, #3
	ldrb	w14, [x23]
	and	w14, w16, w14
	stp	q6, q5, [x11, #64]
	ldr	s18, [x15]
	tst	w14, #0x1
	fcsel	s18, s18, s3, ne
	fmov	w14, s21
	add	x15, sp, #24
	bfxil	x15, x14, #0, #3
	ldrb	w15, [x15]
	and	w15, w17, w15
	stp	q6, q5, [x11, #32]
	add	x16, sp, #192
	ldr	s19, [x16, w14, uxtw #2]
	tst	w15, #0x1
	mov.s	w14, v21[1]
	fcsel	s19, s19, s3, ne
	add	x15, sp, #24
	bfxil	x15, x14, #0, #3
	ldrb	w15, [x15]
	and	w15, w0, w15
	stp	q6, q5, [x11]
	add	x11, sp, #160
	ldr	s20, [x11, w14, uxtw #2]
	tst	w15, #0x1
	fcsel	s20, s20, s3, ne
	mov.s	w11, v21[2]
	add	x14, sp, #24
	bfxil	x14, x11, #0, #3
	ldrb	w14, [x14]
	and	w14, w1, w14
	stp	q6, q5, [sp, #128]
	add	x15, sp, #128
	ldr	s22, [x15, w11, uxtw #2]
	tst	w14, #0x1
	fcsel	s22, s22, s3, ne
	mov.s	w11, v21[3]
	add	x14, sp, #24
	bfxil	x14, x11, #0, #3
	ldrb	w14, [x14]
	and	w14, w2, w14
	stp	q6, q5, [sp, #96]
	add	x15, sp, #96
	ldr	s21, [x15, w11, uxtw #2]
	tst	w14, #0x1
	fcsel	s21, s21, s3, ne
	mov.s	v19[1], v20[0]
	mov.s	v19[2], v22[0]
	mov.s	v19[3], v21[0]
	mov.s	v7[1], v16[0]
	mov.s	v7[2], v17[0]
	mov.s	v7[3], v18[0]
	fadd.4s	v6, v6, v7
	fadd.4s	v5, v5, v19
	fmov	w11, s4
	orr	x13, x13, x11
	ldrb	w13, [x13]
	stp	q6, q5, [sp, #64]
	add	x14, sp, #64
	ldr	s4, [x14, w11, uxtw #2]
	tst	w4, w13
	fcsel	s4, s4, s3, ne
	tst	w12, #0x1
	fadd	s4, s6, s4
	fcsel	s5, s4, s3, ne
	tst	w5, #0x1
	fcsel	s6, s4, s3, ne
	tst	w6, #0x1
	fcsel	s7, s4, s3, ne
	tst	w7, #0x1
	fcsel	s16, s4, s3, ne
	tst	w3, #0x1
	fcsel	s17, s4, s3, ne
	tst	w19, #0x1
	fcsel	s18, s4, s3, ne
	tst	w20, #0x1
	fcsel	s19, s4, s3, ne
	tst	w22, #0x1
	fcsel	s4, s4, s3, ne
	mov.s	v5[1], v6[0]
	mov.s	v5[2], v7[0]
	mov.s	v5[3], v16[0]
	mov.s	v17[1], v18[0]
	mov.s	v17[2], v19[0]
	mov.s	v17[3], v4[0]
	stp	q5, q17, [sp, #32]
	and	x11, x21, #0x7
	add	x12, sp, #32
	ldr	s4, [x12, x11, lsl #2]
	fadd	s3, s4, s3
	mov	w11, #1145044992                ; =0x44400000
	fmov	s4, w11
	fdiv	s3, s3, s4
	mov	w11, #50604                     ; =0xc5ac
	movk	w11, #14119, lsl #16
	fmov	s4, w11
	fadd	s3, s3, s4
	fsqrt	s3, s3
	subs	x11, x9, x8
	cset	w12, hs
	cmp	x11, #3071
	csel	w11, wzr, w12, ls
	subs	x12, x8, x9
	lsr	x12, x12, #10
	mov	w13, #386                       ; =0x182
	ccmp	x12, x13, #0, hs
	b.hi	LBB0_63
; %bb.44:                               ; %direct.false174
	tbnz	w11, #0, LBB0_63
; %bb.45:                               ; %direct.true225.preheader
	mov	x11, #0                         ; =0x0
	fmov	w12, s2
	add	x13, sp, #992
	b	LBB0_47
LBB0_46:                                ; %else172
                                        ;   in Loop: Header=BB0_47 Depth=1
	add	x14, x13, x11
	stp	q4, q5, [x14]
	add	x11, x11, #32
	cmp	x11, #3072
	b.eq	LBB0_97
LBB0_47:                                ; %direct.true225
                                        ; =>This Inner Loop Header: Depth=1
	add	x14, x8, x11
	add	x16, x13, x11
	ldr	q4, [x16]
	tbnz	w12, #0, LBB0_55
; %bb.48:                               ; %else151
                                        ;   in Loop: Header=BB0_47 Depth=1
	and	w15, w12, #0xff
	tbnz	w15, #1, LBB0_56
LBB0_49:                                ; %else154
                                        ;   in Loop: Header=BB0_47 Depth=1
	tbnz	w15, #2, LBB0_57
LBB0_50:                                ; %else157
                                        ;   in Loop: Header=BB0_47 Depth=1
	tbnz	w15, #3, LBB0_58
LBB0_51:                                ; %else160
                                        ;   in Loop: Header=BB0_47 Depth=1
	ldr	q5, [x16, #16]
	tbnz	w15, #4, LBB0_59
LBB0_52:                                ; %else163
                                        ;   in Loop: Header=BB0_47 Depth=1
	tbnz	w15, #5, LBB0_60
LBB0_53:                                ; %else166
                                        ;   in Loop: Header=BB0_47 Depth=1
	tbnz	w15, #6, LBB0_61
LBB0_54:                                ; %else169
                                        ;   in Loop: Header=BB0_47 Depth=1
	tbz	w15, #7, LBB0_46
	b	LBB0_62
LBB0_55:                                ; %cond.load150
                                        ;   in Loop: Header=BB0_47 Depth=1
	ld1.s	{ v4 }[0], [x14]
	and	w15, w12, #0xff
	tbz	w15, #1, LBB0_49
LBB0_56:                                ; %cond.load153
                                        ;   in Loop: Header=BB0_47 Depth=1
	add	x17, x14, #4
	ld1.s	{ v4 }[1], [x17]
	tbz	w15, #2, LBB0_50
LBB0_57:                                ; %cond.load156
                                        ;   in Loop: Header=BB0_47 Depth=1
	add	x17, x14, #8
	ld1.s	{ v4 }[2], [x17]
	tbz	w15, #3, LBB0_51
LBB0_58:                                ; %cond.load159
                                        ;   in Loop: Header=BB0_47 Depth=1
	add	x17, x14, #12
	ld1.s	{ v4 }[3], [x17]
	ldr	q5, [x16, #16]
	tbz	w15, #4, LBB0_52
LBB0_59:                                ; %cond.load162
                                        ;   in Loop: Header=BB0_47 Depth=1
	add	x16, x14, #16
	ld1.s	{ v5 }[0], [x16]
	tbz	w15, #5, LBB0_53
LBB0_60:                                ; %cond.load165
                                        ;   in Loop: Header=BB0_47 Depth=1
	add	x16, x14, #20
	ld1.s	{ v5 }[1], [x16]
	tbz	w15, #6, LBB0_54
LBB0_61:                                ; %cond.load168
                                        ;   in Loop: Header=BB0_47 Depth=1
	add	x16, x14, #24
	ld1.s	{ v5 }[2], [x16]
	tbz	w15, #7, LBB0_46
LBB0_62:                                ; %cond.load171
                                        ;   in Loop: Header=BB0_47 Depth=1
	add	x14, x14, #28
	ld1.s	{ v5 }[3], [x14]
	b	LBB0_46
LBB0_63:                                ; %direct.schedule.17.preheader
	mov	x11, #0                         ; =0x0
	dup.4s	v3, v3[0]
	add	x9, x9, x10
	fmov	w10, s2
	add	x12, sp, #1, lsl #12            ; =4096
	add	x12, x12, #3040
	add	x13, sp, #4064
	b	LBB0_65
LBB0_64:                                ; %else148
                                        ;   in Loop: Header=BB0_65 Depth=1
	add	x11, x11, #32
	cmp	x11, #3072
	b.eq	LBB0_115
LBB0_65:                                ; %direct.true195
                                        ; =>This Inner Loop Header: Depth=1
	add	x14, x8, x11
	movi.2d	v5, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbnz	w10, #0, LBB0_82
; %bb.66:                               ; %else110
                                        ;   in Loop: Header=BB0_65 Depth=1
	and	w15, w10, #0xff
	tbnz	w15, #1, LBB0_83
LBB0_67:                                ; %else113
                                        ;   in Loop: Header=BB0_65 Depth=1
	tbnz	w15, #2, LBB0_84
LBB0_68:                                ; %else116
                                        ;   in Loop: Header=BB0_65 Depth=1
	tbnz	w15, #3, LBB0_85
LBB0_69:                                ; %else119
                                        ;   in Loop: Header=BB0_65 Depth=1
	tbnz	w15, #4, LBB0_86
LBB0_70:                                ; %else122
                                        ;   in Loop: Header=BB0_65 Depth=1
	tbnz	w15, #5, LBB0_87
LBB0_71:                                ; %else125
                                        ;   in Loop: Header=BB0_65 Depth=1
	tbnz	w15, #6, LBB0_88
LBB0_72:                                ; %else128
                                        ;   in Loop: Header=BB0_65 Depth=1
	tbz	w15, #7, LBB0_74
LBB0_73:                                ; %cond.load130
                                        ;   in Loop: Header=BB0_65 Depth=1
	add	x14, x14, #28
	ld1.s	{ v4 }[3], [x14]
LBB0_74:                                ; %else131
                                        ;   in Loop: Header=BB0_65 Depth=1
	add	x16, x12, x11
	ldr	q6, [x16]
	and.16b	v6, v1, v6
	fdiv.4s	v6, v6, v3
	add	x17, x13, x11
	ldr	q7, [x17]
	and.16b	v7, v1, v7
	fmul.4s	v6, v6, v7
	fmov	w15, s2
	fadd.4s	v5, v5, v6
	add	x14, x9, x11
	tbnz	w15, #0, LBB0_89
; %bb.75:                               ; %else134
                                        ;   in Loop: Header=BB0_65 Depth=1
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB0_90
LBB0_76:                                ; %else136
                                        ;   in Loop: Header=BB0_65 Depth=1
	ldr	q7, [x16, #16]
	ldr	q6, [x17, #16]
	tbnz	w15, #2, LBB0_91
LBB0_77:                                ; %else138
                                        ;   in Loop: Header=BB0_65 Depth=1
	tbnz	w15, #3, LBB0_92
LBB0_78:                                ; %else140
                                        ;   in Loop: Header=BB0_65 Depth=1
	and.16b	v5, v0, v7
	fdiv.4s	v5, v5, v3
	and.16b	v6, v0, v6
	fmul.4s	v5, v5, v6
	fadd.4s	v4, v4, v5
	tbnz	w15, #4, LBB0_93
LBB0_79:                                ; %else142
                                        ;   in Loop: Header=BB0_65 Depth=1
	tbnz	w15, #5, LBB0_94
LBB0_80:                                ; %else144
                                        ;   in Loop: Header=BB0_65 Depth=1
	tbnz	w15, #6, LBB0_95
LBB0_81:                                ; %else146
                                        ;   in Loop: Header=BB0_65 Depth=1
	tbz	w15, #7, LBB0_64
	b	LBB0_96
LBB0_82:                                ; %cond.load109
                                        ;   in Loop: Header=BB0_65 Depth=1
	ldr	s5, [x14]
	and	w15, w10, #0xff
	tbz	w15, #1, LBB0_67
LBB0_83:                                ; %cond.load112
                                        ;   in Loop: Header=BB0_65 Depth=1
	add	x16, x14, #4
	ld1.s	{ v5 }[1], [x16]
	tbz	w15, #2, LBB0_68
LBB0_84:                                ; %cond.load115
                                        ;   in Loop: Header=BB0_65 Depth=1
	add	x16, x14, #8
	ld1.s	{ v5 }[2], [x16]
	tbz	w15, #3, LBB0_69
LBB0_85:                                ; %cond.load118
                                        ;   in Loop: Header=BB0_65 Depth=1
	add	x16, x14, #12
	ld1.s	{ v5 }[3], [x16]
	tbz	w15, #4, LBB0_70
LBB0_86:                                ; %cond.load121
                                        ;   in Loop: Header=BB0_65 Depth=1
	add	x16, x14, #16
	ld1.s	{ v4 }[0], [x16]
	tbz	w15, #5, LBB0_71
LBB0_87:                                ; %cond.load124
                                        ;   in Loop: Header=BB0_65 Depth=1
	add	x16, x14, #20
	ld1.s	{ v4 }[1], [x16]
	tbz	w15, #6, LBB0_72
LBB0_88:                                ; %cond.load127
                                        ;   in Loop: Header=BB0_65 Depth=1
	add	x16, x14, #24
	ld1.s	{ v4 }[2], [x16]
	tbnz	w15, #7, LBB0_73
	b	LBB0_74
LBB0_89:                                ; %cond.store
                                        ;   in Loop: Header=BB0_65 Depth=1
	str	s5, [x14]
	and	w15, w15, #0xff
	tbz	w15, #1, LBB0_76
LBB0_90:                                ; %cond.store135
                                        ;   in Loop: Header=BB0_65 Depth=1
	add	x0, x14, #4
	st1.s	{ v5 }[1], [x0]
	ldr	q7, [x16, #16]
	ldr	q6, [x17, #16]
	tbz	w15, #2, LBB0_77
LBB0_91:                                ; %cond.store137
                                        ;   in Loop: Header=BB0_65 Depth=1
	add	x16, x14, #8
	st1.s	{ v5 }[2], [x16]
	tbz	w15, #3, LBB0_78
LBB0_92:                                ; %cond.store139
                                        ;   in Loop: Header=BB0_65 Depth=1
	add	x16, x14, #12
	st1.s	{ v5 }[3], [x16]
	and.16b	v5, v0, v7
	fdiv.4s	v5, v5, v3
	and.16b	v6, v0, v6
	fmul.4s	v5, v5, v6
	fadd.4s	v4, v4, v5
	tbz	w15, #4, LBB0_79
LBB0_93:                                ; %cond.store141
                                        ;   in Loop: Header=BB0_65 Depth=1
	str	s4, [x14, #16]
	tbz	w15, #5, LBB0_80
LBB0_94:                                ; %cond.store143
                                        ;   in Loop: Header=BB0_65 Depth=1
	add	x16, x14, #20
	st1.s	{ v4 }[1], [x16]
	tbz	w15, #6, LBB0_81
LBB0_95:                                ; %cond.store145
                                        ;   in Loop: Header=BB0_65 Depth=1
	add	x16, x14, #24
	st1.s	{ v4 }[2], [x16]
	tbz	w15, #7, LBB0_64
LBB0_96:                                ; %cond.store147
                                        ;   in Loop: Header=BB0_65 Depth=1
	add	x14, x14, #28
	st1.s	{ v4 }[3], [x14]
	b	LBB0_64
LBB0_97:                                ; %direct.schedule.24.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x9, x10
	dup.4s	v3, v3[0]
	fmov	w10, s2
	add	x11, sp, #1, lsl #12            ; =4096
	add	x11, x11, #3040
	add	x12, sp, #4064
	add	x13, sp, #992
	b	LBB0_99
LBB0_98:                                ; %else190
                                        ;   in Loop: Header=BB0_99 Depth=1
	add	x8, x8, #32
	cmp	x8, #3072
	b.eq	LBB0_115
LBB0_99:                                ; %direct.true244
                                        ; =>This Inner Loop Header: Depth=1
	add	x16, x11, x8
	ldr	q2, [x16]
	and.16b	v2, v1, v2
	fdiv.4s	v2, v2, v3
	add	x17, x12, x8
	ldr	q4, [x17]
	and.16b	v4, v1, v4
	fmul.4s	v2, v2, v4
	add	x0, x13, x8
	ldr	q4, [x0]
	and.16b	v4, v1, v4
	fadd.4s	v2, v2, v4
	add	x14, x9, x8
	tbnz	w10, #0, LBB0_108
; %bb.100:                              ; %else176
                                        ;   in Loop: Header=BB0_99 Depth=1
	and	w15, w10, #0xff
	tbnz	w15, #1, LBB0_109
LBB0_101:                               ; %else178
                                        ;   in Loop: Header=BB0_99 Depth=1
	tbnz	w15, #2, LBB0_110
LBB0_102:                               ; %else180
                                        ;   in Loop: Header=BB0_99 Depth=1
	tbz	w15, #3, LBB0_104
LBB0_103:                               ; %cond.store181
                                        ;   in Loop: Header=BB0_99 Depth=1
	add	x1, x14, #12
	st1.s	{ v2 }[3], [x1]
LBB0_104:                               ; %else182
                                        ;   in Loop: Header=BB0_99 Depth=1
	ldr	q2, [x16, #16]
	and.16b	v2, v0, v2
	fdiv.4s	v2, v2, v3
	ldr	q4, [x17, #16]
	and.16b	v4, v0, v4
	fmul.4s	v2, v2, v4
	ldr	q4, [x0, #16]
	and.16b	v4, v0, v4
	fadd.4s	v2, v2, v4
	tbnz	w15, #4, LBB0_111
; %bb.105:                              ; %else184
                                        ;   in Loop: Header=BB0_99 Depth=1
	tbnz	w15, #5, LBB0_112
LBB0_106:                               ; %else186
                                        ;   in Loop: Header=BB0_99 Depth=1
	tbnz	w15, #6, LBB0_113
LBB0_107:                               ; %else188
                                        ;   in Loop: Header=BB0_99 Depth=1
	tbz	w15, #7, LBB0_98
	b	LBB0_114
LBB0_108:                               ; %cond.store175
                                        ;   in Loop: Header=BB0_99 Depth=1
	str	s2, [x14]
	and	w15, w10, #0xff
	tbz	w15, #1, LBB0_101
LBB0_109:                               ; %cond.store177
                                        ;   in Loop: Header=BB0_99 Depth=1
	add	x1, x14, #4
	st1.s	{ v2 }[1], [x1]
	tbz	w15, #2, LBB0_102
LBB0_110:                               ; %cond.store179
                                        ;   in Loop: Header=BB0_99 Depth=1
	add	x1, x14, #8
	st1.s	{ v2 }[2], [x1]
	tbnz	w15, #3, LBB0_103
	b	LBB0_104
LBB0_111:                               ; %cond.store183
                                        ;   in Loop: Header=BB0_99 Depth=1
	str	s2, [x14, #16]
	tbz	w15, #5, LBB0_106
LBB0_112:                               ; %cond.store185
                                        ;   in Loop: Header=BB0_99 Depth=1
	add	x16, x14, #20
	st1.s	{ v2 }[1], [x16]
	tbz	w15, #6, LBB0_107
LBB0_113:                               ; %cond.store187
                                        ;   in Loop: Header=BB0_99 Depth=1
	add	x16, x14, #24
	st1.s	{ v2 }[2], [x16]
	tbz	w15, #7, LBB0_98
LBB0_114:                               ; %cond.store189
                                        ;   in Loop: Header=BB0_99 Depth=1
	add	x14, x14, #28
	st1.s	{ v2 }[3], [x14]
	b	LBB0_98
LBB0_115:
	add	sp, sp, #3, lsl #12             ; =12288
	add	sp, sp, #992
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
LBB0_116:                               ; %common.ret
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
                                        ; -- End function
	.p2align	2                               ; -- Begin function llm_rows.full_packet
_llm_rows.full_packet:                  ; @llm_rows.full_packet
; %bb.0:                                ; %prologue
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	sub	sp, sp, #3, lsl #12             ; =12288
	sub	sp, sp, #128
	ldr	x8, [x0]
	ldr	x20, [x0, #16]
	ldr	x19, [x0, #32]
	ldr	x21, [x0, #48]
	ldr	w9, [x1]
	ldr	w10, [x1, #36]
	add	w9, w10, w9, lsl #5
	lsr	w9, w9, #3
	mov	w10, #3072                      ; =0xc00
	umull	x22, w9, w10
	umaddl	x1, w9, w10, x8
	add	x23, sp, #2, lsl #12            ; =8192
	add	x23, x23, #1152
	add	x0, sp, #2, lsl #12             ; =8192
	add	x0, x0, #1152
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	ldr	q0, [sp, #9360]
	ldr	q2, [sp, #9344]
	ldr	q1, [sp, #9392]
	ldr	q5, [sp, #9376]
	ldr	q4, [sp, #9424]
	ldr	q3, [sp, #9408]
	add	x8, x23, #224
	mov	w9, #4                          ; =0x4
	ldr	q6, [sp, #9456]
	ldr	q7, [sp, #9440]
LBB1_1:                                 ; %direct.true66
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q16, q17, [x8, #-96]
	fadd.4s	v0, v0, v17
	fadd.4s	v2, v2, v16
	ldp	q16, q17, [x8, #-64]
	fadd.4s	v1, v1, v17
	fadd.4s	v5, v5, v16
	ldp	q16, q17, [x8, #-32]
	fadd.4s	v4, v4, v17
	fadd.4s	v3, v3, v16
	ldp	q16, q17, [x8], #128
	fadd.4s	v6, v6, v17
	fadd.4s	v7, v7, v16
	cmp	x9, #92
	add	x9, x9, #4
	b.lo	LBB1_1
; %bb.2:                                ; %direct.false67
	mov	x8, #0                          ; =0x0
	fadd.4s	v2, v2, v5
	fadd.4s	v0, v0, v1
	fadd.4s	v0, v0, v4
	fadd.4s	v1, v2, v3
	fadd.4s	v1, v1, v7
	fadd.4s	v0, v0, v6
	rev64.4s	v2, v0
	rev64.4s	v3, v1
	fadd.4s	v1, v1, v3
	fadd.4s	v0, v0, v2
	dup.4s	v2, v0[2]
	dup.4s	v3, v1[2]
	fadd.4s	v1, v1, v3
	fadd.4s	v0, v0, v2
	fadd.4s	v0, v1, v0
	movi.2d	v1, #0000000000000000
	fadd	s0, s0, s1
	mov	w9, #1145044992                 ; =0x44400000
	fmov	s1, w9
	fdiv	s0, s0, s1
	dup.4s	v0, v0[0]
	add	x9, sp, #2, lsl #12             ; =8192
	add	x9, x9, #1152
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #2176
LBB1_3:                                 ; %direct.true103
                                        ; =>This Inner Loop Header: Depth=1
	add	x11, x9, x8
	ldp	q2, q1, [x11]
	fsub.4s	v2, v2, v0
	fsub.4s	v1, v1, v0
	add	x11, x10, x8
	stp	q2, q1, [x11]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB1_3
; %bb.4:                                ; %direct.false104
	ldr	q0, [sp, #6272]
	ldr	q1, [sp, #6288]
	fmul.4s	v2, v1, v1
	fmul.4s	v3, v0, v0
	ldr	q0, [sp, #6304]
	ldr	q1, [sp, #6320]
	fmul.4s	v4, v1, v1
	fmul.4s	v5, v0, v0
	ldr	q0, [sp, #6336]
	ldr	q1, [sp, #6352]
	fmul.4s	v7, v1, v1
	fmul.4s	v6, v0, v0
	ldr	q0, [sp, #6368]
	ldr	q1, [sp, #6384]
	fmul.4s	v16, v1, v1
	fmul.4s	v17, v0, v0
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2176
	add	x8, x8, #224
	mov	w9, #4                          ; =0x4
LBB1_5:                                 ; %direct.true134
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q1, q0, [x8, #-96]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v2, v2, v0
	fadd.4s	v3, v3, v1
	ldp	q1, q0, [x8, #-64]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v4, v4, v0
	fadd.4s	v5, v5, v1
	ldp	q1, q0, [x8, #-32]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v7, v7, v0
	fadd.4s	v6, v6, v1
	ldp	q1, q0, [x8], #128
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v16, v16, v0
	fadd.4s	v17, v17, v1
	cmp	x9, #92
	add	x9, x9, #4
	b.lo	LBB1_5
; %bb.6:                                ; %direct.false135
	add	x23, sp, #3200
	add	x0, sp, #3200
	mov	x1, x20
	mov	w2, #3072                       ; =0xc00
	stp	q4, q2, [sp, #48]               ; 32-byte Folded Spill
	stp	q5, q3, [sp]                    ; 32-byte Folded Spill
	stp	q6, q16, [sp, #96]              ; 32-byte Folded Spill
	str	q7, [sp, #32]                   ; 16-byte Spill
	str	q17, [sp, #80]                  ; 16-byte Spill
	bl	_memcpy
	ldp	q1, q0, [sp]                    ; 32-byte Folded Reload
	fadd.4s	v0, v0, v1
	ldp	q2, q1, [sp, #48]               ; 32-byte Folded Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #32]                   ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldp	q2, q3, [sp, #80]               ; 32-byte Folded Reload
	fadd.4s	v0, v0, v3
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #112]                  ; 16-byte Reload
	fadd.4s	v1, v1, v2
	rev64.4s	v2, v1
	rev64.4s	v3, v0
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	dup.4s	v2, v1[2]
	dup.4s	v3, v0[2]
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	fadd.4s	v0, v0, v1
	movi.2d	v1, #0000000000000000
	fadd	s0, s0, s1
	mov	w8, #1145044992                 ; =0x44400000
	fmov	s1, w8
	fdiv	s0, s0, s1
	mov	w8, #50604                      ; =0xc5ac
	movk	w8, #14119, lsl #16
	fmov	s1, w8
	fadd	s0, s0, s1
	fsqrt	s0, s0
	subs	x8, x21, x19
	cset	w9, hs
	cmp	x8, #3071
	csel	w8, wzr, w9, ls
	subs	x9, x19, x21
	lsr	x9, x9, #10
	mov	w10, #386                       ; =0x182
	ccmp	x9, x10, #0, hs
	b.hi	LBB1_10
; %bb.7:                                ; %direct.false135
	tbnz	w8, #0, LBB1_10
; %bb.8:                                ; %direct.true225.preheader
	add	x20, sp, #128
	add	x0, sp, #128
	mov	x1, x19
	mov	w2, #3072                       ; =0xc00
	str	q0, [sp, #112]                  ; 16-byte Spill
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	ldr	q0, [sp, #112]                  ; 16-byte Reload
	dup.4s	v0, v0[0]
	add	x9, x21, x22
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #2176
	add	x11, sp, #3200
LBB1_9:                                 ; %direct.true244
                                        ; =>This Inner Loop Header: Depth=1
	add	x12, x10, x8
	ldp	q2, q1, [x12]
	fdiv.4s	v2, v2, v0
	fdiv.4s	v1, v1, v0
	add	x12, x11, x8
	ldp	q3, q4, [x12]
	fmul.4s	v1, v1, v4
	fmul.4s	v2, v2, v3
	add	x12, x20, x8
	ldp	q4, q3, [x12]
	fadd.4s	v2, v2, v4
	fadd.4s	v1, v1, v3
	add	x12, x9, x8
	stp	q2, q1, [x12]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB1_9
	b	LBB1_12
LBB1_10:                                ; %direct.schedule.17.preheader
	mov	x8, #0                          ; =0x0
	dup.4s	v0, v0[0]
	add	x9, x21, x22
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #2176
LBB1_11:                                ; %direct.true195
                                        ; =>This Inner Loop Header: Depth=1
	add	x11, x10, x8
	ldp	q2, q1, [x11]
	fdiv.4s	v2, v2, v0
	fdiv.4s	v1, v1, v0
	add	x11, x23, x8
	ldp	q3, q4, [x11]
	fmul.4s	v1, v1, v4
	fmul.4s	v2, v2, v3
	add	x11, x19, x8
	ldp	q4, q3, [x11]
	fadd.4s	v2, v2, v4
	fadd.4s	v1, v1, v3
	add	x11, x9, x8
	stp	q2, q1, [x11]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB1_11
LBB1_12:                                ; %common.ret
	add	sp, sp, #3, lsl #12             ; =12288
	add	sp, sp, #128
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB2_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB2_4
LBB2_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB2_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB2_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB2_13
LBB2_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB2_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB2_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #1
	b.eq	LBB2_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #2
	b.eq	LBB2_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #3
	b.eq	LBB2_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB2_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB2_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
LBB2_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB2_3
LBB2_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB2_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

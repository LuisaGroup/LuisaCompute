	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_3:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_4:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_5:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_6:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_7:
	.quad	16384                           ; 0x4000
	.quad	16388                           ; 0x4004
lCPI0_8:
	.quad	16400                           ; 0x4010
	.quad	16404                           ; 0x4014
lCPI0_9:
	.quad	16392                           ; 0x4008
	.quad	16396                           ; 0x400c
lCPI0_10:
	.quad	16408                           ; 0x4018
	.quad	16412                           ; 0x401c
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_11:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #8, lsl #12             ; =32768
	sub	sp, sp, #832
	dup.4s	v0, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q1, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q2, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v7, v0, v2
	cmhi.4s	v29, v0, v1
	uzp1.8h	v0, v29, v7
	str	q0, [sp, #240]                  ; 16-byte Spill
	umaxv.8h	h0, v0
	fmov	w8, s0
	tbz	w8, #0, LBB0_204
; %bb.1:                                ; %direct.activate
	ldr	x16, [x0]
	ldr	x2, [x0, #16]
	ldr	x3, [x0, #48]
	sshll.2d	v2, v29, #0
	sshll.2d	v3, v7, #0
	sshll2.2d	v1, v29, #0
	sshll2.2d	v0, v7, #0
	ldr	w8, [x1]
	ldr	w9, [x1, #36]
	add	w8, w9, w8, lsl #5
Lloh4:
	adrp	x9, lCPI0_2@PAGE
Lloh5:
	ldr	q4, [x9, lCPI0_2@PAGEOFF]
	and.16b	v4, v0, v4
	str	q4, [sp, #224]                  ; 16-byte Spill
Lloh6:
	adrp	x9, lCPI0_3@PAGE
Lloh7:
	ldr	q4, [x9, lCPI0_3@PAGEOFF]
	and.16b	v4, v1, v4
	str	q4, [sp, #208]                  ; 16-byte Spill
Lloh8:
	adrp	x9, lCPI0_4@PAGE
Lloh9:
	ldr	q4, [x9, lCPI0_4@PAGEOFF]
	and.16b	v3, v3, v4
	str	q3, [sp, #192]                  ; 16-byte Spill
Lloh10:
	adrp	x9, lCPI0_5@PAGE
Lloh11:
	ldr	q3, [x9, lCPI0_5@PAGEOFF]
	and.16b	v2, v2, v3
	str	q2, [sp, #128]                  ; 16-byte Spill
	lsr	w8, w8, #3
	dup.4s	v2, w8
	and.16b	v3, v29, v2
	and.16b	v2, v7, v2
	ushll2.2d	v4, v2, #0
	ushll2.2d	v5, v3, #0
	ushll.2d	v2, v2, #0
	ushll.2d	v16, v3, #0
	subs	x8, x16, x3
	cset	w9, hs
	mov	w10, #4095                      ; =0xfff
	movk	w10, #256, lsl #16
	cmp	x8, x10
	csel	w8, wzr, w9, ls
	subs	x9, x3, x16
	cset	w11, hs
	cmp	x9, x10
	csel	w9, wzr, w11, ls
	orr	w12, w8, w9
	subs	x8, x2, x3
	cset	w9, hs
	cmp	x8, x10
	csel	w8, wzr, w9, ls
	subs	x9, x3, x2
	cset	w11, hs
	cmp	x9, x10
	csel	w11, wzr, w11, ls
	fmov	x9, d16
	add	x9, x9, x9, lsl #12
	lsl	x9, x9, #2
	adrp	x10, lCPI0_6@PAGE
	xtn.2s	v3, v4
	str	d3, [sp, #176]                  ; 8-byte Spill
	xtn.2s	v2, v2
	str	d2, [sp, #160]                  ; 8-byte Spill
	xtn.2s	v2, v5
	str	d2, [sp, #144]                  ; 8-byte Spill
	adrp	x4, lCPI0_11@PAGE
	cmp	w12, #1
	stp	q29, q7, [sp, #368]             ; 32-byte Folded Spill
	b.ne	LBB0_53
; %bb.2:                                ; %direct.activate
	orr	w8, w8, w11
	cbz	w8, LBB0_53
; %bb.3:                                ; %direct.true20.preheader
	str	q16, [sp, #64]                  ; 16-byte Spill
	mov	x11, #0                         ; =0x0
	str	x3, [sp, #112]                  ; 8-byte Spill
	add	x13, x3, x9
	str	x2, [sp, #96]                   ; 8-byte Spill
	add	x14, x2, x9
	str	x16, [sp, #80]                  ; 8-byte Spill
	add	x15, x16, x9
	ldr	q0, [x10, lCPI0_6@PAGEOFF]
	ldr	q1, [sp, #240]                  ; 16-byte Reload
	and.16b	v0, v1, v0
	addv.8h	h21, v0
	fmov	w16, s21
	movi.4s	v12, #63, lsl #24
	mov	w0, #16938                      ; =0x422a
	movk	w0, #16204, lsl #16
	mov	w1, #37425                      ; =0x9231
	movk	w1, #12080, lsl #16
	mov	w2, #12843                      ; =0x322b
	movk	w2, #13015, lsl #16
	mov	w3, #61213                      ; =0xef1d
	movk	w3, #13880, lsl #16
	mov	w4, #3329                       ; =0xd01
	movk	w4, #14672, lsl #16
	mov	w5, #34953                      ; =0x8889
	movk	w5, #15368, lsl #16
	mov	w6, #43691                      ; =0xaaab
	movk	w6, #15914, lsl #16
	mov	w7, #30407                      ; =0x76c7
	movk	w7, #12559, lsl #16
	mov	w19, #62078                     ; =0xf27e
	movk	w19, #13459, lsl #16
	mov	w20, #3329                      ; =0xd01
	movk	w20, #14288, lsl #16
	mov	w21, #2913                      ; =0xb61
	movk	w21, #15030, lsl #16
	mov	w22, #43691                     ; =0xaaab
	movk	w22, #15658, lsl #16
	mov	w23, #-1026555904               ; =0xc2d00000
	mov	w24, #1120403456                ; =0x42c80000
	mov	w25, #43579                     ; =0xaa3b
	movk	w25, #16312, lsl #16
	movi.4s	v8, #75, lsl #24
	movi.4s	v10, #203, lsl #24
	mov	w26, #29184                     ; =0x7200
	movk	w26, #48945, lsl #16
	mov	w27, #48782                     ; =0xbe8e
	movk	w27, #46527, lsl #16
	mov	w28, #11226                     ; =0x2bda
	movk	w28, #14672, lsl #16
	mov	w30, #38601                     ; =0x96c9
	movk	w30, #15030, lsl #16
	mov	w10, #34982                     ; =0x88a6
	movk	w10, #15368, lsl #16
	mov	w8, #43642                      ; =0xaa7a
	movk	w8, #15658, lsl #16
	mvni.4s	v0, #127, msl #16
	fneg.4s	v0, v0
	str	q0, [sp, #352]                  ; 16-byte Spill
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	stp	q0, q21, [sp, #256]             ; 32-byte Folded Spill
	fmov.4s	v13, #1.00000000
	b	LBB0_5
LBB0_4:                                 ; %else71
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x11, x11, #32
	cmp	x11, #4, lsl #12                ; =16384
	b.eq	LBB0_134
LBB0_5:                                 ; %direct.true20
                                        ; =>This Inner Loop Header: Depth=1
	add	x9, x15, x11
	movi.2d	v31, #0000000000000000
	movi.2d	v30, #0000000000000000
	tbnz	w16, #0, LBB0_31
; %bb.6:                                ; %else
                                        ;   in Loop: Header=BB0_5 Depth=1
	and	w12, w16, #0xff
	tbnz	w12, #1, LBB0_32
LBB0_7:                                 ; %else11
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w12, #2, LBB0_33
LBB0_8:                                 ; %else14
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w12, #3, LBB0_34
LBB0_9:                                 ; %else17
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w12, #4, LBB0_35
LBB0_10:                                ; %else20
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w12, #5, LBB0_36
LBB0_11:                                ; %else23
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w12, #6, LBB0_37
LBB0_12:                                ; %else26
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w12, #7, LBB0_38
LBB0_13:                                ; %else29
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	w12, s21
	add	x9, x14, x11
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	tbnz	w12, #0, LBB0_39
LBB0_14:                                ; %else33
                                        ;   in Loop: Header=BB0_5 Depth=1
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_40
LBB0_15:                                ; %else36
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w12, #2, LBB0_41
LBB0_16:                                ; %else39
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w12, #3, LBB0_42
LBB0_17:                                ; %else42
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w12, #4, LBB0_43
LBB0_18:                                ; %else45
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w12, #5, LBB0_44
LBB0_19:                                ; %else48
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w12, #6, LBB0_45
LBB0_20:                                ; %else51
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w12, #7, LBB0_22
LBB0_21:                                ; %cond.load53
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x9, x9, #28
	ld1.s	{ v1 }[3], [x9]
LBB0_22:                                ; %else54
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	q1, [sp, #336]                  ; 16-byte Spill
	mov	w9, #10003                      ; =0x2713
	movk	w9, #15671, lsl #16
	dup.4s	v1, w9
	str	q1, [sp, #320]                  ; 16-byte Spill
	fmul.4s	v1, v31, v1
	fmul.4s	v1, v31, v1
	fmul.4s	v1, v31, v1
	fadd.4s	v1, v31, v1
	dup.4s	v2, w0
	str	q2, [sp, #304]                  ; 16-byte Spill
	fmul.4s	v1, v1, v2
	and.16b	v28, v29, v1
	fabs.4s	v20, v28
	fmul.4s	v4, v28, v28
	dup.4s	v2, w1
	dup.4s	v11, w2
	mov.16b	v1, v11
	str	q2, [sp, #288]                  ; 16-byte Spill
	fmla.4s	v1, v4, v2
	dup.4s	v14, w3
	mov.16b	v2, v14
	fmla.4s	v2, v4, v1
	dup.4s	v15, w4
	mov.16b	v1, v15
	fmla.4s	v1, v4, v2
	dup.4s	v5, w5
	mov.16b	v2, v5
	fmla.4s	v2, v4, v1
	dup.4s	v1, w6
	mov.16b	v3, v1
	fmla.4s	v3, v4, v2
	fmov.4s	v2, #1.00000000
	fmla.4s	v2, v4, v3
	dup.4s	v6, w7
	fmul.4s	v17, v20, v2
	dup.4s	v7, w19
	mov.16b	v2, v7
	dup.4s	v16, w20
	fmla.4s	v2, v4, v6
	mov.16b	v3, v16
	fmla.4s	v3, v4, v2
	dup.4s	v2, w21
	mov.16b	v18, v2
	fmla.4s	v18, v4, v3
	dup.4s	v3, w22
	mov.16b	v22, v3
	fmla.4s	v22, v4, v18
	movi.4s	v18, #63, lsl #24
	fmla.4s	v18, v4, v22
	fmov.4s	v22, #1.00000000
	fmla.4s	v22, v4, v18
	fdiv.4s	v19, v17, v22
	fmov.4s	v4, #9.00000000
	fcmge.4s	v26, v4, v20
	and.16b	v29, v26, v20
	dup.4s	v4, w23
	fcmge.4s	v17, v29, v4
	dup.4s	v9, w24
	fcmge.4s	v18, v9, v29
	and.16b	v17, v17, v18
	and.16b	v22, v17, v29
	dup.4s	v18, w25
	fmul.4s	v17, v22, v18
	fadd.4s	v17, v17, v8
	fadd.4s	v17, v17, v10
	fcvtzs.4s	v21, v17
	scvtf.4s	v23, v21
	dup.4s	v17, w26
	fmul.4s	v24, v23, v17
	fadd.4s	v24, v22, v24
	dup.4s	v22, w27
	fmul.4s	v25, v23, v22
	dup.4s	v23, w28
	fadd.4s	v8, v24, v25
	fmul.4s	v25, v8, v23
	dup.4s	v24, w30
	fadd.4s	v25, v25, v24
	fmul.4s	v27, v8, v25
	dup.4s	v25, w10
	fadd.4s	v27, v27, v25
	fmul.4s	v10, v8, v27
	dup.4s	v27, w8
	fadd.4s	v10, v10, v27
	fmul.4s	v10, v8, v10
	fadd.4s	v10, v10, v1
	fmul.4s	v10, v8, v10
	fadd.4s	v10, v10, v12
	fmul.4s	v12, v8, v8
	fmul.4s	v10, v12, v10
	fadd.4s	v8, v8, v10
	fadd.4s	v8, v8, v13
	movi.2d	v10, #0xffffffffffffffff
	add.4s	v21, v21, v10
	sshr.4s	v10, v21, #1
	shl.4s	v12, v10, #23
	add.4s	v12, v12, v13
	fmul.4s	v8, v8, v12
	movi.4s	v12, #63, lsl #24
	sub.4s	v21, v21, v10
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v13
	fmul.4s	v21, v8, v21
	fcmgt.4s	v29, v29, v9
	ldr	q8, [sp, #352]                  ; 16-byte Reload
	bit.16b	v21, v8, v29
	fmov.4s	v29, #0.25000000
	fdiv.4s	v29, v29, v21
	fsub.4s	v8, v21, v29
	fadd.4s	v21, v21, v29
	fdiv.4s	v21, v8, v21
	bif.16b	v21, v13, v26
	fcmge.4s	v20, v13, v20
	bif.16b	v19, v21, v20
	mvni.4s	v29, #128, lsl #24
	bif.16b	v19, v28, v29
	fcmeq.4s	v20, v28, v28
	fadd.4s	v19, v19, v13
	ldp	q28, q21, [sp, #256]            ; 32-byte Folded Reload
	bif.16b	v19, v28, v20
	fmul.4s	v20, v31, v12
	fmul.4s	v19, v20, v19
	fadd.4s	v0, v0, v19
	fmov	w12, s21
	add	x9, x13, x11
	tbnz	w12, #0, LBB0_46
; %bb.23:                               ; %else57
                                        ;   in Loop: Header=BB0_5 Depth=1
	and	w12, w12, #0xff
	ldr	q19, [sp, #384]                 ; 16-byte Reload
	tbnz	w12, #1, LBB0_47
LBB0_24:                                ; %else59
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov.4s	v26, #9.00000000
	movi.4s	v8, #75, lsl #24
	movi.4s	v10, #203, lsl #24
	tbnz	w12, #2, LBB0_48
LBB0_25:                                ; %else61
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w12, #3, LBB0_27
LBB0_26:                                ; %cond.store62
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x9, #12
	st1.s	{ v0 }[3], [x17]
LBB0_27:                                ; %else63
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldp	q20, q0, [sp, #304]             ; 32-byte Folded Reload
	fmul.4s	v0, v30, v0
	fmul.4s	v0, v30, v0
	fmul.4s	v0, v30, v0
	fadd.4s	v0, v30, v0
	fmul.4s	v0, v0, v20
	and.16b	v0, v19, v0
	fmul.4s	v19, v0, v0
	ldr	q20, [sp, #288]                 ; 16-byte Reload
	fmla.4s	v11, v19, v20
	fmla.4s	v14, v19, v11
	fmla.4s	v15, v19, v14
	fmla.4s	v5, v19, v15
	mov.16b	v20, v1
	fmla.4s	v20, v19, v5
	fmov.4s	v5, #1.00000000
	fmla.4s	v5, v19, v20
	fmla.4s	v7, v19, v6
	fmla.4s	v16, v19, v7
	fmla.4s	v2, v19, v16
	fabs.4s	v6, v0
	fmul.4s	v5, v6, v5
	fmla.4s	v3, v19, v2
	movi.4s	v2, #63, lsl #24
	fmla.4s	v2, v19, v3
	fmov.4s	v3, #1.00000000
	fmla.4s	v3, v19, v2
	fdiv.4s	v2, v5, v3
	fcmge.4s	v3, v26, v6
	and.16b	v5, v3, v6
	fcmge.4s	v4, v5, v4
	fcmge.4s	v7, v9, v5
	and.16b	v4, v4, v7
	and.16b	v4, v4, v5
	fmul.4s	v7, v4, v18
	fadd.4s	v7, v7, v8
	fadd.4s	v7, v7, v10
	fcvtzs.4s	v7, v7
	scvtf.4s	v16, v7
	fmul.4s	v17, v16, v17
	fadd.4s	v4, v4, v17
	fmul.4s	v16, v16, v22
	fadd.4s	v4, v4, v16
	fmul.4s	v16, v4, v23
	fadd.4s	v16, v16, v24
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v25
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v27
	fmul.4s	v16, v4, v16
	fadd.4s	v1, v16, v1
	fmul.4s	v1, v4, v1
	fadd.4s	v1, v1, v12
	fmul.4s	v16, v4, v4
	fmul.4s	v1, v16, v1
	fadd.4s	v1, v4, v1
	fmov.4s	v17, #1.00000000
	fadd.4s	v1, v1, v17
	movi.2d	v4, #0xffffffffffffffff
	add.4s	v4, v7, v4
	sshr.4s	v7, v4, #1
	shl.4s	v16, v7, #23
	add.4s	v16, v16, v17
	fmul.4s	v1, v1, v16
	sub.4s	v4, v4, v7
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v17
	fmul.4s	v1, v1, v4
	fcmgt.4s	v4, v5, v9
	ldr	q5, [sp, #352]                  ; 16-byte Reload
	bit.16b	v1, v5, v4
	fmov.4s	v4, #0.25000000
	fdiv.4s	v4, v4, v1
	fsub.4s	v5, v1, v4
	fadd.4s	v1, v1, v4
	fdiv.4s	v1, v5, v1
	bif.16b	v1, v17, v3
	fcmge.4s	v3, v17, v6
	bit.16b	v1, v2, v3
	bif.16b	v1, v0, v29
	fcmeq.4s	v0, v0, v0
	fadd.4s	v1, v1, v17
	bsl.16b	v0, v1, v28
	fmul.4s	v1, v30, v12
	fmul.4s	v0, v1, v0
	ldr	q1, [sp, #336]                  ; 16-byte Reload
	fadd.4s	v0, v1, v0
	tbnz	w12, #4, LBB0_49
; %bb.28:                               ; %else65
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q29, [sp, #368]                 ; 16-byte Reload
	tbnz	w12, #5, LBB0_50
LBB0_29:                                ; %else67
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w12, #6, LBB0_51
LBB0_30:                                ; %else69
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w12, #7, LBB0_4
	b	LBB0_52
LBB0_31:                                ; %cond.load
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	s31, [x9]
	and	w12, w16, #0xff
	tbz	w12, #1, LBB0_7
LBB0_32:                                ; %cond.load10
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x9, #4
	ld1.s	{ v31 }[1], [x17]
	tbz	w12, #2, LBB0_8
LBB0_33:                                ; %cond.load13
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x9, #8
	ld1.s	{ v31 }[2], [x17]
	tbz	w12, #3, LBB0_9
LBB0_34:                                ; %cond.load16
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x9, #12
	ld1.s	{ v31 }[3], [x17]
	tbz	w12, #4, LBB0_10
LBB0_35:                                ; %cond.load19
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x9, #16
	ld1.s	{ v30 }[0], [x17]
	tbz	w12, #5, LBB0_11
LBB0_36:                                ; %cond.load22
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x9, #20
	ld1.s	{ v30 }[1], [x17]
	tbz	w12, #6, LBB0_12
LBB0_37:                                ; %cond.load25
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x9, #24
	ld1.s	{ v30 }[2], [x17]
	tbz	w12, #7, LBB0_13
LBB0_38:                                ; %cond.load28
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x9, x9, #28
	ld1.s	{ v30 }[3], [x9]
	fmov	w12, s21
	add	x9, x14, x11
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	tbz	w12, #0, LBB0_14
LBB0_39:                                ; %cond.load32
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	s0, [x9]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_15
LBB0_40:                                ; %cond.load35
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x9, #4
	ld1.s	{ v0 }[1], [x17]
	tbz	w12, #2, LBB0_16
LBB0_41:                                ; %cond.load38
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x9, #8
	ld1.s	{ v0 }[2], [x17]
	tbz	w12, #3, LBB0_17
LBB0_42:                                ; %cond.load41
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x9, #12
	ld1.s	{ v0 }[3], [x17]
	tbz	w12, #4, LBB0_18
LBB0_43:                                ; %cond.load44
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x9, #16
	ld1.s	{ v1 }[0], [x17]
	tbz	w12, #5, LBB0_19
LBB0_44:                                ; %cond.load47
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x9, #20
	ld1.s	{ v1 }[1], [x17]
	tbz	w12, #6, LBB0_20
LBB0_45:                                ; %cond.load50
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x9, #24
	ld1.s	{ v1 }[2], [x17]
	tbnz	w12, #7, LBB0_21
	b	LBB0_22
LBB0_46:                                ; %cond.store
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	s0, [x9]
	and	w12, w12, #0xff
	ldr	q19, [sp, #384]                 ; 16-byte Reload
	tbz	w12, #1, LBB0_24
LBB0_47:                                ; %cond.store58
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x9, #4
	st1.s	{ v0 }[1], [x17]
	fmov.4s	v26, #9.00000000
	movi.4s	v8, #75, lsl #24
	movi.4s	v10, #203, lsl #24
	tbz	w12, #2, LBB0_25
LBB0_48:                                ; %cond.store60
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x9, #8
	st1.s	{ v0 }[2], [x17]
	tbnz	w12, #3, LBB0_26
	b	LBB0_27
LBB0_49:                                ; %cond.store64
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	s0, [x9, #16]
	ldr	q29, [sp, #368]                 ; 16-byte Reload
	tbz	w12, #5, LBB0_29
LBB0_50:                                ; %cond.store66
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x9, #20
	st1.s	{ v0 }[1], [x17]
	tbz	w12, #6, LBB0_30
LBB0_51:                                ; %cond.store68
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x17, x9, #24
	st1.s	{ v0 }[2], [x17]
	tbz	w12, #7, LBB0_4
LBB0_52:                                ; %cond.store70
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x9, x9, #28
	st1.s	{ v0 }[3], [x9]
	b	LBB0_4
LBB0_53:                                ; %direct.schedule.8.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x16, x9
	ldr	q2, [x10, lCPI0_6@PAGEOFF]
	ldr	q3, [sp, #240]                  ; 16-byte Reload
	and.16b	v2, v3, v2
	addv.8h	h20, v2
	fmov	w10, s20
	add	x11, sp, #4, lsl #12            ; =16384
	add	x11, x11, #800
	b	LBB0_55
LBB0_54:                                ; %else162
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x12, x11, x8
	stp	q2, q3, [x12]
	add	x8, x8, #32
	cmp	x8, #4, lsl #12                 ; =16384
	b.eq	LBB0_71
LBB0_55:                                ; %direct.true40
                                        ; =>This Inner Loop Header: Depth=1
	add	x12, x9, x8
	add	x14, x11, x8
	ldr	q2, [x14]
	tbnz	w10, #0, LBB0_63
; %bb.56:                               ; %else141
                                        ;   in Loop: Header=BB0_55 Depth=1
	and	w13, w10, #0xff
	tbnz	w13, #1, LBB0_64
LBB0_57:                                ; %else144
                                        ;   in Loop: Header=BB0_55 Depth=1
	tbnz	w13, #2, LBB0_65
LBB0_58:                                ; %else147
                                        ;   in Loop: Header=BB0_55 Depth=1
	tbnz	w13, #3, LBB0_66
LBB0_59:                                ; %else150
                                        ;   in Loop: Header=BB0_55 Depth=1
	ldr	q3, [x14, #16]
	tbnz	w13, #4, LBB0_67
LBB0_60:                                ; %else153
                                        ;   in Loop: Header=BB0_55 Depth=1
	tbnz	w13, #5, LBB0_68
LBB0_61:                                ; %else156
                                        ;   in Loop: Header=BB0_55 Depth=1
	tbnz	w13, #6, LBB0_69
LBB0_62:                                ; %else159
                                        ;   in Loop: Header=BB0_55 Depth=1
	tbz	w13, #7, LBB0_54
	b	LBB0_70
LBB0_63:                                ; %cond.load140
                                        ;   in Loop: Header=BB0_55 Depth=1
	ld1.s	{ v2 }[0], [x12]
	and	w13, w10, #0xff
	tbz	w13, #1, LBB0_57
LBB0_64:                                ; %cond.load143
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x15, x12, #4
	ld1.s	{ v2 }[1], [x15]
	tbz	w13, #2, LBB0_58
LBB0_65:                                ; %cond.load146
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x15, x12, #8
	ld1.s	{ v2 }[2], [x15]
	tbz	w13, #3, LBB0_59
LBB0_66:                                ; %cond.load149
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x15, x12, #12
	ld1.s	{ v2 }[3], [x15]
	ldr	q3, [x14, #16]
	tbz	w13, #4, LBB0_60
LBB0_67:                                ; %cond.load152
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x14, x12, #16
	ld1.s	{ v3 }[0], [x14]
	tbz	w13, #5, LBB0_61
LBB0_68:                                ; %cond.load155
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x14, x12, #20
	ld1.s	{ v3 }[1], [x14]
	tbz	w13, #6, LBB0_62
LBB0_69:                                ; %cond.load158
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x14, x12, #24
	ld1.s	{ v3 }[2], [x14]
	tbz	w13, #7, LBB0_54
LBB0_70:                                ; %cond.load161
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x12, x12, #28
	ld1.s	{ v3 }[3], [x12]
	b	LBB0_54
LBB0_71:                                ; %direct.false41
	ldr	q2, [sp, #240]                  ; 16-byte Reload
	xtn.8b	v2, v2
	sshll.2d	v3, v7, #0
	sshll.2d	v4, v29, #0
	movi.8b	v5, #1
	and.8b	v5, v2, v5
	umov.b	w13, v5[0]
	movi.2d	v18, #0000000000000000
	mov.b	v18[0], v2[0]
	movi.2d	v5, #0000000000000000
	umaxv.8b	b6, v18
	fmov	w12, s6
	rbit	w8, w13
	clz	w8, w8
	tst	w12, #0x1
	csel	w11, w8, wzr, ne
	mov	w8, #4096                       ; =0x1000
	dup.2d	v19, x8
	fmov	x8, d16
	add	x8, x8, x8, lsl #12
	fmov	d17, x8
	mov.d	x8, v16[1]
	add	x8, x8, x8, lsl #12
	mov.d	v17[1], x8
	ldr	q6, [sp, #128]                  ; 16-byte Reload
	add.2d	v6, v17, v6
	add.2d	v16, v6, v19
	movi.2d	v6, #0000000000000000
	mov.b	v6[0], v2[0]
	ushll.2d	v2, v6, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v2, v2, #0
	str	q16, [sp, #128]                 ; 16-byte Spill
	and.16b	v2, v2, v16
	stp	q5, q5, [sp, #656]
	stp	q2, q5, [sp, #624]
	ubfiz	x8, x11, #3, #3
	add	x9, sp, #624
	ldr	x9, [x9, x8]
	sub	x9, x9, x11
	lsl	x10, x9, #2
	add	x9, x16, x10
	mov	w14, #16384                     ; =0x4000
	dup.2d	v2, x14
Lloh12:
	adrp	x14, lCPI0_7@PAGE
Lloh13:
	ldr	q5, [x14, lCPI0_7@PAGEOFF]
	bsl.16b	v4, v5, v2
Lloh14:
	adrp	x14, lCPI0_8@PAGE
Lloh15:
	ldr	q5, [x14, lCPI0_8@PAGEOFF]
	bsl.16b	v3, v5, v2
Lloh16:
	adrp	x14, lCPI0_9@PAGE
Lloh17:
	ldr	q5, [x14, lCPI0_9@PAGEOFF]
	bsl.16b	v1, v5, v2
Lloh18:
	adrp	x14, lCPI0_10@PAGE
Lloh19:
	ldr	q5, [x14, lCPI0_10@PAGEOFF]
	bsl.16b	v0, v5, v2
	stp	q3, q0, [sp, #720]
	stp	q4, q1, [sp, #688]
	add	x14, sp, #688
	ldr	x8, [x14, x8]
	sub	x8, x8, w11, uxtw #2
	tst	w13, #0x1
	csel	x8, xzr, x8, eq
	add	x14, sp, #4, lsl #12            ; =16384
	add	x14, x14, #800
	add	x14, x14, x8
	ldr	q6, [x14]
	tbnz	w12, #0, LBB0_167
; %bb.72:                               ; %else166
	ldp	q3, q2, [sp, #192]              ; 32-byte Folded Reload
	tbnz	w13, #1, LBB0_168
LBB0_73:                                ; %else169
	tbnz	w13, #2, LBB0_169
LBB0_74:                                ; %else172
	tbnz	w13, #3, LBB0_170
LBB0_75:                                ; %else175
	ldr	q16, [x14, #16]
	tbnz	w13, #4, LBB0_171
LBB0_76:                                ; %else178
	mov	w12, #4097                      ; =0x1001
	tbnz	w13, #5, LBB0_172
LBB0_77:                                ; %else181
	dup.2s	v0, w12
	tbz	w13, #6, LBB0_79
LBB0_78:                                ; %cond.load183
	add	x12, x9, #24
	ld1.s	{ v16 }[2], [x12]
LBB0_79:                                ; %else184
	ldr	d1, [sp, #144]                  ; 8-byte Reload
	umlal.2d	v2, v1, v0
	ldr	d1, [sp, #160]                  ; 8-byte Reload
	umlal.2d	v3, v1, v0
	ldr	q1, [sp, #224]                  ; 16-byte Reload
	ldr	d4, [sp, #176]                  ; 8-byte Reload
	umlal.2d	v1, v4, v0
	mov.16b	v0, v1
	tbz	w13, #7, LBB0_81
; %bb.80:                               ; %cond.load186
	add	x9, x9, #28
	ld1.s	{ v16 }[3], [x9]
LBB0_81:                                ; %else187
	mov	x15, #0                         ; =0x0
	add.2d	v1, v2, v19
	str	q1, [sp, #144]                  ; 16-byte Spill
	add.2d	v1, v3, v19
	add.2d	v0, v0, v19
	stp	q0, q1, [sp, #96]               ; 32-byte Folded Spill
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #800
	add	x9, x9, x8
	stp	q6, q16, [x9]
	fmov	x9, d17
	lsl	x12, x9, #2
	add	x13, x2, x12
	ushll2.2d	v0, v7, #0
	mov	w9, #1                          ; =0x1
	dup.2d	v1, x9
	and.16b	v12, v0, v1
	ushll2.2d	v0, v29, #0
	and.16b	v23, v0, v1
	ushll.2d	v0, v7, #0
	and.16b	v14, v0, v1
	ushll.2d	v0, v29, #0
	and.16b	v27, v0, v1
	movi.2d	v0, #0000000000000000
	fmov	w9, s20
	add	x14, sp, #768
	movi.2d	v1, #0000000000000000
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	b	LBB0_83
LBB0_82:                                ; %else212
                                        ;   in Loop: Header=BB0_83 Depth=1
	add	x15, x14, x15
	stp	q4, q5, [x15]
	add.2d	v1, v1, v23
	add.2d	v2, v2, v14
	add.2d	v3, v3, v12
	add.2d	v0, v0, v27
	fmov	x15, d0
	cmp	x15, #512
	b.ge	LBB0_99
LBB0_83:                                ; %direct.true62
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x15, x15, #5
	add	x16, x13, x15
	add	x0, x14, x15
	ldr	q4, [x0]
	tbnz	w9, #0, LBB0_91
; %bb.84:                               ; %else191
                                        ;   in Loop: Header=BB0_83 Depth=1
	and	w17, w9, #0xff
	tbnz	w17, #1, LBB0_92
LBB0_85:                                ; %else194
                                        ;   in Loop: Header=BB0_83 Depth=1
	tbnz	w17, #2, LBB0_93
LBB0_86:                                ; %else197
                                        ;   in Loop: Header=BB0_83 Depth=1
	tbnz	w17, #3, LBB0_94
LBB0_87:                                ; %else200
                                        ;   in Loop: Header=BB0_83 Depth=1
	ldr	q5, [x0, #16]
	tbnz	w17, #4, LBB0_95
LBB0_88:                                ; %else203
                                        ;   in Loop: Header=BB0_83 Depth=1
	tbnz	w17, #5, LBB0_96
LBB0_89:                                ; %else206
                                        ;   in Loop: Header=BB0_83 Depth=1
	tbnz	w17, #6, LBB0_97
LBB0_90:                                ; %else209
                                        ;   in Loop: Header=BB0_83 Depth=1
	tbz	w17, #7, LBB0_82
	b	LBB0_98
LBB0_91:                                ; %cond.load190
                                        ;   in Loop: Header=BB0_83 Depth=1
	ld1.s	{ v4 }[0], [x16]
	and	w17, w9, #0xff
	tbz	w17, #1, LBB0_85
LBB0_92:                                ; %cond.load193
                                        ;   in Loop: Header=BB0_83 Depth=1
	add	x1, x16, #4
	ld1.s	{ v4 }[1], [x1]
	tbz	w17, #2, LBB0_86
LBB0_93:                                ; %cond.load196
                                        ;   in Loop: Header=BB0_83 Depth=1
	add	x1, x16, #8
	ld1.s	{ v4 }[2], [x1]
	tbz	w17, #3, LBB0_87
LBB0_94:                                ; %cond.load199
                                        ;   in Loop: Header=BB0_83 Depth=1
	add	x1, x16, #12
	ld1.s	{ v4 }[3], [x1]
	ldr	q5, [x0, #16]
	tbz	w17, #4, LBB0_88
LBB0_95:                                ; %cond.load202
                                        ;   in Loop: Header=BB0_83 Depth=1
	add	x0, x16, #16
	ld1.s	{ v5 }[0], [x0]
	tbz	w17, #5, LBB0_89
LBB0_96:                                ; %cond.load205
                                        ;   in Loop: Header=BB0_83 Depth=1
	add	x0, x16, #20
	ld1.s	{ v5 }[1], [x0]
	tbz	w17, #6, LBB0_90
LBB0_97:                                ; %cond.load208
                                        ;   in Loop: Header=BB0_83 Depth=1
	add	x0, x16, #24
	ld1.s	{ v5 }[2], [x0]
	tbz	w17, #7, LBB0_82
LBB0_98:                                ; %cond.load211
                                        ;   in Loop: Header=BB0_83 Depth=1
	add	x16, x16, #28
	ld1.s	{ v5 }[3], [x16]
	b	LBB0_82
LBB0_99:                                ; %direct.false63
	add	x9, x2, x10
	add	x10, sp, #768
	add	x13, x10, x8
	ldr	q2, [x13]
	ldr	d0, [x4, lCPI0_11@PAGEOFF]
	shl.8b	v1, v18, #7
	cmlt.8b	v1, v1, #0
	and.8b	v0, v1, v0
	addv.8b	b0, v0
	str	d0, [sp, #8]                    ; 8-byte Spill
	fmov	w10, s0
	tbnz	w10, #0, LBB0_173
; %bb.100:                              ; %else216
	tbnz	w10, #1, LBB0_174
LBB0_101:                               ; %else219
	tbnz	w10, #2, LBB0_175
LBB0_102:                               ; %else222
	tbnz	w10, #3, LBB0_176
LBB0_103:                               ; %else225
	ldr	q0, [x13, #16]
	tbnz	w10, #4, LBB0_177
LBB0_104:                               ; %else228
	tbnz	w10, #5, LBB0_178
LBB0_105:                               ; %else231
	tbnz	w10, #6, LBB0_179
LBB0_106:                               ; %else234
	stp	q6, q18, [sp, #64]              ; 32-byte Folded Spill
	str	q16, [sp, #32]                  ; 16-byte Spill
	tbz	w10, #7, LBB0_108
LBB0_107:                               ; %cond.load236
	add	x9, x9, #28
	ld1.s	{ v0 }[3], [x9]
LBB0_108:                               ; %else237
	mov	x16, #0                         ; =0x0
	add	x9, sp, #768
	add	x8, x9, x8
	str	q0, [sp, #16]                   ; 16-byte Spill
	stp	q2, q0, [x8]
	str	q2, [sp, #48]                   ; 16-byte Spill
	add	x8, x3, x12
	movi.2d	v25, #0000000000000000
	fmov	w10, s20
	add	x12, sp, #4, lsl #12            ; =16384
	add	x12, x12, #800
	mov	w13, #10003                     ; =0x2713
	movk	w13, #15671, lsl #16
	dup.4s	v1, w13
	mov	w13, #16938                     ; =0x422a
	movk	w13, #16204, lsl #16
	dup.4s	v15, w13
	fmov.4s	v28, #1.00000000
	mov	w13, #37425                     ; =0x9231
	movk	w13, #12080, lsl #16
	dup.4s	v0, w13
	stp	q0, q1, [sp, #336]              ; 32-byte Folded Spill
	mov	w13, #12843                     ; =0x322b
	movk	w13, #13015, lsl #16
	dup.4s	v1, w13
	mov	w13, #61213                     ; =0xef1d
	movk	w13, #13880, lsl #16
	dup.4s	v0, w13
	stp	q0, q1, [sp, #304]              ; 32-byte Folded Spill
	mov	w13, #3329                      ; =0xd01
	movk	w13, #14672, lsl #16
	dup.4s	v1, w13
	mov	w13, #34953                     ; =0x8889
	movk	w13, #15368, lsl #16
	dup.4s	v0, w13
	stp	q0, q1, [sp, #272]              ; 32-byte Folded Spill
	mov	w13, #43691                     ; =0xaaab
	movk	w13, #15914, lsl #16
	dup.4s	v10, w13
	mov	w13, #30407                     ; =0x76c7
	movk	w13, #12559, lsl #16
	dup.4s	v1, w13
	mov	w13, #62078                     ; =0xf27e
	movk	w13, #13459, lsl #16
	dup.4s	v0, w13
	stp	q0, q1, [sp, #240]              ; 32-byte Folded Spill
	mov	w13, #3329                      ; =0xd01
	movk	w13, #14288, lsl #16
	dup.4s	v1, w13
	mov	w13, #2913                      ; =0xb61
	movk	w13, #15030, lsl #16
	dup.4s	v0, w13
	stp	q0, q1, [sp, #208]              ; 32-byte Folded Spill
	mov	w13, #43691                     ; =0xaaab
	movk	w13, #15658, lsl #16
	dup.4s	v1, w13
	mov	w13, #-1026555904               ; =0xc2d00000
	dup.4s	v0, w13
	stp	q0, q1, [sp, #176]              ; 32-byte Folded Spill
	mov	w13, #1120403456                ; =0x42c80000
	dup.4s	v4, w13
	mov	w13, #43579                     ; =0xaa3b
	movk	w13, #16312, lsl #16
	dup.4s	v0, w13
	str	q0, [sp, #160]                  ; 16-byte Spill
	mov	w13, #29184                     ; =0x7200
	movk	w13, #48945, lsl #16
	dup.4s	v18, w13
	mov	w13, #48782                     ; =0xbe8e
	movk	w13, #46527, lsl #16
	dup.4s	v5, w13
	mov	w13, #11226                     ; =0x2bda
	movk	w13, #14672, lsl #16
	dup.4s	v19, w13
	mov	w13, #38601                     ; =0x96c9
	movk	w13, #15030, lsl #16
	mov	w14, #34982                     ; =0x88a6
	movk	w14, #15368, lsl #16
	mov	w15, #43642                     ; =0xaa7a
	movk	w15, #15658, lsl #16
	mvni.4s	v0, #127, msl #16
	fneg.4s	v0, v0
	mvni.4s	v1, #63, msl #16
	fneg.4s	v7, v1
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v24, #0000000000000000
	b	LBB0_110
LBB0_109:                               ; %else255
                                        ;   in Loop: Header=BB0_110 Depth=1
	add.2d	v21, v21, v23
	add.2d	v22, v22, v14
	add.2d	v24, v24, v12
	add.2d	v25, v25, v27
	fmov	x16, d25
	cmp	x16, #512
	b.ge	LBB0_126
LBB0_110:                               ; %direct.true83
                                        ; =>This Inner Loop Header: Depth=1
	mov.16b	v3, v27
	mov.16b	v20, v23
	lsl	x16, x16, #5
	add	x0, x12, x16
	ldr	q1, [x0]
	and.16b	v1, v29, v1
	ldp	q23, q2, [sp, #336]             ; 32-byte Folded Reload
	fmul.4s	v2, v1, v2
	fmul.4s	v2, v1, v2
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v1, v2
	mov.16b	v16, v15
	fmul.4s	v2, v2, v15
	and.16b	v2, v29, v2
	fabs.4s	v26, v2
	fmul.4s	v6, v2, v2
	ldr	q17, [sp, #320]                 ; 16-byte Reload
	fmla.4s	v17, v6, v23
	ldr	q23, [sp, #304]                 ; 16-byte Reload
	fmla.4s	v23, v6, v17
	ldr	q17, [sp, #288]                 ; 16-byte Reload
	fmla.4s	v17, v6, v23
	ldp	q27, q23, [sp, #256]            ; 32-byte Folded Reload
	fmla.4s	v23, v6, v17
	mov.16b	v17, v10
	fmla.4s	v17, v6, v23
	fmov.4s	v23, #1.00000000
	fmla.4s	v23, v6, v17
	fmul.4s	v17, v26, v23
	ldp	q13, q23, [sp, #224]            ; 32-byte Folded Reload
	fmla.4s	v23, v6, v27
	fmla.4s	v13, v6, v23
	ldr	q23, [sp, #208]                 ; 16-byte Reload
	fmla.4s	v23, v6, v13
	ldr	q13, [sp, #192]                 ; 16-byte Reload
	fmla.4s	v13, v6, v23
	movi.4s	v23, #63, lsl #24
	fmla.4s	v23, v6, v13
	fmov.4s	v13, #1.00000000
	fmla.4s	v13, v6, v23
	fdiv.4s	v13, v17, v13
	fmov.4s	v6, #9.00000000
	fcmge.4s	v27, v6, v26
	mov.16b	v15, v29
	and.16b	v29, v27, v26
	ldr	q6, [sp, #176]                  ; 16-byte Reload
	fcmge.4s	v6, v29, v6
	fcmge.4s	v17, v4, v29
	and.16b	v6, v6, v17
	and.16b	v6, v6, v29
	ldr	q17, [sp, #160]                 ; 16-byte Reload
	fmul.4s	v17, v6, v17
	movi.4s	v23, #75, lsl #24
	fadd.4s	v17, v17, v23
	movi.4s	v23, #203, lsl #24
	fadd.4s	v17, v17, v23
	fcvtzs.4s	v30, v17
	scvtf.4s	v17, v30
	fmul.4s	v23, v17, v18
	fadd.4s	v6, v6, v23
	fmul.4s	v17, v17, v5
	fadd.4s	v31, v6, v17
	fmul.4s	v6, v31, v19
	dup.4s	v23, w13
	fadd.4s	v6, v6, v23
	fmul.4s	v6, v31, v6
	dup.4s	v17, w14
	fadd.4s	v6, v6, v17
	fmul.4s	v8, v31, v6
	dup.4s	v6, w15
	fadd.4s	v8, v8, v6
	fmul.4s	v8, v31, v8
	fadd.4s	v8, v8, v10
	fmul.4s	v8, v31, v8
	movi.4s	v11, #63, lsl #24
	fadd.4s	v8, v8, v11
	fmul.4s	v9, v31, v31
	fmul.4s	v8, v9, v8
	fadd.4s	v31, v31, v8
	fadd.4s	v31, v31, v28
	movi.2d	v8, #0xffffffffffffffff
	add.4s	v30, v30, v8
	sshr.4s	v8, v30, #1
	shl.4s	v9, v8, #23
	add.4s	v9, v9, v28
	fmul.4s	v31, v31, v9
	sub.4s	v30, v30, v8
	shl.4s	v30, v30, #23
	add.4s	v30, v30, v28
	fmul.4s	v30, v31, v30
	fcmgt.4s	v29, v29, v4
	bsl.16b	v29, v0, v30
	fmov.4s	v30, #0.25000000
	fdiv.4s	v30, v30, v29
	fsub.4s	v31, v29, v30
	fadd.4s	v29, v29, v30
	fdiv.4s	v29, v31, v29
	bsl.16b	v27, v29, v28
	fcmge.4s	v26, v28, v26
	bsl.16b	v26, v13, v27
	mvni.4s	v27, #128, lsl #24
	bif.16b	v26, v2, v27
	fcmeq.4s	v2, v2, v2
	fadd.4s	v26, v26, v28
	bsl.16b	v2, v26, v7
	fmul.4s	v1, v1, v11
	fmul.4s	v1, v1, v2
	add	x1, x9, x16
	ldr	q2, [x1]
	and.16b	v2, v15, v2
	fadd.4s	v1, v2, v1
	add	x16, x8, x16
	tbnz	w10, #0, LBB0_119
; %bb.111:                              ; %else241
                                        ;   in Loop: Header=BB0_110 Depth=1
	and	w17, w10, #0xff
	tbnz	w17, #1, LBB0_120
LBB0_112:                               ; %else243
                                        ;   in Loop: Header=BB0_110 Depth=1
	mov.16b	v15, v16
	tbnz	w17, #2, LBB0_121
LBB0_113:                               ; %else245
                                        ;   in Loop: Header=BB0_110 Depth=1
	tbz	w17, #3, LBB0_115
LBB0_114:                               ; %cond.store246
                                        ;   in Loop: Header=BB0_110 Depth=1
	add	x2, x16, #12
	st1.s	{ v1 }[3], [x2]
LBB0_115:                               ; %else247
                                        ;   in Loop: Header=BB0_110 Depth=1
	ldr	q1, [x0, #16]
	ldr	q11, [sp, #384]                 ; 16-byte Reload
	and.16b	v1, v11, v1
	ldp	q16, q2, [sp, #336]             ; 32-byte Folded Reload
	fmul.4s	v2, v1, v2
	fmul.4s	v2, v1, v2
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v1, v2
	fmul.4s	v2, v2, v15
	and.16b	v2, v11, v2
	fabs.4s	v26, v2
	fmul.4s	v27, v2, v2
	ldp	q30, q29, [sp, #304]            ; 32-byte Folded Reload
	fmla.4s	v29, v27, v16
	fmla.4s	v30, v27, v29
	ldr	q29, [sp, #288]                 ; 16-byte Reload
	fmla.4s	v29, v27, v30
	ldp	q16, q30, [sp, #256]            ; 32-byte Folded Reload
	fmla.4s	v30, v27, v29
	mov.16b	v29, v10
	fmla.4s	v29, v27, v30
	fmov.4s	v30, #1.00000000
	fmla.4s	v30, v27, v29
	fmul.4s	v29, v26, v30
	ldp	q31, q30, [sp, #224]            ; 32-byte Folded Reload
	fmla.4s	v30, v27, v16
	fmla.4s	v31, v27, v30
	ldr	q30, [sp, #208]                 ; 16-byte Reload
	fmla.4s	v30, v27, v31
	ldr	q31, [sp, #192]                 ; 16-byte Reload
	fmla.4s	v31, v27, v30
	movi.4s	v30, #63, lsl #24
	fmla.4s	v30, v27, v31
	fmov.4s	v31, #1.00000000
	fmla.4s	v31, v27, v30
	fdiv.4s	v27, v29, v31
	fmov.4s	v16, #9.00000000
	fcmge.4s	v29, v16, v26
	and.16b	v30, v29, v26
	ldr	q16, [sp, #176]                 ; 16-byte Reload
	fcmge.4s	v31, v30, v16
	fcmge.4s	v8, v4, v30
	and.16b	v31, v31, v8
	and.16b	v31, v31, v30
	ldr	q16, [sp, #160]                 ; 16-byte Reload
	fmul.4s	v8, v31, v16
	movi.4s	v16, #75, lsl #24
	fadd.4s	v8, v8, v16
	movi.4s	v16, #203, lsl #24
	fadd.4s	v8, v8, v16
	fcvtzs.4s	v8, v8
	scvtf.4s	v9, v8
	fmul.4s	v13, v9, v18
	fadd.4s	v31, v31, v13
	fmul.4s	v9, v9, v5
	fadd.4s	v31, v31, v9
	fmul.4s	v9, v31, v19
	fadd.4s	v23, v9, v23
	fmul.4s	v23, v31, v23
	fadd.4s	v17, v23, v17
	fmul.4s	v17, v31, v17
	fadd.4s	v6, v17, v6
	fmul.4s	v6, v31, v6
	fadd.4s	v6, v6, v10
	fmul.4s	v6, v31, v6
	movi.4s	v9, #63, lsl #24
	fadd.4s	v6, v6, v9
	fmul.4s	v17, v31, v31
	fmul.4s	v6, v17, v6
	fadd.4s	v6, v31, v6
	fadd.4s	v6, v6, v28
	movi.2d	v16, #0xffffffffffffffff
	add.4s	v17, v8, v16
	sshr.4s	v23, v17, #1
	shl.4s	v31, v23, #23
	add.4s	v31, v31, v28
	fmul.4s	v6, v6, v31
	sub.4s	v17, v17, v23
	shl.4s	v17, v17, #23
	add.4s	v17, v17, v28
	fmul.4s	v6, v6, v17
	fcmgt.4s	v17, v30, v4
	bit.16b	v6, v0, v17
	fmov.4s	v16, #0.25000000
	fdiv.4s	v17, v16, v6
	fsub.4s	v23, v6, v17
	fadd.4s	v6, v6, v17
	fdiv.4s	v6, v23, v6
	bif.16b	v6, v28, v29
	fcmge.4s	v17, v28, v26
	bit.16b	v6, v27, v17
	mvni.4s	v16, #128, lsl #24
	bif.16b	v6, v2, v16
	fcmeq.4s	v2, v2, v2
	fadd.4s	v6, v6, v28
	bsl.16b	v2, v6, v7
	fmul.4s	v1, v1, v9
	fmul.4s	v1, v1, v2
	ldr	q2, [x1, #16]
	and.16b	v2, v11, v2
	fadd.4s	v1, v2, v1
	tbnz	w17, #4, LBB0_122
; %bb.116:                              ; %else249
                                        ;   in Loop: Header=BB0_110 Depth=1
	ldr	q29, [sp, #368]                 ; 16-byte Reload
	mov.16b	v23, v20
	mov.16b	v27, v3
	tbnz	w17, #5, LBB0_123
LBB0_117:                               ; %else251
                                        ;   in Loop: Header=BB0_110 Depth=1
	tbnz	w17, #6, LBB0_124
LBB0_118:                               ; %else253
                                        ;   in Loop: Header=BB0_110 Depth=1
	tbz	w17, #7, LBB0_109
	b	LBB0_125
LBB0_119:                               ; %cond.store240
                                        ;   in Loop: Header=BB0_110 Depth=1
	str	s1, [x16]
	and	w17, w10, #0xff
	tbz	w17, #1, LBB0_112
LBB0_120:                               ; %cond.store242
                                        ;   in Loop: Header=BB0_110 Depth=1
	add	x2, x16, #4
	st1.s	{ v1 }[1], [x2]
	mov.16b	v15, v16
	tbz	w17, #2, LBB0_113
LBB0_121:                               ; %cond.store244
                                        ;   in Loop: Header=BB0_110 Depth=1
	add	x2, x16, #8
	st1.s	{ v1 }[2], [x2]
	tbnz	w17, #3, LBB0_114
	b	LBB0_115
LBB0_122:                               ; %cond.store248
                                        ;   in Loop: Header=BB0_110 Depth=1
	str	s1, [x16, #16]
	ldr	q29, [sp, #368]                 ; 16-byte Reload
	mov.16b	v23, v20
	mov.16b	v27, v3
	tbz	w17, #5, LBB0_117
LBB0_123:                               ; %cond.store250
                                        ;   in Loop: Header=BB0_110 Depth=1
	add	x0, x16, #20
	st1.s	{ v1 }[1], [x0]
	tbz	w17, #6, LBB0_118
LBB0_124:                               ; %cond.store252
                                        ;   in Loop: Header=BB0_110 Depth=1
	add	x0, x16, #24
	st1.s	{ v1 }[2], [x0]
	tbz	w17, #7, LBB0_109
LBB0_125:                               ; %cond.store254
                                        ;   in Loop: Header=BB0_110 Depth=1
	add	x16, x16, #28
	st1.s	{ v1 }[3], [x16]
	b	LBB0_109
LBB0_126:                               ; %direct.false84
	ldr	d0, [sp, #8]                    ; 8-byte Reload
	fmov	w8, s0
	ldr	q1, [sp, #80]                   ; 16-byte Reload
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v2, v0, #0
	ldr	q0, [sp, #64]                   ; 16-byte Reload
	and.16b	v5, v2, v0
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	ldr	q1, [sp, #32]                   ; 16-byte Reload
	and.16b	v1, v0, v1
	mov	w9, #10003                      ; =0x2713
	movk	w9, #15671, lsl #16
	dup.4s	v3, w9
	fmul.4s	v4, v5, v3
	fmul.4s	v3, v1, v3
	fmul.4s	v3, v1, v3
	fmul.4s	v4, v5, v4
	fmul.4s	v4, v5, v4
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v1, v3
	fadd.4s	v4, v5, v4
	mov	w9, #16938                      ; =0x422a
	movk	w9, #16204, lsl #16
	dup.4s	v6, w9
	fmul.4s	v4, v4, v6
	fmul.4s	v3, v3, v6
	and.16b	v3, v0, v3
	and.16b	v4, v2, v4
	fabs.4s	v6, v4
	fabs.4s	v7, v3
	fmul.4s	v16, v3, v3
	fmul.4s	v17, v4, v4
	mov	w9, #37425                      ; =0x9231
	movk	w9, #12080, lsl #16
	dup.4s	v18, w9
	mov	w9, #12843                      ; =0x322b
	movk	w9, #13015, lsl #16
	dup.4s	v19, w9
	mov.16b	v20, v19
	fmla.4s	v20, v16, v18
	fmla.4s	v19, v17, v18
	mov	w9, #61213                      ; =0xef1d
	movk	w9, #13880, lsl #16
	dup.4s	v18, w9
	mov.16b	v21, v18
	fmla.4s	v21, v16, v20
	fmla.4s	v18, v17, v19
	mov	w9, #3329                       ; =0xd01
	movk	w9, #14672, lsl #16
	dup.4s	v19, w9
	mov.16b	v22, v19
	fmla.4s	v22, v16, v21
	fmla.4s	v19, v17, v18
	mov	w9, #34953                      ; =0x8889
	movk	w9, #15368, lsl #16
	dup.4s	v18, w9
	mov.16b	v20, v18
	fmla.4s	v20, v16, v22
	fmla.4s	v18, v17, v19
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #15914, lsl #16
	dup.4s	v23, w9
	mov.16b	v21, v23
	fmla.4s	v21, v17, v18
	fmov.4s	v19, #1.00000000
	fmla.4s	v19, v17, v21
	mov	w9, #30407                      ; =0x76c7
	movk	w9, #12559, lsl #16
	dup.4s	v25, w9
	mov	w9, #62078                      ; =0xf27e
	movk	w9, #13459, lsl #16
	dup.4s	v26, w9
	mov.16b	v18, v26
	fmla.4s	v18, v17, v25
	mov	w9, #3329                       ; =0xd01
	movk	w9, #14288, lsl #16
	dup.4s	v27, w9
	mov.16b	v21, v27
	mov	w9, #2913                       ; =0xb61
	movk	w9, #15030, lsl #16
	dup.4s	v28, w9
	fmla.4s	v21, v17, v18
	mov.16b	v18, v28
	fmla.4s	v18, v17, v21
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #15658, lsl #16
	dup.4s	v29, w9
	mov.16b	v21, v29
	fmla.4s	v21, v17, v18
	movi.4s	v18, #63, lsl #24
	fmla.4s	v18, v17, v21
	fmov.4s	v30, #1.00000000
	fmla.4s	v30, v17, v18
	fmov.4s	v18, #9.00000000
	fcmge.4s	v17, v18, v7
	fcmge.4s	v18, v18, v6
	and.16b	v21, v18, v6
	and.16b	v22, v17, v7
	mov	w9, #-1026555904                ; =0xc2d00000
	dup.4s	v31, w9
	fcmge.4s	v8, v22, v31
	mov	w9, #1120403456                 ; =0x42c80000
	dup.4s	v24, w9
	fcmge.4s	v31, v21, v31
	fcmge.4s	v9, v24, v22
	fcmge.4s	v10, v24, v21
	and.16b	v31, v31, v10
	and.16b	v8, v8, v9
	and.16b	v9, v8, v22
	and.16b	v8, v31, v21
	mov	w9, #43579                      ; =0xaa3b
	movk	w9, #16312, lsl #16
	dup.4s	v31, w9
	fmul.4s	v10, v8, v31
	fmul.4s	v31, v9, v31
	movi.4s	v11, #75, lsl #24
	fadd.4s	v31, v31, v11
	fadd.4s	v10, v10, v11
	movi.4s	v11, #203, lsl #24
	fadd.4s	v10, v10, v11
	fadd.4s	v11, v31, v11
	fcvtzs.4s	v31, v10
	mov	w9, #29184                      ; =0x7200
	movk	w9, #48945, lsl #16
	scvtf.4s	v10, v31
	dup.4s	v12, w9
	fmul.4s	v13, v10, v12
	fadd.4s	v13, v8, v13
	fcvtzs.4s	v8, v11
	scvtf.4s	v11, v8
	fmul.4s	v12, v11, v12
	fadd.4s	v9, v9, v12
	mov	w9, #48782                      ; =0xbe8e
	movk	w9, #46527, lsl #16
	dup.4s	v12, w9
	fmul.4s	v10, v10, v12
	fmul.4s	v11, v11, v12
	fadd.4s	v9, v9, v11
	fadd.4s	v10, v13, v10
	mov	w9, #11226                      ; =0x2bda
	movk	w9, #14672, lsl #16
	dup.4s	v11, w9
	fmul.4s	v12, v10, v11
	fmul.4s	v11, v9, v11
	mov	w9, #38601                      ; =0x96c9
	movk	w9, #15030, lsl #16
	dup.4s	v13, w9
	fadd.4s	v11, v11, v13
	fadd.4s	v12, v12, v13
	fmul.4s	v12, v10, v12
	fmul.4s	v11, v9, v11
	mov	w9, #34982                      ; =0x88a6
	movk	w9, #15368, lsl #16
	dup.4s	v13, w9
	fadd.4s	v11, v11, v13
	fadd.4s	v12, v12, v13
	fmul.4s	v12, v10, v12
	fmul.4s	v11, v9, v11
	mov	w9, #43642                      ; =0xaa7a
	movk	w9, #15658, lsl #16
	dup.4s	v13, w9
	fadd.4s	v11, v11, v13
	fadd.4s	v12, v12, v13
	fmul.4s	v12, v10, v12
	fmul.4s	v11, v9, v11
	fadd.4s	v11, v11, v23
	fadd.4s	v12, v12, v23
	fmla.4s	v23, v16, v20
	fmov.4s	v13, #1.00000000
	fmla.4s	v13, v16, v23
	fmla.4s	v26, v16, v25
	fmla.4s	v27, v16, v26
	fmla.4s	v28, v16, v27
	movi.4s	v20, #63, lsl #24
	fmul.4s	v23, v5, v20
	fmla.4s	v29, v16, v28
	movi.4s	v5, #63, lsl #24
	fmla.4s	v5, v16, v29
	fmov.4s	v25, #1.00000000
	fmla.4s	v25, v16, v5
	fmov.4s	v5, #1.00000000
	fcmge.4s	v16, v5, v7
	fmul.4s	v19, v6, v19
	fcmge.4s	v6, v5, v6
	fmul.4s	v7, v7, v13
	fdiv.4s	v7, v7, v25
	fdiv.4s	v19, v19, v30
	fmul.4s	v25, v10, v12
	fmul.4s	v26, v9, v11
	fadd.4s	v26, v26, v20
	fadd.4s	v25, v25, v20
	fmul.4s	v27, v9, v9
	fmul.4s	v28, v10, v10
	fmul.4s	v25, v28, v25
	fmul.4s	v26, v27, v26
	fadd.4s	v26, v9, v26
	fadd.4s	v25, v10, v25
	fadd.4s	v25, v25, v5
	fadd.4s	v26, v26, v5
	movi.2d	v27, #0xffffffffffffffff
	add.4s	v28, v8, v27
	add.4s	v27, v31, v27
	sshr.4s	v29, v27, #1
	sshr.4s	v30, v28, #1
	shl.4s	v31, v30, #23
	shl.4s	v8, v29, #23
	add.4s	v8, v8, v5
	add.4s	v31, v31, v5
	fmul.4s	v26, v26, v31
	fmul.4s	v25, v25, v8
	sub.4s	v28, v28, v30
	sub.4s	v27, v27, v29
	shl.4s	v27, v27, #23
	shl.4s	v28, v28, #23
	add.4s	v28, v28, v5
	add.4s	v27, v27, v5
	fmul.4s	v25, v25, v27
	fmul.4s	v26, v26, v28
	fcmgt.4s	v21, v21, v24
	fcmgt.4s	v22, v22, v24
	mvni.4s	v24, #127, msl #16
	fneg.4s	v24, v24
	bsl.16b	v22, v24, v26
	bsl.16b	v21, v24, v25
	fmov.4s	v24, #0.25000000
	fdiv.4s	v25, v24, v21
	fdiv.4s	v24, v24, v22
	fsub.4s	v26, v22, v24
	fsub.4s	v27, v21, v25
	fadd.4s	v22, v22, v24
	fadd.4s	v21, v21, v25
	fdiv.4s	v21, v27, v21
	fdiv.4s	v22, v26, v22
	bsl.16b	v17, v22, v5
	bsl.16b	v18, v21, v5
	bit.16b	v18, v19, v6
	mov.16b	v6, v16
	bsl.16b	v6, v7, v17
	mvni.4s	v7, #128, lsl #24
	bif.16b	v6, v3, v7
	bsl.16b	v7, v18, v4
	fcmeq.4s	v16, v4, v4
	fadd.4s	v7, v7, v5
	mvni.4s	v4, #63, msl #16
	fneg.4s	v4, v4
	bif.16b	v7, v4, v16
	fmul.4s	v7, v23, v7
	ldr	q16, [sp, #48]                  ; 16-byte Reload
	and.16b	v2, v2, v16
	fadd.4s	v2, v7, v2
	ldr	q7, [sp, #128]                  ; 16-byte Reload
	str	q7, [sp, #544]
	ldr	q7, [sp, #144]                  ; 16-byte Reload
	str	q7, [sp, #560]
	ldr	q7, [sp, #112]                  ; 16-byte Reload
	str	q7, [sp, #576]
	ldr	q7, [sp, #96]                   ; 16-byte Reload
	str	q7, [sp, #592]
	and	x9, x11, #0x7
	add	x10, sp, #544
	ldr	x9, [x10, x9, lsl #3]
	sub	x9, x9, x11
	add	x9, x3, x9, lsl #2
	tbnz	w8, #0, LBB0_180
; %bb.127:                              ; %else258
	fcmeq.4s	v3, v3, v3
	fadd.4s	v5, v6, v5
	tbnz	w8, #1, LBB0_181
LBB0_128:                               ; %else260
	fmul.4s	v1, v1, v20
	bsl.16b	v3, v5, v4
	tbnz	w8, #2, LBB0_182
LBB0_129:                               ; %else262
	fmul.4s	v1, v1, v3
	ldr	q3, [sp, #16]                   ; 16-byte Reload
	and.16b	v0, v0, v3
	tbnz	w8, #3, LBB0_183
LBB0_130:                               ; %else264
	fadd.4s	v0, v1, v0
	tbnz	w8, #4, LBB0_184
LBB0_131:                               ; %else266
	tbnz	w8, #5, LBB0_185
LBB0_132:                               ; %else268
	tbnz	w8, #6, LBB0_186
LBB0_133:                               ; %else270
	tbnz	w8, #7, LBB0_187
	b	LBB0_204
LBB0_134:                               ; %direct.false21
	ldr	q0, [sp, #240]                  ; 16-byte Reload
	xtn.8b	v0, v0
	movi.8b	v1, #1
	and.8b	v1, v0, v1
	umov.b	w8, v1[0]
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	mov.b	v20[0], v0[0]
	umaxv.8b	b1, v20
	fmov	w12, s1
	rbit	w9, w8
	clz	w9, w9
	tst	w12, #0x1
	mov	w10, #4096                      ; =0x1000
	dup.2d	v17, x10
	csel	w11, w9, wzr, ne
	ldr	q2, [sp, #64]                   ; 16-byte Reload
	fmov	x9, d2
	add	x9, x9, x9, lsl #12
	fmov	d1, x9
	mov.d	x9, v2[1]
	add	x9, x9, x9, lsl #12
	mov.d	v1[1], x9
	ldr	q2, [sp, #128]                  ; 16-byte Reload
	add.2d	v1, v1, v2
	add.2d	v2, v1, v17
	movi.2d	v1, #0000000000000000
	mov.b	v1[0], v0[0]
	ushll.2d	v0, v1, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	str	q2, [sp, #384]                  ; 16-byte Spill
	and.16b	v0, v0, v2
	stp	q19, q19, [sp, #496]
	stp	q0, q19, [sp, #464]
	and	x9, x11, #0x7
	add	x10, sp, #464
	ldr	x9, [x10, x9, lsl #3]
	sub	x9, x9, x11
	lsl	x10, x9, #2
	ldr	x9, [sp, #80]                   ; 8-byte Reload
	add	x9, x9, x10
	movi.2d	v1, #0000000000000000
	tbnz	w12, #0, LBB0_188
; %bb.135:                              ; %else74
	ldr	x13, [sp, #112]                 ; 8-byte Reload
	ldr	x14, [sp, #96]                  ; 8-byte Reload
	adrp	x15, lCPI0_11@PAGE
	tbnz	w8, #1, LBB0_189
LBB0_136:                               ; %else77
	tbnz	w8, #2, LBB0_190
LBB0_137:                               ; %else80
	tbnz	w8, #3, LBB0_191
LBB0_138:                               ; %else83
	tbnz	w8, #4, LBB0_192
LBB0_139:                               ; %else86
	tbnz	w8, #5, LBB0_193
LBB0_140:                               ; %else89
	tbnz	w8, #6, LBB0_194
LBB0_141:                               ; %else92
	tbz	w8, #7, LBB0_143
LBB0_142:                               ; %cond.load94
	add	x8, x9, #28
	ld1.s	{ v1 }[3], [x8]
LBB0_143:                               ; %else95
	mov	w8, #10003                      ; =0x2713
	movk	w8, #15671, lsl #16
	dup.4s	v0, w8
	fmul.4s	v2, v1, v0
	fmul.4s	v0, v19, v0
	fmul.4s	v0, v19, v0
	fmul.4s	v2, v1, v2
	fmul.4s	v2, v1, v2
	fmul.4s	v0, v19, v0
	fadd.4s	v0, v19, v0
	fadd.4s	v2, v1, v2
	mov	w8, #16938                      ; =0x422a
	movk	w8, #16204, lsl #16
	dup.4s	v3, w8
	fmul.4s	v2, v2, v3
	fmul.4s	v0, v0, v3
	zip1.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	and.16b	v23, v3, v0
	zip2.8b	v0, v20, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	and.16b	v18, v0, v2
	ldr	d0, [x15, lCPI0_11@PAGEOFF]
	shl.8b	v2, v20, #7
	cmlt.8b	v2, v2, #0
	and.8b	v0, v2, v0
	addv.8b	b0, v0
	str	d0, [sp, #368]                  ; 8-byte Spill
	fmov	w8, s0
	fabs.4s	v22, v18
	fabs.4s	v28, v23
	fmov.4s	v20, #1.00000000
	fmul.4s	v8, v23, v23
	fmul.4s	v24, v18, v18
	mov	w9, #37425                      ; =0x9231
	movk	w9, #12080, lsl #16
	dup.4s	v0, w9
	mov	w9, #12843                      ; =0x322b
	movk	w9, #13015, lsl #16
	dup.4s	v2, w9
	mov.16b	v3, v2
	fmla.4s	v3, v8, v0
	fmla.4s	v2, v24, v0
	mov	w9, #61213                      ; =0xef1d
	movk	w9, #13880, lsl #16
	dup.4s	v11, w9
	mov.16b	v0, v11
	fmla.4s	v0, v8, v3
	fmla.4s	v11, v24, v2
	mov	w9, #3329                       ; =0xd01
	movk	w9, #14672, lsl #16
	dup.4s	v31, w9
	mov.16b	v2, v31
	fmla.4s	v2, v8, v0
	mov	w9, #34953                      ; =0x8889
	movk	w9, #15368, lsl #16
	dup.4s	v29, w9
	mov.16b	v0, v29
	fmla.4s	v0, v8, v2
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #15914, lsl #16
	dup.4s	v26, w9
	mov.16b	v2, v26
	fmla.4s	v2, v8, v0
	fmov.4s	v13, #1.00000000
	mov	w9, #30407                      ; =0x76c7
	movk	w9, #12559, lsl #16
	dup.4s	v0, w9
	mov	w9, #62078                      ; =0xf27e
	movk	w9, #13459, lsl #16
	dup.4s	v3, w9
	fmla.4s	v13, v8, v2
	mov.16b	v15, v3
	fmla.4s	v15, v24, v0
	mov	w9, #3329                       ; =0xd01
	movk	w9, #14288, lsl #16
	dup.4s	v12, w9
	fmla.4s	v3, v8, v0
	mov.16b	v0, v12
	fmla.4s	v0, v8, v3
	mov	w9, #2913                       ; =0xb61
	movk	w9, #15030, lsl #16
	dup.4s	v9, w9
	mov.16b	v2, v9
	fmla.4s	v2, v8, v0
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #15658, lsl #16
	dup.4s	v30, w9
	mov.16b	v0, v30
	fmla.4s	v0, v8, v2
	movi.4s	v5, #63, lsl #24
	fmla.4s	v5, v8, v0
	fmov.4s	v0, #9.00000000
	fcmge.4s	v14, v0, v28
	fcmge.4s	v25, v0, v22
	and.16b	v2, v25, v22
	and.16b	v4, v14, v28
	mov	w9, #-1026555904                ; =0xc2d00000
	dup.4s	v0, w9
	fcmge.4s	v6, v4, v0
	fcmge.4s	v0, v2, v0
	mov	w9, #1120403456                 ; =0x42c80000
	dup.4s	v3, w9
	fcmge.4s	v7, v3, v4
	fcmge.4s	v16, v3, v2
	and.16b	v0, v0, v16
	and.16b	v6, v6, v7
	and.16b	v6, v6, v4
	mov	w9, #43579                      ; =0xaa3b
	movk	w9, #16312, lsl #16
	dup.4s	v7, w9
	and.16b	v0, v0, v2
	fmul.4s	v16, v0, v7
	fmul.4s	v7, v6, v7
	movi.4s	v21, #75, lsl #24
	fadd.4s	v7, v7, v21
	fadd.4s	v16, v16, v21
	movi.4s	v21, #203, lsl #24
	fadd.4s	v16, v16, v21
	fadd.4s	v7, v7, v21
	fcvtzs.4s	v7, v7
	fcvtzs.4s	v16, v16
	scvtf.4s	v21, v16
	mov	w9, #29184                      ; =0x7200
	movk	w9, #48945, lsl #16
	dup.4s	v27, w9
	fmul.4s	v10, v21, v27
	fadd.4s	v0, v0, v10
	scvtf.4s	v10, v7
	fmul.4s	v27, v10, v27
	fadd.4s	v6, v6, v27
	mov	w9, #48782                      ; =0xbe8e
	movk	w9, #46527, lsl #16
	dup.4s	v27, w9
	fmul.4s	v21, v21, v27
	fmul.4s	v27, v10, v27
	fadd.4s	v6, v6, v27
	fadd.4s	v0, v0, v21
	mov	w9, #11226                      ; =0x2bda
	movk	w9, #14672, lsl #16
	dup.4s	v21, w9
	fmul.4s	v27, v0, v21
	fmul.4s	v21, v6, v21
	mov	w9, #38601                      ; =0x96c9
	movk	w9, #15030, lsl #16
	dup.4s	v10, w9
	fadd.4s	v21, v21, v10
	fadd.4s	v27, v27, v10
	fmul.4s	v27, v0, v27
	fmul.4s	v21, v6, v21
	mov	w9, #34982                      ; =0x88a6
	movk	w9, #15368, lsl #16
	dup.4s	v10, w9
	fadd.4s	v21, v21, v10
	fadd.4s	v27, v27, v10
	fmul.4s	v27, v0, v27
	mov	w9, #43642                      ; =0xaa7a
	movk	w9, #15658, lsl #16
	dup.4s	v10, w9
	fmul.4s	v21, v6, v21
	fadd.4s	v21, v21, v10
	fadd.4s	v27, v27, v10
	fmul.4s	v27, v0, v27
	fmul.4s	v21, v6, v21
	fadd.4s	v21, v21, v26
	fadd.4s	v27, v27, v26
	fmul.4s	v27, v0, v27
	fmul.4s	v21, v6, v21
	movi.4s	v10, #63, lsl #24
	fadd.4s	v21, v21, v10
	fadd.4s	v27, v27, v10
	fmul.4s	v10, v0, v0
	fmul.4s	v27, v10, v27
	fmul.4s	v10, v6, v6
	fmul.4s	v21, v10, v21
	fadd.4s	v6, v6, v21
	fadd.4s	v0, v0, v27
	fadd.4s	v0, v0, v20
	fadd.4s	v6, v6, v20
	movi.2d	v21, #0xffffffffffffffff
	add.4s	v27, v7, v21
	add.4s	v16, v16, v21
	sshr.4s	v21, v16, #1
	sshr.4s	v10, v27, #1
	shl.4s	v7, v10, #23
	add.4s	v7, v7, v20
	fmul.4s	v6, v6, v7
	shl.4s	v7, v21, #23
	add.4s	v7, v7, v20
	fmul.4s	v7, v0, v7
	sub.4s	v0, v27, v10
	sub.4s	v16, v16, v21
	shl.4s	v16, v16, #23
	shl.4s	v0, v0, #23
	add.4s	v21, v0, v20
	add.4s	v0, v16, v20
	fmul.4s	v16, v6, v21
	fcmgt.4s	v4, v4, v3
	mvni.4s	v6, #127, msl #16
	fneg.4s	v6, v6
	mov.16b	v21, v4
	bsl.16b	v21, v6, v16
	fmov.4s	v4, #0.25000000
	fdiv.4s	v27, v4, v21
	fsub.4s	v16, v21, v27
	fadd.4s	v21, v21, v27
	add	x9, x14, x10
	movi.2d	v10, #0000000000000000
	movi.2d	v27, #0000000000000000
	tbz	w8, #0, LBB0_145
; %bb.144:                              ; %cond.load98
	ldr	s10, [x9]
LBB0_145:                               ; %else99
	fmla.4s	v31, v24, v11
	fmla.4s	v12, v24, v15
	fmul.4s	v7, v7, v0
	fcmgt.4s	v3, v2, v3
	fmul.4s	v0, v28, v13
	fmov.4s	v2, #1.00000000
	fmla.4s	v2, v8, v5
	fdiv.4s	v16, v16, v21
	tbz	w8, #1, LBB0_147
; %bb.146:                              ; %cond.load101
	add	x10, x9, #4
	ld1.s	{ v10 }[1], [x10]
LBB0_147:                               ; %else102
	fmla.4s	v29, v24, v31
	fmla.4s	v9, v24, v12
	bsl.16b	v3, v6, v7
	fcmge.4s	v5, v20, v28
	fdiv.4s	v0, v0, v2
	mov.16b	v2, v14
	bsl.16b	v2, v16, v20
	tbz	w8, #2, LBB0_149
; %bb.148:                              ; %cond.load104
	add	x10, x9, #8
	ld1.s	{ v10 }[2], [x10]
LBB0_149:                               ; %else105
	fmla.4s	v26, v24, v29
	fmla.4s	v30, v24, v9
	fdiv.4s	v6, v4, v3
	bsl.16b	v5, v0, v2
	mvni.4s	v2, #128, lsl #24
	tbz	w8, #3, LBB0_151
; %bb.150:                              ; %cond.load107
	add	x10, x9, #12
	ld1.s	{ v10 }[3], [x10]
LBB0_151:                               ; %else108
	fmov.4s	v0, #1.00000000
	fmla.4s	v0, v24, v26
	movi.4s	v4, #63, lsl #24
	fmla.4s	v4, v24, v30
	fsub.4s	v21, v3, v6
	fadd.4s	v26, v3, v6
	mov	w10, #4097                      ; =0x1001
	mov.16b	v3, v2
	bsl.16b	v3, v5, v23
	mvni.4s	v6, #63, msl #16
	tbz	w8, #4, LBB0_153
; %bb.152:                              ; %cond.load110
	add	x12, x9, #16
	ld1.s	{ v27 }[0], [x12]
LBB0_153:                               ; %else111
	fmul.4s	v7, v22, v0
	fmov.4s	v16, #1.00000000
	fmla.4s	v16, v24, v4
	fdiv.4s	v21, v21, v26
	dup.2s	v4, w10
	fcmeq.4s	v0, v23, v23
	fadd.4s	v5, v3, v20
	fneg.4s	v3, v6
	tbz	w8, #5, LBB0_155
; %bb.154:                              ; %cond.load113
	add	x10, x9, #20
	ld1.s	{ v27 }[1], [x10]
LBB0_155:                               ; %else114
	fcmge.4s	v6, v20, v22
	fdiv.4s	v7, v7, v16
	mov.16b	v16, v25
	bsl.16b	v16, v21, v20
	ldr	q21, [sp, #208]                 ; 16-byte Reload
	ldr	d22, [sp, #144]                 ; 8-byte Reload
	umlal.2d	v21, v22, v4
	str	q21, [sp, #208]                 ; 16-byte Spill
	ldr	q21, [sp, #192]                 ; 16-byte Reload
	ldr	d22, [sp, #160]                 ; 8-byte Reload
	umlal.2d	v21, v22, v4
	str	q21, [sp, #192]                 ; 16-byte Spill
	ldr	q21, [sp, #224]                 ; 16-byte Reload
	ldr	d22, [sp, #176]                 ; 8-byte Reload
	umlal.2d	v21, v22, v4
	str	q21, [sp, #224]                 ; 16-byte Spill
	movi.4s	v22, #63, lsl #24
	fmul.4s	v19, v19, v22
	mov.16b	v21, v0
	bsl.16b	v21, v5, v3
	tbz	w8, #6, LBB0_157
; %bb.156:                              ; %cond.load116
	add	x10, x9, #24
	ld1.s	{ v27 }[2], [x10]
LBB0_157:                               ; %else117
	bsl.16b	v6, v7, v16
	ldp	q4, q0, [sp, #192]              ; 32-byte Folded Reload
	add.2d	v0, v0, v17
	add.2d	v4, v4, v17
	ldr	q5, [sp, #224]                  ; 16-byte Reload
	add.2d	v5, v5, v17
	fmul.4s	v7, v19, v21
	tbz	w8, #7, LBB0_159
; %bb.158:                              ; %cond.load119
	add	x8, x9, #28
	ld1.s	{ v27 }[3], [x8]
LBB0_159:                               ; %else120
	bif.16b	v6, v18, v2
	fadd.4s	v2, v10, v7
	ldr	q7, [sp, #384]                  ; 16-byte Reload
	stp	q7, q0, [sp, #400]
	stp	q4, q5, [sp, #432]
	and	x8, x11, #0x7
	add	x9, sp, #400
	ldr	x8, [x9, x8, lsl #3]
	sub	x8, x8, x11
	add	x8, x13, x8, lsl #2
	ldr	d0, [sp, #368]                  ; 8-byte Reload
	fmov	w9, s0
	tbnz	w9, #0, LBB0_195
; %bb.160:                              ; %else124
	fcmeq.4s	v0, v18, v18
	fadd.4s	v4, v6, v20
	tbnz	w9, #1, LBB0_196
LBB0_161:                               ; %else126
	fmul.4s	v1, v1, v22
	bsl.16b	v0, v4, v3
	tbnz	w9, #2, LBB0_197
LBB0_162:                               ; %else128
	fmul.4s	v0, v1, v0
	tbnz	w9, #3, LBB0_198
LBB0_163:                               ; %else130
	fadd.4s	v0, v27, v0
	tbnz	w9, #4, LBB0_199
LBB0_164:                               ; %else132
	tbnz	w9, #5, LBB0_200
LBB0_165:                               ; %else134
	tbnz	w9, #6, LBB0_201
LBB0_166:                               ; %else136
	tbnz	w9, #7, LBB0_202
	b	LBB0_204
LBB0_167:                               ; %cond.load165
	ld1.s	{ v6 }[0], [x9]
	ldp	q3, q2, [sp, #192]              ; 32-byte Folded Reload
	tbz	w13, #1, LBB0_73
LBB0_168:                               ; %cond.load168
	add	x12, x9, #4
	ld1.s	{ v6 }[1], [x12]
	tbz	w13, #2, LBB0_74
LBB0_169:                               ; %cond.load171
	add	x12, x9, #8
	ld1.s	{ v6 }[2], [x12]
	tbz	w13, #3, LBB0_75
LBB0_170:                               ; %cond.load174
	add	x12, x9, #12
	ld1.s	{ v6 }[3], [x12]
	ldr	q16, [x14, #16]
	tbz	w13, #4, LBB0_76
LBB0_171:                               ; %cond.load177
	add	x12, x9, #16
	ld1.s	{ v16 }[0], [x12]
	mov	w12, #4097                      ; =0x1001
	tbz	w13, #5, LBB0_77
LBB0_172:                               ; %cond.load180
	add	x14, x9, #20
	ld1.s	{ v16 }[1], [x14]
	dup.2s	v0, w12
	tbnz	w13, #6, LBB0_78
	b	LBB0_79
LBB0_173:                               ; %cond.load215
	ld1.s	{ v2 }[0], [x9]
	tbz	w10, #1, LBB0_101
LBB0_174:                               ; %cond.load218
	add	x14, x9, #4
	ld1.s	{ v2 }[1], [x14]
	tbz	w10, #2, LBB0_102
LBB0_175:                               ; %cond.load221
	add	x14, x9, #8
	ld1.s	{ v2 }[2], [x14]
	tbz	w10, #3, LBB0_103
LBB0_176:                               ; %cond.load224
	add	x14, x9, #12
	ld1.s	{ v2 }[3], [x14]
	ldr	q0, [x13, #16]
	tbz	w10, #4, LBB0_104
LBB0_177:                               ; %cond.load227
	add	x13, x9, #16
	ld1.s	{ v0 }[0], [x13]
	tbz	w10, #5, LBB0_105
LBB0_178:                               ; %cond.load230
	add	x13, x9, #20
	ld1.s	{ v0 }[1], [x13]
	tbz	w10, #6, LBB0_106
LBB0_179:                               ; %cond.load233
	add	x13, x9, #24
	ld1.s	{ v0 }[2], [x13]
	stp	q6, q18, [sp, #64]              ; 32-byte Folded Spill
	str	q16, [sp, #32]                  ; 16-byte Spill
	tbnz	w10, #7, LBB0_107
	b	LBB0_108
LBB0_180:                               ; %cond.store257
	str	s2, [x9]
	fcmeq.4s	v3, v3, v3
	fadd.4s	v5, v6, v5
	tbz	w8, #1, LBB0_128
LBB0_181:                               ; %cond.store259
	add	x10, x9, #4
	st1.s	{ v2 }[1], [x10]
	fmul.4s	v1, v1, v20
	bsl.16b	v3, v5, v4
	tbz	w8, #2, LBB0_129
LBB0_182:                               ; %cond.store261
	add	x10, x9, #8
	st1.s	{ v2 }[2], [x10]
	fmul.4s	v1, v1, v3
	ldr	q3, [sp, #16]                   ; 16-byte Reload
	and.16b	v0, v0, v3
	tbz	w8, #3, LBB0_130
LBB0_183:                               ; %cond.store263
	add	x10, x9, #12
	st1.s	{ v2 }[3], [x10]
	fadd.4s	v0, v1, v0
	tbz	w8, #4, LBB0_131
LBB0_184:                               ; %cond.store265
	str	s0, [x9, #16]
	tbz	w8, #5, LBB0_132
LBB0_185:                               ; %cond.store267
	add	x10, x9, #20
	st1.s	{ v0 }[1], [x10]
	tbz	w8, #6, LBB0_133
LBB0_186:                               ; %cond.store269
	add	x10, x9, #24
	st1.s	{ v0 }[2], [x10]
	tbz	w8, #7, LBB0_204
LBB0_187:                               ; %cond.store271
	add	x8, x9, #28
	b	LBB0_203
LBB0_188:                               ; %cond.load73
	ldr	s19, [x9]
	ldr	x13, [sp, #112]                 ; 8-byte Reload
	ldr	x14, [sp, #96]                  ; 8-byte Reload
	adrp	x15, lCPI0_11@PAGE
	tbz	w8, #1, LBB0_136
LBB0_189:                               ; %cond.load76
	add	x12, x9, #4
	ld1.s	{ v19 }[1], [x12]
	tbz	w8, #2, LBB0_137
LBB0_190:                               ; %cond.load79
	add	x12, x9, #8
	ld1.s	{ v19 }[2], [x12]
	tbz	w8, #3, LBB0_138
LBB0_191:                               ; %cond.load82
	add	x12, x9, #12
	ld1.s	{ v19 }[3], [x12]
	tbz	w8, #4, LBB0_139
LBB0_192:                               ; %cond.load85
	add	x12, x9, #16
	ld1.s	{ v1 }[0], [x12]
	tbz	w8, #5, LBB0_140
LBB0_193:                               ; %cond.load88
	add	x12, x9, #20
	ld1.s	{ v1 }[1], [x12]
	tbz	w8, #6, LBB0_141
LBB0_194:                               ; %cond.load91
	add	x12, x9, #24
	ld1.s	{ v1 }[2], [x12]
	tbnz	w8, #7, LBB0_142
	b	LBB0_143
LBB0_195:                               ; %cond.store123
	str	s2, [x8]
	fcmeq.4s	v0, v18, v18
	fadd.4s	v4, v6, v20
	tbz	w9, #1, LBB0_161
LBB0_196:                               ; %cond.store125
	add	x10, x8, #4
	st1.s	{ v2 }[1], [x10]
	fmul.4s	v1, v1, v22
	bsl.16b	v0, v4, v3
	tbz	w9, #2, LBB0_162
LBB0_197:                               ; %cond.store127
	add	x10, x8, #8
	st1.s	{ v2 }[2], [x10]
	fmul.4s	v0, v1, v0
	tbz	w9, #3, LBB0_163
LBB0_198:                               ; %cond.store129
	add	x10, x8, #12
	st1.s	{ v2 }[3], [x10]
	fadd.4s	v0, v27, v0
	tbz	w9, #4, LBB0_164
LBB0_199:                               ; %cond.store131
	str	s0, [x8, #16]
	tbz	w9, #5, LBB0_165
LBB0_200:                               ; %cond.store133
	add	x10, x8, #20
	st1.s	{ v0 }[1], [x10]
	tbz	w9, #6, LBB0_166
LBB0_201:                               ; %cond.store135
	add	x10, x8, #24
	st1.s	{ v0 }[2], [x10]
	tbz	w9, #7, LBB0_204
LBB0_202:                               ; %cond.store137
	add	x8, x8, #28
LBB0_203:                               ; %common.ret
	st1.s	{ v0 }[3], [x8]
LBB0_204:                               ; %common.ret
	add	sp, sp, #8, lsl #12             ; =32768
	add	sp, sp, #832
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
                                        ; -- End function
	.p2align	2                               ; -- Begin function llm_rows.full_packet
_llm_rows.full_packet:                  ; @llm_rows.full_packet
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-144]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	sub	sp, sp, #8, lsl #12             ; =32768
	sub	sp, sp, #368
	ldr	x22, [x0]
	ldr	x21, [x0, #16]
	ldr	x19, [x0, #48]
	ldr	w8, [x1]
	ldr	w9, [x1, #36]
	add	w8, w9, w8, lsl #5
	lsr	w8, w8, #3
	dup.2s	v0, w8
	ushll.2d	v0, v0, #0
	subs	x8, x22, x19
	cset	w9, hs
	mov	w10, #4095                      ; =0xfff
	movk	w10, #256, lsl #16
	cmp	x8, x10
	csel	w8, wzr, w9, ls
	subs	x9, x19, x22
	cset	w11, hs
	cmp	x9, x10
	csel	w9, wzr, w11, ls
	orr	w9, w8, w9
	subs	x8, x21, x19
	cset	w11, hs
	cmp	x8, x10
	csel	w8, wzr, w11, ls
	subs	x11, x19, x21
	cset	w12, hs
	cmp	x11, x10
	csel	w10, wzr, w12, ls
	orr	w10, w8, w10
	fmov	x8, d0
	add	x8, x8, x8, lsl #12
	lsl	x8, x8, #2
	cmp	w9, #1
	ccmp	w10, #0, #4, eq
	b.ne	LBB1_4
; %bb.1:                                ; %direct.schedule.8.preheader
	add	x23, sp, #4, lsl #12            ; =16384
	add	x23, x23, #336
	add	x0, sp, #4, lsl #12             ; =16384
	add	x0, x0, #336
	add	x1, x22, x8
	mov	w2, #16384                      ; =0x4000
	str	q0, [sp, #288]                  ; 16-byte Spill
	bl	_memcpy
	ldr	q0, [sp, #288]                  ; 16-byte Reload
	fmov	x8, d0
	add	x8, x8, x8, lsl #12
	lsl	x24, x8, #2
	add	x20, x24, #4, lsl #12           ; =16384
	ldr	s0, [x22, x20]
	str	q0, [sp]                        ; 16-byte Spill
	str	q0, [sp, #33104]
	add	x22, sp, #304
	add	x0, sp, #304
	add	x1, x21, x24
	mov	w2, #16384                      ; =0x4000
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	mov	w9, #10003                      ; =0x2713
	movk	w9, #15671, lsl #16
	dup.4s	v1, w9
	mov	w9, #16938                      ; =0x422a
	movk	w9, #16204, lsl #16
	dup.4s	v0, w9
	stp	q0, q1, [sp, #272]              ; 32-byte Folded Spill
	mov	w9, #37425                      ; =0x9231
	movk	w9, #12080, lsl #16
	dup.4s	v1, w9
	mov	w9, #12843                      ; =0x322b
	movk	w9, #13015, lsl #16
	dup.4s	v0, w9
	stp	q0, q1, [sp, #240]              ; 32-byte Folded Spill
	mov	w9, #61213                      ; =0xef1d
	movk	w9, #13880, lsl #16
	dup.4s	v1, w9
	mov	w9, #3329                       ; =0xd01
	movk	w9, #14672, lsl #16
	dup.4s	v0, w9
	stp	q0, q1, [sp, #208]              ; 32-byte Folded Spill
	mov	w9, #34953                      ; =0x8889
	movk	w9, #15368, lsl #16
	dup.4s	v1, w9
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #15914, lsl #16
	dup.4s	v19, w9
	mov	w9, #30407                      ; =0x76c7
	movk	w9, #12559, lsl #16
	dup.4s	v0, w9
	stp	q0, q1, [sp, #176]              ; 32-byte Folded Spill
	mov	w9, #62078                      ; =0xf27e
	movk	w9, #13459, lsl #16
	dup.4s	v1, w9
	mov	w9, #3329                       ; =0xd01
	movk	w9, #14288, lsl #16
	dup.4s	v0, w9
	stp	q0, q1, [sp, #144]              ; 32-byte Folded Spill
	mov	w9, #2913                       ; =0xb61
	movk	w9, #15030, lsl #16
	dup.4s	v1, w9
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #15658, lsl #16
	dup.4s	v0, w9
	stp	q0, q1, [sp, #112]              ; 32-byte Folded Spill
	mov	w9, #-1026555904                ; =0xc2d00000
	dup.4s	v1, w9
	mov	w9, #1120403456                 ; =0x42c80000
	dup.4s	v23, w9
	mov	w9, #43579                      ; =0xaa3b
	movk	w9, #16312, lsl #16
	dup.4s	v0, w9
	stp	q0, q1, [sp, #80]               ; 32-byte Folded Spill
	mov	w9, #29184                      ; =0x7200
	movk	w9, #48945, lsl #16
	dup.4s	v1, w9
	mov	w9, #48782                      ; =0xbe8e
	movk	w9, #46527, lsl #16
	dup.4s	v0, w9
	stp	q0, q1, [sp, #48]               ; 32-byte Folded Spill
	mov	w9, #11226                      ; =0x2bda
	movk	w9, #14672, lsl #16
	dup.4s	v1, w9
	mov	w9, #38601                      ; =0x96c9
	movk	w9, #15030, lsl #16
	dup.4s	v28, w9
	mov	w9, #34982                      ; =0x88a6
	movk	w9, #15368, lsl #16
	dup.4s	v29, w9
	mov	w9, #43642                      ; =0xaa7a
	movk	w9, #15658, lsl #16
	dup.4s	v30, w9
	ldr	s0, [x21, x20]
	add	x9, x19, x24
	stp	q0, q1, [sp, #16]               ; 32-byte Folded Spill
	str	q0, [sp, #16688]
	movi.4s	v31, #63, lsl #24
	fmov.4s	v8, #1.00000000
	mvni.4s	v0, #127, msl #16
	fneg.4s	v13, v0
	mvni.4s	v0, #63, msl #16
	fneg.4s	v15, v0
LBB1_2:                                 ; %direct.true83
                                        ; =>This Inner Loop Header: Depth=1
	add	x10, x23, x8
	ldp	q9, q10, [x10]
	ldp	q2, q1, [sp, #272]              ; 32-byte Folded Reload
	fmul.4s	v0, v9, v1
	fmul.4s	v1, v10, v1
	fmul.4s	v1, v10, v1
	fmul.4s	v0, v9, v0
	fmul.4s	v0, v9, v0
	fmul.4s	v1, v10, v1
	fadd.4s	v1, v10, v1
	fadd.4s	v0, v9, v0
	fmul.4s	v12, v0, v2
	fmul.4s	v11, v1, v2
	fabs.4s	v0, v11
	fabs.4s	v14, v12
	fmul.4s	v6, v12, v12
	fmul.4s	v17, v11, v11
	ldp	q2, q3, [sp, #240]              ; 32-byte Folded Reload
	mov.16b	v1, v2
	fmla.4s	v1, v6, v3
	fmla.4s	v2, v17, v3
	ldr	q4, [sp, #224]                  ; 16-byte Reload
	mov.16b	v3, v4
	fmla.4s	v3, v6, v1
	mov.16b	v1, v4
	fmla.4s	v1, v17, v2
	ldp	q5, q4, [sp, #192]              ; 32-byte Folded Reload
	mov.16b	v2, v4
	fmla.4s	v2, v6, v3
	mov.16b	v3, v4
	fmla.4s	v3, v17, v1
	mov.16b	v4, v5
	mov.16b	v16, v19
	mov.16b	v18, v19
	fmov.4s	v1, #1.00000000
	fmla.4s	v4, v6, v2
	ldp	q7, q20, [sp, #160]             ; 32-byte Folded Reload
	mov.16b	v2, v7
	fmla.4s	v2, v17, v20
	fmla.4s	v7, v6, v20
	ldr	q21, [sp, #144]                 ; 16-byte Reload
	mov.16b	v20, v21
	fmla.4s	v5, v17, v3
	fmla.4s	v20, v17, v2
	mov.16b	v2, v21
	fmla.4s	v2, v6, v7
	ldr	q7, [sp, #128]                  ; 16-byte Reload
	mov.16b	v3, v7
	fmla.4s	v3, v17, v20
	fmla.4s	v16, v6, v4
	mov.16b	v4, v7
	fmla.4s	v4, v6, v2
	ldp	q25, q20, [sp, #96]             ; 32-byte Folded Reload
	mov.16b	v7, v20
	fmla.4s	v7, v17, v3
	fmla.4s	v18, v17, v5
	fmla.4s	v20, v6, v4
	movi.4s	v21, #63, lsl #24
	movi.4s	v22, #63, lsl #24
	fmov.4s	v4, #1.00000000
	fmov.4s	v3, #9.00000000
	fcmge.4s	v2, v3, v14
	fmla.4s	v21, v17, v7
	fcmge.4s	v3, v3, v0
	and.16b	v5, v3, v0
	and.16b	v7, v2, v14
	fcmge.4s	v24, v7, v25
	fcmge.4s	v25, v5, v25
	fcmge.4s	v26, v23, v5
	and.16b	v25, v25, v26
	fcmge.4s	v26, v23, v7
	and.16b	v24, v24, v26
	and.16b	v24, v24, v7
	and.16b	v25, v25, v5
	fmla.4s	v1, v17, v18
	ldr	q26, [sp, #80]                  ; 16-byte Reload
	fmul.4s	v18, v25, v26
	fmul.4s	v26, v24, v26
	movi.4s	v27, #75, lsl #24
	fadd.4s	v26, v26, v27
	fadd.4s	v18, v18, v27
	movi.4s	v27, #203, lsl #24
	fadd.4s	v18, v18, v27
	fmla.4s	v4, v17, v21
	fadd.4s	v17, v26, v27
	fcvtzs.4s	v17, v17
	fcvtzs.4s	v18, v18
	scvtf.4s	v21, v18
	scvtf.4s	v26, v17
	fmla.4s	v22, v6, v20
	ldr	q27, [sp, #64]                  ; 16-byte Reload
	fmul.4s	v20, v21, v27
	fadd.4s	v20, v25, v20
	fmul.4s	v25, v26, v27
	fadd.4s	v24, v24, v25
	fmov.4s	v25, #1.00000000
	fmla.4s	v25, v6, v16
	ldr	q27, [sp, #48]                  ; 16-byte Reload
	fmul.4s	v16, v26, v27
	fadd.4s	v16, v24, v16
	fmul.4s	v21, v21, v27
	fadd.4s	v20, v20, v21
	fmov.4s	v21, #1.00000000
	fmla.4s	v21, v6, v22
	ldr	q22, [sp, #32]                  ; 16-byte Reload
	fmul.4s	v6, v20, v22
	fmul.4s	v22, v16, v22
	fadd.4s	v22, v22, v28
	fadd.4s	v6, v6, v28
	fmul.4s	v6, v20, v6
	fmul.4s	v24, v14, v25
	fmul.4s	v22, v16, v22
	fadd.4s	v22, v22, v29
	fadd.4s	v6, v6, v29
	fmul.4s	v6, v20, v6
	fmul.4s	v22, v16, v22
	fadd.4s	v22, v22, v30
	fadd.4s	v6, v6, v30
	fmul.4s	v6, v20, v6
	fmul.4s	v22, v16, v22
	fadd.4s	v22, v22, v19
	fadd.4s	v25, v6, v19
	fdiv.4s	v6, v24, v21
	fmul.4s	v21, v20, v25
	fmul.4s	v22, v16, v22
	fadd.4s	v22, v22, v31
	fadd.4s	v21, v21, v31
	fmul.4s	v24, v20, v20
	fmul.4s	v21, v24, v21
	fmul.4s	v24, v16, v16
	fmul.4s	v22, v24, v22
	fadd.4s	v16, v16, v22
	fadd.4s	v20, v20, v21
	movi.2d	v24, #0xffffffffffffffff
	add.4s	v17, v17, v24
	fadd.4s	v16, v16, v8
	sshr.4s	v21, v17, #1
	shl.4s	v22, v21, #23
	add.4s	v22, v22, v8
	fmul.4s	v16, v16, v22
	add.4s	v18, v18, v24
	fadd.4s	v20, v20, v8
	sub.4s	v17, v17, v21
	sshr.4s	v21, v18, #1
	sub.4s	v18, v18, v21
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v8
	fmul.4s	v20, v20, v21
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v8
	fmul.4s	v18, v20, v18
	shl.4s	v17, v17, #23
	add.4s	v17, v17, v8
	fmul.4s	v16, v16, v17
	fcmgt.4s	v7, v7, v23
	bsl.16b	v7, v13, v16
	fmul.4s	v1, v0, v1
	fcmgt.4s	v5, v5, v23
	bsl.16b	v5, v13, v18
	fdiv.4s	v1, v1, v4
	fmov.4s	v17, #0.25000000
	fdiv.4s	v4, v17, v5
	fsub.4s	v16, v5, v4
	fadd.4s	v4, v5, v4
	fdiv.4s	v4, v16, v4
	bsl.16b	v3, v4, v8
	fcmge.4s	v0, v8, v0
	bsl.16b	v0, v1, v3
	fdiv.4s	v1, v17, v7
	fsub.4s	v3, v7, v1
	fadd.4s	v1, v7, v1
	fdiv.4s	v1, v3, v1
	bif.16b	v1, v8, v2
	fcmge.4s	v2, v8, v14
	bit.16b	v1, v6, v2
	mvni.4s	v3, #128, lsl #24
	bif.16b	v1, v12, v3
	fcmeq.4s	v2, v12, v12
	fadd.4s	v1, v1, v8
	bif.16b	v1, v15, v2
	bif.16b	v0, v11, v3
	fcmeq.4s	v2, v11, v11
	fadd.4s	v0, v0, v8
	bif.16b	v0, v15, v2
	fmul.4s	v2, v10, v31
	fmul.4s	v0, v2, v0
	fmul.4s	v2, v9, v31
	fmul.4s	v1, v2, v1
	add	x10, x22, x8
	ldp	q3, q2, [x10]
	fadd.4s	v1, v3, v1
	fadd.4s	v0, v2, v0
	add	x10, x9, x8
	stp	q1, q0, [x10]
	add	x8, x8, #32
	cmp	x8, #4, lsl #12                 ; =16384
	b.ne	LBB1_2
; %bb.3:                                ; %direct.false84
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], v0[0]
	mov.16b	v2, v0
	ldr	q4, [sp]                        ; 16-byte Reload
	mov.s	v2[0], v4[0]
	movi.4s	v1, #63, lsl #24
	mov	w8, #10003                      ; =0x2713
	movk	w8, #15671, lsl #16
	fmov	s3, w8
	fmul.4s	v3, v2, v3[0]
	fmul.4s	v3, v4, v3
	fmul.4s	v3, v4, v3
	fadd.4s	v3, v4, v3
	mov	w8, #16938                      ; =0x422a
	movk	w8, #16204, lsl #16
	fmov	s4, w8
	fmul.4s	v3, v3, v4
	mov.s	v0[0], v3[0]
	fabs.4s	v3, v0
	mov	w8, #37425                      ; =0x9231
	movk	w8, #12080, lsl #16
	dup.4s	v5, w8
	mov	w8, #12843                      ; =0x322b
	movk	w8, #13015, lsl #16
	dup.4s	v6, w8
	fmul.4s	v4, v0, v0
	fmla.4s	v6, v4, v5
	mov	w8, #61213                      ; =0xef1d
	movk	w8, #13880, lsl #16
	dup.4s	v5, w8
	fmla.4s	v5, v4, v6
	mov	w8, #3329                       ; =0xd01
	movk	w8, #14672, lsl #16
	dup.4s	v6, w8
	mov	w8, #34953                      ; =0x8889
	movk	w8, #15368, lsl #16
	dup.4s	v16, w8
	fmla.4s	v6, v4, v5
	fmla.4s	v16, v4, v6
	mov	w8, #43691                      ; =0xaaab
	movk	w8, #15914, lsl #16
	dup.4s	v17, w8
	fmov.4s	v5, #9.00000000
	fcmge.4s	v5, v5, v3
	and.16b	v6, v5, v3
	mov	w8, #-1026555904                ; =0xc2d00000
	dup.4s	v7, w8
	fcmge.4s	v18, v6, v7
	mov	w8, #1120403456                 ; =0x42c80000
	dup.4s	v7, w8
	fcmge.4s	v19, v7, v6
	and.16b	v18, v18, v19
	and.16b	v18, v18, v6
	mov	w8, #43579                      ; =0xaa3b
	movk	w8, #16312, lsl #16
	dup.4s	v19, w8
	fmul.4s	v19, v18, v19
	movi.4s	v20, #75, lsl #24
	fadd.4s	v19, v19, v20
	movi.4s	v20, #203, lsl #24
	fadd.4s	v19, v19, v20
	fcvtzs.4s	v19, v19
	mov	w8, #29184                      ; =0x7200
	movk	w8, #48945, lsl #16
	dup.4s	v20, w8
	scvtf.4s	v21, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	mov	w8, #48782                      ; =0xbe8e
	movk	w8, #46527, lsl #16
	dup.4s	v20, w8
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	mov	w8, #11226                      ; =0x2bda
	movk	w8, #14672, lsl #16
	dup.4s	v20, w8
	fmul.4s	v20, v18, v20
	mov	w8, #38601                      ; =0x96c9
	movk	w8, #15030, lsl #16
	dup.4s	v21, w8
	fadd.4s	v20, v20, v21
	fmul.4s	v20, v18, v20
	mov	w8, #34982                      ; =0x88a6
	movk	w8, #15368, lsl #16
	dup.4s	v21, w8
	fadd.4s	v20, v20, v21
	mov	w8, #43642                      ; =0xaa7a
	movk	w8, #15658, lsl #16
	dup.4s	v21, w8
	fmul.4s	v20, v18, v20
	fadd.4s	v20, v20, v21
	fmul.4s	v20, v18, v20
	fadd.4s	v20, v20, v17
	fmla.4s	v17, v4, v16
	fmov.4s	v16, #1.00000000
	fmla.4s	v16, v4, v17
	mov	w8, #30407                      ; =0x76c7
	movk	w8, #12559, lsl #16
	dup.4s	v17, w8
	mov	w8, #62078                      ; =0xf27e
	movk	w8, #13459, lsl #16
	dup.4s	v21, w8
	fmla.4s	v21, v4, v17
	mov	w8, #3329                       ; =0xd01
	movk	w8, #14288, lsl #16
	dup.4s	v17, w8
	fmul.4s	v2, v2, v1
	fmla.4s	v17, v4, v21
	mov	w8, #2913                       ; =0xb61
	movk	w8, #15030, lsl #16
	dup.4s	v21, w8
	fmla.4s	v21, v4, v17
	mov	w8, #43691                      ; =0xaaab
	movk	w8, #15658, lsl #16
	dup.4s	v17, w8
	fmla.4s	v17, v4, v21
	movi.4s	v21, #63, lsl #24
	fmla.4s	v21, v4, v17
	fmov.4s	v17, #1.00000000
	fmla.4s	v17, v4, v21
	fmov.4s	v4, #1.00000000
	fcmge.4s	v21, v4, v3
	fmul.4s	v3, v3, v16
	fdiv.4s	v3, v3, v17
	fmul.4s	v16, v18, v20
	fadd.4s	v1, v16, v1
	fmul.4s	v16, v18, v18
	fmul.4s	v1, v16, v1
	fadd.4s	v1, v18, v1
	fadd.4s	v1, v1, v4
	movi.2d	v16, #0xffffffffffffffff
	add.4s	v16, v19, v16
	sshr.4s	v17, v16, #1
	shl.4s	v18, v17, #23
	add.4s	v18, v18, v4
	fmul.4s	v1, v1, v18
	sub.4s	v16, v16, v17
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v4
	fmul.4s	v1, v1, v16
	fcmgt.4s	v6, v6, v7
	mvni.4s	v7, #127, msl #16
	fneg.4s	v7, v7
	bit.16b	v1, v7, v6
	fmov.4s	v6, #0.25000000
	fdiv.4s	v6, v6, v1
	fsub.4s	v7, v1, v6
	fadd.4s	v1, v1, v6
	fdiv.4s	v1, v7, v1
	bif.16b	v1, v4, v5
	bit.16b	v1, v3, v21
	mvni.4s	v3, #128, lsl #24
	bif.16b	v1, v0, v3
	fcmeq.4s	v0, v0, v0
	fadd.4s	v1, v1, v4
	mvni.4s	v3, #63, msl #16
	fneg.4s	v3, v3
	bsl.16b	v0, v1, v3
	fmul.4s	v0, v2, v0
	ldr	q1, [sp, #16]                   ; 16-byte Reload
	fadd.4s	v0, v0, v1
	b	LBB1_7
LBB1_4:                                 ; %direct.true20.preheader
	mov	x9, #0                          ; =0x0
	mov	w10, #10003                     ; =0x2713
	movk	w10, #15671, lsl #16
	dup.4s	v1, w10
	mov	w10, #16938                     ; =0x422a
	movk	w10, #16204, lsl #16
	dup.4s	v0, w10
	stp	q0, q1, [sp, #272]              ; 32-byte Folded Spill
	mov	w10, #37425                     ; =0x9231
	movk	w10, #12080, lsl #16
	dup.4s	v1, w10
	mov	w10, #12843                     ; =0x322b
	movk	w10, #13015, lsl #16
	dup.4s	v0, w10
	stp	q0, q1, [sp, #240]              ; 32-byte Folded Spill
	mov	w10, #61213                     ; =0xef1d
	movk	w10, #13880, lsl #16
	dup.4s	v1, w10
	mov	w10, #3329                      ; =0xd01
	movk	w10, #14672, lsl #16
	dup.4s	v0, w10
	stp	q0, q1, [sp, #208]              ; 32-byte Folded Spill
	mov	w10, #34953                     ; =0x8889
	movk	w10, #15368, lsl #16
	dup.4s	v1, w10
	mov	w10, #43691                     ; =0xaaab
	movk	w10, #15914, lsl #16
	dup.4s	v18, w10
	mov	w10, #30407                     ; =0x76c7
	movk	w10, #12559, lsl #16
	dup.4s	v0, w10
	stp	q0, q1, [sp, #176]              ; 32-byte Folded Spill
	mov	w10, #62078                     ; =0xf27e
	movk	w10, #13459, lsl #16
	dup.4s	v1, w10
	mov	w10, #3329                      ; =0xd01
	movk	w10, #14288, lsl #16
	dup.4s	v0, w10
	stp	q0, q1, [sp, #144]              ; 32-byte Folded Spill
	mov	w10, #2913                      ; =0xb61
	movk	w10, #15030, lsl #16
	dup.4s	v1, w10
	mov	w10, #43691                     ; =0xaaab
	movk	w10, #15658, lsl #16
	dup.4s	v0, w10
	stp	q0, q1, [sp, #112]              ; 32-byte Folded Spill
	mov	w10, #-1026555904               ; =0xc2d00000
	dup.4s	v1, w10
	mov	w10, #1120403456                ; =0x42c80000
	dup.4s	v22, w10
	mov	w10, #43579                     ; =0xaa3b
	movk	w10, #16312, lsl #16
	dup.4s	v0, w10
	stp	q0, q1, [sp, #80]               ; 32-byte Folded Spill
	mov	w10, #29184                     ; =0x7200
	movk	w10, #48945, lsl #16
	dup.4s	v1, w10
	mov	w10, #48782                     ; =0xbe8e
	movk	w10, #46527, lsl #16
	dup.4s	v0, w10
	stp	q0, q1, [sp, #48]               ; 32-byte Folded Spill
	mov	w10, #11226                     ; =0x2bda
	movk	w10, #14672, lsl #16
	dup.4s	v0, w10
	str	q0, [sp, #32]                   ; 16-byte Spill
	mov	w10, #38601                     ; =0x96c9
	movk	w10, #15030, lsl #16
	dup.4s	v27, w10
	mov	w10, #34982                     ; =0x88a6
	movk	w10, #15368, lsl #16
	dup.4s	v28, w10
	mov	w10, #43642                     ; =0xaa7a
	movk	w10, #15658, lsl #16
	dup.4s	v29, w10
	add	x10, x19, x8
	add	x11, x21, x8
	add	x12, x22, x8
	movi.4s	v30, #63, lsl #24
	fmov.4s	v31, #1.00000000
	mvni.4s	v0, #127, msl #16
	fneg.4s	v12, v0
	mvni.4s	v0, #63, msl #16
	fneg.4s	v15, v0
LBB1_5:                                 ; %direct.true20
                                        ; =>This Inner Loop Header: Depth=1
	add	x13, x12, x9
	ldp	q8, q9, [x13]
	ldp	q2, q1, [sp, #272]              ; 32-byte Folded Reload
	fmul.4s	v0, v8, v1
	fmul.4s	v1, v9, v1
	fmul.4s	v1, v9, v1
	fmul.4s	v0, v8, v0
	fmul.4s	v0, v8, v0
	fmul.4s	v1, v9, v1
	fadd.4s	v1, v9, v1
	fadd.4s	v0, v8, v0
	fmul.4s	v11, v0, v2
	fmul.4s	v10, v1, v2
	fabs.4s	v14, v10
	fabs.4s	v13, v11
	fmul.4s	v5, v11, v11
	fmul.4s	v16, v10, v10
	ldp	q1, q2, [sp, #240]              ; 32-byte Folded Reload
	mov.16b	v0, v1
	fmla.4s	v0, v5, v2
	fmla.4s	v1, v16, v2
	ldr	q3, [sp, #224]                  ; 16-byte Reload
	mov.16b	v2, v3
	fmla.4s	v2, v5, v0
	mov.16b	v0, v3
	fmla.4s	v0, v16, v1
	ldp	q4, q3, [sp, #192]              ; 32-byte Folded Reload
	mov.16b	v1, v3
	fmla.4s	v1, v5, v2
	mov.16b	v2, v3
	fmla.4s	v2, v16, v0
	mov.16b	v3, v4
	mov.16b	v7, v18
	mov.16b	v17, v18
	fmov.4s	v0, #1.00000000
	fmla.4s	v3, v5, v1
	ldp	q6, q19, [sp, #160]             ; 32-byte Folded Reload
	mov.16b	v1, v6
	fmla.4s	v1, v16, v19
	fmla.4s	v6, v5, v19
	ldr	q20, [sp, #144]                 ; 16-byte Reload
	mov.16b	v19, v20
	fmla.4s	v4, v16, v2
	fmla.4s	v19, v16, v1
	mov.16b	v1, v20
	fmla.4s	v1, v5, v6
	ldr	q6, [sp, #128]                  ; 16-byte Reload
	mov.16b	v2, v6
	fmla.4s	v2, v16, v19
	fmla.4s	v7, v5, v3
	mov.16b	v3, v6
	fmla.4s	v3, v5, v1
	ldp	q24, q19, [sp, #96]             ; 32-byte Folded Reload
	mov.16b	v6, v19
	fmla.4s	v6, v16, v2
	fmla.4s	v17, v16, v4
	fmla.4s	v19, v5, v3
	movi.4s	v20, #63, lsl #24
	movi.4s	v21, #63, lsl #24
	fmov.4s	v3, #1.00000000
	fmov.4s	v2, #9.00000000
	fcmge.4s	v1, v2, v13
	fmla.4s	v20, v16, v6
	fcmge.4s	v2, v2, v14
	and.16b	v4, v2, v14
	and.16b	v6, v1, v13
	fcmge.4s	v23, v6, v24
	fcmge.4s	v24, v4, v24
	fcmge.4s	v25, v22, v4
	and.16b	v24, v24, v25
	fcmge.4s	v25, v22, v6
	and.16b	v23, v23, v25
	and.16b	v23, v23, v6
	and.16b	v24, v24, v4
	fmla.4s	v0, v16, v17
	ldr	q25, [sp, #80]                  ; 16-byte Reload
	fmul.4s	v17, v24, v25
	fmul.4s	v25, v23, v25
	movi.4s	v26, #75, lsl #24
	fadd.4s	v25, v25, v26
	fadd.4s	v17, v17, v26
	movi.4s	v26, #203, lsl #24
	fadd.4s	v17, v17, v26
	fmla.4s	v3, v16, v20
	fadd.4s	v16, v25, v26
	fcvtzs.4s	v16, v16
	fcvtzs.4s	v17, v17
	scvtf.4s	v20, v17
	scvtf.4s	v25, v16
	fmla.4s	v21, v5, v19
	ldr	q26, [sp, #64]                  ; 16-byte Reload
	fmul.4s	v19, v20, v26
	fadd.4s	v19, v24, v19
	fmul.4s	v24, v25, v26
	fadd.4s	v23, v23, v24
	fmov.4s	v24, #1.00000000
	fmla.4s	v24, v5, v7
	ldr	q26, [sp, #48]                  ; 16-byte Reload
	fmul.4s	v7, v25, v26
	fadd.4s	v7, v23, v7
	fmul.4s	v20, v20, v26
	fadd.4s	v19, v19, v20
	fmov.4s	v20, #1.00000000
	fmla.4s	v20, v5, v21
	ldr	q21, [sp, #32]                  ; 16-byte Reload
	fmul.4s	v5, v19, v21
	fmul.4s	v21, v7, v21
	fadd.4s	v21, v21, v27
	fadd.4s	v5, v5, v27
	fmul.4s	v5, v19, v5
	fmul.4s	v23, v13, v24
	fmul.4s	v21, v7, v21
	fadd.4s	v21, v21, v28
	fadd.4s	v5, v5, v28
	fmul.4s	v5, v19, v5
	fmul.4s	v21, v7, v21
	fadd.4s	v21, v21, v29
	fadd.4s	v5, v5, v29
	fmul.4s	v5, v19, v5
	fmul.4s	v21, v7, v21
	fadd.4s	v21, v21, v18
	fadd.4s	v24, v5, v18
	fdiv.4s	v5, v23, v20
	fmul.4s	v20, v19, v24
	fmul.4s	v21, v7, v21
	fadd.4s	v21, v21, v30
	fadd.4s	v20, v20, v30
	fmul.4s	v23, v19, v19
	fmul.4s	v20, v23, v20
	fmul.4s	v23, v7, v7
	fmul.4s	v21, v23, v21
	fadd.4s	v7, v7, v21
	fadd.4s	v19, v19, v20
	movi.2d	v23, #0xffffffffffffffff
	add.4s	v16, v16, v23
	fadd.4s	v7, v7, v31
	sshr.4s	v20, v16, #1
	shl.4s	v21, v20, #23
	add.4s	v21, v21, v31
	fmul.4s	v7, v7, v21
	add.4s	v17, v17, v23
	fadd.4s	v19, v19, v31
	sub.4s	v16, v16, v20
	sshr.4s	v20, v17, #1
	sub.4s	v17, v17, v20
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v31
	fmul.4s	v19, v19, v20
	shl.4s	v17, v17, #23
	add.4s	v17, v17, v31
	fmul.4s	v17, v19, v17
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v31
	fmul.4s	v7, v7, v16
	fcmgt.4s	v6, v6, v22
	bsl.16b	v6, v12, v7
	fmul.4s	v0, v14, v0
	fcmgt.4s	v4, v4, v22
	bsl.16b	v4, v12, v17
	fdiv.4s	v0, v0, v3
	fmov.4s	v16, #0.25000000
	fdiv.4s	v3, v16, v4
	fsub.4s	v7, v4, v3
	fadd.4s	v3, v4, v3
	fdiv.4s	v3, v7, v3
	bsl.16b	v2, v3, v31
	fcmge.4s	v3, v31, v14
	bif.16b	v0, v2, v3
	fdiv.4s	v2, v16, v6
	fsub.4s	v3, v6, v2
	fadd.4s	v2, v6, v2
	fdiv.4s	v2, v3, v2
	bsl.16b	v1, v2, v31
	fcmge.4s	v2, v31, v13
	bit.16b	v1, v5, v2
	mvni.4s	v3, #128, lsl #24
	bif.16b	v1, v11, v3
	fcmeq.4s	v2, v11, v11
	fadd.4s	v1, v1, v31
	bif.16b	v1, v15, v2
	bif.16b	v0, v10, v3
	fcmeq.4s	v2, v10, v10
	fadd.4s	v0, v0, v31
	bif.16b	v0, v15, v2
	fmul.4s	v2, v9, v30
	fmul.4s	v0, v2, v0
	fmul.4s	v2, v8, v30
	fmul.4s	v1, v2, v1
	add	x13, x11, x9
	ldp	q3, q2, [x13]
	fadd.4s	v1, v3, v1
	fadd.4s	v0, v2, v0
	add	x13, x10, x9
	stp	q1, q0, [x13]
	add	x9, x9, #32
	cmp	x9, #4, lsl #12                 ; =16384
	b.ne	LBB1_5
; %bb.6:                                ; %direct.false21
	add	x20, x8, #4, lsl #12            ; =16384
	ldr	s2, [x22, x20]
	movi.2d	v0, #0000000000000000
	movi.4s	v1, #63, lsl #24
	mov	w8, #10003                      ; =0x2713
	movk	w8, #15671, lsl #16
	fmov	s3, w8
	fmul.4s	v3, v2, v3
	fmul.4s	v3, v2, v3
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v2, v3
	mov	w8, #16938                      ; =0x422a
	movk	w8, #16204, lsl #16
	fmov	s4, w8
	fmul.4s	v3, v3, v4
	mov.s	v0[0], v3[0]
	fabs.4s	v3, v0
	fmul.4s	v4, v0, v0
	mov	w8, #37425                      ; =0x9231
	movk	w8, #12080, lsl #16
	dup.4s	v5, w8
	mov	w8, #12843                      ; =0x322b
	movk	w8, #13015, lsl #16
	dup.4s	v6, w8
	fmla.4s	v6, v4, v5
	mov	w8, #61213                      ; =0xef1d
	movk	w8, #13880, lsl #16
	dup.4s	v5, w8
	mov	w8, #3329                       ; =0xd01
	movk	w8, #14672, lsl #16
	dup.4s	v7, w8
	fmla.4s	v5, v4, v6
	fmla.4s	v7, v4, v5
	mov	w8, #34953                      ; =0x8889
	movk	w8, #15368, lsl #16
	dup.4s	v16, w8
	fmla.4s	v16, v4, v7
	mov	w8, #43691                      ; =0xaaab
	movk	w8, #15914, lsl #16
	dup.4s	v17, w8
	fmov.4s	v5, #9.00000000
	fcmge.4s	v5, v5, v3
	and.16b	v6, v5, v3
	mov	w8, #-1026555904                ; =0xc2d00000
	dup.4s	v18, w8
	mov	w8, #1120403456                 ; =0x42c80000
	dup.4s	v7, w8
	fcmge.4s	v18, v6, v18
	fcmge.4s	v19, v7, v6
	and.16b	v18, v18, v19
	mov	w8, #43579                      ; =0xaa3b
	movk	w8, #16312, lsl #16
	dup.4s	v19, w8
	and.16b	v18, v18, v6
	fmul.4s	v19, v18, v19
	movi.4s	v20, #75, lsl #24
	fadd.4s	v19, v19, v20
	movi.4s	v20, #203, lsl #24
	fadd.4s	v19, v19, v20
	fcvtzs.4s	v19, v19
	scvtf.4s	v20, v19
	mov	w8, #29184                      ; =0x7200
	movk	w8, #48945, lsl #16
	dup.4s	v21, w8
	fmul.4s	v21, v20, v21
	fadd.4s	v18, v18, v21
	mov	w8, #48782                      ; =0xbe8e
	movk	w8, #46527, lsl #16
	dup.4s	v21, w8
	fmul.4s	v20, v20, v21
	fadd.4s	v18, v18, v20
	mov	w8, #11226                      ; =0x2bda
	movk	w8, #14672, lsl #16
	dup.4s	v20, w8
	mov	w8, #38601                      ; =0x96c9
	movk	w8, #15030, lsl #16
	dup.4s	v21, w8
	fmul.4s	v20, v18, v20
	fadd.4s	v20, v20, v21
	fmul.4s	v20, v18, v20
	mov	w8, #34982                      ; =0x88a6
	movk	w8, #15368, lsl #16
	dup.4s	v21, w8
	fadd.4s	v20, v20, v21
	fmul.4s	v20, v18, v20
	mov	w8, #43642                      ; =0xaa7a
	movk	w8, #15658, lsl #16
	dup.4s	v21, w8
	fadd.4s	v20, v20, v21
	fmul.4s	v20, v18, v20
	fadd.4s	v20, v20, v17
	fmla.4s	v17, v4, v16
	fmov.4s	v16, #1.00000000
	fmla.4s	v16, v4, v17
	mov	w8, #30407                      ; =0x76c7
	movk	w8, #12559, lsl #16
	dup.4s	v17, w8
	mov	w8, #62078                      ; =0xf27e
	movk	w8, #13459, lsl #16
	dup.4s	v21, w8
	fmla.4s	v21, v4, v17
	mov	w8, #3329                       ; =0xd01
	movk	w8, #14288, lsl #16
	dup.4s	v17, w8
	fmla.4s	v17, v4, v21
	mov	w8, #2913                       ; =0xb61
	movk	w8, #15030, lsl #16
	dup.4s	v21, w8
	fmla.4s	v21, v4, v17
	mov	w8, #43691                      ; =0xaaab
	movk	w8, #15658, lsl #16
	dup.4s	v17, w8
	fmul.4s	v2, v2, v1
	fmla.4s	v17, v4, v21
	movi.4s	v21, #63, lsl #24
	fmla.4s	v21, v4, v17
	fmov.4s	v17, #1.00000000
	fmla.4s	v17, v4, v21
	fmov.4s	v4, #1.00000000
	fcmge.4s	v21, v4, v3
	fmul.4s	v3, v3, v16
	fdiv.4s	v3, v3, v17
	fmul.4s	v16, v18, v20
	fadd.4s	v1, v16, v1
	fmul.4s	v16, v18, v18
	fmul.4s	v1, v16, v1
	fadd.4s	v1, v18, v1
	fadd.4s	v1, v1, v4
	movi.2d	v16, #0xffffffffffffffff
	add.4s	v16, v19, v16
	sshr.4s	v17, v16, #1
	shl.4s	v18, v17, #23
	add.4s	v18, v18, v4
	fmul.4s	v1, v1, v18
	sub.4s	v16, v16, v17
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v4
	fmul.4s	v1, v1, v16
	fcmgt.4s	v6, v6, v7
	mvni.4s	v7, #127, msl #16
	fneg.4s	v7, v7
	bit.16b	v1, v7, v6
	fmov.4s	v6, #0.25000000
	fdiv.4s	v6, v6, v1
	fsub.4s	v7, v1, v6
	fadd.4s	v1, v1, v6
	fdiv.4s	v1, v7, v1
	bif.16b	v1, v4, v5
	bit.16b	v1, v3, v21
	mvni.4s	v3, #128, lsl #24
	bif.16b	v1, v0, v3
	fcmeq.4s	v0, v0, v0
	fadd.4s	v1, v1, v4
	mvni.4s	v3, #63, msl #16
	fneg.4s	v3, v3
	bsl.16b	v0, v1, v3
	fmul.4s	v0, v2, v0
	ldr	s1, [x21, x20]
	fadd.4s	v0, v1, v0
LBB1_7:                                 ; %common.ret
	str	s0, [x19, x20]
	add	sp, sp, #8, lsl #12             ; =32768
	add	sp, sp, #368
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #144            ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB2_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB2_4
LBB2_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB2_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB2_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB2_13
LBB2_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB2_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB2_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #1
	b.eq	LBB2_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #2
	b.eq	LBB2_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #3
	b.eq	LBB2_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB2_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB2_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
LBB2_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB2_3
LBB2_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB2_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

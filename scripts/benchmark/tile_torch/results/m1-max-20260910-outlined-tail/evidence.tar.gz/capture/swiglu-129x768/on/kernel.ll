; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [3072 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [3072 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot5 = alloca i64, align 8
  store i64 0, ptr %.slot5, align 4
  %tile_snapshot.spill6 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill6, align 64
  %.slot7 = alloca i64, align 8
  store i64 0, ptr %.slot7, align 4
  %.slot8 = alloca i64, align 8
  store i64 0, ptr %.slot8, align 4
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert9 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat10 = shufflevector <8 x i32> %.splatinsert9, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat10, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert11 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat12 = shufflevector <8 x i32> %.splatinsert11, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat12, %41
  %44 = mul i32 %32, 1
  %.splatinsert13 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat14 = shufflevector <8 x i32> %.splatinsert13, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat14, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert15 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat16 = shufflevector <8 x i32> %.splatinsert15, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat16, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert17 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat18 = shufflevector <8 x i32> %.splatinsert17, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat18
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load <8 x i64>, ptr %.spill4, align 64
  %65 = select <8 x i1> %51, <8 x i64> %63, <8 x i64> %64
  store <8 x i64> %65, ptr %.spill4, align 64
  %66 = extractvalue { ptr, i64 } %9, 1
  %67 = extractvalue { ptr, i64 } %9, 0
  %68 = ptrtoint ptr %67 to i64
  %69 = extractvalue { ptr, i64 } %27, 1
  %70 = extractvalue { ptr, i64 } %27, 0
  %71 = ptrtoint ptr %70 to i64
  %72 = icmp uge i64 %68, %71
  %73 = sub i64 %68, %71
  %74 = icmp uge i64 %73, 396288
  %75 = and i1 %72, %74
  %76 = icmp uge i64 %71, %68
  %77 = sub i64 %71, %68
  %78 = icmp uge i64 %77, 396288
  %79 = and i1 %76, %78
  %80 = or i1 %75, %79
  %81 = and i1 true, %80
  %82 = extractvalue { ptr, i64 } %15, 1
  %83 = extractvalue { ptr, i64 } %15, 0
  %84 = ptrtoint ptr %83 to i64
  %85 = icmp uge i64 %84, %71
  %86 = sub i64 %84, %71
  %87 = icmp uge i64 %86, 396288
  %88 = and i1 %85, %87
  %89 = icmp uge i64 %71, %84
  %90 = sub i64 %71, %84
  %91 = icmp uge i64 %90, 396288
  %92 = and i1 %89, %91
  %93 = or i1 %88, %92
  %94 = and i1 %81, %93
  br i1 %94, label %direct.true, label %direct.false

direct.schedule.1:                                ; preds = %direct.true
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.2

direct.schedule.2:                                ; preds = %direct.schedule.3, %direct.schedule.1
  %.state = load i64, ptr %.slot, align 4
  %95 = icmp slt i64 %.state, 96
  br i1 %95, label %direct.true19, label %direct.false20

direct.schedule.3:                                ; preds = %direct.true19
  %.state21 = load i64, ptr %.slot, align 4
  %96 = mul i64 %.state21, 8
  %.splatinsert22 = insertelement <8 x i64> poison, i64 %96, i64 0
  %.splat23 = shufflevector <8 x i64> %.splatinsert22, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %97 = add <8 x i64> %.splat23, %.spill.load
  %.spill.load24 = load <8 x i64>, ptr %.spill4, align 64
  %98 = add <8 x i64> %.spill.load24, zeroinitializer
  %99 = add <8 x i64> zeroinitializer, %98
  %100 = add <8 x i64> zeroinitializer, %97
  %101 = mul <8 x i64> %99, splat (i64 768)
  %102 = add <8 x i64> %101, %100
  %103 = extractvalue { ptr, i64 } %9, 0
  %104 = extractelement <8 x i64> %102, i32 0
  %105 = sub i64 %104, 0
  %106 = mul i64 %105, 4
  %buffer.contiguous.address = getelementptr i8, ptr %103, i64 %106
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address, <8 x i1> %51, <8 x float> zeroinitializer)
  %107 = fneg <8 x float> %buffer.contiguous.load
  %108 = select <8 x i1> %51, <8 x float> %107, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %108)
  %109 = fadd <8 x float> splat (float 1.000000e+00), %native.exp
  %110 = fdiv <8 x float> %buffer.contiguous.load, %109
  %111 = extractvalue { ptr, i64 } %15, 0
  %112 = extractelement <8 x i64> %102, i32 0
  %113 = sub i64 %112, 0
  %114 = mul i64 %113, 4
  %buffer.contiguous.address25 = getelementptr i8, ptr %111, i64 %114
  %buffer.contiguous.load26 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address25, <8 x i1> %51, <8 x float> zeroinitializer)
  %115 = fmul <8 x float> %110, %buffer.contiguous.load26
  %116 = extractvalue { ptr, i64 } %27, 0
  %117 = extractelement <8 x i64> %102, i32 0
  %118 = sub i64 %117, 0
  %119 = mul i64 %118, 4
  %buffer.contiguous.address27 = getelementptr i8, ptr %116, i64 %119
  call void @llvm.masked.store.v8f32.p0(<8 x float> %115, ptr align 1 %buffer.contiguous.address27, <8 x i1> %51)
  %.state28 = load i64, ptr %.slot, align 4
  %120 = add i64 %.state28, 1
  store i64 %120, ptr %.slot, align 4
  br label %direct.schedule.2

direct.schedule.4:                                ; preds = %direct.false62, %direct.false20
  ret void

direct.schedule.5:                                ; preds = %direct.false
  %121 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %123 = extractvalue { <8 x ptr>, <8 x i64> } %121, 0
  %124 = select <8 x i1> %51, <8 x ptr> %122, <8 x ptr> %123
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %121, 1
  %127 = select <8 x i1> %51, <8 x i64> %125, <8 x i64> %126
  %128 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %124, 0
  %129 = insertvalue { <8 x ptr>, <8 x i64> } %128, <8 x i64> %127, 1
  store { <8 x ptr>, <8 x i64> } %129, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot5, align 4
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.7, %direct.schedule.5
  %.state29 = load i64, ptr %.slot5, align 4
  %130 = icmp slt i64 %.state29, 96
  br i1 %130, label %direct.true30, label %direct.false31

direct.schedule.7:                                ; preds = %direct.true30
  %.state32 = load i64, ptr %.slot5, align 4
  %131 = mul i64 %.state32, 8
  %.splatinsert33 = insertelement <8 x i64> poison, i64 %131, i64 0
  %.splat34 = shufflevector <8 x i64> %.splatinsert33, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load35 = load <8 x i64>, ptr %.spill, align 64
  %132 = add <8 x i64> %.splat34, %.spill.load35
  %.spill.load36 = load <8 x i64>, ptr %.spill4, align 64
  %133 = add <8 x i64> %.spill.load36, zeroinitializer
  %134 = add <8 x i64> zeroinitializer, %133
  %135 = add <8 x i64> zeroinitializer, %132
  %136 = mul <8 x i64> %134, splat (i64 768)
  %137 = add <8 x i64> %136, %135
  %138 = extractvalue { ptr, i64 } %9, 0
  %139 = extractelement <8 x i64> %137, i32 0
  %140 = sub i64 %139, 0
  %141 = mul i64 %140, 4
  %buffer.contiguous.address37 = getelementptr i8, ptr %138, i64 %141
  %buffer.contiguous.load38 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address37, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %143 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state39 = load i64, ptr %.slot5, align 4
  %.splatinsert40 = insertelement <8 x i64> poison, i64 %.state39, i64 0
  %.splat41 = shufflevector <8 x i64> %.splatinsert40, <8 x i64> poison, <8 x i32> zeroinitializer
  %144 = mul <8 x i64> %.splat41, splat (i64 32)
  %145 = add <8 x i64> %143, %144
  %146 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %142, 0
  %147 = insertvalue { <8 x ptr>, <8 x i64> } %146, <8 x i64> %145, 1
  %148 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %147, 1
  %150 = extractelement <8 x ptr> %148, i32 0
  %151 = extractelement <8 x i64> %149, i32 0
  %152 = sub i64 %151, 0
  %153 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %154 = select i1 %153, i64 %152, i64 0
  %private.contiguous.address = getelementptr i8, ptr %150, i64 %154
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %155 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load38, <8 x float> %private.contiguous.preserve
  store <8 x float> %155, ptr %private.contiguous.address, align 4
  %.state42 = load i64, ptr %.slot5, align 4
  %156 = add i64 %.state42, 1
  store i64 %156, ptr %.slot5, align 4
  br label %direct.schedule.6

direct.schedule.8:                                ; preds = %direct.false31
  %157 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %158 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %159 = extractvalue { <8 x ptr>, <8 x i64> } %157, 0
  %160 = select <8 x i1> %51, <8 x ptr> %158, <8 x ptr> %159
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %157, 1
  %163 = select <8 x i1> %51, <8 x i64> %161, <8 x i64> %162
  %164 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %160, 0
  %165 = insertvalue { <8 x ptr>, <8 x i64> } %164, <8 x i64> %163, 1
  store { <8 x ptr>, <8 x i64> } %165, ptr %tile_snapshot.spill6, align 64
  store i64 0, ptr %.slot7, align 4
  br label %direct.schedule.9

direct.schedule.9:                                ; preds = %direct.schedule.10, %direct.schedule.8
  %.state43 = load i64, ptr %.slot7, align 4
  %166 = icmp slt i64 %.state43, 96
  br i1 %166, label %direct.true44, label %direct.false45

direct.schedule.10:                               ; preds = %direct.true44
  %.state46 = load i64, ptr %.slot7, align 4
  %167 = mul i64 %.state46, 8
  %.splatinsert47 = insertelement <8 x i64> poison, i64 %167, i64 0
  %.splat48 = shufflevector <8 x i64> %.splatinsert47, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load49 = load <8 x i64>, ptr %.spill, align 64
  %168 = add <8 x i64> %.splat48, %.spill.load49
  %.spill.load50 = load <8 x i64>, ptr %.spill4, align 64
  %169 = add <8 x i64> %.spill.load50, zeroinitializer
  %170 = add <8 x i64> zeroinitializer, %169
  %171 = add <8 x i64> zeroinitializer, %168
  %172 = mul <8 x i64> %170, splat (i64 768)
  %173 = add <8 x i64> %172, %171
  %174 = extractvalue { ptr, i64 } %15, 0
  %175 = extractelement <8 x i64> %173, i32 0
  %176 = sub i64 %175, 0
  %177 = mul i64 %176, 4
  %buffer.contiguous.address51 = getelementptr i8, ptr %174, i64 %177
  %buffer.contiguous.load52 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address51, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load53 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %178 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 0
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 1
  %.state54 = load i64, ptr %.slot7, align 4
  %.splatinsert55 = insertelement <8 x i64> poison, i64 %.state54, i64 0
  %.splat56 = shufflevector <8 x i64> %.splatinsert55, <8 x i64> poison, <8 x i32> zeroinitializer
  %180 = mul <8 x i64> %.splat56, splat (i64 32)
  %181 = add <8 x i64> %179, %180
  %182 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %178, 0
  %183 = insertvalue { <8 x ptr>, <8 x i64> } %182, <8 x i64> %181, 1
  %184 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %185 = extractvalue { <8 x ptr>, <8 x i64> } %183, 1
  %186 = extractelement <8 x ptr> %184, i32 0
  %187 = extractelement <8 x i64> %185, i32 0
  %188 = sub i64 %187, 0
  %189 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %190 = select i1 %189, i64 %188, i64 0
  %private.contiguous.address57 = getelementptr i8, ptr %186, i64 %190
  %private.contiguous.preserve58 = load <8 x float>, ptr %private.contiguous.address57, align 4
  %191 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load52, <8 x float> %private.contiguous.preserve58
  store <8 x float> %191, ptr %private.contiguous.address57, align 4
  %.state59 = load i64, ptr %.slot7, align 4
  %192 = add i64 %.state59, 1
  store i64 %192, ptr %.slot7, align 4
  br label %direct.schedule.9

direct.schedule.11:                               ; preds = %direct.false45
  store i64 0, ptr %.slot8, align 4
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.schedule.13, %direct.schedule.11
  %.state60 = load i64, ptr %.slot8, align 4
  %193 = icmp slt i64 %.state60, 96
  br i1 %193, label %direct.true61, label %direct.false62

direct.schedule.13:                               ; preds = %direct.true61
  %.state63 = load i64, ptr %.slot8, align 4
  %194 = mul i64 %.state63, 8
  %.splatinsert64 = insertelement <8 x i64> poison, i64 %194, i64 0
  %.splat65 = shufflevector <8 x i64> %.splatinsert64, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load66 = load <8 x i64>, ptr %.spill, align 64
  %195 = add <8 x i64> %.splat65, %.spill.load66
  %.spill.load67 = load <8 x i64>, ptr %.spill4, align 64
  %196 = add <8 x i64> %.spill.load67, zeroinitializer
  %197 = add <8 x i64> zeroinitializer, %196
  %198 = add <8 x i64> zeroinitializer, %195
  %199 = mul <8 x i64> %197, splat (i64 768)
  %200 = add <8 x i64> %199, %198
  %tile_snapshot.spill.load68 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %201 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load68, 0
  %202 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load68, 1
  %.state69 = load i64, ptr %.slot8, align 4
  %.splatinsert70 = insertelement <8 x i64> poison, i64 %.state69, i64 0
  %.splat71 = shufflevector <8 x i64> %.splatinsert70, <8 x i64> poison, <8 x i32> zeroinitializer
  %203 = mul <8 x i64> %.splat71, splat (i64 32)
  %204 = add <8 x i64> %202, %203
  %205 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %201, 0
  %206 = insertvalue { <8 x ptr>, <8 x i64> } %205, <8 x i64> %204, 1
  %207 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %206, 1
  %209 = extractelement <8 x ptr> %207, i32 0
  %210 = extractelement <8 x i64> %208, i32 0
  %211 = sub i64 %210, 0
  %212 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %213 = select i1 %212, i64 %211, i64 0
  %private.contiguous.address72 = getelementptr i8, ptr %209, i64 %213
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address72, align 4
  %214 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %215 = fneg <8 x float> %214
  %216 = select <8 x i1> %51, <8 x float> %215, <8 x float> zeroinitializer
  %native.exp73 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %216)
  %217 = fadd <8 x float> splat (float 1.000000e+00), %native.exp73
  %218 = fdiv <8 x float> %214, %217
  %tile_snapshot.spill.load74 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %219 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load74, 0
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load74, 1
  %.state75 = load i64, ptr %.slot8, align 4
  %.splatinsert76 = insertelement <8 x i64> poison, i64 %.state75, i64 0
  %.splat77 = shufflevector <8 x i64> %.splatinsert76, <8 x i64> poison, <8 x i32> zeroinitializer
  %221 = mul <8 x i64> %.splat77, splat (i64 32)
  %222 = add <8 x i64> %220, %221
  %223 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %219, 0
  %224 = insertvalue { <8 x ptr>, <8 x i64> } %223, <8 x i64> %222, 1
  %225 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %224, 1
  %227 = extractelement <8 x ptr> %225, i32 0
  %228 = extractelement <8 x i64> %226, i32 0
  %229 = sub i64 %228, 0
  %230 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %231 = select i1 %230, i64 %229, i64 0
  %private.contiguous.address78 = getelementptr i8, ptr %227, i64 %231
  %private.contiguous.load79 = load <8 x float>, ptr %private.contiguous.address78, align 4
  %232 = select <8 x i1> %51, <8 x float> %private.contiguous.load79, <8 x float> zeroinitializer
  %233 = fmul <8 x float> %218, %232
  %234 = extractvalue { ptr, i64 } %27, 0
  %235 = extractelement <8 x i64> %200, i32 0
  %236 = sub i64 %235, 0
  %237 = mul i64 %236, 4
  %buffer.contiguous.address80 = getelementptr i8, ptr %234, i64 %237
  call void @llvm.masked.store.v8f32.p0(<8 x float> %233, ptr align 1 %buffer.contiguous.address80, <8 x i1> %51)
  %.state81 = load i64, ptr %.slot8, align 4
  %238 = add i64 %.state81, 1
  store i64 %238, ptr %.slot8, align 4
  br label %direct.schedule.12

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.0
  br label %direct.schedule.1

direct.false:                                     ; preds = %direct.schedule.0
  br label %direct.schedule.5

direct.true19:                                    ; preds = %direct.schedule.2
  br label %direct.schedule.3

direct.false20:                                   ; preds = %direct.schedule.2
  br label %direct.schedule.4

direct.true30:                                    ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false31:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.8

direct.true44:                                    ; preds = %direct.schedule.9
  br label %direct.schedule.10

direct.false45:                                   ; preds = %direct.schedule.9
  br label %direct.schedule.11

direct.true61:                                    ; preds = %direct.schedule.12
  br label %direct.schedule.13

direct.false62:                                   ; preds = %direct.schedule.12
  br label %direct.schedule.4
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), <8 x i1>, <8 x float>) #1

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #2 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), <8 x i1>) #3

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %tile_snapshot.local = alloca [3072 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [3072 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot5 = alloca i64, align 8
  store i64 0, ptr %.slot5, align 4
  %tile_snapshot.spill6 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill6, align 64
  %.slot7 = alloca i64, align 8
  store i64 0, ptr %.slot7, align 4
  %.slot8 = alloca i64, align 8
  store i64 0, ptr %.slot8, align 4
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert9 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat10 = shufflevector <8 x i32> %.splatinsert9, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat10, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert11 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat12 = shufflevector <8 x i32> %.splatinsert11, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat12, %41
  %44 = mul i32 %32, 1
  %.splatinsert13 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat14 = shufflevector <8 x i32> %.splatinsert13, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat14, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert15 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat16 = shufflevector <8 x i32> %.splatinsert15, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat16, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert17 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat18 = shufflevector <8 x i32> %.splatinsert17, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat18
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load <8 x i64>, ptr %.spill4, align 64
  %65 = select <8 x i1> %51, <8 x i64> %63, <8 x i64> %64
  store <8 x i64> %65, ptr %.spill4, align 64
  %66 = extractvalue { ptr, i64 } %9, 1
  %67 = extractvalue { ptr, i64 } %9, 0
  %68 = ptrtoint ptr %67 to i64
  %69 = extractvalue { ptr, i64 } %27, 1
  %70 = extractvalue { ptr, i64 } %27, 0
  %71 = ptrtoint ptr %70 to i64
  %72 = icmp uge i64 %68, %71
  %73 = sub i64 %68, %71
  %74 = icmp uge i64 %73, 396288
  %75 = and i1 %72, %74
  %76 = icmp uge i64 %71, %68
  %77 = sub i64 %71, %68
  %78 = icmp uge i64 %77, 396288
  %79 = and i1 %76, %78
  %80 = or i1 %75, %79
  %81 = and i1 true, %80
  %82 = extractvalue { ptr, i64 } %15, 1
  %83 = extractvalue { ptr, i64 } %15, 0
  %84 = ptrtoint ptr %83 to i64
  %85 = icmp uge i64 %84, %71
  %86 = sub i64 %84, %71
  %87 = icmp uge i64 %86, 396288
  %88 = and i1 %85, %87
  %89 = icmp uge i64 %71, %84
  %90 = sub i64 %71, %84
  %91 = icmp uge i64 %90, 396288
  %92 = and i1 %89, %91
  %93 = or i1 %88, %92
  %94 = and i1 %81, %93
  br i1 %94, label %direct.true, label %direct.false

direct.schedule.1:                                ; preds = %direct.true
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.2

direct.schedule.2:                                ; preds = %direct.schedule.3, %direct.schedule.1
  %.state = load i64, ptr %.slot, align 4
  %95 = icmp slt i64 %.state, 96
  br i1 %95, label %direct.true19, label %direct.false20

direct.schedule.3:                                ; preds = %direct.true19
  %.state21 = load i64, ptr %.slot, align 4
  %96 = mul i64 %.state21, 8
  %.splatinsert22 = insertelement <8 x i64> poison, i64 %96, i64 0
  %.splat23 = shufflevector <8 x i64> %.splatinsert22, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %97 = add <8 x i64> %.splat23, %.spill.load
  %.spill.load24 = load <8 x i64>, ptr %.spill4, align 64
  %98 = add <8 x i64> %.spill.load24, zeroinitializer
  %99 = add <8 x i64> zeroinitializer, %98
  %100 = add <8 x i64> zeroinitializer, %97
  %101 = mul <8 x i64> %99, splat (i64 768)
  %102 = add <8 x i64> %101, %100
  %103 = extractvalue { ptr, i64 } %9, 0
  %104 = extractelement <8 x i64> %102, i32 0
  %105 = sub i64 %104, 0
  %106 = mul i64 %105, 4
  %buffer.contiguous.address = getelementptr i8, ptr %103, i64 %106
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address, <8 x i1> %51, <8 x float> zeroinitializer)
  %107 = fneg <8 x float> %buffer.contiguous.load
  %108 = select <8 x i1> %51, <8 x float> %107, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %108)
  %109 = fadd <8 x float> splat (float 1.000000e+00), %native.exp
  %110 = fdiv <8 x float> %buffer.contiguous.load, %109
  %111 = extractvalue { ptr, i64 } %15, 0
  %112 = extractelement <8 x i64> %102, i32 0
  %113 = sub i64 %112, 0
  %114 = mul i64 %113, 4
  %buffer.contiguous.address25 = getelementptr i8, ptr %111, i64 %114
  %buffer.contiguous.load26 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address25, <8 x i1> %51, <8 x float> zeroinitializer)
  %115 = fmul <8 x float> %110, %buffer.contiguous.load26
  %116 = extractvalue { ptr, i64 } %27, 0
  %117 = extractelement <8 x i64> %102, i32 0
  %118 = sub i64 %117, 0
  %119 = mul i64 %118, 4
  %buffer.contiguous.address27 = getelementptr i8, ptr %116, i64 %119
  call void @llvm.masked.store.v8f32.p0(<8 x float> %115, ptr align 1 %buffer.contiguous.address27, <8 x i1> %51)
  %.state28 = load i64, ptr %.slot, align 4
  %120 = add i64 %.state28, 1
  store i64 %120, ptr %.slot, align 4
  br label %direct.schedule.2

direct.schedule.4:                                ; preds = %direct.false62, %direct.false20
  ret void

direct.schedule.5:                                ; preds = %direct.false
  %121 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %123 = extractvalue { <8 x ptr>, <8 x i64> } %121, 0
  %124 = select <8 x i1> %51, <8 x ptr> %122, <8 x ptr> %123
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %121, 1
  %127 = select <8 x i1> %51, <8 x i64> %125, <8 x i64> %126
  %128 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %124, 0
  %129 = insertvalue { <8 x ptr>, <8 x i64> } %128, <8 x i64> %127, 1
  store { <8 x ptr>, <8 x i64> } %129, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot5, align 4
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.7, %direct.schedule.5
  %.state29 = load i64, ptr %.slot5, align 4
  %130 = icmp slt i64 %.state29, 96
  br i1 %130, label %direct.true30, label %direct.false31

direct.schedule.7:                                ; preds = %direct.true30
  %.state32 = load i64, ptr %.slot5, align 4
  %131 = mul i64 %.state32, 8
  %.splatinsert33 = insertelement <8 x i64> poison, i64 %131, i64 0
  %.splat34 = shufflevector <8 x i64> %.splatinsert33, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load35 = load <8 x i64>, ptr %.spill, align 64
  %132 = add <8 x i64> %.splat34, %.spill.load35
  %.spill.load36 = load <8 x i64>, ptr %.spill4, align 64
  %133 = add <8 x i64> %.spill.load36, zeroinitializer
  %134 = add <8 x i64> zeroinitializer, %133
  %135 = add <8 x i64> zeroinitializer, %132
  %136 = mul <8 x i64> %134, splat (i64 768)
  %137 = add <8 x i64> %136, %135
  %138 = extractvalue { ptr, i64 } %9, 0
  %139 = extractelement <8 x i64> %137, i32 0
  %140 = sub i64 %139, 0
  %141 = mul i64 %140, 4
  %buffer.contiguous.address37 = getelementptr i8, ptr %138, i64 %141
  %buffer.contiguous.load38 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address37, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %143 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state39 = load i64, ptr %.slot5, align 4
  %.splatinsert40 = insertelement <8 x i64> poison, i64 %.state39, i64 0
  %.splat41 = shufflevector <8 x i64> %.splatinsert40, <8 x i64> poison, <8 x i32> zeroinitializer
  %144 = mul <8 x i64> %.splat41, splat (i64 32)
  %145 = add <8 x i64> %143, %144
  %146 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %142, 0
  %147 = insertvalue { <8 x ptr>, <8 x i64> } %146, <8 x i64> %145, 1
  %148 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %147, 1
  %150 = extractelement <8 x ptr> %148, i32 0
  %151 = extractelement <8 x i64> %149, i32 0
  %152 = sub i64 %151, 0
  %153 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %154 = select i1 %153, i64 %152, i64 0
  %private.contiguous.address = getelementptr i8, ptr %150, i64 %154
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %155 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load38, <8 x float> %private.contiguous.preserve
  store <8 x float> %155, ptr %private.contiguous.address, align 4
  %.state42 = load i64, ptr %.slot5, align 4
  %156 = add i64 %.state42, 1
  store i64 %156, ptr %.slot5, align 4
  br label %direct.schedule.6

direct.schedule.8:                                ; preds = %direct.false31
  %157 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %158 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %159 = extractvalue { <8 x ptr>, <8 x i64> } %157, 0
  %160 = select <8 x i1> %51, <8 x ptr> %158, <8 x ptr> %159
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %157, 1
  %163 = select <8 x i1> %51, <8 x i64> %161, <8 x i64> %162
  %164 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %160, 0
  %165 = insertvalue { <8 x ptr>, <8 x i64> } %164, <8 x i64> %163, 1
  store { <8 x ptr>, <8 x i64> } %165, ptr %tile_snapshot.spill6, align 64
  store i64 0, ptr %.slot7, align 4
  br label %direct.schedule.9

direct.schedule.9:                                ; preds = %direct.schedule.10, %direct.schedule.8
  %.state43 = load i64, ptr %.slot7, align 4
  %166 = icmp slt i64 %.state43, 96
  br i1 %166, label %direct.true44, label %direct.false45

direct.schedule.10:                               ; preds = %direct.true44
  %.state46 = load i64, ptr %.slot7, align 4
  %167 = mul i64 %.state46, 8
  %.splatinsert47 = insertelement <8 x i64> poison, i64 %167, i64 0
  %.splat48 = shufflevector <8 x i64> %.splatinsert47, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load49 = load <8 x i64>, ptr %.spill, align 64
  %168 = add <8 x i64> %.splat48, %.spill.load49
  %.spill.load50 = load <8 x i64>, ptr %.spill4, align 64
  %169 = add <8 x i64> %.spill.load50, zeroinitializer
  %170 = add <8 x i64> zeroinitializer, %169
  %171 = add <8 x i64> zeroinitializer, %168
  %172 = mul <8 x i64> %170, splat (i64 768)
  %173 = add <8 x i64> %172, %171
  %174 = extractvalue { ptr, i64 } %15, 0
  %175 = extractelement <8 x i64> %173, i32 0
  %176 = sub i64 %175, 0
  %177 = mul i64 %176, 4
  %buffer.contiguous.address51 = getelementptr i8, ptr %174, i64 %177
  %buffer.contiguous.load52 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address51, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load53 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %178 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 0
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 1
  %.state54 = load i64, ptr %.slot7, align 4
  %.splatinsert55 = insertelement <8 x i64> poison, i64 %.state54, i64 0
  %.splat56 = shufflevector <8 x i64> %.splatinsert55, <8 x i64> poison, <8 x i32> zeroinitializer
  %180 = mul <8 x i64> %.splat56, splat (i64 32)
  %181 = add <8 x i64> %179, %180
  %182 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %178, 0
  %183 = insertvalue { <8 x ptr>, <8 x i64> } %182, <8 x i64> %181, 1
  %184 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %185 = extractvalue { <8 x ptr>, <8 x i64> } %183, 1
  %186 = extractelement <8 x ptr> %184, i32 0
  %187 = extractelement <8 x i64> %185, i32 0
  %188 = sub i64 %187, 0
  %189 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %190 = select i1 %189, i64 %188, i64 0
  %private.contiguous.address57 = getelementptr i8, ptr %186, i64 %190
  %private.contiguous.preserve58 = load <8 x float>, ptr %private.contiguous.address57, align 4
  %191 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load52, <8 x float> %private.contiguous.preserve58
  store <8 x float> %191, ptr %private.contiguous.address57, align 4
  %.state59 = load i64, ptr %.slot7, align 4
  %192 = add i64 %.state59, 1
  store i64 %192, ptr %.slot7, align 4
  br label %direct.schedule.9

direct.schedule.11:                               ; preds = %direct.false45
  store i64 0, ptr %.slot8, align 4
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.schedule.13, %direct.schedule.11
  %.state60 = load i64, ptr %.slot8, align 4
  %193 = icmp slt i64 %.state60, 96
  br i1 %193, label %direct.true61, label %direct.false62

direct.schedule.13:                               ; preds = %direct.true61
  %.state63 = load i64, ptr %.slot8, align 4
  %194 = mul i64 %.state63, 8
  %.splatinsert64 = insertelement <8 x i64> poison, i64 %194, i64 0
  %.splat65 = shufflevector <8 x i64> %.splatinsert64, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load66 = load <8 x i64>, ptr %.spill, align 64
  %195 = add <8 x i64> %.splat65, %.spill.load66
  %.spill.load67 = load <8 x i64>, ptr %.spill4, align 64
  %196 = add <8 x i64> %.spill.load67, zeroinitializer
  %197 = add <8 x i64> zeroinitializer, %196
  %198 = add <8 x i64> zeroinitializer, %195
  %199 = mul <8 x i64> %197, splat (i64 768)
  %200 = add <8 x i64> %199, %198
  %tile_snapshot.spill.load68 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %201 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load68, 0
  %202 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load68, 1
  %.state69 = load i64, ptr %.slot8, align 4
  %.splatinsert70 = insertelement <8 x i64> poison, i64 %.state69, i64 0
  %.splat71 = shufflevector <8 x i64> %.splatinsert70, <8 x i64> poison, <8 x i32> zeroinitializer
  %203 = mul <8 x i64> %.splat71, splat (i64 32)
  %204 = add <8 x i64> %202, %203
  %205 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %201, 0
  %206 = insertvalue { <8 x ptr>, <8 x i64> } %205, <8 x i64> %204, 1
  %207 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %206, 1
  %209 = extractelement <8 x ptr> %207, i32 0
  %210 = extractelement <8 x i64> %208, i32 0
  %211 = sub i64 %210, 0
  %212 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %213 = select i1 %212, i64 %211, i64 0
  %private.contiguous.address72 = getelementptr i8, ptr %209, i64 %213
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address72, align 4
  %214 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %215 = fneg <8 x float> %214
  %216 = select <8 x i1> %51, <8 x float> %215, <8 x float> zeroinitializer
  %native.exp73 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %216)
  %217 = fadd <8 x float> splat (float 1.000000e+00), %native.exp73
  %218 = fdiv <8 x float> %214, %217
  %tile_snapshot.spill.load74 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %219 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load74, 0
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load74, 1
  %.state75 = load i64, ptr %.slot8, align 4
  %.splatinsert76 = insertelement <8 x i64> poison, i64 %.state75, i64 0
  %.splat77 = shufflevector <8 x i64> %.splatinsert76, <8 x i64> poison, <8 x i32> zeroinitializer
  %221 = mul <8 x i64> %.splat77, splat (i64 32)
  %222 = add <8 x i64> %220, %221
  %223 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %219, 0
  %224 = insertvalue { <8 x ptr>, <8 x i64> } %223, <8 x i64> %222, 1
  %225 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %224, 1
  %227 = extractelement <8 x ptr> %225, i32 0
  %228 = extractelement <8 x i64> %226, i32 0
  %229 = sub i64 %228, 0
  %230 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %231 = select i1 %230, i64 %229, i64 0
  %private.contiguous.address78 = getelementptr i8, ptr %227, i64 %231
  %private.contiguous.load79 = load <8 x float>, ptr %private.contiguous.address78, align 4
  %232 = select <8 x i1> %51, <8 x float> %private.contiguous.load79, <8 x float> zeroinitializer
  %233 = fmul <8 x float> %218, %232
  %234 = extractvalue { ptr, i64 } %27, 0
  %235 = extractelement <8 x i64> %200, i32 0
  %236 = sub i64 %235, 0
  %237 = mul i64 %236, 4
  %buffer.contiguous.address80 = getelementptr i8, ptr %234, i64 %237
  call void @llvm.masked.store.v8f32.p0(<8 x float> %233, ptr align 1 %buffer.contiguous.address80, <8 x i1> %51)
  %.state81 = load i64, ptr %.slot8, align 4
  %238 = add i64 %.state81, 1
  store i64 %238, ptr %.slot8, align 4
  br label %direct.schedule.12

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.0
  br label %direct.schedule.1

direct.false:                                     ; preds = %direct.schedule.0
  br label %direct.schedule.5

direct.true19:                                    ; preds = %direct.schedule.2
  br label %direct.schedule.3

direct.false20:                                   ; preds = %direct.schedule.2
  br label %direct.schedule.4

direct.true30:                                    ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false31:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.8

direct.true44:                                    ; preds = %direct.schedule.9
  br label %direct.schedule.10

direct.false45:                                   ; preds = %direct.schedule.9
  br label %direct.schedule.11

direct.true61:                                    ; preds = %direct.schedule.12
  br label %direct.schedule.13

direct.false62:                                   ; preds = %direct.schedule.12
  br label %direct.schedule.4
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count) #4
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #4 = { noinline }

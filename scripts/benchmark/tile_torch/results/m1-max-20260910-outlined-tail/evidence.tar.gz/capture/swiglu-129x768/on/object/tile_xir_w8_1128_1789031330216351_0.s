	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	dup.4s	v1, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q2, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q0, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v0, v1, v0
	cmhi.4s	v1, v1, v2
	uzp1.8h	v2, v1, v0
	umaxv.8h	h3, v2
	fmov	w8, s3
	tbz	w8, #0, LBB0_107
; %bb.1:                                ; %direct.activate
	stp	d11, d10, [sp, #-48]!           ; 16-byte Folded Spill
	stp	d9, d8, [sp, #16]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #32]             ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #2064
	ldr	x12, [x0]
	ldr	x10, [x0, #16]
	ldr	x9, [x0, #48]
	ldr	w8, [x1]
	ldr	w11, [x1, #36]
	add	w8, w11, w8, lsl #5
	lsr	w8, w8, #3
	fmov	s3, w8
	and.16b	v3, v1, v3
	subs	x8, x12, x9
	cset	w11, hs
	lsr	x8, x8, #10
	cmp	x8, #386
	csel	w8, wzr, w11, ls
	subs	x11, x9, x12
	cset	w13, hs
	lsr	x11, x11, #10
	cmp	x11, #386
	csel	w11, wzr, w13, ls
	orr	w8, w8, w11
	subs	x11, x10, x9
	cset	w13, hs
	lsr	x11, x11, #10
	cmp	x11, #386
	csel	w11, wzr, w13, ls
	subs	x13, x9, x10
	cset	w14, hs
	lsr	x13, x13, #10
	cmp	x13, #386
	csel	w13, wzr, w14, ls
	orr	w13, w11, w13
	fmov	w11, s3
	mov	w14, #3072                      ; =0xc00
	umull	x11, w11, w14
	cmp	w8, #1
	ccmp	w13, #0, #4, eq
	adrp	x13, lCPI0_2@PAGE
	mov	x8, #0                          ; =0x0
	b.ne	LBB0_20
; %bb.2:                                ; %direct.schedule.6.preheader
	add	x12, x12, x11
	ldr	q3, [x13, lCPI0_2@PAGEOFF]
	and.16b	v2, v2, v3
	addv.8h	h2, v2
	fmov	w13, s2
	add	x14, sp, #3088
	b	LBB0_4
LBB0_3:                                 ; %else107
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x15, x14, x8
	stp	q3, q4, [x15]
	add	x8, x8, #32
	cmp	x8, #3072
	b.eq	LBB0_70
LBB0_4:                                 ; %direct.true30
                                        ; =>This Inner Loop Header: Depth=1
	add	x15, x12, x8
	add	x17, x14, x8
	ldr	q3, [x17]
	tbnz	w13, #0, LBB0_12
; %bb.5:                                ; %else86
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w16, w13, #0xff
	tbnz	w16, #1, LBB0_13
LBB0_6:                                 ; %else89
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w16, #2, LBB0_14
LBB0_7:                                 ; %else92
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w16, #3, LBB0_15
LBB0_8:                                 ; %else95
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	q4, [x17, #16]
	tbnz	w16, #4, LBB0_16
LBB0_9:                                 ; %else98
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w16, #5, LBB0_17
LBB0_10:                                ; %else101
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w16, #6, LBB0_18
LBB0_11:                                ; %else104
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w16, #7, LBB0_3
	b	LBB0_19
LBB0_12:                                ; %cond.load85
                                        ;   in Loop: Header=BB0_4 Depth=1
	ld1.s	{ v3 }[0], [x15]
	and	w16, w13, #0xff
	tbz	w16, #1, LBB0_6
LBB0_13:                                ; %cond.load88
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x0, x15, #4
	ld1.s	{ v3 }[1], [x0]
	tbz	w16, #2, LBB0_7
LBB0_14:                                ; %cond.load91
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x0, x15, #8
	ld1.s	{ v3 }[2], [x0]
	tbz	w16, #3, LBB0_8
LBB0_15:                                ; %cond.load94
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x0, x15, #12
	ld1.s	{ v3 }[3], [x0]
	ldr	q4, [x17, #16]
	tbz	w16, #4, LBB0_9
LBB0_16:                                ; %cond.load97
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x17, x15, #16
	ld1.s	{ v4 }[0], [x17]
	tbz	w16, #5, LBB0_10
LBB0_17:                                ; %cond.load100
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x17, x15, #20
	ld1.s	{ v4 }[1], [x17]
	tbz	w16, #6, LBB0_11
LBB0_18:                                ; %cond.load103
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x17, x15, #24
	ld1.s	{ v4 }[2], [x17]
	tbz	w16, #7, LBB0_3
LBB0_19:                                ; %cond.load106
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x15, x15, #28
	ld1.s	{ v4 }[3], [x15]
	b	LBB0_3
LBB0_20:                                ; %direct.true19.preheader
	add	x9, x9, x11
	add	x10, x10, x11
	add	x11, x12, x11
	ldr	q3, [x13, lCPI0_2@PAGEOFF]
	and.16b	v2, v2, v3
	addv.8h	h2, v2
	fmov	w12, s2
	mov	w13, #-1026555904               ; =0xc2d00000
	mov	w14, #1120403456                ; =0x42c80000
	mov	w15, #43579                     ; =0xaa3b
	movk	w15, #16312, lsl #16
	movi.4s	v3, #75, lsl #24
	mvni.4s	v4, #128, lsl #24
	mov	w16, #29184                     ; =0x7200
	movk	w16, #48945, lsl #16
	mov	w17, #48782                     ; =0xbe8e
	movk	w17, #46527, lsl #16
	mov	w0, #11226                      ; =0x2bda
	movk	w0, #14672, lsl #16
	mov	w1, #38601                      ; =0x96c9
	movk	w1, #15030, lsl #16
	mov	w2, #34982                      ; =0x88a6
	movk	w2, #15368, lsl #16
	mov	w3, #43642                      ; =0xaa7a
	movk	w3, #15658, lsl #16
	mov	w4, #43691                      ; =0xaaab
	movk	w4, #15914, lsl #16
	movi.4s	v5, #63, lsl #24
	fmov.4s	v6, #1.00000000
	mvni.4s	v7, #127, msl #16
	fneg.4s	v7, v7
	mvni.4s	v16, #63, msl #16
	fneg.4s	v16, v16
	b	LBB0_22
LBB0_21:                                ; %else83
                                        ;   in Loop: Header=BB0_22 Depth=1
	add	x8, x8, #32
	cmp	x8, #3072
	b.eq	LBB0_106
LBB0_22:                                ; %direct.true19
                                        ; =>This Inner Loop Header: Depth=1
	add	x5, x11, x8
	movi.2d	v18, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbnz	w12, #0, LBB0_48
; %bb.23:                               ; %else
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w6, w12, #0xff
	tbnz	w6, #1, LBB0_49
LBB0_24:                                ; %else23
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w6, #2, LBB0_50
LBB0_25:                                ; %else26
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w6, #3, LBB0_51
LBB0_26:                                ; %else29
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w6, #4, LBB0_52
LBB0_27:                                ; %else32
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w6, #5, LBB0_53
LBB0_28:                                ; %else35
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w6, #6, LBB0_54
LBB0_29:                                ; %else38
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w6, #7, LBB0_55
LBB0_30:                                ; %else41
                                        ;   in Loop: Header=BB0_22 Depth=1
	fmov	w6, s2
	add	x5, x10, x8
	movi.2d	v20, #0000000000000000
	movi.2d	v19, #0000000000000000
	tbnz	w6, #0, LBB0_56
LBB0_31:                                ; %else45
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w6, w6, #0xff
	tbnz	w6, #1, LBB0_57
LBB0_32:                                ; %else48
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w6, #2, LBB0_58
LBB0_33:                                ; %else51
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w6, #3, LBB0_59
LBB0_34:                                ; %else54
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w6, #4, LBB0_60
LBB0_35:                                ; %else57
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w6, #5, LBB0_61
LBB0_36:                                ; %else60
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w6, #6, LBB0_62
LBB0_37:                                ; %else63
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w6, #7, LBB0_39
LBB0_38:                                ; %cond.load65
                                        ;   in Loop: Header=BB0_22 Depth=1
	add	x5, x5, #28
	ld1.s	{ v19 }[3], [x5]
LBB0_39:                                ; %else66
                                        ;   in Loop: Header=BB0_22 Depth=1
	fneg.4s	v22, v18
	dup.4s	v21, w13
	and.16b	v31, v1, v22
	fcmge.4s	v23, v31, v21
	dup.4s	v22, w14
	fcmge.4s	v24, v22, v31
	and.16b	v23, v23, v24
	and.16b	v25, v23, v31
	dup.4s	v23, w15
	fmul.4s	v24, v25, v23
	mov.16b	v26, v4
	bsl.16b	v26, v3, v24
	fadd.4s	v24, v24, v26
	fsub.4s	v24, v24, v26
	fcvtzs.4s	v8, v24
	scvtf.4s	v26, v8
	dup.4s	v24, w16
	fmul.4s	v27, v26, v24
	fadd.4s	v27, v25, v27
	dup.4s	v25, w17
	fmul.4s	v28, v26, v25
	dup.4s	v26, w0
	fadd.4s	v9, v27, v28
	fmul.4s	v28, v9, v26
	dup.4s	v27, w1
	fadd.4s	v28, v28, v27
	fmul.4s	v29, v9, v28
	dup.4s	v28, w2
	fadd.4s	v29, v29, v28
	fmul.4s	v30, v9, v29
	dup.4s	v29, w3
	fadd.4s	v30, v30, v29
	fmul.4s	v10, v9, v30
	dup.4s	v30, w4
	fadd.4s	v10, v10, v30
	fmul.4s	v10, v9, v10
	fadd.4s	v10, v10, v5
	fmul.4s	v11, v9, v9
	fmul.4s	v10, v11, v10
	fadd.4s	v9, v9, v10
	fadd.4s	v9, v9, v6
	sshr.4s	v10, v8, #1
	shl.4s	v11, v10, #23
	add.4s	v11, v11, v6
	fmul.4s	v9, v9, v11
	sub.4s	v8, v8, v10
	shl.4s	v8, v8, #23
	add.4s	v8, v8, v6
	fmul.4s	v8, v9, v8
	fcmgt.4s	v9, v21, v31
	fcmgt.4s	v10, v31, v22
	fcmeq.4s	v31, v31, v31
	fadd.4s	v8, v8, v6
	bit.16b	v8, v6, v9
	bit.16b	v8, v7, v10
	bsl.16b	v31, v8, v16
	fdiv.4s	v18, v18, v31
	fmov	w6, s2
	fmul.4s	v18, v20, v18
	add	x5, x9, x8
	tbnz	w6, #0, LBB0_63
; %bb.40:                               ; %else69
                                        ;   in Loop: Header=BB0_22 Depth=1
	and	w6, w6, #0xff
	tbnz	w6, #1, LBB0_64
LBB0_41:                                ; %else71
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w6, #2, LBB0_65
LBB0_42:                                ; %else73
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w6, #3, LBB0_44
LBB0_43:                                ; %cond.store74
                                        ;   in Loop: Header=BB0_22 Depth=1
	add	x7, x5, #12
	st1.s	{ v18 }[3], [x7]
LBB0_44:                                ; %else75
                                        ;   in Loop: Header=BB0_22 Depth=1
	fneg.4s	v18, v17
	and.16b	v18, v0, v18
	fcmge.4s	v20, v18, v21
	fcmge.4s	v31, v22, v18
	and.16b	v20, v20, v31
	and.16b	v20, v20, v18
	fmul.4s	v23, v20, v23
	mov.16b	v31, v4
	bsl.16b	v31, v3, v23
	fadd.4s	v23, v23, v31
	fsub.4s	v23, v23, v31
	fcvtzs.4s	v23, v23
	scvtf.4s	v31, v23
	fmul.4s	v24, v31, v24
	fadd.4s	v20, v20, v24
	fmul.4s	v24, v31, v25
	fadd.4s	v20, v20, v24
	fmul.4s	v24, v20, v26
	fadd.4s	v24, v24, v27
	fmul.4s	v24, v20, v24
	fadd.4s	v24, v24, v28
	fmul.4s	v24, v20, v24
	fadd.4s	v24, v24, v29
	fmul.4s	v24, v20, v24
	fadd.4s	v24, v24, v30
	fmul.4s	v24, v20, v24
	fadd.4s	v24, v24, v5
	fmul.4s	v25, v20, v20
	fmul.4s	v24, v25, v24
	fadd.4s	v20, v20, v24
	fadd.4s	v20, v20, v6
	sshr.4s	v24, v23, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v6
	fmul.4s	v20, v20, v25
	sub.4s	v23, v23, v24
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v6
	fmul.4s	v20, v20, v23
	fcmgt.4s	v21, v21, v18
	fcmgt.4s	v22, v18, v22
	fcmeq.4s	v18, v18, v18
	fadd.4s	v20, v20, v6
	bit.16b	v20, v6, v21
	bit.16b	v20, v7, v22
	bsl.16b	v18, v20, v16
	fdiv.4s	v17, v17, v18
	fmul.4s	v17, v19, v17
	tbnz	w6, #4, LBB0_66
; %bb.45:                               ; %else77
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w6, #5, LBB0_67
LBB0_46:                                ; %else79
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbnz	w6, #6, LBB0_68
LBB0_47:                                ; %else81
                                        ;   in Loop: Header=BB0_22 Depth=1
	tbz	w6, #7, LBB0_21
	b	LBB0_69
LBB0_48:                                ; %cond.load
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	s18, [x5]
	and	w6, w12, #0xff
	tbz	w6, #1, LBB0_24
LBB0_49:                                ; %cond.load22
                                        ;   in Loop: Header=BB0_22 Depth=1
	add	x7, x5, #4
	ld1.s	{ v18 }[1], [x7]
	tbz	w6, #2, LBB0_25
LBB0_50:                                ; %cond.load25
                                        ;   in Loop: Header=BB0_22 Depth=1
	add	x7, x5, #8
	ld1.s	{ v18 }[2], [x7]
	tbz	w6, #3, LBB0_26
LBB0_51:                                ; %cond.load28
                                        ;   in Loop: Header=BB0_22 Depth=1
	add	x7, x5, #12
	ld1.s	{ v18 }[3], [x7]
	tbz	w6, #4, LBB0_27
LBB0_52:                                ; %cond.load31
                                        ;   in Loop: Header=BB0_22 Depth=1
	add	x7, x5, #16
	ld1.s	{ v17 }[0], [x7]
	tbz	w6, #5, LBB0_28
LBB0_53:                                ; %cond.load34
                                        ;   in Loop: Header=BB0_22 Depth=1
	add	x7, x5, #20
	ld1.s	{ v17 }[1], [x7]
	tbz	w6, #6, LBB0_29
LBB0_54:                                ; %cond.load37
                                        ;   in Loop: Header=BB0_22 Depth=1
	add	x7, x5, #24
	ld1.s	{ v17 }[2], [x7]
	tbz	w6, #7, LBB0_30
LBB0_55:                                ; %cond.load40
                                        ;   in Loop: Header=BB0_22 Depth=1
	add	x5, x5, #28
	ld1.s	{ v17 }[3], [x5]
	fmov	w6, s2
	add	x5, x10, x8
	movi.2d	v20, #0000000000000000
	movi.2d	v19, #0000000000000000
	tbz	w6, #0, LBB0_31
LBB0_56:                                ; %cond.load44
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	s20, [x5]
	and	w6, w6, #0xff
	tbz	w6, #1, LBB0_32
LBB0_57:                                ; %cond.load47
                                        ;   in Loop: Header=BB0_22 Depth=1
	add	x7, x5, #4
	ld1.s	{ v20 }[1], [x7]
	tbz	w6, #2, LBB0_33
LBB0_58:                                ; %cond.load50
                                        ;   in Loop: Header=BB0_22 Depth=1
	add	x7, x5, #8
	ld1.s	{ v20 }[2], [x7]
	tbz	w6, #3, LBB0_34
LBB0_59:                                ; %cond.load53
                                        ;   in Loop: Header=BB0_22 Depth=1
	add	x7, x5, #12
	ld1.s	{ v20 }[3], [x7]
	tbz	w6, #4, LBB0_35
LBB0_60:                                ; %cond.load56
                                        ;   in Loop: Header=BB0_22 Depth=1
	add	x7, x5, #16
	ld1.s	{ v19 }[0], [x7]
	tbz	w6, #5, LBB0_36
LBB0_61:                                ; %cond.load59
                                        ;   in Loop: Header=BB0_22 Depth=1
	add	x7, x5, #20
	ld1.s	{ v19 }[1], [x7]
	tbz	w6, #6, LBB0_37
LBB0_62:                                ; %cond.load62
                                        ;   in Loop: Header=BB0_22 Depth=1
	add	x7, x5, #24
	ld1.s	{ v19 }[2], [x7]
	tbnz	w6, #7, LBB0_38
	b	LBB0_39
LBB0_63:                                ; %cond.store
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	s18, [x5]
	and	w6, w6, #0xff
	tbz	w6, #1, LBB0_41
LBB0_64:                                ; %cond.store70
                                        ;   in Loop: Header=BB0_22 Depth=1
	add	x7, x5, #4
	st1.s	{ v18 }[1], [x7]
	tbz	w6, #2, LBB0_42
LBB0_65:                                ; %cond.store72
                                        ;   in Loop: Header=BB0_22 Depth=1
	add	x7, x5, #8
	st1.s	{ v18 }[2], [x7]
	tbnz	w6, #3, LBB0_43
	b	LBB0_44
LBB0_66:                                ; %cond.store76
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	s17, [x5, #16]
	tbz	w6, #5, LBB0_46
LBB0_67:                                ; %cond.store78
                                        ;   in Loop: Header=BB0_22 Depth=1
	add	x7, x5, #20
	st1.s	{ v17 }[1], [x7]
	tbz	w6, #6, LBB0_47
LBB0_68:                                ; %cond.store80
                                        ;   in Loop: Header=BB0_22 Depth=1
	add	x7, x5, #24
	st1.s	{ v17 }[2], [x7]
	tbz	w6, #7, LBB0_21
LBB0_69:                                ; %cond.store82
                                        ;   in Loop: Header=BB0_22 Depth=1
	add	x5, x5, #28
	st1.s	{ v17 }[3], [x5]
	b	LBB0_21
LBB0_70:                                ; %direct.schedule.9.preheader
	mov	x8, #0                          ; =0x0
	add	x10, x10, x11
	fmov	w12, s2
	add	x13, sp, #16
	b	LBB0_72
LBB0_71:                                ; %else132
                                        ;   in Loop: Header=BB0_72 Depth=1
	add	x14, x13, x8
	stp	q3, q4, [x14]
	add	x8, x8, #32
	cmp	x8, #3072
	b.eq	LBB0_88
LBB0_72:                                ; %direct.true44
                                        ; =>This Inner Loop Header: Depth=1
	add	x14, x10, x8
	add	x16, x13, x8
	ldr	q3, [x16]
	tbnz	w12, #0, LBB0_80
; %bb.73:                               ; %else111
                                        ;   in Loop: Header=BB0_72 Depth=1
	and	w15, w12, #0xff
	tbnz	w15, #1, LBB0_81
LBB0_74:                                ; %else114
                                        ;   in Loop: Header=BB0_72 Depth=1
	tbnz	w15, #2, LBB0_82
LBB0_75:                                ; %else117
                                        ;   in Loop: Header=BB0_72 Depth=1
	tbnz	w15, #3, LBB0_83
LBB0_76:                                ; %else120
                                        ;   in Loop: Header=BB0_72 Depth=1
	ldr	q4, [x16, #16]
	tbnz	w15, #4, LBB0_84
LBB0_77:                                ; %else123
                                        ;   in Loop: Header=BB0_72 Depth=1
	tbnz	w15, #5, LBB0_85
LBB0_78:                                ; %else126
                                        ;   in Loop: Header=BB0_72 Depth=1
	tbnz	w15, #6, LBB0_86
LBB0_79:                                ; %else129
                                        ;   in Loop: Header=BB0_72 Depth=1
	tbz	w15, #7, LBB0_71
	b	LBB0_87
LBB0_80:                                ; %cond.load110
                                        ;   in Loop: Header=BB0_72 Depth=1
	ld1.s	{ v3 }[0], [x14]
	and	w15, w12, #0xff
	tbz	w15, #1, LBB0_74
LBB0_81:                                ; %cond.load113
                                        ;   in Loop: Header=BB0_72 Depth=1
	add	x17, x14, #4
	ld1.s	{ v3 }[1], [x17]
	tbz	w15, #2, LBB0_75
LBB0_82:                                ; %cond.load116
                                        ;   in Loop: Header=BB0_72 Depth=1
	add	x17, x14, #8
	ld1.s	{ v3 }[2], [x17]
	tbz	w15, #3, LBB0_76
LBB0_83:                                ; %cond.load119
                                        ;   in Loop: Header=BB0_72 Depth=1
	add	x17, x14, #12
	ld1.s	{ v3 }[3], [x17]
	ldr	q4, [x16, #16]
	tbz	w15, #4, LBB0_77
LBB0_84:                                ; %cond.load122
                                        ;   in Loop: Header=BB0_72 Depth=1
	add	x16, x14, #16
	ld1.s	{ v4 }[0], [x16]
	tbz	w15, #5, LBB0_78
LBB0_85:                                ; %cond.load125
                                        ;   in Loop: Header=BB0_72 Depth=1
	add	x16, x14, #20
	ld1.s	{ v4 }[1], [x16]
	tbz	w15, #6, LBB0_79
LBB0_86:                                ; %cond.load128
                                        ;   in Loop: Header=BB0_72 Depth=1
	add	x16, x14, #24
	ld1.s	{ v4 }[2], [x16]
	tbz	w15, #7, LBB0_71
LBB0_87:                                ; %cond.load131
                                        ;   in Loop: Header=BB0_72 Depth=1
	add	x14, x14, #28
	ld1.s	{ v4 }[3], [x14]
	b	LBB0_71
LBB0_88:                                ; %direct.schedule.12.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x9, x11
	fmov	w10, s2
	add	x11, sp, #3088
	mov	w12, #-1026555904               ; =0xc2d00000
	dup.4s	v2, w12
	mov	w12, #1120403456                ; =0x42c80000
	dup.4s	v3, w12
	mov	w12, #43579                     ; =0xaa3b
	movk	w12, #16312, lsl #16
	dup.4s	v4, w12
	movi.4s	v5, #75, lsl #24
	mvni.4s	v6, #128, lsl #24
	mov	w12, #29184                     ; =0x7200
	movk	w12, #48945, lsl #16
	dup.4s	v7, w12
	mov	w12, #48782                     ; =0xbe8e
	movk	w12, #46527, lsl #16
	dup.4s	v16, w12
	mov	w12, #11226                     ; =0x2bda
	movk	w12, #14672, lsl #16
	dup.4s	v17, w12
	mov	w12, #38601                     ; =0x96c9
	movk	w12, #15030, lsl #16
	dup.4s	v18, w12
	mov	w12, #34982                     ; =0x88a6
	movk	w12, #15368, lsl #16
	dup.4s	v19, w12
	mov	w12, #43642                     ; =0xaa7a
	movk	w12, #15658, lsl #16
	dup.4s	v20, w12
	mov	w12, #43691                     ; =0xaaab
	movk	w12, #15914, lsl #16
	dup.4s	v21, w12
	movi.4s	v22, #63, lsl #24
	fmov.4s	v23, #1.00000000
	mvni.4s	v24, #127, msl #16
	fneg.4s	v24, v24
	mvni.4s	v25, #63, msl #16
	fneg.4s	v25, v25
	add	x12, sp, #16
	b	LBB0_90
LBB0_89:                                ; %else150
                                        ;   in Loop: Header=BB0_90 Depth=1
	add	x8, x8, #32
	cmp	x8, #3072
	b.eq	LBB0_106
LBB0_90:                                ; %direct.true61
                                        ; =>This Inner Loop Header: Depth=1
	add	x15, x11, x8
	ldr	q26, [x15]
	and.16b	v26, v1, v26
	fneg.4s	v27, v26
	and.16b	v27, v1, v27
	fcmge.4s	v28, v27, v2
	fcmge.4s	v29, v3, v27
	and.16b	v28, v28, v29
	and.16b	v28, v28, v27
	fmul.4s	v29, v28, v4
	mov.16b	v30, v6
	bsl.16b	v30, v5, v29
	fadd.4s	v29, v29, v30
	fsub.4s	v29, v29, v30
	fcvtzs.4s	v29, v29
	scvtf.4s	v30, v29
	fmul.4s	v31, v30, v7
	fadd.4s	v28, v28, v31
	fmul.4s	v30, v30, v16
	fadd.4s	v28, v28, v30
	fmul.4s	v30, v28, v17
	fadd.4s	v30, v30, v18
	fmul.4s	v30, v28, v30
	fadd.4s	v30, v30, v19
	fmul.4s	v30, v28, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v28, v30
	fadd.4s	v30, v30, v21
	fmul.4s	v30, v28, v30
	fadd.4s	v30, v30, v22
	fmul.4s	v31, v28, v28
	fmul.4s	v30, v31, v30
	fadd.4s	v28, v28, v30
	fadd.4s	v28, v28, v23
	sshr.4s	v30, v29, #1
	shl.4s	v31, v30, #23
	add.4s	v31, v31, v23
	fmul.4s	v28, v28, v31
	sub.4s	v29, v29, v30
	shl.4s	v29, v29, #23
	add.4s	v29, v29, v23
	fmul.4s	v28, v28, v29
	fcmgt.4s	v29, v2, v27
	fcmgt.4s	v30, v27, v3
	fcmeq.4s	v27, v27, v27
	fadd.4s	v28, v28, v23
	bit.16b	v28, v23, v29
	bit.16b	v28, v24, v30
	bsl.16b	v27, v28, v25
	fdiv.4s	v26, v26, v27
	add	x16, x12, x8
	ldr	q27, [x16]
	and.16b	v27, v1, v27
	fmul.4s	v26, v27, v26
	add	x13, x9, x8
	tbnz	w10, #0, LBB0_99
; %bb.91:                               ; %else136
                                        ;   in Loop: Header=BB0_90 Depth=1
	and	w14, w10, #0xff
	tbnz	w14, #1, LBB0_100
LBB0_92:                                ; %else138
                                        ;   in Loop: Header=BB0_90 Depth=1
	tbnz	w14, #2, LBB0_101
LBB0_93:                                ; %else140
                                        ;   in Loop: Header=BB0_90 Depth=1
	tbz	w14, #3, LBB0_95
LBB0_94:                                ; %cond.store141
                                        ;   in Loop: Header=BB0_90 Depth=1
	add	x17, x13, #12
	st1.s	{ v26 }[3], [x17]
LBB0_95:                                ; %else142
                                        ;   in Loop: Header=BB0_90 Depth=1
	ldr	q26, [x15, #16]
	and.16b	v26, v0, v26
	fneg.4s	v27, v26
	and.16b	v27, v0, v27
	fcmge.4s	v28, v27, v2
	fcmge.4s	v29, v3, v27
	and.16b	v28, v28, v29
	and.16b	v28, v28, v27
	fmul.4s	v29, v28, v4
	mov.16b	v30, v6
	bsl.16b	v30, v5, v29
	fadd.4s	v29, v29, v30
	fsub.4s	v29, v29, v30
	fcvtzs.4s	v29, v29
	scvtf.4s	v30, v29
	fmul.4s	v31, v30, v7
	fadd.4s	v28, v28, v31
	fmul.4s	v30, v30, v16
	fadd.4s	v28, v28, v30
	fmul.4s	v30, v28, v17
	fadd.4s	v30, v30, v18
	fmul.4s	v30, v28, v30
	fadd.4s	v30, v30, v19
	fmul.4s	v30, v28, v30
	fadd.4s	v30, v30, v20
	fmul.4s	v30, v28, v30
	fadd.4s	v30, v30, v21
	fmul.4s	v30, v28, v30
	fadd.4s	v30, v30, v22
	fmul.4s	v31, v28, v28
	fmul.4s	v30, v31, v30
	fadd.4s	v28, v28, v30
	fadd.4s	v28, v28, v23
	sshr.4s	v30, v29, #1
	shl.4s	v31, v30, #23
	add.4s	v31, v31, v23
	fmul.4s	v28, v28, v31
	sub.4s	v29, v29, v30
	shl.4s	v29, v29, #23
	add.4s	v29, v29, v23
	fmul.4s	v28, v28, v29
	fcmgt.4s	v29, v2, v27
	fcmgt.4s	v30, v27, v3
	fcmeq.4s	v27, v27, v27
	fadd.4s	v28, v28, v23
	bit.16b	v28, v23, v29
	bit.16b	v28, v24, v30
	bsl.16b	v27, v28, v25
	fdiv.4s	v26, v26, v27
	ldr	q27, [x16, #16]
	and.16b	v27, v0, v27
	fmul.4s	v26, v27, v26
	tbnz	w14, #4, LBB0_102
; %bb.96:                               ; %else144
                                        ;   in Loop: Header=BB0_90 Depth=1
	tbnz	w14, #5, LBB0_103
LBB0_97:                                ; %else146
                                        ;   in Loop: Header=BB0_90 Depth=1
	tbnz	w14, #6, LBB0_104
LBB0_98:                                ; %else148
                                        ;   in Loop: Header=BB0_90 Depth=1
	tbz	w14, #7, LBB0_89
	b	LBB0_105
LBB0_99:                                ; %cond.store135
                                        ;   in Loop: Header=BB0_90 Depth=1
	str	s26, [x13]
	and	w14, w10, #0xff
	tbz	w14, #1, LBB0_92
LBB0_100:                               ; %cond.store137
                                        ;   in Loop: Header=BB0_90 Depth=1
	add	x17, x13, #4
	st1.s	{ v26 }[1], [x17]
	tbz	w14, #2, LBB0_93
LBB0_101:                               ; %cond.store139
                                        ;   in Loop: Header=BB0_90 Depth=1
	add	x17, x13, #8
	st1.s	{ v26 }[2], [x17]
	tbnz	w14, #3, LBB0_94
	b	LBB0_95
LBB0_102:                               ; %cond.store143
                                        ;   in Loop: Header=BB0_90 Depth=1
	str	s26, [x13, #16]
	tbz	w14, #5, LBB0_97
LBB0_103:                               ; %cond.store145
                                        ;   in Loop: Header=BB0_90 Depth=1
	add	x15, x13, #20
	st1.s	{ v26 }[1], [x15]
	tbz	w14, #6, LBB0_98
LBB0_104:                               ; %cond.store147
                                        ;   in Loop: Header=BB0_90 Depth=1
	add	x15, x13, #24
	st1.s	{ v26 }[2], [x15]
	tbz	w14, #7, LBB0_89
LBB0_105:                               ; %cond.store149
                                        ;   in Loop: Header=BB0_90 Depth=1
	add	x13, x13, #28
	st1.s	{ v26 }[3], [x13]
	b	LBB0_89
LBB0_106:
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #2064
	ldp	x28, x27, [sp, #32]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp], #48             ; 16-byte Folded Reload
LBB0_107:                               ; %common.ret
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
                                        ; -- End function
	.p2align	2                               ; -- Begin function llm_rows.full_packet
_llm_rows.full_packet:                  ; @llm_rows.full_packet
; %bb.0:                                ; %prologue
	stp	d9, d8, [sp, #-80]!             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #2048
	ldr	x11, [x0]
	ldr	x22, [x0, #16]
	ldr	x21, [x0, #48]
	ldr	w8, [x1]
	ldr	w9, [x1, #36]
	add	w8, w9, w8, lsl #5
	lsr	w8, w8, #3
	subs	x9, x11, x21
	cset	w10, hs
	lsr	x9, x9, #10
	cmp	x9, #386
	csel	w9, wzr, w10, ls
	subs	x10, x21, x11
	cset	w12, hs
	lsr	x10, x10, #10
	cmp	x10, #386
	csel	w10, wzr, w12, ls
	orr	w9, w9, w10
	subs	x10, x22, x21
	cset	w12, hs
	lsr	x10, x10, #10
	cmp	x10, #386
	csel	w10, wzr, w12, ls
	subs	x12, x21, x22
	cset	w13, hs
	lsr	x12, x12, #10
	cmp	x12, #386
	csel	w12, wzr, w13, ls
	orr	w10, w10, w12
	mov	w12, #3072                      ; =0xc00
	umull	x23, w8, w12
	cmp	w9, #1
	ccmp	w10, #0, #4, eq
	b.ne	LBB1_3
; %bb.1:                                ; %direct.schedule.6.preheader
	add	x19, sp, #3072
	add	x0, sp, #3072
	add	x1, x11, x23
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	mov	x20, sp
	mov	x0, sp
	add	x1, x22, x23
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	mov	w9, #1120927744                 ; =0x42d00000
	dup.4s	v0, w9
	mov	w9, #-1027080192                ; =0xc2c80000
	dup.4s	v1, w9
	mov	w9, #43579                      ; =0xaa3b
	movk	w9, #16312, lsl #16
	dup.4s	v2, w9
	mov	w9, #29184                      ; =0x7200
	movk	w9, #48945, lsl #16
	dup.4s	v3, w9
	mov	w9, #48782                      ; =0xbe8e
	movk	w9, #46527, lsl #16
	dup.4s	v4, w9
	mov	w9, #11226                      ; =0x2bda
	movk	w9, #14672, lsl #16
	dup.4s	v5, w9
	mov	w9, #38601                      ; =0x96c9
	movk	w9, #15030, lsl #16
	dup.4s	v6, w9
	mov	w9, #34982                      ; =0x88a6
	movk	w9, #15368, lsl #16
	dup.4s	v7, w9
	mov	w9, #43642                      ; =0xaa7a
	movk	w9, #15658, lsl #16
	dup.4s	v16, w9
	add	x9, x21, x23
	mov	w10, #43691                     ; =0xaaab
	movk	w10, #15914, lsl #16
	dup.4s	v17, w10
	movi.4s	v18, #75, lsl #24
	mvni.4s	v19, #128, lsl #24
	movi.4s	v20, #63, lsl #24
	fmov.4s	v21, #1.00000000
	mvni.4s	v22, #127, msl #16
	fneg.4s	v22, v22
	mvni.4s	v23, #63, msl #16
	fneg.4s	v23, v23
LBB1_2:                                 ; %direct.true61
                                        ; =>This Inner Loop Header: Depth=1
	add	x10, x19, x8
	ldp	q24, q25, [x10]
	fneg.4s	v26, v25
	fneg.4s	v27, v24
	fcmge.4s	v28, v0, v24
	fcmge.4s	v29, v0, v25
	fcmge.4s	v30, v24, v1
	fcmge.4s	v31, v25, v1
	and.16b	v29, v29, v31
	and.16b	v28, v28, v30
	and.16b	v27, v28, v27
	and.16b	v26, v29, v26
	fmul.4s	v28, v26, v2
	fmul.4s	v29, v27, v2
	mov.16b	v30, v19
	bsl.16b	v30, v18, v29
	mov.16b	v31, v19
	bsl.16b	v31, v18, v28
	fadd.4s	v28, v28, v31
	fadd.4s	v29, v29, v30
	fsub.4s	v29, v29, v30
	fsub.4s	v28, v28, v31
	fcvtzs.4s	v28, v28
	fcvtzs.4s	v29, v29
	scvtf.4s	v30, v29
	scvtf.4s	v31, v28
	fmul.4s	v8, v31, v3
	fmul.4s	v9, v30, v3
	fadd.4s	v27, v27, v9
	fadd.4s	v26, v26, v8
	fmul.4s	v30, v30, v4
	fmul.4s	v31, v31, v4
	fadd.4s	v26, v26, v31
	fadd.4s	v27, v27, v30
	fmul.4s	v30, v27, v5
	fmul.4s	v31, v26, v5
	fadd.4s	v31, v31, v6
	fadd.4s	v30, v30, v6
	fmul.4s	v30, v27, v30
	fmul.4s	v31, v26, v31
	fadd.4s	v31, v31, v7
	fadd.4s	v30, v30, v7
	fmul.4s	v30, v27, v30
	fmul.4s	v31, v26, v31
	fadd.4s	v31, v31, v16
	fadd.4s	v30, v30, v16
	fmul.4s	v30, v27, v30
	fmul.4s	v31, v26, v31
	fadd.4s	v31, v31, v17
	fadd.4s	v30, v30, v17
	fmul.4s	v30, v27, v30
	fmul.4s	v31, v26, v31
	fadd.4s	v31, v31, v20
	fadd.4s	v30, v30, v20
	fmul.4s	v8, v26, v26
	fmul.4s	v9, v27, v27
	fmul.4s	v30, v9, v30
	fmul.4s	v31, v8, v31
	fadd.4s	v26, v26, v31
	fadd.4s	v27, v27, v30
	sshr.4s	v30, v29, #1
	fadd.4s	v27, v27, v21
	sshr.4s	v31, v28, #1
	shl.4s	v8, v31, #23
	shl.4s	v9, v30, #23
	add.4s	v9, v9, v21
	add.4s	v8, v8, v21
	fadd.4s	v26, v26, v21
	fmul.4s	v26, v26, v8
	sub.4s	v28, v28, v31
	sub.4s	v29, v29, v30
	shl.4s	v29, v29, #23
	shl.4s	v28, v28, #23
	fmul.4s	v27, v27, v9
	add.4s	v28, v28, v21
	add.4s	v29, v29, v21
	fmul.4s	v27, v27, v29
	fmul.4s	v26, v26, v28
	fcmgt.4s	v28, v25, v0
	fcmgt.4s	v29, v24, v0
	fcmgt.4s	v30, v1, v24
	fcmgt.4s	v31, v1, v25
	fcmeq.4s	v8, v25, v25
	fadd.4s	v26, v26, v21
	fadd.4s	v27, v27, v21
	fcmeq.4s	v9, v24, v24
	bit.16b	v27, v21, v29
	bit.16b	v26, v21, v28
	bit.16b	v26, v22, v31
	bit.16b	v27, v22, v30
	bif.16b	v27, v23, v9
	bif.16b	v26, v23, v8
	fdiv.4s	v25, v25, v26
	fdiv.4s	v24, v24, v27
	add	x10, x20, x8
	ldp	q27, q26, [x10]
	fmul.4s	v24, v27, v24
	fmul.4s	v25, v26, v25
	add	x10, x9, x8
	stp	q24, q25, [x10]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB1_2
	b	LBB1_5
LBB1_3:                                 ; %direct.true19.preheader
	mov	x8, #0                          ; =0x0
	mov	w9, #1120927744                 ; =0x42d00000
	dup.4s	v0, w9
	mov	w9, #-1027080192                ; =0xc2c80000
	dup.4s	v1, w9
	mov	w9, #43579                      ; =0xaa3b
	movk	w9, #16312, lsl #16
	dup.4s	v2, w9
	mov	w9, #29184                      ; =0x7200
	movk	w9, #48945, lsl #16
	dup.4s	v3, w9
	mov	w9, #48782                      ; =0xbe8e
	movk	w9, #46527, lsl #16
	dup.4s	v4, w9
	mov	w9, #11226                      ; =0x2bda
	movk	w9, #14672, lsl #16
	dup.4s	v5, w9
	mov	w9, #38601                      ; =0x96c9
	movk	w9, #15030, lsl #16
	dup.4s	v6, w9
	mov	w9, #34982                      ; =0x88a6
	movk	w9, #15368, lsl #16
	dup.4s	v7, w9
	mov	w9, #43642                      ; =0xaa7a
	movk	w9, #15658, lsl #16
	dup.4s	v16, w9
	add	x9, x21, x23
	add	x10, x22, x23
	add	x11, x11, x23
	mov	w12, #43691                     ; =0xaaab
	movk	w12, #15914, lsl #16
	dup.4s	v17, w12
	movi.4s	v18, #75, lsl #24
	mvni.4s	v19, #128, lsl #24
	movi.4s	v20, #63, lsl #24
	fmov.4s	v21, #1.00000000
	mvni.4s	v22, #127, msl #16
	fneg.4s	v22, v22
	mvni.4s	v23, #63, msl #16
	fneg.4s	v23, v23
LBB1_4:                                 ; %direct.true19
                                        ; =>This Inner Loop Header: Depth=1
	add	x12, x11, x8
	ldp	q24, q25, [x12]
	fneg.4s	v26, v25
	fneg.4s	v27, v24
	fcmge.4s	v28, v0, v24
	fcmge.4s	v29, v0, v25
	fcmge.4s	v30, v24, v1
	fcmge.4s	v31, v25, v1
	and.16b	v29, v29, v31
	and.16b	v28, v28, v30
	and.16b	v27, v28, v27
	and.16b	v26, v29, v26
	fmul.4s	v28, v26, v2
	fmul.4s	v29, v27, v2
	mov.16b	v30, v19
	bsl.16b	v30, v18, v29
	mov.16b	v31, v19
	bsl.16b	v31, v18, v28
	fadd.4s	v28, v28, v31
	fadd.4s	v29, v29, v30
	fsub.4s	v29, v29, v30
	fsub.4s	v28, v28, v31
	fcvtzs.4s	v28, v28
	fcvtzs.4s	v29, v29
	scvtf.4s	v30, v29
	scvtf.4s	v31, v28
	fmul.4s	v8, v31, v3
	fmul.4s	v9, v30, v3
	fadd.4s	v27, v27, v9
	fadd.4s	v26, v26, v8
	fmul.4s	v30, v30, v4
	fmul.4s	v31, v31, v4
	fadd.4s	v26, v26, v31
	fadd.4s	v27, v27, v30
	fmul.4s	v30, v27, v5
	fmul.4s	v31, v26, v5
	fadd.4s	v31, v31, v6
	fadd.4s	v30, v30, v6
	fmul.4s	v30, v27, v30
	fmul.4s	v31, v26, v31
	fadd.4s	v31, v31, v7
	fadd.4s	v30, v30, v7
	fmul.4s	v30, v27, v30
	fmul.4s	v31, v26, v31
	fadd.4s	v31, v31, v16
	fadd.4s	v30, v30, v16
	fmul.4s	v30, v27, v30
	fmul.4s	v31, v26, v31
	fadd.4s	v31, v31, v17
	fadd.4s	v30, v30, v17
	fmul.4s	v30, v27, v30
	fmul.4s	v31, v26, v31
	fadd.4s	v31, v31, v20
	fadd.4s	v30, v30, v20
	fmul.4s	v8, v26, v26
	fmul.4s	v9, v27, v27
	fmul.4s	v30, v9, v30
	fmul.4s	v31, v8, v31
	fadd.4s	v26, v26, v31
	fadd.4s	v27, v27, v30
	sshr.4s	v30, v29, #1
	fadd.4s	v27, v27, v21
	sshr.4s	v31, v28, #1
	shl.4s	v8, v31, #23
	shl.4s	v9, v30, #23
	add.4s	v9, v9, v21
	add.4s	v8, v8, v21
	fadd.4s	v26, v26, v21
	fmul.4s	v26, v26, v8
	sub.4s	v28, v28, v31
	sub.4s	v29, v29, v30
	shl.4s	v29, v29, #23
	shl.4s	v28, v28, #23
	fmul.4s	v27, v27, v9
	add.4s	v28, v28, v21
	add.4s	v29, v29, v21
	fmul.4s	v27, v27, v29
	fmul.4s	v26, v26, v28
	fcmgt.4s	v28, v25, v0
	fcmgt.4s	v29, v24, v0
	fcmgt.4s	v30, v1, v24
	fcmgt.4s	v31, v1, v25
	fcmeq.4s	v8, v25, v25
	fadd.4s	v26, v26, v21
	fadd.4s	v27, v27, v21
	fcmeq.4s	v9, v24, v24
	bit.16b	v27, v21, v29
	bit.16b	v26, v21, v28
	bit.16b	v26, v22, v31
	bit.16b	v27, v22, v30
	bif.16b	v27, v23, v9
	bif.16b	v26, v23, v8
	fdiv.4s	v25, v25, v26
	fdiv.4s	v24, v24, v27
	add	x12, x10, x8
	ldp	q27, q26, [x12]
	fmul.4s	v24, v27, v24
	fmul.4s	v25, v26, v25
	add	x12, x9, x8
	stp	q24, q25, [x12]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB1_4
LBB1_5:                                 ; %common.ret
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #2048
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp], #80               ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB2_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB2_4
LBB2_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB2_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB2_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB2_13
LBB2_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB2_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB2_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #1
	b.eq	LBB2_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #2
	b.eq	LBB2_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #3
	b.eq	LBB2_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB2_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB2_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
LBB2_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB2_3
LBB2_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB2_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

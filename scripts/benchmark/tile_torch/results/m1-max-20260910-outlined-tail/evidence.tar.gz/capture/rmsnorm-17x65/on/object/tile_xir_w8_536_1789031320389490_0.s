	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_3:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_4:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_7:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_8:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_9:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_10:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_11:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	dup.4s	v1, w2
Lloh0:
	adrp	x8, lCPI0_1@PAGE
Lloh1:
	ldr	q2, [x8, lCPI0_1@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_2@PAGE
Lloh3:
	ldr	q0, [x8, lCPI0_2@PAGEOFF]
	cmhi.4s	v0, v1, v0
	cmhi.4s	v1, v1, v2
	uzp1.8h	v3, v1, v0
	umaxv.8h	h2, v3
	fmov	w8, s2
	tbz	w8, #0, LBB0_86
; %bb.1:                                ; %direct.activate
	stp	d15, d14, [sp, #-80]!           ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #1456
	mov	x9, #0                          ; =0x0
	ldr	x12, [x0]
	ldr	x10, [x0, #16]
	ldr	x8, [x0, #48]
Lloh4:
	adrp	x11, lCPI0_0@PAGE
Lloh5:
	ldr	q2, [x11, lCPI0_0@PAGEOFF]
	and.16b	v2, v3, v2
	addv.8h	h2, v2
	fmov	w11, s2
	ldr	w13, [x1]
	ldr	w14, [x1, #36]
	add	w13, w14, w13, lsl #5
	lsr	w13, w13, #3
	dup.4s	v4, w13
	and	w11, w11, #0xff
	and.16b	v16, v1, v4
	and.16b	v4, v0, v4
	ushll2.2d	v5, v4, #0
	ushll2.2d	v6, v16, #0
	ushll.2d	v7, v4, #0
	ushll.2d	v4, v16, #0
	fmov	x13, d4
	mov	w14, #260                       ; =0x104
	umaddl	x13, w13, w14, x12
	fmov	w14, s2
	add	x15, sp, #1168
	b	LBB0_3
LBB0_2:                                 ; %else33
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x16, x15, x9
	stp	q16, q17, [x16]
	add	x9, x9, #32
	cmp	x9, #256
	b.eq	LBB0_19
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	add	x16, x13, x9
	add	x0, x15, x9
	ldr	q16, [x0]
	tbnz	w14, #0, LBB0_11
; %bb.4:                                ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w17, w14, #0xff
	tbnz	w17, #1, LBB0_12
LBB0_5:                                 ; %else15
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w17, #2, LBB0_13
LBB0_6:                                 ; %else18
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w17, #3, LBB0_14
LBB0_7:                                 ; %else21
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q17, [x0, #16]
	tbnz	w17, #4, LBB0_15
LBB0_8:                                 ; %else24
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w17, #5, LBB0_16
LBB0_9:                                 ; %else27
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w17, #6, LBB0_17
LBB0_10:                                ; %else30
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w17, #7, LBB0_2
	b	LBB0_18
LBB0_11:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	ld1.s	{ v16 }[0], [x16]
	and	w17, w14, #0xff
	tbz	w17, #1, LBB0_5
LBB0_12:                                ; %cond.load14
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x16, #4
	ld1.s	{ v16 }[1], [x1]
	tbz	w17, #2, LBB0_6
LBB0_13:                                ; %cond.load17
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x16, #8
	ld1.s	{ v16 }[2], [x1]
	tbz	w17, #3, LBB0_7
LBB0_14:                                ; %cond.load20
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x16, #12
	ld1.s	{ v16 }[3], [x1]
	ldr	q17, [x0, #16]
	tbz	w17, #4, LBB0_8
LBB0_15:                                ; %cond.load23
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, x16, #16
	ld1.s	{ v17 }[0], [x0]
	tbz	w17, #5, LBB0_9
LBB0_16:                                ; %cond.load26
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, x16, #20
	ld1.s	{ v17 }[1], [x0]
	tbz	w17, #6, LBB0_10
LBB0_17:                                ; %cond.load29
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, x16, #24
	ld1.s	{ v17 }[2], [x0]
	tbz	w17, #7, LBB0_2
LBB0_18:                                ; %cond.load32
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x16, x16, #28
	ld1.s	{ v17 }[3], [x16]
	b	LBB0_2
LBB0_19:                                ; %direct.true56.preheader
	xtn.8b	v22, v3
	sshll.2d	v3, v1, #0
	sshll.2d	v17, v0, #0
	sshll2.2d	v18, v1, #0
	sshll2.2d	v19, v0, #0
Lloh6:
	adrp	x9, lCPI0_6@PAGE
Lloh7:
	ldr	q16, [x9, lCPI0_6@PAGEOFF]
	and.16b	v21, v3, v16
	movi.2d	v24, #0000000000000000
Lloh8:
	adrp	x9, lCPI0_7@PAGE
Lloh9:
	ldr	q16, [x9, lCPI0_7@PAGEOFF]
	and.16b	v16, v3, v16
Lloh10:
	adrp	x9, lCPI0_8@PAGE
Lloh11:
	ldr	q3, [x9, lCPI0_8@PAGEOFF]
	and.16b	v25, v17, v3
Lloh12:
	adrp	x9, lCPI0_9@PAGE
Lloh13:
	ldr	q3, [x9, lCPI0_9@PAGEOFF]
	and.16b	v26, v18, v3
Lloh14:
	adrp	x9, lCPI0_10@PAGE
Lloh15:
	ldr	q3, [x9, lCPI0_10@PAGEOFF]
	and.16b	v27, v19, v3
	movi.8b	v3, #1
	and.8b	v3, v22, v3
	umov.b	w13, v3[0]
	movi.2d	v29, #0000000000000000
	movi.2d	v3, #0000000000000000
	mov.b	v3[0], v22[0]
	umaxv.8b	b20, v3
	fmov	w16, s20
	rbit	w9, w13
	clz	w9, w9
	tst	w16, #0x1
	mov	w14, #64                        ; =0x40
	dup.2d	v23, x14
	csel	w9, w9, wzr, ne
	str	q21, [sp, #48]                  ; 16-byte Spill
	orr.16b	v28, v21, v23
	xtn.2s	v21, v4
	movi.2s	v20, #65
	str	q28, [sp, #112]                 ; 16-byte Spill
	mov.16b	v4, v28
	umlal.2d	v4, v21, v20
	mov.b	v29[0], v22[0]
	ushll.2d	v29, v29, #0
	shl.2d	v29, v29, #63
	cmlt.2d	v29, v29, #0
	str	q4, [sp, #192]                  ; 16-byte Spill
	and.16b	v29, v29, v4
	stp	q24, q24, [sp, #768]
	stp	q29, q24, [sp, #736]
	ubfiz	x15, x9, #3, #3
	add	x14, sp, #736
	ldr	x14, [x14, x15]
	sub	x14, x14, x9
	add	x14, x12, x14, lsl #2
	stp	q25, q27, [sp, #832]
	stp	q16, q26, [sp, #800]
	add	x12, sp, #800
	ldr	x12, [x12, x15]
	orr	x12, x12, #0x100
	sub	x12, x12, w9, uxtw #2
	tst	w13, #0x1
	csel	x12, xzr, x12, eq
	add	x15, sp, #1168
	add	x15, x15, x12
	ldr	q27, [x15]
	tbnz	w16, #0, LBB0_87
; %bb.20:                               ; %else37
	tbnz	w13, #1, LBB0_88
LBB0_21:                                ; %else40
	tbnz	w13, #2, LBB0_89
LBB0_22:                                ; %else43
	tbnz	w13, #3, LBB0_90
LBB0_23:                                ; %else46
	adrp	x16, lCPI0_3@PAGE
	adrp	x17, lCPI0_4@PAGE
	adrp	x0, lCPI0_5@PAGE
	ldr	q26, [x15, #16]
	str	q3, [sp, #208]                  ; 16-byte Spill
	tbnz	w13, #4, LBB0_91
LBB0_24:                                ; %else49
	ldr	q24, [x16, lCPI0_3@PAGEOFF]
	ldr	q25, [x17, lCPI0_4@PAGEOFF]
	ldr	q31, [x0, lCPI0_5@PAGEOFF]
	tbnz	w13, #5, LBB0_92
LBB0_25:                                ; %else52
	and.16b	v3, v19, v24
	and.16b	v4, v18, v25
	and.16b	v17, v17, v31
	tbz	w13, #6, LBB0_27
LBB0_26:                                ; %cond.load54
	add	x15, x14, #24
	ld1.s	{ v26 }[2], [x15]
LBB0_27:                                ; %else55
	stp	q17, q4, [sp]                   ; 32-byte Folded Spill
	orr.16b	v24, v17, v23
	orr.16b	v25, v4, v23
	orr.16b	v4, v3, v23
	xtn.2s	v17, v6
	xtn.2s	v6, v7
	xtn.2s	v5, v5
	str	q3, [sp, #32]                   ; 16-byte Spill
	tbz	w13, #7, LBB0_29
; %bb.28:                               ; %cond.load57
	add	x13, x14, #28
	ld1.s	{ v26 }[3], [x13]
LBB0_29:                                ; %else58
	umull.2d	v7, v21, v20
	stp	q24, q4, [sp, #80]              ; 32-byte Folded Spill
	mov.16b	v3, v4
	umlal.2d	v3, v5, v20
	str	q3, [sp, #176]                  ; 16-byte Spill
	str	q25, [sp, #64]                  ; 16-byte Spill
	mov.16b	v3, v25
	umlal.2d	v3, v17, v20
	str	q3, [sp, #160]                  ; 16-byte Spill
	mov.16b	v3, v24
	umlal.2d	v3, v6, v20
	stp	q7, q3, [sp, #128]              ; 32-byte Folded Spill
	sshll.2d	v5, v1, #0
	sshll.2d	v6, v0, #0
	add	x13, sp, #1168
	add	x14, x13, x12
	stp	q27, q26, [x14]
	mov	w14, #4                         ; =0x4
	dup.2d	v7, x14
	and.16b	v20, v19, v7
	and.16b	v21, v18, v7
	and.16b	v23, v6, v7
	and.16b	v24, v5, v7
	fmov	x15, d24
	ldr	q7, [sp, #1280]
	ldr	q17, [sp, #1264]
	fmul.4s	v17, v17, v17
	fmul.4s	v7, v7, v7
	and.16b	v8, v0, v7
	and.16b	v9, v1, v17
	ldr	q7, [sp, #1248]
	ldr	q17, [sp, #1232]
	fmul.4s	v17, v17, v17
	fmul.4s	v7, v7, v7
	and.16b	v11, v0, v7
	and.16b	v10, v1, v17
	ldr	q7, [sp, #1216]
	ldr	q17, [sp, #1200]
	fmul.4s	v17, v17, v17
	fmul.4s	v7, v7, v7
	and.16b	v12, v0, v7
	and.16b	v13, v1, v17
	fmov	x16, d16
	add	x16, x13, x16
	ldp	q16, q7, [x16]
	fmul.4s	v16, v16, v16
	fmul.4s	v7, v7, v7
	and.16b	v15, v0, v7
	and.16b	v14, v1, v16
LBB0_30:                                ; %direct.true56
                                        ; =>This Inner Loop Header: Depth=1
	add	x15, x13, x15, lsl #5
	ldp	q16, q7, [x15]
	and.16b	v16, v1, v16
	and.16b	v7, v0, v7
	fmul.4s	v7, v7, v7
	fmul.4s	v16, v16, v16
	fadd.4s	v16, v14, v16
	fadd.4s	v17, v15, v7
	ldp	q25, q7, [x15, #32]
	and.16b	v25, v1, v25
	and.16b	v7, v0, v7
	fmul.4s	v7, v7, v7
	fmul.4s	v25, v25, v25
	fadd.4s	v25, v13, v25
	fadd.4s	v7, v12, v7
	ldp	q28, q4, [x15, #64]
	and.16b	v28, v1, v28
	and.16b	v4, v0, v4
	fmul.4s	v4, v4, v4
	fmul.4s	v28, v28, v28
	fadd.4s	v28, v10, v28
	fadd.4s	v4, v11, v4
	ldp	q30, q29, [x15, #96]
	and.16b	v30, v1, v30
	and.16b	v29, v0, v29
	fmul.4s	v29, v29, v29
	fmul.4s	v30, v30, v30
	fadd.4s	v30, v9, v30
	fadd.4s	v29, v8, v29
	dup.2d	v31, x14
	and.16b	v3, v19, v31
	add.2d	v20, v20, v3
	and.16b	v3, v18, v31
	add.2d	v21, v21, v3
	and.16b	v3, v6, v31
	add.2d	v23, v23, v3
	and.16b	v3, v5, v31
	add.2d	v24, v24, v3
	bit.16b	v15, v17, v0
	bit.16b	v14, v16, v1
	bit.16b	v12, v7, v0
	bit.16b	v13, v25, v1
	bit.16b	v11, v4, v0
	bit.16b	v10, v28, v1
	bit.16b	v8, v29, v0
	bit.16b	v9, v30, v1
	fmov	x15, d24
	cmp	x15, #8
	b.lt	LBB0_30
; %bb.31:                               ; %direct.false57
	mov	x14, #0                         ; =0x0
	ushll2.2d	v3, v0, #0
	mov	w13, #1                         ; =0x1
	dup.2d	v4, x13
	and.16b	v18, v3, v4
	ushll2.2d	v3, v1, #0
	and.16b	v19, v3, v4
	ushll.2d	v3, v0, #0
	and.16b	v20, v3, v4
	ushll.2d	v3, v1, #0
	and.16b	v21, v3, v4
	movi.2d	v23, #0000000000000000
	add	x13, sp, #880
	movi.2d	v24, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	ldr	q31, [sp, #208]                 ; 16-byte Reload
	b	LBB0_33
LBB0_32:                                ; %else83
                                        ;   in Loop: Header=BB0_33 Depth=1
	add	x14, x13, x14
	stp	q7, q25, [x14]
	add.2d	v24, v24, v19
	add.2d	v5, v5, v20
	add.2d	v6, v6, v18
	add.2d	v23, v23, v21
	fmov	x14, d23
	cmp	x14, #8
	b.ge	LBB0_49
LBB0_33:                                ; %direct.true91
                                        ; =>This Inner Loop Header: Depth=1
	fmov	w16, s2
	lsl	x14, x14, #5
	add	x15, x10, x14
	add	x17, x13, x14
	ldr	q7, [x17]
	tbnz	w16, #0, LBB0_41
; %bb.34:                               ; %else62
                                        ;   in Loop: Header=BB0_33 Depth=1
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_42
LBB0_35:                                ; %else65
                                        ;   in Loop: Header=BB0_33 Depth=1
	tbnz	w16, #2, LBB0_43
LBB0_36:                                ; %else68
                                        ;   in Loop: Header=BB0_33 Depth=1
	tbnz	w16, #3, LBB0_44
LBB0_37:                                ; %else71
                                        ;   in Loop: Header=BB0_33 Depth=1
	ldr	q25, [x17, #16]
	tbnz	w16, #4, LBB0_45
LBB0_38:                                ; %else74
                                        ;   in Loop: Header=BB0_33 Depth=1
	tbnz	w16, #5, LBB0_46
LBB0_39:                                ; %else77
                                        ;   in Loop: Header=BB0_33 Depth=1
	tbnz	w16, #6, LBB0_47
LBB0_40:                                ; %else80
                                        ;   in Loop: Header=BB0_33 Depth=1
	tbz	w16, #7, LBB0_32
	b	LBB0_48
LBB0_41:                                ; %cond.load61
                                        ;   in Loop: Header=BB0_33 Depth=1
	ld1.s	{ v7 }[0], [x15]
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_35
LBB0_42:                                ; %cond.load64
                                        ;   in Loop: Header=BB0_33 Depth=1
	add	x0, x15, #4
	ld1.s	{ v7 }[1], [x0]
	tbz	w16, #2, LBB0_36
LBB0_43:                                ; %cond.load67
                                        ;   in Loop: Header=BB0_33 Depth=1
	add	x0, x15, #8
	ld1.s	{ v7 }[2], [x0]
	tbz	w16, #3, LBB0_37
LBB0_44:                                ; %cond.load70
                                        ;   in Loop: Header=BB0_33 Depth=1
	add	x0, x15, #12
	ld1.s	{ v7 }[3], [x0]
	ldr	q25, [x17, #16]
	tbz	w16, #4, LBB0_38
LBB0_45:                                ; %cond.load73
                                        ;   in Loop: Header=BB0_33 Depth=1
	add	x17, x15, #16
	ld1.s	{ v25 }[0], [x17]
	tbz	w16, #5, LBB0_39
LBB0_46:                                ; %cond.load76
                                        ;   in Loop: Header=BB0_33 Depth=1
	add	x17, x15, #20
	ld1.s	{ v25 }[1], [x17]
	tbz	w16, #6, LBB0_40
LBB0_47:                                ; %cond.load79
                                        ;   in Loop: Header=BB0_33 Depth=1
	add	x17, x15, #24
	ld1.s	{ v25 }[2], [x17]
	tbz	w16, #7, LBB0_32
LBB0_48:                                ; %cond.load82
                                        ;   in Loop: Header=BB0_33 Depth=1
	add	x15, x15, #28
	ld1.s	{ v25 }[3], [x15]
	b	LBB0_32
LBB0_49:                                ; %direct.false92
	zip2.8b	v3, v31, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	and.16b	v26, v3, v26
	zip1.8b	v4, v31, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v27, v4, v27
	fmul.4s	v5, v27, v27
	fmul.4s	v6, v26, v26
	fadd.4s	v6, v6, v15
	fadd.4s	v5, v5, v14
	and.16b	v4, v4, v5
	and.16b	v3, v3, v6
	zip2.8b	v5, v22, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	bit.16b	v3, v17, v5
	movi.2d	v5, #0000000000000000
	mov.b	v5[2], v22[1]
	mov.b	v5[4], v22[2]
	mov.b	v5[6], v22[3]
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	bit.16b	v4, v16, v5
	fadd.4s	v4, v13, v4
	fadd.4s	v3, v12, v3
	fadd.4s	v3, v11, v3
	fadd.4s	v4, v10, v4
	fadd.4s	v17, v9, v4
	fadd.4s	v8, v8, v3
	ldp	q3, q5, [sp, #32]               ; 32-byte Folded Reload
	ldp	q4, q6, [sp]                    ; 32-byte Folded Reload
	uzp1.4s	v16, v5, v6
	uzp1.4s	v29, v4, v3
	movi.4s	v3, #1
	eor.16b	v4, v16, v3
	mov.s	w15, v4[1]
	eor.16b	v6, v29, v3
	mov.s	w0, v4[2]
	mov.s	w1, v4[3]
	fmov	w14, s4
	add	x13, sp, #296
	bfxil	x13, x14, #0, #3
	str	d22, [sp, #296]
	ldrb	w16, [x13]
	umov.b	w13, v22[0]
	and	x14, x14, #0x7
	stp	q17, q8, [sp, #560]
	add	x17, sp, #560
	ldr	s3, [x17, x14, lsl #2]
	add	x17, sp, #296
	ands	w14, w13, #0x1
	tst	w14, w16
	movi.2d	v28, #0000000000000000
	fcsel	s30, s3, s28, ne
	add	x16, sp, #296
	bfxil	x16, x15, #0, #3
	ldrb	w16, [x16]
	and	x2, x15, #0x7
	umov.b	w15, v22[1]
	stp	q17, q8, [sp, #528]
	add	x3, sp, #528
	ldr	s3, [x3, x2, lsl #2]
	ands	w2, w15, #0x1
	tst	w2, w16
	fcsel	s5, s3, s28, ne
	add	x16, sp, #296
	bfxil	x16, x0, #0, #3
	ldrb	w2, [x16]
	umov.b	w16, v22[2]
	and	x0, x0, #0x7
	stp	q17, q8, [sp, #496]
	add	x3, sp, #496
	ldr	s3, [x3, x0, lsl #2]
	ands	w0, w16, #0x1
	tst	w0, w2
	fcsel	s23, s3, s28, ne
	add	x0, sp, #296
	bfxil	x0, x1, #0, #3
	ldrb	w2, [x0]
	and	x1, x1, #0x7
	umov.b	w0, v22[3]
	stp	q17, q8, [sp, #464]
	add	x3, sp, #464
	ldr	s3, [x3, x1, lsl #2]
	ands	w1, w0, #0x1
	tst	w1, w2
	mov.s	w3, v6[1]
	fcsel	s7, s3, s28, ne
	mov.s	w4, v6[2]
	mov.s	w5, v6[3]
	fmov	w1, s6
	and	x2, x1, #0x7
	add	x6, sp, #296
	bfxil	x6, x1, #0, #3
	ldrb	w6, [x6]
	umov.b	w1, v22[4]
	and	w6, w1, w6
	stp	q17, q8, [sp, #688]
	add	x7, sp, #688
	ldr	s3, [x7, x2, lsl #2]
	tst	w6, #0x1
	add	x2, sp, #296
	bfxil	x2, x3, #0, #3
	ldrb	w6, [x2]
	umov.b	w2, v22[5]
	and	x3, x3, #0x7
	stp	q17, q8, [sp, #656]
	add	x7, sp, #656
	ldr	s4, [x7, x3, lsl #2]
	fcsel	s3, s3, s28, ne
	ands	w3, w2, #0x1
	tst	w3, w6
	fcsel	s4, s4, s28, ne
	add	x3, sp, #296
	bfxil	x3, x4, #0, #3
	ldrb	w6, [x3]
	and	x4, x4, #0x7
	umov.b	w3, v22[6]
	stp	q17, q8, [sp, #624]
	add	x7, sp, #624
	ldr	s6, [x7, x4, lsl #2]
	ands	w4, w3, #0x1
	tst	w4, w6
	fcsel	s6, s6, s28, ne
	add	x4, sp, #296
	bfxil	x4, x5, #0, #3
	ldrb	w6, [x4]
	and	x5, x5, #0x7
	umov.b	w4, v22[7]
	stp	q17, q8, [sp, #592]
	add	x7, sp, #592
	ldr	s22, [x7, x5, lsl #2]
	ands	w5, w4, #0x1
	tst	w5, w6
	fcsel	s22, s22, s28, ne
	mov.s	v3[1], v4[0]
	mov.s	v3[2], v6[0]
	mov.s	v3[3], v22[0]
	mov.s	v30[1], v5[0]
	mov.s	v30[2], v23[0]
	mov.s	v30[3], v7[0]
	fadd.4s	v4, v17, v30
	fadd.4s	v3, v8, v3
	movi.4s	v5, #2
	eor.16b	v6, v29, v5
	eor.16b	v5, v16, v5
	fmov	w5, s5
	add	x6, sp, #296
	bfxil	x6, x5, #0, #3
	ldrb	w6, [x6]
	and	x5, x5, #0x7
	stp	q4, q3, [sp, #432]
	add	x7, sp, #432
	ldr	s5, [x7, x5, lsl #2]
	tst	w14, w6
	fcsel	s5, s5, s28, ne
	fmov	w5, s6
	and	x6, x5, #0x7
	bfxil	x17, x5, #0, #3
	ldrb	w17, [x17]
	and	w17, w1, w17
	stp	q4, q3, [sp, #400]
	add	x5, sp, #400
	ldr	s6, [x5, x6, lsl #2]
	tst	w17, #0x1
	fcsel	s6, s6, s28, ne
	fadd.4s	v3, v3, v6
	tst	w14, w1
	fcsel	s3, s3, s28, ne
	ands	w13, w13, #0x1
	fadd.4s	v4, v4, v5
	fadd	s3, s4, s3
	fcsel	s4, s3, s28, ne
	tst	w15, #0x1
	fcsel	s5, s4, s28, ne
	tst	w16, #0x1
	fcsel	s6, s4, s28, ne
	tst	w0, #0x1
	fcsel	s7, s4, s28, ne
	tst	w13, w1
	fcsel	s3, s3, s28, ne
	tst	w2, #0x1
	fcsel	s16, s4, s28, ne
	tst	w3, #0x1
	fcsel	s17, s4, s28, ne
	tst	w4, #0x1
Lloh16:
	adrp	x13, lCPI0_11@PAGE
Lloh17:
	ldr	d22, [x13, lCPI0_11@PAGEOFF]
	shl.8b	v23, v31, #7
	cmlt.8b	v23, v23, #0
	and.8b	v22, v23, v22
	addv.8b	b22, v22
	fcsel	s23, s4, s28, ne
	mov.s	v4[1], v5[0]
	mov.s	v4[2], v6[0]
	mov.s	v4[3], v7[0]
	mov.s	v3[1], v16[0]
	mov.s	v3[2], v17[0]
	mov.s	v3[3], v23[0]
	rbit	w11, w11
	clz	w11, w11
	stp	q4, q3, [sp, #368]
	and	x11, x11, #0x7
	add	x13, sp, #368
	ldr	s5, [x13, x11, lsl #2]
	mov	b3, v31[0]
	mov.b	v3[4], v31[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldp	q16, q4, [sp, #96]              ; 32-byte Folded Reload
	and.16b	v3, v3, v4
	mov	b4, v31[2]
	mov.b	v4[4], v31[3]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	ldp	q6, q7, [sp, #64]               ; 32-byte Folded Reload
	and.16b	v4, v4, v6
	mov	b6, v31[4]
	mov.b	v6[4], v31[5]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	and.16b	v6, v6, v7
	mov	b7, v31[6]
	mov.b	v7[4], v31[7]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v7, v7, v16
	stp	q6, q7, [sp, #336]
	stp	q3, q4, [sp, #304]
	and	x11, x9, #0x7
	add	x13, sp, #304
	ldr	x13, [x13, x11, lsl #3]
	fmov	w11, s22
	sub	x13, x13, x9
	add	x10, x10, x13, lsl #2
	add	x13, sp, #880
	add	x13, x13, x12
	ldr	q16, [x13]
	tbnz	w11, #0, LBB0_93
; %bb.50:                               ; %else87
	tbnz	w11, #1, LBB0_94
LBB0_51:                                ; %else90
	tbnz	w11, #2, LBB0_95
LBB0_52:                                ; %else93
	tbnz	w11, #3, LBB0_96
LBB0_53:                                ; %else96
	ldr	q17, [x13, #16]
	tbnz	w11, #4, LBB0_97
LBB0_54:                                ; %else99
	mov	w13, #1115815936                ; =0x42820000
	tbnz	w11, #5, LBB0_98
LBB0_55:                                ; %else102
	fadd	s5, s5, s28
	fmov	s6, w13
	tbnz	w11, #6, LBB0_99
LBB0_56:                                ; %else105
	fdiv	s5, s5, s6
	tbz	w11, #7, LBB0_58
LBB0_57:                                ; %cond.load107
	add	x10, x10, #28
	ld1.s	{ v17 }[3], [x10]
LBB0_58:                                ; %else108
	mov	x14, #0                         ; =0x0
	add	x10, sp, #880
	add	x11, x10, x12
	stp	q16, q17, [x11]
	mov	w11, #50604                     ; =0xc5ac
	movk	w11, #14119, lsl #16
	fmov	s3, w11
	fadd	s3, s5, s3
	fsqrt	s3, s3
	dup.4s	v23, v3[0]
	ldr	q3, [sp, #128]                  ; 16-byte Reload
	fmov	x11, d3
	add	x11, x8, x11, lsl #2
	movi.2d	v5, #0000000000000000
	fmov	w12, s2
	add	x13, sp, #1168
	movi.2d	v2, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	b	LBB0_60
LBB0_59:                                ; %else125
                                        ;   in Loop: Header=BB0_60 Depth=1
	add.2d	v2, v2, v19
	add.2d	v6, v6, v20
	add.2d	v7, v7, v18
	add.2d	v5, v5, v21
	fmov	x14, d5
	cmp	x14, #8
	b.ge	LBB0_76
LBB0_60:                                ; %direct.true117
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x14, x14, #5
	add	x16, x13, x14
	ldr	q3, [x16]
	and.16b	v3, v1, v3
	fdiv.4s	v3, v3, v23
	add	x17, x10, x14
	ldr	q4, [x17]
	and.16b	v4, v1, v4
	fmul.4s	v24, v3, v4
	add	x14, x11, x14
	tbnz	w12, #0, LBB0_69
; %bb.61:                               ; %else111
                                        ;   in Loop: Header=BB0_60 Depth=1
	and	w15, w12, #0xff
	tbnz	w15, #1, LBB0_70
LBB0_62:                                ; %else113
                                        ;   in Loop: Header=BB0_60 Depth=1
	tbnz	w15, #2, LBB0_71
LBB0_63:                                ; %else115
                                        ;   in Loop: Header=BB0_60 Depth=1
	tbz	w15, #3, LBB0_65
LBB0_64:                                ; %cond.store116
                                        ;   in Loop: Header=BB0_60 Depth=1
	add	x0, x14, #12
	st1.s	{ v24 }[3], [x0]
LBB0_65:                                ; %else117
                                        ;   in Loop: Header=BB0_60 Depth=1
	ldr	q3, [x16, #16]
	and.16b	v3, v0, v3
	fdiv.4s	v3, v3, v23
	ldr	q4, [x17, #16]
	and.16b	v4, v0, v4
	fmul.4s	v24, v3, v4
	tbnz	w15, #4, LBB0_72
; %bb.66:                               ; %else119
                                        ;   in Loop: Header=BB0_60 Depth=1
	tbnz	w15, #5, LBB0_73
LBB0_67:                                ; %else121
                                        ;   in Loop: Header=BB0_60 Depth=1
	tbnz	w15, #6, LBB0_74
LBB0_68:                                ; %else123
                                        ;   in Loop: Header=BB0_60 Depth=1
	tbz	w15, #7, LBB0_59
	b	LBB0_75
LBB0_69:                                ; %cond.store
                                        ;   in Loop: Header=BB0_60 Depth=1
	str	s24, [x14]
	and	w15, w12, #0xff
	tbz	w15, #1, LBB0_62
LBB0_70:                                ; %cond.store112
                                        ;   in Loop: Header=BB0_60 Depth=1
	add	x0, x14, #4
	st1.s	{ v24 }[1], [x0]
	tbz	w15, #2, LBB0_63
LBB0_71:                                ; %cond.store114
                                        ;   in Loop: Header=BB0_60 Depth=1
	add	x0, x14, #8
	st1.s	{ v24 }[2], [x0]
	tbnz	w15, #3, LBB0_64
	b	LBB0_65
LBB0_72:                                ; %cond.store118
                                        ;   in Loop: Header=BB0_60 Depth=1
	str	s24, [x14, #16]
	tbz	w15, #5, LBB0_67
LBB0_73:                                ; %cond.store120
                                        ;   in Loop: Header=BB0_60 Depth=1
	add	x16, x14, #20
	st1.s	{ v24 }[1], [x16]
	tbz	w15, #6, LBB0_68
LBB0_74:                                ; %cond.store122
                                        ;   in Loop: Header=BB0_60 Depth=1
	add	x16, x14, #24
	st1.s	{ v24 }[2], [x16]
	tbz	w15, #7, LBB0_59
LBB0_75:                                ; %cond.store124
                                        ;   in Loop: Header=BB0_60 Depth=1
	add	x14, x14, #28
	st1.s	{ v24 }[3], [x14]
	b	LBB0_59
LBB0_76:                                ; %direct.false118
	fdiv.4s	v0, v27, v23
	fmov	w10, s22
	zip1.8b	v1, v31, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	and.16b	v2, v1, v16
	zip2.8b	v1, v31, v0
	ushll.4s	v1, v1, #0
	fmul.4s	v0, v0, v2
	ldp	q2, q3, [sp, #176]              ; 32-byte Folded Reload
	ldp	q5, q4, [sp, #144]              ; 32-byte Folded Reload
	stp	q3, q4, [sp, #224]
	stp	q5, q2, [sp, #256]
	and	x11, x9, #0x7
	add	x12, sp, #224
	ldr	x11, [x12, x11, lsl #3]
	sub	x9, x11, x9
	add	x8, x8, x9, lsl #2
	tbnz	w10, #0, LBB0_100
; %bb.77:                               ; %else128
	shl.4s	v1, v1, #31
	tbnz	w10, #1, LBB0_101
LBB0_78:                                ; %else130
	cmlt.4s	v2, v1, #0
	tbnz	w10, #2, LBB0_102
LBB0_79:                                ; %else132
	fdiv.4s	v1, v26, v23
	and.16b	v2, v2, v17
	tbnz	w10, #3, LBB0_103
LBB0_80:                                ; %else134
	fmul.4s	v0, v1, v2
	tbnz	w10, #4, LBB0_104
LBB0_81:                                ; %else136
	tbnz	w10, #5, LBB0_105
LBB0_82:                                ; %else138
	tbnz	w10, #6, LBB0_106
LBB0_83:                                ; %else140
	tbz	w10, #7, LBB0_85
LBB0_84:                                ; %cond.store141
	add	x8, x8, #28
	st1.s	{ v0 }[3], [x8]
LBB0_85:
	add	sp, sp, #1456
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #80             ; 16-byte Folded Reload
LBB0_86:                                ; %common.ret
	ret
LBB0_87:                                ; %cond.load36
	ld1.s	{ v27 }[0], [x14]
	tbz	w13, #1, LBB0_21
LBB0_88:                                ; %cond.load39
	add	x16, x14, #4
	ld1.s	{ v27 }[1], [x16]
	tbz	w13, #2, LBB0_22
LBB0_89:                                ; %cond.load42
	add	x16, x14, #8
	ld1.s	{ v27 }[2], [x16]
	tbz	w13, #3, LBB0_23
LBB0_90:                                ; %cond.load45
	add	x16, x14, #12
	ld1.s	{ v27 }[3], [x16]
	adrp	x16, lCPI0_3@PAGE
	adrp	x17, lCPI0_4@PAGE
	adrp	x0, lCPI0_5@PAGE
	ldr	q26, [x15, #16]
	str	q3, [sp, #208]                  ; 16-byte Spill
	tbz	w13, #4, LBB0_24
LBB0_91:                                ; %cond.load48
	add	x15, x14, #16
	ld1.s	{ v26 }[0], [x15]
	ldr	q24, [x16, lCPI0_3@PAGEOFF]
	ldr	q25, [x17, lCPI0_4@PAGEOFF]
	ldr	q31, [x0, lCPI0_5@PAGEOFF]
	tbz	w13, #5, LBB0_25
LBB0_92:                                ; %cond.load51
	add	x15, x14, #20
	ld1.s	{ v26 }[1], [x15]
	and.16b	v3, v19, v24
	and.16b	v4, v18, v25
	and.16b	v17, v17, v31
	tbnz	w13, #6, LBB0_26
	b	LBB0_27
LBB0_93:                                ; %cond.load86
	ld1.s	{ v16 }[0], [x10]
	tbz	w11, #1, LBB0_51
LBB0_94:                                ; %cond.load89
	add	x14, x10, #4
	ld1.s	{ v16 }[1], [x14]
	tbz	w11, #2, LBB0_52
LBB0_95:                                ; %cond.load92
	add	x14, x10, #8
	ld1.s	{ v16 }[2], [x14]
	tbz	w11, #3, LBB0_53
LBB0_96:                                ; %cond.load95
	add	x14, x10, #12
	ld1.s	{ v16 }[3], [x14]
	ldr	q17, [x13, #16]
	tbz	w11, #4, LBB0_54
LBB0_97:                                ; %cond.load98
	add	x13, x10, #16
	ld1.s	{ v17 }[0], [x13]
	mov	w13, #1115815936                ; =0x42820000
	tbz	w11, #5, LBB0_55
LBB0_98:                                ; %cond.load101
	add	x14, x10, #20
	ld1.s	{ v17 }[1], [x14]
	fadd	s5, s5, s28
	fmov	s6, w13
	tbz	w11, #6, LBB0_56
LBB0_99:                                ; %cond.load104
	add	x13, x10, #24
	ld1.s	{ v17 }[2], [x13]
	fdiv	s5, s5, s6
	tbnz	w11, #7, LBB0_57
	b	LBB0_58
LBB0_100:                               ; %cond.store127
	str	s0, [x8]
	shl.4s	v1, v1, #31
	tbz	w10, #1, LBB0_78
LBB0_101:                               ; %cond.store129
	add	x9, x8, #4
	st1.s	{ v0 }[1], [x9]
	cmlt.4s	v2, v1, #0
	tbz	w10, #2, LBB0_79
LBB0_102:                               ; %cond.store131
	add	x9, x8, #8
	st1.s	{ v0 }[2], [x9]
	fdiv.4s	v1, v26, v23
	and.16b	v2, v2, v17
	tbz	w10, #3, LBB0_80
LBB0_103:                               ; %cond.store133
	add	x9, x8, #12
	st1.s	{ v0 }[3], [x9]
	fmul.4s	v0, v1, v2
	tbz	w10, #4, LBB0_81
LBB0_104:                               ; %cond.store135
	str	s0, [x8, #16]
	tbz	w10, #5, LBB0_82
LBB0_105:                               ; %cond.store137
	add	x9, x8, #20
	st1.s	{ v0 }[1], [x9]
	tbz	w10, #6, LBB0_83
LBB0_106:                               ; %cond.store139
	add	x9, x8, #24
	st1.s	{ v0 }[2], [x9]
	tbnz	w10, #7, LBB0_84
	b	LBB0_85
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh16, Lloh17
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_11
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #224
	stp	d15, d14, [sp, #64]             ; 16-byte Folded Spill
	stp	d13, d12, [sp, #80]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #96]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #112]              ; 16-byte Folded Spill
	stp	x28, x27, [sp, #128]            ; 16-byte Folded Spill
	stp	x26, x25, [sp, #144]            ; 16-byte Folded Spill
	stp	x24, x23, [sp, #160]            ; 16-byte Folded Spill
	stp	x22, x21, [sp, #176]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #192]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #208]            ; 16-byte Folded Spill
	mov	x1, x2
	mov	w22, #0                         ; =0x0
	ldp	w4, w28, [x2, #44]
	mov	w6, #32                         ; =0x20
	mov	w26, #260                       ; =0x104
	movi.2d	v14, #0000000000000000
	ldp	w25, w19, [x2]
	mov	w7, #1115815936                 ; =0x42820000
	mov	w20, #50604                     ; =0xc5ac
	movk	w20, #14119, lsl #16
	stp	w20, w7, [sp, #56]              ; 8-byte Folded Spill
	mov	w21, #24                        ; =0x18
	ldp	w27, w23, [x2, #8]
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x10, [x0]
	ldr	x9, [x0, #16]
	ldr	x8, [x0, #48]
	ubfiz	w12, w25, #2, #27
	umull	x11, w12, w26
	umaddl	x13, w12, w26, x10
	ldp	q24, q23, [x13]
	ldp	q21, q22, [x13, #32]
	ldp	q20, q19, [x13, #64]
	ldp	q17, q18, [x13, #96]
	ldp	q16, q7, [x13, #128]
	ldp	q5, q6, [x13, #160]
	ldp	q4, q3, [x13, #192]
	ldp	q1, q2, [x13, #224]
	add	x11, x11, #256
	ldr	s25, [x10, x11]
	ldp	q30, q29, [x9]
	ldp	q28, q27, [x9, #32]
	ldp	q26, q0, [x9, #64]
	str	q0, [sp, #32]                   ; 16-byte Spill
	fmul.4s	v31, v24, v24
	fmul.4s	v11, v23, v23
	fmul.4s	v12, v22, v22
	fmul.4s	v13, v21, v21
	fmul.4s	v14, v20, v20
	fmul.4s	v15, v19, v19
	fmul.4s	v9, v18, v18
	fmul.4s	v10, v17, v17
	fmul.4s	v8, v1, v1
	fadd.4s	v8, v10, v8
	fmul.4s	v10, v2, v2
	fadd.4s	v9, v9, v10
	fmul.4s	v10, v3, v3
	fadd.4s	v10, v15, v10
	fmul.4s	v15, v4, v4
	fadd.4s	v14, v14, v15
	fmul.4s	v15, v5, v5
	fadd.4s	v13, v13, v15
	fmul.4s	v15, v6, v6
	fadd.4s	v12, v12, v15
	fmul.4s	v15, v7, v7
	fadd.4s	v11, v11, v15
	fmul.4s	v15, v16, v16
	fadd.4s	v31, v31, v15
	fmul.4s	v15, v25, v25
	fadd.4s	v15, v31, v15
	mov.s	v31[0], v15[0]
	fadd.4s	v11, v12, v11
	ldp	q15, q12, [x9, #96]
	fadd.4s	v31, v13, v31
	fadd.4s	v31, v14, v31
	ldp	q14, q13, [x9, #128]
	fadd.4s	v10, v10, v11
	fadd.4s	v9, v9, v10
	ldp	q11, q10, [x9, #160]
	fadd.4s	v31, v8, v31
	rev64.4s	v8, v9
	fadd.4s	v8, v9, v8
	rev64.4s	v9, v31
	fadd.4s	v31, v31, v9
	dup.4s	v9, v8[2]
	fadd.4s	v8, v8, v9
	dup.4s	v9, v31[2]
	fadd.4s	v31, v31, v9
	fadd.4s	v31, v31, v8
	ldp	q9, q8, [x9, #192]
	movi.2d	v0, #0000000000000000
	fadd	s31, s31, s0
	ldr	s0, [sp, #60]                   ; 4-byte Reload
	fdiv	s31, s31, s0
	ldr	s0, [sp, #56]                   ; 4-byte Reload
	fadd	s31, s31, s0
	fsqrt	s31, s31
	dup.4s	v31, v31[0]
	fdiv.4s	v23, v23, v31
	fdiv.4s	v24, v24, v31
	fmul.4s	v24, v30, v24
	fmul.4s	v23, v29, v23
	ldp	q30, q29, [x9, #224]
	umaddl	x12, w12, w26, x8
	ldr	s0, [x9, #256]
	stp	q24, q23, [x12]
	fdiv.4s	v22, v22, v31
	fdiv.4s	v21, v21, v31
	fmul.4s	v21, v28, v21
	fmul.4s	v22, v27, v22
	stp	q21, q22, [x12, #32]
	fdiv.4s	v19, v19, v31
	fdiv.4s	v20, v20, v31
	fmul.4s	v20, v26, v20
	ldr	q21, [sp, #32]                  ; 16-byte Reload
	fmul.4s	v19, v21, v19
	stp	q20, q19, [x12, #64]
	fdiv.4s	v18, v18, v31
	fdiv.4s	v17, v17, v31
	fmul.4s	v17, v15, v17
	fmul.4s	v18, v12, v18
	stp	q17, q18, [x12, #96]
	fdiv.4s	v7, v7, v31
	fdiv.4s	v16, v16, v31
	fmul.4s	v16, v14, v16
	fmul.4s	v7, v13, v7
	stp	q16, q7, [x12, #128]
	fdiv.4s	v6, v6, v31
	fdiv.4s	v5, v5, v31
	fmul.4s	v5, v11, v5
	fmul.4s	v6, v10, v6
	stp	q5, q6, [x12, #160]
	fdiv.4s	v3, v3, v31
	fdiv.4s	v4, v4, v31
	fmul.4s	v4, v9, v4
	fmul.4s	v3, v8, v3
	stp	q4, q3, [x12, #192]
	fdiv.4s	v2, v2, v31
	fdiv.4s	v1, v1, v31
	fmul.4s	v1, v30, v1
	fmul.4s	v2, v29, v2
	stp	q1, q2, [x12, #224]
	fdiv.4s	v1, v25, v31
	fmul.4s	v0, v0, v1
	str	s0, [x8, x11]
	mov	w12, #1                         ; =0x1
	bfi	w12, w25, #2, #27
	umull	x11, w12, w26
	umaddl	x13, w12, w26, x10
	ldp	q24, q23, [x13]
	ldp	q21, q22, [x13, #32]
	ldp	q20, q19, [x13, #64]
	ldp	q17, q18, [x13, #96]
	ldp	q16, q7, [x13, #128]
	ldp	q5, q6, [x13, #160]
	ldp	q4, q3, [x13, #192]
	ldp	q1, q2, [x13, #224]
	add	x11, x11, #256
	ldr	s27, [x10, x11]
	ldp	q30, q29, [x9]
	ldp	q28, q0, [x9, #32]
	str	q0, [sp]                        ; 16-byte Spill
	ldr	q0, [x9, #80]
	str	q0, [sp, #32]                   ; 16-byte Spill
	ldr	q0, [x9, #64]
	str	q0, [sp, #16]                   ; 16-byte Spill
	fmul.4s	v31, v24, v24
	fmul.4s	v8, v23, v23
	fmul.4s	v9, v22, v22
	fmul.4s	v10, v21, v21
	fmul.4s	v11, v20, v20
	fmul.4s	v12, v19, v19
	fmul.4s	v13, v18, v18
	fmul.4s	v14, v17, v17
	fmul.4s	v15, v1, v1
	fadd.4s	v14, v14, v15
	fmul.4s	v15, v2, v2
	fadd.4s	v13, v13, v15
	fmul.4s	v15, v3, v3
	fadd.4s	v12, v12, v15
	fmul.4s	v15, v4, v4
	fadd.4s	v11, v11, v15
	fmul.4s	v15, v5, v5
	fadd.4s	v10, v10, v15
	fmul.4s	v15, v6, v6
	fadd.4s	v9, v9, v15
	fmul.4s	v15, v7, v7
	fadd.4s	v8, v8, v15
	fmul.4s	v15, v16, v16
	fadd.4s	v31, v31, v15
	fmul.4s	v15, v27, v27
	fadd.4s	v15, v31, v15
	mov.s	v31[0], v15[0]
	fadd.4s	v8, v9, v8
	ldp	q15, q9, [x9, #96]
	fadd.4s	v31, v10, v31
	fadd.4s	v31, v11, v31
	ldp	q11, q10, [x9, #128]
	fadd.4s	v8, v12, v8
	fadd.4s	v8, v13, v8
	ldp	q13, q12, [x9, #160]
	fadd.4s	v31, v14, v31
	rev64.4s	v14, v8
	fadd.4s	v8, v8, v14
	rev64.4s	v14, v31
	fadd.4s	v31, v31, v14
	dup.4s	v14, v8[2]
	fadd.4s	v8, v8, v14
	dup.4s	v14, v31[2]
	fadd.4s	v31, v31, v14
	fadd.4s	v31, v31, v8
	ldp	q14, q8, [x9, #192]
	movi.2d	v0, #0000000000000000
	fadd	s31, s31, s0
	ldp	s26, s25, [sp, #56]             ; 8-byte Folded Reload
	fdiv	s31, s31, s25
	fadd	s31, s31, s26
	fsqrt	s31, s31
	dup.4s	v31, v31[0]
	fdiv.4s	v23, v23, v31
	fdiv.4s	v24, v24, v31
	fmul.4s	v24, v30, v24
	fmul.4s	v23, v29, v23
	ldp	q30, q29, [x9, #224]
	umaddl	x12, w12, w26, x8
	ldr	s0, [x9, #256]
	stp	q24, q23, [x12]
	fdiv.4s	v22, v22, v31
	fdiv.4s	v21, v21, v31
	fmul.4s	v21, v28, v21
	ldr	q23, [sp]                       ; 16-byte Reload
	fmul.4s	v22, v23, v22
	stp	q21, q22, [x12, #32]
	fdiv.4s	v19, v19, v31
	fdiv.4s	v20, v20, v31
	ldp	q22, q21, [sp, #16]             ; 32-byte Folded Reload
	fmul.4s	v20, v22, v20
	fmul.4s	v19, v21, v19
	stp	q20, q19, [x12, #64]
	fdiv.4s	v18, v18, v31
	fdiv.4s	v17, v17, v31
	fmul.4s	v17, v15, v17
	fmul.4s	v18, v9, v18
	stp	q17, q18, [x12, #96]
	fdiv.4s	v7, v7, v31
	fdiv.4s	v16, v16, v31
	fmul.4s	v16, v11, v16
	fmul.4s	v7, v10, v7
	stp	q16, q7, [x12, #128]
	fdiv.4s	v6, v6, v31
	fdiv.4s	v5, v5, v31
	fmul.4s	v5, v13, v5
	fmul.4s	v6, v12, v6
	stp	q5, q6, [x12, #160]
	fdiv.4s	v3, v3, v31
	fdiv.4s	v4, v4, v31
	fmul.4s	v4, v14, v4
	fmul.4s	v3, v8, v3
	stp	q4, q3, [x12, #192]
	fdiv.4s	v2, v2, v31
	fdiv.4s	v1, v1, v31
	fmul.4s	v1, v30, v1
	fmul.4s	v2, v29, v2
	stp	q1, q2, [x12, #224]
	fdiv.4s	v1, v27, v31
	fmul.4s	v0, v0, v1
	str	s0, [x8, x11]
	mov	w12, #2                         ; =0x2
	bfi	w12, w25, #2, #27
	umull	x11, w12, w26
	umaddl	x13, w12, w26, x10
	ldp	q24, q23, [x13]
	ldp	q21, q22, [x13, #32]
	ldp	q20, q19, [x13, #64]
	ldp	q17, q18, [x13, #96]
	ldp	q16, q7, [x13, #128]
	ldp	q5, q6, [x13, #160]
	ldp	q4, q3, [x13, #192]
	ldp	q1, q2, [x13, #224]
	add	x11, x11, #256
	ldr	s27, [x10, x11]
	ldp	q30, q29, [x9]
	ldp	q28, q0, [x9, #32]
	str	q0, [sp]                        ; 16-byte Spill
	ldr	q0, [x9, #80]
	str	q0, [sp, #32]                   ; 16-byte Spill
	ldr	q0, [x9, #64]
	str	q0, [sp, #16]                   ; 16-byte Spill
	fmul.4s	v31, v24, v24
	fmul.4s	v8, v23, v23
	fmul.4s	v9, v22, v22
	fmul.4s	v10, v21, v21
	fmul.4s	v11, v20, v20
	fmul.4s	v12, v19, v19
	fmul.4s	v13, v18, v18
	fmul.4s	v14, v17, v17
	fmul.4s	v15, v1, v1
	fadd.4s	v14, v14, v15
	fmul.4s	v15, v2, v2
	fadd.4s	v13, v13, v15
	fmul.4s	v15, v3, v3
	fadd.4s	v12, v12, v15
	fmul.4s	v15, v4, v4
	fadd.4s	v11, v11, v15
	fmul.4s	v15, v5, v5
	fadd.4s	v10, v10, v15
	fmul.4s	v15, v6, v6
	fadd.4s	v9, v9, v15
	fmul.4s	v15, v7, v7
	fadd.4s	v8, v8, v15
	fmul.4s	v15, v16, v16
	fadd.4s	v31, v31, v15
	fmul.4s	v15, v27, v27
	fadd.4s	v15, v31, v15
	mov.s	v31[0], v15[0]
	fadd.4s	v8, v9, v8
	ldp	q15, q9, [x9, #96]
	fadd.4s	v31, v10, v31
	fadd.4s	v31, v11, v31
	ldp	q11, q10, [x9, #128]
	fadd.4s	v8, v12, v8
	fadd.4s	v8, v13, v8
	ldp	q13, q12, [x9, #160]
	fadd.4s	v31, v14, v31
	rev64.4s	v14, v8
	fadd.4s	v8, v8, v14
	rev64.4s	v14, v31
	fadd.4s	v31, v31, v14
	dup.4s	v14, v8[2]
	fadd.4s	v8, v8, v14
	dup.4s	v14, v31[2]
	fadd.4s	v31, v31, v14
	fadd.4s	v31, v31, v8
	ldp	q14, q8, [x9, #192]
	movi.2d	v0, #0000000000000000
	fadd	s31, s31, s0
	fdiv	s31, s31, s25
	fadd	s31, s31, s26
	fsqrt	s31, s31
	dup.4s	v31, v31[0]
	fdiv.4s	v23, v23, v31
	fdiv.4s	v24, v24, v31
	fmul.4s	v24, v30, v24
	fmul.4s	v23, v29, v23
	ldp	q30, q29, [x9, #224]
	umaddl	x12, w12, w26, x8
	ldr	s0, [x9, #256]
	stp	q24, q23, [x12]
	fdiv.4s	v22, v22, v31
	fdiv.4s	v21, v21, v31
	fmul.4s	v21, v28, v21
	ldr	q23, [sp]                       ; 16-byte Reload
	fmul.4s	v22, v23, v22
	stp	q21, q22, [x12, #32]
	fdiv.4s	v19, v19, v31
	fdiv.4s	v20, v20, v31
	ldp	q22, q21, [sp, #16]             ; 32-byte Folded Reload
	fmul.4s	v20, v22, v20
	fmul.4s	v19, v21, v19
	stp	q20, q19, [x12, #64]
	fdiv.4s	v18, v18, v31
	fdiv.4s	v17, v17, v31
	fmul.4s	v17, v15, v17
	fmul.4s	v18, v9, v18
	stp	q17, q18, [x12, #96]
	fdiv.4s	v7, v7, v31
	fdiv.4s	v16, v16, v31
	fmul.4s	v16, v11, v16
	fmul.4s	v7, v10, v7
	stp	q16, q7, [x12, #128]
	fdiv.4s	v6, v6, v31
	fdiv.4s	v5, v5, v31
	fmul.4s	v5, v13, v5
	fmul.4s	v6, v12, v6
	stp	q5, q6, [x12, #160]
	fdiv.4s	v3, v3, v31
	fdiv.4s	v4, v4, v31
	fmul.4s	v4, v14, v4
	fmul.4s	v3, v8, v3
	stp	q4, q3, [x12, #192]
	fdiv.4s	v2, v2, v31
	fdiv.4s	v1, v1, v31
	fmul.4s	v1, v30, v1
	fmul.4s	v2, v29, v2
	stp	q1, q2, [x12, #224]
	fdiv.4s	v1, v27, v31
	fmul.4s	v0, v0, v1
	str	s0, [x8, x11]
	mov	w12, #3                         ; =0x3
	bfi	w12, w25, #2, #27
	umull	x11, w12, w26
	umaddl	x13, w12, w26, x10
	ldp	q24, q23, [x13]
	ldp	q22, q21, [x13, #32]
	ldp	q20, q19, [x13, #64]
	ldp	q18, q17, [x13, #96]
	ldp	q16, q7, [x13, #128]
	ldp	q6, q5, [x13, #160]
	ldp	q4, q3, [x13, #192]
	ldp	q2, q1, [x13, #224]
	add	x11, x11, #256
	ldr	s0, [x10, x11]
	ldp	q28, q27, [x9]
	ldp	q26, q25, [x9, #32]
	fmul.4s	v29, v24, v24
	fmul.4s	v30, v23, v23
	fmul.4s	v31, v21, v21
	fmul.4s	v8, v22, v22
	fmul.4s	v9, v20, v20
	fmul.4s	v10, v19, v19
	fmul.4s	v11, v17, v17
	fmul.4s	v12, v18, v18
	fmul.4s	v13, v1, v1
	fmul.4s	v14, v2, v2
	fadd.4s	v12, v12, v14
	fadd.4s	v13, v11, v13
	fmul.4s	v11, v4, v4
	fmul.4s	v14, v3, v3
	fadd.4s	v10, v10, v14
	fadd.4s	v9, v9, v11
	fmul.4s	v11, v5, v5
	fmul.4s	v14, v6, v6
	fadd.4s	v8, v8, v14
	fadd.4s	v31, v31, v11
	fmul.4s	v11, v16, v16
	fmul.4s	v14, v7, v7
	fadd.4s	v30, v30, v14
	fadd.4s	v29, v29, v11
	fmul.4s	v11, v0, v0
	fadd.4s	v11, v29, v11
	mov.s	v29[0], v11[0]
	ldp	q15, q14, [x9, #64]
	fadd.4s	v30, v31, v30
	fadd.4s	v29, v8, v29
	ldp	q8, q31, [x9, #96]
	fadd.4s	v29, v9, v29
	fadd.4s	v9, v10, v30
	ldp	q11, q30, [x9, #128]
	fadd.4s	v9, v13, v9
	fadd.4s	v29, v12, v29
	rev64.4s	v10, v29
	rev64.4s	v12, v9
	fadd.4s	v9, v9, v12
	fadd.4s	v29, v29, v10
	dup.4s	v10, v29[2]
	dup.4s	v12, v9[2]
	fadd.4s	v9, v9, v12
	fadd.4s	v29, v29, v10
	fadd.4s	v29, v29, v9
	movi.2d	v9, #0000000000000000
	fadd	s29, s29, s9
	ldr	s9, [sp, #60]                   ; 4-byte Reload
	fdiv	s29, s29, s9
	ldr	s9, [sp, #56]                   ; 4-byte Reload
	fadd	s29, s29, s9
	fsqrt	s29, s29
	dup.4s	v29, v29[0]
	ldp	q10, q9, [x9, #160]
	fdiv.4s	v24, v24, v29
	fmul.4s	v24, v28, v24
	ldp	q12, q28, [x9, #192]
	fdiv.4s	v23, v23, v29
	fmul.4s	v23, v27, v23
	fdiv.4s	v22, v22, v29
	fmul.4s	v22, v26, v22
	ldp	q27, q26, [x9, #224]
	fdiv.4s	v21, v21, v29
	fmul.4s	v21, v25, v21
	ldr	s25, [x9, #256]
	umaddl	x9, w12, w26, x8
	stp	q24, q23, [x9]
	fdiv.4s	v20, v20, v29
	fmul.4s	v20, v15, v20
	fdiv.4s	v19, v19, v29
	fmul.4s	v19, v14, v19
	movi.2d	v14, #0000000000000000
	stp	q22, q21, [x9, #32]
	fdiv.4s	v18, v18, v29
	fmul.4s	v18, v8, v18
	stp	q20, q19, [x9, #64]
	fdiv.4s	v17, v17, v29
	fmul.4s	v17, v31, v17
	fdiv.4s	v16, v16, v29
	fmul.4s	v16, v11, v16
	stp	q18, q17, [x9, #96]
	fdiv.4s	v7, v7, v29
	fmul.4s	v7, v30, v7
	stp	q16, q7, [x9, #128]
	fdiv.4s	v6, v6, v29
	fmul.4s	v6, v10, v6
	fdiv.4s	v5, v5, v29
	fmul.4s	v5, v9, v5
	stp	q6, q5, [x9, #160]
	fdiv.4s	v4, v4, v29
	fmul.4s	v4, v12, v4
	fdiv.4s	v3, v3, v29
	fmul.4s	v3, v28, v3
	stp	q4, q3, [x9, #192]
	fdiv.4s	v2, v2, v29
	fmul.4s	v2, v27, v2
	fdiv.4s	v1, v1, v29
	fmul.4s	v1, v26, v1
	stp	q2, q1, [x9, #224]
	fdiv.4s	v0, v0, v29
	fmul.4s	v0, v25, v0
	str	s0, [x8, x11]
LBB1_3:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	w21, [x1, #36]
	add	w8, w25, #1
	cmp	w8, w4
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w19, eq
	cmp	w9, w28
	cset	w10, eq
	ands	w8, w8, w10
	csel	w19, wzr, w9, ne
	add	w27, w27, w8
	add	w22, w22, #1
	cmp	w22, w3
	b.eq	LBB1_10
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_7 Depth 2
	ubfiz	x8, x25, #5, #32
	cmp	x8, x23
	csel	x9, x8, xzr, ls
	subs	x10, x23, x9
	cmp	x10, #32
	csel	x10, x10, x6, lo
	cmp	x23, x9
	stp	w25, w19, [x1]
	str	w27, [x1, #8]
	ccmp	x8, x23, #2, hi
	csel	x8, x10, xzr, ls
	cmp	x8, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x9, x8, #3
	cbz	x9, LBB1_8
; %bb.6:                                ; %packet.batch.partial.full.loop.preheader.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x10, [x0]
	ldr	x11, [x0, #16]
	ldr	x12, [x0, #48]
	add	x13, x11, #256
	lsl	w14, w25, #2
	mov	x15, x9
LBB1_7:                                 ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w17, w14, #0x1fffffff
	umaddl	x2, w17, w26, x10
	umull	x16, w17, w26
	ldp	q24, q23, [x2]
	ldp	q21, q22, [x2, #32]
	ldp	q20, q19, [x2, #64]
	ldp	q18, q17, [x2, #96]
	ldp	q16, q7, [x2, #128]
	ldp	q6, q5, [x2, #160]
	ldp	q4, q1, [x2, #192]
	add	x16, x16, #256
	ldr	s0, [x10, x16]
	ldp	q3, q2, [x2, #224]
	ldp	q26, q25, [x11]
	fmul.4s	v27, v24, v24
	fmul.4s	v28, v23, v23
	fmul.4s	v29, v22, v22
	fmul.4s	v30, v21, v21
	fmul.4s	v31, v20, v20
	fmul.4s	v8, v19, v19
	fmul.4s	v9, v17, v17
	fmul.4s	v10, v18, v18
	fmul.4s	v11, v2, v2
	fmul.4s	v12, v3, v3
	fadd.4s	v10, v10, v12
	fadd.4s	v9, v9, v11
	fmul.4s	v11, v4, v4
	fmul.4s	v12, v1, v1
	fadd.4s	v8, v8, v12
	fadd.4s	v31, v31, v11
	fmul.4s	v11, v5, v5
	fmul.4s	v12, v6, v6
	fadd.4s	v30, v30, v12
	fmul.4s	v12, v16, v16
	fadd.4s	v29, v29, v11
	fmul.4s	v11, v7, v7
	fadd.4s	v28, v28, v11
	fadd.4s	v27, v27, v12
	fmul.4s	v11, v0, v0
	ldp	q13, q12, [x11, #32]
	fadd.4s	v11, v27, v11
	mov.s	v27[0], v11[0]
	fadd.4s	v28, v29, v28
	fadd.4s	v27, v30, v27
	fadd.4s	v27, v31, v27
	fadd.4s	v28, v8, v28
	fadd.4s	v28, v9, v28
	fadd.4s	v27, v10, v27
	rev64.4s	v29, v27
	rev64.4s	v30, v28
	fadd.4s	v28, v28, v30
	fadd.4s	v27, v27, v29
	dup.4s	v29, v27[2]
	dup.4s	v30, v28[2]
	ldp	q8, q31, [x11, #64]
	fadd.4s	v28, v28, v30
	fadd.4s	v27, v27, v29
	fadd.4s	v27, v27, v28
	ldp	q29, q28, [x11, #96]
	fadd	s27, s27, s14
	fmov	s30, w7
	fdiv	s27, s27, s30
	fmov	s30, w20
	ldp	q10, q9, [x11, #128]
	fadd	s27, s27, s30
	fsqrt	s27, s27
	dup.4s	v27, v27[0]
	ldp	q11, q30, [x11, #160]
	fdiv.4s	v23, v23, v27
	fdiv.4s	v24, v24, v27
	fmul.4s	v24, v26, v24
	fmul.4s	v23, v25, v23
	ldp	q26, q25, [x11, #192]
	fdiv.4s	v22, v22, v27
	fdiv.4s	v21, v21, v27
	fmul.4s	v21, v13, v21
	fmul.4s	v22, v12, v22
	ldp	q13, q12, [x11, #224]
	fdiv.4s	v20, v20, v27
	fmul.4s	v20, v8, v20
	ldr	s8, [x13]
	umaddl	x17, w17, w26, x12
	stp	q24, q23, [x17]
	fdiv.4s	v19, v19, v27
	fmul.4s	v19, v31, v19
	fdiv.4s	v18, v18, v27
	fmul.4s	v18, v29, v18
	stp	q21, q22, [x17, #32]
	fdiv.4s	v17, v17, v27
	fmul.4s	v17, v28, v17
	fdiv.4s	v16, v16, v27
	fmul.4s	v16, v10, v16
	stp	q20, q19, [x17, #64]
	stp	q18, q17, [x17, #96]
	fdiv.4s	v7, v7, v27
	fmul.4s	v7, v9, v7
	stp	q16, q7, [x17, #128]
	fdiv.4s	v6, v6, v27
	fmul.4s	v6, v11, v6
	fdiv.4s	v5, v5, v27
	fmul.4s	v5, v30, v5
	stp	q6, q5, [x17, #160]
	fdiv.4s	v4, v4, v27
	fmul.4s	v4, v26, v4
	fdiv.4s	v1, v1, v27
	fmul.4s	v1, v25, v1
	stp	q4, q1, [x17, #192]
	fdiv.4s	v1, v3, v27
	fmul.4s	v1, v13, v1
	fdiv.4s	v2, v2, v27
	fmul.4s	v2, v12, v2
	stp	q1, q2, [x17, #224]
	fdiv.4s	v0, v0, v27
	fmul.4s	v0, v8, v0
	str	s0, [x12, x16]
	add	w14, w14, #1
	subs	w15, w15, #1
	b.ne	LBB1_7
LBB1_8:                                 ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w8, #0x7
	cbz	w2, LBB1_3
; %bb.9:                                ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w9, #3
	str	w8, [x1, #36]
	str	x25, [sp, #32]                  ; 8-byte Spill
	mov	x25, x19
	mov	x19, x0
	mov	x21, x3
	mov	x20, x4
	mov	x24, x22
	mov	x22, x23
	mov	x23, x1
	bl	_llm_rows
	mov	w7, #1115815936                 ; =0x42820000
	mov	w6, #32                         ; =0x20
	mov	x1, x23
	mov	x23, x22
	mov	x22, x24
	mov	x4, x20
	mov	w20, #50604                     ; =0xc5ac
	movk	w20, #14119, lsl #16
	mov	x0, x19
	mov	x19, x25
	ldr	x25, [sp, #32]                  ; 8-byte Reload
	mov	x3, x21
	mov	w21, #24                        ; =0x18
	b	LBB1_3
LBB1_10:
	ldp	x29, x30, [sp, #208]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #192]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #176]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #160]            ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #144]            ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #128]            ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #112]              ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #96]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #80]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp, #64]             ; 16-byte Folded Reload
	add	sp, sp, #224
LBB1_11:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

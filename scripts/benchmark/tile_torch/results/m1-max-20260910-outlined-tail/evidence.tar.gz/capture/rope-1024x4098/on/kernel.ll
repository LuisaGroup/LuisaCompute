; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [8224 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [8224 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local4 = alloca [8224 x i8], align 4
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local7 = alloca [8224 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill10 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill10, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot11 = alloca i64, align 8
  store i64 0, ptr %.slot11, align 4
  %.spill12 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill12, align 1
  %tile_snapshot.spill13 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill13, align 64
  %.slot14 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot14, align 64
  %tile_snapshot.spill15 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill15, align 64
  %.slot16 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot16, align 64
  %tile_snapshot.spill17 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill17, align 64
  %.slot18 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot18, align 64
  %.slot19 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot19, align 64
  %.slot20 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot20, align 64
  %8 = getelementptr i8, ptr %argument_buffer, i64 0
  %9 = load ptr, ptr %8, align 16
  %10 = getelementptr i8, ptr %8, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = insertvalue { ptr, i64 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %11, 1
  %14 = getelementptr i8, ptr %argument_buffer, i64 16
  %15 = load ptr, ptr %14, align 16
  %16 = getelementptr i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = insertvalue { ptr, i64 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i64 } %18, i64 %17, 1
  %20 = getelementptr i8, ptr %argument_buffer, i64 32
  %21 = load ptr, ptr %20, align 16
  %22 = getelementptr i8, ptr %20, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = insertvalue { ptr, i64 } poison, ptr %21, 0
  %25 = insertvalue { ptr, i64 } %24, i64 %23, 1
  %26 = getelementptr i8, ptr %argument_buffer, i64 48
  %27 = load ptr, ptr %26, align 16
  %28 = getelementptr i8, ptr %26, i64 8
  %29 = load i64, ptr %28, align 8
  %30 = insertvalue { ptr, i64 } poison, ptr %27, 0
  %31 = insertvalue { ptr, i64 } %30, i64 %29, 1
  %32 = load i32, ptr %launch_config, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 12
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 4
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 16
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 8
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 20
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 36
  %44 = load i32, ptr %43, align 4
  %.splatinsert21 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat22 = shufflevector <8 x i32> %.splatinsert21, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat22, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %46 = mul i32 %32, 32
  %.splatinsert23 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat24 = shufflevector <8 x i32> %.splatinsert23, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat24, %45
  %48 = mul i32 %36, 1
  %.splatinsert25 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat26 = shufflevector <8 x i32> %.splatinsert25, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat26, zeroinitializer
  %50 = mul i32 %40, 1
  %.splatinsert27 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat28 = shufflevector <8 x i32> %.splatinsert27, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat28, zeroinitializer
  %52 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %47, 0
  %53 = insertvalue [3 x <8 x i32>] %52, <8 x i32> %49, 1
  %54 = insertvalue [3 x <8 x i32>] %53, <8 x i32> %51, 2
  %.splatinsert29 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat30 = shufflevector <8 x i32> %.splatinsert29, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat30
  %56 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  br i1 %56, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %57 = extractvalue [3 x <8 x i32>] %54, 0
  %58 = load <8 x i64>, ptr %.spill, align 64
  %59 = select <8 x i1> %55, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %58
  store <8 x i64> %59, ptr %.spill, align 64
  %60 = sub <8 x i32> %57, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %61 = select <8 x i1> %55, <8 x i32> %60, <8 x i32> zeroinitializer
  %62 = select <8 x i1> %55, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %63 = lshr <8 x i32> %61, %62
  %64 = zext <8 x i32> %63 to <8 x i64>
  %65 = select <8 x i1> %55, <8 x i64> %64, <8 x i64> zeroinitializer
  %66 = select <8 x i1> %55, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %67 = sdiv <8 x i64> %65, %66
  %68 = load <8 x i64>, ptr %.spill10, align 64
  %69 = select <8 x i1> %55, <8 x i64> %67, <8 x i64> %68
  store <8 x i64> %69, ptr %.spill10, align 64
  %70 = extractvalue { ptr, i64 } %13, 1
  %71 = extractvalue { ptr, i64 } %13, 0
  %72 = ptrtoint ptr %71 to i64
  %73 = extractvalue { ptr, i64 } %31, 1
  %74 = extractvalue { ptr, i64 } %31, 0
  %75 = ptrtoint ptr %74 to i64
  %76 = icmp uge i64 %72, %75
  %77 = sub i64 %72, %75
  %78 = icmp uge i64 %77, 16785408
  %79 = and i1 %76, %78
  %80 = icmp uge i64 %75, %72
  %81 = sub i64 %75, %72
  %82 = icmp uge i64 %81, 16785408
  %83 = and i1 %80, %82
  %84 = or i1 %79, %83
  %85 = and i1 true, %84
  %86 = extractvalue { ptr, i64 } %19, 1
  %87 = extractvalue { ptr, i64 } %19, 0
  %88 = ptrtoint ptr %87 to i64
  %89 = icmp uge i64 %88, %75
  %90 = sub i64 %88, %75
  %91 = icmp uge i64 %90, 16785408
  %92 = and i1 %89, %91
  %93 = icmp uge i64 %75, %88
  %94 = sub i64 %75, %88
  %95 = icmp uge i64 %94, 8392704
  %96 = and i1 %93, %95
  %97 = or i1 %92, %96
  %98 = and i1 %85, %97
  %99 = extractvalue { ptr, i64 } %25, 1
  %100 = extractvalue { ptr, i64 } %25, 0
  %101 = ptrtoint ptr %100 to i64
  %102 = icmp uge i64 %101, %75
  %103 = sub i64 %101, %75
  %104 = icmp uge i64 %103, 16785408
  %105 = and i1 %102, %104
  %106 = icmp uge i64 %75, %101
  %107 = sub i64 %75, %101
  %108 = icmp uge i64 %107, 8392704
  %109 = and i1 %106, %108
  %110 = or i1 %105, %109
  %111 = and i1 %98, %110
  br i1 %111, label %direct.true, label %direct.false

direct.schedule.1:                                ; preds = %direct.true
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.2

direct.schedule.2:                                ; preds = %direct.schedule.3, %direct.schedule.1
  %.state = load i64, ptr %.slot, align 4
  %112 = icmp slt i64 %.state, 256
  br i1 %112, label %direct.true31, label %direct.false32

direct.schedule.3:                                ; preds = %direct.true31
  %.state33 = load i64, ptr %.slot, align 4
  %113 = mul i64 %.state33, 8
  %.splatinsert34 = insertelement <8 x i64> poison, i64 %113, i64 0
  %.splat35 = shufflevector <8 x i64> %.splatinsert34, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %114 = add <8 x i64> %.splat35, %.spill.load
  %.spill.load36 = load <8 x i64>, ptr %.spill10, align 64
  %115 = add <8 x i64> %.spill.load36, zeroinitializer
  %116 = add <8 x i64> zeroinitializer, %115
  %117 = add <8 x i64> zeroinitializer, %114
  %118 = mul <8 x i64> %116, splat (i64 4098)
  %119 = add <8 x i64> %118, %117
  %120 = extractvalue { ptr, i64 } %13, 0
  %121 = extractelement <8 x i64> %119, i32 0
  %122 = sub i64 %121, 0
  %123 = mul i64 %122, 4
  %buffer.contiguous.address = getelementptr i8, ptr %120, i64 %123
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address, <8 x i1> %55, <8 x float> zeroinitializer)
  %124 = add <8 x i64> splat (i64 2049), %114
  %125 = add <8 x i64> %118, %124
  %126 = extractvalue { ptr, i64 } %13, 0
  %127 = extractelement <8 x i64> %125, i32 0
  %128 = sub i64 %127, 0
  %129 = mul i64 %128, 4
  %buffer.contiguous.address37 = getelementptr i8, ptr %126, i64 %129
  %buffer.contiguous.load38 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address37, <8 x i1> %55, <8 x float> zeroinitializer)
  %130 = mul <8 x i64> %116, splat (i64 2049)
  %131 = add <8 x i64> %130, %117
  %132 = extractvalue { ptr, i64 } %19, 0
  %133 = extractelement <8 x i64> %131, i32 0
  %134 = sub i64 %133, 0
  %135 = mul i64 %134, 4
  %buffer.contiguous.address39 = getelementptr i8, ptr %132, i64 %135
  %buffer.contiguous.load40 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address39, <8 x i1> %55, <8 x float> zeroinitializer)
  %136 = extractvalue { ptr, i64 } %25, 0
  %137 = extractelement <8 x i64> %131, i32 0
  %138 = sub i64 %137, 0
  %139 = mul i64 %138, 4
  %buffer.contiguous.address41 = getelementptr i8, ptr %136, i64 %139
  %buffer.contiguous.load42 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address41, <8 x i1> %55, <8 x float> zeroinitializer)
  %140 = fmul <8 x float> %buffer.contiguous.load, %buffer.contiguous.load40
  %141 = fmul <8 x float> %buffer.contiguous.load38, %buffer.contiguous.load42
  %142 = fsub <8 x float> %140, %141
  %143 = extractvalue { ptr, i64 } %31, 0
  %144 = extractelement <8 x i64> %119, i32 0
  %145 = sub i64 %144, 0
  %146 = mul i64 %145, 4
  %buffer.contiguous.address43 = getelementptr i8, ptr %143, i64 %146
  call void @llvm.masked.store.v8f32.p0(<8 x float> %142, ptr align 1 %buffer.contiguous.address43, <8 x i1> %55)
  %147 = fmul <8 x float> %buffer.contiguous.load, %buffer.contiguous.load42
  %148 = fmul <8 x float> %buffer.contiguous.load38, %buffer.contiguous.load40
  %149 = fadd <8 x float> %147, %148
  %150 = extractvalue { ptr, i64 } %31, 0
  %151 = extractelement <8 x i64> %125, i32 0
  %152 = sub i64 %151, 0
  %153 = mul i64 %152, 4
  %buffer.contiguous.address44 = getelementptr i8, ptr %150, i64 %153
  call void @llvm.masked.store.v8f32.p0(<8 x float> %149, ptr align 1 %buffer.contiguous.address44, <8 x i1> %55)
  %.state45 = load i64, ptr %.slot, align 4
  %154 = add i64 %.state45, 1
  store i64 %154, ptr %.slot, align 4
  br label %direct.schedule.2

direct.schedule.4:                                ; preds = %direct.false32
  %.spill.load46 = load <8 x i64>, ptr %.spill, align 64
  %155 = icmp slt <8 x i64> %.spill.load46, splat (i64 1)
  %156 = and <8 x i1> %55, %155
  %157 = xor <8 x i1> %155, splat (i1 true)
  %158 = and <8 x i1> %55, %157
  %159 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %156)
  %160 = bitcast <8 x i1> %156 to i8
  %161 = call i8 @llvm.cttz.i8(i8 %160, i1 false)
  %162 = zext i8 %161 to i32
  %163 = select i1 %159, i32 %162, i32 0
  %.spill.load47 = load <8 x i64>, ptr %.spill, align 64
  %164 = add <8 x i64> splat (i64 2048), %.spill.load47
  %.spill.load48 = load <8 x i64>, ptr %.spill10, align 64
  %165 = add <8 x i64> %.spill.load48, zeroinitializer
  %166 = add <8 x i64> zeroinitializer, %165
  %167 = add <8 x i64> zeroinitializer, %164
  %168 = mul <8 x i64> %166, splat (i64 4098)
  %169 = add <8 x i64> %168, %167
  %170 = extractvalue { ptr, i64 } %13, 0
  %171 = select <8 x i1> %156, <8 x i64> %169, <8 x i64> zeroinitializer
  %172 = extractelement <8 x i64> %171, i32 %163
  %173 = zext i32 %163 to i64
  %174 = sub i64 %172, %173
  %175 = mul i64 %174, 4
  %buffer.contiguous.address49 = getelementptr i8, ptr %170, i64 %175
  %buffer.contiguous.load50 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address49, <8 x i1> %156, <8 x float> zeroinitializer)
  %176 = add <8 x i64> splat (i64 2049), %164
  %177 = add <8 x i64> %168, %176
  %178 = extractvalue { ptr, i64 } %13, 0
  %179 = select <8 x i1> %156, <8 x i64> %177, <8 x i64> zeroinitializer
  %180 = extractelement <8 x i64> %179, i32 %163
  %181 = zext i32 %163 to i64
  %182 = sub i64 %180, %181
  %183 = mul i64 %182, 4
  %buffer.contiguous.address51 = getelementptr i8, ptr %178, i64 %183
  %buffer.contiguous.load52 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address51, <8 x i1> %156, <8 x float> zeroinitializer)
  %184 = mul <8 x i64> %166, splat (i64 2049)
  %185 = add <8 x i64> %184, %167
  %186 = extractvalue { ptr, i64 } %19, 0
  %187 = select <8 x i1> %156, <8 x i64> %185, <8 x i64> zeroinitializer
  %188 = extractelement <8 x i64> %187, i32 %163
  %189 = zext i32 %163 to i64
  %190 = sub i64 %188, %189
  %191 = mul i64 %190, 4
  %buffer.contiguous.address53 = getelementptr i8, ptr %186, i64 %191
  %buffer.contiguous.load54 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address53, <8 x i1> %156, <8 x float> zeroinitializer)
  %192 = extractvalue { ptr, i64 } %25, 0
  %193 = select <8 x i1> %156, <8 x i64> %185, <8 x i64> zeroinitializer
  %194 = extractelement <8 x i64> %193, i32 %163
  %195 = zext i32 %163 to i64
  %196 = sub i64 %194, %195
  %197 = mul i64 %196, 4
  %buffer.contiguous.address55 = getelementptr i8, ptr %192, i64 %197
  %buffer.contiguous.load56 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address55, <8 x i1> %156, <8 x float> zeroinitializer)
  %198 = fmul <8 x float> %buffer.contiguous.load50, %buffer.contiguous.load54
  %199 = fmul <8 x float> %buffer.contiguous.load52, %buffer.contiguous.load56
  %200 = fsub <8 x float> %198, %199
  %201 = extractvalue { ptr, i64 } %31, 0
  %202 = extractelement <8 x i64> %169, i32 %163
  %203 = zext i32 %163 to i64
  %204 = sub i64 %202, %203
  %205 = mul i64 %204, 4
  %buffer.contiguous.address57 = getelementptr i8, ptr %201, i64 %205
  call void @llvm.masked.store.v8f32.p0(<8 x float> %200, ptr align 1 %buffer.contiguous.address57, <8 x i1> %156)
  %206 = fmul <8 x float> %buffer.contiguous.load50, %buffer.contiguous.load56
  %207 = fmul <8 x float> %buffer.contiguous.load52, %buffer.contiguous.load54
  %208 = fadd <8 x float> %206, %207
  %209 = extractvalue { ptr, i64 } %31, 0
  %210 = extractelement <8 x i64> %177, i32 %163
  %211 = zext i32 %163 to i64
  %212 = sub i64 %210, %211
  %213 = mul i64 %212, 4
  %buffer.contiguous.address58 = getelementptr i8, ptr %209, i64 %213
  call void @llvm.masked.store.v8f32.p0(<8 x float> %208, ptr align 1 %buffer.contiguous.address58, <8 x i1> %156)
  %214 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %158)
  %215 = bitcast <8 x i1> %158 to i8
  %216 = call i8 @llvm.cttz.i8(i8 %215, i1 false)
  %217 = zext i8 %216 to i32
  %218 = select i1 %214, i32 %217, i32 0
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.35, %direct.schedule.4
  ret void

direct.schedule.7:                                ; preds = %direct.false
  %219 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %219, 0
  %222 = select <8 x i1> %55, <8 x ptr> %220, <8 x ptr> %221
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %224 = extractvalue { <8 x ptr>, <8 x i64> } %219, 1
  %225 = select <8 x i1> %55, <8 x i64> %223, <8 x i64> %224
  %226 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %222, 0
  %227 = insertvalue { <8 x ptr>, <8 x i64> } %226, <8 x i64> %225, 1
  store { <8 x ptr>, <8 x i64> } %227, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot11, align 4
  br label %direct.schedule.8

direct.schedule.8:                                ; preds = %direct.schedule.9, %direct.schedule.7
  %.state59 = load i64, ptr %.slot11, align 4
  %228 = icmp slt i64 %.state59, 256
  br i1 %228, label %direct.true60, label %direct.false61

direct.schedule.9:                                ; preds = %direct.true60
  %.state62 = load i64, ptr %.slot11, align 4
  %229 = mul i64 %.state62, 8
  %.splatinsert63 = insertelement <8 x i64> poison, i64 %229, i64 0
  %.splat64 = shufflevector <8 x i64> %.splatinsert63, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load65 = load <8 x i64>, ptr %.spill, align 64
  %230 = add <8 x i64> %.splat64, %.spill.load65
  %.spill.load66 = load <8 x i64>, ptr %.spill10, align 64
  %231 = add <8 x i64> %.spill.load66, zeroinitializer
  %232 = add <8 x i64> zeroinitializer, %231
  %233 = add <8 x i64> zeroinitializer, %230
  %234 = mul <8 x i64> %232, splat (i64 4098)
  %235 = add <8 x i64> %234, %233
  %236 = extractvalue { ptr, i64 } %13, 0
  %237 = extractelement <8 x i64> %235, i32 0
  %238 = sub i64 %237, 0
  %239 = mul i64 %238, 4
  %buffer.contiguous.address67 = getelementptr i8, ptr %236, i64 %239
  %buffer.contiguous.load68 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address67, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %240 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state69 = load i64, ptr %.slot11, align 4
  %.splatinsert70 = insertelement <8 x i64> poison, i64 %.state69, i64 0
  %.splat71 = shufflevector <8 x i64> %.splatinsert70, <8 x i64> poison, <8 x i32> zeroinitializer
  %242 = mul <8 x i64> %.splat71, splat (i64 32)
  %243 = add <8 x i64> %241, %242
  %244 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %240, 0
  %245 = insertvalue { <8 x ptr>, <8 x i64> } %244, <8 x i64> %243, 1
  %246 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %247 = extractvalue { <8 x ptr>, <8 x i64> } %245, 1
  %248 = extractelement <8 x ptr> %246, i32 0
  %249 = extractelement <8 x i64> %247, i32 0
  %250 = sub i64 %249, 0
  %251 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %252 = select i1 %251, i64 %250, i64 0
  %private.contiguous.address = getelementptr i8, ptr %248, i64 %252
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %253 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load68, <8 x float> %private.contiguous.preserve
  store <8 x float> %253, ptr %private.contiguous.address, align 4
  %.state72 = load i64, ptr %.slot11, align 4
  %254 = add i64 %.state72, 1
  store i64 %254, ptr %.slot11, align 4
  br label %direct.schedule.8

direct.schedule.10:                               ; preds = %direct.false61
  %.spill.load73 = load <8 x i64>, ptr %.spill, align 64
  %255 = icmp slt <8 x i64> %.spill.load73, splat (i64 1)
  %256 = load <8 x i1>, ptr %.spill12, align 1
  %257 = select <8 x i1> %55, <8 x i1> %255, <8 x i1> %256
  store <8 x i1> %257, ptr %.spill12, align 1
  %258 = and <8 x i1> %55, %255
  %259 = xor <8 x i1> %255, splat (i1 true)
  %260 = and <8 x i1> %55, %259
  %261 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %258)
  %262 = bitcast <8 x i1> %258 to i8
  %263 = call i8 @llvm.cttz.i8(i8 %262, i1 false)
  %264 = zext i8 %263 to i32
  %265 = select i1 %261, i32 %264, i32 0
  %.spill.load74 = load <8 x i64>, ptr %.spill, align 64
  %266 = add <8 x i64> splat (i64 2048), %.spill.load74
  %.spill.load75 = load <8 x i64>, ptr %.spill10, align 64
  %267 = add <8 x i64> %.spill.load75, zeroinitializer
  %268 = add <8 x i64> zeroinitializer, %267
  %269 = add <8 x i64> zeroinitializer, %266
  %270 = mul <8 x i64> %268, splat (i64 4098)
  %271 = add <8 x i64> %270, %269
  %272 = extractvalue { ptr, i64 } %13, 0
  %273 = select <8 x i1> %258, <8 x i64> %271, <8 x i64> zeroinitializer
  %274 = extractelement <8 x i64> %273, i32 %265
  %275 = zext i32 %265 to i64
  %276 = sub i64 %274, %275
  %277 = mul i64 %276, 4
  %buffer.contiguous.address76 = getelementptr i8, ptr %272, i64 %277
  %buffer.contiguous.load77 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address76, <8 x i1> %258, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load78 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %278 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load78, 0
  %279 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load78, 1
  %280 = add <8 x i64> %279, splat (i64 8192)
  %281 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %278, 0
  %282 = insertvalue { <8 x ptr>, <8 x i64> } %281, <8 x i64> %280, 1
  %283 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %284 = extractvalue { <8 x ptr>, <8 x i64> } %282, 1
  %285 = extractelement <8 x ptr> %283, i32 0
  %286 = extractelement <8 x i64> %284, i32 %265
  %287 = zext i32 %265 to i64
  %288 = mul i64 %287, 4
  %289 = sub i64 %286, %288
  %290 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %258)
  %291 = select i1 %290, i64 %289, i64 0
  %private.contiguous.address79 = getelementptr i8, ptr %285, i64 %291
  %private.contiguous.preserve80 = load <8 x float>, ptr %private.contiguous.address79, align 4
  %292 = select <8 x i1> %258, <8 x float> %buffer.contiguous.load77, <8 x float> %private.contiguous.preserve80
  store <8 x float> %292, ptr %private.contiguous.address79, align 4
  %293 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %260)
  %294 = bitcast <8 x i1> %260 to i8
  %295 = call i8 @llvm.cttz.i8(i8 %294, i1 false)
  %296 = zext i8 %295 to i32
  %297 = select i1 %293, i32 %296, i32 0
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.schedule.10
  %298 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %299 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %298, 0
  %301 = select <8 x i1> %55, <8 x ptr> %299, <8 x ptr> %300
  %302 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %303 = extractvalue { <8 x ptr>, <8 x i64> } %298, 1
  %304 = select <8 x i1> %55, <8 x i64> %302, <8 x i64> %303
  %305 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %301, 0
  %306 = insertvalue { <8 x ptr>, <8 x i64> } %305, <8 x i64> %304, 1
  store { <8 x ptr>, <8 x i64> } %306, ptr %tile_snapshot.spill13, align 64
  %307 = load <8 x i64>, ptr %.slot14, align 64
  %308 = select <8 x i1> %55, <8 x i64> zeroinitializer, <8 x i64> %307
  store <8 x i64> %308, ptr %.slot14, align 64
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state81 = load <8 x i64>, ptr %.slot14, align 64
  %309 = icmp slt <8 x i64> %.state81, splat (i64 256)
  %310 = extractelement <8 x i1> %309, i32 0
  br i1 %310, label %direct.true82, label %direct.false83

direct.schedule.14:                               ; preds = %direct.true82
  %.state84 = load <8 x i64>, ptr %.slot14, align 64
  %311 = mul <8 x i64> %.state84, splat (i64 8)
  %.spill.load85 = load <8 x i64>, ptr %.spill, align 64
  %312 = add <8 x i64> %311, %.spill.load85
  %.spill.load86 = load <8 x i64>, ptr %.spill10, align 64
  %313 = add <8 x i64> %.spill.load86, zeroinitializer
  %314 = add <8 x i64> zeroinitializer, %313
  %315 = add <8 x i64> splat (i64 2049), %312
  %316 = mul <8 x i64> %314, splat (i64 4098)
  %317 = add <8 x i64> %316, %315
  %318 = extractvalue { ptr, i64 } %13, 0
  %319 = extractelement <8 x i64> %317, i32 0
  %320 = sub i64 %319, 0
  %321 = mul i64 %320, 4
  %buffer.contiguous.address87 = getelementptr i8, ptr %318, i64 %321
  %buffer.contiguous.load88 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address87, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load89 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load89, 0
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load89, 1
  %.state90 = load <8 x i64>, ptr %.slot14, align 64
  %324 = mul <8 x i64> %.state90, splat (i64 32)
  %325 = add <8 x i64> %323, %324
  %326 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %322, 0
  %327 = insertvalue { <8 x ptr>, <8 x i64> } %326, <8 x i64> %325, 1
  %328 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %327, 1
  %330 = extractelement <8 x ptr> %328, i32 0
  %331 = extractelement <8 x i64> %329, i32 0
  %332 = sub i64 %331, 0
  %333 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %334 = select i1 %333, i64 %332, i64 0
  %private.contiguous.address91 = getelementptr i8, ptr %330, i64 %334
  %private.contiguous.preserve92 = load <8 x float>, ptr %private.contiguous.address91, align 4
  %335 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load88, <8 x float> %private.contiguous.preserve92
  store <8 x float> %335, ptr %private.contiguous.address91, align 4
  %.state93 = load <8 x i64>, ptr %.slot14, align 64
  %336 = add <8 x i64> %.state93, splat (i64 1)
  %337 = load <8 x i64>, ptr %.slot14, align 64
  %338 = select <8 x i1> %55, <8 x i64> %336, <8 x i64> %337
  store <8 x i64> %338, ptr %.slot14, align 64
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false83
  %.spill.load94 = load <8 x i1>, ptr %.spill12, align 1
  %339 = and <8 x i1> %55, %.spill.load94
  %340 = xor <8 x i1> %.spill.load94, splat (i1 true)
  %341 = and <8 x i1> %55, %340
  %342 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %339)
  %343 = bitcast <8 x i1> %339 to i8
  %344 = call i8 @llvm.cttz.i8(i8 %343, i1 false)
  %345 = zext i8 %344 to i32
  %346 = select i1 %342, i32 %345, i32 0
  %.spill.load95 = load <8 x i64>, ptr %.spill, align 64
  %347 = add <8 x i64> splat (i64 2048), %.spill.load95
  %.spill.load96 = load <8 x i64>, ptr %.spill10, align 64
  %348 = add <8 x i64> %.spill.load96, zeroinitializer
  %349 = add <8 x i64> zeroinitializer, %348
  %350 = add <8 x i64> splat (i64 2049), %347
  %351 = mul <8 x i64> %349, splat (i64 4098)
  %352 = add <8 x i64> %351, %350
  %353 = extractvalue { ptr, i64 } %13, 0
  %354 = select <8 x i1> %339, <8 x i64> %352, <8 x i64> zeroinitializer
  %355 = extractelement <8 x i64> %354, i32 %346
  %356 = zext i32 %346 to i64
  %357 = sub i64 %355, %356
  %358 = mul i64 %357, 4
  %buffer.contiguous.address97 = getelementptr i8, ptr %353, i64 %358
  %buffer.contiguous.load98 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address97, <8 x i1> %339, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load99 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %359 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load99, 0
  %360 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load99, 1
  %361 = add <8 x i64> %360, splat (i64 8192)
  %362 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %359, 0
  %363 = insertvalue { <8 x ptr>, <8 x i64> } %362, <8 x i64> %361, 1
  %364 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %365 = extractvalue { <8 x ptr>, <8 x i64> } %363, 1
  %366 = extractelement <8 x ptr> %364, i32 0
  %367 = extractelement <8 x i64> %365, i32 %346
  %368 = zext i32 %346 to i64
  %369 = mul i64 %368, 4
  %370 = sub i64 %367, %369
  %371 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %339)
  %372 = select i1 %371, i64 %370, i64 0
  %private.contiguous.address100 = getelementptr i8, ptr %366, i64 %372
  %private.contiguous.preserve101 = load <8 x float>, ptr %private.contiguous.address100, align 4
  %373 = select <8 x i1> %339, <8 x float> %buffer.contiguous.load98, <8 x float> %private.contiguous.preserve101
  store <8 x float> %373, ptr %private.contiguous.address100, align 4
  %374 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %341)
  %375 = bitcast <8 x i1> %341 to i8
  %376 = call i8 @llvm.cttz.i8(i8 %375, i1 false)
  %377 = zext i8 %376 to i32
  %378 = select i1 %374, i32 %377, i32 0
  br label %direct.schedule.17

direct.schedule.17:                               ; preds = %direct.schedule.15
  %379 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %380 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %381 = extractvalue { <8 x ptr>, <8 x i64> } %379, 0
  %382 = select <8 x i1> %55, <8 x ptr> %380, <8 x ptr> %381
  %383 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %384 = extractvalue { <8 x ptr>, <8 x i64> } %379, 1
  %385 = select <8 x i1> %55, <8 x i64> %383, <8 x i64> %384
  %386 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %382, 0
  %387 = insertvalue { <8 x ptr>, <8 x i64> } %386, <8 x i64> %385, 1
  store { <8 x ptr>, <8 x i64> } %387, ptr %tile_snapshot.spill15, align 64
  %388 = load <8 x i64>, ptr %.slot16, align 64
  %389 = select <8 x i1> %55, <8 x i64> zeroinitializer, <8 x i64> %388
  store <8 x i64> %389, ptr %.slot16, align 64
  br label %direct.schedule.18

direct.schedule.18:                               ; preds = %direct.schedule.19, %direct.schedule.17
  %.state102 = load <8 x i64>, ptr %.slot16, align 64
  %390 = icmp slt <8 x i64> %.state102, splat (i64 256)
  %391 = extractelement <8 x i1> %390, i32 0
  br i1 %391, label %direct.true103, label %direct.false104

direct.schedule.19:                               ; preds = %direct.true103
  %.state105 = load <8 x i64>, ptr %.slot16, align 64
  %392 = mul <8 x i64> %.state105, splat (i64 8)
  %.spill.load106 = load <8 x i64>, ptr %.spill, align 64
  %393 = add <8 x i64> %392, %.spill.load106
  %.spill.load107 = load <8 x i64>, ptr %.spill10, align 64
  %394 = add <8 x i64> %.spill.load107, zeroinitializer
  %395 = add <8 x i64> zeroinitializer, %394
  %396 = add <8 x i64> zeroinitializer, %393
  %397 = mul <8 x i64> %395, splat (i64 2049)
  %398 = add <8 x i64> %397, %396
  %399 = extractvalue { ptr, i64 } %19, 0
  %400 = extractelement <8 x i64> %398, i32 0
  %401 = sub i64 %400, 0
  %402 = mul i64 %401, 4
  %buffer.contiguous.address108 = getelementptr i8, ptr %399, i64 %402
  %buffer.contiguous.load109 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address108, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load110 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %403 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load110, 0
  %404 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load110, 1
  %.state111 = load <8 x i64>, ptr %.slot16, align 64
  %405 = mul <8 x i64> %.state111, splat (i64 32)
  %406 = add <8 x i64> %404, %405
  %407 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %403, 0
  %408 = insertvalue { <8 x ptr>, <8 x i64> } %407, <8 x i64> %406, 1
  %409 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %410 = extractvalue { <8 x ptr>, <8 x i64> } %408, 1
  %411 = extractelement <8 x ptr> %409, i32 0
  %412 = extractelement <8 x i64> %410, i32 0
  %413 = sub i64 %412, 0
  %414 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %415 = select i1 %414, i64 %413, i64 0
  %private.contiguous.address112 = getelementptr i8, ptr %411, i64 %415
  %private.contiguous.preserve113 = load <8 x float>, ptr %private.contiguous.address112, align 4
  %416 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load109, <8 x float> %private.contiguous.preserve113
  store <8 x float> %416, ptr %private.contiguous.address112, align 4
  %.state114 = load <8 x i64>, ptr %.slot16, align 64
  %417 = add <8 x i64> %.state114, splat (i64 1)
  %418 = load <8 x i64>, ptr %.slot16, align 64
  %419 = select <8 x i1> %55, <8 x i64> %417, <8 x i64> %418
  store <8 x i64> %419, ptr %.slot16, align 64
  br label %direct.schedule.18

direct.schedule.20:                               ; preds = %direct.false104
  %.spill.load115 = load <8 x i1>, ptr %.spill12, align 1
  %420 = and <8 x i1> %55, %.spill.load115
  %421 = xor <8 x i1> %.spill.load115, splat (i1 true)
  %422 = and <8 x i1> %55, %421
  %423 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %420)
  %424 = bitcast <8 x i1> %420 to i8
  %425 = call i8 @llvm.cttz.i8(i8 %424, i1 false)
  %426 = zext i8 %425 to i32
  %427 = select i1 %423, i32 %426, i32 0
  %.spill.load116 = load <8 x i64>, ptr %.spill, align 64
  %428 = add <8 x i64> splat (i64 2048), %.spill.load116
  %.spill.load117 = load <8 x i64>, ptr %.spill10, align 64
  %429 = add <8 x i64> %.spill.load117, zeroinitializer
  %430 = add <8 x i64> zeroinitializer, %429
  %431 = add <8 x i64> zeroinitializer, %428
  %432 = mul <8 x i64> %430, splat (i64 2049)
  %433 = add <8 x i64> %432, %431
  %434 = extractvalue { ptr, i64 } %19, 0
  %435 = select <8 x i1> %420, <8 x i64> %433, <8 x i64> zeroinitializer
  %436 = extractelement <8 x i64> %435, i32 %427
  %437 = zext i32 %427 to i64
  %438 = sub i64 %436, %437
  %439 = mul i64 %438, 4
  %buffer.contiguous.address118 = getelementptr i8, ptr %434, i64 %439
  %buffer.contiguous.load119 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address118, <8 x i1> %420, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load120 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %440 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load120, 0
  %441 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load120, 1
  %442 = add <8 x i64> %441, splat (i64 8192)
  %443 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %440, 0
  %444 = insertvalue { <8 x ptr>, <8 x i64> } %443, <8 x i64> %442, 1
  %445 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %446 = extractvalue { <8 x ptr>, <8 x i64> } %444, 1
  %447 = extractelement <8 x ptr> %445, i32 0
  %448 = extractelement <8 x i64> %446, i32 %427
  %449 = zext i32 %427 to i64
  %450 = mul i64 %449, 4
  %451 = sub i64 %448, %450
  %452 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %420)
  %453 = select i1 %452, i64 %451, i64 0
  %private.contiguous.address121 = getelementptr i8, ptr %447, i64 %453
  %private.contiguous.preserve122 = load <8 x float>, ptr %private.contiguous.address121, align 4
  %454 = select <8 x i1> %420, <8 x float> %buffer.contiguous.load119, <8 x float> %private.contiguous.preserve122
  store <8 x float> %454, ptr %private.contiguous.address121, align 4
  %455 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %422)
  %456 = bitcast <8 x i1> %422 to i8
  %457 = call i8 @llvm.cttz.i8(i8 %456, i1 false)
  %458 = zext i8 %457 to i32
  %459 = select i1 %455, i32 %458, i32 0
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.20
  %460 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %461 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %462 = extractvalue { <8 x ptr>, <8 x i64> } %460, 0
  %463 = select <8 x i1> %55, <8 x ptr> %461, <8 x ptr> %462
  %464 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %465 = extractvalue { <8 x ptr>, <8 x i64> } %460, 1
  %466 = select <8 x i1> %55, <8 x i64> %464, <8 x i64> %465
  %467 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %463, 0
  %468 = insertvalue { <8 x ptr>, <8 x i64> } %467, <8 x i64> %466, 1
  store { <8 x ptr>, <8 x i64> } %468, ptr %tile_snapshot.spill17, align 64
  %469 = load <8 x i64>, ptr %.slot18, align 64
  %470 = select <8 x i1> %55, <8 x i64> zeroinitializer, <8 x i64> %469
  store <8 x i64> %470, ptr %.slot18, align 64
  br label %direct.schedule.23

direct.schedule.23:                               ; preds = %direct.schedule.24, %direct.schedule.22
  %.state123 = load <8 x i64>, ptr %.slot18, align 64
  %471 = icmp slt <8 x i64> %.state123, splat (i64 256)
  %472 = extractelement <8 x i1> %471, i32 0
  br i1 %472, label %direct.true124, label %direct.false125

direct.schedule.24:                               ; preds = %direct.true124
  %.state126 = load <8 x i64>, ptr %.slot18, align 64
  %473 = mul <8 x i64> %.state126, splat (i64 8)
  %.spill.load127 = load <8 x i64>, ptr %.spill, align 64
  %474 = add <8 x i64> %473, %.spill.load127
  %.spill.load128 = load <8 x i64>, ptr %.spill10, align 64
  %475 = add <8 x i64> %.spill.load128, zeroinitializer
  %476 = add <8 x i64> zeroinitializer, %475
  %477 = add <8 x i64> zeroinitializer, %474
  %478 = mul <8 x i64> %476, splat (i64 2049)
  %479 = add <8 x i64> %478, %477
  %480 = extractvalue { ptr, i64 } %25, 0
  %481 = extractelement <8 x i64> %479, i32 0
  %482 = sub i64 %481, 0
  %483 = mul i64 %482, 4
  %buffer.contiguous.address129 = getelementptr i8, ptr %480, i64 %483
  %buffer.contiguous.load130 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address129, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load131 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %484 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load131, 0
  %485 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load131, 1
  %.state132 = load <8 x i64>, ptr %.slot18, align 64
  %486 = mul <8 x i64> %.state132, splat (i64 32)
  %487 = add <8 x i64> %485, %486
  %488 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %484, 0
  %489 = insertvalue { <8 x ptr>, <8 x i64> } %488, <8 x i64> %487, 1
  %490 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %491 = extractvalue { <8 x ptr>, <8 x i64> } %489, 1
  %492 = extractelement <8 x ptr> %490, i32 0
  %493 = extractelement <8 x i64> %491, i32 0
  %494 = sub i64 %493, 0
  %495 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %496 = select i1 %495, i64 %494, i64 0
  %private.contiguous.address133 = getelementptr i8, ptr %492, i64 %496
  %private.contiguous.preserve134 = load <8 x float>, ptr %private.contiguous.address133, align 4
  %497 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load130, <8 x float> %private.contiguous.preserve134
  store <8 x float> %497, ptr %private.contiguous.address133, align 4
  %.state135 = load <8 x i64>, ptr %.slot18, align 64
  %498 = add <8 x i64> %.state135, splat (i64 1)
  %499 = load <8 x i64>, ptr %.slot18, align 64
  %500 = select <8 x i1> %55, <8 x i64> %498, <8 x i64> %499
  store <8 x i64> %500, ptr %.slot18, align 64
  br label %direct.schedule.23

direct.schedule.25:                               ; preds = %direct.false125
  %.spill.load136 = load <8 x i1>, ptr %.spill12, align 1
  %501 = and <8 x i1> %55, %.spill.load136
  %502 = xor <8 x i1> %.spill.load136, splat (i1 true)
  %503 = and <8 x i1> %55, %502
  %504 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %501)
  %505 = bitcast <8 x i1> %501 to i8
  %506 = call i8 @llvm.cttz.i8(i8 %505, i1 false)
  %507 = zext i8 %506 to i32
  %508 = select i1 %504, i32 %507, i32 0
  %.spill.load137 = load <8 x i64>, ptr %.spill, align 64
  %509 = add <8 x i64> splat (i64 2048), %.spill.load137
  %.spill.load138 = load <8 x i64>, ptr %.spill10, align 64
  %510 = add <8 x i64> %.spill.load138, zeroinitializer
  %511 = add <8 x i64> zeroinitializer, %510
  %512 = add <8 x i64> zeroinitializer, %509
  %513 = mul <8 x i64> %511, splat (i64 2049)
  %514 = add <8 x i64> %513, %512
  %515 = extractvalue { ptr, i64 } %25, 0
  %516 = select <8 x i1> %501, <8 x i64> %514, <8 x i64> zeroinitializer
  %517 = extractelement <8 x i64> %516, i32 %508
  %518 = zext i32 %508 to i64
  %519 = sub i64 %517, %518
  %520 = mul i64 %519, 4
  %buffer.contiguous.address139 = getelementptr i8, ptr %515, i64 %520
  %buffer.contiguous.load140 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address139, <8 x i1> %501, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load141 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %521 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 0
  %522 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 1
  %523 = add <8 x i64> %522, splat (i64 8192)
  %524 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %521, 0
  %525 = insertvalue { <8 x ptr>, <8 x i64> } %524, <8 x i64> %523, 1
  %526 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %527 = extractvalue { <8 x ptr>, <8 x i64> } %525, 1
  %528 = extractelement <8 x ptr> %526, i32 0
  %529 = extractelement <8 x i64> %527, i32 %508
  %530 = zext i32 %508 to i64
  %531 = mul i64 %530, 4
  %532 = sub i64 %529, %531
  %533 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %501)
  %534 = select i1 %533, i64 %532, i64 0
  %private.contiguous.address142 = getelementptr i8, ptr %528, i64 %534
  %private.contiguous.preserve143 = load <8 x float>, ptr %private.contiguous.address142, align 4
  %535 = select <8 x i1> %501, <8 x float> %buffer.contiguous.load140, <8 x float> %private.contiguous.preserve143
  store <8 x float> %535, ptr %private.contiguous.address142, align 4
  %536 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %503)
  %537 = bitcast <8 x i1> %503 to i8
  %538 = call i8 @llvm.cttz.i8(i8 %537, i1 false)
  %539 = zext i8 %538 to i32
  %540 = select i1 %536, i32 %539, i32 0
  br label %direct.schedule.27

direct.schedule.27:                               ; preds = %direct.schedule.25
  %541 = load <8 x i64>, ptr %.slot19, align 64
  %542 = select <8 x i1> %55, <8 x i64> zeroinitializer, <8 x i64> %541
  store <8 x i64> %542, ptr %.slot19, align 64
  br label %direct.schedule.28

direct.schedule.28:                               ; preds = %direct.schedule.29, %direct.schedule.27
  %.state144 = load <8 x i64>, ptr %.slot19, align 64
  %543 = icmp slt <8 x i64> %.state144, splat (i64 256)
  %544 = extractelement <8 x i1> %543, i32 0
  br i1 %544, label %direct.true145, label %direct.false146

direct.schedule.29:                               ; preds = %direct.true145
  %.state147 = load <8 x i64>, ptr %.slot19, align 64
  %545 = mul <8 x i64> %.state147, splat (i64 8)
  %.spill.load148 = load <8 x i64>, ptr %.spill, align 64
  %546 = add <8 x i64> %545, %.spill.load148
  %.spill.load149 = load <8 x i64>, ptr %.spill10, align 64
  %547 = add <8 x i64> %.spill.load149, zeroinitializer
  %548 = add <8 x i64> zeroinitializer, %547
  %549 = add <8 x i64> zeroinitializer, %546
  %550 = mul <8 x i64> %548, splat (i64 4098)
  %551 = add <8 x i64> %550, %549
  %tile_snapshot.spill.load150 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %552 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load150, 0
  %553 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load150, 1
  %.state151 = load <8 x i64>, ptr %.slot19, align 64
  %554 = mul <8 x i64> %.state151, splat (i64 32)
  %555 = add <8 x i64> %553, %554
  %556 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %552, 0
  %557 = insertvalue { <8 x ptr>, <8 x i64> } %556, <8 x i64> %555, 1
  %558 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %559 = extractvalue { <8 x ptr>, <8 x i64> } %557, 1
  %560 = extractelement <8 x ptr> %558, i32 0
  %561 = extractelement <8 x i64> %559, i32 0
  %562 = sub i64 %561, 0
  %563 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %564 = select i1 %563, i64 %562, i64 0
  %private.contiguous.address152 = getelementptr i8, ptr %560, i64 %564
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address152, align 4
  %565 = select <8 x i1> %55, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load153 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %566 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load153, 0
  %567 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load153, 1
  %.state154 = load <8 x i64>, ptr %.slot19, align 64
  %568 = mul <8 x i64> %.state154, splat (i64 32)
  %569 = add <8 x i64> %567, %568
  %570 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %566, 0
  %571 = insertvalue { <8 x ptr>, <8 x i64> } %570, <8 x i64> %569, 1
  %572 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %573 = extractvalue { <8 x ptr>, <8 x i64> } %571, 1
  %574 = extractelement <8 x ptr> %572, i32 0
  %575 = extractelement <8 x i64> %573, i32 0
  %576 = sub i64 %575, 0
  %577 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %578 = select i1 %577, i64 %576, i64 0
  %private.contiguous.address155 = getelementptr i8, ptr %574, i64 %578
  %private.contiguous.load156 = load <8 x float>, ptr %private.contiguous.address155, align 4
  %579 = select <8 x i1> %55, <8 x float> %private.contiguous.load156, <8 x float> zeroinitializer
  %580 = fmul <8 x float> %565, %579
  %tile_snapshot.spill.load157 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %581 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load157, 0
  %582 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load157, 1
  %.state158 = load <8 x i64>, ptr %.slot19, align 64
  %583 = mul <8 x i64> %.state158, splat (i64 32)
  %584 = add <8 x i64> %582, %583
  %585 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %581, 0
  %586 = insertvalue { <8 x ptr>, <8 x i64> } %585, <8 x i64> %584, 1
  %587 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %588 = extractvalue { <8 x ptr>, <8 x i64> } %586, 1
  %589 = extractelement <8 x ptr> %587, i32 0
  %590 = extractelement <8 x i64> %588, i32 0
  %591 = sub i64 %590, 0
  %592 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %593 = select i1 %592, i64 %591, i64 0
  %private.contiguous.address159 = getelementptr i8, ptr %589, i64 %593
  %private.contiguous.load160 = load <8 x float>, ptr %private.contiguous.address159, align 4
  %594 = select <8 x i1> %55, <8 x float> %private.contiguous.load160, <8 x float> zeroinitializer
  %tile_snapshot.spill.load161 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %595 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load161, 0
  %596 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load161, 1
  %.state162 = load <8 x i64>, ptr %.slot19, align 64
  %597 = mul <8 x i64> %.state162, splat (i64 32)
  %598 = add <8 x i64> %596, %597
  %599 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %595, 0
  %600 = insertvalue { <8 x ptr>, <8 x i64> } %599, <8 x i64> %598, 1
  %601 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %602 = extractvalue { <8 x ptr>, <8 x i64> } %600, 1
  %603 = extractelement <8 x ptr> %601, i32 0
  %604 = extractelement <8 x i64> %602, i32 0
  %605 = sub i64 %604, 0
  %606 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %607 = select i1 %606, i64 %605, i64 0
  %private.contiguous.address163 = getelementptr i8, ptr %603, i64 %607
  %private.contiguous.load164 = load <8 x float>, ptr %private.contiguous.address163, align 4
  %608 = select <8 x i1> %55, <8 x float> %private.contiguous.load164, <8 x float> zeroinitializer
  %609 = fmul <8 x float> %594, %608
  %610 = fsub <8 x float> %580, %609
  %611 = extractvalue { ptr, i64 } %31, 0
  %612 = extractelement <8 x i64> %551, i32 0
  %613 = sub i64 %612, 0
  %614 = mul i64 %613, 4
  %buffer.contiguous.address165 = getelementptr i8, ptr %611, i64 %614
  call void @llvm.masked.store.v8f32.p0(<8 x float> %610, ptr align 1 %buffer.contiguous.address165, <8 x i1> %55)
  %.state166 = load <8 x i64>, ptr %.slot19, align 64
  %615 = add <8 x i64> %.state166, splat (i64 1)
  %616 = load <8 x i64>, ptr %.slot19, align 64
  %617 = select <8 x i1> %55, <8 x i64> %615, <8 x i64> %616
  store <8 x i64> %617, ptr %.slot19, align 64
  br label %direct.schedule.28

direct.schedule.30:                               ; preds = %direct.false146
  %.spill.load167 = load <8 x i1>, ptr %.spill12, align 1
  %618 = and <8 x i1> %55, %.spill.load167
  %619 = xor <8 x i1> %.spill.load167, splat (i1 true)
  %620 = and <8 x i1> %55, %619
  %621 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %618)
  %622 = bitcast <8 x i1> %618 to i8
  %623 = call i8 @llvm.cttz.i8(i8 %622, i1 false)
  %624 = zext i8 %623 to i32
  %625 = select i1 %621, i32 %624, i32 0
  %.spill.load168 = load <8 x i64>, ptr %.spill, align 64
  %626 = add <8 x i64> splat (i64 2048), %.spill.load168
  %.spill.load169 = load <8 x i64>, ptr %.spill10, align 64
  %627 = add <8 x i64> %.spill.load169, zeroinitializer
  %628 = add <8 x i64> zeroinitializer, %627
  %629 = add <8 x i64> zeroinitializer, %626
  %630 = mul <8 x i64> %628, splat (i64 4098)
  %631 = add <8 x i64> %630, %629
  %tile_snapshot.spill.load170 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %632 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load170, 0
  %633 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load170, 1
  %634 = add <8 x i64> %633, splat (i64 8192)
  %635 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %632, 0
  %636 = insertvalue { <8 x ptr>, <8 x i64> } %635, <8 x i64> %634, 1
  %637 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %638 = extractvalue { <8 x ptr>, <8 x i64> } %636, 1
  %639 = extractelement <8 x ptr> %637, i32 0
  %640 = extractelement <8 x i64> %638, i32 %625
  %641 = zext i32 %625 to i64
  %642 = mul i64 %641, 4
  %643 = sub i64 %640, %642
  %644 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %618)
  %645 = select i1 %644, i64 %643, i64 0
  %private.contiguous.address171 = getelementptr i8, ptr %639, i64 %645
  %private.contiguous.load172 = load <8 x float>, ptr %private.contiguous.address171, align 4
  %646 = select <8 x i1> %618, <8 x float> %private.contiguous.load172, <8 x float> zeroinitializer
  %tile_snapshot.spill.load173 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %647 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load173, 0
  %648 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load173, 1
  %649 = add <8 x i64> %648, splat (i64 8192)
  %650 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %647, 0
  %651 = insertvalue { <8 x ptr>, <8 x i64> } %650, <8 x i64> %649, 1
  %652 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %653 = extractvalue { <8 x ptr>, <8 x i64> } %651, 1
  %654 = extractelement <8 x ptr> %652, i32 0
  %655 = extractelement <8 x i64> %653, i32 %625
  %656 = zext i32 %625 to i64
  %657 = mul i64 %656, 4
  %658 = sub i64 %655, %657
  %659 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %618)
  %660 = select i1 %659, i64 %658, i64 0
  %private.contiguous.address174 = getelementptr i8, ptr %654, i64 %660
  %private.contiguous.load175 = load <8 x float>, ptr %private.contiguous.address174, align 4
  %661 = select <8 x i1> %618, <8 x float> %private.contiguous.load175, <8 x float> zeroinitializer
  %662 = fmul <8 x float> %646, %661
  %tile_snapshot.spill.load176 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %663 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load176, 0
  %664 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load176, 1
  %665 = add <8 x i64> %664, splat (i64 8192)
  %666 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %663, 0
  %667 = insertvalue { <8 x ptr>, <8 x i64> } %666, <8 x i64> %665, 1
  %668 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %669 = extractvalue { <8 x ptr>, <8 x i64> } %667, 1
  %670 = extractelement <8 x ptr> %668, i32 0
  %671 = extractelement <8 x i64> %669, i32 %625
  %672 = zext i32 %625 to i64
  %673 = mul i64 %672, 4
  %674 = sub i64 %671, %673
  %675 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %618)
  %676 = select i1 %675, i64 %674, i64 0
  %private.contiguous.address177 = getelementptr i8, ptr %670, i64 %676
  %private.contiguous.load178 = load <8 x float>, ptr %private.contiguous.address177, align 4
  %677 = select <8 x i1> %618, <8 x float> %private.contiguous.load178, <8 x float> zeroinitializer
  %tile_snapshot.spill.load179 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %678 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load179, 0
  %679 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load179, 1
  %680 = add <8 x i64> %679, splat (i64 8192)
  %681 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %678, 0
  %682 = insertvalue { <8 x ptr>, <8 x i64> } %681, <8 x i64> %680, 1
  %683 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %684 = extractvalue { <8 x ptr>, <8 x i64> } %682, 1
  %685 = extractelement <8 x ptr> %683, i32 0
  %686 = extractelement <8 x i64> %684, i32 %625
  %687 = zext i32 %625 to i64
  %688 = mul i64 %687, 4
  %689 = sub i64 %686, %688
  %690 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %618)
  %691 = select i1 %690, i64 %689, i64 0
  %private.contiguous.address180 = getelementptr i8, ptr %685, i64 %691
  %private.contiguous.load181 = load <8 x float>, ptr %private.contiguous.address180, align 4
  %692 = select <8 x i1> %618, <8 x float> %private.contiguous.load181, <8 x float> zeroinitializer
  %693 = fmul <8 x float> %677, %692
  %694 = fsub <8 x float> %662, %693
  %695 = extractvalue { ptr, i64 } %31, 0
  %696 = extractelement <8 x i64> %631, i32 %625
  %697 = zext i32 %625 to i64
  %698 = sub i64 %696, %697
  %699 = mul i64 %698, 4
  %buffer.contiguous.address182 = getelementptr i8, ptr %695, i64 %699
  call void @llvm.masked.store.v8f32.p0(<8 x float> %694, ptr align 1 %buffer.contiguous.address182, <8 x i1> %618)
  %700 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %620)
  %701 = bitcast <8 x i1> %620 to i8
  %702 = call i8 @llvm.cttz.i8(i8 %701, i1 false)
  %703 = zext i8 %702 to i32
  %704 = select i1 %700, i32 %703, i32 0
  br label %direct.schedule.32

direct.schedule.32:                               ; preds = %direct.schedule.30
  %705 = load <8 x i64>, ptr %.slot20, align 64
  %706 = select <8 x i1> %55, <8 x i64> zeroinitializer, <8 x i64> %705
  store <8 x i64> %706, ptr %.slot20, align 64
  br label %direct.schedule.33

direct.schedule.33:                               ; preds = %direct.schedule.34, %direct.schedule.32
  %.state183 = load <8 x i64>, ptr %.slot20, align 64
  %707 = icmp slt <8 x i64> %.state183, splat (i64 256)
  %708 = extractelement <8 x i1> %707, i32 0
  br i1 %708, label %direct.true184, label %direct.false185

direct.schedule.34:                               ; preds = %direct.true184
  %.state186 = load <8 x i64>, ptr %.slot20, align 64
  %709 = mul <8 x i64> %.state186, splat (i64 8)
  %.spill.load187 = load <8 x i64>, ptr %.spill, align 64
  %710 = add <8 x i64> %709, %.spill.load187
  %.spill.load188 = load <8 x i64>, ptr %.spill10, align 64
  %711 = add <8 x i64> %.spill.load188, zeroinitializer
  %712 = add <8 x i64> zeroinitializer, %711
  %713 = add <8 x i64> splat (i64 2049), %710
  %714 = mul <8 x i64> %712, splat (i64 4098)
  %715 = add <8 x i64> %714, %713
  %tile_snapshot.spill.load189 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %716 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 0
  %717 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 1
  %.state190 = load <8 x i64>, ptr %.slot20, align 64
  %718 = mul <8 x i64> %.state190, splat (i64 32)
  %719 = add <8 x i64> %717, %718
  %720 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %716, 0
  %721 = insertvalue { <8 x ptr>, <8 x i64> } %720, <8 x i64> %719, 1
  %722 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %723 = extractvalue { <8 x ptr>, <8 x i64> } %721, 1
  %724 = extractelement <8 x ptr> %722, i32 0
  %725 = extractelement <8 x i64> %723, i32 0
  %726 = sub i64 %725, 0
  %727 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %728 = select i1 %727, i64 %726, i64 0
  %private.contiguous.address191 = getelementptr i8, ptr %724, i64 %728
  %private.contiguous.load192 = load <8 x float>, ptr %private.contiguous.address191, align 4
  %729 = select <8 x i1> %55, <8 x float> %private.contiguous.load192, <8 x float> zeroinitializer
  %tile_snapshot.spill.load193 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %730 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load193, 0
  %731 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load193, 1
  %.state194 = load <8 x i64>, ptr %.slot20, align 64
  %732 = mul <8 x i64> %.state194, splat (i64 32)
  %733 = add <8 x i64> %731, %732
  %734 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %730, 0
  %735 = insertvalue { <8 x ptr>, <8 x i64> } %734, <8 x i64> %733, 1
  %736 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %737 = extractvalue { <8 x ptr>, <8 x i64> } %735, 1
  %738 = extractelement <8 x ptr> %736, i32 0
  %739 = extractelement <8 x i64> %737, i32 0
  %740 = sub i64 %739, 0
  %741 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %742 = select i1 %741, i64 %740, i64 0
  %private.contiguous.address195 = getelementptr i8, ptr %738, i64 %742
  %private.contiguous.load196 = load <8 x float>, ptr %private.contiguous.address195, align 4
  %743 = select <8 x i1> %55, <8 x float> %private.contiguous.load196, <8 x float> zeroinitializer
  %744 = fmul <8 x float> %729, %743
  %tile_snapshot.spill.load197 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %745 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load197, 0
  %746 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load197, 1
  %.state198 = load <8 x i64>, ptr %.slot20, align 64
  %747 = mul <8 x i64> %.state198, splat (i64 32)
  %748 = add <8 x i64> %746, %747
  %749 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %745, 0
  %750 = insertvalue { <8 x ptr>, <8 x i64> } %749, <8 x i64> %748, 1
  %751 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %752 = extractvalue { <8 x ptr>, <8 x i64> } %750, 1
  %753 = extractelement <8 x ptr> %751, i32 0
  %754 = extractelement <8 x i64> %752, i32 0
  %755 = sub i64 %754, 0
  %756 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %757 = select i1 %756, i64 %755, i64 0
  %private.contiguous.address199 = getelementptr i8, ptr %753, i64 %757
  %private.contiguous.load200 = load <8 x float>, ptr %private.contiguous.address199, align 4
  %758 = select <8 x i1> %55, <8 x float> %private.contiguous.load200, <8 x float> zeroinitializer
  %tile_snapshot.spill.load201 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %759 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load201, 0
  %760 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load201, 1
  %.state202 = load <8 x i64>, ptr %.slot20, align 64
  %761 = mul <8 x i64> %.state202, splat (i64 32)
  %762 = add <8 x i64> %760, %761
  %763 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %759, 0
  %764 = insertvalue { <8 x ptr>, <8 x i64> } %763, <8 x i64> %762, 1
  %765 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %766 = extractvalue { <8 x ptr>, <8 x i64> } %764, 1
  %767 = extractelement <8 x ptr> %765, i32 0
  %768 = extractelement <8 x i64> %766, i32 0
  %769 = sub i64 %768, 0
  %770 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %771 = select i1 %770, i64 %769, i64 0
  %private.contiguous.address203 = getelementptr i8, ptr %767, i64 %771
  %private.contiguous.load204 = load <8 x float>, ptr %private.contiguous.address203, align 4
  %772 = select <8 x i1> %55, <8 x float> %private.contiguous.load204, <8 x float> zeroinitializer
  %773 = fmul <8 x float> %758, %772
  %774 = fadd <8 x float> %744, %773
  %775 = extractvalue { ptr, i64 } %31, 0
  %776 = extractelement <8 x i64> %715, i32 0
  %777 = sub i64 %776, 0
  %778 = mul i64 %777, 4
  %buffer.contiguous.address205 = getelementptr i8, ptr %775, i64 %778
  call void @llvm.masked.store.v8f32.p0(<8 x float> %774, ptr align 1 %buffer.contiguous.address205, <8 x i1> %55)
  %.state206 = load <8 x i64>, ptr %.slot20, align 64
  %779 = add <8 x i64> %.state206, splat (i64 1)
  %780 = load <8 x i64>, ptr %.slot20, align 64
  %781 = select <8 x i1> %55, <8 x i64> %779, <8 x i64> %780
  store <8 x i64> %781, ptr %.slot20, align 64
  br label %direct.schedule.33

direct.schedule.35:                               ; preds = %direct.false185
  %.spill.load207 = load <8 x i1>, ptr %.spill12, align 1
  %782 = and <8 x i1> %55, %.spill.load207
  %783 = xor <8 x i1> %.spill.load207, splat (i1 true)
  %784 = and <8 x i1> %55, %783
  %785 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %782)
  %786 = bitcast <8 x i1> %782 to i8
  %787 = call i8 @llvm.cttz.i8(i8 %786, i1 false)
  %788 = zext i8 %787 to i32
  %789 = select i1 %785, i32 %788, i32 0
  %.spill.load208 = load <8 x i64>, ptr %.spill, align 64
  %790 = add <8 x i64> splat (i64 2048), %.spill.load208
  %.spill.load209 = load <8 x i64>, ptr %.spill10, align 64
  %791 = add <8 x i64> %.spill.load209, zeroinitializer
  %792 = add <8 x i64> zeroinitializer, %791
  %793 = add <8 x i64> splat (i64 2049), %790
  %794 = mul <8 x i64> %792, splat (i64 4098)
  %795 = add <8 x i64> %794, %793
  %tile_snapshot.spill.load210 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %796 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load210, 0
  %797 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load210, 1
  %798 = add <8 x i64> %797, splat (i64 8192)
  %799 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %796, 0
  %800 = insertvalue { <8 x ptr>, <8 x i64> } %799, <8 x i64> %798, 1
  %801 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %802 = extractvalue { <8 x ptr>, <8 x i64> } %800, 1
  %803 = extractelement <8 x ptr> %801, i32 0
  %804 = extractelement <8 x i64> %802, i32 %789
  %805 = zext i32 %789 to i64
  %806 = mul i64 %805, 4
  %807 = sub i64 %804, %806
  %808 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %782)
  %809 = select i1 %808, i64 %807, i64 0
  %private.contiguous.address211 = getelementptr i8, ptr %803, i64 %809
  %private.contiguous.load212 = load <8 x float>, ptr %private.contiguous.address211, align 4
  %810 = select <8 x i1> %782, <8 x float> %private.contiguous.load212, <8 x float> zeroinitializer
  %tile_snapshot.spill.load213 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %811 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load213, 0
  %812 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load213, 1
  %813 = add <8 x i64> %812, splat (i64 8192)
  %814 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %811, 0
  %815 = insertvalue { <8 x ptr>, <8 x i64> } %814, <8 x i64> %813, 1
  %816 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %817 = extractvalue { <8 x ptr>, <8 x i64> } %815, 1
  %818 = extractelement <8 x ptr> %816, i32 0
  %819 = extractelement <8 x i64> %817, i32 %789
  %820 = zext i32 %789 to i64
  %821 = mul i64 %820, 4
  %822 = sub i64 %819, %821
  %823 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %782)
  %824 = select i1 %823, i64 %822, i64 0
  %private.contiguous.address214 = getelementptr i8, ptr %818, i64 %824
  %private.contiguous.load215 = load <8 x float>, ptr %private.contiguous.address214, align 4
  %825 = select <8 x i1> %782, <8 x float> %private.contiguous.load215, <8 x float> zeroinitializer
  %826 = fmul <8 x float> %810, %825
  %tile_snapshot.spill.load216 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %827 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load216, 0
  %828 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load216, 1
  %829 = add <8 x i64> %828, splat (i64 8192)
  %830 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %827, 0
  %831 = insertvalue { <8 x ptr>, <8 x i64> } %830, <8 x i64> %829, 1
  %832 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %833 = extractvalue { <8 x ptr>, <8 x i64> } %831, 1
  %834 = extractelement <8 x ptr> %832, i32 0
  %835 = extractelement <8 x i64> %833, i32 %789
  %836 = zext i32 %789 to i64
  %837 = mul i64 %836, 4
  %838 = sub i64 %835, %837
  %839 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %782)
  %840 = select i1 %839, i64 %838, i64 0
  %private.contiguous.address217 = getelementptr i8, ptr %834, i64 %840
  %private.contiguous.load218 = load <8 x float>, ptr %private.contiguous.address217, align 4
  %841 = select <8 x i1> %782, <8 x float> %private.contiguous.load218, <8 x float> zeroinitializer
  %tile_snapshot.spill.load219 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %842 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load219, 0
  %843 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load219, 1
  %844 = add <8 x i64> %843, splat (i64 8192)
  %845 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %842, 0
  %846 = insertvalue { <8 x ptr>, <8 x i64> } %845, <8 x i64> %844, 1
  %847 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %848 = extractvalue { <8 x ptr>, <8 x i64> } %846, 1
  %849 = extractelement <8 x ptr> %847, i32 0
  %850 = extractelement <8 x i64> %848, i32 %789
  %851 = zext i32 %789 to i64
  %852 = mul i64 %851, 4
  %853 = sub i64 %850, %852
  %854 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %782)
  %855 = select i1 %854, i64 %853, i64 0
  %private.contiguous.address220 = getelementptr i8, ptr %849, i64 %855
  %private.contiguous.load221 = load <8 x float>, ptr %private.contiguous.address220, align 4
  %856 = select <8 x i1> %782, <8 x float> %private.contiguous.load221, <8 x float> zeroinitializer
  %857 = fmul <8 x float> %841, %856
  %858 = fadd <8 x float> %826, %857
  %859 = extractvalue { ptr, i64 } %31, 0
  %860 = extractelement <8 x i64> %795, i32 %789
  %861 = zext i32 %789 to i64
  %862 = sub i64 %860, %861
  %863 = mul i64 %862, 4
  %buffer.contiguous.address222 = getelementptr i8, ptr %859, i64 %863
  call void @llvm.masked.store.v8f32.p0(<8 x float> %858, ptr align 1 %buffer.contiguous.address222, <8 x i1> %782)
  %864 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %784)
  %865 = bitcast <8 x i1> %784 to i8
  %866 = call i8 @llvm.cttz.i8(i8 %865, i1 false)
  %867 = zext i8 %866 to i32
  %868 = select i1 %864, i32 %867, i32 0
  br label %direct.schedule.6

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.0
  br label %direct.schedule.1

direct.false:                                     ; preds = %direct.schedule.0
  br label %direct.schedule.7

direct.true31:                                    ; preds = %direct.schedule.2
  br label %direct.schedule.3

direct.false32:                                   ; preds = %direct.schedule.2
  br label %direct.schedule.4

direct.true60:                                    ; preds = %direct.schedule.8
  br label %direct.schedule.9

direct.false61:                                   ; preds = %direct.schedule.8
  br label %direct.schedule.10

direct.true82:                                    ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false83:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true103:                                   ; preds = %direct.schedule.18
  br label %direct.schedule.19

direct.false104:                                  ; preds = %direct.schedule.18
  br label %direct.schedule.20

direct.true124:                                   ; preds = %direct.schedule.23
  br label %direct.schedule.24

direct.false125:                                  ; preds = %direct.schedule.23
  br label %direct.schedule.25

direct.true145:                                   ; preds = %direct.schedule.28
  br label %direct.schedule.29

direct.false146:                                  ; preds = %direct.schedule.28
  br label %direct.schedule.30

direct.true184:                                   ; preds = %direct.schedule.33
  br label %direct.schedule.34

direct.false185:                                  ; preds = %direct.schedule.33
  br label %direct.schedule.35
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %tile_snapshot.local = alloca [8224 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [8224 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local4 = alloca [8224 x i8], align 4
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local7 = alloca [8224 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill10 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill10, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot11 = alloca i64, align 8
  store i64 0, ptr %.slot11, align 4
  %.spill12 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill12, align 1
  %tile_snapshot.spill13 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill13, align 64
  %.slot14 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot14, align 64
  %tile_snapshot.spill15 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill15, align 64
  %.slot16 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot16, align 64
  %tile_snapshot.spill17 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill17, align 64
  %.slot18 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot18, align 64
  %.slot19 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot19, align 64
  %.slot20 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot20, align 64
  %8 = getelementptr i8, ptr %argument_buffer, i64 0
  %9 = load ptr, ptr %8, align 16
  %10 = getelementptr i8, ptr %8, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = insertvalue { ptr, i64 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %11, 1
  %14 = getelementptr i8, ptr %argument_buffer, i64 16
  %15 = load ptr, ptr %14, align 16
  %16 = getelementptr i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = insertvalue { ptr, i64 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i64 } %18, i64 %17, 1
  %20 = getelementptr i8, ptr %argument_buffer, i64 32
  %21 = load ptr, ptr %20, align 16
  %22 = getelementptr i8, ptr %20, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = insertvalue { ptr, i64 } poison, ptr %21, 0
  %25 = insertvalue { ptr, i64 } %24, i64 %23, 1
  %26 = getelementptr i8, ptr %argument_buffer, i64 48
  %27 = load ptr, ptr %26, align 16
  %28 = getelementptr i8, ptr %26, i64 8
  %29 = load i64, ptr %28, align 8
  %30 = insertvalue { ptr, i64 } poison, ptr %27, 0
  %31 = insertvalue { ptr, i64 } %30, i64 %29, 1
  %32 = load i32, ptr %launch_config, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 12
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 4
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 16
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 8
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 20
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 36
  %44 = load i32, ptr %43, align 4
  %.splatinsert21 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat22 = shufflevector <8 x i32> %.splatinsert21, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat22, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %46 = mul i32 %32, 32
  %.splatinsert23 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat24 = shufflevector <8 x i32> %.splatinsert23, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat24, %45
  %48 = mul i32 %36, 1
  %.splatinsert25 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat26 = shufflevector <8 x i32> %.splatinsert25, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat26, zeroinitializer
  %50 = mul i32 %40, 1
  %.splatinsert27 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat28 = shufflevector <8 x i32> %.splatinsert27, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat28, zeroinitializer
  %52 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %47, 0
  %53 = insertvalue [3 x <8 x i32>] %52, <8 x i32> %49, 1
  %54 = insertvalue [3 x <8 x i32>] %53, <8 x i32> %51, 2
  %.splatinsert29 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat30 = shufflevector <8 x i32> %.splatinsert29, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat30
  %56 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  br i1 %56, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %57 = extractvalue [3 x <8 x i32>] %54, 0
  %58 = load <8 x i64>, ptr %.spill, align 64
  %59 = select <8 x i1> %55, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %58
  store <8 x i64> %59, ptr %.spill, align 64
  %60 = sub <8 x i32> %57, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %61 = select <8 x i1> %55, <8 x i32> %60, <8 x i32> zeroinitializer
  %62 = select <8 x i1> %55, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %63 = lshr <8 x i32> %61, %62
  %64 = zext <8 x i32> %63 to <8 x i64>
  %65 = select <8 x i1> %55, <8 x i64> %64, <8 x i64> zeroinitializer
  %66 = select <8 x i1> %55, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %67 = sdiv <8 x i64> %65, %66
  %68 = load <8 x i64>, ptr %.spill10, align 64
  %69 = select <8 x i1> %55, <8 x i64> %67, <8 x i64> %68
  store <8 x i64> %69, ptr %.spill10, align 64
  %70 = extractvalue { ptr, i64 } %13, 1
  %71 = extractvalue { ptr, i64 } %13, 0
  %72 = ptrtoint ptr %71 to i64
  %73 = extractvalue { ptr, i64 } %31, 1
  %74 = extractvalue { ptr, i64 } %31, 0
  %75 = ptrtoint ptr %74 to i64
  %76 = icmp uge i64 %72, %75
  %77 = sub i64 %72, %75
  %78 = icmp uge i64 %77, 16785408
  %79 = and i1 %76, %78
  %80 = icmp uge i64 %75, %72
  %81 = sub i64 %75, %72
  %82 = icmp uge i64 %81, 16785408
  %83 = and i1 %80, %82
  %84 = or i1 %79, %83
  %85 = and i1 true, %84
  %86 = extractvalue { ptr, i64 } %19, 1
  %87 = extractvalue { ptr, i64 } %19, 0
  %88 = ptrtoint ptr %87 to i64
  %89 = icmp uge i64 %88, %75
  %90 = sub i64 %88, %75
  %91 = icmp uge i64 %90, 16785408
  %92 = and i1 %89, %91
  %93 = icmp uge i64 %75, %88
  %94 = sub i64 %75, %88
  %95 = icmp uge i64 %94, 8392704
  %96 = and i1 %93, %95
  %97 = or i1 %92, %96
  %98 = and i1 %85, %97
  %99 = extractvalue { ptr, i64 } %25, 1
  %100 = extractvalue { ptr, i64 } %25, 0
  %101 = ptrtoint ptr %100 to i64
  %102 = icmp uge i64 %101, %75
  %103 = sub i64 %101, %75
  %104 = icmp uge i64 %103, 16785408
  %105 = and i1 %102, %104
  %106 = icmp uge i64 %75, %101
  %107 = sub i64 %75, %101
  %108 = icmp uge i64 %107, 8392704
  %109 = and i1 %106, %108
  %110 = or i1 %105, %109
  %111 = and i1 %98, %110
  br i1 %111, label %direct.true, label %direct.false

direct.schedule.1:                                ; preds = %direct.true
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.2

direct.schedule.2:                                ; preds = %direct.schedule.3, %direct.schedule.1
  %.state = load i64, ptr %.slot, align 4
  %112 = icmp slt i64 %.state, 256
  br i1 %112, label %direct.true31, label %direct.false32

direct.schedule.3:                                ; preds = %direct.true31
  %.state33 = load i64, ptr %.slot, align 4
  %113 = mul i64 %.state33, 8
  %.splatinsert34 = insertelement <8 x i64> poison, i64 %113, i64 0
  %.splat35 = shufflevector <8 x i64> %.splatinsert34, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %114 = add <8 x i64> %.splat35, %.spill.load
  %.spill.load36 = load <8 x i64>, ptr %.spill10, align 64
  %115 = add <8 x i64> %.spill.load36, zeroinitializer
  %116 = add <8 x i64> zeroinitializer, %115
  %117 = add <8 x i64> zeroinitializer, %114
  %118 = mul <8 x i64> %116, splat (i64 4098)
  %119 = add <8 x i64> %118, %117
  %120 = extractvalue { ptr, i64 } %13, 0
  %121 = extractelement <8 x i64> %119, i32 0
  %122 = sub i64 %121, 0
  %123 = mul i64 %122, 4
  %buffer.contiguous.address = getelementptr i8, ptr %120, i64 %123
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address, <8 x i1> %55, <8 x float> zeroinitializer)
  %124 = add <8 x i64> splat (i64 2049), %114
  %125 = add <8 x i64> %118, %124
  %126 = extractvalue { ptr, i64 } %13, 0
  %127 = extractelement <8 x i64> %125, i32 0
  %128 = sub i64 %127, 0
  %129 = mul i64 %128, 4
  %buffer.contiguous.address37 = getelementptr i8, ptr %126, i64 %129
  %buffer.contiguous.load38 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address37, <8 x i1> %55, <8 x float> zeroinitializer)
  %130 = mul <8 x i64> %116, splat (i64 2049)
  %131 = add <8 x i64> %130, %117
  %132 = extractvalue { ptr, i64 } %19, 0
  %133 = extractelement <8 x i64> %131, i32 0
  %134 = sub i64 %133, 0
  %135 = mul i64 %134, 4
  %buffer.contiguous.address39 = getelementptr i8, ptr %132, i64 %135
  %buffer.contiguous.load40 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address39, <8 x i1> %55, <8 x float> zeroinitializer)
  %136 = extractvalue { ptr, i64 } %25, 0
  %137 = extractelement <8 x i64> %131, i32 0
  %138 = sub i64 %137, 0
  %139 = mul i64 %138, 4
  %buffer.contiguous.address41 = getelementptr i8, ptr %136, i64 %139
  %buffer.contiguous.load42 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address41, <8 x i1> %55, <8 x float> zeroinitializer)
  %140 = fmul <8 x float> %buffer.contiguous.load, %buffer.contiguous.load40
  %141 = fmul <8 x float> %buffer.contiguous.load38, %buffer.contiguous.load42
  %142 = fsub <8 x float> %140, %141
  %143 = extractvalue { ptr, i64 } %31, 0
  %144 = extractelement <8 x i64> %119, i32 0
  %145 = sub i64 %144, 0
  %146 = mul i64 %145, 4
  %buffer.contiguous.address43 = getelementptr i8, ptr %143, i64 %146
  call void @llvm.masked.store.v8f32.p0(<8 x float> %142, ptr align 1 %buffer.contiguous.address43, <8 x i1> %55)
  %147 = fmul <8 x float> %buffer.contiguous.load, %buffer.contiguous.load42
  %148 = fmul <8 x float> %buffer.contiguous.load38, %buffer.contiguous.load40
  %149 = fadd <8 x float> %147, %148
  %150 = extractvalue { ptr, i64 } %31, 0
  %151 = extractelement <8 x i64> %125, i32 0
  %152 = sub i64 %151, 0
  %153 = mul i64 %152, 4
  %buffer.contiguous.address44 = getelementptr i8, ptr %150, i64 %153
  call void @llvm.masked.store.v8f32.p0(<8 x float> %149, ptr align 1 %buffer.contiguous.address44, <8 x i1> %55)
  %.state45 = load i64, ptr %.slot, align 4
  %154 = add i64 %.state45, 1
  store i64 %154, ptr %.slot, align 4
  br label %direct.schedule.2

direct.schedule.4:                                ; preds = %direct.false32
  %.spill.load46 = load <8 x i64>, ptr %.spill, align 64
  %155 = icmp slt <8 x i64> %.spill.load46, splat (i64 1)
  %156 = and <8 x i1> %55, %155
  %157 = xor <8 x i1> %155, splat (i1 true)
  %158 = and <8 x i1> %55, %157
  %159 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %156)
  %160 = bitcast <8 x i1> %156 to i8
  %161 = call i8 @llvm.cttz.i8(i8 %160, i1 false)
  %162 = zext i8 %161 to i32
  %163 = select i1 %159, i32 %162, i32 0
  %.spill.load47 = load <8 x i64>, ptr %.spill, align 64
  %164 = add <8 x i64> splat (i64 2048), %.spill.load47
  %.spill.load48 = load <8 x i64>, ptr %.spill10, align 64
  %165 = add <8 x i64> %.spill.load48, zeroinitializer
  %166 = add <8 x i64> zeroinitializer, %165
  %167 = add <8 x i64> zeroinitializer, %164
  %168 = mul <8 x i64> %166, splat (i64 4098)
  %169 = add <8 x i64> %168, %167
  %170 = extractvalue { ptr, i64 } %13, 0
  %171 = select <8 x i1> %156, <8 x i64> %169, <8 x i64> zeroinitializer
  %172 = extractelement <8 x i64> %171, i32 %163
  %173 = zext i32 %163 to i64
  %174 = sub i64 %172, %173
  %175 = mul i64 %174, 4
  %buffer.contiguous.address49 = getelementptr i8, ptr %170, i64 %175
  %buffer.contiguous.load50 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address49, <8 x i1> %156, <8 x float> zeroinitializer)
  %176 = add <8 x i64> splat (i64 2049), %164
  %177 = add <8 x i64> %168, %176
  %178 = extractvalue { ptr, i64 } %13, 0
  %179 = select <8 x i1> %156, <8 x i64> %177, <8 x i64> zeroinitializer
  %180 = extractelement <8 x i64> %179, i32 %163
  %181 = zext i32 %163 to i64
  %182 = sub i64 %180, %181
  %183 = mul i64 %182, 4
  %buffer.contiguous.address51 = getelementptr i8, ptr %178, i64 %183
  %buffer.contiguous.load52 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address51, <8 x i1> %156, <8 x float> zeroinitializer)
  %184 = mul <8 x i64> %166, splat (i64 2049)
  %185 = add <8 x i64> %184, %167
  %186 = extractvalue { ptr, i64 } %19, 0
  %187 = select <8 x i1> %156, <8 x i64> %185, <8 x i64> zeroinitializer
  %188 = extractelement <8 x i64> %187, i32 %163
  %189 = zext i32 %163 to i64
  %190 = sub i64 %188, %189
  %191 = mul i64 %190, 4
  %buffer.contiguous.address53 = getelementptr i8, ptr %186, i64 %191
  %buffer.contiguous.load54 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address53, <8 x i1> %156, <8 x float> zeroinitializer)
  %192 = extractvalue { ptr, i64 } %25, 0
  %193 = select <8 x i1> %156, <8 x i64> %185, <8 x i64> zeroinitializer
  %194 = extractelement <8 x i64> %193, i32 %163
  %195 = zext i32 %163 to i64
  %196 = sub i64 %194, %195
  %197 = mul i64 %196, 4
  %buffer.contiguous.address55 = getelementptr i8, ptr %192, i64 %197
  %buffer.contiguous.load56 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address55, <8 x i1> %156, <8 x float> zeroinitializer)
  %198 = fmul <8 x float> %buffer.contiguous.load50, %buffer.contiguous.load54
  %199 = fmul <8 x float> %buffer.contiguous.load52, %buffer.contiguous.load56
  %200 = fsub <8 x float> %198, %199
  %201 = extractvalue { ptr, i64 } %31, 0
  %202 = extractelement <8 x i64> %169, i32 %163
  %203 = zext i32 %163 to i64
  %204 = sub i64 %202, %203
  %205 = mul i64 %204, 4
  %buffer.contiguous.address57 = getelementptr i8, ptr %201, i64 %205
  call void @llvm.masked.store.v8f32.p0(<8 x float> %200, ptr align 1 %buffer.contiguous.address57, <8 x i1> %156)
  %206 = fmul <8 x float> %buffer.contiguous.load50, %buffer.contiguous.load56
  %207 = fmul <8 x float> %buffer.contiguous.load52, %buffer.contiguous.load54
  %208 = fadd <8 x float> %206, %207
  %209 = extractvalue { ptr, i64 } %31, 0
  %210 = extractelement <8 x i64> %177, i32 %163
  %211 = zext i32 %163 to i64
  %212 = sub i64 %210, %211
  %213 = mul i64 %212, 4
  %buffer.contiguous.address58 = getelementptr i8, ptr %209, i64 %213
  call void @llvm.masked.store.v8f32.p0(<8 x float> %208, ptr align 1 %buffer.contiguous.address58, <8 x i1> %156)
  %214 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %158)
  %215 = bitcast <8 x i1> %158 to i8
  %216 = call i8 @llvm.cttz.i8(i8 %215, i1 false)
  %217 = zext i8 %216 to i32
  %218 = select i1 %214, i32 %217, i32 0
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.35, %direct.schedule.4
  ret void

direct.schedule.7:                                ; preds = %direct.false
  %219 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %219, 0
  %222 = select <8 x i1> %55, <8 x ptr> %220, <8 x ptr> %221
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %224 = extractvalue { <8 x ptr>, <8 x i64> } %219, 1
  %225 = select <8 x i1> %55, <8 x i64> %223, <8 x i64> %224
  %226 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %222, 0
  %227 = insertvalue { <8 x ptr>, <8 x i64> } %226, <8 x i64> %225, 1
  store { <8 x ptr>, <8 x i64> } %227, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot11, align 4
  br label %direct.schedule.8

direct.schedule.8:                                ; preds = %direct.schedule.9, %direct.schedule.7
  %.state59 = load i64, ptr %.slot11, align 4
  %228 = icmp slt i64 %.state59, 256
  br i1 %228, label %direct.true60, label %direct.false61

direct.schedule.9:                                ; preds = %direct.true60
  %.state62 = load i64, ptr %.slot11, align 4
  %229 = mul i64 %.state62, 8
  %.splatinsert63 = insertelement <8 x i64> poison, i64 %229, i64 0
  %.splat64 = shufflevector <8 x i64> %.splatinsert63, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load65 = load <8 x i64>, ptr %.spill, align 64
  %230 = add <8 x i64> %.splat64, %.spill.load65
  %.spill.load66 = load <8 x i64>, ptr %.spill10, align 64
  %231 = add <8 x i64> %.spill.load66, zeroinitializer
  %232 = add <8 x i64> zeroinitializer, %231
  %233 = add <8 x i64> zeroinitializer, %230
  %234 = mul <8 x i64> %232, splat (i64 4098)
  %235 = add <8 x i64> %234, %233
  %236 = extractvalue { ptr, i64 } %13, 0
  %237 = extractelement <8 x i64> %235, i32 0
  %238 = sub i64 %237, 0
  %239 = mul i64 %238, 4
  %buffer.contiguous.address67 = getelementptr i8, ptr %236, i64 %239
  %buffer.contiguous.load68 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address67, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %240 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state69 = load i64, ptr %.slot11, align 4
  %.splatinsert70 = insertelement <8 x i64> poison, i64 %.state69, i64 0
  %.splat71 = shufflevector <8 x i64> %.splatinsert70, <8 x i64> poison, <8 x i32> zeroinitializer
  %242 = mul <8 x i64> %.splat71, splat (i64 32)
  %243 = add <8 x i64> %241, %242
  %244 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %240, 0
  %245 = insertvalue { <8 x ptr>, <8 x i64> } %244, <8 x i64> %243, 1
  %246 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %247 = extractvalue { <8 x ptr>, <8 x i64> } %245, 1
  %248 = extractelement <8 x ptr> %246, i32 0
  %249 = extractelement <8 x i64> %247, i32 0
  %250 = sub i64 %249, 0
  %251 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %252 = select i1 %251, i64 %250, i64 0
  %private.contiguous.address = getelementptr i8, ptr %248, i64 %252
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %253 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load68, <8 x float> %private.contiguous.preserve
  store <8 x float> %253, ptr %private.contiguous.address, align 4
  %.state72 = load i64, ptr %.slot11, align 4
  %254 = add i64 %.state72, 1
  store i64 %254, ptr %.slot11, align 4
  br label %direct.schedule.8

direct.schedule.10:                               ; preds = %direct.false61
  %.spill.load73 = load <8 x i64>, ptr %.spill, align 64
  %255 = icmp slt <8 x i64> %.spill.load73, splat (i64 1)
  %256 = load <8 x i1>, ptr %.spill12, align 1
  %257 = select <8 x i1> %55, <8 x i1> %255, <8 x i1> %256
  store <8 x i1> %257, ptr %.spill12, align 1
  %258 = and <8 x i1> %55, %255
  %259 = xor <8 x i1> %255, splat (i1 true)
  %260 = and <8 x i1> %55, %259
  %261 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %258)
  %262 = bitcast <8 x i1> %258 to i8
  %263 = call i8 @llvm.cttz.i8(i8 %262, i1 false)
  %264 = zext i8 %263 to i32
  %265 = select i1 %261, i32 %264, i32 0
  %.spill.load74 = load <8 x i64>, ptr %.spill, align 64
  %266 = add <8 x i64> splat (i64 2048), %.spill.load74
  %.spill.load75 = load <8 x i64>, ptr %.spill10, align 64
  %267 = add <8 x i64> %.spill.load75, zeroinitializer
  %268 = add <8 x i64> zeroinitializer, %267
  %269 = add <8 x i64> zeroinitializer, %266
  %270 = mul <8 x i64> %268, splat (i64 4098)
  %271 = add <8 x i64> %270, %269
  %272 = extractvalue { ptr, i64 } %13, 0
  %273 = select <8 x i1> %258, <8 x i64> %271, <8 x i64> zeroinitializer
  %274 = extractelement <8 x i64> %273, i32 %265
  %275 = zext i32 %265 to i64
  %276 = sub i64 %274, %275
  %277 = mul i64 %276, 4
  %buffer.contiguous.address76 = getelementptr i8, ptr %272, i64 %277
  %buffer.contiguous.load77 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address76, <8 x i1> %258, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load78 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %278 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load78, 0
  %279 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load78, 1
  %280 = add <8 x i64> %279, splat (i64 8192)
  %281 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %278, 0
  %282 = insertvalue { <8 x ptr>, <8 x i64> } %281, <8 x i64> %280, 1
  %283 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %284 = extractvalue { <8 x ptr>, <8 x i64> } %282, 1
  %285 = extractelement <8 x ptr> %283, i32 0
  %286 = extractelement <8 x i64> %284, i32 %265
  %287 = zext i32 %265 to i64
  %288 = mul i64 %287, 4
  %289 = sub i64 %286, %288
  %290 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %258)
  %291 = select i1 %290, i64 %289, i64 0
  %private.contiguous.address79 = getelementptr i8, ptr %285, i64 %291
  %private.contiguous.preserve80 = load <8 x float>, ptr %private.contiguous.address79, align 4
  %292 = select <8 x i1> %258, <8 x float> %buffer.contiguous.load77, <8 x float> %private.contiguous.preserve80
  store <8 x float> %292, ptr %private.contiguous.address79, align 4
  %293 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %260)
  %294 = bitcast <8 x i1> %260 to i8
  %295 = call i8 @llvm.cttz.i8(i8 %294, i1 false)
  %296 = zext i8 %295 to i32
  %297 = select i1 %293, i32 %296, i32 0
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.schedule.10
  %298 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %299 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %298, 0
  %301 = select <8 x i1> %55, <8 x ptr> %299, <8 x ptr> %300
  %302 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %303 = extractvalue { <8 x ptr>, <8 x i64> } %298, 1
  %304 = select <8 x i1> %55, <8 x i64> %302, <8 x i64> %303
  %305 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %301, 0
  %306 = insertvalue { <8 x ptr>, <8 x i64> } %305, <8 x i64> %304, 1
  store { <8 x ptr>, <8 x i64> } %306, ptr %tile_snapshot.spill13, align 64
  %307 = load <8 x i64>, ptr %.slot14, align 64
  %308 = select <8 x i1> %55, <8 x i64> zeroinitializer, <8 x i64> %307
  store <8 x i64> %308, ptr %.slot14, align 64
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state81 = load <8 x i64>, ptr %.slot14, align 64
  %309 = icmp slt <8 x i64> %.state81, splat (i64 256)
  %310 = extractelement <8 x i1> %309, i32 0
  br i1 %310, label %direct.true82, label %direct.false83

direct.schedule.14:                               ; preds = %direct.true82
  %.state84 = load <8 x i64>, ptr %.slot14, align 64
  %311 = mul <8 x i64> %.state84, splat (i64 8)
  %.spill.load85 = load <8 x i64>, ptr %.spill, align 64
  %312 = add <8 x i64> %311, %.spill.load85
  %.spill.load86 = load <8 x i64>, ptr %.spill10, align 64
  %313 = add <8 x i64> %.spill.load86, zeroinitializer
  %314 = add <8 x i64> zeroinitializer, %313
  %315 = add <8 x i64> splat (i64 2049), %312
  %316 = mul <8 x i64> %314, splat (i64 4098)
  %317 = add <8 x i64> %316, %315
  %318 = extractvalue { ptr, i64 } %13, 0
  %319 = extractelement <8 x i64> %317, i32 0
  %320 = sub i64 %319, 0
  %321 = mul i64 %320, 4
  %buffer.contiguous.address87 = getelementptr i8, ptr %318, i64 %321
  %buffer.contiguous.load88 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address87, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load89 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load89, 0
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load89, 1
  %.state90 = load <8 x i64>, ptr %.slot14, align 64
  %324 = mul <8 x i64> %.state90, splat (i64 32)
  %325 = add <8 x i64> %323, %324
  %326 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %322, 0
  %327 = insertvalue { <8 x ptr>, <8 x i64> } %326, <8 x i64> %325, 1
  %328 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %327, 1
  %330 = extractelement <8 x ptr> %328, i32 0
  %331 = extractelement <8 x i64> %329, i32 0
  %332 = sub i64 %331, 0
  %333 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %334 = select i1 %333, i64 %332, i64 0
  %private.contiguous.address91 = getelementptr i8, ptr %330, i64 %334
  %private.contiguous.preserve92 = load <8 x float>, ptr %private.contiguous.address91, align 4
  %335 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load88, <8 x float> %private.contiguous.preserve92
  store <8 x float> %335, ptr %private.contiguous.address91, align 4
  %.state93 = load <8 x i64>, ptr %.slot14, align 64
  %336 = add <8 x i64> %.state93, splat (i64 1)
  %337 = load <8 x i64>, ptr %.slot14, align 64
  %338 = select <8 x i1> %55, <8 x i64> %336, <8 x i64> %337
  store <8 x i64> %338, ptr %.slot14, align 64
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false83
  %.spill.load94 = load <8 x i1>, ptr %.spill12, align 1
  %339 = and <8 x i1> %55, %.spill.load94
  %340 = xor <8 x i1> %.spill.load94, splat (i1 true)
  %341 = and <8 x i1> %55, %340
  %342 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %339)
  %343 = bitcast <8 x i1> %339 to i8
  %344 = call i8 @llvm.cttz.i8(i8 %343, i1 false)
  %345 = zext i8 %344 to i32
  %346 = select i1 %342, i32 %345, i32 0
  %.spill.load95 = load <8 x i64>, ptr %.spill, align 64
  %347 = add <8 x i64> splat (i64 2048), %.spill.load95
  %.spill.load96 = load <8 x i64>, ptr %.spill10, align 64
  %348 = add <8 x i64> %.spill.load96, zeroinitializer
  %349 = add <8 x i64> zeroinitializer, %348
  %350 = add <8 x i64> splat (i64 2049), %347
  %351 = mul <8 x i64> %349, splat (i64 4098)
  %352 = add <8 x i64> %351, %350
  %353 = extractvalue { ptr, i64 } %13, 0
  %354 = select <8 x i1> %339, <8 x i64> %352, <8 x i64> zeroinitializer
  %355 = extractelement <8 x i64> %354, i32 %346
  %356 = zext i32 %346 to i64
  %357 = sub i64 %355, %356
  %358 = mul i64 %357, 4
  %buffer.contiguous.address97 = getelementptr i8, ptr %353, i64 %358
  %buffer.contiguous.load98 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address97, <8 x i1> %339, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load99 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %359 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load99, 0
  %360 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load99, 1
  %361 = add <8 x i64> %360, splat (i64 8192)
  %362 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %359, 0
  %363 = insertvalue { <8 x ptr>, <8 x i64> } %362, <8 x i64> %361, 1
  %364 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %365 = extractvalue { <8 x ptr>, <8 x i64> } %363, 1
  %366 = extractelement <8 x ptr> %364, i32 0
  %367 = extractelement <8 x i64> %365, i32 %346
  %368 = zext i32 %346 to i64
  %369 = mul i64 %368, 4
  %370 = sub i64 %367, %369
  %371 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %339)
  %372 = select i1 %371, i64 %370, i64 0
  %private.contiguous.address100 = getelementptr i8, ptr %366, i64 %372
  %private.contiguous.preserve101 = load <8 x float>, ptr %private.contiguous.address100, align 4
  %373 = select <8 x i1> %339, <8 x float> %buffer.contiguous.load98, <8 x float> %private.contiguous.preserve101
  store <8 x float> %373, ptr %private.contiguous.address100, align 4
  %374 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %341)
  %375 = bitcast <8 x i1> %341 to i8
  %376 = call i8 @llvm.cttz.i8(i8 %375, i1 false)
  %377 = zext i8 %376 to i32
  %378 = select i1 %374, i32 %377, i32 0
  br label %direct.schedule.17

direct.schedule.17:                               ; preds = %direct.schedule.15
  %379 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %380 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %381 = extractvalue { <8 x ptr>, <8 x i64> } %379, 0
  %382 = select <8 x i1> %55, <8 x ptr> %380, <8 x ptr> %381
  %383 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %384 = extractvalue { <8 x ptr>, <8 x i64> } %379, 1
  %385 = select <8 x i1> %55, <8 x i64> %383, <8 x i64> %384
  %386 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %382, 0
  %387 = insertvalue { <8 x ptr>, <8 x i64> } %386, <8 x i64> %385, 1
  store { <8 x ptr>, <8 x i64> } %387, ptr %tile_snapshot.spill15, align 64
  %388 = load <8 x i64>, ptr %.slot16, align 64
  %389 = select <8 x i1> %55, <8 x i64> zeroinitializer, <8 x i64> %388
  store <8 x i64> %389, ptr %.slot16, align 64
  br label %direct.schedule.18

direct.schedule.18:                               ; preds = %direct.schedule.19, %direct.schedule.17
  %.state102 = load <8 x i64>, ptr %.slot16, align 64
  %390 = icmp slt <8 x i64> %.state102, splat (i64 256)
  %391 = extractelement <8 x i1> %390, i32 0
  br i1 %391, label %direct.true103, label %direct.false104

direct.schedule.19:                               ; preds = %direct.true103
  %.state105 = load <8 x i64>, ptr %.slot16, align 64
  %392 = mul <8 x i64> %.state105, splat (i64 8)
  %.spill.load106 = load <8 x i64>, ptr %.spill, align 64
  %393 = add <8 x i64> %392, %.spill.load106
  %.spill.load107 = load <8 x i64>, ptr %.spill10, align 64
  %394 = add <8 x i64> %.spill.load107, zeroinitializer
  %395 = add <8 x i64> zeroinitializer, %394
  %396 = add <8 x i64> zeroinitializer, %393
  %397 = mul <8 x i64> %395, splat (i64 2049)
  %398 = add <8 x i64> %397, %396
  %399 = extractvalue { ptr, i64 } %19, 0
  %400 = extractelement <8 x i64> %398, i32 0
  %401 = sub i64 %400, 0
  %402 = mul i64 %401, 4
  %buffer.contiguous.address108 = getelementptr i8, ptr %399, i64 %402
  %buffer.contiguous.load109 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address108, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load110 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %403 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load110, 0
  %404 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load110, 1
  %.state111 = load <8 x i64>, ptr %.slot16, align 64
  %405 = mul <8 x i64> %.state111, splat (i64 32)
  %406 = add <8 x i64> %404, %405
  %407 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %403, 0
  %408 = insertvalue { <8 x ptr>, <8 x i64> } %407, <8 x i64> %406, 1
  %409 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %410 = extractvalue { <8 x ptr>, <8 x i64> } %408, 1
  %411 = extractelement <8 x ptr> %409, i32 0
  %412 = extractelement <8 x i64> %410, i32 0
  %413 = sub i64 %412, 0
  %414 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %415 = select i1 %414, i64 %413, i64 0
  %private.contiguous.address112 = getelementptr i8, ptr %411, i64 %415
  %private.contiguous.preserve113 = load <8 x float>, ptr %private.contiguous.address112, align 4
  %416 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load109, <8 x float> %private.contiguous.preserve113
  store <8 x float> %416, ptr %private.contiguous.address112, align 4
  %.state114 = load <8 x i64>, ptr %.slot16, align 64
  %417 = add <8 x i64> %.state114, splat (i64 1)
  %418 = load <8 x i64>, ptr %.slot16, align 64
  %419 = select <8 x i1> %55, <8 x i64> %417, <8 x i64> %418
  store <8 x i64> %419, ptr %.slot16, align 64
  br label %direct.schedule.18

direct.schedule.20:                               ; preds = %direct.false104
  %.spill.load115 = load <8 x i1>, ptr %.spill12, align 1
  %420 = and <8 x i1> %55, %.spill.load115
  %421 = xor <8 x i1> %.spill.load115, splat (i1 true)
  %422 = and <8 x i1> %55, %421
  %423 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %420)
  %424 = bitcast <8 x i1> %420 to i8
  %425 = call i8 @llvm.cttz.i8(i8 %424, i1 false)
  %426 = zext i8 %425 to i32
  %427 = select i1 %423, i32 %426, i32 0
  %.spill.load116 = load <8 x i64>, ptr %.spill, align 64
  %428 = add <8 x i64> splat (i64 2048), %.spill.load116
  %.spill.load117 = load <8 x i64>, ptr %.spill10, align 64
  %429 = add <8 x i64> %.spill.load117, zeroinitializer
  %430 = add <8 x i64> zeroinitializer, %429
  %431 = add <8 x i64> zeroinitializer, %428
  %432 = mul <8 x i64> %430, splat (i64 2049)
  %433 = add <8 x i64> %432, %431
  %434 = extractvalue { ptr, i64 } %19, 0
  %435 = select <8 x i1> %420, <8 x i64> %433, <8 x i64> zeroinitializer
  %436 = extractelement <8 x i64> %435, i32 %427
  %437 = zext i32 %427 to i64
  %438 = sub i64 %436, %437
  %439 = mul i64 %438, 4
  %buffer.contiguous.address118 = getelementptr i8, ptr %434, i64 %439
  %buffer.contiguous.load119 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address118, <8 x i1> %420, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load120 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %440 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load120, 0
  %441 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load120, 1
  %442 = add <8 x i64> %441, splat (i64 8192)
  %443 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %440, 0
  %444 = insertvalue { <8 x ptr>, <8 x i64> } %443, <8 x i64> %442, 1
  %445 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %446 = extractvalue { <8 x ptr>, <8 x i64> } %444, 1
  %447 = extractelement <8 x ptr> %445, i32 0
  %448 = extractelement <8 x i64> %446, i32 %427
  %449 = zext i32 %427 to i64
  %450 = mul i64 %449, 4
  %451 = sub i64 %448, %450
  %452 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %420)
  %453 = select i1 %452, i64 %451, i64 0
  %private.contiguous.address121 = getelementptr i8, ptr %447, i64 %453
  %private.contiguous.preserve122 = load <8 x float>, ptr %private.contiguous.address121, align 4
  %454 = select <8 x i1> %420, <8 x float> %buffer.contiguous.load119, <8 x float> %private.contiguous.preserve122
  store <8 x float> %454, ptr %private.contiguous.address121, align 4
  %455 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %422)
  %456 = bitcast <8 x i1> %422 to i8
  %457 = call i8 @llvm.cttz.i8(i8 %456, i1 false)
  %458 = zext i8 %457 to i32
  %459 = select i1 %455, i32 %458, i32 0
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.20
  %460 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %461 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %462 = extractvalue { <8 x ptr>, <8 x i64> } %460, 0
  %463 = select <8 x i1> %55, <8 x ptr> %461, <8 x ptr> %462
  %464 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %465 = extractvalue { <8 x ptr>, <8 x i64> } %460, 1
  %466 = select <8 x i1> %55, <8 x i64> %464, <8 x i64> %465
  %467 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %463, 0
  %468 = insertvalue { <8 x ptr>, <8 x i64> } %467, <8 x i64> %466, 1
  store { <8 x ptr>, <8 x i64> } %468, ptr %tile_snapshot.spill17, align 64
  %469 = load <8 x i64>, ptr %.slot18, align 64
  %470 = select <8 x i1> %55, <8 x i64> zeroinitializer, <8 x i64> %469
  store <8 x i64> %470, ptr %.slot18, align 64
  br label %direct.schedule.23

direct.schedule.23:                               ; preds = %direct.schedule.24, %direct.schedule.22
  %.state123 = load <8 x i64>, ptr %.slot18, align 64
  %471 = icmp slt <8 x i64> %.state123, splat (i64 256)
  %472 = extractelement <8 x i1> %471, i32 0
  br i1 %472, label %direct.true124, label %direct.false125

direct.schedule.24:                               ; preds = %direct.true124
  %.state126 = load <8 x i64>, ptr %.slot18, align 64
  %473 = mul <8 x i64> %.state126, splat (i64 8)
  %.spill.load127 = load <8 x i64>, ptr %.spill, align 64
  %474 = add <8 x i64> %473, %.spill.load127
  %.spill.load128 = load <8 x i64>, ptr %.spill10, align 64
  %475 = add <8 x i64> %.spill.load128, zeroinitializer
  %476 = add <8 x i64> zeroinitializer, %475
  %477 = add <8 x i64> zeroinitializer, %474
  %478 = mul <8 x i64> %476, splat (i64 2049)
  %479 = add <8 x i64> %478, %477
  %480 = extractvalue { ptr, i64 } %25, 0
  %481 = extractelement <8 x i64> %479, i32 0
  %482 = sub i64 %481, 0
  %483 = mul i64 %482, 4
  %buffer.contiguous.address129 = getelementptr i8, ptr %480, i64 %483
  %buffer.contiguous.load130 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address129, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load131 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %484 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load131, 0
  %485 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load131, 1
  %.state132 = load <8 x i64>, ptr %.slot18, align 64
  %486 = mul <8 x i64> %.state132, splat (i64 32)
  %487 = add <8 x i64> %485, %486
  %488 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %484, 0
  %489 = insertvalue { <8 x ptr>, <8 x i64> } %488, <8 x i64> %487, 1
  %490 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %491 = extractvalue { <8 x ptr>, <8 x i64> } %489, 1
  %492 = extractelement <8 x ptr> %490, i32 0
  %493 = extractelement <8 x i64> %491, i32 0
  %494 = sub i64 %493, 0
  %495 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %496 = select i1 %495, i64 %494, i64 0
  %private.contiguous.address133 = getelementptr i8, ptr %492, i64 %496
  %private.contiguous.preserve134 = load <8 x float>, ptr %private.contiguous.address133, align 4
  %497 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load130, <8 x float> %private.contiguous.preserve134
  store <8 x float> %497, ptr %private.contiguous.address133, align 4
  %.state135 = load <8 x i64>, ptr %.slot18, align 64
  %498 = add <8 x i64> %.state135, splat (i64 1)
  %499 = load <8 x i64>, ptr %.slot18, align 64
  %500 = select <8 x i1> %55, <8 x i64> %498, <8 x i64> %499
  store <8 x i64> %500, ptr %.slot18, align 64
  br label %direct.schedule.23

direct.schedule.25:                               ; preds = %direct.false125
  %.spill.load136 = load <8 x i1>, ptr %.spill12, align 1
  %501 = and <8 x i1> %55, %.spill.load136
  %502 = xor <8 x i1> %.spill.load136, splat (i1 true)
  %503 = and <8 x i1> %55, %502
  %504 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %501)
  %505 = bitcast <8 x i1> %501 to i8
  %506 = call i8 @llvm.cttz.i8(i8 %505, i1 false)
  %507 = zext i8 %506 to i32
  %508 = select i1 %504, i32 %507, i32 0
  %.spill.load137 = load <8 x i64>, ptr %.spill, align 64
  %509 = add <8 x i64> splat (i64 2048), %.spill.load137
  %.spill.load138 = load <8 x i64>, ptr %.spill10, align 64
  %510 = add <8 x i64> %.spill.load138, zeroinitializer
  %511 = add <8 x i64> zeroinitializer, %510
  %512 = add <8 x i64> zeroinitializer, %509
  %513 = mul <8 x i64> %511, splat (i64 2049)
  %514 = add <8 x i64> %513, %512
  %515 = extractvalue { ptr, i64 } %25, 0
  %516 = select <8 x i1> %501, <8 x i64> %514, <8 x i64> zeroinitializer
  %517 = extractelement <8 x i64> %516, i32 %508
  %518 = zext i32 %508 to i64
  %519 = sub i64 %517, %518
  %520 = mul i64 %519, 4
  %buffer.contiguous.address139 = getelementptr i8, ptr %515, i64 %520
  %buffer.contiguous.load140 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address139, <8 x i1> %501, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load141 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %521 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 0
  %522 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 1
  %523 = add <8 x i64> %522, splat (i64 8192)
  %524 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %521, 0
  %525 = insertvalue { <8 x ptr>, <8 x i64> } %524, <8 x i64> %523, 1
  %526 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %527 = extractvalue { <8 x ptr>, <8 x i64> } %525, 1
  %528 = extractelement <8 x ptr> %526, i32 0
  %529 = extractelement <8 x i64> %527, i32 %508
  %530 = zext i32 %508 to i64
  %531 = mul i64 %530, 4
  %532 = sub i64 %529, %531
  %533 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %501)
  %534 = select i1 %533, i64 %532, i64 0
  %private.contiguous.address142 = getelementptr i8, ptr %528, i64 %534
  %private.contiguous.preserve143 = load <8 x float>, ptr %private.contiguous.address142, align 4
  %535 = select <8 x i1> %501, <8 x float> %buffer.contiguous.load140, <8 x float> %private.contiguous.preserve143
  store <8 x float> %535, ptr %private.contiguous.address142, align 4
  %536 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %503)
  %537 = bitcast <8 x i1> %503 to i8
  %538 = call i8 @llvm.cttz.i8(i8 %537, i1 false)
  %539 = zext i8 %538 to i32
  %540 = select i1 %536, i32 %539, i32 0
  br label %direct.schedule.27

direct.schedule.27:                               ; preds = %direct.schedule.25
  %541 = load <8 x i64>, ptr %.slot19, align 64
  %542 = select <8 x i1> %55, <8 x i64> zeroinitializer, <8 x i64> %541
  store <8 x i64> %542, ptr %.slot19, align 64
  br label %direct.schedule.28

direct.schedule.28:                               ; preds = %direct.schedule.29, %direct.schedule.27
  %.state144 = load <8 x i64>, ptr %.slot19, align 64
  %543 = icmp slt <8 x i64> %.state144, splat (i64 256)
  %544 = extractelement <8 x i1> %543, i32 0
  br i1 %544, label %direct.true145, label %direct.false146

direct.schedule.29:                               ; preds = %direct.true145
  %.state147 = load <8 x i64>, ptr %.slot19, align 64
  %545 = mul <8 x i64> %.state147, splat (i64 8)
  %.spill.load148 = load <8 x i64>, ptr %.spill, align 64
  %546 = add <8 x i64> %545, %.spill.load148
  %.spill.load149 = load <8 x i64>, ptr %.spill10, align 64
  %547 = add <8 x i64> %.spill.load149, zeroinitializer
  %548 = add <8 x i64> zeroinitializer, %547
  %549 = add <8 x i64> zeroinitializer, %546
  %550 = mul <8 x i64> %548, splat (i64 4098)
  %551 = add <8 x i64> %550, %549
  %tile_snapshot.spill.load150 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %552 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load150, 0
  %553 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load150, 1
  %.state151 = load <8 x i64>, ptr %.slot19, align 64
  %554 = mul <8 x i64> %.state151, splat (i64 32)
  %555 = add <8 x i64> %553, %554
  %556 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %552, 0
  %557 = insertvalue { <8 x ptr>, <8 x i64> } %556, <8 x i64> %555, 1
  %558 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %559 = extractvalue { <8 x ptr>, <8 x i64> } %557, 1
  %560 = extractelement <8 x ptr> %558, i32 0
  %561 = extractelement <8 x i64> %559, i32 0
  %562 = sub i64 %561, 0
  %563 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %564 = select i1 %563, i64 %562, i64 0
  %private.contiguous.address152 = getelementptr i8, ptr %560, i64 %564
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address152, align 4
  %565 = select <8 x i1> %55, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load153 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %566 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load153, 0
  %567 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load153, 1
  %.state154 = load <8 x i64>, ptr %.slot19, align 64
  %568 = mul <8 x i64> %.state154, splat (i64 32)
  %569 = add <8 x i64> %567, %568
  %570 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %566, 0
  %571 = insertvalue { <8 x ptr>, <8 x i64> } %570, <8 x i64> %569, 1
  %572 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %573 = extractvalue { <8 x ptr>, <8 x i64> } %571, 1
  %574 = extractelement <8 x ptr> %572, i32 0
  %575 = extractelement <8 x i64> %573, i32 0
  %576 = sub i64 %575, 0
  %577 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %578 = select i1 %577, i64 %576, i64 0
  %private.contiguous.address155 = getelementptr i8, ptr %574, i64 %578
  %private.contiguous.load156 = load <8 x float>, ptr %private.contiguous.address155, align 4
  %579 = select <8 x i1> %55, <8 x float> %private.contiguous.load156, <8 x float> zeroinitializer
  %580 = fmul <8 x float> %565, %579
  %tile_snapshot.spill.load157 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %581 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load157, 0
  %582 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load157, 1
  %.state158 = load <8 x i64>, ptr %.slot19, align 64
  %583 = mul <8 x i64> %.state158, splat (i64 32)
  %584 = add <8 x i64> %582, %583
  %585 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %581, 0
  %586 = insertvalue { <8 x ptr>, <8 x i64> } %585, <8 x i64> %584, 1
  %587 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %588 = extractvalue { <8 x ptr>, <8 x i64> } %586, 1
  %589 = extractelement <8 x ptr> %587, i32 0
  %590 = extractelement <8 x i64> %588, i32 0
  %591 = sub i64 %590, 0
  %592 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %593 = select i1 %592, i64 %591, i64 0
  %private.contiguous.address159 = getelementptr i8, ptr %589, i64 %593
  %private.contiguous.load160 = load <8 x float>, ptr %private.contiguous.address159, align 4
  %594 = select <8 x i1> %55, <8 x float> %private.contiguous.load160, <8 x float> zeroinitializer
  %tile_snapshot.spill.load161 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %595 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load161, 0
  %596 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load161, 1
  %.state162 = load <8 x i64>, ptr %.slot19, align 64
  %597 = mul <8 x i64> %.state162, splat (i64 32)
  %598 = add <8 x i64> %596, %597
  %599 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %595, 0
  %600 = insertvalue { <8 x ptr>, <8 x i64> } %599, <8 x i64> %598, 1
  %601 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %602 = extractvalue { <8 x ptr>, <8 x i64> } %600, 1
  %603 = extractelement <8 x ptr> %601, i32 0
  %604 = extractelement <8 x i64> %602, i32 0
  %605 = sub i64 %604, 0
  %606 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %607 = select i1 %606, i64 %605, i64 0
  %private.contiguous.address163 = getelementptr i8, ptr %603, i64 %607
  %private.contiguous.load164 = load <8 x float>, ptr %private.contiguous.address163, align 4
  %608 = select <8 x i1> %55, <8 x float> %private.contiguous.load164, <8 x float> zeroinitializer
  %609 = fmul <8 x float> %594, %608
  %610 = fsub <8 x float> %580, %609
  %611 = extractvalue { ptr, i64 } %31, 0
  %612 = extractelement <8 x i64> %551, i32 0
  %613 = sub i64 %612, 0
  %614 = mul i64 %613, 4
  %buffer.contiguous.address165 = getelementptr i8, ptr %611, i64 %614
  call void @llvm.masked.store.v8f32.p0(<8 x float> %610, ptr align 1 %buffer.contiguous.address165, <8 x i1> %55)
  %.state166 = load <8 x i64>, ptr %.slot19, align 64
  %615 = add <8 x i64> %.state166, splat (i64 1)
  %616 = load <8 x i64>, ptr %.slot19, align 64
  %617 = select <8 x i1> %55, <8 x i64> %615, <8 x i64> %616
  store <8 x i64> %617, ptr %.slot19, align 64
  br label %direct.schedule.28

direct.schedule.30:                               ; preds = %direct.false146
  %.spill.load167 = load <8 x i1>, ptr %.spill12, align 1
  %618 = and <8 x i1> %55, %.spill.load167
  %619 = xor <8 x i1> %.spill.load167, splat (i1 true)
  %620 = and <8 x i1> %55, %619
  %621 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %618)
  %622 = bitcast <8 x i1> %618 to i8
  %623 = call i8 @llvm.cttz.i8(i8 %622, i1 false)
  %624 = zext i8 %623 to i32
  %625 = select i1 %621, i32 %624, i32 0
  %.spill.load168 = load <8 x i64>, ptr %.spill, align 64
  %626 = add <8 x i64> splat (i64 2048), %.spill.load168
  %.spill.load169 = load <8 x i64>, ptr %.spill10, align 64
  %627 = add <8 x i64> %.spill.load169, zeroinitializer
  %628 = add <8 x i64> zeroinitializer, %627
  %629 = add <8 x i64> zeroinitializer, %626
  %630 = mul <8 x i64> %628, splat (i64 4098)
  %631 = add <8 x i64> %630, %629
  %tile_snapshot.spill.load170 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %632 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load170, 0
  %633 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load170, 1
  %634 = add <8 x i64> %633, splat (i64 8192)
  %635 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %632, 0
  %636 = insertvalue { <8 x ptr>, <8 x i64> } %635, <8 x i64> %634, 1
  %637 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %638 = extractvalue { <8 x ptr>, <8 x i64> } %636, 1
  %639 = extractelement <8 x ptr> %637, i32 0
  %640 = extractelement <8 x i64> %638, i32 %625
  %641 = zext i32 %625 to i64
  %642 = mul i64 %641, 4
  %643 = sub i64 %640, %642
  %644 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %618)
  %645 = select i1 %644, i64 %643, i64 0
  %private.contiguous.address171 = getelementptr i8, ptr %639, i64 %645
  %private.contiguous.load172 = load <8 x float>, ptr %private.contiguous.address171, align 4
  %646 = select <8 x i1> %618, <8 x float> %private.contiguous.load172, <8 x float> zeroinitializer
  %tile_snapshot.spill.load173 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %647 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load173, 0
  %648 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load173, 1
  %649 = add <8 x i64> %648, splat (i64 8192)
  %650 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %647, 0
  %651 = insertvalue { <8 x ptr>, <8 x i64> } %650, <8 x i64> %649, 1
  %652 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %653 = extractvalue { <8 x ptr>, <8 x i64> } %651, 1
  %654 = extractelement <8 x ptr> %652, i32 0
  %655 = extractelement <8 x i64> %653, i32 %625
  %656 = zext i32 %625 to i64
  %657 = mul i64 %656, 4
  %658 = sub i64 %655, %657
  %659 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %618)
  %660 = select i1 %659, i64 %658, i64 0
  %private.contiguous.address174 = getelementptr i8, ptr %654, i64 %660
  %private.contiguous.load175 = load <8 x float>, ptr %private.contiguous.address174, align 4
  %661 = select <8 x i1> %618, <8 x float> %private.contiguous.load175, <8 x float> zeroinitializer
  %662 = fmul <8 x float> %646, %661
  %tile_snapshot.spill.load176 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %663 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load176, 0
  %664 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load176, 1
  %665 = add <8 x i64> %664, splat (i64 8192)
  %666 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %663, 0
  %667 = insertvalue { <8 x ptr>, <8 x i64> } %666, <8 x i64> %665, 1
  %668 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %669 = extractvalue { <8 x ptr>, <8 x i64> } %667, 1
  %670 = extractelement <8 x ptr> %668, i32 0
  %671 = extractelement <8 x i64> %669, i32 %625
  %672 = zext i32 %625 to i64
  %673 = mul i64 %672, 4
  %674 = sub i64 %671, %673
  %675 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %618)
  %676 = select i1 %675, i64 %674, i64 0
  %private.contiguous.address177 = getelementptr i8, ptr %670, i64 %676
  %private.contiguous.load178 = load <8 x float>, ptr %private.contiguous.address177, align 4
  %677 = select <8 x i1> %618, <8 x float> %private.contiguous.load178, <8 x float> zeroinitializer
  %tile_snapshot.spill.load179 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %678 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load179, 0
  %679 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load179, 1
  %680 = add <8 x i64> %679, splat (i64 8192)
  %681 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %678, 0
  %682 = insertvalue { <8 x ptr>, <8 x i64> } %681, <8 x i64> %680, 1
  %683 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %684 = extractvalue { <8 x ptr>, <8 x i64> } %682, 1
  %685 = extractelement <8 x ptr> %683, i32 0
  %686 = extractelement <8 x i64> %684, i32 %625
  %687 = zext i32 %625 to i64
  %688 = mul i64 %687, 4
  %689 = sub i64 %686, %688
  %690 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %618)
  %691 = select i1 %690, i64 %689, i64 0
  %private.contiguous.address180 = getelementptr i8, ptr %685, i64 %691
  %private.contiguous.load181 = load <8 x float>, ptr %private.contiguous.address180, align 4
  %692 = select <8 x i1> %618, <8 x float> %private.contiguous.load181, <8 x float> zeroinitializer
  %693 = fmul <8 x float> %677, %692
  %694 = fsub <8 x float> %662, %693
  %695 = extractvalue { ptr, i64 } %31, 0
  %696 = extractelement <8 x i64> %631, i32 %625
  %697 = zext i32 %625 to i64
  %698 = sub i64 %696, %697
  %699 = mul i64 %698, 4
  %buffer.contiguous.address182 = getelementptr i8, ptr %695, i64 %699
  call void @llvm.masked.store.v8f32.p0(<8 x float> %694, ptr align 1 %buffer.contiguous.address182, <8 x i1> %618)
  %700 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %620)
  %701 = bitcast <8 x i1> %620 to i8
  %702 = call i8 @llvm.cttz.i8(i8 %701, i1 false)
  %703 = zext i8 %702 to i32
  %704 = select i1 %700, i32 %703, i32 0
  br label %direct.schedule.32

direct.schedule.32:                               ; preds = %direct.schedule.30
  %705 = load <8 x i64>, ptr %.slot20, align 64
  %706 = select <8 x i1> %55, <8 x i64> zeroinitializer, <8 x i64> %705
  store <8 x i64> %706, ptr %.slot20, align 64
  br label %direct.schedule.33

direct.schedule.33:                               ; preds = %direct.schedule.34, %direct.schedule.32
  %.state183 = load <8 x i64>, ptr %.slot20, align 64
  %707 = icmp slt <8 x i64> %.state183, splat (i64 256)
  %708 = extractelement <8 x i1> %707, i32 0
  br i1 %708, label %direct.true184, label %direct.false185

direct.schedule.34:                               ; preds = %direct.true184
  %.state186 = load <8 x i64>, ptr %.slot20, align 64
  %709 = mul <8 x i64> %.state186, splat (i64 8)
  %.spill.load187 = load <8 x i64>, ptr %.spill, align 64
  %710 = add <8 x i64> %709, %.spill.load187
  %.spill.load188 = load <8 x i64>, ptr %.spill10, align 64
  %711 = add <8 x i64> %.spill.load188, zeroinitializer
  %712 = add <8 x i64> zeroinitializer, %711
  %713 = add <8 x i64> splat (i64 2049), %710
  %714 = mul <8 x i64> %712, splat (i64 4098)
  %715 = add <8 x i64> %714, %713
  %tile_snapshot.spill.load189 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %716 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 0
  %717 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 1
  %.state190 = load <8 x i64>, ptr %.slot20, align 64
  %718 = mul <8 x i64> %.state190, splat (i64 32)
  %719 = add <8 x i64> %717, %718
  %720 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %716, 0
  %721 = insertvalue { <8 x ptr>, <8 x i64> } %720, <8 x i64> %719, 1
  %722 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %723 = extractvalue { <8 x ptr>, <8 x i64> } %721, 1
  %724 = extractelement <8 x ptr> %722, i32 0
  %725 = extractelement <8 x i64> %723, i32 0
  %726 = sub i64 %725, 0
  %727 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %728 = select i1 %727, i64 %726, i64 0
  %private.contiguous.address191 = getelementptr i8, ptr %724, i64 %728
  %private.contiguous.load192 = load <8 x float>, ptr %private.contiguous.address191, align 4
  %729 = select <8 x i1> %55, <8 x float> %private.contiguous.load192, <8 x float> zeroinitializer
  %tile_snapshot.spill.load193 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %730 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load193, 0
  %731 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load193, 1
  %.state194 = load <8 x i64>, ptr %.slot20, align 64
  %732 = mul <8 x i64> %.state194, splat (i64 32)
  %733 = add <8 x i64> %731, %732
  %734 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %730, 0
  %735 = insertvalue { <8 x ptr>, <8 x i64> } %734, <8 x i64> %733, 1
  %736 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %737 = extractvalue { <8 x ptr>, <8 x i64> } %735, 1
  %738 = extractelement <8 x ptr> %736, i32 0
  %739 = extractelement <8 x i64> %737, i32 0
  %740 = sub i64 %739, 0
  %741 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %742 = select i1 %741, i64 %740, i64 0
  %private.contiguous.address195 = getelementptr i8, ptr %738, i64 %742
  %private.contiguous.load196 = load <8 x float>, ptr %private.contiguous.address195, align 4
  %743 = select <8 x i1> %55, <8 x float> %private.contiguous.load196, <8 x float> zeroinitializer
  %744 = fmul <8 x float> %729, %743
  %tile_snapshot.spill.load197 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %745 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load197, 0
  %746 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load197, 1
  %.state198 = load <8 x i64>, ptr %.slot20, align 64
  %747 = mul <8 x i64> %.state198, splat (i64 32)
  %748 = add <8 x i64> %746, %747
  %749 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %745, 0
  %750 = insertvalue { <8 x ptr>, <8 x i64> } %749, <8 x i64> %748, 1
  %751 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %752 = extractvalue { <8 x ptr>, <8 x i64> } %750, 1
  %753 = extractelement <8 x ptr> %751, i32 0
  %754 = extractelement <8 x i64> %752, i32 0
  %755 = sub i64 %754, 0
  %756 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %757 = select i1 %756, i64 %755, i64 0
  %private.contiguous.address199 = getelementptr i8, ptr %753, i64 %757
  %private.contiguous.load200 = load <8 x float>, ptr %private.contiguous.address199, align 4
  %758 = select <8 x i1> %55, <8 x float> %private.contiguous.load200, <8 x float> zeroinitializer
  %tile_snapshot.spill.load201 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %759 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load201, 0
  %760 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load201, 1
  %.state202 = load <8 x i64>, ptr %.slot20, align 64
  %761 = mul <8 x i64> %.state202, splat (i64 32)
  %762 = add <8 x i64> %760, %761
  %763 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %759, 0
  %764 = insertvalue { <8 x ptr>, <8 x i64> } %763, <8 x i64> %762, 1
  %765 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %766 = extractvalue { <8 x ptr>, <8 x i64> } %764, 1
  %767 = extractelement <8 x ptr> %765, i32 0
  %768 = extractelement <8 x i64> %766, i32 0
  %769 = sub i64 %768, 0
  %770 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %771 = select i1 %770, i64 %769, i64 0
  %private.contiguous.address203 = getelementptr i8, ptr %767, i64 %771
  %private.contiguous.load204 = load <8 x float>, ptr %private.contiguous.address203, align 4
  %772 = select <8 x i1> %55, <8 x float> %private.contiguous.load204, <8 x float> zeroinitializer
  %773 = fmul <8 x float> %758, %772
  %774 = fadd <8 x float> %744, %773
  %775 = extractvalue { ptr, i64 } %31, 0
  %776 = extractelement <8 x i64> %715, i32 0
  %777 = sub i64 %776, 0
  %778 = mul i64 %777, 4
  %buffer.contiguous.address205 = getelementptr i8, ptr %775, i64 %778
  call void @llvm.masked.store.v8f32.p0(<8 x float> %774, ptr align 1 %buffer.contiguous.address205, <8 x i1> %55)
  %.state206 = load <8 x i64>, ptr %.slot20, align 64
  %779 = add <8 x i64> %.state206, splat (i64 1)
  %780 = load <8 x i64>, ptr %.slot20, align 64
  %781 = select <8 x i1> %55, <8 x i64> %779, <8 x i64> %780
  store <8 x i64> %781, ptr %.slot20, align 64
  br label %direct.schedule.33

direct.schedule.35:                               ; preds = %direct.false185
  %.spill.load207 = load <8 x i1>, ptr %.spill12, align 1
  %782 = and <8 x i1> %55, %.spill.load207
  %783 = xor <8 x i1> %.spill.load207, splat (i1 true)
  %784 = and <8 x i1> %55, %783
  %785 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %782)
  %786 = bitcast <8 x i1> %782 to i8
  %787 = call i8 @llvm.cttz.i8(i8 %786, i1 false)
  %788 = zext i8 %787 to i32
  %789 = select i1 %785, i32 %788, i32 0
  %.spill.load208 = load <8 x i64>, ptr %.spill, align 64
  %790 = add <8 x i64> splat (i64 2048), %.spill.load208
  %.spill.load209 = load <8 x i64>, ptr %.spill10, align 64
  %791 = add <8 x i64> %.spill.load209, zeroinitializer
  %792 = add <8 x i64> zeroinitializer, %791
  %793 = add <8 x i64> splat (i64 2049), %790
  %794 = mul <8 x i64> %792, splat (i64 4098)
  %795 = add <8 x i64> %794, %793
  %tile_snapshot.spill.load210 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %796 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load210, 0
  %797 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load210, 1
  %798 = add <8 x i64> %797, splat (i64 8192)
  %799 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %796, 0
  %800 = insertvalue { <8 x ptr>, <8 x i64> } %799, <8 x i64> %798, 1
  %801 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %802 = extractvalue { <8 x ptr>, <8 x i64> } %800, 1
  %803 = extractelement <8 x ptr> %801, i32 0
  %804 = extractelement <8 x i64> %802, i32 %789
  %805 = zext i32 %789 to i64
  %806 = mul i64 %805, 4
  %807 = sub i64 %804, %806
  %808 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %782)
  %809 = select i1 %808, i64 %807, i64 0
  %private.contiguous.address211 = getelementptr i8, ptr %803, i64 %809
  %private.contiguous.load212 = load <8 x float>, ptr %private.contiguous.address211, align 4
  %810 = select <8 x i1> %782, <8 x float> %private.contiguous.load212, <8 x float> zeroinitializer
  %tile_snapshot.spill.load213 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %811 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load213, 0
  %812 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load213, 1
  %813 = add <8 x i64> %812, splat (i64 8192)
  %814 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %811, 0
  %815 = insertvalue { <8 x ptr>, <8 x i64> } %814, <8 x i64> %813, 1
  %816 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %817 = extractvalue { <8 x ptr>, <8 x i64> } %815, 1
  %818 = extractelement <8 x ptr> %816, i32 0
  %819 = extractelement <8 x i64> %817, i32 %789
  %820 = zext i32 %789 to i64
  %821 = mul i64 %820, 4
  %822 = sub i64 %819, %821
  %823 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %782)
  %824 = select i1 %823, i64 %822, i64 0
  %private.contiguous.address214 = getelementptr i8, ptr %818, i64 %824
  %private.contiguous.load215 = load <8 x float>, ptr %private.contiguous.address214, align 4
  %825 = select <8 x i1> %782, <8 x float> %private.contiguous.load215, <8 x float> zeroinitializer
  %826 = fmul <8 x float> %810, %825
  %tile_snapshot.spill.load216 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %827 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load216, 0
  %828 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load216, 1
  %829 = add <8 x i64> %828, splat (i64 8192)
  %830 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %827, 0
  %831 = insertvalue { <8 x ptr>, <8 x i64> } %830, <8 x i64> %829, 1
  %832 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %833 = extractvalue { <8 x ptr>, <8 x i64> } %831, 1
  %834 = extractelement <8 x ptr> %832, i32 0
  %835 = extractelement <8 x i64> %833, i32 %789
  %836 = zext i32 %789 to i64
  %837 = mul i64 %836, 4
  %838 = sub i64 %835, %837
  %839 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %782)
  %840 = select i1 %839, i64 %838, i64 0
  %private.contiguous.address217 = getelementptr i8, ptr %834, i64 %840
  %private.contiguous.load218 = load <8 x float>, ptr %private.contiguous.address217, align 4
  %841 = select <8 x i1> %782, <8 x float> %private.contiguous.load218, <8 x float> zeroinitializer
  %tile_snapshot.spill.load219 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %842 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load219, 0
  %843 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load219, 1
  %844 = add <8 x i64> %843, splat (i64 8192)
  %845 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %842, 0
  %846 = insertvalue { <8 x ptr>, <8 x i64> } %845, <8 x i64> %844, 1
  %847 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %848 = extractvalue { <8 x ptr>, <8 x i64> } %846, 1
  %849 = extractelement <8 x ptr> %847, i32 0
  %850 = extractelement <8 x i64> %848, i32 %789
  %851 = zext i32 %789 to i64
  %852 = mul i64 %851, 4
  %853 = sub i64 %850, %852
  %854 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %782)
  %855 = select i1 %854, i64 %853, i64 0
  %private.contiguous.address220 = getelementptr i8, ptr %849, i64 %855
  %private.contiguous.load221 = load <8 x float>, ptr %private.contiguous.address220, align 4
  %856 = select <8 x i1> %782, <8 x float> %private.contiguous.load221, <8 x float> zeroinitializer
  %857 = fmul <8 x float> %841, %856
  %858 = fadd <8 x float> %826, %857
  %859 = extractvalue { ptr, i64 } %31, 0
  %860 = extractelement <8 x i64> %795, i32 %789
  %861 = zext i32 %789 to i64
  %862 = sub i64 %860, %861
  %863 = mul i64 %862, 4
  %buffer.contiguous.address222 = getelementptr i8, ptr %859, i64 %863
  call void @llvm.masked.store.v8f32.p0(<8 x float> %858, ptr align 1 %buffer.contiguous.address222, <8 x i1> %782)
  %864 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %784)
  %865 = bitcast <8 x i1> %784 to i8
  %866 = call i8 @llvm.cttz.i8(i8 %865, i1 false)
  %867 = zext i8 %866 to i32
  %868 = select i1 %864, i32 %867, i32 0
  br label %direct.schedule.6

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.0
  br label %direct.schedule.1

direct.false:                                     ; preds = %direct.schedule.0
  br label %direct.schedule.7

direct.true31:                                    ; preds = %direct.schedule.2
  br label %direct.schedule.3

direct.false32:                                   ; preds = %direct.schedule.2
  br label %direct.schedule.4

direct.true60:                                    ; preds = %direct.schedule.8
  br label %direct.schedule.9

direct.false61:                                   ; preds = %direct.schedule.8
  br label %direct.schedule.10

direct.true82:                                    ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false83:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true103:                                   ; preds = %direct.schedule.18
  br label %direct.schedule.19

direct.false104:                                  ; preds = %direct.schedule.18
  br label %direct.schedule.20

direct.true124:                                   ; preds = %direct.schedule.23
  br label %direct.schedule.24

direct.false125:                                  ; preds = %direct.schedule.23
  br label %direct.schedule.25

direct.true145:                                   ; preds = %direct.schedule.28
  br label %direct.schedule.29

direct.false146:                                  ; preds = %direct.schedule.28
  br label %direct.schedule.30

direct.true184:                                   ; preds = %direct.schedule.33
  br label %direct.schedule.34

direct.false185:                                  ; preds = %direct.schedule.33
  br label %direct.schedule.35
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count) #3
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #3 = { noinline }

	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_3:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_4:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_7:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_8:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_9:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_10:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_12:
	.quad	0                               ; 0x0
	.quad	8                               ; 0x8
lCPI0_13:
	.quad	32                              ; 0x20
	.quad	40                              ; 0x28
lCPI0_14:
	.quad	16                              ; 0x10
	.quad	24                              ; 0x18
lCPI0_15:
	.quad	48                              ; 0x30
	.quad	56                              ; 0x38
lCPI0_16:
	.quad	1158                            ; 0x486
	.quad	1351                            ; 0x547
lCPI0_17:
	.quad	386                             ; 0x182
	.quad	579                             ; 0x243
lCPI0_18:
	.quad	772                             ; 0x304
	.quad	965                             ; 0x3c5
lCPI0_19:
	.quad	0                               ; 0x0
	.quad	193                             ; 0xc1
lCPI0_21:
	.long	5                               ; 0x5
	.long	4                               ; 0x4
	.long	7                               ; 0x7
	.long	6                               ; 0x6
lCPI0_22:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	3                               ; 0x3
	.long	2                               ; 0x2
lCPI0_23:
	.long	6                               ; 0x6
	.long	7                               ; 0x7
	.long	4                               ; 0x4
	.long	5                               ; 0x5
lCPI0_24:
	.long	2                               ; 0x2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	1                               ; 0x1
lCPI0_25:
	.long	4                               ; 0x4
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_11:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
lCPI0_20:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	dup.4s	v7, w2
Lloh0:
	adrp	x8, lCPI0_1@PAGE
Lloh1:
	ldr	q3, [x8, lCPI0_1@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_2@PAGE
Lloh3:
	ldr	q5, [x8, lCPI0_2@PAGEOFF]
	cmhi.4s	v0, v7, v5
	cmhi.4s	v1, v7, v3
	uzp1.8h	v4, v1, v0
	umaxv.8h	h2, v4
	fmov	w8, s2
	tbz	w8, #0, LBB0_150
; %bb.1:                                ; %direct.activate
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #8, lsl #12             ; =32768
	sub	sp, sp, #1904
	str	q5, [sp, #432]                  ; 16-byte Spill
	mov	x9, #0                          ; =0x0
	add	x4, sp, #2248
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #2312
	dup.2d	v2, x8
	stp	q2, q3, [sp, #528]              ; 32-byte Folded Spill
	ldr	x8, [x0]
	ldr	x10, [x0, #48]
	str	x10, [sp, #248]                 ; 8-byte Spill
Lloh4:
	adrp	x10, lCPI0_0@PAGE
Lloh5:
	ldr	q2, [x10, lCPI0_0@PAGEOFF]
	and.16b	v2, v4, v2
	addv.8h	h5, v2
	fmov	w10, s5
	ldr	w11, [x1]
	ldr	w12, [x1, #36]
	add	w11, w12, w11, lsl #5
	lsr	w11, w11, #3
	dup.4s	v2, w11
	and	w12, w10, #0xff
	and.16b	v25, v1, v2
	and.16b	v26, v0, v2
	ushll2.2d	v16, v26, #0
	ushll2.2d	v17, v25, #0
	ushll.2d	v18, v26, #0
	ushll.2d	v3, v25, #0
	fmov	x10, d3
	mov	w11, #6152                      ; =0x1808
	umaddl	x10, w10, w11, x8
	str	q5, [sp, #464]                  ; 16-byte Spill
	fmov	w11, s5
	add	x13, sp, #6, lsl #12            ; =24576
	add	x13, x13, #3920
	b	LBB0_3
LBB0_2:                                 ; %else48
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x14, x13, x9, lsl #5
	stp	q5, q2, [x14]
	add	x9, x9, #1
	cmp	x9, #192
	b.eq	LBB0_19
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x15, x9, #5
	add	x14, x10, x15
	add	x16, x13, x15
	ldr	q5, [x16]
	tbnz	w11, #0, LBB0_11
; %bb.4:                                ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w15, w11, #0xff
	tbnz	w15, #1, LBB0_12
LBB0_5:                                 ; %else30
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w15, #2, LBB0_13
LBB0_6:                                 ; %else33
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w15, #3, LBB0_14
LBB0_7:                                 ; %else36
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q2, [x16, #16]
	tbnz	w15, #4, LBB0_15
LBB0_8:                                 ; %else39
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w15, #5, LBB0_16
LBB0_9:                                 ; %else42
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w15, #6, LBB0_17
LBB0_10:                                ; %else45
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w15, #7, LBB0_2
	b	LBB0_18
LBB0_11:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	ld1.s	{ v5 }[0], [x14]
	and	w15, w11, #0xff
	tbz	w15, #1, LBB0_5
LBB0_12:                                ; %cond.load29
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x14, #4
	ld1.s	{ v5 }[1], [x17]
	tbz	w15, #2, LBB0_6
LBB0_13:                                ; %cond.load32
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x14, #8
	ld1.s	{ v5 }[2], [x17]
	tbz	w15, #3, LBB0_7
LBB0_14:                                ; %cond.load35
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x14, #12
	ld1.s	{ v5 }[3], [x17]
	ldr	q2, [x16, #16]
	tbz	w15, #4, LBB0_8
LBB0_15:                                ; %cond.load38
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x16, x14, #16
	ld1.s	{ v2 }[0], [x16]
	tbz	w15, #5, LBB0_9
LBB0_16:                                ; %cond.load41
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x16, x14, #20
	ld1.s	{ v2 }[1], [x16]
	tbz	w15, #6, LBB0_10
LBB0_17:                                ; %cond.load44
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x16, x14, #24
	ld1.s	{ v2 }[2], [x16]
	tbz	w15, #7, LBB0_2
LBB0_18:                                ; %cond.load47
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x14, x14, #28
	ld1.s	{ v2 }[3], [x14]
	b	LBB0_2
LBB0_19:                                ; %direct.false
	xtn.8b	v21, v4
	sshll.2d	v2, v1, #0
	sshll.2d	v6, v0, #0
	sshll2.2d	v19, v1, #0
	sshll2.2d	v27, v0, #0
Lloh6:
	adrp	x9, lCPI0_6@PAGE
Lloh7:
	ldr	q8, [x9, lCPI0_6@PAGEOFF]
	and.16b	v22, v2, v8
	movi.2d	v4, #0000000000000000
Lloh8:
	adrp	x9, lCPI0_7@PAGE
Lloh9:
	ldr	q5, [x9, lCPI0_7@PAGEOFF]
	and.16b	v28, v2, v5
Lloh10:
	adrp	x9, lCPI0_8@PAGE
Lloh11:
	ldr	q2, [x9, lCPI0_8@PAGEOFF]
	and.16b	v2, v6, v2
Lloh12:
	adrp	x9, lCPI0_9@PAGE
Lloh13:
	ldr	q5, [x9, lCPI0_9@PAGEOFF]
	str	q19, [sp, #336]                 ; 16-byte Spill
	and.16b	v5, v19, v5
Lloh14:
	adrp	x9, lCPI0_10@PAGE
Lloh15:
	ldr	q19, [x9, lCPI0_10@PAGEOFF]
	and.16b	v20, v27, v19
	movi	d19, #0x0000000000ffff
	and.8b	v23, v21, v19
Lloh16:
	adrp	x9, lCPI0_11@PAGE
Lloh17:
	ldr	d19, [x9, lCPI0_11@PAGEOFF]
	str	q21, [sp, #320]                 ; 16-byte Spill
	and.8b	v19, v21, v19
	addv.8b	b19, v19
	fmov	w13, s19
	umaxv.8b	b19, v23
	fmov	w9, s19
	rbit	w10, w13
	clz	w10, w10
	tst	w9, #0x1
	csel	w3, w10, wzr, ne
	mov	w9, #1536                       ; =0x600
	dup.2d	v21, x9
	str	q22, [sp, #112]                 ; 16-byte Spill
	orr.16b	v24, v22, v21
	mov	w9, #1538                       ; =0x602
	dup.2s	v19, w9
	xtn.2s	v3, v3
	str	q24, [sp, #512]                 ; 16-byte Spill
	umlal.2d	v24, v3, v19
	mov	b22, v23[0]
	str	q23, [sp, #352]                 ; 16-byte Spill
	mov.b	v22[4], v23[1]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	str	q24, [sp, #224]                 ; 16-byte Spill
	and.16b	v22, v22, v24
	str	q4, [sp, #2160]
	str	q4, [sp, #2144]
	str	q4, [sp, #2128]
	str	q22, [sp, #2112]
	ubfiz	x9, x3, #3, #3
	add	x10, sp, #2112
	ldr	x10, [x10, x9]
	sub	x10, x10, x3
	add	x8, x8, x10, lsl #2
	str	q20, [sp, #2224]
	str	q2, [sp, #2208]
	str	q5, [sp, #2192]
	str	q28, [sp, #80]                  ; 16-byte Spill
	str	q28, [sp, #2176]
	add	x10, sp, #2176
	ldr	x9, [x10, x9]
	orr	x9, x9, #0x1800
	sub	x9, x9, w3, uxtw #2
	tst	w13, #0xff
	csel	x5, xzr, x9, eq
	add	x9, sp, #6, lsl #12             ; =24576
	add	x9, x9, #3920
	add	x9, x9, x5
	ldr	q23, [x9]
	tbnz	w13, #0, LBB0_78
; %bb.20:                               ; %else52
	tbnz	w13, #1, LBB0_79
LBB0_21:                                ; %else55
	tbnz	w13, #2, LBB0_80
LBB0_22:                                ; %else58
	tbnz	w13, #3, LBB0_81
LBB0_23:                                ; %else61
	adrp	x10, lCPI0_3@PAGE
	adrp	x11, lCPI0_4@PAGE
	adrp	x14, lCPI0_5@PAGE
	ldr	q28, [x9, #16]
	tbnz	w13, #4, LBB0_82
LBB0_24:                                ; %else64
	ldr	q5, [x10, lCPI0_3@PAGEOFF]
	ldr	q20, [x11, lCPI0_4@PAGEOFF]
	ldr	q10, [x14, lCPI0_5@PAGEOFF]
	tbnz	w13, #5, LBB0_83
LBB0_25:                                ; %else67
	and.16b	v22, v27, v5
	ldr	q2, [sp, #336]                  ; 16-byte Reload
	and.16b	v2, v2, v20
	and.16b	v4, v6, v10
	str	q27, [sp, #304]                 ; 16-byte Spill
	tbz	w13, #6, LBB0_27
LBB0_26:                                ; %cond.load69
	add	x9, x8, #24
	ld1.s	{ v28 }[2], [x9]
LBB0_27:                                ; %else70
	stp	q4, q2, [sp, #32]               ; 32-byte Folded Spill
	orr.16b	v24, v4, v21
	orr.16b	v4, v2, v21
	orr.16b	v30, v22, v21
	xtn.2s	v6, v17
	xtn.2s	v2, v18
	xtn.2s	v16, v16
	str	q22, [sp, #64]                  ; 16-byte Spill
	tbz	w13, #7, LBB0_29
; %bb.28:                               ; %cond.load72
	add	x8, x8, #28
	ld1.s	{ v28 }[3], [x8]
LBB0_29:                                ; %else73
	ldr	q17, [sp, #464]                 ; 16-byte Reload
	mov	x8, #0                          ; =0x0
	umull.2d	v3, v3, v19
	str	q3, [sp, #160]                  ; 16-byte Spill
	mov.16b	v3, v30
	umlal.2d	v3, v16, v19
	str	q3, [sp, #208]                  ; 16-byte Spill
	mov.16b	v3, v4
	umlal.2d	v3, v6, v19
	str	q3, [sp, #192]                  ; 16-byte Spill
	mov.16b	v3, v24
	umlal.2d	v3, v2, v19
	str	q3, [sp, #176]                  ; 16-byte Spill
	ushll2.2d	v2, v0, #0
	mov	w9, #1                          ; =0x1
	dup.2d	v3, x9
	and.16b	v18, v2, v3
	add	x9, sp, #6, lsl #12             ; =24576
	add	x9, x9, #3920
	add	x9, x9, x5
	str	q28, [sp, #448]                 ; 16-byte Spill
	stp	q23, q28, [x9]
	str	q23, [sp, #272]                 ; 16-byte Spill
	ushll2.2d	v2, v1, #0
	and.16b	v19, v2, v3
	ushll.2d	v2, v0, #0
	and.16b	v28, v2, v3
	ushll.2d	v2, v1, #0
	and.16b	v31, v2, v3
	movi.2d	v2, #0000000000000000
	sshll.2d	v3, v0, #0
	sshll.2d	v6, v1, #0
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #3856
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	ldr	q16, [sp, #336]                 ; 16-byte Reload
	ldr	q29, [sp, #304]                 ; 16-byte Reload
	str	q28, [sp, #480]                 ; 16-byte Spill
LBB0_30:                                ; %direct.true69
                                        ; =>This Inner Loop Header: Depth=1
	shl.2d	v12, v23, #3
	shl.2d	v13, v2, #3
	shl.2d	v14, v22, #3
	shl.2d	v15, v21, #3
	orr.16b	v15, v15, v20
	orr.16b	v14, v14, v10
	orr.16b	v13, v13, v8
	orr.16b	v12, v12, v5
	add	x8, x9, x8, lsl #6
	ldp	q11, q9, [x8]
	ldp	q27, q28, [x8, #32]
	bit.16b	v28, v12, v29
	bit.16b	v11, v13, v6
	bit.16b	v27, v14, v3
	bit.16b	v9, v15, v16
	stp	q11, q9, [x8]
	stp	q27, q28, [x8, #32]
	ldr	q28, [sp, #480]                 ; 16-byte Reload
	add.2d	v21, v21, v19
	add.2d	v22, v22, v28
	add.2d	v23, v23, v18
	add.2d	v2, v2, v31
	fmov	x8, d2
	cmp	x8, #192
	b.lt	LBB0_30
; %bb.31:                               ; %direct.false70
	mov	x8, #0                          ; =0x0
	sshll.2d	v21, v0, #0
	sshll.2d	v3, v1, #0
Lloh18:
	adrp	x9, lCPI0_12@PAGE
Lloh19:
	ldr	q2, [x9, lCPI0_12@PAGEOFF]
	and.16b	v8, v3, v2
Lloh20:
	adrp	x9, lCPI0_13@PAGE
Lloh21:
	ldr	q2, [x9, lCPI0_13@PAGEOFF]
	and.16b	v2, v21, v2
Lloh22:
	adrp	x9, lCPI0_14@PAGE
Lloh23:
	ldr	q5, [x9, lCPI0_14@PAGEOFF]
	and.16b	v5, v16, v5
Lloh24:
	adrp	x9, lCPI0_15@PAGE
Lloh25:
	ldr	q6, [x9, lCPI0_15@PAGEOFF]
	and.16b	v6, v29, v6
	mov	w9, #1538                       ; =0x602
	dup.4s	v20, w9
	str	q6, [sp, #2096]
	str	q2, [sp, #2080]
	and.16b	v2, v1, v20
	mvn.16b	v6, v1
	and.16b	v20, v0, v20
	mvn.16b	v22, v0
	sub.4s	v20, v20, v22
	mov.s	w9, v20[1]
	mov.s	w10, v20[2]
	mov.s	w11, v20[3]
	sub.4s	v2, v2, v6
	fmov	w14, s20
	fmov	w15, s26
	udiv	w16, w15, w14
	mov.s	w17, v26[1]
	msub	w14, w16, w14, w15
	udiv	w15, w17, w9
	msub	w9, w15, w9, w17
	mov.s	w15, v26[2]
	udiv	w16, w15, w10
	msub	w10, w16, w10, w15
	mov.s	w15, v26[3]
	udiv	w16, w15, w11
	mov.s	w17, v2[1]
	msub	w11, w16, w11, w15
	mov.s	w15, v2[2]
	mov.s	w16, v2[3]
	fmov	w0, s2
	fmov	w1, s25
	udiv	w2, w1, w0
	msub	w0, w2, w0, w1
	mov.s	w1, v25[1]
	str	q5, [sp, #2064]
	str	q8, [sp, #2048]
	udiv	w2, w1, w17
	msub	w17, w2, w17, w1
	mov.s	w1, v25[2]
	udiv	w2, w1, w15
	msub	w15, w2, w15, w1
	mov.s	w1, v25[3]
	udiv	w2, w1, w16
	msub	w16, w2, w16, w1
	and	x1, x3, #0x7
	add	x2, sp, #2048
	ldr	x1, [x2, x1, lsl #3]
	fmov	s2, w14
	mov.s	v2[1], w9
	tst	w13, #0xff
	mov.s	v2[2], w10
	mov.s	v2[3], w11
	fmov	s5, w0
	mov.s	v5[1], w17
	orr	x9, x1, #0x3000
	sub	x9, x9, x3, lsl #3
	mov.s	v5[2], w15
	csel	x10, xzr, x9, eq
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #3856
	add	x10, x9, x10
	ldp	q6, q20, [x10, #32]
	ldp	q22, q23, [x10]
	ldr	q16, [sp, #352]                 ; 16-byte Reload
	mov	b25, v16[2]
	mov.b	v25[4], v16[3]
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	mov.16b	v12, v25
	bsl.16b	v12, v4, v23
	mov	b23, v16[0]
	mov.b	v23[4], v16[1]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v23, v23, #0
	ldr	q4, [sp, #512]                  ; 16-byte Reload
	mov.16b	v13, v23
	bsl.16b	v13, v4, v22
	mov	b22, v16[6]
	mov.b	v22[4], v16[7]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	mov	b23, v16[4]
	mov.b	v23[4], v16[5]
	ldr	q4, [sp, #336]                  ; 16-byte Reload
	mov.16b	v15, v22
	bsl.16b	v15, v30, v20
	ushll.2d	v20, v23, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	mov.s	v5[3], w16
	mov.16b	v14, v20
	bsl.16b	v14, v24, v6
	and.16b	v6, v1, v5
	and.16b	v2, v0, v2
	ushll2.2d	v10, v2, #0
	ushll2.2d	v20, v6, #0
	ushll.2d	v5, v2, #0
	ushll.2d	v6, v6, #0
	ldr	q2, [sp, #528]                  ; 16-byte Reload
	and.16b	v16, v29, v2
	and.16b	v24, v4, v2
	and.16b	v30, v21, v2
	and.16b	v8, v3, v2
Lloh26:
	adrp	x11, lCPI0_16@PAGE
Lloh27:
	ldr	q2, [x11, lCPI0_16@PAGEOFF]
	and.16b	v23, v29, v2
Lloh28:
	adrp	x11, lCPI0_17@PAGE
Lloh29:
	ldr	q2, [x11, lCPI0_17@PAGEOFF]
	and.16b	v2, v4, v2
	str	q2, [sp, #528]                  ; 16-byte Spill
Lloh30:
	adrp	x11, lCPI0_18@PAGE
Lloh31:
	ldr	q2, [x11, lCPI0_18@PAGEOFF]
	and.16b	v2, v21, v2
	str	q2, [sp, #512]                  ; 16-byte Spill
Lloh32:
	adrp	x11, lCPI0_19@PAGE
Lloh33:
	ldr	q2, [x11, lCPI0_19@PAGEOFF]
	and.16b	v2, v3, v2
	str	q2, [sp, #496]                  ; 16-byte Spill
	ldr	q2, [sp, #432]                  ; 16-byte Reload
	cmhs.4s	v2, v2, v7
	ldr	q3, [sp, #544]                  ; 16-byte Reload
	cmhs.4s	v3, v3, v7
	uzp1.8h	v2, v3, v2
	stp	q14, q15, [x10, #32]
	stp	q13, q12, [x10]
	xtn.8b	v3, v2
	movi.2d	v7, #0000000000000000
	movi.8b	v21, #1
	movi.2d	v2, #0000000000000000
	movi.2d	v9, #0000000000000000
	movi.2d	v22, #0000000000000000
	str	q31, [sp, #544]                 ; 16-byte Spill
	mov.16b	v31, v23
	b	LBB0_33
LBB0_32:                                ; %else90
                                        ;   in Loop: Header=BB0_33 Depth=1
	add.2d	v2, v2, v19
	add.2d	v9, v9, v28
	add.2d	v22, v22, v18
	ldr	q4, [sp, #544]                  ; 16-byte Reload
	add.2d	v7, v7, v4
	fmov	x8, d7
	cmp	x8, #192
	b.ge	LBB0_49
LBB0_33:                                ; %direct.true85
                                        ; =>This Inner Loop Header: Depth=1
	fmov	w10, s17
	add	x8, x9, x8, lsl #6
	ldp	q25, q23, [x8, #32]
	ldp	q26, q27, [x8]
	cmge.2d	v27, v20, v27
	cmge.2d	v26, v6, v26
	uzp1.4s	v26, v26, v27
	cmge.2d	v25, v5, v25
	cmge.2d	v23, v10, v23
	uzp1.4s	v23, v25, v23
	uzp1.8h	v23, v26, v23
	xtn.8b	v23, v23
	orr.8b	v23, v3, v23
	ldr	q4, [sp, #496]                  ; 16-byte Reload
	add.2d	v25, v7, v4
	add.2d	v25, v8, v25
	and.8b	v23, v23, v21
	tbnz	w10, #0, LBB0_41
; %bb.34:                               ; %else76
                                        ;   in Loop: Header=BB0_33 Depth=1
	and	w8, w10, #0xff
	tbnz	w8, #1, LBB0_42
LBB0_35:                                ; %else78
                                        ;   in Loop: Header=BB0_33 Depth=1
	ldr	q4, [sp, #528]                  ; 16-byte Reload
	add.2d	v25, v2, v4
	add.2d	v25, v24, v25
	tbnz	w8, #2, LBB0_43
LBB0_36:                                ; %else80
                                        ;   in Loop: Header=BB0_33 Depth=1
	tbnz	w8, #3, LBB0_44
LBB0_37:                                ; %else82
                                        ;   in Loop: Header=BB0_33 Depth=1
	ldr	q4, [sp, #512]                  ; 16-byte Reload
	add.2d	v25, v9, v4
	add.2d	v25, v30, v25
	tbnz	w8, #4, LBB0_45
LBB0_38:                                ; %else84
                                        ;   in Loop: Header=BB0_33 Depth=1
	tbnz	w8, #5, LBB0_46
LBB0_39:                                ; %else86
                                        ;   in Loop: Header=BB0_33 Depth=1
	add.2d	v25, v22, v31
	add.2d	v25, v16, v25
	tbnz	w8, #6, LBB0_47
LBB0_40:                                ; %else88
                                        ;   in Loop: Header=BB0_33 Depth=1
	tbz	w8, #7, LBB0_32
	b	LBB0_48
LBB0_41:                                ; %cond.store
                                        ;   in Loop: Header=BB0_33 Depth=1
	fmov	x8, d25
	str	b23, [x8]
	and	w8, w10, #0xff
	tbz	w8, #1, LBB0_35
LBB0_42:                                ; %cond.store77
                                        ;   in Loop: Header=BB0_33 Depth=1
	mov.d	x10, v25[1]
	st1.b	{ v23 }[1], [x10]
	ldr	q4, [sp, #528]                  ; 16-byte Reload
	add.2d	v25, v2, v4
	add.2d	v25, v24, v25
	tbz	w8, #2, LBB0_36
LBB0_43:                                ; %cond.store79
                                        ;   in Loop: Header=BB0_33 Depth=1
	fmov	x10, d25
	st1.b	{ v23 }[2], [x10]
	tbz	w8, #3, LBB0_37
LBB0_44:                                ; %cond.store81
                                        ;   in Loop: Header=BB0_33 Depth=1
	mov.d	x10, v25[1]
	st1.b	{ v23 }[3], [x10]
	ldr	q4, [sp, #512]                  ; 16-byte Reload
	add.2d	v25, v9, v4
	add.2d	v25, v30, v25
	tbz	w8, #4, LBB0_38
LBB0_45:                                ; %cond.store83
                                        ;   in Loop: Header=BB0_33 Depth=1
	fmov	x10, d25
	st1.b	{ v23 }[4], [x10]
	tbz	w8, #5, LBB0_39
LBB0_46:                                ; %cond.store85
                                        ;   in Loop: Header=BB0_33 Depth=1
	mov.d	x10, v25[1]
	st1.b	{ v23 }[5], [x10]
	add.2d	v25, v22, v31
	add.2d	v25, v16, v25
	tbz	w8, #6, LBB0_40
LBB0_47:                                ; %cond.store87
                                        ;   in Loop: Header=BB0_33 Depth=1
	fmov	x10, d25
	st1.b	{ v23 }[6], [x10]
	tbz	w8, #7, LBB0_32
LBB0_48:                                ; %cond.store89
                                        ;   in Loop: Header=BB0_33 Depth=1
	mov.d	x8, v25[1]
	st1.b	{ v23 }[7], [x8]
	b	LBB0_32
LBB0_49:                                ; %direct.false86
	cmge.2d	v2, v6, v13
	cmge.2d	v3, v20, v12
	uzp1.4s	v2, v2, v3
	cmge.2d	v3, v5, v14
	cmge.2d	v5, v10, v15
	uzp1.4s	v3, v3, v5
	uzp1.8h	v2, v2, v3
	xtn.8b	v2, v2
Lloh34:
	adrp	x8, lCPI0_20@PAGE
Lloh35:
	ldr	d3, [x8, lCPI0_20@PAGEOFF]
	ldr	q6, [sp, #352]                  ; 16-byte Reload
	shl.8b	v5, v6, #7
	cmlt.8b	v5, v5, #0
	and.8b	v3, v5, v3
	addv.8b	b4, v3
	fmov	w11, s4
	orn.8b	v2, v2, v6
	ldr	q3, [sp, #496]                  ; 16-byte Reload
	add.2d	v3, v3, v8
	mov	w8, #192                        ; =0xc0
	dup.2d	v5, x8
	add.2d	v21, v3, v5
	movi.8b	v3, #1
	and.8b	v2, v2, v3
	ldr	q22, [sp, #272]                 ; 16-byte Reload
	tbnz	w11, #0, LBB0_84
; %bb.50:                               ; %else95
	ldr	q3, [sp, #528]                  ; 16-byte Reload
	add.2d	v3, v3, v24
	mov.d	x10, v21[1]
	tbnz	w11, #1, LBB0_85
LBB0_51:                                ; %else99
	add.2d	v3, v3, v5
	tbnz	w11, #2, LBB0_86
LBB0_52:                                ; %else103
	ldr	q6, [sp, #512]                  ; 16-byte Reload
	add.2d	v6, v6, v30
	mov.d	x9, v3[1]
	tbnz	w11, #3, LBB0_87
LBB0_53:                                ; %else107
	add.2d	v9, v6, v5
	tbnz	w11, #4, LBB0_88
LBB0_54:                                ; %else111
	add.2d	v6, v31, v16
	mov.d	x8, v9[1]
	tbnz	w11, #5, LBB0_89
LBB0_55:                                ; %else115
	add.2d	v7, v6, v5
	tbnz	w11, #6, LBB0_90
LBB0_56:                                ; %else119
	mov.d	x13, v7[1]
	tbz	w11, #7, LBB0_58
LBB0_57:                                ; %cond.store120
	st1.b	{ v2 }[7], [x13]
LBB0_58:                                ; %else123
	mov	x16, #0                         ; =0x0
	movi.2d	v11, #0000000000000000
	fmov	w11, s17
	add	x14, sp, #6, lsl #12            ; =24576
	add	x14, x14, #3920
	mov	w15, #62154                     ; =0xf2ca
	movk	w15, #61769, lsl #16
	dup.4s	v12, w15
	add	x15, sp, #2, lsl #12            ; =8192
	add	x15, x15, #232
	movi.2d	v13, #0000000000000000
	movi.2d	v15, #0000000000000000
	movi.2d	v14, #0000000000000000
	b	LBB0_60
LBB0_59:                                ; %else155
                                        ;   in Loop: Header=BB0_60 Depth=1
	cmeq.8b	v2, v5, #0
	sshll.8h	v2, v2, #0
	sshll2.4s	v5, v2, #0
	sshll.4s	v2, v2, #0
	lsl	x16, x16, #5
	add	x17, x14, x16
	ldp	q6, q20, [x17]
	and.16b	v20, v0, v20
	and.16b	v6, v1, v6
	bsl.16b	v2, v12, v6
	bsl.16b	v5, v12, v20
	add	x16, x15, x16
	ldp	q6, q20, [x16]
	bif.16b	v5, v20, v0
	bif.16b	v2, v6, v1
	stp	q2, q5, [x16]
	add.2d	v13, v13, v19
	add.2d	v15, v15, v28
	add.2d	v14, v14, v18
	ldr	q2, [sp, #544]                  ; 16-byte Reload
	add.2d	v11, v11, v2
	fmov	x16, d11
	cmp	x16, #192
	b.ge	LBB0_76
LBB0_60:                                ; %direct.true101
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q2, [sp, #496]                  ; 16-byte Reload
	add.2d	v2, v11, v2
	add.2d	v2, v8, v2
	tbz	w11, #0, LBB0_69
; %bb.61:                               ; %cond.load125
                                        ;   in Loop: Header=BB0_60 Depth=1
	fmov	x17, d2
	ldr	b5, [x17]
	and	w17, w11, #0xff
	tbz	w17, #1, LBB0_63
LBB0_62:                                ; %cond.load129
                                        ;   in Loop: Header=BB0_60 Depth=1
	mov.d	x0, v2[1]
	ld1.b	{ v5 }[1], [x0]
LBB0_63:                                ; %else131
                                        ;   in Loop: Header=BB0_60 Depth=1
	ldr	q2, [sp, #528]                  ; 16-byte Reload
	add.2d	v2, v13, v2
	add.2d	v2, v24, v2
	tbnz	w17, #2, LBB0_70
; %bb.64:                               ; %else135
                                        ;   in Loop: Header=BB0_60 Depth=1
	tbnz	w17, #3, LBB0_71
LBB0_65:                                ; %else139
                                        ;   in Loop: Header=BB0_60 Depth=1
	ldr	q2, [sp, #512]                  ; 16-byte Reload
	add.2d	v2, v15, v2
	add.2d	v2, v30, v2
	tbnz	w17, #4, LBB0_72
LBB0_66:                                ; %else143
                                        ;   in Loop: Header=BB0_60 Depth=1
	tbnz	w17, #5, LBB0_73
LBB0_67:                                ; %else147
                                        ;   in Loop: Header=BB0_60 Depth=1
	add.2d	v2, v14, v31
	add.2d	v2, v16, v2
	tbnz	w17, #6, LBB0_74
LBB0_68:                                ; %else151
                                        ;   in Loop: Header=BB0_60 Depth=1
	tbz	w17, #7, LBB0_59
	b	LBB0_75
LBB0_69:                                ;   in Loop: Header=BB0_60 Depth=1
	movi.2d	v5, #0000000000000000
	and	w17, w11, #0xff
	tbnz	w17, #1, LBB0_62
	b	LBB0_63
LBB0_70:                                ; %cond.load133
                                        ;   in Loop: Header=BB0_60 Depth=1
	fmov	x0, d2
	ld1.b	{ v5 }[2], [x0]
	tbz	w17, #3, LBB0_65
LBB0_71:                                ; %cond.load137
                                        ;   in Loop: Header=BB0_60 Depth=1
	mov.d	x0, v2[1]
	ld1.b	{ v5 }[3], [x0]
	ldr	q2, [sp, #512]                  ; 16-byte Reload
	add.2d	v2, v15, v2
	add.2d	v2, v30, v2
	tbz	w17, #4, LBB0_66
LBB0_72:                                ; %cond.load141
                                        ;   in Loop: Header=BB0_60 Depth=1
	fmov	x0, d2
	ld1.b	{ v5 }[4], [x0]
	tbz	w17, #5, LBB0_67
LBB0_73:                                ; %cond.load145
                                        ;   in Loop: Header=BB0_60 Depth=1
	mov.d	x0, v2[1]
	ld1.b	{ v5 }[5], [x0]
	add.2d	v2, v14, v31
	add.2d	v2, v16, v2
	tbz	w17, #6, LBB0_68
LBB0_74:                                ; %cond.load149
                                        ;   in Loop: Header=BB0_60 Depth=1
	fmov	x0, d2
	ld1.b	{ v5 }[6], [x0]
	tbz	w17, #7, LBB0_59
LBB0_75:                                ; %cond.load153
                                        ;   in Loop: Header=BB0_60 Depth=1
	mov.d	x17, v2[1]
	ld1.b	{ v5 }[7], [x17]
	b	LBB0_59
LBB0_76:                                ; %direct.true135.preheader
	fmov	w11, s4
	tbz	w11, #0, LBB0_91
; %bb.77:                               ; %cond.load158
	fmov	x14, d21
	ldr	b2, [x14]
	ldr	q20, [sp, #448]                 ; 16-byte Reload
	tbnz	w11, #1, LBB0_92
	b	LBB0_93
LBB0_78:                                ; %cond.load51
	ld1.s	{ v23 }[0], [x8]
	tbz	w13, #1, LBB0_21
LBB0_79:                                ; %cond.load54
	add	x10, x8, #4
	ld1.s	{ v23 }[1], [x10]
	tbz	w13, #2, LBB0_22
LBB0_80:                                ; %cond.load57
	add	x10, x8, #8
	ld1.s	{ v23 }[2], [x10]
	tbz	w13, #3, LBB0_23
LBB0_81:                                ; %cond.load60
	add	x10, x8, #12
	ld1.s	{ v23 }[3], [x10]
	adrp	x10, lCPI0_3@PAGE
	adrp	x11, lCPI0_4@PAGE
	adrp	x14, lCPI0_5@PAGE
	ldr	q28, [x9, #16]
	tbz	w13, #4, LBB0_24
LBB0_82:                                ; %cond.load63
	add	x9, x8, #16
	ld1.s	{ v28 }[0], [x9]
	ldr	q5, [x10, lCPI0_3@PAGEOFF]
	ldr	q20, [x11, lCPI0_4@PAGEOFF]
	ldr	q10, [x14, lCPI0_5@PAGEOFF]
	tbz	w13, #5, LBB0_25
LBB0_83:                                ; %cond.load66
	add	x9, x8, #20
	ld1.s	{ v28 }[1], [x9]
	and.16b	v22, v27, v5
	ldr	q2, [sp, #336]                  ; 16-byte Reload
	and.16b	v2, v2, v20
	and.16b	v4, v6, v10
	str	q27, [sp, #304]                 ; 16-byte Spill
	tbnz	w13, #6, LBB0_26
	b	LBB0_27
LBB0_84:                                ; %cond.store92
	fmov	x8, d21
	str	b2, [x8]
	ldr	q3, [sp, #528]                  ; 16-byte Reload
	add.2d	v3, v3, v24
	mov.d	x10, v21[1]
	tbz	w11, #1, LBB0_51
LBB0_85:                                ; %cond.store96
	st1.b	{ v2 }[1], [x10]
	add.2d	v3, v3, v5
	tbz	w11, #2, LBB0_52
LBB0_86:                                ; %cond.store100
	fmov	x8, d3
	st1.b	{ v2 }[2], [x8]
	ldr	q6, [sp, #512]                  ; 16-byte Reload
	add.2d	v6, v6, v30
	mov.d	x9, v3[1]
	tbz	w11, #3, LBB0_53
LBB0_87:                                ; %cond.store104
	st1.b	{ v2 }[3], [x9]
	add.2d	v9, v6, v5
	tbz	w11, #4, LBB0_54
LBB0_88:                                ; %cond.store108
	fmov	x8, d9
	st1.b	{ v2 }[4], [x8]
	add.2d	v6, v31, v16
	mov.d	x8, v9[1]
	tbz	w11, #5, LBB0_55
LBB0_89:                                ; %cond.store112
	st1.b	{ v2 }[5], [x8]
	add.2d	v7, v6, v5
	tbz	w11, #6, LBB0_56
LBB0_90:                                ; %cond.store116
	fmov	x13, d7
	st1.b	{ v2 }[6], [x13]
	mov.d	x13, v7[1]
	tbnz	w11, #7, LBB0_57
	b	LBB0_58
LBB0_91:
	movi.2d	v2, #0000000000000000
	ldr	q20, [sp, #448]                 ; 16-byte Reload
	tbz	w11, #1, LBB0_93
LBB0_92:                                ; %cond.load164
	ld1.b	{ v2 }[1], [x10]
LBB0_93:                                ; %else168
	tbnz	w11, #2, LBB0_151
; %bb.94:                               ; %else174
	tbnz	w11, #3, LBB0_152
LBB0_95:                                ; %else180
	tbnz	w11, #4, LBB0_153
LBB0_96:                                ; %else186
	tbnz	w11, #5, LBB0_154
LBB0_97:                                ; %else192
	tbnz	w11, #6, LBB0_155
LBB0_98:                                ; %else198
	movi	d3, #0xffffffffffff0000
	stp	q30, q24, [sp, #400]            ; 32-byte Folded Spill
	stp	q31, q8, [sp, #368]             ; 32-byte Folded Spill
	str	d4, [sp, #144]                  ; 8-byte Spill
	str	q16, [sp, #128]                 ; 16-byte Spill
	tbz	w11, #7, LBB0_100
LBB0_99:                                ; %cond.load200
	ld1.b	{ v2 }[7], [x13]
LBB0_100:                               ; %else204
	stp	q19, q18, [sp, #432]            ; 32-byte Folded Spill
	str	x3, [sp, #240]                  ; 8-byte Spill
	ldr	q4, [sp, #320]                  ; 16-byte Reload
	and.8b	v3, v4, v3
	str	d3, [sp, #296]                  ; 8-byte Spill
	sshll.2d	v3, v1, #0
	sshll.2d	v5, v0, #0
	cmeq.8b	v2, v2, #0
	sshll.8h	v2, v2, #0
	sshll2.4s	v17, v2, #0
	str	q2, [sp, #16]                   ; 16-byte Spill
	sshll.4s	v2, v2, #0
	ldr	q16, [sp, #352]                 ; 16-byte Reload
	zip2.8b	v6, v16, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v7, v6, v20
	zip1.8b	v20, v16, v0
	ushll.4s	v20, v20, #0
	shl.4s	v20, v20, #31
	cmlt.4s	v20, v20, #0
	mov	w8, #62154                      ; =0xf2ca
	movk	w8, #61769, lsl #16
	dup.4s	v21, w8
	and.16b	v4, v20, v22
	mov.16b	v16, v2
	bsl.16b	v16, v21, v4
	str	q17, [sp, #96]                  ; 16-byte Spill
	bit.16b	v7, v21, v17
	add	x8, sp, #2, lsl #12             ; =8192
	add	x8, x8, #232
	str	x5, [sp, #152]                  ; 8-byte Spill
	add	x9, x8, x5
	ldp	q2, q4, [x9]
	stp	q7, q16, [sp, #256]             ; 32-byte Folded Spill
	bit.16b	v4, v7, v6
	bit.16b	v2, v16, v20
	stp	q2, q4, [x9]
	ldr	q2, [sp, #80]                   ; 16-byte Reload
	fmov	x10, d2
	mov	w9, #4                          ; =0x4
	dup.2d	v2, x9
	and.16b	v10, v29, v2
	ldr	q31, [sp, #336]                 ; 16-byte Reload
	and.16b	v11, v31, v2
	and.16b	v12, v5, v2
	and.16b	v13, v3, v2
	fmov	x17, d13
	ldr	q2, [x4, #6272]
	ldr	q4, [x4, #6288]
	and.16b	v6, v0, v4
	and.16b	v4, v1, v2
	ldr	q2, [x4, #6240]
	ldr	q7, [x4, #6256]
	and.16b	v20, v0, v7
	and.16b	v7, v1, v2
	ldr	q2, [x4, #6208]
	ldr	q21, [x4, #6224]
	and.16b	v21, v0, v21
	and.16b	v24, v1, v2
	str	x10, [sp, #80]                  ; 8-byte Spill
	add	x10, x8, x10
	ldp	q22, q2, [x10]
	and.16b	v2, v0, v2
	mov	x10, x17
	and.16b	v22, v1, v22
	mov.16b	v25, v13
	mov.16b	v26, v11
	mov.16b	v27, v12
	mov.16b	v14, v10
	mov.16b	v8, v29
LBB0_101:                               ; %direct.true135
                                        ; =>This Inner Loop Header: Depth=1
	add	x10, x8, x10, lsl #5
	ldp	q23, q9, [x10]
	and.16b	v9, v0, v9
	and.16b	v23, v1, v23
	fmaxnm.4s	v23, v22, v23
	fmaxnm.4s	v9, v2, v9
	ldp	q15, q28, [x10, #32]
	and.16b	v28, v0, v28
	and.16b	v15, v1, v15
	fmaxnm.4s	v15, v24, v15
	fmaxnm.4s	v28, v21, v28
	ldp	q16, q29, [x10, #64]
	and.16b	v29, v0, v29
	and.16b	v16, v1, v16
	fmaxnm.4s	v16, v7, v16
	fmaxnm.4s	v29, v20, v29
	ldp	q17, q30, [x10, #96]
	and.16b	v30, v0, v30
	and.16b	v17, v1, v17
	fmaxnm.4s	v17, v4, v17
	fmaxnm.4s	v30, v6, v30
	dup.2d	v18, x9
	and.16b	v19, v8, v18
	add.2d	v14, v14, v19
	and.16b	v19, v31, v18
	add.2d	v26, v26, v19
	and.16b	v19, v5, v18
	add.2d	v27, v27, v19
	and.16b	v18, v3, v18
	add.2d	v25, v25, v18
	bit.16b	v2, v9, v0
	bit.16b	v22, v23, v1
	bit.16b	v21, v28, v0
	bit.16b	v24, v15, v1
	bit.16b	v20, v29, v0
	bit.16b	v7, v16, v1
	bit.16b	v6, v30, v0
	bit.16b	v4, v17, v1
	fmov	x10, d25
	cmp	x10, #192
	b.lt	LBB0_101
; %bb.102:                              ; %direct.false136
	mov	x24, #0                         ; =0x0
	ldr	q16, [sp, #352]                 ; 16-byte Reload
	zip1.8b	v3, v16, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldp	q17, q5, [sp, #256]             ; 32-byte Folded Reload
	and.16b	v5, v3, v5
	zip2.8b	v16, v16, v0
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	and.16b	v17, v16, v17
	fmaxnm.4s	v2, v2, v17
	fmaxnm.4s	v5, v22, v5
	and.16b	v3, v3, v5
	and.16b	v2, v16, v2
	ldr	d16, [sp, #296]                 ; 8-byte Reload
	zip2.8b	v5, v16, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	bit.16b	v2, v9, v5
	zip1.8b	v5, v16, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	bit.16b	v3, v23, v5
	fmaxnm.4s	v3, v3, v24
	fmaxnm.4s	v2, v2, v21
	fmaxnm.4s	v2, v2, v20
	fmaxnm.4s	v3, v3, v7
	fmaxnm.4s	v4, v3, v4
	fmaxnm.4s	v7, v2, v6
	ldr	q2, [sp, #112]                  ; 16-byte Reload
	ldp	q3, q5, [sp, #32]               ; 32-byte Folded Reload
	uzp1.4s	v14, v2, v5
	ldr	q2, [sp, #64]                   ; 16-byte Reload
	uzp1.4s	v3, v3, v2
	movi.4s	v2, #1
	eor.16b	v5, v14, v2
	mov.s	w8, v5[1]
	mov.s	w9, v5[2]
	eor.16b	v24, v3, v2
	mov.s	w10, v5[3]
	fmov	w11, s5
	add	x6, sp, #1224
	add	x13, sp, #1224
	bfxil	x13, x11, #0, #3
	ldr	q19, [sp, #320]                 ; 16-byte Reload
	str	d19, [sp, #1224]
	ldrb	w14, [x13]
	and	x11, x11, #0x7
	umov.b	w13, v19[0]
	str	q7, [sp, #1888]
	str	q4, [sp, #1872]
	add	x15, sp, #1872
	ldr	s2, [x15, x11, lsl #2]
	ands	w5, w13, #0x1
	tst	w5, w14
	movi.2d	v5, #0000000000000000
	fcsel	s6, s2, s5, ne
	and	x11, x8, #0x7
	add	x14, sp, #1224
	bfxil	x14, x8, #0, #3
	ldrb	w8, [x14]
	umov.b	w16, v19[1]
	and	w8, w16, w8
	str	q7, [sp, #1856]
	str	q4, [sp, #1840]
	add	x14, sp, #1840
	ldr	s2, [x14, x11, lsl #2]
	tst	w8, #0x1
	fcsel	s20, s2, s5, ne
	and	x8, x9, #0x7
	add	x11, sp, #1224
	bfxil	x11, x9, #0, #3
	ldrb	w9, [x11]
	umov.b	w14, v19[2]
	and	w9, w14, w9
	str	q7, [sp, #1824]
	str	q4, [sp, #1808]
	add	x11, sp, #1808
	ldr	s2, [x11, x8, lsl #2]
	tst	w9, #0x1
	fcsel	s21, s2, s5, ne
	and	x8, x10, #0x7
	add	x9, sp, #1224
	bfxil	x9, x10, #0, #3
	umov.b	w15, v19[3]
	ldrb	w9, [x9]
	str	q7, [sp, #1792]
	str	q4, [sp, #1776]
	add	x10, sp, #1776
	ldr	s2, [x10, x8, lsl #2]
	and	w8, w15, w9
	tst	w8, #0x1
	mov.s	w8, v24[1]
	mov.s	w9, v24[2]
	fcsel	s2, s2, s5, ne
	mov.s	w10, v24[3]
	fmov	w11, s24
	and	x0, x11, #0x7
	add	x1, sp, #1224
	bfxil	x1, x11, #0, #3
	ldrb	w11, [x1]
	umov.b	w3, v19[4]
	and	w11, w3, w11
	str	q7, [sp, #2016]
	str	q4, [sp, #2000]
	add	x1, sp, #2000
	ldr	s16, [x1, x0, lsl #2]
	tst	w11, #0x1
	fcsel	s16, s16, s5, ne
	and	x11, x8, #0x7
	add	x0, sp, #1224
	bfxil	x0, x8, #0, #3
	ldrb	w8, [x0]
	umov.b	w2, v19[5]
	and	w8, w2, w8
	str	q7, [sp, #1984]
	str	q4, [sp, #1968]
	add	x0, sp, #1968
	ldr	s17, [x0, x11, lsl #2]
	tst	w8, #0x1
	fcsel	s17, s17, s5, ne
	and	x8, x9, #0x7
	add	x11, sp, #1224
	bfxil	x11, x9, #0, #3
	ldrb	w9, [x11]
	umov.b	w0, v19[6]
	and	w9, w0, w9
	str	q7, [sp, #1952]
	str	q4, [sp, #1936]
	add	x11, sp, #1936
	ldr	s18, [x11, x8, lsl #2]
	tst	w9, #0x1
	fcsel	s18, s18, s5, ne
	and	x8, x10, #0x7
	add	x9, sp, #1224
	bfxil	x9, x10, #0, #3
	ldrb	w9, [x9]
	umov.b	w1, v19[7]
	and	w9, w1, w9
	str	q7, [sp, #1920]
	str	q4, [sp, #1904]
	add	x10, sp, #1904
	ldr	s19, [x10, x8, lsl #2]
	tst	w9, #0x1
	fcsel	s19, s19, s5, ne
	mov.s	v16[1], v17[0]
	mov.s	v16[2], v18[0]
	mov.s	v16[3], v19[0]
	mov.s	v6[1], v20[0]
	mov.s	v6[2], v21[0]
	mov.s	v6[3], v2[0]
	fmaxnm.4s	v4, v4, v6
	fmaxnm.4s	v6, v7, v16
	movi.4s	v2, #2
	eor.16b	v7, v14, v2
	mov.s	w8, v7[1]
	eor.16b	v24, v3, v2
	mov.s	w9, v7[2]
	mov.s	w10, v7[3]
	fmov	w11, s7
	add	x4, sp, #1224
	bfxil	x4, x11, #0, #3
	ldrb	w4, [x4]
	and	x11, x11, #0x7
	str	q6, [sp, #1760]
	str	q4, [sp, #1744]
	add	x7, sp, #1744
	ldr	s2, [x7, x11, lsl #2]
	tst	w5, w4
	fcsel	s3, s2, s5, ne
	and	x11, x8, #0x7
	add	x4, sp, #1224
	bfxil	x4, x8, #0, #3
	ldrb	w8, [x4]
	and	w8, w16, w8
	str	q6, [sp, #1728]
	str	q4, [sp, #1712]
	add	x4, sp, #1712
	ldr	s2, [x4, x11, lsl #2]
	tst	w8, #0x1
	fcsel	s7, s2, s5, ne
	and	x8, x9, #0x7
	add	x11, sp, #1224
	bfxil	x11, x9, #0, #3
	ldrb	w9, [x11]
	and	w9, w14, w9
	str	q6, [sp, #1696]
	str	q4, [sp, #1680]
	add	x11, sp, #1680
	ldr	s2, [x11, x8, lsl #2]
	tst	w9, #0x1
	fcsel	s20, s2, s5, ne
	and	x8, x10, #0x7
	add	x9, sp, #1224
	bfxil	x9, x10, #0, #3
	ldrb	w9, [x9]
	and	w9, w15, w9
	str	q6, [sp, #1664]
	str	q4, [sp, #1648]
	add	x10, sp, #1648
	ldr	s2, [x10, x8, lsl #2]
	tst	w9, #0x1
	mov.s	w8, v24[3]
	fcsel	s21, s2, s5, ne
	mov.s	w22, v24[1]
	mov.s	w23, v24[2]
	fmov	w9, s24
	and	x25, x9, #0x7
	add	x26, sp, #1224
	bfxil	x26, x9, #0, #3
	add	x9, sp, #1224
	bfxil	x9, x8, #0, #3
	ldrb	w27, [x9]
	movi.4s	v2, #4
	eor.16b	v2, v14, v2
	mov.s	w4, v2[1]
	mov.s	w10, v2[2]
	mov.s	w9, v2[3]
	fmov	w21, s2
	add	x11, sp, #1224
	bfxil	x11, x21, #0, #3
	ldrb	w19, [x11]
	add	x11, sp, #1224
	bfxil	x11, x4, #0, #3
	ldrb	w20, [x11]
	add	x11, sp, #1224
	bfxil	x11, x10, #0, #3
	ldrb	w7, [x11]
	add	x11, sp, #1224
	bfxil	x11, x9, #0, #3
	ldrb	w11, [x11]
	ldrb	w26, [x26]
	and	w26, w3, w26
	str	q6, [sp, #1632]
	str	q4, [sp, #1616]
	add	x28, sp, #1616
	ldr	s2, [x28, x25, lsl #2]
	tst	w26, #0x1
	fcsel	s2, s2, s5, ne
	and	x25, x22, #0x7
	add	x26, sp, #1224
	bfxil	x26, x22, #0, #3
	ldrb	w22, [x26]
	and	w22, w2, w22
	str	q6, [sp, #1600]
	str	q4, [sp, #1584]
	add	x26, sp, #1584
	ldr	s16, [x26, x25, lsl #2]
	tst	w22, #0x1
	fcsel	s16, s16, s5, ne
	and	x22, x23, #0x7
	bfxil	x6, x23, #0, #3
	ldrb	w6, [x6]
	and	w6, w0, w6
	str	q6, [sp, #1568]
	str	q4, [sp, #1552]
	add	x23, sp, #1552
	ldr	s17, [x23, x22, lsl #2]
	tst	w6, #0x1
	fcsel	s17, s17, s5, ne
	and	x8, x8, #0x7
	and	w6, w1, w27
	str	q6, [sp, #1536]
	str	q4, [sp, #1520]
	add	x22, sp, #1520
	ldr	s18, [x22, x8, lsl #2]
	tst	w6, #0x1
	fcsel	s18, s18, s5, ne
	mov.s	v2[1], v16[0]
	mov.s	v2[2], v17[0]
	mov.s	v2[3], v18[0]
	mov.s	v3[1], v7[0]
	mov.s	v3[2], v20[0]
	mov.s	v3[3], v21[0]
	fmaxnm.4s	v3, v4, v3
	fmaxnm.4s	v2, v6, v2
	and	x8, x21, #0x7
	str	q2, [sp, #1504]
	str	q3, [sp, #1488]
	add	x6, sp, #1488
	ldr	s4, [x6, x8, lsl #2]
	tst	w5, w19
	fcsel	s4, s4, s5, ne
	and	x8, x4, #0x7
	and	w4, w16, w20
	str	q2, [sp, #1472]
	str	q3, [sp, #1456]
	add	x5, sp, #1456
	ldr	s6, [x5, x8, lsl #2]
	tst	w4, #0x1
	fcsel	s6, s6, s5, ne
	and	x8, x10, #0x7
	and	w10, w14, w7
	str	q2, [sp, #1440]
	str	q3, [sp, #1424]
	add	x4, sp, #1424
	ldr	s7, [x4, x8, lsl #2]
	tst	w10, #0x1
	fcsel	s7, s7, s5, ne
	and	x8, x9, #0x7
	and	w9, w15, w11
	str	q2, [sp, #1408]
	str	q3, [sp, #1392]
	add	x10, sp, #1392
	ldr	s2, [x10, x8, lsl #2]
	tst	w9, #0x1
	fcsel	s2, s2, s5, ne
	mov.s	v4[1], v6[0]
	ands	w5, w13, #0x1
	mov.s	v4[2], v7[0]
	mov.s	v4[3], v2[0]
	fmaxnm.4s	v2, v3, v4
	fcsel	s3, s2, s5, ne
	and	w9, w16, w13
	and	w8, w16, w13
	str	w8, [sp, #112]                  ; 4-byte Spill
	tst	w9, #0x1
	fcsel	s4, s2, s5, ne
	and	w9, w14, w13
	and	w8, w14, w13
	str	w8, [sp, #64]                   ; 4-byte Spill
	tst	w9, #0x1
	fcsel	s6, s2, s5, ne
	and	w9, w15, w13
	and	w8, w15, w13
	str	w8, [sp, #48]                   ; 4-byte Spill
	tst	w9, #0x1
	fcsel	s7, s2, s5, ne
	and	w9, w3, w13
	and	w8, w3, w13
	str	w8, [sp, #32]                   ; 4-byte Spill
	tst	w9, #0x1
	fcsel	s16, s2, s5, ne
	and	w21, w2, w13
	tst	w21, #0x1
	fcsel	s17, s2, s5, ne
	and	w22, w0, w13
	tst	w22, #0x1
	fcsel	s18, s2, s5, ne
	and	w23, w1, w13
	tst	w23, #0x1
	fcsel	s2, s2, s5, ne
	mov.s	v3[1], v4[0]
	mov.s	v3[2], v6[0]
	mov.s	v3[3], v7[0]
	mov.s	v16[1], v17[0]
	mov.s	v16[2], v18[0]
	mov.s	v16[3], v2[0]
	rbit	w8, w12
	clz	w12, w8
	str	q16, [sp, #1248]
	str	q3, [sp, #1232]
	and	x8, x12, #0x7
	add	x9, sp, #1232
	ldr	s2, [x9, x8, lsl #2]
	mov	w8, #-8388608                   ; =0xff800000
	fmov	s3, w8
	fmaxnm	s2, s2, s3
	dup.4s	v5, v2[0]
	movi.2d	v6, #0000000000000000
	add	x25, sp, #2, lsl #12            ; =8192
	add	x25, x25, #232
	mov	w26, #-1026555904               ; =0xc2d00000
	mov	w27, #1120403456                ; =0x42c80000
	mov	w28, #43579                     ; =0xaa3b
	movk	w28, #16312, lsl #16
	movi.4s	v20, #75, lsl #24
	mvni.4s	v14, #128, lsl #24
	mov	w30, #29184                     ; =0x7200
	movk	w30, #48945, lsl #16
	mov	w8, #48782                      ; =0xbe8e
	movk	w8, #46527, lsl #16
	mov	w11, #11226                     ; =0x2bda
	movk	w11, #14672, lsl #16
	mov	w4, #38601                      ; =0x96c9
	movk	w4, #15030, lsl #16
	mov	w10, #34982                     ; =0x88a6
	movk	w10, #15368, lsl #16
	mov	w9, #43642                      ; =0xaa7a
	movk	w9, #15658, lsl #16
	mov	w6, #43691                      ; =0xaaab
	movk	w6, #15914, lsl #16
	movi.4s	v15, #63, lsl #24
	fmov.4s	v9, #1.00000000
	mvni.4s	v2, #127, msl #16
	fneg.4s	v7, v2
	mvni.4s	v2, #63, msl #16
	fneg.4s	v4, v2
	add	x7, sp, #2248
	movi.2d	v24, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v3, #0000000000000000
	ldr	q8, [sp, #128]                  ; 16-byte Reload
	b	LBB0_104
LBB0_103:                               ; %else253
                                        ;   in Loop: Header=BB0_104 Depth=1
	cmeq.8b	v2, v2, #0
	sshll.8h	v16, v2, #0
	sshll2.4s	v2, v16, #0
	sshll.4s	v22, v16, #0
	lsl	x24, x24, #5
	add	x19, x25, x24
	ldp	q17, q16, [x19]
	fsub.4s	v17, v17, v5
	fsub.4s	v16, v16, v5
	and.16b	v23, v0, v16
	and.16b	v25, v1, v17
	dup.4s	v26, w26
	fcmge.4s	v16, v25, v26
	dup.4s	v27, w27
	fcmge.4s	v17, v23, v26
	fcmge.4s	v18, v27, v25
	fcmge.4s	v19, v27, v23
	and.16b	v17, v17, v19
	and.16b	v16, v16, v18
	and.16b	v16, v16, v25
	and.16b	v17, v17, v23
	dup.4s	v18, w28
	fmul.4s	v19, v17, v18
	fmul.4s	v18, v16, v18
	mov.16b	v28, v14
	bsl.16b	v28, v20, v18
	mov.16b	v29, v14
	bsl.16b	v29, v20, v19
	fadd.4s	v19, v19, v29
	fadd.4s	v18, v18, v28
	fsub.4s	v18, v18, v28
	fsub.4s	v19, v19, v29
	fcvtzs.4s	v19, v19
	fcvtzs.4s	v18, v18
	scvtf.4s	v28, v18
	scvtf.4s	v29, v19
	dup.4s	v30, w30
	fmul.4s	v31, v29, v30
	fmul.4s	v30, v28, v30
	fadd.4s	v16, v16, v30
	fadd.4s	v17, v17, v31
	dup.4s	v30, w8
	fmul.4s	v28, v28, v30
	fmul.4s	v29, v29, v30
	fadd.4s	v17, v17, v29
	fadd.4s	v16, v16, v28
	dup.4s	v28, w11
	fmul.4s	v29, v16, v28
	fmul.4s	v28, v17, v28
	dup.4s	v30, w4
	fadd.4s	v28, v28, v30
	fadd.4s	v29, v29, v30
	fmul.4s	v29, v16, v29
	fmul.4s	v28, v17, v28
	dup.4s	v30, w10
	fadd.4s	v28, v28, v30
	fadd.4s	v29, v29, v30
	fmul.4s	v29, v16, v29
	fmul.4s	v28, v17, v28
	dup.4s	v30, w9
	fadd.4s	v28, v28, v30
	fadd.4s	v29, v29, v30
	fmul.4s	v29, v16, v29
	fmul.4s	v28, v17, v28
	dup.4s	v30, w6
	fadd.4s	v28, v28, v30
	fadd.4s	v29, v29, v30
	fmul.4s	v29, v16, v29
	fmul.4s	v28, v17, v28
	fadd.4s	v28, v28, v15
	fadd.4s	v29, v29, v15
	fmul.4s	v30, v17, v17
	fmul.4s	v31, v16, v16
	fmul.4s	v29, v31, v29
	fmul.4s	v28, v30, v28
	fadd.4s	v17, v17, v28
	fadd.4s	v16, v16, v29
	fadd.4s	v16, v16, v9
	fadd.4s	v17, v17, v9
	sshr.4s	v28, v18, #1
	sshr.4s	v29, v19, #1
	shl.4s	v30, v29, #23
	shl.4s	v31, v28, #23
	add.4s	v31, v31, v9
	add.4s	v30, v30, v9
	fmul.4s	v17, v17, v30
	fmul.4s	v16, v16, v31
	sub.4s	v19, v19, v29
	sub.4s	v18, v18, v28
	shl.4s	v18, v18, #23
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v9
	add.4s	v18, v18, v9
	fmul.4s	v16, v16, v18
	fmul.4s	v17, v17, v19
	fcmgt.4s	v18, v26, v23
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v26, v25
	bic.16b	v16, v16, v18
	fcmgt.4s	v18, v23, v27
	fcmgt.4s	v19, v25, v27
	bit.16b	v16, v7, v19
	bit.16b	v17, v7, v18
	fcmeq.4s	v18, v25, v25
	fcmeq.4s	v19, v23, v23
	bif.16b	v17, v4, v19
	bif.16b	v16, v4, v18
	bic.16b	v16, v16, v22
	bic.16b	v2, v17, v2
	add	x19, x7, x24
	ldp	q17, q18, [x19]
	bif.16b	v2, v18, v0
	bif.16b	v16, v17, v1
	stp	q16, q2, [x19]
	ldr	q2, [sp, #432]                  ; 16-byte Reload
	add.2d	v24, v24, v2
	ldr	q2, [sp, #480]                  ; 16-byte Reload
	add.2d	v21, v21, v2
	ldr	q2, [sp, #448]                  ; 16-byte Reload
	add.2d	v3, v3, v2
	ldr	q2, [sp, #544]                  ; 16-byte Reload
	add.2d	v6, v6, v2
	fmov	x24, d6
	cmp	x24, #192
	b.ge	LBB0_120
LBB0_104:                               ; %direct.true170
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q2, [sp, #464]                  ; 16-byte Reload
	fmov	w19, s2
	ldr	q2, [sp, #496]                  ; 16-byte Reload
	add.2d	v2, v6, v2
	ldr	q16, [sp, #384]                 ; 16-byte Reload
	add.2d	v22, v16, v2
	tbz	w19, #0, LBB0_113
; %bb.105:                              ; %cond.load207
                                        ;   in Loop: Header=BB0_104 Depth=1
	fmov	x20, d22
	ldr	b2, [x20]
	ldr	q18, [sp, #400]                 ; 16-byte Reload
	ldr	q19, [sp, #368]                 ; 16-byte Reload
	and	w19, w19, #0xff
	tbz	w19, #1, LBB0_107
LBB0_106:                               ; %cond.load213
                                        ;   in Loop: Header=BB0_104 Depth=1
	mov.d	x20, v22[1]
	ld1.b	{ v2 }[1], [x20]
LBB0_107:                               ; %else217
                                        ;   in Loop: Header=BB0_104 Depth=1
	ldr	q16, [sp, #528]                 ; 16-byte Reload
	add.2d	v16, v24, v16
	ldr	q17, [sp, #416]                 ; 16-byte Reload
	add.2d	v22, v17, v16
	tbnz	w19, #2, LBB0_114
; %bb.108:                              ; %else223
                                        ;   in Loop: Header=BB0_104 Depth=1
	tbnz	w19, #3, LBB0_115
LBB0_109:                               ; %else229
                                        ;   in Loop: Header=BB0_104 Depth=1
	ldr	q16, [sp, #512]                 ; 16-byte Reload
	add.2d	v16, v21, v16
	add.2d	v22, v18, v16
	tbnz	w19, #4, LBB0_116
LBB0_110:                               ; %else235
                                        ;   in Loop: Header=BB0_104 Depth=1
	tbnz	w19, #5, LBB0_117
LBB0_111:                               ; %else241
                                        ;   in Loop: Header=BB0_104 Depth=1
	add.2d	v16, v3, v19
	add.2d	v22, v8, v16
	tbnz	w19, #6, LBB0_118
LBB0_112:                               ; %else247
                                        ;   in Loop: Header=BB0_104 Depth=1
	tbz	w19, #7, LBB0_103
	b	LBB0_119
LBB0_113:                               ;   in Loop: Header=BB0_104 Depth=1
	movi.2d	v2, #0000000000000000
	ldr	q18, [sp, #400]                 ; 16-byte Reload
	ldr	q19, [sp, #368]                 ; 16-byte Reload
	and	w19, w19, #0xff
	tbnz	w19, #1, LBB0_106
	b	LBB0_107
LBB0_114:                               ; %cond.load219
                                        ;   in Loop: Header=BB0_104 Depth=1
	fmov	x20, d22
	ld1.b	{ v2 }[2], [x20]
	tbz	w19, #3, LBB0_109
LBB0_115:                               ; %cond.load225
                                        ;   in Loop: Header=BB0_104 Depth=1
	mov.d	x20, v22[1]
	ld1.b	{ v2 }[3], [x20]
	ldr	q16, [sp, #512]                 ; 16-byte Reload
	add.2d	v16, v21, v16
	add.2d	v22, v18, v16
	tbz	w19, #4, LBB0_110
LBB0_116:                               ; %cond.load231
                                        ;   in Loop: Header=BB0_104 Depth=1
	fmov	x20, d22
	ld1.b	{ v2 }[4], [x20]
	tbz	w19, #5, LBB0_111
LBB0_117:                               ; %cond.load237
                                        ;   in Loop: Header=BB0_104 Depth=1
	mov.d	x20, v22[1]
	ld1.b	{ v2 }[5], [x20]
	add.2d	v16, v3, v19
	add.2d	v22, v8, v16
	tbz	w19, #6, LBB0_112
LBB0_118:                               ; %cond.load243
                                        ;   in Loop: Header=BB0_104 Depth=1
	fmov	x20, d22
	ld1.b	{ v2 }[6], [x20]
	tbz	w19, #7, LBB0_103
LBB0_119:                               ; %cond.load249
                                        ;   in Loop: Header=BB0_104 Depth=1
	mov.d	x19, v22[1]
	ld1.b	{ v2 }[7], [x19]
	b	LBB0_103
LBB0_120:                               ; %direct.true211.preheader
	ldr	q2, [sp, #16]                   ; 16-byte Reload
	sshll.4s	v3, v2, #0
Lloh36:
	adrp	x8, lCPI0_21@PAGE
Lloh37:
	ldr	q2, [x8, lCPI0_21@PAGEOFF]
	and.16b	v25, v0, v2
Lloh38:
	adrp	x8, lCPI0_22@PAGE
Lloh39:
	ldr	q2, [x8, lCPI0_22@PAGEOFF]
	and.16b	v26, v1, v2
Lloh40:
	adrp	x8, lCPI0_23@PAGE
Lloh41:
	ldr	q2, [x8, lCPI0_23@PAGEOFF]
	and.16b	v2, v0, v2
	str	q2, [sp, #512]                  ; 16-byte Spill
Lloh42:
	adrp	x8, lCPI0_24@PAGE
Lloh43:
	ldr	q2, [x8, lCPI0_24@PAGEOFF]
	and.16b	v2, v1, v2
	str	q2, [sp, #496]                  ; 16-byte Spill
Lloh44:
	adrp	x8, lCPI0_25@PAGE
Lloh45:
	ldr	q2, [x8, lCPI0_25@PAGEOFF]
	and.16b	v2, v1, v2
	str	q2, [sp, #528]                  ; 16-byte Spill
	ldp	q4, q2, [sp, #256]              ; 32-byte Folded Reload
	fsub.4s	v2, v2, v5
	fsub.4s	v4, v4, v5
	ldr	q6, [sp, #352]                  ; 16-byte Reload
	zip2.8b	v5, v6, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v21, v5, #0
	and.16b	v4, v21, v4
	zip1.8b	v5, v6, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v24, v5, #0
	and.16b	v5, v24, v2
	mov	w8, #-1026555904                ; =0xc2d00000
	dup.4s	v2, w8
	fcmge.4s	v16, v5, v2
	fcmge.4s	v17, v4, v2
	mov	w8, #1120403456                 ; =0x42c80000
	dup.4s	v22, w8
	fcmge.4s	v18, v22, v5
	fcmge.4s	v19, v22, v4
	and.16b	v17, v17, v19
	and.16b	v16, v16, v18
	and.16b	v16, v16, v5
	and.16b	v17, v17, v4
	mov	w8, #43579                      ; =0xaa3b
	movk	w8, #16312, lsl #16
	dup.4s	v18, w8
	fmul.4s	v19, v17, v18
	fmul.4s	v18, v16, v18
	movi.4s	v23, #75, lsl #24
	mvni.4s	v27, #128, lsl #24
	mov.16b	v28, v27
	bsl.16b	v28, v23, v18
	bif.16b	v23, v19, v27
	fadd.4s	v19, v19, v23
	fadd.4s	v18, v18, v28
	fsub.4s	v18, v18, v28
	fsub.4s	v19, v19, v23
	fcvtzs.4s	v23, v19
	fcvtzs.4s	v27, v18
	scvtf.4s	v18, v27
	scvtf.4s	v19, v23
	mov	w8, #29184                      ; =0x7200
	movk	w8, #48945, lsl #16
	dup.4s	v28, w8
	fmul.4s	v29, v19, v28
	fmul.4s	v28, v18, v28
	fadd.4s	v16, v16, v28
	fadd.4s	v17, v17, v29
	mov	w8, #48782                      ; =0xbe8e
	movk	w8, #46527, lsl #16
	dup.4s	v28, w8
	fmul.4s	v18, v18, v28
	fmul.4s	v19, v19, v28
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	mov	w8, #11226                      ; =0x2bda
	movk	w8, #14672, lsl #16
	dup.4s	v18, w8
	fmul.4s	v19, v16, v18
	fmul.4s	v18, v17, v18
	mov	w8, #38601                      ; =0x96c9
	movk	w8, #15030, lsl #16
	dup.4s	v28, w8
	fadd.4s	v18, v18, v28
	fadd.4s	v19, v19, v28
	fmul.4s	v19, v16, v19
	fmul.4s	v18, v17, v18
	mov	w8, #34982                      ; =0x88a6
	movk	w8, #15368, lsl #16
	dup.4s	v28, w8
	fadd.4s	v18, v18, v28
	fadd.4s	v19, v19, v28
	fmul.4s	v19, v16, v19
	mov	w8, #43642                      ; =0xaa7a
	movk	w8, #15658, lsl #16
	dup.4s	v28, w8
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v28
	fadd.4s	v19, v19, v28
	fmul.4s	v19, v16, v19
	fmul.4s	v18, v17, v18
	mov	w8, #43691                      ; =0xaaab
	movk	w8, #15914, lsl #16
	dup.4s	v28, w8
	fadd.4s	v18, v18, v28
	fadd.4s	v19, v19, v28
	fmul.4s	v19, v16, v19
	fmul.4s	v18, v17, v18
	movi.4s	v28, #63, lsl #24
	fadd.4s	v18, v18, v28
	fadd.4s	v19, v19, v28
	fmul.4s	v28, v17, v17
	fmul.4s	v29, v16, v16
	fmul.4s	v19, v29, v19
	fmul.4s	v18, v28, v18
	fadd.4s	v17, v17, v18
	fadd.4s	v16, v16, v19
	fmov.4s	v18, #1.00000000
	fadd.4s	v16, v16, v18
	fadd.4s	v17, v17, v18
	sshr.4s	v19, v27, #1
	sshr.4s	v28, v23, #1
	shl.4s	v29, v28, #23
	shl.4s	v30, v19, #23
	add.4s	v30, v30, v18
	add.4s	v29, v29, v18
	fmul.4s	v17, v17, v29
	fmul.4s	v16, v16, v30
	sub.4s	v23, v23, v28
	sub.4s	v19, v27, v19
	shl.4s	v19, v19, #23
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v18
	add.4s	v18, v19, v18
	fmul.4s	v16, v16, v18
	fmul.4s	v17, v17, v23
	fcmgt.4s	v18, v2, v4
	bic.16b	v17, v17, v18
	fcmgt.4s	v2, v2, v5
	bic.16b	v2, v16, v2
	fcmgt.4s	v16, v4, v22
	fcmgt.4s	v18, v5, v22
	mvni.4s	v19, #127, msl #16
	fneg.4s	v19, v19
	bit.16b	v2, v19, v18
	bsl.16b	v16, v19, v17
	fcmeq.4s	v5, v5, v5
	fcmeq.4s	v4, v4, v4
	mvni.4s	v17, #63, msl #16
	fneg.4s	v17, v17
	bsl.16b	v4, v16, v17
	bif.16b	v2, v17, v5
	bic.16b	v5, v2, v3
	ldr	q2, [sp, #96]                   ; 16-byte Reload
	bic.16b	v4, v4, v2
	add	x8, sp, #2248
	ldr	x9, [sp, #152]                  ; 8-byte Reload
	add	x9, x8, x9
	ldp	q2, q3, [x9]
	mov.16b	v7, v4
	bit.16b	v3, v4, v21
	mov.16b	v20, v5
	bit.16b	v2, v5, v24
	stp	q2, q3, [x9]
	add	x9, sp, #2248
	ldp	q2, q3, [x9, #96]
	and.16b	v21, v0, v3
	and.16b	v3, v1, v2
	ldp	q2, q16, [x9, #64]
	and.16b	v27, v0, v16
	and.16b	v24, v1, v2
	ldp	q2, q16, [x9, #32]
	and.16b	v28, v0, v16
	and.16b	v29, v1, v2
	ldr	x9, [sp, #80]                   ; 8-byte Reload
	add	x9, x8, x9
	ldp	q2, q16, [x9]
	and.16b	v22, v0, v16
	and.16b	v2, v1, v2
	mov	w9, #4                          ; =0x4
	ldr	q4, [sp, #336]                  ; 16-byte Reload
	ldr	q5, [sp, #304]                  ; 16-byte Reload
LBB0_121:                               ; %direct.true211
                                        ; =>This Inner Loop Header: Depth=1
	sshll.2d	v16, v1, #0
	sshll.2d	v17, v0, #0
	add	x10, x8, x17, lsl #5
	ldp	q19, q18, [x10]
	fadd.4s	v23, v2, v19
	fadd.4s	v30, v22, v18
	ldp	q19, q18, [x10, #32]
	fadd.4s	v19, v29, v19
	fadd.4s	v18, v28, v18
	ldp	q8, q31, [x10, #64]
	fadd.4s	v8, v24, v8
	fadd.4s	v31, v27, v31
	ldp	q14, q9, [x10, #96]
	fadd.4s	v14, v3, v14
	fadd.4s	v9, v21, v9
	dup.2d	v15, x9
	and.16b	v6, v5, v15
	add.2d	v10, v10, v6
	and.16b	v6, v4, v15
	add.2d	v11, v11, v6
	and.16b	v6, v17, v15
	add.2d	v12, v12, v6
	and.16b	v6, v16, v15
	add.2d	v13, v13, v6
	bit.16b	v22, v30, v0
	bit.16b	v2, v23, v1
	bit.16b	v28, v18, v0
	bit.16b	v29, v19, v1
	bit.16b	v27, v31, v0
	bit.16b	v24, v8, v1
	bit.16b	v21, v9, v0
	bit.16b	v3, v14, v1
	fmov	x17, d13
	cmp	x17, #192
	b.lt	LBB0_121
; %bb.122:                              ; %direct.false212
	mov	x10, #0                         ; =0x0
	mov.16b	v5, v7
	fadd.4s	v6, v7, v22
	mov.16b	v31, v20
	fadd.4s	v2, v20, v2
	ldr	q17, [sp, #352]                 ; 16-byte Reload
	zip1.8b	v16, v17, v0
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	and.16b	v2, v16, v2
	zip2.8b	v16, v17, v0
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	and.16b	v6, v16, v6
	ldr	d4, [sp, #296]                  ; 8-byte Reload
	zip2.8b	v16, v4, v0
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	bit.16b	v6, v30, v16
	zip1.8b	v16, v4, v0
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	bit.16b	v2, v23, v16
	fadd.4s	v2, v29, v2
	fadd.4s	v6, v28, v6
	fadd.4s	v6, v27, v6
	fadd.4s	v2, v24, v2
	fadd.4s	v3, v3, v2
	fadd.4s	v22, v21, v6
	fmov	w8, s26
	add	x9, sp, #632
	bfxil	x9, x8, #0, #3
	ldr	q2, [sp, #320]                  ; 16-byte Reload
	str	d2, [sp, #632]
	ldrb	w9, [x9]
	and	x8, x8, #0x7
	str	q22, [sp, #1072]
	str	q3, [sp, #1056]
	add	x11, sp, #1056
	ldr	s2, [x11, x8, lsl #2]
	tst	w5, w9
	movi.2d	v21, #0000000000000000
	fcsel	s23, s2, s21, ne
	mov.s	w8, v26[1]
	and	x9, x8, #0x7
	add	x11, sp, #632
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	str	q22, [sp, #1040]
	str	q3, [sp, #1024]
	add	x11, sp, #1024
	ldr	s2, [x11, x9, lsl #2]
	and	w8, w16, w8
	tst	w8, #0x1
	fcsel	s2, s2, s21, ne
	mov.s	w8, v26[2]
	and	x9, x8, #0x7
	add	x11, sp, #632
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w14, w8
	stp	q3, q22, [sp, #992]
	add	x11, sp, #992
	ldr	s6, [x11, x9, lsl #2]
	tst	w8, #0x1
	mov.s	w8, v26[3]
	fcsel	s24, s6, s21, ne
	and	x9, x8, #0x7
	add	x11, sp, #632
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w15, w8
	stp	q3, q22, [sp, #960]
	add	x11, sp, #960
	ldr	s6, [x11, x9, lsl #2]
	tst	w8, #0x1
	fcsel	s26, s6, s21, ne
	fmov	w8, s25
	and	x9, x8, #0x7
	add	x11, sp, #632
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w3, w8
	str	q22, [sp, #1200]
	str	q3, [sp, #1184]
	add	x11, sp, #1184
	ldr	s6, [x11, x9, lsl #2]
	tst	w8, #0x1
	fcsel	s6, s6, s21, ne
	mov.s	w8, v25[1]
	and	x9, x8, #0x7
	add	x11, sp, #632
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w2, w8
	str	q22, [sp, #1168]
	str	q3, [sp, #1152]
	add	x11, sp, #1152
	ldr	s16, [x11, x9, lsl #2]
	tst	w8, #0x1
	fcsel	s16, s16, s21, ne
	mov.s	w8, v25[2]
	and	x9, x8, #0x7
	add	x11, sp, #632
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w0, w8
	str	q22, [sp, #1136]
	str	q3, [sp, #1120]
	add	x11, sp, #1120
	ldr	s17, [x11, x9, lsl #2]
	tst	w8, #0x1
	fcsel	s17, s17, s21, ne
	mov.s	w8, v25[3]
	and	x9, x8, #0x7
	add	x11, sp, #632
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w1, w8
	str	q22, [sp, #1104]
	str	q3, [sp, #1088]
	add	x11, sp, #1088
	ldr	s18, [x11, x9, lsl #2]
	tst	w8, #0x1
	fcsel	s18, s18, s21, ne
	mov.s	v6[1], v16[0]
	mov.s	v6[2], v17[0]
	mov.s	v6[3], v18[0]
	mov.s	v23[1], v2[0]
	mov.s	v23[2], v24[0]
	mov.s	v23[3], v26[0]
	fadd.4s	v3, v3, v23
	fadd.4s	v22, v22, v6
	ldr	q4, [sp, #496]                  ; 16-byte Reload
	fmov	w8, s4
	add	x9, sp, #632
	bfxil	x9, x8, #0, #3
	ldrb	w9, [x9]
	and	x8, x8, #0x7
	stp	q3, q22, [sp, #800]
	add	x11, sp, #800
	ldr	s2, [x11, x8, lsl #2]
	tst	w5, w9
	mov.s	w8, v4[1]
	fcsel	s23, s2, s21, ne
	and	x9, x8, #0x7
	add	x11, sp, #632
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w16, w8
	stp	q3, q22, [sp, #768]
	add	x11, sp, #768
	ldr	s2, [x11, x9, lsl #2]
	tst	w8, #0x1
	fcsel	s2, s2, s21, ne
	mov.s	w8, v4[2]
	and	x9, x8, #0x7
	add	x11, sp, #632
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	stp	q3, q22, [sp, #736]
	add	x11, sp, #736
	ldr	s6, [x11, x9, lsl #2]
	and	w8, w14, w8
	tst	w8, #0x1
	fcsel	s24, s6, s21, ne
	mov.s	w8, v4[3]
	and	x9, x8, #0x7
	add	x11, sp, #632
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w15, w8
	stp	q3, q22, [sp, #704]
	add	x11, sp, #704
	ldr	s6, [x11, x9, lsl #2]
	tst	w8, #0x1
	fcsel	s20, s6, s21, ne
	ldr	q4, [sp, #512]                  ; 16-byte Reload
	fmov	w8, s4
	and	x9, x8, #0x7
	add	x11, sp, #632
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w3, w8
	stp	q3, q22, [sp, #928]
	add	x11, sp, #928
	ldr	s6, [x11, x9, lsl #2]
	tst	w8, #0x1
	fcsel	s6, s6, s21, ne
	mov.s	w8, v4[1]
	and	x9, x8, #0x7
	add	x11, sp, #632
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w2, w8
	stp	q3, q22, [sp, #896]
	add	x11, sp, #896
	ldr	s16, [x11, x9, lsl #2]
	tst	w8, #0x1
	fcsel	s16, s16, s21, ne
	mov.s	w8, v4[2]
	and	x9, x8, #0x7
	add	x11, sp, #632
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w0, w8
	stp	q3, q22, [sp, #864]
	add	x11, sp, #864
	ldr	s17, [x11, x9, lsl #2]
	tst	w8, #0x1
	fcsel	s17, s17, s21, ne
	mov.s	w8, v4[3]
	and	x9, x8, #0x7
	add	x11, sp, #632
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w1, w8
	stp	q3, q22, [sp, #832]
	add	x11, sp, #832
	ldr	s7, [x11, x9, lsl #2]
	tst	w8, #0x1
	fcsel	s7, s7, s21, ne
	mov.s	v6[1], v16[0]
	mov.s	v6[2], v17[0]
	mov.s	v6[3], v7[0]
	mov.s	v23[1], v2[0]
	mov.s	v23[2], v24[0]
	mov.s	v23[3], v20[0]
	add	x8, sp, #632
	fadd.4s	v2, v3, v23
	fadd.4s	v3, v22, v6
	ldr	q4, [sp, #528]                  ; 16-byte Reload
	fmov	w9, s4
	bfxil	x8, x9, #0, #3
	ldrb	w8, [x8]
	and	x9, x9, #0x7
	stp	q2, q3, [sp, #672]
	add	x11, sp, #672
	ldr	s3, [x11, x9, lsl #2]
	tst	w5, w8
	fcsel	s3, s3, s21, ne
	tst	w13, #0x1
	fadd	s2, s2, s3
	fcsel	s3, s2, s21, ne
	ldr	w8, [sp, #112]                  ; 4-byte Reload
	tst	w8, #0x1
	fcsel	s6, s2, s21, ne
	ldr	w8, [sp, #64]                   ; 4-byte Reload
	tst	w8, #0x1
	fcsel	s7, s2, s21, ne
	ldr	w8, [sp, #48]                   ; 4-byte Reload
	tst	w8, #0x1
	fcsel	s16, s2, s21, ne
	ldr	w8, [sp, #32]                   ; 4-byte Reload
	tst	w8, #0x1
	fcsel	s17, s2, s21, ne
	tst	w21, #0x1
	fcsel	s18, s2, s21, ne
	tst	w22, #0x1
	fcsel	s19, s2, s21, ne
	tst	w23, #0x1
	fcsel	s2, s2, s21, ne
	mov.s	v3[1], v6[0]
	mov.s	v3[2], v7[0]
	mov.s	v3[3], v16[0]
	mov.s	v17[1], v18[0]
	mov.s	v17[2], v19[0]
	mov.s	v17[3], v2[0]
	stp	q3, q17, [sp, #640]
	and	x8, x12, #0x7
	add	x9, sp, #640
	ldr	s2, [x9, x8, lsl #2]
	fadd	s2, s2, s21
	dup.4s	v3, v2[0]
	ldr	q2, [sp, #160]                  ; 16-byte Reload
	fmov	x8, d2
	ldp	x15, x14, [sp, #240]            ; 16-byte Folded Reload
	add	x8, x14, x8, lsl #2
	movi.2d	v2, #0000000000000000
	add	x9, sp, #2248
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v20, #0000000000000000
	ldp	q18, q17, [sp, #448]            ; 32-byte Folded Reload
	ldr	q19, [sp, #432]                 ; 16-byte Reload
	ldr	q22, [sp, #480]                 ; 16-byte Reload
	ldr	q23, [sp, #544]                 ; 16-byte Reload
	ldr	d4, [sp, #144]                  ; 8-byte Reload
	b	LBB0_124
LBB0_123:                               ; %else271
                                        ;   in Loop: Header=BB0_124 Depth=1
	add.2d	v6, v6, v19
	add.2d	v7, v7, v22
	add.2d	v20, v20, v18
	add.2d	v2, v2, v23
	fmov	x10, d2
	cmp	x10, #192
	b.ge	LBB0_140
LBB0_124:                               ; %direct.true248
                                        ; =>This Inner Loop Header: Depth=1
	fmov	w11, s17
	lsl	x10, x10, #5
	add	x12, x9, x10
	ldr	q16, [x12]
	and.16b	v16, v1, v16
	fdiv.4s	v21, v16, v3
	add	x10, x8, x10
	tbnz	w11, #0, LBB0_132
; %bb.125:                              ; %else257
                                        ;   in Loop: Header=BB0_124 Depth=1
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB0_133
LBB0_126:                               ; %else259
                                        ;   in Loop: Header=BB0_124 Depth=1
	tbnz	w11, #2, LBB0_134
LBB0_127:                               ; %else261
                                        ;   in Loop: Header=BB0_124 Depth=1
	tbnz	w11, #3, LBB0_135
LBB0_128:                               ; %else263
                                        ;   in Loop: Header=BB0_124 Depth=1
	ldr	q16, [x12, #16]
	and.16b	v16, v0, v16
	fdiv.4s	v21, v16, v3
	tbnz	w11, #4, LBB0_136
LBB0_129:                               ; %else265
                                        ;   in Loop: Header=BB0_124 Depth=1
	tbnz	w11, #5, LBB0_137
LBB0_130:                               ; %else267
                                        ;   in Loop: Header=BB0_124 Depth=1
	tbnz	w11, #6, LBB0_138
LBB0_131:                               ; %else269
                                        ;   in Loop: Header=BB0_124 Depth=1
	tbz	w11, #7, LBB0_123
	b	LBB0_139
LBB0_132:                               ; %cond.store256
                                        ;   in Loop: Header=BB0_124 Depth=1
	str	s21, [x10]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB0_126
LBB0_133:                               ; %cond.store258
                                        ;   in Loop: Header=BB0_124 Depth=1
	add	x13, x10, #4
	st1.s	{ v21 }[1], [x13]
	tbz	w11, #2, LBB0_127
LBB0_134:                               ; %cond.store260
                                        ;   in Loop: Header=BB0_124 Depth=1
	add	x13, x10, #8
	st1.s	{ v21 }[2], [x13]
	tbz	w11, #3, LBB0_128
LBB0_135:                               ; %cond.store262
                                        ;   in Loop: Header=BB0_124 Depth=1
	add	x13, x10, #12
	st1.s	{ v21 }[3], [x13]
	ldr	q16, [x12, #16]
	and.16b	v16, v0, v16
	fdiv.4s	v21, v16, v3
	tbz	w11, #4, LBB0_129
LBB0_136:                               ; %cond.store264
                                        ;   in Loop: Header=BB0_124 Depth=1
	str	s21, [x10, #16]
	tbz	w11, #5, LBB0_130
LBB0_137:                               ; %cond.store266
                                        ;   in Loop: Header=BB0_124 Depth=1
	add	x12, x10, #20
	st1.s	{ v21 }[1], [x12]
	tbz	w11, #6, LBB0_131
LBB0_138:                               ; %cond.store268
                                        ;   in Loop: Header=BB0_124 Depth=1
	add	x12, x10, #24
	st1.s	{ v21 }[2], [x12]
	tbz	w11, #7, LBB0_123
LBB0_139:                               ; %cond.store270
                                        ;   in Loop: Header=BB0_124 Depth=1
	add	x10, x10, #28
	st1.s	{ v21 }[3], [x10]
	b	LBB0_123
LBB0_140:                               ; %direct.false249
	fmov	w8, s4
	ldr	q1, [sp, #352]                  ; 16-byte Reload
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	and.16b	v0, v0, v31
	zip2.8b	v1, v1, v0
	ushll.4s	v1, v1, #0
	fdiv.4s	v0, v0, v3
	ldr	q6, [sp, #224]                  ; 16-byte Reload
	ldp	q2, q7, [sp, #176]              ; 32-byte Folded Reload
	stp	q6, q7, [sp, #560]
	str	q2, [sp, #592]
	ldr	q2, [sp, #208]                  ; 16-byte Reload
	str	q2, [sp, #608]
	and	x9, x15, #0x7
	add	x10, sp, #560
	ldr	x9, [x10, x9, lsl #3]
	sub	x9, x9, x15
	add	x9, x14, x9, lsl #2
	tbnz	w8, #0, LBB0_156
; %bb.141:                              ; %else274
	shl.4s	v1, v1, #31
	tbnz	w8, #1, LBB0_157
LBB0_142:                               ; %else276
	cmlt.4s	v1, v1, #0
	tbnz	w8, #2, LBB0_158
LBB0_143:                               ; %else278
	and.16b	v1, v1, v5
	tbnz	w8, #3, LBB0_159
LBB0_144:                               ; %else280
	fdiv.4s	v0, v1, v3
	tbnz	w8, #4, LBB0_160
LBB0_145:                               ; %else282
	tbnz	w8, #5, LBB0_161
LBB0_146:                               ; %else284
	tbnz	w8, #6, LBB0_162
LBB0_147:                               ; %else286
	tbz	w8, #7, LBB0_149
LBB0_148:                               ; %cond.store287
	add	x8, x9, #28
	st1.s	{ v0 }[3], [x8]
LBB0_149:
	add	sp, sp, #8, lsl #12             ; =32768
	add	sp, sp, #1904
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
LBB0_150:                               ; %common.ret
	ret
LBB0_151:                               ; %cond.load170
	fmov	x10, d3
	ld1.b	{ v2 }[2], [x10]
	tbz	w11, #3, LBB0_95
LBB0_152:                               ; %cond.load176
	ld1.b	{ v2 }[3], [x9]
	tbz	w11, #4, LBB0_96
LBB0_153:                               ; %cond.load182
	fmov	x9, d9
	ld1.b	{ v2 }[4], [x9]
	tbz	w11, #5, LBB0_97
LBB0_154:                               ; %cond.load188
	ld1.b	{ v2 }[5], [x8]
	tbz	w11, #6, LBB0_98
LBB0_155:                               ; %cond.load194
	fmov	x8, d7
	ld1.b	{ v2 }[6], [x8]
	movi	d3, #0xffffffffffff0000
	stp	q30, q24, [sp, #400]            ; 32-byte Folded Spill
	stp	q31, q8, [sp, #368]             ; 32-byte Folded Spill
	str	d4, [sp, #144]                  ; 8-byte Spill
	str	q16, [sp, #128]                 ; 16-byte Spill
	tbnz	w11, #7, LBB0_99
	b	LBB0_100
LBB0_156:                               ; %cond.store273
	str	s0, [x9]
	shl.4s	v1, v1, #31
	tbz	w8, #1, LBB0_142
LBB0_157:                               ; %cond.store275
	add	x10, x9, #4
	st1.s	{ v0 }[1], [x10]
	cmlt.4s	v1, v1, #0
	tbz	w8, #2, LBB0_143
LBB0_158:                               ; %cond.store277
	add	x10, x9, #8
	st1.s	{ v0 }[2], [x10]
	and.16b	v1, v1, v5
	tbz	w8, #3, LBB0_144
LBB0_159:                               ; %cond.store279
	add	x10, x9, #12
	st1.s	{ v0 }[3], [x10]
	fdiv.4s	v0, v1, v3
	tbz	w8, #4, LBB0_145
LBB0_160:                               ; %cond.store281
	str	s0, [x9, #16]
	tbz	w8, #5, LBB0_146
LBB0_161:                               ; %cond.store283
	add	x10, x9, #20
	st1.s	{ v0 }[1], [x10]
	tbz	w8, #6, LBB0_147
LBB0_162:                               ; %cond.store285
	add	x10, x9, #24
	st1.s	{ v0 }[2], [x10]
	tbnz	w8, #7, LBB0_148
	b	LBB0_149
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh32, Lloh33
	.loh AdrpAdrp	Lloh30, Lloh32
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdrp	Lloh28, Lloh30
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpLdr	Lloh44, Lloh45
	.loh AdrpAdrp	Lloh42, Lloh44
	.loh AdrpLdr	Lloh42, Lloh43
	.loh AdrpAdrp	Lloh40, Lloh42
	.loh AdrpLdr	Lloh40, Lloh41
	.loh AdrpAdrp	Lloh38, Lloh40
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpAdrp	Lloh36, Lloh38
	.loh AdrpLdr	Lloh36, Lloh37
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.full_packet
lCPI1_0:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI1_1:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI1_2:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI1_3:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI1_4:
	.quad	1536                            ; 0x600
	.quad	1537                            ; 0x601
lCPI1_5:
	.quad	0                               ; 0x0
	.quad	193                             ; 0xc1
lCPI1_6:
	.quad	386                             ; 0x182
	.quad	579                             ; 0x243
lCPI1_7:
	.quad	772                             ; 0x304
	.quad	965                             ; 0x3c5
lCPI1_8:
	.quad	1158                            ; 0x486
	.quad	1351                            ; 0x547
lCPI1_9:
	.long	1536                            ; 0x600
	.long	1537                            ; 0x601
	.long	0                               ; 0x0
	.long	0                               ; 0x0
lCPI1_10:
	.quad	1350                            ; 0x546
	.quad	1543                            ; 0x607
lCPI1_11:
	.quad	964                             ; 0x3c4
	.quad	1157                            ; 0x485
lCPI1_12:
	.quad	578                             ; 0x242
	.quad	771                             ; 0x303
lCPI1_13:
	.quad	192                             ; 0xc0
	.quad	385                             ; 0x181
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows.full_packet:                  ; @llm_rows.full_packet
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-144]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x26, x25, [sp, #64]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	sub	sp, sp, #7, lsl #12             ; =28672
	sub	sp, sp, #3792
	add	x21, sp, #3, lsl #12            ; =12288
	add	x21, x21, #1648
	ldr	x22, [x0]
	ldr	x19, [x0, #48]
	ldr	w8, [x1]
	ldr	w9, [x1, #36]
	add	w8, w9, w8, lsl #5
	lsr	w8, w8, #3
	dup.4s	v0, w8
	str	q0, [sp, #16]                   ; 16-byte Spill
	fmov	s0, w8
	ushll.2d	v0, v0, #0
	fmov	x23, d0
	mov	w24, #6152                      ; =0x1808
	umull	x20, w23, w24
	umaddl	x1, w23, w24, x22
	mov	w25, #6144                      ; =0x1800
	add	x0, sp, #6, lsl #12             ; =24576
	add	x0, x0, #1712
	mov	w2, #6144                       ; =0x1800
	bl	_memcpy
	mov	x9, #0                          ; =0x0
	umaddl	x8, w23, w24, x25
	add	x10, x22, x8
	add	x11, x10, #4
	ldr	s5, [x10]
	ld1.s	{ v5 }[1], [x11]
	str	q5, [x21, #18496]
	movi.2d	v0, #0000000000000000
Lloh46:
	adrp	x10, lCPI1_0@PAGE
Lloh47:
	ldr	q1, [x10, lCPI1_0@PAGEOFF]
Lloh48:
	adrp	x10, lCPI1_1@PAGE
Lloh49:
	ldr	q2, [x10, lCPI1_1@PAGEOFF]
Lloh50:
	adrp	x10, lCPI1_2@PAGE
Lloh51:
	ldr	q3, [x10, lCPI1_2@PAGEOFF]
Lloh52:
	adrp	x10, lCPI1_3@PAGE
Lloh53:
	ldr	q4, [x10, lCPI1_3@PAGEOFF]
	mov	w10, #1                         ; =0x1
	dup.2d	v6, x10
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
LBB1_1:                                 ; %direct.true69
                                        ; =>This Inner Loop Header: Depth=1
	shl.2d	v18, v0, #3
	shl.2d	v19, v7, #3
	shl.2d	v20, v16, #3
	shl.2d	v21, v17, #3
	orr.16b	v21, v21, v1
	orr.16b	v20, v20, v2
	orr.16b	v19, v19, v3
	orr.16b	v18, v18, v4
	add	x9, x21, x9, lsl #6
	stp	q18, q19, [x9]
	stp	q20, q21, [x9, #32]
	add.2d	v16, v16, v6
	add.2d	v7, v7, v6
	add.2d	v17, v17, v6
	add.2d	v0, v0, v6
	fmov	x9, d0
	cmp	x9, #192
	b.lt	LBB1_1
; %bb.2:                                ; %direct.false70
	mov	x10, #0                         ; =0x0
Lloh54:
	adrp	x9, lCPI1_4@PAGE
Lloh55:
	ldr	q0, [x9, lCPI1_4@PAGEOFF]
	str	q0, [x21, #12288]
	mov	w9, #7585                       ; =0x1da1
	movk	w9, #2727, lsl #16
	dup.4s	v0, w9
	ldr	q16, [sp, #16]                  ; 16-byte Reload
	umull2.2d	v1, v16, v0
	umull.2d	v2, v16, v0
	uzp2.4s	v2, v2, v1
	ushr.4s	v2, v2, #6
	mov	w9, #1538                       ; =0x602
	dup.4s	v3, w9
	mov.16b	v4, v16
	mls.4s	v4, v2, v3
	umull.2d	v0, v16, v0
	uzp2.4s	v0, v0, v1
	ushr.4s	v0, v0, #6
	mls.4s	v16, v0, v3
	ushll2.2d	v6, v16, #0
	ushll2.2d	v7, v4, #0
	ushll.2d	v16, v16, #0
	ushll.2d	v17, v4, #0
	movi.2d	v18, #0000000000000000
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #104
	dup.2d	v19, x9
Lloh56:
	adrp	x9, lCPI1_5@PAGE
Lloh57:
	ldr	q0, [x9, lCPI1_5@PAGEOFF]
Lloh58:
	adrp	x9, lCPI1_6@PAGE
Lloh59:
	ldr	q1, [x9, lCPI1_6@PAGEOFF]
Lloh60:
	adrp	x9, lCPI1_7@PAGE
Lloh61:
	ldr	q2, [x9, lCPI1_7@PAGEOFF]
	mov	w9, #1                          ; =0x1
	dup.2d	v20, x9
Lloh62:
	adrp	x9, lCPI1_8@PAGE
Lloh63:
	ldr	q3, [x9, lCPI1_8@PAGEOFF]
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #1648
	movi.8b	v21, #1
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
LBB1_3:                                 ; %direct.true85
                                        ; =>This Inner Loop Header: Depth=1
	add	x10, x9, x10, lsl #6
	ldp	q26, q25, [x10, #32]
	ldp	q27, q28, [x10]
	add.2d	v29, v24, v3
	add.2d	v29, v29, v19
	add.2d	v30, v23, v2
	add.2d	v31, v22, v1
	add.2d	v8, v18, v0
	add.2d	v8, v8, v19
	cmge.2d	v28, v7, v28
	cmge.2d	v27, v17, v27
	uzp1.4s	v27, v27, v28
	cmge.2d	v26, v16, v26
	cmge.2d	v25, v6, v25
	uzp1.4s	v25, v26, v25
	uzp1.8h	v25, v27, v25
	xtn.8b	v25, v25
	and.8b	v25, v25, v21
	mov.d	x10, v8[1]
	fmov	x11, d8
	str	b25, [x11]
	st1.b	{ v25 }[1], [x10]
	add.2d	v26, v31, v19
	mov.d	x10, v26[1]
	fmov	x11, d26
	st1.b	{ v25 }[2], [x11]
	add.2d	v26, v30, v19
	st1.b	{ v25 }[3], [x10]
	mov.d	x10, v26[1]
	fmov	x11, d26
	st1.b	{ v25 }[4], [x11]
	st1.b	{ v25 }[5], [x10]
	mov.d	x10, v29[1]
	fmov	x11, d29
	st1.b	{ v25 }[6], [x11]
	st1.b	{ v25 }[7], [x10]
	add.2d	v23, v23, v20
	add.2d	v22, v22, v20
	add.2d	v24, v24, v20
	add.2d	v18, v18, v20
	fmov	x10, d18
	cmp	x10, #192
	b.lt	LBB1_3
; %bb.4:                                ; %direct.false86
	mov	x10, #0                         ; =0x0
Lloh64:
	adrp	x9, lCPI1_9@PAGE
Lloh65:
	ldr	q16, [x9, lCPI1_9@PAGEOFF]
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #104
	dup.2d	v6, x9
Lloh66:
	adrp	x9, lCPI1_13@PAGE
Lloh67:
	ldr	q7, [x9, lCPI1_13@PAGEOFF]
	add.2d	v7, v6, v7
	cmhs.4s	v4, v4, v16
	xtn.4h	v4, v4
	uzp1.8b	v4, v4, v0
	movi.8b	v16, #1
	and.8b	v4, v4, v16
	fmov	x9, d7
	str	b4, [x9]
	mov.d	x9, v7[1]
	st1.b	{ v4 }[1], [x9]
	movi.2d	v4, #0000000000000000
	add	x11, sp, #6, lsl #12            ; =24576
	add	x11, x11, #1712
	mov	w12, #62154                     ; =0xf2ca
	movk	w12, #61769, lsl #16
	dup.4s	v16, w12
	mov	w12, #1                         ; =0x1
	dup.2d	v17, x12
	add	x12, sp, #1, lsl #12            ; =4096
	add	x12, x12, #2120
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
LBB1_5:                                 ; %direct.true101
                                        ; =>This Inner Loop Header: Depth=1
	add.2d	v21, v20, v3
	add.2d	v21, v21, v6
	add.2d	v22, v19, v2
	add.2d	v22, v22, v6
	add.2d	v23, v18, v1
	add.2d	v23, v23, v6
	add.2d	v24, v4, v0
	add.2d	v24, v24, v6
	mov.d	x13, v24[1]
	mov.d	x14, v23[1]
	fmov	x15, d24
	fmov	x16, d23
	mov.d	x17, v22[1]
	fmov	x0, d22
	ldr	b22, [x15]
	ld1.b	{ v22 }[1], [x13]
	ld1.b	{ v22 }[2], [x16]
	mov.d	x13, v21[1]
	ld1.b	{ v22 }[3], [x14]
	ld1.b	{ v22 }[4], [x0]
	ld1.b	{ v22 }[5], [x17]
	fmov	x14, d21
	ld1.b	{ v22 }[6], [x14]
	ld1.b	{ v22 }[7], [x13]
	cmeq.8b	v21, v22, #0
	sshll.8h	v21, v21, #0
	sshll2.4s	v22, v21, #0
	lsl	x10, x10, #5
	add	x13, x11, x10
	ldp	q24, q23, [x13]
	sshll.4s	v21, v21, #0
	bsl.16b	v21, v16, v24
	bsl.16b	v22, v16, v23
	add	x10, x12, x10
	stp	q21, q22, [x10]
	add.2d	v19, v19, v17
	add.2d	v18, v18, v17
	add.2d	v20, v20, v17
	add.2d	v4, v4, v17
	fmov	x10, d4
	cmp	x10, #192
	b.lt	LBB1_5
; %bb.6:                                ; %direct.false102
	fmov	x10, d7
	ldr	b4, [x10]
	ld1.b	{ v4 }[1], [x9]
	cmeq.8b	v4, v4, #0
	sshll.8h	v4, v4, #0
	mov	w9, #62154                      ; =0xf2ca
	movk	w9, #61769, lsl #16
	dup.4s	v6, w9
	str	q4, [sp, #16]                   ; 16-byte Spill
	sshll.4s	v7, v4, #0
	bif.16b	v6, v5, v7
	add	x9, sp, #2, lsl #12             ; =8192
	add	x9, x9, #3913
	ldur	q7, [x9, #255]
	mov.16b	v4, v6
	mov.d	v4[1], v7[1]
	str	q4, [sp]                        ; 16-byte Spill
	add	x9, sp, #2, lsl #12             ; =8192
	add	x9, x9, #3913
	stur	q4, [x9, #255]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #1881
	ldur	q7, [x9, #255]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #1865
	ldur	q21, [x9, #255]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #1913
	ldur	q20, [x9, #255]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #1897
	ldur	q19, [x9, #255]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #1945
	ldur	q16, [x9, #255]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #1929
	ldur	q22, [x9, #255]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #1977
	ldur	q18, [x9, #255]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #1961
	ldur	q17, [x9, #255]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #2120
	add	x9, x9, #224
	mov	w10, #4                         ; =0x4
LBB1_7:                                 ; %direct.true135
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q23, q24, [x9, #-96]
	fmaxnm.4s	v7, v7, v24
	fmaxnm.4s	v21, v21, v23
	ldp	q23, q24, [x9, #-64]
	fmaxnm.4s	v20, v20, v24
	fmaxnm.4s	v19, v19, v23
	ldp	q23, q24, [x9, #-32]
	fmaxnm.4s	v16, v16, v24
	fmaxnm.4s	v22, v22, v23
	ldp	q23, q24, [x9], #128
	fmaxnm.4s	v18, v18, v24
	fmaxnm.4s	v17, v17, v23
	cmp	x10, #188
	add	x10, x10, #4
	b.lo	LBB1_7
; %bb.8:                                ; %direct.false136
	mov	x0, #0                          ; =0x0
	movi.2d	v23, #0000000000000000
	mov.d	v23[0], v6[0]
	fmaxnm.4s	v6, v21, v23
	mov.d	v6[1], v21[1]
	fmaxnm.4s	v7, v7, v20
	fmaxnm.4s	v6, v6, v19
	fmaxnm.4s	v6, v6, v22
	fmaxnm.4s	v7, v7, v16
	fmaxnm.4s	v7, v7, v18
	fmaxnm.4s	v6, v6, v17
	rev64.4s	v16, v6
	rev64.4s	v17, v7
	fmaxnm.4s	v7, v7, v17
	fmaxnm.4s	v6, v6, v16
	ext.16b	v16, v6, v6, #8
	ext.16b	v17, v7, v7, #8
	fmaxnm.4s	v7, v7, v17
	fmaxnm.4s	v6, v6, v16
	fmaxnm.4s	v6, v6, v7
	mov	w9, #-8388608                   ; =0xff800000
	fmov	s7, w9
	fmaxnm	s6, s6, s7
	dup.4s	v6, v6[0]
	movi.2d	v7, #0000000000000000
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #104
	dup.2d	v16, x9
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #2120
	mov	w10, #-1026555904               ; =0xc2d00000
	dup.4s	v17, w10
	mov	w10, #1120403456                ; =0x42c80000
	dup.4s	v18, w10
	mov	w10, #43579                     ; =0xaa3b
	movk	w10, #16312, lsl #16
	dup.4s	v19, w10
	mov	w10, #29184                     ; =0x7200
	movk	w10, #48945, lsl #16
	dup.4s	v21, w10
	mvni.4s	v22, #128, lsl #24
	mov	w10, #48782                     ; =0xbe8e
	movk	w10, #46527, lsl #16
	mov	w11, #11226                     ; =0x2bda
	movk	w11, #14672, lsl #16
	mov	w12, #38601                     ; =0x96c9
	movk	w12, #15030, lsl #16
	mov	w13, #34982                     ; =0x88a6
	movk	w13, #15368, lsl #16
	mov	w14, #43642                     ; =0xaa7a
	movk	w14, #15658, lsl #16
	mov	w15, #43691                     ; =0xaaab
	movk	w15, #15914, lsl #16
	movi.4s	v23, #63, lsl #24
	fmov.4s	v24, #1.00000000
	mvni.4s	v25, #127, msl #16
	fneg.4s	v25, v25
	mvni.4s	v26, #63, msl #16
	fneg.4s	v26, v26
	add	x16, sp, #40
	mov	w17, #1                         ; =0x1
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
LBB1_9:                                 ; %direct.true170
                                        ; =>This Inner Loop Header: Depth=1
	add.2d	v30, v29, v3
	add.2d	v30, v30, v16
	add.2d	v31, v28, v2
	add.2d	v31, v31, v16
	add.2d	v8, v27, v1
	add.2d	v8, v8, v16
	add.2d	v9, v7, v0
	add.2d	v9, v9, v16
	mov.d	x1, v9[1]
	fmov	x2, d9
	mov.d	x3, v8[1]
	fmov	x4, d8
	mov.d	x5, v31[1]
	fmov	x6, d31
	mov.d	x7, v30[1]
	ldr	b8, [x2]
	ld1.b	{ v8 }[1], [x1]
	ld1.b	{ v8 }[2], [x4]
	ld1.b	{ v8 }[3], [x3]
	ld1.b	{ v8 }[4], [x6]
	fmov	x1, d30
	ld1.b	{ v8 }[5], [x5]
	lsl	x0, x0, #5
	ld1.b	{ v8 }[6], [x1]
	add	x1, x9, x0
	ldp	q31, q30, [x1]
	fsub.4s	v30, v30, v6
	ld1.b	{ v8 }[7], [x7]
	fsub.4s	v31, v31, v6
	fcmge.4s	v9, v31, v17
	fcmge.4s	v10, v30, v17
	fcmge.4s	v11, v18, v31
	fcmge.4s	v12, v18, v30
	cmeq.8b	v8, v8, #0
	and.16b	v10, v10, v12
	and.16b	v9, v9, v11
	and.16b	v11, v9, v31
	and.16b	v10, v10, v30
	fmul.4s	v9, v10, v19
	sshll.8h	v12, v8, #0
	fmul.4s	v8, v11, v19
	movi.4s	v4, #75, lsl #24
	mov.16b	v13, v22
	bsl.16b	v13, v4, v8
	mov.16b	v14, v22
	bsl.16b	v14, v4, v9
	fadd.4s	v9, v9, v14
	fadd.4s	v15, v8, v13
	sshll2.4s	v8, v12, #0
	fsub.4s	v13, v15, v13
	fsub.4s	v9, v9, v14
	fcvtzs.4s	v14, v9
	fcvtzs.4s	v13, v13
	scvtf.4s	v15, v13
	sshll.4s	v9, v12, #0
	scvtf.4s	v12, v14
	fmul.4s	v4, v12, v21
	fmul.4s	v5, v15, v21
	dup.4s	v20, w10
	fadd.4s	v5, v11, v5
	fadd.4s	v4, v10, v4
	fmul.4s	v10, v15, v20
	fmul.4s	v20, v12, v20
	dup.4s	v11, w11
	fadd.4s	v4, v4, v20
	fadd.4s	v5, v5, v10
	fmul.4s	v20, v5, v11
	fmul.4s	v10, v4, v11
	dup.4s	v11, w12
	fadd.4s	v10, v10, v11
	fadd.4s	v20, v20, v11
	fmul.4s	v20, v5, v20
	fmul.4s	v10, v4, v10
	dup.4s	v11, w13
	fadd.4s	v10, v10, v11
	fadd.4s	v20, v20, v11
	fmul.4s	v20, v5, v20
	fmul.4s	v10, v4, v10
	dup.4s	v11, w14
	fadd.4s	v10, v10, v11
	fadd.4s	v20, v20, v11
	fmul.4s	v20, v5, v20
	fmul.4s	v10, v4, v10
	dup.4s	v11, w15
	fadd.4s	v10, v10, v11
	fadd.4s	v20, v20, v11
	fmul.4s	v20, v5, v20
	fmul.4s	v10, v4, v10
	fadd.4s	v10, v10, v23
	fadd.4s	v20, v20, v23
	fmul.4s	v11, v4, v4
	fmul.4s	v12, v5, v5
	fmul.4s	v20, v12, v20
	fmul.4s	v10, v11, v10
	fadd.4s	v4, v4, v10
	fadd.4s	v5, v5, v20
	fadd.4s	v5, v5, v24
	sshr.4s	v20, v13, #1
	sshr.4s	v10, v14, #1
	shl.4s	v11, v10, #23
	shl.4s	v12, v20, #23
	add.4s	v12, v12, v24
	fadd.4s	v4, v4, v24
	add.4s	v11, v11, v24
	fmul.4s	v4, v4, v11
	sub.4s	v10, v14, v10
	sub.4s	v20, v13, v20
	shl.4s	v20, v20, #23
	fmul.4s	v5, v5, v12
	shl.4s	v10, v10, #23
	add.4s	v10, v10, v24
	add.4s	v20, v20, v24
	fmul.4s	v5, v5, v20
	fcmgt.4s	v20, v17, v30
	fmul.4s	v4, v4, v10
	bic.16b	v4, v4, v20
	fcmgt.4s	v20, v17, v31
	bic.16b	v5, v5, v20
	fcmgt.4s	v20, v30, v18
	fcmgt.4s	v10, v31, v18
	bit.16b	v5, v25, v10
	bit.16b	v4, v25, v20
	fcmeq.4s	v20, v31, v31
	fcmeq.4s	v30, v30, v30
	bif.16b	v4, v26, v30
	bif.16b	v5, v26, v20
	bic.16b	v5, v5, v9
	bic.16b	v4, v4, v8
	add	x0, x16, x0
	dup.2d	v20, x17
	stp	q5, q4, [x0]
	add.2d	v28, v28, v20
	add.2d	v27, v27, v20
	add.2d	v29, v29, v20
	add.2d	v7, v7, v20
	fmov	x0, d7
	cmp	x0, #192
	b.lt	LBB1_9
; %bb.10:                               ; %direct.false171
	ldp	q2, q0, [sp]                    ; 32-byte Folded Reload
	sshll.4s	v0, v0, #0
	dup.4s	v1, v6[0]
	fsub.4s	v2, v2, v1
	movi.2d	v1, #0000000000000000
	mov.d	v1[0], v2[0]
	mov	w9, #-1026555904                ; =0xc2d00000
	dup.4s	v2, w9
	mov	w9, #1120403456                 ; =0x42c80000
	dup.4s	v3, w9
	fcmge.4s	v4, v1, v2
	fcmge.4s	v5, v3, v1
	and.16b	v4, v4, v5
	mov	w9, #43579                      ; =0xaa3b
	movk	w9, #16312, lsl #16
	dup.4s	v5, w9
	and.16b	v4, v4, v1
	fmul.4s	v5, v4, v5
	movi.4s	v6, #75, lsl #24
	mvni.4s	v7, #128, lsl #24
	bif.16b	v6, v5, v7
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	fcvtzs.4s	v5, v5
	scvtf.4s	v6, v5
	mov	w9, #29184                      ; =0x7200
	movk	w9, #48945, lsl #16
	dup.4s	v7, w9
	fmul.4s	v7, v6, v7
	fadd.4s	v4, v4, v7
	mov	w9, #48782                      ; =0xbe8e
	movk	w9, #46527, lsl #16
	dup.4s	v7, w9
	fmul.4s	v6, v6, v7
	fadd.4s	v4, v4, v6
	mov	w9, #11226                      ; =0x2bda
	movk	w9, #14672, lsl #16
	dup.4s	v6, w9
	fmul.4s	v6, v4, v6
	mov	w9, #38601                      ; =0x96c9
	movk	w9, #15030, lsl #16
	dup.4s	v7, w9
	fadd.4s	v6, v6, v7
	mov	w9, #34982                      ; =0x88a6
	movk	w9, #15368, lsl #16
	dup.4s	v7, w9
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v7
	fmul.4s	v6, v4, v6
	mov	w9, #43642                      ; =0xaa7a
	movk	w9, #15658, lsl #16
	dup.4s	v7, w9
	fadd.4s	v6, v6, v7
	fmul.4s	v6, v4, v6
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #15914, lsl #16
	dup.4s	v7, w9
	fadd.4s	v6, v6, v7
	fmul.4s	v6, v4, v6
	movi.4s	v7, #63, lsl #24
	fadd.4s	v6, v6, v7
	fmul.4s	v7, v4, v4
	fmul.4s	v6, v7, v6
	fadd.4s	v4, v4, v6
	fmov.4s	v6, #1.00000000
	fadd.4s	v4, v4, v6
	sshr.4s	v7, v5, #1
	shl.4s	v16, v7, #23
	add.4s	v16, v16, v6
	fmul.4s	v4, v4, v16
	sub.4s	v5, v5, v7
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v6
	fmul.4s	v4, v4, v5
	fcmgt.4s	v2, v2, v1
	bic.16b	v2, v4, v2
	fcmgt.4s	v3, v1, v3
	mvni.4s	v4, #127, msl #16
	fneg.4s	v4, v4
	bit.16b	v2, v4, v3
	fcmeq.4s	v1, v1, v1
	mvni.4s	v3, #63, msl #16
	fneg.4s	v3, v3
	bsl.16b	v1, v2, v3
	bic.16b	v0, v1, v0
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #1833
	ldur	q1, [x9, #255]
	mov.d	v0[1], v1[1]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #1833
	stur	q0, [x9, #255]
	ldur	q1, [sp, #56]
	ldur	q7, [sp, #40]
	ldur	q6, [sp, #88]
	ldur	q5, [sp, #72]
	ldur	q2, [sp, #120]
	ldur	q16, [sp, #104]
	ldur	q4, [sp, #152]
	ldur	q3, [sp, #136]
	add	x9, sp, #40
	add	x9, x9, #224
	mov	w10, #4                         ; =0x4
LBB1_11:                                ; %direct.true211
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q17, q18, [x9, #-96]
	fadd.4s	v1, v1, v18
	fadd.4s	v7, v7, v17
	ldp	q17, q18, [x9, #-64]
	fadd.4s	v6, v6, v18
	fadd.4s	v5, v5, v17
	ldp	q17, q18, [x9, #-32]
	fadd.4s	v2, v2, v18
	fadd.4s	v16, v16, v17
	ldp	q17, q18, [x9], #128
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v17
	cmp	x10, #188
	add	x10, x10, #4
	b.lo	LBB1_11
; %bb.12:                               ; %direct.false212
	mov	x9, #0                          ; =0x0
	fadd.4s	v17, v0, v7
	mov.d	v17[1], v7[1]
	fadd.4s	v1, v6, v1
	fadd.4s	v5, v5, v17
	fadd.4s	v5, v16, v5
	fadd.4s	v1, v2, v1
	fadd.4s	v1, v4, v1
	fadd.4s	v2, v3, v5
	rev64.4s	v3, v2
	rev64.4s	v4, v1
	fadd.4s	v2, v2, v3
	dup.4s	v3, v2[2]
	fadd.4s	v1, v1, v4
	dup.4s	v4, v1[2]
	fadd.4s	v1, v1, v4
	fadd.4s	v2, v2, v3
	fadd.4s	v1, v2, v1
	movi.2d	v2, #0000000000000000
	fadd	s1, s1, s2
	dup.4s	v1, v1[0]
	add	x10, x19, x20
	add	x11, sp, #40
LBB1_13:                                ; %direct.true248
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x12, x9, #5
	add	x13, x11, x12
	ldp	q3, q2, [x13]
	fdiv.4s	v3, v3, v1
	fdiv.4s	v2, v2, v1
	add	x12, x10, x12
	stp	q3, q2, [x12]
	add	x9, x9, #1
	cmp	x9, #192
	b.ne	LBB1_13
; %bb.14:                               ; %direct.false249
	dup.2s	v1, v1[0]
	fdiv.2s	v0, v0, v1
	str	d0, [x19, x8]
	add	sp, sp, #7, lsl #12             ; =28672
	add	sp, sp, #3792
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #144            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh52, Lloh53
	.loh AdrpAdrp	Lloh50, Lloh52
	.loh AdrpLdr	Lloh50, Lloh51
	.loh AdrpAdrp	Lloh48, Lloh50
	.loh AdrpLdr	Lloh48, Lloh49
	.loh AdrpAdrp	Lloh46, Lloh48
	.loh AdrpLdr	Lloh46, Lloh47
	.loh AdrpLdr	Lloh62, Lloh63
	.loh AdrpLdr	Lloh60, Lloh61
	.loh AdrpAdrp	Lloh58, Lloh60
	.loh AdrpLdr	Lloh58, Lloh59
	.loh AdrpAdrp	Lloh56, Lloh58
	.loh AdrpLdr	Lloh56, Lloh57
	.loh AdrpLdr	Lloh54, Lloh55
	.loh AdrpLdr	Lloh66, Lloh67
	.loh AdrpLdr	Lloh64, Lloh65
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB2_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB2_4
LBB2_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB2_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB2_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB2_13
LBB2_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB2_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB2_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #1
	b.eq	LBB2_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #2
	b.eq	LBB2_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #3
	b.eq	LBB2_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB2_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB2_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
LBB2_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB2_3
LBB2_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB2_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	dup.4s	v1, w2
Lloh0:
	adrp	x8, lCPI0_1@PAGE
Lloh1:
	ldr	q3, [x8, lCPI0_1@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_2@PAGE
Lloh3:
	ldr	q4, [x8, lCPI0_2@PAGEOFF]
	cmhi.4s	v0, v1, v4
	cmhi.4s	v1, v1, v3
	uzp1.8h	v5, v1, v0
	umaxv.8h	h2, v5
	fmov	w8, s2
	tbz	w8, #0, LBB0_58
; %bb.1:                                ; %direct.activate
	stp	x28, x27, [sp, #-16]!           ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #2432
	mov	x13, #0                         ; =0x0
	add	x11, sp, #144
	ldr	x12, [x0, #16]
	ldr	x8, [x0, #48]
Lloh4:
	adrp	x9, lCPI0_0@PAGE
Lloh5:
	ldr	q2, [x9, lCPI0_0@PAGEOFF]
	and.16b	v2, v5, v2
	addv.8h	h2, v2
	fmov	w9, s2
	and	w10, w9, #0xff
	ldr	x14, [x0]
	ldr	w9, [x1]
	ldr	w15, [x1, #36]
	add	w9, w15, w9, lsl #5
	lsr	w9, w9, #3
	fmov	s6, w9
	and.16b	v6, v1, v6
	fmov	w15, s6
	mov	w16, #3072                      ; =0xc00
	umull	x9, w15, w16
	umaddl	x14, w15, w16, x14
	fmov	w15, s2
	add	x16, sp, #3456
	b	LBB0_3
LBB0_2:                                 ; %else45
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x16, x13
	stp	q6, q7, [x17]
	add	x13, x13, #32
	cmp	x13, #3072
	b.eq	LBB0_19
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	add	x17, x14, x13
	add	x1, x16, x13
	ldr	q6, [x1]
	tbnz	w15, #0, LBB0_11
; %bb.4:                                ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w0, w15, #0xff
	tbnz	w0, #1, LBB0_12
LBB0_5:                                 ; %else27
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w0, #2, LBB0_13
LBB0_6:                                 ; %else30
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w0, #3, LBB0_14
LBB0_7:                                 ; %else33
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q7, [x1, #16]
	tbnz	w0, #4, LBB0_15
LBB0_8:                                 ; %else36
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w0, #5, LBB0_16
LBB0_9:                                 ; %else39
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w0, #6, LBB0_17
LBB0_10:                                ; %else42
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w0, #7, LBB0_2
	b	LBB0_18
LBB0_11:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	ld1.s	{ v6 }[0], [x17]
	and	w0, w15, #0xff
	tbz	w0, #1, LBB0_5
LBB0_12:                                ; %cond.load26
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x2, x17, #4
	ld1.s	{ v6 }[1], [x2]
	tbz	w0, #2, LBB0_6
LBB0_13:                                ; %cond.load29
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x2, x17, #8
	ld1.s	{ v6 }[2], [x2]
	tbz	w0, #3, LBB0_7
LBB0_14:                                ; %cond.load32
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x2, x17, #12
	ld1.s	{ v6 }[3], [x2]
	ldr	q7, [x1, #16]
	tbz	w0, #4, LBB0_8
LBB0_15:                                ; %cond.load35
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x17, #16
	ld1.s	{ v7 }[0], [x1]
	tbz	w0, #5, LBB0_9
LBB0_16:                                ; %cond.load38
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x17, #20
	ld1.s	{ v7 }[1], [x1]
	tbz	w0, #6, LBB0_10
LBB0_17:                                ; %cond.load41
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x17, #24
	ld1.s	{ v7 }[2], [x1]
	tbz	w0, #7, LBB0_2
LBB0_18:                                ; %cond.load44
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x17, #28
	ld1.s	{ v7 }[3], [x17]
	b	LBB0_2
LBB0_19:                                ; %direct.false
	ldr	q6, [x11, #3328]
	ldr	q7, [x11, #3312]
	fmul.4s	v16, v7, v7
	fmul.4s	v6, v6, v6
	ldr	q7, [x11, #3360]
	ldr	q17, [x11, #3344]
	fmul.4s	v17, v17, v17
	fmul.4s	v18, v7, v7
	ldr	q7, [x11, #3392]
	ldr	q19, [x11, #3376]
	fmul.4s	v21, v19, v19
	fmul.4s	v22, v7, v7
	ldr	q7, [x11, #3424]
	ldr	q19, [x11, #3408]
	fmul.4s	v23, v19, v19
	fmul.4s	v24, v7, v7
	and.16b	v7, v0, v6
	and.16b	v6, v1, v16
	and.16b	v20, v0, v18
	and.16b	v19, v1, v17
	and.16b	v16, v0, v22
	and.16b	v21, v1, v21
	and.16b	v18, v0, v24
	and.16b	v17, v1, v23
	add	x13, sp, #3456
	add	x13, x13, #224
	mov	w14, #4                         ; =0x4
LBB0_20:                                ; %direct.true46
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q23, q22, [x13, #-96]
	and.16b	v23, v1, v23
	and.16b	v22, v0, v22
	fmul.4s	v22, v22, v22
	fmul.4s	v23, v23, v23
	fadd.4s	v23, v6, v23
	fadd.4s	v22, v7, v22
	ldp	q25, q24, [x13, #-64]
	and.16b	v25, v1, v25
	and.16b	v24, v0, v24
	fmul.4s	v24, v24, v24
	fmul.4s	v25, v25, v25
	fadd.4s	v25, v19, v25
	fadd.4s	v24, v20, v24
	ldp	q27, q26, [x13, #-32]
	and.16b	v27, v1, v27
	and.16b	v26, v0, v26
	fmul.4s	v26, v26, v26
	fmul.4s	v27, v27, v27
	fadd.4s	v27, v21, v27
	fadd.4s	v26, v16, v26
	ldp	q29, q28, [x13], #128
	and.16b	v29, v1, v29
	and.16b	v28, v0, v28
	fmul.4s	v28, v28, v28
	fmul.4s	v29, v29, v29
	fadd.4s	v29, v17, v29
	fadd.4s	v28, v18, v28
	bit.16b	v7, v22, v0
	bit.16b	v6, v23, v1
	bit.16b	v20, v24, v0
	bit.16b	v19, v25, v1
	bit.16b	v16, v26, v0
	bit.16b	v21, v27, v1
	bit.16b	v18, v28, v0
	bit.16b	v17, v29, v1
	cmp	x14, #92
	add	x14, x14, #4
	b.lo	LBB0_20
; %bb.21:                               ; %direct.true83.preheader
	mov	x13, #0                         ; =0x0
	fmov	w14, s2
	add	x15, sp, #384
	b	LBB0_23
LBB0_22:                                ; %else70
                                        ;   in Loop: Header=BB0_23 Depth=1
	add	x16, x15, x13
	stp	q22, q23, [x16]
	add	x13, x13, #32
	cmp	x13, #3072
	b.eq	LBB0_39
LBB0_23:                                ; %direct.true83
                                        ; =>This Inner Loop Header: Depth=1
	add	x16, x12, x13
	add	x0, x15, x13
	ldr	q22, [x0]
	tbnz	w14, #0, LBB0_31
; %bb.24:                               ; %else49
                                        ;   in Loop: Header=BB0_23 Depth=1
	and	w17, w14, #0xff
	tbnz	w17, #1, LBB0_32
LBB0_25:                                ; %else52
                                        ;   in Loop: Header=BB0_23 Depth=1
	tbnz	w17, #2, LBB0_33
LBB0_26:                                ; %else55
                                        ;   in Loop: Header=BB0_23 Depth=1
	tbnz	w17, #3, LBB0_34
LBB0_27:                                ; %else58
                                        ;   in Loop: Header=BB0_23 Depth=1
	ldr	q23, [x0, #16]
	tbnz	w17, #4, LBB0_35
LBB0_28:                                ; %else61
                                        ;   in Loop: Header=BB0_23 Depth=1
	tbnz	w17, #5, LBB0_36
LBB0_29:                                ; %else64
                                        ;   in Loop: Header=BB0_23 Depth=1
	tbnz	w17, #6, LBB0_37
LBB0_30:                                ; %else67
                                        ;   in Loop: Header=BB0_23 Depth=1
	tbz	w17, #7, LBB0_22
	b	LBB0_38
LBB0_31:                                ; %cond.load48
                                        ;   in Loop: Header=BB0_23 Depth=1
	ld1.s	{ v22 }[0], [x16]
	and	w17, w14, #0xff
	tbz	w17, #1, LBB0_25
LBB0_32:                                ; %cond.load51
                                        ;   in Loop: Header=BB0_23 Depth=1
	add	x1, x16, #4
	ld1.s	{ v22 }[1], [x1]
	tbz	w17, #2, LBB0_26
LBB0_33:                                ; %cond.load54
                                        ;   in Loop: Header=BB0_23 Depth=1
	add	x1, x16, #8
	ld1.s	{ v22 }[2], [x1]
	tbz	w17, #3, LBB0_27
LBB0_34:                                ; %cond.load57
                                        ;   in Loop: Header=BB0_23 Depth=1
	add	x1, x16, #12
	ld1.s	{ v22 }[3], [x1]
	ldr	q23, [x0, #16]
	tbz	w17, #4, LBB0_28
LBB0_35:                                ; %cond.load60
                                        ;   in Loop: Header=BB0_23 Depth=1
	add	x0, x16, #16
	ld1.s	{ v23 }[0], [x0]
	tbz	w17, #5, LBB0_29
LBB0_36:                                ; %cond.load63
                                        ;   in Loop: Header=BB0_23 Depth=1
	add	x0, x16, #20
	ld1.s	{ v23 }[1], [x0]
	tbz	w17, #6, LBB0_30
LBB0_37:                                ; %cond.load66
                                        ;   in Loop: Header=BB0_23 Depth=1
	add	x0, x16, #24
	ld1.s	{ v23 }[2], [x0]
	tbz	w17, #7, LBB0_22
LBB0_38:                                ; %cond.load69
                                        ;   in Loop: Header=BB0_23 Depth=1
	add	x16, x16, #28
	ld1.s	{ v23 }[3], [x16]
	b	LBB0_22
LBB0_39:                                ; %direct.false84
	mov	x12, #0                         ; =0x0
	xtn.8b	v22, v5
	fadd.4s	v5, v7, v20
	fadd.4s	v6, v6, v19
	fadd.4s	v6, v6, v21
	fadd.4s	v5, v5, v16
	fadd.4s	v5, v5, v18
	fadd.4s	v6, v6, v17
	and.16b	v3, v1, v3
	and.16b	v4, v0, v4
	movi.4s	v7, #1
	eor.16b	v16, v4, v7
	eor.16b	v19, v3, v7
	umov.b	w14, v22[0]
	str	q6, [x11, #192]
	ldr	s7, [x11, #196]
	umov.b	w13, v22[1]
	ands	w15, w14, #0x1
	tst	w15, w13
	movi.2d	v3, #0000000000000000
	fcsel	s7, s7, s3, ne
	mov.s	w16, v19[1]
	add	x17, sp, #8
	add	x0, sp, #8
	bfxil	x0, x16, #0, #3
	str	d22, [sp, #8]
	ldrb	w0, [x0]
	add	x1, sp, #304
	orr	x16, x1, x16, lsl #2
	stp	q6, q5, [x11, #160]
	ldr	s17, [x16]
	ands	w16, w13, #0x1
	tst	w16, w0
	mov.s	w16, v19[2]
	fcsel	s17, s17, s3, ne
	add	x0, sp, #8
	bfxil	x0, x16, #0, #3
	ldrb	w0, [x0]
	add	x1, sp, #272
	orr	x1, x1, x16, lsl #2
	umov.b	w16, v22[2]
	stp	q6, q5, [x11, #128]
	ldr	s18, [x1]
	ands	w1, w16, #0x1
	tst	w1, w0
	fcsel	s18, s18, s3, ne
	mov.s	w0, v19[3]
	add	x1, sp, #8
	bfxil	x1, x0, #0, #3
	ldrb	w1, [x1]
	add	x2, sp, #240
	orr	x2, x2, x0, lsl #2
	umov.b	w0, v22[3]
	stp	q6, q5, [x11, #96]
	ldr	s19, [x2]
	ands	w2, w0, #0x1
	tst	w2, w1
	fcsel	s19, s19, s3, ne
	fmov	w2, s16
	add	x1, sp, #8
	bfxil	x1, x2, #0, #3
	ldrb	w3, [x1]
	umov.b	w1, v22[4]
	and	w3, w1, w3
	stp	q6, q5, [x11, #64]
	add	x4, sp, #208
	ldr	s20, [x4, w2, uxtw #2]
	tst	w3, #0x1
	mov.s	w3, v16[1]
	add	x4, sp, #8
	bfxil	x4, x3, #0, #3
	umov.b	w2, v22[5]
	ldrb	w4, [x4]
	stp	q6, q5, [x11, #32]
	add	x5, sp, #176
	ldr	s21, [x5, w3, uxtw #2]
	fcsel	s20, s20, s3, ne
	ands	w3, w2, #0x1
	tst	w3, w4
	fcsel	s21, s21, s3, ne
	mov.s	w4, v16[2]
	add	x3, sp, #8
	bfxil	x3, x4, #0, #3
	ldrb	w5, [x3]
	umov.b	w3, v22[6]
	stp	q6, q5, [x11]
	add	x11, sp, #144
	ldr	s23, [x11, w4, uxtw #2]
	ands	w11, w3, #0x1
	tst	w11, w5
	mov.s	w11, v16[3]
	add	x4, sp, #8
	bfxil	x4, x11, #0, #3
	ldrb	w4, [x4]
	stp	q6, q5, [sp, #112]
	add	x5, sp, #112
	ldr	s16, [x5, w11, uxtw #2]
	umov.b	w11, v22[7]
	fcsel	s22, s23, s3, ne
	ands	w5, w11, #0x1
	tst	w5, w4
	fcsel	s16, s16, s3, ne
	mov.s	v7[1], v17[0]
	mov.s	v7[2], v18[0]
	mov.s	v7[3], v19[0]
	mov.s	v20[1], v21[0]
	mov.s	v20[2], v22[0]
	mov.s	v20[3], v16[0]
	fadd.4s	v5, v5, v20
	fadd.4s	v6, v6, v7
	movi.4s	v7, #2
	eor.16b	v4, v4, v7
	str	q6, [sp, #80]
	ldr	s7, [sp, #88]
	tst	w15, w16
	fcsel	s7, s7, s3, ne
	fmov	w4, s4
	bfxil	x17, x4, #0, #3
	ldrb	w17, [x17]
	and	w17, w1, w17
	stp	q6, q5, [sp, #48]
	add	x5, sp, #48
	ldr	s4, [x5, w4, uxtw #2]
	tst	w17, #0x1
	fcsel	s4, s4, s3, ne
	fadd.4s	v4, v5, v4
	tst	w15, w1
	fcsel	s4, s4, s3, ne
	ands	w14, w14, #0x1
	fadd.4s	v5, v6, v7
	fadd	s4, s5, s4
	fcsel	s5, s4, s3, ne
	tst	w13, #0x1
	fcsel	s6, s5, s3, ne
	tst	w16, #0x1
	fcsel	s7, s5, s3, ne
	tst	w0, #0x1
	fcsel	s16, s5, s3, ne
	tst	w14, w1
	fcsel	s4, s4, s3, ne
	tst	w2, #0x1
	fcsel	s17, s5, s3, ne
	tst	w3, #0x1
	fcsel	s18, s5, s3, ne
	tst	w11, #0x1
	fcsel	s19, s5, s3, ne
	mov.s	v5[1], v6[0]
	mov.s	v5[2], v7[0]
	mov.s	v5[3], v16[0]
	mov.s	v4[1], v17[0]
	mov.s	v4[2], v18[0]
	mov.s	v4[3], v19[0]
	rbit	w10, w10
	clz	w10, w10
	stp	q5, q4, [sp, #16]
	and	x10, x10, #0x7
	add	x11, sp, #16
	ldr	s4, [x11, x10, lsl #2]
	fadd	s3, s4, s3
	mov	w10, #1145044992                ; =0x44400000
	fmov	s4, w10
	fdiv	s3, s3, s4
	mov	w10, #50604                     ; =0xc5ac
	movk	w10, #14119, lsl #16
	fmov	s4, w10
	fadd	s3, s3, s4
	fsqrt	s3, s3
	dup.4s	v3, v3[0]
	add	x8, x8, x9
	fmov	w9, s2
	add	x10, sp, #3456
	add	x11, sp, #384
	b	LBB0_41
LBB0_40:                                ; %else87
                                        ;   in Loop: Header=BB0_41 Depth=1
	add	x12, x12, #32
	cmp	x12, #3072
	b.eq	LBB0_57
LBB0_41:                                ; %direct.true103
                                        ; =>This Inner Loop Header: Depth=1
	add	x15, x10, x12
	ldr	q2, [x15]
	and.16b	v2, v1, v2
	fdiv.4s	v2, v2, v3
	add	x16, x11, x12
	ldr	q4, [x16]
	and.16b	v4, v1, v4
	fmul.4s	v2, v2, v4
	add	x13, x8, x12
	tbnz	w9, #0, LBB0_50
; %bb.42:                               ; %else73
                                        ;   in Loop: Header=BB0_41 Depth=1
	and	w14, w9, #0xff
	tbnz	w14, #1, LBB0_51
LBB0_43:                                ; %else75
                                        ;   in Loop: Header=BB0_41 Depth=1
	tbnz	w14, #2, LBB0_52
LBB0_44:                                ; %else77
                                        ;   in Loop: Header=BB0_41 Depth=1
	tbz	w14, #3, LBB0_46
LBB0_45:                                ; %cond.store78
                                        ;   in Loop: Header=BB0_41 Depth=1
	add	x17, x13, #12
	st1.s	{ v2 }[3], [x17]
LBB0_46:                                ; %else79
                                        ;   in Loop: Header=BB0_41 Depth=1
	ldr	q2, [x15, #16]
	and.16b	v2, v0, v2
	fdiv.4s	v2, v2, v3
	ldr	q4, [x16, #16]
	and.16b	v4, v0, v4
	fmul.4s	v2, v2, v4
	tbnz	w14, #4, LBB0_53
; %bb.47:                               ; %else81
                                        ;   in Loop: Header=BB0_41 Depth=1
	tbnz	w14, #5, LBB0_54
LBB0_48:                                ; %else83
                                        ;   in Loop: Header=BB0_41 Depth=1
	tbnz	w14, #6, LBB0_55
LBB0_49:                                ; %else85
                                        ;   in Loop: Header=BB0_41 Depth=1
	tbz	w14, #7, LBB0_40
	b	LBB0_56
LBB0_50:                                ; %cond.store
                                        ;   in Loop: Header=BB0_41 Depth=1
	str	s2, [x13]
	and	w14, w9, #0xff
	tbz	w14, #1, LBB0_43
LBB0_51:                                ; %cond.store74
                                        ;   in Loop: Header=BB0_41 Depth=1
	add	x17, x13, #4
	st1.s	{ v2 }[1], [x17]
	tbz	w14, #2, LBB0_44
LBB0_52:                                ; %cond.store76
                                        ;   in Loop: Header=BB0_41 Depth=1
	add	x17, x13, #8
	st1.s	{ v2 }[2], [x17]
	tbnz	w14, #3, LBB0_45
	b	LBB0_46
LBB0_53:                                ; %cond.store80
                                        ;   in Loop: Header=BB0_41 Depth=1
	str	s2, [x13, #16]
	tbz	w14, #5, LBB0_48
LBB0_54:                                ; %cond.store82
                                        ;   in Loop: Header=BB0_41 Depth=1
	add	x15, x13, #20
	st1.s	{ v2 }[1], [x15]
	tbz	w14, #6, LBB0_49
LBB0_55:                                ; %cond.store84
                                        ;   in Loop: Header=BB0_41 Depth=1
	add	x15, x13, #24
	st1.s	{ v2 }[2], [x15]
	tbz	w14, #7, LBB0_40
LBB0_56:                                ; %cond.store86
                                        ;   in Loop: Header=BB0_41 Depth=1
	add	x13, x13, #28
	st1.s	{ v2 }[3], [x13]
	b	LBB0_40
LBB0_57:
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #2432
	ldp	x28, x27, [sp], #16             ; 16-byte Folded Reload
LBB0_58:                                ; %common.ret
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d9, d8, [sp, #-112]!            ; 16-byte Folded Spill
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #2272
	str	x0, [sp, #72]                   ; 8-byte Spill
	cbz	w3, LBB1_31
; %bb.1:                                ; %block.batch.loop.preheader
	mov	x20, x3
	mov	x21, x2
	mov	w23, #0                         ; =0x0
	ldp	w24, w27, [x2, #44]
	add	x26, sp, #3296
	mov	w15, #32                        ; =0x20
	ldp	w11, w12, [x2]
	add	x25, sp, #224
	movi.2d	v8, #0000000000000000
	ldp	w13, w8, [x2, #8]
	str	x8, [sp, #64]                   ; 8-byte Spill
	str	w3, [sp, #28]                   ; 4-byte Spill
	str	x2, [sp, #16]                   ; 8-byte Spill
	stp	w27, w24, [sp, #8]              ; 8-byte Folded Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x21, #36]
	ldr	w20, [sp, #28]                  ; 4-byte Reload
	ldr	w23, [sp, #48]                  ; 4-byte Reload
	ldp	w27, w24, [sp, #8]              ; 8-byte Folded Reload
	mov	w15, #32                        ; =0x20
	ldr	x11, [sp, #88]                  ; 8-byte Reload
	ldp	w13, w9, [sp, #80]              ; 8-byte Folded Reload
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w11, #1
	cmp	w8, w24
	cset	w8, eq
	csinc	w11, wzr, w11, eq
	cinc	w9, w9, eq
	cmp	w9, w27
	cset	w10, eq
	ands	w8, w8, w10
	csel	w12, wzr, w9, ne
	add	w13, w13, w8
	add	w23, w23, #1
	cmp	w23, w20
	b.eq	LBB1_31
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_24 Depth 2
                                        ;       Child Loop BB1_25 Depth 3
                                        ;       Child Loop BB1_27 Depth 3
                                        ;     Child Loop BB1_6 Depth 2
                                        ;     Child Loop BB1_8 Depth 2
                                        ;     Child Loop BB1_10 Depth 2
                                        ;     Child Loop BB1_12 Depth 2
                                        ;     Child Loop BB1_14 Depth 2
                                        ;     Child Loop BB1_16 Depth 2
                                        ;     Child Loop BB1_18 Depth 2
                                        ;     Child Loop BB1_20 Depth 2
	ubfiz	x8, x11, #5, #32
	ldr	x14, [sp, #64]                  ; 8-byte Reload
	cmp	x8, x14
	csel	x9, x8, xzr, ls
	subs	x10, x14, x9
	cmp	x10, #32
	csel	x10, x10, x15, lo
	cmp	x14, x9
	stp	w11, w12, [x21]
	str	w13, [x21, #8]
	ccmp	x8, x14, #2, hi
	csel	x8, x10, xzr, ls
	cmp	x8, #32
	str	x11, [sp, #88]                  ; 8-byte Spill
	stp	w13, w12, [sp, #80]             ; 8-byte Folded Spill
	b.lo	LBB1_22
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Reload
	ldr	x10, [x8]
	ldr	x9, [x8, #16]
	str	x9, [sp, #192]                  ; 8-byte Spill
	ldr	x8, [x8, #48]
	str	x8, [sp, #208]                  ; 8-byte Spill
	ubfiz	w22, w11, #2, #27
	mov	w8, #3072                       ; =0xc00
	umull	x19, w22, w8
	mov	x28, x10
	umaddl	x1, w22, w8, x10
	add	x0, sp, #3296
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	ldr	q0, [sp, #3296]
	ldr	q1, [sp, #3312]
	fmul.4s	v2, v1, v1
	fmul.4s	v3, v0, v0
	ldr	q0, [sp, #3328]
	ldr	q1, [sp, #3344]
	fmul.4s	v4, v1, v1
	fmul.4s	v5, v0, v0
	ldr	q0, [sp, #3360]
	ldr	q1, [sp, #3376]
	fmul.4s	v7, v1, v1
	fmul.4s	v6, v0, v0
	ldr	q0, [sp, #3392]
	ldr	q1, [sp, #3408]
	fmul.4s	v16, v1, v1
	fmul.4s	v17, v0, v0
	add	x8, x26, #224
	mov	w9, #4                          ; =0x4
LBB1_6:                                 ; %direct.true46.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q1, q0, [x8, #-96]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v2, v2, v0
	fadd.4s	v3, v3, v1
	ldp	q1, q0, [x8, #-64]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v4, v4, v0
	fadd.4s	v5, v5, v1
	ldp	q1, q0, [x8, #-32]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v7, v7, v0
	fadd.4s	v6, v6, v1
	ldp	q1, q0, [x8], #128
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v16, v16, v0
	fadd.4s	v17, v17, v1
	cmp	x9, #92
	add	x9, x9, #4
	b.lo	LBB1_6
; %bb.7:                                ; %direct.false47.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, sp, #224
	ldr	x1, [sp, #192]                  ; 8-byte Reload
	mov	w2, #3072                       ; =0xc00
	stp	q4, q2, [sp, #112]              ; 32-byte Folded Spill
	stp	q5, q3, [sp, #32]               ; 32-byte Folded Spill
	stp	q6, q16, [sp, #160]             ; 32-byte Folded Spill
	str	q7, [sp, #96]                   ; 16-byte Spill
	str	q17, [sp, #144]                 ; 16-byte Spill
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	ldp	q1, q0, [sp, #32]               ; 32-byte Folded Reload
	fadd.4s	v0, v0, v1
	ldp	q2, q1, [sp, #112]              ; 32-byte Folded Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #96]                   ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldp	q2, q3, [sp, #144]              ; 32-byte Folded Reload
	fadd.4s	v0, v0, v3
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #176]                  ; 16-byte Reload
	fadd.4s	v1, v1, v2
	rev64.4s	v2, v1
	rev64.4s	v3, v0
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	dup.4s	v2, v1[2]
	dup.4s	v3, v0[2]
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	fadd.4s	v0, v0, v1
	fadd	s0, s0, s8
	mov	w9, #1145044992                 ; =0x44400000
	fmov	s1, w9
	fdiv	s0, s0, s1
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s1, w9
	fadd	s0, s0, s1
	fsqrt	s0, s0
	dup.4s	v0, v0[0]
	ldr	x9, [sp, #208]                  ; 8-byte Reload
	add	x9, x9, x19
LBB1_8:                                 ; %direct.true103.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x26, x8
	ldp	q1, q2, [x10]
	fdiv.4s	v2, v2, v0
	fdiv.4s	v1, v1, v0
	add	x10, x25, x8
	ldp	q4, q3, [x10]
	fmul.4s	v1, v1, v4
	fmul.4s	v2, v2, v3
	add	x10, x9, x8
	stp	q1, q2, [x10]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB1_8
; %bb.9:                                ; %llm_rows.full_packet.exit.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	orr	w8, w22, #0x1
	mov	w9, #3072                       ; =0xc00
	umull	x19, w8, w9
	umaddl	x1, w8, w9, x28
	add	x0, sp, #3296
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	ldr	q0, [sp, #3296]
	ldr	q1, [sp, #3312]
	fmul.4s	v2, v1, v1
	fmul.4s	v3, v0, v0
	ldr	q0, [sp, #3328]
	ldr	q1, [sp, #3344]
	fmul.4s	v4, v1, v1
	fmul.4s	v5, v0, v0
	ldr	q0, [sp, #3360]
	ldr	q1, [sp, #3376]
	fmul.4s	v7, v1, v1
	fmul.4s	v6, v0, v0
	ldr	q0, [sp, #3392]
	ldr	q1, [sp, #3408]
	fmul.4s	v16, v1, v1
	fmul.4s	v17, v0, v0
	add	x8, x26, #224
	mov	w9, #4                          ; =0x4
LBB1_10:                                ; %direct.true46.i15.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q1, q0, [x8, #-96]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v2, v2, v0
	fadd.4s	v3, v3, v1
	ldp	q1, q0, [x8, #-64]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v4, v4, v0
	fadd.4s	v5, v5, v1
	ldp	q1, q0, [x8, #-32]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v7, v7, v0
	fadd.4s	v6, v6, v1
	ldp	q1, q0, [x8], #128
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v16, v16, v0
	fadd.4s	v17, v17, v1
	cmp	x9, #92
	add	x9, x9, #4
	b.lo	LBB1_10
; %bb.11:                               ; %direct.false47.i29.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, sp, #224
	ldr	x1, [sp, #192]                  ; 8-byte Reload
	mov	w2, #3072                       ; =0xc00
	stp	q4, q2, [sp, #112]              ; 32-byte Folded Spill
	stp	q5, q3, [sp, #32]               ; 32-byte Folded Spill
	stp	q6, q16, [sp, #160]             ; 32-byte Folded Spill
	str	q7, [sp, #96]                   ; 16-byte Spill
	str	q17, [sp, #144]                 ; 16-byte Spill
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	ldp	q1, q0, [sp, #32]               ; 32-byte Folded Reload
	fadd.4s	v0, v0, v1
	ldp	q2, q1, [sp, #112]              ; 32-byte Folded Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #96]                   ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldp	q2, q3, [sp, #144]              ; 32-byte Folded Reload
	fadd.4s	v0, v0, v3
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #176]                  ; 16-byte Reload
	fadd.4s	v1, v1, v2
	rev64.4s	v2, v1
	rev64.4s	v3, v0
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	dup.4s	v2, v1[2]
	dup.4s	v3, v0[2]
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	fadd.4s	v0, v0, v1
	fadd	s0, s0, s8
	mov	w9, #1145044992                 ; =0x44400000
	fmov	s1, w9
	fdiv	s0, s0, s1
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s1, w9
	fadd	s0, s0, s1
	fsqrt	s0, s0
	dup.4s	v0, v0[0]
	ldr	x9, [sp, #208]                  ; 8-byte Reload
	add	x9, x9, x19
LBB1_12:                                ; %direct.true103.i33.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x26, x8
	ldp	q1, q2, [x10]
	fdiv.4s	v2, v2, v0
	fdiv.4s	v1, v1, v0
	add	x10, x25, x8
	ldp	q4, q3, [x10]
	fmul.4s	v1, v1, v4
	fmul.4s	v2, v2, v3
	add	x10, x9, x8
	stp	q1, q2, [x10]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB1_12
; %bb.13:                               ; %llm_rows.full_packet.exit41.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	orr	w8, w22, #0x2
	mov	w9, #3072                       ; =0xc00
	umull	x19, w8, w9
	umaddl	x1, w8, w9, x28
	add	x0, sp, #3296
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	ldr	q0, [sp, #3296]
	ldr	q1, [sp, #3312]
	fmul.4s	v2, v1, v1
	fmul.4s	v3, v0, v0
	ldr	q0, [sp, #3328]
	ldr	q1, [sp, #3344]
	fmul.4s	v4, v1, v1
	fmul.4s	v5, v0, v0
	ldr	q0, [sp, #3360]
	ldr	q1, [sp, #3376]
	fmul.4s	v7, v1, v1
	fmul.4s	v6, v0, v0
	ldr	q0, [sp, #3392]
	ldr	q1, [sp, #3408]
	fmul.4s	v16, v1, v1
	fmul.4s	v17, v0, v0
	add	x8, x26, #224
	mov	w9, #4                          ; =0x4
LBB1_14:                                ; %direct.true46.i54.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q1, q0, [x8, #-96]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v2, v2, v0
	fadd.4s	v3, v3, v1
	ldp	q1, q0, [x8, #-64]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v4, v4, v0
	fadd.4s	v5, v5, v1
	ldp	q1, q0, [x8, #-32]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v7, v7, v0
	fadd.4s	v6, v6, v1
	ldp	q1, q0, [x8], #128
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v16, v16, v0
	fadd.4s	v17, v17, v1
	cmp	x9, #92
	add	x9, x9, #4
	b.lo	LBB1_14
; %bb.15:                               ; %direct.false47.i68.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, sp, #224
	ldr	x1, [sp, #192]                  ; 8-byte Reload
	mov	w2, #3072                       ; =0xc00
	stp	q4, q2, [sp, #112]              ; 32-byte Folded Spill
	stp	q5, q3, [sp, #32]               ; 32-byte Folded Spill
	stp	q6, q16, [sp, #160]             ; 32-byte Folded Spill
	str	q7, [sp, #96]                   ; 16-byte Spill
	str	q17, [sp, #144]                 ; 16-byte Spill
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	ldp	q1, q0, [sp, #32]               ; 32-byte Folded Reload
	fadd.4s	v0, v0, v1
	ldp	q2, q1, [sp, #112]              ; 32-byte Folded Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #96]                   ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldp	q2, q3, [sp, #144]              ; 32-byte Folded Reload
	fadd.4s	v0, v0, v3
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #176]                  ; 16-byte Reload
	fadd.4s	v1, v1, v2
	rev64.4s	v2, v1
	rev64.4s	v3, v0
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	dup.4s	v2, v1[2]
	dup.4s	v3, v0[2]
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	fadd.4s	v0, v0, v1
	fadd	s0, s0, s8
	mov	w9, #1145044992                 ; =0x44400000
	fmov	s1, w9
	fdiv	s0, s0, s1
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s1, w9
	fadd	s0, s0, s1
	fsqrt	s0, s0
	dup.4s	v0, v0[0]
	ldr	x9, [sp, #208]                  ; 8-byte Reload
	add	x9, x9, x19
LBB1_16:                                ; %direct.true103.i72.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x26, x8
	ldp	q1, q2, [x10]
	fdiv.4s	v2, v2, v0
	fdiv.4s	v1, v1, v0
	add	x10, x25, x8
	ldp	q4, q3, [x10]
	fmul.4s	v1, v1, v4
	fmul.4s	v2, v2, v3
	add	x10, x9, x8
	stp	q1, q2, [x10]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB1_16
; %bb.17:                               ; %llm_rows.full_packet.exit80.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x21, #36]
	orr	w8, w22, #0x3
	mov	w9, #3072                       ; =0xc00
	umull	x19, w8, w9
	umaddl	x1, w8, w9, x28
	add	x0, sp, #3296
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	ldr	q0, [sp, #3296]
	ldr	q1, [sp, #3312]
	fmul.4s	v2, v1, v1
	fmul.4s	v3, v0, v0
	ldr	q0, [sp, #3328]
	ldr	q1, [sp, #3344]
	fmul.4s	v4, v1, v1
	fmul.4s	v5, v0, v0
	ldr	q0, [sp, #3360]
	ldr	q1, [sp, #3376]
	fmul.4s	v7, v1, v1
	fmul.4s	v6, v0, v0
	ldr	q0, [sp, #3392]
	ldr	q1, [sp, #3408]
	fmul.4s	v16, v1, v1
	fmul.4s	v17, v0, v0
	add	x8, x26, #224
	mov	w9, #4                          ; =0x4
LBB1_18:                                ; %direct.true46.i93.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q1, q0, [x8, #-96]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v2, v2, v0
	fadd.4s	v3, v3, v1
	ldp	q1, q0, [x8, #-64]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v4, v4, v0
	fadd.4s	v5, v5, v1
	ldp	q1, q0, [x8, #-32]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v7, v7, v0
	fadd.4s	v6, v6, v1
	ldp	q1, q0, [x8], #128
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v16, v16, v0
	fadd.4s	v17, v17, v1
	cmp	x9, #92
	add	x9, x9, #4
	b.lo	LBB1_18
; %bb.19:                               ; %direct.false47.i107.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, sp, #224
	ldr	x1, [sp, #192]                  ; 8-byte Reload
	mov	w2, #3072                       ; =0xc00
	stp	q4, q2, [sp, #128]              ; 32-byte Folded Spill
	stp	q3, q7, [sp, #96]               ; 32-byte Folded Spill
	str	q5, [sp, #48]                   ; 16-byte Spill
	stp	q6, q16, [sp, #176]             ; 32-byte Folded Spill
	str	q17, [sp, #160]                 ; 16-byte Spill
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	ldr	q0, [sp, #96]                   ; 16-byte Reload
	ldr	q1, [sp, #48]                   ; 16-byte Reload
	fadd.4s	v0, v0, v1
	ldp	q2, q1, [sp, #128]              ; 32-byte Folded Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #112]                  ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldp	q2, q3, [sp, #160]              ; 32-byte Folded Reload
	fadd.4s	v0, v0, v3
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #192]                  ; 16-byte Reload
	fadd.4s	v1, v1, v2
	rev64.4s	v2, v1
	rev64.4s	v3, v0
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	dup.4s	v2, v1[2]
	dup.4s	v3, v0[2]
	ldr	x9, [sp, #208]                  ; 8-byte Reload
	add	x9, x9, x19
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	fadd.4s	v0, v0, v1
	fadd	s0, s0, s8
	mov	w10, #1145044992                ; =0x44400000
	fmov	s1, w10
	fdiv	s0, s0, s1
	mov	w10, #50604                     ; =0xc5ac
	movk	w10, #14119, lsl #16
	fmov	s1, w10
	fadd	s0, s0, s1
	fsqrt	s0, s0
	dup.4s	v0, v0[0]
LBB1_20:                                ; %direct.true103.i111.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x26, x8
	ldp	q1, q2, [x10]
	fdiv.4s	v2, v2, v0
	fdiv.4s	v1, v1, v0
	add	x10, x25, x8
	ldp	q4, q3, [x10]
	fmul.4s	v1, v1, v4
	fmul.4s	v2, v2, v3
	add	x10, x9, x8
	stp	q1, q2, [x10]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB1_20
; %bb.21:                               ; %llm_rows.full_packet.exit119.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x11, [sp, #88]                  ; 8-byte Reload
	ldp	w13, w9, [sp, #80]              ; 8-byte Folded Reload
	mov	w15, #32                        ; =0x20
	b	LBB1_3
LBB1_22:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	w23, [sp, #48]                  ; 4-byte Spill
	str	x8, [sp, #32]                   ; 8-byte Spill
	lsr	x19, x8, #3
	cbz	x19, LBB1_29
; %bb.23:                               ; %packet.batch.partial.full.loop.preheader.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w21, #0                         ; =0x0
	ldr	x8, [sp, #72]                   ; 8-byte Reload
	ldr	x23, [x8]
	ldr	x22, [x8, #16]
	ldr	x20, [x8, #48]
	ldr	x8, [sp, #88]                   ; 8-byte Reload
	lsl	w28, w8, #2
	mov	x27, x28
LBB1_24:                                ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB1_25 Depth 3
                                        ;       Child Loop BB1_27 Depth 3
	and	x8, x27, #0x1fffffff
	mov	w9, #3072                       ; =0xc00
	umaddl	x24, w8, w9, x20
	add	w8, w21, w28
	and	w8, w8, #0x1fffffff
	umaddl	x1, w8, w9, x23
	add	x0, sp, #3296
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	ldr	q0, [sp, #3296]
	ldr	q1, [sp, #3312]
	fmul.4s	v2, v1, v1
	fmul.4s	v3, v0, v0
	ldr	q0, [sp, #3328]
	ldr	q1, [sp, #3344]
	fmul.4s	v4, v1, v1
	fmul.4s	v5, v0, v0
	ldr	q0, [sp, #3360]
	ldr	q1, [sp, #3376]
	fmul.4s	v7, v1, v1
	fmul.4s	v6, v0, v0
	ldr	q0, [sp, #3392]
	ldr	q1, [sp, #3408]
	fmul.4s	v16, v1, v1
	fmul.4s	v17, v0, v0
	add	x8, x26, #224
	mov	w9, #4                          ; =0x4
LBB1_25:                                ; %direct.true46.i132.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_24 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q1, q0, [x8, #-96]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v2, v2, v0
	fadd.4s	v3, v3, v1
	ldp	q1, q0, [x8, #-64]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v4, v4, v0
	fadd.4s	v5, v5, v1
	ldp	q1, q0, [x8, #-32]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v7, v7, v0
	fadd.4s	v6, v6, v1
	ldp	q1, q0, [x8], #128
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v16, v16, v0
	fadd.4s	v17, v17, v1
	cmp	x9, #92
	add	x9, x9, #4
	b.lo	LBB1_25
; %bb.26:                               ; %direct.false47.i146.i
                                        ;   in Loop: Header=BB1_24 Depth=2
	add	x0, sp, #224
	mov	x1, x22
	mov	w2, #3072                       ; =0xc00
	stp	q4, q2, [sp, #144]              ; 32-byte Folded Spill
	stp	q5, q3, [sp, #96]               ; 32-byte Folded Spill
	stp	q6, q16, [sp, #192]             ; 32-byte Folded Spill
	str	q7, [sp, #128]                  ; 16-byte Spill
	str	q17, [sp, #176]                 ; 16-byte Spill
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	ldp	q1, q0, [sp, #96]               ; 32-byte Folded Reload
	fadd.4s	v0, v0, v1
	ldp	q2, q1, [sp, #144]              ; 32-byte Folded Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #128]                  ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldp	q2, q3, [sp, #176]              ; 32-byte Folded Reload
	fadd.4s	v0, v0, v3
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #208]                  ; 16-byte Reload
	fadd.4s	v1, v1, v2
	rev64.4s	v2, v1
	rev64.4s	v3, v0
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	dup.4s	v2, v1[2]
	dup.4s	v3, v0[2]
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	fadd.4s	v0, v0, v1
	fadd	s0, s0, s8
	mov	w9, #1145044992                 ; =0x44400000
	fmov	s1, w9
	fdiv	s0, s0, s1
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s1, w9
	fadd	s0, s0, s1
	fsqrt	s0, s0
	dup.4s	v0, v0[0]
LBB1_27:                                ; %direct.true103.i150.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_24 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x9, x26, x8
	ldp	q1, q2, [x9]
	fdiv.4s	v2, v2, v0
	fdiv.4s	v1, v1, v0
	add	x9, x25, x8
	ldp	q4, q3, [x9]
	fmul.4s	v1, v1, v4
	fmul.4s	v2, v2, v3
	add	x9, x24, x8
	stp	q1, q2, [x9]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB1_27
; %bb.28:                               ; %llm_rows.full_packet.exit158.i
                                        ;   in Loop: Header=BB1_24 Depth=2
	add	w21, w21, #1
	add	w27, w27, #1
	cmp	w21, w19
	b.ne	LBB1_24
LBB1_29:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x8, [sp, #32]                   ; 8-byte Reload
	and	w2, w8, #0x7
	ldr	x21, [sp, #16]                  ; 8-byte Reload
	cbz	w2, LBB1_2
; %bb.30:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w19, #3
	str	w8, [x21, #36]
	ldr	x0, [sp, #72]                   ; 8-byte Reload
	mov	x1, x21
	bl	_llm_rows
	b	LBB1_2
LBB1_31:                                ; %block.batch.exit
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #2272
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp], #112              ; 16-byte Folded Reload
	ret
                                        ; -- End function
.subsections_via_symbols

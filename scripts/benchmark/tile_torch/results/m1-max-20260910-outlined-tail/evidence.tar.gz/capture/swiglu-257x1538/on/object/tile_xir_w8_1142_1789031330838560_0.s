	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_3:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_4:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_5:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_6:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_8:
	.quad	6144                            ; 0x1800
	.quad	6148                            ; 0x1804
lCPI0_9:
	.quad	6160                            ; 0x1810
	.quad	6164                            ; 0x1814
lCPI0_10:
	.quad	6152                            ; 0x1808
	.quad	6156                            ; 0x180c
lCPI0_11:
	.quad	6168                            ; 0x1818
	.quad	6172                            ; 0x181c
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_7:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
lCPI0_12:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	dup.4s	v1, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q2, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q0, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v0, v1, v0
	cmhi.4s	v1, v1, v2
	uzp1.8h	v17, v1, v0
	umaxv.8h	h2, v17
	fmov	w8, s2
	tbz	w8, #0, LBB0_191
; %bb.1:                                ; %direct.activate
	stp	d15, d14, [sp, #-112]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	sub	sp, sp, #3, lsl #12             ; =12288
	sub	sp, sp, #592
	ldr	x12, [x0]
	ldr	x9, [x0, #16]
	ldr	x8, [x0, #48]
	sshll.2d	v5, v1, #0
	sshll.2d	v4, v0, #0
	sshll2.2d	v21, v1, #0
	sshll2.2d	v20, v0, #0
	ldr	w10, [x1]
	ldr	w11, [x1, #36]
	add	w10, w11, w10, lsl #5
Lloh4:
	adrp	x11, lCPI0_2@PAGE
Lloh5:
	ldr	q2, [x11, lCPI0_2@PAGEOFF]
	and.16b	v25, v20, v2
Lloh6:
	adrp	x11, lCPI0_3@PAGE
Lloh7:
	ldr	q3, [x11, lCPI0_3@PAGEOFF]
	and.16b	v3, v21, v3
Lloh8:
	adrp	x11, lCPI0_4@PAGE
Lloh9:
	ldr	q6, [x11, lCPI0_4@PAGEOFF]
	and.16b	v4, v4, v6
Lloh10:
	adrp	x11, lCPI0_5@PAGE
Lloh11:
	ldr	q6, [x11, lCPI0_5@PAGEOFF]
	and.16b	v2, v5, v6
	str	q2, [sp, #96]                   ; 16-byte Spill
	lsr	w10, w10, #3
	dup.4s	v5, w10
	and.16b	v6, v1, v5
	and.16b	v5, v0, v5
	ushll2.2d	v7, v5, #0
	ushll2.2d	v19, v6, #0
	ushll.2d	v22, v5, #0
	ushll.2d	v18, v6, #0
	subs	x10, x12, x8
	cset	w11, hs
	mov	w14, #8199                      ; =0x2007
	movk	w14, #24, lsl #16
	cmp	x10, x14
	csel	w10, wzr, w11, ls
	subs	x11, x8, x12
	cset	w13, hs
	cmp	x11, x14
	csel	w11, wzr, w13, ls
	orr	w15, w10, w11
	subs	x10, x9, x8
	cset	w11, hs
	cmp	x10, x14
	csel	w13, wzr, w11, ls
	subs	x10, x8, x9
	cset	w11, hs
	cmp	x10, x14
	csel	w14, wzr, w11, ls
	fmov	x10, d18
	mov	w11, #6152                      ; =0x1808
	umull	x16, w10, w11
	adrp	x17, lCPI0_6@PAGE
	adrp	x11, lCPI0_7@PAGE
	xtn.2s	v26, v7
	xtn.2s	v2, v22
	str	d2, [sp, #128]                  ; 8-byte Spill
	xtn.2s	v2, v19
	str	d2, [sp, #112]                  ; 8-byte Spill
	adrp	x10, lCPI0_12@PAGE
	cmp	w15, #1
	b.ne	LBB0_53
; %bb.2:                                ; %direct.activate
	orr	w13, w13, w14
	cbz	w13, LBB0_53
; %bb.3:                                ; %direct.true20.preheader
	str	d26, [sp, #80]                  ; 8-byte Spill
	str	q25, [sp, #144]                 ; 16-byte Spill
	mov	x13, #0                         ; =0x0
	add	x14, x8, x16
	add	x15, x9, x16
	add	x16, x12, x16
	ldr	q19, [x17, lCPI0_6@PAGEOFF]
	and.16b	v19, v17, v19
	addv.8h	h19, v19
	fmov	w17, s19
	mov	w0, #-1026555904                ; =0xc2d00000
	mov	w1, #1120403456                 ; =0x42c80000
	mov	w2, #43579                      ; =0xaa3b
	movk	w2, #16312, lsl #16
	movi.4s	v20, #75, lsl #24
	mvni.4s	v21, #128, lsl #24
	mov	w3, #29184                      ; =0x7200
	movk	w3, #48945, lsl #16
	mov	w4, #48782                      ; =0xbe8e
	movk	w4, #46527, lsl #16
	mov	w5, #11226                      ; =0x2bda
	movk	w5, #14672, lsl #16
	mov	w6, #38601                      ; =0x96c9
	movk	w6, #15030, lsl #16
	mov	w7, #34982                      ; =0x88a6
	movk	w7, #15368, lsl #16
	mov	w19, #43642                     ; =0xaa7a
	movk	w19, #15658, lsl #16
	mov	w20, #43691                     ; =0xaaab
	movk	w20, #15914, lsl #16
	movi.4s	v22, #63, lsl #24
	fmov.4s	v23, #1.00000000
	mvni.4s	v24, #127, msl #16
	fneg.4s	v24, v24
	mvni.4s	v25, #63, msl #16
	fneg.4s	v25, v25
	b	LBB0_5
LBB0_4:                                 ; %else69
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x13, x13, #1
	cmp	x13, #192
	b.eq	LBB0_151
LBB0_5:                                 ; %direct.true20
                                        ; =>This Inner Loop Header: Depth=1
	add	x21, x16, x13, lsl #5
	movi.2d	v27, #0000000000000000
	movi.2d	v26, #0000000000000000
	tbz	w17, #0, LBB0_21
; %bb.6:                                ; %cond.load
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	s27, [x21]
	and	w22, w17, #0xff
	tbnz	w22, #1, LBB0_22
LBB0_7:                                 ; %else9
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w22, #2, LBB0_23
LBB0_8:                                 ; %cond.load11
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x23, x21, #8
	ld1.s	{ v27 }[2], [x23]
	tbnz	w22, #3, LBB0_24
LBB0_9:                                 ; %else15
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w22, #4, LBB0_25
LBB0_10:                                ; %cond.load17
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x23, x21, #16
	ld1.s	{ v26 }[0], [x23]
	tbnz	w22, #5, LBB0_26
LBB0_11:                                ; %else21
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w22, #6, LBB0_27
LBB0_12:                                ; %cond.load23
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x23, x21, #24
	ld1.s	{ v26 }[2], [x23]
	tbnz	w22, #7, LBB0_28
LBB0_13:                                ; %else27
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	w22, s19
	add	x21, x15, x13, lsl #5
	movi.2d	v29, #0000000000000000
	movi.2d	v28, #0000000000000000
	tbz	w22, #0, LBB0_29
LBB0_14:                                ; %cond.load30
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	s29, [x21]
	and	w22, w22, #0xff
	tbnz	w22, #1, LBB0_30
LBB0_15:                                ; %else34
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w22, #2, LBB0_31
LBB0_16:                                ; %cond.load36
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x23, x21, #8
	ld1.s	{ v29 }[2], [x23]
	tbnz	w22, #3, LBB0_32
LBB0_17:                                ; %else40
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w22, #4, LBB0_33
LBB0_18:                                ; %cond.load42
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x23, x21, #16
	ld1.s	{ v28 }[0], [x23]
	tbnz	w22, #5, LBB0_34
LBB0_19:                                ; %else46
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w22, #6, LBB0_35
LBB0_20:                                ; %cond.load48
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x23, x21, #24
	ld1.s	{ v28 }[2], [x23]
	tbnz	w22, #7, LBB0_36
	b	LBB0_37
LBB0_21:                                ; %else
                                        ;   in Loop: Header=BB0_5 Depth=1
	and	w22, w17, #0xff
	tbz	w22, #1, LBB0_7
LBB0_22:                                ; %cond.load8
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x23, x21, #4
	ld1.s	{ v27 }[1], [x23]
	tbnz	w22, #2, LBB0_8
LBB0_23:                                ; %else12
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w22, #3, LBB0_9
LBB0_24:                                ; %cond.load14
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x23, x21, #12
	ld1.s	{ v27 }[3], [x23]
	tbnz	w22, #4, LBB0_10
LBB0_25:                                ; %else18
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w22, #5, LBB0_11
LBB0_26:                                ; %cond.load20
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x23, x21, #20
	ld1.s	{ v26 }[1], [x23]
	tbnz	w22, #6, LBB0_12
LBB0_27:                                ; %else24
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w22, #7, LBB0_13
LBB0_28:                                ; %cond.load26
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x21, x21, #28
	ld1.s	{ v26 }[3], [x21]
	fmov	w22, s19
	add	x21, x15, x13, lsl #5
	movi.2d	v29, #0000000000000000
	movi.2d	v28, #0000000000000000
	tbnz	w22, #0, LBB0_14
LBB0_29:                                ; %else31
                                        ;   in Loop: Header=BB0_5 Depth=1
	and	w22, w22, #0xff
	tbz	w22, #1, LBB0_15
LBB0_30:                                ; %cond.load33
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x23, x21, #4
	ld1.s	{ v29 }[1], [x23]
	tbnz	w22, #2, LBB0_16
LBB0_31:                                ; %else37
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w22, #3, LBB0_17
LBB0_32:                                ; %cond.load39
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x23, x21, #12
	ld1.s	{ v29 }[3], [x23]
	tbnz	w22, #4, LBB0_18
LBB0_33:                                ; %else43
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w22, #5, LBB0_19
LBB0_34:                                ; %cond.load45
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x23, x21, #20
	ld1.s	{ v28 }[1], [x23]
	tbnz	w22, #6, LBB0_20
LBB0_35:                                ; %else49
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w22, #7, LBB0_37
LBB0_36:                                ; %cond.load51
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x21, x21, #28
	ld1.s	{ v28 }[3], [x21]
LBB0_37:                                ; %else52
                                        ;   in Loop: Header=BB0_5 Depth=1
	fneg.4s	v31, v27
	dup.4s	v30, w0
	and.16b	v5, v1, v31
	fcmge.4s	v8, v5, v30
	dup.4s	v31, w1
	fcmge.4s	v9, v31, v5
	and.16b	v8, v8, v9
	and.16b	v10, v8, v5
	dup.4s	v8, w2
	fmul.4s	v9, v10, v8
	mov.16b	v11, v21
	bsl.16b	v11, v20, v9
	fadd.4s	v9, v9, v11
	fsub.4s	v9, v9, v11
	fcvtzs.4s	v6, v9
	scvtf.4s	v11, v6
	dup.4s	v9, w3
	fmul.4s	v12, v11, v9
	fadd.4s	v12, v10, v12
	dup.4s	v10, w4
	fmul.4s	v13, v11, v10
	dup.4s	v11, w5
	fadd.4s	v7, v12, v13
	fmul.4s	v13, v7, v11
	dup.4s	v12, w6
	fadd.4s	v13, v13, v12
	fmul.4s	v14, v7, v13
	dup.4s	v13, w7
	fadd.4s	v14, v14, v13
	fmul.4s	v15, v7, v14
	dup.4s	v14, w19
	fadd.4s	v15, v15, v14
	fmul.4s	v16, v7, v15
	dup.4s	v15, w20
	fadd.4s	v16, v16, v15
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v22
	fmul.4s	v2, v7, v7
	fmul.4s	v2, v2, v16
	fadd.4s	v2, v7, v2
	fadd.4s	v2, v2, v23
	sshr.4s	v7, v6, #1
	shl.4s	v16, v7, #23
	add.4s	v16, v16, v23
	fmul.4s	v2, v2, v16
	sub.4s	v6, v6, v7
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v23
	fmul.4s	v2, v2, v6
	fcmgt.4s	v6, v30, v5
	fcmgt.4s	v7, v5, v31
	fcmeq.4s	v5, v5, v5
	fadd.4s	v2, v2, v23
	bit.16b	v2, v23, v6
	bit.16b	v2, v24, v7
	bif.16b	v2, v25, v5
	fdiv.4s	v2, v27, v2
	fmov	w22, s19
	fmul.4s	v27, v29, v2
	add	x21, x14, x13, lsl #5
	tbz	w22, #0, LBB0_41
; %bb.38:                               ; %cond.store
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	s27, [x21]
	and	w22, w22, #0xff
	tbnz	w22, #1, LBB0_42
LBB0_39:                                ; %else57
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w22, #2, LBB0_43
LBB0_40:                                ; %cond.store58
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x23, x21, #8
	st1.s	{ v27 }[2], [x23]
	tbnz	w22, #3, LBB0_44
	b	LBB0_45
LBB0_41:                                ; %else55
                                        ;   in Loop: Header=BB0_5 Depth=1
	and	w22, w22, #0xff
	tbz	w22, #1, LBB0_39
LBB0_42:                                ; %cond.store56
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x23, x21, #4
	st1.s	{ v27 }[1], [x23]
	tbnz	w22, #2, LBB0_40
LBB0_43:                                ; %else59
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w22, #3, LBB0_45
LBB0_44:                                ; %cond.store60
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x23, x21, #12
	st1.s	{ v27 }[3], [x23]
LBB0_45:                                ; %else61
                                        ;   in Loop: Header=BB0_5 Depth=1
	fneg.4s	v2, v26
	and.16b	v2, v0, v2
	fcmge.4s	v5, v2, v30
	fcmge.4s	v6, v31, v2
	and.16b	v5, v5, v6
	and.16b	v5, v5, v2
	fmul.4s	v6, v5, v8
	mov.16b	v7, v21
	bsl.16b	v7, v20, v6
	fadd.4s	v6, v6, v7
	fsub.4s	v6, v6, v7
	fcvtzs.4s	v6, v6
	scvtf.4s	v7, v6
	fmul.4s	v16, v7, v9
	fadd.4s	v5, v5, v16
	fmul.4s	v7, v7, v10
	fadd.4s	v5, v5, v7
	fmul.4s	v7, v5, v11
	fadd.4s	v7, v7, v12
	fmul.4s	v7, v5, v7
	fadd.4s	v7, v7, v13
	fmul.4s	v7, v5, v7
	fadd.4s	v7, v7, v14
	fmul.4s	v7, v5, v7
	fadd.4s	v7, v7, v15
	fmul.4s	v7, v5, v7
	fadd.4s	v7, v7, v22
	fmul.4s	v16, v5, v5
	fmul.4s	v7, v16, v7
	fadd.4s	v5, v5, v7
	fadd.4s	v5, v5, v23
	sshr.4s	v7, v6, #1
	shl.4s	v16, v7, #23
	add.4s	v16, v16, v23
	fmul.4s	v5, v5, v16
	sub.4s	v6, v6, v7
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v23
	fmul.4s	v5, v5, v6
	fcmgt.4s	v6, v30, v2
	fcmgt.4s	v7, v2, v31
	fcmeq.4s	v2, v2, v2
	fadd.4s	v5, v5, v23
	bit.16b	v5, v23, v6
	bit.16b	v5, v24, v7
	bsl.16b	v2, v5, v25
	fdiv.4s	v2, v26, v2
	fmul.4s	v26, v28, v2
	tbz	w22, #4, LBB0_49
; %bb.46:                               ; %cond.store62
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	s26, [x21, #16]
	tbnz	w22, #5, LBB0_50
LBB0_47:                                ; %else65
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w22, #6, LBB0_51
LBB0_48:                                ; %cond.store66
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x23, x21, #24
	st1.s	{ v26 }[2], [x23]
	tbz	w22, #7, LBB0_4
	b	LBB0_52
LBB0_49:                                ; %else63
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w22, #5, LBB0_47
LBB0_50:                                ; %cond.store64
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x23, x21, #20
	st1.s	{ v26 }[1], [x23]
	tbnz	w22, #6, LBB0_48
LBB0_51:                                ; %else67
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w22, #7, LBB0_4
LBB0_52:                                ; %cond.store68
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x21, x21, #28
	st1.s	{ v26 }[3], [x21]
	b	LBB0_4
LBB0_53:                                ; %direct.schedule.8.preheader
	mov	x13, #0                         ; =0x0
	add	x14, x12, x16
	ldr	q19, [x17, lCPI0_6@PAGEOFF]
	and.16b	v19, v17, v19
	addv.8h	h19, v19
	fmov	w15, s19
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #2608
	b	LBB0_55
LBB0_54:                                ; %else160
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x17, x16, x13, lsl #5
	stp	q22, q23, [x17]
	add	x13, x13, #1
	cmp	x13, #192
	b.eq	LBB0_71
LBB0_55:                                ; %direct.true40
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x0, x13, #5
	add	x17, x14, x0
	add	x1, x16, x0
	ldr	q22, [x1]
	tbz	w15, #0, LBB0_63
; %bb.56:                               ; %cond.load138
                                        ;   in Loop: Header=BB0_55 Depth=1
	ld1.s	{ v22 }[0], [x17]
	and	w0, w15, #0xff
	tbnz	w0, #1, LBB0_64
LBB0_57:                                ; %else142
                                        ;   in Loop: Header=BB0_55 Depth=1
	tbz	w0, #2, LBB0_65
LBB0_58:                                ; %cond.load144
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x2, x17, #8
	ld1.s	{ v22 }[2], [x2]
	tbnz	w0, #3, LBB0_66
LBB0_59:                                ; %else148
                                        ;   in Loop: Header=BB0_55 Depth=1
	ldr	q23, [x1, #16]
	tbz	w0, #4, LBB0_67
LBB0_60:                                ; %cond.load150
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x1, x17, #16
	ld1.s	{ v23 }[0], [x1]
	tbnz	w0, #5, LBB0_68
LBB0_61:                                ; %else154
                                        ;   in Loop: Header=BB0_55 Depth=1
	tbz	w0, #6, LBB0_69
LBB0_62:                                ; %cond.load156
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x1, x17, #24
	ld1.s	{ v23 }[2], [x1]
	tbz	w0, #7, LBB0_54
	b	LBB0_70
LBB0_63:                                ; %else139
                                        ;   in Loop: Header=BB0_55 Depth=1
	and	w0, w15, #0xff
	tbz	w0, #1, LBB0_57
LBB0_64:                                ; %cond.load141
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x2, x17, #4
	ld1.s	{ v22 }[1], [x2]
	tbnz	w0, #2, LBB0_58
LBB0_65:                                ; %else145
                                        ;   in Loop: Header=BB0_55 Depth=1
	tbz	w0, #3, LBB0_59
LBB0_66:                                ; %cond.load147
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x2, x17, #12
	ld1.s	{ v22 }[3], [x2]
	ldr	q23, [x1, #16]
	tbnz	w0, #4, LBB0_60
LBB0_67:                                ; %else151
                                        ;   in Loop: Header=BB0_55 Depth=1
	tbz	w0, #5, LBB0_61
LBB0_68:                                ; %cond.load153
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x1, x17, #20
	ld1.s	{ v23 }[1], [x1]
	tbnz	w0, #6, LBB0_62
LBB0_69:                                ; %else157
                                        ;   in Loop: Header=BB0_55 Depth=1
	tbz	w0, #7, LBB0_54
LBB0_70:                                ; %cond.load159
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x17, x17, #28
	ld1.s	{ v23 }[3], [x17]
	b	LBB0_54
LBB0_71:                                ; %direct.false41
	xtn.8b	v2, v17
	sshll.2d	v24, v0, #0
	sshll.2d	v5, v1, #0
	movi	d6, #0x0000000000ffff
	and.8b	v17, v2, v6
	ldr	d6, [x11, lCPI0_7@PAGEOFF]
	and.8b	v2, v2, v6
	addv.8b	b2, v2
	fmov	w14, s2
	umaxv.8b	b2, v17
	fmov	w11, s2
	rbit	w13, w14
	clz	w13, w13
	tst	w11, #0x1
	csel	w11, w13, wzr, ne
	mov	w13, #1536                      ; =0x600
	dup.2d	v22, x13
	mov.d	x13, v18[1]
	mov	w15, #1538                      ; =0x602
	mul	x13, x13, x15
	fmov	x16, d18
	mul	x16, x16, x15
	fmov	d23, x16
	mov.d	v23[1], x13
	ldr	q2, [sp, #96]                   ; 16-byte Reload
	add.2d	v2, v2, v22
	add.2d	v6, v23, v2
	mov	b2, v17[0]
	mov.b	v2[4], v17[1]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v2, v2, #0
	str	q6, [sp, #144]                  ; 16-byte Spill
	and.16b	v2, v2, v6
	movi.2d	v6, #0000000000000000
	stp	q6, q6, [sp, #416]
	stp	q2, q6, [sp, #384]
	ubfiz	x17, x11, #3, #3
	add	x13, sp, #384
	ldr	x13, [x13, x17]
	sub	x13, x13, x11
	lsl	x13, x13, #2
	add	x16, x12, x13
	mov	w12, #6144                      ; =0x1800
	dup.2d	v2, x12
Lloh12:
	adrp	x12, lCPI0_8@PAGE
Lloh13:
	ldr	q6, [x12, lCPI0_8@PAGEOFF]
	bsl.16b	v5, v6, v2
Lloh14:
	adrp	x12, lCPI0_9@PAGE
Lloh15:
	ldr	q6, [x12, lCPI0_9@PAGEOFF]
	bif.16b	v6, v2, v24
Lloh16:
	adrp	x12, lCPI0_10@PAGE
Lloh17:
	ldr	q7, [x12, lCPI0_10@PAGEOFF]
	bif.16b	v7, v2, v21
Lloh18:
	adrp	x12, lCPI0_11@PAGE
Lloh19:
	ldr	q16, [x12, lCPI0_11@PAGEOFF]
	bit.16b	v2, v16, v20
	stp	q6, q2, [sp, #480]
	stp	q5, q7, [sp, #448]
	add	x12, sp, #448
	ldr	x12, [x12, x17]
	sub	x12, x12, w11, uxtw #2
	tst	w14, #0xff
	csel	x12, xzr, x12, eq
	add	x17, sp, #1, lsl #12            ; =4096
	add	x17, x17, #2608
	add	x17, x17, x12
	ldr	q5, [x17]
	tbz	w14, #0, LBB0_79
; %bb.72:                               ; %cond.load163
	ld1.s	{ v5 }[0], [x16]
	tbnz	w14, #1, LBB0_80
LBB0_73:                                ; %else167
	tbz	w14, #2, LBB0_81
LBB0_74:                                ; %cond.load169
	add	x0, x16, #8
	ld1.s	{ v5 }[2], [x0]
	tbnz	w14, #3, LBB0_82
LBB0_75:                                ; %else173
	ldr	q6, [x17, #16]
	tbz	w14, #4, LBB0_83
LBB0_76:                                ; %cond.load175
	add	x17, x16, #16
	ld1.s	{ v6 }[0], [x17]
	tbnz	w14, #5, LBB0_84
LBB0_77:                                ; %else179
	dup.2s	v16, w15
	tbz	w14, #6, LBB0_85
LBB0_78:                                ; %cond.load181
	add	x15, x16, #24
	ld1.s	{ v6 }[2], [x15]
	ldr	d2, [sp, #112]                  ; 8-byte Reload
	umlal.2d	v3, v2, v16
	ldr	d2, [sp, #128]                  ; 8-byte Reload
	umlal.2d	v4, v2, v16
	umlal.2d	v25, v26, v16
	tbnz	w14, #7, LBB0_86
	b	LBB0_87
LBB0_79:                                ; %else164
	tbz	w14, #1, LBB0_73
LBB0_80:                                ; %cond.load166
	add	x0, x16, #4
	ld1.s	{ v5 }[1], [x0]
	tbnz	w14, #2, LBB0_74
LBB0_81:                                ; %else170
	tbz	w14, #3, LBB0_75
LBB0_82:                                ; %cond.load172
	add	x0, x16, #12
	ld1.s	{ v5 }[3], [x0]
	ldr	q6, [x17, #16]
	tbnz	w14, #4, LBB0_76
LBB0_83:                                ; %else176
	tbz	w14, #5, LBB0_77
LBB0_84:                                ; %cond.load178
	add	x17, x16, #20
	ld1.s	{ v6 }[1], [x17]
	dup.2s	v16, w15
	tbnz	w14, #6, LBB0_78
LBB0_85:                                ; %else182
	ldr	d2, [sp, #112]                  ; 8-byte Reload
	umlal.2d	v3, v2, v16
	ldr	d2, [sp, #128]                  ; 8-byte Reload
	umlal.2d	v4, v2, v16
	umlal.2d	v25, v26, v16
	tbz	w14, #7, LBB0_87
LBB0_86:                                ; %cond.load184
	add	x14, x16, #28
	ld1.s	{ v6 }[3], [x14]
LBB0_87:                                ; %else185
	mov	x0, #0                          ; =0x0
	add.2d	v7, v3, v22
	add.2d	v2, v4, v22
	stp	q2, q7, [sp, #112]              ; 32-byte Folded Spill
	add.2d	v2, v25, v22
	str	q2, [sp, #96]                   ; 16-byte Spill
	add	x14, sp, #1, lsl #12            ; =4096
	add	x14, x14, #2608
	add	x14, x14, x12
	stp	q6, q5, [sp, #48]               ; 32-byte Folded Spill
	stp	q5, q6, [x14]
	fmov	x14, d23
	lsl	x14, x14, #2
	add	x15, x9, x14
	ushll2.2d	v2, v0, #0
	mov	w16, #1                         ; =0x1
	dup.2d	v3, x16
	and.16b	v5, v2, v3
	ushll2.2d	v2, v1, #0
	and.16b	v6, v2, v3
	ushll.2d	v2, v0, #0
	and.16b	v7, v2, v3
	ushll.2d	v2, v1, #0
	and.16b	v21, v2, v3
	movi.2d	v2, #0000000000000000
	fmov	w16, s19
	add	x17, sp, #528
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v16, #0000000000000000
	b	LBB0_89
LBB0_88:                                ; %else210
                                        ;   in Loop: Header=BB0_89 Depth=1
	add	x0, x17, x0
	stp	q22, q23, [x0]
	add.2d	v3, v3, v6
	add.2d	v4, v4, v7
	add.2d	v16, v16, v5
	add.2d	v2, v2, v21
	fmov	x0, d2
	cmp	x0, #192
	b.ge	LBB0_105
LBB0_89:                                ; %direct.true62
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x0, x0, #5
	add	x1, x15, x0
	add	x3, x17, x0
	ldr	q22, [x3]
	tbz	w16, #0, LBB0_97
; %bb.90:                               ; %cond.load188
                                        ;   in Loop: Header=BB0_89 Depth=1
	ld1.s	{ v22 }[0], [x1]
	and	w2, w16, #0xff
	tbnz	w2, #1, LBB0_98
LBB0_91:                                ; %else192
                                        ;   in Loop: Header=BB0_89 Depth=1
	tbz	w2, #2, LBB0_99
LBB0_92:                                ; %cond.load194
                                        ;   in Loop: Header=BB0_89 Depth=1
	add	x4, x1, #8
	ld1.s	{ v22 }[2], [x4]
	tbnz	w2, #3, LBB0_100
LBB0_93:                                ; %else198
                                        ;   in Loop: Header=BB0_89 Depth=1
	ldr	q23, [x3, #16]
	tbz	w2, #4, LBB0_101
LBB0_94:                                ; %cond.load200
                                        ;   in Loop: Header=BB0_89 Depth=1
	add	x3, x1, #16
	ld1.s	{ v23 }[0], [x3]
	tbnz	w2, #5, LBB0_102
LBB0_95:                                ; %else204
                                        ;   in Loop: Header=BB0_89 Depth=1
	tbz	w2, #6, LBB0_103
LBB0_96:                                ; %cond.load206
                                        ;   in Loop: Header=BB0_89 Depth=1
	add	x3, x1, #24
	ld1.s	{ v23 }[2], [x3]
	tbz	w2, #7, LBB0_88
	b	LBB0_104
LBB0_97:                                ; %else189
                                        ;   in Loop: Header=BB0_89 Depth=1
	and	w2, w16, #0xff
	tbz	w2, #1, LBB0_91
LBB0_98:                                ; %cond.load191
                                        ;   in Loop: Header=BB0_89 Depth=1
	add	x4, x1, #4
	ld1.s	{ v22 }[1], [x4]
	tbnz	w2, #2, LBB0_92
LBB0_99:                                ; %else195
                                        ;   in Loop: Header=BB0_89 Depth=1
	tbz	w2, #3, LBB0_93
LBB0_100:                               ; %cond.load197
                                        ;   in Loop: Header=BB0_89 Depth=1
	add	x4, x1, #12
	ld1.s	{ v22 }[3], [x4]
	ldr	q23, [x3, #16]
	tbnz	w2, #4, LBB0_94
LBB0_101:                               ; %else201
                                        ;   in Loop: Header=BB0_89 Depth=1
	tbz	w2, #5, LBB0_95
LBB0_102:                               ; %cond.load203
                                        ;   in Loop: Header=BB0_89 Depth=1
	add	x3, x1, #20
	ld1.s	{ v23 }[1], [x3]
	tbnz	w2, #6, LBB0_96
LBB0_103:                               ; %else207
                                        ;   in Loop: Header=BB0_89 Depth=1
	tbz	w2, #7, LBB0_88
LBB0_104:                               ; %cond.load209
                                        ;   in Loop: Header=BB0_89 Depth=1
	add	x1, x1, #28
	ld1.s	{ v23 }[3], [x1]
	b	LBB0_88
LBB0_105:                               ; %direct.false63
	add	x9, x9, x13
	add	x13, sp, #528
	add	x13, x13, x12
	ldr	q4, [x13]
	ldr	d2, [x10, lCPI0_12@PAGEOFF]
	shl.8b	v3, v17, #7
	cmlt.8b	v3, v3, #0
	and.8b	v2, v3, v2
	addv.8b	b2, v2
	str	d2, [sp, #8]                    ; 8-byte Spill
	fmov	w10, s2
	tbz	w10, #0, LBB0_113
; %bb.106:                              ; %cond.load213
	ld1.s	{ v4 }[0], [x9]
	tbnz	w10, #1, LBB0_114
LBB0_107:                               ; %else217
	tbz	w10, #2, LBB0_115
LBB0_108:                               ; %cond.load219
	add	x15, x9, #8
	ld1.s	{ v4 }[2], [x15]
	tbnz	w10, #3, LBB0_116
LBB0_109:                               ; %else223
	ldr	q2, [x13, #16]
	tbz	w10, #4, LBB0_117
LBB0_110:                               ; %cond.load225
	add	x13, x9, #16
	ld1.s	{ v2 }[0], [x13]
	tbnz	w10, #5, LBB0_118
LBB0_111:                               ; %else229
	tbz	w10, #6, LBB0_119
LBB0_112:                               ; %cond.load231
	add	x13, x9, #24
	ld1.s	{ v2 }[2], [x13]
	str	q17, [sp, #80]                  ; 16-byte Spill
	tbnz	w10, #7, LBB0_120
	b	LBB0_121
LBB0_113:                               ; %else214
	tbz	w10, #1, LBB0_107
LBB0_114:                               ; %cond.load216
	add	x15, x9, #4
	ld1.s	{ v4 }[1], [x15]
	tbnz	w10, #2, LBB0_108
LBB0_115:                               ; %else220
	tbz	w10, #3, LBB0_109
LBB0_116:                               ; %cond.load222
	add	x15, x9, #12
	ld1.s	{ v4 }[3], [x15]
	ldr	q2, [x13, #16]
	tbnz	w10, #4, LBB0_110
LBB0_117:                               ; %else226
	tbz	w10, #5, LBB0_111
LBB0_118:                               ; %cond.load228
	add	x13, x9, #20
	ld1.s	{ v2 }[1], [x13]
	tbnz	w10, #6, LBB0_112
LBB0_119:                               ; %else232
	str	q17, [sp, #80]                  ; 16-byte Spill
	tbz	w10, #7, LBB0_121
LBB0_120:                               ; %cond.load234
	add	x9, x9, #28
	ld1.s	{ v2 }[3], [x9]
LBB0_121:                               ; %else235
	mov	x15, #0                         ; =0x0
	add	x9, sp, #528
	add	x10, x9, x12
	stp	q2, q4, [sp, #16]               ; 32-byte Folded Spill
	stp	q4, q2, [x10]
	add	x10, x8, x14
	movi.2d	v25, #0000000000000000
	fmov	w12, s19
	mov	w13, #-1026555904               ; =0xc2d00000
	dup.4s	v19, w13
	mov	w13, #1120403456                ; =0x42c80000
	dup.4s	v26, w13
	mov	w13, #43579                     ; =0xaa3b
	movk	w13, #16312, lsl #16
	dup.4s	v27, w13
	mov	w13, #29184                     ; =0x7200
	movk	w13, #48945, lsl #16
	dup.4s	v28, w13
	mov	w13, #48782                     ; =0xbe8e
	movk	w13, #46527, lsl #16
	dup.4s	v29, w13
	mov	w13, #11226                     ; =0x2bda
	movk	w13, #14672, lsl #16
	dup.4s	v30, w13
	mov	w13, #38601                     ; =0x96c9
	movk	w13, #15030, lsl #16
	dup.4s	v31, w13
	mov	w13, #34982                     ; =0x88a6
	movk	w13, #15368, lsl #16
	dup.4s	v8, w13
	mov	w13, #43642                     ; =0xaa7a
	movk	w13, #15658, lsl #16
	dup.4s	v9, w13
	mov	w13, #43691                     ; =0xaaab
	movk	w13, #15914, lsl #16
	dup.4s	v10, w13
	add	x13, sp, #1, lsl #12            ; =4096
	add	x13, x13, #2608
	movi.4s	v11, #75, lsl #24
	mvni.4s	v12, #128, lsl #24
	movi.4s	v13, #63, lsl #24
	fmov.4s	v14, #1.00000000
	mvni.4s	v2, #127, msl #16
	fneg.4s	v15, v2
	mvni.4s	v2, #63, msl #16
	fneg.4s	v2, v2
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v16, #0000000000000000
	b	LBB0_123
LBB0_122:                               ; %else253
                                        ;   in Loop: Header=BB0_123 Depth=1
	add.2d	v3, v3, v6
	add.2d	v4, v4, v7
	add.2d	v16, v16, v5
	add.2d	v25, v25, v21
	fmov	x15, d25
	cmp	x15, #192
	b.ge	LBB0_139
LBB0_123:                               ; %direct.true83
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x14, x15, #5
	add	x16, x13, x14
	ldr	q24, [x16]
	and.16b	v24, v1, v24
	fneg.4s	v17, v24
	and.16b	v17, v1, v17
	fcmge.4s	v18, v17, v19
	fcmge.4s	v20, v26, v17
	and.16b	v18, v18, v20
	and.16b	v18, v18, v17
	fmul.4s	v20, v18, v27
	mov.16b	v22, v12
	bsl.16b	v22, v11, v20
	fadd.4s	v20, v20, v22
	fsub.4s	v20, v20, v22
	fcvtzs.4s	v20, v20
	scvtf.4s	v22, v20
	fmul.4s	v23, v22, v28
	fadd.4s	v18, v18, v23
	fmul.4s	v22, v22, v29
	fadd.4s	v18, v18, v22
	fmul.4s	v22, v18, v30
	fadd.4s	v22, v22, v31
	fmul.4s	v22, v18, v22
	fadd.4s	v22, v22, v8
	fmul.4s	v22, v18, v22
	fadd.4s	v22, v22, v9
	fmul.4s	v22, v18, v22
	fadd.4s	v22, v22, v10
	fmul.4s	v22, v18, v22
	fadd.4s	v22, v22, v13
	fmul.4s	v23, v18, v18
	fmul.4s	v22, v23, v22
	fadd.4s	v18, v18, v22
	fadd.4s	v18, v18, v14
	sshr.4s	v22, v20, #1
	shl.4s	v23, v22, #23
	add.4s	v23, v23, v14
	fmul.4s	v18, v18, v23
	sub.4s	v20, v20, v22
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v14
	fmul.4s	v18, v18, v20
	fcmgt.4s	v20, v19, v17
	fcmgt.4s	v22, v17, v26
	fcmeq.4s	v17, v17, v17
	fadd.4s	v18, v18, v14
	bit.16b	v18, v14, v20
	bit.16b	v18, v15, v22
	bsl.16b	v17, v18, v2
	fdiv.4s	v17, v24, v17
	add	x17, x9, x14
	ldr	q18, [x17]
	and.16b	v18, v1, v18
	fmul.4s	v24, v18, v17
	add	x14, x10, x14
	tbz	w12, #0, LBB0_127
; %bb.124:                              ; %cond.store238
                                        ;   in Loop: Header=BB0_123 Depth=1
	str	s24, [x14]
	and	w15, w12, #0xff
	tbnz	w15, #1, LBB0_128
LBB0_125:                               ; %else241
                                        ;   in Loop: Header=BB0_123 Depth=1
	tbz	w15, #2, LBB0_129
LBB0_126:                               ; %cond.store242
                                        ;   in Loop: Header=BB0_123 Depth=1
	add	x0, x14, #8
	st1.s	{ v24 }[2], [x0]
	tbnz	w15, #3, LBB0_130
	b	LBB0_131
LBB0_127:                               ; %else239
                                        ;   in Loop: Header=BB0_123 Depth=1
	and	w15, w12, #0xff
	tbz	w15, #1, LBB0_125
LBB0_128:                               ; %cond.store240
                                        ;   in Loop: Header=BB0_123 Depth=1
	add	x0, x14, #4
	st1.s	{ v24 }[1], [x0]
	tbnz	w15, #2, LBB0_126
LBB0_129:                               ; %else243
                                        ;   in Loop: Header=BB0_123 Depth=1
	tbz	w15, #3, LBB0_131
LBB0_130:                               ; %cond.store244
                                        ;   in Loop: Header=BB0_123 Depth=1
	add	x0, x14, #12
	st1.s	{ v24 }[3], [x0]
LBB0_131:                               ; %else245
                                        ;   in Loop: Header=BB0_123 Depth=1
	ldr	q17, [x16, #16]
	and.16b	v17, v0, v17
	fneg.4s	v18, v17
	and.16b	v18, v0, v18
	fcmge.4s	v20, v18, v19
	fcmge.4s	v22, v26, v18
	and.16b	v20, v20, v22
	and.16b	v20, v20, v18
	fmul.4s	v22, v20, v27
	mov.16b	v23, v12
	bsl.16b	v23, v11, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	fcvtzs.4s	v22, v22
	scvtf.4s	v23, v22
	fmul.4s	v24, v23, v28
	fadd.4s	v20, v20, v24
	fmul.4s	v23, v23, v29
	fadd.4s	v20, v20, v23
	fmul.4s	v23, v20, v30
	fadd.4s	v23, v23, v31
	fmul.4s	v23, v20, v23
	fadd.4s	v23, v23, v8
	fmul.4s	v23, v20, v23
	fadd.4s	v23, v23, v9
	fmul.4s	v23, v20, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v23, v20, v23
	fadd.4s	v23, v23, v13
	fmul.4s	v24, v20, v20
	fmul.4s	v23, v24, v23
	fadd.4s	v20, v20, v23
	fadd.4s	v20, v20, v14
	sshr.4s	v23, v22, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v14
	fmul.4s	v20, v20, v24
	sub.4s	v22, v22, v23
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v14
	fmul.4s	v20, v20, v22
	fcmgt.4s	v22, v19, v18
	fcmgt.4s	v23, v18, v26
	fcmeq.4s	v18, v18, v18
	fadd.4s	v20, v20, v14
	bit.16b	v20, v14, v22
	bit.16b	v20, v15, v23
	bsl.16b	v18, v20, v2
	fdiv.4s	v17, v17, v18
	ldr	q18, [x17, #16]
	and.16b	v18, v0, v18
	fmul.4s	v24, v18, v17
	tbz	w15, #4, LBB0_135
; %bb.132:                              ; %cond.store246
                                        ;   in Loop: Header=BB0_123 Depth=1
	str	s24, [x14, #16]
	tbnz	w15, #5, LBB0_136
LBB0_133:                               ; %else249
                                        ;   in Loop: Header=BB0_123 Depth=1
	tbz	w15, #6, LBB0_137
LBB0_134:                               ; %cond.store250
                                        ;   in Loop: Header=BB0_123 Depth=1
	add	x16, x14, #24
	st1.s	{ v24 }[2], [x16]
	tbz	w15, #7, LBB0_122
	b	LBB0_138
LBB0_135:                               ; %else247
                                        ;   in Loop: Header=BB0_123 Depth=1
	tbz	w15, #5, LBB0_133
LBB0_136:                               ; %cond.store248
                                        ;   in Loop: Header=BB0_123 Depth=1
	add	x16, x14, #20
	st1.s	{ v24 }[1], [x16]
	tbnz	w15, #6, LBB0_134
LBB0_137:                               ; %else251
                                        ;   in Loop: Header=BB0_123 Depth=1
	tbz	w15, #7, LBB0_122
LBB0_138:                               ; %cond.store252
                                        ;   in Loop: Header=BB0_123 Depth=1
	add	x14, x14, #28
	st1.s	{ v24 }[3], [x14]
	b	LBB0_122
LBB0_139:                               ; %direct.false84
	ldr	d0, [sp, #8]                    ; 8-byte Reload
	fmov	w9, s0
	ldr	q1, [sp, #80]                   ; 16-byte Reload
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v3, v0, #0
	ldr	q0, [sp, #64]                   ; 16-byte Reload
	and.16b	v4, v3, v0
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	ldr	q1, [sp, #48]                   ; 16-byte Reload
	and.16b	v1, v0, v1
	fneg.4s	v2, v1
	fneg.4s	v5, v4
	and.16b	v5, v3, v5
	mov	w10, #-1026555904               ; =0xc2d00000
	dup.4s	v6, w10
	and.16b	v2, v0, v2
	fcmge.4s	v16, v2, v6
	fcmge.4s	v17, v5, v6
	mov	w10, #1120403456                ; =0x42c80000
	dup.4s	v7, w10
	fcmge.4s	v18, v7, v2
	fcmge.4s	v19, v7, v5
	and.16b	v17, v17, v19
	and.16b	v16, v16, v18
	and.16b	v16, v16, v2
	and.16b	v17, v17, v5
	mov	w10, #43579                     ; =0xaa3b
	movk	w10, #16312, lsl #16
	dup.4s	v18, w10
	fmul.4s	v19, v17, v18
	fmul.4s	v18, v16, v18
	movi.4s	v20, #75, lsl #24
	mvni.4s	v21, #128, lsl #24
	mov.16b	v22, v21
	bsl.16b	v22, v20, v18
	bif.16b	v20, v19, v21
	fadd.4s	v19, v19, v20
	fadd.4s	v18, v18, v22
	fsub.4s	v18, v18, v22
	fsub.4s	v19, v19, v20
	fcvtzs.4s	v19, v19
	fcvtzs.4s	v18, v18
	scvtf.4s	v20, v18
	scvtf.4s	v21, v19
	mov	w10, #29184                     ; =0x7200
	movk	w10, #48945, lsl #16
	dup.4s	v22, w10
	fmul.4s	v23, v21, v22
	fmul.4s	v22, v20, v22
	fadd.4s	v16, v16, v22
	fadd.4s	v17, v17, v23
	mov	w10, #48782                     ; =0xbe8e
	movk	w10, #46527, lsl #16
	dup.4s	v22, w10
	fmul.4s	v20, v20, v22
	fmul.4s	v21, v21, v22
	fadd.4s	v17, v17, v21
	fadd.4s	v16, v16, v20
	mov	w10, #11226                     ; =0x2bda
	movk	w10, #14672, lsl #16
	dup.4s	v20, w10
	fmul.4s	v21, v16, v20
	fmul.4s	v20, v17, v20
	mov	w10, #38601                     ; =0x96c9
	movk	w10, #15030, lsl #16
	dup.4s	v22, w10
	fadd.4s	v20, v20, v22
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v16, v21
	fmul.4s	v20, v17, v20
	mov	w10, #34982                     ; =0x88a6
	movk	w10, #15368, lsl #16
	dup.4s	v22, w10
	fadd.4s	v20, v20, v22
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v16, v21
	fmul.4s	v20, v17, v20
	mov	w10, #43642                     ; =0xaa7a
	movk	w10, #15658, lsl #16
	dup.4s	v22, w10
	fadd.4s	v20, v20, v22
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v16, v21
	fmul.4s	v20, v17, v20
	mov	w10, #43691                     ; =0xaaab
	movk	w10, #15914, lsl #16
	dup.4s	v22, w10
	fadd.4s	v20, v20, v22
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v16, v21
	fmul.4s	v20, v17, v20
	movi.4s	v22, #63, lsl #24
	fadd.4s	v20, v20, v22
	fadd.4s	v21, v21, v22
	fmul.4s	v22, v17, v17
	fmul.4s	v23, v16, v16
	fmul.4s	v21, v23, v21
	fmul.4s	v20, v22, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v21
	fmov.4s	v20, #1.00000000
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v20
	sshr.4s	v21, v18, #1
	sshr.4s	v22, v19, #1
	shl.4s	v23, v22, #23
	shl.4s	v24, v21, #23
	add.4s	v24, v24, v20
	add.4s	v23, v23, v20
	fmul.4s	v17, v17, v23
	fmul.4s	v16, v16, v24
	sub.4s	v19, v19, v22
	sub.4s	v18, v18, v21
	shl.4s	v18, v18, #23
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v20
	add.4s	v18, v18, v20
	fmul.4s	v16, v16, v18
	fmul.4s	v17, v17, v19
	fcmgt.4s	v18, v6, v5
	fcmgt.4s	v19, v6, v2
	fcmgt.4s	v6, v2, v7
	fcmgt.4s	v21, v5, v7
	fcmeq.4s	v22, v5, v5
	fadd.4s	v5, v17, v20
	fadd.4s	v7, v16, v20
	bit.16b	v7, v20, v19
	bit.16b	v5, v20, v18
	mvni.4s	v16, #127, msl #16
	fneg.4s	v16, v16
	mov.16b	v17, v21
	bsl.16b	v17, v16, v5
	mvni.4s	v5, #63, msl #16
	fneg.4s	v5, v5
	bif.16b	v17, v5, v22
	fdiv.4s	v4, v4, v17
	ldr	q17, [sp, #32]                  ; 16-byte Reload
	and.16b	v3, v3, v17
	fmul.4s	v3, v4, v3
	ldr	q4, [sp, #144]                  ; 16-byte Reload
	str	q4, [sp, #304]
	ldr	q4, [sp, #128]                  ; 16-byte Reload
	str	q4, [sp, #320]
	ldr	q4, [sp, #112]                  ; 16-byte Reload
	str	q4, [sp, #336]
	ldr	q4, [sp, #96]                   ; 16-byte Reload
	str	q4, [sp, #352]
	and	x10, x11, #0x7
	add	x12, sp, #304
	ldr	x10, [x12, x10, lsl #3]
	sub	x10, x10, x11
	add	x8, x8, x10, lsl #2
	tbz	w9, #0, LBB0_147
; %bb.140:                              ; %cond.store255
	str	s3, [x8]
	fcmeq.4s	v2, v2, v2
	mov.16b	v4, v6
	bsl.16b	v4, v16, v7
	tbnz	w9, #1, LBB0_148
LBB0_141:                               ; %else258
	bsl.16b	v2, v4, v5
	tbz	w9, #2, LBB0_149
LBB0_142:                               ; %cond.store259
	add	x10, x8, #8
	st1.s	{ v3 }[2], [x10]
	fdiv.4s	v1, v1, v2
	ldr	q2, [sp, #16]                   ; 16-byte Reload
	and.16b	v0, v0, v2
	tbnz	w9, #3, LBB0_150
LBB0_143:                               ; %else262
	fmul.4s	v0, v1, v0
	tbz	w9, #4, LBB0_186
LBB0_144:                               ; %cond.store263
	str	s0, [x8, #16]
	tbnz	w9, #5, LBB0_187
LBB0_145:                               ; %else266
	tbz	w9, #6, LBB0_188
LBB0_146:                               ; %cond.store133
	add	x10, x8, #24
	st1.s	{ v0 }[2], [x10]
	tbnz	w9, #7, LBB0_189
	b	LBB0_190
LBB0_147:                               ; %else256
	fcmeq.4s	v2, v2, v2
	mov.16b	v4, v6
	bsl.16b	v4, v16, v7
	tbz	w9, #1, LBB0_141
LBB0_148:                               ; %cond.store257
	add	x10, x8, #4
	st1.s	{ v3 }[1], [x10]
	bsl.16b	v2, v4, v5
	tbnz	w9, #2, LBB0_142
LBB0_149:                               ; %else260
	fdiv.4s	v1, v1, v2
	ldr	q2, [sp, #16]                   ; 16-byte Reload
	and.16b	v0, v0, v2
	tbz	w9, #3, LBB0_143
LBB0_150:                               ; %cond.store261
	add	x10, x8, #12
	st1.s	{ v3 }[3], [x10]
	fmul.4s	v0, v1, v0
	tbz	w9, #4, LBB0_186
	b	LBB0_144
LBB0_151:                               ; %direct.false21
	xtn.8b	v0, v17
	movi	d1, #0x0000000000ffff
	and.8b	v20, v0, v1
	ldr	d1, [x11, lCPI0_7@PAGEOFF]
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w15, s0
	umaxv.8b	b0, v20
	fmov	w11, s0
	rbit	w13, w15
	clz	w13, w13
	tst	w11, #0x1
	mov	w11, #1536                      ; =0x600
	dup.2d	v17, x11
	mov.d	x14, v18[1]
	csel	w11, w13, wzr, ne
	mov	w13, #1538                      ; =0x602
	mul	x14, x14, x13
	fmov	x16, d18
	mul	x16, x16, x13
	fmov	d0, x16
	mov.d	v0[1], x14
	ldr	q1, [sp, #96]                   ; 16-byte Reload
	add.2d	v1, v1, v17
	mov	b2, v20[0]
	mov.b	v2[4], v20[1]
	add.2d	v1, v0, v1
	ushll.2d	v0, v2, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	and.16b	v0, v0, v1
	movi.2d	v16, #0000000000000000
	stp	q16, q16, [sp, #256]
	stp	q0, q16, [sp, #224]
	and	x14, x11, #0x7
	add	x16, sp, #224
	ldr	x14, [x16, x14, lsl #3]
	sub	x14, x14, x11
	lsl	x14, x14, #2
	add	x12, x12, x14
	movi.2d	v0, #0000000000000000
	tbz	w15, #0, LBB0_159
; %bb.152:                              ; %cond.load71
	ldr	s16, [x12]
	tbnz	w15, #1, LBB0_160
LBB0_153:                               ; %else75
	tbz	w15, #2, LBB0_161
LBB0_154:                               ; %cond.load77
	add	x16, x12, #8
	ld1.s	{ v16 }[2], [x16]
	tbnz	w15, #3, LBB0_162
LBB0_155:                               ; %else81
	tbz	w15, #4, LBB0_163
LBB0_156:                               ; %cond.load83
	add	x16, x12, #16
	ld1.s	{ v0 }[0], [x16]
	tbnz	w15, #5, LBB0_164
LBB0_157:                               ; %else87
	tbz	w15, #6, LBB0_165
LBB0_158:                               ; %cond.load89
	add	x16, x12, #24
	ld1.s	{ v0 }[2], [x16]
	tbnz	w15, #7, LBB0_166
	b	LBB0_167
LBB0_159:                               ; %else72
	tbz	w15, #1, LBB0_153
LBB0_160:                               ; %cond.load74
	add	x16, x12, #4
	ld1.s	{ v16 }[1], [x16]
	tbnz	w15, #2, LBB0_154
LBB0_161:                               ; %else78
	tbz	w15, #3, LBB0_155
LBB0_162:                               ; %cond.load80
	add	x16, x12, #12
	ld1.s	{ v16 }[3], [x16]
	tbnz	w15, #4, LBB0_156
LBB0_163:                               ; %else84
	tbz	w15, #5, LBB0_157
LBB0_164:                               ; %cond.load86
	add	x16, x12, #20
	ld1.s	{ v0 }[1], [x16]
	tbnz	w15, #6, LBB0_158
LBB0_165:                               ; %else90
	tbz	w15, #7, LBB0_167
LBB0_166:                               ; %cond.load92
	add	x12, x12, #28
	ld1.s	{ v0 }[3], [x12]
LBB0_167:                               ; %else93
	fneg.4s	v2, v16
	fneg.4s	v5, v0
	ldr	d6, [x10, lCPI0_12@PAGEOFF]
	shl.8b	v7, v20, #7
	cmlt.8b	v7, v7, #0
	and.8b	v6, v7, v6
	addv.8b	b19, v6
	fmov	w10, s19
	zip2.8b	v6, v20, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v18, v6, v5
	zip1.8b	v5, v20, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	and.16b	v23, v5, v2
	mov	w12, #-1026555904               ; =0xc2d00000
	dup.4s	v21, w12
	fcmge.4s	v2, v23, v21
	fcmge.4s	v5, v18, v21
	mov	w12, #1120403456                ; =0x42c80000
	dup.4s	v20, w12
	fcmge.4s	v6, v20, v23
	fcmge.4s	v7, v20, v18
	and.16b	v5, v5, v7
	and.16b	v2, v2, v6
	and.16b	v2, v2, v23
	and.16b	v5, v5, v18
	mov	w12, #43579                     ; =0xaa3b
	movk	w12, #16312, lsl #16
	dup.4s	v6, w12
	fmul.4s	v7, v5, v6
	fmul.4s	v6, v2, v6
	movi.4s	v22, #75, lsl #24
	mvni.4s	v24, #128, lsl #24
	mov.16b	v25, v24
	bsl.16b	v25, v22, v6
	bif.16b	v22, v7, v24
	fadd.4s	v7, v7, v22
	fadd.4s	v6, v6, v25
	fsub.4s	v6, v6, v25
	fsub.4s	v7, v7, v22
	fcvtzs.4s	v26, v7
	fcvtzs.4s	v6, v6
	scvtf.4s	v7, v6
	mov	w12, #29184                     ; =0x7200
	movk	w12, #48945, lsl #16
	dup.4s	v22, w12
	scvtf.4s	v24, v26
	fmul.4s	v25, v24, v22
	fmul.4s	v22, v7, v22
	fadd.4s	v2, v2, v22
	fadd.4s	v5, v5, v25
	mov	w12, #48782                     ; =0xbe8e
	movk	w12, #46527, lsl #16
	dup.4s	v22, w12
	fmul.4s	v7, v7, v22
	fmul.4s	v22, v24, v22
	fadd.4s	v27, v5, v22
	fadd.4s	v2, v2, v7
	mov	w12, #11226                     ; =0x2bda
	movk	w12, #14672, lsl #16
	dup.4s	v5, w12
	fmul.4s	v7, v2, v5
	fmul.4s	v5, v27, v5
	mov	w12, #38601                     ; =0x96c9
	movk	w12, #15030, lsl #16
	dup.4s	v22, w12
	fadd.4s	v5, v5, v22
	fadd.4s	v7, v7, v22
	fmul.4s	v7, v2, v7
	fmul.4s	v5, v27, v5
	mov	w12, #34982                     ; =0x88a6
	movk	w12, #15368, lsl #16
	dup.4s	v22, w12
	fadd.4s	v5, v5, v22
	fadd.4s	v7, v7, v22
	fmul.4s	v7, v2, v7
	fmul.4s	v5, v27, v5
	mov	w12, #43642                     ; =0xaa7a
	movk	w12, #15658, lsl #16
	dup.4s	v22, w12
	fadd.4s	v5, v5, v22
	fadd.4s	v7, v7, v22
	fmul.4s	v7, v2, v7
	fmul.4s	v5, v27, v5
	mov	w12, #43691                     ; =0xaaab
	movk	w12, #15914, lsl #16
	dup.4s	v22, w12
	fadd.4s	v5, v5, v22
	fadd.4s	v7, v7, v22
	fmul.4s	v7, v2, v7
	fmul.4s	v28, v27, v5
	movi.4s	v29, #63, lsl #24
	fadd.4s	v5, v7, v29
	fmul.4s	v7, v2, v2
	fmul.4s	v5, v7, v5
	fadd.4s	v2, v2, v5
	fmov.4s	v24, #1.00000000
	fadd.4s	v30, v2, v24
	sshr.4s	v2, v6, #1
	shl.4s	v5, v2, #23
	add.4s	v31, v5, v24
	sub.4s	v2, v6, v2
	shl.4s	v8, v2, #23
	add	x9, x9, x14
	movi.2d	v25, #0000000000000000
	movi.2d	v22, #0000000000000000
	tbz	w10, #0, LBB0_192
; %bb.168:                              ; %cond.load96
	ldr	s25, [x9]
	fadd.4s	v28, v28, v29
	fmul.4s	v29, v27, v27
	fmul.4s	v30, v30, v31
	add.4s	v31, v8, v24
	tbnz	w10, #1, LBB0_193
LBB0_169:                               ; %else100
	fmul.4s	v28, v29, v28
	sshr.4s	v29, v26, #1
	fmul.4s	v30, v30, v31
	tbz	w10, #2, LBB0_171
LBB0_170:                               ; %cond.load102
	add	x12, x9, #8
	ld1.s	{ v25 }[2], [x12]
LBB0_171:                               ; %else103
	fadd.4s	v27, v27, v28
	shl.4s	v28, v29, #23
	sub.4s	v29, v26, v29
	fcmgt.4s	v26, v21, v23
	fadd.4s	v30, v30, v24
	mvni.4s	v31, #127, msl #16
	tbz	w10, #3, LBB0_173
; %bb.172:                              ; %cond.load105
	add	x12, x9, #12
	ld1.s	{ v25 }[3], [x12]
LBB0_173:                               ; %else106
	fadd.4s	v27, v27, v24
	add.4s	v28, v28, v24
	shl.4s	v8, v29, #23
	fcmgt.4s	v29, v23, v20
	bit.16b	v30, v24, v26
	fneg.4s	v26, v31
	mvni.4s	v9, #63, msl #16
	tbz	w10, #4, LBB0_175
; %bb.174:                              ; %cond.load108
	add	x12, x9, #16
	ld1.s	{ v22 }[0], [x12]
LBB0_175:                               ; %else109
	fmul.4s	v31, v27, v28
	add.4s	v8, v8, v24
	dup.2s	v27, w13
	fcmeq.4s	v28, v23, v23
	bit.16b	v30, v26, v29
	fneg.4s	v23, v9
	tbz	w10, #5, LBB0_177
; %bb.176:                              ; %cond.load111
	add	x12, x9, #20
	ld1.s	{ v22 }[1], [x12]
LBB0_177:                               ; %else112
	fmul.4s	v29, v31, v8
	ldr	d2, [sp, #112]                  ; 8-byte Reload
	umlal.2d	v3, v2, v27
	ldr	d2, [sp, #128]                  ; 8-byte Reload
	umlal.2d	v4, v2, v27
	ldr	q2, [sp, #144]                  ; 16-byte Reload
	ldr	d5, [sp, #80]                   ; 8-byte Reload
	umlal.2d	v2, v5, v27
	str	q2, [sp, #144]                  ; 16-byte Spill
	mov.16b	v6, v28
	bsl.16b	v6, v30, v23
	tbz	w10, #6, LBB0_179
; %bb.178:                              ; %cond.load114
	add	x12, x9, #24
	ld1.s	{ v22 }[2], [x12]
LBB0_179:                               ; %else115
	fcmgt.4s	v7, v21, v18
	fadd.4s	v21, v29, v24
	add.2d	v3, v3, v17
	add.2d	v4, v4, v17
	ldr	q2, [sp, #144]                  ; 16-byte Reload
	add.2d	v5, v2, v17
	fdiv.4s	v2, v16, v6
	tbz	w10, #7, LBB0_181
; %bb.180:                              ; %cond.load117
	add	x9, x9, #28
	ld1.s	{ v22 }[3], [x9]
LBB0_181:                               ; %else118
	fcmgt.4s	v6, v18, v20
	bsl.16b	v7, v24, v21
	fmul.4s	v2, v25, v2
	stp	q1, q3, [sp, #160]
	stp	q4, q5, [sp, #192]
	and	x9, x11, #0x7
	add	x10, sp, #160
	ldr	x9, [x10, x9, lsl #3]
	sub	x9, x9, x11
	add	x8, x8, x9, lsl #2
	fmov	w9, s19
	tbz	w9, #0, LBB0_194
; %bb.182:                              ; %cond.store121
	str	s2, [x8]
	fcmeq.4s	v1, v18, v18
	mov.16b	v3, v6
	bsl.16b	v3, v26, v7
	tbnz	w9, #1, LBB0_195
LBB0_183:                               ; %else124
	bsl.16b	v1, v3, v23
	tbz	w9, #2, LBB0_196
LBB0_184:                               ; %cond.store125
	add	x10, x8, #8
	st1.s	{ v2 }[2], [x10]
	fdiv.4s	v0, v0, v1
	tbnz	w9, #3, LBB0_197
LBB0_185:                               ; %else128
	fmul.4s	v0, v22, v0
	tbnz	w9, #4, LBB0_144
LBB0_186:                               ; %else264
	tbz	w9, #5, LBB0_145
LBB0_187:                               ; %cond.store265
	add	x10, x8, #20
	st1.s	{ v0 }[1], [x10]
	tbnz	w9, #6, LBB0_146
LBB0_188:                               ; %else268
	tbz	w9, #7, LBB0_190
LBB0_189:                               ; %cond.store269
	add	x8, x8, #28
	st1.s	{ v0 }[3], [x8]
LBB0_190:
	add	sp, sp, #3, lsl #12             ; =12288
	add	sp, sp, #592
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #112            ; 16-byte Folded Reload
LBB0_191:                               ; %common.ret
	ret
LBB0_192:                               ; %else97
	fadd.4s	v28, v28, v29
	fmul.4s	v29, v27, v27
	fmul.4s	v30, v30, v31
	add.4s	v31, v8, v24
	tbz	w10, #1, LBB0_169
LBB0_193:                               ; %cond.load99
	add	x12, x9, #4
	ld1.s	{ v25 }[1], [x12]
	fmul.4s	v28, v29, v28
	sshr.4s	v29, v26, #1
	fmul.4s	v30, v30, v31
	tbnz	w10, #2, LBB0_170
	b	LBB0_171
LBB0_194:                               ; %else122
	fcmeq.4s	v1, v18, v18
	mov.16b	v3, v6
	bsl.16b	v3, v26, v7
	tbz	w9, #1, LBB0_183
LBB0_195:                               ; %cond.store123
	add	x10, x8, #4
	st1.s	{ v2 }[1], [x10]
	bsl.16b	v1, v3, v23
	tbnz	w9, #2, LBB0_184
LBB0_196:                               ; %else126
	fdiv.4s	v0, v0, v1
	tbz	w9, #3, LBB0_185
LBB0_197:                               ; %cond.store127
	add	x10, x8, #12
	st1.s	{ v2 }[3], [x10]
	fmul.4s	v0, v22, v0
	tbz	w9, #4, LBB0_186
	b	LBB0_144
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
                                        ; -- End function
	.p2align	2                               ; -- Begin function llm_rows.full_packet
_llm_rows.full_packet:                  ; @llm_rows.full_packet
; %bb.0:                                ; %prologue
	stp	d11, d10, [sp, #-112]!          ; 16-byte Folded Spill
	stp	d9, d8, [sp, #16]               ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	sub	sp, sp, #3, lsl #12             ; =12288
	sub	sp, sp, #80
	ldr	x22, [x0]
	ldr	x21, [x0, #16]
	ldr	x19, [x0, #48]
	ldr	w8, [x1]
	ldr	w9, [x1, #36]
	add	w8, w9, w8, lsl #5
	lsr	w8, w8, #3
	dup.2s	v0, w8
	ushll.2d	v0, v0, #0
	subs	x8, x22, x19
	cset	w9, hs
	mov	w10, #8199                      ; =0x2007
	movk	w10, #24, lsl #16
	cmp	x8, x10
	csel	w8, wzr, w9, ls
	subs	x9, x19, x22
	cset	w11, hs
	cmp	x9, x10
	csel	w9, wzr, w11, ls
	orr	w9, w8, w9
	subs	x8, x21, x19
	cset	w11, hs
	cmp	x8, x10
	csel	w8, wzr, w11, ls
	subs	x11, x19, x21
	cset	w12, hs
	cmp	x11, x10
	csel	w10, wzr, w12, ls
	orr	w10, w8, w10
	fmov	x8, d0
	mov	w11, #6152                      ; =0x1808
	umull	x8, w8, w11
	cmp	w9, #1
	ccmp	w10, #0, #4, eq
	b.ne	LBB1_4
; %bb.1:                                ; %direct.schedule.8.preheader
	mov	w20, #6144                      ; =0x1800
	add	x23, sp, #1, lsl #12            ; =4096
	add	x23, x23, #2096
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2096
	add	x1, x22, x8
	mov	w2, #6144                       ; =0x1800
	str	q0, [sp]                        ; 16-byte Spill
	bl	_memcpy
	ldr	q0, [sp]                        ; 16-byte Reload
	fmov	x24, d0
	mov	w25, #6152                      ; =0x1808
	umaddl	x20, w24, w25, x20
	add	x8, x22, x20
	add	x9, x8, #4
	ldr	s0, [x8]
	ld1.s	{ v0 }[1], [x9]
	str	q0, [sp]                        ; 16-byte Spill
	str	q0, [sp, #12336]
	umaddl	x1, w24, w25, x21
	add	x22, sp, #16
	add	x0, sp, #16
	mov	w2, #6144                       ; =0x1800
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	add	x9, x21, x20
	ldr	s0, [x9], #4
	ld1.s	{ v0 }[1], [x9]
	str	q0, [sp, #6160]
	mov	w9, #1120927744                 ; =0x42d00000
	dup.4s	v1, w9
	mov	w9, #-1027080192                ; =0xc2c80000
	dup.4s	v2, w9
	mov	w9, #43579                      ; =0xaa3b
	movk	w9, #16312, lsl #16
	dup.4s	v3, w9
	umaddl	x9, w24, w25, x19
	movi.4s	v4, #75, lsl #24
	mvni.4s	v5, #128, lsl #24
	mov	w10, #29184                     ; =0x7200
	movk	w10, #48945, lsl #16
	dup.4s	v6, w10
	mov	w10, #48782                     ; =0xbe8e
	movk	w10, #46527, lsl #16
	dup.4s	v7, w10
	mov	w10, #11226                     ; =0x2bda
	movk	w10, #14672, lsl #16
	dup.4s	v16, w10
	mov	w10, #38601                     ; =0x96c9
	movk	w10, #15030, lsl #16
	dup.4s	v17, w10
	mov	w10, #34982                     ; =0x88a6
	movk	w10, #15368, lsl #16
	dup.4s	v18, w10
	mov	w10, #43642                     ; =0xaa7a
	movk	w10, #15658, lsl #16
	dup.4s	v19, w10
	mov	w10, #43691                     ; =0xaaab
	movk	w10, #15914, lsl #16
	dup.4s	v20, w10
	movi.4s	v21, #63, lsl #24
	fmov.4s	v22, #1.00000000
	mvni.4s	v23, #127, msl #16
	fneg.4s	v23, v23
	mvni.4s	v24, #63, msl #16
	fneg.4s	v24, v24
LBB1_2:                                 ; %direct.true83
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x10, x8, #5
	add	x11, x23, x10
	ldp	q25, q26, [x11]
	fneg.4s	v27, v26
	fneg.4s	v28, v25
	fcmge.4s	v29, v1, v25
	fcmge.4s	v30, v1, v26
	fcmge.4s	v31, v25, v2
	fcmge.4s	v8, v26, v2
	and.16b	v30, v30, v8
	and.16b	v29, v29, v31
	and.16b	v28, v29, v28
	and.16b	v27, v30, v27
	fmul.4s	v29, v27, v3
	fmul.4s	v30, v28, v3
	mov.16b	v31, v5
	bsl.16b	v31, v4, v30
	mov.16b	v8, v5
	bsl.16b	v8, v4, v29
	fadd.4s	v29, v29, v8
	fadd.4s	v30, v30, v31
	fsub.4s	v30, v30, v31
	fsub.4s	v29, v29, v8
	fcvtzs.4s	v29, v29
	fcvtzs.4s	v30, v30
	scvtf.4s	v31, v30
	scvtf.4s	v8, v29
	fmul.4s	v9, v8, v6
	fmul.4s	v10, v31, v6
	fadd.4s	v28, v28, v10
	fadd.4s	v27, v27, v9
	fmul.4s	v31, v31, v7
	fmul.4s	v8, v8, v7
	fadd.4s	v27, v27, v8
	fadd.4s	v28, v28, v31
	fmul.4s	v31, v28, v16
	fmul.4s	v8, v27, v16
	fadd.4s	v8, v8, v17
	fadd.4s	v31, v31, v17
	fmul.4s	v31, v28, v31
	fmul.4s	v8, v27, v8
	fadd.4s	v8, v8, v18
	fadd.4s	v31, v31, v18
	fmul.4s	v31, v28, v31
	fmul.4s	v8, v27, v8
	fadd.4s	v8, v8, v19
	fadd.4s	v31, v31, v19
	fmul.4s	v31, v28, v31
	fmul.4s	v8, v27, v8
	fadd.4s	v8, v8, v20
	fadd.4s	v31, v31, v20
	fmul.4s	v31, v28, v31
	fmul.4s	v8, v27, v8
	fadd.4s	v8, v8, v21
	fadd.4s	v31, v31, v21
	fmul.4s	v9, v27, v27
	fmul.4s	v10, v28, v28
	fmul.4s	v31, v10, v31
	fmul.4s	v8, v9, v8
	fadd.4s	v27, v27, v8
	fadd.4s	v28, v28, v31
	sshr.4s	v31, v30, #1
	fadd.4s	v28, v28, v22
	sshr.4s	v8, v29, #1
	shl.4s	v9, v8, #23
	shl.4s	v10, v31, #23
	add.4s	v10, v10, v22
	add.4s	v9, v9, v22
	fadd.4s	v27, v27, v22
	fmul.4s	v27, v27, v9
	sub.4s	v29, v29, v8
	sub.4s	v30, v30, v31
	shl.4s	v30, v30, #23
	shl.4s	v29, v29, #23
	fmul.4s	v28, v28, v10
	add.4s	v29, v29, v22
	add.4s	v30, v30, v22
	fmul.4s	v28, v28, v30
	fmul.4s	v27, v27, v29
	fcmgt.4s	v29, v26, v1
	fcmgt.4s	v30, v25, v1
	fcmgt.4s	v31, v2, v25
	fcmgt.4s	v8, v2, v26
	fcmeq.4s	v9, v26, v26
	fadd.4s	v27, v27, v22
	fadd.4s	v28, v28, v22
	fcmeq.4s	v10, v25, v25
	bit.16b	v28, v22, v30
	bit.16b	v27, v22, v29
	bit.16b	v27, v23, v8
	bit.16b	v28, v23, v31
	bif.16b	v28, v24, v10
	bif.16b	v27, v24, v9
	fdiv.4s	v26, v26, v27
	fdiv.4s	v25, v25, v28
	add	x11, x22, x10
	ldp	q28, q27, [x11]
	fmul.4s	v25, v28, v25
	fmul.4s	v26, v27, v26
	add	x10, x9, x10
	stp	q25, q26, [x10]
	add	x8, x8, #1
	cmp	x8, #192
	b.ne	LBB1_2
; %bb.3:                                ; %direct.false84
	movi.2d	v2, #0000000000000000
	movi.2d	v1, #0000000000000000
	ldr	q3, [sp]                        ; 16-byte Reload
	mov.d	v1[0], v3[0]
	fneg.4s	v3, v1
	mov.d	v2[0], v3[0]
	mov	w8, #-1026555904                ; =0xc2d00000
	dup.4s	v3, w8
	fcmge.4s	v4, v2, v3
	mov	w8, #1120403456                 ; =0x42c80000
	dup.4s	v5, w8
	fcmge.4s	v6, v5, v2
	and.16b	v4, v4, v6
	and.16b	v4, v4, v2
	mov	w8, #43579                      ; =0xaa3b
	movk	w8, #16312, lsl #16
	dup.4s	v6, w8
	fmul.4s	v6, v4, v6
	movi.4s	v7, #75, lsl #24
	mvni.4s	v16, #128, lsl #24
	bif.16b	v7, v6, v16
	fadd.4s	v6, v6, v7
	fsub.4s	v6, v6, v7
	fcvtzs.4s	v6, v6
	mov	w8, #29184                      ; =0x7200
	movk	w8, #48945, lsl #16
	dup.4s	v7, w8
	scvtf.4s	v16, v6
	fmul.4s	v7, v16, v7
	fadd.4s	v4, v4, v7
	mov	w8, #48782                      ; =0xbe8e
	movk	w8, #46527, lsl #16
	dup.4s	v7, w8
	fmul.4s	v7, v16, v7
	fadd.4s	v4, v4, v7
	mov	w8, #11226                      ; =0x2bda
	movk	w8, #14672, lsl #16
	dup.4s	v7, w8
	fmul.4s	v7, v4, v7
	mov	w8, #38601                      ; =0x96c9
	movk	w8, #15030, lsl #16
	dup.4s	v16, w8
	fadd.4s	v7, v7, v16
	fmul.4s	v7, v4, v7
	mov	w8, #34982                      ; =0x88a6
	movk	w8, #15368, lsl #16
	dup.4s	v16, w8
	fadd.4s	v7, v7, v16
	mov	w8, #43642                      ; =0xaa7a
	movk	w8, #15658, lsl #16
	dup.4s	v16, w8
	fmul.4s	v7, v4, v7
	fadd.4s	v7, v7, v16
	fmul.4s	v7, v4, v7
	mov	w8, #43691                      ; =0xaaab
	movk	w8, #15914, lsl #16
	dup.4s	v16, w8
	fadd.4s	v7, v7, v16
	fmul.4s	v7, v4, v7
	movi.4s	v16, #63, lsl #24
	fadd.4s	v7, v7, v16
	fmul.4s	v16, v4, v4
	fmul.4s	v7, v16, v7
	fadd.4s	v4, v4, v7
	fmov.4s	v7, #1.00000000
	fadd.4s	v4, v4, v7
	sshr.4s	v16, v6, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v7
	fmul.4s	v4, v4, v17
	sub.4s	v6, v6, v16
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v7
	fmul.4s	v4, v4, v6
	fcmgt.4s	v3, v3, v2
	fcmgt.4s	v5, v2, v5
	fcmeq.4s	v2, v2, v2
	fadd.4s	v4, v4, v7
	bsl.16b	v3, v7, v4
	mvni.4s	v4, #127, msl #16
	fneg.4s	v4, v4
	bit.16b	v3, v4, v5
	mvni.4s	v4, #63, msl #16
	fneg.4s	v4, v4
	bsl.16b	v2, v3, v4
	fdiv.4s	v1, v1, v2
	b	LBB1_7
LBB1_4:                                 ; %direct.true20.preheader
	mov	x9, #0                          ; =0x0
	add	x10, x19, x8
	add	x11, x21, x8
	mov	w12, #1120927744                ; =0x42d00000
	dup.4s	v0, w12
	mov	w12, #-1027080192               ; =0xc2c80000
	dup.4s	v1, w12
	mov	w12, #43579                     ; =0xaa3b
	movk	w12, #16312, lsl #16
	dup.4s	v2, w12
	mov	w12, #29184                     ; =0x7200
	movk	w12, #48945, lsl #16
	dup.4s	v3, w12
	mov	w12, #48782                     ; =0xbe8e
	movk	w12, #46527, lsl #16
	dup.4s	v4, w12
	mov	w12, #11226                     ; =0x2bda
	movk	w12, #14672, lsl #16
	dup.4s	v5, w12
	mov	w12, #38601                     ; =0x96c9
	movk	w12, #15030, lsl #16
	dup.4s	v6, w12
	mov	w12, #34982                     ; =0x88a6
	movk	w12, #15368, lsl #16
	dup.4s	v7, w12
	mov	w12, #43642                     ; =0xaa7a
	movk	w12, #15658, lsl #16
	dup.4s	v16, w12
	mov	w12, #43691                     ; =0xaaab
	movk	w12, #15914, lsl #16
	dup.4s	v17, w12
	add	x12, x22, x8
	movi.4s	v18, #75, lsl #24
	mvni.4s	v19, #128, lsl #24
	movi.4s	v20, #63, lsl #24
	fmov.4s	v21, #1.00000000
	mvni.4s	v22, #127, msl #16
	fneg.4s	v22, v22
	mvni.4s	v23, #63, msl #16
	fneg.4s	v23, v23
LBB1_5:                                 ; %direct.true20
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x13, x9, #5
	add	x14, x12, x13
	ldp	q24, q25, [x14]
	fneg.4s	v26, v25
	fneg.4s	v27, v24
	fcmge.4s	v28, v0, v24
	fcmge.4s	v29, v0, v25
	fcmge.4s	v30, v24, v1
	fcmge.4s	v31, v25, v1
	and.16b	v29, v29, v31
	and.16b	v28, v28, v30
	and.16b	v27, v28, v27
	and.16b	v26, v29, v26
	fmul.4s	v28, v26, v2
	fmul.4s	v29, v27, v2
	mov.16b	v30, v19
	bsl.16b	v30, v18, v29
	mov.16b	v31, v19
	bsl.16b	v31, v18, v28
	fadd.4s	v28, v28, v31
	fadd.4s	v29, v29, v30
	fsub.4s	v29, v29, v30
	fsub.4s	v28, v28, v31
	fcvtzs.4s	v28, v28
	fcvtzs.4s	v29, v29
	scvtf.4s	v30, v29
	scvtf.4s	v31, v28
	fmul.4s	v8, v31, v3
	fmul.4s	v9, v30, v3
	fadd.4s	v27, v27, v9
	fadd.4s	v26, v26, v8
	fmul.4s	v30, v30, v4
	fmul.4s	v31, v31, v4
	fadd.4s	v26, v26, v31
	fadd.4s	v27, v27, v30
	fmul.4s	v30, v27, v5
	fmul.4s	v31, v26, v5
	fadd.4s	v31, v31, v6
	fadd.4s	v30, v30, v6
	fmul.4s	v30, v27, v30
	fmul.4s	v31, v26, v31
	fadd.4s	v31, v31, v7
	fadd.4s	v30, v30, v7
	fmul.4s	v30, v27, v30
	fmul.4s	v31, v26, v31
	fadd.4s	v31, v31, v16
	fadd.4s	v30, v30, v16
	fmul.4s	v30, v27, v30
	fmul.4s	v31, v26, v31
	fadd.4s	v31, v31, v17
	fadd.4s	v30, v30, v17
	fmul.4s	v30, v27, v30
	fmul.4s	v31, v26, v31
	fadd.4s	v31, v31, v20
	fadd.4s	v30, v30, v20
	fmul.4s	v8, v26, v26
	fmul.4s	v9, v27, v27
	fmul.4s	v30, v9, v30
	fmul.4s	v31, v8, v31
	fadd.4s	v26, v26, v31
	fadd.4s	v27, v27, v30
	sshr.4s	v30, v29, #1
	fadd.4s	v27, v27, v21
	sshr.4s	v31, v28, #1
	shl.4s	v8, v31, #23
	shl.4s	v9, v30, #23
	add.4s	v9, v9, v21
	add.4s	v8, v8, v21
	fadd.4s	v26, v26, v21
	fmul.4s	v26, v26, v8
	sub.4s	v28, v28, v31
	sub.4s	v29, v29, v30
	shl.4s	v29, v29, #23
	shl.4s	v28, v28, #23
	fmul.4s	v27, v27, v9
	add.4s	v28, v28, v21
	add.4s	v29, v29, v21
	fmul.4s	v27, v27, v29
	fmul.4s	v26, v26, v28
	fcmgt.4s	v28, v25, v0
	fcmgt.4s	v29, v24, v0
	fcmgt.4s	v30, v1, v24
	fcmgt.4s	v31, v1, v25
	fcmeq.4s	v8, v25, v25
	fadd.4s	v26, v26, v21
	fadd.4s	v27, v27, v21
	fcmeq.4s	v9, v24, v24
	bit.16b	v27, v21, v29
	bit.16b	v26, v21, v28
	bit.16b	v26, v22, v31
	bit.16b	v27, v22, v30
	bif.16b	v27, v23, v9
	bif.16b	v26, v23, v8
	fdiv.4s	v25, v25, v26
	fdiv.4s	v24, v24, v27
	add	x14, x11, x13
	ldp	q27, q26, [x14]
	fmul.4s	v24, v27, v24
	fmul.4s	v25, v26, v25
	add	x13, x10, x13
	stp	q24, q25, [x13]
	add	x9, x9, #1
	cmp	x9, #192
	b.ne	LBB1_5
; %bb.6:                                ; %direct.false21
	mov	w9, #6144                       ; =0x1800
	add	x20, x8, x9
	add	x8, x22, x20
	movi.2d	v1, #0000000000000000
	ldp	s2, s3, [x8]
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], v2[0]
	mov.s	v0[1], v3[0]
	fneg.4s	v2, v0
	mov.d	v1[0], v2[0]
	mov	w8, #-1026555904                ; =0xc2d00000
	dup.4s	v2, w8
	fcmge.4s	v3, v1, v2
	mov	w8, #1120403456                 ; =0x42c80000
	dup.4s	v4, w8
	fcmge.4s	v5, v4, v1
	and.16b	v3, v3, v5
	and.16b	v3, v3, v1
	mov	w8, #43579                      ; =0xaa3b
	movk	w8, #16312, lsl #16
	dup.4s	v5, w8
	fmul.4s	v5, v3, v5
	movi.4s	v6, #75, lsl #24
	mvni.4s	v7, #128, lsl #24
	bif.16b	v6, v5, v7
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	fcvtzs.4s	v5, v5
	scvtf.4s	v6, v5
	mov	w8, #29184                      ; =0x7200
	movk	w8, #48945, lsl #16
	dup.4s	v7, w8
	fmul.4s	v7, v6, v7
	mov	w8, #48782                      ; =0xbe8e
	movk	w8, #46527, lsl #16
	dup.4s	v16, w8
	fadd.4s	v3, v3, v7
	fmul.4s	v6, v6, v16
	fadd.4s	v3, v3, v6
	mov	w8, #11226                      ; =0x2bda
	movk	w8, #14672, lsl #16
	dup.4s	v6, w8
	fmul.4s	v6, v3, v6
	mov	w8, #38601                      ; =0x96c9
	movk	w8, #15030, lsl #16
	dup.4s	v7, w8
	fadd.4s	v6, v6, v7
	fmul.4s	v6, v3, v6
	mov	w8, #34982                      ; =0x88a6
	movk	w8, #15368, lsl #16
	dup.4s	v7, w8
	fadd.4s	v6, v6, v7
	fmul.4s	v6, v3, v6
	mov	w8, #43642                      ; =0xaa7a
	movk	w8, #15658, lsl #16
	dup.4s	v7, w8
	fadd.4s	v6, v6, v7
	mov	w8, #43691                      ; =0xaaab
	movk	w8, #15914, lsl #16
	dup.4s	v7, w8
	fmul.4s	v6, v3, v6
	fadd.4s	v6, v6, v7
	fmul.4s	v6, v3, v6
	movi.4s	v7, #63, lsl #24
	fadd.4s	v6, v6, v7
	fmul.4s	v7, v3, v3
	fmul.4s	v6, v7, v6
	fadd.4s	v3, v3, v6
	fmov.4s	v6, #1.00000000
	fadd.4s	v3, v3, v6
	sshr.4s	v7, v5, #1
	shl.4s	v16, v7, #23
	add.4s	v16, v16, v6
	fmul.4s	v3, v3, v16
	sub.4s	v5, v5, v7
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v6
	fmul.4s	v3, v3, v5
	fcmgt.4s	v2, v2, v1
	fcmgt.4s	v4, v1, v4
	fcmeq.4s	v1, v1, v1
	fadd.4s	v3, v3, v6
	bsl.16b	v2, v6, v3
	mvni.4s	v3, #127, msl #16
	fneg.4s	v3, v3
	bit.16b	v2, v3, v4
	mvni.4s	v3, #63, msl #16
	fneg.4s	v3, v3
	bsl.16b	v1, v2, v3
	fdiv.4s	v0, v0, v1
	add	x8, x21, x20
	add	x9, x8, #4
	ldr	s1, [x8]
	ld1.s	{ v1 }[1], [x9]
LBB1_7:                                 ; %common.ret
	fmul.4s	v0, v1, v0
	str	d0, [x19, x20]
	add	sp, sp, #3, lsl #12             ; =12288
	add	sp, sp, #80
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp], #112            ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB2_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB2_4
LBB2_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB2_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB2_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB2_13
LBB2_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB2_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB2_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #1
	b.eq	LBB2_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #2
	b.eq	LBB2_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #3
	b.eq	LBB2_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB2_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB2_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
LBB2_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB2_3
LBB2_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB2_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_3:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_4:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_7:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_8:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_9:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_10:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_11:
	.long	5                               ; 0x5
	.long	4                               ; 0x4
	.long	7                               ; 0x7
	.long	6                               ; 0x6
lCPI0_12:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	3                               ; 0x3
	.long	2                               ; 0x2
lCPI0_13:
	.long	6                               ; 0x6
	.long	7                               ; 0x7
	.long	4                               ; 0x4
	.long	5                               ; 0x5
lCPI0_14:
	.long	2                               ; 0x2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	1                               ; 0x1
lCPI0_15:
	.long	4                               ; 0x4
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_16:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	dup.4s	v1, w2
Lloh0:
	adrp	x8, lCPI0_1@PAGE
Lloh1:
	ldr	q2, [x8, lCPI0_1@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_2@PAGE
Lloh3:
	ldr	q0, [x8, lCPI0_2@PAGEOFF]
	cmhi.4s	v0, v1, v0
	cmhi.4s	v1, v1, v2
	uzp1.8h	v2, v1, v0
	umaxv.8h	h3, v2
	fmov	w8, s3
	tbz	w8, #0, LBB0_82
; %bb.1:                                ; %direct.activate
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #2736
	mov	x9, #0                          ; =0x0
	ldr	x11, [x0]
	ldr	x12, [x0, #16]
	ldr	x10, [x0, #32]
	ldr	x8, [x0, #48]
Lloh4:
	adrp	x13, lCPI0_0@PAGE
Lloh5:
	ldr	q3, [x13, lCPI0_0@PAGEOFF]
	and.16b	v3, v2, v3
	addv.8h	h28, v3
	fmov	w13, s28
	ldr	w14, [x1]
	ldr	w15, [x1, #36]
	add	w14, w15, w14, lsl #5
	lsr	w14, w14, #3
	dup.4s	v4, w14
	and	w14, w13, #0xff
	and.16b	v16, v1, v4
	and.16b	v4, v0, v4
	ushll2.2d	v5, v4, #0
	ushll2.2d	v6, v16, #0
	ushll.2d	v7, v4, #0
	ushll.2d	v17, v16, #0
	fmov	x13, d17
	mov	w15, #260                       ; =0x104
	umaddl	x13, w13, w15, x11
	fmov	w15, s28
	add	x16, sp, #2448
	b	LBB0_3
LBB0_2:                                 ; %else64
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x16, x9
	stp	q4, q16, [x17]
	add	x9, x9, #32
	cmp	x9, #256
	b.eq	LBB0_19
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	add	x17, x13, x9
	add	x1, x16, x9
	ldr	q4, [x1]
	tbnz	w15, #0, LBB0_11
; %bb.4:                                ; %else44
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w0, w15, #0xff
	tbnz	w0, #1, LBB0_12
LBB0_5:                                 ; %else46
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w0, #2, LBB0_13
LBB0_6:                                 ; %else49
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w0, #3, LBB0_14
LBB0_7:                                 ; %else52
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q16, [x1, #16]
	tbnz	w0, #4, LBB0_15
LBB0_8:                                 ; %else55
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w0, #5, LBB0_16
LBB0_9:                                 ; %else58
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w0, #6, LBB0_17
LBB0_10:                                ; %else61
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w0, #7, LBB0_2
	b	LBB0_18
LBB0_11:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	ld1.s	{ v4 }[0], [x17]
	and	w0, w15, #0xff
	tbz	w0, #1, LBB0_5
LBB0_12:                                ; %cond.load45
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x2, x17, #4
	ld1.s	{ v4 }[1], [x2]
	tbz	w0, #2, LBB0_6
LBB0_13:                                ; %cond.load48
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x2, x17, #8
	ld1.s	{ v4 }[2], [x2]
	tbz	w0, #3, LBB0_7
LBB0_14:                                ; %cond.load51
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x2, x17, #12
	ld1.s	{ v4 }[3], [x2]
	ldr	q16, [x1, #16]
	tbz	w0, #4, LBB0_8
LBB0_15:                                ; %cond.load54
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x17, #16
	ld1.s	{ v16 }[0], [x1]
	tbz	w0, #5, LBB0_9
LBB0_16:                                ; %cond.load57
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x17, #20
	ld1.s	{ v16 }[1], [x1]
	tbz	w0, #6, LBB0_10
LBB0_17:                                ; %cond.load60
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x17, #24
	ld1.s	{ v16 }[2], [x1]
	tbz	w0, #7, LBB0_2
LBB0_18:                                ; %cond.load63
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x17, #28
	ld1.s	{ v16 }[3], [x17]
	b	LBB0_2
LBB0_19:                                ; %direct.true77.preheader
	xtn.8b	v29, v2
	sshll.2d	v2, v1, #0
	sshll.2d	v19, v0, #0
	sshll2.2d	v25, v1, #0
	sshll2.2d	v26, v0, #0
Lloh6:
	adrp	x9, lCPI0_6@PAGE
Lloh7:
	ldr	q4, [x9, lCPI0_6@PAGEOFF]
	and.16b	v3, v2, v4
	movi.2d	v4, #0000000000000000
Lloh8:
	adrp	x9, lCPI0_7@PAGE
Lloh9:
	ldr	q18, [x9, lCPI0_7@PAGEOFF]
	and.16b	v2, v2, v18
Lloh10:
	adrp	x9, lCPI0_8@PAGE
Lloh11:
	ldr	q18, [x9, lCPI0_8@PAGEOFF]
	and.16b	v18, v19, v18
Lloh12:
	adrp	x9, lCPI0_9@PAGE
Lloh13:
	ldr	q20, [x9, lCPI0_9@PAGEOFF]
	and.16b	v23, v25, v20
Lloh14:
	adrp	x9, lCPI0_10@PAGE
Lloh15:
	ldr	q20, [x9, lCPI0_10@PAGEOFF]
	and.16b	v24, v26, v20
	movi.8b	v20, #1
	and.8b	v20, v29, v20
	umov.b	w13, v20[0]
	movi.2d	v27, #0000000000000000
	movi.2d	v16, #0000000000000000
	mov.b	v16[0], v29[0]
	umaxv.8b	b20, v16
	fmov	w17, s20
	rbit	w9, w13
	clz	w9, w9
	tst	w17, #0x1
	mov	w15, #64                        ; =0x40
	dup.2d	v22, x15
	csel	w9, w9, wzr, ne
	stp	q29, q3, [sp, #304]             ; 32-byte Folded Spill
	orr.16b	v3, v3, v22
	xtn.2s	v21, v17
	movi.2s	v20, #65
	str	q3, [sp, #192]                  ; 16-byte Spill
	umlal.2d	v3, v21, v20
	mov.b	v27[0], v29[0]
	ushll.2d	v17, v27, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	str	q3, [sp, #288]                  ; 16-byte Spill
	and.16b	v17, v17, v3
	str	q4, [sp, #1488]
	str	q4, [sp, #1472]
	str	q4, [sp, #1456]
	str	q17, [sp, #1440]
	ubfiz	x16, x9, #3, #3
	add	x15, sp, #1440
	ldr	x15, [x15, x16]
	sub	x15, x15, x9
	add	x15, x11, x15, lsl #2
	str	q24, [sp, #1552]
	str	q18, [sp, #1536]
	str	q23, [sp, #1520]
	str	q2, [sp, #1504]
	add	x11, sp, #1504
	ldr	x11, [x11, x16]
	orr	x11, x11, #0x100
	sub	x11, x11, w9, uxtw #2
	tst	w13, #0x1
	csel	x11, xzr, x11, eq
	add	x16, sp, #2448
	add	x16, x16, x11
	ldr	q24, [x16]
	tbnz	w17, #0, LBB0_127
; %bb.20:                               ; %else68
	tbnz	w13, #1, LBB0_128
LBB0_21:                                ; %else71
	tbnz	w13, #2, LBB0_129
LBB0_22:                                ; %else74
	tbnz	w13, #3, LBB0_130
LBB0_23:                                ; %else77
	adrp	x17, lCPI0_3@PAGE
	adrp	x0, lCPI0_4@PAGE
	adrp	x1, lCPI0_5@PAGE
	ldr	q27, [x16, #16]
	tbnz	w13, #4, LBB0_131
LBB0_24:                                ; %else80
	ldr	q4, [x17, lCPI0_3@PAGEOFF]
	ldr	q18, [x0, lCPI0_4@PAGEOFF]
	ldr	q23, [x1, lCPI0_5@PAGEOFF]
	tbnz	w13, #5, LBB0_132
LBB0_25:                                ; %else83
	and.16b	v3, v26, v4
	and.16b	v4, v25, v18
	and.16b	v17, v19, v23
	tbz	w13, #6, LBB0_27
LBB0_26:                                ; %cond.load85
	add	x16, x15, #24
	ld1.s	{ v27 }[2], [x16]
LBB0_27:                                ; %else86
	stp	q17, q4, [sp, #64]              ; 32-byte Folded Spill
	orr.16b	v18, v17, v22
	orr.16b	v19, v4, v22
	orr.16b	v17, v3, v22
	xtn.2s	v6, v6
	xtn.2s	v4, v7
	xtn.2s	v5, v5
	str	q16, [sp, #336]                 ; 16-byte Spill
	str	q28, [sp, #272]                 ; 16-byte Spill
	str	q3, [sp, #96]                   ; 16-byte Spill
	tbz	w13, #7, LBB0_29
; %bb.28:                               ; %cond.load88
	add	x13, x15, #28
	ld1.s	{ v27 }[3], [x13]
LBB0_29:                                ; %else89
	umull.2d	v7, v21, v20
	stp	q18, q17, [sp, #160]            ; 32-byte Folded Spill
	mov.16b	v3, v17
	umlal.2d	v3, v5, v20
	str	q3, [sp, #256]                  ; 16-byte Spill
	stp	q24, q19, [sp, #128]            ; 32-byte Folded Spill
	mov.16b	v3, v19
	umlal.2d	v3, v6, v20
	str	q3, [sp, #240]                  ; 16-byte Spill
	mov.16b	v3, v18
	umlal.2d	v3, v4, v20
	stp	q7, q3, [sp, #208]              ; 32-byte Folded Spill
	sshll.2d	v22, v1, #0
	sshll.2d	v23, v0, #0
	add	x13, sp, #2448
	add	x15, x13, x11
	str	q27, [sp, #112]                 ; 16-byte Spill
	stp	q24, q27, [x15]
	fmov	x24, d2
	mov	w15, #4                         ; =0x4
	dup.2d	v2, x15
	and.16b	v4, v26, v2
	and.16b	v31, v25, v2
	and.16b	v8, v23, v2
	and.16b	v9, v22, v2
	fmov	x23, d9
	ldr	q5, [sp, #2544]
	ldr	q2, [sp, #2560]
	and.16b	v2, v0, v2
	and.16b	v5, v1, v5
	ldr	q6, [sp, #2512]
	ldr	q7, [sp, #2528]
	and.16b	v7, v0, v7
	and.16b	v6, v1, v6
	ldr	q21, [sp, #2480]
	ldr	q20, [sp, #2496]
	and.16b	v20, v0, v20
	and.16b	v21, v1, v21
	add	x16, x13, x24
	ldp	q24, q27, [x16]
	and.16b	v27, v0, v27
	mov	x16, x23
	and.16b	v11, v1, v24
	mov.16b	v12, v9
	mov.16b	v13, v31
	mov.16b	v14, v8
	mov.16b	v29, v4
LBB0_30:                                ; %direct.true77
                                        ; =>This Inner Loop Header: Depth=1
	add	x16, x13, x16, lsl #5
	ldp	q24, q15, [x16]
	fadd.4s	v24, v11, v24
	fadd.4s	v15, v27, v15
	ldp	q16, q3, [x16, #32]
	fadd.4s	v16, v21, v16
	fadd.4s	v3, v20, v3
	ldp	q10, q30, [x16, #64]
	fadd.4s	v10, v6, v10
	fadd.4s	v30, v7, v30
	ldp	q18, q17, [x16, #96]
	fadd.4s	v18, v5, v18
	fadd.4s	v17, v2, v17
	dup.2d	v19, x15
	and.16b	v28, v26, v19
	add.2d	v29, v29, v28
	and.16b	v28, v25, v19
	add.2d	v13, v13, v28
	and.16b	v28, v23, v19
	add.2d	v14, v14, v28
	and.16b	v19, v22, v19
	add.2d	v12, v12, v19
	bit.16b	v27, v15, v0
	bit.16b	v11, v24, v1
	bit.16b	v20, v3, v0
	bit.16b	v21, v16, v1
	bit.16b	v7, v30, v0
	bit.16b	v6, v10, v1
	bit.16b	v2, v17, v0
	bit.16b	v5, v18, v1
	fmov	x16, d12
	cmp	x16, #8
	b.lt	LBB0_30
; %bb.31:                               ; %direct.false78
	mov	x25, #0                         ; =0x0
	ldp	q30, q29, [sp, #112]            ; 32-byte Folded Reload
	fadd.4s	v3, v30, v27
	fadd.4s	v16, v29, v11
	ldr	q27, [sp, #336]                 ; 16-byte Reload
	zip1.8b	v17, v27, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	and.16b	v16, v17, v16
	zip2.8b	v17, v27, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	and.16b	v3, v17, v3
	ldr	q28, [sp, #304]                 ; 16-byte Reload
	zip2.8b	v17, v28, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	bit.16b	v3, v15, v17
	movi.2d	v11, #0000000000000000
	movi.2d	v17, #0000000000000000
	mov.b	v17[2], v28[1]
	mov.b	v17[4], v28[2]
	mov.b	v17[6], v28[3]
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	bit.16b	v16, v24, v17
	fadd.4s	v16, v21, v16
	fadd.4s	v3, v20, v3
	fadd.4s	v3, v7, v3
	fadd.4s	v6, v6, v16
	fadd.4s	v6, v5, v6
	fadd.4s	v7, v2, v3
	ldr	q2, [sp, #320]                  ; 16-byte Reload
	ldr	q3, [sp, #80]                   ; 16-byte Reload
	uzp1.4s	v5, v2, v3
	ldr	q2, [sp, #96]                   ; 16-byte Reload
	ldr	q3, [sp, #64]                   ; 16-byte Reload
	uzp1.4s	v17, v3, v2
	movi.4s	v2, #1
	eor.16b	v3, v5, v2
	mov.s	w15, v3[1]
	mov.s	w16, v3[2]
	eor.16b	v21, v17, v2
	mov.s	w1, v3[3]
	fmov	w13, s3
	add	x0, sp, #1080
	add	x17, sp, #1080
	bfxil	x17, x13, #0, #3
	str	d28, [sp, #1080]
	ldrb	w17, [x17]
	and	x2, x13, #0x7
	umov.b	w13, v28[0]
	str	q7, [sp, #1296]
	str	q6, [sp, #1280]
	add	x3, sp, #1280
	ldr	s3, [x3, x2, lsl #2]
	ands	w5, w13, #0x1
	tst	w5, w17
	movi.2d	v2, #0000000000000000
	fcsel	s18, s3, s2, ne
	and	x2, x15, #0x7
	add	x17, sp, #1080
	bfxil	x17, x15, #0, #3
	ldrb	w15, [x17]
	umov.b	w17, v28[1]
	and	w15, w17, w15
	str	q7, [sp, #1264]
	str	q6, [sp, #1248]
	add	x3, sp, #1248
	ldr	s3, [x3, x2, lsl #2]
	tst	w15, #0x1
	fcsel	s19, s3, s2, ne
	and	x15, x16, #0x7
	add	x2, sp, #1080
	bfxil	x2, x16, #0, #3
	ldrb	w2, [x2]
	umov.b	w16, v28[2]
	and	w2, w16, w2
	str	q7, [sp, #1232]
	str	q6, [sp, #1216]
	add	x3, sp, #1216
	ldr	s3, [x3, x15, lsl #2]
	tst	w2, #0x1
	fcsel	s20, s3, s2, ne
	and	x2, x1, #0x7
	add	x3, sp, #1080
	bfxil	x3, x1, #0, #3
	umov.b	w15, v28[3]
	ldrb	w1, [x3]
	str	q7, [sp, #1200]
	str	q6, [sp, #1184]
	add	x3, sp, #1184
	ldr	s3, [x3, x2, lsl #2]
	and	w1, w15, w1
	tst	w1, #0x1
	mov.s	w1, v21[1]
	mov.s	w2, v21[2]
	fcsel	s22, s3, s2, ne
	mov.s	w6, v21[3]
	fmov	w3, s21
	and	x7, x3, #0x7
	add	x4, sp, #1080
	bfxil	x4, x3, #0, #3
	ldrb	w3, [x4]
	umov.b	w4, v28[4]
	and	w3, w4, w3
	str	q7, [sp, #1424]
	str	q6, [sp, #1408]
	add	x19, sp, #1408
	ldr	s3, [x19, x7, lsl #2]
	tst	w3, #0x1
	fcsel	s3, s3, s2, ne
	and	x7, x1, #0x7
	add	x3, sp, #1080
	bfxil	x3, x1, #0, #3
	ldrb	w1, [x3]
	umov.b	w3, v28[5]
	and	w1, w3, w1
	str	q7, [sp, #1392]
	str	q6, [sp, #1376]
	add	x19, sp, #1376
	ldr	s16, [x19, x7, lsl #2]
	tst	w1, #0x1
	fcsel	s16, s16, s2, ne
	and	x7, x2, #0x7
	add	x1, sp, #1080
	bfxil	x1, x2, #0, #3
	ldrb	w2, [x1]
	umov.b	w1, v28[6]
	and	w2, w1, w2
	str	q7, [sp, #1360]
	str	q6, [sp, #1344]
	add	x19, sp, #1344
	ldr	s21, [x19, x7, lsl #2]
	tst	w2, #0x1
	fcsel	s21, s21, s2, ne
	and	x7, x6, #0x7
	add	x2, sp, #1080
	bfxil	x2, x6, #0, #3
	ldrb	w6, [x2]
	umov.b	w2, v28[7]
	and	w6, w2, w6
	str	q7, [sp, #1328]
	str	q6, [sp, #1312]
	add	x19, sp, #1312
	ldr	s23, [x19, x7, lsl #2]
	tst	w6, #0x1
	fcsel	s23, s23, s2, ne
	mov.s	v3[1], v16[0]
	mov.s	v3[2], v21[0]
	mov.s	v3[3], v23[0]
	mov.s	v18[1], v19[0]
	mov.s	v18[2], v20[0]
	mov.s	v18[3], v22[0]
	fadd.4s	v6, v6, v18
	fadd.4s	v3, v7, v3
	movi.4s	v7, #2
	eor.16b	v16, v17, v7
	eor.16b	v5, v5, v7
	fmov	w6, s5
	add	x7, sp, #1080
	bfxil	x7, x6, #0, #3
	ldrb	w7, [x7]
	and	x6, x6, #0x7
	str	q3, [sp, #1168]
	str	q6, [sp, #1152]
	add	x19, sp, #1152
	ldr	s5, [x19, x6, lsl #2]
	tst	w5, w7
	fcsel	s5, s5, s2, ne
	fmov	w5, s16
	and	x6, x5, #0x7
	bfxil	x0, x5, #0, #3
	ldrb	w0, [x0]
	and	w0, w4, w0
	str	q3, [sp, #1136]
	str	q6, [sp, #1120]
	add	x5, sp, #1120
	ldr	s7, [x5, x6, lsl #2]
	tst	w0, #0x1
	fcsel	s7, s7, s2, ne
	fadd.4s	v3, v3, v7
	and	w0, w13, w4
	tst	w0, #0x1
	fcsel	s3, s3, s2, ne
	ands	w21, w13, #0x1
	fadd.4s	v5, v6, v5
	fadd	s3, s5, s3
	fcsel	s5, s3, s2, ne
	tst	w0, #0x1
	mov.b	v28[0], wzr
	str	q28, [sp, #48]                  ; 16-byte Spill
	and	w5, w17, w13
	fcsel	s6, s3, s2, ne
	tst	w5, #0x1
	and	w6, w16, w13
	fcsel	s7, s3, s2, ne
	tst	w6, #0x1
	and	w7, w15, w13
	fcsel	s16, s3, s2, ne
	tst	w7, #0x1
	fcsel	s17, s3, s2, ne
	and	w19, w3, w13
	tst	w19, #0x1
	fcsel	s18, s3, s2, ne
	and	w20, w1, w13
	tst	w20, #0x1
	fcsel	s19, s3, s2, ne
	and	w22, w2, w13
	tst	w22, #0x1
	fcsel	s3, s3, s2, ne
	mov.s	v5[1], v7[0]
	mov.s	v5[2], v16[0]
	mov.s	v5[3], v17[0]
	mov.s	v6[1], v18[0]
	mov.s	v6[2], v19[0]
	mov.s	v6[3], v3[0]
	rbit	w14, w14
	clz	w14, w14
	str	q6, [sp, #1104]
	str	q5, [sp, #1088]
	and	x26, x14, #0x7
	add	x27, sp, #1088
	ldr	s3, [x27, x26, lsl #2]
	fadd	s2, s3, s2
	mov	w26, #1115815936                ; =0x42820000
	fmov	s3, w26
	fdiv	s2, s2, s3
	dup.4s	v2, v2[0]
	ushll2.2d	v3, v0, #0
	mov	w26, #1                         ; =0x1
	dup.2d	v5, x26
	and.16b	v18, v3, v5
	ushll2.2d	v3, v1, #0
	and.16b	v19, v3, v5
	ushll.2d	v3, v0, #0
	and.16b	v20, v3, v5
	ushll.2d	v3, v1, #0
	and.16b	v21, v3, v5
	add	x26, sp, #2448
	add	x27, sp, #2160
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
LBB0_32:                                ; %direct.true112
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x25, x25, #5
	add	x28, x26, x25
	ldp	q16, q3, [x28]
	fsub.4s	v16, v16, v2
	fsub.4s	v3, v3, v2
	add	x25, x27, x25
	ldp	q17, q22, [x25]
	bif.16b	v3, v22, v0
	bif.16b	v16, v17, v1
	stp	q16, q3, [x25]
	add.2d	v5, v5, v19
	add.2d	v6, v6, v20
	add.2d	v7, v7, v18
	add.2d	v11, v11, v21
	fmov	x25, d11
	cmp	x25, #8
	b.lt	LBB0_32
; %bb.33:                               ; %direct.true149.preheader
Lloh16:
	adrp	x25, lCPI0_11@PAGE
Lloh17:
	ldr	q3, [x25, lCPI0_11@PAGEOFF]
	and.16b	v3, v0, v3
	str	q3, [sp, #32]                   ; 16-byte Spill
Lloh18:
	adrp	x25, lCPI0_12@PAGE
Lloh19:
	ldr	q3, [x25, lCPI0_12@PAGEOFF]
	and.16b	v3, v1, v3
	str	q3, [sp, #16]                   ; 16-byte Spill
Lloh20:
	adrp	x25, lCPI0_13@PAGE
Lloh21:
	ldr	q3, [x25, lCPI0_13@PAGEOFF]
	and.16b	v3, v0, v3
	str	q3, [sp, #80]                   ; 16-byte Spill
Lloh22:
	adrp	x25, lCPI0_14@PAGE
Lloh23:
	ldr	q3, [x25, lCPI0_14@PAGEOFF]
	and.16b	v3, v1, v3
	str	q3, [sp, #64]                   ; 16-byte Spill
Lloh24:
	adrp	x25, lCPI0_15@PAGE
Lloh25:
	ldr	q3, [x25, lCPI0_15@PAGEOFF]
	and.16b	v3, v1, v3
	str	q3, [sp, #96]                   ; 16-byte Spill
	fsub.4s	v6, v29, v2
	fsub.4s	v7, v30, v2
	add	x25, sp, #2160
	add	x26, x25, x11
	ldp	q2, q3, [x26]
	zip2.8b	v5, v27, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	stp	q7, q6, [sp, #112]              ; 32-byte Folded Spill
	bit.16b	v3, v7, v5
	zip1.8b	v5, v27, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	bit.16b	v2, v6, v5
	stp	q2, q3, [x26]
	ldr	q2, [sp, #2272]
	ldr	q3, [sp, #2256]
	fmul.4s	v3, v3, v3
	fmul.4s	v2, v2, v2
	and.16b	v10, v0, v2
	and.16b	v5, v1, v3
	ldr	q2, [sp, #2240]
	ldr	q3, [sp, #2224]
	fmul.4s	v3, v3, v3
	fmul.4s	v2, v2, v2
	and.16b	v2, v0, v2
	and.16b	v7, v1, v3
	ldr	q3, [sp, #2208]
	ldr	q16, [sp, #2192]
	fmul.4s	v16, v16, v16
	fmul.4s	v3, v3, v3
	and.16b	v22, v0, v3
	and.16b	v23, v1, v16
	add	x24, x25, x24
	ldp	q16, q3, [x24]
	fmul.4s	v16, v16, v16
	fmul.4s	v3, v3, v3
	and.16b	v27, v0, v3
	and.16b	v24, v1, v16
	mov	w24, #4                         ; =0x4
LBB0_34:                                ; %direct.true149
                                        ; =>This Inner Loop Header: Depth=1
	sshll.2d	v3, v1, #0
	sshll.2d	v16, v0, #0
	add	x23, x25, x23, lsl #5
	ldp	q29, q28, [x23]
	and.16b	v29, v1, v29
	and.16b	v28, v0, v28
	fmul.4s	v28, v28, v28
	fmul.4s	v29, v29, v29
	fadd.4s	v11, v24, v29
	fadd.4s	v12, v27, v28
	ldp	q29, q28, [x23, #32]
	and.16b	v29, v1, v29
	and.16b	v28, v0, v28
	fmul.4s	v28, v28, v28
	fmul.4s	v29, v29, v29
	fadd.4s	v29, v23, v29
	fadd.4s	v28, v22, v28
	ldp	q6, q30, [x23, #64]
	and.16b	v6, v1, v6
	and.16b	v30, v0, v30
	fmul.4s	v30, v30, v30
	fmul.4s	v6, v6, v6
	fadd.4s	v6, v7, v6
	fadd.4s	v30, v2, v30
	ldp	q14, q13, [x23, #96]
	and.16b	v14, v1, v14
	and.16b	v13, v0, v13
	fmul.4s	v13, v13, v13
	fmul.4s	v14, v14, v14
	fadd.4s	v14, v5, v14
	fadd.4s	v13, v10, v13
	dup.2d	v15, x24
	and.16b	v17, v26, v15
	add.2d	v4, v4, v17
	and.16b	v17, v25, v15
	add.2d	v31, v31, v17
	and.16b	v16, v16, v15
	add.2d	v8, v8, v16
	and.16b	v3, v3, v15
	add.2d	v9, v9, v3
	bit.16b	v27, v12, v0
	bit.16b	v24, v11, v1
	bit.16b	v22, v28, v0
	bit.16b	v23, v29, v1
	bit.16b	v2, v30, v0
	bit.16b	v7, v6, v1
	bit.16b	v10, v13, v0
	bit.16b	v5, v14, v1
	fmov	x23, d9
	cmp	x23, #8
	b.lt	LBB0_34
; %bb.35:                               ; %direct.true186.preheader
	mov	x25, #0                         ; =0x0
	movi.2d	v25, #0000000000000000
	ldr	q9, [sp, #272]                  ; 16-byte Reload
	fmov	w23, s9
	add	x24, sp, #1872
	movi.2d	v26, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v31, #0000000000000000
	ldr	q13, [sp, #336]                 ; 16-byte Reload
	b	LBB0_37
LBB0_36:                                ; %else114
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x25, x24, x25
	stp	q8, q4, [x25]
	add.2d	v26, v26, v19
	add.2d	v29, v29, v20
	add.2d	v31, v31, v18
	add.2d	v25, v25, v21
	fmov	x25, d25
	cmp	x25, #8
	b.ge	LBB0_53
LBB0_37:                                ; %direct.true186
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x25, x25, #5
	add	x26, x12, x25
	add	x28, x24, x25
	ldr	q8, [x28]
	tbnz	w23, #0, LBB0_45
; %bb.38:                               ; %else93
                                        ;   in Loop: Header=BB0_37 Depth=1
	and	w27, w23, #0xff
	tbnz	w27, #1, LBB0_46
LBB0_39:                                ; %else96
                                        ;   in Loop: Header=BB0_37 Depth=1
	tbnz	w27, #2, LBB0_47
LBB0_40:                                ; %else99
                                        ;   in Loop: Header=BB0_37 Depth=1
	tbnz	w27, #3, LBB0_48
LBB0_41:                                ; %else102
                                        ;   in Loop: Header=BB0_37 Depth=1
	ldr	q4, [x28, #16]
	tbnz	w27, #4, LBB0_49
LBB0_42:                                ; %else105
                                        ;   in Loop: Header=BB0_37 Depth=1
	tbnz	w27, #5, LBB0_50
LBB0_43:                                ; %else108
                                        ;   in Loop: Header=BB0_37 Depth=1
	tbnz	w27, #6, LBB0_51
LBB0_44:                                ; %else111
                                        ;   in Loop: Header=BB0_37 Depth=1
	tbz	w27, #7, LBB0_36
	b	LBB0_52
LBB0_45:                                ; %cond.load92
                                        ;   in Loop: Header=BB0_37 Depth=1
	ld1.s	{ v8 }[0], [x26]
	and	w27, w23, #0xff
	tbz	w27, #1, LBB0_39
LBB0_46:                                ; %cond.load95
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x30, x26, #4
	ld1.s	{ v8 }[1], [x30]
	tbz	w27, #2, LBB0_40
LBB0_47:                                ; %cond.load98
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x30, x26, #8
	ld1.s	{ v8 }[2], [x30]
	tbz	w27, #3, LBB0_41
LBB0_48:                                ; %cond.load101
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x30, x26, #12
	ld1.s	{ v8 }[3], [x30]
	ldr	q4, [x28, #16]
	tbz	w27, #4, LBB0_42
LBB0_49:                                ; %cond.load104
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x28, x26, #16
	ld1.s	{ v4 }[0], [x28]
	tbz	w27, #5, LBB0_43
LBB0_50:                                ; %cond.load107
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x28, x26, #20
	ld1.s	{ v4 }[1], [x28]
	tbz	w27, #6, LBB0_44
LBB0_51:                                ; %cond.load110
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x28, x26, #24
	ld1.s	{ v4 }[2], [x28]
	tbz	w27, #7, LBB0_36
LBB0_52:                                ; %cond.load113
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x26, x26, #28
	ld1.s	{ v4 }[3], [x26]
	b	LBB0_36
LBB0_53:                                ; %direct.false187
	zip2.8b	v3, v13, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldp	q4, q6, [sp, #112]              ; 32-byte Folded Reload
	and.16b	v25, v3, v4
	zip1.8b	v4, v13, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v26, v4, v6
	fmul.4s	v6, v26, v26
	fmul.4s	v16, v25, v25
	fadd.4s	v16, v16, v27
	fadd.4s	v6, v6, v24
	and.16b	v4, v4, v6
	and.16b	v3, v3, v16
	ldr	q16, [sp, #48]                  ; 16-byte Reload
	zip2.8b	v6, v16, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	bit.16b	v3, v12, v6
	zip1.8b	v6, v16, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	bit.16b	v4, v11, v6
	fadd.4s	v4, v23, v4
	fadd.4s	v3, v22, v3
	fadd.4s	v3, v2, v3
	fadd.4s	v2, v7, v4
	fadd.4s	v2, v5, v2
	fadd.4s	v5, v10, v3
	ldr	q4, [sp, #16]                   ; 16-byte Reload
	fmov	w23, s4
	add	x24, sp, #424
	bfxil	x24, x23, #0, #3
	ldr	q3, [sp, #304]                  ; 16-byte Reload
	str	d3, [sp, #424]
	ldrb	w24, [x24]
	and	x23, x23, #0x7
	stp	q2, q5, [sp, #912]
	add	x25, sp, #912
	ldr	s3, [x25, x23, lsl #2]
	tst	w21, w24
	movi.2d	v29, #0000000000000000
	mov.s	w23, v4[1]
	fcsel	s6, s3, s29, ne
	and	x24, x23, #0x7
	add	x25, sp, #424
	bfxil	x25, x23, #0, #3
	ldrb	w23, [x25]
	and	w23, w17, w23
	stp	q2, q5, [sp, #880]
	add	x25, sp, #880
	ldr	s3, [x25, x24, lsl #2]
	tst	w23, #0x1
	fcsel	s7, s3, s29, ne
	mov.s	w23, v4[2]
	and	x24, x23, #0x7
	add	x25, sp, #424
	bfxil	x25, x23, #0, #3
	ldrb	w23, [x25]
	stp	q2, q5, [sp, #848]
	add	x25, sp, #848
	ldr	s3, [x25, x24, lsl #2]
	and	w23, w16, w23
	tst	w23, #0x1
	fcsel	s22, s3, s29, ne
	mov.s	w23, v4[3]
	and	x24, x23, #0x7
	add	x25, sp, #424
	bfxil	x25, x23, #0, #3
	ldrb	w23, [x25]
	and	w23, w15, w23
	stp	q2, q5, [sp, #816]
	add	x25, sp, #816
	ldr	s3, [x25, x24, lsl #2]
	tst	w23, #0x1
	fcsel	s17, s3, s29, ne
	ldr	q23, [sp, #32]                  ; 16-byte Reload
	fmov	w23, s23
	and	x24, x23, #0x7
	add	x25, sp, #424
	bfxil	x25, x23, #0, #3
	ldrb	w23, [x25]
	and	w23, w4, w23
	str	q5, [sp, #1056]
	str	q2, [sp, #1040]
	add	x25, sp, #1040
	ldr	s3, [x25, x24, lsl #2]
	tst	w23, #0x1
	fcsel	s3, s3, s29, ne
	mov.s	w23, v23[1]
	and	x24, x23, #0x7
	add	x25, sp, #424
	bfxil	x25, x23, #0, #3
	ldrb	w23, [x25]
	and	w23, w3, w23
	stp	q2, q5, [sp, #1008]
	add	x25, sp, #1008
	ldr	s4, [x25, x24, lsl #2]
	tst	w23, #0x1
	fcsel	s4, s4, s29, ne
	mov.s	w23, v23[2]
	and	x24, x23, #0x7
	add	x25, sp, #424
	bfxil	x25, x23, #0, #3
	ldrb	w23, [x25]
	and	w23, w1, w23
	stp	q2, q5, [sp, #976]
	add	x25, sp, #976
	ldr	s16, [x25, x24, lsl #2]
	tst	w23, #0x1
	fcsel	s16, s16, s29, ne
	mov.s	w23, v23[3]
	and	x24, x23, #0x7
	add	x25, sp, #424
	bfxil	x25, x23, #0, #3
	ldrb	w23, [x25]
	and	w23, w2, w23
	stp	q2, q5, [sp, #944]
	add	x25, sp, #944
	ldr	s23, [x25, x24, lsl #2]
	tst	w23, #0x1
	fcsel	s23, s23, s29, ne
	mov.s	v3[1], v4[0]
	mov.s	v3[2], v16[0]
	mov.s	v3[3], v23[0]
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v22[0]
	mov.s	v6[3], v17[0]
	fadd.4s	v2, v2, v6
	fadd.4s	v5, v5, v3
	ldr	q4, [sp, #64]                   ; 16-byte Reload
	fmov	w23, s4
	add	x24, sp, #424
	bfxil	x24, x23, #0, #3
	ldrb	w24, [x24]
	and	x23, x23, #0x7
	stp	q2, q5, [sp, #656]
	add	x25, sp, #656
	ldr	s3, [x25, x23, lsl #2]
	tst	w21, w24
	fcsel	s6, s3, s29, ne
	mov.s	w23, v4[1]
	and	x24, x23, #0x7
	add	x25, sp, #424
	bfxil	x25, x23, #0, #3
	ldrb	w23, [x25]
	and	w17, w17, w23
	stp	q2, q5, [sp, #624]
	add	x23, sp, #624
	ldr	s3, [x23, x24, lsl #2]
	tst	w17, #0x1
	mov.s	w17, v4[2]
	fcsel	s7, s3, s29, ne
	and	x23, x17, #0x7
	add	x24, sp, #424
	bfxil	x24, x17, #0, #3
	ldrb	w17, [x24]
	and	w16, w16, w17
	stp	q2, q5, [sp, #592]
	add	x17, sp, #592
	ldr	s3, [x17, x23, lsl #2]
	tst	w16, #0x1
	fcsel	s17, s3, s29, ne
	mov.s	w16, v4[3]
	and	x17, x16, #0x7
	add	x23, sp, #424
	bfxil	x23, x16, #0, #3
	ldrb	w16, [x23]
	stp	q2, q5, [sp, #560]
	add	x23, sp, #560
	ldr	s3, [x23, x17, lsl #2]
	and	w15, w15, w16
	tst	w15, #0x1
	fcsel	s22, s3, s29, ne
	ldr	q23, [sp, #80]                  ; 16-byte Reload
	fmov	w15, s23
	and	x16, x15, #0x7
	add	x17, sp, #424
	bfxil	x17, x15, #0, #3
	ldrb	w15, [x17]
	and	w15, w4, w15
	stp	q2, q5, [sp, #784]
	add	x17, sp, #784
	ldr	s3, [x17, x16, lsl #2]
	tst	w15, #0x1
	fcsel	s3, s3, s29, ne
	mov.s	w15, v23[1]
	and	x16, x15, #0x7
	add	x17, sp, #424
	bfxil	x17, x15, #0, #3
	ldrb	w15, [x17]
	and	w15, w3, w15
	stp	q2, q5, [sp, #752]
	add	x17, sp, #752
	ldr	s4, [x17, x16, lsl #2]
	tst	w15, #0x1
	fcsel	s4, s4, s29, ne
	mov.s	w15, v23[2]
	and	x16, x15, #0x7
	add	x17, sp, #424
	bfxil	x17, x15, #0, #3
	ldrb	w15, [x17]
	and	w15, w1, w15
	stp	q2, q5, [sp, #720]
	add	x17, sp, #720
	ldr	s16, [x17, x16, lsl #2]
	tst	w15, #0x1
	fcsel	s16, s16, s29, ne
	mov.s	w15, v23[3]
	and	x16, x15, #0x7
	add	x17, sp, #424
	bfxil	x17, x15, #0, #3
	ldrb	w15, [x17]
	and	w15, w2, w15
	stp	q2, q5, [sp, #688]
	add	x17, sp, #688
	ldr	s23, [x17, x16, lsl #2]
	tst	w15, #0x1
	fcsel	s23, s23, s29, ne
	mov.s	v3[1], v4[0]
	mov.s	v3[2], v16[0]
	mov.s	v3[3], v23[0]
	mov.s	v6[1], v7[0]
	add	x15, sp, #424
	mov.s	v6[2], v17[0]
	mov.s	v6[3], v22[0]
	fadd.4s	v2, v2, v6
	fadd.4s	v3, v5, v3
	ldr	q4, [sp, #96]                   ; 16-byte Reload
	fmov	w16, s4
	bfxil	x15, x16, #0, #3
	ldrb	w15, [x15]
	and	x16, x16, #0x7
	stp	q2, q3, [sp, #528]
	add	x17, sp, #528
	ldr	s3, [x17, x16, lsl #2]
	tst	w21, w15
	fcsel	s3, s3, s29, ne
	tst	w13, #0x1
Lloh26:
	adrp	x13, lCPI0_16@PAGE
Lloh27:
	ldr	d4, [x13, lCPI0_16@PAGEOFF]
	shl.8b	v5, v13, #7
	cmlt.8b	v5, v5, #0
	and.8b	v4, v5, v4
	addv.8b	b28, v4
	fmov	w15, s28
	fadd	s2, s2, s3
	fcsel	s3, s2, s29, ne
	tst	w5, #0x1
	fcsel	s4, s2, s29, ne
	tst	w6, #0x1
	fcsel	s5, s2, s29, ne
	tst	w7, #0x1
	fcsel	s6, s2, s29, ne
	tst	w0, #0x1
	fcsel	s7, s2, s29, ne
	tst	w19, #0x1
	fcsel	s16, s2, s29, ne
	tst	w20, #0x1
	fcsel	s17, s2, s29, ne
	tst	w22, #0x1
	fcsel	s2, s2, s29, ne
	mov.s	v3[1], v4[0]
	mov.s	v3[2], v5[0]
	mov.s	v3[3], v6[0]
	mov.s	v7[1], v16[0]
	mov.s	v7[2], v17[0]
	mov.s	v7[3], v2[0]
	stp	q3, q7, [sp, #496]
	and	x13, x14, #0x7
	add	x14, sp, #496
	ldr	s2, [x14, x13, lsl #2]
	mov	b3, v13[0]
	mov.b	v3[4], v13[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldp	q7, q4, [sp, #176]              ; 32-byte Folded Reload
	and.16b	v3, v3, v4
	mov	b4, v13[2]
	mov.b	v4[4], v13[3]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	ldp	q5, q6, [sp, #144]              ; 32-byte Folded Reload
	and.16b	v4, v4, v5
	mov	b5, v13[4]
	mov.b	v5[4], v13[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	and.16b	v5, v5, v6
	mov	b6, v13[6]
	mov.b	v6[4], v13[7]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	and.16b	v6, v6, v7
	stp	q5, q6, [sp, #464]
	stp	q3, q4, [sp, #432]
	and	x13, x9, #0x7
	add	x14, sp, #432
	ldr	x13, [x14, x13, lsl #3]
	sub	x13, x13, x9
	lsl	x13, x13, #2
	add	x12, x12, x13
	add	x14, sp, #1872
	add	x14, x14, x11
	ldr	q22, [x14]
	tbnz	w15, #0, LBB0_133
; %bb.54:                               ; %else118
	ldr	q16, [sp, #320]                 ; 16-byte Reload
	tbnz	w15, #1, LBB0_134
LBB0_55:                                ; %else121
	tbnz	w15, #2, LBB0_135
LBB0_56:                                ; %else124
	tbnz	w15, #3, LBB0_136
LBB0_57:                                ; %else127
	ldr	q23, [x14, #16]
	tbnz	w15, #4, LBB0_137
LBB0_58:                                ; %else130
	mov	w14, #1115815936                ; =0x42820000
	tbnz	w15, #5, LBB0_138
LBB0_59:                                ; %else133
	fadd	s2, s2, s29
	fmov	s4, w14
	tbnz	w15, #6, LBB0_139
LBB0_60:                                ; %else136
	fdiv	s2, s2, s4
	tbz	w15, #7, LBB0_62
LBB0_61:                                ; %cond.load138
	add	x12, x12, #28
	ld1.s	{ v23 }[3], [x12]
LBB0_62:                                ; %else139
	add	x12, sp, #1872
	add	x14, x12, x11
	stp	q22, q23, [x14]
	mov	w14, #50604                     ; =0xc5ac
	movk	w14, #14119, lsl #16
	fmov	s3, w14
	fadd	s2, s2, s3
	subs	x14, x8, x10
	cset	w15, hs
	cmp	x14, #259
	csel	w14, wzr, w15, ls
	subs	x15, x10, x8
	lsr	x15, x15, #2
	mov	w16, #1104                      ; =0x450
	ccmp	x15, x16, #0, hs
	fsqrt	s2, s2
	b.hi	LBB0_83
; %bb.63:                               ; %else139
	tbnz	w14, #0, LBB0_83
; %bb.64:                               ; %direct.true256.preheader
	mov	x15, #0                         ; =0x0
	movi.2d	v5, #0000000000000000
	fmov	w12, s9
	add	x14, sp, #1584
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	b	LBB0_66
LBB0_65:                                ; %else231
                                        ;   in Loop: Header=BB0_66 Depth=1
	add	x15, x14, x15
	stp	q17, q4, [x15]
	add.2d	v6, v6, v19
	add.2d	v7, v7, v20
	add.2d	v16, v16, v18
	add.2d	v5, v5, v21
	fmov	x15, d5
	cmp	x15, #8
	b.ge	LBB0_140
LBB0_66:                                ; %direct.true256
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x15, x15, #5
	add	x16, x10, x15
	add	x0, x14, x15
	ldr	q17, [x0]
	tbnz	w12, #0, LBB0_74
; %bb.67:                               ; %else210
                                        ;   in Loop: Header=BB0_66 Depth=1
	and	w17, w12, #0xff
	tbnz	w17, #1, LBB0_75
LBB0_68:                                ; %else213
                                        ;   in Loop: Header=BB0_66 Depth=1
	tbnz	w17, #2, LBB0_76
LBB0_69:                                ; %else216
                                        ;   in Loop: Header=BB0_66 Depth=1
	tbnz	w17, #3, LBB0_77
LBB0_70:                                ; %else219
                                        ;   in Loop: Header=BB0_66 Depth=1
	ldr	q4, [x0, #16]
	tbnz	w17, #4, LBB0_78
LBB0_71:                                ; %else222
                                        ;   in Loop: Header=BB0_66 Depth=1
	tbnz	w17, #5, LBB0_79
LBB0_72:                                ; %else225
                                        ;   in Loop: Header=BB0_66 Depth=1
	tbnz	w17, #6, LBB0_80
LBB0_73:                                ; %else228
                                        ;   in Loop: Header=BB0_66 Depth=1
	tbz	w17, #7, LBB0_65
	b	LBB0_81
LBB0_74:                                ; %cond.load209
                                        ;   in Loop: Header=BB0_66 Depth=1
	ld1.s	{ v17 }[0], [x16]
	and	w17, w12, #0xff
	tbz	w17, #1, LBB0_68
LBB0_75:                                ; %cond.load212
                                        ;   in Loop: Header=BB0_66 Depth=1
	add	x1, x16, #4
	ld1.s	{ v17 }[1], [x1]
	tbz	w17, #2, LBB0_69
LBB0_76:                                ; %cond.load215
                                        ;   in Loop: Header=BB0_66 Depth=1
	add	x1, x16, #8
	ld1.s	{ v17 }[2], [x1]
	tbz	w17, #3, LBB0_70
LBB0_77:                                ; %cond.load218
                                        ;   in Loop: Header=BB0_66 Depth=1
	add	x1, x16, #12
	ld1.s	{ v17 }[3], [x1]
	ldr	q4, [x0, #16]
	tbz	w17, #4, LBB0_71
LBB0_78:                                ; %cond.load221
                                        ;   in Loop: Header=BB0_66 Depth=1
	add	x0, x16, #16
	ld1.s	{ v4 }[0], [x0]
	tbz	w17, #5, LBB0_72
LBB0_79:                                ; %cond.load224
                                        ;   in Loop: Header=BB0_66 Depth=1
	add	x0, x16, #20
	ld1.s	{ v4 }[1], [x0]
	tbz	w17, #6, LBB0_73
LBB0_80:                                ; %cond.load227
                                        ;   in Loop: Header=BB0_66 Depth=1
	add	x0, x16, #24
	ld1.s	{ v4 }[2], [x0]
	tbz	w17, #7, LBB0_65
LBB0_81:                                ; %cond.load230
                                        ;   in Loop: Header=BB0_66 Depth=1
	add	x16, x16, #28
	ld1.s	{ v4 }[3], [x16]
	b	LBB0_65
LBB0_82:                                ; %common.ret
	ret
LBB0_83:                                ; %direct.schedule.27.preheader
	mov	x15, #0                         ; =0x0
	ldr	q3, [sp, #208]                  ; 16-byte Reload
	add.2d	v5, v16, v3
	dup.4s	v17, v2[0]
	movi.2d	v2, #0000000000000000
	fmov	w11, s9
	add	x14, sp, #2160
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v24, #0000000000000000
	b	LBB0_85
LBB0_84:                                ; %else182
                                        ;   in Loop: Header=BB0_85 Depth=1
	add.2d	v6, v6, v19
	add.2d	v7, v7, v20
	add.2d	v24, v24, v18
	add.2d	v2, v2, v21
	fmov	x15, d2
	cmp	x15, #8
	b.ge	LBB0_117
LBB0_85:                                ; %direct.true214
                                        ; =>This Inner Loop Header: Depth=1
	shl.2d	v29, v2, #3
	orr.16b	v3, v29, v16
	fmov	x16, d3
	add	x16, x10, x16, lsl #2
	movi.2d	v30, #0000000000000000
	movi.2d	v27, #0000000000000000
	tbnz	w11, #0, LBB0_102
; %bb.86:                               ; %else143
                                        ;   in Loop: Header=BB0_85 Depth=1
	and	w17, w11, #0xff
	tbnz	w17, #1, LBB0_103
LBB0_87:                                ; %else146
                                        ;   in Loop: Header=BB0_85 Depth=1
	tbnz	w17, #2, LBB0_104
LBB0_88:                                ; %else149
                                        ;   in Loop: Header=BB0_85 Depth=1
	tbnz	w17, #3, LBB0_105
LBB0_89:                                ; %else152
                                        ;   in Loop: Header=BB0_85 Depth=1
	tbnz	w17, #4, LBB0_106
LBB0_90:                                ; %else155
                                        ;   in Loop: Header=BB0_85 Depth=1
	tbnz	w17, #5, LBB0_107
LBB0_91:                                ; %else158
                                        ;   in Loop: Header=BB0_85 Depth=1
	tbnz	w17, #6, LBB0_108
LBB0_92:                                ; %else161
                                        ;   in Loop: Header=BB0_85 Depth=1
	tbz	w17, #7, LBB0_94
LBB0_93:                                ; %cond.load163
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x16, x16, #28
	ld1.s	{ v27 }[3], [x16]
LBB0_94:                                ; %else164
                                        ;   in Loop: Header=BB0_85 Depth=1
	lsl	x15, x15, #5
	add	x17, x14, x15
	ldr	q3, [x17]
	and.16b	v3, v1, v3
	fdiv.4s	v3, v3, v17
	add	x0, x12, x15
	ldr	q4, [x0]
	and.16b	v4, v1, v4
	fmul.4s	v3, v3, v4
	fmov	w16, s9
	fadd.4s	v4, v30, v3
	add.2d	v3, v29, v5
	fmov	x15, d3
	add	x15, x8, x15, lsl #2
	tbnz	w16, #0, LBB0_109
; %bb.95:                               ; %else168
                                        ;   in Loop: Header=BB0_85 Depth=1
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_110
LBB0_96:                                ; %else170
                                        ;   in Loop: Header=BB0_85 Depth=1
	ldr	q30, [x17, #16]
	ldr	q29, [x0, #16]
	tbnz	w16, #2, LBB0_111
LBB0_97:                                ; %else172
                                        ;   in Loop: Header=BB0_85 Depth=1
	tbnz	w16, #3, LBB0_112
LBB0_98:                                ; %else174
                                        ;   in Loop: Header=BB0_85 Depth=1
	and.16b	v3, v0, v30
	fdiv.4s	v3, v3, v17
	and.16b	v4, v0, v29
	fmul.4s	v3, v3, v4
	fadd.4s	v4, v27, v3
	tbnz	w16, #4, LBB0_113
LBB0_99:                                ; %else176
                                        ;   in Loop: Header=BB0_85 Depth=1
	tbnz	w16, #5, LBB0_114
LBB0_100:                               ; %else178
                                        ;   in Loop: Header=BB0_85 Depth=1
	tbnz	w16, #6, LBB0_115
LBB0_101:                               ; %else180
                                        ;   in Loop: Header=BB0_85 Depth=1
	tbz	w16, #7, LBB0_84
	b	LBB0_116
LBB0_102:                               ; %cond.load142
                                        ;   in Loop: Header=BB0_85 Depth=1
	ldr	s30, [x16]
	and	w17, w11, #0xff
	tbz	w17, #1, LBB0_87
LBB0_103:                               ; %cond.load145
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x0, x16, #4
	ld1.s	{ v30 }[1], [x0]
	tbz	w17, #2, LBB0_88
LBB0_104:                               ; %cond.load148
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x0, x16, #8
	ld1.s	{ v30 }[2], [x0]
	tbz	w17, #3, LBB0_89
LBB0_105:                               ; %cond.load151
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x0, x16, #12
	ld1.s	{ v30 }[3], [x0]
	tbz	w17, #4, LBB0_90
LBB0_106:                               ; %cond.load154
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x0, x16, #16
	ld1.s	{ v27 }[0], [x0]
	tbz	w17, #5, LBB0_91
LBB0_107:                               ; %cond.load157
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x0, x16, #20
	ld1.s	{ v27 }[1], [x0]
	tbz	w17, #6, LBB0_92
LBB0_108:                               ; %cond.load160
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x0, x16, #24
	ld1.s	{ v27 }[2], [x0]
	tbnz	w17, #7, LBB0_93
	b	LBB0_94
LBB0_109:                               ; %cond.store167
                                        ;   in Loop: Header=BB0_85 Depth=1
	str	s4, [x15]
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_96
LBB0_110:                               ; %cond.store169
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x1, x15, #4
	st1.s	{ v4 }[1], [x1]
	ldr	q30, [x17, #16]
	ldr	q29, [x0, #16]
	tbz	w16, #2, LBB0_97
LBB0_111:                               ; %cond.store171
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x17, x15, #8
	st1.s	{ v4 }[2], [x17]
	tbz	w16, #3, LBB0_98
LBB0_112:                               ; %cond.store173
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x17, x15, #12
	st1.s	{ v4 }[3], [x17]
	and.16b	v3, v0, v30
	fdiv.4s	v3, v3, v17
	and.16b	v4, v0, v29
	fmul.4s	v3, v3, v4
	fadd.4s	v4, v27, v3
	tbz	w16, #4, LBB0_99
LBB0_113:                               ; %cond.store175
                                        ;   in Loop: Header=BB0_85 Depth=1
	str	s4, [x15, #16]
	tbz	w16, #5, LBB0_100
LBB0_114:                               ; %cond.store177
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x17, x15, #20
	st1.s	{ v4 }[1], [x17]
	tbz	w16, #6, LBB0_101
LBB0_115:                               ; %cond.store179
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x17, x15, #24
	st1.s	{ v4 }[2], [x17]
	tbz	w16, #7, LBB0_84
LBB0_116:                               ; %cond.store181
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x15, x15, #28
	st1.s	{ v4 }[3], [x15]
	b	LBB0_84
LBB0_117:                               ; %direct.false215
	fmov	w11, s28
	add	x10, x10, x13
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	tbnz	w11, #0, LBB0_185
; %bb.118:                              ; %else185
	tbnz	w11, #1, LBB0_186
LBB0_119:                               ; %else188
	zip1.8b	v2, v13, v0
	zip2.8b	v3, v13, v0
	tbnz	w11, #2, LBB0_187
LBB0_120:                               ; %else191
	ushll.4s	v2, v2, #0
	ushll.4s	v3, v3, #0
	tbnz	w11, #3, LBB0_188
LBB0_121:                               ; %else194
	shl.4s	v2, v2, #31
	shl.4s	v4, v3, #31
	tbnz	w11, #4, LBB0_189
LBB0_122:                               ; %else197
	cmlt.4s	v3, v2, #0
	cmlt.4s	v4, v4, #0
	tbnz	w11, #5, LBB0_190
LBB0_123:                               ; %else200
	fdiv.4s	v2, v26, v17
	fdiv.4s	v5, v25, v17
	and.16b	v6, v3, v22
	and.16b	v3, v4, v23
	tbnz	w11, #6, LBB0_191
LBB0_124:                               ; %else203
	fmul.4s	v3, v5, v3
	fmul.4s	v2, v2, v6
	tbz	w11, #7, LBB0_126
LBB0_125:                               ; %cond.load205
	add	x10, x10, #28
	ld1.s	{ v1 }[3], [x10]
LBB0_126:                               ; %else206
	fadd.4s	v2, v2, v0
	fadd.4s	v0, v3, v1
	b	LBB0_168
LBB0_127:                               ; %cond.load67
	ld1.s	{ v24 }[0], [x15]
	tbz	w13, #1, LBB0_21
LBB0_128:                               ; %cond.load70
	add	x17, x15, #4
	ld1.s	{ v24 }[1], [x17]
	tbz	w13, #2, LBB0_22
LBB0_129:                               ; %cond.load73
	add	x17, x15, #8
	ld1.s	{ v24 }[2], [x17]
	tbz	w13, #3, LBB0_23
LBB0_130:                               ; %cond.load76
	add	x17, x15, #12
	ld1.s	{ v24 }[3], [x17]
	adrp	x17, lCPI0_3@PAGE
	adrp	x0, lCPI0_4@PAGE
	adrp	x1, lCPI0_5@PAGE
	ldr	q27, [x16, #16]
	tbz	w13, #4, LBB0_24
LBB0_131:                               ; %cond.load79
	add	x16, x15, #16
	ld1.s	{ v27 }[0], [x16]
	ldr	q4, [x17, lCPI0_3@PAGEOFF]
	ldr	q18, [x0, lCPI0_4@PAGEOFF]
	ldr	q23, [x1, lCPI0_5@PAGEOFF]
	tbz	w13, #5, LBB0_25
LBB0_132:                               ; %cond.load82
	add	x16, x15, #20
	ld1.s	{ v27 }[1], [x16]
	and.16b	v3, v26, v4
	and.16b	v4, v25, v18
	and.16b	v17, v19, v23
	tbnz	w13, #6, LBB0_26
	b	LBB0_27
LBB0_133:                               ; %cond.load117
	ld1.s	{ v22 }[0], [x12]
	ldr	q16, [sp, #320]                 ; 16-byte Reload
	tbz	w15, #1, LBB0_55
LBB0_134:                               ; %cond.load120
	add	x16, x12, #4
	ld1.s	{ v22 }[1], [x16]
	tbz	w15, #2, LBB0_56
LBB0_135:                               ; %cond.load123
	add	x16, x12, #8
	ld1.s	{ v22 }[2], [x16]
	tbz	w15, #3, LBB0_57
LBB0_136:                               ; %cond.load126
	add	x16, x12, #12
	ld1.s	{ v22 }[3], [x16]
	ldr	q23, [x14, #16]
	tbz	w15, #4, LBB0_58
LBB0_137:                               ; %cond.load129
	add	x14, x12, #16
	ld1.s	{ v23 }[0], [x14]
	mov	w14, #1115815936                ; =0x42820000
	tbz	w15, #5, LBB0_59
LBB0_138:                               ; %cond.load132
	add	x16, x12, #20
	ld1.s	{ v23 }[1], [x16]
	fadd	s2, s2, s29
	fmov	s4, w14
	tbz	w15, #6, LBB0_60
LBB0_139:                               ; %cond.load135
	add	x14, x12, #24
	ld1.s	{ v23 }[2], [x14]
	fdiv	s2, s2, s4
	tbnz	w15, #7, LBB0_61
	b	LBB0_62
LBB0_140:                               ; %direct.false257
	add	x10, x10, x13
	add	x12, sp, #1584
	add	x13, x12, x11
	ldr	q5, [x13]
	fmov	w12, s28
	tbnz	w12, #0, LBB0_192
; %bb.141:                              ; %else235
	tbnz	w12, #1, LBB0_193
LBB0_142:                               ; %else238
	tbnz	w12, #2, LBB0_194
LBB0_143:                               ; %else241
	tbnz	w12, #3, LBB0_195
LBB0_144:                               ; %else244
	ldr	q6, [x13, #16]
	tbnz	w12, #4, LBB0_196
LBB0_145:                               ; %else247
	tbnz	w12, #5, LBB0_197
LBB0_146:                               ; %else250
	tbnz	w12, #6, LBB0_198
LBB0_147:                               ; %else253
	tbz	w12, #7, LBB0_149
LBB0_148:                               ; %cond.load255
	add	x10, x10, #28
	ld1.s	{ v6 }[3], [x10]
LBB0_149:                               ; %else256
	mov	x15, #0                         ; =0x0
	add	x10, sp, #1584
	add	x11, x10, x11
	stp	q5, q6, [x11]
	dup.4s	v2, v2[0]
	ldr	q3, [sp, #208]                  ; 16-byte Reload
	fmov	x11, d3
	add	x11, x8, x11, lsl #2
	movi.2d	v7, #0000000000000000
	fmov	w12, s9
	add	x13, sp, #2160
	add	x14, sp, #1872
	movi.2d	v3, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	b	LBB0_151
LBB0_150:                               ; %else274
                                        ;   in Loop: Header=BB0_151 Depth=1
	add.2d	v3, v3, v19
	add.2d	v16, v16, v20
	add.2d	v17, v17, v18
	add.2d	v7, v7, v21
	fmov	x15, d7
	cmp	x15, #8
	b.ge	LBB0_167
LBB0_151:                               ; %direct.true281
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x15, x15, #5
	add	x17, x13, x15
	ldr	q4, [x17]
	and.16b	v4, v1, v4
	fdiv.4s	v4, v4, v2
	add	x0, x14, x15
	ldr	q24, [x0]
	and.16b	v24, v1, v24
	fmul.4s	v4, v4, v24
	add	x1, x10, x15
	ldr	q24, [x1]
	and.16b	v24, v1, v24
	fadd.4s	v4, v4, v24
	add	x15, x11, x15
	tbnz	w12, #0, LBB0_160
; %bb.152:                              ; %else260
                                        ;   in Loop: Header=BB0_151 Depth=1
	and	w16, w12, #0xff
	tbnz	w16, #1, LBB0_161
LBB0_153:                               ; %else262
                                        ;   in Loop: Header=BB0_151 Depth=1
	tbnz	w16, #2, LBB0_162
LBB0_154:                               ; %else264
                                        ;   in Loop: Header=BB0_151 Depth=1
	tbz	w16, #3, LBB0_156
LBB0_155:                               ; %cond.store265
                                        ;   in Loop: Header=BB0_151 Depth=1
	add	x2, x15, #12
	st1.s	{ v4 }[3], [x2]
LBB0_156:                               ; %else266
                                        ;   in Loop: Header=BB0_151 Depth=1
	ldr	q4, [x17, #16]
	and.16b	v4, v0, v4
	fdiv.4s	v4, v4, v2
	ldr	q24, [x0, #16]
	and.16b	v24, v0, v24
	fmul.4s	v4, v4, v24
	ldr	q24, [x1, #16]
	and.16b	v24, v0, v24
	fadd.4s	v4, v4, v24
	tbnz	w16, #4, LBB0_163
; %bb.157:                              ; %else268
                                        ;   in Loop: Header=BB0_151 Depth=1
	tbnz	w16, #5, LBB0_164
LBB0_158:                               ; %else270
                                        ;   in Loop: Header=BB0_151 Depth=1
	tbnz	w16, #6, LBB0_165
LBB0_159:                               ; %else272
                                        ;   in Loop: Header=BB0_151 Depth=1
	tbz	w16, #7, LBB0_150
	b	LBB0_166
LBB0_160:                               ; %cond.store259
                                        ;   in Loop: Header=BB0_151 Depth=1
	str	s4, [x15]
	and	w16, w12, #0xff
	tbz	w16, #1, LBB0_153
LBB0_161:                               ; %cond.store261
                                        ;   in Loop: Header=BB0_151 Depth=1
	add	x2, x15, #4
	st1.s	{ v4 }[1], [x2]
	tbz	w16, #2, LBB0_154
LBB0_162:                               ; %cond.store263
                                        ;   in Loop: Header=BB0_151 Depth=1
	add	x2, x15, #8
	st1.s	{ v4 }[2], [x2]
	tbnz	w16, #3, LBB0_155
	b	LBB0_156
LBB0_163:                               ; %cond.store267
                                        ;   in Loop: Header=BB0_151 Depth=1
	str	s4, [x15, #16]
	tbz	w16, #5, LBB0_158
LBB0_164:                               ; %cond.store269
                                        ;   in Loop: Header=BB0_151 Depth=1
	add	x17, x15, #20
	st1.s	{ v4 }[1], [x17]
	tbz	w16, #6, LBB0_159
LBB0_165:                               ; %cond.store271
                                        ;   in Loop: Header=BB0_151 Depth=1
	add	x17, x15, #24
	st1.s	{ v4 }[2], [x17]
	tbz	w16, #7, LBB0_150
LBB0_166:                               ; %cond.store273
                                        ;   in Loop: Header=BB0_151 Depth=1
	add	x15, x15, #28
	st1.s	{ v4 }[3], [x15]
	b	LBB0_150
LBB0_167:                               ; %direct.false282
	fdiv.4s	v0, v25, v2
	fdiv.4s	v1, v26, v2
	zip2.8b	v2, v13, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	and.16b	v3, v2, v23
	zip1.8b	v4, v13, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v7, v4, v22
	fmul.4s	v1, v1, v7
	fmul.4s	v0, v0, v3
	and.16b	v3, v4, v5
	and.16b	v2, v2, v6
	fadd.4s	v0, v0, v2
	fadd.4s	v2, v1, v3
LBB0_168:                               ; %common.ret.sink.split
	ldr	q3, [sp, #288]                  ; 16-byte Reload
	ldp	q5, q4, [sp, #224]              ; 32-byte Folded Reload
	stp	q3, q4, [sp, #352]
	ldr	q1, [sp, #256]                  ; 16-byte Reload
	stp	q5, q1, [sp, #384]
	and	x10, x9, #0x7
	add	x11, sp, #352
	ldr	x10, [x11, x10, lsl #3]
	sub	x9, x10, x9
	add	x8, x8, x9, lsl #2
	fmov	w9, s28
	tbnz	w9, #0, LBB0_178
; %bb.169:                              ; %else
	tbnz	w9, #1, LBB0_179
LBB0_170:                               ; %else30
	tbnz	w9, #2, LBB0_180
LBB0_171:                               ; %else32
	tbnz	w9, #3, LBB0_181
LBB0_172:                               ; %else34
	tbnz	w9, #4, LBB0_182
LBB0_173:                               ; %else36
	tbnz	w9, #5, LBB0_183
LBB0_174:                               ; %else38
	tbnz	w9, #6, LBB0_184
LBB0_175:                               ; %else40
	tbz	w9, #7, LBB0_177
LBB0_176:                               ; %cond.store41
	add	x8, x8, #28
	st1.s	{ v0 }[3], [x8]
LBB0_177:
	add	sp, sp, #2736
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
LBB0_178:                               ; %cond.store
	str	s2, [x8]
	tbz	w9, #1, LBB0_170
LBB0_179:                               ; %cond.store29
	add	x10, x8, #4
	st1.s	{ v2 }[1], [x10]
	tbz	w9, #2, LBB0_171
LBB0_180:                               ; %cond.store31
	add	x10, x8, #8
	st1.s	{ v2 }[2], [x10]
	tbz	w9, #3, LBB0_172
LBB0_181:                               ; %cond.store33
	add	x10, x8, #12
	st1.s	{ v2 }[3], [x10]
	tbz	w9, #4, LBB0_173
LBB0_182:                               ; %cond.store35
	str	s0, [x8, #16]
	tbz	w9, #5, LBB0_174
LBB0_183:                               ; %cond.store37
	add	x10, x8, #20
	st1.s	{ v0 }[1], [x10]
	tbz	w9, #6, LBB0_175
LBB0_184:                               ; %cond.store39
	add	x10, x8, #24
	st1.s	{ v0 }[2], [x10]
	tbnz	w9, #7, LBB0_176
	b	LBB0_177
LBB0_185:                               ; %cond.load184
	ldr	s0, [x10]
	tbz	w11, #1, LBB0_119
LBB0_186:                               ; %cond.load187
	add	x12, x10, #4
	ld1.s	{ v0 }[1], [x12]
	zip1.8b	v2, v13, v0
	zip2.8b	v3, v13, v0
	tbz	w11, #2, LBB0_120
LBB0_187:                               ; %cond.load190
	add	x12, x10, #8
	ld1.s	{ v0 }[2], [x12]
	ushll.4s	v2, v2, #0
	ushll.4s	v3, v3, #0
	tbz	w11, #3, LBB0_121
LBB0_188:                               ; %cond.load193
	add	x12, x10, #12
	ld1.s	{ v0 }[3], [x12]
	shl.4s	v2, v2, #31
	shl.4s	v4, v3, #31
	tbz	w11, #4, LBB0_122
LBB0_189:                               ; %cond.load196
	add	x12, x10, #16
	ld1.s	{ v1 }[0], [x12]
	cmlt.4s	v3, v2, #0
	cmlt.4s	v4, v4, #0
	tbz	w11, #5, LBB0_123
LBB0_190:                               ; %cond.load199
	add	x12, x10, #20
	ld1.s	{ v1 }[1], [x12]
	fdiv.4s	v2, v26, v17
	fdiv.4s	v5, v25, v17
	and.16b	v6, v3, v22
	and.16b	v3, v4, v23
	tbz	w11, #6, LBB0_124
LBB0_191:                               ; %cond.load202
	add	x12, x10, #24
	ld1.s	{ v1 }[2], [x12]
	fmul.4s	v3, v5, v3
	fmul.4s	v2, v2, v6
	tbnz	w11, #7, LBB0_125
	b	LBB0_126
LBB0_192:                               ; %cond.load234
	ld1.s	{ v5 }[0], [x10]
	tbz	w12, #1, LBB0_142
LBB0_193:                               ; %cond.load237
	add	x14, x10, #4
	ld1.s	{ v5 }[1], [x14]
	tbz	w12, #2, LBB0_143
LBB0_194:                               ; %cond.load240
	add	x14, x10, #8
	ld1.s	{ v5 }[2], [x14]
	tbz	w12, #3, LBB0_144
LBB0_195:                               ; %cond.load243
	add	x14, x10, #12
	ld1.s	{ v5 }[3], [x14]
	ldr	q6, [x13, #16]
	tbz	w12, #4, LBB0_145
LBB0_196:                               ; %cond.load246
	add	x13, x10, #16
	ld1.s	{ v6 }[0], [x13]
	tbz	w12, #5, LBB0_146
LBB0_197:                               ; %cond.load249
	add	x13, x10, #20
	ld1.s	{ v6 }[1], [x13]
	tbz	w12, #6, LBB0_147
LBB0_198:                               ; %cond.load252
	add	x13, x10, #24
	ld1.s	{ v6 }[2], [x13]
	tbnz	w12, #7, LBB0_148
	b	LBB0_149
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpLdr	Lloh26, Lloh27
                                        ; -- End function
	.p2align	2                               ; -- Begin function llm_rows.full_packet
_llm_rows.full_packet:                  ; @llm_rows.full_packet
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-80]!           ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #592
	ldr	x9, [x0]
	ldr	x13, [x0, #16]
	ldr	x10, [x0, #32]
	ldr	w8, [x1]
	ldr	w11, [x1, #36]
	add	w8, w11, w8, lsl #5
	lsr	w8, w8, #3
	fmov	s0, w8
	ushll.2d	v0, v0, #0
	fmov	x12, d0
	add	x8, x12, x12, lsl #6
	lsl	x11, x8, #2
	add	x8, x9, x11
	ldp	q6, q7, [x8]
	ldp	q17, q16, [x8, #32]
	ldp	q18, q19, [x8, #64]
	ldp	q29, q28, [x8, #96]
	ldp	q30, q31, [x8, #128]
	ldp	q8, q4, [x8, #160]
	ldp	q2, q3, [x8, #192]
	ldp	q1, q0, [x8, #224]
	add	x8, x11, #256
	ldr	s27, [x9, x8]
	fadd.4s	v5, v29, v1
	fadd.4s	v20, v28, v0
	fadd.4s	v21, v19, v3
	fadd.4s	v22, v18, v2
	fadd.4s	v23, v17, v8
	fadd.4s	v24, v16, v4
	fadd.4s	v25, v7, v31
	fadd.4s	v26, v6, v30
	fadd.4s	v9, v27, v26
	mov.s	v26[0], v9[0]
	fadd.4s	v24, v24, v25
	fadd.4s	v23, v23, v26
	fadd.4s	v22, v22, v23
	fadd.4s	v21, v21, v24
	fadd.4s	v20, v20, v21
	fadd.4s	v5, v5, v22
	rev64.4s	v21, v5
	rev64.4s	v22, v20
	fadd.4s	v20, v20, v22
	fadd.4s	v5, v5, v21
	dup.4s	v21, v5[2]
	dup.4s	v22, v20[2]
	ldr	x9, [x0, #48]
	fadd.4s	v20, v20, v22
	fadd.4s	v5, v5, v21
	fadd.4s	v20, v5, v20
	movi.2d	v5, #0000000000000000
	fadd	s20, s20, s5
	mov	w14, #1115815936                ; =0x42820000
	fmov	s26, w14
	fdiv	s20, s20, s26
	dup.4s	v9, v20[0]
	fsub.4s	v25, v6, v9
	fsub.4s	v24, v7, v9
	stp	q25, q24, [sp, #304]
	fsub.4s	v23, v17, v9
	fsub.4s	v22, v16, v9
	stp	q23, q22, [sp, #336]
	fsub.4s	v21, v18, v9
	fsub.4s	v20, v19, v9
	stp	q21, q20, [sp, #368]
	fsub.4s	v19, v29, v9
	fsub.4s	v18, v28, v9
	stp	q19, q18, [sp, #400]
	fsub.4s	v17, v30, v9
	fsub.4s	v16, v31, v9
	stp	q17, q16, [sp, #432]
	fsub.4s	v7, v8, v9
	fsub.4s	v6, v4, v9
	stp	q7, q6, [sp, #464]
	fsub.4s	v4, v2, v9
	fsub.4s	v3, v3, v9
	stp	q4, q3, [sp, #496]
	fsub.4s	v2, v1, v9
	fsub.4s	v1, v0, v9
	stp	q2, q1, [sp, #528]
	fsub.4s	v13, v27, v9
	str	q13, [sp, #560]
	ldp	q27, q28, [x13, #192]
	stp	q27, q28, [sp, #208]
	ldp	q27, q28, [x13, #224]
	stp	q27, q28, [sp, #240]
	ldp	q27, q28, [x13, #128]
	stp	q27, q28, [sp, #144]
	ldp	q27, q28, [x13, #160]
	stp	q27, q28, [sp, #176]
	ldp	q27, q28, [x13, #64]
	stp	q27, q28, [sp, #80]
	ldp	q27, q28, [x13, #96]
	stp	q27, q28, [sp, #112]
	ldp	q27, q28, [x13]
	stp	q27, q28, [sp, #16]
	ldp	q27, q28, [x13, #32]
	stp	q27, q28, [sp, #48]
	fmul.4s	v27, v25, v25
	fmul.4s	v28, v24, v24
	fmul.4s	v29, v22, v22
	fmul.4s	v30, v23, v23
	fmul.4s	v31, v21, v21
	fmul.4s	v8, v20, v20
	fmul.4s	v9, v18, v18
	fmul.4s	v10, v19, v19
	fmul.4s	v11, v1, v1
	fmul.4s	v12, v2, v2
	fadd.4s	v10, v10, v12
	fadd.4s	v9, v9, v11
	fmul.4s	v11, v4, v4
	fmul.4s	v12, v3, v3
	fadd.4s	v8, v8, v12
	fadd.4s	v31, v31, v11
	fmul.4s	v11, v6, v6
	fmul.4s	v12, v7, v7
	fadd.4s	v30, v30, v12
	fadd.4s	v29, v29, v11
	fmul.4s	v11, v17, v17
	fmul.4s	v12, v16, v16
	fadd.4s	v28, v28, v12
	fadd.4s	v27, v27, v11
	fmul.4s	v11, v13, v13
	fadd.4s	v11, v11, v27
	mov.s	v27[0], v11[0]
	fadd.4s	v28, v29, v28
	fadd.4s	v27, v30, v27
	fadd.4s	v27, v31, v27
	fadd.4s	v28, v8, v28
	fadd.4s	v28, v9, v28
	fadd.4s	v27, v10, v27
	rev64.4s	v29, v27
	rev64.4s	v30, v28
	fadd.4s	v28, v28, v30
	fadd.4s	v27, v27, v29
	dup.4s	v29, v27[2]
	dup.4s	v30, v28[2]
	fadd.4s	v28, v28, v30
	fadd.4s	v27, v27, v29
	fadd.4s	v27, v27, v28
	fadd	s5, s27, s5
	fdiv	s26, s5, s26
	ldr	s5, [x13, #256]
	str	q5, [sp, #272]
	mov	w13, #50604                     ; =0xc5ac
	movk	w13, #14119, lsl #16
	fmov	s27, w13
	fadd	s26, s26, s27
	fsqrt	s26, s26
	subs	x13, x9, x10
	cset	w14, hs
	cmp	x13, #259
	csel	w13, wzr, w14, ls
	subs	x14, x10, x9
	lsr	x14, x14, #2
	mov	w15, #1104                      ; =0x450
	ccmp	x14, x15, #0, hs
	b.hi	LBB1_3
; %bb.1:                                ; %prologue
	tbnz	w13, #0, LBB1_3
; %bb.2:                                ; %direct.true256.preheader
	ldp	q30, q10, [x10]
	ldp	q11, q12, [x10, #32]
	str	q13, [sp]                       ; 16-byte Spill
	ldp	q13, q14, [x10, #64]
	ldp	q8, q9, [x10, #96]
	ldp	q27, q28, [x10, #128]
	dup.4s	v26, v26[0]
	fdiv.4s	v25, v25, v26
	ldp	q29, q15, [sp, #16]
	fmul.4s	v25, v25, v29
	ldp	q29, q31, [x10, #160]
	fdiv.4s	v24, v24, v26
	fmul.4s	v24, v24, v15
	fadd.4s	v10, v24, v10
	fadd.4s	v15, v25, v30
	fdiv.4s	v23, v23, v26
	ldp	q25, q24, [sp, #48]
	fmul.4s	v23, v23, v25
	ldp	q25, q30, [x10, #192]
	fdiv.4s	v22, v22, v26
	fmul.4s	v22, v22, v24
	fadd.4s	v0, v22, v12
	ldp	q12, q24, [x10, #224]
	add	x11, x9, x11
	ldr	s22, [x10, #256]
	stp	q15, q10, [x11]
	fadd.4s	v23, v23, v11
	fdiv.4s	v21, v21, v26
	ldr	q10, [sp, #80]
	fmul.4s	v21, v21, v10
	ldr	q10, [sp, #96]
	fdiv.4s	v20, v20, v26
	fmul.4s	v20, v20, v10
	fadd.4s	v20, v20, v14
	fadd.4s	v21, v21, v13
	stp	q23, q0, [x11, #32]
	stp	q21, q20, [x11, #64]
	fdiv.4s	v0, v19, v26
	ldp	q20, q19, [sp, #112]
	fmul.4s	v0, v0, v20
	fdiv.4s	v18, v18, v26
	fmul.4s	v18, v18, v19
	fadd.4s	v18, v18, v9
	fadd.4s	v0, v0, v8
	fdiv.4s	v17, v17, v26
	ldp	q20, q19, [sp, #144]
	fmul.4s	v17, v17, v20
	fdiv.4s	v16, v16, v26
	fmul.4s	v16, v16, v19
	fadd.4s	v16, v16, v28
	stp	q0, q18, [x11, #96]
	fadd.4s	v0, v17, v27
	fdiv.4s	v7, v7, v26
	ldp	q18, q17, [sp, #176]
	fmul.4s	v7, v7, v18
	fdiv.4s	v6, v6, v26
	fmul.4s	v6, v6, v17
	fadd.4s	v6, v6, v31
	stp	q0, q16, [x11, #128]
	fadd.4s	v0, v7, v29
	fdiv.4s	v4, v4, v26
	ldr	q7, [sp, #208]
	fmul.4s	v4, v4, v7
	ldr	q7, [sp, #224]
	fdiv.4s	v3, v3, v26
	fmul.4s	v3, v3, v7
	fadd.4s	v3, v3, v30
	stp	q0, q6, [x11, #160]
	fadd.4s	v0, v4, v25
	fdiv.4s	v2, v2, v26
	ldp	q6, q4, [sp, #240]
	fmul.4s	v2, v2, v6
	fdiv.4s	v1, v1, v26
	fmul.4s	v1, v1, v4
	fadd.4s	v1, v1, v24
	stp	q0, q3, [x11, #192]
	fadd.4s	v2, v2, v12
	ldr	q0, [sp]                        ; 16-byte Reload
	fdiv.4s	v0, v0, v26
	fmul.4s	v0, v0, v5
	fadd.4s	v0, v0, v22
	stp	q2, q1, [x11, #224]
	b	LBB1_6
LBB1_3:                                 ; %direct.schedule.27.preheader
	mov	x14, #0                         ; =0x0
	dup.4s	v1, v26[0]
	mov	w11, #260                       ; =0x104
	umaddl	x11, w12, w11, x9
	movi.2d	v2, #0000000000000000
	add	x12, sp, #304
	add	x13, sp, #16
	mov	w15, #1                         ; =0x1
	dup.2d	v3, x15
	movi.2d	v4, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
LBB1_4:                                 ; %direct.true214
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x14, x14, #5
	add	x15, x12, x14
	ldp	q16, q0, [x15]
	fdiv.4s	v16, v16, v1
	fdiv.4s	v0, v0, v1
	add	x14, x13, x14
	ldp	q17, q18, [x14]
	fmul.4s	v0, v0, v18
	fmul.4s	v16, v16, v17
	fmov	x14, d2
	lsl	x14, x14, #5
	add	x15, x10, x14
	ldp	q18, q17, [x15]
	fadd.4s	v16, v16, v18
	fadd.4s	v0, v0, v17
	add	x14, x11, x14
	stp	q16, q0, [x14]
	add.2d	v6, v6, v3
	add.2d	v4, v4, v3
	add.2d	v7, v7, v3
	add.2d	v2, v2, v3
	fmov	x14, d2
	cmp	x14, #8
	b.lt	LBB1_4
; %bb.5:                                ; %direct.false215
	fdiv.4s	v0, v13, v1
	fmul.4s	v0, v0, v5
	ldr	s1, [x10, #256]
	fadd.4s	v0, v0, v1
LBB1_6:                                 ; %common.ret
	str	s0, [x9, x8]
	add	sp, sp, #592
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #80             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB2_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB2_4
LBB2_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB2_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB2_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB2_13
LBB2_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB2_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB2_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #1
	b.eq	LBB2_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #2
	b.eq	LBB2_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #3
	b.eq	LBB2_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB2_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB2_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
LBB2_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB2_3
LBB2_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB2_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

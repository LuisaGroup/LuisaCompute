	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_3:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_4:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_5:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_6:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	dup.4s	v0, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q2, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q1, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v1, v0, v1
	cmhi.4s	v0, v0, v2
	uzp1.8h	v2, v0, v1
	umaxv.8h	h3, v2
	fmov	w8, s3
	tbz	w8, #0, LBB0_211
; %bb.1:                                ; %direct.activate
	stp	x28, x27, [sp, #-16]!           ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #2064
	ldr	x11, [x0]
	ldr	x10, [x0, #16]
	ldr	x9, [x0, #32]
	ldr	w8, [x1]
	ldr	w12, [x1, #36]
	add	w8, w12, w8, lsl #5
	lsr	w8, w8, #3
	dup.4s	v3, w8
	ldr	x8, [x0, #48]
	and.16b	v3, v0, v3
	ushll.2d	v3, v3, #0
	subs	x12, x11, x8
	cset	w13, hs
	lsr	x12, x12, #10
	cmp	x12, #386
	csel	w12, wzr, w13, ls
	subs	x13, x8, x11
	cset	w14, hs
	lsr	x13, x13, #10
	cmp	x13, #386
	csel	w13, wzr, w14, ls
	subs	x14, x10, x8
	cset	w15, hs
	lsr	x14, x14, #10
	cmp	x14, #386
	csel	w14, wzr, w15, ls
	subs	x15, x8, x10
	cset	w16, hs
	lsr	x15, x15, #9
	cmp	x15, #386
	csel	w15, wzr, w16, ls
	subs	x16, x9, x8
	cset	w17, hs
	lsr	x16, x16, #10
	cmp	x16, #386
	csel	w16, wzr, w17, ls
	subs	x17, x8, x9
	cset	w0, hs
	lsr	x17, x17, #9
	cmp	x17, #386
	csel	w17, wzr, w0, ls
	orr	w17, w16, w17
	adrp	x16, lCPI0_6@PAGE
	cmp	w17, #1
	b.ne	LBB0_102
; %bb.2:                                ; %direct.activate
	orr	w12, w12, w13
	cbz	w12, LBB0_102
; %bb.3:                                ; %direct.activate
	orr	w12, w14, w15
	tbz	w12, #0, LBB0_102
; %bb.4:                                ; %direct.schedule.2.preheader
	mov	x12, #0                         ; =0x0
	sshll.2d	v0, v0, #0
Lloh4:
	adrp	x13, lCPI0_5@PAGE
Lloh5:
	ldr	q1, [x13, lCPI0_5@PAGEOFF]
	and.16b	v0, v0, v1
	movi.2s	v1, #3, lsl #8
	xtn.2s	v4, v3
	umull.2d	v1, v4, v1
	fmov	x13, d1
	add	x13, x13, #384
	fmov	x14, d3
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #7
	ldr	q3, [x16, lCPI0_6@PAGEOFF]
	and.16b	v2, v2, v3
	addv.8h	h2, v2
	fmov	w15, s2
	b	LBB0_6
LBB0_5:                                 ; %else164
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x12, x12, #8
	cmp	x12, #384
	b.eq	LBB0_210
LBB0_6:                                 ; %direct.true30
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v3, x12
	orr.16b	v5, v3, v0
	add.2d	v3, v5, v1
	fmov	x16, d3
	lsl	x16, x16, #2
	add	x17, x11, x16
	movi.2d	v4, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w15, #0, LBB0_56
; %bb.7:                                ; %else
                                        ;   in Loop: Header=BB0_6 Depth=1
	and	w0, w15, #0xff
	tbnz	w0, #1, LBB0_57
LBB0_8:                                 ; %else37
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w0, #2, LBB0_58
LBB0_9:                                 ; %else40
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w0, #3, LBB0_59
LBB0_10:                                ; %else43
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w0, #4, LBB0_60
LBB0_11:                                ; %else46
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w0, #5, LBB0_61
LBB0_12:                                ; %else49
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w0, #6, LBB0_62
LBB0_13:                                ; %else52
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w0, #7, LBB0_15
LBB0_14:                                ; %cond.load54
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x17, x17, #28
	ld1.s	{ v3 }[3], [x17]
LBB0_15:                                ; %else55
                                        ;   in Loop: Header=BB0_6 Depth=1
	fmov	w2, s2
	fmov	x0, d5
	add	x17, x13, x0
	lsl	x17, x17, #2
	add	x1, x11, x17
	movi.2d	v6, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbnz	w2, #0, LBB0_63
; %bb.16:                               ; %else59
                                        ;   in Loop: Header=BB0_6 Depth=1
	and	w2, w2, #0xff
	tbnz	w2, #1, LBB0_64
LBB0_17:                                ; %else62
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w2, #2, LBB0_65
LBB0_18:                                ; %else65
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w2, #3, LBB0_66
LBB0_19:                                ; %else68
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w2, #4, LBB0_67
LBB0_20:                                ; %else71
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w2, #5, LBB0_68
LBB0_21:                                ; %else74
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w2, #6, LBB0_69
LBB0_22:                                ; %else77
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w2, #7, LBB0_24
LBB0_23:                                ; %cond.load79
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x1, x1, #28
	ld1.s	{ v5 }[3], [x1]
LBB0_24:                                ; %else80
                                        ;   in Loop: Header=BB0_6 Depth=1
	fmov	w2, s2
	add	x0, x0, x14
	lsl	x0, x0, #2
	add	x1, x10, x0
	movi.2d	v16, #0000000000000000
	movi.2d	v7, #0000000000000000
	tbnz	w2, #0, LBB0_70
; %bb.25:                               ; %else84
                                        ;   in Loop: Header=BB0_6 Depth=1
	and	w2, w2, #0xff
	tbnz	w2, #1, LBB0_71
LBB0_26:                                ; %else87
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w2, #2, LBB0_72
LBB0_27:                                ; %else90
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w2, #3, LBB0_73
LBB0_28:                                ; %else93
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w2, #4, LBB0_74
LBB0_29:                                ; %else96
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w2, #5, LBB0_75
LBB0_30:                                ; %else99
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w2, #6, LBB0_76
LBB0_31:                                ; %else102
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w2, #7, LBB0_77
LBB0_32:                                ; %else105
                                        ;   in Loop: Header=BB0_6 Depth=1
	fmov	w1, s2
	add	x0, x9, x0
	movi.2d	v18, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbnz	w1, #0, LBB0_78
LBB0_33:                                ; %else109
                                        ;   in Loop: Header=BB0_6 Depth=1
	and	w1, w1, #0xff
	tbnz	w1, #1, LBB0_79
LBB0_34:                                ; %else112
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w1, #2, LBB0_80
LBB0_35:                                ; %else115
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w1, #3, LBB0_81
LBB0_36:                                ; %else118
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w1, #4, LBB0_82
LBB0_37:                                ; %else121
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w1, #5, LBB0_83
LBB0_38:                                ; %else124
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w1, #6, LBB0_84
LBB0_39:                                ; %else127
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w1, #7, LBB0_85
LBB0_40:                                ; %else130
                                        ;   in Loop: Header=BB0_6 Depth=1
	fmov	w0, s2
	fmul.4s	v19, v4, v16
	fmul.4s	v20, v6, v18
	fsub.4s	v19, v19, v20
	add	x16, x8, x16
	tbnz	w0, #0, LBB0_86
LBB0_41:                                ; %else133
                                        ;   in Loop: Header=BB0_6 Depth=1
	and	w0, w0, #0xff
	tbnz	w0, #1, LBB0_87
LBB0_42:                                ; %else135
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w0, #2, LBB0_88
LBB0_43:                                ; %else137
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w0, #3, LBB0_89
LBB0_44:                                ; %else139
                                        ;   in Loop: Header=BB0_6 Depth=1
	fmul.4s	v19, v3, v7
	fmul.4s	v20, v5, v17
	fsub.4s	v19, v19, v20
	tbnz	w0, #4, LBB0_90
LBB0_45:                                ; %else141
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w0, #5, LBB0_91
LBB0_46:                                ; %else143
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w0, #6, LBB0_92
LBB0_47:                                ; %else145
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w0, #7, LBB0_93
LBB0_48:                                ; %else147
                                        ;   in Loop: Header=BB0_6 Depth=1
	fmov	w0, s2
	fmul.4s	v4, v4, v18
	fmul.4s	v6, v6, v16
	fadd.4s	v4, v6, v4
	add	x16, x8, x17
	tbnz	w0, #0, LBB0_94
LBB0_49:                                ; %else150
                                        ;   in Loop: Header=BB0_6 Depth=1
	and	w17, w0, #0xff
	tbnz	w17, #1, LBB0_95
LBB0_50:                                ; %else152
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w17, #2, LBB0_96
LBB0_51:                                ; %else154
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w17, #3, LBB0_97
LBB0_52:                                ; %else156
                                        ;   in Loop: Header=BB0_6 Depth=1
	fmul.4s	v3, v3, v17
	fmul.4s	v4, v5, v7
	fadd.4s	v3, v4, v3
	tbnz	w17, #4, LBB0_98
LBB0_53:                                ; %else158
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w17, #5, LBB0_99
LBB0_54:                                ; %else160
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbnz	w17, #6, LBB0_100
LBB0_55:                                ; %else162
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w17, #7, LBB0_5
	b	LBB0_101
LBB0_56:                                ; %cond.load
                                        ;   in Loop: Header=BB0_6 Depth=1
	ldr	s4, [x17]
	and	w0, w15, #0xff
	tbz	w0, #1, LBB0_8
LBB0_57:                                ; %cond.load36
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x1, x17, #4
	ld1.s	{ v4 }[1], [x1]
	tbz	w0, #2, LBB0_9
LBB0_58:                                ; %cond.load39
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x1, x17, #8
	ld1.s	{ v4 }[2], [x1]
	tbz	w0, #3, LBB0_10
LBB0_59:                                ; %cond.load42
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x1, x17, #12
	ld1.s	{ v4 }[3], [x1]
	tbz	w0, #4, LBB0_11
LBB0_60:                                ; %cond.load45
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x1, x17, #16
	ld1.s	{ v3 }[0], [x1]
	tbz	w0, #5, LBB0_12
LBB0_61:                                ; %cond.load48
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x1, x17, #20
	ld1.s	{ v3 }[1], [x1]
	tbz	w0, #6, LBB0_13
LBB0_62:                                ; %cond.load51
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x1, x17, #24
	ld1.s	{ v3 }[2], [x1]
	tbnz	w0, #7, LBB0_14
	b	LBB0_15
LBB0_63:                                ; %cond.load58
                                        ;   in Loop: Header=BB0_6 Depth=1
	ldr	s6, [x1]
	and	w2, w2, #0xff
	tbz	w2, #1, LBB0_17
LBB0_64:                                ; %cond.load61
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x3, x1, #4
	ld1.s	{ v6 }[1], [x3]
	tbz	w2, #2, LBB0_18
LBB0_65:                                ; %cond.load64
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x3, x1, #8
	ld1.s	{ v6 }[2], [x3]
	tbz	w2, #3, LBB0_19
LBB0_66:                                ; %cond.load67
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x3, x1, #12
	ld1.s	{ v6 }[3], [x3]
	tbz	w2, #4, LBB0_20
LBB0_67:                                ; %cond.load70
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x3, x1, #16
	ld1.s	{ v5 }[0], [x3]
	tbz	w2, #5, LBB0_21
LBB0_68:                                ; %cond.load73
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x3, x1, #20
	ld1.s	{ v5 }[1], [x3]
	tbz	w2, #6, LBB0_22
LBB0_69:                                ; %cond.load76
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x3, x1, #24
	ld1.s	{ v5 }[2], [x3]
	tbnz	w2, #7, LBB0_23
	b	LBB0_24
LBB0_70:                                ; %cond.load83
                                        ;   in Loop: Header=BB0_6 Depth=1
	ldr	s16, [x1]
	and	w2, w2, #0xff
	tbz	w2, #1, LBB0_26
LBB0_71:                                ; %cond.load86
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x3, x1, #4
	ld1.s	{ v16 }[1], [x3]
	tbz	w2, #2, LBB0_27
LBB0_72:                                ; %cond.load89
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x3, x1, #8
	ld1.s	{ v16 }[2], [x3]
	tbz	w2, #3, LBB0_28
LBB0_73:                                ; %cond.load92
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x3, x1, #12
	ld1.s	{ v16 }[3], [x3]
	tbz	w2, #4, LBB0_29
LBB0_74:                                ; %cond.load95
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x3, x1, #16
	ld1.s	{ v7 }[0], [x3]
	tbz	w2, #5, LBB0_30
LBB0_75:                                ; %cond.load98
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x3, x1, #20
	ld1.s	{ v7 }[1], [x3]
	tbz	w2, #6, LBB0_31
LBB0_76:                                ; %cond.load101
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x3, x1, #24
	ld1.s	{ v7 }[2], [x3]
	tbz	w2, #7, LBB0_32
LBB0_77:                                ; %cond.load104
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x1, x1, #28
	ld1.s	{ v7 }[3], [x1]
	fmov	w1, s2
	add	x0, x9, x0
	movi.2d	v18, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbz	w1, #0, LBB0_33
LBB0_78:                                ; %cond.load108
                                        ;   in Loop: Header=BB0_6 Depth=1
	ldr	s18, [x0]
	and	w1, w1, #0xff
	tbz	w1, #1, LBB0_34
LBB0_79:                                ; %cond.load111
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x2, x0, #4
	ld1.s	{ v18 }[1], [x2]
	tbz	w1, #2, LBB0_35
LBB0_80:                                ; %cond.load114
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x2, x0, #8
	ld1.s	{ v18 }[2], [x2]
	tbz	w1, #3, LBB0_36
LBB0_81:                                ; %cond.load117
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x2, x0, #12
	ld1.s	{ v18 }[3], [x2]
	tbz	w1, #4, LBB0_37
LBB0_82:                                ; %cond.load120
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x2, x0, #16
	ld1.s	{ v17 }[0], [x2]
	tbz	w1, #5, LBB0_38
LBB0_83:                                ; %cond.load123
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x2, x0, #20
	ld1.s	{ v17 }[1], [x2]
	tbz	w1, #6, LBB0_39
LBB0_84:                                ; %cond.load126
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x2, x0, #24
	ld1.s	{ v17 }[2], [x2]
	tbz	w1, #7, LBB0_40
LBB0_85:                                ; %cond.load129
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x0, x0, #28
	ld1.s	{ v17 }[3], [x0]
	fmov	w0, s2
	fmul.4s	v19, v4, v16
	fmul.4s	v20, v6, v18
	fsub.4s	v19, v19, v20
	add	x16, x8, x16
	tbz	w0, #0, LBB0_41
LBB0_86:                                ; %cond.store
                                        ;   in Loop: Header=BB0_6 Depth=1
	str	s19, [x16]
	and	w0, w0, #0xff
	tbz	w0, #1, LBB0_42
LBB0_87:                                ; %cond.store134
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x1, x16, #4
	st1.s	{ v19 }[1], [x1]
	tbz	w0, #2, LBB0_43
LBB0_88:                                ; %cond.store136
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x1, x16, #8
	st1.s	{ v19 }[2], [x1]
	tbz	w0, #3, LBB0_44
LBB0_89:                                ; %cond.store138
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x1, x16, #12
	st1.s	{ v19 }[3], [x1]
	fmul.4s	v19, v3, v7
	fmul.4s	v20, v5, v17
	fsub.4s	v19, v19, v20
	tbz	w0, #4, LBB0_45
LBB0_90:                                ; %cond.store140
                                        ;   in Loop: Header=BB0_6 Depth=1
	str	s19, [x16, #16]
	tbz	w0, #5, LBB0_46
LBB0_91:                                ; %cond.store142
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x1, x16, #20
	st1.s	{ v19 }[1], [x1]
	tbz	w0, #6, LBB0_47
LBB0_92:                                ; %cond.store144
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x1, x16, #24
	st1.s	{ v19 }[2], [x1]
	tbz	w0, #7, LBB0_48
LBB0_93:                                ; %cond.store146
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x16, x16, #28
	st1.s	{ v19 }[3], [x16]
	fmov	w0, s2
	fmul.4s	v4, v4, v18
	fmul.4s	v6, v6, v16
	fadd.4s	v4, v6, v4
	add	x16, x8, x17
	tbz	w0, #0, LBB0_49
LBB0_94:                                ; %cond.store149
                                        ;   in Loop: Header=BB0_6 Depth=1
	str	s4, [x16]
	and	w17, w0, #0xff
	tbz	w17, #1, LBB0_50
LBB0_95:                                ; %cond.store151
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x0, x16, #4
	st1.s	{ v4 }[1], [x0]
	tbz	w17, #2, LBB0_51
LBB0_96:                                ; %cond.store153
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x0, x16, #8
	st1.s	{ v4 }[2], [x0]
	tbz	w17, #3, LBB0_52
LBB0_97:                                ; %cond.store155
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x0, x16, #12
	st1.s	{ v4 }[3], [x0]
	fmul.4s	v3, v3, v17
	fmul.4s	v4, v5, v7
	fadd.4s	v3, v4, v3
	tbz	w17, #4, LBB0_53
LBB0_98:                                ; %cond.store157
                                        ;   in Loop: Header=BB0_6 Depth=1
	str	s3, [x16, #16]
	tbz	w17, #5, LBB0_54
LBB0_99:                                ; %cond.store159
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x0, x16, #20
	st1.s	{ v3 }[1], [x0]
	tbz	w17, #6, LBB0_55
LBB0_100:                               ; %cond.store161
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x0, x16, #24
	st1.s	{ v3 }[2], [x0]
	tbz	w17, #7, LBB0_5
LBB0_101:                               ; %cond.store163
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x16, x16, #28
	st1.s	{ v3 }[3], [x16]
	b	LBB0_5
LBB0_102:                               ; %direct.schedule.6.preheader
	mov	x14, #0                         ; =0x0
	fmov	x12, d3
	add	x13, x12, x12, lsl #1
	lsl	x12, x13, #10
	add	x15, x11, x12
	ldr	q3, [x16, lCPI0_6@PAGEOFF]
	and.16b	v2, v2, v3
	addv.8h	h2, v2
	fmov	w16, s2
	add	x17, sp, #1, lsl #12            ; =4096
	add	x17, x17, #528
	b	LBB0_104
LBB0_103:                               ; %else188
                                        ;   in Loop: Header=BB0_104 Depth=1
	add	x0, x17, x14
	stp	q3, q4, [x0]
	add	x14, x14, #32
	cmp	x14, #1536
	b.eq	LBB0_120
LBB0_104:                               ; %direct.true46
                                        ; =>This Inner Loop Header: Depth=1
	add	x0, x15, x14
	add	x2, x17, x14
	ldr	q3, [x2]
	tbnz	w16, #0, LBB0_112
; %bb.105:                              ; %else167
                                        ;   in Loop: Header=BB0_104 Depth=1
	and	w1, w16, #0xff
	tbnz	w1, #1, LBB0_113
LBB0_106:                               ; %else170
                                        ;   in Loop: Header=BB0_104 Depth=1
	tbnz	w1, #2, LBB0_114
LBB0_107:                               ; %else173
                                        ;   in Loop: Header=BB0_104 Depth=1
	tbnz	w1, #3, LBB0_115
LBB0_108:                               ; %else176
                                        ;   in Loop: Header=BB0_104 Depth=1
	ldr	q4, [x2, #16]
	tbnz	w1, #4, LBB0_116
LBB0_109:                               ; %else179
                                        ;   in Loop: Header=BB0_104 Depth=1
	tbnz	w1, #5, LBB0_117
LBB0_110:                               ; %else182
                                        ;   in Loop: Header=BB0_104 Depth=1
	tbnz	w1, #6, LBB0_118
LBB0_111:                               ; %else185
                                        ;   in Loop: Header=BB0_104 Depth=1
	tbz	w1, #7, LBB0_103
	b	LBB0_119
LBB0_112:                               ; %cond.load166
                                        ;   in Loop: Header=BB0_104 Depth=1
	ld1.s	{ v3 }[0], [x0]
	and	w1, w16, #0xff
	tbz	w1, #1, LBB0_106
LBB0_113:                               ; %cond.load169
                                        ;   in Loop: Header=BB0_104 Depth=1
	add	x3, x0, #4
	ld1.s	{ v3 }[1], [x3]
	tbz	w1, #2, LBB0_107
LBB0_114:                               ; %cond.load172
                                        ;   in Loop: Header=BB0_104 Depth=1
	add	x3, x0, #8
	ld1.s	{ v3 }[2], [x3]
	tbz	w1, #3, LBB0_108
LBB0_115:                               ; %cond.load175
                                        ;   in Loop: Header=BB0_104 Depth=1
	add	x3, x0, #12
	ld1.s	{ v3 }[3], [x3]
	ldr	q4, [x2, #16]
	tbz	w1, #4, LBB0_109
LBB0_116:                               ; %cond.load178
                                        ;   in Loop: Header=BB0_104 Depth=1
	add	x2, x0, #16
	ld1.s	{ v4 }[0], [x2]
	tbz	w1, #5, LBB0_110
LBB0_117:                               ; %cond.load181
                                        ;   in Loop: Header=BB0_104 Depth=1
	add	x2, x0, #20
	ld1.s	{ v4 }[1], [x2]
	tbz	w1, #6, LBB0_111
LBB0_118:                               ; %cond.load184
                                        ;   in Loop: Header=BB0_104 Depth=1
	add	x2, x0, #24
	ld1.s	{ v4 }[2], [x2]
	tbz	w1, #7, LBB0_103
LBB0_119:                               ; %cond.load187
                                        ;   in Loop: Header=BB0_104 Depth=1
	add	x0, x0, #28
	ld1.s	{ v4 }[3], [x0]
	b	LBB0_103
LBB0_120:                               ; %direct.schedule.9.preheader
	mov	x14, #0                         ; =0x0
	add	x11, x12, x11
	add	x11, x11, #1536
	fmov	w15, s2
	add	x16, sp, #3088
	b	LBB0_122
LBB0_121:                               ; %else213
                                        ;   in Loop: Header=BB0_122 Depth=1
	add	x17, x16, x14
	stp	q3, q4, [x17]
	add	x14, x14, #32
	cmp	x14, #1536
	b.eq	LBB0_138
LBB0_122:                               ; %direct.true60
                                        ; =>This Inner Loop Header: Depth=1
	add	x17, x11, x14
	add	x1, x16, x14
	ldr	q3, [x1]
	tbnz	w15, #0, LBB0_130
; %bb.123:                              ; %else192
                                        ;   in Loop: Header=BB0_122 Depth=1
	and	w0, w15, #0xff
	tbnz	w0, #1, LBB0_131
LBB0_124:                               ; %else195
                                        ;   in Loop: Header=BB0_122 Depth=1
	tbnz	w0, #2, LBB0_132
LBB0_125:                               ; %else198
                                        ;   in Loop: Header=BB0_122 Depth=1
	tbnz	w0, #3, LBB0_133
LBB0_126:                               ; %else201
                                        ;   in Loop: Header=BB0_122 Depth=1
	ldr	q4, [x1, #16]
	tbnz	w0, #4, LBB0_134
LBB0_127:                               ; %else204
                                        ;   in Loop: Header=BB0_122 Depth=1
	tbnz	w0, #5, LBB0_135
LBB0_128:                               ; %else207
                                        ;   in Loop: Header=BB0_122 Depth=1
	tbnz	w0, #6, LBB0_136
LBB0_129:                               ; %else210
                                        ;   in Loop: Header=BB0_122 Depth=1
	tbz	w0, #7, LBB0_121
	b	LBB0_137
LBB0_130:                               ; %cond.load191
                                        ;   in Loop: Header=BB0_122 Depth=1
	ld1.s	{ v3 }[0], [x17]
	and	w0, w15, #0xff
	tbz	w0, #1, LBB0_124
LBB0_131:                               ; %cond.load194
                                        ;   in Loop: Header=BB0_122 Depth=1
	add	x2, x17, #4
	ld1.s	{ v3 }[1], [x2]
	tbz	w0, #2, LBB0_125
LBB0_132:                               ; %cond.load197
                                        ;   in Loop: Header=BB0_122 Depth=1
	add	x2, x17, #8
	ld1.s	{ v3 }[2], [x2]
	tbz	w0, #3, LBB0_126
LBB0_133:                               ; %cond.load200
                                        ;   in Loop: Header=BB0_122 Depth=1
	add	x2, x17, #12
	ld1.s	{ v3 }[3], [x2]
	ldr	q4, [x1, #16]
	tbz	w0, #4, LBB0_127
LBB0_134:                               ; %cond.load203
                                        ;   in Loop: Header=BB0_122 Depth=1
	add	x1, x17, #16
	ld1.s	{ v4 }[0], [x1]
	tbz	w0, #5, LBB0_128
LBB0_135:                               ; %cond.load206
                                        ;   in Loop: Header=BB0_122 Depth=1
	add	x1, x17, #20
	ld1.s	{ v4 }[1], [x1]
	tbz	w0, #6, LBB0_129
LBB0_136:                               ; %cond.load209
                                        ;   in Loop: Header=BB0_122 Depth=1
	add	x1, x17, #24
	ld1.s	{ v4 }[2], [x1]
	tbz	w0, #7, LBB0_121
LBB0_137:                               ; %cond.load212
                                        ;   in Loop: Header=BB0_122 Depth=1
	add	x17, x17, #28
	ld1.s	{ v4 }[3], [x17]
	b	LBB0_121
LBB0_138:                               ; %direct.schedule.12.preheader
	mov	x14, #0                         ; =0x0
	lsl	x11, x13, #9
	add	x10, x10, x11
	fmov	w13, s2
	add	x15, sp, #1552
	b	LBB0_140
LBB0_139:                               ; %else238
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x16, x15, x14
	stp	q3, q4, [x16]
	add	x14, x14, #32
	cmp	x14, #1536
	b.eq	LBB0_156
LBB0_140:                               ; %direct.true77
                                        ; =>This Inner Loop Header: Depth=1
	add	x16, x10, x14
	add	x0, x15, x14
	ldr	q3, [x0]
	tbnz	w13, #0, LBB0_148
; %bb.141:                              ; %else217
                                        ;   in Loop: Header=BB0_140 Depth=1
	and	w17, w13, #0xff
	tbnz	w17, #1, LBB0_149
LBB0_142:                               ; %else220
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w17, #2, LBB0_150
LBB0_143:                               ; %else223
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w17, #3, LBB0_151
LBB0_144:                               ; %else226
                                        ;   in Loop: Header=BB0_140 Depth=1
	ldr	q4, [x0, #16]
	tbnz	w17, #4, LBB0_152
LBB0_145:                               ; %else229
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w17, #5, LBB0_153
LBB0_146:                               ; %else232
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w17, #6, LBB0_154
LBB0_147:                               ; %else235
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbz	w17, #7, LBB0_139
	b	LBB0_155
LBB0_148:                               ; %cond.load216
                                        ;   in Loop: Header=BB0_140 Depth=1
	ld1.s	{ v3 }[0], [x16]
	and	w17, w13, #0xff
	tbz	w17, #1, LBB0_142
LBB0_149:                               ; %cond.load219
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x1, x16, #4
	ld1.s	{ v3 }[1], [x1]
	tbz	w17, #2, LBB0_143
LBB0_150:                               ; %cond.load222
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x1, x16, #8
	ld1.s	{ v3 }[2], [x1]
	tbz	w17, #3, LBB0_144
LBB0_151:                               ; %cond.load225
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x1, x16, #12
	ld1.s	{ v3 }[3], [x1]
	ldr	q4, [x0, #16]
	tbz	w17, #4, LBB0_145
LBB0_152:                               ; %cond.load228
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x0, x16, #16
	ld1.s	{ v4 }[0], [x0]
	tbz	w17, #5, LBB0_146
LBB0_153:                               ; %cond.load231
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x0, x16, #20
	ld1.s	{ v4 }[1], [x0]
	tbz	w17, #6, LBB0_147
LBB0_154:                               ; %cond.load234
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x0, x16, #24
	ld1.s	{ v4 }[2], [x0]
	tbz	w17, #7, LBB0_139
LBB0_155:                               ; %cond.load237
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x16, x16, #28
	ld1.s	{ v4 }[3], [x16]
	b	LBB0_139
LBB0_156:                               ; %direct.schedule.15.preheader
	mov	x10, #0                         ; =0x0
	add	x9, x9, x11
	fmov	w11, s2
	add	x13, sp, #16
	b	LBB0_158
LBB0_157:                               ; %else263
                                        ;   in Loop: Header=BB0_158 Depth=1
	add	x14, x13, x10
	stp	q3, q4, [x14]
	add	x10, x10, #32
	cmp	x10, #1536
	b.eq	LBB0_174
LBB0_158:                               ; %direct.true94
                                        ; =>This Inner Loop Header: Depth=1
	add	x14, x9, x10
	add	x16, x13, x10
	ldr	q3, [x16]
	tbnz	w11, #0, LBB0_166
; %bb.159:                              ; %else242
                                        ;   in Loop: Header=BB0_158 Depth=1
	and	w15, w11, #0xff
	tbnz	w15, #1, LBB0_167
LBB0_160:                               ; %else245
                                        ;   in Loop: Header=BB0_158 Depth=1
	tbnz	w15, #2, LBB0_168
LBB0_161:                               ; %else248
                                        ;   in Loop: Header=BB0_158 Depth=1
	tbnz	w15, #3, LBB0_169
LBB0_162:                               ; %else251
                                        ;   in Loop: Header=BB0_158 Depth=1
	ldr	q4, [x16, #16]
	tbnz	w15, #4, LBB0_170
LBB0_163:                               ; %else254
                                        ;   in Loop: Header=BB0_158 Depth=1
	tbnz	w15, #5, LBB0_171
LBB0_164:                               ; %else257
                                        ;   in Loop: Header=BB0_158 Depth=1
	tbnz	w15, #6, LBB0_172
LBB0_165:                               ; %else260
                                        ;   in Loop: Header=BB0_158 Depth=1
	tbz	w15, #7, LBB0_157
	b	LBB0_173
LBB0_166:                               ; %cond.load241
                                        ;   in Loop: Header=BB0_158 Depth=1
	ld1.s	{ v3 }[0], [x14]
	and	w15, w11, #0xff
	tbz	w15, #1, LBB0_160
LBB0_167:                               ; %cond.load244
                                        ;   in Loop: Header=BB0_158 Depth=1
	add	x17, x14, #4
	ld1.s	{ v3 }[1], [x17]
	tbz	w15, #2, LBB0_161
LBB0_168:                               ; %cond.load247
                                        ;   in Loop: Header=BB0_158 Depth=1
	add	x17, x14, #8
	ld1.s	{ v3 }[2], [x17]
	tbz	w15, #3, LBB0_162
LBB0_169:                               ; %cond.load250
                                        ;   in Loop: Header=BB0_158 Depth=1
	add	x17, x14, #12
	ld1.s	{ v3 }[3], [x17]
	ldr	q4, [x16, #16]
	tbz	w15, #4, LBB0_163
LBB0_170:                               ; %cond.load253
                                        ;   in Loop: Header=BB0_158 Depth=1
	add	x16, x14, #16
	ld1.s	{ v4 }[0], [x16]
	tbz	w15, #5, LBB0_164
LBB0_171:                               ; %cond.load256
                                        ;   in Loop: Header=BB0_158 Depth=1
	add	x16, x14, #20
	ld1.s	{ v4 }[1], [x16]
	tbz	w15, #6, LBB0_165
LBB0_172:                               ; %cond.load259
                                        ;   in Loop: Header=BB0_158 Depth=1
	add	x16, x14, #24
	ld1.s	{ v4 }[2], [x16]
	tbz	w15, #7, LBB0_157
LBB0_173:                               ; %cond.load262
                                        ;   in Loop: Header=BB0_158 Depth=1
	add	x14, x14, #28
	ld1.s	{ v4 }[3], [x14]
	b	LBB0_157
LBB0_174:                               ; %direct.schedule.18.preheader
	mov	x9, #0                          ; =0x0
	add	x10, x8, x12
	fmov	w11, s2
	add	x13, sp, #1, lsl #12            ; =4096
	add	x13, x13, #528
	add	x14, sp, #1552
	add	x15, sp, #3088
	add	x16, sp, #16
	b	LBB0_176
LBB0_175:                               ; %else281
                                        ;   in Loop: Header=BB0_176 Depth=1
	add	x9, x9, #32
	cmp	x9, #1536
	b.eq	LBB0_192
LBB0_176:                               ; %direct.true111
                                        ; =>This Inner Loop Header: Depth=1
	add	x1, x13, x9
	ldr	q3, [x1]
	add	x2, x14, x9
	ldr	q4, [x2]
	fmul.4s	v3, v3, v4
	add	x3, x15, x9
	ldr	q4, [x3]
	add	x4, x16, x9
	ldr	q5, [x4]
	fmul.4s	v4, v4, v5
	fsub.4s	v3, v3, v4
	and.16b	v3, v0, v3
	add	x17, x10, x9
	tbnz	w11, #0, LBB0_185
; %bb.177:                              ; %else267
                                        ;   in Loop: Header=BB0_176 Depth=1
	and	w0, w11, #0xff
	tbnz	w0, #1, LBB0_186
LBB0_178:                               ; %else269
                                        ;   in Loop: Header=BB0_176 Depth=1
	tbnz	w0, #2, LBB0_187
LBB0_179:                               ; %else271
                                        ;   in Loop: Header=BB0_176 Depth=1
	tbz	w0, #3, LBB0_181
LBB0_180:                               ; %cond.store272
                                        ;   in Loop: Header=BB0_176 Depth=1
	add	x5, x17, #12
	st1.s	{ v3 }[3], [x5]
LBB0_181:                               ; %else273
                                        ;   in Loop: Header=BB0_176 Depth=1
	ldr	q3, [x1, #16]
	ldr	q4, [x2, #16]
	fmul.4s	v3, v3, v4
	ldr	q4, [x3, #16]
	ldr	q5, [x4, #16]
	fmul.4s	v4, v4, v5
	fsub.4s	v3, v3, v4
	and.16b	v3, v1, v3
	tbnz	w0, #4, LBB0_188
; %bb.182:                              ; %else275
                                        ;   in Loop: Header=BB0_176 Depth=1
	tbnz	w0, #5, LBB0_189
LBB0_183:                               ; %else277
                                        ;   in Loop: Header=BB0_176 Depth=1
	tbnz	w0, #6, LBB0_190
LBB0_184:                               ; %else279
                                        ;   in Loop: Header=BB0_176 Depth=1
	tbz	w0, #7, LBB0_175
	b	LBB0_191
LBB0_185:                               ; %cond.store266
                                        ;   in Loop: Header=BB0_176 Depth=1
	str	s3, [x17]
	and	w0, w11, #0xff
	tbz	w0, #1, LBB0_178
LBB0_186:                               ; %cond.store268
                                        ;   in Loop: Header=BB0_176 Depth=1
	add	x5, x17, #4
	st1.s	{ v3 }[1], [x5]
	tbz	w0, #2, LBB0_179
LBB0_187:                               ; %cond.store270
                                        ;   in Loop: Header=BB0_176 Depth=1
	add	x5, x17, #8
	st1.s	{ v3 }[2], [x5]
	tbnz	w0, #3, LBB0_180
	b	LBB0_181
LBB0_188:                               ; %cond.store274
                                        ;   in Loop: Header=BB0_176 Depth=1
	str	s3, [x17, #16]
	tbz	w0, #5, LBB0_183
LBB0_189:                               ; %cond.store276
                                        ;   in Loop: Header=BB0_176 Depth=1
	add	x1, x17, #20
	st1.s	{ v3 }[1], [x1]
	tbz	w0, #6, LBB0_184
LBB0_190:                               ; %cond.store278
                                        ;   in Loop: Header=BB0_176 Depth=1
	add	x1, x17, #24
	st1.s	{ v3 }[2], [x1]
	tbz	w0, #7, LBB0_175
LBB0_191:                               ; %cond.store280
                                        ;   in Loop: Header=BB0_176 Depth=1
	add	x17, x17, #28
	st1.s	{ v3 }[3], [x17]
	b	LBB0_175
LBB0_192:                               ; %direct.schedule.21.preheader
	mov	x9, #0                          ; =0x0
	add	x8, x12, x8
	add	x8, x8, #1536
	fmov	w10, s2
	add	x11, sp, #1, lsl #12            ; =4096
	add	x11, x11, #528
	add	x12, sp, #16
	add	x13, sp, #3088
	add	x14, sp, #1552
	b	LBB0_194
LBB0_193:                               ; %else298
                                        ;   in Loop: Header=BB0_194 Depth=1
	add	x9, x9, #32
	cmp	x9, #1536
	b.eq	LBB0_210
LBB0_194:                               ; %direct.true144
                                        ; =>This Inner Loop Header: Depth=1
	add	x17, x11, x9
	ldr	q2, [x17]
	add	x0, x12, x9
	ldr	q3, [x0]
	fmul.4s	v2, v2, v3
	add	x1, x13, x9
	ldr	q3, [x1]
	add	x2, x14, x9
	ldr	q4, [x2]
	fmul.4s	v3, v3, v4
	fadd.4s	v2, v2, v3
	and.16b	v2, v0, v2
	add	x15, x8, x9
	tbnz	w10, #0, LBB0_203
; %bb.195:                              ; %else284
                                        ;   in Loop: Header=BB0_194 Depth=1
	and	w16, w10, #0xff
	tbnz	w16, #1, LBB0_204
LBB0_196:                               ; %else286
                                        ;   in Loop: Header=BB0_194 Depth=1
	tbnz	w16, #2, LBB0_205
LBB0_197:                               ; %else288
                                        ;   in Loop: Header=BB0_194 Depth=1
	tbz	w16, #3, LBB0_199
LBB0_198:                               ; %cond.store289
                                        ;   in Loop: Header=BB0_194 Depth=1
	add	x3, x15, #12
	st1.s	{ v2 }[3], [x3]
LBB0_199:                               ; %else290
                                        ;   in Loop: Header=BB0_194 Depth=1
	ldr	q2, [x17, #16]
	ldr	q3, [x0, #16]
	fmul.4s	v2, v2, v3
	ldr	q3, [x1, #16]
	ldr	q4, [x2, #16]
	fmul.4s	v3, v3, v4
	fadd.4s	v2, v2, v3
	and.16b	v2, v1, v2
	tbnz	w16, #4, LBB0_206
; %bb.200:                              ; %else292
                                        ;   in Loop: Header=BB0_194 Depth=1
	tbnz	w16, #5, LBB0_207
LBB0_201:                               ; %else294
                                        ;   in Loop: Header=BB0_194 Depth=1
	tbnz	w16, #6, LBB0_208
LBB0_202:                               ; %else296
                                        ;   in Loop: Header=BB0_194 Depth=1
	tbz	w16, #7, LBB0_193
	b	LBB0_209
LBB0_203:                               ; %cond.store283
                                        ;   in Loop: Header=BB0_194 Depth=1
	str	s2, [x15]
	and	w16, w10, #0xff
	tbz	w16, #1, LBB0_196
LBB0_204:                               ; %cond.store285
                                        ;   in Loop: Header=BB0_194 Depth=1
	add	x3, x15, #4
	st1.s	{ v2 }[1], [x3]
	tbz	w16, #2, LBB0_197
LBB0_205:                               ; %cond.store287
                                        ;   in Loop: Header=BB0_194 Depth=1
	add	x3, x15, #8
	st1.s	{ v2 }[2], [x3]
	tbnz	w16, #3, LBB0_198
	b	LBB0_199
LBB0_206:                               ; %cond.store291
                                        ;   in Loop: Header=BB0_194 Depth=1
	str	s2, [x15, #16]
	tbz	w16, #5, LBB0_201
LBB0_207:                               ; %cond.store293
                                        ;   in Loop: Header=BB0_194 Depth=1
	add	x17, x15, #20
	st1.s	{ v2 }[1], [x17]
	tbz	w16, #6, LBB0_202
LBB0_208:                               ; %cond.store295
                                        ;   in Loop: Header=BB0_194 Depth=1
	add	x17, x15, #24
	st1.s	{ v2 }[2], [x17]
	tbz	w16, #7, LBB0_193
LBB0_209:                               ; %cond.store297
                                        ;   in Loop: Header=BB0_194 Depth=1
	add	x15, x15, #28
	st1.s	{ v2 }[3], [x15]
	b	LBB0_193
LBB0_210:
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #2064
	ldp	x28, x27, [sp], #16             ; 16-byte Folded Reload
LBB0_211:                               ; %common.ret
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
                                        ; -- End function
	.p2align	2                               ; -- Begin function llm_rows.full_packet
_llm_rows.full_packet:                  ; @llm_rows.full_packet
; %bb.0:                                ; %prologue
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #2048
	ldr	x8, [x0]
	ldr	x22, [x0, #16]
	ldr	x21, [x0, #32]
	ldr	x20, [x0, #48]
	ldr	w9, [x1]
	ldr	w10, [x1, #36]
	add	w9, w10, w9, lsl #5
	lsr	w9, w9, #3
	dup.2s	v0, w9
	ushll.2d	v1, v0, #0
	subs	x9, x8, x20
	cset	w10, hs
	lsr	x9, x9, #10
	cmp	x9, #386
	csel	w9, wzr, w10, ls
	subs	x10, x20, x8
	cset	w11, hs
	lsr	x10, x10, #10
	cmp	x10, #386
	csel	w10, wzr, w11, ls
	subs	x11, x22, x20
	cset	w12, hs
	lsr	x11, x11, #10
	cmp	x11, #386
	csel	w11, wzr, w12, ls
	subs	x12, x20, x22
	cset	w13, hs
	lsr	x12, x12, #9
	cmp	x12, #386
	csel	w12, wzr, w13, ls
	subs	x13, x21, x20
	cset	w14, hs
	lsr	x13, x13, #10
	cmp	x13, #386
	csel	w13, wzr, w14, ls
	subs	x14, x20, x21
	cset	w15, hs
	lsr	x14, x14, #9
	cmp	x14, #386
	csel	w14, wzr, w15, ls
	orr	w13, w13, w14
	cmp	w13, #1
	b.ne	LBB1_5
; %bb.1:                                ; %prologue
	orr	w9, w9, w10
	cbz	w9, LBB1_5
; %bb.2:                                ; %prologue
	orr	w9, w11, w12
	tbz	w9, #0, LBB1_5
; %bb.3:                                ; %direct.schedule.2.preheader
	mov	x9, #0                          ; =0x0
	movi.2s	v0, #3, lsl #8
	xtn.2s	v2, v1
	umull.2d	v0, v2, v0
	fmov	x11, d0
	fmov	x10, d1
	add	x10, x10, x10, lsl #1
	lsl	x10, x10, #7
	lsl	x11, x11, #2
	add	x12, x11, #1536
	add	x11, x8, x12
	add	x12, x20, x12
LBB1_4:                                 ; %direct.true30
                                        ; =>This Inner Loop Header: Depth=1
	fmov	d1, x9
	add.2d	v1, v1, v0
	fmov	x13, d1
	lsl	x13, x13, #2
	add	x14, x8, x13
	ldp	q1, q2, [x14]
	ldp	q3, q4, [x11], #32
	add	x14, x9, x10
	lsl	x14, x14, #2
	add	x15, x22, x14
	ldp	q5, q6, [x15]
	add	x14, x21, x14
	ldp	q7, q16, [x14]
	fmul.4s	v17, v2, v6
	fmul.4s	v18, v1, v5
	fmul.4s	v19, v4, v16
	fmul.4s	v20, v3, v7
	fsub.4s	v18, v18, v20
	fsub.4s	v17, v17, v19
	add	x13, x20, x13
	stp	q18, q17, [x13]
	fmul.4s	v2, v2, v16
	fmul.4s	v1, v1, v7
	fmul.4s	v4, v4, v6
	fmul.4s	v3, v3, v5
	fadd.4s	v1, v3, v1
	fadd.4s	v2, v4, v2
	stp	q1, q2, [x12], #32
	add	x9, x9, #8
	cmp	x9, #384
	b.ne	LBB1_4
	b	LBB1_9
LBB1_5:                                 ; %direct.schedule.6.preheader
	fmov	x9, d1
	add	x26, x9, x9, lsl #1
	lsl	x23, x26, #10
	add	x19, x8, x23
	add	x24, sp, #1, lsl #12            ; =4096
	add	x24, x24, #512
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #512
	mov	x1, x19
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	add	x25, sp, #3072
	add	x0, sp, #3072
	add	x1, x19, #1536
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	lsl	x26, x26, #9
	add	x19, sp, #1536
	add	x0, sp, #1536
	add	x1, x22, x26
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	mov	x22, sp
	mov	x0, sp
	add	x1, x21, x26
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	add	x9, x20, x23
LBB1_6:                                 ; %direct.true111
                                        ; =>This Inner Loop Header: Depth=1
	add	x10, x24, x8
	ldp	q0, q1, [x10]
	add	x10, x19, x8
	ldp	q2, q3, [x10]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	add	x10, x25, x8
	ldp	q2, q3, [x10]
	add	x10, x22, x8
	ldp	q4, q5, [x10]
	fmul.4s	v3, v3, v5
	fmul.4s	v2, v2, v4
	fsub.4s	v0, v0, v2
	fsub.4s	v1, v1, v3
	add	x10, x9, x8
	stp	q0, q1, [x10]
	add	x8, x8, #32
	cmp	x8, #1536
	b.ne	LBB1_6
; %bb.7:                                ; %direct.schedule.21.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x23, x20
	add	x9, x9, #1536
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #512
	mov	x11, sp
	add	x12, sp, #3072
	add	x13, sp, #1536
LBB1_8:                                 ; %direct.true144
                                        ; =>This Inner Loop Header: Depth=1
	add	x14, x10, x8
	ldp	q0, q1, [x14]
	add	x14, x11, x8
	ldp	q2, q3, [x14]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	add	x14, x12, x8
	ldp	q2, q3, [x14]
	add	x14, x13, x8
	ldp	q4, q5, [x14]
	fmul.4s	v3, v3, v5
	fmul.4s	v2, v2, v4
	fadd.4s	v0, v0, v2
	fadd.4s	v1, v1, v3
	add	x14, x9, x8
	stp	q0, q1, [x14]
	add	x8, x8, #32
	cmp	x8, #1536
	b.ne	LBB1_8
LBB1_9:                                 ; %common.ret
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #2048
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB2_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB2_4
LBB2_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB2_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB2_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB2_13
LBB2_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB2_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB2_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #1
	b.eq	LBB2_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #2
	b.eq	LBB2_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #3
	b.eq	LBB2_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB2_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB2_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
LBB2_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB2_3
LBB2_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB2_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

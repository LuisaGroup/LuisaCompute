	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_3:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_4:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_5:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_6:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_8:
	.quad	6144                            ; 0x1800
	.quad	6148                            ; 0x1804
lCPI0_9:
	.quad	6160                            ; 0x1810
	.quad	6164                            ; 0x1814
lCPI0_10:
	.quad	6152                            ; 0x1808
	.quad	6156                            ; 0x180c
lCPI0_11:
	.quad	6168                            ; 0x1818
	.quad	6172                            ; 0x181c
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_7:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
lCPI0_12:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #3, lsl #12             ; =12288
	sub	sp, sp, #832
	dup.4s	v0, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q1, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q2, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v6, v0, v2
	cmhi.4s	v27, v0, v1
	uzp1.8h	v0, v27, v6
	str	q0, [sp, #240]                  ; 16-byte Spill
	umaxv.8h	h0, v0
	fmov	w8, s0
	tbz	w8, #0, LBB0_204
; %bb.1:                                ; %direct.activate
	ldr	x16, [x0]
	ldr	x2, [x0, #16]
	ldr	x3, [x0, #48]
	sshll.2d	v1, v27, #0
	sshll.2d	v2, v6, #0
	sshll2.2d	v0, v27, #0
	sshll2.2d	v19, v6, #0
	ldr	w8, [x1]
	ldr	w9, [x1, #36]
	add	w8, w9, w8, lsl #5
Lloh4:
	adrp	x9, lCPI0_2@PAGE
Lloh5:
	ldr	q3, [x9, lCPI0_2@PAGEOFF]
	and.16b	v3, v19, v3
	str	q3, [sp, #224]                  ; 16-byte Spill
Lloh6:
	adrp	x9, lCPI0_3@PAGE
Lloh7:
	ldr	q3, [x9, lCPI0_3@PAGEOFF]
	and.16b	v3, v0, v3
	str	q3, [sp, #208]                  ; 16-byte Spill
Lloh8:
	adrp	x9, lCPI0_4@PAGE
Lloh9:
	ldr	q3, [x9, lCPI0_4@PAGEOFF]
	and.16b	v2, v2, v3
	str	q2, [sp, #192]                  ; 16-byte Spill
Lloh10:
	adrp	x9, lCPI0_5@PAGE
Lloh11:
	ldr	q2, [x9, lCPI0_5@PAGEOFF]
	and.16b	v1, v1, v2
	str	q1, [sp, #128]                  ; 16-byte Spill
	lsr	w8, w8, #3
	dup.4s	v1, w8
	and.16b	v2, v27, v1
	and.16b	v1, v6, v1
	ushll2.2d	v3, v1, #0
	ushll2.2d	v4, v2, #0
	ushll.2d	v1, v1, #0
	ushll.2d	v2, v2, #0
	subs	x8, x16, x3
	cset	w9, hs
	mov	w10, #8199                      ; =0x2007
	movk	w10, #24, lsl #16
	cmp	x8, x10
	csel	w8, wzr, w9, ls
	subs	x9, x3, x16
	cset	w11, hs
	cmp	x9, x10
	csel	w9, wzr, w11, ls
	orr	w12, w8, w9
	subs	x8, x2, x3
	cset	w9, hs
	cmp	x8, x10
	csel	w8, wzr, w9, ls
	subs	x9, x3, x2
	cset	w11, hs
	cmp	x9, x10
	csel	w11, wzr, w11, ls
	str	q2, [sp, #112]                  ; 16-byte Spill
	fmov	x9, d2
	mov	w10, #6152                      ; =0x1808
	umull	x9, w9, w10
	adrp	x10, lCPI0_6@PAGE
	adrp	x17, lCPI0_7@PAGE
	xtn.2s	v2, v3
	str	d2, [sp, #176]                  ; 8-byte Spill
	xtn.2s	v1, v1
	str	d1, [sp, #160]                  ; 8-byte Spill
	xtn.2s	v1, v4
	str	d1, [sp, #144]                  ; 8-byte Spill
	adrp	x4, lCPI0_12@PAGE
	cmp	w12, #1
	stp	q27, q6, [sp, #368]             ; 32-byte Folded Spill
	b.ne	LBB0_53
; %bb.2:                                ; %direct.activate
	orr	w8, w8, w11
	cbz	w8, LBB0_53
; %bb.3:                                ; %direct.true20.preheader
	mov	x13, #0                         ; =0x0
	str	x3, [sp, #96]                   ; 8-byte Spill
	add	x14, x3, x9
	str	x2, [sp, #80]                   ; 8-byte Spill
	add	x15, x2, x9
	str	x16, [sp, #64]                  ; 8-byte Spill
	add	x16, x16, x9
	ldr	q0, [x10, lCPI0_6@PAGEOFF]
	ldr	q1, [sp, #240]                  ; 16-byte Reload
	and.16b	v0, v1, v0
	addv.8h	h21, v0
	fmov	w17, s21
	movi.4s	v12, #63, lsl #24
	mov	w1, #16938                      ; =0x422a
	movk	w1, #16204, lsl #16
	mov	w2, #37425                      ; =0x9231
	movk	w2, #12080, lsl #16
	mov	w3, #12843                      ; =0x322b
	movk	w3, #13015, lsl #16
	mov	w4, #61213                      ; =0xef1d
	movk	w4, #13880, lsl #16
	mov	w5, #3329                       ; =0xd01
	movk	w5, #14672, lsl #16
	mov	w6, #34953                      ; =0x8889
	movk	w6, #15368, lsl #16
	mov	w7, #43691                      ; =0xaaab
	movk	w7, #15914, lsl #16
	mov	w19, #30407                     ; =0x76c7
	movk	w19, #12559, lsl #16
	mov	w20, #62078                     ; =0xf27e
	movk	w20, #13459, lsl #16
	mov	w21, #3329                      ; =0xd01
	movk	w21, #14288, lsl #16
	mov	w22, #2913                      ; =0xb61
	movk	w22, #15030, lsl #16
	mov	w23, #43691                     ; =0xaaab
	movk	w23, #15658, lsl #16
	mov	w24, #-1026555904               ; =0xc2d00000
	mov	w25, #1120403456                ; =0x42c80000
	mov	w26, #43579                     ; =0xaa3b
	movk	w26, #16312, lsl #16
	movi.4s	v8, #75, lsl #24
	movi.4s	v10, #203, lsl #24
	mov	w27, #29184                     ; =0x7200
	movk	w27, #48945, lsl #16
	mov	w28, #48782                     ; =0xbe8e
	movk	w28, #46527, lsl #16
	mov	w30, #11226                     ; =0x2bda
	movk	w30, #14672, lsl #16
	mov	w10, #38601                     ; =0x96c9
	movk	w10, #15030, lsl #16
	mov	w11, #34982                     ; =0x88a6
	movk	w11, #15368, lsl #16
	mov	w8, #43642                      ; =0xaa7a
	movk	w8, #15658, lsl #16
	mvni.4s	v0, #127, msl #16
	fneg.4s	v0, v0
	str	q0, [sp, #352]                  ; 16-byte Spill
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	stp	q0, q21, [sp, #256]             ; 32-byte Folded Spill
	fmov.4s	v13, #1.00000000
	b	LBB0_5
LBB0_4:                                 ; %else69
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x13, x13, #1
	cmp	x13, #192
	b.eq	LBB0_134
LBB0_5:                                 ; %direct.true20
                                        ; =>This Inner Loop Header: Depth=1
	add	x9, x16, x13, lsl #5
	movi.2d	v31, #0000000000000000
	movi.2d	v30, #0000000000000000
	tbnz	w17, #0, LBB0_31
; %bb.6:                                ; %else
                                        ;   in Loop: Header=BB0_5 Depth=1
	and	w12, w17, #0xff
	tbnz	w12, #1, LBB0_32
LBB0_7:                                 ; %else9
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w12, #2, LBB0_33
LBB0_8:                                 ; %else12
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w12, #3, LBB0_34
LBB0_9:                                 ; %else15
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w12, #4, LBB0_35
LBB0_10:                                ; %else18
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w12, #5, LBB0_36
LBB0_11:                                ; %else21
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w12, #6, LBB0_37
LBB0_12:                                ; %else24
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w12, #7, LBB0_38
LBB0_13:                                ; %else27
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	w12, s21
	add	x9, x15, x13, lsl #5
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	tbnz	w12, #0, LBB0_39
LBB0_14:                                ; %else31
                                        ;   in Loop: Header=BB0_5 Depth=1
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_40
LBB0_15:                                ; %else34
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w12, #2, LBB0_41
LBB0_16:                                ; %else37
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w12, #3, LBB0_42
LBB0_17:                                ; %else40
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w12, #4, LBB0_43
LBB0_18:                                ; %else43
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w12, #5, LBB0_44
LBB0_19:                                ; %else46
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w12, #6, LBB0_45
LBB0_20:                                ; %else49
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w12, #7, LBB0_22
LBB0_21:                                ; %cond.load51
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x9, x9, #28
	ld1.s	{ v1 }[3], [x9]
LBB0_22:                                ; %else52
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	q1, [sp, #336]                  ; 16-byte Spill
	mov	w9, #10003                      ; =0x2713
	movk	w9, #15671, lsl #16
	dup.4s	v1, w9
	str	q1, [sp, #320]                  ; 16-byte Spill
	fmul.4s	v1, v31, v1
	fmul.4s	v1, v31, v1
	fmul.4s	v1, v31, v1
	fadd.4s	v1, v31, v1
	dup.4s	v2, w1
	str	q2, [sp, #304]                  ; 16-byte Spill
	fmul.4s	v1, v1, v2
	and.16b	v28, v27, v1
	fabs.4s	v20, v28
	fmul.4s	v4, v28, v28
	dup.4s	v2, w2
	dup.4s	v11, w3
	mov.16b	v1, v11
	str	q2, [sp, #288]                  ; 16-byte Spill
	fmla.4s	v1, v4, v2
	dup.4s	v14, w4
	mov.16b	v2, v14
	fmla.4s	v2, v4, v1
	dup.4s	v15, w5
	mov.16b	v1, v15
	fmla.4s	v1, v4, v2
	dup.4s	v5, w6
	mov.16b	v2, v5
	fmla.4s	v2, v4, v1
	dup.4s	v1, w7
	mov.16b	v3, v1
	fmla.4s	v3, v4, v2
	fmov.4s	v2, #1.00000000
	fmla.4s	v2, v4, v3
	dup.4s	v6, w19
	fmul.4s	v17, v20, v2
	dup.4s	v7, w20
	mov.16b	v2, v7
	dup.4s	v16, w21
	fmla.4s	v2, v4, v6
	mov.16b	v3, v16
	fmla.4s	v3, v4, v2
	dup.4s	v2, w22
	mov.16b	v18, v2
	fmla.4s	v18, v4, v3
	dup.4s	v3, w23
	mov.16b	v22, v3
	fmla.4s	v22, v4, v18
	movi.4s	v18, #63, lsl #24
	fmla.4s	v18, v4, v22
	fmov.4s	v22, #1.00000000
	fmla.4s	v22, v4, v18
	fdiv.4s	v19, v17, v22
	fmov.4s	v4, #9.00000000
	fcmge.4s	v26, v4, v20
	and.16b	v29, v26, v20
	dup.4s	v4, w24
	fcmge.4s	v17, v29, v4
	dup.4s	v9, w25
	fcmge.4s	v18, v9, v29
	and.16b	v17, v17, v18
	and.16b	v22, v17, v29
	dup.4s	v18, w26
	fmul.4s	v17, v22, v18
	fadd.4s	v17, v17, v8
	fadd.4s	v17, v17, v10
	fcvtzs.4s	v21, v17
	scvtf.4s	v23, v21
	dup.4s	v17, w27
	fmul.4s	v24, v23, v17
	fadd.4s	v24, v22, v24
	dup.4s	v22, w28
	fmul.4s	v25, v23, v22
	dup.4s	v23, w30
	fadd.4s	v8, v24, v25
	fmul.4s	v25, v8, v23
	dup.4s	v24, w10
	fadd.4s	v25, v25, v24
	fmul.4s	v27, v8, v25
	dup.4s	v25, w11
	fadd.4s	v27, v27, v25
	fmul.4s	v10, v8, v27
	dup.4s	v27, w8
	fadd.4s	v10, v10, v27
	fmul.4s	v10, v8, v10
	fadd.4s	v10, v10, v1
	fmul.4s	v10, v8, v10
	fadd.4s	v10, v10, v12
	fmul.4s	v12, v8, v8
	fmul.4s	v10, v12, v10
	fadd.4s	v8, v8, v10
	fadd.4s	v8, v8, v13
	movi.2d	v10, #0xffffffffffffffff
	add.4s	v21, v21, v10
	sshr.4s	v10, v21, #1
	shl.4s	v12, v10, #23
	add.4s	v12, v12, v13
	fmul.4s	v8, v8, v12
	movi.4s	v12, #63, lsl #24
	sub.4s	v21, v21, v10
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v13
	fmul.4s	v21, v8, v21
	fcmgt.4s	v29, v29, v9
	ldr	q8, [sp, #352]                  ; 16-byte Reload
	bit.16b	v21, v8, v29
	fmov.4s	v29, #0.25000000
	fdiv.4s	v29, v29, v21
	fsub.4s	v8, v21, v29
	fadd.4s	v21, v21, v29
	fdiv.4s	v21, v8, v21
	bif.16b	v21, v13, v26
	fcmge.4s	v20, v13, v20
	bif.16b	v19, v21, v20
	mvni.4s	v29, #128, lsl #24
	bif.16b	v19, v28, v29
	fcmeq.4s	v20, v28, v28
	fadd.4s	v19, v19, v13
	ldp	q28, q21, [sp, #256]            ; 32-byte Folded Reload
	bif.16b	v19, v28, v20
	fmul.4s	v20, v31, v12
	fmul.4s	v19, v20, v19
	fadd.4s	v0, v0, v19
	fmov	w12, s21
	add	x9, x14, x13, lsl #5
	tbnz	w12, #0, LBB0_46
; %bb.23:                               ; %else55
                                        ;   in Loop: Header=BB0_5 Depth=1
	and	w12, w12, #0xff
	ldr	q19, [sp, #384]                 ; 16-byte Reload
	tbnz	w12, #1, LBB0_47
LBB0_24:                                ; %else57
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov.4s	v26, #9.00000000
	movi.4s	v8, #75, lsl #24
	movi.4s	v10, #203, lsl #24
	tbnz	w12, #2, LBB0_48
LBB0_25:                                ; %else59
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w12, #3, LBB0_27
LBB0_26:                                ; %cond.store60
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x9, #12
	st1.s	{ v0 }[3], [x0]
LBB0_27:                                ; %else61
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldp	q20, q0, [sp, #304]             ; 32-byte Folded Reload
	fmul.4s	v0, v30, v0
	fmul.4s	v0, v30, v0
	fmul.4s	v0, v30, v0
	fadd.4s	v0, v30, v0
	fmul.4s	v0, v0, v20
	and.16b	v0, v19, v0
	fmul.4s	v19, v0, v0
	ldr	q20, [sp, #288]                 ; 16-byte Reload
	fmla.4s	v11, v19, v20
	fmla.4s	v14, v19, v11
	fmla.4s	v15, v19, v14
	fmla.4s	v5, v19, v15
	mov.16b	v20, v1
	fmla.4s	v20, v19, v5
	fmov.4s	v5, #1.00000000
	fmla.4s	v5, v19, v20
	fmla.4s	v7, v19, v6
	fmla.4s	v16, v19, v7
	fmla.4s	v2, v19, v16
	fabs.4s	v6, v0
	fmul.4s	v5, v6, v5
	fmla.4s	v3, v19, v2
	movi.4s	v2, #63, lsl #24
	fmla.4s	v2, v19, v3
	fmov.4s	v3, #1.00000000
	fmla.4s	v3, v19, v2
	fdiv.4s	v2, v5, v3
	fcmge.4s	v3, v26, v6
	and.16b	v5, v3, v6
	fcmge.4s	v4, v5, v4
	fcmge.4s	v7, v9, v5
	and.16b	v4, v4, v7
	and.16b	v4, v4, v5
	fmul.4s	v7, v4, v18
	fadd.4s	v7, v7, v8
	fadd.4s	v7, v7, v10
	fcvtzs.4s	v7, v7
	scvtf.4s	v16, v7
	fmul.4s	v17, v16, v17
	fadd.4s	v4, v4, v17
	fmul.4s	v16, v16, v22
	fadd.4s	v4, v4, v16
	fmul.4s	v16, v4, v23
	fadd.4s	v16, v16, v24
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v25
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v27
	fmul.4s	v16, v4, v16
	fadd.4s	v1, v16, v1
	fmul.4s	v1, v4, v1
	fadd.4s	v1, v1, v12
	fmul.4s	v16, v4, v4
	fmul.4s	v1, v16, v1
	fadd.4s	v1, v4, v1
	fmov.4s	v17, #1.00000000
	fadd.4s	v1, v1, v17
	movi.2d	v4, #0xffffffffffffffff
	add.4s	v4, v7, v4
	sshr.4s	v7, v4, #1
	shl.4s	v16, v7, #23
	add.4s	v16, v16, v17
	fmul.4s	v1, v1, v16
	sub.4s	v4, v4, v7
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v17
	fmul.4s	v1, v1, v4
	fcmgt.4s	v4, v5, v9
	ldr	q5, [sp, #352]                  ; 16-byte Reload
	bit.16b	v1, v5, v4
	fmov.4s	v4, #0.25000000
	fdiv.4s	v4, v4, v1
	fsub.4s	v5, v1, v4
	fadd.4s	v1, v1, v4
	fdiv.4s	v1, v5, v1
	bif.16b	v1, v17, v3
	fcmge.4s	v3, v17, v6
	bit.16b	v1, v2, v3
	bif.16b	v1, v0, v29
	fcmeq.4s	v0, v0, v0
	fadd.4s	v1, v1, v17
	bsl.16b	v0, v1, v28
	fmul.4s	v1, v30, v12
	fmul.4s	v0, v1, v0
	ldr	q1, [sp, #336]                  ; 16-byte Reload
	fadd.4s	v0, v1, v0
	tbnz	w12, #4, LBB0_49
; %bb.28:                               ; %else63
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q27, [sp, #368]                 ; 16-byte Reload
	tbnz	w12, #5, LBB0_50
LBB0_29:                                ; %else65
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w12, #6, LBB0_51
LBB0_30:                                ; %else67
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w12, #7, LBB0_4
	b	LBB0_52
LBB0_31:                                ; %cond.load
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	s31, [x9]
	and	w12, w17, #0xff
	tbz	w12, #1, LBB0_7
LBB0_32:                                ; %cond.load8
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x9, #4
	ld1.s	{ v31 }[1], [x0]
	tbz	w12, #2, LBB0_8
LBB0_33:                                ; %cond.load11
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x9, #8
	ld1.s	{ v31 }[2], [x0]
	tbz	w12, #3, LBB0_9
LBB0_34:                                ; %cond.load14
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x9, #12
	ld1.s	{ v31 }[3], [x0]
	tbz	w12, #4, LBB0_10
LBB0_35:                                ; %cond.load17
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x9, #16
	ld1.s	{ v30 }[0], [x0]
	tbz	w12, #5, LBB0_11
LBB0_36:                                ; %cond.load20
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x9, #20
	ld1.s	{ v30 }[1], [x0]
	tbz	w12, #6, LBB0_12
LBB0_37:                                ; %cond.load23
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x9, #24
	ld1.s	{ v30 }[2], [x0]
	tbz	w12, #7, LBB0_13
LBB0_38:                                ; %cond.load26
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x9, x9, #28
	ld1.s	{ v30 }[3], [x9]
	fmov	w12, s21
	add	x9, x15, x13, lsl #5
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	tbz	w12, #0, LBB0_14
LBB0_39:                                ; %cond.load30
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	s0, [x9]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_15
LBB0_40:                                ; %cond.load33
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x9, #4
	ld1.s	{ v0 }[1], [x0]
	tbz	w12, #2, LBB0_16
LBB0_41:                                ; %cond.load36
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x9, #8
	ld1.s	{ v0 }[2], [x0]
	tbz	w12, #3, LBB0_17
LBB0_42:                                ; %cond.load39
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x9, #12
	ld1.s	{ v0 }[3], [x0]
	tbz	w12, #4, LBB0_18
LBB0_43:                                ; %cond.load42
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x9, #16
	ld1.s	{ v1 }[0], [x0]
	tbz	w12, #5, LBB0_19
LBB0_44:                                ; %cond.load45
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x9, #20
	ld1.s	{ v1 }[1], [x0]
	tbz	w12, #6, LBB0_20
LBB0_45:                                ; %cond.load48
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x9, #24
	ld1.s	{ v1 }[2], [x0]
	tbnz	w12, #7, LBB0_21
	b	LBB0_22
LBB0_46:                                ; %cond.store
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	s0, [x9]
	and	w12, w12, #0xff
	ldr	q19, [sp, #384]                 ; 16-byte Reload
	tbz	w12, #1, LBB0_24
LBB0_47:                                ; %cond.store56
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x9, #4
	st1.s	{ v0 }[1], [x0]
	fmov.4s	v26, #9.00000000
	movi.4s	v8, #75, lsl #24
	movi.4s	v10, #203, lsl #24
	tbz	w12, #2, LBB0_25
LBB0_48:                                ; %cond.store58
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x9, #8
	st1.s	{ v0 }[2], [x0]
	tbnz	w12, #3, LBB0_26
	b	LBB0_27
LBB0_49:                                ; %cond.store62
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	s0, [x9, #16]
	ldr	q27, [sp, #368]                 ; 16-byte Reload
	tbz	w12, #5, LBB0_29
LBB0_50:                                ; %cond.store64
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x9, #20
	st1.s	{ v0 }[1], [x0]
	tbz	w12, #6, LBB0_30
LBB0_51:                                ; %cond.store66
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x0, x9, #24
	st1.s	{ v0 }[2], [x0]
	tbz	w12, #7, LBB0_4
LBB0_52:                                ; %cond.store68
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x9, x9, #28
	st1.s	{ v0 }[3], [x9]
	b	LBB0_4
LBB0_53:                                ; %direct.schedule.8.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x16, x9
	ldr	q1, [x10, lCPI0_6@PAGEOFF]
	ldr	q2, [sp, #240]                  ; 16-byte Reload
	and.16b	v1, v2, v1
	addv.8h	h20, v1
	fmov	w10, s20
	add	x11, sp, #1, lsl #12            ; =4096
	add	x11, x11, #2848
	b	LBB0_55
LBB0_54:                                ; %else160
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x12, x11, x8, lsl #5
	stp	q1, q2, [x12]
	add	x8, x8, #1
	cmp	x8, #192
	b.eq	LBB0_71
LBB0_55:                                ; %direct.true40
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x13, x8, #5
	add	x12, x9, x13
	add	x14, x11, x13
	ldr	q1, [x14]
	tbnz	w10, #0, LBB0_63
; %bb.56:                               ; %else139
                                        ;   in Loop: Header=BB0_55 Depth=1
	and	w13, w10, #0xff
	tbnz	w13, #1, LBB0_64
LBB0_57:                                ; %else142
                                        ;   in Loop: Header=BB0_55 Depth=1
	tbnz	w13, #2, LBB0_65
LBB0_58:                                ; %else145
                                        ;   in Loop: Header=BB0_55 Depth=1
	tbnz	w13, #3, LBB0_66
LBB0_59:                                ; %else148
                                        ;   in Loop: Header=BB0_55 Depth=1
	ldr	q2, [x14, #16]
	tbnz	w13, #4, LBB0_67
LBB0_60:                                ; %else151
                                        ;   in Loop: Header=BB0_55 Depth=1
	tbnz	w13, #5, LBB0_68
LBB0_61:                                ; %else154
                                        ;   in Loop: Header=BB0_55 Depth=1
	tbnz	w13, #6, LBB0_69
LBB0_62:                                ; %else157
                                        ;   in Loop: Header=BB0_55 Depth=1
	tbz	w13, #7, LBB0_54
	b	LBB0_70
LBB0_63:                                ; %cond.load138
                                        ;   in Loop: Header=BB0_55 Depth=1
	ld1.s	{ v1 }[0], [x12]
	and	w13, w10, #0xff
	tbz	w13, #1, LBB0_57
LBB0_64:                                ; %cond.load141
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x15, x12, #4
	ld1.s	{ v1 }[1], [x15]
	tbz	w13, #2, LBB0_58
LBB0_65:                                ; %cond.load144
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x15, x12, #8
	ld1.s	{ v1 }[2], [x15]
	tbz	w13, #3, LBB0_59
LBB0_66:                                ; %cond.load147
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x15, x12, #12
	ld1.s	{ v1 }[3], [x15]
	ldr	q2, [x14, #16]
	tbz	w13, #4, LBB0_60
LBB0_67:                                ; %cond.load150
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x14, x12, #16
	ld1.s	{ v2 }[0], [x14]
	tbz	w13, #5, LBB0_61
LBB0_68:                                ; %cond.load153
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x14, x12, #20
	ld1.s	{ v2 }[1], [x14]
	tbz	w13, #6, LBB0_62
LBB0_69:                                ; %cond.load156
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x14, x12, #24
	ld1.s	{ v2 }[2], [x14]
	tbz	w13, #7, LBB0_54
LBB0_70:                                ; %cond.load159
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x12, x12, #28
	ld1.s	{ v2 }[3], [x12]
	b	LBB0_54
LBB0_71:                                ; %direct.false41
	ldr	q1, [sp, #240]                  ; 16-byte Reload
	xtn.8b	v1, v1
	sshll.2d	v2, v6, #0
	sshll.2d	v3, v27, #0
	movi	d4, #0x0000000000ffff
	and.8b	v7, v1, v4
	ldr	d4, [x17, lCPI0_7@PAGEOFF]
	and.8b	v1, v1, v4
	addv.8b	b1, v1
	fmov	w13, s1
	umaxv.8b	b1, v7
	fmov	w8, s1
	rbit	w9, w13
	clz	w9, w9
	tst	w8, #0x1
	csel	w11, w9, wzr, ne
	mov	w8, #1536                       ; =0x600
	dup.2d	v1, x8
	ldr	q4, [sp, #112]                  ; 16-byte Reload
	mov.d	x8, v4[1]
	mov	w9, #1538                       ; =0x602
	mul	x8, x8, x9
	fmov	x10, d4
	mul	x10, x10, x9
	fmov	d17, x10
	mov.d	v17[1], x8
	ldr	q4, [sp, #128]                  ; 16-byte Reload
	add.2d	v4, v4, v1
	add.2d	v5, v17, v4
	mov	b4, v7[0]
	mov.b	v4[4], v7[1]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	str	q5, [sp, #128]                  ; 16-byte Spill
	and.16b	v4, v4, v5
	movi.2d	v5, #0000000000000000
	stp	q5, q5, [sp, #656]
	stp	q4, q5, [sp, #624]
	ubfiz	x8, x11, #3, #3
	add	x10, sp, #624
	ldr	x10, [x10, x8]
	sub	x10, x10, x11
	lsl	x10, x10, #2
	add	x12, x16, x10
	mov	w14, #6144                      ; =0x1800
	dup.2d	v4, x14
Lloh12:
	adrp	x14, lCPI0_8@PAGE
Lloh13:
	ldr	q5, [x14, lCPI0_8@PAGEOFF]
	bsl.16b	v3, v5, v4
Lloh14:
	adrp	x14, lCPI0_9@PAGE
Lloh15:
	ldr	q5, [x14, lCPI0_9@PAGEOFF]
	bsl.16b	v2, v5, v4
Lloh16:
	adrp	x14, lCPI0_10@PAGE
Lloh17:
	ldr	q5, [x14, lCPI0_10@PAGEOFF]
	bsl.16b	v0, v5, v4
Lloh18:
	adrp	x14, lCPI0_11@PAGE
Lloh19:
	ldr	q5, [x14, lCPI0_11@PAGEOFF]
	bit.16b	v4, v5, v19
	stp	q2, q4, [sp, #720]
	stp	q3, q0, [sp, #688]
	add	x14, sp, #688
	ldr	x8, [x14, x8]
	sub	x8, x8, w11, uxtw #2
	tst	w13, #0xff
	csel	x8, xzr, x8, eq
	add	x14, sp, #1, lsl #12            ; =4096
	add	x14, x14, #2848
	add	x14, x14, x8
	ldr	q16, [x14]
	tbnz	w13, #0, LBB0_167
; %bb.72:                               ; %else164
	ldp	q4, q3, [sp, #192]              ; 32-byte Folded Reload
	tbnz	w13, #1, LBB0_168
LBB0_73:                                ; %else167
	tbnz	w13, #2, LBB0_169
LBB0_74:                                ; %else170
	tbnz	w13, #3, LBB0_170
LBB0_75:                                ; %else173
	ldr	q18, [x14, #16]
	tbnz	w13, #4, LBB0_171
LBB0_76:                                ; %else176
	tbnz	w13, #5, LBB0_172
LBB0_77:                                ; %else179
	dup.2s	v0, w9
	tbz	w13, #6, LBB0_79
LBB0_78:                                ; %cond.load181
	add	x9, x12, #24
	ld1.s	{ v18 }[2], [x9]
LBB0_79:                                ; %else182
	ldr	d2, [sp, #144]                  ; 8-byte Reload
	umlal.2d	v3, v2, v0
	ldr	d2, [sp, #160]                  ; 8-byte Reload
	umlal.2d	v4, v2, v0
	ldr	q2, [sp, #224]                  ; 16-byte Reload
	ldr	d5, [sp, #176]                  ; 8-byte Reload
	umlal.2d	v2, v5, v0
	mov.16b	v0, v2
	tbz	w13, #7, LBB0_81
; %bb.80:                               ; %cond.load184
	add	x9, x12, #28
	ld1.s	{ v18 }[3], [x9]
LBB0_81:                                ; %else185
	mov	x15, #0                         ; =0x0
	add.2d	v2, v3, v1
	str	q2, [sp, #144]                  ; 16-byte Spill
	add.2d	v2, v4, v1
	add.2d	v0, v0, v1
	stp	q0, q2, [sp, #96]               ; 32-byte Folded Spill
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #2848
	add	x9, x9, x8
	stp	q16, q18, [x9]
	fmov	x9, d17
	lsl	x12, x9, #2
	add	x13, x2, x12
	ushll2.2d	v0, v6, #0
	mov	w9, #1                          ; =0x1
	dup.2d	v1, x9
	and.16b	v12, v0, v1
	ushll2.2d	v0, v27, #0
	and.16b	v23, v0, v1
	ushll.2d	v0, v6, #0
	and.16b	v14, v0, v1
	ushll.2d	v0, v27, #0
	and.16b	v26, v0, v1
	movi.2d	v0, #0000000000000000
	fmov	w9, s20
	add	x14, sp, #768
	movi.2d	v1, #0000000000000000
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	b	LBB0_83
LBB0_82:                                ; %else210
                                        ;   in Loop: Header=BB0_83 Depth=1
	add	x15, x14, x15
	stp	q4, q5, [x15]
	add.2d	v1, v1, v23
	add.2d	v2, v2, v14
	add.2d	v3, v3, v12
	add.2d	v0, v0, v26
	fmov	x15, d0
	cmp	x15, #192
	b.ge	LBB0_99
LBB0_83:                                ; %direct.true62
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x15, x15, #5
	add	x16, x13, x15
	add	x0, x14, x15
	ldr	q4, [x0]
	tbnz	w9, #0, LBB0_91
; %bb.84:                               ; %else189
                                        ;   in Loop: Header=BB0_83 Depth=1
	and	w17, w9, #0xff
	tbnz	w17, #1, LBB0_92
LBB0_85:                                ; %else192
                                        ;   in Loop: Header=BB0_83 Depth=1
	tbnz	w17, #2, LBB0_93
LBB0_86:                                ; %else195
                                        ;   in Loop: Header=BB0_83 Depth=1
	tbnz	w17, #3, LBB0_94
LBB0_87:                                ; %else198
                                        ;   in Loop: Header=BB0_83 Depth=1
	ldr	q5, [x0, #16]
	tbnz	w17, #4, LBB0_95
LBB0_88:                                ; %else201
                                        ;   in Loop: Header=BB0_83 Depth=1
	tbnz	w17, #5, LBB0_96
LBB0_89:                                ; %else204
                                        ;   in Loop: Header=BB0_83 Depth=1
	tbnz	w17, #6, LBB0_97
LBB0_90:                                ; %else207
                                        ;   in Loop: Header=BB0_83 Depth=1
	tbz	w17, #7, LBB0_82
	b	LBB0_98
LBB0_91:                                ; %cond.load188
                                        ;   in Loop: Header=BB0_83 Depth=1
	ld1.s	{ v4 }[0], [x16]
	and	w17, w9, #0xff
	tbz	w17, #1, LBB0_85
LBB0_92:                                ; %cond.load191
                                        ;   in Loop: Header=BB0_83 Depth=1
	add	x1, x16, #4
	ld1.s	{ v4 }[1], [x1]
	tbz	w17, #2, LBB0_86
LBB0_93:                                ; %cond.load194
                                        ;   in Loop: Header=BB0_83 Depth=1
	add	x1, x16, #8
	ld1.s	{ v4 }[2], [x1]
	tbz	w17, #3, LBB0_87
LBB0_94:                                ; %cond.load197
                                        ;   in Loop: Header=BB0_83 Depth=1
	add	x1, x16, #12
	ld1.s	{ v4 }[3], [x1]
	ldr	q5, [x0, #16]
	tbz	w17, #4, LBB0_88
LBB0_95:                                ; %cond.load200
                                        ;   in Loop: Header=BB0_83 Depth=1
	add	x0, x16, #16
	ld1.s	{ v5 }[0], [x0]
	tbz	w17, #5, LBB0_89
LBB0_96:                                ; %cond.load203
                                        ;   in Loop: Header=BB0_83 Depth=1
	add	x0, x16, #20
	ld1.s	{ v5 }[1], [x0]
	tbz	w17, #6, LBB0_90
LBB0_97:                                ; %cond.load206
                                        ;   in Loop: Header=BB0_83 Depth=1
	add	x0, x16, #24
	ld1.s	{ v5 }[2], [x0]
	tbz	w17, #7, LBB0_82
LBB0_98:                                ; %cond.load209
                                        ;   in Loop: Header=BB0_83 Depth=1
	add	x16, x16, #28
	ld1.s	{ v5 }[3], [x16]
	b	LBB0_82
LBB0_99:                                ; %direct.false63
	add	x9, x2, x10
	add	x10, sp, #768
	add	x13, x10, x8
	ldr	q2, [x13]
	ldr	d0, [x4, lCPI0_12@PAGEOFF]
	shl.8b	v1, v7, #7
	cmlt.8b	v1, v1, #0
	and.8b	v0, v1, v0
	addv.8b	b0, v0
	str	d0, [sp, #8]                    ; 8-byte Spill
	fmov	w10, s0
	tbnz	w10, #0, LBB0_173
; %bb.100:                              ; %else214
	tbnz	w10, #1, LBB0_174
LBB0_101:                               ; %else217
	tbnz	w10, #2, LBB0_175
LBB0_102:                               ; %else220
	tbnz	w10, #3, LBB0_176
LBB0_103:                               ; %else223
	ldr	q0, [x13, #16]
	tbnz	w10, #4, LBB0_177
LBB0_104:                               ; %else226
	tbnz	w10, #5, LBB0_178
LBB0_105:                               ; %else229
	tbnz	w10, #6, LBB0_179
LBB0_106:                               ; %else232
	stp	q16, q7, [sp, #64]              ; 32-byte Folded Spill
	str	q18, [sp, #32]                  ; 16-byte Spill
	tbz	w10, #7, LBB0_108
LBB0_107:                               ; %cond.load234
	add	x9, x9, #28
	ld1.s	{ v0 }[3], [x9]
LBB0_108:                               ; %else235
	mov	x16, #0                         ; =0x0
	add	x9, sp, #768
	add	x8, x9, x8
	str	q0, [sp, #16]                   ; 16-byte Spill
	stp	q2, q0, [x8]
	str	q2, [sp, #48]                   ; 16-byte Spill
	add	x8, x3, x12
	movi.2d	v25, #0000000000000000
	fmov	w10, s20
	add	x12, sp, #1, lsl #12            ; =4096
	add	x12, x12, #2848
	mov	w13, #10003                     ; =0x2713
	movk	w13, #15671, lsl #16
	dup.4s	v1, w13
	mov	w13, #16938                     ; =0x422a
	movk	w13, #16204, lsl #16
	dup.4s	v15, w13
	fmov.4s	v28, #1.00000000
	mov	w13, #37425                     ; =0x9231
	movk	w13, #12080, lsl #16
	dup.4s	v0, w13
	stp	q0, q1, [sp, #336]              ; 32-byte Folded Spill
	mov	w13, #12843                     ; =0x322b
	movk	w13, #13015, lsl #16
	dup.4s	v1, w13
	mov	w13, #61213                     ; =0xef1d
	movk	w13, #13880, lsl #16
	dup.4s	v0, w13
	stp	q0, q1, [sp, #304]              ; 32-byte Folded Spill
	mov	w13, #3329                      ; =0xd01
	movk	w13, #14672, lsl #16
	dup.4s	v1, w13
	mov	w13, #34953                     ; =0x8889
	movk	w13, #15368, lsl #16
	dup.4s	v0, w13
	stp	q0, q1, [sp, #272]              ; 32-byte Folded Spill
	mov	w13, #43691                     ; =0xaaab
	movk	w13, #15914, lsl #16
	dup.4s	v10, w13
	mov	w13, #30407                     ; =0x76c7
	movk	w13, #12559, lsl #16
	dup.4s	v1, w13
	mov	w13, #62078                     ; =0xf27e
	movk	w13, #13459, lsl #16
	dup.4s	v0, w13
	stp	q0, q1, [sp, #240]              ; 32-byte Folded Spill
	mov	w13, #3329                      ; =0xd01
	movk	w13, #14288, lsl #16
	dup.4s	v1, w13
	mov	w13, #2913                      ; =0xb61
	movk	w13, #15030, lsl #16
	dup.4s	v0, w13
	stp	q0, q1, [sp, #208]              ; 32-byte Folded Spill
	mov	w13, #43691                     ; =0xaaab
	movk	w13, #15658, lsl #16
	dup.4s	v1, w13
	mov	w13, #-1026555904               ; =0xc2d00000
	dup.4s	v0, w13
	stp	q0, q1, [sp, #176]              ; 32-byte Folded Spill
	mov	w13, #1120403456                ; =0x42c80000
	dup.4s	v4, w13
	mov	w13, #43579                     ; =0xaa3b
	movk	w13, #16312, lsl #16
	dup.4s	v0, w13
	str	q0, [sp, #160]                  ; 16-byte Spill
	mov	w13, #29184                     ; =0x7200
	movk	w13, #48945, lsl #16
	dup.4s	v18, w13
	mov	w13, #48782                     ; =0xbe8e
	movk	w13, #46527, lsl #16
	dup.4s	v5, w13
	mov	w13, #11226                     ; =0x2bda
	movk	w13, #14672, lsl #16
	dup.4s	v19, w13
	mov	w13, #38601                     ; =0x96c9
	movk	w13, #15030, lsl #16
	mov	w14, #34982                     ; =0x88a6
	movk	w14, #15368, lsl #16
	mov	w15, #43642                     ; =0xaa7a
	movk	w15, #15658, lsl #16
	mvni.4s	v0, #127, msl #16
	fneg.4s	v0, v0
	mvni.4s	v1, #63, msl #16
	fneg.4s	v7, v1
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v24, #0000000000000000
	b	LBB0_110
LBB0_109:                               ; %else253
                                        ;   in Loop: Header=BB0_110 Depth=1
	add.2d	v21, v21, v23
	add.2d	v22, v22, v14
	add.2d	v24, v24, v12
	add.2d	v25, v25, v26
	fmov	x16, d25
	cmp	x16, #192
	b.ge	LBB0_126
LBB0_110:                               ; %direct.true83
                                        ; =>This Inner Loop Header: Depth=1
	mov.16b	v3, v26
	mov.16b	v20, v23
	lsl	x16, x16, #5
	add	x0, x12, x16
	ldr	q1, [x0]
	and.16b	v1, v27, v1
	ldp	q23, q2, [sp, #336]             ; 32-byte Folded Reload
	fmul.4s	v2, v1, v2
	fmul.4s	v2, v1, v2
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v1, v2
	mov.16b	v16, v15
	fmul.4s	v2, v2, v15
	and.16b	v2, v27, v2
	fabs.4s	v26, v2
	fmul.4s	v6, v2, v2
	ldr	q17, [sp, #320]                 ; 16-byte Reload
	fmla.4s	v17, v6, v23
	ldr	q23, [sp, #304]                 ; 16-byte Reload
	fmla.4s	v23, v6, v17
	ldr	q17, [sp, #288]                 ; 16-byte Reload
	fmla.4s	v17, v6, v23
	ldp	q29, q23, [sp, #256]            ; 32-byte Folded Reload
	fmla.4s	v23, v6, v17
	mov.16b	v17, v10
	fmla.4s	v17, v6, v23
	fmov.4s	v23, #1.00000000
	fmla.4s	v23, v6, v17
	fmul.4s	v17, v26, v23
	ldp	q13, q23, [sp, #224]            ; 32-byte Folded Reload
	fmla.4s	v23, v6, v29
	fmla.4s	v13, v6, v23
	ldr	q23, [sp, #208]                 ; 16-byte Reload
	fmla.4s	v23, v6, v13
	ldr	q13, [sp, #192]                 ; 16-byte Reload
	fmla.4s	v13, v6, v23
	movi.4s	v23, #63, lsl #24
	fmla.4s	v23, v6, v13
	fmov.4s	v13, #1.00000000
	fmla.4s	v13, v6, v23
	fdiv.4s	v13, v17, v13
	mov.16b	v15, v27
	fmov.4s	v6, #9.00000000
	fcmge.4s	v27, v6, v26
	and.16b	v29, v27, v26
	ldr	q6, [sp, #176]                  ; 16-byte Reload
	fcmge.4s	v6, v29, v6
	fcmge.4s	v17, v4, v29
	and.16b	v6, v6, v17
	and.16b	v6, v6, v29
	ldr	q17, [sp, #160]                 ; 16-byte Reload
	fmul.4s	v17, v6, v17
	movi.4s	v23, #75, lsl #24
	fadd.4s	v17, v17, v23
	movi.4s	v23, #203, lsl #24
	fadd.4s	v17, v17, v23
	fcvtzs.4s	v30, v17
	scvtf.4s	v17, v30
	fmul.4s	v23, v17, v18
	fadd.4s	v6, v6, v23
	fmul.4s	v17, v17, v5
	fadd.4s	v31, v6, v17
	fmul.4s	v6, v31, v19
	dup.4s	v23, w13
	fadd.4s	v6, v6, v23
	fmul.4s	v6, v31, v6
	dup.4s	v17, w14
	fadd.4s	v6, v6, v17
	fmul.4s	v8, v31, v6
	dup.4s	v6, w15
	fadd.4s	v8, v8, v6
	fmul.4s	v8, v31, v8
	fadd.4s	v8, v8, v10
	fmul.4s	v8, v31, v8
	movi.4s	v11, #63, lsl #24
	fadd.4s	v8, v8, v11
	fmul.4s	v9, v31, v31
	fmul.4s	v8, v9, v8
	fadd.4s	v31, v31, v8
	fadd.4s	v31, v31, v28
	movi.2d	v8, #0xffffffffffffffff
	add.4s	v30, v30, v8
	sshr.4s	v8, v30, #1
	shl.4s	v9, v8, #23
	add.4s	v9, v9, v28
	fmul.4s	v31, v31, v9
	sub.4s	v30, v30, v8
	shl.4s	v30, v30, #23
	add.4s	v30, v30, v28
	fmul.4s	v30, v31, v30
	fcmgt.4s	v29, v29, v4
	bsl.16b	v29, v0, v30
	fmov.4s	v30, #0.25000000
	fdiv.4s	v30, v30, v29
	fsub.4s	v31, v29, v30
	fadd.4s	v29, v29, v30
	fdiv.4s	v29, v31, v29
	bsl.16b	v27, v29, v28
	fcmge.4s	v26, v28, v26
	bsl.16b	v26, v13, v27
	mvni.4s	v27, #128, lsl #24
	bif.16b	v26, v2, v27
	fcmeq.4s	v2, v2, v2
	fadd.4s	v26, v26, v28
	bsl.16b	v2, v26, v7
	fmul.4s	v1, v1, v11
	fmul.4s	v1, v1, v2
	add	x1, x9, x16
	ldr	q2, [x1]
	and.16b	v2, v15, v2
	fadd.4s	v1, v2, v1
	add	x16, x8, x16
	tbnz	w10, #0, LBB0_119
; %bb.111:                              ; %else239
                                        ;   in Loop: Header=BB0_110 Depth=1
	and	w17, w10, #0xff
	tbnz	w17, #1, LBB0_120
LBB0_112:                               ; %else241
                                        ;   in Loop: Header=BB0_110 Depth=1
	mov.16b	v15, v16
	tbnz	w17, #2, LBB0_121
LBB0_113:                               ; %else243
                                        ;   in Loop: Header=BB0_110 Depth=1
	tbz	w17, #3, LBB0_115
LBB0_114:                               ; %cond.store244
                                        ;   in Loop: Header=BB0_110 Depth=1
	add	x2, x16, #12
	st1.s	{ v1 }[3], [x2]
LBB0_115:                               ; %else245
                                        ;   in Loop: Header=BB0_110 Depth=1
	ldr	q1, [x0, #16]
	ldr	q11, [sp, #384]                 ; 16-byte Reload
	and.16b	v1, v11, v1
	ldp	q16, q2, [sp, #336]             ; 32-byte Folded Reload
	fmul.4s	v2, v1, v2
	fmul.4s	v2, v1, v2
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v1, v2
	fmul.4s	v2, v2, v15
	and.16b	v2, v11, v2
	fabs.4s	v26, v2
	fmul.4s	v27, v2, v2
	ldp	q30, q29, [sp, #304]            ; 32-byte Folded Reload
	fmla.4s	v29, v27, v16
	fmla.4s	v30, v27, v29
	ldr	q29, [sp, #288]                 ; 16-byte Reload
	fmla.4s	v29, v27, v30
	ldp	q16, q30, [sp, #256]            ; 32-byte Folded Reload
	fmla.4s	v30, v27, v29
	mov.16b	v29, v10
	fmla.4s	v29, v27, v30
	fmov.4s	v30, #1.00000000
	fmla.4s	v30, v27, v29
	fmul.4s	v29, v26, v30
	ldp	q31, q30, [sp, #224]            ; 32-byte Folded Reload
	fmla.4s	v30, v27, v16
	fmla.4s	v31, v27, v30
	ldr	q30, [sp, #208]                 ; 16-byte Reload
	fmla.4s	v30, v27, v31
	ldr	q31, [sp, #192]                 ; 16-byte Reload
	fmla.4s	v31, v27, v30
	movi.4s	v30, #63, lsl #24
	fmla.4s	v30, v27, v31
	fmov.4s	v31, #1.00000000
	fmla.4s	v31, v27, v30
	fdiv.4s	v27, v29, v31
	fmov.4s	v16, #9.00000000
	fcmge.4s	v29, v16, v26
	and.16b	v30, v29, v26
	ldr	q16, [sp, #176]                 ; 16-byte Reload
	fcmge.4s	v31, v30, v16
	fcmge.4s	v8, v4, v30
	and.16b	v31, v31, v8
	and.16b	v31, v31, v30
	ldr	q16, [sp, #160]                 ; 16-byte Reload
	fmul.4s	v8, v31, v16
	movi.4s	v16, #75, lsl #24
	fadd.4s	v8, v8, v16
	movi.4s	v16, #203, lsl #24
	fadd.4s	v8, v8, v16
	fcvtzs.4s	v8, v8
	scvtf.4s	v9, v8
	fmul.4s	v13, v9, v18
	fadd.4s	v31, v31, v13
	fmul.4s	v9, v9, v5
	fadd.4s	v31, v31, v9
	fmul.4s	v9, v31, v19
	fadd.4s	v23, v9, v23
	fmul.4s	v23, v31, v23
	fadd.4s	v17, v23, v17
	fmul.4s	v17, v31, v17
	fadd.4s	v6, v17, v6
	fmul.4s	v6, v31, v6
	fadd.4s	v6, v6, v10
	fmul.4s	v6, v31, v6
	movi.4s	v9, #63, lsl #24
	fadd.4s	v6, v6, v9
	fmul.4s	v17, v31, v31
	fmul.4s	v6, v17, v6
	fadd.4s	v6, v31, v6
	fadd.4s	v6, v6, v28
	movi.2d	v16, #0xffffffffffffffff
	add.4s	v17, v8, v16
	sshr.4s	v23, v17, #1
	shl.4s	v31, v23, #23
	add.4s	v31, v31, v28
	fmul.4s	v6, v6, v31
	sub.4s	v17, v17, v23
	shl.4s	v17, v17, #23
	add.4s	v17, v17, v28
	fmul.4s	v6, v6, v17
	fcmgt.4s	v17, v30, v4
	bit.16b	v6, v0, v17
	fmov.4s	v16, #0.25000000
	fdiv.4s	v17, v16, v6
	fsub.4s	v23, v6, v17
	fadd.4s	v6, v6, v17
	fdiv.4s	v6, v23, v6
	bif.16b	v6, v28, v29
	fcmge.4s	v17, v28, v26
	bit.16b	v6, v27, v17
	mvni.4s	v16, #128, lsl #24
	bif.16b	v6, v2, v16
	fcmeq.4s	v2, v2, v2
	fadd.4s	v6, v6, v28
	bsl.16b	v2, v6, v7
	fmul.4s	v1, v1, v9
	fmul.4s	v1, v1, v2
	ldr	q2, [x1, #16]
	and.16b	v2, v11, v2
	fadd.4s	v1, v2, v1
	tbnz	w17, #4, LBB0_122
; %bb.116:                              ; %else247
                                        ;   in Loop: Header=BB0_110 Depth=1
	ldr	q27, [sp, #368]                 ; 16-byte Reload
	mov.16b	v23, v20
	mov.16b	v26, v3
	tbnz	w17, #5, LBB0_123
LBB0_117:                               ; %else249
                                        ;   in Loop: Header=BB0_110 Depth=1
	tbnz	w17, #6, LBB0_124
LBB0_118:                               ; %else251
                                        ;   in Loop: Header=BB0_110 Depth=1
	tbz	w17, #7, LBB0_109
	b	LBB0_125
LBB0_119:                               ; %cond.store238
                                        ;   in Loop: Header=BB0_110 Depth=1
	str	s1, [x16]
	and	w17, w10, #0xff
	tbz	w17, #1, LBB0_112
LBB0_120:                               ; %cond.store240
                                        ;   in Loop: Header=BB0_110 Depth=1
	add	x2, x16, #4
	st1.s	{ v1 }[1], [x2]
	mov.16b	v15, v16
	tbz	w17, #2, LBB0_113
LBB0_121:                               ; %cond.store242
                                        ;   in Loop: Header=BB0_110 Depth=1
	add	x2, x16, #8
	st1.s	{ v1 }[2], [x2]
	tbnz	w17, #3, LBB0_114
	b	LBB0_115
LBB0_122:                               ; %cond.store246
                                        ;   in Loop: Header=BB0_110 Depth=1
	str	s1, [x16, #16]
	ldr	q27, [sp, #368]                 ; 16-byte Reload
	mov.16b	v23, v20
	mov.16b	v26, v3
	tbz	w17, #5, LBB0_117
LBB0_123:                               ; %cond.store248
                                        ;   in Loop: Header=BB0_110 Depth=1
	add	x0, x16, #20
	st1.s	{ v1 }[1], [x0]
	tbz	w17, #6, LBB0_118
LBB0_124:                               ; %cond.store250
                                        ;   in Loop: Header=BB0_110 Depth=1
	add	x0, x16, #24
	st1.s	{ v1 }[2], [x0]
	tbz	w17, #7, LBB0_109
LBB0_125:                               ; %cond.store252
                                        ;   in Loop: Header=BB0_110 Depth=1
	add	x16, x16, #28
	st1.s	{ v1 }[3], [x16]
	b	LBB0_109
LBB0_126:                               ; %direct.false84
	ldr	d0, [sp, #8]                    ; 8-byte Reload
	fmov	w8, s0
	ldr	q1, [sp, #80]                   ; 16-byte Reload
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v2, v0, #0
	ldr	q0, [sp, #64]                   ; 16-byte Reload
	and.16b	v5, v2, v0
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	ldr	q1, [sp, #32]                   ; 16-byte Reload
	and.16b	v1, v0, v1
	mov	w9, #10003                      ; =0x2713
	movk	w9, #15671, lsl #16
	dup.4s	v3, w9
	fmul.4s	v4, v5, v3
	fmul.4s	v3, v1, v3
	fmul.4s	v3, v1, v3
	fmul.4s	v4, v5, v4
	fmul.4s	v4, v5, v4
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v1, v3
	fadd.4s	v4, v5, v4
	mov	w9, #16938                      ; =0x422a
	movk	w9, #16204, lsl #16
	dup.4s	v6, w9
	fmul.4s	v4, v4, v6
	fmul.4s	v3, v3, v6
	and.16b	v3, v0, v3
	and.16b	v4, v2, v4
	fabs.4s	v6, v4
	fabs.4s	v7, v3
	fmul.4s	v16, v3, v3
	fmul.4s	v17, v4, v4
	mov	w9, #37425                      ; =0x9231
	movk	w9, #12080, lsl #16
	dup.4s	v18, w9
	mov	w9, #12843                      ; =0x322b
	movk	w9, #13015, lsl #16
	dup.4s	v19, w9
	mov.16b	v20, v19
	fmla.4s	v20, v16, v18
	fmla.4s	v19, v17, v18
	mov	w9, #61213                      ; =0xef1d
	movk	w9, #13880, lsl #16
	dup.4s	v18, w9
	mov.16b	v21, v18
	fmla.4s	v21, v16, v20
	fmla.4s	v18, v17, v19
	mov	w9, #3329                       ; =0xd01
	movk	w9, #14672, lsl #16
	dup.4s	v19, w9
	mov.16b	v22, v19
	fmla.4s	v22, v16, v21
	fmla.4s	v19, v17, v18
	mov	w9, #34953                      ; =0x8889
	movk	w9, #15368, lsl #16
	dup.4s	v18, w9
	mov.16b	v20, v18
	fmla.4s	v20, v16, v22
	fmla.4s	v18, v17, v19
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #15914, lsl #16
	dup.4s	v23, w9
	mov.16b	v21, v23
	fmla.4s	v21, v17, v18
	fmov.4s	v19, #1.00000000
	fmla.4s	v19, v17, v21
	mov	w9, #30407                      ; =0x76c7
	movk	w9, #12559, lsl #16
	dup.4s	v25, w9
	mov	w9, #62078                      ; =0xf27e
	movk	w9, #13459, lsl #16
	dup.4s	v26, w9
	mov.16b	v18, v26
	fmla.4s	v18, v17, v25
	mov	w9, #3329                       ; =0xd01
	movk	w9, #14288, lsl #16
	dup.4s	v27, w9
	mov.16b	v21, v27
	mov	w9, #2913                       ; =0xb61
	movk	w9, #15030, lsl #16
	dup.4s	v28, w9
	fmla.4s	v21, v17, v18
	mov.16b	v18, v28
	fmla.4s	v18, v17, v21
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #15658, lsl #16
	dup.4s	v29, w9
	mov.16b	v21, v29
	fmla.4s	v21, v17, v18
	movi.4s	v18, #63, lsl #24
	fmla.4s	v18, v17, v21
	fmov.4s	v30, #1.00000000
	fmla.4s	v30, v17, v18
	fmov.4s	v18, #9.00000000
	fcmge.4s	v17, v18, v7
	fcmge.4s	v18, v18, v6
	and.16b	v21, v18, v6
	and.16b	v22, v17, v7
	mov	w9, #-1026555904                ; =0xc2d00000
	dup.4s	v31, w9
	fcmge.4s	v8, v22, v31
	mov	w9, #1120403456                 ; =0x42c80000
	dup.4s	v24, w9
	fcmge.4s	v31, v21, v31
	fcmge.4s	v9, v24, v22
	fcmge.4s	v10, v24, v21
	and.16b	v31, v31, v10
	and.16b	v8, v8, v9
	and.16b	v9, v8, v22
	and.16b	v8, v31, v21
	mov	w9, #43579                      ; =0xaa3b
	movk	w9, #16312, lsl #16
	dup.4s	v31, w9
	fmul.4s	v10, v8, v31
	fmul.4s	v31, v9, v31
	movi.4s	v11, #75, lsl #24
	fadd.4s	v31, v31, v11
	fadd.4s	v10, v10, v11
	movi.4s	v11, #203, lsl #24
	fadd.4s	v10, v10, v11
	fadd.4s	v11, v31, v11
	fcvtzs.4s	v31, v10
	mov	w9, #29184                      ; =0x7200
	movk	w9, #48945, lsl #16
	scvtf.4s	v10, v31
	dup.4s	v12, w9
	fmul.4s	v13, v10, v12
	fadd.4s	v13, v8, v13
	fcvtzs.4s	v8, v11
	scvtf.4s	v11, v8
	fmul.4s	v12, v11, v12
	fadd.4s	v9, v9, v12
	mov	w9, #48782                      ; =0xbe8e
	movk	w9, #46527, lsl #16
	dup.4s	v12, w9
	fmul.4s	v10, v10, v12
	fmul.4s	v11, v11, v12
	fadd.4s	v9, v9, v11
	fadd.4s	v10, v13, v10
	mov	w9, #11226                      ; =0x2bda
	movk	w9, #14672, lsl #16
	dup.4s	v11, w9
	fmul.4s	v12, v10, v11
	fmul.4s	v11, v9, v11
	mov	w9, #38601                      ; =0x96c9
	movk	w9, #15030, lsl #16
	dup.4s	v13, w9
	fadd.4s	v11, v11, v13
	fadd.4s	v12, v12, v13
	fmul.4s	v12, v10, v12
	fmul.4s	v11, v9, v11
	mov	w9, #34982                      ; =0x88a6
	movk	w9, #15368, lsl #16
	dup.4s	v13, w9
	fadd.4s	v11, v11, v13
	fadd.4s	v12, v12, v13
	fmul.4s	v12, v10, v12
	fmul.4s	v11, v9, v11
	mov	w9, #43642                      ; =0xaa7a
	movk	w9, #15658, lsl #16
	dup.4s	v13, w9
	fadd.4s	v11, v11, v13
	fadd.4s	v12, v12, v13
	fmul.4s	v12, v10, v12
	fmul.4s	v11, v9, v11
	fadd.4s	v11, v11, v23
	fadd.4s	v12, v12, v23
	fmla.4s	v23, v16, v20
	fmov.4s	v13, #1.00000000
	fmla.4s	v13, v16, v23
	fmla.4s	v26, v16, v25
	fmla.4s	v27, v16, v26
	fmla.4s	v28, v16, v27
	movi.4s	v20, #63, lsl #24
	fmul.4s	v23, v5, v20
	fmla.4s	v29, v16, v28
	movi.4s	v5, #63, lsl #24
	fmla.4s	v5, v16, v29
	fmov.4s	v25, #1.00000000
	fmla.4s	v25, v16, v5
	fmov.4s	v5, #1.00000000
	fcmge.4s	v16, v5, v7
	fmul.4s	v19, v6, v19
	fcmge.4s	v6, v5, v6
	fmul.4s	v7, v7, v13
	fdiv.4s	v7, v7, v25
	fdiv.4s	v19, v19, v30
	fmul.4s	v25, v10, v12
	fmul.4s	v26, v9, v11
	fadd.4s	v26, v26, v20
	fadd.4s	v25, v25, v20
	fmul.4s	v27, v9, v9
	fmul.4s	v28, v10, v10
	fmul.4s	v25, v28, v25
	fmul.4s	v26, v27, v26
	fadd.4s	v26, v9, v26
	fadd.4s	v25, v10, v25
	fadd.4s	v25, v25, v5
	fadd.4s	v26, v26, v5
	movi.2d	v27, #0xffffffffffffffff
	add.4s	v28, v8, v27
	add.4s	v27, v31, v27
	sshr.4s	v29, v27, #1
	sshr.4s	v30, v28, #1
	shl.4s	v31, v30, #23
	shl.4s	v8, v29, #23
	add.4s	v8, v8, v5
	add.4s	v31, v31, v5
	fmul.4s	v26, v26, v31
	fmul.4s	v25, v25, v8
	sub.4s	v28, v28, v30
	sub.4s	v27, v27, v29
	shl.4s	v27, v27, #23
	shl.4s	v28, v28, #23
	add.4s	v28, v28, v5
	add.4s	v27, v27, v5
	fmul.4s	v25, v25, v27
	fmul.4s	v26, v26, v28
	fcmgt.4s	v21, v21, v24
	fcmgt.4s	v22, v22, v24
	mvni.4s	v24, #127, msl #16
	fneg.4s	v24, v24
	bsl.16b	v22, v24, v26
	bsl.16b	v21, v24, v25
	fmov.4s	v24, #0.25000000
	fdiv.4s	v25, v24, v21
	fdiv.4s	v24, v24, v22
	fsub.4s	v26, v22, v24
	fsub.4s	v27, v21, v25
	fadd.4s	v22, v22, v24
	fadd.4s	v21, v21, v25
	fdiv.4s	v21, v27, v21
	fdiv.4s	v22, v26, v22
	bsl.16b	v17, v22, v5
	bsl.16b	v18, v21, v5
	bit.16b	v18, v19, v6
	mov.16b	v6, v16
	bsl.16b	v6, v7, v17
	mvni.4s	v7, #128, lsl #24
	bif.16b	v6, v3, v7
	bsl.16b	v7, v18, v4
	fcmeq.4s	v16, v4, v4
	fadd.4s	v7, v7, v5
	mvni.4s	v4, #63, msl #16
	fneg.4s	v4, v4
	bif.16b	v7, v4, v16
	fmul.4s	v7, v23, v7
	ldr	q16, [sp, #48]                  ; 16-byte Reload
	and.16b	v2, v2, v16
	fadd.4s	v2, v7, v2
	ldr	q7, [sp, #128]                  ; 16-byte Reload
	str	q7, [sp, #544]
	ldr	q7, [sp, #144]                  ; 16-byte Reload
	str	q7, [sp, #560]
	ldr	q7, [sp, #112]                  ; 16-byte Reload
	str	q7, [sp, #576]
	ldr	q7, [sp, #96]                   ; 16-byte Reload
	str	q7, [sp, #592]
	and	x9, x11, #0x7
	add	x10, sp, #544
	ldr	x9, [x10, x9, lsl #3]
	sub	x9, x9, x11
	add	x9, x3, x9, lsl #2
	tbnz	w8, #0, LBB0_180
; %bb.127:                              ; %else256
	fcmeq.4s	v3, v3, v3
	fadd.4s	v5, v6, v5
	tbnz	w8, #1, LBB0_181
LBB0_128:                               ; %else258
	fmul.4s	v1, v1, v20
	bsl.16b	v3, v5, v4
	tbnz	w8, #2, LBB0_182
LBB0_129:                               ; %else260
	fmul.4s	v1, v1, v3
	ldr	q3, [sp, #16]                   ; 16-byte Reload
	and.16b	v0, v0, v3
	tbnz	w8, #3, LBB0_183
LBB0_130:                               ; %else262
	fadd.4s	v0, v1, v0
	tbnz	w8, #4, LBB0_184
LBB0_131:                               ; %else264
	tbnz	w8, #5, LBB0_185
LBB0_132:                               ; %else266
	tbnz	w8, #6, LBB0_186
LBB0_133:                               ; %else268
	tbnz	w8, #7, LBB0_187
	b	LBB0_204
LBB0_134:                               ; %direct.false21
	ldr	q0, [sp, #240]                  ; 16-byte Reload
	xtn.8b	v0, v0
	movi	d1, #0x0000000000ffff
	and.8b	v20, v0, v1
Lloh20:
	adrp	x8, lCPI0_7@PAGE
Lloh21:
	ldr	d1, [x8, lCPI0_7@PAGEOFF]
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w10, s0
	umaxv.8b	b0, v20
	fmov	w8, s0
	rbit	w9, w10
	clz	w9, w9
	tst	w8, #0x1
	mov	w8, #1536                       ; =0x600
	dup.2d	v1, x8
	ldp	q0, q2, [sp, #112]              ; 32-byte Folded Reload
	mov.d	x12, v0[1]
	csel	w11, w9, wzr, ne
	mov	w8, #1538                       ; =0x602
	mul	x9, x12, x8
	fmov	x12, d0
	mul	x12, x12, x8
	fmov	d0, x12
	mov.d	v0[1], x9
	add.2d	v2, v2, v1
	mov	b3, v20[0]
	mov.b	v3[4], v20[1]
	add.2d	v2, v0, v2
	ushll.2d	v0, v3, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	str	q2, [sp, #384]                  ; 16-byte Spill
	and.16b	v0, v0, v2
	movi.2d	v17, #0000000000000000
	stp	q17, q17, [sp, #496]
	stp	q0, q17, [sp, #464]
	and	x9, x11, #0x7
	add	x12, sp, #464
	ldr	x9, [x12, x9, lsl #3]
	sub	x9, x9, x11
	lsl	x13, x9, #2
	ldr	x9, [sp, #64]                   ; 8-byte Reload
	add	x9, x9, x13
	movi.2d	v0, #0000000000000000
	tbnz	w10, #0, LBB0_188
; %bb.135:                              ; %else72
	ldr	x14, [sp, #96]                  ; 8-byte Reload
	ldr	x15, [sp, #80]                  ; 8-byte Reload
	adrp	x16, lCPI0_12@PAGE
	tbnz	w10, #1, LBB0_189
LBB0_136:                               ; %else75
	tbnz	w10, #2, LBB0_190
LBB0_137:                               ; %else78
	tbnz	w10, #3, LBB0_191
LBB0_138:                               ; %else81
	tbnz	w10, #4, LBB0_192
LBB0_139:                               ; %else84
	tbnz	w10, #5, LBB0_193
LBB0_140:                               ; %else87
	tbnz	w10, #6, LBB0_194
LBB0_141:                               ; %else90
	tbz	w10, #7, LBB0_143
LBB0_142:                               ; %cond.load92
	add	x9, x9, #28
	ld1.s	{ v0 }[3], [x9]
LBB0_143:                               ; %else93
	mov	w9, #10003                      ; =0x2713
	movk	w9, #15671, lsl #16
	dup.4s	v2, w9
	fmul.4s	v3, v0, v2
	fmul.4s	v2, v17, v2
	fmul.4s	v2, v17, v2
	fmul.4s	v3, v0, v3
	fmul.4s	v3, v0, v3
	fmul.4s	v2, v17, v2
	fadd.4s	v2, v17, v2
	fadd.4s	v3, v0, v3
	mov	w9, #16938                      ; =0x422a
	movk	w9, #16204, lsl #16
	dup.4s	v4, w9
	fmul.4s	v3, v3, v4
	fmul.4s	v2, v2, v4
	zip1.8b	v4, v20, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v23, v4, v2
	zip2.8b	v2, v20, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	and.16b	v19, v2, v3
	ldr	d2, [x16, lCPI0_12@PAGEOFF]
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v2, v3, v2
	addv.8b	b2, v2
	str	d2, [sp, #368]                  ; 8-byte Spill
	fmov	w10, s2
	fabs.4s	v22, v19
	fabs.4s	v27, v23
	fmov.4s	v20, #1.00000000
	fmul.4s	v8, v23, v23
	fmul.4s	v24, v19, v19
	mov	w9, #37425                      ; =0x9231
	movk	w9, #12080, lsl #16
	dup.4s	v2, w9
	mov	w9, #12843                      ; =0x322b
	movk	w9, #13015, lsl #16
	dup.4s	v3, w9
	mov.16b	v4, v3
	fmla.4s	v4, v8, v2
	fmla.4s	v3, v24, v2
	mov	w9, #61213                      ; =0xef1d
	movk	w9, #13880, lsl #16
	dup.4s	v11, w9
	mov.16b	v2, v11
	fmla.4s	v2, v8, v4
	fmla.4s	v11, v24, v3
	mov	w9, #3329                       ; =0xd01
	movk	w9, #14672, lsl #16
	dup.4s	v31, w9
	mov.16b	v3, v31
	fmla.4s	v3, v8, v2
	mov	w9, #34953                      ; =0x8889
	movk	w9, #15368, lsl #16
	dup.4s	v29, w9
	mov.16b	v2, v29
	fmla.4s	v2, v8, v3
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #15914, lsl #16
	dup.4s	v26, w9
	mov.16b	v3, v26
	fmla.4s	v3, v8, v2
	fmov.4s	v13, #1.00000000
	mov	w9, #30407                      ; =0x76c7
	movk	w9, #12559, lsl #16
	dup.4s	v2, w9
	mov	w9, #62078                      ; =0xf27e
	movk	w9, #13459, lsl #16
	dup.4s	v4, w9
	fmla.4s	v13, v8, v3
	mov.16b	v15, v4
	fmla.4s	v15, v24, v2
	mov	w9, #3329                       ; =0xd01
	movk	w9, #14288, lsl #16
	dup.4s	v12, w9
	fmla.4s	v4, v8, v2
	mov.16b	v2, v12
	fmla.4s	v2, v8, v4
	mov	w9, #2913                       ; =0xb61
	movk	w9, #15030, lsl #16
	dup.4s	v9, w9
	mov.16b	v3, v9
	fmla.4s	v3, v8, v2
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #15658, lsl #16
	dup.4s	v30, w9
	mov.16b	v2, v30
	fmla.4s	v2, v8, v3
	movi.4s	v5, #63, lsl #24
	fmla.4s	v5, v8, v2
	fmov.4s	v2, #9.00000000
	fcmge.4s	v14, v2, v27
	fcmge.4s	v25, v2, v22
	and.16b	v2, v25, v22
	and.16b	v4, v14, v27
	mov	w9, #-1026555904                ; =0xc2d00000
	dup.4s	v3, w9
	fcmge.4s	v6, v4, v3
	fcmge.4s	v7, v2, v3
	mov	w9, #1120403456                 ; =0x42c80000
	dup.4s	v3, w9
	fcmge.4s	v16, v3, v4
	fcmge.4s	v18, v3, v2
	and.16b	v7, v7, v18
	and.16b	v6, v6, v16
	and.16b	v6, v6, v4
	mov	w9, #43579                      ; =0xaa3b
	movk	w9, #16312, lsl #16
	dup.4s	v16, w9
	and.16b	v7, v7, v2
	fmul.4s	v18, v7, v16
	fmul.4s	v16, v6, v16
	movi.4s	v21, #75, lsl #24
	fadd.4s	v16, v16, v21
	fadd.4s	v18, v18, v21
	movi.4s	v21, #203, lsl #24
	fadd.4s	v18, v18, v21
	fadd.4s	v16, v16, v21
	fcvtzs.4s	v16, v16
	fcvtzs.4s	v18, v18
	scvtf.4s	v21, v18
	mov	w9, #29184                      ; =0x7200
	movk	w9, #48945, lsl #16
	dup.4s	v28, w9
	fmul.4s	v10, v21, v28
	fadd.4s	v7, v7, v10
	scvtf.4s	v10, v16
	fmul.4s	v28, v10, v28
	fadd.4s	v6, v6, v28
	mov	w9, #48782                      ; =0xbe8e
	movk	w9, #46527, lsl #16
	dup.4s	v28, w9
	fmul.4s	v21, v21, v28
	fmul.4s	v28, v10, v28
	fadd.4s	v6, v6, v28
	fadd.4s	v7, v7, v21
	mov	w9, #11226                      ; =0x2bda
	movk	w9, #14672, lsl #16
	dup.4s	v21, w9
	fmul.4s	v28, v7, v21
	fmul.4s	v21, v6, v21
	mov	w9, #38601                      ; =0x96c9
	movk	w9, #15030, lsl #16
	dup.4s	v10, w9
	fadd.4s	v21, v21, v10
	fadd.4s	v28, v28, v10
	fmul.4s	v28, v7, v28
	fmul.4s	v21, v6, v21
	mov	w9, #34982                      ; =0x88a6
	movk	w9, #15368, lsl #16
	dup.4s	v10, w9
	fadd.4s	v21, v21, v10
	fadd.4s	v28, v28, v10
	fmul.4s	v28, v7, v28
	mov	w9, #43642                      ; =0xaa7a
	movk	w9, #15658, lsl #16
	dup.4s	v10, w9
	fmul.4s	v21, v6, v21
	fadd.4s	v21, v21, v10
	fadd.4s	v28, v28, v10
	fmul.4s	v28, v7, v28
	fmul.4s	v21, v6, v21
	fadd.4s	v21, v21, v26
	fadd.4s	v28, v28, v26
	fmul.4s	v28, v7, v28
	fmul.4s	v21, v6, v21
	movi.4s	v10, #63, lsl #24
	fadd.4s	v21, v21, v10
	fadd.4s	v28, v28, v10
	fmul.4s	v10, v7, v7
	fmul.4s	v28, v10, v28
	fmul.4s	v10, v6, v6
	fmul.4s	v21, v10, v21
	fadd.4s	v6, v6, v21
	fadd.4s	v7, v7, v28
	fadd.4s	v7, v7, v20
	fadd.4s	v6, v6, v20
	movi.2d	v21, #0xffffffffffffffff
	add.4s	v16, v16, v21
	add.4s	v18, v18, v21
	sshr.4s	v21, v18, #1
	sshr.4s	v28, v16, #1
	shl.4s	v10, v28, #23
	add.4s	v10, v10, v20
	fmul.4s	v6, v6, v10
	shl.4s	v10, v21, #23
	add.4s	v10, v10, v20
	fmul.4s	v7, v7, v10
	sub.4s	v16, v16, v28
	sub.4s	v18, v18, v21
	shl.4s	v18, v18, #23
	shl.4s	v16, v16, #23
	add.4s	v21, v16, v20
	add.4s	v16, v18, v20
	fmul.4s	v18, v6, v21
	fcmgt.4s	v4, v4, v3
	mvni.4s	v6, #127, msl #16
	fneg.4s	v6, v6
	mov.16b	v21, v4
	bsl.16b	v21, v6, v18
	fmov.4s	v4, #0.25000000
	fdiv.4s	v28, v4, v21
	fsub.4s	v18, v21, v28
	fadd.4s	v21, v21, v28
	add	x9, x15, x13
	movi.2d	v10, #0000000000000000
	movi.2d	v28, #0000000000000000
	tbz	w10, #0, LBB0_145
; %bb.144:                              ; %cond.load96
	ldr	s10, [x9]
LBB0_145:                               ; %else97
	fmla.4s	v31, v24, v11
	fmla.4s	v12, v24, v15
	fmul.4s	v7, v7, v16
	fcmgt.4s	v3, v2, v3
	fmul.4s	v2, v27, v13
	fmov.4s	v16, #1.00000000
	fmla.4s	v16, v8, v5
	fdiv.4s	v18, v18, v21
	tbz	w10, #1, LBB0_147
; %bb.146:                              ; %cond.load99
	add	x12, x9, #4
	ld1.s	{ v10 }[1], [x12]
LBB0_147:                               ; %else100
	fmla.4s	v29, v24, v31
	fmla.4s	v9, v24, v12
	bsl.16b	v3, v6, v7
	fcmge.4s	v5, v20, v27
	fdiv.4s	v2, v2, v16
	mov.16b	v7, v14
	bsl.16b	v7, v18, v20
	tbz	w10, #2, LBB0_149
; %bb.148:                              ; %cond.load102
	add	x12, x9, #8
	ld1.s	{ v10 }[2], [x12]
LBB0_149:                               ; %else103
	fmla.4s	v26, v24, v29
	fmla.4s	v30, v24, v9
	fdiv.4s	v6, v4, v3
	bit.16b	v7, v2, v5
	mvni.4s	v2, #128, lsl #24
	tbz	w10, #3, LBB0_151
; %bb.150:                              ; %cond.load105
	add	x12, x9, #12
	ld1.s	{ v10 }[3], [x12]
LBB0_151:                               ; %else106
	fmov.4s	v4, #1.00000000
	fmla.4s	v4, v24, v26
	movi.4s	v5, #63, lsl #24
	fmla.4s	v5, v24, v30
	fsub.4s	v21, v3, v6
	fadd.4s	v6, v3, v6
	mov.16b	v3, v2
	bsl.16b	v3, v7, v23
	mvni.4s	v7, #63, msl #16
	tbz	w10, #4, LBB0_153
; %bb.152:                              ; %cond.load108
	add	x12, x9, #16
	ld1.s	{ v28 }[0], [x12]
LBB0_153:                               ; %else109
	fmul.4s	v16, v22, v4
	fmov.4s	v18, #1.00000000
	fmla.4s	v18, v24, v5
	fdiv.4s	v21, v21, v6
	dup.2s	v5, w8
	fcmeq.4s	v4, v23, v23
	fadd.4s	v6, v3, v20
	fneg.4s	v3, v7
	tbz	w10, #5, LBB0_155
; %bb.154:                              ; %cond.load111
	add	x8, x9, #20
	ld1.s	{ v28 }[1], [x8]
LBB0_155:                               ; %else112
	fcmge.4s	v7, v20, v22
	fdiv.4s	v16, v16, v18
	mov.16b	v18, v25
	bsl.16b	v18, v21, v20
	ldr	q21, [sp, #208]                 ; 16-byte Reload
	ldr	d22, [sp, #144]                 ; 8-byte Reload
	umlal.2d	v21, v22, v5
	str	q21, [sp, #208]                 ; 16-byte Spill
	ldr	q21, [sp, #192]                 ; 16-byte Reload
	ldr	d22, [sp, #160]                 ; 8-byte Reload
	umlal.2d	v21, v22, v5
	str	q21, [sp, #192]                 ; 16-byte Spill
	ldr	q21, [sp, #224]                 ; 16-byte Reload
	ldr	d22, [sp, #176]                 ; 8-byte Reload
	umlal.2d	v21, v22, v5
	str	q21, [sp, #224]                 ; 16-byte Spill
	movi.4s	v22, #63, lsl #24
	fmul.4s	v17, v17, v22
	mov.16b	v21, v4
	bsl.16b	v21, v6, v3
	tbz	w10, #6, LBB0_157
; %bb.156:                              ; %cond.load114
	add	x8, x9, #24
	ld1.s	{ v28 }[2], [x8]
LBB0_157:                               ; %else115
	bsl.16b	v7, v16, v18
	ldp	q5, q4, [sp, #192]              ; 32-byte Folded Reload
	add.2d	v4, v4, v1
	add.2d	v5, v5, v1
	ldr	q6, [sp, #224]                  ; 16-byte Reload
	add.2d	v6, v6, v1
	fmul.4s	v1, v17, v21
	tbz	w10, #7, LBB0_159
; %bb.158:                              ; %cond.load117
	add	x8, x9, #28
	ld1.s	{ v28 }[3], [x8]
LBB0_159:                               ; %else118
	bsl.16b	v2, v7, v19
	fadd.4s	v1, v10, v1
	ldr	q7, [sp, #384]                  ; 16-byte Reload
	stp	q7, q4, [sp, #400]
	stp	q5, q6, [sp, #432]
	and	x8, x11, #0x7
	add	x9, sp, #400
	ldr	x8, [x9, x8, lsl #3]
	sub	x8, x8, x11
	add	x8, x14, x8, lsl #2
	ldr	d4, [sp, #368]                  ; 8-byte Reload
	fmov	w9, s4
	tbnz	w9, #0, LBB0_195
; %bb.160:                              ; %else122
	fcmeq.4s	v4, v19, v19
	fadd.4s	v2, v2, v20
	tbnz	w9, #1, LBB0_196
LBB0_161:                               ; %else124
	fmul.4s	v0, v0, v22
	bif.16b	v2, v3, v4
	tbnz	w9, #2, LBB0_197
LBB0_162:                               ; %else126
	fmul.4s	v0, v0, v2
	tbnz	w9, #3, LBB0_198
LBB0_163:                               ; %else128
	fadd.4s	v0, v28, v0
	tbnz	w9, #4, LBB0_199
LBB0_164:                               ; %else130
	tbnz	w9, #5, LBB0_200
LBB0_165:                               ; %else132
	tbnz	w9, #6, LBB0_201
LBB0_166:                               ; %else134
	tbnz	w9, #7, LBB0_202
	b	LBB0_204
LBB0_167:                               ; %cond.load163
	ld1.s	{ v16 }[0], [x12]
	ldp	q4, q3, [sp, #192]              ; 32-byte Folded Reload
	tbz	w13, #1, LBB0_73
LBB0_168:                               ; %cond.load166
	add	x15, x12, #4
	ld1.s	{ v16 }[1], [x15]
	tbz	w13, #2, LBB0_74
LBB0_169:                               ; %cond.load169
	add	x15, x12, #8
	ld1.s	{ v16 }[2], [x15]
	tbz	w13, #3, LBB0_75
LBB0_170:                               ; %cond.load172
	add	x15, x12, #12
	ld1.s	{ v16 }[3], [x15]
	ldr	q18, [x14, #16]
	tbz	w13, #4, LBB0_76
LBB0_171:                               ; %cond.load175
	add	x14, x12, #16
	ld1.s	{ v18 }[0], [x14]
	tbz	w13, #5, LBB0_77
LBB0_172:                               ; %cond.load178
	add	x14, x12, #20
	ld1.s	{ v18 }[1], [x14]
	dup.2s	v0, w9
	tbnz	w13, #6, LBB0_78
	b	LBB0_79
LBB0_173:                               ; %cond.load213
	ld1.s	{ v2 }[0], [x9]
	tbz	w10, #1, LBB0_101
LBB0_174:                               ; %cond.load216
	add	x14, x9, #4
	ld1.s	{ v2 }[1], [x14]
	tbz	w10, #2, LBB0_102
LBB0_175:                               ; %cond.load219
	add	x14, x9, #8
	ld1.s	{ v2 }[2], [x14]
	tbz	w10, #3, LBB0_103
LBB0_176:                               ; %cond.load222
	add	x14, x9, #12
	ld1.s	{ v2 }[3], [x14]
	ldr	q0, [x13, #16]
	tbz	w10, #4, LBB0_104
LBB0_177:                               ; %cond.load225
	add	x13, x9, #16
	ld1.s	{ v0 }[0], [x13]
	tbz	w10, #5, LBB0_105
LBB0_178:                               ; %cond.load228
	add	x13, x9, #20
	ld1.s	{ v0 }[1], [x13]
	tbz	w10, #6, LBB0_106
LBB0_179:                               ; %cond.load231
	add	x13, x9, #24
	ld1.s	{ v0 }[2], [x13]
	stp	q16, q7, [sp, #64]              ; 32-byte Folded Spill
	str	q18, [sp, #32]                  ; 16-byte Spill
	tbnz	w10, #7, LBB0_107
	b	LBB0_108
LBB0_180:                               ; %cond.store255
	str	s2, [x9]
	fcmeq.4s	v3, v3, v3
	fadd.4s	v5, v6, v5
	tbz	w8, #1, LBB0_128
LBB0_181:                               ; %cond.store257
	add	x10, x9, #4
	st1.s	{ v2 }[1], [x10]
	fmul.4s	v1, v1, v20
	bsl.16b	v3, v5, v4
	tbz	w8, #2, LBB0_129
LBB0_182:                               ; %cond.store259
	add	x10, x9, #8
	st1.s	{ v2 }[2], [x10]
	fmul.4s	v1, v1, v3
	ldr	q3, [sp, #16]                   ; 16-byte Reload
	and.16b	v0, v0, v3
	tbz	w8, #3, LBB0_130
LBB0_183:                               ; %cond.store261
	add	x10, x9, #12
	st1.s	{ v2 }[3], [x10]
	fadd.4s	v0, v1, v0
	tbz	w8, #4, LBB0_131
LBB0_184:                               ; %cond.store263
	str	s0, [x9, #16]
	tbz	w8, #5, LBB0_132
LBB0_185:                               ; %cond.store265
	add	x10, x9, #20
	st1.s	{ v0 }[1], [x10]
	tbz	w8, #6, LBB0_133
LBB0_186:                               ; %cond.store267
	add	x10, x9, #24
	st1.s	{ v0 }[2], [x10]
	tbz	w8, #7, LBB0_204
LBB0_187:                               ; %cond.store269
	add	x8, x9, #28
	b	LBB0_203
LBB0_188:                               ; %cond.load71
	ldr	s17, [x9]
	ldr	x14, [sp, #96]                  ; 8-byte Reload
	ldr	x15, [sp, #80]                  ; 8-byte Reload
	adrp	x16, lCPI0_12@PAGE
	tbz	w10, #1, LBB0_136
LBB0_189:                               ; %cond.load74
	add	x12, x9, #4
	ld1.s	{ v17 }[1], [x12]
	tbz	w10, #2, LBB0_137
LBB0_190:                               ; %cond.load77
	add	x12, x9, #8
	ld1.s	{ v17 }[2], [x12]
	tbz	w10, #3, LBB0_138
LBB0_191:                               ; %cond.load80
	add	x12, x9, #12
	ld1.s	{ v17 }[3], [x12]
	tbz	w10, #4, LBB0_139
LBB0_192:                               ; %cond.load83
	add	x12, x9, #16
	ld1.s	{ v0 }[0], [x12]
	tbz	w10, #5, LBB0_140
LBB0_193:                               ; %cond.load86
	add	x12, x9, #20
	ld1.s	{ v0 }[1], [x12]
	tbz	w10, #6, LBB0_141
LBB0_194:                               ; %cond.load89
	add	x12, x9, #24
	ld1.s	{ v0 }[2], [x12]
	tbnz	w10, #7, LBB0_142
	b	LBB0_143
LBB0_195:                               ; %cond.store121
	str	s1, [x8]
	fcmeq.4s	v4, v19, v19
	fadd.4s	v2, v2, v20
	tbz	w9, #1, LBB0_161
LBB0_196:                               ; %cond.store123
	add	x10, x8, #4
	st1.s	{ v1 }[1], [x10]
	fmul.4s	v0, v0, v22
	bif.16b	v2, v3, v4
	tbz	w9, #2, LBB0_162
LBB0_197:                               ; %cond.store125
	add	x10, x8, #8
	st1.s	{ v1 }[2], [x10]
	fmul.4s	v0, v0, v2
	tbz	w9, #3, LBB0_163
LBB0_198:                               ; %cond.store127
	add	x10, x8, #12
	st1.s	{ v1 }[3], [x10]
	fadd.4s	v0, v28, v0
	tbz	w9, #4, LBB0_164
LBB0_199:                               ; %cond.store129
	str	s0, [x8, #16]
	tbz	w9, #5, LBB0_165
LBB0_200:                               ; %cond.store131
	add	x10, x8, #20
	st1.s	{ v0 }[1], [x10]
	tbz	w9, #6, LBB0_166
LBB0_201:                               ; %cond.store133
	add	x10, x8, #24
	st1.s	{ v0 }[2], [x10]
	tbz	w9, #7, LBB0_204
LBB0_202:                               ; %cond.store135
	add	x8, x8, #28
LBB0_203:                               ; %common.ret
	st1.s	{ v0 }[3], [x8]
LBB0_204:                               ; %common.ret
	add	sp, sp, #3, lsl #12             ; =12288
	add	sp, sp, #832
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpLdr	Lloh20, Lloh21
                                        ; -- End function
	.p2align	2                               ; -- Begin function llm_rows.full_packet
_llm_rows.full_packet:                  ; @llm_rows.full_packet
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-144]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x26, x25, [sp, #64]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	sub	sp, sp, #3, lsl #12             ; =12288
	sub	sp, sp, #352
	ldr	x22, [x0]
	ldr	x21, [x0, #16]
	ldr	x19, [x0, #48]
	ldr	w8, [x1]
	ldr	w9, [x1, #36]
	add	w8, w9, w8, lsl #5
	lsr	w8, w8, #3
	dup.2s	v0, w8
	ushll.2d	v0, v0, #0
	subs	x8, x22, x19
	cset	w9, hs
	mov	w10, #8199                      ; =0x2007
	movk	w10, #24, lsl #16
	cmp	x8, x10
	csel	w8, wzr, w9, ls
	subs	x9, x19, x22
	cset	w11, hs
	cmp	x9, x10
	csel	w9, wzr, w11, ls
	orr	w9, w8, w9
	subs	x8, x21, x19
	cset	w11, hs
	cmp	x8, x10
	csel	w8, wzr, w11, ls
	subs	x11, x19, x21
	cset	w12, hs
	cmp	x11, x10
	csel	w10, wzr, w12, ls
	orr	w10, w8, w10
	fmov	x8, d0
	mov	w11, #6152                      ; =0x1808
	umull	x8, w8, w11
	cmp	w9, #1
	ccmp	w10, #0, #4, eq
	b.ne	LBB1_4
; %bb.1:                                ; %direct.schedule.8.preheader
	mov	w20, #6144                      ; =0x1800
	add	x23, sp, #1, lsl #12            ; =4096
	add	x23, x23, #2368
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2368
	add	x1, x22, x8
	mov	w2, #6144                       ; =0x1800
	str	q0, [sp, #272]                  ; 16-byte Spill
	bl	_memcpy
	ldr	q0, [sp, #272]                  ; 16-byte Reload
	fmov	x24, d0
	mov	w25, #6152                      ; =0x1808
	umaddl	x20, w24, w25, x20
	add	x8, x22, x20
	add	x9, x8, #4
	ldr	s0, [x8]
	ld1.s	{ v0 }[1], [x9]
	str	q0, [sp]                        ; 16-byte Spill
	str	q0, [sp, #12608]
	umaddl	x1, w24, w25, x21
	add	x22, sp, #288
	add	x0, sp, #288
	mov	w2, #6144                       ; =0x1800
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	add	x9, x21, x20
	ldr	s0, [x9], #4
	ld1.s	{ v0 }[1], [x9]
	str	q0, [sp, #16]                   ; 16-byte Spill
	str	q0, [sp, #6432]
	umaddl	x9, w24, w25, x19
	mov	w10, #10003                     ; =0x2713
	movk	w10, #15671, lsl #16
	dup.4s	v1, w10
	mov	w10, #16938                     ; =0x422a
	movk	w10, #16204, lsl #16
	dup.4s	v0, w10
	stp	q0, q1, [sp, #256]              ; 32-byte Folded Spill
	fmov.4s	v4, #1.00000000
	mov	w10, #37425                     ; =0x9231
	movk	w10, #12080, lsl #16
	dup.4s	v1, w10
	mov	w10, #12843                     ; =0x322b
	movk	w10, #13015, lsl #16
	dup.4s	v0, w10
	stp	q0, q1, [sp, #224]              ; 32-byte Folded Spill
	mov	w10, #61213                     ; =0xef1d
	movk	w10, #13880, lsl #16
	dup.4s	v1, w10
	mov	w10, #3329                      ; =0xd01
	movk	w10, #14672, lsl #16
	dup.4s	v0, w10
	stp	q0, q1, [sp, #192]              ; 32-byte Folded Spill
	mov	w10, #34953                     ; =0x8889
	movk	w10, #15368, lsl #16
	dup.4s	v1, w10
	mov	w10, #43691                     ; =0xaaab
	movk	w10, #15914, lsl #16
	dup.4s	v20, w10
	mov	w10, #30407                     ; =0x76c7
	movk	w10, #12559, lsl #16
	dup.4s	v0, w10
	stp	q0, q1, [sp, #160]              ; 32-byte Folded Spill
	mov	w10, #62078                     ; =0xf27e
	movk	w10, #13459, lsl #16
	dup.4s	v1, w10
	mov	w10, #3329                      ; =0xd01
	movk	w10, #14288, lsl #16
	dup.4s	v0, w10
	stp	q0, q1, [sp, #128]              ; 32-byte Folded Spill
	mov	w10, #2913                      ; =0xb61
	movk	w10, #15030, lsl #16
	dup.4s	v1, w10
	mov	w10, #43691                     ; =0xaaab
	movk	w10, #15658, lsl #16
	dup.4s	v0, w10
	stp	q0, q1, [sp, #96]               ; 32-byte Folded Spill
	mov	w10, #-1026555904               ; =0xc2d00000
	dup.4s	v1, w10
	mov	w10, #1120403456                ; =0x42c80000
	dup.4s	v26, w10
	mov	w10, #43579                     ; =0xaa3b
	movk	w10, #16312, lsl #16
	dup.4s	v0, w10
	stp	q0, q1, [sp, #64]               ; 32-byte Folded Spill
	mov	w10, #29184                     ; =0x7200
	movk	w10, #48945, lsl #16
	dup.4s	v1, w10
	mov	w10, #48782                     ; =0xbe8e
	movk	w10, #46527, lsl #16
	dup.4s	v0, w10
	stp	q0, q1, [sp, #32]               ; 32-byte Folded Spill
	mov	w10, #11226                     ; =0x2bda
	movk	w10, #14672, lsl #16
	dup.4s	v8, w10
	mov	w10, #38601                     ; =0x96c9
	movk	w10, #15030, lsl #16
	dup.4s	v9, w10
	mov	w10, #34982                     ; =0x88a6
	movk	w10, #15368, lsl #16
	dup.4s	v10, w10
	mov	w10, #43642                     ; =0xaa7a
	movk	w10, #15658, lsl #16
	dup.4s	v11, w10
	mvni.4s	v0, #127, msl #16
	fneg.4s	v13, v0
	mvni.4s	v0, #63, msl #16
	fneg.4s	v15, v0
LBB1_2:                                 ; %direct.true83
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x10, x8, #5
	add	x11, x23, x10
	ldp	q24, q28, [x11]
	ldp	q2, q1, [sp, #256]              ; 32-byte Folded Reload
	fmul.4s	v0, v24, v1
	fmul.4s	v1, v28, v1
	fmul.4s	v1, v28, v1
	fmul.4s	v0, v24, v0
	fmul.4s	v0, v24, v0
	fmul.4s	v1, v28, v1
	fadd.4s	v1, v28, v1
	fadd.4s	v0, v24, v0
	fmul.4s	v12, v0, v2
	fmul.4s	v29, v1, v2
	fabs.4s	v0, v29
	fabs.4s	v14, v12
	fmul.4s	v7, v12, v12
	fmul.4s	v17, v29, v29
	ldp	q2, q3, [sp, #224]              ; 32-byte Folded Reload
	mov.16b	v1, v2
	fmla.4s	v1, v7, v3
	fmla.4s	v2, v17, v3
	ldr	q5, [sp, #208]                  ; 16-byte Reload
	mov.16b	v3, v5
	fmla.4s	v3, v7, v1
	mov.16b	v1, v5
	fmla.4s	v1, v17, v2
	ldp	q6, q5, [sp, #176]              ; 32-byte Folded Reload
	mov.16b	v2, v5
	fmla.4s	v2, v7, v3
	mov.16b	v3, v5
	fmla.4s	v3, v17, v1
	mov.16b	v5, v6
	mov.16b	v18, v20
	mov.16b	v19, v20
	fmov.4s	v1, #1.00000000
	fmla.4s	v5, v7, v2
	ldp	q16, q21, [sp, #144]            ; 32-byte Folded Reload
	mov.16b	v2, v16
	fmla.4s	v2, v17, v21
	fmla.4s	v16, v7, v21
	ldr	q22, [sp, #128]                 ; 16-byte Reload
	mov.16b	v21, v22
	fmla.4s	v6, v17, v3
	fmla.4s	v21, v17, v2
	mov.16b	v2, v22
	fmla.4s	v2, v7, v16
	ldr	q16, [sp, #112]                 ; 16-byte Reload
	mov.16b	v3, v16
	fmla.4s	v3, v17, v21
	fmla.4s	v18, v7, v5
	mov.16b	v5, v16
	fmla.4s	v5, v7, v2
	ldp	q27, q21, [sp, #80]             ; 32-byte Folded Reload
	mov.16b	v2, v21
	fmla.4s	v2, v17, v3
	fmla.4s	v19, v17, v6
	fmla.4s	v21, v7, v5
	movi.4s	v22, #63, lsl #24
	movi.4s	v23, #63, lsl #24
	fmov.4s	v5, #1.00000000
	fmov.4s	v6, #9.00000000
	fcmge.4s	v3, v6, v14
	fmla.4s	v22, v17, v2
	fcmge.4s	v2, v6, v0
	and.16b	v6, v2, v0
	and.16b	v16, v3, v14
	fcmge.4s	v25, v16, v27
	fcmge.4s	v27, v6, v27
	fcmge.4s	v30, v26, v6
	and.16b	v27, v27, v30
	fcmge.4s	v30, v26, v16
	and.16b	v25, v25, v30
	and.16b	v25, v25, v16
	and.16b	v27, v27, v6
	fmla.4s	v1, v17, v19
	ldr	q30, [sp, #64]                  ; 16-byte Reload
	fmul.4s	v19, v27, v30
	fmul.4s	v30, v25, v30
	movi.4s	v31, #75, lsl #24
	fadd.4s	v30, v30, v31
	fadd.4s	v19, v19, v31
	movi.4s	v31, #203, lsl #24
	fadd.4s	v19, v19, v31
	fmla.4s	v5, v17, v22
	fadd.4s	v17, v30, v31
	fcvtzs.4s	v17, v17
	fcvtzs.4s	v19, v19
	scvtf.4s	v22, v19
	scvtf.4s	v30, v17
	fmla.4s	v23, v7, v21
	ldr	q31, [sp, #48]                  ; 16-byte Reload
	fmul.4s	v21, v22, v31
	fadd.4s	v21, v27, v21
	fmul.4s	v27, v30, v31
	fadd.4s	v25, v25, v27
	fmov.4s	v27, #1.00000000
	fmla.4s	v27, v7, v18
	ldr	q31, [sp, #32]                  ; 16-byte Reload
	fmul.4s	v18, v30, v31
	fadd.4s	v18, v25, v18
	fmul.4s	v22, v22, v31
	fadd.4s	v21, v21, v22
	fmov.4s	v22, #1.00000000
	fmla.4s	v22, v7, v23
	fmul.4s	v7, v21, v8
	fmul.4s	v23, v18, v8
	fadd.4s	v23, v23, v9
	fadd.4s	v7, v7, v9
	fmul.4s	v7, v21, v7
	fmul.4s	v25, v14, v27
	fmul.4s	v23, v18, v23
	fadd.4s	v23, v23, v10
	fadd.4s	v7, v7, v10
	fmul.4s	v7, v21, v7
	fmul.4s	v23, v18, v23
	fadd.4s	v23, v23, v11
	fadd.4s	v7, v7, v11
	fmul.4s	v7, v21, v7
	fmul.4s	v23, v18, v23
	fadd.4s	v23, v23, v20
	fadd.4s	v27, v7, v20
	fdiv.4s	v7, v25, v22
	fmul.4s	v22, v21, v27
	fmul.4s	v23, v18, v23
	movi.4s	v27, #63, lsl #24
	fadd.4s	v23, v23, v27
	fadd.4s	v22, v22, v27
	fmul.4s	v25, v21, v21
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v18, v18
	fmul.4s	v23, v25, v23
	fadd.4s	v18, v18, v23
	fadd.4s	v21, v21, v22
	movi.2d	v25, #0xffffffffffffffff
	add.4s	v17, v17, v25
	fadd.4s	v18, v18, v4
	sshr.4s	v22, v17, #1
	shl.4s	v23, v22, #23
	add.4s	v23, v23, v4
	fmul.4s	v18, v18, v23
	add.4s	v19, v19, v25
	fadd.4s	v21, v21, v4
	sub.4s	v17, v17, v22
	sshr.4s	v22, v19, #1
	sub.4s	v19, v19, v22
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v4
	fmul.4s	v21, v21, v22
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v4
	fmul.4s	v19, v21, v19
	shl.4s	v17, v17, #23
	add.4s	v17, v17, v4
	fmul.4s	v17, v18, v17
	fcmgt.4s	v16, v16, v26
	bsl.16b	v16, v13, v17
	fmul.4s	v1, v0, v1
	fcmgt.4s	v6, v6, v26
	bsl.16b	v6, v13, v19
	fdiv.4s	v1, v1, v5
	fmov.4s	v18, #0.25000000
	fdiv.4s	v5, v18, v6
	fsub.4s	v17, v6, v5
	fadd.4s	v5, v6, v5
	fdiv.4s	v5, v17, v5
	bsl.16b	v2, v5, v4
	fcmge.4s	v0, v4, v0
	bsl.16b	v0, v1, v2
	fdiv.4s	v1, v18, v16
	fsub.4s	v2, v16, v1
	fadd.4s	v1, v16, v1
	fdiv.4s	v1, v2, v1
	bif.16b	v1, v4, v3
	fcmge.4s	v2, v4, v14
	bit.16b	v1, v7, v2
	mvni.4s	v3, #128, lsl #24
	bif.16b	v1, v12, v3
	fcmeq.4s	v2, v12, v12
	fadd.4s	v1, v1, v4
	bif.16b	v1, v15, v2
	bif.16b	v0, v29, v3
	fcmeq.4s	v2, v29, v29
	fadd.4s	v0, v0, v4
	bif.16b	v0, v15, v2
	fmul.4s	v2, v28, v27
	fmul.4s	v0, v2, v0
	fmul.4s	v2, v24, v27
	fmul.4s	v1, v2, v1
	add	x11, x22, x10
	ldp	q3, q2, [x11]
	fadd.4s	v1, v3, v1
	fadd.4s	v0, v2, v0
	add	x10, x9, x10
	stp	q1, q0, [x10]
	add	x8, x8, #1
	cmp	x8, #192
	b.ne	LBB1_2
; %bb.3:                                ; %direct.false84
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], v0[0]
	mov.s	v0[1], v0[0]
	mov.16b	v2, v0
	ldr	q4, [sp]                        ; 16-byte Reload
	mov.d	v2[0], v4[0]
	mov	w8, #10003                      ; =0x2713
	movk	w8, #15671, lsl #16
	fmov	s1, w8
	dup.4s	v3, v1[0]
	mov.s	v3[2], v0[0]
	mov.s	v3[3], v0[0]
	movi.4s	v1, #63, lsl #24
	fmul.4s	v3, v2, v3
	fmul.4s	v3, v4, v3
	fmul.4s	v3, v4, v3
	fadd.4s	v3, v4, v3
	mov	w8, #16938                      ; =0x422a
	movk	w8, #16204, lsl #16
	dup.4s	v4, w8
	fmul.4s	v3, v3, v4
	mov.d	v0[0], v3[0]
	fabs.4s	v3, v0
	mov	w8, #37425                      ; =0x9231
	movk	w8, #12080, lsl #16
	dup.4s	v5, w8
	mov	w8, #12843                      ; =0x322b
	movk	w8, #13015, lsl #16
	dup.4s	v6, w8
	fmul.4s	v4, v0, v0
	fmla.4s	v6, v4, v5
	mov	w8, #61213                      ; =0xef1d
	movk	w8, #13880, lsl #16
	dup.4s	v5, w8
	fmla.4s	v5, v4, v6
	mov	w8, #3329                       ; =0xd01
	movk	w8, #14672, lsl #16
	dup.4s	v6, w8
	mov	w8, #34953                      ; =0x8889
	movk	w8, #15368, lsl #16
	dup.4s	v16, w8
	fmla.4s	v6, v4, v5
	fmla.4s	v16, v4, v6
	mov	w8, #43691                      ; =0xaaab
	movk	w8, #15914, lsl #16
	dup.4s	v17, w8
	fmov.4s	v5, #9.00000000
	fcmge.4s	v5, v5, v3
	and.16b	v6, v5, v3
	mov	w8, #-1026555904                ; =0xc2d00000
	dup.4s	v7, w8
	fcmge.4s	v18, v6, v7
	mov	w8, #1120403456                 ; =0x42c80000
	dup.4s	v7, w8
	fcmge.4s	v19, v7, v6
	and.16b	v18, v18, v19
	and.16b	v18, v18, v6
	mov	w8, #43579                      ; =0xaa3b
	movk	w8, #16312, lsl #16
	dup.4s	v19, w8
	fmul.4s	v19, v18, v19
	movi.4s	v20, #75, lsl #24
	fadd.4s	v19, v19, v20
	movi.4s	v20, #203, lsl #24
	fadd.4s	v19, v19, v20
	fcvtzs.4s	v19, v19
	mov	w8, #29184                      ; =0x7200
	movk	w8, #48945, lsl #16
	dup.4s	v20, w8
	scvtf.4s	v21, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	mov	w8, #48782                      ; =0xbe8e
	movk	w8, #46527, lsl #16
	dup.4s	v20, w8
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	mov	w8, #11226                      ; =0x2bda
	movk	w8, #14672, lsl #16
	dup.4s	v20, w8
	fmul.4s	v20, v18, v20
	mov	w8, #38601                      ; =0x96c9
	movk	w8, #15030, lsl #16
	dup.4s	v21, w8
	fadd.4s	v20, v20, v21
	fmul.4s	v20, v18, v20
	mov	w8, #34982                      ; =0x88a6
	movk	w8, #15368, lsl #16
	dup.4s	v21, w8
	fadd.4s	v20, v20, v21
	mov	w8, #43642                      ; =0xaa7a
	movk	w8, #15658, lsl #16
	dup.4s	v21, w8
	fmul.4s	v20, v18, v20
	fadd.4s	v20, v20, v21
	fmul.4s	v20, v18, v20
	fadd.4s	v20, v20, v17
	fmla.4s	v17, v4, v16
	fmov.4s	v16, #1.00000000
	fmla.4s	v16, v4, v17
	mov	w8, #30407                      ; =0x76c7
	movk	w8, #12559, lsl #16
	dup.4s	v17, w8
	mov	w8, #62078                      ; =0xf27e
	movk	w8, #13459, lsl #16
	dup.4s	v21, w8
	fmla.4s	v21, v4, v17
	mov	w8, #3329                       ; =0xd01
	movk	w8, #14288, lsl #16
	dup.4s	v17, w8
	fmul.4s	v2, v2, v1
	fmla.4s	v17, v4, v21
	mov	w8, #2913                       ; =0xb61
	movk	w8, #15030, lsl #16
	dup.4s	v21, w8
	fmla.4s	v21, v4, v17
	mov	w8, #43691                      ; =0xaaab
	movk	w8, #15658, lsl #16
	dup.4s	v17, w8
	fmla.4s	v17, v4, v21
	movi.4s	v21, #63, lsl #24
	fmla.4s	v21, v4, v17
	fmov.4s	v17, #1.00000000
	fmla.4s	v17, v4, v21
	fmov.4s	v4, #1.00000000
	fcmge.4s	v21, v4, v3
	fmul.4s	v3, v3, v16
	fdiv.4s	v3, v3, v17
	fmul.4s	v16, v18, v20
	fadd.4s	v1, v16, v1
	fmul.4s	v16, v18, v18
	fmul.4s	v1, v16, v1
	fadd.4s	v1, v18, v1
	fadd.4s	v1, v1, v4
	movi.2d	v16, #0xffffffffffffffff
	add.4s	v16, v19, v16
	sshr.4s	v17, v16, #1
	shl.4s	v18, v17, #23
	add.4s	v18, v18, v4
	fmul.4s	v1, v1, v18
	sub.4s	v16, v16, v17
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v4
	fmul.4s	v1, v1, v16
	fcmgt.4s	v6, v6, v7
	mvni.4s	v7, #127, msl #16
	fneg.4s	v7, v7
	bit.16b	v1, v7, v6
	fmov.4s	v6, #0.25000000
	fdiv.4s	v6, v6, v1
	fsub.4s	v7, v1, v6
	fadd.4s	v1, v1, v6
	fdiv.4s	v1, v7, v1
	bif.16b	v1, v4, v5
	bit.16b	v1, v3, v21
	mvni.4s	v3, #128, lsl #24
	bif.16b	v1, v0, v3
	fcmeq.4s	v0, v0, v0
	fadd.4s	v1, v1, v4
	mvni.4s	v3, #63, msl #16
	fneg.4s	v3, v3
	bsl.16b	v0, v1, v3
	fmul.4s	v0, v2, v0
	ldr	q1, [sp, #16]                   ; 16-byte Reload
	fadd.4s	v0, v0, v1
	b	LBB1_7
LBB1_4:                                 ; %direct.true20.preheader
	mov	x9, #0                          ; =0x0
	mov	w10, #10003                     ; =0x2713
	movk	w10, #15671, lsl #16
	dup.4s	v1, w10
	mov	w10, #16938                     ; =0x422a
	movk	w10, #16204, lsl #16
	dup.4s	v0, w10
	stp	q0, q1, [sp, #256]              ; 32-byte Folded Spill
	mov	w10, #37425                     ; =0x9231
	movk	w10, #12080, lsl #16
	dup.4s	v1, w10
	mov	w10, #12843                     ; =0x322b
	movk	w10, #13015, lsl #16
	dup.4s	v0, w10
	stp	q0, q1, [sp, #224]              ; 32-byte Folded Spill
	mov	w10, #61213                     ; =0xef1d
	movk	w10, #13880, lsl #16
	dup.4s	v1, w10
	mov	w10, #3329                      ; =0xd01
	movk	w10, #14672, lsl #16
	dup.4s	v0, w10
	stp	q0, q1, [sp, #192]              ; 32-byte Folded Spill
	mov	w10, #34953                     ; =0x8889
	movk	w10, #15368, lsl #16
	dup.4s	v1, w10
	mov	w10, #43691                     ; =0xaaab
	movk	w10, #15914, lsl #16
	dup.4s	v18, w10
	mov	w10, #30407                     ; =0x76c7
	movk	w10, #12559, lsl #16
	dup.4s	v0, w10
	stp	q0, q1, [sp, #160]              ; 32-byte Folded Spill
	mov	w10, #62078                     ; =0xf27e
	movk	w10, #13459, lsl #16
	dup.4s	v1, w10
	mov	w10, #3329                      ; =0xd01
	movk	w10, #14288, lsl #16
	dup.4s	v0, w10
	stp	q0, q1, [sp, #128]              ; 32-byte Folded Spill
	mov	w10, #2913                      ; =0xb61
	movk	w10, #15030, lsl #16
	dup.4s	v1, w10
	mov	w10, #43691                     ; =0xaaab
	movk	w10, #15658, lsl #16
	dup.4s	v0, w10
	stp	q0, q1, [sp, #96]               ; 32-byte Folded Spill
	mov	w10, #-1026555904               ; =0xc2d00000
	dup.4s	v1, w10
	mov	w10, #1120403456                ; =0x42c80000
	dup.4s	v22, w10
	mov	w10, #43579                     ; =0xaa3b
	movk	w10, #16312, lsl #16
	dup.4s	v0, w10
	stp	q0, q1, [sp, #64]               ; 32-byte Folded Spill
	mov	w10, #29184                     ; =0x7200
	movk	w10, #48945, lsl #16
	dup.4s	v1, w10
	mov	w10, #48782                     ; =0xbe8e
	movk	w10, #46527, lsl #16
	dup.4s	v0, w10
	stp	q0, q1, [sp, #32]               ; 32-byte Folded Spill
	mov	w10, #11226                     ; =0x2bda
	movk	w10, #14672, lsl #16
	dup.4s	v0, w10
	str	q0, [sp, #16]                   ; 16-byte Spill
	mov	w10, #38601                     ; =0x96c9
	movk	w10, #15030, lsl #16
	dup.4s	v27, w10
	mov	w10, #34982                     ; =0x88a6
	movk	w10, #15368, lsl #16
	dup.4s	v28, w10
	mov	w10, #43642                     ; =0xaa7a
	movk	w10, #15658, lsl #16
	dup.4s	v29, w10
	add	x10, x19, x8
	add	x11, x21, x8
	add	x12, x22, x8
	movi.4s	v30, #63, lsl #24
	fmov.4s	v31, #1.00000000
	mvni.4s	v0, #127, msl #16
	fneg.4s	v12, v0
	mvni.4s	v0, #63, msl #16
	fneg.4s	v15, v0
LBB1_5:                                 ; %direct.true20
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x13, x9, #5
	add	x14, x12, x13
	ldp	q8, q9, [x14]
	ldp	q2, q1, [sp, #256]              ; 32-byte Folded Reload
	fmul.4s	v0, v8, v1
	fmul.4s	v1, v9, v1
	fmul.4s	v1, v9, v1
	fmul.4s	v0, v8, v0
	fmul.4s	v0, v8, v0
	fmul.4s	v1, v9, v1
	fadd.4s	v1, v9, v1
	fadd.4s	v0, v8, v0
	fmul.4s	v11, v0, v2
	fmul.4s	v10, v1, v2
	fabs.4s	v14, v10
	fabs.4s	v13, v11
	fmul.4s	v5, v11, v11
	fmul.4s	v16, v10, v10
	ldp	q1, q2, [sp, #224]              ; 32-byte Folded Reload
	mov.16b	v0, v1
	fmla.4s	v0, v5, v2
	fmla.4s	v1, v16, v2
	ldr	q3, [sp, #208]                  ; 16-byte Reload
	mov.16b	v2, v3
	fmla.4s	v2, v5, v0
	mov.16b	v0, v3
	fmla.4s	v0, v16, v1
	ldp	q4, q3, [sp, #176]              ; 32-byte Folded Reload
	mov.16b	v1, v3
	fmla.4s	v1, v5, v2
	mov.16b	v2, v3
	fmla.4s	v2, v16, v0
	mov.16b	v3, v4
	mov.16b	v7, v18
	mov.16b	v17, v18
	fmov.4s	v0, #1.00000000
	fmla.4s	v3, v5, v1
	ldp	q6, q19, [sp, #144]             ; 32-byte Folded Reload
	mov.16b	v1, v6
	fmla.4s	v1, v16, v19
	fmla.4s	v6, v5, v19
	ldr	q20, [sp, #128]                 ; 16-byte Reload
	mov.16b	v19, v20
	fmla.4s	v4, v16, v2
	fmla.4s	v19, v16, v1
	mov.16b	v1, v20
	fmla.4s	v1, v5, v6
	ldr	q6, [sp, #112]                  ; 16-byte Reload
	mov.16b	v2, v6
	fmla.4s	v2, v16, v19
	fmla.4s	v7, v5, v3
	mov.16b	v3, v6
	fmla.4s	v3, v5, v1
	ldp	q24, q19, [sp, #80]             ; 32-byte Folded Reload
	mov.16b	v6, v19
	fmla.4s	v6, v16, v2
	fmla.4s	v17, v16, v4
	fmla.4s	v19, v5, v3
	movi.4s	v20, #63, lsl #24
	movi.4s	v21, #63, lsl #24
	fmov.4s	v3, #1.00000000
	fmov.4s	v2, #9.00000000
	fcmge.4s	v1, v2, v13
	fmla.4s	v20, v16, v6
	fcmge.4s	v2, v2, v14
	and.16b	v4, v2, v14
	and.16b	v6, v1, v13
	fcmge.4s	v23, v6, v24
	fcmge.4s	v24, v4, v24
	fcmge.4s	v25, v22, v4
	and.16b	v24, v24, v25
	fcmge.4s	v25, v22, v6
	and.16b	v23, v23, v25
	and.16b	v23, v23, v6
	and.16b	v24, v24, v4
	fmla.4s	v0, v16, v17
	ldr	q25, [sp, #64]                  ; 16-byte Reload
	fmul.4s	v17, v24, v25
	fmul.4s	v25, v23, v25
	movi.4s	v26, #75, lsl #24
	fadd.4s	v25, v25, v26
	fadd.4s	v17, v17, v26
	movi.4s	v26, #203, lsl #24
	fadd.4s	v17, v17, v26
	fmla.4s	v3, v16, v20
	fadd.4s	v16, v25, v26
	fcvtzs.4s	v16, v16
	fcvtzs.4s	v17, v17
	scvtf.4s	v20, v17
	scvtf.4s	v25, v16
	fmla.4s	v21, v5, v19
	ldr	q26, [sp, #48]                  ; 16-byte Reload
	fmul.4s	v19, v20, v26
	fadd.4s	v19, v24, v19
	fmul.4s	v24, v25, v26
	fadd.4s	v23, v23, v24
	fmov.4s	v24, #1.00000000
	fmla.4s	v24, v5, v7
	ldr	q26, [sp, #32]                  ; 16-byte Reload
	fmul.4s	v7, v25, v26
	fadd.4s	v7, v23, v7
	fmul.4s	v20, v20, v26
	fadd.4s	v19, v19, v20
	fmov.4s	v20, #1.00000000
	fmla.4s	v20, v5, v21
	ldr	q21, [sp, #16]                  ; 16-byte Reload
	fmul.4s	v5, v19, v21
	fmul.4s	v21, v7, v21
	fadd.4s	v21, v21, v27
	fadd.4s	v5, v5, v27
	fmul.4s	v5, v19, v5
	fmul.4s	v23, v13, v24
	fmul.4s	v21, v7, v21
	fadd.4s	v21, v21, v28
	fadd.4s	v5, v5, v28
	fmul.4s	v5, v19, v5
	fmul.4s	v21, v7, v21
	fadd.4s	v21, v21, v29
	fadd.4s	v5, v5, v29
	fmul.4s	v5, v19, v5
	fmul.4s	v21, v7, v21
	fadd.4s	v21, v21, v18
	fadd.4s	v24, v5, v18
	fdiv.4s	v5, v23, v20
	fmul.4s	v20, v19, v24
	fmul.4s	v21, v7, v21
	fadd.4s	v21, v21, v30
	fadd.4s	v20, v20, v30
	fmul.4s	v23, v19, v19
	fmul.4s	v20, v23, v20
	fmul.4s	v23, v7, v7
	fmul.4s	v21, v23, v21
	fadd.4s	v7, v7, v21
	fadd.4s	v19, v19, v20
	movi.2d	v23, #0xffffffffffffffff
	add.4s	v16, v16, v23
	fadd.4s	v7, v7, v31
	sshr.4s	v20, v16, #1
	shl.4s	v21, v20, #23
	add.4s	v21, v21, v31
	fmul.4s	v7, v7, v21
	add.4s	v17, v17, v23
	fadd.4s	v19, v19, v31
	sub.4s	v16, v16, v20
	sshr.4s	v20, v17, #1
	sub.4s	v17, v17, v20
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v31
	fmul.4s	v19, v19, v20
	shl.4s	v17, v17, #23
	add.4s	v17, v17, v31
	fmul.4s	v17, v19, v17
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v31
	fmul.4s	v7, v7, v16
	fcmgt.4s	v6, v6, v22
	bsl.16b	v6, v12, v7
	fmul.4s	v0, v14, v0
	fcmgt.4s	v4, v4, v22
	bsl.16b	v4, v12, v17
	fdiv.4s	v0, v0, v3
	fmov.4s	v16, #0.25000000
	fdiv.4s	v3, v16, v4
	fsub.4s	v7, v4, v3
	fadd.4s	v3, v4, v3
	fdiv.4s	v3, v7, v3
	bsl.16b	v2, v3, v31
	fcmge.4s	v3, v31, v14
	bif.16b	v0, v2, v3
	fdiv.4s	v2, v16, v6
	fsub.4s	v3, v6, v2
	fadd.4s	v2, v6, v2
	fdiv.4s	v2, v3, v2
	bsl.16b	v1, v2, v31
	fcmge.4s	v2, v31, v13
	bit.16b	v1, v5, v2
	mvni.4s	v3, #128, lsl #24
	bif.16b	v1, v11, v3
	fcmeq.4s	v2, v11, v11
	fadd.4s	v1, v1, v31
	bif.16b	v1, v15, v2
	bif.16b	v0, v10, v3
	fcmeq.4s	v2, v10, v10
	fadd.4s	v0, v0, v31
	bif.16b	v0, v15, v2
	fmul.4s	v2, v9, v30
	fmul.4s	v0, v2, v0
	fmul.4s	v2, v8, v30
	fmul.4s	v1, v2, v1
	add	x14, x11, x13
	ldp	q3, q2, [x14]
	fadd.4s	v1, v3, v1
	fadd.4s	v0, v2, v0
	add	x13, x10, x13
	stp	q1, q0, [x13]
	add	x9, x9, #1
	cmp	x9, #192
	b.ne	LBB1_5
; %bb.6:                                ; %direct.false21
	mov	w9, #6144                       ; =0x1800
	add	x20, x8, x9
	add	x8, x22, x20
	movi.2d	v1, #0000000000000000
	ld1.s	{ v1 }[0], [x8], #4
	movi.2d	v0, #0000000000000000
	ld1.s	{ v1 }[1], [x8]
	movi.4s	v2, #63, lsl #24
	mov	w8, #10003                      ; =0x2713
	movk	w8, #15671, lsl #16
	dup.4s	v3, w8
	fmul.4s	v3, v1, v3
	fmul.4s	v3, v1, v3
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v1, v3
	mov	w8, #16938                      ; =0x422a
	movk	w8, #16204, lsl #16
	dup.4s	v4, w8
	fmul.4s	v3, v3, v4
	mov.d	v0[0], v3[0]
	fmul.4s	v1, v1, v2
	fabs.4s	v3, v0
	fmul.4s	v4, v0, v0
	mov	w8, #37425                      ; =0x9231
	movk	w8, #12080, lsl #16
	dup.4s	v5, w8
	mov	w8, #12843                      ; =0x322b
	movk	w8, #13015, lsl #16
	dup.4s	v6, w8
	mov	w8, #61213                      ; =0xef1d
	movk	w8, #13880, lsl #16
	dup.4s	v7, w8
	fmla.4s	v6, v4, v5
	fmla.4s	v7, v4, v6
	mov	w8, #3329                       ; =0xd01
	movk	w8, #14672, lsl #16
	dup.4s	v5, w8
	fmla.4s	v5, v4, v7
	mov	w8, #34953                      ; =0x8889
	movk	w8, #15368, lsl #16
	dup.4s	v7, w8
	mov	w8, #43691                      ; =0xaaab
	movk	w8, #15914, lsl #16
	dup.4s	v17, w8
	fmla.4s	v7, v4, v5
	fmov.4s	v5, #9.00000000
	fcmge.4s	v5, v5, v3
	mov	w8, #-1026555904                ; =0xc2d00000
	dup.4s	v16, w8
	and.16b	v6, v5, v3
	fcmge.4s	v18, v6, v16
	mov	w8, #1120403456                 ; =0x42c80000
	dup.4s	v16, w8
	fcmge.4s	v19, v16, v6
	and.16b	v18, v18, v19
	and.16b	v18, v18, v6
	mov	w8, #43579                      ; =0xaa3b
	movk	w8, #16312, lsl #16
	dup.4s	v19, w8
	fmul.4s	v19, v18, v19
	movi.4s	v20, #75, lsl #24
	fadd.4s	v19, v19, v20
	movi.4s	v20, #203, lsl #24
	fadd.4s	v19, v19, v20
	fcvtzs.4s	v19, v19
	scvtf.4s	v20, v19
	mov	w8, #29184                      ; =0x7200
	movk	w8, #48945, lsl #16
	dup.4s	v21, w8
	fmul.4s	v21, v20, v21
	fadd.4s	v18, v18, v21
	mov	w8, #48782                      ; =0xbe8e
	movk	w8, #46527, lsl #16
	dup.4s	v21, w8
	fmul.4s	v20, v20, v21
	mov	w8, #11226                      ; =0x2bda
	movk	w8, #14672, lsl #16
	dup.4s	v21, w8
	fadd.4s	v18, v18, v20
	fmul.4s	v20, v18, v21
	mov	w8, #38601                      ; =0x96c9
	movk	w8, #15030, lsl #16
	dup.4s	v21, w8
	fadd.4s	v20, v20, v21
	fmul.4s	v20, v18, v20
	mov	w8, #34982                      ; =0x88a6
	movk	w8, #15368, lsl #16
	dup.4s	v21, w8
	fadd.4s	v20, v20, v21
	fmul.4s	v20, v18, v20
	mov	w8, #43642                      ; =0xaa7a
	movk	w8, #15658, lsl #16
	dup.4s	v21, w8
	fadd.4s	v20, v20, v21
	fmul.4s	v20, v18, v20
	fadd.4s	v20, v20, v17
	fmla.4s	v17, v4, v7
	fmov.4s	v7, #1.00000000
	mov	w8, #30407                      ; =0x76c7
	movk	w8, #12559, lsl #16
	dup.4s	v21, w8
	fmla.4s	v7, v4, v17
	mov	w8, #62078                      ; =0xf27e
	movk	w8, #13459, lsl #16
	dup.4s	v17, w8
	fmla.4s	v17, v4, v21
	mov	w8, #3329                       ; =0xd01
	movk	w8, #14288, lsl #16
	dup.4s	v21, w8
	fmla.4s	v21, v4, v17
	mov	w8, #2913                       ; =0xb61
	movk	w8, #15030, lsl #16
	dup.4s	v17, w8
	fmla.4s	v17, v4, v21
	mov	w8, #43691                      ; =0xaaab
	movk	w8, #15658, lsl #16
	dup.4s	v21, w8
	fmla.4s	v21, v4, v17
	movi.4s	v17, #63, lsl #24
	fmla.4s	v17, v4, v21
	fmov.4s	v21, #1.00000000
	fmla.4s	v21, v4, v17
	fmov.4s	v4, #1.00000000
	fcmge.4s	v17, v4, v3
	fmul.4s	v3, v3, v7
	fdiv.4s	v3, v3, v21
	fmul.4s	v7, v18, v20
	fadd.4s	v2, v7, v2
	fmul.4s	v7, v18, v18
	fmul.4s	v2, v7, v2
	fadd.4s	v2, v18, v2
	fadd.4s	v2, v2, v4
	movi.2d	v7, #0xffffffffffffffff
	add.4s	v7, v19, v7
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v4
	fmul.4s	v2, v2, v19
	sub.4s	v7, v7, v18
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v4
	fmul.4s	v2, v2, v7
	fcmgt.4s	v6, v6, v16
	mvni.4s	v7, #127, msl #16
	fneg.4s	v7, v7
	bit.16b	v2, v7, v6
	fmov.4s	v6, #0.25000000
	fdiv.4s	v6, v6, v2
	fsub.4s	v7, v2, v6
	fadd.4s	v2, v2, v6
	fdiv.4s	v2, v7, v2
	bif.16b	v2, v4, v5
	bit.16b	v2, v3, v17
	mvni.4s	v3, #128, lsl #24
	bif.16b	v2, v0, v3
	fcmeq.4s	v0, v0, v0
	fadd.4s	v2, v2, v4
	mvni.4s	v3, #63, msl #16
	fneg.4s	v3, v3
	bsl.16b	v0, v2, v3
	fmul.4s	v0, v1, v0
	add	x8, x21, x20
	add	x9, x8, #4
	ldr	s1, [x8]
	ld1.s	{ v1 }[1], [x9]
	fadd.4s	v0, v1, v0
LBB1_7:                                 ; %common.ret
	str	d0, [x19, x20]
	add	sp, sp, #3, lsl #12             ; =12288
	add	sp, sp, #352
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #144            ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB2_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB2_4
LBB2_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB2_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB2_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB2_13
LBB2_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB2_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB2_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #1
	b.eq	LBB2_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #2
	b.eq	LBB2_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #3
	b.eq	LBB2_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB2_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB2_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
LBB2_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB2_3
LBB2_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB2_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_3:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_4:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_7:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_8:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_9:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_10:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_11:
	.quad	0                               ; 0x0
	.quad	8                               ; 0x8
lCPI0_12:
	.quad	32                              ; 0x20
	.quad	40                              ; 0x28
lCPI0_13:
	.quad	16                              ; 0x10
	.quad	24                              ; 0x18
lCPI0_14:
	.quad	48                              ; 0x30
	.quad	56                              ; 0x38
lCPI0_15:
	.quad	3078                            ; 0xc06
	.quad	3591                            ; 0xe07
lCPI0_16:
	.quad	1026                            ; 0x402
	.quad	1539                            ; 0x603
lCPI0_17:
	.quad	2052                            ; 0x804
	.quad	2565                            ; 0xa05
lCPI0_18:
	.quad	0                               ; 0x0
	.quad	513                             ; 0x201
lCPI0_20:
	.long	5                               ; 0x5
	.long	4                               ; 0x4
	.long	7                               ; 0x7
	.long	6                               ; 0x6
lCPI0_21:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	3                               ; 0x3
	.long	2                               ; 0x2
lCPI0_22:
	.long	6                               ; 0x6
	.long	7                               ; 0x7
	.long	4                               ; 0x4
	.long	5                               ; 0x5
lCPI0_23:
	.long	2                               ; 0x2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	1                               ; 0x1
lCPI0_24:
	.long	4                               ; 0x4
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_19:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	dup.4s	v20, w2
Lloh0:
	adrp	x8, lCPI0_1@PAGE
Lloh1:
	ldr	q4, [x8, lCPI0_1@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_2@PAGE
Lloh3:
	ldr	q5, [x8, lCPI0_2@PAGEOFF]
	cmhi.4s	v0, v20, v5
	cmhi.4s	v1, v20, v4
	uzp1.8h	v3, v1, v0
	umaxv.8h	h2, v3
	fmov	w8, s2
	tbz	w8, #0, LBB0_166
; %bb.1:                                ; %direct.activate
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #2384
	str	q5, [sp, #592]                  ; 16-byte Spill
	str	q4, [sp, #672]                  ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	ldr	x2, [x1, #136]
	add	x9, x2, #17, lsl #12            ; =69632
	add	x9, x9, #168
	str	x9, [sp, #280]                  ; 8-byte Spill
	mov	w9, #53384                      ; =0xd088
	add	x15, x2, x9
	mov	w9, #16416                      ; =0x4020
	add	x16, x2, x9
	mov	w9, #49248                      ; =0xc060
	add	x9, x2, x9
	dup.2d	v28, x9
	mov	w9, #53352                      ; =0xd068
	add	x13, x2, x9
	add	x9, x2, #17, lsl #12            ; =69632
	add	x9, x9, #136
	ldr	x10, [x0]
	ldr	x11, [x0, #48]
	str	x11, [sp, #392]                 ; 8-byte Spill
Lloh4:
	adrp	x11, lCPI0_0@PAGE
Lloh5:
	ldr	q2, [x11, lCPI0_0@PAGEOFF]
	and.16b	v2, v3, v2
	addv.8h	h15, v2
	fmov	w11, s15
	and	w11, w11, #0xff
	str	w11, [sp, #276]                 ; 4-byte Spill
	ldr	w11, [x1]
	ldr	w12, [x1, #36]
	add	w11, w12, w11, lsl #5
	lsr	w11, w11, #3
	dup.4s	v2, w11
	and.16b	v8, v1, v2
	and.16b	v9, v0, v2
	ushll2.2d	v16, v9, #0
	ushll2.2d	v17, v8, #0
	ushll.2d	v18, v9, #0
	ushll.2d	v4, v8, #0
	fmov	x11, d4
	mov	w12, #16388                     ; =0x4004
	umaddl	x11, w11, w12, x10
	fmov	w12, s15
	b	LBB0_3
LBB0_2:                                 ; %else48
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x2, x8
	stp	q5, q2, [x17]
	add	x8, x8, #32
	cmp	x8, #4, lsl #12                 ; =16384
	b.eq	LBB0_19
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	add	x17, x11, x8
	add	x1, x2, x8
	ldr	q5, [x1]
	tbnz	w12, #0, LBB0_11
; %bb.4:                                ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w0, w12, #0xff
	tbnz	w0, #1, LBB0_12
LBB0_5:                                 ; %else30
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w0, #2, LBB0_13
LBB0_6:                                 ; %else33
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w0, #3, LBB0_14
LBB0_7:                                 ; %else36
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q2, [x1, #16]
	tbnz	w0, #4, LBB0_15
LBB0_8:                                 ; %else39
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w0, #5, LBB0_16
LBB0_9:                                 ; %else42
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w0, #6, LBB0_17
LBB0_10:                                ; %else45
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w0, #7, LBB0_2
	b	LBB0_18
LBB0_11:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	ld1.s	{ v5 }[0], [x17]
	and	w0, w12, #0xff
	tbz	w0, #1, LBB0_5
LBB0_12:                                ; %cond.load29
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x3, x17, #4
	ld1.s	{ v5 }[1], [x3]
	tbz	w0, #2, LBB0_6
LBB0_13:                                ; %cond.load32
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x3, x17, #8
	ld1.s	{ v5 }[2], [x3]
	tbz	w0, #3, LBB0_7
LBB0_14:                                ; %cond.load35
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x3, x17, #12
	ld1.s	{ v5 }[3], [x3]
	ldr	q2, [x1, #16]
	tbz	w0, #4, LBB0_8
LBB0_15:                                ; %cond.load38
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x17, #16
	ld1.s	{ v2 }[0], [x1]
	tbz	w0, #5, LBB0_9
LBB0_16:                                ; %cond.load41
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x17, #20
	ld1.s	{ v2 }[1], [x1]
	tbz	w0, #6, LBB0_10
LBB0_17:                                ; %cond.load44
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x17, #24
	ld1.s	{ v2 }[2], [x1]
	tbz	w0, #7, LBB0_2
LBB0_18:                                ; %cond.load47
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x17, #28
	ld1.s	{ v2 }[3], [x17]
	b	LBB0_2
LBB0_19:                                ; %direct.false
	xtn.8b	v5, v3
	sshll.2d	v2, v1, #0
	sshll.2d	v21, v0, #0
	sshll2.2d	v25, v1, #0
	sshll2.2d	v26, v0, #0
Lloh6:
	adrp	x8, lCPI0_6@PAGE
Lloh7:
	ldr	q10, [x8, lCPI0_6@PAGEOFF]
	and.16b	v19, v2, v10
	movi.2d	v6, #0000000000000000
Lloh8:
	adrp	x8, lCPI0_7@PAGE
Lloh9:
	ldr	q3, [x8, lCPI0_7@PAGEOFF]
	and.16b	v29, v2, v3
Lloh10:
	adrp	x8, lCPI0_8@PAGE
Lloh11:
	ldr	q2, [x8, lCPI0_8@PAGEOFF]
	and.16b	v2, v21, v2
Lloh12:
	adrp	x8, lCPI0_9@PAGE
Lloh13:
	ldr	q3, [x8, lCPI0_9@PAGEOFF]
	and.16b	v7, v25, v3
Lloh14:
	adrp	x8, lCPI0_10@PAGE
Lloh15:
	ldr	q3, [x8, lCPI0_10@PAGEOFF]
	and.16b	v22, v26, v3
	movi.8b	v3, #1
	and.8b	v3, v5, v3
	umov.b	w8, v3[0]
	movi.2d	v23, #0000000000000000
	movi.2d	v3, #0000000000000000
	mov.b	v3[0], v5[0]
	stp	q5, q3, [sp, #464]              ; 32-byte Folded Spill
	umaxv.8b	b3, v3
	fmov	w12, s3
	rbit	w11, w8
	clz	w11, w11
	tst	w12, #0x1
	csel	w14, w11, wzr, ne
	mov	w11, #4096                      ; =0x1000
	dup.2d	v30, x11
	str	q19, [sp, #224]                 ; 16-byte Spill
	orr.16b	v27, v19, v30
	mov	w11, #4097                      ; =0x1001
	dup.2s	v3, w11
	xtn.2s	v19, v4
	mov.16b	v24, v27
	umlal.2d	v24, v19, v3
	mov.b	v23[0], v5[0]
	ushll.2d	v4, v23, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	str	q24, [sp, #368]                 ; 16-byte Spill
	and.16b	v4, v4, v24
	str	q6, [sp, #2288]
	str	q6, [sp, #2272]
	str	q6, [sp, #2256]
	str	q4, [sp, #2240]
	ubfiz	x11, x14, #3, #3
	add	x17, sp, #2240
	ldr	x17, [x17, x11]
	sub	x17, x17, x14
	add	x10, x10, x17, lsl #2
	str	q22, [sp, #2352]
	str	q2, [sp, #2336]
	str	q7, [sp, #2320]
	str	q29, [sp, #240]                 ; 16-byte Spill
	str	q29, [sp, #2304]
	add	x17, sp, #2304
	ldr	x11, [x17, x11]
	orr	x11, x11, #0x4000
	sub	x11, x11, w14, uxtw #2
	tst	w8, #0x1
	csel	x19, xzr, x11, eq
	add	x11, x2, x19
	ldr	q14, [x11]
	tbnz	w12, #0, LBB0_78
; %bb.20:                               ; %else52
	tbnz	w8, #1, LBB0_79
LBB0_21:                                ; %else55
	tbnz	w8, #2, LBB0_80
LBB0_22:                                ; %else58
	tbnz	w8, #3, LBB0_81
LBB0_23:                                ; %else61
	adrp	x12, lCPI0_3@PAGE
	adrp	x17, lCPI0_4@PAGE
	adrp	x0, lCPI0_5@PAGE
	ldr	q2, [x11, #16]
	tbnz	w8, #4, LBB0_82
LBB0_24:                                ; %else64
	ldr	q11, [x12, lCPI0_3@PAGEOFF]
	ldr	q12, [x17, lCPI0_4@PAGEOFF]
	ldr	q13, [x0, lCPI0_5@PAGEOFF]
	tbnz	w8, #5, LBB0_83
LBB0_25:                                ; %else67
	and.16b	v4, v26, v11
	and.16b	v5, v25, v12
	and.16b	v6, v21, v13
	stp	q26, q25, [sp, #416]            ; 32-byte Folded Spill
	tbz	w8, #6, LBB0_27
LBB0_26:                                ; %cond.load69
	add	x11, x10, #24
	ld1.s	{ v2 }[2], [x11]
LBB0_27:                                ; %else70
	stp	q6, q5, [sp, #176]              ; 32-byte Folded Spill
	orr.16b	v29, v6, v30
	orr.16b	v5, v5, v30
	str	q4, [sp, #208]                  ; 16-byte Spill
	orr.16b	v30, v4, v30
	xtn.2s	v6, v17
	xtn.2s	v4, v18
	xtn.2s	v7, v16
	tbz	w8, #7, LBB0_29
; %bb.28:                               ; %cond.load72
	add	x10, x10, #28
	ld1.s	{ v2 }[3], [x10]
LBB0_29:                                ; %else73
	mov	x10, #0                         ; =0x0
	mov	w11, #1                         ; =0x1
	dup.2d	v16, x11
	add	x11, x2, x19
	stp	q14, q2, [x11]
	umull.2d	v2, v19, v3
	str	q2, [sp, #288]                  ; 16-byte Spill
	mov.16b	v2, v30
	umlal.2d	v2, v7, v3
	str	q2, [sp, #336]                  ; 16-byte Spill
	mov.16b	v2, v5
	umlal.2d	v2, v6, v3
	str	q2, [sp, #320]                  ; 16-byte Spill
	mov.16b	v2, v29
	umlal.2d	v2, v4, v3
	str	q2, [sp, #304]                  ; 16-byte Spill
	ushll2.2d	v2, v0, #0
	and.16b	v23, v2, v16
	ushll2.2d	v2, v1, #0
	and.16b	v24, v2, v16
	ushll.2d	v2, v0, #0
	and.16b	v31, v2, v16
	ushll.2d	v2, v1, #0
	and.16b	v14, v2, v16
	movi.2d	v2, #0000000000000000
	sshll.2d	v3, v0, #0
	sshll.2d	v4, v1, #0
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	ldp	q26, q25, [sp, #416]            ; 32-byte Folded Reload
	stp	q24, q23, [sp, #640]            ; 32-byte Folded Spill
	str	q14, [sp, #624]                 ; 16-byte Spill
LBB0_30:                                ; %direct.true73
                                        ; =>This Inner Loop Header: Depth=1
	shl.2d	v17, v16, #3
	shl.2d	v18, v2, #3
	shl.2d	v19, v7, #3
	shl.2d	v21, v6, #3
	orr.16b	v21, v21, v12
	orr.16b	v19, v19, v13
	orr.16b	v18, v18, v10
	orr.16b	v17, v17, v11
	add	x10, x16, x10, lsl #6
	ldp	q23, q22, [x10]
	ldp	q24, q14, [x10, #32]
	bif.16b	v17, v14, v26
	bif.16b	v18, v23, v4
	bif.16b	v19, v24, v3
	ldp	q14, q24, [sp, #624]            ; 32-byte Folded Reload
	ldr	q23, [sp, #656]                 ; 16-byte Reload
	bif.16b	v21, v22, v25
	stp	q18, q21, [x10]
	stp	q19, q17, [x10, #32]
	add.2d	v6, v6, v24
	add.2d	v7, v7, v31
	add.2d	v16, v16, v23
	add.2d	v2, v2, v14
	fmov	x10, d2
	cmp	x10, #512
	b.lt	LBB0_30
; %bb.31:                               ; %direct.false74
	mov	x10, #0                         ; =0x0
	sshll.2d	v21, v0, #0
	sshll.2d	v3, v1, #0
Lloh16:
	adrp	x11, lCPI0_11@PAGE
Lloh17:
	ldr	q2, [x11, lCPI0_11@PAGEOFF]
	and.16b	v2, v3, v2
Lloh18:
	adrp	x11, lCPI0_12@PAGE
Lloh19:
	ldr	q4, [x11, lCPI0_12@PAGEOFF]
	and.16b	v4, v21, v4
Lloh20:
	adrp	x11, lCPI0_13@PAGE
Lloh21:
	ldr	q6, [x11, lCPI0_13@PAGEOFF]
	and.16b	v6, v25, v6
Lloh22:
	adrp	x11, lCPI0_14@PAGE
Lloh23:
	ldr	q7, [x11, lCPI0_14@PAGEOFF]
	and.16b	v7, v26, v7
	str	q7, [sp, #2224]
	str	q4, [sp, #2208]
	str	q6, [sp, #2192]
	str	q2, [sp, #2176]
	mov	w11, #4097                      ; =0x1001
	dup.4s	v2, w11
	and.16b	v4, v1, v2
	mvn.16b	v6, v1
	sub.4s	v4, v4, v6
	and.16b	v2, v0, v2
	mvn.16b	v6, v0
	sub.4s	v2, v2, v6
	mov.s	w11, v2[1]
	mov.s	w12, v2[2]
	mov.s	w17, v2[3]
	fmov	w0, s2
	fmov	w1, s9
	udiv	w3, w1, w0
	msub	w0, w3, w0, w1
	mov.s	w1, v9[1]
	udiv	w3, w1, w11
	msub	w11, w3, w11, w1
	mov.s	w1, v9[2]
	udiv	w3, w1, w12
	msub	w12, w3, w12, w1
	mov.s	w1, v9[3]
	udiv	w3, w1, w17
	msub	w17, w3, w17, w1
	mov.s	w1, v4[1]
	mov.s	w3, v4[2]
	mov.s	w4, v4[3]
	fmov	w5, s4
	fmov	w6, s8
	udiv	w7, w6, w5
	msub	w5, w7, w5, w6
	mov.s	w6, v8[1]
	udiv	w7, w6, w1
	msub	w1, w7, w1, w6
	mov.s	w6, v8[2]
	udiv	w7, w6, w3
	msub	w3, w7, w3, w6
	mov.s	w6, v8[3]
	udiv	w7, w6, w4
	msub	w4, w7, w4, w6
	and	x6, x14, #0x7
	add	x7, sp, #2176
	ldr	x6, [x7, x6, lsl #3]
	tst	w8, #0xff
	fmov	s2, w0
	mov.s	v2[1], w11
	mov.s	v2[2], w12
	mov.s	v2[3], w17
	fmov	s4, w5
	mov.s	v4[1], w1
	orr	x8, x6, #0x8000
	sub	x8, x8, x14, lsl #3
	csel	x8, xzr, x8, eq
	mov.s	v4[2], w3
	add	x11, x16, x8
	ldp	q6, q7, [x11, #32]
	ldp	q16, q17, [x11]
	ldr	q22, [sp, #480]                 ; 16-byte Reload
	mov	b18, v22[2]
	mov.b	v18[4], v22[3]
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	bit.16b	v17, v5, v18
	mov	b18, v22[0]
	mov.b	v18[4], v22[1]
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	bit.16b	v16, v27, v18
	mov	b18, v22[6]
	mov.b	v18[4], v22[7]
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	mov	b19, v22[4]
	mov.b	v19[4], v22[5]
	bit.16b	v7, v30, v18
	ushll.2d	v18, v19, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	mov.s	v4[3], w4
	bit.16b	v6, v29, v18
	and.16b	v4, v1, v4
	and.16b	v2, v0, v2
	ushll2.2d	v10, v2, #0
	ushll2.2d	v12, v4, #0
	ushll.2d	v11, v2, #0
	ushll.2d	v13, v4, #0
	and.16b	v5, v26, v28
	and.16b	v22, v25, v28
	and.16b	v27, v21, v28
	and.16b	v28, v3, v28
Lloh24:
	adrp	x12, lCPI0_17@PAGE
Lloh25:
	ldr	q2, [x12, lCPI0_17@PAGEOFF]
	and.16b	v29, v21, v2
Lloh26:
	adrp	x12, lCPI0_18@PAGE
Lloh27:
	ldr	q2, [x12, lCPI0_18@PAGEOFF]
	and.16b	v30, v3, v2
Lloh28:
	adrp	x12, lCPI0_15@PAGE
Lloh29:
	ldr	q2, [x12, lCPI0_15@PAGEOFF]
	and.16b	v8, v26, v2
	ldr	q2, [sp, #592]                  ; 16-byte Reload
	cmhs.4s	v2, v2, v20
	ldr	q3, [sp, #672]                  ; 16-byte Reload
	cmhs.4s	v3, v3, v20
Lloh30:
	adrp	x12, lCPI0_16@PAGE
Lloh31:
	ldr	q4, [x12, lCPI0_16@PAGEOFF]
	and.16b	v18, v25, v4
	uzp1.8h	v2, v3, v2
	stp	q6, q7, [x11, #32]
	stp	q16, q17, [x11]
	xtn.8b	v3, v2
	movi.2d	v4, #0000000000000000
	movi.8b	v6, #1
	movi.2d	v2, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v20, #0000000000000000
	str	q31, [sp, #672]                 ; 16-byte Spill
	mov.16b	v31, v18
	b	LBB0_33
LBB0_32:                                ; %else90
                                        ;   in Loop: Header=BB0_33 Depth=1
	add.2d	v2, v2, v24
	ldr	q16, [sp, #672]                 ; 16-byte Reload
	add.2d	v7, v7, v16
	add.2d	v20, v20, v23
	add.2d	v4, v4, v14
	fmov	x10, d4
	cmp	x10, #512
	b.ge	LBB0_49
LBB0_33:                                ; %direct.true89
                                        ; =>This Inner Loop Header: Depth=1
	fmov	w11, s15
	add	x10, x16, x10, lsl #6
	ldp	q17, q16, [x10, #32]
	ldp	q18, q19, [x10]
	cmge.2d	v19, v12, v19
	cmge.2d	v18, v13, v18
	uzp1.4s	v18, v18, v19
	cmge.2d	v17, v11, v17
	cmge.2d	v16, v10, v16
	uzp1.4s	v16, v17, v16
	uzp1.8h	v16, v18, v16
	xtn.8b	v16, v16
	orr.8b	v16, v3, v16
	add.2d	v17, v4, v30
	add.2d	v17, v28, v17
	and.8b	v16, v16, v6
	tbnz	w11, #0, LBB0_41
; %bb.34:                               ; %else76
                                        ;   in Loop: Header=BB0_33 Depth=1
	and	w10, w11, #0xff
	tbnz	w10, #1, LBB0_42
LBB0_35:                                ; %else78
                                        ;   in Loop: Header=BB0_33 Depth=1
	add.2d	v17, v2, v31
	add.2d	v17, v22, v17
	tbnz	w10, #2, LBB0_43
LBB0_36:                                ; %else80
                                        ;   in Loop: Header=BB0_33 Depth=1
	tbnz	w10, #3, LBB0_44
LBB0_37:                                ; %else82
                                        ;   in Loop: Header=BB0_33 Depth=1
	add.2d	v17, v7, v29
	add.2d	v17, v27, v17
	tbnz	w10, #4, LBB0_45
LBB0_38:                                ; %else84
                                        ;   in Loop: Header=BB0_33 Depth=1
	tbnz	w10, #5, LBB0_46
LBB0_39:                                ; %else86
                                        ;   in Loop: Header=BB0_33 Depth=1
	add.2d	v17, v20, v8
	add.2d	v17, v5, v17
	tbnz	w10, #6, LBB0_47
LBB0_40:                                ; %else88
                                        ;   in Loop: Header=BB0_33 Depth=1
	tbz	w10, #7, LBB0_32
	b	LBB0_48
LBB0_41:                                ; %cond.store
                                        ;   in Loop: Header=BB0_33 Depth=1
	fmov	x10, d17
	str	b16, [x10]
	and	w10, w11, #0xff
	tbz	w10, #1, LBB0_35
LBB0_42:                                ; %cond.store77
                                        ;   in Loop: Header=BB0_33 Depth=1
	mov.d	x11, v17[1]
	st1.b	{ v16 }[1], [x11]
	add.2d	v17, v2, v31
	add.2d	v17, v22, v17
	tbz	w10, #2, LBB0_36
LBB0_43:                                ; %cond.store79
                                        ;   in Loop: Header=BB0_33 Depth=1
	fmov	x11, d17
	st1.b	{ v16 }[2], [x11]
	tbz	w10, #3, LBB0_37
LBB0_44:                                ; %cond.store81
                                        ;   in Loop: Header=BB0_33 Depth=1
	mov.d	x11, v17[1]
	st1.b	{ v16 }[3], [x11]
	add.2d	v17, v7, v29
	add.2d	v17, v27, v17
	tbz	w10, #4, LBB0_38
LBB0_45:                                ; %cond.store83
                                        ;   in Loop: Header=BB0_33 Depth=1
	fmov	x11, d17
	st1.b	{ v16 }[4], [x11]
	tbz	w10, #5, LBB0_39
LBB0_46:                                ; %cond.store85
                                        ;   in Loop: Header=BB0_33 Depth=1
	mov.d	x11, v17[1]
	st1.b	{ v16 }[5], [x11]
	add.2d	v17, v20, v8
	add.2d	v17, v5, v17
	tbz	w10, #6, LBB0_40
LBB0_47:                                ; %cond.store87
                                        ;   in Loop: Header=BB0_33 Depth=1
	fmov	x11, d17
	st1.b	{ v16 }[6], [x11]
	tbz	w10, #7, LBB0_32
LBB0_48:                                ; %cond.store89
                                        ;   in Loop: Header=BB0_33 Depth=1
	mov.d	x10, v17[1]
	st1.b	{ v16 }[7], [x10]
	b	LBB0_32
LBB0_49:                                ; %direct.false90
	add	x8, x16, x8
	ldp	q3, q2, [x8, #32]
	ldp	q4, q6, [x8]
	cmge.2d	v6, v12, v6
	cmge.2d	v4, v13, v4
	uzp1.4s	v4, v4, v6
	cmge.2d	v3, v11, v3
	cmge.2d	v2, v10, v2
	uzp1.4s	v2, v3, v2
	uzp1.8h	v2, v4, v2
	xtn.8b	v2, v2
Lloh32:
	adrp	x8, lCPI0_19@PAGE
Lloh33:
	ldr	d3, [x8, lCPI0_19@PAGEOFF]
	ldr	q6, [sp, #480]                  ; 16-byte Reload
	shl.8b	v4, v6, #7
	cmlt.8b	v4, v4, #0
	and.8b	v3, v4, v3
	addv.8b	b3, v3
	str	d3, [sp, #456]                  ; 8-byte Spill
	fmov	w8, s3
	orn.8b	v2, v2, v6
	add.2d	v4, v30, v28
	mov	w10, #512                       ; =0x200
	dup.2d	v3, x10
	add.2d	v19, v4, v3
	movi.8b	v4, #1
	and.8b	v2, v2, v4
	tbnz	w8, #0, LBB0_84
; %bb.50:                               ; %else95
	add.2d	v4, v31, v22
	mov.d	x1, v19[1]
	tbnz	w8, #1, LBB0_85
LBB0_51:                                ; %else99
	add.2d	v18, v4, v3
	tbnz	w8, #2, LBB0_86
LBB0_52:                                ; %else103
	add.2d	v4, v29, v27
	mov.d	x0, v18[1]
	tbnz	w8, #3, LBB0_87
LBB0_53:                                ; %else107
	add.2d	v17, v4, v3
	tbnz	w8, #4, LBB0_88
LBB0_54:                                ; %else111
	add.2d	v4, v8, v5
	mov.d	x17, v17[1]
	tbnz	w8, #5, LBB0_89
LBB0_55:                                ; %else115
	add.2d	v16, v4, v3
	tbnz	w8, #6, LBB0_90
LBB0_56:                                ; %else119
	mov.d	x16, v16[1]
	tbz	w8, #7, LBB0_58
LBB0_57:                                ; %cond.store120
	st1.b	{ v2 }[7], [x16]
LBB0_58:                                ; %else123
	mov	x10, #0                         ; =0x0
	movi.2d	v3, #0000000000000000
	fmov	w8, s15
	mov	w11, #62154                     ; =0xf2ca
	movk	w11, #61769, lsl #16
	dup.4s	v20, w11
	movi.2d	v21, #0000000000000000
	movi.2d	v9, #0000000000000000
	movi.2d	v10, #0000000000000000
	b	LBB0_60
LBB0_59:                                ; %else155
                                        ;   in Loop: Header=BB0_60 Depth=1
	cmeq.8b	v2, v4, #0
	sshll.8h	v2, v2, #0
	sshll2.4s	v4, v2, #0
	sshll.4s	v2, v2, #0
	lsl	x10, x10, #5
	add	x11, x2, x10
	ldp	q6, q7, [x11]
	and.16b	v7, v0, v7
	and.16b	v6, v1, v6
	bsl.16b	v2, v20, v6
	bsl.16b	v4, v20, v7
	add	x10, x13, x10
	ldp	q6, q7, [x10]
	bif.16b	v4, v7, v0
	bif.16b	v2, v6, v1
	stp	q2, q4, [x10]
	add.2d	v21, v21, v24
	ldr	q2, [sp, #672]                  ; 16-byte Reload
	add.2d	v9, v9, v2
	add.2d	v10, v10, v23
	add.2d	v3, v3, v14
	fmov	x10, d3
	cmp	x10, #512
	b.ge	LBB0_76
LBB0_60:                                ; %direct.true105
                                        ; =>This Inner Loop Header: Depth=1
	add.2d	v2, v3, v30
	add.2d	v2, v28, v2
	tbz	w8, #0, LBB0_69
; %bb.61:                               ; %cond.load125
                                        ;   in Loop: Header=BB0_60 Depth=1
	fmov	x11, d2
	ldr	b4, [x11]
	and	w11, w8, #0xff
	tbz	w11, #1, LBB0_63
LBB0_62:                                ; %cond.load129
                                        ;   in Loop: Header=BB0_60 Depth=1
	mov.d	x12, v2[1]
	ld1.b	{ v4 }[1], [x12]
LBB0_63:                                ; %else131
                                        ;   in Loop: Header=BB0_60 Depth=1
	add.2d	v2, v21, v31
	add.2d	v2, v22, v2
	tbnz	w11, #2, LBB0_70
; %bb.64:                               ; %else135
                                        ;   in Loop: Header=BB0_60 Depth=1
	tbnz	w11, #3, LBB0_71
LBB0_65:                                ; %else139
                                        ;   in Loop: Header=BB0_60 Depth=1
	add.2d	v2, v9, v29
	add.2d	v2, v27, v2
	tbnz	w11, #4, LBB0_72
LBB0_66:                                ; %else143
                                        ;   in Loop: Header=BB0_60 Depth=1
	tbnz	w11, #5, LBB0_73
LBB0_67:                                ; %else147
                                        ;   in Loop: Header=BB0_60 Depth=1
	add.2d	v2, v10, v8
	add.2d	v2, v5, v2
	tbnz	w11, #6, LBB0_74
LBB0_68:                                ; %else151
                                        ;   in Loop: Header=BB0_60 Depth=1
	tbz	w11, #7, LBB0_59
	b	LBB0_75
LBB0_69:                                ;   in Loop: Header=BB0_60 Depth=1
	movi.2d	v4, #0000000000000000
	and	w11, w8, #0xff
	tbnz	w11, #1, LBB0_62
	b	LBB0_63
LBB0_70:                                ; %cond.load133
                                        ;   in Loop: Header=BB0_60 Depth=1
	fmov	x12, d2
	ld1.b	{ v4 }[2], [x12]
	tbz	w11, #3, LBB0_65
LBB0_71:                                ; %cond.load137
                                        ;   in Loop: Header=BB0_60 Depth=1
	mov.d	x12, v2[1]
	ld1.b	{ v4 }[3], [x12]
	add.2d	v2, v9, v29
	add.2d	v2, v27, v2
	tbz	w11, #4, LBB0_66
LBB0_72:                                ; %cond.load141
                                        ;   in Loop: Header=BB0_60 Depth=1
	fmov	x12, d2
	ld1.b	{ v4 }[4], [x12]
	tbz	w11, #5, LBB0_67
LBB0_73:                                ; %cond.load145
                                        ;   in Loop: Header=BB0_60 Depth=1
	mov.d	x12, v2[1]
	ld1.b	{ v4 }[5], [x12]
	add.2d	v2, v10, v8
	add.2d	v2, v5, v2
	tbz	w11, #6, LBB0_68
LBB0_74:                                ; %cond.load149
                                        ;   in Loop: Header=BB0_60 Depth=1
	fmov	x12, d2
	ld1.b	{ v4 }[6], [x12]
	tbz	w11, #7, LBB0_59
LBB0_75:                                ; %cond.load153
                                        ;   in Loop: Header=BB0_60 Depth=1
	mov.d	x11, v2[1]
	ld1.b	{ v4 }[7], [x11]
	b	LBB0_59
LBB0_76:                                ; %direct.true139.preheader
	ldr	d2, [sp, #456]                  ; 8-byte Reload
	fmov	w8, s2
	tbz	w8, #0, LBB0_91
; %bb.77:                               ; %cond.load158
	fmov	x10, d19
	ldr	b2, [x10]
	tbnz	w8, #1, LBB0_92
	b	LBB0_93
LBB0_78:                                ; %cond.load51
	ld1.s	{ v14 }[0], [x10]
	tbz	w8, #1, LBB0_21
LBB0_79:                                ; %cond.load54
	add	x12, x10, #4
	ld1.s	{ v14 }[1], [x12]
	tbz	w8, #2, LBB0_22
LBB0_80:                                ; %cond.load57
	add	x12, x10, #8
	ld1.s	{ v14 }[2], [x12]
	tbz	w8, #3, LBB0_23
LBB0_81:                                ; %cond.load60
	add	x12, x10, #12
	ld1.s	{ v14 }[3], [x12]
	adrp	x12, lCPI0_3@PAGE
	adrp	x17, lCPI0_4@PAGE
	adrp	x0, lCPI0_5@PAGE
	ldr	q2, [x11, #16]
	tbz	w8, #4, LBB0_24
LBB0_82:                                ; %cond.load63
	add	x11, x10, #16
	ld1.s	{ v2 }[0], [x11]
	ldr	q11, [x12, lCPI0_3@PAGEOFF]
	ldr	q12, [x17, lCPI0_4@PAGEOFF]
	ldr	q13, [x0, lCPI0_5@PAGEOFF]
	tbz	w8, #5, LBB0_25
LBB0_83:                                ; %cond.load66
	add	x11, x10, #20
	ld1.s	{ v2 }[1], [x11]
	and.16b	v4, v26, v11
	and.16b	v5, v25, v12
	and.16b	v6, v21, v13
	stp	q26, q25, [sp, #416]            ; 32-byte Folded Spill
	tbnz	w8, #6, LBB0_26
	b	LBB0_27
LBB0_84:                                ; %cond.store92
	fmov	x10, d19
	str	b2, [x10]
	add.2d	v4, v31, v22
	mov.d	x1, v19[1]
	tbz	w8, #1, LBB0_51
LBB0_85:                                ; %cond.store96
	st1.b	{ v2 }[1], [x1]
	add.2d	v18, v4, v3
	tbz	w8, #2, LBB0_52
LBB0_86:                                ; %cond.store100
	fmov	x10, d18
	st1.b	{ v2 }[2], [x10]
	add.2d	v4, v29, v27
	mov.d	x0, v18[1]
	tbz	w8, #3, LBB0_53
LBB0_87:                                ; %cond.store104
	st1.b	{ v2 }[3], [x0]
	add.2d	v17, v4, v3
	tbz	w8, #4, LBB0_54
LBB0_88:                                ; %cond.store108
	fmov	x10, d17
	st1.b	{ v2 }[4], [x10]
	add.2d	v4, v8, v5
	mov.d	x17, v17[1]
	tbz	w8, #5, LBB0_55
LBB0_89:                                ; %cond.store112
	st1.b	{ v2 }[5], [x17]
	add.2d	v16, v4, v3
	tbz	w8, #6, LBB0_56
LBB0_90:                                ; %cond.store116
	fmov	x10, d16
	st1.b	{ v2 }[6], [x10]
	mov.d	x16, v16[1]
	tbnz	w8, #7, LBB0_57
	b	LBB0_58
LBB0_91:
	movi.2d	v2, #0000000000000000
	tbz	w8, #1, LBB0_93
LBB0_92:                                ; %cond.load164
	ld1.b	{ v2 }[1], [x1]
LBB0_93:                                ; %else168
	tbnz	w8, #2, LBB0_123
; %bb.94:                               ; %else174
	tbnz	w8, #3, LBB0_124
LBB0_95:                                ; %else180
	tbnz	w8, #4, LBB0_125
LBB0_96:                                ; %else186
	tbnz	w8, #5, LBB0_126
LBB0_97:                                ; %else192
	tbz	w8, #6, LBB0_99
LBB0_98:                                ; %cond.load194
	fmov	x10, d16
	ld1.b	{ v2 }[6], [x10]
LBB0_99:                                ; %else198
	ldr	q3, [sp, #464]                  ; 16-byte Reload
	mov.b	v3[0], wzr
	str	q3, [sp, #400]                  ; 16-byte Spill
	stp	q27, q22, [sp, #576]            ; 32-byte Folded Spill
	stp	q29, q28, [sp, #544]            ; 32-byte Folded Spill
	stp	q8, q30, [sp, #512]             ; 32-byte Folded Spill
	str	q31, [sp, #496]                 ; 16-byte Spill
	str	q15, [sp, #608]                 ; 16-byte Spill
	str	q5, [sp, #256]                  ; 16-byte Spill
	str	q16, [sp, #112]                 ; 16-byte Spill
	str	q17, [sp, #80]                  ; 16-byte Spill
	str	q18, [sp, #48]                  ; 16-byte Spill
	str	q19, [sp, #16]                  ; 16-byte Spill
	tbz	w8, #7, LBB0_101
; %bb.100:                              ; %cond.load200
	ld1.b	{ v2 }[7], [x16]
LBB0_101:                               ; %else204
	str	x1, [sp, #40]                   ; 8-byte Spill
	str	x0, [sp, #72]                   ; 8-byte Spill
	str	x17, [sp, #104]                 ; 8-byte Spill
	str	x16, [sp, #136]                 ; 8-byte Spill
	str	x14, [sp, #384]                 ; 8-byte Spill
	sshll.2d	v3, v1, #0
	sshll.2d	v21, v0, #0
	cmeq.8b	v2, v2, #0
	sshll.8h	v2, v2, #0
	sshll2.4s	v4, v2, #0
	sshll.4s	v2, v2, #0
	add	x8, x2, x19
	ldp	q6, q7, [x8]
	ldr	q17, [sp, #480]                 ; 16-byte Reload
	zip2.8b	v16, v17, v0
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	and.16b	v7, v16, v7
	zip1.8b	v17, v17, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	and.16b	v6, v17, v6
	mov	w8, #62154                      ; =0xf2ca
	movk	w8, #61769, lsl #16
	dup.4s	v18, w8
	bit.16b	v6, v18, v2
	mov.16b	v5, v4
	bsl.16b	v5, v18, v7
	str	x19, [sp, #360]                 ; 8-byte Spill
	add	x8, x13, x19
	ldp	q2, q4, [x8]
	stp	q6, q5, [sp, #144]              ; 32-byte Folded Spill
	bit.16b	v4, v5, v16
	bit.16b	v2, v6, v17
	stp	q2, q4, [x8]
	ldr	q2, [sp, #240]                  ; 16-byte Reload
	fmov	x10, d2
	mov	w8, #4                          ; =0x4
	dup.2d	v2, x8
	and.16b	v19, v26, v2
	and.16b	v15, v25, v2
	and.16b	v20, v21, v2
	and.16b	v5, v3, v2
	fmov	x5, d5
	ldp	q2, q4, [x15, #64]
	and.16b	v9, v0, v4
	and.16b	v11, v1, v2
	ldp	q2, q4, [x15, #32]
	and.16b	v6, v0, v4
	and.16b	v13, v1, v2
	ldp	q2, q4, [x15]
	and.16b	v7, v0, v4
	and.16b	v4, v1, v2
	str	x10, [sp, #240]                 ; 8-byte Spill
	add	x10, x13, x10
	ldp	q16, q2, [x10]
	and.16b	v2, v0, v2
	mov	x10, x5
	and.16b	v22, v1, v16
	mov.16b	v17, v5
	mov.16b	v18, v15
	mov.16b	v23, v20
	mov.16b	v14, v19
	mov.16b	v31, v25
	mov.16b	v8, v26
LBB0_102:                               ; %direct.true139
                                        ; =>This Inner Loop Header: Depth=1
	add	x10, x13, x10, lsl #5
	ldp	q16, q24, [x10]
	and.16b	v24, v0, v24
	and.16b	v16, v1, v16
	fmaxnm.4s	v16, v22, v16
	fmaxnm.4s	v24, v2, v24
	ldp	q10, q12, [x10, #32]
	and.16b	v12, v0, v12
	and.16b	v10, v1, v10
	fmaxnm.4s	v10, v4, v10
	fmaxnm.4s	v12, v7, v12
	ldp	q25, q26, [x10, #64]
	and.16b	v26, v0, v26
	and.16b	v25, v1, v25
	fmaxnm.4s	v25, v13, v25
	fmaxnm.4s	v26, v6, v26
	ldp	q27, q28, [x10, #96]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	fmaxnm.4s	v27, v11, v27
	fmaxnm.4s	v28, v9, v28
	dup.2d	v29, x8
	and.16b	v30, v8, v29
	add.2d	v14, v14, v30
	and.16b	v30, v31, v29
	add.2d	v18, v18, v30
	and.16b	v30, v21, v29
	add.2d	v23, v23, v30
	and.16b	v29, v3, v29
	add.2d	v17, v17, v29
	bit.16b	v2, v24, v0
	bit.16b	v22, v16, v1
	bit.16b	v7, v12, v0
	bit.16b	v4, v10, v1
	bit.16b	v6, v26, v0
	bit.16b	v13, v25, v1
	bit.16b	v9, v28, v0
	bit.16b	v11, v27, v1
	fmov	x10, d17
	cmp	x10, #512
	b.lt	LBB0_102
; %bb.103:                              ; %direct.false140
	mov	x8, #0                          ; =0x0
	ldr	q18, [sp, #480]                 ; 16-byte Reload
	zip1.8b	v3, v18, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldp	q17, q21, [sp, #144]            ; 32-byte Folded Reload
	and.16b	v17, v3, v17
	zip2.8b	v18, v18, v0
	ushll.4s	v18, v18, #0
	shl.4s	v18, v18, #31
	cmlt.4s	v18, v18, #0
	and.16b	v21, v18, v21
	fmaxnm.4s	v2, v2, v21
	fmaxnm.4s	v17, v22, v17
	and.16b	v3, v3, v17
	and.16b	v2, v18, v2
	ldr	q18, [sp, #400]                 ; 16-byte Reload
	zip2.8b	v17, v18, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	bit.16b	v2, v24, v17
	zip1.8b	v17, v18, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	bit.16b	v3, v16, v17
	fmaxnm.4s	v3, v3, v4
	fmaxnm.4s	v2, v2, v7
	fmaxnm.4s	v2, v2, v6
	fmaxnm.4s	v3, v3, v13
	fmaxnm.4s	v3, v3, v11
	fmaxnm.4s	v21, v2, v9
	ldp	q2, q7, [sp, #208]              ; 32-byte Folded Reload
	ldr	q4, [sp, #192]                  ; 16-byte Reload
	uzp1.4s	v6, v7, v4
	ldr	q4, [sp, #176]                  ; 16-byte Reload
	uzp1.4s	v7, v4, v2
	movi.4s	v2, #1
	eor.16b	v4, v6, v2
	mov.s	w10, v4[1]
	eor.16b	v10, v7, v2
	mov.s	w11, v4[2]
	mov.s	w12, v4[3]
	fmov	w16, s4
	add	x15, sp, #1352
	bfxil	x15, x16, #0, #3
	ldr	q22, [sp, #464]                 ; 16-byte Reload
	str	d22, [sp, #1352]
	ldrb	w17, [x15]
	umov.b	w15, v22[0]
	and	x16, x16, #0x7
	str	q21, [sp, #2016]
	str	q3, [sp, #2000]
	add	x0, sp, #2000
	ldr	s2, [x0, x16, lsl #2]
	add	x23, sp, #1352
	ands	w22, w15, #0x1
	tst	w22, w17
	movi.2d	v4, #0000000000000000
	fcsel	s24, s2, s4, ne
	and	x16, x10, #0x7
	add	x17, sp, #1352
	bfxil	x17, x10, #0, #3
	ldrb	w10, [x17]
	umov.b	w2, v22[1]
	and	w10, w2, w10
	str	q21, [sp, #1984]
	str	q3, [sp, #1968]
	add	x17, sp, #1968
	ldr	s2, [x17, x16, lsl #2]
	tst	w10, #0x1
	fcsel	s9, s2, s4, ne
	and	x10, x11, #0x7
	add	x16, sp, #1352
	bfxil	x16, x11, #0, #3
	umov.b	w3, v22[2]
	ldrb	w11, [x16]
	str	q21, [sp, #1952]
	str	q3, [sp, #1936]
	add	x16, sp, #1936
	ldr	s2, [x16, x10, lsl #2]
	and	w10, w3, w11
	tst	w10, #0x1
	fcsel	s11, s2, s4, ne
	and	x10, x12, #0x7
	add	x11, sp, #1352
	bfxil	x11, x12, #0, #3
	ldrb	w11, [x11]
	umov.b	w4, v22[3]
	and	w11, w4, w11
	str	q21, [sp, #1920]
	str	q3, [sp, #1904]
	add	x12, sp, #1904
	ldr	s2, [x12, x10, lsl #2]
	tst	w11, #0x1
	mov.s	w10, v10[1]
	fcsel	s2, s2, s4, ne
	mov.s	w11, v10[2]
	mov.s	w12, v10[3]
	fmov	w16, s10
	and	x17, x16, #0x7
	add	x0, sp, #1352
	bfxil	x0, x16, #0, #3
	ldrb	w16, [x0]
	umov.b	w20, v22[4]
	and	w16, w20, w16
	str	q21, [sp, #2144]
	str	q3, [sp, #2128]
	add	x0, sp, #2128
	ldr	s16, [x0, x17, lsl #2]
	tst	w16, #0x1
	fcsel	s16, s16, s4, ne
	and	x16, x10, #0x7
	add	x17, sp, #1352
	bfxil	x17, x10, #0, #3
	ldrb	w10, [x17]
	umov.b	w19, v22[5]
	and	w10, w19, w10
	str	q21, [sp, #2112]
	str	q3, [sp, #2096]
	add	x17, sp, #2096
	ldr	s17, [x17, x16, lsl #2]
	tst	w10, #0x1
	fcsel	s17, s17, s4, ne
	and	x10, x11, #0x7
	add	x16, sp, #1352
	bfxil	x16, x11, #0, #3
	ldrb	w11, [x16]
	umov.b	w6, v22[6]
	and	w11, w6, w11
	str	q21, [sp, #2080]
	str	q3, [sp, #2064]
	add	x16, sp, #2064
	ldr	s18, [x16, x10, lsl #2]
	tst	w11, #0x1
	fcsel	s18, s18, s4, ne
	and	x10, x12, #0x7
	add	x11, sp, #1352
	bfxil	x11, x12, #0, #3
	ldrb	w11, [x11]
	umov.b	w7, v22[7]
	and	w11, w7, w11
	str	q21, [sp, #2048]
	str	q3, [sp, #2032]
	add	x12, sp, #2032
	ldr	s22, [x12, x10, lsl #2]
	tst	w11, #0x1
	fcsel	s22, s22, s4, ne
	mov.s	v16[1], v17[0]
	mov.s	v16[2], v18[0]
	mov.s	v16[3], v22[0]
	mov.s	v24[1], v9[0]
	mov.s	v24[2], v11[0]
	mov.s	v24[3], v2[0]
	fmaxnm.4s	v3, v3, v24
	fmaxnm.4s	v21, v21, v16
	movi.4s	v2, #2
	eor.16b	v16, v6, v2
	mov.s	w10, v16[1]
	mov.s	w11, v16[2]
	mov.s	w12, v16[3]
	eor.16b	v2, v7, v2
	fmov	w16, s16
	add	x17, sp, #1352
	bfxil	x17, x16, #0, #3
	ldrb	w17, [x17]
	and	x16, x16, #0x7
	str	q21, [sp, #1888]
	str	q3, [sp, #1872]
	add	x0, sp, #1872
	ldr	s7, [x0, x16, lsl #2]
	tst	w22, w17
	fcsel	s7, s7, s4, ne
	and	x16, x10, #0x7
	add	x17, sp, #1352
	bfxil	x17, x10, #0, #3
	ldrb	w10, [x17]
	and	w10, w2, w10
	str	q21, [sp, #1856]
	str	q3, [sp, #1840]
	add	x17, sp, #1840
	ldr	s16, [x17, x16, lsl #2]
	tst	w10, #0x1
	fcsel	s24, s16, s4, ne
	and	x10, x11, #0x7
	add	x16, sp, #1352
	bfxil	x16, x11, #0, #3
	ldrb	w11, [x16]
	and	w11, w3, w11
	str	q21, [sp, #1824]
	str	q3, [sp, #1808]
	add	x16, sp, #1808
	ldr	s16, [x16, x10, lsl #2]
	tst	w11, #0x1
	fcsel	s9, s16, s4, ne
	and	x10, x12, #0x7
	add	x11, sp, #1352
	bfxil	x11, x12, #0, #3
	ldrb	w11, [x11]
	and	w11, w4, w11
	str	q21, [sp, #1792]
	str	q3, [sp, #1776]
	add	x12, sp, #1776
	ldr	s16, [x12, x10, lsl #2]
	tst	w11, #0x1
	mov.s	w10, v2[3]
	mov.s	w25, v2[1]
	mov.s	w26, v2[2]
	fcsel	s16, s16, s4, ne
	fmov	w11, s2
	and	x27, x11, #0x7
	add	x28, sp, #1352
	bfxil	x28, x11, #0, #3
	add	x11, sp, #1352
	bfxil	x11, x10, #0, #3
	ldrb	w30, [x11]
	movi.4s	v2, #4
	eor.16b	v2, v6, v2
	mov.s	w0, v2[1]
	mov.s	w12, v2[2]
	mov.s	w11, v2[3]
	fmov	w24, s2
	add	x16, sp, #1352
	bfxil	x16, x24, #0, #3
	ldrb	w1, [x16]
	add	x16, sp, #1352
	bfxil	x16, x0, #0, #3
	ldrb	w21, [x16]
	add	x16, sp, #1352
	bfxil	x16, x12, #0, #3
	ldrb	w17, [x16]
	add	x16, sp, #1352
	bfxil	x16, x11, #0, #3
	ldrb	w16, [x16]
	ldrb	w28, [x28]
	and	w28, w20, w28
	str	q21, [sp, #1760]
	str	q3, [sp, #1744]
	add	x14, sp, #1744
	ldr	s2, [x14, x27, lsl #2]
	tst	w28, #0x1
	fcsel	s2, s2, s4, ne
	and	x14, x25, #0x7
	add	x27, sp, #1352
	bfxil	x27, x25, #0, #3
	ldrb	w25, [x27]
	and	w25, w19, w25
	str	q21, [sp, #1728]
	str	q3, [sp, #1712]
	add	x27, sp, #1712
	ldr	s6, [x27, x14, lsl #2]
	tst	w25, #0x1
	fcsel	s6, s6, s4, ne
	and	x14, x26, #0x7
	bfxil	x23, x26, #0, #3
	ldrb	w23, [x23]
	and	w23, w6, w23
	str	q21, [sp, #1696]
	str	q3, [sp, #1680]
	add	x25, sp, #1680
	ldr	s17, [x25, x14, lsl #2]
	tst	w23, #0x1
	fcsel	s17, s17, s4, ne
	and	x10, x10, #0x7
	and	w14, w7, w30
	str	q21, [sp, #1664]
	str	q3, [sp, #1648]
	add	x23, sp, #1648
	ldr	s18, [x23, x10, lsl #2]
	tst	w14, #0x1
	fcsel	s18, s18, s4, ne
	mov.s	v2[1], v6[0]
	mov.s	v2[2], v17[0]
	mov.s	v2[3], v18[0]
	mov.s	v7[1], v24[0]
	mov.s	v7[2], v9[0]
	mov.s	v7[3], v16[0]
	fmaxnm.4s	v3, v3, v7
	fmaxnm.4s	v2, v21, v2
	and	x10, x24, #0x7
	str	q2, [sp, #1632]
	str	q3, [sp, #1616]
	add	x14, sp, #1616
	ldr	s6, [x14, x10, lsl #2]
	tst	w22, w1
	fcsel	s6, s6, s4, ne
	and	x10, x0, #0x7
	and	w14, w2, w21
	str	q2, [sp, #1600]
	str	q3, [sp, #1584]
	add	x0, sp, #1584
	ldr	s7, [x0, x10, lsl #2]
	tst	w14, #0x1
	fcsel	s7, s7, s4, ne
	and	x10, x12, #0x7
	str	q2, [sp, #1568]
	str	q3, [sp, #1552]
	add	x12, sp, #1552
	ldr	s16, [x12, x10, lsl #2]
	and	w10, w3, w17
	tst	w10, #0x1
	fcsel	s16, s16, s4, ne
	and	x10, x11, #0x7
	and	w11, w4, w16
	str	q2, [sp, #1536]
	str	q3, [sp, #1520]
	add	x12, sp, #1520
	ldr	s2, [x12, x10, lsl #2]
	tst	w11, #0x1
	fcsel	s2, s2, s4, ne
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v16[0]
	mov.s	v6[3], v2[0]
	ands	w24, w15, #0x1
	fmaxnm.4s	v2, v3, v6
	fcsel	s3, s2, s4, ne
	and	w11, w2, w15
	and	w10, w2, w15
	str	w10, [sp, #224]                 ; 4-byte Spill
	tst	w11, #0x1
	fcsel	s6, s2, s4, ne
	and	w11, w3, w15
	and	w10, w3, w15
	str	w10, [sp, #208]                 ; 4-byte Spill
	tst	w11, #0x1
	fcsel	s7, s2, s4, ne
	and	w11, w4, w15
	and	w10, w4, w15
	str	w10, [sp, #192]                 ; 4-byte Spill
	tst	w11, #0x1
	fcsel	s16, s2, s4, ne
	and	w11, w20, w15
	and	w10, w20, w15
	str	w10, [sp, #176]                 ; 4-byte Spill
	tst	w11, #0x1
	fcsel	s17, s2, s4, ne
	and	w27, w19, w15
	tst	w27, #0x1
	fcsel	s18, s2, s4, ne
	and	w28, w6, w15
	tst	w28, #0x1
	fcsel	s21, s2, s4, ne
	and	w30, w7, w15
	tst	w30, #0x1
	fcsel	s2, s2, s4, ne
	mov.s	v3[1], v6[0]
	mov.s	v3[2], v7[0]
	mov.s	v3[3], v16[0]
	mov.s	v17[1], v18[0]
	mov.s	v17[2], v21[0]
	mov.s	v17[3], v2[0]
	ldr	w10, [sp, #276]                 ; 4-byte Reload
	rbit	w10, w10
	clz	w14, w10
	str	q17, [sp, #1376]
	str	q3, [sp, #1360]
	and	x10, x14, #0x7
	add	x11, sp, #1360
	ldr	s2, [x11, x10, lsl #2]
	mov	w10, #-8388608                  ; =0xff800000
	fmov	s3, w10
	fmaxnm	s2, s2, s3
	dup.4s	v24, v2[0]
	movi.2d	v4, #0000000000000000
	mov	w16, #-1026555904               ; =0xc2d00000
	mov	w17, #1120403456                ; =0x42c80000
	mov	w0, #43579                      ; =0xaa3b
	movk	w0, #16312, lsl #16
	movi.4s	v6, #75, lsl #24
	mvni.4s	v7, #128, lsl #24
	mov	w1, #29184                      ; =0x7200
	movk	w1, #48945, lsl #16
	mov	w21, #48782                     ; =0xbe8e
	movk	w21, #46527, lsl #16
	mov	w12, #11226                     ; =0x2bda
	movk	w12, #14672, lsl #16
	mov	w10, #38601                     ; =0x96c9
	movk	w10, #15030, lsl #16
	mov	w11, #34982                     ; =0x88a6
	movk	w11, #15368, lsl #16
	mov	w22, #43642                     ; =0xaa7a
	movk	w22, #15658, lsl #16
	mov	w23, #43691                     ; =0xaaab
	movk	w23, #15914, lsl #16
	movi.4s	v10, #63, lsl #24
	fmov.4s	v11, #1.00000000
	mvni.4s	v2, #127, msl #16
	fneg.4s	v12, v2
	mvni.4s	v2, #63, msl #16
	fneg.4s	v13, v2
	movi.2d	v9, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v3, #0000000000000000
	ldr	q8, [sp, #256]                  ; 16-byte Reload
	b	LBB0_105
LBB0_104:                               ; %else253
                                        ;   in Loop: Header=BB0_105 Depth=1
	cmeq.8b	v2, v2, #0
	sshll.8h	v16, v2, #0
	sshll2.4s	v2, v16, #0
	sshll.4s	v22, v16, #0
	lsl	x8, x8, #5
	add	x25, x13, x8
	ldp	q17, q16, [x25]
	fsub.4s	v17, v17, v24
	fsub.4s	v16, v16, v24
	and.16b	v23, v0, v16
	and.16b	v16, v1, v17
	dup.4s	v17, w16
	fcmge.4s	v25, v16, v17
	dup.4s	v18, w17
	fcmge.4s	v26, v23, v17
	fcmge.4s	v27, v18, v16
	fcmge.4s	v28, v18, v23
	and.16b	v26, v26, v28
	and.16b	v25, v25, v27
	and.16b	v25, v25, v16
	and.16b	v26, v26, v23
	dup.4s	v27, w0
	fmul.4s	v28, v26, v27
	fmul.4s	v27, v25, v27
	mov.16b	v29, v7
	bsl.16b	v29, v6, v27
	mov.16b	v30, v7
	bsl.16b	v30, v6, v28
	fadd.4s	v28, v28, v30
	fadd.4s	v27, v27, v29
	fsub.4s	v27, v27, v29
	fsub.4s	v28, v28, v30
	fcvtzs.4s	v28, v28
	fcvtzs.4s	v27, v27
	scvtf.4s	v29, v27
	scvtf.4s	v30, v28
	dup.4s	v14, w1
	fmul.4s	v31, v30, v14
	fmul.4s	v14, v29, v14
	fadd.4s	v25, v25, v14
	fadd.4s	v26, v26, v31
	dup.4s	v31, w21
	fmul.4s	v29, v29, v31
	fmul.4s	v30, v30, v31
	fadd.4s	v26, v26, v30
	fadd.4s	v25, v25, v29
	dup.4s	v29, w12
	fmul.4s	v30, v25, v29
	fmul.4s	v29, v26, v29
	dup.4s	v31, w10
	fadd.4s	v29, v29, v31
	fadd.4s	v30, v30, v31
	fmul.4s	v30, v25, v30
	fmul.4s	v29, v26, v29
	dup.4s	v31, w11
	fadd.4s	v29, v29, v31
	fadd.4s	v30, v30, v31
	fmul.4s	v30, v25, v30
	fmul.4s	v29, v26, v29
	dup.4s	v31, w22
	fadd.4s	v29, v29, v31
	fadd.4s	v30, v30, v31
	fmul.4s	v30, v25, v30
	fmul.4s	v29, v26, v29
	dup.4s	v31, w23
	fadd.4s	v29, v29, v31
	fadd.4s	v30, v30, v31
	fmul.4s	v30, v25, v30
	fmul.4s	v29, v26, v29
	fadd.4s	v29, v29, v10
	fadd.4s	v30, v30, v10
	fmul.4s	v31, v26, v26
	fmul.4s	v14, v25, v25
	fmul.4s	v30, v14, v30
	fmul.4s	v29, v31, v29
	fadd.4s	v26, v26, v29
	fadd.4s	v25, v25, v30
	fadd.4s	v25, v25, v11
	fadd.4s	v26, v26, v11
	sshr.4s	v29, v27, #1
	sshr.4s	v30, v28, #1
	shl.4s	v31, v30, #23
	shl.4s	v14, v29, #23
	add.4s	v14, v14, v11
	add.4s	v31, v31, v11
	fmul.4s	v26, v26, v31
	fmul.4s	v25, v25, v14
	sub.4s	v28, v28, v30
	sub.4s	v27, v27, v29
	shl.4s	v27, v27, #23
	shl.4s	v28, v28, #23
	add.4s	v28, v28, v11
	add.4s	v27, v27, v11
	fmul.4s	v25, v25, v27
	fmul.4s	v26, v26, v28
	fcmgt.4s	v27, v17, v23
	bic.16b	v26, v26, v27
	fcmgt.4s	v17, v17, v16
	bic.16b	v17, v25, v17
	fcmgt.4s	v25, v23, v18
	fcmgt.4s	v18, v16, v18
	bit.16b	v17, v12, v18
	mov.16b	v18, v25
	bsl.16b	v18, v12, v26
	fcmeq.4s	v16, v16, v16
	fcmeq.4s	v23, v23, v23
	bif.16b	v18, v13, v23
	bsl.16b	v16, v17, v13
	bic.16b	v16, v16, v22
	bic.16b	v2, v18, v2
	add	x8, x9, x8
	ldp	q17, q18, [x8]
	bif.16b	v2, v18, v0
	bif.16b	v16, v17, v1
	stp	q16, q2, [x8]
	ldr	q2, [sp, #640]                  ; 16-byte Reload
	add.2d	v9, v9, v2
	ldr	q2, [sp, #672]                  ; 16-byte Reload
	add.2d	v21, v21, v2
	ldr	q2, [sp, #656]                  ; 16-byte Reload
	add.2d	v3, v3, v2
	ldr	q2, [sp, #624]                  ; 16-byte Reload
	add.2d	v4, v4, v2
	fmov	x8, d4
	cmp	x8, #512
	b.ge	LBB0_121
LBB0_105:                               ; %direct.true174
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q2, [sp, #608]                  ; 16-byte Reload
	fmov	w25, s2
	ldr	q2, [sp, #528]                  ; 16-byte Reload
	add.2d	v2, v4, v2
	ldr	q16, [sp, #560]                 ; 16-byte Reload
	add.2d	v16, v16, v2
	tbz	w25, #0, LBB0_114
; %bb.106:                              ; %cond.load207
                                        ;   in Loop: Header=BB0_105 Depth=1
	fmov	x26, d16
	ldr	b2, [x26]
	ldp	q18, q17, [sp, #576]            ; 32-byte Folded Reload
	ldr	q22, [sp, #544]                 ; 16-byte Reload
	ldr	q23, [sp, #496]                 ; 16-byte Reload
	and	w25, w25, #0xff
	tbz	w25, #1, LBB0_108
LBB0_107:                               ; %cond.load213
                                        ;   in Loop: Header=BB0_105 Depth=1
	mov.d	x26, v16[1]
	ld1.b	{ v2 }[1], [x26]
LBB0_108:                               ; %else217
                                        ;   in Loop: Header=BB0_105 Depth=1
	add.2d	v16, v9, v23
	add.2d	v16, v17, v16
	tbnz	w25, #2, LBB0_115
; %bb.109:                              ; %else223
                                        ;   in Loop: Header=BB0_105 Depth=1
	tbnz	w25, #3, LBB0_116
LBB0_110:                               ; %else229
                                        ;   in Loop: Header=BB0_105 Depth=1
	add.2d	v16, v21, v22
	add.2d	v16, v18, v16
	tbnz	w25, #4, LBB0_117
LBB0_111:                               ; %else235
                                        ;   in Loop: Header=BB0_105 Depth=1
	tbnz	w25, #5, LBB0_118
LBB0_112:                               ; %else241
                                        ;   in Loop: Header=BB0_105 Depth=1
	ldr	q16, [sp, #512]                 ; 16-byte Reload
	add.2d	v16, v3, v16
	add.2d	v16, v8, v16
	tbnz	w25, #6, LBB0_119
LBB0_113:                               ; %else247
                                        ;   in Loop: Header=BB0_105 Depth=1
	tbz	w25, #7, LBB0_104
	b	LBB0_120
LBB0_114:                               ;   in Loop: Header=BB0_105 Depth=1
	movi.2d	v2, #0000000000000000
	ldp	q18, q17, [sp, #576]            ; 32-byte Folded Reload
	ldr	q22, [sp, #544]                 ; 16-byte Reload
	ldr	q23, [sp, #496]                 ; 16-byte Reload
	and	w25, w25, #0xff
	tbnz	w25, #1, LBB0_107
	b	LBB0_108
LBB0_115:                               ; %cond.load219
                                        ;   in Loop: Header=BB0_105 Depth=1
	fmov	x26, d16
	ld1.b	{ v2 }[2], [x26]
	tbz	w25, #3, LBB0_110
LBB0_116:                               ; %cond.load225
                                        ;   in Loop: Header=BB0_105 Depth=1
	mov.d	x26, v16[1]
	ld1.b	{ v2 }[3], [x26]
	add.2d	v16, v21, v22
	add.2d	v16, v18, v16
	tbz	w25, #4, LBB0_111
LBB0_117:                               ; %cond.load231
                                        ;   in Loop: Header=BB0_105 Depth=1
	fmov	x26, d16
	ld1.b	{ v2 }[4], [x26]
	tbz	w25, #5, LBB0_112
LBB0_118:                               ; %cond.load237
                                        ;   in Loop: Header=BB0_105 Depth=1
	mov.d	x26, v16[1]
	ld1.b	{ v2 }[5], [x26]
	ldr	q16, [sp, #512]                 ; 16-byte Reload
	add.2d	v16, v3, v16
	add.2d	v16, v8, v16
	tbz	w25, #6, LBB0_113
LBB0_119:                               ; %cond.load243
                                        ;   in Loop: Header=BB0_105 Depth=1
	fmov	x26, d16
	ld1.b	{ v2 }[6], [x26]
	tbz	w25, #7, LBB0_104
LBB0_120:                               ; %cond.load249
                                        ;   in Loop: Header=BB0_105 Depth=1
	mov.d	x25, v16[1]
	ld1.b	{ v2 }[7], [x25]
	b	LBB0_104
LBB0_121:                               ; %direct.true215.preheader
	ldr	d2, [sp, #456]                  ; 8-byte Reload
	fmov	w8, s2
	tbz	w8, #0, LBB0_127
; %bb.122:                              ; %cond.load256
	ldr	q2, [sp, #16]                   ; 16-byte Reload
	fmov	x10, d2
	ldr	b3, [x10]
	ldr	x1, [sp, #360]                  ; 8-byte Reload
	tbnz	w8, #1, LBB0_128
	b	LBB0_129
LBB0_123:                               ; %cond.load170
	fmov	x10, d18
	ld1.b	{ v2 }[2], [x10]
	tbz	w8, #3, LBB0_95
LBB0_124:                               ; %cond.load176
	ld1.b	{ v2 }[3], [x0]
	tbz	w8, #4, LBB0_96
LBB0_125:                               ; %cond.load182
	fmov	x10, d17
	ld1.b	{ v2 }[4], [x10]
	tbz	w8, #5, LBB0_97
LBB0_126:                               ; %cond.load188
	ld1.b	{ v2 }[5], [x17]
	tbnz	w8, #6, LBB0_98
	b	LBB0_99
LBB0_127:
	movi.2d	v3, #0000000000000000
	ldr	x1, [sp, #360]                  ; 8-byte Reload
	tbz	w8, #1, LBB0_129
LBB0_128:                               ; %cond.load262
	ldr	x10, [sp, #40]                  ; 8-byte Reload
	ld1.b	{ v3 }[1], [x10]
LBB0_129:                               ; %else266
	tbnz	w8, #2, LBB0_167
; %bb.130:                              ; %else272
	tbnz	w8, #3, LBB0_168
LBB0_131:                               ; %else278
	tbnz	w8, #4, LBB0_169
LBB0_132:                               ; %else284
	tbnz	w8, #5, LBB0_170
LBB0_133:                               ; %else290
	adrp	x10, lCPI0_20@PAGE
	adrp	x11, lCPI0_21@PAGE
	adrp	x12, lCPI0_22@PAGE
	adrp	x16, lCPI0_23@PAGE
	adrp	x17, lCPI0_24@PAGE
	tbnz	w8, #6, LBB0_171
LBB0_134:                               ; %else296
	ldr	q2, [x10, lCPI0_20@PAGEOFF]
	ldr	q4, [x11, lCPI0_21@PAGEOFF]
	ldr	q6, [x12, lCPI0_22@PAGEOFF]
	ldr	q7, [x16, lCPI0_23@PAGEOFF]
	ldr	q16, [x17, lCPI0_24@PAGEOFF]
	tbz	w8, #7, LBB0_136
LBB0_135:                               ; %cond.load298
	ldr	x8, [sp, #136]                  ; 8-byte Reload
	ld1.b	{ v3 }[7], [x8]
LBB0_136:                               ; %else302
	and.16b	v25, v0, v2
	and.16b	v26, v1, v4
	and.16b	v4, v0, v6
	and.16b	v2, v1, v7
	stp	q2, q4, [sp, #560]              ; 32-byte Folded Spill
	and.16b	v2, v1, v16
	str	q2, [sp, #592]                  ; 16-byte Spill
	cmeq.8b	v2, v3, #0
	sshll.8h	v2, v2, #0
	sshll2.4s	v3, v2, #0
	sshll.4s	v21, v2, #0
	add	x8, x13, x1
	ldp	q16, q2, [x8]
	fsub.4s	v16, v16, v24
	fsub.4s	v2, v2, v24
	ldr	q4, [sp, #480]                  ; 16-byte Reload
	zip2.8b	v17, v4, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v24, v17, #0
	and.16b	v28, v24, v2
	zip1.8b	v2, v4, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v27, v2, #0
	and.16b	v29, v27, v16
	mov	w8, #-1026555904                ; =0xc2d00000
	dup.4s	v2, w8
	fcmge.4s	v16, v29, v2
	fcmge.4s	v17, v28, v2
	mov	w8, #1120403456                 ; =0x42c80000
	dup.4s	v22, w8
	fcmge.4s	v18, v22, v29
	fcmge.4s	v23, v22, v28
	and.16b	v17, v17, v23
	and.16b	v16, v16, v18
	and.16b	v18, v16, v29
	and.16b	v23, v17, v28
	mov	w8, #43579                      ; =0xaa3b
	movk	w8, #16312, lsl #16
	dup.4s	v16, w8
	fmul.4s	v17, v23, v16
	fmul.4s	v16, v18, v16
	movi.4s	v30, #75, lsl #24
	mvni.4s	v31, #128, lsl #24
	mov.16b	v8, v31
	bsl.16b	v8, v30, v16
	bif.16b	v30, v17, v31
	fadd.4s	v17, v17, v30
	fadd.4s	v16, v16, v8
	fsub.4s	v31, v16, v8
	fsub.4s	v16, v17, v30
	fcvtzs.4s	v16, v16
	fcvtzs.4s	v17, v31
	scvtf.4s	v30, v17
	scvtf.4s	v31, v16
	mov	w8, #29184                      ; =0x7200
	movk	w8, #48945, lsl #16
	dup.4s	v8, w8
	fmul.4s	v9, v31, v8
	fmul.4s	v8, v30, v8
	fadd.4s	v18, v18, v8
	fadd.4s	v23, v23, v9
	mov	w8, #48782                      ; =0xbe8e
	movk	w8, #46527, lsl #16
	dup.4s	v8, w8
	fmul.4s	v30, v30, v8
	fmul.4s	v31, v31, v8
	fadd.4s	v23, v23, v31
	mov	w8, #11226                      ; =0x2bda
	movk	w8, #14672, lsl #16
	dup.4s	v31, w8
	fadd.4s	v18, v18, v30
	fmul.4s	v30, v18, v31
	fmul.4s	v31, v23, v31
	mov	w8, #38601                      ; =0x96c9
	movk	w8, #15030, lsl #16
	dup.4s	v8, w8
	fadd.4s	v31, v31, v8
	fadd.4s	v30, v30, v8
	fmul.4s	v30, v18, v30
	mov	w8, #34982                      ; =0x88a6
	movk	w8, #15368, lsl #16
	dup.4s	v8, w8
	fmul.4s	v31, v23, v31
	fadd.4s	v31, v31, v8
	fadd.4s	v30, v30, v8
	fmul.4s	v30, v18, v30
	fmul.4s	v31, v23, v31
	mov	w8, #43642                      ; =0xaa7a
	movk	w8, #15658, lsl #16
	dup.4s	v8, w8
	fadd.4s	v31, v31, v8
	fadd.4s	v30, v30, v8
	fmul.4s	v30, v18, v30
	fmul.4s	v31, v23, v31
	mov	w8, #43691                      ; =0xaaab
	movk	w8, #15914, lsl #16
	dup.4s	v8, w8
	fadd.4s	v31, v31, v8
	fadd.4s	v30, v30, v8
	fmul.4s	v30, v18, v30
	fmul.4s	v31, v23, v31
	movi.4s	v8, #63, lsl #24
	fadd.4s	v31, v31, v8
	fadd.4s	v30, v30, v8
	fmul.4s	v8, v23, v23
	fmul.4s	v9, v18, v18
	fmul.4s	v30, v9, v30
	fmul.4s	v31, v8, v31
	fadd.4s	v23, v23, v31
	fadd.4s	v18, v18, v30
	fmov.4s	v30, #1.00000000
	fadd.4s	v18, v18, v30
	fadd.4s	v23, v23, v30
	sshr.4s	v31, v17, #1
	sshr.4s	v8, v16, #1
	shl.4s	v9, v8, #23
	shl.4s	v10, v31, #23
	add.4s	v10, v10, v30
	add.4s	v9, v9, v30
	fmul.4s	v23, v23, v9
	fmul.4s	v18, v18, v10
	sub.4s	v16, v16, v8
	sub.4s	v17, v17, v31
	shl.4s	v17, v17, #23
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v30
	add.4s	v17, v17, v30
	fmul.4s	v17, v18, v17
	fmul.4s	v16, v23, v16
	fcmgt.4s	v18, v2, v28
	bic.16b	v16, v16, v18
	fcmgt.4s	v2, v2, v29
	bic.16b	v2, v17, v2
	fcmgt.4s	v17, v28, v22
	fcmgt.4s	v18, v29, v22
	mvni.4s	v22, #127, msl #16
	fneg.4s	v22, v22
	bit.16b	v2, v22, v18
	bit.16b	v16, v22, v17
	fcmeq.4s	v17, v29, v29
	fcmeq.4s	v18, v28, v28
	mvni.4s	v22, #63, msl #16
	fneg.4s	v22, v22
	bif.16b	v16, v22, v18
	bif.16b	v2, v22, v17
	bic.16b	v30, v2, v21
	bic.16b	v31, v16, v3
	add	x8, x9, x1
	ldp	q2, q3, [x8]
	bit.16b	v3, v31, v24
	bit.16b	v2, v30, v27
	stp	q2, q3, [x8]
	ldr	x8, [sp, #280]                  ; 8-byte Reload
	ldp	q2, q3, [x8, #64]
	and.16b	v21, v0, v3
	and.16b	v3, v1, v2
	ldp	q2, q16, [x8, #32]
	and.16b	v27, v0, v16
	and.16b	v24, v1, v2
	ldp	q2, q16, [x8]
	and.16b	v28, v0, v16
	and.16b	v29, v1, v2
	ldr	x8, [sp, #240]                  ; 8-byte Reload
	add	x8, x9, x8
	ldp	q2, q16, [x8]
	and.16b	v16, v0, v16
	and.16b	v2, v1, v2
	mov	w8, #4                          ; =0x4
	ldp	q7, q6, [sp, #416]              ; 32-byte Folded Reload
LBB0_137:                               ; %direct.true215
                                        ; =>This Inner Loop Header: Depth=1
	sshll.2d	v22, v1, #0
	sshll.2d	v23, v0, #0
	add	x10, x9, x5, lsl #5
	ldp	q17, q18, [x10]
	fadd.4s	v17, v2, v17
	fadd.4s	v18, v16, v18
	ldp	q9, q8, [x10, #32]
	fadd.4s	v9, v29, v9
	fadd.4s	v8, v28, v8
	ldp	q11, q10, [x10, #64]
	fadd.4s	v11, v24, v11
	fadd.4s	v10, v27, v10
	ldp	q13, q12, [x10, #96]
	fadd.4s	v13, v3, v13
	fadd.4s	v12, v21, v12
	dup.2d	v14, x8
	and.16b	v4, v7, v14
	add.2d	v19, v19, v4
	and.16b	v4, v6, v14
	add.2d	v15, v15, v4
	and.16b	v4, v23, v14
	add.2d	v20, v20, v4
	and.16b	v4, v22, v14
	add.2d	v5, v5, v4
	bit.16b	v16, v18, v0
	bit.16b	v2, v17, v1
	bit.16b	v28, v8, v0
	bit.16b	v29, v9, v1
	bit.16b	v27, v10, v0
	bit.16b	v24, v11, v1
	bit.16b	v21, v12, v0
	bit.16b	v3, v13, v1
	fmov	x5, d5
	cmp	x5, #512
	b.lt	LBB0_137
; %bb.138:                              ; %direct.false216
	mov	x8, #0                          ; =0x0
	fadd.4s	v4, v31, v16
	fadd.4s	v2, v30, v2
	ldr	q16, [sp, #480]                 ; 16-byte Reload
	zip1.8b	v5, v16, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	and.16b	v2, v5, v2
	zip2.8b	v5, v16, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	and.16b	v4, v5, v4
	ldr	q6, [sp, #400]                  ; 16-byte Reload
	zip2.8b	v5, v6, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	bit.16b	v4, v18, v5
	zip1.8b	v5, v6, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	bit.16b	v2, v17, v5
	fadd.4s	v2, v29, v2
	fadd.4s	v4, v28, v4
	fadd.4s	v4, v27, v4
	fadd.4s	v2, v24, v2
	fadd.4s	v3, v3, v2
	fadd.4s	v20, v21, v4
	fmov	w10, s26
	add	x11, sp, #760
	bfxil	x11, x10, #0, #3
	ldr	q2, [sp, #464]                  ; 16-byte Reload
	str	d2, [sp, #760]
	ldrb	w11, [x11]
	and	x10, x10, #0x7
	str	q20, [sp, #1200]
	str	q3, [sp, #1184]
	add	x12, sp, #1184
	ldr	s2, [x12, x10, lsl #2]
	tst	w24, w11
	movi.2d	v5, #0000000000000000
	fcsel	s21, s2, s5, ne
	mov.s	w10, v26[1]
	and	x11, x10, #0x7
	add	x12, sp, #760
	bfxil	x12, x10, #0, #3
	ldrb	w10, [x12]
	and	w10, w2, w10
	str	q20, [sp, #1168]
	str	q3, [sp, #1152]
	add	x12, sp, #1152
	ldr	s2, [x12, x11, lsl #2]
	tst	w10, #0x1
	mov.s	w10, v26[2]
	fcsel	s2, s2, s5, ne
	and	x11, x10, #0x7
	add	x12, sp, #760
	bfxil	x12, x10, #0, #3
	ldrb	w10, [x12]
	and	w10, w3, w10
	str	q20, [sp, #1136]
	str	q3, [sp, #1120]
	add	x12, sp, #1120
	ldr	s4, [x12, x11, lsl #2]
	tst	w10, #0x1
	fcsel	s16, s4, s5, ne
	mov.s	w10, v26[3]
	and	x11, x10, #0x7
	add	x12, sp, #760
	bfxil	x12, x10, #0, #3
	ldrb	w10, [x12]
	str	q20, [sp, #1104]
	str	q3, [sp, #1088]
	add	x12, sp, #1088
	ldr	s4, [x12, x11, lsl #2]
	and	w10, w4, w10
	tst	w10, #0x1
	fcsel	s17, s4, s5, ne
	fmov	w10, s25
	and	x11, x10, #0x7
	add	x12, sp, #760
	bfxil	x12, x10, #0, #3
	ldrb	w10, [x12]
	and	w10, w20, w10
	str	q20, [sp, #1328]
	str	q3, [sp, #1312]
	add	x12, sp, #1312
	ldr	s4, [x12, x11, lsl #2]
	tst	w10, #0x1
	fcsel	s4, s4, s5, ne
	mov.s	w10, v25[1]
	and	x11, x10, #0x7
	add	x12, sp, #760
	bfxil	x12, x10, #0, #3
	ldrb	w10, [x12]
	and	w10, w19, w10
	str	q20, [sp, #1296]
	str	q3, [sp, #1280]
	add	x12, sp, #1280
	ldr	s18, [x12, x11, lsl #2]
	tst	w10, #0x1
	fcsel	s18, s18, s5, ne
	mov.s	w10, v25[2]
	and	x11, x10, #0x7
	add	x12, sp, #760
	bfxil	x12, x10, #0, #3
	ldrb	w10, [x12]
	and	w10, w6, w10
	str	q20, [sp, #1264]
	str	q3, [sp, #1248]
	add	x12, sp, #1248
	ldr	s19, [x12, x11, lsl #2]
	tst	w10, #0x1
	fcsel	s19, s19, s5, ne
	mov.s	w10, v25[3]
	and	x11, x10, #0x7
	add	x12, sp, #760
	bfxil	x12, x10, #0, #3
	ldrb	w10, [x12]
	and	w10, w7, w10
	str	q20, [sp, #1232]
	str	q3, [sp, #1216]
	add	x12, sp, #1216
	ldr	s22, [x12, x11, lsl #2]
	tst	w10, #0x1
	fcsel	s22, s22, s5, ne
	mov.s	v4[1], v18[0]
	mov.s	v4[2], v19[0]
	mov.s	v4[3], v22[0]
	mov.s	v21[1], v2[0]
	mov.s	v21[2], v16[0]
	mov.s	v21[3], v17[0]
	fadd.4s	v3, v3, v21
	fadd.4s	v20, v20, v4
	ldr	q6, [sp, #560]                  ; 16-byte Reload
	fmov	w10, s6
	add	x11, sp, #760
	bfxil	x11, x10, #0, #3
	ldrb	w11, [x11]
	and	x10, x10, #0x7
	stp	q3, q20, [sp, #928]
	add	x12, sp, #928
	ldr	s2, [x12, x10, lsl #2]
	tst	w24, w11
	fcsel	s21, s2, s5, ne
	mov.s	w10, v6[1]
	and	x11, x10, #0x7
	add	x12, sp, #760
	bfxil	x12, x10, #0, #3
	ldrb	w10, [x12]
	stp	q3, q20, [sp, #896]
	add	x12, sp, #896
	ldr	s2, [x12, x11, lsl #2]
	and	w10, w2, w10
	tst	w10, #0x1
	fcsel	s2, s2, s5, ne
	mov.s	w10, v6[2]
	and	x11, x10, #0x7
	add	x12, sp, #760
	bfxil	x12, x10, #0, #3
	ldrb	w10, [x12]
	and	w10, w3, w10
	stp	q3, q20, [sp, #864]
	add	x12, sp, #864
	ldr	s4, [x12, x11, lsl #2]
	tst	w10, #0x1
	mov.s	w10, v6[3]
	fcsel	s7, s4, s5, ne
	and	x11, x10, #0x7
	add	x12, sp, #760
	bfxil	x12, x10, #0, #3
	ldrb	w10, [x12]
	and	w10, w4, w10
	stp	q3, q20, [sp, #832]
	add	x12, sp, #832
	ldr	s4, [x12, x11, lsl #2]
	tst	w10, #0x1
	fcsel	s16, s4, s5, ne
	ldr	q6, [sp, #576]                  ; 16-byte Reload
	fmov	w10, s6
	and	x11, x10, #0x7
	add	x12, sp, #760
	bfxil	x12, x10, #0, #3
	ldrb	w10, [x12]
	and	w10, w20, w10
	str	q20, [sp, #1072]
	str	q3, [sp, #1056]
	add	x12, sp, #1056
	ldr	s4, [x12, x11, lsl #2]
	tst	w10, #0x1
	fcsel	s4, s4, s5, ne
	mov.s	w10, v6[1]
	and	x11, x10, #0x7
	add	x12, sp, #760
	bfxil	x12, x10, #0, #3
	ldrb	w10, [x12]
	and	w10, w19, w10
	str	q20, [sp, #1040]
	str	q3, [sp, #1024]
	add	x12, sp, #1024
	ldr	s17, [x12, x11, lsl #2]
	tst	w10, #0x1
	fcsel	s17, s17, s5, ne
	mov.s	w10, v6[2]
	and	x11, x10, #0x7
	add	x12, sp, #760
	bfxil	x12, x10, #0, #3
	ldrb	w10, [x12]
	and	w10, w6, w10
	stp	q3, q20, [sp, #992]
	add	x12, sp, #992
	ldr	s18, [x12, x11, lsl #2]
	tst	w10, #0x1
	fcsel	s18, s18, s5, ne
	mov.s	w10, v6[3]
	and	x11, x10, #0x7
	add	x12, sp, #760
	bfxil	x12, x10, #0, #3
	ldrb	w10, [x12]
	and	w10, w7, w10
	stp	q3, q20, [sp, #960]
	add	x12, sp, #960
	ldr	s6, [x12, x11, lsl #2]
	tst	w10, #0x1
	fcsel	s6, s6, s5, ne
	mov.s	v4[1], v17[0]
	mov.s	v4[2], v18[0]
	mov.s	v4[3], v6[0]
	mov.s	v21[1], v2[0]
	mov.s	v21[2], v7[0]
	add	x10, sp, #760
	mov.s	v21[3], v16[0]
	fadd.4s	v2, v3, v21
	fadd.4s	v3, v20, v4
	ldr	q4, [sp, #592]                  ; 16-byte Reload
	fmov	w11, s4
	bfxil	x10, x11, #0, #3
	ldrb	w10, [x10]
	and	x11, x11, #0x7
	stp	q2, q3, [sp, #800]
	add	x12, sp, #800
	ldr	s3, [x12, x11, lsl #2]
	tst	w24, w10
	fcsel	s3, s3, s5, ne
	tst	w15, #0x1
	fadd	s2, s2, s3
	fcsel	s3, s2, s5, ne
	ldr	w10, [sp, #224]                 ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s4, s2, s5, ne
	ldr	w10, [sp, #208]                 ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s6, s2, s5, ne
	ldr	w10, [sp, #192]                 ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s7, s2, s5, ne
	ldr	w10, [sp, #176]                 ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s16, s2, s5, ne
	tst	w27, #0x1
	fcsel	s17, s2, s5, ne
	tst	w28, #0x1
	fcsel	s18, s2, s5, ne
	tst	w30, #0x1
	mov.s	v3[1], v4[0]
	mov.s	v3[2], v6[0]
	mov.s	v3[3], v7[0]
	mov.s	v16[1], v17[0]
	mov.s	v16[2], v18[0]
	fcsel	s2, s2, s5, ne
	mov.s	v16[3], v2[0]
	stp	q3, q16, [sp, #768]
	and	x10, x14, #0x7
	add	x11, sp, #768
	ldr	s2, [x11, x10, lsl #2]
	fadd	s2, s2, s5
	dup.4s	v3, v2[0]
	ldr	q2, [sp, #288]                  ; 16-byte Reload
	fmov	x10, d2
	ldp	x14, x13, [sp, #384]            ; 16-byte Folded Reload
	add	x10, x13, x10, lsl #2
	movi.2d	v2, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	ldp	q17, q21, [sp, #608]            ; 32-byte Folded Reload
	ldp	q19, q18, [sp, #640]            ; 32-byte Folded Reload
	ldr	q20, [sp, #672]                 ; 16-byte Reload
	b	LBB0_140
LBB0_139:                               ; %else320
                                        ;   in Loop: Header=BB0_140 Depth=1
	add.2d	v4, v4, v19
	add.2d	v5, v5, v20
	add.2d	v6, v6, v18
	add.2d	v2, v2, v21
	fmov	x8, d2
	cmp	x8, #512
	b.ge	LBB0_156
LBB0_140:                               ; %direct.true252
                                        ; =>This Inner Loop Header: Depth=1
	fmov	w11, s17
	lsl	x8, x8, #5
	add	x12, x9, x8
	ldp	q16, q7, [x12]
	and.16b	v16, v1, v16
	fdiv.4s	v16, v16, v3
	add	x8, x10, x8
	tbnz	w11, #0, LBB0_148
; %bb.141:                              ; %else306
                                        ;   in Loop: Header=BB0_140 Depth=1
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB0_149
LBB0_142:                               ; %else308
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w11, #2, LBB0_150
LBB0_143:                               ; %else310
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w11, #3, LBB0_151
LBB0_144:                               ; %else312
                                        ;   in Loop: Header=BB0_140 Depth=1
	and.16b	v7, v0, v7
	fdiv.4s	v7, v7, v3
	tbnz	w11, #4, LBB0_152
LBB0_145:                               ; %else314
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w11, #5, LBB0_153
LBB0_146:                               ; %else316
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w11, #6, LBB0_154
LBB0_147:                               ; %else318
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbz	w11, #7, LBB0_139
	b	LBB0_155
LBB0_148:                               ; %cond.store305
                                        ;   in Loop: Header=BB0_140 Depth=1
	str	s16, [x8]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB0_142
LBB0_149:                               ; %cond.store307
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x12, x8, #4
	st1.s	{ v16 }[1], [x12]
	tbz	w11, #2, LBB0_143
LBB0_150:                               ; %cond.store309
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x12, x8, #8
	st1.s	{ v16 }[2], [x12]
	tbz	w11, #3, LBB0_144
LBB0_151:                               ; %cond.store311
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x12, x8, #12
	st1.s	{ v16 }[3], [x12]
	and.16b	v7, v0, v7
	fdiv.4s	v7, v7, v3
	tbz	w11, #4, LBB0_145
LBB0_152:                               ; %cond.store313
                                        ;   in Loop: Header=BB0_140 Depth=1
	str	s7, [x8, #16]
	tbz	w11, #5, LBB0_146
LBB0_153:                               ; %cond.store315
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x12, x8, #20
	st1.s	{ v7 }[1], [x12]
	tbz	w11, #6, LBB0_147
LBB0_154:                               ; %cond.store317
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x12, x8, #24
	st1.s	{ v7 }[2], [x12]
	tbz	w11, #7, LBB0_139
LBB0_155:                               ; %cond.store319
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x8, x8, #28
	st1.s	{ v7 }[3], [x8]
	b	LBB0_139
LBB0_156:                               ; %direct.false253
	add	x8, x9, x1
	ldp	q1, q0, [x8]
	ldr	q4, [sp, #480]                  ; 16-byte Reload
	zip1.8b	v2, v4, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	and.16b	v1, v2, v1
	zip2.8b	v2, v4, v0
	ushll.4s	v2, v2, #0
	ldr	d4, [sp, #456]                  ; 8-byte Reload
	fmov	w8, s4
	fdiv.4s	v1, v1, v3
	ldr	q5, [sp, #368]                  ; 16-byte Reload
	ldp	q7, q6, [sp, #304]              ; 32-byte Folded Reload
	stp	q5, q6, [sp, #688]
	ldr	q4, [sp, #336]                  ; 16-byte Reload
	stp	q7, q4, [sp, #720]
	and	x9, x14, #0x7
	add	x10, sp, #688
	ldr	x9, [x10, x9, lsl #3]
	sub	x9, x9, x14
	add	x9, x13, x9, lsl #2
	tbnz	w8, #0, LBB0_172
; %bb.157:                              ; %else323
	shl.4s	v2, v2, #31
	tbnz	w8, #1, LBB0_173
LBB0_158:                               ; %else325
	cmlt.4s	v2, v2, #0
	tbnz	w8, #2, LBB0_174
LBB0_159:                               ; %else327
	and.16b	v0, v2, v0
	tbnz	w8, #3, LBB0_175
LBB0_160:                               ; %else329
	fdiv.4s	v0, v0, v3
	tbnz	w8, #4, LBB0_176
LBB0_161:                               ; %else331
	tbnz	w8, #5, LBB0_177
LBB0_162:                               ; %else333
	tbnz	w8, #6, LBB0_178
LBB0_163:                               ; %else335
	tbz	w8, #7, LBB0_165
LBB0_164:                               ; %cond.store336
	add	x8, x9, #28
	st1.s	{ v0 }[3], [x8]
LBB0_165:
	add	sp, sp, #2384
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
LBB0_166:                               ; %common.ret
	ret
LBB0_167:                               ; %cond.load268
	ldr	q2, [sp, #48]                   ; 16-byte Reload
	fmov	x10, d2
	ld1.b	{ v3 }[2], [x10]
	tbz	w8, #3, LBB0_131
LBB0_168:                               ; %cond.load274
	ldr	x10, [sp, #72]                  ; 8-byte Reload
	ld1.b	{ v3 }[3], [x10]
	tbz	w8, #4, LBB0_132
LBB0_169:                               ; %cond.load280
	ldr	q2, [sp, #80]                   ; 16-byte Reload
	fmov	x10, d2
	ld1.b	{ v3 }[4], [x10]
	tbz	w8, #5, LBB0_133
LBB0_170:                               ; %cond.load286
	ldr	x10, [sp, #104]                 ; 8-byte Reload
	ld1.b	{ v3 }[5], [x10]
	adrp	x10, lCPI0_20@PAGE
	adrp	x11, lCPI0_21@PAGE
	adrp	x12, lCPI0_22@PAGE
	adrp	x16, lCPI0_23@PAGE
	adrp	x17, lCPI0_24@PAGE
	tbz	w8, #6, LBB0_134
LBB0_171:                               ; %cond.load292
	ldr	q2, [sp, #112]                  ; 16-byte Reload
	fmov	x0, d2
	ld1.b	{ v3 }[6], [x0]
	ldr	q2, [x10, lCPI0_20@PAGEOFF]
	ldr	q4, [x11, lCPI0_21@PAGEOFF]
	ldr	q6, [x12, lCPI0_22@PAGEOFF]
	ldr	q7, [x16, lCPI0_23@PAGEOFF]
	ldr	q16, [x17, lCPI0_24@PAGEOFF]
	tbnz	w8, #7, LBB0_135
	b	LBB0_136
LBB0_172:                               ; %cond.store322
	str	s1, [x9]
	shl.4s	v2, v2, #31
	tbz	w8, #1, LBB0_158
LBB0_173:                               ; %cond.store324
	add	x10, x9, #4
	st1.s	{ v1 }[1], [x10]
	cmlt.4s	v2, v2, #0
	tbz	w8, #2, LBB0_159
LBB0_174:                               ; %cond.store326
	add	x10, x9, #8
	st1.s	{ v1 }[2], [x10]
	and.16b	v0, v2, v0
	tbz	w8, #3, LBB0_160
LBB0_175:                               ; %cond.store328
	add	x10, x9, #12
	st1.s	{ v1 }[3], [x10]
	fdiv.4s	v0, v0, v3
	tbz	w8, #4, LBB0_161
LBB0_176:                               ; %cond.store330
	str	s0, [x9, #16]
	tbz	w8, #5, LBB0_162
LBB0_177:                               ; %cond.store332
	add	x10, x9, #20
	st1.s	{ v0 }[1], [x10]
	tbz	w8, #6, LBB0_163
LBB0_178:                               ; %cond.store334
	add	x10, x9, #24
	st1.s	{ v0 }[2], [x10]
	tbnz	w8, #7, LBB0_164
	b	LBB0_165
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdrp	Lloh28, Lloh30
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpLdr	Lloh32, Lloh33
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.full_packet
lCPI1_0:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI1_1:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI1_2:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI1_3:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI1_4:
	.quad	0                               ; 0x0
	.quad	513                             ; 0x201
lCPI1_5:
	.quad	1026                            ; 0x402
	.quad	1539                            ; 0x603
lCPI1_6:
	.quad	2052                            ; 0x804
	.quad	2565                            ; 0xa05
lCPI1_7:
	.quad	3078                            ; 0xc06
	.quad	3591                            ; 0xe07
lCPI1_8:
	.quad	3590                            ; 0xe06
	.quad	4103                            ; 0x1007
lCPI1_9:
	.quad	2564                            ; 0xa04
	.quad	3077                            ; 0xc05
lCPI1_10:
	.quad	1538                            ; 0x602
	.quad	2051                            ; 0x803
lCPI1_11:
	.quad	512                             ; 0x200
	.quad	1025                            ; 0x401
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows.full_packet:                  ; @llm_rows.full_packet
; %bb.0:                                ; %prologue
	sub	sp, sp, #128
	stp	d15, d14, [sp, #16]             ; 16-byte Folded Spill
	stp	d13, d12, [sp, #32]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #48]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #64]               ; 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	mov	x11, #0                         ; =0x0
	ldr	x8, [x1, #136]
	mov	w9, #20616                      ; =0x5088
	movk	w9, #1, lsl #16
	add	x10, x8, #17, lsl #12           ; =69632
	add	x13, x10, #104
	mov	w10, #53352                     ; =0xd068
	add	x14, x8, x10
	ldr	x16, [x0]
	ldr	w10, [x1]
	ldr	w12, [x1, #36]
	add	w10, w12, w10, lsl #5
	lsr	w10, w10, #3
	dup.4s	v0, w10
	ushll.2d	v1, v0, #0
	fmov	x10, d1
	mov	w12, #16388                     ; =0x4004
	umaddl	x12, w10, w12, x16
	mov	w15, #49184                     ; =0xc020
	ldr	x10, [x0, #48]
LBB1_1:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	add	x17, x12, x11
	ldp	q2, q3, [x17]
	add	x17, x8, x11
	stp	q2, q3, [x17]
	add	x11, x11, #32
	cmp	x11, #4, lsl #12                ; =16384
	b.ne	LBB1_1
; %bb.2:                                ; %direct.false
	mov	x17, #0                         ; =0x0
	fmov	x11, d1
	add	x11, x11, x11, lsl #12
	lsl	x12, x11, #2
	add	x11, x12, #4, lsl #12           ; =16384
	ldr	s1, [x16, x11]
	mov	w16, #16384                     ; =0x4000
	str	s1, [x8, x16]
Lloh34:
	adrp	x16, lCPI1_0@PAGE
Lloh35:
	ldr	q1, [x16, lCPI1_0@PAGEOFF]
Lloh36:
	adrp	x16, lCPI1_1@PAGE
Lloh37:
	ldr	q2, [x16, lCPI1_1@PAGEOFF]
Lloh38:
	adrp	x16, lCPI1_2@PAGE
Lloh39:
	ldr	q3, [x16, lCPI1_2@PAGEOFF]
Lloh40:
	adrp	x16, lCPI1_3@PAGE
Lloh41:
	ldr	q4, [x16, lCPI1_3@PAGEOFF]
	mov	w16, #1                         ; =0x1
	dup.2d	v5, x16
	mov	w16, #16416                     ; =0x4020
	add	x16, x8, x16
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
LBB1_3:                                 ; %direct.true73
                                        ; =>This Inner Loop Header: Depth=1
	shl.2d	v18, v6, #3
	shl.2d	v19, v7, #3
	shl.2d	v20, v16, #3
	shl.2d	v21, v17, #3
	orr.16b	v21, v21, v1
	orr.16b	v20, v20, v2
	orr.16b	v19, v19, v3
	orr.16b	v18, v18, v4
	add	x17, x16, x17, lsl #6
	stp	q18, q19, [x17]
	stp	q20, q21, [x17, #32]
	add.2d	v16, v16, v5
	add.2d	v7, v7, v5
	add.2d	v17, v17, v5
	add.2d	v6, v6, v5
	fmov	x17, d6
	cmp	x17, #512
	b.lt	LBB1_3
; %bb.4:                                ; %direct.false74
	mov	x17, #0                         ; =0x0
	mov	w0, #4096                       ; =0x1000
	str	x0, [x8, x15]
	mov	w0, #61441                      ; =0xf001
	movk	w0, #255, lsl #16
	dup.4s	v1, w0
	mov	w0, #4097                       ; =0x1001
	dup.4s	v2, w0
	mov	w0, #49248                      ; =0xc060
	add	x0, x8, x0
	umull2.2d	v3, v0, v1
	umull.2d	v4, v0, v1
	uzp2.4s	v4, v4, v3
	ushr.4s	v4, v4, #4
	mov.16b	v6, v0
	mls.4s	v6, v4, v2
	umull.2d	v1, v0, v1
	uzp2.4s	v1, v1, v3
	ushr.4s	v1, v1, #4
	mls.4s	v0, v1, v2
	ushll2.2d	v5, v0, #0
	ushll2.2d	v7, v6, #0
	ushll.2d	v16, v0, #0
	ushll.2d	v6, v6, #0
	movi.2d	v17, #0000000000000000
	dup.2d	v0, x0
Lloh42:
	adrp	x0, lCPI1_4@PAGE
Lloh43:
	ldr	q1, [x0, lCPI1_4@PAGEOFF]
Lloh44:
	adrp	x0, lCPI1_5@PAGE
Lloh45:
	ldr	q2, [x0, lCPI1_5@PAGEOFF]
Lloh46:
	adrp	x0, lCPI1_6@PAGE
Lloh47:
	ldr	q3, [x0, lCPI1_6@PAGEOFF]
Lloh48:
	adrp	x0, lCPI1_7@PAGE
Lloh49:
	ldr	q4, [x0, lCPI1_7@PAGEOFF]
	movi.8b	v18, #1
	mov	w0, #1                          ; =0x1
	dup.2d	v19, x0
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
LBB1_5:                                 ; %direct.true89
                                        ; =>This Inner Loop Header: Depth=1
	add	x17, x16, x17, lsl #6
	ldp	q24, q23, [x17, #32]
	ldp	q25, q26, [x17]
	add.2d	v27, v22, v4
	add.2d	v27, v27, v0
	add.2d	v28, v21, v3
	add.2d	v29, v20, v2
	add.2d	v30, v17, v1
	add.2d	v30, v30, v0
	cmge.2d	v26, v7, v26
	cmge.2d	v25, v6, v25
	uzp1.4s	v25, v25, v26
	cmge.2d	v24, v16, v24
	cmge.2d	v23, v5, v23
	uzp1.4s	v23, v24, v23
	uzp1.8h	v23, v25, v23
	xtn.8b	v23, v23
	and.8b	v23, v23, v18
	mov.d	x17, v30[1]
	fmov	x0, d30
	str	b23, [x0]
	st1.b	{ v23 }[1], [x17]
	add.2d	v24, v29, v0
	mov.d	x17, v24[1]
	fmov	x0, d24
	st1.b	{ v23 }[2], [x0]
	add.2d	v24, v28, v0
	st1.b	{ v23 }[3], [x17]
	mov.d	x17, v24[1]
	fmov	x0, d24
	st1.b	{ v23 }[4], [x0]
	st1.b	{ v23 }[5], [x17]
	mov.d	x17, v27[1]
	fmov	x0, d27
	st1.b	{ v23 }[6], [x0]
	st1.b	{ v23 }[7], [x17]
	add.2d	v21, v21, v19
	add.2d	v20, v20, v19
	add.2d	v22, v22, v19
	add.2d	v17, v17, v19
	fmov	x17, d17
	cmp	x17, #512
	b.lt	LBB1_5
; %bb.6:                                ; %direct.false90
	mov	x16, #0                         ; =0x0
	ldr	d7, [x8, x15]
Lloh50:
	adrp	x15, lCPI1_11@PAGE
Lloh51:
	ldr	q5, [x15, lCPI1_11@PAGEOFF]
	add.2d	v5, v0, v5
	cmge.2d	v6, v6, v7
	xtn.2s	v6, v6
	uzp1.4h	v6, v6, v0
	uzp1.8b	v6, v6, v0
	movi.8b	v7, #1
	and.8b	v6, v6, v7
	fmov	x15, d5
	str	b6, [x15]
	mov	w15, #62154                     ; =0xf2ca
	movk	w15, #61769, lsl #16
	dup.4s	v6, w15
	mov	w15, #1                         ; =0x1
	dup.2d	v7, x15
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
LBB1_7:                                 ; %direct.true105
                                        ; =>This Inner Loop Header: Depth=1
	add.2d	v20, v19, v4
	add.2d	v20, v20, v0
	add.2d	v21, v18, v3
	add.2d	v21, v21, v0
	add.2d	v22, v17, v2
	add.2d	v22, v22, v0
	add.2d	v23, v16, v1
	add.2d	v23, v23, v0
	mov.d	x15, v23[1]
	mov.d	x17, v22[1]
	fmov	x0, d23
	fmov	x1, d22
	mov.d	x2, v21[1]
	fmov	x3, d21
	ldr	b21, [x0]
	ld1.b	{ v21 }[1], [x15]
	ld1.b	{ v21 }[2], [x1]
	mov.d	x15, v20[1]
	ld1.b	{ v21 }[3], [x17]
	ld1.b	{ v21 }[4], [x3]
	ld1.b	{ v21 }[5], [x2]
	fmov	x17, d20
	ld1.b	{ v21 }[6], [x17]
	ld1.b	{ v21 }[7], [x15]
	cmeq.8b	v20, v21, #0
	sshll.8h	v20, v20, #0
	sshll2.4s	v21, v20, #0
	lsl	x15, x16, #5
	add	x16, x8, x15
	ldp	q23, q22, [x16]
	sshll.4s	v20, v20, #0
	bsl.16b	v20, v6, v23
	bsl.16b	v21, v6, v22
	add	x15, x14, x15
	stp	q20, q21, [x15]
	add.2d	v18, v18, v7
	add.2d	v17, v17, v7
	add.2d	v19, v19, v7
	add.2d	v16, v16, v7
	fmov	x16, d16
	cmp	x16, #512
	b.lt	LBB1_7
; %bb.8:                                ; %direct.false106
	mov	x15, #0                         ; =0x0
	str	q5, [sp]                        ; 16-byte Spill
	fmov	x16, d5
	ldr	b6, [x16]
	cmeq.8b	v6, v6, #0
	sshll.8h	v6, v6, #0
	sshll.4s	v6, v6, #0
	ldr	q7, [x8, #16384]
	mov	w16, #62154                     ; =0xf2ca
	movk	w16, #61769, lsl #16
	fmov	s16, w16
	bsl.16b	v6, v16, v7
	ldr	q7, [x13]
	mov.s	v7[0], v6[0]
	str	q7, [x13]
	ldp	q7, q16, [x14]
	ldp	q20, q21, [x14, #32]
	ldp	q22, q17, [x14, #64]
	ldp	q18, q19, [x14, #96]
	mov	w16, #53544                     ; =0xd128
	add	x16, x8, x16
LBB1_9:                                 ; %direct.true139
                                        ; =>This Inner Loop Header: Depth=1
	add	x17, x16, x15, lsl #5
	ldp	q23, q24, [x17, #-64]
	fmaxnm.4s	v16, v16, v24
	fmaxnm.4s	v7, v7, v23
	ldp	q23, q24, [x17, #-32]
	fmaxnm.4s	v21, v21, v24
	fmaxnm.4s	v20, v20, v23
	ldp	q23, q24, [x17]
	fmaxnm.4s	v17, v17, v24
	fmaxnm.4s	v22, v22, v23
	ldp	q23, q24, [x17, #32]
	fmaxnm.4s	v19, v19, v24
	fmaxnm.4s	v18, v18, v23
	add	x15, x15, #4
	cmp	x15, #508
	b.lo	LBB1_9
; %bb.10:                               ; %direct.false140
	mov	x5, #0                          ; =0x0
	add	x15, x13, #32
	movi.2d	v23, #0000000000000000
	mov.s	v23[0], v6[0]
	movi.2d	v6, #0000000000000000
	fmaxnm.4s	v23, v7, v23
	mov.s	v7[0], v23[0]
	fmaxnm.4s	v16, v16, v21
	fmaxnm.4s	v7, v7, v20
	fmaxnm.4s	v7, v7, v22
	fmaxnm.4s	v16, v16, v17
	fmaxnm.4s	v16, v16, v19
	fmaxnm.4s	v7, v7, v18
	rev64.4s	v17, v7
	rev64.4s	v18, v16
	fmaxnm.4s	v16, v16, v18
	fmaxnm.4s	v7, v7, v17
	ext.16b	v17, v7, v7, #8
	ext.16b	v18, v16, v16, #8
	fmaxnm.4s	v16, v16, v18
	fmaxnm.4s	v7, v7, v17
	fmaxnm.4s	v7, v7, v16
	mov	w16, #-8388608                  ; =0xff800000
	fmov	s16, w16
	fmaxnm	s7, s7, s16
	dup.4s	v7, v7[0]
	mov	w16, #-1026555904               ; =0xc2d00000
	dup.4s	v16, w16
	mov	w16, #1120403456                ; =0x42c80000
	dup.4s	v17, w16
	mov	w16, #43579                     ; =0xaa3b
	movk	w16, #16312, lsl #16
	dup.4s	v18, w16
	mvni.4s	v20, #128, lsl #24
	mov	w16, #29184                     ; =0x7200
	movk	w16, #48945, lsl #16
	dup.4s	v21, w16
	mov	w16, #48782                     ; =0xbe8e
	movk	w16, #46527, lsl #16
	mov	w17, #11226                     ; =0x2bda
	movk	w17, #14672, lsl #16
	mov	w0, #38601                      ; =0x96c9
	movk	w0, #15030, lsl #16
	mov	w1, #34982                      ; =0x88a6
	movk	w1, #15368, lsl #16
	mov	w2, #43642                      ; =0xaa7a
	movk	w2, #15658, lsl #16
	mov	w3, #43691                      ; =0xaaab
	movk	w3, #15914, lsl #16
	movi.4s	v22, #63, lsl #24
	fmov.4s	v23, #1.00000000
	mvni.4s	v24, #127, msl #16
	fneg.4s	v24, v24
	mvni.4s	v25, #63, msl #16
	fneg.4s	v25, v25
	mov	w4, #1                          ; =0x1
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
LBB1_11:                                ; %direct.true174
                                        ; =>This Inner Loop Header: Depth=1
	add.2d	v29, v28, v4
	add.2d	v29, v29, v0
	add.2d	v30, v27, v3
	add.2d	v30, v30, v0
	add.2d	v31, v26, v2
	add.2d	v31, v31, v0
	add.2d	v8, v6, v1
	add.2d	v8, v8, v0
	mov.d	x6, v8[1]
	fmov	x7, d8
	mov.d	x19, v31[1]
	fmov	x20, d31
	mov.d	x21, v30[1]
	fmov	x22, d30
	mov.d	x23, v29[1]
	ldr	b31, [x7]
	ld1.b	{ v31 }[1], [x6]
	ld1.b	{ v31 }[2], [x20]
	ld1.b	{ v31 }[3], [x19]
	ld1.b	{ v31 }[4], [x22]
	fmov	x6, d29
	ld1.b	{ v31 }[5], [x21]
	lsl	x5, x5, #5
	ld1.b	{ v31 }[6], [x6]
	add	x6, x14, x5
	ldp	q30, q29, [x6]
	fsub.4s	v29, v29, v7
	ld1.b	{ v31 }[7], [x23]
	fsub.4s	v30, v30, v7
	fcmge.4s	v8, v30, v16
	fcmge.4s	v9, v29, v16
	fcmge.4s	v10, v17, v30
	fcmge.4s	v11, v17, v29
	cmeq.8b	v31, v31, #0
	and.16b	v9, v9, v11
	and.16b	v8, v8, v10
	and.16b	v10, v8, v30
	and.16b	v9, v9, v29
	fmul.4s	v8, v9, v18
	sshll.8h	v11, v31, #0
	fmul.4s	v31, v10, v18
	movi.4s	v5, #75, lsl #24
	mov.16b	v12, v20
	bsl.16b	v12, v5, v31
	mov.16b	v13, v20
	bsl.16b	v13, v5, v8
	fadd.4s	v8, v8, v13
	fadd.4s	v14, v31, v12
	sshll2.4s	v31, v11, #0
	fsub.4s	v12, v14, v12
	fsub.4s	v8, v8, v13
	fcvtzs.4s	v13, v8
	fcvtzs.4s	v12, v12
	scvtf.4s	v14, v12
	sshll.4s	v8, v11, #0
	scvtf.4s	v11, v13
	fmul.4s	v15, v11, v21
	fmul.4s	v5, v14, v21
	dup.4s	v19, w16
	fadd.4s	v5, v10, v5
	fadd.4s	v9, v9, v15
	fmul.4s	v10, v14, v19
	fmul.4s	v19, v11, v19
	dup.4s	v11, w17
	fadd.4s	v19, v9, v19
	fadd.4s	v5, v5, v10
	fmul.4s	v9, v5, v11
	fmul.4s	v10, v19, v11
	dup.4s	v11, w0
	fadd.4s	v10, v10, v11
	fadd.4s	v9, v9, v11
	fmul.4s	v9, v5, v9
	fmul.4s	v10, v19, v10
	dup.4s	v11, w1
	fadd.4s	v10, v10, v11
	fadd.4s	v9, v9, v11
	fmul.4s	v9, v5, v9
	fmul.4s	v10, v19, v10
	dup.4s	v11, w2
	fadd.4s	v10, v10, v11
	fadd.4s	v9, v9, v11
	fmul.4s	v9, v5, v9
	fmul.4s	v10, v19, v10
	dup.4s	v11, w3
	fadd.4s	v10, v10, v11
	fadd.4s	v9, v9, v11
	fmul.4s	v9, v5, v9
	fmul.4s	v10, v19, v10
	fadd.4s	v10, v10, v22
	fadd.4s	v9, v9, v22
	fmul.4s	v11, v19, v19
	fmul.4s	v14, v5, v5
	fmul.4s	v9, v14, v9
	fmul.4s	v10, v11, v10
	fadd.4s	v19, v19, v10
	fadd.4s	v5, v5, v9
	fadd.4s	v5, v5, v23
	sshr.4s	v9, v12, #1
	sshr.4s	v10, v13, #1
	shl.4s	v11, v10, #23
	shl.4s	v14, v9, #23
	add.4s	v14, v14, v23
	fadd.4s	v19, v19, v23
	add.4s	v11, v11, v23
	fmul.4s	v19, v19, v11
	sub.4s	v10, v13, v10
	sub.4s	v9, v12, v9
	shl.4s	v9, v9, #23
	fmul.4s	v5, v5, v14
	shl.4s	v10, v10, #23
	add.4s	v10, v10, v23
	add.4s	v9, v9, v23
	fmul.4s	v5, v5, v9
	fcmgt.4s	v9, v16, v29
	fmul.4s	v19, v19, v10
	bic.16b	v19, v19, v9
	fcmgt.4s	v9, v16, v30
	bic.16b	v5, v5, v9
	fcmgt.4s	v9, v29, v17
	fcmgt.4s	v10, v30, v17
	bit.16b	v5, v24, v10
	bit.16b	v19, v24, v9
	fcmeq.4s	v30, v30, v30
	fcmeq.4s	v29, v29, v29
	bif.16b	v19, v25, v29
	bif.16b	v5, v25, v30
	bic.16b	v5, v5, v8
	bic.16b	v19, v19, v31
	add	x5, x15, x5
	dup.2d	v29, x4
	stp	q5, q19, [x5]
	add.2d	v27, v27, v29
	add.2d	v26, v26, v29
	add.2d	v28, v28, v29
	add.2d	v6, v6, v29
	fmov	x5, d6
	cmp	x5, #512
	b.lt	LBB1_11
; %bb.12:                               ; %direct.false175
	mov	x14, #0                         ; =0x0
	ldr	q0, [sp]                        ; 16-byte Reload
	fmov	x16, d0
	ldr	b3, [x16]
	ldr	q0, [x13]
	fsub.4s	v1, v0, v7
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], v1[0]
	mov	w16, #-1026555904               ; =0xc2d00000
	dup.4s	v1, w16
	fcmge.4s	v4, v0, v1
	mov	w16, #1120403456                ; =0x42c80000
	dup.4s	v2, w16
	fcmge.4s	v5, v2, v0
	and.16b	v4, v4, v5
	and.16b	v4, v4, v0
	mov	w16, #43579                     ; =0xaa3b
	movk	w16, #16312, lsl #16
	dup.4s	v5, w16
	fmul.4s	v5, v4, v5
	movi.4s	v6, #75, lsl #24
	mvni.4s	v7, #128, lsl #24
	bif.16b	v6, v5, v7
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	fcvtzs.4s	v5, v5
	scvtf.4s	v6, v5
	mov	w16, #29184                     ; =0x7200
	movk	w16, #48945, lsl #16
	dup.4s	v7, w16
	fmul.4s	v7, v6, v7
	mov	w16, #48782                     ; =0xbe8e
	movk	w16, #46527, lsl #16
	dup.4s	v16, w16
	fadd.4s	v4, v4, v7
	fmul.4s	v6, v6, v16
	fadd.4s	v4, v4, v6
	mov	w16, #11226                     ; =0x2bda
	movk	w16, #14672, lsl #16
	dup.4s	v6, w16
	fmul.4s	v6, v4, v6
	mov	w16, #38601                     ; =0x96c9
	movk	w16, #15030, lsl #16
	dup.4s	v7, w16
	fadd.4s	v6, v6, v7
	fmul.4s	v6, v4, v6
	mov	w16, #34982                     ; =0x88a6
	movk	w16, #15368, lsl #16
	dup.4s	v7, w16
	mov	w16, #43642                     ; =0xaa7a
	movk	w16, #15658, lsl #16
	dup.4s	v16, w16
	fadd.4s	v6, v6, v7
	mov	w16, #43691                     ; =0xaaab
	movk	w16, #15914, lsl #16
	dup.4s	v7, w16
	cmeq.8b	v3, v3, #0
	sshll.8h	v3, v3, #0
	sshll.4s	v3, v3, #0
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v16
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v7
	fmul.4s	v6, v4, v6
	movi.4s	v7, #63, lsl #24
	fadd.4s	v6, v6, v7
	fmul.4s	v7, v4, v4
	fmul.4s	v6, v7, v6
	fadd.4s	v4, v4, v6
	fmov.4s	v6, #1.00000000
	fadd.4s	v4, v4, v6
	sshr.4s	v7, v5, #1
	shl.4s	v16, v7, #23
	add.4s	v16, v16, v6
	fmul.4s	v4, v4, v16
	sub.4s	v5, v5, v7
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v6
	fmul.4s	v4, v4, v5
	fcmgt.4s	v1, v1, v0
	bic.16b	v1, v4, v1
	fcmgt.4s	v2, v0, v2
	mvni.4s	v4, #127, msl #16
	fneg.4s	v4, v4
	bit.16b	v1, v4, v2
	fcmeq.4s	v0, v0, v0
	mvni.4s	v2, #63, msl #16
	fneg.4s	v2, v2
	bsl.16b	v0, v1, v2
	bic.16b	v1, v0, v3
	ldr	q0, [x8, x9]
	mov.s	v0[0], v1[0]
	str	q0, [x8, x9]
	ldp	q1, q2, [x13, #32]
	ldp	q6, q7, [x13, #64]
	ldp	q16, q3, [x13, #96]
	ldp	q4, q5, [x13, #128]
	add	x13, x8, #17, lsl #12           ; =69632
	add	x13, x13, #328
LBB1_13:                                ; %direct.true215
                                        ; =>This Inner Loop Header: Depth=1
	add	x16, x13, x14, lsl #5
	ldp	q17, q18, [x16, #-64]
	fadd.4s	v2, v2, v18
	fadd.4s	v1, v1, v17
	ldp	q17, q18, [x16, #-32]
	fadd.4s	v7, v7, v18
	fadd.4s	v6, v6, v17
	ldp	q17, q18, [x16]
	fadd.4s	v3, v3, v18
	fadd.4s	v16, v16, v17
	ldp	q17, q18, [x16, #32]
	fadd.4s	v5, v5, v18
	fadd.4s	v4, v4, v17
	add	x14, x14, #4
	cmp	x14, #508
	b.lo	LBB1_13
; %bb.14:                               ; %direct.false216
	mov	x13, #0                         ; =0x0
	fadd.4s	v0, v0, v1
	mov.s	v1[0], v0[0]
	fadd.4s	v0, v7, v2
	fadd.4s	v1, v6, v1
	fadd.4s	v1, v16, v1
	fadd.4s	v0, v3, v0
	fadd.4s	v0, v5, v0
	fadd.4s	v1, v4, v1
	rev64.4s	v2, v1
	rev64.4s	v3, v0
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	dup.4s	v2, v1[2]
	dup.4s	v3, v0[2]
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	fadd.4s	v0, v1, v0
	movi.2d	v1, #0000000000000000
	fadd	s0, s0, s1
	dup.4s	v0, v0[0]
	add	x12, x10, x12
LBB1_15:                                ; %direct.true252
                                        ; =>This Inner Loop Header: Depth=1
	add	x14, x15, x13
	ldp	q2, q1, [x14]
	fdiv.4s	v2, v2, v0
	fdiv.4s	v1, v1, v0
	add	x14, x12, x13
	stp	q2, q1, [x14]
	add	x13, x13, #32
	cmp	x13, #4, lsl #12                ; =16384
	b.ne	LBB1_15
; %bb.16:                               ; %direct.false253
	ldr	q1, [x8, x9]
	fdiv.4s	v0, v1, v0
	str	s0, [x10, x11]
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #64]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #48]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #32]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.loh AdrpLdr	Lloh40, Lloh41
	.loh AdrpAdrp	Lloh38, Lloh40
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpAdrp	Lloh36, Lloh38
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpAdrp	Lloh34, Lloh36
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpLdr	Lloh48, Lloh49
	.loh AdrpAdrp	Lloh46, Lloh48
	.loh AdrpLdr	Lloh46, Lloh47
	.loh AdrpAdrp	Lloh44, Lloh46
	.loh AdrpLdr	Lloh44, Lloh45
	.loh AdrpAdrp	Lloh42, Lloh44
	.loh AdrpLdr	Lloh42, Lloh43
	.loh AdrpLdr	Lloh50, Lloh51
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB2_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB2_4
LBB2_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB2_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB2_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB2_13
LBB2_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB2_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB2_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #1
	b.eq	LBB2_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #2
	b.eq	LBB2_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #3
	b.eq	LBB2_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB2_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB2_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
LBB2_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB2_3
LBB2_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB2_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

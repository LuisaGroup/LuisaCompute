	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_3:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_4:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_7:
	.quad	576                             ; 0x240
	.quad	672                             ; 0x2a0
lCPI0_8:
	.quad	192                             ; 0xc0
	.quad	288                             ; 0x120
lCPI0_9:
	.quad	384                             ; 0x180
	.quad	480                             ; 0x1e0
lCPI0_10:
	.quad	0                               ; 0x0
	.quad	96                              ; 0x60
lCPI0_11:
	.long	5                               ; 0x5
	.long	4                               ; 0x4
	.long	7                               ; 0x7
	.long	6                               ; 0x6
lCPI0_12:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	3                               ; 0x3
	.long	2                               ; 0x2
lCPI0_13:
	.long	6                               ; 0x6
	.long	7                               ; 0x7
	.long	4                               ; 0x4
	.long	5                               ; 0x5
lCPI0_14:
	.long	2                               ; 0x2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	dup.4s	v3, w2
Lloh0:
	adrp	x8, lCPI0_1@PAGE
Lloh1:
	ldr	q16, [x8, lCPI0_1@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_2@PAGE
Lloh3:
	ldr	q17, [x8, lCPI0_2@PAGEOFF]
	cmhi.4s	v0, v3, v17
	cmhi.4s	v1, v3, v16
	uzp1.8h	v7, v1, v0
	umaxv.8h	h2, v7
	fmov	w8, s2
	tbz	w8, #0, LBB0_98
; %bb.1:                                ; %direct.activate
	stp	d13, d12, [sp, #-144]!          ; 16-byte Folded Spill
	stp	d11, d10, [sp, #16]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #32]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #48]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #64]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	sub	sp, sp, #4, lsl #12             ; =16384
	sub	sp, sp, #1216
	mov	x8, #0                          ; =0x0
	add	x10, sp, #192
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #3520
	dup.2d	v4, x9
	ldr	x9, [x0, #48]
	str	x9, [sp, #40]                   ; 8-byte Spill
Lloh4:
	adrp	x9, lCPI0_0@PAGE
Lloh5:
	ldr	q2, [x9, lCPI0_0@PAGEOFF]
	and.16b	v2, v7, v2
	addv.8h	h2, v2
	fmov	w9, s2
	and	w11, w9, #0xff
	ldr	x9, [x0]
	ldr	w12, [x1]
	ldr	w13, [x1, #36]
	add	w12, w13, w12, lsl #5
	lsr	w12, w12, #3
	dup.4s	v5, w12
	and.16b	v6, v1, v5
	fmov	w12, s6
	mov	w13, #3072                      ; =0xc00
	umull	x14, w12, w13
	str	x14, [sp, #32]                  ; 8-byte Spill
	umaddl	x9, w12, w13, x9
	fmov	w12, s2
	add	x13, sp, #3, lsl #12            ; =12288
	add	x13, x13, #2240
	b	LBB0_3
LBB0_2:                                 ; %else67
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x14, x13, x8
	stp	q6, q18, [x14]
	add	x8, x8, #32
	cmp	x8, #3072
	b.eq	LBB0_19
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	add	x14, x9, x8
	add	x16, x13, x8
	ldr	q6, [x16]
	tbnz	w12, #0, LBB0_11
; %bb.4:                                ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w15, w12, #0xff
	tbnz	w15, #1, LBB0_12
LBB0_5:                                 ; %else49
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w15, #2, LBB0_13
LBB0_6:                                 ; %else52
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w15, #3, LBB0_14
LBB0_7:                                 ; %else55
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q18, [x16, #16]
	tbnz	w15, #4, LBB0_15
LBB0_8:                                 ; %else58
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w15, #5, LBB0_16
LBB0_9:                                 ; %else61
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w15, #6, LBB0_17
LBB0_10:                                ; %else64
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w15, #7, LBB0_2
	b	LBB0_18
LBB0_11:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	ld1.s	{ v6 }[0], [x14]
	and	w15, w12, #0xff
	tbz	w15, #1, LBB0_5
LBB0_12:                                ; %cond.load48
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x14, #4
	ld1.s	{ v6 }[1], [x17]
	tbz	w15, #2, LBB0_6
LBB0_13:                                ; %cond.load51
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x14, #8
	ld1.s	{ v6 }[2], [x17]
	tbz	w15, #3, LBB0_7
LBB0_14:                                ; %cond.load54
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x14, #12
	ld1.s	{ v6 }[3], [x17]
	ldr	q18, [x16, #16]
	tbz	w15, #4, LBB0_8
LBB0_15:                                ; %cond.load57
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x16, x14, #16
	ld1.s	{ v18 }[0], [x16]
	tbz	w15, #5, LBB0_9
LBB0_16:                                ; %cond.load60
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x16, x14, #20
	ld1.s	{ v18 }[1], [x16]
	tbz	w15, #6, LBB0_10
LBB0_17:                                ; %cond.load63
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x16, x14, #24
	ld1.s	{ v18 }[2], [x16]
	tbz	w15, #7, LBB0_2
LBB0_18:                                ; %cond.load66
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x14, x14, #28
	ld1.s	{ v18 }[3], [x14]
	b	LBB0_2
LBB0_19:                                ; %direct.true58.preheader
	mov	x8, #0                          ; =0x0
	add	x9, sp, #2, lsl #12             ; =8192
	add	x9, x9, #192
	sshll2.2d	v19, v0, #0
	sshll2.2d	v6, v1, #0
	sshll.2d	v18, v0, #0
	sshll.2d	v20, v1, #0
Lloh6:
	adrp	x12, lCPI0_3@PAGE
Lloh7:
	ldr	q21, [x12, lCPI0_3@PAGEOFF]
Lloh8:
	adrp	x12, lCPI0_4@PAGE
Lloh9:
	ldr	q22, [x12, lCPI0_4@PAGEOFF]
Lloh10:
	adrp	x12, lCPI0_5@PAGE
Lloh11:
	ldr	q23, [x12, lCPI0_5@PAGEOFF]
Lloh12:
	adrp	x12, lCPI0_6@PAGE
Lloh13:
	ldr	q24, [x12, lCPI0_6@PAGEOFF]
LBB0_20:                                ; %direct.true58
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v25, x8
	orr.16b	v26, v25, v21
	orr.16b	v27, v25, v22
	orr.16b	v28, v25, v23
	orr.16b	v25, v25, v24
	ldp	q30, q29, [x9, #32]
	ldp	q8, q31, [x9]
	bif.16b	v25, v8, v20
	bif.16b	v28, v30, v18
	bif.16b	v27, v31, v6
	bif.16b	v26, v29, v19
	stp	q28, q26, [x9, #32]
	stp	q25, q27, [x9], #64
	add	x8, x8, #8
	cmp	x8, #768
	b.ne	LBB0_20
; %bb.21:                               ; %direct.false59
	mov	x8, #0                          ; =0x0
	sshll.2d	v29, v1, #0
	sshll.2d	v28, v0, #0
	and.16b	v18, v0, v5
	and.16b	v5, v1, v5
	movi.4s	v20, #3, lsl #8
	and.16b	v21, v0, v20
	mvn.16b	v22, v0
	sub.4s	v21, v21, v22
	and.16b	v20, v1, v20
	mvn.16b	v22, v1
	sub.4s	v20, v20, v22
	mov.s	w9, v20[1]
	mov.s	w12, v5[1]
	udiv	w13, w12, w9
	msub	w9, w13, w9, w12
	mov.s	w12, v20[3]
	mov.s	w13, v20[2]
	fmov	w14, s20
	mov.s	w15, v5[3]
	mov.s	w16, v5[2]
	fmov	w17, s5
	udiv	w0, w17, w14
	msub	w14, w0, w14, w17
	udiv	w17, w15, w12
	msub	w12, w17, w12, w15
	udiv	w15, w16, w13
	msub	w13, w15, w13, w16
	mov.s	w15, v21[1]
	mov.s	w16, v18[1]
	udiv	w17, w16, w15
	msub	w15, w17, w15, w16
	mov.s	w16, v21[3]
	mov.s	w17, v18[3]
	udiv	w0, w17, w16
	msub	w16, w0, w16, w17
	mov.s	w17, v21[2]
	mov.s	w0, v18[2]
	udiv	w1, w0, w17
	msub	w17, w1, w17, w0
	fmov	w0, s21
	fmov	w1, s18
	fmov	s5, w17
	mov.s	v5[1], w16
	udiv	w16, w1, w0
	msub	w16, w16, w0, w1
	ushll.2d	v18, v5, #0
	fmov	s5, w16
	mov.s	v5[1], w15
	ushll.2d	v20, v5, #0
	fmov	s5, w13
	mov.s	v5[1], w12
	fmov	s22, w14
	mov.s	v22[1], w9
	ushll.2d	v21, v5, #0
	ushll.2d	v22, v22, #0
	and.16b	v23, v19, v4
	and.16b	v24, v6, v4
	and.16b	v25, v28, v4
	and.16b	v26, v29, v4
Lloh14:
	adrp	x9, lCPI0_7@PAGE
Lloh15:
	ldr	q4, [x9, lCPI0_7@PAGEOFF]
	and.16b	v19, v19, v4
Lloh16:
	adrp	x9, lCPI0_8@PAGE
Lloh17:
	ldr	q4, [x9, lCPI0_8@PAGEOFF]
	and.16b	v27, v6, v4
Lloh18:
	adrp	x9, lCPI0_9@PAGE
Lloh19:
	ldr	q4, [x9, lCPI0_9@PAGEOFF]
	and.16b	v28, v28, v4
Lloh20:
	adrp	x9, lCPI0_10@PAGE
Lloh21:
	ldr	q4, [x9, lCPI0_10@PAGEOFF]
	and.16b	v29, v29, v4
	cmhs.4s	v4, v17, v3
	cmhs.4s	v3, v16, v3
	uzp1.8h	v3, v3, v4
	xtn.8b	v30, v3
	add	x9, sp, #2, lsl #12             ; =8192
	add	x9, x9, #192
	movi.8b	v31, #1
	b	LBB0_23
LBB0_22:                                ; %else84
                                        ;   in Loop: Header=BB0_23 Depth=1
	add	x8, x8, #1
	cmp	x8, #96
	b.eq	LBB0_39
LBB0_23:                                ; %direct.true73
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v8, x8
	fmov	w12, s2
	add	x13, x9, x8, lsl #6
	ldp	q4, q3, [x13, #32]
	ldp	q5, q6, [x13]
	cmge.2d	v6, v21, v6
	cmge.2d	v5, v22, v5
	uzp1.4s	v5, v5, v6
	cmge.2d	v4, v20, v4
	cmge.2d	v3, v18, v3
	uzp1.4s	v3, v4, v3
	uzp1.8h	v3, v5, v3
	xtn.8b	v3, v3
	orr.8b	v5, v30, v3
	add.2d	v3, v26, v29
	add.2d	v4, v3, v8
	and.8b	v9, v5, v31
	tbnz	w12, #0, LBB0_31
; %bb.24:                               ; %else70
                                        ;   in Loop: Header=BB0_23 Depth=1
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_32
LBB0_25:                                ; %else72
                                        ;   in Loop: Header=BB0_23 Depth=1
	add.2d	v4, v24, v27
	add.2d	v5, v4, v8
	tbnz	w12, #2, LBB0_33
LBB0_26:                                ; %else74
                                        ;   in Loop: Header=BB0_23 Depth=1
	tbnz	w12, #3, LBB0_34
LBB0_27:                                ; %else76
                                        ;   in Loop: Header=BB0_23 Depth=1
	add.2d	v5, v25, v28
	add.2d	v6, v5, v8
	tbnz	w12, #4, LBB0_35
LBB0_28:                                ; %else78
                                        ;   in Loop: Header=BB0_23 Depth=1
	tbnz	w12, #5, LBB0_36
LBB0_29:                                ; %else80
                                        ;   in Loop: Header=BB0_23 Depth=1
	add.2d	v6, v23, v19
	add.2d	v8, v6, v8
	tbnz	w12, #6, LBB0_37
LBB0_30:                                ; %else82
                                        ;   in Loop: Header=BB0_23 Depth=1
	tbz	w12, #7, LBB0_22
	b	LBB0_38
LBB0_31:                                ; %cond.store
                                        ;   in Loop: Header=BB0_23 Depth=1
	fmov	x13, d4
	str	b9, [x13]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_25
LBB0_32:                                ; %cond.store71
                                        ;   in Loop: Header=BB0_23 Depth=1
	mov.d	x13, v4[1]
	st1.b	{ v9 }[1], [x13]
	add.2d	v4, v24, v27
	add.2d	v5, v4, v8
	tbz	w12, #2, LBB0_26
LBB0_33:                                ; %cond.store73
                                        ;   in Loop: Header=BB0_23 Depth=1
	fmov	x13, d5
	st1.b	{ v9 }[2], [x13]
	tbz	w12, #3, LBB0_27
LBB0_34:                                ; %cond.store75
                                        ;   in Loop: Header=BB0_23 Depth=1
	mov.d	x13, v5[1]
	st1.b	{ v9 }[3], [x13]
	add.2d	v5, v25, v28
	add.2d	v6, v5, v8
	tbz	w12, #4, LBB0_28
LBB0_35:                                ; %cond.store77
                                        ;   in Loop: Header=BB0_23 Depth=1
	fmov	x13, d6
	st1.b	{ v9 }[4], [x13]
	tbz	w12, #5, LBB0_29
LBB0_36:                                ; %cond.store79
                                        ;   in Loop: Header=BB0_23 Depth=1
	mov.d	x13, v6[1]
	st1.b	{ v9 }[5], [x13]
	add.2d	v6, v23, v19
	add.2d	v8, v6, v8
	tbz	w12, #6, LBB0_30
LBB0_37:                                ; %cond.store81
                                        ;   in Loop: Header=BB0_23 Depth=1
	fmov	x13, d8
	st1.b	{ v9 }[6], [x13]
	tbz	w12, #7, LBB0_22
LBB0_38:                                ; %cond.store83
                                        ;   in Loop: Header=BB0_23 Depth=1
	mov.d	x12, v8[1]
	st1.b	{ v9 }[7], [x12]
	b	LBB0_22
LBB0_39:                                ; %direct.true87.preheader
	mov	x8, #0                          ; =0x0
	fmov	w9, s2
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #2240
	mov	w13, #62154                     ; =0xf2ca
	movk	w13, #61769, lsl #16
	dup.4s	v18, w13
	add	x13, sp, #1, lsl #12            ; =4096
	add	x13, x13, #448
	b	LBB0_41
LBB0_40:                                ; %else116
                                        ;   in Loop: Header=BB0_41 Depth=1
	cmeq.8b	v19, v19, #0
	sshll.8h	v19, v19, #0
	sshll2.4s	v20, v19, #0
	sshll.4s	v19, v19, #0
	lsl	x14, x8, #5
	add	x15, x12, x14
	ldp	q21, q22, [x15]
	and.16b	v22, v0, v22
	and.16b	v21, v1, v21
	bsl.16b	v19, v18, v21
	bsl.16b	v20, v18, v22
	add	x14, x13, x14
	ldp	q21, q22, [x14]
	bif.16b	v20, v22, v0
	bif.16b	v19, v21, v1
	stp	q19, q20, [x14]
	add	x8, x8, #1
	cmp	x8, #96
	b.eq	LBB0_57
LBB0_41:                                ; %direct.true87
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v20, x8
	add.2d	v21, v3, v20
	tbz	w9, #0, LBB0_50
; %bb.42:                               ; %cond.load86
                                        ;   in Loop: Header=BB0_41 Depth=1
	fmov	x14, d21
	ldr	b19, [x14]
	and	w14, w9, #0xff
	tbz	w14, #1, LBB0_44
LBB0_43:                                ; %cond.load90
                                        ;   in Loop: Header=BB0_41 Depth=1
	mov.d	x15, v21[1]
	ld1.b	{ v19 }[1], [x15]
LBB0_44:                                ; %else92
                                        ;   in Loop: Header=BB0_41 Depth=1
	add.2d	v21, v4, v20
	tbnz	w14, #2, LBB0_51
; %bb.45:                               ; %else96
                                        ;   in Loop: Header=BB0_41 Depth=1
	tbnz	w14, #3, LBB0_52
LBB0_46:                                ; %else100
                                        ;   in Loop: Header=BB0_41 Depth=1
	add.2d	v21, v5, v20
	tbnz	w14, #4, LBB0_53
LBB0_47:                                ; %else104
                                        ;   in Loop: Header=BB0_41 Depth=1
	tbnz	w14, #5, LBB0_54
LBB0_48:                                ; %else108
                                        ;   in Loop: Header=BB0_41 Depth=1
	add.2d	v20, v6, v20
	tbnz	w14, #6, LBB0_55
LBB0_49:                                ; %else112
                                        ;   in Loop: Header=BB0_41 Depth=1
	tbz	w14, #7, LBB0_40
	b	LBB0_56
LBB0_50:                                ;   in Loop: Header=BB0_41 Depth=1
	movi.2d	v19, #0000000000000000
	and	w14, w9, #0xff
	tbnz	w14, #1, LBB0_43
	b	LBB0_44
LBB0_51:                                ; %cond.load94
                                        ;   in Loop: Header=BB0_41 Depth=1
	fmov	x15, d21
	ld1.b	{ v19 }[2], [x15]
	tbz	w14, #3, LBB0_46
LBB0_52:                                ; %cond.load98
                                        ;   in Loop: Header=BB0_41 Depth=1
	mov.d	x15, v21[1]
	ld1.b	{ v19 }[3], [x15]
	add.2d	v21, v5, v20
	tbz	w14, #4, LBB0_47
LBB0_53:                                ; %cond.load102
                                        ;   in Loop: Header=BB0_41 Depth=1
	fmov	x15, d21
	ld1.b	{ v19 }[4], [x15]
	tbz	w14, #5, LBB0_48
LBB0_54:                                ; %cond.load106
                                        ;   in Loop: Header=BB0_41 Depth=1
	mov.d	x15, v21[1]
	ld1.b	{ v19 }[5], [x15]
	add.2d	v20, v6, v20
	tbz	w14, #6, LBB0_49
LBB0_55:                                ; %cond.load110
                                        ;   in Loop: Header=BB0_41 Depth=1
	fmov	x15, d20
	ld1.b	{ v19 }[6], [x15]
	tbz	w14, #7, LBB0_40
LBB0_56:                                ; %cond.load114
                                        ;   in Loop: Header=BB0_41 Depth=1
	mov.d	x14, v20[1]
	ld1.b	{ v19 }[7], [x14]
	b	LBB0_40
LBB0_57:                                ; %direct.false88
	ldr	q18, [x10, #4352]
	ldr	q19, [x10, #4368]
	ldr	q20, [x10, #4384]
	ldr	q21, [x10, #4400]
	ldr	q22, [x10, #4416]
	ldr	q25, [x10, #4432]
	ldr	q26, [x10, #4448]
	and.16b	v19, v0, v19
	and.16b	v18, v1, v18
	ldr	q27, [x10, #4464]
	and.16b	v24, v0, v21
	and.16b	v23, v1, v20
	and.16b	v20, v0, v25
	and.16b	v25, v1, v22
	and.16b	v22, v0, v27
	and.16b	v21, v1, v26
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #448
	add	x8, x8, #224
	mov	w9, #4                          ; =0x4
LBB0_58:                                ; %direct.true119
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q26, q27, [x8, #-96]
	and.16b	v27, v0, v27
	and.16b	v26, v1, v26
	fmaxnm.4s	v26, v18, v26
	fmaxnm.4s	v27, v19, v27
	ldp	q28, q29, [x8, #-64]
	and.16b	v29, v0, v29
	and.16b	v28, v1, v28
	fmaxnm.4s	v28, v23, v28
	fmaxnm.4s	v29, v24, v29
	ldp	q30, q31, [x8, #-32]
	and.16b	v31, v0, v31
	and.16b	v30, v1, v30
	fmaxnm.4s	v30, v25, v30
	fmaxnm.4s	v31, v20, v31
	ldp	q8, q9, [x8], #128
	and.16b	v9, v0, v9
	and.16b	v8, v1, v8
	fmaxnm.4s	v8, v21, v8
	fmaxnm.4s	v9, v22, v9
	bit.16b	v19, v27, v0
	bit.16b	v18, v26, v1
	bit.16b	v24, v29, v0
	bit.16b	v23, v28, v1
	bit.16b	v20, v31, v0
	bit.16b	v25, v30, v1
	bit.16b	v22, v9, v0
	bit.16b	v21, v8, v1
	cmp	x9, #92
	add	x9, x9, #4
	b.lo	LBB0_58
; %bb.59:                               ; %direct.false120
	mov	x21, #0                         ; =0x0
	xtn.8b	v7, v7
	fmaxnm.4s	v19, v19, v24
	fmaxnm.4s	v18, v18, v23
	fmaxnm.4s	v18, v18, v25
	fmaxnm.4s	v19, v19, v20
	fmaxnm.4s	v19, v19, v22
	fmaxnm.4s	v20, v18, v21
	and.16b	v18, v1, v16
	and.16b	v17, v0, v17
	movi.4s	v16, #1
	eor.16b	v22, v17, v16
	eor.16b	v25, v18, v16
	umov.b	w12, v7[0]
	str	q20, [x10, #1232]
	ldr	s21, [x10, #1236]
	umov.b	w13, v7[1]
	ands	w8, w12, #0x1
	tst	w8, w13
	movi.2d	v16, #0000000000000000
	fcsel	s21, s21, s16, ne
	mov.s	w9, v25[1]
	add	x14, sp, #1392
	orr	x14, x14, x9, lsl #2
	add	x2, sp, #648
	add	x15, sp, #648
	bfxil	x15, x9, #0, #3
	str	d7, [x10, #456]
	ldrb	w9, [x15]
	and	w9, w13, w9
	str	q20, [x10, #1200]
	str	q19, [x10, #1216]
	ldr	s23, [x14]
	tst	w9, #0x1
	fcsel	s23, s23, s16, ne
	mov.s	w9, v25[2]
	add	x14, sp, #1360
	orr	x14, x14, x9, lsl #2
	add	x16, sp, #648
	bfxil	x16, x9, #0, #3
	umov.b	w15, v7[2]
	ldrb	w9, [x16]
	and	w9, w15, w9
	str	q20, [x10, #1168]
	str	q19, [x10, #1184]
	ldr	s24, [x14]
	tst	w9, #0x1
	fcsel	s24, s24, s16, ne
	mov.s	w9, v25[3]
	add	x14, sp, #1328
	orr	x14, x14, x9, lsl #2
	add	x16, sp, #648
	bfxil	x16, x9, #0, #3
	ldrb	w9, [x16]
	umov.b	w16, v7[3]
	and	w9, w16, w9
	str	q20, [x10, #1136]
	str	q19, [x10, #1152]
	ldr	s25, [x14]
	tst	w9, #0x1
	fcsel	s25, s25, s16, ne
	fmov	w9, s22
	add	x14, sp, #648
	bfxil	x14, x9, #0, #3
	ldrb	w17, [x14]
	umov.b	w14, v7[4]
	and	w17, w14, w17
	str	q20, [x10, #1104]
	str	q19, [x10, #1120]
	add	x0, sp, #1296
	ldr	s26, [x0, w9, uxtw #2]
	tst	w17, #0x1
	fcsel	s26, s26, s16, ne
	mov.s	w9, v22[1]
	add	x0, sp, #648
	bfxil	x0, x9, #0, #3
	umov.b	w17, v7[5]
	ldrb	w0, [x0]
	str	q20, [x10, #1072]
	str	q19, [x10, #1088]
	add	x1, sp, #1264
	ldr	s27, [x1, w9, uxtw #2]
	and	w9, w17, w0
	tst	w9, #0x1
	fcsel	s27, s27, s16, ne
	mov.s	w9, v22[2]
	add	x0, sp, #648
	bfxil	x0, x9, #0, #3
	ldrb	w1, [x0]
	umov.b	w0, v7[6]
	and	w1, w0, w1
	str	q20, [x10, #1040]
	str	q19, [x10, #1056]
	add	x3, sp, #1232
	ldr	s28, [x3, w9, uxtw #2]
	tst	w1, #0x1
	fcsel	s28, s28, s16, ne
	mov.s	w9, v22[3]
	add	x3, sp, #648
	bfxil	x3, x9, #0, #3
	umov.b	w1, v7[7]
	ldrb	w3, [x3]
	stp	q20, q19, [x10, #1008]
	add	x4, sp, #1200
	ldr	s22, [x4, w9, uxtw #2]
	and	w9, w1, w3
	tst	w9, #0x1
	mov.s	v21[1], v23[0]
	mov.s	v21[2], v24[0]
	mov.s	v21[3], v25[0]
	mov.s	v26[1], v27[0]
	mov.s	v26[2], v28[0]
	fcsel	s22, s22, s16, ne
	mov.s	v26[3], v22[0]
	fmaxnm.4s	v19, v19, v26
	fmaxnm.4s	v20, v20, v21
	movi.4s	v21, #2
	eor.16b	v22, v17, v21
	eor.16b	v24, v18, v21
	str	q20, [x10, #976]
	ldr	s17, [x10, #984]
	tst	w8, w15
	fcsel	s17, s17, s16, ne
	mov.s	w9, v24[1]
	add	x3, sp, #1136
	orr	x3, x3, x9, lsl #2
	add	x4, sp, #648
	bfxil	x4, x9, #0, #3
	ldrb	w9, [x4]
	and	w9, w13, w9
	stp	q20, q19, [x10, #944]
	ldr	s21, [x3]
	tst	w9, #0x1
	fcsel	s21, s21, s16, ne
	mov.s	w9, v24[2]
	add	x3, sp, #1104
	orr	x3, x3, x9, lsl #2
	add	x4, sp, #648
	bfxil	x4, x9, #0, #3
	ldrb	w9, [x4]
	and	w9, w15, w9
	stp	q20, q19, [x10, #912]
	ldr	s23, [x3]
	tst	w9, #0x1
	fcsel	s23, s23, s16, ne
	mov.s	w9, v24[3]
	add	x3, sp, #1072
	orr	x3, x3, x9, lsl #2
	add	x4, sp, #648
	bfxil	x4, x9, #0, #3
	ldrb	w9, [x4]
	and	w9, w16, w9
	stp	q20, q19, [x10, #880]
	ldr	s24, [x3]
	tst	w9, #0x1
	fcsel	s24, s24, s16, ne
	fmov	w9, s22
	add	x3, sp, #648
	bfxil	x3, x9, #0, #3
	ldrb	w3, [x3]
	stp	q20, q19, [x10, #848]
	add	x4, sp, #1040
	ldr	s25, [x4, w9, uxtw #2]
	and	w9, w14, w3
	tst	w9, #0x1
	fcsel	s25, s25, s16, ne
	mov.s	w9, v22[1]
	add	x3, sp, #648
	bfxil	x3, x9, #0, #3
	ldrb	w3, [x3]
	and	w3, w17, w3
	stp	q20, q19, [x10, #816]
	add	x4, sp, #1008
	ldr	s26, [x4, w9, uxtw #2]
	tst	w3, #0x1
	fcsel	s26, s26, s16, ne
	mov.s	w9, v22[2]
	add	x3, sp, #648
	bfxil	x3, x9, #0, #3
	ldrb	w3, [x3]
	and	w3, w0, w3
	stp	q20, q19, [x10, #784]
	add	x4, sp, #976
	ldr	s27, [x4, w9, uxtw #2]
	tst	w3, #0x1
	mov.s	w9, v22[3]
	fcsel	s22, s27, s16, ne
	add	x3, sp, #648
	bfxil	x3, x9, #0, #3
	ldrb	w3, [x3]
	and	w3, w1, w3
	stp	q20, q19, [x10, #752]
	add	x4, sp, #944
	ldr	s27, [x4, w9, uxtw #2]
	tst	w3, #0x1
	fcsel	s27, s27, s16, ne
	mov.s	v25[1], v26[0]
	mov.s	v25[2], v22[0]
	mov.s	v25[3], v27[0]
	mov.s	v17[1], v21[0]
	mov.s	v17[2], v23[0]
	mov.s	v17[3], v24[0]
	fmaxnm.4s	v17, v20, v17
	fmaxnm.4s	v19, v19, v25
	orr.4s	v18, #4
	str	q19, [x10, #736]
	ldr	s20, [x10, #736]
	tst	w8, w14
	fcsel	s20, s20, s16, ne
	mov.s	w8, v18[1]
	add	x9, sp, #648
	bfxil	x9, x8, #0, #3
	ldrb	w9, [x9]
	and	w9, w13, w9
	stp	q17, q19, [x10, #688]
	add	x3, sp, #880
	ldr	s21, [x3, w8, uxtw #2]
	tst	w9, #0x1
	fcsel	s21, s21, s16, ne
	mov.s	w8, v18[2]
	add	x9, sp, #648
	bfxil	x9, x8, #0, #3
	ldrb	w9, [x9]
	stp	q17, q19, [x10, #656]
	add	x3, sp, #848
	ldr	s22, [x3, w8, uxtw #2]
	and	w8, w15, w9
	tst	w8, #0x1
	fcsel	s22, s22, s16, ne
	mov.s	w8, v18[3]
	bfxil	x2, x8, #0, #3
	ldrb	w9, [x2]
	stp	q17, q19, [x10, #624]
	add	x2, sp, #816
	ldr	s18, [x2, w8, uxtw #2]
	and	w8, w16, w9
	tst	w8, #0x1
	fcsel	s18, s18, s16, ne
	ands	w2, w12, #0x1
	mov.s	v20[1], v21[0]
	mov.s	v20[2], v22[0]
	mov.s	v20[3], v18[0]
	fmaxnm.4s	v17, v17, v20
	fcsel	s18, s17, s16, ne
	and	w9, w13, w12
	and	w8, w13, w12
	str	w8, [sp, #28]                   ; 4-byte Spill
	tst	w9, #0x1
	fcsel	s19, s17, s16, ne
	and	w9, w15, w12
	and	w8, w15, w12
	str	w8, [sp, #24]                   ; 4-byte Spill
	tst	w9, #0x1
	fcsel	s20, s17, s16, ne
	and	w9, w16, w12
	and	w8, w16, w12
	str	w8, [sp, #20]                   ; 4-byte Spill
	tst	w9, #0x1
	fcsel	s21, s17, s16, ne
	and	w9, w14, w12
	and	w8, w14, w12
	str	w8, [sp, #16]                   ; 4-byte Spill
	tst	w9, #0x1
	fcsel	s22, s17, s16, ne
	and	w7, w17, w12
	tst	w7, #0x1
	fcsel	s23, s17, s16, ne
	and	w19, w0, w12
	tst	w19, #0x1
	fcsel	s24, s17, s16, ne
	and	w20, w1, w12
	tst	w20, #0x1
	mov.s	v18[1], v19[0]
	mov.s	v18[2], v20[0]
	mov.s	v18[3], v21[0]
	mov.s	v22[1], v23[0]
	mov.s	v22[2], v24[0]
	fcsel	s16, s17, s16, ne
	mov.s	v22[3], v16[0]
	rbit	w8, w11
	clz	w11, w8
	stp	q18, q22, [x10, #464]
	and	x8, x11, #0x7
	add	x9, sp, #656
	ldr	s16, [x9, x8, lsl #2]
	mov	w8, #-8388608                   ; =0xff800000
	fmov	s17, w8
	fmaxnm	s16, s16, s17
	dup.4s	v16, v16[0]
	add	x22, sp, #1, lsl #12            ; =4096
	add	x22, x22, #448
	mov	w23, #-1026555904               ; =0xc2d00000
	mov	w24, #1120403456                ; =0x42c80000
	mov	w25, #43579                     ; =0xaa3b
	movk	w25, #16312, lsl #16
	movi.4s	v17, #75, lsl #24
	mvni.4s	v18, #128, lsl #24
	mov	w26, #29184                     ; =0x7200
	movk	w26, #48945, lsl #16
	mov	w27, #48782                     ; =0xbe8e
	movk	w27, #46527, lsl #16
	mov	w28, #11226                     ; =0x2bda
	movk	w28, #14672, lsl #16
	mov	w30, #38601                     ; =0x96c9
	movk	w30, #15030, lsl #16
	mov	w8, #34982                      ; =0x88a6
	movk	w8, #15368, lsl #16
	mov	w9, #43642                      ; =0xaa7a
	movk	w9, #15658, lsl #16
	mov	w3, #43691                      ; =0xaaab
	movk	w3, #15914, lsl #16
	movi.4s	v19, #63, lsl #24
	fmov.4s	v20, #1.00000000
	mvni.4s	v21, #127, msl #16
	fneg.4s	v21, v21
	mvni.4s	v22, #63, msl #16
	fneg.4s	v22, v22
	add	x4, sp, #1472
	b	LBB0_61
LBB0_60:                                ; %else165
                                        ;   in Loop: Header=BB0_61 Depth=1
	cmeq.8b	v23, v23, #0
	sshll.8h	v24, v23, #0
	sshll2.4s	v23, v24, #0
	sshll.4s	v24, v24, #0
	lsl	x5, x21, #5
	add	x6, x22, x5
	ldp	q26, q25, [x6]
	fsub.4s	v26, v26, v16
	fsub.4s	v25, v25, v16
	and.16b	v25, v0, v25
	dup.4s	v27, w23
	and.16b	v26, v1, v26
	fcmge.4s	v29, v26, v27
	fcmge.4s	v30, v25, v27
	dup.4s	v28, w24
	fcmge.4s	v31, v28, v26
	fcmge.4s	v8, v28, v25
	and.16b	v30, v30, v8
	and.16b	v29, v29, v31
	and.16b	v29, v29, v26
	dup.4s	v31, w25
	and.16b	v30, v30, v25
	fmul.4s	v8, v30, v31
	fmul.4s	v31, v29, v31
	mov.16b	v9, v18
	bsl.16b	v9, v17, v31
	mov.16b	v10, v18
	bsl.16b	v10, v17, v8
	fadd.4s	v8, v8, v10
	fadd.4s	v31, v31, v9
	fsub.4s	v31, v31, v9
	fsub.4s	v8, v8, v10
	fcvtzs.4s	v8, v8
	fcvtzs.4s	v31, v31
	scvtf.4s	v9, v31
	scvtf.4s	v10, v8
	dup.4s	v11, w26
	fmul.4s	v12, v10, v11
	fmul.4s	v11, v9, v11
	fadd.4s	v29, v29, v11
	fadd.4s	v30, v30, v12
	dup.4s	v11, w27
	fmul.4s	v9, v9, v11
	fmul.4s	v10, v10, v11
	fadd.4s	v30, v30, v10
	fadd.4s	v29, v29, v9
	dup.4s	v9, w28
	fmul.4s	v10, v29, v9
	dup.4s	v11, w30
	fmul.4s	v9, v30, v9
	fadd.4s	v9, v9, v11
	fadd.4s	v10, v10, v11
	fmul.4s	v10, v29, v10
	dup.4s	v11, w8
	fmul.4s	v9, v30, v9
	fadd.4s	v9, v9, v11
	fadd.4s	v10, v10, v11
	fmul.4s	v10, v29, v10
	dup.4s	v11, w9
	fmul.4s	v9, v30, v9
	fadd.4s	v9, v9, v11
	fadd.4s	v10, v10, v11
	fmul.4s	v10, v29, v10
	dup.4s	v11, w3
	fmul.4s	v9, v30, v9
	fadd.4s	v9, v9, v11
	fadd.4s	v10, v10, v11
	fmul.4s	v10, v29, v10
	fmul.4s	v9, v30, v9
	fadd.4s	v9, v9, v19
	fadd.4s	v10, v10, v19
	fmul.4s	v11, v30, v30
	fmul.4s	v12, v29, v29
	fmul.4s	v10, v12, v10
	fmul.4s	v9, v11, v9
	fadd.4s	v30, v30, v9
	fadd.4s	v29, v29, v10
	fadd.4s	v29, v29, v20
	fadd.4s	v30, v30, v20
	sshr.4s	v9, v31, #1
	sshr.4s	v10, v8, #1
	shl.4s	v11, v10, #23
	shl.4s	v12, v9, #23
	add.4s	v12, v12, v20
	add.4s	v11, v11, v20
	fmul.4s	v30, v30, v11
	fmul.4s	v29, v29, v12
	sub.4s	v8, v8, v10
	sub.4s	v31, v31, v9
	shl.4s	v31, v31, #23
	shl.4s	v8, v8, #23
	add.4s	v8, v8, v20
	add.4s	v31, v31, v20
	fmul.4s	v29, v29, v31
	fmul.4s	v30, v30, v8
	fcmgt.4s	v31, v27, v25
	bic.16b	v30, v30, v31
	fcmgt.4s	v27, v27, v26
	bic.16b	v27, v29, v27
	fcmgt.4s	v29, v25, v28
	fcmgt.4s	v28, v26, v28
	bit.16b	v27, v21, v28
	mov.16b	v28, v29
	bsl.16b	v28, v21, v30
	fcmeq.4s	v26, v26, v26
	fcmeq.4s	v25, v25, v25
	bsl.16b	v25, v28, v22
	bsl.16b	v26, v27, v22
	bic.16b	v24, v26, v24
	bic.16b	v23, v25, v23
	add	x5, x4, x5
	ldp	q25, q26, [x5]
	bif.16b	v23, v26, v0
	bif.16b	v24, v25, v1
	stp	q24, q23, [x5]
	add	x21, x21, #1
	cmp	x21, #96
	b.eq	LBB0_77
LBB0_61:                                ; %direct.true156
                                        ; =>This Inner Loop Header: Depth=1
	fmov	w5, s2
	dup.2d	v24, x21
	add.2d	v25, v3, v24
	tbz	w5, #0, LBB0_70
; %bb.62:                               ; %cond.load119
                                        ;   in Loop: Header=BB0_61 Depth=1
	fmov	x6, d25
	ldr	b23, [x6]
	and	w5, w5, #0xff
	tbz	w5, #1, LBB0_64
LBB0_63:                                ; %cond.load125
                                        ;   in Loop: Header=BB0_61 Depth=1
	mov.d	x6, v25[1]
	ld1.b	{ v23 }[1], [x6]
LBB0_64:                                ; %else129
                                        ;   in Loop: Header=BB0_61 Depth=1
	add.2d	v25, v4, v24
	tbnz	w5, #2, LBB0_71
; %bb.65:                               ; %else135
                                        ;   in Loop: Header=BB0_61 Depth=1
	tbnz	w5, #3, LBB0_72
LBB0_66:                                ; %else141
                                        ;   in Loop: Header=BB0_61 Depth=1
	add.2d	v25, v5, v24
	tbnz	w5, #4, LBB0_73
LBB0_67:                                ; %else147
                                        ;   in Loop: Header=BB0_61 Depth=1
	tbnz	w5, #5, LBB0_74
LBB0_68:                                ; %else153
                                        ;   in Loop: Header=BB0_61 Depth=1
	add.2d	v24, v6, v24
	tbnz	w5, #6, LBB0_75
LBB0_69:                                ; %else159
                                        ;   in Loop: Header=BB0_61 Depth=1
	tbz	w5, #7, LBB0_60
	b	LBB0_76
LBB0_70:                                ;   in Loop: Header=BB0_61 Depth=1
	movi.2d	v23, #0000000000000000
	and	w5, w5, #0xff
	tbnz	w5, #1, LBB0_63
	b	LBB0_64
LBB0_71:                                ; %cond.load131
                                        ;   in Loop: Header=BB0_61 Depth=1
	fmov	x6, d25
	ld1.b	{ v23 }[2], [x6]
	tbz	w5, #3, LBB0_66
LBB0_72:                                ; %cond.load137
                                        ;   in Loop: Header=BB0_61 Depth=1
	mov.d	x6, v25[1]
	ld1.b	{ v23 }[3], [x6]
	add.2d	v25, v5, v24
	tbz	w5, #4, LBB0_67
LBB0_73:                                ; %cond.load143
                                        ;   in Loop: Header=BB0_61 Depth=1
	fmov	x6, d25
	ld1.b	{ v23 }[4], [x6]
	tbz	w5, #5, LBB0_68
LBB0_74:                                ; %cond.load149
                                        ;   in Loop: Header=BB0_61 Depth=1
	mov.d	x6, v25[1]
	ld1.b	{ v23 }[5], [x6]
	add.2d	v24, v6, v24
	tbz	w5, #6, LBB0_69
LBB0_75:                                ; %cond.load155
                                        ;   in Loop: Header=BB0_61 Depth=1
	fmov	x6, d24
	ld1.b	{ v23 }[6], [x6]
	tbz	w5, #7, LBB0_60
LBB0_76:                                ; %cond.load161
                                        ;   in Loop: Header=BB0_61 Depth=1
	mov.d	x5, v24[1]
	ld1.b	{ v23 }[7], [x5]
	b	LBB0_60
LBB0_77:                                ; %direct.false157
	ldr	q3, [x10, #1280]
	ldr	q4, [x10, #1296]
	ldr	q5, [x10, #1312]
	ldr	q6, [x10, #1328]
	ldr	q18, [x10, #1344]
	ldr	q17, [x10, #1360]
	ldr	q19, [x10, #1376]
	and.16b	v16, v0, v4
	and.16b	v3, v1, v3
	ldr	q4, [x10, #1392]
	and.16b	v22, v0, v6
	and.16b	v21, v1, v5
	and.16b	v17, v0, v17
	and.16b	v23, v1, v18
	and.16b	v20, v0, v4
	and.16b	v19, v1, v19
	add	x8, sp, #1472
	add	x8, x8, #224
	mov	w9, #4                          ; =0x4
LBB0_78:                                ; %direct.true191
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q5, q4, [x8, #-96]
	fadd.4s	v5, v3, v5
	fadd.4s	v4, v16, v4
	ldp	q18, q6, [x8, #-64]
	fadd.4s	v18, v21, v18
	fadd.4s	v6, v22, v6
	ldp	q25, q24, [x8, #-32]
	fadd.4s	v25, v23, v25
	fadd.4s	v24, v17, v24
	ldp	q27, q26, [x8], #128
	fadd.4s	v27, v19, v27
	fadd.4s	v26, v20, v26
	bit.16b	v16, v4, v0
	bit.16b	v3, v5, v1
	bit.16b	v22, v6, v0
	bit.16b	v21, v18, v1
	bit.16b	v17, v24, v0
	bit.16b	v23, v25, v1
	bit.16b	v20, v26, v0
	bit.16b	v19, v27, v1
	cmp	x9, #92
	add	x9, x9, #4
	b.lo	LBB0_78
; %bb.79:                               ; %direct.false192
	mov	x21, #0                         ; =0x0
Lloh22:
	adrp	x8, lCPI0_11@PAGE
Lloh23:
	ldr	q4, [x8, lCPI0_11@PAGEOFF]
	and.16b	v18, v0, v4
Lloh24:
	adrp	x8, lCPI0_12@PAGE
Lloh25:
	ldr	q4, [x8, lCPI0_12@PAGEOFF]
	and.16b	v24, v1, v4
Lloh26:
	adrp	x8, lCPI0_13@PAGE
Lloh27:
	ldr	q4, [x8, lCPI0_13@PAGEOFF]
	and.16b	v5, v0, v4
Lloh28:
	adrp	x8, lCPI0_14@PAGE
Lloh29:
	ldr	q4, [x8, lCPI0_14@PAGEOFF]
	and.16b	v6, v1, v4
	movi.4s	v4, #4
	and.16b	v4, v1, v4
	fadd.4s	v16, v16, v22
	fadd.4s	v3, v3, v21
	fadd.4s	v3, v3, v23
	fadd.4s	v16, v16, v17
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v3, v19
	fmov	w8, s24
	add	x9, sp, #56
	bfxil	x9, x8, #0, #3
	str	d7, [sp, #56]
	ldrb	w9, [x9]
	add	x3, sp, #608
	orr	x8, x3, x8, lsl #2
	stp	q17, q16, [x10, #416]
	ldr	s7, [x8]
	tst	w2, w9
	movi.2d	v3, #0000000000000000
	mov.s	w8, v24[1]
	fcsel	s19, s7, s3, ne
	add	x9, sp, #56
	bfxil	x9, x8, #0, #3
	ldrb	w8, [x9]
	and	w8, w13, w8
	str	q17, [x10, #384]
	ldr	s7, [x10, #384]
	tst	w8, #0x1
	fcsel	s7, s7, s3, ne
	mov.s	w8, v24[2]
	add	x9, sp, #544
	orr	x9, x9, x8, lsl #2
	add	x3, sp, #56
	bfxil	x3, x8, #0, #3
	ldrb	w8, [x3]
	and	w8, w15, w8
	stp	q17, q16, [x10, #352]
	ldr	s20, [x9]
	tst	w8, #0x1
	fcsel	s20, s20, s3, ne
	mov.s	w8, v24[3]
	add	x9, sp, #512
	orr	x9, x9, x8, lsl #2
	add	x3, sp, #56
	bfxil	x3, x8, #0, #3
	ldrb	w8, [x3]
	and	w8, w16, w8
	stp	q17, q16, [x10, #320]
	ldr	s21, [x9]
	tst	w8, #0x1
	fcsel	s21, s21, s3, ne
	fmov	w8, s18
	add	x9, sp, #56
	bfxil	x9, x8, #0, #3
	ldrb	w9, [x9]
	and	w9, w14, w9
	stp	q17, q16, [x10, #288]
	add	x3, sp, #480
	ldr	s22, [x3, w8, uxtw #2]
	tst	w9, #0x1
	mov.s	w8, v18[1]
	fcsel	s22, s22, s3, ne
	add	x9, sp, #56
	bfxil	x9, x8, #0, #3
	ldrb	w9, [x9]
	and	w9, w17, w9
	stp	q17, q16, [x10, #256]
	add	x3, sp, #448
	ldr	s23, [x3, w8, uxtw #2]
	tst	w9, #0x1
	fcsel	s23, s23, s3, ne
	mov.s	w8, v18[2]
	add	x9, sp, #56
	bfxil	x9, x8, #0, #3
	ldrb	w9, [x9]
	and	w9, w0, w9
	stp	q17, q16, [x10, #224]
	add	x3, sp, #416
	ldr	s24, [x3, w8, uxtw #2]
	tst	w9, #0x1
	fcsel	s24, s24, s3, ne
	mov.s	w8, v18[3]
	add	x9, sp, #56
	bfxil	x9, x8, #0, #3
	ldrb	w9, [x9]
	and	w9, w1, w9
	stp	q17, q16, [x10, #192]
	add	x3, sp, #384
	ldr	s18, [x3, w8, uxtw #2]
	tst	w9, #0x1
	fcsel	s18, s18, s3, ne
	mov.s	v19[1], v7[0]
	mov.s	v19[2], v20[0]
	mov.s	v19[3], v21[0]
	mov.s	v22[1], v23[0]
	mov.s	v22[2], v24[0]
	mov.s	v22[3], v18[0]
	fadd.4s	v7, v16, v22
	fadd.4s	v16, v17, v19
	fmov	w8, s6
	add	x9, sp, #56
	bfxil	x9, x8, #0, #3
	ldrb	w9, [x9]
	add	x3, sp, #352
	orr	x8, x3, x8, lsl #2
	stp	q16, q7, [x10, #160]
	ldr	s17, [x8]
	tst	w2, w9
	fcsel	s17, s17, s3, ne
	mov.s	w8, v6[1]
	add	x9, sp, #320
	orr	x9, x9, x8, lsl #2
	add	x3, sp, #56
	bfxil	x3, x8, #0, #3
	ldrb	w8, [x3]
	and	w8, w13, w8
	stp	q16, q7, [x10, #128]
	ldr	s18, [x9]
	tst	w8, #0x1
	fcsel	s18, s18, s3, ne
	mov.s	w8, v6[2]
	add	x9, sp, #56
	bfxil	x9, x8, #0, #3
	ldrb	w8, [x9]
	and	w8, w15, w8
	str	q16, [x10, #96]
	ldr	s19, [x10, #96]
	tst	w8, #0x1
	fcsel	s19, s19, s3, ne
	mov.s	w8, v6[3]
	add	x9, sp, #256
	orr	x9, x9, x8, lsl #2
	add	x13, sp, #56
	bfxil	x13, x8, #0, #3
	ldrb	w8, [x13]
	and	w8, w16, w8
	stp	q16, q7, [x10, #64]
	ldr	s6, [x9]
	tst	w8, #0x1
	fcsel	s6, s6, s3, ne
	fmov	w8, s5
	add	x9, sp, #56
	bfxil	x9, x8, #0, #3
	ldrb	w9, [x9]
	stp	q16, q7, [x10, #32]
	add	x13, sp, #224
	ldr	s20, [x13, w8, uxtw #2]
	and	w8, w14, w9
	tst	w8, #0x1
	fcsel	s20, s20, s3, ne
	mov.s	w8, v5[1]
	add	x9, sp, #56
	bfxil	x9, x8, #0, #3
	ldrb	w9, [x9]
	and	w9, w17, w9
	stp	q16, q7, [x10]
	add	x10, sp, #192
	ldr	s21, [x10, w8, uxtw #2]
	tst	w9, #0x1
	fcsel	s21, s21, s3, ne
	mov.s	w8, v5[2]
	add	x9, sp, #56
	bfxil	x9, x8, #0, #3
	ldrb	w9, [x9]
	and	w9, w0, w9
	stp	q16, q7, [sp, #160]
	add	x10, sp, #160
	ldr	s22, [x10, w8, uxtw #2]
	tst	w9, #0x1
	mov.s	w8, v5[3]
	fcsel	s5, s22, s3, ne
	add	x9, sp, #56
	bfxil	x9, x8, #0, #3
	ldrb	w9, [x9]
	and	w9, w1, w9
	stp	q16, q7, [sp, #128]
	add	x10, sp, #128
	ldr	s22, [x10, w8, uxtw #2]
	tst	w9, #0x1
	fcsel	s22, s22, s3, ne
	mov.s	v20[1], v21[0]
	mov.s	v20[2], v5[0]
	mov.s	v20[3], v22[0]
	mov.s	v17[1], v18[0]
	mov.s	v17[2], v19[0]
	mov.s	v17[3], v6[0]
	add	x8, sp, #56
	fadd.4s	v5, v16, v17
	fadd.4s	v6, v7, v20
	fmov	w9, s4
	orr	x8, x8, x9
	ldrb	w8, [x8]
	stp	q5, q6, [sp, #96]
	add	x10, sp, #96
	ldr	s4, [x10, w9, uxtw #2]
	tst	w2, w8
	fcsel	s4, s4, s3, ne
	tst	w12, #0x1
	fadd	s4, s5, s4
	fcsel	s5, s4, s3, ne
	ldp	w8, w10, [sp, #24]              ; 8-byte Folded Reload
	tst	w10, #0x1
	fcsel	s6, s4, s3, ne
	tst	w8, #0x1
	fcsel	s7, s4, s3, ne
	ldp	w8, w10, [sp, #16]              ; 8-byte Folded Reload
	tst	w10, #0x1
	fcsel	s16, s4, s3, ne
	tst	w8, #0x1
	fcsel	s17, s4, s3, ne
	tst	w7, #0x1
	fcsel	s18, s4, s3, ne
	tst	w19, #0x1
	fcsel	s19, s4, s3, ne
	tst	w20, #0x1
	fcsel	s4, s4, s3, ne
	mov.s	v5[1], v6[0]
	mov.s	v5[2], v7[0]
	mov.s	v5[3], v16[0]
	mov.s	v17[1], v18[0]
	mov.s	v17[2], v19[0]
	mov.s	v17[3], v4[0]
	stp	q5, q17, [sp, #64]
	and	x8, x11, #0x7
	add	x9, sp, #64
	ldr	s4, [x9, x8, lsl #2]
	fadd	s3, s4, s3
	dup.4s	v3, v3[0]
	ldp	x9, x8, [sp, #32]               ; 16-byte Folded Reload
	add	x8, x8, x9
	add	x9, sp, #1472
	b	LBB0_81
LBB0_80:                                ; %else183
                                        ;   in Loop: Header=BB0_81 Depth=1
	add	x21, x21, #32
	cmp	x21, #3072
	b.eq	LBB0_97
LBB0_81:                                ; %direct.true230
                                        ; =>This Inner Loop Header: Depth=1
	fmov	w11, s2
	add	x12, x9, x21
	ldr	q4, [x12]
	and.16b	v4, v1, v4
	fdiv.4s	v4, v4, v3
	add	x10, x8, x21
	tbnz	w11, #0, LBB0_89
; %bb.82:                               ; %else169
                                        ;   in Loop: Header=BB0_81 Depth=1
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB0_90
LBB0_83:                                ; %else171
                                        ;   in Loop: Header=BB0_81 Depth=1
	tbnz	w11, #2, LBB0_91
LBB0_84:                                ; %else173
                                        ;   in Loop: Header=BB0_81 Depth=1
	tbnz	w11, #3, LBB0_92
LBB0_85:                                ; %else175
                                        ;   in Loop: Header=BB0_81 Depth=1
	ldr	q4, [x12, #16]
	and.16b	v4, v0, v4
	fdiv.4s	v4, v4, v3
	tbnz	w11, #4, LBB0_93
LBB0_86:                                ; %else177
                                        ;   in Loop: Header=BB0_81 Depth=1
	tbnz	w11, #5, LBB0_94
LBB0_87:                                ; %else179
                                        ;   in Loop: Header=BB0_81 Depth=1
	tbnz	w11, #6, LBB0_95
LBB0_88:                                ; %else181
                                        ;   in Loop: Header=BB0_81 Depth=1
	tbz	w11, #7, LBB0_80
	b	LBB0_96
LBB0_89:                                ; %cond.store168
                                        ;   in Loop: Header=BB0_81 Depth=1
	str	s4, [x10]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB0_83
LBB0_90:                                ; %cond.store170
                                        ;   in Loop: Header=BB0_81 Depth=1
	add	x13, x10, #4
	st1.s	{ v4 }[1], [x13]
	tbz	w11, #2, LBB0_84
LBB0_91:                                ; %cond.store172
                                        ;   in Loop: Header=BB0_81 Depth=1
	add	x13, x10, #8
	st1.s	{ v4 }[2], [x13]
	tbz	w11, #3, LBB0_85
LBB0_92:                                ; %cond.store174
                                        ;   in Loop: Header=BB0_81 Depth=1
	add	x13, x10, #12
	st1.s	{ v4 }[3], [x13]
	ldr	q4, [x12, #16]
	and.16b	v4, v0, v4
	fdiv.4s	v4, v4, v3
	tbz	w11, #4, LBB0_86
LBB0_93:                                ; %cond.store176
                                        ;   in Loop: Header=BB0_81 Depth=1
	str	s4, [x10, #16]
	tbz	w11, #5, LBB0_87
LBB0_94:                                ; %cond.store178
                                        ;   in Loop: Header=BB0_81 Depth=1
	add	x12, x10, #20
	st1.s	{ v4 }[1], [x12]
	tbz	w11, #6, LBB0_88
LBB0_95:                                ; %cond.store180
                                        ;   in Loop: Header=BB0_81 Depth=1
	add	x12, x10, #24
	st1.s	{ v4 }[2], [x12]
	tbz	w11, #7, LBB0_80
LBB0_96:                                ; %cond.store182
                                        ;   in Loop: Header=BB0_81 Depth=1
	add	x10, x10, #28
	st1.s	{ v4 }[3], [x10]
	b	LBB0_80
LBB0_97:
	add	sp, sp, #4, lsl #12             ; =16384
	add	sp, sp, #1216
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #48]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #32]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #16]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp], #144            ; 16-byte Folded Reload
LBB0_98:                                ; %common.ret
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.full_packet
lCPI1_0:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI1_1:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI1_2:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI1_3:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI1_4:
	.quad	0                               ; 0x0
	.quad	96                              ; 0x60
lCPI1_5:
	.quad	192                             ; 0xc0
	.quad	288                             ; 0x120
lCPI1_6:
	.quad	384                             ; 0x180
	.quad	480                             ; 0x1e0
lCPI1_7:
	.quad	576                             ; 0x240
	.quad	672                             ; 0x2a0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows.full_packet:                  ; @llm_rows.full_packet
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-112]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	sub	sp, sp, #3, lsl #12             ; =12288
	sub	sp, sp, #3840
	ldr	x8, [x0]
	ldr	x19, [x0, #48]
	ldr	w9, [x1]
	ldr	w10, [x1, #36]
	add	w9, w10, w9, lsl #5
	lsr	w21, w9, #3
	mov	w9, #3072                       ; =0xc00
	umull	x20, w21, w9
	umaddl	x1, w21, w9, x8
	add	x0, sp, #3, lsl #12             ; =12288
	add	x0, x0, #768
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #2816
Lloh30:
	adrp	x10, lCPI1_0@PAGE
Lloh31:
	ldr	q0, [x10, lCPI1_0@PAGEOFF]
Lloh32:
	adrp	x10, lCPI1_1@PAGE
Lloh33:
	ldr	q1, [x10, lCPI1_1@PAGEOFF]
Lloh34:
	adrp	x10, lCPI1_2@PAGE
Lloh35:
	ldr	q2, [x10, lCPI1_2@PAGEOFF]
Lloh36:
	adrp	x10, lCPI1_3@PAGE
Lloh37:
	ldr	q3, [x10, lCPI1_3@PAGEOFF]
LBB1_1:                                 ; %direct.true58
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v4, x8
	orr.16b	v5, v4, v0
	orr.16b	v6, v4, v1
	orr.16b	v7, v4, v2
	orr.16b	v4, v4, v3
	stp	q7, q4, [x9, #32]
	stp	q5, q6, [x9], #64
	add	x8, x8, #8
	cmp	x8, #768
	b.ne	LBB1_1
; %bb.2:                                ; %direct.false59
	mov	x8, #0                          ; =0x0
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #2730, lsl #16
	umull	x9, w21, w9
	lsr	x9, x9, #37
	mov	w10, #768                       ; =0x300
	msub	w9, w9, w10, w21
	dup.2s	v0, w9
	ushll.2d	v4, v0, #0
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #2816
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #2048
	dup.2d	v5, x10
Lloh38:
	adrp	x10, lCPI1_4@PAGE
Lloh39:
	ldr	q0, [x10, lCPI1_4@PAGEOFF]
Lloh40:
	adrp	x10, lCPI1_5@PAGE
Lloh41:
	ldr	q1, [x10, lCPI1_5@PAGEOFF]
Lloh42:
	adrp	x10, lCPI1_6@PAGE
Lloh43:
	ldr	q2, [x10, lCPI1_6@PAGEOFF]
Lloh44:
	adrp	x10, lCPI1_7@PAGE
Lloh45:
	ldr	q3, [x10, lCPI1_7@PAGEOFF]
	movi.8b	v6, #1
LBB1_3:                                 ; %direct.true73
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v7, x8
	add	x10, x9, x8, lsl #6
	ldp	q17, q16, [x10, #32]
	ldp	q18, q19, [x10]
	add.2d	v7, v7, v5
	add.2d	v20, v7, v1
	add.2d	v21, v7, v0
	cmge.2d	v19, v4, v19
	cmge.2d	v18, v4, v18
	uzp1.4s	v18, v18, v19
	cmge.2d	v17, v4, v17
	cmge.2d	v16, v4, v16
	uzp1.4s	v16, v17, v16
	uzp1.8h	v16, v18, v16
	xtn.8b	v16, v16
	and.8b	v16, v16, v6
	mov.d	x10, v21[1]
	fmov	x11, d21
	str	b16, [x11]
	st1.b	{ v16 }[1], [x10]
	mov.d	x10, v20[1]
	fmov	x11, d20
	st1.b	{ v16 }[2], [x11]
	st1.b	{ v16 }[3], [x10]
	add.2d	v17, v7, v2
	mov.d	x10, v17[1]
	fmov	x11, d17
	st1.b	{ v16 }[4], [x11]
	add.2d	v7, v7, v3
	st1.b	{ v16 }[5], [x10]
	mov.d	x10, v7[1]
	fmov	x11, d7
	st1.b	{ v16 }[6], [x11]
	st1.b	{ v16 }[7], [x10]
	add	x8, x8, #1
	cmp	x8, #96
	b.ne	LBB1_3
; %bb.4:                                ; %direct.true87.preheader
	mov	x8, #0                          ; =0x0
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #2048
	dup.2d	v4, x9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #768
	mov	w10, #62154                     ; =0xf2ca
	movk	w10, #61769, lsl #16
	dup.4s	v5, w10
	add	x10, sp, #3072
LBB1_5:                                 ; %direct.true87
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v6, x8
	add.2d	v6, v6, v4
	add.2d	v7, v6, v3
	add.2d	v16, v6, v0
	mov.d	x11, v16[1]
	add.2d	v17, v6, v2
	add.2d	v6, v6, v1
	fmov	x12, d16
	mov.d	x13, v6[1]
	mov.d	x14, v17[1]
	fmov	x15, d6
	ldr	b6, [x12]
	ld1.b	{ v6 }[1], [x11]
	mov.d	x11, v7[1]
	fmov	x12, d17
	ld1.b	{ v6 }[2], [x15]
	ld1.b	{ v6 }[3], [x13]
	fmov	x13, d7
	ld1.b	{ v6 }[4], [x12]
	ld1.b	{ v6 }[5], [x14]
	ld1.b	{ v6 }[6], [x13]
	ld1.b	{ v6 }[7], [x11]
	cmeq.8b	v6, v6, #0
	sshll.8h	v6, v6, #0
	sshll2.4s	v7, v6, #0
	sshll.4s	v6, v6, #0
	lsl	x11, x8, #5
	add	x12, x9, x11
	ldp	q17, q16, [x12]
	bsl.16b	v6, v5, v17
	bsl.16b	v7, v5, v16
	add	x11, x10, x11
	stp	q6, q7, [x11]
	add	x8, x8, #1
	cmp	x8, #96
	b.ne	LBB1_5
; %bb.6:                                ; %direct.false88
	ldr	q4, [sp, #3088]
	ldr	q6, [sp, #3072]
	ldr	q5, [sp, #3120]
	ldr	q17, [sp, #3104]
	ldr	q16, [sp, #3152]
	ldr	q7, [sp, #3136]
	add	x8, sp, #3072
	add	x8, x8, #224
	mov	w9, #4                          ; =0x4
	ldr	q18, [sp, #3184]
	ldr	q19, [sp, #3168]
LBB1_7:                                 ; %direct.true119
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q20, q21, [x8, #-96]
	fmaxnm.4s	v4, v4, v21
	fmaxnm.4s	v6, v6, v20
	ldp	q20, q21, [x8, #-64]
	fmaxnm.4s	v5, v5, v21
	fmaxnm.4s	v17, v17, v20
	ldp	q20, q21, [x8, #-32]
	fmaxnm.4s	v16, v16, v21
	fmaxnm.4s	v7, v7, v20
	ldp	q20, q21, [x8], #128
	fmaxnm.4s	v18, v18, v21
	fmaxnm.4s	v19, v19, v20
	cmp	x9, #92
	add	x9, x9, #4
	b.lo	LBB1_7
; %bb.8:                                ; %direct.false120
	mov	x8, #0                          ; =0x0
	fmaxnm.4s	v6, v6, v17
	fmaxnm.4s	v4, v4, v5
	fmaxnm.4s	v4, v4, v16
	fmaxnm.4s	v5, v6, v7
	fmaxnm.4s	v5, v5, v19
	fmaxnm.4s	v4, v4, v18
	rev64.4s	v6, v4
	rev64.4s	v7, v5
	fmaxnm.4s	v5, v5, v7
	fmaxnm.4s	v4, v4, v6
	ext.16b	v6, v4, v4, #8
	ext.16b	v7, v5, v5, #8
	fmaxnm.4s	v5, v5, v7
	fmaxnm.4s	v4, v4, v6
	fmaxnm.4s	v4, v5, v4
	mov	w9, #-8388608                   ; =0xff800000
	fmov	s5, w9
	fmaxnm	s4, s4, s5
	dup.4s	v4, v4[0]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #2048
	dup.2d	v5, x9
	add	x9, sp, #3072
	mov	w10, #-1026555904               ; =0xc2d00000
	dup.4s	v6, w10
	mov	w10, #1120403456                ; =0x42c80000
	dup.4s	v7, w10
	mov	w10, #43579                     ; =0xaa3b
	movk	w10, #16312, lsl #16
	dup.4s	v16, w10
	movi.4s	v17, #75, lsl #24
	mvni.4s	v18, #128, lsl #24
	mov	w10, #29184                     ; =0x7200
	movk	w10, #48945, lsl #16
	dup.4s	v19, w10
	mov	w10, #48782                     ; =0xbe8e
	movk	w10, #46527, lsl #16
	dup.4s	v20, w10
	mov	w10, #11226                     ; =0x2bda
	movk	w10, #14672, lsl #16
	dup.4s	v21, w10
	mov	w10, #38601                     ; =0x96c9
	movk	w10, #15030, lsl #16
	dup.4s	v22, w10
	mov	w10, #34982                     ; =0x88a6
	movk	w10, #15368, lsl #16
	dup.4s	v23, w10
	mov	w10, #43642                     ; =0xaa7a
	movk	w10, #15658, lsl #16
	dup.4s	v24, w10
	mov	w10, #43691                     ; =0xaaab
	movk	w10, #15914, lsl #16
	dup.4s	v25, w10
	movi.4s	v26, #63, lsl #24
	fmov.4s	v27, #1.00000000
	mvni.4s	v28, #127, msl #16
	fneg.4s	v28, v28
	mvni.4s	v29, #63, msl #16
	fneg.4s	v29, v29
	mov	x10, sp
LBB1_9:                                 ; %direct.true156
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v30, x8
	add.2d	v8, v30, v5
	add.2d	v9, v8, v1
	add.2d	v30, v8, v0
	mov.d	x11, v30[1]
	lsl	x12, x8, #5
	fmov	x13, d30
	add	x14, x9, x12
	ldp	q30, q31, [x14]
	fsub.4s	v31, v31, v4
	mov.d	x14, v9[1]
	fsub.4s	v30, v30, v4
	fcmge.4s	v10, v30, v6
	fcmge.4s	v11, v31, v6
	fcmge.4s	v12, v7, v30
	fcmge.4s	v13, v7, v31
	and.16b	v11, v11, v13
	and.16b	v10, v10, v12
	and.16b	v10, v10, v30
	and.16b	v11, v11, v31
	fmul.4s	v12, v11, v16
	fmul.4s	v13, v10, v16
	mov.16b	v14, v18
	bsl.16b	v14, v17, v13
	mov.16b	v15, v18
	bsl.16b	v15, v17, v12
	fadd.4s	v12, v12, v15
	fadd.4s	v13, v13, v14
	fsub.4s	v13, v13, v14
	fsub.4s	v12, v12, v15
	fmov	x0, d9
	fcvtzs.4s	v9, v12
	fcvtzs.4s	v12, v13
	scvtf.4s	v13, v12
	scvtf.4s	v14, v9
	fmul.4s	v15, v13, v19
	fadd.4s	v10, v10, v15
	fmul.4s	v15, v14, v19
	fadd.4s	v11, v11, v15
	add.2d	v15, v8, v2
	mov.d	x16, v15[1]
	fmov	x17, d15
	add.2d	v8, v8, v3
	mov.d	x15, v8[1]
	fmul.4s	v13, v13, v20
	fmul.4s	v14, v14, v20
	fadd.4s	v11, v11, v14
	fadd.4s	v10, v10, v13
	fmul.4s	v13, v10, v21
	fmul.4s	v14, v11, v21
	fadd.4s	v14, v14, v22
	fadd.4s	v13, v13, v22
	fmul.4s	v13, v10, v13
	fmul.4s	v14, v11, v14
	fadd.4s	v14, v14, v23
	fadd.4s	v13, v13, v23
	fmul.4s	v13, v10, v13
	fmul.4s	v14, v11, v14
	fadd.4s	v14, v14, v24
	fadd.4s	v13, v13, v24
	fmul.4s	v13, v10, v13
	fmul.4s	v14, v11, v14
	fadd.4s	v14, v14, v25
	fadd.4s	v13, v13, v25
	fmov	x1, d8
	fmul.4s	v8, v10, v13
	fmul.4s	v13, v11, v14
	fadd.4s	v13, v13, v26
	fadd.4s	v8, v8, v26
	fmul.4s	v14, v10, v10
	fmul.4s	v8, v14, v8
	fmul.4s	v14, v11, v11
	fmul.4s	v13, v14, v13
	fadd.4s	v11, v11, v13
	fadd.4s	v8, v10, v8
	sshr.4s	v10, v12, #1
	fadd.4s	v11, v11, v27
	sshr.4s	v13, v9, #1
	shl.4s	v14, v13, #23
	add.4s	v14, v14, v27
	fmul.4s	v11, v11, v14
	shl.4s	v14, v10, #23
	fadd.4s	v8, v8, v27
	add.4s	v14, v14, v27
	fmul.4s	v8, v8, v14
	sub.4s	v9, v9, v13
	sub.4s	v10, v12, v10
	shl.4s	v10, v10, #23
	add.4s	v10, v10, v27
	fmul.4s	v8, v8, v10
	ldr	b10, [x13]
	ld1.b	{ v10 }[1], [x11]
	ld1.b	{ v10 }[2], [x0]
	ld1.b	{ v10 }[3], [x14]
	shl.4s	v9, v9, #23
	add.4s	v9, v9, v27
	fmul.4s	v9, v11, v9
	fcmgt.4s	v11, v6, v31
	bic.16b	v9, v9, v11
	fcmgt.4s	v11, v6, v30
	bic.16b	v8, v8, v11
	fcmgt.4s	v11, v30, v7
	bit.16b	v8, v28, v11
	fcmgt.4s	v11, v31, v7
	bit.16b	v9, v28, v11
	ld1.b	{ v10 }[4], [x17]
	ld1.b	{ v10 }[5], [x16]
	fcmeq.4s	v31, v31, v31
	bsl.16b	v31, v9, v29
	ld1.b	{ v10 }[6], [x1]
	ld1.b	{ v10 }[7], [x15]
	cmeq.8b	v9, v10, #0
	sshll.8h	v9, v9, #0
	fcmeq.4s	v30, v30, v30
	bsl.16b	v30, v8, v29
	sshll.4s	v8, v9, #0
	bic.16b	v30, v30, v8
	sshll2.4s	v8, v9, #0
	bic.16b	v31, v31, v8
	add	x11, x10, x12
	stp	q30, q31, [x11]
	add	x8, x8, #1
	cmp	x8, #96
	b.ne	LBB1_9
; %bb.10:                               ; %direct.false157
	ldp	q2, q0, [sp]
	ldp	q5, q1, [sp, #32]
	ldp	q3, q4, [sp, #64]
	mov	x8, sp
	add	x8, x8, #224
	mov	w9, #4                          ; =0x4
	ldp	q7, q6, [sp, #96]
LBB1_11:                                ; %direct.true191
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q16, q17, [x8, #-96]
	fadd.4s	v0, v0, v17
	fadd.4s	v2, v2, v16
	ldp	q16, q17, [x8, #-64]
	fadd.4s	v1, v1, v17
	fadd.4s	v5, v5, v16
	ldp	q16, q17, [x8, #-32]
	fadd.4s	v4, v4, v17
	fadd.4s	v3, v3, v16
	ldp	q16, q17, [x8], #128
	fadd.4s	v6, v6, v17
	fadd.4s	v7, v7, v16
	cmp	x9, #92
	add	x9, x9, #4
	b.lo	LBB1_11
; %bb.12:                               ; %direct.false192
	mov	x8, #0                          ; =0x0
	fadd.4s	v2, v2, v5
	fadd.4s	v0, v0, v1
	fadd.4s	v0, v0, v4
	fadd.4s	v1, v2, v3
	fadd.4s	v1, v1, v7
	fadd.4s	v0, v0, v6
	rev64.4s	v2, v0
	rev64.4s	v3, v1
	fadd.4s	v0, v0, v2
	dup.4s	v2, v0[2]
	fadd.4s	v1, v1, v3
	dup.4s	v3, v1[2]
	fadd.4s	v1, v1, v3
	fadd.4s	v0, v0, v2
	fadd.4s	v0, v1, v0
	movi.2d	v1, #0000000000000000
	fadd	s0, s0, s1
	dup.4s	v0, v0[0]
	add	x9, x19, x20
	mov	x10, sp
LBB1_13:                                ; %direct.true230
                                        ; =>This Inner Loop Header: Depth=1
	add	x11, x10, x8
	ldp	q2, q1, [x11]
	fdiv.4s	v2, v2, v0
	fdiv.4s	v1, v1, v0
	add	x11, x9, x8
	stp	q2, q1, [x11]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB1_13
; %bb.14:                               ; %common.ret
	add	sp, sp, #3, lsl #12             ; =12288
	add	sp, sp, #3840
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #112            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpAdrp	Lloh34, Lloh36
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpAdrp	Lloh32, Lloh34
	.loh AdrpLdr	Lloh32, Lloh33
	.loh AdrpAdrp	Lloh30, Lloh32
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpLdr	Lloh44, Lloh45
	.loh AdrpAdrp	Lloh42, Lloh44
	.loh AdrpLdr	Lloh42, Lloh43
	.loh AdrpAdrp	Lloh40, Lloh42
	.loh AdrpLdr	Lloh40, Lloh41
	.loh AdrpAdrp	Lloh38, Lloh40
	.loh AdrpLdr	Lloh38, Lloh39
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB2_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB2_4
LBB2_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB2_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB2_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB2_13
LBB2_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB2_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB2_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #1
	b.eq	LBB2_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #2
	b.eq	LBB2_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #3
	b.eq	LBB2_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB2_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB2_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
LBB2_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB2_3
LBB2_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB2_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_3:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_4:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_5:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_6:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_7:
	.quad	3072                            ; 0xc00
	.quad	3076                            ; 0xc04
lCPI0_8:
	.quad	3088                            ; 0xc10
	.quad	3092                            ; 0xc14
lCPI0_9:
	.quad	3080                            ; 0xc08
	.quad	3084                            ; 0xc0c
lCPI0_10:
	.quad	3096                            ; 0xc18
	.quad	3100                            ; 0xc1c
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_11:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	dup.4s	v0, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q1, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q2, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v4, v0, v2
	cmhi.4s	v5, v0, v1
	uzp1.8h	v18, v5, v4
	umaxv.8h	h0, v18
	fmov	w8, s0
	tbz	w8, #0, LBB0_392
; %bb.1:                                ; %direct.activate
	stp	d15, d14, [sp, #-80]!           ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #3, lsl #12             ; =12288
	sub	sp, sp, #1008
	ldr	x11, [x0]
	ldr	x10, [x0, #16]
	ldr	x9, [x0, #32]
	ldr	x8, [x0, #48]
	sshll.2d	v0, v5, #0
	sshll.2d	v1, v4, #0
	sshll2.2d	v21, v5, #0
	sshll2.2d	v20, v4, #0
	ldr	w12, [x1]
	ldr	w13, [x1, #36]
	add	w12, w13, w12, lsl #5
Lloh4:
	adrp	x13, lCPI0_2@PAGE
Lloh5:
	ldr	q2, [x13, lCPI0_2@PAGEOFF]
	and.16b	v11, v20, v2
Lloh6:
	adrp	x13, lCPI0_3@PAGE
Lloh7:
	ldr	q2, [x13, lCPI0_3@PAGEOFF]
	and.16b	v7, v21, v2
Lloh8:
	adrp	x13, lCPI0_4@PAGE
Lloh9:
	ldr	q2, [x13, lCPI0_4@PAGEOFF]
	and.16b	v13, v1, v2
Lloh10:
	adrp	x13, lCPI0_5@PAGE
Lloh11:
	ldr	q1, [x13, lCPI0_5@PAGEOFF]
	and.16b	v19, v0, v1
	lsr	w12, w12, #3
	dup.4s	v0, w12
	and.16b	v3, v5, v0
	and.16b	v1, v4, v0
	ushll2.2d	v0, v1, #0
	ushll2.2d	v2, v3, #0
	ushll.2d	v1, v1, #0
	ushll.2d	v3, v3, #0
	subs	x12, x11, x8
	cset	w13, hs
	mov	w17, #8199                      ; =0x2007
	movk	w17, #24, lsl #16
	cmp	x12, x17
	csel	w12, wzr, w13, ls
	subs	x13, x8, x11
	cset	w14, hs
	cmp	x13, x17
	csel	w14, wzr, w14, ls
	subs	x13, x10, x8
	cset	w15, hs
	cmp	x13, x17
	csel	w15, wzr, w15, ls
	subs	x13, x8, x10
	cset	w16, hs
	mov	w0, #4099                       ; =0x1003
	movk	w0, #12, lsl #16
	cmp	x13, x0
	csel	w16, wzr, w16, ls
	subs	x13, x9, x8
	cset	w1, hs
	cmp	x13, x17
	csel	w13, wzr, w1, ls
	subs	x17, x8, x9
	cset	w1, hs
	cmp	x17, x0
	csel	w17, wzr, w1, ls
	orr	w0, w13, w17
	xtn.2s	v24, v2
	xtn.2s	v25, v1
	xtn.2s	v23, v0
	xtn.2s	v26, v3
	adrp	x17, lCPI0_6@PAGE
	adrp	x13, lCPI0_11@PAGE
	cmp	w0, #1
	b.ne	LBB0_194
; %bb.2:                                ; %direct.activate
	orr	w12, w12, w14
	cbz	w12, LBB0_194
; %bb.3:                                ; %direct.activate
	orr	w12, w15, w16
	tbz	w12, #0, LBB0_194
; %bb.4:                                ; %direct.schedule.2.preheader
	mov	x12, #0                         ; =0x0
	mov	w14, #1538                      ; =0x602
	dup.2s	v6, w14
	umull.2d	v4, v24, v6
	umull.2d	v17, v25, v6
	umull.2d	v5, v23, v6
	umull.2d	v20, v26, v6
	fmov	x14, d3
	mov	w15, #769                       ; =0x301
	umull	x14, w14, w15
	fmov	x15, d20
	add	x15, x15, #769
	ldr	q6, [x17, lCPI0_6@PAGEOFF]
	and.16b	v6, v18, v6
	addv.8h	h21, v6
	fmov	w16, s21
	b	LBB0_6
LBB0_5:                                 ; %else133
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x12, x12, #8
	cmp	x12, #768
	b.eq	LBB0_102
LBB0_6:                                 ; %direct.true31
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v6, x12
	orr.16b	v24, v6, v19
	add.2d	v6, v24, v20
	fmov	x17, d6
	lsl	x17, x17, #2
	add	x0, x11, x17
	movi.2d	v23, #0000000000000000
	movi.2d	v22, #0000000000000000
	tbz	w16, #0, LBB0_14
; %bb.7:                                ; %cond.load
                                        ;   in Loop: Header=BB0_6 Depth=1
	ldr	s23, [x0]
	and	w1, w16, #0xff
	tbnz	w1, #1, LBB0_15
LBB0_8:                                 ; %else6
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w1, #2, LBB0_16
LBB0_9:                                 ; %cond.load8
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x2, x0, #8
	ld1.s	{ v23 }[2], [x2]
	tbnz	w1, #3, LBB0_17
LBB0_10:                                ; %else12
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w1, #4, LBB0_18
LBB0_11:                                ; %cond.load14
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x2, x0, #16
	ld1.s	{ v22 }[0], [x2]
	tbnz	w1, #5, LBB0_19
LBB0_12:                                ; %else18
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w1, #6, LBB0_20
LBB0_13:                                ; %cond.load20
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x2, x0, #24
	ld1.s	{ v22 }[2], [x2]
	tbnz	w1, #7, LBB0_21
	b	LBB0_22
LBB0_14:                                ; %else
                                        ;   in Loop: Header=BB0_6 Depth=1
	and	w1, w16, #0xff
	tbz	w1, #1, LBB0_8
LBB0_15:                                ; %cond.load5
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x2, x0, #4
	ld1.s	{ v23 }[1], [x2]
	tbnz	w1, #2, LBB0_9
LBB0_16:                                ; %else9
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w1, #3, LBB0_10
LBB0_17:                                ; %cond.load11
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x2, x0, #12
	ld1.s	{ v23 }[3], [x2]
	tbnz	w1, #4, LBB0_11
LBB0_18:                                ; %else15
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w1, #5, LBB0_12
LBB0_19:                                ; %cond.load17
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x2, x0, #20
	ld1.s	{ v22 }[1], [x2]
	tbnz	w1, #6, LBB0_13
LBB0_20:                                ; %else21
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w1, #7, LBB0_22
LBB0_21:                                ; %cond.load23
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x0, x0, #28
	ld1.s	{ v22 }[3], [x0]
LBB0_22:                                ; %else24
                                        ;   in Loop: Header=BB0_6 Depth=1
	fmov	w3, s21
	fmov	x1, d24
	add	x0, x15, x1
	lsl	x0, x0, #2
	add	x2, x11, x0
	movi.2d	v25, #0000000000000000
	movi.2d	v24, #0000000000000000
	tbz	w3, #0, LBB0_30
; %bb.23:                               ; %cond.load27
                                        ;   in Loop: Header=BB0_6 Depth=1
	ldr	s25, [x2]
	and	w3, w3, #0xff
	tbnz	w3, #1, LBB0_31
LBB0_24:                                ; %else31
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w3, #2, LBB0_32
LBB0_25:                                ; %cond.load33
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x4, x2, #8
	ld1.s	{ v25 }[2], [x4]
	tbnz	w3, #3, LBB0_33
LBB0_26:                                ; %else37
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w3, #4, LBB0_34
LBB0_27:                                ; %cond.load39
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x4, x2, #16
	ld1.s	{ v24 }[0], [x4]
	tbnz	w3, #5, LBB0_35
LBB0_28:                                ; %else43
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w3, #6, LBB0_36
LBB0_29:                                ; %cond.load45
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x4, x2, #24
	ld1.s	{ v24 }[2], [x4]
	tbnz	w3, #7, LBB0_37
	b	LBB0_38
LBB0_30:                                ; %else28
                                        ;   in Loop: Header=BB0_6 Depth=1
	and	w3, w3, #0xff
	tbz	w3, #1, LBB0_24
LBB0_31:                                ; %cond.load30
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x4, x2, #4
	ld1.s	{ v25 }[1], [x4]
	tbnz	w3, #2, LBB0_25
LBB0_32:                                ; %else34
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w3, #3, LBB0_26
LBB0_33:                                ; %cond.load36
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x4, x2, #12
	ld1.s	{ v25 }[3], [x4]
	tbnz	w3, #4, LBB0_27
LBB0_34:                                ; %else40
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w3, #5, LBB0_28
LBB0_35:                                ; %cond.load42
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x4, x2, #20
	ld1.s	{ v24 }[1], [x4]
	tbnz	w3, #6, LBB0_29
LBB0_36:                                ; %else46
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w3, #7, LBB0_38
LBB0_37:                                ; %cond.load48
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x2, x2, #28
	ld1.s	{ v24 }[3], [x2]
LBB0_38:                                ; %else49
                                        ;   in Loop: Header=BB0_6 Depth=1
	fmov	w3, s21
	add	x1, x1, x14
	lsl	x1, x1, #2
	add	x2, x10, x1
	movi.2d	v27, #0000000000000000
	movi.2d	v26, #0000000000000000
	tbz	w3, #0, LBB0_70
; %bb.39:                               ; %cond.load52
                                        ;   in Loop: Header=BB0_6 Depth=1
	ldr	s27, [x2]
	and	w3, w3, #0xff
	tbnz	w3, #1, LBB0_71
LBB0_40:                                ; %else56
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w3, #2, LBB0_72
LBB0_41:                                ; %cond.load58
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x4, x2, #8
	ld1.s	{ v27 }[2], [x4]
	tbnz	w3, #3, LBB0_73
LBB0_42:                                ; %else62
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w3, #4, LBB0_74
LBB0_43:                                ; %cond.load64
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x4, x2, #16
	ld1.s	{ v26 }[0], [x4]
	tbnz	w3, #5, LBB0_75
LBB0_44:                                ; %else68
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w3, #6, LBB0_76
LBB0_45:                                ; %cond.load70
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x4, x2, #24
	ld1.s	{ v26 }[2], [x4]
	tbnz	w3, #7, LBB0_77
LBB0_46:                                ; %else74
                                        ;   in Loop: Header=BB0_6 Depth=1
	fmov	w2, s21
	add	x1, x9, x1
	movi.2d	v29, #0000000000000000
	movi.2d	v28, #0000000000000000
	tbz	w2, #0, LBB0_78
LBB0_47:                                ; %cond.load77
                                        ;   in Loop: Header=BB0_6 Depth=1
	ldr	s29, [x1]
	and	w2, w2, #0xff
	tbnz	w2, #1, LBB0_79
LBB0_48:                                ; %else81
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w2, #2, LBB0_80
LBB0_49:                                ; %cond.load83
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x3, x1, #8
	ld1.s	{ v29 }[2], [x3]
	tbnz	w2, #3, LBB0_81
LBB0_50:                                ; %else87
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w2, #4, LBB0_82
LBB0_51:                                ; %cond.load89
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x3, x1, #16
	ld1.s	{ v28 }[0], [x3]
	tbnz	w2, #5, LBB0_83
LBB0_52:                                ; %else93
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w2, #6, LBB0_84
LBB0_53:                                ; %cond.load95
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x3, x1, #24
	ld1.s	{ v28 }[2], [x3]
	tbnz	w2, #7, LBB0_85
LBB0_54:                                ; %else99
                                        ;   in Loop: Header=BB0_6 Depth=1
	fmov	w1, s21
	fmul.4s	v6, v23, v27
	fmul.4s	v30, v25, v29
	fsub.4s	v6, v6, v30
	add	x17, x8, x17
	tbz	w1, #0, LBB0_86
LBB0_55:                                ; %cond.store
                                        ;   in Loop: Header=BB0_6 Depth=1
	str	s6, [x17]
	and	w1, w1, #0xff
	tbnz	w1, #1, LBB0_87
LBB0_56:                                ; %else104
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w1, #2, LBB0_88
LBB0_57:                                ; %cond.store105
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x2, x17, #8
	st1.s	{ v6 }[2], [x2]
	tbnz	w1, #3, LBB0_89
LBB0_58:                                ; %else108
                                        ;   in Loop: Header=BB0_6 Depth=1
	fmul.4s	v6, v22, v26
	fmul.4s	v30, v24, v28
	fsub.4s	v6, v6, v30
	tbz	w1, #4, LBB0_90
LBB0_59:                                ; %cond.store109
                                        ;   in Loop: Header=BB0_6 Depth=1
	str	s6, [x17, #16]
	tbnz	w1, #5, LBB0_91
LBB0_60:                                ; %else112
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w1, #6, LBB0_92
LBB0_61:                                ; %cond.store113
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x2, x17, #24
	st1.s	{ v6 }[2], [x2]
	tbnz	w1, #7, LBB0_93
LBB0_62:                                ; %else116
                                        ;   in Loop: Header=BB0_6 Depth=1
	fmov	w1, s21
	fmul.4s	v6, v23, v29
	fmul.4s	v23, v25, v27
	fadd.4s	v6, v23, v6
	add	x17, x8, x0
	tbz	w1, #0, LBB0_94
LBB0_63:                                ; %cond.store118
                                        ;   in Loop: Header=BB0_6 Depth=1
	str	s6, [x17]
	and	w0, w1, #0xff
	tbnz	w0, #1, LBB0_95
LBB0_64:                                ; %else121
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w0, #2, LBB0_96
LBB0_65:                                ; %cond.store122
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x1, x17, #8
	st1.s	{ v6 }[2], [x1]
	tbnz	w0, #3, LBB0_97
LBB0_66:                                ; %else125
                                        ;   in Loop: Header=BB0_6 Depth=1
	fmul.4s	v6, v22, v28
	fmul.4s	v22, v24, v26
	fadd.4s	v6, v22, v6
	tbz	w0, #4, LBB0_98
LBB0_67:                                ; %cond.store126
                                        ;   in Loop: Header=BB0_6 Depth=1
	str	s6, [x17, #16]
	tbnz	w0, #5, LBB0_99
LBB0_68:                                ; %else129
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w0, #6, LBB0_100
LBB0_69:                                ; %cond.store130
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x1, x17, #24
	st1.s	{ v6 }[2], [x1]
	tbz	w0, #7, LBB0_5
	b	LBB0_101
LBB0_70:                                ; %else53
                                        ;   in Loop: Header=BB0_6 Depth=1
	and	w3, w3, #0xff
	tbz	w3, #1, LBB0_40
LBB0_71:                                ; %cond.load55
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x4, x2, #4
	ld1.s	{ v27 }[1], [x4]
	tbnz	w3, #2, LBB0_41
LBB0_72:                                ; %else59
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w3, #3, LBB0_42
LBB0_73:                                ; %cond.load61
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x4, x2, #12
	ld1.s	{ v27 }[3], [x4]
	tbnz	w3, #4, LBB0_43
LBB0_74:                                ; %else65
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w3, #5, LBB0_44
LBB0_75:                                ; %cond.load67
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x4, x2, #20
	ld1.s	{ v26 }[1], [x4]
	tbnz	w3, #6, LBB0_45
LBB0_76:                                ; %else71
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w3, #7, LBB0_46
LBB0_77:                                ; %cond.load73
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x2, x2, #28
	ld1.s	{ v26 }[3], [x2]
	fmov	w2, s21
	add	x1, x9, x1
	movi.2d	v29, #0000000000000000
	movi.2d	v28, #0000000000000000
	tbnz	w2, #0, LBB0_47
LBB0_78:                                ; %else78
                                        ;   in Loop: Header=BB0_6 Depth=1
	and	w2, w2, #0xff
	tbz	w2, #1, LBB0_48
LBB0_79:                                ; %cond.load80
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x3, x1, #4
	ld1.s	{ v29 }[1], [x3]
	tbnz	w2, #2, LBB0_49
LBB0_80:                                ; %else84
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w2, #3, LBB0_50
LBB0_81:                                ; %cond.load86
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x3, x1, #12
	ld1.s	{ v29 }[3], [x3]
	tbnz	w2, #4, LBB0_51
LBB0_82:                                ; %else90
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w2, #5, LBB0_52
LBB0_83:                                ; %cond.load92
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x3, x1, #20
	ld1.s	{ v28 }[1], [x3]
	tbnz	w2, #6, LBB0_53
LBB0_84:                                ; %else96
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w2, #7, LBB0_54
LBB0_85:                                ; %cond.load98
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x1, x1, #28
	ld1.s	{ v28 }[3], [x1]
	fmov	w1, s21
	fmul.4s	v6, v23, v27
	fmul.4s	v30, v25, v29
	fsub.4s	v6, v6, v30
	add	x17, x8, x17
	tbnz	w1, #0, LBB0_55
LBB0_86:                                ; %else102
                                        ;   in Loop: Header=BB0_6 Depth=1
	and	w1, w1, #0xff
	tbz	w1, #1, LBB0_56
LBB0_87:                                ; %cond.store103
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x2, x17, #4
	st1.s	{ v6 }[1], [x2]
	tbnz	w1, #2, LBB0_57
LBB0_88:                                ; %else106
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w1, #3, LBB0_58
LBB0_89:                                ; %cond.store107
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x2, x17, #12
	st1.s	{ v6 }[3], [x2]
	fmul.4s	v6, v22, v26
	fmul.4s	v30, v24, v28
	fsub.4s	v6, v6, v30
	tbnz	w1, #4, LBB0_59
LBB0_90:                                ; %else110
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w1, #5, LBB0_60
LBB0_91:                                ; %cond.store111
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x2, x17, #20
	st1.s	{ v6 }[1], [x2]
	tbnz	w1, #6, LBB0_61
LBB0_92:                                ; %else114
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w1, #7, LBB0_62
LBB0_93:                                ; %cond.store115
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x17, x17, #28
	st1.s	{ v6 }[3], [x17]
	fmov	w1, s21
	fmul.4s	v6, v23, v29
	fmul.4s	v23, v25, v27
	fadd.4s	v6, v23, v6
	add	x17, x8, x0
	tbnz	w1, #0, LBB0_63
LBB0_94:                                ; %else119
                                        ;   in Loop: Header=BB0_6 Depth=1
	and	w0, w1, #0xff
	tbz	w0, #1, LBB0_64
LBB0_95:                                ; %cond.store120
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x1, x17, #4
	st1.s	{ v6 }[1], [x1]
	tbnz	w0, #2, LBB0_65
LBB0_96:                                ; %else123
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w0, #3, LBB0_66
LBB0_97:                                ; %cond.store124
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x1, x17, #12
	st1.s	{ v6 }[3], [x1]
	fmul.4s	v6, v22, v28
	fmul.4s	v22, v24, v26
	fadd.4s	v6, v22, v6
	tbnz	w0, #4, LBB0_67
LBB0_98:                                ; %else127
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w0, #5, LBB0_68
LBB0_99:                                ; %cond.store128
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x1, x17, #20
	st1.s	{ v6 }[1], [x1]
	tbnz	w0, #6, LBB0_69
LBB0_100:                               ; %else131
                                        ;   in Loop: Header=BB0_6 Depth=1
	tbz	w0, #7, LBB0_5
LBB0_101:                               ; %cond.store132
                                        ;   in Loop: Header=BB0_6 Depth=1
	add	x17, x17, #28
	st1.s	{ v6 }[3], [x17]
	b	LBB0_5
LBB0_102:                               ; %direct.false32
	xtn.8b	v6, v18
	movi.8b	v18, #1
	and.8b	v18, v6, v18
	umov.b	w14, v18[0]
	movi.2d	v28, #0000000000000000
	mov.b	v28[0], v6[0]
	movi.2d	v18, #0000000000000000
	umaxv.8b	b21, v28
	fmov	w16, s21
	rbit	w12, w14
	clz	w12, w12
	tst	w16, #0x1
	csel	w12, w12, wzr, ne
	mov	w15, #768                       ; =0x300
	dup.2d	v30, x15
	orr.16b	v29, v19, v30
	add.2d	v22, v20, v29
	movi.2d	v21, #0000000000000000
	mov.b	v21[0], v6[0]
	ushll.2d	v6, v21, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	and.16b	v6, v6, v22
	stp	q18, q18, [sp, #368]
	stp	q6, q18, [sp, #336]
	and	x15, x12, #0x7
	add	x17, sp, #336
	ldr	x15, [x17, x15, lsl #3]
	sub	x15, x15, x12
	add	x15, x11, x15, lsl #2
	movi.2d	v21, #0000000000000000
	tbz	w16, #0, LBB0_110
; %bb.103:                              ; %cond.load135
	ldr	s18, [x15]
	tbnz	w14, #1, LBB0_111
LBB0_104:                               ; %else139
	tbz	w14, #2, LBB0_112
LBB0_105:                               ; %cond.load141
	add	x16, x15, #8
	ld1.s	{ v18 }[2], [x16]
	tbnz	w14, #3, LBB0_113
LBB0_106:                               ; %else145
	tbz	w14, #4, LBB0_114
LBB0_107:                               ; %cond.load147
	add	x16, x15, #16
	ld1.s	{ v21 }[0], [x16]
	tbnz	w14, #5, LBB0_115
LBB0_108:                               ; %else151
	tbz	w14, #6, LBB0_116
LBB0_109:                               ; %cond.load153
	add	x16, x15, #24
	ld1.s	{ v21 }[2], [x16]
	tbnz	w14, #7, LBB0_117
	b	LBB0_118
LBB0_110:                               ; %else136
	tbz	w14, #1, LBB0_104
LBB0_111:                               ; %cond.load138
	add	x16, x15, #4
	ld1.s	{ v18 }[1], [x16]
	tbnz	w14, #2, LBB0_105
LBB0_112:                               ; %else142
	tbz	w14, #3, LBB0_106
LBB0_113:                               ; %cond.load144
	add	x16, x15, #12
	ld1.s	{ v18 }[3], [x16]
	tbnz	w14, #4, LBB0_107
LBB0_114:                               ; %else148
	tbz	w14, #5, LBB0_108
LBB0_115:                               ; %cond.load150
	add	x16, x15, #20
	ld1.s	{ v21 }[1], [x16]
	tbnz	w14, #6, LBB0_109
LBB0_116:                               ; %else154
	tbz	w14, #7, LBB0_118
LBB0_117:                               ; %cond.load156
	add	x14, x15, #28
	ld1.s	{ v21 }[3], [x14]
LBB0_118:                               ; %else157
	add.2d	v6, v19, v20
	add.2d	v23, v7, v4
	add.2d	v20, v13, v17
	add.2d	v19, v11, v5
	mov	w14, #1537                      ; =0x601
	dup.2d	v24, x14
	add.2d	v19, v19, v24
	add.2d	v20, v20, v24
	add.2d	v23, v23, v24
	add.2d	v24, v6, v24
	mov	b6, v28[0]
	mov.b	v6[4], v28[1]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	and.16b	v6, v6, v24
	mov	b25, v28[2]
	mov.b	v25[4], v28[3]
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	mov	b26, v28[4]
	mov.b	v26[4], v28[5]
	and.16b	v27, v25, v23
	ushll.2d	v25, v26, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	and.16b	v26, v25, v20
	mov	b25, v28[6]
	mov.b	v25[4], v28[7]
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	and.16b	v31, v25, v19
	ldr	d25, [x13, lCPI0_11@PAGEOFF]
	shl.8b	v8, v28, #7
	cmlt.8b	v8, v8, #0
	and.8b	v25, v8, v25
	addv.8b	b25, v25
	fmov	w13, s25
	stp	q26, q31, [sp, #304]
	stp	q6, q27, [sp, #272]
	and	x14, x12, #0x7
	add	x15, sp, #272
	ldr	x14, [x15, x14, lsl #3]
	sub	x14, x14, x12
	add	x11, x11, x14, lsl #2
	movi.2d	v27, #0000000000000000
	movi.2d	v26, #0000000000000000
	tbz	w13, #0, LBB0_126
; %bb.119:                              ; %cond.load160
	ldr	s27, [x11]
	tbnz	w13, #1, LBB0_127
LBB0_120:                               ; %else164
	tbz	w13, #2, LBB0_128
LBB0_121:                               ; %cond.load166
	add	x14, x11, #8
	ld1.s	{ v27 }[2], [x14]
	tbnz	w13, #3, LBB0_129
LBB0_122:                               ; %else170
	tbz	w13, #4, LBB0_130
LBB0_123:                               ; %cond.load172
	add	x14, x11, #16
	ld1.s	{ v26 }[0], [x14]
	tbnz	w13, #5, LBB0_131
LBB0_124:                               ; %else176
	tbz	w13, #6, LBB0_132
LBB0_125:                               ; %cond.load178
	add	x14, x11, #24
	ld1.s	{ v26 }[2], [x14]
	orr.16b	v6, v11, v30
	orr.16b	v7, v7, v30
	orr.16b	v16, v13, v30
	tbnz	w13, #7, LBB0_133
	b	LBB0_134
LBB0_126:                               ; %else161
	tbz	w13, #1, LBB0_120
LBB0_127:                               ; %cond.load163
	add	x14, x11, #4
	ld1.s	{ v27 }[1], [x14]
	tbnz	w13, #2, LBB0_121
LBB0_128:                               ; %else167
	tbz	w13, #3, LBB0_122
LBB0_129:                               ; %cond.load169
	add	x14, x11, #12
	ld1.s	{ v27 }[3], [x14]
	tbnz	w13, #4, LBB0_123
LBB0_130:                               ; %else173
	tbz	w13, #5, LBB0_124
LBB0_131:                               ; %cond.load175
	add	x14, x11, #20
	ld1.s	{ v26 }[1], [x14]
	tbnz	w13, #6, LBB0_125
LBB0_132:                               ; %else179
	orr.16b	v6, v11, v30
	orr.16b	v7, v7, v30
	orr.16b	v16, v13, v30
	tbz	w13, #7, LBB0_134
LBB0_133:                               ; %cond.load181
	add	x11, x11, #28
	ld1.s	{ v26 }[3], [x11]
LBB0_134:                               ; %else182
	mov.d	x11, v3[1]
	mov	w13, #769                       ; =0x301
	mul	x11, x11, x13
	fmov	x14, d3
	mul	x14, x14, x13
	fmov	d3, x14
	mov.d	v3[1], x11
	mov.d	x11, v2[1]
	mul	x11, x11, x13
	fmov	x14, d2
	mul	x14, x14, x13
	fmov	d2, x14
	mov.d	v2[1], x11
	mov.d	x11, v1[1]
	mul	x11, x11, x13
	fmov	x14, d1
	mul	x14, x14, x13
	fmov	d1, x14
	mov.d	v1[1], x11
	mov.d	x11, v0[1]
	mul	x11, x11, x13
	fmov	x14, d0
	mul	x13, x14, x13
	fmov	d0, x13
	mov.d	v0[1], x11
	add.2d	v0, v0, v6
	add.2d	v1, v1, v16
	add.2d	v2, v2, v7
	add.2d	v3, v3, v29
	mov	b29, v28[0]
	mov.b	v29[4], v28[1]
	ushll.2d	v29, v29, #0
	shl.2d	v29, v29, #63
	cmlt.2d	v29, v29, #0
	and.16b	v3, v29, v3
	mov	b29, v28[2]
	mov.b	v29[4], v28[3]
	ushll.2d	v29, v29, #0
	shl.2d	v29, v29, #63
	cmlt.2d	v29, v29, #0
	and.16b	v2, v29, v2
	mov	b29, v28[4]
	mov.b	v29[4], v28[5]
	ushll.2d	v29, v29, #0
	shl.2d	v29, v29, #63
	cmlt.2d	v29, v29, #0
	and.16b	v1, v29, v1
	mov	b29, v28[6]
	mov.b	v29[4], v28[7]
	ushll.2d	v28, v29, #0
	shl.2d	v28, v28, #63
	cmlt.2d	v28, v28, #0
	and.16b	v0, v28, v0
	stp	q1, q0, [sp, #240]
	stp	q3, q2, [sp, #208]
	and	x11, x12, #0x7
	add	x13, sp, #208
	ldr	x11, [x13, x11, lsl #3]
	fmov	w13, s25
	sub	x11, x11, x12
	lsl	x11, x11, #2
	add	x10, x10, x11
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbz	w13, #0, LBB0_150
; %bb.135:                              ; %cond.load185
	ldr	s1, [x10]
	tbnz	w13, #1, LBB0_151
LBB0_136:                               ; %else189
	tbz	w13, #2, LBB0_152
LBB0_137:                               ; %cond.load191
	add	x14, x10, #8
	ld1.s	{ v1 }[2], [x14]
	tbnz	w13, #3, LBB0_153
LBB0_138:                               ; %else195
	tbz	w13, #4, LBB0_154
LBB0_139:                               ; %cond.load197
	add	x14, x10, #16
	ld1.s	{ v0 }[0], [x14]
	tbnz	w13, #5, LBB0_155
LBB0_140:                               ; %else201
	tbz	w13, #6, LBB0_156
LBB0_141:                               ; %cond.load203
	add	x14, x10, #24
	ld1.s	{ v0 }[2], [x14]
	tbnz	w13, #7, LBB0_157
LBB0_142:                               ; %else207
	add	x9, x9, x11
	fmov	w10, s25
	movi.2d	v3, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbz	w10, #0, LBB0_158
LBB0_143:                               ; %cond.load210
	ldr	s3, [x9]
	tbnz	w10, #1, LBB0_159
LBB0_144:                               ; %else214
	tbz	w10, #2, LBB0_160
LBB0_145:                               ; %cond.load216
	add	x11, x9, #8
	ld1.s	{ v3 }[2], [x11]
	tbnz	w10, #3, LBB0_161
LBB0_146:                               ; %else220
	tbz	w10, #4, LBB0_162
LBB0_147:                               ; %cond.load222
	add	x11, x9, #16
	ld1.s	{ v2 }[0], [x11]
	tbnz	w10, #5, LBB0_163
LBB0_148:                               ; %else226
	tbz	w10, #6, LBB0_164
LBB0_149:                               ; %cond.load228
	add	x11, x9, #24
	ld1.s	{ v2 }[2], [x11]
	add.2d	v16, v17, v16
	add.2d	v7, v4, v7
	add.2d	v5, v5, v6
	tbnz	w10, #7, LBB0_165
	b	LBB0_166
LBB0_150:                               ; %else186
	tbz	w13, #1, LBB0_136
LBB0_151:                               ; %cond.load188
	add	x14, x10, #4
	ld1.s	{ v1 }[1], [x14]
	tbnz	w13, #2, LBB0_137
LBB0_152:                               ; %else192
	tbz	w13, #3, LBB0_138
LBB0_153:                               ; %cond.load194
	add	x14, x10, #12
	ld1.s	{ v1 }[3], [x14]
	tbnz	w13, #4, LBB0_139
LBB0_154:                               ; %else198
	tbz	w13, #5, LBB0_140
LBB0_155:                               ; %cond.load200
	add	x14, x10, #20
	ld1.s	{ v0 }[1], [x14]
	tbnz	w13, #6, LBB0_141
LBB0_156:                               ; %else204
	tbz	w13, #7, LBB0_142
LBB0_157:                               ; %cond.load206
	add	x10, x10, #28
	ld1.s	{ v0 }[3], [x10]
	add	x9, x9, x11
	fmov	w10, s25
	movi.2d	v3, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w10, #0, LBB0_143
LBB0_158:                               ; %else211
	tbz	w10, #1, LBB0_144
LBB0_159:                               ; %cond.load213
	add	x11, x9, #4
	ld1.s	{ v3 }[1], [x11]
	tbnz	w10, #2, LBB0_145
LBB0_160:                               ; %else217
	tbz	w10, #3, LBB0_146
LBB0_161:                               ; %cond.load219
	add	x11, x9, #12
	ld1.s	{ v3 }[3], [x11]
	tbnz	w10, #4, LBB0_147
LBB0_162:                               ; %else223
	tbz	w10, #5, LBB0_148
LBB0_163:                               ; %cond.load225
	add	x11, x9, #20
	ld1.s	{ v2 }[1], [x11]
	tbnz	w10, #6, LBB0_149
LBB0_164:                               ; %else229
	add.2d	v16, v17, v16
	add.2d	v7, v4, v7
	add.2d	v5, v5, v6
	tbz	w10, #7, LBB0_166
LBB0_165:                               ; %cond.load231
	add	x9, x9, #28
	ld1.s	{ v2 }[3], [x9]
LBB0_166:                               ; %else232
	fmul.4s	v4, v18, v1
	fmul.4s	v6, v27, v3
	fsub.4s	v4, v4, v6
	stp	q22, q7, [sp, #144]
	stp	q16, q5, [sp, #176]
	and	x9, x12, #0x7
	add	x10, sp, #144
	ldr	x9, [x10, x9, lsl #3]
	sub	x9, x9, x12
	add	x9, x8, x9, lsl #2
	fmov	w10, s25
	tbz	w10, #0, LBB0_174
; %bb.167:                              ; %cond.store235
	str	s4, [x9]
	tbnz	w10, #1, LBB0_175
LBB0_168:                               ; %else238
	tbz	w10, #2, LBB0_176
LBB0_169:                               ; %cond.store239
	add	x11, x9, #8
	st1.s	{ v4 }[2], [x11]
	fmul.4s	v5, v21, v0
	fmul.4s	v6, v26, v2
	tbnz	w10, #3, LBB0_177
LBB0_170:                               ; %else242
	fsub.4s	v4, v5, v6
	tbz	w10, #4, LBB0_178
LBB0_171:                               ; %cond.store243
	str	s4, [x9, #16]
	tbnz	w10, #5, LBB0_179
LBB0_172:                               ; %else246
	tbz	w10, #6, LBB0_180
LBB0_173:                               ; %cond.store247
	add	x11, x9, #24
	st1.s	{ v4 }[2], [x11]
	tbnz	w10, #7, LBB0_181
	b	LBB0_182
LBB0_174:                               ; %else236
	tbz	w10, #1, LBB0_168
LBB0_175:                               ; %cond.store237
	add	x11, x9, #4
	st1.s	{ v4 }[1], [x11]
	tbnz	w10, #2, LBB0_169
LBB0_176:                               ; %else240
	fmul.4s	v5, v21, v0
	fmul.4s	v6, v26, v2
	tbz	w10, #3, LBB0_170
LBB0_177:                               ; %cond.store241
	add	x11, x9, #12
	st1.s	{ v4 }[3], [x11]
	fsub.4s	v4, v5, v6
	tbnz	w10, #4, LBB0_171
LBB0_178:                               ; %else244
	tbz	w10, #5, LBB0_172
LBB0_179:                               ; %cond.store245
	add	x11, x9, #20
	st1.s	{ v4 }[1], [x11]
	tbnz	w10, #6, LBB0_173
LBB0_180:                               ; %else248
	tbz	w10, #7, LBB0_182
LBB0_181:                               ; %cond.store249
	add	x9, x9, #28
	st1.s	{ v4 }[3], [x9]
LBB0_182:                               ; %else250
	fmul.4s	v3, v18, v3
	fmul.4s	v1, v27, v1
	fadd.4s	v1, v1, v3
	stp	q24, q23, [sp, #80]
	stp	q20, q19, [sp, #112]
	and	x9, x12, #0x7
	add	x10, sp, #80
	ldr	x9, [x10, x9, lsl #3]
	sub	x9, x9, x12
	add	x8, x8, x9, lsl #2
	fmov	w9, s25
	tbz	w9, #0, LBB0_190
; %bb.183:                              ; %cond.store252
	str	s1, [x8]
	tbnz	w9, #1, LBB0_191
LBB0_184:                               ; %else255
	tbz	w9, #2, LBB0_192
LBB0_185:                               ; %cond.store256
	add	x10, x8, #8
	st1.s	{ v1 }[2], [x10]
	fmul.4s	v2, v21, v2
	fmul.4s	v0, v26, v0
	tbnz	w9, #3, LBB0_193
LBB0_186:                               ; %else259
	fadd.4s	v0, v0, v2
	tbz	w9, #4, LBB0_387
LBB0_187:                               ; %cond.store260
	str	s0, [x8, #16]
	tbnz	w9, #5, LBB0_388
LBB0_188:                               ; %else263
	tbz	w9, #6, LBB0_389
LBB0_189:                               ; %cond.store532
	add	x10, x8, #24
	st1.s	{ v0 }[2], [x10]
	tbnz	w9, #7, LBB0_390
	b	LBB0_391
LBB0_190:                               ; %else253
	tbz	w9, #1, LBB0_184
LBB0_191:                               ; %cond.store254
	add	x10, x8, #4
	st1.s	{ v1 }[1], [x10]
	tbnz	w9, #2, LBB0_185
LBB0_192:                               ; %else257
	fmul.4s	v2, v21, v2
	fmul.4s	v0, v26, v0
	tbz	w9, #3, LBB0_186
LBB0_193:                               ; %cond.store258
	add	x10, x8, #12
	st1.s	{ v1 }[3], [x10]
	fadd.4s	v0, v0, v2
	tbz	w9, #4, LBB0_387
	b	LBB0_187
LBB0_194:                               ; %direct.schedule.8.preheader
	mov	x12, #0                         ; =0x0
	fmov	x16, d3
	mov	w14, #6152                      ; =0x1808
	umaddl	x14, w16, w14, x11
	ldr	q6, [x17, lCPI0_6@PAGEOFF]
	and.16b	v6, v18, v6
	addv.8h	h17, v6
	fmov	w15, s17
	add	x17, sp, #2, lsl #12            ; =8192
	add	x17, x17, #2000
	b	LBB0_196
LBB0_195:                               ; %else291
                                        ;   in Loop: Header=BB0_196 Depth=1
	add	x0, x17, x12
	stp	q22, q27, [x0]
	add	x12, x12, #32
	cmp	x12, #3072
	b.eq	LBB0_212
LBB0_196:                               ; %direct.true60
                                        ; =>This Inner Loop Header: Depth=1
	add	x0, x14, x12
	add	x2, x17, x12
	ldr	q22, [x2]
	tbz	w15, #0, LBB0_204
; %bb.197:                              ; %cond.load269
                                        ;   in Loop: Header=BB0_196 Depth=1
	ld1.s	{ v22 }[0], [x0]
	and	w1, w15, #0xff
	tbnz	w1, #1, LBB0_205
LBB0_198:                               ; %else273
                                        ;   in Loop: Header=BB0_196 Depth=1
	tbz	w1, #2, LBB0_206
LBB0_199:                               ; %cond.load275
                                        ;   in Loop: Header=BB0_196 Depth=1
	add	x3, x0, #8
	ld1.s	{ v22 }[2], [x3]
	tbnz	w1, #3, LBB0_207
LBB0_200:                               ; %else279
                                        ;   in Loop: Header=BB0_196 Depth=1
	ldr	q27, [x2, #16]
	tbz	w1, #4, LBB0_208
LBB0_201:                               ; %cond.load281
                                        ;   in Loop: Header=BB0_196 Depth=1
	add	x2, x0, #16
	ld1.s	{ v27 }[0], [x2]
	tbnz	w1, #5, LBB0_209
LBB0_202:                               ; %else285
                                        ;   in Loop: Header=BB0_196 Depth=1
	tbz	w1, #6, LBB0_210
LBB0_203:                               ; %cond.load287
                                        ;   in Loop: Header=BB0_196 Depth=1
	add	x2, x0, #24
	ld1.s	{ v27 }[2], [x2]
	tbz	w1, #7, LBB0_195
	b	LBB0_211
LBB0_204:                               ; %else270
                                        ;   in Loop: Header=BB0_196 Depth=1
	and	w1, w15, #0xff
	tbz	w1, #1, LBB0_198
LBB0_205:                               ; %cond.load272
                                        ;   in Loop: Header=BB0_196 Depth=1
	add	x3, x0, #4
	ld1.s	{ v22 }[1], [x3]
	tbnz	w1, #2, LBB0_199
LBB0_206:                               ; %else276
                                        ;   in Loop: Header=BB0_196 Depth=1
	tbz	w1, #3, LBB0_200
LBB0_207:                               ; %cond.load278
                                        ;   in Loop: Header=BB0_196 Depth=1
	add	x3, x0, #12
	ld1.s	{ v22 }[3], [x3]
	ldr	q27, [x2, #16]
	tbnz	w1, #4, LBB0_201
LBB0_208:                               ; %else282
                                        ;   in Loop: Header=BB0_196 Depth=1
	tbz	w1, #5, LBB0_202
LBB0_209:                               ; %cond.load284
                                        ;   in Loop: Header=BB0_196 Depth=1
	add	x2, x0, #20
	ld1.s	{ v27 }[1], [x2]
	tbnz	w1, #6, LBB0_203
LBB0_210:                               ; %else288
                                        ;   in Loop: Header=BB0_196 Depth=1
	tbz	w1, #7, LBB0_195
LBB0_211:                               ; %cond.load290
                                        ;   in Loop: Header=BB0_196 Depth=1
	add	x0, x0, #28
	ld1.s	{ v27 }[3], [x0]
	b	LBB0_195
LBB0_212:                               ; %direct.false61
	xtn.8b	v6, v18
	sshll.2d	v28, v4, #0
	sshll.2d	v29, v5, #0
	movi.8b	v18, #1
	and.8b	v18, v6, v18
	umov.b	w14, v18[0]
	movi.2d	v30, #0000000000000000
	movi.2d	v18, #0000000000000000
	mov.b	v18[0], v6[0]
	umaxv.8b	b22, v18
	fmov	w0, s22
	rbit	w12, w14
	clz	w12, w12
	tst	w0, #0x1
	csel	w12, w12, wzr, ne
	mov	w15, #768                       ; =0x300
	dup.2d	v27, x15
	mov	w15, #1538                      ; =0x602
	dup.2s	v14, w15
	orr.16b	v9, v19, v27
	mov.16b	v16, v9
	umlal.2d	v16, v26, v14
	movi.2d	v31, #0000000000000000
	mov.b	v31[0], v6[0]
	ushll.2d	v6, v31, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	str	q16, [sp, #64]                  ; 16-byte Spill
	and.16b	v6, v6, v16
	stp	q30, q30, [sp, #768]
	stp	q6, q30, [sp, #736]
	ubfiz	x15, x12, #3, #3
	add	x17, sp, #736
	ldr	x17, [x17, x15]
	sub	x17, x17, x12
	add	x17, x11, x17, lsl #2
	mov	w1, #3072                       ; =0xc00
	dup.2d	v6, x1
Lloh12:
	adrp	x1, lCPI0_7@PAGE
Lloh13:
	ldr	q30, [x1, lCPI0_7@PAGEOFF]
	bsl.16b	v29, v30, v6
Lloh14:
	adrp	x1, lCPI0_8@PAGE
Lloh15:
	ldr	q30, [x1, lCPI0_8@PAGEOFF]
	bsl.16b	v28, v30, v6
Lloh16:
	adrp	x1, lCPI0_9@PAGE
Lloh17:
	ldr	q30, [x1, lCPI0_9@PAGEOFF]
	bsl.16b	v21, v30, v6
Lloh18:
	adrp	x1, lCPI0_10@PAGE
Lloh19:
	ldr	q30, [x1, lCPI0_10@PAGEOFF]
	bit.16b	v6, v30, v20
	stp	q28, q6, [sp, #832]
	stp	q29, q21, [sp, #800]
	add	x1, sp, #800
	ldr	x15, [x1, x15]
	sub	x15, x15, w12, uxtw #2
	tst	w14, #0x1
	csel	x15, xzr, x15, eq
	add	x1, sp, #2, lsl #12             ; =8192
	add	x1, x1, #2000
	add	x1, x1, x15
	ldr	q20, [x1]
	tbz	w0, #0, LBB0_240
; %bb.213:                              ; %cond.load294
	ld1.s	{ v20 }[0], [x17]
	tbnz	w14, #1, LBB0_241
LBB0_214:                               ; %else298
	tbz	w14, #2, LBB0_242
LBB0_215:                               ; %cond.load300
	add	x0, x17, #8
	ld1.s	{ v20 }[2], [x0]
	tbnz	w14, #3, LBB0_243
LBB0_216:                               ; %else304
	ldr	q21, [x1, #16]
	tbz	w14, #4, LBB0_244
LBB0_217:                               ; %cond.load306
	add	x0, x17, #16
	ld1.s	{ v21 }[0], [x0]
	tbnz	w14, #5, LBB0_245
LBB0_218:                               ; %else310
	tbz	w14, #6, LBB0_220
LBB0_219:                               ; %cond.load312
	add	x0, x17, #24
	ld1.s	{ v21 }[2], [x0]
LBB0_220:                               ; %else313
	mov.16b	v10, v11
	orr.16b	v11, v11, v27
	orr.16b	v16, v7, v27
	mov.16b	v12, v13
	orr.16b	v22, v13, v27
	umull.2d	v30, v26, v14
	tbz	w14, #7, LBB0_222
; %bb.221:                              ; %cond.load315
	add	x14, x17, #28
	ld1.s	{ v21 }[3], [x14]
LBB0_222:                               ; %else316
	mov	x2, #0                          ; =0x0
	umull.2d	v31, v24, v14
	umull.2d	v8, v25, v14
	umull.2d	v13, v23, v14
	mov.16b	v6, v22
	umlal.2d	v6, v25, v14
	str	q6, [sp, #32]                   ; 16-byte Spill
	mov.16b	v6, v16
	umlal.2d	v6, v24, v14
	str	q6, [sp, #16]                   ; 16-byte Spill
	mov.16b	v6, v11
	umlal.2d	v6, v23, v14
	str	q6, [sp]                        ; 16-byte Spill
	add	x14, sp, #2, lsl #12            ; =8192
	add	x14, x14, #2000
	add	x14, x14, x15
	stp	q20, q21, [x14]
	fmov	x14, d30
	ushll2.2d	v6, v4, #0
	mov	w17, #1                         ; =0x1
	dup.2d	v26, x17
	and.16b	v23, v6, v26
	ushll2.2d	v6, v5, #0
	and.16b	v24, v6, v26
	ushll.2d	v6, v4, #0
	and.16b	v25, v6, v26
	ushll.2d	v6, v5, #0
	and.16b	v26, v6, v26
	lsl	x14, x14, #2
	add	x17, x11, x14
	movi.2d	v14, #0000000000000000
	fmov	w0, s17
	add	x1, sp, #1, lsl #12             ; =4096
	add	x1, x1, #2992
	movi.2d	v15, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	b	LBB0_224
LBB0_223:                               ; %else341
                                        ;   in Loop: Header=BB0_224 Depth=1
	add	x2, x1, x2
	stp	q29, q6, [x2]
	add.2d	v15, v15, v24
	add.2d	v27, v27, v25
	add.2d	v28, v28, v23
	add.2d	v14, v14, v26
	fmov	x2, d14
	cmp	x2, #96
	b.ge	LBB0_246
LBB0_224:                               ; %direct.true82
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x2, x2, #5
	add	x3, x17, x2
	add	x3, x3, #3076
	add	x5, x1, x2
	ldr	q29, [x5]
	tbz	w0, #0, LBB0_232
; %bb.225:                              ; %cond.load319
                                        ;   in Loop: Header=BB0_224 Depth=1
	ld1.s	{ v29 }[0], [x3]
	and	w4, w0, #0xff
	tbnz	w4, #1, LBB0_233
LBB0_226:                               ; %else323
                                        ;   in Loop: Header=BB0_224 Depth=1
	tbz	w4, #2, LBB0_234
LBB0_227:                               ; %cond.load325
                                        ;   in Loop: Header=BB0_224 Depth=1
	add	x6, x3, #8
	ld1.s	{ v29 }[2], [x6]
	tbnz	w4, #3, LBB0_235
LBB0_228:                               ; %else329
                                        ;   in Loop: Header=BB0_224 Depth=1
	ldr	q6, [x5, #16]
	tbz	w4, #4, LBB0_236
LBB0_229:                               ; %cond.load331
                                        ;   in Loop: Header=BB0_224 Depth=1
	add	x5, x3, #16
	ld1.s	{ v6 }[0], [x5]
	tbnz	w4, #5, LBB0_237
LBB0_230:                               ; %else335
                                        ;   in Loop: Header=BB0_224 Depth=1
	tbz	w4, #6, LBB0_238
LBB0_231:                               ; %cond.load337
                                        ;   in Loop: Header=BB0_224 Depth=1
	add	x5, x3, #24
	ld1.s	{ v6 }[2], [x5]
	tbz	w4, #7, LBB0_223
	b	LBB0_239
LBB0_232:                               ; %else320
                                        ;   in Loop: Header=BB0_224 Depth=1
	and	w4, w0, #0xff
	tbz	w4, #1, LBB0_226
LBB0_233:                               ; %cond.load322
                                        ;   in Loop: Header=BB0_224 Depth=1
	add	x6, x3, #4
	ld1.s	{ v29 }[1], [x6]
	tbnz	w4, #2, LBB0_227
LBB0_234:                               ; %else326
                                        ;   in Loop: Header=BB0_224 Depth=1
	tbz	w4, #3, LBB0_228
LBB0_235:                               ; %cond.load328
                                        ;   in Loop: Header=BB0_224 Depth=1
	add	x6, x3, #12
	ld1.s	{ v29 }[3], [x6]
	ldr	q6, [x5, #16]
	tbnz	w4, #4, LBB0_229
LBB0_236:                               ; %else332
                                        ;   in Loop: Header=BB0_224 Depth=1
	tbz	w4, #5, LBB0_230
LBB0_237:                               ; %cond.load334
                                        ;   in Loop: Header=BB0_224 Depth=1
	add	x5, x3, #20
	ld1.s	{ v6 }[1], [x5]
	tbnz	w4, #6, LBB0_231
LBB0_238:                               ; %else338
                                        ;   in Loop: Header=BB0_224 Depth=1
	tbz	w4, #7, LBB0_223
LBB0_239:                               ; %cond.load340
                                        ;   in Loop: Header=BB0_224 Depth=1
	add	x3, x3, #28
	ld1.s	{ v6 }[3], [x3]
	b	LBB0_223
LBB0_240:                               ; %else295
	tbz	w14, #1, LBB0_214
LBB0_241:                               ; %cond.load297
	add	x0, x17, #4
	ld1.s	{ v20 }[1], [x0]
	tbnz	w14, #2, LBB0_215
LBB0_242:                               ; %else301
	tbz	w14, #3, LBB0_216
LBB0_243:                               ; %cond.load303
	add	x0, x17, #12
	ld1.s	{ v20 }[3], [x0]
	ldr	q21, [x1, #16]
	tbnz	w14, #4, LBB0_217
LBB0_244:                               ; %else307
	tbz	w14, #5, LBB0_218
LBB0_245:                               ; %cond.load309
	add	x0, x17, #20
	ld1.s	{ v21 }[1], [x0]
	tbnz	w14, #6, LBB0_219
	b	LBB0_220
LBB0_246:                               ; %direct.false83
	add.2d	v19, v19, v30
	add.2d	v27, v7, v31
	add.2d	v7, v12, v8
	add.2d	v6, v10, v13
	mov	w17, #1537                      ; =0x601
	dup.2d	v28, x17
	add.2d	v31, v6, v28
	add.2d	v7, v7, v28
	add.2d	v6, v27, v28
	add.2d	v19, v19, v28
	mov	b27, v18[0]
	mov.b	v27[4], v18[1]
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	and.16b	v27, v27, v19
	mov	b28, v18[2]
	mov.b	v28[4], v18[3]
	ushll.2d	v28, v28, #0
	shl.2d	v28, v28, #63
	cmlt.2d	v28, v28, #0
	and.16b	v28, v28, v6
	mov	b29, v18[4]
	mov.b	v29[4], v18[5]
	ushll.2d	v29, v29, #0
	shl.2d	v29, v29, #63
	cmlt.2d	v29, v29, #0
	mov	b30, v18[6]
	mov.b	v30[4], v18[7]
	and.16b	v29, v29, v7
	ushll.2d	v30, v30, #0
	shl.2d	v30, v30, #63
	cmlt.2d	v30, v30, #0
	str	q31, [sp, #48]                  ; 16-byte Spill
	and.16b	v31, v30, v31
	ldr	d30, [x13, lCPI0_11@PAGEOFF]
	shl.8b	v8, v18, #7
	cmlt.8b	v8, v8, #0
	and.8b	v30, v8, v30
	addv.8b	b30, v30
	stp	q29, q31, [sp, #688]
	stp	q27, q28, [sp, #656]
	and	x13, x12, #0x7
	add	x17, sp, #656
	ldr	x17, [x17, x13, lsl #3]
	fmov	w13, s30
	sub	x17, x17, x12
	add	x11, x11, x17, lsl #2
	add	x17, sp, #1, lsl #12            ; =4096
	add	x17, x17, #2992
	add	x17, x17, x15
	ldr	q31, [x17]
	tbz	w13, #0, LBB0_254
; %bb.247:                              ; %cond.load344
	ld1.s	{ v31 }[0], [x11]
	tbnz	w13, #1, LBB0_255
LBB0_248:                               ; %else348
	tbz	w13, #2, LBB0_256
LBB0_249:                               ; %cond.load350
	add	x0, x11, #8
	ld1.s	{ v31 }[2], [x0]
	tbnz	w13, #3, LBB0_257
LBB0_250:                               ; %else354
	ldr	q8, [x17, #16]
	tbz	w13, #4, LBB0_258
LBB0_251:                               ; %cond.load356
	add	x17, x11, #16
	ld1.s	{ v8 }[0], [x17]
	tbnz	w13, #5, LBB0_259
LBB0_252:                               ; %else360
	tbz	w13, #6, LBB0_260
LBB0_253:                               ; %cond.load362
	add	x17, x11, #24
	ld1.s	{ v8 }[2], [x17]
	tbnz	w13, #7, LBB0_261
	b	LBB0_262
LBB0_254:                               ; %else345
	tbz	w13, #1, LBB0_248
LBB0_255:                               ; %cond.load347
	add	x0, x11, #4
	ld1.s	{ v31 }[1], [x0]
	tbnz	w13, #2, LBB0_249
LBB0_256:                               ; %else351
	tbz	w13, #3, LBB0_250
LBB0_257:                               ; %cond.load353
	add	x0, x11, #12
	ld1.s	{ v31 }[3], [x0]
	ldr	q8, [x17, #16]
	tbnz	w13, #4, LBB0_251
LBB0_258:                               ; %else357
	tbz	w13, #5, LBB0_252
LBB0_259:                               ; %cond.load359
	add	x17, x11, #20
	ld1.s	{ v8 }[1], [x17]
	tbnz	w13, #6, LBB0_253
LBB0_260:                               ; %else363
	tbz	w13, #7, LBB0_262
LBB0_261:                               ; %cond.load365
	add	x11, x11, #28
	ld1.s	{ v8 }[3], [x11]
LBB0_262:                               ; %else366
	mov	x17, #0                         ; =0x0
	add	x11, sp, #1, lsl #12            ; =4096
	add	x11, x11, #2992
	add	x11, x11, x15
	stp	q31, q8, [x11]
	mov	w11, #3076                      ; =0xc04
	umaddl	x11, w16, w11, x10
	movi.2d	v13, #0000000000000000
	fmov	w13, s17
	add	x16, sp, #3984
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v14, #0000000000000000
	b	LBB0_264
LBB0_263:                               ; %else391
                                        ;   in Loop: Header=BB0_264 Depth=1
	add	x17, x16, x17
	stp	q29, q15, [x17]
	add.2d	v27, v27, v24
	add.2d	v28, v28, v25
	add.2d	v14, v14, v23
	add.2d	v13, v13, v26
	fmov	x17, d13
	cmp	x17, #96
	b.ge	LBB0_280
LBB0_264:                               ; %direct.true103
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x17, x17, #5
	add	x0, x11, x17
	add	x2, x16, x17
	ldr	q29, [x2]
	tbz	w13, #0, LBB0_272
; %bb.265:                              ; %cond.load369
                                        ;   in Loop: Header=BB0_264 Depth=1
	ld1.s	{ v29 }[0], [x0]
	and	w1, w13, #0xff
	tbnz	w1, #1, LBB0_273
LBB0_266:                               ; %else373
                                        ;   in Loop: Header=BB0_264 Depth=1
	tbz	w1, #2, LBB0_274
LBB0_267:                               ; %cond.load375
                                        ;   in Loop: Header=BB0_264 Depth=1
	add	x3, x0, #8
	ld1.s	{ v29 }[2], [x3]
	tbnz	w1, #3, LBB0_275
LBB0_268:                               ; %else379
                                        ;   in Loop: Header=BB0_264 Depth=1
	ldr	q15, [x2, #16]
	tbz	w1, #4, LBB0_276
LBB0_269:                               ; %cond.load381
                                        ;   in Loop: Header=BB0_264 Depth=1
	add	x2, x0, #16
	ld1.s	{ v15 }[0], [x2]
	tbnz	w1, #5, LBB0_277
LBB0_270:                               ; %else385
                                        ;   in Loop: Header=BB0_264 Depth=1
	tbz	w1, #6, LBB0_278
LBB0_271:                               ; %cond.load387
                                        ;   in Loop: Header=BB0_264 Depth=1
	add	x2, x0, #24
	ld1.s	{ v15 }[2], [x2]
	tbz	w1, #7, LBB0_263
	b	LBB0_279
LBB0_272:                               ; %else370
                                        ;   in Loop: Header=BB0_264 Depth=1
	and	w1, w13, #0xff
	tbz	w1, #1, LBB0_266
LBB0_273:                               ; %cond.load372
                                        ;   in Loop: Header=BB0_264 Depth=1
	add	x3, x0, #4
	ld1.s	{ v29 }[1], [x3]
	tbnz	w1, #2, LBB0_267
LBB0_274:                               ; %else376
                                        ;   in Loop: Header=BB0_264 Depth=1
	tbz	w1, #3, LBB0_268
LBB0_275:                               ; %cond.load378
                                        ;   in Loop: Header=BB0_264 Depth=1
	add	x3, x0, #12
	ld1.s	{ v29 }[3], [x3]
	ldr	q15, [x2, #16]
	tbnz	w1, #4, LBB0_269
LBB0_276:                               ; %else382
                                        ;   in Loop: Header=BB0_264 Depth=1
	tbz	w1, #5, LBB0_270
LBB0_277:                               ; %cond.load384
                                        ;   in Loop: Header=BB0_264 Depth=1
	add	x2, x0, #20
	ld1.s	{ v15 }[1], [x2]
	tbnz	w1, #6, LBB0_271
LBB0_278:                               ; %else388
                                        ;   in Loop: Header=BB0_264 Depth=1
	tbz	w1, #7, LBB0_263
LBB0_279:                               ; %cond.load390
                                        ;   in Loop: Header=BB0_264 Depth=1
	add	x0, x0, #28
	ld1.s	{ v15 }[3], [x0]
	b	LBB0_263
LBB0_280:                               ; %direct.false104
	mov.d	x11, v3[1]
	mov	w13, #769                       ; =0x301
	mul	x11, x11, x13
	fmov	x16, d3
	mul	x16, x16, x13
	fmov	d3, x16
	mov.d	v3[1], x11
	mov.d	x11, v2[1]
	mul	x11, x11, x13
	fmov	x16, d2
	mul	x16, x16, x13
	fmov	d2, x16
	mov.d	v2[1], x11
	mov.d	x11, v1[1]
	mul	x11, x11, x13
	fmov	x16, d1
	mul	x16, x16, x13
	fmov	d1, x16
	mov.d	v1[1], x11
	mov.d	x11, v0[1]
	mul	x11, x11, x13
	fmov	x16, d0
	mul	x13, x16, x13
	fmov	d0, x13
	mov.d	v0[1], x11
	add.2d	v0, v0, v11
	add.2d	v1, v1, v22
	add.2d	v2, v2, v16
	add.2d	v27, v3, v9
	mov	b28, v18[0]
	mov.b	v28[4], v18[1]
	ushll.2d	v28, v28, #0
	shl.2d	v28, v28, #63
	cmlt.2d	v28, v28, #0
	and.16b	v27, v28, v27
	mov	b28, v18[2]
	mov.b	v28[4], v18[3]
	ushll.2d	v28, v28, #0
	shl.2d	v28, v28, #63
	cmlt.2d	v28, v28, #0
	and.16b	v2, v28, v2
	mov	b28, v18[4]
	mov.b	v28[4], v18[5]
	ushll.2d	v28, v28, #0
	shl.2d	v28, v28, #63
	cmlt.2d	v28, v28, #0
	and.16b	v1, v28, v1
	mov	b28, v18[6]
	mov.b	v28[4], v18[7]
	ushll.2d	v28, v28, #0
	shl.2d	v28, v28, #63
	cmlt.2d	v28, v28, #0
	and.16b	v0, v28, v0
	fmov	w13, s30
	stp	q1, q0, [sp, #608]
	stp	q27, q2, [sp, #576]
	and	x11, x12, #0x7
	add	x16, sp, #576
	ldr	x11, [x16, x11, lsl #3]
	sub	x11, x11, x12
	lsl	x11, x11, #2
	add	x10, x10, x11
	add	x16, sp, #3984
	add	x16, x16, x15
	ldr	q0, [x16]
	tbz	w13, #0, LBB0_288
; %bb.281:                              ; %cond.load394
	ld1.s	{ v0 }[0], [x10]
	tbnz	w13, #1, LBB0_289
LBB0_282:                               ; %else398
	tbz	w13, #2, LBB0_290
LBB0_283:                               ; %cond.load400
	add	x17, x10, #8
	ld1.s	{ v0 }[2], [x17]
	tbnz	w13, #3, LBB0_291
LBB0_284:                               ; %else404
	ldr	q1, [x16, #16]
	tbz	w13, #4, LBB0_292
LBB0_285:                               ; %cond.load406
	add	x16, x10, #16
	ld1.s	{ v1 }[0], [x16]
	tbnz	w13, #5, LBB0_293
LBB0_286:                               ; %else410
	tbz	w13, #6, LBB0_294
LBB0_287:                               ; %cond.load412
	add	x16, x10, #24
	ld1.s	{ v1 }[2], [x16]
	tbnz	w13, #7, LBB0_295
	b	LBB0_296
LBB0_288:                               ; %else395
	tbz	w13, #1, LBB0_282
LBB0_289:                               ; %cond.load397
	add	x17, x10, #4
	ld1.s	{ v0 }[1], [x17]
	tbnz	w13, #2, LBB0_283
LBB0_290:                               ; %else401
	tbz	w13, #3, LBB0_284
LBB0_291:                               ; %cond.load403
	add	x17, x10, #12
	ld1.s	{ v0 }[3], [x17]
	ldr	q1, [x16, #16]
	tbnz	w13, #4, LBB0_285
LBB0_292:                               ; %else407
	tbz	w13, #5, LBB0_286
LBB0_293:                               ; %cond.load409
	add	x16, x10, #20
	ld1.s	{ v1 }[1], [x16]
	tbnz	w13, #6, LBB0_287
LBB0_294:                               ; %else413
	tbz	w13, #7, LBB0_296
LBB0_295:                               ; %cond.load415
	add	x10, x10, #28
	ld1.s	{ v1 }[3], [x10]
LBB0_296:                               ; %else416
	mov	x17, #0                         ; =0x0
	add	x10, sp, #3984
	add	x10, x10, x15
	stp	q0, q1, [x10]
	fmov	x10, d3
	add	x10, x9, x10, lsl #2
	movi.2d	v2, #0000000000000000
	fmov	w13, s17
	add	x16, sp, #880
	movi.2d	v3, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	b	LBB0_298
LBB0_297:                               ; %else441
                                        ;   in Loop: Header=BB0_298 Depth=1
	add	x17, x16, x17
	stp	q29, q9, [x17]
	add.2d	v3, v3, v24
	add.2d	v27, v27, v25
	add.2d	v28, v28, v23
	add.2d	v2, v2, v26
	fmov	x17, d2
	cmp	x17, #96
	b.ge	LBB0_314
LBB0_298:                               ; %direct.true124
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x17, x17, #5
	add	x0, x10, x17
	add	x2, x16, x17
	ldr	q29, [x2]
	tbz	w13, #0, LBB0_306
; %bb.299:                              ; %cond.load419
                                        ;   in Loop: Header=BB0_298 Depth=1
	ld1.s	{ v29 }[0], [x0]
	and	w1, w13, #0xff
	tbnz	w1, #1, LBB0_307
LBB0_300:                               ; %else423
                                        ;   in Loop: Header=BB0_298 Depth=1
	tbz	w1, #2, LBB0_308
LBB0_301:                               ; %cond.load425
                                        ;   in Loop: Header=BB0_298 Depth=1
	add	x3, x0, #8
	ld1.s	{ v29 }[2], [x3]
	tbnz	w1, #3, LBB0_309
LBB0_302:                               ; %else429
                                        ;   in Loop: Header=BB0_298 Depth=1
	ldr	q9, [x2, #16]
	tbz	w1, #4, LBB0_310
LBB0_303:                               ; %cond.load431
                                        ;   in Loop: Header=BB0_298 Depth=1
	add	x2, x0, #16
	ld1.s	{ v9 }[0], [x2]
	tbnz	w1, #5, LBB0_311
LBB0_304:                               ; %else435
                                        ;   in Loop: Header=BB0_298 Depth=1
	tbz	w1, #6, LBB0_312
LBB0_305:                               ; %cond.load437
                                        ;   in Loop: Header=BB0_298 Depth=1
	add	x2, x0, #24
	ld1.s	{ v9 }[2], [x2]
	tbz	w1, #7, LBB0_297
	b	LBB0_313
LBB0_306:                               ; %else420
                                        ;   in Loop: Header=BB0_298 Depth=1
	and	w1, w13, #0xff
	tbz	w1, #1, LBB0_300
LBB0_307:                               ; %cond.load422
                                        ;   in Loop: Header=BB0_298 Depth=1
	add	x3, x0, #4
	ld1.s	{ v29 }[1], [x3]
	tbnz	w1, #2, LBB0_301
LBB0_308:                               ; %else426
                                        ;   in Loop: Header=BB0_298 Depth=1
	tbz	w1, #3, LBB0_302
LBB0_309:                               ; %cond.load428
                                        ;   in Loop: Header=BB0_298 Depth=1
	add	x3, x0, #12
	ld1.s	{ v29 }[3], [x3]
	ldr	q9, [x2, #16]
	tbnz	w1, #4, LBB0_303
LBB0_310:                               ; %else432
                                        ;   in Loop: Header=BB0_298 Depth=1
	tbz	w1, #5, LBB0_304
LBB0_311:                               ; %cond.load434
                                        ;   in Loop: Header=BB0_298 Depth=1
	add	x2, x0, #20
	ld1.s	{ v9 }[1], [x2]
	tbnz	w1, #6, LBB0_305
LBB0_312:                               ; %else438
                                        ;   in Loop: Header=BB0_298 Depth=1
	tbz	w1, #7, LBB0_297
LBB0_313:                               ; %cond.load440
                                        ;   in Loop: Header=BB0_298 Depth=1
	add	x0, x0, #28
	ld1.s	{ v9 }[3], [x0]
	b	LBB0_297
LBB0_314:                               ; %direct.false125
	add	x9, x9, x11
	add	x10, sp, #880
	add	x11, x10, x15
	ldr	q2, [x11]
	fmov	w10, s30
	tbz	w10, #0, LBB0_322
; %bb.315:                              ; %cond.load444
	ld1.s	{ v2 }[0], [x9]
	tbnz	w10, #1, LBB0_323
LBB0_316:                               ; %else448
	tbz	w10, #2, LBB0_324
LBB0_317:                               ; %cond.load450
	add	x13, x9, #8
	ld1.s	{ v2 }[2], [x13]
	tbnz	w10, #3, LBB0_325
LBB0_318:                               ; %else454
	ldr	q3, [x11, #16]
	tbz	w10, #4, LBB0_326
LBB0_319:                               ; %cond.load456
	add	x11, x9, #16
	ld1.s	{ v3 }[0], [x11]
	tbnz	w10, #5, LBB0_327
LBB0_320:                               ; %else460
	tbz	w10, #6, LBB0_328
LBB0_321:                               ; %cond.load462
	add	x11, x9, #24
	ld1.s	{ v3 }[2], [x11]
	tbnz	w10, #7, LBB0_329
	b	LBB0_330
LBB0_322:                               ; %else445
	tbz	w10, #1, LBB0_316
LBB0_323:                               ; %cond.load447
	add	x13, x9, #4
	ld1.s	{ v2 }[1], [x13]
	tbnz	w10, #2, LBB0_317
LBB0_324:                               ; %else451
	tbz	w10, #3, LBB0_318
LBB0_325:                               ; %cond.load453
	add	x13, x9, #12
	ld1.s	{ v2 }[3], [x13]
	ldr	q3, [x11, #16]
	tbnz	w10, #4, LBB0_319
LBB0_326:                               ; %else457
	tbz	w10, #5, LBB0_320
LBB0_327:                               ; %cond.load459
	add	x11, x9, #20
	ld1.s	{ v3 }[1], [x11]
	tbnz	w10, #6, LBB0_321
LBB0_328:                               ; %else463
	tbz	w10, #7, LBB0_330
LBB0_329:                               ; %cond.load465
	add	x9, x9, #28
	ld1.s	{ v3 }[3], [x9]
LBB0_330:                               ; %else466
	mov	x17, #0                         ; =0x0
	add	x9, sp, #880
	add	x10, x9, x15
	stp	q2, q3, [x10]
	add	x10, x8, x14
	movi.2d	v27, #0000000000000000
	fmov	w11, s17
	add	x13, sp, #2, lsl #12            ; =8192
	add	x13, x13, #2000
	add	x15, sp, #3984
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #2992
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v9, #0000000000000000
	b	LBB0_332
LBB0_331:                               ; %else484
                                        ;   in Loop: Header=BB0_332 Depth=1
	add.2d	v28, v28, v24
	add.2d	v29, v29, v25
	add.2d	v9, v9, v23
	add.2d	v27, v27, v26
	fmov	x17, d27
	cmp	x17, #96
	b.ge	LBB0_348
LBB0_332:                               ; %direct.true145
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x17, x17, #5
	add	x1, x13, x17
	ldr	q10, [x1]
	add	x2, x15, x17
	ldr	q11, [x2]
	fmul.4s	v10, v10, v11
	add	x3, x16, x17
	ldr	q11, [x3]
	add	x4, x9, x17
	ldr	q12, [x4]
	fmul.4s	v11, v11, v12
	fsub.4s	v10, v10, v11
	and.16b	v10, v5, v10
	add	x17, x10, x17
	tbz	w11, #0, LBB0_336
; %bb.333:                              ; %cond.store469
                                        ;   in Loop: Header=BB0_332 Depth=1
	str	s10, [x17]
	and	w0, w11, #0xff
	tbnz	w0, #1, LBB0_337
LBB0_334:                               ; %else472
                                        ;   in Loop: Header=BB0_332 Depth=1
	tbz	w0, #2, LBB0_338
LBB0_335:                               ; %cond.store473
                                        ;   in Loop: Header=BB0_332 Depth=1
	add	x5, x17, #8
	st1.s	{ v10 }[2], [x5]
	tbnz	w0, #3, LBB0_339
	b	LBB0_340
LBB0_336:                               ; %else470
                                        ;   in Loop: Header=BB0_332 Depth=1
	and	w0, w11, #0xff
	tbz	w0, #1, LBB0_334
LBB0_337:                               ; %cond.store471
                                        ;   in Loop: Header=BB0_332 Depth=1
	add	x5, x17, #4
	st1.s	{ v10 }[1], [x5]
	tbnz	w0, #2, LBB0_335
LBB0_338:                               ; %else474
                                        ;   in Loop: Header=BB0_332 Depth=1
	tbz	w0, #3, LBB0_340
LBB0_339:                               ; %cond.store475
                                        ;   in Loop: Header=BB0_332 Depth=1
	add	x5, x17, #12
	st1.s	{ v10 }[3], [x5]
LBB0_340:                               ; %else476
                                        ;   in Loop: Header=BB0_332 Depth=1
	ldr	q10, [x1, #16]
	ldr	q11, [x2, #16]
	fmul.4s	v10, v10, v11
	ldr	q11, [x3, #16]
	ldr	q12, [x4, #16]
	fmul.4s	v11, v11, v12
	fsub.4s	v10, v10, v11
	and.16b	v10, v4, v10
	tbz	w0, #4, LBB0_344
; %bb.341:                              ; %cond.store477
                                        ;   in Loop: Header=BB0_332 Depth=1
	str	s10, [x17, #16]
	tbnz	w0, #5, LBB0_345
LBB0_342:                               ; %else480
                                        ;   in Loop: Header=BB0_332 Depth=1
	tbz	w0, #6, LBB0_346
LBB0_343:                               ; %cond.store481
                                        ;   in Loop: Header=BB0_332 Depth=1
	add	x1, x17, #24
	st1.s	{ v10 }[2], [x1]
	tbz	w0, #7, LBB0_331
	b	LBB0_347
LBB0_344:                               ; %else478
                                        ;   in Loop: Header=BB0_332 Depth=1
	tbz	w0, #5, LBB0_342
LBB0_345:                               ; %cond.store479
                                        ;   in Loop: Header=BB0_332 Depth=1
	add	x1, x17, #20
	st1.s	{ v10 }[1], [x1]
	tbnz	w0, #6, LBB0_343
LBB0_346:                               ; %else482
                                        ;   in Loop: Header=BB0_332 Depth=1
	tbz	w0, #7, LBB0_331
LBB0_347:                               ; %cond.store483
                                        ;   in Loop: Header=BB0_332 Depth=1
	add	x17, x17, #28
	st1.s	{ v10 }[3], [x17]
	b	LBB0_331
LBB0_348:                               ; %direct.false146
	fmul.4s	v27, v20, v0
	fmul.4s	v28, v31, v2
	fsub.4s	v27, v27, v28
	zip2.8b	v28, v18, v0
	zip1.8b	v29, v18, v0
	ushll.4s	v29, v29, #0
	shl.4s	v29, v29, #31
	cmlt.4s	v29, v29, #0
	and.16b	v27, v29, v27
	fmov	w9, s30
	ldr	q22, [sp, #64]                  ; 16-byte Reload
	ldp	q29, q16, [sp, #16]             ; 32-byte Folded Reload
	stp	q22, q29, [sp, #496]
	str	q16, [sp, #528]
	ldr	q16, [sp]                       ; 16-byte Reload
	str	q16, [sp, #544]
	and	x10, x12, #0x7
	add	x11, sp, #496
	ldr	x10, [x11, x10, lsl #3]
	sub	x10, x10, x12
	add	x10, x8, x10, lsl #2
	tbz	w9, #0, LBB0_356
; %bb.349:                              ; %cond.store486
	str	s27, [x10]
	ushll.4s	v28, v28, #0
	tbnz	w9, #1, LBB0_357
LBB0_350:                               ; %else489
	fmul.4s	v22, v21, v1
	fmul.4s	v29, v8, v3
	shl.4s	v28, v28, #31
	tbz	w9, #2, LBB0_358
LBB0_351:                               ; %cond.store490
	add	x11, x10, #8
	st1.s	{ v27 }[2], [x11]
	fsub.4s	v22, v22, v29
	cmlt.4s	v28, v28, #0
	tbnz	w9, #3, LBB0_359
LBB0_352:                               ; %else493
	and.16b	v22, v28, v22
	tbz	w9, #4, LBB0_360
LBB0_353:                               ; %cond.store494
	str	s22, [x10, #16]
	tbnz	w9, #5, LBB0_361
LBB0_354:                               ; %else497
	tbz	w9, #6, LBB0_362
LBB0_355:                               ; %cond.store498
	add	x11, x10, #24
	st1.s	{ v22 }[2], [x11]
	tbnz	w9, #7, LBB0_363
	b	LBB0_364
LBB0_356:                               ; %else487
	ushll.4s	v28, v28, #0
	tbz	w9, #1, LBB0_350
LBB0_357:                               ; %cond.store488
	add	x11, x10, #4
	st1.s	{ v27 }[1], [x11]
	fmul.4s	v22, v21, v1
	fmul.4s	v29, v8, v3
	shl.4s	v28, v28, #31
	tbnz	w9, #2, LBB0_351
LBB0_358:                               ; %else491
	fsub.4s	v22, v22, v29
	cmlt.4s	v28, v28, #0
	tbz	w9, #3, LBB0_352
LBB0_359:                               ; %cond.store492
	add	x11, x10, #12
	st1.s	{ v27 }[3], [x11]
	and.16b	v22, v28, v22
	tbnz	w9, #4, LBB0_353
LBB0_360:                               ; %else495
	tbz	w9, #5, LBB0_354
LBB0_361:                               ; %cond.store496
	add	x11, x10, #20
	st1.s	{ v22 }[1], [x11]
	tbnz	w9, #6, LBB0_355
LBB0_362:                               ; %else499
	tbz	w9, #7, LBB0_364
LBB0_363:                               ; %cond.store500
	add	x9, x10, #28
	st1.s	{ v22 }[3], [x9]
LBB0_364:                               ; %else501
	mov	x16, #0                         ; =0x0
	add	x9, x8, x14
	movi.2d	v22, #0000000000000000
	fmov	w10, s17
	add	x11, sp, #2, lsl #12            ; =8192
	add	x11, x11, #2000
	movi.2d	v17, #0000000000000000
	add	x13, sp, #880
	add	x14, sp, #1, lsl #12            ; =4096
	add	x14, x14, #2992
	movi.2d	v27, #0000000000000000
	add	x15, sp, #3984
	movi.2d	v28, #0000000000000000
	b	LBB0_366
LBB0_365:                               ; %else518
                                        ;   in Loop: Header=BB0_366 Depth=1
	add.2d	v17, v17, v24
	add.2d	v27, v27, v25
	add.2d	v28, v28, v23
	add.2d	v22, v22, v26
	fmov	x16, d22
	cmp	x16, #96
	b.ge	LBB0_382
LBB0_366:                               ; %direct.true184
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x16, x16, #5
	add	x0, x11, x16
	ldr	q29, [x0]
	add	x1, x13, x16
	ldr	q9, [x1]
	fmul.4s	v29, v29, v9
	add	x2, x14, x16
	ldr	q9, [x2]
	add	x3, x15, x16
	ldr	q10, [x3]
	fmul.4s	v9, v9, v10
	fadd.4s	v29, v29, v9
	and.16b	v29, v5, v29
	add	x16, x9, x16
	add	x16, x16, #3076
	tbz	w10, #0, LBB0_370
; %bb.367:                              ; %cond.store503
                                        ;   in Loop: Header=BB0_366 Depth=1
	str	s29, [x16]
	and	w17, w10, #0xff
	tbnz	w17, #1, LBB0_371
LBB0_368:                               ; %else506
                                        ;   in Loop: Header=BB0_366 Depth=1
	tbz	w17, #2, LBB0_372
LBB0_369:                               ; %cond.store507
                                        ;   in Loop: Header=BB0_366 Depth=1
	add	x4, x16, #8
	st1.s	{ v29 }[2], [x4]
	tbnz	w17, #3, LBB0_373
	b	LBB0_374
LBB0_370:                               ; %else504
                                        ;   in Loop: Header=BB0_366 Depth=1
	and	w17, w10, #0xff
	tbz	w17, #1, LBB0_368
LBB0_371:                               ; %cond.store505
                                        ;   in Loop: Header=BB0_366 Depth=1
	add	x4, x16, #4
	st1.s	{ v29 }[1], [x4]
	tbnz	w17, #2, LBB0_369
LBB0_372:                               ; %else508
                                        ;   in Loop: Header=BB0_366 Depth=1
	tbz	w17, #3, LBB0_374
LBB0_373:                               ; %cond.store509
                                        ;   in Loop: Header=BB0_366 Depth=1
	add	x4, x16, #12
	st1.s	{ v29 }[3], [x4]
LBB0_374:                               ; %else510
                                        ;   in Loop: Header=BB0_366 Depth=1
	ldr	q29, [x0, #16]
	ldr	q9, [x1, #16]
	fmul.4s	v29, v29, v9
	ldr	q9, [x2, #16]
	ldr	q10, [x3, #16]
	fmul.4s	v9, v9, v10
	fadd.4s	v29, v29, v9
	and.16b	v29, v4, v29
	tbz	w17, #4, LBB0_378
; %bb.375:                              ; %cond.store511
                                        ;   in Loop: Header=BB0_366 Depth=1
	str	s29, [x16, #16]
	tbnz	w17, #5, LBB0_379
LBB0_376:                               ; %else514
                                        ;   in Loop: Header=BB0_366 Depth=1
	tbz	w17, #6, LBB0_380
LBB0_377:                               ; %cond.store515
                                        ;   in Loop: Header=BB0_366 Depth=1
	add	x0, x16, #24
	st1.s	{ v29 }[2], [x0]
	tbz	w17, #7, LBB0_365
	b	LBB0_381
LBB0_378:                               ; %else512
                                        ;   in Loop: Header=BB0_366 Depth=1
	tbz	w17, #5, LBB0_376
LBB0_379:                               ; %cond.store513
                                        ;   in Loop: Header=BB0_366 Depth=1
	add	x0, x16, #20
	st1.s	{ v29 }[1], [x0]
	tbnz	w17, #6, LBB0_377
LBB0_380:                               ; %else516
                                        ;   in Loop: Header=BB0_366 Depth=1
	tbz	w17, #7, LBB0_365
LBB0_381:                               ; %cond.store517
                                        ;   in Loop: Header=BB0_366 Depth=1
	add	x16, x16, #28
	st1.s	{ v29 }[3], [x16]
	b	LBB0_365
LBB0_382:                               ; %direct.false185
	fmul.4s	v2, v20, v2
	fmul.4s	v0, v31, v0
	fadd.4s	v0, v0, v2
	zip2.8b	v2, v18, v0
	zip1.8b	v4, v18, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v0, v4, v0
	fmov	w9, s30
	stp	q19, q6, [sp, #416]
	ldr	q4, [sp, #48]                   ; 16-byte Reload
	stp	q7, q4, [sp, #448]
	and	x10, x12, #0x7
	add	x11, sp, #416
	ldr	x10, [x11, x10, lsl #3]
	sub	x10, x10, x12
	add	x8, x8, x10, lsl #2
	tbz	w9, #0, LBB0_393
; %bb.383:                              ; %cond.store520
	str	s0, [x8]
	ushll.4s	v4, v2, #0
	tbnz	w9, #1, LBB0_394
LBB0_384:                               ; %else523
	fmul.4s	v2, v21, v3
	fmul.4s	v1, v8, v1
	shl.4s	v3, v4, #31
	tbz	w9, #2, LBB0_395
LBB0_385:                               ; %cond.store524
	add	x10, x8, #8
	st1.s	{ v0 }[2], [x10]
	fadd.4s	v1, v1, v2
	cmlt.4s	v2, v3, #0
	tbnz	w9, #3, LBB0_396
LBB0_386:                               ; %else527
	and.16b	v0, v2, v1
	tbnz	w9, #4, LBB0_187
LBB0_387:                               ; %else261
	tbz	w9, #5, LBB0_188
LBB0_388:                               ; %cond.store262
	add	x10, x8, #20
	st1.s	{ v0 }[1], [x10]
	tbnz	w9, #6, LBB0_189
LBB0_389:                               ; %else265
	tbz	w9, #7, LBB0_391
LBB0_390:                               ; %cond.store534
	add	x8, x8, #28
	st1.s	{ v0 }[3], [x8]
LBB0_391:
	add	sp, sp, #3, lsl #12             ; =12288
	add	sp, sp, #1008
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #80             ; 16-byte Folded Reload
LBB0_392:                               ; %common.ret
	ret
LBB0_393:                               ; %else521
	ushll.4s	v4, v2, #0
	tbz	w9, #1, LBB0_384
LBB0_394:                               ; %cond.store522
	add	x10, x8, #4
	st1.s	{ v0 }[1], [x10]
	fmul.4s	v2, v21, v3
	fmul.4s	v1, v8, v1
	shl.4s	v3, v4, #31
	tbnz	w9, #2, LBB0_385
LBB0_395:                               ; %else525
	fadd.4s	v1, v1, v2
	cmlt.4s	v2, v3, #0
	tbz	w9, #3, LBB0_386
LBB0_396:                               ; %cond.store526
	add	x10, x8, #12
	st1.s	{ v0 }[3], [x10]
	and.16b	v0, v2, v1
	tbz	w9, #4, LBB0_387
	b	LBB0_187
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
                                        ; -- End function
	.p2align	2                               ; -- Begin function llm_rows.full_packet
_llm_rows.full_packet:                  ; @llm_rows.full_packet
; %bb.0:                                ; %prologue
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #3, lsl #12             ; =12288
	sub	sp, sp, #208
	ldr	x23, [x0]
	ldr	x22, [x0, #16]
	ldr	x21, [x0, #32]
	ldr	w8, [x1]
	ldr	w9, [x1, #36]
	add	w8, w9, w8, lsl #5
	lsr	w8, w8, #3
	dup.2s	v0, w8
	ldr	x20, [x0, #48]
	ushll.2d	v0, v0, #0
	subs	x8, x23, x20
	cset	w9, hs
	mov	w12, #8199                      ; =0x2007
	movk	w12, #24, lsl #16
	cmp	x8, x12
	csel	w8, wzr, w9, ls
	subs	x9, x20, x23
	cset	w10, hs
	cmp	x9, x12
	csel	w9, wzr, w10, ls
	subs	x10, x22, x20
	cset	w11, hs
	cmp	x10, x12
	csel	w10, wzr, w11, ls
	subs	x11, x20, x22
	cset	w13, hs
	mov	w14, #4099                      ; =0x1003
	movk	w14, #12, lsl #16
	cmp	x11, x14
	csel	w11, wzr, w13, ls
	subs	x13, x21, x20
	cset	w15, hs
	cmp	x13, x12
	csel	w12, wzr, w15, ls
	subs	x13, x20, x21
	cset	w15, hs
	cmp	x13, x14
	csel	w13, wzr, w15, ls
	orr	w12, w12, w13
	cmp	w12, #1
	b.ne	LBB1_6
; %bb.1:                                ; %prologue
	orr	w8, w8, w9
	cbz	w8, LBB1_6
; %bb.2:                                ; %prologue
	orr	w8, w10, w11
	tbz	w8, #0, LBB1_6
; %bb.3:                                ; %direct.schedule.2.preheader
	mov	x9, #0                          ; =0x0
	mov	w8, #1538                       ; =0x602
	dup.2s	v1, w8
	xtn.2s	v2, v0
	umull.2d	v1, v2, v1
	fmov	x11, d1
	fmov	x8, d0
	mov	w10, #769                       ; =0x301
	umull	x10, w8, w10
	lsl	x11, x11, #2
	add	x12, x11, #3076
	add	x11, x23, x12
	add	x12, x20, x12
LBB1_4:                                 ; %direct.true31
                                        ; =>This Inner Loop Header: Depth=1
	fmov	d2, x9
	add.2d	v2, v2, v1
	fmov	x13, d2
	lsl	x13, x13, #2
	add	x14, x23, x13
	ldp	q2, q3, [x14]
	ldp	q4, q5, [x11], #32
	add	x14, x9, x10
	lsl	x14, x14, #2
	add	x15, x22, x14
	ldp	q6, q7, [x15]
	add	x14, x21, x14
	ldp	q16, q17, [x14]
	fmul.4s	v18, v3, v7
	fmul.4s	v19, v2, v6
	fmul.4s	v20, v5, v17
	fmul.4s	v21, v4, v16
	fsub.4s	v19, v19, v21
	fsub.4s	v18, v18, v20
	add	x13, x20, x13
	stp	q19, q18, [x13]
	fmul.4s	v3, v3, v17
	fmul.4s	v2, v2, v16
	fmul.4s	v5, v5, v7
	fmul.4s	v4, v4, v6
	fadd.4s	v2, v4, v2
	fadd.4s	v3, v5, v3
	stp	q2, q3, [x12], #32
	add	x9, x9, #8
	cmp	x9, #768
	b.ne	LBB1_4
; %bb.5:                                ; %direct.false32
	fmov	x9, d0
	mov	w10, #6152                      ; =0x1808
	umull	x11, w9, w10
	add	x11, x11, #3072
	ldr	s0, [x23, x11]
	mov	w12, #6148                      ; =0x1804
	umaddl	x19, w9, w10, x12
	ldr	s1, [x23, x19]
	mov	w9, #3076                       ; =0xc04
	umull	x8, w8, w9
	add	x8, x8, #3072
	ldr	s2, [x22, x8]
	ldr	s3, [x21, x8]
	fmul.4s	v4, v0, v2
	fmul.4s	v5, v1, v3
	fsub.4s	v4, v4, v5
	str	s4, [x20, x11]
	fmul.4s	v0, v0, v3
	fmul.4s	v1, v1, v2
	b	LBB1_11
LBB1_6:                                 ; %direct.schedule.8.preheader
	fmov	x28, d0
	mov	w8, #6152                       ; =0x1808
	umull	x24, w28, w8
	umaddl	x19, w28, w8, x23
	mov	w25, #6152                      ; =0x1808
	add	x26, sp, #2, lsl #12            ; =8192
	add	x26, x26, #1200
	add	x0, sp, #2, lsl #12             ; =8192
	add	x0, x0, #1200
	mov	x1, x19
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	str	x24, [sp, #40]                  ; 8-byte Spill
	add	x8, x24, #3072
	str	x8, [sp, #8]                    ; 8-byte Spill
	ldr	s0, [x23, x8]
	str	q0, [sp, #64]                   ; 16-byte Spill
	str	q0, [sp, #12464]
	add	x27, sp, #1, lsl #12            ; =4096
	add	x27, x27, #2192
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2192
	add	x1, x19, #3076
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	mov	w8, #6148                       ; =0x1804
	umaddl	x19, w28, w25, x8
	ldr	s0, [x23, x19]
	str	q0, [sp, #48]                   ; 16-byte Spill
	str	q0, [sp, #9360]
	mov	w24, #3076                      ; =0xc04
	umull	x25, w28, w24
	umaddl	x1, w28, w24, x22
	add	x23, sp, #3184
	add	x0, sp, #3184
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	add	x25, x25, #3072
	ldr	s0, [x22, x25]
	str	q0, [sp, #16]                   ; 16-byte Spill
	str	q0, [sp, #6256]
	umaddl	x1, w28, w24, x21
	add	x22, sp, #80
	add	x0, sp, #80
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	ldr	s0, [x21, x25]
	str	q0, [sp, #3152]
	mov	w9, #6152                       ; =0x1808
	umaddl	x9, w28, w9, x20
LBB1_7:                                 ; %direct.true145
                                        ; =>This Inner Loop Header: Depth=1
	add	x10, x26, x8
	ldp	q1, q2, [x10]
	add	x10, x23, x8
	ldp	q3, q4, [x10]
	fmul.4s	v2, v2, v4
	fmul.4s	v1, v1, v3
	add	x10, x27, x8
	ldp	q3, q4, [x10]
	add	x10, x22, x8
	ldp	q5, q6, [x10]
	fmul.4s	v4, v4, v6
	fmul.4s	v3, v3, v5
	fsub.4s	v1, v1, v3
	fsub.4s	v2, v2, v4
	add	x10, x9, x8
	stp	q1, q2, [x10]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB1_7
; %bb.8:                                ; %direct.false146
	mov	x8, #0                          ; =0x0
	ldp	q16, q7, [sp, #48]              ; 32-byte Folded Reload
	ldr	q17, [sp, #16]                  ; 16-byte Reload
	fmul.4s	v1, v7, v17
	fmul.4s	v2, v16, v0
	fsub.4s	v1, v1, v2
	ldr	x9, [sp, #8]                    ; 8-byte Reload
	str	s1, [x20, x9]
	ldr	x9, [sp, #40]                   ; 8-byte Reload
	add	x9, x9, x20
	add	x9, x9, #3076
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #1200
	add	x11, sp, #80
	add	x12, sp, #1, lsl #12            ; =4096
	add	x12, x12, #2192
	add	x13, sp, #3184
LBB1_9:                                 ; %direct.true184
                                        ; =>This Inner Loop Header: Depth=1
	add	x14, x10, x8
	ldp	q1, q2, [x14]
	add	x14, x11, x8
	ldp	q3, q4, [x14]
	fmul.4s	v2, v2, v4
	fmul.4s	v1, v1, v3
	add	x14, x12, x8
	ldp	q3, q4, [x14]
	add	x14, x13, x8
	ldp	q5, q6, [x14]
	fmul.4s	v4, v4, v6
	fmul.4s	v3, v3, v5
	fadd.4s	v1, v1, v3
	fadd.4s	v2, v2, v4
	add	x14, x9, x8
	stp	q1, q2, [x14]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB1_9
; %bb.10:                               ; %direct.false185
	fmul.4s	v0, v7, v0
	fmul.4s	v1, v16, v17
LBB1_11:                                ; %common.ret
	fadd.4s	v0, v1, v0
	str	s0, [x20, x19]
	add	sp, sp, #3, lsl #12             ; =12288
	add	sp, sp, #208
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB2_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB2_4
LBB2_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB2_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB2_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB2_13
LBB2_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB2_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB2_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #1
	b.eq	LBB2_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #2
	b.eq	LBB2_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x28, #3
	b.eq	LBB2_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB2_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB2_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
LBB2_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB2_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB2_3
LBB2_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB2_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

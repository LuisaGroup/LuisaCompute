; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @tile_inclusive_scan(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [128 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [4096 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local4 = alloca [4096 x i8], align 4
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local7 = alloca [4096 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local10 = alloca [4096 x i8], align 4
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %8 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %9 = insertvalue { <8 x ptr>, <8 x i64> } %8, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local13 = alloca [4096 x i8], align 4
  %.splatinsert14 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local13, i64 0
  %.splat15 = shufflevector <8 x ptr> %.splatinsert14, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat15, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local16 = alloca [4096 x i8], align 4
  %.splatinsert17 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local16, i64 0
  %.splat18 = shufflevector <8 x ptr> %.splatinsert17, <8 x ptr> poison, <8 x i32> zeroinitializer
  %12 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat18, 0
  %13 = insertvalue { <8 x ptr>, <8 x i64> } %12, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill19 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill19, align 4
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.slot20 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot20, align 32
  %.slot21 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot21, align 32
  %.slot22 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot22, align 32
  %.slot23 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot23, align 32
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.spill24 = alloca i64, align 8
  store i64 0, ptr %.spill24, align 4
  %tile_snapshot.spill25 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill25, align 64
  %.slot26 = alloca i64, align 8
  store i64 0, ptr %.slot26, align 4
  %tile_snapshot.spill27 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill27, align 64
  %.slot28 = alloca i64, align 8
  store i64 0, ptr %.slot28, align 4
  %.spill29 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill29, align 32
  %.spill30 = alloca i1, align 1
  store i1 false, ptr %.spill30, align 1
  %.spill31 = alloca i64, align 8
  store i64 0, ptr %.spill31, align 4
  %.slot32 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot32, align 32
  %tile_snapshot.spill33 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill33, align 64
  %.slot34 = alloca i64, align 8
  store i64 0, ptr %.slot34, align 4
  %.spill35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill35, align 32
  %.spill36 = alloca i1, align 1
  store i1 false, ptr %.spill36, align 1
  %.spill37 = alloca i64, align 8
  store i64 0, ptr %.spill37, align 4
  %.slot38 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot38, align 32
  %tile_snapshot.spill39 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill39, align 64
  %.slot40 = alloca i64, align 8
  store i64 0, ptr %.slot40, align 4
  %.spill41 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill41, align 32
  %.spill42 = alloca i1, align 1
  store i1 false, ptr %.spill42, align 1
  %.spill43 = alloca i64, align 8
  store i64 0, ptr %.spill43, align 4
  %.slot44 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot44, align 32
  %tile_snapshot.spill45 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill45, align 64
  %.slot46 = alloca i64, align 8
  store i64 0, ptr %.slot46, align 4
  %.spill47 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill47, align 32
  %.spill48 = alloca i1, align 1
  store i1 false, ptr %.spill48, align 1
  %.spill49 = alloca i64, align 8
  store i64 0, ptr %.spill49, align 4
  %.slot50 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot50, align 32
  %tile_snapshot.spill51 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill51, align 64
  %.slot52 = alloca i64, align 8
  store i64 0, ptr %.slot52, align 4
  %.spill53 = alloca i64, align 8
  store i64 0, ptr %.spill53, align 4
  %.spill54 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill54, align 32
  %.spill55 = alloca i1, align 1
  store i1 false, ptr %.spill55, align 1
  %.spill56 = alloca i64, align 8
  store i64 0, ptr %.spill56, align 4
  %.slot57 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot57, align 32
  %.slot58 = alloca i64, align 8
  store i64 0, ptr %.slot58, align 4
  %14 = getelementptr i8, ptr %argument_buffer, i64 0
  %15 = load ptr, ptr %14, align 16
  %16 = getelementptr i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = insertvalue { ptr, i64 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i64 } %18, i64 %17, 1
  %20 = getelementptr i8, ptr %argument_buffer, i64 16
  %21 = load ptr, ptr %20, align 16
  %22 = getelementptr i8, ptr %20, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = insertvalue { ptr, i64 } poison, ptr %21, 0
  %25 = insertvalue { ptr, i64 } %24, i64 %23, 1
  %26 = load i32, ptr %launch_config, align 4
  %27 = getelementptr i8, ptr %launch_config, i64 12
  %28 = load i32, ptr %27, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 4
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 16
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 8
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 20
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 36
  %38 = load i32, ptr %37, align 4
  %.splatinsert59 = insertelement <8 x i32> poison, i32 %38, i64 0
  %.splat60 = shufflevector <8 x i32> %.splatinsert59, <8 x i32> poison, <8 x i32> zeroinitializer
  %39 = add <8 x i32> %.splat60, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %40 = mul i32 %26, 32
  %.splatinsert61 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat62 = shufflevector <8 x i32> %.splatinsert61, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat62, %39
  %42 = mul i32 %30, 1
  %.splatinsert63 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat64 = shufflevector <8 x i32> %.splatinsert63, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat64, zeroinitializer
  %44 = mul i32 %34, 1
  %.splatinsert65 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat66 = shufflevector <8 x i32> %.splatinsert65, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat66, zeroinitializer
  %46 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %41, 0
  %47 = insertvalue [3 x <8 x i32>] %46, <8 x i32> %43, 1
  %48 = insertvalue [3 x <8 x i32>] %47, <8 x i32> %45, 2
  %.splatinsert67 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat68 = shufflevector <8 x i32> %.splatinsert67, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat68
  %50 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  br i1 %50, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %51 = extractvalue [3 x <8 x i32>] %48, 0
  %52 = zext <8 x i32> %51 to <8 x i64>
  %53 = select <8 x i1> %49, <8 x i64> %52, <8 x i64> zeroinitializer
  %54 = select <8 x i1> %49, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %55 = sdiv <8 x i64> %53, %54
  %56 = mul <8 x i64> %55, splat (i64 4)
  %57 = load <8 x i64>, ptr %.spill, align 64
  %58 = select <8 x i1> %49, <8 x i64> %56, <8 x i64> %57
  store <8 x i64> %58, ptr %.spill, align 64
  store float 0xFFF0000000000000, ptr %.spill19, align 4
  store i64 0, ptr %.slot, align 4
  %59 = load <8 x float>, ptr %.slot20, align 32
  %60 = select <8 x i1> %49, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %59
  store <8 x float> %60, ptr %.slot20, align 32
  %61 = load <8 x float>, ptr %.slot21, align 32
  %62 = select <8 x i1> %49, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %61
  store <8 x float> %62, ptr %.slot21, align 32
  %63 = load <8 x float>, ptr %.slot22, align 32
  %64 = select <8 x i1> %49, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %63
  store <8 x float> %64, ptr %.slot22, align 32
  %65 = load <8 x float>, ptr %.slot23, align 32
  %66 = select <8 x i1> %49, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %65
  store <8 x float> %66, ptr %.slot23, align 32
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.33, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %67 = icmp slt i64 %.state, 32
  br i1 %67, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %68 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %69 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %68, 0
  %71 = select <8 x i1> %49, <8 x ptr> %69, <8 x ptr> %70
  %72 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %73 = extractvalue { <8 x ptr>, <8 x i64> } %68, 1
  %74 = select <8 x i1> %49, <8 x i64> %72, <8 x i64> %73
  %75 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %71, 0
  %76 = insertvalue { <8 x ptr>, <8 x i64> } %75, <8 x i64> %74, 1
  store { <8 x ptr>, <8 x i64> } %76, ptr %tile_snapshot.spill, align 64
  %77 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %78 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %79 = add <8 x i64> %78, zeroinitializer
  %80 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %77, 0
  %81 = insertvalue { <8 x ptr>, <8 x i64> } %80, <8 x i64> %79, 1
  %.state69 = load <8 x float>, ptr %.slot20, align 32
  %82 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %83 = extractvalue { <8 x ptr>, <8 x i64> } %81, 1
  %84 = extractelement <8 x ptr> %82, i32 0
  %85 = extractelement <8 x i64> %83, i32 0
  %86 = sub i64 %85, 0
  %87 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %88 = select i1 %87, i64 %86, i64 0
  %private.contiguous.address = getelementptr i8, ptr %84, i64 %88
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %89 = select <8 x i1> %49, <8 x float> %.state69, <8 x float> %private.contiguous.preserve
  store <8 x float> %89, ptr %private.contiguous.address, align 4
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %91 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %92 = add <8 x i64> %91, splat (i64 32)
  %93 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %90, 0
  %94 = insertvalue { <8 x ptr>, <8 x i64> } %93, <8 x i64> %92, 1
  %.state70 = load <8 x float>, ptr %.slot21, align 32
  %95 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %96 = extractvalue { <8 x ptr>, <8 x i64> } %94, 1
  %97 = extractelement <8 x ptr> %95, i32 0
  %98 = extractelement <8 x i64> %96, i32 0
  %99 = sub i64 %98, 0
  %100 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %101 = select i1 %100, i64 %99, i64 0
  %private.contiguous.address71 = getelementptr i8, ptr %97, i64 %101
  %private.contiguous.preserve72 = load <8 x float>, ptr %private.contiguous.address71, align 4
  %102 = select <8 x i1> %49, <8 x float> %.state70, <8 x float> %private.contiguous.preserve72
  store <8 x float> %102, ptr %private.contiguous.address71, align 4
  %103 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %104 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %105 = add <8 x i64> %104, splat (i64 64)
  %106 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %103, 0
  %107 = insertvalue { <8 x ptr>, <8 x i64> } %106, <8 x i64> %105, 1
  %.state73 = load <8 x float>, ptr %.slot22, align 32
  %108 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %107, 1
  %110 = extractelement <8 x ptr> %108, i32 0
  %111 = extractelement <8 x i64> %109, i32 0
  %112 = sub i64 %111, 0
  %113 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %114 = select i1 %113, i64 %112, i64 0
  %private.contiguous.address74 = getelementptr i8, ptr %110, i64 %114
  %private.contiguous.preserve75 = load <8 x float>, ptr %private.contiguous.address74, align 4
  %115 = select <8 x i1> %49, <8 x float> %.state73, <8 x float> %private.contiguous.preserve75
  store <8 x float> %115, ptr %private.contiguous.address74, align 4
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %117 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %118 = add <8 x i64> %117, splat (i64 96)
  %119 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %116, 0
  %120 = insertvalue { <8 x ptr>, <8 x i64> } %119, <8 x i64> %118, 1
  %.state76 = load <8 x float>, ptr %.slot23, align 32
  %121 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %120, 1
  %123 = extractelement <8 x ptr> %121, i32 0
  %124 = extractelement <8 x i64> %122, i32 0
  %125 = sub i64 %124, 0
  %126 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %127 = select i1 %126, i64 %125, i64 0
  %private.contiguous.address77 = getelementptr i8, ptr %123, i64 %127
  %private.contiguous.preserve78 = load <8 x float>, ptr %private.contiguous.address77, align 4
  %128 = select <8 x i1> %49, <8 x float> %.state76, <8 x float> %private.contiguous.preserve78
  store <8 x float> %128, ptr %private.contiguous.address77, align 4
  %.state79 = load i64, ptr %.slot, align 4
  %129 = sdiv i64 %.state79, 1
  %130 = mul i64 %129, 32
  store i64 %130, ptr %.spill24, align 4
  %131 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %132 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %133 = extractvalue { <8 x ptr>, <8 x i64> } %131, 0
  %134 = select <8 x i1> %49, <8 x ptr> %132, <8 x ptr> %133
  %135 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %136 = extractvalue { <8 x ptr>, <8 x i64> } %131, 1
  %137 = select <8 x i1> %49, <8 x i64> %135, <8 x i64> %136
  %138 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %134, 0
  %139 = insertvalue { <8 x ptr>, <8 x i64> } %138, <8 x i64> %137, 1
  store { <8 x ptr>, <8 x i64> } %139, ptr %tile_snapshot.spill25, align 64
  store i64 0, ptr %.slot26, align 4
  br label %direct.schedule.3

direct.schedule.3:                                ; preds = %direct.schedule.4, %direct.schedule.2
  %.state80 = load i64, ptr %.slot26, align 4
  %140 = icmp slt i64 %.state80, 128
  br i1 %140, label %direct.true81, label %direct.false82

direct.schedule.4:                                ; preds = %direct.true81
  %.state83 = load i64, ptr %.slot26, align 4
  %141 = srem i64 %.state83, 32
  %.state84 = load i64, ptr %.slot26, align 4
  %142 = sdiv i64 %.state84, 32
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %.splatinsert85 = insertelement <8 x i64> poison, i64 %142, i64 0
  %.splat86 = shufflevector <8 x i64> %.splatinsert85, <8 x i64> poison, <8 x i32> zeroinitializer
  %143 = add <8 x i64> %.spill.load, %.splat86
  %144 = add <8 x i64> zeroinitializer, %143
  %.spill.load87 = load i64, ptr %.spill24, align 4
  %145 = add i64 %.spill.load87, %141
  %146 = mul <8 x i64> %144, splat (i64 1024)
  %.splatinsert88 = insertelement <8 x i64> poison, i64 %145, i64 0
  %.splat89 = shufflevector <8 x i64> %.splatinsert88, <8 x i64> poison, <8 x i32> zeroinitializer
  %147 = add <8 x i64> %146, %.splat89
  %148 = extractvalue { ptr, i64 } %19, 0
  %149 = mul <8 x i64> %147, splat (i64 4)
  %150 = getelementptr i8, ptr %148, <8 x i64> %149
  %151 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %150, i32 1, <8 x i1> %49, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %152 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state90 = load i64, ptr %.slot26, align 4
  %.splatinsert91 = insertelement <8 x i64> poison, i64 %.state90, i64 0
  %.splat92 = shufflevector <8 x i64> %.splatinsert91, <8 x i64> poison, <8 x i32> zeroinitializer
  %154 = mul <8 x i64> %.splat92, splat (i64 32)
  %155 = add <8 x i64> %153, %154
  %156 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %152, 0
  %157 = insertvalue { <8 x ptr>, <8 x i64> } %156, <8 x i64> %155, 1
  %158 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %159 = extractvalue { <8 x ptr>, <8 x i64> } %157, 1
  %160 = extractelement <8 x ptr> %158, i32 0
  %161 = extractelement <8 x i64> %159, i32 0
  %162 = sub i64 %161, 0
  %163 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %164 = select i1 %163, i64 %162, i64 0
  %private.contiguous.address93 = getelementptr i8, ptr %160, i64 %164
  %private.contiguous.preserve94 = load <8 x float>, ptr %private.contiguous.address93, align 4
  %165 = select <8 x i1> %49, <8 x float> %151, <8 x float> %private.contiguous.preserve94
  store <8 x float> %165, ptr %private.contiguous.address93, align 4
  %.state95 = load i64, ptr %.slot26, align 4
  %166 = add i64 %.state95, 1
  store i64 %166, ptr %.slot26, align 4
  br label %direct.schedule.3

direct.schedule.5:                                ; preds = %direct.false82
  %167 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %168 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %167, 0
  %170 = select <8 x i1> %49, <8 x ptr> %168, <8 x ptr> %169
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %167, 1
  %173 = select <8 x i1> %49, <8 x i64> %171, <8 x i64> %172
  %174 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %170, 0
  %175 = insertvalue { <8 x ptr>, <8 x i64> } %174, <8 x i64> %173, 1
  store { <8 x ptr>, <8 x i64> } %175, ptr %tile_snapshot.spill27, align 64
  store i64 0, ptr %.slot28, align 4
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.9, %direct.schedule.5
  %.state96 = load i64, ptr %.slot28, align 4
  %176 = icmp slt i64 %.state96, 128
  br i1 %176, label %direct.true97, label %direct.false98

direct.schedule.7:                                ; preds = %direct.true97
  %.state99 = load i64, ptr %.slot28, align 4
  %177 = srem i64 %.state99, 32
  %.state100 = load i64, ptr %.slot28, align 4
  %178 = sdiv i64 %.state100, 32
  %179 = add i64 0, %178
  %180 = mul i64 %179, 32
  %181 = add i64 %180, %177
  %tile_snapshot.spill.load101 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %182 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load101, 0
  %183 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load101, 1
  %.splatinsert102 = insertelement <8 x i64> poison, i64 %181, i64 0
  %.splat103 = shufflevector <8 x i64> %.splatinsert102, <8 x i64> poison, <8 x i32> zeroinitializer
  %184 = mul <8 x i64> %.splat103, splat (i64 32)
  %185 = add <8 x i64> %183, %184
  %186 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %182, 0
  %187 = insertvalue { <8 x ptr>, <8 x i64> } %186, <8 x i64> %185, 1
  %188 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %189 = extractvalue { <8 x ptr>, <8 x i64> } %187, 1
  %190 = extractelement <8 x ptr> %188, i32 0
  %191 = extractelement <8 x i64> %189, i32 0
  %192 = sub i64 %191, 0
  %193 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %194 = select i1 %193, i64 %192, i64 0
  %private.contiguous.address104 = getelementptr i8, ptr %190, i64 %194
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address104, align 4
  %195 = select <8 x i1> %49, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %196 = load <8 x float>, ptr %.spill29, align 32
  %197 = select <8 x i1> %49, <8 x float> %195, <8 x float> %196
  store <8 x float> %197, ptr %.spill29, align 32
  %198 = srem i64 %181, 32
  %199 = sdiv i64 %181, 32
  %200 = add i64 0, %198
  %201 = add i64 0, %200
  %202 = sub i64 %201, 1
  %203 = icmp sge i64 %202, 0
  %204 = icmp slt i64 %202, 32
  %205 = and i1 %203, %204
  store i1 %205, ptr %.spill30, align 1
  %206 = add i64 0, %199
  %207 = mul i64 %206, 32
  %208 = add i64 %207, %202
  store i64 %208, ptr %.spill31, align 4
  %209 = icmp sge i64 %208, 0
  %210 = icmp slt i64 %208, 128
  %211 = and i1 %209, %210
  br i1 %211, label %direct.true105, label %direct.false106

direct.schedule.8:                                ; preds = %direct.true105
  %tile_snapshot.spill.load107 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %212 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load107, 0
  %213 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load107, 1
  %.spill.load108 = load i64, ptr %.spill31, align 4
  %.splatinsert109 = insertelement <8 x i64> poison, i64 %.spill.load108, i64 0
  %.splat110 = shufflevector <8 x i64> %.splatinsert109, <8 x i64> poison, <8 x i32> zeroinitializer
  %214 = mul <8 x i64> %.splat110, splat (i64 32)
  %215 = add <8 x i64> %213, %214
  %216 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %212, 0
  %217 = insertvalue { <8 x ptr>, <8 x i64> } %216, <8 x i64> %215, 1
  %218 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %219 = extractvalue { <8 x ptr>, <8 x i64> } %217, 1
  %220 = extractelement <8 x ptr> %218, i32 0
  %221 = extractelement <8 x i64> %219, i32 0
  %222 = sub i64 %221, 0
  %223 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %224 = select i1 %223, i64 %222, i64 0
  %private.contiguous.address111 = getelementptr i8, ptr %220, i64 %224
  %private.contiguous.load112 = load <8 x float>, ptr %private.contiguous.address111, align 4
  %225 = select <8 x i1> %49, <8 x float> %private.contiguous.load112, <8 x float> zeroinitializer
  %226 = load <8 x float>, ptr %.slot32, align 32
  %227 = select <8 x i1> %49, <8 x float> %225, <8 x float> %226
  store <8 x float> %227, ptr %.slot32, align 32
  br label %direct.schedule.9

direct.schedule.9:                                ; preds = %direct.schedule.8, %direct.false106
  %.spill.load113 = load float, ptr %.spill19, align 4
  %.splatinsert114 = insertelement <8 x float> poison, float %.spill.load113, i64 0
  %.splat115 = shufflevector <8 x float> %.splatinsert114, <8 x float> poison, <8 x i32> zeroinitializer
  %.state116 = load <8 x float>, ptr %.slot32, align 32
  %.spill.load117 = load i1, ptr %.spill30, align 1
  %.splatinsert118 = insertelement <8 x i1> poison, i1 %.spill.load117, i64 0
  %.splat119 = shufflevector <8 x i1> %.splatinsert118, <8 x i1> poison, <8 x i32> zeroinitializer
  %228 = select <8 x i1> %.splat119, <8 x float> %.state116, <8 x float> %.splat115
  %.spill.load120 = load <8 x float>, ptr %.spill29, align 32
  %229 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.spill.load120, <8 x float> %228)
  %tile_snapshot.spill.load121 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %230 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load121, 0
  %231 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load121, 1
  %.state122 = load i64, ptr %.slot28, align 4
  %.splatinsert123 = insertelement <8 x i64> poison, i64 %.state122, i64 0
  %.splat124 = shufflevector <8 x i64> %.splatinsert123, <8 x i64> poison, <8 x i32> zeroinitializer
  %232 = mul <8 x i64> %.splat124, splat (i64 32)
  %233 = add <8 x i64> %231, %232
  %234 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %230, 0
  %235 = insertvalue { <8 x ptr>, <8 x i64> } %234, <8 x i64> %233, 1
  %236 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %237 = extractvalue { <8 x ptr>, <8 x i64> } %235, 1
  %238 = extractelement <8 x ptr> %236, i32 0
  %239 = extractelement <8 x i64> %237, i32 0
  %240 = sub i64 %239, 0
  %241 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %242 = select i1 %241, i64 %240, i64 0
  %private.contiguous.address125 = getelementptr i8, ptr %238, i64 %242
  %private.contiguous.preserve126 = load <8 x float>, ptr %private.contiguous.address125, align 4
  %243 = select <8 x i1> %49, <8 x float> %229, <8 x float> %private.contiguous.preserve126
  store <8 x float> %243, ptr %private.contiguous.address125, align 4
  %.state127 = load i64, ptr %.slot28, align 4
  %244 = add i64 %.state127, 1
  store i64 %244, ptr %.slot28, align 4
  br label %direct.schedule.6

direct.schedule.10:                               ; preds = %direct.false98
  %245 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill33, align 64
  %246 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %247 = extractvalue { <8 x ptr>, <8 x i64> } %245, 0
  %248 = select <8 x i1> %49, <8 x ptr> %246, <8 x ptr> %247
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %250 = extractvalue { <8 x ptr>, <8 x i64> } %245, 1
  %251 = select <8 x i1> %49, <8 x i64> %249, <8 x i64> %250
  %252 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %248, 0
  %253 = insertvalue { <8 x ptr>, <8 x i64> } %252, <8 x i64> %251, 1
  store { <8 x ptr>, <8 x i64> } %253, ptr %tile_snapshot.spill33, align 64
  store i64 0, ptr %.slot34, align 4
  br label %direct.schedule.11

direct.schedule.11:                               ; preds = %direct.schedule.14, %direct.schedule.10
  %.state128 = load i64, ptr %.slot34, align 4
  %254 = icmp slt i64 %.state128, 128
  br i1 %254, label %direct.true129, label %direct.false130

direct.schedule.12:                               ; preds = %direct.true129
  %.state131 = load i64, ptr %.slot34, align 4
  %255 = srem i64 %.state131, 32
  %.state132 = load i64, ptr %.slot34, align 4
  %256 = sdiv i64 %.state132, 32
  %257 = add i64 0, %256
  %258 = mul i64 %257, 32
  %259 = add i64 %258, %255
  %tile_snapshot.spill.load133 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %260 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load133, 0
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load133, 1
  %.splatinsert134 = insertelement <8 x i64> poison, i64 %259, i64 0
  %.splat135 = shufflevector <8 x i64> %.splatinsert134, <8 x i64> poison, <8 x i32> zeroinitializer
  %262 = mul <8 x i64> %.splat135, splat (i64 32)
  %263 = add <8 x i64> %261, %262
  %264 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %260, 0
  %265 = insertvalue { <8 x ptr>, <8 x i64> } %264, <8 x i64> %263, 1
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %265, 1
  %268 = extractelement <8 x ptr> %266, i32 0
  %269 = extractelement <8 x i64> %267, i32 0
  %270 = sub i64 %269, 0
  %271 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %272 = select i1 %271, i64 %270, i64 0
  %private.contiguous.address136 = getelementptr i8, ptr %268, i64 %272
  %private.contiguous.load137 = load <8 x float>, ptr %private.contiguous.address136, align 4
  %273 = select <8 x i1> %49, <8 x float> %private.contiguous.load137, <8 x float> zeroinitializer
  %274 = load <8 x float>, ptr %.spill35, align 32
  %275 = select <8 x i1> %49, <8 x float> %273, <8 x float> %274
  store <8 x float> %275, ptr %.spill35, align 32
  %276 = srem i64 %259, 32
  %277 = sdiv i64 %259, 32
  %278 = add i64 0, %276
  %279 = add i64 0, %278
  %280 = sub i64 %279, 2
  %281 = icmp sge i64 %280, 0
  %282 = icmp slt i64 %280, 32
  %283 = and i1 %281, %282
  store i1 %283, ptr %.spill36, align 1
  %284 = add i64 0, %277
  %285 = mul i64 %284, 32
  %286 = add i64 %285, %280
  store i64 %286, ptr %.spill37, align 4
  %287 = icmp sge i64 %286, 0
  %288 = icmp slt i64 %286, 128
  %289 = and i1 %287, %288
  br i1 %289, label %direct.true138, label %direct.false139

direct.schedule.13:                               ; preds = %direct.true138
  %tile_snapshot.spill.load140 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %290 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load140, 0
  %291 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load140, 1
  %.spill.load141 = load i64, ptr %.spill37, align 4
  %.splatinsert142 = insertelement <8 x i64> poison, i64 %.spill.load141, i64 0
  %.splat143 = shufflevector <8 x i64> %.splatinsert142, <8 x i64> poison, <8 x i32> zeroinitializer
  %292 = mul <8 x i64> %.splat143, splat (i64 32)
  %293 = add <8 x i64> %291, %292
  %294 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %290, 0
  %295 = insertvalue { <8 x ptr>, <8 x i64> } %294, <8 x i64> %293, 1
  %296 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %297 = extractvalue { <8 x ptr>, <8 x i64> } %295, 1
  %298 = extractelement <8 x ptr> %296, i32 0
  %299 = extractelement <8 x i64> %297, i32 0
  %300 = sub i64 %299, 0
  %301 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %302 = select i1 %301, i64 %300, i64 0
  %private.contiguous.address144 = getelementptr i8, ptr %298, i64 %302
  %private.contiguous.load145 = load <8 x float>, ptr %private.contiguous.address144, align 4
  %303 = select <8 x i1> %49, <8 x float> %private.contiguous.load145, <8 x float> zeroinitializer
  %304 = load <8 x float>, ptr %.slot38, align 32
  %305 = select <8 x i1> %49, <8 x float> %303, <8 x float> %304
  store <8 x float> %305, ptr %.slot38, align 32
  br label %direct.schedule.14

direct.schedule.14:                               ; preds = %direct.schedule.13, %direct.false139
  %.spill.load146 = load float, ptr %.spill19, align 4
  %.splatinsert147 = insertelement <8 x float> poison, float %.spill.load146, i64 0
  %.splat148 = shufflevector <8 x float> %.splatinsert147, <8 x float> poison, <8 x i32> zeroinitializer
  %.state149 = load <8 x float>, ptr %.slot38, align 32
  %.spill.load150 = load i1, ptr %.spill36, align 1
  %.splatinsert151 = insertelement <8 x i1> poison, i1 %.spill.load150, i64 0
  %.splat152 = shufflevector <8 x i1> %.splatinsert151, <8 x i1> poison, <8 x i32> zeroinitializer
  %306 = select <8 x i1> %.splat152, <8 x float> %.state149, <8 x float> %.splat148
  %.spill.load153 = load <8 x float>, ptr %.spill35, align 32
  %307 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.spill.load153, <8 x float> %306)
  %tile_snapshot.spill.load154 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill33, align 64
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load154, 0
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load154, 1
  %.state155 = load i64, ptr %.slot34, align 4
  %.splatinsert156 = insertelement <8 x i64> poison, i64 %.state155, i64 0
  %.splat157 = shufflevector <8 x i64> %.splatinsert156, <8 x i64> poison, <8 x i32> zeroinitializer
  %310 = mul <8 x i64> %.splat157, splat (i64 32)
  %311 = add <8 x i64> %309, %310
  %312 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %308, 0
  %313 = insertvalue { <8 x ptr>, <8 x i64> } %312, <8 x i64> %311, 1
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %313, 1
  %316 = extractelement <8 x ptr> %314, i32 0
  %317 = extractelement <8 x i64> %315, i32 0
  %318 = sub i64 %317, 0
  %319 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %320 = select i1 %319, i64 %318, i64 0
  %private.contiguous.address158 = getelementptr i8, ptr %316, i64 %320
  %private.contiguous.preserve159 = load <8 x float>, ptr %private.contiguous.address158, align 4
  %321 = select <8 x i1> %49, <8 x float> %307, <8 x float> %private.contiguous.preserve159
  store <8 x float> %321, ptr %private.contiguous.address158, align 4
  %.state160 = load i64, ptr %.slot34, align 4
  %322 = add i64 %.state160, 1
  store i64 %322, ptr %.slot34, align 4
  br label %direct.schedule.11

direct.schedule.15:                               ; preds = %direct.false130
  %323 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %323, 0
  %326 = select <8 x i1> %49, <8 x ptr> %324, <8 x ptr> %325
  %327 = extractvalue { <8 x ptr>, <8 x i64> } %9, 1
  %328 = extractvalue { <8 x ptr>, <8 x i64> } %323, 1
  %329 = select <8 x i1> %49, <8 x i64> %327, <8 x i64> %328
  %330 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %326, 0
  %331 = insertvalue { <8 x ptr>, <8 x i64> } %330, <8 x i64> %329, 1
  store { <8 x ptr>, <8 x i64> } %331, ptr %tile_snapshot.spill39, align 64
  store i64 0, ptr %.slot40, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.19, %direct.schedule.15
  %.state161 = load i64, ptr %.slot40, align 4
  %332 = icmp slt i64 %.state161, 128
  br i1 %332, label %direct.true162, label %direct.false163

direct.schedule.17:                               ; preds = %direct.true162
  %.state164 = load i64, ptr %.slot40, align 4
  %333 = srem i64 %.state164, 32
  %.state165 = load i64, ptr %.slot40, align 4
  %334 = sdiv i64 %.state165, 32
  %335 = add i64 0, %334
  %336 = mul i64 %335, 32
  %337 = add i64 %336, %333
  %tile_snapshot.spill.load166 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill33, align 64
  %338 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load166, 0
  %339 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load166, 1
  %.splatinsert167 = insertelement <8 x i64> poison, i64 %337, i64 0
  %.splat168 = shufflevector <8 x i64> %.splatinsert167, <8 x i64> poison, <8 x i32> zeroinitializer
  %340 = mul <8 x i64> %.splat168, splat (i64 32)
  %341 = add <8 x i64> %339, %340
  %342 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %338, 0
  %343 = insertvalue { <8 x ptr>, <8 x i64> } %342, <8 x i64> %341, 1
  %344 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %345 = extractvalue { <8 x ptr>, <8 x i64> } %343, 1
  %346 = extractelement <8 x ptr> %344, i32 0
  %347 = extractelement <8 x i64> %345, i32 0
  %348 = sub i64 %347, 0
  %349 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %350 = select i1 %349, i64 %348, i64 0
  %private.contiguous.address169 = getelementptr i8, ptr %346, i64 %350
  %private.contiguous.load170 = load <8 x float>, ptr %private.contiguous.address169, align 4
  %351 = select <8 x i1> %49, <8 x float> %private.contiguous.load170, <8 x float> zeroinitializer
  %352 = load <8 x float>, ptr %.spill41, align 32
  %353 = select <8 x i1> %49, <8 x float> %351, <8 x float> %352
  store <8 x float> %353, ptr %.spill41, align 32
  %354 = srem i64 %337, 32
  %355 = sdiv i64 %337, 32
  %356 = add i64 0, %354
  %357 = add i64 0, %356
  %358 = sub i64 %357, 4
  %359 = icmp sge i64 %358, 0
  %360 = icmp slt i64 %358, 32
  %361 = and i1 %359, %360
  store i1 %361, ptr %.spill42, align 1
  %362 = add i64 0, %355
  %363 = mul i64 %362, 32
  %364 = add i64 %363, %358
  store i64 %364, ptr %.spill43, align 4
  %365 = icmp sge i64 %364, 0
  %366 = icmp slt i64 %364, 128
  %367 = and i1 %365, %366
  br i1 %367, label %direct.true171, label %direct.false172

direct.schedule.18:                               ; preds = %direct.true171
  %tile_snapshot.spill.load173 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill33, align 64
  %368 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load173, 0
  %369 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load173, 1
  %.spill.load174 = load i64, ptr %.spill43, align 4
  %.splatinsert175 = insertelement <8 x i64> poison, i64 %.spill.load174, i64 0
  %.splat176 = shufflevector <8 x i64> %.splatinsert175, <8 x i64> poison, <8 x i32> zeroinitializer
  %370 = mul <8 x i64> %.splat176, splat (i64 32)
  %371 = add <8 x i64> %369, %370
  %372 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %368, 0
  %373 = insertvalue { <8 x ptr>, <8 x i64> } %372, <8 x i64> %371, 1
  %374 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %375 = extractvalue { <8 x ptr>, <8 x i64> } %373, 1
  %376 = extractelement <8 x ptr> %374, i32 0
  %377 = extractelement <8 x i64> %375, i32 0
  %378 = sub i64 %377, 0
  %379 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %380 = select i1 %379, i64 %378, i64 0
  %private.contiguous.address177 = getelementptr i8, ptr %376, i64 %380
  %private.contiguous.load178 = load <8 x float>, ptr %private.contiguous.address177, align 4
  %381 = select <8 x i1> %49, <8 x float> %private.contiguous.load178, <8 x float> zeroinitializer
  %382 = load <8 x float>, ptr %.slot44, align 32
  %383 = select <8 x i1> %49, <8 x float> %381, <8 x float> %382
  store <8 x float> %383, ptr %.slot44, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.18, %direct.false172
  %.spill.load179 = load float, ptr %.spill19, align 4
  %.splatinsert180 = insertelement <8 x float> poison, float %.spill.load179, i64 0
  %.splat181 = shufflevector <8 x float> %.splatinsert180, <8 x float> poison, <8 x i32> zeroinitializer
  %.state182 = load <8 x float>, ptr %.slot44, align 32
  %.spill.load183 = load i1, ptr %.spill42, align 1
  %.splatinsert184 = insertelement <8 x i1> poison, i1 %.spill.load183, i64 0
  %.splat185 = shufflevector <8 x i1> %.splatinsert184, <8 x i1> poison, <8 x i32> zeroinitializer
  %384 = select <8 x i1> %.splat185, <8 x float> %.state182, <8 x float> %.splat181
  %.spill.load186 = load <8 x float>, ptr %.spill41, align 32
  %385 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.spill.load186, <8 x float> %384)
  %tile_snapshot.spill.load187 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %386 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load187, 0
  %387 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load187, 1
  %.state188 = load i64, ptr %.slot40, align 4
  %.splatinsert189 = insertelement <8 x i64> poison, i64 %.state188, i64 0
  %.splat190 = shufflevector <8 x i64> %.splatinsert189, <8 x i64> poison, <8 x i32> zeroinitializer
  %388 = mul <8 x i64> %.splat190, splat (i64 32)
  %389 = add <8 x i64> %387, %388
  %390 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %386, 0
  %391 = insertvalue { <8 x ptr>, <8 x i64> } %390, <8 x i64> %389, 1
  %392 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %393 = extractvalue { <8 x ptr>, <8 x i64> } %391, 1
  %394 = extractelement <8 x ptr> %392, i32 0
  %395 = extractelement <8 x i64> %393, i32 0
  %396 = sub i64 %395, 0
  %397 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %398 = select i1 %397, i64 %396, i64 0
  %private.contiguous.address191 = getelementptr i8, ptr %394, i64 %398
  %private.contiguous.preserve192 = load <8 x float>, ptr %private.contiguous.address191, align 4
  %399 = select <8 x i1> %49, <8 x float> %385, <8 x float> %private.contiguous.preserve192
  store <8 x float> %399, ptr %private.contiguous.address191, align 4
  %.state193 = load i64, ptr %.slot40, align 4
  %400 = add i64 %.state193, 1
  store i64 %400, ptr %.slot40, align 4
  br label %direct.schedule.16

direct.schedule.20:                               ; preds = %direct.false163
  %401 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill45, align 64
  %402 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %403 = extractvalue { <8 x ptr>, <8 x i64> } %401, 0
  %404 = select <8 x i1> %49, <8 x ptr> %402, <8 x ptr> %403
  %405 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %406 = extractvalue { <8 x ptr>, <8 x i64> } %401, 1
  %407 = select <8 x i1> %49, <8 x i64> %405, <8 x i64> %406
  %408 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %404, 0
  %409 = insertvalue { <8 x ptr>, <8 x i64> } %408, <8 x i64> %407, 1
  store { <8 x ptr>, <8 x i64> } %409, ptr %tile_snapshot.spill45, align 64
  store i64 0, ptr %.slot46, align 4
  br label %direct.schedule.21

direct.schedule.21:                               ; preds = %direct.schedule.24, %direct.schedule.20
  %.state194 = load i64, ptr %.slot46, align 4
  %410 = icmp slt i64 %.state194, 128
  br i1 %410, label %direct.true195, label %direct.false196

direct.schedule.22:                               ; preds = %direct.true195
  %.state197 = load i64, ptr %.slot46, align 4
  %411 = srem i64 %.state197, 32
  %.state198 = load i64, ptr %.slot46, align 4
  %412 = sdiv i64 %.state198, 32
  %413 = add i64 0, %412
  %414 = mul i64 %413, 32
  %415 = add i64 %414, %411
  %tile_snapshot.spill.load199 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %416 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load199, 0
  %417 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load199, 1
  %.splatinsert200 = insertelement <8 x i64> poison, i64 %415, i64 0
  %.splat201 = shufflevector <8 x i64> %.splatinsert200, <8 x i64> poison, <8 x i32> zeroinitializer
  %418 = mul <8 x i64> %.splat201, splat (i64 32)
  %419 = add <8 x i64> %417, %418
  %420 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %416, 0
  %421 = insertvalue { <8 x ptr>, <8 x i64> } %420, <8 x i64> %419, 1
  %422 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %423 = extractvalue { <8 x ptr>, <8 x i64> } %421, 1
  %424 = extractelement <8 x ptr> %422, i32 0
  %425 = extractelement <8 x i64> %423, i32 0
  %426 = sub i64 %425, 0
  %427 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %428 = select i1 %427, i64 %426, i64 0
  %private.contiguous.address202 = getelementptr i8, ptr %424, i64 %428
  %private.contiguous.load203 = load <8 x float>, ptr %private.contiguous.address202, align 4
  %429 = select <8 x i1> %49, <8 x float> %private.contiguous.load203, <8 x float> zeroinitializer
  %430 = load <8 x float>, ptr %.spill47, align 32
  %431 = select <8 x i1> %49, <8 x float> %429, <8 x float> %430
  store <8 x float> %431, ptr %.spill47, align 32
  %432 = srem i64 %415, 32
  %433 = sdiv i64 %415, 32
  %434 = add i64 0, %432
  %435 = add i64 0, %434
  %436 = sub i64 %435, 8
  %437 = icmp sge i64 %436, 0
  %438 = icmp slt i64 %436, 32
  %439 = and i1 %437, %438
  store i1 %439, ptr %.spill48, align 1
  %440 = add i64 0, %433
  %441 = mul i64 %440, 32
  %442 = add i64 %441, %436
  store i64 %442, ptr %.spill49, align 4
  %443 = icmp sge i64 %442, 0
  %444 = icmp slt i64 %442, 128
  %445 = and i1 %443, %444
  br i1 %445, label %direct.true204, label %direct.false205

direct.schedule.23:                               ; preds = %direct.true204
  %tile_snapshot.spill.load206 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %446 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load206, 0
  %447 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load206, 1
  %.spill.load207 = load i64, ptr %.spill49, align 4
  %.splatinsert208 = insertelement <8 x i64> poison, i64 %.spill.load207, i64 0
  %.splat209 = shufflevector <8 x i64> %.splatinsert208, <8 x i64> poison, <8 x i32> zeroinitializer
  %448 = mul <8 x i64> %.splat209, splat (i64 32)
  %449 = add <8 x i64> %447, %448
  %450 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %446, 0
  %451 = insertvalue { <8 x ptr>, <8 x i64> } %450, <8 x i64> %449, 1
  %452 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %453 = extractvalue { <8 x ptr>, <8 x i64> } %451, 1
  %454 = extractelement <8 x ptr> %452, i32 0
  %455 = extractelement <8 x i64> %453, i32 0
  %456 = sub i64 %455, 0
  %457 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %458 = select i1 %457, i64 %456, i64 0
  %private.contiguous.address210 = getelementptr i8, ptr %454, i64 %458
  %private.contiguous.load211 = load <8 x float>, ptr %private.contiguous.address210, align 4
  %459 = select <8 x i1> %49, <8 x float> %private.contiguous.load211, <8 x float> zeroinitializer
  %460 = load <8 x float>, ptr %.slot50, align 32
  %461 = select <8 x i1> %49, <8 x float> %459, <8 x float> %460
  store <8 x float> %461, ptr %.slot50, align 32
  br label %direct.schedule.24

direct.schedule.24:                               ; preds = %direct.schedule.23, %direct.false205
  %.spill.load212 = load float, ptr %.spill19, align 4
  %.splatinsert213 = insertelement <8 x float> poison, float %.spill.load212, i64 0
  %.splat214 = shufflevector <8 x float> %.splatinsert213, <8 x float> poison, <8 x i32> zeroinitializer
  %.state215 = load <8 x float>, ptr %.slot50, align 32
  %.spill.load216 = load i1, ptr %.spill48, align 1
  %.splatinsert217 = insertelement <8 x i1> poison, i1 %.spill.load216, i64 0
  %.splat218 = shufflevector <8 x i1> %.splatinsert217, <8 x i1> poison, <8 x i32> zeroinitializer
  %462 = select <8 x i1> %.splat218, <8 x float> %.state215, <8 x float> %.splat214
  %.spill.load219 = load <8 x float>, ptr %.spill47, align 32
  %463 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.spill.load219, <8 x float> %462)
  %tile_snapshot.spill.load220 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill45, align 64
  %464 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load220, 0
  %465 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load220, 1
  %.state221 = load i64, ptr %.slot46, align 4
  %.splatinsert222 = insertelement <8 x i64> poison, i64 %.state221, i64 0
  %.splat223 = shufflevector <8 x i64> %.splatinsert222, <8 x i64> poison, <8 x i32> zeroinitializer
  %466 = mul <8 x i64> %.splat223, splat (i64 32)
  %467 = add <8 x i64> %465, %466
  %468 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %464, 0
  %469 = insertvalue { <8 x ptr>, <8 x i64> } %468, <8 x i64> %467, 1
  %470 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %471 = extractvalue { <8 x ptr>, <8 x i64> } %469, 1
  %472 = extractelement <8 x ptr> %470, i32 0
  %473 = extractelement <8 x i64> %471, i32 0
  %474 = sub i64 %473, 0
  %475 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %476 = select i1 %475, i64 %474, i64 0
  %private.contiguous.address224 = getelementptr i8, ptr %472, i64 %476
  %private.contiguous.preserve225 = load <8 x float>, ptr %private.contiguous.address224, align 4
  %477 = select <8 x i1> %49, <8 x float> %463, <8 x float> %private.contiguous.preserve225
  store <8 x float> %477, ptr %private.contiguous.address224, align 4
  %.state226 = load i64, ptr %.slot46, align 4
  %478 = add i64 %.state226, 1
  store i64 %478, ptr %.slot46, align 4
  br label %direct.schedule.21

direct.schedule.25:                               ; preds = %direct.false196
  %479 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill51, align 64
  %480 = extractvalue { <8 x ptr>, <8 x i64> } %13, 0
  %481 = extractvalue { <8 x ptr>, <8 x i64> } %479, 0
  %482 = select <8 x i1> %49, <8 x ptr> %480, <8 x ptr> %481
  %483 = extractvalue { <8 x ptr>, <8 x i64> } %13, 1
  %484 = extractvalue { <8 x ptr>, <8 x i64> } %479, 1
  %485 = select <8 x i1> %49, <8 x i64> %483, <8 x i64> %484
  %486 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %482, 0
  %487 = insertvalue { <8 x ptr>, <8 x i64> } %486, <8 x i64> %485, 1
  store { <8 x ptr>, <8 x i64> } %487, ptr %tile_snapshot.spill51, align 64
  store i64 0, ptr %.slot52, align 4
  br label %direct.schedule.26

direct.schedule.26:                               ; preds = %direct.schedule.29, %direct.schedule.25
  %.state227 = load i64, ptr %.slot52, align 4
  %488 = icmp slt i64 %.state227, 128
  br i1 %488, label %direct.true228, label %direct.false229

direct.schedule.27:                               ; preds = %direct.true228
  %.state230 = load i64, ptr %.slot52, align 4
  %489 = srem i64 %.state230, 32
  %.state231 = load i64, ptr %.slot52, align 4
  %490 = sdiv i64 %.state231, 32
  %491 = add i64 0, %490
  store i64 %491, ptr %.spill53, align 4
  %492 = mul i64 %491, 32
  %493 = add i64 %492, %489
  %494 = srem i64 %493, 32
  %495 = sdiv i64 %493, 32
  %496 = add i64 0, %495
  %497 = mul i64 %496, 32
  %498 = add i64 %497, %494
  %tile_snapshot.spill.load232 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill45, align 64
  %499 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load232, 0
  %500 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load232, 1
  %.splatinsert233 = insertelement <8 x i64> poison, i64 %498, i64 0
  %.splat234 = shufflevector <8 x i64> %.splatinsert233, <8 x i64> poison, <8 x i32> zeroinitializer
  %501 = mul <8 x i64> %.splat234, splat (i64 32)
  %502 = add <8 x i64> %500, %501
  %503 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %499, 0
  %504 = insertvalue { <8 x ptr>, <8 x i64> } %503, <8 x i64> %502, 1
  %505 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %506 = extractvalue { <8 x ptr>, <8 x i64> } %504, 1
  %507 = extractelement <8 x ptr> %505, i32 0
  %508 = extractelement <8 x i64> %506, i32 0
  %509 = sub i64 %508, 0
  %510 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %511 = select i1 %510, i64 %509, i64 0
  %private.contiguous.address235 = getelementptr i8, ptr %507, i64 %511
  %private.contiguous.load236 = load <8 x float>, ptr %private.contiguous.address235, align 4
  %512 = select <8 x i1> %49, <8 x float> %private.contiguous.load236, <8 x float> zeroinitializer
  %513 = load <8 x float>, ptr %.spill54, align 32
  %514 = select <8 x i1> %49, <8 x float> %512, <8 x float> %513
  store <8 x float> %514, ptr %.spill54, align 32
  %515 = srem i64 %498, 32
  %516 = sdiv i64 %498, 32
  %517 = add i64 0, %515
  %518 = add i64 0, %517
  %519 = sub i64 %518, 16
  %520 = icmp sge i64 %519, 0
  %521 = icmp slt i64 %519, 32
  %522 = and i1 %520, %521
  store i1 %522, ptr %.spill55, align 1
  %523 = add i64 0, %516
  %524 = mul i64 %523, 32
  %525 = add i64 %524, %519
  store i64 %525, ptr %.spill56, align 4
  %526 = icmp sge i64 %525, 0
  %527 = icmp slt i64 %525, 128
  %528 = and i1 %526, %527
  br i1 %528, label %direct.true237, label %direct.false238

direct.schedule.28:                               ; preds = %direct.true237
  %tile_snapshot.spill.load239 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill45, align 64
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load239, 0
  %530 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load239, 1
  %.spill.load240 = load i64, ptr %.spill56, align 4
  %.splatinsert241 = insertelement <8 x i64> poison, i64 %.spill.load240, i64 0
  %.splat242 = shufflevector <8 x i64> %.splatinsert241, <8 x i64> poison, <8 x i32> zeroinitializer
  %531 = mul <8 x i64> %.splat242, splat (i64 32)
  %532 = add <8 x i64> %530, %531
  %533 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %529, 0
  %534 = insertvalue { <8 x ptr>, <8 x i64> } %533, <8 x i64> %532, 1
  %535 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %536 = extractvalue { <8 x ptr>, <8 x i64> } %534, 1
  %537 = extractelement <8 x ptr> %535, i32 0
  %538 = extractelement <8 x i64> %536, i32 0
  %539 = sub i64 %538, 0
  %540 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %541 = select i1 %540, i64 %539, i64 0
  %private.contiguous.address243 = getelementptr i8, ptr %537, i64 %541
  %private.contiguous.load244 = load <8 x float>, ptr %private.contiguous.address243, align 4
  %542 = select <8 x i1> %49, <8 x float> %private.contiguous.load244, <8 x float> zeroinitializer
  %543 = load <8 x float>, ptr %.slot57, align 32
  %544 = select <8 x i1> %49, <8 x float> %542, <8 x float> %543
  store <8 x float> %544, ptr %.slot57, align 32
  br label %direct.schedule.29

direct.schedule.29:                               ; preds = %direct.schedule.28, %direct.false238
  %.spill.load245 = load float, ptr %.spill19, align 4
  %.splatinsert246 = insertelement <8 x float> poison, float %.spill.load245, i64 0
  %.splat247 = shufflevector <8 x float> %.splatinsert246, <8 x float> poison, <8 x i32> zeroinitializer
  %.state248 = load <8 x float>, ptr %.slot57, align 32
  %.spill.load249 = load i1, ptr %.spill55, align 1
  %.splatinsert250 = insertelement <8 x i1> poison, i1 %.spill.load249, i64 0
  %.splat251 = shufflevector <8 x i1> %.splatinsert250, <8 x i1> poison, <8 x i32> zeroinitializer
  %545 = select <8 x i1> %.splat251, <8 x float> %.state248, <8 x float> %.splat247
  %.spill.load252 = load <8 x float>, ptr %.spill54, align 32
  %546 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.spill.load252, <8 x float> %545)
  %tile_snapshot.spill.load253 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %547 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load253, 0
  %548 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load253, 1
  %.spill.load254 = load i64, ptr %.spill53, align 4
  %.splatinsert255 = insertelement <8 x i64> poison, i64 %.spill.load254, i64 0
  %.splat256 = shufflevector <8 x i64> %.splatinsert255, <8 x i64> poison, <8 x i32> zeroinitializer
  %549 = mul <8 x i64> %.splat256, splat (i64 32)
  %550 = add <8 x i64> %548, %549
  %551 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %547, 0
  %552 = insertvalue { <8 x ptr>, <8 x i64> } %551, <8 x i64> %550, 1
  %553 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %554 = extractvalue { <8 x ptr>, <8 x i64> } %552, 1
  %555 = extractelement <8 x ptr> %553, i32 0
  %556 = extractelement <8 x i64> %554, i32 0
  %557 = sub i64 %556, 0
  %558 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %559 = select i1 %558, i64 %557, i64 0
  %private.contiguous.address257 = getelementptr i8, ptr %555, i64 %559
  %private.contiguous.load258 = load <8 x float>, ptr %private.contiguous.address257, align 4
  %560 = select <8 x i1> %49, <8 x float> %private.contiguous.load258, <8 x float> zeroinitializer
  %561 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %546, <8 x float> %560)
  %tile_snapshot.spill.load259 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill51, align 64
  %562 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load259, 0
  %563 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load259, 1
  %.state260 = load i64, ptr %.slot52, align 4
  %.splatinsert261 = insertelement <8 x i64> poison, i64 %.state260, i64 0
  %.splat262 = shufflevector <8 x i64> %.splatinsert261, <8 x i64> poison, <8 x i32> zeroinitializer
  %564 = mul <8 x i64> %.splat262, splat (i64 32)
  %565 = add <8 x i64> %563, %564
  %566 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %562, 0
  %567 = insertvalue { <8 x ptr>, <8 x i64> } %566, <8 x i64> %565, 1
  %568 = extractvalue { <8 x ptr>, <8 x i64> } %13, 0
  %569 = extractvalue { <8 x ptr>, <8 x i64> } %567, 1
  %570 = extractelement <8 x ptr> %568, i32 0
  %571 = extractelement <8 x i64> %569, i32 0
  %572 = sub i64 %571, 0
  %573 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %574 = select i1 %573, i64 %572, i64 0
  %private.contiguous.address263 = getelementptr i8, ptr %570, i64 %574
  %private.contiguous.preserve264 = load <8 x float>, ptr %private.contiguous.address263, align 4
  %575 = select <8 x i1> %49, <8 x float> %561, <8 x float> %private.contiguous.preserve264
  store <8 x float> %575, ptr %private.contiguous.address263, align 4
  %.state265 = load i64, ptr %.slot52, align 4
  %576 = add i64 %.state265, 1
  store i64 %576, ptr %.slot52, align 4
  br label %direct.schedule.26

direct.schedule.30:                               ; preds = %direct.false229
  store i64 0, ptr %.slot58, align 4
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.32, %direct.schedule.30
  %.state266 = load i64, ptr %.slot58, align 4
  %577 = icmp slt i64 %.state266, 128
  br i1 %577, label %direct.true267, label %direct.false268

direct.schedule.32:                               ; preds = %direct.true267
  %.state269 = load i64, ptr %.slot58, align 4
  %578 = srem i64 %.state269, 32
  %.state270 = load i64, ptr %.slot58, align 4
  %579 = sdiv i64 %.state270, 32
  %.spill.load271 = load <8 x i64>, ptr %.spill, align 64
  %.splatinsert272 = insertelement <8 x i64> poison, i64 %579, i64 0
  %.splat273 = shufflevector <8 x i64> %.splatinsert272, <8 x i64> poison, <8 x i32> zeroinitializer
  %580 = add <8 x i64> %.spill.load271, %.splat273
  %581 = add <8 x i64> zeroinitializer, %580
  %.spill.load274 = load i64, ptr %.spill24, align 4
  %582 = add i64 %.spill.load274, %578
  %583 = mul <8 x i64> %581, splat (i64 1024)
  %.splatinsert275 = insertelement <8 x i64> poison, i64 %582, i64 0
  %.splat276 = shufflevector <8 x i64> %.splatinsert275, <8 x i64> poison, <8 x i32> zeroinitializer
  %584 = add <8 x i64> %583, %.splat276
  %tile_snapshot.spill.load277 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill51, align 64
  %585 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load277, 0
  %586 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load277, 1
  %.state278 = load i64, ptr %.slot58, align 4
  %.splatinsert279 = insertelement <8 x i64> poison, i64 %.state278, i64 0
  %.splat280 = shufflevector <8 x i64> %.splatinsert279, <8 x i64> poison, <8 x i32> zeroinitializer
  %587 = mul <8 x i64> %.splat280, splat (i64 32)
  %588 = add <8 x i64> %586, %587
  %589 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %585, 0
  %590 = insertvalue { <8 x ptr>, <8 x i64> } %589, <8 x i64> %588, 1
  %591 = extractvalue { <8 x ptr>, <8 x i64> } %13, 0
  %592 = extractvalue { <8 x ptr>, <8 x i64> } %590, 1
  %593 = extractelement <8 x ptr> %591, i32 0
  %594 = extractelement <8 x i64> %592, i32 0
  %595 = sub i64 %594, 0
  %596 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %597 = select i1 %596, i64 %595, i64 0
  %private.contiguous.address281 = getelementptr i8, ptr %593, i64 %597
  %private.contiguous.load282 = load <8 x float>, ptr %private.contiguous.address281, align 4
  %598 = select <8 x i1> %49, <8 x float> %private.contiguous.load282, <8 x float> zeroinitializer
  %599 = extractvalue { ptr, i64 } %25, 0
  %600 = mul <8 x i64> %584, splat (i64 4)
  %601 = getelementptr i8, ptr %599, <8 x i64> %600
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %598, <8 x ptr> %601, i32 1, <8 x i1> %49)
  %.state283 = load i64, ptr %.slot58, align 4
  %602 = add i64 %.state283, 1
  store i64 %602, ptr %.slot58, align 4
  br label %direct.schedule.31

direct.schedule.33:                               ; preds = %direct.false268
  %tile_snapshot.spill.load284 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill51, align 64
  %603 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load284, 0
  %604 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load284, 1
  %605 = add <8 x i64> %604, splat (i64 992)
  %606 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %603, 0
  %607 = insertvalue { <8 x ptr>, <8 x i64> } %606, <8 x i64> %605, 1
  %608 = extractvalue { <8 x ptr>, <8 x i64> } %13, 0
  %609 = extractvalue { <8 x ptr>, <8 x i64> } %607, 1
  %610 = extractelement <8 x ptr> %608, i32 0
  %611 = extractelement <8 x i64> %609, i32 0
  %612 = sub i64 %611, 0
  %613 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %614 = select i1 %613, i64 %612, i64 0
  %private.contiguous.address285 = getelementptr i8, ptr %610, i64 %614
  %private.contiguous.load286 = load <8 x float>, ptr %private.contiguous.address285, align 4
  %615 = select <8 x i1> %49, <8 x float> %private.contiguous.load286, <8 x float> zeroinitializer
  %tile_snapshot.spill.load287 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill51, align 64
  %616 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load287, 0
  %617 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load287, 1
  %618 = add <8 x i64> %617, splat (i64 2016)
  %619 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %616, 0
  %620 = insertvalue { <8 x ptr>, <8 x i64> } %619, <8 x i64> %618, 1
  %621 = extractvalue { <8 x ptr>, <8 x i64> } %13, 0
  %622 = extractvalue { <8 x ptr>, <8 x i64> } %620, 1
  %623 = extractelement <8 x ptr> %621, i32 0
  %624 = extractelement <8 x i64> %622, i32 0
  %625 = sub i64 %624, 0
  %626 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %627 = select i1 %626, i64 %625, i64 0
  %private.contiguous.address288 = getelementptr i8, ptr %623, i64 %627
  %private.contiguous.load289 = load <8 x float>, ptr %private.contiguous.address288, align 4
  %628 = select <8 x i1> %49, <8 x float> %private.contiguous.load289, <8 x float> zeroinitializer
  %tile_snapshot.spill.load290 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill51, align 64
  %629 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load290, 0
  %630 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load290, 1
  %631 = add <8 x i64> %630, splat (i64 3040)
  %632 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %629, 0
  %633 = insertvalue { <8 x ptr>, <8 x i64> } %632, <8 x i64> %631, 1
  %634 = extractvalue { <8 x ptr>, <8 x i64> } %13, 0
  %635 = extractvalue { <8 x ptr>, <8 x i64> } %633, 1
  %636 = extractelement <8 x ptr> %634, i32 0
  %637 = extractelement <8 x i64> %635, i32 0
  %638 = sub i64 %637, 0
  %639 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %640 = select i1 %639, i64 %638, i64 0
  %private.contiguous.address291 = getelementptr i8, ptr %636, i64 %640
  %private.contiguous.load292 = load <8 x float>, ptr %private.contiguous.address291, align 4
  %641 = select <8 x i1> %49, <8 x float> %private.contiguous.load292, <8 x float> zeroinitializer
  %tile_snapshot.spill.load293 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill51, align 64
  %642 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load293, 0
  %643 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load293, 1
  %644 = add <8 x i64> %643, splat (i64 4064)
  %645 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %642, 0
  %646 = insertvalue { <8 x ptr>, <8 x i64> } %645, <8 x i64> %644, 1
  %647 = extractvalue { <8 x ptr>, <8 x i64> } %13, 0
  %648 = extractvalue { <8 x ptr>, <8 x i64> } %646, 1
  %649 = extractelement <8 x ptr> %647, i32 0
  %650 = extractelement <8 x i64> %648, i32 0
  %651 = sub i64 %650, 0
  %652 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %653 = select i1 %652, i64 %651, i64 0
  %private.contiguous.address294 = getelementptr i8, ptr %649, i64 %653
  %private.contiguous.load295 = load <8 x float>, ptr %private.contiguous.address294, align 4
  %654 = select <8 x i1> %49, <8 x float> %private.contiguous.load295, <8 x float> zeroinitializer
  %.state296 = load i64, ptr %.slot, align 4
  %655 = add i64 %.state296, 1
  store i64 %655, ptr %.slot, align 4
  %656 = load <8 x float>, ptr %.slot20, align 32
  %657 = select <8 x i1> %49, <8 x float> %615, <8 x float> %656
  store <8 x float> %657, ptr %.slot20, align 32
  %658 = load <8 x float>, ptr %.slot21, align 32
  %659 = select <8 x i1> %49, <8 x float> %628, <8 x float> %658
  store <8 x float> %659, ptr %.slot21, align 32
  %660 = load <8 x float>, ptr %.slot22, align 32
  %661 = select <8 x i1> %49, <8 x float> %641, <8 x float> %660
  store <8 x float> %661, ptr %.slot22, align 32
  %662 = load <8 x float>, ptr %.slot23, align 32
  %663 = select <8 x i1> %49, <8 x float> %654, <8 x float> %662
  store <8 x float> %663, ptr %.slot23, align 32
  br label %direct.schedule.1

direct.schedule.34:                               ; preds = %direct.false
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.34

direct.true81:                                    ; preds = %direct.schedule.3
  br label %direct.schedule.4

direct.false82:                                   ; preds = %direct.schedule.3
  br label %direct.schedule.5

direct.true97:                                    ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false98:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.10

direct.true105:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false106:                                  ; preds = %direct.schedule.7
  %664 = load <8 x float>, ptr %.slot32, align 32
  %665 = select <8 x i1> %49, <8 x float> zeroinitializer, <8 x float> %664
  store <8 x float> %665, ptr %.slot32, align 32
  br label %direct.schedule.9

direct.true129:                                   ; preds = %direct.schedule.11
  br label %direct.schedule.12

direct.false130:                                  ; preds = %direct.schedule.11
  br label %direct.schedule.15

direct.true138:                                   ; preds = %direct.schedule.12
  br label %direct.schedule.13

direct.false139:                                  ; preds = %direct.schedule.12
  %666 = load <8 x float>, ptr %.slot38, align 32
  %667 = select <8 x i1> %49, <8 x float> zeroinitializer, <8 x float> %666
  store <8 x float> %667, ptr %.slot38, align 32
  br label %direct.schedule.14

direct.true162:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false163:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.20

direct.true171:                                   ; preds = %direct.schedule.17
  br label %direct.schedule.18

direct.false172:                                  ; preds = %direct.schedule.17
  %668 = load <8 x float>, ptr %.slot44, align 32
  %669 = select <8 x i1> %49, <8 x float> zeroinitializer, <8 x float> %668
  store <8 x float> %669, ptr %.slot44, align 32
  br label %direct.schedule.19

direct.true195:                                   ; preds = %direct.schedule.21
  br label %direct.schedule.22

direct.false196:                                  ; preds = %direct.schedule.21
  br label %direct.schedule.25

direct.true204:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false205:                                  ; preds = %direct.schedule.22
  %670 = load <8 x float>, ptr %.slot50, align 32
  %671 = select <8 x i1> %49, <8 x float> zeroinitializer, <8 x float> %670
  store <8 x float> %671, ptr %.slot50, align 32
  br label %direct.schedule.24

direct.true228:                                   ; preds = %direct.schedule.26
  br label %direct.schedule.27

direct.false229:                                  ; preds = %direct.schedule.26
  br label %direct.schedule.30

direct.true237:                                   ; preds = %direct.schedule.27
  br label %direct.schedule.28

direct.false238:                                  ; preds = %direct.schedule.27
  %672 = load <8 x float>, ptr %.slot57, align 32
  %673 = select <8 x i1> %49, <8 x float> zeroinitializer, <8 x float> %672
  store <8 x float> %673, ptr %.slot57, align 32
  br label %direct.schedule.29

direct.true267:                                   ; preds = %direct.schedule.31
  br label %direct.schedule.32

direct.false268:                                  ; preds = %direct.schedule.31
  br label %direct.schedule.33
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #2

define internal void @tile_inclusive_scan.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @tile_inclusive_scan.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }

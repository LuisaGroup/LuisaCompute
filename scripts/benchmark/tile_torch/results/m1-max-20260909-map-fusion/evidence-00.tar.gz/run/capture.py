import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path(__file__).parent
build = Path('/tmp/luisa-next-integration.roZbN8/build')
source = build.parent / 'source'
files = [
    'include/luisa/tile/bridge/xir/lower.h', 'include/luisa/tile/bridge/xir/planner.h',
    'src/tile/bridge/xir/lower.cpp', 'src/tile/bridge/xir/representation.h',
    'src/tile/bridge/xir/planner.cpp', 'src/backends/simd/runtime/simd_tile.cpp',
    'src/tests/unit/tile/bridge/test_xir.cpp', 'src/tests/unit/tile/bridge/test_xir_runtime.cpp',
    'src/tests/benchmark/benchmark_tile_migrated.cpp', 'examples/compute/tile/kernels.h',
    'src/tests/common/tile_migrated_test_utils.h',
]

def digest(path):
    return hashlib.file_digest(open(path, 'rb'), 'sha256').hexdigest()

def binaries():
    return {str(p): digest(p) for p in sorted((build / 'bin').glob('libluisa*.dylib'))} | {
        str(build / 'bin/benchmark_tile_migrated'): digest(build / 'bin/benchmark_tile_migrated')}

out = root / 'captures'
out.mkdir(exist_ok=False)
manifest = {'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'source_sha256': {f: digest(source / f) for f in files},
            'binary_sha256_before': binaries(), 'cases': []}
cases = [('cumsum', 8, 32), ('cumsum', 128, 1024), ('cummax', 128, 1024),
         ('cumsum', 17, 65), ('cumsum', 1024, 4096),
         ('transpose', 65, 129), ('abssum', 17, 65), ('copy', 512, 4096)]
for operation, rows, columns in cases:
    for enabled in [False, True]:
        name = f'{operation}-{rows}x{columns}-' + ('on' if enabled else 'off')
        prefix = out / name
        objects = out / (name + '-objects')
        objects.mkdir()
        env = {k: v for k, v in os.environ.items() if not k.startswith('LUISA_SIMD_')}
        env.update(LUISA_SIMD_WARP_WIDTH='8', LUISA_SIMD_WORKER_COUNT='1',
                   LUISA_SIMD_DUMP_ASSEMBLY_DIR=str(objects),
                   LUISA_SIMD_ENABLE_MAP_FUSION='1' if enabled else '0',
                   LUISA_SIMD_DISABLE_MAP_FUSION='0' if enabled else '1')
        command = [str(build / 'bin/benchmark_tile_migrated'), 'simd', operation,
                   str(rows), str(columns), '1', '16', '16', '32', '3', '1', '1', str(prefix)]
        record = {'name': name, 'command': command,
                  'environment': {k: v for k, v in env.items() if k.startswith('LUISA_SIMD_')}}
        with open(str(prefix) + '.log', 'x') as log:
            try:
                result = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=120)
                record['exit_code'] = result.returncode
            except subprocess.TimeoutExpired:
                record['error'] = 'whole-process capture timeout after 120 seconds, not kernel time'
        manifest['cases'].append(record)
        print(json.dumps(record), flush=True)
manifest['binary_sha256_after'] = binaries()
manifest['frozen_binaries_unchanged'] = manifest['binary_sha256_before'] == manifest['binary_sha256_after']
with open(root / 'capture-manifest.json', 'x') as f:
    json.dump(manifest, f, indent=2)
assert manifest['frozen_binaries_unchanged']

"""Fresh v4 captures, exact source/object comparison, no native-entry replay."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import xml.etree.ElementTree as ET

ROOT = Path(__file__).parent
BUILD = Path('/tmp/luisa-next-integration.roZbN8/build')
SOURCE = BUILD.parent / 'source'
WORKTREE = Path('/Users/mike/CLionProjects/luisa')
OUT = ROOT / 'v4'
FILES = [
    'include/luisa/tile/bridge/xir/lower.h', 'include/luisa/tile/bridge/xir/planner.h',
    'src/tile/bridge/xir/lower.cpp', 'src/tile/bridge/xir/representation.h',
    'src/tile/bridge/xir/planner.cpp', 'src/backends/simd/runtime/simd_tile.cpp',
    'src/tests/unit/tile/bridge/test_xir.cpp', 'src/tests/unit/tile/bridge/test_xir_runtime.cpp',
    'src/tests/benchmark/benchmark_tile_migrated.cpp', 'examples/compute/tile/kernels.h',
    'src/tests/common/tile_migrated_test_utils.h',
]
CASES = [('cumsum', 8, 32), ('cumsum', 128, 1024), ('cummax', 128, 1024),
         ('cumsum', 17, 65), ('cumsum', 1024, 4096),
         ('transpose', 65, 129), ('abssum', 17, 65), ('copy', 512, 4096)]


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    with Path(path).open('rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()


def binary_hashes():
    # Include plugin .so files: these contain the actual SIMD implementation.
    paths = sorted(p for p in (BUILD / 'bin').iterdir()
                   if p.is_file() and (p.suffix in ('.so', '.dylib') or p.name == 'benchmark_tile_migrated'))
    return {str(p): digest(p) for p in paths}


def source_hashes():
    return {relative: digest(SOURCE / relative) for relative in FILES}


def comparison(old, new):
    old_hash, new_hash = digest(old), digest(new)
    return dict(v2=str(old), v4=str(new.relative_to(OUT)), v2_sha256=old_hash,
                v4_sha256=new_hash, v2_size=old.stat().st_size, v4_size=new.stat().st_size,
                exact_bytes_equal=old_hash == new_hash and old.read_bytes() == new.read_bytes())


OUT.mkdir(exist_ok=False)
captures = OUT / 'captures'
captures.mkdir()
manifest = dict(status='capturing', started_utc=now(), build=str(BUILD), source=str(SOURCE),
                purpose='Frozen v4 recapture and exact v2 comparison; not a native-entry timing replay',
                capture_timing='Diagnostic Runtime timings emitted by capture executable only; do not promote to kernel timing',
                source_sha256_before=source_hashes(), binary_sha256_before=binary_hashes(), cases=[])


def save():
    (OUT / 'capture-manifest.json').write_text(json.dumps(manifest, indent=2, allow_nan=False) + '\n')


save()
try:
    # Archive all eleven authoritative isolated source contents, not only hashes.
    for relative in FILES:
        destination = OUT / 'source' / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(SOURCE / relative, destination)
    manifest['source_snapshot_sha256'] = {relative: digest(OUT / 'source' / relative) for relative in FILES}
    if manifest['source_snapshot_sha256'] != manifest['source_sha256_before']:
        raise RuntimeError('isolated sources changed while snapshotting')
    # Worktree changes are not used to build or capture the frozen isolated v4.
    manifest['worktree_sha256_at_start'] = {relative: digest(WORKTREE / relative) for relative in FILES}
    receipts = OUT / 'receipts'
    receipts.mkdir()
    for name in ('build-v4.log', 'tests-v4.log', 'tests-v4.xml', 'capture-manifest.json', 'capture.py', 'capture-v3.py', 'capture-v4.py'):
        shutil.copy2(ROOT / name, receipts / name)
    tests = ET.parse(receipts / 'tests-v4.xml').getroot()
    testcases = tests.findall('testcase')
    required_tests = {'test_tile_migrated_simd', 'test_tile_types_simd', 'test_tile_migrated_metal',
                      'test_tile_xir', 'test_tile_xir_runtime', 'test_tile_xir_llm'}
    if (tests.get('tests') != '6' or tests.get('failures') != '0' or tests.get('skipped') != '0' or
            len(testcases) != 6 or {t.get('name') for t in testcases} != required_tests or
            any(t.get('status') != 'run' or t.find('failure') is not None or t.find('error') is not None or t.find('skipped') is not None for t in testcases)):
        raise RuntimeError('v4 prerequisite test receipt is not successful')
    manifest['prerequisite_tests'] = sorted(required_tests)
    manifest['receipt_sha256'] = {p.name: digest(p) for p in sorted(receipts.iterdir())}
    manifest['binary_modules'] = [str(p) for p in (BUILD / 'bin').iterdir() if p.suffix == '.so' and p.is_file()]
    if str(BUILD / 'bin/libluisa-backend-simd.so') not in manifest['binary_sha256_before']:
        raise RuntimeError('SIMD plugin missing from binary hash closure')
    if len(manifest['binary_sha256_before']) != 24:
        raise RuntimeError('expected exactly 24 frozen capture binaries/plugins')
    old_files = [p for p in (ROOT / 'captures').rglob('*') if p.is_file()]
    manifest['v2_artifact_sha256_before'] = {str(p.relative_to(ROOT)): digest(p) for p in sorted(old_files)}
    save()
    for operation, rows, columns in CASES:
        for enabled in (False, True):
            name = f'{operation}-{rows}x{columns}-' + ('on' if enabled else 'off')
            prefix = captures / name
            objects = captures / (name + '-objects')
            objects.mkdir()
            env = {k: v for k, v in os.environ.items() if not k.startswith('LUISA_SIMD_')}
            env.update(LUISA_SIMD_WARP_WIDTH='8', LUISA_SIMD_WORKER_COUNT='1',
                       LUISA_SIMD_DUMP_ASSEMBLY_DIR=str(objects),
                       LUISA_SIMD_ENABLE_MAP_FUSION='1' if enabled else '0',
                       LUISA_SIMD_DISABLE_MAP_FUSION='0' if enabled else '1')
            command = [str(BUILD / 'bin/benchmark_tile_migrated'), 'simd', operation,
                       str(rows), str(columns), '1', '16', '16', '32', '3', '1', '1', str(prefix)]
            record = dict(name=name, command=command, started_utc=now(),
                          environment={k: v for k, v in env.items() if k.startswith(('LUISA_SIMD_', 'LUISA_TILE_BENCH_', 'DYLD_'))})
            manifest['cases'].append(record)
            save()
            with Path(str(prefix) + '.log').open('x') as log:
                try:
                    result = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=120)
                    record['exit_code'] = result.returncode
                except subprocess.TimeoutExpired:
                    record['error'] = 'whole-process capture timeout after 120 seconds, not kernel time'
            record['finished_utc'] = now()
            if record.get('exit_code') == 0:
                records = [json.loads(line) for line in Path(str(prefix) + '.log').read_text().splitlines() if line.startswith('{')]
                if len(records) != 1:
                    raise RuntimeError('missing/ambiguous capture JSON for ' + name)
                measurement = records[0]
                if (measurement['dimensions'] != [rows, columns, 1] or
                        measurement['correctness']['checks'] != 2 or
                        measurement['correctness']['elements_per_check'] != rows * (1 if operation == 'abssum' else columns)):
                    raise RuntimeError('incorrect full-output receipt for ' + name)
                record['measurement'] = measurement
                old_prefix = ROOT / 'captures' / name
                old_objects = list((ROOT / 'captures' / (name + '-objects')).glob('*.o'))
                new_objects = list(objects.glob('*.o'))
                if len(old_objects) != 1 or len(new_objects) != 1:
                    raise RuntimeError('not exactly one old/new ORC object for ' + name)
                record['llvm_comparison'] = comparison(Path(str(old_prefix) + '.source.txt'), Path(str(prefix) + '.source.txt'))
                record['object_comparison'] = comparison(old_objects[0], new_objects[0])
                record['data_comparisons'] = {}
                for suffix in ('.input0.f32', '.input1.f32', '.expected.f64', '.output.f32'):
                    old, new = Path(str(old_prefix) + suffix), Path(str(prefix) + suffix)
                    if old.exists() or new.exists():
                        if not old.exists() or not new.exists():
                            raise RuntimeError('old/new data extent differs for ' + name + suffix)
                        record['data_comparisons'][suffix] = comparison(old, new)
            record['artifacts'] = {str(p.relative_to(OUT)): digest(p) for p in sorted(captures.glob(name + '.*')) if p.is_file()}
            record['artifacts'].update({str(p.relative_to(OUT)): digest(p) for p in sorted(objects.iterdir()) if p.is_file()})
            save()
            print(json.dumps(dict(name=name, exit_code=record.get('exit_code'),
                                  llvm_identical=record.get('llvm_comparison', {}).get('exact_bytes_equal'),
                                  object_identical=record.get('object_comparison', {}).get('exact_bytes_equal'))), flush=True)
    manifest['source_sha256_after'] = source_hashes()
    manifest['binary_sha256_after'] = binary_hashes()
    manifest['v2_artifact_sha256_after'] = {str(p.relative_to(ROOT)): digest(p) for p in sorted(old_files)}
    manifest['frozen_sources_unchanged'] = manifest['source_sha256_before'] == manifest['source_sha256_after']
    manifest['frozen_binaries_unchanged'] = manifest['binary_sha256_before'] == manifest['binary_sha256_after']
    manifest['v2_artifacts_unchanged'] = manifest['v2_artifact_sha256_before'] == manifest['v2_artifact_sha256_after']
    manifest['all_captures_passed'] = len(manifest['cases']) == 16 and all(r.get('exit_code') == 0 for r in manifest['cases'])
    manifest['llvm_exact_equal_count'] = sum(r.get('llvm_comparison', {}).get('exact_bytes_equal', False) for r in manifest['cases'])
    manifest['object_exact_equal_count'] = sum(r.get('object_comparison', {}).get('exact_bytes_equal', False) for r in manifest['cases'])
    manifest['data_exact_equal_count'] = sum(c['exact_bytes_equal'] for r in manifest['cases'] for c in r.get('data_comparisons', {}).values())
    manifest['data_comparison_count'] = sum(len(r.get('data_comparisons', {})) for r in manifest['cases'])
    manifest['all_capture_bytes_equal_v2'] = (manifest['llvm_exact_equal_count'] == 16 and
                                             manifest['object_exact_equal_count'] == 16 and
                                             manifest['data_exact_equal_count'] == manifest['data_comparison_count'])
    manifest['status'] = 'complete'
    if not all(manifest[key] for key in ('frozen_sources_unchanged', 'frozen_binaries_unchanged', 'v2_artifacts_unchanged', 'all_captures_passed', 'all_capture_bytes_equal_v2')):
        raise RuntimeError('capture/frozen-state validation failed')
except Exception as error:
    manifest.update(status='error', error=str(error))
    raise
finally:
    manifest['finished_utc'] = now()
    save()

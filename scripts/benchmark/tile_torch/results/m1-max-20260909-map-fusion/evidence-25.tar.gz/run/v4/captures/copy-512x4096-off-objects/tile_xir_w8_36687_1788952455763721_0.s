	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function tile_pointwise.packet_batch.blocks
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_tile_pointwise.packet_batch.blocks
	.p2align	2
_tile_pointwise.packet_batch.blocks:    ; @tile_pointwise.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB0_56
; %bb.1:                                ; %block.batch.loop.preheader
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #2, lsl #12             ; =8192
	sub	sp, sp, #16
	mov	w8, #0                          ; =0x0
	ldp	w9, w10, [x2, #44]
	ldp	w6, w7, [x2]
	ldp	w19, w11, [x2, #8]
	mov	w12, #1024                      ; =0x400
Lloh0:
	adrp	x13, lCPI0_0@PAGE
Lloh1:
	ldr	q0, [x13, lCPI0_0@PAGEOFF]
	mov	w13, #268435440                 ; =0xffffff0
	dup.2d	v1, x13
	mov	w14, #4080                      ; =0xff0
Lloh2:
	adrp	x15, lCPI0_1@PAGE
Lloh3:
	ldr	q2, [x15, lCPI0_1@PAGEOFF]
	add	x15, sp, #16
	adrp	x17, lCPI0_2@PAGE
	dup.2d	v3, x14
	b	LBB0_3
LBB0_2:                                 ; %tile_pointwise.packet_batch.exit
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	w16, w5, #1
	cmp	w16, w9
	cset	w16, eq
	csinc	w6, wzr, w5, eq
	cinc	w7, w4, eq
	cmp	w7, w10
	cset	w19, eq
	ands	w16, w16, w19
	csel	w7, wzr, w7, ne
	add	w19, w1, w16
	add	w8, w8, #1
	cmp	w8, w3
	b.eq	LBB0_55
LBB0_3:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_12 Depth 2
                                        ;       Child Loop BB0_13 Depth 3
                                        ;       Child Loop BB0_15 Depth 3
                                        ;     Child Loop BB0_21 Depth 2
                                        ;     Child Loop BB0_39 Depth 2
                                        ;     Child Loop BB0_5 Depth 2
                                        ;       Child Loop BB0_6 Depth 3
                                        ;       Child Loop BB0_8 Depth 3
	mov	x1, x19
	mov	x4, x7
	mov	x5, x6
	ubfiz	x6, x6, #10, #32
	cmp	x6, x11
	csel	x7, x6, xzr, ls
	subs	x19, x11, x7
	cmp	x19, #1024
	csel	x19, x19, x12, lo
	cmp	x11, x7
	ccmp	x6, x11, #2, hi
	csel	x7, x19, xzr, ls
	cmp	x7, #1024
	b.lo	LBB0_10
; %bb.4:                                ; %packet.batch.full.loop.preheader.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	w6, #0                          ; =0x0
	ldr	x19, [x0]
	ldr	x20, [x0, #32]
	lsl	w7, w5, #10
	dup.2d	v4, x19
	dup.2d	v5, x20
LBB0_5:                                 ; %packet.batch.full.loop.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_6 Depth 3
                                        ;       Child Loop BB0_8 Depth 3
	mov	x19, #0                         ; =0x0
	add	w20, w7, w6, lsl #3
	dup.4s	v6, w20
	orr.16b	v18, v6, v0
	orr.16b	v19, v6, v2
	ushll2.2d	v6, v19, #0
	ushll2.2d	v7, v18, #0
	ushll.2d	v16, v19, #0
	ushll.2d	v17, v18, #0
	ushr.2d	v17, v17, #4
	ushr.2d	v16, v16, #4
	ushr.2d	v7, v7, #4
	ushr.2d	v6, v6, #4
	and.16b	v6, v6, v1
	and.16b	v7, v7, v1
	and.16b	v16, v16, v1
	and.16b	v17, v17, v1
	ushll.2d	v21, v18, #4
	ushll.2d	v20, v19, #4
	ushll2.2d	v22, v18, #4
	ushll2.2d	v18, v19, #4
	and.16b	v18, v18, v3
	and.16b	v19, v22, v3
	and.16b	v20, v20, v3
	and.16b	v21, v21, v3
LBB0_6:                                 ; %direct.true.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_5 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsr	x20, x19, #4
	and	x21, x19, #0xf
	dup.2d	v22, x20
	add.2d	v23, v22, v17
	add.2d	v24, v22, v7
	add.2d	v25, v22, v16
	add.2d	v22, v22, v6
	dup.2d	v26, x21
	shl.2d	v22, v22, #12
	shl.2d	v25, v25, #12
	shl.2d	v24, v24, #12
	shl.2d	v23, v23, #12
	orr.16b	v27, v26, v18
	orr.16b	v22, v22, v27
	orr.16b	v27, v26, v20
	orr.16b	v25, v25, v27
	orr.16b	v27, v26, v19
	orr.16b	v24, v24, v27
	orr.16b	v26, v26, v21
	orr.16b	v23, v23, v26
	shl.2d	v23, v23, #2
	shl.2d	v24, v24, #2
	shl.2d	v25, v25, #2
	shl.2d	v22, v22, #2
	add.2d	v22, v4, v22
	add.2d	v25, v4, v25
	add.2d	v24, v4, v24
	add.2d	v23, v4, v23
	mov.d	x20, v23[1]
	fmov	x21, d23
	mov.d	x22, v24[1]
	mov.d	x23, v25[1]
	fmov	x24, d24
	fmov	x25, d25
	mov.d	x26, v22[1]
	ldr	s23, [x21]
	ld1.s	{ v23 }[1], [x20]
	fmov	x20, d22
	ld1.s	{ v23 }[2], [x24]
	ldr	s22, [x25]
	ld1.s	{ v23 }[3], [x22]
	ld1.s	{ v22 }[1], [x23]
	ld1.s	{ v22 }[2], [x20]
	ld1.s	{ v22 }[3], [x26]
	add	x20, x15, x19, lsl #5
	stp	q23, q22, [x20]
	add	x19, x19, #1
	cmp	x19, #256
	b.ne	LBB0_6
; %bb.7:                                ; %direct.true25.i.i.preheader
                                        ;   in Loop: Header=BB0_5 Depth=2
	mov	x19, #0                         ; =0x0
LBB0_8:                                 ; %direct.true25.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_5 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	x20, x19, #0xf
	lsr	x21, x19, #4
	dup.2d	v22, x21
	add.2d	v23, v22, v17
	add.2d	v24, v22, v7
	add.2d	v25, v22, v16
	add.2d	v22, v22, v6
	dup.2d	v26, x20
	shl.2d	v22, v22, #12
	shl.2d	v25, v25, #12
	shl.2d	v24, v24, #12
	shl.2d	v23, v23, #12
	orr.16b	v27, v26, v18
	orr.16b	v22, v22, v27
	orr.16b	v27, v26, v20
	orr.16b	v25, v25, v27
	orr.16b	v27, v26, v19
	orr.16b	v24, v24, v27
	orr.16b	v26, v26, v21
	orr.16b	v23, v23, v26
	add	x20, x15, x19, lsl #5
	ldp	q27, q26, [x20]
	shl.2d	v23, v23, #2
	shl.2d	v24, v24, #2
	shl.2d	v25, v25, #2
	shl.2d	v22, v22, #2
	add.2d	v22, v5, v22
	add.2d	v23, v5, v23
	mov.d	x20, v23[1]
	fmov	x21, d23
	str	s27, [x21]
	st1.s	{ v27 }[1], [x20]
	add.2d	v23, v5, v24
	mov.d	x20, v23[1]
	fmov	x21, d23
	st1.s	{ v27 }[2], [x21]
	add.2d	v23, v5, v25
	st1.s	{ v27 }[3], [x20]
	mov.d	x20, v23[1]
	fmov	x21, d23
	str	s26, [x21]
	st1.s	{ v26 }[1], [x20]
	mov.d	x20, v22[1]
	fmov	x21, d22
	st1.s	{ v26 }[2], [x21]
	st1.s	{ v26 }[3], [x20]
	add	x19, x19, #1
	cmp	x19, #256
	b.ne	LBB0_8
; %bb.9:                                ; %tile_pointwise.exit.i
                                        ;   in Loop: Header=BB0_5 Depth=2
	add	w6, w6, #1
	cmp	w6, #128
	b.ne	LBB0_5
	b	LBB0_2
LBB0_10:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	lsr	x6, x7, #3
	cmp	x7, #8
	b.lo	LBB0_17
; %bb.11:                               ; %packet.batch.partial.full.loop.preheader.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	w19, #0                         ; =0x0
	ldr	x20, [x0]
	ldr	x21, [x0, #32]
	lsl	w22, w5, #10
LBB0_12:                                ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_13 Depth 3
                                        ;       Child Loop BB0_15 Depth 3
	mov	x23, #0                         ; =0x0
	add	w24, w22, w19, lsl #3
	dup.4s	v4, w24
	orr.16b	v16, v4, v0
	orr.16b	v17, v4, v2
	ushll2.2d	v4, v17, #0
	ushll2.2d	v5, v16, #0
	ushll.2d	v6, v17, #0
	ushll.2d	v7, v16, #0
	ushr.2d	v7, v7, #4
	ushr.2d	v6, v6, #4
	ushr.2d	v5, v5, #4
	ushr.2d	v4, v4, #4
	dup.2d	v18, x13
	and.16b	v4, v4, v18
	and.16b	v5, v5, v18
	and.16b	v6, v6, v18
	and.16b	v7, v7, v18
	ushll.2d	v19, v16, #4
	ushll.2d	v18, v17, #4
	ushll2.2d	v20, v16, #4
	ushll2.2d	v16, v17, #4
	dup.2d	v21, x14
	and.16b	v16, v16, v21
	and.16b	v17, v20, v21
	and.16b	v18, v18, v21
	and.16b	v19, v19, v21
LBB0_13:                                ; %direct.true.i5.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_12 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsr	x24, x23, #4
	dup.2d	v20, x24
	and	x24, x23, #0xf
	add.2d	v21, v20, v7
	add.2d	v22, v20, v5
	add.2d	v23, v20, v6
	dup.2d	v24, x24
	add.2d	v20, v20, v4
	shl.2d	v20, v20, #12
	shl.2d	v23, v23, #12
	shl.2d	v22, v22, #12
	shl.2d	v21, v21, #12
	orr.16b	v25, v24, v16
	orr.16b	v20, v20, v25
	orr.16b	v25, v24, v18
	orr.16b	v23, v23, v25
	orr.16b	v25, v24, v17
	orr.16b	v22, v22, v25
	orr.16b	v24, v24, v19
	orr.16b	v21, v21, v24
	shl.2d	v21, v21, #2
	shl.2d	v22, v22, #2
	shl.2d	v23, v23, #2
	dup.2d	v24, x20
	shl.2d	v20, v20, #2
	add.2d	v20, v24, v20
	add.2d	v23, v24, v23
	add.2d	v22, v24, v22
	add.2d	v21, v24, v21
	mov.d	x24, v21[1]
	fmov	x25, d21
	mov.d	x26, v22[1]
	mov.d	x27, v23[1]
	fmov	x28, d22
	fmov	x30, d23
	mov.d	x16, v20[1]
	ldr	s21, [x25]
	ld1.s	{ v21 }[1], [x24]
	fmov	x24, d20
	ld1.s	{ v21 }[2], [x28]
	ldr	s20, [x30]
	ld1.s	{ v21 }[3], [x26]
	ld1.s	{ v20 }[1], [x27]
	ld1.s	{ v20 }[2], [x24]
	ld1.s	{ v20 }[3], [x16]
	add	x16, x15, x23, lsl #5
	stp	q21, q20, [x16]
	add	x23, x23, #1
	cmp	x23, #256
	b.ne	LBB0_13
; %bb.14:                               ; %direct.true25.i14.i.preheader
                                        ;   in Loop: Header=BB0_12 Depth=2
	mov	x23, #0                         ; =0x0
LBB0_15:                                ; %direct.true25.i14.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_12 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsr	x16, x23, #4
	dup.2d	v20, x16
	and	x16, x23, #0xf
	add.2d	v21, v20, v7
	add.2d	v22, v20, v5
	add.2d	v23, v20, v6
	dup.2d	v24, x16
	add.2d	v20, v20, v4
	shl.2d	v20, v20, #12
	shl.2d	v23, v23, #12
	shl.2d	v22, v22, #12
	shl.2d	v21, v21, #12
	orr.16b	v25, v24, v16
	orr.16b	v20, v20, v25
	orr.16b	v25, v24, v18
	orr.16b	v23, v23, v25
	orr.16b	v25, v24, v17
	orr.16b	v22, v22, v25
	orr.16b	v24, v24, v19
	orr.16b	v21, v21, v24
	add	x16, x15, x23, lsl #5
	ldp	q25, q24, [x16]
	shl.2d	v21, v21, #2
	shl.2d	v22, v22, #2
	shl.2d	v23, v23, #2
	shl.2d	v20, v20, #2
	dup.2d	v26, x21
	add.2d	v20, v26, v20
	add.2d	v21, v26, v21
	mov.d	x16, v21[1]
	fmov	x24, d21
	str	s25, [x24]
	st1.s	{ v25 }[1], [x16]
	add.2d	v21, v26, v22
	mov.d	x16, v21[1]
	fmov	x24, d21
	st1.s	{ v25 }[2], [x24]
	add.2d	v21, v26, v23
	st1.s	{ v25 }[3], [x16]
	mov.d	x16, v21[1]
	fmov	x24, d21
	str	s24, [x24]
	st1.s	{ v24 }[1], [x16]
	mov.d	x16, v20[1]
	fmov	x24, d20
	st1.s	{ v24 }[2], [x24]
	st1.s	{ v24 }[3], [x16]
	add	x23, x23, #1
	cmp	x23, #256
	b.ne	LBB0_15
; %bb.16:                               ; %tile_pointwise.exit23.i
                                        ;   in Loop: Header=BB0_12 Depth=2
	add	w19, w19, #1
	cmp	w19, w6
	b.ne	LBB0_12
LBB0_17:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w7, w7, #0x7
	cbz	w7, LBB0_2
; %bb.18:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	dup.4s	v5, w7
	cmhi.4s	v4, v5, v2
	cmhi.4s	v5, v5, v0
	uzp1.8h	v23, v5, v4
	umaxv.8h	h6, v23
	fmov	w16, s6
	tbz	w16, #0, LBB0_2
; %bb.19:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x7, #0                          ; =0x0
	ldr	x19, [x0]
	lsl	w16, w6, #3
	orr	w16, w16, w5, lsl #10
	dup.4s	v6, w16
	ldr	x6, [x0, #32]
	sshll2.2d	v18, v4, #0
	sshll2.2d	v19, v5, #0
	sshll.2d	v20, v4, #0
	sshll.2d	v21, v5, #0
	orr.16b	v7, v6, v0
	orr.16b	v6, v6, v2
	and.16b	v22, v4, v6
	and.16b	v24, v5, v7
	ushll.2d	v6, v24, #0
	ushll.2d	v7, v22, #0
	ushll2.2d	v16, v24, #0
	ushll2.2d	v17, v22, #0
	mov	w16, #8                         ; =0x8
	dup.2d	v25, x16
	and.16b	v26, v21, v25
	and.16b	v27, v20, v25
	and.16b	v28, v19, v25
	and.16b	v25, v18, v25
	neg.2d	v25, v25
	ushl.2d	v17, v17, v25
	neg.2d	v25, v28
	ushl.2d	v16, v16, v25
	neg.2d	v25, v27
	ushl.2d	v7, v7, v25
	neg.2d	v25, v26
	ushl.2d	v6, v6, v25
	shl.2d	v25, v6, #4
	shl.2d	v26, v7, #4
	shl.2d	v7, v16, #4
	shl.2d	v6, v17, #4
	and.16b	v6, v18, v6
	and.16b	v7, v19, v7
	and.16b	v16, v20, v26
	and.16b	v17, v21, v25
	ushll2.2d	v25, v22, #4
	ushll2.2d	v26, v24, #4
	ushll.2d	v22, v22, #4
	ushll.2d	v24, v24, #4
	dup.2d	v27, x14
	and.16b	v18, v18, v27
	and.16b	v18, v25, v18
	and.16b	v19, v19, v27
	and.16b	v19, v26, v19
	and.16b	v20, v20, v27
	and.16b	v20, v22, v20
	and.16b	v21, v21, v27
	and.16b	v21, v24, v21
	b	LBB0_21
LBB0_20:                                ; %else97
                                        ;   in Loop: Header=BB0_21 Depth=2
	add	x16, x15, x7, lsl #5
	ldp	q26, q27, [x16]
	bif.16b	v25, v27, v4
	bif.16b	v24, v26, v5
	stp	q24, q25, [x16]
	add	x7, x7, #1
	cmp	x7, #256
	b.eq	LBB0_37
LBB0_21:                                ; %direct.true.i26.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q22, [x17, lCPI0_2@PAGEOFF]
	and.16b	v22, v23, v22
	addv.8h	h22, v22
	fmov	w20, s22
	and	x16, x7, #0xf
	lsr	x21, x7, #4
	dup.2d	v26, x21
	add.2d	v24, v26, v17
	dup.2d	v27, x16
	shl.2d	v24, v24, #12
	orr.16b	v25, v27, v21
	orr.16b	v24, v24, v25
	shl.2d	v24, v24, #2
	dup.2d	v28, x19
	add.2d	v29, v28, v24
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
	tbz	w20, #0, LBB0_23
; %bb.22:                               ; %cond.load
                                        ;   in Loop: Header=BB0_21 Depth=2
	fmov	x16, d29
	ldr	s24, [x16]
LBB0_23:                                ; %else
                                        ;   in Loop: Header=BB0_21 Depth=2
	and	w20, w20, #0xff
	tbz	w20, #1, LBB0_25
; %bb.24:                               ; %cond.load57
                                        ;   in Loop: Header=BB0_21 Depth=2
	mov.d	x16, v29[1]
	ld1.s	{ v24 }[1], [x16]
LBB0_25:                                ; %else61
                                        ;   in Loop: Header=BB0_21 Depth=2
	add.2d	v29, v26, v7
	shl.2d	v29, v29, #12
	orr.16b	v30, v27, v19
	orr.16b	v29, v29, v30
	shl.2d	v29, v29, #2
	add.2d	v29, v28, v29
	tbz	w20, #2, LBB0_27
; %bb.26:                               ; %cond.load63
                                        ;   in Loop: Header=BB0_21 Depth=2
	fmov	x16, d29
	ld1.s	{ v24 }[2], [x16]
LBB0_27:                                ; %else67
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbz	w20, #3, LBB0_29
; %bb.28:                               ; %cond.load69
                                        ;   in Loop: Header=BB0_21 Depth=2
	mov.d	x16, v29[1]
	ld1.s	{ v24 }[3], [x16]
LBB0_29:                                ; %else73
                                        ;   in Loop: Header=BB0_21 Depth=2
	add.2d	v29, v26, v16
	shl.2d	v29, v29, #12
	orr.16b	v30, v27, v20
	orr.16b	v29, v29, v30
	shl.2d	v29, v29, #2
	add.2d	v29, v28, v29
	tbz	w20, #4, LBB0_31
; %bb.30:                               ; %cond.load75
                                        ;   in Loop: Header=BB0_21 Depth=2
	fmov	x16, d29
	ld1.s	{ v25 }[0], [x16]
LBB0_31:                                ; %else79
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbz	w20, #5, LBB0_33
; %bb.32:                               ; %cond.load81
                                        ;   in Loop: Header=BB0_21 Depth=2
	mov.d	x16, v29[1]
	ld1.s	{ v25 }[1], [x16]
LBB0_33:                                ; %else85
                                        ;   in Loop: Header=BB0_21 Depth=2
	add.2d	v26, v26, v6
	shl.2d	v26, v26, #12
	orr.16b	v27, v27, v18
	orr.16b	v26, v26, v27
	shl.2d	v26, v26, #2
	add.2d	v26, v28, v26
	tbz	w20, #6, LBB0_35
; %bb.34:                               ; %cond.load87
                                        ;   in Loop: Header=BB0_21 Depth=2
	fmov	x16, d26
	ld1.s	{ v25 }[2], [x16]
LBB0_35:                                ; %else91
                                        ;   in Loop: Header=BB0_21 Depth=2
	tbz	w20, #7, LBB0_20
; %bb.36:                               ; %cond.load93
                                        ;   in Loop: Header=BB0_21 Depth=2
	mov.d	x16, v26[1]
	ld1.s	{ v25 }[3], [x16]
	b	LBB0_20
LBB0_37:                                ; %direct.true25.i35.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x7, #0                          ; =0x0
	b	LBB0_39
LBB0_38:                                ; %else130
                                        ;   in Loop: Header=BB0_39 Depth=2
	add	x7, x7, #1
	cmp	x7, #256
	b.eq	LBB0_2
LBB0_39:                                ; %direct.true25.i35.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w19, s22
	and	x16, x7, #0xf
	lsr	x20, x7, #4
	dup.2d	v23, x20
	dup.2d	v24, x16
	add.2d	v25, v23, v17
	shl.2d	v25, v25, #12
	orr.16b	v26, v24, v21
	orr.16b	v25, v25, v26
	add	x16, x15, x7, lsl #5
	ldp	q27, q26, [x16]
	and.16b	v27, v5, v27
	shl.2d	v28, v25, #2
	dup.2d	v25, x6
	add.2d	v28, v25, v28
	tbz	w19, #0, LBB0_41
; %bb.40:                               ; %cond.store
                                        ;   in Loop: Header=BB0_39 Depth=2
	fmov	x16, d28
	str	s27, [x16]
LBB0_41:                                ; %else102
                                        ;   in Loop: Header=BB0_39 Depth=2
	and	w19, w19, #0xff
	tbz	w19, #1, LBB0_43
; %bb.42:                               ; %cond.store103
                                        ;   in Loop: Header=BB0_39 Depth=2
	mov.d	x16, v28[1]
	st1.s	{ v27 }[1], [x16]
LBB0_43:                                ; %else106
                                        ;   in Loop: Header=BB0_39 Depth=2
	add.2d	v28, v23, v7
	shl.2d	v28, v28, #12
	orr.16b	v29, v24, v19
	orr.16b	v28, v28, v29
	shl.2d	v28, v28, #2
	add.2d	v28, v25, v28
	tbz	w19, #2, LBB0_45
; %bb.44:                               ; %cond.store107
                                        ;   in Loop: Header=BB0_39 Depth=2
	fmov	x16, d28
	st1.s	{ v27 }[2], [x16]
LBB0_45:                                ; %else110
                                        ;   in Loop: Header=BB0_39 Depth=2
	tbz	w19, #3, LBB0_47
; %bb.46:                               ; %cond.store111
                                        ;   in Loop: Header=BB0_39 Depth=2
	mov.d	x16, v28[1]
	st1.s	{ v27 }[3], [x16]
LBB0_47:                                ; %else114
                                        ;   in Loop: Header=BB0_39 Depth=2
	add.2d	v27, v23, v16
	shl.2d	v27, v27, #12
	orr.16b	v28, v24, v20
	orr.16b	v27, v27, v28
	and.16b	v26, v4, v26
	shl.2d	v27, v27, #2
	add.2d	v27, v25, v27
	tbz	w19, #4, LBB0_49
; %bb.48:                               ; %cond.store115
                                        ;   in Loop: Header=BB0_39 Depth=2
	fmov	x16, d27
	str	s26, [x16]
LBB0_49:                                ; %else118
                                        ;   in Loop: Header=BB0_39 Depth=2
	tbz	w19, #5, LBB0_51
; %bb.50:                               ; %cond.store119
                                        ;   in Loop: Header=BB0_39 Depth=2
	mov.d	x16, v27[1]
	st1.s	{ v26 }[1], [x16]
LBB0_51:                                ; %else122
                                        ;   in Loop: Header=BB0_39 Depth=2
	add.2d	v23, v23, v6
	shl.2d	v23, v23, #12
	orr.16b	v24, v24, v18
	orr.16b	v23, v23, v24
	shl.2d	v23, v23, #2
	add.2d	v23, v25, v23
	tbnz	w19, #6, LBB0_53
; %bb.52:                               ; %else126
                                        ;   in Loop: Header=BB0_39 Depth=2
	tbz	w19, #7, LBB0_38
	b	LBB0_54
LBB0_53:                                ; %cond.store123
                                        ;   in Loop: Header=BB0_39 Depth=2
	fmov	x16, d23
	st1.s	{ v26 }[2], [x16]
	tbz	w19, #7, LBB0_38
LBB0_54:                                ; %cond.store127
                                        ;   in Loop: Header=BB0_39 Depth=2
	mov.d	x16, v23[1]
	st1.s	{ v26 }[3], [x16]
	b	LBB0_38
LBB0_55:                                ; %block.batch.exit.loopexit
	stp	w5, w4, [x2]
	str	w1, [x2, #8]
	mov	w8, #1016                       ; =0x3f8
	str	w8, [x2, #36]
	add	sp, sp, #2, lsl #12             ; =8192
	add	sp, sp, #16
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
LBB0_56:                                ; %block.batch.exit
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpLdr	Lloh0, Lloh1
                                        ; -- End function
.subsections_via_symbols

	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function tile_row_reduce
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_4:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_5:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_6:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_7:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_3:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_tile_row_reduce:                       ; @tile_row_reduce
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #3, lsl #12             ; =12288
	sub	sp, sp, #944
	fmov	s2, wzr
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #856
	str	wzr, [sp, #13228]
	stur	wzr, [x8, #81]
	stur	xzr, [x8, #52]
	stur	xzr, [x8, #68]
	stur	xzr, [x8, #60]
	stur	xzr, [x8, #20]
	stur	xzr, [x8, #36]
	stur	xzr, [x8, #28]
	str	xzr, [sp, #13152]
	str	xzr, [sp, #13144]
	ldr	x9, [x0]
	str	x9, [sp, #168]                  ; 8-byte Folded Spill
	ldr	x9, [x0, #16]
	str	x9, [sp, #216]                  ; 8-byte Folded Spill
	ldr	w9, [x1]
	ldr	w10, [x1, #36]
	dup.4s	v0, w2
Lloh0:
	adrp	x11, lCPI0_0@PAGE
Lloh1:
	ldr	q1, [x11, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x11, lCPI0_1@PAGE
Lloh3:
	ldr	q3, [x11, lCPI0_1@PAGEOFF]
	cmhi.4s	v4, v0, v3
	cmhi.4s	v0, v0, v1
	uzp1.8h	v4, v0, v4
	xtn.8b	v0, v4
Lloh4:
	adrp	x11, lCPI0_2@PAGE
Lloh5:
	ldr	q5, [x11, lCPI0_2@PAGEOFF]
	and.16b	v5, v4, v5
	addv.8h	h5, v5
	fmov	w11, s5
	and	w11, w11, #0xff
	fmov	s5, w11
	cmeq.8b	v2, v5, v2
	umov.b	w11, v2[0]
	and	w12, w11, #0x1
	fmov	s2, w12
	ubfx	w12, w11, #1, #1
	mov.b	v2[1], w12
	ubfx	w12, w11, #2, #1
	mov.b	v2[2], w12
	ubfx	w12, w11, #3, #1
	mov.b	v2[3], w12
	ubfx	w12, w11, #4, #1
	mov.b	v2[4], w12
	ubfx	w12, w11, #5, #1
	mov.b	v2[5], w12
	ubfx	w12, w11, #6, #1
	mov.b	v2[6], w12
	ubfx	w11, w11, #7, #1
	mov.b	v2[7], w11
	movi.8b	v5, #1
	eor.8b	v2, v2, v5
	str	d0, [sp, #1752]                 ; 8-byte Folded Spill
	and.8b	v2, v2, v0
	umaxv.8h	h4, v4
	fmov	w11, s4
	shl.8b	v2, v2, #7
	cmlt.8b	v4, v2, #0
Lloh6:
	adrp	x12, lCPI0_3@PAGE
Lloh7:
	ldr	d2, [x12, lCPI0_3@PAGEOFF]
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x8, #80]
	str	wzr, [sp, #13220]
	str	wzr, [sp, #13192]
	str	wzr, [sp, #13188]
	str	wzr, [sp, #13160]
	tbnz	w11, #0, LBB0_1
	b	LBB0_601
LBB0_1:                                 ; %scheduler.dispatch.lr.ph.lr.ph
	stp	xzr, xzr, [sp, #368]            ; 16-byte Folded Spill
	str	xzr, [sp, #296]                 ; 8-byte Folded Spill
	str	xzr, [sp, #616]                 ; 8-byte Folded Spill
	stp	xzr, xzr, [sp, #488]            ; 16-byte Folded Spill
	str	xzr, [sp, #504]                 ; 8-byte Folded Spill
	mov	w14, #0                         ; =0x0
	stp	xzr, xzr, [sp, #64]             ; 16-byte Folded Spill
	stp	xzr, xzr, [sp, #48]             ; 16-byte Folded Spill
	stp	xzr, xzr, [sp, #32]             ; 16-byte Folded Spill
	stp	xzr, xzr, [sp, #16]             ; 16-byte Folded Spill
	add	x11, sp, #1, lsl #12            ; =4096
	add	x11, x11, #728
	dup.2d	v0, x11
	add	w9, w10, w9, lsl #5
	dup.4s	v4, w9
	add.4s	v3, v4, v3
	add.4s	v1, v4, v1
	ushll2.2d	v4, v3, #2
	stp	q4, q0, [sp, #128]              ; 32-byte Folded Spill
	ushll2.2d	v4, v1, #2
	ushll.2d	v3, v3, #2
	stp	q3, q4, [sp, #96]               ; 32-byte Folded Spill
	ushll.2d	v1, v1, #2
	str	q1, [sp, #80]                   ; 16-byte Folded Spill
	movi.2d	v1, #0000000000000000
	stp	q1, q1, [sp, #416]              ; 32-byte Folded Spill
	mov	w12, #1                         ; =0x1
	add	x21, sp, #3, lsl #12            ; =12288
	add	x21, x21, #936
	add	x27, sp, #3, lsl #12            ; =12288
	add	x27, x27, #904
	add	x28, sp, #3, lsl #12            ; =12288
	add	x28, x28, #872
	add	x5, sp, #3, lsl #12             ; =12288
	add	x5, x5, #864
	stp	q1, q1, [sp, #384]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #576]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #544]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #256]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #224]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #176]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #912]              ; 32-byte Folded Spill
	str	q1, [sp, #1344]                 ; 16-byte Folded Spill
	str	q1, [sp, #1328]                 ; 16-byte Folded Spill
	str	q1, [sp, #1312]                 ; 16-byte Folded Spill
	add	x17, sp, #2112
	mov	w0, #-1                         ; =0xffffffff
	add	x1, sp, #2080
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #560
	add	x20, sp, #1, lsl #12            ; =4096
	add	x20, x20, #528
	add	x22, sp, #1, lsl #12            ; =4096
	add	x22, x22, #240
	add	x25, sp, #1, lsl #12            ; =4096
	add	x25, x25, #208
	add	x26, sp, #3952
	add	x30, sp, #3376
	add	x24, sp, #3344
	mov	x13, x12
	str	q1, [sp, #1296]                 ; 16-byte Folded Spill
	str	q1, [sp, #1280]                 ; 16-byte Folded Spill
	str	q1, [sp, #1264]                 ; 16-byte Folded Spill
	str	q1, [sp, #1648]                 ; 16-byte Folded Spill
	str	q1, [sp, #1632]                 ; 16-byte Folded Spill
	movi.2d	v22, #0000000000000000
	movi.2d	v11, #0000000000000000
	stp	q1, q1, [sp, #624]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #880]              ; 32-byte Folded Spill
	str	q1, [sp, #1248]                 ; 16-byte Folded Spill
	str	q1, [sp, #1232]                 ; 16-byte Folded Spill
	str	q1, [sp, #1216]                 ; 16-byte Folded Spill
	str	q1, [sp, #1200]                 ; 16-byte Folded Spill
	str	q1, [sp, #1184]                 ; 16-byte Folded Spill
	str	q1, [sp, #1168]                 ; 16-byte Folded Spill
	movi.2d	v27, #0000000000000000
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #1680]                 ; 16-byte Folded Spill
	movi.2d	v26, #0000000000000000
	movi.2d	v29, #0000000000000000
	stp	q1, q1, [sp, #448]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #848]              ; 32-byte Folded Spill
	str	q1, [sp, #1152]                 ; 16-byte Folded Spill
	str	q1, [sp, #1136]                 ; 16-byte Folded Spill
	str	q1, [sp, #1120]                 ; 16-byte Folded Spill
	str	q1, [sp, #1104]                 ; 16-byte Folded Spill
	str	q1, [sp, #1088]                 ; 16-byte Folded Spill
	str	q1, [sp, #1072]                 ; 16-byte Folded Spill
	movi.2d	v15, #0000000000000000
	movi.2d	v23, #0000000000000000
	str	q0, [sp, #1664]                 ; 16-byte Folded Spill
	movi.2d	v14, #0000000000000000
	stp	q1, q1, [sp, #512]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #752]              ; 32-byte Folded Spill
	str	q1, [sp, #1056]                 ; 16-byte Folded Spill
	str	q1, [sp, #1040]                 ; 16-byte Folded Spill
	stp	q1, q1, [sp, #1008]             ; 32-byte Folded Spill
	stp	q1, q1, [sp, #976]              ; 32-byte Folded Spill
	str	q0, [sp, #1712]                 ; 16-byte Folded Spill
	movi.2d	v31, #0000000000000000
	str	q0, [sp, #1488]                 ; 16-byte Folded Spill
	str	q1, [sp, #1600]                 ; 16-byte Folded Spill
	stp	q1, q1, [sp, #944]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #336]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #304]              ; 32-byte Folded Spill
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v20, #0000000000000000
	stp	q1, q1, [sp, #816]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #784]              ; 32-byte Folded Spill
	str	q1, [sp, #1472]                 ; 16-byte Folded Spill
	str	q1, [sp, #1456]                 ; 16-byte Folded Spill
	str	q1, [sp, #1440]                 ; 16-byte Folded Spill
	str	q1, [sp, #1424]                 ; 16-byte Folded Spill
	movi.2d	v21, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v9, #0000000000000000
	movi.2d	v12, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v8, #0000000000000000
	movi.2d	v13, #0000000000000000
LBB0_2:                                 ; %scheduler.dispatch.lr.ph
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_6 Depth 2
                                        ;       Child Loop BB0_11 Depth 3
                                        ;         Child Loop BB0_123 Depth 4
                                        ;         Child Loop BB0_213 Depth 4
                                        ;         Child Loop BB0_295 Depth 4
                                        ;         Child Loop BB0_377 Depth 4
                                        ;         Child Loop BB0_459 Depth 4
                                        ;         Child Loop BB0_506 Depth 4
                                        ;         Child Loop BB0_529 Depth 4
                                        ;         Child Loop BB0_38 Depth 4
                                        ;       Child Loop BB0_584 Depth 3
	stp	q9, q25, [sp, #688]             ; 32-byte Folded Spill
	stp	q28, q21, [sp, #720]            ; 32-byte Folded Spill
	str	q20, [sp, #1360]                ; 16-byte Folded Spill
	str	q18, [sp, #1376]                ; 16-byte Folded Spill
	str	q17, [sp, #1392]                ; 16-byte Folded Spill
	str	q16, [sp, #1408]                ; 16-byte Folded Spill
	mov.16b	v21, v22
	mov.16b	v22, v11
	mov.16b	v28, v15
	mov.16b	v25, v27
	b	LBB0_6
LBB0_3:                                 ; %schedule.23.convergence.cascade.exit575_crit_edge
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w3, s1
LBB0_4:                                 ; %convergence.cascade.exit575
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w3, #0xff
	b.ne	LBB0_587
LBB0_5:                                 ; %scheduler.loop.backedge
                                        ;   in Loop: Header=BB0_6 Depth=2
	cbz	x13, LBB0_601
LBB0_6:                                 ; %scheduler.dispatch
                                        ;   Parent Loop BB0_2 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_11 Depth 3
                                        ;         Child Loop BB0_123 Depth 4
                                        ;         Child Loop BB0_213 Depth 4
                                        ;         Child Loop BB0_295 Depth 4
                                        ;         Child Loop BB0_377 Depth 4
                                        ;         Child Loop BB0_459 Depth 4
                                        ;         Child Loop BB0_506 Depth 4
                                        ;         Child Loop BB0_529 Depth 4
                                        ;         Child Loop BB0_38 Depth 4
                                        ;       Child Loop BB0_584 Depth 3
	sub	w13, w13, #1
	ldrb	w11, [x21, w13, sxtw]
	and	w15, w11, #0x1
	fmov	s9, w15
	ubfx	w15, w11, #1, #1
	mov.b	v9[1], w15
	ubfx	w15, w11, #2, #1
	mov.b	v9[2], w15
	ubfx	w15, w11, #3, #1
	mov.b	v9[3], w15
	ubfx	w15, w11, #4, #1
	mov.b	v9[4], w15
	ubfx	w15, w11, #5, #1
	mov.b	v9[5], w15
	ubfx	w15, w11, #6, #1
	mov.b	v9[6], w15
	lsr	w11, w11, #7
	mov.b	v9[7], w11
	ldr	w7, [x27, w13, sxtw #2]
	ldr	w15, [x28, w13, sxtw #2]
	b	LBB0_11
LBB0_7:                                 ; %convergence.overflow.resume567
                                        ;   in Loop: Header=BB0_11 Depth=3
	mvn	w9, w14
	rbit	w9, w9
	clz	w9, w9
	mov	w10, #255                       ; =0xff
	bics	wzr, w10, w14
	csel	w6, wzr, w9, eq
	ldrb	w9, [x5, w6, uxtw]
	and	w10, w9, #0x1
	fmov	s1, w10
	ubfx	w10, w9, #1, #1
	mov.b	v1[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v1[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v1[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v1[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v1[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v1[6], w10
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, w6, uxtw]
	and	w10, w9, #0x1
	fmov	s3, w10
	ubfx	w10, w9, #1, #1
	mov.b	v3[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v3[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v3[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v3[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v3[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v3[6], w10
	lsr	w9, w9, #7
	mov.b	v3[7], w9
	cmp	w4, #0
	csetm	w9, ne
	dup.8b	v4, w9
	bit.8b	v1, v9, v4
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x5, w6, uxtw]
	bic.8b	v1, v3, v4
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x8, w6, uxtw]
	cmp	x13, #8
	b.hs	LBB0_603
; %bb.8:                                ; %ready.overflow.resume569
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.16b	v22, v15
	mov.16b	v28, v27
	mov.16b	v21, v30
	str	q12, [sp, #3200]
	str	q19, [sp, #3216]
	ubfiz	x9, x6, #2, #3
	add	x10, sp, #3200
	ldr	w10, [x10, x9]
	cmp	w4, #0
	csel	w10, w15, w10, ne
	str	q12, [sp, #3168]
	str	q19, [sp, #3184]
	add	x11, sp, #3168
	str	w10, [x11, x9]
	ldr	q19, [sp, #3184]
	ldr	q12, [sp, #3168]
	str	q8, [sp, #3136]
	str	q13, [sp, #3152]
	add	x10, sp, #3136
	ldr	w10, [x10, x9]
	csinc	w15, w15, w6, eq
	mov	w11, #8                         ; =0x8
	csel	w10, w11, w10, ne
	str	q8, [sp, #3104]
	str	q13, [sp, #3120]
	add	x11, sp, #3104
	str	w10, [x11, x9]
	mov	w7, #23                         ; =0x17
	mov	w11, #22                        ; =0x16
	ldr	q13, [sp, #3120]
	ldr	q8, [sp, #3104]
LBB0_9:                                 ; %scheduler.dispatch.route.backedge
                                        ;   in Loop: Header=BB0_11 Depth=3
                                        ; kill: def $w6 killed $w6 killed $x6 def $x6
LBB0_10:                                ; %scheduler.dispatch.route.backedge
                                        ;   in Loop: Header=BB0_11 Depth=3
	lsl	w9, w12, w6
	cmp	w4, #0
	csel	w9, w9, wzr, ne
	orr	w14, w9, w14
	shl.8b	v1, v10, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x21, x13]
	str	w11, [x27, x13, lsl #2]
	str	w15, [x28, x13, lsl #2]
	add	x13, x13, #1
	fmov	d9, d11
LBB0_11:                                ; %scheduler.dispatch.route
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB0_123 Depth 4
                                        ;         Child Loop BB0_213 Depth 4
                                        ;         Child Loop BB0_295 Depth 4
                                        ;         Child Loop BB0_377 Depth 4
                                        ;         Child Loop BB0_459 Depth 4
                                        ;         Child Loop BB0_506 Depth 4
                                        ;         Child Loop BB0_529 Depth 4
                                        ;         Child Loop BB0_38 Depth 4
	cmp	w7, #23
	b.hi	LBB0_603
; %bb.12:                               ; %scheduler.dispatch.route
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov	w3, w7
Lloh8:
	adrp	x9, LJTI0_0@PAGE
Lloh9:
	add	x9, x9, LJTI0_0@PAGEOFF
	adr	x11, LBB0_13
	ldrh	w4, [x9, x3, lsl #1]
	add	x11, x11, x4, lsl #2
	br	x11
LBB0_13:                                ; %schedule.0
                                        ;   in Loop: Header=BB0_11 Depth=3
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	umaxv.8b	b1, v1
	mov	b3, v9[6]
	mov.b	v3[4], v9[7]
	fmov	w11, s1
	ushll.2d	v1, v3, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	ldr	q3, [sp, #128]                  ; 16-byte Folded Reload
	ldp	q4, q5, [sp, #688]              ; 32-byte Folded Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #688]                  ; 16-byte Folded Spill
	mov	b3, v9[4]
	mov.b	v3[4], v9[5]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q4, [sp, #96]                   ; 16-byte Folded Reload
	bit.16b	v5, v4, v3
	str	q5, [sp, #704]                  ; 16-byte Folded Spill
	mov	b4, v9[2]
	mov.b	v4[4], v9[3]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	ldr	q5, [sp, #112]                  ; 16-byte Folded Reload
	ldp	q6, q7, [sp, #720]              ; 32-byte Folded Reload
	bit.16b	v6, v5, v4
	str	q6, [sp, #720]                  ; 16-byte Folded Spill
	mov	b5, v9[0]
	mov.b	v5[4], v9[1]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	ldr	q6, [sp, #80]                   ; 16-byte Folded Reload
	bit.16b	v7, v6, v5
	str	q7, [sp, #736]                  ; 16-byte Folded Spill
	ldr	q6, [sp, #144]                  ; 16-byte Folded Reload
	ldr	q7, [sp, #784]                  ; 16-byte Folded Reload
	bit.16b	v7, v6, v1
	str	q7, [sp, #784]                  ; 16-byte Folded Spill
	ldr	q7, [sp, #800]                  ; 16-byte Folded Reload
	bit.16b	v7, v6, v3
	str	q7, [sp, #800]                  ; 16-byte Folded Spill
	ldr	q7, [sp, #816]                  ; 16-byte Folded Reload
	bit.16b	v7, v6, v4
	str	q7, [sp, #816]                  ; 16-byte Folded Spill
	ldr	q7, [sp, #832]                  ; 16-byte Folded Reload
	bit.16b	v7, v6, v5
	str	q7, [sp, #832]                  ; 16-byte Folded Spill
Lloh10:
	adrp	x9, lCPI0_4@PAGE
Lloh11:
	ldr	q6, [x9, lCPI0_4@PAGEOFF]
	ldr	q7, [sp, #1424]                 ; 16-byte Folded Reload
	bit.16b	v7, v6, v1
	str	q7, [sp, #1424]                 ; 16-byte Folded Spill
Lloh12:
	adrp	x9, lCPI0_5@PAGE
Lloh13:
	ldr	q6, [x9, lCPI0_5@PAGEOFF]
	ldr	q7, [sp, #1440]                 ; 16-byte Folded Reload
	bit.16b	v7, v6, v3
	str	q7, [sp, #1440]                 ; 16-byte Folded Spill
Lloh14:
	adrp	x9, lCPI0_6@PAGE
Lloh15:
	ldr	q6, [x9, lCPI0_6@PAGEOFF]
	ldr	q7, [sp, #1456]                 ; 16-byte Folded Reload
	bit.16b	v7, v6, v4
	str	q7, [sp, #1456]                 ; 16-byte Folded Spill
Lloh16:
	adrp	x9, lCPI0_7@PAGE
Lloh17:
	ldr	q6, [x9, lCPI0_7@PAGEOFF]
	ldr	q7, [sp, #1472]                 ; 16-byte Folded Reload
	bit.16b	v7, v6, v5
	str	q7, [sp, #1472]                 ; 16-byte Folded Spill
	ldr	q6, [sp, #1360]                 ; 16-byte Folded Reload
	bic.16b	v6, v6, v1
	str	q6, [sp, #1360]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #1376]                 ; 16-byte Folded Reload
	bic.16b	v1, v1, v3
	str	q1, [sp, #1376]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #1392]                 ; 16-byte Folded Reload
	bic.16b	v1, v1, v4
	str	q1, [sp, #1392]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #1408]                 ; 16-byte Folded Reload
	bic.16b	v1, v1, v5
	str	q1, [sp, #1408]                 ; 16-byte Folded Spill
	tbnz	w11, #0, LBB0_75
	b	LBB0_5
LBB0_14:                                ; %scheduler.dispatch.route.schedule.13_crit_edge
                                        ;   in Loop: Header=BB0_11 Depth=3
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	umaxv.8b	b1, v1
	fmov	w11, s1
	eor	w4, w11, #0x1
	b	LBB0_309
LBB0_15:                                ; %schedule.18
                                        ;   in Loop: Header=BB0_11 Depth=3
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	ldr	q1, [sp, #272]                  ; 16-byte Folded Reload
	shl.2d	v3, v1, #2
	ldr	x9, [sp, #216]                  ; 8-byte Folded Reload
	dup.2d	v1, x9
	add.2d	v3, v1, v3
	tbnz	w11, #0, LBB0_52
; %bb.16:                               ; %else4400
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #1, LBB0_53
LBB0_17:                                ; %else4403
                                        ;   in Loop: Header=BB0_11 Depth=3
	ldr	q3, [sp, #256]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v3, v1, v3
	tbnz	w11, #2, LBB0_54
LBB0_18:                                ; %else4406
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #3, LBB0_55
LBB0_19:                                ; %else4409
                                        ;   in Loop: Header=BB0_11 Depth=3
	ldr	q3, [sp, #240]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v3, v1, v3
	tbnz	w11, #4, LBB0_56
LBB0_20:                                ; %else4412
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #5, LBB0_57
LBB0_21:                                ; %else4415
                                        ;   in Loop: Header=BB0_11 Depth=3
	ldr	q3, [sp, #224]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v1, v1, v3
	tbnz	w11, #6, LBB0_58
LBB0_22:                                ; %else4418
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #7, LBB0_59
LBB0_23:                                ; %else4421
                                        ;   in Loop: Header=BB0_11 Depth=3
	tst	w11, #0xff
	b.ne	LBB0_504
	b	LBB0_5
LBB0_24:                                ; %scheduler.dispatch.route.schedule.10_crit_edge
                                        ;   in Loop: Header=BB0_11 Depth=3
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	umaxv.8b	b1, v1
	fmov	w11, s1
	eor	w4, w11, #0x1
	b	LBB0_227
LBB0_25:                                ; %scheduler.dispatch.route.schedule.16_crit_edge
                                        ;   in Loop: Header=BB0_11 Depth=3
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	umaxv.8b	b1, v1
	fmov	w11, s1
	eor	w4, w11, #0x1
	b	LBB0_391
LBB0_26:                                ; %schedule.3
                                        ;   in Loop: Header=BB0_11 Depth=3
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	ldr	q1, [sp, #352]                  ; 16-byte Folded Reload
	shl.2d	v1, v1, #2
	ldr	x9, [sp, #168]                  ; 8-byte Folded Reload
	dup.2d	v4, x9
	add.2d	v5, v4, v1
	movi.2d	v1, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w11, #0, LBB0_60
; %bb.27:                               ; %else
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #1, LBB0_61
LBB0_28:                                ; %else3594
                                        ;   in Loop: Header=BB0_11 Depth=3
	ldr	q5, [sp, #336]                  ; 16-byte Folded Reload
	shl.2d	v5, v5, #2
	add.2d	v5, v4, v5
	tbnz	w11, #2, LBB0_62
LBB0_29:                                ; %else3597
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #3, LBB0_63
LBB0_30:                                ; %else3600
                                        ;   in Loop: Header=BB0_11 Depth=3
	ldr	q5, [sp, #320]                  ; 16-byte Folded Reload
	shl.2d	v5, v5, #2
	add.2d	v5, v4, v5
	tbnz	w11, #4, LBB0_64
LBB0_31:                                ; %else3603
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #5, LBB0_65
LBB0_32:                                ; %else3606
                                        ;   in Loop: Header=BB0_11 Depth=3
	ldr	q5, [sp, #304]                  ; 16-byte Folded Reload
	shl.2d	v5, v5, #2
	add.2d	v4, v4, v5
	tbnz	w11, #6, LBB0_66
LBB0_33:                                ; %else3609
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbz	w11, #7, LBB0_35
LBB0_34:                                ; %cond.load3611
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v4[1]
	ld1.s	{ v3 }[3], [x9]
LBB0_35:                                ; %else3612
                                        ;   in Loop: Header=BB0_11 Depth=3
	zip2.8b	v4, v9, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q5, [sp, #944]                  ; 16-byte Folded Reload
	bit.16b	v5, v3, v4
	zip1.8b	v3, v9, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q4, [sp, #960]                  ; 16-byte Folded Reload
	bit.16b	v4, v1, v3
	stp	q5, q4, [sp, #944]              ; 32-byte Folded Spill
	tst	w11, #0xff
	b.eq	LBB0_5
LBB0_36:                                ; %schedule.4
                                        ;   in Loop: Header=BB0_11 Depth=3
	cbz	w15, LBB0_101
LBB0_37:                                ; %convergence.cascade.preheader
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov	w11, #0                         ; =0x0
LBB0_38:                                ; %convergence.cascade
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_11 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w9, s3
	umaxv.8b	b1, v1
	fmov	w10, s1
	sub	w16, w15, #1
	tst	w9, #0xff
	csel	w4, w16, wzr, ne
	lsl	w6, w12, w4
	and	w9, w6, w14
	tst	w9, #0xff
	cset	w9, ne
	str	q8, [sp, #2112]
	str	q13, [sp, #2128]
	ubfiz	x3, x4, #2, #3
	ldr	w16, [x17, x3]
	cmp	w16, #1
	cset	w7, eq
	and	w23, w9, w10
	ldrb	w9, [x5, w4, sxtw]
	and	w10, w9, #0x1
	fmov	s1, w10
	ubfx	w10, w9, #1, #1
	mov.b	v1[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v1[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v1[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v1[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v1[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v1[6], w10
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, w4, sxtw]
	and	w10, w9, #0x1
	fmov	s3, w10
	ubfx	w10, w9, #1, #1
	mov.b	v3[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v3[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v3[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v3[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v3[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v3[6], w10
	lsr	w9, w9, #7
	mov.b	v3[7], w9
	orr.8b	v4, v9, v3
	ldr	d0, [sp, #1752]                 ; 8-byte Folded Reload
	and.8b	v5, v0, v1
	eor.8b	v5, v5, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	umaxv.8b	b5, v5
	fmov	w9, s5
	ands	w10, w23, w7
	csetm	w16, ne
	bics	w9, w10, w9
	csetm	w2, ne
	dup.8b	v5, w2
	dup.8b	v6, w16
	bic.8b	v7, v4, v5
	bit.8b	v3, v7, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w4, sxtw]
	bic.8b	v1, v1, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x5, w4, sxtw]
	csinv	w16, w0, w6, eq
	dup.8b	v1, w10
	and	w14, w16, w14
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w9
	and.8b	v3, v3, v4
	str	q12, [sp, #2080]
	str	q19, [sp, #2096]
	ldr	w9, [x1, x3]
	csel	w15, w9, w15, ne
	bit.8b	v9, v3, v1
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w3, s1
	cmp	w10, #1
	b.ne	LBB0_102
; %bb.39:                               ; %convergence.cascade
                                        ;   in Loop: Header=BB0_38 Depth=4
	cmp	w15, #0
	ccmp	w11, #6, #2, ne
	b.hi	LBB0_102
; %bb.40:                               ; %convergence.cascade
                                        ;   in Loop: Header=BB0_38 Depth=4
	add	w11, w11, #1
	tst	w3, #0xff
	b.ne	LBB0_38
	b	LBB0_102
LBB0_41:                                ; %scheduler.dispatch.route.schedule.2_crit_edge
                                        ;   in Loop: Header=BB0_11 Depth=3
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	umaxv.8b	b1, v1
	fmov	w11, s1
	eor	w11, w11, #0x1
	b	LBB0_83
LBB0_42:                                ; %scheduler.dispatch.route.schedule.7_crit_edge
                                        ;   in Loop: Header=BB0_11 Depth=3
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	umaxv.8b	b1, v1
	fmov	w11, s1
	eor	w4, w11, #0x1
	b	LBB0_145
LBB0_43:                                ; %schedule.20
                                        ;   in Loop: Header=BB0_11 Depth=3
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	ldr	q1, [sp, #592]                  ; 16-byte Folded Reload
	shl.2d	v3, v1, #2
	ldr	x9, [sp, #216]                  ; 8-byte Folded Reload
	dup.2d	v1, x9
	add.2d	v3, v1, v3
	tbnz	w11, #0, LBB0_67
; %bb.44:                               ; %else4426
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #1, LBB0_68
LBB0_45:                                ; %else4430
                                        ;   in Loop: Header=BB0_11 Depth=3
	ldr	q3, [sp, #576]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v3, v1, v3
	tbnz	w11, #2, LBB0_69
LBB0_46:                                ; %else4434
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #3, LBB0_70
LBB0_47:                                ; %else4438
                                        ;   in Loop: Header=BB0_11 Depth=3
	ldr	q3, [sp, #560]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v3, v1, v3
	tbnz	w11, #4, LBB0_71
LBB0_48:                                ; %else4442
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #5, LBB0_72
LBB0_49:                                ; %else4446
                                        ;   in Loop: Header=BB0_11 Depth=3
	ldr	q3, [sp, #544]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v1, v1, v3
	tbnz	w11, #6, LBB0_73
LBB0_50:                                ; %else4450
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #7, LBB0_74
LBB0_51:                                ; %else4454
                                        ;   in Loop: Header=BB0_11 Depth=3
	tst	w11, #0xff
	b.ne	LBB0_527
	b	LBB0_5
LBB0_52:                                ; %cond.store
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d3
	ldr	q4, [sp, #464]                  ; 16-byte Folded Reload
	str	s4, [x9]
	tbz	w11, #1, LBB0_17
LBB0_53:                                ; %cond.store4401
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v3[1]
	ldr	q3, [sp, #464]                  ; 16-byte Folded Reload
	st1.s	{ v3 }[1], [x9]
	ldr	q3, [sp, #256]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v3, v1, v3
	tbz	w11, #2, LBB0_18
LBB0_54:                                ; %cond.store4404
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d3
	ldr	q4, [sp, #464]                  ; 16-byte Folded Reload
	st1.s	{ v4 }[2], [x9]
	tbz	w11, #3, LBB0_19
LBB0_55:                                ; %cond.store4407
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v3[1]
	ldr	q3, [sp, #464]                  ; 16-byte Folded Reload
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #240]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v3, v1, v3
	tbz	w11, #4, LBB0_20
LBB0_56:                                ; %cond.store4410
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d3
	ldr	q4, [sp, #448]                  ; 16-byte Folded Reload
	str	s4, [x9]
	tbz	w11, #5, LBB0_21
LBB0_57:                                ; %cond.store4413
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v3[1]
	ldr	q3, [sp, #448]                  ; 16-byte Folded Reload
	st1.s	{ v3 }[1], [x9]
	ldr	q3, [sp, #224]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v1, v1, v3
	tbz	w11, #6, LBB0_22
LBB0_58:                                ; %cond.store4416
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d1
	ldr	q3, [sp, #448]                  ; 16-byte Folded Reload
	st1.s	{ v3 }[2], [x9]
	tbz	w11, #7, LBB0_23
LBB0_59:                                ; %cond.store4419
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v1[1]
	ldr	q1, [sp, #448]                  ; 16-byte Folded Reload
	st1.s	{ v1 }[3], [x9]
	tst	w11, #0xff
	b.ne	LBB0_504
	b	LBB0_5
LBB0_60:                                ; %cond.load
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d5
	ldr	s1, [x9]
	tbz	w11, #1, LBB0_28
LBB0_61:                                ; %cond.load3593
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v5[1]
	ld1.s	{ v1 }[1], [x9]
	ldr	q5, [sp, #336]                  ; 16-byte Folded Reload
	shl.2d	v5, v5, #2
	add.2d	v5, v4, v5
	tbz	w11, #2, LBB0_29
LBB0_62:                                ; %cond.load3596
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d5
	ld1.s	{ v1 }[2], [x9]
	tbz	w11, #3, LBB0_30
LBB0_63:                                ; %cond.load3599
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v5[1]
	ld1.s	{ v1 }[3], [x9]
	ldr	q5, [sp, #320]                  ; 16-byte Folded Reload
	shl.2d	v5, v5, #2
	add.2d	v5, v4, v5
	tbz	w11, #4, LBB0_31
LBB0_64:                                ; %cond.load3602
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d5
	ld1.s	{ v3 }[0], [x9]
	tbz	w11, #5, LBB0_32
LBB0_65:                                ; %cond.load3605
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v5[1]
	ld1.s	{ v3 }[1], [x9]
	ldr	q5, [sp, #304]                  ; 16-byte Folded Reload
	shl.2d	v5, v5, #2
	add.2d	v4, v4, v5
	tbz	w11, #6, LBB0_33
LBB0_66:                                ; %cond.load3608
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d4
	ld1.s	{ v3 }[2], [x9]
	tbnz	w11, #7, LBB0_34
	b	LBB0_35
LBB0_67:                                ; %cond.store4423
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d3
	ldr	q4, [sp, #640]                  ; 16-byte Folded Reload
	str	s4, [x9]
	tbz	w11, #1, LBB0_45
LBB0_68:                                ; %cond.store4427
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v3[1]
	ldr	q3, [sp, #640]                  ; 16-byte Folded Reload
	st1.s	{ v3 }[1], [x9]
	ldr	q3, [sp, #576]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v3, v1, v3
	tbz	w11, #2, LBB0_46
LBB0_69:                                ; %cond.store4431
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d3
	ldr	q4, [sp, #640]                  ; 16-byte Folded Reload
	st1.s	{ v4 }[2], [x9]
	tbz	w11, #3, LBB0_47
LBB0_70:                                ; %cond.store4435
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v3[1]
	ldr	q3, [sp, #640]                  ; 16-byte Folded Reload
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #560]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v3, v1, v3
	tbz	w11, #4, LBB0_48
LBB0_71:                                ; %cond.store4439
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d3
	ldr	q4, [sp, #624]                  ; 16-byte Folded Reload
	str	s4, [x9]
	tbz	w11, #5, LBB0_49
LBB0_72:                                ; %cond.store4443
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v3[1]
	ldr	q3, [sp, #624]                  ; 16-byte Folded Reload
	st1.s	{ v3 }[1], [x9]
	ldr	q3, [sp, #544]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v1, v1, v3
	tbz	w11, #6, LBB0_50
LBB0_73:                                ; %cond.store4447
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d1
	ldr	q3, [sp, #624]                  ; 16-byte Folded Reload
	st1.s	{ v3 }[2], [x9]
	tbz	w11, #7, LBB0_51
LBB0_74:                                ; %cond.store4451
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v1[1]
	ldr	q1, [sp, #624]                  ; 16-byte Folded Reload
	st1.s	{ v1 }[3], [x9]
	tst	w11, #0xff
	b.ne	LBB0_527
	b	LBB0_5
LBB0_75:                                ; %schedule.1
                                        ;   in Loop: Header=BB0_11 Depth=3
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w3, s1
	mov	w9, #260                        ; =0x104
	dup.2d	v1, x9
	ldr	q7, [sp, #1392]                 ; 16-byte Folded Reload
	cmgt.2d	v3, v1, v7
	ldr	q6, [sp, #1408]                 ; 16-byte Folded Reload
	cmgt.2d	v4, v1, v6
	uzp1.4s	v3, v4, v3
	ldr	q16, [sp, #1376]                ; 16-byte Folded Reload
	cmgt.2d	v4, v1, v16
	ldr	q17, [sp, #1360]                ; 16-byte Folded Reload
	cmgt.2d	v5, v1, v17
	uzp1.4s	v4, v4, v5
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v10, v9, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w11, s4
	umaxv.8b	b3, v3
	fmov	w4, s3
	tbz	w4, #0, LBB0_81
; %bb.76:                               ; %schedule.1
                                        ;   in Loop: Header=BB0_11 Depth=3
	cmge.2d	v3, v7, v1
	cmge.2d	v4, v6, v1
	uzp1.4s	v3, v4, v3
	cmge.2d	v4, v16, v1
	cmge.2d	v1, v17, v1
	uzp1.4s	v1, v4, v1
	uzp1.8h	v1, v3, v1
	xtn.8b	v1, v1
	and.8b	v11, v9, v1
	shl.8b	v1, v11, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w4, s1
	tst	w4, #0xff
	b.eq	LBB0_81
; %bb.77:                               ; %varying.divergent
                                        ;   in Loop: Header=BB0_11 Depth=3
	subs	w9, w15, #1
	csel	w9, wzr, w9, lo
	and	w10, w14, #0xff
	lsr	w11, w10, w9
	tst	w11, #0x1
	str	q8, [sp, #1888]
	str	q13, [sp, #1904]
	and	x9, x9, #0x7
	add	x11, sp, #1888
	ldr	w9, [x11, x9, lsl #2]
	ccmp	w15, #0, #4, ne
	ccmp	w9, #0, #0, ne
	cset	w4, ne
	cmp	w10, #255
	b.ne	LBB0_79
; %bb.78:                               ; %varying.divergent
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w4, #0, LBB0_603
LBB0_79:                                ; %convergence.overflow.resume
                                        ;   in Loop: Header=BB0_11 Depth=3
	mvn	w9, w14
	rbit	w9, w9
	clz	w9, w9
	mov	w10, #255                       ; =0xff
	bics	wzr, w10, w14
	csel	w6, wzr, w9, eq
	ldrb	w9, [x5, w6, uxtw]
	and	w10, w9, #0x1
	fmov	s1, w10
	ubfx	w10, w9, #1, #1
	mov.b	v1[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v1[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v1[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v1[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v1[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v1[6], w10
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, w6, uxtw]
	and	w10, w9, #0x1
	fmov	s3, w10
	ubfx	w10, w9, #1, #1
	mov.b	v3[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v3[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v3[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v3[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v3[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v3[6], w10
	lsr	w9, w9, #7
	mov.b	v3[7], w9
	cmp	w4, #0
	csetm	w9, ne
	dup.8b	v4, w9
	bit.8b	v1, v9, v4
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x5, w6, uxtw]
	bic.8b	v1, v3, v4
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x8, w6, uxtw]
	cmp	x13, #8
	b.hs	LBB0_603
; %bb.80:                               ; %ready.overflow.resume53
                                        ;   in Loop: Header=BB0_11 Depth=3
	str	q12, [sp, #1856]
	str	q19, [sp, #1872]
	ubfiz	x9, x6, #2, #3
	add	x10, sp, #1856
	ldr	w10, [x10, x9]
	cmp	w4, #0
	csel	w10, w15, w10, ne
	str	q12, [sp, #1824]
	str	q19, [sp, #1840]
	add	x11, sp, #1824
	str	w10, [x11, x9]
	ldr	q19, [sp, #1840]
	ldr	q12, [sp, #1824]
	str	q8, [sp, #1792]
	str	q13, [sp, #1808]
	add	x10, sp, #1792
	ldr	w10, [x10, x9]
	csel	w10, wzr, w10, ne
	str	q8, [sp, #1760]
	str	q13, [sp, #1776]
	add	x11, sp, #1760
	str	w10, [x11, x9]
	csinc	w15, w15, w6, eq
	mov	w7, #5                          ; =0x5
	mov	w11, #2                         ; =0x2
	ldr	q13, [sp, #1776]
	ldr	q8, [sp, #1760]
	b	LBB0_10
LBB0_81:                                ; %varying.coherent
                                        ;   in Loop: Header=BB0_11 Depth=3
	tst	w11, #0xff
	b.eq	LBB0_120
; %bb.82:                               ; %varying.coherent.true
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov	w11, #0                         ; =0x0
	tst	w3, #0xff
	b.eq	LBB0_5
LBB0_83:                                ; %schedule.2
                                        ;   in Loop: Header=BB0_11 Depth=3
	str	q21, [sp, #1520]                ; 16-byte Folded Spill
	str	q31, [sp, #1584]                ; 16-byte Folded Spill
	str	q14, [sp, #1728]                ; 16-byte Folded Spill
	str	q23, [sp, #1696]                ; 16-byte Folded Spill
	str	q28, [sp, #1504]                ; 16-byte Folded Spill
	mov.16b	v15, v26
	mov.16b	v31, v25
	mov.16b	v30, v22
	mov	b1, v9[0]
	mov.b	v1[4], v9[1]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	ldr	q3, [sp, #1408]                 ; 16-byte Folded Reload
	and.16b	v6, v1, v3
	mov	b3, v9[2]
	mov.b	v3[4], v9[3]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	mov	b4, v9[4]
	mov.b	v4[4], v9[5]
	ldr	q5, [sp, #1392]                 ; 16-byte Folded Reload
	and.16b	v7, v3, v5
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	ldr	q5, [sp, #1376]                 ; 16-byte Folded Reload
	and.16b	v16, v4, v5
	mov	b5, v9[6]
	mov.b	v5[4], v9[7]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	ldr	q17, [sp, #1360]                ; 16-byte Folded Reload
	and.16b	v17, v5, v17
	mov	w9, #65                         ; =0x41
	dup.2d	v21, x9
	and.16b	v18, v1, v21
	mvn.16b	v20, v1
	sub.2d	v18, v18, v20
	and.16b	v20, v3, v21
	mvn.16b	v22, v3
	sub.2d	v20, v20, v22
	and.16b	v22, v4, v21
	mvn.16b	v23, v4
	sub.2d	v22, v22, v23
	and.16b	v21, v5, v21
	mvn.16b	v23, v5
	sub.2d	v21, v21, v23
	mov.d	x3, v21[1]
	mov.d	x4, v17[1]
	sdiv	x4, x4, x3
	fmov	x6, d21
	fmov	x7, d17
	sdiv	x7, x7, x6
	mul	x6, x7, x6
	fmov	d21, x7
	mov.d	v21[1], x4
	mov.d	x7, v22[1]
	mov.d	x23, v16[1]
	sdiv	x23, x23, x7
	fmov	x19, d22
	fmov	x20, d16
	sdiv	x20, x20, x19
	mul	x19, x20, x19
	fmov	d22, x20
	mov.d	v22[1], x23
	mov.d	x20, v20[1]
	mov.d	x25, v7[1]
	sdiv	x25, x25, x20
	fmov	x26, d20
	fmov	x16, d7
	sdiv	x16, x16, x26
	mul	x26, x16, x26
	fmov	d20, x16
	mov.d	v20[1], x25
	mov.d	x16, v18[1]
	mov.d	x9, v6[1]
	fmov	x22, d18
	fmov	x2, d6
	sdiv	x2, x2, x22
	mul	x22, x2, x22
	fmov	d18, x2
	sdiv	x9, x9, x16
	mov.d	v18[1], x9
	mul	x9, x9, x16
	fmov	d23, x22
	mov.d	v23[1], x9
	mul	x9, x25, x20
	fmov	d24, x26
	mov.d	v24[1], x9
	mul	x9, x23, x7
	fmov	d25, x19
	mov.d	v25[1], x9
	mul	x9, x4, x3
	fmov	d26, x6
	mov.d	v26[1], x9
	sub.2d	v26, v17, v26
	sub.2d	v25, v16, v25
	sub.2d	v24, v7, v24
	sub.2d	v23, v6, v23
	ldp	q7, q6, [sp, #720]              ; 32-byte Folded Reload
	add.2d	v6, v18, v6
	add.2d	v7, v20, v7
	ldp	q16, q0, [sp, #688]             ; 32-byte Folded Reload
	add.2d	v17, v22, v0
	add.2d	v18, v21, v16
	mov	w9, #17                         ; =0x11
	dup.2d	v16, x9
	cmhi.2d	v20, v16, v18
	cmhi.2d	v21, v16, v17
	uzp1.4s	v20, v21, v20
	cmhi.2d	v21, v16, v7
	cmhi.2d	v22, v16, v6
	uzp1.4s	v21, v22, v21
	uzp1.8h	v20, v21, v20
	xtn.8b	v20, v20
	fmov	x9, d18
	add	x9, x9, x9, lsl #6
	fmov	d21, x9
	mov.d	x9, v18[1]
	add	x9, x9, x9, lsl #6
	mov.d	v21[1], x9
	fmov	x9, d17
	add	x9, x9, x9, lsl #6
	mov.d	x16, v17[1]
	fmov	d22, x9
	add	x9, x16, x16, lsl #6
	mov.d	v22[1], x9
	fmov	x9, d7
	add	x9, x9, x9, lsl #6
	fmov	d27, x9
	mov.d	x9, v7[1]
	add	x9, x9, x9, lsl #6
	mov.d	v27[1], x9
	fmov	x9, d6
	add	x9, x9, x9, lsl #6
	fmov	d28, x9
	mov.d	x9, v6[1]
	add	x9, x9, x9, lsl #6
	mov.d	v28[1], x9
	add.2d	v23, v28, v23
	add.2d	v24, v27, v24
	add.2d	v22, v22, v25
	add.2d	v21, v21, v26
	ldr	q25, [sp, #304]                 ; 16-byte Folded Reload
	bit.16b	v25, v21, v5
	ldr	q5, [sp, #320]                  ; 16-byte Folded Reload
	bit.16b	v5, v22, v4
	stp	q25, q5, [sp, #304]             ; 32-byte Folded Spill
	ldr	q4, [sp, #336]                  ; 16-byte Folded Reload
	bit.16b	v4, v24, v3
	ldr	q3, [sp, #352]                  ; 16-byte Folded Reload
	bit.16b	v3, v23, v1
	stp	q4, q3, [sp, #336]              ; 32-byte Folded Spill
	and.8b	v10, v9, v20
	shl.8b	v1, v10, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w3, s3
	umaxv.8b	b1, v1
	fmov	w9, s1
	tbz	w9, #0, LBB0_89
; %bb.84:                               ; %schedule.2
                                        ;   in Loop: Header=BB0_11 Depth=3
	cmhs.2d	v1, v18, v16
	cmhs.2d	v3, v17, v16
	uzp1.4s	v1, v3, v1
	cmhs.2d	v3, v7, v16
	cmhs.2d	v4, v6, v16
	uzp1.4s	v3, v4, v3
	uzp1.8h	v1, v3, v1
	xtn.8b	v1, v1
	and.8b	v11, v9, v1
	shl.8b	v1, v11, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w9, s1
	tst	w9, #0xff
	b.eq	LBB0_89
; %bb.85:                               ; %varying.divergent56
                                        ;   in Loop: Header=BB0_11 Depth=3
	subs	w9, w15, #1
	csel	w9, wzr, w9, lo
	and	w10, w14, #0xff
	lsr	w11, w10, w9
	tst	w11, #0x1
	str	q8, [sp, #2048]
	str	q13, [sp, #2064]
	and	x9, x9, #0x7
	add	x11, sp, #2048
	ldr	w9, [x11, x9, lsl #2]
	ccmp	w15, #0, #4, ne
	ccmp	w9, #1, #0, ne
	cset	w4, ne
	cmp	w10, #255
	b.ne	LBB0_87
; %bb.86:                               ; %varying.divergent56
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w4, #0, LBB0_603
LBB0_87:                                ; %convergence.overflow.resume59
                                        ;   in Loop: Header=BB0_11 Depth=3
	mvn	w9, w14
	rbit	w9, w9
	clz	w9, w9
	mov	w10, #255                       ; =0xff
	bics	wzr, w10, w14
	csel	w6, wzr, w9, eq
	ldrb	w9, [x5, w6, uxtw]
	and	w10, w9, #0x1
	fmov	s1, w10
	ubfx	w10, w9, #1, #1
	mov.b	v1[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v1[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v1[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v1[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v1[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v1[6], w10
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, w6, uxtw]
	and	w10, w9, #0x1
	fmov	s3, w10
	ubfx	w10, w9, #1, #1
	mov.b	v3[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v3[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v3[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v3[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v3[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v3[6], w10
	lsr	w9, w9, #7
	mov.b	v3[7], w9
	cmp	w4, #0
	csetm	w9, ne
	dup.8b	v4, w9
	bit.8b	v1, v9, v4
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x5, w6, uxtw]
	bic.8b	v1, v3, v4
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x8, w6, uxtw]
	cmp	x13, #8
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #560
	add	x20, sp, #1, lsl #12            ; =4096
	add	x20, x20, #528
	add	x22, sp, #1, lsl #12            ; =4096
	add	x22, x22, #240
	add	x25, sp, #1, lsl #12            ; =4096
	add	x25, x25, #208
	add	x26, sp, #3952
	ldr	q23, [sp, #1696]                ; 16-byte Folded Reload
	ldr	q14, [sp, #1728]                ; 16-byte Folded Reload
	b.hs	LBB0_603
; %bb.88:                               ; %ready.overflow.resume61
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.16b	v22, v30
	mov.16b	v4, v31
	mov.16b	v26, v15
	zip2.8b	v1, v11, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	ldp	q6, q3, [sp, #944]              ; 32-byte Folded Reload
	and.16b	v5, v1, v6
	zip1.8b	v1, v11, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	and.16b	v3, v1, v3
	stp	q5, q3, [sp, #944]              ; 32-byte Folded Spill
	str	q12, [sp, #2016]
	str	q19, [sp, #2032]
	ubfiz	x9, x6, #2, #3
	add	x10, sp, #2016
	ldr	w10, [x10, x9]
	cmp	w4, #0
	csel	w10, w15, w10, ne
	str	q12, [sp, #1984]
	str	q19, [sp, #2000]
	add	x11, sp, #1984
	str	w10, [x11, x9]
	ldr	q19, [sp, #2000]
	ldr	q12, [sp, #1984]
	str	q8, [sp, #1952]
	str	q13, [sp, #1968]
	add	x10, sp, #1952
	ldr	w10, [x10, x9]
	csinc	w15, w15, w6, eq
	csinc	w10, w10, wzr, eq
	str	q8, [sp, #1920]
	str	q13, [sp, #1936]
	add	x11, sp, #1920
	str	w10, [x11, x9]
	mov	w7, #4                          ; =0x4
	mov	w11, #3                         ; =0x3
	ldr	q13, [sp, #1936]
	ldr	q8, [sp, #1920]
                                        ; kill: def $w6 killed $w6 killed $x6 def $x6
	ldr	q28, [sp, #1504]                ; 16-byte Folded Reload
	ldr	q31, [sp, #1584]                ; 16-byte Folded Reload
	ldr	q21, [sp, #1520]                ; 16-byte Folded Reload
	mov.16b	v25, v4
	b	LBB0_10
LBB0_89:                                ; %varying.coherent57
                                        ;   in Loop: Header=BB0_11 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_126
; %bb.90:                               ; %varying.coherent.true62
                                        ;   in Loop: Header=BB0_11 Depth=3
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #560
	add	x20, sp, #1, lsl #12            ; =4096
	add	x20, x20, #528
	add	x22, sp, #1, lsl #12            ; =4096
	add	x22, x22, #240
	add	x25, sp, #1, lsl #12            ; =4096
	add	x25, x25, #208
	add	x26, sp, #3952
	mov.16b	v22, v30
	mov.16b	v17, v31
	mov.16b	v26, v15
	ldr	q23, [sp, #1696]                ; 16-byte Folded Reload
	ldr	q14, [sp, #1728]                ; 16-byte Folded Reload
	tbnz	w11, #0, LBB0_555
; %bb.91:                               ; %schedule.3.thread
                                        ;   in Loop: Header=BB0_11 Depth=3
	ldp	q1, q3, [sp, #304]              ; 32-byte Folded Reload
	shl.2d	v1, v1, #2
	shl.2d	v3, v3, #2
	ldp	q4, q5, [sp, #336]              ; 32-byte Folded Reload
	shl.2d	v4, v4, #2
	ldr	x9, [sp, #168]                  ; 8-byte Folded Reload
	dup.2d	v16, x9
	shl.2d	v5, v5, #2
	add.2d	v7, v16, v5
	add.2d	v6, v16, v4
	add.2d	v5, v16, v3
	add.2d	v4, v16, v1
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	movi.2d	v1, #0000000000000000
	movi.2d	v3, #0000000000000000
	ldr	q28, [sp, #1504]                ; 16-byte Folded Reload
	ldr	q31, [sp, #1584]                ; 16-byte Folded Reload
	ldr	q21, [sp, #1520]                ; 16-byte Folded Reload
	tbnz	w11, #0, LBB0_130
; %bb.92:                               ; %else4493
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.16b	v25, v17
	tbnz	w11, #1, LBB0_131
LBB0_93:                                ; %else4499
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #2, LBB0_132
LBB0_94:                                ; %else4505
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #3, LBB0_133
LBB0_95:                                ; %else4511
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #4, LBB0_134
LBB0_96:                                ; %else4517
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #5, LBB0_135
LBB0_97:                                ; %else4523
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #6, LBB0_136
LBB0_98:                                ; %else4529
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbz	w11, #7, LBB0_100
LBB0_99:                                ; %cond.load4531
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v4[1]
	ld1.s	{ v3 }[3], [x9]
LBB0_100:                               ; %else4535
                                        ;   in Loop: Header=BB0_11 Depth=3
	zip2.8b	v4, v9, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q5, [sp, #944]                  ; 16-byte Folded Reload
	bit.16b	v5, v3, v4
	zip1.8b	v3, v9, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q4, [sp, #960]                  ; 16-byte Folded Reload
	bit.16b	v4, v1, v3
	stp	q5, q4, [sp, #944]              ; 32-byte Folded Spill
	cbnz	w15, LBB0_37
LBB0_101:                               ; %schedule.4.convergence.cascade.exit_crit_edge
                                        ;   in Loop: Header=BB0_11 Depth=3
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w3, s1
LBB0_102:                               ; %convergence.cascade.exit
                                        ;   in Loop: Header=BB0_11 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
; %bb.103:                              ; %convergence.target.4.ready
                                        ;   in Loop: Header=BB0_11 Depth=3
	ldr	q1, [sp, #1408]                 ; 16-byte Folded Reload
	shl.2d	v1, v1, #5
	ldr	q3, [sp, #1392]                 ; 16-byte Folded Reload
	shl.2d	v3, v3, #5
	ldr	q4, [sp, #1376]                 ; 16-byte Folded Reload
	shl.2d	v6, v4, #5
	ldr	q4, [sp, #1360]                 ; 16-byte Folded Reload
	shl.2d	v7, v4, #5
	ldr	q4, [sp, #832]                  ; 16-byte Folded Reload
	ldr	q5, [sp, #1472]                 ; 16-byte Folded Reload
	add.2d	v4, v4, v5
	add.2d	v5, v4, v1
	ldr	q1, [sp, #816]                  ; 16-byte Folded Reload
	ldr	q4, [sp, #1456]                 ; 16-byte Folded Reload
	add.2d	v1, v1, v4
	add.2d	v4, v1, v3
	ldr	q1, [sp, #800]                  ; 16-byte Folded Reload
	ldr	q3, [sp, #1440]                 ; 16-byte Folded Reload
	add.2d	v1, v1, v3
	add.2d	v3, v1, v6
	ldr	q1, [sp, #784]                  ; 16-byte Folded Reload
	ldr	q6, [sp, #1424]                 ; 16-byte Folded Reload
	add.2d	v1, v1, v6
	add.2d	v1, v1, v7
	shl.8b	v6, v9, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	fmov	w11, s6
	tbnz	w11, #0, LBB0_113
; %bb.104:                              ; %else4541
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #1, LBB0_114
LBB0_105:                               ; %else4545
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #2, LBB0_115
LBB0_106:                               ; %else4549
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #3, LBB0_116
LBB0_107:                               ; %else4553
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #4, LBB0_117
LBB0_108:                               ; %else4557
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #5, LBB0_118
LBB0_109:                               ; %else4561
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #6, LBB0_119
LBB0_110:                               ; %else4565
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbz	w11, #7, LBB0_112
LBB0_111:                               ; %cond.store4566
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v1[1]
	ldr	q1, [sp, #944]                  ; 16-byte Folded Reload
	st1.s	{ v1 }[3], [x9]
LBB0_112:                               ; %else4569
                                        ;   in Loop: Header=BB0_11 Depth=3
	movi.8b	v1, #1
	and.8b	v1, v9, v1
	ushll.8h	v1, v1, #0
	ushll.4s	v3, v1, #0
	ushll2.4s	v1, v1, #0
	ldr	q4, [sp, #1360]                 ; 16-byte Folded Reload
	uaddw2.2d	v4, v4, v1
	str	q4, [sp, #1360]                 ; 16-byte Folded Spill
	ldr	q4, [sp, #1376]                 ; 16-byte Folded Reload
	uaddw.2d	v4, v4, v1
	str	q4, [sp, #1376]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #1392]                 ; 16-byte Folded Reload
	uaddw2.2d	v1, v1, v3
	str	q1, [sp, #1392]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #1408]                 ; 16-byte Folded Reload
	uaddw.2d	v1, v1, v3
	str	q1, [sp, #1408]                 ; 16-byte Folded Spill
	b	LBB0_75
LBB0_113:                               ; %cond.store4538
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d5
	ldr	q6, [sp, #960]                  ; 16-byte Folded Reload
	str	s6, [x9]
	tbz	w11, #1, LBB0_105
LBB0_114:                               ; %cond.store4542
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v5[1]
	ldr	q5, [sp, #960]                  ; 16-byte Folded Reload
	st1.s	{ v5 }[1], [x9]
	tbz	w11, #2, LBB0_106
LBB0_115:                               ; %cond.store4546
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d4
	ldr	q5, [sp, #960]                  ; 16-byte Folded Reload
	st1.s	{ v5 }[2], [x9]
	tbz	w11, #3, LBB0_107
LBB0_116:                               ; %cond.store4550
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v4[1]
	ldr	q4, [sp, #960]                  ; 16-byte Folded Reload
	st1.s	{ v4 }[3], [x9]
	tbz	w11, #4, LBB0_108
LBB0_117:                               ; %cond.store4554
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d3
	ldr	q4, [sp, #944]                  ; 16-byte Folded Reload
	str	s4, [x9]
	tbz	w11, #5, LBB0_109
LBB0_118:                               ; %cond.store4558
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v3[1]
	ldr	q3, [sp, #944]                  ; 16-byte Folded Reload
	st1.s	{ v3 }[1], [x9]
	tbz	w11, #6, LBB0_110
LBB0_119:                               ; %cond.store4562
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d1
	ldr	q3, [sp, #944]                  ; 16-byte Folded Reload
	st1.s	{ v3 }[2], [x9]
	tbnz	w11, #7, LBB0_111
	b	LBB0_112
LBB0_120:                               ; %varying.coherent.false
                                        ;   in Loop: Header=BB0_11 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
LBB0_121:                               ; %schedule.5
                                        ;   in Loop: Header=BB0_11 Depth=3
	cbz	w15, LBB0_127
; %bb.122:                              ; %convergence.cascade74.preheader
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov	w11, #0                         ; =0x0
LBB0_123:                               ; %convergence.cascade74
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_11 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w9, s3
	umaxv.8b	b1, v1
	fmov	w10, s1
	sub	w16, w15, #1
	tst	w9, #0xff
	csel	w4, w16, wzr, ne
	lsl	w6, w12, w4
	and	w9, w6, w14
	tst	w9, #0xff
	cset	w9, ne
	str	q8, [sp, #4784]
	str	q13, [sp, #4800]
	ubfiz	x3, x4, #2, #3
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #688
	ldr	w16, [x16, x3]
	cmp	w16, #0
	cset	w7, eq
	and	w23, w9, w10
	ldrb	w9, [x5, w4, sxtw]
	and	w10, w9, #0x1
	fmov	s1, w10
	ubfx	w10, w9, #1, #1
	mov.b	v1[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v1[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v1[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v1[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v1[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v1[6], w10
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, w4, sxtw]
	and	w10, w9, #0x1
	fmov	s3, w10
	ubfx	w10, w9, #1, #1
	mov.b	v3[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v3[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v3[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v3[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v3[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v3[6], w10
	lsr	w9, w9, #7
	mov.b	v3[7], w9
	orr.8b	v4, v9, v3
	ldr	d0, [sp, #1752]                 ; 8-byte Folded Reload
	and.8b	v5, v0, v1
	eor.8b	v5, v5, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	umaxv.8b	b5, v5
	fmov	w9, s5
	ands	w10, w23, w7
	csetm	w16, ne
	bics	w9, w10, w9
	csetm	w2, ne
	dup.8b	v5, w2
	dup.8b	v6, w16
	bic.8b	v7, v4, v5
	bit.8b	v3, v7, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w4, sxtw]
	bic.8b	v1, v1, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x5, w4, sxtw]
	csinv	w16, w0, w6, eq
	dup.8b	v1, w10
	and	w14, w16, w14
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w9
	and.8b	v3, v3, v4
	str	q12, [sp, #4752]
	str	q19, [sp, #4768]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #656
	ldr	w9, [x9, x3]
	csel	w15, w9, w15, ne
	bit.8b	v9, v3, v1
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w3, s1
	cmp	w10, #1
	b.ne	LBB0_128
; %bb.124:                              ; %convergence.cascade74
                                        ;   in Loop: Header=BB0_123 Depth=4
	cmp	w15, #0
	ccmp	w11, #6, #2, ne
	b.hi	LBB0_128
; %bb.125:                              ; %convergence.cascade74
                                        ;   in Loop: Header=BB0_123 Depth=4
	add	w11, w11, #1
	tst	w3, #0xff
	b.ne	LBB0_123
	b	LBB0_128
LBB0_126:                               ; %varying.coherent.false63
                                        ;   in Loop: Header=BB0_11 Depth=3
	zip2.8b	v1, v9, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	ldp	q5, q3, [sp, #944]              ; 32-byte Folded Reload
	and.16b	v4, v1, v5
	zip1.8b	v1, v9, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	and.16b	v3, v1, v3
	stp	q4, q3, [sp, #944]              ; 32-byte Folded Spill
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #560
	add	x20, sp, #1, lsl #12            ; =4096
	add	x20, x20, #528
	add	x22, sp, #1, lsl #12            ; =4096
	add	x22, x22, #240
	add	x25, sp, #1, lsl #12            ; =4096
	add	x25, x25, #208
	add	x26, sp, #3952
	mov.16b	v22, v30
	mov.16b	v25, v31
	mov.16b	v26, v15
	ldr	q28, [sp, #1504]                ; 16-byte Folded Reload
	ldr	q23, [sp, #1696]                ; 16-byte Folded Reload
	ldr	q14, [sp, #1728]                ; 16-byte Folded Reload
	ldr	q31, [sp, #1584]                ; 16-byte Folded Reload
	ldr	q21, [sp, #1520]                ; 16-byte Folded Reload
	tbz	w11, #0, LBB0_36
	b	LBB0_5
LBB0_127:                               ; %schedule.5.convergence.cascade.exit75_crit_edge
                                        ;   in Loop: Header=BB0_11 Depth=3
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w3, s1
LBB0_128:                               ; %convergence.cascade.exit75
                                        ;   in Loop: Header=BB0_11 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
; %bb.129:                              ; %convergence.target.5.ready
                                        ;   in Loop: Header=BB0_11 Depth=3
	rbit	w9, w3
	clz	w9, w9
	ldr	q1, [sp, #1472]                 ; 16-byte Folded Reload
	str	q1, [sp, #4688]
	ldr	q1, [sp, #1456]                 ; 16-byte Folded Reload
	str	q1, [sp, #4704]
	ldr	q1, [sp, #1440]                 ; 16-byte Folded Reload
	str	q1, [sp, #4720]
	ldr	q1, [sp, #1424]                 ; 16-byte Folded Reload
	str	q1, [sp, #4736]
	and	x10, x9, #0x7
	add	x11, sp, #1, lsl #12            ; =4096
	add	x11, x11, #592
	ldr	x10, [x11, x10, lsl #3]
	lsl	w9, w9, #2
	sub	x9, x10, x9
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #728
	add	x9, x10, x9
	ldp	q1, q3, [x9]
	fabs.4s	v1, v1
	fabs.4s	v3, v3
	ldp	q4, q5, [x9, #32]
	fabs.4s	v4, v4
	fabs.4s	v5, v5
	ldp	q6, q7, [x9, #64]
	fabs.4s	v6, v6
	fabs.4s	v7, v7
	ldp	q17, q16, [x9, #96]
	mov	b18, v9[6]
	mov.b	v18[4], v9[7]
	fabs.4s	v17, v17
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	mov	w9, #4                          ; =0x4
	dup.2d	v20, x9
	mov.16b	v27, v21
	ldr	q21, [sp, #1600]                ; 16-byte Folded Reload
	bit.16b	v21, v20, v18
	str	q21, [sp, #1600]                ; 16-byte Folded Spill
	mov	b18, v9[4]
	mov.b	v18[4], v9[5]
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	bit.16b	v0, v20, v18
	str	q0, [sp, #1488]                 ; 16-byte Folded Spill
	mov	b18, v9[2]
	mov.b	v18[4], v9[3]
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	bit.16b	v31, v20, v18
	mov	b18, v9[0]
	mov.b	v18[4], v9[1]
	fabs.4s	v16, v16
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	ldr	q0, [sp, #1712]                 ; 16-byte Folded Reload
	bit.16b	v0, v20, v18
	str	q0, [sp, #1712]                 ; 16-byte Folded Spill
	zip1.8b	v18, v9, v0
	ushll.4s	v18, v18, #0
	shl.4s	v18, v18, #31
	cmlt.4s	v18, v18, #0
	zip2.8b	v20, v9, v0
	ushll.4s	v20, v20, #0
	shl.4s	v20, v20, #31
	cmlt.4s	v20, v20, #0
	ldr	q21, [sp, #976]                 ; 16-byte Folded Reload
	bit.16b	v21, v3, v20
	str	q21, [sp, #976]                 ; 16-byte Folded Spill
	mov.16b	v21, v27
	ldr	q3, [sp, #992]                  ; 16-byte Folded Reload
	bit.16b	v3, v1, v18
	ldr	q1, [sp, #1008]                 ; 16-byte Folded Reload
	bit.16b	v1, v5, v20
	stp	q3, q1, [sp, #992]              ; 32-byte Folded Spill
	ldr	q1, [sp, #1024]                 ; 16-byte Folded Reload
	bit.16b	v1, v4, v18
	str	q1, [sp, #1024]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #1040]                 ; 16-byte Folded Reload
	bit.16b	v1, v7, v20
	str	q1, [sp, #1040]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #1056]                 ; 16-byte Folded Reload
	bit.16b	v1, v6, v18
	str	q1, [sp, #1056]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #752]                  ; 16-byte Folded Reload
	bit.16b	v1, v16, v20
	str	q1, [sp, #752]                  ; 16-byte Folded Spill
	ldr	q1, [sp, #768]                  ; 16-byte Folded Reload
	bit.16b	v1, v17, v18
	str	q1, [sp, #768]                  ; 16-byte Folded Spill
	mov	w9, #1                          ; =0x1
	str	x9, [sp, #504]                  ; 8-byte Folded Spill
	mov	w9, #2                          ; =0x2
	str	x9, [sp, #496]                  ; 8-byte Folded Spill
	mov	w9, #3                          ; =0x3
	str	x9, [sp, #488]                  ; 8-byte Folded Spill
	b	LBB0_137
LBB0_130:                               ; %cond.load4489
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d7
	ldr	s1, [x9]
	mov.16b	v25, v17
	tbz	w11, #1, LBB0_93
LBB0_131:                               ; %cond.load4495
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v7[1]
	ld1.s	{ v1 }[1], [x9]
	tbz	w11, #2, LBB0_94
LBB0_132:                               ; %cond.load4501
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d6
	ld1.s	{ v1 }[2], [x9]
	tbz	w11, #3, LBB0_95
LBB0_133:                               ; %cond.load4507
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v6[1]
	ld1.s	{ v1 }[3], [x9]
	tbz	w11, #4, LBB0_96
LBB0_134:                               ; %cond.load4513
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d5
	ld1.s	{ v3 }[0], [x9]
	tbz	w11, #5, LBB0_97
LBB0_135:                               ; %cond.load4519
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v5[1]
	ld1.s	{ v3 }[1], [x9]
	tbz	w11, #6, LBB0_98
LBB0_136:                               ; %cond.load4525
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d4
	ld1.s	{ v3 }[2], [x9]
	tbnz	w11, #7, LBB0_99
	b	LBB0_100
LBB0_137:                               ; %schedule.6
                                        ;   in Loop: Header=BB0_11 Depth=3
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	mov	w9, #64                         ; =0x40
	dup.2d	v1, x9
	cmgt.2d	v3, v1, v31
	ldr	q0, [sp, #1712]                 ; 16-byte Folded Reload
	cmgt.2d	v4, v1, v0
	uzp1.4s	v3, v4, v3
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	cmgt.2d	v4, v1, v0
	ldr	q6, [sp, #1600]                 ; 16-byte Folded Reload
	cmgt.2d	v5, v1, v6
	uzp1.4s	v4, v4, v5
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v10, v9, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w3, s4
	umaxv.8b	b3, v3
	fmov	w9, s3
	tbz	w9, #0, LBB0_143
; %bb.138:                              ; %schedule.6
                                        ;   in Loop: Header=BB0_11 Depth=3
	cmge.2d	v3, v31, v1
	ldr	q0, [sp, #1712]                 ; 16-byte Folded Reload
	cmge.2d	v4, v0, v1
	uzp1.4s	v3, v4, v3
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	cmge.2d	v4, v0, v1
	cmge.2d	v1, v6, v1
	uzp1.4s	v1, v4, v1
	uzp1.8h	v1, v3, v1
	xtn.8b	v1, v1
	and.8b	v11, v9, v1
	shl.8b	v1, v11, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w9, s1
	tst	w9, #0xff
	b.eq	LBB0_143
; %bb.139:                              ; %varying.divergent102
                                        ;   in Loop: Header=BB0_11 Depth=3
	subs	w9, w15, #1
	csel	w9, wzr, w9, lo
	and	w10, w14, #0xff
	lsr	w11, w10, w9
	tst	w11, #0x1
	str	q8, [sp, #2272]
	str	q13, [sp, #2288]
	and	x9, x9, #0x7
	add	x11, sp, #2272
	ldr	w9, [x11, x9, lsl #2]
	ccmp	w15, #0, #4, ne
	ccmp	w9, #2, #0, ne
	cset	w4, ne
	cmp	w10, #255
	b.ne	LBB0_141
; %bb.140:                              ; %varying.divergent102
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w4, #0, LBB0_603
LBB0_141:                               ; %convergence.overflow.resume105
                                        ;   in Loop: Header=BB0_11 Depth=3
	mvn	w9, w14
	rbit	w9, w9
	clz	w9, w9
	mov	w10, #255                       ; =0xff
	bics	wzr, w10, w14
	csel	w6, wzr, w9, eq
	ldrb	w9, [x5, w6, uxtw]
	and	w10, w9, #0x1
	fmov	s1, w10
	ubfx	w10, w9, #1, #1
	mov.b	v1[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v1[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v1[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v1[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v1[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v1[6], w10
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, w6, uxtw]
	and	w10, w9, #0x1
	fmov	s3, w10
	ubfx	w10, w9, #1, #1
	mov.b	v3[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v3[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v3[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v3[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v3[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v3[6], w10
	lsr	w9, w9, #7
	mov.b	v3[7], w9
	cmp	w4, #0
	csetm	w9, ne
	dup.8b	v4, w9
	bit.8b	v1, v9, v4
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x5, w6, uxtw]
	bic.8b	v1, v3, v4
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x8, w6, uxtw]
	cmp	x13, #8
	b.hs	LBB0_603
; %bb.142:                              ; %ready.overflow.resume107
                                        ;   in Loop: Header=BB0_11 Depth=3
	str	q12, [sp, #2240]
	str	q19, [sp, #2256]
	ubfiz	x9, x6, #2, #3
	add	x10, sp, #2240
	ldr	w10, [x10, x9]
	cmp	w4, #0
	csel	w10, w15, w10, ne
	str	q12, [sp, #2208]
	str	q19, [sp, #2224]
	add	x11, sp, #2208
	str	w10, [x11, x9]
	ldr	q19, [sp, #2224]
	ldr	q12, [sp, #2208]
	str	q8, [sp, #2176]
	str	q13, [sp, #2192]
	add	x10, sp, #2176
	ldr	w10, [x10, x9]
	csinc	w15, w15, w6, eq
	mov	w11, #2                         ; =0x2
	csel	w10, w11, w10, ne
	str	q8, [sp, #2144]
	str	q13, [sp, #2160]
	add	x11, sp, #2144
	str	w10, [x11, x9]
	mov	w7, #8                          ; =0x8
	mov	w11, #7                         ; =0x7
	ldr	q13, [sp, #2160]
	ldr	q8, [sp, #2144]
	b	LBB0_9
LBB0_143:                               ; %varying.coherent103
                                        ;   in Loop: Header=BB0_11 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_210
; %bb.144:                              ; %varying.coherent.true108
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov	w4, #0                          ; =0x0
	tst	w11, #0xff
	b.eq	LBB0_5
LBB0_145:                               ; %schedule.7
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.16b	v11, v21
	str	q22, [sp, #1568]                ; 16-byte Folded Spill
	str	q25, [sp, #1616]                ; 16-byte Folded Spill
	str	q29, [sp, #1536]                ; 16-byte Folded Spill
	str	q26, [sp, #1552]                ; 16-byte Folded Spill
	mov	b1, v9[0]
	mov.b	v1[4], v9[1]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	mov	b3, v9[2]
	mov.b	v3[4], v9[3]
	ldr	q0, [sp, #1712]                 ; 16-byte Folded Reload
	and.16b	v5, v1, v0
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	and.16b	v6, v3, v31
	mov	b4, v9[4]
	mov.b	v4[4], v9[5]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	mov.16b	v29, v0
	and.16b	v16, v4, v0
	mov	b7, v9[6]
	mov.b	v7[4], v9[7]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v18, v7, #0
	ldr	q7, [sp, #1600]                 ; 16-byte Folded Reload
	and.16b	v17, v18, v7
	shl.8b	v7, v9, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	mov	w9, #65                         ; =0x41
	dup.2d	v20, x9
	addv.8b	b0, v7
	and.16b	v7, v1, v20
	mvn.16b	v1, v1
	sub.2d	v7, v7, v1
	and.16b	v1, v3, v20
	mvn.16b	v3, v3
	sub.2d	v3, v1, v3
	and.16b	v1, v18, v20
	mvn.16b	v18, v18
	sub.2d	v1, v1, v18
	mov.d	x11, v1[1]
	and.16b	v18, v4, v20
	mov.d	x9, v17[1]
	sdiv	x9, x9, x11
	mvn.16b	v4, v4
	sub.2d	v4, v18, v4
	fmov	x16, d1
	fmov	x2, d17
	fmov	x19, d4
	fmov	x3, d16
	mov.d	x6, v4[1]
	sdiv	x20, x3, x19
	mov.d	x3, v16[1]
	sdiv	x22, x3, x6
	fmov	x23, d3
	fmov	x3, d6
	sdiv	x25, x3, x23
	mov.d	x7, v3[1]
	mov.d	x26, v6[1]
	fmov	x10, d7
	fmov	x3, d5
	sdiv	x21, x3, x10
	mov.d	x3, v7[1]
	mov.d	x27, v5[1]
	sdiv	x27, x27, x3
	mul	x28, x27, x3
	mul	x10, x21, x10
	fmov	d18, x10
	mov.d	v18[1], x28
	sdiv	x10, x26, x7
	mul	x26, x10, x7
	mul	x23, x25, x23
	fmov	d20, x23
	mov.d	v20[1], x26
	mul	x23, x22, x6
	mul	x19, x20, x19
	fmov	d21, x19
	mov.d	v21[1], x23
	mul	x19, x9, x11
	sdiv	x2, x2, x16
	mul	x16, x2, x16
	fmov	d22, x16
	mov.d	v22[1], x19
	sub.2d	v17, v17, v22
	sub.2d	v16, v16, v21
	add	x16, x2, x2, lsl #6
	fmov	d21, x16
	add	x9, x9, x9, lsl #6
	mov.d	v21[1], x9
	sub.2d	v6, v6, v20
	add	x9, x20, x20, lsl #6
	fmov	d20, x9
	add	x9, x22, x22, lsl #6
	mov.d	v20[1], x9
	sub.2d	v5, v5, v18
	add	x9, x25, x25, lsl #6
	fmov	d18, x9
	add	x9, x10, x10, lsl #6
	mov.d	v18[1], x9
	add	x9, x21, x21, lsl #6
	fmov	d22, x9
	add	x9, x27, x27, lsl #6
	mov.d	v22[1], x9
	add.2d	v5, v22, v5
	add.2d	v6, v18, v6
	add.2d	v16, v20, v16
	add.2d	v17, v21, v17
	shl.2d	v17, v17, #5
	shl.2d	v18, v16, #5
	str	d0, [sp, #1584]                 ; 8-byte Folded Spill
	fmov	w23, s0
	shl.2d	v6, v6, #5
	shl.2d	v21, v5, #5
	ldr	q5, [sp, #784]                  ; 16-byte Folded Reload
	ldr	q16, [sp, #1424]                ; 16-byte Folded Reload
	add.2d	v5, v5, v16
	add.2d	v17, v5, v17
	ldr	q16, [sp, #800]                 ; 16-byte Folded Reload
	ldr	q20, [sp, #1440]                ; 16-byte Folded Reload
	add.2d	v16, v16, v20
	add.2d	v18, v16, v18
	ldr	q20, [sp, #816]                 ; 16-byte Folded Reload
	ldr	q22, [sp, #1456]                ; 16-byte Folded Reload
	add.2d	v24, v20, v22
	add.2d	v20, v24, v6
	ldr	q6, [sp, #832]                  ; 16-byte Folded Reload
	ldr	q22, [sp, #1472]                ; 16-byte Folded Reload
	add.2d	v25, v6, v22
	add.2d	v21, v25, v21
	movi.2d	v6, #0000000000000000
	movi.2d	v26, #0000000000000000
	str	q23, [sp, #1696]                ; 16-byte Folded Spill
	str	q14, [sp, #1728]                ; 16-byte Folded Spill
	tbnz	w23, #0, LBB0_183
; %bb.146:                              ; %else3619
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #1, LBB0_184
LBB0_147:                               ; %else3625
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #2, LBB0_185
LBB0_148:                               ; %else3631
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #3, LBB0_186
LBB0_149:                               ; %else3637
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #4, LBB0_187
LBB0_150:                               ; %else3643
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #5, LBB0_188
LBB0_151:                               ; %else3649
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #6, LBB0_189
LBB0_152:                               ; %else3655
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbz	w23, #7, LBB0_154
LBB0_153:                               ; %cond.load3657
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v17[1]
	ld1.s	{ v26 }[3], [x9]
LBB0_154:                               ; %else3661
                                        ;   in Loop: Header=BB0_11 Depth=3
	fabs.4s	v17, v26
	fabs.4s	v6, v6
	ldr	q18, [sp, #992]                 ; 16-byte Folded Reload
	fadd.4s	v30, v18, v6
	ldr	q6, [sp, #976]                  ; 16-byte Folded Reload
	fadd.4s	v6, v6, v17
	dup.2d	v17, x12
	ldr	q15, [sp, #1600]                ; 16-byte Folded Reload
	add.2d	v20, v15, v17
	add.2d	v21, v29, v17
	add.2d	v18, v31, v17
	ldr	q0, [sp, #1712]                 ; 16-byte Folded Reload
	add.2d	v17, v0, v17
	mov	b22, v9[0]
	mov.b	v22[4], v9[1]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	mov	b23, v9[2]
	mov.b	v23[4], v9[3]
	and.16b	v17, v22, v17
	ushll.2d	v22, v23, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	and.16b	v18, v22, v18
	mov	b22, v9[4]
	mov.b	v22[4], v9[5]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	and.16b	v21, v22, v21
	mov	b22, v9[6]
	mov.b	v22[4], v9[7]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	and.16b	v20, v22, v20
	fmov	x9, d20
	fmov	x10, d1
	mov.d	x16, v20[1]
	sdiv	x16, x16, x11
	fmov	x2, d21
	fmov	x19, d4
	sdiv	x2, x2, x19
	mov.d	x20, v21[1]
	sdiv	x20, x20, x6
	fmov	x21, d18
	fmov	x22, d3
	sdiv	x21, x21, x22
	mov.d	x23, v18[1]
	sdiv	x23, x23, x7
	fmov	x25, d17
	fmov	x26, d7
	sdiv	x25, x25, x26
	mov.d	x27, v17[1]
	sdiv	x27, x27, x3
	mul	x28, x27, x3
	mul	x26, x25, x26
	fmov	d22, x26
	mov.d	v22[1], x28
	mul	x26, x23, x7
	mul	x22, x21, x22
	fmov	d23, x22
	mov.d	v23[1], x26
	mul	x22, x20, x6
	mul	x19, x2, x19
	fmov	d26, x19
	mov.d	v26[1], x22
	mul	x19, x16, x11
	sdiv	x9, x9, x10
	mul	x10, x9, x10
	fmov	d27, x10
	mov.d	v27[1], x19
	sub.2d	v20, v20, v27
	sub.2d	v21, v21, v26
	sub.2d	v18, v18, v23
	sub.2d	v17, v17, v22
	add	x9, x9, x9, lsl #6
	fmov	d22, x9
	add	x9, x16, x16, lsl #6
	mov.d	v22[1], x9
	add	x9, x2, x2, lsl #6
	fmov	d23, x9
	add	x9, x20, x20, lsl #6
	mov.d	v23[1], x9
	add	x9, x21, x21, lsl #6
	fmov	d26, x9
	add	x9, x23, x23, lsl #6
	mov.d	v26[1], x9
	add	x9, x25, x25, lsl #6
	fmov	d27, x9
	add	x9, x27, x27, lsl #6
	mov.d	v27[1], x9
	add.2d	v17, v27, v17
	add.2d	v18, v26, v18
	add.2d	v21, v23, v21
	add.2d	v20, v22, v20
	shl.2d	v20, v20, #5
	shl.2d	v21, v21, #5
	shl.2d	v22, v18, #5
	shl.2d	v17, v17, #5
	ldr	d0, [sp, #1584]                 ; 8-byte Folded Reload
	fmov	w23, s0
	add.2d	v18, v5, v20
	add.2d	v20, v16, v21
	add.2d	v21, v24, v22
	add.2d	v22, v25, v17
	movi.2d	v17, #0000000000000000
	movi.2d	v26, #0000000000000000
	tbnz	w23, #0, LBB0_190
; %bb.155:                              ; %else3668
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #1, LBB0_191
LBB0_156:                               ; %else3674
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #2, LBB0_192
LBB0_157:                               ; %else3680
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #3, LBB0_193
LBB0_158:                               ; %else3686
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.16b	v10, v8
	tbnz	w23, #4, LBB0_194
LBB0_159:                               ; %else3692
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.16b	v8, v13
	mov.16b	v13, v12
	tbnz	w23, #5, LBB0_195
LBB0_160:                               ; %else3698
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.16b	v12, v19
	mov.16b	v19, v6
	tbnz	w23, #6, LBB0_196
LBB0_161:                               ; %else3704
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.16b	v6, v30
	ldr	q0, [sp, #1712]                 ; 16-byte Folded Reload
	mov.16b	v14, v28
	tbz	w23, #7, LBB0_163
LBB0_162:                               ; %cond.load3706
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v18[1]
	ld1.s	{ v26 }[3], [x9]
LBB0_163:                               ; %else3710
                                        ;   in Loop: Header=BB0_11 Depth=3
	fabs.4s	v18, v26
	fabs.4s	v17, v17
	ldr	q20, [sp, #1024]                ; 16-byte Folded Reload
	fadd.4s	v30, v20, v17
	ldr	q17, [sp, #1008]                ; 16-byte Folded Reload
	fadd.4s	v27, v17, v18
	mov	w9, #2                          ; =0x2
	dup.2d	v17, x9
	add.2d	v20, v15, v17
	mov.16b	v15, v29
	add.2d	v21, v29, v17
	add.2d	v18, v31, v17
	add.2d	v17, v0, v17
	mov	b22, v9[0]
	mov.b	v22[4], v9[1]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	mov	b23, v9[2]
	mov.b	v23[4], v9[3]
	and.16b	v17, v22, v17
	ushll.2d	v22, v23, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	and.16b	v18, v22, v18
	mov	b22, v9[4]
	mov.b	v22[4], v9[5]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	and.16b	v21, v22, v21
	mov	b22, v9[6]
	mov.b	v22[4], v9[7]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	and.16b	v20, v22, v20
	fmov	x9, d20
	fmov	x10, d1
	mov.d	x16, v20[1]
	sdiv	x16, x16, x11
	fmov	x2, d21
	fmov	x19, d4
	sdiv	x2, x2, x19
	mov.d	x20, v21[1]
	sdiv	x20, x20, x6
	fmov	x21, d18
	fmov	x22, d3
	sdiv	x21, x21, x22
	mov.d	x23, v18[1]
	sdiv	x23, x23, x7
	fmov	x25, d17
	fmov	x26, d7
	sdiv	x25, x25, x26
	mov.d	x27, v17[1]
	sdiv	x27, x27, x3
	mul	x28, x27, x3
	mul	x26, x25, x26
	fmov	d22, x26
	mov.d	v22[1], x28
	mul	x26, x23, x7
	mul	x22, x21, x22
	fmov	d23, x22
	mov.d	v23[1], x26
	mul	x22, x20, x6
	mul	x19, x2, x19
	fmov	d28, x19
	mov.d	v28[1], x22
	mul	x19, x16, x11
	sdiv	x9, x9, x10
	mul	x10, x9, x10
	fmov	d29, x10
	mov.d	v29[1], x19
	sub.2d	v20, v20, v29
	sub.2d	v21, v21, v28
	sub.2d	v18, v18, v23
	sub.2d	v17, v17, v22
	add	x9, x9, x9, lsl #6
	fmov	d22, x9
	add	x9, x16, x16, lsl #6
	mov.d	v22[1], x9
	add	x9, x2, x2, lsl #6
	fmov	d23, x9
	add	x9, x20, x20, lsl #6
	mov.d	v23[1], x9
	add	x9, x21, x21, lsl #6
	fmov	d28, x9
	add	x9, x23, x23, lsl #6
	mov.d	v28[1], x9
	add	x9, x25, x25, lsl #6
	fmov	d29, x9
	add	x9, x27, x27, lsl #6
	mov.d	v29[1], x9
	add.2d	v17, v29, v17
	add.2d	v18, v28, v18
	add.2d	v21, v23, v21
	add.2d	v20, v22, v20
	shl.2d	v20, v20, #5
	shl.2d	v21, v21, #5
	shl.2d	v22, v18, #5
	shl.2d	v17, v17, #5
	ldr	d0, [sp, #1584]                 ; 8-byte Folded Reload
	fmov	w23, s0
	add.2d	v18, v5, v20
	add.2d	v20, v16, v21
	add.2d	v21, v24, v22
	add.2d	v22, v25, v17
	movi.2d	v17, #0000000000000000
	movi.2d	v28, #0000000000000000
	tbnz	w23, #0, LBB0_197
; %bb.164:                              ; %else3717
                                        ;   in Loop: Header=BB0_11 Depth=3
	add	x28, sp, #3, lsl #12            ; =12288
	add	x28, x28, #872
	mov.16b	v26, v11
	tbnz	w23, #1, LBB0_198
LBB0_165:                               ; %else3723
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.16b	v29, v6
	mov.16b	v6, v19
	tbnz	w23, #2, LBB0_199
LBB0_166:                               ; %else3729
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.16b	v19, v12
	mov.16b	v12, v13
	tbnz	w23, #3, LBB0_200
LBB0_167:                               ; %else3735
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.16b	v13, v8
	mov.16b	v8, v10
	tbnz	w23, #4, LBB0_201
LBB0_168:                               ; %else3741
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #5, LBB0_202
LBB0_169:                               ; %else3747
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #6, LBB0_203
LBB0_170:                               ; %else3753
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbz	w23, #7, LBB0_172
LBB0_171:                               ; %cond.load3755
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v18[1]
	ld1.s	{ v28 }[3], [x9]
LBB0_172:                               ; %else3759
                                        ;   in Loop: Header=BB0_11 Depth=3
	fabs.4s	v18, v28
	fabs.4s	v17, v17
	ldr	q20, [sp, #1056]                ; 16-byte Folded Reload
	fadd.4s	v28, v20, v17
	ldr	q17, [sp, #1040]                ; 16-byte Folded Reload
	fadd.4s	v17, v17, v18
	mov	w9, #3                          ; =0x3
	dup.2d	v20, x9
	ldr	q18, [sp, #1600]                ; 16-byte Folded Reload
	add.2d	v21, v18, v20
	add.2d	v22, v15, v20
	ldr	q0, [sp, #1712]                 ; 16-byte Folded Reload
	add.2d	v18, v0, v20
	mov	b23, v9[0]
	mov.b	v23[4], v9[1]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v23, v23, #0
	and.16b	v18, v23, v18
	mov	b23, v9[2]
	mov.b	v23[4], v9[3]
	add.2d	v20, v31, v20
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v23, v23, #0
	and.16b	v20, v23, v20
	mov	b23, v9[4]
	mov.b	v23[4], v9[5]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v23, v23, #0
	and.16b	v22, v23, v22
	mov	b23, v9[6]
	mov.b	v23[4], v9[7]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v23, v23, #0
	and.16b	v21, v23, v21
	fmov	x9, d21
	fmov	x10, d1
	mov.d	x16, v21[1]
	sdiv	x16, x16, x11
	fmov	x2, d22
	fmov	x19, d4
	sdiv	x2, x2, x19
	mov.d	x20, v22[1]
	sdiv	x20, x20, x6
	fmov	x21, d20
	fmov	x22, d3
	sdiv	x21, x21, x22
	mov.d	x23, v20[1]
	sdiv	x23, x23, x7
	fmov	x25, d18
	fmov	x26, d7
	sdiv	x25, x25, x26
	mov.d	x27, v18[1]
	sdiv	x27, x27, x3
	mul	x3, x27, x3
	mul	x26, x25, x26
	fmov	d1, x26
	mov.d	v1[1], x3
	mul	x3, x23, x7
	mul	x7, x21, x22
	fmov	d3, x7
	mov.d	v3[1], x3
	mul	x3, x20, x6
	mul	x6, x2, x19
	fmov	d4, x6
	mov.d	v4[1], x3
	mul	x11, x16, x11
	sdiv	x9, x9, x10
	mul	x10, x9, x10
	fmov	d7, x10
	mov.d	v7[1], x11
	sub.2d	v7, v21, v7
	sub.2d	v4, v22, v4
	sub.2d	v3, v20, v3
	sub.2d	v1, v18, v1
	add	x9, x9, x9, lsl #6
	fmov	d18, x9
	add	x9, x16, x16, lsl #6
	mov.d	v18[1], x9
	add	x9, x2, x2, lsl #6
	fmov	d20, x9
	add	x9, x20, x20, lsl #6
	mov.d	v20[1], x9
	add	x9, x21, x21, lsl #6
	fmov	d21, x9
	add	x9, x23, x23, lsl #6
	mov.d	v21[1], x9
	add	x9, x25, x25, lsl #6
	fmov	d22, x9
	add	x9, x27, x27, lsl #6
	mov.d	v22[1], x9
	add.2d	v1, v22, v1
	add.2d	v3, v21, v3
	add.2d	v4, v20, v4
	add.2d	v7, v18, v7
	shl.2d	v7, v7, #5
	shl.2d	v18, v4, #5
	shl.2d	v3, v3, #5
	shl.2d	v1, v1, #5
	ldr	d0, [sp, #1584]                 ; 8-byte Folded Reload
	fmov	w11, s0
	add.2d	v4, v5, v7
	add.2d	v5, v16, v18
	add.2d	v7, v24, v3
	add.2d	v16, v25, v1
	movi.2d	v1, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbz	w11, #0, LBB0_174
; %bb.173:                              ; %cond.load3762
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d16
	ldr	s1, [x9]
LBB0_174:                               ; %else3766
                                        ;   in Loop: Header=BB0_11 Depth=3
	add	x21, sp, #3, lsl #12            ; =12288
	add	x21, x21, #936
	add	x27, sp, #3, lsl #12            ; =12288
	add	x27, x27, #904
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #560
	add	x20, sp, #1, lsl #12            ; =4096
	add	x20, x20, #528
	add	x22, sp, #1, lsl #12            ; =4096
	add	x22, x22, #240
	add	x25, sp, #1, lsl #12            ; =4096
	add	x25, x25, #208
	add	x26, sp, #3952
	ldr	q22, [sp, #1568]                ; 16-byte Folded Reload
	ldr	q25, [sp, #1616]                ; 16-byte Folded Reload
	ldr	q20, [sp, #1680]                ; 16-byte Folded Reload
	ldr	q24, [sp, #1552]                ; 16-byte Folded Reload
	ldr	q21, [sp, #1664]                ; 16-byte Folded Reload
	mov.16b	v11, v14
	tbnz	w11, #1, LBB0_204
; %bb.175:                              ; %else3772
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #2, LBB0_205
LBB0_176:                               ; %else3778
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #3, LBB0_206
LBB0_177:                               ; %else3784
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #4, LBB0_207
LBB0_178:                               ; %else3790
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #5, LBB0_208
LBB0_179:                               ; %else3796
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #6, LBB0_209
LBB0_180:                               ; %else3802
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbz	w11, #7, LBB0_182
LBB0_181:                               ; %cond.load3804
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v4[1]
	ld1.s	{ v3 }[3], [x9]
LBB0_182:                               ; %else3808
                                        ;   in Loop: Header=BB0_11 Depth=3
	fabs.4s	v3, v3
	fabs.4s	v1, v1
	ldr	q7, [sp, #768]                  ; 16-byte Folded Reload
	fadd.4s	v1, v7, v1
	mov	w9, #4                          ; =0x4
	dup.2d	v4, x9
	mov	b5, v9[6]
	mov.b	v5[4], v9[7]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	and.16b	v5, v5, v4
	ldr	q16, [sp, #1600]                ; 16-byte Folded Reload
	add.2d	v16, v16, v5
	str	q16, [sp, #1600]                ; 16-byte Folded Spill
	mov	b5, v9[4]
	mov.b	v5[4], v9[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	and.16b	v5, v5, v4
	add.2d	v15, v15, v5
	str	q15, [sp, #1488]                ; 16-byte Folded Spill
	mov	b5, v9[2]
	mov.b	v5[4], v9[3]
	ldr	q16, [sp, #752]                 ; 16-byte Folded Reload
	fadd.4s	v3, v16, v3
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	and.16b	v5, v5, v4
	add.2d	v31, v31, v5
	mov	b5, v9[0]
	mov.b	v5[4], v9[1]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	and.16b	v4, v5, v4
	ldr	q0, [sp, #1712]                 ; 16-byte Folded Reload
	add.2d	v0, v0, v4
	str	q0, [sp, #1712]                 ; 16-byte Folded Spill
	zip1.8b	v4, v9, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	zip2.8b	v5, v9, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q18, [sp, #976]                 ; 16-byte Folded Reload
	bit.16b	v18, v6, v5
	ldr	q6, [sp, #992]                  ; 16-byte Folded Reload
	bit.16b	v6, v29, v4
	stp	q18, q6, [sp, #976]             ; 32-byte Folded Spill
	ldr	q6, [sp, #1008]                 ; 16-byte Folded Reload
	bit.16b	v6, v27, v5
	str	q6, [sp, #1008]                 ; 16-byte Folded Spill
	ldr	q6, [sp, #1024]                 ; 16-byte Folded Reload
	bit.16b	v6, v30, v4
	str	q6, [sp, #1024]                 ; 16-byte Folded Spill
	ldr	q6, [sp, #1040]                 ; 16-byte Folded Reload
	bit.16b	v6, v17, v5
	str	q6, [sp, #1040]                 ; 16-byte Folded Spill
	ldr	q6, [sp, #1056]                 ; 16-byte Folded Reload
	bit.16b	v6, v28, v4
	str	q6, [sp, #1056]                 ; 16-byte Folded Spill
	bit.16b	v16, v3, v5
	bit.16b	v7, v1, v4
	stp	q16, q7, [sp, #752]             ; 32-byte Folded Spill
	ldr	q29, [sp, #1536]                ; 16-byte Folded Reload
	ldr	q23, [sp, #1696]                ; 16-byte Folded Reload
	ldr	q14, [sp, #1728]                ; 16-byte Folded Reload
	str	q20, [sp, #1680]                ; 16-byte Folded Spill
	str	q21, [sp, #1664]                ; 16-byte Folded Spill
	mov.16b	v28, v11
	mov.16b	v21, v26
	mov.16b	v26, v24
	tbz	w4, #0, LBB0_137
	b	LBB0_5
LBB0_183:                               ; %cond.load3615
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d21
	ldr	s6, [x9]
	tbz	w23, #1, LBB0_147
LBB0_184:                               ; %cond.load3621
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v21[1]
	ld1.s	{ v6 }[1], [x9]
	tbz	w23, #2, LBB0_148
LBB0_185:                               ; %cond.load3627
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d20
	ld1.s	{ v6 }[2], [x9]
	tbz	w23, #3, LBB0_149
LBB0_186:                               ; %cond.load3633
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v20[1]
	ld1.s	{ v6 }[3], [x9]
	tbz	w23, #4, LBB0_150
LBB0_187:                               ; %cond.load3639
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d18
	ld1.s	{ v26 }[0], [x9]
	tbz	w23, #5, LBB0_151
LBB0_188:                               ; %cond.load3645
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v18[1]
	ld1.s	{ v26 }[1], [x9]
	tbz	w23, #6, LBB0_152
LBB0_189:                               ; %cond.load3651
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d17
	ld1.s	{ v26 }[2], [x9]
	tbnz	w23, #7, LBB0_153
	b	LBB0_154
LBB0_190:                               ; %cond.load3664
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d22
	ldr	s17, [x9]
	tbz	w23, #1, LBB0_156
LBB0_191:                               ; %cond.load3670
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v22[1]
	ld1.s	{ v17 }[1], [x9]
	tbz	w23, #2, LBB0_157
LBB0_192:                               ; %cond.load3676
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d21
	ld1.s	{ v17 }[2], [x9]
	tbz	w23, #3, LBB0_158
LBB0_193:                               ; %cond.load3682
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v21[1]
	ld1.s	{ v17 }[3], [x9]
	mov.16b	v10, v8
	tbz	w23, #4, LBB0_159
LBB0_194:                               ; %cond.load3688
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d20
	ld1.s	{ v26 }[0], [x9]
	mov.16b	v8, v13
	mov.16b	v13, v12
	tbz	w23, #5, LBB0_160
LBB0_195:                               ; %cond.load3694
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v20[1]
	ld1.s	{ v26 }[1], [x9]
	mov.16b	v12, v19
	mov.16b	v19, v6
	tbz	w23, #6, LBB0_161
LBB0_196:                               ; %cond.load3700
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d18
	ld1.s	{ v26 }[2], [x9]
	mov.16b	v6, v30
	ldr	q0, [sp, #1712]                 ; 16-byte Folded Reload
	mov.16b	v14, v28
	tbnz	w23, #7, LBB0_162
	b	LBB0_163
LBB0_197:                               ; %cond.load3713
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d22
	ldr	s17, [x9]
	add	x28, sp, #3, lsl #12            ; =12288
	add	x28, x28, #872
	mov.16b	v26, v11
	tbz	w23, #1, LBB0_165
LBB0_198:                               ; %cond.load3719
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v22[1]
	ld1.s	{ v17 }[1], [x9]
	mov.16b	v29, v6
	mov.16b	v6, v19
	tbz	w23, #2, LBB0_166
LBB0_199:                               ; %cond.load3725
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d21
	ld1.s	{ v17 }[2], [x9]
	mov.16b	v19, v12
	mov.16b	v12, v13
	tbz	w23, #3, LBB0_167
LBB0_200:                               ; %cond.load3731
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v21[1]
	ld1.s	{ v17 }[3], [x9]
	mov.16b	v13, v8
	mov.16b	v8, v10
	tbz	w23, #4, LBB0_168
LBB0_201:                               ; %cond.load3737
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d20
	ld1.s	{ v28 }[0], [x9]
	tbz	w23, #5, LBB0_169
LBB0_202:                               ; %cond.load3743
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v20[1]
	ld1.s	{ v28 }[1], [x9]
	tbz	w23, #6, LBB0_170
LBB0_203:                               ; %cond.load3749
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d18
	ld1.s	{ v28 }[2], [x9]
	tbnz	w23, #7, LBB0_171
	b	LBB0_172
LBB0_204:                               ; %cond.load3768
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v16[1]
	ld1.s	{ v1 }[1], [x9]
	tbz	w11, #2, LBB0_176
LBB0_205:                               ; %cond.load3774
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d7
	ld1.s	{ v1 }[2], [x9]
	tbz	w11, #3, LBB0_177
LBB0_206:                               ; %cond.load3780
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v7[1]
	ld1.s	{ v1 }[3], [x9]
	tbz	w11, #4, LBB0_178
LBB0_207:                               ; %cond.load3786
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d5
	ld1.s	{ v3 }[0], [x9]
	tbz	w11, #5, LBB0_179
LBB0_208:                               ; %cond.load3792
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v5[1]
	ld1.s	{ v3 }[1], [x9]
	tbz	w11, #6, LBB0_180
LBB0_209:                               ; %cond.load3798
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d4
	ld1.s	{ v3 }[2], [x9]
	tbnz	w11, #7, LBB0_181
	b	LBB0_182
LBB0_210:                               ; %varying.coherent.false109
                                        ;   in Loop: Header=BB0_11 Depth=3
	tst	w11, #0xff
	b.eq	LBB0_5
LBB0_211:                               ; %schedule.8
                                        ;   in Loop: Header=BB0_11 Depth=3
	cbz	w15, LBB0_216
; %bb.212:                              ; %convergence.cascade147.preheader
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov	w11, #0                         ; =0x0
LBB0_213:                               ; %convergence.cascade147
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_11 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w9, s3
	umaxv.8b	b1, v1
	fmov	w10, s1
	sub	w16, w15, #1
	tst	w9, #0xff
	csel	w4, w16, wzr, ne
	lsl	w6, w12, w4
	and	w9, w6, w14
	tst	w9, #0xff
	cset	w9, ne
	str	q8, [sp, #4656]
	str	q13, [sp, #4672]
	ubfiz	x3, x4, #2, #3
	ldr	w16, [x19, x3]
	cmp	w16, #2
	cset	w7, eq
	and	w23, w9, w10
	ldrb	w9, [x5, w4, sxtw]
	and	w10, w9, #0x1
	fmov	s1, w10
	ubfx	w10, w9, #1, #1
	mov.b	v1[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v1[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v1[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v1[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v1[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v1[6], w10
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, w4, sxtw]
	and	w10, w9, #0x1
	fmov	s3, w10
	ubfx	w10, w9, #1, #1
	mov.b	v3[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v3[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v3[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v3[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v3[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v3[6], w10
	lsr	w9, w9, #7
	mov.b	v3[7], w9
	orr.8b	v4, v9, v3
	ldr	d0, [sp, #1752]                 ; 8-byte Folded Reload
	and.8b	v5, v0, v1
	eor.8b	v5, v5, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	umaxv.8b	b5, v5
	fmov	w9, s5
	ands	w10, w23, w7
	csetm	w16, ne
	bics	w9, w10, w9
	csetm	w2, ne
	dup.8b	v5, w2
	dup.8b	v6, w16
	bic.8b	v7, v4, v5
	bit.8b	v3, v7, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w4, sxtw]
	bic.8b	v1, v1, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x5, w4, sxtw]
	csinv	w16, w0, w6, eq
	dup.8b	v1, w10
	and	w14, w16, w14
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w9
	and.8b	v3, v3, v4
	str	q12, [sp, #4624]
	str	q19, [sp, #4640]
	ldr	w9, [x20, x3]
	csel	w15, w9, w15, ne
	bit.8b	v9, v3, v1
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w3, s1
	cmp	w10, #1
	b.ne	LBB0_217
; %bb.214:                              ; %convergence.cascade147
                                        ;   in Loop: Header=BB0_213 Depth=4
	cmp	w15, #0
	ccmp	w11, #6, #2, ne
	b.hi	LBB0_217
; %bb.215:                              ; %convergence.cascade147
                                        ;   in Loop: Header=BB0_213 Depth=4
	add	w11, w11, #1
	tst	w3, #0xff
	b.ne	LBB0_213
	b	LBB0_217
LBB0_216:                               ; %schedule.8.convergence.cascade.exit148_crit_edge
                                        ;   in Loop: Header=BB0_11 Depth=3
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w3, s1
LBB0_217:                               ; %convergence.cascade.exit148
                                        ;   in Loop: Header=BB0_11 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
; %bb.218:                              ; %convergence.target.8.ready
                                        ;   in Loop: Header=BB0_11 Depth=3
	rbit	w9, w3
	clz	w9, w9
	ldr	q10, [sp, #1472]                ; 16-byte Folded Reload
	str	q10, [sp, #4560]
	ldr	q11, [sp, #1456]                ; 16-byte Folded Reload
	str	q11, [sp, #4576]
	mov.16b	v0, v25
	mov.16b	v25, v28
	ldr	q28, [sp, #1440]                ; 16-byte Folded Reload
	str	q28, [sp, #4592]
	mov.16b	v27, v29
	mov.16b	v24, v22
	mov.16b	v22, v21
	ldr	q21, [sp, #1664]                ; 16-byte Folded Reload
	ldr	q29, [sp, #1424]                ; 16-byte Folded Reload
	str	q29, [sp, #4608]
	ubfiz	x11, x9, #3, #3
	ldr	x10, [sp, #504]                 ; 8-byte Folded Reload
	add	x10, x10, #65
	mov	x2, #4033                       ; =0xfc1
	movk	x2, #49404, lsl #16
	movk	x2, #64527, lsl #32
	movk	x2, #4032, lsl #48
	umulh	x16, x10, x2
	lsr	x16, x16, #2
	add	x16, x16, x16, lsl #6
	sub	x10, x10, x16
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #464
	ldr	x16, [x16, x11]
	lsl	w3, w9, #2
	sub	x9, x16, x3
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #728
	add	x9, x9, x16
	ldr	q1, [x9, #2048]
	ldr	q3, [x9, #2064]
	fabs.4s	v3, v3
	zip2.8b	v4, v9, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v3, v4, v3
	ldr	q5, [sp, #976]                  ; 16-byte Folded Reload
	fadd.4s	v3, v5, v3
	ldr	q5, [sp, #1008]                 ; 16-byte Folded Reload
	fadd.4s	v3, v5, v3
	ldr	q5, [sp, #1040]                 ; 16-byte Folded Reload
	fadd.4s	v3, v5, v3
	ldr	q5, [sp, #752]                  ; 16-byte Folded Reload
	fadd.4s	v3, v5, v3
	ldr	q5, [sp, #512]                  ; 16-byte Folded Reload
	bit.16b	v5, v3, v4
	str	q5, [sp, #512]                  ; 16-byte Folded Spill
	ldr	q6, [x9, #2096]
	lsl	x10, x10, #5
	add	x10, x10, #2080
	dup.2d	v5, x10
	ldr	q3, [x9, #2080]
	add.2d	v7, v5, v10
	add.2d	v16, v5, v11
	add.2d	v17, v5, v28
	add.2d	v5, v5, v29
	str	q5, [sp, #4544]
	str	q17, [sp, #4528]
	str	q16, [sp, #4512]
	str	q7, [sp, #4496]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #400
	ldr	x9, [x9, x11]
	sub	x9, x9, x3
	add	x9, x16, x9
	ldp	q5, q7, [x9]
	ldr	x9, [sp, #496]                  ; 8-byte Folded Reload
	add	x9, x9, #65
	umulh	x10, x9, x2
	lsr	x10, x10, #2
	add	x10, x10, x10, lsl #6
	sub	x9, x9, x10
	lsl	x9, x9, #5
	add	x9, x9, #2080
	dup.2d	v16, x9
	add.2d	v17, v16, v10
	add.2d	v18, v16, v11
	add.2d	v20, v16, v28
	add.2d	v16, v16, v29
	str	q16, [sp, #4480]
	str	q20, [sp, #4464]
	str	q18, [sp, #4448]
	str	q17, [sp, #4432]
	ldr	x9, [sp, #488]                  ; 8-byte Folded Reload
	add	x9, x9, #65
	umulh	x10, x9, x2
	lsr	x10, x10, #2
	add	x10, x10, x10, lsl #6
	sub	x9, x9, x10
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #336
	ldr	x10, [x10, x11]
	sub	x10, x10, x3
	add	x4, x16, x10
	lsl	x9, x9, #5
	add	x9, x9, #2080
	dup.2d	v16, x9
	mov	b17, v9[6]
	mov.b	v17[4], v9[7]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	mov	w9, #4                          ; =0x4
	dup.2d	v18, x9
	bit.16b	v14, v18, v17
	mov	b17, v9[4]
	mov.b	v17[4], v9[5]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	bit.16b	v21, v18, v17
	str	q21, [sp, #1664]                ; 16-byte Folded Spill
	mov	b17, v9[2]
	mov.b	v17[4], v9[3]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	bit.16b	v23, v18, v17
	mov	b17, v9[0]
	mov.b	v17[4], v9[1]
	ldp	q21, q20, [x4]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	bit.16b	v25, v18, v17
	add.2d	v17, v16, v28
	mov.16b	v28, v25
	mov.16b	v25, v0
	add.2d	v18, v16, v29
	mov.16b	v0, v22
	mov.16b	v22, v24
	mov.16b	v29, v27
	str	q18, [sp, #4416]
	str	q17, [sp, #4400]
	add.2d	v17, v16, v10
	add.2d	v16, v16, v11
	str	q16, [sp, #4384]
	str	q17, [sp, #4368]
	fabs.4s	v6, v6
	ldr	q16, [sp, #1072]                ; 16-byte Folded Reload
	bit.16b	v16, v6, v4
	str	q16, [sp, #1072]                ; 16-byte Folded Spill
	fabs.4s	v6, v7
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #272
	ldr	x9, [x9, x11]
	fabs.4s	v7, v20
	sub	x9, x9, x3
	add	x9, x16, x9
	ldr	q16, [sp, #1104]                ; 16-byte Folded Reload
	bit.16b	v16, v6, v4
	str	q16, [sp, #1104]                ; 16-byte Folded Spill
	ldr	q6, [sp, #1136]                 ; 16-byte Folded Reload
	bit.16b	v6, v7, v4
	str	q6, [sp, #1136]                 ; 16-byte Folded Spill
	ldp	q7, q6, [x9]
	fabs.4s	v6, v6
	ldr	q16, [sp, #848]                 ; 16-byte Folded Reload
	bit.16b	v16, v6, v4
	str	q16, [sp, #848]                 ; 16-byte Folded Spill
	fabs.4s	v1, v1
	zip1.8b	v4, v9, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v1, v4, v1
	ldr	q6, [sp, #992]                  ; 16-byte Folded Reload
	fadd.4s	v1, v6, v1
	ldr	q6, [sp, #1024]                 ; 16-byte Folded Reload
	fadd.4s	v1, v6, v1
	ldr	q6, [sp, #1056]                 ; 16-byte Folded Reload
	fadd.4s	v1, v6, v1
	ldr	q6, [sp, #768]                  ; 16-byte Folded Reload
	fadd.4s	v1, v6, v1
	ldr	q6, [sp, #528]                  ; 16-byte Folded Reload
	bit.16b	v6, v1, v4
	str	q6, [sp, #528]                  ; 16-byte Folded Spill
	fabs.4s	v1, v3
	ldr	q3, [sp, #1088]                 ; 16-byte Folded Reload
	bit.16b	v3, v1, v4
	str	q3, [sp, #1088]                 ; 16-byte Folded Spill
	fabs.4s	v1, v5
	ldr	q3, [sp, #1120]                 ; 16-byte Folded Reload
	bit.16b	v3, v1, v4
	str	q3, [sp, #1120]                 ; 16-byte Folded Spill
	fabs.4s	v1, v21
	mov.16b	v21, v0
	ldr	q3, [sp, #1152]                 ; 16-byte Folded Reload
	bit.16b	v3, v1, v4
	str	q3, [sp, #1152]                 ; 16-byte Folded Spill
	fabs.4s	v1, v7
	ldr	q3, [sp, #864]                  ; 16-byte Folded Reload
	bit.16b	v3, v1, v4
	str	q3, [sp, #864]                  ; 16-byte Folded Spill
	mov	w9, #64                         ; =0x40
	str	x9, [sp, #616]                  ; 8-byte Folded Spill
	mov	w9, #65                         ; =0x41
	str	x9, [sp, #296]                  ; 8-byte Folded Spill
LBB0_219:                               ; %schedule.9
                                        ;   in Loop: Header=BB0_11 Depth=3
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	mov	w9, #64                         ; =0x40
	dup.2d	v1, x9
	cmgt.2d	v3, v1, v23
	cmgt.2d	v4, v1, v28
	uzp1.4s	v3, v4, v3
	ldr	q0, [sp, #1664]                 ; 16-byte Folded Reload
	cmgt.2d	v4, v1, v0
	cmgt.2d	v5, v1, v14
	uzp1.4s	v4, v4, v5
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v10, v9, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w3, s4
	umaxv.8b	b3, v3
	fmov	w9, s3
	tbz	w9, #0, LBB0_225
; %bb.220:                              ; %schedule.9
                                        ;   in Loop: Header=BB0_11 Depth=3
	cmge.2d	v3, v23, v1
	cmge.2d	v4, v28, v1
	uzp1.4s	v3, v4, v3
	ldr	q0, [sp, #1664]                 ; 16-byte Folded Reload
	cmge.2d	v4, v0, v1
	cmge.2d	v1, v14, v1
	uzp1.4s	v1, v4, v1
	uzp1.8h	v1, v3, v1
	xtn.8b	v1, v1
	and.8b	v11, v9, v1
	shl.8b	v1, v11, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w9, s1
	tst	w9, #0xff
	b.eq	LBB0_225
; %bb.221:                              ; %varying.divergent208
                                        ;   in Loop: Header=BB0_11 Depth=3
	subs	w9, w15, #1
	csel	w9, wzr, w9, lo
	and	w10, w14, #0xff
	lsr	w11, w10, w9
	tst	w11, #0x1
	str	q8, [sp, #2432]
	str	q13, [sp, #2448]
	and	x9, x9, #0x7
	add	x11, sp, #2432
	ldr	w9, [x11, x9, lsl #2]
	ccmp	w15, #0, #4, ne
	ccmp	w9, #3, #0, ne
	cset	w4, ne
	cmp	w10, #255
	b.ne	LBB0_223
; %bb.222:                              ; %varying.divergent208
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w4, #0, LBB0_603
LBB0_223:                               ; %convergence.overflow.resume211
                                        ;   in Loop: Header=BB0_11 Depth=3
	mvn	w9, w14
	rbit	w9, w9
	clz	w9, w9
	mov	w10, #255                       ; =0xff
	bics	wzr, w10, w14
	csel	w6, wzr, w9, eq
	ldrb	w9, [x5, w6, uxtw]
	and	w10, w9, #0x1
	fmov	s1, w10
	ubfx	w10, w9, #1, #1
	mov.b	v1[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v1[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v1[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v1[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v1[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v1[6], w10
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, w6, uxtw]
	and	w10, w9, #0x1
	fmov	s3, w10
	ubfx	w10, w9, #1, #1
	mov.b	v3[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v3[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v3[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v3[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v3[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v3[6], w10
	lsr	w9, w9, #7
	mov.b	v3[7], w9
	cmp	w4, #0
	csetm	w9, ne
	dup.8b	v4, w9
	bit.8b	v1, v9, v4
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x5, w6, uxtw]
	bic.8b	v1, v3, v4
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x8, w6, uxtw]
	cmp	x13, #8
	b.hs	LBB0_603
; %bb.224:                              ; %ready.overflow.resume213
                                        ;   in Loop: Header=BB0_11 Depth=3
	str	q12, [sp, #2400]
	str	q19, [sp, #2416]
	ubfiz	x9, x6, #2, #3
	add	x10, sp, #2400
	ldr	w10, [x10, x9]
	cmp	w4, #0
	csel	w10, w15, w10, ne
	str	q12, [sp, #2368]
	str	q19, [sp, #2384]
	add	x11, sp, #2368
	str	w10, [x11, x9]
	ldr	q19, [sp, #2384]
	ldr	q12, [sp, #2368]
	str	q8, [sp, #2336]
	str	q13, [sp, #2352]
	add	x10, sp, #2336
	ldr	w10, [x10, x9]
	csinc	w15, w15, w6, eq
	mov	w11, #3                         ; =0x3
	csel	w10, w11, w10, ne
	str	q8, [sp, #2304]
	str	q13, [sp, #2320]
	add	x11, sp, #2304
	str	w10, [x11, x9]
	mov	w7, #11                         ; =0xb
	mov	w11, #10                        ; =0xa
	ldr	q13, [sp, #2320]
	ldr	q8, [sp, #2304]
	b	LBB0_9
LBB0_225:                               ; %varying.coherent209
                                        ;   in Loop: Header=BB0_11 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_292
; %bb.226:                              ; %varying.coherent.true214
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov	w4, #0                          ; =0x0
	tst	w11, #0xff
	b.eq	LBB0_5
LBB0_227:                               ; %schedule.10
                                        ;   in Loop: Header=BB0_11 Depth=3
	str	q29, [sp, #1536]                ; 16-byte Folded Spill
	str	q26, [sp, #1552]                ; 16-byte Folded Spill
	str	q25, [sp, #1616]                ; 16-byte Folded Spill
	str	q22, [sp, #1568]                ; 16-byte Folded Spill
	str	q21, [sp, #1520]                ; 16-byte Folded Spill
	ldr	x9, [sp, #296]                  ; 8-byte Folded Reload
	dup.2d	v1, x9
	str	q14, [sp, #1728]                ; 16-byte Folded Spill
	add.2d	v4, v1, v14
	ldr	q0, [sp, #1664]                 ; 16-byte Folded Reload
	add.2d	v3, v1, v0
	str	q23, [sp, #1696]                ; 16-byte Folded Spill
	add.2d	v16, v1, v23
	str	q28, [sp, #1504]                ; 16-byte Folded Spill
	add.2d	v7, v1, v28
	mov	b1, v9[0]
	mov.b	v1[4], v9[1]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	mov	b5, v9[2]
	mov.b	v5[4], v9[3]
	and.16b	v6, v1, v7
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v21, v5, #0
	and.16b	v17, v21, v16
	mov	b5, v9[4]
	mov.b	v5[4], v9[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v22, v5, #0
	and.16b	v18, v22, v3
	mov	b5, v9[6]
	mov.b	v5[4], v9[7]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	and.16b	v20, v5, v4
	shl.8b	v23, v9, #7
	cmlt.8b	v23, v23, #0
	and.8b	v23, v23, v2
	mov	w9, #65                         ; =0x41
	dup.2d	v25, x9
	addv.8b	b10, v23
	and.16b	v23, v1, v25
	mvn.16b	v1, v1
	and.16b	v24, v5, v25
	mvn.16b	v5, v5
	sub.2d	v24, v24, v5
	mov.d	x11, v24[1]
	mov.d	x9, v20[1]
	sdiv	x9, x9, x11
	sub.2d	v5, v23, v1
	and.16b	v1, v21, v25
	mvn.16b	v21, v21
	sub.2d	v1, v1, v21
	and.16b	v21, v22, v25
	mvn.16b	v22, v22
	sub.2d	v25, v21, v22
	fmov	x10, d24
	fmov	x16, d20
	fmov	x2, d25
	fmov	x3, d18
	mov.d	x6, v25[1]
	sdiv	x19, x3, x2
	mov.d	x3, v18[1]
	sdiv	x20, x3, x6
	fmov	x21, d1
	fmov	x3, d17
	sdiv	x22, x3, x21
	mov.d	x7, v1[1]
	mov.d	x23, v17[1]
	fmov	x25, d5
	fmov	x3, d6
	sdiv	x26, x3, x25
	mov.d	x3, v5[1]
	mov.d	x27, v6[1]
	sdiv	x27, x27, x3
	mul	x28, x27, x3
	mul	x25, x26, x25
	fmov	d21, x25
	mov.d	v21[1], x28
	sdiv	x23, x23, x7
	mul	x25, x23, x7
	mul	x21, x22, x21
	fmov	d22, x21
	mov.d	v22[1], x25
	mul	x21, x20, x6
	mul	x2, x19, x2
	fmov	d23, x2
	mov.d	v23[1], x21
	mul	x2, x9, x11
	sdiv	x16, x16, x10
	mul	x10, x16, x10
	fmov	d26, x10
	mov.d	v26[1], x2
	sub.2d	v20, v20, v26
	sub.2d	v18, v18, v23
	add	x10, x16, x16, lsl #6
	fmov	d23, x10
	add	x9, x9, x9, lsl #6
	mov.d	v23[1], x9
	sub.2d	v17, v17, v22
	add	x9, x19, x19, lsl #6
	fmov	d22, x9
	add	x9, x20, x20, lsl #6
	mov.d	v22[1], x9
	sub.2d	v6, v6, v21
	add	x9, x22, x22, lsl #6
	fmov	d21, x9
	add	x9, x23, x23, lsl #6
	mov.d	v21[1], x9
	add	x9, x26, x26, lsl #6
	fmov	d26, x9
	add	x9, x27, x27, lsl #6
	mov.d	v26[1], x9
	add.2d	v6, v26, v6
	add.2d	v17, v21, v17
	add.2d	v18, v22, v18
	add.2d	v20, v23, v20
	shl.2d	v20, v20, #5
	shl.2d	v18, v18, #5
	fmov	w23, s10
	shl.2d	v21, v17, #5
	shl.2d	v6, v6, #5
	ldr	q17, [sp, #784]                 ; 16-byte Folded Reload
	ldr	q22, [sp, #1424]                ; 16-byte Folded Reload
	add.2d	v26, v17, v22
	add.2d	v17, v26, v20
	ldp	q0, q20, [sp, #800]             ; 32-byte Folded Reload
	ldr	q22, [sp, #1440]                ; 16-byte Folded Reload
	add.2d	v27, v0, v22
	add.2d	v18, v27, v18
	ldr	q22, [sp, #1456]                ; 16-byte Folded Reload
	add.2d	v28, v20, v22
	add.2d	v20, v28, v21
	ldr	q21, [sp, #832]                 ; 16-byte Folded Reload
	ldr	q22, [sp, #1472]                ; 16-byte Folded Reload
	add.2d	v29, v21, v22
	add.2d	v21, v29, v6
	movi.2d	v6, #0000000000000000
	movi.2d	v30, #0000000000000000
	ldr	q11, [sp, #1648]                ; 16-byte Folded Reload
	ldr	q14, [sp, #1632]                ; 16-byte Folded Reload
	str	q31, [sp, #1584]                ; 16-byte Folded Spill
	str	q11, [sp, #1648]                ; 16-byte Folded Spill
	str	q14, [sp, #1632]                ; 16-byte Folded Spill
	tbnz	w23, #0, LBB0_265
; %bb.228:                              ; %else3815
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #1, LBB0_266
LBB0_229:                               ; %else3821
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #2, LBB0_267
LBB0_230:                               ; %else3827
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #3, LBB0_268
LBB0_231:                               ; %else3833
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #4, LBB0_269
LBB0_232:                               ; %else3839
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #5, LBB0_270
LBB0_233:                               ; %else3845
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #6, LBB0_271
LBB0_234:                               ; %else3851
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbz	w23, #7, LBB0_236
LBB0_235:                               ; %cond.load3853
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v17[1]
	ld1.s	{ v30 }[3], [x9]
LBB0_236:                               ; %else3857
                                        ;   in Loop: Header=BB0_11 Depth=3
	fabs.4s	v17, v30
	fabs.4s	v6, v6
	ldr	q18, [sp, #1088]                ; 16-byte Folded Reload
	fadd.4s	v0, v18, v6
	ldr	q6, [sp, #1072]                 ; 16-byte Folded Reload
	fadd.4s	v6, v6, v17
	dup.2d	v17, x12
	add.2d	v20, v4, v17
	add.2d	v21, v3, v17
	add.2d	v18, v16, v17
	add.2d	v17, v7, v17
	mov	b22, v9[0]
	mov.b	v22[4], v9[1]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	mov	b23, v9[2]
	mov.b	v23[4], v9[3]
	and.16b	v17, v22, v17
	ushll.2d	v22, v23, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	and.16b	v18, v22, v18
	mov	b22, v9[4]
	mov.b	v22[4], v9[5]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	and.16b	v21, v22, v21
	mov	b22, v9[6]
	mov.b	v22[4], v9[7]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	and.16b	v20, v22, v20
	fmov	x9, d20
	fmov	x10, d24
	mov.d	x16, v20[1]
	sdiv	x16, x16, x11
	fmov	x2, d21
	fmov	x19, d25
	sdiv	x2, x2, x19
	mov.d	x20, v21[1]
	sdiv	x20, x20, x6
	fmov	x21, d18
	fmov	x22, d1
	sdiv	x21, x21, x22
	mov.d	x23, v18[1]
	sdiv	x23, x23, x7
	fmov	x25, d17
	fmov	x26, d5
	sdiv	x25, x25, x26
	mov.d	x27, v17[1]
	sdiv	x27, x27, x3
	mul	x28, x27, x3
	mul	x26, x25, x26
	fmov	d22, x26
	mov.d	v22[1], x28
	mul	x26, x23, x7
	mul	x22, x21, x22
	fmov	d23, x22
	mov.d	v23[1], x26
	mul	x22, x20, x6
	mul	x19, x2, x19
	fmov	d30, x19
	mov.d	v30[1], x22
	mul	x19, x16, x11
	sdiv	x9, x9, x10
	mul	x10, x9, x10
	fmov	d31, x10
	mov.d	v31[1], x19
	sub.2d	v20, v20, v31
	sub.2d	v21, v21, v30
	sub.2d	v18, v18, v23
	sub.2d	v17, v17, v22
	add	x9, x9, x9, lsl #6
	fmov	d22, x9
	add	x9, x16, x16, lsl #6
	mov.d	v22[1], x9
	add	x9, x2, x2, lsl #6
	fmov	d23, x9
	add	x9, x20, x20, lsl #6
	mov.d	v23[1], x9
	add	x9, x21, x21, lsl #6
	fmov	d30, x9
	add	x9, x23, x23, lsl #6
	mov.d	v30[1], x9
	add	x9, x25, x25, lsl #6
	fmov	d31, x9
	add	x9, x27, x27, lsl #6
	mov.d	v31[1], x9
	add.2d	v17, v31, v17
	add.2d	v18, v30, v18
	add.2d	v21, v23, v21
	add.2d	v20, v22, v20
	shl.2d	v20, v20, #5
	shl.2d	v21, v21, #5
	shl.2d	v22, v18, #5
	shl.2d	v17, v17, #5
	fmov	w23, s10
	add.2d	v18, v26, v20
	add.2d	v20, v27, v21
	add.2d	v21, v28, v22
	add.2d	v22, v29, v17
	movi.2d	v17, #0000000000000000
	movi.2d	v30, #0000000000000000
	tbnz	w23, #0, LBB0_272
; %bb.237:                              ; %else3864
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #1, LBB0_273
LBB0_238:                               ; %else3870
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #2, LBB0_274
LBB0_239:                               ; %else3876
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #3, LBB0_275
LBB0_240:                               ; %else3882
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #4, LBB0_276
LBB0_241:                               ; %else3888
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #5, LBB0_277
LBB0_242:                               ; %else3894
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #6, LBB0_278
LBB0_243:                               ; %else3900
                                        ;   in Loop: Header=BB0_11 Depth=3
	str	q6, [sp, #672]                  ; 16-byte Folded Spill
	tbz	w23, #7, LBB0_245
LBB0_244:                               ; %cond.load3902
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v18[1]
	ld1.s	{ v30 }[3], [x9]
LBB0_245:                               ; %else3906
                                        ;   in Loop: Header=BB0_11 Depth=3
	fabs.4s	v18, v30
	fabs.4s	v17, v17
	ldr	q20, [sp, #1120]                ; 16-byte Folded Reload
	fadd.4s	v30, v20, v17
	ldr	q17, [sp, #1104]                ; 16-byte Folded Reload
	fadd.4s	v31, v17, v18
	mov	w9, #2                          ; =0x2
	dup.2d	v17, x9
	add.2d	v20, v4, v17
	add.2d	v21, v3, v17
	add.2d	v18, v16, v17
	add.2d	v17, v7, v17
	mov	b22, v9[0]
	mov.b	v22[4], v9[1]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	mov	b23, v9[2]
	mov.b	v23[4], v9[3]
	and.16b	v17, v22, v17
	ushll.2d	v22, v23, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	and.16b	v18, v22, v18
	mov	b22, v9[4]
	mov.b	v22[4], v9[5]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	and.16b	v21, v22, v21
	mov	b22, v9[6]
	mov.b	v22[4], v9[7]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	and.16b	v20, v22, v20
	fmov	x9, d20
	fmov	x10, d24
	mov.d	x16, v20[1]
	sdiv	x16, x16, x11
	fmov	x2, d21
	fmov	x19, d25
	sdiv	x2, x2, x19
	mov.d	x20, v21[1]
	sdiv	x20, x20, x6
	fmov	x21, d18
	fmov	x22, d1
	sdiv	x21, x21, x22
	mov.d	x23, v18[1]
	sdiv	x23, x23, x7
	fmov	x25, d17
	fmov	x26, d5
	sdiv	x25, x25, x26
	mov.d	x27, v17[1]
	sdiv	x27, x27, x3
	mul	x28, x27, x3
	mul	x26, x25, x26
	fmov	d22, x26
	mov.d	v22[1], x28
	mul	x26, x23, x7
	mul	x22, x21, x22
	fmov	d23, x22
	mov.d	v23[1], x26
	mul	x22, x20, x6
	mul	x19, x2, x19
	fmov	d14, x19
	mov.d	v14[1], x22
	mul	x19, x16, x11
	sdiv	x9, x9, x10
	mul	x10, x9, x10
	fmov	d15, x10
	mov.d	v15[1], x19
	sub.2d	v20, v20, v15
	sub.2d	v21, v21, v14
	sub.2d	v18, v18, v23
	sub.2d	v17, v17, v22
	add	x9, x9, x9, lsl #6
	fmov	d22, x9
	add	x9, x16, x16, lsl #6
	mov.d	v22[1], x9
	add	x9, x2, x2, lsl #6
	fmov	d23, x9
	add	x9, x20, x20, lsl #6
	mov.d	v23[1], x9
	add	x9, x21, x21, lsl #6
	fmov	d14, x9
	add	x9, x23, x23, lsl #6
	mov.d	v14[1], x9
	add	x9, x25, x25, lsl #6
	fmov	d15, x9
	add	x9, x27, x27, lsl #6
	mov.d	v15[1], x9
	add.2d	v17, v15, v17
	add.2d	v18, v14, v18
	add.2d	v21, v23, v21
	add.2d	v20, v22, v20
	shl.2d	v20, v20, #5
	shl.2d	v21, v21, #5
	shl.2d	v18, v18, #5
	shl.2d	v17, v17, #5
	fmov	w23, s10
	add.2d	v20, v26, v20
	add.2d	v21, v27, v21
	add.2d	v22, v28, v18
	add.2d	v23, v29, v17
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w23, #0, LBB0_279
; %bb.246:                              ; %else3913
                                        ;   in Loop: Header=BB0_11 Depth=3
	add	x28, sp, #3, lsl #12            ; =12288
	add	x28, x28, #872
	tbnz	w23, #1, LBB0_280
LBB0_247:                               ; %else3919
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.16b	v15, v0
	tbnz	w23, #2, LBB0_281
LBB0_248:                               ; %else3925
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #3, LBB0_282
LBB0_249:                               ; %else3931
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #4, LBB0_283
LBB0_250:                               ; %else3937
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #5, LBB0_284
LBB0_251:                               ; %else3943
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #6, LBB0_285
LBB0_252:                               ; %else3949
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbz	w23, #7, LBB0_254
LBB0_253:                               ; %cond.load3951
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v20[1]
	ld1.s	{ v18 }[3], [x9]
LBB0_254:                               ; %else3955
                                        ;   in Loop: Header=BB0_11 Depth=3
	fabs.4s	v18, v18
	fabs.4s	v17, v17
	ldr	q6, [sp, #1152]                 ; 16-byte Folded Reload
	fadd.4s	v17, v6, v17
	mov	w9, #3                          ; =0x3
	dup.2d	v20, x9
	add.2d	v21, v4, v20
	add.2d	v22, v3, v20
	add.2d	v16, v16, v20
	add.2d	v3, v7, v20
	mov	b4, v9[0]
	mov.b	v4[4], v9[1]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	and.16b	v4, v4, v3
	mov	b7, v9[2]
	mov.b	v7[4], v9[3]
	ldr	q3, [sp, #1136]                 ; 16-byte Folded Reload
	fadd.4s	v3, v3, v18
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v7, v7, v16
	mov	b16, v9[4]
	mov.b	v16[4], v9[5]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	and.16b	v16, v16, v22
	mov	b18, v9[6]
	mov.b	v18[4], v9[7]
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	and.16b	v18, v18, v21
	fmov	x9, d18
	fmov	x10, d24
	mov.d	x16, v18[1]
	sdiv	x16, x16, x11
	fmov	x2, d16
	fmov	x19, d25
	sdiv	x2, x2, x19
	mov.d	x20, v16[1]
	sdiv	x20, x20, x6
	fmov	x21, d7
	fmov	x22, d1
	sdiv	x21, x21, x22
	mov.d	x23, v7[1]
	sdiv	x23, x23, x7
	fmov	x25, d4
	fmov	x26, d5
	sdiv	x25, x25, x26
	mov.d	x27, v4[1]
	sdiv	x27, x27, x3
	mul	x3, x27, x3
	mul	x26, x25, x26
	fmov	d1, x26
	mov.d	v1[1], x3
	mul	x3, x23, x7
	mul	x7, x21, x22
	fmov	d5, x7
	mov.d	v5[1], x3
	mul	x3, x20, x6
	mul	x6, x2, x19
	fmov	d20, x6
	mov.d	v20[1], x3
	mul	x11, x16, x11
	sdiv	x9, x9, x10
	mul	x10, x9, x10
	fmov	d21, x10
	mov.d	v21[1], x11
	sub.2d	v18, v18, v21
	sub.2d	v16, v16, v20
	sub.2d	v5, v7, v5
	sub.2d	v1, v4, v1
	add	x9, x9, x9, lsl #6
	fmov	d4, x9
	add	x9, x16, x16, lsl #6
	mov.d	v4[1], x9
	add	x9, x2, x2, lsl #6
	fmov	d7, x9
	add	x9, x20, x20, lsl #6
	mov.d	v7[1], x9
	add	x9, x21, x21, lsl #6
	fmov	d20, x9
	add	x9, x23, x23, lsl #6
	mov.d	v20[1], x9
	add	x9, x25, x25, lsl #6
	fmov	d21, x9
	add	x9, x27, x27, lsl #6
	mov.d	v21[1], x9
	add.2d	v1, v21, v1
	add.2d	v5, v20, v5
	add.2d	v7, v7, v16
	add.2d	v4, v4, v18
	shl.2d	v4, v4, #5
	shl.2d	v7, v7, #5
	shl.2d	v16, v5, #5
	shl.2d	v1, v1, #5
	fmov	w11, s10
	add.2d	v5, v26, v4
	add.2d	v7, v27, v7
	add.2d	v16, v28, v16
	add.2d	v18, v29, v1
	movi.2d	v1, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbz	w11, #0, LBB0_256
; %bb.255:                              ; %cond.load3958
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d18
	ldr	s1, [x9]
LBB0_256:                               ; %else3962
                                        ;   in Loop: Header=BB0_11 Depth=3
	add	x21, sp, #3, lsl #12            ; =12288
	add	x21, x21, #936
	add	x27, sp, #3, lsl #12            ; =12288
	add	x27, x27, #904
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #560
	add	x20, sp, #1, lsl #12            ; =4096
	add	x20, x20, #528
	add	x22, sp, #1, lsl #12            ; =4096
	add	x22, x22, #240
	add	x25, sp, #1, lsl #12            ; =4096
	add	x25, x25, #208
	add	x26, sp, #3952
	ldr	q21, [sp, #1520]                ; 16-byte Folded Reload
	ldr	q22, [sp, #1568]                ; 16-byte Folded Reload
	ldr	q25, [sp, #1616]                ; 16-byte Folded Reload
	ldr	q26, [sp, #1552]                ; 16-byte Folded Reload
	ldr	q29, [sp, #1536]                ; 16-byte Folded Reload
	ldr	q28, [sp, #1504]                ; 16-byte Folded Reload
	ldr	q23, [sp, #1696]                ; 16-byte Folded Reload
	ldr	q14, [sp, #1728]                ; 16-byte Folded Reload
	tbnz	w11, #1, LBB0_286
; %bb.257:                              ; %else3968
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #2, LBB0_287
LBB0_258:                               ; %else3974
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #3, LBB0_288
LBB0_259:                               ; %else3980
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #4, LBB0_289
LBB0_260:                               ; %else3986
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #5, LBB0_290
LBB0_261:                               ; %else3992
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #6, LBB0_291
LBB0_262:                               ; %else3998
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbz	w11, #7, LBB0_264
LBB0_263:                               ; %cond.load4000
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v5[1]
	ld1.s	{ v4 }[3], [x9]
LBB0_264:                               ; %else4004
                                        ;   in Loop: Header=BB0_11 Depth=3
	fabs.4s	v4, v4
	fabs.4s	v1, v1
	ldr	q6, [sp, #864]                  ; 16-byte Folded Reload
	fadd.4s	v1, v6, v1
	mov	w9, #4                          ; =0x4
	dup.2d	v5, x9
	mov	b7, v9[6]
	mov.b	v7[4], v9[7]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v7, v7, v5
	add.2d	v14, v14, v7
	mov	b7, v9[4]
	mov.b	v7[4], v9[5]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v7, v7, v5
	ldr	q0, [sp, #1664]                 ; 16-byte Folded Reload
	add.2d	v0, v0, v7
	str	q0, [sp, #1664]                 ; 16-byte Folded Spill
	mov	b7, v9[2]
	mov.b	v7[4], v9[3]
	ldr	q16, [sp, #848]                 ; 16-byte Folded Reload
	fadd.4s	v4, v16, v4
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v7, v7, v5
	add.2d	v23, v23, v7
	mov	b7, v9[0]
	mov.b	v7[4], v9[1]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v5, v7, v5
	add.2d	v28, v28, v5
	zip1.8b	v5, v9, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	zip2.8b	v7, v9, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	ldr	q18, [sp, #1072]                ; 16-byte Folded Reload
	ldr	q0, [sp, #672]                  ; 16-byte Folded Reload
	bit.16b	v18, v0, v7
	str	q18, [sp, #1072]                ; 16-byte Folded Spill
	ldr	q18, [sp, #1088]                ; 16-byte Folded Reload
	bit.16b	v18, v15, v5
	str	q18, [sp, #1088]                ; 16-byte Folded Spill
	ldr	q18, [sp, #1104]                ; 16-byte Folded Reload
	bit.16b	v18, v31, v7
	str	q18, [sp, #1104]                ; 16-byte Folded Spill
	ldr	q18, [sp, #1120]                ; 16-byte Folded Reload
	bit.16b	v18, v30, v5
	str	q18, [sp, #1120]                ; 16-byte Folded Spill
	ldr	q18, [sp, #1136]                ; 16-byte Folded Reload
	bit.16b	v18, v3, v7
	str	q18, [sp, #1136]                ; 16-byte Folded Spill
	ldr	q3, [sp, #1152]                 ; 16-byte Folded Reload
	bit.16b	v3, v17, v5
	str	q3, [sp, #1152]                 ; 16-byte Folded Spill
	bit.16b	v16, v4, v7
	bit.16b	v6, v1, v5
	stp	q16, q6, [sp, #848]             ; 32-byte Folded Spill
	ldr	q31, [sp, #1584]                ; 16-byte Folded Reload
	tbz	w4, #0, LBB0_219
	b	LBB0_5
LBB0_265:                               ; %cond.load3811
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d21
	ldr	s6, [x9]
	tbz	w23, #1, LBB0_229
LBB0_266:                               ; %cond.load3817
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v21[1]
	ld1.s	{ v6 }[1], [x9]
	tbz	w23, #2, LBB0_230
LBB0_267:                               ; %cond.load3823
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d20
	ld1.s	{ v6 }[2], [x9]
	tbz	w23, #3, LBB0_231
LBB0_268:                               ; %cond.load3829
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v20[1]
	ld1.s	{ v6 }[3], [x9]
	tbz	w23, #4, LBB0_232
LBB0_269:                               ; %cond.load3835
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d18
	ld1.s	{ v30 }[0], [x9]
	tbz	w23, #5, LBB0_233
LBB0_270:                               ; %cond.load3841
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v18[1]
	ld1.s	{ v30 }[1], [x9]
	tbz	w23, #6, LBB0_234
LBB0_271:                               ; %cond.load3847
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d17
	ld1.s	{ v30 }[2], [x9]
	tbnz	w23, #7, LBB0_235
	b	LBB0_236
LBB0_272:                               ; %cond.load3860
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d22
	ldr	s17, [x9]
	tbz	w23, #1, LBB0_238
LBB0_273:                               ; %cond.load3866
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v22[1]
	ld1.s	{ v17 }[1], [x9]
	tbz	w23, #2, LBB0_239
LBB0_274:                               ; %cond.load3872
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d21
	ld1.s	{ v17 }[2], [x9]
	tbz	w23, #3, LBB0_240
LBB0_275:                               ; %cond.load3878
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v21[1]
	ld1.s	{ v17 }[3], [x9]
	tbz	w23, #4, LBB0_241
LBB0_276:                               ; %cond.load3884
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d20
	ld1.s	{ v30 }[0], [x9]
	tbz	w23, #5, LBB0_242
LBB0_277:                               ; %cond.load3890
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v20[1]
	ld1.s	{ v30 }[1], [x9]
	tbz	w23, #6, LBB0_243
LBB0_278:                               ; %cond.load3896
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d18
	ld1.s	{ v30 }[2], [x9]
	str	q6, [sp, #672]                  ; 16-byte Folded Spill
	tbnz	w23, #7, LBB0_244
	b	LBB0_245
LBB0_279:                               ; %cond.load3909
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d23
	ldr	s17, [x9]
	add	x28, sp, #3, lsl #12            ; =12288
	add	x28, x28, #872
	tbz	w23, #1, LBB0_247
LBB0_280:                               ; %cond.load3915
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v23[1]
	ld1.s	{ v17 }[1], [x9]
	mov.16b	v15, v0
	tbz	w23, #2, LBB0_248
LBB0_281:                               ; %cond.load3921
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d22
	ld1.s	{ v17 }[2], [x9]
	tbz	w23, #3, LBB0_249
LBB0_282:                               ; %cond.load3927
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v22[1]
	ld1.s	{ v17 }[3], [x9]
	tbz	w23, #4, LBB0_250
LBB0_283:                               ; %cond.load3933
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d21
	ld1.s	{ v18 }[0], [x9]
	tbz	w23, #5, LBB0_251
LBB0_284:                               ; %cond.load3939
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v21[1]
	ld1.s	{ v18 }[1], [x9]
	tbz	w23, #6, LBB0_252
LBB0_285:                               ; %cond.load3945
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d20
	ld1.s	{ v18 }[2], [x9]
	tbnz	w23, #7, LBB0_253
	b	LBB0_254
LBB0_286:                               ; %cond.load3964
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v18[1]
	ld1.s	{ v1 }[1], [x9]
	tbz	w11, #2, LBB0_258
LBB0_287:                               ; %cond.load3970
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d16
	ld1.s	{ v1 }[2], [x9]
	tbz	w11, #3, LBB0_259
LBB0_288:                               ; %cond.load3976
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v16[1]
	ld1.s	{ v1 }[3], [x9]
	tbz	w11, #4, LBB0_260
LBB0_289:                               ; %cond.load3982
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d7
	ld1.s	{ v4 }[0], [x9]
	tbz	w11, #5, LBB0_261
LBB0_290:                               ; %cond.load3988
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v7[1]
	ld1.s	{ v4 }[1], [x9]
	tbz	w11, #6, LBB0_262
LBB0_291:                               ; %cond.load3994
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d5
	ld1.s	{ v4 }[2], [x9]
	tbnz	w11, #7, LBB0_263
	b	LBB0_264
LBB0_292:                               ; %varying.coherent.false215
                                        ;   in Loop: Header=BB0_11 Depth=3
	tst	w11, #0xff
	b.eq	LBB0_5
LBB0_293:                               ; %schedule.11
                                        ;   in Loop: Header=BB0_11 Depth=3
	cbz	w15, LBB0_298
; %bb.294:                              ; %convergence.cascade253.preheader
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov	w11, #0                         ; =0x0
LBB0_295:                               ; %convergence.cascade253
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_11 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w9, s3
	umaxv.8b	b1, v1
	fmov	w10, s1
	sub	w16, w15, #1
	tst	w9, #0xff
	csel	w4, w16, wzr, ne
	lsl	w6, w12, w4
	and	w9, w6, w14
	tst	w9, #0xff
	cset	w9, ne
	str	q8, [sp, #4336]
	str	q13, [sp, #4352]
	ubfiz	x3, x4, #2, #3
	ldr	w16, [x22, x3]
	cmp	w16, #3
	cset	w7, eq
	and	w23, w9, w10
	ldrb	w9, [x5, w4, sxtw]
	and	w10, w9, #0x1
	fmov	s1, w10
	ubfx	w10, w9, #1, #1
	mov.b	v1[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v1[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v1[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v1[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v1[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v1[6], w10
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, w4, sxtw]
	and	w10, w9, #0x1
	fmov	s3, w10
	ubfx	w10, w9, #1, #1
	mov.b	v3[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v3[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v3[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v3[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v3[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v3[6], w10
	lsr	w9, w9, #7
	mov.b	v3[7], w9
	orr.8b	v4, v9, v3
	ldr	d0, [sp, #1752]                 ; 8-byte Folded Reload
	and.8b	v5, v0, v1
	eor.8b	v5, v5, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	umaxv.8b	b5, v5
	fmov	w9, s5
	ands	w10, w23, w7
	csetm	w16, ne
	bics	w9, w10, w9
	csetm	w2, ne
	dup.8b	v5, w2
	dup.8b	v6, w16
	bic.8b	v7, v4, v5
	bit.8b	v3, v7, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w4, sxtw]
	bic.8b	v1, v1, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x5, w4, sxtw]
	csinv	w16, w0, w6, eq
	dup.8b	v1, w10
	and	w14, w16, w14
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w9
	and.8b	v3, v3, v4
	str	q12, [sp, #4304]
	str	q19, [sp, #4320]
	ldr	w9, [x25, x3]
	csel	w15, w9, w15, ne
	bit.8b	v9, v3, v1
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w3, s1
	cmp	w10, #1
	b.ne	LBB0_299
; %bb.296:                              ; %convergence.cascade253
                                        ;   in Loop: Header=BB0_295 Depth=4
	cmp	w15, #0
	ccmp	w11, #6, #2, ne
	b.hi	LBB0_299
; %bb.297:                              ; %convergence.cascade253
                                        ;   in Loop: Header=BB0_295 Depth=4
	add	w11, w11, #1
	tst	w3, #0xff
	b.ne	LBB0_295
	b	LBB0_299
LBB0_298:                               ; %schedule.11.convergence.cascade.exit254_crit_edge
                                        ;   in Loop: Header=BB0_11 Depth=3
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w3, s1
LBB0_299:                               ; %convergence.cascade.exit254
                                        ;   in Loop: Header=BB0_11 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
; %bb.300:                              ; %convergence.target.11.ready
                                        ;   in Loop: Header=BB0_11 Depth=3
	rbit	w9, w3
	ldr	x10, [sp, #616]                 ; 8-byte Folded Reload
	ldr	x11, [sp, #296]                 ; 8-byte Folded Reload
	add	x10, x11, x10
	lsl	x10, x10, #5
	dup.2d	v1, x10
	clz	w9, w9
	ldr	q10, [sp, #1472]                ; 16-byte Folded Reload
	add.2d	v3, v1, v10
	ldr	q11, [sp, #1456]                ; 16-byte Folded Reload
	add.2d	v4, v1, v11
	mov.16b	v30, v25
	mov.16b	v25, v28
	ldr	q28, [sp, #1440]                ; 16-byte Folded Reload
	add.2d	v5, v1, v28
	mov.16b	v0, v14
	mov.16b	v14, v23
	mov.16b	v27, v29
	mov.16b	v24, v22
	mov.16b	v22, v21
	ldr	q29, [sp, #1424]                ; 16-byte Folded Reload
	add.2d	v1, v1, v29
	str	q1, [sp, #4288]
	str	q5, [sp, #4272]
	str	q4, [sp, #4256]
	str	q3, [sp, #4240]
	ubfiz	x11, x9, #3, #3
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #144
	ldr	x10, [x10, x11]
	lsl	w3, w9, #2
	sub	x9, x10, x3
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #728
	add	x9, x16, x9
	ldp	q1, q3, [x9]
	fabs.4s	v4, v3
	zip2.8b	v3, v9, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	and.16b	v4, v3, v4
	ldr	q5, [sp, #1072]                 ; 16-byte Folded Reload
	fadd.4s	v4, v5, v4
	ldr	q5, [sp, #1104]                 ; 16-byte Folded Reload
	fadd.4s	v4, v5, v4
	ldr	q5, [sp, #1136]                 ; 16-byte Folded Reload
	fadd.4s	v4, v5, v4
	ldr	q5, [sp, #848]                  ; 16-byte Folded Reload
	fadd.4s	v4, v5, v4
	ldr	q5, [sp, #448]                  ; 16-byte Folded Reload
	bit.16b	v5, v4, v3
	str	q5, [sp, #448]                  ; 16-byte Folded Spill
	str	q10, [sp, #4176]
	str	q11, [sp, #4192]
	str	q28, [sp, #4208]
	str	q29, [sp, #4224]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #80
	ldr	x9, [x9, x11]
	sub	x9, x9, x3
	add	x9, x9, x16
	ldr	q6, [x9, #4176]
	ldr	q4, [x9, #4160]
	ldr	x9, [sp, #504]                  ; 8-byte Folded Reload
	add	x9, x9, #130
	mov	x2, #4033                       ; =0xfc1
	movk	x2, #49404, lsl #16
	movk	x2, #64527, lsl #32
	movk	x2, #4032, lsl #48
	umulh	x10, x9, x2
	lsr	x10, x10, #2
	add	x10, x10, x10, lsl #6
	sub	x9, x9, x10
	mov	w4, #4160                       ; =0x1040
	add	x9, x4, x9, lsl #5
	dup.2d	v5, x9
	add.2d	v7, v5, v10
	add.2d	v16, v5, v11
	add.2d	v17, v5, v28
	add.2d	v5, v5, v29
	str	q5, [sp, #4160]
	str	q17, [sp, #4144]
	str	q16, [sp, #4128]
	str	q7, [sp, #4112]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #16
	ldr	x9, [x9, x11]
	sub	x9, x9, x3
	add	x9, x16, x9
	ldp	q5, q7, [x9]
	ldr	x9, [sp, #496]                  ; 8-byte Folded Reload
	add	x9, x9, #130
	umulh	x10, x9, x2
	lsr	x10, x10, #2
	add	x10, x10, x10, lsl #6
	sub	x9, x9, x10
	add	x9, x4, x9, lsl #5
	dup.2d	v16, x9
	add.2d	v17, v16, v10
	add.2d	v18, v16, v11
	add.2d	v20, v16, v28
	add.2d	v16, v16, v29
	str	q16, [sp, #4096]
	str	q20, [sp, #4080]
	str	q18, [sp, #4064]
	str	q17, [sp, #4048]
	ldr	x9, [sp, #488]                  ; 8-byte Folded Reload
	add	x9, x9, #130
	umulh	x10, x9, x2
	lsr	x10, x10, #2
	add	x10, x10, x10, lsl #6
	sub	x9, x9, x10
	add	x10, sp, #4048
	ldr	x10, [x10, x11]
	add	x9, x4, x9, lsl #5
	dup.2d	v16, x9
	mov	b17, v9[6]
	mov.b	v17[4], v9[7]
	sub	x9, x10, x3
	add	x9, x16, x9
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	mov	w10, #4                         ; =0x4
	dup.2d	v18, x10
	bit.16b	v27, v18, v17
	mov	b17, v9[4]
	mov.b	v17[4], v9[5]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	bit.16b	v26, v18, v17
	mov	b17, v9[2]
	mov.b	v17[4], v9[3]
	ldp	q21, q20, [x9]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	ldr	q23, [sp, #1680]                ; 16-byte Folded Reload
	bit.16b	v23, v18, v17
	str	q23, [sp, #1680]                ; 16-byte Folded Spill
	mov	b17, v9[0]
	mov.b	v17[4], v9[1]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	bit.16b	v30, v18, v17
	add.2d	v17, v16, v28
	mov.16b	v28, v25
	mov.16b	v25, v30
	add.2d	v18, v16, v29
	mov.16b	v30, v22
	mov.16b	v22, v24
	mov.16b	v29, v27
	mov.16b	v23, v14
	mov.16b	v14, v0
	str	q18, [sp, #4032]
	str	q17, [sp, #4016]
	add.2d	v17, v16, v10
	add.2d	v16, v16, v11
	str	q16, [sp, #4000]
	str	q17, [sp, #3984]
	fabs.4s	v6, v6
	ldr	q16, [sp, #1168]                ; 16-byte Folded Reload
	bit.16b	v16, v6, v3
	str	q16, [sp, #1168]                ; 16-byte Folded Spill
	fabs.4s	v6, v7
	fabs.4s	v7, v20
	add	x9, sp, #3984
	ldr	x9, [x9, x11]
	sub	x9, x9, x3
	add	x9, x16, x9
	ldr	q16, [sp, #1200]                ; 16-byte Folded Reload
	bit.16b	v16, v6, v3
	str	q16, [sp, #1200]                ; 16-byte Folded Spill
	ldr	q6, [sp, #1232]                 ; 16-byte Folded Reload
	bit.16b	v6, v7, v3
	str	q6, [sp, #1232]                 ; 16-byte Folded Spill
	ldp	q7, q6, [x9]
	fabs.4s	v6, v6
	ldr	q16, [sp, #880]                 ; 16-byte Folded Reload
	bit.16b	v16, v6, v3
	str	q16, [sp, #880]                 ; 16-byte Folded Spill
	fabs.4s	v1, v1
	zip1.8b	v3, v9, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	and.16b	v1, v3, v1
	ldr	q6, [sp, #1088]                 ; 16-byte Folded Reload
	fadd.4s	v1, v6, v1
	ldr	q6, [sp, #1120]                 ; 16-byte Folded Reload
	fadd.4s	v1, v6, v1
	ldr	q6, [sp, #1152]                 ; 16-byte Folded Reload
	fadd.4s	v1, v6, v1
	ldr	q6, [sp, #864]                  ; 16-byte Folded Reload
	fadd.4s	v1, v6, v1
	ldr	q6, [sp, #464]                  ; 16-byte Folded Reload
	bit.16b	v6, v1, v3
	str	q6, [sp, #464]                  ; 16-byte Folded Spill
	fabs.4s	v1, v4
	ldr	q4, [sp, #1184]                 ; 16-byte Folded Reload
	bit.16b	v4, v1, v3
	str	q4, [sp, #1184]                 ; 16-byte Folded Spill
	fabs.4s	v1, v5
	ldr	q4, [sp, #1216]                 ; 16-byte Folded Reload
	bit.16b	v4, v1, v3
	str	q4, [sp, #1216]                 ; 16-byte Folded Spill
	fabs.4s	v1, v21
	mov.16b	v21, v30
	ldr	q4, [sp, #1248]                 ; 16-byte Folded Reload
	bit.16b	v4, v1, v3
	str	q4, [sp, #1248]                 ; 16-byte Folded Spill
	fabs.4s	v1, v7
	ldr	q4, [sp, #896]                  ; 16-byte Folded Reload
	bit.16b	v4, v1, v3
	str	q4, [sp, #896]                  ; 16-byte Folded Spill
	mov	w9, #130                        ; =0x82
	str	x9, [sp, #368]                  ; 8-byte Folded Spill
LBB0_301:                               ; %schedule.12
                                        ;   in Loop: Header=BB0_11 Depth=3
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	mov	w9, #64                         ; =0x40
	dup.2d	v1, x9
	ldr	q0, [sp, #1680]                 ; 16-byte Folded Reload
	cmgt.2d	v3, v1, v0
	cmgt.2d	v4, v1, v25
	uzp1.4s	v3, v4, v3
	cmgt.2d	v4, v1, v26
	cmgt.2d	v5, v1, v29
	uzp1.4s	v4, v4, v5
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v10, v9, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w3, s4
	umaxv.8b	b3, v3
	fmov	w9, s3
	tbz	w9, #0, LBB0_307
; %bb.302:                              ; %schedule.12
                                        ;   in Loop: Header=BB0_11 Depth=3
	ldr	q0, [sp, #1680]                 ; 16-byte Folded Reload
	cmge.2d	v3, v0, v1
	cmge.2d	v4, v25, v1
	uzp1.4s	v3, v4, v3
	cmge.2d	v4, v26, v1
	cmge.2d	v1, v29, v1
	uzp1.4s	v1, v4, v1
	uzp1.8h	v1, v3, v1
	xtn.8b	v1, v1
	and.8b	v11, v9, v1
	shl.8b	v1, v11, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w9, s1
	tst	w9, #0xff
	b.eq	LBB0_307
; %bb.303:                              ; %varying.divergent315
                                        ;   in Loop: Header=BB0_11 Depth=3
	subs	w9, w15, #1
	csel	w9, wzr, w9, lo
	and	w10, w14, #0xff
	lsr	w11, w10, w9
	tst	w11, #0x1
	str	q8, [sp, #2592]
	str	q13, [sp, #2608]
	and	x9, x9, #0x7
	add	x11, sp, #2592
	ldr	w9, [x11, x9, lsl #2]
	ccmp	w15, #0, #4, ne
	ccmp	w9, #4, #0, ne
	cset	w4, ne
	cmp	w10, #255
	b.ne	LBB0_305
; %bb.304:                              ; %varying.divergent315
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w4, #0, LBB0_603
LBB0_305:                               ; %convergence.overflow.resume318
                                        ;   in Loop: Header=BB0_11 Depth=3
	mvn	w9, w14
	rbit	w9, w9
	clz	w9, w9
	mov	w10, #255                       ; =0xff
	bics	wzr, w10, w14
	csel	w6, wzr, w9, eq
	ldrb	w9, [x5, w6, uxtw]
	and	w10, w9, #0x1
	fmov	s1, w10
	ubfx	w10, w9, #1, #1
	mov.b	v1[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v1[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v1[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v1[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v1[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v1[6], w10
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, w6, uxtw]
	and	w10, w9, #0x1
	fmov	s3, w10
	ubfx	w10, w9, #1, #1
	mov.b	v3[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v3[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v3[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v3[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v3[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v3[6], w10
	lsr	w9, w9, #7
	mov.b	v3[7], w9
	cmp	w4, #0
	csetm	w9, ne
	dup.8b	v4, w9
	bit.8b	v1, v9, v4
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x5, w6, uxtw]
	bic.8b	v1, v3, v4
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x8, w6, uxtw]
	cmp	x13, #8
	b.hs	LBB0_603
; %bb.306:                              ; %ready.overflow.resume320
                                        ;   in Loop: Header=BB0_11 Depth=3
	str	q12, [sp, #2560]
	str	q19, [sp, #2576]
	ubfiz	x9, x6, #2, #3
	add	x10, sp, #2560
	ldr	w10, [x10, x9]
	cmp	w4, #0
	csel	w10, w15, w10, ne
	str	q12, [sp, #2528]
	str	q19, [sp, #2544]
	add	x11, sp, #2528
	str	w10, [x11, x9]
	ldr	q19, [sp, #2544]
	ldr	q12, [sp, #2528]
	str	q8, [sp, #2496]
	str	q13, [sp, #2512]
	add	x10, sp, #2496
	ldr	w10, [x10, x9]
	csinc	w15, w15, w6, eq
	mov	w11, #4                         ; =0x4
	csel	w10, w11, w10, ne
	str	q8, [sp, #2464]
	str	q13, [sp, #2480]
	add	x11, sp, #2464
	str	w10, [x11, x9]
	mov	w7, #14                         ; =0xe
	mov	w11, #13                        ; =0xd
	ldr	q13, [sp, #2480]
	ldr	q8, [sp, #2464]
	b	LBB0_9
LBB0_307:                               ; %varying.coherent316
                                        ;   in Loop: Header=BB0_11 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_374
; %bb.308:                              ; %varying.coherent.true321
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov	w4, #0                          ; =0x0
	tst	w11, #0xff
	b.eq	LBB0_5
LBB0_309:                               ; %schedule.13
                                        ;   in Loop: Header=BB0_11 Depth=3
	str	q14, [sp, #1728]                ; 16-byte Folded Spill
	str	q23, [sp, #1696]                ; 16-byte Folded Spill
	str	q28, [sp, #1504]                ; 16-byte Folded Spill
	str	q22, [sp, #1568]                ; 16-byte Folded Spill
	str	q21, [sp, #1520]                ; 16-byte Folded Spill
	ldr	x9, [sp, #368]                  ; 8-byte Folded Reload
	dup.2d	v1, x9
	str	q29, [sp, #1536]                ; 16-byte Folded Spill
	add.2d	v16, v1, v29
	str	q26, [sp, #1552]                ; 16-byte Folded Spill
	add.2d	v7, v1, v26
	ldr	q0, [sp, #1680]                 ; 16-byte Folded Reload
	add.2d	v4, v1, v0
	str	q25, [sp, #1616]                ; 16-byte Folded Spill
	add.2d	v3, v1, v25
	mov	b1, v9[0]
	mov.b	v1[4], v9[1]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	mov	b5, v9[2]
	mov.b	v5[4], v9[3]
	and.16b	v6, v1, v3
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v21, v5, #0
	and.16b	v17, v21, v4
	mov	b5, v9[4]
	mov.b	v5[4], v9[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v22, v5, #0
	and.16b	v18, v22, v7
	mov	b5, v9[6]
	mov.b	v5[4], v9[7]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	and.16b	v20, v5, v16
	shl.8b	v23, v9, #7
	cmlt.8b	v23, v23, #0
	and.8b	v23, v23, v2
	mov	w9, #65                         ; =0x41
	dup.2d	v25, x9
	addv.8b	b10, v23
	and.16b	v23, v1, v25
	mvn.16b	v1, v1
	and.16b	v24, v5, v25
	mvn.16b	v5, v5
	sub.2d	v24, v24, v5
	mov.d	x11, v24[1]
	mov.d	x9, v20[1]
	sdiv	x9, x9, x11
	sub.2d	v5, v23, v1
	and.16b	v1, v21, v25
	mvn.16b	v21, v21
	sub.2d	v1, v1, v21
	and.16b	v21, v22, v25
	mvn.16b	v22, v22
	sub.2d	v25, v21, v22
	fmov	x10, d24
	fmov	x16, d20
	fmov	x2, d25
	fmov	x3, d18
	mov.d	x6, v25[1]
	sdiv	x19, x3, x2
	mov.d	x3, v18[1]
	sdiv	x20, x3, x6
	fmov	x21, d1
	fmov	x3, d17
	sdiv	x22, x3, x21
	mov.d	x7, v1[1]
	mov.d	x23, v17[1]
	fmov	x25, d5
	fmov	x3, d6
	sdiv	x26, x3, x25
	mov.d	x3, v5[1]
	mov.d	x27, v6[1]
	sdiv	x27, x27, x3
	mul	x28, x27, x3
	mul	x25, x26, x25
	fmov	d21, x25
	mov.d	v21[1], x28
	sdiv	x23, x23, x7
	mul	x25, x23, x7
	mul	x21, x22, x21
	fmov	d22, x21
	mov.d	v22[1], x25
	mul	x21, x20, x6
	mul	x2, x19, x2
	fmov	d23, x2
	mov.d	v23[1], x21
	mul	x2, x9, x11
	sdiv	x16, x16, x10
	mul	x10, x16, x10
	fmov	d26, x10
	mov.d	v26[1], x2
	sub.2d	v20, v20, v26
	sub.2d	v18, v18, v23
	add	x10, x16, x16, lsl #6
	fmov	d23, x10
	add	x9, x9, x9, lsl #6
	mov.d	v23[1], x9
	sub.2d	v17, v17, v22
	add	x9, x19, x19, lsl #6
	fmov	d22, x9
	add	x9, x20, x20, lsl #6
	mov.d	v22[1], x9
	sub.2d	v6, v6, v21
	add	x9, x22, x22, lsl #6
	fmov	d21, x9
	add	x9, x23, x23, lsl #6
	mov.d	v21[1], x9
	add	x9, x26, x26, lsl #6
	fmov	d26, x9
	add	x9, x27, x27, lsl #6
	mov.d	v26[1], x9
	add.2d	v6, v26, v6
	add.2d	v17, v21, v17
	add.2d	v18, v22, v18
	add.2d	v20, v23, v20
	shl.2d	v20, v20, #5
	shl.2d	v18, v18, #5
	fmov	w23, s10
	shl.2d	v21, v17, #5
	shl.2d	v6, v6, #5
	ldr	q17, [sp, #784]                 ; 16-byte Folded Reload
	ldr	q22, [sp, #1424]                ; 16-byte Folded Reload
	add.2d	v26, v17, v22
	add.2d	v17, v26, v20
	ldr	q20, [sp, #800]                 ; 16-byte Folded Reload
	ldr	q22, [sp, #1440]                ; 16-byte Folded Reload
	add.2d	v27, v20, v22
	add.2d	v20, v27, v18
	ldp	q0, q18, [sp, #816]             ; 32-byte Folded Reload
	ldr	q22, [sp, #1456]                ; 16-byte Folded Reload
	add.2d	v28, v0, v22
	add.2d	v21, v28, v21
	ldr	q22, [sp, #1472]                ; 16-byte Folded Reload
	add.2d	v29, v18, v22
	add.2d	v22, v29, v6
	movi.2d	v6, #0000000000000000
	movi.2d	v18, #0000000000000000
	ldr	q11, [sp, #1648]                ; 16-byte Folded Reload
	ldr	q14, [sp, #1632]                ; 16-byte Folded Reload
	str	q31, [sp, #1584]                ; 16-byte Folded Spill
	str	q11, [sp, #1648]                ; 16-byte Folded Spill
	str	q14, [sp, #1632]                ; 16-byte Folded Spill
	tbnz	w23, #0, LBB0_347
; %bb.310:                              ; %else4011
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #1, LBB0_348
LBB0_311:                               ; %else4017
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #2, LBB0_349
LBB0_312:                               ; %else4023
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #3, LBB0_350
LBB0_313:                               ; %else4029
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #4, LBB0_351
LBB0_314:                               ; %else4035
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #5, LBB0_352
LBB0_315:                               ; %else4041
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #6, LBB0_353
LBB0_316:                               ; %else4047
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbz	w23, #7, LBB0_318
LBB0_317:                               ; %cond.load4049
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v17[1]
	ld1.s	{ v18 }[3], [x9]
LBB0_318:                               ; %else4053
                                        ;   in Loop: Header=BB0_11 Depth=3
	fabs.4s	v17, v18
	fabs.4s	v6, v6
	ldr	q18, [sp, #1184]                ; 16-byte Folded Reload
	fadd.4s	v0, v18, v6
	str	q0, [sp, #672]                  ; 16-byte Folded Spill
	ldr	q6, [sp, #1168]                 ; 16-byte Folded Reload
	fadd.4s	v0, v6, v17
	str	q0, [sp, #656]                  ; 16-byte Folded Spill
	dup.2d	v17, x12
	add.2d	v20, v16, v17
	add.2d	v21, v7, v17
	add.2d	v18, v4, v17
	add.2d	v17, v3, v17
	mov	b22, v9[0]
	mov.b	v22[4], v9[1]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	mov	b23, v9[2]
	mov.b	v23[4], v9[3]
	and.16b	v17, v22, v17
	ushll.2d	v22, v23, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	and.16b	v18, v22, v18
	mov	b22, v9[4]
	mov.b	v22[4], v9[5]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	and.16b	v21, v22, v21
	mov	b22, v9[6]
	mov.b	v22[4], v9[7]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	and.16b	v20, v22, v20
	fmov	x9, d20
	fmov	x10, d24
	mov.d	x16, v20[1]
	sdiv	x16, x16, x11
	fmov	x2, d21
	fmov	x19, d25
	sdiv	x2, x2, x19
	mov.d	x20, v21[1]
	sdiv	x20, x20, x6
	fmov	x21, d18
	fmov	x22, d1
	sdiv	x21, x21, x22
	mov.d	x23, v18[1]
	sdiv	x23, x23, x7
	fmov	x25, d17
	fmov	x26, d5
	sdiv	x25, x25, x26
	mov.d	x27, v17[1]
	sdiv	x27, x27, x3
	mul	x28, x27, x3
	mul	x26, x25, x26
	fmov	d22, x26
	mov.d	v22[1], x28
	mul	x26, x23, x7
	mul	x22, x21, x22
	fmov	d23, x22
	mov.d	v23[1], x26
	mul	x22, x20, x6
	mul	x19, x2, x19
	fmov	d30, x19
	mov.d	v30[1], x22
	mul	x19, x16, x11
	sdiv	x9, x9, x10
	mul	x10, x9, x10
	fmov	d31, x10
	mov.d	v31[1], x19
	sub.2d	v20, v20, v31
	sub.2d	v21, v21, v30
	sub.2d	v18, v18, v23
	sub.2d	v17, v17, v22
	add	x9, x9, x9, lsl #6
	fmov	d22, x9
	add	x9, x16, x16, lsl #6
	mov.d	v22[1], x9
	add	x9, x2, x2, lsl #6
	fmov	d23, x9
	add	x9, x20, x20, lsl #6
	mov.d	v23[1], x9
	add	x9, x21, x21, lsl #6
	fmov	d30, x9
	add	x9, x23, x23, lsl #6
	mov.d	v30[1], x9
	add	x9, x25, x25, lsl #6
	fmov	d31, x9
	add	x9, x27, x27, lsl #6
	mov.d	v31[1], x9
	add.2d	v17, v31, v17
	add.2d	v18, v30, v18
	add.2d	v21, v23, v21
	add.2d	v20, v22, v20
	shl.2d	v20, v20, #5
	shl.2d	v21, v21, #5
	shl.2d	v18, v18, #5
	shl.2d	v17, v17, #5
	fmov	w23, s10
	add.2d	v20, v26, v20
	add.2d	v21, v27, v21
	add.2d	v22, v28, v18
	add.2d	v23, v29, v17
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w23, #0, LBB0_354
; %bb.319:                              ; %else4060
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #1, LBB0_355
LBB0_320:                               ; %else4066
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #2, LBB0_356
LBB0_321:                               ; %else4072
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #3, LBB0_357
LBB0_322:                               ; %else4078
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #4, LBB0_358
LBB0_323:                               ; %else4084
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #5, LBB0_359
LBB0_324:                               ; %else4090
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #6, LBB0_360
LBB0_325:                               ; %else4096
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbz	w23, #7, LBB0_327
LBB0_326:                               ; %cond.load4098
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v20[1]
	ld1.s	{ v18 }[3], [x9]
LBB0_327:                               ; %else4102
                                        ;   in Loop: Header=BB0_11 Depth=3
	fabs.4s	v18, v18
	fabs.4s	v17, v17
	ldr	q20, [sp, #1216]                ; 16-byte Folded Reload
	fadd.4s	v30, v20, v17
	ldr	q17, [sp, #1200]                ; 16-byte Folded Reload
	fadd.4s	v31, v17, v18
	mov	w9, #2                          ; =0x2
	dup.2d	v17, x9
	add.2d	v20, v16, v17
	add.2d	v21, v7, v17
	add.2d	v18, v4, v17
	add.2d	v17, v3, v17
	mov	b22, v9[0]
	mov.b	v22[4], v9[1]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	mov	b23, v9[2]
	mov.b	v23[4], v9[3]
	and.16b	v17, v22, v17
	ushll.2d	v22, v23, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	and.16b	v18, v22, v18
	mov	b22, v9[4]
	mov.b	v22[4], v9[5]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	and.16b	v21, v22, v21
	mov	b22, v9[6]
	mov.b	v22[4], v9[7]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	and.16b	v20, v22, v20
	fmov	x9, d20
	fmov	x10, d24
	mov.d	x16, v20[1]
	sdiv	x16, x16, x11
	fmov	x2, d21
	fmov	x19, d25
	sdiv	x2, x2, x19
	mov.d	x20, v21[1]
	sdiv	x20, x20, x6
	fmov	x21, d18
	fmov	x22, d1
	sdiv	x21, x21, x22
	mov.d	x23, v18[1]
	sdiv	x23, x23, x7
	fmov	x25, d17
	fmov	x26, d5
	sdiv	x25, x25, x26
	mov.d	x27, v17[1]
	sdiv	x27, x27, x3
	mul	x28, x27, x3
	mul	x26, x25, x26
	fmov	d22, x26
	mov.d	v22[1], x28
	mul	x26, x23, x7
	mul	x22, x21, x22
	fmov	d23, x22
	mov.d	v23[1], x26
	mul	x22, x20, x6
	mul	x19, x2, x19
	fmov	d14, x19
	mov.d	v14[1], x22
	mul	x19, x16, x11
	sdiv	x9, x9, x10
	mul	x10, x9, x10
	fmov	d15, x10
	mov.d	v15[1], x19
	sub.2d	v20, v20, v15
	sub.2d	v21, v21, v14
	sub.2d	v18, v18, v23
	sub.2d	v17, v17, v22
	add	x9, x9, x9, lsl #6
	fmov	d22, x9
	add	x9, x16, x16, lsl #6
	mov.d	v22[1], x9
	add	x9, x2, x2, lsl #6
	fmov	d23, x9
	add	x9, x20, x20, lsl #6
	mov.d	v23[1], x9
	add	x9, x21, x21, lsl #6
	fmov	d14, x9
	add	x9, x23, x23, lsl #6
	mov.d	v14[1], x9
	add	x9, x25, x25, lsl #6
	fmov	d15, x9
	add	x9, x27, x27, lsl #6
	mov.d	v15[1], x9
	add.2d	v17, v15, v17
	add.2d	v18, v14, v18
	add.2d	v21, v23, v21
	add.2d	v20, v22, v20
	shl.2d	v20, v20, #5
	shl.2d	v21, v21, #5
	shl.2d	v18, v18, #5
	shl.2d	v17, v17, #5
	fmov	w23, s10
	add.2d	v20, v26, v20
	add.2d	v21, v27, v21
	add.2d	v22, v28, v18
	add.2d	v23, v29, v17
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w23, #0, LBB0_361
; %bb.328:                              ; %else4109
                                        ;   in Loop: Header=BB0_11 Depth=3
	add	x28, sp, #3, lsl #12            ; =12288
	add	x28, x28, #872
	tbnz	w23, #1, LBB0_362
LBB0_329:                               ; %else4115
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #2, LBB0_363
LBB0_330:                               ; %else4121
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #3, LBB0_364
LBB0_331:                               ; %else4127
                                        ;   in Loop: Header=BB0_11 Depth=3
	ldr	q22, [sp, #1568]                ; 16-byte Folded Reload
	tbnz	w23, #4, LBB0_365
LBB0_332:                               ; %else4133
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #5, LBB0_366
LBB0_333:                               ; %else4139
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #6, LBB0_367
LBB0_334:                               ; %else4145
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbz	w23, #7, LBB0_336
LBB0_335:                               ; %cond.load4147
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v20[1]
	ld1.s	{ v18 }[3], [x9]
LBB0_336:                               ; %else4151
                                        ;   in Loop: Header=BB0_11 Depth=3
	fabs.4s	v18, v18
	fabs.4s	v17, v17
	ldr	q6, [sp, #1248]                 ; 16-byte Folded Reload
	fadd.4s	v17, v6, v17
	mov	w9, #3                          ; =0x3
	dup.2d	v20, x9
	add.2d	v16, v16, v20
	add.2d	v21, v7, v20
	add.2d	v7, v4, v20
	add.2d	v3, v3, v20
	mov	b4, v9[0]
	mov.b	v4[4], v9[1]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	and.16b	v4, v4, v3
	mov	b20, v9[2]
	mov.b	v20[4], v9[3]
	ldr	q3, [sp, #1232]                 ; 16-byte Folded Reload
	fadd.4s	v3, v3, v18
	ushll.2d	v18, v20, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	and.16b	v7, v18, v7
	mov	b18, v9[4]
	mov.b	v18[4], v9[5]
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	and.16b	v18, v18, v21
	mov	b20, v9[6]
	mov.b	v20[4], v9[7]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	and.16b	v16, v20, v16
	fmov	x9, d16
	fmov	x10, d24
	mov.d	x16, v16[1]
	sdiv	x16, x16, x11
	fmov	x2, d18
	fmov	x19, d25
	sdiv	x2, x2, x19
	mov.d	x20, v18[1]
	sdiv	x20, x20, x6
	fmov	x21, d7
	fmov	x22, d1
	sdiv	x21, x21, x22
	mov.d	x23, v7[1]
	sdiv	x23, x23, x7
	fmov	x25, d4
	fmov	x26, d5
	sdiv	x25, x25, x26
	mov.d	x27, v4[1]
	sdiv	x27, x27, x3
	mul	x3, x27, x3
	mul	x26, x25, x26
	fmov	d1, x26
	mov.d	v1[1], x3
	mul	x3, x23, x7
	mul	x7, x21, x22
	fmov	d5, x7
	mov.d	v5[1], x3
	mul	x3, x20, x6
	mul	x6, x2, x19
	fmov	d20, x6
	mov.d	v20[1], x3
	mul	x11, x16, x11
	sdiv	x9, x9, x10
	mul	x10, x9, x10
	fmov	d21, x10
	mov.d	v21[1], x11
	sub.2d	v16, v16, v21
	sub.2d	v18, v18, v20
	sub.2d	v5, v7, v5
	sub.2d	v1, v4, v1
	add	x9, x9, x9, lsl #6
	fmov	d4, x9
	add	x9, x16, x16, lsl #6
	mov.d	v4[1], x9
	add	x9, x2, x2, lsl #6
	fmov	d7, x9
	add	x9, x20, x20, lsl #6
	mov.d	v7[1], x9
	add	x9, x21, x21, lsl #6
	fmov	d20, x9
	add	x9, x23, x23, lsl #6
	mov.d	v20[1], x9
	add	x9, x25, x25, lsl #6
	fmov	d21, x9
	add	x9, x27, x27, lsl #6
	mov.d	v21[1], x9
	add.2d	v1, v21, v1
	add.2d	v5, v20, v5
	add.2d	v7, v7, v18
	add.2d	v4, v4, v16
	shl.2d	v4, v4, #5
	shl.2d	v7, v7, #5
	shl.2d	v16, v5, #5
	shl.2d	v1, v1, #5
	fmov	w11, s10
	add.2d	v5, v26, v4
	add.2d	v7, v27, v7
	add.2d	v16, v28, v16
	add.2d	v18, v29, v1
	movi.2d	v1, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbz	w11, #0, LBB0_338
; %bb.337:                              ; %cond.load4154
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d18
	ldr	s1, [x9]
LBB0_338:                               ; %else4158
                                        ;   in Loop: Header=BB0_11 Depth=3
	add	x21, sp, #3, lsl #12            ; =12288
	add	x21, x21, #936
	add	x27, sp, #3, lsl #12            ; =12288
	add	x27, x27, #904
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #560
	add	x20, sp, #1, lsl #12            ; =4096
	add	x20, x20, #528
	add	x22, sp, #1, lsl #12            ; =4096
	add	x22, x22, #240
	add	x25, sp, #1, lsl #12            ; =4096
	add	x25, x25, #208
	add	x26, sp, #3952
	ldr	q21, [sp, #1520]                ; 16-byte Folded Reload
	ldr	q25, [sp, #1616]                ; 16-byte Folded Reload
	ldr	q26, [sp, #1552]                ; 16-byte Folded Reload
	ldr	q29, [sp, #1536]                ; 16-byte Folded Reload
	ldr	q28, [sp, #1504]                ; 16-byte Folded Reload
	ldr	q23, [sp, #1696]                ; 16-byte Folded Reload
	ldr	q14, [sp, #1728]                ; 16-byte Folded Reload
	tbnz	w11, #1, LBB0_368
; %bb.339:                              ; %else4164
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #2, LBB0_369
LBB0_340:                               ; %else4170
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #3, LBB0_370
LBB0_341:                               ; %else4176
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #4, LBB0_371
LBB0_342:                               ; %else4182
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #5, LBB0_372
LBB0_343:                               ; %else4188
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #6, LBB0_373
LBB0_344:                               ; %else4194
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbz	w11, #7, LBB0_346
LBB0_345:                               ; %cond.load4196
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v5[1]
	ld1.s	{ v4 }[3], [x9]
LBB0_346:                               ; %else4200
                                        ;   in Loop: Header=BB0_11 Depth=3
	fabs.4s	v4, v4
	fabs.4s	v1, v1
	ldp	q16, q6, [sp, #880]             ; 32-byte Folded Reload
	fadd.4s	v1, v6, v1
	mov	w9, #4                          ; =0x4
	dup.2d	v5, x9
	mov	b7, v9[6]
	mov.b	v7[4], v9[7]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v7, v7, v5
	add.2d	v29, v29, v7
	mov	b7, v9[4]
	mov.b	v7[4], v9[5]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v7, v7, v5
	add.2d	v26, v26, v7
	mov	b7, v9[2]
	mov.b	v7[4], v9[3]
	fadd.4s	v4, v16, v4
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v7, v7, v5
	ldr	q0, [sp, #1680]                 ; 16-byte Folded Reload
	add.2d	v0, v0, v7
	str	q0, [sp, #1680]                 ; 16-byte Folded Spill
	mov	b7, v9[0]
	mov.b	v7[4], v9[1]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v5, v7, v5
	add.2d	v25, v25, v5
	zip1.8b	v5, v9, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	zip2.8b	v7, v9, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	ldr	q18, [sp, #1168]                ; 16-byte Folded Reload
	ldr	q0, [sp, #656]                  ; 16-byte Folded Reload
	bit.16b	v18, v0, v7
	str	q18, [sp, #1168]                ; 16-byte Folded Spill
	ldr	q18, [sp, #1184]                ; 16-byte Folded Reload
	ldr	q0, [sp, #672]                  ; 16-byte Folded Reload
	bit.16b	v18, v0, v5
	str	q18, [sp, #1184]                ; 16-byte Folded Spill
	ldr	q18, [sp, #1200]                ; 16-byte Folded Reload
	bit.16b	v18, v31, v7
	str	q18, [sp, #1200]                ; 16-byte Folded Spill
	ldr	q18, [sp, #1216]                ; 16-byte Folded Reload
	bit.16b	v18, v30, v5
	str	q18, [sp, #1216]                ; 16-byte Folded Spill
	ldr	q18, [sp, #1232]                ; 16-byte Folded Reload
	bit.16b	v18, v3, v7
	str	q18, [sp, #1232]                ; 16-byte Folded Spill
	ldr	q3, [sp, #1248]                 ; 16-byte Folded Reload
	bit.16b	v3, v17, v5
	str	q3, [sp, #1248]                 ; 16-byte Folded Spill
	bit.16b	v16, v4, v7
	bit.16b	v6, v1, v5
	stp	q16, q6, [sp, #880]             ; 32-byte Folded Spill
	ldr	q31, [sp, #1584]                ; 16-byte Folded Reload
	tbz	w4, #0, LBB0_301
	b	LBB0_5
LBB0_347:                               ; %cond.load4007
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d22
	ldr	s6, [x9]
	tbz	w23, #1, LBB0_311
LBB0_348:                               ; %cond.load4013
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v22[1]
	ld1.s	{ v6 }[1], [x9]
	tbz	w23, #2, LBB0_312
LBB0_349:                               ; %cond.load4019
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d21
	ld1.s	{ v6 }[2], [x9]
	tbz	w23, #3, LBB0_313
LBB0_350:                               ; %cond.load4025
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v21[1]
	ld1.s	{ v6 }[3], [x9]
	tbz	w23, #4, LBB0_314
LBB0_351:                               ; %cond.load4031
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d20
	ld1.s	{ v18 }[0], [x9]
	tbz	w23, #5, LBB0_315
LBB0_352:                               ; %cond.load4037
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v20[1]
	ld1.s	{ v18 }[1], [x9]
	tbz	w23, #6, LBB0_316
LBB0_353:                               ; %cond.load4043
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d17
	ld1.s	{ v18 }[2], [x9]
	tbnz	w23, #7, LBB0_317
	b	LBB0_318
LBB0_354:                               ; %cond.load4056
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d23
	ldr	s17, [x9]
	tbz	w23, #1, LBB0_320
LBB0_355:                               ; %cond.load4062
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v23[1]
	ld1.s	{ v17 }[1], [x9]
	tbz	w23, #2, LBB0_321
LBB0_356:                               ; %cond.load4068
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d22
	ld1.s	{ v17 }[2], [x9]
	tbz	w23, #3, LBB0_322
LBB0_357:                               ; %cond.load4074
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v22[1]
	ld1.s	{ v17 }[3], [x9]
	tbz	w23, #4, LBB0_323
LBB0_358:                               ; %cond.load4080
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d21
	ld1.s	{ v18 }[0], [x9]
	tbz	w23, #5, LBB0_324
LBB0_359:                               ; %cond.load4086
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v21[1]
	ld1.s	{ v18 }[1], [x9]
	tbz	w23, #6, LBB0_325
LBB0_360:                               ; %cond.load4092
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d20
	ld1.s	{ v18 }[2], [x9]
	tbnz	w23, #7, LBB0_326
	b	LBB0_327
LBB0_361:                               ; %cond.load4105
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d23
	ldr	s17, [x9]
	add	x28, sp, #3, lsl #12            ; =12288
	add	x28, x28, #872
	tbz	w23, #1, LBB0_329
LBB0_362:                               ; %cond.load4111
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v23[1]
	ld1.s	{ v17 }[1], [x9]
	tbz	w23, #2, LBB0_330
LBB0_363:                               ; %cond.load4117
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d22
	ld1.s	{ v17 }[2], [x9]
	tbz	w23, #3, LBB0_331
LBB0_364:                               ; %cond.load4123
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v22[1]
	ld1.s	{ v17 }[3], [x9]
	ldr	q22, [sp, #1568]                ; 16-byte Folded Reload
	tbz	w23, #4, LBB0_332
LBB0_365:                               ; %cond.load4129
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d21
	ld1.s	{ v18 }[0], [x9]
	tbz	w23, #5, LBB0_333
LBB0_366:                               ; %cond.load4135
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v21[1]
	ld1.s	{ v18 }[1], [x9]
	tbz	w23, #6, LBB0_334
LBB0_367:                               ; %cond.load4141
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d20
	ld1.s	{ v18 }[2], [x9]
	tbnz	w23, #7, LBB0_335
	b	LBB0_336
LBB0_368:                               ; %cond.load4160
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v18[1]
	ld1.s	{ v1 }[1], [x9]
	tbz	w11, #2, LBB0_340
LBB0_369:                               ; %cond.load4166
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d16
	ld1.s	{ v1 }[2], [x9]
	tbz	w11, #3, LBB0_341
LBB0_370:                               ; %cond.load4172
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v16[1]
	ld1.s	{ v1 }[3], [x9]
	tbz	w11, #4, LBB0_342
LBB0_371:                               ; %cond.load4178
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d7
	ld1.s	{ v4 }[0], [x9]
	tbz	w11, #5, LBB0_343
LBB0_372:                               ; %cond.load4184
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v7[1]
	ld1.s	{ v4 }[1], [x9]
	tbz	w11, #6, LBB0_344
LBB0_373:                               ; %cond.load4190
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d5
	ld1.s	{ v4 }[2], [x9]
	tbnz	w11, #7, LBB0_345
	b	LBB0_346
LBB0_374:                               ; %varying.coherent.false322
                                        ;   in Loop: Header=BB0_11 Depth=3
	tst	w11, #0xff
	b.eq	LBB0_5
LBB0_375:                               ; %schedule.14
                                        ;   in Loop: Header=BB0_11 Depth=3
	cbz	w15, LBB0_380
; %bb.376:                              ; %convergence.cascade360.preheader
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov	w11, #0                         ; =0x0
LBB0_377:                               ; %convergence.cascade360
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_11 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w9, s3
	umaxv.8b	b1, v1
	fmov	w10, s1
	sub	w16, w15, #1
	tst	w9, #0xff
	csel	w4, w16, wzr, ne
	lsl	w6, w12, w4
	and	w9, w6, w14
	tst	w9, #0xff
	cset	w9, ne
	str	q8, [sp, #3952]
	str	q13, [sp, #3968]
	ubfiz	x3, x4, #2, #3
	ldr	w16, [x26, x3]
	cmp	w16, #4
	cset	w7, eq
	and	w23, w9, w10
	ldrb	w9, [x5, w4, sxtw]
	and	w10, w9, #0x1
	fmov	s1, w10
	ubfx	w10, w9, #1, #1
	mov.b	v1[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v1[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v1[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v1[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v1[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v1[6], w10
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, w4, sxtw]
	and	w10, w9, #0x1
	fmov	s3, w10
	ubfx	w10, w9, #1, #1
	mov.b	v3[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v3[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v3[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v3[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v3[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v3[6], w10
	lsr	w9, w9, #7
	mov.b	v3[7], w9
	orr.8b	v4, v9, v3
	ldr	d0, [sp, #1752]                 ; 8-byte Folded Reload
	and.8b	v5, v0, v1
	eor.8b	v5, v5, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	umaxv.8b	b5, v5
	fmov	w9, s5
	ands	w10, w23, w7
	csetm	w16, ne
	bics	w9, w10, w9
	csetm	w2, ne
	dup.8b	v5, w2
	dup.8b	v6, w16
	bic.8b	v7, v4, v5
	bit.8b	v3, v7, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w4, sxtw]
	bic.8b	v1, v1, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x5, w4, sxtw]
	csinv	w16, w0, w6, eq
	dup.8b	v1, w10
	and	w14, w16, w14
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w9
	and.8b	v3, v3, v4
	str	q12, [sp, #3920]
	str	q19, [sp, #3936]
	add	x9, sp, #3920
	ldr	w9, [x9, x3]
	csel	w15, w9, w15, ne
	bit.8b	v9, v3, v1
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w3, s1
	cmp	w10, #1
	b.ne	LBB0_381
; %bb.378:                              ; %convergence.cascade360
                                        ;   in Loop: Header=BB0_377 Depth=4
	cmp	w15, #0
	ccmp	w11, #6, #2, ne
	b.hi	LBB0_381
; %bb.379:                              ; %convergence.cascade360
                                        ;   in Loop: Header=BB0_377 Depth=4
	add	w11, w11, #1
	tst	w3, #0xff
	b.ne	LBB0_377
	b	LBB0_381
LBB0_380:                               ; %schedule.14.convergence.cascade.exit361_crit_edge
                                        ;   in Loop: Header=BB0_11 Depth=3
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w3, s1
LBB0_381:                               ; %convergence.cascade.exit361
                                        ;   in Loop: Header=BB0_11 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
; %bb.382:                              ; %convergence.target.14.ready
                                        ;   in Loop: Header=BB0_11 Depth=3
	rbit	w9, w3
	ldr	x10, [sp, #616]                 ; 8-byte Folded Reload
	ldr	x11, [sp, #368]                 ; 8-byte Folded Reload
	add	x10, x11, x10
	lsl	x10, x10, #5
	dup.2d	v1, x10
	clz	w9, w9
	ldr	q10, [sp, #1472]                ; 16-byte Folded Reload
	add.2d	v3, v1, v10
	ldr	q11, [sp, #1456]                ; 16-byte Folded Reload
	add.2d	v4, v1, v11
	mov.16b	v27, v28
	ldr	q28, [sp, #1440]                ; 16-byte Folded Reload
	add.2d	v5, v1, v28
	str	q31, [sp, #1584]                ; 16-byte Folded Spill
	str	q14, [sp, #1728]                ; 16-byte Folded Spill
	mov.16b	v31, v23
	mov.16b	v30, v25
	mov.16b	v23, v29
	ldr	q29, [sp, #1424]                ; 16-byte Folded Reload
	add.2d	v1, v1, v29
	str	q1, [sp, #3904]
	str	q5, [sp, #3888]
	str	q4, [sp, #3872]
	str	q3, [sp, #3856]
	ubfiz	x11, x9, #3, #3
	add	x10, sp, #3856
	ldr	x10, [x10, x11]
	lsl	w3, w9, #2
	sub	x9, x10, x3
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #728
	add	x9, x16, x9
	ldp	q1, q3, [x9]
	fabs.4s	v4, v3
	zip2.8b	v3, v9, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	and.16b	v4, v3, v4
	ldr	q5, [sp, #1168]                 ; 16-byte Folded Reload
	fadd.4s	v4, v5, v4
	ldr	q5, [sp, #1200]                 ; 16-byte Folded Reload
	fadd.4s	v4, v5, v4
	ldr	q5, [sp, #1232]                 ; 16-byte Folded Reload
	fadd.4s	v4, v5, v4
	ldr	q5, [sp, #880]                  ; 16-byte Folded Reload
	fadd.4s	v4, v5, v4
	ldr	q5, [sp, #624]                  ; 16-byte Folded Reload
	bit.16b	v5, v4, v3
	str	q5, [sp, #624]                  ; 16-byte Folded Spill
	str	q10, [sp, #3792]
	str	q11, [sp, #3808]
	str	q28, [sp, #3824]
	str	q29, [sp, #3840]
	add	x9, sp, #3792
	ldr	x9, [x9, x11]
	sub	x9, x9, x3
	add	x9, x9, x16
	ldr	q6, [x9, #6256]
	ldr	q4, [x9, #6240]
	ldr	x9, [sp, #504]                  ; 8-byte Folded Reload
	add	x9, x9, #195
	mov	x2, #4033                       ; =0xfc1
	movk	x2, #49404, lsl #16
	movk	x2, #64527, lsl #32
	movk	x2, #4032, lsl #48
	umulh	x10, x9, x2
	lsr	x10, x10, #2
	add	x10, x10, x10, lsl #6
	sub	x9, x9, x10
	mov	w4, #6240                       ; =0x1860
	add	x9, x4, x9, lsl #5
	dup.2d	v5, x9
	add.2d	v7, v5, v10
	add.2d	v16, v5, v11
	add.2d	v17, v5, v28
	add.2d	v5, v5, v29
	str	q5, [sp, #3776]
	str	q17, [sp, #3760]
	str	q16, [sp, #3744]
	str	q7, [sp, #3728]
	add	x9, sp, #3728
	ldr	x9, [x9, x11]
	sub	x9, x9, x3
	add	x9, x16, x9
	ldp	q5, q7, [x9]
	ldr	x9, [sp, #496]                  ; 8-byte Folded Reload
	add	x9, x9, #195
	umulh	x10, x9, x2
	lsr	x10, x10, #2
	add	x10, x10, x10, lsl #6
	sub	x9, x9, x10
	add	x9, x4, x9, lsl #5
	dup.2d	v16, x9
	add.2d	v17, v16, v10
	add.2d	v18, v16, v11
	add.2d	v20, v16, v28
	add.2d	v16, v16, v29
	str	q16, [sp, #3712]
	str	q20, [sp, #3696]
	str	q18, [sp, #3680]
	str	q17, [sp, #3664]
	ldr	x9, [sp, #488]                  ; 8-byte Folded Reload
	add	x9, x9, #195
	umulh	x10, x9, x2
	lsr	x10, x10, #2
	add	x10, x10, x10, lsl #6
	sub	x9, x9, x10
	add	x10, sp, #3664
	ldr	x10, [x10, x11]
	add	x9, x4, x9, lsl #5
	dup.2d	v16, x9
	mov	b17, v9[6]
	mov.b	v17[4], v9[7]
	sub	x9, x10, x3
	add	x9, x16, x9
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	mov	w10, #4                         ; =0x4
	dup.2d	v18, x10
	mov.16b	v25, v17
	bsl.16b	v25, v18, v22
	mov	b17, v9[4]
	mov.b	v17[4], v9[5]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	mov.16b	v24, v17
	bsl.16b	v24, v18, v21
	mov	b17, v9[2]
	mov.b	v17[4], v9[3]
	ldp	q21, q20, [x9]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	ldr	q22, [sp, #1632]                ; 16-byte Folded Reload
	bit.16b	v22, v18, v17
	str	q22, [sp, #1632]                ; 16-byte Folded Spill
	mov	b17, v9[0]
	mov.b	v17[4], v9[1]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	ldr	q22, [sp, #1648]                ; 16-byte Folded Reload
	bit.16b	v22, v18, v17
	str	q22, [sp, #1648]                ; 16-byte Folded Spill
	add.2d	v17, v16, v28
	add.2d	v18, v16, v29
	mov.16b	v29, v23
	mov.16b	v28, v27
	mov.16b	v22, v25
	mov.16b	v25, v30
	mov.16b	v23, v31
	ldr	q14, [sp, #1728]                ; 16-byte Folded Reload
	ldr	q31, [sp, #1584]                ; 16-byte Folded Reload
	str	q18, [sp, #3648]
	str	q17, [sp, #3632]
	add.2d	v17, v16, v10
	add.2d	v16, v16, v11
	str	q16, [sp, #3616]
	str	q17, [sp, #3600]
	fabs.4s	v6, v6
	ldr	q16, [sp, #1264]                ; 16-byte Folded Reload
	bit.16b	v16, v6, v3
	str	q16, [sp, #1264]                ; 16-byte Folded Spill
	fabs.4s	v6, v7
	fabs.4s	v7, v20
	add	x9, sp, #3600
	ldr	x9, [x9, x11]
	sub	x9, x9, x3
	add	x9, x16, x9
	ldr	q16, [sp, #1296]                ; 16-byte Folded Reload
	bit.16b	v16, v6, v3
	str	q16, [sp, #1296]                ; 16-byte Folded Spill
	ldr	q6, [sp, #1328]                 ; 16-byte Folded Reload
	bit.16b	v6, v7, v3
	str	q6, [sp, #1328]                 ; 16-byte Folded Spill
	ldp	q7, q6, [x9]
	fabs.4s	v6, v6
	ldr	q16, [sp, #912]                 ; 16-byte Folded Reload
	bit.16b	v16, v6, v3
	str	q16, [sp, #912]                 ; 16-byte Folded Spill
	fabs.4s	v1, v1
	zip1.8b	v3, v9, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	and.16b	v1, v3, v1
	ldr	q6, [sp, #1184]                 ; 16-byte Folded Reload
	fadd.4s	v1, v6, v1
	ldr	q6, [sp, #1216]                 ; 16-byte Folded Reload
	fadd.4s	v1, v6, v1
	ldr	q6, [sp, #1248]                 ; 16-byte Folded Reload
	fadd.4s	v1, v6, v1
	ldr	q6, [sp, #896]                  ; 16-byte Folded Reload
	fadd.4s	v1, v6, v1
	ldr	q6, [sp, #640]                  ; 16-byte Folded Reload
	bit.16b	v6, v1, v3
	str	q6, [sp, #640]                  ; 16-byte Folded Spill
	fabs.4s	v1, v4
	ldr	q4, [sp, #1280]                 ; 16-byte Folded Reload
	bit.16b	v4, v1, v3
	str	q4, [sp, #1280]                 ; 16-byte Folded Spill
	fabs.4s	v1, v5
	ldr	q4, [sp, #1312]                 ; 16-byte Folded Reload
	bit.16b	v4, v1, v3
	str	q4, [sp, #1312]                 ; 16-byte Folded Spill
	fabs.4s	v1, v21
	mov.16b	v21, v24
	ldr	q4, [sp, #1344]                 ; 16-byte Folded Reload
	bit.16b	v4, v1, v3
	str	q4, [sp, #1344]                 ; 16-byte Folded Spill
	fabs.4s	v1, v7
	ldr	q4, [sp, #928]                  ; 16-byte Folded Reload
	bit.16b	v4, v1, v3
	str	q4, [sp, #928]                  ; 16-byte Folded Spill
	mov	w9, #195                        ; =0xc3
	str	x9, [sp, #376]                  ; 8-byte Folded Spill
LBB0_383:                               ; %schedule.15
                                        ;   in Loop: Header=BB0_11 Depth=3
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	mov	w9, #64                         ; =0x40
	dup.2d	v1, x9
	ldr	q7, [sp, #1632]                 ; 16-byte Folded Reload
	cmgt.2d	v3, v1, v7
	ldr	q6, [sp, #1648]                 ; 16-byte Folded Reload
	cmgt.2d	v4, v1, v6
	uzp1.4s	v3, v4, v3
	cmgt.2d	v4, v1, v21
	cmgt.2d	v5, v1, v22
	uzp1.4s	v4, v4, v5
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v10, v9, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w3, s4
	umaxv.8b	b3, v3
	fmov	w9, s3
	tbz	w9, #0, LBB0_389
; %bb.384:                              ; %schedule.15
                                        ;   in Loop: Header=BB0_11 Depth=3
	cmge.2d	v3, v7, v1
	cmge.2d	v4, v6, v1
	uzp1.4s	v3, v4, v3
	cmge.2d	v4, v21, v1
	cmge.2d	v1, v22, v1
	uzp1.4s	v1, v4, v1
	uzp1.8h	v1, v3, v1
	xtn.8b	v1, v1
	and.8b	v11, v9, v1
	shl.8b	v1, v11, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w9, s1
	tst	w9, #0xff
	b.eq	LBB0_389
; %bb.385:                              ; %varying.divergent422
                                        ;   in Loop: Header=BB0_11 Depth=3
	subs	w9, w15, #1
	csel	w9, wzr, w9, lo
	and	w10, w14, #0xff
	lsr	w11, w10, w9
	tst	w11, #0x1
	str	q8, [sp, #2752]
	str	q13, [sp, #2768]
	and	x9, x9, #0x7
	add	x11, sp, #2752
	ldr	w9, [x11, x9, lsl #2]
	ccmp	w15, #0, #4, ne
	ccmp	w9, #5, #0, ne
	cset	w4, ne
	cmp	w10, #255
	b.ne	LBB0_387
; %bb.386:                              ; %varying.divergent422
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w4, #0, LBB0_603
LBB0_387:                               ; %convergence.overflow.resume425
                                        ;   in Loop: Header=BB0_11 Depth=3
	mvn	w9, w14
	rbit	w9, w9
	clz	w9, w9
	mov	w10, #255                       ; =0xff
	bics	wzr, w10, w14
	csel	w6, wzr, w9, eq
	ldrb	w9, [x5, w6, uxtw]
	and	w10, w9, #0x1
	fmov	s1, w10
	ubfx	w10, w9, #1, #1
	mov.b	v1[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v1[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v1[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v1[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v1[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v1[6], w10
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, w6, uxtw]
	and	w10, w9, #0x1
	fmov	s3, w10
	ubfx	w10, w9, #1, #1
	mov.b	v3[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v3[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v3[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v3[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v3[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v3[6], w10
	lsr	w9, w9, #7
	mov.b	v3[7], w9
	cmp	w4, #0
	csetm	w9, ne
	dup.8b	v4, w9
	bit.8b	v1, v9, v4
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x5, w6, uxtw]
	bic.8b	v1, v3, v4
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x8, w6, uxtw]
	cmp	x13, #8
	b.hs	LBB0_603
; %bb.388:                              ; %ready.overflow.resume427
                                        ;   in Loop: Header=BB0_11 Depth=3
	str	q12, [sp, #2720]
	str	q19, [sp, #2736]
	ubfiz	x9, x6, #2, #3
	add	x10, sp, #2720
	ldr	w10, [x10, x9]
	cmp	w4, #0
	csel	w10, w15, w10, ne
	str	q12, [sp, #2688]
	str	q19, [sp, #2704]
	add	x11, sp, #2688
	str	w10, [x11, x9]
	ldr	q19, [sp, #2704]
	ldr	q12, [sp, #2688]
	str	q8, [sp, #2656]
	str	q13, [sp, #2672]
	add	x10, sp, #2656
	ldr	w10, [x10, x9]
	csinc	w15, w15, w6, eq
	mov	w11, #5                         ; =0x5
	csel	w10, w11, w10, ne
	str	q8, [sp, #2624]
	str	q13, [sp, #2640]
	add	x11, sp, #2624
	str	w10, [x11, x9]
	mov	w7, #17                         ; =0x11
	mov	w11, #16                        ; =0x10
	ldr	q13, [sp, #2640]
	ldr	q8, [sp, #2624]
	b	LBB0_9
LBB0_389:                               ; %varying.coherent423
                                        ;   in Loop: Header=BB0_11 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_456
; %bb.390:                              ; %varying.coherent.true428
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov	w4, #0                          ; =0x0
	tst	w11, #0xff
	b.eq	LBB0_5
LBB0_391:                               ; %schedule.16
                                        ;   in Loop: Header=BB0_11 Depth=3
	str	q14, [sp, #1728]                ; 16-byte Folded Spill
	str	q23, [sp, #1696]                ; 16-byte Folded Spill
	str	q28, [sp, #1504]                ; 16-byte Folded Spill
	str	q29, [sp, #1536]                ; 16-byte Folded Spill
	str	q26, [sp, #1552]                ; 16-byte Folded Spill
	str	q25, [sp, #1616]                ; 16-byte Folded Spill
	ldr	x9, [sp, #376]                  ; 8-byte Folded Reload
	dup.2d	v1, x9
	str	q22, [sp, #1568]                ; 16-byte Folded Spill
	add.2d	v16, v1, v22
	str	q21, [sp, #1520]                ; 16-byte Folded Spill
	add.2d	v7, v1, v21
	ldr	q14, [sp, #1632]                ; 16-byte Folded Reload
	add.2d	v4, v1, v14
	ldr	q11, [sp, #1648]                ; 16-byte Folded Reload
	add.2d	v3, v1, v11
	mov	b1, v9[0]
	mov.b	v1[4], v9[1]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	mov	b5, v9[2]
	mov.b	v5[4], v9[3]
	and.16b	v6, v1, v3
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v21, v5, #0
	and.16b	v17, v21, v4
	mov	b5, v9[4]
	mov.b	v5[4], v9[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v22, v5, #0
	and.16b	v18, v22, v7
	mov	b5, v9[6]
	mov.b	v5[4], v9[7]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	and.16b	v20, v5, v16
	shl.8b	v23, v9, #7
	cmlt.8b	v23, v23, #0
	and.8b	v23, v23, v2
	mov	w9, #65                         ; =0x41
	dup.2d	v25, x9
	addv.8b	b10, v23
	and.16b	v23, v1, v25
	mvn.16b	v1, v1
	and.16b	v24, v5, v25
	mvn.16b	v5, v5
	sub.2d	v24, v24, v5
	mov.d	x11, v24[1]
	mov.d	x9, v20[1]
	sdiv	x9, x9, x11
	sub.2d	v5, v23, v1
	and.16b	v1, v21, v25
	mvn.16b	v21, v21
	sub.2d	v1, v1, v21
	and.16b	v21, v22, v25
	mvn.16b	v22, v22
	sub.2d	v25, v21, v22
	fmov	x10, d24
	fmov	x16, d20
	fmov	x2, d25
	fmov	x3, d18
	mov.d	x6, v25[1]
	sdiv	x19, x3, x2
	mov.d	x3, v18[1]
	sdiv	x20, x3, x6
	fmov	x21, d1
	fmov	x3, d17
	sdiv	x22, x3, x21
	mov.d	x7, v1[1]
	mov.d	x23, v17[1]
	fmov	x25, d5
	fmov	x3, d6
	sdiv	x26, x3, x25
	mov.d	x3, v5[1]
	mov.d	x27, v6[1]
	sdiv	x27, x27, x3
	mul	x28, x27, x3
	mul	x25, x26, x25
	fmov	d21, x25
	mov.d	v21[1], x28
	sdiv	x23, x23, x7
	mul	x25, x23, x7
	mul	x21, x22, x21
	fmov	d22, x21
	mov.d	v22[1], x25
	mul	x21, x20, x6
	mul	x2, x19, x2
	fmov	d23, x2
	mov.d	v23[1], x21
	mul	x2, x9, x11
	sdiv	x16, x16, x10
	mul	x10, x16, x10
	fmov	d26, x10
	mov.d	v26[1], x2
	sub.2d	v20, v20, v26
	sub.2d	v18, v18, v23
	add	x10, x16, x16, lsl #6
	fmov	d23, x10
	add	x9, x9, x9, lsl #6
	mov.d	v23[1], x9
	sub.2d	v17, v17, v22
	add	x9, x19, x19, lsl #6
	fmov	d22, x9
	add	x9, x20, x20, lsl #6
	mov.d	v22[1], x9
	sub.2d	v6, v6, v21
	add	x9, x22, x22, lsl #6
	fmov	d21, x9
	add	x9, x23, x23, lsl #6
	mov.d	v21[1], x9
	add	x9, x26, x26, lsl #6
	fmov	d26, x9
	add	x9, x27, x27, lsl #6
	mov.d	v26[1], x9
	add.2d	v6, v26, v6
	add.2d	v17, v21, v17
	add.2d	v18, v22, v18
	add.2d	v20, v23, v20
	shl.2d	v20, v20, #5
	shl.2d	v18, v18, #5
	fmov	w23, s10
	shl.2d	v21, v17, #5
	shl.2d	v6, v6, #5
	ldr	q17, [sp, #784]                 ; 16-byte Folded Reload
	ldr	q22, [sp, #1424]                ; 16-byte Folded Reload
	add.2d	v26, v17, v22
	add.2d	v17, v26, v20
	ldr	q20, [sp, #800]                 ; 16-byte Folded Reload
	ldr	q22, [sp, #1440]                ; 16-byte Folded Reload
	add.2d	v27, v20, v22
	add.2d	v20, v27, v18
	ldp	q0, q18, [sp, #816]             ; 32-byte Folded Reload
	ldr	q22, [sp, #1456]                ; 16-byte Folded Reload
	add.2d	v28, v0, v22
	add.2d	v21, v28, v21
	ldr	q22, [sp, #1472]                ; 16-byte Folded Reload
	add.2d	v29, v18, v22
	add.2d	v22, v29, v6
	movi.2d	v6, #0000000000000000
	movi.2d	v18, #0000000000000000
	str	q31, [sp, #1584]                ; 16-byte Folded Spill
	str	q11, [sp, #1648]                ; 16-byte Folded Spill
	str	q14, [sp, #1632]                ; 16-byte Folded Spill
	tbnz	w23, #0, LBB0_429
; %bb.392:                              ; %else4207
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #1, LBB0_430
LBB0_393:                               ; %else4213
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #2, LBB0_431
LBB0_394:                               ; %else4219
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #3, LBB0_432
LBB0_395:                               ; %else4225
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #4, LBB0_433
LBB0_396:                               ; %else4231
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #5, LBB0_434
LBB0_397:                               ; %else4237
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #6, LBB0_435
LBB0_398:                               ; %else4243
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbz	w23, #7, LBB0_400
LBB0_399:                               ; %cond.load4245
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v17[1]
	ld1.s	{ v18 }[3], [x9]
LBB0_400:                               ; %else4249
                                        ;   in Loop: Header=BB0_11 Depth=3
	fabs.4s	v17, v18
	fabs.4s	v6, v6
	ldr	q18, [sp, #1280]                ; 16-byte Folded Reload
	fadd.4s	v0, v18, v6
	ldr	q6, [sp, #1264]                 ; 16-byte Folded Reload
	fadd.4s	v6, v6, v17
	dup.2d	v17, x12
	add.2d	v20, v16, v17
	add.2d	v21, v7, v17
	add.2d	v18, v4, v17
	add.2d	v17, v3, v17
	mov	b22, v9[0]
	mov.b	v22[4], v9[1]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	mov	b23, v9[2]
	mov.b	v23[4], v9[3]
	and.16b	v17, v22, v17
	ushll.2d	v22, v23, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	and.16b	v18, v22, v18
	mov	b22, v9[4]
	mov.b	v22[4], v9[5]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	and.16b	v21, v22, v21
	mov	b22, v9[6]
	mov.b	v22[4], v9[7]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	and.16b	v20, v22, v20
	fmov	x9, d20
	fmov	x10, d24
	mov.d	x16, v20[1]
	sdiv	x16, x16, x11
	fmov	x2, d21
	fmov	x19, d25
	sdiv	x2, x2, x19
	mov.d	x20, v21[1]
	sdiv	x20, x20, x6
	fmov	x21, d18
	fmov	x22, d1
	sdiv	x21, x21, x22
	mov.d	x23, v18[1]
	sdiv	x23, x23, x7
	fmov	x25, d17
	fmov	x26, d5
	sdiv	x25, x25, x26
	mov.d	x27, v17[1]
	sdiv	x27, x27, x3
	mul	x28, x27, x3
	mul	x26, x25, x26
	fmov	d22, x26
	mov.d	v22[1], x28
	mul	x26, x23, x7
	mul	x22, x21, x22
	fmov	d23, x22
	mov.d	v23[1], x26
	mul	x22, x20, x6
	mul	x19, x2, x19
	fmov	d30, x19
	mov.d	v30[1], x22
	mul	x19, x16, x11
	sdiv	x9, x9, x10
	mul	x10, x9, x10
	fmov	d31, x10
	mov.d	v31[1], x19
	sub.2d	v20, v20, v31
	sub.2d	v21, v21, v30
	sub.2d	v18, v18, v23
	sub.2d	v17, v17, v22
	add	x9, x9, x9, lsl #6
	fmov	d22, x9
	add	x9, x16, x16, lsl #6
	mov.d	v22[1], x9
	add	x9, x2, x2, lsl #6
	fmov	d23, x9
	add	x9, x20, x20, lsl #6
	mov.d	v23[1], x9
	add	x9, x21, x21, lsl #6
	fmov	d30, x9
	add	x9, x23, x23, lsl #6
	mov.d	v30[1], x9
	add	x9, x25, x25, lsl #6
	fmov	d31, x9
	add	x9, x27, x27, lsl #6
	mov.d	v31[1], x9
	add.2d	v17, v31, v17
	add.2d	v18, v30, v18
	add.2d	v21, v23, v21
	add.2d	v20, v22, v20
	shl.2d	v20, v20, #5
	shl.2d	v21, v21, #5
	shl.2d	v18, v18, #5
	shl.2d	v17, v17, #5
	fmov	w23, s10
	add.2d	v20, v26, v20
	add.2d	v21, v27, v21
	add.2d	v22, v28, v18
	add.2d	v23, v29, v17
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w23, #0, LBB0_436
; %bb.401:                              ; %else4256
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #1, LBB0_437
LBB0_402:                               ; %else4262
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #2, LBB0_438
LBB0_403:                               ; %else4268
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #3, LBB0_439
LBB0_404:                               ; %else4274
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #4, LBB0_440
LBB0_405:                               ; %else4280
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #5, LBB0_441
LBB0_406:                               ; %else4286
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #6, LBB0_442
LBB0_407:                               ; %else4292
                                        ;   in Loop: Header=BB0_11 Depth=3
	str	q6, [sp, #672]                  ; 16-byte Folded Spill
	tbz	w23, #7, LBB0_409
LBB0_408:                               ; %cond.load4294
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v20[1]
	ld1.s	{ v18 }[3], [x9]
LBB0_409:                               ; %else4298
                                        ;   in Loop: Header=BB0_11 Depth=3
	fabs.4s	v18, v18
	fabs.4s	v17, v17
	ldr	q20, [sp, #1312]                ; 16-byte Folded Reload
	fadd.4s	v30, v20, v17
	ldr	q17, [sp, #1296]                ; 16-byte Folded Reload
	fadd.4s	v31, v17, v18
	mov	w9, #2                          ; =0x2
	dup.2d	v17, x9
	add.2d	v20, v16, v17
	add.2d	v21, v7, v17
	add.2d	v18, v4, v17
	add.2d	v17, v3, v17
	mov	b22, v9[0]
	mov.b	v22[4], v9[1]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	mov	b23, v9[2]
	mov.b	v23[4], v9[3]
	and.16b	v17, v22, v17
	ushll.2d	v22, v23, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	and.16b	v18, v22, v18
	mov	b22, v9[4]
	mov.b	v22[4], v9[5]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	and.16b	v21, v22, v21
	mov	b22, v9[6]
	mov.b	v22[4], v9[7]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	and.16b	v20, v22, v20
	fmov	x9, d20
	fmov	x10, d24
	mov.d	x16, v20[1]
	sdiv	x16, x16, x11
	fmov	x2, d21
	fmov	x19, d25
	sdiv	x2, x2, x19
	mov.d	x20, v21[1]
	sdiv	x20, x20, x6
	fmov	x21, d18
	fmov	x22, d1
	sdiv	x21, x21, x22
	mov.d	x23, v18[1]
	sdiv	x23, x23, x7
	fmov	x25, d17
	fmov	x26, d5
	sdiv	x25, x25, x26
	mov.d	x27, v17[1]
	sdiv	x27, x27, x3
	mul	x28, x27, x3
	mul	x26, x25, x26
	fmov	d22, x26
	mov.d	v22[1], x28
	mul	x26, x23, x7
	mul	x22, x21, x22
	fmov	d23, x22
	mov.d	v23[1], x26
	mul	x22, x20, x6
	mul	x19, x2, x19
	fmov	d14, x19
	mov.d	v14[1], x22
	mul	x19, x16, x11
	sdiv	x9, x9, x10
	mul	x10, x9, x10
	fmov	d15, x10
	mov.d	v15[1], x19
	sub.2d	v20, v20, v15
	sub.2d	v21, v21, v14
	sub.2d	v18, v18, v23
	sub.2d	v17, v17, v22
	add	x9, x9, x9, lsl #6
	fmov	d22, x9
	add	x9, x16, x16, lsl #6
	mov.d	v22[1], x9
	add	x9, x2, x2, lsl #6
	fmov	d23, x9
	add	x9, x20, x20, lsl #6
	mov.d	v23[1], x9
	add	x9, x21, x21, lsl #6
	fmov	d14, x9
	add	x9, x23, x23, lsl #6
	mov.d	v14[1], x9
	add	x9, x25, x25, lsl #6
	fmov	d15, x9
	add	x9, x27, x27, lsl #6
	mov.d	v15[1], x9
	add.2d	v17, v15, v17
	add.2d	v18, v14, v18
	add.2d	v21, v23, v21
	add.2d	v20, v22, v20
	shl.2d	v20, v20, #5
	shl.2d	v21, v21, #5
	shl.2d	v18, v18, #5
	shl.2d	v17, v17, #5
	fmov	w23, s10
	add.2d	v20, v26, v20
	add.2d	v21, v27, v21
	add.2d	v22, v28, v18
	add.2d	v23, v29, v17
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w23, #0, LBB0_443
; %bb.410:                              ; %else4305
                                        ;   in Loop: Header=BB0_11 Depth=3
	add	x28, sp, #3, lsl #12            ; =12288
	add	x28, x28, #872
	tbnz	w23, #1, LBB0_444
LBB0_411:                               ; %else4311
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.16b	v15, v0
	tbnz	w23, #2, LBB0_445
LBB0_412:                               ; %else4317
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #3, LBB0_446
LBB0_413:                               ; %else4323
                                        ;   in Loop: Header=BB0_11 Depth=3
	ldr	q22, [sp, #1568]                ; 16-byte Folded Reload
	tbnz	w23, #4, LBB0_447
LBB0_414:                               ; %else4329
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #5, LBB0_448
LBB0_415:                               ; %else4335
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w23, #6, LBB0_449
LBB0_416:                               ; %else4341
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbz	w23, #7, LBB0_418
LBB0_417:                               ; %cond.load4343
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v20[1]
	ld1.s	{ v18 }[3], [x9]
LBB0_418:                               ; %else4347
                                        ;   in Loop: Header=BB0_11 Depth=3
	fabs.4s	v18, v18
	fabs.4s	v17, v17
	ldr	q20, [sp, #1344]                ; 16-byte Folded Reload
	fadd.4s	v17, v20, v17
	mov	w9, #3                          ; =0x3
	dup.2d	v20, x9
	add.2d	v16, v16, v20
	add.2d	v21, v7, v20
	add.2d	v7, v4, v20
	add.2d	v3, v3, v20
	mov	b4, v9[0]
	mov.b	v4[4], v9[1]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	and.16b	v4, v4, v3
	mov	b20, v9[2]
	mov.b	v20[4], v9[3]
	ldr	q3, [sp, #1328]                 ; 16-byte Folded Reload
	fadd.4s	v3, v3, v18
	ushll.2d	v18, v20, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	and.16b	v7, v18, v7
	mov	b18, v9[4]
	mov.b	v18[4], v9[5]
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	and.16b	v18, v18, v21
	mov	b20, v9[6]
	mov.b	v20[4], v9[7]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	and.16b	v16, v20, v16
	fmov	x9, d16
	fmov	x10, d24
	mov.d	x16, v16[1]
	sdiv	x16, x16, x11
	fmov	x2, d18
	fmov	x19, d25
	sdiv	x2, x2, x19
	mov.d	x20, v18[1]
	sdiv	x20, x20, x6
	fmov	x21, d7
	fmov	x22, d1
	sdiv	x21, x21, x22
	mov.d	x23, v7[1]
	sdiv	x23, x23, x7
	fmov	x25, d4
	fmov	x26, d5
	sdiv	x25, x25, x26
	mov.d	x27, v4[1]
	sdiv	x27, x27, x3
	mul	x3, x27, x3
	mul	x26, x25, x26
	fmov	d1, x26
	mov.d	v1[1], x3
	mul	x3, x23, x7
	mul	x7, x21, x22
	fmov	d5, x7
	mov.d	v5[1], x3
	mul	x3, x20, x6
	mul	x6, x2, x19
	fmov	d20, x6
	mov.d	v20[1], x3
	mul	x11, x16, x11
	sdiv	x9, x9, x10
	mul	x10, x9, x10
	fmov	d21, x10
	mov.d	v21[1], x11
	sub.2d	v16, v16, v21
	sub.2d	v18, v18, v20
	sub.2d	v5, v7, v5
	sub.2d	v1, v4, v1
	add	x9, x9, x9, lsl #6
	fmov	d4, x9
	add	x9, x16, x16, lsl #6
	mov.d	v4[1], x9
	add	x9, x2, x2, lsl #6
	fmov	d7, x9
	add	x9, x20, x20, lsl #6
	mov.d	v7[1], x9
	add	x9, x21, x21, lsl #6
	fmov	d20, x9
	add	x9, x23, x23, lsl #6
	mov.d	v20[1], x9
	add	x9, x25, x25, lsl #6
	fmov	d21, x9
	add	x9, x27, x27, lsl #6
	mov.d	v21[1], x9
	add.2d	v1, v21, v1
	add.2d	v5, v20, v5
	add.2d	v7, v7, v18
	add.2d	v4, v4, v16
	shl.2d	v4, v4, #5
	shl.2d	v7, v7, #5
	shl.2d	v16, v5, #5
	shl.2d	v1, v1, #5
	fmov	w11, s10
	add.2d	v5, v26, v4
	add.2d	v7, v27, v7
	add.2d	v16, v28, v16
	add.2d	v18, v29, v1
	movi.2d	v1, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbz	w11, #0, LBB0_420
; %bb.419:                              ; %cond.load4350
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d18
	ldr	s1, [x9]
LBB0_420:                               ; %else4354
                                        ;   in Loop: Header=BB0_11 Depth=3
	add	x21, sp, #3, lsl #12            ; =12288
	add	x21, x21, #936
	add	x27, sp, #3, lsl #12            ; =12288
	add	x27, x27, #904
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #560
	add	x20, sp, #1, lsl #12            ; =4096
	add	x20, x20, #528
	add	x22, sp, #1, lsl #12            ; =4096
	add	x22, x22, #240
	add	x25, sp, #1, lsl #12            ; =4096
	add	x25, x25, #208
	add	x26, sp, #3952
	ldr	q21, [sp, #1520]                ; 16-byte Folded Reload
	ldr	q25, [sp, #1616]                ; 16-byte Folded Reload
	ldr	q26, [sp, #1552]                ; 16-byte Folded Reload
	ldr	q29, [sp, #1536]                ; 16-byte Folded Reload
	ldr	q28, [sp, #1504]                ; 16-byte Folded Reload
	ldr	q23, [sp, #1696]                ; 16-byte Folded Reload
	ldr	q14, [sp, #1728]                ; 16-byte Folded Reload
	tbnz	w11, #1, LBB0_450
; %bb.421:                              ; %else4360
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #2, LBB0_451
LBB0_422:                               ; %else4366
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #3, LBB0_452
LBB0_423:                               ; %else4372
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #4, LBB0_453
LBB0_424:                               ; %else4378
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #5, LBB0_454
LBB0_425:                               ; %else4384
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #6, LBB0_455
LBB0_426:                               ; %else4390
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbz	w11, #7, LBB0_428
LBB0_427:                               ; %cond.load4392
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v5[1]
	ld1.s	{ v4 }[3], [x9]
LBB0_428:                               ; %else4396
                                        ;   in Loop: Header=BB0_11 Depth=3
	fabs.4s	v4, v4
	fabs.4s	v1, v1
	ldp	q18, q16, [sp, #912]            ; 32-byte Folded Reload
	fadd.4s	v1, v16, v1
	mov	w9, #4                          ; =0x4
	dup.2d	v5, x9
	mov	b7, v9[6]
	mov.b	v7[4], v9[7]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v7, v7, v5
	add.2d	v22, v22, v7
	mov	b7, v9[4]
	mov.b	v7[4], v9[5]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v7, v7, v5
	add.2d	v21, v21, v7
	mov	b7, v9[2]
	mov.b	v7[4], v9[3]
	fadd.4s	v4, v18, v4
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v7, v7, v5
	ldr	q6, [sp, #1632]                 ; 16-byte Folded Reload
	add.2d	v6, v6, v7
	str	q6, [sp, #1632]                 ; 16-byte Folded Spill
	mov	b7, v9[0]
	mov.b	v7[4], v9[1]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v5, v7, v5
	ldr	q6, [sp, #1648]                 ; 16-byte Folded Reload
	add.2d	v6, v6, v5
	str	q6, [sp, #1648]                 ; 16-byte Folded Spill
	zip1.8b	v5, v9, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	zip2.8b	v7, v9, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	ldr	q20, [sp, #1264]                ; 16-byte Folded Reload
	ldr	q6, [sp, #672]                  ; 16-byte Folded Reload
	bit.16b	v20, v6, v7
	str	q20, [sp, #1264]                ; 16-byte Folded Spill
	ldr	q6, [sp, #1280]                 ; 16-byte Folded Reload
	bit.16b	v6, v15, v5
	str	q6, [sp, #1280]                 ; 16-byte Folded Spill
	ldr	q6, [sp, #1296]                 ; 16-byte Folded Reload
	bit.16b	v6, v31, v7
	str	q6, [sp, #1296]                 ; 16-byte Folded Spill
	ldr	q6, [sp, #1312]                 ; 16-byte Folded Reload
	bit.16b	v6, v30, v5
	str	q6, [sp, #1312]                 ; 16-byte Folded Spill
	ldr	q6, [sp, #1328]                 ; 16-byte Folded Reload
	bit.16b	v6, v3, v7
	str	q6, [sp, #1328]                 ; 16-byte Folded Spill
	ldr	q3, [sp, #1344]                 ; 16-byte Folded Reload
	bit.16b	v3, v17, v5
	str	q3, [sp, #1344]                 ; 16-byte Folded Spill
	bit.16b	v18, v4, v7
	bit.16b	v16, v1, v5
	stp	q18, q16, [sp, #912]            ; 32-byte Folded Spill
	ldr	q31, [sp, #1584]                ; 16-byte Folded Reload
	tbz	w4, #0, LBB0_383
	b	LBB0_5
LBB0_429:                               ; %cond.load4203
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d22
	ldr	s6, [x9]
	tbz	w23, #1, LBB0_393
LBB0_430:                               ; %cond.load4209
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v22[1]
	ld1.s	{ v6 }[1], [x9]
	tbz	w23, #2, LBB0_394
LBB0_431:                               ; %cond.load4215
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d21
	ld1.s	{ v6 }[2], [x9]
	tbz	w23, #3, LBB0_395
LBB0_432:                               ; %cond.load4221
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v21[1]
	ld1.s	{ v6 }[3], [x9]
	tbz	w23, #4, LBB0_396
LBB0_433:                               ; %cond.load4227
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d20
	ld1.s	{ v18 }[0], [x9]
	tbz	w23, #5, LBB0_397
LBB0_434:                               ; %cond.load4233
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v20[1]
	ld1.s	{ v18 }[1], [x9]
	tbz	w23, #6, LBB0_398
LBB0_435:                               ; %cond.load4239
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d17
	ld1.s	{ v18 }[2], [x9]
	tbnz	w23, #7, LBB0_399
	b	LBB0_400
LBB0_436:                               ; %cond.load4252
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d23
	ldr	s17, [x9]
	tbz	w23, #1, LBB0_402
LBB0_437:                               ; %cond.load4258
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v23[1]
	ld1.s	{ v17 }[1], [x9]
	tbz	w23, #2, LBB0_403
LBB0_438:                               ; %cond.load4264
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d22
	ld1.s	{ v17 }[2], [x9]
	tbz	w23, #3, LBB0_404
LBB0_439:                               ; %cond.load4270
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v22[1]
	ld1.s	{ v17 }[3], [x9]
	tbz	w23, #4, LBB0_405
LBB0_440:                               ; %cond.load4276
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d21
	ld1.s	{ v18 }[0], [x9]
	tbz	w23, #5, LBB0_406
LBB0_441:                               ; %cond.load4282
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v21[1]
	ld1.s	{ v18 }[1], [x9]
	tbz	w23, #6, LBB0_407
LBB0_442:                               ; %cond.load4288
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d20
	ld1.s	{ v18 }[2], [x9]
	str	q6, [sp, #672]                  ; 16-byte Folded Spill
	tbnz	w23, #7, LBB0_408
	b	LBB0_409
LBB0_443:                               ; %cond.load4301
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d23
	ldr	s17, [x9]
	add	x28, sp, #3, lsl #12            ; =12288
	add	x28, x28, #872
	tbz	w23, #1, LBB0_411
LBB0_444:                               ; %cond.load4307
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v23[1]
	ld1.s	{ v17 }[1], [x9]
	mov.16b	v15, v0
	tbz	w23, #2, LBB0_412
LBB0_445:                               ; %cond.load4313
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d22
	ld1.s	{ v17 }[2], [x9]
	tbz	w23, #3, LBB0_413
LBB0_446:                               ; %cond.load4319
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v22[1]
	ld1.s	{ v17 }[3], [x9]
	ldr	q22, [sp, #1568]                ; 16-byte Folded Reload
	tbz	w23, #4, LBB0_414
LBB0_447:                               ; %cond.load4325
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d21
	ld1.s	{ v18 }[0], [x9]
	tbz	w23, #5, LBB0_415
LBB0_448:                               ; %cond.load4331
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v21[1]
	ld1.s	{ v18 }[1], [x9]
	tbz	w23, #6, LBB0_416
LBB0_449:                               ; %cond.load4337
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d20
	ld1.s	{ v18 }[2], [x9]
	tbnz	w23, #7, LBB0_417
	b	LBB0_418
LBB0_450:                               ; %cond.load4356
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v18[1]
	ld1.s	{ v1 }[1], [x9]
	tbz	w11, #2, LBB0_422
LBB0_451:                               ; %cond.load4362
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d16
	ld1.s	{ v1 }[2], [x9]
	tbz	w11, #3, LBB0_423
LBB0_452:                               ; %cond.load4368
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v16[1]
	ld1.s	{ v1 }[3], [x9]
	tbz	w11, #4, LBB0_424
LBB0_453:                               ; %cond.load4374
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d7
	ld1.s	{ v4 }[0], [x9]
	tbz	w11, #5, LBB0_425
LBB0_454:                               ; %cond.load4380
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v7[1]
	ld1.s	{ v4 }[1], [x9]
	tbz	w11, #6, LBB0_426
LBB0_455:                               ; %cond.load4386
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d5
	ld1.s	{ v4 }[2], [x9]
	tbnz	w11, #7, LBB0_427
	b	LBB0_428
LBB0_456:                               ; %varying.coherent.false429
                                        ;   in Loop: Header=BB0_11 Depth=3
	tst	w11, #0xff
	b.eq	LBB0_5
LBB0_457:                               ; %schedule.17
                                        ;   in Loop: Header=BB0_11 Depth=3
	cbz	w15, LBB0_462
; %bb.458:                              ; %convergence.cascade467.preheader
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov	w11, #0                         ; =0x0
LBB0_459:                               ; %convergence.cascade467
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_11 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w9, s3
	umaxv.8b	b1, v1
	fmov	w10, s1
	sub	w16, w15, #1
	tst	w9, #0xff
	csel	w4, w16, wzr, ne
	lsl	w6, w12, w4
	and	w9, w6, w14
	tst	w9, #0xff
	cset	w9, ne
	str	q8, [sp, #3568]
	str	q13, [sp, #3584]
	ubfiz	x3, x4, #2, #3
	add	x16, sp, #3568
	ldr	w16, [x16, x3]
	cmp	w16, #5
	cset	w7, eq
	and	w23, w9, w10
	ldrb	w9, [x5, w4, sxtw]
	and	w10, w9, #0x1
	fmov	s1, w10
	ubfx	w10, w9, #1, #1
	mov.b	v1[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v1[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v1[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v1[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v1[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v1[6], w10
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, w4, sxtw]
	and	w10, w9, #0x1
	fmov	s3, w10
	ubfx	w10, w9, #1, #1
	mov.b	v3[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v3[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v3[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v3[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v3[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v3[6], w10
	lsr	w9, w9, #7
	mov.b	v3[7], w9
	orr.8b	v4, v9, v3
	ldr	d0, [sp, #1752]                 ; 8-byte Folded Reload
	and.8b	v5, v0, v1
	eor.8b	v5, v5, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	umaxv.8b	b5, v5
	fmov	w9, s5
	ands	w10, w23, w7
	csetm	w16, ne
	bics	w9, w10, w9
	csetm	w2, ne
	dup.8b	v5, w2
	dup.8b	v6, w16
	bic.8b	v7, v4, v5
	bit.8b	v3, v7, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w4, sxtw]
	bic.8b	v1, v1, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x5, w4, sxtw]
	csinv	w16, w0, w6, eq
	dup.8b	v1, w10
	and	w14, w16, w14
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w9
	and.8b	v3, v3, v4
	str	q12, [sp, #3536]
	str	q19, [sp, #3552]
	add	x9, sp, #3536
	ldr	w9, [x9, x3]
	csel	w15, w9, w15, ne
	bit.8b	v9, v3, v1
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w3, s1
	cmp	w10, #1
	b.ne	LBB0_463
; %bb.460:                              ; %convergence.cascade467
                                        ;   in Loop: Header=BB0_459 Depth=4
	cmp	w15, #0
	ccmp	w11, #6, #2, ne
	b.hi	LBB0_463
; %bb.461:                              ; %convergence.cascade467
                                        ;   in Loop: Header=BB0_459 Depth=4
	add	w11, w11, #1
	tst	w3, #0xff
	b.ne	LBB0_459
	b	LBB0_463
LBB0_462:                               ; %schedule.17.convergence.cascade.exit468_crit_edge
                                        ;   in Loop: Header=BB0_11 Depth=3
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w3, s1
LBB0_463:                               ; %convergence.cascade.exit468
                                        ;   in Loop: Header=BB0_11 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
; %bb.464:                              ; %convergence.target.17.ready
                                        ;   in Loop: Header=BB0_11 Depth=3
	str	q14, [sp, #1728]                ; 16-byte Folded Spill
	rbit	w9, w3
	clz	w9, w9
	ldr	x10, [sp, #616]                 ; 8-byte Folded Reload
	ldr	x11, [sp, #376]                 ; 8-byte Folded Reload
	add	x10, x11, x10
	lsl	x10, x10, #5
	dup.2d	v1, x10
	ldr	q3, [sp, #1472]                 ; 16-byte Folded Reload
	add.2d	v3, v1, v3
	ldr	q4, [sp, #1456]                 ; 16-byte Folded Reload
	add.2d	v4, v1, v4
	ldr	q5, [sp, #1440]                 ; 16-byte Folded Reload
	add.2d	v5, v1, v5
	ldr	q6, [sp, #1424]                 ; 16-byte Folded Reload
	add.2d	v1, v1, v6
	str	q1, [sp, #3520]
	str	q5, [sp, #3504]
	str	q4, [sp, #3488]
	str	q3, [sp, #3472]
	and	x10, x9, #0x7
	add	x11, sp, #3472
	ldr	x10, [x11, x10, lsl #3]
	lsl	w9, w9, #2
	sub	x9, x10, x9
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #728
	add	x9, x10, x9
	ldp	q4, q5, [x9]
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b3, v1
	fmov	w11, s3
	ldr	q1, [sp, #736]                  ; 16-byte Folded Reload
	shl.2d	v6, v1, #2
	ldr	x9, [sp, #216]                  ; 8-byte Folded Reload
	dup.2d	v1, x9
	add.2d	v6, v1, v6
	tbnz	w11, #0, LBB0_488
; %bb.465:                              ; %else4574
                                        ;   in Loop: Header=BB0_11 Depth=3
	str	q23, [sp, #1696]                ; 16-byte Folded Spill
	tbnz	w11, #1, LBB0_489
LBB0_466:                               ; %else4578
                                        ;   in Loop: Header=BB0_11 Depth=3
	ldr	q6, [sp, #720]                  ; 16-byte Folded Reload
	shl.2d	v6, v6, #2
	add.2d	v6, v1, v6
	tbnz	w11, #2, LBB0_490
LBB0_467:                               ; %else4582
                                        ;   in Loop: Header=BB0_11 Depth=3
	str	q25, [sp, #1616]                ; 16-byte Folded Spill
	tbnz	w11, #3, LBB0_491
LBB0_468:                               ; %else4586
                                        ;   in Loop: Header=BB0_11 Depth=3
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	ldr	q6, [sp, #704]                  ; 16-byte Folded Reload
	shl.2d	v6, v6, #2
	add.2d	v6, v1, v6
	tbnz	w11, #4, LBB0_492
LBB0_469:                               ; %else4590
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.16b	v25, v22
	tbnz	w11, #5, LBB0_493
LBB0_470:                               ; %else4594
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.16b	v27, v29
	mov.16b	v23, v28
	ldr	q6, [sp, #688]                  ; 16-byte Folded Reload
	shl.2d	v6, v6, #2
	add.2d	v6, v1, v6
	tbnz	w11, #6, LBB0_494
LBB0_471:                               ; %else4598
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.16b	v24, v21
	tbz	w11, #7, LBB0_473
LBB0_472:                               ; %cond.store4599
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v6[1]
	ldr	q6, [sp, #512]                  ; 16-byte Folded Reload
	st1.s	{ v6 }[3], [x9]
LBB0_473:                               ; %else4602
                                        ;   in Loop: Header=BB0_11 Depth=3
	fabs.4s	v5, v5
	fabs.4s	v4, v4
	zip1.8b	v6, v9, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v4, v6, v4
	zip2.8b	v7, v9, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	and.16b	v5, v7, v5
	ldr	q16, [sp, #1264]                ; 16-byte Folded Reload
	fadd.4s	v5, v16, v5
	ldr	q16, [sp, #1280]                ; 16-byte Folded Reload
	fadd.4s	v4, v16, v4
	ldr	q16, [sp, #1312]                ; 16-byte Folded Reload
	fadd.4s	v4, v16, v4
	ldr	q16, [sp, #1296]                ; 16-byte Folded Reload
	fadd.4s	v5, v16, v5
	ldr	q16, [sp, #1328]                ; 16-byte Folded Reload
	fadd.4s	v5, v16, v5
	ldr	q16, [sp, #1344]                ; 16-byte Folded Reload
	fadd.4s	v4, v16, v4
	ldp	q16, q17, [sp, #912]            ; 32-byte Folded Reload
	fadd.4s	v4, v17, v4
	fadd.4s	v5, v16, v5
	ldr	q16, [sp, #176]                 ; 16-byte Folded Reload
	bit.16b	v16, v5, v7
	dup.2d	v5, x12
	ldr	q7, [sp, #192]                  ; 16-byte Folded Reload
	bit.16b	v7, v4, v6
	stp	q16, q7, [sp, #176]             ; 32-byte Folded Spill
	ldp	q29, q28, [sp, #720]            ; 32-byte Folded Reload
	add.2d	v6, v28, v5
	add.2d	v7, v29, v5
	ldp	q22, q11, [sp, #688]            ; 32-byte Folded Reload
	add.2d	v16, v11, v5
	mov	w9, #16                         ; =0x10
	dup.2d	v4, x9
	add.2d	v5, v22, v5
	cmhi.2d	v17, v4, v29
	cmhi.2d	v18, v4, v28
	uzp1.4s	v17, v18, v17
	cmhi.2d	v18, v4, v11
	cmhi.2d	v20, v4, v22
	uzp1.4s	v18, v18, v20
	uzp1.8h	v17, v17, v18
	xtn.8b	v17, v17
	mov	b18, v9[6]
	mov.b	v18[4], v9[7]
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	mov	b20, v9[4]
	mov.b	v20[4], v9[5]
	ldr	q21, [sp, #224]                 ; 16-byte Folded Reload
	bit.16b	v21, v5, v18
	ushll.2d	v5, v20, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	ldr	q18, [sp, #240]                 ; 16-byte Folded Reload
	bit.16b	v18, v16, v5
	stp	q21, q18, [sp, #224]            ; 32-byte Folded Spill
	mov	b5, v9[2]
	mov.b	v5[4], v9[3]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	ldr	q16, [sp, #256]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v5
	mov	b5, v9[0]
	mov.b	v5[4], v9[1]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	ldr	q7, [sp, #272]                  ; 16-byte Folded Reload
	bit.16b	v7, v6, v5
	stp	q16, q7, [sp, #256]             ; 32-byte Folded Spill
	and.8b	v10, v17, v9
	shl.8b	v5, v10, #7
	cmlt.8b	v5, v5, #0
	umaxv.8b	b6, v5
	fmov	w9, s6
	tbz	w9, #0, LBB0_479
; %bb.474:                              ; %else4602
                                        ;   in Loop: Header=BB0_11 Depth=3
	cmhs.2d	v6, v29, v4
	cmhs.2d	v7, v28, v4
	uzp1.4s	v6, v7, v6
	cmhs.2d	v7, v11, v4
	cmhs.2d	v4, v22, v4
	uzp1.4s	v4, v7, v4
	uzp1.8h	v4, v6, v4
	xtn.8b	v4, v4
	and.8b	v11, v9, v4
	shl.8b	v4, v11, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w9, s4
	tst	w9, #0xff
	b.eq	LBB0_479
; %bb.475:                              ; %varying.divergent502
                                        ;   in Loop: Header=BB0_11 Depth=3
	subs	w9, w15, #1
	csel	w9, wzr, w9, lo
	and	w10, w14, #0xff
	lsr	w11, w10, w9
	tst	w11, #0x1
	str	q8, [sp, #2912]
	str	q13, [sp, #2928]
	and	x9, x9, #0x7
	add	x11, sp, #2912
	ldr	w9, [x11, x9, lsl #2]
	ccmp	w15, #0, #4, ne
	ccmp	w9, #6, #0, ne
	cset	w4, ne
	cmp	w10, #255
	b.ne	LBB0_477
; %bb.476:                              ; %varying.divergent502
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w4, #0, LBB0_603
LBB0_477:                               ; %convergence.overflow.resume505
                                        ;   in Loop: Header=BB0_11 Depth=3
	mvn	w9, w14
	rbit	w9, w9
	clz	w9, w9
	mov	w10, #255                       ; =0xff
	bics	wzr, w10, w14
	csel	w6, wzr, w9, eq
	ldrb	w9, [x5, w6, uxtw]
	and	w10, w9, #0x1
	fmov	s1, w10
	ubfx	w10, w9, #1, #1
	mov.b	v1[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v1[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v1[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v1[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v1[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v1[6], w10
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, w6, uxtw]
	and	w10, w9, #0x1
	fmov	s3, w10
	ubfx	w10, w9, #1, #1
	mov.b	v3[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v3[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v3[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v3[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v3[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v3[6], w10
	lsr	w9, w9, #7
	mov.b	v3[7], w9
	cmp	w4, #0
	csetm	w9, ne
	dup.8b	v4, w9
	bit.8b	v1, v9, v4
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x5, w6, uxtw]
	bic.8b	v1, v3, v4
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x8, w6, uxtw]
	cmp	x13, #8
	b.hs	LBB0_603
; %bb.478:                              ; %ready.overflow.resume507
                                        ;   in Loop: Header=BB0_11 Depth=3
	str	q12, [sp, #2880]
	str	q19, [sp, #2896]
	ubfiz	x9, x6, #2, #3
	add	x10, sp, #2880
	ldr	w10, [x10, x9]
	cmp	w4, #0
	csel	w10, w15, w10, ne
	str	q12, [sp, #2848]
	str	q19, [sp, #2864]
	add	x11, sp, #2848
	str	w10, [x11, x9]
	ldr	q19, [sp, #2864]
	ldr	q12, [sp, #2848]
	str	q8, [sp, #2816]
	str	q13, [sp, #2832]
	add	x10, sp, #2816
	ldr	w10, [x10, x9]
	csinc	w15, w15, w6, eq
	mov	w11, #6                         ; =0x6
	csel	w10, w11, w10, ne
	str	q8, [sp, #2784]
	str	q13, [sp, #2800]
	add	x11, sp, #2784
	str	w10, [x11, x9]
	mov	w7, #19                         ; =0x13
	mov	w11, #18                        ; =0x12
	ldr	q13, [sp, #2800]
	ldr	q8, [sp, #2784]
                                        ; kill: def $w6 killed $w6 killed $x6 def $x6
	mov.16b	v21, v24
	mov.16b	v28, v23
	mov.16b	v22, v25
	str	q0, [sp, #1488]                 ; 16-byte Folded Spill
	ldr	q25, [sp, #1616]                ; 16-byte Folded Reload
	ldr	q23, [sp, #1696]                ; 16-byte Folded Reload
	ldr	q14, [sp, #1728]                ; 16-byte Folded Reload
	mov.16b	v29, v27
	b	LBB0_10
LBB0_479:                               ; %varying.coherent503
                                        ;   in Loop: Header=BB0_11 Depth=3
	and.8b	v4, v5, v2
	addv.8b	b4, v4
	fmov	w9, s4
	tst	w9, #0xff
	b.eq	LBB0_495
; %bb.480:                              ; %schedule.18.thread
                                        ;   in Loop: Header=BB0_11 Depth=3
	ldr	q4, [sp, #272]                  ; 16-byte Folded Reload
	shl.2d	v4, v4, #2
	add.2d	v4, v1, v4
	fmov	w11, s3
	mov.16b	v21, v24
	tbnz	w11, #0, LBB0_496
; %bb.481:                              ; %else4607
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.16b	v28, v23
	mov.16b	v29, v27
	tbnz	w11, #1, LBB0_497
LBB0_482:                               ; %else4611
                                        ;   in Loop: Header=BB0_11 Depth=3
	ldr	q3, [sp, #256]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v3, v1, v3
	mov.16b	v22, v25
	tbnz	w11, #2, LBB0_498
LBB0_483:                               ; %else4615
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #3, LBB0_499
LBB0_484:                               ; %else4619
                                        ;   in Loop: Header=BB0_11 Depth=3
	ldr	q3, [sp, #240]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v3, v1, v3
	ldr	q25, [sp, #1616]                ; 16-byte Folded Reload
	tbnz	w11, #4, LBB0_500
LBB0_485:                               ; %else4623
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #5, LBB0_501
LBB0_486:                               ; %else4627
                                        ;   in Loop: Header=BB0_11 Depth=3
	ldr	q3, [sp, #224]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v1, v1, v3
	ldr	q23, [sp, #1696]                ; 16-byte Folded Reload
	tbnz	w11, #6, LBB0_502
LBB0_487:                               ; %else4631
                                        ;   in Loop: Header=BB0_11 Depth=3
	ldr	q14, [sp, #1728]                ; 16-byte Folded Reload
	tbnz	w11, #7, LBB0_503
	b	LBB0_504
LBB0_488:                               ; %cond.store4571
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d6
	ldr	q7, [sp, #528]                  ; 16-byte Folded Reload
	str	s7, [x9]
	str	q23, [sp, #1696]                ; 16-byte Folded Spill
	tbz	w11, #1, LBB0_466
LBB0_489:                               ; %cond.store4575
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v6[1]
	ldr	q6, [sp, #528]                  ; 16-byte Folded Reload
	st1.s	{ v6 }[1], [x9]
	ldr	q6, [sp, #720]                  ; 16-byte Folded Reload
	shl.2d	v6, v6, #2
	add.2d	v6, v1, v6
	tbz	w11, #2, LBB0_467
LBB0_490:                               ; %cond.store4579
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d6
	ldr	q7, [sp, #528]                  ; 16-byte Folded Reload
	st1.s	{ v7 }[2], [x9]
	str	q25, [sp, #1616]                ; 16-byte Folded Spill
	tbz	w11, #3, LBB0_468
LBB0_491:                               ; %cond.store4583
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v6[1]
	ldr	q6, [sp, #528]                  ; 16-byte Folded Reload
	st1.s	{ v6 }[3], [x9]
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	ldr	q6, [sp, #704]                  ; 16-byte Folded Reload
	shl.2d	v6, v6, #2
	add.2d	v6, v1, v6
	tbz	w11, #4, LBB0_469
LBB0_492:                               ; %cond.store4587
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d6
	ldr	q7, [sp, #512]                  ; 16-byte Folded Reload
	str	s7, [x9]
	mov.16b	v25, v22
	tbz	w11, #5, LBB0_470
LBB0_493:                               ; %cond.store4591
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v6[1]
	ldr	q6, [sp, #512]                  ; 16-byte Folded Reload
	st1.s	{ v6 }[1], [x9]
	mov.16b	v27, v29
	mov.16b	v23, v28
	ldr	q6, [sp, #688]                  ; 16-byte Folded Reload
	shl.2d	v6, v6, #2
	add.2d	v6, v1, v6
	tbz	w11, #6, LBB0_471
LBB0_494:                               ; %cond.store4595
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d6
	ldr	q7, [sp, #512]                  ; 16-byte Folded Reload
	st1.s	{ v7 }[2], [x9]
	mov.16b	v24, v21
	tbnz	w11, #7, LBB0_472
	b	LBB0_473
LBB0_495:                               ;   in Loop: Header=BB0_11 Depth=3
	mov.16b	v21, v24
	mov.16b	v28, v23
	mov.16b	v22, v25
	str	q0, [sp, #1488]                 ; 16-byte Folded Spill
	ldr	q25, [sp, #1616]                ; 16-byte Folded Reload
	ldr	q23, [sp, #1696]                ; 16-byte Folded Reload
	ldr	q14, [sp, #1728]                ; 16-byte Folded Reload
	mov.16b	v29, v27
	b	LBB0_504
LBB0_496:                               ; %cond.store4604
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d4
	ldr	q3, [sp, #464]                  ; 16-byte Folded Reload
	str	s3, [x9]
	mov.16b	v28, v23
	mov.16b	v29, v27
	tbz	w11, #1, LBB0_482
LBB0_497:                               ; %cond.store4608
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v4[1]
	ldr	q3, [sp, #464]                  ; 16-byte Folded Reload
	st1.s	{ v3 }[1], [x9]
	ldr	q3, [sp, #256]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v3, v1, v3
	mov.16b	v22, v25
	tbz	w11, #2, LBB0_483
LBB0_498:                               ; %cond.store4612
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d3
	ldr	q4, [sp, #464]                  ; 16-byte Folded Reload
	st1.s	{ v4 }[2], [x9]
	tbz	w11, #3, LBB0_484
LBB0_499:                               ; %cond.store4616
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v3[1]
	ldr	q3, [sp, #464]                  ; 16-byte Folded Reload
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #240]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v3, v1, v3
	ldr	q25, [sp, #1616]                ; 16-byte Folded Reload
	tbz	w11, #4, LBB0_485
LBB0_500:                               ; %cond.store4620
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d3
	ldr	q4, [sp, #448]                  ; 16-byte Folded Reload
	str	s4, [x9]
	tbz	w11, #5, LBB0_486
LBB0_501:                               ; %cond.store4624
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v3[1]
	ldr	q3, [sp, #448]                  ; 16-byte Folded Reload
	st1.s	{ v3 }[1], [x9]
	ldr	q3, [sp, #224]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v1, v1, v3
	ldr	q23, [sp, #1696]                ; 16-byte Folded Reload
	tbz	w11, #6, LBB0_487
LBB0_502:                               ; %cond.store4628
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d1
	ldr	q3, [sp, #448]                  ; 16-byte Folded Reload
	st1.s	{ v3 }[2], [x9]
	ldr	q14, [sp, #1728]                ; 16-byte Folded Reload
	tbz	w11, #7, LBB0_504
LBB0_503:                               ; %cond.store4632
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v1[1]
	ldr	q1, [sp, #448]                  ; 16-byte Folded Reload
	st1.s	{ v1 }[3], [x9]
LBB0_504:                               ; %schedule.19
                                        ;   in Loop: Header=BB0_11 Depth=3
	cbz	w15, LBB0_509
; %bb.505:                              ; %convergence.cascade512.preheader
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.16b	v30, v21
	mov.16b	v27, v28
	mov.16b	v15, v22
	mov	w11, #0                         ; =0x0
LBB0_506:                               ; %convergence.cascade512
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_11 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w9, s3
	umaxv.8b	b1, v1
	fmov	w10, s1
	sub	w16, w15, #1
	tst	w9, #0xff
	csel	w4, w16, wzr, ne
	lsl	w6, w12, w4
	and	w9, w6, w14
	tst	w9, #0xff
	cset	w9, ne
	str	q8, [sp, #3440]
	str	q13, [sp, #3456]
	ubfiz	x3, x4, #2, #3
	add	x16, sp, #3440
	ldr	w16, [x16, x3]
	cmp	w16, #6
	cset	w7, eq
	and	w23, w9, w10
	ldrb	w9, [x5, w4, sxtw]
	and	w10, w9, #0x1
	fmov	s1, w10
	ubfx	w10, w9, #1, #1
	mov.b	v1[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v1[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v1[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v1[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v1[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v1[6], w10
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, w4, sxtw]
	and	w10, w9, #0x1
	fmov	s3, w10
	ubfx	w10, w9, #1, #1
	mov.b	v3[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v3[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v3[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v3[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v3[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v3[6], w10
	lsr	w9, w9, #7
	mov.b	v3[7], w9
	orr.8b	v4, v9, v3
	ldr	d0, [sp, #1752]                 ; 8-byte Folded Reload
	and.8b	v5, v0, v1
	eor.8b	v5, v5, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	umaxv.8b	b5, v5
	fmov	w9, s5
	ands	w10, w23, w7
	csetm	w16, ne
	bics	w9, w10, w9
	csetm	w2, ne
	dup.8b	v5, w2
	dup.8b	v6, w16
	bic.8b	v7, v4, v5
	bit.8b	v3, v7, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w4, sxtw]
	bic.8b	v1, v1, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x5, w4, sxtw]
	csinv	w16, w0, w6, eq
	dup.8b	v1, w10
	and	w14, w16, w14
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w9
	and.8b	v3, v3, v4
	str	q12, [sp, #3408]
	str	q19, [sp, #3424]
	add	x9, sp, #3408
	ldr	w9, [x9, x3]
	csel	w15, w9, w15, ne
	bit.8b	v9, v3, v1
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w3, s1
	cmp	w10, #1
	b.ne	LBB0_510
; %bb.507:                              ; %convergence.cascade512
                                        ;   in Loop: Header=BB0_506 Depth=4
	cmp	w15, #0
	ccmp	w11, #6, #2, ne
	b.hi	LBB0_510
; %bb.508:                              ; %convergence.cascade512
                                        ;   in Loop: Header=BB0_506 Depth=4
	add	w11, w11, #1
	tst	w3, #0xff
	b.ne	LBB0_506
	b	LBB0_510
LBB0_509:                               ; %schedule.19.convergence.cascade.exit513_crit_edge
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.16b	v30, v21
	mov.16b	v27, v28
	mov.16b	v15, v22
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w3, s1
LBB0_510:                               ; %convergence.cascade.exit513
                                        ;   in Loop: Header=BB0_11 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_545
; %bb.511:                              ; %convergence.target.19.ready
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov	w9, #2                          ; =0x2
	dup.2d	v3, x9
	ldp	q21, q20, [sp, #720]            ; 32-byte Folded Reload
	add.2d	v4, v20, v3
	add.2d	v5, v21, v3
	ldp	q22, q28, [sp, #688]            ; 32-byte Folded Reload
	add.2d	v6, v28, v3
	mov	w9, #15                         ; =0xf
	dup.2d	v1, x9
	add.2d	v3, v22, v3
	cmhi.2d	v7, v1, v21
	cmhi.2d	v16, v1, v20
	uzp1.4s	v7, v16, v7
	cmhi.2d	v16, v1, v28
	cmhi.2d	v17, v1, v22
	uzp1.4s	v16, v16, v17
	uzp1.8h	v7, v7, v16
	xtn.8b	v7, v7
	mov	b16, v9[6]
	mov.b	v16[4], v9[7]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	mov	b17, v9[4]
	mov.b	v17[4], v9[5]
	ldr	q18, [sp, #544]                 ; 16-byte Folded Reload
	bit.16b	v18, v3, v16
	ushll.2d	v3, v17, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q16, [sp, #560]                 ; 16-byte Folded Reload
	bit.16b	v16, v6, v3
	stp	q18, q16, [sp, #544]            ; 32-byte Folded Spill
	mov	b3, v9[2]
	mov.b	v3[4], v9[3]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q6, [sp, #576]                  ; 16-byte Folded Reload
	bit.16b	v6, v5, v3
	mov	b3, v9[0]
	mov.b	v3[4], v9[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q5, [sp, #592]                  ; 16-byte Folded Reload
	bit.16b	v5, v4, v3
	stp	q6, q5, [sp, #576]              ; 32-byte Folded Spill
	and.8b	v10, v7, v9
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b4, v3
	fmov	w9, s4
	tbz	w9, #0, LBB0_517
; %bb.512:                              ; %convergence.target.19.ready
                                        ;   in Loop: Header=BB0_11 Depth=3
	cmhs.2d	v4, v21, v1
	cmhs.2d	v5, v20, v1
	uzp1.4s	v4, v5, v4
	cmhs.2d	v5, v28, v1
	cmhs.2d	v1, v22, v1
	uzp1.4s	v1, v5, v1
	uzp1.8h	v1, v4, v1
	xtn.8b	v1, v1
	and.8b	v11, v9, v1
	shl.8b	v1, v11, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w9, s1
	tst	w9, #0xff
	b.eq	LBB0_517
; %bb.513:                              ; %varying.divergent533
                                        ;   in Loop: Header=BB0_11 Depth=3
	subs	w9, w15, #1
	csel	w9, wzr, w9, lo
	and	w10, w14, #0xff
	lsr	w11, w10, w9
	tst	w11, #0x1
	str	q8, [sp, #3072]
	str	q13, [sp, #3088]
	and	x9, x9, #0x7
	add	x11, sp, #3072
	ldr	w9, [x11, x9, lsl #2]
	ccmp	w15, #0, #4, ne
	ccmp	w9, #7, #0, ne
	cset	w4, ne
	cmp	w10, #255
	b.ne	LBB0_515
; %bb.514:                              ; %varying.divergent533
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w4, #0, LBB0_603
LBB0_515:                               ; %convergence.overflow.resume536
                                        ;   in Loop: Header=BB0_11 Depth=3
	mvn	w9, w14
	rbit	w9, w9
	clz	w9, w9
	mov	w10, #255                       ; =0xff
	bics	wzr, w10, w14
	csel	w6, wzr, w9, eq
	ldrb	w9, [x5, w6, uxtw]
	and	w10, w9, #0x1
	fmov	s1, w10
	ubfx	w10, w9, #1, #1
	mov.b	v1[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v1[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v1[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v1[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v1[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v1[6], w10
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, w6, uxtw]
	and	w10, w9, #0x1
	fmov	s3, w10
	ubfx	w10, w9, #1, #1
	mov.b	v3[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v3[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v3[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v3[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v3[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v3[6], w10
	lsr	w9, w9, #7
	mov.b	v3[7], w9
	cmp	w4, #0
	csetm	w9, ne
	dup.8b	v4, w9
	bit.8b	v1, v9, v4
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x5, w6, uxtw]
	bic.8b	v1, v3, v4
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x8, w6, uxtw]
	cmp	x13, #8
	b.hs	LBB0_603
; %bb.516:                              ; %ready.overflow.resume538
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.16b	v22, v15
	mov.16b	v28, v27
	mov.16b	v21, v30
	str	q12, [sp, #3040]
	str	q19, [sp, #3056]
	ubfiz	x9, x6, #2, #3
	add	x10, sp, #3040
	ldr	w10, [x10, x9]
	cmp	w4, #0
	csel	w10, w15, w10, ne
	str	q12, [sp, #3008]
	str	q19, [sp, #3024]
	add	x11, sp, #3008
	str	w10, [x11, x9]
	ldr	q19, [sp, #3024]
	ldr	q12, [sp, #3008]
	str	q8, [sp, #2976]
	str	q13, [sp, #2992]
	add	x10, sp, #2976
	ldr	w10, [x10, x9]
	csinc	w15, w15, w6, eq
	mov	w11, #7                         ; =0x7
	csel	w10, w11, w10, ne
	str	q8, [sp, #2944]
	str	q13, [sp, #2960]
	add	x11, sp, #2944
	str	w10, [x11, x9]
	mov	w7, #21                         ; =0x15
	mov	w11, #20                        ; =0x14
	ldr	q13, [sp, #2960]
	ldr	q8, [sp, #2944]
	b	LBB0_9
LBB0_517:                               ; %varying.coherent534
                                        ;   in Loop: Header=BB0_11 Depth=3
	and.8b	v1, v3, v2
	addv.8b	b1, v1
	fmov	w9, s1
	tst	w9, #0xff
	mov.16b	v22, v15
	mov.16b	v28, v27
	mov.16b	v21, v30
	b.eq	LBB0_527
; %bb.518:                              ; %schedule.20.thread
                                        ;   in Loop: Header=BB0_11 Depth=3
	ldr	q1, [sp, #592]                  ; 16-byte Folded Reload
	shl.2d	v3, v1, #2
	ldr	x9, [sp, #216]                  ; 8-byte Folded Reload
	dup.2d	v1, x9
	add.2d	v3, v1, v3
	shl.8b	v4, v9, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w11, s4
	tbnz	w11, #0, LBB0_538
; %bb.519:                              ; %else4640
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #1, LBB0_539
LBB0_520:                               ; %else4644
                                        ;   in Loop: Header=BB0_11 Depth=3
	ldr	q3, [sp, #576]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v3, v1, v3
	tbnz	w11, #2, LBB0_540
LBB0_521:                               ; %else4648
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #3, LBB0_541
LBB0_522:                               ; %else4652
                                        ;   in Loop: Header=BB0_11 Depth=3
	ldr	q3, [sp, #560]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v3, v1, v3
	tbnz	w11, #4, LBB0_542
LBB0_523:                               ; %else4656
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbnz	w11, #5, LBB0_543
LBB0_524:                               ; %else4660
                                        ;   in Loop: Header=BB0_11 Depth=3
	ldr	q3, [sp, #544]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v1, v1, v3
	tbnz	w11, #6, LBB0_544
LBB0_525:                               ; %else4664
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbz	w11, #7, LBB0_527
LBB0_526:                               ; %cond.store4665
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v1[1]
	ldr	q1, [sp, #624]                  ; 16-byte Folded Reload
	st1.s	{ v1 }[3], [x9]
LBB0_527:                               ; %schedule.21
                                        ;   in Loop: Header=BB0_11 Depth=3
	cbz	w15, LBB0_532
; %bb.528:                              ; %convergence.cascade543.preheader
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.16b	v30, v21
	mov.16b	v27, v28
	mov.16b	v15, v22
	mov	w11, #0                         ; =0x0
LBB0_529:                               ; %convergence.cascade543
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_11 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w9, s3
	umaxv.8b	b1, v1
	fmov	w10, s1
	sub	w16, w15, #1
	tst	w9, #0xff
	csel	w4, w16, wzr, ne
	lsl	w6, w12, w4
	and	w9, w6, w14
	tst	w9, #0xff
	cset	w9, ne
	str	q8, [sp, #3376]
	str	q13, [sp, #3392]
	ubfiz	x3, x4, #2, #3
	ldr	w16, [x30, x3]
	cmp	w16, #7
	cset	w7, eq
	and	w23, w9, w10
	ldrb	w9, [x5, w4, sxtw]
	and	w10, w9, #0x1
	fmov	s1, w10
	ubfx	w10, w9, #1, #1
	mov.b	v1[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v1[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v1[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v1[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v1[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v1[6], w10
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, w4, sxtw]
	and	w10, w9, #0x1
	fmov	s3, w10
	ubfx	w10, w9, #1, #1
	mov.b	v3[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v3[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v3[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v3[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v3[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v3[6], w10
	lsr	w9, w9, #7
	mov.b	v3[7], w9
	orr.8b	v4, v9, v3
	ldr	d0, [sp, #1752]                 ; 8-byte Folded Reload
	and.8b	v5, v0, v1
	eor.8b	v5, v5, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	umaxv.8b	b5, v5
	fmov	w9, s5
	ands	w10, w23, w7
	csetm	w16, ne
	bics	w9, w10, w9
	csetm	w2, ne
	dup.8b	v5, w2
	dup.8b	v6, w16
	bic.8b	v7, v4, v5
	bit.8b	v3, v7, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w4, sxtw]
	bic.8b	v1, v1, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x5, w4, sxtw]
	csinv	w16, w0, w6, eq
	dup.8b	v1, w10
	and	w14, w16, w14
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w9
	and.8b	v3, v3, v4
	str	q12, [sp, #3344]
	str	q19, [sp, #3360]
	ldr	w9, [x24, x3]
	csel	w15, w9, w15, ne
	bit.8b	v9, v3, v1
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w3, s1
	cmp	w10, #1
	b.ne	LBB0_533
; %bb.530:                              ; %convergence.cascade543
                                        ;   in Loop: Header=BB0_529 Depth=4
	cmp	w15, #0
	ccmp	w11, #6, #2, ne
	b.hi	LBB0_533
; %bb.531:                              ; %convergence.cascade543
                                        ;   in Loop: Header=BB0_529 Depth=4
	add	w11, w11, #1
	tst	w3, #0xff
	b.ne	LBB0_529
	b	LBB0_533
LBB0_532:                               ; %schedule.21.convergence.cascade.exit544_crit_edge
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.16b	v30, v21
	mov.16b	v27, v28
	mov.16b	v15, v22
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w3, s1
LBB0_533:                               ; %convergence.cascade.exit544
                                        ;   in Loop: Header=BB0_11 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_545
; %bb.534:                              ; %convergence.target.21.ready
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov	w9, #3                          ; =0x3
	dup.2d	v3, x9
	ldp	q21, q20, [sp, #720]            ; 32-byte Folded Reload
	add.2d	v4, v20, v3
	add.2d	v5, v21, v3
	ldp	q22, q28, [sp, #688]            ; 32-byte Folded Reload
	add.2d	v6, v28, v3
	mov	w9, #14                         ; =0xe
	dup.2d	v1, x9
	add.2d	v3, v22, v3
	cmhi.2d	v7, v1, v21
	cmhi.2d	v16, v1, v20
	uzp1.4s	v7, v16, v7
	cmhi.2d	v16, v1, v28
	cmhi.2d	v17, v1, v22
	uzp1.4s	v16, v16, v17
	uzp1.8h	v7, v7, v16
	xtn.8b	v7, v7
	mov	b16, v9[6]
	mov.b	v16[4], v9[7]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	mov	b17, v9[4]
	mov.b	v17[4], v9[5]
	ldr	q18, [sp, #384]                 ; 16-byte Folded Reload
	bit.16b	v18, v3, v16
	ushll.2d	v3, v17, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q16, [sp, #400]                 ; 16-byte Folded Reload
	bit.16b	v16, v6, v3
	stp	q18, q16, [sp, #384]            ; 32-byte Folded Spill
	mov	b3, v9[2]
	mov.b	v3[4], v9[3]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q6, [sp, #416]                  ; 16-byte Folded Reload
	bit.16b	v6, v5, v3
	mov	b3, v9[0]
	mov.b	v3[4], v9[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q5, [sp, #432]                  ; 16-byte Folded Reload
	bit.16b	v5, v4, v3
	stp	q6, q5, [sp, #416]              ; 32-byte Folded Spill
	and.8b	v10, v7, v9
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b4, v3
	fmov	w9, s4
	tbz	w9, #0, LBB0_546
; %bb.535:                              ; %convergence.target.21.ready
                                        ;   in Loop: Header=BB0_11 Depth=3
	cmhs.2d	v4, v21, v1
	cmhs.2d	v5, v20, v1
	uzp1.4s	v4, v5, v4
	cmhs.2d	v5, v28, v1
	cmhs.2d	v1, v22, v1
	uzp1.4s	v1, v5, v1
	uzp1.8h	v1, v4, v1
	xtn.8b	v1, v1
	and.8b	v11, v9, v1
	shl.8b	v1, v11, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w9, s1
	tst	w9, #0xff
	b.eq	LBB0_546
; %bb.536:                              ; %varying.divergent564
                                        ;   in Loop: Header=BB0_11 Depth=3
	subs	w9, w15, #1
	csel	w9, wzr, w9, lo
	and	w10, w14, #0xff
	lsr	w11, w10, w9
	tst	w11, #0x1
	str	q8, [sp, #3232]
	str	q13, [sp, #3248]
	and	x9, x9, #0x7
	add	x11, sp, #3232
	ldr	w9, [x11, x9, lsl #2]
	ccmp	w15, #0, #4, ne
	ccmp	w9, #8, #0, ne
	cset	w4, ne
	cmp	w10, #255
	b.ne	LBB0_7
; %bb.537:                              ; %varying.divergent564
                                        ;   in Loop: Header=BB0_11 Depth=3
	tbz	w4, #0, LBB0_7
	b	LBB0_603
LBB0_538:                               ; %cond.store4637
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d3
	ldr	q4, [sp, #640]                  ; 16-byte Folded Reload
	str	s4, [x9]
	tbz	w11, #1, LBB0_520
LBB0_539:                               ; %cond.store4641
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v3[1]
	ldr	q3, [sp, #640]                  ; 16-byte Folded Reload
	st1.s	{ v3 }[1], [x9]
	ldr	q3, [sp, #576]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v3, v1, v3
	tbz	w11, #2, LBB0_521
LBB0_540:                               ; %cond.store4645
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d3
	ldr	q4, [sp, #640]                  ; 16-byte Folded Reload
	st1.s	{ v4 }[2], [x9]
	tbz	w11, #3, LBB0_522
LBB0_541:                               ; %cond.store4649
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v3[1]
	ldr	q3, [sp, #640]                  ; 16-byte Folded Reload
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #560]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v3, v1, v3
	tbz	w11, #4, LBB0_523
LBB0_542:                               ; %cond.store4653
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d3
	ldr	q4, [sp, #624]                  ; 16-byte Folded Reload
	str	s4, [x9]
	tbz	w11, #5, LBB0_524
LBB0_543:                               ; %cond.store4657
                                        ;   in Loop: Header=BB0_11 Depth=3
	mov.d	x9, v3[1]
	ldr	q3, [sp, #624]                  ; 16-byte Folded Reload
	st1.s	{ v3 }[1], [x9]
	ldr	q3, [sp, #544]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v1, v1, v3
	tbz	w11, #6, LBB0_525
LBB0_544:                               ; %cond.store4661
                                        ;   in Loop: Header=BB0_11 Depth=3
	fmov	x9, d1
	ldr	q3, [sp, #624]                  ; 16-byte Folded Reload
	st1.s	{ v3 }[2], [x9]
	tbnz	w11, #7, LBB0_526
	b	LBB0_527
LBB0_545:                               ;   in Loop: Header=BB0_6 Depth=2
	mov.16b	v22, v15
	mov.16b	v28, v27
	mov.16b	v21, v30
	cbnz	x13, LBB0_6
	b	LBB0_601
LBB0_546:                               ; %varying.coherent565
                                        ;   in Loop: Header=BB0_6 Depth=2
	and.8b	v1, v3, v2
	addv.8b	b1, v1
	fmov	w9, s1
	tst	w9, #0xff
	b.eq	LBB0_556
; %bb.547:                              ; %schedule.22.thread
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #432]                  ; 16-byte Folded Reload
	shl.2d	v3, v1, #2
	ldr	x9, [sp, #216]                  ; 8-byte Folded Reload
	dup.2d	v1, x9
	add.2d	v3, v1, v3
	shl.8b	v4, v9, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w11, s4
	mov.16b	v22, v15
	mov.16b	v28, v27
	mov.16b	v21, v30
	tbnz	w11, #0, LBB0_566
; %bb.548:                              ; %else4673
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w11, #1, LBB0_567
LBB0_549:                               ; %else4677
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q3, [sp, #416]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v3, v1, v3
	tbnz	w11, #2, LBB0_568
LBB0_550:                               ; %else4681
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w11, #3, LBB0_569
LBB0_551:                               ; %else4685
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q3, [sp, #400]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v3, v1, v3
	tbnz	w11, #4, LBB0_570
LBB0_552:                               ; %else4689
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w11, #5, LBB0_571
LBB0_553:                               ; %else4693
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q3, [sp, #384]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v1, v1, v3
	tbnz	w11, #6, LBB0_572
LBB0_554:                               ; %else4697
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w11, #7, LBB0_573
	b	LBB0_582
LBB0_555:                               ;   in Loop: Header=BB0_6 Depth=2
	ldr	q28, [sp, #1504]                ; 16-byte Folded Reload
	ldr	q31, [sp, #1584]                ; 16-byte Folded Reload
	ldr	q21, [sp, #1520]                ; 16-byte Folded Reload
	mov.16b	v25, v17
	cbnz	x13, LBB0_6
	b	LBB0_601
LBB0_556:                               ;   in Loop: Header=BB0_6 Depth=2
	mov.16b	v22, v15
	mov.16b	v28, v27
	mov.16b	v21, v30
	b	LBB0_582
LBB0_557:                               ; %schedule.22
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w11, s1
	ldr	q1, [sp, #432]                  ; 16-byte Folded Reload
	shl.2d	v3, v1, #2
	ldr	x9, [sp, #216]                  ; 8-byte Folded Reload
	dup.2d	v1, x9
	add.2d	v3, v1, v3
	tbnz	w11, #0, LBB0_574
; %bb.558:                              ; %else4459
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w11, #1, LBB0_575
LBB0_559:                               ; %else4463
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q3, [sp, #416]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v3, v1, v3
	tbnz	w11, #2, LBB0_576
LBB0_560:                               ; %else4467
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w11, #3, LBB0_577
LBB0_561:                               ; %else4471
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q3, [sp, #400]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v3, v1, v3
	tbnz	w11, #4, LBB0_578
LBB0_562:                               ; %else4475
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w11, #5, LBB0_579
LBB0_563:                               ; %else4479
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q3, [sp, #384]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v1, v1, v3
	tbnz	w11, #6, LBB0_580
LBB0_564:                               ; %else4483
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w11, #7, LBB0_581
LBB0_565:                               ; %else4487
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w11, #0xff
	b.ne	LBB0_582
	b	LBB0_5
LBB0_566:                               ; %cond.store4670
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x9, d3
	ldr	q4, [sp, #192]                  ; 16-byte Folded Reload
	str	s4, [x9]
	tbz	w11, #1, LBB0_549
LBB0_567:                               ; %cond.store4674
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x9, v3[1]
	ldr	q3, [sp, #192]                  ; 16-byte Folded Reload
	st1.s	{ v3 }[1], [x9]
	ldr	q3, [sp, #416]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v3, v1, v3
	tbz	w11, #2, LBB0_550
LBB0_568:                               ; %cond.store4678
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x9, d3
	ldr	q4, [sp, #192]                  ; 16-byte Folded Reload
	st1.s	{ v4 }[2], [x9]
	tbz	w11, #3, LBB0_551
LBB0_569:                               ; %cond.store4682
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x9, v3[1]
	ldr	q3, [sp, #192]                  ; 16-byte Folded Reload
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #400]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v3, v1, v3
	tbz	w11, #4, LBB0_552
LBB0_570:                               ; %cond.store4686
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x9, d3
	ldr	q4, [sp, #176]                  ; 16-byte Folded Reload
	str	s4, [x9]
	tbz	w11, #5, LBB0_553
LBB0_571:                               ; %cond.store4690
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x9, v3[1]
	ldr	q3, [sp, #176]                  ; 16-byte Folded Reload
	st1.s	{ v3 }[1], [x9]
	ldr	q3, [sp, #384]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v1, v1, v3
	tbz	w11, #6, LBB0_554
LBB0_572:                               ; %cond.store4694
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x9, d1
	ldr	q3, [sp, #176]                  ; 16-byte Folded Reload
	st1.s	{ v3 }[2], [x9]
	tbz	w11, #7, LBB0_582
LBB0_573:                               ; %cond.store4698
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x9, v1[1]
	ldr	q1, [sp, #176]                  ; 16-byte Folded Reload
	st1.s	{ v1 }[3], [x9]
	b	LBB0_582
LBB0_574:                               ; %cond.store4456
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x9, d3
	ldr	q4, [sp, #192]                  ; 16-byte Folded Reload
	str	s4, [x9]
	tbz	w11, #1, LBB0_559
LBB0_575:                               ; %cond.store4460
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x9, v3[1]
	ldr	q3, [sp, #192]                  ; 16-byte Folded Reload
	st1.s	{ v3 }[1], [x9]
	ldr	q3, [sp, #416]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v3, v1, v3
	tbz	w11, #2, LBB0_560
LBB0_576:                               ; %cond.store4464
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x9, d3
	ldr	q4, [sp, #192]                  ; 16-byte Folded Reload
	st1.s	{ v4 }[2], [x9]
	tbz	w11, #3, LBB0_561
LBB0_577:                               ; %cond.store4468
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x9, v3[1]
	ldr	q3, [sp, #192]                  ; 16-byte Folded Reload
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #400]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v3, v1, v3
	tbz	w11, #4, LBB0_562
LBB0_578:                               ; %cond.store4472
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x9, d3
	ldr	q4, [sp, #176]                  ; 16-byte Folded Reload
	str	s4, [x9]
	tbz	w11, #5, LBB0_563
LBB0_579:                               ; %cond.store4476
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x9, v3[1]
	ldr	q3, [sp, #176]                  ; 16-byte Folded Reload
	st1.s	{ v3 }[1], [x9]
	ldr	q3, [sp, #384]                  ; 16-byte Folded Reload
	shl.2d	v3, v3, #2
	add.2d	v1, v1, v3
	tbz	w11, #6, LBB0_564
LBB0_580:                               ; %cond.store4480
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x9, d1
	ldr	q3, [sp, #176]                  ; 16-byte Folded Reload
	st1.s	{ v3 }[2], [x9]
	tbz	w11, #7, LBB0_565
LBB0_581:                               ; %cond.store4484
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x9, v1[1]
	ldr	q1, [sp, #176]                  ; 16-byte Folded Reload
	st1.s	{ v1 }[3], [x9]
	tst	w11, #0xff
	b.eq	LBB0_5
LBB0_582:                               ; %schedule.23
                                        ;   in Loop: Header=BB0_6 Depth=2
	cbz	w15, LBB0_3
; %bb.583:                              ; %convergence.cascade574.preheader
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w11, #0                         ; =0x0
LBB0_584:                               ; %convergence.cascade574
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v3, v1, v2
	addv.8b	b3, v3
	fmov	w9, s3
	umaxv.8b	b1, v1
	fmov	w10, s1
	sub	w16, w15, #1
	tst	w9, #0xff
	csel	w4, w16, wzr, ne
	lsl	w6, w12, w4
	and	w9, w6, w14
	tst	w9, #0xff
	cset	w9, ne
	str	q8, [sp, #3312]
	str	q13, [sp, #3328]
	ubfiz	x3, x4, #2, #3
	add	x16, sp, #3312
	ldr	w16, [x16, x3]
	cmp	w16, #8
	cset	w7, eq
	and	w23, w9, w10
	ldrb	w9, [x5, w4, sxtw]
	and	w10, w9, #0x1
	fmov	s1, w10
	ubfx	w10, w9, #1, #1
	mov.b	v1[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v1[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v1[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v1[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v1[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v1[6], w10
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, w4, sxtw]
	and	w10, w9, #0x1
	fmov	s3, w10
	ubfx	w10, w9, #1, #1
	mov.b	v3[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v3[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v3[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v3[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v3[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v3[6], w10
	lsr	w9, w9, #7
	mov.b	v3[7], w9
	orr.8b	v4, v9, v3
	ldr	d0, [sp, #1752]                 ; 8-byte Folded Reload
	and.8b	v5, v0, v1
	eor.8b	v5, v5, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	umaxv.8b	b5, v5
	fmov	w9, s5
	ands	w10, w23, w7
	csetm	w16, ne
	bics	w9, w10, w9
	csetm	w2, ne
	dup.8b	v5, w2
	dup.8b	v6, w16
	bic.8b	v7, v4, v5
	bit.8b	v3, v7, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, w4, sxtw]
	bic.8b	v1, v1, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x5, w4, sxtw]
	csinv	w16, w0, w6, eq
	dup.8b	v1, w10
	and	w14, w16, w14
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	dup.8b	v3, w9
	and.8b	v3, v3, v4
	str	q12, [sp, #3280]
	str	q19, [sp, #3296]
	add	x9, sp, #3280
	ldr	w9, [x9, x3]
	csel	w15, w9, w15, ne
	bit.8b	v9, v3, v1
	shl.8b	v1, v9, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w3, s1
	cmp	w10, #1
	b.ne	LBB0_4
; %bb.585:                              ; %convergence.cascade574
                                        ;   in Loop: Header=BB0_584 Depth=3
	cmp	w15, #0
	ccmp	w11, #6, #2, ne
	b.hi	LBB0_4
; %bb.586:                              ; %convergence.cascade574
                                        ;   in Loop: Header=BB0_584 Depth=3
	add	w11, w11, #1
	tst	w3, #0xff
	b.ne	LBB0_584
	b	LBB0_4
LBB0_587:                               ; %convergence.target.23.ready
                                        ;   in Loop: Header=BB0_2 Depth=1
	mov.16b	v27, v25
	mov.16b	v15, v28
	mov.16b	v11, v22
	mov.16b	v22, v21
	ldr	d0, [sp, #1752]                 ; 8-byte Folded Reload
	bic.8b	v0, v0, v9
	str	d0, [sp, #1752]                 ; 8-byte Folded Spill
	tst	w14, #0xff
Lloh18:
	adrp	x16, l_convergence.targets@PAGE
Lloh19:
	add	x16, x16, l_convergence.targets@PAGEOFF
	b.eq	LBB0_600
; %bb.588:                              ; %return.frame.cleanup
                                        ;   in Loop: Header=BB0_2 Depth=1
	ldrb	w9, [x8, #8]
	and	w10, w9, #0x1
	fmov	s1, w10
	ubfx	w10, w9, #1, #1
	mov.b	v1[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v1[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v1[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v1[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v1[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v1[6], w10
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8]
	and	w10, w9, #0x1
	fmov	s5, w10
	ubfx	w10, w9, #1, #1
	mov.b	v5[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v5[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v5[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v5[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v5[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v5[6], w10
	lsr	w9, w9, #7
	mov.b	v5[7], w9
	ldr	d0, [sp, #1752]                 ; 8-byte Folded Reload
	and.8b	v6, v0, v1
	eor.8b	v1, v5, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w9, s1
	eor	w9, w9, #0x1
	and	w9, w14, w9
	dup.8b	v1, w9
	and.8b	v1, v1, v5
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w15, s4
	tst	w9, #0x1
	csetm	w9, ne
	dup.8b	v7, w9
	bic.8b	v6, v6, v7
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	str	b6, [x8, #8]
	bic.8b	v5, v5, v7
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x8]
	cmp	x13, #8
	ldr	q16, [sp, #1408]                ; 16-byte Folded Reload
	ldr	q17, [sp, #1392]                ; 16-byte Folded Reload
	ldr	q18, [sp, #1376]                ; 16-byte Folded Reload
	ldr	q20, [sp, #1360]                ; 16-byte Folded Reload
	ldp	q28, q21, [sp, #720]            ; 32-byte Folded Reload
	ldp	q9, q25, [sp, #688]             ; 32-byte Folded Reload
	b.lo	LBB0_590
; %bb.589:                              ; %return.frame.cleanup
                                        ;   in Loop: Header=BB0_2 Depth=1
	tst	w15, #0xff
	b.ne	LBB0_603
LBB0_590:                               ; %ready.overflow.resume596
                                        ;   in Loop: Header=BB0_2 Depth=1
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w9, s3
	ldr	d3, [sp, #72]                   ; 8-byte Folded Reload
	cmeq.8b	v3, v4, v3
	mvn.8b	v3, v3
	umov.b	w10, v3[0]
	sbfx	w11, w10, #0, #1
	fmov	s3, w11
	sbfx	w11, w10, #1, #1
	mov.b	v3[1], w11
	sbfx	w11, w10, #2, #1
	mov.b	v3[2], w11
	sbfx	w11, w10, #3, #1
	mov.b	v3[3], w11
	sbfx	w11, w10, #4, #1
	mov.b	v3[4], w11
	sbfx	w11, w10, #5, #1
	mov.b	v3[5], w11
	sbfx	w11, w10, #6, #1
	mov.b	v3[6], w11
	sbfx	w10, w10, #7, #1
	mov.b	v3[7], w10
	and	w10, w14, #0xfffffffe
	tst	w9, #0xff
	csel	w11, w10, w14, eq
	sxtw	x9, w13
	tst	w15, #0xff
	csel	x9, x9, xzr, ne
	ldrb	w10, [x21, x9]
	and	w14, w10, #0x1
	fmov	s4, w14
	ubfx	w14, w10, #1, #1
	mov.b	v4[1], w14
	ubfx	w14, w10, #2, #1
	mov.b	v4[2], w14
	ubfx	w14, w10, #3, #1
	mov.b	v4[3], w14
	ubfx	w14, w10, #4, #1
	mov.b	v4[4], w14
	ubfx	w14, w10, #5, #1
	mov.b	v4[5], w14
	ubfx	w14, w10, #6, #1
	mov.b	v4[6], w14
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	bif.8b	v1, v4, v3
	fmov	w10, s8
	add	x10, x16, w10, sxtw #2
	fmov	w14, s12
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x21, x9]
	lsl	x9, x9, #2
	add	x15, x27, x9
	csel	x10, x10, x15, ne
	ldr	w10, [x10]
	str	w10, [x15]
	ldr	w10, [x28, x9]
	csel	w10, w14, w10, ne
	str	w10, [x28, x9]
	cinc	w13, w13, ne
	and	w14, w11, #0x2
	ldrb	w9, [x8, #9]
	and	w10, w9, #0x1
	fmov	s1, w10
	ubfx	w10, w9, #1, #1
	mov.b	v1[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v1[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v1[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v1[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v1[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v1[6], w10
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, #1]
	and	w10, w9, #0x1
	fmov	s5, w10
	ubfx	w10, w9, #1, #1
	mov.b	v5[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v5[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v5[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v5[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v5[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v5[6], w10
	lsr	w9, w9, #7
	mov.b	v5[7], w9
	ldr	d0, [sp, #1752]                 ; 8-byte Folded Reload
	and.8b	v6, v0, v1
	eor.8b	v1, v5, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w9, s1
	eor	w9, w9, #0x1
	ands	w9, w9, w14, lsr #1
	dup.8b	v1, w9
	and.8b	v1, v1, v5
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w14, s4
	csetm	w9, ne
	dup.8b	v7, w9
	bic.8b	v6, v6, v7
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #9]
	bic.8b	v5, v5, v7
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	stur	b5, [x8, #1]
	cmp	w13, #8
	and	w9, w14, #0xff
	ccmp	w9, #0, #4, hs
	b.ne	LBB0_603
; %bb.591:                              ; %ready.overflow.resume602
                                        ;   in Loop: Header=BB0_2 Depth=1
	and.8b	v3, v3, v2
	ldr	d5, [sp, #64]                   ; 8-byte Folded Reload
	cmeq.8b	v4, v4, v5
	mvn.8b	v4, v4
	umov.b	w9, v4[0]
	addv.8b	b4, v3
	sbfx	w10, w9, #0, #1
	fmov	s3, w10
	sbfx	w10, w9, #1, #1
	mov.b	v3[1], w10
	sbfx	w10, w9, #2, #1
	mov.b	v3[2], w10
	sbfx	w10, w9, #3, #1
	mov.b	v3[3], w10
	sbfx	w10, w9, #4, #1
	mov.b	v3[4], w10
	sbfx	w10, w9, #5, #1
	mov.b	v3[5], w10
	sbfx	w10, w9, #6, #1
	mov.b	v3[6], w10
	sbfx	w9, w9, #7, #1
	mov.b	v3[7], w9
	fmov	w9, s4
	and	w10, w11, #0xfffffffd
	tst	w9, #0xff
	csel	w11, w10, w11, eq
	sxtw	x9, w13
	tst	w14, #0xff
	csel	x9, x9, xzr, ne
	ldrb	w10, [x21, x9]
	and	w14, w10, #0x1
	fmov	s4, w14
	ubfx	w14, w10, #1, #1
	mov.b	v4[1], w14
	ubfx	w14, w10, #2, #1
	mov.b	v4[2], w14
	ubfx	w14, w10, #3, #1
	mov.b	v4[3], w14
	ubfx	w14, w10, #4, #1
	mov.b	v4[4], w14
	ubfx	w14, w10, #5, #1
	mov.b	v4[5], w14
	ubfx	w14, w10, #6, #1
	mov.b	v4[6], w14
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	bif.8b	v1, v4, v3
	mov.s	w10, v8[1]
	add	x10, x16, w10, sxtw #2
	mov.s	w14, v12[1]
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x21, x9]
	lsl	x9, x9, #2
	add	x15, x27, x9
	csel	x10, x10, x15, ne
	ldr	w10, [x10]
	str	w10, [x15]
	ldr	w10, [x28, x9]
	csel	w10, w14, w10, ne
	str	w10, [x28, x9]
	cinc	w13, w13, ne
	and	w14, w11, #0x4
	ldrb	w9, [x8, #10]
	and	w10, w9, #0x1
	fmov	s1, w10
	ubfx	w10, w9, #1, #1
	mov.b	v1[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v1[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v1[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v1[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v1[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v1[6], w10
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, #2]
	and	w10, w9, #0x1
	fmov	s5, w10
	ubfx	w10, w9, #1, #1
	mov.b	v5[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v5[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v5[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v5[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v5[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v5[6], w10
	lsr	w9, w9, #7
	mov.b	v5[7], w9
	ldr	d0, [sp, #1752]                 ; 8-byte Folded Reload
	and.8b	v6, v0, v1
	eor.8b	v1, v5, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w9, s1
	eor	w9, w9, #0x1
	ands	w9, w9, w14, lsr #2
	dup.8b	v1, w9
	and.8b	v1, v1, v5
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w14, s4
	csetm	w9, ne
	dup.8b	v7, w9
	bic.8b	v6, v6, v7
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #10]
	bic.8b	v5, v5, v7
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	stur	b5, [x8, #2]
	cmp	w13, #8
	and	w9, w14, #0xff
	ccmp	w9, #0, #4, hs
	b.ne	LBB0_603
; %bb.592:                              ; %ready.overflow.resume608
                                        ;   in Loop: Header=BB0_2 Depth=1
	and.8b	v3, v3, v2
	ldr	d5, [sp, #56]                   ; 8-byte Folded Reload
	cmeq.8b	v4, v4, v5
	mvn.8b	v4, v4
	umov.b	w9, v4[0]
	addv.8b	b4, v3
	sbfx	w10, w9, #0, #1
	fmov	s3, w10
	sbfx	w10, w9, #1, #1
	mov.b	v3[1], w10
	sbfx	w10, w9, #2, #1
	mov.b	v3[2], w10
	sbfx	w10, w9, #3, #1
	mov.b	v3[3], w10
	sbfx	w10, w9, #4, #1
	mov.b	v3[4], w10
	sbfx	w10, w9, #5, #1
	mov.b	v3[5], w10
	sbfx	w10, w9, #6, #1
	mov.b	v3[6], w10
	sbfx	w9, w9, #7, #1
	mov.b	v3[7], w9
	fmov	w9, s4
	and	w10, w11, #0xfffffffb
	tst	w9, #0xff
	csel	w11, w10, w11, eq
	sxtw	x9, w13
	tst	w14, #0xff
	csel	x9, x9, xzr, ne
	ldrb	w10, [x21, x9]
	and	w14, w10, #0x1
	fmov	s4, w14
	ubfx	w14, w10, #1, #1
	mov.b	v4[1], w14
	ubfx	w14, w10, #2, #1
	mov.b	v4[2], w14
	ubfx	w14, w10, #3, #1
	mov.b	v4[3], w14
	ubfx	w14, w10, #4, #1
	mov.b	v4[4], w14
	ubfx	w14, w10, #5, #1
	mov.b	v4[5], w14
	ubfx	w14, w10, #6, #1
	mov.b	v4[6], w14
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	bif.8b	v1, v4, v3
	mov.s	w10, v8[2]
	add	x10, x16, w10, sxtw #2
	mov.s	w14, v12[2]
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x21, x9]
	lsl	x9, x9, #2
	add	x15, x27, x9
	csel	x10, x10, x15, ne
	ldr	w10, [x10]
	str	w10, [x15]
	ldr	w10, [x28, x9]
	csel	w10, w14, w10, ne
	str	w10, [x28, x9]
	cinc	w13, w13, ne
	and	w14, w11, #0x8
	ldrb	w9, [x8, #11]
	and	w10, w9, #0x1
	fmov	s1, w10
	ubfx	w10, w9, #1, #1
	mov.b	v1[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v1[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v1[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v1[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v1[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v1[6], w10
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, #3]
	and	w10, w9, #0x1
	fmov	s5, w10
	ubfx	w10, w9, #1, #1
	mov.b	v5[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v5[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v5[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v5[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v5[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v5[6], w10
	lsr	w9, w9, #7
	mov.b	v5[7], w9
	ldr	d0, [sp, #1752]                 ; 8-byte Folded Reload
	and.8b	v6, v0, v1
	eor.8b	v1, v5, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w9, s1
	eor	w9, w9, #0x1
	ands	w9, w9, w14, lsr #3
	dup.8b	v1, w9
	and.8b	v1, v1, v5
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w14, s4
	csetm	w9, ne
	dup.8b	v7, w9
	bic.8b	v6, v6, v7
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #11]
	bic.8b	v5, v5, v7
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	stur	b5, [x8, #3]
	cmp	w13, #8
	and	w9, w14, #0xff
	ccmp	w9, #0, #4, hs
	b.ne	LBB0_603
; %bb.593:                              ; %ready.overflow.resume614
                                        ;   in Loop: Header=BB0_2 Depth=1
	and.8b	v3, v3, v2
	ldr	d5, [sp, #48]                   ; 8-byte Folded Reload
	cmeq.8b	v4, v4, v5
	mvn.8b	v4, v4
	umov.b	w9, v4[0]
	addv.8b	b4, v3
	sbfx	w10, w9, #0, #1
	fmov	s3, w10
	sbfx	w10, w9, #1, #1
	mov.b	v3[1], w10
	sbfx	w10, w9, #2, #1
	mov.b	v3[2], w10
	sbfx	w10, w9, #3, #1
	mov.b	v3[3], w10
	sbfx	w10, w9, #4, #1
	mov.b	v3[4], w10
	sbfx	w10, w9, #5, #1
	mov.b	v3[5], w10
	sbfx	w10, w9, #6, #1
	mov.b	v3[6], w10
	sbfx	w9, w9, #7, #1
	mov.b	v3[7], w9
	fmov	w9, s4
	and	w10, w11, #0xfffffff7
	tst	w9, #0xff
	csel	w11, w10, w11, eq
	sxtw	x9, w13
	tst	w14, #0xff
	csel	x9, x9, xzr, ne
	ldrb	w10, [x21, x9]
	and	w14, w10, #0x1
	fmov	s4, w14
	ubfx	w14, w10, #1, #1
	mov.b	v4[1], w14
	ubfx	w14, w10, #2, #1
	mov.b	v4[2], w14
	ubfx	w14, w10, #3, #1
	mov.b	v4[3], w14
	ubfx	w14, w10, #4, #1
	mov.b	v4[4], w14
	ubfx	w14, w10, #5, #1
	mov.b	v4[5], w14
	ubfx	w14, w10, #6, #1
	mov.b	v4[6], w14
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	bif.8b	v1, v4, v3
	mov.s	w10, v8[3]
	add	x10, x16, w10, sxtw #2
	mov.s	w14, v12[3]
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x21, x9]
	lsl	x9, x9, #2
	add	x15, x27, x9
	csel	x10, x10, x15, ne
	ldr	w10, [x10]
	str	w10, [x15]
	ldr	w10, [x28, x9]
	csel	w10, w14, w10, ne
	str	w10, [x28, x9]
	cinc	w14, w13, ne
	and	w13, w11, #0x10
	ldrb	w9, [x8, #12]
	and	w10, w9, #0x1
	fmov	s1, w10
	ubfx	w10, w9, #1, #1
	mov.b	v1[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v1[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v1[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v1[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v1[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v1[6], w10
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, #4]
	and	w10, w9, #0x1
	fmov	s5, w10
	ubfx	w10, w9, #1, #1
	mov.b	v5[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v5[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v5[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v5[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v5[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v5[6], w10
	lsr	w9, w9, #7
	mov.b	v5[7], w9
	ldr	d0, [sp, #1752]                 ; 8-byte Folded Reload
	and.8b	v6, v0, v1
	eor.8b	v1, v5, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w9, s1
	eor	w9, w9, #0x1
	ands	w9, w9, w13, lsr #4
	dup.8b	v1, w9
	and.8b	v1, v1, v5
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w15, s4
	csetm	w9, ne
	dup.8b	v7, w9
	bic.8b	v6, v6, v7
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #12]
	bic.8b	v5, v5, v7
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	stur	b5, [x8, #4]
	cmp	w14, #8
	and	w9, w15, #0xff
	ccmp	w9, #0, #4, hs
	b.ne	LBB0_603
; %bb.594:                              ; %ready.overflow.resume620
                                        ;   in Loop: Header=BB0_2 Depth=1
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w9, s3
	ldr	d3, [sp, #40]                   ; 8-byte Folded Reload
	cmeq.8b	v3, v4, v3
	mvn.8b	v3, v3
	umov.b	w10, v3[0]
	sbfx	w13, w10, #0, #1
	fmov	s3, w13
	sbfx	w13, w10, #1, #1
	mov.b	v3[1], w13
	sbfx	w13, w10, #2, #1
	mov.b	v3[2], w13
	sbfx	w13, w10, #3, #1
	mov.b	v3[3], w13
	sbfx	w13, w10, #4, #1
	mov.b	v3[4], w13
	sbfx	w13, w10, #5, #1
	mov.b	v3[5], w13
	sbfx	w13, w10, #6, #1
	mov.b	v3[6], w13
	sbfx	w10, w10, #7, #1
	mov.b	v3[7], w10
	and	w10, w11, #0xffffffef
	tst	w9, #0xff
	csel	w13, w10, w11, eq
	sxtw	x9, w14
	tst	w15, #0xff
	csel	x9, x9, xzr, ne
	ldrb	w10, [x21, x9]
	and	w11, w10, #0x1
	fmov	s4, w11
	ubfx	w11, w10, #1, #1
	mov.b	v4[1], w11
	ubfx	w11, w10, #2, #1
	mov.b	v4[2], w11
	ubfx	w11, w10, #3, #1
	mov.b	v4[3], w11
	ubfx	w11, w10, #4, #1
	mov.b	v4[4], w11
	ubfx	w11, w10, #5, #1
	mov.b	v4[5], w11
	ubfx	w11, w10, #6, #1
	mov.b	v4[6], w11
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	bif.8b	v1, v4, v3
	fmov	w10, s13
	add	x10, x16, w10, sxtw #2
	fmov	w11, s19
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x21, x9]
	lsl	x9, x9, #2
	add	x15, x27, x9
	csel	x10, x10, x15, ne
	ldr	w10, [x10]
	str	w10, [x15]
	ldr	w10, [x28, x9]
	csel	w10, w11, w10, ne
	str	w10, [x28, x9]
	cinc	w11, w14, ne
	and	w14, w13, #0x20
	ldrb	w9, [x8, #13]
	and	w10, w9, #0x1
	fmov	s1, w10
	ubfx	w10, w9, #1, #1
	mov.b	v1[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v1[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v1[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v1[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v1[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v1[6], w10
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, #5]
	and	w10, w9, #0x1
	fmov	s5, w10
	ubfx	w10, w9, #1, #1
	mov.b	v5[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v5[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v5[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v5[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v5[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v5[6], w10
	lsr	w9, w9, #7
	mov.b	v5[7], w9
	ldr	d0, [sp, #1752]                 ; 8-byte Folded Reload
	and.8b	v6, v0, v1
	eor.8b	v1, v5, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w9, s1
	eor	w9, w9, #0x1
	ands	w9, w9, w14, lsr #5
	dup.8b	v1, w9
	and.8b	v1, v1, v5
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w14, s4
	csetm	w9, ne
	dup.8b	v7, w9
	bic.8b	v6, v6, v7
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #13]
	bic.8b	v5, v5, v7
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	stur	b5, [x8, #5]
	cmp	w11, #8
	and	w9, w14, #0xff
	ccmp	w9, #0, #4, hs
	b.ne	LBB0_603
; %bb.595:                              ; %ready.overflow.resume626
                                        ;   in Loop: Header=BB0_2 Depth=1
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w9, s3
	ldr	d3, [sp, #32]                   ; 8-byte Folded Reload
	cmeq.8b	v3, v4, v3
	mvn.8b	v3, v3
	umov.b	w10, v3[0]
	sbfx	w15, w10, #0, #1
	fmov	s3, w15
	sbfx	w15, w10, #1, #1
	mov.b	v3[1], w15
	sbfx	w15, w10, #2, #1
	mov.b	v3[2], w15
	sbfx	w15, w10, #3, #1
	mov.b	v3[3], w15
	sbfx	w15, w10, #4, #1
	mov.b	v3[4], w15
	sbfx	w15, w10, #5, #1
	mov.b	v3[5], w15
	sbfx	w15, w10, #6, #1
	mov.b	v3[6], w15
	sbfx	w10, w10, #7, #1
	mov.b	v3[7], w10
	and	w10, w13, #0xffffffdf
	tst	w9, #0xff
	csel	w13, w10, w13, eq
	sxtw	x9, w11
	tst	w14, #0xff
	csel	x9, x9, xzr, ne
	ldrb	w10, [x21, x9]
	and	w14, w10, #0x1
	fmov	s4, w14
	ubfx	w14, w10, #1, #1
	mov.b	v4[1], w14
	ubfx	w14, w10, #2, #1
	mov.b	v4[2], w14
	ubfx	w14, w10, #3, #1
	mov.b	v4[3], w14
	ubfx	w14, w10, #4, #1
	mov.b	v4[4], w14
	ubfx	w14, w10, #5, #1
	mov.b	v4[5], w14
	ubfx	w14, w10, #6, #1
	mov.b	v4[6], w14
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	mov.s	w10, v13[1]
	bif.8b	v1, v4, v3
	add	x10, x16, w10, sxtw #2
	mov.s	w14, v19[1]
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x21, x9]
	lsl	x9, x9, #2
	add	x15, x27, x9
	csel	x10, x10, x15, ne
	ldr	w10, [x10]
	str	w10, [x15]
	ldr	w10, [x28, x9]
	csel	w10, w14, w10, ne
	str	w10, [x28, x9]
	cinc	w11, w11, ne
	ldrb	w9, [x8, #14]
	and	w10, w9, #0x1
	fmov	s1, w10
	ubfx	w10, w9, #1, #1
	mov.b	v1[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v1[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v1[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v1[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v1[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v1[6], w10
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, #6]
	and	w10, w9, #0x1
	fmov	s5, w10
	ubfx	w10, w9, #1, #1
	mov.b	v5[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v5[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v5[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v5[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v5[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v5[6], w10
	and	w10, w13, #0x40
	lsr	w9, w9, #7
	mov.b	v5[7], w9
	ldr	d0, [sp, #1752]                 ; 8-byte Folded Reload
	and.8b	v6, v0, v1
	eor.8b	v1, v5, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w9, s1
	eor	w9, w9, #0x1
	ands	w9, w9, w10, lsr #6
	dup.8b	v1, w9
	and.8b	v1, v1, v5
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w14, s4
	csetm	w9, ne
	dup.8b	v7, w9
	bic.8b	v6, v6, v7
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #14]
	bic.8b	v5, v5, v7
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	stur	b5, [x8, #6]
	cmp	w11, #8
	b.lo	LBB0_597
; %bb.596:                              ; %ready.overflow.resume626
                                        ;   in Loop: Header=BB0_2 Depth=1
	tst	w14, #0xff
	b.ne	LBB0_603
LBB0_597:                               ; %ready.overflow.resume632
                                        ;   in Loop: Header=BB0_2 Depth=1
	and.8b	v3, v3, v2
	ldr	d5, [sp, #24]                   ; 8-byte Folded Reload
	cmeq.8b	v4, v4, v5
	mvn.8b	v4, v4
	umov.b	w9, v4[0]
	addv.8b	b4, v3
	sbfx	w10, w9, #0, #1
	fmov	s3, w10
	sbfx	w10, w9, #1, #1
	mov.b	v3[1], w10
	sbfx	w10, w9, #2, #1
	mov.b	v3[2], w10
	sbfx	w10, w9, #3, #1
	mov.b	v3[3], w10
	sbfx	w10, w9, #4, #1
	mov.b	v3[4], w10
	sbfx	w10, w9, #5, #1
	mov.b	v3[5], w10
	sbfx	w10, w9, #6, #1
	mov.b	v3[6], w10
	sbfx	w9, w9, #7, #1
	mov.b	v3[7], w9
	fmov	w9, s4
	and	w10, w13, #0xffffffbf
	tst	w9, #0xff
	csel	w9, w10, w13, eq
	sxtw	x10, w11
	tst	w14, #0xff
	csel	x10, x10, xzr, ne
	ldrb	w13, [x21, x10]
	and	w14, w13, #0x1
	fmov	s4, w14
	ubfx	w14, w13, #1, #1
	mov.b	v4[1], w14
	ubfx	w14, w13, #2, #1
	mov.b	v4[2], w14
	ubfx	w14, w13, #3, #1
	mov.b	v4[3], w14
	ubfx	w14, w13, #4, #1
	mov.b	v4[4], w14
	ubfx	w14, w13, #5, #1
	mov.b	v4[5], w14
	ubfx	w14, w13, #6, #1
	mov.b	v4[6], w14
	lsr	w13, w13, #7
	mov.b	v4[7], w13
	bif.8b	v1, v4, v3
	mov.s	w13, v13[2]
	add	x14, x16, w13, sxtw #2
	mov.s	w15, v19[2]
	sxtb	w13, w9
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x21, x10]
	lsl	x9, x10, #2
	ldr	w10, [x28, x9]
	csel	w10, w15, w10, ne
	add	x15, x27, x9
	csel	x14, x14, x15, ne
	ldr	w14, [x14]
	str	w10, [x28, x9]
	str	w14, [x15]
	cinc	w11, w11, ne
	cmp	w13, #0
	ldrb	w9, [x8, #15]
	and	w10, w9, #0x1
	fmov	s1, w10
	ubfx	w10, w9, #1, #1
	mov.b	v1[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v1[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v1[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v1[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v1[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v1[6], w10
	lsr	w9, w9, #7
	mov.b	v1[7], w9
	ldrb	w9, [x8, #7]
	and	w10, w9, #0x1
	fmov	s5, w10
	ubfx	w10, w9, #1, #1
	mov.b	v5[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v5[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v5[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v5[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v5[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v5[6], w10
	cset	w10, lt
	lsr	w9, w9, #7
	mov.b	v5[7], w9
	ldr	d0, [sp, #1752]                 ; 8-byte Folded Reload
	and.8b	v6, v0, v1
	eor.8b	v1, v5, v6
	shl.8b	v1, v1, #7
	cmlt.8b	v3, v1, #0
	umaxv.8b	b1, v3
	fmov	w9, s1
	eor	w9, w9, #0x1
	ands	w9, w10, w9
	dup.8b	v1, w9
	and.8b	v1, v1, v5
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w15, s4
	csetm	w9, ne
	dup.8b	v7, w9
	bic.8b	v6, v6, v7
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #15]
	bic.8b	v5, v5, v7
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	stur	b5, [x8, #7]
	cmp	w11, #8
	b.lo	LBB0_599
; %bb.598:                              ; %ready.overflow.resume632
                                        ;   in Loop: Header=BB0_2 Depth=1
	tst	w15, #0xff
	b.ne	LBB0_603
LBB0_599:                               ; %ready.overflow.resume638
                                        ;   in Loop: Header=BB0_2 Depth=1
	and.8b	v3, v3, v2
	addv.8b	b5, v3
	ldr	d3, [sp, #16]                   ; 8-byte Folded Reload
	cmeq.8b	v3, v4, v3
	mvn.8b	v3, v3
	umov.b	w9, v3[0]
	sbfx	w10, w9, #0, #1
	fmov	s3, w10
	sbfx	w10, w9, #1, #1
	mov.b	v3[1], w10
	sbfx	w10, w9, #2, #1
	mov.b	v3[2], w10
	sbfx	w10, w9, #3, #1
	mov.b	v3[3], w10
	sbfx	w10, w9, #4, #1
	mov.b	v3[4], w10
	sbfx	w10, w9, #5, #1
	mov.b	v3[5], w10
	sbfx	w10, w9, #6, #1
	mov.b	v3[6], w10
	fmov	w10, s5
	sbfx	w9, w9, #7, #1
	mov.b	v3[7], w9
	and	w9, w13, #0x7f
	tst	w10, #0xff
	csel	w14, w9, w13, eq
	sxtw	x9, w11
	tst	w15, #0xff
	csel	x9, x9, xzr, ne
	ldrb	w10, [x21, x9]
	and	w13, w10, #0x1
	fmov	s4, w13
	ubfx	w13, w10, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w10, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w10, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w10, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w10, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w10, #6, #1
	mov.b	v4[6], w13
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	bif.8b	v1, v4, v3
	mov.s	w10, v13[3]
	mov.s	w13, v19[3]
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	b1, [x21, x9]
	add	x10, x16, w10, sxtw #2
	lsl	x9, x9, #2
	add	x15, x27, x9
	csel	x10, x10, x15, ne
	ldr	w10, [x10]
	str	w10, [x15]
	ldr	w10, [x28, x9]
	csel	w10, w13, w10, ne
	str	w10, [x28, x9]
	cinc	w13, w11, ne
	cbnz	w13, LBB0_2
	b	LBB0_601
LBB0_600:                               ;   in Loop: Header=BB0_2 Depth=1
	mov	w14, #0                         ; =0x0
	ldr	q16, [sp, #1408]                ; 16-byte Folded Reload
	ldr	q17, [sp, #1392]                ; 16-byte Folded Reload
	ldr	q18, [sp, #1376]                ; 16-byte Folded Reload
	ldr	q20, [sp, #1360]                ; 16-byte Folded Reload
	ldp	q28, q21, [sp, #720]            ; 32-byte Folded Reload
	ldp	q9, q25, [sp, #688]             ; 32-byte Folded Reload
	cbnz	w13, LBB0_2
LBB0_601:                               ; %scheduler.done
	ldr	d0, [sp, #1752]                 ; 8-byte Folded Reload
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	umaxv.8b	b0, v0
	fmov	w8, s0
	tbnz	w8, #0, LBB0_603
; %bb.602:                              ; %scheduler.exit
	add	sp, sp, #3, lsl #12             ; =12288
	add	sp, sp, #944
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
LBB0_603:                               ; %scheduler.stalled
	brk	#0x1
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdd	Lloh18, Lloh19
	.section	__TEXT,__const
	.p2align	1, 0x0
LJTI0_0:
	.short	(LBB0_13-LBB0_13)>>2
	.short	(LBB0_75-LBB0_13)>>2
	.short	(LBB0_41-LBB0_13)>>2
	.short	(LBB0_26-LBB0_13)>>2
	.short	(LBB0_36-LBB0_13)>>2
	.short	(LBB0_121-LBB0_13)>>2
	.short	(LBB0_137-LBB0_13)>>2
	.short	(LBB0_42-LBB0_13)>>2
	.short	(LBB0_211-LBB0_13)>>2
	.short	(LBB0_219-LBB0_13)>>2
	.short	(LBB0_24-LBB0_13)>>2
	.short	(LBB0_293-LBB0_13)>>2
	.short	(LBB0_301-LBB0_13)>>2
	.short	(LBB0_14-LBB0_13)>>2
	.short	(LBB0_375-LBB0_13)>>2
	.short	(LBB0_383-LBB0_13)>>2
	.short	(LBB0_25-LBB0_13)>>2
	.short	(LBB0_457-LBB0_13)>>2
	.short	(LBB0_15-LBB0_13)>>2
	.short	(LBB0_504-LBB0_13)>>2
	.short	(LBB0_43-LBB0_13)>>2
	.short	(LBB0_527-LBB0_13)>>2
	.short	(LBB0_557-LBB0_13)>>2
	.short	(LBB0_582-LBB0_13)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_tile_row_reduce.packet_batch   ; -- Begin function tile_row_reduce.packet_batch
	.p2align	2
_tile_row_reduce.packet_batch:          ; @tile_row_reduce.packet_batch
; %bb.0:                                ; %packet.batch.prologue
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	mov	x21, x3
	mov	x19, x2
	mov	x20, x0
	ldr	w23, [x2, #36]
	ldr	w8, [x2]
	ldr	w9, [x2, #12]
	lsl	x8, x8, #5
	cmp	x8, x9
	csel	x10, x8, xzr, ls
	add	x10, x10, x23
	subs	x11, x9, x10
	mov	w12, #32                        ; =0x20
	sub	x13, x12, x23
	cmp	x11, x13
	csel	x11, x11, x13, lo
	cmp	x9, x10
	ccmp	x23, x12, #2, hi
	ccmp	x8, x9, #2, lo
	csel	x8, x11, xzr, ls
	cmp	w3, #4
	b.ne	LBB1_3
; %bb.1:                                ; %packet.batch.prologue
	cmp	x8, #32
	b.lo	LBB1_3
; %bb.2:                                ; %packet.batch.full
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_row_reduce
	add	w8, w23, #8
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_row_reduce
	add	w8, w23, #16
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_row_reduce
	add	w8, w23, #24
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	b	_tile_row_reduce
LBB1_3:                                 ; %packet.batch.partial
	ubfiz	x9, x21, #3, #32
	cmp	x8, x9
	csel	x8, x8, x9, lo
	lsr	x24, x8, #3
	and	w22, w8, #0x7
	cmp	x8, #8
	b.lo	LBB1_6
; %bb.4:                                ; %packet.batch.partial.full.loop.preheader
	mov	x25, x24
	mov	x26, x23
LBB1_5:                                 ; %packet.batch.partial.full.loop
                                        ; =>This Inner Loop Header: Depth=1
	str	w26, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_row_reduce
	add	w26, w26, #8
	subs	w25, w25, #1
	b.ne	LBB1_5
LBB1_6:                                 ; %packet.batch.tail.check
	cbz	w22, LBB1_8
; %bb.7:                                ; %packet.batch.tail.call
	add	w8, w23, w24, lsl #3
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	x2, x22
	bl	_tile_row_reduce
LBB1_8:                                 ; %packet.batch.partial.finish
	lsl	w8, w21, #3
	sub	w8, w8, #8
	cmp	w21, #0
	csel	w8, wzr, w8, eq
	add	w8, w23, w8
	str	w8, [x19, #36]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.section	__TEXT,__const
	.p2align	2, 0x0                          ; @convergence.targets
l_convergence.targets:
	.long	5                               ; 0x5
	.long	4                               ; 0x4
	.long	8                               ; 0x8
	.long	11                              ; 0xb
	.long	14                              ; 0xe
	.long	17                              ; 0x11
	.long	19                              ; 0x13
	.long	21                              ; 0x15
	.long	23                              ; 0x17

.subsections_via_symbols

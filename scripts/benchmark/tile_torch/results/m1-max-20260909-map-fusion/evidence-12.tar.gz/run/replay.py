import json
from pathlib import Path
import subprocess

root = Path(__file__).parent
driver = Path('/Users/mike/CLionProjects/luisa/scripts/benchmark/tile_torch/native_tile.py')
captures = json.loads((root / 'capture-manifest.json').read_text())
records = []
for case in captures['cases']:
    name = case['name']
    prefix = root / 'captures' / name
    output = root / 'prepared' / name
    command = ['python3', str(driver), 'prepare', '--prefix', str(prefix), '--log', str(prefix) + '.log',
               '--objects', str(prefix) + '-objects', '--output', str(output), '--name', name.rsplit('-', 1)[1]]
    with open(root / (name + '-prepare.log'), 'x') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=120)
    records.append({'name': name, 'command': command, 'exit_code': result.returncode})
    print(name, 'prepare', result.returncode, flush=True)
with open(root / 'prepare-runs.json', 'x') as f:
    json.dump(records, f, indent=2)
if any(x['exit_code'] for x in records):
    raise SystemExit('preparation failed; retained all outcomes')
for case in captures['cases'][::2]:
    name = case['name'].rsplit('-', 1)[0]
    command = ['python3', str(driver), 'replay', '--prepared', str(root / 'prepared' / (name + '-off') / 'prepared.json'),
               '--prepared', str(root / 'prepared' / (name + '-on') / 'prepared.json'),
               '--output', str(root / 'replay' / name), '--cycles', '2', '--samples', '7', '--warmup-ms', '100', '--target-ms', '30']
    with open(root / (name + '-replay.log'), 'x') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=180)
    print(name, 'replay', result.returncode, flush=True)

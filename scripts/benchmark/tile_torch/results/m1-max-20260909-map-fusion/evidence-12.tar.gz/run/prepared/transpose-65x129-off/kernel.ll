; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

@convergence.targets = private unnamed_addr constant [5 x i32] [i32 5, i32 4, i32 8, i32 13, i32 12], align 4

define internal void @tile_transpose(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %live.mask = alloca <8 x i1>, align 1
  %runnable.mask = alloca <8 x i1>, align 1
  %ready.count = alloca i32, align 4
  %ready.mask = alloca [8 x <8 x i1>], align 1
  %ready.target = alloca [8 x i32], align 4
  %ready.token = alloca [8 x i32], align 4
  %current.mask = alloca <8 x i1>, align 1
  %current.token = alloca i32, align 4
  %frame.active = alloca i8, align 1
  %frame.static.id = alloca <8 x i32>, align 32
  %frame.parent.token = alloca <8 x i32>, align 32
  %frame.expected = alloca [8 x <8 x i1>], align 1
  %frame.arrived = alloca [8 x <8 x i1>], align 1
  store <8 x i1> zeroinitializer, ptr %live.mask, align 1
  store <8 x i1> zeroinitializer, ptr %runnable.mask, align 1
  store i32 0, ptr %ready.count, align 4
  store [8 x <8 x i1>] zeroinitializer, ptr %ready.mask, align 1
  store [8 x i32] zeroinitializer, ptr %ready.target, align 4
  store [8 x i32] zeroinitializer, ptr %ready.token, align 4
  store <8 x i1> zeroinitializer, ptr %current.mask, align 1
  store i32 0, ptr %current.token, align 4
  store i8 0, ptr %frame.active, align 1
  store <8 x i32> zeroinitializer, ptr %frame.static.id, align 32
  store <8 x i32> zeroinitializer, ptr %frame.parent.token, align 32
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.expected, align 1
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.arrived, align 1
  %tile_snapshot.local = alloca [8192 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [8192 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot, align 64
  %.spill5 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill5, align 64
  %.slot6 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot6, align 32
  %tile_snapshot.spill7 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill7, align 64
  %.slot8 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot8, align 64
  %.slot9 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot9, align 64
  %.spill10 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill10, align 64
  %.spill11 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill11, align 32
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = load i32, ptr %launch_config, align 4
  %17 = getelementptr i8, ptr %launch_config, i64 12
  %18 = load i32, ptr %17, align 4
  %19 = getelementptr i8, ptr %launch_config, i64 4
  %20 = load i32, ptr %19, align 4
  %21 = getelementptr i8, ptr %launch_config, i64 16
  %22 = load i32, ptr %21, align 4
  %23 = getelementptr i8, ptr %launch_config, i64 8
  %24 = load i32, ptr %23, align 4
  %25 = getelementptr i8, ptr %launch_config, i64 20
  %26 = load i32, ptr %25, align 4
  %27 = getelementptr i8, ptr %launch_config, i64 36
  %28 = load i32, ptr %27, align 4
  %.splatinsert12 = insertelement <8 x i32> poison, i32 %28, i64 0
  %.splat13 = shufflevector <8 x i32> %.splatinsert12, <8 x i32> poison, <8 x i32> zeroinitializer
  %29 = add <8 x i32> %.splat13, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %30 = mul i32 %16, 64
  %.splatinsert14 = insertelement <8 x i32> poison, i32 %30, i64 0
  %.splat15 = shufflevector <8 x i32> %.splatinsert14, <8 x i32> poison, <8 x i32> zeroinitializer
  %31 = add <8 x i32> %.splat15, %29
  %32 = mul i32 %20, 1
  %.splatinsert16 = insertelement <8 x i32> poison, i32 %32, i64 0
  %.splat17 = shufflevector <8 x i32> %.splatinsert16, <8 x i32> poison, <8 x i32> zeroinitializer
  %33 = add <8 x i32> %.splat17, zeroinitializer
  %34 = mul i32 %24, 1
  %.splatinsert18 = insertelement <8 x i32> poison, i32 %34, i64 0
  %.splat19 = shufflevector <8 x i32> %.splatinsert18, <8 x i32> poison, <8 x i32> zeroinitializer
  %35 = add <8 x i32> %.splat19, zeroinitializer
  %36 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %31, 0
  %37 = insertvalue [3 x <8 x i32>] %36, <8 x i32> %33, 1
  %38 = insertvalue [3 x <8 x i32>] %37, <8 x i32> %35, 2
  %.splatinsert20 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat21 = shufflevector <8 x i32> %.splatinsert20, <8 x i32> poison, <8 x i32> zeroinitializer
  %39 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat21
  store <8 x i1> %39, ptr %live.mask, align 1
  %40 = load i32, ptr %current.token, align 4
  %41 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %39)
  %42 = load i32, ptr %ready.count, align 4
  %43 = icmp uge i32 %42, 8
  %44 = and i1 %41, %43
  br i1 %44, label %ready.overflow.trap, label %ready.overflow.resume

ready.overflow.trap:                              ; preds = %prologue
  call void @llvm.trap()
  unreachable

ready.overflow.resume:                            ; preds = %prologue
  %45 = select i1 %41, i32 %42, i32 0
  %46 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %45
  %47 = load <8 x i1>, ptr %46, align 1
  %48 = select i1 %41, <8 x i1> %39, <8 x i1> %47
  store <8 x i1> %48, ptr %46, align 1
  %49 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %45
  %50 = load i32, ptr %49, align 4
  %51 = select i1 %41, i32 0, i32 %50
  store i32 %51, ptr %49, align 4
  %52 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %45
  %53 = load i32, ptr %52, align 4
  %54 = select i1 %41, i32 %40, i32 %53
  store i32 %54, ptr %52, align 4
  %55 = add i32 %42, 1
  %56 = select i1 %41, i32 %55, i32 %42
  store i32 %56, ptr %ready.count, align 4
  %57 = load <8 x i1>, ptr %runnable.mask, align 1
  %58 = or <8 x i1> %57, %39
  store <8 x i1> %58, ptr %runnable.mask, align 1
  br label %scheduler.loop

scheduler.loop:                                   ; preds = %return.frame.cleanup.done, %convergence.cascade.exit148, %convergence.target.12.ready, %convergence.cascade.exit130, %schedule.11, %varying.coherent.false126, %varying.coherent.true125, %ready.overflow.resume124, %varying.coherent.false110, %varying.coherent.true109, %ready.overflow.resume108, %convergence.target.8.ready, %convergence.cascade.exit84, %schedule.7, %varying.coherent.false76, %varying.coherent.true75, %ready.overflow.resume74, %convergence.target.5.ready, %convergence.cascade.exit50, %convergence.target.4.ready, %convergence.cascade.exit, %schedule.3, %varying.coherent.false38, %varying.coherent.true37, %ready.overflow.resume36, %varying.coherent.false, %varying.coherent.true, %ready.overflow.resume25, %schedule.0, %ready.overflow.resume
  %59 = load i32, ptr %ready.count, align 4
  %60 = icmp ne i32 %59, 0
  br i1 %60, label %scheduler.dispatch, label %scheduler.done

scheduler.dispatch:                               ; preds = %scheduler.loop
  %61 = sub i32 %59, 1
  store i32 %61, ptr %ready.count, align 4
  %62 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %61
  %63 = load <8 x i1>, ptr %62, align 1
  store <8 x i1> %63, ptr %current.mask, align 1
  %64 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %61
  %65 = load i32, ptr %64, align 4
  %66 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %61
  %67 = load i32, ptr %66, align 4
  store i32 %67, ptr %current.token, align 4
  %68 = load <8 x i1>, ptr %runnable.mask, align 1
  %69 = xor <8 x i1> %63, splat (i1 true)
  %70 = and <8 x i1> %68, %69
  store <8 x i1> %70, ptr %runnable.mask, align 1
  br label %scheduler.dispatch.route

scheduler.dispatch.route:                         ; preds = %scheduler.dispatch
  %scheduler.dispatch.pc = phi i32 [ %65, %scheduler.dispatch ]
  switch i32 %scheduler.dispatch.pc, label %scheduler.invalid [
    i32 0, label %schedule.0
    i32 1, label %schedule.1
    i32 2, label %schedule.2
    i32 3, label %schedule.3
    i32 4, label %schedule.4
    i32 5, label %schedule.5
    i32 6, label %schedule.6
    i32 7, label %schedule.7
    i32 8, label %schedule.8
    i32 9, label %schedule.9
    i32 10, label %schedule.10
    i32 11, label %schedule.11
    i32 12, label %schedule.12
    i32 13, label %schedule.13
  ]

scheduler.done:                                   ; preds = %scheduler.loop
  %71 = load <8 x i1>, ptr %live.mask, align 1
  %72 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  br i1 %72, label %scheduler.stalled, label %scheduler.exit

scheduler.exit:                                   ; preds = %scheduler.done
  ret void

scheduler.stalled:                                ; preds = %scheduler.done
  call void @llvm.trap()
  unreachable

scheduler.invalid:                                ; preds = %scheduler.dispatch.route
  call void @llvm.trap()
  unreachable

schedule.0:                                       ; preds = %scheduler.dispatch.route
  %73 = load <8 x i1>, ptr %current.mask, align 1
  %74 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %73)
  %75 = bitcast <8 x i1> %73 to i8
  %76 = call i8 @llvm.cttz.i8(i8 %75, i1 false)
  %77 = zext i8 %76 to i32
  %78 = select i1 %74, i32 %77, i32 0
  %79 = extractvalue [3 x <8 x i32>] %38, 0
  %80 = zext <8 x i32> %79 to <8 x i64>
  %81 = select <8 x i1> %73, <8 x i64> %80, <8 x i64> zeroinitializer
  %82 = select <8 x i1> %73, <8 x i64> splat (i64 9), <8 x i64> splat (i64 1)
  %83 = sdiv <8 x i64> %81, %82
  %84 = select <8 x i1> %73, <8 x i64> %80, <8 x i64> zeroinitializer
  %85 = select <8 x i1> %73, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %86 = sdiv <8 x i64> %84, %85
  %87 = select <8 x i1> %73, <8 x i64> %86, <8 x i64> zeroinitializer
  %88 = select <8 x i1> %73, <8 x i64> splat (i64 9), <8 x i64> splat (i64 1)
  %89 = srem <8 x i64> %87, %88
  %90 = mul <8 x i64> %83, splat (i64 16)
  %91 = load volatile <8 x i64>, ptr %.spill, align 64
  %92 = select <8 x i1> %73, <8 x i64> %90, <8 x i64> %91
  store volatile <8 x i64> %92, ptr %.spill, align 64
  %93 = mul <8 x i64> %89, splat (i64 16)
  %94 = load volatile <8 x i64>, ptr %.spill4, align 64
  %95 = select <8 x i1> %73, <8 x i64> %93, <8 x i64> %94
  store volatile <8 x i64> %95, ptr %.spill4, align 64
  %96 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %97 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %96, 0
  %99 = select <8 x i1> %73, <8 x ptr> %97, <8 x ptr> %98
  %100 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %101 = extractvalue { <8 x ptr>, <8 x i64> } %96, 1
  %102 = select <8 x i1> %73, <8 x i64> %100, <8 x i64> %101
  %103 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %99, 0
  %104 = insertvalue { <8 x ptr>, <8 x i64> } %103, <8 x i64> %102, 1
  store volatile { <8 x ptr>, <8 x i64> } %104, ptr %tile_snapshot.spill, align 64
  %105 = load <8 x i64>, ptr %.slot, align 64
  %106 = select <8 x i1> %73, <8 x i64> zeroinitializer, <8 x i64> %105
  store <8 x i64> %106, ptr %.slot, align 64
  store <8 x i1> %73, ptr %current.mask, align 1
  %107 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %73)
  br i1 %107, label %schedule.1, label %scheduler.loop

schedule.1:                                       ; preds = %convergence.target.4.ready, %schedule.0, %scheduler.dispatch.route
  %108 = load <8 x i1>, ptr %current.mask, align 1
  %109 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %108)
  %110 = bitcast <8 x i1> %108 to i8
  %111 = call i8 @llvm.cttz.i8(i8 %110, i1 false)
  %112 = zext i8 %111 to i32
  %113 = select i1 %109, i32 %112, i32 0
  %.state = load <8 x i64>, ptr %.slot, align 64
  %114 = icmp slt <8 x i64> %.state, splat (i64 256)
  %115 = and <8 x i1> %108, %114
  %116 = xor <8 x i1> %114, splat (i1 true)
  %117 = and <8 x i1> %108, %116
  %118 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %115)
  %119 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %117)
  %120 = and i1 %118, %119
  br i1 %120, label %varying.divergent, label %varying.coherent

schedule.2:                                       ; preds = %varying.coherent.true, %scheduler.dispatch.route
  %121 = load <8 x i1>, ptr %current.mask, align 1
  %122 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %121)
  %123 = bitcast <8 x i1> %121 to i8
  %124 = call i8 @llvm.cttz.i8(i8 %123, i1 false)
  %125 = zext i8 %124 to i32
  %126 = select i1 %122, i32 %125, i32 0
  %.state26 = load <8 x i64>, ptr %.slot, align 64
  %127 = select <8 x i1> %121, <8 x i64> %.state26, <8 x i64> zeroinitializer
  %128 = select <8 x i1> %121, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %129 = srem <8 x i64> %127, %128
  %.state27 = load <8 x i64>, ptr %.slot, align 64
  %130 = select <8 x i1> %121, <8 x i64> %.state27, <8 x i64> zeroinitializer
  %131 = select <8 x i1> %121, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %132 = sdiv <8 x i64> %130, %131
  %.spill.load = load volatile <8 x i64>, ptr %.spill, align 64
  %133 = add <8 x i64> %.spill.load, %132
  %134 = add <8 x i64> zeroinitializer, %133
  %135 = icmp sge <8 x i64> %133, zeroinitializer
  %136 = and <8 x i1> splat (i1 true), %135
  %137 = icmp slt <8 x i64> %133, splat (i64 65)
  %138 = and <8 x i1> %136, %137
  %.spill.load28 = load volatile <8 x i64>, ptr %.spill4, align 64
  %139 = add <8 x i64> %.spill.load28, %129
  %140 = mul <8 x i64> %134, splat (i64 129)
  %141 = add <8 x i64> %140, %139
  %142 = icmp sge <8 x i64> %139, zeroinitializer
  %143 = and <8 x i1> %138, %142
  %144 = icmp slt <8 x i64> %139, splat (i64 129)
  %145 = and <8 x i1> %143, %144
  %146 = load volatile <8 x i64>, ptr %.spill5, align 64
  %147 = select <8 x i1> %121, <8 x i64> %141, <8 x i64> %146
  store volatile <8 x i64> %147, ptr %.spill5, align 64
  %148 = and <8 x i1> %121, %145
  %149 = xor <8 x i1> %145, splat (i1 true)
  %150 = and <8 x i1> %121, %149
  %151 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %148)
  %152 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %150)
  %153 = and i1 %151, %152
  br i1 %153, label %varying.divergent29, label %varying.coherent30

schedule.3:                                       ; preds = %varying.coherent.true37, %scheduler.dispatch.route
  %154 = load <8 x i1>, ptr %current.mask, align 1
  %155 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %154)
  %156 = bitcast <8 x i1> %154 to i8
  %157 = call i8 @llvm.cttz.i8(i8 %156, i1 false)
  %158 = zext i8 %157 to i32
  %159 = select i1 %155, i32 %158, i32 0
  %.spill.load39 = load volatile <8 x i64>, ptr %.spill5, align 64
  %160 = extractvalue { ptr, i64 } %9, 0
  %161 = mul <8 x i64> %.spill.load39, splat (i64 4)
  %162 = getelementptr i8, ptr %160, <8 x i64> %161
  %163 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %162, i32 1, <8 x i1> %154, <8 x float> zeroinitializer)
  %164 = load <8 x float>, ptr %.slot6, align 32
  %165 = select <8 x i1> %154, <8 x float> %163, <8 x float> %164
  store <8 x float> %165, ptr %.slot6, align 32
  store <8 x i1> %154, ptr %current.mask, align 1
  %166 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %154)
  br i1 %166, label %schedule.4, label %scheduler.loop

schedule.4:                                       ; preds = %schedule.3, %varying.coherent.false38, %scheduler.dispatch.route
  %167 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token = load i32, ptr %current.token, align 4
  %convergence.token.present = icmp ne i32 %convergence.current.token, 0
  br i1 %convergence.token.present, label %convergence.cascade, label %convergence.cascade.exit

schedule.5:                                       ; preds = %varying.coherent.false, %scheduler.dispatch.route
  %168 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token51 = load i32, ptr %current.token, align 4
  %convergence.token.present52 = icmp ne i32 %convergence.current.token51, 0
  br i1 %convergence.token.present52, label %convergence.cascade49, label %convergence.cascade.exit50

schedule.6:                                       ; preds = %schedule.7, %convergence.target.5.ready, %scheduler.dispatch.route
  %169 = load <8 x i1>, ptr %current.mask, align 1
  %170 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %169)
  %171 = bitcast <8 x i1> %169 to i8
  %172 = call i8 @llvm.cttz.i8(i8 %171, i1 false)
  %173 = zext i8 %172 to i32
  %174 = select i1 %170, i32 %173, i32 0
  %.state66 = load <8 x i64>, ptr %.slot8, align 64
  %175 = icmp slt <8 x i64> %.state66, splat (i64 256)
  %176 = and <8 x i1> %169, %175
  %177 = xor <8 x i1> %175, splat (i1 true)
  %178 = and <8 x i1> %169, %177
  %179 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %176)
  %180 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %178)
  %181 = and i1 %179, %180
  br i1 %181, label %varying.divergent67, label %varying.coherent68

schedule.7:                                       ; preds = %varying.coherent.true75, %scheduler.dispatch.route
  %182 = load <8 x i1>, ptr %current.mask, align 1
  %183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %182)
  %184 = bitcast <8 x i1> %182 to i8
  %185 = call i8 @llvm.cttz.i8(i8 %184, i1 false)
  %186 = zext i8 %185 to i32
  %187 = select i1 %183, i32 %186, i32 0
  %.state77 = load <8 x i64>, ptr %.slot8, align 64
  %188 = select <8 x i1> %182, <8 x i64> %.state77, <8 x i64> zeroinitializer
  %189 = select <8 x i1> %182, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %190 = srem <8 x i64> %188, %189
  %.state78 = load <8 x i64>, ptr %.slot8, align 64
  %191 = select <8 x i1> %182, <8 x i64> %.state78, <8 x i64> zeroinitializer
  %192 = select <8 x i1> %182, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %193 = sdiv <8 x i64> %191, %192
  %194 = add <8 x i64> zeroinitializer, %190
  %195 = mul <8 x i64> %194, splat (i64 16)
  %196 = add <8 x i64> %195, %193
  %tile_snapshot.spill.load79 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %197 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load79, 0
  %198 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load79, 1
  %199 = mul <8 x i64> %196, splat (i64 32)
  %200 = add <8 x i64> %198, %199
  %201 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %197, 0
  %202 = insertvalue { <8 x ptr>, <8 x i64> } %201, <8 x i64> %200, 1
  %203 = extractvalue { <8 x ptr>, <8 x i64> } %202, 0
  %204 = extractvalue { <8 x ptr>, <8 x i64> } %202, 1
  %205 = getelementptr i8, <8 x ptr> %203, <8 x i64> %204
  %206 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %205, i32 1, <8 x i1> %182, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load80 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill7, align 64
  %207 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load80, 0
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load80, 1
  %.state81 = load <8 x i64>, ptr %.slot8, align 64
  %209 = mul <8 x i64> %.state81, splat (i64 32)
  %210 = add <8 x i64> %208, %209
  %211 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %207, 0
  %212 = insertvalue { <8 x ptr>, <8 x i64> } %211, <8 x i64> %210, 1
  %213 = extractvalue { <8 x ptr>, <8 x i64> } %212, 0
  %214 = extractvalue { <8 x ptr>, <8 x i64> } %212, 1
  %215 = getelementptr i8, <8 x ptr> %213, <8 x i64> %214
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %206, <8 x ptr> %215, i32 1, <8 x i1> %182)
  %.state82 = load <8 x i64>, ptr %.slot8, align 64
  %216 = add <8 x i64> %.state82, splat (i64 1)
  %217 = load <8 x i64>, ptr %.slot8, align 64
  %218 = select <8 x i1> %182, <8 x i64> %216, <8 x i64> %217
  store <8 x i64> %218, ptr %.slot8, align 64
  store <8 x i1> %182, ptr %current.mask, align 1
  %219 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %182)
  br i1 %219, label %schedule.6, label %scheduler.loop

schedule.8:                                       ; preds = %varying.coherent.false76, %scheduler.dispatch.route
  %220 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token85 = load i32, ptr %current.token, align 4
  %convergence.token.present86 = icmp ne i32 %convergence.current.token85, 0
  br i1 %convergence.token.present86, label %convergence.cascade83, label %convergence.cascade.exit84

schedule.9:                                       ; preds = %convergence.target.12.ready, %convergence.target.8.ready, %scheduler.dispatch.route
  %221 = load <8 x i1>, ptr %current.mask, align 1
  %222 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %221)
  %223 = bitcast <8 x i1> %221 to i8
  %224 = call i8 @llvm.cttz.i8(i8 %223, i1 false)
  %225 = zext i8 %224 to i32
  %226 = select i1 %222, i32 %225, i32 0
  %.state100 = load <8 x i64>, ptr %.slot9, align 64
  %227 = icmp slt <8 x i64> %.state100, splat (i64 256)
  %228 = and <8 x i1> %221, %227
  %229 = xor <8 x i1> %227, splat (i1 true)
  %230 = and <8 x i1> %221, %229
  %231 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %228)
  %232 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %230)
  %233 = and i1 %231, %232
  br i1 %233, label %varying.divergent101, label %varying.coherent102

schedule.10:                                      ; preds = %varying.coherent.true109, %scheduler.dispatch.route
  %234 = load <8 x i1>, ptr %current.mask, align 1
  %235 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %234)
  %236 = bitcast <8 x i1> %234 to i8
  %237 = call i8 @llvm.cttz.i8(i8 %236, i1 false)
  %238 = zext i8 %237 to i32
  %239 = select i1 %235, i32 %238, i32 0
  %.state111 = load <8 x i64>, ptr %.slot9, align 64
  %240 = select <8 x i1> %234, <8 x i64> %.state111, <8 x i64> zeroinitializer
  %241 = select <8 x i1> %234, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %242 = srem <8 x i64> %240, %241
  %.state112 = load <8 x i64>, ptr %.slot9, align 64
  %243 = select <8 x i1> %234, <8 x i64> %.state112, <8 x i64> zeroinitializer
  %244 = select <8 x i1> %234, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %245 = sdiv <8 x i64> %243, %244
  %.spill.load113 = load volatile <8 x i64>, ptr %.spill4, align 64
  %246 = add <8 x i64> %.spill.load113, %245
  %247 = add <8 x i64> zeroinitializer, %246
  %248 = icmp sge <8 x i64> %246, zeroinitializer
  %249 = and <8 x i1> splat (i1 true), %248
  %250 = icmp slt <8 x i64> %246, splat (i64 129)
  %251 = and <8 x i1> %249, %250
  %.spill.load114 = load volatile <8 x i64>, ptr %.spill, align 64
  %252 = add <8 x i64> %.spill.load114, %242
  %253 = mul <8 x i64> %247, splat (i64 65)
  %254 = add <8 x i64> %253, %252
  %255 = icmp sge <8 x i64> %252, zeroinitializer
  %256 = and <8 x i1> %251, %255
  %257 = icmp slt <8 x i64> %252, splat (i64 65)
  %258 = and <8 x i1> %256, %257
  %259 = load volatile <8 x i64>, ptr %.spill10, align 64
  %260 = select <8 x i1> %234, <8 x i64> %254, <8 x i64> %259
  store volatile <8 x i64> %260, ptr %.spill10, align 64
  %tile_snapshot.spill.load115 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill7, align 64
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load115, 0
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load115, 1
  %.state116 = load <8 x i64>, ptr %.slot9, align 64
  %263 = mul <8 x i64> %.state116, splat (i64 32)
  %264 = add <8 x i64> %262, %263
  %265 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %261, 0
  %266 = insertvalue { <8 x ptr>, <8 x i64> } %265, <8 x i64> %264, 1
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %266, 0
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %266, 1
  %269 = getelementptr i8, <8 x ptr> %267, <8 x i64> %268
  %270 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %269, i32 1, <8 x i1> %234, <8 x float> zeroinitializer)
  %271 = load volatile <8 x float>, ptr %.spill11, align 32
  %272 = select <8 x i1> %234, <8 x float> %270, <8 x float> %271
  store volatile <8 x float> %272, ptr %.spill11, align 32
  %273 = and <8 x i1> %234, %258
  %274 = xor <8 x i1> %258, splat (i1 true)
  %275 = and <8 x i1> %234, %274
  %276 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %273)
  %277 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %275)
  %278 = and i1 %276, %277
  br i1 %278, label %varying.divergent117, label %varying.coherent118

schedule.11:                                      ; preds = %varying.coherent.true125, %scheduler.dispatch.route
  %279 = load <8 x i1>, ptr %current.mask, align 1
  %280 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %279)
  %281 = bitcast <8 x i1> %279 to i8
  %282 = call i8 @llvm.cttz.i8(i8 %281, i1 false)
  %283 = zext i8 %282 to i32
  %284 = select i1 %280, i32 %283, i32 0
  %.spill.load127 = load volatile <8 x i64>, ptr %.spill10, align 64
  %.spill.load128 = load volatile <8 x float>, ptr %.spill11, align 32
  %285 = extractvalue { ptr, i64 } %15, 0
  %286 = mul <8 x i64> %.spill.load127, splat (i64 4)
  %287 = getelementptr i8, ptr %285, <8 x i64> %286
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.spill.load128, <8 x ptr> %287, i32 1, <8 x i1> %279)
  store <8 x i1> %279, ptr %current.mask, align 1
  %288 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %279)
  br i1 %288, label %schedule.12, label %scheduler.loop

schedule.12:                                      ; preds = %schedule.11, %varying.coherent.false126, %scheduler.dispatch.route
  %289 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token131 = load i32, ptr %current.token, align 4
  %convergence.token.present132 = icmp ne i32 %convergence.current.token131, 0
  br i1 %convergence.token.present132, label %convergence.cascade129, label %convergence.cascade.exit130

schedule.13:                                      ; preds = %varying.coherent.false110, %scheduler.dispatch.route
  %290 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token149 = load i32, ptr %current.token, align 4
  %convergence.token.present150 = icmp ne i32 %convergence.current.token149, 0
  br i1 %convergence.token.present150, label %convergence.cascade147, label %convergence.cascade.exit148

varying.divergent:                                ; preds = %schedule.1
  %291 = load i32, ptr %current.token, align 4
  %292 = icmp ne i32 %291, 0
  %293 = sub i32 %291, 1
  %294 = select i1 %292, i32 %293, i32 0
  %295 = load i8, ptr %frame.active, align 1
  %296 = trunc i32 %294 to i8
  %297 = shl i8 1, %296
  %298 = and i8 %295, %297
  %299 = icmp ne i8 %298, 0
  %300 = load <8 x i32>, ptr %frame.static.id, align 32
  %301 = extractelement <8 x i32> %300, i32 %294
  %302 = icmp eq i32 %301, 0
  %303 = and i1 %299, %302
  %304 = and i1 %292, %303
  %305 = xor i1 %304, true
  %306 = and i1 true, %305
  %307 = xor i8 %295, -1
  %308 = icmp ne i8 %307, 0
  %309 = xor i1 %308, true
  %310 = and i1 %306, %309
  br i1 %310, label %convergence.overflow.trap, label %convergence.overflow.resume

varying.coherent:                                 ; preds = %schedule.1
  br i1 %118, label %varying.coherent.true, label %varying.coherent.false

convergence.overflow.trap:                        ; preds = %varying.divergent
  call void @llvm.trap()
  unreachable

convergence.overflow.resume:                      ; preds = %varying.divergent
  %311 = call i8 @llvm.cttz.i8(i8 %307, i1 false)
  %312 = zext i8 %311 to i32
  %313 = select i1 %308, i32 %312, i32 0
  %314 = trunc i32 %313 to i8
  %315 = shl i8 1, %314
  %316 = or i8 %295, %315
  %317 = select i1 %306, i8 %316, i8 %295
  store i8 %317, ptr %frame.active, align 1
  %318 = load <8 x i32>, ptr %frame.static.id, align 32
  %319 = extractelement <8 x i32> %318, i32 %313
  %320 = select i1 %306, i32 0, i32 %319
  %321 = load <8 x i32>, ptr %frame.static.id, align 32
  %322 = insertelement <8 x i32> %321, i32 %320, i32 %313
  store <8 x i32> %322, ptr %frame.static.id, align 32
  %323 = load <8 x i32>, ptr %frame.parent.token, align 32
  %324 = extractelement <8 x i32> %323, i32 %313
  %325 = select i1 %306, i32 %291, i32 %324
  %326 = load <8 x i32>, ptr %frame.parent.token, align 32
  %327 = insertelement <8 x i32> %326, i32 %325, i32 %313
  store <8 x i32> %327, ptr %frame.parent.token, align 32
  %328 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %313
  %329 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %313
  %330 = load <8 x i1>, ptr %328, align 1
  %331 = load <8 x i1>, ptr %329, align 1
  %332 = select i1 %306, <8 x i1> %108, <8 x i1> %330
  store <8 x i1> %332, ptr %328, align 1
  %333 = select i1 %306, <8 x i1> zeroinitializer, <8 x i1> %331
  store <8 x i1> %333, ptr %329, align 1
  %334 = add i32 %313, 1
  %335 = select i1 %304, i32 %291, i32 %334
  %336 = select i1 true, i32 %335, i32 %291
  store i32 %336, ptr %current.token, align 4
  %337 = load i32, ptr %current.token, align 4
  %338 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %115)
  %339 = load i32, ptr %ready.count, align 4
  %340 = icmp uge i32 %339, 8
  %341 = and i1 %338, %340
  br i1 %341, label %ready.overflow.trap22, label %ready.overflow.resume23

ready.overflow.trap22:                            ; preds = %convergence.overflow.resume
  call void @llvm.trap()
  unreachable

ready.overflow.resume23:                          ; preds = %convergence.overflow.resume
  %342 = select i1 %338, i32 %339, i32 0
  %343 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %342
  %344 = load <8 x i1>, ptr %343, align 1
  %345 = select i1 %338, <8 x i1> %115, <8 x i1> %344
  store <8 x i1> %345, ptr %343, align 1
  %346 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %342
  %347 = load i32, ptr %346, align 4
  %348 = select i1 %338, i32 2, i32 %347
  store i32 %348, ptr %346, align 4
  %349 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %342
  %350 = load i32, ptr %349, align 4
  %351 = select i1 %338, i32 %337, i32 %350
  store i32 %351, ptr %349, align 4
  %352 = add i32 %339, 1
  %353 = select i1 %338, i32 %352, i32 %339
  store i32 %353, ptr %ready.count, align 4
  %354 = load <8 x i1>, ptr %runnable.mask, align 1
  %355 = or <8 x i1> %354, %115
  store <8 x i1> %355, ptr %runnable.mask, align 1
  %356 = load i32, ptr %current.token, align 4
  %357 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %117)
  %358 = load i32, ptr %ready.count, align 4
  %359 = icmp uge i32 %358, 8
  %360 = and i1 %357, %359
  br i1 %360, label %ready.overflow.trap24, label %ready.overflow.resume25

ready.overflow.trap24:                            ; preds = %ready.overflow.resume23
  call void @llvm.trap()
  unreachable

ready.overflow.resume25:                          ; preds = %ready.overflow.resume23
  %361 = select i1 %357, i32 %358, i32 0
  %362 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %361
  %363 = load <8 x i1>, ptr %362, align 1
  %364 = select i1 %357, <8 x i1> %117, <8 x i1> %363
  store <8 x i1> %364, ptr %362, align 1
  %365 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %361
  %366 = load i32, ptr %365, align 4
  %367 = select i1 %357, i32 5, i32 %366
  store i32 %367, ptr %365, align 4
  %368 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %361
  %369 = load i32, ptr %368, align 4
  %370 = select i1 %357, i32 %356, i32 %369
  store i32 %370, ptr %368, align 4
  %371 = add i32 %358, 1
  %372 = select i1 %357, i32 %371, i32 %358
  store i32 %372, ptr %ready.count, align 4
  %373 = load <8 x i1>, ptr %runnable.mask, align 1
  %374 = or <8 x i1> %373, %117
  store <8 x i1> %374, ptr %runnable.mask, align 1
  br label %scheduler.loop

varying.coherent.true:                            ; preds = %varying.coherent
  store <8 x i1> %108, ptr %current.mask, align 1
  %375 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %108)
  br i1 %375, label %schedule.2, label %scheduler.loop

varying.coherent.false:                           ; preds = %varying.coherent
  store <8 x i1> %108, ptr %current.mask, align 1
  %376 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %108)
  br i1 %376, label %schedule.5, label %scheduler.loop

varying.divergent29:                              ; preds = %schedule.2
  %377 = load i32, ptr %current.token, align 4
  %378 = icmp ne i32 %377, 0
  %379 = sub i32 %377, 1
  %380 = select i1 %378, i32 %379, i32 0
  %381 = load i8, ptr %frame.active, align 1
  %382 = trunc i32 %380 to i8
  %383 = shl i8 1, %382
  %384 = and i8 %381, %383
  %385 = icmp ne i8 %384, 0
  %386 = load <8 x i32>, ptr %frame.static.id, align 32
  %387 = extractelement <8 x i32> %386, i32 %380
  %388 = icmp eq i32 %387, 1
  %389 = and i1 %385, %388
  %390 = and i1 %378, %389
  %391 = xor i1 %390, true
  %392 = and i1 true, %391
  %393 = xor i8 %381, -1
  %394 = icmp ne i8 %393, 0
  %395 = xor i1 %394, true
  %396 = and i1 %392, %395
  br i1 %396, label %convergence.overflow.trap31, label %convergence.overflow.resume32

varying.coherent30:                               ; preds = %schedule.2
  br i1 %151, label %varying.coherent.true37, label %varying.coherent.false38

convergence.overflow.trap31:                      ; preds = %varying.divergent29
  call void @llvm.trap()
  unreachable

convergence.overflow.resume32:                    ; preds = %varying.divergent29
  %397 = call i8 @llvm.cttz.i8(i8 %393, i1 false)
  %398 = zext i8 %397 to i32
  %399 = select i1 %394, i32 %398, i32 0
  %400 = trunc i32 %399 to i8
  %401 = shl i8 1, %400
  %402 = or i8 %381, %401
  %403 = select i1 %392, i8 %402, i8 %381
  store i8 %403, ptr %frame.active, align 1
  %404 = load <8 x i32>, ptr %frame.static.id, align 32
  %405 = extractelement <8 x i32> %404, i32 %399
  %406 = select i1 %392, i32 1, i32 %405
  %407 = load <8 x i32>, ptr %frame.static.id, align 32
  %408 = insertelement <8 x i32> %407, i32 %406, i32 %399
  store <8 x i32> %408, ptr %frame.static.id, align 32
  %409 = load <8 x i32>, ptr %frame.parent.token, align 32
  %410 = extractelement <8 x i32> %409, i32 %399
  %411 = select i1 %392, i32 %377, i32 %410
  %412 = load <8 x i32>, ptr %frame.parent.token, align 32
  %413 = insertelement <8 x i32> %412, i32 %411, i32 %399
  store <8 x i32> %413, ptr %frame.parent.token, align 32
  %414 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %399
  %415 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %399
  %416 = load <8 x i1>, ptr %414, align 1
  %417 = load <8 x i1>, ptr %415, align 1
  %418 = select i1 %392, <8 x i1> %121, <8 x i1> %416
  store <8 x i1> %418, ptr %414, align 1
  %419 = select i1 %392, <8 x i1> zeroinitializer, <8 x i1> %417
  store <8 x i1> %419, ptr %415, align 1
  %420 = add i32 %399, 1
  %421 = select i1 %390, i32 %377, i32 %420
  %422 = select i1 true, i32 %421, i32 %377
  store i32 %422, ptr %current.token, align 4
  %423 = load <8 x float>, ptr %.slot6, align 32
  %424 = select <8 x i1> %150, <8 x float> zeroinitializer, <8 x float> %423
  store <8 x float> %424, ptr %.slot6, align 32
  %425 = load i32, ptr %current.token, align 4
  %426 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %148)
  %427 = load i32, ptr %ready.count, align 4
  %428 = icmp uge i32 %427, 8
  %429 = and i1 %426, %428
  br i1 %429, label %ready.overflow.trap33, label %ready.overflow.resume34

ready.overflow.trap33:                            ; preds = %convergence.overflow.resume32
  call void @llvm.trap()
  unreachable

ready.overflow.resume34:                          ; preds = %convergence.overflow.resume32
  %430 = select i1 %426, i32 %427, i32 0
  %431 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %430
  %432 = load <8 x i1>, ptr %431, align 1
  %433 = select i1 %426, <8 x i1> %148, <8 x i1> %432
  store <8 x i1> %433, ptr %431, align 1
  %434 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %430
  %435 = load i32, ptr %434, align 4
  %436 = select i1 %426, i32 3, i32 %435
  store i32 %436, ptr %434, align 4
  %437 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %430
  %438 = load i32, ptr %437, align 4
  %439 = select i1 %426, i32 %425, i32 %438
  store i32 %439, ptr %437, align 4
  %440 = add i32 %427, 1
  %441 = select i1 %426, i32 %440, i32 %427
  store i32 %441, ptr %ready.count, align 4
  %442 = load <8 x i1>, ptr %runnable.mask, align 1
  %443 = or <8 x i1> %442, %148
  store <8 x i1> %443, ptr %runnable.mask, align 1
  %444 = load i32, ptr %current.token, align 4
  %445 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %150)
  %446 = load i32, ptr %ready.count, align 4
  %447 = icmp uge i32 %446, 8
  %448 = and i1 %445, %447
  br i1 %448, label %ready.overflow.trap35, label %ready.overflow.resume36

ready.overflow.trap35:                            ; preds = %ready.overflow.resume34
  call void @llvm.trap()
  unreachable

ready.overflow.resume36:                          ; preds = %ready.overflow.resume34
  %449 = select i1 %445, i32 %446, i32 0
  %450 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %449
  %451 = load <8 x i1>, ptr %450, align 1
  %452 = select i1 %445, <8 x i1> %150, <8 x i1> %451
  store <8 x i1> %452, ptr %450, align 1
  %453 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %449
  %454 = load i32, ptr %453, align 4
  %455 = select i1 %445, i32 4, i32 %454
  store i32 %455, ptr %453, align 4
  %456 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %449
  %457 = load i32, ptr %456, align 4
  %458 = select i1 %445, i32 %444, i32 %457
  store i32 %458, ptr %456, align 4
  %459 = add i32 %446, 1
  %460 = select i1 %445, i32 %459, i32 %446
  store i32 %460, ptr %ready.count, align 4
  %461 = load <8 x i1>, ptr %runnable.mask, align 1
  %462 = or <8 x i1> %461, %150
  store <8 x i1> %462, ptr %runnable.mask, align 1
  br label %scheduler.loop

varying.coherent.true37:                          ; preds = %varying.coherent30
  store <8 x i1> %121, ptr %current.mask, align 1
  %463 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %121)
  br i1 %463, label %schedule.3, label %scheduler.loop

varying.coherent.false38:                         ; preds = %varying.coherent30
  %464 = load <8 x float>, ptr %.slot6, align 32
  %465 = select <8 x i1> %121, <8 x float> zeroinitializer, <8 x float> %464
  store <8 x float> %465, ptr %.slot6, align 32
  store <8 x i1> %121, ptr %current.mask, align 1
  %466 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %121)
  br i1 %466, label %schedule.4, label %scheduler.loop

convergence.cascade:                              ; preds = %convergence.cascade, %schedule.4
  %convergence.cascade.flow = phi <8 x i1> [ %167, %schedule.4 ], [ %509, %convergence.cascade ]
  %convergence.cascade.depth = phi i32 [ 0, %schedule.4 ], [ %510, %convergence.cascade ]
  %467 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow)
  %468 = load i32, ptr %current.token, align 4
  %469 = icmp ne i32 %468, 0
  %470 = and i1 %467, %469
  %471 = sub i32 %468, 1
  %472 = select i1 %470, i32 %471, i32 0
  %473 = load i8, ptr %frame.active, align 1
  %474 = trunc i32 %472 to i8
  %475 = shl i8 1, %474
  %476 = and i8 %473, %475
  %477 = icmp ne i8 %476, 0
  %478 = load <8 x i32>, ptr %frame.static.id, align 32
  %479 = extractelement <8 x i32> %478, i32 %472
  %convergence.target.pointer = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %479
  %convergence.dynamic.target = load i32, ptr %convergence.target.pointer, align 4
  %480 = icmp eq i32 %convergence.dynamic.target, 4
  %481 = and i1 %477, %480
  %482 = and i1 %470, %481
  %483 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %472
  %484 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %472
  %485 = load <8 x i1>, ptr %483, align 1
  %486 = load <8 x i1>, ptr %484, align 1
  %487 = or <8 x i1> %486, %convergence.cascade.flow
  %488 = load <8 x i1>, ptr %live.mask, align 1
  %489 = and <8 x i1> %485, %488
  %490 = icmp eq <8 x i1> %487, %489
  %491 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %490)
  %492 = and i1 %482, %491
  %493 = select i1 %492, <8 x i1> zeroinitializer, <8 x i1> %487
  %494 = select i1 %482, <8 x i1> %493, <8 x i1> %486
  store <8 x i1> %494, ptr %484, align 1
  %495 = select i1 %492, <8 x i1> zeroinitializer, <8 x i1> %485
  store <8 x i1> %495, ptr %483, align 1
  %496 = trunc i32 %472 to i8
  %497 = shl i8 1, %496
  %498 = xor i8 %497, -1
  %499 = and i8 %473, %498
  %500 = select i1 %492, i8 %499, i8 %473
  store i8 %500, ptr %frame.active, align 1
  %.splatinsert40 = insertelement <8 x i1> poison, i1 %482, i64 0
  %.splat41 = shufflevector <8 x i1> %.splatinsert40, <8 x i1> poison, <8 x i32> zeroinitializer
  %501 = and <8 x i1> %convergence.cascade.flow, %.splat41
  %502 = load <8 x i1>, ptr %runnable.mask, align 1
  %503 = xor <8 x i1> %501, splat (i1 true)
  %504 = and <8 x i1> %502, %503
  store <8 x i1> %504, ptr %runnable.mask, align 1
  %.splatinsert42 = insertelement <8 x i1> poison, i1 %492, i64 0
  %.splat43 = shufflevector <8 x i1> %.splatinsert42, <8 x i1> poison, <8 x i32> zeroinitializer
  %505 = select <8 x i1> %.splat43, <8 x i1> %487, <8 x i1> zeroinitializer
  %506 = load <8 x i32>, ptr %frame.parent.token, align 32
  %507 = extractelement <8 x i32> %506, i32 %472
  %508 = select i1 %492, i32 %507, i32 %468
  store i32 %508, ptr %current.token, align 4
  %.splatinsert44 = insertelement <8 x i1> poison, i1 %482, i64 0
  %.splat45 = shufflevector <8 x i1> %.splatinsert44, <8 x i1> poison, <8 x i32> zeroinitializer
  %509 = select <8 x i1> %.splat45, <8 x i1> %505, <8 x i1> %convergence.cascade.flow
  %510 = add i32 %convergence.cascade.depth, 1
  %511 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %509)
  %512 = icmp ult i32 %510, 8
  %513 = and i1 %511, %512
  %514 = and i1 %482, %513
  %convergence.parent.token = load i32, ptr %current.token, align 4
  %convergence.parent.present = icmp ne i32 %convergence.parent.token, 0
  %515 = and i1 %514, %convergence.parent.present
  br i1 %515, label %convergence.cascade, label %convergence.cascade.exit

convergence.cascade.exit:                         ; preds = %convergence.cascade, %schedule.4
  %convergence.cascade.result = phi <8 x i1> [ %167, %schedule.4 ], [ %509, %convergence.cascade ]
  %516 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %516, label %convergence.target.4.ready, label %scheduler.loop

convergence.target.4.ready:                       ; preds = %convergence.cascade.exit
  %517 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %518 = bitcast <8 x i1> %convergence.cascade.result to i8
  %519 = call i8 @llvm.cttz.i8(i8 %518, i1 false)
  %520 = zext i8 %519 to i32
  %521 = select i1 %517, i32 %520, i32 0
  %tile_snapshot.spill.load = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %522 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %523 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state46 = load <8 x i64>, ptr %.slot, align 64
  %524 = mul <8 x i64> %.state46, splat (i64 32)
  %525 = add <8 x i64> %523, %524
  %526 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %522, 0
  %527 = insertvalue { <8 x ptr>, <8 x i64> } %526, <8 x i64> %525, 1
  %.state47 = load <8 x float>, ptr %.slot6, align 32
  %528 = extractvalue { <8 x ptr>, <8 x i64> } %527, 0
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %527, 1
  %530 = getelementptr i8, <8 x ptr> %528, <8 x i64> %529
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state47, <8 x ptr> %530, i32 1, <8 x i1> %convergence.cascade.result)
  %.state48 = load <8 x i64>, ptr %.slot, align 64
  %531 = add <8 x i64> %.state48, splat (i64 1)
  %532 = load <8 x i64>, ptr %.slot, align 64
  %533 = select <8 x i1> %convergence.cascade.result, <8 x i64> %531, <8 x i64> %532
  store <8 x i64> %533, ptr %.slot, align 64
  store <8 x i1> %convergence.cascade.result, ptr %current.mask, align 1
  %534 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %534, label %schedule.1, label %scheduler.loop

convergence.cascade49:                            ; preds = %convergence.cascade49, %schedule.5
  %convergence.cascade.flow53 = phi <8 x i1> [ %168, %schedule.5 ], [ %577, %convergence.cascade49 ]
  %convergence.cascade.depth54 = phi i32 [ 0, %schedule.5 ], [ %578, %convergence.cascade49 ]
  %535 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow53)
  %536 = load i32, ptr %current.token, align 4
  %537 = icmp ne i32 %536, 0
  %538 = and i1 %535, %537
  %539 = sub i32 %536, 1
  %540 = select i1 %538, i32 %539, i32 0
  %541 = load i8, ptr %frame.active, align 1
  %542 = trunc i32 %540 to i8
  %543 = shl i8 1, %542
  %544 = and i8 %541, %543
  %545 = icmp ne i8 %544, 0
  %546 = load <8 x i32>, ptr %frame.static.id, align 32
  %547 = extractelement <8 x i32> %546, i32 %540
  %convergence.target.pointer55 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %547
  %convergence.dynamic.target56 = load i32, ptr %convergence.target.pointer55, align 4
  %548 = icmp eq i32 %convergence.dynamic.target56, 5
  %549 = and i1 %545, %548
  %550 = and i1 %538, %549
  %551 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %540
  %552 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %540
  %553 = load <8 x i1>, ptr %551, align 1
  %554 = load <8 x i1>, ptr %552, align 1
  %555 = or <8 x i1> %554, %convergence.cascade.flow53
  %556 = load <8 x i1>, ptr %live.mask, align 1
  %557 = and <8 x i1> %553, %556
  %558 = icmp eq <8 x i1> %555, %557
  %559 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %558)
  %560 = and i1 %550, %559
  %561 = select i1 %560, <8 x i1> zeroinitializer, <8 x i1> %555
  %562 = select i1 %550, <8 x i1> %561, <8 x i1> %554
  store <8 x i1> %562, ptr %552, align 1
  %563 = select i1 %560, <8 x i1> zeroinitializer, <8 x i1> %553
  store <8 x i1> %563, ptr %551, align 1
  %564 = trunc i32 %540 to i8
  %565 = shl i8 1, %564
  %566 = xor i8 %565, -1
  %567 = and i8 %541, %566
  %568 = select i1 %560, i8 %567, i8 %541
  store i8 %568, ptr %frame.active, align 1
  %.splatinsert57 = insertelement <8 x i1> poison, i1 %550, i64 0
  %.splat58 = shufflevector <8 x i1> %.splatinsert57, <8 x i1> poison, <8 x i32> zeroinitializer
  %569 = and <8 x i1> %convergence.cascade.flow53, %.splat58
  %570 = load <8 x i1>, ptr %runnable.mask, align 1
  %571 = xor <8 x i1> %569, splat (i1 true)
  %572 = and <8 x i1> %570, %571
  store <8 x i1> %572, ptr %runnable.mask, align 1
  %.splatinsert59 = insertelement <8 x i1> poison, i1 %560, i64 0
  %.splat60 = shufflevector <8 x i1> %.splatinsert59, <8 x i1> poison, <8 x i32> zeroinitializer
  %573 = select <8 x i1> %.splat60, <8 x i1> %555, <8 x i1> zeroinitializer
  %574 = load <8 x i32>, ptr %frame.parent.token, align 32
  %575 = extractelement <8 x i32> %574, i32 %540
  %576 = select i1 %560, i32 %575, i32 %536
  store i32 %576, ptr %current.token, align 4
  %.splatinsert61 = insertelement <8 x i1> poison, i1 %550, i64 0
  %.splat62 = shufflevector <8 x i1> %.splatinsert61, <8 x i1> poison, <8 x i32> zeroinitializer
  %577 = select <8 x i1> %.splat62, <8 x i1> %573, <8 x i1> %convergence.cascade.flow53
  %578 = add i32 %convergence.cascade.depth54, 1
  %579 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %577)
  %580 = icmp ult i32 %578, 8
  %581 = and i1 %579, %580
  %582 = and i1 %550, %581
  %convergence.parent.token63 = load i32, ptr %current.token, align 4
  %convergence.parent.present64 = icmp ne i32 %convergence.parent.token63, 0
  %583 = and i1 %582, %convergence.parent.present64
  br i1 %583, label %convergence.cascade49, label %convergence.cascade.exit50

convergence.cascade.exit50:                       ; preds = %convergence.cascade49, %schedule.5
  %convergence.cascade.result65 = phi <8 x i1> [ %168, %schedule.5 ], [ %577, %convergence.cascade49 ]
  %584 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result65)
  br i1 %584, label %convergence.target.5.ready, label %scheduler.loop

convergence.target.5.ready:                       ; preds = %convergence.cascade.exit50
  %585 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result65)
  %586 = bitcast <8 x i1> %convergence.cascade.result65 to i8
  %587 = call i8 @llvm.cttz.i8(i8 %586, i1 false)
  %588 = zext i8 %587 to i32
  %589 = select i1 %585, i32 %588, i32 0
  %590 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill7, align 64
  %591 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %592 = extractvalue { <8 x ptr>, <8 x i64> } %590, 0
  %593 = select <8 x i1> %convergence.cascade.result65, <8 x ptr> %591, <8 x ptr> %592
  %594 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %595 = extractvalue { <8 x ptr>, <8 x i64> } %590, 1
  %596 = select <8 x i1> %convergence.cascade.result65, <8 x i64> %594, <8 x i64> %595
  %597 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %593, 0
  %598 = insertvalue { <8 x ptr>, <8 x i64> } %597, <8 x i64> %596, 1
  store volatile { <8 x ptr>, <8 x i64> } %598, ptr %tile_snapshot.spill7, align 64
  %599 = load <8 x i64>, ptr %.slot8, align 64
  %600 = select <8 x i1> %convergence.cascade.result65, <8 x i64> zeroinitializer, <8 x i64> %599
  store <8 x i64> %600, ptr %.slot8, align 64
  store <8 x i1> %convergence.cascade.result65, ptr %current.mask, align 1
  %601 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result65)
  br i1 %601, label %schedule.6, label %scheduler.loop

varying.divergent67:                              ; preds = %schedule.6
  %602 = load i32, ptr %current.token, align 4
  %603 = icmp ne i32 %602, 0
  %604 = sub i32 %602, 1
  %605 = select i1 %603, i32 %604, i32 0
  %606 = load i8, ptr %frame.active, align 1
  %607 = trunc i32 %605 to i8
  %608 = shl i8 1, %607
  %609 = and i8 %606, %608
  %610 = icmp ne i8 %609, 0
  %611 = load <8 x i32>, ptr %frame.static.id, align 32
  %612 = extractelement <8 x i32> %611, i32 %605
  %613 = icmp eq i32 %612, 2
  %614 = and i1 %610, %613
  %615 = and i1 %603, %614
  %616 = xor i1 %615, true
  %617 = and i1 true, %616
  %618 = xor i8 %606, -1
  %619 = icmp ne i8 %618, 0
  %620 = xor i1 %619, true
  %621 = and i1 %617, %620
  br i1 %621, label %convergence.overflow.trap69, label %convergence.overflow.resume70

varying.coherent68:                               ; preds = %schedule.6
  br i1 %179, label %varying.coherent.true75, label %varying.coherent.false76

convergence.overflow.trap69:                      ; preds = %varying.divergent67
  call void @llvm.trap()
  unreachable

convergence.overflow.resume70:                    ; preds = %varying.divergent67
  %622 = call i8 @llvm.cttz.i8(i8 %618, i1 false)
  %623 = zext i8 %622 to i32
  %624 = select i1 %619, i32 %623, i32 0
  %625 = trunc i32 %624 to i8
  %626 = shl i8 1, %625
  %627 = or i8 %606, %626
  %628 = select i1 %617, i8 %627, i8 %606
  store i8 %628, ptr %frame.active, align 1
  %629 = load <8 x i32>, ptr %frame.static.id, align 32
  %630 = extractelement <8 x i32> %629, i32 %624
  %631 = select i1 %617, i32 2, i32 %630
  %632 = load <8 x i32>, ptr %frame.static.id, align 32
  %633 = insertelement <8 x i32> %632, i32 %631, i32 %624
  store <8 x i32> %633, ptr %frame.static.id, align 32
  %634 = load <8 x i32>, ptr %frame.parent.token, align 32
  %635 = extractelement <8 x i32> %634, i32 %624
  %636 = select i1 %617, i32 %602, i32 %635
  %637 = load <8 x i32>, ptr %frame.parent.token, align 32
  %638 = insertelement <8 x i32> %637, i32 %636, i32 %624
  store <8 x i32> %638, ptr %frame.parent.token, align 32
  %639 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %624
  %640 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %624
  %641 = load <8 x i1>, ptr %639, align 1
  %642 = load <8 x i1>, ptr %640, align 1
  %643 = select i1 %617, <8 x i1> %169, <8 x i1> %641
  store <8 x i1> %643, ptr %639, align 1
  %644 = select i1 %617, <8 x i1> zeroinitializer, <8 x i1> %642
  store <8 x i1> %644, ptr %640, align 1
  %645 = add i32 %624, 1
  %646 = select i1 %615, i32 %602, i32 %645
  %647 = select i1 true, i32 %646, i32 %602
  store i32 %647, ptr %current.token, align 4
  %648 = load i32, ptr %current.token, align 4
  %649 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %176)
  %650 = load i32, ptr %ready.count, align 4
  %651 = icmp uge i32 %650, 8
  %652 = and i1 %649, %651
  br i1 %652, label %ready.overflow.trap71, label %ready.overflow.resume72

ready.overflow.trap71:                            ; preds = %convergence.overflow.resume70
  call void @llvm.trap()
  unreachable

ready.overflow.resume72:                          ; preds = %convergence.overflow.resume70
  %653 = select i1 %649, i32 %650, i32 0
  %654 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %653
  %655 = load <8 x i1>, ptr %654, align 1
  %656 = select i1 %649, <8 x i1> %176, <8 x i1> %655
  store <8 x i1> %656, ptr %654, align 1
  %657 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %653
  %658 = load i32, ptr %657, align 4
  %659 = select i1 %649, i32 7, i32 %658
  store i32 %659, ptr %657, align 4
  %660 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %653
  %661 = load i32, ptr %660, align 4
  %662 = select i1 %649, i32 %648, i32 %661
  store i32 %662, ptr %660, align 4
  %663 = add i32 %650, 1
  %664 = select i1 %649, i32 %663, i32 %650
  store i32 %664, ptr %ready.count, align 4
  %665 = load <8 x i1>, ptr %runnable.mask, align 1
  %666 = or <8 x i1> %665, %176
  store <8 x i1> %666, ptr %runnable.mask, align 1
  %667 = load i32, ptr %current.token, align 4
  %668 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %178)
  %669 = load i32, ptr %ready.count, align 4
  %670 = icmp uge i32 %669, 8
  %671 = and i1 %668, %670
  br i1 %671, label %ready.overflow.trap73, label %ready.overflow.resume74

ready.overflow.trap73:                            ; preds = %ready.overflow.resume72
  call void @llvm.trap()
  unreachable

ready.overflow.resume74:                          ; preds = %ready.overflow.resume72
  %672 = select i1 %668, i32 %669, i32 0
  %673 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %672
  %674 = load <8 x i1>, ptr %673, align 1
  %675 = select i1 %668, <8 x i1> %178, <8 x i1> %674
  store <8 x i1> %675, ptr %673, align 1
  %676 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %672
  %677 = load i32, ptr %676, align 4
  %678 = select i1 %668, i32 8, i32 %677
  store i32 %678, ptr %676, align 4
  %679 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %672
  %680 = load i32, ptr %679, align 4
  %681 = select i1 %668, i32 %667, i32 %680
  store i32 %681, ptr %679, align 4
  %682 = add i32 %669, 1
  %683 = select i1 %668, i32 %682, i32 %669
  store i32 %683, ptr %ready.count, align 4
  %684 = load <8 x i1>, ptr %runnable.mask, align 1
  %685 = or <8 x i1> %684, %178
  store <8 x i1> %685, ptr %runnable.mask, align 1
  br label %scheduler.loop

varying.coherent.true75:                          ; preds = %varying.coherent68
  store <8 x i1> %169, ptr %current.mask, align 1
  %686 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %169)
  br i1 %686, label %schedule.7, label %scheduler.loop

varying.coherent.false76:                         ; preds = %varying.coherent68
  store <8 x i1> %169, ptr %current.mask, align 1
  %687 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %169)
  br i1 %687, label %schedule.8, label %scheduler.loop

convergence.cascade83:                            ; preds = %convergence.cascade83, %schedule.8
  %convergence.cascade.flow87 = phi <8 x i1> [ %220, %schedule.8 ], [ %730, %convergence.cascade83 ]
  %convergence.cascade.depth88 = phi i32 [ 0, %schedule.8 ], [ %731, %convergence.cascade83 ]
  %688 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow87)
  %689 = load i32, ptr %current.token, align 4
  %690 = icmp ne i32 %689, 0
  %691 = and i1 %688, %690
  %692 = sub i32 %689, 1
  %693 = select i1 %691, i32 %692, i32 0
  %694 = load i8, ptr %frame.active, align 1
  %695 = trunc i32 %693 to i8
  %696 = shl i8 1, %695
  %697 = and i8 %694, %696
  %698 = icmp ne i8 %697, 0
  %699 = load <8 x i32>, ptr %frame.static.id, align 32
  %700 = extractelement <8 x i32> %699, i32 %693
  %convergence.target.pointer89 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %700
  %convergence.dynamic.target90 = load i32, ptr %convergence.target.pointer89, align 4
  %701 = icmp eq i32 %convergence.dynamic.target90, 8
  %702 = and i1 %698, %701
  %703 = and i1 %691, %702
  %704 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %693
  %705 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %693
  %706 = load <8 x i1>, ptr %704, align 1
  %707 = load <8 x i1>, ptr %705, align 1
  %708 = or <8 x i1> %707, %convergence.cascade.flow87
  %709 = load <8 x i1>, ptr %live.mask, align 1
  %710 = and <8 x i1> %706, %709
  %711 = icmp eq <8 x i1> %708, %710
  %712 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %711)
  %713 = and i1 %703, %712
  %714 = select i1 %713, <8 x i1> zeroinitializer, <8 x i1> %708
  %715 = select i1 %703, <8 x i1> %714, <8 x i1> %707
  store <8 x i1> %715, ptr %705, align 1
  %716 = select i1 %713, <8 x i1> zeroinitializer, <8 x i1> %706
  store <8 x i1> %716, ptr %704, align 1
  %717 = trunc i32 %693 to i8
  %718 = shl i8 1, %717
  %719 = xor i8 %718, -1
  %720 = and i8 %694, %719
  %721 = select i1 %713, i8 %720, i8 %694
  store i8 %721, ptr %frame.active, align 1
  %.splatinsert91 = insertelement <8 x i1> poison, i1 %703, i64 0
  %.splat92 = shufflevector <8 x i1> %.splatinsert91, <8 x i1> poison, <8 x i32> zeroinitializer
  %722 = and <8 x i1> %convergence.cascade.flow87, %.splat92
  %723 = load <8 x i1>, ptr %runnable.mask, align 1
  %724 = xor <8 x i1> %722, splat (i1 true)
  %725 = and <8 x i1> %723, %724
  store <8 x i1> %725, ptr %runnable.mask, align 1
  %.splatinsert93 = insertelement <8 x i1> poison, i1 %713, i64 0
  %.splat94 = shufflevector <8 x i1> %.splatinsert93, <8 x i1> poison, <8 x i32> zeroinitializer
  %726 = select <8 x i1> %.splat94, <8 x i1> %708, <8 x i1> zeroinitializer
  %727 = load <8 x i32>, ptr %frame.parent.token, align 32
  %728 = extractelement <8 x i32> %727, i32 %693
  %729 = select i1 %713, i32 %728, i32 %689
  store i32 %729, ptr %current.token, align 4
  %.splatinsert95 = insertelement <8 x i1> poison, i1 %703, i64 0
  %.splat96 = shufflevector <8 x i1> %.splatinsert95, <8 x i1> poison, <8 x i32> zeroinitializer
  %730 = select <8 x i1> %.splat96, <8 x i1> %726, <8 x i1> %convergence.cascade.flow87
  %731 = add i32 %convergence.cascade.depth88, 1
  %732 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %730)
  %733 = icmp ult i32 %731, 8
  %734 = and i1 %732, %733
  %735 = and i1 %703, %734
  %convergence.parent.token97 = load i32, ptr %current.token, align 4
  %convergence.parent.present98 = icmp ne i32 %convergence.parent.token97, 0
  %736 = and i1 %735, %convergence.parent.present98
  br i1 %736, label %convergence.cascade83, label %convergence.cascade.exit84

convergence.cascade.exit84:                       ; preds = %convergence.cascade83, %schedule.8
  %convergence.cascade.result99 = phi <8 x i1> [ %220, %schedule.8 ], [ %730, %convergence.cascade83 ]
  %737 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result99)
  br i1 %737, label %convergence.target.8.ready, label %scheduler.loop

convergence.target.8.ready:                       ; preds = %convergence.cascade.exit84
  %738 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result99)
  %739 = bitcast <8 x i1> %convergence.cascade.result99 to i8
  %740 = call i8 @llvm.cttz.i8(i8 %739, i1 false)
  %741 = zext i8 %740 to i32
  %742 = select i1 %738, i32 %741, i32 0
  %743 = load <8 x i64>, ptr %.slot9, align 64
  %744 = select <8 x i1> %convergence.cascade.result99, <8 x i64> zeroinitializer, <8 x i64> %743
  store <8 x i64> %744, ptr %.slot9, align 64
  store <8 x i1> %convergence.cascade.result99, ptr %current.mask, align 1
  %745 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result99)
  br i1 %745, label %schedule.9, label %scheduler.loop

varying.divergent101:                             ; preds = %schedule.9
  %746 = load i32, ptr %current.token, align 4
  %747 = icmp ne i32 %746, 0
  %748 = sub i32 %746, 1
  %749 = select i1 %747, i32 %748, i32 0
  %750 = load i8, ptr %frame.active, align 1
  %751 = trunc i32 %749 to i8
  %752 = shl i8 1, %751
  %753 = and i8 %750, %752
  %754 = icmp ne i8 %753, 0
  %755 = load <8 x i32>, ptr %frame.static.id, align 32
  %756 = extractelement <8 x i32> %755, i32 %749
  %757 = icmp eq i32 %756, 3
  %758 = and i1 %754, %757
  %759 = and i1 %747, %758
  %760 = xor i1 %759, true
  %761 = and i1 true, %760
  %762 = xor i8 %750, -1
  %763 = icmp ne i8 %762, 0
  %764 = xor i1 %763, true
  %765 = and i1 %761, %764
  br i1 %765, label %convergence.overflow.trap103, label %convergence.overflow.resume104

varying.coherent102:                              ; preds = %schedule.9
  br i1 %231, label %varying.coherent.true109, label %varying.coherent.false110

convergence.overflow.trap103:                     ; preds = %varying.divergent101
  call void @llvm.trap()
  unreachable

convergence.overflow.resume104:                   ; preds = %varying.divergent101
  %766 = call i8 @llvm.cttz.i8(i8 %762, i1 false)
  %767 = zext i8 %766 to i32
  %768 = select i1 %763, i32 %767, i32 0
  %769 = trunc i32 %768 to i8
  %770 = shl i8 1, %769
  %771 = or i8 %750, %770
  %772 = select i1 %761, i8 %771, i8 %750
  store i8 %772, ptr %frame.active, align 1
  %773 = load <8 x i32>, ptr %frame.static.id, align 32
  %774 = extractelement <8 x i32> %773, i32 %768
  %775 = select i1 %761, i32 3, i32 %774
  %776 = load <8 x i32>, ptr %frame.static.id, align 32
  %777 = insertelement <8 x i32> %776, i32 %775, i32 %768
  store <8 x i32> %777, ptr %frame.static.id, align 32
  %778 = load <8 x i32>, ptr %frame.parent.token, align 32
  %779 = extractelement <8 x i32> %778, i32 %768
  %780 = select i1 %761, i32 %746, i32 %779
  %781 = load <8 x i32>, ptr %frame.parent.token, align 32
  %782 = insertelement <8 x i32> %781, i32 %780, i32 %768
  store <8 x i32> %782, ptr %frame.parent.token, align 32
  %783 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %768
  %784 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %768
  %785 = load <8 x i1>, ptr %783, align 1
  %786 = load <8 x i1>, ptr %784, align 1
  %787 = select i1 %761, <8 x i1> %221, <8 x i1> %785
  store <8 x i1> %787, ptr %783, align 1
  %788 = select i1 %761, <8 x i1> zeroinitializer, <8 x i1> %786
  store <8 x i1> %788, ptr %784, align 1
  %789 = add i32 %768, 1
  %790 = select i1 %759, i32 %746, i32 %789
  %791 = select i1 true, i32 %790, i32 %746
  store i32 %791, ptr %current.token, align 4
  %792 = load i32, ptr %current.token, align 4
  %793 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %228)
  %794 = load i32, ptr %ready.count, align 4
  %795 = icmp uge i32 %794, 8
  %796 = and i1 %793, %795
  br i1 %796, label %ready.overflow.trap105, label %ready.overflow.resume106

ready.overflow.trap105:                           ; preds = %convergence.overflow.resume104
  call void @llvm.trap()
  unreachable

ready.overflow.resume106:                         ; preds = %convergence.overflow.resume104
  %797 = select i1 %793, i32 %794, i32 0
  %798 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %797
  %799 = load <8 x i1>, ptr %798, align 1
  %800 = select i1 %793, <8 x i1> %228, <8 x i1> %799
  store <8 x i1> %800, ptr %798, align 1
  %801 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %797
  %802 = load i32, ptr %801, align 4
  %803 = select i1 %793, i32 10, i32 %802
  store i32 %803, ptr %801, align 4
  %804 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %797
  %805 = load i32, ptr %804, align 4
  %806 = select i1 %793, i32 %792, i32 %805
  store i32 %806, ptr %804, align 4
  %807 = add i32 %794, 1
  %808 = select i1 %793, i32 %807, i32 %794
  store i32 %808, ptr %ready.count, align 4
  %809 = load <8 x i1>, ptr %runnable.mask, align 1
  %810 = or <8 x i1> %809, %228
  store <8 x i1> %810, ptr %runnable.mask, align 1
  %811 = load i32, ptr %current.token, align 4
  %812 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %230)
  %813 = load i32, ptr %ready.count, align 4
  %814 = icmp uge i32 %813, 8
  %815 = and i1 %812, %814
  br i1 %815, label %ready.overflow.trap107, label %ready.overflow.resume108

ready.overflow.trap107:                           ; preds = %ready.overflow.resume106
  call void @llvm.trap()
  unreachable

ready.overflow.resume108:                         ; preds = %ready.overflow.resume106
  %816 = select i1 %812, i32 %813, i32 0
  %817 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %816
  %818 = load <8 x i1>, ptr %817, align 1
  %819 = select i1 %812, <8 x i1> %230, <8 x i1> %818
  store <8 x i1> %819, ptr %817, align 1
  %820 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %816
  %821 = load i32, ptr %820, align 4
  %822 = select i1 %812, i32 13, i32 %821
  store i32 %822, ptr %820, align 4
  %823 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %816
  %824 = load i32, ptr %823, align 4
  %825 = select i1 %812, i32 %811, i32 %824
  store i32 %825, ptr %823, align 4
  %826 = add i32 %813, 1
  %827 = select i1 %812, i32 %826, i32 %813
  store i32 %827, ptr %ready.count, align 4
  %828 = load <8 x i1>, ptr %runnable.mask, align 1
  %829 = or <8 x i1> %828, %230
  store <8 x i1> %829, ptr %runnable.mask, align 1
  br label %scheduler.loop

varying.coherent.true109:                         ; preds = %varying.coherent102
  store <8 x i1> %221, ptr %current.mask, align 1
  %830 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %221)
  br i1 %830, label %schedule.10, label %scheduler.loop

varying.coherent.false110:                        ; preds = %varying.coherent102
  store <8 x i1> %221, ptr %current.mask, align 1
  %831 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %221)
  br i1 %831, label %schedule.13, label %scheduler.loop

varying.divergent117:                             ; preds = %schedule.10
  %832 = load i32, ptr %current.token, align 4
  %833 = icmp ne i32 %832, 0
  %834 = sub i32 %832, 1
  %835 = select i1 %833, i32 %834, i32 0
  %836 = load i8, ptr %frame.active, align 1
  %837 = trunc i32 %835 to i8
  %838 = shl i8 1, %837
  %839 = and i8 %836, %838
  %840 = icmp ne i8 %839, 0
  %841 = load <8 x i32>, ptr %frame.static.id, align 32
  %842 = extractelement <8 x i32> %841, i32 %835
  %843 = icmp eq i32 %842, 4
  %844 = and i1 %840, %843
  %845 = and i1 %833, %844
  %846 = xor i1 %845, true
  %847 = and i1 true, %846
  %848 = xor i8 %836, -1
  %849 = icmp ne i8 %848, 0
  %850 = xor i1 %849, true
  %851 = and i1 %847, %850
  br i1 %851, label %convergence.overflow.trap119, label %convergence.overflow.resume120

varying.coherent118:                              ; preds = %schedule.10
  br i1 %276, label %varying.coherent.true125, label %varying.coherent.false126

convergence.overflow.trap119:                     ; preds = %varying.divergent117
  call void @llvm.trap()
  unreachable

convergence.overflow.resume120:                   ; preds = %varying.divergent117
  %852 = call i8 @llvm.cttz.i8(i8 %848, i1 false)
  %853 = zext i8 %852 to i32
  %854 = select i1 %849, i32 %853, i32 0
  %855 = trunc i32 %854 to i8
  %856 = shl i8 1, %855
  %857 = or i8 %836, %856
  %858 = select i1 %847, i8 %857, i8 %836
  store i8 %858, ptr %frame.active, align 1
  %859 = load <8 x i32>, ptr %frame.static.id, align 32
  %860 = extractelement <8 x i32> %859, i32 %854
  %861 = select i1 %847, i32 4, i32 %860
  %862 = load <8 x i32>, ptr %frame.static.id, align 32
  %863 = insertelement <8 x i32> %862, i32 %861, i32 %854
  store <8 x i32> %863, ptr %frame.static.id, align 32
  %864 = load <8 x i32>, ptr %frame.parent.token, align 32
  %865 = extractelement <8 x i32> %864, i32 %854
  %866 = select i1 %847, i32 %832, i32 %865
  %867 = load <8 x i32>, ptr %frame.parent.token, align 32
  %868 = insertelement <8 x i32> %867, i32 %866, i32 %854
  store <8 x i32> %868, ptr %frame.parent.token, align 32
  %869 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %854
  %870 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %854
  %871 = load <8 x i1>, ptr %869, align 1
  %872 = load <8 x i1>, ptr %870, align 1
  %873 = select i1 %847, <8 x i1> %234, <8 x i1> %871
  store <8 x i1> %873, ptr %869, align 1
  %874 = select i1 %847, <8 x i1> zeroinitializer, <8 x i1> %872
  store <8 x i1> %874, ptr %870, align 1
  %875 = add i32 %854, 1
  %876 = select i1 %845, i32 %832, i32 %875
  %877 = select i1 true, i32 %876, i32 %832
  store i32 %877, ptr %current.token, align 4
  %878 = load i32, ptr %current.token, align 4
  %879 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %273)
  %880 = load i32, ptr %ready.count, align 4
  %881 = icmp uge i32 %880, 8
  %882 = and i1 %879, %881
  br i1 %882, label %ready.overflow.trap121, label %ready.overflow.resume122

ready.overflow.trap121:                           ; preds = %convergence.overflow.resume120
  call void @llvm.trap()
  unreachable

ready.overflow.resume122:                         ; preds = %convergence.overflow.resume120
  %883 = select i1 %879, i32 %880, i32 0
  %884 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %883
  %885 = load <8 x i1>, ptr %884, align 1
  %886 = select i1 %879, <8 x i1> %273, <8 x i1> %885
  store <8 x i1> %886, ptr %884, align 1
  %887 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %883
  %888 = load i32, ptr %887, align 4
  %889 = select i1 %879, i32 11, i32 %888
  store i32 %889, ptr %887, align 4
  %890 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %883
  %891 = load i32, ptr %890, align 4
  %892 = select i1 %879, i32 %878, i32 %891
  store i32 %892, ptr %890, align 4
  %893 = add i32 %880, 1
  %894 = select i1 %879, i32 %893, i32 %880
  store i32 %894, ptr %ready.count, align 4
  %895 = load <8 x i1>, ptr %runnable.mask, align 1
  %896 = or <8 x i1> %895, %273
  store <8 x i1> %896, ptr %runnable.mask, align 1
  %897 = load i32, ptr %current.token, align 4
  %898 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %275)
  %899 = load i32, ptr %ready.count, align 4
  %900 = icmp uge i32 %899, 8
  %901 = and i1 %898, %900
  br i1 %901, label %ready.overflow.trap123, label %ready.overflow.resume124

ready.overflow.trap123:                           ; preds = %ready.overflow.resume122
  call void @llvm.trap()
  unreachable

ready.overflow.resume124:                         ; preds = %ready.overflow.resume122
  %902 = select i1 %898, i32 %899, i32 0
  %903 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %902
  %904 = load <8 x i1>, ptr %903, align 1
  %905 = select i1 %898, <8 x i1> %275, <8 x i1> %904
  store <8 x i1> %905, ptr %903, align 1
  %906 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %902
  %907 = load i32, ptr %906, align 4
  %908 = select i1 %898, i32 12, i32 %907
  store i32 %908, ptr %906, align 4
  %909 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %902
  %910 = load i32, ptr %909, align 4
  %911 = select i1 %898, i32 %897, i32 %910
  store i32 %911, ptr %909, align 4
  %912 = add i32 %899, 1
  %913 = select i1 %898, i32 %912, i32 %899
  store i32 %913, ptr %ready.count, align 4
  %914 = load <8 x i1>, ptr %runnable.mask, align 1
  %915 = or <8 x i1> %914, %275
  store <8 x i1> %915, ptr %runnable.mask, align 1
  br label %scheduler.loop

varying.coherent.true125:                         ; preds = %varying.coherent118
  store <8 x i1> %234, ptr %current.mask, align 1
  %916 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %234)
  br i1 %916, label %schedule.11, label %scheduler.loop

varying.coherent.false126:                        ; preds = %varying.coherent118
  store <8 x i1> %234, ptr %current.mask, align 1
  %917 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %234)
  br i1 %917, label %schedule.12, label %scheduler.loop

convergence.cascade129:                           ; preds = %convergence.cascade129, %schedule.12
  %convergence.cascade.flow133 = phi <8 x i1> [ %289, %schedule.12 ], [ %960, %convergence.cascade129 ]
  %convergence.cascade.depth134 = phi i32 [ 0, %schedule.12 ], [ %961, %convergence.cascade129 ]
  %918 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow133)
  %919 = load i32, ptr %current.token, align 4
  %920 = icmp ne i32 %919, 0
  %921 = and i1 %918, %920
  %922 = sub i32 %919, 1
  %923 = select i1 %921, i32 %922, i32 0
  %924 = load i8, ptr %frame.active, align 1
  %925 = trunc i32 %923 to i8
  %926 = shl i8 1, %925
  %927 = and i8 %924, %926
  %928 = icmp ne i8 %927, 0
  %929 = load <8 x i32>, ptr %frame.static.id, align 32
  %930 = extractelement <8 x i32> %929, i32 %923
  %convergence.target.pointer135 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %930
  %convergence.dynamic.target136 = load i32, ptr %convergence.target.pointer135, align 4
  %931 = icmp eq i32 %convergence.dynamic.target136, 12
  %932 = and i1 %928, %931
  %933 = and i1 %921, %932
  %934 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %923
  %935 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %923
  %936 = load <8 x i1>, ptr %934, align 1
  %937 = load <8 x i1>, ptr %935, align 1
  %938 = or <8 x i1> %937, %convergence.cascade.flow133
  %939 = load <8 x i1>, ptr %live.mask, align 1
  %940 = and <8 x i1> %936, %939
  %941 = icmp eq <8 x i1> %938, %940
  %942 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %941)
  %943 = and i1 %933, %942
  %944 = select i1 %943, <8 x i1> zeroinitializer, <8 x i1> %938
  %945 = select i1 %933, <8 x i1> %944, <8 x i1> %937
  store <8 x i1> %945, ptr %935, align 1
  %946 = select i1 %943, <8 x i1> zeroinitializer, <8 x i1> %936
  store <8 x i1> %946, ptr %934, align 1
  %947 = trunc i32 %923 to i8
  %948 = shl i8 1, %947
  %949 = xor i8 %948, -1
  %950 = and i8 %924, %949
  %951 = select i1 %943, i8 %950, i8 %924
  store i8 %951, ptr %frame.active, align 1
  %.splatinsert137 = insertelement <8 x i1> poison, i1 %933, i64 0
  %.splat138 = shufflevector <8 x i1> %.splatinsert137, <8 x i1> poison, <8 x i32> zeroinitializer
  %952 = and <8 x i1> %convergence.cascade.flow133, %.splat138
  %953 = load <8 x i1>, ptr %runnable.mask, align 1
  %954 = xor <8 x i1> %952, splat (i1 true)
  %955 = and <8 x i1> %953, %954
  store <8 x i1> %955, ptr %runnable.mask, align 1
  %.splatinsert139 = insertelement <8 x i1> poison, i1 %943, i64 0
  %.splat140 = shufflevector <8 x i1> %.splatinsert139, <8 x i1> poison, <8 x i32> zeroinitializer
  %956 = select <8 x i1> %.splat140, <8 x i1> %938, <8 x i1> zeroinitializer
  %957 = load <8 x i32>, ptr %frame.parent.token, align 32
  %958 = extractelement <8 x i32> %957, i32 %923
  %959 = select i1 %943, i32 %958, i32 %919
  store i32 %959, ptr %current.token, align 4
  %.splatinsert141 = insertelement <8 x i1> poison, i1 %933, i64 0
  %.splat142 = shufflevector <8 x i1> %.splatinsert141, <8 x i1> poison, <8 x i32> zeroinitializer
  %960 = select <8 x i1> %.splat142, <8 x i1> %956, <8 x i1> %convergence.cascade.flow133
  %961 = add i32 %convergence.cascade.depth134, 1
  %962 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %960)
  %963 = icmp ult i32 %961, 8
  %964 = and i1 %962, %963
  %965 = and i1 %933, %964
  %convergence.parent.token143 = load i32, ptr %current.token, align 4
  %convergence.parent.present144 = icmp ne i32 %convergence.parent.token143, 0
  %966 = and i1 %965, %convergence.parent.present144
  br i1 %966, label %convergence.cascade129, label %convergence.cascade.exit130

convergence.cascade.exit130:                      ; preds = %convergence.cascade129, %schedule.12
  %convergence.cascade.result145 = phi <8 x i1> [ %289, %schedule.12 ], [ %960, %convergence.cascade129 ]
  %967 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result145)
  br i1 %967, label %convergence.target.12.ready, label %scheduler.loop

convergence.target.12.ready:                      ; preds = %convergence.cascade.exit130
  %968 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result145)
  %969 = bitcast <8 x i1> %convergence.cascade.result145 to i8
  %970 = call i8 @llvm.cttz.i8(i8 %969, i1 false)
  %971 = zext i8 %970 to i32
  %972 = select i1 %968, i32 %971, i32 0
  %.state146 = load <8 x i64>, ptr %.slot9, align 64
  %973 = add <8 x i64> %.state146, splat (i64 1)
  %974 = load <8 x i64>, ptr %.slot9, align 64
  %975 = select <8 x i1> %convergence.cascade.result145, <8 x i64> %973, <8 x i64> %974
  store <8 x i64> %975, ptr %.slot9, align 64
  store <8 x i1> %convergence.cascade.result145, ptr %current.mask, align 1
  %976 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result145)
  br i1 %976, label %schedule.9, label %scheduler.loop

convergence.cascade147:                           ; preds = %convergence.cascade147, %schedule.13
  %convergence.cascade.flow151 = phi <8 x i1> [ %290, %schedule.13 ], [ %1019, %convergence.cascade147 ]
  %convergence.cascade.depth152 = phi i32 [ 0, %schedule.13 ], [ %1020, %convergence.cascade147 ]
  %977 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow151)
  %978 = load i32, ptr %current.token, align 4
  %979 = icmp ne i32 %978, 0
  %980 = and i1 %977, %979
  %981 = sub i32 %978, 1
  %982 = select i1 %980, i32 %981, i32 0
  %983 = load i8, ptr %frame.active, align 1
  %984 = trunc i32 %982 to i8
  %985 = shl i8 1, %984
  %986 = and i8 %983, %985
  %987 = icmp ne i8 %986, 0
  %988 = load <8 x i32>, ptr %frame.static.id, align 32
  %989 = extractelement <8 x i32> %988, i32 %982
  %convergence.target.pointer153 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %989
  %convergence.dynamic.target154 = load i32, ptr %convergence.target.pointer153, align 4
  %990 = icmp eq i32 %convergence.dynamic.target154, 13
  %991 = and i1 %987, %990
  %992 = and i1 %980, %991
  %993 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %982
  %994 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %982
  %995 = load <8 x i1>, ptr %993, align 1
  %996 = load <8 x i1>, ptr %994, align 1
  %997 = or <8 x i1> %996, %convergence.cascade.flow151
  %998 = load <8 x i1>, ptr %live.mask, align 1
  %999 = and <8 x i1> %995, %998
  %1000 = icmp eq <8 x i1> %997, %999
  %1001 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1000)
  %1002 = and i1 %992, %1001
  %1003 = select i1 %1002, <8 x i1> zeroinitializer, <8 x i1> %997
  %1004 = select i1 %992, <8 x i1> %1003, <8 x i1> %996
  store <8 x i1> %1004, ptr %994, align 1
  %1005 = select i1 %1002, <8 x i1> zeroinitializer, <8 x i1> %995
  store <8 x i1> %1005, ptr %993, align 1
  %1006 = trunc i32 %982 to i8
  %1007 = shl i8 1, %1006
  %1008 = xor i8 %1007, -1
  %1009 = and i8 %983, %1008
  %1010 = select i1 %1002, i8 %1009, i8 %983
  store i8 %1010, ptr %frame.active, align 1
  %.splatinsert155 = insertelement <8 x i1> poison, i1 %992, i64 0
  %.splat156 = shufflevector <8 x i1> %.splatinsert155, <8 x i1> poison, <8 x i32> zeroinitializer
  %1011 = and <8 x i1> %convergence.cascade.flow151, %.splat156
  %1012 = load <8 x i1>, ptr %runnable.mask, align 1
  %1013 = xor <8 x i1> %1011, splat (i1 true)
  %1014 = and <8 x i1> %1012, %1013
  store <8 x i1> %1014, ptr %runnable.mask, align 1
  %.splatinsert157 = insertelement <8 x i1> poison, i1 %1002, i64 0
  %.splat158 = shufflevector <8 x i1> %.splatinsert157, <8 x i1> poison, <8 x i32> zeroinitializer
  %1015 = select <8 x i1> %.splat158, <8 x i1> %997, <8 x i1> zeroinitializer
  %1016 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1017 = extractelement <8 x i32> %1016, i32 %982
  %1018 = select i1 %1002, i32 %1017, i32 %978
  store i32 %1018, ptr %current.token, align 4
  %.splatinsert159 = insertelement <8 x i1> poison, i1 %992, i64 0
  %.splat160 = shufflevector <8 x i1> %.splatinsert159, <8 x i1> poison, <8 x i32> zeroinitializer
  %1019 = select <8 x i1> %.splat160, <8 x i1> %1015, <8 x i1> %convergence.cascade.flow151
  %1020 = add i32 %convergence.cascade.depth152, 1
  %1021 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1019)
  %1022 = icmp ult i32 %1020, 8
  %1023 = and i1 %1021, %1022
  %1024 = and i1 %992, %1023
  %convergence.parent.token161 = load i32, ptr %current.token, align 4
  %convergence.parent.present162 = icmp ne i32 %convergence.parent.token161, 0
  %1025 = and i1 %1024, %convergence.parent.present162
  br i1 %1025, label %convergence.cascade147, label %convergence.cascade.exit148

convergence.cascade.exit148:                      ; preds = %convergence.cascade147, %schedule.13
  %convergence.cascade.result163 = phi <8 x i1> [ %290, %schedule.13 ], [ %1019, %convergence.cascade147 ]
  %1026 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result163)
  br i1 %1026, label %convergence.target.13.ready, label %scheduler.loop

convergence.target.13.ready:                      ; preds = %convergence.cascade.exit148
  %1027 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result163)
  %1028 = bitcast <8 x i1> %convergence.cascade.result163 to i8
  %1029 = call i8 @llvm.cttz.i8(i8 %1028, i1 false)
  %1030 = zext i8 %1029 to i32
  %1031 = select i1 %1027, i32 %1030, i32 0
  %1032 = load <8 x i1>, ptr %live.mask, align 1
  %1033 = xor <8 x i1> %convergence.cascade.result163, splat (i1 true)
  %1034 = and <8 x i1> %1032, %1033
  store <8 x i1> %1034, ptr %live.mask, align 1
  %1035 = load <8 x i1>, ptr %runnable.mask, align 1
  %1036 = xor <8 x i1> %convergence.cascade.result163, splat (i1 true)
  %1037 = and <8 x i1> %1035, %1036
  store <8 x i1> %1037, ptr %runnable.mask, align 1
  %return.active.frames = load i8, ptr %frame.active, align 1
  %return.frames.present = icmp ne i8 %return.active.frames, 0
  br i1 %return.frames.present, label %return.frame.cleanup, label %return.frame.cleanup.done

return.frame.cleanup:                             ; preds = %convergence.target.13.ready
  %1038 = load i8, ptr %frame.active, align 1
  %1039 = and i8 %1038, 1
  %1040 = icmp ne i8 %1039, 0
  %1041 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 0
  %1042 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 0
  %1043 = load <8 x i1>, ptr %1041, align 1
  %1044 = load <8 x i1>, ptr %1042, align 1
  %1045 = and <8 x i1> %1043, %1034
  %1046 = icmp eq <8 x i1> %1044, %1045
  %1047 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1046)
  %1048 = and i1 %1040, %1047
  %.splatinsert164 = insertelement <8 x i1> poison, i1 %1048, i64 0
  %.splat165 = shufflevector <8 x i1> %.splatinsert164, <8 x i1> poison, <8 x i32> zeroinitializer
  %1049 = select <8 x i1> %.splat165, <8 x i1> %1044, <8 x i1> zeroinitializer
  %1050 = select i1 %1048, <8 x i1> zeroinitializer, <8 x i1> %1045
  store <8 x i1> %1050, ptr %1041, align 1
  %1051 = select i1 %1048, <8 x i1> zeroinitializer, <8 x i1> %1044
  store <8 x i1> %1051, ptr %1042, align 1
  %1052 = and i8 %1038, -2
  %1053 = select i1 %1048, i8 %1052, i8 %1038
  store i8 %1053, ptr %frame.active, align 1
  %1054 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1055 = extractelement <8 x i32> %1054, i32 0
  %1056 = load <8 x i32>, ptr %frame.static.id, align 32
  %1057 = extractelement <8 x i32> %1056, i32 0
  %convergence.target.pointer166 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %1057
  %convergence.dynamic.target167 = load i32, ptr %convergence.target.pointer166, align 4
  %1058 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1049)
  %1059 = load i32, ptr %ready.count, align 4
  %1060 = icmp uge i32 %1059, 8
  %1061 = and i1 %1058, %1060
  br i1 %1061, label %ready.overflow.trap168, label %ready.overflow.resume169

return.frame.cleanup.done:                        ; preds = %ready.overflow.resume211, %convergence.target.13.ready
  br label %scheduler.loop

ready.overflow.trap168:                           ; preds = %return.frame.cleanup
  call void @llvm.trap()
  unreachable

ready.overflow.resume169:                         ; preds = %return.frame.cleanup
  %1062 = select i1 %1058, i32 %1059, i32 0
  %1063 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1062
  %1064 = load <8 x i1>, ptr %1063, align 1
  %1065 = select i1 %1058, <8 x i1> %1049, <8 x i1> %1064
  store <8 x i1> %1065, ptr %1063, align 1
  %1066 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1062
  %1067 = load i32, ptr %1066, align 4
  %1068 = select i1 %1058, i32 %convergence.dynamic.target167, i32 %1067
  store i32 %1068, ptr %1066, align 4
  %1069 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1062
  %1070 = load i32, ptr %1069, align 4
  %1071 = select i1 %1058, i32 %1055, i32 %1070
  store i32 %1071, ptr %1069, align 4
  %1072 = add i32 %1059, 1
  %1073 = select i1 %1058, i32 %1072, i32 %1059
  store i32 %1073, ptr %ready.count, align 4
  %1074 = load <8 x i1>, ptr %runnable.mask, align 1
  %1075 = or <8 x i1> %1074, %1049
  store <8 x i1> %1075, ptr %runnable.mask, align 1
  %1076 = load i8, ptr %frame.active, align 1
  %1077 = and i8 %1076, 2
  %1078 = icmp ne i8 %1077, 0
  %1079 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 1
  %1080 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 1
  %1081 = load <8 x i1>, ptr %1079, align 1
  %1082 = load <8 x i1>, ptr %1080, align 1
  %1083 = and <8 x i1> %1081, %1034
  %1084 = icmp eq <8 x i1> %1082, %1083
  %1085 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1084)
  %1086 = and i1 %1078, %1085
  %.splatinsert170 = insertelement <8 x i1> poison, i1 %1086, i64 0
  %.splat171 = shufflevector <8 x i1> %.splatinsert170, <8 x i1> poison, <8 x i32> zeroinitializer
  %1087 = select <8 x i1> %.splat171, <8 x i1> %1082, <8 x i1> zeroinitializer
  %1088 = select i1 %1086, <8 x i1> zeroinitializer, <8 x i1> %1083
  store <8 x i1> %1088, ptr %1079, align 1
  %1089 = select i1 %1086, <8 x i1> zeroinitializer, <8 x i1> %1082
  store <8 x i1> %1089, ptr %1080, align 1
  %1090 = and i8 %1076, -3
  %1091 = select i1 %1086, i8 %1090, i8 %1076
  store i8 %1091, ptr %frame.active, align 1
  %1092 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1093 = extractelement <8 x i32> %1092, i32 1
  %1094 = load <8 x i32>, ptr %frame.static.id, align 32
  %1095 = extractelement <8 x i32> %1094, i32 1
  %convergence.target.pointer172 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %1095
  %convergence.dynamic.target173 = load i32, ptr %convergence.target.pointer172, align 4
  %1096 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1087)
  %1097 = load i32, ptr %ready.count, align 4
  %1098 = icmp uge i32 %1097, 8
  %1099 = and i1 %1096, %1098
  br i1 %1099, label %ready.overflow.trap174, label %ready.overflow.resume175

ready.overflow.trap174:                           ; preds = %ready.overflow.resume169
  call void @llvm.trap()
  unreachable

ready.overflow.resume175:                         ; preds = %ready.overflow.resume169
  %1100 = select i1 %1096, i32 %1097, i32 0
  %1101 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1100
  %1102 = load <8 x i1>, ptr %1101, align 1
  %1103 = select i1 %1096, <8 x i1> %1087, <8 x i1> %1102
  store <8 x i1> %1103, ptr %1101, align 1
  %1104 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1100
  %1105 = load i32, ptr %1104, align 4
  %1106 = select i1 %1096, i32 %convergence.dynamic.target173, i32 %1105
  store i32 %1106, ptr %1104, align 4
  %1107 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1100
  %1108 = load i32, ptr %1107, align 4
  %1109 = select i1 %1096, i32 %1093, i32 %1108
  store i32 %1109, ptr %1107, align 4
  %1110 = add i32 %1097, 1
  %1111 = select i1 %1096, i32 %1110, i32 %1097
  store i32 %1111, ptr %ready.count, align 4
  %1112 = load <8 x i1>, ptr %runnable.mask, align 1
  %1113 = or <8 x i1> %1112, %1087
  store <8 x i1> %1113, ptr %runnable.mask, align 1
  %1114 = load i8, ptr %frame.active, align 1
  %1115 = and i8 %1114, 4
  %1116 = icmp ne i8 %1115, 0
  %1117 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 2
  %1118 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 2
  %1119 = load <8 x i1>, ptr %1117, align 1
  %1120 = load <8 x i1>, ptr %1118, align 1
  %1121 = and <8 x i1> %1119, %1034
  %1122 = icmp eq <8 x i1> %1120, %1121
  %1123 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1122)
  %1124 = and i1 %1116, %1123
  %.splatinsert176 = insertelement <8 x i1> poison, i1 %1124, i64 0
  %.splat177 = shufflevector <8 x i1> %.splatinsert176, <8 x i1> poison, <8 x i32> zeroinitializer
  %1125 = select <8 x i1> %.splat177, <8 x i1> %1120, <8 x i1> zeroinitializer
  %1126 = select i1 %1124, <8 x i1> zeroinitializer, <8 x i1> %1121
  store <8 x i1> %1126, ptr %1117, align 1
  %1127 = select i1 %1124, <8 x i1> zeroinitializer, <8 x i1> %1120
  store <8 x i1> %1127, ptr %1118, align 1
  %1128 = and i8 %1114, -5
  %1129 = select i1 %1124, i8 %1128, i8 %1114
  store i8 %1129, ptr %frame.active, align 1
  %1130 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1131 = extractelement <8 x i32> %1130, i32 2
  %1132 = load <8 x i32>, ptr %frame.static.id, align 32
  %1133 = extractelement <8 x i32> %1132, i32 2
  %convergence.target.pointer178 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %1133
  %convergence.dynamic.target179 = load i32, ptr %convergence.target.pointer178, align 4
  %1134 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1125)
  %1135 = load i32, ptr %ready.count, align 4
  %1136 = icmp uge i32 %1135, 8
  %1137 = and i1 %1134, %1136
  br i1 %1137, label %ready.overflow.trap180, label %ready.overflow.resume181

ready.overflow.trap180:                           ; preds = %ready.overflow.resume175
  call void @llvm.trap()
  unreachable

ready.overflow.resume181:                         ; preds = %ready.overflow.resume175
  %1138 = select i1 %1134, i32 %1135, i32 0
  %1139 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1138
  %1140 = load <8 x i1>, ptr %1139, align 1
  %1141 = select i1 %1134, <8 x i1> %1125, <8 x i1> %1140
  store <8 x i1> %1141, ptr %1139, align 1
  %1142 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1138
  %1143 = load i32, ptr %1142, align 4
  %1144 = select i1 %1134, i32 %convergence.dynamic.target179, i32 %1143
  store i32 %1144, ptr %1142, align 4
  %1145 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1138
  %1146 = load i32, ptr %1145, align 4
  %1147 = select i1 %1134, i32 %1131, i32 %1146
  store i32 %1147, ptr %1145, align 4
  %1148 = add i32 %1135, 1
  %1149 = select i1 %1134, i32 %1148, i32 %1135
  store i32 %1149, ptr %ready.count, align 4
  %1150 = load <8 x i1>, ptr %runnable.mask, align 1
  %1151 = or <8 x i1> %1150, %1125
  store <8 x i1> %1151, ptr %runnable.mask, align 1
  %1152 = load i8, ptr %frame.active, align 1
  %1153 = and i8 %1152, 8
  %1154 = icmp ne i8 %1153, 0
  %1155 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 3
  %1156 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 3
  %1157 = load <8 x i1>, ptr %1155, align 1
  %1158 = load <8 x i1>, ptr %1156, align 1
  %1159 = and <8 x i1> %1157, %1034
  %1160 = icmp eq <8 x i1> %1158, %1159
  %1161 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1160)
  %1162 = and i1 %1154, %1161
  %.splatinsert182 = insertelement <8 x i1> poison, i1 %1162, i64 0
  %.splat183 = shufflevector <8 x i1> %.splatinsert182, <8 x i1> poison, <8 x i32> zeroinitializer
  %1163 = select <8 x i1> %.splat183, <8 x i1> %1158, <8 x i1> zeroinitializer
  %1164 = select i1 %1162, <8 x i1> zeroinitializer, <8 x i1> %1159
  store <8 x i1> %1164, ptr %1155, align 1
  %1165 = select i1 %1162, <8 x i1> zeroinitializer, <8 x i1> %1158
  store <8 x i1> %1165, ptr %1156, align 1
  %1166 = and i8 %1152, -9
  %1167 = select i1 %1162, i8 %1166, i8 %1152
  store i8 %1167, ptr %frame.active, align 1
  %1168 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1169 = extractelement <8 x i32> %1168, i32 3
  %1170 = load <8 x i32>, ptr %frame.static.id, align 32
  %1171 = extractelement <8 x i32> %1170, i32 3
  %convergence.target.pointer184 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %1171
  %convergence.dynamic.target185 = load i32, ptr %convergence.target.pointer184, align 4
  %1172 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1163)
  %1173 = load i32, ptr %ready.count, align 4
  %1174 = icmp uge i32 %1173, 8
  %1175 = and i1 %1172, %1174
  br i1 %1175, label %ready.overflow.trap186, label %ready.overflow.resume187

ready.overflow.trap186:                           ; preds = %ready.overflow.resume181
  call void @llvm.trap()
  unreachable

ready.overflow.resume187:                         ; preds = %ready.overflow.resume181
  %1176 = select i1 %1172, i32 %1173, i32 0
  %1177 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1176
  %1178 = load <8 x i1>, ptr %1177, align 1
  %1179 = select i1 %1172, <8 x i1> %1163, <8 x i1> %1178
  store <8 x i1> %1179, ptr %1177, align 1
  %1180 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1176
  %1181 = load i32, ptr %1180, align 4
  %1182 = select i1 %1172, i32 %convergence.dynamic.target185, i32 %1181
  store i32 %1182, ptr %1180, align 4
  %1183 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1176
  %1184 = load i32, ptr %1183, align 4
  %1185 = select i1 %1172, i32 %1169, i32 %1184
  store i32 %1185, ptr %1183, align 4
  %1186 = add i32 %1173, 1
  %1187 = select i1 %1172, i32 %1186, i32 %1173
  store i32 %1187, ptr %ready.count, align 4
  %1188 = load <8 x i1>, ptr %runnable.mask, align 1
  %1189 = or <8 x i1> %1188, %1163
  store <8 x i1> %1189, ptr %runnable.mask, align 1
  %1190 = load i8, ptr %frame.active, align 1
  %1191 = and i8 %1190, 16
  %1192 = icmp ne i8 %1191, 0
  %1193 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 4
  %1194 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 4
  %1195 = load <8 x i1>, ptr %1193, align 1
  %1196 = load <8 x i1>, ptr %1194, align 1
  %1197 = and <8 x i1> %1195, %1034
  %1198 = icmp eq <8 x i1> %1196, %1197
  %1199 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1198)
  %1200 = and i1 %1192, %1199
  %.splatinsert188 = insertelement <8 x i1> poison, i1 %1200, i64 0
  %.splat189 = shufflevector <8 x i1> %.splatinsert188, <8 x i1> poison, <8 x i32> zeroinitializer
  %1201 = select <8 x i1> %.splat189, <8 x i1> %1196, <8 x i1> zeroinitializer
  %1202 = select i1 %1200, <8 x i1> zeroinitializer, <8 x i1> %1197
  store <8 x i1> %1202, ptr %1193, align 1
  %1203 = select i1 %1200, <8 x i1> zeroinitializer, <8 x i1> %1196
  store <8 x i1> %1203, ptr %1194, align 1
  %1204 = and i8 %1190, -17
  %1205 = select i1 %1200, i8 %1204, i8 %1190
  store i8 %1205, ptr %frame.active, align 1
  %1206 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1207 = extractelement <8 x i32> %1206, i32 4
  %1208 = load <8 x i32>, ptr %frame.static.id, align 32
  %1209 = extractelement <8 x i32> %1208, i32 4
  %convergence.target.pointer190 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %1209
  %convergence.dynamic.target191 = load i32, ptr %convergence.target.pointer190, align 4
  %1210 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1201)
  %1211 = load i32, ptr %ready.count, align 4
  %1212 = icmp uge i32 %1211, 8
  %1213 = and i1 %1210, %1212
  br i1 %1213, label %ready.overflow.trap192, label %ready.overflow.resume193

ready.overflow.trap192:                           ; preds = %ready.overflow.resume187
  call void @llvm.trap()
  unreachable

ready.overflow.resume193:                         ; preds = %ready.overflow.resume187
  %1214 = select i1 %1210, i32 %1211, i32 0
  %1215 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1214
  %1216 = load <8 x i1>, ptr %1215, align 1
  %1217 = select i1 %1210, <8 x i1> %1201, <8 x i1> %1216
  store <8 x i1> %1217, ptr %1215, align 1
  %1218 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1214
  %1219 = load i32, ptr %1218, align 4
  %1220 = select i1 %1210, i32 %convergence.dynamic.target191, i32 %1219
  store i32 %1220, ptr %1218, align 4
  %1221 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1214
  %1222 = load i32, ptr %1221, align 4
  %1223 = select i1 %1210, i32 %1207, i32 %1222
  store i32 %1223, ptr %1221, align 4
  %1224 = add i32 %1211, 1
  %1225 = select i1 %1210, i32 %1224, i32 %1211
  store i32 %1225, ptr %ready.count, align 4
  %1226 = load <8 x i1>, ptr %runnable.mask, align 1
  %1227 = or <8 x i1> %1226, %1201
  store <8 x i1> %1227, ptr %runnable.mask, align 1
  %1228 = load i8, ptr %frame.active, align 1
  %1229 = and i8 %1228, 32
  %1230 = icmp ne i8 %1229, 0
  %1231 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 5
  %1232 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 5
  %1233 = load <8 x i1>, ptr %1231, align 1
  %1234 = load <8 x i1>, ptr %1232, align 1
  %1235 = and <8 x i1> %1233, %1034
  %1236 = icmp eq <8 x i1> %1234, %1235
  %1237 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1236)
  %1238 = and i1 %1230, %1237
  %.splatinsert194 = insertelement <8 x i1> poison, i1 %1238, i64 0
  %.splat195 = shufflevector <8 x i1> %.splatinsert194, <8 x i1> poison, <8 x i32> zeroinitializer
  %1239 = select <8 x i1> %.splat195, <8 x i1> %1234, <8 x i1> zeroinitializer
  %1240 = select i1 %1238, <8 x i1> zeroinitializer, <8 x i1> %1235
  store <8 x i1> %1240, ptr %1231, align 1
  %1241 = select i1 %1238, <8 x i1> zeroinitializer, <8 x i1> %1234
  store <8 x i1> %1241, ptr %1232, align 1
  %1242 = and i8 %1228, -33
  %1243 = select i1 %1238, i8 %1242, i8 %1228
  store i8 %1243, ptr %frame.active, align 1
  %1244 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1245 = extractelement <8 x i32> %1244, i32 5
  %1246 = load <8 x i32>, ptr %frame.static.id, align 32
  %1247 = extractelement <8 x i32> %1246, i32 5
  %convergence.target.pointer196 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %1247
  %convergence.dynamic.target197 = load i32, ptr %convergence.target.pointer196, align 4
  %1248 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1239)
  %1249 = load i32, ptr %ready.count, align 4
  %1250 = icmp uge i32 %1249, 8
  %1251 = and i1 %1248, %1250
  br i1 %1251, label %ready.overflow.trap198, label %ready.overflow.resume199

ready.overflow.trap198:                           ; preds = %ready.overflow.resume193
  call void @llvm.trap()
  unreachable

ready.overflow.resume199:                         ; preds = %ready.overflow.resume193
  %1252 = select i1 %1248, i32 %1249, i32 0
  %1253 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1252
  %1254 = load <8 x i1>, ptr %1253, align 1
  %1255 = select i1 %1248, <8 x i1> %1239, <8 x i1> %1254
  store <8 x i1> %1255, ptr %1253, align 1
  %1256 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1252
  %1257 = load i32, ptr %1256, align 4
  %1258 = select i1 %1248, i32 %convergence.dynamic.target197, i32 %1257
  store i32 %1258, ptr %1256, align 4
  %1259 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1252
  %1260 = load i32, ptr %1259, align 4
  %1261 = select i1 %1248, i32 %1245, i32 %1260
  store i32 %1261, ptr %1259, align 4
  %1262 = add i32 %1249, 1
  %1263 = select i1 %1248, i32 %1262, i32 %1249
  store i32 %1263, ptr %ready.count, align 4
  %1264 = load <8 x i1>, ptr %runnable.mask, align 1
  %1265 = or <8 x i1> %1264, %1239
  store <8 x i1> %1265, ptr %runnable.mask, align 1
  %1266 = load i8, ptr %frame.active, align 1
  %1267 = and i8 %1266, 64
  %1268 = icmp ne i8 %1267, 0
  %1269 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 6
  %1270 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 6
  %1271 = load <8 x i1>, ptr %1269, align 1
  %1272 = load <8 x i1>, ptr %1270, align 1
  %1273 = and <8 x i1> %1271, %1034
  %1274 = icmp eq <8 x i1> %1272, %1273
  %1275 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1274)
  %1276 = and i1 %1268, %1275
  %.splatinsert200 = insertelement <8 x i1> poison, i1 %1276, i64 0
  %.splat201 = shufflevector <8 x i1> %.splatinsert200, <8 x i1> poison, <8 x i32> zeroinitializer
  %1277 = select <8 x i1> %.splat201, <8 x i1> %1272, <8 x i1> zeroinitializer
  %1278 = select i1 %1276, <8 x i1> zeroinitializer, <8 x i1> %1273
  store <8 x i1> %1278, ptr %1269, align 1
  %1279 = select i1 %1276, <8 x i1> zeroinitializer, <8 x i1> %1272
  store <8 x i1> %1279, ptr %1270, align 1
  %1280 = and i8 %1266, -65
  %1281 = select i1 %1276, i8 %1280, i8 %1266
  store i8 %1281, ptr %frame.active, align 1
  %1282 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1283 = extractelement <8 x i32> %1282, i32 6
  %1284 = load <8 x i32>, ptr %frame.static.id, align 32
  %1285 = extractelement <8 x i32> %1284, i32 6
  %convergence.target.pointer202 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %1285
  %convergence.dynamic.target203 = load i32, ptr %convergence.target.pointer202, align 4
  %1286 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1277)
  %1287 = load i32, ptr %ready.count, align 4
  %1288 = icmp uge i32 %1287, 8
  %1289 = and i1 %1286, %1288
  br i1 %1289, label %ready.overflow.trap204, label %ready.overflow.resume205

ready.overflow.trap204:                           ; preds = %ready.overflow.resume199
  call void @llvm.trap()
  unreachable

ready.overflow.resume205:                         ; preds = %ready.overflow.resume199
  %1290 = select i1 %1286, i32 %1287, i32 0
  %1291 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1290
  %1292 = load <8 x i1>, ptr %1291, align 1
  %1293 = select i1 %1286, <8 x i1> %1277, <8 x i1> %1292
  store <8 x i1> %1293, ptr %1291, align 1
  %1294 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1290
  %1295 = load i32, ptr %1294, align 4
  %1296 = select i1 %1286, i32 %convergence.dynamic.target203, i32 %1295
  store i32 %1296, ptr %1294, align 4
  %1297 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1290
  %1298 = load i32, ptr %1297, align 4
  %1299 = select i1 %1286, i32 %1283, i32 %1298
  store i32 %1299, ptr %1297, align 4
  %1300 = add i32 %1287, 1
  %1301 = select i1 %1286, i32 %1300, i32 %1287
  store i32 %1301, ptr %ready.count, align 4
  %1302 = load <8 x i1>, ptr %runnable.mask, align 1
  %1303 = or <8 x i1> %1302, %1277
  store <8 x i1> %1303, ptr %runnable.mask, align 1
  %1304 = load i8, ptr %frame.active, align 1
  %1305 = and i8 %1304, -128
  %1306 = icmp ne i8 %1305, 0
  %1307 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 7
  %1308 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 7
  %1309 = load <8 x i1>, ptr %1307, align 1
  %1310 = load <8 x i1>, ptr %1308, align 1
  %1311 = and <8 x i1> %1309, %1034
  %1312 = icmp eq <8 x i1> %1310, %1311
  %1313 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1312)
  %1314 = and i1 %1306, %1313
  %.splatinsert206 = insertelement <8 x i1> poison, i1 %1314, i64 0
  %.splat207 = shufflevector <8 x i1> %.splatinsert206, <8 x i1> poison, <8 x i32> zeroinitializer
  %1315 = select <8 x i1> %.splat207, <8 x i1> %1310, <8 x i1> zeroinitializer
  %1316 = select i1 %1314, <8 x i1> zeroinitializer, <8 x i1> %1311
  store <8 x i1> %1316, ptr %1307, align 1
  %1317 = select i1 %1314, <8 x i1> zeroinitializer, <8 x i1> %1310
  store <8 x i1> %1317, ptr %1308, align 1
  %1318 = and i8 %1304, 127
  %1319 = select i1 %1314, i8 %1318, i8 %1304
  store i8 %1319, ptr %frame.active, align 1
  %1320 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1321 = extractelement <8 x i32> %1320, i32 7
  %1322 = load <8 x i32>, ptr %frame.static.id, align 32
  %1323 = extractelement <8 x i32> %1322, i32 7
  %convergence.target.pointer208 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %1323
  %convergence.dynamic.target209 = load i32, ptr %convergence.target.pointer208, align 4
  %1324 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1315)
  %1325 = load i32, ptr %ready.count, align 4
  %1326 = icmp uge i32 %1325, 8
  %1327 = and i1 %1324, %1326
  br i1 %1327, label %ready.overflow.trap210, label %ready.overflow.resume211

ready.overflow.trap210:                           ; preds = %ready.overflow.resume205
  call void @llvm.trap()
  unreachable

ready.overflow.resume211:                         ; preds = %ready.overflow.resume205
  %1328 = select i1 %1324, i32 %1325, i32 0
  %1329 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1328
  %1330 = load <8 x i1>, ptr %1329, align 1
  %1331 = select i1 %1324, <8 x i1> %1315, <8 x i1> %1330
  store <8 x i1> %1331, ptr %1329, align 1
  %1332 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1328
  %1333 = load i32, ptr %1332, align 4
  %1334 = select i1 %1324, i32 %convergence.dynamic.target209, i32 %1333
  store i32 %1334, ptr %1332, align 4
  %1335 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1328
  %1336 = load i32, ptr %1335, align 4
  %1337 = select i1 %1324, i32 %1321, i32 %1336
  store i32 %1337, ptr %1335, align 4
  %1338 = add i32 %1325, 1
  %1339 = select i1 %1324, i32 %1338, i32 %1325
  store i32 %1339, ptr %ready.count, align 4
  %1340 = load <8 x i1>, ptr %runnable.mask, align 1
  %1341 = or <8 x i1> %1340, %1315
  store <8 x i1> %1341, ptr %runnable.mask, align 1
  br label %return.frame.cleanup.done
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.and.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #3

define dso_local void @tile_transpose.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 64
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 64
  %3 = sub i64 64, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 8
  %8 = icmp uge i64 %packet.range.remaining, 64
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @tile_transpose(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @tile_transpose(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @tile_transpose(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @tile_transpose(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index3 = add i32 %base.thread.index, 32
  store i32 %packet.thread.index3, ptr %thread.index.address, align 4
  call void @tile_transpose(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index4 = add i32 %base.thread.index, 40
  store i32 %packet.thread.index4, ptr %thread.index.address, align 4
  call void @tile_transpose(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index5 = add i32 %base.thread.index, 48
  store i32 %packet.thread.index5, ptr %thread.index.address, align 4
  call void @tile_transpose(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index6 = add i32 %base.thread.index, 56
  store i32 %packet.thread.index6, ptr %thread.index.address, align 4
  call void @tile_transpose(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @tile_transpose(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @tile_transpose(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(write) }

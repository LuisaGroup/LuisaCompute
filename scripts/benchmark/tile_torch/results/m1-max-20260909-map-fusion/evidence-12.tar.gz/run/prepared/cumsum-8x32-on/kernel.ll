; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @tile_inclusive_scan(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [128 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [4096 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local4 = alloca [4096 x i8], align 4
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local7 = alloca [4096 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local10 = alloca [4096 x i8], align 4
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %8 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %9 = insertvalue { <8 x ptr>, <8 x i64> } %8, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local13 = alloca [4096 x i8], align 4
  %.splatinsert14 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local13, i64 0
  %.splat15 = shufflevector <8 x ptr> %.splatinsert14, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat15, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local16 = alloca [4096 x i8], align 4
  %.splatinsert17 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local16, i64 0
  %.splat18 = shufflevector <8 x ptr> %.splatinsert17, <8 x ptr> poison, <8 x i32> zeroinitializer
  %12 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat18, 0
  %13 = insertvalue { <8 x ptr>, <8 x i64> } %12, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill19 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill19, align 4
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.slot20 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot20, align 32
  %.slot21 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot21, align 32
  %.slot22 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot22, align 32
  %.slot23 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot23, align 32
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.spill24 = alloca i64, align 8
  store i64 0, ptr %.spill24, align 4
  %tile_snapshot.spill25 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill25, align 64
  %.slot26 = alloca i64, align 8
  store i64 0, ptr %.slot26, align 4
  %tile_snapshot.spill27 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill27, align 64
  %.slot28 = alloca i64, align 8
  store i64 0, ptr %.slot28, align 4
  %.spill29 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill29, align 32
  %.spill30 = alloca i1, align 1
  store i1 false, ptr %.spill30, align 1
  %.spill31 = alloca i64, align 8
  store i64 0, ptr %.spill31, align 4
  %.slot32 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot32, align 32
  %tile_snapshot.spill33 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill33, align 64
  %.slot34 = alloca i64, align 8
  store i64 0, ptr %.slot34, align 4
  %.spill35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill35, align 32
  %.spill36 = alloca i1, align 1
  store i1 false, ptr %.spill36, align 1
  %.spill37 = alloca i64, align 8
  store i64 0, ptr %.spill37, align 4
  %.slot38 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot38, align 32
  %tile_snapshot.spill39 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill39, align 64
  %.slot40 = alloca i64, align 8
  store i64 0, ptr %.slot40, align 4
  %.spill41 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill41, align 32
  %.spill42 = alloca i1, align 1
  store i1 false, ptr %.spill42, align 1
  %.spill43 = alloca i64, align 8
  store i64 0, ptr %.spill43, align 4
  %.slot44 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot44, align 32
  %tile_snapshot.spill45 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill45, align 64
  %.slot46 = alloca i64, align 8
  store i64 0, ptr %.slot46, align 4
  %.spill47 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill47, align 32
  %.spill48 = alloca i1, align 1
  store i1 false, ptr %.spill48, align 1
  %.spill49 = alloca i64, align 8
  store i64 0, ptr %.spill49, align 4
  %.slot50 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot50, align 32
  %tile_snapshot.spill51 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill51, align 64
  %.slot52 = alloca i64, align 8
  store i64 0, ptr %.slot52, align 4
  %.spill53 = alloca i64, align 8
  store i64 0, ptr %.spill53, align 4
  %.spill54 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill54, align 32
  %.spill55 = alloca i1, align 1
  store i1 false, ptr %.spill55, align 1
  %.spill56 = alloca i64, align 8
  store i64 0, ptr %.spill56, align 4
  %.slot57 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot57, align 32
  %.slot58 = alloca i64, align 8
  store i64 0, ptr %.slot58, align 4
  %14 = getelementptr i8, ptr %argument_buffer, i64 0
  %15 = load ptr, ptr %14, align 16
  %16 = getelementptr i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = insertvalue { ptr, i64 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i64 } %18, i64 %17, 1
  %20 = getelementptr i8, ptr %argument_buffer, i64 16
  %21 = load ptr, ptr %20, align 16
  %22 = getelementptr i8, ptr %20, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = insertvalue { ptr, i64 } poison, ptr %21, 0
  %25 = insertvalue { ptr, i64 } %24, i64 %23, 1
  %26 = load i32, ptr %launch_config, align 4
  %27 = getelementptr i8, ptr %launch_config, i64 12
  %28 = load i32, ptr %27, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 4
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 16
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 8
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 20
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 36
  %38 = load i32, ptr %37, align 4
  %.splatinsert59 = insertelement <8 x i32> poison, i32 %38, i64 0
  %.splat60 = shufflevector <8 x i32> %.splatinsert59, <8 x i32> poison, <8 x i32> zeroinitializer
  %39 = add <8 x i32> %.splat60, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %40 = mul i32 %26, 32
  %.splatinsert61 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat62 = shufflevector <8 x i32> %.splatinsert61, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat62, %39
  %42 = mul i32 %30, 1
  %.splatinsert63 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat64 = shufflevector <8 x i32> %.splatinsert63, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat64, zeroinitializer
  %44 = mul i32 %34, 1
  %.splatinsert65 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat66 = shufflevector <8 x i32> %.splatinsert65, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat66, zeroinitializer
  %46 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %41, 0
  %47 = insertvalue [3 x <8 x i32>] %46, <8 x i32> %43, 1
  %48 = insertvalue [3 x <8 x i32>] %47, <8 x i32> %45, 2
  %.splatinsert67 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat68 = shufflevector <8 x i32> %.splatinsert67, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat68
  %50 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  br i1 %50, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %51 = extractvalue [3 x <8 x i32>] %48, 0
  %52 = zext <8 x i32> %51 to <8 x i64>
  %53 = select <8 x i1> %49, <8 x i64> %52, <8 x i64> zeroinitializer
  %54 = select <8 x i1> %49, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %55 = sdiv <8 x i64> %53, %54
  %56 = mul <8 x i64> %55, splat (i64 4)
  %57 = load <8 x i64>, ptr %.spill, align 64
  %58 = select <8 x i1> %49, <8 x i64> %56, <8 x i64> %57
  store <8 x i64> %58, ptr %.spill, align 64
  store float 0.000000e+00, ptr %.spill19, align 4
  store i64 0, ptr %.slot, align 4
  %59 = load <8 x float>, ptr %.slot20, align 32
  %60 = select <8 x i1> %49, <8 x float> zeroinitializer, <8 x float> %59
  store <8 x float> %60, ptr %.slot20, align 32
  %61 = load <8 x float>, ptr %.slot21, align 32
  %62 = select <8 x i1> %49, <8 x float> zeroinitializer, <8 x float> %61
  store <8 x float> %62, ptr %.slot21, align 32
  %63 = load <8 x float>, ptr %.slot22, align 32
  %64 = select <8 x i1> %49, <8 x float> zeroinitializer, <8 x float> %63
  store <8 x float> %64, ptr %.slot22, align 32
  %65 = load <8 x float>, ptr %.slot23, align 32
  %66 = select <8 x i1> %49, <8 x float> zeroinitializer, <8 x float> %65
  store <8 x float> %66, ptr %.slot23, align 32
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.33, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %67 = icmp slt i64 %.state, 1
  br i1 %67, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %68 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %69 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %68, 0
  %71 = select <8 x i1> %49, <8 x ptr> %69, <8 x ptr> %70
  %72 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %73 = extractvalue { <8 x ptr>, <8 x i64> } %68, 1
  %74 = select <8 x i1> %49, <8 x i64> %72, <8 x i64> %73
  %75 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %71, 0
  %76 = insertvalue { <8 x ptr>, <8 x i64> } %75, <8 x i64> %74, 1
  store { <8 x ptr>, <8 x i64> } %76, ptr %tile_snapshot.spill, align 64
  %77 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %78 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %79 = add <8 x i64> %78, zeroinitializer
  %80 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %77, 0
  %81 = insertvalue { <8 x ptr>, <8 x i64> } %80, <8 x i64> %79, 1
  %.state69 = load <8 x float>, ptr %.slot20, align 32
  %82 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %83 = extractvalue { <8 x ptr>, <8 x i64> } %81, 1
  %84 = extractelement <8 x ptr> %82, i32 0
  %85 = extractelement <8 x i64> %83, i32 0
  %86 = sub i64 %85, 0
  %87 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %88 = select i1 %87, i64 %86, i64 0
  %private.contiguous.address = getelementptr i8, ptr %84, i64 %88
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %89 = select <8 x i1> %49, <8 x float> %.state69, <8 x float> %private.contiguous.preserve
  store <8 x float> %89, ptr %private.contiguous.address, align 4
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %91 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %92 = add <8 x i64> %91, splat (i64 32)
  %93 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %90, 0
  %94 = insertvalue { <8 x ptr>, <8 x i64> } %93, <8 x i64> %92, 1
  %.state70 = load <8 x float>, ptr %.slot21, align 32
  %95 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %96 = extractvalue { <8 x ptr>, <8 x i64> } %94, 1
  %97 = extractelement <8 x ptr> %95, i32 0
  %98 = extractelement <8 x i64> %96, i32 0
  %99 = sub i64 %98, 0
  %100 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %101 = select i1 %100, i64 %99, i64 0
  %private.contiguous.address71 = getelementptr i8, ptr %97, i64 %101
  %private.contiguous.preserve72 = load <8 x float>, ptr %private.contiguous.address71, align 4
  %102 = select <8 x i1> %49, <8 x float> %.state70, <8 x float> %private.contiguous.preserve72
  store <8 x float> %102, ptr %private.contiguous.address71, align 4
  %103 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %104 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %105 = add <8 x i64> %104, splat (i64 64)
  %106 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %103, 0
  %107 = insertvalue { <8 x ptr>, <8 x i64> } %106, <8 x i64> %105, 1
  %.state73 = load <8 x float>, ptr %.slot22, align 32
  %108 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %107, 1
  %110 = extractelement <8 x ptr> %108, i32 0
  %111 = extractelement <8 x i64> %109, i32 0
  %112 = sub i64 %111, 0
  %113 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %114 = select i1 %113, i64 %112, i64 0
  %private.contiguous.address74 = getelementptr i8, ptr %110, i64 %114
  %private.contiguous.preserve75 = load <8 x float>, ptr %private.contiguous.address74, align 4
  %115 = select <8 x i1> %49, <8 x float> %.state73, <8 x float> %private.contiguous.preserve75
  store <8 x float> %115, ptr %private.contiguous.address74, align 4
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %117 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %118 = add <8 x i64> %117, splat (i64 96)
  %119 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %116, 0
  %120 = insertvalue { <8 x ptr>, <8 x i64> } %119, <8 x i64> %118, 1
  %.state76 = load <8 x float>, ptr %.slot23, align 32
  %121 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %120, 1
  %123 = extractelement <8 x ptr> %121, i32 0
  %124 = extractelement <8 x i64> %122, i32 0
  %125 = sub i64 %124, 0
  %126 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %127 = select i1 %126, i64 %125, i64 0
  %private.contiguous.address77 = getelementptr i8, ptr %123, i64 %127
  %private.contiguous.preserve78 = load <8 x float>, ptr %private.contiguous.address77, align 4
  %128 = select <8 x i1> %49, <8 x float> %.state76, <8 x float> %private.contiguous.preserve78
  store <8 x float> %128, ptr %private.contiguous.address77, align 4
  store i64 0, ptr %.spill24, align 4
  %129 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %131 = extractvalue { <8 x ptr>, <8 x i64> } %129, 0
  %132 = select <8 x i1> %49, <8 x ptr> %130, <8 x ptr> %131
  %133 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %129, 1
  %135 = select <8 x i1> %49, <8 x i64> %133, <8 x i64> %134
  %136 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %132, 0
  %137 = insertvalue { <8 x ptr>, <8 x i64> } %136, <8 x i64> %135, 1
  store { <8 x ptr>, <8 x i64> } %137, ptr %tile_snapshot.spill25, align 64
  store i64 0, ptr %.slot26, align 4
  br label %direct.schedule.3

direct.schedule.3:                                ; preds = %direct.schedule.4, %direct.schedule.2
  %.state79 = load i64, ptr %.slot26, align 4
  %138 = icmp slt i64 %.state79, 128
  br i1 %138, label %direct.true80, label %direct.false81

direct.schedule.4:                                ; preds = %direct.true80
  %.state82 = load i64, ptr %.slot26, align 4
  %139 = srem i64 %.state82, 32
  %.state83 = load i64, ptr %.slot26, align 4
  %140 = sdiv i64 %.state83, 32
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %.splatinsert84 = insertelement <8 x i64> poison, i64 %140, i64 0
  %.splat85 = shufflevector <8 x i64> %.splatinsert84, <8 x i64> poison, <8 x i32> zeroinitializer
  %141 = add <8 x i64> %.spill.load, %.splat85
  %142 = add <8 x i64> zeroinitializer, %141
  %.spill.load86 = load i64, ptr %.spill24, align 4
  %143 = add i64 %.spill.load86, %139
  %144 = mul <8 x i64> %142, splat (i64 32)
  %.splatinsert87 = insertelement <8 x i64> poison, i64 %143, i64 0
  %.splat88 = shufflevector <8 x i64> %.splatinsert87, <8 x i64> poison, <8 x i32> zeroinitializer
  %145 = add <8 x i64> %144, %.splat88
  %146 = extractvalue { ptr, i64 } %19, 0
  %147 = mul <8 x i64> %145, splat (i64 4)
  %148 = getelementptr i8, ptr %146, <8 x i64> %147
  %149 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %148, i32 1, <8 x i1> %49, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %151 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state89 = load i64, ptr %.slot26, align 4
  %.splatinsert90 = insertelement <8 x i64> poison, i64 %.state89, i64 0
  %.splat91 = shufflevector <8 x i64> %.splatinsert90, <8 x i64> poison, <8 x i32> zeroinitializer
  %152 = mul <8 x i64> %.splat91, splat (i64 32)
  %153 = add <8 x i64> %151, %152
  %154 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %150, 0
  %155 = insertvalue { <8 x ptr>, <8 x i64> } %154, <8 x i64> %153, 1
  %156 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %157 = extractvalue { <8 x ptr>, <8 x i64> } %155, 1
  %158 = extractelement <8 x ptr> %156, i32 0
  %159 = extractelement <8 x i64> %157, i32 0
  %160 = sub i64 %159, 0
  %161 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %162 = select i1 %161, i64 %160, i64 0
  %private.contiguous.address92 = getelementptr i8, ptr %158, i64 %162
  %private.contiguous.preserve93 = load <8 x float>, ptr %private.contiguous.address92, align 4
  %163 = select <8 x i1> %49, <8 x float> %149, <8 x float> %private.contiguous.preserve93
  store <8 x float> %163, ptr %private.contiguous.address92, align 4
  %.state94 = load i64, ptr %.slot26, align 4
  %164 = add i64 %.state94, 1
  store i64 %164, ptr %.slot26, align 4
  br label %direct.schedule.3

direct.schedule.5:                                ; preds = %direct.false81
  %165 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %165, 0
  %168 = select <8 x i1> %49, <8 x ptr> %166, <8 x ptr> %167
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %165, 1
  %171 = select <8 x i1> %49, <8 x i64> %169, <8 x i64> %170
  %172 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %168, 0
  %173 = insertvalue { <8 x ptr>, <8 x i64> } %172, <8 x i64> %171, 1
  store { <8 x ptr>, <8 x i64> } %173, ptr %tile_snapshot.spill27, align 64
  store i64 0, ptr %.slot28, align 4
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.9, %direct.schedule.5
  %.state95 = load i64, ptr %.slot28, align 4
  %174 = icmp slt i64 %.state95, 128
  br i1 %174, label %direct.true96, label %direct.false97

direct.schedule.7:                                ; preds = %direct.true96
  %.state98 = load i64, ptr %.slot28, align 4
  %175 = srem i64 %.state98, 32
  %.state99 = load i64, ptr %.slot28, align 4
  %176 = sdiv i64 %.state99, 32
  %177 = add i64 0, %176
  %178 = mul i64 %177, 32
  %179 = add i64 %178, %175
  %tile_snapshot.spill.load100 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %180 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load100, 0
  %181 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load100, 1
  %.splatinsert101 = insertelement <8 x i64> poison, i64 %179, i64 0
  %.splat102 = shufflevector <8 x i64> %.splatinsert101, <8 x i64> poison, <8 x i32> zeroinitializer
  %182 = mul <8 x i64> %.splat102, splat (i64 32)
  %183 = add <8 x i64> %181, %182
  %184 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %180, 0
  %185 = insertvalue { <8 x ptr>, <8 x i64> } %184, <8 x i64> %183, 1
  %186 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %185, 1
  %188 = extractelement <8 x ptr> %186, i32 0
  %189 = extractelement <8 x i64> %187, i32 0
  %190 = sub i64 %189, 0
  %191 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %192 = select i1 %191, i64 %190, i64 0
  %private.contiguous.address103 = getelementptr i8, ptr %188, i64 %192
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address103, align 4
  %193 = select <8 x i1> %49, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %194 = load <8 x float>, ptr %.spill29, align 32
  %195 = select <8 x i1> %49, <8 x float> %193, <8 x float> %194
  store <8 x float> %195, ptr %.spill29, align 32
  %196 = srem i64 %179, 32
  %197 = sdiv i64 %179, 32
  %.spill.load104 = load i64, ptr %.spill24, align 4
  %198 = add i64 %.spill.load104, %196
  %.spill.load105 = load i64, ptr %.spill24, align 4
  %199 = add i64 %.spill.load105, %198
  %200 = sub i64 %199, 1
  %201 = icmp sge i64 %200, 0
  %202 = icmp slt i64 %200, 32
  %203 = and i1 %201, %202
  store i1 %203, ptr %.spill30, align 1
  %204 = add i64 0, %197
  %205 = mul i64 %204, 32
  %206 = add i64 %205, %200
  store i64 %206, ptr %.spill31, align 4
  %207 = icmp sge i64 %206, 0
  %208 = icmp slt i64 %206, 128
  %209 = and i1 %207, %208
  br i1 %209, label %direct.true106, label %direct.false107

direct.schedule.8:                                ; preds = %direct.true106
  %tile_snapshot.spill.load108 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %210 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load108, 0
  %211 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load108, 1
  %.spill.load109 = load i64, ptr %.spill31, align 4
  %.splatinsert110 = insertelement <8 x i64> poison, i64 %.spill.load109, i64 0
  %.splat111 = shufflevector <8 x i64> %.splatinsert110, <8 x i64> poison, <8 x i32> zeroinitializer
  %212 = mul <8 x i64> %.splat111, splat (i64 32)
  %213 = add <8 x i64> %211, %212
  %214 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %210, 0
  %215 = insertvalue { <8 x ptr>, <8 x i64> } %214, <8 x i64> %213, 1
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %217 = extractvalue { <8 x ptr>, <8 x i64> } %215, 1
  %218 = extractelement <8 x ptr> %216, i32 0
  %219 = extractelement <8 x i64> %217, i32 0
  %220 = sub i64 %219, 0
  %221 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %222 = select i1 %221, i64 %220, i64 0
  %private.contiguous.address112 = getelementptr i8, ptr %218, i64 %222
  %private.contiguous.load113 = load <8 x float>, ptr %private.contiguous.address112, align 4
  %223 = select <8 x i1> %49, <8 x float> %private.contiguous.load113, <8 x float> zeroinitializer
  %224 = load <8 x float>, ptr %.slot32, align 32
  %225 = select <8 x i1> %49, <8 x float> %223, <8 x float> %224
  store <8 x float> %225, ptr %.slot32, align 32
  br label %direct.schedule.9

direct.schedule.9:                                ; preds = %direct.schedule.8, %direct.false107
  %.spill.load114 = load float, ptr %.spill19, align 4
  %.splatinsert115 = insertelement <8 x float> poison, float %.spill.load114, i64 0
  %.splat116 = shufflevector <8 x float> %.splatinsert115, <8 x float> poison, <8 x i32> zeroinitializer
  %.state117 = load <8 x float>, ptr %.slot32, align 32
  %.spill.load118 = load i1, ptr %.spill30, align 1
  %.splatinsert119 = insertelement <8 x i1> poison, i1 %.spill.load118, i64 0
  %.splat120 = shufflevector <8 x i1> %.splatinsert119, <8 x i1> poison, <8 x i32> zeroinitializer
  %226 = select <8 x i1> %.splat120, <8 x float> %.state117, <8 x float> %.splat116
  %.spill.load121 = load <8 x float>, ptr %.spill29, align 32
  %227 = fadd <8 x float> %.spill.load121, %226
  %tile_snapshot.spill.load122 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 0
  %229 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 1
  %.state123 = load i64, ptr %.slot28, align 4
  %.splatinsert124 = insertelement <8 x i64> poison, i64 %.state123, i64 0
  %.splat125 = shufflevector <8 x i64> %.splatinsert124, <8 x i64> poison, <8 x i32> zeroinitializer
  %230 = mul <8 x i64> %.splat125, splat (i64 32)
  %231 = add <8 x i64> %229, %230
  %232 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %228, 0
  %233 = insertvalue { <8 x ptr>, <8 x i64> } %232, <8 x i64> %231, 1
  %234 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %235 = extractvalue { <8 x ptr>, <8 x i64> } %233, 1
  %236 = extractelement <8 x ptr> %234, i32 0
  %237 = extractelement <8 x i64> %235, i32 0
  %238 = sub i64 %237, 0
  %239 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %240 = select i1 %239, i64 %238, i64 0
  %private.contiguous.address126 = getelementptr i8, ptr %236, i64 %240
  %private.contiguous.preserve127 = load <8 x float>, ptr %private.contiguous.address126, align 4
  %241 = select <8 x i1> %49, <8 x float> %227, <8 x float> %private.contiguous.preserve127
  store <8 x float> %241, ptr %private.contiguous.address126, align 4
  %.state128 = load i64, ptr %.slot28, align 4
  %242 = add i64 %.state128, 1
  store i64 %242, ptr %.slot28, align 4
  br label %direct.schedule.6

direct.schedule.10:                               ; preds = %direct.false97
  %243 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill33, align 64
  %244 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %245 = extractvalue { <8 x ptr>, <8 x i64> } %243, 0
  %246 = select <8 x i1> %49, <8 x ptr> %244, <8 x ptr> %245
  %247 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %243, 1
  %249 = select <8 x i1> %49, <8 x i64> %247, <8 x i64> %248
  %250 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %246, 0
  %251 = insertvalue { <8 x ptr>, <8 x i64> } %250, <8 x i64> %249, 1
  store { <8 x ptr>, <8 x i64> } %251, ptr %tile_snapshot.spill33, align 64
  store i64 0, ptr %.slot34, align 4
  br label %direct.schedule.11

direct.schedule.11:                               ; preds = %direct.schedule.14, %direct.schedule.10
  %.state129 = load i64, ptr %.slot34, align 4
  %252 = icmp slt i64 %.state129, 128
  br i1 %252, label %direct.true130, label %direct.false131

direct.schedule.12:                               ; preds = %direct.true130
  %.state132 = load i64, ptr %.slot34, align 4
  %253 = srem i64 %.state132, 32
  %.state133 = load i64, ptr %.slot34, align 4
  %254 = sdiv i64 %.state133, 32
  %255 = add i64 0, %254
  %256 = mul i64 %255, 32
  %257 = add i64 %256, %253
  %tile_snapshot.spill.load134 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %258 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load134, 0
  %259 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load134, 1
  %.splatinsert135 = insertelement <8 x i64> poison, i64 %257, i64 0
  %.splat136 = shufflevector <8 x i64> %.splatinsert135, <8 x i64> poison, <8 x i32> zeroinitializer
  %260 = mul <8 x i64> %.splat136, splat (i64 32)
  %261 = add <8 x i64> %259, %260
  %262 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %258, 0
  %263 = insertvalue { <8 x ptr>, <8 x i64> } %262, <8 x i64> %261, 1
  %264 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %265 = extractvalue { <8 x ptr>, <8 x i64> } %263, 1
  %266 = extractelement <8 x ptr> %264, i32 0
  %267 = extractelement <8 x i64> %265, i32 0
  %268 = sub i64 %267, 0
  %269 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %270 = select i1 %269, i64 %268, i64 0
  %private.contiguous.address137 = getelementptr i8, ptr %266, i64 %270
  %private.contiguous.load138 = load <8 x float>, ptr %private.contiguous.address137, align 4
  %271 = select <8 x i1> %49, <8 x float> %private.contiguous.load138, <8 x float> zeroinitializer
  %272 = load <8 x float>, ptr %.spill35, align 32
  %273 = select <8 x i1> %49, <8 x float> %271, <8 x float> %272
  store <8 x float> %273, ptr %.spill35, align 32
  %274 = srem i64 %257, 32
  %275 = sdiv i64 %257, 32
  %.spill.load139 = load i64, ptr %.spill24, align 4
  %276 = add i64 %.spill.load139, %274
  %.spill.load140 = load i64, ptr %.spill24, align 4
  %277 = add i64 %.spill.load140, %276
  %278 = sub i64 %277, 2
  %279 = icmp sge i64 %278, 0
  %280 = icmp slt i64 %278, 32
  %281 = and i1 %279, %280
  store i1 %281, ptr %.spill36, align 1
  %282 = add i64 0, %275
  %283 = mul i64 %282, 32
  %284 = add i64 %283, %278
  store i64 %284, ptr %.spill37, align 4
  %285 = icmp sge i64 %284, 0
  %286 = icmp slt i64 %284, 128
  %287 = and i1 %285, %286
  br i1 %287, label %direct.true141, label %direct.false142

direct.schedule.13:                               ; preds = %direct.true141
  %tile_snapshot.spill.load143 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill27, align 64
  %288 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load143, 0
  %289 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load143, 1
  %.spill.load144 = load i64, ptr %.spill37, align 4
  %.splatinsert145 = insertelement <8 x i64> poison, i64 %.spill.load144, i64 0
  %.splat146 = shufflevector <8 x i64> %.splatinsert145, <8 x i64> poison, <8 x i32> zeroinitializer
  %290 = mul <8 x i64> %.splat146, splat (i64 32)
  %291 = add <8 x i64> %289, %290
  %292 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %288, 0
  %293 = insertvalue { <8 x ptr>, <8 x i64> } %292, <8 x i64> %291, 1
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %295 = extractvalue { <8 x ptr>, <8 x i64> } %293, 1
  %296 = extractelement <8 x ptr> %294, i32 0
  %297 = extractelement <8 x i64> %295, i32 0
  %298 = sub i64 %297, 0
  %299 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %300 = select i1 %299, i64 %298, i64 0
  %private.contiguous.address147 = getelementptr i8, ptr %296, i64 %300
  %private.contiguous.load148 = load <8 x float>, ptr %private.contiguous.address147, align 4
  %301 = select <8 x i1> %49, <8 x float> %private.contiguous.load148, <8 x float> zeroinitializer
  %302 = load <8 x float>, ptr %.slot38, align 32
  %303 = select <8 x i1> %49, <8 x float> %301, <8 x float> %302
  store <8 x float> %303, ptr %.slot38, align 32
  br label %direct.schedule.14

direct.schedule.14:                               ; preds = %direct.schedule.13, %direct.false142
  %.spill.load149 = load float, ptr %.spill19, align 4
  %.splatinsert150 = insertelement <8 x float> poison, float %.spill.load149, i64 0
  %.splat151 = shufflevector <8 x float> %.splatinsert150, <8 x float> poison, <8 x i32> zeroinitializer
  %.state152 = load <8 x float>, ptr %.slot38, align 32
  %.spill.load153 = load i1, ptr %.spill36, align 1
  %.splatinsert154 = insertelement <8 x i1> poison, i1 %.spill.load153, i64 0
  %.splat155 = shufflevector <8 x i1> %.splatinsert154, <8 x i1> poison, <8 x i32> zeroinitializer
  %304 = select <8 x i1> %.splat155, <8 x float> %.state152, <8 x float> %.splat151
  %.spill.load156 = load <8 x float>, ptr %.spill35, align 32
  %305 = fadd <8 x float> %.spill.load156, %304
  %tile_snapshot.spill.load157 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill33, align 64
  %306 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load157, 0
  %307 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load157, 1
  %.state158 = load i64, ptr %.slot34, align 4
  %.splatinsert159 = insertelement <8 x i64> poison, i64 %.state158, i64 0
  %.splat160 = shufflevector <8 x i64> %.splatinsert159, <8 x i64> poison, <8 x i32> zeroinitializer
  %308 = mul <8 x i64> %.splat160, splat (i64 32)
  %309 = add <8 x i64> %307, %308
  %310 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %306, 0
  %311 = insertvalue { <8 x ptr>, <8 x i64> } %310, <8 x i64> %309, 1
  %312 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %313 = extractvalue { <8 x ptr>, <8 x i64> } %311, 1
  %314 = extractelement <8 x ptr> %312, i32 0
  %315 = extractelement <8 x i64> %313, i32 0
  %316 = sub i64 %315, 0
  %317 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %318 = select i1 %317, i64 %316, i64 0
  %private.contiguous.address161 = getelementptr i8, ptr %314, i64 %318
  %private.contiguous.preserve162 = load <8 x float>, ptr %private.contiguous.address161, align 4
  %319 = select <8 x i1> %49, <8 x float> %305, <8 x float> %private.contiguous.preserve162
  store <8 x float> %319, ptr %private.contiguous.address161, align 4
  %.state163 = load i64, ptr %.slot34, align 4
  %320 = add i64 %.state163, 1
  store i64 %320, ptr %.slot34, align 4
  br label %direct.schedule.11

direct.schedule.15:                               ; preds = %direct.false131
  %321 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %321, 0
  %324 = select <8 x i1> %49, <8 x ptr> %322, <8 x ptr> %323
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %9, 1
  %326 = extractvalue { <8 x ptr>, <8 x i64> } %321, 1
  %327 = select <8 x i1> %49, <8 x i64> %325, <8 x i64> %326
  %328 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %324, 0
  %329 = insertvalue { <8 x ptr>, <8 x i64> } %328, <8 x i64> %327, 1
  store { <8 x ptr>, <8 x i64> } %329, ptr %tile_snapshot.spill39, align 64
  store i64 0, ptr %.slot40, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.19, %direct.schedule.15
  %.state164 = load i64, ptr %.slot40, align 4
  %330 = icmp slt i64 %.state164, 128
  br i1 %330, label %direct.true165, label %direct.false166

direct.schedule.17:                               ; preds = %direct.true165
  %.state167 = load i64, ptr %.slot40, align 4
  %331 = srem i64 %.state167, 32
  %.state168 = load i64, ptr %.slot40, align 4
  %332 = sdiv i64 %.state168, 32
  %333 = add i64 0, %332
  %334 = mul i64 %333, 32
  %335 = add i64 %334, %331
  %tile_snapshot.spill.load169 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill33, align 64
  %336 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load169, 0
  %337 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load169, 1
  %.splatinsert170 = insertelement <8 x i64> poison, i64 %335, i64 0
  %.splat171 = shufflevector <8 x i64> %.splatinsert170, <8 x i64> poison, <8 x i32> zeroinitializer
  %338 = mul <8 x i64> %.splat171, splat (i64 32)
  %339 = add <8 x i64> %337, %338
  %340 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %336, 0
  %341 = insertvalue { <8 x ptr>, <8 x i64> } %340, <8 x i64> %339, 1
  %342 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %343 = extractvalue { <8 x ptr>, <8 x i64> } %341, 1
  %344 = extractelement <8 x ptr> %342, i32 0
  %345 = extractelement <8 x i64> %343, i32 0
  %346 = sub i64 %345, 0
  %347 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %348 = select i1 %347, i64 %346, i64 0
  %private.contiguous.address172 = getelementptr i8, ptr %344, i64 %348
  %private.contiguous.load173 = load <8 x float>, ptr %private.contiguous.address172, align 4
  %349 = select <8 x i1> %49, <8 x float> %private.contiguous.load173, <8 x float> zeroinitializer
  %350 = load <8 x float>, ptr %.spill41, align 32
  %351 = select <8 x i1> %49, <8 x float> %349, <8 x float> %350
  store <8 x float> %351, ptr %.spill41, align 32
  %352 = srem i64 %335, 32
  %353 = sdiv i64 %335, 32
  %.spill.load174 = load i64, ptr %.spill24, align 4
  %354 = add i64 %.spill.load174, %352
  %.spill.load175 = load i64, ptr %.spill24, align 4
  %355 = add i64 %.spill.load175, %354
  %356 = sub i64 %355, 4
  %357 = icmp sge i64 %356, 0
  %358 = icmp slt i64 %356, 32
  %359 = and i1 %357, %358
  store i1 %359, ptr %.spill42, align 1
  %360 = add i64 0, %353
  %361 = mul i64 %360, 32
  %362 = add i64 %361, %356
  store i64 %362, ptr %.spill43, align 4
  %363 = icmp sge i64 %362, 0
  %364 = icmp slt i64 %362, 128
  %365 = and i1 %363, %364
  br i1 %365, label %direct.true176, label %direct.false177

direct.schedule.18:                               ; preds = %direct.true176
  %tile_snapshot.spill.load178 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill33, align 64
  %366 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load178, 0
  %367 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load178, 1
  %.spill.load179 = load i64, ptr %.spill43, align 4
  %.splatinsert180 = insertelement <8 x i64> poison, i64 %.spill.load179, i64 0
  %.splat181 = shufflevector <8 x i64> %.splatinsert180, <8 x i64> poison, <8 x i32> zeroinitializer
  %368 = mul <8 x i64> %.splat181, splat (i64 32)
  %369 = add <8 x i64> %367, %368
  %370 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %366, 0
  %371 = insertvalue { <8 x ptr>, <8 x i64> } %370, <8 x i64> %369, 1
  %372 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %373 = extractvalue { <8 x ptr>, <8 x i64> } %371, 1
  %374 = extractelement <8 x ptr> %372, i32 0
  %375 = extractelement <8 x i64> %373, i32 0
  %376 = sub i64 %375, 0
  %377 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %378 = select i1 %377, i64 %376, i64 0
  %private.contiguous.address182 = getelementptr i8, ptr %374, i64 %378
  %private.contiguous.load183 = load <8 x float>, ptr %private.contiguous.address182, align 4
  %379 = select <8 x i1> %49, <8 x float> %private.contiguous.load183, <8 x float> zeroinitializer
  %380 = load <8 x float>, ptr %.slot44, align 32
  %381 = select <8 x i1> %49, <8 x float> %379, <8 x float> %380
  store <8 x float> %381, ptr %.slot44, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.18, %direct.false177
  %.spill.load184 = load float, ptr %.spill19, align 4
  %.splatinsert185 = insertelement <8 x float> poison, float %.spill.load184, i64 0
  %.splat186 = shufflevector <8 x float> %.splatinsert185, <8 x float> poison, <8 x i32> zeroinitializer
  %.state187 = load <8 x float>, ptr %.slot44, align 32
  %.spill.load188 = load i1, ptr %.spill42, align 1
  %.splatinsert189 = insertelement <8 x i1> poison, i1 %.spill.load188, i64 0
  %.splat190 = shufflevector <8 x i1> %.splatinsert189, <8 x i1> poison, <8 x i32> zeroinitializer
  %382 = select <8 x i1> %.splat190, <8 x float> %.state187, <8 x float> %.splat186
  %.spill.load191 = load <8 x float>, ptr %.spill41, align 32
  %383 = fadd <8 x float> %.spill.load191, %382
  %tile_snapshot.spill.load192 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %384 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 0
  %385 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 1
  %.state193 = load i64, ptr %.slot40, align 4
  %.splatinsert194 = insertelement <8 x i64> poison, i64 %.state193, i64 0
  %.splat195 = shufflevector <8 x i64> %.splatinsert194, <8 x i64> poison, <8 x i32> zeroinitializer
  %386 = mul <8 x i64> %.splat195, splat (i64 32)
  %387 = add <8 x i64> %385, %386
  %388 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %384, 0
  %389 = insertvalue { <8 x ptr>, <8 x i64> } %388, <8 x i64> %387, 1
  %390 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %391 = extractvalue { <8 x ptr>, <8 x i64> } %389, 1
  %392 = extractelement <8 x ptr> %390, i32 0
  %393 = extractelement <8 x i64> %391, i32 0
  %394 = sub i64 %393, 0
  %395 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %396 = select i1 %395, i64 %394, i64 0
  %private.contiguous.address196 = getelementptr i8, ptr %392, i64 %396
  %private.contiguous.preserve197 = load <8 x float>, ptr %private.contiguous.address196, align 4
  %397 = select <8 x i1> %49, <8 x float> %383, <8 x float> %private.contiguous.preserve197
  store <8 x float> %397, ptr %private.contiguous.address196, align 4
  %.state198 = load i64, ptr %.slot40, align 4
  %398 = add i64 %.state198, 1
  store i64 %398, ptr %.slot40, align 4
  br label %direct.schedule.16

direct.schedule.20:                               ; preds = %direct.false166
  %399 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill45, align 64
  %400 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %401 = extractvalue { <8 x ptr>, <8 x i64> } %399, 0
  %402 = select <8 x i1> %49, <8 x ptr> %400, <8 x ptr> %401
  %403 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %404 = extractvalue { <8 x ptr>, <8 x i64> } %399, 1
  %405 = select <8 x i1> %49, <8 x i64> %403, <8 x i64> %404
  %406 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %402, 0
  %407 = insertvalue { <8 x ptr>, <8 x i64> } %406, <8 x i64> %405, 1
  store { <8 x ptr>, <8 x i64> } %407, ptr %tile_snapshot.spill45, align 64
  store i64 0, ptr %.slot46, align 4
  br label %direct.schedule.21

direct.schedule.21:                               ; preds = %direct.schedule.24, %direct.schedule.20
  %.state199 = load i64, ptr %.slot46, align 4
  %408 = icmp slt i64 %.state199, 128
  br i1 %408, label %direct.true200, label %direct.false201

direct.schedule.22:                               ; preds = %direct.true200
  %.state202 = load i64, ptr %.slot46, align 4
  %409 = srem i64 %.state202, 32
  %.state203 = load i64, ptr %.slot46, align 4
  %410 = sdiv i64 %.state203, 32
  %411 = add i64 0, %410
  %412 = mul i64 %411, 32
  %413 = add i64 %412, %409
  %tile_snapshot.spill.load204 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %414 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load204, 0
  %415 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load204, 1
  %.splatinsert205 = insertelement <8 x i64> poison, i64 %413, i64 0
  %.splat206 = shufflevector <8 x i64> %.splatinsert205, <8 x i64> poison, <8 x i32> zeroinitializer
  %416 = mul <8 x i64> %.splat206, splat (i64 32)
  %417 = add <8 x i64> %415, %416
  %418 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %414, 0
  %419 = insertvalue { <8 x ptr>, <8 x i64> } %418, <8 x i64> %417, 1
  %420 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %421 = extractvalue { <8 x ptr>, <8 x i64> } %419, 1
  %422 = extractelement <8 x ptr> %420, i32 0
  %423 = extractelement <8 x i64> %421, i32 0
  %424 = sub i64 %423, 0
  %425 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %426 = select i1 %425, i64 %424, i64 0
  %private.contiguous.address207 = getelementptr i8, ptr %422, i64 %426
  %private.contiguous.load208 = load <8 x float>, ptr %private.contiguous.address207, align 4
  %427 = select <8 x i1> %49, <8 x float> %private.contiguous.load208, <8 x float> zeroinitializer
  %428 = load <8 x float>, ptr %.spill47, align 32
  %429 = select <8 x i1> %49, <8 x float> %427, <8 x float> %428
  store <8 x float> %429, ptr %.spill47, align 32
  %430 = srem i64 %413, 32
  %431 = sdiv i64 %413, 32
  %.spill.load209 = load i64, ptr %.spill24, align 4
  %432 = add i64 %.spill.load209, %430
  %.spill.load210 = load i64, ptr %.spill24, align 4
  %433 = add i64 %.spill.load210, %432
  %434 = sub i64 %433, 8
  %435 = icmp sge i64 %434, 0
  %436 = icmp slt i64 %434, 32
  %437 = and i1 %435, %436
  store i1 %437, ptr %.spill48, align 1
  %438 = add i64 0, %431
  %439 = mul i64 %438, 32
  %440 = add i64 %439, %434
  store i64 %440, ptr %.spill49, align 4
  %441 = icmp sge i64 %440, 0
  %442 = icmp slt i64 %440, 128
  %443 = and i1 %441, %442
  br i1 %443, label %direct.true211, label %direct.false212

direct.schedule.23:                               ; preds = %direct.true211
  %tile_snapshot.spill.load213 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %444 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load213, 0
  %445 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load213, 1
  %.spill.load214 = load i64, ptr %.spill49, align 4
  %.splatinsert215 = insertelement <8 x i64> poison, i64 %.spill.load214, i64 0
  %.splat216 = shufflevector <8 x i64> %.splatinsert215, <8 x i64> poison, <8 x i32> zeroinitializer
  %446 = mul <8 x i64> %.splat216, splat (i64 32)
  %447 = add <8 x i64> %445, %446
  %448 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %444, 0
  %449 = insertvalue { <8 x ptr>, <8 x i64> } %448, <8 x i64> %447, 1
  %450 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %451 = extractvalue { <8 x ptr>, <8 x i64> } %449, 1
  %452 = extractelement <8 x ptr> %450, i32 0
  %453 = extractelement <8 x i64> %451, i32 0
  %454 = sub i64 %453, 0
  %455 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %456 = select i1 %455, i64 %454, i64 0
  %private.contiguous.address217 = getelementptr i8, ptr %452, i64 %456
  %private.contiguous.load218 = load <8 x float>, ptr %private.contiguous.address217, align 4
  %457 = select <8 x i1> %49, <8 x float> %private.contiguous.load218, <8 x float> zeroinitializer
  %458 = load <8 x float>, ptr %.slot50, align 32
  %459 = select <8 x i1> %49, <8 x float> %457, <8 x float> %458
  store <8 x float> %459, ptr %.slot50, align 32
  br label %direct.schedule.24

direct.schedule.24:                               ; preds = %direct.schedule.23, %direct.false212
  %.spill.load219 = load float, ptr %.spill19, align 4
  %.splatinsert220 = insertelement <8 x float> poison, float %.spill.load219, i64 0
  %.splat221 = shufflevector <8 x float> %.splatinsert220, <8 x float> poison, <8 x i32> zeroinitializer
  %.state222 = load <8 x float>, ptr %.slot50, align 32
  %.spill.load223 = load i1, ptr %.spill48, align 1
  %.splatinsert224 = insertelement <8 x i1> poison, i1 %.spill.load223, i64 0
  %.splat225 = shufflevector <8 x i1> %.splatinsert224, <8 x i1> poison, <8 x i32> zeroinitializer
  %460 = select <8 x i1> %.splat225, <8 x float> %.state222, <8 x float> %.splat221
  %.spill.load226 = load <8 x float>, ptr %.spill47, align 32
  %461 = fadd <8 x float> %.spill.load226, %460
  %tile_snapshot.spill.load227 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill45, align 64
  %462 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load227, 0
  %463 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load227, 1
  %.state228 = load i64, ptr %.slot46, align 4
  %.splatinsert229 = insertelement <8 x i64> poison, i64 %.state228, i64 0
  %.splat230 = shufflevector <8 x i64> %.splatinsert229, <8 x i64> poison, <8 x i32> zeroinitializer
  %464 = mul <8 x i64> %.splat230, splat (i64 32)
  %465 = add <8 x i64> %463, %464
  %466 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %462, 0
  %467 = insertvalue { <8 x ptr>, <8 x i64> } %466, <8 x i64> %465, 1
  %468 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %469 = extractvalue { <8 x ptr>, <8 x i64> } %467, 1
  %470 = extractelement <8 x ptr> %468, i32 0
  %471 = extractelement <8 x i64> %469, i32 0
  %472 = sub i64 %471, 0
  %473 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %474 = select i1 %473, i64 %472, i64 0
  %private.contiguous.address231 = getelementptr i8, ptr %470, i64 %474
  %private.contiguous.preserve232 = load <8 x float>, ptr %private.contiguous.address231, align 4
  %475 = select <8 x i1> %49, <8 x float> %461, <8 x float> %private.contiguous.preserve232
  store <8 x float> %475, ptr %private.contiguous.address231, align 4
  %.state233 = load i64, ptr %.slot46, align 4
  %476 = add i64 %.state233, 1
  store i64 %476, ptr %.slot46, align 4
  br label %direct.schedule.21

direct.schedule.25:                               ; preds = %direct.false201
  %477 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill51, align 64
  %478 = extractvalue { <8 x ptr>, <8 x i64> } %13, 0
  %479 = extractvalue { <8 x ptr>, <8 x i64> } %477, 0
  %480 = select <8 x i1> %49, <8 x ptr> %478, <8 x ptr> %479
  %481 = extractvalue { <8 x ptr>, <8 x i64> } %13, 1
  %482 = extractvalue { <8 x ptr>, <8 x i64> } %477, 1
  %483 = select <8 x i1> %49, <8 x i64> %481, <8 x i64> %482
  %484 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %480, 0
  %485 = insertvalue { <8 x ptr>, <8 x i64> } %484, <8 x i64> %483, 1
  store { <8 x ptr>, <8 x i64> } %485, ptr %tile_snapshot.spill51, align 64
  store i64 0, ptr %.slot52, align 4
  br label %direct.schedule.26

direct.schedule.26:                               ; preds = %direct.schedule.29, %direct.schedule.25
  %.state234 = load i64, ptr %.slot52, align 4
  %486 = icmp slt i64 %.state234, 128
  br i1 %486, label %direct.true235, label %direct.false236

direct.schedule.27:                               ; preds = %direct.true235
  %.state237 = load i64, ptr %.slot52, align 4
  %487 = srem i64 %.state237, 32
  %.state238 = load i64, ptr %.slot52, align 4
  %488 = sdiv i64 %.state238, 32
  %489 = add i64 0, %488
  store i64 %489, ptr %.spill53, align 4
  %490 = mul i64 %489, 32
  %491 = add i64 %490, %487
  %492 = srem i64 %491, 32
  %493 = sdiv i64 %491, 32
  %494 = add i64 0, %493
  %495 = mul i64 %494, 32
  %496 = add i64 %495, %492
  %tile_snapshot.spill.load239 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill45, align 64
  %497 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load239, 0
  %498 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load239, 1
  %.splatinsert240 = insertelement <8 x i64> poison, i64 %496, i64 0
  %.splat241 = shufflevector <8 x i64> %.splatinsert240, <8 x i64> poison, <8 x i32> zeroinitializer
  %499 = mul <8 x i64> %.splat241, splat (i64 32)
  %500 = add <8 x i64> %498, %499
  %501 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %497, 0
  %502 = insertvalue { <8 x ptr>, <8 x i64> } %501, <8 x i64> %500, 1
  %503 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %504 = extractvalue { <8 x ptr>, <8 x i64> } %502, 1
  %505 = extractelement <8 x ptr> %503, i32 0
  %506 = extractelement <8 x i64> %504, i32 0
  %507 = sub i64 %506, 0
  %508 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %509 = select i1 %508, i64 %507, i64 0
  %private.contiguous.address242 = getelementptr i8, ptr %505, i64 %509
  %private.contiguous.load243 = load <8 x float>, ptr %private.contiguous.address242, align 4
  %510 = select <8 x i1> %49, <8 x float> %private.contiguous.load243, <8 x float> zeroinitializer
  %511 = load <8 x float>, ptr %.spill54, align 32
  %512 = select <8 x i1> %49, <8 x float> %510, <8 x float> %511
  store <8 x float> %512, ptr %.spill54, align 32
  %513 = srem i64 %496, 32
  %514 = sdiv i64 %496, 32
  %.spill.load244 = load i64, ptr %.spill24, align 4
  %515 = add i64 %.spill.load244, %513
  %.spill.load245 = load i64, ptr %.spill24, align 4
  %516 = add i64 %.spill.load245, %515
  %517 = sub i64 %516, 16
  %518 = icmp sge i64 %517, 0
  %519 = icmp slt i64 %517, 32
  %520 = and i1 %518, %519
  store i1 %520, ptr %.spill55, align 1
  %521 = add i64 0, %514
  %522 = mul i64 %521, 32
  %523 = add i64 %522, %517
  store i64 %523, ptr %.spill56, align 4
  %524 = icmp sge i64 %523, 0
  %525 = icmp slt i64 %523, 128
  %526 = and i1 %524, %525
  br i1 %526, label %direct.true246, label %direct.false247

direct.schedule.28:                               ; preds = %direct.true246
  %tile_snapshot.spill.load248 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill45, align 64
  %527 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 0
  %528 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 1
  %.spill.load249 = load i64, ptr %.spill56, align 4
  %.splatinsert250 = insertelement <8 x i64> poison, i64 %.spill.load249, i64 0
  %.splat251 = shufflevector <8 x i64> %.splatinsert250, <8 x i64> poison, <8 x i32> zeroinitializer
  %529 = mul <8 x i64> %.splat251, splat (i64 32)
  %530 = add <8 x i64> %528, %529
  %531 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %527, 0
  %532 = insertvalue { <8 x ptr>, <8 x i64> } %531, <8 x i64> %530, 1
  %533 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %534 = extractvalue { <8 x ptr>, <8 x i64> } %532, 1
  %535 = extractelement <8 x ptr> %533, i32 0
  %536 = extractelement <8 x i64> %534, i32 0
  %537 = sub i64 %536, 0
  %538 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %539 = select i1 %538, i64 %537, i64 0
  %private.contiguous.address252 = getelementptr i8, ptr %535, i64 %539
  %private.contiguous.load253 = load <8 x float>, ptr %private.contiguous.address252, align 4
  %540 = select <8 x i1> %49, <8 x float> %private.contiguous.load253, <8 x float> zeroinitializer
  %541 = load <8 x float>, ptr %.slot57, align 32
  %542 = select <8 x i1> %49, <8 x float> %540, <8 x float> %541
  store <8 x float> %542, ptr %.slot57, align 32
  br label %direct.schedule.29

direct.schedule.29:                               ; preds = %direct.schedule.28, %direct.false247
  %.spill.load254 = load float, ptr %.spill19, align 4
  %.splatinsert255 = insertelement <8 x float> poison, float %.spill.load254, i64 0
  %.splat256 = shufflevector <8 x float> %.splatinsert255, <8 x float> poison, <8 x i32> zeroinitializer
  %.state257 = load <8 x float>, ptr %.slot57, align 32
  %.spill.load258 = load i1, ptr %.spill55, align 1
  %.splatinsert259 = insertelement <8 x i1> poison, i1 %.spill.load258, i64 0
  %.splat260 = shufflevector <8 x i1> %.splatinsert259, <8 x i1> poison, <8 x i32> zeroinitializer
  %543 = select <8 x i1> %.splat260, <8 x float> %.state257, <8 x float> %.splat256
  %.spill.load261 = load <8 x float>, ptr %.spill54, align 32
  %544 = fadd <8 x float> %.spill.load261, %543
  %tile_snapshot.spill.load262 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %545 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load262, 0
  %546 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load262, 1
  %.spill.load263 = load i64, ptr %.spill53, align 4
  %.splatinsert264 = insertelement <8 x i64> poison, i64 %.spill.load263, i64 0
  %.splat265 = shufflevector <8 x i64> %.splatinsert264, <8 x i64> poison, <8 x i32> zeroinitializer
  %547 = mul <8 x i64> %.splat265, splat (i64 32)
  %548 = add <8 x i64> %546, %547
  %549 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %545, 0
  %550 = insertvalue { <8 x ptr>, <8 x i64> } %549, <8 x i64> %548, 1
  %551 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %552 = extractvalue { <8 x ptr>, <8 x i64> } %550, 1
  %553 = extractelement <8 x ptr> %551, i32 0
  %554 = extractelement <8 x i64> %552, i32 0
  %555 = sub i64 %554, 0
  %556 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %557 = select i1 %556, i64 %555, i64 0
  %private.contiguous.address266 = getelementptr i8, ptr %553, i64 %557
  %private.contiguous.load267 = load <8 x float>, ptr %private.contiguous.address266, align 4
  %558 = select <8 x i1> %49, <8 x float> %private.contiguous.load267, <8 x float> zeroinitializer
  %559 = fadd <8 x float> %544, %558
  %tile_snapshot.spill.load268 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill51, align 64
  %560 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load268, 0
  %561 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load268, 1
  %.state269 = load i64, ptr %.slot52, align 4
  %.splatinsert270 = insertelement <8 x i64> poison, i64 %.state269, i64 0
  %.splat271 = shufflevector <8 x i64> %.splatinsert270, <8 x i64> poison, <8 x i32> zeroinitializer
  %562 = mul <8 x i64> %.splat271, splat (i64 32)
  %563 = add <8 x i64> %561, %562
  %564 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %560, 0
  %565 = insertvalue { <8 x ptr>, <8 x i64> } %564, <8 x i64> %563, 1
  %566 = extractvalue { <8 x ptr>, <8 x i64> } %13, 0
  %567 = extractvalue { <8 x ptr>, <8 x i64> } %565, 1
  %568 = extractelement <8 x ptr> %566, i32 0
  %569 = extractelement <8 x i64> %567, i32 0
  %570 = sub i64 %569, 0
  %571 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %572 = select i1 %571, i64 %570, i64 0
  %private.contiguous.address272 = getelementptr i8, ptr %568, i64 %572
  %private.contiguous.preserve273 = load <8 x float>, ptr %private.contiguous.address272, align 4
  %573 = select <8 x i1> %49, <8 x float> %559, <8 x float> %private.contiguous.preserve273
  store <8 x float> %573, ptr %private.contiguous.address272, align 4
  %.state274 = load i64, ptr %.slot52, align 4
  %574 = add i64 %.state274, 1
  store i64 %574, ptr %.slot52, align 4
  br label %direct.schedule.26

direct.schedule.30:                               ; preds = %direct.false236
  store i64 0, ptr %.slot58, align 4
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.32, %direct.schedule.30
  %.state275 = load i64, ptr %.slot58, align 4
  %575 = icmp slt i64 %.state275, 128
  br i1 %575, label %direct.true276, label %direct.false277

direct.schedule.32:                               ; preds = %direct.true276
  %.state278 = load i64, ptr %.slot58, align 4
  %576 = srem i64 %.state278, 32
  %.state279 = load i64, ptr %.slot58, align 4
  %577 = sdiv i64 %.state279, 32
  %.spill.load280 = load <8 x i64>, ptr %.spill, align 64
  %.splatinsert281 = insertelement <8 x i64> poison, i64 %577, i64 0
  %.splat282 = shufflevector <8 x i64> %.splatinsert281, <8 x i64> poison, <8 x i32> zeroinitializer
  %578 = add <8 x i64> %.spill.load280, %.splat282
  %579 = add <8 x i64> zeroinitializer, %578
  %.spill.load283 = load i64, ptr %.spill24, align 4
  %580 = add i64 %.spill.load283, %576
  %581 = mul <8 x i64> %579, splat (i64 32)
  %.splatinsert284 = insertelement <8 x i64> poison, i64 %580, i64 0
  %.splat285 = shufflevector <8 x i64> %.splatinsert284, <8 x i64> poison, <8 x i32> zeroinitializer
  %582 = add <8 x i64> %581, %.splat285
  %tile_snapshot.spill.load286 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill51, align 64
  %583 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load286, 0
  %584 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load286, 1
  %.state287 = load i64, ptr %.slot58, align 4
  %.splatinsert288 = insertelement <8 x i64> poison, i64 %.state287, i64 0
  %.splat289 = shufflevector <8 x i64> %.splatinsert288, <8 x i64> poison, <8 x i32> zeroinitializer
  %585 = mul <8 x i64> %.splat289, splat (i64 32)
  %586 = add <8 x i64> %584, %585
  %587 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %583, 0
  %588 = insertvalue { <8 x ptr>, <8 x i64> } %587, <8 x i64> %586, 1
  %589 = extractvalue { <8 x ptr>, <8 x i64> } %13, 0
  %590 = extractvalue { <8 x ptr>, <8 x i64> } %588, 1
  %591 = extractelement <8 x ptr> %589, i32 0
  %592 = extractelement <8 x i64> %590, i32 0
  %593 = sub i64 %592, 0
  %594 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %595 = select i1 %594, i64 %593, i64 0
  %private.contiguous.address290 = getelementptr i8, ptr %591, i64 %595
  %private.contiguous.load291 = load <8 x float>, ptr %private.contiguous.address290, align 4
  %596 = select <8 x i1> %49, <8 x float> %private.contiguous.load291, <8 x float> zeroinitializer
  %597 = extractvalue { ptr, i64 } %25, 0
  %598 = mul <8 x i64> %582, splat (i64 4)
  %599 = getelementptr i8, ptr %597, <8 x i64> %598
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %596, <8 x ptr> %599, i32 1, <8 x i1> %49)
  %.state292 = load i64, ptr %.slot58, align 4
  %600 = add i64 %.state292, 1
  store i64 %600, ptr %.slot58, align 4
  br label %direct.schedule.31

direct.schedule.33:                               ; preds = %direct.false277
  %tile_snapshot.spill.load293 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill51, align 64
  %601 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load293, 0
  %602 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load293, 1
  %603 = add <8 x i64> %602, splat (i64 992)
  %604 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %601, 0
  %605 = insertvalue { <8 x ptr>, <8 x i64> } %604, <8 x i64> %603, 1
  %606 = extractvalue { <8 x ptr>, <8 x i64> } %13, 0
  %607 = extractvalue { <8 x ptr>, <8 x i64> } %605, 1
  %608 = extractelement <8 x ptr> %606, i32 0
  %609 = extractelement <8 x i64> %607, i32 0
  %610 = sub i64 %609, 0
  %611 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %612 = select i1 %611, i64 %610, i64 0
  %private.contiguous.address294 = getelementptr i8, ptr %608, i64 %612
  %private.contiguous.load295 = load <8 x float>, ptr %private.contiguous.address294, align 4
  %613 = select <8 x i1> %49, <8 x float> %private.contiguous.load295, <8 x float> zeroinitializer
  %tile_snapshot.spill.load296 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill51, align 64
  %614 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load296, 0
  %615 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load296, 1
  %616 = add <8 x i64> %615, splat (i64 2016)
  %617 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %614, 0
  %618 = insertvalue { <8 x ptr>, <8 x i64> } %617, <8 x i64> %616, 1
  %619 = extractvalue { <8 x ptr>, <8 x i64> } %13, 0
  %620 = extractvalue { <8 x ptr>, <8 x i64> } %618, 1
  %621 = extractelement <8 x ptr> %619, i32 0
  %622 = extractelement <8 x i64> %620, i32 0
  %623 = sub i64 %622, 0
  %624 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %625 = select i1 %624, i64 %623, i64 0
  %private.contiguous.address297 = getelementptr i8, ptr %621, i64 %625
  %private.contiguous.load298 = load <8 x float>, ptr %private.contiguous.address297, align 4
  %626 = select <8 x i1> %49, <8 x float> %private.contiguous.load298, <8 x float> zeroinitializer
  %tile_snapshot.spill.load299 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill51, align 64
  %627 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load299, 0
  %628 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load299, 1
  %629 = add <8 x i64> %628, splat (i64 3040)
  %630 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %627, 0
  %631 = insertvalue { <8 x ptr>, <8 x i64> } %630, <8 x i64> %629, 1
  %632 = extractvalue { <8 x ptr>, <8 x i64> } %13, 0
  %633 = extractvalue { <8 x ptr>, <8 x i64> } %631, 1
  %634 = extractelement <8 x ptr> %632, i32 0
  %635 = extractelement <8 x i64> %633, i32 0
  %636 = sub i64 %635, 0
  %637 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %638 = select i1 %637, i64 %636, i64 0
  %private.contiguous.address300 = getelementptr i8, ptr %634, i64 %638
  %private.contiguous.load301 = load <8 x float>, ptr %private.contiguous.address300, align 4
  %639 = select <8 x i1> %49, <8 x float> %private.contiguous.load301, <8 x float> zeroinitializer
  %tile_snapshot.spill.load302 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill51, align 64
  %640 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load302, 0
  %641 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load302, 1
  %642 = add <8 x i64> %641, splat (i64 4064)
  %643 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %640, 0
  %644 = insertvalue { <8 x ptr>, <8 x i64> } %643, <8 x i64> %642, 1
  %645 = extractvalue { <8 x ptr>, <8 x i64> } %13, 0
  %646 = extractvalue { <8 x ptr>, <8 x i64> } %644, 1
  %647 = extractelement <8 x ptr> %645, i32 0
  %648 = extractelement <8 x i64> %646, i32 0
  %649 = sub i64 %648, 0
  %650 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %651 = select i1 %650, i64 %649, i64 0
  %private.contiguous.address303 = getelementptr i8, ptr %647, i64 %651
  %private.contiguous.load304 = load <8 x float>, ptr %private.contiguous.address303, align 4
  %652 = select <8 x i1> %49, <8 x float> %private.contiguous.load304, <8 x float> zeroinitializer
  %.state305 = load i64, ptr %.slot, align 4
  %653 = add i64 %.state305, 1
  store i64 %653, ptr %.slot, align 4
  %654 = load <8 x float>, ptr %.slot20, align 32
  %655 = select <8 x i1> %49, <8 x float> %613, <8 x float> %654
  store <8 x float> %655, ptr %.slot20, align 32
  %656 = load <8 x float>, ptr %.slot21, align 32
  %657 = select <8 x i1> %49, <8 x float> %626, <8 x float> %656
  store <8 x float> %657, ptr %.slot21, align 32
  %658 = load <8 x float>, ptr %.slot22, align 32
  %659 = select <8 x i1> %49, <8 x float> %639, <8 x float> %658
  store <8 x float> %659, ptr %.slot22, align 32
  %660 = load <8 x float>, ptr %.slot23, align 32
  %661 = select <8 x i1> %49, <8 x float> %652, <8 x float> %660
  store <8 x float> %661, ptr %.slot23, align 32
  br label %direct.schedule.1

direct.schedule.34:                               ; preds = %direct.false
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.34

direct.true80:                                    ; preds = %direct.schedule.3
  br label %direct.schedule.4

direct.false81:                                   ; preds = %direct.schedule.3
  br label %direct.schedule.5

direct.true96:                                    ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false97:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.10

direct.true106:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false107:                                  ; preds = %direct.schedule.7
  %662 = load <8 x float>, ptr %.slot32, align 32
  %663 = select <8 x i1> %49, <8 x float> zeroinitializer, <8 x float> %662
  store <8 x float> %663, ptr %.slot32, align 32
  br label %direct.schedule.9

direct.true130:                                   ; preds = %direct.schedule.11
  br label %direct.schedule.12

direct.false131:                                  ; preds = %direct.schedule.11
  br label %direct.schedule.15

direct.true141:                                   ; preds = %direct.schedule.12
  br label %direct.schedule.13

direct.false142:                                  ; preds = %direct.schedule.12
  %664 = load <8 x float>, ptr %.slot38, align 32
  %665 = select <8 x i1> %49, <8 x float> zeroinitializer, <8 x float> %664
  store <8 x float> %665, ptr %.slot38, align 32
  br label %direct.schedule.14

direct.true165:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false166:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.20

direct.true176:                                   ; preds = %direct.schedule.17
  br label %direct.schedule.18

direct.false177:                                  ; preds = %direct.schedule.17
  %666 = load <8 x float>, ptr %.slot44, align 32
  %667 = select <8 x i1> %49, <8 x float> zeroinitializer, <8 x float> %666
  store <8 x float> %667, ptr %.slot44, align 32
  br label %direct.schedule.19

direct.true200:                                   ; preds = %direct.schedule.21
  br label %direct.schedule.22

direct.false201:                                  ; preds = %direct.schedule.21
  br label %direct.schedule.25

direct.true211:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false212:                                  ; preds = %direct.schedule.22
  %668 = load <8 x float>, ptr %.slot50, align 32
  %669 = select <8 x i1> %49, <8 x float> zeroinitializer, <8 x float> %668
  store <8 x float> %669, ptr %.slot50, align 32
  br label %direct.schedule.24

direct.true235:                                   ; preds = %direct.schedule.26
  br label %direct.schedule.27

direct.false236:                                  ; preds = %direct.schedule.26
  br label %direct.schedule.30

direct.true246:                                   ; preds = %direct.schedule.27
  br label %direct.schedule.28

direct.false247:                                  ; preds = %direct.schedule.27
  %670 = load <8 x float>, ptr %.slot57, align 32
  %671 = select <8 x i1> %49, <8 x float> zeroinitializer, <8 x float> %670
  store <8 x float> %671, ptr %.slot57, align 32
  br label %direct.schedule.29

direct.true276:                                   ; preds = %direct.schedule.31
  br label %direct.schedule.32

direct.false277:                                  ; preds = %direct.schedule.31
  br label %direct.schedule.33
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #2

define internal void @tile_inclusive_scan.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @tile_inclusive_scan.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }

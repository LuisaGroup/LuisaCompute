; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

@convergence.targets = private unnamed_addr constant [18 x i32] [i32 49, i32 5, i32 10, i32 9, i32 13, i32 18, i32 17, i32 21, i32 26, i32 25, i32 29, i32 34, i32 33, i32 37, i32 42, i32 41, i32 45, i32 48], align 4

define internal void @tile_inclusive_scan(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %live.mask = alloca <8 x i1>, align 1
  %runnable.mask = alloca <8 x i1>, align 1
  %ready.count = alloca i32, align 4
  %ready.mask = alloca [8 x <8 x i1>], align 1
  %ready.target = alloca [8 x i32], align 4
  %ready.token = alloca [8 x i32], align 4
  %current.mask = alloca <8 x i1>, align 1
  %current.token = alloca i32, align 4
  %frame.active = alloca i8, align 1
  %frame.static.id = alloca <8 x i32>, align 32
  %frame.parent.token = alloca <8 x i32>, align 32
  %frame.expected = alloca [8 x <8 x i1>], align 1
  %frame.arrived = alloca [8 x <8 x i1>], align 1
  store <8 x i1> zeroinitializer, ptr %live.mask, align 1
  store <8 x i1> zeroinitializer, ptr %runnable.mask, align 1
  store i32 0, ptr %ready.count, align 4
  store [8 x <8 x i1>] zeroinitializer, ptr %ready.mask, align 1
  store [8 x i32] zeroinitializer, ptr %ready.target, align 4
  store [8 x i32] zeroinitializer, ptr %ready.token, align 4
  store <8 x i1> zeroinitializer, ptr %current.mask, align 1
  store i32 0, ptr %current.token, align 4
  store i8 0, ptr %frame.active, align 1
  store <8 x i32> zeroinitializer, ptr %frame.static.id, align 32
  store <8 x i32> zeroinitializer, ptr %frame.parent.token, align 32
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.expected, align 1
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.arrived, align 1
  %tile_snapshot.local = alloca [128 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [4096 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local4 = alloca [2048 x i8], align 8
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local7 = alloca [4096 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local10 = alloca [4096 x i8], align 4
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %8 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %9 = insertvalue { <8 x ptr>, <8 x i64> } %8, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local13 = alloca [2048 x i8], align 8
  %.splatinsert14 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local13, i64 0
  %.splat15 = shufflevector <8 x ptr> %.splatinsert14, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat15, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local16 = alloca [4096 x i8], align 4
  %.splatinsert17 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local16, i64 0
  %.splat18 = shufflevector <8 x ptr> %.splatinsert17, <8 x ptr> poison, <8 x i32> zeroinitializer
  %12 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat18, 0
  %13 = insertvalue { <8 x ptr>, <8 x i64> } %12, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local19 = alloca [4096 x i8], align 4
  %.splatinsert20 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local19, i64 0
  %.splat21 = shufflevector <8 x ptr> %.splatinsert20, <8 x ptr> poison, <8 x i32> zeroinitializer
  %14 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat21, 0
  %15 = insertvalue { <8 x ptr>, <8 x i64> } %14, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local22 = alloca [2048 x i8], align 8
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local25 = alloca [4096 x i8], align 4
  %.splatinsert26 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local25, i64 0
  %.splat27 = shufflevector <8 x ptr> %.splatinsert26, <8 x ptr> poison, <8 x i32> zeroinitializer
  %18 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat27, 0
  %19 = insertvalue { <8 x ptr>, <8 x i64> } %18, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local28 = alloca [4096 x i8], align 4
  %.splatinsert29 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local28, i64 0
  %.splat30 = shufflevector <8 x ptr> %.splatinsert29, <8 x ptr> poison, <8 x i32> zeroinitializer
  %20 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat30, 0
  %21 = insertvalue { <8 x ptr>, <8 x i64> } %20, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local31 = alloca [2048 x i8], align 8
  %.splatinsert32 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local31, i64 0
  %.splat33 = shufflevector <8 x ptr> %.splatinsert32, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat33, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local34 = alloca [4096 x i8], align 4
  %.splatinsert35 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local34, i64 0
  %.splat36 = shufflevector <8 x ptr> %.splatinsert35, <8 x ptr> poison, <8 x i32> zeroinitializer
  %24 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat36, 0
  %25 = insertvalue { <8 x ptr>, <8 x i64> } %24, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local37 = alloca [4096 x i8], align 4
  %.splatinsert38 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local37, i64 0
  %.splat39 = shufflevector <8 x ptr> %.splatinsert38, <8 x ptr> poison, <8 x i32> zeroinitializer
  %26 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat39, 0
  %27 = insertvalue { <8 x ptr>, <8 x i64> } %26, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local40 = alloca [2048 x i8], align 8
  %.splatinsert41 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local40, i64 0
  %.splat42 = shufflevector <8 x ptr> %.splatinsert41, <8 x ptr> poison, <8 x i32> zeroinitializer
  %28 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat42, 0
  %29 = insertvalue { <8 x ptr>, <8 x i64> } %28, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local43 = alloca [4096 x i8], align 4
  %.splatinsert44 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local43, i64 0
  %.splat45 = shufflevector <8 x ptr> %.splatinsert44, <8 x ptr> poison, <8 x i32> zeroinitializer
  %30 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat45, 0
  %31 = insertvalue { <8 x ptr>, <8 x i64> } %30, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local46 = alloca [4096 x i8], align 4
  %.splatinsert47 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local46, i64 0
  %.splat48 = shufflevector <8 x ptr> %.splatinsert47, <8 x ptr> poison, <8 x i32> zeroinitializer
  %32 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat48, 0
  %33 = insertvalue { <8 x ptr>, <8 x i64> } %32, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill49 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill49, align 4
  %.slot = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot, align 64
  %.slot50 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.slot50, align 32
  %.slot51 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.slot51, align 32
  %.slot52 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.slot52, align 32
  %.slot53 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.slot53, align 32
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.spill54 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill54, align 64
  %tile_snapshot.spill55 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill55, align 64
  %.slot56 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot56, align 64
  %tile_snapshot.spill57 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill57, align 64
  %tile_snapshot.spill58 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill58, align 64
  %.slot59 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot59, align 64
  %.spill60 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill60, align 1
  %.spill61 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill61, align 64
  %.slot62 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot62, align 32
  %tile_snapshot.spill63 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill63, align 64
  %.slot64 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot64, align 64
  %tile_snapshot.spill65 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill65, align 64
  %tile_snapshot.spill66 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill66, align 64
  %.slot67 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot67, align 64
  %.spill68 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill68, align 1
  %.spill69 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill69, align 64
  %.slot70 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot70, align 32
  %tile_snapshot.spill71 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill71, align 64
  %.slot72 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot72, align 64
  %tile_snapshot.spill73 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill73, align 64
  %tile_snapshot.spill74 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill74, align 64
  %.slot75 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot75, align 64
  %.spill76 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill76, align 1
  %.spill77 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill77, align 64
  %.slot78 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot78, align 32
  %tile_snapshot.spill79 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill79, align 64
  %.slot80 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot80, align 64
  %tile_snapshot.spill81 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill81, align 64
  %tile_snapshot.spill82 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill82, align 64
  %.slot83 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot83, align 64
  %.spill84 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill84, align 1
  %.spill85 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill85, align 64
  %.slot86 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot86, align 32
  %tile_snapshot.spill87 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill87, align 64
  %.slot88 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot88, align 64
  %tile_snapshot.spill89 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill89, align 64
  %tile_snapshot.spill90 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill90, align 64
  %.slot91 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot91, align 64
  %.spill92 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill92, align 1
  %.spill93 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill93, align 64
  %.slot94 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot94, align 32
  %tile_snapshot.spill95 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill95, align 64
  %.slot96 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot96, align 64
  %.slot97 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot97, align 64
  %34 = getelementptr i8, ptr %argument_buffer, i64 0
  %35 = load ptr, ptr %34, align 16
  %36 = getelementptr i8, ptr %34, i64 8
  %37 = load i64, ptr %36, align 8
  %38 = insertvalue { ptr, i64 } poison, ptr %35, 0
  %39 = insertvalue { ptr, i64 } %38, i64 %37, 1
  %40 = getelementptr i8, ptr %argument_buffer, i64 16
  %41 = load ptr, ptr %40, align 16
  %42 = getelementptr i8, ptr %40, i64 8
  %43 = load i64, ptr %42, align 8
  %44 = insertvalue { ptr, i64 } poison, ptr %41, 0
  %45 = insertvalue { ptr, i64 } %44, i64 %43, 1
  %46 = load i32, ptr %launch_config, align 4
  %47 = getelementptr i8, ptr %launch_config, i64 12
  %48 = load i32, ptr %47, align 4
  %49 = getelementptr i8, ptr %launch_config, i64 4
  %50 = load i32, ptr %49, align 4
  %51 = getelementptr i8, ptr %launch_config, i64 16
  %52 = load i32, ptr %51, align 4
  %53 = getelementptr i8, ptr %launch_config, i64 8
  %54 = load i32, ptr %53, align 4
  %55 = getelementptr i8, ptr %launch_config, i64 20
  %56 = load i32, ptr %55, align 4
  %57 = getelementptr i8, ptr %launch_config, i64 36
  %58 = load i32, ptr %57, align 4
  %.splatinsert98 = insertelement <8 x i32> poison, i32 %58, i64 0
  %.splat99 = shufflevector <8 x i32> %.splatinsert98, <8 x i32> poison, <8 x i32> zeroinitializer
  %59 = add <8 x i32> %.splat99, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %60 = mul i32 %46, 32
  %.splatinsert100 = insertelement <8 x i32> poison, i32 %60, i64 0
  %.splat101 = shufflevector <8 x i32> %.splatinsert100, <8 x i32> poison, <8 x i32> zeroinitializer
  %61 = add <8 x i32> %.splat101, %59
  %62 = mul i32 %50, 1
  %.splatinsert102 = insertelement <8 x i32> poison, i32 %62, i64 0
  %.splat103 = shufflevector <8 x i32> %.splatinsert102, <8 x i32> poison, <8 x i32> zeroinitializer
  %63 = add <8 x i32> %.splat103, zeroinitializer
  %64 = mul i32 %54, 1
  %.splatinsert104 = insertelement <8 x i32> poison, i32 %64, i64 0
  %.splat105 = shufflevector <8 x i32> %.splatinsert104, <8 x i32> poison, <8 x i32> zeroinitializer
  %65 = add <8 x i32> %.splat105, zeroinitializer
  %66 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %61, 0
  %67 = insertvalue [3 x <8 x i32>] %66, <8 x i32> %63, 1
  %68 = insertvalue [3 x <8 x i32>] %67, <8 x i32> %65, 2
  %.splatinsert106 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat107 = shufflevector <8 x i32> %.splatinsert106, <8 x i32> poison, <8 x i32> zeroinitializer
  %69 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat107
  store <8 x i1> %69, ptr %live.mask, align 1
  %70 = load i32, ptr %current.token, align 4
  %71 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %69)
  %72 = load i32, ptr %ready.count, align 4
  %73 = icmp uge i32 %72, 8
  %74 = and i1 %71, %73
  br i1 %74, label %ready.overflow.trap, label %ready.overflow.resume

ready.overflow.trap:                              ; preds = %prologue
  call void @llvm.trap()
  unreachable

ready.overflow.resume:                            ; preds = %prologue
  %75 = select i1 %71, i32 %72, i32 0
  %76 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %75
  %77 = load <8 x i1>, ptr %76, align 1
  %78 = select i1 %71, <8 x i1> %69, <8 x i1> %77
  store <8 x i1> %78, ptr %76, align 1
  %79 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %75
  %80 = load i32, ptr %79, align 4
  %81 = select i1 %71, i32 0, i32 %80
  store i32 %81, ptr %79, align 4
  %82 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %75
  %83 = load i32, ptr %82, align 4
  %84 = select i1 %71, i32 %70, i32 %83
  store i32 %84, ptr %82, align 4
  %85 = add i32 %72, 1
  %86 = select i1 %71, i32 %85, i32 %72
  store i32 %86, ptr %ready.count, align 4
  %87 = load <8 x i1>, ptr %runnable.mask, align 1
  %88 = or <8 x i1> %87, %69
  store <8 x i1> %88, ptr %runnable.mask, align 1
  br label %scheduler.loop

scheduler.loop:                                   ; preds = %return.frame.cleanup.done, %convergence.cascade.exit993, %convergence.target.48.ready, %convergence.cascade.exit964, %schedule.47, %varying.coherent.false955, %varying.coherent.true954, %convergence.target.45.ready, %convergence.cascade.exit931, %schedule.44, %varying.coherent.false921, %varying.coherent.true920, %convergence.target.42.ready, %convergence.cascade.exit897, %convergence.target.41.ready, %convergence.cascade.exit872, %schedule.40, %varying.coherent.false868, %varying.coherent.true867, %varying.coherent.false857, %varying.coherent.true856, %convergence.target.37.ready, %convergence.cascade.exit769, %schedule.36, %varying.coherent.false760, %varying.coherent.true759, %convergence.target.34.ready, %convergence.cascade.exit736, %convergence.target.33.ready, %convergence.cascade.exit711, %schedule.32, %varying.coherent.false707, %varying.coherent.true706, %varying.coherent.false696, %varying.coherent.true695, %convergence.target.29.ready, %convergence.cascade.exit608, %schedule.28, %varying.coherent.false599, %varying.coherent.true598, %convergence.target.26.ready, %convergence.cascade.exit575, %convergence.target.25.ready, %convergence.cascade.exit550, %schedule.24, %varying.coherent.false546, %varying.coherent.true545, %varying.coherent.false535, %varying.coherent.true534, %convergence.target.21.ready, %convergence.cascade.exit447, %schedule.20, %varying.coherent.false438, %varying.coherent.true437, %convergence.target.18.ready, %convergence.cascade.exit414, %convergence.target.17.ready, %convergence.cascade.exit389, %schedule.16, %varying.coherent.false385, %varying.coherent.true384, %varying.coherent.false374, %varying.coherent.true373, %convergence.target.13.ready, %convergence.cascade.exit286, %schedule.12, %varying.coherent.false277, %varying.coherent.true276, %convergence.target.10.ready, %convergence.cascade.exit253, %convergence.target.9.ready, %convergence.cascade.exit228, %schedule.8, %varying.coherent.false224, %varying.coherent.true223, %varying.coherent.false213, %varying.coherent.true212, %convergence.target.5.ready, %convergence.cascade.exit, %schedule.4, %varying.coherent.false129, %varying.coherent.true128, %schedule.2, %varying.coherent.false, %varying.coherent.true, %schedule.0, %ready.overflow.resume
  %89 = load i32, ptr %ready.count, align 4
  %90 = icmp ne i32 %89, 0
  br i1 %90, label %scheduler.dispatch, label %scheduler.done

scheduler.dispatch:                               ; preds = %scheduler.loop
  %91 = sub i32 %89, 1
  store i32 %91, ptr %ready.count, align 4
  %92 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %91
  %93 = load <8 x i1>, ptr %92, align 1
  store <8 x i1> %93, ptr %current.mask, align 1
  %94 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %91
  %95 = load i32, ptr %94, align 4
  %96 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %91
  %97 = load i32, ptr %96, align 4
  store i32 %97, ptr %current.token, align 4
  %98 = load <8 x i1>, ptr %runnable.mask, align 1
  %99 = xor <8 x i1> %93, splat (i1 true)
  %100 = and <8 x i1> %98, %99
  store <8 x i1> %100, ptr %runnable.mask, align 1
  br label %scheduler.dispatch.route

scheduler.dispatch.route:                         ; preds = %ready.overflow.resume953, %ready.overflow.resume919, %ready.overflow.resume866, %ready.overflow.resume855, %ready.overflow.resume758, %ready.overflow.resume705, %ready.overflow.resume694, %ready.overflow.resume597, %ready.overflow.resume544, %ready.overflow.resume533, %ready.overflow.resume436, %ready.overflow.resume383, %ready.overflow.resume372, %ready.overflow.resume275, %ready.overflow.resume222, %ready.overflow.resume211, %ready.overflow.resume127, %ready.overflow.resume109, %scheduler.dispatch
  %scheduler.dispatch.pc = phi i32 [ %95, %scheduler.dispatch ], [ 49, %ready.overflow.resume109 ], [ 5, %ready.overflow.resume127 ], [ 10, %ready.overflow.resume211 ], [ 9, %ready.overflow.resume222 ], [ 13, %ready.overflow.resume275 ], [ 18, %ready.overflow.resume372 ], [ 17, %ready.overflow.resume383 ], [ 21, %ready.overflow.resume436 ], [ 26, %ready.overflow.resume533 ], [ 25, %ready.overflow.resume544 ], [ 29, %ready.overflow.resume597 ], [ 34, %ready.overflow.resume694 ], [ 33, %ready.overflow.resume705 ], [ 37, %ready.overflow.resume758 ], [ 42, %ready.overflow.resume855 ], [ 41, %ready.overflow.resume866 ], [ 45, %ready.overflow.resume919 ], [ 48, %ready.overflow.resume953 ]
  switch i32 %scheduler.dispatch.pc, label %scheduler.invalid [
    i32 0, label %schedule.0
    i32 1, label %schedule.1
    i32 2, label %schedule.2
    i32 3, label %schedule.3
    i32 4, label %schedule.4
    i32 5, label %schedule.5
    i32 6, label %schedule.6
    i32 7, label %schedule.7
    i32 8, label %schedule.8
    i32 9, label %schedule.9
    i32 10, label %schedule.10
    i32 11, label %schedule.11
    i32 12, label %schedule.12
    i32 13, label %schedule.13
    i32 14, label %schedule.14
    i32 15, label %schedule.15
    i32 16, label %schedule.16
    i32 17, label %schedule.17
    i32 18, label %schedule.18
    i32 19, label %schedule.19
    i32 20, label %schedule.20
    i32 21, label %schedule.21
    i32 22, label %schedule.22
    i32 23, label %schedule.23
    i32 24, label %schedule.24
    i32 25, label %schedule.25
    i32 26, label %schedule.26
    i32 27, label %schedule.27
    i32 28, label %schedule.28
    i32 29, label %schedule.29
    i32 30, label %schedule.30
    i32 31, label %schedule.31
    i32 32, label %schedule.32
    i32 33, label %schedule.33
    i32 34, label %schedule.34
    i32 35, label %schedule.35
    i32 36, label %schedule.36
    i32 37, label %schedule.37
    i32 38, label %schedule.38
    i32 39, label %schedule.39
    i32 40, label %schedule.40
    i32 41, label %schedule.41
    i32 42, label %schedule.42
    i32 43, label %schedule.43
    i32 44, label %schedule.44
    i32 45, label %schedule.45
    i32 46, label %schedule.46
    i32 47, label %schedule.47
    i32 48, label %schedule.48
    i32 49, label %schedule.49
  ]

scheduler.done:                                   ; preds = %scheduler.loop
  %101 = load <8 x i1>, ptr %live.mask, align 1
  %102 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  br i1 %102, label %scheduler.stalled, label %scheduler.exit

scheduler.exit:                                   ; preds = %scheduler.done
  ret void

scheduler.stalled:                                ; preds = %scheduler.done
  call void @llvm.trap()
  unreachable

scheduler.invalid:                                ; preds = %scheduler.dispatch.route
  call void @llvm.trap()
  unreachable

schedule.0:                                       ; preds = %scheduler.dispatch.route
  %103 = load <8 x i1>, ptr %current.mask, align 1
  %104 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %103)
  %105 = bitcast <8 x i1> %103 to i8
  %106 = call i8 @llvm.cttz.i8(i8 %105, i1 false)
  %107 = zext i8 %106 to i32
  %108 = select i1 %104, i32 %107, i32 0
  %109 = extractvalue [3 x <8 x i32>] %68, 0
  %110 = zext <8 x i32> %109 to <8 x i64>
  %111 = select <8 x i1> %103, <8 x i64> %110, <8 x i64> zeroinitializer
  %112 = select <8 x i1> %103, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %113 = sdiv <8 x i64> %111, %112
  %114 = mul <8 x i64> %113, splat (i64 4)
  %115 = load volatile <8 x i64>, ptr %.spill, align 64
  %116 = select <8 x i1> %103, <8 x i64> %114, <8 x i64> %115
  store volatile <8 x i64> %116, ptr %.spill, align 64
  store float 0.000000e+00, ptr %.spill49, align 4
  %117 = load <8 x i64>, ptr %.slot, align 64
  %118 = select <8 x i1> %103, <8 x i64> zeroinitializer, <8 x i64> %117
  store <8 x i64> %118, ptr %.slot, align 64
  %119 = load volatile <8 x float>, ptr %.slot50, align 32
  %120 = select <8 x i1> %103, <8 x float> zeroinitializer, <8 x float> %119
  store volatile <8 x float> %120, ptr %.slot50, align 32
  %121 = load volatile <8 x float>, ptr %.slot51, align 32
  %122 = select <8 x i1> %103, <8 x float> zeroinitializer, <8 x float> %121
  store volatile <8 x float> %122, ptr %.slot51, align 32
  %123 = load volatile <8 x float>, ptr %.slot52, align 32
  %124 = select <8 x i1> %103, <8 x float> zeroinitializer, <8 x float> %123
  store volatile <8 x float> %124, ptr %.slot52, align 32
  %125 = load volatile <8 x float>, ptr %.slot53, align 32
  %126 = select <8 x i1> %103, <8 x float> zeroinitializer, <8 x float> %125
  store volatile <8 x float> %126, ptr %.slot53, align 32
  store <8 x i1> %103, ptr %current.mask, align 1
  %127 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %103)
  br i1 %127, label %schedule.1, label %scheduler.loop

schedule.1:                                       ; preds = %convergence.target.48.ready, %schedule.0, %scheduler.dispatch.route
  %128 = load <8 x i1>, ptr %current.mask, align 1
  %129 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %128)
  %130 = bitcast <8 x i1> %128 to i8
  %131 = call i8 @llvm.cttz.i8(i8 %130, i1 false)
  %132 = zext i8 %131 to i32
  %133 = select i1 %129, i32 %132, i32 0
  %.state = load <8 x i64>, ptr %.slot, align 64
  %134 = icmp slt <8 x i64> %.state, splat (i64 32)
  %135 = and <8 x i1> %128, %134
  %136 = xor <8 x i1> %134, splat (i1 true)
  %137 = and <8 x i1> %128, %136
  %138 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %135)
  %139 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %137)
  %140 = and i1 %138, %139
  br i1 %140, label %varying.divergent, label %varying.coherent

schedule.2:                                       ; preds = %varying.coherent.true, %scheduler.dispatch.route
  %141 = load <8 x i1>, ptr %current.mask, align 1
  %142 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %141)
  %143 = bitcast <8 x i1> %141 to i8
  %144 = call i8 @llvm.cttz.i8(i8 %143, i1 false)
  %145 = zext i8 %144 to i32
  %146 = select i1 %142, i32 %145, i32 0
  %147 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %148 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %147, 0
  %150 = select <8 x i1> %141, <8 x ptr> %148, <8 x ptr> %149
  %151 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %152 = extractvalue { <8 x ptr>, <8 x i64> } %147, 1
  %153 = select <8 x i1> %141, <8 x i64> %151, <8 x i64> %152
  %154 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %150, 0
  %155 = insertvalue { <8 x ptr>, <8 x i64> } %154, <8 x i64> %153, 1
  store volatile { <8 x ptr>, <8 x i64> } %155, ptr %tile_snapshot.spill, align 64
  %156 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %157 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %158 = add <8 x i64> %157, zeroinitializer
  %159 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %156, 0
  %160 = insertvalue { <8 x ptr>, <8 x i64> } %159, <8 x i64> %158, 1
  %.state110 = load volatile <8 x float>, ptr %.slot50, align 32
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %160, 1
  %163 = extractelement <8 x ptr> %161, i32 0
  %164 = extractelement <8 x i64> %162, i32 %146
  %165 = zext i32 %146 to i64
  %166 = mul i64 %165, 4
  %167 = sub i64 %164, %166
  %168 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %141)
  %169 = select i1 %168, i64 %167, i64 0
  %private.contiguous.address = getelementptr i8, ptr %163, i64 %169
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %170 = select <8 x i1> %141, <8 x float> %.state110, <8 x float> %private.contiguous.preserve
  store <8 x float> %170, ptr %private.contiguous.address, align 4
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %173 = add <8 x i64> %172, splat (i64 32)
  %174 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %171, 0
  %175 = insertvalue { <8 x ptr>, <8 x i64> } %174, <8 x i64> %173, 1
  %.state111 = load volatile <8 x float>, ptr %.slot51, align 32
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %177 = extractvalue { <8 x ptr>, <8 x i64> } %175, 1
  %178 = extractelement <8 x ptr> %176, i32 0
  %179 = extractelement <8 x i64> %177, i32 %146
  %180 = zext i32 %146 to i64
  %181 = mul i64 %180, 4
  %182 = sub i64 %179, %181
  %183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %141)
  %184 = select i1 %183, i64 %182, i64 0
  %private.contiguous.address112 = getelementptr i8, ptr %178, i64 %184
  %private.contiguous.preserve113 = load <8 x float>, ptr %private.contiguous.address112, align 4
  %185 = select <8 x i1> %141, <8 x float> %.state111, <8 x float> %private.contiguous.preserve113
  store <8 x float> %185, ptr %private.contiguous.address112, align 4
  %186 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %188 = add <8 x i64> %187, splat (i64 64)
  %189 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %186, 0
  %190 = insertvalue { <8 x ptr>, <8 x i64> } %189, <8 x i64> %188, 1
  %.state114 = load volatile <8 x float>, ptr %.slot52, align 32
  %191 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %190, 1
  %193 = extractelement <8 x ptr> %191, i32 0
  %194 = extractelement <8 x i64> %192, i32 %146
  %195 = zext i32 %146 to i64
  %196 = mul i64 %195, 4
  %197 = sub i64 %194, %196
  %198 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %141)
  %199 = select i1 %198, i64 %197, i64 0
  %private.contiguous.address115 = getelementptr i8, ptr %193, i64 %199
  %private.contiguous.preserve116 = load <8 x float>, ptr %private.contiguous.address115, align 4
  %200 = select <8 x i1> %141, <8 x float> %.state114, <8 x float> %private.contiguous.preserve116
  store <8 x float> %200, ptr %private.contiguous.address115, align 4
  %201 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %202 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %203 = add <8 x i64> %202, splat (i64 96)
  %204 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %201, 0
  %205 = insertvalue { <8 x ptr>, <8 x i64> } %204, <8 x i64> %203, 1
  %.state117 = load volatile <8 x float>, ptr %.slot53, align 32
  %206 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %207 = extractvalue { <8 x ptr>, <8 x i64> } %205, 1
  %208 = extractelement <8 x ptr> %206, i32 0
  %209 = extractelement <8 x i64> %207, i32 %146
  %210 = zext i32 %146 to i64
  %211 = mul i64 %210, 4
  %212 = sub i64 %209, %211
  %213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %141)
  %214 = select i1 %213, i64 %212, i64 0
  %private.contiguous.address118 = getelementptr i8, ptr %208, i64 %214
  %private.contiguous.preserve119 = load <8 x float>, ptr %private.contiguous.address118, align 4
  %215 = select <8 x i1> %141, <8 x float> %.state117, <8 x float> %private.contiguous.preserve119
  store <8 x float> %215, ptr %private.contiguous.address118, align 4
  %.state120 = load <8 x i64>, ptr %.slot, align 64
  %216 = select <8 x i1> %141, <8 x i64> %.state120, <8 x i64> zeroinitializer
  %217 = select <8 x i1> %141, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %218 = sdiv <8 x i64> %216, %217
  %219 = mul <8 x i64> %218, splat (i64 32)
  %220 = load volatile <8 x i64>, ptr %.spill54, align 64
  %221 = select <8 x i1> %141, <8 x i64> %219, <8 x i64> %220
  store volatile <8 x i64> %221, ptr %.spill54, align 64
  %222 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %224 = extractvalue { <8 x ptr>, <8 x i64> } %222, 0
  %225 = select <8 x i1> %141, <8 x ptr> %223, <8 x ptr> %224
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %222, 1
  %228 = select <8 x i1> %141, <8 x i64> %226, <8 x i64> %227
  %229 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %225, 0
  %230 = insertvalue { <8 x ptr>, <8 x i64> } %229, <8 x i64> %228, 1
  store volatile { <8 x ptr>, <8 x i64> } %230, ptr %tile_snapshot.spill55, align 64
  %231 = load <8 x i64>, ptr %.slot56, align 64
  %232 = select <8 x i1> %141, <8 x i64> zeroinitializer, <8 x i64> %231
  store <8 x i64> %232, ptr %.slot56, align 64
  store <8 x i1> %141, ptr %current.mask, align 1
  %233 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %141)
  br i1 %233, label %schedule.3, label %scheduler.loop

schedule.3:                                       ; preds = %schedule.4, %schedule.2, %scheduler.dispatch.route
  %234 = load <8 x i1>, ptr %current.mask, align 1
  %235 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %234)
  %236 = bitcast <8 x i1> %234 to i8
  %237 = call i8 @llvm.cttz.i8(i8 %236, i1 false)
  %238 = zext i8 %237 to i32
  %239 = select i1 %235, i32 %238, i32 0
  %.state121 = load <8 x i64>, ptr %.slot56, align 64
  %240 = icmp slt <8 x i64> %.state121, splat (i64 128)
  %241 = and <8 x i1> %234, %240
  %242 = xor <8 x i1> %240, splat (i1 true)
  %243 = and <8 x i1> %234, %242
  %244 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %241)
  %245 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %243)
  %246 = and i1 %244, %245
  br i1 %246, label %varying.divergent122, label %varying.coherent123

schedule.4:                                       ; preds = %varying.coherent.true128, %scheduler.dispatch.route
  %247 = load <8 x i1>, ptr %current.mask, align 1
  %248 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %247)
  %249 = bitcast <8 x i1> %247 to i8
  %250 = call i8 @llvm.cttz.i8(i8 %249, i1 false)
  %251 = zext i8 %250 to i32
  %252 = select i1 %248, i32 %251, i32 0
  %.state130 = load <8 x i64>, ptr %.slot56, align 64
  %253 = select <8 x i1> %247, <8 x i64> %.state130, <8 x i64> zeroinitializer
  %254 = select <8 x i1> %247, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %255 = srem <8 x i64> %253, %254
  %.state131 = load <8 x i64>, ptr %.slot56, align 64
  %256 = select <8 x i1> %247, <8 x i64> %.state131, <8 x i64> zeroinitializer
  %257 = select <8 x i1> %247, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %258 = sdiv <8 x i64> %256, %257
  %.spill.load = load volatile <8 x i64>, ptr %.spill, align 64
  %259 = add <8 x i64> %.spill.load, %258
  %260 = add <8 x i64> zeroinitializer, %259
  %.spill.load132 = load volatile <8 x i64>, ptr %.spill54, align 64
  %261 = add <8 x i64> %.spill.load132, %255
  %262 = mul <8 x i64> %260, splat (i64 1024)
  %263 = add <8 x i64> %262, %261
  %264 = extractvalue { ptr, i64 } %39, 0
  %265 = mul <8 x i64> %263, splat (i64 4)
  %266 = getelementptr i8, ptr %264, <8 x i64> %265
  %267 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %266, i32 1, <8 x i1> %247, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %269 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state133 = load <8 x i64>, ptr %.slot56, align 64
  %270 = mul <8 x i64> %.state133, splat (i64 32)
  %271 = add <8 x i64> %269, %270
  %272 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %268, 0
  %273 = insertvalue { <8 x ptr>, <8 x i64> } %272, <8 x i64> %271, 1
  %274 = extractvalue { <8 x ptr>, <8 x i64> } %273, 0
  %275 = extractvalue { <8 x ptr>, <8 x i64> } %273, 1
  %276 = getelementptr i8, <8 x ptr> %274, <8 x i64> %275
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %267, <8 x ptr> %276, i32 1, <8 x i1> %247)
  %.state134 = load <8 x i64>, ptr %.slot56, align 64
  %277 = add <8 x i64> %.state134, splat (i64 1)
  %278 = load <8 x i64>, ptr %.slot56, align 64
  %279 = select <8 x i1> %247, <8 x i64> %277, <8 x i64> %278
  store <8 x i64> %279, ptr %.slot56, align 64
  store <8 x i1> %247, ptr %current.mask, align 1
  %280 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %247)
  br i1 %280, label %schedule.3, label %scheduler.loop

schedule.5:                                       ; preds = %varying.coherent.false129, %scheduler.dispatch.route
  %281 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token = load i32, ptr %current.token, align 4
  %convergence.token.present = icmp ne i32 %convergence.current.token, 0
  br i1 %convergence.token.present, label %convergence.cascade, label %convergence.cascade.exit

schedule.6:                                       ; preds = %convergence.target.9.ready, %convergence.target.5.ready, %scheduler.dispatch.route
  %282 = load <8 x i1>, ptr %current.mask, align 1
  %283 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %282)
  %284 = bitcast <8 x i1> %282 to i8
  %285 = call i8 @llvm.cttz.i8(i8 %284, i1 false)
  %286 = zext i8 %285 to i32
  %287 = select i1 %283, i32 %286, i32 0
  %.state205 = load <8 x i64>, ptr %.slot59, align 64
  %288 = icmp slt <8 x i64> %.state205, splat (i64 128)
  %289 = and <8 x i1> %282, %288
  %290 = xor <8 x i1> %288, splat (i1 true)
  %291 = and <8 x i1> %282, %290
  %292 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %289)
  %293 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %291)
  %294 = and i1 %292, %293
  br i1 %294, label %varying.divergent206, label %varying.coherent207

schedule.7:                                       ; preds = %varying.coherent.true212, %scheduler.dispatch.route
  %295 = load <8 x i1>, ptr %current.mask, align 1
  %296 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %295)
  %297 = bitcast <8 x i1> %295 to i8
  %298 = call i8 @llvm.cttz.i8(i8 %297, i1 false)
  %299 = zext i8 %298 to i32
  %300 = select i1 %296, i32 %299, i32 0
  %.state214 = load <8 x i64>, ptr %.slot59, align 64
  %301 = select <8 x i1> %295, <8 x i64> %.state214, <8 x i64> zeroinitializer
  %302 = select <8 x i1> %295, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %303 = srem <8 x i64> %301, %302
  %.state215 = load <8 x i64>, ptr %.slot59, align 64
  %304 = select <8 x i1> %295, <8 x i64> %.state215, <8 x i64> zeroinitializer
  %305 = select <8 x i1> %295, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %306 = sdiv <8 x i64> %304, %305
  %307 = add <8 x i64> zeroinitializer, %303
  %tile_snapshot.spill.load216 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill57, align 64
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load216, 0
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load216, 1
  %310 = mul <8 x i64> %307, splat (i64 64)
  %311 = add <8 x i64> %309, %310
  %312 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %308, 0
  %313 = insertvalue { <8 x ptr>, <8 x i64> } %312, <8 x i64> %311, 1
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %313, 0
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %313, 1
  %316 = getelementptr i8, <8 x ptr> %314, <8 x i64> %315
  %317 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> %316, i32 1, <8 x i1> %295, <8 x i64> zeroinitializer)
  %318 = icmp sge <8 x i64> %317, zeroinitializer
  %319 = icmp slt <8 x i64> %317, splat (i64 32)
  %320 = and <8 x i1> %318, %319
  %321 = load volatile <8 x i1>, ptr %.spill60, align 1
  %322 = select <8 x i1> %295, <8 x i1> %320, <8 x i1> %321
  store volatile <8 x i1> %322, ptr %.spill60, align 1
  %323 = add <8 x i64> zeroinitializer, %306
  %324 = mul <8 x i64> %323, splat (i64 32)
  %325 = add <8 x i64> %324, %317
  %326 = load volatile <8 x i64>, ptr %.spill61, align 64
  %327 = select <8 x i1> %295, <8 x i64> %325, <8 x i64> %326
  store volatile <8 x i64> %327, ptr %.spill61, align 64
  %328 = icmp sge <8 x i64> %325, zeroinitializer
  %329 = icmp slt <8 x i64> %325, splat (i64 128)
  %330 = and <8 x i1> %328, %329
  %331 = and <8 x i1> %295, %330
  %332 = xor <8 x i1> %330, splat (i1 true)
  %333 = and <8 x i1> %295, %332
  %334 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %331)
  %335 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %333)
  %336 = and i1 %334, %335
  br i1 %336, label %varying.divergent217, label %varying.coherent218

schedule.8:                                       ; preds = %varying.coherent.true223, %scheduler.dispatch.route
  %337 = load <8 x i1>, ptr %current.mask, align 1
  %338 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %337)
  %339 = bitcast <8 x i1> %337 to i8
  %340 = call i8 @llvm.cttz.i8(i8 %339, i1 false)
  %341 = zext i8 %340 to i32
  %342 = select i1 %338, i32 %341, i32 0
  %tile_snapshot.spill.load225 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %343 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load225, 0
  %344 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load225, 1
  %.spill.load226 = load volatile <8 x i64>, ptr %.spill61, align 64
  %345 = mul <8 x i64> %.spill.load226, splat (i64 32)
  %346 = add <8 x i64> %344, %345
  %347 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %343, 0
  %348 = insertvalue { <8 x ptr>, <8 x i64> } %347, <8 x i64> %346, 1
  %349 = extractvalue { <8 x ptr>, <8 x i64> } %348, 0
  %350 = extractvalue { <8 x ptr>, <8 x i64> } %348, 1
  %351 = getelementptr i8, <8 x ptr> %349, <8 x i64> %350
  %352 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %351, i32 1, <8 x i1> %337, <8 x float> zeroinitializer)
  %353 = load <8 x float>, ptr %.slot62, align 32
  %354 = select <8 x i1> %337, <8 x float> %352, <8 x float> %353
  store <8 x float> %354, ptr %.slot62, align 32
  store <8 x i1> %337, ptr %current.mask, align 1
  %355 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %337)
  br i1 %355, label %schedule.9, label %scheduler.loop

schedule.9:                                       ; preds = %schedule.8, %varying.coherent.false224, %scheduler.dispatch.route
  %356 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token229 = load i32, ptr %current.token, align 4
  %convergence.token.present230 = icmp ne i32 %convergence.current.token229, 0
  br i1 %convergence.token.present230, label %convergence.cascade227, label %convergence.cascade.exit228

schedule.10:                                      ; preds = %varying.coherent.false213, %scheduler.dispatch.route
  %357 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token254 = load i32, ptr %current.token, align 4
  %convergence.token.present255 = icmp ne i32 %convergence.current.token254, 0
  br i1 %convergence.token.present255, label %convergence.cascade252, label %convergence.cascade.exit253

schedule.11:                                      ; preds = %schedule.12, %convergence.target.10.ready, %scheduler.dispatch.route
  %358 = load <8 x i1>, ptr %current.mask, align 1
  %359 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %358)
  %360 = bitcast <8 x i1> %358 to i8
  %361 = call i8 @llvm.cttz.i8(i8 %360, i1 false)
  %362 = zext i8 %361 to i32
  %363 = select i1 %359, i32 %362, i32 0
  %.state269 = load <8 x i64>, ptr %.slot64, align 64
  %364 = icmp slt <8 x i64> %.state269, splat (i64 128)
  %365 = and <8 x i1> %358, %364
  %366 = xor <8 x i1> %364, splat (i1 true)
  %367 = and <8 x i1> %358, %366
  %368 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %365)
  %369 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %367)
  %370 = and i1 %368, %369
  br i1 %370, label %varying.divergent270, label %varying.coherent271

schedule.12:                                      ; preds = %varying.coherent.true276, %scheduler.dispatch.route
  %371 = load <8 x i1>, ptr %current.mask, align 1
  %372 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %371)
  %373 = bitcast <8 x i1> %371 to i8
  %374 = call i8 @llvm.cttz.i8(i8 %373, i1 false)
  %375 = zext i8 %374 to i32
  %376 = select i1 %372, i32 %375, i32 0
  %.state278 = load <8 x i64>, ptr %.slot64, align 64
  %377 = select <8 x i1> %371, <8 x i64> %.state278, <8 x i64> zeroinitializer
  %378 = select <8 x i1> %371, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %379 = srem <8 x i64> %377, %378
  %.state279 = load <8 x i64>, ptr %.slot64, align 64
  %380 = select <8 x i1> %371, <8 x i64> %.state279, <8 x i64> zeroinitializer
  %381 = select <8 x i1> %371, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %382 = sdiv <8 x i64> %380, %381
  %383 = add <8 x i64> zeroinitializer, %382
  %384 = mul <8 x i64> %383, splat (i64 32)
  %385 = add <8 x i64> %384, %379
  %tile_snapshot.spill.load280 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %386 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 0
  %387 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 1
  %388 = mul <8 x i64> %385, splat (i64 32)
  %389 = add <8 x i64> %387, %388
  %390 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %386, 0
  %391 = insertvalue { <8 x ptr>, <8 x i64> } %390, <8 x i64> %389, 1
  %392 = extractvalue { <8 x ptr>, <8 x i64> } %391, 0
  %393 = extractvalue { <8 x ptr>, <8 x i64> } %391, 1
  %394 = getelementptr i8, <8 x ptr> %392, <8 x i64> %393
  %395 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %394, i32 1, <8 x i1> %371, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load281 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill58, align 64
  %396 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 0
  %397 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 1
  %398 = mul <8 x i64> %385, splat (i64 32)
  %399 = add <8 x i64> %397, %398
  %400 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %396, 0
  %401 = insertvalue { <8 x ptr>, <8 x i64> } %400, <8 x i64> %399, 1
  %402 = extractvalue { <8 x ptr>, <8 x i64> } %401, 0
  %403 = extractvalue { <8 x ptr>, <8 x i64> } %401, 1
  %404 = getelementptr i8, <8 x ptr> %402, <8 x i64> %403
  %405 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %404, i32 1, <8 x i1> %371, <8 x float> zeroinitializer)
  %406 = fadd <8 x float> %395, %405
  %tile_snapshot.spill.load282 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill63, align 64
  %407 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load282, 0
  %408 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load282, 1
  %.state283 = load <8 x i64>, ptr %.slot64, align 64
  %409 = mul <8 x i64> %.state283, splat (i64 32)
  %410 = add <8 x i64> %408, %409
  %411 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %407, 0
  %412 = insertvalue { <8 x ptr>, <8 x i64> } %411, <8 x i64> %410, 1
  %413 = extractvalue { <8 x ptr>, <8 x i64> } %412, 0
  %414 = extractvalue { <8 x ptr>, <8 x i64> } %412, 1
  %415 = getelementptr i8, <8 x ptr> %413, <8 x i64> %414
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %406, <8 x ptr> %415, i32 1, <8 x i1> %371)
  %.state284 = load <8 x i64>, ptr %.slot64, align 64
  %416 = add <8 x i64> %.state284, splat (i64 1)
  %417 = load <8 x i64>, ptr %.slot64, align 64
  %418 = select <8 x i1> %371, <8 x i64> %416, <8 x i64> %417
  store <8 x i64> %418, ptr %.slot64, align 64
  store <8 x i1> %371, ptr %current.mask, align 1
  %419 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %371)
  br i1 %419, label %schedule.11, label %scheduler.loop

schedule.13:                                      ; preds = %varying.coherent.false277, %scheduler.dispatch.route
  %420 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token287 = load i32, ptr %current.token, align 4
  %convergence.token.present288 = icmp ne i32 %convergence.current.token287, 0
  br i1 %convergence.token.present288, label %convergence.cascade285, label %convergence.cascade.exit286

schedule.14:                                      ; preds = %convergence.target.17.ready, %convergence.target.13.ready, %scheduler.dispatch.route
  %421 = load <8 x i1>, ptr %current.mask, align 1
  %422 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %421)
  %423 = bitcast <8 x i1> %421 to i8
  %424 = call i8 @llvm.cttz.i8(i8 %423, i1 false)
  %425 = zext i8 %424 to i32
  %426 = select i1 %422, i32 %425, i32 0
  %.state366 = load <8 x i64>, ptr %.slot67, align 64
  %427 = icmp slt <8 x i64> %.state366, splat (i64 128)
  %428 = and <8 x i1> %421, %427
  %429 = xor <8 x i1> %427, splat (i1 true)
  %430 = and <8 x i1> %421, %429
  %431 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %428)
  %432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %430)
  %433 = and i1 %431, %432
  br i1 %433, label %varying.divergent367, label %varying.coherent368

schedule.15:                                      ; preds = %varying.coherent.true373, %scheduler.dispatch.route
  %434 = load <8 x i1>, ptr %current.mask, align 1
  %435 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %434)
  %436 = bitcast <8 x i1> %434 to i8
  %437 = call i8 @llvm.cttz.i8(i8 %436, i1 false)
  %438 = zext i8 %437 to i32
  %439 = select i1 %435, i32 %438, i32 0
  %.state375 = load <8 x i64>, ptr %.slot67, align 64
  %440 = select <8 x i1> %434, <8 x i64> %.state375, <8 x i64> zeroinitializer
  %441 = select <8 x i1> %434, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %442 = srem <8 x i64> %440, %441
  %.state376 = load <8 x i64>, ptr %.slot67, align 64
  %443 = select <8 x i1> %434, <8 x i64> %.state376, <8 x i64> zeroinitializer
  %444 = select <8 x i1> %434, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %445 = sdiv <8 x i64> %443, %444
  %446 = add <8 x i64> zeroinitializer, %442
  %tile_snapshot.spill.load377 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %447 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load377, 0
  %448 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load377, 1
  %449 = mul <8 x i64> %446, splat (i64 64)
  %450 = add <8 x i64> %448, %449
  %451 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %447, 0
  %452 = insertvalue { <8 x ptr>, <8 x i64> } %451, <8 x i64> %450, 1
  %453 = extractvalue { <8 x ptr>, <8 x i64> } %452, 0
  %454 = extractvalue { <8 x ptr>, <8 x i64> } %452, 1
  %455 = getelementptr i8, <8 x ptr> %453, <8 x i64> %454
  %456 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> %455, i32 1, <8 x i1> %434, <8 x i64> zeroinitializer)
  %457 = icmp sge <8 x i64> %456, zeroinitializer
  %458 = icmp slt <8 x i64> %456, splat (i64 32)
  %459 = and <8 x i1> %457, %458
  %460 = load volatile <8 x i1>, ptr %.spill68, align 1
  %461 = select <8 x i1> %434, <8 x i1> %459, <8 x i1> %460
  store volatile <8 x i1> %461, ptr %.spill68, align 1
  %462 = add <8 x i64> zeroinitializer, %445
  %463 = mul <8 x i64> %462, splat (i64 32)
  %464 = add <8 x i64> %463, %456
  %465 = load volatile <8 x i64>, ptr %.spill69, align 64
  %466 = select <8 x i1> %434, <8 x i64> %464, <8 x i64> %465
  store volatile <8 x i64> %466, ptr %.spill69, align 64
  %467 = icmp sge <8 x i64> %464, zeroinitializer
  %468 = icmp slt <8 x i64> %464, splat (i64 128)
  %469 = and <8 x i1> %467, %468
  %470 = and <8 x i1> %434, %469
  %471 = xor <8 x i1> %469, splat (i1 true)
  %472 = and <8 x i1> %434, %471
  %473 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %470)
  %474 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %472)
  %475 = and i1 %473, %474
  br i1 %475, label %varying.divergent378, label %varying.coherent379

schedule.16:                                      ; preds = %varying.coherent.true384, %scheduler.dispatch.route
  %476 = load <8 x i1>, ptr %current.mask, align 1
  %477 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %476)
  %478 = bitcast <8 x i1> %476 to i8
  %479 = call i8 @llvm.cttz.i8(i8 %478, i1 false)
  %480 = zext i8 %479 to i32
  %481 = select i1 %477, i32 %480, i32 0
  %tile_snapshot.spill.load386 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill63, align 64
  %482 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load386, 0
  %483 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load386, 1
  %.spill.load387 = load volatile <8 x i64>, ptr %.spill69, align 64
  %484 = mul <8 x i64> %.spill.load387, splat (i64 32)
  %485 = add <8 x i64> %483, %484
  %486 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %482, 0
  %487 = insertvalue { <8 x ptr>, <8 x i64> } %486, <8 x i64> %485, 1
  %488 = extractvalue { <8 x ptr>, <8 x i64> } %487, 0
  %489 = extractvalue { <8 x ptr>, <8 x i64> } %487, 1
  %490 = getelementptr i8, <8 x ptr> %488, <8 x i64> %489
  %491 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %490, i32 1, <8 x i1> %476, <8 x float> zeroinitializer)
  %492 = load <8 x float>, ptr %.slot70, align 32
  %493 = select <8 x i1> %476, <8 x float> %491, <8 x float> %492
  store <8 x float> %493, ptr %.slot70, align 32
  store <8 x i1> %476, ptr %current.mask, align 1
  %494 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %476)
  br i1 %494, label %schedule.17, label %scheduler.loop

schedule.17:                                      ; preds = %schedule.16, %varying.coherent.false385, %scheduler.dispatch.route
  %495 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token390 = load i32, ptr %current.token, align 4
  %convergence.token.present391 = icmp ne i32 %convergence.current.token390, 0
  br i1 %convergence.token.present391, label %convergence.cascade388, label %convergence.cascade.exit389

schedule.18:                                      ; preds = %varying.coherent.false374, %scheduler.dispatch.route
  %496 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token415 = load i32, ptr %current.token, align 4
  %convergence.token.present416 = icmp ne i32 %convergence.current.token415, 0
  br i1 %convergence.token.present416, label %convergence.cascade413, label %convergence.cascade.exit414

schedule.19:                                      ; preds = %schedule.20, %convergence.target.18.ready, %scheduler.dispatch.route
  %497 = load <8 x i1>, ptr %current.mask, align 1
  %498 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %497)
  %499 = bitcast <8 x i1> %497 to i8
  %500 = call i8 @llvm.cttz.i8(i8 %499, i1 false)
  %501 = zext i8 %500 to i32
  %502 = select i1 %498, i32 %501, i32 0
  %.state430 = load <8 x i64>, ptr %.slot72, align 64
  %503 = icmp slt <8 x i64> %.state430, splat (i64 128)
  %504 = and <8 x i1> %497, %503
  %505 = xor <8 x i1> %503, splat (i1 true)
  %506 = and <8 x i1> %497, %505
  %507 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %504)
  %508 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %506)
  %509 = and i1 %507, %508
  br i1 %509, label %varying.divergent431, label %varying.coherent432

schedule.20:                                      ; preds = %varying.coherent.true437, %scheduler.dispatch.route
  %510 = load <8 x i1>, ptr %current.mask, align 1
  %511 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %510)
  %512 = bitcast <8 x i1> %510 to i8
  %513 = call i8 @llvm.cttz.i8(i8 %512, i1 false)
  %514 = zext i8 %513 to i32
  %515 = select i1 %511, i32 %514, i32 0
  %.state439 = load <8 x i64>, ptr %.slot72, align 64
  %516 = select <8 x i1> %510, <8 x i64> %.state439, <8 x i64> zeroinitializer
  %517 = select <8 x i1> %510, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %518 = srem <8 x i64> %516, %517
  %.state440 = load <8 x i64>, ptr %.slot72, align 64
  %519 = select <8 x i1> %510, <8 x i64> %.state440, <8 x i64> zeroinitializer
  %520 = select <8 x i1> %510, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %521 = sdiv <8 x i64> %519, %520
  %522 = add <8 x i64> zeroinitializer, %521
  %523 = mul <8 x i64> %522, splat (i64 32)
  %524 = add <8 x i64> %523, %518
  %tile_snapshot.spill.load441 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill63, align 64
  %525 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load441, 0
  %526 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load441, 1
  %527 = mul <8 x i64> %524, splat (i64 32)
  %528 = add <8 x i64> %526, %527
  %529 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %525, 0
  %530 = insertvalue { <8 x ptr>, <8 x i64> } %529, <8 x i64> %528, 1
  %531 = extractvalue { <8 x ptr>, <8 x i64> } %530, 0
  %532 = extractvalue { <8 x ptr>, <8 x i64> } %530, 1
  %533 = getelementptr i8, <8 x ptr> %531, <8 x i64> %532
  %534 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %533, i32 1, <8 x i1> %510, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load442 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill66, align 64
  %535 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load442, 0
  %536 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load442, 1
  %537 = mul <8 x i64> %524, splat (i64 32)
  %538 = add <8 x i64> %536, %537
  %539 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %535, 0
  %540 = insertvalue { <8 x ptr>, <8 x i64> } %539, <8 x i64> %538, 1
  %541 = extractvalue { <8 x ptr>, <8 x i64> } %540, 0
  %542 = extractvalue { <8 x ptr>, <8 x i64> } %540, 1
  %543 = getelementptr i8, <8 x ptr> %541, <8 x i64> %542
  %544 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %543, i32 1, <8 x i1> %510, <8 x float> zeroinitializer)
  %545 = fadd <8 x float> %534, %544
  %tile_snapshot.spill.load443 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill71, align 64
  %546 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load443, 0
  %547 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load443, 1
  %.state444 = load <8 x i64>, ptr %.slot72, align 64
  %548 = mul <8 x i64> %.state444, splat (i64 32)
  %549 = add <8 x i64> %547, %548
  %550 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %546, 0
  %551 = insertvalue { <8 x ptr>, <8 x i64> } %550, <8 x i64> %549, 1
  %552 = extractvalue { <8 x ptr>, <8 x i64> } %551, 0
  %553 = extractvalue { <8 x ptr>, <8 x i64> } %551, 1
  %554 = getelementptr i8, <8 x ptr> %552, <8 x i64> %553
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %545, <8 x ptr> %554, i32 1, <8 x i1> %510)
  %.state445 = load <8 x i64>, ptr %.slot72, align 64
  %555 = add <8 x i64> %.state445, splat (i64 1)
  %556 = load <8 x i64>, ptr %.slot72, align 64
  %557 = select <8 x i1> %510, <8 x i64> %555, <8 x i64> %556
  store <8 x i64> %557, ptr %.slot72, align 64
  store <8 x i1> %510, ptr %current.mask, align 1
  %558 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %510)
  br i1 %558, label %schedule.19, label %scheduler.loop

schedule.21:                                      ; preds = %varying.coherent.false438, %scheduler.dispatch.route
  %559 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token448 = load i32, ptr %current.token, align 4
  %convergence.token.present449 = icmp ne i32 %convergence.current.token448, 0
  br i1 %convergence.token.present449, label %convergence.cascade446, label %convergence.cascade.exit447

schedule.22:                                      ; preds = %convergence.target.25.ready, %convergence.target.21.ready, %scheduler.dispatch.route
  %560 = load <8 x i1>, ptr %current.mask, align 1
  %561 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %560)
  %562 = bitcast <8 x i1> %560 to i8
  %563 = call i8 @llvm.cttz.i8(i8 %562, i1 false)
  %564 = zext i8 %563 to i32
  %565 = select i1 %561, i32 %564, i32 0
  %.state527 = load <8 x i64>, ptr %.slot75, align 64
  %566 = icmp slt <8 x i64> %.state527, splat (i64 128)
  %567 = and <8 x i1> %560, %566
  %568 = xor <8 x i1> %566, splat (i1 true)
  %569 = and <8 x i1> %560, %568
  %570 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %567)
  %571 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %569)
  %572 = and i1 %570, %571
  br i1 %572, label %varying.divergent528, label %varying.coherent529

schedule.23:                                      ; preds = %varying.coherent.true534, %scheduler.dispatch.route
  %573 = load <8 x i1>, ptr %current.mask, align 1
  %574 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %573)
  %575 = bitcast <8 x i1> %573 to i8
  %576 = call i8 @llvm.cttz.i8(i8 %575, i1 false)
  %577 = zext i8 %576 to i32
  %578 = select i1 %574, i32 %577, i32 0
  %.state536 = load <8 x i64>, ptr %.slot75, align 64
  %579 = select <8 x i1> %573, <8 x i64> %.state536, <8 x i64> zeroinitializer
  %580 = select <8 x i1> %573, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %581 = srem <8 x i64> %579, %580
  %.state537 = load <8 x i64>, ptr %.slot75, align 64
  %582 = select <8 x i1> %573, <8 x i64> %.state537, <8 x i64> zeroinitializer
  %583 = select <8 x i1> %573, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %584 = sdiv <8 x i64> %582, %583
  %585 = add <8 x i64> zeroinitializer, %581
  %tile_snapshot.spill.load538 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill73, align 64
  %586 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load538, 0
  %587 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load538, 1
  %588 = mul <8 x i64> %585, splat (i64 64)
  %589 = add <8 x i64> %587, %588
  %590 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %586, 0
  %591 = insertvalue { <8 x ptr>, <8 x i64> } %590, <8 x i64> %589, 1
  %592 = extractvalue { <8 x ptr>, <8 x i64> } %591, 0
  %593 = extractvalue { <8 x ptr>, <8 x i64> } %591, 1
  %594 = getelementptr i8, <8 x ptr> %592, <8 x i64> %593
  %595 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> %594, i32 1, <8 x i1> %573, <8 x i64> zeroinitializer)
  %596 = icmp sge <8 x i64> %595, zeroinitializer
  %597 = icmp slt <8 x i64> %595, splat (i64 32)
  %598 = and <8 x i1> %596, %597
  %599 = load volatile <8 x i1>, ptr %.spill76, align 1
  %600 = select <8 x i1> %573, <8 x i1> %598, <8 x i1> %599
  store volatile <8 x i1> %600, ptr %.spill76, align 1
  %601 = add <8 x i64> zeroinitializer, %584
  %602 = mul <8 x i64> %601, splat (i64 32)
  %603 = add <8 x i64> %602, %595
  %604 = load volatile <8 x i64>, ptr %.spill77, align 64
  %605 = select <8 x i1> %573, <8 x i64> %603, <8 x i64> %604
  store volatile <8 x i64> %605, ptr %.spill77, align 64
  %606 = icmp sge <8 x i64> %603, zeroinitializer
  %607 = icmp slt <8 x i64> %603, splat (i64 128)
  %608 = and <8 x i1> %606, %607
  %609 = and <8 x i1> %573, %608
  %610 = xor <8 x i1> %608, splat (i1 true)
  %611 = and <8 x i1> %573, %610
  %612 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %609)
  %613 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %611)
  %614 = and i1 %612, %613
  br i1 %614, label %varying.divergent539, label %varying.coherent540

schedule.24:                                      ; preds = %varying.coherent.true545, %scheduler.dispatch.route
  %615 = load <8 x i1>, ptr %current.mask, align 1
  %616 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %615)
  %617 = bitcast <8 x i1> %615 to i8
  %618 = call i8 @llvm.cttz.i8(i8 %617, i1 false)
  %619 = zext i8 %618 to i32
  %620 = select i1 %616, i32 %619, i32 0
  %tile_snapshot.spill.load547 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill71, align 64
  %621 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load547, 0
  %622 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load547, 1
  %.spill.load548 = load volatile <8 x i64>, ptr %.spill77, align 64
  %623 = mul <8 x i64> %.spill.load548, splat (i64 32)
  %624 = add <8 x i64> %622, %623
  %625 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %621, 0
  %626 = insertvalue { <8 x ptr>, <8 x i64> } %625, <8 x i64> %624, 1
  %627 = extractvalue { <8 x ptr>, <8 x i64> } %626, 0
  %628 = extractvalue { <8 x ptr>, <8 x i64> } %626, 1
  %629 = getelementptr i8, <8 x ptr> %627, <8 x i64> %628
  %630 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %629, i32 1, <8 x i1> %615, <8 x float> zeroinitializer)
  %631 = load <8 x float>, ptr %.slot78, align 32
  %632 = select <8 x i1> %615, <8 x float> %630, <8 x float> %631
  store <8 x float> %632, ptr %.slot78, align 32
  store <8 x i1> %615, ptr %current.mask, align 1
  %633 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %615)
  br i1 %633, label %schedule.25, label %scheduler.loop

schedule.25:                                      ; preds = %schedule.24, %varying.coherent.false546, %scheduler.dispatch.route
  %634 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token551 = load i32, ptr %current.token, align 4
  %convergence.token.present552 = icmp ne i32 %convergence.current.token551, 0
  br i1 %convergence.token.present552, label %convergence.cascade549, label %convergence.cascade.exit550

schedule.26:                                      ; preds = %varying.coherent.false535, %scheduler.dispatch.route
  %635 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token576 = load i32, ptr %current.token, align 4
  %convergence.token.present577 = icmp ne i32 %convergence.current.token576, 0
  br i1 %convergence.token.present577, label %convergence.cascade574, label %convergence.cascade.exit575

schedule.27:                                      ; preds = %schedule.28, %convergence.target.26.ready, %scheduler.dispatch.route
  %636 = load <8 x i1>, ptr %current.mask, align 1
  %637 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %636)
  %638 = bitcast <8 x i1> %636 to i8
  %639 = call i8 @llvm.cttz.i8(i8 %638, i1 false)
  %640 = zext i8 %639 to i32
  %641 = select i1 %637, i32 %640, i32 0
  %.state591 = load <8 x i64>, ptr %.slot80, align 64
  %642 = icmp slt <8 x i64> %.state591, splat (i64 128)
  %643 = and <8 x i1> %636, %642
  %644 = xor <8 x i1> %642, splat (i1 true)
  %645 = and <8 x i1> %636, %644
  %646 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %643)
  %647 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %645)
  %648 = and i1 %646, %647
  br i1 %648, label %varying.divergent592, label %varying.coherent593

schedule.28:                                      ; preds = %varying.coherent.true598, %scheduler.dispatch.route
  %649 = load <8 x i1>, ptr %current.mask, align 1
  %650 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %649)
  %651 = bitcast <8 x i1> %649 to i8
  %652 = call i8 @llvm.cttz.i8(i8 %651, i1 false)
  %653 = zext i8 %652 to i32
  %654 = select i1 %650, i32 %653, i32 0
  %.state600 = load <8 x i64>, ptr %.slot80, align 64
  %655 = select <8 x i1> %649, <8 x i64> %.state600, <8 x i64> zeroinitializer
  %656 = select <8 x i1> %649, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %657 = srem <8 x i64> %655, %656
  %.state601 = load <8 x i64>, ptr %.slot80, align 64
  %658 = select <8 x i1> %649, <8 x i64> %.state601, <8 x i64> zeroinitializer
  %659 = select <8 x i1> %649, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %660 = sdiv <8 x i64> %658, %659
  %661 = add <8 x i64> zeroinitializer, %660
  %662 = mul <8 x i64> %661, splat (i64 32)
  %663 = add <8 x i64> %662, %657
  %tile_snapshot.spill.load602 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill71, align 64
  %664 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load602, 0
  %665 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load602, 1
  %666 = mul <8 x i64> %663, splat (i64 32)
  %667 = add <8 x i64> %665, %666
  %668 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %664, 0
  %669 = insertvalue { <8 x ptr>, <8 x i64> } %668, <8 x i64> %667, 1
  %670 = extractvalue { <8 x ptr>, <8 x i64> } %669, 0
  %671 = extractvalue { <8 x ptr>, <8 x i64> } %669, 1
  %672 = getelementptr i8, <8 x ptr> %670, <8 x i64> %671
  %673 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %672, i32 1, <8 x i1> %649, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load603 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill74, align 64
  %674 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load603, 0
  %675 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load603, 1
  %676 = mul <8 x i64> %663, splat (i64 32)
  %677 = add <8 x i64> %675, %676
  %678 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %674, 0
  %679 = insertvalue { <8 x ptr>, <8 x i64> } %678, <8 x i64> %677, 1
  %680 = extractvalue { <8 x ptr>, <8 x i64> } %679, 0
  %681 = extractvalue { <8 x ptr>, <8 x i64> } %679, 1
  %682 = getelementptr i8, <8 x ptr> %680, <8 x i64> %681
  %683 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %682, i32 1, <8 x i1> %649, <8 x float> zeroinitializer)
  %684 = fadd <8 x float> %673, %683
  %tile_snapshot.spill.load604 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %685 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load604, 0
  %686 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load604, 1
  %.state605 = load <8 x i64>, ptr %.slot80, align 64
  %687 = mul <8 x i64> %.state605, splat (i64 32)
  %688 = add <8 x i64> %686, %687
  %689 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %685, 0
  %690 = insertvalue { <8 x ptr>, <8 x i64> } %689, <8 x i64> %688, 1
  %691 = extractvalue { <8 x ptr>, <8 x i64> } %690, 0
  %692 = extractvalue { <8 x ptr>, <8 x i64> } %690, 1
  %693 = getelementptr i8, <8 x ptr> %691, <8 x i64> %692
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %684, <8 x ptr> %693, i32 1, <8 x i1> %649)
  %.state606 = load <8 x i64>, ptr %.slot80, align 64
  %694 = add <8 x i64> %.state606, splat (i64 1)
  %695 = load <8 x i64>, ptr %.slot80, align 64
  %696 = select <8 x i1> %649, <8 x i64> %694, <8 x i64> %695
  store <8 x i64> %696, ptr %.slot80, align 64
  store <8 x i1> %649, ptr %current.mask, align 1
  %697 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %649)
  br i1 %697, label %schedule.27, label %scheduler.loop

schedule.29:                                      ; preds = %varying.coherent.false599, %scheduler.dispatch.route
  %698 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token609 = load i32, ptr %current.token, align 4
  %convergence.token.present610 = icmp ne i32 %convergence.current.token609, 0
  br i1 %convergence.token.present610, label %convergence.cascade607, label %convergence.cascade.exit608

schedule.30:                                      ; preds = %convergence.target.33.ready, %convergence.target.29.ready, %scheduler.dispatch.route
  %699 = load <8 x i1>, ptr %current.mask, align 1
  %700 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %699)
  %701 = bitcast <8 x i1> %699 to i8
  %702 = call i8 @llvm.cttz.i8(i8 %701, i1 false)
  %703 = zext i8 %702 to i32
  %704 = select i1 %700, i32 %703, i32 0
  %.state688 = load <8 x i64>, ptr %.slot83, align 64
  %705 = icmp slt <8 x i64> %.state688, splat (i64 128)
  %706 = and <8 x i1> %699, %705
  %707 = xor <8 x i1> %705, splat (i1 true)
  %708 = and <8 x i1> %699, %707
  %709 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %706)
  %710 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %708)
  %711 = and i1 %709, %710
  br i1 %711, label %varying.divergent689, label %varying.coherent690

schedule.31:                                      ; preds = %varying.coherent.true695, %scheduler.dispatch.route
  %712 = load <8 x i1>, ptr %current.mask, align 1
  %713 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %712)
  %714 = bitcast <8 x i1> %712 to i8
  %715 = call i8 @llvm.cttz.i8(i8 %714, i1 false)
  %716 = zext i8 %715 to i32
  %717 = select i1 %713, i32 %716, i32 0
  %.state697 = load <8 x i64>, ptr %.slot83, align 64
  %718 = select <8 x i1> %712, <8 x i64> %.state697, <8 x i64> zeroinitializer
  %719 = select <8 x i1> %712, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %720 = srem <8 x i64> %718, %719
  %.state698 = load <8 x i64>, ptr %.slot83, align 64
  %721 = select <8 x i1> %712, <8 x i64> %.state698, <8 x i64> zeroinitializer
  %722 = select <8 x i1> %712, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %723 = sdiv <8 x i64> %721, %722
  %724 = add <8 x i64> zeroinitializer, %720
  %tile_snapshot.spill.load699 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill81, align 64
  %725 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load699, 0
  %726 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load699, 1
  %727 = mul <8 x i64> %724, splat (i64 64)
  %728 = add <8 x i64> %726, %727
  %729 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %725, 0
  %730 = insertvalue { <8 x ptr>, <8 x i64> } %729, <8 x i64> %728, 1
  %731 = extractvalue { <8 x ptr>, <8 x i64> } %730, 0
  %732 = extractvalue { <8 x ptr>, <8 x i64> } %730, 1
  %733 = getelementptr i8, <8 x ptr> %731, <8 x i64> %732
  %734 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> %733, i32 1, <8 x i1> %712, <8 x i64> zeroinitializer)
  %735 = icmp sge <8 x i64> %734, zeroinitializer
  %736 = icmp slt <8 x i64> %734, splat (i64 32)
  %737 = and <8 x i1> %735, %736
  %738 = load volatile <8 x i1>, ptr %.spill84, align 1
  %739 = select <8 x i1> %712, <8 x i1> %737, <8 x i1> %738
  store volatile <8 x i1> %739, ptr %.spill84, align 1
  %740 = add <8 x i64> zeroinitializer, %723
  %741 = mul <8 x i64> %740, splat (i64 32)
  %742 = add <8 x i64> %741, %734
  %743 = load volatile <8 x i64>, ptr %.spill85, align 64
  %744 = select <8 x i1> %712, <8 x i64> %742, <8 x i64> %743
  store volatile <8 x i64> %744, ptr %.spill85, align 64
  %745 = icmp sge <8 x i64> %742, zeroinitializer
  %746 = icmp slt <8 x i64> %742, splat (i64 128)
  %747 = and <8 x i1> %745, %746
  %748 = and <8 x i1> %712, %747
  %749 = xor <8 x i1> %747, splat (i1 true)
  %750 = and <8 x i1> %712, %749
  %751 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %748)
  %752 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %750)
  %753 = and i1 %751, %752
  br i1 %753, label %varying.divergent700, label %varying.coherent701

schedule.32:                                      ; preds = %varying.coherent.true706, %scheduler.dispatch.route
  %754 = load <8 x i1>, ptr %current.mask, align 1
  %755 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %754)
  %756 = bitcast <8 x i1> %754 to i8
  %757 = call i8 @llvm.cttz.i8(i8 %756, i1 false)
  %758 = zext i8 %757 to i32
  %759 = select i1 %755, i32 %758, i32 0
  %tile_snapshot.spill.load708 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %760 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load708, 0
  %761 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load708, 1
  %.spill.load709 = load volatile <8 x i64>, ptr %.spill85, align 64
  %762 = mul <8 x i64> %.spill.load709, splat (i64 32)
  %763 = add <8 x i64> %761, %762
  %764 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %760, 0
  %765 = insertvalue { <8 x ptr>, <8 x i64> } %764, <8 x i64> %763, 1
  %766 = extractvalue { <8 x ptr>, <8 x i64> } %765, 0
  %767 = extractvalue { <8 x ptr>, <8 x i64> } %765, 1
  %768 = getelementptr i8, <8 x ptr> %766, <8 x i64> %767
  %769 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %768, i32 1, <8 x i1> %754, <8 x float> zeroinitializer)
  %770 = load <8 x float>, ptr %.slot86, align 32
  %771 = select <8 x i1> %754, <8 x float> %769, <8 x float> %770
  store <8 x float> %771, ptr %.slot86, align 32
  store <8 x i1> %754, ptr %current.mask, align 1
  %772 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %754)
  br i1 %772, label %schedule.33, label %scheduler.loop

schedule.33:                                      ; preds = %schedule.32, %varying.coherent.false707, %scheduler.dispatch.route
  %773 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token712 = load i32, ptr %current.token, align 4
  %convergence.token.present713 = icmp ne i32 %convergence.current.token712, 0
  br i1 %convergence.token.present713, label %convergence.cascade710, label %convergence.cascade.exit711

schedule.34:                                      ; preds = %varying.coherent.false696, %scheduler.dispatch.route
  %774 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token737 = load i32, ptr %current.token, align 4
  %convergence.token.present738 = icmp ne i32 %convergence.current.token737, 0
  br i1 %convergence.token.present738, label %convergence.cascade735, label %convergence.cascade.exit736

schedule.35:                                      ; preds = %schedule.36, %convergence.target.34.ready, %scheduler.dispatch.route
  %775 = load <8 x i1>, ptr %current.mask, align 1
  %776 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %775)
  %777 = bitcast <8 x i1> %775 to i8
  %778 = call i8 @llvm.cttz.i8(i8 %777, i1 false)
  %779 = zext i8 %778 to i32
  %780 = select i1 %776, i32 %779, i32 0
  %.state752 = load <8 x i64>, ptr %.slot88, align 64
  %781 = icmp slt <8 x i64> %.state752, splat (i64 128)
  %782 = and <8 x i1> %775, %781
  %783 = xor <8 x i1> %781, splat (i1 true)
  %784 = and <8 x i1> %775, %783
  %785 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %782)
  %786 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %784)
  %787 = and i1 %785, %786
  br i1 %787, label %varying.divergent753, label %varying.coherent754

schedule.36:                                      ; preds = %varying.coherent.true759, %scheduler.dispatch.route
  %788 = load <8 x i1>, ptr %current.mask, align 1
  %789 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %788)
  %790 = bitcast <8 x i1> %788 to i8
  %791 = call i8 @llvm.cttz.i8(i8 %790, i1 false)
  %792 = zext i8 %791 to i32
  %793 = select i1 %789, i32 %792, i32 0
  %.state761 = load <8 x i64>, ptr %.slot88, align 64
  %794 = select <8 x i1> %788, <8 x i64> %.state761, <8 x i64> zeroinitializer
  %795 = select <8 x i1> %788, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %796 = srem <8 x i64> %794, %795
  %.state762 = load <8 x i64>, ptr %.slot88, align 64
  %797 = select <8 x i1> %788, <8 x i64> %.state762, <8 x i64> zeroinitializer
  %798 = select <8 x i1> %788, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %799 = sdiv <8 x i64> %797, %798
  %800 = add <8 x i64> zeroinitializer, %799
  %801 = mul <8 x i64> %800, splat (i64 32)
  %802 = add <8 x i64> %801, %796
  %tile_snapshot.spill.load763 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %803 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 0
  %804 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load763, 1
  %805 = mul <8 x i64> %802, splat (i64 32)
  %806 = add <8 x i64> %804, %805
  %807 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %803, 0
  %808 = insertvalue { <8 x ptr>, <8 x i64> } %807, <8 x i64> %806, 1
  %809 = extractvalue { <8 x ptr>, <8 x i64> } %808, 0
  %810 = extractvalue { <8 x ptr>, <8 x i64> } %808, 1
  %811 = getelementptr i8, <8 x ptr> %809, <8 x i64> %810
  %812 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %811, i32 1, <8 x i1> %788, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load764 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill82, align 64
  %813 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 0
  %814 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load764, 1
  %815 = mul <8 x i64> %802, splat (i64 32)
  %816 = add <8 x i64> %814, %815
  %817 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %813, 0
  %818 = insertvalue { <8 x ptr>, <8 x i64> } %817, <8 x i64> %816, 1
  %819 = extractvalue { <8 x ptr>, <8 x i64> } %818, 0
  %820 = extractvalue { <8 x ptr>, <8 x i64> } %818, 1
  %821 = getelementptr i8, <8 x ptr> %819, <8 x i64> %820
  %822 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %821, i32 1, <8 x i1> %788, <8 x float> zeroinitializer)
  %823 = fadd <8 x float> %812, %822
  %tile_snapshot.spill.load765 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %824 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load765, 0
  %825 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load765, 1
  %.state766 = load <8 x i64>, ptr %.slot88, align 64
  %826 = mul <8 x i64> %.state766, splat (i64 32)
  %827 = add <8 x i64> %825, %826
  %828 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %824, 0
  %829 = insertvalue { <8 x ptr>, <8 x i64> } %828, <8 x i64> %827, 1
  %830 = extractvalue { <8 x ptr>, <8 x i64> } %829, 0
  %831 = extractvalue { <8 x ptr>, <8 x i64> } %829, 1
  %832 = getelementptr i8, <8 x ptr> %830, <8 x i64> %831
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %823, <8 x ptr> %832, i32 1, <8 x i1> %788)
  %.state767 = load <8 x i64>, ptr %.slot88, align 64
  %833 = add <8 x i64> %.state767, splat (i64 1)
  %834 = load <8 x i64>, ptr %.slot88, align 64
  %835 = select <8 x i1> %788, <8 x i64> %833, <8 x i64> %834
  store <8 x i64> %835, ptr %.slot88, align 64
  store <8 x i1> %788, ptr %current.mask, align 1
  %836 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %788)
  br i1 %836, label %schedule.35, label %scheduler.loop

schedule.37:                                      ; preds = %varying.coherent.false760, %scheduler.dispatch.route
  %837 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token770 = load i32, ptr %current.token, align 4
  %convergence.token.present771 = icmp ne i32 %convergence.current.token770, 0
  br i1 %convergence.token.present771, label %convergence.cascade768, label %convergence.cascade.exit769

schedule.38:                                      ; preds = %convergence.target.41.ready, %convergence.target.37.ready, %scheduler.dispatch.route
  %838 = load <8 x i1>, ptr %current.mask, align 1
  %839 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %838)
  %840 = bitcast <8 x i1> %838 to i8
  %841 = call i8 @llvm.cttz.i8(i8 %840, i1 false)
  %842 = zext i8 %841 to i32
  %843 = select i1 %839, i32 %842, i32 0
  %.state849 = load <8 x i64>, ptr %.slot91, align 64
  %844 = icmp slt <8 x i64> %.state849, splat (i64 128)
  %845 = and <8 x i1> %838, %844
  %846 = xor <8 x i1> %844, splat (i1 true)
  %847 = and <8 x i1> %838, %846
  %848 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %845)
  %849 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %847)
  %850 = and i1 %848, %849
  br i1 %850, label %varying.divergent850, label %varying.coherent851

schedule.39:                                      ; preds = %varying.coherent.true856, %scheduler.dispatch.route
  %851 = load <8 x i1>, ptr %current.mask, align 1
  %852 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %851)
  %853 = bitcast <8 x i1> %851 to i8
  %854 = call i8 @llvm.cttz.i8(i8 %853, i1 false)
  %855 = zext i8 %854 to i32
  %856 = select i1 %852, i32 %855, i32 0
  %.state858 = load <8 x i64>, ptr %.slot91, align 64
  %857 = select <8 x i1> %851, <8 x i64> %.state858, <8 x i64> zeroinitializer
  %858 = select <8 x i1> %851, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %859 = srem <8 x i64> %857, %858
  %.state859 = load <8 x i64>, ptr %.slot91, align 64
  %860 = select <8 x i1> %851, <8 x i64> %.state859, <8 x i64> zeroinitializer
  %861 = select <8 x i1> %851, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %862 = sdiv <8 x i64> %860, %861
  %863 = add <8 x i64> zeroinitializer, %859
  %tile_snapshot.spill.load860 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill89, align 64
  %864 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load860, 0
  %865 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load860, 1
  %866 = mul <8 x i64> %863, splat (i64 64)
  %867 = add <8 x i64> %865, %866
  %868 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %864, 0
  %869 = insertvalue { <8 x ptr>, <8 x i64> } %868, <8 x i64> %867, 1
  %870 = extractvalue { <8 x ptr>, <8 x i64> } %869, 0
  %871 = extractvalue { <8 x ptr>, <8 x i64> } %869, 1
  %872 = getelementptr i8, <8 x ptr> %870, <8 x i64> %871
  %873 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> %872, i32 1, <8 x i1> %851, <8 x i64> zeroinitializer)
  %874 = icmp sge <8 x i64> %873, zeroinitializer
  %875 = icmp slt <8 x i64> %873, splat (i64 32)
  %876 = and <8 x i1> %874, %875
  %877 = load volatile <8 x i1>, ptr %.spill92, align 1
  %878 = select <8 x i1> %851, <8 x i1> %876, <8 x i1> %877
  store volatile <8 x i1> %878, ptr %.spill92, align 1
  %879 = add <8 x i64> zeroinitializer, %862
  %880 = mul <8 x i64> %879, splat (i64 32)
  %881 = add <8 x i64> %880, %873
  %882 = load volatile <8 x i64>, ptr %.spill93, align 64
  %883 = select <8 x i1> %851, <8 x i64> %881, <8 x i64> %882
  store volatile <8 x i64> %883, ptr %.spill93, align 64
  %884 = icmp sge <8 x i64> %881, zeroinitializer
  %885 = icmp slt <8 x i64> %881, splat (i64 128)
  %886 = and <8 x i1> %884, %885
  %887 = and <8 x i1> %851, %886
  %888 = xor <8 x i1> %886, splat (i1 true)
  %889 = and <8 x i1> %851, %888
  %890 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %887)
  %891 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %889)
  %892 = and i1 %890, %891
  br i1 %892, label %varying.divergent861, label %varying.coherent862

schedule.40:                                      ; preds = %varying.coherent.true867, %scheduler.dispatch.route
  %893 = load <8 x i1>, ptr %current.mask, align 1
  %894 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %893)
  %895 = bitcast <8 x i1> %893 to i8
  %896 = call i8 @llvm.cttz.i8(i8 %895, i1 false)
  %897 = zext i8 %896 to i32
  %898 = select i1 %894, i32 %897, i32 0
  %tile_snapshot.spill.load869 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %899 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load869, 0
  %900 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load869, 1
  %.spill.load870 = load volatile <8 x i64>, ptr %.spill93, align 64
  %901 = mul <8 x i64> %.spill.load870, splat (i64 32)
  %902 = add <8 x i64> %900, %901
  %903 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %899, 0
  %904 = insertvalue { <8 x ptr>, <8 x i64> } %903, <8 x i64> %902, 1
  %905 = extractvalue { <8 x ptr>, <8 x i64> } %904, 0
  %906 = extractvalue { <8 x ptr>, <8 x i64> } %904, 1
  %907 = getelementptr i8, <8 x ptr> %905, <8 x i64> %906
  %908 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %907, i32 1, <8 x i1> %893, <8 x float> zeroinitializer)
  %909 = load <8 x float>, ptr %.slot94, align 32
  %910 = select <8 x i1> %893, <8 x float> %908, <8 x float> %909
  store <8 x float> %910, ptr %.slot94, align 32
  store <8 x i1> %893, ptr %current.mask, align 1
  %911 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %893)
  br i1 %911, label %schedule.41, label %scheduler.loop

schedule.41:                                      ; preds = %schedule.40, %varying.coherent.false868, %scheduler.dispatch.route
  %912 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token873 = load i32, ptr %current.token, align 4
  %convergence.token.present874 = icmp ne i32 %convergence.current.token873, 0
  br i1 %convergence.token.present874, label %convergence.cascade871, label %convergence.cascade.exit872

schedule.42:                                      ; preds = %varying.coherent.false857, %scheduler.dispatch.route
  %913 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token898 = load i32, ptr %current.token, align 4
  %convergence.token.present899 = icmp ne i32 %convergence.current.token898, 0
  br i1 %convergence.token.present899, label %convergence.cascade896, label %convergence.cascade.exit897

schedule.43:                                      ; preds = %schedule.44, %convergence.target.42.ready, %scheduler.dispatch.route
  %914 = load <8 x i1>, ptr %current.mask, align 1
  %915 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %914)
  %916 = bitcast <8 x i1> %914 to i8
  %917 = call i8 @llvm.cttz.i8(i8 %916, i1 false)
  %918 = zext i8 %917 to i32
  %919 = select i1 %915, i32 %918, i32 0
  %.state913 = load <8 x i64>, ptr %.slot96, align 64
  %920 = icmp slt <8 x i64> %.state913, splat (i64 128)
  %921 = and <8 x i1> %914, %920
  %922 = xor <8 x i1> %920, splat (i1 true)
  %923 = and <8 x i1> %914, %922
  %924 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %921)
  %925 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %923)
  %926 = and i1 %924, %925
  br i1 %926, label %varying.divergent914, label %varying.coherent915

schedule.44:                                      ; preds = %varying.coherent.true920, %scheduler.dispatch.route
  %927 = load <8 x i1>, ptr %current.mask, align 1
  %928 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %927)
  %929 = bitcast <8 x i1> %927 to i8
  %930 = call i8 @llvm.cttz.i8(i8 %929, i1 false)
  %931 = zext i8 %930 to i32
  %932 = select i1 %928, i32 %931, i32 0
  %.state922 = load <8 x i64>, ptr %.slot96, align 64
  %933 = select <8 x i1> %927, <8 x i64> %.state922, <8 x i64> zeroinitializer
  %934 = select <8 x i1> %927, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %935 = srem <8 x i64> %933, %934
  %.state923 = load <8 x i64>, ptr %.slot96, align 64
  %936 = select <8 x i1> %927, <8 x i64> %.state923, <8 x i64> zeroinitializer
  %937 = select <8 x i1> %927, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %938 = sdiv <8 x i64> %936, %937
  %939 = add <8 x i64> zeroinitializer, %938
  %940 = mul <8 x i64> %939, splat (i64 32)
  %941 = add <8 x i64> %940, %935
  %942 = select <8 x i1> %927, <8 x i64> %941, <8 x i64> zeroinitializer
  %943 = select <8 x i1> %927, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %944 = srem <8 x i64> %942, %943
  %945 = select <8 x i1> %927, <8 x i64> %941, <8 x i64> zeroinitializer
  %946 = select <8 x i1> %927, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %947 = sdiv <8 x i64> %945, %946
  %948 = add <8 x i64> zeroinitializer, %947
  %949 = mul <8 x i64> %948, splat (i64 32)
  %950 = add <8 x i64> %949, %944
  %tile_snapshot.spill.load924 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %951 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load924, 0
  %952 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load924, 1
  %953 = mul <8 x i64> %950, splat (i64 32)
  %954 = add <8 x i64> %952, %953
  %955 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %951, 0
  %956 = insertvalue { <8 x ptr>, <8 x i64> } %955, <8 x i64> %954, 1
  %957 = extractvalue { <8 x ptr>, <8 x i64> } %956, 0
  %958 = extractvalue { <8 x ptr>, <8 x i64> } %956, 1
  %959 = getelementptr i8, <8 x ptr> %957, <8 x i64> %958
  %960 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %959, i32 1, <8 x i1> %927, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load925 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill90, align 64
  %961 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load925, 0
  %962 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load925, 1
  %963 = mul <8 x i64> %950, splat (i64 32)
  %964 = add <8 x i64> %962, %963
  %965 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %961, 0
  %966 = insertvalue { <8 x ptr>, <8 x i64> } %965, <8 x i64> %964, 1
  %967 = extractvalue { <8 x ptr>, <8 x i64> } %966, 0
  %968 = extractvalue { <8 x ptr>, <8 x i64> } %966, 1
  %969 = getelementptr i8, <8 x ptr> %967, <8 x i64> %968
  %970 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %969, i32 1, <8 x i1> %927, <8 x float> zeroinitializer)
  %971 = fadd <8 x float> %960, %970
  %tile_snapshot.spill.load926 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %972 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load926, 0
  %973 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load926, 1
  %974 = mul <8 x i64> %939, splat (i64 32)
  %975 = add <8 x i64> %973, %974
  %976 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %972, 0
  %977 = insertvalue { <8 x ptr>, <8 x i64> } %976, <8 x i64> %975, 1
  %978 = extractvalue { <8 x ptr>, <8 x i64> } %977, 0
  %979 = extractvalue { <8 x ptr>, <8 x i64> } %977, 1
  %980 = getelementptr i8, <8 x ptr> %978, <8 x i64> %979
  %981 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %980, i32 1, <8 x i1> %927, <8 x float> zeroinitializer)
  %982 = fadd <8 x float> %971, %981
  %tile_snapshot.spill.load927 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %983 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load927, 0
  %984 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load927, 1
  %.state928 = load <8 x i64>, ptr %.slot96, align 64
  %985 = mul <8 x i64> %.state928, splat (i64 32)
  %986 = add <8 x i64> %984, %985
  %987 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %983, 0
  %988 = insertvalue { <8 x ptr>, <8 x i64> } %987, <8 x i64> %986, 1
  %989 = extractvalue { <8 x ptr>, <8 x i64> } %988, 0
  %990 = extractvalue { <8 x ptr>, <8 x i64> } %988, 1
  %991 = getelementptr i8, <8 x ptr> %989, <8 x i64> %990
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %982, <8 x ptr> %991, i32 1, <8 x i1> %927)
  %.state929 = load <8 x i64>, ptr %.slot96, align 64
  %992 = add <8 x i64> %.state929, splat (i64 1)
  %993 = load <8 x i64>, ptr %.slot96, align 64
  %994 = select <8 x i1> %927, <8 x i64> %992, <8 x i64> %993
  store <8 x i64> %994, ptr %.slot96, align 64
  store <8 x i1> %927, ptr %current.mask, align 1
  %995 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %927)
  br i1 %995, label %schedule.43, label %scheduler.loop

schedule.45:                                      ; preds = %varying.coherent.false921, %scheduler.dispatch.route
  %996 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token932 = load i32, ptr %current.token, align 4
  %convergence.token.present933 = icmp ne i32 %convergence.current.token932, 0
  br i1 %convergence.token.present933, label %convergence.cascade930, label %convergence.cascade.exit931

schedule.46:                                      ; preds = %schedule.47, %convergence.target.45.ready, %scheduler.dispatch.route
  %997 = load <8 x i1>, ptr %current.mask, align 1
  %998 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %997)
  %999 = bitcast <8 x i1> %997 to i8
  %1000 = call i8 @llvm.cttz.i8(i8 %999, i1 false)
  %1001 = zext i8 %1000 to i32
  %1002 = select i1 %998, i32 %1001, i32 0
  %.state947 = load <8 x i64>, ptr %.slot97, align 64
  %1003 = icmp slt <8 x i64> %.state947, splat (i64 128)
  %1004 = and <8 x i1> %997, %1003
  %1005 = xor <8 x i1> %1003, splat (i1 true)
  %1006 = and <8 x i1> %997, %1005
  %1007 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1004)
  %1008 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1006)
  %1009 = and i1 %1007, %1008
  br i1 %1009, label %varying.divergent948, label %varying.coherent949

schedule.47:                                      ; preds = %varying.coherent.true954, %scheduler.dispatch.route
  %1010 = load <8 x i1>, ptr %current.mask, align 1
  %1011 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1010)
  %1012 = bitcast <8 x i1> %1010 to i8
  %1013 = call i8 @llvm.cttz.i8(i8 %1012, i1 false)
  %1014 = zext i8 %1013 to i32
  %1015 = select i1 %1011, i32 %1014, i32 0
  %.state956 = load <8 x i64>, ptr %.slot97, align 64
  %1016 = select <8 x i1> %1010, <8 x i64> %.state956, <8 x i64> zeroinitializer
  %1017 = select <8 x i1> %1010, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %1018 = srem <8 x i64> %1016, %1017
  %.state957 = load <8 x i64>, ptr %.slot97, align 64
  %1019 = select <8 x i1> %1010, <8 x i64> %.state957, <8 x i64> zeroinitializer
  %1020 = select <8 x i1> %1010, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %1021 = sdiv <8 x i64> %1019, %1020
  %.spill.load958 = load volatile <8 x i64>, ptr %.spill, align 64
  %1022 = add <8 x i64> %.spill.load958, %1021
  %1023 = add <8 x i64> zeroinitializer, %1022
  %.spill.load959 = load volatile <8 x i64>, ptr %.spill54, align 64
  %1024 = add <8 x i64> %.spill.load959, %1018
  %1025 = mul <8 x i64> %1023, splat (i64 1024)
  %1026 = add <8 x i64> %1025, %1024
  %tile_snapshot.spill.load960 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %1027 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load960, 0
  %1028 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load960, 1
  %.state961 = load <8 x i64>, ptr %.slot97, align 64
  %1029 = mul <8 x i64> %.state961, splat (i64 32)
  %1030 = add <8 x i64> %1028, %1029
  %1031 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1027, 0
  %1032 = insertvalue { <8 x ptr>, <8 x i64> } %1031, <8 x i64> %1030, 1
  %1033 = extractvalue { <8 x ptr>, <8 x i64> } %1032, 0
  %1034 = extractvalue { <8 x ptr>, <8 x i64> } %1032, 1
  %1035 = getelementptr i8, <8 x ptr> %1033, <8 x i64> %1034
  %1036 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %1035, i32 1, <8 x i1> %1010, <8 x float> zeroinitializer)
  %1037 = extractvalue { ptr, i64 } %45, 0
  %1038 = mul <8 x i64> %1026, splat (i64 4)
  %1039 = getelementptr i8, ptr %1037, <8 x i64> %1038
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1036, <8 x ptr> %1039, i32 1, <8 x i1> %1010)
  %.state962 = load <8 x i64>, ptr %.slot97, align 64
  %1040 = add <8 x i64> %.state962, splat (i64 1)
  %1041 = load <8 x i64>, ptr %.slot97, align 64
  %1042 = select <8 x i1> %1010, <8 x i64> %1040, <8 x i64> %1041
  store <8 x i64> %1042, ptr %.slot97, align 64
  store <8 x i1> %1010, ptr %current.mask, align 1
  %1043 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1010)
  br i1 %1043, label %schedule.46, label %scheduler.loop

schedule.48:                                      ; preds = %varying.coherent.false955, %scheduler.dispatch.route
  %1044 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token965 = load i32, ptr %current.token, align 4
  %convergence.token.present966 = icmp ne i32 %convergence.current.token965, 0
  br i1 %convergence.token.present966, label %convergence.cascade963, label %convergence.cascade.exit964

schedule.49:                                      ; preds = %varying.coherent.false, %scheduler.dispatch.route
  %1045 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token994 = load i32, ptr %current.token, align 4
  %convergence.token.present995 = icmp ne i32 %convergence.current.token994, 0
  br i1 %convergence.token.present995, label %convergence.cascade992, label %convergence.cascade.exit993

varying.divergent:                                ; preds = %schedule.1
  %1046 = load i32, ptr %current.token, align 4
  %1047 = icmp ne i32 %1046, 0
  %1048 = sub i32 %1046, 1
  %1049 = select i1 %1047, i32 %1048, i32 0
  %1050 = load i8, ptr %frame.active, align 1
  %1051 = trunc i32 %1049 to i8
  %1052 = shl i8 1, %1051
  %1053 = and i8 %1050, %1052
  %1054 = icmp ne i8 %1053, 0
  %1055 = load <8 x i32>, ptr %frame.static.id, align 32
  %1056 = extractelement <8 x i32> %1055, i32 %1049
  %1057 = icmp eq i32 %1056, 0
  %1058 = and i1 %1054, %1057
  %1059 = and i1 %1047, %1058
  %1060 = xor i1 %1059, true
  %1061 = and i1 true, %1060
  %1062 = xor i8 %1050, -1
  %1063 = icmp ne i8 %1062, 0
  %1064 = xor i1 %1063, true
  %1065 = and i1 %1061, %1064
  br i1 %1065, label %convergence.overflow.trap, label %convergence.overflow.resume

varying.coherent:                                 ; preds = %schedule.1
  br i1 %138, label %varying.coherent.true, label %varying.coherent.false

convergence.overflow.trap:                        ; preds = %varying.divergent
  call void @llvm.trap()
  unreachable

convergence.overflow.resume:                      ; preds = %varying.divergent
  %1066 = call i8 @llvm.cttz.i8(i8 %1062, i1 false)
  %1067 = zext i8 %1066 to i32
  %1068 = select i1 %1063, i32 %1067, i32 0
  %1069 = trunc i32 %1068 to i8
  %1070 = shl i8 1, %1069
  %1071 = or i8 %1050, %1070
  %1072 = select i1 %1061, i8 %1071, i8 %1050
  store i8 %1072, ptr %frame.active, align 1
  %1073 = load <8 x i32>, ptr %frame.static.id, align 32
  %1074 = extractelement <8 x i32> %1073, i32 %1068
  %1075 = select i1 %1061, i32 0, i32 %1074
  %1076 = load <8 x i32>, ptr %frame.static.id, align 32
  %1077 = insertelement <8 x i32> %1076, i32 %1075, i32 %1068
  store <8 x i32> %1077, ptr %frame.static.id, align 32
  %1078 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1079 = extractelement <8 x i32> %1078, i32 %1068
  %1080 = select i1 %1061, i32 %1046, i32 %1079
  %1081 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1082 = insertelement <8 x i32> %1081, i32 %1080, i32 %1068
  store <8 x i32> %1082, ptr %frame.parent.token, align 32
  %1083 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1068
  %1084 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1068
  %1085 = load <8 x i1>, ptr %1083, align 1
  %1086 = load <8 x i1>, ptr %1084, align 1
  %1087 = select i1 %1061, <8 x i1> %128, <8 x i1> %1085
  store <8 x i1> %1087, ptr %1083, align 1
  %1088 = select i1 %1061, <8 x i1> zeroinitializer, <8 x i1> %1086
  store <8 x i1> %1088, ptr %1084, align 1
  %1089 = add i32 %1068, 1
  %1090 = select i1 %1059, i32 %1046, i32 %1089
  %1091 = select i1 true, i32 %1090, i32 %1046
  store i32 %1091, ptr %current.token, align 4
  %1092 = load i32, ptr %current.token, align 4
  %1093 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %135)
  %1094 = load i32, ptr %ready.count, align 4
  %1095 = icmp uge i32 %1094, 8
  %1096 = and i1 %1093, %1095
  br i1 %1096, label %ready.overflow.trap108, label %ready.overflow.resume109

ready.overflow.trap108:                           ; preds = %convergence.overflow.resume
  call void @llvm.trap()
  unreachable

ready.overflow.resume109:                         ; preds = %convergence.overflow.resume
  %1097 = select i1 %1093, i32 %1094, i32 0
  %1098 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1097
  %1099 = load <8 x i1>, ptr %1098, align 1
  %1100 = select i1 %1093, <8 x i1> %135, <8 x i1> %1099
  store <8 x i1> %1100, ptr %1098, align 1
  %1101 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1097
  %1102 = load i32, ptr %1101, align 4
  %1103 = select i1 %1093, i32 2, i32 %1102
  store i32 %1103, ptr %1101, align 4
  %1104 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1097
  %1105 = load i32, ptr %1104, align 4
  %1106 = select i1 %1093, i32 %1092, i32 %1105
  store i32 %1106, ptr %1104, align 4
  %1107 = add i32 %1094, 1
  %1108 = select i1 %1093, i32 %1107, i32 %1094
  store i32 %1108, ptr %ready.count, align 4
  %1109 = load <8 x i1>, ptr %runnable.mask, align 1
  %1110 = or <8 x i1> %1109, %135
  store <8 x i1> %1110, ptr %runnable.mask, align 1
  store <8 x i1> %137, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true:                            ; preds = %varying.coherent
  store <8 x i1> %128, ptr %current.mask, align 1
  %1111 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %128)
  br i1 %1111, label %schedule.2, label %scheduler.loop

varying.coherent.false:                           ; preds = %varying.coherent
  store <8 x i1> %128, ptr %current.mask, align 1
  %1112 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %128)
  br i1 %1112, label %schedule.49, label %scheduler.loop

varying.divergent122:                             ; preds = %schedule.3
  %1113 = load i32, ptr %current.token, align 4
  %1114 = icmp ne i32 %1113, 0
  %1115 = sub i32 %1113, 1
  %1116 = select i1 %1114, i32 %1115, i32 0
  %1117 = load i8, ptr %frame.active, align 1
  %1118 = trunc i32 %1116 to i8
  %1119 = shl i8 1, %1118
  %1120 = and i8 %1117, %1119
  %1121 = icmp ne i8 %1120, 0
  %1122 = load <8 x i32>, ptr %frame.static.id, align 32
  %1123 = extractelement <8 x i32> %1122, i32 %1116
  %1124 = icmp eq i32 %1123, 1
  %1125 = and i1 %1121, %1124
  %1126 = and i1 %1114, %1125
  %1127 = xor i1 %1126, true
  %1128 = and i1 true, %1127
  %1129 = xor i8 %1117, -1
  %1130 = icmp ne i8 %1129, 0
  %1131 = xor i1 %1130, true
  %1132 = and i1 %1128, %1131
  br i1 %1132, label %convergence.overflow.trap124, label %convergence.overflow.resume125

varying.coherent123:                              ; preds = %schedule.3
  br i1 %244, label %varying.coherent.true128, label %varying.coherent.false129

convergence.overflow.trap124:                     ; preds = %varying.divergent122
  call void @llvm.trap()
  unreachable

convergence.overflow.resume125:                   ; preds = %varying.divergent122
  %1133 = call i8 @llvm.cttz.i8(i8 %1129, i1 false)
  %1134 = zext i8 %1133 to i32
  %1135 = select i1 %1130, i32 %1134, i32 0
  %1136 = trunc i32 %1135 to i8
  %1137 = shl i8 1, %1136
  %1138 = or i8 %1117, %1137
  %1139 = select i1 %1128, i8 %1138, i8 %1117
  store i8 %1139, ptr %frame.active, align 1
  %1140 = load <8 x i32>, ptr %frame.static.id, align 32
  %1141 = extractelement <8 x i32> %1140, i32 %1135
  %1142 = select i1 %1128, i32 1, i32 %1141
  %1143 = load <8 x i32>, ptr %frame.static.id, align 32
  %1144 = insertelement <8 x i32> %1143, i32 %1142, i32 %1135
  store <8 x i32> %1144, ptr %frame.static.id, align 32
  %1145 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1146 = extractelement <8 x i32> %1145, i32 %1135
  %1147 = select i1 %1128, i32 %1113, i32 %1146
  %1148 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1149 = insertelement <8 x i32> %1148, i32 %1147, i32 %1135
  store <8 x i32> %1149, ptr %frame.parent.token, align 32
  %1150 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1135
  %1151 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1135
  %1152 = load <8 x i1>, ptr %1150, align 1
  %1153 = load <8 x i1>, ptr %1151, align 1
  %1154 = select i1 %1128, <8 x i1> %234, <8 x i1> %1152
  store <8 x i1> %1154, ptr %1150, align 1
  %1155 = select i1 %1128, <8 x i1> zeroinitializer, <8 x i1> %1153
  store <8 x i1> %1155, ptr %1151, align 1
  %1156 = add i32 %1135, 1
  %1157 = select i1 %1126, i32 %1113, i32 %1156
  %1158 = select i1 true, i32 %1157, i32 %1113
  store i32 %1158, ptr %current.token, align 4
  %1159 = load i32, ptr %current.token, align 4
  %1160 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %241)
  %1161 = load i32, ptr %ready.count, align 4
  %1162 = icmp uge i32 %1161, 8
  %1163 = and i1 %1160, %1162
  br i1 %1163, label %ready.overflow.trap126, label %ready.overflow.resume127

ready.overflow.trap126:                           ; preds = %convergence.overflow.resume125
  call void @llvm.trap()
  unreachable

ready.overflow.resume127:                         ; preds = %convergence.overflow.resume125
  %1164 = select i1 %1160, i32 %1161, i32 0
  %1165 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1164
  %1166 = load <8 x i1>, ptr %1165, align 1
  %1167 = select i1 %1160, <8 x i1> %241, <8 x i1> %1166
  store <8 x i1> %1167, ptr %1165, align 1
  %1168 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1164
  %1169 = load i32, ptr %1168, align 4
  %1170 = select i1 %1160, i32 4, i32 %1169
  store i32 %1170, ptr %1168, align 4
  %1171 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1164
  %1172 = load i32, ptr %1171, align 4
  %1173 = select i1 %1160, i32 %1159, i32 %1172
  store i32 %1173, ptr %1171, align 4
  %1174 = add i32 %1161, 1
  %1175 = select i1 %1160, i32 %1174, i32 %1161
  store i32 %1175, ptr %ready.count, align 4
  %1176 = load <8 x i1>, ptr %runnable.mask, align 1
  %1177 = or <8 x i1> %1176, %241
  store <8 x i1> %1177, ptr %runnable.mask, align 1
  store <8 x i1> %243, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true128:                         ; preds = %varying.coherent123
  store <8 x i1> %234, ptr %current.mask, align 1
  %1178 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %234)
  br i1 %1178, label %schedule.4, label %scheduler.loop

varying.coherent.false129:                        ; preds = %varying.coherent123
  store <8 x i1> %234, ptr %current.mask, align 1
  %1179 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %234)
  br i1 %1179, label %schedule.5, label %scheduler.loop

convergence.cascade:                              ; preds = %convergence.cascade, %schedule.5
  %convergence.cascade.flow = phi <8 x i1> [ %281, %schedule.5 ], [ %1222, %convergence.cascade ]
  %convergence.cascade.depth = phi i32 [ 0, %schedule.5 ], [ %1223, %convergence.cascade ]
  %1180 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow)
  %1181 = load i32, ptr %current.token, align 4
  %1182 = icmp ne i32 %1181, 0
  %1183 = and i1 %1180, %1182
  %1184 = sub i32 %1181, 1
  %1185 = select i1 %1183, i32 %1184, i32 0
  %1186 = load i8, ptr %frame.active, align 1
  %1187 = trunc i32 %1185 to i8
  %1188 = shl i8 1, %1187
  %1189 = and i8 %1186, %1188
  %1190 = icmp ne i8 %1189, 0
  %1191 = load <8 x i32>, ptr %frame.static.id, align 32
  %1192 = extractelement <8 x i32> %1191, i32 %1185
  %convergence.target.pointer = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %1192
  %convergence.dynamic.target = load i32, ptr %convergence.target.pointer, align 4
  %1193 = icmp eq i32 %convergence.dynamic.target, 5
  %1194 = and i1 %1190, %1193
  %1195 = and i1 %1183, %1194
  %1196 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1185
  %1197 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1185
  %1198 = load <8 x i1>, ptr %1196, align 1
  %1199 = load <8 x i1>, ptr %1197, align 1
  %1200 = or <8 x i1> %1199, %convergence.cascade.flow
  %1201 = load <8 x i1>, ptr %live.mask, align 1
  %1202 = and <8 x i1> %1198, %1201
  %1203 = icmp eq <8 x i1> %1200, %1202
  %1204 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1203)
  %1205 = and i1 %1195, %1204
  %1206 = select i1 %1205, <8 x i1> zeroinitializer, <8 x i1> %1200
  %1207 = select i1 %1195, <8 x i1> %1206, <8 x i1> %1199
  store <8 x i1> %1207, ptr %1197, align 1
  %1208 = select i1 %1205, <8 x i1> zeroinitializer, <8 x i1> %1198
  store <8 x i1> %1208, ptr %1196, align 1
  %1209 = trunc i32 %1185 to i8
  %1210 = shl i8 1, %1209
  %1211 = xor i8 %1210, -1
  %1212 = and i8 %1186, %1211
  %1213 = select i1 %1205, i8 %1212, i8 %1186
  store i8 %1213, ptr %frame.active, align 1
  %.splatinsert135 = insertelement <8 x i1> poison, i1 %1195, i64 0
  %.splat136 = shufflevector <8 x i1> %.splatinsert135, <8 x i1> poison, <8 x i32> zeroinitializer
  %1214 = and <8 x i1> %convergence.cascade.flow, %.splat136
  %1215 = load <8 x i1>, ptr %runnable.mask, align 1
  %1216 = xor <8 x i1> %1214, splat (i1 true)
  %1217 = and <8 x i1> %1215, %1216
  store <8 x i1> %1217, ptr %runnable.mask, align 1
  %.splatinsert137 = insertelement <8 x i1> poison, i1 %1205, i64 0
  %.splat138 = shufflevector <8 x i1> %.splatinsert137, <8 x i1> poison, <8 x i32> zeroinitializer
  %1218 = select <8 x i1> %.splat138, <8 x i1> %1200, <8 x i1> zeroinitializer
  %1219 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1220 = extractelement <8 x i32> %1219, i32 %1185
  %1221 = select i1 %1205, i32 %1220, i32 %1181
  store i32 %1221, ptr %current.token, align 4
  %.splatinsert139 = insertelement <8 x i1> poison, i1 %1195, i64 0
  %.splat140 = shufflevector <8 x i1> %.splatinsert139, <8 x i1> poison, <8 x i32> zeroinitializer
  %1222 = select <8 x i1> %.splat140, <8 x i1> %1218, <8 x i1> %convergence.cascade.flow
  %1223 = add i32 %convergence.cascade.depth, 1
  %1224 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1222)
  %1225 = icmp ult i32 %1223, 8
  %1226 = and i1 %1224, %1225
  %1227 = and i1 %1195, %1226
  %convergence.parent.token = load i32, ptr %current.token, align 4
  %convergence.parent.present = icmp ne i32 %convergence.parent.token, 0
  %1228 = and i1 %1227, %convergence.parent.present
  br i1 %1228, label %convergence.cascade, label %convergence.cascade.exit

convergence.cascade.exit:                         ; preds = %convergence.cascade, %schedule.5
  %convergence.cascade.result = phi <8 x i1> [ %281, %schedule.5 ], [ %1222, %convergence.cascade ]
  %1229 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %1229, label %convergence.target.5.ready, label %scheduler.loop

convergence.target.5.ready:                       ; preds = %convergence.cascade.exit
  %1230 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1231 = bitcast <8 x i1> %convergence.cascade.result to i8
  %1232 = call i8 @llvm.cttz.i8(i8 %1231, i1 false)
  %1233 = zext i8 %1232 to i32
  %1234 = select i1 %1230, i32 %1233, i32 0
  %1235 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill57, align 64
  %1236 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1237 = extractvalue { <8 x ptr>, <8 x i64> } %1235, 0
  %1238 = select <8 x i1> %convergence.cascade.result, <8 x ptr> %1236, <8 x ptr> %1237
  %1239 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1240 = extractvalue { <8 x ptr>, <8 x i64> } %1235, 1
  %1241 = select <8 x i1> %convergence.cascade.result, <8 x i64> %1239, <8 x i64> %1240
  %1242 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1238, 0
  %1243 = insertvalue { <8 x ptr>, <8 x i64> } %1242, <8 x i64> %1241, 1
  store volatile { <8 x ptr>, <8 x i64> } %1243, ptr %tile_snapshot.spill57, align 64
  %1244 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1245 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1246 = add <8 x i64> %1245, zeroinitializer
  %1247 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1244, 0
  %1248 = insertvalue { <8 x ptr>, <8 x i64> } %1247, <8 x i64> %1246, 1
  %1249 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1250 = extractvalue { <8 x ptr>, <8 x i64> } %1248, 1
  %1251 = extractelement <8 x ptr> %1249, i32 0
  %1252 = extractelement <8 x i64> %1250, i32 %1234
  %1253 = zext i32 %1234 to i64
  %1254 = mul i64 %1253, 8
  %1255 = sub i64 %1252, %1254
  %1256 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1257 = select i1 %1256, i64 %1255, i64 0
  %private.contiguous.address141 = getelementptr i8, ptr %1251, i64 %1257
  %private.contiguous.preserve142 = load <8 x i64>, ptr %private.contiguous.address141, align 8
  %1258 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 -1), <8 x i64> %private.contiguous.preserve142
  store <8 x i64> %1258, ptr %private.contiguous.address141, align 8
  %1259 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1260 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1261 = add <8 x i64> %1260, splat (i64 64)
  %1262 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1259, 0
  %1263 = insertvalue { <8 x ptr>, <8 x i64> } %1262, <8 x i64> %1261, 1
  %1264 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1265 = extractvalue { <8 x ptr>, <8 x i64> } %1263, 1
  %1266 = extractelement <8 x ptr> %1264, i32 0
  %1267 = extractelement <8 x i64> %1265, i32 %1234
  %1268 = zext i32 %1234 to i64
  %1269 = mul i64 %1268, 8
  %1270 = sub i64 %1267, %1269
  %1271 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1272 = select i1 %1271, i64 %1270, i64 0
  %private.contiguous.address143 = getelementptr i8, ptr %1266, i64 %1272
  %private.contiguous.preserve144 = load <8 x i64>, ptr %private.contiguous.address143, align 8
  %1273 = select <8 x i1> %convergence.cascade.result, <8 x i64> zeroinitializer, <8 x i64> %private.contiguous.preserve144
  store <8 x i64> %1273, ptr %private.contiguous.address143, align 8
  %1274 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1275 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1276 = add <8 x i64> %1275, splat (i64 128)
  %1277 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1274, 0
  %1278 = insertvalue { <8 x ptr>, <8 x i64> } %1277, <8 x i64> %1276, 1
  %1279 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1280 = extractvalue { <8 x ptr>, <8 x i64> } %1278, 1
  %1281 = extractelement <8 x ptr> %1279, i32 0
  %1282 = extractelement <8 x i64> %1280, i32 %1234
  %1283 = zext i32 %1234 to i64
  %1284 = mul i64 %1283, 8
  %1285 = sub i64 %1282, %1284
  %1286 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1287 = select i1 %1286, i64 %1285, i64 0
  %private.contiguous.address145 = getelementptr i8, ptr %1281, i64 %1287
  %private.contiguous.preserve146 = load <8 x i64>, ptr %private.contiguous.address145, align 8
  %1288 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 1), <8 x i64> %private.contiguous.preserve146
  store <8 x i64> %1288, ptr %private.contiguous.address145, align 8
  %1289 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1290 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1291 = add <8 x i64> %1290, splat (i64 192)
  %1292 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1289, 0
  %1293 = insertvalue { <8 x ptr>, <8 x i64> } %1292, <8 x i64> %1291, 1
  %1294 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1295 = extractvalue { <8 x ptr>, <8 x i64> } %1293, 1
  %1296 = extractelement <8 x ptr> %1294, i32 0
  %1297 = extractelement <8 x i64> %1295, i32 %1234
  %1298 = zext i32 %1234 to i64
  %1299 = mul i64 %1298, 8
  %1300 = sub i64 %1297, %1299
  %1301 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1302 = select i1 %1301, i64 %1300, i64 0
  %private.contiguous.address147 = getelementptr i8, ptr %1296, i64 %1302
  %private.contiguous.preserve148 = load <8 x i64>, ptr %private.contiguous.address147, align 8
  %1303 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 2), <8 x i64> %private.contiguous.preserve148
  store <8 x i64> %1303, ptr %private.contiguous.address147, align 8
  %1304 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1305 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1306 = add <8 x i64> %1305, splat (i64 256)
  %1307 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1304, 0
  %1308 = insertvalue { <8 x ptr>, <8 x i64> } %1307, <8 x i64> %1306, 1
  %1309 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1310 = extractvalue { <8 x ptr>, <8 x i64> } %1308, 1
  %1311 = extractelement <8 x ptr> %1309, i32 0
  %1312 = extractelement <8 x i64> %1310, i32 %1234
  %1313 = zext i32 %1234 to i64
  %1314 = mul i64 %1313, 8
  %1315 = sub i64 %1312, %1314
  %1316 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1317 = select i1 %1316, i64 %1315, i64 0
  %private.contiguous.address149 = getelementptr i8, ptr %1311, i64 %1317
  %private.contiguous.preserve150 = load <8 x i64>, ptr %private.contiguous.address149, align 8
  %1318 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 3), <8 x i64> %private.contiguous.preserve150
  store <8 x i64> %1318, ptr %private.contiguous.address149, align 8
  %1319 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1320 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1321 = add <8 x i64> %1320, splat (i64 320)
  %1322 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1319, 0
  %1323 = insertvalue { <8 x ptr>, <8 x i64> } %1322, <8 x i64> %1321, 1
  %1324 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1325 = extractvalue { <8 x ptr>, <8 x i64> } %1323, 1
  %1326 = extractelement <8 x ptr> %1324, i32 0
  %1327 = extractelement <8 x i64> %1325, i32 %1234
  %1328 = zext i32 %1234 to i64
  %1329 = mul i64 %1328, 8
  %1330 = sub i64 %1327, %1329
  %1331 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1332 = select i1 %1331, i64 %1330, i64 0
  %private.contiguous.address151 = getelementptr i8, ptr %1326, i64 %1332
  %private.contiguous.preserve152 = load <8 x i64>, ptr %private.contiguous.address151, align 8
  %1333 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 4), <8 x i64> %private.contiguous.preserve152
  store <8 x i64> %1333, ptr %private.contiguous.address151, align 8
  %1334 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1335 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1336 = add <8 x i64> %1335, splat (i64 384)
  %1337 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1334, 0
  %1338 = insertvalue { <8 x ptr>, <8 x i64> } %1337, <8 x i64> %1336, 1
  %1339 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1340 = extractvalue { <8 x ptr>, <8 x i64> } %1338, 1
  %1341 = extractelement <8 x ptr> %1339, i32 0
  %1342 = extractelement <8 x i64> %1340, i32 %1234
  %1343 = zext i32 %1234 to i64
  %1344 = mul i64 %1343, 8
  %1345 = sub i64 %1342, %1344
  %1346 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1347 = select i1 %1346, i64 %1345, i64 0
  %private.contiguous.address153 = getelementptr i8, ptr %1341, i64 %1347
  %private.contiguous.preserve154 = load <8 x i64>, ptr %private.contiguous.address153, align 8
  %1348 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 5), <8 x i64> %private.contiguous.preserve154
  store <8 x i64> %1348, ptr %private.contiguous.address153, align 8
  %1349 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1350 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1351 = add <8 x i64> %1350, splat (i64 448)
  %1352 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1349, 0
  %1353 = insertvalue { <8 x ptr>, <8 x i64> } %1352, <8 x i64> %1351, 1
  %1354 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1355 = extractvalue { <8 x ptr>, <8 x i64> } %1353, 1
  %1356 = extractelement <8 x ptr> %1354, i32 0
  %1357 = extractelement <8 x i64> %1355, i32 %1234
  %1358 = zext i32 %1234 to i64
  %1359 = mul i64 %1358, 8
  %1360 = sub i64 %1357, %1359
  %1361 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1362 = select i1 %1361, i64 %1360, i64 0
  %private.contiguous.address155 = getelementptr i8, ptr %1356, i64 %1362
  %private.contiguous.preserve156 = load <8 x i64>, ptr %private.contiguous.address155, align 8
  %1363 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 6), <8 x i64> %private.contiguous.preserve156
  store <8 x i64> %1363, ptr %private.contiguous.address155, align 8
  %1364 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1365 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1366 = add <8 x i64> %1365, splat (i64 512)
  %1367 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1364, 0
  %1368 = insertvalue { <8 x ptr>, <8 x i64> } %1367, <8 x i64> %1366, 1
  %1369 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1370 = extractvalue { <8 x ptr>, <8 x i64> } %1368, 1
  %1371 = extractelement <8 x ptr> %1369, i32 0
  %1372 = extractelement <8 x i64> %1370, i32 %1234
  %1373 = zext i32 %1234 to i64
  %1374 = mul i64 %1373, 8
  %1375 = sub i64 %1372, %1374
  %1376 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1377 = select i1 %1376, i64 %1375, i64 0
  %private.contiguous.address157 = getelementptr i8, ptr %1371, i64 %1377
  %private.contiguous.preserve158 = load <8 x i64>, ptr %private.contiguous.address157, align 8
  %1378 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 7), <8 x i64> %private.contiguous.preserve158
  store <8 x i64> %1378, ptr %private.contiguous.address157, align 8
  %1379 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1380 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1381 = add <8 x i64> %1380, splat (i64 576)
  %1382 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1379, 0
  %1383 = insertvalue { <8 x ptr>, <8 x i64> } %1382, <8 x i64> %1381, 1
  %1384 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1385 = extractvalue { <8 x ptr>, <8 x i64> } %1383, 1
  %1386 = extractelement <8 x ptr> %1384, i32 0
  %1387 = extractelement <8 x i64> %1385, i32 %1234
  %1388 = zext i32 %1234 to i64
  %1389 = mul i64 %1388, 8
  %1390 = sub i64 %1387, %1389
  %1391 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1392 = select i1 %1391, i64 %1390, i64 0
  %private.contiguous.address159 = getelementptr i8, ptr %1386, i64 %1392
  %private.contiguous.preserve160 = load <8 x i64>, ptr %private.contiguous.address159, align 8
  %1393 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 8), <8 x i64> %private.contiguous.preserve160
  store <8 x i64> %1393, ptr %private.contiguous.address159, align 8
  %1394 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1395 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1396 = add <8 x i64> %1395, splat (i64 640)
  %1397 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1394, 0
  %1398 = insertvalue { <8 x ptr>, <8 x i64> } %1397, <8 x i64> %1396, 1
  %1399 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1400 = extractvalue { <8 x ptr>, <8 x i64> } %1398, 1
  %1401 = extractelement <8 x ptr> %1399, i32 0
  %1402 = extractelement <8 x i64> %1400, i32 %1234
  %1403 = zext i32 %1234 to i64
  %1404 = mul i64 %1403, 8
  %1405 = sub i64 %1402, %1404
  %1406 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1407 = select i1 %1406, i64 %1405, i64 0
  %private.contiguous.address161 = getelementptr i8, ptr %1401, i64 %1407
  %private.contiguous.preserve162 = load <8 x i64>, ptr %private.contiguous.address161, align 8
  %1408 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 9), <8 x i64> %private.contiguous.preserve162
  store <8 x i64> %1408, ptr %private.contiguous.address161, align 8
  %1409 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1410 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1411 = add <8 x i64> %1410, splat (i64 704)
  %1412 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1409, 0
  %1413 = insertvalue { <8 x ptr>, <8 x i64> } %1412, <8 x i64> %1411, 1
  %1414 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1415 = extractvalue { <8 x ptr>, <8 x i64> } %1413, 1
  %1416 = extractelement <8 x ptr> %1414, i32 0
  %1417 = extractelement <8 x i64> %1415, i32 %1234
  %1418 = zext i32 %1234 to i64
  %1419 = mul i64 %1418, 8
  %1420 = sub i64 %1417, %1419
  %1421 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1422 = select i1 %1421, i64 %1420, i64 0
  %private.contiguous.address163 = getelementptr i8, ptr %1416, i64 %1422
  %private.contiguous.preserve164 = load <8 x i64>, ptr %private.contiguous.address163, align 8
  %1423 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 10), <8 x i64> %private.contiguous.preserve164
  store <8 x i64> %1423, ptr %private.contiguous.address163, align 8
  %1424 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1425 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1426 = add <8 x i64> %1425, splat (i64 768)
  %1427 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1424, 0
  %1428 = insertvalue { <8 x ptr>, <8 x i64> } %1427, <8 x i64> %1426, 1
  %1429 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1430 = extractvalue { <8 x ptr>, <8 x i64> } %1428, 1
  %1431 = extractelement <8 x ptr> %1429, i32 0
  %1432 = extractelement <8 x i64> %1430, i32 %1234
  %1433 = zext i32 %1234 to i64
  %1434 = mul i64 %1433, 8
  %1435 = sub i64 %1432, %1434
  %1436 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1437 = select i1 %1436, i64 %1435, i64 0
  %private.contiguous.address165 = getelementptr i8, ptr %1431, i64 %1437
  %private.contiguous.preserve166 = load <8 x i64>, ptr %private.contiguous.address165, align 8
  %1438 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 11), <8 x i64> %private.contiguous.preserve166
  store <8 x i64> %1438, ptr %private.contiguous.address165, align 8
  %1439 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1440 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1441 = add <8 x i64> %1440, splat (i64 832)
  %1442 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1439, 0
  %1443 = insertvalue { <8 x ptr>, <8 x i64> } %1442, <8 x i64> %1441, 1
  %1444 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1445 = extractvalue { <8 x ptr>, <8 x i64> } %1443, 1
  %1446 = extractelement <8 x ptr> %1444, i32 0
  %1447 = extractelement <8 x i64> %1445, i32 %1234
  %1448 = zext i32 %1234 to i64
  %1449 = mul i64 %1448, 8
  %1450 = sub i64 %1447, %1449
  %1451 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1452 = select i1 %1451, i64 %1450, i64 0
  %private.contiguous.address167 = getelementptr i8, ptr %1446, i64 %1452
  %private.contiguous.preserve168 = load <8 x i64>, ptr %private.contiguous.address167, align 8
  %1453 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 12), <8 x i64> %private.contiguous.preserve168
  store <8 x i64> %1453, ptr %private.contiguous.address167, align 8
  %1454 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1455 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1456 = add <8 x i64> %1455, splat (i64 896)
  %1457 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1454, 0
  %1458 = insertvalue { <8 x ptr>, <8 x i64> } %1457, <8 x i64> %1456, 1
  %1459 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1460 = extractvalue { <8 x ptr>, <8 x i64> } %1458, 1
  %1461 = extractelement <8 x ptr> %1459, i32 0
  %1462 = extractelement <8 x i64> %1460, i32 %1234
  %1463 = zext i32 %1234 to i64
  %1464 = mul i64 %1463, 8
  %1465 = sub i64 %1462, %1464
  %1466 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1467 = select i1 %1466, i64 %1465, i64 0
  %private.contiguous.address169 = getelementptr i8, ptr %1461, i64 %1467
  %private.contiguous.preserve170 = load <8 x i64>, ptr %private.contiguous.address169, align 8
  %1468 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 13), <8 x i64> %private.contiguous.preserve170
  store <8 x i64> %1468, ptr %private.contiguous.address169, align 8
  %1469 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1470 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1471 = add <8 x i64> %1470, splat (i64 960)
  %1472 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1469, 0
  %1473 = insertvalue { <8 x ptr>, <8 x i64> } %1472, <8 x i64> %1471, 1
  %1474 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1475 = extractvalue { <8 x ptr>, <8 x i64> } %1473, 1
  %1476 = extractelement <8 x ptr> %1474, i32 0
  %1477 = extractelement <8 x i64> %1475, i32 %1234
  %1478 = zext i32 %1234 to i64
  %1479 = mul i64 %1478, 8
  %1480 = sub i64 %1477, %1479
  %1481 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1482 = select i1 %1481, i64 %1480, i64 0
  %private.contiguous.address171 = getelementptr i8, ptr %1476, i64 %1482
  %private.contiguous.preserve172 = load <8 x i64>, ptr %private.contiguous.address171, align 8
  %1483 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 14), <8 x i64> %private.contiguous.preserve172
  store <8 x i64> %1483, ptr %private.contiguous.address171, align 8
  %1484 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1485 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1486 = add <8 x i64> %1485, splat (i64 1024)
  %1487 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1484, 0
  %1488 = insertvalue { <8 x ptr>, <8 x i64> } %1487, <8 x i64> %1486, 1
  %1489 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1490 = extractvalue { <8 x ptr>, <8 x i64> } %1488, 1
  %1491 = extractelement <8 x ptr> %1489, i32 0
  %1492 = extractelement <8 x i64> %1490, i32 %1234
  %1493 = zext i32 %1234 to i64
  %1494 = mul i64 %1493, 8
  %1495 = sub i64 %1492, %1494
  %1496 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1497 = select i1 %1496, i64 %1495, i64 0
  %private.contiguous.address173 = getelementptr i8, ptr %1491, i64 %1497
  %private.contiguous.preserve174 = load <8 x i64>, ptr %private.contiguous.address173, align 8
  %1498 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 15), <8 x i64> %private.contiguous.preserve174
  store <8 x i64> %1498, ptr %private.contiguous.address173, align 8
  %1499 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1500 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1501 = add <8 x i64> %1500, splat (i64 1088)
  %1502 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1499, 0
  %1503 = insertvalue { <8 x ptr>, <8 x i64> } %1502, <8 x i64> %1501, 1
  %1504 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1505 = extractvalue { <8 x ptr>, <8 x i64> } %1503, 1
  %1506 = extractelement <8 x ptr> %1504, i32 0
  %1507 = extractelement <8 x i64> %1505, i32 %1234
  %1508 = zext i32 %1234 to i64
  %1509 = mul i64 %1508, 8
  %1510 = sub i64 %1507, %1509
  %1511 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1512 = select i1 %1511, i64 %1510, i64 0
  %private.contiguous.address175 = getelementptr i8, ptr %1506, i64 %1512
  %private.contiguous.preserve176 = load <8 x i64>, ptr %private.contiguous.address175, align 8
  %1513 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 16), <8 x i64> %private.contiguous.preserve176
  store <8 x i64> %1513, ptr %private.contiguous.address175, align 8
  %1514 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1515 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1516 = add <8 x i64> %1515, splat (i64 1152)
  %1517 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1514, 0
  %1518 = insertvalue { <8 x ptr>, <8 x i64> } %1517, <8 x i64> %1516, 1
  %1519 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1520 = extractvalue { <8 x ptr>, <8 x i64> } %1518, 1
  %1521 = extractelement <8 x ptr> %1519, i32 0
  %1522 = extractelement <8 x i64> %1520, i32 %1234
  %1523 = zext i32 %1234 to i64
  %1524 = mul i64 %1523, 8
  %1525 = sub i64 %1522, %1524
  %1526 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1527 = select i1 %1526, i64 %1525, i64 0
  %private.contiguous.address177 = getelementptr i8, ptr %1521, i64 %1527
  %private.contiguous.preserve178 = load <8 x i64>, ptr %private.contiguous.address177, align 8
  %1528 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 17), <8 x i64> %private.contiguous.preserve178
  store <8 x i64> %1528, ptr %private.contiguous.address177, align 8
  %1529 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1530 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1531 = add <8 x i64> %1530, splat (i64 1216)
  %1532 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1529, 0
  %1533 = insertvalue { <8 x ptr>, <8 x i64> } %1532, <8 x i64> %1531, 1
  %1534 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1535 = extractvalue { <8 x ptr>, <8 x i64> } %1533, 1
  %1536 = extractelement <8 x ptr> %1534, i32 0
  %1537 = extractelement <8 x i64> %1535, i32 %1234
  %1538 = zext i32 %1234 to i64
  %1539 = mul i64 %1538, 8
  %1540 = sub i64 %1537, %1539
  %1541 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1542 = select i1 %1541, i64 %1540, i64 0
  %private.contiguous.address179 = getelementptr i8, ptr %1536, i64 %1542
  %private.contiguous.preserve180 = load <8 x i64>, ptr %private.contiguous.address179, align 8
  %1543 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 18), <8 x i64> %private.contiguous.preserve180
  store <8 x i64> %1543, ptr %private.contiguous.address179, align 8
  %1544 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1545 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1546 = add <8 x i64> %1545, splat (i64 1280)
  %1547 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1544, 0
  %1548 = insertvalue { <8 x ptr>, <8 x i64> } %1547, <8 x i64> %1546, 1
  %1549 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1550 = extractvalue { <8 x ptr>, <8 x i64> } %1548, 1
  %1551 = extractelement <8 x ptr> %1549, i32 0
  %1552 = extractelement <8 x i64> %1550, i32 %1234
  %1553 = zext i32 %1234 to i64
  %1554 = mul i64 %1553, 8
  %1555 = sub i64 %1552, %1554
  %1556 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1557 = select i1 %1556, i64 %1555, i64 0
  %private.contiguous.address181 = getelementptr i8, ptr %1551, i64 %1557
  %private.contiguous.preserve182 = load <8 x i64>, ptr %private.contiguous.address181, align 8
  %1558 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 19), <8 x i64> %private.contiguous.preserve182
  store <8 x i64> %1558, ptr %private.contiguous.address181, align 8
  %1559 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1560 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1561 = add <8 x i64> %1560, splat (i64 1344)
  %1562 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1559, 0
  %1563 = insertvalue { <8 x ptr>, <8 x i64> } %1562, <8 x i64> %1561, 1
  %1564 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1565 = extractvalue { <8 x ptr>, <8 x i64> } %1563, 1
  %1566 = extractelement <8 x ptr> %1564, i32 0
  %1567 = extractelement <8 x i64> %1565, i32 %1234
  %1568 = zext i32 %1234 to i64
  %1569 = mul i64 %1568, 8
  %1570 = sub i64 %1567, %1569
  %1571 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1572 = select i1 %1571, i64 %1570, i64 0
  %private.contiguous.address183 = getelementptr i8, ptr %1566, i64 %1572
  %private.contiguous.preserve184 = load <8 x i64>, ptr %private.contiguous.address183, align 8
  %1573 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 20), <8 x i64> %private.contiguous.preserve184
  store <8 x i64> %1573, ptr %private.contiguous.address183, align 8
  %1574 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1575 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1576 = add <8 x i64> %1575, splat (i64 1408)
  %1577 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1574, 0
  %1578 = insertvalue { <8 x ptr>, <8 x i64> } %1577, <8 x i64> %1576, 1
  %1579 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1580 = extractvalue { <8 x ptr>, <8 x i64> } %1578, 1
  %1581 = extractelement <8 x ptr> %1579, i32 0
  %1582 = extractelement <8 x i64> %1580, i32 %1234
  %1583 = zext i32 %1234 to i64
  %1584 = mul i64 %1583, 8
  %1585 = sub i64 %1582, %1584
  %1586 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1587 = select i1 %1586, i64 %1585, i64 0
  %private.contiguous.address185 = getelementptr i8, ptr %1581, i64 %1587
  %private.contiguous.preserve186 = load <8 x i64>, ptr %private.contiguous.address185, align 8
  %1588 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 21), <8 x i64> %private.contiguous.preserve186
  store <8 x i64> %1588, ptr %private.contiguous.address185, align 8
  %1589 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1590 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1591 = add <8 x i64> %1590, splat (i64 1472)
  %1592 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1589, 0
  %1593 = insertvalue { <8 x ptr>, <8 x i64> } %1592, <8 x i64> %1591, 1
  %1594 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1595 = extractvalue { <8 x ptr>, <8 x i64> } %1593, 1
  %1596 = extractelement <8 x ptr> %1594, i32 0
  %1597 = extractelement <8 x i64> %1595, i32 %1234
  %1598 = zext i32 %1234 to i64
  %1599 = mul i64 %1598, 8
  %1600 = sub i64 %1597, %1599
  %1601 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1602 = select i1 %1601, i64 %1600, i64 0
  %private.contiguous.address187 = getelementptr i8, ptr %1596, i64 %1602
  %private.contiguous.preserve188 = load <8 x i64>, ptr %private.contiguous.address187, align 8
  %1603 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 22), <8 x i64> %private.contiguous.preserve188
  store <8 x i64> %1603, ptr %private.contiguous.address187, align 8
  %1604 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1605 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1606 = add <8 x i64> %1605, splat (i64 1536)
  %1607 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1604, 0
  %1608 = insertvalue { <8 x ptr>, <8 x i64> } %1607, <8 x i64> %1606, 1
  %1609 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1610 = extractvalue { <8 x ptr>, <8 x i64> } %1608, 1
  %1611 = extractelement <8 x ptr> %1609, i32 0
  %1612 = extractelement <8 x i64> %1610, i32 %1234
  %1613 = zext i32 %1234 to i64
  %1614 = mul i64 %1613, 8
  %1615 = sub i64 %1612, %1614
  %1616 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1617 = select i1 %1616, i64 %1615, i64 0
  %private.contiguous.address189 = getelementptr i8, ptr %1611, i64 %1617
  %private.contiguous.preserve190 = load <8 x i64>, ptr %private.contiguous.address189, align 8
  %1618 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 23), <8 x i64> %private.contiguous.preserve190
  store <8 x i64> %1618, ptr %private.contiguous.address189, align 8
  %1619 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1620 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1621 = add <8 x i64> %1620, splat (i64 1600)
  %1622 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1619, 0
  %1623 = insertvalue { <8 x ptr>, <8 x i64> } %1622, <8 x i64> %1621, 1
  %1624 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1625 = extractvalue { <8 x ptr>, <8 x i64> } %1623, 1
  %1626 = extractelement <8 x ptr> %1624, i32 0
  %1627 = extractelement <8 x i64> %1625, i32 %1234
  %1628 = zext i32 %1234 to i64
  %1629 = mul i64 %1628, 8
  %1630 = sub i64 %1627, %1629
  %1631 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1632 = select i1 %1631, i64 %1630, i64 0
  %private.contiguous.address191 = getelementptr i8, ptr %1626, i64 %1632
  %private.contiguous.preserve192 = load <8 x i64>, ptr %private.contiguous.address191, align 8
  %1633 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 24), <8 x i64> %private.contiguous.preserve192
  store <8 x i64> %1633, ptr %private.contiguous.address191, align 8
  %1634 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1635 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1636 = add <8 x i64> %1635, splat (i64 1664)
  %1637 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1634, 0
  %1638 = insertvalue { <8 x ptr>, <8 x i64> } %1637, <8 x i64> %1636, 1
  %1639 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1640 = extractvalue { <8 x ptr>, <8 x i64> } %1638, 1
  %1641 = extractelement <8 x ptr> %1639, i32 0
  %1642 = extractelement <8 x i64> %1640, i32 %1234
  %1643 = zext i32 %1234 to i64
  %1644 = mul i64 %1643, 8
  %1645 = sub i64 %1642, %1644
  %1646 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1647 = select i1 %1646, i64 %1645, i64 0
  %private.contiguous.address193 = getelementptr i8, ptr %1641, i64 %1647
  %private.contiguous.preserve194 = load <8 x i64>, ptr %private.contiguous.address193, align 8
  %1648 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 25), <8 x i64> %private.contiguous.preserve194
  store <8 x i64> %1648, ptr %private.contiguous.address193, align 8
  %1649 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1650 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1651 = add <8 x i64> %1650, splat (i64 1728)
  %1652 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1649, 0
  %1653 = insertvalue { <8 x ptr>, <8 x i64> } %1652, <8 x i64> %1651, 1
  %1654 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1655 = extractvalue { <8 x ptr>, <8 x i64> } %1653, 1
  %1656 = extractelement <8 x ptr> %1654, i32 0
  %1657 = extractelement <8 x i64> %1655, i32 %1234
  %1658 = zext i32 %1234 to i64
  %1659 = mul i64 %1658, 8
  %1660 = sub i64 %1657, %1659
  %1661 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1662 = select i1 %1661, i64 %1660, i64 0
  %private.contiguous.address195 = getelementptr i8, ptr %1656, i64 %1662
  %private.contiguous.preserve196 = load <8 x i64>, ptr %private.contiguous.address195, align 8
  %1663 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 26), <8 x i64> %private.contiguous.preserve196
  store <8 x i64> %1663, ptr %private.contiguous.address195, align 8
  %1664 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1665 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1666 = add <8 x i64> %1665, splat (i64 1792)
  %1667 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1664, 0
  %1668 = insertvalue { <8 x ptr>, <8 x i64> } %1667, <8 x i64> %1666, 1
  %1669 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1670 = extractvalue { <8 x ptr>, <8 x i64> } %1668, 1
  %1671 = extractelement <8 x ptr> %1669, i32 0
  %1672 = extractelement <8 x i64> %1670, i32 %1234
  %1673 = zext i32 %1234 to i64
  %1674 = mul i64 %1673, 8
  %1675 = sub i64 %1672, %1674
  %1676 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1677 = select i1 %1676, i64 %1675, i64 0
  %private.contiguous.address197 = getelementptr i8, ptr %1671, i64 %1677
  %private.contiguous.preserve198 = load <8 x i64>, ptr %private.contiguous.address197, align 8
  %1678 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 27), <8 x i64> %private.contiguous.preserve198
  store <8 x i64> %1678, ptr %private.contiguous.address197, align 8
  %1679 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1680 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1681 = add <8 x i64> %1680, splat (i64 1856)
  %1682 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1679, 0
  %1683 = insertvalue { <8 x ptr>, <8 x i64> } %1682, <8 x i64> %1681, 1
  %1684 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1685 = extractvalue { <8 x ptr>, <8 x i64> } %1683, 1
  %1686 = extractelement <8 x ptr> %1684, i32 0
  %1687 = extractelement <8 x i64> %1685, i32 %1234
  %1688 = zext i32 %1234 to i64
  %1689 = mul i64 %1688, 8
  %1690 = sub i64 %1687, %1689
  %1691 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1692 = select i1 %1691, i64 %1690, i64 0
  %private.contiguous.address199 = getelementptr i8, ptr %1686, i64 %1692
  %private.contiguous.preserve200 = load <8 x i64>, ptr %private.contiguous.address199, align 8
  %1693 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 28), <8 x i64> %private.contiguous.preserve200
  store <8 x i64> %1693, ptr %private.contiguous.address199, align 8
  %1694 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1695 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1696 = add <8 x i64> %1695, splat (i64 1920)
  %1697 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1694, 0
  %1698 = insertvalue { <8 x ptr>, <8 x i64> } %1697, <8 x i64> %1696, 1
  %1699 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1700 = extractvalue { <8 x ptr>, <8 x i64> } %1698, 1
  %1701 = extractelement <8 x ptr> %1699, i32 0
  %1702 = extractelement <8 x i64> %1700, i32 %1234
  %1703 = zext i32 %1234 to i64
  %1704 = mul i64 %1703, 8
  %1705 = sub i64 %1702, %1704
  %1706 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1707 = select i1 %1706, i64 %1705, i64 0
  %private.contiguous.address201 = getelementptr i8, ptr %1701, i64 %1707
  %private.contiguous.preserve202 = load <8 x i64>, ptr %private.contiguous.address201, align 8
  %1708 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 29), <8 x i64> %private.contiguous.preserve202
  store <8 x i64> %1708, ptr %private.contiguous.address201, align 8
  %1709 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1710 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1711 = add <8 x i64> %1710, splat (i64 1984)
  %1712 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1709, 0
  %1713 = insertvalue { <8 x ptr>, <8 x i64> } %1712, <8 x i64> %1711, 1
  %1714 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1715 = extractvalue { <8 x ptr>, <8 x i64> } %1713, 1
  %1716 = extractelement <8 x ptr> %1714, i32 0
  %1717 = extractelement <8 x i64> %1715, i32 %1234
  %1718 = zext i32 %1234 to i64
  %1719 = mul i64 %1718, 8
  %1720 = sub i64 %1717, %1719
  %1721 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1722 = select i1 %1721, i64 %1720, i64 0
  %private.contiguous.address203 = getelementptr i8, ptr %1716, i64 %1722
  %private.contiguous.preserve204 = load <8 x i64>, ptr %private.contiguous.address203, align 8
  %1723 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 30), <8 x i64> %private.contiguous.preserve204
  store <8 x i64> %1723, ptr %private.contiguous.address203, align 8
  %1724 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill58, align 64
  %1725 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1726 = extractvalue { <8 x ptr>, <8 x i64> } %1724, 0
  %1727 = select <8 x i1> %convergence.cascade.result, <8 x ptr> %1725, <8 x ptr> %1726
  %1728 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %1729 = extractvalue { <8 x ptr>, <8 x i64> } %1724, 1
  %1730 = select <8 x i1> %convergence.cascade.result, <8 x i64> %1728, <8 x i64> %1729
  %1731 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1727, 0
  %1732 = insertvalue { <8 x ptr>, <8 x i64> } %1731, <8 x i64> %1730, 1
  store volatile { <8 x ptr>, <8 x i64> } %1732, ptr %tile_snapshot.spill58, align 64
  %1733 = load <8 x i64>, ptr %.slot59, align 64
  %1734 = select <8 x i1> %convergence.cascade.result, <8 x i64> zeroinitializer, <8 x i64> %1733
  store <8 x i64> %1734, ptr %.slot59, align 64
  store <8 x i1> %convergence.cascade.result, ptr %current.mask, align 1
  %1735 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %1735, label %schedule.6, label %scheduler.loop

varying.divergent206:                             ; preds = %schedule.6
  %1736 = load i32, ptr %current.token, align 4
  %1737 = icmp ne i32 %1736, 0
  %1738 = sub i32 %1736, 1
  %1739 = select i1 %1737, i32 %1738, i32 0
  %1740 = load i8, ptr %frame.active, align 1
  %1741 = trunc i32 %1739 to i8
  %1742 = shl i8 1, %1741
  %1743 = and i8 %1740, %1742
  %1744 = icmp ne i8 %1743, 0
  %1745 = load <8 x i32>, ptr %frame.static.id, align 32
  %1746 = extractelement <8 x i32> %1745, i32 %1739
  %1747 = icmp eq i32 %1746, 2
  %1748 = and i1 %1744, %1747
  %1749 = and i1 %1737, %1748
  %1750 = xor i1 %1749, true
  %1751 = and i1 true, %1750
  %1752 = xor i8 %1740, -1
  %1753 = icmp ne i8 %1752, 0
  %1754 = xor i1 %1753, true
  %1755 = and i1 %1751, %1754
  br i1 %1755, label %convergence.overflow.trap208, label %convergence.overflow.resume209

varying.coherent207:                              ; preds = %schedule.6
  br i1 %292, label %varying.coherent.true212, label %varying.coherent.false213

convergence.overflow.trap208:                     ; preds = %varying.divergent206
  call void @llvm.trap()
  unreachable

convergence.overflow.resume209:                   ; preds = %varying.divergent206
  %1756 = call i8 @llvm.cttz.i8(i8 %1752, i1 false)
  %1757 = zext i8 %1756 to i32
  %1758 = select i1 %1753, i32 %1757, i32 0
  %1759 = trunc i32 %1758 to i8
  %1760 = shl i8 1, %1759
  %1761 = or i8 %1740, %1760
  %1762 = select i1 %1751, i8 %1761, i8 %1740
  store i8 %1762, ptr %frame.active, align 1
  %1763 = load <8 x i32>, ptr %frame.static.id, align 32
  %1764 = extractelement <8 x i32> %1763, i32 %1758
  %1765 = select i1 %1751, i32 2, i32 %1764
  %1766 = load <8 x i32>, ptr %frame.static.id, align 32
  %1767 = insertelement <8 x i32> %1766, i32 %1765, i32 %1758
  store <8 x i32> %1767, ptr %frame.static.id, align 32
  %1768 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1769 = extractelement <8 x i32> %1768, i32 %1758
  %1770 = select i1 %1751, i32 %1736, i32 %1769
  %1771 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1772 = insertelement <8 x i32> %1771, i32 %1770, i32 %1758
  store <8 x i32> %1772, ptr %frame.parent.token, align 32
  %1773 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1758
  %1774 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1758
  %1775 = load <8 x i1>, ptr %1773, align 1
  %1776 = load <8 x i1>, ptr %1774, align 1
  %1777 = select i1 %1751, <8 x i1> %282, <8 x i1> %1775
  store <8 x i1> %1777, ptr %1773, align 1
  %1778 = select i1 %1751, <8 x i1> zeroinitializer, <8 x i1> %1776
  store <8 x i1> %1778, ptr %1774, align 1
  %1779 = add i32 %1758, 1
  %1780 = select i1 %1749, i32 %1736, i32 %1779
  %1781 = select i1 true, i32 %1780, i32 %1736
  store i32 %1781, ptr %current.token, align 4
  %1782 = load i32, ptr %current.token, align 4
  %1783 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %289)
  %1784 = load i32, ptr %ready.count, align 4
  %1785 = icmp uge i32 %1784, 8
  %1786 = and i1 %1783, %1785
  br i1 %1786, label %ready.overflow.trap210, label %ready.overflow.resume211

ready.overflow.trap210:                           ; preds = %convergence.overflow.resume209
  call void @llvm.trap()
  unreachable

ready.overflow.resume211:                         ; preds = %convergence.overflow.resume209
  %1787 = select i1 %1783, i32 %1784, i32 0
  %1788 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1787
  %1789 = load <8 x i1>, ptr %1788, align 1
  %1790 = select i1 %1783, <8 x i1> %289, <8 x i1> %1789
  store <8 x i1> %1790, ptr %1788, align 1
  %1791 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1787
  %1792 = load i32, ptr %1791, align 4
  %1793 = select i1 %1783, i32 7, i32 %1792
  store i32 %1793, ptr %1791, align 4
  %1794 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1787
  %1795 = load i32, ptr %1794, align 4
  %1796 = select i1 %1783, i32 %1782, i32 %1795
  store i32 %1796, ptr %1794, align 4
  %1797 = add i32 %1784, 1
  %1798 = select i1 %1783, i32 %1797, i32 %1784
  store i32 %1798, ptr %ready.count, align 4
  %1799 = load <8 x i1>, ptr %runnable.mask, align 1
  %1800 = or <8 x i1> %1799, %289
  store <8 x i1> %1800, ptr %runnable.mask, align 1
  store <8 x i1> %291, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true212:                         ; preds = %varying.coherent207
  store <8 x i1> %282, ptr %current.mask, align 1
  %1801 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %282)
  br i1 %1801, label %schedule.7, label %scheduler.loop

varying.coherent.false213:                        ; preds = %varying.coherent207
  store <8 x i1> %282, ptr %current.mask, align 1
  %1802 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %282)
  br i1 %1802, label %schedule.10, label %scheduler.loop

varying.divergent217:                             ; preds = %schedule.7
  %1803 = load i32, ptr %current.token, align 4
  %1804 = icmp ne i32 %1803, 0
  %1805 = sub i32 %1803, 1
  %1806 = select i1 %1804, i32 %1805, i32 0
  %1807 = load i8, ptr %frame.active, align 1
  %1808 = trunc i32 %1806 to i8
  %1809 = shl i8 1, %1808
  %1810 = and i8 %1807, %1809
  %1811 = icmp ne i8 %1810, 0
  %1812 = load <8 x i32>, ptr %frame.static.id, align 32
  %1813 = extractelement <8 x i32> %1812, i32 %1806
  %1814 = icmp eq i32 %1813, 3
  %1815 = and i1 %1811, %1814
  %1816 = and i1 %1804, %1815
  %1817 = xor i1 %1816, true
  %1818 = and i1 true, %1817
  %1819 = xor i8 %1807, -1
  %1820 = icmp ne i8 %1819, 0
  %1821 = xor i1 %1820, true
  %1822 = and i1 %1818, %1821
  br i1 %1822, label %convergence.overflow.trap219, label %convergence.overflow.resume220

varying.coherent218:                              ; preds = %schedule.7
  br i1 %334, label %varying.coherent.true223, label %varying.coherent.false224

convergence.overflow.trap219:                     ; preds = %varying.divergent217
  call void @llvm.trap()
  unreachable

convergence.overflow.resume220:                   ; preds = %varying.divergent217
  %1823 = call i8 @llvm.cttz.i8(i8 %1819, i1 false)
  %1824 = zext i8 %1823 to i32
  %1825 = select i1 %1820, i32 %1824, i32 0
  %1826 = trunc i32 %1825 to i8
  %1827 = shl i8 1, %1826
  %1828 = or i8 %1807, %1827
  %1829 = select i1 %1818, i8 %1828, i8 %1807
  store i8 %1829, ptr %frame.active, align 1
  %1830 = load <8 x i32>, ptr %frame.static.id, align 32
  %1831 = extractelement <8 x i32> %1830, i32 %1825
  %1832 = select i1 %1818, i32 3, i32 %1831
  %1833 = load <8 x i32>, ptr %frame.static.id, align 32
  %1834 = insertelement <8 x i32> %1833, i32 %1832, i32 %1825
  store <8 x i32> %1834, ptr %frame.static.id, align 32
  %1835 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1836 = extractelement <8 x i32> %1835, i32 %1825
  %1837 = select i1 %1818, i32 %1803, i32 %1836
  %1838 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1839 = insertelement <8 x i32> %1838, i32 %1837, i32 %1825
  store <8 x i32> %1839, ptr %frame.parent.token, align 32
  %1840 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1825
  %1841 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1825
  %1842 = load <8 x i1>, ptr %1840, align 1
  %1843 = load <8 x i1>, ptr %1841, align 1
  %1844 = select i1 %1818, <8 x i1> %295, <8 x i1> %1842
  store <8 x i1> %1844, ptr %1840, align 1
  %1845 = select i1 %1818, <8 x i1> zeroinitializer, <8 x i1> %1843
  store <8 x i1> %1845, ptr %1841, align 1
  %1846 = add i32 %1825, 1
  %1847 = select i1 %1816, i32 %1803, i32 %1846
  %1848 = select i1 true, i32 %1847, i32 %1803
  store i32 %1848, ptr %current.token, align 4
  %1849 = load <8 x float>, ptr %.slot62, align 32
  %1850 = select <8 x i1> %333, <8 x float> zeroinitializer, <8 x float> %1849
  store <8 x float> %1850, ptr %.slot62, align 32
  %1851 = load i32, ptr %current.token, align 4
  %1852 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %331)
  %1853 = load i32, ptr %ready.count, align 4
  %1854 = icmp uge i32 %1853, 8
  %1855 = and i1 %1852, %1854
  br i1 %1855, label %ready.overflow.trap221, label %ready.overflow.resume222

ready.overflow.trap221:                           ; preds = %convergence.overflow.resume220
  call void @llvm.trap()
  unreachable

ready.overflow.resume222:                         ; preds = %convergence.overflow.resume220
  %1856 = select i1 %1852, i32 %1853, i32 0
  %1857 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1856
  %1858 = load <8 x i1>, ptr %1857, align 1
  %1859 = select i1 %1852, <8 x i1> %331, <8 x i1> %1858
  store <8 x i1> %1859, ptr %1857, align 1
  %1860 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1856
  %1861 = load i32, ptr %1860, align 4
  %1862 = select i1 %1852, i32 8, i32 %1861
  store i32 %1862, ptr %1860, align 4
  %1863 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1856
  %1864 = load i32, ptr %1863, align 4
  %1865 = select i1 %1852, i32 %1851, i32 %1864
  store i32 %1865, ptr %1863, align 4
  %1866 = add i32 %1853, 1
  %1867 = select i1 %1852, i32 %1866, i32 %1853
  store i32 %1867, ptr %ready.count, align 4
  %1868 = load <8 x i1>, ptr %runnable.mask, align 1
  %1869 = or <8 x i1> %1868, %331
  store <8 x i1> %1869, ptr %runnable.mask, align 1
  store <8 x i1> %333, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true223:                         ; preds = %varying.coherent218
  store <8 x i1> %295, ptr %current.mask, align 1
  %1870 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %295)
  br i1 %1870, label %schedule.8, label %scheduler.loop

varying.coherent.false224:                        ; preds = %varying.coherent218
  %1871 = load <8 x float>, ptr %.slot62, align 32
  %1872 = select <8 x i1> %295, <8 x float> zeroinitializer, <8 x float> %1871
  store <8 x float> %1872, ptr %.slot62, align 32
  store <8 x i1> %295, ptr %current.mask, align 1
  %1873 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %295)
  br i1 %1873, label %schedule.9, label %scheduler.loop

convergence.cascade227:                           ; preds = %convergence.cascade227, %schedule.9
  %convergence.cascade.flow231 = phi <8 x i1> [ %356, %schedule.9 ], [ %1916, %convergence.cascade227 ]
  %convergence.cascade.depth232 = phi i32 [ 0, %schedule.9 ], [ %1917, %convergence.cascade227 ]
  %1874 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow231)
  %1875 = load i32, ptr %current.token, align 4
  %1876 = icmp ne i32 %1875, 0
  %1877 = and i1 %1874, %1876
  %1878 = sub i32 %1875, 1
  %1879 = select i1 %1877, i32 %1878, i32 0
  %1880 = load i8, ptr %frame.active, align 1
  %1881 = trunc i32 %1879 to i8
  %1882 = shl i8 1, %1881
  %1883 = and i8 %1880, %1882
  %1884 = icmp ne i8 %1883, 0
  %1885 = load <8 x i32>, ptr %frame.static.id, align 32
  %1886 = extractelement <8 x i32> %1885, i32 %1879
  %convergence.target.pointer233 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %1886
  %convergence.dynamic.target234 = load i32, ptr %convergence.target.pointer233, align 4
  %1887 = icmp eq i32 %convergence.dynamic.target234, 9
  %1888 = and i1 %1884, %1887
  %1889 = and i1 %1877, %1888
  %1890 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1879
  %1891 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1879
  %1892 = load <8 x i1>, ptr %1890, align 1
  %1893 = load <8 x i1>, ptr %1891, align 1
  %1894 = or <8 x i1> %1893, %convergence.cascade.flow231
  %1895 = load <8 x i1>, ptr %live.mask, align 1
  %1896 = and <8 x i1> %1892, %1895
  %1897 = icmp eq <8 x i1> %1894, %1896
  %1898 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1897)
  %1899 = and i1 %1889, %1898
  %1900 = select i1 %1899, <8 x i1> zeroinitializer, <8 x i1> %1894
  %1901 = select i1 %1889, <8 x i1> %1900, <8 x i1> %1893
  store <8 x i1> %1901, ptr %1891, align 1
  %1902 = select i1 %1899, <8 x i1> zeroinitializer, <8 x i1> %1892
  store <8 x i1> %1902, ptr %1890, align 1
  %1903 = trunc i32 %1879 to i8
  %1904 = shl i8 1, %1903
  %1905 = xor i8 %1904, -1
  %1906 = and i8 %1880, %1905
  %1907 = select i1 %1899, i8 %1906, i8 %1880
  store i8 %1907, ptr %frame.active, align 1
  %.splatinsert235 = insertelement <8 x i1> poison, i1 %1889, i64 0
  %.splat236 = shufflevector <8 x i1> %.splatinsert235, <8 x i1> poison, <8 x i32> zeroinitializer
  %1908 = and <8 x i1> %convergence.cascade.flow231, %.splat236
  %1909 = load <8 x i1>, ptr %runnable.mask, align 1
  %1910 = xor <8 x i1> %1908, splat (i1 true)
  %1911 = and <8 x i1> %1909, %1910
  store <8 x i1> %1911, ptr %runnable.mask, align 1
  %.splatinsert237 = insertelement <8 x i1> poison, i1 %1899, i64 0
  %.splat238 = shufflevector <8 x i1> %.splatinsert237, <8 x i1> poison, <8 x i32> zeroinitializer
  %1912 = select <8 x i1> %.splat238, <8 x i1> %1894, <8 x i1> zeroinitializer
  %1913 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1914 = extractelement <8 x i32> %1913, i32 %1879
  %1915 = select i1 %1899, i32 %1914, i32 %1875
  store i32 %1915, ptr %current.token, align 4
  %.splatinsert239 = insertelement <8 x i1> poison, i1 %1889, i64 0
  %.splat240 = shufflevector <8 x i1> %.splatinsert239, <8 x i1> poison, <8 x i32> zeroinitializer
  %1916 = select <8 x i1> %.splat240, <8 x i1> %1912, <8 x i1> %convergence.cascade.flow231
  %1917 = add i32 %convergence.cascade.depth232, 1
  %1918 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1916)
  %1919 = icmp ult i32 %1917, 8
  %1920 = and i1 %1918, %1919
  %1921 = and i1 %1889, %1920
  %convergence.parent.token241 = load i32, ptr %current.token, align 4
  %convergence.parent.present242 = icmp ne i32 %convergence.parent.token241, 0
  %1922 = and i1 %1921, %convergence.parent.present242
  br i1 %1922, label %convergence.cascade227, label %convergence.cascade.exit228

convergence.cascade.exit228:                      ; preds = %convergence.cascade227, %schedule.9
  %convergence.cascade.result243 = phi <8 x i1> [ %356, %schedule.9 ], [ %1916, %convergence.cascade227 ]
  %1923 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result243)
  br i1 %1923, label %convergence.target.9.ready, label %scheduler.loop

convergence.target.9.ready:                       ; preds = %convergence.cascade.exit228
  %1924 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result243)
  %1925 = bitcast <8 x i1> %convergence.cascade.result243 to i8
  %1926 = call i8 @llvm.cttz.i8(i8 %1925, i1 false)
  %1927 = zext i8 %1926 to i32
  %1928 = select i1 %1924, i32 %1927, i32 0
  %.spill.load244 = load float, ptr %.spill49, align 4
  %.splatinsert245 = insertelement <8 x float> poison, float %.spill.load244, i64 0
  %.splat246 = shufflevector <8 x float> %.splatinsert245, <8 x float> poison, <8 x i32> zeroinitializer
  %.state247 = load <8 x float>, ptr %.slot62, align 32
  %.spill.load248 = load volatile <8 x i1>, ptr %.spill60, align 1
  %1929 = select <8 x i1> %.spill.load248, <8 x float> %.state247, <8 x float> %.splat246
  %tile_snapshot.spill.load249 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill58, align 64
  %1930 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load249, 0
  %1931 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load249, 1
  %.state250 = load <8 x i64>, ptr %.slot59, align 64
  %1932 = mul <8 x i64> %.state250, splat (i64 32)
  %1933 = add <8 x i64> %1931, %1932
  %1934 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1930, 0
  %1935 = insertvalue { <8 x ptr>, <8 x i64> } %1934, <8 x i64> %1933, 1
  %1936 = extractvalue { <8 x ptr>, <8 x i64> } %1935, 0
  %1937 = extractvalue { <8 x ptr>, <8 x i64> } %1935, 1
  %1938 = getelementptr i8, <8 x ptr> %1936, <8 x i64> %1937
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1929, <8 x ptr> %1938, i32 1, <8 x i1> %convergence.cascade.result243)
  %.state251 = load <8 x i64>, ptr %.slot59, align 64
  %1939 = add <8 x i64> %.state251, splat (i64 1)
  %1940 = load <8 x i64>, ptr %.slot59, align 64
  %1941 = select <8 x i1> %convergence.cascade.result243, <8 x i64> %1939, <8 x i64> %1940
  store <8 x i64> %1941, ptr %.slot59, align 64
  store <8 x i1> %convergence.cascade.result243, ptr %current.mask, align 1
  %1942 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result243)
  br i1 %1942, label %schedule.6, label %scheduler.loop

convergence.cascade252:                           ; preds = %convergence.cascade252, %schedule.10
  %convergence.cascade.flow256 = phi <8 x i1> [ %357, %schedule.10 ], [ %1985, %convergence.cascade252 ]
  %convergence.cascade.depth257 = phi i32 [ 0, %schedule.10 ], [ %1986, %convergence.cascade252 ]
  %1943 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow256)
  %1944 = load i32, ptr %current.token, align 4
  %1945 = icmp ne i32 %1944, 0
  %1946 = and i1 %1943, %1945
  %1947 = sub i32 %1944, 1
  %1948 = select i1 %1946, i32 %1947, i32 0
  %1949 = load i8, ptr %frame.active, align 1
  %1950 = trunc i32 %1948 to i8
  %1951 = shl i8 1, %1950
  %1952 = and i8 %1949, %1951
  %1953 = icmp ne i8 %1952, 0
  %1954 = load <8 x i32>, ptr %frame.static.id, align 32
  %1955 = extractelement <8 x i32> %1954, i32 %1948
  %convergence.target.pointer258 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %1955
  %convergence.dynamic.target259 = load i32, ptr %convergence.target.pointer258, align 4
  %1956 = icmp eq i32 %convergence.dynamic.target259, 10
  %1957 = and i1 %1953, %1956
  %1958 = and i1 %1946, %1957
  %1959 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1948
  %1960 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1948
  %1961 = load <8 x i1>, ptr %1959, align 1
  %1962 = load <8 x i1>, ptr %1960, align 1
  %1963 = or <8 x i1> %1962, %convergence.cascade.flow256
  %1964 = load <8 x i1>, ptr %live.mask, align 1
  %1965 = and <8 x i1> %1961, %1964
  %1966 = icmp eq <8 x i1> %1963, %1965
  %1967 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1966)
  %1968 = and i1 %1958, %1967
  %1969 = select i1 %1968, <8 x i1> zeroinitializer, <8 x i1> %1963
  %1970 = select i1 %1958, <8 x i1> %1969, <8 x i1> %1962
  store <8 x i1> %1970, ptr %1960, align 1
  %1971 = select i1 %1968, <8 x i1> zeroinitializer, <8 x i1> %1961
  store <8 x i1> %1971, ptr %1959, align 1
  %1972 = trunc i32 %1948 to i8
  %1973 = shl i8 1, %1972
  %1974 = xor i8 %1973, -1
  %1975 = and i8 %1949, %1974
  %1976 = select i1 %1968, i8 %1975, i8 %1949
  store i8 %1976, ptr %frame.active, align 1
  %.splatinsert260 = insertelement <8 x i1> poison, i1 %1958, i64 0
  %.splat261 = shufflevector <8 x i1> %.splatinsert260, <8 x i1> poison, <8 x i32> zeroinitializer
  %1977 = and <8 x i1> %convergence.cascade.flow256, %.splat261
  %1978 = load <8 x i1>, ptr %runnable.mask, align 1
  %1979 = xor <8 x i1> %1977, splat (i1 true)
  %1980 = and <8 x i1> %1978, %1979
  store <8 x i1> %1980, ptr %runnable.mask, align 1
  %.splatinsert262 = insertelement <8 x i1> poison, i1 %1968, i64 0
  %.splat263 = shufflevector <8 x i1> %.splatinsert262, <8 x i1> poison, <8 x i32> zeroinitializer
  %1981 = select <8 x i1> %.splat263, <8 x i1> %1963, <8 x i1> zeroinitializer
  %1982 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1983 = extractelement <8 x i32> %1982, i32 %1948
  %1984 = select i1 %1968, i32 %1983, i32 %1944
  store i32 %1984, ptr %current.token, align 4
  %.splatinsert264 = insertelement <8 x i1> poison, i1 %1958, i64 0
  %.splat265 = shufflevector <8 x i1> %.splatinsert264, <8 x i1> poison, <8 x i32> zeroinitializer
  %1985 = select <8 x i1> %.splat265, <8 x i1> %1981, <8 x i1> %convergence.cascade.flow256
  %1986 = add i32 %convergence.cascade.depth257, 1
  %1987 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1985)
  %1988 = icmp ult i32 %1986, 8
  %1989 = and i1 %1987, %1988
  %1990 = and i1 %1958, %1989
  %convergence.parent.token266 = load i32, ptr %current.token, align 4
  %convergence.parent.present267 = icmp ne i32 %convergence.parent.token266, 0
  %1991 = and i1 %1990, %convergence.parent.present267
  br i1 %1991, label %convergence.cascade252, label %convergence.cascade.exit253

convergence.cascade.exit253:                      ; preds = %convergence.cascade252, %schedule.10
  %convergence.cascade.result268 = phi <8 x i1> [ %357, %schedule.10 ], [ %1985, %convergence.cascade252 ]
  %1992 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result268)
  br i1 %1992, label %convergence.target.10.ready, label %scheduler.loop

convergence.target.10.ready:                      ; preds = %convergence.cascade.exit253
  %1993 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result268)
  %1994 = bitcast <8 x i1> %convergence.cascade.result268 to i8
  %1995 = call i8 @llvm.cttz.i8(i8 %1994, i1 false)
  %1996 = zext i8 %1995 to i32
  %1997 = select i1 %1993, i32 %1996, i32 0
  %1998 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill63, align 64
  %1999 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %2000 = extractvalue { <8 x ptr>, <8 x i64> } %1998, 0
  %2001 = select <8 x i1> %convergence.cascade.result268, <8 x ptr> %1999, <8 x ptr> %2000
  %2002 = extractvalue { <8 x ptr>, <8 x i64> } %9, 1
  %2003 = extractvalue { <8 x ptr>, <8 x i64> } %1998, 1
  %2004 = select <8 x i1> %convergence.cascade.result268, <8 x i64> %2002, <8 x i64> %2003
  %2005 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2001, 0
  %2006 = insertvalue { <8 x ptr>, <8 x i64> } %2005, <8 x i64> %2004, 1
  store volatile { <8 x ptr>, <8 x i64> } %2006, ptr %tile_snapshot.spill63, align 64
  %2007 = load <8 x i64>, ptr %.slot64, align 64
  %2008 = select <8 x i1> %convergence.cascade.result268, <8 x i64> zeroinitializer, <8 x i64> %2007
  store <8 x i64> %2008, ptr %.slot64, align 64
  store <8 x i1> %convergence.cascade.result268, ptr %current.mask, align 1
  %2009 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result268)
  br i1 %2009, label %schedule.11, label %scheduler.loop

varying.divergent270:                             ; preds = %schedule.11
  %2010 = load i32, ptr %current.token, align 4
  %2011 = icmp ne i32 %2010, 0
  %2012 = sub i32 %2010, 1
  %2013 = select i1 %2011, i32 %2012, i32 0
  %2014 = load i8, ptr %frame.active, align 1
  %2015 = trunc i32 %2013 to i8
  %2016 = shl i8 1, %2015
  %2017 = and i8 %2014, %2016
  %2018 = icmp ne i8 %2017, 0
  %2019 = load <8 x i32>, ptr %frame.static.id, align 32
  %2020 = extractelement <8 x i32> %2019, i32 %2013
  %2021 = icmp eq i32 %2020, 4
  %2022 = and i1 %2018, %2021
  %2023 = and i1 %2011, %2022
  %2024 = xor i1 %2023, true
  %2025 = and i1 true, %2024
  %2026 = xor i8 %2014, -1
  %2027 = icmp ne i8 %2026, 0
  %2028 = xor i1 %2027, true
  %2029 = and i1 %2025, %2028
  br i1 %2029, label %convergence.overflow.trap272, label %convergence.overflow.resume273

varying.coherent271:                              ; preds = %schedule.11
  br i1 %368, label %varying.coherent.true276, label %varying.coherent.false277

convergence.overflow.trap272:                     ; preds = %varying.divergent270
  call void @llvm.trap()
  unreachable

convergence.overflow.resume273:                   ; preds = %varying.divergent270
  %2030 = call i8 @llvm.cttz.i8(i8 %2026, i1 false)
  %2031 = zext i8 %2030 to i32
  %2032 = select i1 %2027, i32 %2031, i32 0
  %2033 = trunc i32 %2032 to i8
  %2034 = shl i8 1, %2033
  %2035 = or i8 %2014, %2034
  %2036 = select i1 %2025, i8 %2035, i8 %2014
  store i8 %2036, ptr %frame.active, align 1
  %2037 = load <8 x i32>, ptr %frame.static.id, align 32
  %2038 = extractelement <8 x i32> %2037, i32 %2032
  %2039 = select i1 %2025, i32 4, i32 %2038
  %2040 = load <8 x i32>, ptr %frame.static.id, align 32
  %2041 = insertelement <8 x i32> %2040, i32 %2039, i32 %2032
  store <8 x i32> %2041, ptr %frame.static.id, align 32
  %2042 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2043 = extractelement <8 x i32> %2042, i32 %2032
  %2044 = select i1 %2025, i32 %2010, i32 %2043
  %2045 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2046 = insertelement <8 x i32> %2045, i32 %2044, i32 %2032
  store <8 x i32> %2046, ptr %frame.parent.token, align 32
  %2047 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2032
  %2048 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2032
  %2049 = load <8 x i1>, ptr %2047, align 1
  %2050 = load <8 x i1>, ptr %2048, align 1
  %2051 = select i1 %2025, <8 x i1> %358, <8 x i1> %2049
  store <8 x i1> %2051, ptr %2047, align 1
  %2052 = select i1 %2025, <8 x i1> zeroinitializer, <8 x i1> %2050
  store <8 x i1> %2052, ptr %2048, align 1
  %2053 = add i32 %2032, 1
  %2054 = select i1 %2023, i32 %2010, i32 %2053
  %2055 = select i1 true, i32 %2054, i32 %2010
  store i32 %2055, ptr %current.token, align 4
  %2056 = load i32, ptr %current.token, align 4
  %2057 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %365)
  %2058 = load i32, ptr %ready.count, align 4
  %2059 = icmp uge i32 %2058, 8
  %2060 = and i1 %2057, %2059
  br i1 %2060, label %ready.overflow.trap274, label %ready.overflow.resume275

ready.overflow.trap274:                           ; preds = %convergence.overflow.resume273
  call void @llvm.trap()
  unreachable

ready.overflow.resume275:                         ; preds = %convergence.overflow.resume273
  %2061 = select i1 %2057, i32 %2058, i32 0
  %2062 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2061
  %2063 = load <8 x i1>, ptr %2062, align 1
  %2064 = select i1 %2057, <8 x i1> %365, <8 x i1> %2063
  store <8 x i1> %2064, ptr %2062, align 1
  %2065 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2061
  %2066 = load i32, ptr %2065, align 4
  %2067 = select i1 %2057, i32 12, i32 %2066
  store i32 %2067, ptr %2065, align 4
  %2068 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2061
  %2069 = load i32, ptr %2068, align 4
  %2070 = select i1 %2057, i32 %2056, i32 %2069
  store i32 %2070, ptr %2068, align 4
  %2071 = add i32 %2058, 1
  %2072 = select i1 %2057, i32 %2071, i32 %2058
  store i32 %2072, ptr %ready.count, align 4
  %2073 = load <8 x i1>, ptr %runnable.mask, align 1
  %2074 = or <8 x i1> %2073, %365
  store <8 x i1> %2074, ptr %runnable.mask, align 1
  store <8 x i1> %367, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true276:                         ; preds = %varying.coherent271
  store <8 x i1> %358, ptr %current.mask, align 1
  %2075 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %358)
  br i1 %2075, label %schedule.12, label %scheduler.loop

varying.coherent.false277:                        ; preds = %varying.coherent271
  store <8 x i1> %358, ptr %current.mask, align 1
  %2076 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %358)
  br i1 %2076, label %schedule.13, label %scheduler.loop

convergence.cascade285:                           ; preds = %convergence.cascade285, %schedule.13
  %convergence.cascade.flow289 = phi <8 x i1> [ %420, %schedule.13 ], [ %2119, %convergence.cascade285 ]
  %convergence.cascade.depth290 = phi i32 [ 0, %schedule.13 ], [ %2120, %convergence.cascade285 ]
  %2077 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow289)
  %2078 = load i32, ptr %current.token, align 4
  %2079 = icmp ne i32 %2078, 0
  %2080 = and i1 %2077, %2079
  %2081 = sub i32 %2078, 1
  %2082 = select i1 %2080, i32 %2081, i32 0
  %2083 = load i8, ptr %frame.active, align 1
  %2084 = trunc i32 %2082 to i8
  %2085 = shl i8 1, %2084
  %2086 = and i8 %2083, %2085
  %2087 = icmp ne i8 %2086, 0
  %2088 = load <8 x i32>, ptr %frame.static.id, align 32
  %2089 = extractelement <8 x i32> %2088, i32 %2082
  %convergence.target.pointer291 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %2089
  %convergence.dynamic.target292 = load i32, ptr %convergence.target.pointer291, align 4
  %2090 = icmp eq i32 %convergence.dynamic.target292, 13
  %2091 = and i1 %2087, %2090
  %2092 = and i1 %2080, %2091
  %2093 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2082
  %2094 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2082
  %2095 = load <8 x i1>, ptr %2093, align 1
  %2096 = load <8 x i1>, ptr %2094, align 1
  %2097 = or <8 x i1> %2096, %convergence.cascade.flow289
  %2098 = load <8 x i1>, ptr %live.mask, align 1
  %2099 = and <8 x i1> %2095, %2098
  %2100 = icmp eq <8 x i1> %2097, %2099
  %2101 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2100)
  %2102 = and i1 %2092, %2101
  %2103 = select i1 %2102, <8 x i1> zeroinitializer, <8 x i1> %2097
  %2104 = select i1 %2092, <8 x i1> %2103, <8 x i1> %2096
  store <8 x i1> %2104, ptr %2094, align 1
  %2105 = select i1 %2102, <8 x i1> zeroinitializer, <8 x i1> %2095
  store <8 x i1> %2105, ptr %2093, align 1
  %2106 = trunc i32 %2082 to i8
  %2107 = shl i8 1, %2106
  %2108 = xor i8 %2107, -1
  %2109 = and i8 %2083, %2108
  %2110 = select i1 %2102, i8 %2109, i8 %2083
  store i8 %2110, ptr %frame.active, align 1
  %.splatinsert293 = insertelement <8 x i1> poison, i1 %2092, i64 0
  %.splat294 = shufflevector <8 x i1> %.splatinsert293, <8 x i1> poison, <8 x i32> zeroinitializer
  %2111 = and <8 x i1> %convergence.cascade.flow289, %.splat294
  %2112 = load <8 x i1>, ptr %runnable.mask, align 1
  %2113 = xor <8 x i1> %2111, splat (i1 true)
  %2114 = and <8 x i1> %2112, %2113
  store <8 x i1> %2114, ptr %runnable.mask, align 1
  %.splatinsert295 = insertelement <8 x i1> poison, i1 %2102, i64 0
  %.splat296 = shufflevector <8 x i1> %.splatinsert295, <8 x i1> poison, <8 x i32> zeroinitializer
  %2115 = select <8 x i1> %.splat296, <8 x i1> %2097, <8 x i1> zeroinitializer
  %2116 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2117 = extractelement <8 x i32> %2116, i32 %2082
  %2118 = select i1 %2102, i32 %2117, i32 %2078
  store i32 %2118, ptr %current.token, align 4
  %.splatinsert297 = insertelement <8 x i1> poison, i1 %2092, i64 0
  %.splat298 = shufflevector <8 x i1> %.splatinsert297, <8 x i1> poison, <8 x i32> zeroinitializer
  %2119 = select <8 x i1> %.splat298, <8 x i1> %2115, <8 x i1> %convergence.cascade.flow289
  %2120 = add i32 %convergence.cascade.depth290, 1
  %2121 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2119)
  %2122 = icmp ult i32 %2120, 8
  %2123 = and i1 %2121, %2122
  %2124 = and i1 %2092, %2123
  %convergence.parent.token299 = load i32, ptr %current.token, align 4
  %convergence.parent.present300 = icmp ne i32 %convergence.parent.token299, 0
  %2125 = and i1 %2124, %convergence.parent.present300
  br i1 %2125, label %convergence.cascade285, label %convergence.cascade.exit286

convergence.cascade.exit286:                      ; preds = %convergence.cascade285, %schedule.13
  %convergence.cascade.result301 = phi <8 x i1> [ %420, %schedule.13 ], [ %2119, %convergence.cascade285 ]
  %2126 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  br i1 %2126, label %convergence.target.13.ready, label %scheduler.loop

convergence.target.13.ready:                      ; preds = %convergence.cascade.exit286
  %2127 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2128 = bitcast <8 x i1> %convergence.cascade.result301 to i8
  %2129 = call i8 @llvm.cttz.i8(i8 %2128, i1 false)
  %2130 = zext i8 %2129 to i32
  %2131 = select i1 %2127, i32 %2130, i32 0
  %2132 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %2133 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2134 = extractvalue { <8 x ptr>, <8 x i64> } %2132, 0
  %2135 = select <8 x i1> %convergence.cascade.result301, <8 x ptr> %2133, <8 x ptr> %2134
  %2136 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2137 = extractvalue { <8 x ptr>, <8 x i64> } %2132, 1
  %2138 = select <8 x i1> %convergence.cascade.result301, <8 x i64> %2136, <8 x i64> %2137
  %2139 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2135, 0
  %2140 = insertvalue { <8 x ptr>, <8 x i64> } %2139, <8 x i64> %2138, 1
  store volatile { <8 x ptr>, <8 x i64> } %2140, ptr %tile_snapshot.spill65, align 64
  %2141 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2142 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2143 = add <8 x i64> %2142, zeroinitializer
  %2144 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2141, 0
  %2145 = insertvalue { <8 x ptr>, <8 x i64> } %2144, <8 x i64> %2143, 1
  %2146 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2147 = extractvalue { <8 x ptr>, <8 x i64> } %2145, 1
  %2148 = extractelement <8 x ptr> %2146, i32 0
  %2149 = extractelement <8 x i64> %2147, i32 %2131
  %2150 = zext i32 %2131 to i64
  %2151 = mul i64 %2150, 8
  %2152 = sub i64 %2149, %2151
  %2153 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2154 = select i1 %2153, i64 %2152, i64 0
  %private.contiguous.address302 = getelementptr i8, ptr %2148, i64 %2154
  %private.contiguous.preserve303 = load <8 x i64>, ptr %private.contiguous.address302, align 8
  %2155 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 -2), <8 x i64> %private.contiguous.preserve303
  store <8 x i64> %2155, ptr %private.contiguous.address302, align 8
  %2156 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2157 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2158 = add <8 x i64> %2157, splat (i64 64)
  %2159 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2156, 0
  %2160 = insertvalue { <8 x ptr>, <8 x i64> } %2159, <8 x i64> %2158, 1
  %2161 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2162 = extractvalue { <8 x ptr>, <8 x i64> } %2160, 1
  %2163 = extractelement <8 x ptr> %2161, i32 0
  %2164 = extractelement <8 x i64> %2162, i32 %2131
  %2165 = zext i32 %2131 to i64
  %2166 = mul i64 %2165, 8
  %2167 = sub i64 %2164, %2166
  %2168 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2169 = select i1 %2168, i64 %2167, i64 0
  %private.contiguous.address304 = getelementptr i8, ptr %2163, i64 %2169
  %private.contiguous.preserve305 = load <8 x i64>, ptr %private.contiguous.address304, align 8
  %2170 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 -1), <8 x i64> %private.contiguous.preserve305
  store <8 x i64> %2170, ptr %private.contiguous.address304, align 8
  %2171 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2172 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2173 = add <8 x i64> %2172, splat (i64 128)
  %2174 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2171, 0
  %2175 = insertvalue { <8 x ptr>, <8 x i64> } %2174, <8 x i64> %2173, 1
  %2176 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2177 = extractvalue { <8 x ptr>, <8 x i64> } %2175, 1
  %2178 = extractelement <8 x ptr> %2176, i32 0
  %2179 = extractelement <8 x i64> %2177, i32 %2131
  %2180 = zext i32 %2131 to i64
  %2181 = mul i64 %2180, 8
  %2182 = sub i64 %2179, %2181
  %2183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2184 = select i1 %2183, i64 %2182, i64 0
  %private.contiguous.address306 = getelementptr i8, ptr %2178, i64 %2184
  %private.contiguous.preserve307 = load <8 x i64>, ptr %private.contiguous.address306, align 8
  %2185 = select <8 x i1> %convergence.cascade.result301, <8 x i64> zeroinitializer, <8 x i64> %private.contiguous.preserve307
  store <8 x i64> %2185, ptr %private.contiguous.address306, align 8
  %2186 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2187 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2188 = add <8 x i64> %2187, splat (i64 192)
  %2189 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2186, 0
  %2190 = insertvalue { <8 x ptr>, <8 x i64> } %2189, <8 x i64> %2188, 1
  %2191 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2192 = extractvalue { <8 x ptr>, <8 x i64> } %2190, 1
  %2193 = extractelement <8 x ptr> %2191, i32 0
  %2194 = extractelement <8 x i64> %2192, i32 %2131
  %2195 = zext i32 %2131 to i64
  %2196 = mul i64 %2195, 8
  %2197 = sub i64 %2194, %2196
  %2198 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2199 = select i1 %2198, i64 %2197, i64 0
  %private.contiguous.address308 = getelementptr i8, ptr %2193, i64 %2199
  %private.contiguous.preserve309 = load <8 x i64>, ptr %private.contiguous.address308, align 8
  %2200 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 1), <8 x i64> %private.contiguous.preserve309
  store <8 x i64> %2200, ptr %private.contiguous.address308, align 8
  %2201 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2202 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2203 = add <8 x i64> %2202, splat (i64 256)
  %2204 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2201, 0
  %2205 = insertvalue { <8 x ptr>, <8 x i64> } %2204, <8 x i64> %2203, 1
  %2206 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2207 = extractvalue { <8 x ptr>, <8 x i64> } %2205, 1
  %2208 = extractelement <8 x ptr> %2206, i32 0
  %2209 = extractelement <8 x i64> %2207, i32 %2131
  %2210 = zext i32 %2131 to i64
  %2211 = mul i64 %2210, 8
  %2212 = sub i64 %2209, %2211
  %2213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2214 = select i1 %2213, i64 %2212, i64 0
  %private.contiguous.address310 = getelementptr i8, ptr %2208, i64 %2214
  %private.contiguous.preserve311 = load <8 x i64>, ptr %private.contiguous.address310, align 8
  %2215 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 2), <8 x i64> %private.contiguous.preserve311
  store <8 x i64> %2215, ptr %private.contiguous.address310, align 8
  %2216 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2217 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2218 = add <8 x i64> %2217, splat (i64 320)
  %2219 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2216, 0
  %2220 = insertvalue { <8 x ptr>, <8 x i64> } %2219, <8 x i64> %2218, 1
  %2221 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2222 = extractvalue { <8 x ptr>, <8 x i64> } %2220, 1
  %2223 = extractelement <8 x ptr> %2221, i32 0
  %2224 = extractelement <8 x i64> %2222, i32 %2131
  %2225 = zext i32 %2131 to i64
  %2226 = mul i64 %2225, 8
  %2227 = sub i64 %2224, %2226
  %2228 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2229 = select i1 %2228, i64 %2227, i64 0
  %private.contiguous.address312 = getelementptr i8, ptr %2223, i64 %2229
  %private.contiguous.preserve313 = load <8 x i64>, ptr %private.contiguous.address312, align 8
  %2230 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 3), <8 x i64> %private.contiguous.preserve313
  store <8 x i64> %2230, ptr %private.contiguous.address312, align 8
  %2231 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2232 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2233 = add <8 x i64> %2232, splat (i64 384)
  %2234 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2231, 0
  %2235 = insertvalue { <8 x ptr>, <8 x i64> } %2234, <8 x i64> %2233, 1
  %2236 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2237 = extractvalue { <8 x ptr>, <8 x i64> } %2235, 1
  %2238 = extractelement <8 x ptr> %2236, i32 0
  %2239 = extractelement <8 x i64> %2237, i32 %2131
  %2240 = zext i32 %2131 to i64
  %2241 = mul i64 %2240, 8
  %2242 = sub i64 %2239, %2241
  %2243 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2244 = select i1 %2243, i64 %2242, i64 0
  %private.contiguous.address314 = getelementptr i8, ptr %2238, i64 %2244
  %private.contiguous.preserve315 = load <8 x i64>, ptr %private.contiguous.address314, align 8
  %2245 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 4), <8 x i64> %private.contiguous.preserve315
  store <8 x i64> %2245, ptr %private.contiguous.address314, align 8
  %2246 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2247 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2248 = add <8 x i64> %2247, splat (i64 448)
  %2249 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2246, 0
  %2250 = insertvalue { <8 x ptr>, <8 x i64> } %2249, <8 x i64> %2248, 1
  %2251 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2252 = extractvalue { <8 x ptr>, <8 x i64> } %2250, 1
  %2253 = extractelement <8 x ptr> %2251, i32 0
  %2254 = extractelement <8 x i64> %2252, i32 %2131
  %2255 = zext i32 %2131 to i64
  %2256 = mul i64 %2255, 8
  %2257 = sub i64 %2254, %2256
  %2258 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2259 = select i1 %2258, i64 %2257, i64 0
  %private.contiguous.address316 = getelementptr i8, ptr %2253, i64 %2259
  %private.contiguous.preserve317 = load <8 x i64>, ptr %private.contiguous.address316, align 8
  %2260 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 5), <8 x i64> %private.contiguous.preserve317
  store <8 x i64> %2260, ptr %private.contiguous.address316, align 8
  %2261 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2262 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2263 = add <8 x i64> %2262, splat (i64 512)
  %2264 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2261, 0
  %2265 = insertvalue { <8 x ptr>, <8 x i64> } %2264, <8 x i64> %2263, 1
  %2266 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2267 = extractvalue { <8 x ptr>, <8 x i64> } %2265, 1
  %2268 = extractelement <8 x ptr> %2266, i32 0
  %2269 = extractelement <8 x i64> %2267, i32 %2131
  %2270 = zext i32 %2131 to i64
  %2271 = mul i64 %2270, 8
  %2272 = sub i64 %2269, %2271
  %2273 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2274 = select i1 %2273, i64 %2272, i64 0
  %private.contiguous.address318 = getelementptr i8, ptr %2268, i64 %2274
  %private.contiguous.preserve319 = load <8 x i64>, ptr %private.contiguous.address318, align 8
  %2275 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 6), <8 x i64> %private.contiguous.preserve319
  store <8 x i64> %2275, ptr %private.contiguous.address318, align 8
  %2276 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2277 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2278 = add <8 x i64> %2277, splat (i64 576)
  %2279 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2276, 0
  %2280 = insertvalue { <8 x ptr>, <8 x i64> } %2279, <8 x i64> %2278, 1
  %2281 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2282 = extractvalue { <8 x ptr>, <8 x i64> } %2280, 1
  %2283 = extractelement <8 x ptr> %2281, i32 0
  %2284 = extractelement <8 x i64> %2282, i32 %2131
  %2285 = zext i32 %2131 to i64
  %2286 = mul i64 %2285, 8
  %2287 = sub i64 %2284, %2286
  %2288 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2289 = select i1 %2288, i64 %2287, i64 0
  %private.contiguous.address320 = getelementptr i8, ptr %2283, i64 %2289
  %private.contiguous.preserve321 = load <8 x i64>, ptr %private.contiguous.address320, align 8
  %2290 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 7), <8 x i64> %private.contiguous.preserve321
  store <8 x i64> %2290, ptr %private.contiguous.address320, align 8
  %2291 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2292 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2293 = add <8 x i64> %2292, splat (i64 640)
  %2294 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2291, 0
  %2295 = insertvalue { <8 x ptr>, <8 x i64> } %2294, <8 x i64> %2293, 1
  %2296 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2297 = extractvalue { <8 x ptr>, <8 x i64> } %2295, 1
  %2298 = extractelement <8 x ptr> %2296, i32 0
  %2299 = extractelement <8 x i64> %2297, i32 %2131
  %2300 = zext i32 %2131 to i64
  %2301 = mul i64 %2300, 8
  %2302 = sub i64 %2299, %2301
  %2303 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2304 = select i1 %2303, i64 %2302, i64 0
  %private.contiguous.address322 = getelementptr i8, ptr %2298, i64 %2304
  %private.contiguous.preserve323 = load <8 x i64>, ptr %private.contiguous.address322, align 8
  %2305 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 8), <8 x i64> %private.contiguous.preserve323
  store <8 x i64> %2305, ptr %private.contiguous.address322, align 8
  %2306 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2307 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2308 = add <8 x i64> %2307, splat (i64 704)
  %2309 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2306, 0
  %2310 = insertvalue { <8 x ptr>, <8 x i64> } %2309, <8 x i64> %2308, 1
  %2311 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2312 = extractvalue { <8 x ptr>, <8 x i64> } %2310, 1
  %2313 = extractelement <8 x ptr> %2311, i32 0
  %2314 = extractelement <8 x i64> %2312, i32 %2131
  %2315 = zext i32 %2131 to i64
  %2316 = mul i64 %2315, 8
  %2317 = sub i64 %2314, %2316
  %2318 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2319 = select i1 %2318, i64 %2317, i64 0
  %private.contiguous.address324 = getelementptr i8, ptr %2313, i64 %2319
  %private.contiguous.preserve325 = load <8 x i64>, ptr %private.contiguous.address324, align 8
  %2320 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 9), <8 x i64> %private.contiguous.preserve325
  store <8 x i64> %2320, ptr %private.contiguous.address324, align 8
  %2321 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2322 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2323 = add <8 x i64> %2322, splat (i64 768)
  %2324 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2321, 0
  %2325 = insertvalue { <8 x ptr>, <8 x i64> } %2324, <8 x i64> %2323, 1
  %2326 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2327 = extractvalue { <8 x ptr>, <8 x i64> } %2325, 1
  %2328 = extractelement <8 x ptr> %2326, i32 0
  %2329 = extractelement <8 x i64> %2327, i32 %2131
  %2330 = zext i32 %2131 to i64
  %2331 = mul i64 %2330, 8
  %2332 = sub i64 %2329, %2331
  %2333 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2334 = select i1 %2333, i64 %2332, i64 0
  %private.contiguous.address326 = getelementptr i8, ptr %2328, i64 %2334
  %private.contiguous.preserve327 = load <8 x i64>, ptr %private.contiguous.address326, align 8
  %2335 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 10), <8 x i64> %private.contiguous.preserve327
  store <8 x i64> %2335, ptr %private.contiguous.address326, align 8
  %2336 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2337 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2338 = add <8 x i64> %2337, splat (i64 832)
  %2339 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2336, 0
  %2340 = insertvalue { <8 x ptr>, <8 x i64> } %2339, <8 x i64> %2338, 1
  %2341 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2342 = extractvalue { <8 x ptr>, <8 x i64> } %2340, 1
  %2343 = extractelement <8 x ptr> %2341, i32 0
  %2344 = extractelement <8 x i64> %2342, i32 %2131
  %2345 = zext i32 %2131 to i64
  %2346 = mul i64 %2345, 8
  %2347 = sub i64 %2344, %2346
  %2348 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2349 = select i1 %2348, i64 %2347, i64 0
  %private.contiguous.address328 = getelementptr i8, ptr %2343, i64 %2349
  %private.contiguous.preserve329 = load <8 x i64>, ptr %private.contiguous.address328, align 8
  %2350 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 11), <8 x i64> %private.contiguous.preserve329
  store <8 x i64> %2350, ptr %private.contiguous.address328, align 8
  %2351 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2352 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2353 = add <8 x i64> %2352, splat (i64 896)
  %2354 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2351, 0
  %2355 = insertvalue { <8 x ptr>, <8 x i64> } %2354, <8 x i64> %2353, 1
  %2356 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2357 = extractvalue { <8 x ptr>, <8 x i64> } %2355, 1
  %2358 = extractelement <8 x ptr> %2356, i32 0
  %2359 = extractelement <8 x i64> %2357, i32 %2131
  %2360 = zext i32 %2131 to i64
  %2361 = mul i64 %2360, 8
  %2362 = sub i64 %2359, %2361
  %2363 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2364 = select i1 %2363, i64 %2362, i64 0
  %private.contiguous.address330 = getelementptr i8, ptr %2358, i64 %2364
  %private.contiguous.preserve331 = load <8 x i64>, ptr %private.contiguous.address330, align 8
  %2365 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 12), <8 x i64> %private.contiguous.preserve331
  store <8 x i64> %2365, ptr %private.contiguous.address330, align 8
  %2366 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2367 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2368 = add <8 x i64> %2367, splat (i64 960)
  %2369 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2366, 0
  %2370 = insertvalue { <8 x ptr>, <8 x i64> } %2369, <8 x i64> %2368, 1
  %2371 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2372 = extractvalue { <8 x ptr>, <8 x i64> } %2370, 1
  %2373 = extractelement <8 x ptr> %2371, i32 0
  %2374 = extractelement <8 x i64> %2372, i32 %2131
  %2375 = zext i32 %2131 to i64
  %2376 = mul i64 %2375, 8
  %2377 = sub i64 %2374, %2376
  %2378 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2379 = select i1 %2378, i64 %2377, i64 0
  %private.contiguous.address332 = getelementptr i8, ptr %2373, i64 %2379
  %private.contiguous.preserve333 = load <8 x i64>, ptr %private.contiguous.address332, align 8
  %2380 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 13), <8 x i64> %private.contiguous.preserve333
  store <8 x i64> %2380, ptr %private.contiguous.address332, align 8
  %2381 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2382 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2383 = add <8 x i64> %2382, splat (i64 1024)
  %2384 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2381, 0
  %2385 = insertvalue { <8 x ptr>, <8 x i64> } %2384, <8 x i64> %2383, 1
  %2386 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2387 = extractvalue { <8 x ptr>, <8 x i64> } %2385, 1
  %2388 = extractelement <8 x ptr> %2386, i32 0
  %2389 = extractelement <8 x i64> %2387, i32 %2131
  %2390 = zext i32 %2131 to i64
  %2391 = mul i64 %2390, 8
  %2392 = sub i64 %2389, %2391
  %2393 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2394 = select i1 %2393, i64 %2392, i64 0
  %private.contiguous.address334 = getelementptr i8, ptr %2388, i64 %2394
  %private.contiguous.preserve335 = load <8 x i64>, ptr %private.contiguous.address334, align 8
  %2395 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 14), <8 x i64> %private.contiguous.preserve335
  store <8 x i64> %2395, ptr %private.contiguous.address334, align 8
  %2396 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2397 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2398 = add <8 x i64> %2397, splat (i64 1088)
  %2399 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2396, 0
  %2400 = insertvalue { <8 x ptr>, <8 x i64> } %2399, <8 x i64> %2398, 1
  %2401 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2402 = extractvalue { <8 x ptr>, <8 x i64> } %2400, 1
  %2403 = extractelement <8 x ptr> %2401, i32 0
  %2404 = extractelement <8 x i64> %2402, i32 %2131
  %2405 = zext i32 %2131 to i64
  %2406 = mul i64 %2405, 8
  %2407 = sub i64 %2404, %2406
  %2408 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2409 = select i1 %2408, i64 %2407, i64 0
  %private.contiguous.address336 = getelementptr i8, ptr %2403, i64 %2409
  %private.contiguous.preserve337 = load <8 x i64>, ptr %private.contiguous.address336, align 8
  %2410 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 15), <8 x i64> %private.contiguous.preserve337
  store <8 x i64> %2410, ptr %private.contiguous.address336, align 8
  %2411 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2412 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2413 = add <8 x i64> %2412, splat (i64 1152)
  %2414 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2411, 0
  %2415 = insertvalue { <8 x ptr>, <8 x i64> } %2414, <8 x i64> %2413, 1
  %2416 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2417 = extractvalue { <8 x ptr>, <8 x i64> } %2415, 1
  %2418 = extractelement <8 x ptr> %2416, i32 0
  %2419 = extractelement <8 x i64> %2417, i32 %2131
  %2420 = zext i32 %2131 to i64
  %2421 = mul i64 %2420, 8
  %2422 = sub i64 %2419, %2421
  %2423 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2424 = select i1 %2423, i64 %2422, i64 0
  %private.contiguous.address338 = getelementptr i8, ptr %2418, i64 %2424
  %private.contiguous.preserve339 = load <8 x i64>, ptr %private.contiguous.address338, align 8
  %2425 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 16), <8 x i64> %private.contiguous.preserve339
  store <8 x i64> %2425, ptr %private.contiguous.address338, align 8
  %2426 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2427 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2428 = add <8 x i64> %2427, splat (i64 1216)
  %2429 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2426, 0
  %2430 = insertvalue { <8 x ptr>, <8 x i64> } %2429, <8 x i64> %2428, 1
  %2431 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2432 = extractvalue { <8 x ptr>, <8 x i64> } %2430, 1
  %2433 = extractelement <8 x ptr> %2431, i32 0
  %2434 = extractelement <8 x i64> %2432, i32 %2131
  %2435 = zext i32 %2131 to i64
  %2436 = mul i64 %2435, 8
  %2437 = sub i64 %2434, %2436
  %2438 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2439 = select i1 %2438, i64 %2437, i64 0
  %private.contiguous.address340 = getelementptr i8, ptr %2433, i64 %2439
  %private.contiguous.preserve341 = load <8 x i64>, ptr %private.contiguous.address340, align 8
  %2440 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 17), <8 x i64> %private.contiguous.preserve341
  store <8 x i64> %2440, ptr %private.contiguous.address340, align 8
  %2441 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2442 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2443 = add <8 x i64> %2442, splat (i64 1280)
  %2444 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2441, 0
  %2445 = insertvalue { <8 x ptr>, <8 x i64> } %2444, <8 x i64> %2443, 1
  %2446 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2447 = extractvalue { <8 x ptr>, <8 x i64> } %2445, 1
  %2448 = extractelement <8 x ptr> %2446, i32 0
  %2449 = extractelement <8 x i64> %2447, i32 %2131
  %2450 = zext i32 %2131 to i64
  %2451 = mul i64 %2450, 8
  %2452 = sub i64 %2449, %2451
  %2453 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2454 = select i1 %2453, i64 %2452, i64 0
  %private.contiguous.address342 = getelementptr i8, ptr %2448, i64 %2454
  %private.contiguous.preserve343 = load <8 x i64>, ptr %private.contiguous.address342, align 8
  %2455 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 18), <8 x i64> %private.contiguous.preserve343
  store <8 x i64> %2455, ptr %private.contiguous.address342, align 8
  %2456 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2457 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2458 = add <8 x i64> %2457, splat (i64 1344)
  %2459 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2456, 0
  %2460 = insertvalue { <8 x ptr>, <8 x i64> } %2459, <8 x i64> %2458, 1
  %2461 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2462 = extractvalue { <8 x ptr>, <8 x i64> } %2460, 1
  %2463 = extractelement <8 x ptr> %2461, i32 0
  %2464 = extractelement <8 x i64> %2462, i32 %2131
  %2465 = zext i32 %2131 to i64
  %2466 = mul i64 %2465, 8
  %2467 = sub i64 %2464, %2466
  %2468 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2469 = select i1 %2468, i64 %2467, i64 0
  %private.contiguous.address344 = getelementptr i8, ptr %2463, i64 %2469
  %private.contiguous.preserve345 = load <8 x i64>, ptr %private.contiguous.address344, align 8
  %2470 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 19), <8 x i64> %private.contiguous.preserve345
  store <8 x i64> %2470, ptr %private.contiguous.address344, align 8
  %2471 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2472 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2473 = add <8 x i64> %2472, splat (i64 1408)
  %2474 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2471, 0
  %2475 = insertvalue { <8 x ptr>, <8 x i64> } %2474, <8 x i64> %2473, 1
  %2476 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2477 = extractvalue { <8 x ptr>, <8 x i64> } %2475, 1
  %2478 = extractelement <8 x ptr> %2476, i32 0
  %2479 = extractelement <8 x i64> %2477, i32 %2131
  %2480 = zext i32 %2131 to i64
  %2481 = mul i64 %2480, 8
  %2482 = sub i64 %2479, %2481
  %2483 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2484 = select i1 %2483, i64 %2482, i64 0
  %private.contiguous.address346 = getelementptr i8, ptr %2478, i64 %2484
  %private.contiguous.preserve347 = load <8 x i64>, ptr %private.contiguous.address346, align 8
  %2485 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 20), <8 x i64> %private.contiguous.preserve347
  store <8 x i64> %2485, ptr %private.contiguous.address346, align 8
  %2486 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2487 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2488 = add <8 x i64> %2487, splat (i64 1472)
  %2489 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2486, 0
  %2490 = insertvalue { <8 x ptr>, <8 x i64> } %2489, <8 x i64> %2488, 1
  %2491 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2492 = extractvalue { <8 x ptr>, <8 x i64> } %2490, 1
  %2493 = extractelement <8 x ptr> %2491, i32 0
  %2494 = extractelement <8 x i64> %2492, i32 %2131
  %2495 = zext i32 %2131 to i64
  %2496 = mul i64 %2495, 8
  %2497 = sub i64 %2494, %2496
  %2498 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2499 = select i1 %2498, i64 %2497, i64 0
  %private.contiguous.address348 = getelementptr i8, ptr %2493, i64 %2499
  %private.contiguous.preserve349 = load <8 x i64>, ptr %private.contiguous.address348, align 8
  %2500 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 21), <8 x i64> %private.contiguous.preserve349
  store <8 x i64> %2500, ptr %private.contiguous.address348, align 8
  %2501 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2502 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2503 = add <8 x i64> %2502, splat (i64 1536)
  %2504 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2501, 0
  %2505 = insertvalue { <8 x ptr>, <8 x i64> } %2504, <8 x i64> %2503, 1
  %2506 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2507 = extractvalue { <8 x ptr>, <8 x i64> } %2505, 1
  %2508 = extractelement <8 x ptr> %2506, i32 0
  %2509 = extractelement <8 x i64> %2507, i32 %2131
  %2510 = zext i32 %2131 to i64
  %2511 = mul i64 %2510, 8
  %2512 = sub i64 %2509, %2511
  %2513 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2514 = select i1 %2513, i64 %2512, i64 0
  %private.contiguous.address350 = getelementptr i8, ptr %2508, i64 %2514
  %private.contiguous.preserve351 = load <8 x i64>, ptr %private.contiguous.address350, align 8
  %2515 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 22), <8 x i64> %private.contiguous.preserve351
  store <8 x i64> %2515, ptr %private.contiguous.address350, align 8
  %2516 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2517 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2518 = add <8 x i64> %2517, splat (i64 1600)
  %2519 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2516, 0
  %2520 = insertvalue { <8 x ptr>, <8 x i64> } %2519, <8 x i64> %2518, 1
  %2521 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2522 = extractvalue { <8 x ptr>, <8 x i64> } %2520, 1
  %2523 = extractelement <8 x ptr> %2521, i32 0
  %2524 = extractelement <8 x i64> %2522, i32 %2131
  %2525 = zext i32 %2131 to i64
  %2526 = mul i64 %2525, 8
  %2527 = sub i64 %2524, %2526
  %2528 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2529 = select i1 %2528, i64 %2527, i64 0
  %private.contiguous.address352 = getelementptr i8, ptr %2523, i64 %2529
  %private.contiguous.preserve353 = load <8 x i64>, ptr %private.contiguous.address352, align 8
  %2530 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 23), <8 x i64> %private.contiguous.preserve353
  store <8 x i64> %2530, ptr %private.contiguous.address352, align 8
  %2531 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2532 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2533 = add <8 x i64> %2532, splat (i64 1664)
  %2534 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2531, 0
  %2535 = insertvalue { <8 x ptr>, <8 x i64> } %2534, <8 x i64> %2533, 1
  %2536 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2537 = extractvalue { <8 x ptr>, <8 x i64> } %2535, 1
  %2538 = extractelement <8 x ptr> %2536, i32 0
  %2539 = extractelement <8 x i64> %2537, i32 %2131
  %2540 = zext i32 %2131 to i64
  %2541 = mul i64 %2540, 8
  %2542 = sub i64 %2539, %2541
  %2543 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2544 = select i1 %2543, i64 %2542, i64 0
  %private.contiguous.address354 = getelementptr i8, ptr %2538, i64 %2544
  %private.contiguous.preserve355 = load <8 x i64>, ptr %private.contiguous.address354, align 8
  %2545 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 24), <8 x i64> %private.contiguous.preserve355
  store <8 x i64> %2545, ptr %private.contiguous.address354, align 8
  %2546 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2547 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2548 = add <8 x i64> %2547, splat (i64 1728)
  %2549 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2546, 0
  %2550 = insertvalue { <8 x ptr>, <8 x i64> } %2549, <8 x i64> %2548, 1
  %2551 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2552 = extractvalue { <8 x ptr>, <8 x i64> } %2550, 1
  %2553 = extractelement <8 x ptr> %2551, i32 0
  %2554 = extractelement <8 x i64> %2552, i32 %2131
  %2555 = zext i32 %2131 to i64
  %2556 = mul i64 %2555, 8
  %2557 = sub i64 %2554, %2556
  %2558 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2559 = select i1 %2558, i64 %2557, i64 0
  %private.contiguous.address356 = getelementptr i8, ptr %2553, i64 %2559
  %private.contiguous.preserve357 = load <8 x i64>, ptr %private.contiguous.address356, align 8
  %2560 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 25), <8 x i64> %private.contiguous.preserve357
  store <8 x i64> %2560, ptr %private.contiguous.address356, align 8
  %2561 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2562 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2563 = add <8 x i64> %2562, splat (i64 1792)
  %2564 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2561, 0
  %2565 = insertvalue { <8 x ptr>, <8 x i64> } %2564, <8 x i64> %2563, 1
  %2566 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2567 = extractvalue { <8 x ptr>, <8 x i64> } %2565, 1
  %2568 = extractelement <8 x ptr> %2566, i32 0
  %2569 = extractelement <8 x i64> %2567, i32 %2131
  %2570 = zext i32 %2131 to i64
  %2571 = mul i64 %2570, 8
  %2572 = sub i64 %2569, %2571
  %2573 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2574 = select i1 %2573, i64 %2572, i64 0
  %private.contiguous.address358 = getelementptr i8, ptr %2568, i64 %2574
  %private.contiguous.preserve359 = load <8 x i64>, ptr %private.contiguous.address358, align 8
  %2575 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 26), <8 x i64> %private.contiguous.preserve359
  store <8 x i64> %2575, ptr %private.contiguous.address358, align 8
  %2576 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2577 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2578 = add <8 x i64> %2577, splat (i64 1856)
  %2579 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2576, 0
  %2580 = insertvalue { <8 x ptr>, <8 x i64> } %2579, <8 x i64> %2578, 1
  %2581 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2582 = extractvalue { <8 x ptr>, <8 x i64> } %2580, 1
  %2583 = extractelement <8 x ptr> %2581, i32 0
  %2584 = extractelement <8 x i64> %2582, i32 %2131
  %2585 = zext i32 %2131 to i64
  %2586 = mul i64 %2585, 8
  %2587 = sub i64 %2584, %2586
  %2588 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2589 = select i1 %2588, i64 %2587, i64 0
  %private.contiguous.address360 = getelementptr i8, ptr %2583, i64 %2589
  %private.contiguous.preserve361 = load <8 x i64>, ptr %private.contiguous.address360, align 8
  %2590 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 27), <8 x i64> %private.contiguous.preserve361
  store <8 x i64> %2590, ptr %private.contiguous.address360, align 8
  %2591 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2592 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2593 = add <8 x i64> %2592, splat (i64 1920)
  %2594 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2591, 0
  %2595 = insertvalue { <8 x ptr>, <8 x i64> } %2594, <8 x i64> %2593, 1
  %2596 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2597 = extractvalue { <8 x ptr>, <8 x i64> } %2595, 1
  %2598 = extractelement <8 x ptr> %2596, i32 0
  %2599 = extractelement <8 x i64> %2597, i32 %2131
  %2600 = zext i32 %2131 to i64
  %2601 = mul i64 %2600, 8
  %2602 = sub i64 %2599, %2601
  %2603 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2604 = select i1 %2603, i64 %2602, i64 0
  %private.contiguous.address362 = getelementptr i8, ptr %2598, i64 %2604
  %private.contiguous.preserve363 = load <8 x i64>, ptr %private.contiguous.address362, align 8
  %2605 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 28), <8 x i64> %private.contiguous.preserve363
  store <8 x i64> %2605, ptr %private.contiguous.address362, align 8
  %2606 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2607 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2608 = add <8 x i64> %2607, splat (i64 1984)
  %2609 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2606, 0
  %2610 = insertvalue { <8 x ptr>, <8 x i64> } %2609, <8 x i64> %2608, 1
  %2611 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2612 = extractvalue { <8 x ptr>, <8 x i64> } %2610, 1
  %2613 = extractelement <8 x ptr> %2611, i32 0
  %2614 = extractelement <8 x i64> %2612, i32 %2131
  %2615 = zext i32 %2131 to i64
  %2616 = mul i64 %2615, 8
  %2617 = sub i64 %2614, %2616
  %2618 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  %2619 = select i1 %2618, i64 %2617, i64 0
  %private.contiguous.address364 = getelementptr i8, ptr %2613, i64 %2619
  %private.contiguous.preserve365 = load <8 x i64>, ptr %private.contiguous.address364, align 8
  %2620 = select <8 x i1> %convergence.cascade.result301, <8 x i64> splat (i64 29), <8 x i64> %private.contiguous.preserve365
  store <8 x i64> %2620, ptr %private.contiguous.address364, align 8
  %2621 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill66, align 64
  %2622 = extractvalue { <8 x ptr>, <8 x i64> } %13, 0
  %2623 = extractvalue { <8 x ptr>, <8 x i64> } %2621, 0
  %2624 = select <8 x i1> %convergence.cascade.result301, <8 x ptr> %2622, <8 x ptr> %2623
  %2625 = extractvalue { <8 x ptr>, <8 x i64> } %13, 1
  %2626 = extractvalue { <8 x ptr>, <8 x i64> } %2621, 1
  %2627 = select <8 x i1> %convergence.cascade.result301, <8 x i64> %2625, <8 x i64> %2626
  %2628 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2624, 0
  %2629 = insertvalue { <8 x ptr>, <8 x i64> } %2628, <8 x i64> %2627, 1
  store volatile { <8 x ptr>, <8 x i64> } %2629, ptr %tile_snapshot.spill66, align 64
  %2630 = load <8 x i64>, ptr %.slot67, align 64
  %2631 = select <8 x i1> %convergence.cascade.result301, <8 x i64> zeroinitializer, <8 x i64> %2630
  store <8 x i64> %2631, ptr %.slot67, align 64
  store <8 x i1> %convergence.cascade.result301, ptr %current.mask, align 1
  %2632 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result301)
  br i1 %2632, label %schedule.14, label %scheduler.loop

varying.divergent367:                             ; preds = %schedule.14
  %2633 = load i32, ptr %current.token, align 4
  %2634 = icmp ne i32 %2633, 0
  %2635 = sub i32 %2633, 1
  %2636 = select i1 %2634, i32 %2635, i32 0
  %2637 = load i8, ptr %frame.active, align 1
  %2638 = trunc i32 %2636 to i8
  %2639 = shl i8 1, %2638
  %2640 = and i8 %2637, %2639
  %2641 = icmp ne i8 %2640, 0
  %2642 = load <8 x i32>, ptr %frame.static.id, align 32
  %2643 = extractelement <8 x i32> %2642, i32 %2636
  %2644 = icmp eq i32 %2643, 5
  %2645 = and i1 %2641, %2644
  %2646 = and i1 %2634, %2645
  %2647 = xor i1 %2646, true
  %2648 = and i1 true, %2647
  %2649 = xor i8 %2637, -1
  %2650 = icmp ne i8 %2649, 0
  %2651 = xor i1 %2650, true
  %2652 = and i1 %2648, %2651
  br i1 %2652, label %convergence.overflow.trap369, label %convergence.overflow.resume370

varying.coherent368:                              ; preds = %schedule.14
  br i1 %431, label %varying.coherent.true373, label %varying.coherent.false374

convergence.overflow.trap369:                     ; preds = %varying.divergent367
  call void @llvm.trap()
  unreachable

convergence.overflow.resume370:                   ; preds = %varying.divergent367
  %2653 = call i8 @llvm.cttz.i8(i8 %2649, i1 false)
  %2654 = zext i8 %2653 to i32
  %2655 = select i1 %2650, i32 %2654, i32 0
  %2656 = trunc i32 %2655 to i8
  %2657 = shl i8 1, %2656
  %2658 = or i8 %2637, %2657
  %2659 = select i1 %2648, i8 %2658, i8 %2637
  store i8 %2659, ptr %frame.active, align 1
  %2660 = load <8 x i32>, ptr %frame.static.id, align 32
  %2661 = extractelement <8 x i32> %2660, i32 %2655
  %2662 = select i1 %2648, i32 5, i32 %2661
  %2663 = load <8 x i32>, ptr %frame.static.id, align 32
  %2664 = insertelement <8 x i32> %2663, i32 %2662, i32 %2655
  store <8 x i32> %2664, ptr %frame.static.id, align 32
  %2665 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2666 = extractelement <8 x i32> %2665, i32 %2655
  %2667 = select i1 %2648, i32 %2633, i32 %2666
  %2668 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2669 = insertelement <8 x i32> %2668, i32 %2667, i32 %2655
  store <8 x i32> %2669, ptr %frame.parent.token, align 32
  %2670 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2655
  %2671 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2655
  %2672 = load <8 x i1>, ptr %2670, align 1
  %2673 = load <8 x i1>, ptr %2671, align 1
  %2674 = select i1 %2648, <8 x i1> %421, <8 x i1> %2672
  store <8 x i1> %2674, ptr %2670, align 1
  %2675 = select i1 %2648, <8 x i1> zeroinitializer, <8 x i1> %2673
  store <8 x i1> %2675, ptr %2671, align 1
  %2676 = add i32 %2655, 1
  %2677 = select i1 %2646, i32 %2633, i32 %2676
  %2678 = select i1 true, i32 %2677, i32 %2633
  store i32 %2678, ptr %current.token, align 4
  %2679 = load i32, ptr %current.token, align 4
  %2680 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %428)
  %2681 = load i32, ptr %ready.count, align 4
  %2682 = icmp uge i32 %2681, 8
  %2683 = and i1 %2680, %2682
  br i1 %2683, label %ready.overflow.trap371, label %ready.overflow.resume372

ready.overflow.trap371:                           ; preds = %convergence.overflow.resume370
  call void @llvm.trap()
  unreachable

ready.overflow.resume372:                         ; preds = %convergence.overflow.resume370
  %2684 = select i1 %2680, i32 %2681, i32 0
  %2685 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2684
  %2686 = load <8 x i1>, ptr %2685, align 1
  %2687 = select i1 %2680, <8 x i1> %428, <8 x i1> %2686
  store <8 x i1> %2687, ptr %2685, align 1
  %2688 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2684
  %2689 = load i32, ptr %2688, align 4
  %2690 = select i1 %2680, i32 15, i32 %2689
  store i32 %2690, ptr %2688, align 4
  %2691 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2684
  %2692 = load i32, ptr %2691, align 4
  %2693 = select i1 %2680, i32 %2679, i32 %2692
  store i32 %2693, ptr %2691, align 4
  %2694 = add i32 %2681, 1
  %2695 = select i1 %2680, i32 %2694, i32 %2681
  store i32 %2695, ptr %ready.count, align 4
  %2696 = load <8 x i1>, ptr %runnable.mask, align 1
  %2697 = or <8 x i1> %2696, %428
  store <8 x i1> %2697, ptr %runnable.mask, align 1
  store <8 x i1> %430, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true373:                         ; preds = %varying.coherent368
  store <8 x i1> %421, ptr %current.mask, align 1
  %2698 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %421)
  br i1 %2698, label %schedule.15, label %scheduler.loop

varying.coherent.false374:                        ; preds = %varying.coherent368
  store <8 x i1> %421, ptr %current.mask, align 1
  %2699 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %421)
  br i1 %2699, label %schedule.18, label %scheduler.loop

varying.divergent378:                             ; preds = %schedule.15
  %2700 = load i32, ptr %current.token, align 4
  %2701 = icmp ne i32 %2700, 0
  %2702 = sub i32 %2700, 1
  %2703 = select i1 %2701, i32 %2702, i32 0
  %2704 = load i8, ptr %frame.active, align 1
  %2705 = trunc i32 %2703 to i8
  %2706 = shl i8 1, %2705
  %2707 = and i8 %2704, %2706
  %2708 = icmp ne i8 %2707, 0
  %2709 = load <8 x i32>, ptr %frame.static.id, align 32
  %2710 = extractelement <8 x i32> %2709, i32 %2703
  %2711 = icmp eq i32 %2710, 6
  %2712 = and i1 %2708, %2711
  %2713 = and i1 %2701, %2712
  %2714 = xor i1 %2713, true
  %2715 = and i1 true, %2714
  %2716 = xor i8 %2704, -1
  %2717 = icmp ne i8 %2716, 0
  %2718 = xor i1 %2717, true
  %2719 = and i1 %2715, %2718
  br i1 %2719, label %convergence.overflow.trap380, label %convergence.overflow.resume381

varying.coherent379:                              ; preds = %schedule.15
  br i1 %473, label %varying.coherent.true384, label %varying.coherent.false385

convergence.overflow.trap380:                     ; preds = %varying.divergent378
  call void @llvm.trap()
  unreachable

convergence.overflow.resume381:                   ; preds = %varying.divergent378
  %2720 = call i8 @llvm.cttz.i8(i8 %2716, i1 false)
  %2721 = zext i8 %2720 to i32
  %2722 = select i1 %2717, i32 %2721, i32 0
  %2723 = trunc i32 %2722 to i8
  %2724 = shl i8 1, %2723
  %2725 = or i8 %2704, %2724
  %2726 = select i1 %2715, i8 %2725, i8 %2704
  store i8 %2726, ptr %frame.active, align 1
  %2727 = load <8 x i32>, ptr %frame.static.id, align 32
  %2728 = extractelement <8 x i32> %2727, i32 %2722
  %2729 = select i1 %2715, i32 6, i32 %2728
  %2730 = load <8 x i32>, ptr %frame.static.id, align 32
  %2731 = insertelement <8 x i32> %2730, i32 %2729, i32 %2722
  store <8 x i32> %2731, ptr %frame.static.id, align 32
  %2732 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2733 = extractelement <8 x i32> %2732, i32 %2722
  %2734 = select i1 %2715, i32 %2700, i32 %2733
  %2735 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2736 = insertelement <8 x i32> %2735, i32 %2734, i32 %2722
  store <8 x i32> %2736, ptr %frame.parent.token, align 32
  %2737 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2722
  %2738 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2722
  %2739 = load <8 x i1>, ptr %2737, align 1
  %2740 = load <8 x i1>, ptr %2738, align 1
  %2741 = select i1 %2715, <8 x i1> %434, <8 x i1> %2739
  store <8 x i1> %2741, ptr %2737, align 1
  %2742 = select i1 %2715, <8 x i1> zeroinitializer, <8 x i1> %2740
  store <8 x i1> %2742, ptr %2738, align 1
  %2743 = add i32 %2722, 1
  %2744 = select i1 %2713, i32 %2700, i32 %2743
  %2745 = select i1 true, i32 %2744, i32 %2700
  store i32 %2745, ptr %current.token, align 4
  %2746 = load <8 x float>, ptr %.slot70, align 32
  %2747 = select <8 x i1> %472, <8 x float> zeroinitializer, <8 x float> %2746
  store <8 x float> %2747, ptr %.slot70, align 32
  %2748 = load i32, ptr %current.token, align 4
  %2749 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %470)
  %2750 = load i32, ptr %ready.count, align 4
  %2751 = icmp uge i32 %2750, 8
  %2752 = and i1 %2749, %2751
  br i1 %2752, label %ready.overflow.trap382, label %ready.overflow.resume383

ready.overflow.trap382:                           ; preds = %convergence.overflow.resume381
  call void @llvm.trap()
  unreachable

ready.overflow.resume383:                         ; preds = %convergence.overflow.resume381
  %2753 = select i1 %2749, i32 %2750, i32 0
  %2754 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2753
  %2755 = load <8 x i1>, ptr %2754, align 1
  %2756 = select i1 %2749, <8 x i1> %470, <8 x i1> %2755
  store <8 x i1> %2756, ptr %2754, align 1
  %2757 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2753
  %2758 = load i32, ptr %2757, align 4
  %2759 = select i1 %2749, i32 16, i32 %2758
  store i32 %2759, ptr %2757, align 4
  %2760 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2753
  %2761 = load i32, ptr %2760, align 4
  %2762 = select i1 %2749, i32 %2748, i32 %2761
  store i32 %2762, ptr %2760, align 4
  %2763 = add i32 %2750, 1
  %2764 = select i1 %2749, i32 %2763, i32 %2750
  store i32 %2764, ptr %ready.count, align 4
  %2765 = load <8 x i1>, ptr %runnable.mask, align 1
  %2766 = or <8 x i1> %2765, %470
  store <8 x i1> %2766, ptr %runnable.mask, align 1
  store <8 x i1> %472, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true384:                         ; preds = %varying.coherent379
  store <8 x i1> %434, ptr %current.mask, align 1
  %2767 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %434)
  br i1 %2767, label %schedule.16, label %scheduler.loop

varying.coherent.false385:                        ; preds = %varying.coherent379
  %2768 = load <8 x float>, ptr %.slot70, align 32
  %2769 = select <8 x i1> %434, <8 x float> zeroinitializer, <8 x float> %2768
  store <8 x float> %2769, ptr %.slot70, align 32
  store <8 x i1> %434, ptr %current.mask, align 1
  %2770 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %434)
  br i1 %2770, label %schedule.17, label %scheduler.loop

convergence.cascade388:                           ; preds = %convergence.cascade388, %schedule.17
  %convergence.cascade.flow392 = phi <8 x i1> [ %495, %schedule.17 ], [ %2813, %convergence.cascade388 ]
  %convergence.cascade.depth393 = phi i32 [ 0, %schedule.17 ], [ %2814, %convergence.cascade388 ]
  %2771 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow392)
  %2772 = load i32, ptr %current.token, align 4
  %2773 = icmp ne i32 %2772, 0
  %2774 = and i1 %2771, %2773
  %2775 = sub i32 %2772, 1
  %2776 = select i1 %2774, i32 %2775, i32 0
  %2777 = load i8, ptr %frame.active, align 1
  %2778 = trunc i32 %2776 to i8
  %2779 = shl i8 1, %2778
  %2780 = and i8 %2777, %2779
  %2781 = icmp ne i8 %2780, 0
  %2782 = load <8 x i32>, ptr %frame.static.id, align 32
  %2783 = extractelement <8 x i32> %2782, i32 %2776
  %convergence.target.pointer394 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %2783
  %convergence.dynamic.target395 = load i32, ptr %convergence.target.pointer394, align 4
  %2784 = icmp eq i32 %convergence.dynamic.target395, 17
  %2785 = and i1 %2781, %2784
  %2786 = and i1 %2774, %2785
  %2787 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2776
  %2788 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2776
  %2789 = load <8 x i1>, ptr %2787, align 1
  %2790 = load <8 x i1>, ptr %2788, align 1
  %2791 = or <8 x i1> %2790, %convergence.cascade.flow392
  %2792 = load <8 x i1>, ptr %live.mask, align 1
  %2793 = and <8 x i1> %2789, %2792
  %2794 = icmp eq <8 x i1> %2791, %2793
  %2795 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2794)
  %2796 = and i1 %2786, %2795
  %2797 = select i1 %2796, <8 x i1> zeroinitializer, <8 x i1> %2791
  %2798 = select i1 %2786, <8 x i1> %2797, <8 x i1> %2790
  store <8 x i1> %2798, ptr %2788, align 1
  %2799 = select i1 %2796, <8 x i1> zeroinitializer, <8 x i1> %2789
  store <8 x i1> %2799, ptr %2787, align 1
  %2800 = trunc i32 %2776 to i8
  %2801 = shl i8 1, %2800
  %2802 = xor i8 %2801, -1
  %2803 = and i8 %2777, %2802
  %2804 = select i1 %2796, i8 %2803, i8 %2777
  store i8 %2804, ptr %frame.active, align 1
  %.splatinsert396 = insertelement <8 x i1> poison, i1 %2786, i64 0
  %.splat397 = shufflevector <8 x i1> %.splatinsert396, <8 x i1> poison, <8 x i32> zeroinitializer
  %2805 = and <8 x i1> %convergence.cascade.flow392, %.splat397
  %2806 = load <8 x i1>, ptr %runnable.mask, align 1
  %2807 = xor <8 x i1> %2805, splat (i1 true)
  %2808 = and <8 x i1> %2806, %2807
  store <8 x i1> %2808, ptr %runnable.mask, align 1
  %.splatinsert398 = insertelement <8 x i1> poison, i1 %2796, i64 0
  %.splat399 = shufflevector <8 x i1> %.splatinsert398, <8 x i1> poison, <8 x i32> zeroinitializer
  %2809 = select <8 x i1> %.splat399, <8 x i1> %2791, <8 x i1> zeroinitializer
  %2810 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2811 = extractelement <8 x i32> %2810, i32 %2776
  %2812 = select i1 %2796, i32 %2811, i32 %2772
  store i32 %2812, ptr %current.token, align 4
  %.splatinsert400 = insertelement <8 x i1> poison, i1 %2786, i64 0
  %.splat401 = shufflevector <8 x i1> %.splatinsert400, <8 x i1> poison, <8 x i32> zeroinitializer
  %2813 = select <8 x i1> %.splat401, <8 x i1> %2809, <8 x i1> %convergence.cascade.flow392
  %2814 = add i32 %convergence.cascade.depth393, 1
  %2815 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2813)
  %2816 = icmp ult i32 %2814, 8
  %2817 = and i1 %2815, %2816
  %2818 = and i1 %2786, %2817
  %convergence.parent.token402 = load i32, ptr %current.token, align 4
  %convergence.parent.present403 = icmp ne i32 %convergence.parent.token402, 0
  %2819 = and i1 %2818, %convergence.parent.present403
  br i1 %2819, label %convergence.cascade388, label %convergence.cascade.exit389

convergence.cascade.exit389:                      ; preds = %convergence.cascade388, %schedule.17
  %convergence.cascade.result404 = phi <8 x i1> [ %495, %schedule.17 ], [ %2813, %convergence.cascade388 ]
  %2820 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result404)
  br i1 %2820, label %convergence.target.17.ready, label %scheduler.loop

convergence.target.17.ready:                      ; preds = %convergence.cascade.exit389
  %2821 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result404)
  %2822 = bitcast <8 x i1> %convergence.cascade.result404 to i8
  %2823 = call i8 @llvm.cttz.i8(i8 %2822, i1 false)
  %2824 = zext i8 %2823 to i32
  %2825 = select i1 %2821, i32 %2824, i32 0
  %.spill.load405 = load float, ptr %.spill49, align 4
  %.splatinsert406 = insertelement <8 x float> poison, float %.spill.load405, i64 0
  %.splat407 = shufflevector <8 x float> %.splatinsert406, <8 x float> poison, <8 x i32> zeroinitializer
  %.state408 = load <8 x float>, ptr %.slot70, align 32
  %.spill.load409 = load volatile <8 x i1>, ptr %.spill68, align 1
  %2826 = select <8 x i1> %.spill.load409, <8 x float> %.state408, <8 x float> %.splat407
  %tile_snapshot.spill.load410 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill66, align 64
  %2827 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 0
  %2828 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 1
  %.state411 = load <8 x i64>, ptr %.slot67, align 64
  %2829 = mul <8 x i64> %.state411, splat (i64 32)
  %2830 = add <8 x i64> %2828, %2829
  %2831 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2827, 0
  %2832 = insertvalue { <8 x ptr>, <8 x i64> } %2831, <8 x i64> %2830, 1
  %2833 = extractvalue { <8 x ptr>, <8 x i64> } %2832, 0
  %2834 = extractvalue { <8 x ptr>, <8 x i64> } %2832, 1
  %2835 = getelementptr i8, <8 x ptr> %2833, <8 x i64> %2834
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %2826, <8 x ptr> %2835, i32 1, <8 x i1> %convergence.cascade.result404)
  %.state412 = load <8 x i64>, ptr %.slot67, align 64
  %2836 = add <8 x i64> %.state412, splat (i64 1)
  %2837 = load <8 x i64>, ptr %.slot67, align 64
  %2838 = select <8 x i1> %convergence.cascade.result404, <8 x i64> %2836, <8 x i64> %2837
  store <8 x i64> %2838, ptr %.slot67, align 64
  store <8 x i1> %convergence.cascade.result404, ptr %current.mask, align 1
  %2839 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result404)
  br i1 %2839, label %schedule.14, label %scheduler.loop

convergence.cascade413:                           ; preds = %convergence.cascade413, %schedule.18
  %convergence.cascade.flow417 = phi <8 x i1> [ %496, %schedule.18 ], [ %2882, %convergence.cascade413 ]
  %convergence.cascade.depth418 = phi i32 [ 0, %schedule.18 ], [ %2883, %convergence.cascade413 ]
  %2840 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow417)
  %2841 = load i32, ptr %current.token, align 4
  %2842 = icmp ne i32 %2841, 0
  %2843 = and i1 %2840, %2842
  %2844 = sub i32 %2841, 1
  %2845 = select i1 %2843, i32 %2844, i32 0
  %2846 = load i8, ptr %frame.active, align 1
  %2847 = trunc i32 %2845 to i8
  %2848 = shl i8 1, %2847
  %2849 = and i8 %2846, %2848
  %2850 = icmp ne i8 %2849, 0
  %2851 = load <8 x i32>, ptr %frame.static.id, align 32
  %2852 = extractelement <8 x i32> %2851, i32 %2845
  %convergence.target.pointer419 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %2852
  %convergence.dynamic.target420 = load i32, ptr %convergence.target.pointer419, align 4
  %2853 = icmp eq i32 %convergence.dynamic.target420, 18
  %2854 = and i1 %2850, %2853
  %2855 = and i1 %2843, %2854
  %2856 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2845
  %2857 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2845
  %2858 = load <8 x i1>, ptr %2856, align 1
  %2859 = load <8 x i1>, ptr %2857, align 1
  %2860 = or <8 x i1> %2859, %convergence.cascade.flow417
  %2861 = load <8 x i1>, ptr %live.mask, align 1
  %2862 = and <8 x i1> %2858, %2861
  %2863 = icmp eq <8 x i1> %2860, %2862
  %2864 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2863)
  %2865 = and i1 %2855, %2864
  %2866 = select i1 %2865, <8 x i1> zeroinitializer, <8 x i1> %2860
  %2867 = select i1 %2855, <8 x i1> %2866, <8 x i1> %2859
  store <8 x i1> %2867, ptr %2857, align 1
  %2868 = select i1 %2865, <8 x i1> zeroinitializer, <8 x i1> %2858
  store <8 x i1> %2868, ptr %2856, align 1
  %2869 = trunc i32 %2845 to i8
  %2870 = shl i8 1, %2869
  %2871 = xor i8 %2870, -1
  %2872 = and i8 %2846, %2871
  %2873 = select i1 %2865, i8 %2872, i8 %2846
  store i8 %2873, ptr %frame.active, align 1
  %.splatinsert421 = insertelement <8 x i1> poison, i1 %2855, i64 0
  %.splat422 = shufflevector <8 x i1> %.splatinsert421, <8 x i1> poison, <8 x i32> zeroinitializer
  %2874 = and <8 x i1> %convergence.cascade.flow417, %.splat422
  %2875 = load <8 x i1>, ptr %runnable.mask, align 1
  %2876 = xor <8 x i1> %2874, splat (i1 true)
  %2877 = and <8 x i1> %2875, %2876
  store <8 x i1> %2877, ptr %runnable.mask, align 1
  %.splatinsert423 = insertelement <8 x i1> poison, i1 %2865, i64 0
  %.splat424 = shufflevector <8 x i1> %.splatinsert423, <8 x i1> poison, <8 x i32> zeroinitializer
  %2878 = select <8 x i1> %.splat424, <8 x i1> %2860, <8 x i1> zeroinitializer
  %2879 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2880 = extractelement <8 x i32> %2879, i32 %2845
  %2881 = select i1 %2865, i32 %2880, i32 %2841
  store i32 %2881, ptr %current.token, align 4
  %.splatinsert425 = insertelement <8 x i1> poison, i1 %2855, i64 0
  %.splat426 = shufflevector <8 x i1> %.splatinsert425, <8 x i1> poison, <8 x i32> zeroinitializer
  %2882 = select <8 x i1> %.splat426, <8 x i1> %2878, <8 x i1> %convergence.cascade.flow417
  %2883 = add i32 %convergence.cascade.depth418, 1
  %2884 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2882)
  %2885 = icmp ult i32 %2883, 8
  %2886 = and i1 %2884, %2885
  %2887 = and i1 %2855, %2886
  %convergence.parent.token427 = load i32, ptr %current.token, align 4
  %convergence.parent.present428 = icmp ne i32 %convergence.parent.token427, 0
  %2888 = and i1 %2887, %convergence.parent.present428
  br i1 %2888, label %convergence.cascade413, label %convergence.cascade.exit414

convergence.cascade.exit414:                      ; preds = %convergence.cascade413, %schedule.18
  %convergence.cascade.result429 = phi <8 x i1> [ %496, %schedule.18 ], [ %2882, %convergence.cascade413 ]
  %2889 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result429)
  br i1 %2889, label %convergence.target.18.ready, label %scheduler.loop

convergence.target.18.ready:                      ; preds = %convergence.cascade.exit414
  %2890 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result429)
  %2891 = bitcast <8 x i1> %convergence.cascade.result429 to i8
  %2892 = call i8 @llvm.cttz.i8(i8 %2891, i1 false)
  %2893 = zext i8 %2892 to i32
  %2894 = select i1 %2890, i32 %2893, i32 0
  %2895 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill71, align 64
  %2896 = extractvalue { <8 x ptr>, <8 x i64> } %15, 0
  %2897 = extractvalue { <8 x ptr>, <8 x i64> } %2895, 0
  %2898 = select <8 x i1> %convergence.cascade.result429, <8 x ptr> %2896, <8 x ptr> %2897
  %2899 = extractvalue { <8 x ptr>, <8 x i64> } %15, 1
  %2900 = extractvalue { <8 x ptr>, <8 x i64> } %2895, 1
  %2901 = select <8 x i1> %convergence.cascade.result429, <8 x i64> %2899, <8 x i64> %2900
  %2902 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2898, 0
  %2903 = insertvalue { <8 x ptr>, <8 x i64> } %2902, <8 x i64> %2901, 1
  store volatile { <8 x ptr>, <8 x i64> } %2903, ptr %tile_snapshot.spill71, align 64
  %2904 = load <8 x i64>, ptr %.slot72, align 64
  %2905 = select <8 x i1> %convergence.cascade.result429, <8 x i64> zeroinitializer, <8 x i64> %2904
  store <8 x i64> %2905, ptr %.slot72, align 64
  store <8 x i1> %convergence.cascade.result429, ptr %current.mask, align 1
  %2906 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result429)
  br i1 %2906, label %schedule.19, label %scheduler.loop

varying.divergent431:                             ; preds = %schedule.19
  %2907 = load i32, ptr %current.token, align 4
  %2908 = icmp ne i32 %2907, 0
  %2909 = sub i32 %2907, 1
  %2910 = select i1 %2908, i32 %2909, i32 0
  %2911 = load i8, ptr %frame.active, align 1
  %2912 = trunc i32 %2910 to i8
  %2913 = shl i8 1, %2912
  %2914 = and i8 %2911, %2913
  %2915 = icmp ne i8 %2914, 0
  %2916 = load <8 x i32>, ptr %frame.static.id, align 32
  %2917 = extractelement <8 x i32> %2916, i32 %2910
  %2918 = icmp eq i32 %2917, 7
  %2919 = and i1 %2915, %2918
  %2920 = and i1 %2908, %2919
  %2921 = xor i1 %2920, true
  %2922 = and i1 true, %2921
  %2923 = xor i8 %2911, -1
  %2924 = icmp ne i8 %2923, 0
  %2925 = xor i1 %2924, true
  %2926 = and i1 %2922, %2925
  br i1 %2926, label %convergence.overflow.trap433, label %convergence.overflow.resume434

varying.coherent432:                              ; preds = %schedule.19
  br i1 %507, label %varying.coherent.true437, label %varying.coherent.false438

convergence.overflow.trap433:                     ; preds = %varying.divergent431
  call void @llvm.trap()
  unreachable

convergence.overflow.resume434:                   ; preds = %varying.divergent431
  %2927 = call i8 @llvm.cttz.i8(i8 %2923, i1 false)
  %2928 = zext i8 %2927 to i32
  %2929 = select i1 %2924, i32 %2928, i32 0
  %2930 = trunc i32 %2929 to i8
  %2931 = shl i8 1, %2930
  %2932 = or i8 %2911, %2931
  %2933 = select i1 %2922, i8 %2932, i8 %2911
  store i8 %2933, ptr %frame.active, align 1
  %2934 = load <8 x i32>, ptr %frame.static.id, align 32
  %2935 = extractelement <8 x i32> %2934, i32 %2929
  %2936 = select i1 %2922, i32 7, i32 %2935
  %2937 = load <8 x i32>, ptr %frame.static.id, align 32
  %2938 = insertelement <8 x i32> %2937, i32 %2936, i32 %2929
  store <8 x i32> %2938, ptr %frame.static.id, align 32
  %2939 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2940 = extractelement <8 x i32> %2939, i32 %2929
  %2941 = select i1 %2922, i32 %2907, i32 %2940
  %2942 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2943 = insertelement <8 x i32> %2942, i32 %2941, i32 %2929
  store <8 x i32> %2943, ptr %frame.parent.token, align 32
  %2944 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2929
  %2945 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2929
  %2946 = load <8 x i1>, ptr %2944, align 1
  %2947 = load <8 x i1>, ptr %2945, align 1
  %2948 = select i1 %2922, <8 x i1> %497, <8 x i1> %2946
  store <8 x i1> %2948, ptr %2944, align 1
  %2949 = select i1 %2922, <8 x i1> zeroinitializer, <8 x i1> %2947
  store <8 x i1> %2949, ptr %2945, align 1
  %2950 = add i32 %2929, 1
  %2951 = select i1 %2920, i32 %2907, i32 %2950
  %2952 = select i1 true, i32 %2951, i32 %2907
  store i32 %2952, ptr %current.token, align 4
  %2953 = load i32, ptr %current.token, align 4
  %2954 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %504)
  %2955 = load i32, ptr %ready.count, align 4
  %2956 = icmp uge i32 %2955, 8
  %2957 = and i1 %2954, %2956
  br i1 %2957, label %ready.overflow.trap435, label %ready.overflow.resume436

ready.overflow.trap435:                           ; preds = %convergence.overflow.resume434
  call void @llvm.trap()
  unreachable

ready.overflow.resume436:                         ; preds = %convergence.overflow.resume434
  %2958 = select i1 %2954, i32 %2955, i32 0
  %2959 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2958
  %2960 = load <8 x i1>, ptr %2959, align 1
  %2961 = select i1 %2954, <8 x i1> %504, <8 x i1> %2960
  store <8 x i1> %2961, ptr %2959, align 1
  %2962 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2958
  %2963 = load i32, ptr %2962, align 4
  %2964 = select i1 %2954, i32 20, i32 %2963
  store i32 %2964, ptr %2962, align 4
  %2965 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2958
  %2966 = load i32, ptr %2965, align 4
  %2967 = select i1 %2954, i32 %2953, i32 %2966
  store i32 %2967, ptr %2965, align 4
  %2968 = add i32 %2955, 1
  %2969 = select i1 %2954, i32 %2968, i32 %2955
  store i32 %2969, ptr %ready.count, align 4
  %2970 = load <8 x i1>, ptr %runnable.mask, align 1
  %2971 = or <8 x i1> %2970, %504
  store <8 x i1> %2971, ptr %runnable.mask, align 1
  store <8 x i1> %506, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true437:                         ; preds = %varying.coherent432
  store <8 x i1> %497, ptr %current.mask, align 1
  %2972 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %497)
  br i1 %2972, label %schedule.20, label %scheduler.loop

varying.coherent.false438:                        ; preds = %varying.coherent432
  store <8 x i1> %497, ptr %current.mask, align 1
  %2973 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %497)
  br i1 %2973, label %schedule.21, label %scheduler.loop

convergence.cascade446:                           ; preds = %convergence.cascade446, %schedule.21
  %convergence.cascade.flow450 = phi <8 x i1> [ %559, %schedule.21 ], [ %3016, %convergence.cascade446 ]
  %convergence.cascade.depth451 = phi i32 [ 0, %schedule.21 ], [ %3017, %convergence.cascade446 ]
  %2974 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow450)
  %2975 = load i32, ptr %current.token, align 4
  %2976 = icmp ne i32 %2975, 0
  %2977 = and i1 %2974, %2976
  %2978 = sub i32 %2975, 1
  %2979 = select i1 %2977, i32 %2978, i32 0
  %2980 = load i8, ptr %frame.active, align 1
  %2981 = trunc i32 %2979 to i8
  %2982 = shl i8 1, %2981
  %2983 = and i8 %2980, %2982
  %2984 = icmp ne i8 %2983, 0
  %2985 = load <8 x i32>, ptr %frame.static.id, align 32
  %2986 = extractelement <8 x i32> %2985, i32 %2979
  %convergence.target.pointer452 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %2986
  %convergence.dynamic.target453 = load i32, ptr %convergence.target.pointer452, align 4
  %2987 = icmp eq i32 %convergence.dynamic.target453, 21
  %2988 = and i1 %2984, %2987
  %2989 = and i1 %2977, %2988
  %2990 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2979
  %2991 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2979
  %2992 = load <8 x i1>, ptr %2990, align 1
  %2993 = load <8 x i1>, ptr %2991, align 1
  %2994 = or <8 x i1> %2993, %convergence.cascade.flow450
  %2995 = load <8 x i1>, ptr %live.mask, align 1
  %2996 = and <8 x i1> %2992, %2995
  %2997 = icmp eq <8 x i1> %2994, %2996
  %2998 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2997)
  %2999 = and i1 %2989, %2998
  %3000 = select i1 %2999, <8 x i1> zeroinitializer, <8 x i1> %2994
  %3001 = select i1 %2989, <8 x i1> %3000, <8 x i1> %2993
  store <8 x i1> %3001, ptr %2991, align 1
  %3002 = select i1 %2999, <8 x i1> zeroinitializer, <8 x i1> %2992
  store <8 x i1> %3002, ptr %2990, align 1
  %3003 = trunc i32 %2979 to i8
  %3004 = shl i8 1, %3003
  %3005 = xor i8 %3004, -1
  %3006 = and i8 %2980, %3005
  %3007 = select i1 %2999, i8 %3006, i8 %2980
  store i8 %3007, ptr %frame.active, align 1
  %.splatinsert454 = insertelement <8 x i1> poison, i1 %2989, i64 0
  %.splat455 = shufflevector <8 x i1> %.splatinsert454, <8 x i1> poison, <8 x i32> zeroinitializer
  %3008 = and <8 x i1> %convergence.cascade.flow450, %.splat455
  %3009 = load <8 x i1>, ptr %runnable.mask, align 1
  %3010 = xor <8 x i1> %3008, splat (i1 true)
  %3011 = and <8 x i1> %3009, %3010
  store <8 x i1> %3011, ptr %runnable.mask, align 1
  %.splatinsert456 = insertelement <8 x i1> poison, i1 %2999, i64 0
  %.splat457 = shufflevector <8 x i1> %.splatinsert456, <8 x i1> poison, <8 x i32> zeroinitializer
  %3012 = select <8 x i1> %.splat457, <8 x i1> %2994, <8 x i1> zeroinitializer
  %3013 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3014 = extractelement <8 x i32> %3013, i32 %2979
  %3015 = select i1 %2999, i32 %3014, i32 %2975
  store i32 %3015, ptr %current.token, align 4
  %.splatinsert458 = insertelement <8 x i1> poison, i1 %2989, i64 0
  %.splat459 = shufflevector <8 x i1> %.splatinsert458, <8 x i1> poison, <8 x i32> zeroinitializer
  %3016 = select <8 x i1> %.splat459, <8 x i1> %3012, <8 x i1> %convergence.cascade.flow450
  %3017 = add i32 %convergence.cascade.depth451, 1
  %3018 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3016)
  %3019 = icmp ult i32 %3017, 8
  %3020 = and i1 %3018, %3019
  %3021 = and i1 %2989, %3020
  %convergence.parent.token460 = load i32, ptr %current.token, align 4
  %convergence.parent.present461 = icmp ne i32 %convergence.parent.token460, 0
  %3022 = and i1 %3021, %convergence.parent.present461
  br i1 %3022, label %convergence.cascade446, label %convergence.cascade.exit447

convergence.cascade.exit447:                      ; preds = %convergence.cascade446, %schedule.21
  %convergence.cascade.result462 = phi <8 x i1> [ %559, %schedule.21 ], [ %3016, %convergence.cascade446 ]
  %3023 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  br i1 %3023, label %convergence.target.21.ready, label %scheduler.loop

convergence.target.21.ready:                      ; preds = %convergence.cascade.exit447
  %3024 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3025 = bitcast <8 x i1> %convergence.cascade.result462 to i8
  %3026 = call i8 @llvm.cttz.i8(i8 %3025, i1 false)
  %3027 = zext i8 %3026 to i32
  %3028 = select i1 %3024, i32 %3027, i32 0
  %3029 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill73, align 64
  %3030 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3031 = extractvalue { <8 x ptr>, <8 x i64> } %3029, 0
  %3032 = select <8 x i1> %convergence.cascade.result462, <8 x ptr> %3030, <8 x ptr> %3031
  %3033 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3034 = extractvalue { <8 x ptr>, <8 x i64> } %3029, 1
  %3035 = select <8 x i1> %convergence.cascade.result462, <8 x i64> %3033, <8 x i64> %3034
  %3036 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3032, 0
  %3037 = insertvalue { <8 x ptr>, <8 x i64> } %3036, <8 x i64> %3035, 1
  store volatile { <8 x ptr>, <8 x i64> } %3037, ptr %tile_snapshot.spill73, align 64
  %3038 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3039 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3040 = add <8 x i64> %3039, zeroinitializer
  %3041 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3038, 0
  %3042 = insertvalue { <8 x ptr>, <8 x i64> } %3041, <8 x i64> %3040, 1
  %3043 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3044 = extractvalue { <8 x ptr>, <8 x i64> } %3042, 1
  %3045 = extractelement <8 x ptr> %3043, i32 0
  %3046 = extractelement <8 x i64> %3044, i32 %3028
  %3047 = zext i32 %3028 to i64
  %3048 = mul i64 %3047, 8
  %3049 = sub i64 %3046, %3048
  %3050 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3051 = select i1 %3050, i64 %3049, i64 0
  %private.contiguous.address463 = getelementptr i8, ptr %3045, i64 %3051
  %private.contiguous.preserve464 = load <8 x i64>, ptr %private.contiguous.address463, align 8
  %3052 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 -4), <8 x i64> %private.contiguous.preserve464
  store <8 x i64> %3052, ptr %private.contiguous.address463, align 8
  %3053 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3054 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3055 = add <8 x i64> %3054, splat (i64 64)
  %3056 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3053, 0
  %3057 = insertvalue { <8 x ptr>, <8 x i64> } %3056, <8 x i64> %3055, 1
  %3058 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3059 = extractvalue { <8 x ptr>, <8 x i64> } %3057, 1
  %3060 = extractelement <8 x ptr> %3058, i32 0
  %3061 = extractelement <8 x i64> %3059, i32 %3028
  %3062 = zext i32 %3028 to i64
  %3063 = mul i64 %3062, 8
  %3064 = sub i64 %3061, %3063
  %3065 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3066 = select i1 %3065, i64 %3064, i64 0
  %private.contiguous.address465 = getelementptr i8, ptr %3060, i64 %3066
  %private.contiguous.preserve466 = load <8 x i64>, ptr %private.contiguous.address465, align 8
  %3067 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 -3), <8 x i64> %private.contiguous.preserve466
  store <8 x i64> %3067, ptr %private.contiguous.address465, align 8
  %3068 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3069 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3070 = add <8 x i64> %3069, splat (i64 128)
  %3071 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3068, 0
  %3072 = insertvalue { <8 x ptr>, <8 x i64> } %3071, <8 x i64> %3070, 1
  %3073 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3074 = extractvalue { <8 x ptr>, <8 x i64> } %3072, 1
  %3075 = extractelement <8 x ptr> %3073, i32 0
  %3076 = extractelement <8 x i64> %3074, i32 %3028
  %3077 = zext i32 %3028 to i64
  %3078 = mul i64 %3077, 8
  %3079 = sub i64 %3076, %3078
  %3080 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3081 = select i1 %3080, i64 %3079, i64 0
  %private.contiguous.address467 = getelementptr i8, ptr %3075, i64 %3081
  %private.contiguous.preserve468 = load <8 x i64>, ptr %private.contiguous.address467, align 8
  %3082 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 -2), <8 x i64> %private.contiguous.preserve468
  store <8 x i64> %3082, ptr %private.contiguous.address467, align 8
  %3083 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3084 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3085 = add <8 x i64> %3084, splat (i64 192)
  %3086 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3083, 0
  %3087 = insertvalue { <8 x ptr>, <8 x i64> } %3086, <8 x i64> %3085, 1
  %3088 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3089 = extractvalue { <8 x ptr>, <8 x i64> } %3087, 1
  %3090 = extractelement <8 x ptr> %3088, i32 0
  %3091 = extractelement <8 x i64> %3089, i32 %3028
  %3092 = zext i32 %3028 to i64
  %3093 = mul i64 %3092, 8
  %3094 = sub i64 %3091, %3093
  %3095 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3096 = select i1 %3095, i64 %3094, i64 0
  %private.contiguous.address469 = getelementptr i8, ptr %3090, i64 %3096
  %private.contiguous.preserve470 = load <8 x i64>, ptr %private.contiguous.address469, align 8
  %3097 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 -1), <8 x i64> %private.contiguous.preserve470
  store <8 x i64> %3097, ptr %private.contiguous.address469, align 8
  %3098 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3099 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3100 = add <8 x i64> %3099, splat (i64 256)
  %3101 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3098, 0
  %3102 = insertvalue { <8 x ptr>, <8 x i64> } %3101, <8 x i64> %3100, 1
  %3103 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3104 = extractvalue { <8 x ptr>, <8 x i64> } %3102, 1
  %3105 = extractelement <8 x ptr> %3103, i32 0
  %3106 = extractelement <8 x i64> %3104, i32 %3028
  %3107 = zext i32 %3028 to i64
  %3108 = mul i64 %3107, 8
  %3109 = sub i64 %3106, %3108
  %3110 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3111 = select i1 %3110, i64 %3109, i64 0
  %private.contiguous.address471 = getelementptr i8, ptr %3105, i64 %3111
  %private.contiguous.preserve472 = load <8 x i64>, ptr %private.contiguous.address471, align 8
  %3112 = select <8 x i1> %convergence.cascade.result462, <8 x i64> zeroinitializer, <8 x i64> %private.contiguous.preserve472
  store <8 x i64> %3112, ptr %private.contiguous.address471, align 8
  %3113 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3114 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3115 = add <8 x i64> %3114, splat (i64 320)
  %3116 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3113, 0
  %3117 = insertvalue { <8 x ptr>, <8 x i64> } %3116, <8 x i64> %3115, 1
  %3118 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3119 = extractvalue { <8 x ptr>, <8 x i64> } %3117, 1
  %3120 = extractelement <8 x ptr> %3118, i32 0
  %3121 = extractelement <8 x i64> %3119, i32 %3028
  %3122 = zext i32 %3028 to i64
  %3123 = mul i64 %3122, 8
  %3124 = sub i64 %3121, %3123
  %3125 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3126 = select i1 %3125, i64 %3124, i64 0
  %private.contiguous.address473 = getelementptr i8, ptr %3120, i64 %3126
  %private.contiguous.preserve474 = load <8 x i64>, ptr %private.contiguous.address473, align 8
  %3127 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 1), <8 x i64> %private.contiguous.preserve474
  store <8 x i64> %3127, ptr %private.contiguous.address473, align 8
  %3128 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3129 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3130 = add <8 x i64> %3129, splat (i64 384)
  %3131 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3128, 0
  %3132 = insertvalue { <8 x ptr>, <8 x i64> } %3131, <8 x i64> %3130, 1
  %3133 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3134 = extractvalue { <8 x ptr>, <8 x i64> } %3132, 1
  %3135 = extractelement <8 x ptr> %3133, i32 0
  %3136 = extractelement <8 x i64> %3134, i32 %3028
  %3137 = zext i32 %3028 to i64
  %3138 = mul i64 %3137, 8
  %3139 = sub i64 %3136, %3138
  %3140 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3141 = select i1 %3140, i64 %3139, i64 0
  %private.contiguous.address475 = getelementptr i8, ptr %3135, i64 %3141
  %private.contiguous.preserve476 = load <8 x i64>, ptr %private.contiguous.address475, align 8
  %3142 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 2), <8 x i64> %private.contiguous.preserve476
  store <8 x i64> %3142, ptr %private.contiguous.address475, align 8
  %3143 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3144 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3145 = add <8 x i64> %3144, splat (i64 448)
  %3146 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3143, 0
  %3147 = insertvalue { <8 x ptr>, <8 x i64> } %3146, <8 x i64> %3145, 1
  %3148 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3149 = extractvalue { <8 x ptr>, <8 x i64> } %3147, 1
  %3150 = extractelement <8 x ptr> %3148, i32 0
  %3151 = extractelement <8 x i64> %3149, i32 %3028
  %3152 = zext i32 %3028 to i64
  %3153 = mul i64 %3152, 8
  %3154 = sub i64 %3151, %3153
  %3155 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3156 = select i1 %3155, i64 %3154, i64 0
  %private.contiguous.address477 = getelementptr i8, ptr %3150, i64 %3156
  %private.contiguous.preserve478 = load <8 x i64>, ptr %private.contiguous.address477, align 8
  %3157 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 3), <8 x i64> %private.contiguous.preserve478
  store <8 x i64> %3157, ptr %private.contiguous.address477, align 8
  %3158 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3159 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3160 = add <8 x i64> %3159, splat (i64 512)
  %3161 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3158, 0
  %3162 = insertvalue { <8 x ptr>, <8 x i64> } %3161, <8 x i64> %3160, 1
  %3163 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3164 = extractvalue { <8 x ptr>, <8 x i64> } %3162, 1
  %3165 = extractelement <8 x ptr> %3163, i32 0
  %3166 = extractelement <8 x i64> %3164, i32 %3028
  %3167 = zext i32 %3028 to i64
  %3168 = mul i64 %3167, 8
  %3169 = sub i64 %3166, %3168
  %3170 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3171 = select i1 %3170, i64 %3169, i64 0
  %private.contiguous.address479 = getelementptr i8, ptr %3165, i64 %3171
  %private.contiguous.preserve480 = load <8 x i64>, ptr %private.contiguous.address479, align 8
  %3172 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 4), <8 x i64> %private.contiguous.preserve480
  store <8 x i64> %3172, ptr %private.contiguous.address479, align 8
  %3173 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3174 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3175 = add <8 x i64> %3174, splat (i64 576)
  %3176 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3173, 0
  %3177 = insertvalue { <8 x ptr>, <8 x i64> } %3176, <8 x i64> %3175, 1
  %3178 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3179 = extractvalue { <8 x ptr>, <8 x i64> } %3177, 1
  %3180 = extractelement <8 x ptr> %3178, i32 0
  %3181 = extractelement <8 x i64> %3179, i32 %3028
  %3182 = zext i32 %3028 to i64
  %3183 = mul i64 %3182, 8
  %3184 = sub i64 %3181, %3183
  %3185 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3186 = select i1 %3185, i64 %3184, i64 0
  %private.contiguous.address481 = getelementptr i8, ptr %3180, i64 %3186
  %private.contiguous.preserve482 = load <8 x i64>, ptr %private.contiguous.address481, align 8
  %3187 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 5), <8 x i64> %private.contiguous.preserve482
  store <8 x i64> %3187, ptr %private.contiguous.address481, align 8
  %3188 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3189 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3190 = add <8 x i64> %3189, splat (i64 640)
  %3191 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3188, 0
  %3192 = insertvalue { <8 x ptr>, <8 x i64> } %3191, <8 x i64> %3190, 1
  %3193 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3194 = extractvalue { <8 x ptr>, <8 x i64> } %3192, 1
  %3195 = extractelement <8 x ptr> %3193, i32 0
  %3196 = extractelement <8 x i64> %3194, i32 %3028
  %3197 = zext i32 %3028 to i64
  %3198 = mul i64 %3197, 8
  %3199 = sub i64 %3196, %3198
  %3200 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3201 = select i1 %3200, i64 %3199, i64 0
  %private.contiguous.address483 = getelementptr i8, ptr %3195, i64 %3201
  %private.contiguous.preserve484 = load <8 x i64>, ptr %private.contiguous.address483, align 8
  %3202 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 6), <8 x i64> %private.contiguous.preserve484
  store <8 x i64> %3202, ptr %private.contiguous.address483, align 8
  %3203 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3204 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3205 = add <8 x i64> %3204, splat (i64 704)
  %3206 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3203, 0
  %3207 = insertvalue { <8 x ptr>, <8 x i64> } %3206, <8 x i64> %3205, 1
  %3208 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3209 = extractvalue { <8 x ptr>, <8 x i64> } %3207, 1
  %3210 = extractelement <8 x ptr> %3208, i32 0
  %3211 = extractelement <8 x i64> %3209, i32 %3028
  %3212 = zext i32 %3028 to i64
  %3213 = mul i64 %3212, 8
  %3214 = sub i64 %3211, %3213
  %3215 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3216 = select i1 %3215, i64 %3214, i64 0
  %private.contiguous.address485 = getelementptr i8, ptr %3210, i64 %3216
  %private.contiguous.preserve486 = load <8 x i64>, ptr %private.contiguous.address485, align 8
  %3217 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 7), <8 x i64> %private.contiguous.preserve486
  store <8 x i64> %3217, ptr %private.contiguous.address485, align 8
  %3218 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3219 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3220 = add <8 x i64> %3219, splat (i64 768)
  %3221 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3218, 0
  %3222 = insertvalue { <8 x ptr>, <8 x i64> } %3221, <8 x i64> %3220, 1
  %3223 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3224 = extractvalue { <8 x ptr>, <8 x i64> } %3222, 1
  %3225 = extractelement <8 x ptr> %3223, i32 0
  %3226 = extractelement <8 x i64> %3224, i32 %3028
  %3227 = zext i32 %3028 to i64
  %3228 = mul i64 %3227, 8
  %3229 = sub i64 %3226, %3228
  %3230 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3231 = select i1 %3230, i64 %3229, i64 0
  %private.contiguous.address487 = getelementptr i8, ptr %3225, i64 %3231
  %private.contiguous.preserve488 = load <8 x i64>, ptr %private.contiguous.address487, align 8
  %3232 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 8), <8 x i64> %private.contiguous.preserve488
  store <8 x i64> %3232, ptr %private.contiguous.address487, align 8
  %3233 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3234 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3235 = add <8 x i64> %3234, splat (i64 832)
  %3236 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3233, 0
  %3237 = insertvalue { <8 x ptr>, <8 x i64> } %3236, <8 x i64> %3235, 1
  %3238 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3239 = extractvalue { <8 x ptr>, <8 x i64> } %3237, 1
  %3240 = extractelement <8 x ptr> %3238, i32 0
  %3241 = extractelement <8 x i64> %3239, i32 %3028
  %3242 = zext i32 %3028 to i64
  %3243 = mul i64 %3242, 8
  %3244 = sub i64 %3241, %3243
  %3245 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3246 = select i1 %3245, i64 %3244, i64 0
  %private.contiguous.address489 = getelementptr i8, ptr %3240, i64 %3246
  %private.contiguous.preserve490 = load <8 x i64>, ptr %private.contiguous.address489, align 8
  %3247 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 9), <8 x i64> %private.contiguous.preserve490
  store <8 x i64> %3247, ptr %private.contiguous.address489, align 8
  %3248 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3249 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3250 = add <8 x i64> %3249, splat (i64 896)
  %3251 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3248, 0
  %3252 = insertvalue { <8 x ptr>, <8 x i64> } %3251, <8 x i64> %3250, 1
  %3253 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3254 = extractvalue { <8 x ptr>, <8 x i64> } %3252, 1
  %3255 = extractelement <8 x ptr> %3253, i32 0
  %3256 = extractelement <8 x i64> %3254, i32 %3028
  %3257 = zext i32 %3028 to i64
  %3258 = mul i64 %3257, 8
  %3259 = sub i64 %3256, %3258
  %3260 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3261 = select i1 %3260, i64 %3259, i64 0
  %private.contiguous.address491 = getelementptr i8, ptr %3255, i64 %3261
  %private.contiguous.preserve492 = load <8 x i64>, ptr %private.contiguous.address491, align 8
  %3262 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 10), <8 x i64> %private.contiguous.preserve492
  store <8 x i64> %3262, ptr %private.contiguous.address491, align 8
  %3263 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3264 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3265 = add <8 x i64> %3264, splat (i64 960)
  %3266 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3263, 0
  %3267 = insertvalue { <8 x ptr>, <8 x i64> } %3266, <8 x i64> %3265, 1
  %3268 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3269 = extractvalue { <8 x ptr>, <8 x i64> } %3267, 1
  %3270 = extractelement <8 x ptr> %3268, i32 0
  %3271 = extractelement <8 x i64> %3269, i32 %3028
  %3272 = zext i32 %3028 to i64
  %3273 = mul i64 %3272, 8
  %3274 = sub i64 %3271, %3273
  %3275 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3276 = select i1 %3275, i64 %3274, i64 0
  %private.contiguous.address493 = getelementptr i8, ptr %3270, i64 %3276
  %private.contiguous.preserve494 = load <8 x i64>, ptr %private.contiguous.address493, align 8
  %3277 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 11), <8 x i64> %private.contiguous.preserve494
  store <8 x i64> %3277, ptr %private.contiguous.address493, align 8
  %3278 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3279 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3280 = add <8 x i64> %3279, splat (i64 1024)
  %3281 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3278, 0
  %3282 = insertvalue { <8 x ptr>, <8 x i64> } %3281, <8 x i64> %3280, 1
  %3283 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3284 = extractvalue { <8 x ptr>, <8 x i64> } %3282, 1
  %3285 = extractelement <8 x ptr> %3283, i32 0
  %3286 = extractelement <8 x i64> %3284, i32 %3028
  %3287 = zext i32 %3028 to i64
  %3288 = mul i64 %3287, 8
  %3289 = sub i64 %3286, %3288
  %3290 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3291 = select i1 %3290, i64 %3289, i64 0
  %private.contiguous.address495 = getelementptr i8, ptr %3285, i64 %3291
  %private.contiguous.preserve496 = load <8 x i64>, ptr %private.contiguous.address495, align 8
  %3292 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 12), <8 x i64> %private.contiguous.preserve496
  store <8 x i64> %3292, ptr %private.contiguous.address495, align 8
  %3293 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3294 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3295 = add <8 x i64> %3294, splat (i64 1088)
  %3296 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3293, 0
  %3297 = insertvalue { <8 x ptr>, <8 x i64> } %3296, <8 x i64> %3295, 1
  %3298 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3299 = extractvalue { <8 x ptr>, <8 x i64> } %3297, 1
  %3300 = extractelement <8 x ptr> %3298, i32 0
  %3301 = extractelement <8 x i64> %3299, i32 %3028
  %3302 = zext i32 %3028 to i64
  %3303 = mul i64 %3302, 8
  %3304 = sub i64 %3301, %3303
  %3305 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3306 = select i1 %3305, i64 %3304, i64 0
  %private.contiguous.address497 = getelementptr i8, ptr %3300, i64 %3306
  %private.contiguous.preserve498 = load <8 x i64>, ptr %private.contiguous.address497, align 8
  %3307 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 13), <8 x i64> %private.contiguous.preserve498
  store <8 x i64> %3307, ptr %private.contiguous.address497, align 8
  %3308 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3309 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3310 = add <8 x i64> %3309, splat (i64 1152)
  %3311 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3308, 0
  %3312 = insertvalue { <8 x ptr>, <8 x i64> } %3311, <8 x i64> %3310, 1
  %3313 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3314 = extractvalue { <8 x ptr>, <8 x i64> } %3312, 1
  %3315 = extractelement <8 x ptr> %3313, i32 0
  %3316 = extractelement <8 x i64> %3314, i32 %3028
  %3317 = zext i32 %3028 to i64
  %3318 = mul i64 %3317, 8
  %3319 = sub i64 %3316, %3318
  %3320 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3321 = select i1 %3320, i64 %3319, i64 0
  %private.contiguous.address499 = getelementptr i8, ptr %3315, i64 %3321
  %private.contiguous.preserve500 = load <8 x i64>, ptr %private.contiguous.address499, align 8
  %3322 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 14), <8 x i64> %private.contiguous.preserve500
  store <8 x i64> %3322, ptr %private.contiguous.address499, align 8
  %3323 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3324 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3325 = add <8 x i64> %3324, splat (i64 1216)
  %3326 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3323, 0
  %3327 = insertvalue { <8 x ptr>, <8 x i64> } %3326, <8 x i64> %3325, 1
  %3328 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3329 = extractvalue { <8 x ptr>, <8 x i64> } %3327, 1
  %3330 = extractelement <8 x ptr> %3328, i32 0
  %3331 = extractelement <8 x i64> %3329, i32 %3028
  %3332 = zext i32 %3028 to i64
  %3333 = mul i64 %3332, 8
  %3334 = sub i64 %3331, %3333
  %3335 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3336 = select i1 %3335, i64 %3334, i64 0
  %private.contiguous.address501 = getelementptr i8, ptr %3330, i64 %3336
  %private.contiguous.preserve502 = load <8 x i64>, ptr %private.contiguous.address501, align 8
  %3337 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 15), <8 x i64> %private.contiguous.preserve502
  store <8 x i64> %3337, ptr %private.contiguous.address501, align 8
  %3338 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3339 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3340 = add <8 x i64> %3339, splat (i64 1280)
  %3341 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3338, 0
  %3342 = insertvalue { <8 x ptr>, <8 x i64> } %3341, <8 x i64> %3340, 1
  %3343 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3344 = extractvalue { <8 x ptr>, <8 x i64> } %3342, 1
  %3345 = extractelement <8 x ptr> %3343, i32 0
  %3346 = extractelement <8 x i64> %3344, i32 %3028
  %3347 = zext i32 %3028 to i64
  %3348 = mul i64 %3347, 8
  %3349 = sub i64 %3346, %3348
  %3350 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3351 = select i1 %3350, i64 %3349, i64 0
  %private.contiguous.address503 = getelementptr i8, ptr %3345, i64 %3351
  %private.contiguous.preserve504 = load <8 x i64>, ptr %private.contiguous.address503, align 8
  %3352 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 16), <8 x i64> %private.contiguous.preserve504
  store <8 x i64> %3352, ptr %private.contiguous.address503, align 8
  %3353 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3354 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3355 = add <8 x i64> %3354, splat (i64 1344)
  %3356 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3353, 0
  %3357 = insertvalue { <8 x ptr>, <8 x i64> } %3356, <8 x i64> %3355, 1
  %3358 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3359 = extractvalue { <8 x ptr>, <8 x i64> } %3357, 1
  %3360 = extractelement <8 x ptr> %3358, i32 0
  %3361 = extractelement <8 x i64> %3359, i32 %3028
  %3362 = zext i32 %3028 to i64
  %3363 = mul i64 %3362, 8
  %3364 = sub i64 %3361, %3363
  %3365 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3366 = select i1 %3365, i64 %3364, i64 0
  %private.contiguous.address505 = getelementptr i8, ptr %3360, i64 %3366
  %private.contiguous.preserve506 = load <8 x i64>, ptr %private.contiguous.address505, align 8
  %3367 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 17), <8 x i64> %private.contiguous.preserve506
  store <8 x i64> %3367, ptr %private.contiguous.address505, align 8
  %3368 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3369 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3370 = add <8 x i64> %3369, splat (i64 1408)
  %3371 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3368, 0
  %3372 = insertvalue { <8 x ptr>, <8 x i64> } %3371, <8 x i64> %3370, 1
  %3373 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3374 = extractvalue { <8 x ptr>, <8 x i64> } %3372, 1
  %3375 = extractelement <8 x ptr> %3373, i32 0
  %3376 = extractelement <8 x i64> %3374, i32 %3028
  %3377 = zext i32 %3028 to i64
  %3378 = mul i64 %3377, 8
  %3379 = sub i64 %3376, %3378
  %3380 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3381 = select i1 %3380, i64 %3379, i64 0
  %private.contiguous.address507 = getelementptr i8, ptr %3375, i64 %3381
  %private.contiguous.preserve508 = load <8 x i64>, ptr %private.contiguous.address507, align 8
  %3382 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 18), <8 x i64> %private.contiguous.preserve508
  store <8 x i64> %3382, ptr %private.contiguous.address507, align 8
  %3383 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3384 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3385 = add <8 x i64> %3384, splat (i64 1472)
  %3386 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3383, 0
  %3387 = insertvalue { <8 x ptr>, <8 x i64> } %3386, <8 x i64> %3385, 1
  %3388 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3389 = extractvalue { <8 x ptr>, <8 x i64> } %3387, 1
  %3390 = extractelement <8 x ptr> %3388, i32 0
  %3391 = extractelement <8 x i64> %3389, i32 %3028
  %3392 = zext i32 %3028 to i64
  %3393 = mul i64 %3392, 8
  %3394 = sub i64 %3391, %3393
  %3395 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3396 = select i1 %3395, i64 %3394, i64 0
  %private.contiguous.address509 = getelementptr i8, ptr %3390, i64 %3396
  %private.contiguous.preserve510 = load <8 x i64>, ptr %private.contiguous.address509, align 8
  %3397 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 19), <8 x i64> %private.contiguous.preserve510
  store <8 x i64> %3397, ptr %private.contiguous.address509, align 8
  %3398 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3399 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3400 = add <8 x i64> %3399, splat (i64 1536)
  %3401 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3398, 0
  %3402 = insertvalue { <8 x ptr>, <8 x i64> } %3401, <8 x i64> %3400, 1
  %3403 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3404 = extractvalue { <8 x ptr>, <8 x i64> } %3402, 1
  %3405 = extractelement <8 x ptr> %3403, i32 0
  %3406 = extractelement <8 x i64> %3404, i32 %3028
  %3407 = zext i32 %3028 to i64
  %3408 = mul i64 %3407, 8
  %3409 = sub i64 %3406, %3408
  %3410 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3411 = select i1 %3410, i64 %3409, i64 0
  %private.contiguous.address511 = getelementptr i8, ptr %3405, i64 %3411
  %private.contiguous.preserve512 = load <8 x i64>, ptr %private.contiguous.address511, align 8
  %3412 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 20), <8 x i64> %private.contiguous.preserve512
  store <8 x i64> %3412, ptr %private.contiguous.address511, align 8
  %3413 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3414 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3415 = add <8 x i64> %3414, splat (i64 1600)
  %3416 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3413, 0
  %3417 = insertvalue { <8 x ptr>, <8 x i64> } %3416, <8 x i64> %3415, 1
  %3418 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3419 = extractvalue { <8 x ptr>, <8 x i64> } %3417, 1
  %3420 = extractelement <8 x ptr> %3418, i32 0
  %3421 = extractelement <8 x i64> %3419, i32 %3028
  %3422 = zext i32 %3028 to i64
  %3423 = mul i64 %3422, 8
  %3424 = sub i64 %3421, %3423
  %3425 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3426 = select i1 %3425, i64 %3424, i64 0
  %private.contiguous.address513 = getelementptr i8, ptr %3420, i64 %3426
  %private.contiguous.preserve514 = load <8 x i64>, ptr %private.contiguous.address513, align 8
  %3427 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 21), <8 x i64> %private.contiguous.preserve514
  store <8 x i64> %3427, ptr %private.contiguous.address513, align 8
  %3428 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3429 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3430 = add <8 x i64> %3429, splat (i64 1664)
  %3431 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3428, 0
  %3432 = insertvalue { <8 x ptr>, <8 x i64> } %3431, <8 x i64> %3430, 1
  %3433 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3434 = extractvalue { <8 x ptr>, <8 x i64> } %3432, 1
  %3435 = extractelement <8 x ptr> %3433, i32 0
  %3436 = extractelement <8 x i64> %3434, i32 %3028
  %3437 = zext i32 %3028 to i64
  %3438 = mul i64 %3437, 8
  %3439 = sub i64 %3436, %3438
  %3440 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3441 = select i1 %3440, i64 %3439, i64 0
  %private.contiguous.address515 = getelementptr i8, ptr %3435, i64 %3441
  %private.contiguous.preserve516 = load <8 x i64>, ptr %private.contiguous.address515, align 8
  %3442 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 22), <8 x i64> %private.contiguous.preserve516
  store <8 x i64> %3442, ptr %private.contiguous.address515, align 8
  %3443 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3444 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3445 = add <8 x i64> %3444, splat (i64 1728)
  %3446 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3443, 0
  %3447 = insertvalue { <8 x ptr>, <8 x i64> } %3446, <8 x i64> %3445, 1
  %3448 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3449 = extractvalue { <8 x ptr>, <8 x i64> } %3447, 1
  %3450 = extractelement <8 x ptr> %3448, i32 0
  %3451 = extractelement <8 x i64> %3449, i32 %3028
  %3452 = zext i32 %3028 to i64
  %3453 = mul i64 %3452, 8
  %3454 = sub i64 %3451, %3453
  %3455 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3456 = select i1 %3455, i64 %3454, i64 0
  %private.contiguous.address517 = getelementptr i8, ptr %3450, i64 %3456
  %private.contiguous.preserve518 = load <8 x i64>, ptr %private.contiguous.address517, align 8
  %3457 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 23), <8 x i64> %private.contiguous.preserve518
  store <8 x i64> %3457, ptr %private.contiguous.address517, align 8
  %3458 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3459 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3460 = add <8 x i64> %3459, splat (i64 1792)
  %3461 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3458, 0
  %3462 = insertvalue { <8 x ptr>, <8 x i64> } %3461, <8 x i64> %3460, 1
  %3463 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3464 = extractvalue { <8 x ptr>, <8 x i64> } %3462, 1
  %3465 = extractelement <8 x ptr> %3463, i32 0
  %3466 = extractelement <8 x i64> %3464, i32 %3028
  %3467 = zext i32 %3028 to i64
  %3468 = mul i64 %3467, 8
  %3469 = sub i64 %3466, %3468
  %3470 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3471 = select i1 %3470, i64 %3469, i64 0
  %private.contiguous.address519 = getelementptr i8, ptr %3465, i64 %3471
  %private.contiguous.preserve520 = load <8 x i64>, ptr %private.contiguous.address519, align 8
  %3472 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 24), <8 x i64> %private.contiguous.preserve520
  store <8 x i64> %3472, ptr %private.contiguous.address519, align 8
  %3473 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3474 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3475 = add <8 x i64> %3474, splat (i64 1856)
  %3476 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3473, 0
  %3477 = insertvalue { <8 x ptr>, <8 x i64> } %3476, <8 x i64> %3475, 1
  %3478 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3479 = extractvalue { <8 x ptr>, <8 x i64> } %3477, 1
  %3480 = extractelement <8 x ptr> %3478, i32 0
  %3481 = extractelement <8 x i64> %3479, i32 %3028
  %3482 = zext i32 %3028 to i64
  %3483 = mul i64 %3482, 8
  %3484 = sub i64 %3481, %3483
  %3485 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3486 = select i1 %3485, i64 %3484, i64 0
  %private.contiguous.address521 = getelementptr i8, ptr %3480, i64 %3486
  %private.contiguous.preserve522 = load <8 x i64>, ptr %private.contiguous.address521, align 8
  %3487 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 25), <8 x i64> %private.contiguous.preserve522
  store <8 x i64> %3487, ptr %private.contiguous.address521, align 8
  %3488 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3489 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3490 = add <8 x i64> %3489, splat (i64 1920)
  %3491 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3488, 0
  %3492 = insertvalue { <8 x ptr>, <8 x i64> } %3491, <8 x i64> %3490, 1
  %3493 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3494 = extractvalue { <8 x ptr>, <8 x i64> } %3492, 1
  %3495 = extractelement <8 x ptr> %3493, i32 0
  %3496 = extractelement <8 x i64> %3494, i32 %3028
  %3497 = zext i32 %3028 to i64
  %3498 = mul i64 %3497, 8
  %3499 = sub i64 %3496, %3498
  %3500 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3501 = select i1 %3500, i64 %3499, i64 0
  %private.contiguous.address523 = getelementptr i8, ptr %3495, i64 %3501
  %private.contiguous.preserve524 = load <8 x i64>, ptr %private.contiguous.address523, align 8
  %3502 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 26), <8 x i64> %private.contiguous.preserve524
  store <8 x i64> %3502, ptr %private.contiguous.address523, align 8
  %3503 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3504 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3505 = add <8 x i64> %3504, splat (i64 1984)
  %3506 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3503, 0
  %3507 = insertvalue { <8 x ptr>, <8 x i64> } %3506, <8 x i64> %3505, 1
  %3508 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3509 = extractvalue { <8 x ptr>, <8 x i64> } %3507, 1
  %3510 = extractelement <8 x ptr> %3508, i32 0
  %3511 = extractelement <8 x i64> %3509, i32 %3028
  %3512 = zext i32 %3028 to i64
  %3513 = mul i64 %3512, 8
  %3514 = sub i64 %3511, %3513
  %3515 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  %3516 = select i1 %3515, i64 %3514, i64 0
  %private.contiguous.address525 = getelementptr i8, ptr %3510, i64 %3516
  %private.contiguous.preserve526 = load <8 x i64>, ptr %private.contiguous.address525, align 8
  %3517 = select <8 x i1> %convergence.cascade.result462, <8 x i64> splat (i64 27), <8 x i64> %private.contiguous.preserve526
  store <8 x i64> %3517, ptr %private.contiguous.address525, align 8
  %3518 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill74, align 64
  %3519 = extractvalue { <8 x ptr>, <8 x i64> } %19, 0
  %3520 = extractvalue { <8 x ptr>, <8 x i64> } %3518, 0
  %3521 = select <8 x i1> %convergence.cascade.result462, <8 x ptr> %3519, <8 x ptr> %3520
  %3522 = extractvalue { <8 x ptr>, <8 x i64> } %19, 1
  %3523 = extractvalue { <8 x ptr>, <8 x i64> } %3518, 1
  %3524 = select <8 x i1> %convergence.cascade.result462, <8 x i64> %3522, <8 x i64> %3523
  %3525 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3521, 0
  %3526 = insertvalue { <8 x ptr>, <8 x i64> } %3525, <8 x i64> %3524, 1
  store volatile { <8 x ptr>, <8 x i64> } %3526, ptr %tile_snapshot.spill74, align 64
  %3527 = load <8 x i64>, ptr %.slot75, align 64
  %3528 = select <8 x i1> %convergence.cascade.result462, <8 x i64> zeroinitializer, <8 x i64> %3527
  store <8 x i64> %3528, ptr %.slot75, align 64
  store <8 x i1> %convergence.cascade.result462, ptr %current.mask, align 1
  %3529 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result462)
  br i1 %3529, label %schedule.22, label %scheduler.loop

varying.divergent528:                             ; preds = %schedule.22
  %3530 = load i32, ptr %current.token, align 4
  %3531 = icmp ne i32 %3530, 0
  %3532 = sub i32 %3530, 1
  %3533 = select i1 %3531, i32 %3532, i32 0
  %3534 = load i8, ptr %frame.active, align 1
  %3535 = trunc i32 %3533 to i8
  %3536 = shl i8 1, %3535
  %3537 = and i8 %3534, %3536
  %3538 = icmp ne i8 %3537, 0
  %3539 = load <8 x i32>, ptr %frame.static.id, align 32
  %3540 = extractelement <8 x i32> %3539, i32 %3533
  %3541 = icmp eq i32 %3540, 8
  %3542 = and i1 %3538, %3541
  %3543 = and i1 %3531, %3542
  %3544 = xor i1 %3543, true
  %3545 = and i1 true, %3544
  %3546 = xor i8 %3534, -1
  %3547 = icmp ne i8 %3546, 0
  %3548 = xor i1 %3547, true
  %3549 = and i1 %3545, %3548
  br i1 %3549, label %convergence.overflow.trap530, label %convergence.overflow.resume531

varying.coherent529:                              ; preds = %schedule.22
  br i1 %570, label %varying.coherent.true534, label %varying.coherent.false535

convergence.overflow.trap530:                     ; preds = %varying.divergent528
  call void @llvm.trap()
  unreachable

convergence.overflow.resume531:                   ; preds = %varying.divergent528
  %3550 = call i8 @llvm.cttz.i8(i8 %3546, i1 false)
  %3551 = zext i8 %3550 to i32
  %3552 = select i1 %3547, i32 %3551, i32 0
  %3553 = trunc i32 %3552 to i8
  %3554 = shl i8 1, %3553
  %3555 = or i8 %3534, %3554
  %3556 = select i1 %3545, i8 %3555, i8 %3534
  store i8 %3556, ptr %frame.active, align 1
  %3557 = load <8 x i32>, ptr %frame.static.id, align 32
  %3558 = extractelement <8 x i32> %3557, i32 %3552
  %3559 = select i1 %3545, i32 8, i32 %3558
  %3560 = load <8 x i32>, ptr %frame.static.id, align 32
  %3561 = insertelement <8 x i32> %3560, i32 %3559, i32 %3552
  store <8 x i32> %3561, ptr %frame.static.id, align 32
  %3562 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3563 = extractelement <8 x i32> %3562, i32 %3552
  %3564 = select i1 %3545, i32 %3530, i32 %3563
  %3565 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3566 = insertelement <8 x i32> %3565, i32 %3564, i32 %3552
  store <8 x i32> %3566, ptr %frame.parent.token, align 32
  %3567 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3552
  %3568 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3552
  %3569 = load <8 x i1>, ptr %3567, align 1
  %3570 = load <8 x i1>, ptr %3568, align 1
  %3571 = select i1 %3545, <8 x i1> %560, <8 x i1> %3569
  store <8 x i1> %3571, ptr %3567, align 1
  %3572 = select i1 %3545, <8 x i1> zeroinitializer, <8 x i1> %3570
  store <8 x i1> %3572, ptr %3568, align 1
  %3573 = add i32 %3552, 1
  %3574 = select i1 %3543, i32 %3530, i32 %3573
  %3575 = select i1 true, i32 %3574, i32 %3530
  store i32 %3575, ptr %current.token, align 4
  %3576 = load i32, ptr %current.token, align 4
  %3577 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %567)
  %3578 = load i32, ptr %ready.count, align 4
  %3579 = icmp uge i32 %3578, 8
  %3580 = and i1 %3577, %3579
  br i1 %3580, label %ready.overflow.trap532, label %ready.overflow.resume533

ready.overflow.trap532:                           ; preds = %convergence.overflow.resume531
  call void @llvm.trap()
  unreachable

ready.overflow.resume533:                         ; preds = %convergence.overflow.resume531
  %3581 = select i1 %3577, i32 %3578, i32 0
  %3582 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3581
  %3583 = load <8 x i1>, ptr %3582, align 1
  %3584 = select i1 %3577, <8 x i1> %567, <8 x i1> %3583
  store <8 x i1> %3584, ptr %3582, align 1
  %3585 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3581
  %3586 = load i32, ptr %3585, align 4
  %3587 = select i1 %3577, i32 23, i32 %3586
  store i32 %3587, ptr %3585, align 4
  %3588 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3581
  %3589 = load i32, ptr %3588, align 4
  %3590 = select i1 %3577, i32 %3576, i32 %3589
  store i32 %3590, ptr %3588, align 4
  %3591 = add i32 %3578, 1
  %3592 = select i1 %3577, i32 %3591, i32 %3578
  store i32 %3592, ptr %ready.count, align 4
  %3593 = load <8 x i1>, ptr %runnable.mask, align 1
  %3594 = or <8 x i1> %3593, %567
  store <8 x i1> %3594, ptr %runnable.mask, align 1
  store <8 x i1> %569, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true534:                         ; preds = %varying.coherent529
  store <8 x i1> %560, ptr %current.mask, align 1
  %3595 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %560)
  br i1 %3595, label %schedule.23, label %scheduler.loop

varying.coherent.false535:                        ; preds = %varying.coherent529
  store <8 x i1> %560, ptr %current.mask, align 1
  %3596 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %560)
  br i1 %3596, label %schedule.26, label %scheduler.loop

varying.divergent539:                             ; preds = %schedule.23
  %3597 = load i32, ptr %current.token, align 4
  %3598 = icmp ne i32 %3597, 0
  %3599 = sub i32 %3597, 1
  %3600 = select i1 %3598, i32 %3599, i32 0
  %3601 = load i8, ptr %frame.active, align 1
  %3602 = trunc i32 %3600 to i8
  %3603 = shl i8 1, %3602
  %3604 = and i8 %3601, %3603
  %3605 = icmp ne i8 %3604, 0
  %3606 = load <8 x i32>, ptr %frame.static.id, align 32
  %3607 = extractelement <8 x i32> %3606, i32 %3600
  %3608 = icmp eq i32 %3607, 9
  %3609 = and i1 %3605, %3608
  %3610 = and i1 %3598, %3609
  %3611 = xor i1 %3610, true
  %3612 = and i1 true, %3611
  %3613 = xor i8 %3601, -1
  %3614 = icmp ne i8 %3613, 0
  %3615 = xor i1 %3614, true
  %3616 = and i1 %3612, %3615
  br i1 %3616, label %convergence.overflow.trap541, label %convergence.overflow.resume542

varying.coherent540:                              ; preds = %schedule.23
  br i1 %612, label %varying.coherent.true545, label %varying.coherent.false546

convergence.overflow.trap541:                     ; preds = %varying.divergent539
  call void @llvm.trap()
  unreachable

convergence.overflow.resume542:                   ; preds = %varying.divergent539
  %3617 = call i8 @llvm.cttz.i8(i8 %3613, i1 false)
  %3618 = zext i8 %3617 to i32
  %3619 = select i1 %3614, i32 %3618, i32 0
  %3620 = trunc i32 %3619 to i8
  %3621 = shl i8 1, %3620
  %3622 = or i8 %3601, %3621
  %3623 = select i1 %3612, i8 %3622, i8 %3601
  store i8 %3623, ptr %frame.active, align 1
  %3624 = load <8 x i32>, ptr %frame.static.id, align 32
  %3625 = extractelement <8 x i32> %3624, i32 %3619
  %3626 = select i1 %3612, i32 9, i32 %3625
  %3627 = load <8 x i32>, ptr %frame.static.id, align 32
  %3628 = insertelement <8 x i32> %3627, i32 %3626, i32 %3619
  store <8 x i32> %3628, ptr %frame.static.id, align 32
  %3629 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3630 = extractelement <8 x i32> %3629, i32 %3619
  %3631 = select i1 %3612, i32 %3597, i32 %3630
  %3632 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3633 = insertelement <8 x i32> %3632, i32 %3631, i32 %3619
  store <8 x i32> %3633, ptr %frame.parent.token, align 32
  %3634 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3619
  %3635 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3619
  %3636 = load <8 x i1>, ptr %3634, align 1
  %3637 = load <8 x i1>, ptr %3635, align 1
  %3638 = select i1 %3612, <8 x i1> %573, <8 x i1> %3636
  store <8 x i1> %3638, ptr %3634, align 1
  %3639 = select i1 %3612, <8 x i1> zeroinitializer, <8 x i1> %3637
  store <8 x i1> %3639, ptr %3635, align 1
  %3640 = add i32 %3619, 1
  %3641 = select i1 %3610, i32 %3597, i32 %3640
  %3642 = select i1 true, i32 %3641, i32 %3597
  store i32 %3642, ptr %current.token, align 4
  %3643 = load <8 x float>, ptr %.slot78, align 32
  %3644 = select <8 x i1> %611, <8 x float> zeroinitializer, <8 x float> %3643
  store <8 x float> %3644, ptr %.slot78, align 32
  %3645 = load i32, ptr %current.token, align 4
  %3646 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %609)
  %3647 = load i32, ptr %ready.count, align 4
  %3648 = icmp uge i32 %3647, 8
  %3649 = and i1 %3646, %3648
  br i1 %3649, label %ready.overflow.trap543, label %ready.overflow.resume544

ready.overflow.trap543:                           ; preds = %convergence.overflow.resume542
  call void @llvm.trap()
  unreachable

ready.overflow.resume544:                         ; preds = %convergence.overflow.resume542
  %3650 = select i1 %3646, i32 %3647, i32 0
  %3651 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3650
  %3652 = load <8 x i1>, ptr %3651, align 1
  %3653 = select i1 %3646, <8 x i1> %609, <8 x i1> %3652
  store <8 x i1> %3653, ptr %3651, align 1
  %3654 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3650
  %3655 = load i32, ptr %3654, align 4
  %3656 = select i1 %3646, i32 24, i32 %3655
  store i32 %3656, ptr %3654, align 4
  %3657 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3650
  %3658 = load i32, ptr %3657, align 4
  %3659 = select i1 %3646, i32 %3645, i32 %3658
  store i32 %3659, ptr %3657, align 4
  %3660 = add i32 %3647, 1
  %3661 = select i1 %3646, i32 %3660, i32 %3647
  store i32 %3661, ptr %ready.count, align 4
  %3662 = load <8 x i1>, ptr %runnable.mask, align 1
  %3663 = or <8 x i1> %3662, %609
  store <8 x i1> %3663, ptr %runnable.mask, align 1
  store <8 x i1> %611, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true545:                         ; preds = %varying.coherent540
  store <8 x i1> %573, ptr %current.mask, align 1
  %3664 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %573)
  br i1 %3664, label %schedule.24, label %scheduler.loop

varying.coherent.false546:                        ; preds = %varying.coherent540
  %3665 = load <8 x float>, ptr %.slot78, align 32
  %3666 = select <8 x i1> %573, <8 x float> zeroinitializer, <8 x float> %3665
  store <8 x float> %3666, ptr %.slot78, align 32
  store <8 x i1> %573, ptr %current.mask, align 1
  %3667 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %573)
  br i1 %3667, label %schedule.25, label %scheduler.loop

convergence.cascade549:                           ; preds = %convergence.cascade549, %schedule.25
  %convergence.cascade.flow553 = phi <8 x i1> [ %634, %schedule.25 ], [ %3710, %convergence.cascade549 ]
  %convergence.cascade.depth554 = phi i32 [ 0, %schedule.25 ], [ %3711, %convergence.cascade549 ]
  %3668 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow553)
  %3669 = load i32, ptr %current.token, align 4
  %3670 = icmp ne i32 %3669, 0
  %3671 = and i1 %3668, %3670
  %3672 = sub i32 %3669, 1
  %3673 = select i1 %3671, i32 %3672, i32 0
  %3674 = load i8, ptr %frame.active, align 1
  %3675 = trunc i32 %3673 to i8
  %3676 = shl i8 1, %3675
  %3677 = and i8 %3674, %3676
  %3678 = icmp ne i8 %3677, 0
  %3679 = load <8 x i32>, ptr %frame.static.id, align 32
  %3680 = extractelement <8 x i32> %3679, i32 %3673
  %convergence.target.pointer555 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %3680
  %convergence.dynamic.target556 = load i32, ptr %convergence.target.pointer555, align 4
  %3681 = icmp eq i32 %convergence.dynamic.target556, 25
  %3682 = and i1 %3678, %3681
  %3683 = and i1 %3671, %3682
  %3684 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3673
  %3685 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3673
  %3686 = load <8 x i1>, ptr %3684, align 1
  %3687 = load <8 x i1>, ptr %3685, align 1
  %3688 = or <8 x i1> %3687, %convergence.cascade.flow553
  %3689 = load <8 x i1>, ptr %live.mask, align 1
  %3690 = and <8 x i1> %3686, %3689
  %3691 = icmp eq <8 x i1> %3688, %3690
  %3692 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3691)
  %3693 = and i1 %3683, %3692
  %3694 = select i1 %3693, <8 x i1> zeroinitializer, <8 x i1> %3688
  %3695 = select i1 %3683, <8 x i1> %3694, <8 x i1> %3687
  store <8 x i1> %3695, ptr %3685, align 1
  %3696 = select i1 %3693, <8 x i1> zeroinitializer, <8 x i1> %3686
  store <8 x i1> %3696, ptr %3684, align 1
  %3697 = trunc i32 %3673 to i8
  %3698 = shl i8 1, %3697
  %3699 = xor i8 %3698, -1
  %3700 = and i8 %3674, %3699
  %3701 = select i1 %3693, i8 %3700, i8 %3674
  store i8 %3701, ptr %frame.active, align 1
  %.splatinsert557 = insertelement <8 x i1> poison, i1 %3683, i64 0
  %.splat558 = shufflevector <8 x i1> %.splatinsert557, <8 x i1> poison, <8 x i32> zeroinitializer
  %3702 = and <8 x i1> %convergence.cascade.flow553, %.splat558
  %3703 = load <8 x i1>, ptr %runnable.mask, align 1
  %3704 = xor <8 x i1> %3702, splat (i1 true)
  %3705 = and <8 x i1> %3703, %3704
  store <8 x i1> %3705, ptr %runnable.mask, align 1
  %.splatinsert559 = insertelement <8 x i1> poison, i1 %3693, i64 0
  %.splat560 = shufflevector <8 x i1> %.splatinsert559, <8 x i1> poison, <8 x i32> zeroinitializer
  %3706 = select <8 x i1> %.splat560, <8 x i1> %3688, <8 x i1> zeroinitializer
  %3707 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3708 = extractelement <8 x i32> %3707, i32 %3673
  %3709 = select i1 %3693, i32 %3708, i32 %3669
  store i32 %3709, ptr %current.token, align 4
  %.splatinsert561 = insertelement <8 x i1> poison, i1 %3683, i64 0
  %.splat562 = shufflevector <8 x i1> %.splatinsert561, <8 x i1> poison, <8 x i32> zeroinitializer
  %3710 = select <8 x i1> %.splat562, <8 x i1> %3706, <8 x i1> %convergence.cascade.flow553
  %3711 = add i32 %convergence.cascade.depth554, 1
  %3712 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3710)
  %3713 = icmp ult i32 %3711, 8
  %3714 = and i1 %3712, %3713
  %3715 = and i1 %3683, %3714
  %convergence.parent.token563 = load i32, ptr %current.token, align 4
  %convergence.parent.present564 = icmp ne i32 %convergence.parent.token563, 0
  %3716 = and i1 %3715, %convergence.parent.present564
  br i1 %3716, label %convergence.cascade549, label %convergence.cascade.exit550

convergence.cascade.exit550:                      ; preds = %convergence.cascade549, %schedule.25
  %convergence.cascade.result565 = phi <8 x i1> [ %634, %schedule.25 ], [ %3710, %convergence.cascade549 ]
  %3717 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result565)
  br i1 %3717, label %convergence.target.25.ready, label %scheduler.loop

convergence.target.25.ready:                      ; preds = %convergence.cascade.exit550
  %3718 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result565)
  %3719 = bitcast <8 x i1> %convergence.cascade.result565 to i8
  %3720 = call i8 @llvm.cttz.i8(i8 %3719, i1 false)
  %3721 = zext i8 %3720 to i32
  %3722 = select i1 %3718, i32 %3721, i32 0
  %.spill.load566 = load float, ptr %.spill49, align 4
  %.splatinsert567 = insertelement <8 x float> poison, float %.spill.load566, i64 0
  %.splat568 = shufflevector <8 x float> %.splatinsert567, <8 x float> poison, <8 x i32> zeroinitializer
  %.state569 = load <8 x float>, ptr %.slot78, align 32
  %.spill.load570 = load volatile <8 x i1>, ptr %.spill76, align 1
  %3723 = select <8 x i1> %.spill.load570, <8 x float> %.state569, <8 x float> %.splat568
  %tile_snapshot.spill.load571 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill74, align 64
  %3724 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load571, 0
  %3725 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load571, 1
  %.state572 = load <8 x i64>, ptr %.slot75, align 64
  %3726 = mul <8 x i64> %.state572, splat (i64 32)
  %3727 = add <8 x i64> %3725, %3726
  %3728 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3724, 0
  %3729 = insertvalue { <8 x ptr>, <8 x i64> } %3728, <8 x i64> %3727, 1
  %3730 = extractvalue { <8 x ptr>, <8 x i64> } %3729, 0
  %3731 = extractvalue { <8 x ptr>, <8 x i64> } %3729, 1
  %3732 = getelementptr i8, <8 x ptr> %3730, <8 x i64> %3731
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %3723, <8 x ptr> %3732, i32 1, <8 x i1> %convergence.cascade.result565)
  %.state573 = load <8 x i64>, ptr %.slot75, align 64
  %3733 = add <8 x i64> %.state573, splat (i64 1)
  %3734 = load <8 x i64>, ptr %.slot75, align 64
  %3735 = select <8 x i1> %convergence.cascade.result565, <8 x i64> %3733, <8 x i64> %3734
  store <8 x i64> %3735, ptr %.slot75, align 64
  store <8 x i1> %convergence.cascade.result565, ptr %current.mask, align 1
  %3736 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result565)
  br i1 %3736, label %schedule.22, label %scheduler.loop

convergence.cascade574:                           ; preds = %convergence.cascade574, %schedule.26
  %convergence.cascade.flow578 = phi <8 x i1> [ %635, %schedule.26 ], [ %3779, %convergence.cascade574 ]
  %convergence.cascade.depth579 = phi i32 [ 0, %schedule.26 ], [ %3780, %convergence.cascade574 ]
  %3737 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow578)
  %3738 = load i32, ptr %current.token, align 4
  %3739 = icmp ne i32 %3738, 0
  %3740 = and i1 %3737, %3739
  %3741 = sub i32 %3738, 1
  %3742 = select i1 %3740, i32 %3741, i32 0
  %3743 = load i8, ptr %frame.active, align 1
  %3744 = trunc i32 %3742 to i8
  %3745 = shl i8 1, %3744
  %3746 = and i8 %3743, %3745
  %3747 = icmp ne i8 %3746, 0
  %3748 = load <8 x i32>, ptr %frame.static.id, align 32
  %3749 = extractelement <8 x i32> %3748, i32 %3742
  %convergence.target.pointer580 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %3749
  %convergence.dynamic.target581 = load i32, ptr %convergence.target.pointer580, align 4
  %3750 = icmp eq i32 %convergence.dynamic.target581, 26
  %3751 = and i1 %3747, %3750
  %3752 = and i1 %3740, %3751
  %3753 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3742
  %3754 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3742
  %3755 = load <8 x i1>, ptr %3753, align 1
  %3756 = load <8 x i1>, ptr %3754, align 1
  %3757 = or <8 x i1> %3756, %convergence.cascade.flow578
  %3758 = load <8 x i1>, ptr %live.mask, align 1
  %3759 = and <8 x i1> %3755, %3758
  %3760 = icmp eq <8 x i1> %3757, %3759
  %3761 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3760)
  %3762 = and i1 %3752, %3761
  %3763 = select i1 %3762, <8 x i1> zeroinitializer, <8 x i1> %3757
  %3764 = select i1 %3752, <8 x i1> %3763, <8 x i1> %3756
  store <8 x i1> %3764, ptr %3754, align 1
  %3765 = select i1 %3762, <8 x i1> zeroinitializer, <8 x i1> %3755
  store <8 x i1> %3765, ptr %3753, align 1
  %3766 = trunc i32 %3742 to i8
  %3767 = shl i8 1, %3766
  %3768 = xor i8 %3767, -1
  %3769 = and i8 %3743, %3768
  %3770 = select i1 %3762, i8 %3769, i8 %3743
  store i8 %3770, ptr %frame.active, align 1
  %.splatinsert582 = insertelement <8 x i1> poison, i1 %3752, i64 0
  %.splat583 = shufflevector <8 x i1> %.splatinsert582, <8 x i1> poison, <8 x i32> zeroinitializer
  %3771 = and <8 x i1> %convergence.cascade.flow578, %.splat583
  %3772 = load <8 x i1>, ptr %runnable.mask, align 1
  %3773 = xor <8 x i1> %3771, splat (i1 true)
  %3774 = and <8 x i1> %3772, %3773
  store <8 x i1> %3774, ptr %runnable.mask, align 1
  %.splatinsert584 = insertelement <8 x i1> poison, i1 %3762, i64 0
  %.splat585 = shufflevector <8 x i1> %.splatinsert584, <8 x i1> poison, <8 x i32> zeroinitializer
  %3775 = select <8 x i1> %.splat585, <8 x i1> %3757, <8 x i1> zeroinitializer
  %3776 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3777 = extractelement <8 x i32> %3776, i32 %3742
  %3778 = select i1 %3762, i32 %3777, i32 %3738
  store i32 %3778, ptr %current.token, align 4
  %.splatinsert586 = insertelement <8 x i1> poison, i1 %3752, i64 0
  %.splat587 = shufflevector <8 x i1> %.splatinsert586, <8 x i1> poison, <8 x i32> zeroinitializer
  %3779 = select <8 x i1> %.splat587, <8 x i1> %3775, <8 x i1> %convergence.cascade.flow578
  %3780 = add i32 %convergence.cascade.depth579, 1
  %3781 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3779)
  %3782 = icmp ult i32 %3780, 8
  %3783 = and i1 %3781, %3782
  %3784 = and i1 %3752, %3783
  %convergence.parent.token588 = load i32, ptr %current.token, align 4
  %convergence.parent.present589 = icmp ne i32 %convergence.parent.token588, 0
  %3785 = and i1 %3784, %convergence.parent.present589
  br i1 %3785, label %convergence.cascade574, label %convergence.cascade.exit575

convergence.cascade.exit575:                      ; preds = %convergence.cascade574, %schedule.26
  %convergence.cascade.result590 = phi <8 x i1> [ %635, %schedule.26 ], [ %3779, %convergence.cascade574 ]
  %3786 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result590)
  br i1 %3786, label %convergence.target.26.ready, label %scheduler.loop

convergence.target.26.ready:                      ; preds = %convergence.cascade.exit575
  %3787 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result590)
  %3788 = bitcast <8 x i1> %convergence.cascade.result590 to i8
  %3789 = call i8 @llvm.cttz.i8(i8 %3788, i1 false)
  %3790 = zext i8 %3789 to i32
  %3791 = select i1 %3787, i32 %3790, i32 0
  %3792 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %3793 = extractvalue { <8 x ptr>, <8 x i64> } %21, 0
  %3794 = extractvalue { <8 x ptr>, <8 x i64> } %3792, 0
  %3795 = select <8 x i1> %convergence.cascade.result590, <8 x ptr> %3793, <8 x ptr> %3794
  %3796 = extractvalue { <8 x ptr>, <8 x i64> } %21, 1
  %3797 = extractvalue { <8 x ptr>, <8 x i64> } %3792, 1
  %3798 = select <8 x i1> %convergence.cascade.result590, <8 x i64> %3796, <8 x i64> %3797
  %3799 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3795, 0
  %3800 = insertvalue { <8 x ptr>, <8 x i64> } %3799, <8 x i64> %3798, 1
  store volatile { <8 x ptr>, <8 x i64> } %3800, ptr %tile_snapshot.spill79, align 64
  %3801 = load <8 x i64>, ptr %.slot80, align 64
  %3802 = select <8 x i1> %convergence.cascade.result590, <8 x i64> zeroinitializer, <8 x i64> %3801
  store <8 x i64> %3802, ptr %.slot80, align 64
  store <8 x i1> %convergence.cascade.result590, ptr %current.mask, align 1
  %3803 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result590)
  br i1 %3803, label %schedule.27, label %scheduler.loop

varying.divergent592:                             ; preds = %schedule.27
  %3804 = load i32, ptr %current.token, align 4
  %3805 = icmp ne i32 %3804, 0
  %3806 = sub i32 %3804, 1
  %3807 = select i1 %3805, i32 %3806, i32 0
  %3808 = load i8, ptr %frame.active, align 1
  %3809 = trunc i32 %3807 to i8
  %3810 = shl i8 1, %3809
  %3811 = and i8 %3808, %3810
  %3812 = icmp ne i8 %3811, 0
  %3813 = load <8 x i32>, ptr %frame.static.id, align 32
  %3814 = extractelement <8 x i32> %3813, i32 %3807
  %3815 = icmp eq i32 %3814, 10
  %3816 = and i1 %3812, %3815
  %3817 = and i1 %3805, %3816
  %3818 = xor i1 %3817, true
  %3819 = and i1 true, %3818
  %3820 = xor i8 %3808, -1
  %3821 = icmp ne i8 %3820, 0
  %3822 = xor i1 %3821, true
  %3823 = and i1 %3819, %3822
  br i1 %3823, label %convergence.overflow.trap594, label %convergence.overflow.resume595

varying.coherent593:                              ; preds = %schedule.27
  br i1 %646, label %varying.coherent.true598, label %varying.coherent.false599

convergence.overflow.trap594:                     ; preds = %varying.divergent592
  call void @llvm.trap()
  unreachable

convergence.overflow.resume595:                   ; preds = %varying.divergent592
  %3824 = call i8 @llvm.cttz.i8(i8 %3820, i1 false)
  %3825 = zext i8 %3824 to i32
  %3826 = select i1 %3821, i32 %3825, i32 0
  %3827 = trunc i32 %3826 to i8
  %3828 = shl i8 1, %3827
  %3829 = or i8 %3808, %3828
  %3830 = select i1 %3819, i8 %3829, i8 %3808
  store i8 %3830, ptr %frame.active, align 1
  %3831 = load <8 x i32>, ptr %frame.static.id, align 32
  %3832 = extractelement <8 x i32> %3831, i32 %3826
  %3833 = select i1 %3819, i32 10, i32 %3832
  %3834 = load <8 x i32>, ptr %frame.static.id, align 32
  %3835 = insertelement <8 x i32> %3834, i32 %3833, i32 %3826
  store <8 x i32> %3835, ptr %frame.static.id, align 32
  %3836 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3837 = extractelement <8 x i32> %3836, i32 %3826
  %3838 = select i1 %3819, i32 %3804, i32 %3837
  %3839 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3840 = insertelement <8 x i32> %3839, i32 %3838, i32 %3826
  store <8 x i32> %3840, ptr %frame.parent.token, align 32
  %3841 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3826
  %3842 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3826
  %3843 = load <8 x i1>, ptr %3841, align 1
  %3844 = load <8 x i1>, ptr %3842, align 1
  %3845 = select i1 %3819, <8 x i1> %636, <8 x i1> %3843
  store <8 x i1> %3845, ptr %3841, align 1
  %3846 = select i1 %3819, <8 x i1> zeroinitializer, <8 x i1> %3844
  store <8 x i1> %3846, ptr %3842, align 1
  %3847 = add i32 %3826, 1
  %3848 = select i1 %3817, i32 %3804, i32 %3847
  %3849 = select i1 true, i32 %3848, i32 %3804
  store i32 %3849, ptr %current.token, align 4
  %3850 = load i32, ptr %current.token, align 4
  %3851 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %643)
  %3852 = load i32, ptr %ready.count, align 4
  %3853 = icmp uge i32 %3852, 8
  %3854 = and i1 %3851, %3853
  br i1 %3854, label %ready.overflow.trap596, label %ready.overflow.resume597

ready.overflow.trap596:                           ; preds = %convergence.overflow.resume595
  call void @llvm.trap()
  unreachable

ready.overflow.resume597:                         ; preds = %convergence.overflow.resume595
  %3855 = select i1 %3851, i32 %3852, i32 0
  %3856 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3855
  %3857 = load <8 x i1>, ptr %3856, align 1
  %3858 = select i1 %3851, <8 x i1> %643, <8 x i1> %3857
  store <8 x i1> %3858, ptr %3856, align 1
  %3859 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3855
  %3860 = load i32, ptr %3859, align 4
  %3861 = select i1 %3851, i32 28, i32 %3860
  store i32 %3861, ptr %3859, align 4
  %3862 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3855
  %3863 = load i32, ptr %3862, align 4
  %3864 = select i1 %3851, i32 %3850, i32 %3863
  store i32 %3864, ptr %3862, align 4
  %3865 = add i32 %3852, 1
  %3866 = select i1 %3851, i32 %3865, i32 %3852
  store i32 %3866, ptr %ready.count, align 4
  %3867 = load <8 x i1>, ptr %runnable.mask, align 1
  %3868 = or <8 x i1> %3867, %643
  store <8 x i1> %3868, ptr %runnable.mask, align 1
  store <8 x i1> %645, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true598:                         ; preds = %varying.coherent593
  store <8 x i1> %636, ptr %current.mask, align 1
  %3869 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %636)
  br i1 %3869, label %schedule.28, label %scheduler.loop

varying.coherent.false599:                        ; preds = %varying.coherent593
  store <8 x i1> %636, ptr %current.mask, align 1
  %3870 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %636)
  br i1 %3870, label %schedule.29, label %scheduler.loop

convergence.cascade607:                           ; preds = %convergence.cascade607, %schedule.29
  %convergence.cascade.flow611 = phi <8 x i1> [ %698, %schedule.29 ], [ %3913, %convergence.cascade607 ]
  %convergence.cascade.depth612 = phi i32 [ 0, %schedule.29 ], [ %3914, %convergence.cascade607 ]
  %3871 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow611)
  %3872 = load i32, ptr %current.token, align 4
  %3873 = icmp ne i32 %3872, 0
  %3874 = and i1 %3871, %3873
  %3875 = sub i32 %3872, 1
  %3876 = select i1 %3874, i32 %3875, i32 0
  %3877 = load i8, ptr %frame.active, align 1
  %3878 = trunc i32 %3876 to i8
  %3879 = shl i8 1, %3878
  %3880 = and i8 %3877, %3879
  %3881 = icmp ne i8 %3880, 0
  %3882 = load <8 x i32>, ptr %frame.static.id, align 32
  %3883 = extractelement <8 x i32> %3882, i32 %3876
  %convergence.target.pointer613 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %3883
  %convergence.dynamic.target614 = load i32, ptr %convergence.target.pointer613, align 4
  %3884 = icmp eq i32 %convergence.dynamic.target614, 29
  %3885 = and i1 %3881, %3884
  %3886 = and i1 %3874, %3885
  %3887 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3876
  %3888 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3876
  %3889 = load <8 x i1>, ptr %3887, align 1
  %3890 = load <8 x i1>, ptr %3888, align 1
  %3891 = or <8 x i1> %3890, %convergence.cascade.flow611
  %3892 = load <8 x i1>, ptr %live.mask, align 1
  %3893 = and <8 x i1> %3889, %3892
  %3894 = icmp eq <8 x i1> %3891, %3893
  %3895 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3894)
  %3896 = and i1 %3886, %3895
  %3897 = select i1 %3896, <8 x i1> zeroinitializer, <8 x i1> %3891
  %3898 = select i1 %3886, <8 x i1> %3897, <8 x i1> %3890
  store <8 x i1> %3898, ptr %3888, align 1
  %3899 = select i1 %3896, <8 x i1> zeroinitializer, <8 x i1> %3889
  store <8 x i1> %3899, ptr %3887, align 1
  %3900 = trunc i32 %3876 to i8
  %3901 = shl i8 1, %3900
  %3902 = xor i8 %3901, -1
  %3903 = and i8 %3877, %3902
  %3904 = select i1 %3896, i8 %3903, i8 %3877
  store i8 %3904, ptr %frame.active, align 1
  %.splatinsert615 = insertelement <8 x i1> poison, i1 %3886, i64 0
  %.splat616 = shufflevector <8 x i1> %.splatinsert615, <8 x i1> poison, <8 x i32> zeroinitializer
  %3905 = and <8 x i1> %convergence.cascade.flow611, %.splat616
  %3906 = load <8 x i1>, ptr %runnable.mask, align 1
  %3907 = xor <8 x i1> %3905, splat (i1 true)
  %3908 = and <8 x i1> %3906, %3907
  store <8 x i1> %3908, ptr %runnable.mask, align 1
  %.splatinsert617 = insertelement <8 x i1> poison, i1 %3896, i64 0
  %.splat618 = shufflevector <8 x i1> %.splatinsert617, <8 x i1> poison, <8 x i32> zeroinitializer
  %3909 = select <8 x i1> %.splat618, <8 x i1> %3891, <8 x i1> zeroinitializer
  %3910 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3911 = extractelement <8 x i32> %3910, i32 %3876
  %3912 = select i1 %3896, i32 %3911, i32 %3872
  store i32 %3912, ptr %current.token, align 4
  %.splatinsert619 = insertelement <8 x i1> poison, i1 %3886, i64 0
  %.splat620 = shufflevector <8 x i1> %.splatinsert619, <8 x i1> poison, <8 x i32> zeroinitializer
  %3913 = select <8 x i1> %.splat620, <8 x i1> %3909, <8 x i1> %convergence.cascade.flow611
  %3914 = add i32 %convergence.cascade.depth612, 1
  %3915 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3913)
  %3916 = icmp ult i32 %3914, 8
  %3917 = and i1 %3915, %3916
  %3918 = and i1 %3886, %3917
  %convergence.parent.token621 = load i32, ptr %current.token, align 4
  %convergence.parent.present622 = icmp ne i32 %convergence.parent.token621, 0
  %3919 = and i1 %3918, %convergence.parent.present622
  br i1 %3919, label %convergence.cascade607, label %convergence.cascade.exit608

convergence.cascade.exit608:                      ; preds = %convergence.cascade607, %schedule.29
  %convergence.cascade.result623 = phi <8 x i1> [ %698, %schedule.29 ], [ %3913, %convergence.cascade607 ]
  %3920 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  br i1 %3920, label %convergence.target.29.ready, label %scheduler.loop

convergence.target.29.ready:                      ; preds = %convergence.cascade.exit608
  %3921 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %3922 = bitcast <8 x i1> %convergence.cascade.result623 to i8
  %3923 = call i8 @llvm.cttz.i8(i8 %3922, i1 false)
  %3924 = zext i8 %3923 to i32
  %3925 = select i1 %3921, i32 %3924, i32 0
  %3926 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill81, align 64
  %3927 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3928 = extractvalue { <8 x ptr>, <8 x i64> } %3926, 0
  %3929 = select <8 x i1> %convergence.cascade.result623, <8 x ptr> %3927, <8 x ptr> %3928
  %3930 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3931 = extractvalue { <8 x ptr>, <8 x i64> } %3926, 1
  %3932 = select <8 x i1> %convergence.cascade.result623, <8 x i64> %3930, <8 x i64> %3931
  %3933 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3929, 0
  %3934 = insertvalue { <8 x ptr>, <8 x i64> } %3933, <8 x i64> %3932, 1
  store volatile { <8 x ptr>, <8 x i64> } %3934, ptr %tile_snapshot.spill81, align 64
  %3935 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3936 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3937 = add <8 x i64> %3936, zeroinitializer
  %3938 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3935, 0
  %3939 = insertvalue { <8 x ptr>, <8 x i64> } %3938, <8 x i64> %3937, 1
  %3940 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3941 = extractvalue { <8 x ptr>, <8 x i64> } %3939, 1
  %3942 = extractelement <8 x ptr> %3940, i32 0
  %3943 = extractelement <8 x i64> %3941, i32 %3925
  %3944 = zext i32 %3925 to i64
  %3945 = mul i64 %3944, 8
  %3946 = sub i64 %3943, %3945
  %3947 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %3948 = select i1 %3947, i64 %3946, i64 0
  %private.contiguous.address624 = getelementptr i8, ptr %3942, i64 %3948
  %private.contiguous.preserve625 = load <8 x i64>, ptr %private.contiguous.address624, align 8
  %3949 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 -8), <8 x i64> %private.contiguous.preserve625
  store <8 x i64> %3949, ptr %private.contiguous.address624, align 8
  %3950 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3951 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3952 = add <8 x i64> %3951, splat (i64 64)
  %3953 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3950, 0
  %3954 = insertvalue { <8 x ptr>, <8 x i64> } %3953, <8 x i64> %3952, 1
  %3955 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3956 = extractvalue { <8 x ptr>, <8 x i64> } %3954, 1
  %3957 = extractelement <8 x ptr> %3955, i32 0
  %3958 = extractelement <8 x i64> %3956, i32 %3925
  %3959 = zext i32 %3925 to i64
  %3960 = mul i64 %3959, 8
  %3961 = sub i64 %3958, %3960
  %3962 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %3963 = select i1 %3962, i64 %3961, i64 0
  %private.contiguous.address626 = getelementptr i8, ptr %3957, i64 %3963
  %private.contiguous.preserve627 = load <8 x i64>, ptr %private.contiguous.address626, align 8
  %3964 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 -7), <8 x i64> %private.contiguous.preserve627
  store <8 x i64> %3964, ptr %private.contiguous.address626, align 8
  %3965 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3966 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3967 = add <8 x i64> %3966, splat (i64 128)
  %3968 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3965, 0
  %3969 = insertvalue { <8 x ptr>, <8 x i64> } %3968, <8 x i64> %3967, 1
  %3970 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3971 = extractvalue { <8 x ptr>, <8 x i64> } %3969, 1
  %3972 = extractelement <8 x ptr> %3970, i32 0
  %3973 = extractelement <8 x i64> %3971, i32 %3925
  %3974 = zext i32 %3925 to i64
  %3975 = mul i64 %3974, 8
  %3976 = sub i64 %3973, %3975
  %3977 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %3978 = select i1 %3977, i64 %3976, i64 0
  %private.contiguous.address628 = getelementptr i8, ptr %3972, i64 %3978
  %private.contiguous.preserve629 = load <8 x i64>, ptr %private.contiguous.address628, align 8
  %3979 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 -6), <8 x i64> %private.contiguous.preserve629
  store <8 x i64> %3979, ptr %private.contiguous.address628, align 8
  %3980 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3981 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3982 = add <8 x i64> %3981, splat (i64 192)
  %3983 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3980, 0
  %3984 = insertvalue { <8 x ptr>, <8 x i64> } %3983, <8 x i64> %3982, 1
  %3985 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3986 = extractvalue { <8 x ptr>, <8 x i64> } %3984, 1
  %3987 = extractelement <8 x ptr> %3985, i32 0
  %3988 = extractelement <8 x i64> %3986, i32 %3925
  %3989 = zext i32 %3925 to i64
  %3990 = mul i64 %3989, 8
  %3991 = sub i64 %3988, %3990
  %3992 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %3993 = select i1 %3992, i64 %3991, i64 0
  %private.contiguous.address630 = getelementptr i8, ptr %3987, i64 %3993
  %private.contiguous.preserve631 = load <8 x i64>, ptr %private.contiguous.address630, align 8
  %3994 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 -5), <8 x i64> %private.contiguous.preserve631
  store <8 x i64> %3994, ptr %private.contiguous.address630, align 8
  %3995 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3996 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3997 = add <8 x i64> %3996, splat (i64 256)
  %3998 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3995, 0
  %3999 = insertvalue { <8 x ptr>, <8 x i64> } %3998, <8 x i64> %3997, 1
  %4000 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4001 = extractvalue { <8 x ptr>, <8 x i64> } %3999, 1
  %4002 = extractelement <8 x ptr> %4000, i32 0
  %4003 = extractelement <8 x i64> %4001, i32 %3925
  %4004 = zext i32 %3925 to i64
  %4005 = mul i64 %4004, 8
  %4006 = sub i64 %4003, %4005
  %4007 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %4008 = select i1 %4007, i64 %4006, i64 0
  %private.contiguous.address632 = getelementptr i8, ptr %4002, i64 %4008
  %private.contiguous.preserve633 = load <8 x i64>, ptr %private.contiguous.address632, align 8
  %4009 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 -4), <8 x i64> %private.contiguous.preserve633
  store <8 x i64> %4009, ptr %private.contiguous.address632, align 8
  %4010 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4011 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4012 = add <8 x i64> %4011, splat (i64 320)
  %4013 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4010, 0
  %4014 = insertvalue { <8 x ptr>, <8 x i64> } %4013, <8 x i64> %4012, 1
  %4015 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4016 = extractvalue { <8 x ptr>, <8 x i64> } %4014, 1
  %4017 = extractelement <8 x ptr> %4015, i32 0
  %4018 = extractelement <8 x i64> %4016, i32 %3925
  %4019 = zext i32 %3925 to i64
  %4020 = mul i64 %4019, 8
  %4021 = sub i64 %4018, %4020
  %4022 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %4023 = select i1 %4022, i64 %4021, i64 0
  %private.contiguous.address634 = getelementptr i8, ptr %4017, i64 %4023
  %private.contiguous.preserve635 = load <8 x i64>, ptr %private.contiguous.address634, align 8
  %4024 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 -3), <8 x i64> %private.contiguous.preserve635
  store <8 x i64> %4024, ptr %private.contiguous.address634, align 8
  %4025 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4026 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4027 = add <8 x i64> %4026, splat (i64 384)
  %4028 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4025, 0
  %4029 = insertvalue { <8 x ptr>, <8 x i64> } %4028, <8 x i64> %4027, 1
  %4030 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4031 = extractvalue { <8 x ptr>, <8 x i64> } %4029, 1
  %4032 = extractelement <8 x ptr> %4030, i32 0
  %4033 = extractelement <8 x i64> %4031, i32 %3925
  %4034 = zext i32 %3925 to i64
  %4035 = mul i64 %4034, 8
  %4036 = sub i64 %4033, %4035
  %4037 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %4038 = select i1 %4037, i64 %4036, i64 0
  %private.contiguous.address636 = getelementptr i8, ptr %4032, i64 %4038
  %private.contiguous.preserve637 = load <8 x i64>, ptr %private.contiguous.address636, align 8
  %4039 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 -2), <8 x i64> %private.contiguous.preserve637
  store <8 x i64> %4039, ptr %private.contiguous.address636, align 8
  %4040 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4041 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4042 = add <8 x i64> %4041, splat (i64 448)
  %4043 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4040, 0
  %4044 = insertvalue { <8 x ptr>, <8 x i64> } %4043, <8 x i64> %4042, 1
  %4045 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4046 = extractvalue { <8 x ptr>, <8 x i64> } %4044, 1
  %4047 = extractelement <8 x ptr> %4045, i32 0
  %4048 = extractelement <8 x i64> %4046, i32 %3925
  %4049 = zext i32 %3925 to i64
  %4050 = mul i64 %4049, 8
  %4051 = sub i64 %4048, %4050
  %4052 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %4053 = select i1 %4052, i64 %4051, i64 0
  %private.contiguous.address638 = getelementptr i8, ptr %4047, i64 %4053
  %private.contiguous.preserve639 = load <8 x i64>, ptr %private.contiguous.address638, align 8
  %4054 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 -1), <8 x i64> %private.contiguous.preserve639
  store <8 x i64> %4054, ptr %private.contiguous.address638, align 8
  %4055 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4056 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4057 = add <8 x i64> %4056, splat (i64 512)
  %4058 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4055, 0
  %4059 = insertvalue { <8 x ptr>, <8 x i64> } %4058, <8 x i64> %4057, 1
  %4060 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4061 = extractvalue { <8 x ptr>, <8 x i64> } %4059, 1
  %4062 = extractelement <8 x ptr> %4060, i32 0
  %4063 = extractelement <8 x i64> %4061, i32 %3925
  %4064 = zext i32 %3925 to i64
  %4065 = mul i64 %4064, 8
  %4066 = sub i64 %4063, %4065
  %4067 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %4068 = select i1 %4067, i64 %4066, i64 0
  %private.contiguous.address640 = getelementptr i8, ptr %4062, i64 %4068
  %private.contiguous.preserve641 = load <8 x i64>, ptr %private.contiguous.address640, align 8
  %4069 = select <8 x i1> %convergence.cascade.result623, <8 x i64> zeroinitializer, <8 x i64> %private.contiguous.preserve641
  store <8 x i64> %4069, ptr %private.contiguous.address640, align 8
  %4070 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4071 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4072 = add <8 x i64> %4071, splat (i64 576)
  %4073 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4070, 0
  %4074 = insertvalue { <8 x ptr>, <8 x i64> } %4073, <8 x i64> %4072, 1
  %4075 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4076 = extractvalue { <8 x ptr>, <8 x i64> } %4074, 1
  %4077 = extractelement <8 x ptr> %4075, i32 0
  %4078 = extractelement <8 x i64> %4076, i32 %3925
  %4079 = zext i32 %3925 to i64
  %4080 = mul i64 %4079, 8
  %4081 = sub i64 %4078, %4080
  %4082 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %4083 = select i1 %4082, i64 %4081, i64 0
  %private.contiguous.address642 = getelementptr i8, ptr %4077, i64 %4083
  %private.contiguous.preserve643 = load <8 x i64>, ptr %private.contiguous.address642, align 8
  %4084 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 1), <8 x i64> %private.contiguous.preserve643
  store <8 x i64> %4084, ptr %private.contiguous.address642, align 8
  %4085 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4086 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4087 = add <8 x i64> %4086, splat (i64 640)
  %4088 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4085, 0
  %4089 = insertvalue { <8 x ptr>, <8 x i64> } %4088, <8 x i64> %4087, 1
  %4090 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4091 = extractvalue { <8 x ptr>, <8 x i64> } %4089, 1
  %4092 = extractelement <8 x ptr> %4090, i32 0
  %4093 = extractelement <8 x i64> %4091, i32 %3925
  %4094 = zext i32 %3925 to i64
  %4095 = mul i64 %4094, 8
  %4096 = sub i64 %4093, %4095
  %4097 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %4098 = select i1 %4097, i64 %4096, i64 0
  %private.contiguous.address644 = getelementptr i8, ptr %4092, i64 %4098
  %private.contiguous.preserve645 = load <8 x i64>, ptr %private.contiguous.address644, align 8
  %4099 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 2), <8 x i64> %private.contiguous.preserve645
  store <8 x i64> %4099, ptr %private.contiguous.address644, align 8
  %4100 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4101 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4102 = add <8 x i64> %4101, splat (i64 704)
  %4103 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4100, 0
  %4104 = insertvalue { <8 x ptr>, <8 x i64> } %4103, <8 x i64> %4102, 1
  %4105 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4106 = extractvalue { <8 x ptr>, <8 x i64> } %4104, 1
  %4107 = extractelement <8 x ptr> %4105, i32 0
  %4108 = extractelement <8 x i64> %4106, i32 %3925
  %4109 = zext i32 %3925 to i64
  %4110 = mul i64 %4109, 8
  %4111 = sub i64 %4108, %4110
  %4112 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %4113 = select i1 %4112, i64 %4111, i64 0
  %private.contiguous.address646 = getelementptr i8, ptr %4107, i64 %4113
  %private.contiguous.preserve647 = load <8 x i64>, ptr %private.contiguous.address646, align 8
  %4114 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 3), <8 x i64> %private.contiguous.preserve647
  store <8 x i64> %4114, ptr %private.contiguous.address646, align 8
  %4115 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4116 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4117 = add <8 x i64> %4116, splat (i64 768)
  %4118 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4115, 0
  %4119 = insertvalue { <8 x ptr>, <8 x i64> } %4118, <8 x i64> %4117, 1
  %4120 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4121 = extractvalue { <8 x ptr>, <8 x i64> } %4119, 1
  %4122 = extractelement <8 x ptr> %4120, i32 0
  %4123 = extractelement <8 x i64> %4121, i32 %3925
  %4124 = zext i32 %3925 to i64
  %4125 = mul i64 %4124, 8
  %4126 = sub i64 %4123, %4125
  %4127 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %4128 = select i1 %4127, i64 %4126, i64 0
  %private.contiguous.address648 = getelementptr i8, ptr %4122, i64 %4128
  %private.contiguous.preserve649 = load <8 x i64>, ptr %private.contiguous.address648, align 8
  %4129 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 4), <8 x i64> %private.contiguous.preserve649
  store <8 x i64> %4129, ptr %private.contiguous.address648, align 8
  %4130 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4131 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4132 = add <8 x i64> %4131, splat (i64 832)
  %4133 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4130, 0
  %4134 = insertvalue { <8 x ptr>, <8 x i64> } %4133, <8 x i64> %4132, 1
  %4135 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4136 = extractvalue { <8 x ptr>, <8 x i64> } %4134, 1
  %4137 = extractelement <8 x ptr> %4135, i32 0
  %4138 = extractelement <8 x i64> %4136, i32 %3925
  %4139 = zext i32 %3925 to i64
  %4140 = mul i64 %4139, 8
  %4141 = sub i64 %4138, %4140
  %4142 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %4143 = select i1 %4142, i64 %4141, i64 0
  %private.contiguous.address650 = getelementptr i8, ptr %4137, i64 %4143
  %private.contiguous.preserve651 = load <8 x i64>, ptr %private.contiguous.address650, align 8
  %4144 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 5), <8 x i64> %private.contiguous.preserve651
  store <8 x i64> %4144, ptr %private.contiguous.address650, align 8
  %4145 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4146 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4147 = add <8 x i64> %4146, splat (i64 896)
  %4148 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4145, 0
  %4149 = insertvalue { <8 x ptr>, <8 x i64> } %4148, <8 x i64> %4147, 1
  %4150 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4151 = extractvalue { <8 x ptr>, <8 x i64> } %4149, 1
  %4152 = extractelement <8 x ptr> %4150, i32 0
  %4153 = extractelement <8 x i64> %4151, i32 %3925
  %4154 = zext i32 %3925 to i64
  %4155 = mul i64 %4154, 8
  %4156 = sub i64 %4153, %4155
  %4157 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %4158 = select i1 %4157, i64 %4156, i64 0
  %private.contiguous.address652 = getelementptr i8, ptr %4152, i64 %4158
  %private.contiguous.preserve653 = load <8 x i64>, ptr %private.contiguous.address652, align 8
  %4159 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 6), <8 x i64> %private.contiguous.preserve653
  store <8 x i64> %4159, ptr %private.contiguous.address652, align 8
  %4160 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4161 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4162 = add <8 x i64> %4161, splat (i64 960)
  %4163 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4160, 0
  %4164 = insertvalue { <8 x ptr>, <8 x i64> } %4163, <8 x i64> %4162, 1
  %4165 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4166 = extractvalue { <8 x ptr>, <8 x i64> } %4164, 1
  %4167 = extractelement <8 x ptr> %4165, i32 0
  %4168 = extractelement <8 x i64> %4166, i32 %3925
  %4169 = zext i32 %3925 to i64
  %4170 = mul i64 %4169, 8
  %4171 = sub i64 %4168, %4170
  %4172 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %4173 = select i1 %4172, i64 %4171, i64 0
  %private.contiguous.address654 = getelementptr i8, ptr %4167, i64 %4173
  %private.contiguous.preserve655 = load <8 x i64>, ptr %private.contiguous.address654, align 8
  %4174 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 7), <8 x i64> %private.contiguous.preserve655
  store <8 x i64> %4174, ptr %private.contiguous.address654, align 8
  %4175 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4176 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4177 = add <8 x i64> %4176, splat (i64 1024)
  %4178 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4175, 0
  %4179 = insertvalue { <8 x ptr>, <8 x i64> } %4178, <8 x i64> %4177, 1
  %4180 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4181 = extractvalue { <8 x ptr>, <8 x i64> } %4179, 1
  %4182 = extractelement <8 x ptr> %4180, i32 0
  %4183 = extractelement <8 x i64> %4181, i32 %3925
  %4184 = zext i32 %3925 to i64
  %4185 = mul i64 %4184, 8
  %4186 = sub i64 %4183, %4185
  %4187 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %4188 = select i1 %4187, i64 %4186, i64 0
  %private.contiguous.address656 = getelementptr i8, ptr %4182, i64 %4188
  %private.contiguous.preserve657 = load <8 x i64>, ptr %private.contiguous.address656, align 8
  %4189 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 8), <8 x i64> %private.contiguous.preserve657
  store <8 x i64> %4189, ptr %private.contiguous.address656, align 8
  %4190 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4191 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4192 = add <8 x i64> %4191, splat (i64 1088)
  %4193 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4190, 0
  %4194 = insertvalue { <8 x ptr>, <8 x i64> } %4193, <8 x i64> %4192, 1
  %4195 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4196 = extractvalue { <8 x ptr>, <8 x i64> } %4194, 1
  %4197 = extractelement <8 x ptr> %4195, i32 0
  %4198 = extractelement <8 x i64> %4196, i32 %3925
  %4199 = zext i32 %3925 to i64
  %4200 = mul i64 %4199, 8
  %4201 = sub i64 %4198, %4200
  %4202 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %4203 = select i1 %4202, i64 %4201, i64 0
  %private.contiguous.address658 = getelementptr i8, ptr %4197, i64 %4203
  %private.contiguous.preserve659 = load <8 x i64>, ptr %private.contiguous.address658, align 8
  %4204 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 9), <8 x i64> %private.contiguous.preserve659
  store <8 x i64> %4204, ptr %private.contiguous.address658, align 8
  %4205 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4206 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4207 = add <8 x i64> %4206, splat (i64 1152)
  %4208 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4205, 0
  %4209 = insertvalue { <8 x ptr>, <8 x i64> } %4208, <8 x i64> %4207, 1
  %4210 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4211 = extractvalue { <8 x ptr>, <8 x i64> } %4209, 1
  %4212 = extractelement <8 x ptr> %4210, i32 0
  %4213 = extractelement <8 x i64> %4211, i32 %3925
  %4214 = zext i32 %3925 to i64
  %4215 = mul i64 %4214, 8
  %4216 = sub i64 %4213, %4215
  %4217 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %4218 = select i1 %4217, i64 %4216, i64 0
  %private.contiguous.address660 = getelementptr i8, ptr %4212, i64 %4218
  %private.contiguous.preserve661 = load <8 x i64>, ptr %private.contiguous.address660, align 8
  %4219 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 10), <8 x i64> %private.contiguous.preserve661
  store <8 x i64> %4219, ptr %private.contiguous.address660, align 8
  %4220 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4221 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4222 = add <8 x i64> %4221, splat (i64 1216)
  %4223 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4220, 0
  %4224 = insertvalue { <8 x ptr>, <8 x i64> } %4223, <8 x i64> %4222, 1
  %4225 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4226 = extractvalue { <8 x ptr>, <8 x i64> } %4224, 1
  %4227 = extractelement <8 x ptr> %4225, i32 0
  %4228 = extractelement <8 x i64> %4226, i32 %3925
  %4229 = zext i32 %3925 to i64
  %4230 = mul i64 %4229, 8
  %4231 = sub i64 %4228, %4230
  %4232 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %4233 = select i1 %4232, i64 %4231, i64 0
  %private.contiguous.address662 = getelementptr i8, ptr %4227, i64 %4233
  %private.contiguous.preserve663 = load <8 x i64>, ptr %private.contiguous.address662, align 8
  %4234 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 11), <8 x i64> %private.contiguous.preserve663
  store <8 x i64> %4234, ptr %private.contiguous.address662, align 8
  %4235 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4236 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4237 = add <8 x i64> %4236, splat (i64 1280)
  %4238 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4235, 0
  %4239 = insertvalue { <8 x ptr>, <8 x i64> } %4238, <8 x i64> %4237, 1
  %4240 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4241 = extractvalue { <8 x ptr>, <8 x i64> } %4239, 1
  %4242 = extractelement <8 x ptr> %4240, i32 0
  %4243 = extractelement <8 x i64> %4241, i32 %3925
  %4244 = zext i32 %3925 to i64
  %4245 = mul i64 %4244, 8
  %4246 = sub i64 %4243, %4245
  %4247 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %4248 = select i1 %4247, i64 %4246, i64 0
  %private.contiguous.address664 = getelementptr i8, ptr %4242, i64 %4248
  %private.contiguous.preserve665 = load <8 x i64>, ptr %private.contiguous.address664, align 8
  %4249 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 12), <8 x i64> %private.contiguous.preserve665
  store <8 x i64> %4249, ptr %private.contiguous.address664, align 8
  %4250 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4251 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4252 = add <8 x i64> %4251, splat (i64 1344)
  %4253 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4250, 0
  %4254 = insertvalue { <8 x ptr>, <8 x i64> } %4253, <8 x i64> %4252, 1
  %4255 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4256 = extractvalue { <8 x ptr>, <8 x i64> } %4254, 1
  %4257 = extractelement <8 x ptr> %4255, i32 0
  %4258 = extractelement <8 x i64> %4256, i32 %3925
  %4259 = zext i32 %3925 to i64
  %4260 = mul i64 %4259, 8
  %4261 = sub i64 %4258, %4260
  %4262 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %4263 = select i1 %4262, i64 %4261, i64 0
  %private.contiguous.address666 = getelementptr i8, ptr %4257, i64 %4263
  %private.contiguous.preserve667 = load <8 x i64>, ptr %private.contiguous.address666, align 8
  %4264 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 13), <8 x i64> %private.contiguous.preserve667
  store <8 x i64> %4264, ptr %private.contiguous.address666, align 8
  %4265 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4266 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4267 = add <8 x i64> %4266, splat (i64 1408)
  %4268 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4265, 0
  %4269 = insertvalue { <8 x ptr>, <8 x i64> } %4268, <8 x i64> %4267, 1
  %4270 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4271 = extractvalue { <8 x ptr>, <8 x i64> } %4269, 1
  %4272 = extractelement <8 x ptr> %4270, i32 0
  %4273 = extractelement <8 x i64> %4271, i32 %3925
  %4274 = zext i32 %3925 to i64
  %4275 = mul i64 %4274, 8
  %4276 = sub i64 %4273, %4275
  %4277 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %4278 = select i1 %4277, i64 %4276, i64 0
  %private.contiguous.address668 = getelementptr i8, ptr %4272, i64 %4278
  %private.contiguous.preserve669 = load <8 x i64>, ptr %private.contiguous.address668, align 8
  %4279 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 14), <8 x i64> %private.contiguous.preserve669
  store <8 x i64> %4279, ptr %private.contiguous.address668, align 8
  %4280 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4281 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4282 = add <8 x i64> %4281, splat (i64 1472)
  %4283 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4280, 0
  %4284 = insertvalue { <8 x ptr>, <8 x i64> } %4283, <8 x i64> %4282, 1
  %4285 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4286 = extractvalue { <8 x ptr>, <8 x i64> } %4284, 1
  %4287 = extractelement <8 x ptr> %4285, i32 0
  %4288 = extractelement <8 x i64> %4286, i32 %3925
  %4289 = zext i32 %3925 to i64
  %4290 = mul i64 %4289, 8
  %4291 = sub i64 %4288, %4290
  %4292 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %4293 = select i1 %4292, i64 %4291, i64 0
  %private.contiguous.address670 = getelementptr i8, ptr %4287, i64 %4293
  %private.contiguous.preserve671 = load <8 x i64>, ptr %private.contiguous.address670, align 8
  %4294 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 15), <8 x i64> %private.contiguous.preserve671
  store <8 x i64> %4294, ptr %private.contiguous.address670, align 8
  %4295 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4296 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4297 = add <8 x i64> %4296, splat (i64 1536)
  %4298 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4295, 0
  %4299 = insertvalue { <8 x ptr>, <8 x i64> } %4298, <8 x i64> %4297, 1
  %4300 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4301 = extractvalue { <8 x ptr>, <8 x i64> } %4299, 1
  %4302 = extractelement <8 x ptr> %4300, i32 0
  %4303 = extractelement <8 x i64> %4301, i32 %3925
  %4304 = zext i32 %3925 to i64
  %4305 = mul i64 %4304, 8
  %4306 = sub i64 %4303, %4305
  %4307 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %4308 = select i1 %4307, i64 %4306, i64 0
  %private.contiguous.address672 = getelementptr i8, ptr %4302, i64 %4308
  %private.contiguous.preserve673 = load <8 x i64>, ptr %private.contiguous.address672, align 8
  %4309 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 16), <8 x i64> %private.contiguous.preserve673
  store <8 x i64> %4309, ptr %private.contiguous.address672, align 8
  %4310 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4311 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4312 = add <8 x i64> %4311, splat (i64 1600)
  %4313 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4310, 0
  %4314 = insertvalue { <8 x ptr>, <8 x i64> } %4313, <8 x i64> %4312, 1
  %4315 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4316 = extractvalue { <8 x ptr>, <8 x i64> } %4314, 1
  %4317 = extractelement <8 x ptr> %4315, i32 0
  %4318 = extractelement <8 x i64> %4316, i32 %3925
  %4319 = zext i32 %3925 to i64
  %4320 = mul i64 %4319, 8
  %4321 = sub i64 %4318, %4320
  %4322 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %4323 = select i1 %4322, i64 %4321, i64 0
  %private.contiguous.address674 = getelementptr i8, ptr %4317, i64 %4323
  %private.contiguous.preserve675 = load <8 x i64>, ptr %private.contiguous.address674, align 8
  %4324 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 17), <8 x i64> %private.contiguous.preserve675
  store <8 x i64> %4324, ptr %private.contiguous.address674, align 8
  %4325 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4326 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4327 = add <8 x i64> %4326, splat (i64 1664)
  %4328 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4325, 0
  %4329 = insertvalue { <8 x ptr>, <8 x i64> } %4328, <8 x i64> %4327, 1
  %4330 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4331 = extractvalue { <8 x ptr>, <8 x i64> } %4329, 1
  %4332 = extractelement <8 x ptr> %4330, i32 0
  %4333 = extractelement <8 x i64> %4331, i32 %3925
  %4334 = zext i32 %3925 to i64
  %4335 = mul i64 %4334, 8
  %4336 = sub i64 %4333, %4335
  %4337 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %4338 = select i1 %4337, i64 %4336, i64 0
  %private.contiguous.address676 = getelementptr i8, ptr %4332, i64 %4338
  %private.contiguous.preserve677 = load <8 x i64>, ptr %private.contiguous.address676, align 8
  %4339 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 18), <8 x i64> %private.contiguous.preserve677
  store <8 x i64> %4339, ptr %private.contiguous.address676, align 8
  %4340 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4341 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4342 = add <8 x i64> %4341, splat (i64 1728)
  %4343 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4340, 0
  %4344 = insertvalue { <8 x ptr>, <8 x i64> } %4343, <8 x i64> %4342, 1
  %4345 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4346 = extractvalue { <8 x ptr>, <8 x i64> } %4344, 1
  %4347 = extractelement <8 x ptr> %4345, i32 0
  %4348 = extractelement <8 x i64> %4346, i32 %3925
  %4349 = zext i32 %3925 to i64
  %4350 = mul i64 %4349, 8
  %4351 = sub i64 %4348, %4350
  %4352 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %4353 = select i1 %4352, i64 %4351, i64 0
  %private.contiguous.address678 = getelementptr i8, ptr %4347, i64 %4353
  %private.contiguous.preserve679 = load <8 x i64>, ptr %private.contiguous.address678, align 8
  %4354 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 19), <8 x i64> %private.contiguous.preserve679
  store <8 x i64> %4354, ptr %private.contiguous.address678, align 8
  %4355 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4356 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4357 = add <8 x i64> %4356, splat (i64 1792)
  %4358 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4355, 0
  %4359 = insertvalue { <8 x ptr>, <8 x i64> } %4358, <8 x i64> %4357, 1
  %4360 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4361 = extractvalue { <8 x ptr>, <8 x i64> } %4359, 1
  %4362 = extractelement <8 x ptr> %4360, i32 0
  %4363 = extractelement <8 x i64> %4361, i32 %3925
  %4364 = zext i32 %3925 to i64
  %4365 = mul i64 %4364, 8
  %4366 = sub i64 %4363, %4365
  %4367 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %4368 = select i1 %4367, i64 %4366, i64 0
  %private.contiguous.address680 = getelementptr i8, ptr %4362, i64 %4368
  %private.contiguous.preserve681 = load <8 x i64>, ptr %private.contiguous.address680, align 8
  %4369 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 20), <8 x i64> %private.contiguous.preserve681
  store <8 x i64> %4369, ptr %private.contiguous.address680, align 8
  %4370 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4371 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4372 = add <8 x i64> %4371, splat (i64 1856)
  %4373 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4370, 0
  %4374 = insertvalue { <8 x ptr>, <8 x i64> } %4373, <8 x i64> %4372, 1
  %4375 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4376 = extractvalue { <8 x ptr>, <8 x i64> } %4374, 1
  %4377 = extractelement <8 x ptr> %4375, i32 0
  %4378 = extractelement <8 x i64> %4376, i32 %3925
  %4379 = zext i32 %3925 to i64
  %4380 = mul i64 %4379, 8
  %4381 = sub i64 %4378, %4380
  %4382 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %4383 = select i1 %4382, i64 %4381, i64 0
  %private.contiguous.address682 = getelementptr i8, ptr %4377, i64 %4383
  %private.contiguous.preserve683 = load <8 x i64>, ptr %private.contiguous.address682, align 8
  %4384 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 21), <8 x i64> %private.contiguous.preserve683
  store <8 x i64> %4384, ptr %private.contiguous.address682, align 8
  %4385 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4386 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4387 = add <8 x i64> %4386, splat (i64 1920)
  %4388 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4385, 0
  %4389 = insertvalue { <8 x ptr>, <8 x i64> } %4388, <8 x i64> %4387, 1
  %4390 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4391 = extractvalue { <8 x ptr>, <8 x i64> } %4389, 1
  %4392 = extractelement <8 x ptr> %4390, i32 0
  %4393 = extractelement <8 x i64> %4391, i32 %3925
  %4394 = zext i32 %3925 to i64
  %4395 = mul i64 %4394, 8
  %4396 = sub i64 %4393, %4395
  %4397 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %4398 = select i1 %4397, i64 %4396, i64 0
  %private.contiguous.address684 = getelementptr i8, ptr %4392, i64 %4398
  %private.contiguous.preserve685 = load <8 x i64>, ptr %private.contiguous.address684, align 8
  %4399 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 22), <8 x i64> %private.contiguous.preserve685
  store <8 x i64> %4399, ptr %private.contiguous.address684, align 8
  %4400 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4401 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4402 = add <8 x i64> %4401, splat (i64 1984)
  %4403 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4400, 0
  %4404 = insertvalue { <8 x ptr>, <8 x i64> } %4403, <8 x i64> %4402, 1
  %4405 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4406 = extractvalue { <8 x ptr>, <8 x i64> } %4404, 1
  %4407 = extractelement <8 x ptr> %4405, i32 0
  %4408 = extractelement <8 x i64> %4406, i32 %3925
  %4409 = zext i32 %3925 to i64
  %4410 = mul i64 %4409, 8
  %4411 = sub i64 %4408, %4410
  %4412 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  %4413 = select i1 %4412, i64 %4411, i64 0
  %private.contiguous.address686 = getelementptr i8, ptr %4407, i64 %4413
  %private.contiguous.preserve687 = load <8 x i64>, ptr %private.contiguous.address686, align 8
  %4414 = select <8 x i1> %convergence.cascade.result623, <8 x i64> splat (i64 23), <8 x i64> %private.contiguous.preserve687
  store <8 x i64> %4414, ptr %private.contiguous.address686, align 8
  %4415 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill82, align 64
  %4416 = extractvalue { <8 x ptr>, <8 x i64> } %25, 0
  %4417 = extractvalue { <8 x ptr>, <8 x i64> } %4415, 0
  %4418 = select <8 x i1> %convergence.cascade.result623, <8 x ptr> %4416, <8 x ptr> %4417
  %4419 = extractvalue { <8 x ptr>, <8 x i64> } %25, 1
  %4420 = extractvalue { <8 x ptr>, <8 x i64> } %4415, 1
  %4421 = select <8 x i1> %convergence.cascade.result623, <8 x i64> %4419, <8 x i64> %4420
  %4422 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4418, 0
  %4423 = insertvalue { <8 x ptr>, <8 x i64> } %4422, <8 x i64> %4421, 1
  store volatile { <8 x ptr>, <8 x i64> } %4423, ptr %tile_snapshot.spill82, align 64
  %4424 = load <8 x i64>, ptr %.slot83, align 64
  %4425 = select <8 x i1> %convergence.cascade.result623, <8 x i64> zeroinitializer, <8 x i64> %4424
  store <8 x i64> %4425, ptr %.slot83, align 64
  store <8 x i1> %convergence.cascade.result623, ptr %current.mask, align 1
  %4426 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result623)
  br i1 %4426, label %schedule.30, label %scheduler.loop

varying.divergent689:                             ; preds = %schedule.30
  %4427 = load i32, ptr %current.token, align 4
  %4428 = icmp ne i32 %4427, 0
  %4429 = sub i32 %4427, 1
  %4430 = select i1 %4428, i32 %4429, i32 0
  %4431 = load i8, ptr %frame.active, align 1
  %4432 = trunc i32 %4430 to i8
  %4433 = shl i8 1, %4432
  %4434 = and i8 %4431, %4433
  %4435 = icmp ne i8 %4434, 0
  %4436 = load <8 x i32>, ptr %frame.static.id, align 32
  %4437 = extractelement <8 x i32> %4436, i32 %4430
  %4438 = icmp eq i32 %4437, 11
  %4439 = and i1 %4435, %4438
  %4440 = and i1 %4428, %4439
  %4441 = xor i1 %4440, true
  %4442 = and i1 true, %4441
  %4443 = xor i8 %4431, -1
  %4444 = icmp ne i8 %4443, 0
  %4445 = xor i1 %4444, true
  %4446 = and i1 %4442, %4445
  br i1 %4446, label %convergence.overflow.trap691, label %convergence.overflow.resume692

varying.coherent690:                              ; preds = %schedule.30
  br i1 %709, label %varying.coherent.true695, label %varying.coherent.false696

convergence.overflow.trap691:                     ; preds = %varying.divergent689
  call void @llvm.trap()
  unreachable

convergence.overflow.resume692:                   ; preds = %varying.divergent689
  %4447 = call i8 @llvm.cttz.i8(i8 %4443, i1 false)
  %4448 = zext i8 %4447 to i32
  %4449 = select i1 %4444, i32 %4448, i32 0
  %4450 = trunc i32 %4449 to i8
  %4451 = shl i8 1, %4450
  %4452 = or i8 %4431, %4451
  %4453 = select i1 %4442, i8 %4452, i8 %4431
  store i8 %4453, ptr %frame.active, align 1
  %4454 = load <8 x i32>, ptr %frame.static.id, align 32
  %4455 = extractelement <8 x i32> %4454, i32 %4449
  %4456 = select i1 %4442, i32 11, i32 %4455
  %4457 = load <8 x i32>, ptr %frame.static.id, align 32
  %4458 = insertelement <8 x i32> %4457, i32 %4456, i32 %4449
  store <8 x i32> %4458, ptr %frame.static.id, align 32
  %4459 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4460 = extractelement <8 x i32> %4459, i32 %4449
  %4461 = select i1 %4442, i32 %4427, i32 %4460
  %4462 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4463 = insertelement <8 x i32> %4462, i32 %4461, i32 %4449
  store <8 x i32> %4463, ptr %frame.parent.token, align 32
  %4464 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4449
  %4465 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4449
  %4466 = load <8 x i1>, ptr %4464, align 1
  %4467 = load <8 x i1>, ptr %4465, align 1
  %4468 = select i1 %4442, <8 x i1> %699, <8 x i1> %4466
  store <8 x i1> %4468, ptr %4464, align 1
  %4469 = select i1 %4442, <8 x i1> zeroinitializer, <8 x i1> %4467
  store <8 x i1> %4469, ptr %4465, align 1
  %4470 = add i32 %4449, 1
  %4471 = select i1 %4440, i32 %4427, i32 %4470
  %4472 = select i1 true, i32 %4471, i32 %4427
  store i32 %4472, ptr %current.token, align 4
  %4473 = load i32, ptr %current.token, align 4
  %4474 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %706)
  %4475 = load i32, ptr %ready.count, align 4
  %4476 = icmp uge i32 %4475, 8
  %4477 = and i1 %4474, %4476
  br i1 %4477, label %ready.overflow.trap693, label %ready.overflow.resume694

ready.overflow.trap693:                           ; preds = %convergence.overflow.resume692
  call void @llvm.trap()
  unreachable

ready.overflow.resume694:                         ; preds = %convergence.overflow.resume692
  %4478 = select i1 %4474, i32 %4475, i32 0
  %4479 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4478
  %4480 = load <8 x i1>, ptr %4479, align 1
  %4481 = select i1 %4474, <8 x i1> %706, <8 x i1> %4480
  store <8 x i1> %4481, ptr %4479, align 1
  %4482 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4478
  %4483 = load i32, ptr %4482, align 4
  %4484 = select i1 %4474, i32 31, i32 %4483
  store i32 %4484, ptr %4482, align 4
  %4485 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4478
  %4486 = load i32, ptr %4485, align 4
  %4487 = select i1 %4474, i32 %4473, i32 %4486
  store i32 %4487, ptr %4485, align 4
  %4488 = add i32 %4475, 1
  %4489 = select i1 %4474, i32 %4488, i32 %4475
  store i32 %4489, ptr %ready.count, align 4
  %4490 = load <8 x i1>, ptr %runnable.mask, align 1
  %4491 = or <8 x i1> %4490, %706
  store <8 x i1> %4491, ptr %runnable.mask, align 1
  store <8 x i1> %708, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true695:                         ; preds = %varying.coherent690
  store <8 x i1> %699, ptr %current.mask, align 1
  %4492 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %699)
  br i1 %4492, label %schedule.31, label %scheduler.loop

varying.coherent.false696:                        ; preds = %varying.coherent690
  store <8 x i1> %699, ptr %current.mask, align 1
  %4493 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %699)
  br i1 %4493, label %schedule.34, label %scheduler.loop

varying.divergent700:                             ; preds = %schedule.31
  %4494 = load i32, ptr %current.token, align 4
  %4495 = icmp ne i32 %4494, 0
  %4496 = sub i32 %4494, 1
  %4497 = select i1 %4495, i32 %4496, i32 0
  %4498 = load i8, ptr %frame.active, align 1
  %4499 = trunc i32 %4497 to i8
  %4500 = shl i8 1, %4499
  %4501 = and i8 %4498, %4500
  %4502 = icmp ne i8 %4501, 0
  %4503 = load <8 x i32>, ptr %frame.static.id, align 32
  %4504 = extractelement <8 x i32> %4503, i32 %4497
  %4505 = icmp eq i32 %4504, 12
  %4506 = and i1 %4502, %4505
  %4507 = and i1 %4495, %4506
  %4508 = xor i1 %4507, true
  %4509 = and i1 true, %4508
  %4510 = xor i8 %4498, -1
  %4511 = icmp ne i8 %4510, 0
  %4512 = xor i1 %4511, true
  %4513 = and i1 %4509, %4512
  br i1 %4513, label %convergence.overflow.trap702, label %convergence.overflow.resume703

varying.coherent701:                              ; preds = %schedule.31
  br i1 %751, label %varying.coherent.true706, label %varying.coherent.false707

convergence.overflow.trap702:                     ; preds = %varying.divergent700
  call void @llvm.trap()
  unreachable

convergence.overflow.resume703:                   ; preds = %varying.divergent700
  %4514 = call i8 @llvm.cttz.i8(i8 %4510, i1 false)
  %4515 = zext i8 %4514 to i32
  %4516 = select i1 %4511, i32 %4515, i32 0
  %4517 = trunc i32 %4516 to i8
  %4518 = shl i8 1, %4517
  %4519 = or i8 %4498, %4518
  %4520 = select i1 %4509, i8 %4519, i8 %4498
  store i8 %4520, ptr %frame.active, align 1
  %4521 = load <8 x i32>, ptr %frame.static.id, align 32
  %4522 = extractelement <8 x i32> %4521, i32 %4516
  %4523 = select i1 %4509, i32 12, i32 %4522
  %4524 = load <8 x i32>, ptr %frame.static.id, align 32
  %4525 = insertelement <8 x i32> %4524, i32 %4523, i32 %4516
  store <8 x i32> %4525, ptr %frame.static.id, align 32
  %4526 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4527 = extractelement <8 x i32> %4526, i32 %4516
  %4528 = select i1 %4509, i32 %4494, i32 %4527
  %4529 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4530 = insertelement <8 x i32> %4529, i32 %4528, i32 %4516
  store <8 x i32> %4530, ptr %frame.parent.token, align 32
  %4531 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4516
  %4532 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4516
  %4533 = load <8 x i1>, ptr %4531, align 1
  %4534 = load <8 x i1>, ptr %4532, align 1
  %4535 = select i1 %4509, <8 x i1> %712, <8 x i1> %4533
  store <8 x i1> %4535, ptr %4531, align 1
  %4536 = select i1 %4509, <8 x i1> zeroinitializer, <8 x i1> %4534
  store <8 x i1> %4536, ptr %4532, align 1
  %4537 = add i32 %4516, 1
  %4538 = select i1 %4507, i32 %4494, i32 %4537
  %4539 = select i1 true, i32 %4538, i32 %4494
  store i32 %4539, ptr %current.token, align 4
  %4540 = load <8 x float>, ptr %.slot86, align 32
  %4541 = select <8 x i1> %750, <8 x float> zeroinitializer, <8 x float> %4540
  store <8 x float> %4541, ptr %.slot86, align 32
  %4542 = load i32, ptr %current.token, align 4
  %4543 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %748)
  %4544 = load i32, ptr %ready.count, align 4
  %4545 = icmp uge i32 %4544, 8
  %4546 = and i1 %4543, %4545
  br i1 %4546, label %ready.overflow.trap704, label %ready.overflow.resume705

ready.overflow.trap704:                           ; preds = %convergence.overflow.resume703
  call void @llvm.trap()
  unreachable

ready.overflow.resume705:                         ; preds = %convergence.overflow.resume703
  %4547 = select i1 %4543, i32 %4544, i32 0
  %4548 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4547
  %4549 = load <8 x i1>, ptr %4548, align 1
  %4550 = select i1 %4543, <8 x i1> %748, <8 x i1> %4549
  store <8 x i1> %4550, ptr %4548, align 1
  %4551 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4547
  %4552 = load i32, ptr %4551, align 4
  %4553 = select i1 %4543, i32 32, i32 %4552
  store i32 %4553, ptr %4551, align 4
  %4554 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4547
  %4555 = load i32, ptr %4554, align 4
  %4556 = select i1 %4543, i32 %4542, i32 %4555
  store i32 %4556, ptr %4554, align 4
  %4557 = add i32 %4544, 1
  %4558 = select i1 %4543, i32 %4557, i32 %4544
  store i32 %4558, ptr %ready.count, align 4
  %4559 = load <8 x i1>, ptr %runnable.mask, align 1
  %4560 = or <8 x i1> %4559, %748
  store <8 x i1> %4560, ptr %runnable.mask, align 1
  store <8 x i1> %750, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true706:                         ; preds = %varying.coherent701
  store <8 x i1> %712, ptr %current.mask, align 1
  %4561 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %712)
  br i1 %4561, label %schedule.32, label %scheduler.loop

varying.coherent.false707:                        ; preds = %varying.coherent701
  %4562 = load <8 x float>, ptr %.slot86, align 32
  %4563 = select <8 x i1> %712, <8 x float> zeroinitializer, <8 x float> %4562
  store <8 x float> %4563, ptr %.slot86, align 32
  store <8 x i1> %712, ptr %current.mask, align 1
  %4564 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %712)
  br i1 %4564, label %schedule.33, label %scheduler.loop

convergence.cascade710:                           ; preds = %convergence.cascade710, %schedule.33
  %convergence.cascade.flow714 = phi <8 x i1> [ %773, %schedule.33 ], [ %4607, %convergence.cascade710 ]
  %convergence.cascade.depth715 = phi i32 [ 0, %schedule.33 ], [ %4608, %convergence.cascade710 ]
  %4565 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow714)
  %4566 = load i32, ptr %current.token, align 4
  %4567 = icmp ne i32 %4566, 0
  %4568 = and i1 %4565, %4567
  %4569 = sub i32 %4566, 1
  %4570 = select i1 %4568, i32 %4569, i32 0
  %4571 = load i8, ptr %frame.active, align 1
  %4572 = trunc i32 %4570 to i8
  %4573 = shl i8 1, %4572
  %4574 = and i8 %4571, %4573
  %4575 = icmp ne i8 %4574, 0
  %4576 = load <8 x i32>, ptr %frame.static.id, align 32
  %4577 = extractelement <8 x i32> %4576, i32 %4570
  %convergence.target.pointer716 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %4577
  %convergence.dynamic.target717 = load i32, ptr %convergence.target.pointer716, align 4
  %4578 = icmp eq i32 %convergence.dynamic.target717, 33
  %4579 = and i1 %4575, %4578
  %4580 = and i1 %4568, %4579
  %4581 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4570
  %4582 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4570
  %4583 = load <8 x i1>, ptr %4581, align 1
  %4584 = load <8 x i1>, ptr %4582, align 1
  %4585 = or <8 x i1> %4584, %convergence.cascade.flow714
  %4586 = load <8 x i1>, ptr %live.mask, align 1
  %4587 = and <8 x i1> %4583, %4586
  %4588 = icmp eq <8 x i1> %4585, %4587
  %4589 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4588)
  %4590 = and i1 %4580, %4589
  %4591 = select i1 %4590, <8 x i1> zeroinitializer, <8 x i1> %4585
  %4592 = select i1 %4580, <8 x i1> %4591, <8 x i1> %4584
  store <8 x i1> %4592, ptr %4582, align 1
  %4593 = select i1 %4590, <8 x i1> zeroinitializer, <8 x i1> %4583
  store <8 x i1> %4593, ptr %4581, align 1
  %4594 = trunc i32 %4570 to i8
  %4595 = shl i8 1, %4594
  %4596 = xor i8 %4595, -1
  %4597 = and i8 %4571, %4596
  %4598 = select i1 %4590, i8 %4597, i8 %4571
  store i8 %4598, ptr %frame.active, align 1
  %.splatinsert718 = insertelement <8 x i1> poison, i1 %4580, i64 0
  %.splat719 = shufflevector <8 x i1> %.splatinsert718, <8 x i1> poison, <8 x i32> zeroinitializer
  %4599 = and <8 x i1> %convergence.cascade.flow714, %.splat719
  %4600 = load <8 x i1>, ptr %runnable.mask, align 1
  %4601 = xor <8 x i1> %4599, splat (i1 true)
  %4602 = and <8 x i1> %4600, %4601
  store <8 x i1> %4602, ptr %runnable.mask, align 1
  %.splatinsert720 = insertelement <8 x i1> poison, i1 %4590, i64 0
  %.splat721 = shufflevector <8 x i1> %.splatinsert720, <8 x i1> poison, <8 x i32> zeroinitializer
  %4603 = select <8 x i1> %.splat721, <8 x i1> %4585, <8 x i1> zeroinitializer
  %4604 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4605 = extractelement <8 x i32> %4604, i32 %4570
  %4606 = select i1 %4590, i32 %4605, i32 %4566
  store i32 %4606, ptr %current.token, align 4
  %.splatinsert722 = insertelement <8 x i1> poison, i1 %4580, i64 0
  %.splat723 = shufflevector <8 x i1> %.splatinsert722, <8 x i1> poison, <8 x i32> zeroinitializer
  %4607 = select <8 x i1> %.splat723, <8 x i1> %4603, <8 x i1> %convergence.cascade.flow714
  %4608 = add i32 %convergence.cascade.depth715, 1
  %4609 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4607)
  %4610 = icmp ult i32 %4608, 8
  %4611 = and i1 %4609, %4610
  %4612 = and i1 %4580, %4611
  %convergence.parent.token724 = load i32, ptr %current.token, align 4
  %convergence.parent.present725 = icmp ne i32 %convergence.parent.token724, 0
  %4613 = and i1 %4612, %convergence.parent.present725
  br i1 %4613, label %convergence.cascade710, label %convergence.cascade.exit711

convergence.cascade.exit711:                      ; preds = %convergence.cascade710, %schedule.33
  %convergence.cascade.result726 = phi <8 x i1> [ %773, %schedule.33 ], [ %4607, %convergence.cascade710 ]
  %4614 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result726)
  br i1 %4614, label %convergence.target.33.ready, label %scheduler.loop

convergence.target.33.ready:                      ; preds = %convergence.cascade.exit711
  %4615 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result726)
  %4616 = bitcast <8 x i1> %convergence.cascade.result726 to i8
  %4617 = call i8 @llvm.cttz.i8(i8 %4616, i1 false)
  %4618 = zext i8 %4617 to i32
  %4619 = select i1 %4615, i32 %4618, i32 0
  %.spill.load727 = load float, ptr %.spill49, align 4
  %.splatinsert728 = insertelement <8 x float> poison, float %.spill.load727, i64 0
  %.splat729 = shufflevector <8 x float> %.splatinsert728, <8 x float> poison, <8 x i32> zeroinitializer
  %.state730 = load <8 x float>, ptr %.slot86, align 32
  %.spill.load731 = load volatile <8 x i1>, ptr %.spill84, align 1
  %4620 = select <8 x i1> %.spill.load731, <8 x float> %.state730, <8 x float> %.splat729
  %tile_snapshot.spill.load732 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill82, align 64
  %4621 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load732, 0
  %4622 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load732, 1
  %.state733 = load <8 x i64>, ptr %.slot83, align 64
  %4623 = mul <8 x i64> %.state733, splat (i64 32)
  %4624 = add <8 x i64> %4622, %4623
  %4625 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4621, 0
  %4626 = insertvalue { <8 x ptr>, <8 x i64> } %4625, <8 x i64> %4624, 1
  %4627 = extractvalue { <8 x ptr>, <8 x i64> } %4626, 0
  %4628 = extractvalue { <8 x ptr>, <8 x i64> } %4626, 1
  %4629 = getelementptr i8, <8 x ptr> %4627, <8 x i64> %4628
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %4620, <8 x ptr> %4629, i32 1, <8 x i1> %convergence.cascade.result726)
  %.state734 = load <8 x i64>, ptr %.slot83, align 64
  %4630 = add <8 x i64> %.state734, splat (i64 1)
  %4631 = load <8 x i64>, ptr %.slot83, align 64
  %4632 = select <8 x i1> %convergence.cascade.result726, <8 x i64> %4630, <8 x i64> %4631
  store <8 x i64> %4632, ptr %.slot83, align 64
  store <8 x i1> %convergence.cascade.result726, ptr %current.mask, align 1
  %4633 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result726)
  br i1 %4633, label %schedule.30, label %scheduler.loop

convergence.cascade735:                           ; preds = %convergence.cascade735, %schedule.34
  %convergence.cascade.flow739 = phi <8 x i1> [ %774, %schedule.34 ], [ %4676, %convergence.cascade735 ]
  %convergence.cascade.depth740 = phi i32 [ 0, %schedule.34 ], [ %4677, %convergence.cascade735 ]
  %4634 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow739)
  %4635 = load i32, ptr %current.token, align 4
  %4636 = icmp ne i32 %4635, 0
  %4637 = and i1 %4634, %4636
  %4638 = sub i32 %4635, 1
  %4639 = select i1 %4637, i32 %4638, i32 0
  %4640 = load i8, ptr %frame.active, align 1
  %4641 = trunc i32 %4639 to i8
  %4642 = shl i8 1, %4641
  %4643 = and i8 %4640, %4642
  %4644 = icmp ne i8 %4643, 0
  %4645 = load <8 x i32>, ptr %frame.static.id, align 32
  %4646 = extractelement <8 x i32> %4645, i32 %4639
  %convergence.target.pointer741 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %4646
  %convergence.dynamic.target742 = load i32, ptr %convergence.target.pointer741, align 4
  %4647 = icmp eq i32 %convergence.dynamic.target742, 34
  %4648 = and i1 %4644, %4647
  %4649 = and i1 %4637, %4648
  %4650 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4639
  %4651 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4639
  %4652 = load <8 x i1>, ptr %4650, align 1
  %4653 = load <8 x i1>, ptr %4651, align 1
  %4654 = or <8 x i1> %4653, %convergence.cascade.flow739
  %4655 = load <8 x i1>, ptr %live.mask, align 1
  %4656 = and <8 x i1> %4652, %4655
  %4657 = icmp eq <8 x i1> %4654, %4656
  %4658 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4657)
  %4659 = and i1 %4649, %4658
  %4660 = select i1 %4659, <8 x i1> zeroinitializer, <8 x i1> %4654
  %4661 = select i1 %4649, <8 x i1> %4660, <8 x i1> %4653
  store <8 x i1> %4661, ptr %4651, align 1
  %4662 = select i1 %4659, <8 x i1> zeroinitializer, <8 x i1> %4652
  store <8 x i1> %4662, ptr %4650, align 1
  %4663 = trunc i32 %4639 to i8
  %4664 = shl i8 1, %4663
  %4665 = xor i8 %4664, -1
  %4666 = and i8 %4640, %4665
  %4667 = select i1 %4659, i8 %4666, i8 %4640
  store i8 %4667, ptr %frame.active, align 1
  %.splatinsert743 = insertelement <8 x i1> poison, i1 %4649, i64 0
  %.splat744 = shufflevector <8 x i1> %.splatinsert743, <8 x i1> poison, <8 x i32> zeroinitializer
  %4668 = and <8 x i1> %convergence.cascade.flow739, %.splat744
  %4669 = load <8 x i1>, ptr %runnable.mask, align 1
  %4670 = xor <8 x i1> %4668, splat (i1 true)
  %4671 = and <8 x i1> %4669, %4670
  store <8 x i1> %4671, ptr %runnable.mask, align 1
  %.splatinsert745 = insertelement <8 x i1> poison, i1 %4659, i64 0
  %.splat746 = shufflevector <8 x i1> %.splatinsert745, <8 x i1> poison, <8 x i32> zeroinitializer
  %4672 = select <8 x i1> %.splat746, <8 x i1> %4654, <8 x i1> zeroinitializer
  %4673 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4674 = extractelement <8 x i32> %4673, i32 %4639
  %4675 = select i1 %4659, i32 %4674, i32 %4635
  store i32 %4675, ptr %current.token, align 4
  %.splatinsert747 = insertelement <8 x i1> poison, i1 %4649, i64 0
  %.splat748 = shufflevector <8 x i1> %.splatinsert747, <8 x i1> poison, <8 x i32> zeroinitializer
  %4676 = select <8 x i1> %.splat748, <8 x i1> %4672, <8 x i1> %convergence.cascade.flow739
  %4677 = add i32 %convergence.cascade.depth740, 1
  %4678 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4676)
  %4679 = icmp ult i32 %4677, 8
  %4680 = and i1 %4678, %4679
  %4681 = and i1 %4649, %4680
  %convergence.parent.token749 = load i32, ptr %current.token, align 4
  %convergence.parent.present750 = icmp ne i32 %convergence.parent.token749, 0
  %4682 = and i1 %4681, %convergence.parent.present750
  br i1 %4682, label %convergence.cascade735, label %convergence.cascade.exit736

convergence.cascade.exit736:                      ; preds = %convergence.cascade735, %schedule.34
  %convergence.cascade.result751 = phi <8 x i1> [ %774, %schedule.34 ], [ %4676, %convergence.cascade735 ]
  %4683 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result751)
  br i1 %4683, label %convergence.target.34.ready, label %scheduler.loop

convergence.target.34.ready:                      ; preds = %convergence.cascade.exit736
  %4684 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result751)
  %4685 = bitcast <8 x i1> %convergence.cascade.result751 to i8
  %4686 = call i8 @llvm.cttz.i8(i8 %4685, i1 false)
  %4687 = zext i8 %4686 to i32
  %4688 = select i1 %4684, i32 %4687, i32 0
  %4689 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4690 = extractvalue { <8 x ptr>, <8 x i64> } %27, 0
  %4691 = extractvalue { <8 x ptr>, <8 x i64> } %4689, 0
  %4692 = select <8 x i1> %convergence.cascade.result751, <8 x ptr> %4690, <8 x ptr> %4691
  %4693 = extractvalue { <8 x ptr>, <8 x i64> } %27, 1
  %4694 = extractvalue { <8 x ptr>, <8 x i64> } %4689, 1
  %4695 = select <8 x i1> %convergence.cascade.result751, <8 x i64> %4693, <8 x i64> %4694
  %4696 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4692, 0
  %4697 = insertvalue { <8 x ptr>, <8 x i64> } %4696, <8 x i64> %4695, 1
  store volatile { <8 x ptr>, <8 x i64> } %4697, ptr %tile_snapshot.spill87, align 64
  %4698 = load <8 x i64>, ptr %.slot88, align 64
  %4699 = select <8 x i1> %convergence.cascade.result751, <8 x i64> zeroinitializer, <8 x i64> %4698
  store <8 x i64> %4699, ptr %.slot88, align 64
  store <8 x i1> %convergence.cascade.result751, ptr %current.mask, align 1
  %4700 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result751)
  br i1 %4700, label %schedule.35, label %scheduler.loop

varying.divergent753:                             ; preds = %schedule.35
  %4701 = load i32, ptr %current.token, align 4
  %4702 = icmp ne i32 %4701, 0
  %4703 = sub i32 %4701, 1
  %4704 = select i1 %4702, i32 %4703, i32 0
  %4705 = load i8, ptr %frame.active, align 1
  %4706 = trunc i32 %4704 to i8
  %4707 = shl i8 1, %4706
  %4708 = and i8 %4705, %4707
  %4709 = icmp ne i8 %4708, 0
  %4710 = load <8 x i32>, ptr %frame.static.id, align 32
  %4711 = extractelement <8 x i32> %4710, i32 %4704
  %4712 = icmp eq i32 %4711, 13
  %4713 = and i1 %4709, %4712
  %4714 = and i1 %4702, %4713
  %4715 = xor i1 %4714, true
  %4716 = and i1 true, %4715
  %4717 = xor i8 %4705, -1
  %4718 = icmp ne i8 %4717, 0
  %4719 = xor i1 %4718, true
  %4720 = and i1 %4716, %4719
  br i1 %4720, label %convergence.overflow.trap755, label %convergence.overflow.resume756

varying.coherent754:                              ; preds = %schedule.35
  br i1 %785, label %varying.coherent.true759, label %varying.coherent.false760

convergence.overflow.trap755:                     ; preds = %varying.divergent753
  call void @llvm.trap()
  unreachable

convergence.overflow.resume756:                   ; preds = %varying.divergent753
  %4721 = call i8 @llvm.cttz.i8(i8 %4717, i1 false)
  %4722 = zext i8 %4721 to i32
  %4723 = select i1 %4718, i32 %4722, i32 0
  %4724 = trunc i32 %4723 to i8
  %4725 = shl i8 1, %4724
  %4726 = or i8 %4705, %4725
  %4727 = select i1 %4716, i8 %4726, i8 %4705
  store i8 %4727, ptr %frame.active, align 1
  %4728 = load <8 x i32>, ptr %frame.static.id, align 32
  %4729 = extractelement <8 x i32> %4728, i32 %4723
  %4730 = select i1 %4716, i32 13, i32 %4729
  %4731 = load <8 x i32>, ptr %frame.static.id, align 32
  %4732 = insertelement <8 x i32> %4731, i32 %4730, i32 %4723
  store <8 x i32> %4732, ptr %frame.static.id, align 32
  %4733 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4734 = extractelement <8 x i32> %4733, i32 %4723
  %4735 = select i1 %4716, i32 %4701, i32 %4734
  %4736 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4737 = insertelement <8 x i32> %4736, i32 %4735, i32 %4723
  store <8 x i32> %4737, ptr %frame.parent.token, align 32
  %4738 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4723
  %4739 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4723
  %4740 = load <8 x i1>, ptr %4738, align 1
  %4741 = load <8 x i1>, ptr %4739, align 1
  %4742 = select i1 %4716, <8 x i1> %775, <8 x i1> %4740
  store <8 x i1> %4742, ptr %4738, align 1
  %4743 = select i1 %4716, <8 x i1> zeroinitializer, <8 x i1> %4741
  store <8 x i1> %4743, ptr %4739, align 1
  %4744 = add i32 %4723, 1
  %4745 = select i1 %4714, i32 %4701, i32 %4744
  %4746 = select i1 true, i32 %4745, i32 %4701
  store i32 %4746, ptr %current.token, align 4
  %4747 = load i32, ptr %current.token, align 4
  %4748 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %782)
  %4749 = load i32, ptr %ready.count, align 4
  %4750 = icmp uge i32 %4749, 8
  %4751 = and i1 %4748, %4750
  br i1 %4751, label %ready.overflow.trap757, label %ready.overflow.resume758

ready.overflow.trap757:                           ; preds = %convergence.overflow.resume756
  call void @llvm.trap()
  unreachable

ready.overflow.resume758:                         ; preds = %convergence.overflow.resume756
  %4752 = select i1 %4748, i32 %4749, i32 0
  %4753 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4752
  %4754 = load <8 x i1>, ptr %4753, align 1
  %4755 = select i1 %4748, <8 x i1> %782, <8 x i1> %4754
  store <8 x i1> %4755, ptr %4753, align 1
  %4756 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4752
  %4757 = load i32, ptr %4756, align 4
  %4758 = select i1 %4748, i32 36, i32 %4757
  store i32 %4758, ptr %4756, align 4
  %4759 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4752
  %4760 = load i32, ptr %4759, align 4
  %4761 = select i1 %4748, i32 %4747, i32 %4760
  store i32 %4761, ptr %4759, align 4
  %4762 = add i32 %4749, 1
  %4763 = select i1 %4748, i32 %4762, i32 %4749
  store i32 %4763, ptr %ready.count, align 4
  %4764 = load <8 x i1>, ptr %runnable.mask, align 1
  %4765 = or <8 x i1> %4764, %782
  store <8 x i1> %4765, ptr %runnable.mask, align 1
  store <8 x i1> %784, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true759:                         ; preds = %varying.coherent754
  store <8 x i1> %775, ptr %current.mask, align 1
  %4766 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %775)
  br i1 %4766, label %schedule.36, label %scheduler.loop

varying.coherent.false760:                        ; preds = %varying.coherent754
  store <8 x i1> %775, ptr %current.mask, align 1
  %4767 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %775)
  br i1 %4767, label %schedule.37, label %scheduler.loop

convergence.cascade768:                           ; preds = %convergence.cascade768, %schedule.37
  %convergence.cascade.flow772 = phi <8 x i1> [ %837, %schedule.37 ], [ %4810, %convergence.cascade768 ]
  %convergence.cascade.depth773 = phi i32 [ 0, %schedule.37 ], [ %4811, %convergence.cascade768 ]
  %4768 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow772)
  %4769 = load i32, ptr %current.token, align 4
  %4770 = icmp ne i32 %4769, 0
  %4771 = and i1 %4768, %4770
  %4772 = sub i32 %4769, 1
  %4773 = select i1 %4771, i32 %4772, i32 0
  %4774 = load i8, ptr %frame.active, align 1
  %4775 = trunc i32 %4773 to i8
  %4776 = shl i8 1, %4775
  %4777 = and i8 %4774, %4776
  %4778 = icmp ne i8 %4777, 0
  %4779 = load <8 x i32>, ptr %frame.static.id, align 32
  %4780 = extractelement <8 x i32> %4779, i32 %4773
  %convergence.target.pointer774 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %4780
  %convergence.dynamic.target775 = load i32, ptr %convergence.target.pointer774, align 4
  %4781 = icmp eq i32 %convergence.dynamic.target775, 37
  %4782 = and i1 %4778, %4781
  %4783 = and i1 %4771, %4782
  %4784 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4773
  %4785 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4773
  %4786 = load <8 x i1>, ptr %4784, align 1
  %4787 = load <8 x i1>, ptr %4785, align 1
  %4788 = or <8 x i1> %4787, %convergence.cascade.flow772
  %4789 = load <8 x i1>, ptr %live.mask, align 1
  %4790 = and <8 x i1> %4786, %4789
  %4791 = icmp eq <8 x i1> %4788, %4790
  %4792 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4791)
  %4793 = and i1 %4783, %4792
  %4794 = select i1 %4793, <8 x i1> zeroinitializer, <8 x i1> %4788
  %4795 = select i1 %4783, <8 x i1> %4794, <8 x i1> %4787
  store <8 x i1> %4795, ptr %4785, align 1
  %4796 = select i1 %4793, <8 x i1> zeroinitializer, <8 x i1> %4786
  store <8 x i1> %4796, ptr %4784, align 1
  %4797 = trunc i32 %4773 to i8
  %4798 = shl i8 1, %4797
  %4799 = xor i8 %4798, -1
  %4800 = and i8 %4774, %4799
  %4801 = select i1 %4793, i8 %4800, i8 %4774
  store i8 %4801, ptr %frame.active, align 1
  %.splatinsert776 = insertelement <8 x i1> poison, i1 %4783, i64 0
  %.splat777 = shufflevector <8 x i1> %.splatinsert776, <8 x i1> poison, <8 x i32> zeroinitializer
  %4802 = and <8 x i1> %convergence.cascade.flow772, %.splat777
  %4803 = load <8 x i1>, ptr %runnable.mask, align 1
  %4804 = xor <8 x i1> %4802, splat (i1 true)
  %4805 = and <8 x i1> %4803, %4804
  store <8 x i1> %4805, ptr %runnable.mask, align 1
  %.splatinsert778 = insertelement <8 x i1> poison, i1 %4793, i64 0
  %.splat779 = shufflevector <8 x i1> %.splatinsert778, <8 x i1> poison, <8 x i32> zeroinitializer
  %4806 = select <8 x i1> %.splat779, <8 x i1> %4788, <8 x i1> zeroinitializer
  %4807 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4808 = extractelement <8 x i32> %4807, i32 %4773
  %4809 = select i1 %4793, i32 %4808, i32 %4769
  store i32 %4809, ptr %current.token, align 4
  %.splatinsert780 = insertelement <8 x i1> poison, i1 %4783, i64 0
  %.splat781 = shufflevector <8 x i1> %.splatinsert780, <8 x i1> poison, <8 x i32> zeroinitializer
  %4810 = select <8 x i1> %.splat781, <8 x i1> %4806, <8 x i1> %convergence.cascade.flow772
  %4811 = add i32 %convergence.cascade.depth773, 1
  %4812 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4810)
  %4813 = icmp ult i32 %4811, 8
  %4814 = and i1 %4812, %4813
  %4815 = and i1 %4783, %4814
  %convergence.parent.token782 = load i32, ptr %current.token, align 4
  %convergence.parent.present783 = icmp ne i32 %convergence.parent.token782, 0
  %4816 = and i1 %4815, %convergence.parent.present783
  br i1 %4816, label %convergence.cascade768, label %convergence.cascade.exit769

convergence.cascade.exit769:                      ; preds = %convergence.cascade768, %schedule.37
  %convergence.cascade.result784 = phi <8 x i1> [ %837, %schedule.37 ], [ %4810, %convergence.cascade768 ]
  %4817 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  br i1 %4817, label %convergence.target.37.ready, label %scheduler.loop

convergence.target.37.ready:                      ; preds = %convergence.cascade.exit769
  %4818 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %4819 = bitcast <8 x i1> %convergence.cascade.result784 to i8
  %4820 = call i8 @llvm.cttz.i8(i8 %4819, i1 false)
  %4821 = zext i8 %4820 to i32
  %4822 = select i1 %4818, i32 %4821, i32 0
  %4823 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill89, align 64
  %4824 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4825 = extractvalue { <8 x ptr>, <8 x i64> } %4823, 0
  %4826 = select <8 x i1> %convergence.cascade.result784, <8 x ptr> %4824, <8 x ptr> %4825
  %4827 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %4828 = extractvalue { <8 x ptr>, <8 x i64> } %4823, 1
  %4829 = select <8 x i1> %convergence.cascade.result784, <8 x i64> %4827, <8 x i64> %4828
  %4830 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4826, 0
  %4831 = insertvalue { <8 x ptr>, <8 x i64> } %4830, <8 x i64> %4829, 1
  store volatile { <8 x ptr>, <8 x i64> } %4831, ptr %tile_snapshot.spill89, align 64
  %4832 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4833 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %4834 = add <8 x i64> %4833, zeroinitializer
  %4835 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4832, 0
  %4836 = insertvalue { <8 x ptr>, <8 x i64> } %4835, <8 x i64> %4834, 1
  %4837 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4838 = extractvalue { <8 x ptr>, <8 x i64> } %4836, 1
  %4839 = extractelement <8 x ptr> %4837, i32 0
  %4840 = extractelement <8 x i64> %4838, i32 %4822
  %4841 = zext i32 %4822 to i64
  %4842 = mul i64 %4841, 8
  %4843 = sub i64 %4840, %4842
  %4844 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %4845 = select i1 %4844, i64 %4843, i64 0
  %private.contiguous.address785 = getelementptr i8, ptr %4839, i64 %4845
  %private.contiguous.preserve786 = load <8 x i64>, ptr %private.contiguous.address785, align 8
  %4846 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 -16), <8 x i64> %private.contiguous.preserve786
  store <8 x i64> %4846, ptr %private.contiguous.address785, align 8
  %4847 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4848 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %4849 = add <8 x i64> %4848, splat (i64 64)
  %4850 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4847, 0
  %4851 = insertvalue { <8 x ptr>, <8 x i64> } %4850, <8 x i64> %4849, 1
  %4852 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4853 = extractvalue { <8 x ptr>, <8 x i64> } %4851, 1
  %4854 = extractelement <8 x ptr> %4852, i32 0
  %4855 = extractelement <8 x i64> %4853, i32 %4822
  %4856 = zext i32 %4822 to i64
  %4857 = mul i64 %4856, 8
  %4858 = sub i64 %4855, %4857
  %4859 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %4860 = select i1 %4859, i64 %4858, i64 0
  %private.contiguous.address787 = getelementptr i8, ptr %4854, i64 %4860
  %private.contiguous.preserve788 = load <8 x i64>, ptr %private.contiguous.address787, align 8
  %4861 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 -15), <8 x i64> %private.contiguous.preserve788
  store <8 x i64> %4861, ptr %private.contiguous.address787, align 8
  %4862 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4863 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %4864 = add <8 x i64> %4863, splat (i64 128)
  %4865 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4862, 0
  %4866 = insertvalue { <8 x ptr>, <8 x i64> } %4865, <8 x i64> %4864, 1
  %4867 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4868 = extractvalue { <8 x ptr>, <8 x i64> } %4866, 1
  %4869 = extractelement <8 x ptr> %4867, i32 0
  %4870 = extractelement <8 x i64> %4868, i32 %4822
  %4871 = zext i32 %4822 to i64
  %4872 = mul i64 %4871, 8
  %4873 = sub i64 %4870, %4872
  %4874 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %4875 = select i1 %4874, i64 %4873, i64 0
  %private.contiguous.address789 = getelementptr i8, ptr %4869, i64 %4875
  %private.contiguous.preserve790 = load <8 x i64>, ptr %private.contiguous.address789, align 8
  %4876 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 -14), <8 x i64> %private.contiguous.preserve790
  store <8 x i64> %4876, ptr %private.contiguous.address789, align 8
  %4877 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4878 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %4879 = add <8 x i64> %4878, splat (i64 192)
  %4880 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4877, 0
  %4881 = insertvalue { <8 x ptr>, <8 x i64> } %4880, <8 x i64> %4879, 1
  %4882 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4883 = extractvalue { <8 x ptr>, <8 x i64> } %4881, 1
  %4884 = extractelement <8 x ptr> %4882, i32 0
  %4885 = extractelement <8 x i64> %4883, i32 %4822
  %4886 = zext i32 %4822 to i64
  %4887 = mul i64 %4886, 8
  %4888 = sub i64 %4885, %4887
  %4889 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %4890 = select i1 %4889, i64 %4888, i64 0
  %private.contiguous.address791 = getelementptr i8, ptr %4884, i64 %4890
  %private.contiguous.preserve792 = load <8 x i64>, ptr %private.contiguous.address791, align 8
  %4891 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 -13), <8 x i64> %private.contiguous.preserve792
  store <8 x i64> %4891, ptr %private.contiguous.address791, align 8
  %4892 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4893 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %4894 = add <8 x i64> %4893, splat (i64 256)
  %4895 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4892, 0
  %4896 = insertvalue { <8 x ptr>, <8 x i64> } %4895, <8 x i64> %4894, 1
  %4897 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4898 = extractvalue { <8 x ptr>, <8 x i64> } %4896, 1
  %4899 = extractelement <8 x ptr> %4897, i32 0
  %4900 = extractelement <8 x i64> %4898, i32 %4822
  %4901 = zext i32 %4822 to i64
  %4902 = mul i64 %4901, 8
  %4903 = sub i64 %4900, %4902
  %4904 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %4905 = select i1 %4904, i64 %4903, i64 0
  %private.contiguous.address793 = getelementptr i8, ptr %4899, i64 %4905
  %private.contiguous.preserve794 = load <8 x i64>, ptr %private.contiguous.address793, align 8
  %4906 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 -12), <8 x i64> %private.contiguous.preserve794
  store <8 x i64> %4906, ptr %private.contiguous.address793, align 8
  %4907 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4908 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %4909 = add <8 x i64> %4908, splat (i64 320)
  %4910 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4907, 0
  %4911 = insertvalue { <8 x ptr>, <8 x i64> } %4910, <8 x i64> %4909, 1
  %4912 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4913 = extractvalue { <8 x ptr>, <8 x i64> } %4911, 1
  %4914 = extractelement <8 x ptr> %4912, i32 0
  %4915 = extractelement <8 x i64> %4913, i32 %4822
  %4916 = zext i32 %4822 to i64
  %4917 = mul i64 %4916, 8
  %4918 = sub i64 %4915, %4917
  %4919 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %4920 = select i1 %4919, i64 %4918, i64 0
  %private.contiguous.address795 = getelementptr i8, ptr %4914, i64 %4920
  %private.contiguous.preserve796 = load <8 x i64>, ptr %private.contiguous.address795, align 8
  %4921 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 -11), <8 x i64> %private.contiguous.preserve796
  store <8 x i64> %4921, ptr %private.contiguous.address795, align 8
  %4922 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4923 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %4924 = add <8 x i64> %4923, splat (i64 384)
  %4925 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4922, 0
  %4926 = insertvalue { <8 x ptr>, <8 x i64> } %4925, <8 x i64> %4924, 1
  %4927 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4928 = extractvalue { <8 x ptr>, <8 x i64> } %4926, 1
  %4929 = extractelement <8 x ptr> %4927, i32 0
  %4930 = extractelement <8 x i64> %4928, i32 %4822
  %4931 = zext i32 %4822 to i64
  %4932 = mul i64 %4931, 8
  %4933 = sub i64 %4930, %4932
  %4934 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %4935 = select i1 %4934, i64 %4933, i64 0
  %private.contiguous.address797 = getelementptr i8, ptr %4929, i64 %4935
  %private.contiguous.preserve798 = load <8 x i64>, ptr %private.contiguous.address797, align 8
  %4936 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 -10), <8 x i64> %private.contiguous.preserve798
  store <8 x i64> %4936, ptr %private.contiguous.address797, align 8
  %4937 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4938 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %4939 = add <8 x i64> %4938, splat (i64 448)
  %4940 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4937, 0
  %4941 = insertvalue { <8 x ptr>, <8 x i64> } %4940, <8 x i64> %4939, 1
  %4942 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4943 = extractvalue { <8 x ptr>, <8 x i64> } %4941, 1
  %4944 = extractelement <8 x ptr> %4942, i32 0
  %4945 = extractelement <8 x i64> %4943, i32 %4822
  %4946 = zext i32 %4822 to i64
  %4947 = mul i64 %4946, 8
  %4948 = sub i64 %4945, %4947
  %4949 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %4950 = select i1 %4949, i64 %4948, i64 0
  %private.contiguous.address799 = getelementptr i8, ptr %4944, i64 %4950
  %private.contiguous.preserve800 = load <8 x i64>, ptr %private.contiguous.address799, align 8
  %4951 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 -9), <8 x i64> %private.contiguous.preserve800
  store <8 x i64> %4951, ptr %private.contiguous.address799, align 8
  %4952 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4953 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %4954 = add <8 x i64> %4953, splat (i64 512)
  %4955 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4952, 0
  %4956 = insertvalue { <8 x ptr>, <8 x i64> } %4955, <8 x i64> %4954, 1
  %4957 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4958 = extractvalue { <8 x ptr>, <8 x i64> } %4956, 1
  %4959 = extractelement <8 x ptr> %4957, i32 0
  %4960 = extractelement <8 x i64> %4958, i32 %4822
  %4961 = zext i32 %4822 to i64
  %4962 = mul i64 %4961, 8
  %4963 = sub i64 %4960, %4962
  %4964 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %4965 = select i1 %4964, i64 %4963, i64 0
  %private.contiguous.address801 = getelementptr i8, ptr %4959, i64 %4965
  %private.contiguous.preserve802 = load <8 x i64>, ptr %private.contiguous.address801, align 8
  %4966 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 -8), <8 x i64> %private.contiguous.preserve802
  store <8 x i64> %4966, ptr %private.contiguous.address801, align 8
  %4967 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4968 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %4969 = add <8 x i64> %4968, splat (i64 576)
  %4970 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4967, 0
  %4971 = insertvalue { <8 x ptr>, <8 x i64> } %4970, <8 x i64> %4969, 1
  %4972 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4973 = extractvalue { <8 x ptr>, <8 x i64> } %4971, 1
  %4974 = extractelement <8 x ptr> %4972, i32 0
  %4975 = extractelement <8 x i64> %4973, i32 %4822
  %4976 = zext i32 %4822 to i64
  %4977 = mul i64 %4976, 8
  %4978 = sub i64 %4975, %4977
  %4979 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %4980 = select i1 %4979, i64 %4978, i64 0
  %private.contiguous.address803 = getelementptr i8, ptr %4974, i64 %4980
  %private.contiguous.preserve804 = load <8 x i64>, ptr %private.contiguous.address803, align 8
  %4981 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 -7), <8 x i64> %private.contiguous.preserve804
  store <8 x i64> %4981, ptr %private.contiguous.address803, align 8
  %4982 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4983 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %4984 = add <8 x i64> %4983, splat (i64 640)
  %4985 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4982, 0
  %4986 = insertvalue { <8 x ptr>, <8 x i64> } %4985, <8 x i64> %4984, 1
  %4987 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4988 = extractvalue { <8 x ptr>, <8 x i64> } %4986, 1
  %4989 = extractelement <8 x ptr> %4987, i32 0
  %4990 = extractelement <8 x i64> %4988, i32 %4822
  %4991 = zext i32 %4822 to i64
  %4992 = mul i64 %4991, 8
  %4993 = sub i64 %4990, %4992
  %4994 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %4995 = select i1 %4994, i64 %4993, i64 0
  %private.contiguous.address805 = getelementptr i8, ptr %4989, i64 %4995
  %private.contiguous.preserve806 = load <8 x i64>, ptr %private.contiguous.address805, align 8
  %4996 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 -6), <8 x i64> %private.contiguous.preserve806
  store <8 x i64> %4996, ptr %private.contiguous.address805, align 8
  %4997 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4998 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %4999 = add <8 x i64> %4998, splat (i64 704)
  %5000 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4997, 0
  %5001 = insertvalue { <8 x ptr>, <8 x i64> } %5000, <8 x i64> %4999, 1
  %5002 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5003 = extractvalue { <8 x ptr>, <8 x i64> } %5001, 1
  %5004 = extractelement <8 x ptr> %5002, i32 0
  %5005 = extractelement <8 x i64> %5003, i32 %4822
  %5006 = zext i32 %4822 to i64
  %5007 = mul i64 %5006, 8
  %5008 = sub i64 %5005, %5007
  %5009 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %5010 = select i1 %5009, i64 %5008, i64 0
  %private.contiguous.address807 = getelementptr i8, ptr %5004, i64 %5010
  %private.contiguous.preserve808 = load <8 x i64>, ptr %private.contiguous.address807, align 8
  %5011 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 -5), <8 x i64> %private.contiguous.preserve808
  store <8 x i64> %5011, ptr %private.contiguous.address807, align 8
  %5012 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5013 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5014 = add <8 x i64> %5013, splat (i64 768)
  %5015 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5012, 0
  %5016 = insertvalue { <8 x ptr>, <8 x i64> } %5015, <8 x i64> %5014, 1
  %5017 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5018 = extractvalue { <8 x ptr>, <8 x i64> } %5016, 1
  %5019 = extractelement <8 x ptr> %5017, i32 0
  %5020 = extractelement <8 x i64> %5018, i32 %4822
  %5021 = zext i32 %4822 to i64
  %5022 = mul i64 %5021, 8
  %5023 = sub i64 %5020, %5022
  %5024 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %5025 = select i1 %5024, i64 %5023, i64 0
  %private.contiguous.address809 = getelementptr i8, ptr %5019, i64 %5025
  %private.contiguous.preserve810 = load <8 x i64>, ptr %private.contiguous.address809, align 8
  %5026 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 -4), <8 x i64> %private.contiguous.preserve810
  store <8 x i64> %5026, ptr %private.contiguous.address809, align 8
  %5027 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5028 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5029 = add <8 x i64> %5028, splat (i64 832)
  %5030 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5027, 0
  %5031 = insertvalue { <8 x ptr>, <8 x i64> } %5030, <8 x i64> %5029, 1
  %5032 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5033 = extractvalue { <8 x ptr>, <8 x i64> } %5031, 1
  %5034 = extractelement <8 x ptr> %5032, i32 0
  %5035 = extractelement <8 x i64> %5033, i32 %4822
  %5036 = zext i32 %4822 to i64
  %5037 = mul i64 %5036, 8
  %5038 = sub i64 %5035, %5037
  %5039 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %5040 = select i1 %5039, i64 %5038, i64 0
  %private.contiguous.address811 = getelementptr i8, ptr %5034, i64 %5040
  %private.contiguous.preserve812 = load <8 x i64>, ptr %private.contiguous.address811, align 8
  %5041 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 -3), <8 x i64> %private.contiguous.preserve812
  store <8 x i64> %5041, ptr %private.contiguous.address811, align 8
  %5042 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5043 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5044 = add <8 x i64> %5043, splat (i64 896)
  %5045 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5042, 0
  %5046 = insertvalue { <8 x ptr>, <8 x i64> } %5045, <8 x i64> %5044, 1
  %5047 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5048 = extractvalue { <8 x ptr>, <8 x i64> } %5046, 1
  %5049 = extractelement <8 x ptr> %5047, i32 0
  %5050 = extractelement <8 x i64> %5048, i32 %4822
  %5051 = zext i32 %4822 to i64
  %5052 = mul i64 %5051, 8
  %5053 = sub i64 %5050, %5052
  %5054 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %5055 = select i1 %5054, i64 %5053, i64 0
  %private.contiguous.address813 = getelementptr i8, ptr %5049, i64 %5055
  %private.contiguous.preserve814 = load <8 x i64>, ptr %private.contiguous.address813, align 8
  %5056 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 -2), <8 x i64> %private.contiguous.preserve814
  store <8 x i64> %5056, ptr %private.contiguous.address813, align 8
  %5057 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5058 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5059 = add <8 x i64> %5058, splat (i64 960)
  %5060 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5057, 0
  %5061 = insertvalue { <8 x ptr>, <8 x i64> } %5060, <8 x i64> %5059, 1
  %5062 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5063 = extractvalue { <8 x ptr>, <8 x i64> } %5061, 1
  %5064 = extractelement <8 x ptr> %5062, i32 0
  %5065 = extractelement <8 x i64> %5063, i32 %4822
  %5066 = zext i32 %4822 to i64
  %5067 = mul i64 %5066, 8
  %5068 = sub i64 %5065, %5067
  %5069 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %5070 = select i1 %5069, i64 %5068, i64 0
  %private.contiguous.address815 = getelementptr i8, ptr %5064, i64 %5070
  %private.contiguous.preserve816 = load <8 x i64>, ptr %private.contiguous.address815, align 8
  %5071 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 -1), <8 x i64> %private.contiguous.preserve816
  store <8 x i64> %5071, ptr %private.contiguous.address815, align 8
  %5072 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5073 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5074 = add <8 x i64> %5073, splat (i64 1024)
  %5075 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5072, 0
  %5076 = insertvalue { <8 x ptr>, <8 x i64> } %5075, <8 x i64> %5074, 1
  %5077 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5078 = extractvalue { <8 x ptr>, <8 x i64> } %5076, 1
  %5079 = extractelement <8 x ptr> %5077, i32 0
  %5080 = extractelement <8 x i64> %5078, i32 %4822
  %5081 = zext i32 %4822 to i64
  %5082 = mul i64 %5081, 8
  %5083 = sub i64 %5080, %5082
  %5084 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %5085 = select i1 %5084, i64 %5083, i64 0
  %private.contiguous.address817 = getelementptr i8, ptr %5079, i64 %5085
  %private.contiguous.preserve818 = load <8 x i64>, ptr %private.contiguous.address817, align 8
  %5086 = select <8 x i1> %convergence.cascade.result784, <8 x i64> zeroinitializer, <8 x i64> %private.contiguous.preserve818
  store <8 x i64> %5086, ptr %private.contiguous.address817, align 8
  %5087 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5088 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5089 = add <8 x i64> %5088, splat (i64 1088)
  %5090 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5087, 0
  %5091 = insertvalue { <8 x ptr>, <8 x i64> } %5090, <8 x i64> %5089, 1
  %5092 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5093 = extractvalue { <8 x ptr>, <8 x i64> } %5091, 1
  %5094 = extractelement <8 x ptr> %5092, i32 0
  %5095 = extractelement <8 x i64> %5093, i32 %4822
  %5096 = zext i32 %4822 to i64
  %5097 = mul i64 %5096, 8
  %5098 = sub i64 %5095, %5097
  %5099 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %5100 = select i1 %5099, i64 %5098, i64 0
  %private.contiguous.address819 = getelementptr i8, ptr %5094, i64 %5100
  %private.contiguous.preserve820 = load <8 x i64>, ptr %private.contiguous.address819, align 8
  %5101 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 1), <8 x i64> %private.contiguous.preserve820
  store <8 x i64> %5101, ptr %private.contiguous.address819, align 8
  %5102 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5103 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5104 = add <8 x i64> %5103, splat (i64 1152)
  %5105 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5102, 0
  %5106 = insertvalue { <8 x ptr>, <8 x i64> } %5105, <8 x i64> %5104, 1
  %5107 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5108 = extractvalue { <8 x ptr>, <8 x i64> } %5106, 1
  %5109 = extractelement <8 x ptr> %5107, i32 0
  %5110 = extractelement <8 x i64> %5108, i32 %4822
  %5111 = zext i32 %4822 to i64
  %5112 = mul i64 %5111, 8
  %5113 = sub i64 %5110, %5112
  %5114 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %5115 = select i1 %5114, i64 %5113, i64 0
  %private.contiguous.address821 = getelementptr i8, ptr %5109, i64 %5115
  %private.contiguous.preserve822 = load <8 x i64>, ptr %private.contiguous.address821, align 8
  %5116 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 2), <8 x i64> %private.contiguous.preserve822
  store <8 x i64> %5116, ptr %private.contiguous.address821, align 8
  %5117 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5118 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5119 = add <8 x i64> %5118, splat (i64 1216)
  %5120 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5117, 0
  %5121 = insertvalue { <8 x ptr>, <8 x i64> } %5120, <8 x i64> %5119, 1
  %5122 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5123 = extractvalue { <8 x ptr>, <8 x i64> } %5121, 1
  %5124 = extractelement <8 x ptr> %5122, i32 0
  %5125 = extractelement <8 x i64> %5123, i32 %4822
  %5126 = zext i32 %4822 to i64
  %5127 = mul i64 %5126, 8
  %5128 = sub i64 %5125, %5127
  %5129 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %5130 = select i1 %5129, i64 %5128, i64 0
  %private.contiguous.address823 = getelementptr i8, ptr %5124, i64 %5130
  %private.contiguous.preserve824 = load <8 x i64>, ptr %private.contiguous.address823, align 8
  %5131 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 3), <8 x i64> %private.contiguous.preserve824
  store <8 x i64> %5131, ptr %private.contiguous.address823, align 8
  %5132 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5133 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5134 = add <8 x i64> %5133, splat (i64 1280)
  %5135 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5132, 0
  %5136 = insertvalue { <8 x ptr>, <8 x i64> } %5135, <8 x i64> %5134, 1
  %5137 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5138 = extractvalue { <8 x ptr>, <8 x i64> } %5136, 1
  %5139 = extractelement <8 x ptr> %5137, i32 0
  %5140 = extractelement <8 x i64> %5138, i32 %4822
  %5141 = zext i32 %4822 to i64
  %5142 = mul i64 %5141, 8
  %5143 = sub i64 %5140, %5142
  %5144 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %5145 = select i1 %5144, i64 %5143, i64 0
  %private.contiguous.address825 = getelementptr i8, ptr %5139, i64 %5145
  %private.contiguous.preserve826 = load <8 x i64>, ptr %private.contiguous.address825, align 8
  %5146 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 4), <8 x i64> %private.contiguous.preserve826
  store <8 x i64> %5146, ptr %private.contiguous.address825, align 8
  %5147 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5148 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5149 = add <8 x i64> %5148, splat (i64 1344)
  %5150 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5147, 0
  %5151 = insertvalue { <8 x ptr>, <8 x i64> } %5150, <8 x i64> %5149, 1
  %5152 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5153 = extractvalue { <8 x ptr>, <8 x i64> } %5151, 1
  %5154 = extractelement <8 x ptr> %5152, i32 0
  %5155 = extractelement <8 x i64> %5153, i32 %4822
  %5156 = zext i32 %4822 to i64
  %5157 = mul i64 %5156, 8
  %5158 = sub i64 %5155, %5157
  %5159 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %5160 = select i1 %5159, i64 %5158, i64 0
  %private.contiguous.address827 = getelementptr i8, ptr %5154, i64 %5160
  %private.contiguous.preserve828 = load <8 x i64>, ptr %private.contiguous.address827, align 8
  %5161 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 5), <8 x i64> %private.contiguous.preserve828
  store <8 x i64> %5161, ptr %private.contiguous.address827, align 8
  %5162 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5163 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5164 = add <8 x i64> %5163, splat (i64 1408)
  %5165 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5162, 0
  %5166 = insertvalue { <8 x ptr>, <8 x i64> } %5165, <8 x i64> %5164, 1
  %5167 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5168 = extractvalue { <8 x ptr>, <8 x i64> } %5166, 1
  %5169 = extractelement <8 x ptr> %5167, i32 0
  %5170 = extractelement <8 x i64> %5168, i32 %4822
  %5171 = zext i32 %4822 to i64
  %5172 = mul i64 %5171, 8
  %5173 = sub i64 %5170, %5172
  %5174 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %5175 = select i1 %5174, i64 %5173, i64 0
  %private.contiguous.address829 = getelementptr i8, ptr %5169, i64 %5175
  %private.contiguous.preserve830 = load <8 x i64>, ptr %private.contiguous.address829, align 8
  %5176 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 6), <8 x i64> %private.contiguous.preserve830
  store <8 x i64> %5176, ptr %private.contiguous.address829, align 8
  %5177 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5178 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5179 = add <8 x i64> %5178, splat (i64 1472)
  %5180 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5177, 0
  %5181 = insertvalue { <8 x ptr>, <8 x i64> } %5180, <8 x i64> %5179, 1
  %5182 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5183 = extractvalue { <8 x ptr>, <8 x i64> } %5181, 1
  %5184 = extractelement <8 x ptr> %5182, i32 0
  %5185 = extractelement <8 x i64> %5183, i32 %4822
  %5186 = zext i32 %4822 to i64
  %5187 = mul i64 %5186, 8
  %5188 = sub i64 %5185, %5187
  %5189 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %5190 = select i1 %5189, i64 %5188, i64 0
  %private.contiguous.address831 = getelementptr i8, ptr %5184, i64 %5190
  %private.contiguous.preserve832 = load <8 x i64>, ptr %private.contiguous.address831, align 8
  %5191 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 7), <8 x i64> %private.contiguous.preserve832
  store <8 x i64> %5191, ptr %private.contiguous.address831, align 8
  %5192 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5193 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5194 = add <8 x i64> %5193, splat (i64 1536)
  %5195 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5192, 0
  %5196 = insertvalue { <8 x ptr>, <8 x i64> } %5195, <8 x i64> %5194, 1
  %5197 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5198 = extractvalue { <8 x ptr>, <8 x i64> } %5196, 1
  %5199 = extractelement <8 x ptr> %5197, i32 0
  %5200 = extractelement <8 x i64> %5198, i32 %4822
  %5201 = zext i32 %4822 to i64
  %5202 = mul i64 %5201, 8
  %5203 = sub i64 %5200, %5202
  %5204 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %5205 = select i1 %5204, i64 %5203, i64 0
  %private.contiguous.address833 = getelementptr i8, ptr %5199, i64 %5205
  %private.contiguous.preserve834 = load <8 x i64>, ptr %private.contiguous.address833, align 8
  %5206 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 8), <8 x i64> %private.contiguous.preserve834
  store <8 x i64> %5206, ptr %private.contiguous.address833, align 8
  %5207 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5208 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5209 = add <8 x i64> %5208, splat (i64 1600)
  %5210 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5207, 0
  %5211 = insertvalue { <8 x ptr>, <8 x i64> } %5210, <8 x i64> %5209, 1
  %5212 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5213 = extractvalue { <8 x ptr>, <8 x i64> } %5211, 1
  %5214 = extractelement <8 x ptr> %5212, i32 0
  %5215 = extractelement <8 x i64> %5213, i32 %4822
  %5216 = zext i32 %4822 to i64
  %5217 = mul i64 %5216, 8
  %5218 = sub i64 %5215, %5217
  %5219 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %5220 = select i1 %5219, i64 %5218, i64 0
  %private.contiguous.address835 = getelementptr i8, ptr %5214, i64 %5220
  %private.contiguous.preserve836 = load <8 x i64>, ptr %private.contiguous.address835, align 8
  %5221 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 9), <8 x i64> %private.contiguous.preserve836
  store <8 x i64> %5221, ptr %private.contiguous.address835, align 8
  %5222 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5223 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5224 = add <8 x i64> %5223, splat (i64 1664)
  %5225 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5222, 0
  %5226 = insertvalue { <8 x ptr>, <8 x i64> } %5225, <8 x i64> %5224, 1
  %5227 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5228 = extractvalue { <8 x ptr>, <8 x i64> } %5226, 1
  %5229 = extractelement <8 x ptr> %5227, i32 0
  %5230 = extractelement <8 x i64> %5228, i32 %4822
  %5231 = zext i32 %4822 to i64
  %5232 = mul i64 %5231, 8
  %5233 = sub i64 %5230, %5232
  %5234 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %5235 = select i1 %5234, i64 %5233, i64 0
  %private.contiguous.address837 = getelementptr i8, ptr %5229, i64 %5235
  %private.contiguous.preserve838 = load <8 x i64>, ptr %private.contiguous.address837, align 8
  %5236 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 10), <8 x i64> %private.contiguous.preserve838
  store <8 x i64> %5236, ptr %private.contiguous.address837, align 8
  %5237 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5238 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5239 = add <8 x i64> %5238, splat (i64 1728)
  %5240 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5237, 0
  %5241 = insertvalue { <8 x ptr>, <8 x i64> } %5240, <8 x i64> %5239, 1
  %5242 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5243 = extractvalue { <8 x ptr>, <8 x i64> } %5241, 1
  %5244 = extractelement <8 x ptr> %5242, i32 0
  %5245 = extractelement <8 x i64> %5243, i32 %4822
  %5246 = zext i32 %4822 to i64
  %5247 = mul i64 %5246, 8
  %5248 = sub i64 %5245, %5247
  %5249 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %5250 = select i1 %5249, i64 %5248, i64 0
  %private.contiguous.address839 = getelementptr i8, ptr %5244, i64 %5250
  %private.contiguous.preserve840 = load <8 x i64>, ptr %private.contiguous.address839, align 8
  %5251 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 11), <8 x i64> %private.contiguous.preserve840
  store <8 x i64> %5251, ptr %private.contiguous.address839, align 8
  %5252 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5253 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5254 = add <8 x i64> %5253, splat (i64 1792)
  %5255 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5252, 0
  %5256 = insertvalue { <8 x ptr>, <8 x i64> } %5255, <8 x i64> %5254, 1
  %5257 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5258 = extractvalue { <8 x ptr>, <8 x i64> } %5256, 1
  %5259 = extractelement <8 x ptr> %5257, i32 0
  %5260 = extractelement <8 x i64> %5258, i32 %4822
  %5261 = zext i32 %4822 to i64
  %5262 = mul i64 %5261, 8
  %5263 = sub i64 %5260, %5262
  %5264 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %5265 = select i1 %5264, i64 %5263, i64 0
  %private.contiguous.address841 = getelementptr i8, ptr %5259, i64 %5265
  %private.contiguous.preserve842 = load <8 x i64>, ptr %private.contiguous.address841, align 8
  %5266 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 12), <8 x i64> %private.contiguous.preserve842
  store <8 x i64> %5266, ptr %private.contiguous.address841, align 8
  %5267 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5268 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5269 = add <8 x i64> %5268, splat (i64 1856)
  %5270 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5267, 0
  %5271 = insertvalue { <8 x ptr>, <8 x i64> } %5270, <8 x i64> %5269, 1
  %5272 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5273 = extractvalue { <8 x ptr>, <8 x i64> } %5271, 1
  %5274 = extractelement <8 x ptr> %5272, i32 0
  %5275 = extractelement <8 x i64> %5273, i32 %4822
  %5276 = zext i32 %4822 to i64
  %5277 = mul i64 %5276, 8
  %5278 = sub i64 %5275, %5277
  %5279 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %5280 = select i1 %5279, i64 %5278, i64 0
  %private.contiguous.address843 = getelementptr i8, ptr %5274, i64 %5280
  %private.contiguous.preserve844 = load <8 x i64>, ptr %private.contiguous.address843, align 8
  %5281 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 13), <8 x i64> %private.contiguous.preserve844
  store <8 x i64> %5281, ptr %private.contiguous.address843, align 8
  %5282 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5283 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5284 = add <8 x i64> %5283, splat (i64 1920)
  %5285 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5282, 0
  %5286 = insertvalue { <8 x ptr>, <8 x i64> } %5285, <8 x i64> %5284, 1
  %5287 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5288 = extractvalue { <8 x ptr>, <8 x i64> } %5286, 1
  %5289 = extractelement <8 x ptr> %5287, i32 0
  %5290 = extractelement <8 x i64> %5288, i32 %4822
  %5291 = zext i32 %4822 to i64
  %5292 = mul i64 %5291, 8
  %5293 = sub i64 %5290, %5292
  %5294 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %5295 = select i1 %5294, i64 %5293, i64 0
  %private.contiguous.address845 = getelementptr i8, ptr %5289, i64 %5295
  %private.contiguous.preserve846 = load <8 x i64>, ptr %private.contiguous.address845, align 8
  %5296 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 14), <8 x i64> %private.contiguous.preserve846
  store <8 x i64> %5296, ptr %private.contiguous.address845, align 8
  %5297 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5298 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5299 = add <8 x i64> %5298, splat (i64 1984)
  %5300 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5297, 0
  %5301 = insertvalue { <8 x ptr>, <8 x i64> } %5300, <8 x i64> %5299, 1
  %5302 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5303 = extractvalue { <8 x ptr>, <8 x i64> } %5301, 1
  %5304 = extractelement <8 x ptr> %5302, i32 0
  %5305 = extractelement <8 x i64> %5303, i32 %4822
  %5306 = zext i32 %4822 to i64
  %5307 = mul i64 %5306, 8
  %5308 = sub i64 %5305, %5307
  %5309 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  %5310 = select i1 %5309, i64 %5308, i64 0
  %private.contiguous.address847 = getelementptr i8, ptr %5304, i64 %5310
  %private.contiguous.preserve848 = load <8 x i64>, ptr %private.contiguous.address847, align 8
  %5311 = select <8 x i1> %convergence.cascade.result784, <8 x i64> splat (i64 15), <8 x i64> %private.contiguous.preserve848
  store <8 x i64> %5311, ptr %private.contiguous.address847, align 8
  %5312 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill90, align 64
  %5313 = extractvalue { <8 x ptr>, <8 x i64> } %31, 0
  %5314 = extractvalue { <8 x ptr>, <8 x i64> } %5312, 0
  %5315 = select <8 x i1> %convergence.cascade.result784, <8 x ptr> %5313, <8 x ptr> %5314
  %5316 = extractvalue { <8 x ptr>, <8 x i64> } %31, 1
  %5317 = extractvalue { <8 x ptr>, <8 x i64> } %5312, 1
  %5318 = select <8 x i1> %convergence.cascade.result784, <8 x i64> %5316, <8 x i64> %5317
  %5319 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5315, 0
  %5320 = insertvalue { <8 x ptr>, <8 x i64> } %5319, <8 x i64> %5318, 1
  store volatile { <8 x ptr>, <8 x i64> } %5320, ptr %tile_snapshot.spill90, align 64
  %5321 = load <8 x i64>, ptr %.slot91, align 64
  %5322 = select <8 x i1> %convergence.cascade.result784, <8 x i64> zeroinitializer, <8 x i64> %5321
  store <8 x i64> %5322, ptr %.slot91, align 64
  store <8 x i1> %convergence.cascade.result784, ptr %current.mask, align 1
  %5323 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result784)
  br i1 %5323, label %schedule.38, label %scheduler.loop

varying.divergent850:                             ; preds = %schedule.38
  %5324 = load i32, ptr %current.token, align 4
  %5325 = icmp ne i32 %5324, 0
  %5326 = sub i32 %5324, 1
  %5327 = select i1 %5325, i32 %5326, i32 0
  %5328 = load i8, ptr %frame.active, align 1
  %5329 = trunc i32 %5327 to i8
  %5330 = shl i8 1, %5329
  %5331 = and i8 %5328, %5330
  %5332 = icmp ne i8 %5331, 0
  %5333 = load <8 x i32>, ptr %frame.static.id, align 32
  %5334 = extractelement <8 x i32> %5333, i32 %5327
  %5335 = icmp eq i32 %5334, 14
  %5336 = and i1 %5332, %5335
  %5337 = and i1 %5325, %5336
  %5338 = xor i1 %5337, true
  %5339 = and i1 true, %5338
  %5340 = xor i8 %5328, -1
  %5341 = icmp ne i8 %5340, 0
  %5342 = xor i1 %5341, true
  %5343 = and i1 %5339, %5342
  br i1 %5343, label %convergence.overflow.trap852, label %convergence.overflow.resume853

varying.coherent851:                              ; preds = %schedule.38
  br i1 %848, label %varying.coherent.true856, label %varying.coherent.false857

convergence.overflow.trap852:                     ; preds = %varying.divergent850
  call void @llvm.trap()
  unreachable

convergence.overflow.resume853:                   ; preds = %varying.divergent850
  %5344 = call i8 @llvm.cttz.i8(i8 %5340, i1 false)
  %5345 = zext i8 %5344 to i32
  %5346 = select i1 %5341, i32 %5345, i32 0
  %5347 = trunc i32 %5346 to i8
  %5348 = shl i8 1, %5347
  %5349 = or i8 %5328, %5348
  %5350 = select i1 %5339, i8 %5349, i8 %5328
  store i8 %5350, ptr %frame.active, align 1
  %5351 = load <8 x i32>, ptr %frame.static.id, align 32
  %5352 = extractelement <8 x i32> %5351, i32 %5346
  %5353 = select i1 %5339, i32 14, i32 %5352
  %5354 = load <8 x i32>, ptr %frame.static.id, align 32
  %5355 = insertelement <8 x i32> %5354, i32 %5353, i32 %5346
  store <8 x i32> %5355, ptr %frame.static.id, align 32
  %5356 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5357 = extractelement <8 x i32> %5356, i32 %5346
  %5358 = select i1 %5339, i32 %5324, i32 %5357
  %5359 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5360 = insertelement <8 x i32> %5359, i32 %5358, i32 %5346
  store <8 x i32> %5360, ptr %frame.parent.token, align 32
  %5361 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5346
  %5362 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5346
  %5363 = load <8 x i1>, ptr %5361, align 1
  %5364 = load <8 x i1>, ptr %5362, align 1
  %5365 = select i1 %5339, <8 x i1> %838, <8 x i1> %5363
  store <8 x i1> %5365, ptr %5361, align 1
  %5366 = select i1 %5339, <8 x i1> zeroinitializer, <8 x i1> %5364
  store <8 x i1> %5366, ptr %5362, align 1
  %5367 = add i32 %5346, 1
  %5368 = select i1 %5337, i32 %5324, i32 %5367
  %5369 = select i1 true, i32 %5368, i32 %5324
  store i32 %5369, ptr %current.token, align 4
  %5370 = load i32, ptr %current.token, align 4
  %5371 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %845)
  %5372 = load i32, ptr %ready.count, align 4
  %5373 = icmp uge i32 %5372, 8
  %5374 = and i1 %5371, %5373
  br i1 %5374, label %ready.overflow.trap854, label %ready.overflow.resume855

ready.overflow.trap854:                           ; preds = %convergence.overflow.resume853
  call void @llvm.trap()
  unreachable

ready.overflow.resume855:                         ; preds = %convergence.overflow.resume853
  %5375 = select i1 %5371, i32 %5372, i32 0
  %5376 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5375
  %5377 = load <8 x i1>, ptr %5376, align 1
  %5378 = select i1 %5371, <8 x i1> %845, <8 x i1> %5377
  store <8 x i1> %5378, ptr %5376, align 1
  %5379 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5375
  %5380 = load i32, ptr %5379, align 4
  %5381 = select i1 %5371, i32 39, i32 %5380
  store i32 %5381, ptr %5379, align 4
  %5382 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5375
  %5383 = load i32, ptr %5382, align 4
  %5384 = select i1 %5371, i32 %5370, i32 %5383
  store i32 %5384, ptr %5382, align 4
  %5385 = add i32 %5372, 1
  %5386 = select i1 %5371, i32 %5385, i32 %5372
  store i32 %5386, ptr %ready.count, align 4
  %5387 = load <8 x i1>, ptr %runnable.mask, align 1
  %5388 = or <8 x i1> %5387, %845
  store <8 x i1> %5388, ptr %runnable.mask, align 1
  store <8 x i1> %847, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true856:                         ; preds = %varying.coherent851
  store <8 x i1> %838, ptr %current.mask, align 1
  %5389 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %838)
  br i1 %5389, label %schedule.39, label %scheduler.loop

varying.coherent.false857:                        ; preds = %varying.coherent851
  store <8 x i1> %838, ptr %current.mask, align 1
  %5390 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %838)
  br i1 %5390, label %schedule.42, label %scheduler.loop

varying.divergent861:                             ; preds = %schedule.39
  %5391 = load i32, ptr %current.token, align 4
  %5392 = icmp ne i32 %5391, 0
  %5393 = sub i32 %5391, 1
  %5394 = select i1 %5392, i32 %5393, i32 0
  %5395 = load i8, ptr %frame.active, align 1
  %5396 = trunc i32 %5394 to i8
  %5397 = shl i8 1, %5396
  %5398 = and i8 %5395, %5397
  %5399 = icmp ne i8 %5398, 0
  %5400 = load <8 x i32>, ptr %frame.static.id, align 32
  %5401 = extractelement <8 x i32> %5400, i32 %5394
  %5402 = icmp eq i32 %5401, 15
  %5403 = and i1 %5399, %5402
  %5404 = and i1 %5392, %5403
  %5405 = xor i1 %5404, true
  %5406 = and i1 true, %5405
  %5407 = xor i8 %5395, -1
  %5408 = icmp ne i8 %5407, 0
  %5409 = xor i1 %5408, true
  %5410 = and i1 %5406, %5409
  br i1 %5410, label %convergence.overflow.trap863, label %convergence.overflow.resume864

varying.coherent862:                              ; preds = %schedule.39
  br i1 %890, label %varying.coherent.true867, label %varying.coherent.false868

convergence.overflow.trap863:                     ; preds = %varying.divergent861
  call void @llvm.trap()
  unreachable

convergence.overflow.resume864:                   ; preds = %varying.divergent861
  %5411 = call i8 @llvm.cttz.i8(i8 %5407, i1 false)
  %5412 = zext i8 %5411 to i32
  %5413 = select i1 %5408, i32 %5412, i32 0
  %5414 = trunc i32 %5413 to i8
  %5415 = shl i8 1, %5414
  %5416 = or i8 %5395, %5415
  %5417 = select i1 %5406, i8 %5416, i8 %5395
  store i8 %5417, ptr %frame.active, align 1
  %5418 = load <8 x i32>, ptr %frame.static.id, align 32
  %5419 = extractelement <8 x i32> %5418, i32 %5413
  %5420 = select i1 %5406, i32 15, i32 %5419
  %5421 = load <8 x i32>, ptr %frame.static.id, align 32
  %5422 = insertelement <8 x i32> %5421, i32 %5420, i32 %5413
  store <8 x i32> %5422, ptr %frame.static.id, align 32
  %5423 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5424 = extractelement <8 x i32> %5423, i32 %5413
  %5425 = select i1 %5406, i32 %5391, i32 %5424
  %5426 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5427 = insertelement <8 x i32> %5426, i32 %5425, i32 %5413
  store <8 x i32> %5427, ptr %frame.parent.token, align 32
  %5428 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5413
  %5429 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5413
  %5430 = load <8 x i1>, ptr %5428, align 1
  %5431 = load <8 x i1>, ptr %5429, align 1
  %5432 = select i1 %5406, <8 x i1> %851, <8 x i1> %5430
  store <8 x i1> %5432, ptr %5428, align 1
  %5433 = select i1 %5406, <8 x i1> zeroinitializer, <8 x i1> %5431
  store <8 x i1> %5433, ptr %5429, align 1
  %5434 = add i32 %5413, 1
  %5435 = select i1 %5404, i32 %5391, i32 %5434
  %5436 = select i1 true, i32 %5435, i32 %5391
  store i32 %5436, ptr %current.token, align 4
  %5437 = load <8 x float>, ptr %.slot94, align 32
  %5438 = select <8 x i1> %889, <8 x float> zeroinitializer, <8 x float> %5437
  store <8 x float> %5438, ptr %.slot94, align 32
  %5439 = load i32, ptr %current.token, align 4
  %5440 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %887)
  %5441 = load i32, ptr %ready.count, align 4
  %5442 = icmp uge i32 %5441, 8
  %5443 = and i1 %5440, %5442
  br i1 %5443, label %ready.overflow.trap865, label %ready.overflow.resume866

ready.overflow.trap865:                           ; preds = %convergence.overflow.resume864
  call void @llvm.trap()
  unreachable

ready.overflow.resume866:                         ; preds = %convergence.overflow.resume864
  %5444 = select i1 %5440, i32 %5441, i32 0
  %5445 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5444
  %5446 = load <8 x i1>, ptr %5445, align 1
  %5447 = select i1 %5440, <8 x i1> %887, <8 x i1> %5446
  store <8 x i1> %5447, ptr %5445, align 1
  %5448 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5444
  %5449 = load i32, ptr %5448, align 4
  %5450 = select i1 %5440, i32 40, i32 %5449
  store i32 %5450, ptr %5448, align 4
  %5451 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5444
  %5452 = load i32, ptr %5451, align 4
  %5453 = select i1 %5440, i32 %5439, i32 %5452
  store i32 %5453, ptr %5451, align 4
  %5454 = add i32 %5441, 1
  %5455 = select i1 %5440, i32 %5454, i32 %5441
  store i32 %5455, ptr %ready.count, align 4
  %5456 = load <8 x i1>, ptr %runnable.mask, align 1
  %5457 = or <8 x i1> %5456, %887
  store <8 x i1> %5457, ptr %runnable.mask, align 1
  store <8 x i1> %889, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true867:                         ; preds = %varying.coherent862
  store <8 x i1> %851, ptr %current.mask, align 1
  %5458 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %851)
  br i1 %5458, label %schedule.40, label %scheduler.loop

varying.coherent.false868:                        ; preds = %varying.coherent862
  %5459 = load <8 x float>, ptr %.slot94, align 32
  %5460 = select <8 x i1> %851, <8 x float> zeroinitializer, <8 x float> %5459
  store <8 x float> %5460, ptr %.slot94, align 32
  store <8 x i1> %851, ptr %current.mask, align 1
  %5461 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %851)
  br i1 %5461, label %schedule.41, label %scheduler.loop

convergence.cascade871:                           ; preds = %convergence.cascade871, %schedule.41
  %convergence.cascade.flow875 = phi <8 x i1> [ %912, %schedule.41 ], [ %5504, %convergence.cascade871 ]
  %convergence.cascade.depth876 = phi i32 [ 0, %schedule.41 ], [ %5505, %convergence.cascade871 ]
  %5462 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow875)
  %5463 = load i32, ptr %current.token, align 4
  %5464 = icmp ne i32 %5463, 0
  %5465 = and i1 %5462, %5464
  %5466 = sub i32 %5463, 1
  %5467 = select i1 %5465, i32 %5466, i32 0
  %5468 = load i8, ptr %frame.active, align 1
  %5469 = trunc i32 %5467 to i8
  %5470 = shl i8 1, %5469
  %5471 = and i8 %5468, %5470
  %5472 = icmp ne i8 %5471, 0
  %5473 = load <8 x i32>, ptr %frame.static.id, align 32
  %5474 = extractelement <8 x i32> %5473, i32 %5467
  %convergence.target.pointer877 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %5474
  %convergence.dynamic.target878 = load i32, ptr %convergence.target.pointer877, align 4
  %5475 = icmp eq i32 %convergence.dynamic.target878, 41
  %5476 = and i1 %5472, %5475
  %5477 = and i1 %5465, %5476
  %5478 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5467
  %5479 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5467
  %5480 = load <8 x i1>, ptr %5478, align 1
  %5481 = load <8 x i1>, ptr %5479, align 1
  %5482 = or <8 x i1> %5481, %convergence.cascade.flow875
  %5483 = load <8 x i1>, ptr %live.mask, align 1
  %5484 = and <8 x i1> %5480, %5483
  %5485 = icmp eq <8 x i1> %5482, %5484
  %5486 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5485)
  %5487 = and i1 %5477, %5486
  %5488 = select i1 %5487, <8 x i1> zeroinitializer, <8 x i1> %5482
  %5489 = select i1 %5477, <8 x i1> %5488, <8 x i1> %5481
  store <8 x i1> %5489, ptr %5479, align 1
  %5490 = select i1 %5487, <8 x i1> zeroinitializer, <8 x i1> %5480
  store <8 x i1> %5490, ptr %5478, align 1
  %5491 = trunc i32 %5467 to i8
  %5492 = shl i8 1, %5491
  %5493 = xor i8 %5492, -1
  %5494 = and i8 %5468, %5493
  %5495 = select i1 %5487, i8 %5494, i8 %5468
  store i8 %5495, ptr %frame.active, align 1
  %.splatinsert879 = insertelement <8 x i1> poison, i1 %5477, i64 0
  %.splat880 = shufflevector <8 x i1> %.splatinsert879, <8 x i1> poison, <8 x i32> zeroinitializer
  %5496 = and <8 x i1> %convergence.cascade.flow875, %.splat880
  %5497 = load <8 x i1>, ptr %runnable.mask, align 1
  %5498 = xor <8 x i1> %5496, splat (i1 true)
  %5499 = and <8 x i1> %5497, %5498
  store <8 x i1> %5499, ptr %runnable.mask, align 1
  %.splatinsert881 = insertelement <8 x i1> poison, i1 %5487, i64 0
  %.splat882 = shufflevector <8 x i1> %.splatinsert881, <8 x i1> poison, <8 x i32> zeroinitializer
  %5500 = select <8 x i1> %.splat882, <8 x i1> %5482, <8 x i1> zeroinitializer
  %5501 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5502 = extractelement <8 x i32> %5501, i32 %5467
  %5503 = select i1 %5487, i32 %5502, i32 %5463
  store i32 %5503, ptr %current.token, align 4
  %.splatinsert883 = insertelement <8 x i1> poison, i1 %5477, i64 0
  %.splat884 = shufflevector <8 x i1> %.splatinsert883, <8 x i1> poison, <8 x i32> zeroinitializer
  %5504 = select <8 x i1> %.splat884, <8 x i1> %5500, <8 x i1> %convergence.cascade.flow875
  %5505 = add i32 %convergence.cascade.depth876, 1
  %5506 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5504)
  %5507 = icmp ult i32 %5505, 8
  %5508 = and i1 %5506, %5507
  %5509 = and i1 %5477, %5508
  %convergence.parent.token885 = load i32, ptr %current.token, align 4
  %convergence.parent.present886 = icmp ne i32 %convergence.parent.token885, 0
  %5510 = and i1 %5509, %convergence.parent.present886
  br i1 %5510, label %convergence.cascade871, label %convergence.cascade.exit872

convergence.cascade.exit872:                      ; preds = %convergence.cascade871, %schedule.41
  %convergence.cascade.result887 = phi <8 x i1> [ %912, %schedule.41 ], [ %5504, %convergence.cascade871 ]
  %5511 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result887)
  br i1 %5511, label %convergence.target.41.ready, label %scheduler.loop

convergence.target.41.ready:                      ; preds = %convergence.cascade.exit872
  %5512 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result887)
  %5513 = bitcast <8 x i1> %convergence.cascade.result887 to i8
  %5514 = call i8 @llvm.cttz.i8(i8 %5513, i1 false)
  %5515 = zext i8 %5514 to i32
  %5516 = select i1 %5512, i32 %5515, i32 0
  %.spill.load888 = load float, ptr %.spill49, align 4
  %.splatinsert889 = insertelement <8 x float> poison, float %.spill.load888, i64 0
  %.splat890 = shufflevector <8 x float> %.splatinsert889, <8 x float> poison, <8 x i32> zeroinitializer
  %.state891 = load <8 x float>, ptr %.slot94, align 32
  %.spill.load892 = load volatile <8 x i1>, ptr %.spill92, align 1
  %5517 = select <8 x i1> %.spill.load892, <8 x float> %.state891, <8 x float> %.splat890
  %tile_snapshot.spill.load893 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill90, align 64
  %5518 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load893, 0
  %5519 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load893, 1
  %.state894 = load <8 x i64>, ptr %.slot91, align 64
  %5520 = mul <8 x i64> %.state894, splat (i64 32)
  %5521 = add <8 x i64> %5519, %5520
  %5522 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5518, 0
  %5523 = insertvalue { <8 x ptr>, <8 x i64> } %5522, <8 x i64> %5521, 1
  %5524 = extractvalue { <8 x ptr>, <8 x i64> } %5523, 0
  %5525 = extractvalue { <8 x ptr>, <8 x i64> } %5523, 1
  %5526 = getelementptr i8, <8 x ptr> %5524, <8 x i64> %5525
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5517, <8 x ptr> %5526, i32 1, <8 x i1> %convergence.cascade.result887)
  %.state895 = load <8 x i64>, ptr %.slot91, align 64
  %5527 = add <8 x i64> %.state895, splat (i64 1)
  %5528 = load <8 x i64>, ptr %.slot91, align 64
  %5529 = select <8 x i1> %convergence.cascade.result887, <8 x i64> %5527, <8 x i64> %5528
  store <8 x i64> %5529, ptr %.slot91, align 64
  store <8 x i1> %convergence.cascade.result887, ptr %current.mask, align 1
  %5530 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result887)
  br i1 %5530, label %schedule.38, label %scheduler.loop

convergence.cascade896:                           ; preds = %convergence.cascade896, %schedule.42
  %convergence.cascade.flow900 = phi <8 x i1> [ %913, %schedule.42 ], [ %5573, %convergence.cascade896 ]
  %convergence.cascade.depth901 = phi i32 [ 0, %schedule.42 ], [ %5574, %convergence.cascade896 ]
  %5531 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow900)
  %5532 = load i32, ptr %current.token, align 4
  %5533 = icmp ne i32 %5532, 0
  %5534 = and i1 %5531, %5533
  %5535 = sub i32 %5532, 1
  %5536 = select i1 %5534, i32 %5535, i32 0
  %5537 = load i8, ptr %frame.active, align 1
  %5538 = trunc i32 %5536 to i8
  %5539 = shl i8 1, %5538
  %5540 = and i8 %5537, %5539
  %5541 = icmp ne i8 %5540, 0
  %5542 = load <8 x i32>, ptr %frame.static.id, align 32
  %5543 = extractelement <8 x i32> %5542, i32 %5536
  %convergence.target.pointer902 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %5543
  %convergence.dynamic.target903 = load i32, ptr %convergence.target.pointer902, align 4
  %5544 = icmp eq i32 %convergence.dynamic.target903, 42
  %5545 = and i1 %5541, %5544
  %5546 = and i1 %5534, %5545
  %5547 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5536
  %5548 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5536
  %5549 = load <8 x i1>, ptr %5547, align 1
  %5550 = load <8 x i1>, ptr %5548, align 1
  %5551 = or <8 x i1> %5550, %convergence.cascade.flow900
  %5552 = load <8 x i1>, ptr %live.mask, align 1
  %5553 = and <8 x i1> %5549, %5552
  %5554 = icmp eq <8 x i1> %5551, %5553
  %5555 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5554)
  %5556 = and i1 %5546, %5555
  %5557 = select i1 %5556, <8 x i1> zeroinitializer, <8 x i1> %5551
  %5558 = select i1 %5546, <8 x i1> %5557, <8 x i1> %5550
  store <8 x i1> %5558, ptr %5548, align 1
  %5559 = select i1 %5556, <8 x i1> zeroinitializer, <8 x i1> %5549
  store <8 x i1> %5559, ptr %5547, align 1
  %5560 = trunc i32 %5536 to i8
  %5561 = shl i8 1, %5560
  %5562 = xor i8 %5561, -1
  %5563 = and i8 %5537, %5562
  %5564 = select i1 %5556, i8 %5563, i8 %5537
  store i8 %5564, ptr %frame.active, align 1
  %.splatinsert904 = insertelement <8 x i1> poison, i1 %5546, i64 0
  %.splat905 = shufflevector <8 x i1> %.splatinsert904, <8 x i1> poison, <8 x i32> zeroinitializer
  %5565 = and <8 x i1> %convergence.cascade.flow900, %.splat905
  %5566 = load <8 x i1>, ptr %runnable.mask, align 1
  %5567 = xor <8 x i1> %5565, splat (i1 true)
  %5568 = and <8 x i1> %5566, %5567
  store <8 x i1> %5568, ptr %runnable.mask, align 1
  %.splatinsert906 = insertelement <8 x i1> poison, i1 %5556, i64 0
  %.splat907 = shufflevector <8 x i1> %.splatinsert906, <8 x i1> poison, <8 x i32> zeroinitializer
  %5569 = select <8 x i1> %.splat907, <8 x i1> %5551, <8 x i1> zeroinitializer
  %5570 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5571 = extractelement <8 x i32> %5570, i32 %5536
  %5572 = select i1 %5556, i32 %5571, i32 %5532
  store i32 %5572, ptr %current.token, align 4
  %.splatinsert908 = insertelement <8 x i1> poison, i1 %5546, i64 0
  %.splat909 = shufflevector <8 x i1> %.splatinsert908, <8 x i1> poison, <8 x i32> zeroinitializer
  %5573 = select <8 x i1> %.splat909, <8 x i1> %5569, <8 x i1> %convergence.cascade.flow900
  %5574 = add i32 %convergence.cascade.depth901, 1
  %5575 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5573)
  %5576 = icmp ult i32 %5574, 8
  %5577 = and i1 %5575, %5576
  %5578 = and i1 %5546, %5577
  %convergence.parent.token910 = load i32, ptr %current.token, align 4
  %convergence.parent.present911 = icmp ne i32 %convergence.parent.token910, 0
  %5579 = and i1 %5578, %convergence.parent.present911
  br i1 %5579, label %convergence.cascade896, label %convergence.cascade.exit897

convergence.cascade.exit897:                      ; preds = %convergence.cascade896, %schedule.42
  %convergence.cascade.result912 = phi <8 x i1> [ %913, %schedule.42 ], [ %5573, %convergence.cascade896 ]
  %5580 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result912)
  br i1 %5580, label %convergence.target.42.ready, label %scheduler.loop

convergence.target.42.ready:                      ; preds = %convergence.cascade.exit897
  %5581 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result912)
  %5582 = bitcast <8 x i1> %convergence.cascade.result912 to i8
  %5583 = call i8 @llvm.cttz.i8(i8 %5582, i1 false)
  %5584 = zext i8 %5583 to i32
  %5585 = select i1 %5581, i32 %5584, i32 0
  %5586 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %5587 = extractvalue { <8 x ptr>, <8 x i64> } %33, 0
  %5588 = extractvalue { <8 x ptr>, <8 x i64> } %5586, 0
  %5589 = select <8 x i1> %convergence.cascade.result912, <8 x ptr> %5587, <8 x ptr> %5588
  %5590 = extractvalue { <8 x ptr>, <8 x i64> } %33, 1
  %5591 = extractvalue { <8 x ptr>, <8 x i64> } %5586, 1
  %5592 = select <8 x i1> %convergence.cascade.result912, <8 x i64> %5590, <8 x i64> %5591
  %5593 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5589, 0
  %5594 = insertvalue { <8 x ptr>, <8 x i64> } %5593, <8 x i64> %5592, 1
  store { <8 x ptr>, <8 x i64> } %5594, ptr %tile_snapshot.spill95, align 64
  %5595 = load <8 x i64>, ptr %.slot96, align 64
  %5596 = select <8 x i1> %convergence.cascade.result912, <8 x i64> zeroinitializer, <8 x i64> %5595
  store <8 x i64> %5596, ptr %.slot96, align 64
  store <8 x i1> %convergence.cascade.result912, ptr %current.mask, align 1
  %5597 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result912)
  br i1 %5597, label %schedule.43, label %scheduler.loop

varying.divergent914:                             ; preds = %schedule.43
  %5598 = load i32, ptr %current.token, align 4
  %5599 = icmp ne i32 %5598, 0
  %5600 = sub i32 %5598, 1
  %5601 = select i1 %5599, i32 %5600, i32 0
  %5602 = load i8, ptr %frame.active, align 1
  %5603 = trunc i32 %5601 to i8
  %5604 = shl i8 1, %5603
  %5605 = and i8 %5602, %5604
  %5606 = icmp ne i8 %5605, 0
  %5607 = load <8 x i32>, ptr %frame.static.id, align 32
  %5608 = extractelement <8 x i32> %5607, i32 %5601
  %5609 = icmp eq i32 %5608, 16
  %5610 = and i1 %5606, %5609
  %5611 = and i1 %5599, %5610
  %5612 = xor i1 %5611, true
  %5613 = and i1 true, %5612
  %5614 = xor i8 %5602, -1
  %5615 = icmp ne i8 %5614, 0
  %5616 = xor i1 %5615, true
  %5617 = and i1 %5613, %5616
  br i1 %5617, label %convergence.overflow.trap916, label %convergence.overflow.resume917

varying.coherent915:                              ; preds = %schedule.43
  br i1 %924, label %varying.coherent.true920, label %varying.coherent.false921

convergence.overflow.trap916:                     ; preds = %varying.divergent914
  call void @llvm.trap()
  unreachable

convergence.overflow.resume917:                   ; preds = %varying.divergent914
  %5618 = call i8 @llvm.cttz.i8(i8 %5614, i1 false)
  %5619 = zext i8 %5618 to i32
  %5620 = select i1 %5615, i32 %5619, i32 0
  %5621 = trunc i32 %5620 to i8
  %5622 = shl i8 1, %5621
  %5623 = or i8 %5602, %5622
  %5624 = select i1 %5613, i8 %5623, i8 %5602
  store i8 %5624, ptr %frame.active, align 1
  %5625 = load <8 x i32>, ptr %frame.static.id, align 32
  %5626 = extractelement <8 x i32> %5625, i32 %5620
  %5627 = select i1 %5613, i32 16, i32 %5626
  %5628 = load <8 x i32>, ptr %frame.static.id, align 32
  %5629 = insertelement <8 x i32> %5628, i32 %5627, i32 %5620
  store <8 x i32> %5629, ptr %frame.static.id, align 32
  %5630 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5631 = extractelement <8 x i32> %5630, i32 %5620
  %5632 = select i1 %5613, i32 %5598, i32 %5631
  %5633 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5634 = insertelement <8 x i32> %5633, i32 %5632, i32 %5620
  store <8 x i32> %5634, ptr %frame.parent.token, align 32
  %5635 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5620
  %5636 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5620
  %5637 = load <8 x i1>, ptr %5635, align 1
  %5638 = load <8 x i1>, ptr %5636, align 1
  %5639 = select i1 %5613, <8 x i1> %914, <8 x i1> %5637
  store <8 x i1> %5639, ptr %5635, align 1
  %5640 = select i1 %5613, <8 x i1> zeroinitializer, <8 x i1> %5638
  store <8 x i1> %5640, ptr %5636, align 1
  %5641 = add i32 %5620, 1
  %5642 = select i1 %5611, i32 %5598, i32 %5641
  %5643 = select i1 true, i32 %5642, i32 %5598
  store i32 %5643, ptr %current.token, align 4
  %5644 = load i32, ptr %current.token, align 4
  %5645 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %921)
  %5646 = load i32, ptr %ready.count, align 4
  %5647 = icmp uge i32 %5646, 8
  %5648 = and i1 %5645, %5647
  br i1 %5648, label %ready.overflow.trap918, label %ready.overflow.resume919

ready.overflow.trap918:                           ; preds = %convergence.overflow.resume917
  call void @llvm.trap()
  unreachable

ready.overflow.resume919:                         ; preds = %convergence.overflow.resume917
  %5649 = select i1 %5645, i32 %5646, i32 0
  %5650 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5649
  %5651 = load <8 x i1>, ptr %5650, align 1
  %5652 = select i1 %5645, <8 x i1> %921, <8 x i1> %5651
  store <8 x i1> %5652, ptr %5650, align 1
  %5653 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5649
  %5654 = load i32, ptr %5653, align 4
  %5655 = select i1 %5645, i32 44, i32 %5654
  store i32 %5655, ptr %5653, align 4
  %5656 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5649
  %5657 = load i32, ptr %5656, align 4
  %5658 = select i1 %5645, i32 %5644, i32 %5657
  store i32 %5658, ptr %5656, align 4
  %5659 = add i32 %5646, 1
  %5660 = select i1 %5645, i32 %5659, i32 %5646
  store i32 %5660, ptr %ready.count, align 4
  %5661 = load <8 x i1>, ptr %runnable.mask, align 1
  %5662 = or <8 x i1> %5661, %921
  store <8 x i1> %5662, ptr %runnable.mask, align 1
  store <8 x i1> %923, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true920:                         ; preds = %varying.coherent915
  store <8 x i1> %914, ptr %current.mask, align 1
  %5663 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %914)
  br i1 %5663, label %schedule.44, label %scheduler.loop

varying.coherent.false921:                        ; preds = %varying.coherent915
  store <8 x i1> %914, ptr %current.mask, align 1
  %5664 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %914)
  br i1 %5664, label %schedule.45, label %scheduler.loop

convergence.cascade930:                           ; preds = %convergence.cascade930, %schedule.45
  %convergence.cascade.flow934 = phi <8 x i1> [ %996, %schedule.45 ], [ %5707, %convergence.cascade930 ]
  %convergence.cascade.depth935 = phi i32 [ 0, %schedule.45 ], [ %5708, %convergence.cascade930 ]
  %5665 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow934)
  %5666 = load i32, ptr %current.token, align 4
  %5667 = icmp ne i32 %5666, 0
  %5668 = and i1 %5665, %5667
  %5669 = sub i32 %5666, 1
  %5670 = select i1 %5668, i32 %5669, i32 0
  %5671 = load i8, ptr %frame.active, align 1
  %5672 = trunc i32 %5670 to i8
  %5673 = shl i8 1, %5672
  %5674 = and i8 %5671, %5673
  %5675 = icmp ne i8 %5674, 0
  %5676 = load <8 x i32>, ptr %frame.static.id, align 32
  %5677 = extractelement <8 x i32> %5676, i32 %5670
  %convergence.target.pointer936 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %5677
  %convergence.dynamic.target937 = load i32, ptr %convergence.target.pointer936, align 4
  %5678 = icmp eq i32 %convergence.dynamic.target937, 45
  %5679 = and i1 %5675, %5678
  %5680 = and i1 %5668, %5679
  %5681 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5670
  %5682 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5670
  %5683 = load <8 x i1>, ptr %5681, align 1
  %5684 = load <8 x i1>, ptr %5682, align 1
  %5685 = or <8 x i1> %5684, %convergence.cascade.flow934
  %5686 = load <8 x i1>, ptr %live.mask, align 1
  %5687 = and <8 x i1> %5683, %5686
  %5688 = icmp eq <8 x i1> %5685, %5687
  %5689 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5688)
  %5690 = and i1 %5680, %5689
  %5691 = select i1 %5690, <8 x i1> zeroinitializer, <8 x i1> %5685
  %5692 = select i1 %5680, <8 x i1> %5691, <8 x i1> %5684
  store <8 x i1> %5692, ptr %5682, align 1
  %5693 = select i1 %5690, <8 x i1> zeroinitializer, <8 x i1> %5683
  store <8 x i1> %5693, ptr %5681, align 1
  %5694 = trunc i32 %5670 to i8
  %5695 = shl i8 1, %5694
  %5696 = xor i8 %5695, -1
  %5697 = and i8 %5671, %5696
  %5698 = select i1 %5690, i8 %5697, i8 %5671
  store i8 %5698, ptr %frame.active, align 1
  %.splatinsert938 = insertelement <8 x i1> poison, i1 %5680, i64 0
  %.splat939 = shufflevector <8 x i1> %.splatinsert938, <8 x i1> poison, <8 x i32> zeroinitializer
  %5699 = and <8 x i1> %convergence.cascade.flow934, %.splat939
  %5700 = load <8 x i1>, ptr %runnable.mask, align 1
  %5701 = xor <8 x i1> %5699, splat (i1 true)
  %5702 = and <8 x i1> %5700, %5701
  store <8 x i1> %5702, ptr %runnable.mask, align 1
  %.splatinsert940 = insertelement <8 x i1> poison, i1 %5690, i64 0
  %.splat941 = shufflevector <8 x i1> %.splatinsert940, <8 x i1> poison, <8 x i32> zeroinitializer
  %5703 = select <8 x i1> %.splat941, <8 x i1> %5685, <8 x i1> zeroinitializer
  %5704 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5705 = extractelement <8 x i32> %5704, i32 %5670
  %5706 = select i1 %5690, i32 %5705, i32 %5666
  store i32 %5706, ptr %current.token, align 4
  %.splatinsert942 = insertelement <8 x i1> poison, i1 %5680, i64 0
  %.splat943 = shufflevector <8 x i1> %.splatinsert942, <8 x i1> poison, <8 x i32> zeroinitializer
  %5707 = select <8 x i1> %.splat943, <8 x i1> %5703, <8 x i1> %convergence.cascade.flow934
  %5708 = add i32 %convergence.cascade.depth935, 1
  %5709 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5707)
  %5710 = icmp ult i32 %5708, 8
  %5711 = and i1 %5709, %5710
  %5712 = and i1 %5680, %5711
  %convergence.parent.token944 = load i32, ptr %current.token, align 4
  %convergence.parent.present945 = icmp ne i32 %convergence.parent.token944, 0
  %5713 = and i1 %5712, %convergence.parent.present945
  br i1 %5713, label %convergence.cascade930, label %convergence.cascade.exit931

convergence.cascade.exit931:                      ; preds = %convergence.cascade930, %schedule.45
  %convergence.cascade.result946 = phi <8 x i1> [ %996, %schedule.45 ], [ %5707, %convergence.cascade930 ]
  %5714 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result946)
  br i1 %5714, label %convergence.target.45.ready, label %scheduler.loop

convergence.target.45.ready:                      ; preds = %convergence.cascade.exit931
  %5715 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result946)
  %5716 = bitcast <8 x i1> %convergence.cascade.result946 to i8
  %5717 = call i8 @llvm.cttz.i8(i8 %5716, i1 false)
  %5718 = zext i8 %5717 to i32
  %5719 = select i1 %5715, i32 %5718, i32 0
  %5720 = load <8 x i64>, ptr %.slot97, align 64
  %5721 = select <8 x i1> %convergence.cascade.result946, <8 x i64> zeroinitializer, <8 x i64> %5720
  store <8 x i64> %5721, ptr %.slot97, align 64
  store <8 x i1> %convergence.cascade.result946, ptr %current.mask, align 1
  %5722 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result946)
  br i1 %5722, label %schedule.46, label %scheduler.loop

varying.divergent948:                             ; preds = %schedule.46
  %5723 = load i32, ptr %current.token, align 4
  %5724 = icmp ne i32 %5723, 0
  %5725 = sub i32 %5723, 1
  %5726 = select i1 %5724, i32 %5725, i32 0
  %5727 = load i8, ptr %frame.active, align 1
  %5728 = trunc i32 %5726 to i8
  %5729 = shl i8 1, %5728
  %5730 = and i8 %5727, %5729
  %5731 = icmp ne i8 %5730, 0
  %5732 = load <8 x i32>, ptr %frame.static.id, align 32
  %5733 = extractelement <8 x i32> %5732, i32 %5726
  %5734 = icmp eq i32 %5733, 17
  %5735 = and i1 %5731, %5734
  %5736 = and i1 %5724, %5735
  %5737 = xor i1 %5736, true
  %5738 = and i1 true, %5737
  %5739 = xor i8 %5727, -1
  %5740 = icmp ne i8 %5739, 0
  %5741 = xor i1 %5740, true
  %5742 = and i1 %5738, %5741
  br i1 %5742, label %convergence.overflow.trap950, label %convergence.overflow.resume951

varying.coherent949:                              ; preds = %schedule.46
  br i1 %1007, label %varying.coherent.true954, label %varying.coherent.false955

convergence.overflow.trap950:                     ; preds = %varying.divergent948
  call void @llvm.trap()
  unreachable

convergence.overflow.resume951:                   ; preds = %varying.divergent948
  %5743 = call i8 @llvm.cttz.i8(i8 %5739, i1 false)
  %5744 = zext i8 %5743 to i32
  %5745 = select i1 %5740, i32 %5744, i32 0
  %5746 = trunc i32 %5745 to i8
  %5747 = shl i8 1, %5746
  %5748 = or i8 %5727, %5747
  %5749 = select i1 %5738, i8 %5748, i8 %5727
  store i8 %5749, ptr %frame.active, align 1
  %5750 = load <8 x i32>, ptr %frame.static.id, align 32
  %5751 = extractelement <8 x i32> %5750, i32 %5745
  %5752 = select i1 %5738, i32 17, i32 %5751
  %5753 = load <8 x i32>, ptr %frame.static.id, align 32
  %5754 = insertelement <8 x i32> %5753, i32 %5752, i32 %5745
  store <8 x i32> %5754, ptr %frame.static.id, align 32
  %5755 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5756 = extractelement <8 x i32> %5755, i32 %5745
  %5757 = select i1 %5738, i32 %5723, i32 %5756
  %5758 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5759 = insertelement <8 x i32> %5758, i32 %5757, i32 %5745
  store <8 x i32> %5759, ptr %frame.parent.token, align 32
  %5760 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5745
  %5761 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5745
  %5762 = load <8 x i1>, ptr %5760, align 1
  %5763 = load <8 x i1>, ptr %5761, align 1
  %5764 = select i1 %5738, <8 x i1> %997, <8 x i1> %5762
  store <8 x i1> %5764, ptr %5760, align 1
  %5765 = select i1 %5738, <8 x i1> zeroinitializer, <8 x i1> %5763
  store <8 x i1> %5765, ptr %5761, align 1
  %5766 = add i32 %5745, 1
  %5767 = select i1 %5736, i32 %5723, i32 %5766
  %5768 = select i1 true, i32 %5767, i32 %5723
  store i32 %5768, ptr %current.token, align 4
  %5769 = load i32, ptr %current.token, align 4
  %5770 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1004)
  %5771 = load i32, ptr %ready.count, align 4
  %5772 = icmp uge i32 %5771, 8
  %5773 = and i1 %5770, %5772
  br i1 %5773, label %ready.overflow.trap952, label %ready.overflow.resume953

ready.overflow.trap952:                           ; preds = %convergence.overflow.resume951
  call void @llvm.trap()
  unreachable

ready.overflow.resume953:                         ; preds = %convergence.overflow.resume951
  %5774 = select i1 %5770, i32 %5771, i32 0
  %5775 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5774
  %5776 = load <8 x i1>, ptr %5775, align 1
  %5777 = select i1 %5770, <8 x i1> %1004, <8 x i1> %5776
  store <8 x i1> %5777, ptr %5775, align 1
  %5778 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5774
  %5779 = load i32, ptr %5778, align 4
  %5780 = select i1 %5770, i32 47, i32 %5779
  store i32 %5780, ptr %5778, align 4
  %5781 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5774
  %5782 = load i32, ptr %5781, align 4
  %5783 = select i1 %5770, i32 %5769, i32 %5782
  store i32 %5783, ptr %5781, align 4
  %5784 = add i32 %5771, 1
  %5785 = select i1 %5770, i32 %5784, i32 %5771
  store i32 %5785, ptr %ready.count, align 4
  %5786 = load <8 x i1>, ptr %runnable.mask, align 1
  %5787 = or <8 x i1> %5786, %1004
  store <8 x i1> %5787, ptr %runnable.mask, align 1
  store <8 x i1> %1006, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true954:                         ; preds = %varying.coherent949
  store <8 x i1> %997, ptr %current.mask, align 1
  %5788 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %997)
  br i1 %5788, label %schedule.47, label %scheduler.loop

varying.coherent.false955:                        ; preds = %varying.coherent949
  store <8 x i1> %997, ptr %current.mask, align 1
  %5789 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %997)
  br i1 %5789, label %schedule.48, label %scheduler.loop

convergence.cascade963:                           ; preds = %convergence.cascade963, %schedule.48
  %convergence.cascade.flow967 = phi <8 x i1> [ %1044, %schedule.48 ], [ %5832, %convergence.cascade963 ]
  %convergence.cascade.depth968 = phi i32 [ 0, %schedule.48 ], [ %5833, %convergence.cascade963 ]
  %5790 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow967)
  %5791 = load i32, ptr %current.token, align 4
  %5792 = icmp ne i32 %5791, 0
  %5793 = and i1 %5790, %5792
  %5794 = sub i32 %5791, 1
  %5795 = select i1 %5793, i32 %5794, i32 0
  %5796 = load i8, ptr %frame.active, align 1
  %5797 = trunc i32 %5795 to i8
  %5798 = shl i8 1, %5797
  %5799 = and i8 %5796, %5798
  %5800 = icmp ne i8 %5799, 0
  %5801 = load <8 x i32>, ptr %frame.static.id, align 32
  %5802 = extractelement <8 x i32> %5801, i32 %5795
  %convergence.target.pointer969 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %5802
  %convergence.dynamic.target970 = load i32, ptr %convergence.target.pointer969, align 4
  %5803 = icmp eq i32 %convergence.dynamic.target970, 48
  %5804 = and i1 %5800, %5803
  %5805 = and i1 %5793, %5804
  %5806 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5795
  %5807 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5795
  %5808 = load <8 x i1>, ptr %5806, align 1
  %5809 = load <8 x i1>, ptr %5807, align 1
  %5810 = or <8 x i1> %5809, %convergence.cascade.flow967
  %5811 = load <8 x i1>, ptr %live.mask, align 1
  %5812 = and <8 x i1> %5808, %5811
  %5813 = icmp eq <8 x i1> %5810, %5812
  %5814 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5813)
  %5815 = and i1 %5805, %5814
  %5816 = select i1 %5815, <8 x i1> zeroinitializer, <8 x i1> %5810
  %5817 = select i1 %5805, <8 x i1> %5816, <8 x i1> %5809
  store <8 x i1> %5817, ptr %5807, align 1
  %5818 = select i1 %5815, <8 x i1> zeroinitializer, <8 x i1> %5808
  store <8 x i1> %5818, ptr %5806, align 1
  %5819 = trunc i32 %5795 to i8
  %5820 = shl i8 1, %5819
  %5821 = xor i8 %5820, -1
  %5822 = and i8 %5796, %5821
  %5823 = select i1 %5815, i8 %5822, i8 %5796
  store i8 %5823, ptr %frame.active, align 1
  %.splatinsert971 = insertelement <8 x i1> poison, i1 %5805, i64 0
  %.splat972 = shufflevector <8 x i1> %.splatinsert971, <8 x i1> poison, <8 x i32> zeroinitializer
  %5824 = and <8 x i1> %convergence.cascade.flow967, %.splat972
  %5825 = load <8 x i1>, ptr %runnable.mask, align 1
  %5826 = xor <8 x i1> %5824, splat (i1 true)
  %5827 = and <8 x i1> %5825, %5826
  store <8 x i1> %5827, ptr %runnable.mask, align 1
  %.splatinsert973 = insertelement <8 x i1> poison, i1 %5815, i64 0
  %.splat974 = shufflevector <8 x i1> %.splatinsert973, <8 x i1> poison, <8 x i32> zeroinitializer
  %5828 = select <8 x i1> %.splat974, <8 x i1> %5810, <8 x i1> zeroinitializer
  %5829 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5830 = extractelement <8 x i32> %5829, i32 %5795
  %5831 = select i1 %5815, i32 %5830, i32 %5791
  store i32 %5831, ptr %current.token, align 4
  %.splatinsert975 = insertelement <8 x i1> poison, i1 %5805, i64 0
  %.splat976 = shufflevector <8 x i1> %.splatinsert975, <8 x i1> poison, <8 x i32> zeroinitializer
  %5832 = select <8 x i1> %.splat976, <8 x i1> %5828, <8 x i1> %convergence.cascade.flow967
  %5833 = add i32 %convergence.cascade.depth968, 1
  %5834 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5832)
  %5835 = icmp ult i32 %5833, 8
  %5836 = and i1 %5834, %5835
  %5837 = and i1 %5805, %5836
  %convergence.parent.token977 = load i32, ptr %current.token, align 4
  %convergence.parent.present978 = icmp ne i32 %convergence.parent.token977, 0
  %5838 = and i1 %5837, %convergence.parent.present978
  br i1 %5838, label %convergence.cascade963, label %convergence.cascade.exit964

convergence.cascade.exit964:                      ; preds = %convergence.cascade963, %schedule.48
  %convergence.cascade.result979 = phi <8 x i1> [ %1044, %schedule.48 ], [ %5832, %convergence.cascade963 ]
  %5839 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result979)
  br i1 %5839, label %convergence.target.48.ready, label %scheduler.loop

convergence.target.48.ready:                      ; preds = %convergence.cascade.exit964
  %5840 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result979)
  %5841 = bitcast <8 x i1> %convergence.cascade.result979 to i8
  %5842 = call i8 @llvm.cttz.i8(i8 %5841, i1 false)
  %5843 = zext i8 %5842 to i32
  %5844 = select i1 %5840, i32 %5843, i32 0
  %tile_snapshot.spill.load980 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %5845 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load980, 0
  %5846 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load980, 1
  %5847 = add <8 x i64> %5846, splat (i64 992)
  %5848 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5845, 0
  %5849 = insertvalue { <8 x ptr>, <8 x i64> } %5848, <8 x i64> %5847, 1
  %5850 = extractvalue { <8 x ptr>, <8 x i64> } %33, 0
  %5851 = extractvalue { <8 x ptr>, <8 x i64> } %5849, 1
  %5852 = extractelement <8 x ptr> %5850, i32 0
  %5853 = extractelement <8 x i64> %5851, i32 %5844
  %5854 = zext i32 %5844 to i64
  %5855 = mul i64 %5854, 4
  %5856 = sub i64 %5853, %5855
  %5857 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result979)
  %5858 = select i1 %5857, i64 %5856, i64 0
  %private.contiguous.address981 = getelementptr i8, ptr %5852, i64 %5858
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address981, align 4
  %5859 = select <8 x i1> %convergence.cascade.result979, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load982 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %5860 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load982, 0
  %5861 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load982, 1
  %5862 = add <8 x i64> %5861, splat (i64 2016)
  %5863 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5860, 0
  %5864 = insertvalue { <8 x ptr>, <8 x i64> } %5863, <8 x i64> %5862, 1
  %5865 = extractvalue { <8 x ptr>, <8 x i64> } %33, 0
  %5866 = extractvalue { <8 x ptr>, <8 x i64> } %5864, 1
  %5867 = extractelement <8 x ptr> %5865, i32 0
  %5868 = extractelement <8 x i64> %5866, i32 %5844
  %5869 = zext i32 %5844 to i64
  %5870 = mul i64 %5869, 4
  %5871 = sub i64 %5868, %5870
  %5872 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result979)
  %5873 = select i1 %5872, i64 %5871, i64 0
  %private.contiguous.address983 = getelementptr i8, ptr %5867, i64 %5873
  %private.contiguous.load984 = load <8 x float>, ptr %private.contiguous.address983, align 4
  %5874 = select <8 x i1> %convergence.cascade.result979, <8 x float> %private.contiguous.load984, <8 x float> zeroinitializer
  %tile_snapshot.spill.load985 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %5875 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load985, 0
  %5876 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load985, 1
  %5877 = add <8 x i64> %5876, splat (i64 3040)
  %5878 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5875, 0
  %5879 = insertvalue { <8 x ptr>, <8 x i64> } %5878, <8 x i64> %5877, 1
  %5880 = extractvalue { <8 x ptr>, <8 x i64> } %33, 0
  %5881 = extractvalue { <8 x ptr>, <8 x i64> } %5879, 1
  %5882 = extractelement <8 x ptr> %5880, i32 0
  %5883 = extractelement <8 x i64> %5881, i32 %5844
  %5884 = zext i32 %5844 to i64
  %5885 = mul i64 %5884, 4
  %5886 = sub i64 %5883, %5885
  %5887 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result979)
  %5888 = select i1 %5887, i64 %5886, i64 0
  %private.contiguous.address986 = getelementptr i8, ptr %5882, i64 %5888
  %private.contiguous.load987 = load <8 x float>, ptr %private.contiguous.address986, align 4
  %5889 = select <8 x i1> %convergence.cascade.result979, <8 x float> %private.contiguous.load987, <8 x float> zeroinitializer
  %tile_snapshot.spill.load988 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %5890 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load988, 0
  %5891 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load988, 1
  %5892 = add <8 x i64> %5891, splat (i64 4064)
  %5893 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5890, 0
  %5894 = insertvalue { <8 x ptr>, <8 x i64> } %5893, <8 x i64> %5892, 1
  %5895 = extractvalue { <8 x ptr>, <8 x i64> } %33, 0
  %5896 = extractvalue { <8 x ptr>, <8 x i64> } %5894, 1
  %5897 = extractelement <8 x ptr> %5895, i32 0
  %5898 = extractelement <8 x i64> %5896, i32 %5844
  %5899 = zext i32 %5844 to i64
  %5900 = mul i64 %5899, 4
  %5901 = sub i64 %5898, %5900
  %5902 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result979)
  %5903 = select i1 %5902, i64 %5901, i64 0
  %private.contiguous.address989 = getelementptr i8, ptr %5897, i64 %5903
  %private.contiguous.load990 = load <8 x float>, ptr %private.contiguous.address989, align 4
  %5904 = select <8 x i1> %convergence.cascade.result979, <8 x float> %private.contiguous.load990, <8 x float> zeroinitializer
  %.state991 = load <8 x i64>, ptr %.slot, align 64
  %5905 = add <8 x i64> %.state991, splat (i64 1)
  %5906 = load <8 x i64>, ptr %.slot, align 64
  %5907 = select <8 x i1> %convergence.cascade.result979, <8 x i64> %5905, <8 x i64> %5906
  store <8 x i64> %5907, ptr %.slot, align 64
  %5908 = load volatile <8 x float>, ptr %.slot50, align 32
  %5909 = select <8 x i1> %convergence.cascade.result979, <8 x float> %5859, <8 x float> %5908
  store volatile <8 x float> %5909, ptr %.slot50, align 32
  %5910 = load volatile <8 x float>, ptr %.slot51, align 32
  %5911 = select <8 x i1> %convergence.cascade.result979, <8 x float> %5874, <8 x float> %5910
  store volatile <8 x float> %5911, ptr %.slot51, align 32
  %5912 = load volatile <8 x float>, ptr %.slot52, align 32
  %5913 = select <8 x i1> %convergence.cascade.result979, <8 x float> %5889, <8 x float> %5912
  store volatile <8 x float> %5913, ptr %.slot52, align 32
  %5914 = load volatile <8 x float>, ptr %.slot53, align 32
  %5915 = select <8 x i1> %convergence.cascade.result979, <8 x float> %5904, <8 x float> %5914
  store volatile <8 x float> %5915, ptr %.slot53, align 32
  store <8 x i1> %convergence.cascade.result979, ptr %current.mask, align 1
  %5916 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result979)
  br i1 %5916, label %schedule.1, label %scheduler.loop

convergence.cascade992:                           ; preds = %convergence.cascade992, %schedule.49
  %convergence.cascade.flow996 = phi <8 x i1> [ %1045, %schedule.49 ], [ %5959, %convergence.cascade992 ]
  %convergence.cascade.depth997 = phi i32 [ 0, %schedule.49 ], [ %5960, %convergence.cascade992 ]
  %5917 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow996)
  %5918 = load i32, ptr %current.token, align 4
  %5919 = icmp ne i32 %5918, 0
  %5920 = and i1 %5917, %5919
  %5921 = sub i32 %5918, 1
  %5922 = select i1 %5920, i32 %5921, i32 0
  %5923 = load i8, ptr %frame.active, align 1
  %5924 = trunc i32 %5922 to i8
  %5925 = shl i8 1, %5924
  %5926 = and i8 %5923, %5925
  %5927 = icmp ne i8 %5926, 0
  %5928 = load <8 x i32>, ptr %frame.static.id, align 32
  %5929 = extractelement <8 x i32> %5928, i32 %5922
  %convergence.target.pointer998 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %5929
  %convergence.dynamic.target999 = load i32, ptr %convergence.target.pointer998, align 4
  %5930 = icmp eq i32 %convergence.dynamic.target999, 49
  %5931 = and i1 %5927, %5930
  %5932 = and i1 %5920, %5931
  %5933 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5922
  %5934 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5922
  %5935 = load <8 x i1>, ptr %5933, align 1
  %5936 = load <8 x i1>, ptr %5934, align 1
  %5937 = or <8 x i1> %5936, %convergence.cascade.flow996
  %5938 = load <8 x i1>, ptr %live.mask, align 1
  %5939 = and <8 x i1> %5935, %5938
  %5940 = icmp eq <8 x i1> %5937, %5939
  %5941 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5940)
  %5942 = and i1 %5932, %5941
  %5943 = select i1 %5942, <8 x i1> zeroinitializer, <8 x i1> %5937
  %5944 = select i1 %5932, <8 x i1> %5943, <8 x i1> %5936
  store <8 x i1> %5944, ptr %5934, align 1
  %5945 = select i1 %5942, <8 x i1> zeroinitializer, <8 x i1> %5935
  store <8 x i1> %5945, ptr %5933, align 1
  %5946 = trunc i32 %5922 to i8
  %5947 = shl i8 1, %5946
  %5948 = xor i8 %5947, -1
  %5949 = and i8 %5923, %5948
  %5950 = select i1 %5942, i8 %5949, i8 %5923
  store i8 %5950, ptr %frame.active, align 1
  %.splatinsert1000 = insertelement <8 x i1> poison, i1 %5932, i64 0
  %.splat1001 = shufflevector <8 x i1> %.splatinsert1000, <8 x i1> poison, <8 x i32> zeroinitializer
  %5951 = and <8 x i1> %convergence.cascade.flow996, %.splat1001
  %5952 = load <8 x i1>, ptr %runnable.mask, align 1
  %5953 = xor <8 x i1> %5951, splat (i1 true)
  %5954 = and <8 x i1> %5952, %5953
  store <8 x i1> %5954, ptr %runnable.mask, align 1
  %.splatinsert1002 = insertelement <8 x i1> poison, i1 %5942, i64 0
  %.splat1003 = shufflevector <8 x i1> %.splatinsert1002, <8 x i1> poison, <8 x i32> zeroinitializer
  %5955 = select <8 x i1> %.splat1003, <8 x i1> %5937, <8 x i1> zeroinitializer
  %5956 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5957 = extractelement <8 x i32> %5956, i32 %5922
  %5958 = select i1 %5942, i32 %5957, i32 %5918
  store i32 %5958, ptr %current.token, align 4
  %.splatinsert1004 = insertelement <8 x i1> poison, i1 %5932, i64 0
  %.splat1005 = shufflevector <8 x i1> %.splatinsert1004, <8 x i1> poison, <8 x i32> zeroinitializer
  %5959 = select <8 x i1> %.splat1005, <8 x i1> %5955, <8 x i1> %convergence.cascade.flow996
  %5960 = add i32 %convergence.cascade.depth997, 1
  %5961 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5959)
  %5962 = icmp ult i32 %5960, 8
  %5963 = and i1 %5961, %5962
  %5964 = and i1 %5932, %5963
  %convergence.parent.token1006 = load i32, ptr %current.token, align 4
  %convergence.parent.present1007 = icmp ne i32 %convergence.parent.token1006, 0
  %5965 = and i1 %5964, %convergence.parent.present1007
  br i1 %5965, label %convergence.cascade992, label %convergence.cascade.exit993

convergence.cascade.exit993:                      ; preds = %convergence.cascade992, %schedule.49
  %convergence.cascade.result1008 = phi <8 x i1> [ %1045, %schedule.49 ], [ %5959, %convergence.cascade992 ]
  %5966 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1008)
  br i1 %5966, label %convergence.target.49.ready, label %scheduler.loop

convergence.target.49.ready:                      ; preds = %convergence.cascade.exit993
  %5967 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1008)
  %5968 = bitcast <8 x i1> %convergence.cascade.result1008 to i8
  %5969 = call i8 @llvm.cttz.i8(i8 %5968, i1 false)
  %5970 = zext i8 %5969 to i32
  %5971 = select i1 %5967, i32 %5970, i32 0
  %5972 = load <8 x i1>, ptr %live.mask, align 1
  %5973 = xor <8 x i1> %convergence.cascade.result1008, splat (i1 true)
  %5974 = and <8 x i1> %5972, %5973
  store <8 x i1> %5974, ptr %live.mask, align 1
  %5975 = load <8 x i1>, ptr %runnable.mask, align 1
  %5976 = xor <8 x i1> %convergence.cascade.result1008, splat (i1 true)
  %5977 = and <8 x i1> %5975, %5976
  store <8 x i1> %5977, ptr %runnable.mask, align 1
  %return.active.frames = load i8, ptr %frame.active, align 1
  %return.frames.present = icmp ne i8 %return.active.frames, 0
  br i1 %return.frames.present, label %return.frame.cleanup, label %return.frame.cleanup.done

return.frame.cleanup:                             ; preds = %convergence.target.49.ready
  %5978 = load i8, ptr %frame.active, align 1
  %5979 = and i8 %5978, 1
  %5980 = icmp ne i8 %5979, 0
  %5981 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 0
  %5982 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 0
  %5983 = load <8 x i1>, ptr %5981, align 1
  %5984 = load <8 x i1>, ptr %5982, align 1
  %5985 = and <8 x i1> %5983, %5974
  %5986 = icmp eq <8 x i1> %5984, %5985
  %5987 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5986)
  %5988 = and i1 %5980, %5987
  %.splatinsert1009 = insertelement <8 x i1> poison, i1 %5988, i64 0
  %.splat1010 = shufflevector <8 x i1> %.splatinsert1009, <8 x i1> poison, <8 x i32> zeroinitializer
  %5989 = select <8 x i1> %.splat1010, <8 x i1> %5984, <8 x i1> zeroinitializer
  %5990 = select i1 %5988, <8 x i1> zeroinitializer, <8 x i1> %5985
  store <8 x i1> %5990, ptr %5981, align 1
  %5991 = select i1 %5988, <8 x i1> zeroinitializer, <8 x i1> %5984
  store <8 x i1> %5991, ptr %5982, align 1
  %5992 = and i8 %5978, -2
  %5993 = select i1 %5988, i8 %5992, i8 %5978
  store i8 %5993, ptr %frame.active, align 1
  %5994 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5995 = extractelement <8 x i32> %5994, i32 0
  %5996 = load <8 x i32>, ptr %frame.static.id, align 32
  %5997 = extractelement <8 x i32> %5996, i32 0
  %convergence.target.pointer1011 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %5997
  %convergence.dynamic.target1012 = load i32, ptr %convergence.target.pointer1011, align 4
  %5998 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5989)
  %5999 = load i32, ptr %ready.count, align 4
  %6000 = icmp uge i32 %5999, 8
  %6001 = and i1 %5998, %6000
  br i1 %6001, label %ready.overflow.trap1013, label %ready.overflow.resume1014

return.frame.cleanup.done:                        ; preds = %ready.overflow.resume1056, %convergence.target.49.ready
  br label %scheduler.loop

ready.overflow.trap1013:                          ; preds = %return.frame.cleanup
  call void @llvm.trap()
  unreachable

ready.overflow.resume1014:                        ; preds = %return.frame.cleanup
  %6002 = select i1 %5998, i32 %5999, i32 0
  %6003 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6002
  %6004 = load <8 x i1>, ptr %6003, align 1
  %6005 = select i1 %5998, <8 x i1> %5989, <8 x i1> %6004
  store <8 x i1> %6005, ptr %6003, align 1
  %6006 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6002
  %6007 = load i32, ptr %6006, align 4
  %6008 = select i1 %5998, i32 %convergence.dynamic.target1012, i32 %6007
  store i32 %6008, ptr %6006, align 4
  %6009 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6002
  %6010 = load i32, ptr %6009, align 4
  %6011 = select i1 %5998, i32 %5995, i32 %6010
  store i32 %6011, ptr %6009, align 4
  %6012 = add i32 %5999, 1
  %6013 = select i1 %5998, i32 %6012, i32 %5999
  store i32 %6013, ptr %ready.count, align 4
  %6014 = load <8 x i1>, ptr %runnable.mask, align 1
  %6015 = or <8 x i1> %6014, %5989
  store <8 x i1> %6015, ptr %runnable.mask, align 1
  %6016 = load i8, ptr %frame.active, align 1
  %6017 = and i8 %6016, 2
  %6018 = icmp ne i8 %6017, 0
  %6019 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 1
  %6020 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 1
  %6021 = load <8 x i1>, ptr %6019, align 1
  %6022 = load <8 x i1>, ptr %6020, align 1
  %6023 = and <8 x i1> %6021, %5974
  %6024 = icmp eq <8 x i1> %6022, %6023
  %6025 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6024)
  %6026 = and i1 %6018, %6025
  %.splatinsert1015 = insertelement <8 x i1> poison, i1 %6026, i64 0
  %.splat1016 = shufflevector <8 x i1> %.splatinsert1015, <8 x i1> poison, <8 x i32> zeroinitializer
  %6027 = select <8 x i1> %.splat1016, <8 x i1> %6022, <8 x i1> zeroinitializer
  %6028 = select i1 %6026, <8 x i1> zeroinitializer, <8 x i1> %6023
  store <8 x i1> %6028, ptr %6019, align 1
  %6029 = select i1 %6026, <8 x i1> zeroinitializer, <8 x i1> %6022
  store <8 x i1> %6029, ptr %6020, align 1
  %6030 = and i8 %6016, -3
  %6031 = select i1 %6026, i8 %6030, i8 %6016
  store i8 %6031, ptr %frame.active, align 1
  %6032 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6033 = extractelement <8 x i32> %6032, i32 1
  %6034 = load <8 x i32>, ptr %frame.static.id, align 32
  %6035 = extractelement <8 x i32> %6034, i32 1
  %convergence.target.pointer1017 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %6035
  %convergence.dynamic.target1018 = load i32, ptr %convergence.target.pointer1017, align 4
  %6036 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6027)
  %6037 = load i32, ptr %ready.count, align 4
  %6038 = icmp uge i32 %6037, 8
  %6039 = and i1 %6036, %6038
  br i1 %6039, label %ready.overflow.trap1019, label %ready.overflow.resume1020

ready.overflow.trap1019:                          ; preds = %ready.overflow.resume1014
  call void @llvm.trap()
  unreachable

ready.overflow.resume1020:                        ; preds = %ready.overflow.resume1014
  %6040 = select i1 %6036, i32 %6037, i32 0
  %6041 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6040
  %6042 = load <8 x i1>, ptr %6041, align 1
  %6043 = select i1 %6036, <8 x i1> %6027, <8 x i1> %6042
  store <8 x i1> %6043, ptr %6041, align 1
  %6044 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6040
  %6045 = load i32, ptr %6044, align 4
  %6046 = select i1 %6036, i32 %convergence.dynamic.target1018, i32 %6045
  store i32 %6046, ptr %6044, align 4
  %6047 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6040
  %6048 = load i32, ptr %6047, align 4
  %6049 = select i1 %6036, i32 %6033, i32 %6048
  store i32 %6049, ptr %6047, align 4
  %6050 = add i32 %6037, 1
  %6051 = select i1 %6036, i32 %6050, i32 %6037
  store i32 %6051, ptr %ready.count, align 4
  %6052 = load <8 x i1>, ptr %runnable.mask, align 1
  %6053 = or <8 x i1> %6052, %6027
  store <8 x i1> %6053, ptr %runnable.mask, align 1
  %6054 = load i8, ptr %frame.active, align 1
  %6055 = and i8 %6054, 4
  %6056 = icmp ne i8 %6055, 0
  %6057 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 2
  %6058 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 2
  %6059 = load <8 x i1>, ptr %6057, align 1
  %6060 = load <8 x i1>, ptr %6058, align 1
  %6061 = and <8 x i1> %6059, %5974
  %6062 = icmp eq <8 x i1> %6060, %6061
  %6063 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6062)
  %6064 = and i1 %6056, %6063
  %.splatinsert1021 = insertelement <8 x i1> poison, i1 %6064, i64 0
  %.splat1022 = shufflevector <8 x i1> %.splatinsert1021, <8 x i1> poison, <8 x i32> zeroinitializer
  %6065 = select <8 x i1> %.splat1022, <8 x i1> %6060, <8 x i1> zeroinitializer
  %6066 = select i1 %6064, <8 x i1> zeroinitializer, <8 x i1> %6061
  store <8 x i1> %6066, ptr %6057, align 1
  %6067 = select i1 %6064, <8 x i1> zeroinitializer, <8 x i1> %6060
  store <8 x i1> %6067, ptr %6058, align 1
  %6068 = and i8 %6054, -5
  %6069 = select i1 %6064, i8 %6068, i8 %6054
  store i8 %6069, ptr %frame.active, align 1
  %6070 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6071 = extractelement <8 x i32> %6070, i32 2
  %6072 = load <8 x i32>, ptr %frame.static.id, align 32
  %6073 = extractelement <8 x i32> %6072, i32 2
  %convergence.target.pointer1023 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %6073
  %convergence.dynamic.target1024 = load i32, ptr %convergence.target.pointer1023, align 4
  %6074 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6065)
  %6075 = load i32, ptr %ready.count, align 4
  %6076 = icmp uge i32 %6075, 8
  %6077 = and i1 %6074, %6076
  br i1 %6077, label %ready.overflow.trap1025, label %ready.overflow.resume1026

ready.overflow.trap1025:                          ; preds = %ready.overflow.resume1020
  call void @llvm.trap()
  unreachable

ready.overflow.resume1026:                        ; preds = %ready.overflow.resume1020
  %6078 = select i1 %6074, i32 %6075, i32 0
  %6079 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6078
  %6080 = load <8 x i1>, ptr %6079, align 1
  %6081 = select i1 %6074, <8 x i1> %6065, <8 x i1> %6080
  store <8 x i1> %6081, ptr %6079, align 1
  %6082 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6078
  %6083 = load i32, ptr %6082, align 4
  %6084 = select i1 %6074, i32 %convergence.dynamic.target1024, i32 %6083
  store i32 %6084, ptr %6082, align 4
  %6085 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6078
  %6086 = load i32, ptr %6085, align 4
  %6087 = select i1 %6074, i32 %6071, i32 %6086
  store i32 %6087, ptr %6085, align 4
  %6088 = add i32 %6075, 1
  %6089 = select i1 %6074, i32 %6088, i32 %6075
  store i32 %6089, ptr %ready.count, align 4
  %6090 = load <8 x i1>, ptr %runnable.mask, align 1
  %6091 = or <8 x i1> %6090, %6065
  store <8 x i1> %6091, ptr %runnable.mask, align 1
  %6092 = load i8, ptr %frame.active, align 1
  %6093 = and i8 %6092, 8
  %6094 = icmp ne i8 %6093, 0
  %6095 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 3
  %6096 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 3
  %6097 = load <8 x i1>, ptr %6095, align 1
  %6098 = load <8 x i1>, ptr %6096, align 1
  %6099 = and <8 x i1> %6097, %5974
  %6100 = icmp eq <8 x i1> %6098, %6099
  %6101 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6100)
  %6102 = and i1 %6094, %6101
  %.splatinsert1027 = insertelement <8 x i1> poison, i1 %6102, i64 0
  %.splat1028 = shufflevector <8 x i1> %.splatinsert1027, <8 x i1> poison, <8 x i32> zeroinitializer
  %6103 = select <8 x i1> %.splat1028, <8 x i1> %6098, <8 x i1> zeroinitializer
  %6104 = select i1 %6102, <8 x i1> zeroinitializer, <8 x i1> %6099
  store <8 x i1> %6104, ptr %6095, align 1
  %6105 = select i1 %6102, <8 x i1> zeroinitializer, <8 x i1> %6098
  store <8 x i1> %6105, ptr %6096, align 1
  %6106 = and i8 %6092, -9
  %6107 = select i1 %6102, i8 %6106, i8 %6092
  store i8 %6107, ptr %frame.active, align 1
  %6108 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6109 = extractelement <8 x i32> %6108, i32 3
  %6110 = load <8 x i32>, ptr %frame.static.id, align 32
  %6111 = extractelement <8 x i32> %6110, i32 3
  %convergence.target.pointer1029 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %6111
  %convergence.dynamic.target1030 = load i32, ptr %convergence.target.pointer1029, align 4
  %6112 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6103)
  %6113 = load i32, ptr %ready.count, align 4
  %6114 = icmp uge i32 %6113, 8
  %6115 = and i1 %6112, %6114
  br i1 %6115, label %ready.overflow.trap1031, label %ready.overflow.resume1032

ready.overflow.trap1031:                          ; preds = %ready.overflow.resume1026
  call void @llvm.trap()
  unreachable

ready.overflow.resume1032:                        ; preds = %ready.overflow.resume1026
  %6116 = select i1 %6112, i32 %6113, i32 0
  %6117 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6116
  %6118 = load <8 x i1>, ptr %6117, align 1
  %6119 = select i1 %6112, <8 x i1> %6103, <8 x i1> %6118
  store <8 x i1> %6119, ptr %6117, align 1
  %6120 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6116
  %6121 = load i32, ptr %6120, align 4
  %6122 = select i1 %6112, i32 %convergence.dynamic.target1030, i32 %6121
  store i32 %6122, ptr %6120, align 4
  %6123 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6116
  %6124 = load i32, ptr %6123, align 4
  %6125 = select i1 %6112, i32 %6109, i32 %6124
  store i32 %6125, ptr %6123, align 4
  %6126 = add i32 %6113, 1
  %6127 = select i1 %6112, i32 %6126, i32 %6113
  store i32 %6127, ptr %ready.count, align 4
  %6128 = load <8 x i1>, ptr %runnable.mask, align 1
  %6129 = or <8 x i1> %6128, %6103
  store <8 x i1> %6129, ptr %runnable.mask, align 1
  %6130 = load i8, ptr %frame.active, align 1
  %6131 = and i8 %6130, 16
  %6132 = icmp ne i8 %6131, 0
  %6133 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 4
  %6134 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 4
  %6135 = load <8 x i1>, ptr %6133, align 1
  %6136 = load <8 x i1>, ptr %6134, align 1
  %6137 = and <8 x i1> %6135, %5974
  %6138 = icmp eq <8 x i1> %6136, %6137
  %6139 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6138)
  %6140 = and i1 %6132, %6139
  %.splatinsert1033 = insertelement <8 x i1> poison, i1 %6140, i64 0
  %.splat1034 = shufflevector <8 x i1> %.splatinsert1033, <8 x i1> poison, <8 x i32> zeroinitializer
  %6141 = select <8 x i1> %.splat1034, <8 x i1> %6136, <8 x i1> zeroinitializer
  %6142 = select i1 %6140, <8 x i1> zeroinitializer, <8 x i1> %6137
  store <8 x i1> %6142, ptr %6133, align 1
  %6143 = select i1 %6140, <8 x i1> zeroinitializer, <8 x i1> %6136
  store <8 x i1> %6143, ptr %6134, align 1
  %6144 = and i8 %6130, -17
  %6145 = select i1 %6140, i8 %6144, i8 %6130
  store i8 %6145, ptr %frame.active, align 1
  %6146 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6147 = extractelement <8 x i32> %6146, i32 4
  %6148 = load <8 x i32>, ptr %frame.static.id, align 32
  %6149 = extractelement <8 x i32> %6148, i32 4
  %convergence.target.pointer1035 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %6149
  %convergence.dynamic.target1036 = load i32, ptr %convergence.target.pointer1035, align 4
  %6150 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6141)
  %6151 = load i32, ptr %ready.count, align 4
  %6152 = icmp uge i32 %6151, 8
  %6153 = and i1 %6150, %6152
  br i1 %6153, label %ready.overflow.trap1037, label %ready.overflow.resume1038

ready.overflow.trap1037:                          ; preds = %ready.overflow.resume1032
  call void @llvm.trap()
  unreachable

ready.overflow.resume1038:                        ; preds = %ready.overflow.resume1032
  %6154 = select i1 %6150, i32 %6151, i32 0
  %6155 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6154
  %6156 = load <8 x i1>, ptr %6155, align 1
  %6157 = select i1 %6150, <8 x i1> %6141, <8 x i1> %6156
  store <8 x i1> %6157, ptr %6155, align 1
  %6158 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6154
  %6159 = load i32, ptr %6158, align 4
  %6160 = select i1 %6150, i32 %convergence.dynamic.target1036, i32 %6159
  store i32 %6160, ptr %6158, align 4
  %6161 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6154
  %6162 = load i32, ptr %6161, align 4
  %6163 = select i1 %6150, i32 %6147, i32 %6162
  store i32 %6163, ptr %6161, align 4
  %6164 = add i32 %6151, 1
  %6165 = select i1 %6150, i32 %6164, i32 %6151
  store i32 %6165, ptr %ready.count, align 4
  %6166 = load <8 x i1>, ptr %runnable.mask, align 1
  %6167 = or <8 x i1> %6166, %6141
  store <8 x i1> %6167, ptr %runnable.mask, align 1
  %6168 = load i8, ptr %frame.active, align 1
  %6169 = and i8 %6168, 32
  %6170 = icmp ne i8 %6169, 0
  %6171 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 5
  %6172 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 5
  %6173 = load <8 x i1>, ptr %6171, align 1
  %6174 = load <8 x i1>, ptr %6172, align 1
  %6175 = and <8 x i1> %6173, %5974
  %6176 = icmp eq <8 x i1> %6174, %6175
  %6177 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6176)
  %6178 = and i1 %6170, %6177
  %.splatinsert1039 = insertelement <8 x i1> poison, i1 %6178, i64 0
  %.splat1040 = shufflevector <8 x i1> %.splatinsert1039, <8 x i1> poison, <8 x i32> zeroinitializer
  %6179 = select <8 x i1> %.splat1040, <8 x i1> %6174, <8 x i1> zeroinitializer
  %6180 = select i1 %6178, <8 x i1> zeroinitializer, <8 x i1> %6175
  store <8 x i1> %6180, ptr %6171, align 1
  %6181 = select i1 %6178, <8 x i1> zeroinitializer, <8 x i1> %6174
  store <8 x i1> %6181, ptr %6172, align 1
  %6182 = and i8 %6168, -33
  %6183 = select i1 %6178, i8 %6182, i8 %6168
  store i8 %6183, ptr %frame.active, align 1
  %6184 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6185 = extractelement <8 x i32> %6184, i32 5
  %6186 = load <8 x i32>, ptr %frame.static.id, align 32
  %6187 = extractelement <8 x i32> %6186, i32 5
  %convergence.target.pointer1041 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %6187
  %convergence.dynamic.target1042 = load i32, ptr %convergence.target.pointer1041, align 4
  %6188 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6179)
  %6189 = load i32, ptr %ready.count, align 4
  %6190 = icmp uge i32 %6189, 8
  %6191 = and i1 %6188, %6190
  br i1 %6191, label %ready.overflow.trap1043, label %ready.overflow.resume1044

ready.overflow.trap1043:                          ; preds = %ready.overflow.resume1038
  call void @llvm.trap()
  unreachable

ready.overflow.resume1044:                        ; preds = %ready.overflow.resume1038
  %6192 = select i1 %6188, i32 %6189, i32 0
  %6193 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6192
  %6194 = load <8 x i1>, ptr %6193, align 1
  %6195 = select i1 %6188, <8 x i1> %6179, <8 x i1> %6194
  store <8 x i1> %6195, ptr %6193, align 1
  %6196 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6192
  %6197 = load i32, ptr %6196, align 4
  %6198 = select i1 %6188, i32 %convergence.dynamic.target1042, i32 %6197
  store i32 %6198, ptr %6196, align 4
  %6199 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6192
  %6200 = load i32, ptr %6199, align 4
  %6201 = select i1 %6188, i32 %6185, i32 %6200
  store i32 %6201, ptr %6199, align 4
  %6202 = add i32 %6189, 1
  %6203 = select i1 %6188, i32 %6202, i32 %6189
  store i32 %6203, ptr %ready.count, align 4
  %6204 = load <8 x i1>, ptr %runnable.mask, align 1
  %6205 = or <8 x i1> %6204, %6179
  store <8 x i1> %6205, ptr %runnable.mask, align 1
  %6206 = load i8, ptr %frame.active, align 1
  %6207 = and i8 %6206, 64
  %6208 = icmp ne i8 %6207, 0
  %6209 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 6
  %6210 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 6
  %6211 = load <8 x i1>, ptr %6209, align 1
  %6212 = load <8 x i1>, ptr %6210, align 1
  %6213 = and <8 x i1> %6211, %5974
  %6214 = icmp eq <8 x i1> %6212, %6213
  %6215 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6214)
  %6216 = and i1 %6208, %6215
  %.splatinsert1045 = insertelement <8 x i1> poison, i1 %6216, i64 0
  %.splat1046 = shufflevector <8 x i1> %.splatinsert1045, <8 x i1> poison, <8 x i32> zeroinitializer
  %6217 = select <8 x i1> %.splat1046, <8 x i1> %6212, <8 x i1> zeroinitializer
  %6218 = select i1 %6216, <8 x i1> zeroinitializer, <8 x i1> %6213
  store <8 x i1> %6218, ptr %6209, align 1
  %6219 = select i1 %6216, <8 x i1> zeroinitializer, <8 x i1> %6212
  store <8 x i1> %6219, ptr %6210, align 1
  %6220 = and i8 %6206, -65
  %6221 = select i1 %6216, i8 %6220, i8 %6206
  store i8 %6221, ptr %frame.active, align 1
  %6222 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6223 = extractelement <8 x i32> %6222, i32 6
  %6224 = load <8 x i32>, ptr %frame.static.id, align 32
  %6225 = extractelement <8 x i32> %6224, i32 6
  %convergence.target.pointer1047 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %6225
  %convergence.dynamic.target1048 = load i32, ptr %convergence.target.pointer1047, align 4
  %6226 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6217)
  %6227 = load i32, ptr %ready.count, align 4
  %6228 = icmp uge i32 %6227, 8
  %6229 = and i1 %6226, %6228
  br i1 %6229, label %ready.overflow.trap1049, label %ready.overflow.resume1050

ready.overflow.trap1049:                          ; preds = %ready.overflow.resume1044
  call void @llvm.trap()
  unreachable

ready.overflow.resume1050:                        ; preds = %ready.overflow.resume1044
  %6230 = select i1 %6226, i32 %6227, i32 0
  %6231 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6230
  %6232 = load <8 x i1>, ptr %6231, align 1
  %6233 = select i1 %6226, <8 x i1> %6217, <8 x i1> %6232
  store <8 x i1> %6233, ptr %6231, align 1
  %6234 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6230
  %6235 = load i32, ptr %6234, align 4
  %6236 = select i1 %6226, i32 %convergence.dynamic.target1048, i32 %6235
  store i32 %6236, ptr %6234, align 4
  %6237 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6230
  %6238 = load i32, ptr %6237, align 4
  %6239 = select i1 %6226, i32 %6223, i32 %6238
  store i32 %6239, ptr %6237, align 4
  %6240 = add i32 %6227, 1
  %6241 = select i1 %6226, i32 %6240, i32 %6227
  store i32 %6241, ptr %ready.count, align 4
  %6242 = load <8 x i1>, ptr %runnable.mask, align 1
  %6243 = or <8 x i1> %6242, %6217
  store <8 x i1> %6243, ptr %runnable.mask, align 1
  %6244 = load i8, ptr %frame.active, align 1
  %6245 = and i8 %6244, -128
  %6246 = icmp ne i8 %6245, 0
  %6247 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 7
  %6248 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 7
  %6249 = load <8 x i1>, ptr %6247, align 1
  %6250 = load <8 x i1>, ptr %6248, align 1
  %6251 = and <8 x i1> %6249, %5974
  %6252 = icmp eq <8 x i1> %6250, %6251
  %6253 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6252)
  %6254 = and i1 %6246, %6253
  %.splatinsert1051 = insertelement <8 x i1> poison, i1 %6254, i64 0
  %.splat1052 = shufflevector <8 x i1> %.splatinsert1051, <8 x i1> poison, <8 x i32> zeroinitializer
  %6255 = select <8 x i1> %.splat1052, <8 x i1> %6250, <8 x i1> zeroinitializer
  %6256 = select i1 %6254, <8 x i1> zeroinitializer, <8 x i1> %6251
  store <8 x i1> %6256, ptr %6247, align 1
  %6257 = select i1 %6254, <8 x i1> zeroinitializer, <8 x i1> %6250
  store <8 x i1> %6257, ptr %6248, align 1
  %6258 = and i8 %6244, 127
  %6259 = select i1 %6254, i8 %6258, i8 %6244
  store i8 %6259, ptr %frame.active, align 1
  %6260 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6261 = extractelement <8 x i32> %6260, i32 7
  %6262 = load <8 x i32>, ptr %frame.static.id, align 32
  %6263 = extractelement <8 x i32> %6262, i32 7
  %convergence.target.pointer1053 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %6263
  %convergence.dynamic.target1054 = load i32, ptr %convergence.target.pointer1053, align 4
  %6264 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6255)
  %6265 = load i32, ptr %ready.count, align 4
  %6266 = icmp uge i32 %6265, 8
  %6267 = and i1 %6264, %6266
  br i1 %6267, label %ready.overflow.trap1055, label %ready.overflow.resume1056

ready.overflow.trap1055:                          ; preds = %ready.overflow.resume1050
  call void @llvm.trap()
  unreachable

ready.overflow.resume1056:                        ; preds = %ready.overflow.resume1050
  %6268 = select i1 %6264, i32 %6265, i32 0
  %6269 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6268
  %6270 = load <8 x i1>, ptr %6269, align 1
  %6271 = select i1 %6264, <8 x i1> %6255, <8 x i1> %6270
  store <8 x i1> %6271, ptr %6269, align 1
  %6272 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6268
  %6273 = load i32, ptr %6272, align 4
  %6274 = select i1 %6264, i32 %convergence.dynamic.target1054, i32 %6273
  store i32 %6274, ptr %6272, align 4
  %6275 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6268
  %6276 = load i32, ptr %6275, align 4
  %6277 = select i1 %6264, i32 %6261, i32 %6276
  store i32 %6277, ptr %6275, align 4
  %6278 = add i32 %6265, 1
  %6279 = select i1 %6264, i32 %6278, i32 %6265
  store i32 %6279, ptr %ready.count, align 4
  %6280 = load <8 x i1>, ptr %runnable.mask, align 1
  %6281 = or <8 x i1> %6280, %6255
  store <8 x i1> %6281, ptr %runnable.mask, align 1
  br label %return.frame.cleanup.done
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.and.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x i64>) #2

define dso_local void @tile_inclusive_scan.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(write) }

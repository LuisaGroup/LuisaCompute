; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

@convergence.targets = private unnamed_addr constant [18 x i32] [i32 49, i32 5, i32 10, i32 9, i32 13, i32 18, i32 17, i32 21, i32 26, i32 25, i32 29, i32 34, i32 33, i32 37, i32 42, i32 41, i32 45, i32 48], align 4

define internal void @tile_inclusive_scan(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %live.mask = alloca <8 x i1>, align 1
  %runnable.mask = alloca <8 x i1>, align 1
  %ready.count = alloca i32, align 4
  %ready.mask = alloca [8 x <8 x i1>], align 1
  %ready.target = alloca [8 x i32], align 4
  %ready.token = alloca [8 x i32], align 4
  %current.mask = alloca <8 x i1>, align 1
  %current.token = alloca i32, align 4
  %frame.active = alloca i8, align 1
  %frame.static.id = alloca <8 x i32>, align 32
  %frame.parent.token = alloca <8 x i32>, align 32
  %frame.expected = alloca [8 x <8 x i1>], align 1
  %frame.arrived = alloca [8 x <8 x i1>], align 1
  store <8 x i1> zeroinitializer, ptr %live.mask, align 1
  store <8 x i1> zeroinitializer, ptr %runnable.mask, align 1
  store i32 0, ptr %ready.count, align 4
  store [8 x <8 x i1>] zeroinitializer, ptr %ready.mask, align 1
  store [8 x i32] zeroinitializer, ptr %ready.target, align 4
  store [8 x i32] zeroinitializer, ptr %ready.token, align 4
  store <8 x i1> zeroinitializer, ptr %current.mask, align 1
  store i32 0, ptr %current.token, align 4
  store i8 0, ptr %frame.active, align 1
  store <8 x i32> zeroinitializer, ptr %frame.static.id, align 32
  store <8 x i32> zeroinitializer, ptr %frame.parent.token, align 32
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.expected, align 1
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.arrived, align 1
  %tile_snapshot.local = alloca [128 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [4096 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local4 = alloca [2048 x i8], align 8
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local7 = alloca [4096 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local10 = alloca [4096 x i8], align 4
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %8 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %9 = insertvalue { <8 x ptr>, <8 x i64> } %8, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local13 = alloca [2048 x i8], align 8
  %.splatinsert14 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local13, i64 0
  %.splat15 = shufflevector <8 x ptr> %.splatinsert14, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat15, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local16 = alloca [4096 x i8], align 4
  %.splatinsert17 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local16, i64 0
  %.splat18 = shufflevector <8 x ptr> %.splatinsert17, <8 x ptr> poison, <8 x i32> zeroinitializer
  %12 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat18, 0
  %13 = insertvalue { <8 x ptr>, <8 x i64> } %12, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local19 = alloca [4096 x i8], align 4
  %.splatinsert20 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local19, i64 0
  %.splat21 = shufflevector <8 x ptr> %.splatinsert20, <8 x ptr> poison, <8 x i32> zeroinitializer
  %14 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat21, 0
  %15 = insertvalue { <8 x ptr>, <8 x i64> } %14, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local22 = alloca [2048 x i8], align 8
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local25 = alloca [4096 x i8], align 4
  %.splatinsert26 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local25, i64 0
  %.splat27 = shufflevector <8 x ptr> %.splatinsert26, <8 x ptr> poison, <8 x i32> zeroinitializer
  %18 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat27, 0
  %19 = insertvalue { <8 x ptr>, <8 x i64> } %18, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local28 = alloca [4096 x i8], align 4
  %.splatinsert29 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local28, i64 0
  %.splat30 = shufflevector <8 x ptr> %.splatinsert29, <8 x ptr> poison, <8 x i32> zeroinitializer
  %20 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat30, 0
  %21 = insertvalue { <8 x ptr>, <8 x i64> } %20, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local31 = alloca [2048 x i8], align 8
  %.splatinsert32 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local31, i64 0
  %.splat33 = shufflevector <8 x ptr> %.splatinsert32, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat33, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local34 = alloca [4096 x i8], align 4
  %.splatinsert35 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local34, i64 0
  %.splat36 = shufflevector <8 x ptr> %.splatinsert35, <8 x ptr> poison, <8 x i32> zeroinitializer
  %24 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat36, 0
  %25 = insertvalue { <8 x ptr>, <8 x i64> } %24, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local37 = alloca [4096 x i8], align 4
  %.splatinsert38 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local37, i64 0
  %.splat39 = shufflevector <8 x ptr> %.splatinsert38, <8 x ptr> poison, <8 x i32> zeroinitializer
  %26 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat39, 0
  %27 = insertvalue { <8 x ptr>, <8 x i64> } %26, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local40 = alloca [2048 x i8], align 8
  %.splatinsert41 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local40, i64 0
  %.splat42 = shufflevector <8 x ptr> %.splatinsert41, <8 x ptr> poison, <8 x i32> zeroinitializer
  %28 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat42, 0
  %29 = insertvalue { <8 x ptr>, <8 x i64> } %28, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local43 = alloca [4096 x i8], align 4
  %.splatinsert44 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local43, i64 0
  %.splat45 = shufflevector <8 x ptr> %.splatinsert44, <8 x ptr> poison, <8 x i32> zeroinitializer
  %30 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat45, 0
  %31 = insertvalue { <8 x ptr>, <8 x i64> } %30, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local46 = alloca [4096 x i8], align 4
  %.splatinsert47 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local46, i64 0
  %.splat48 = shufflevector <8 x ptr> %.splatinsert47, <8 x ptr> poison, <8 x i32> zeroinitializer
  %32 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat48, 0
  %33 = insertvalue { <8 x ptr>, <8 x i64> } %32, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill49 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill49, align 4
  %.slot = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot, align 64
  %.slot50 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.slot50, align 32
  %.slot51 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.slot51, align 32
  %.slot52 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.slot52, align 32
  %.slot53 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.slot53, align 32
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.spill54 = alloca i64, align 8
  store i64 0, ptr %.spill54, align 4
  %tile_snapshot.spill55 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill55, align 64
  %.slot56 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot56, align 64
  %tile_snapshot.spill57 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill57, align 64
  %tile_snapshot.spill58 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill58, align 64
  %.slot59 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot59, align 64
  %.spill60 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill60, align 1
  %.spill61 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill61, align 64
  %.slot62 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot62, align 32
  %tile_snapshot.spill63 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill63, align 64
  %.slot64 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot64, align 64
  %tile_snapshot.spill65 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill65, align 64
  %tile_snapshot.spill66 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill66, align 64
  %.slot67 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot67, align 64
  %.spill68 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill68, align 1
  %.spill69 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill69, align 64
  %.slot70 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot70, align 32
  %tile_snapshot.spill71 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill71, align 64
  %.slot72 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot72, align 64
  %tile_snapshot.spill73 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill73, align 64
  %tile_snapshot.spill74 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill74, align 64
  %.slot75 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot75, align 64
  %.spill76 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill76, align 1
  %.spill77 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill77, align 64
  %.slot78 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot78, align 32
  %tile_snapshot.spill79 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill79, align 64
  %.slot80 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot80, align 64
  %tile_snapshot.spill81 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill81, align 64
  %tile_snapshot.spill82 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill82, align 64
  %.slot83 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot83, align 64
  %.spill84 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill84, align 1
  %.spill85 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill85, align 64
  %.slot86 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot86, align 32
  %tile_snapshot.spill87 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill87, align 64
  %.slot88 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot88, align 64
  %tile_snapshot.spill89 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill89, align 64
  %tile_snapshot.spill90 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill90, align 64
  %.slot91 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot91, align 64
  %.spill92 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill92, align 1
  %.spill93 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill93, align 64
  %.slot94 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot94, align 32
  %tile_snapshot.spill95 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill95, align 64
  %.slot96 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot96, align 64
  %.slot97 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot97, align 64
  %34 = getelementptr i8, ptr %argument_buffer, i64 0
  %35 = load ptr, ptr %34, align 16
  %36 = getelementptr i8, ptr %34, i64 8
  %37 = load i64, ptr %36, align 8
  %38 = insertvalue { ptr, i64 } poison, ptr %35, 0
  %39 = insertvalue { ptr, i64 } %38, i64 %37, 1
  %40 = getelementptr i8, ptr %argument_buffer, i64 16
  %41 = load ptr, ptr %40, align 16
  %42 = getelementptr i8, ptr %40, i64 8
  %43 = load i64, ptr %42, align 8
  %44 = insertvalue { ptr, i64 } poison, ptr %41, 0
  %45 = insertvalue { ptr, i64 } %44, i64 %43, 1
  %46 = load i32, ptr %launch_config, align 4
  %47 = getelementptr i8, ptr %launch_config, i64 12
  %48 = load i32, ptr %47, align 4
  %49 = getelementptr i8, ptr %launch_config, i64 4
  %50 = load i32, ptr %49, align 4
  %51 = getelementptr i8, ptr %launch_config, i64 16
  %52 = load i32, ptr %51, align 4
  %53 = getelementptr i8, ptr %launch_config, i64 8
  %54 = load i32, ptr %53, align 4
  %55 = getelementptr i8, ptr %launch_config, i64 20
  %56 = load i32, ptr %55, align 4
  %57 = getelementptr i8, ptr %launch_config, i64 36
  %58 = load i32, ptr %57, align 4
  %.splatinsert98 = insertelement <8 x i32> poison, i32 %58, i64 0
  %.splat99 = shufflevector <8 x i32> %.splatinsert98, <8 x i32> poison, <8 x i32> zeroinitializer
  %59 = add <8 x i32> %.splat99, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %60 = mul i32 %46, 32
  %.splatinsert100 = insertelement <8 x i32> poison, i32 %60, i64 0
  %.splat101 = shufflevector <8 x i32> %.splatinsert100, <8 x i32> poison, <8 x i32> zeroinitializer
  %61 = add <8 x i32> %.splat101, %59
  %62 = mul i32 %50, 1
  %.splatinsert102 = insertelement <8 x i32> poison, i32 %62, i64 0
  %.splat103 = shufflevector <8 x i32> %.splatinsert102, <8 x i32> poison, <8 x i32> zeroinitializer
  %63 = add <8 x i32> %.splat103, zeroinitializer
  %64 = mul i32 %54, 1
  %.splatinsert104 = insertelement <8 x i32> poison, i32 %64, i64 0
  %.splat105 = shufflevector <8 x i32> %.splatinsert104, <8 x i32> poison, <8 x i32> zeroinitializer
  %65 = add <8 x i32> %.splat105, zeroinitializer
  %66 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %61, 0
  %67 = insertvalue [3 x <8 x i32>] %66, <8 x i32> %63, 1
  %68 = insertvalue [3 x <8 x i32>] %67, <8 x i32> %65, 2
  %.splatinsert106 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat107 = shufflevector <8 x i32> %.splatinsert106, <8 x i32> poison, <8 x i32> zeroinitializer
  %69 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat107
  store <8 x i1> %69, ptr %live.mask, align 1
  %70 = load i32, ptr %current.token, align 4
  %71 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %69)
  %72 = load i32, ptr %ready.count, align 4
  %73 = icmp uge i32 %72, 8
  %74 = and i1 %71, %73
  br i1 %74, label %ready.overflow.trap, label %ready.overflow.resume

ready.overflow.trap:                              ; preds = %prologue
  call void @llvm.trap()
  unreachable

ready.overflow.resume:                            ; preds = %prologue
  %75 = select i1 %71, i32 %72, i32 0
  %76 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %75
  %77 = load <8 x i1>, ptr %76, align 1
  %78 = select i1 %71, <8 x i1> %69, <8 x i1> %77
  store <8 x i1> %78, ptr %76, align 1
  %79 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %75
  %80 = load i32, ptr %79, align 4
  %81 = select i1 %71, i32 0, i32 %80
  store i32 %81, ptr %79, align 4
  %82 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %75
  %83 = load i32, ptr %82, align 4
  %84 = select i1 %71, i32 %70, i32 %83
  store i32 %84, ptr %82, align 4
  %85 = add i32 %72, 1
  %86 = select i1 %71, i32 %85, i32 %72
  store i32 %86, ptr %ready.count, align 4
  %87 = load <8 x i1>, ptr %runnable.mask, align 1
  %88 = or <8 x i1> %87, %69
  store <8 x i1> %88, ptr %runnable.mask, align 1
  br label %scheduler.loop

scheduler.loop:                                   ; preds = %return.frame.cleanup.done, %convergence.cascade.exit1011, %convergence.target.48.ready, %convergence.cascade.exit982, %schedule.47, %varying.coherent.false971, %varying.coherent.true970, %convergence.target.45.ready, %convergence.cascade.exit947, %schedule.44, %varying.coherent.false937, %varying.coherent.true936, %convergence.target.42.ready, %convergence.cascade.exit913, %convergence.target.41.ready, %convergence.cascade.exit888, %schedule.40, %varying.coherent.false884, %varying.coherent.true883, %varying.coherent.false870, %varying.coherent.true869, %convergence.target.37.ready, %convergence.cascade.exit782, %schedule.36, %varying.coherent.false773, %varying.coherent.true772, %convergence.target.34.ready, %convergence.cascade.exit749, %convergence.target.33.ready, %convergence.cascade.exit724, %schedule.32, %varying.coherent.false720, %varying.coherent.true719, %varying.coherent.false706, %varying.coherent.true705, %convergence.target.29.ready, %convergence.cascade.exit618, %schedule.28, %varying.coherent.false609, %varying.coherent.true608, %convergence.target.26.ready, %convergence.cascade.exit585, %convergence.target.25.ready, %convergence.cascade.exit560, %schedule.24, %varying.coherent.false556, %varying.coherent.true555, %varying.coherent.false542, %varying.coherent.true541, %convergence.target.21.ready, %convergence.cascade.exit454, %schedule.20, %varying.coherent.false445, %varying.coherent.true444, %convergence.target.18.ready, %convergence.cascade.exit421, %convergence.target.17.ready, %convergence.cascade.exit396, %schedule.16, %varying.coherent.false392, %varying.coherent.true391, %varying.coherent.false378, %varying.coherent.true377, %convergence.target.13.ready, %convergence.cascade.exit290, %schedule.12, %varying.coherent.false281, %varying.coherent.true280, %convergence.target.10.ready, %convergence.cascade.exit257, %convergence.target.9.ready, %convergence.cascade.exit232, %schedule.8, %varying.coherent.false228, %varying.coherent.true227, %varying.coherent.false214, %varying.coherent.true213, %convergence.target.5.ready, %convergence.cascade.exit, %schedule.4, %varying.coherent.false128, %varying.coherent.true127, %schedule.2, %varying.coherent.false, %varying.coherent.true, %schedule.0, %ready.overflow.resume
  %89 = load i32, ptr %ready.count, align 4
  %90 = icmp ne i32 %89, 0
  br i1 %90, label %scheduler.dispatch, label %scheduler.done

scheduler.dispatch:                               ; preds = %scheduler.loop
  %91 = sub i32 %89, 1
  store i32 %91, ptr %ready.count, align 4
  %92 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %91
  %93 = load <8 x i1>, ptr %92, align 1
  store <8 x i1> %93, ptr %current.mask, align 1
  %94 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %91
  %95 = load i32, ptr %94, align 4
  %96 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %91
  %97 = load i32, ptr %96, align 4
  store i32 %97, ptr %current.token, align 4
  %98 = load <8 x i1>, ptr %runnable.mask, align 1
  %99 = xor <8 x i1> %93, splat (i1 true)
  %100 = and <8 x i1> %98, %99
  store <8 x i1> %100, ptr %runnable.mask, align 1
  br label %scheduler.dispatch.route

scheduler.dispatch.route:                         ; preds = %ready.overflow.resume969, %ready.overflow.resume935, %ready.overflow.resume882, %ready.overflow.resume868, %ready.overflow.resume771, %ready.overflow.resume718, %ready.overflow.resume704, %ready.overflow.resume607, %ready.overflow.resume554, %ready.overflow.resume540, %ready.overflow.resume443, %ready.overflow.resume390, %ready.overflow.resume376, %ready.overflow.resume279, %ready.overflow.resume226, %ready.overflow.resume212, %ready.overflow.resume126, %ready.overflow.resume109, %scheduler.dispatch
  %scheduler.dispatch.pc = phi i32 [ %95, %scheduler.dispatch ], [ 49, %ready.overflow.resume109 ], [ 5, %ready.overflow.resume126 ], [ 10, %ready.overflow.resume212 ], [ 9, %ready.overflow.resume226 ], [ 13, %ready.overflow.resume279 ], [ 18, %ready.overflow.resume376 ], [ 17, %ready.overflow.resume390 ], [ 21, %ready.overflow.resume443 ], [ 26, %ready.overflow.resume540 ], [ 25, %ready.overflow.resume554 ], [ 29, %ready.overflow.resume607 ], [ 34, %ready.overflow.resume704 ], [ 33, %ready.overflow.resume718 ], [ 37, %ready.overflow.resume771 ], [ 42, %ready.overflow.resume868 ], [ 41, %ready.overflow.resume882 ], [ 45, %ready.overflow.resume935 ], [ 48, %ready.overflow.resume969 ]
  switch i32 %scheduler.dispatch.pc, label %scheduler.invalid [
    i32 0, label %schedule.0
    i32 1, label %schedule.1
    i32 2, label %schedule.2
    i32 3, label %schedule.3
    i32 4, label %schedule.4
    i32 5, label %schedule.5
    i32 6, label %schedule.6
    i32 7, label %schedule.7
    i32 8, label %schedule.8
    i32 9, label %schedule.9
    i32 10, label %schedule.10
    i32 11, label %schedule.11
    i32 12, label %schedule.12
    i32 13, label %schedule.13
    i32 14, label %schedule.14
    i32 15, label %schedule.15
    i32 16, label %schedule.16
    i32 17, label %schedule.17
    i32 18, label %schedule.18
    i32 19, label %schedule.19
    i32 20, label %schedule.20
    i32 21, label %schedule.21
    i32 22, label %schedule.22
    i32 23, label %schedule.23
    i32 24, label %schedule.24
    i32 25, label %schedule.25
    i32 26, label %schedule.26
    i32 27, label %schedule.27
    i32 28, label %schedule.28
    i32 29, label %schedule.29
    i32 30, label %schedule.30
    i32 31, label %schedule.31
    i32 32, label %schedule.32
    i32 33, label %schedule.33
    i32 34, label %schedule.34
    i32 35, label %schedule.35
    i32 36, label %schedule.36
    i32 37, label %schedule.37
    i32 38, label %schedule.38
    i32 39, label %schedule.39
    i32 40, label %schedule.40
    i32 41, label %schedule.41
    i32 42, label %schedule.42
    i32 43, label %schedule.43
    i32 44, label %schedule.44
    i32 45, label %schedule.45
    i32 46, label %schedule.46
    i32 47, label %schedule.47
    i32 48, label %schedule.48
    i32 49, label %schedule.49
  ]

scheduler.done:                                   ; preds = %scheduler.loop
  %101 = load <8 x i1>, ptr %live.mask, align 1
  %102 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  br i1 %102, label %scheduler.stalled, label %scheduler.exit

scheduler.exit:                                   ; preds = %scheduler.done
  ret void

scheduler.stalled:                                ; preds = %scheduler.done
  call void @llvm.trap()
  unreachable

scheduler.invalid:                                ; preds = %scheduler.dispatch.route
  call void @llvm.trap()
  unreachable

schedule.0:                                       ; preds = %scheduler.dispatch.route
  %103 = load <8 x i1>, ptr %current.mask, align 1
  %104 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %103)
  %105 = bitcast <8 x i1> %103 to i8
  %106 = call i8 @llvm.cttz.i8(i8 %105, i1 false)
  %107 = zext i8 %106 to i32
  %108 = select i1 %104, i32 %107, i32 0
  %109 = extractvalue [3 x <8 x i32>] %68, 0
  %110 = zext <8 x i32> %109 to <8 x i64>
  %111 = select <8 x i1> %103, <8 x i64> %110, <8 x i64> zeroinitializer
  %112 = select <8 x i1> %103, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %113 = sdiv <8 x i64> %111, %112
  %114 = mul <8 x i64> %113, splat (i64 4)
  %115 = load volatile <8 x i64>, ptr %.spill, align 64
  %116 = select <8 x i1> %103, <8 x i64> %114, <8 x i64> %115
  store volatile <8 x i64> %116, ptr %.spill, align 64
  store float 0.000000e+00, ptr %.spill49, align 4
  %117 = load <8 x i64>, ptr %.slot, align 64
  %118 = select <8 x i1> %103, <8 x i64> zeroinitializer, <8 x i64> %117
  store <8 x i64> %118, ptr %.slot, align 64
  %119 = load volatile <8 x float>, ptr %.slot50, align 32
  %120 = select <8 x i1> %103, <8 x float> zeroinitializer, <8 x float> %119
  store volatile <8 x float> %120, ptr %.slot50, align 32
  %121 = load volatile <8 x float>, ptr %.slot51, align 32
  %122 = select <8 x i1> %103, <8 x float> zeroinitializer, <8 x float> %121
  store volatile <8 x float> %122, ptr %.slot51, align 32
  %123 = load volatile <8 x float>, ptr %.slot52, align 32
  %124 = select <8 x i1> %103, <8 x float> zeroinitializer, <8 x float> %123
  store volatile <8 x float> %124, ptr %.slot52, align 32
  %125 = load volatile <8 x float>, ptr %.slot53, align 32
  %126 = select <8 x i1> %103, <8 x float> zeroinitializer, <8 x float> %125
  store volatile <8 x float> %126, ptr %.slot53, align 32
  store <8 x i1> %103, ptr %current.mask, align 1
  %127 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %103)
  br i1 %127, label %schedule.1, label %scheduler.loop

schedule.1:                                       ; preds = %convergence.target.48.ready, %schedule.0, %scheduler.dispatch.route
  %128 = load <8 x i1>, ptr %current.mask, align 1
  %129 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %128)
  %130 = bitcast <8 x i1> %128 to i8
  %131 = call i8 @llvm.cttz.i8(i8 %130, i1 false)
  %132 = zext i8 %131 to i32
  %133 = select i1 %129, i32 %132, i32 0
  %.state = load <8 x i64>, ptr %.slot, align 64
  %134 = icmp slt <8 x i64> %.state, splat (i64 1)
  %135 = and <8 x i1> %128, %134
  %136 = xor <8 x i1> %134, splat (i1 true)
  %137 = and <8 x i1> %128, %136
  %138 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %135)
  %139 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %137)
  %140 = and i1 %138, %139
  br i1 %140, label %varying.divergent, label %varying.coherent

schedule.2:                                       ; preds = %varying.coherent.true, %scheduler.dispatch.route
  %141 = load <8 x i1>, ptr %current.mask, align 1
  %142 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %141)
  %143 = bitcast <8 x i1> %141 to i8
  %144 = call i8 @llvm.cttz.i8(i8 %143, i1 false)
  %145 = zext i8 %144 to i32
  %146 = select i1 %142, i32 %145, i32 0
  %147 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %148 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %147, 0
  %150 = select <8 x i1> %141, <8 x ptr> %148, <8 x ptr> %149
  %151 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %152 = extractvalue { <8 x ptr>, <8 x i64> } %147, 1
  %153 = select <8 x i1> %141, <8 x i64> %151, <8 x i64> %152
  %154 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %150, 0
  %155 = insertvalue { <8 x ptr>, <8 x i64> } %154, <8 x i64> %153, 1
  store volatile { <8 x ptr>, <8 x i64> } %155, ptr %tile_snapshot.spill, align 64
  %156 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %157 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %158 = add <8 x i64> %157, zeroinitializer
  %159 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %156, 0
  %160 = insertvalue { <8 x ptr>, <8 x i64> } %159, <8 x i64> %158, 1
  %.state110 = load volatile <8 x float>, ptr %.slot50, align 32
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %160, 1
  %163 = extractelement <8 x ptr> %161, i32 0
  %164 = extractelement <8 x i64> %162, i32 %146
  %165 = zext i32 %146 to i64
  %166 = mul i64 %165, 4
  %167 = sub i64 %164, %166
  %168 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %141)
  %169 = select i1 %168, i64 %167, i64 0
  %private.contiguous.address = getelementptr i8, ptr %163, i64 %169
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %170 = select <8 x i1> %141, <8 x float> %.state110, <8 x float> %private.contiguous.preserve
  store <8 x float> %170, ptr %private.contiguous.address, align 4
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %173 = add <8 x i64> %172, splat (i64 32)
  %174 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %171, 0
  %175 = insertvalue { <8 x ptr>, <8 x i64> } %174, <8 x i64> %173, 1
  %.state111 = load volatile <8 x float>, ptr %.slot51, align 32
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %177 = extractvalue { <8 x ptr>, <8 x i64> } %175, 1
  %178 = extractelement <8 x ptr> %176, i32 0
  %179 = extractelement <8 x i64> %177, i32 %146
  %180 = zext i32 %146 to i64
  %181 = mul i64 %180, 4
  %182 = sub i64 %179, %181
  %183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %141)
  %184 = select i1 %183, i64 %182, i64 0
  %private.contiguous.address112 = getelementptr i8, ptr %178, i64 %184
  %private.contiguous.preserve113 = load <8 x float>, ptr %private.contiguous.address112, align 4
  %185 = select <8 x i1> %141, <8 x float> %.state111, <8 x float> %private.contiguous.preserve113
  store <8 x float> %185, ptr %private.contiguous.address112, align 4
  %186 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %188 = add <8 x i64> %187, splat (i64 64)
  %189 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %186, 0
  %190 = insertvalue { <8 x ptr>, <8 x i64> } %189, <8 x i64> %188, 1
  %.state114 = load volatile <8 x float>, ptr %.slot52, align 32
  %191 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %190, 1
  %193 = extractelement <8 x ptr> %191, i32 0
  %194 = extractelement <8 x i64> %192, i32 %146
  %195 = zext i32 %146 to i64
  %196 = mul i64 %195, 4
  %197 = sub i64 %194, %196
  %198 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %141)
  %199 = select i1 %198, i64 %197, i64 0
  %private.contiguous.address115 = getelementptr i8, ptr %193, i64 %199
  %private.contiguous.preserve116 = load <8 x float>, ptr %private.contiguous.address115, align 4
  %200 = select <8 x i1> %141, <8 x float> %.state114, <8 x float> %private.contiguous.preserve116
  store <8 x float> %200, ptr %private.contiguous.address115, align 4
  %201 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %202 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %203 = add <8 x i64> %202, splat (i64 96)
  %204 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %201, 0
  %205 = insertvalue { <8 x ptr>, <8 x i64> } %204, <8 x i64> %203, 1
  %.state117 = load volatile <8 x float>, ptr %.slot53, align 32
  %206 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %207 = extractvalue { <8 x ptr>, <8 x i64> } %205, 1
  %208 = extractelement <8 x ptr> %206, i32 0
  %209 = extractelement <8 x i64> %207, i32 %146
  %210 = zext i32 %146 to i64
  %211 = mul i64 %210, 4
  %212 = sub i64 %209, %211
  %213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %141)
  %214 = select i1 %213, i64 %212, i64 0
  %private.contiguous.address118 = getelementptr i8, ptr %208, i64 %214
  %private.contiguous.preserve119 = load <8 x float>, ptr %private.contiguous.address118, align 4
  %215 = select <8 x i1> %141, <8 x float> %.state117, <8 x float> %private.contiguous.preserve119
  store <8 x float> %215, ptr %private.contiguous.address118, align 4
  store i64 0, ptr %.spill54, align 4
  %216 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %217 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %218 = extractvalue { <8 x ptr>, <8 x i64> } %216, 0
  %219 = select <8 x i1> %141, <8 x ptr> %217, <8 x ptr> %218
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %216, 1
  %222 = select <8 x i1> %141, <8 x i64> %220, <8 x i64> %221
  %223 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %219, 0
  %224 = insertvalue { <8 x ptr>, <8 x i64> } %223, <8 x i64> %222, 1
  store volatile { <8 x ptr>, <8 x i64> } %224, ptr %tile_snapshot.spill55, align 64
  %225 = load <8 x i64>, ptr %.slot56, align 64
  %226 = select <8 x i1> %141, <8 x i64> zeroinitializer, <8 x i64> %225
  store <8 x i64> %226, ptr %.slot56, align 64
  store <8 x i1> %141, ptr %current.mask, align 1
  %227 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %141)
  br i1 %227, label %schedule.3, label %scheduler.loop

schedule.3:                                       ; preds = %schedule.4, %schedule.2, %scheduler.dispatch.route
  %228 = load <8 x i1>, ptr %current.mask, align 1
  %229 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %228)
  %230 = bitcast <8 x i1> %228 to i8
  %231 = call i8 @llvm.cttz.i8(i8 %230, i1 false)
  %232 = zext i8 %231 to i32
  %233 = select i1 %229, i32 %232, i32 0
  %.state120 = load <8 x i64>, ptr %.slot56, align 64
  %234 = icmp slt <8 x i64> %.state120, splat (i64 128)
  %235 = and <8 x i1> %228, %234
  %236 = xor <8 x i1> %234, splat (i1 true)
  %237 = and <8 x i1> %228, %236
  %238 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %235)
  %239 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %237)
  %240 = and i1 %238, %239
  br i1 %240, label %varying.divergent121, label %varying.coherent122

schedule.4:                                       ; preds = %varying.coherent.true127, %scheduler.dispatch.route
  %241 = load <8 x i1>, ptr %current.mask, align 1
  %242 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %241)
  %243 = bitcast <8 x i1> %241 to i8
  %244 = call i8 @llvm.cttz.i8(i8 %243, i1 false)
  %245 = zext i8 %244 to i32
  %246 = select i1 %242, i32 %245, i32 0
  %.state129 = load <8 x i64>, ptr %.slot56, align 64
  %247 = select <8 x i1> %241, <8 x i64> %.state129, <8 x i64> zeroinitializer
  %248 = select <8 x i1> %241, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %249 = srem <8 x i64> %247, %248
  %.state130 = load <8 x i64>, ptr %.slot56, align 64
  %250 = select <8 x i1> %241, <8 x i64> %.state130, <8 x i64> zeroinitializer
  %251 = select <8 x i1> %241, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %252 = sdiv <8 x i64> %250, %251
  %.spill.load = load volatile <8 x i64>, ptr %.spill, align 64
  %253 = add <8 x i64> %.spill.load, %252
  %254 = add <8 x i64> zeroinitializer, %253
  %.spill.load131 = load i64, ptr %.spill54, align 4
  %.splatinsert132 = insertelement <8 x i64> poison, i64 %.spill.load131, i64 0
  %.splat133 = shufflevector <8 x i64> %.splatinsert132, <8 x i64> poison, <8 x i32> zeroinitializer
  %255 = add <8 x i64> %.splat133, %249
  %256 = mul <8 x i64> %254, splat (i64 32)
  %257 = add <8 x i64> %256, %255
  %258 = extractvalue { ptr, i64 } %39, 0
  %259 = mul <8 x i64> %257, splat (i64 4)
  %260 = getelementptr i8, ptr %258, <8 x i64> %259
  %261 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %260, i32 1, <8 x i1> %241, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %263 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state134 = load <8 x i64>, ptr %.slot56, align 64
  %264 = mul <8 x i64> %.state134, splat (i64 32)
  %265 = add <8 x i64> %263, %264
  %266 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %262, 0
  %267 = insertvalue { <8 x ptr>, <8 x i64> } %266, <8 x i64> %265, 1
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %267, 0
  %269 = extractvalue { <8 x ptr>, <8 x i64> } %267, 1
  %270 = getelementptr i8, <8 x ptr> %268, <8 x i64> %269
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %261, <8 x ptr> %270, i32 1, <8 x i1> %241)
  %.state135 = load <8 x i64>, ptr %.slot56, align 64
  %271 = add <8 x i64> %.state135, splat (i64 1)
  %272 = load <8 x i64>, ptr %.slot56, align 64
  %273 = select <8 x i1> %241, <8 x i64> %271, <8 x i64> %272
  store <8 x i64> %273, ptr %.slot56, align 64
  store <8 x i1> %241, ptr %current.mask, align 1
  %274 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %241)
  br i1 %274, label %schedule.3, label %scheduler.loop

schedule.5:                                       ; preds = %varying.coherent.false128, %scheduler.dispatch.route
  %275 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token = load i32, ptr %current.token, align 4
  %convergence.token.present = icmp ne i32 %convergence.current.token, 0
  br i1 %convergence.token.present, label %convergence.cascade, label %convergence.cascade.exit

schedule.6:                                       ; preds = %convergence.target.9.ready, %convergence.target.5.ready, %scheduler.dispatch.route
  %276 = load <8 x i1>, ptr %current.mask, align 1
  %277 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %276)
  %278 = bitcast <8 x i1> %276 to i8
  %279 = call i8 @llvm.cttz.i8(i8 %278, i1 false)
  %280 = zext i8 %279 to i32
  %281 = select i1 %277, i32 %280, i32 0
  %.state206 = load <8 x i64>, ptr %.slot59, align 64
  %282 = icmp slt <8 x i64> %.state206, splat (i64 128)
  %283 = and <8 x i1> %276, %282
  %284 = xor <8 x i1> %282, splat (i1 true)
  %285 = and <8 x i1> %276, %284
  %286 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %283)
  %287 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %285)
  %288 = and i1 %286, %287
  br i1 %288, label %varying.divergent207, label %varying.coherent208

schedule.7:                                       ; preds = %varying.coherent.true213, %scheduler.dispatch.route
  %289 = load <8 x i1>, ptr %current.mask, align 1
  %290 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %289)
  %291 = bitcast <8 x i1> %289 to i8
  %292 = call i8 @llvm.cttz.i8(i8 %291, i1 false)
  %293 = zext i8 %292 to i32
  %294 = select i1 %290, i32 %293, i32 0
  %.state215 = load <8 x i64>, ptr %.slot59, align 64
  %295 = select <8 x i1> %289, <8 x i64> %.state215, <8 x i64> zeroinitializer
  %296 = select <8 x i1> %289, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %297 = srem <8 x i64> %295, %296
  %.state216 = load <8 x i64>, ptr %.slot59, align 64
  %298 = select <8 x i1> %289, <8 x i64> %.state216, <8 x i64> zeroinitializer
  %299 = select <8 x i1> %289, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %300 = sdiv <8 x i64> %298, %299
  %.spill.load217 = load i64, ptr %.spill54, align 4
  %.splatinsert218 = insertelement <8 x i64> poison, i64 %.spill.load217, i64 0
  %.splat219 = shufflevector <8 x i64> %.splatinsert218, <8 x i64> poison, <8 x i32> zeroinitializer
  %301 = add <8 x i64> %.splat219, %297
  %tile_snapshot.spill.load220 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill57, align 64
  %302 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load220, 0
  %303 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load220, 1
  %304 = mul <8 x i64> %301, splat (i64 64)
  %305 = add <8 x i64> %303, %304
  %306 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %302, 0
  %307 = insertvalue { <8 x ptr>, <8 x i64> } %306, <8 x i64> %305, 1
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %307, 0
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %307, 1
  %310 = getelementptr i8, <8 x ptr> %308, <8 x i64> %309
  %311 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> %310, i32 1, <8 x i1> %289, <8 x i64> zeroinitializer)
  %312 = icmp sge <8 x i64> %311, zeroinitializer
  %313 = icmp slt <8 x i64> %311, splat (i64 32)
  %314 = and <8 x i1> %312, %313
  %315 = load volatile <8 x i1>, ptr %.spill60, align 1
  %316 = select <8 x i1> %289, <8 x i1> %314, <8 x i1> %315
  store volatile <8 x i1> %316, ptr %.spill60, align 1
  %317 = add <8 x i64> zeroinitializer, %300
  %318 = mul <8 x i64> %317, splat (i64 32)
  %319 = add <8 x i64> %318, %311
  %320 = load volatile <8 x i64>, ptr %.spill61, align 64
  %321 = select <8 x i1> %289, <8 x i64> %319, <8 x i64> %320
  store volatile <8 x i64> %321, ptr %.spill61, align 64
  %322 = icmp sge <8 x i64> %319, zeroinitializer
  %323 = icmp slt <8 x i64> %319, splat (i64 128)
  %324 = and <8 x i1> %322, %323
  %325 = and <8 x i1> %289, %324
  %326 = xor <8 x i1> %324, splat (i1 true)
  %327 = and <8 x i1> %289, %326
  %328 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %325)
  %329 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %327)
  %330 = and i1 %328, %329
  br i1 %330, label %varying.divergent221, label %varying.coherent222

schedule.8:                                       ; preds = %varying.coherent.true227, %scheduler.dispatch.route
  %331 = load <8 x i1>, ptr %current.mask, align 1
  %332 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %331)
  %333 = bitcast <8 x i1> %331 to i8
  %334 = call i8 @llvm.cttz.i8(i8 %333, i1 false)
  %335 = zext i8 %334 to i32
  %336 = select i1 %332, i32 %335, i32 0
  %tile_snapshot.spill.load229 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %337 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load229, 0
  %338 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load229, 1
  %.spill.load230 = load volatile <8 x i64>, ptr %.spill61, align 64
  %339 = mul <8 x i64> %.spill.load230, splat (i64 32)
  %340 = add <8 x i64> %338, %339
  %341 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %337, 0
  %342 = insertvalue { <8 x ptr>, <8 x i64> } %341, <8 x i64> %340, 1
  %343 = extractvalue { <8 x ptr>, <8 x i64> } %342, 0
  %344 = extractvalue { <8 x ptr>, <8 x i64> } %342, 1
  %345 = getelementptr i8, <8 x ptr> %343, <8 x i64> %344
  %346 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %345, i32 1, <8 x i1> %331, <8 x float> zeroinitializer)
  %347 = load <8 x float>, ptr %.slot62, align 32
  %348 = select <8 x i1> %331, <8 x float> %346, <8 x float> %347
  store <8 x float> %348, ptr %.slot62, align 32
  store <8 x i1> %331, ptr %current.mask, align 1
  %349 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %331)
  br i1 %349, label %schedule.9, label %scheduler.loop

schedule.9:                                       ; preds = %schedule.8, %varying.coherent.false228, %scheduler.dispatch.route
  %350 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token233 = load i32, ptr %current.token, align 4
  %convergence.token.present234 = icmp ne i32 %convergence.current.token233, 0
  br i1 %convergence.token.present234, label %convergence.cascade231, label %convergence.cascade.exit232

schedule.10:                                      ; preds = %varying.coherent.false214, %scheduler.dispatch.route
  %351 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token258 = load i32, ptr %current.token, align 4
  %convergence.token.present259 = icmp ne i32 %convergence.current.token258, 0
  br i1 %convergence.token.present259, label %convergence.cascade256, label %convergence.cascade.exit257

schedule.11:                                      ; preds = %schedule.12, %convergence.target.10.ready, %scheduler.dispatch.route
  %352 = load <8 x i1>, ptr %current.mask, align 1
  %353 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %352)
  %354 = bitcast <8 x i1> %352 to i8
  %355 = call i8 @llvm.cttz.i8(i8 %354, i1 false)
  %356 = zext i8 %355 to i32
  %357 = select i1 %353, i32 %356, i32 0
  %.state273 = load <8 x i64>, ptr %.slot64, align 64
  %358 = icmp slt <8 x i64> %.state273, splat (i64 128)
  %359 = and <8 x i1> %352, %358
  %360 = xor <8 x i1> %358, splat (i1 true)
  %361 = and <8 x i1> %352, %360
  %362 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %359)
  %363 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %361)
  %364 = and i1 %362, %363
  br i1 %364, label %varying.divergent274, label %varying.coherent275

schedule.12:                                      ; preds = %varying.coherent.true280, %scheduler.dispatch.route
  %365 = load <8 x i1>, ptr %current.mask, align 1
  %366 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %365)
  %367 = bitcast <8 x i1> %365 to i8
  %368 = call i8 @llvm.cttz.i8(i8 %367, i1 false)
  %369 = zext i8 %368 to i32
  %370 = select i1 %366, i32 %369, i32 0
  %.state282 = load <8 x i64>, ptr %.slot64, align 64
  %371 = select <8 x i1> %365, <8 x i64> %.state282, <8 x i64> zeroinitializer
  %372 = select <8 x i1> %365, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %373 = srem <8 x i64> %371, %372
  %.state283 = load <8 x i64>, ptr %.slot64, align 64
  %374 = select <8 x i1> %365, <8 x i64> %.state283, <8 x i64> zeroinitializer
  %375 = select <8 x i1> %365, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %376 = sdiv <8 x i64> %374, %375
  %377 = add <8 x i64> zeroinitializer, %376
  %378 = mul <8 x i64> %377, splat (i64 32)
  %379 = add <8 x i64> %378, %373
  %tile_snapshot.spill.load284 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %380 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load284, 0
  %381 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load284, 1
  %382 = mul <8 x i64> %379, splat (i64 32)
  %383 = add <8 x i64> %381, %382
  %384 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %380, 0
  %385 = insertvalue { <8 x ptr>, <8 x i64> } %384, <8 x i64> %383, 1
  %386 = extractvalue { <8 x ptr>, <8 x i64> } %385, 0
  %387 = extractvalue { <8 x ptr>, <8 x i64> } %385, 1
  %388 = getelementptr i8, <8 x ptr> %386, <8 x i64> %387
  %389 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %388, i32 1, <8 x i1> %365, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load285 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill58, align 64
  %390 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load285, 0
  %391 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load285, 1
  %392 = mul <8 x i64> %379, splat (i64 32)
  %393 = add <8 x i64> %391, %392
  %394 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %390, 0
  %395 = insertvalue { <8 x ptr>, <8 x i64> } %394, <8 x i64> %393, 1
  %396 = extractvalue { <8 x ptr>, <8 x i64> } %395, 0
  %397 = extractvalue { <8 x ptr>, <8 x i64> } %395, 1
  %398 = getelementptr i8, <8 x ptr> %396, <8 x i64> %397
  %399 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %398, i32 1, <8 x i1> %365, <8 x float> zeroinitializer)
  %400 = fadd <8 x float> %389, %399
  %tile_snapshot.spill.load286 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill63, align 64
  %401 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load286, 0
  %402 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load286, 1
  %.state287 = load <8 x i64>, ptr %.slot64, align 64
  %403 = mul <8 x i64> %.state287, splat (i64 32)
  %404 = add <8 x i64> %402, %403
  %405 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %401, 0
  %406 = insertvalue { <8 x ptr>, <8 x i64> } %405, <8 x i64> %404, 1
  %407 = extractvalue { <8 x ptr>, <8 x i64> } %406, 0
  %408 = extractvalue { <8 x ptr>, <8 x i64> } %406, 1
  %409 = getelementptr i8, <8 x ptr> %407, <8 x i64> %408
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %400, <8 x ptr> %409, i32 1, <8 x i1> %365)
  %.state288 = load <8 x i64>, ptr %.slot64, align 64
  %410 = add <8 x i64> %.state288, splat (i64 1)
  %411 = load <8 x i64>, ptr %.slot64, align 64
  %412 = select <8 x i1> %365, <8 x i64> %410, <8 x i64> %411
  store <8 x i64> %412, ptr %.slot64, align 64
  store <8 x i1> %365, ptr %current.mask, align 1
  %413 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %365)
  br i1 %413, label %schedule.11, label %scheduler.loop

schedule.13:                                      ; preds = %varying.coherent.false281, %scheduler.dispatch.route
  %414 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token291 = load i32, ptr %current.token, align 4
  %convergence.token.present292 = icmp ne i32 %convergence.current.token291, 0
  br i1 %convergence.token.present292, label %convergence.cascade289, label %convergence.cascade.exit290

schedule.14:                                      ; preds = %convergence.target.17.ready, %convergence.target.13.ready, %scheduler.dispatch.route
  %415 = load <8 x i1>, ptr %current.mask, align 1
  %416 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %415)
  %417 = bitcast <8 x i1> %415 to i8
  %418 = call i8 @llvm.cttz.i8(i8 %417, i1 false)
  %419 = zext i8 %418 to i32
  %420 = select i1 %416, i32 %419, i32 0
  %.state370 = load <8 x i64>, ptr %.slot67, align 64
  %421 = icmp slt <8 x i64> %.state370, splat (i64 128)
  %422 = and <8 x i1> %415, %421
  %423 = xor <8 x i1> %421, splat (i1 true)
  %424 = and <8 x i1> %415, %423
  %425 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %422)
  %426 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %424)
  %427 = and i1 %425, %426
  br i1 %427, label %varying.divergent371, label %varying.coherent372

schedule.15:                                      ; preds = %varying.coherent.true377, %scheduler.dispatch.route
  %428 = load <8 x i1>, ptr %current.mask, align 1
  %429 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %428)
  %430 = bitcast <8 x i1> %428 to i8
  %431 = call i8 @llvm.cttz.i8(i8 %430, i1 false)
  %432 = zext i8 %431 to i32
  %433 = select i1 %429, i32 %432, i32 0
  %.state379 = load <8 x i64>, ptr %.slot67, align 64
  %434 = select <8 x i1> %428, <8 x i64> %.state379, <8 x i64> zeroinitializer
  %435 = select <8 x i1> %428, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %436 = srem <8 x i64> %434, %435
  %.state380 = load <8 x i64>, ptr %.slot67, align 64
  %437 = select <8 x i1> %428, <8 x i64> %.state380, <8 x i64> zeroinitializer
  %438 = select <8 x i1> %428, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %439 = sdiv <8 x i64> %437, %438
  %.spill.load381 = load i64, ptr %.spill54, align 4
  %.splatinsert382 = insertelement <8 x i64> poison, i64 %.spill.load381, i64 0
  %.splat383 = shufflevector <8 x i64> %.splatinsert382, <8 x i64> poison, <8 x i32> zeroinitializer
  %440 = add <8 x i64> %.splat383, %436
  %tile_snapshot.spill.load384 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %441 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load384, 0
  %442 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load384, 1
  %443 = mul <8 x i64> %440, splat (i64 64)
  %444 = add <8 x i64> %442, %443
  %445 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %441, 0
  %446 = insertvalue { <8 x ptr>, <8 x i64> } %445, <8 x i64> %444, 1
  %447 = extractvalue { <8 x ptr>, <8 x i64> } %446, 0
  %448 = extractvalue { <8 x ptr>, <8 x i64> } %446, 1
  %449 = getelementptr i8, <8 x ptr> %447, <8 x i64> %448
  %450 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> %449, i32 1, <8 x i1> %428, <8 x i64> zeroinitializer)
  %451 = icmp sge <8 x i64> %450, zeroinitializer
  %452 = icmp slt <8 x i64> %450, splat (i64 32)
  %453 = and <8 x i1> %451, %452
  %454 = load volatile <8 x i1>, ptr %.spill68, align 1
  %455 = select <8 x i1> %428, <8 x i1> %453, <8 x i1> %454
  store volatile <8 x i1> %455, ptr %.spill68, align 1
  %456 = add <8 x i64> zeroinitializer, %439
  %457 = mul <8 x i64> %456, splat (i64 32)
  %458 = add <8 x i64> %457, %450
  %459 = load volatile <8 x i64>, ptr %.spill69, align 64
  %460 = select <8 x i1> %428, <8 x i64> %458, <8 x i64> %459
  store volatile <8 x i64> %460, ptr %.spill69, align 64
  %461 = icmp sge <8 x i64> %458, zeroinitializer
  %462 = icmp slt <8 x i64> %458, splat (i64 128)
  %463 = and <8 x i1> %461, %462
  %464 = and <8 x i1> %428, %463
  %465 = xor <8 x i1> %463, splat (i1 true)
  %466 = and <8 x i1> %428, %465
  %467 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %464)
  %468 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %466)
  %469 = and i1 %467, %468
  br i1 %469, label %varying.divergent385, label %varying.coherent386

schedule.16:                                      ; preds = %varying.coherent.true391, %scheduler.dispatch.route
  %470 = load <8 x i1>, ptr %current.mask, align 1
  %471 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %470)
  %472 = bitcast <8 x i1> %470 to i8
  %473 = call i8 @llvm.cttz.i8(i8 %472, i1 false)
  %474 = zext i8 %473 to i32
  %475 = select i1 %471, i32 %474, i32 0
  %tile_snapshot.spill.load393 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill63, align 64
  %476 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load393, 0
  %477 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load393, 1
  %.spill.load394 = load volatile <8 x i64>, ptr %.spill69, align 64
  %478 = mul <8 x i64> %.spill.load394, splat (i64 32)
  %479 = add <8 x i64> %477, %478
  %480 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %476, 0
  %481 = insertvalue { <8 x ptr>, <8 x i64> } %480, <8 x i64> %479, 1
  %482 = extractvalue { <8 x ptr>, <8 x i64> } %481, 0
  %483 = extractvalue { <8 x ptr>, <8 x i64> } %481, 1
  %484 = getelementptr i8, <8 x ptr> %482, <8 x i64> %483
  %485 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %484, i32 1, <8 x i1> %470, <8 x float> zeroinitializer)
  %486 = load <8 x float>, ptr %.slot70, align 32
  %487 = select <8 x i1> %470, <8 x float> %485, <8 x float> %486
  store <8 x float> %487, ptr %.slot70, align 32
  store <8 x i1> %470, ptr %current.mask, align 1
  %488 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %470)
  br i1 %488, label %schedule.17, label %scheduler.loop

schedule.17:                                      ; preds = %schedule.16, %varying.coherent.false392, %scheduler.dispatch.route
  %489 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token397 = load i32, ptr %current.token, align 4
  %convergence.token.present398 = icmp ne i32 %convergence.current.token397, 0
  br i1 %convergence.token.present398, label %convergence.cascade395, label %convergence.cascade.exit396

schedule.18:                                      ; preds = %varying.coherent.false378, %scheduler.dispatch.route
  %490 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token422 = load i32, ptr %current.token, align 4
  %convergence.token.present423 = icmp ne i32 %convergence.current.token422, 0
  br i1 %convergence.token.present423, label %convergence.cascade420, label %convergence.cascade.exit421

schedule.19:                                      ; preds = %schedule.20, %convergence.target.18.ready, %scheduler.dispatch.route
  %491 = load <8 x i1>, ptr %current.mask, align 1
  %492 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %491)
  %493 = bitcast <8 x i1> %491 to i8
  %494 = call i8 @llvm.cttz.i8(i8 %493, i1 false)
  %495 = zext i8 %494 to i32
  %496 = select i1 %492, i32 %495, i32 0
  %.state437 = load <8 x i64>, ptr %.slot72, align 64
  %497 = icmp slt <8 x i64> %.state437, splat (i64 128)
  %498 = and <8 x i1> %491, %497
  %499 = xor <8 x i1> %497, splat (i1 true)
  %500 = and <8 x i1> %491, %499
  %501 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %498)
  %502 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %500)
  %503 = and i1 %501, %502
  br i1 %503, label %varying.divergent438, label %varying.coherent439

schedule.20:                                      ; preds = %varying.coherent.true444, %scheduler.dispatch.route
  %504 = load <8 x i1>, ptr %current.mask, align 1
  %505 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %504)
  %506 = bitcast <8 x i1> %504 to i8
  %507 = call i8 @llvm.cttz.i8(i8 %506, i1 false)
  %508 = zext i8 %507 to i32
  %509 = select i1 %505, i32 %508, i32 0
  %.state446 = load <8 x i64>, ptr %.slot72, align 64
  %510 = select <8 x i1> %504, <8 x i64> %.state446, <8 x i64> zeroinitializer
  %511 = select <8 x i1> %504, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %512 = srem <8 x i64> %510, %511
  %.state447 = load <8 x i64>, ptr %.slot72, align 64
  %513 = select <8 x i1> %504, <8 x i64> %.state447, <8 x i64> zeroinitializer
  %514 = select <8 x i1> %504, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %515 = sdiv <8 x i64> %513, %514
  %516 = add <8 x i64> zeroinitializer, %515
  %517 = mul <8 x i64> %516, splat (i64 32)
  %518 = add <8 x i64> %517, %512
  %tile_snapshot.spill.load448 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill63, align 64
  %519 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load448, 0
  %520 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load448, 1
  %521 = mul <8 x i64> %518, splat (i64 32)
  %522 = add <8 x i64> %520, %521
  %523 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %519, 0
  %524 = insertvalue { <8 x ptr>, <8 x i64> } %523, <8 x i64> %522, 1
  %525 = extractvalue { <8 x ptr>, <8 x i64> } %524, 0
  %526 = extractvalue { <8 x ptr>, <8 x i64> } %524, 1
  %527 = getelementptr i8, <8 x ptr> %525, <8 x i64> %526
  %528 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %527, i32 1, <8 x i1> %504, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load449 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill66, align 64
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load449, 0
  %530 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load449, 1
  %531 = mul <8 x i64> %518, splat (i64 32)
  %532 = add <8 x i64> %530, %531
  %533 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %529, 0
  %534 = insertvalue { <8 x ptr>, <8 x i64> } %533, <8 x i64> %532, 1
  %535 = extractvalue { <8 x ptr>, <8 x i64> } %534, 0
  %536 = extractvalue { <8 x ptr>, <8 x i64> } %534, 1
  %537 = getelementptr i8, <8 x ptr> %535, <8 x i64> %536
  %538 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %537, i32 1, <8 x i1> %504, <8 x float> zeroinitializer)
  %539 = fadd <8 x float> %528, %538
  %tile_snapshot.spill.load450 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill71, align 64
  %540 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load450, 0
  %541 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load450, 1
  %.state451 = load <8 x i64>, ptr %.slot72, align 64
  %542 = mul <8 x i64> %.state451, splat (i64 32)
  %543 = add <8 x i64> %541, %542
  %544 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %540, 0
  %545 = insertvalue { <8 x ptr>, <8 x i64> } %544, <8 x i64> %543, 1
  %546 = extractvalue { <8 x ptr>, <8 x i64> } %545, 0
  %547 = extractvalue { <8 x ptr>, <8 x i64> } %545, 1
  %548 = getelementptr i8, <8 x ptr> %546, <8 x i64> %547
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %539, <8 x ptr> %548, i32 1, <8 x i1> %504)
  %.state452 = load <8 x i64>, ptr %.slot72, align 64
  %549 = add <8 x i64> %.state452, splat (i64 1)
  %550 = load <8 x i64>, ptr %.slot72, align 64
  %551 = select <8 x i1> %504, <8 x i64> %549, <8 x i64> %550
  store <8 x i64> %551, ptr %.slot72, align 64
  store <8 x i1> %504, ptr %current.mask, align 1
  %552 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %504)
  br i1 %552, label %schedule.19, label %scheduler.loop

schedule.21:                                      ; preds = %varying.coherent.false445, %scheduler.dispatch.route
  %553 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token455 = load i32, ptr %current.token, align 4
  %convergence.token.present456 = icmp ne i32 %convergence.current.token455, 0
  br i1 %convergence.token.present456, label %convergence.cascade453, label %convergence.cascade.exit454

schedule.22:                                      ; preds = %convergence.target.25.ready, %convergence.target.21.ready, %scheduler.dispatch.route
  %554 = load <8 x i1>, ptr %current.mask, align 1
  %555 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %554)
  %556 = bitcast <8 x i1> %554 to i8
  %557 = call i8 @llvm.cttz.i8(i8 %556, i1 false)
  %558 = zext i8 %557 to i32
  %559 = select i1 %555, i32 %558, i32 0
  %.state534 = load <8 x i64>, ptr %.slot75, align 64
  %560 = icmp slt <8 x i64> %.state534, splat (i64 128)
  %561 = and <8 x i1> %554, %560
  %562 = xor <8 x i1> %560, splat (i1 true)
  %563 = and <8 x i1> %554, %562
  %564 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %561)
  %565 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %563)
  %566 = and i1 %564, %565
  br i1 %566, label %varying.divergent535, label %varying.coherent536

schedule.23:                                      ; preds = %varying.coherent.true541, %scheduler.dispatch.route
  %567 = load <8 x i1>, ptr %current.mask, align 1
  %568 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %567)
  %569 = bitcast <8 x i1> %567 to i8
  %570 = call i8 @llvm.cttz.i8(i8 %569, i1 false)
  %571 = zext i8 %570 to i32
  %572 = select i1 %568, i32 %571, i32 0
  %.state543 = load <8 x i64>, ptr %.slot75, align 64
  %573 = select <8 x i1> %567, <8 x i64> %.state543, <8 x i64> zeroinitializer
  %574 = select <8 x i1> %567, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %575 = srem <8 x i64> %573, %574
  %.state544 = load <8 x i64>, ptr %.slot75, align 64
  %576 = select <8 x i1> %567, <8 x i64> %.state544, <8 x i64> zeroinitializer
  %577 = select <8 x i1> %567, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %578 = sdiv <8 x i64> %576, %577
  %.spill.load545 = load i64, ptr %.spill54, align 4
  %.splatinsert546 = insertelement <8 x i64> poison, i64 %.spill.load545, i64 0
  %.splat547 = shufflevector <8 x i64> %.splatinsert546, <8 x i64> poison, <8 x i32> zeroinitializer
  %579 = add <8 x i64> %.splat547, %575
  %tile_snapshot.spill.load548 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill73, align 64
  %580 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load548, 0
  %581 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load548, 1
  %582 = mul <8 x i64> %579, splat (i64 64)
  %583 = add <8 x i64> %581, %582
  %584 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %580, 0
  %585 = insertvalue { <8 x ptr>, <8 x i64> } %584, <8 x i64> %583, 1
  %586 = extractvalue { <8 x ptr>, <8 x i64> } %585, 0
  %587 = extractvalue { <8 x ptr>, <8 x i64> } %585, 1
  %588 = getelementptr i8, <8 x ptr> %586, <8 x i64> %587
  %589 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> %588, i32 1, <8 x i1> %567, <8 x i64> zeroinitializer)
  %590 = icmp sge <8 x i64> %589, zeroinitializer
  %591 = icmp slt <8 x i64> %589, splat (i64 32)
  %592 = and <8 x i1> %590, %591
  %593 = load volatile <8 x i1>, ptr %.spill76, align 1
  %594 = select <8 x i1> %567, <8 x i1> %592, <8 x i1> %593
  store volatile <8 x i1> %594, ptr %.spill76, align 1
  %595 = add <8 x i64> zeroinitializer, %578
  %596 = mul <8 x i64> %595, splat (i64 32)
  %597 = add <8 x i64> %596, %589
  %598 = load volatile <8 x i64>, ptr %.spill77, align 64
  %599 = select <8 x i1> %567, <8 x i64> %597, <8 x i64> %598
  store volatile <8 x i64> %599, ptr %.spill77, align 64
  %600 = icmp sge <8 x i64> %597, zeroinitializer
  %601 = icmp slt <8 x i64> %597, splat (i64 128)
  %602 = and <8 x i1> %600, %601
  %603 = and <8 x i1> %567, %602
  %604 = xor <8 x i1> %602, splat (i1 true)
  %605 = and <8 x i1> %567, %604
  %606 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %603)
  %607 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %605)
  %608 = and i1 %606, %607
  br i1 %608, label %varying.divergent549, label %varying.coherent550

schedule.24:                                      ; preds = %varying.coherent.true555, %scheduler.dispatch.route
  %609 = load <8 x i1>, ptr %current.mask, align 1
  %610 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %609)
  %611 = bitcast <8 x i1> %609 to i8
  %612 = call i8 @llvm.cttz.i8(i8 %611, i1 false)
  %613 = zext i8 %612 to i32
  %614 = select i1 %610, i32 %613, i32 0
  %tile_snapshot.spill.load557 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill71, align 64
  %615 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load557, 0
  %616 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load557, 1
  %.spill.load558 = load volatile <8 x i64>, ptr %.spill77, align 64
  %617 = mul <8 x i64> %.spill.load558, splat (i64 32)
  %618 = add <8 x i64> %616, %617
  %619 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %615, 0
  %620 = insertvalue { <8 x ptr>, <8 x i64> } %619, <8 x i64> %618, 1
  %621 = extractvalue { <8 x ptr>, <8 x i64> } %620, 0
  %622 = extractvalue { <8 x ptr>, <8 x i64> } %620, 1
  %623 = getelementptr i8, <8 x ptr> %621, <8 x i64> %622
  %624 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %623, i32 1, <8 x i1> %609, <8 x float> zeroinitializer)
  %625 = load <8 x float>, ptr %.slot78, align 32
  %626 = select <8 x i1> %609, <8 x float> %624, <8 x float> %625
  store <8 x float> %626, ptr %.slot78, align 32
  store <8 x i1> %609, ptr %current.mask, align 1
  %627 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %609)
  br i1 %627, label %schedule.25, label %scheduler.loop

schedule.25:                                      ; preds = %schedule.24, %varying.coherent.false556, %scheduler.dispatch.route
  %628 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token561 = load i32, ptr %current.token, align 4
  %convergence.token.present562 = icmp ne i32 %convergence.current.token561, 0
  br i1 %convergence.token.present562, label %convergence.cascade559, label %convergence.cascade.exit560

schedule.26:                                      ; preds = %varying.coherent.false542, %scheduler.dispatch.route
  %629 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token586 = load i32, ptr %current.token, align 4
  %convergence.token.present587 = icmp ne i32 %convergence.current.token586, 0
  br i1 %convergence.token.present587, label %convergence.cascade584, label %convergence.cascade.exit585

schedule.27:                                      ; preds = %schedule.28, %convergence.target.26.ready, %scheduler.dispatch.route
  %630 = load <8 x i1>, ptr %current.mask, align 1
  %631 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %630)
  %632 = bitcast <8 x i1> %630 to i8
  %633 = call i8 @llvm.cttz.i8(i8 %632, i1 false)
  %634 = zext i8 %633 to i32
  %635 = select i1 %631, i32 %634, i32 0
  %.state601 = load <8 x i64>, ptr %.slot80, align 64
  %636 = icmp slt <8 x i64> %.state601, splat (i64 128)
  %637 = and <8 x i1> %630, %636
  %638 = xor <8 x i1> %636, splat (i1 true)
  %639 = and <8 x i1> %630, %638
  %640 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %637)
  %641 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %639)
  %642 = and i1 %640, %641
  br i1 %642, label %varying.divergent602, label %varying.coherent603

schedule.28:                                      ; preds = %varying.coherent.true608, %scheduler.dispatch.route
  %643 = load <8 x i1>, ptr %current.mask, align 1
  %644 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %643)
  %645 = bitcast <8 x i1> %643 to i8
  %646 = call i8 @llvm.cttz.i8(i8 %645, i1 false)
  %647 = zext i8 %646 to i32
  %648 = select i1 %644, i32 %647, i32 0
  %.state610 = load <8 x i64>, ptr %.slot80, align 64
  %649 = select <8 x i1> %643, <8 x i64> %.state610, <8 x i64> zeroinitializer
  %650 = select <8 x i1> %643, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %651 = srem <8 x i64> %649, %650
  %.state611 = load <8 x i64>, ptr %.slot80, align 64
  %652 = select <8 x i1> %643, <8 x i64> %.state611, <8 x i64> zeroinitializer
  %653 = select <8 x i1> %643, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %654 = sdiv <8 x i64> %652, %653
  %655 = add <8 x i64> zeroinitializer, %654
  %656 = mul <8 x i64> %655, splat (i64 32)
  %657 = add <8 x i64> %656, %651
  %tile_snapshot.spill.load612 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill71, align 64
  %658 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load612, 0
  %659 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load612, 1
  %660 = mul <8 x i64> %657, splat (i64 32)
  %661 = add <8 x i64> %659, %660
  %662 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %658, 0
  %663 = insertvalue { <8 x ptr>, <8 x i64> } %662, <8 x i64> %661, 1
  %664 = extractvalue { <8 x ptr>, <8 x i64> } %663, 0
  %665 = extractvalue { <8 x ptr>, <8 x i64> } %663, 1
  %666 = getelementptr i8, <8 x ptr> %664, <8 x i64> %665
  %667 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %666, i32 1, <8 x i1> %643, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load613 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill74, align 64
  %668 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load613, 0
  %669 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load613, 1
  %670 = mul <8 x i64> %657, splat (i64 32)
  %671 = add <8 x i64> %669, %670
  %672 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %668, 0
  %673 = insertvalue { <8 x ptr>, <8 x i64> } %672, <8 x i64> %671, 1
  %674 = extractvalue { <8 x ptr>, <8 x i64> } %673, 0
  %675 = extractvalue { <8 x ptr>, <8 x i64> } %673, 1
  %676 = getelementptr i8, <8 x ptr> %674, <8 x i64> %675
  %677 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %676, i32 1, <8 x i1> %643, <8 x float> zeroinitializer)
  %678 = fadd <8 x float> %667, %677
  %tile_snapshot.spill.load614 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %679 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load614, 0
  %680 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load614, 1
  %.state615 = load <8 x i64>, ptr %.slot80, align 64
  %681 = mul <8 x i64> %.state615, splat (i64 32)
  %682 = add <8 x i64> %680, %681
  %683 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %679, 0
  %684 = insertvalue { <8 x ptr>, <8 x i64> } %683, <8 x i64> %682, 1
  %685 = extractvalue { <8 x ptr>, <8 x i64> } %684, 0
  %686 = extractvalue { <8 x ptr>, <8 x i64> } %684, 1
  %687 = getelementptr i8, <8 x ptr> %685, <8 x i64> %686
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %678, <8 x ptr> %687, i32 1, <8 x i1> %643)
  %.state616 = load <8 x i64>, ptr %.slot80, align 64
  %688 = add <8 x i64> %.state616, splat (i64 1)
  %689 = load <8 x i64>, ptr %.slot80, align 64
  %690 = select <8 x i1> %643, <8 x i64> %688, <8 x i64> %689
  store <8 x i64> %690, ptr %.slot80, align 64
  store <8 x i1> %643, ptr %current.mask, align 1
  %691 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %643)
  br i1 %691, label %schedule.27, label %scheduler.loop

schedule.29:                                      ; preds = %varying.coherent.false609, %scheduler.dispatch.route
  %692 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token619 = load i32, ptr %current.token, align 4
  %convergence.token.present620 = icmp ne i32 %convergence.current.token619, 0
  br i1 %convergence.token.present620, label %convergence.cascade617, label %convergence.cascade.exit618

schedule.30:                                      ; preds = %convergence.target.33.ready, %convergence.target.29.ready, %scheduler.dispatch.route
  %693 = load <8 x i1>, ptr %current.mask, align 1
  %694 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %693)
  %695 = bitcast <8 x i1> %693 to i8
  %696 = call i8 @llvm.cttz.i8(i8 %695, i1 false)
  %697 = zext i8 %696 to i32
  %698 = select i1 %694, i32 %697, i32 0
  %.state698 = load <8 x i64>, ptr %.slot83, align 64
  %699 = icmp slt <8 x i64> %.state698, splat (i64 128)
  %700 = and <8 x i1> %693, %699
  %701 = xor <8 x i1> %699, splat (i1 true)
  %702 = and <8 x i1> %693, %701
  %703 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %700)
  %704 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %702)
  %705 = and i1 %703, %704
  br i1 %705, label %varying.divergent699, label %varying.coherent700

schedule.31:                                      ; preds = %varying.coherent.true705, %scheduler.dispatch.route
  %706 = load <8 x i1>, ptr %current.mask, align 1
  %707 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %706)
  %708 = bitcast <8 x i1> %706 to i8
  %709 = call i8 @llvm.cttz.i8(i8 %708, i1 false)
  %710 = zext i8 %709 to i32
  %711 = select i1 %707, i32 %710, i32 0
  %.state707 = load <8 x i64>, ptr %.slot83, align 64
  %712 = select <8 x i1> %706, <8 x i64> %.state707, <8 x i64> zeroinitializer
  %713 = select <8 x i1> %706, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %714 = srem <8 x i64> %712, %713
  %.state708 = load <8 x i64>, ptr %.slot83, align 64
  %715 = select <8 x i1> %706, <8 x i64> %.state708, <8 x i64> zeroinitializer
  %716 = select <8 x i1> %706, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %717 = sdiv <8 x i64> %715, %716
  %.spill.load709 = load i64, ptr %.spill54, align 4
  %.splatinsert710 = insertelement <8 x i64> poison, i64 %.spill.load709, i64 0
  %.splat711 = shufflevector <8 x i64> %.splatinsert710, <8 x i64> poison, <8 x i32> zeroinitializer
  %718 = add <8 x i64> %.splat711, %714
  %tile_snapshot.spill.load712 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill81, align 64
  %719 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load712, 0
  %720 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load712, 1
  %721 = mul <8 x i64> %718, splat (i64 64)
  %722 = add <8 x i64> %720, %721
  %723 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %719, 0
  %724 = insertvalue { <8 x ptr>, <8 x i64> } %723, <8 x i64> %722, 1
  %725 = extractvalue { <8 x ptr>, <8 x i64> } %724, 0
  %726 = extractvalue { <8 x ptr>, <8 x i64> } %724, 1
  %727 = getelementptr i8, <8 x ptr> %725, <8 x i64> %726
  %728 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> %727, i32 1, <8 x i1> %706, <8 x i64> zeroinitializer)
  %729 = icmp sge <8 x i64> %728, zeroinitializer
  %730 = icmp slt <8 x i64> %728, splat (i64 32)
  %731 = and <8 x i1> %729, %730
  %732 = load volatile <8 x i1>, ptr %.spill84, align 1
  %733 = select <8 x i1> %706, <8 x i1> %731, <8 x i1> %732
  store volatile <8 x i1> %733, ptr %.spill84, align 1
  %734 = add <8 x i64> zeroinitializer, %717
  %735 = mul <8 x i64> %734, splat (i64 32)
  %736 = add <8 x i64> %735, %728
  %737 = load volatile <8 x i64>, ptr %.spill85, align 64
  %738 = select <8 x i1> %706, <8 x i64> %736, <8 x i64> %737
  store volatile <8 x i64> %738, ptr %.spill85, align 64
  %739 = icmp sge <8 x i64> %736, zeroinitializer
  %740 = icmp slt <8 x i64> %736, splat (i64 128)
  %741 = and <8 x i1> %739, %740
  %742 = and <8 x i1> %706, %741
  %743 = xor <8 x i1> %741, splat (i1 true)
  %744 = and <8 x i1> %706, %743
  %745 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %742)
  %746 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %744)
  %747 = and i1 %745, %746
  br i1 %747, label %varying.divergent713, label %varying.coherent714

schedule.32:                                      ; preds = %varying.coherent.true719, %scheduler.dispatch.route
  %748 = load <8 x i1>, ptr %current.mask, align 1
  %749 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %748)
  %750 = bitcast <8 x i1> %748 to i8
  %751 = call i8 @llvm.cttz.i8(i8 %750, i1 false)
  %752 = zext i8 %751 to i32
  %753 = select i1 %749, i32 %752, i32 0
  %tile_snapshot.spill.load721 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %754 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load721, 0
  %755 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load721, 1
  %.spill.load722 = load volatile <8 x i64>, ptr %.spill85, align 64
  %756 = mul <8 x i64> %.spill.load722, splat (i64 32)
  %757 = add <8 x i64> %755, %756
  %758 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %754, 0
  %759 = insertvalue { <8 x ptr>, <8 x i64> } %758, <8 x i64> %757, 1
  %760 = extractvalue { <8 x ptr>, <8 x i64> } %759, 0
  %761 = extractvalue { <8 x ptr>, <8 x i64> } %759, 1
  %762 = getelementptr i8, <8 x ptr> %760, <8 x i64> %761
  %763 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %762, i32 1, <8 x i1> %748, <8 x float> zeroinitializer)
  %764 = load <8 x float>, ptr %.slot86, align 32
  %765 = select <8 x i1> %748, <8 x float> %763, <8 x float> %764
  store <8 x float> %765, ptr %.slot86, align 32
  store <8 x i1> %748, ptr %current.mask, align 1
  %766 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %748)
  br i1 %766, label %schedule.33, label %scheduler.loop

schedule.33:                                      ; preds = %schedule.32, %varying.coherent.false720, %scheduler.dispatch.route
  %767 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token725 = load i32, ptr %current.token, align 4
  %convergence.token.present726 = icmp ne i32 %convergence.current.token725, 0
  br i1 %convergence.token.present726, label %convergence.cascade723, label %convergence.cascade.exit724

schedule.34:                                      ; preds = %varying.coherent.false706, %scheduler.dispatch.route
  %768 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token750 = load i32, ptr %current.token, align 4
  %convergence.token.present751 = icmp ne i32 %convergence.current.token750, 0
  br i1 %convergence.token.present751, label %convergence.cascade748, label %convergence.cascade.exit749

schedule.35:                                      ; preds = %schedule.36, %convergence.target.34.ready, %scheduler.dispatch.route
  %769 = load <8 x i1>, ptr %current.mask, align 1
  %770 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %769)
  %771 = bitcast <8 x i1> %769 to i8
  %772 = call i8 @llvm.cttz.i8(i8 %771, i1 false)
  %773 = zext i8 %772 to i32
  %774 = select i1 %770, i32 %773, i32 0
  %.state765 = load <8 x i64>, ptr %.slot88, align 64
  %775 = icmp slt <8 x i64> %.state765, splat (i64 128)
  %776 = and <8 x i1> %769, %775
  %777 = xor <8 x i1> %775, splat (i1 true)
  %778 = and <8 x i1> %769, %777
  %779 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %776)
  %780 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %778)
  %781 = and i1 %779, %780
  br i1 %781, label %varying.divergent766, label %varying.coherent767

schedule.36:                                      ; preds = %varying.coherent.true772, %scheduler.dispatch.route
  %782 = load <8 x i1>, ptr %current.mask, align 1
  %783 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %782)
  %784 = bitcast <8 x i1> %782 to i8
  %785 = call i8 @llvm.cttz.i8(i8 %784, i1 false)
  %786 = zext i8 %785 to i32
  %787 = select i1 %783, i32 %786, i32 0
  %.state774 = load <8 x i64>, ptr %.slot88, align 64
  %788 = select <8 x i1> %782, <8 x i64> %.state774, <8 x i64> zeroinitializer
  %789 = select <8 x i1> %782, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %790 = srem <8 x i64> %788, %789
  %.state775 = load <8 x i64>, ptr %.slot88, align 64
  %791 = select <8 x i1> %782, <8 x i64> %.state775, <8 x i64> zeroinitializer
  %792 = select <8 x i1> %782, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %793 = sdiv <8 x i64> %791, %792
  %794 = add <8 x i64> zeroinitializer, %793
  %795 = mul <8 x i64> %794, splat (i64 32)
  %796 = add <8 x i64> %795, %790
  %tile_snapshot.spill.load776 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %797 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load776, 0
  %798 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load776, 1
  %799 = mul <8 x i64> %796, splat (i64 32)
  %800 = add <8 x i64> %798, %799
  %801 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %797, 0
  %802 = insertvalue { <8 x ptr>, <8 x i64> } %801, <8 x i64> %800, 1
  %803 = extractvalue { <8 x ptr>, <8 x i64> } %802, 0
  %804 = extractvalue { <8 x ptr>, <8 x i64> } %802, 1
  %805 = getelementptr i8, <8 x ptr> %803, <8 x i64> %804
  %806 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %805, i32 1, <8 x i1> %782, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load777 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill82, align 64
  %807 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load777, 0
  %808 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load777, 1
  %809 = mul <8 x i64> %796, splat (i64 32)
  %810 = add <8 x i64> %808, %809
  %811 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %807, 0
  %812 = insertvalue { <8 x ptr>, <8 x i64> } %811, <8 x i64> %810, 1
  %813 = extractvalue { <8 x ptr>, <8 x i64> } %812, 0
  %814 = extractvalue { <8 x ptr>, <8 x i64> } %812, 1
  %815 = getelementptr i8, <8 x ptr> %813, <8 x i64> %814
  %816 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %815, i32 1, <8 x i1> %782, <8 x float> zeroinitializer)
  %817 = fadd <8 x float> %806, %816
  %tile_snapshot.spill.load778 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %818 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load778, 0
  %819 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load778, 1
  %.state779 = load <8 x i64>, ptr %.slot88, align 64
  %820 = mul <8 x i64> %.state779, splat (i64 32)
  %821 = add <8 x i64> %819, %820
  %822 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %818, 0
  %823 = insertvalue { <8 x ptr>, <8 x i64> } %822, <8 x i64> %821, 1
  %824 = extractvalue { <8 x ptr>, <8 x i64> } %823, 0
  %825 = extractvalue { <8 x ptr>, <8 x i64> } %823, 1
  %826 = getelementptr i8, <8 x ptr> %824, <8 x i64> %825
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %817, <8 x ptr> %826, i32 1, <8 x i1> %782)
  %.state780 = load <8 x i64>, ptr %.slot88, align 64
  %827 = add <8 x i64> %.state780, splat (i64 1)
  %828 = load <8 x i64>, ptr %.slot88, align 64
  %829 = select <8 x i1> %782, <8 x i64> %827, <8 x i64> %828
  store <8 x i64> %829, ptr %.slot88, align 64
  store <8 x i1> %782, ptr %current.mask, align 1
  %830 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %782)
  br i1 %830, label %schedule.35, label %scheduler.loop

schedule.37:                                      ; preds = %varying.coherent.false773, %scheduler.dispatch.route
  %831 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token783 = load i32, ptr %current.token, align 4
  %convergence.token.present784 = icmp ne i32 %convergence.current.token783, 0
  br i1 %convergence.token.present784, label %convergence.cascade781, label %convergence.cascade.exit782

schedule.38:                                      ; preds = %convergence.target.41.ready, %convergence.target.37.ready, %scheduler.dispatch.route
  %832 = load <8 x i1>, ptr %current.mask, align 1
  %833 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %832)
  %834 = bitcast <8 x i1> %832 to i8
  %835 = call i8 @llvm.cttz.i8(i8 %834, i1 false)
  %836 = zext i8 %835 to i32
  %837 = select i1 %833, i32 %836, i32 0
  %.state862 = load <8 x i64>, ptr %.slot91, align 64
  %838 = icmp slt <8 x i64> %.state862, splat (i64 128)
  %839 = and <8 x i1> %832, %838
  %840 = xor <8 x i1> %838, splat (i1 true)
  %841 = and <8 x i1> %832, %840
  %842 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %839)
  %843 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %841)
  %844 = and i1 %842, %843
  br i1 %844, label %varying.divergent863, label %varying.coherent864

schedule.39:                                      ; preds = %varying.coherent.true869, %scheduler.dispatch.route
  %845 = load <8 x i1>, ptr %current.mask, align 1
  %846 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %845)
  %847 = bitcast <8 x i1> %845 to i8
  %848 = call i8 @llvm.cttz.i8(i8 %847, i1 false)
  %849 = zext i8 %848 to i32
  %850 = select i1 %846, i32 %849, i32 0
  %.state871 = load <8 x i64>, ptr %.slot91, align 64
  %851 = select <8 x i1> %845, <8 x i64> %.state871, <8 x i64> zeroinitializer
  %852 = select <8 x i1> %845, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %853 = srem <8 x i64> %851, %852
  %.state872 = load <8 x i64>, ptr %.slot91, align 64
  %854 = select <8 x i1> %845, <8 x i64> %.state872, <8 x i64> zeroinitializer
  %855 = select <8 x i1> %845, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %856 = sdiv <8 x i64> %854, %855
  %.spill.load873 = load i64, ptr %.spill54, align 4
  %.splatinsert874 = insertelement <8 x i64> poison, i64 %.spill.load873, i64 0
  %.splat875 = shufflevector <8 x i64> %.splatinsert874, <8 x i64> poison, <8 x i32> zeroinitializer
  %857 = add <8 x i64> %.splat875, %853
  %tile_snapshot.spill.load876 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill89, align 64
  %858 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load876, 0
  %859 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load876, 1
  %860 = mul <8 x i64> %857, splat (i64 64)
  %861 = add <8 x i64> %859, %860
  %862 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %858, 0
  %863 = insertvalue { <8 x ptr>, <8 x i64> } %862, <8 x i64> %861, 1
  %864 = extractvalue { <8 x ptr>, <8 x i64> } %863, 0
  %865 = extractvalue { <8 x ptr>, <8 x i64> } %863, 1
  %866 = getelementptr i8, <8 x ptr> %864, <8 x i64> %865
  %867 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> %866, i32 1, <8 x i1> %845, <8 x i64> zeroinitializer)
  %868 = icmp sge <8 x i64> %867, zeroinitializer
  %869 = icmp slt <8 x i64> %867, splat (i64 32)
  %870 = and <8 x i1> %868, %869
  %871 = load volatile <8 x i1>, ptr %.spill92, align 1
  %872 = select <8 x i1> %845, <8 x i1> %870, <8 x i1> %871
  store volatile <8 x i1> %872, ptr %.spill92, align 1
  %873 = add <8 x i64> zeroinitializer, %856
  %874 = mul <8 x i64> %873, splat (i64 32)
  %875 = add <8 x i64> %874, %867
  %876 = load volatile <8 x i64>, ptr %.spill93, align 64
  %877 = select <8 x i1> %845, <8 x i64> %875, <8 x i64> %876
  store volatile <8 x i64> %877, ptr %.spill93, align 64
  %878 = icmp sge <8 x i64> %875, zeroinitializer
  %879 = icmp slt <8 x i64> %875, splat (i64 128)
  %880 = and <8 x i1> %878, %879
  %881 = and <8 x i1> %845, %880
  %882 = xor <8 x i1> %880, splat (i1 true)
  %883 = and <8 x i1> %845, %882
  %884 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %881)
  %885 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %883)
  %886 = and i1 %884, %885
  br i1 %886, label %varying.divergent877, label %varying.coherent878

schedule.40:                                      ; preds = %varying.coherent.true883, %scheduler.dispatch.route
  %887 = load <8 x i1>, ptr %current.mask, align 1
  %888 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %887)
  %889 = bitcast <8 x i1> %887 to i8
  %890 = call i8 @llvm.cttz.i8(i8 %889, i1 false)
  %891 = zext i8 %890 to i32
  %892 = select i1 %888, i32 %891, i32 0
  %tile_snapshot.spill.load885 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %893 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load885, 0
  %894 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load885, 1
  %.spill.load886 = load volatile <8 x i64>, ptr %.spill93, align 64
  %895 = mul <8 x i64> %.spill.load886, splat (i64 32)
  %896 = add <8 x i64> %894, %895
  %897 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %893, 0
  %898 = insertvalue { <8 x ptr>, <8 x i64> } %897, <8 x i64> %896, 1
  %899 = extractvalue { <8 x ptr>, <8 x i64> } %898, 0
  %900 = extractvalue { <8 x ptr>, <8 x i64> } %898, 1
  %901 = getelementptr i8, <8 x ptr> %899, <8 x i64> %900
  %902 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %901, i32 1, <8 x i1> %887, <8 x float> zeroinitializer)
  %903 = load <8 x float>, ptr %.slot94, align 32
  %904 = select <8 x i1> %887, <8 x float> %902, <8 x float> %903
  store <8 x float> %904, ptr %.slot94, align 32
  store <8 x i1> %887, ptr %current.mask, align 1
  %905 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %887)
  br i1 %905, label %schedule.41, label %scheduler.loop

schedule.41:                                      ; preds = %schedule.40, %varying.coherent.false884, %scheduler.dispatch.route
  %906 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token889 = load i32, ptr %current.token, align 4
  %convergence.token.present890 = icmp ne i32 %convergence.current.token889, 0
  br i1 %convergence.token.present890, label %convergence.cascade887, label %convergence.cascade.exit888

schedule.42:                                      ; preds = %varying.coherent.false870, %scheduler.dispatch.route
  %907 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token914 = load i32, ptr %current.token, align 4
  %convergence.token.present915 = icmp ne i32 %convergence.current.token914, 0
  br i1 %convergence.token.present915, label %convergence.cascade912, label %convergence.cascade.exit913

schedule.43:                                      ; preds = %schedule.44, %convergence.target.42.ready, %scheduler.dispatch.route
  %908 = load <8 x i1>, ptr %current.mask, align 1
  %909 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %908)
  %910 = bitcast <8 x i1> %908 to i8
  %911 = call i8 @llvm.cttz.i8(i8 %910, i1 false)
  %912 = zext i8 %911 to i32
  %913 = select i1 %909, i32 %912, i32 0
  %.state929 = load <8 x i64>, ptr %.slot96, align 64
  %914 = icmp slt <8 x i64> %.state929, splat (i64 128)
  %915 = and <8 x i1> %908, %914
  %916 = xor <8 x i1> %914, splat (i1 true)
  %917 = and <8 x i1> %908, %916
  %918 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %915)
  %919 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %917)
  %920 = and i1 %918, %919
  br i1 %920, label %varying.divergent930, label %varying.coherent931

schedule.44:                                      ; preds = %varying.coherent.true936, %scheduler.dispatch.route
  %921 = load <8 x i1>, ptr %current.mask, align 1
  %922 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %921)
  %923 = bitcast <8 x i1> %921 to i8
  %924 = call i8 @llvm.cttz.i8(i8 %923, i1 false)
  %925 = zext i8 %924 to i32
  %926 = select i1 %922, i32 %925, i32 0
  %.state938 = load <8 x i64>, ptr %.slot96, align 64
  %927 = select <8 x i1> %921, <8 x i64> %.state938, <8 x i64> zeroinitializer
  %928 = select <8 x i1> %921, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %929 = srem <8 x i64> %927, %928
  %.state939 = load <8 x i64>, ptr %.slot96, align 64
  %930 = select <8 x i1> %921, <8 x i64> %.state939, <8 x i64> zeroinitializer
  %931 = select <8 x i1> %921, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %932 = sdiv <8 x i64> %930, %931
  %933 = add <8 x i64> zeroinitializer, %932
  %934 = mul <8 x i64> %933, splat (i64 32)
  %935 = add <8 x i64> %934, %929
  %936 = select <8 x i1> %921, <8 x i64> %935, <8 x i64> zeroinitializer
  %937 = select <8 x i1> %921, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %938 = srem <8 x i64> %936, %937
  %939 = select <8 x i1> %921, <8 x i64> %935, <8 x i64> zeroinitializer
  %940 = select <8 x i1> %921, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %941 = sdiv <8 x i64> %939, %940
  %942 = add <8 x i64> zeroinitializer, %941
  %943 = mul <8 x i64> %942, splat (i64 32)
  %944 = add <8 x i64> %943, %938
  %tile_snapshot.spill.load940 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %945 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load940, 0
  %946 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load940, 1
  %947 = mul <8 x i64> %944, splat (i64 32)
  %948 = add <8 x i64> %946, %947
  %949 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %945, 0
  %950 = insertvalue { <8 x ptr>, <8 x i64> } %949, <8 x i64> %948, 1
  %951 = extractvalue { <8 x ptr>, <8 x i64> } %950, 0
  %952 = extractvalue { <8 x ptr>, <8 x i64> } %950, 1
  %953 = getelementptr i8, <8 x ptr> %951, <8 x i64> %952
  %954 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %953, i32 1, <8 x i1> %921, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load941 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill90, align 64
  %955 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load941, 0
  %956 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load941, 1
  %957 = mul <8 x i64> %944, splat (i64 32)
  %958 = add <8 x i64> %956, %957
  %959 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %955, 0
  %960 = insertvalue { <8 x ptr>, <8 x i64> } %959, <8 x i64> %958, 1
  %961 = extractvalue { <8 x ptr>, <8 x i64> } %960, 0
  %962 = extractvalue { <8 x ptr>, <8 x i64> } %960, 1
  %963 = getelementptr i8, <8 x ptr> %961, <8 x i64> %962
  %964 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %963, i32 1, <8 x i1> %921, <8 x float> zeroinitializer)
  %965 = fadd <8 x float> %954, %964
  %tile_snapshot.spill.load942 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %966 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load942, 0
  %967 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load942, 1
  %968 = mul <8 x i64> %933, splat (i64 32)
  %969 = add <8 x i64> %967, %968
  %970 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %966, 0
  %971 = insertvalue { <8 x ptr>, <8 x i64> } %970, <8 x i64> %969, 1
  %972 = extractvalue { <8 x ptr>, <8 x i64> } %971, 0
  %973 = extractvalue { <8 x ptr>, <8 x i64> } %971, 1
  %974 = getelementptr i8, <8 x ptr> %972, <8 x i64> %973
  %975 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %974, i32 1, <8 x i1> %921, <8 x float> zeroinitializer)
  %976 = fadd <8 x float> %965, %975
  %tile_snapshot.spill.load943 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %977 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load943, 0
  %978 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load943, 1
  %.state944 = load <8 x i64>, ptr %.slot96, align 64
  %979 = mul <8 x i64> %.state944, splat (i64 32)
  %980 = add <8 x i64> %978, %979
  %981 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %977, 0
  %982 = insertvalue { <8 x ptr>, <8 x i64> } %981, <8 x i64> %980, 1
  %983 = extractvalue { <8 x ptr>, <8 x i64> } %982, 0
  %984 = extractvalue { <8 x ptr>, <8 x i64> } %982, 1
  %985 = getelementptr i8, <8 x ptr> %983, <8 x i64> %984
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %976, <8 x ptr> %985, i32 1, <8 x i1> %921)
  %.state945 = load <8 x i64>, ptr %.slot96, align 64
  %986 = add <8 x i64> %.state945, splat (i64 1)
  %987 = load <8 x i64>, ptr %.slot96, align 64
  %988 = select <8 x i1> %921, <8 x i64> %986, <8 x i64> %987
  store <8 x i64> %988, ptr %.slot96, align 64
  store <8 x i1> %921, ptr %current.mask, align 1
  %989 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %921)
  br i1 %989, label %schedule.43, label %scheduler.loop

schedule.45:                                      ; preds = %varying.coherent.false937, %scheduler.dispatch.route
  %990 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token948 = load i32, ptr %current.token, align 4
  %convergence.token.present949 = icmp ne i32 %convergence.current.token948, 0
  br i1 %convergence.token.present949, label %convergence.cascade946, label %convergence.cascade.exit947

schedule.46:                                      ; preds = %schedule.47, %convergence.target.45.ready, %scheduler.dispatch.route
  %991 = load <8 x i1>, ptr %current.mask, align 1
  %992 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %991)
  %993 = bitcast <8 x i1> %991 to i8
  %994 = call i8 @llvm.cttz.i8(i8 %993, i1 false)
  %995 = zext i8 %994 to i32
  %996 = select i1 %992, i32 %995, i32 0
  %.state963 = load <8 x i64>, ptr %.slot97, align 64
  %997 = icmp slt <8 x i64> %.state963, splat (i64 128)
  %998 = and <8 x i1> %991, %997
  %999 = xor <8 x i1> %997, splat (i1 true)
  %1000 = and <8 x i1> %991, %999
  %1001 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %998)
  %1002 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1000)
  %1003 = and i1 %1001, %1002
  br i1 %1003, label %varying.divergent964, label %varying.coherent965

schedule.47:                                      ; preds = %varying.coherent.true970, %scheduler.dispatch.route
  %1004 = load <8 x i1>, ptr %current.mask, align 1
  %1005 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1004)
  %1006 = bitcast <8 x i1> %1004 to i8
  %1007 = call i8 @llvm.cttz.i8(i8 %1006, i1 false)
  %1008 = zext i8 %1007 to i32
  %1009 = select i1 %1005, i32 %1008, i32 0
  %.state972 = load <8 x i64>, ptr %.slot97, align 64
  %1010 = select <8 x i1> %1004, <8 x i64> %.state972, <8 x i64> zeroinitializer
  %1011 = select <8 x i1> %1004, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %1012 = srem <8 x i64> %1010, %1011
  %.state973 = load <8 x i64>, ptr %.slot97, align 64
  %1013 = select <8 x i1> %1004, <8 x i64> %.state973, <8 x i64> zeroinitializer
  %1014 = select <8 x i1> %1004, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %1015 = sdiv <8 x i64> %1013, %1014
  %.spill.load974 = load volatile <8 x i64>, ptr %.spill, align 64
  %1016 = add <8 x i64> %.spill.load974, %1015
  %1017 = add <8 x i64> zeroinitializer, %1016
  %.spill.load975 = load i64, ptr %.spill54, align 4
  %.splatinsert976 = insertelement <8 x i64> poison, i64 %.spill.load975, i64 0
  %.splat977 = shufflevector <8 x i64> %.splatinsert976, <8 x i64> poison, <8 x i32> zeroinitializer
  %1018 = add <8 x i64> %.splat977, %1012
  %1019 = mul <8 x i64> %1017, splat (i64 32)
  %1020 = add <8 x i64> %1019, %1018
  %tile_snapshot.spill.load978 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %1021 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load978, 0
  %1022 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load978, 1
  %.state979 = load <8 x i64>, ptr %.slot97, align 64
  %1023 = mul <8 x i64> %.state979, splat (i64 32)
  %1024 = add <8 x i64> %1022, %1023
  %1025 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1021, 0
  %1026 = insertvalue { <8 x ptr>, <8 x i64> } %1025, <8 x i64> %1024, 1
  %1027 = extractvalue { <8 x ptr>, <8 x i64> } %1026, 0
  %1028 = extractvalue { <8 x ptr>, <8 x i64> } %1026, 1
  %1029 = getelementptr i8, <8 x ptr> %1027, <8 x i64> %1028
  %1030 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %1029, i32 1, <8 x i1> %1004, <8 x float> zeroinitializer)
  %1031 = extractvalue { ptr, i64 } %45, 0
  %1032 = mul <8 x i64> %1020, splat (i64 4)
  %1033 = getelementptr i8, ptr %1031, <8 x i64> %1032
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1030, <8 x ptr> %1033, i32 1, <8 x i1> %1004)
  %.state980 = load <8 x i64>, ptr %.slot97, align 64
  %1034 = add <8 x i64> %.state980, splat (i64 1)
  %1035 = load <8 x i64>, ptr %.slot97, align 64
  %1036 = select <8 x i1> %1004, <8 x i64> %1034, <8 x i64> %1035
  store <8 x i64> %1036, ptr %.slot97, align 64
  store <8 x i1> %1004, ptr %current.mask, align 1
  %1037 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1004)
  br i1 %1037, label %schedule.46, label %scheduler.loop

schedule.48:                                      ; preds = %varying.coherent.false971, %scheduler.dispatch.route
  %1038 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token983 = load i32, ptr %current.token, align 4
  %convergence.token.present984 = icmp ne i32 %convergence.current.token983, 0
  br i1 %convergence.token.present984, label %convergence.cascade981, label %convergence.cascade.exit982

schedule.49:                                      ; preds = %varying.coherent.false, %scheduler.dispatch.route
  %1039 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1012 = load i32, ptr %current.token, align 4
  %convergence.token.present1013 = icmp ne i32 %convergence.current.token1012, 0
  br i1 %convergence.token.present1013, label %convergence.cascade1010, label %convergence.cascade.exit1011

varying.divergent:                                ; preds = %schedule.1
  %1040 = load i32, ptr %current.token, align 4
  %1041 = icmp ne i32 %1040, 0
  %1042 = sub i32 %1040, 1
  %1043 = select i1 %1041, i32 %1042, i32 0
  %1044 = load i8, ptr %frame.active, align 1
  %1045 = trunc i32 %1043 to i8
  %1046 = shl i8 1, %1045
  %1047 = and i8 %1044, %1046
  %1048 = icmp ne i8 %1047, 0
  %1049 = load <8 x i32>, ptr %frame.static.id, align 32
  %1050 = extractelement <8 x i32> %1049, i32 %1043
  %1051 = icmp eq i32 %1050, 0
  %1052 = and i1 %1048, %1051
  %1053 = and i1 %1041, %1052
  %1054 = xor i1 %1053, true
  %1055 = and i1 true, %1054
  %1056 = xor i8 %1044, -1
  %1057 = icmp ne i8 %1056, 0
  %1058 = xor i1 %1057, true
  %1059 = and i1 %1055, %1058
  br i1 %1059, label %convergence.overflow.trap, label %convergence.overflow.resume

varying.coherent:                                 ; preds = %schedule.1
  br i1 %138, label %varying.coherent.true, label %varying.coherent.false

convergence.overflow.trap:                        ; preds = %varying.divergent
  call void @llvm.trap()
  unreachable

convergence.overflow.resume:                      ; preds = %varying.divergent
  %1060 = call i8 @llvm.cttz.i8(i8 %1056, i1 false)
  %1061 = zext i8 %1060 to i32
  %1062 = select i1 %1057, i32 %1061, i32 0
  %1063 = trunc i32 %1062 to i8
  %1064 = shl i8 1, %1063
  %1065 = or i8 %1044, %1064
  %1066 = select i1 %1055, i8 %1065, i8 %1044
  store i8 %1066, ptr %frame.active, align 1
  %1067 = load <8 x i32>, ptr %frame.static.id, align 32
  %1068 = extractelement <8 x i32> %1067, i32 %1062
  %1069 = select i1 %1055, i32 0, i32 %1068
  %1070 = load <8 x i32>, ptr %frame.static.id, align 32
  %1071 = insertelement <8 x i32> %1070, i32 %1069, i32 %1062
  store <8 x i32> %1071, ptr %frame.static.id, align 32
  %1072 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1073 = extractelement <8 x i32> %1072, i32 %1062
  %1074 = select i1 %1055, i32 %1040, i32 %1073
  %1075 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1076 = insertelement <8 x i32> %1075, i32 %1074, i32 %1062
  store <8 x i32> %1076, ptr %frame.parent.token, align 32
  %1077 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1062
  %1078 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1062
  %1079 = load <8 x i1>, ptr %1077, align 1
  %1080 = load <8 x i1>, ptr %1078, align 1
  %1081 = select i1 %1055, <8 x i1> %128, <8 x i1> %1079
  store <8 x i1> %1081, ptr %1077, align 1
  %1082 = select i1 %1055, <8 x i1> zeroinitializer, <8 x i1> %1080
  store <8 x i1> %1082, ptr %1078, align 1
  %1083 = add i32 %1062, 1
  %1084 = select i1 %1053, i32 %1040, i32 %1083
  %1085 = select i1 true, i32 %1084, i32 %1040
  store i32 %1085, ptr %current.token, align 4
  %1086 = load i32, ptr %current.token, align 4
  %1087 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %135)
  %1088 = load i32, ptr %ready.count, align 4
  %1089 = icmp uge i32 %1088, 8
  %1090 = and i1 %1087, %1089
  br i1 %1090, label %ready.overflow.trap108, label %ready.overflow.resume109

ready.overflow.trap108:                           ; preds = %convergence.overflow.resume
  call void @llvm.trap()
  unreachable

ready.overflow.resume109:                         ; preds = %convergence.overflow.resume
  %1091 = select i1 %1087, i32 %1088, i32 0
  %1092 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1091
  %1093 = load <8 x i1>, ptr %1092, align 1
  %1094 = select i1 %1087, <8 x i1> %135, <8 x i1> %1093
  store <8 x i1> %1094, ptr %1092, align 1
  %1095 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1091
  %1096 = load i32, ptr %1095, align 4
  %1097 = select i1 %1087, i32 2, i32 %1096
  store i32 %1097, ptr %1095, align 4
  %1098 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1091
  %1099 = load i32, ptr %1098, align 4
  %1100 = select i1 %1087, i32 %1086, i32 %1099
  store i32 %1100, ptr %1098, align 4
  %1101 = add i32 %1088, 1
  %1102 = select i1 %1087, i32 %1101, i32 %1088
  store i32 %1102, ptr %ready.count, align 4
  %1103 = load <8 x i1>, ptr %runnable.mask, align 1
  %1104 = or <8 x i1> %1103, %135
  store <8 x i1> %1104, ptr %runnable.mask, align 1
  store <8 x i1> %137, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true:                            ; preds = %varying.coherent
  store <8 x i1> %128, ptr %current.mask, align 1
  %1105 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %128)
  br i1 %1105, label %schedule.2, label %scheduler.loop

varying.coherent.false:                           ; preds = %varying.coherent
  store <8 x i1> %128, ptr %current.mask, align 1
  %1106 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %128)
  br i1 %1106, label %schedule.49, label %scheduler.loop

varying.divergent121:                             ; preds = %schedule.3
  %1107 = load i32, ptr %current.token, align 4
  %1108 = icmp ne i32 %1107, 0
  %1109 = sub i32 %1107, 1
  %1110 = select i1 %1108, i32 %1109, i32 0
  %1111 = load i8, ptr %frame.active, align 1
  %1112 = trunc i32 %1110 to i8
  %1113 = shl i8 1, %1112
  %1114 = and i8 %1111, %1113
  %1115 = icmp ne i8 %1114, 0
  %1116 = load <8 x i32>, ptr %frame.static.id, align 32
  %1117 = extractelement <8 x i32> %1116, i32 %1110
  %1118 = icmp eq i32 %1117, 1
  %1119 = and i1 %1115, %1118
  %1120 = and i1 %1108, %1119
  %1121 = xor i1 %1120, true
  %1122 = and i1 true, %1121
  %1123 = xor i8 %1111, -1
  %1124 = icmp ne i8 %1123, 0
  %1125 = xor i1 %1124, true
  %1126 = and i1 %1122, %1125
  br i1 %1126, label %convergence.overflow.trap123, label %convergence.overflow.resume124

varying.coherent122:                              ; preds = %schedule.3
  br i1 %238, label %varying.coherent.true127, label %varying.coherent.false128

convergence.overflow.trap123:                     ; preds = %varying.divergent121
  call void @llvm.trap()
  unreachable

convergence.overflow.resume124:                   ; preds = %varying.divergent121
  %1127 = call i8 @llvm.cttz.i8(i8 %1123, i1 false)
  %1128 = zext i8 %1127 to i32
  %1129 = select i1 %1124, i32 %1128, i32 0
  %1130 = trunc i32 %1129 to i8
  %1131 = shl i8 1, %1130
  %1132 = or i8 %1111, %1131
  %1133 = select i1 %1122, i8 %1132, i8 %1111
  store i8 %1133, ptr %frame.active, align 1
  %1134 = load <8 x i32>, ptr %frame.static.id, align 32
  %1135 = extractelement <8 x i32> %1134, i32 %1129
  %1136 = select i1 %1122, i32 1, i32 %1135
  %1137 = load <8 x i32>, ptr %frame.static.id, align 32
  %1138 = insertelement <8 x i32> %1137, i32 %1136, i32 %1129
  store <8 x i32> %1138, ptr %frame.static.id, align 32
  %1139 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1140 = extractelement <8 x i32> %1139, i32 %1129
  %1141 = select i1 %1122, i32 %1107, i32 %1140
  %1142 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1143 = insertelement <8 x i32> %1142, i32 %1141, i32 %1129
  store <8 x i32> %1143, ptr %frame.parent.token, align 32
  %1144 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1129
  %1145 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1129
  %1146 = load <8 x i1>, ptr %1144, align 1
  %1147 = load <8 x i1>, ptr %1145, align 1
  %1148 = select i1 %1122, <8 x i1> %228, <8 x i1> %1146
  store <8 x i1> %1148, ptr %1144, align 1
  %1149 = select i1 %1122, <8 x i1> zeroinitializer, <8 x i1> %1147
  store <8 x i1> %1149, ptr %1145, align 1
  %1150 = add i32 %1129, 1
  %1151 = select i1 %1120, i32 %1107, i32 %1150
  %1152 = select i1 true, i32 %1151, i32 %1107
  store i32 %1152, ptr %current.token, align 4
  %1153 = load i32, ptr %current.token, align 4
  %1154 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %235)
  %1155 = load i32, ptr %ready.count, align 4
  %1156 = icmp uge i32 %1155, 8
  %1157 = and i1 %1154, %1156
  br i1 %1157, label %ready.overflow.trap125, label %ready.overflow.resume126

ready.overflow.trap125:                           ; preds = %convergence.overflow.resume124
  call void @llvm.trap()
  unreachable

ready.overflow.resume126:                         ; preds = %convergence.overflow.resume124
  %1158 = select i1 %1154, i32 %1155, i32 0
  %1159 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1158
  %1160 = load <8 x i1>, ptr %1159, align 1
  %1161 = select i1 %1154, <8 x i1> %235, <8 x i1> %1160
  store <8 x i1> %1161, ptr %1159, align 1
  %1162 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1158
  %1163 = load i32, ptr %1162, align 4
  %1164 = select i1 %1154, i32 4, i32 %1163
  store i32 %1164, ptr %1162, align 4
  %1165 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1158
  %1166 = load i32, ptr %1165, align 4
  %1167 = select i1 %1154, i32 %1153, i32 %1166
  store i32 %1167, ptr %1165, align 4
  %1168 = add i32 %1155, 1
  %1169 = select i1 %1154, i32 %1168, i32 %1155
  store i32 %1169, ptr %ready.count, align 4
  %1170 = load <8 x i1>, ptr %runnable.mask, align 1
  %1171 = or <8 x i1> %1170, %235
  store <8 x i1> %1171, ptr %runnable.mask, align 1
  store <8 x i1> %237, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true127:                         ; preds = %varying.coherent122
  store <8 x i1> %228, ptr %current.mask, align 1
  %1172 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %228)
  br i1 %1172, label %schedule.4, label %scheduler.loop

varying.coherent.false128:                        ; preds = %varying.coherent122
  store <8 x i1> %228, ptr %current.mask, align 1
  %1173 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %228)
  br i1 %1173, label %schedule.5, label %scheduler.loop

convergence.cascade:                              ; preds = %convergence.cascade, %schedule.5
  %convergence.cascade.flow = phi <8 x i1> [ %275, %schedule.5 ], [ %1216, %convergence.cascade ]
  %convergence.cascade.depth = phi i32 [ 0, %schedule.5 ], [ %1217, %convergence.cascade ]
  %1174 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow)
  %1175 = load i32, ptr %current.token, align 4
  %1176 = icmp ne i32 %1175, 0
  %1177 = and i1 %1174, %1176
  %1178 = sub i32 %1175, 1
  %1179 = select i1 %1177, i32 %1178, i32 0
  %1180 = load i8, ptr %frame.active, align 1
  %1181 = trunc i32 %1179 to i8
  %1182 = shl i8 1, %1181
  %1183 = and i8 %1180, %1182
  %1184 = icmp ne i8 %1183, 0
  %1185 = load <8 x i32>, ptr %frame.static.id, align 32
  %1186 = extractelement <8 x i32> %1185, i32 %1179
  %convergence.target.pointer = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %1186
  %convergence.dynamic.target = load i32, ptr %convergence.target.pointer, align 4
  %1187 = icmp eq i32 %convergence.dynamic.target, 5
  %1188 = and i1 %1184, %1187
  %1189 = and i1 %1177, %1188
  %1190 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1179
  %1191 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1179
  %1192 = load <8 x i1>, ptr %1190, align 1
  %1193 = load <8 x i1>, ptr %1191, align 1
  %1194 = or <8 x i1> %1193, %convergence.cascade.flow
  %1195 = load <8 x i1>, ptr %live.mask, align 1
  %1196 = and <8 x i1> %1192, %1195
  %1197 = icmp eq <8 x i1> %1194, %1196
  %1198 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1197)
  %1199 = and i1 %1189, %1198
  %1200 = select i1 %1199, <8 x i1> zeroinitializer, <8 x i1> %1194
  %1201 = select i1 %1189, <8 x i1> %1200, <8 x i1> %1193
  store <8 x i1> %1201, ptr %1191, align 1
  %1202 = select i1 %1199, <8 x i1> zeroinitializer, <8 x i1> %1192
  store <8 x i1> %1202, ptr %1190, align 1
  %1203 = trunc i32 %1179 to i8
  %1204 = shl i8 1, %1203
  %1205 = xor i8 %1204, -1
  %1206 = and i8 %1180, %1205
  %1207 = select i1 %1199, i8 %1206, i8 %1180
  store i8 %1207, ptr %frame.active, align 1
  %.splatinsert136 = insertelement <8 x i1> poison, i1 %1189, i64 0
  %.splat137 = shufflevector <8 x i1> %.splatinsert136, <8 x i1> poison, <8 x i32> zeroinitializer
  %1208 = and <8 x i1> %convergence.cascade.flow, %.splat137
  %1209 = load <8 x i1>, ptr %runnable.mask, align 1
  %1210 = xor <8 x i1> %1208, splat (i1 true)
  %1211 = and <8 x i1> %1209, %1210
  store <8 x i1> %1211, ptr %runnable.mask, align 1
  %.splatinsert138 = insertelement <8 x i1> poison, i1 %1199, i64 0
  %.splat139 = shufflevector <8 x i1> %.splatinsert138, <8 x i1> poison, <8 x i32> zeroinitializer
  %1212 = select <8 x i1> %.splat139, <8 x i1> %1194, <8 x i1> zeroinitializer
  %1213 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1214 = extractelement <8 x i32> %1213, i32 %1179
  %1215 = select i1 %1199, i32 %1214, i32 %1175
  store i32 %1215, ptr %current.token, align 4
  %.splatinsert140 = insertelement <8 x i1> poison, i1 %1189, i64 0
  %.splat141 = shufflevector <8 x i1> %.splatinsert140, <8 x i1> poison, <8 x i32> zeroinitializer
  %1216 = select <8 x i1> %.splat141, <8 x i1> %1212, <8 x i1> %convergence.cascade.flow
  %1217 = add i32 %convergence.cascade.depth, 1
  %1218 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1216)
  %1219 = icmp ult i32 %1217, 8
  %1220 = and i1 %1218, %1219
  %1221 = and i1 %1189, %1220
  %convergence.parent.token = load i32, ptr %current.token, align 4
  %convergence.parent.present = icmp ne i32 %convergence.parent.token, 0
  %1222 = and i1 %1221, %convergence.parent.present
  br i1 %1222, label %convergence.cascade, label %convergence.cascade.exit

convergence.cascade.exit:                         ; preds = %convergence.cascade, %schedule.5
  %convergence.cascade.result = phi <8 x i1> [ %275, %schedule.5 ], [ %1216, %convergence.cascade ]
  %1223 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %1223, label %convergence.target.5.ready, label %scheduler.loop

convergence.target.5.ready:                       ; preds = %convergence.cascade.exit
  %1224 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1225 = bitcast <8 x i1> %convergence.cascade.result to i8
  %1226 = call i8 @llvm.cttz.i8(i8 %1225, i1 false)
  %1227 = zext i8 %1226 to i32
  %1228 = select i1 %1224, i32 %1227, i32 0
  %1229 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill57, align 64
  %1230 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1231 = extractvalue { <8 x ptr>, <8 x i64> } %1229, 0
  %1232 = select <8 x i1> %convergence.cascade.result, <8 x ptr> %1230, <8 x ptr> %1231
  %1233 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1234 = extractvalue { <8 x ptr>, <8 x i64> } %1229, 1
  %1235 = select <8 x i1> %convergence.cascade.result, <8 x i64> %1233, <8 x i64> %1234
  %1236 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1232, 0
  %1237 = insertvalue { <8 x ptr>, <8 x i64> } %1236, <8 x i64> %1235, 1
  store volatile { <8 x ptr>, <8 x i64> } %1237, ptr %tile_snapshot.spill57, align 64
  %1238 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1239 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1240 = add <8 x i64> %1239, zeroinitializer
  %1241 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1238, 0
  %1242 = insertvalue { <8 x ptr>, <8 x i64> } %1241, <8 x i64> %1240, 1
  %1243 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1244 = extractvalue { <8 x ptr>, <8 x i64> } %1242, 1
  %1245 = extractelement <8 x ptr> %1243, i32 0
  %1246 = extractelement <8 x i64> %1244, i32 %1228
  %1247 = zext i32 %1228 to i64
  %1248 = mul i64 %1247, 8
  %1249 = sub i64 %1246, %1248
  %1250 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1251 = select i1 %1250, i64 %1249, i64 0
  %private.contiguous.address142 = getelementptr i8, ptr %1245, i64 %1251
  %private.contiguous.preserve143 = load <8 x i64>, ptr %private.contiguous.address142, align 8
  %1252 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 -1), <8 x i64> %private.contiguous.preserve143
  store <8 x i64> %1252, ptr %private.contiguous.address142, align 8
  %1253 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1254 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1255 = add <8 x i64> %1254, splat (i64 64)
  %1256 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1253, 0
  %1257 = insertvalue { <8 x ptr>, <8 x i64> } %1256, <8 x i64> %1255, 1
  %1258 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1259 = extractvalue { <8 x ptr>, <8 x i64> } %1257, 1
  %1260 = extractelement <8 x ptr> %1258, i32 0
  %1261 = extractelement <8 x i64> %1259, i32 %1228
  %1262 = zext i32 %1228 to i64
  %1263 = mul i64 %1262, 8
  %1264 = sub i64 %1261, %1263
  %1265 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1266 = select i1 %1265, i64 %1264, i64 0
  %private.contiguous.address144 = getelementptr i8, ptr %1260, i64 %1266
  %private.contiguous.preserve145 = load <8 x i64>, ptr %private.contiguous.address144, align 8
  %1267 = select <8 x i1> %convergence.cascade.result, <8 x i64> zeroinitializer, <8 x i64> %private.contiguous.preserve145
  store <8 x i64> %1267, ptr %private.contiguous.address144, align 8
  %1268 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1269 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1270 = add <8 x i64> %1269, splat (i64 128)
  %1271 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1268, 0
  %1272 = insertvalue { <8 x ptr>, <8 x i64> } %1271, <8 x i64> %1270, 1
  %1273 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1274 = extractvalue { <8 x ptr>, <8 x i64> } %1272, 1
  %1275 = extractelement <8 x ptr> %1273, i32 0
  %1276 = extractelement <8 x i64> %1274, i32 %1228
  %1277 = zext i32 %1228 to i64
  %1278 = mul i64 %1277, 8
  %1279 = sub i64 %1276, %1278
  %1280 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1281 = select i1 %1280, i64 %1279, i64 0
  %private.contiguous.address146 = getelementptr i8, ptr %1275, i64 %1281
  %private.contiguous.preserve147 = load <8 x i64>, ptr %private.contiguous.address146, align 8
  %1282 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 1), <8 x i64> %private.contiguous.preserve147
  store <8 x i64> %1282, ptr %private.contiguous.address146, align 8
  %1283 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1284 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1285 = add <8 x i64> %1284, splat (i64 192)
  %1286 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1283, 0
  %1287 = insertvalue { <8 x ptr>, <8 x i64> } %1286, <8 x i64> %1285, 1
  %1288 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1289 = extractvalue { <8 x ptr>, <8 x i64> } %1287, 1
  %1290 = extractelement <8 x ptr> %1288, i32 0
  %1291 = extractelement <8 x i64> %1289, i32 %1228
  %1292 = zext i32 %1228 to i64
  %1293 = mul i64 %1292, 8
  %1294 = sub i64 %1291, %1293
  %1295 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1296 = select i1 %1295, i64 %1294, i64 0
  %private.contiguous.address148 = getelementptr i8, ptr %1290, i64 %1296
  %private.contiguous.preserve149 = load <8 x i64>, ptr %private.contiguous.address148, align 8
  %1297 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 2), <8 x i64> %private.contiguous.preserve149
  store <8 x i64> %1297, ptr %private.contiguous.address148, align 8
  %1298 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1299 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1300 = add <8 x i64> %1299, splat (i64 256)
  %1301 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1298, 0
  %1302 = insertvalue { <8 x ptr>, <8 x i64> } %1301, <8 x i64> %1300, 1
  %1303 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1304 = extractvalue { <8 x ptr>, <8 x i64> } %1302, 1
  %1305 = extractelement <8 x ptr> %1303, i32 0
  %1306 = extractelement <8 x i64> %1304, i32 %1228
  %1307 = zext i32 %1228 to i64
  %1308 = mul i64 %1307, 8
  %1309 = sub i64 %1306, %1308
  %1310 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1311 = select i1 %1310, i64 %1309, i64 0
  %private.contiguous.address150 = getelementptr i8, ptr %1305, i64 %1311
  %private.contiguous.preserve151 = load <8 x i64>, ptr %private.contiguous.address150, align 8
  %1312 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 3), <8 x i64> %private.contiguous.preserve151
  store <8 x i64> %1312, ptr %private.contiguous.address150, align 8
  %1313 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1314 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1315 = add <8 x i64> %1314, splat (i64 320)
  %1316 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1313, 0
  %1317 = insertvalue { <8 x ptr>, <8 x i64> } %1316, <8 x i64> %1315, 1
  %1318 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1319 = extractvalue { <8 x ptr>, <8 x i64> } %1317, 1
  %1320 = extractelement <8 x ptr> %1318, i32 0
  %1321 = extractelement <8 x i64> %1319, i32 %1228
  %1322 = zext i32 %1228 to i64
  %1323 = mul i64 %1322, 8
  %1324 = sub i64 %1321, %1323
  %1325 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1326 = select i1 %1325, i64 %1324, i64 0
  %private.contiguous.address152 = getelementptr i8, ptr %1320, i64 %1326
  %private.contiguous.preserve153 = load <8 x i64>, ptr %private.contiguous.address152, align 8
  %1327 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 4), <8 x i64> %private.contiguous.preserve153
  store <8 x i64> %1327, ptr %private.contiguous.address152, align 8
  %1328 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1329 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1330 = add <8 x i64> %1329, splat (i64 384)
  %1331 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1328, 0
  %1332 = insertvalue { <8 x ptr>, <8 x i64> } %1331, <8 x i64> %1330, 1
  %1333 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1334 = extractvalue { <8 x ptr>, <8 x i64> } %1332, 1
  %1335 = extractelement <8 x ptr> %1333, i32 0
  %1336 = extractelement <8 x i64> %1334, i32 %1228
  %1337 = zext i32 %1228 to i64
  %1338 = mul i64 %1337, 8
  %1339 = sub i64 %1336, %1338
  %1340 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1341 = select i1 %1340, i64 %1339, i64 0
  %private.contiguous.address154 = getelementptr i8, ptr %1335, i64 %1341
  %private.contiguous.preserve155 = load <8 x i64>, ptr %private.contiguous.address154, align 8
  %1342 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 5), <8 x i64> %private.contiguous.preserve155
  store <8 x i64> %1342, ptr %private.contiguous.address154, align 8
  %1343 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1344 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1345 = add <8 x i64> %1344, splat (i64 448)
  %1346 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1343, 0
  %1347 = insertvalue { <8 x ptr>, <8 x i64> } %1346, <8 x i64> %1345, 1
  %1348 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1349 = extractvalue { <8 x ptr>, <8 x i64> } %1347, 1
  %1350 = extractelement <8 x ptr> %1348, i32 0
  %1351 = extractelement <8 x i64> %1349, i32 %1228
  %1352 = zext i32 %1228 to i64
  %1353 = mul i64 %1352, 8
  %1354 = sub i64 %1351, %1353
  %1355 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1356 = select i1 %1355, i64 %1354, i64 0
  %private.contiguous.address156 = getelementptr i8, ptr %1350, i64 %1356
  %private.contiguous.preserve157 = load <8 x i64>, ptr %private.contiguous.address156, align 8
  %1357 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 6), <8 x i64> %private.contiguous.preserve157
  store <8 x i64> %1357, ptr %private.contiguous.address156, align 8
  %1358 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1359 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1360 = add <8 x i64> %1359, splat (i64 512)
  %1361 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1358, 0
  %1362 = insertvalue { <8 x ptr>, <8 x i64> } %1361, <8 x i64> %1360, 1
  %1363 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1364 = extractvalue { <8 x ptr>, <8 x i64> } %1362, 1
  %1365 = extractelement <8 x ptr> %1363, i32 0
  %1366 = extractelement <8 x i64> %1364, i32 %1228
  %1367 = zext i32 %1228 to i64
  %1368 = mul i64 %1367, 8
  %1369 = sub i64 %1366, %1368
  %1370 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1371 = select i1 %1370, i64 %1369, i64 0
  %private.contiguous.address158 = getelementptr i8, ptr %1365, i64 %1371
  %private.contiguous.preserve159 = load <8 x i64>, ptr %private.contiguous.address158, align 8
  %1372 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 7), <8 x i64> %private.contiguous.preserve159
  store <8 x i64> %1372, ptr %private.contiguous.address158, align 8
  %1373 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1374 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1375 = add <8 x i64> %1374, splat (i64 576)
  %1376 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1373, 0
  %1377 = insertvalue { <8 x ptr>, <8 x i64> } %1376, <8 x i64> %1375, 1
  %1378 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1379 = extractvalue { <8 x ptr>, <8 x i64> } %1377, 1
  %1380 = extractelement <8 x ptr> %1378, i32 0
  %1381 = extractelement <8 x i64> %1379, i32 %1228
  %1382 = zext i32 %1228 to i64
  %1383 = mul i64 %1382, 8
  %1384 = sub i64 %1381, %1383
  %1385 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1386 = select i1 %1385, i64 %1384, i64 0
  %private.contiguous.address160 = getelementptr i8, ptr %1380, i64 %1386
  %private.contiguous.preserve161 = load <8 x i64>, ptr %private.contiguous.address160, align 8
  %1387 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 8), <8 x i64> %private.contiguous.preserve161
  store <8 x i64> %1387, ptr %private.contiguous.address160, align 8
  %1388 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1389 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1390 = add <8 x i64> %1389, splat (i64 640)
  %1391 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1388, 0
  %1392 = insertvalue { <8 x ptr>, <8 x i64> } %1391, <8 x i64> %1390, 1
  %1393 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1394 = extractvalue { <8 x ptr>, <8 x i64> } %1392, 1
  %1395 = extractelement <8 x ptr> %1393, i32 0
  %1396 = extractelement <8 x i64> %1394, i32 %1228
  %1397 = zext i32 %1228 to i64
  %1398 = mul i64 %1397, 8
  %1399 = sub i64 %1396, %1398
  %1400 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1401 = select i1 %1400, i64 %1399, i64 0
  %private.contiguous.address162 = getelementptr i8, ptr %1395, i64 %1401
  %private.contiguous.preserve163 = load <8 x i64>, ptr %private.contiguous.address162, align 8
  %1402 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 9), <8 x i64> %private.contiguous.preserve163
  store <8 x i64> %1402, ptr %private.contiguous.address162, align 8
  %1403 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1404 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1405 = add <8 x i64> %1404, splat (i64 704)
  %1406 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1403, 0
  %1407 = insertvalue { <8 x ptr>, <8 x i64> } %1406, <8 x i64> %1405, 1
  %1408 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1409 = extractvalue { <8 x ptr>, <8 x i64> } %1407, 1
  %1410 = extractelement <8 x ptr> %1408, i32 0
  %1411 = extractelement <8 x i64> %1409, i32 %1228
  %1412 = zext i32 %1228 to i64
  %1413 = mul i64 %1412, 8
  %1414 = sub i64 %1411, %1413
  %1415 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1416 = select i1 %1415, i64 %1414, i64 0
  %private.contiguous.address164 = getelementptr i8, ptr %1410, i64 %1416
  %private.contiguous.preserve165 = load <8 x i64>, ptr %private.contiguous.address164, align 8
  %1417 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 10), <8 x i64> %private.contiguous.preserve165
  store <8 x i64> %1417, ptr %private.contiguous.address164, align 8
  %1418 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1419 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1420 = add <8 x i64> %1419, splat (i64 768)
  %1421 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1418, 0
  %1422 = insertvalue { <8 x ptr>, <8 x i64> } %1421, <8 x i64> %1420, 1
  %1423 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1424 = extractvalue { <8 x ptr>, <8 x i64> } %1422, 1
  %1425 = extractelement <8 x ptr> %1423, i32 0
  %1426 = extractelement <8 x i64> %1424, i32 %1228
  %1427 = zext i32 %1228 to i64
  %1428 = mul i64 %1427, 8
  %1429 = sub i64 %1426, %1428
  %1430 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1431 = select i1 %1430, i64 %1429, i64 0
  %private.contiguous.address166 = getelementptr i8, ptr %1425, i64 %1431
  %private.contiguous.preserve167 = load <8 x i64>, ptr %private.contiguous.address166, align 8
  %1432 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 11), <8 x i64> %private.contiguous.preserve167
  store <8 x i64> %1432, ptr %private.contiguous.address166, align 8
  %1433 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1434 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1435 = add <8 x i64> %1434, splat (i64 832)
  %1436 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1433, 0
  %1437 = insertvalue { <8 x ptr>, <8 x i64> } %1436, <8 x i64> %1435, 1
  %1438 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1439 = extractvalue { <8 x ptr>, <8 x i64> } %1437, 1
  %1440 = extractelement <8 x ptr> %1438, i32 0
  %1441 = extractelement <8 x i64> %1439, i32 %1228
  %1442 = zext i32 %1228 to i64
  %1443 = mul i64 %1442, 8
  %1444 = sub i64 %1441, %1443
  %1445 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1446 = select i1 %1445, i64 %1444, i64 0
  %private.contiguous.address168 = getelementptr i8, ptr %1440, i64 %1446
  %private.contiguous.preserve169 = load <8 x i64>, ptr %private.contiguous.address168, align 8
  %1447 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 12), <8 x i64> %private.contiguous.preserve169
  store <8 x i64> %1447, ptr %private.contiguous.address168, align 8
  %1448 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1449 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1450 = add <8 x i64> %1449, splat (i64 896)
  %1451 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1448, 0
  %1452 = insertvalue { <8 x ptr>, <8 x i64> } %1451, <8 x i64> %1450, 1
  %1453 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1454 = extractvalue { <8 x ptr>, <8 x i64> } %1452, 1
  %1455 = extractelement <8 x ptr> %1453, i32 0
  %1456 = extractelement <8 x i64> %1454, i32 %1228
  %1457 = zext i32 %1228 to i64
  %1458 = mul i64 %1457, 8
  %1459 = sub i64 %1456, %1458
  %1460 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1461 = select i1 %1460, i64 %1459, i64 0
  %private.contiguous.address170 = getelementptr i8, ptr %1455, i64 %1461
  %private.contiguous.preserve171 = load <8 x i64>, ptr %private.contiguous.address170, align 8
  %1462 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 13), <8 x i64> %private.contiguous.preserve171
  store <8 x i64> %1462, ptr %private.contiguous.address170, align 8
  %1463 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1464 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1465 = add <8 x i64> %1464, splat (i64 960)
  %1466 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1463, 0
  %1467 = insertvalue { <8 x ptr>, <8 x i64> } %1466, <8 x i64> %1465, 1
  %1468 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1469 = extractvalue { <8 x ptr>, <8 x i64> } %1467, 1
  %1470 = extractelement <8 x ptr> %1468, i32 0
  %1471 = extractelement <8 x i64> %1469, i32 %1228
  %1472 = zext i32 %1228 to i64
  %1473 = mul i64 %1472, 8
  %1474 = sub i64 %1471, %1473
  %1475 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1476 = select i1 %1475, i64 %1474, i64 0
  %private.contiguous.address172 = getelementptr i8, ptr %1470, i64 %1476
  %private.contiguous.preserve173 = load <8 x i64>, ptr %private.contiguous.address172, align 8
  %1477 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 14), <8 x i64> %private.contiguous.preserve173
  store <8 x i64> %1477, ptr %private.contiguous.address172, align 8
  %1478 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1479 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1480 = add <8 x i64> %1479, splat (i64 1024)
  %1481 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1478, 0
  %1482 = insertvalue { <8 x ptr>, <8 x i64> } %1481, <8 x i64> %1480, 1
  %1483 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1484 = extractvalue { <8 x ptr>, <8 x i64> } %1482, 1
  %1485 = extractelement <8 x ptr> %1483, i32 0
  %1486 = extractelement <8 x i64> %1484, i32 %1228
  %1487 = zext i32 %1228 to i64
  %1488 = mul i64 %1487, 8
  %1489 = sub i64 %1486, %1488
  %1490 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1491 = select i1 %1490, i64 %1489, i64 0
  %private.contiguous.address174 = getelementptr i8, ptr %1485, i64 %1491
  %private.contiguous.preserve175 = load <8 x i64>, ptr %private.contiguous.address174, align 8
  %1492 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 15), <8 x i64> %private.contiguous.preserve175
  store <8 x i64> %1492, ptr %private.contiguous.address174, align 8
  %1493 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1494 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1495 = add <8 x i64> %1494, splat (i64 1088)
  %1496 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1493, 0
  %1497 = insertvalue { <8 x ptr>, <8 x i64> } %1496, <8 x i64> %1495, 1
  %1498 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1499 = extractvalue { <8 x ptr>, <8 x i64> } %1497, 1
  %1500 = extractelement <8 x ptr> %1498, i32 0
  %1501 = extractelement <8 x i64> %1499, i32 %1228
  %1502 = zext i32 %1228 to i64
  %1503 = mul i64 %1502, 8
  %1504 = sub i64 %1501, %1503
  %1505 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1506 = select i1 %1505, i64 %1504, i64 0
  %private.contiguous.address176 = getelementptr i8, ptr %1500, i64 %1506
  %private.contiguous.preserve177 = load <8 x i64>, ptr %private.contiguous.address176, align 8
  %1507 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 16), <8 x i64> %private.contiguous.preserve177
  store <8 x i64> %1507, ptr %private.contiguous.address176, align 8
  %1508 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1509 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1510 = add <8 x i64> %1509, splat (i64 1152)
  %1511 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1508, 0
  %1512 = insertvalue { <8 x ptr>, <8 x i64> } %1511, <8 x i64> %1510, 1
  %1513 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1514 = extractvalue { <8 x ptr>, <8 x i64> } %1512, 1
  %1515 = extractelement <8 x ptr> %1513, i32 0
  %1516 = extractelement <8 x i64> %1514, i32 %1228
  %1517 = zext i32 %1228 to i64
  %1518 = mul i64 %1517, 8
  %1519 = sub i64 %1516, %1518
  %1520 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1521 = select i1 %1520, i64 %1519, i64 0
  %private.contiguous.address178 = getelementptr i8, ptr %1515, i64 %1521
  %private.contiguous.preserve179 = load <8 x i64>, ptr %private.contiguous.address178, align 8
  %1522 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 17), <8 x i64> %private.contiguous.preserve179
  store <8 x i64> %1522, ptr %private.contiguous.address178, align 8
  %1523 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1524 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1525 = add <8 x i64> %1524, splat (i64 1216)
  %1526 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1523, 0
  %1527 = insertvalue { <8 x ptr>, <8 x i64> } %1526, <8 x i64> %1525, 1
  %1528 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1529 = extractvalue { <8 x ptr>, <8 x i64> } %1527, 1
  %1530 = extractelement <8 x ptr> %1528, i32 0
  %1531 = extractelement <8 x i64> %1529, i32 %1228
  %1532 = zext i32 %1228 to i64
  %1533 = mul i64 %1532, 8
  %1534 = sub i64 %1531, %1533
  %1535 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1536 = select i1 %1535, i64 %1534, i64 0
  %private.contiguous.address180 = getelementptr i8, ptr %1530, i64 %1536
  %private.contiguous.preserve181 = load <8 x i64>, ptr %private.contiguous.address180, align 8
  %1537 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 18), <8 x i64> %private.contiguous.preserve181
  store <8 x i64> %1537, ptr %private.contiguous.address180, align 8
  %1538 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1539 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1540 = add <8 x i64> %1539, splat (i64 1280)
  %1541 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1538, 0
  %1542 = insertvalue { <8 x ptr>, <8 x i64> } %1541, <8 x i64> %1540, 1
  %1543 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1544 = extractvalue { <8 x ptr>, <8 x i64> } %1542, 1
  %1545 = extractelement <8 x ptr> %1543, i32 0
  %1546 = extractelement <8 x i64> %1544, i32 %1228
  %1547 = zext i32 %1228 to i64
  %1548 = mul i64 %1547, 8
  %1549 = sub i64 %1546, %1548
  %1550 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1551 = select i1 %1550, i64 %1549, i64 0
  %private.contiguous.address182 = getelementptr i8, ptr %1545, i64 %1551
  %private.contiguous.preserve183 = load <8 x i64>, ptr %private.contiguous.address182, align 8
  %1552 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 19), <8 x i64> %private.contiguous.preserve183
  store <8 x i64> %1552, ptr %private.contiguous.address182, align 8
  %1553 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1554 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1555 = add <8 x i64> %1554, splat (i64 1344)
  %1556 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1553, 0
  %1557 = insertvalue { <8 x ptr>, <8 x i64> } %1556, <8 x i64> %1555, 1
  %1558 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1559 = extractvalue { <8 x ptr>, <8 x i64> } %1557, 1
  %1560 = extractelement <8 x ptr> %1558, i32 0
  %1561 = extractelement <8 x i64> %1559, i32 %1228
  %1562 = zext i32 %1228 to i64
  %1563 = mul i64 %1562, 8
  %1564 = sub i64 %1561, %1563
  %1565 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1566 = select i1 %1565, i64 %1564, i64 0
  %private.contiguous.address184 = getelementptr i8, ptr %1560, i64 %1566
  %private.contiguous.preserve185 = load <8 x i64>, ptr %private.contiguous.address184, align 8
  %1567 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 20), <8 x i64> %private.contiguous.preserve185
  store <8 x i64> %1567, ptr %private.contiguous.address184, align 8
  %1568 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1569 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1570 = add <8 x i64> %1569, splat (i64 1408)
  %1571 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1568, 0
  %1572 = insertvalue { <8 x ptr>, <8 x i64> } %1571, <8 x i64> %1570, 1
  %1573 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1574 = extractvalue { <8 x ptr>, <8 x i64> } %1572, 1
  %1575 = extractelement <8 x ptr> %1573, i32 0
  %1576 = extractelement <8 x i64> %1574, i32 %1228
  %1577 = zext i32 %1228 to i64
  %1578 = mul i64 %1577, 8
  %1579 = sub i64 %1576, %1578
  %1580 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1581 = select i1 %1580, i64 %1579, i64 0
  %private.contiguous.address186 = getelementptr i8, ptr %1575, i64 %1581
  %private.contiguous.preserve187 = load <8 x i64>, ptr %private.contiguous.address186, align 8
  %1582 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 21), <8 x i64> %private.contiguous.preserve187
  store <8 x i64> %1582, ptr %private.contiguous.address186, align 8
  %1583 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1584 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1585 = add <8 x i64> %1584, splat (i64 1472)
  %1586 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1583, 0
  %1587 = insertvalue { <8 x ptr>, <8 x i64> } %1586, <8 x i64> %1585, 1
  %1588 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1589 = extractvalue { <8 x ptr>, <8 x i64> } %1587, 1
  %1590 = extractelement <8 x ptr> %1588, i32 0
  %1591 = extractelement <8 x i64> %1589, i32 %1228
  %1592 = zext i32 %1228 to i64
  %1593 = mul i64 %1592, 8
  %1594 = sub i64 %1591, %1593
  %1595 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1596 = select i1 %1595, i64 %1594, i64 0
  %private.contiguous.address188 = getelementptr i8, ptr %1590, i64 %1596
  %private.contiguous.preserve189 = load <8 x i64>, ptr %private.contiguous.address188, align 8
  %1597 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 22), <8 x i64> %private.contiguous.preserve189
  store <8 x i64> %1597, ptr %private.contiguous.address188, align 8
  %1598 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1599 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1600 = add <8 x i64> %1599, splat (i64 1536)
  %1601 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1598, 0
  %1602 = insertvalue { <8 x ptr>, <8 x i64> } %1601, <8 x i64> %1600, 1
  %1603 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1604 = extractvalue { <8 x ptr>, <8 x i64> } %1602, 1
  %1605 = extractelement <8 x ptr> %1603, i32 0
  %1606 = extractelement <8 x i64> %1604, i32 %1228
  %1607 = zext i32 %1228 to i64
  %1608 = mul i64 %1607, 8
  %1609 = sub i64 %1606, %1608
  %1610 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1611 = select i1 %1610, i64 %1609, i64 0
  %private.contiguous.address190 = getelementptr i8, ptr %1605, i64 %1611
  %private.contiguous.preserve191 = load <8 x i64>, ptr %private.contiguous.address190, align 8
  %1612 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 23), <8 x i64> %private.contiguous.preserve191
  store <8 x i64> %1612, ptr %private.contiguous.address190, align 8
  %1613 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1614 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1615 = add <8 x i64> %1614, splat (i64 1600)
  %1616 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1613, 0
  %1617 = insertvalue { <8 x ptr>, <8 x i64> } %1616, <8 x i64> %1615, 1
  %1618 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1619 = extractvalue { <8 x ptr>, <8 x i64> } %1617, 1
  %1620 = extractelement <8 x ptr> %1618, i32 0
  %1621 = extractelement <8 x i64> %1619, i32 %1228
  %1622 = zext i32 %1228 to i64
  %1623 = mul i64 %1622, 8
  %1624 = sub i64 %1621, %1623
  %1625 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1626 = select i1 %1625, i64 %1624, i64 0
  %private.contiguous.address192 = getelementptr i8, ptr %1620, i64 %1626
  %private.contiguous.preserve193 = load <8 x i64>, ptr %private.contiguous.address192, align 8
  %1627 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 24), <8 x i64> %private.contiguous.preserve193
  store <8 x i64> %1627, ptr %private.contiguous.address192, align 8
  %1628 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1629 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1630 = add <8 x i64> %1629, splat (i64 1664)
  %1631 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1628, 0
  %1632 = insertvalue { <8 x ptr>, <8 x i64> } %1631, <8 x i64> %1630, 1
  %1633 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1634 = extractvalue { <8 x ptr>, <8 x i64> } %1632, 1
  %1635 = extractelement <8 x ptr> %1633, i32 0
  %1636 = extractelement <8 x i64> %1634, i32 %1228
  %1637 = zext i32 %1228 to i64
  %1638 = mul i64 %1637, 8
  %1639 = sub i64 %1636, %1638
  %1640 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1641 = select i1 %1640, i64 %1639, i64 0
  %private.contiguous.address194 = getelementptr i8, ptr %1635, i64 %1641
  %private.contiguous.preserve195 = load <8 x i64>, ptr %private.contiguous.address194, align 8
  %1642 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 25), <8 x i64> %private.contiguous.preserve195
  store <8 x i64> %1642, ptr %private.contiguous.address194, align 8
  %1643 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1644 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1645 = add <8 x i64> %1644, splat (i64 1728)
  %1646 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1643, 0
  %1647 = insertvalue { <8 x ptr>, <8 x i64> } %1646, <8 x i64> %1645, 1
  %1648 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1649 = extractvalue { <8 x ptr>, <8 x i64> } %1647, 1
  %1650 = extractelement <8 x ptr> %1648, i32 0
  %1651 = extractelement <8 x i64> %1649, i32 %1228
  %1652 = zext i32 %1228 to i64
  %1653 = mul i64 %1652, 8
  %1654 = sub i64 %1651, %1653
  %1655 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1656 = select i1 %1655, i64 %1654, i64 0
  %private.contiguous.address196 = getelementptr i8, ptr %1650, i64 %1656
  %private.contiguous.preserve197 = load <8 x i64>, ptr %private.contiguous.address196, align 8
  %1657 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 26), <8 x i64> %private.contiguous.preserve197
  store <8 x i64> %1657, ptr %private.contiguous.address196, align 8
  %1658 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1659 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1660 = add <8 x i64> %1659, splat (i64 1792)
  %1661 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1658, 0
  %1662 = insertvalue { <8 x ptr>, <8 x i64> } %1661, <8 x i64> %1660, 1
  %1663 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1664 = extractvalue { <8 x ptr>, <8 x i64> } %1662, 1
  %1665 = extractelement <8 x ptr> %1663, i32 0
  %1666 = extractelement <8 x i64> %1664, i32 %1228
  %1667 = zext i32 %1228 to i64
  %1668 = mul i64 %1667, 8
  %1669 = sub i64 %1666, %1668
  %1670 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1671 = select i1 %1670, i64 %1669, i64 0
  %private.contiguous.address198 = getelementptr i8, ptr %1665, i64 %1671
  %private.contiguous.preserve199 = load <8 x i64>, ptr %private.contiguous.address198, align 8
  %1672 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 27), <8 x i64> %private.contiguous.preserve199
  store <8 x i64> %1672, ptr %private.contiguous.address198, align 8
  %1673 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1674 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1675 = add <8 x i64> %1674, splat (i64 1856)
  %1676 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1673, 0
  %1677 = insertvalue { <8 x ptr>, <8 x i64> } %1676, <8 x i64> %1675, 1
  %1678 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1679 = extractvalue { <8 x ptr>, <8 x i64> } %1677, 1
  %1680 = extractelement <8 x ptr> %1678, i32 0
  %1681 = extractelement <8 x i64> %1679, i32 %1228
  %1682 = zext i32 %1228 to i64
  %1683 = mul i64 %1682, 8
  %1684 = sub i64 %1681, %1683
  %1685 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1686 = select i1 %1685, i64 %1684, i64 0
  %private.contiguous.address200 = getelementptr i8, ptr %1680, i64 %1686
  %private.contiguous.preserve201 = load <8 x i64>, ptr %private.contiguous.address200, align 8
  %1687 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 28), <8 x i64> %private.contiguous.preserve201
  store <8 x i64> %1687, ptr %private.contiguous.address200, align 8
  %1688 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1689 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1690 = add <8 x i64> %1689, splat (i64 1920)
  %1691 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1688, 0
  %1692 = insertvalue { <8 x ptr>, <8 x i64> } %1691, <8 x i64> %1690, 1
  %1693 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1694 = extractvalue { <8 x ptr>, <8 x i64> } %1692, 1
  %1695 = extractelement <8 x ptr> %1693, i32 0
  %1696 = extractelement <8 x i64> %1694, i32 %1228
  %1697 = zext i32 %1228 to i64
  %1698 = mul i64 %1697, 8
  %1699 = sub i64 %1696, %1698
  %1700 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1701 = select i1 %1700, i64 %1699, i64 0
  %private.contiguous.address202 = getelementptr i8, ptr %1695, i64 %1701
  %private.contiguous.preserve203 = load <8 x i64>, ptr %private.contiguous.address202, align 8
  %1702 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 29), <8 x i64> %private.contiguous.preserve203
  store <8 x i64> %1702, ptr %private.contiguous.address202, align 8
  %1703 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1704 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1705 = add <8 x i64> %1704, splat (i64 1984)
  %1706 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1703, 0
  %1707 = insertvalue { <8 x ptr>, <8 x i64> } %1706, <8 x i64> %1705, 1
  %1708 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1709 = extractvalue { <8 x ptr>, <8 x i64> } %1707, 1
  %1710 = extractelement <8 x ptr> %1708, i32 0
  %1711 = extractelement <8 x i64> %1709, i32 %1228
  %1712 = zext i32 %1228 to i64
  %1713 = mul i64 %1712, 8
  %1714 = sub i64 %1711, %1713
  %1715 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1716 = select i1 %1715, i64 %1714, i64 0
  %private.contiguous.address204 = getelementptr i8, ptr %1710, i64 %1716
  %private.contiguous.preserve205 = load <8 x i64>, ptr %private.contiguous.address204, align 8
  %1717 = select <8 x i1> %convergence.cascade.result, <8 x i64> splat (i64 30), <8 x i64> %private.contiguous.preserve205
  store <8 x i64> %1717, ptr %private.contiguous.address204, align 8
  %1718 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill58, align 64
  %1719 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1720 = extractvalue { <8 x ptr>, <8 x i64> } %1718, 0
  %1721 = select <8 x i1> %convergence.cascade.result, <8 x ptr> %1719, <8 x ptr> %1720
  %1722 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %1723 = extractvalue { <8 x ptr>, <8 x i64> } %1718, 1
  %1724 = select <8 x i1> %convergence.cascade.result, <8 x i64> %1722, <8 x i64> %1723
  %1725 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1721, 0
  %1726 = insertvalue { <8 x ptr>, <8 x i64> } %1725, <8 x i64> %1724, 1
  store volatile { <8 x ptr>, <8 x i64> } %1726, ptr %tile_snapshot.spill58, align 64
  %1727 = load <8 x i64>, ptr %.slot59, align 64
  %1728 = select <8 x i1> %convergence.cascade.result, <8 x i64> zeroinitializer, <8 x i64> %1727
  store <8 x i64> %1728, ptr %.slot59, align 64
  store <8 x i1> %convergence.cascade.result, ptr %current.mask, align 1
  %1729 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %1729, label %schedule.6, label %scheduler.loop

varying.divergent207:                             ; preds = %schedule.6
  %1730 = load i32, ptr %current.token, align 4
  %1731 = icmp ne i32 %1730, 0
  %1732 = sub i32 %1730, 1
  %1733 = select i1 %1731, i32 %1732, i32 0
  %1734 = load i8, ptr %frame.active, align 1
  %1735 = trunc i32 %1733 to i8
  %1736 = shl i8 1, %1735
  %1737 = and i8 %1734, %1736
  %1738 = icmp ne i8 %1737, 0
  %1739 = load <8 x i32>, ptr %frame.static.id, align 32
  %1740 = extractelement <8 x i32> %1739, i32 %1733
  %1741 = icmp eq i32 %1740, 2
  %1742 = and i1 %1738, %1741
  %1743 = and i1 %1731, %1742
  %1744 = xor i1 %1743, true
  %1745 = and i1 true, %1744
  %1746 = xor i8 %1734, -1
  %1747 = icmp ne i8 %1746, 0
  %1748 = xor i1 %1747, true
  %1749 = and i1 %1745, %1748
  br i1 %1749, label %convergence.overflow.trap209, label %convergence.overflow.resume210

varying.coherent208:                              ; preds = %schedule.6
  br i1 %286, label %varying.coherent.true213, label %varying.coherent.false214

convergence.overflow.trap209:                     ; preds = %varying.divergent207
  call void @llvm.trap()
  unreachable

convergence.overflow.resume210:                   ; preds = %varying.divergent207
  %1750 = call i8 @llvm.cttz.i8(i8 %1746, i1 false)
  %1751 = zext i8 %1750 to i32
  %1752 = select i1 %1747, i32 %1751, i32 0
  %1753 = trunc i32 %1752 to i8
  %1754 = shl i8 1, %1753
  %1755 = or i8 %1734, %1754
  %1756 = select i1 %1745, i8 %1755, i8 %1734
  store i8 %1756, ptr %frame.active, align 1
  %1757 = load <8 x i32>, ptr %frame.static.id, align 32
  %1758 = extractelement <8 x i32> %1757, i32 %1752
  %1759 = select i1 %1745, i32 2, i32 %1758
  %1760 = load <8 x i32>, ptr %frame.static.id, align 32
  %1761 = insertelement <8 x i32> %1760, i32 %1759, i32 %1752
  store <8 x i32> %1761, ptr %frame.static.id, align 32
  %1762 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1763 = extractelement <8 x i32> %1762, i32 %1752
  %1764 = select i1 %1745, i32 %1730, i32 %1763
  %1765 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1766 = insertelement <8 x i32> %1765, i32 %1764, i32 %1752
  store <8 x i32> %1766, ptr %frame.parent.token, align 32
  %1767 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1752
  %1768 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1752
  %1769 = load <8 x i1>, ptr %1767, align 1
  %1770 = load <8 x i1>, ptr %1768, align 1
  %1771 = select i1 %1745, <8 x i1> %276, <8 x i1> %1769
  store <8 x i1> %1771, ptr %1767, align 1
  %1772 = select i1 %1745, <8 x i1> zeroinitializer, <8 x i1> %1770
  store <8 x i1> %1772, ptr %1768, align 1
  %1773 = add i32 %1752, 1
  %1774 = select i1 %1743, i32 %1730, i32 %1773
  %1775 = select i1 true, i32 %1774, i32 %1730
  store i32 %1775, ptr %current.token, align 4
  %1776 = load i32, ptr %current.token, align 4
  %1777 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %283)
  %1778 = load i32, ptr %ready.count, align 4
  %1779 = icmp uge i32 %1778, 8
  %1780 = and i1 %1777, %1779
  br i1 %1780, label %ready.overflow.trap211, label %ready.overflow.resume212

ready.overflow.trap211:                           ; preds = %convergence.overflow.resume210
  call void @llvm.trap()
  unreachable

ready.overflow.resume212:                         ; preds = %convergence.overflow.resume210
  %1781 = select i1 %1777, i32 %1778, i32 0
  %1782 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1781
  %1783 = load <8 x i1>, ptr %1782, align 1
  %1784 = select i1 %1777, <8 x i1> %283, <8 x i1> %1783
  store <8 x i1> %1784, ptr %1782, align 1
  %1785 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1781
  %1786 = load i32, ptr %1785, align 4
  %1787 = select i1 %1777, i32 7, i32 %1786
  store i32 %1787, ptr %1785, align 4
  %1788 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1781
  %1789 = load i32, ptr %1788, align 4
  %1790 = select i1 %1777, i32 %1776, i32 %1789
  store i32 %1790, ptr %1788, align 4
  %1791 = add i32 %1778, 1
  %1792 = select i1 %1777, i32 %1791, i32 %1778
  store i32 %1792, ptr %ready.count, align 4
  %1793 = load <8 x i1>, ptr %runnable.mask, align 1
  %1794 = or <8 x i1> %1793, %283
  store <8 x i1> %1794, ptr %runnable.mask, align 1
  store <8 x i1> %285, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true213:                         ; preds = %varying.coherent208
  store <8 x i1> %276, ptr %current.mask, align 1
  %1795 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %276)
  br i1 %1795, label %schedule.7, label %scheduler.loop

varying.coherent.false214:                        ; preds = %varying.coherent208
  store <8 x i1> %276, ptr %current.mask, align 1
  %1796 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %276)
  br i1 %1796, label %schedule.10, label %scheduler.loop

varying.divergent221:                             ; preds = %schedule.7
  %1797 = load i32, ptr %current.token, align 4
  %1798 = icmp ne i32 %1797, 0
  %1799 = sub i32 %1797, 1
  %1800 = select i1 %1798, i32 %1799, i32 0
  %1801 = load i8, ptr %frame.active, align 1
  %1802 = trunc i32 %1800 to i8
  %1803 = shl i8 1, %1802
  %1804 = and i8 %1801, %1803
  %1805 = icmp ne i8 %1804, 0
  %1806 = load <8 x i32>, ptr %frame.static.id, align 32
  %1807 = extractelement <8 x i32> %1806, i32 %1800
  %1808 = icmp eq i32 %1807, 3
  %1809 = and i1 %1805, %1808
  %1810 = and i1 %1798, %1809
  %1811 = xor i1 %1810, true
  %1812 = and i1 true, %1811
  %1813 = xor i8 %1801, -1
  %1814 = icmp ne i8 %1813, 0
  %1815 = xor i1 %1814, true
  %1816 = and i1 %1812, %1815
  br i1 %1816, label %convergence.overflow.trap223, label %convergence.overflow.resume224

varying.coherent222:                              ; preds = %schedule.7
  br i1 %328, label %varying.coherent.true227, label %varying.coherent.false228

convergence.overflow.trap223:                     ; preds = %varying.divergent221
  call void @llvm.trap()
  unreachable

convergence.overflow.resume224:                   ; preds = %varying.divergent221
  %1817 = call i8 @llvm.cttz.i8(i8 %1813, i1 false)
  %1818 = zext i8 %1817 to i32
  %1819 = select i1 %1814, i32 %1818, i32 0
  %1820 = trunc i32 %1819 to i8
  %1821 = shl i8 1, %1820
  %1822 = or i8 %1801, %1821
  %1823 = select i1 %1812, i8 %1822, i8 %1801
  store i8 %1823, ptr %frame.active, align 1
  %1824 = load <8 x i32>, ptr %frame.static.id, align 32
  %1825 = extractelement <8 x i32> %1824, i32 %1819
  %1826 = select i1 %1812, i32 3, i32 %1825
  %1827 = load <8 x i32>, ptr %frame.static.id, align 32
  %1828 = insertelement <8 x i32> %1827, i32 %1826, i32 %1819
  store <8 x i32> %1828, ptr %frame.static.id, align 32
  %1829 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1830 = extractelement <8 x i32> %1829, i32 %1819
  %1831 = select i1 %1812, i32 %1797, i32 %1830
  %1832 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1833 = insertelement <8 x i32> %1832, i32 %1831, i32 %1819
  store <8 x i32> %1833, ptr %frame.parent.token, align 32
  %1834 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1819
  %1835 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1819
  %1836 = load <8 x i1>, ptr %1834, align 1
  %1837 = load <8 x i1>, ptr %1835, align 1
  %1838 = select i1 %1812, <8 x i1> %289, <8 x i1> %1836
  store <8 x i1> %1838, ptr %1834, align 1
  %1839 = select i1 %1812, <8 x i1> zeroinitializer, <8 x i1> %1837
  store <8 x i1> %1839, ptr %1835, align 1
  %1840 = add i32 %1819, 1
  %1841 = select i1 %1810, i32 %1797, i32 %1840
  %1842 = select i1 true, i32 %1841, i32 %1797
  store i32 %1842, ptr %current.token, align 4
  %1843 = load <8 x float>, ptr %.slot62, align 32
  %1844 = select <8 x i1> %327, <8 x float> zeroinitializer, <8 x float> %1843
  store <8 x float> %1844, ptr %.slot62, align 32
  %1845 = load i32, ptr %current.token, align 4
  %1846 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %325)
  %1847 = load i32, ptr %ready.count, align 4
  %1848 = icmp uge i32 %1847, 8
  %1849 = and i1 %1846, %1848
  br i1 %1849, label %ready.overflow.trap225, label %ready.overflow.resume226

ready.overflow.trap225:                           ; preds = %convergence.overflow.resume224
  call void @llvm.trap()
  unreachable

ready.overflow.resume226:                         ; preds = %convergence.overflow.resume224
  %1850 = select i1 %1846, i32 %1847, i32 0
  %1851 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1850
  %1852 = load <8 x i1>, ptr %1851, align 1
  %1853 = select i1 %1846, <8 x i1> %325, <8 x i1> %1852
  store <8 x i1> %1853, ptr %1851, align 1
  %1854 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1850
  %1855 = load i32, ptr %1854, align 4
  %1856 = select i1 %1846, i32 8, i32 %1855
  store i32 %1856, ptr %1854, align 4
  %1857 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1850
  %1858 = load i32, ptr %1857, align 4
  %1859 = select i1 %1846, i32 %1845, i32 %1858
  store i32 %1859, ptr %1857, align 4
  %1860 = add i32 %1847, 1
  %1861 = select i1 %1846, i32 %1860, i32 %1847
  store i32 %1861, ptr %ready.count, align 4
  %1862 = load <8 x i1>, ptr %runnable.mask, align 1
  %1863 = or <8 x i1> %1862, %325
  store <8 x i1> %1863, ptr %runnable.mask, align 1
  store <8 x i1> %327, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true227:                         ; preds = %varying.coherent222
  store <8 x i1> %289, ptr %current.mask, align 1
  %1864 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %289)
  br i1 %1864, label %schedule.8, label %scheduler.loop

varying.coherent.false228:                        ; preds = %varying.coherent222
  %1865 = load <8 x float>, ptr %.slot62, align 32
  %1866 = select <8 x i1> %289, <8 x float> zeroinitializer, <8 x float> %1865
  store <8 x float> %1866, ptr %.slot62, align 32
  store <8 x i1> %289, ptr %current.mask, align 1
  %1867 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %289)
  br i1 %1867, label %schedule.9, label %scheduler.loop

convergence.cascade231:                           ; preds = %convergence.cascade231, %schedule.9
  %convergence.cascade.flow235 = phi <8 x i1> [ %350, %schedule.9 ], [ %1910, %convergence.cascade231 ]
  %convergence.cascade.depth236 = phi i32 [ 0, %schedule.9 ], [ %1911, %convergence.cascade231 ]
  %1868 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow235)
  %1869 = load i32, ptr %current.token, align 4
  %1870 = icmp ne i32 %1869, 0
  %1871 = and i1 %1868, %1870
  %1872 = sub i32 %1869, 1
  %1873 = select i1 %1871, i32 %1872, i32 0
  %1874 = load i8, ptr %frame.active, align 1
  %1875 = trunc i32 %1873 to i8
  %1876 = shl i8 1, %1875
  %1877 = and i8 %1874, %1876
  %1878 = icmp ne i8 %1877, 0
  %1879 = load <8 x i32>, ptr %frame.static.id, align 32
  %1880 = extractelement <8 x i32> %1879, i32 %1873
  %convergence.target.pointer237 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %1880
  %convergence.dynamic.target238 = load i32, ptr %convergence.target.pointer237, align 4
  %1881 = icmp eq i32 %convergence.dynamic.target238, 9
  %1882 = and i1 %1878, %1881
  %1883 = and i1 %1871, %1882
  %1884 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1873
  %1885 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1873
  %1886 = load <8 x i1>, ptr %1884, align 1
  %1887 = load <8 x i1>, ptr %1885, align 1
  %1888 = or <8 x i1> %1887, %convergence.cascade.flow235
  %1889 = load <8 x i1>, ptr %live.mask, align 1
  %1890 = and <8 x i1> %1886, %1889
  %1891 = icmp eq <8 x i1> %1888, %1890
  %1892 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1891)
  %1893 = and i1 %1883, %1892
  %1894 = select i1 %1893, <8 x i1> zeroinitializer, <8 x i1> %1888
  %1895 = select i1 %1883, <8 x i1> %1894, <8 x i1> %1887
  store <8 x i1> %1895, ptr %1885, align 1
  %1896 = select i1 %1893, <8 x i1> zeroinitializer, <8 x i1> %1886
  store <8 x i1> %1896, ptr %1884, align 1
  %1897 = trunc i32 %1873 to i8
  %1898 = shl i8 1, %1897
  %1899 = xor i8 %1898, -1
  %1900 = and i8 %1874, %1899
  %1901 = select i1 %1893, i8 %1900, i8 %1874
  store i8 %1901, ptr %frame.active, align 1
  %.splatinsert239 = insertelement <8 x i1> poison, i1 %1883, i64 0
  %.splat240 = shufflevector <8 x i1> %.splatinsert239, <8 x i1> poison, <8 x i32> zeroinitializer
  %1902 = and <8 x i1> %convergence.cascade.flow235, %.splat240
  %1903 = load <8 x i1>, ptr %runnable.mask, align 1
  %1904 = xor <8 x i1> %1902, splat (i1 true)
  %1905 = and <8 x i1> %1903, %1904
  store <8 x i1> %1905, ptr %runnable.mask, align 1
  %.splatinsert241 = insertelement <8 x i1> poison, i1 %1893, i64 0
  %.splat242 = shufflevector <8 x i1> %.splatinsert241, <8 x i1> poison, <8 x i32> zeroinitializer
  %1906 = select <8 x i1> %.splat242, <8 x i1> %1888, <8 x i1> zeroinitializer
  %1907 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1908 = extractelement <8 x i32> %1907, i32 %1873
  %1909 = select i1 %1893, i32 %1908, i32 %1869
  store i32 %1909, ptr %current.token, align 4
  %.splatinsert243 = insertelement <8 x i1> poison, i1 %1883, i64 0
  %.splat244 = shufflevector <8 x i1> %.splatinsert243, <8 x i1> poison, <8 x i32> zeroinitializer
  %1910 = select <8 x i1> %.splat244, <8 x i1> %1906, <8 x i1> %convergence.cascade.flow235
  %1911 = add i32 %convergence.cascade.depth236, 1
  %1912 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1910)
  %1913 = icmp ult i32 %1911, 8
  %1914 = and i1 %1912, %1913
  %1915 = and i1 %1883, %1914
  %convergence.parent.token245 = load i32, ptr %current.token, align 4
  %convergence.parent.present246 = icmp ne i32 %convergence.parent.token245, 0
  %1916 = and i1 %1915, %convergence.parent.present246
  br i1 %1916, label %convergence.cascade231, label %convergence.cascade.exit232

convergence.cascade.exit232:                      ; preds = %convergence.cascade231, %schedule.9
  %convergence.cascade.result247 = phi <8 x i1> [ %350, %schedule.9 ], [ %1910, %convergence.cascade231 ]
  %1917 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result247)
  br i1 %1917, label %convergence.target.9.ready, label %scheduler.loop

convergence.target.9.ready:                       ; preds = %convergence.cascade.exit232
  %1918 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result247)
  %1919 = bitcast <8 x i1> %convergence.cascade.result247 to i8
  %1920 = call i8 @llvm.cttz.i8(i8 %1919, i1 false)
  %1921 = zext i8 %1920 to i32
  %1922 = select i1 %1918, i32 %1921, i32 0
  %.spill.load248 = load float, ptr %.spill49, align 4
  %.splatinsert249 = insertelement <8 x float> poison, float %.spill.load248, i64 0
  %.splat250 = shufflevector <8 x float> %.splatinsert249, <8 x float> poison, <8 x i32> zeroinitializer
  %.state251 = load <8 x float>, ptr %.slot62, align 32
  %.spill.load252 = load volatile <8 x i1>, ptr %.spill60, align 1
  %1923 = select <8 x i1> %.spill.load252, <8 x float> %.state251, <8 x float> %.splat250
  %tile_snapshot.spill.load253 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill58, align 64
  %1924 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load253, 0
  %1925 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load253, 1
  %.state254 = load <8 x i64>, ptr %.slot59, align 64
  %1926 = mul <8 x i64> %.state254, splat (i64 32)
  %1927 = add <8 x i64> %1925, %1926
  %1928 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1924, 0
  %1929 = insertvalue { <8 x ptr>, <8 x i64> } %1928, <8 x i64> %1927, 1
  %1930 = extractvalue { <8 x ptr>, <8 x i64> } %1929, 0
  %1931 = extractvalue { <8 x ptr>, <8 x i64> } %1929, 1
  %1932 = getelementptr i8, <8 x ptr> %1930, <8 x i64> %1931
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1923, <8 x ptr> %1932, i32 1, <8 x i1> %convergence.cascade.result247)
  %.state255 = load <8 x i64>, ptr %.slot59, align 64
  %1933 = add <8 x i64> %.state255, splat (i64 1)
  %1934 = load <8 x i64>, ptr %.slot59, align 64
  %1935 = select <8 x i1> %convergence.cascade.result247, <8 x i64> %1933, <8 x i64> %1934
  store <8 x i64> %1935, ptr %.slot59, align 64
  store <8 x i1> %convergence.cascade.result247, ptr %current.mask, align 1
  %1936 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result247)
  br i1 %1936, label %schedule.6, label %scheduler.loop

convergence.cascade256:                           ; preds = %convergence.cascade256, %schedule.10
  %convergence.cascade.flow260 = phi <8 x i1> [ %351, %schedule.10 ], [ %1979, %convergence.cascade256 ]
  %convergence.cascade.depth261 = phi i32 [ 0, %schedule.10 ], [ %1980, %convergence.cascade256 ]
  %1937 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow260)
  %1938 = load i32, ptr %current.token, align 4
  %1939 = icmp ne i32 %1938, 0
  %1940 = and i1 %1937, %1939
  %1941 = sub i32 %1938, 1
  %1942 = select i1 %1940, i32 %1941, i32 0
  %1943 = load i8, ptr %frame.active, align 1
  %1944 = trunc i32 %1942 to i8
  %1945 = shl i8 1, %1944
  %1946 = and i8 %1943, %1945
  %1947 = icmp ne i8 %1946, 0
  %1948 = load <8 x i32>, ptr %frame.static.id, align 32
  %1949 = extractelement <8 x i32> %1948, i32 %1942
  %convergence.target.pointer262 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %1949
  %convergence.dynamic.target263 = load i32, ptr %convergence.target.pointer262, align 4
  %1950 = icmp eq i32 %convergence.dynamic.target263, 10
  %1951 = and i1 %1947, %1950
  %1952 = and i1 %1940, %1951
  %1953 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1942
  %1954 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1942
  %1955 = load <8 x i1>, ptr %1953, align 1
  %1956 = load <8 x i1>, ptr %1954, align 1
  %1957 = or <8 x i1> %1956, %convergence.cascade.flow260
  %1958 = load <8 x i1>, ptr %live.mask, align 1
  %1959 = and <8 x i1> %1955, %1958
  %1960 = icmp eq <8 x i1> %1957, %1959
  %1961 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1960)
  %1962 = and i1 %1952, %1961
  %1963 = select i1 %1962, <8 x i1> zeroinitializer, <8 x i1> %1957
  %1964 = select i1 %1952, <8 x i1> %1963, <8 x i1> %1956
  store <8 x i1> %1964, ptr %1954, align 1
  %1965 = select i1 %1962, <8 x i1> zeroinitializer, <8 x i1> %1955
  store <8 x i1> %1965, ptr %1953, align 1
  %1966 = trunc i32 %1942 to i8
  %1967 = shl i8 1, %1966
  %1968 = xor i8 %1967, -1
  %1969 = and i8 %1943, %1968
  %1970 = select i1 %1962, i8 %1969, i8 %1943
  store i8 %1970, ptr %frame.active, align 1
  %.splatinsert264 = insertelement <8 x i1> poison, i1 %1952, i64 0
  %.splat265 = shufflevector <8 x i1> %.splatinsert264, <8 x i1> poison, <8 x i32> zeroinitializer
  %1971 = and <8 x i1> %convergence.cascade.flow260, %.splat265
  %1972 = load <8 x i1>, ptr %runnable.mask, align 1
  %1973 = xor <8 x i1> %1971, splat (i1 true)
  %1974 = and <8 x i1> %1972, %1973
  store <8 x i1> %1974, ptr %runnable.mask, align 1
  %.splatinsert266 = insertelement <8 x i1> poison, i1 %1962, i64 0
  %.splat267 = shufflevector <8 x i1> %.splatinsert266, <8 x i1> poison, <8 x i32> zeroinitializer
  %1975 = select <8 x i1> %.splat267, <8 x i1> %1957, <8 x i1> zeroinitializer
  %1976 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1977 = extractelement <8 x i32> %1976, i32 %1942
  %1978 = select i1 %1962, i32 %1977, i32 %1938
  store i32 %1978, ptr %current.token, align 4
  %.splatinsert268 = insertelement <8 x i1> poison, i1 %1952, i64 0
  %.splat269 = shufflevector <8 x i1> %.splatinsert268, <8 x i1> poison, <8 x i32> zeroinitializer
  %1979 = select <8 x i1> %.splat269, <8 x i1> %1975, <8 x i1> %convergence.cascade.flow260
  %1980 = add i32 %convergence.cascade.depth261, 1
  %1981 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1979)
  %1982 = icmp ult i32 %1980, 8
  %1983 = and i1 %1981, %1982
  %1984 = and i1 %1952, %1983
  %convergence.parent.token270 = load i32, ptr %current.token, align 4
  %convergence.parent.present271 = icmp ne i32 %convergence.parent.token270, 0
  %1985 = and i1 %1984, %convergence.parent.present271
  br i1 %1985, label %convergence.cascade256, label %convergence.cascade.exit257

convergence.cascade.exit257:                      ; preds = %convergence.cascade256, %schedule.10
  %convergence.cascade.result272 = phi <8 x i1> [ %351, %schedule.10 ], [ %1979, %convergence.cascade256 ]
  %1986 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result272)
  br i1 %1986, label %convergence.target.10.ready, label %scheduler.loop

convergence.target.10.ready:                      ; preds = %convergence.cascade.exit257
  %1987 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result272)
  %1988 = bitcast <8 x i1> %convergence.cascade.result272 to i8
  %1989 = call i8 @llvm.cttz.i8(i8 %1988, i1 false)
  %1990 = zext i8 %1989 to i32
  %1991 = select i1 %1987, i32 %1990, i32 0
  %1992 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill63, align 64
  %1993 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1994 = extractvalue { <8 x ptr>, <8 x i64> } %1992, 0
  %1995 = select <8 x i1> %convergence.cascade.result272, <8 x ptr> %1993, <8 x ptr> %1994
  %1996 = extractvalue { <8 x ptr>, <8 x i64> } %9, 1
  %1997 = extractvalue { <8 x ptr>, <8 x i64> } %1992, 1
  %1998 = select <8 x i1> %convergence.cascade.result272, <8 x i64> %1996, <8 x i64> %1997
  %1999 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1995, 0
  %2000 = insertvalue { <8 x ptr>, <8 x i64> } %1999, <8 x i64> %1998, 1
  store volatile { <8 x ptr>, <8 x i64> } %2000, ptr %tile_snapshot.spill63, align 64
  %2001 = load <8 x i64>, ptr %.slot64, align 64
  %2002 = select <8 x i1> %convergence.cascade.result272, <8 x i64> zeroinitializer, <8 x i64> %2001
  store <8 x i64> %2002, ptr %.slot64, align 64
  store <8 x i1> %convergence.cascade.result272, ptr %current.mask, align 1
  %2003 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result272)
  br i1 %2003, label %schedule.11, label %scheduler.loop

varying.divergent274:                             ; preds = %schedule.11
  %2004 = load i32, ptr %current.token, align 4
  %2005 = icmp ne i32 %2004, 0
  %2006 = sub i32 %2004, 1
  %2007 = select i1 %2005, i32 %2006, i32 0
  %2008 = load i8, ptr %frame.active, align 1
  %2009 = trunc i32 %2007 to i8
  %2010 = shl i8 1, %2009
  %2011 = and i8 %2008, %2010
  %2012 = icmp ne i8 %2011, 0
  %2013 = load <8 x i32>, ptr %frame.static.id, align 32
  %2014 = extractelement <8 x i32> %2013, i32 %2007
  %2015 = icmp eq i32 %2014, 4
  %2016 = and i1 %2012, %2015
  %2017 = and i1 %2005, %2016
  %2018 = xor i1 %2017, true
  %2019 = and i1 true, %2018
  %2020 = xor i8 %2008, -1
  %2021 = icmp ne i8 %2020, 0
  %2022 = xor i1 %2021, true
  %2023 = and i1 %2019, %2022
  br i1 %2023, label %convergence.overflow.trap276, label %convergence.overflow.resume277

varying.coherent275:                              ; preds = %schedule.11
  br i1 %362, label %varying.coherent.true280, label %varying.coherent.false281

convergence.overflow.trap276:                     ; preds = %varying.divergent274
  call void @llvm.trap()
  unreachable

convergence.overflow.resume277:                   ; preds = %varying.divergent274
  %2024 = call i8 @llvm.cttz.i8(i8 %2020, i1 false)
  %2025 = zext i8 %2024 to i32
  %2026 = select i1 %2021, i32 %2025, i32 0
  %2027 = trunc i32 %2026 to i8
  %2028 = shl i8 1, %2027
  %2029 = or i8 %2008, %2028
  %2030 = select i1 %2019, i8 %2029, i8 %2008
  store i8 %2030, ptr %frame.active, align 1
  %2031 = load <8 x i32>, ptr %frame.static.id, align 32
  %2032 = extractelement <8 x i32> %2031, i32 %2026
  %2033 = select i1 %2019, i32 4, i32 %2032
  %2034 = load <8 x i32>, ptr %frame.static.id, align 32
  %2035 = insertelement <8 x i32> %2034, i32 %2033, i32 %2026
  store <8 x i32> %2035, ptr %frame.static.id, align 32
  %2036 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2037 = extractelement <8 x i32> %2036, i32 %2026
  %2038 = select i1 %2019, i32 %2004, i32 %2037
  %2039 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2040 = insertelement <8 x i32> %2039, i32 %2038, i32 %2026
  store <8 x i32> %2040, ptr %frame.parent.token, align 32
  %2041 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2026
  %2042 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2026
  %2043 = load <8 x i1>, ptr %2041, align 1
  %2044 = load <8 x i1>, ptr %2042, align 1
  %2045 = select i1 %2019, <8 x i1> %352, <8 x i1> %2043
  store <8 x i1> %2045, ptr %2041, align 1
  %2046 = select i1 %2019, <8 x i1> zeroinitializer, <8 x i1> %2044
  store <8 x i1> %2046, ptr %2042, align 1
  %2047 = add i32 %2026, 1
  %2048 = select i1 %2017, i32 %2004, i32 %2047
  %2049 = select i1 true, i32 %2048, i32 %2004
  store i32 %2049, ptr %current.token, align 4
  %2050 = load i32, ptr %current.token, align 4
  %2051 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %359)
  %2052 = load i32, ptr %ready.count, align 4
  %2053 = icmp uge i32 %2052, 8
  %2054 = and i1 %2051, %2053
  br i1 %2054, label %ready.overflow.trap278, label %ready.overflow.resume279

ready.overflow.trap278:                           ; preds = %convergence.overflow.resume277
  call void @llvm.trap()
  unreachable

ready.overflow.resume279:                         ; preds = %convergence.overflow.resume277
  %2055 = select i1 %2051, i32 %2052, i32 0
  %2056 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2055
  %2057 = load <8 x i1>, ptr %2056, align 1
  %2058 = select i1 %2051, <8 x i1> %359, <8 x i1> %2057
  store <8 x i1> %2058, ptr %2056, align 1
  %2059 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2055
  %2060 = load i32, ptr %2059, align 4
  %2061 = select i1 %2051, i32 12, i32 %2060
  store i32 %2061, ptr %2059, align 4
  %2062 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2055
  %2063 = load i32, ptr %2062, align 4
  %2064 = select i1 %2051, i32 %2050, i32 %2063
  store i32 %2064, ptr %2062, align 4
  %2065 = add i32 %2052, 1
  %2066 = select i1 %2051, i32 %2065, i32 %2052
  store i32 %2066, ptr %ready.count, align 4
  %2067 = load <8 x i1>, ptr %runnable.mask, align 1
  %2068 = or <8 x i1> %2067, %359
  store <8 x i1> %2068, ptr %runnable.mask, align 1
  store <8 x i1> %361, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true280:                         ; preds = %varying.coherent275
  store <8 x i1> %352, ptr %current.mask, align 1
  %2069 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %352)
  br i1 %2069, label %schedule.12, label %scheduler.loop

varying.coherent.false281:                        ; preds = %varying.coherent275
  store <8 x i1> %352, ptr %current.mask, align 1
  %2070 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %352)
  br i1 %2070, label %schedule.13, label %scheduler.loop

convergence.cascade289:                           ; preds = %convergence.cascade289, %schedule.13
  %convergence.cascade.flow293 = phi <8 x i1> [ %414, %schedule.13 ], [ %2113, %convergence.cascade289 ]
  %convergence.cascade.depth294 = phi i32 [ 0, %schedule.13 ], [ %2114, %convergence.cascade289 ]
  %2071 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow293)
  %2072 = load i32, ptr %current.token, align 4
  %2073 = icmp ne i32 %2072, 0
  %2074 = and i1 %2071, %2073
  %2075 = sub i32 %2072, 1
  %2076 = select i1 %2074, i32 %2075, i32 0
  %2077 = load i8, ptr %frame.active, align 1
  %2078 = trunc i32 %2076 to i8
  %2079 = shl i8 1, %2078
  %2080 = and i8 %2077, %2079
  %2081 = icmp ne i8 %2080, 0
  %2082 = load <8 x i32>, ptr %frame.static.id, align 32
  %2083 = extractelement <8 x i32> %2082, i32 %2076
  %convergence.target.pointer295 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %2083
  %convergence.dynamic.target296 = load i32, ptr %convergence.target.pointer295, align 4
  %2084 = icmp eq i32 %convergence.dynamic.target296, 13
  %2085 = and i1 %2081, %2084
  %2086 = and i1 %2074, %2085
  %2087 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2076
  %2088 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2076
  %2089 = load <8 x i1>, ptr %2087, align 1
  %2090 = load <8 x i1>, ptr %2088, align 1
  %2091 = or <8 x i1> %2090, %convergence.cascade.flow293
  %2092 = load <8 x i1>, ptr %live.mask, align 1
  %2093 = and <8 x i1> %2089, %2092
  %2094 = icmp eq <8 x i1> %2091, %2093
  %2095 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2094)
  %2096 = and i1 %2086, %2095
  %2097 = select i1 %2096, <8 x i1> zeroinitializer, <8 x i1> %2091
  %2098 = select i1 %2086, <8 x i1> %2097, <8 x i1> %2090
  store <8 x i1> %2098, ptr %2088, align 1
  %2099 = select i1 %2096, <8 x i1> zeroinitializer, <8 x i1> %2089
  store <8 x i1> %2099, ptr %2087, align 1
  %2100 = trunc i32 %2076 to i8
  %2101 = shl i8 1, %2100
  %2102 = xor i8 %2101, -1
  %2103 = and i8 %2077, %2102
  %2104 = select i1 %2096, i8 %2103, i8 %2077
  store i8 %2104, ptr %frame.active, align 1
  %.splatinsert297 = insertelement <8 x i1> poison, i1 %2086, i64 0
  %.splat298 = shufflevector <8 x i1> %.splatinsert297, <8 x i1> poison, <8 x i32> zeroinitializer
  %2105 = and <8 x i1> %convergence.cascade.flow293, %.splat298
  %2106 = load <8 x i1>, ptr %runnable.mask, align 1
  %2107 = xor <8 x i1> %2105, splat (i1 true)
  %2108 = and <8 x i1> %2106, %2107
  store <8 x i1> %2108, ptr %runnable.mask, align 1
  %.splatinsert299 = insertelement <8 x i1> poison, i1 %2096, i64 0
  %.splat300 = shufflevector <8 x i1> %.splatinsert299, <8 x i1> poison, <8 x i32> zeroinitializer
  %2109 = select <8 x i1> %.splat300, <8 x i1> %2091, <8 x i1> zeroinitializer
  %2110 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2111 = extractelement <8 x i32> %2110, i32 %2076
  %2112 = select i1 %2096, i32 %2111, i32 %2072
  store i32 %2112, ptr %current.token, align 4
  %.splatinsert301 = insertelement <8 x i1> poison, i1 %2086, i64 0
  %.splat302 = shufflevector <8 x i1> %.splatinsert301, <8 x i1> poison, <8 x i32> zeroinitializer
  %2113 = select <8 x i1> %.splat302, <8 x i1> %2109, <8 x i1> %convergence.cascade.flow293
  %2114 = add i32 %convergence.cascade.depth294, 1
  %2115 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2113)
  %2116 = icmp ult i32 %2114, 8
  %2117 = and i1 %2115, %2116
  %2118 = and i1 %2086, %2117
  %convergence.parent.token303 = load i32, ptr %current.token, align 4
  %convergence.parent.present304 = icmp ne i32 %convergence.parent.token303, 0
  %2119 = and i1 %2118, %convergence.parent.present304
  br i1 %2119, label %convergence.cascade289, label %convergence.cascade.exit290

convergence.cascade.exit290:                      ; preds = %convergence.cascade289, %schedule.13
  %convergence.cascade.result305 = phi <8 x i1> [ %414, %schedule.13 ], [ %2113, %convergence.cascade289 ]
  %2120 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  br i1 %2120, label %convergence.target.13.ready, label %scheduler.loop

convergence.target.13.ready:                      ; preds = %convergence.cascade.exit290
  %2121 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2122 = bitcast <8 x i1> %convergence.cascade.result305 to i8
  %2123 = call i8 @llvm.cttz.i8(i8 %2122, i1 false)
  %2124 = zext i8 %2123 to i32
  %2125 = select i1 %2121, i32 %2124, i32 0
  %2126 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %2127 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2128 = extractvalue { <8 x ptr>, <8 x i64> } %2126, 0
  %2129 = select <8 x i1> %convergence.cascade.result305, <8 x ptr> %2127, <8 x ptr> %2128
  %2130 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2131 = extractvalue { <8 x ptr>, <8 x i64> } %2126, 1
  %2132 = select <8 x i1> %convergence.cascade.result305, <8 x i64> %2130, <8 x i64> %2131
  %2133 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2129, 0
  %2134 = insertvalue { <8 x ptr>, <8 x i64> } %2133, <8 x i64> %2132, 1
  store volatile { <8 x ptr>, <8 x i64> } %2134, ptr %tile_snapshot.spill65, align 64
  %2135 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2136 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2137 = add <8 x i64> %2136, zeroinitializer
  %2138 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2135, 0
  %2139 = insertvalue { <8 x ptr>, <8 x i64> } %2138, <8 x i64> %2137, 1
  %2140 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2141 = extractvalue { <8 x ptr>, <8 x i64> } %2139, 1
  %2142 = extractelement <8 x ptr> %2140, i32 0
  %2143 = extractelement <8 x i64> %2141, i32 %2125
  %2144 = zext i32 %2125 to i64
  %2145 = mul i64 %2144, 8
  %2146 = sub i64 %2143, %2145
  %2147 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2148 = select i1 %2147, i64 %2146, i64 0
  %private.contiguous.address306 = getelementptr i8, ptr %2142, i64 %2148
  %private.contiguous.preserve307 = load <8 x i64>, ptr %private.contiguous.address306, align 8
  %2149 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 -2), <8 x i64> %private.contiguous.preserve307
  store <8 x i64> %2149, ptr %private.contiguous.address306, align 8
  %2150 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2151 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2152 = add <8 x i64> %2151, splat (i64 64)
  %2153 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2150, 0
  %2154 = insertvalue { <8 x ptr>, <8 x i64> } %2153, <8 x i64> %2152, 1
  %2155 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2156 = extractvalue { <8 x ptr>, <8 x i64> } %2154, 1
  %2157 = extractelement <8 x ptr> %2155, i32 0
  %2158 = extractelement <8 x i64> %2156, i32 %2125
  %2159 = zext i32 %2125 to i64
  %2160 = mul i64 %2159, 8
  %2161 = sub i64 %2158, %2160
  %2162 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2163 = select i1 %2162, i64 %2161, i64 0
  %private.contiguous.address308 = getelementptr i8, ptr %2157, i64 %2163
  %private.contiguous.preserve309 = load <8 x i64>, ptr %private.contiguous.address308, align 8
  %2164 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 -1), <8 x i64> %private.contiguous.preserve309
  store <8 x i64> %2164, ptr %private.contiguous.address308, align 8
  %2165 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2166 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2167 = add <8 x i64> %2166, splat (i64 128)
  %2168 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2165, 0
  %2169 = insertvalue { <8 x ptr>, <8 x i64> } %2168, <8 x i64> %2167, 1
  %2170 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2171 = extractvalue { <8 x ptr>, <8 x i64> } %2169, 1
  %2172 = extractelement <8 x ptr> %2170, i32 0
  %2173 = extractelement <8 x i64> %2171, i32 %2125
  %2174 = zext i32 %2125 to i64
  %2175 = mul i64 %2174, 8
  %2176 = sub i64 %2173, %2175
  %2177 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2178 = select i1 %2177, i64 %2176, i64 0
  %private.contiguous.address310 = getelementptr i8, ptr %2172, i64 %2178
  %private.contiguous.preserve311 = load <8 x i64>, ptr %private.contiguous.address310, align 8
  %2179 = select <8 x i1> %convergence.cascade.result305, <8 x i64> zeroinitializer, <8 x i64> %private.contiguous.preserve311
  store <8 x i64> %2179, ptr %private.contiguous.address310, align 8
  %2180 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2181 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2182 = add <8 x i64> %2181, splat (i64 192)
  %2183 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2180, 0
  %2184 = insertvalue { <8 x ptr>, <8 x i64> } %2183, <8 x i64> %2182, 1
  %2185 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2186 = extractvalue { <8 x ptr>, <8 x i64> } %2184, 1
  %2187 = extractelement <8 x ptr> %2185, i32 0
  %2188 = extractelement <8 x i64> %2186, i32 %2125
  %2189 = zext i32 %2125 to i64
  %2190 = mul i64 %2189, 8
  %2191 = sub i64 %2188, %2190
  %2192 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2193 = select i1 %2192, i64 %2191, i64 0
  %private.contiguous.address312 = getelementptr i8, ptr %2187, i64 %2193
  %private.contiguous.preserve313 = load <8 x i64>, ptr %private.contiguous.address312, align 8
  %2194 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 1), <8 x i64> %private.contiguous.preserve313
  store <8 x i64> %2194, ptr %private.contiguous.address312, align 8
  %2195 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2196 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2197 = add <8 x i64> %2196, splat (i64 256)
  %2198 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2195, 0
  %2199 = insertvalue { <8 x ptr>, <8 x i64> } %2198, <8 x i64> %2197, 1
  %2200 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2201 = extractvalue { <8 x ptr>, <8 x i64> } %2199, 1
  %2202 = extractelement <8 x ptr> %2200, i32 0
  %2203 = extractelement <8 x i64> %2201, i32 %2125
  %2204 = zext i32 %2125 to i64
  %2205 = mul i64 %2204, 8
  %2206 = sub i64 %2203, %2205
  %2207 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2208 = select i1 %2207, i64 %2206, i64 0
  %private.contiguous.address314 = getelementptr i8, ptr %2202, i64 %2208
  %private.contiguous.preserve315 = load <8 x i64>, ptr %private.contiguous.address314, align 8
  %2209 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 2), <8 x i64> %private.contiguous.preserve315
  store <8 x i64> %2209, ptr %private.contiguous.address314, align 8
  %2210 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2211 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2212 = add <8 x i64> %2211, splat (i64 320)
  %2213 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2210, 0
  %2214 = insertvalue { <8 x ptr>, <8 x i64> } %2213, <8 x i64> %2212, 1
  %2215 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2216 = extractvalue { <8 x ptr>, <8 x i64> } %2214, 1
  %2217 = extractelement <8 x ptr> %2215, i32 0
  %2218 = extractelement <8 x i64> %2216, i32 %2125
  %2219 = zext i32 %2125 to i64
  %2220 = mul i64 %2219, 8
  %2221 = sub i64 %2218, %2220
  %2222 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2223 = select i1 %2222, i64 %2221, i64 0
  %private.contiguous.address316 = getelementptr i8, ptr %2217, i64 %2223
  %private.contiguous.preserve317 = load <8 x i64>, ptr %private.contiguous.address316, align 8
  %2224 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 3), <8 x i64> %private.contiguous.preserve317
  store <8 x i64> %2224, ptr %private.contiguous.address316, align 8
  %2225 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2226 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2227 = add <8 x i64> %2226, splat (i64 384)
  %2228 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2225, 0
  %2229 = insertvalue { <8 x ptr>, <8 x i64> } %2228, <8 x i64> %2227, 1
  %2230 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2231 = extractvalue { <8 x ptr>, <8 x i64> } %2229, 1
  %2232 = extractelement <8 x ptr> %2230, i32 0
  %2233 = extractelement <8 x i64> %2231, i32 %2125
  %2234 = zext i32 %2125 to i64
  %2235 = mul i64 %2234, 8
  %2236 = sub i64 %2233, %2235
  %2237 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2238 = select i1 %2237, i64 %2236, i64 0
  %private.contiguous.address318 = getelementptr i8, ptr %2232, i64 %2238
  %private.contiguous.preserve319 = load <8 x i64>, ptr %private.contiguous.address318, align 8
  %2239 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 4), <8 x i64> %private.contiguous.preserve319
  store <8 x i64> %2239, ptr %private.contiguous.address318, align 8
  %2240 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2241 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2242 = add <8 x i64> %2241, splat (i64 448)
  %2243 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2240, 0
  %2244 = insertvalue { <8 x ptr>, <8 x i64> } %2243, <8 x i64> %2242, 1
  %2245 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2246 = extractvalue { <8 x ptr>, <8 x i64> } %2244, 1
  %2247 = extractelement <8 x ptr> %2245, i32 0
  %2248 = extractelement <8 x i64> %2246, i32 %2125
  %2249 = zext i32 %2125 to i64
  %2250 = mul i64 %2249, 8
  %2251 = sub i64 %2248, %2250
  %2252 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2253 = select i1 %2252, i64 %2251, i64 0
  %private.contiguous.address320 = getelementptr i8, ptr %2247, i64 %2253
  %private.contiguous.preserve321 = load <8 x i64>, ptr %private.contiguous.address320, align 8
  %2254 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 5), <8 x i64> %private.contiguous.preserve321
  store <8 x i64> %2254, ptr %private.contiguous.address320, align 8
  %2255 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2256 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2257 = add <8 x i64> %2256, splat (i64 512)
  %2258 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2255, 0
  %2259 = insertvalue { <8 x ptr>, <8 x i64> } %2258, <8 x i64> %2257, 1
  %2260 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2261 = extractvalue { <8 x ptr>, <8 x i64> } %2259, 1
  %2262 = extractelement <8 x ptr> %2260, i32 0
  %2263 = extractelement <8 x i64> %2261, i32 %2125
  %2264 = zext i32 %2125 to i64
  %2265 = mul i64 %2264, 8
  %2266 = sub i64 %2263, %2265
  %2267 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2268 = select i1 %2267, i64 %2266, i64 0
  %private.contiguous.address322 = getelementptr i8, ptr %2262, i64 %2268
  %private.contiguous.preserve323 = load <8 x i64>, ptr %private.contiguous.address322, align 8
  %2269 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 6), <8 x i64> %private.contiguous.preserve323
  store <8 x i64> %2269, ptr %private.contiguous.address322, align 8
  %2270 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2271 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2272 = add <8 x i64> %2271, splat (i64 576)
  %2273 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2270, 0
  %2274 = insertvalue { <8 x ptr>, <8 x i64> } %2273, <8 x i64> %2272, 1
  %2275 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2276 = extractvalue { <8 x ptr>, <8 x i64> } %2274, 1
  %2277 = extractelement <8 x ptr> %2275, i32 0
  %2278 = extractelement <8 x i64> %2276, i32 %2125
  %2279 = zext i32 %2125 to i64
  %2280 = mul i64 %2279, 8
  %2281 = sub i64 %2278, %2280
  %2282 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2283 = select i1 %2282, i64 %2281, i64 0
  %private.contiguous.address324 = getelementptr i8, ptr %2277, i64 %2283
  %private.contiguous.preserve325 = load <8 x i64>, ptr %private.contiguous.address324, align 8
  %2284 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 7), <8 x i64> %private.contiguous.preserve325
  store <8 x i64> %2284, ptr %private.contiguous.address324, align 8
  %2285 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2286 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2287 = add <8 x i64> %2286, splat (i64 640)
  %2288 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2285, 0
  %2289 = insertvalue { <8 x ptr>, <8 x i64> } %2288, <8 x i64> %2287, 1
  %2290 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2291 = extractvalue { <8 x ptr>, <8 x i64> } %2289, 1
  %2292 = extractelement <8 x ptr> %2290, i32 0
  %2293 = extractelement <8 x i64> %2291, i32 %2125
  %2294 = zext i32 %2125 to i64
  %2295 = mul i64 %2294, 8
  %2296 = sub i64 %2293, %2295
  %2297 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2298 = select i1 %2297, i64 %2296, i64 0
  %private.contiguous.address326 = getelementptr i8, ptr %2292, i64 %2298
  %private.contiguous.preserve327 = load <8 x i64>, ptr %private.contiguous.address326, align 8
  %2299 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 8), <8 x i64> %private.contiguous.preserve327
  store <8 x i64> %2299, ptr %private.contiguous.address326, align 8
  %2300 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2301 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2302 = add <8 x i64> %2301, splat (i64 704)
  %2303 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2300, 0
  %2304 = insertvalue { <8 x ptr>, <8 x i64> } %2303, <8 x i64> %2302, 1
  %2305 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2306 = extractvalue { <8 x ptr>, <8 x i64> } %2304, 1
  %2307 = extractelement <8 x ptr> %2305, i32 0
  %2308 = extractelement <8 x i64> %2306, i32 %2125
  %2309 = zext i32 %2125 to i64
  %2310 = mul i64 %2309, 8
  %2311 = sub i64 %2308, %2310
  %2312 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2313 = select i1 %2312, i64 %2311, i64 0
  %private.contiguous.address328 = getelementptr i8, ptr %2307, i64 %2313
  %private.contiguous.preserve329 = load <8 x i64>, ptr %private.contiguous.address328, align 8
  %2314 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 9), <8 x i64> %private.contiguous.preserve329
  store <8 x i64> %2314, ptr %private.contiguous.address328, align 8
  %2315 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2316 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2317 = add <8 x i64> %2316, splat (i64 768)
  %2318 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2315, 0
  %2319 = insertvalue { <8 x ptr>, <8 x i64> } %2318, <8 x i64> %2317, 1
  %2320 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2321 = extractvalue { <8 x ptr>, <8 x i64> } %2319, 1
  %2322 = extractelement <8 x ptr> %2320, i32 0
  %2323 = extractelement <8 x i64> %2321, i32 %2125
  %2324 = zext i32 %2125 to i64
  %2325 = mul i64 %2324, 8
  %2326 = sub i64 %2323, %2325
  %2327 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2328 = select i1 %2327, i64 %2326, i64 0
  %private.contiguous.address330 = getelementptr i8, ptr %2322, i64 %2328
  %private.contiguous.preserve331 = load <8 x i64>, ptr %private.contiguous.address330, align 8
  %2329 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 10), <8 x i64> %private.contiguous.preserve331
  store <8 x i64> %2329, ptr %private.contiguous.address330, align 8
  %2330 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2331 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2332 = add <8 x i64> %2331, splat (i64 832)
  %2333 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2330, 0
  %2334 = insertvalue { <8 x ptr>, <8 x i64> } %2333, <8 x i64> %2332, 1
  %2335 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2336 = extractvalue { <8 x ptr>, <8 x i64> } %2334, 1
  %2337 = extractelement <8 x ptr> %2335, i32 0
  %2338 = extractelement <8 x i64> %2336, i32 %2125
  %2339 = zext i32 %2125 to i64
  %2340 = mul i64 %2339, 8
  %2341 = sub i64 %2338, %2340
  %2342 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2343 = select i1 %2342, i64 %2341, i64 0
  %private.contiguous.address332 = getelementptr i8, ptr %2337, i64 %2343
  %private.contiguous.preserve333 = load <8 x i64>, ptr %private.contiguous.address332, align 8
  %2344 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 11), <8 x i64> %private.contiguous.preserve333
  store <8 x i64> %2344, ptr %private.contiguous.address332, align 8
  %2345 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2346 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2347 = add <8 x i64> %2346, splat (i64 896)
  %2348 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2345, 0
  %2349 = insertvalue { <8 x ptr>, <8 x i64> } %2348, <8 x i64> %2347, 1
  %2350 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2351 = extractvalue { <8 x ptr>, <8 x i64> } %2349, 1
  %2352 = extractelement <8 x ptr> %2350, i32 0
  %2353 = extractelement <8 x i64> %2351, i32 %2125
  %2354 = zext i32 %2125 to i64
  %2355 = mul i64 %2354, 8
  %2356 = sub i64 %2353, %2355
  %2357 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2358 = select i1 %2357, i64 %2356, i64 0
  %private.contiguous.address334 = getelementptr i8, ptr %2352, i64 %2358
  %private.contiguous.preserve335 = load <8 x i64>, ptr %private.contiguous.address334, align 8
  %2359 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 12), <8 x i64> %private.contiguous.preserve335
  store <8 x i64> %2359, ptr %private.contiguous.address334, align 8
  %2360 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2361 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2362 = add <8 x i64> %2361, splat (i64 960)
  %2363 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2360, 0
  %2364 = insertvalue { <8 x ptr>, <8 x i64> } %2363, <8 x i64> %2362, 1
  %2365 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2366 = extractvalue { <8 x ptr>, <8 x i64> } %2364, 1
  %2367 = extractelement <8 x ptr> %2365, i32 0
  %2368 = extractelement <8 x i64> %2366, i32 %2125
  %2369 = zext i32 %2125 to i64
  %2370 = mul i64 %2369, 8
  %2371 = sub i64 %2368, %2370
  %2372 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2373 = select i1 %2372, i64 %2371, i64 0
  %private.contiguous.address336 = getelementptr i8, ptr %2367, i64 %2373
  %private.contiguous.preserve337 = load <8 x i64>, ptr %private.contiguous.address336, align 8
  %2374 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 13), <8 x i64> %private.contiguous.preserve337
  store <8 x i64> %2374, ptr %private.contiguous.address336, align 8
  %2375 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2376 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2377 = add <8 x i64> %2376, splat (i64 1024)
  %2378 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2375, 0
  %2379 = insertvalue { <8 x ptr>, <8 x i64> } %2378, <8 x i64> %2377, 1
  %2380 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2381 = extractvalue { <8 x ptr>, <8 x i64> } %2379, 1
  %2382 = extractelement <8 x ptr> %2380, i32 0
  %2383 = extractelement <8 x i64> %2381, i32 %2125
  %2384 = zext i32 %2125 to i64
  %2385 = mul i64 %2384, 8
  %2386 = sub i64 %2383, %2385
  %2387 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2388 = select i1 %2387, i64 %2386, i64 0
  %private.contiguous.address338 = getelementptr i8, ptr %2382, i64 %2388
  %private.contiguous.preserve339 = load <8 x i64>, ptr %private.contiguous.address338, align 8
  %2389 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 14), <8 x i64> %private.contiguous.preserve339
  store <8 x i64> %2389, ptr %private.contiguous.address338, align 8
  %2390 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2391 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2392 = add <8 x i64> %2391, splat (i64 1088)
  %2393 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2390, 0
  %2394 = insertvalue { <8 x ptr>, <8 x i64> } %2393, <8 x i64> %2392, 1
  %2395 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2396 = extractvalue { <8 x ptr>, <8 x i64> } %2394, 1
  %2397 = extractelement <8 x ptr> %2395, i32 0
  %2398 = extractelement <8 x i64> %2396, i32 %2125
  %2399 = zext i32 %2125 to i64
  %2400 = mul i64 %2399, 8
  %2401 = sub i64 %2398, %2400
  %2402 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2403 = select i1 %2402, i64 %2401, i64 0
  %private.contiguous.address340 = getelementptr i8, ptr %2397, i64 %2403
  %private.contiguous.preserve341 = load <8 x i64>, ptr %private.contiguous.address340, align 8
  %2404 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 15), <8 x i64> %private.contiguous.preserve341
  store <8 x i64> %2404, ptr %private.contiguous.address340, align 8
  %2405 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2406 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2407 = add <8 x i64> %2406, splat (i64 1152)
  %2408 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2405, 0
  %2409 = insertvalue { <8 x ptr>, <8 x i64> } %2408, <8 x i64> %2407, 1
  %2410 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2411 = extractvalue { <8 x ptr>, <8 x i64> } %2409, 1
  %2412 = extractelement <8 x ptr> %2410, i32 0
  %2413 = extractelement <8 x i64> %2411, i32 %2125
  %2414 = zext i32 %2125 to i64
  %2415 = mul i64 %2414, 8
  %2416 = sub i64 %2413, %2415
  %2417 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2418 = select i1 %2417, i64 %2416, i64 0
  %private.contiguous.address342 = getelementptr i8, ptr %2412, i64 %2418
  %private.contiguous.preserve343 = load <8 x i64>, ptr %private.contiguous.address342, align 8
  %2419 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 16), <8 x i64> %private.contiguous.preserve343
  store <8 x i64> %2419, ptr %private.contiguous.address342, align 8
  %2420 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2421 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2422 = add <8 x i64> %2421, splat (i64 1216)
  %2423 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2420, 0
  %2424 = insertvalue { <8 x ptr>, <8 x i64> } %2423, <8 x i64> %2422, 1
  %2425 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2426 = extractvalue { <8 x ptr>, <8 x i64> } %2424, 1
  %2427 = extractelement <8 x ptr> %2425, i32 0
  %2428 = extractelement <8 x i64> %2426, i32 %2125
  %2429 = zext i32 %2125 to i64
  %2430 = mul i64 %2429, 8
  %2431 = sub i64 %2428, %2430
  %2432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2433 = select i1 %2432, i64 %2431, i64 0
  %private.contiguous.address344 = getelementptr i8, ptr %2427, i64 %2433
  %private.contiguous.preserve345 = load <8 x i64>, ptr %private.contiguous.address344, align 8
  %2434 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 17), <8 x i64> %private.contiguous.preserve345
  store <8 x i64> %2434, ptr %private.contiguous.address344, align 8
  %2435 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2436 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2437 = add <8 x i64> %2436, splat (i64 1280)
  %2438 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2435, 0
  %2439 = insertvalue { <8 x ptr>, <8 x i64> } %2438, <8 x i64> %2437, 1
  %2440 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2441 = extractvalue { <8 x ptr>, <8 x i64> } %2439, 1
  %2442 = extractelement <8 x ptr> %2440, i32 0
  %2443 = extractelement <8 x i64> %2441, i32 %2125
  %2444 = zext i32 %2125 to i64
  %2445 = mul i64 %2444, 8
  %2446 = sub i64 %2443, %2445
  %2447 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2448 = select i1 %2447, i64 %2446, i64 0
  %private.contiguous.address346 = getelementptr i8, ptr %2442, i64 %2448
  %private.contiguous.preserve347 = load <8 x i64>, ptr %private.contiguous.address346, align 8
  %2449 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 18), <8 x i64> %private.contiguous.preserve347
  store <8 x i64> %2449, ptr %private.contiguous.address346, align 8
  %2450 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2451 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2452 = add <8 x i64> %2451, splat (i64 1344)
  %2453 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2450, 0
  %2454 = insertvalue { <8 x ptr>, <8 x i64> } %2453, <8 x i64> %2452, 1
  %2455 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2456 = extractvalue { <8 x ptr>, <8 x i64> } %2454, 1
  %2457 = extractelement <8 x ptr> %2455, i32 0
  %2458 = extractelement <8 x i64> %2456, i32 %2125
  %2459 = zext i32 %2125 to i64
  %2460 = mul i64 %2459, 8
  %2461 = sub i64 %2458, %2460
  %2462 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2463 = select i1 %2462, i64 %2461, i64 0
  %private.contiguous.address348 = getelementptr i8, ptr %2457, i64 %2463
  %private.contiguous.preserve349 = load <8 x i64>, ptr %private.contiguous.address348, align 8
  %2464 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 19), <8 x i64> %private.contiguous.preserve349
  store <8 x i64> %2464, ptr %private.contiguous.address348, align 8
  %2465 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2466 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2467 = add <8 x i64> %2466, splat (i64 1408)
  %2468 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2465, 0
  %2469 = insertvalue { <8 x ptr>, <8 x i64> } %2468, <8 x i64> %2467, 1
  %2470 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2471 = extractvalue { <8 x ptr>, <8 x i64> } %2469, 1
  %2472 = extractelement <8 x ptr> %2470, i32 0
  %2473 = extractelement <8 x i64> %2471, i32 %2125
  %2474 = zext i32 %2125 to i64
  %2475 = mul i64 %2474, 8
  %2476 = sub i64 %2473, %2475
  %2477 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2478 = select i1 %2477, i64 %2476, i64 0
  %private.contiguous.address350 = getelementptr i8, ptr %2472, i64 %2478
  %private.contiguous.preserve351 = load <8 x i64>, ptr %private.contiguous.address350, align 8
  %2479 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 20), <8 x i64> %private.contiguous.preserve351
  store <8 x i64> %2479, ptr %private.contiguous.address350, align 8
  %2480 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2481 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2482 = add <8 x i64> %2481, splat (i64 1472)
  %2483 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2480, 0
  %2484 = insertvalue { <8 x ptr>, <8 x i64> } %2483, <8 x i64> %2482, 1
  %2485 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2486 = extractvalue { <8 x ptr>, <8 x i64> } %2484, 1
  %2487 = extractelement <8 x ptr> %2485, i32 0
  %2488 = extractelement <8 x i64> %2486, i32 %2125
  %2489 = zext i32 %2125 to i64
  %2490 = mul i64 %2489, 8
  %2491 = sub i64 %2488, %2490
  %2492 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2493 = select i1 %2492, i64 %2491, i64 0
  %private.contiguous.address352 = getelementptr i8, ptr %2487, i64 %2493
  %private.contiguous.preserve353 = load <8 x i64>, ptr %private.contiguous.address352, align 8
  %2494 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 21), <8 x i64> %private.contiguous.preserve353
  store <8 x i64> %2494, ptr %private.contiguous.address352, align 8
  %2495 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2496 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2497 = add <8 x i64> %2496, splat (i64 1536)
  %2498 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2495, 0
  %2499 = insertvalue { <8 x ptr>, <8 x i64> } %2498, <8 x i64> %2497, 1
  %2500 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2501 = extractvalue { <8 x ptr>, <8 x i64> } %2499, 1
  %2502 = extractelement <8 x ptr> %2500, i32 0
  %2503 = extractelement <8 x i64> %2501, i32 %2125
  %2504 = zext i32 %2125 to i64
  %2505 = mul i64 %2504, 8
  %2506 = sub i64 %2503, %2505
  %2507 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2508 = select i1 %2507, i64 %2506, i64 0
  %private.contiguous.address354 = getelementptr i8, ptr %2502, i64 %2508
  %private.contiguous.preserve355 = load <8 x i64>, ptr %private.contiguous.address354, align 8
  %2509 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 22), <8 x i64> %private.contiguous.preserve355
  store <8 x i64> %2509, ptr %private.contiguous.address354, align 8
  %2510 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2511 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2512 = add <8 x i64> %2511, splat (i64 1600)
  %2513 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2510, 0
  %2514 = insertvalue { <8 x ptr>, <8 x i64> } %2513, <8 x i64> %2512, 1
  %2515 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2516 = extractvalue { <8 x ptr>, <8 x i64> } %2514, 1
  %2517 = extractelement <8 x ptr> %2515, i32 0
  %2518 = extractelement <8 x i64> %2516, i32 %2125
  %2519 = zext i32 %2125 to i64
  %2520 = mul i64 %2519, 8
  %2521 = sub i64 %2518, %2520
  %2522 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2523 = select i1 %2522, i64 %2521, i64 0
  %private.contiguous.address356 = getelementptr i8, ptr %2517, i64 %2523
  %private.contiguous.preserve357 = load <8 x i64>, ptr %private.contiguous.address356, align 8
  %2524 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 23), <8 x i64> %private.contiguous.preserve357
  store <8 x i64> %2524, ptr %private.contiguous.address356, align 8
  %2525 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2526 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2527 = add <8 x i64> %2526, splat (i64 1664)
  %2528 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2525, 0
  %2529 = insertvalue { <8 x ptr>, <8 x i64> } %2528, <8 x i64> %2527, 1
  %2530 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2531 = extractvalue { <8 x ptr>, <8 x i64> } %2529, 1
  %2532 = extractelement <8 x ptr> %2530, i32 0
  %2533 = extractelement <8 x i64> %2531, i32 %2125
  %2534 = zext i32 %2125 to i64
  %2535 = mul i64 %2534, 8
  %2536 = sub i64 %2533, %2535
  %2537 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2538 = select i1 %2537, i64 %2536, i64 0
  %private.contiguous.address358 = getelementptr i8, ptr %2532, i64 %2538
  %private.contiguous.preserve359 = load <8 x i64>, ptr %private.contiguous.address358, align 8
  %2539 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 24), <8 x i64> %private.contiguous.preserve359
  store <8 x i64> %2539, ptr %private.contiguous.address358, align 8
  %2540 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2541 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2542 = add <8 x i64> %2541, splat (i64 1728)
  %2543 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2540, 0
  %2544 = insertvalue { <8 x ptr>, <8 x i64> } %2543, <8 x i64> %2542, 1
  %2545 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2546 = extractvalue { <8 x ptr>, <8 x i64> } %2544, 1
  %2547 = extractelement <8 x ptr> %2545, i32 0
  %2548 = extractelement <8 x i64> %2546, i32 %2125
  %2549 = zext i32 %2125 to i64
  %2550 = mul i64 %2549, 8
  %2551 = sub i64 %2548, %2550
  %2552 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2553 = select i1 %2552, i64 %2551, i64 0
  %private.contiguous.address360 = getelementptr i8, ptr %2547, i64 %2553
  %private.contiguous.preserve361 = load <8 x i64>, ptr %private.contiguous.address360, align 8
  %2554 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 25), <8 x i64> %private.contiguous.preserve361
  store <8 x i64> %2554, ptr %private.contiguous.address360, align 8
  %2555 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2556 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2557 = add <8 x i64> %2556, splat (i64 1792)
  %2558 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2555, 0
  %2559 = insertvalue { <8 x ptr>, <8 x i64> } %2558, <8 x i64> %2557, 1
  %2560 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2561 = extractvalue { <8 x ptr>, <8 x i64> } %2559, 1
  %2562 = extractelement <8 x ptr> %2560, i32 0
  %2563 = extractelement <8 x i64> %2561, i32 %2125
  %2564 = zext i32 %2125 to i64
  %2565 = mul i64 %2564, 8
  %2566 = sub i64 %2563, %2565
  %2567 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2568 = select i1 %2567, i64 %2566, i64 0
  %private.contiguous.address362 = getelementptr i8, ptr %2562, i64 %2568
  %private.contiguous.preserve363 = load <8 x i64>, ptr %private.contiguous.address362, align 8
  %2569 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 26), <8 x i64> %private.contiguous.preserve363
  store <8 x i64> %2569, ptr %private.contiguous.address362, align 8
  %2570 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2571 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2572 = add <8 x i64> %2571, splat (i64 1856)
  %2573 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2570, 0
  %2574 = insertvalue { <8 x ptr>, <8 x i64> } %2573, <8 x i64> %2572, 1
  %2575 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2576 = extractvalue { <8 x ptr>, <8 x i64> } %2574, 1
  %2577 = extractelement <8 x ptr> %2575, i32 0
  %2578 = extractelement <8 x i64> %2576, i32 %2125
  %2579 = zext i32 %2125 to i64
  %2580 = mul i64 %2579, 8
  %2581 = sub i64 %2578, %2580
  %2582 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2583 = select i1 %2582, i64 %2581, i64 0
  %private.contiguous.address364 = getelementptr i8, ptr %2577, i64 %2583
  %private.contiguous.preserve365 = load <8 x i64>, ptr %private.contiguous.address364, align 8
  %2584 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 27), <8 x i64> %private.contiguous.preserve365
  store <8 x i64> %2584, ptr %private.contiguous.address364, align 8
  %2585 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2586 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2587 = add <8 x i64> %2586, splat (i64 1920)
  %2588 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2585, 0
  %2589 = insertvalue { <8 x ptr>, <8 x i64> } %2588, <8 x i64> %2587, 1
  %2590 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2591 = extractvalue { <8 x ptr>, <8 x i64> } %2589, 1
  %2592 = extractelement <8 x ptr> %2590, i32 0
  %2593 = extractelement <8 x i64> %2591, i32 %2125
  %2594 = zext i32 %2125 to i64
  %2595 = mul i64 %2594, 8
  %2596 = sub i64 %2593, %2595
  %2597 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2598 = select i1 %2597, i64 %2596, i64 0
  %private.contiguous.address366 = getelementptr i8, ptr %2592, i64 %2598
  %private.contiguous.preserve367 = load <8 x i64>, ptr %private.contiguous.address366, align 8
  %2599 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 28), <8 x i64> %private.contiguous.preserve367
  store <8 x i64> %2599, ptr %private.contiguous.address366, align 8
  %2600 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2601 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2602 = add <8 x i64> %2601, splat (i64 1984)
  %2603 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2600, 0
  %2604 = insertvalue { <8 x ptr>, <8 x i64> } %2603, <8 x i64> %2602, 1
  %2605 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2606 = extractvalue { <8 x ptr>, <8 x i64> } %2604, 1
  %2607 = extractelement <8 x ptr> %2605, i32 0
  %2608 = extractelement <8 x i64> %2606, i32 %2125
  %2609 = zext i32 %2125 to i64
  %2610 = mul i64 %2609, 8
  %2611 = sub i64 %2608, %2610
  %2612 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2613 = select i1 %2612, i64 %2611, i64 0
  %private.contiguous.address368 = getelementptr i8, ptr %2607, i64 %2613
  %private.contiguous.preserve369 = load <8 x i64>, ptr %private.contiguous.address368, align 8
  %2614 = select <8 x i1> %convergence.cascade.result305, <8 x i64> splat (i64 29), <8 x i64> %private.contiguous.preserve369
  store <8 x i64> %2614, ptr %private.contiguous.address368, align 8
  %2615 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill66, align 64
  %2616 = extractvalue { <8 x ptr>, <8 x i64> } %13, 0
  %2617 = extractvalue { <8 x ptr>, <8 x i64> } %2615, 0
  %2618 = select <8 x i1> %convergence.cascade.result305, <8 x ptr> %2616, <8 x ptr> %2617
  %2619 = extractvalue { <8 x ptr>, <8 x i64> } %13, 1
  %2620 = extractvalue { <8 x ptr>, <8 x i64> } %2615, 1
  %2621 = select <8 x i1> %convergence.cascade.result305, <8 x i64> %2619, <8 x i64> %2620
  %2622 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2618, 0
  %2623 = insertvalue { <8 x ptr>, <8 x i64> } %2622, <8 x i64> %2621, 1
  store volatile { <8 x ptr>, <8 x i64> } %2623, ptr %tile_snapshot.spill66, align 64
  %2624 = load <8 x i64>, ptr %.slot67, align 64
  %2625 = select <8 x i1> %convergence.cascade.result305, <8 x i64> zeroinitializer, <8 x i64> %2624
  store <8 x i64> %2625, ptr %.slot67, align 64
  store <8 x i1> %convergence.cascade.result305, ptr %current.mask, align 1
  %2626 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  br i1 %2626, label %schedule.14, label %scheduler.loop

varying.divergent371:                             ; preds = %schedule.14
  %2627 = load i32, ptr %current.token, align 4
  %2628 = icmp ne i32 %2627, 0
  %2629 = sub i32 %2627, 1
  %2630 = select i1 %2628, i32 %2629, i32 0
  %2631 = load i8, ptr %frame.active, align 1
  %2632 = trunc i32 %2630 to i8
  %2633 = shl i8 1, %2632
  %2634 = and i8 %2631, %2633
  %2635 = icmp ne i8 %2634, 0
  %2636 = load <8 x i32>, ptr %frame.static.id, align 32
  %2637 = extractelement <8 x i32> %2636, i32 %2630
  %2638 = icmp eq i32 %2637, 5
  %2639 = and i1 %2635, %2638
  %2640 = and i1 %2628, %2639
  %2641 = xor i1 %2640, true
  %2642 = and i1 true, %2641
  %2643 = xor i8 %2631, -1
  %2644 = icmp ne i8 %2643, 0
  %2645 = xor i1 %2644, true
  %2646 = and i1 %2642, %2645
  br i1 %2646, label %convergence.overflow.trap373, label %convergence.overflow.resume374

varying.coherent372:                              ; preds = %schedule.14
  br i1 %425, label %varying.coherent.true377, label %varying.coherent.false378

convergence.overflow.trap373:                     ; preds = %varying.divergent371
  call void @llvm.trap()
  unreachable

convergence.overflow.resume374:                   ; preds = %varying.divergent371
  %2647 = call i8 @llvm.cttz.i8(i8 %2643, i1 false)
  %2648 = zext i8 %2647 to i32
  %2649 = select i1 %2644, i32 %2648, i32 0
  %2650 = trunc i32 %2649 to i8
  %2651 = shl i8 1, %2650
  %2652 = or i8 %2631, %2651
  %2653 = select i1 %2642, i8 %2652, i8 %2631
  store i8 %2653, ptr %frame.active, align 1
  %2654 = load <8 x i32>, ptr %frame.static.id, align 32
  %2655 = extractelement <8 x i32> %2654, i32 %2649
  %2656 = select i1 %2642, i32 5, i32 %2655
  %2657 = load <8 x i32>, ptr %frame.static.id, align 32
  %2658 = insertelement <8 x i32> %2657, i32 %2656, i32 %2649
  store <8 x i32> %2658, ptr %frame.static.id, align 32
  %2659 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2660 = extractelement <8 x i32> %2659, i32 %2649
  %2661 = select i1 %2642, i32 %2627, i32 %2660
  %2662 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2663 = insertelement <8 x i32> %2662, i32 %2661, i32 %2649
  store <8 x i32> %2663, ptr %frame.parent.token, align 32
  %2664 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2649
  %2665 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2649
  %2666 = load <8 x i1>, ptr %2664, align 1
  %2667 = load <8 x i1>, ptr %2665, align 1
  %2668 = select i1 %2642, <8 x i1> %415, <8 x i1> %2666
  store <8 x i1> %2668, ptr %2664, align 1
  %2669 = select i1 %2642, <8 x i1> zeroinitializer, <8 x i1> %2667
  store <8 x i1> %2669, ptr %2665, align 1
  %2670 = add i32 %2649, 1
  %2671 = select i1 %2640, i32 %2627, i32 %2670
  %2672 = select i1 true, i32 %2671, i32 %2627
  store i32 %2672, ptr %current.token, align 4
  %2673 = load i32, ptr %current.token, align 4
  %2674 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %422)
  %2675 = load i32, ptr %ready.count, align 4
  %2676 = icmp uge i32 %2675, 8
  %2677 = and i1 %2674, %2676
  br i1 %2677, label %ready.overflow.trap375, label %ready.overflow.resume376

ready.overflow.trap375:                           ; preds = %convergence.overflow.resume374
  call void @llvm.trap()
  unreachable

ready.overflow.resume376:                         ; preds = %convergence.overflow.resume374
  %2678 = select i1 %2674, i32 %2675, i32 0
  %2679 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2678
  %2680 = load <8 x i1>, ptr %2679, align 1
  %2681 = select i1 %2674, <8 x i1> %422, <8 x i1> %2680
  store <8 x i1> %2681, ptr %2679, align 1
  %2682 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2678
  %2683 = load i32, ptr %2682, align 4
  %2684 = select i1 %2674, i32 15, i32 %2683
  store i32 %2684, ptr %2682, align 4
  %2685 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2678
  %2686 = load i32, ptr %2685, align 4
  %2687 = select i1 %2674, i32 %2673, i32 %2686
  store i32 %2687, ptr %2685, align 4
  %2688 = add i32 %2675, 1
  %2689 = select i1 %2674, i32 %2688, i32 %2675
  store i32 %2689, ptr %ready.count, align 4
  %2690 = load <8 x i1>, ptr %runnable.mask, align 1
  %2691 = or <8 x i1> %2690, %422
  store <8 x i1> %2691, ptr %runnable.mask, align 1
  store <8 x i1> %424, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true377:                         ; preds = %varying.coherent372
  store <8 x i1> %415, ptr %current.mask, align 1
  %2692 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %415)
  br i1 %2692, label %schedule.15, label %scheduler.loop

varying.coherent.false378:                        ; preds = %varying.coherent372
  store <8 x i1> %415, ptr %current.mask, align 1
  %2693 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %415)
  br i1 %2693, label %schedule.18, label %scheduler.loop

varying.divergent385:                             ; preds = %schedule.15
  %2694 = load i32, ptr %current.token, align 4
  %2695 = icmp ne i32 %2694, 0
  %2696 = sub i32 %2694, 1
  %2697 = select i1 %2695, i32 %2696, i32 0
  %2698 = load i8, ptr %frame.active, align 1
  %2699 = trunc i32 %2697 to i8
  %2700 = shl i8 1, %2699
  %2701 = and i8 %2698, %2700
  %2702 = icmp ne i8 %2701, 0
  %2703 = load <8 x i32>, ptr %frame.static.id, align 32
  %2704 = extractelement <8 x i32> %2703, i32 %2697
  %2705 = icmp eq i32 %2704, 6
  %2706 = and i1 %2702, %2705
  %2707 = and i1 %2695, %2706
  %2708 = xor i1 %2707, true
  %2709 = and i1 true, %2708
  %2710 = xor i8 %2698, -1
  %2711 = icmp ne i8 %2710, 0
  %2712 = xor i1 %2711, true
  %2713 = and i1 %2709, %2712
  br i1 %2713, label %convergence.overflow.trap387, label %convergence.overflow.resume388

varying.coherent386:                              ; preds = %schedule.15
  br i1 %467, label %varying.coherent.true391, label %varying.coherent.false392

convergence.overflow.trap387:                     ; preds = %varying.divergent385
  call void @llvm.trap()
  unreachable

convergence.overflow.resume388:                   ; preds = %varying.divergent385
  %2714 = call i8 @llvm.cttz.i8(i8 %2710, i1 false)
  %2715 = zext i8 %2714 to i32
  %2716 = select i1 %2711, i32 %2715, i32 0
  %2717 = trunc i32 %2716 to i8
  %2718 = shl i8 1, %2717
  %2719 = or i8 %2698, %2718
  %2720 = select i1 %2709, i8 %2719, i8 %2698
  store i8 %2720, ptr %frame.active, align 1
  %2721 = load <8 x i32>, ptr %frame.static.id, align 32
  %2722 = extractelement <8 x i32> %2721, i32 %2716
  %2723 = select i1 %2709, i32 6, i32 %2722
  %2724 = load <8 x i32>, ptr %frame.static.id, align 32
  %2725 = insertelement <8 x i32> %2724, i32 %2723, i32 %2716
  store <8 x i32> %2725, ptr %frame.static.id, align 32
  %2726 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2727 = extractelement <8 x i32> %2726, i32 %2716
  %2728 = select i1 %2709, i32 %2694, i32 %2727
  %2729 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2730 = insertelement <8 x i32> %2729, i32 %2728, i32 %2716
  store <8 x i32> %2730, ptr %frame.parent.token, align 32
  %2731 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2716
  %2732 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2716
  %2733 = load <8 x i1>, ptr %2731, align 1
  %2734 = load <8 x i1>, ptr %2732, align 1
  %2735 = select i1 %2709, <8 x i1> %428, <8 x i1> %2733
  store <8 x i1> %2735, ptr %2731, align 1
  %2736 = select i1 %2709, <8 x i1> zeroinitializer, <8 x i1> %2734
  store <8 x i1> %2736, ptr %2732, align 1
  %2737 = add i32 %2716, 1
  %2738 = select i1 %2707, i32 %2694, i32 %2737
  %2739 = select i1 true, i32 %2738, i32 %2694
  store i32 %2739, ptr %current.token, align 4
  %2740 = load <8 x float>, ptr %.slot70, align 32
  %2741 = select <8 x i1> %466, <8 x float> zeroinitializer, <8 x float> %2740
  store <8 x float> %2741, ptr %.slot70, align 32
  %2742 = load i32, ptr %current.token, align 4
  %2743 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %464)
  %2744 = load i32, ptr %ready.count, align 4
  %2745 = icmp uge i32 %2744, 8
  %2746 = and i1 %2743, %2745
  br i1 %2746, label %ready.overflow.trap389, label %ready.overflow.resume390

ready.overflow.trap389:                           ; preds = %convergence.overflow.resume388
  call void @llvm.trap()
  unreachable

ready.overflow.resume390:                         ; preds = %convergence.overflow.resume388
  %2747 = select i1 %2743, i32 %2744, i32 0
  %2748 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2747
  %2749 = load <8 x i1>, ptr %2748, align 1
  %2750 = select i1 %2743, <8 x i1> %464, <8 x i1> %2749
  store <8 x i1> %2750, ptr %2748, align 1
  %2751 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2747
  %2752 = load i32, ptr %2751, align 4
  %2753 = select i1 %2743, i32 16, i32 %2752
  store i32 %2753, ptr %2751, align 4
  %2754 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2747
  %2755 = load i32, ptr %2754, align 4
  %2756 = select i1 %2743, i32 %2742, i32 %2755
  store i32 %2756, ptr %2754, align 4
  %2757 = add i32 %2744, 1
  %2758 = select i1 %2743, i32 %2757, i32 %2744
  store i32 %2758, ptr %ready.count, align 4
  %2759 = load <8 x i1>, ptr %runnable.mask, align 1
  %2760 = or <8 x i1> %2759, %464
  store <8 x i1> %2760, ptr %runnable.mask, align 1
  store <8 x i1> %466, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true391:                         ; preds = %varying.coherent386
  store <8 x i1> %428, ptr %current.mask, align 1
  %2761 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %428)
  br i1 %2761, label %schedule.16, label %scheduler.loop

varying.coherent.false392:                        ; preds = %varying.coherent386
  %2762 = load <8 x float>, ptr %.slot70, align 32
  %2763 = select <8 x i1> %428, <8 x float> zeroinitializer, <8 x float> %2762
  store <8 x float> %2763, ptr %.slot70, align 32
  store <8 x i1> %428, ptr %current.mask, align 1
  %2764 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %428)
  br i1 %2764, label %schedule.17, label %scheduler.loop

convergence.cascade395:                           ; preds = %convergence.cascade395, %schedule.17
  %convergence.cascade.flow399 = phi <8 x i1> [ %489, %schedule.17 ], [ %2807, %convergence.cascade395 ]
  %convergence.cascade.depth400 = phi i32 [ 0, %schedule.17 ], [ %2808, %convergence.cascade395 ]
  %2765 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow399)
  %2766 = load i32, ptr %current.token, align 4
  %2767 = icmp ne i32 %2766, 0
  %2768 = and i1 %2765, %2767
  %2769 = sub i32 %2766, 1
  %2770 = select i1 %2768, i32 %2769, i32 0
  %2771 = load i8, ptr %frame.active, align 1
  %2772 = trunc i32 %2770 to i8
  %2773 = shl i8 1, %2772
  %2774 = and i8 %2771, %2773
  %2775 = icmp ne i8 %2774, 0
  %2776 = load <8 x i32>, ptr %frame.static.id, align 32
  %2777 = extractelement <8 x i32> %2776, i32 %2770
  %convergence.target.pointer401 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %2777
  %convergence.dynamic.target402 = load i32, ptr %convergence.target.pointer401, align 4
  %2778 = icmp eq i32 %convergence.dynamic.target402, 17
  %2779 = and i1 %2775, %2778
  %2780 = and i1 %2768, %2779
  %2781 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2770
  %2782 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2770
  %2783 = load <8 x i1>, ptr %2781, align 1
  %2784 = load <8 x i1>, ptr %2782, align 1
  %2785 = or <8 x i1> %2784, %convergence.cascade.flow399
  %2786 = load <8 x i1>, ptr %live.mask, align 1
  %2787 = and <8 x i1> %2783, %2786
  %2788 = icmp eq <8 x i1> %2785, %2787
  %2789 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2788)
  %2790 = and i1 %2780, %2789
  %2791 = select i1 %2790, <8 x i1> zeroinitializer, <8 x i1> %2785
  %2792 = select i1 %2780, <8 x i1> %2791, <8 x i1> %2784
  store <8 x i1> %2792, ptr %2782, align 1
  %2793 = select i1 %2790, <8 x i1> zeroinitializer, <8 x i1> %2783
  store <8 x i1> %2793, ptr %2781, align 1
  %2794 = trunc i32 %2770 to i8
  %2795 = shl i8 1, %2794
  %2796 = xor i8 %2795, -1
  %2797 = and i8 %2771, %2796
  %2798 = select i1 %2790, i8 %2797, i8 %2771
  store i8 %2798, ptr %frame.active, align 1
  %.splatinsert403 = insertelement <8 x i1> poison, i1 %2780, i64 0
  %.splat404 = shufflevector <8 x i1> %.splatinsert403, <8 x i1> poison, <8 x i32> zeroinitializer
  %2799 = and <8 x i1> %convergence.cascade.flow399, %.splat404
  %2800 = load <8 x i1>, ptr %runnable.mask, align 1
  %2801 = xor <8 x i1> %2799, splat (i1 true)
  %2802 = and <8 x i1> %2800, %2801
  store <8 x i1> %2802, ptr %runnable.mask, align 1
  %.splatinsert405 = insertelement <8 x i1> poison, i1 %2790, i64 0
  %.splat406 = shufflevector <8 x i1> %.splatinsert405, <8 x i1> poison, <8 x i32> zeroinitializer
  %2803 = select <8 x i1> %.splat406, <8 x i1> %2785, <8 x i1> zeroinitializer
  %2804 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2805 = extractelement <8 x i32> %2804, i32 %2770
  %2806 = select i1 %2790, i32 %2805, i32 %2766
  store i32 %2806, ptr %current.token, align 4
  %.splatinsert407 = insertelement <8 x i1> poison, i1 %2780, i64 0
  %.splat408 = shufflevector <8 x i1> %.splatinsert407, <8 x i1> poison, <8 x i32> zeroinitializer
  %2807 = select <8 x i1> %.splat408, <8 x i1> %2803, <8 x i1> %convergence.cascade.flow399
  %2808 = add i32 %convergence.cascade.depth400, 1
  %2809 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2807)
  %2810 = icmp ult i32 %2808, 8
  %2811 = and i1 %2809, %2810
  %2812 = and i1 %2780, %2811
  %convergence.parent.token409 = load i32, ptr %current.token, align 4
  %convergence.parent.present410 = icmp ne i32 %convergence.parent.token409, 0
  %2813 = and i1 %2812, %convergence.parent.present410
  br i1 %2813, label %convergence.cascade395, label %convergence.cascade.exit396

convergence.cascade.exit396:                      ; preds = %convergence.cascade395, %schedule.17
  %convergence.cascade.result411 = phi <8 x i1> [ %489, %schedule.17 ], [ %2807, %convergence.cascade395 ]
  %2814 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result411)
  br i1 %2814, label %convergence.target.17.ready, label %scheduler.loop

convergence.target.17.ready:                      ; preds = %convergence.cascade.exit396
  %2815 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result411)
  %2816 = bitcast <8 x i1> %convergence.cascade.result411 to i8
  %2817 = call i8 @llvm.cttz.i8(i8 %2816, i1 false)
  %2818 = zext i8 %2817 to i32
  %2819 = select i1 %2815, i32 %2818, i32 0
  %.spill.load412 = load float, ptr %.spill49, align 4
  %.splatinsert413 = insertelement <8 x float> poison, float %.spill.load412, i64 0
  %.splat414 = shufflevector <8 x float> %.splatinsert413, <8 x float> poison, <8 x i32> zeroinitializer
  %.state415 = load <8 x float>, ptr %.slot70, align 32
  %.spill.load416 = load volatile <8 x i1>, ptr %.spill68, align 1
  %2820 = select <8 x i1> %.spill.load416, <8 x float> %.state415, <8 x float> %.splat414
  %tile_snapshot.spill.load417 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill66, align 64
  %2821 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load417, 0
  %2822 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load417, 1
  %.state418 = load <8 x i64>, ptr %.slot67, align 64
  %2823 = mul <8 x i64> %.state418, splat (i64 32)
  %2824 = add <8 x i64> %2822, %2823
  %2825 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2821, 0
  %2826 = insertvalue { <8 x ptr>, <8 x i64> } %2825, <8 x i64> %2824, 1
  %2827 = extractvalue { <8 x ptr>, <8 x i64> } %2826, 0
  %2828 = extractvalue { <8 x ptr>, <8 x i64> } %2826, 1
  %2829 = getelementptr i8, <8 x ptr> %2827, <8 x i64> %2828
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %2820, <8 x ptr> %2829, i32 1, <8 x i1> %convergence.cascade.result411)
  %.state419 = load <8 x i64>, ptr %.slot67, align 64
  %2830 = add <8 x i64> %.state419, splat (i64 1)
  %2831 = load <8 x i64>, ptr %.slot67, align 64
  %2832 = select <8 x i1> %convergence.cascade.result411, <8 x i64> %2830, <8 x i64> %2831
  store <8 x i64> %2832, ptr %.slot67, align 64
  store <8 x i1> %convergence.cascade.result411, ptr %current.mask, align 1
  %2833 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result411)
  br i1 %2833, label %schedule.14, label %scheduler.loop

convergence.cascade420:                           ; preds = %convergence.cascade420, %schedule.18
  %convergence.cascade.flow424 = phi <8 x i1> [ %490, %schedule.18 ], [ %2876, %convergence.cascade420 ]
  %convergence.cascade.depth425 = phi i32 [ 0, %schedule.18 ], [ %2877, %convergence.cascade420 ]
  %2834 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow424)
  %2835 = load i32, ptr %current.token, align 4
  %2836 = icmp ne i32 %2835, 0
  %2837 = and i1 %2834, %2836
  %2838 = sub i32 %2835, 1
  %2839 = select i1 %2837, i32 %2838, i32 0
  %2840 = load i8, ptr %frame.active, align 1
  %2841 = trunc i32 %2839 to i8
  %2842 = shl i8 1, %2841
  %2843 = and i8 %2840, %2842
  %2844 = icmp ne i8 %2843, 0
  %2845 = load <8 x i32>, ptr %frame.static.id, align 32
  %2846 = extractelement <8 x i32> %2845, i32 %2839
  %convergence.target.pointer426 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %2846
  %convergence.dynamic.target427 = load i32, ptr %convergence.target.pointer426, align 4
  %2847 = icmp eq i32 %convergence.dynamic.target427, 18
  %2848 = and i1 %2844, %2847
  %2849 = and i1 %2837, %2848
  %2850 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2839
  %2851 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2839
  %2852 = load <8 x i1>, ptr %2850, align 1
  %2853 = load <8 x i1>, ptr %2851, align 1
  %2854 = or <8 x i1> %2853, %convergence.cascade.flow424
  %2855 = load <8 x i1>, ptr %live.mask, align 1
  %2856 = and <8 x i1> %2852, %2855
  %2857 = icmp eq <8 x i1> %2854, %2856
  %2858 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2857)
  %2859 = and i1 %2849, %2858
  %2860 = select i1 %2859, <8 x i1> zeroinitializer, <8 x i1> %2854
  %2861 = select i1 %2849, <8 x i1> %2860, <8 x i1> %2853
  store <8 x i1> %2861, ptr %2851, align 1
  %2862 = select i1 %2859, <8 x i1> zeroinitializer, <8 x i1> %2852
  store <8 x i1> %2862, ptr %2850, align 1
  %2863 = trunc i32 %2839 to i8
  %2864 = shl i8 1, %2863
  %2865 = xor i8 %2864, -1
  %2866 = and i8 %2840, %2865
  %2867 = select i1 %2859, i8 %2866, i8 %2840
  store i8 %2867, ptr %frame.active, align 1
  %.splatinsert428 = insertelement <8 x i1> poison, i1 %2849, i64 0
  %.splat429 = shufflevector <8 x i1> %.splatinsert428, <8 x i1> poison, <8 x i32> zeroinitializer
  %2868 = and <8 x i1> %convergence.cascade.flow424, %.splat429
  %2869 = load <8 x i1>, ptr %runnable.mask, align 1
  %2870 = xor <8 x i1> %2868, splat (i1 true)
  %2871 = and <8 x i1> %2869, %2870
  store <8 x i1> %2871, ptr %runnable.mask, align 1
  %.splatinsert430 = insertelement <8 x i1> poison, i1 %2859, i64 0
  %.splat431 = shufflevector <8 x i1> %.splatinsert430, <8 x i1> poison, <8 x i32> zeroinitializer
  %2872 = select <8 x i1> %.splat431, <8 x i1> %2854, <8 x i1> zeroinitializer
  %2873 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2874 = extractelement <8 x i32> %2873, i32 %2839
  %2875 = select i1 %2859, i32 %2874, i32 %2835
  store i32 %2875, ptr %current.token, align 4
  %.splatinsert432 = insertelement <8 x i1> poison, i1 %2849, i64 0
  %.splat433 = shufflevector <8 x i1> %.splatinsert432, <8 x i1> poison, <8 x i32> zeroinitializer
  %2876 = select <8 x i1> %.splat433, <8 x i1> %2872, <8 x i1> %convergence.cascade.flow424
  %2877 = add i32 %convergence.cascade.depth425, 1
  %2878 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2876)
  %2879 = icmp ult i32 %2877, 8
  %2880 = and i1 %2878, %2879
  %2881 = and i1 %2849, %2880
  %convergence.parent.token434 = load i32, ptr %current.token, align 4
  %convergence.parent.present435 = icmp ne i32 %convergence.parent.token434, 0
  %2882 = and i1 %2881, %convergence.parent.present435
  br i1 %2882, label %convergence.cascade420, label %convergence.cascade.exit421

convergence.cascade.exit421:                      ; preds = %convergence.cascade420, %schedule.18
  %convergence.cascade.result436 = phi <8 x i1> [ %490, %schedule.18 ], [ %2876, %convergence.cascade420 ]
  %2883 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result436)
  br i1 %2883, label %convergence.target.18.ready, label %scheduler.loop

convergence.target.18.ready:                      ; preds = %convergence.cascade.exit421
  %2884 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result436)
  %2885 = bitcast <8 x i1> %convergence.cascade.result436 to i8
  %2886 = call i8 @llvm.cttz.i8(i8 %2885, i1 false)
  %2887 = zext i8 %2886 to i32
  %2888 = select i1 %2884, i32 %2887, i32 0
  %2889 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill71, align 64
  %2890 = extractvalue { <8 x ptr>, <8 x i64> } %15, 0
  %2891 = extractvalue { <8 x ptr>, <8 x i64> } %2889, 0
  %2892 = select <8 x i1> %convergence.cascade.result436, <8 x ptr> %2890, <8 x ptr> %2891
  %2893 = extractvalue { <8 x ptr>, <8 x i64> } %15, 1
  %2894 = extractvalue { <8 x ptr>, <8 x i64> } %2889, 1
  %2895 = select <8 x i1> %convergence.cascade.result436, <8 x i64> %2893, <8 x i64> %2894
  %2896 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2892, 0
  %2897 = insertvalue { <8 x ptr>, <8 x i64> } %2896, <8 x i64> %2895, 1
  store volatile { <8 x ptr>, <8 x i64> } %2897, ptr %tile_snapshot.spill71, align 64
  %2898 = load <8 x i64>, ptr %.slot72, align 64
  %2899 = select <8 x i1> %convergence.cascade.result436, <8 x i64> zeroinitializer, <8 x i64> %2898
  store <8 x i64> %2899, ptr %.slot72, align 64
  store <8 x i1> %convergence.cascade.result436, ptr %current.mask, align 1
  %2900 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result436)
  br i1 %2900, label %schedule.19, label %scheduler.loop

varying.divergent438:                             ; preds = %schedule.19
  %2901 = load i32, ptr %current.token, align 4
  %2902 = icmp ne i32 %2901, 0
  %2903 = sub i32 %2901, 1
  %2904 = select i1 %2902, i32 %2903, i32 0
  %2905 = load i8, ptr %frame.active, align 1
  %2906 = trunc i32 %2904 to i8
  %2907 = shl i8 1, %2906
  %2908 = and i8 %2905, %2907
  %2909 = icmp ne i8 %2908, 0
  %2910 = load <8 x i32>, ptr %frame.static.id, align 32
  %2911 = extractelement <8 x i32> %2910, i32 %2904
  %2912 = icmp eq i32 %2911, 7
  %2913 = and i1 %2909, %2912
  %2914 = and i1 %2902, %2913
  %2915 = xor i1 %2914, true
  %2916 = and i1 true, %2915
  %2917 = xor i8 %2905, -1
  %2918 = icmp ne i8 %2917, 0
  %2919 = xor i1 %2918, true
  %2920 = and i1 %2916, %2919
  br i1 %2920, label %convergence.overflow.trap440, label %convergence.overflow.resume441

varying.coherent439:                              ; preds = %schedule.19
  br i1 %501, label %varying.coherent.true444, label %varying.coherent.false445

convergence.overflow.trap440:                     ; preds = %varying.divergent438
  call void @llvm.trap()
  unreachable

convergence.overflow.resume441:                   ; preds = %varying.divergent438
  %2921 = call i8 @llvm.cttz.i8(i8 %2917, i1 false)
  %2922 = zext i8 %2921 to i32
  %2923 = select i1 %2918, i32 %2922, i32 0
  %2924 = trunc i32 %2923 to i8
  %2925 = shl i8 1, %2924
  %2926 = or i8 %2905, %2925
  %2927 = select i1 %2916, i8 %2926, i8 %2905
  store i8 %2927, ptr %frame.active, align 1
  %2928 = load <8 x i32>, ptr %frame.static.id, align 32
  %2929 = extractelement <8 x i32> %2928, i32 %2923
  %2930 = select i1 %2916, i32 7, i32 %2929
  %2931 = load <8 x i32>, ptr %frame.static.id, align 32
  %2932 = insertelement <8 x i32> %2931, i32 %2930, i32 %2923
  store <8 x i32> %2932, ptr %frame.static.id, align 32
  %2933 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2934 = extractelement <8 x i32> %2933, i32 %2923
  %2935 = select i1 %2916, i32 %2901, i32 %2934
  %2936 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2937 = insertelement <8 x i32> %2936, i32 %2935, i32 %2923
  store <8 x i32> %2937, ptr %frame.parent.token, align 32
  %2938 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2923
  %2939 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2923
  %2940 = load <8 x i1>, ptr %2938, align 1
  %2941 = load <8 x i1>, ptr %2939, align 1
  %2942 = select i1 %2916, <8 x i1> %491, <8 x i1> %2940
  store <8 x i1> %2942, ptr %2938, align 1
  %2943 = select i1 %2916, <8 x i1> zeroinitializer, <8 x i1> %2941
  store <8 x i1> %2943, ptr %2939, align 1
  %2944 = add i32 %2923, 1
  %2945 = select i1 %2914, i32 %2901, i32 %2944
  %2946 = select i1 true, i32 %2945, i32 %2901
  store i32 %2946, ptr %current.token, align 4
  %2947 = load i32, ptr %current.token, align 4
  %2948 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %498)
  %2949 = load i32, ptr %ready.count, align 4
  %2950 = icmp uge i32 %2949, 8
  %2951 = and i1 %2948, %2950
  br i1 %2951, label %ready.overflow.trap442, label %ready.overflow.resume443

ready.overflow.trap442:                           ; preds = %convergence.overflow.resume441
  call void @llvm.trap()
  unreachable

ready.overflow.resume443:                         ; preds = %convergence.overflow.resume441
  %2952 = select i1 %2948, i32 %2949, i32 0
  %2953 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2952
  %2954 = load <8 x i1>, ptr %2953, align 1
  %2955 = select i1 %2948, <8 x i1> %498, <8 x i1> %2954
  store <8 x i1> %2955, ptr %2953, align 1
  %2956 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2952
  %2957 = load i32, ptr %2956, align 4
  %2958 = select i1 %2948, i32 20, i32 %2957
  store i32 %2958, ptr %2956, align 4
  %2959 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2952
  %2960 = load i32, ptr %2959, align 4
  %2961 = select i1 %2948, i32 %2947, i32 %2960
  store i32 %2961, ptr %2959, align 4
  %2962 = add i32 %2949, 1
  %2963 = select i1 %2948, i32 %2962, i32 %2949
  store i32 %2963, ptr %ready.count, align 4
  %2964 = load <8 x i1>, ptr %runnable.mask, align 1
  %2965 = or <8 x i1> %2964, %498
  store <8 x i1> %2965, ptr %runnable.mask, align 1
  store <8 x i1> %500, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true444:                         ; preds = %varying.coherent439
  store <8 x i1> %491, ptr %current.mask, align 1
  %2966 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %491)
  br i1 %2966, label %schedule.20, label %scheduler.loop

varying.coherent.false445:                        ; preds = %varying.coherent439
  store <8 x i1> %491, ptr %current.mask, align 1
  %2967 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %491)
  br i1 %2967, label %schedule.21, label %scheduler.loop

convergence.cascade453:                           ; preds = %convergence.cascade453, %schedule.21
  %convergence.cascade.flow457 = phi <8 x i1> [ %553, %schedule.21 ], [ %3010, %convergence.cascade453 ]
  %convergence.cascade.depth458 = phi i32 [ 0, %schedule.21 ], [ %3011, %convergence.cascade453 ]
  %2968 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow457)
  %2969 = load i32, ptr %current.token, align 4
  %2970 = icmp ne i32 %2969, 0
  %2971 = and i1 %2968, %2970
  %2972 = sub i32 %2969, 1
  %2973 = select i1 %2971, i32 %2972, i32 0
  %2974 = load i8, ptr %frame.active, align 1
  %2975 = trunc i32 %2973 to i8
  %2976 = shl i8 1, %2975
  %2977 = and i8 %2974, %2976
  %2978 = icmp ne i8 %2977, 0
  %2979 = load <8 x i32>, ptr %frame.static.id, align 32
  %2980 = extractelement <8 x i32> %2979, i32 %2973
  %convergence.target.pointer459 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %2980
  %convergence.dynamic.target460 = load i32, ptr %convergence.target.pointer459, align 4
  %2981 = icmp eq i32 %convergence.dynamic.target460, 21
  %2982 = and i1 %2978, %2981
  %2983 = and i1 %2971, %2982
  %2984 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2973
  %2985 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2973
  %2986 = load <8 x i1>, ptr %2984, align 1
  %2987 = load <8 x i1>, ptr %2985, align 1
  %2988 = or <8 x i1> %2987, %convergence.cascade.flow457
  %2989 = load <8 x i1>, ptr %live.mask, align 1
  %2990 = and <8 x i1> %2986, %2989
  %2991 = icmp eq <8 x i1> %2988, %2990
  %2992 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2991)
  %2993 = and i1 %2983, %2992
  %2994 = select i1 %2993, <8 x i1> zeroinitializer, <8 x i1> %2988
  %2995 = select i1 %2983, <8 x i1> %2994, <8 x i1> %2987
  store <8 x i1> %2995, ptr %2985, align 1
  %2996 = select i1 %2993, <8 x i1> zeroinitializer, <8 x i1> %2986
  store <8 x i1> %2996, ptr %2984, align 1
  %2997 = trunc i32 %2973 to i8
  %2998 = shl i8 1, %2997
  %2999 = xor i8 %2998, -1
  %3000 = and i8 %2974, %2999
  %3001 = select i1 %2993, i8 %3000, i8 %2974
  store i8 %3001, ptr %frame.active, align 1
  %.splatinsert461 = insertelement <8 x i1> poison, i1 %2983, i64 0
  %.splat462 = shufflevector <8 x i1> %.splatinsert461, <8 x i1> poison, <8 x i32> zeroinitializer
  %3002 = and <8 x i1> %convergence.cascade.flow457, %.splat462
  %3003 = load <8 x i1>, ptr %runnable.mask, align 1
  %3004 = xor <8 x i1> %3002, splat (i1 true)
  %3005 = and <8 x i1> %3003, %3004
  store <8 x i1> %3005, ptr %runnable.mask, align 1
  %.splatinsert463 = insertelement <8 x i1> poison, i1 %2993, i64 0
  %.splat464 = shufflevector <8 x i1> %.splatinsert463, <8 x i1> poison, <8 x i32> zeroinitializer
  %3006 = select <8 x i1> %.splat464, <8 x i1> %2988, <8 x i1> zeroinitializer
  %3007 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3008 = extractelement <8 x i32> %3007, i32 %2973
  %3009 = select i1 %2993, i32 %3008, i32 %2969
  store i32 %3009, ptr %current.token, align 4
  %.splatinsert465 = insertelement <8 x i1> poison, i1 %2983, i64 0
  %.splat466 = shufflevector <8 x i1> %.splatinsert465, <8 x i1> poison, <8 x i32> zeroinitializer
  %3010 = select <8 x i1> %.splat466, <8 x i1> %3006, <8 x i1> %convergence.cascade.flow457
  %3011 = add i32 %convergence.cascade.depth458, 1
  %3012 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3010)
  %3013 = icmp ult i32 %3011, 8
  %3014 = and i1 %3012, %3013
  %3015 = and i1 %2983, %3014
  %convergence.parent.token467 = load i32, ptr %current.token, align 4
  %convergence.parent.present468 = icmp ne i32 %convergence.parent.token467, 0
  %3016 = and i1 %3015, %convergence.parent.present468
  br i1 %3016, label %convergence.cascade453, label %convergence.cascade.exit454

convergence.cascade.exit454:                      ; preds = %convergence.cascade453, %schedule.21
  %convergence.cascade.result469 = phi <8 x i1> [ %553, %schedule.21 ], [ %3010, %convergence.cascade453 ]
  %3017 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  br i1 %3017, label %convergence.target.21.ready, label %scheduler.loop

convergence.target.21.ready:                      ; preds = %convergence.cascade.exit454
  %3018 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3019 = bitcast <8 x i1> %convergence.cascade.result469 to i8
  %3020 = call i8 @llvm.cttz.i8(i8 %3019, i1 false)
  %3021 = zext i8 %3020 to i32
  %3022 = select i1 %3018, i32 %3021, i32 0
  %3023 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill73, align 64
  %3024 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3025 = extractvalue { <8 x ptr>, <8 x i64> } %3023, 0
  %3026 = select <8 x i1> %convergence.cascade.result469, <8 x ptr> %3024, <8 x ptr> %3025
  %3027 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3028 = extractvalue { <8 x ptr>, <8 x i64> } %3023, 1
  %3029 = select <8 x i1> %convergence.cascade.result469, <8 x i64> %3027, <8 x i64> %3028
  %3030 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3026, 0
  %3031 = insertvalue { <8 x ptr>, <8 x i64> } %3030, <8 x i64> %3029, 1
  store volatile { <8 x ptr>, <8 x i64> } %3031, ptr %tile_snapshot.spill73, align 64
  %3032 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3033 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3034 = add <8 x i64> %3033, zeroinitializer
  %3035 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3032, 0
  %3036 = insertvalue { <8 x ptr>, <8 x i64> } %3035, <8 x i64> %3034, 1
  %3037 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3038 = extractvalue { <8 x ptr>, <8 x i64> } %3036, 1
  %3039 = extractelement <8 x ptr> %3037, i32 0
  %3040 = extractelement <8 x i64> %3038, i32 %3022
  %3041 = zext i32 %3022 to i64
  %3042 = mul i64 %3041, 8
  %3043 = sub i64 %3040, %3042
  %3044 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3045 = select i1 %3044, i64 %3043, i64 0
  %private.contiguous.address470 = getelementptr i8, ptr %3039, i64 %3045
  %private.contiguous.preserve471 = load <8 x i64>, ptr %private.contiguous.address470, align 8
  %3046 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 -4), <8 x i64> %private.contiguous.preserve471
  store <8 x i64> %3046, ptr %private.contiguous.address470, align 8
  %3047 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3048 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3049 = add <8 x i64> %3048, splat (i64 64)
  %3050 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3047, 0
  %3051 = insertvalue { <8 x ptr>, <8 x i64> } %3050, <8 x i64> %3049, 1
  %3052 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3053 = extractvalue { <8 x ptr>, <8 x i64> } %3051, 1
  %3054 = extractelement <8 x ptr> %3052, i32 0
  %3055 = extractelement <8 x i64> %3053, i32 %3022
  %3056 = zext i32 %3022 to i64
  %3057 = mul i64 %3056, 8
  %3058 = sub i64 %3055, %3057
  %3059 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3060 = select i1 %3059, i64 %3058, i64 0
  %private.contiguous.address472 = getelementptr i8, ptr %3054, i64 %3060
  %private.contiguous.preserve473 = load <8 x i64>, ptr %private.contiguous.address472, align 8
  %3061 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 -3), <8 x i64> %private.contiguous.preserve473
  store <8 x i64> %3061, ptr %private.contiguous.address472, align 8
  %3062 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3063 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3064 = add <8 x i64> %3063, splat (i64 128)
  %3065 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3062, 0
  %3066 = insertvalue { <8 x ptr>, <8 x i64> } %3065, <8 x i64> %3064, 1
  %3067 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3068 = extractvalue { <8 x ptr>, <8 x i64> } %3066, 1
  %3069 = extractelement <8 x ptr> %3067, i32 0
  %3070 = extractelement <8 x i64> %3068, i32 %3022
  %3071 = zext i32 %3022 to i64
  %3072 = mul i64 %3071, 8
  %3073 = sub i64 %3070, %3072
  %3074 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3075 = select i1 %3074, i64 %3073, i64 0
  %private.contiguous.address474 = getelementptr i8, ptr %3069, i64 %3075
  %private.contiguous.preserve475 = load <8 x i64>, ptr %private.contiguous.address474, align 8
  %3076 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 -2), <8 x i64> %private.contiguous.preserve475
  store <8 x i64> %3076, ptr %private.contiguous.address474, align 8
  %3077 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3078 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3079 = add <8 x i64> %3078, splat (i64 192)
  %3080 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3077, 0
  %3081 = insertvalue { <8 x ptr>, <8 x i64> } %3080, <8 x i64> %3079, 1
  %3082 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3083 = extractvalue { <8 x ptr>, <8 x i64> } %3081, 1
  %3084 = extractelement <8 x ptr> %3082, i32 0
  %3085 = extractelement <8 x i64> %3083, i32 %3022
  %3086 = zext i32 %3022 to i64
  %3087 = mul i64 %3086, 8
  %3088 = sub i64 %3085, %3087
  %3089 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3090 = select i1 %3089, i64 %3088, i64 0
  %private.contiguous.address476 = getelementptr i8, ptr %3084, i64 %3090
  %private.contiguous.preserve477 = load <8 x i64>, ptr %private.contiguous.address476, align 8
  %3091 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 -1), <8 x i64> %private.contiguous.preserve477
  store <8 x i64> %3091, ptr %private.contiguous.address476, align 8
  %3092 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3093 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3094 = add <8 x i64> %3093, splat (i64 256)
  %3095 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3092, 0
  %3096 = insertvalue { <8 x ptr>, <8 x i64> } %3095, <8 x i64> %3094, 1
  %3097 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3098 = extractvalue { <8 x ptr>, <8 x i64> } %3096, 1
  %3099 = extractelement <8 x ptr> %3097, i32 0
  %3100 = extractelement <8 x i64> %3098, i32 %3022
  %3101 = zext i32 %3022 to i64
  %3102 = mul i64 %3101, 8
  %3103 = sub i64 %3100, %3102
  %3104 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3105 = select i1 %3104, i64 %3103, i64 0
  %private.contiguous.address478 = getelementptr i8, ptr %3099, i64 %3105
  %private.contiguous.preserve479 = load <8 x i64>, ptr %private.contiguous.address478, align 8
  %3106 = select <8 x i1> %convergence.cascade.result469, <8 x i64> zeroinitializer, <8 x i64> %private.contiguous.preserve479
  store <8 x i64> %3106, ptr %private.contiguous.address478, align 8
  %3107 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3108 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3109 = add <8 x i64> %3108, splat (i64 320)
  %3110 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3107, 0
  %3111 = insertvalue { <8 x ptr>, <8 x i64> } %3110, <8 x i64> %3109, 1
  %3112 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3113 = extractvalue { <8 x ptr>, <8 x i64> } %3111, 1
  %3114 = extractelement <8 x ptr> %3112, i32 0
  %3115 = extractelement <8 x i64> %3113, i32 %3022
  %3116 = zext i32 %3022 to i64
  %3117 = mul i64 %3116, 8
  %3118 = sub i64 %3115, %3117
  %3119 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3120 = select i1 %3119, i64 %3118, i64 0
  %private.contiguous.address480 = getelementptr i8, ptr %3114, i64 %3120
  %private.contiguous.preserve481 = load <8 x i64>, ptr %private.contiguous.address480, align 8
  %3121 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 1), <8 x i64> %private.contiguous.preserve481
  store <8 x i64> %3121, ptr %private.contiguous.address480, align 8
  %3122 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3123 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3124 = add <8 x i64> %3123, splat (i64 384)
  %3125 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3122, 0
  %3126 = insertvalue { <8 x ptr>, <8 x i64> } %3125, <8 x i64> %3124, 1
  %3127 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3128 = extractvalue { <8 x ptr>, <8 x i64> } %3126, 1
  %3129 = extractelement <8 x ptr> %3127, i32 0
  %3130 = extractelement <8 x i64> %3128, i32 %3022
  %3131 = zext i32 %3022 to i64
  %3132 = mul i64 %3131, 8
  %3133 = sub i64 %3130, %3132
  %3134 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3135 = select i1 %3134, i64 %3133, i64 0
  %private.contiguous.address482 = getelementptr i8, ptr %3129, i64 %3135
  %private.contiguous.preserve483 = load <8 x i64>, ptr %private.contiguous.address482, align 8
  %3136 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 2), <8 x i64> %private.contiguous.preserve483
  store <8 x i64> %3136, ptr %private.contiguous.address482, align 8
  %3137 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3138 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3139 = add <8 x i64> %3138, splat (i64 448)
  %3140 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3137, 0
  %3141 = insertvalue { <8 x ptr>, <8 x i64> } %3140, <8 x i64> %3139, 1
  %3142 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3143 = extractvalue { <8 x ptr>, <8 x i64> } %3141, 1
  %3144 = extractelement <8 x ptr> %3142, i32 0
  %3145 = extractelement <8 x i64> %3143, i32 %3022
  %3146 = zext i32 %3022 to i64
  %3147 = mul i64 %3146, 8
  %3148 = sub i64 %3145, %3147
  %3149 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3150 = select i1 %3149, i64 %3148, i64 0
  %private.contiguous.address484 = getelementptr i8, ptr %3144, i64 %3150
  %private.contiguous.preserve485 = load <8 x i64>, ptr %private.contiguous.address484, align 8
  %3151 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 3), <8 x i64> %private.contiguous.preserve485
  store <8 x i64> %3151, ptr %private.contiguous.address484, align 8
  %3152 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3153 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3154 = add <8 x i64> %3153, splat (i64 512)
  %3155 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3152, 0
  %3156 = insertvalue { <8 x ptr>, <8 x i64> } %3155, <8 x i64> %3154, 1
  %3157 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3158 = extractvalue { <8 x ptr>, <8 x i64> } %3156, 1
  %3159 = extractelement <8 x ptr> %3157, i32 0
  %3160 = extractelement <8 x i64> %3158, i32 %3022
  %3161 = zext i32 %3022 to i64
  %3162 = mul i64 %3161, 8
  %3163 = sub i64 %3160, %3162
  %3164 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3165 = select i1 %3164, i64 %3163, i64 0
  %private.contiguous.address486 = getelementptr i8, ptr %3159, i64 %3165
  %private.contiguous.preserve487 = load <8 x i64>, ptr %private.contiguous.address486, align 8
  %3166 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 4), <8 x i64> %private.contiguous.preserve487
  store <8 x i64> %3166, ptr %private.contiguous.address486, align 8
  %3167 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3168 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3169 = add <8 x i64> %3168, splat (i64 576)
  %3170 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3167, 0
  %3171 = insertvalue { <8 x ptr>, <8 x i64> } %3170, <8 x i64> %3169, 1
  %3172 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3173 = extractvalue { <8 x ptr>, <8 x i64> } %3171, 1
  %3174 = extractelement <8 x ptr> %3172, i32 0
  %3175 = extractelement <8 x i64> %3173, i32 %3022
  %3176 = zext i32 %3022 to i64
  %3177 = mul i64 %3176, 8
  %3178 = sub i64 %3175, %3177
  %3179 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3180 = select i1 %3179, i64 %3178, i64 0
  %private.contiguous.address488 = getelementptr i8, ptr %3174, i64 %3180
  %private.contiguous.preserve489 = load <8 x i64>, ptr %private.contiguous.address488, align 8
  %3181 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 5), <8 x i64> %private.contiguous.preserve489
  store <8 x i64> %3181, ptr %private.contiguous.address488, align 8
  %3182 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3183 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3184 = add <8 x i64> %3183, splat (i64 640)
  %3185 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3182, 0
  %3186 = insertvalue { <8 x ptr>, <8 x i64> } %3185, <8 x i64> %3184, 1
  %3187 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3188 = extractvalue { <8 x ptr>, <8 x i64> } %3186, 1
  %3189 = extractelement <8 x ptr> %3187, i32 0
  %3190 = extractelement <8 x i64> %3188, i32 %3022
  %3191 = zext i32 %3022 to i64
  %3192 = mul i64 %3191, 8
  %3193 = sub i64 %3190, %3192
  %3194 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3195 = select i1 %3194, i64 %3193, i64 0
  %private.contiguous.address490 = getelementptr i8, ptr %3189, i64 %3195
  %private.contiguous.preserve491 = load <8 x i64>, ptr %private.contiguous.address490, align 8
  %3196 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 6), <8 x i64> %private.contiguous.preserve491
  store <8 x i64> %3196, ptr %private.contiguous.address490, align 8
  %3197 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3198 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3199 = add <8 x i64> %3198, splat (i64 704)
  %3200 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3197, 0
  %3201 = insertvalue { <8 x ptr>, <8 x i64> } %3200, <8 x i64> %3199, 1
  %3202 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3203 = extractvalue { <8 x ptr>, <8 x i64> } %3201, 1
  %3204 = extractelement <8 x ptr> %3202, i32 0
  %3205 = extractelement <8 x i64> %3203, i32 %3022
  %3206 = zext i32 %3022 to i64
  %3207 = mul i64 %3206, 8
  %3208 = sub i64 %3205, %3207
  %3209 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3210 = select i1 %3209, i64 %3208, i64 0
  %private.contiguous.address492 = getelementptr i8, ptr %3204, i64 %3210
  %private.contiguous.preserve493 = load <8 x i64>, ptr %private.contiguous.address492, align 8
  %3211 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 7), <8 x i64> %private.contiguous.preserve493
  store <8 x i64> %3211, ptr %private.contiguous.address492, align 8
  %3212 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3213 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3214 = add <8 x i64> %3213, splat (i64 768)
  %3215 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3212, 0
  %3216 = insertvalue { <8 x ptr>, <8 x i64> } %3215, <8 x i64> %3214, 1
  %3217 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3218 = extractvalue { <8 x ptr>, <8 x i64> } %3216, 1
  %3219 = extractelement <8 x ptr> %3217, i32 0
  %3220 = extractelement <8 x i64> %3218, i32 %3022
  %3221 = zext i32 %3022 to i64
  %3222 = mul i64 %3221, 8
  %3223 = sub i64 %3220, %3222
  %3224 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3225 = select i1 %3224, i64 %3223, i64 0
  %private.contiguous.address494 = getelementptr i8, ptr %3219, i64 %3225
  %private.contiguous.preserve495 = load <8 x i64>, ptr %private.contiguous.address494, align 8
  %3226 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 8), <8 x i64> %private.contiguous.preserve495
  store <8 x i64> %3226, ptr %private.contiguous.address494, align 8
  %3227 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3228 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3229 = add <8 x i64> %3228, splat (i64 832)
  %3230 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3227, 0
  %3231 = insertvalue { <8 x ptr>, <8 x i64> } %3230, <8 x i64> %3229, 1
  %3232 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3233 = extractvalue { <8 x ptr>, <8 x i64> } %3231, 1
  %3234 = extractelement <8 x ptr> %3232, i32 0
  %3235 = extractelement <8 x i64> %3233, i32 %3022
  %3236 = zext i32 %3022 to i64
  %3237 = mul i64 %3236, 8
  %3238 = sub i64 %3235, %3237
  %3239 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3240 = select i1 %3239, i64 %3238, i64 0
  %private.contiguous.address496 = getelementptr i8, ptr %3234, i64 %3240
  %private.contiguous.preserve497 = load <8 x i64>, ptr %private.contiguous.address496, align 8
  %3241 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 9), <8 x i64> %private.contiguous.preserve497
  store <8 x i64> %3241, ptr %private.contiguous.address496, align 8
  %3242 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3243 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3244 = add <8 x i64> %3243, splat (i64 896)
  %3245 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3242, 0
  %3246 = insertvalue { <8 x ptr>, <8 x i64> } %3245, <8 x i64> %3244, 1
  %3247 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3248 = extractvalue { <8 x ptr>, <8 x i64> } %3246, 1
  %3249 = extractelement <8 x ptr> %3247, i32 0
  %3250 = extractelement <8 x i64> %3248, i32 %3022
  %3251 = zext i32 %3022 to i64
  %3252 = mul i64 %3251, 8
  %3253 = sub i64 %3250, %3252
  %3254 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3255 = select i1 %3254, i64 %3253, i64 0
  %private.contiguous.address498 = getelementptr i8, ptr %3249, i64 %3255
  %private.contiguous.preserve499 = load <8 x i64>, ptr %private.contiguous.address498, align 8
  %3256 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 10), <8 x i64> %private.contiguous.preserve499
  store <8 x i64> %3256, ptr %private.contiguous.address498, align 8
  %3257 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3258 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3259 = add <8 x i64> %3258, splat (i64 960)
  %3260 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3257, 0
  %3261 = insertvalue { <8 x ptr>, <8 x i64> } %3260, <8 x i64> %3259, 1
  %3262 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3263 = extractvalue { <8 x ptr>, <8 x i64> } %3261, 1
  %3264 = extractelement <8 x ptr> %3262, i32 0
  %3265 = extractelement <8 x i64> %3263, i32 %3022
  %3266 = zext i32 %3022 to i64
  %3267 = mul i64 %3266, 8
  %3268 = sub i64 %3265, %3267
  %3269 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3270 = select i1 %3269, i64 %3268, i64 0
  %private.contiguous.address500 = getelementptr i8, ptr %3264, i64 %3270
  %private.contiguous.preserve501 = load <8 x i64>, ptr %private.contiguous.address500, align 8
  %3271 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 11), <8 x i64> %private.contiguous.preserve501
  store <8 x i64> %3271, ptr %private.contiguous.address500, align 8
  %3272 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3273 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3274 = add <8 x i64> %3273, splat (i64 1024)
  %3275 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3272, 0
  %3276 = insertvalue { <8 x ptr>, <8 x i64> } %3275, <8 x i64> %3274, 1
  %3277 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3278 = extractvalue { <8 x ptr>, <8 x i64> } %3276, 1
  %3279 = extractelement <8 x ptr> %3277, i32 0
  %3280 = extractelement <8 x i64> %3278, i32 %3022
  %3281 = zext i32 %3022 to i64
  %3282 = mul i64 %3281, 8
  %3283 = sub i64 %3280, %3282
  %3284 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3285 = select i1 %3284, i64 %3283, i64 0
  %private.contiguous.address502 = getelementptr i8, ptr %3279, i64 %3285
  %private.contiguous.preserve503 = load <8 x i64>, ptr %private.contiguous.address502, align 8
  %3286 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 12), <8 x i64> %private.contiguous.preserve503
  store <8 x i64> %3286, ptr %private.contiguous.address502, align 8
  %3287 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3288 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3289 = add <8 x i64> %3288, splat (i64 1088)
  %3290 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3287, 0
  %3291 = insertvalue { <8 x ptr>, <8 x i64> } %3290, <8 x i64> %3289, 1
  %3292 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3293 = extractvalue { <8 x ptr>, <8 x i64> } %3291, 1
  %3294 = extractelement <8 x ptr> %3292, i32 0
  %3295 = extractelement <8 x i64> %3293, i32 %3022
  %3296 = zext i32 %3022 to i64
  %3297 = mul i64 %3296, 8
  %3298 = sub i64 %3295, %3297
  %3299 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3300 = select i1 %3299, i64 %3298, i64 0
  %private.contiguous.address504 = getelementptr i8, ptr %3294, i64 %3300
  %private.contiguous.preserve505 = load <8 x i64>, ptr %private.contiguous.address504, align 8
  %3301 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 13), <8 x i64> %private.contiguous.preserve505
  store <8 x i64> %3301, ptr %private.contiguous.address504, align 8
  %3302 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3303 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3304 = add <8 x i64> %3303, splat (i64 1152)
  %3305 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3302, 0
  %3306 = insertvalue { <8 x ptr>, <8 x i64> } %3305, <8 x i64> %3304, 1
  %3307 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3308 = extractvalue { <8 x ptr>, <8 x i64> } %3306, 1
  %3309 = extractelement <8 x ptr> %3307, i32 0
  %3310 = extractelement <8 x i64> %3308, i32 %3022
  %3311 = zext i32 %3022 to i64
  %3312 = mul i64 %3311, 8
  %3313 = sub i64 %3310, %3312
  %3314 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3315 = select i1 %3314, i64 %3313, i64 0
  %private.contiguous.address506 = getelementptr i8, ptr %3309, i64 %3315
  %private.contiguous.preserve507 = load <8 x i64>, ptr %private.contiguous.address506, align 8
  %3316 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 14), <8 x i64> %private.contiguous.preserve507
  store <8 x i64> %3316, ptr %private.contiguous.address506, align 8
  %3317 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3318 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3319 = add <8 x i64> %3318, splat (i64 1216)
  %3320 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3317, 0
  %3321 = insertvalue { <8 x ptr>, <8 x i64> } %3320, <8 x i64> %3319, 1
  %3322 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3323 = extractvalue { <8 x ptr>, <8 x i64> } %3321, 1
  %3324 = extractelement <8 x ptr> %3322, i32 0
  %3325 = extractelement <8 x i64> %3323, i32 %3022
  %3326 = zext i32 %3022 to i64
  %3327 = mul i64 %3326, 8
  %3328 = sub i64 %3325, %3327
  %3329 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3330 = select i1 %3329, i64 %3328, i64 0
  %private.contiguous.address508 = getelementptr i8, ptr %3324, i64 %3330
  %private.contiguous.preserve509 = load <8 x i64>, ptr %private.contiguous.address508, align 8
  %3331 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 15), <8 x i64> %private.contiguous.preserve509
  store <8 x i64> %3331, ptr %private.contiguous.address508, align 8
  %3332 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3333 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3334 = add <8 x i64> %3333, splat (i64 1280)
  %3335 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3332, 0
  %3336 = insertvalue { <8 x ptr>, <8 x i64> } %3335, <8 x i64> %3334, 1
  %3337 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3338 = extractvalue { <8 x ptr>, <8 x i64> } %3336, 1
  %3339 = extractelement <8 x ptr> %3337, i32 0
  %3340 = extractelement <8 x i64> %3338, i32 %3022
  %3341 = zext i32 %3022 to i64
  %3342 = mul i64 %3341, 8
  %3343 = sub i64 %3340, %3342
  %3344 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3345 = select i1 %3344, i64 %3343, i64 0
  %private.contiguous.address510 = getelementptr i8, ptr %3339, i64 %3345
  %private.contiguous.preserve511 = load <8 x i64>, ptr %private.contiguous.address510, align 8
  %3346 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 16), <8 x i64> %private.contiguous.preserve511
  store <8 x i64> %3346, ptr %private.contiguous.address510, align 8
  %3347 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3348 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3349 = add <8 x i64> %3348, splat (i64 1344)
  %3350 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3347, 0
  %3351 = insertvalue { <8 x ptr>, <8 x i64> } %3350, <8 x i64> %3349, 1
  %3352 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3353 = extractvalue { <8 x ptr>, <8 x i64> } %3351, 1
  %3354 = extractelement <8 x ptr> %3352, i32 0
  %3355 = extractelement <8 x i64> %3353, i32 %3022
  %3356 = zext i32 %3022 to i64
  %3357 = mul i64 %3356, 8
  %3358 = sub i64 %3355, %3357
  %3359 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3360 = select i1 %3359, i64 %3358, i64 0
  %private.contiguous.address512 = getelementptr i8, ptr %3354, i64 %3360
  %private.contiguous.preserve513 = load <8 x i64>, ptr %private.contiguous.address512, align 8
  %3361 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 17), <8 x i64> %private.contiguous.preserve513
  store <8 x i64> %3361, ptr %private.contiguous.address512, align 8
  %3362 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3363 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3364 = add <8 x i64> %3363, splat (i64 1408)
  %3365 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3362, 0
  %3366 = insertvalue { <8 x ptr>, <8 x i64> } %3365, <8 x i64> %3364, 1
  %3367 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3368 = extractvalue { <8 x ptr>, <8 x i64> } %3366, 1
  %3369 = extractelement <8 x ptr> %3367, i32 0
  %3370 = extractelement <8 x i64> %3368, i32 %3022
  %3371 = zext i32 %3022 to i64
  %3372 = mul i64 %3371, 8
  %3373 = sub i64 %3370, %3372
  %3374 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3375 = select i1 %3374, i64 %3373, i64 0
  %private.contiguous.address514 = getelementptr i8, ptr %3369, i64 %3375
  %private.contiguous.preserve515 = load <8 x i64>, ptr %private.contiguous.address514, align 8
  %3376 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 18), <8 x i64> %private.contiguous.preserve515
  store <8 x i64> %3376, ptr %private.contiguous.address514, align 8
  %3377 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3378 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3379 = add <8 x i64> %3378, splat (i64 1472)
  %3380 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3377, 0
  %3381 = insertvalue { <8 x ptr>, <8 x i64> } %3380, <8 x i64> %3379, 1
  %3382 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3383 = extractvalue { <8 x ptr>, <8 x i64> } %3381, 1
  %3384 = extractelement <8 x ptr> %3382, i32 0
  %3385 = extractelement <8 x i64> %3383, i32 %3022
  %3386 = zext i32 %3022 to i64
  %3387 = mul i64 %3386, 8
  %3388 = sub i64 %3385, %3387
  %3389 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3390 = select i1 %3389, i64 %3388, i64 0
  %private.contiguous.address516 = getelementptr i8, ptr %3384, i64 %3390
  %private.contiguous.preserve517 = load <8 x i64>, ptr %private.contiguous.address516, align 8
  %3391 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 19), <8 x i64> %private.contiguous.preserve517
  store <8 x i64> %3391, ptr %private.contiguous.address516, align 8
  %3392 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3393 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3394 = add <8 x i64> %3393, splat (i64 1536)
  %3395 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3392, 0
  %3396 = insertvalue { <8 x ptr>, <8 x i64> } %3395, <8 x i64> %3394, 1
  %3397 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3398 = extractvalue { <8 x ptr>, <8 x i64> } %3396, 1
  %3399 = extractelement <8 x ptr> %3397, i32 0
  %3400 = extractelement <8 x i64> %3398, i32 %3022
  %3401 = zext i32 %3022 to i64
  %3402 = mul i64 %3401, 8
  %3403 = sub i64 %3400, %3402
  %3404 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3405 = select i1 %3404, i64 %3403, i64 0
  %private.contiguous.address518 = getelementptr i8, ptr %3399, i64 %3405
  %private.contiguous.preserve519 = load <8 x i64>, ptr %private.contiguous.address518, align 8
  %3406 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 20), <8 x i64> %private.contiguous.preserve519
  store <8 x i64> %3406, ptr %private.contiguous.address518, align 8
  %3407 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3408 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3409 = add <8 x i64> %3408, splat (i64 1600)
  %3410 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3407, 0
  %3411 = insertvalue { <8 x ptr>, <8 x i64> } %3410, <8 x i64> %3409, 1
  %3412 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3413 = extractvalue { <8 x ptr>, <8 x i64> } %3411, 1
  %3414 = extractelement <8 x ptr> %3412, i32 0
  %3415 = extractelement <8 x i64> %3413, i32 %3022
  %3416 = zext i32 %3022 to i64
  %3417 = mul i64 %3416, 8
  %3418 = sub i64 %3415, %3417
  %3419 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3420 = select i1 %3419, i64 %3418, i64 0
  %private.contiguous.address520 = getelementptr i8, ptr %3414, i64 %3420
  %private.contiguous.preserve521 = load <8 x i64>, ptr %private.contiguous.address520, align 8
  %3421 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 21), <8 x i64> %private.contiguous.preserve521
  store <8 x i64> %3421, ptr %private.contiguous.address520, align 8
  %3422 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3423 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3424 = add <8 x i64> %3423, splat (i64 1664)
  %3425 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3422, 0
  %3426 = insertvalue { <8 x ptr>, <8 x i64> } %3425, <8 x i64> %3424, 1
  %3427 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3428 = extractvalue { <8 x ptr>, <8 x i64> } %3426, 1
  %3429 = extractelement <8 x ptr> %3427, i32 0
  %3430 = extractelement <8 x i64> %3428, i32 %3022
  %3431 = zext i32 %3022 to i64
  %3432 = mul i64 %3431, 8
  %3433 = sub i64 %3430, %3432
  %3434 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3435 = select i1 %3434, i64 %3433, i64 0
  %private.contiguous.address522 = getelementptr i8, ptr %3429, i64 %3435
  %private.contiguous.preserve523 = load <8 x i64>, ptr %private.contiguous.address522, align 8
  %3436 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 22), <8 x i64> %private.contiguous.preserve523
  store <8 x i64> %3436, ptr %private.contiguous.address522, align 8
  %3437 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3438 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3439 = add <8 x i64> %3438, splat (i64 1728)
  %3440 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3437, 0
  %3441 = insertvalue { <8 x ptr>, <8 x i64> } %3440, <8 x i64> %3439, 1
  %3442 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3443 = extractvalue { <8 x ptr>, <8 x i64> } %3441, 1
  %3444 = extractelement <8 x ptr> %3442, i32 0
  %3445 = extractelement <8 x i64> %3443, i32 %3022
  %3446 = zext i32 %3022 to i64
  %3447 = mul i64 %3446, 8
  %3448 = sub i64 %3445, %3447
  %3449 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3450 = select i1 %3449, i64 %3448, i64 0
  %private.contiguous.address524 = getelementptr i8, ptr %3444, i64 %3450
  %private.contiguous.preserve525 = load <8 x i64>, ptr %private.contiguous.address524, align 8
  %3451 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 23), <8 x i64> %private.contiguous.preserve525
  store <8 x i64> %3451, ptr %private.contiguous.address524, align 8
  %3452 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3453 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3454 = add <8 x i64> %3453, splat (i64 1792)
  %3455 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3452, 0
  %3456 = insertvalue { <8 x ptr>, <8 x i64> } %3455, <8 x i64> %3454, 1
  %3457 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3458 = extractvalue { <8 x ptr>, <8 x i64> } %3456, 1
  %3459 = extractelement <8 x ptr> %3457, i32 0
  %3460 = extractelement <8 x i64> %3458, i32 %3022
  %3461 = zext i32 %3022 to i64
  %3462 = mul i64 %3461, 8
  %3463 = sub i64 %3460, %3462
  %3464 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3465 = select i1 %3464, i64 %3463, i64 0
  %private.contiguous.address526 = getelementptr i8, ptr %3459, i64 %3465
  %private.contiguous.preserve527 = load <8 x i64>, ptr %private.contiguous.address526, align 8
  %3466 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 24), <8 x i64> %private.contiguous.preserve527
  store <8 x i64> %3466, ptr %private.contiguous.address526, align 8
  %3467 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3468 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3469 = add <8 x i64> %3468, splat (i64 1856)
  %3470 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3467, 0
  %3471 = insertvalue { <8 x ptr>, <8 x i64> } %3470, <8 x i64> %3469, 1
  %3472 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3473 = extractvalue { <8 x ptr>, <8 x i64> } %3471, 1
  %3474 = extractelement <8 x ptr> %3472, i32 0
  %3475 = extractelement <8 x i64> %3473, i32 %3022
  %3476 = zext i32 %3022 to i64
  %3477 = mul i64 %3476, 8
  %3478 = sub i64 %3475, %3477
  %3479 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3480 = select i1 %3479, i64 %3478, i64 0
  %private.contiguous.address528 = getelementptr i8, ptr %3474, i64 %3480
  %private.contiguous.preserve529 = load <8 x i64>, ptr %private.contiguous.address528, align 8
  %3481 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 25), <8 x i64> %private.contiguous.preserve529
  store <8 x i64> %3481, ptr %private.contiguous.address528, align 8
  %3482 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3483 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3484 = add <8 x i64> %3483, splat (i64 1920)
  %3485 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3482, 0
  %3486 = insertvalue { <8 x ptr>, <8 x i64> } %3485, <8 x i64> %3484, 1
  %3487 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3488 = extractvalue { <8 x ptr>, <8 x i64> } %3486, 1
  %3489 = extractelement <8 x ptr> %3487, i32 0
  %3490 = extractelement <8 x i64> %3488, i32 %3022
  %3491 = zext i32 %3022 to i64
  %3492 = mul i64 %3491, 8
  %3493 = sub i64 %3490, %3492
  %3494 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3495 = select i1 %3494, i64 %3493, i64 0
  %private.contiguous.address530 = getelementptr i8, ptr %3489, i64 %3495
  %private.contiguous.preserve531 = load <8 x i64>, ptr %private.contiguous.address530, align 8
  %3496 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 26), <8 x i64> %private.contiguous.preserve531
  store <8 x i64> %3496, ptr %private.contiguous.address530, align 8
  %3497 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3498 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3499 = add <8 x i64> %3498, splat (i64 1984)
  %3500 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3497, 0
  %3501 = insertvalue { <8 x ptr>, <8 x i64> } %3500, <8 x i64> %3499, 1
  %3502 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3503 = extractvalue { <8 x ptr>, <8 x i64> } %3501, 1
  %3504 = extractelement <8 x ptr> %3502, i32 0
  %3505 = extractelement <8 x i64> %3503, i32 %3022
  %3506 = zext i32 %3022 to i64
  %3507 = mul i64 %3506, 8
  %3508 = sub i64 %3505, %3507
  %3509 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  %3510 = select i1 %3509, i64 %3508, i64 0
  %private.contiguous.address532 = getelementptr i8, ptr %3504, i64 %3510
  %private.contiguous.preserve533 = load <8 x i64>, ptr %private.contiguous.address532, align 8
  %3511 = select <8 x i1> %convergence.cascade.result469, <8 x i64> splat (i64 27), <8 x i64> %private.contiguous.preserve533
  store <8 x i64> %3511, ptr %private.contiguous.address532, align 8
  %3512 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill74, align 64
  %3513 = extractvalue { <8 x ptr>, <8 x i64> } %19, 0
  %3514 = extractvalue { <8 x ptr>, <8 x i64> } %3512, 0
  %3515 = select <8 x i1> %convergence.cascade.result469, <8 x ptr> %3513, <8 x ptr> %3514
  %3516 = extractvalue { <8 x ptr>, <8 x i64> } %19, 1
  %3517 = extractvalue { <8 x ptr>, <8 x i64> } %3512, 1
  %3518 = select <8 x i1> %convergence.cascade.result469, <8 x i64> %3516, <8 x i64> %3517
  %3519 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3515, 0
  %3520 = insertvalue { <8 x ptr>, <8 x i64> } %3519, <8 x i64> %3518, 1
  store volatile { <8 x ptr>, <8 x i64> } %3520, ptr %tile_snapshot.spill74, align 64
  %3521 = load <8 x i64>, ptr %.slot75, align 64
  %3522 = select <8 x i1> %convergence.cascade.result469, <8 x i64> zeroinitializer, <8 x i64> %3521
  store <8 x i64> %3522, ptr %.slot75, align 64
  store <8 x i1> %convergence.cascade.result469, ptr %current.mask, align 1
  %3523 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result469)
  br i1 %3523, label %schedule.22, label %scheduler.loop

varying.divergent535:                             ; preds = %schedule.22
  %3524 = load i32, ptr %current.token, align 4
  %3525 = icmp ne i32 %3524, 0
  %3526 = sub i32 %3524, 1
  %3527 = select i1 %3525, i32 %3526, i32 0
  %3528 = load i8, ptr %frame.active, align 1
  %3529 = trunc i32 %3527 to i8
  %3530 = shl i8 1, %3529
  %3531 = and i8 %3528, %3530
  %3532 = icmp ne i8 %3531, 0
  %3533 = load <8 x i32>, ptr %frame.static.id, align 32
  %3534 = extractelement <8 x i32> %3533, i32 %3527
  %3535 = icmp eq i32 %3534, 8
  %3536 = and i1 %3532, %3535
  %3537 = and i1 %3525, %3536
  %3538 = xor i1 %3537, true
  %3539 = and i1 true, %3538
  %3540 = xor i8 %3528, -1
  %3541 = icmp ne i8 %3540, 0
  %3542 = xor i1 %3541, true
  %3543 = and i1 %3539, %3542
  br i1 %3543, label %convergence.overflow.trap537, label %convergence.overflow.resume538

varying.coherent536:                              ; preds = %schedule.22
  br i1 %564, label %varying.coherent.true541, label %varying.coherent.false542

convergence.overflow.trap537:                     ; preds = %varying.divergent535
  call void @llvm.trap()
  unreachable

convergence.overflow.resume538:                   ; preds = %varying.divergent535
  %3544 = call i8 @llvm.cttz.i8(i8 %3540, i1 false)
  %3545 = zext i8 %3544 to i32
  %3546 = select i1 %3541, i32 %3545, i32 0
  %3547 = trunc i32 %3546 to i8
  %3548 = shl i8 1, %3547
  %3549 = or i8 %3528, %3548
  %3550 = select i1 %3539, i8 %3549, i8 %3528
  store i8 %3550, ptr %frame.active, align 1
  %3551 = load <8 x i32>, ptr %frame.static.id, align 32
  %3552 = extractelement <8 x i32> %3551, i32 %3546
  %3553 = select i1 %3539, i32 8, i32 %3552
  %3554 = load <8 x i32>, ptr %frame.static.id, align 32
  %3555 = insertelement <8 x i32> %3554, i32 %3553, i32 %3546
  store <8 x i32> %3555, ptr %frame.static.id, align 32
  %3556 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3557 = extractelement <8 x i32> %3556, i32 %3546
  %3558 = select i1 %3539, i32 %3524, i32 %3557
  %3559 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3560 = insertelement <8 x i32> %3559, i32 %3558, i32 %3546
  store <8 x i32> %3560, ptr %frame.parent.token, align 32
  %3561 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3546
  %3562 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3546
  %3563 = load <8 x i1>, ptr %3561, align 1
  %3564 = load <8 x i1>, ptr %3562, align 1
  %3565 = select i1 %3539, <8 x i1> %554, <8 x i1> %3563
  store <8 x i1> %3565, ptr %3561, align 1
  %3566 = select i1 %3539, <8 x i1> zeroinitializer, <8 x i1> %3564
  store <8 x i1> %3566, ptr %3562, align 1
  %3567 = add i32 %3546, 1
  %3568 = select i1 %3537, i32 %3524, i32 %3567
  %3569 = select i1 true, i32 %3568, i32 %3524
  store i32 %3569, ptr %current.token, align 4
  %3570 = load i32, ptr %current.token, align 4
  %3571 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %561)
  %3572 = load i32, ptr %ready.count, align 4
  %3573 = icmp uge i32 %3572, 8
  %3574 = and i1 %3571, %3573
  br i1 %3574, label %ready.overflow.trap539, label %ready.overflow.resume540

ready.overflow.trap539:                           ; preds = %convergence.overflow.resume538
  call void @llvm.trap()
  unreachable

ready.overflow.resume540:                         ; preds = %convergence.overflow.resume538
  %3575 = select i1 %3571, i32 %3572, i32 0
  %3576 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3575
  %3577 = load <8 x i1>, ptr %3576, align 1
  %3578 = select i1 %3571, <8 x i1> %561, <8 x i1> %3577
  store <8 x i1> %3578, ptr %3576, align 1
  %3579 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3575
  %3580 = load i32, ptr %3579, align 4
  %3581 = select i1 %3571, i32 23, i32 %3580
  store i32 %3581, ptr %3579, align 4
  %3582 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3575
  %3583 = load i32, ptr %3582, align 4
  %3584 = select i1 %3571, i32 %3570, i32 %3583
  store i32 %3584, ptr %3582, align 4
  %3585 = add i32 %3572, 1
  %3586 = select i1 %3571, i32 %3585, i32 %3572
  store i32 %3586, ptr %ready.count, align 4
  %3587 = load <8 x i1>, ptr %runnable.mask, align 1
  %3588 = or <8 x i1> %3587, %561
  store <8 x i1> %3588, ptr %runnable.mask, align 1
  store <8 x i1> %563, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true541:                         ; preds = %varying.coherent536
  store <8 x i1> %554, ptr %current.mask, align 1
  %3589 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %554)
  br i1 %3589, label %schedule.23, label %scheduler.loop

varying.coherent.false542:                        ; preds = %varying.coherent536
  store <8 x i1> %554, ptr %current.mask, align 1
  %3590 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %554)
  br i1 %3590, label %schedule.26, label %scheduler.loop

varying.divergent549:                             ; preds = %schedule.23
  %3591 = load i32, ptr %current.token, align 4
  %3592 = icmp ne i32 %3591, 0
  %3593 = sub i32 %3591, 1
  %3594 = select i1 %3592, i32 %3593, i32 0
  %3595 = load i8, ptr %frame.active, align 1
  %3596 = trunc i32 %3594 to i8
  %3597 = shl i8 1, %3596
  %3598 = and i8 %3595, %3597
  %3599 = icmp ne i8 %3598, 0
  %3600 = load <8 x i32>, ptr %frame.static.id, align 32
  %3601 = extractelement <8 x i32> %3600, i32 %3594
  %3602 = icmp eq i32 %3601, 9
  %3603 = and i1 %3599, %3602
  %3604 = and i1 %3592, %3603
  %3605 = xor i1 %3604, true
  %3606 = and i1 true, %3605
  %3607 = xor i8 %3595, -1
  %3608 = icmp ne i8 %3607, 0
  %3609 = xor i1 %3608, true
  %3610 = and i1 %3606, %3609
  br i1 %3610, label %convergence.overflow.trap551, label %convergence.overflow.resume552

varying.coherent550:                              ; preds = %schedule.23
  br i1 %606, label %varying.coherent.true555, label %varying.coherent.false556

convergence.overflow.trap551:                     ; preds = %varying.divergent549
  call void @llvm.trap()
  unreachable

convergence.overflow.resume552:                   ; preds = %varying.divergent549
  %3611 = call i8 @llvm.cttz.i8(i8 %3607, i1 false)
  %3612 = zext i8 %3611 to i32
  %3613 = select i1 %3608, i32 %3612, i32 0
  %3614 = trunc i32 %3613 to i8
  %3615 = shl i8 1, %3614
  %3616 = or i8 %3595, %3615
  %3617 = select i1 %3606, i8 %3616, i8 %3595
  store i8 %3617, ptr %frame.active, align 1
  %3618 = load <8 x i32>, ptr %frame.static.id, align 32
  %3619 = extractelement <8 x i32> %3618, i32 %3613
  %3620 = select i1 %3606, i32 9, i32 %3619
  %3621 = load <8 x i32>, ptr %frame.static.id, align 32
  %3622 = insertelement <8 x i32> %3621, i32 %3620, i32 %3613
  store <8 x i32> %3622, ptr %frame.static.id, align 32
  %3623 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3624 = extractelement <8 x i32> %3623, i32 %3613
  %3625 = select i1 %3606, i32 %3591, i32 %3624
  %3626 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3627 = insertelement <8 x i32> %3626, i32 %3625, i32 %3613
  store <8 x i32> %3627, ptr %frame.parent.token, align 32
  %3628 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3613
  %3629 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3613
  %3630 = load <8 x i1>, ptr %3628, align 1
  %3631 = load <8 x i1>, ptr %3629, align 1
  %3632 = select i1 %3606, <8 x i1> %567, <8 x i1> %3630
  store <8 x i1> %3632, ptr %3628, align 1
  %3633 = select i1 %3606, <8 x i1> zeroinitializer, <8 x i1> %3631
  store <8 x i1> %3633, ptr %3629, align 1
  %3634 = add i32 %3613, 1
  %3635 = select i1 %3604, i32 %3591, i32 %3634
  %3636 = select i1 true, i32 %3635, i32 %3591
  store i32 %3636, ptr %current.token, align 4
  %3637 = load <8 x float>, ptr %.slot78, align 32
  %3638 = select <8 x i1> %605, <8 x float> zeroinitializer, <8 x float> %3637
  store <8 x float> %3638, ptr %.slot78, align 32
  %3639 = load i32, ptr %current.token, align 4
  %3640 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %603)
  %3641 = load i32, ptr %ready.count, align 4
  %3642 = icmp uge i32 %3641, 8
  %3643 = and i1 %3640, %3642
  br i1 %3643, label %ready.overflow.trap553, label %ready.overflow.resume554

ready.overflow.trap553:                           ; preds = %convergence.overflow.resume552
  call void @llvm.trap()
  unreachable

ready.overflow.resume554:                         ; preds = %convergence.overflow.resume552
  %3644 = select i1 %3640, i32 %3641, i32 0
  %3645 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3644
  %3646 = load <8 x i1>, ptr %3645, align 1
  %3647 = select i1 %3640, <8 x i1> %603, <8 x i1> %3646
  store <8 x i1> %3647, ptr %3645, align 1
  %3648 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3644
  %3649 = load i32, ptr %3648, align 4
  %3650 = select i1 %3640, i32 24, i32 %3649
  store i32 %3650, ptr %3648, align 4
  %3651 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3644
  %3652 = load i32, ptr %3651, align 4
  %3653 = select i1 %3640, i32 %3639, i32 %3652
  store i32 %3653, ptr %3651, align 4
  %3654 = add i32 %3641, 1
  %3655 = select i1 %3640, i32 %3654, i32 %3641
  store i32 %3655, ptr %ready.count, align 4
  %3656 = load <8 x i1>, ptr %runnable.mask, align 1
  %3657 = or <8 x i1> %3656, %603
  store <8 x i1> %3657, ptr %runnable.mask, align 1
  store <8 x i1> %605, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true555:                         ; preds = %varying.coherent550
  store <8 x i1> %567, ptr %current.mask, align 1
  %3658 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %567)
  br i1 %3658, label %schedule.24, label %scheduler.loop

varying.coherent.false556:                        ; preds = %varying.coherent550
  %3659 = load <8 x float>, ptr %.slot78, align 32
  %3660 = select <8 x i1> %567, <8 x float> zeroinitializer, <8 x float> %3659
  store <8 x float> %3660, ptr %.slot78, align 32
  store <8 x i1> %567, ptr %current.mask, align 1
  %3661 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %567)
  br i1 %3661, label %schedule.25, label %scheduler.loop

convergence.cascade559:                           ; preds = %convergence.cascade559, %schedule.25
  %convergence.cascade.flow563 = phi <8 x i1> [ %628, %schedule.25 ], [ %3704, %convergence.cascade559 ]
  %convergence.cascade.depth564 = phi i32 [ 0, %schedule.25 ], [ %3705, %convergence.cascade559 ]
  %3662 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow563)
  %3663 = load i32, ptr %current.token, align 4
  %3664 = icmp ne i32 %3663, 0
  %3665 = and i1 %3662, %3664
  %3666 = sub i32 %3663, 1
  %3667 = select i1 %3665, i32 %3666, i32 0
  %3668 = load i8, ptr %frame.active, align 1
  %3669 = trunc i32 %3667 to i8
  %3670 = shl i8 1, %3669
  %3671 = and i8 %3668, %3670
  %3672 = icmp ne i8 %3671, 0
  %3673 = load <8 x i32>, ptr %frame.static.id, align 32
  %3674 = extractelement <8 x i32> %3673, i32 %3667
  %convergence.target.pointer565 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %3674
  %convergence.dynamic.target566 = load i32, ptr %convergence.target.pointer565, align 4
  %3675 = icmp eq i32 %convergence.dynamic.target566, 25
  %3676 = and i1 %3672, %3675
  %3677 = and i1 %3665, %3676
  %3678 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3667
  %3679 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3667
  %3680 = load <8 x i1>, ptr %3678, align 1
  %3681 = load <8 x i1>, ptr %3679, align 1
  %3682 = or <8 x i1> %3681, %convergence.cascade.flow563
  %3683 = load <8 x i1>, ptr %live.mask, align 1
  %3684 = and <8 x i1> %3680, %3683
  %3685 = icmp eq <8 x i1> %3682, %3684
  %3686 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3685)
  %3687 = and i1 %3677, %3686
  %3688 = select i1 %3687, <8 x i1> zeroinitializer, <8 x i1> %3682
  %3689 = select i1 %3677, <8 x i1> %3688, <8 x i1> %3681
  store <8 x i1> %3689, ptr %3679, align 1
  %3690 = select i1 %3687, <8 x i1> zeroinitializer, <8 x i1> %3680
  store <8 x i1> %3690, ptr %3678, align 1
  %3691 = trunc i32 %3667 to i8
  %3692 = shl i8 1, %3691
  %3693 = xor i8 %3692, -1
  %3694 = and i8 %3668, %3693
  %3695 = select i1 %3687, i8 %3694, i8 %3668
  store i8 %3695, ptr %frame.active, align 1
  %.splatinsert567 = insertelement <8 x i1> poison, i1 %3677, i64 0
  %.splat568 = shufflevector <8 x i1> %.splatinsert567, <8 x i1> poison, <8 x i32> zeroinitializer
  %3696 = and <8 x i1> %convergence.cascade.flow563, %.splat568
  %3697 = load <8 x i1>, ptr %runnable.mask, align 1
  %3698 = xor <8 x i1> %3696, splat (i1 true)
  %3699 = and <8 x i1> %3697, %3698
  store <8 x i1> %3699, ptr %runnable.mask, align 1
  %.splatinsert569 = insertelement <8 x i1> poison, i1 %3687, i64 0
  %.splat570 = shufflevector <8 x i1> %.splatinsert569, <8 x i1> poison, <8 x i32> zeroinitializer
  %3700 = select <8 x i1> %.splat570, <8 x i1> %3682, <8 x i1> zeroinitializer
  %3701 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3702 = extractelement <8 x i32> %3701, i32 %3667
  %3703 = select i1 %3687, i32 %3702, i32 %3663
  store i32 %3703, ptr %current.token, align 4
  %.splatinsert571 = insertelement <8 x i1> poison, i1 %3677, i64 0
  %.splat572 = shufflevector <8 x i1> %.splatinsert571, <8 x i1> poison, <8 x i32> zeroinitializer
  %3704 = select <8 x i1> %.splat572, <8 x i1> %3700, <8 x i1> %convergence.cascade.flow563
  %3705 = add i32 %convergence.cascade.depth564, 1
  %3706 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3704)
  %3707 = icmp ult i32 %3705, 8
  %3708 = and i1 %3706, %3707
  %3709 = and i1 %3677, %3708
  %convergence.parent.token573 = load i32, ptr %current.token, align 4
  %convergence.parent.present574 = icmp ne i32 %convergence.parent.token573, 0
  %3710 = and i1 %3709, %convergence.parent.present574
  br i1 %3710, label %convergence.cascade559, label %convergence.cascade.exit560

convergence.cascade.exit560:                      ; preds = %convergence.cascade559, %schedule.25
  %convergence.cascade.result575 = phi <8 x i1> [ %628, %schedule.25 ], [ %3704, %convergence.cascade559 ]
  %3711 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result575)
  br i1 %3711, label %convergence.target.25.ready, label %scheduler.loop

convergence.target.25.ready:                      ; preds = %convergence.cascade.exit560
  %3712 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result575)
  %3713 = bitcast <8 x i1> %convergence.cascade.result575 to i8
  %3714 = call i8 @llvm.cttz.i8(i8 %3713, i1 false)
  %3715 = zext i8 %3714 to i32
  %3716 = select i1 %3712, i32 %3715, i32 0
  %.spill.load576 = load float, ptr %.spill49, align 4
  %.splatinsert577 = insertelement <8 x float> poison, float %.spill.load576, i64 0
  %.splat578 = shufflevector <8 x float> %.splatinsert577, <8 x float> poison, <8 x i32> zeroinitializer
  %.state579 = load <8 x float>, ptr %.slot78, align 32
  %.spill.load580 = load volatile <8 x i1>, ptr %.spill76, align 1
  %3717 = select <8 x i1> %.spill.load580, <8 x float> %.state579, <8 x float> %.splat578
  %tile_snapshot.spill.load581 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill74, align 64
  %3718 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load581, 0
  %3719 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load581, 1
  %.state582 = load <8 x i64>, ptr %.slot75, align 64
  %3720 = mul <8 x i64> %.state582, splat (i64 32)
  %3721 = add <8 x i64> %3719, %3720
  %3722 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3718, 0
  %3723 = insertvalue { <8 x ptr>, <8 x i64> } %3722, <8 x i64> %3721, 1
  %3724 = extractvalue { <8 x ptr>, <8 x i64> } %3723, 0
  %3725 = extractvalue { <8 x ptr>, <8 x i64> } %3723, 1
  %3726 = getelementptr i8, <8 x ptr> %3724, <8 x i64> %3725
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %3717, <8 x ptr> %3726, i32 1, <8 x i1> %convergence.cascade.result575)
  %.state583 = load <8 x i64>, ptr %.slot75, align 64
  %3727 = add <8 x i64> %.state583, splat (i64 1)
  %3728 = load <8 x i64>, ptr %.slot75, align 64
  %3729 = select <8 x i1> %convergence.cascade.result575, <8 x i64> %3727, <8 x i64> %3728
  store <8 x i64> %3729, ptr %.slot75, align 64
  store <8 x i1> %convergence.cascade.result575, ptr %current.mask, align 1
  %3730 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result575)
  br i1 %3730, label %schedule.22, label %scheduler.loop

convergence.cascade584:                           ; preds = %convergence.cascade584, %schedule.26
  %convergence.cascade.flow588 = phi <8 x i1> [ %629, %schedule.26 ], [ %3773, %convergence.cascade584 ]
  %convergence.cascade.depth589 = phi i32 [ 0, %schedule.26 ], [ %3774, %convergence.cascade584 ]
  %3731 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow588)
  %3732 = load i32, ptr %current.token, align 4
  %3733 = icmp ne i32 %3732, 0
  %3734 = and i1 %3731, %3733
  %3735 = sub i32 %3732, 1
  %3736 = select i1 %3734, i32 %3735, i32 0
  %3737 = load i8, ptr %frame.active, align 1
  %3738 = trunc i32 %3736 to i8
  %3739 = shl i8 1, %3738
  %3740 = and i8 %3737, %3739
  %3741 = icmp ne i8 %3740, 0
  %3742 = load <8 x i32>, ptr %frame.static.id, align 32
  %3743 = extractelement <8 x i32> %3742, i32 %3736
  %convergence.target.pointer590 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %3743
  %convergence.dynamic.target591 = load i32, ptr %convergence.target.pointer590, align 4
  %3744 = icmp eq i32 %convergence.dynamic.target591, 26
  %3745 = and i1 %3741, %3744
  %3746 = and i1 %3734, %3745
  %3747 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3736
  %3748 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3736
  %3749 = load <8 x i1>, ptr %3747, align 1
  %3750 = load <8 x i1>, ptr %3748, align 1
  %3751 = or <8 x i1> %3750, %convergence.cascade.flow588
  %3752 = load <8 x i1>, ptr %live.mask, align 1
  %3753 = and <8 x i1> %3749, %3752
  %3754 = icmp eq <8 x i1> %3751, %3753
  %3755 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3754)
  %3756 = and i1 %3746, %3755
  %3757 = select i1 %3756, <8 x i1> zeroinitializer, <8 x i1> %3751
  %3758 = select i1 %3746, <8 x i1> %3757, <8 x i1> %3750
  store <8 x i1> %3758, ptr %3748, align 1
  %3759 = select i1 %3756, <8 x i1> zeroinitializer, <8 x i1> %3749
  store <8 x i1> %3759, ptr %3747, align 1
  %3760 = trunc i32 %3736 to i8
  %3761 = shl i8 1, %3760
  %3762 = xor i8 %3761, -1
  %3763 = and i8 %3737, %3762
  %3764 = select i1 %3756, i8 %3763, i8 %3737
  store i8 %3764, ptr %frame.active, align 1
  %.splatinsert592 = insertelement <8 x i1> poison, i1 %3746, i64 0
  %.splat593 = shufflevector <8 x i1> %.splatinsert592, <8 x i1> poison, <8 x i32> zeroinitializer
  %3765 = and <8 x i1> %convergence.cascade.flow588, %.splat593
  %3766 = load <8 x i1>, ptr %runnable.mask, align 1
  %3767 = xor <8 x i1> %3765, splat (i1 true)
  %3768 = and <8 x i1> %3766, %3767
  store <8 x i1> %3768, ptr %runnable.mask, align 1
  %.splatinsert594 = insertelement <8 x i1> poison, i1 %3756, i64 0
  %.splat595 = shufflevector <8 x i1> %.splatinsert594, <8 x i1> poison, <8 x i32> zeroinitializer
  %3769 = select <8 x i1> %.splat595, <8 x i1> %3751, <8 x i1> zeroinitializer
  %3770 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3771 = extractelement <8 x i32> %3770, i32 %3736
  %3772 = select i1 %3756, i32 %3771, i32 %3732
  store i32 %3772, ptr %current.token, align 4
  %.splatinsert596 = insertelement <8 x i1> poison, i1 %3746, i64 0
  %.splat597 = shufflevector <8 x i1> %.splatinsert596, <8 x i1> poison, <8 x i32> zeroinitializer
  %3773 = select <8 x i1> %.splat597, <8 x i1> %3769, <8 x i1> %convergence.cascade.flow588
  %3774 = add i32 %convergence.cascade.depth589, 1
  %3775 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3773)
  %3776 = icmp ult i32 %3774, 8
  %3777 = and i1 %3775, %3776
  %3778 = and i1 %3746, %3777
  %convergence.parent.token598 = load i32, ptr %current.token, align 4
  %convergence.parent.present599 = icmp ne i32 %convergence.parent.token598, 0
  %3779 = and i1 %3778, %convergence.parent.present599
  br i1 %3779, label %convergence.cascade584, label %convergence.cascade.exit585

convergence.cascade.exit585:                      ; preds = %convergence.cascade584, %schedule.26
  %convergence.cascade.result600 = phi <8 x i1> [ %629, %schedule.26 ], [ %3773, %convergence.cascade584 ]
  %3780 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result600)
  br i1 %3780, label %convergence.target.26.ready, label %scheduler.loop

convergence.target.26.ready:                      ; preds = %convergence.cascade.exit585
  %3781 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result600)
  %3782 = bitcast <8 x i1> %convergence.cascade.result600 to i8
  %3783 = call i8 @llvm.cttz.i8(i8 %3782, i1 false)
  %3784 = zext i8 %3783 to i32
  %3785 = select i1 %3781, i32 %3784, i32 0
  %3786 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %3787 = extractvalue { <8 x ptr>, <8 x i64> } %21, 0
  %3788 = extractvalue { <8 x ptr>, <8 x i64> } %3786, 0
  %3789 = select <8 x i1> %convergence.cascade.result600, <8 x ptr> %3787, <8 x ptr> %3788
  %3790 = extractvalue { <8 x ptr>, <8 x i64> } %21, 1
  %3791 = extractvalue { <8 x ptr>, <8 x i64> } %3786, 1
  %3792 = select <8 x i1> %convergence.cascade.result600, <8 x i64> %3790, <8 x i64> %3791
  %3793 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3789, 0
  %3794 = insertvalue { <8 x ptr>, <8 x i64> } %3793, <8 x i64> %3792, 1
  store volatile { <8 x ptr>, <8 x i64> } %3794, ptr %tile_snapshot.spill79, align 64
  %3795 = load <8 x i64>, ptr %.slot80, align 64
  %3796 = select <8 x i1> %convergence.cascade.result600, <8 x i64> zeroinitializer, <8 x i64> %3795
  store <8 x i64> %3796, ptr %.slot80, align 64
  store <8 x i1> %convergence.cascade.result600, ptr %current.mask, align 1
  %3797 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result600)
  br i1 %3797, label %schedule.27, label %scheduler.loop

varying.divergent602:                             ; preds = %schedule.27
  %3798 = load i32, ptr %current.token, align 4
  %3799 = icmp ne i32 %3798, 0
  %3800 = sub i32 %3798, 1
  %3801 = select i1 %3799, i32 %3800, i32 0
  %3802 = load i8, ptr %frame.active, align 1
  %3803 = trunc i32 %3801 to i8
  %3804 = shl i8 1, %3803
  %3805 = and i8 %3802, %3804
  %3806 = icmp ne i8 %3805, 0
  %3807 = load <8 x i32>, ptr %frame.static.id, align 32
  %3808 = extractelement <8 x i32> %3807, i32 %3801
  %3809 = icmp eq i32 %3808, 10
  %3810 = and i1 %3806, %3809
  %3811 = and i1 %3799, %3810
  %3812 = xor i1 %3811, true
  %3813 = and i1 true, %3812
  %3814 = xor i8 %3802, -1
  %3815 = icmp ne i8 %3814, 0
  %3816 = xor i1 %3815, true
  %3817 = and i1 %3813, %3816
  br i1 %3817, label %convergence.overflow.trap604, label %convergence.overflow.resume605

varying.coherent603:                              ; preds = %schedule.27
  br i1 %640, label %varying.coherent.true608, label %varying.coherent.false609

convergence.overflow.trap604:                     ; preds = %varying.divergent602
  call void @llvm.trap()
  unreachable

convergence.overflow.resume605:                   ; preds = %varying.divergent602
  %3818 = call i8 @llvm.cttz.i8(i8 %3814, i1 false)
  %3819 = zext i8 %3818 to i32
  %3820 = select i1 %3815, i32 %3819, i32 0
  %3821 = trunc i32 %3820 to i8
  %3822 = shl i8 1, %3821
  %3823 = or i8 %3802, %3822
  %3824 = select i1 %3813, i8 %3823, i8 %3802
  store i8 %3824, ptr %frame.active, align 1
  %3825 = load <8 x i32>, ptr %frame.static.id, align 32
  %3826 = extractelement <8 x i32> %3825, i32 %3820
  %3827 = select i1 %3813, i32 10, i32 %3826
  %3828 = load <8 x i32>, ptr %frame.static.id, align 32
  %3829 = insertelement <8 x i32> %3828, i32 %3827, i32 %3820
  store <8 x i32> %3829, ptr %frame.static.id, align 32
  %3830 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3831 = extractelement <8 x i32> %3830, i32 %3820
  %3832 = select i1 %3813, i32 %3798, i32 %3831
  %3833 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3834 = insertelement <8 x i32> %3833, i32 %3832, i32 %3820
  store <8 x i32> %3834, ptr %frame.parent.token, align 32
  %3835 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3820
  %3836 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3820
  %3837 = load <8 x i1>, ptr %3835, align 1
  %3838 = load <8 x i1>, ptr %3836, align 1
  %3839 = select i1 %3813, <8 x i1> %630, <8 x i1> %3837
  store <8 x i1> %3839, ptr %3835, align 1
  %3840 = select i1 %3813, <8 x i1> zeroinitializer, <8 x i1> %3838
  store <8 x i1> %3840, ptr %3836, align 1
  %3841 = add i32 %3820, 1
  %3842 = select i1 %3811, i32 %3798, i32 %3841
  %3843 = select i1 true, i32 %3842, i32 %3798
  store i32 %3843, ptr %current.token, align 4
  %3844 = load i32, ptr %current.token, align 4
  %3845 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %637)
  %3846 = load i32, ptr %ready.count, align 4
  %3847 = icmp uge i32 %3846, 8
  %3848 = and i1 %3845, %3847
  br i1 %3848, label %ready.overflow.trap606, label %ready.overflow.resume607

ready.overflow.trap606:                           ; preds = %convergence.overflow.resume605
  call void @llvm.trap()
  unreachable

ready.overflow.resume607:                         ; preds = %convergence.overflow.resume605
  %3849 = select i1 %3845, i32 %3846, i32 0
  %3850 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3849
  %3851 = load <8 x i1>, ptr %3850, align 1
  %3852 = select i1 %3845, <8 x i1> %637, <8 x i1> %3851
  store <8 x i1> %3852, ptr %3850, align 1
  %3853 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3849
  %3854 = load i32, ptr %3853, align 4
  %3855 = select i1 %3845, i32 28, i32 %3854
  store i32 %3855, ptr %3853, align 4
  %3856 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3849
  %3857 = load i32, ptr %3856, align 4
  %3858 = select i1 %3845, i32 %3844, i32 %3857
  store i32 %3858, ptr %3856, align 4
  %3859 = add i32 %3846, 1
  %3860 = select i1 %3845, i32 %3859, i32 %3846
  store i32 %3860, ptr %ready.count, align 4
  %3861 = load <8 x i1>, ptr %runnable.mask, align 1
  %3862 = or <8 x i1> %3861, %637
  store <8 x i1> %3862, ptr %runnable.mask, align 1
  store <8 x i1> %639, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true608:                         ; preds = %varying.coherent603
  store <8 x i1> %630, ptr %current.mask, align 1
  %3863 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %630)
  br i1 %3863, label %schedule.28, label %scheduler.loop

varying.coherent.false609:                        ; preds = %varying.coherent603
  store <8 x i1> %630, ptr %current.mask, align 1
  %3864 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %630)
  br i1 %3864, label %schedule.29, label %scheduler.loop

convergence.cascade617:                           ; preds = %convergence.cascade617, %schedule.29
  %convergence.cascade.flow621 = phi <8 x i1> [ %692, %schedule.29 ], [ %3907, %convergence.cascade617 ]
  %convergence.cascade.depth622 = phi i32 [ 0, %schedule.29 ], [ %3908, %convergence.cascade617 ]
  %3865 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow621)
  %3866 = load i32, ptr %current.token, align 4
  %3867 = icmp ne i32 %3866, 0
  %3868 = and i1 %3865, %3867
  %3869 = sub i32 %3866, 1
  %3870 = select i1 %3868, i32 %3869, i32 0
  %3871 = load i8, ptr %frame.active, align 1
  %3872 = trunc i32 %3870 to i8
  %3873 = shl i8 1, %3872
  %3874 = and i8 %3871, %3873
  %3875 = icmp ne i8 %3874, 0
  %3876 = load <8 x i32>, ptr %frame.static.id, align 32
  %3877 = extractelement <8 x i32> %3876, i32 %3870
  %convergence.target.pointer623 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %3877
  %convergence.dynamic.target624 = load i32, ptr %convergence.target.pointer623, align 4
  %3878 = icmp eq i32 %convergence.dynamic.target624, 29
  %3879 = and i1 %3875, %3878
  %3880 = and i1 %3868, %3879
  %3881 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3870
  %3882 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3870
  %3883 = load <8 x i1>, ptr %3881, align 1
  %3884 = load <8 x i1>, ptr %3882, align 1
  %3885 = or <8 x i1> %3884, %convergence.cascade.flow621
  %3886 = load <8 x i1>, ptr %live.mask, align 1
  %3887 = and <8 x i1> %3883, %3886
  %3888 = icmp eq <8 x i1> %3885, %3887
  %3889 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3888)
  %3890 = and i1 %3880, %3889
  %3891 = select i1 %3890, <8 x i1> zeroinitializer, <8 x i1> %3885
  %3892 = select i1 %3880, <8 x i1> %3891, <8 x i1> %3884
  store <8 x i1> %3892, ptr %3882, align 1
  %3893 = select i1 %3890, <8 x i1> zeroinitializer, <8 x i1> %3883
  store <8 x i1> %3893, ptr %3881, align 1
  %3894 = trunc i32 %3870 to i8
  %3895 = shl i8 1, %3894
  %3896 = xor i8 %3895, -1
  %3897 = and i8 %3871, %3896
  %3898 = select i1 %3890, i8 %3897, i8 %3871
  store i8 %3898, ptr %frame.active, align 1
  %.splatinsert625 = insertelement <8 x i1> poison, i1 %3880, i64 0
  %.splat626 = shufflevector <8 x i1> %.splatinsert625, <8 x i1> poison, <8 x i32> zeroinitializer
  %3899 = and <8 x i1> %convergence.cascade.flow621, %.splat626
  %3900 = load <8 x i1>, ptr %runnable.mask, align 1
  %3901 = xor <8 x i1> %3899, splat (i1 true)
  %3902 = and <8 x i1> %3900, %3901
  store <8 x i1> %3902, ptr %runnable.mask, align 1
  %.splatinsert627 = insertelement <8 x i1> poison, i1 %3890, i64 0
  %.splat628 = shufflevector <8 x i1> %.splatinsert627, <8 x i1> poison, <8 x i32> zeroinitializer
  %3903 = select <8 x i1> %.splat628, <8 x i1> %3885, <8 x i1> zeroinitializer
  %3904 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3905 = extractelement <8 x i32> %3904, i32 %3870
  %3906 = select i1 %3890, i32 %3905, i32 %3866
  store i32 %3906, ptr %current.token, align 4
  %.splatinsert629 = insertelement <8 x i1> poison, i1 %3880, i64 0
  %.splat630 = shufflevector <8 x i1> %.splatinsert629, <8 x i1> poison, <8 x i32> zeroinitializer
  %3907 = select <8 x i1> %.splat630, <8 x i1> %3903, <8 x i1> %convergence.cascade.flow621
  %3908 = add i32 %convergence.cascade.depth622, 1
  %3909 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3907)
  %3910 = icmp ult i32 %3908, 8
  %3911 = and i1 %3909, %3910
  %3912 = and i1 %3880, %3911
  %convergence.parent.token631 = load i32, ptr %current.token, align 4
  %convergence.parent.present632 = icmp ne i32 %convergence.parent.token631, 0
  %3913 = and i1 %3912, %convergence.parent.present632
  br i1 %3913, label %convergence.cascade617, label %convergence.cascade.exit618

convergence.cascade.exit618:                      ; preds = %convergence.cascade617, %schedule.29
  %convergence.cascade.result633 = phi <8 x i1> [ %692, %schedule.29 ], [ %3907, %convergence.cascade617 ]
  %3914 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  br i1 %3914, label %convergence.target.29.ready, label %scheduler.loop

convergence.target.29.ready:                      ; preds = %convergence.cascade.exit618
  %3915 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %3916 = bitcast <8 x i1> %convergence.cascade.result633 to i8
  %3917 = call i8 @llvm.cttz.i8(i8 %3916, i1 false)
  %3918 = zext i8 %3917 to i32
  %3919 = select i1 %3915, i32 %3918, i32 0
  %3920 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill81, align 64
  %3921 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3922 = extractvalue { <8 x ptr>, <8 x i64> } %3920, 0
  %3923 = select <8 x i1> %convergence.cascade.result633, <8 x ptr> %3921, <8 x ptr> %3922
  %3924 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3925 = extractvalue { <8 x ptr>, <8 x i64> } %3920, 1
  %3926 = select <8 x i1> %convergence.cascade.result633, <8 x i64> %3924, <8 x i64> %3925
  %3927 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3923, 0
  %3928 = insertvalue { <8 x ptr>, <8 x i64> } %3927, <8 x i64> %3926, 1
  store volatile { <8 x ptr>, <8 x i64> } %3928, ptr %tile_snapshot.spill81, align 64
  %3929 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3930 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3931 = add <8 x i64> %3930, zeroinitializer
  %3932 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3929, 0
  %3933 = insertvalue { <8 x ptr>, <8 x i64> } %3932, <8 x i64> %3931, 1
  %3934 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3935 = extractvalue { <8 x ptr>, <8 x i64> } %3933, 1
  %3936 = extractelement <8 x ptr> %3934, i32 0
  %3937 = extractelement <8 x i64> %3935, i32 %3919
  %3938 = zext i32 %3919 to i64
  %3939 = mul i64 %3938, 8
  %3940 = sub i64 %3937, %3939
  %3941 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %3942 = select i1 %3941, i64 %3940, i64 0
  %private.contiguous.address634 = getelementptr i8, ptr %3936, i64 %3942
  %private.contiguous.preserve635 = load <8 x i64>, ptr %private.contiguous.address634, align 8
  %3943 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 -8), <8 x i64> %private.contiguous.preserve635
  store <8 x i64> %3943, ptr %private.contiguous.address634, align 8
  %3944 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3945 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3946 = add <8 x i64> %3945, splat (i64 64)
  %3947 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3944, 0
  %3948 = insertvalue { <8 x ptr>, <8 x i64> } %3947, <8 x i64> %3946, 1
  %3949 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3950 = extractvalue { <8 x ptr>, <8 x i64> } %3948, 1
  %3951 = extractelement <8 x ptr> %3949, i32 0
  %3952 = extractelement <8 x i64> %3950, i32 %3919
  %3953 = zext i32 %3919 to i64
  %3954 = mul i64 %3953, 8
  %3955 = sub i64 %3952, %3954
  %3956 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %3957 = select i1 %3956, i64 %3955, i64 0
  %private.contiguous.address636 = getelementptr i8, ptr %3951, i64 %3957
  %private.contiguous.preserve637 = load <8 x i64>, ptr %private.contiguous.address636, align 8
  %3958 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 -7), <8 x i64> %private.contiguous.preserve637
  store <8 x i64> %3958, ptr %private.contiguous.address636, align 8
  %3959 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3960 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3961 = add <8 x i64> %3960, splat (i64 128)
  %3962 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3959, 0
  %3963 = insertvalue { <8 x ptr>, <8 x i64> } %3962, <8 x i64> %3961, 1
  %3964 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3965 = extractvalue { <8 x ptr>, <8 x i64> } %3963, 1
  %3966 = extractelement <8 x ptr> %3964, i32 0
  %3967 = extractelement <8 x i64> %3965, i32 %3919
  %3968 = zext i32 %3919 to i64
  %3969 = mul i64 %3968, 8
  %3970 = sub i64 %3967, %3969
  %3971 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %3972 = select i1 %3971, i64 %3970, i64 0
  %private.contiguous.address638 = getelementptr i8, ptr %3966, i64 %3972
  %private.contiguous.preserve639 = load <8 x i64>, ptr %private.contiguous.address638, align 8
  %3973 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 -6), <8 x i64> %private.contiguous.preserve639
  store <8 x i64> %3973, ptr %private.contiguous.address638, align 8
  %3974 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3975 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3976 = add <8 x i64> %3975, splat (i64 192)
  %3977 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3974, 0
  %3978 = insertvalue { <8 x ptr>, <8 x i64> } %3977, <8 x i64> %3976, 1
  %3979 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3980 = extractvalue { <8 x ptr>, <8 x i64> } %3978, 1
  %3981 = extractelement <8 x ptr> %3979, i32 0
  %3982 = extractelement <8 x i64> %3980, i32 %3919
  %3983 = zext i32 %3919 to i64
  %3984 = mul i64 %3983, 8
  %3985 = sub i64 %3982, %3984
  %3986 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %3987 = select i1 %3986, i64 %3985, i64 0
  %private.contiguous.address640 = getelementptr i8, ptr %3981, i64 %3987
  %private.contiguous.preserve641 = load <8 x i64>, ptr %private.contiguous.address640, align 8
  %3988 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 -5), <8 x i64> %private.contiguous.preserve641
  store <8 x i64> %3988, ptr %private.contiguous.address640, align 8
  %3989 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3990 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3991 = add <8 x i64> %3990, splat (i64 256)
  %3992 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3989, 0
  %3993 = insertvalue { <8 x ptr>, <8 x i64> } %3992, <8 x i64> %3991, 1
  %3994 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3995 = extractvalue { <8 x ptr>, <8 x i64> } %3993, 1
  %3996 = extractelement <8 x ptr> %3994, i32 0
  %3997 = extractelement <8 x i64> %3995, i32 %3919
  %3998 = zext i32 %3919 to i64
  %3999 = mul i64 %3998, 8
  %4000 = sub i64 %3997, %3999
  %4001 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %4002 = select i1 %4001, i64 %4000, i64 0
  %private.contiguous.address642 = getelementptr i8, ptr %3996, i64 %4002
  %private.contiguous.preserve643 = load <8 x i64>, ptr %private.contiguous.address642, align 8
  %4003 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 -4), <8 x i64> %private.contiguous.preserve643
  store <8 x i64> %4003, ptr %private.contiguous.address642, align 8
  %4004 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4005 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4006 = add <8 x i64> %4005, splat (i64 320)
  %4007 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4004, 0
  %4008 = insertvalue { <8 x ptr>, <8 x i64> } %4007, <8 x i64> %4006, 1
  %4009 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4010 = extractvalue { <8 x ptr>, <8 x i64> } %4008, 1
  %4011 = extractelement <8 x ptr> %4009, i32 0
  %4012 = extractelement <8 x i64> %4010, i32 %3919
  %4013 = zext i32 %3919 to i64
  %4014 = mul i64 %4013, 8
  %4015 = sub i64 %4012, %4014
  %4016 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %4017 = select i1 %4016, i64 %4015, i64 0
  %private.contiguous.address644 = getelementptr i8, ptr %4011, i64 %4017
  %private.contiguous.preserve645 = load <8 x i64>, ptr %private.contiguous.address644, align 8
  %4018 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 -3), <8 x i64> %private.contiguous.preserve645
  store <8 x i64> %4018, ptr %private.contiguous.address644, align 8
  %4019 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4020 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4021 = add <8 x i64> %4020, splat (i64 384)
  %4022 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4019, 0
  %4023 = insertvalue { <8 x ptr>, <8 x i64> } %4022, <8 x i64> %4021, 1
  %4024 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4025 = extractvalue { <8 x ptr>, <8 x i64> } %4023, 1
  %4026 = extractelement <8 x ptr> %4024, i32 0
  %4027 = extractelement <8 x i64> %4025, i32 %3919
  %4028 = zext i32 %3919 to i64
  %4029 = mul i64 %4028, 8
  %4030 = sub i64 %4027, %4029
  %4031 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %4032 = select i1 %4031, i64 %4030, i64 0
  %private.contiguous.address646 = getelementptr i8, ptr %4026, i64 %4032
  %private.contiguous.preserve647 = load <8 x i64>, ptr %private.contiguous.address646, align 8
  %4033 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 -2), <8 x i64> %private.contiguous.preserve647
  store <8 x i64> %4033, ptr %private.contiguous.address646, align 8
  %4034 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4035 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4036 = add <8 x i64> %4035, splat (i64 448)
  %4037 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4034, 0
  %4038 = insertvalue { <8 x ptr>, <8 x i64> } %4037, <8 x i64> %4036, 1
  %4039 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4040 = extractvalue { <8 x ptr>, <8 x i64> } %4038, 1
  %4041 = extractelement <8 x ptr> %4039, i32 0
  %4042 = extractelement <8 x i64> %4040, i32 %3919
  %4043 = zext i32 %3919 to i64
  %4044 = mul i64 %4043, 8
  %4045 = sub i64 %4042, %4044
  %4046 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %4047 = select i1 %4046, i64 %4045, i64 0
  %private.contiguous.address648 = getelementptr i8, ptr %4041, i64 %4047
  %private.contiguous.preserve649 = load <8 x i64>, ptr %private.contiguous.address648, align 8
  %4048 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 -1), <8 x i64> %private.contiguous.preserve649
  store <8 x i64> %4048, ptr %private.contiguous.address648, align 8
  %4049 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4050 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4051 = add <8 x i64> %4050, splat (i64 512)
  %4052 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4049, 0
  %4053 = insertvalue { <8 x ptr>, <8 x i64> } %4052, <8 x i64> %4051, 1
  %4054 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4055 = extractvalue { <8 x ptr>, <8 x i64> } %4053, 1
  %4056 = extractelement <8 x ptr> %4054, i32 0
  %4057 = extractelement <8 x i64> %4055, i32 %3919
  %4058 = zext i32 %3919 to i64
  %4059 = mul i64 %4058, 8
  %4060 = sub i64 %4057, %4059
  %4061 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %4062 = select i1 %4061, i64 %4060, i64 0
  %private.contiguous.address650 = getelementptr i8, ptr %4056, i64 %4062
  %private.contiguous.preserve651 = load <8 x i64>, ptr %private.contiguous.address650, align 8
  %4063 = select <8 x i1> %convergence.cascade.result633, <8 x i64> zeroinitializer, <8 x i64> %private.contiguous.preserve651
  store <8 x i64> %4063, ptr %private.contiguous.address650, align 8
  %4064 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4065 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4066 = add <8 x i64> %4065, splat (i64 576)
  %4067 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4064, 0
  %4068 = insertvalue { <8 x ptr>, <8 x i64> } %4067, <8 x i64> %4066, 1
  %4069 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4070 = extractvalue { <8 x ptr>, <8 x i64> } %4068, 1
  %4071 = extractelement <8 x ptr> %4069, i32 0
  %4072 = extractelement <8 x i64> %4070, i32 %3919
  %4073 = zext i32 %3919 to i64
  %4074 = mul i64 %4073, 8
  %4075 = sub i64 %4072, %4074
  %4076 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %4077 = select i1 %4076, i64 %4075, i64 0
  %private.contiguous.address652 = getelementptr i8, ptr %4071, i64 %4077
  %private.contiguous.preserve653 = load <8 x i64>, ptr %private.contiguous.address652, align 8
  %4078 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 1), <8 x i64> %private.contiguous.preserve653
  store <8 x i64> %4078, ptr %private.contiguous.address652, align 8
  %4079 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4080 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4081 = add <8 x i64> %4080, splat (i64 640)
  %4082 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4079, 0
  %4083 = insertvalue { <8 x ptr>, <8 x i64> } %4082, <8 x i64> %4081, 1
  %4084 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4085 = extractvalue { <8 x ptr>, <8 x i64> } %4083, 1
  %4086 = extractelement <8 x ptr> %4084, i32 0
  %4087 = extractelement <8 x i64> %4085, i32 %3919
  %4088 = zext i32 %3919 to i64
  %4089 = mul i64 %4088, 8
  %4090 = sub i64 %4087, %4089
  %4091 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %4092 = select i1 %4091, i64 %4090, i64 0
  %private.contiguous.address654 = getelementptr i8, ptr %4086, i64 %4092
  %private.contiguous.preserve655 = load <8 x i64>, ptr %private.contiguous.address654, align 8
  %4093 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 2), <8 x i64> %private.contiguous.preserve655
  store <8 x i64> %4093, ptr %private.contiguous.address654, align 8
  %4094 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4095 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4096 = add <8 x i64> %4095, splat (i64 704)
  %4097 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4094, 0
  %4098 = insertvalue { <8 x ptr>, <8 x i64> } %4097, <8 x i64> %4096, 1
  %4099 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4100 = extractvalue { <8 x ptr>, <8 x i64> } %4098, 1
  %4101 = extractelement <8 x ptr> %4099, i32 0
  %4102 = extractelement <8 x i64> %4100, i32 %3919
  %4103 = zext i32 %3919 to i64
  %4104 = mul i64 %4103, 8
  %4105 = sub i64 %4102, %4104
  %4106 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %4107 = select i1 %4106, i64 %4105, i64 0
  %private.contiguous.address656 = getelementptr i8, ptr %4101, i64 %4107
  %private.contiguous.preserve657 = load <8 x i64>, ptr %private.contiguous.address656, align 8
  %4108 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 3), <8 x i64> %private.contiguous.preserve657
  store <8 x i64> %4108, ptr %private.contiguous.address656, align 8
  %4109 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4110 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4111 = add <8 x i64> %4110, splat (i64 768)
  %4112 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4109, 0
  %4113 = insertvalue { <8 x ptr>, <8 x i64> } %4112, <8 x i64> %4111, 1
  %4114 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4115 = extractvalue { <8 x ptr>, <8 x i64> } %4113, 1
  %4116 = extractelement <8 x ptr> %4114, i32 0
  %4117 = extractelement <8 x i64> %4115, i32 %3919
  %4118 = zext i32 %3919 to i64
  %4119 = mul i64 %4118, 8
  %4120 = sub i64 %4117, %4119
  %4121 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %4122 = select i1 %4121, i64 %4120, i64 0
  %private.contiguous.address658 = getelementptr i8, ptr %4116, i64 %4122
  %private.contiguous.preserve659 = load <8 x i64>, ptr %private.contiguous.address658, align 8
  %4123 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 4), <8 x i64> %private.contiguous.preserve659
  store <8 x i64> %4123, ptr %private.contiguous.address658, align 8
  %4124 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4125 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4126 = add <8 x i64> %4125, splat (i64 832)
  %4127 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4124, 0
  %4128 = insertvalue { <8 x ptr>, <8 x i64> } %4127, <8 x i64> %4126, 1
  %4129 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4130 = extractvalue { <8 x ptr>, <8 x i64> } %4128, 1
  %4131 = extractelement <8 x ptr> %4129, i32 0
  %4132 = extractelement <8 x i64> %4130, i32 %3919
  %4133 = zext i32 %3919 to i64
  %4134 = mul i64 %4133, 8
  %4135 = sub i64 %4132, %4134
  %4136 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %4137 = select i1 %4136, i64 %4135, i64 0
  %private.contiguous.address660 = getelementptr i8, ptr %4131, i64 %4137
  %private.contiguous.preserve661 = load <8 x i64>, ptr %private.contiguous.address660, align 8
  %4138 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 5), <8 x i64> %private.contiguous.preserve661
  store <8 x i64> %4138, ptr %private.contiguous.address660, align 8
  %4139 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4140 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4141 = add <8 x i64> %4140, splat (i64 896)
  %4142 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4139, 0
  %4143 = insertvalue { <8 x ptr>, <8 x i64> } %4142, <8 x i64> %4141, 1
  %4144 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4145 = extractvalue { <8 x ptr>, <8 x i64> } %4143, 1
  %4146 = extractelement <8 x ptr> %4144, i32 0
  %4147 = extractelement <8 x i64> %4145, i32 %3919
  %4148 = zext i32 %3919 to i64
  %4149 = mul i64 %4148, 8
  %4150 = sub i64 %4147, %4149
  %4151 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %4152 = select i1 %4151, i64 %4150, i64 0
  %private.contiguous.address662 = getelementptr i8, ptr %4146, i64 %4152
  %private.contiguous.preserve663 = load <8 x i64>, ptr %private.contiguous.address662, align 8
  %4153 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 6), <8 x i64> %private.contiguous.preserve663
  store <8 x i64> %4153, ptr %private.contiguous.address662, align 8
  %4154 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4155 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4156 = add <8 x i64> %4155, splat (i64 960)
  %4157 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4154, 0
  %4158 = insertvalue { <8 x ptr>, <8 x i64> } %4157, <8 x i64> %4156, 1
  %4159 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4160 = extractvalue { <8 x ptr>, <8 x i64> } %4158, 1
  %4161 = extractelement <8 x ptr> %4159, i32 0
  %4162 = extractelement <8 x i64> %4160, i32 %3919
  %4163 = zext i32 %3919 to i64
  %4164 = mul i64 %4163, 8
  %4165 = sub i64 %4162, %4164
  %4166 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %4167 = select i1 %4166, i64 %4165, i64 0
  %private.contiguous.address664 = getelementptr i8, ptr %4161, i64 %4167
  %private.contiguous.preserve665 = load <8 x i64>, ptr %private.contiguous.address664, align 8
  %4168 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 7), <8 x i64> %private.contiguous.preserve665
  store <8 x i64> %4168, ptr %private.contiguous.address664, align 8
  %4169 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4170 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4171 = add <8 x i64> %4170, splat (i64 1024)
  %4172 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4169, 0
  %4173 = insertvalue { <8 x ptr>, <8 x i64> } %4172, <8 x i64> %4171, 1
  %4174 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4175 = extractvalue { <8 x ptr>, <8 x i64> } %4173, 1
  %4176 = extractelement <8 x ptr> %4174, i32 0
  %4177 = extractelement <8 x i64> %4175, i32 %3919
  %4178 = zext i32 %3919 to i64
  %4179 = mul i64 %4178, 8
  %4180 = sub i64 %4177, %4179
  %4181 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %4182 = select i1 %4181, i64 %4180, i64 0
  %private.contiguous.address666 = getelementptr i8, ptr %4176, i64 %4182
  %private.contiguous.preserve667 = load <8 x i64>, ptr %private.contiguous.address666, align 8
  %4183 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 8), <8 x i64> %private.contiguous.preserve667
  store <8 x i64> %4183, ptr %private.contiguous.address666, align 8
  %4184 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4185 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4186 = add <8 x i64> %4185, splat (i64 1088)
  %4187 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4184, 0
  %4188 = insertvalue { <8 x ptr>, <8 x i64> } %4187, <8 x i64> %4186, 1
  %4189 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4190 = extractvalue { <8 x ptr>, <8 x i64> } %4188, 1
  %4191 = extractelement <8 x ptr> %4189, i32 0
  %4192 = extractelement <8 x i64> %4190, i32 %3919
  %4193 = zext i32 %3919 to i64
  %4194 = mul i64 %4193, 8
  %4195 = sub i64 %4192, %4194
  %4196 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %4197 = select i1 %4196, i64 %4195, i64 0
  %private.contiguous.address668 = getelementptr i8, ptr %4191, i64 %4197
  %private.contiguous.preserve669 = load <8 x i64>, ptr %private.contiguous.address668, align 8
  %4198 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 9), <8 x i64> %private.contiguous.preserve669
  store <8 x i64> %4198, ptr %private.contiguous.address668, align 8
  %4199 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4200 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4201 = add <8 x i64> %4200, splat (i64 1152)
  %4202 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4199, 0
  %4203 = insertvalue { <8 x ptr>, <8 x i64> } %4202, <8 x i64> %4201, 1
  %4204 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4205 = extractvalue { <8 x ptr>, <8 x i64> } %4203, 1
  %4206 = extractelement <8 x ptr> %4204, i32 0
  %4207 = extractelement <8 x i64> %4205, i32 %3919
  %4208 = zext i32 %3919 to i64
  %4209 = mul i64 %4208, 8
  %4210 = sub i64 %4207, %4209
  %4211 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %4212 = select i1 %4211, i64 %4210, i64 0
  %private.contiguous.address670 = getelementptr i8, ptr %4206, i64 %4212
  %private.contiguous.preserve671 = load <8 x i64>, ptr %private.contiguous.address670, align 8
  %4213 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 10), <8 x i64> %private.contiguous.preserve671
  store <8 x i64> %4213, ptr %private.contiguous.address670, align 8
  %4214 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4215 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4216 = add <8 x i64> %4215, splat (i64 1216)
  %4217 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4214, 0
  %4218 = insertvalue { <8 x ptr>, <8 x i64> } %4217, <8 x i64> %4216, 1
  %4219 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4220 = extractvalue { <8 x ptr>, <8 x i64> } %4218, 1
  %4221 = extractelement <8 x ptr> %4219, i32 0
  %4222 = extractelement <8 x i64> %4220, i32 %3919
  %4223 = zext i32 %3919 to i64
  %4224 = mul i64 %4223, 8
  %4225 = sub i64 %4222, %4224
  %4226 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %4227 = select i1 %4226, i64 %4225, i64 0
  %private.contiguous.address672 = getelementptr i8, ptr %4221, i64 %4227
  %private.contiguous.preserve673 = load <8 x i64>, ptr %private.contiguous.address672, align 8
  %4228 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 11), <8 x i64> %private.contiguous.preserve673
  store <8 x i64> %4228, ptr %private.contiguous.address672, align 8
  %4229 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4230 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4231 = add <8 x i64> %4230, splat (i64 1280)
  %4232 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4229, 0
  %4233 = insertvalue { <8 x ptr>, <8 x i64> } %4232, <8 x i64> %4231, 1
  %4234 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4235 = extractvalue { <8 x ptr>, <8 x i64> } %4233, 1
  %4236 = extractelement <8 x ptr> %4234, i32 0
  %4237 = extractelement <8 x i64> %4235, i32 %3919
  %4238 = zext i32 %3919 to i64
  %4239 = mul i64 %4238, 8
  %4240 = sub i64 %4237, %4239
  %4241 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %4242 = select i1 %4241, i64 %4240, i64 0
  %private.contiguous.address674 = getelementptr i8, ptr %4236, i64 %4242
  %private.contiguous.preserve675 = load <8 x i64>, ptr %private.contiguous.address674, align 8
  %4243 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 12), <8 x i64> %private.contiguous.preserve675
  store <8 x i64> %4243, ptr %private.contiguous.address674, align 8
  %4244 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4245 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4246 = add <8 x i64> %4245, splat (i64 1344)
  %4247 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4244, 0
  %4248 = insertvalue { <8 x ptr>, <8 x i64> } %4247, <8 x i64> %4246, 1
  %4249 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4250 = extractvalue { <8 x ptr>, <8 x i64> } %4248, 1
  %4251 = extractelement <8 x ptr> %4249, i32 0
  %4252 = extractelement <8 x i64> %4250, i32 %3919
  %4253 = zext i32 %3919 to i64
  %4254 = mul i64 %4253, 8
  %4255 = sub i64 %4252, %4254
  %4256 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %4257 = select i1 %4256, i64 %4255, i64 0
  %private.contiguous.address676 = getelementptr i8, ptr %4251, i64 %4257
  %private.contiguous.preserve677 = load <8 x i64>, ptr %private.contiguous.address676, align 8
  %4258 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 13), <8 x i64> %private.contiguous.preserve677
  store <8 x i64> %4258, ptr %private.contiguous.address676, align 8
  %4259 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4260 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4261 = add <8 x i64> %4260, splat (i64 1408)
  %4262 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4259, 0
  %4263 = insertvalue { <8 x ptr>, <8 x i64> } %4262, <8 x i64> %4261, 1
  %4264 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4265 = extractvalue { <8 x ptr>, <8 x i64> } %4263, 1
  %4266 = extractelement <8 x ptr> %4264, i32 0
  %4267 = extractelement <8 x i64> %4265, i32 %3919
  %4268 = zext i32 %3919 to i64
  %4269 = mul i64 %4268, 8
  %4270 = sub i64 %4267, %4269
  %4271 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %4272 = select i1 %4271, i64 %4270, i64 0
  %private.contiguous.address678 = getelementptr i8, ptr %4266, i64 %4272
  %private.contiguous.preserve679 = load <8 x i64>, ptr %private.contiguous.address678, align 8
  %4273 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 14), <8 x i64> %private.contiguous.preserve679
  store <8 x i64> %4273, ptr %private.contiguous.address678, align 8
  %4274 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4275 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4276 = add <8 x i64> %4275, splat (i64 1472)
  %4277 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4274, 0
  %4278 = insertvalue { <8 x ptr>, <8 x i64> } %4277, <8 x i64> %4276, 1
  %4279 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4280 = extractvalue { <8 x ptr>, <8 x i64> } %4278, 1
  %4281 = extractelement <8 x ptr> %4279, i32 0
  %4282 = extractelement <8 x i64> %4280, i32 %3919
  %4283 = zext i32 %3919 to i64
  %4284 = mul i64 %4283, 8
  %4285 = sub i64 %4282, %4284
  %4286 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %4287 = select i1 %4286, i64 %4285, i64 0
  %private.contiguous.address680 = getelementptr i8, ptr %4281, i64 %4287
  %private.contiguous.preserve681 = load <8 x i64>, ptr %private.contiguous.address680, align 8
  %4288 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 15), <8 x i64> %private.contiguous.preserve681
  store <8 x i64> %4288, ptr %private.contiguous.address680, align 8
  %4289 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4290 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4291 = add <8 x i64> %4290, splat (i64 1536)
  %4292 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4289, 0
  %4293 = insertvalue { <8 x ptr>, <8 x i64> } %4292, <8 x i64> %4291, 1
  %4294 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4295 = extractvalue { <8 x ptr>, <8 x i64> } %4293, 1
  %4296 = extractelement <8 x ptr> %4294, i32 0
  %4297 = extractelement <8 x i64> %4295, i32 %3919
  %4298 = zext i32 %3919 to i64
  %4299 = mul i64 %4298, 8
  %4300 = sub i64 %4297, %4299
  %4301 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %4302 = select i1 %4301, i64 %4300, i64 0
  %private.contiguous.address682 = getelementptr i8, ptr %4296, i64 %4302
  %private.contiguous.preserve683 = load <8 x i64>, ptr %private.contiguous.address682, align 8
  %4303 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 16), <8 x i64> %private.contiguous.preserve683
  store <8 x i64> %4303, ptr %private.contiguous.address682, align 8
  %4304 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4305 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4306 = add <8 x i64> %4305, splat (i64 1600)
  %4307 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4304, 0
  %4308 = insertvalue { <8 x ptr>, <8 x i64> } %4307, <8 x i64> %4306, 1
  %4309 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4310 = extractvalue { <8 x ptr>, <8 x i64> } %4308, 1
  %4311 = extractelement <8 x ptr> %4309, i32 0
  %4312 = extractelement <8 x i64> %4310, i32 %3919
  %4313 = zext i32 %3919 to i64
  %4314 = mul i64 %4313, 8
  %4315 = sub i64 %4312, %4314
  %4316 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %4317 = select i1 %4316, i64 %4315, i64 0
  %private.contiguous.address684 = getelementptr i8, ptr %4311, i64 %4317
  %private.contiguous.preserve685 = load <8 x i64>, ptr %private.contiguous.address684, align 8
  %4318 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 17), <8 x i64> %private.contiguous.preserve685
  store <8 x i64> %4318, ptr %private.contiguous.address684, align 8
  %4319 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4320 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4321 = add <8 x i64> %4320, splat (i64 1664)
  %4322 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4319, 0
  %4323 = insertvalue { <8 x ptr>, <8 x i64> } %4322, <8 x i64> %4321, 1
  %4324 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4325 = extractvalue { <8 x ptr>, <8 x i64> } %4323, 1
  %4326 = extractelement <8 x ptr> %4324, i32 0
  %4327 = extractelement <8 x i64> %4325, i32 %3919
  %4328 = zext i32 %3919 to i64
  %4329 = mul i64 %4328, 8
  %4330 = sub i64 %4327, %4329
  %4331 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %4332 = select i1 %4331, i64 %4330, i64 0
  %private.contiguous.address686 = getelementptr i8, ptr %4326, i64 %4332
  %private.contiguous.preserve687 = load <8 x i64>, ptr %private.contiguous.address686, align 8
  %4333 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 18), <8 x i64> %private.contiguous.preserve687
  store <8 x i64> %4333, ptr %private.contiguous.address686, align 8
  %4334 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4335 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4336 = add <8 x i64> %4335, splat (i64 1728)
  %4337 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4334, 0
  %4338 = insertvalue { <8 x ptr>, <8 x i64> } %4337, <8 x i64> %4336, 1
  %4339 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4340 = extractvalue { <8 x ptr>, <8 x i64> } %4338, 1
  %4341 = extractelement <8 x ptr> %4339, i32 0
  %4342 = extractelement <8 x i64> %4340, i32 %3919
  %4343 = zext i32 %3919 to i64
  %4344 = mul i64 %4343, 8
  %4345 = sub i64 %4342, %4344
  %4346 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %4347 = select i1 %4346, i64 %4345, i64 0
  %private.contiguous.address688 = getelementptr i8, ptr %4341, i64 %4347
  %private.contiguous.preserve689 = load <8 x i64>, ptr %private.contiguous.address688, align 8
  %4348 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 19), <8 x i64> %private.contiguous.preserve689
  store <8 x i64> %4348, ptr %private.contiguous.address688, align 8
  %4349 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4350 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4351 = add <8 x i64> %4350, splat (i64 1792)
  %4352 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4349, 0
  %4353 = insertvalue { <8 x ptr>, <8 x i64> } %4352, <8 x i64> %4351, 1
  %4354 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4355 = extractvalue { <8 x ptr>, <8 x i64> } %4353, 1
  %4356 = extractelement <8 x ptr> %4354, i32 0
  %4357 = extractelement <8 x i64> %4355, i32 %3919
  %4358 = zext i32 %3919 to i64
  %4359 = mul i64 %4358, 8
  %4360 = sub i64 %4357, %4359
  %4361 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %4362 = select i1 %4361, i64 %4360, i64 0
  %private.contiguous.address690 = getelementptr i8, ptr %4356, i64 %4362
  %private.contiguous.preserve691 = load <8 x i64>, ptr %private.contiguous.address690, align 8
  %4363 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 20), <8 x i64> %private.contiguous.preserve691
  store <8 x i64> %4363, ptr %private.contiguous.address690, align 8
  %4364 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4365 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4366 = add <8 x i64> %4365, splat (i64 1856)
  %4367 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4364, 0
  %4368 = insertvalue { <8 x ptr>, <8 x i64> } %4367, <8 x i64> %4366, 1
  %4369 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4370 = extractvalue { <8 x ptr>, <8 x i64> } %4368, 1
  %4371 = extractelement <8 x ptr> %4369, i32 0
  %4372 = extractelement <8 x i64> %4370, i32 %3919
  %4373 = zext i32 %3919 to i64
  %4374 = mul i64 %4373, 8
  %4375 = sub i64 %4372, %4374
  %4376 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %4377 = select i1 %4376, i64 %4375, i64 0
  %private.contiguous.address692 = getelementptr i8, ptr %4371, i64 %4377
  %private.contiguous.preserve693 = load <8 x i64>, ptr %private.contiguous.address692, align 8
  %4378 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 21), <8 x i64> %private.contiguous.preserve693
  store <8 x i64> %4378, ptr %private.contiguous.address692, align 8
  %4379 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4380 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4381 = add <8 x i64> %4380, splat (i64 1920)
  %4382 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4379, 0
  %4383 = insertvalue { <8 x ptr>, <8 x i64> } %4382, <8 x i64> %4381, 1
  %4384 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4385 = extractvalue { <8 x ptr>, <8 x i64> } %4383, 1
  %4386 = extractelement <8 x ptr> %4384, i32 0
  %4387 = extractelement <8 x i64> %4385, i32 %3919
  %4388 = zext i32 %3919 to i64
  %4389 = mul i64 %4388, 8
  %4390 = sub i64 %4387, %4389
  %4391 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %4392 = select i1 %4391, i64 %4390, i64 0
  %private.contiguous.address694 = getelementptr i8, ptr %4386, i64 %4392
  %private.contiguous.preserve695 = load <8 x i64>, ptr %private.contiguous.address694, align 8
  %4393 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 22), <8 x i64> %private.contiguous.preserve695
  store <8 x i64> %4393, ptr %private.contiguous.address694, align 8
  %4394 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4395 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4396 = add <8 x i64> %4395, splat (i64 1984)
  %4397 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4394, 0
  %4398 = insertvalue { <8 x ptr>, <8 x i64> } %4397, <8 x i64> %4396, 1
  %4399 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4400 = extractvalue { <8 x ptr>, <8 x i64> } %4398, 1
  %4401 = extractelement <8 x ptr> %4399, i32 0
  %4402 = extractelement <8 x i64> %4400, i32 %3919
  %4403 = zext i32 %3919 to i64
  %4404 = mul i64 %4403, 8
  %4405 = sub i64 %4402, %4404
  %4406 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  %4407 = select i1 %4406, i64 %4405, i64 0
  %private.contiguous.address696 = getelementptr i8, ptr %4401, i64 %4407
  %private.contiguous.preserve697 = load <8 x i64>, ptr %private.contiguous.address696, align 8
  %4408 = select <8 x i1> %convergence.cascade.result633, <8 x i64> splat (i64 23), <8 x i64> %private.contiguous.preserve697
  store <8 x i64> %4408, ptr %private.contiguous.address696, align 8
  %4409 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill82, align 64
  %4410 = extractvalue { <8 x ptr>, <8 x i64> } %25, 0
  %4411 = extractvalue { <8 x ptr>, <8 x i64> } %4409, 0
  %4412 = select <8 x i1> %convergence.cascade.result633, <8 x ptr> %4410, <8 x ptr> %4411
  %4413 = extractvalue { <8 x ptr>, <8 x i64> } %25, 1
  %4414 = extractvalue { <8 x ptr>, <8 x i64> } %4409, 1
  %4415 = select <8 x i1> %convergence.cascade.result633, <8 x i64> %4413, <8 x i64> %4414
  %4416 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4412, 0
  %4417 = insertvalue { <8 x ptr>, <8 x i64> } %4416, <8 x i64> %4415, 1
  store volatile { <8 x ptr>, <8 x i64> } %4417, ptr %tile_snapshot.spill82, align 64
  %4418 = load <8 x i64>, ptr %.slot83, align 64
  %4419 = select <8 x i1> %convergence.cascade.result633, <8 x i64> zeroinitializer, <8 x i64> %4418
  store <8 x i64> %4419, ptr %.slot83, align 64
  store <8 x i1> %convergence.cascade.result633, ptr %current.mask, align 1
  %4420 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result633)
  br i1 %4420, label %schedule.30, label %scheduler.loop

varying.divergent699:                             ; preds = %schedule.30
  %4421 = load i32, ptr %current.token, align 4
  %4422 = icmp ne i32 %4421, 0
  %4423 = sub i32 %4421, 1
  %4424 = select i1 %4422, i32 %4423, i32 0
  %4425 = load i8, ptr %frame.active, align 1
  %4426 = trunc i32 %4424 to i8
  %4427 = shl i8 1, %4426
  %4428 = and i8 %4425, %4427
  %4429 = icmp ne i8 %4428, 0
  %4430 = load <8 x i32>, ptr %frame.static.id, align 32
  %4431 = extractelement <8 x i32> %4430, i32 %4424
  %4432 = icmp eq i32 %4431, 11
  %4433 = and i1 %4429, %4432
  %4434 = and i1 %4422, %4433
  %4435 = xor i1 %4434, true
  %4436 = and i1 true, %4435
  %4437 = xor i8 %4425, -1
  %4438 = icmp ne i8 %4437, 0
  %4439 = xor i1 %4438, true
  %4440 = and i1 %4436, %4439
  br i1 %4440, label %convergence.overflow.trap701, label %convergence.overflow.resume702

varying.coherent700:                              ; preds = %schedule.30
  br i1 %703, label %varying.coherent.true705, label %varying.coherent.false706

convergence.overflow.trap701:                     ; preds = %varying.divergent699
  call void @llvm.trap()
  unreachable

convergence.overflow.resume702:                   ; preds = %varying.divergent699
  %4441 = call i8 @llvm.cttz.i8(i8 %4437, i1 false)
  %4442 = zext i8 %4441 to i32
  %4443 = select i1 %4438, i32 %4442, i32 0
  %4444 = trunc i32 %4443 to i8
  %4445 = shl i8 1, %4444
  %4446 = or i8 %4425, %4445
  %4447 = select i1 %4436, i8 %4446, i8 %4425
  store i8 %4447, ptr %frame.active, align 1
  %4448 = load <8 x i32>, ptr %frame.static.id, align 32
  %4449 = extractelement <8 x i32> %4448, i32 %4443
  %4450 = select i1 %4436, i32 11, i32 %4449
  %4451 = load <8 x i32>, ptr %frame.static.id, align 32
  %4452 = insertelement <8 x i32> %4451, i32 %4450, i32 %4443
  store <8 x i32> %4452, ptr %frame.static.id, align 32
  %4453 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4454 = extractelement <8 x i32> %4453, i32 %4443
  %4455 = select i1 %4436, i32 %4421, i32 %4454
  %4456 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4457 = insertelement <8 x i32> %4456, i32 %4455, i32 %4443
  store <8 x i32> %4457, ptr %frame.parent.token, align 32
  %4458 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4443
  %4459 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4443
  %4460 = load <8 x i1>, ptr %4458, align 1
  %4461 = load <8 x i1>, ptr %4459, align 1
  %4462 = select i1 %4436, <8 x i1> %693, <8 x i1> %4460
  store <8 x i1> %4462, ptr %4458, align 1
  %4463 = select i1 %4436, <8 x i1> zeroinitializer, <8 x i1> %4461
  store <8 x i1> %4463, ptr %4459, align 1
  %4464 = add i32 %4443, 1
  %4465 = select i1 %4434, i32 %4421, i32 %4464
  %4466 = select i1 true, i32 %4465, i32 %4421
  store i32 %4466, ptr %current.token, align 4
  %4467 = load i32, ptr %current.token, align 4
  %4468 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %700)
  %4469 = load i32, ptr %ready.count, align 4
  %4470 = icmp uge i32 %4469, 8
  %4471 = and i1 %4468, %4470
  br i1 %4471, label %ready.overflow.trap703, label %ready.overflow.resume704

ready.overflow.trap703:                           ; preds = %convergence.overflow.resume702
  call void @llvm.trap()
  unreachable

ready.overflow.resume704:                         ; preds = %convergence.overflow.resume702
  %4472 = select i1 %4468, i32 %4469, i32 0
  %4473 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4472
  %4474 = load <8 x i1>, ptr %4473, align 1
  %4475 = select i1 %4468, <8 x i1> %700, <8 x i1> %4474
  store <8 x i1> %4475, ptr %4473, align 1
  %4476 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4472
  %4477 = load i32, ptr %4476, align 4
  %4478 = select i1 %4468, i32 31, i32 %4477
  store i32 %4478, ptr %4476, align 4
  %4479 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4472
  %4480 = load i32, ptr %4479, align 4
  %4481 = select i1 %4468, i32 %4467, i32 %4480
  store i32 %4481, ptr %4479, align 4
  %4482 = add i32 %4469, 1
  %4483 = select i1 %4468, i32 %4482, i32 %4469
  store i32 %4483, ptr %ready.count, align 4
  %4484 = load <8 x i1>, ptr %runnable.mask, align 1
  %4485 = or <8 x i1> %4484, %700
  store <8 x i1> %4485, ptr %runnable.mask, align 1
  store <8 x i1> %702, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true705:                         ; preds = %varying.coherent700
  store <8 x i1> %693, ptr %current.mask, align 1
  %4486 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %693)
  br i1 %4486, label %schedule.31, label %scheduler.loop

varying.coherent.false706:                        ; preds = %varying.coherent700
  store <8 x i1> %693, ptr %current.mask, align 1
  %4487 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %693)
  br i1 %4487, label %schedule.34, label %scheduler.loop

varying.divergent713:                             ; preds = %schedule.31
  %4488 = load i32, ptr %current.token, align 4
  %4489 = icmp ne i32 %4488, 0
  %4490 = sub i32 %4488, 1
  %4491 = select i1 %4489, i32 %4490, i32 0
  %4492 = load i8, ptr %frame.active, align 1
  %4493 = trunc i32 %4491 to i8
  %4494 = shl i8 1, %4493
  %4495 = and i8 %4492, %4494
  %4496 = icmp ne i8 %4495, 0
  %4497 = load <8 x i32>, ptr %frame.static.id, align 32
  %4498 = extractelement <8 x i32> %4497, i32 %4491
  %4499 = icmp eq i32 %4498, 12
  %4500 = and i1 %4496, %4499
  %4501 = and i1 %4489, %4500
  %4502 = xor i1 %4501, true
  %4503 = and i1 true, %4502
  %4504 = xor i8 %4492, -1
  %4505 = icmp ne i8 %4504, 0
  %4506 = xor i1 %4505, true
  %4507 = and i1 %4503, %4506
  br i1 %4507, label %convergence.overflow.trap715, label %convergence.overflow.resume716

varying.coherent714:                              ; preds = %schedule.31
  br i1 %745, label %varying.coherent.true719, label %varying.coherent.false720

convergence.overflow.trap715:                     ; preds = %varying.divergent713
  call void @llvm.trap()
  unreachable

convergence.overflow.resume716:                   ; preds = %varying.divergent713
  %4508 = call i8 @llvm.cttz.i8(i8 %4504, i1 false)
  %4509 = zext i8 %4508 to i32
  %4510 = select i1 %4505, i32 %4509, i32 0
  %4511 = trunc i32 %4510 to i8
  %4512 = shl i8 1, %4511
  %4513 = or i8 %4492, %4512
  %4514 = select i1 %4503, i8 %4513, i8 %4492
  store i8 %4514, ptr %frame.active, align 1
  %4515 = load <8 x i32>, ptr %frame.static.id, align 32
  %4516 = extractelement <8 x i32> %4515, i32 %4510
  %4517 = select i1 %4503, i32 12, i32 %4516
  %4518 = load <8 x i32>, ptr %frame.static.id, align 32
  %4519 = insertelement <8 x i32> %4518, i32 %4517, i32 %4510
  store <8 x i32> %4519, ptr %frame.static.id, align 32
  %4520 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4521 = extractelement <8 x i32> %4520, i32 %4510
  %4522 = select i1 %4503, i32 %4488, i32 %4521
  %4523 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4524 = insertelement <8 x i32> %4523, i32 %4522, i32 %4510
  store <8 x i32> %4524, ptr %frame.parent.token, align 32
  %4525 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4510
  %4526 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4510
  %4527 = load <8 x i1>, ptr %4525, align 1
  %4528 = load <8 x i1>, ptr %4526, align 1
  %4529 = select i1 %4503, <8 x i1> %706, <8 x i1> %4527
  store <8 x i1> %4529, ptr %4525, align 1
  %4530 = select i1 %4503, <8 x i1> zeroinitializer, <8 x i1> %4528
  store <8 x i1> %4530, ptr %4526, align 1
  %4531 = add i32 %4510, 1
  %4532 = select i1 %4501, i32 %4488, i32 %4531
  %4533 = select i1 true, i32 %4532, i32 %4488
  store i32 %4533, ptr %current.token, align 4
  %4534 = load <8 x float>, ptr %.slot86, align 32
  %4535 = select <8 x i1> %744, <8 x float> zeroinitializer, <8 x float> %4534
  store <8 x float> %4535, ptr %.slot86, align 32
  %4536 = load i32, ptr %current.token, align 4
  %4537 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %742)
  %4538 = load i32, ptr %ready.count, align 4
  %4539 = icmp uge i32 %4538, 8
  %4540 = and i1 %4537, %4539
  br i1 %4540, label %ready.overflow.trap717, label %ready.overflow.resume718

ready.overflow.trap717:                           ; preds = %convergence.overflow.resume716
  call void @llvm.trap()
  unreachable

ready.overflow.resume718:                         ; preds = %convergence.overflow.resume716
  %4541 = select i1 %4537, i32 %4538, i32 0
  %4542 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4541
  %4543 = load <8 x i1>, ptr %4542, align 1
  %4544 = select i1 %4537, <8 x i1> %742, <8 x i1> %4543
  store <8 x i1> %4544, ptr %4542, align 1
  %4545 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4541
  %4546 = load i32, ptr %4545, align 4
  %4547 = select i1 %4537, i32 32, i32 %4546
  store i32 %4547, ptr %4545, align 4
  %4548 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4541
  %4549 = load i32, ptr %4548, align 4
  %4550 = select i1 %4537, i32 %4536, i32 %4549
  store i32 %4550, ptr %4548, align 4
  %4551 = add i32 %4538, 1
  %4552 = select i1 %4537, i32 %4551, i32 %4538
  store i32 %4552, ptr %ready.count, align 4
  %4553 = load <8 x i1>, ptr %runnable.mask, align 1
  %4554 = or <8 x i1> %4553, %742
  store <8 x i1> %4554, ptr %runnable.mask, align 1
  store <8 x i1> %744, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true719:                         ; preds = %varying.coherent714
  store <8 x i1> %706, ptr %current.mask, align 1
  %4555 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %706)
  br i1 %4555, label %schedule.32, label %scheduler.loop

varying.coherent.false720:                        ; preds = %varying.coherent714
  %4556 = load <8 x float>, ptr %.slot86, align 32
  %4557 = select <8 x i1> %706, <8 x float> zeroinitializer, <8 x float> %4556
  store <8 x float> %4557, ptr %.slot86, align 32
  store <8 x i1> %706, ptr %current.mask, align 1
  %4558 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %706)
  br i1 %4558, label %schedule.33, label %scheduler.loop

convergence.cascade723:                           ; preds = %convergence.cascade723, %schedule.33
  %convergence.cascade.flow727 = phi <8 x i1> [ %767, %schedule.33 ], [ %4601, %convergence.cascade723 ]
  %convergence.cascade.depth728 = phi i32 [ 0, %schedule.33 ], [ %4602, %convergence.cascade723 ]
  %4559 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow727)
  %4560 = load i32, ptr %current.token, align 4
  %4561 = icmp ne i32 %4560, 0
  %4562 = and i1 %4559, %4561
  %4563 = sub i32 %4560, 1
  %4564 = select i1 %4562, i32 %4563, i32 0
  %4565 = load i8, ptr %frame.active, align 1
  %4566 = trunc i32 %4564 to i8
  %4567 = shl i8 1, %4566
  %4568 = and i8 %4565, %4567
  %4569 = icmp ne i8 %4568, 0
  %4570 = load <8 x i32>, ptr %frame.static.id, align 32
  %4571 = extractelement <8 x i32> %4570, i32 %4564
  %convergence.target.pointer729 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %4571
  %convergence.dynamic.target730 = load i32, ptr %convergence.target.pointer729, align 4
  %4572 = icmp eq i32 %convergence.dynamic.target730, 33
  %4573 = and i1 %4569, %4572
  %4574 = and i1 %4562, %4573
  %4575 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4564
  %4576 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4564
  %4577 = load <8 x i1>, ptr %4575, align 1
  %4578 = load <8 x i1>, ptr %4576, align 1
  %4579 = or <8 x i1> %4578, %convergence.cascade.flow727
  %4580 = load <8 x i1>, ptr %live.mask, align 1
  %4581 = and <8 x i1> %4577, %4580
  %4582 = icmp eq <8 x i1> %4579, %4581
  %4583 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4582)
  %4584 = and i1 %4574, %4583
  %4585 = select i1 %4584, <8 x i1> zeroinitializer, <8 x i1> %4579
  %4586 = select i1 %4574, <8 x i1> %4585, <8 x i1> %4578
  store <8 x i1> %4586, ptr %4576, align 1
  %4587 = select i1 %4584, <8 x i1> zeroinitializer, <8 x i1> %4577
  store <8 x i1> %4587, ptr %4575, align 1
  %4588 = trunc i32 %4564 to i8
  %4589 = shl i8 1, %4588
  %4590 = xor i8 %4589, -1
  %4591 = and i8 %4565, %4590
  %4592 = select i1 %4584, i8 %4591, i8 %4565
  store i8 %4592, ptr %frame.active, align 1
  %.splatinsert731 = insertelement <8 x i1> poison, i1 %4574, i64 0
  %.splat732 = shufflevector <8 x i1> %.splatinsert731, <8 x i1> poison, <8 x i32> zeroinitializer
  %4593 = and <8 x i1> %convergence.cascade.flow727, %.splat732
  %4594 = load <8 x i1>, ptr %runnable.mask, align 1
  %4595 = xor <8 x i1> %4593, splat (i1 true)
  %4596 = and <8 x i1> %4594, %4595
  store <8 x i1> %4596, ptr %runnable.mask, align 1
  %.splatinsert733 = insertelement <8 x i1> poison, i1 %4584, i64 0
  %.splat734 = shufflevector <8 x i1> %.splatinsert733, <8 x i1> poison, <8 x i32> zeroinitializer
  %4597 = select <8 x i1> %.splat734, <8 x i1> %4579, <8 x i1> zeroinitializer
  %4598 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4599 = extractelement <8 x i32> %4598, i32 %4564
  %4600 = select i1 %4584, i32 %4599, i32 %4560
  store i32 %4600, ptr %current.token, align 4
  %.splatinsert735 = insertelement <8 x i1> poison, i1 %4574, i64 0
  %.splat736 = shufflevector <8 x i1> %.splatinsert735, <8 x i1> poison, <8 x i32> zeroinitializer
  %4601 = select <8 x i1> %.splat736, <8 x i1> %4597, <8 x i1> %convergence.cascade.flow727
  %4602 = add i32 %convergence.cascade.depth728, 1
  %4603 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4601)
  %4604 = icmp ult i32 %4602, 8
  %4605 = and i1 %4603, %4604
  %4606 = and i1 %4574, %4605
  %convergence.parent.token737 = load i32, ptr %current.token, align 4
  %convergence.parent.present738 = icmp ne i32 %convergence.parent.token737, 0
  %4607 = and i1 %4606, %convergence.parent.present738
  br i1 %4607, label %convergence.cascade723, label %convergence.cascade.exit724

convergence.cascade.exit724:                      ; preds = %convergence.cascade723, %schedule.33
  %convergence.cascade.result739 = phi <8 x i1> [ %767, %schedule.33 ], [ %4601, %convergence.cascade723 ]
  %4608 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result739)
  br i1 %4608, label %convergence.target.33.ready, label %scheduler.loop

convergence.target.33.ready:                      ; preds = %convergence.cascade.exit724
  %4609 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result739)
  %4610 = bitcast <8 x i1> %convergence.cascade.result739 to i8
  %4611 = call i8 @llvm.cttz.i8(i8 %4610, i1 false)
  %4612 = zext i8 %4611 to i32
  %4613 = select i1 %4609, i32 %4612, i32 0
  %.spill.load740 = load float, ptr %.spill49, align 4
  %.splatinsert741 = insertelement <8 x float> poison, float %.spill.load740, i64 0
  %.splat742 = shufflevector <8 x float> %.splatinsert741, <8 x float> poison, <8 x i32> zeroinitializer
  %.state743 = load <8 x float>, ptr %.slot86, align 32
  %.spill.load744 = load volatile <8 x i1>, ptr %.spill84, align 1
  %4614 = select <8 x i1> %.spill.load744, <8 x float> %.state743, <8 x float> %.splat742
  %tile_snapshot.spill.load745 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill82, align 64
  %4615 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load745, 0
  %4616 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load745, 1
  %.state746 = load <8 x i64>, ptr %.slot83, align 64
  %4617 = mul <8 x i64> %.state746, splat (i64 32)
  %4618 = add <8 x i64> %4616, %4617
  %4619 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4615, 0
  %4620 = insertvalue { <8 x ptr>, <8 x i64> } %4619, <8 x i64> %4618, 1
  %4621 = extractvalue { <8 x ptr>, <8 x i64> } %4620, 0
  %4622 = extractvalue { <8 x ptr>, <8 x i64> } %4620, 1
  %4623 = getelementptr i8, <8 x ptr> %4621, <8 x i64> %4622
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %4614, <8 x ptr> %4623, i32 1, <8 x i1> %convergence.cascade.result739)
  %.state747 = load <8 x i64>, ptr %.slot83, align 64
  %4624 = add <8 x i64> %.state747, splat (i64 1)
  %4625 = load <8 x i64>, ptr %.slot83, align 64
  %4626 = select <8 x i1> %convergence.cascade.result739, <8 x i64> %4624, <8 x i64> %4625
  store <8 x i64> %4626, ptr %.slot83, align 64
  store <8 x i1> %convergence.cascade.result739, ptr %current.mask, align 1
  %4627 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result739)
  br i1 %4627, label %schedule.30, label %scheduler.loop

convergence.cascade748:                           ; preds = %convergence.cascade748, %schedule.34
  %convergence.cascade.flow752 = phi <8 x i1> [ %768, %schedule.34 ], [ %4670, %convergence.cascade748 ]
  %convergence.cascade.depth753 = phi i32 [ 0, %schedule.34 ], [ %4671, %convergence.cascade748 ]
  %4628 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow752)
  %4629 = load i32, ptr %current.token, align 4
  %4630 = icmp ne i32 %4629, 0
  %4631 = and i1 %4628, %4630
  %4632 = sub i32 %4629, 1
  %4633 = select i1 %4631, i32 %4632, i32 0
  %4634 = load i8, ptr %frame.active, align 1
  %4635 = trunc i32 %4633 to i8
  %4636 = shl i8 1, %4635
  %4637 = and i8 %4634, %4636
  %4638 = icmp ne i8 %4637, 0
  %4639 = load <8 x i32>, ptr %frame.static.id, align 32
  %4640 = extractelement <8 x i32> %4639, i32 %4633
  %convergence.target.pointer754 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %4640
  %convergence.dynamic.target755 = load i32, ptr %convergence.target.pointer754, align 4
  %4641 = icmp eq i32 %convergence.dynamic.target755, 34
  %4642 = and i1 %4638, %4641
  %4643 = and i1 %4631, %4642
  %4644 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4633
  %4645 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4633
  %4646 = load <8 x i1>, ptr %4644, align 1
  %4647 = load <8 x i1>, ptr %4645, align 1
  %4648 = or <8 x i1> %4647, %convergence.cascade.flow752
  %4649 = load <8 x i1>, ptr %live.mask, align 1
  %4650 = and <8 x i1> %4646, %4649
  %4651 = icmp eq <8 x i1> %4648, %4650
  %4652 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4651)
  %4653 = and i1 %4643, %4652
  %4654 = select i1 %4653, <8 x i1> zeroinitializer, <8 x i1> %4648
  %4655 = select i1 %4643, <8 x i1> %4654, <8 x i1> %4647
  store <8 x i1> %4655, ptr %4645, align 1
  %4656 = select i1 %4653, <8 x i1> zeroinitializer, <8 x i1> %4646
  store <8 x i1> %4656, ptr %4644, align 1
  %4657 = trunc i32 %4633 to i8
  %4658 = shl i8 1, %4657
  %4659 = xor i8 %4658, -1
  %4660 = and i8 %4634, %4659
  %4661 = select i1 %4653, i8 %4660, i8 %4634
  store i8 %4661, ptr %frame.active, align 1
  %.splatinsert756 = insertelement <8 x i1> poison, i1 %4643, i64 0
  %.splat757 = shufflevector <8 x i1> %.splatinsert756, <8 x i1> poison, <8 x i32> zeroinitializer
  %4662 = and <8 x i1> %convergence.cascade.flow752, %.splat757
  %4663 = load <8 x i1>, ptr %runnable.mask, align 1
  %4664 = xor <8 x i1> %4662, splat (i1 true)
  %4665 = and <8 x i1> %4663, %4664
  store <8 x i1> %4665, ptr %runnable.mask, align 1
  %.splatinsert758 = insertelement <8 x i1> poison, i1 %4653, i64 0
  %.splat759 = shufflevector <8 x i1> %.splatinsert758, <8 x i1> poison, <8 x i32> zeroinitializer
  %4666 = select <8 x i1> %.splat759, <8 x i1> %4648, <8 x i1> zeroinitializer
  %4667 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4668 = extractelement <8 x i32> %4667, i32 %4633
  %4669 = select i1 %4653, i32 %4668, i32 %4629
  store i32 %4669, ptr %current.token, align 4
  %.splatinsert760 = insertelement <8 x i1> poison, i1 %4643, i64 0
  %.splat761 = shufflevector <8 x i1> %.splatinsert760, <8 x i1> poison, <8 x i32> zeroinitializer
  %4670 = select <8 x i1> %.splat761, <8 x i1> %4666, <8 x i1> %convergence.cascade.flow752
  %4671 = add i32 %convergence.cascade.depth753, 1
  %4672 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4670)
  %4673 = icmp ult i32 %4671, 8
  %4674 = and i1 %4672, %4673
  %4675 = and i1 %4643, %4674
  %convergence.parent.token762 = load i32, ptr %current.token, align 4
  %convergence.parent.present763 = icmp ne i32 %convergence.parent.token762, 0
  %4676 = and i1 %4675, %convergence.parent.present763
  br i1 %4676, label %convergence.cascade748, label %convergence.cascade.exit749

convergence.cascade.exit749:                      ; preds = %convergence.cascade748, %schedule.34
  %convergence.cascade.result764 = phi <8 x i1> [ %768, %schedule.34 ], [ %4670, %convergence.cascade748 ]
  %4677 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result764)
  br i1 %4677, label %convergence.target.34.ready, label %scheduler.loop

convergence.target.34.ready:                      ; preds = %convergence.cascade.exit749
  %4678 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result764)
  %4679 = bitcast <8 x i1> %convergence.cascade.result764 to i8
  %4680 = call i8 @llvm.cttz.i8(i8 %4679, i1 false)
  %4681 = zext i8 %4680 to i32
  %4682 = select i1 %4678, i32 %4681, i32 0
  %4683 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4684 = extractvalue { <8 x ptr>, <8 x i64> } %27, 0
  %4685 = extractvalue { <8 x ptr>, <8 x i64> } %4683, 0
  %4686 = select <8 x i1> %convergence.cascade.result764, <8 x ptr> %4684, <8 x ptr> %4685
  %4687 = extractvalue { <8 x ptr>, <8 x i64> } %27, 1
  %4688 = extractvalue { <8 x ptr>, <8 x i64> } %4683, 1
  %4689 = select <8 x i1> %convergence.cascade.result764, <8 x i64> %4687, <8 x i64> %4688
  %4690 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4686, 0
  %4691 = insertvalue { <8 x ptr>, <8 x i64> } %4690, <8 x i64> %4689, 1
  store volatile { <8 x ptr>, <8 x i64> } %4691, ptr %tile_snapshot.spill87, align 64
  %4692 = load <8 x i64>, ptr %.slot88, align 64
  %4693 = select <8 x i1> %convergence.cascade.result764, <8 x i64> zeroinitializer, <8 x i64> %4692
  store <8 x i64> %4693, ptr %.slot88, align 64
  store <8 x i1> %convergence.cascade.result764, ptr %current.mask, align 1
  %4694 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result764)
  br i1 %4694, label %schedule.35, label %scheduler.loop

varying.divergent766:                             ; preds = %schedule.35
  %4695 = load i32, ptr %current.token, align 4
  %4696 = icmp ne i32 %4695, 0
  %4697 = sub i32 %4695, 1
  %4698 = select i1 %4696, i32 %4697, i32 0
  %4699 = load i8, ptr %frame.active, align 1
  %4700 = trunc i32 %4698 to i8
  %4701 = shl i8 1, %4700
  %4702 = and i8 %4699, %4701
  %4703 = icmp ne i8 %4702, 0
  %4704 = load <8 x i32>, ptr %frame.static.id, align 32
  %4705 = extractelement <8 x i32> %4704, i32 %4698
  %4706 = icmp eq i32 %4705, 13
  %4707 = and i1 %4703, %4706
  %4708 = and i1 %4696, %4707
  %4709 = xor i1 %4708, true
  %4710 = and i1 true, %4709
  %4711 = xor i8 %4699, -1
  %4712 = icmp ne i8 %4711, 0
  %4713 = xor i1 %4712, true
  %4714 = and i1 %4710, %4713
  br i1 %4714, label %convergence.overflow.trap768, label %convergence.overflow.resume769

varying.coherent767:                              ; preds = %schedule.35
  br i1 %779, label %varying.coherent.true772, label %varying.coherent.false773

convergence.overflow.trap768:                     ; preds = %varying.divergent766
  call void @llvm.trap()
  unreachable

convergence.overflow.resume769:                   ; preds = %varying.divergent766
  %4715 = call i8 @llvm.cttz.i8(i8 %4711, i1 false)
  %4716 = zext i8 %4715 to i32
  %4717 = select i1 %4712, i32 %4716, i32 0
  %4718 = trunc i32 %4717 to i8
  %4719 = shl i8 1, %4718
  %4720 = or i8 %4699, %4719
  %4721 = select i1 %4710, i8 %4720, i8 %4699
  store i8 %4721, ptr %frame.active, align 1
  %4722 = load <8 x i32>, ptr %frame.static.id, align 32
  %4723 = extractelement <8 x i32> %4722, i32 %4717
  %4724 = select i1 %4710, i32 13, i32 %4723
  %4725 = load <8 x i32>, ptr %frame.static.id, align 32
  %4726 = insertelement <8 x i32> %4725, i32 %4724, i32 %4717
  store <8 x i32> %4726, ptr %frame.static.id, align 32
  %4727 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4728 = extractelement <8 x i32> %4727, i32 %4717
  %4729 = select i1 %4710, i32 %4695, i32 %4728
  %4730 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4731 = insertelement <8 x i32> %4730, i32 %4729, i32 %4717
  store <8 x i32> %4731, ptr %frame.parent.token, align 32
  %4732 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4717
  %4733 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4717
  %4734 = load <8 x i1>, ptr %4732, align 1
  %4735 = load <8 x i1>, ptr %4733, align 1
  %4736 = select i1 %4710, <8 x i1> %769, <8 x i1> %4734
  store <8 x i1> %4736, ptr %4732, align 1
  %4737 = select i1 %4710, <8 x i1> zeroinitializer, <8 x i1> %4735
  store <8 x i1> %4737, ptr %4733, align 1
  %4738 = add i32 %4717, 1
  %4739 = select i1 %4708, i32 %4695, i32 %4738
  %4740 = select i1 true, i32 %4739, i32 %4695
  store i32 %4740, ptr %current.token, align 4
  %4741 = load i32, ptr %current.token, align 4
  %4742 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %776)
  %4743 = load i32, ptr %ready.count, align 4
  %4744 = icmp uge i32 %4743, 8
  %4745 = and i1 %4742, %4744
  br i1 %4745, label %ready.overflow.trap770, label %ready.overflow.resume771

ready.overflow.trap770:                           ; preds = %convergence.overflow.resume769
  call void @llvm.trap()
  unreachable

ready.overflow.resume771:                         ; preds = %convergence.overflow.resume769
  %4746 = select i1 %4742, i32 %4743, i32 0
  %4747 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4746
  %4748 = load <8 x i1>, ptr %4747, align 1
  %4749 = select i1 %4742, <8 x i1> %776, <8 x i1> %4748
  store <8 x i1> %4749, ptr %4747, align 1
  %4750 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4746
  %4751 = load i32, ptr %4750, align 4
  %4752 = select i1 %4742, i32 36, i32 %4751
  store i32 %4752, ptr %4750, align 4
  %4753 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4746
  %4754 = load i32, ptr %4753, align 4
  %4755 = select i1 %4742, i32 %4741, i32 %4754
  store i32 %4755, ptr %4753, align 4
  %4756 = add i32 %4743, 1
  %4757 = select i1 %4742, i32 %4756, i32 %4743
  store i32 %4757, ptr %ready.count, align 4
  %4758 = load <8 x i1>, ptr %runnable.mask, align 1
  %4759 = or <8 x i1> %4758, %776
  store <8 x i1> %4759, ptr %runnable.mask, align 1
  store <8 x i1> %778, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true772:                         ; preds = %varying.coherent767
  store <8 x i1> %769, ptr %current.mask, align 1
  %4760 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %769)
  br i1 %4760, label %schedule.36, label %scheduler.loop

varying.coherent.false773:                        ; preds = %varying.coherent767
  store <8 x i1> %769, ptr %current.mask, align 1
  %4761 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %769)
  br i1 %4761, label %schedule.37, label %scheduler.loop

convergence.cascade781:                           ; preds = %convergence.cascade781, %schedule.37
  %convergence.cascade.flow785 = phi <8 x i1> [ %831, %schedule.37 ], [ %4804, %convergence.cascade781 ]
  %convergence.cascade.depth786 = phi i32 [ 0, %schedule.37 ], [ %4805, %convergence.cascade781 ]
  %4762 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow785)
  %4763 = load i32, ptr %current.token, align 4
  %4764 = icmp ne i32 %4763, 0
  %4765 = and i1 %4762, %4764
  %4766 = sub i32 %4763, 1
  %4767 = select i1 %4765, i32 %4766, i32 0
  %4768 = load i8, ptr %frame.active, align 1
  %4769 = trunc i32 %4767 to i8
  %4770 = shl i8 1, %4769
  %4771 = and i8 %4768, %4770
  %4772 = icmp ne i8 %4771, 0
  %4773 = load <8 x i32>, ptr %frame.static.id, align 32
  %4774 = extractelement <8 x i32> %4773, i32 %4767
  %convergence.target.pointer787 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %4774
  %convergence.dynamic.target788 = load i32, ptr %convergence.target.pointer787, align 4
  %4775 = icmp eq i32 %convergence.dynamic.target788, 37
  %4776 = and i1 %4772, %4775
  %4777 = and i1 %4765, %4776
  %4778 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4767
  %4779 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4767
  %4780 = load <8 x i1>, ptr %4778, align 1
  %4781 = load <8 x i1>, ptr %4779, align 1
  %4782 = or <8 x i1> %4781, %convergence.cascade.flow785
  %4783 = load <8 x i1>, ptr %live.mask, align 1
  %4784 = and <8 x i1> %4780, %4783
  %4785 = icmp eq <8 x i1> %4782, %4784
  %4786 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4785)
  %4787 = and i1 %4777, %4786
  %4788 = select i1 %4787, <8 x i1> zeroinitializer, <8 x i1> %4782
  %4789 = select i1 %4777, <8 x i1> %4788, <8 x i1> %4781
  store <8 x i1> %4789, ptr %4779, align 1
  %4790 = select i1 %4787, <8 x i1> zeroinitializer, <8 x i1> %4780
  store <8 x i1> %4790, ptr %4778, align 1
  %4791 = trunc i32 %4767 to i8
  %4792 = shl i8 1, %4791
  %4793 = xor i8 %4792, -1
  %4794 = and i8 %4768, %4793
  %4795 = select i1 %4787, i8 %4794, i8 %4768
  store i8 %4795, ptr %frame.active, align 1
  %.splatinsert789 = insertelement <8 x i1> poison, i1 %4777, i64 0
  %.splat790 = shufflevector <8 x i1> %.splatinsert789, <8 x i1> poison, <8 x i32> zeroinitializer
  %4796 = and <8 x i1> %convergence.cascade.flow785, %.splat790
  %4797 = load <8 x i1>, ptr %runnable.mask, align 1
  %4798 = xor <8 x i1> %4796, splat (i1 true)
  %4799 = and <8 x i1> %4797, %4798
  store <8 x i1> %4799, ptr %runnable.mask, align 1
  %.splatinsert791 = insertelement <8 x i1> poison, i1 %4787, i64 0
  %.splat792 = shufflevector <8 x i1> %.splatinsert791, <8 x i1> poison, <8 x i32> zeroinitializer
  %4800 = select <8 x i1> %.splat792, <8 x i1> %4782, <8 x i1> zeroinitializer
  %4801 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4802 = extractelement <8 x i32> %4801, i32 %4767
  %4803 = select i1 %4787, i32 %4802, i32 %4763
  store i32 %4803, ptr %current.token, align 4
  %.splatinsert793 = insertelement <8 x i1> poison, i1 %4777, i64 0
  %.splat794 = shufflevector <8 x i1> %.splatinsert793, <8 x i1> poison, <8 x i32> zeroinitializer
  %4804 = select <8 x i1> %.splat794, <8 x i1> %4800, <8 x i1> %convergence.cascade.flow785
  %4805 = add i32 %convergence.cascade.depth786, 1
  %4806 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4804)
  %4807 = icmp ult i32 %4805, 8
  %4808 = and i1 %4806, %4807
  %4809 = and i1 %4777, %4808
  %convergence.parent.token795 = load i32, ptr %current.token, align 4
  %convergence.parent.present796 = icmp ne i32 %convergence.parent.token795, 0
  %4810 = and i1 %4809, %convergence.parent.present796
  br i1 %4810, label %convergence.cascade781, label %convergence.cascade.exit782

convergence.cascade.exit782:                      ; preds = %convergence.cascade781, %schedule.37
  %convergence.cascade.result797 = phi <8 x i1> [ %831, %schedule.37 ], [ %4804, %convergence.cascade781 ]
  %4811 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  br i1 %4811, label %convergence.target.37.ready, label %scheduler.loop

convergence.target.37.ready:                      ; preds = %convergence.cascade.exit782
  %4812 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %4813 = bitcast <8 x i1> %convergence.cascade.result797 to i8
  %4814 = call i8 @llvm.cttz.i8(i8 %4813, i1 false)
  %4815 = zext i8 %4814 to i32
  %4816 = select i1 %4812, i32 %4815, i32 0
  %4817 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill89, align 64
  %4818 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4819 = extractvalue { <8 x ptr>, <8 x i64> } %4817, 0
  %4820 = select <8 x i1> %convergence.cascade.result797, <8 x ptr> %4818, <8 x ptr> %4819
  %4821 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %4822 = extractvalue { <8 x ptr>, <8 x i64> } %4817, 1
  %4823 = select <8 x i1> %convergence.cascade.result797, <8 x i64> %4821, <8 x i64> %4822
  %4824 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4820, 0
  %4825 = insertvalue { <8 x ptr>, <8 x i64> } %4824, <8 x i64> %4823, 1
  store volatile { <8 x ptr>, <8 x i64> } %4825, ptr %tile_snapshot.spill89, align 64
  %4826 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4827 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %4828 = add <8 x i64> %4827, zeroinitializer
  %4829 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4826, 0
  %4830 = insertvalue { <8 x ptr>, <8 x i64> } %4829, <8 x i64> %4828, 1
  %4831 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4832 = extractvalue { <8 x ptr>, <8 x i64> } %4830, 1
  %4833 = extractelement <8 x ptr> %4831, i32 0
  %4834 = extractelement <8 x i64> %4832, i32 %4816
  %4835 = zext i32 %4816 to i64
  %4836 = mul i64 %4835, 8
  %4837 = sub i64 %4834, %4836
  %4838 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %4839 = select i1 %4838, i64 %4837, i64 0
  %private.contiguous.address798 = getelementptr i8, ptr %4833, i64 %4839
  %private.contiguous.preserve799 = load <8 x i64>, ptr %private.contiguous.address798, align 8
  %4840 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 -16), <8 x i64> %private.contiguous.preserve799
  store <8 x i64> %4840, ptr %private.contiguous.address798, align 8
  %4841 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4842 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %4843 = add <8 x i64> %4842, splat (i64 64)
  %4844 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4841, 0
  %4845 = insertvalue { <8 x ptr>, <8 x i64> } %4844, <8 x i64> %4843, 1
  %4846 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4847 = extractvalue { <8 x ptr>, <8 x i64> } %4845, 1
  %4848 = extractelement <8 x ptr> %4846, i32 0
  %4849 = extractelement <8 x i64> %4847, i32 %4816
  %4850 = zext i32 %4816 to i64
  %4851 = mul i64 %4850, 8
  %4852 = sub i64 %4849, %4851
  %4853 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %4854 = select i1 %4853, i64 %4852, i64 0
  %private.contiguous.address800 = getelementptr i8, ptr %4848, i64 %4854
  %private.contiguous.preserve801 = load <8 x i64>, ptr %private.contiguous.address800, align 8
  %4855 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 -15), <8 x i64> %private.contiguous.preserve801
  store <8 x i64> %4855, ptr %private.contiguous.address800, align 8
  %4856 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4857 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %4858 = add <8 x i64> %4857, splat (i64 128)
  %4859 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4856, 0
  %4860 = insertvalue { <8 x ptr>, <8 x i64> } %4859, <8 x i64> %4858, 1
  %4861 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4862 = extractvalue { <8 x ptr>, <8 x i64> } %4860, 1
  %4863 = extractelement <8 x ptr> %4861, i32 0
  %4864 = extractelement <8 x i64> %4862, i32 %4816
  %4865 = zext i32 %4816 to i64
  %4866 = mul i64 %4865, 8
  %4867 = sub i64 %4864, %4866
  %4868 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %4869 = select i1 %4868, i64 %4867, i64 0
  %private.contiguous.address802 = getelementptr i8, ptr %4863, i64 %4869
  %private.contiguous.preserve803 = load <8 x i64>, ptr %private.contiguous.address802, align 8
  %4870 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 -14), <8 x i64> %private.contiguous.preserve803
  store <8 x i64> %4870, ptr %private.contiguous.address802, align 8
  %4871 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4872 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %4873 = add <8 x i64> %4872, splat (i64 192)
  %4874 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4871, 0
  %4875 = insertvalue { <8 x ptr>, <8 x i64> } %4874, <8 x i64> %4873, 1
  %4876 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4877 = extractvalue { <8 x ptr>, <8 x i64> } %4875, 1
  %4878 = extractelement <8 x ptr> %4876, i32 0
  %4879 = extractelement <8 x i64> %4877, i32 %4816
  %4880 = zext i32 %4816 to i64
  %4881 = mul i64 %4880, 8
  %4882 = sub i64 %4879, %4881
  %4883 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %4884 = select i1 %4883, i64 %4882, i64 0
  %private.contiguous.address804 = getelementptr i8, ptr %4878, i64 %4884
  %private.contiguous.preserve805 = load <8 x i64>, ptr %private.contiguous.address804, align 8
  %4885 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 -13), <8 x i64> %private.contiguous.preserve805
  store <8 x i64> %4885, ptr %private.contiguous.address804, align 8
  %4886 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4887 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %4888 = add <8 x i64> %4887, splat (i64 256)
  %4889 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4886, 0
  %4890 = insertvalue { <8 x ptr>, <8 x i64> } %4889, <8 x i64> %4888, 1
  %4891 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4892 = extractvalue { <8 x ptr>, <8 x i64> } %4890, 1
  %4893 = extractelement <8 x ptr> %4891, i32 0
  %4894 = extractelement <8 x i64> %4892, i32 %4816
  %4895 = zext i32 %4816 to i64
  %4896 = mul i64 %4895, 8
  %4897 = sub i64 %4894, %4896
  %4898 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %4899 = select i1 %4898, i64 %4897, i64 0
  %private.contiguous.address806 = getelementptr i8, ptr %4893, i64 %4899
  %private.contiguous.preserve807 = load <8 x i64>, ptr %private.contiguous.address806, align 8
  %4900 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 -12), <8 x i64> %private.contiguous.preserve807
  store <8 x i64> %4900, ptr %private.contiguous.address806, align 8
  %4901 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4902 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %4903 = add <8 x i64> %4902, splat (i64 320)
  %4904 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4901, 0
  %4905 = insertvalue { <8 x ptr>, <8 x i64> } %4904, <8 x i64> %4903, 1
  %4906 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4907 = extractvalue { <8 x ptr>, <8 x i64> } %4905, 1
  %4908 = extractelement <8 x ptr> %4906, i32 0
  %4909 = extractelement <8 x i64> %4907, i32 %4816
  %4910 = zext i32 %4816 to i64
  %4911 = mul i64 %4910, 8
  %4912 = sub i64 %4909, %4911
  %4913 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %4914 = select i1 %4913, i64 %4912, i64 0
  %private.contiguous.address808 = getelementptr i8, ptr %4908, i64 %4914
  %private.contiguous.preserve809 = load <8 x i64>, ptr %private.contiguous.address808, align 8
  %4915 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 -11), <8 x i64> %private.contiguous.preserve809
  store <8 x i64> %4915, ptr %private.contiguous.address808, align 8
  %4916 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4917 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %4918 = add <8 x i64> %4917, splat (i64 384)
  %4919 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4916, 0
  %4920 = insertvalue { <8 x ptr>, <8 x i64> } %4919, <8 x i64> %4918, 1
  %4921 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4922 = extractvalue { <8 x ptr>, <8 x i64> } %4920, 1
  %4923 = extractelement <8 x ptr> %4921, i32 0
  %4924 = extractelement <8 x i64> %4922, i32 %4816
  %4925 = zext i32 %4816 to i64
  %4926 = mul i64 %4925, 8
  %4927 = sub i64 %4924, %4926
  %4928 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %4929 = select i1 %4928, i64 %4927, i64 0
  %private.contiguous.address810 = getelementptr i8, ptr %4923, i64 %4929
  %private.contiguous.preserve811 = load <8 x i64>, ptr %private.contiguous.address810, align 8
  %4930 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 -10), <8 x i64> %private.contiguous.preserve811
  store <8 x i64> %4930, ptr %private.contiguous.address810, align 8
  %4931 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4932 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %4933 = add <8 x i64> %4932, splat (i64 448)
  %4934 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4931, 0
  %4935 = insertvalue { <8 x ptr>, <8 x i64> } %4934, <8 x i64> %4933, 1
  %4936 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4937 = extractvalue { <8 x ptr>, <8 x i64> } %4935, 1
  %4938 = extractelement <8 x ptr> %4936, i32 0
  %4939 = extractelement <8 x i64> %4937, i32 %4816
  %4940 = zext i32 %4816 to i64
  %4941 = mul i64 %4940, 8
  %4942 = sub i64 %4939, %4941
  %4943 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %4944 = select i1 %4943, i64 %4942, i64 0
  %private.contiguous.address812 = getelementptr i8, ptr %4938, i64 %4944
  %private.contiguous.preserve813 = load <8 x i64>, ptr %private.contiguous.address812, align 8
  %4945 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 -9), <8 x i64> %private.contiguous.preserve813
  store <8 x i64> %4945, ptr %private.contiguous.address812, align 8
  %4946 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4947 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %4948 = add <8 x i64> %4947, splat (i64 512)
  %4949 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4946, 0
  %4950 = insertvalue { <8 x ptr>, <8 x i64> } %4949, <8 x i64> %4948, 1
  %4951 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4952 = extractvalue { <8 x ptr>, <8 x i64> } %4950, 1
  %4953 = extractelement <8 x ptr> %4951, i32 0
  %4954 = extractelement <8 x i64> %4952, i32 %4816
  %4955 = zext i32 %4816 to i64
  %4956 = mul i64 %4955, 8
  %4957 = sub i64 %4954, %4956
  %4958 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %4959 = select i1 %4958, i64 %4957, i64 0
  %private.contiguous.address814 = getelementptr i8, ptr %4953, i64 %4959
  %private.contiguous.preserve815 = load <8 x i64>, ptr %private.contiguous.address814, align 8
  %4960 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 -8), <8 x i64> %private.contiguous.preserve815
  store <8 x i64> %4960, ptr %private.contiguous.address814, align 8
  %4961 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4962 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %4963 = add <8 x i64> %4962, splat (i64 576)
  %4964 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4961, 0
  %4965 = insertvalue { <8 x ptr>, <8 x i64> } %4964, <8 x i64> %4963, 1
  %4966 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4967 = extractvalue { <8 x ptr>, <8 x i64> } %4965, 1
  %4968 = extractelement <8 x ptr> %4966, i32 0
  %4969 = extractelement <8 x i64> %4967, i32 %4816
  %4970 = zext i32 %4816 to i64
  %4971 = mul i64 %4970, 8
  %4972 = sub i64 %4969, %4971
  %4973 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %4974 = select i1 %4973, i64 %4972, i64 0
  %private.contiguous.address816 = getelementptr i8, ptr %4968, i64 %4974
  %private.contiguous.preserve817 = load <8 x i64>, ptr %private.contiguous.address816, align 8
  %4975 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 -7), <8 x i64> %private.contiguous.preserve817
  store <8 x i64> %4975, ptr %private.contiguous.address816, align 8
  %4976 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4977 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %4978 = add <8 x i64> %4977, splat (i64 640)
  %4979 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4976, 0
  %4980 = insertvalue { <8 x ptr>, <8 x i64> } %4979, <8 x i64> %4978, 1
  %4981 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4982 = extractvalue { <8 x ptr>, <8 x i64> } %4980, 1
  %4983 = extractelement <8 x ptr> %4981, i32 0
  %4984 = extractelement <8 x i64> %4982, i32 %4816
  %4985 = zext i32 %4816 to i64
  %4986 = mul i64 %4985, 8
  %4987 = sub i64 %4984, %4986
  %4988 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %4989 = select i1 %4988, i64 %4987, i64 0
  %private.contiguous.address818 = getelementptr i8, ptr %4983, i64 %4989
  %private.contiguous.preserve819 = load <8 x i64>, ptr %private.contiguous.address818, align 8
  %4990 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 -6), <8 x i64> %private.contiguous.preserve819
  store <8 x i64> %4990, ptr %private.contiguous.address818, align 8
  %4991 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4992 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %4993 = add <8 x i64> %4992, splat (i64 704)
  %4994 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4991, 0
  %4995 = insertvalue { <8 x ptr>, <8 x i64> } %4994, <8 x i64> %4993, 1
  %4996 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4997 = extractvalue { <8 x ptr>, <8 x i64> } %4995, 1
  %4998 = extractelement <8 x ptr> %4996, i32 0
  %4999 = extractelement <8 x i64> %4997, i32 %4816
  %5000 = zext i32 %4816 to i64
  %5001 = mul i64 %5000, 8
  %5002 = sub i64 %4999, %5001
  %5003 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %5004 = select i1 %5003, i64 %5002, i64 0
  %private.contiguous.address820 = getelementptr i8, ptr %4998, i64 %5004
  %private.contiguous.preserve821 = load <8 x i64>, ptr %private.contiguous.address820, align 8
  %5005 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 -5), <8 x i64> %private.contiguous.preserve821
  store <8 x i64> %5005, ptr %private.contiguous.address820, align 8
  %5006 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5007 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5008 = add <8 x i64> %5007, splat (i64 768)
  %5009 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5006, 0
  %5010 = insertvalue { <8 x ptr>, <8 x i64> } %5009, <8 x i64> %5008, 1
  %5011 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5012 = extractvalue { <8 x ptr>, <8 x i64> } %5010, 1
  %5013 = extractelement <8 x ptr> %5011, i32 0
  %5014 = extractelement <8 x i64> %5012, i32 %4816
  %5015 = zext i32 %4816 to i64
  %5016 = mul i64 %5015, 8
  %5017 = sub i64 %5014, %5016
  %5018 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %5019 = select i1 %5018, i64 %5017, i64 0
  %private.contiguous.address822 = getelementptr i8, ptr %5013, i64 %5019
  %private.contiguous.preserve823 = load <8 x i64>, ptr %private.contiguous.address822, align 8
  %5020 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 -4), <8 x i64> %private.contiguous.preserve823
  store <8 x i64> %5020, ptr %private.contiguous.address822, align 8
  %5021 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5022 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5023 = add <8 x i64> %5022, splat (i64 832)
  %5024 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5021, 0
  %5025 = insertvalue { <8 x ptr>, <8 x i64> } %5024, <8 x i64> %5023, 1
  %5026 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5027 = extractvalue { <8 x ptr>, <8 x i64> } %5025, 1
  %5028 = extractelement <8 x ptr> %5026, i32 0
  %5029 = extractelement <8 x i64> %5027, i32 %4816
  %5030 = zext i32 %4816 to i64
  %5031 = mul i64 %5030, 8
  %5032 = sub i64 %5029, %5031
  %5033 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %5034 = select i1 %5033, i64 %5032, i64 0
  %private.contiguous.address824 = getelementptr i8, ptr %5028, i64 %5034
  %private.contiguous.preserve825 = load <8 x i64>, ptr %private.contiguous.address824, align 8
  %5035 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 -3), <8 x i64> %private.contiguous.preserve825
  store <8 x i64> %5035, ptr %private.contiguous.address824, align 8
  %5036 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5037 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5038 = add <8 x i64> %5037, splat (i64 896)
  %5039 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5036, 0
  %5040 = insertvalue { <8 x ptr>, <8 x i64> } %5039, <8 x i64> %5038, 1
  %5041 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5042 = extractvalue { <8 x ptr>, <8 x i64> } %5040, 1
  %5043 = extractelement <8 x ptr> %5041, i32 0
  %5044 = extractelement <8 x i64> %5042, i32 %4816
  %5045 = zext i32 %4816 to i64
  %5046 = mul i64 %5045, 8
  %5047 = sub i64 %5044, %5046
  %5048 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %5049 = select i1 %5048, i64 %5047, i64 0
  %private.contiguous.address826 = getelementptr i8, ptr %5043, i64 %5049
  %private.contiguous.preserve827 = load <8 x i64>, ptr %private.contiguous.address826, align 8
  %5050 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 -2), <8 x i64> %private.contiguous.preserve827
  store <8 x i64> %5050, ptr %private.contiguous.address826, align 8
  %5051 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5052 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5053 = add <8 x i64> %5052, splat (i64 960)
  %5054 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5051, 0
  %5055 = insertvalue { <8 x ptr>, <8 x i64> } %5054, <8 x i64> %5053, 1
  %5056 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5057 = extractvalue { <8 x ptr>, <8 x i64> } %5055, 1
  %5058 = extractelement <8 x ptr> %5056, i32 0
  %5059 = extractelement <8 x i64> %5057, i32 %4816
  %5060 = zext i32 %4816 to i64
  %5061 = mul i64 %5060, 8
  %5062 = sub i64 %5059, %5061
  %5063 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %5064 = select i1 %5063, i64 %5062, i64 0
  %private.contiguous.address828 = getelementptr i8, ptr %5058, i64 %5064
  %private.contiguous.preserve829 = load <8 x i64>, ptr %private.contiguous.address828, align 8
  %5065 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 -1), <8 x i64> %private.contiguous.preserve829
  store <8 x i64> %5065, ptr %private.contiguous.address828, align 8
  %5066 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5067 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5068 = add <8 x i64> %5067, splat (i64 1024)
  %5069 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5066, 0
  %5070 = insertvalue { <8 x ptr>, <8 x i64> } %5069, <8 x i64> %5068, 1
  %5071 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5072 = extractvalue { <8 x ptr>, <8 x i64> } %5070, 1
  %5073 = extractelement <8 x ptr> %5071, i32 0
  %5074 = extractelement <8 x i64> %5072, i32 %4816
  %5075 = zext i32 %4816 to i64
  %5076 = mul i64 %5075, 8
  %5077 = sub i64 %5074, %5076
  %5078 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %5079 = select i1 %5078, i64 %5077, i64 0
  %private.contiguous.address830 = getelementptr i8, ptr %5073, i64 %5079
  %private.contiguous.preserve831 = load <8 x i64>, ptr %private.contiguous.address830, align 8
  %5080 = select <8 x i1> %convergence.cascade.result797, <8 x i64> zeroinitializer, <8 x i64> %private.contiguous.preserve831
  store <8 x i64> %5080, ptr %private.contiguous.address830, align 8
  %5081 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5082 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5083 = add <8 x i64> %5082, splat (i64 1088)
  %5084 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5081, 0
  %5085 = insertvalue { <8 x ptr>, <8 x i64> } %5084, <8 x i64> %5083, 1
  %5086 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5087 = extractvalue { <8 x ptr>, <8 x i64> } %5085, 1
  %5088 = extractelement <8 x ptr> %5086, i32 0
  %5089 = extractelement <8 x i64> %5087, i32 %4816
  %5090 = zext i32 %4816 to i64
  %5091 = mul i64 %5090, 8
  %5092 = sub i64 %5089, %5091
  %5093 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %5094 = select i1 %5093, i64 %5092, i64 0
  %private.contiguous.address832 = getelementptr i8, ptr %5088, i64 %5094
  %private.contiguous.preserve833 = load <8 x i64>, ptr %private.contiguous.address832, align 8
  %5095 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 1), <8 x i64> %private.contiguous.preserve833
  store <8 x i64> %5095, ptr %private.contiguous.address832, align 8
  %5096 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5097 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5098 = add <8 x i64> %5097, splat (i64 1152)
  %5099 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5096, 0
  %5100 = insertvalue { <8 x ptr>, <8 x i64> } %5099, <8 x i64> %5098, 1
  %5101 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5102 = extractvalue { <8 x ptr>, <8 x i64> } %5100, 1
  %5103 = extractelement <8 x ptr> %5101, i32 0
  %5104 = extractelement <8 x i64> %5102, i32 %4816
  %5105 = zext i32 %4816 to i64
  %5106 = mul i64 %5105, 8
  %5107 = sub i64 %5104, %5106
  %5108 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %5109 = select i1 %5108, i64 %5107, i64 0
  %private.contiguous.address834 = getelementptr i8, ptr %5103, i64 %5109
  %private.contiguous.preserve835 = load <8 x i64>, ptr %private.contiguous.address834, align 8
  %5110 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 2), <8 x i64> %private.contiguous.preserve835
  store <8 x i64> %5110, ptr %private.contiguous.address834, align 8
  %5111 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5112 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5113 = add <8 x i64> %5112, splat (i64 1216)
  %5114 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5111, 0
  %5115 = insertvalue { <8 x ptr>, <8 x i64> } %5114, <8 x i64> %5113, 1
  %5116 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5117 = extractvalue { <8 x ptr>, <8 x i64> } %5115, 1
  %5118 = extractelement <8 x ptr> %5116, i32 0
  %5119 = extractelement <8 x i64> %5117, i32 %4816
  %5120 = zext i32 %4816 to i64
  %5121 = mul i64 %5120, 8
  %5122 = sub i64 %5119, %5121
  %5123 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %5124 = select i1 %5123, i64 %5122, i64 0
  %private.contiguous.address836 = getelementptr i8, ptr %5118, i64 %5124
  %private.contiguous.preserve837 = load <8 x i64>, ptr %private.contiguous.address836, align 8
  %5125 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 3), <8 x i64> %private.contiguous.preserve837
  store <8 x i64> %5125, ptr %private.contiguous.address836, align 8
  %5126 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5127 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5128 = add <8 x i64> %5127, splat (i64 1280)
  %5129 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5126, 0
  %5130 = insertvalue { <8 x ptr>, <8 x i64> } %5129, <8 x i64> %5128, 1
  %5131 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5132 = extractvalue { <8 x ptr>, <8 x i64> } %5130, 1
  %5133 = extractelement <8 x ptr> %5131, i32 0
  %5134 = extractelement <8 x i64> %5132, i32 %4816
  %5135 = zext i32 %4816 to i64
  %5136 = mul i64 %5135, 8
  %5137 = sub i64 %5134, %5136
  %5138 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %5139 = select i1 %5138, i64 %5137, i64 0
  %private.contiguous.address838 = getelementptr i8, ptr %5133, i64 %5139
  %private.contiguous.preserve839 = load <8 x i64>, ptr %private.contiguous.address838, align 8
  %5140 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 4), <8 x i64> %private.contiguous.preserve839
  store <8 x i64> %5140, ptr %private.contiguous.address838, align 8
  %5141 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5142 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5143 = add <8 x i64> %5142, splat (i64 1344)
  %5144 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5141, 0
  %5145 = insertvalue { <8 x ptr>, <8 x i64> } %5144, <8 x i64> %5143, 1
  %5146 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5147 = extractvalue { <8 x ptr>, <8 x i64> } %5145, 1
  %5148 = extractelement <8 x ptr> %5146, i32 0
  %5149 = extractelement <8 x i64> %5147, i32 %4816
  %5150 = zext i32 %4816 to i64
  %5151 = mul i64 %5150, 8
  %5152 = sub i64 %5149, %5151
  %5153 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %5154 = select i1 %5153, i64 %5152, i64 0
  %private.contiguous.address840 = getelementptr i8, ptr %5148, i64 %5154
  %private.contiguous.preserve841 = load <8 x i64>, ptr %private.contiguous.address840, align 8
  %5155 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 5), <8 x i64> %private.contiguous.preserve841
  store <8 x i64> %5155, ptr %private.contiguous.address840, align 8
  %5156 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5157 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5158 = add <8 x i64> %5157, splat (i64 1408)
  %5159 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5156, 0
  %5160 = insertvalue { <8 x ptr>, <8 x i64> } %5159, <8 x i64> %5158, 1
  %5161 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5162 = extractvalue { <8 x ptr>, <8 x i64> } %5160, 1
  %5163 = extractelement <8 x ptr> %5161, i32 0
  %5164 = extractelement <8 x i64> %5162, i32 %4816
  %5165 = zext i32 %4816 to i64
  %5166 = mul i64 %5165, 8
  %5167 = sub i64 %5164, %5166
  %5168 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %5169 = select i1 %5168, i64 %5167, i64 0
  %private.contiguous.address842 = getelementptr i8, ptr %5163, i64 %5169
  %private.contiguous.preserve843 = load <8 x i64>, ptr %private.contiguous.address842, align 8
  %5170 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 6), <8 x i64> %private.contiguous.preserve843
  store <8 x i64> %5170, ptr %private.contiguous.address842, align 8
  %5171 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5172 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5173 = add <8 x i64> %5172, splat (i64 1472)
  %5174 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5171, 0
  %5175 = insertvalue { <8 x ptr>, <8 x i64> } %5174, <8 x i64> %5173, 1
  %5176 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5177 = extractvalue { <8 x ptr>, <8 x i64> } %5175, 1
  %5178 = extractelement <8 x ptr> %5176, i32 0
  %5179 = extractelement <8 x i64> %5177, i32 %4816
  %5180 = zext i32 %4816 to i64
  %5181 = mul i64 %5180, 8
  %5182 = sub i64 %5179, %5181
  %5183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %5184 = select i1 %5183, i64 %5182, i64 0
  %private.contiguous.address844 = getelementptr i8, ptr %5178, i64 %5184
  %private.contiguous.preserve845 = load <8 x i64>, ptr %private.contiguous.address844, align 8
  %5185 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 7), <8 x i64> %private.contiguous.preserve845
  store <8 x i64> %5185, ptr %private.contiguous.address844, align 8
  %5186 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5187 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5188 = add <8 x i64> %5187, splat (i64 1536)
  %5189 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5186, 0
  %5190 = insertvalue { <8 x ptr>, <8 x i64> } %5189, <8 x i64> %5188, 1
  %5191 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5192 = extractvalue { <8 x ptr>, <8 x i64> } %5190, 1
  %5193 = extractelement <8 x ptr> %5191, i32 0
  %5194 = extractelement <8 x i64> %5192, i32 %4816
  %5195 = zext i32 %4816 to i64
  %5196 = mul i64 %5195, 8
  %5197 = sub i64 %5194, %5196
  %5198 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %5199 = select i1 %5198, i64 %5197, i64 0
  %private.contiguous.address846 = getelementptr i8, ptr %5193, i64 %5199
  %private.contiguous.preserve847 = load <8 x i64>, ptr %private.contiguous.address846, align 8
  %5200 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 8), <8 x i64> %private.contiguous.preserve847
  store <8 x i64> %5200, ptr %private.contiguous.address846, align 8
  %5201 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5202 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5203 = add <8 x i64> %5202, splat (i64 1600)
  %5204 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5201, 0
  %5205 = insertvalue { <8 x ptr>, <8 x i64> } %5204, <8 x i64> %5203, 1
  %5206 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5207 = extractvalue { <8 x ptr>, <8 x i64> } %5205, 1
  %5208 = extractelement <8 x ptr> %5206, i32 0
  %5209 = extractelement <8 x i64> %5207, i32 %4816
  %5210 = zext i32 %4816 to i64
  %5211 = mul i64 %5210, 8
  %5212 = sub i64 %5209, %5211
  %5213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %5214 = select i1 %5213, i64 %5212, i64 0
  %private.contiguous.address848 = getelementptr i8, ptr %5208, i64 %5214
  %private.contiguous.preserve849 = load <8 x i64>, ptr %private.contiguous.address848, align 8
  %5215 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 9), <8 x i64> %private.contiguous.preserve849
  store <8 x i64> %5215, ptr %private.contiguous.address848, align 8
  %5216 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5217 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5218 = add <8 x i64> %5217, splat (i64 1664)
  %5219 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5216, 0
  %5220 = insertvalue { <8 x ptr>, <8 x i64> } %5219, <8 x i64> %5218, 1
  %5221 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5222 = extractvalue { <8 x ptr>, <8 x i64> } %5220, 1
  %5223 = extractelement <8 x ptr> %5221, i32 0
  %5224 = extractelement <8 x i64> %5222, i32 %4816
  %5225 = zext i32 %4816 to i64
  %5226 = mul i64 %5225, 8
  %5227 = sub i64 %5224, %5226
  %5228 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %5229 = select i1 %5228, i64 %5227, i64 0
  %private.contiguous.address850 = getelementptr i8, ptr %5223, i64 %5229
  %private.contiguous.preserve851 = load <8 x i64>, ptr %private.contiguous.address850, align 8
  %5230 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 10), <8 x i64> %private.contiguous.preserve851
  store <8 x i64> %5230, ptr %private.contiguous.address850, align 8
  %5231 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5232 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5233 = add <8 x i64> %5232, splat (i64 1728)
  %5234 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5231, 0
  %5235 = insertvalue { <8 x ptr>, <8 x i64> } %5234, <8 x i64> %5233, 1
  %5236 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5237 = extractvalue { <8 x ptr>, <8 x i64> } %5235, 1
  %5238 = extractelement <8 x ptr> %5236, i32 0
  %5239 = extractelement <8 x i64> %5237, i32 %4816
  %5240 = zext i32 %4816 to i64
  %5241 = mul i64 %5240, 8
  %5242 = sub i64 %5239, %5241
  %5243 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %5244 = select i1 %5243, i64 %5242, i64 0
  %private.contiguous.address852 = getelementptr i8, ptr %5238, i64 %5244
  %private.contiguous.preserve853 = load <8 x i64>, ptr %private.contiguous.address852, align 8
  %5245 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 11), <8 x i64> %private.contiguous.preserve853
  store <8 x i64> %5245, ptr %private.contiguous.address852, align 8
  %5246 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5247 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5248 = add <8 x i64> %5247, splat (i64 1792)
  %5249 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5246, 0
  %5250 = insertvalue { <8 x ptr>, <8 x i64> } %5249, <8 x i64> %5248, 1
  %5251 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5252 = extractvalue { <8 x ptr>, <8 x i64> } %5250, 1
  %5253 = extractelement <8 x ptr> %5251, i32 0
  %5254 = extractelement <8 x i64> %5252, i32 %4816
  %5255 = zext i32 %4816 to i64
  %5256 = mul i64 %5255, 8
  %5257 = sub i64 %5254, %5256
  %5258 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %5259 = select i1 %5258, i64 %5257, i64 0
  %private.contiguous.address854 = getelementptr i8, ptr %5253, i64 %5259
  %private.contiguous.preserve855 = load <8 x i64>, ptr %private.contiguous.address854, align 8
  %5260 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 12), <8 x i64> %private.contiguous.preserve855
  store <8 x i64> %5260, ptr %private.contiguous.address854, align 8
  %5261 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5262 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5263 = add <8 x i64> %5262, splat (i64 1856)
  %5264 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5261, 0
  %5265 = insertvalue { <8 x ptr>, <8 x i64> } %5264, <8 x i64> %5263, 1
  %5266 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5267 = extractvalue { <8 x ptr>, <8 x i64> } %5265, 1
  %5268 = extractelement <8 x ptr> %5266, i32 0
  %5269 = extractelement <8 x i64> %5267, i32 %4816
  %5270 = zext i32 %4816 to i64
  %5271 = mul i64 %5270, 8
  %5272 = sub i64 %5269, %5271
  %5273 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %5274 = select i1 %5273, i64 %5272, i64 0
  %private.contiguous.address856 = getelementptr i8, ptr %5268, i64 %5274
  %private.contiguous.preserve857 = load <8 x i64>, ptr %private.contiguous.address856, align 8
  %5275 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 13), <8 x i64> %private.contiguous.preserve857
  store <8 x i64> %5275, ptr %private.contiguous.address856, align 8
  %5276 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5277 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5278 = add <8 x i64> %5277, splat (i64 1920)
  %5279 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5276, 0
  %5280 = insertvalue { <8 x ptr>, <8 x i64> } %5279, <8 x i64> %5278, 1
  %5281 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5282 = extractvalue { <8 x ptr>, <8 x i64> } %5280, 1
  %5283 = extractelement <8 x ptr> %5281, i32 0
  %5284 = extractelement <8 x i64> %5282, i32 %4816
  %5285 = zext i32 %4816 to i64
  %5286 = mul i64 %5285, 8
  %5287 = sub i64 %5284, %5286
  %5288 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %5289 = select i1 %5288, i64 %5287, i64 0
  %private.contiguous.address858 = getelementptr i8, ptr %5283, i64 %5289
  %private.contiguous.preserve859 = load <8 x i64>, ptr %private.contiguous.address858, align 8
  %5290 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 14), <8 x i64> %private.contiguous.preserve859
  store <8 x i64> %5290, ptr %private.contiguous.address858, align 8
  %5291 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5292 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5293 = add <8 x i64> %5292, splat (i64 1984)
  %5294 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5291, 0
  %5295 = insertvalue { <8 x ptr>, <8 x i64> } %5294, <8 x i64> %5293, 1
  %5296 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5297 = extractvalue { <8 x ptr>, <8 x i64> } %5295, 1
  %5298 = extractelement <8 x ptr> %5296, i32 0
  %5299 = extractelement <8 x i64> %5297, i32 %4816
  %5300 = zext i32 %4816 to i64
  %5301 = mul i64 %5300, 8
  %5302 = sub i64 %5299, %5301
  %5303 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  %5304 = select i1 %5303, i64 %5302, i64 0
  %private.contiguous.address860 = getelementptr i8, ptr %5298, i64 %5304
  %private.contiguous.preserve861 = load <8 x i64>, ptr %private.contiguous.address860, align 8
  %5305 = select <8 x i1> %convergence.cascade.result797, <8 x i64> splat (i64 15), <8 x i64> %private.contiguous.preserve861
  store <8 x i64> %5305, ptr %private.contiguous.address860, align 8
  %5306 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill90, align 64
  %5307 = extractvalue { <8 x ptr>, <8 x i64> } %31, 0
  %5308 = extractvalue { <8 x ptr>, <8 x i64> } %5306, 0
  %5309 = select <8 x i1> %convergence.cascade.result797, <8 x ptr> %5307, <8 x ptr> %5308
  %5310 = extractvalue { <8 x ptr>, <8 x i64> } %31, 1
  %5311 = extractvalue { <8 x ptr>, <8 x i64> } %5306, 1
  %5312 = select <8 x i1> %convergence.cascade.result797, <8 x i64> %5310, <8 x i64> %5311
  %5313 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5309, 0
  %5314 = insertvalue { <8 x ptr>, <8 x i64> } %5313, <8 x i64> %5312, 1
  store volatile { <8 x ptr>, <8 x i64> } %5314, ptr %tile_snapshot.spill90, align 64
  %5315 = load <8 x i64>, ptr %.slot91, align 64
  %5316 = select <8 x i1> %convergence.cascade.result797, <8 x i64> zeroinitializer, <8 x i64> %5315
  store <8 x i64> %5316, ptr %.slot91, align 64
  store <8 x i1> %convergence.cascade.result797, ptr %current.mask, align 1
  %5317 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result797)
  br i1 %5317, label %schedule.38, label %scheduler.loop

varying.divergent863:                             ; preds = %schedule.38
  %5318 = load i32, ptr %current.token, align 4
  %5319 = icmp ne i32 %5318, 0
  %5320 = sub i32 %5318, 1
  %5321 = select i1 %5319, i32 %5320, i32 0
  %5322 = load i8, ptr %frame.active, align 1
  %5323 = trunc i32 %5321 to i8
  %5324 = shl i8 1, %5323
  %5325 = and i8 %5322, %5324
  %5326 = icmp ne i8 %5325, 0
  %5327 = load <8 x i32>, ptr %frame.static.id, align 32
  %5328 = extractelement <8 x i32> %5327, i32 %5321
  %5329 = icmp eq i32 %5328, 14
  %5330 = and i1 %5326, %5329
  %5331 = and i1 %5319, %5330
  %5332 = xor i1 %5331, true
  %5333 = and i1 true, %5332
  %5334 = xor i8 %5322, -1
  %5335 = icmp ne i8 %5334, 0
  %5336 = xor i1 %5335, true
  %5337 = and i1 %5333, %5336
  br i1 %5337, label %convergence.overflow.trap865, label %convergence.overflow.resume866

varying.coherent864:                              ; preds = %schedule.38
  br i1 %842, label %varying.coherent.true869, label %varying.coherent.false870

convergence.overflow.trap865:                     ; preds = %varying.divergent863
  call void @llvm.trap()
  unreachable

convergence.overflow.resume866:                   ; preds = %varying.divergent863
  %5338 = call i8 @llvm.cttz.i8(i8 %5334, i1 false)
  %5339 = zext i8 %5338 to i32
  %5340 = select i1 %5335, i32 %5339, i32 0
  %5341 = trunc i32 %5340 to i8
  %5342 = shl i8 1, %5341
  %5343 = or i8 %5322, %5342
  %5344 = select i1 %5333, i8 %5343, i8 %5322
  store i8 %5344, ptr %frame.active, align 1
  %5345 = load <8 x i32>, ptr %frame.static.id, align 32
  %5346 = extractelement <8 x i32> %5345, i32 %5340
  %5347 = select i1 %5333, i32 14, i32 %5346
  %5348 = load <8 x i32>, ptr %frame.static.id, align 32
  %5349 = insertelement <8 x i32> %5348, i32 %5347, i32 %5340
  store <8 x i32> %5349, ptr %frame.static.id, align 32
  %5350 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5351 = extractelement <8 x i32> %5350, i32 %5340
  %5352 = select i1 %5333, i32 %5318, i32 %5351
  %5353 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5354 = insertelement <8 x i32> %5353, i32 %5352, i32 %5340
  store <8 x i32> %5354, ptr %frame.parent.token, align 32
  %5355 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5340
  %5356 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5340
  %5357 = load <8 x i1>, ptr %5355, align 1
  %5358 = load <8 x i1>, ptr %5356, align 1
  %5359 = select i1 %5333, <8 x i1> %832, <8 x i1> %5357
  store <8 x i1> %5359, ptr %5355, align 1
  %5360 = select i1 %5333, <8 x i1> zeroinitializer, <8 x i1> %5358
  store <8 x i1> %5360, ptr %5356, align 1
  %5361 = add i32 %5340, 1
  %5362 = select i1 %5331, i32 %5318, i32 %5361
  %5363 = select i1 true, i32 %5362, i32 %5318
  store i32 %5363, ptr %current.token, align 4
  %5364 = load i32, ptr %current.token, align 4
  %5365 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %839)
  %5366 = load i32, ptr %ready.count, align 4
  %5367 = icmp uge i32 %5366, 8
  %5368 = and i1 %5365, %5367
  br i1 %5368, label %ready.overflow.trap867, label %ready.overflow.resume868

ready.overflow.trap867:                           ; preds = %convergence.overflow.resume866
  call void @llvm.trap()
  unreachable

ready.overflow.resume868:                         ; preds = %convergence.overflow.resume866
  %5369 = select i1 %5365, i32 %5366, i32 0
  %5370 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5369
  %5371 = load <8 x i1>, ptr %5370, align 1
  %5372 = select i1 %5365, <8 x i1> %839, <8 x i1> %5371
  store <8 x i1> %5372, ptr %5370, align 1
  %5373 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5369
  %5374 = load i32, ptr %5373, align 4
  %5375 = select i1 %5365, i32 39, i32 %5374
  store i32 %5375, ptr %5373, align 4
  %5376 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5369
  %5377 = load i32, ptr %5376, align 4
  %5378 = select i1 %5365, i32 %5364, i32 %5377
  store i32 %5378, ptr %5376, align 4
  %5379 = add i32 %5366, 1
  %5380 = select i1 %5365, i32 %5379, i32 %5366
  store i32 %5380, ptr %ready.count, align 4
  %5381 = load <8 x i1>, ptr %runnable.mask, align 1
  %5382 = or <8 x i1> %5381, %839
  store <8 x i1> %5382, ptr %runnable.mask, align 1
  store <8 x i1> %841, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true869:                         ; preds = %varying.coherent864
  store <8 x i1> %832, ptr %current.mask, align 1
  %5383 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %832)
  br i1 %5383, label %schedule.39, label %scheduler.loop

varying.coherent.false870:                        ; preds = %varying.coherent864
  store <8 x i1> %832, ptr %current.mask, align 1
  %5384 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %832)
  br i1 %5384, label %schedule.42, label %scheduler.loop

varying.divergent877:                             ; preds = %schedule.39
  %5385 = load i32, ptr %current.token, align 4
  %5386 = icmp ne i32 %5385, 0
  %5387 = sub i32 %5385, 1
  %5388 = select i1 %5386, i32 %5387, i32 0
  %5389 = load i8, ptr %frame.active, align 1
  %5390 = trunc i32 %5388 to i8
  %5391 = shl i8 1, %5390
  %5392 = and i8 %5389, %5391
  %5393 = icmp ne i8 %5392, 0
  %5394 = load <8 x i32>, ptr %frame.static.id, align 32
  %5395 = extractelement <8 x i32> %5394, i32 %5388
  %5396 = icmp eq i32 %5395, 15
  %5397 = and i1 %5393, %5396
  %5398 = and i1 %5386, %5397
  %5399 = xor i1 %5398, true
  %5400 = and i1 true, %5399
  %5401 = xor i8 %5389, -1
  %5402 = icmp ne i8 %5401, 0
  %5403 = xor i1 %5402, true
  %5404 = and i1 %5400, %5403
  br i1 %5404, label %convergence.overflow.trap879, label %convergence.overflow.resume880

varying.coherent878:                              ; preds = %schedule.39
  br i1 %884, label %varying.coherent.true883, label %varying.coherent.false884

convergence.overflow.trap879:                     ; preds = %varying.divergent877
  call void @llvm.trap()
  unreachable

convergence.overflow.resume880:                   ; preds = %varying.divergent877
  %5405 = call i8 @llvm.cttz.i8(i8 %5401, i1 false)
  %5406 = zext i8 %5405 to i32
  %5407 = select i1 %5402, i32 %5406, i32 0
  %5408 = trunc i32 %5407 to i8
  %5409 = shl i8 1, %5408
  %5410 = or i8 %5389, %5409
  %5411 = select i1 %5400, i8 %5410, i8 %5389
  store i8 %5411, ptr %frame.active, align 1
  %5412 = load <8 x i32>, ptr %frame.static.id, align 32
  %5413 = extractelement <8 x i32> %5412, i32 %5407
  %5414 = select i1 %5400, i32 15, i32 %5413
  %5415 = load <8 x i32>, ptr %frame.static.id, align 32
  %5416 = insertelement <8 x i32> %5415, i32 %5414, i32 %5407
  store <8 x i32> %5416, ptr %frame.static.id, align 32
  %5417 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5418 = extractelement <8 x i32> %5417, i32 %5407
  %5419 = select i1 %5400, i32 %5385, i32 %5418
  %5420 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5421 = insertelement <8 x i32> %5420, i32 %5419, i32 %5407
  store <8 x i32> %5421, ptr %frame.parent.token, align 32
  %5422 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5407
  %5423 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5407
  %5424 = load <8 x i1>, ptr %5422, align 1
  %5425 = load <8 x i1>, ptr %5423, align 1
  %5426 = select i1 %5400, <8 x i1> %845, <8 x i1> %5424
  store <8 x i1> %5426, ptr %5422, align 1
  %5427 = select i1 %5400, <8 x i1> zeroinitializer, <8 x i1> %5425
  store <8 x i1> %5427, ptr %5423, align 1
  %5428 = add i32 %5407, 1
  %5429 = select i1 %5398, i32 %5385, i32 %5428
  %5430 = select i1 true, i32 %5429, i32 %5385
  store i32 %5430, ptr %current.token, align 4
  %5431 = load <8 x float>, ptr %.slot94, align 32
  %5432 = select <8 x i1> %883, <8 x float> zeroinitializer, <8 x float> %5431
  store <8 x float> %5432, ptr %.slot94, align 32
  %5433 = load i32, ptr %current.token, align 4
  %5434 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %881)
  %5435 = load i32, ptr %ready.count, align 4
  %5436 = icmp uge i32 %5435, 8
  %5437 = and i1 %5434, %5436
  br i1 %5437, label %ready.overflow.trap881, label %ready.overflow.resume882

ready.overflow.trap881:                           ; preds = %convergence.overflow.resume880
  call void @llvm.trap()
  unreachable

ready.overflow.resume882:                         ; preds = %convergence.overflow.resume880
  %5438 = select i1 %5434, i32 %5435, i32 0
  %5439 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5438
  %5440 = load <8 x i1>, ptr %5439, align 1
  %5441 = select i1 %5434, <8 x i1> %881, <8 x i1> %5440
  store <8 x i1> %5441, ptr %5439, align 1
  %5442 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5438
  %5443 = load i32, ptr %5442, align 4
  %5444 = select i1 %5434, i32 40, i32 %5443
  store i32 %5444, ptr %5442, align 4
  %5445 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5438
  %5446 = load i32, ptr %5445, align 4
  %5447 = select i1 %5434, i32 %5433, i32 %5446
  store i32 %5447, ptr %5445, align 4
  %5448 = add i32 %5435, 1
  %5449 = select i1 %5434, i32 %5448, i32 %5435
  store i32 %5449, ptr %ready.count, align 4
  %5450 = load <8 x i1>, ptr %runnable.mask, align 1
  %5451 = or <8 x i1> %5450, %881
  store <8 x i1> %5451, ptr %runnable.mask, align 1
  store <8 x i1> %883, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true883:                         ; preds = %varying.coherent878
  store <8 x i1> %845, ptr %current.mask, align 1
  %5452 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %845)
  br i1 %5452, label %schedule.40, label %scheduler.loop

varying.coherent.false884:                        ; preds = %varying.coherent878
  %5453 = load <8 x float>, ptr %.slot94, align 32
  %5454 = select <8 x i1> %845, <8 x float> zeroinitializer, <8 x float> %5453
  store <8 x float> %5454, ptr %.slot94, align 32
  store <8 x i1> %845, ptr %current.mask, align 1
  %5455 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %845)
  br i1 %5455, label %schedule.41, label %scheduler.loop

convergence.cascade887:                           ; preds = %convergence.cascade887, %schedule.41
  %convergence.cascade.flow891 = phi <8 x i1> [ %906, %schedule.41 ], [ %5498, %convergence.cascade887 ]
  %convergence.cascade.depth892 = phi i32 [ 0, %schedule.41 ], [ %5499, %convergence.cascade887 ]
  %5456 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow891)
  %5457 = load i32, ptr %current.token, align 4
  %5458 = icmp ne i32 %5457, 0
  %5459 = and i1 %5456, %5458
  %5460 = sub i32 %5457, 1
  %5461 = select i1 %5459, i32 %5460, i32 0
  %5462 = load i8, ptr %frame.active, align 1
  %5463 = trunc i32 %5461 to i8
  %5464 = shl i8 1, %5463
  %5465 = and i8 %5462, %5464
  %5466 = icmp ne i8 %5465, 0
  %5467 = load <8 x i32>, ptr %frame.static.id, align 32
  %5468 = extractelement <8 x i32> %5467, i32 %5461
  %convergence.target.pointer893 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %5468
  %convergence.dynamic.target894 = load i32, ptr %convergence.target.pointer893, align 4
  %5469 = icmp eq i32 %convergence.dynamic.target894, 41
  %5470 = and i1 %5466, %5469
  %5471 = and i1 %5459, %5470
  %5472 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5461
  %5473 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5461
  %5474 = load <8 x i1>, ptr %5472, align 1
  %5475 = load <8 x i1>, ptr %5473, align 1
  %5476 = or <8 x i1> %5475, %convergence.cascade.flow891
  %5477 = load <8 x i1>, ptr %live.mask, align 1
  %5478 = and <8 x i1> %5474, %5477
  %5479 = icmp eq <8 x i1> %5476, %5478
  %5480 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5479)
  %5481 = and i1 %5471, %5480
  %5482 = select i1 %5481, <8 x i1> zeroinitializer, <8 x i1> %5476
  %5483 = select i1 %5471, <8 x i1> %5482, <8 x i1> %5475
  store <8 x i1> %5483, ptr %5473, align 1
  %5484 = select i1 %5481, <8 x i1> zeroinitializer, <8 x i1> %5474
  store <8 x i1> %5484, ptr %5472, align 1
  %5485 = trunc i32 %5461 to i8
  %5486 = shl i8 1, %5485
  %5487 = xor i8 %5486, -1
  %5488 = and i8 %5462, %5487
  %5489 = select i1 %5481, i8 %5488, i8 %5462
  store i8 %5489, ptr %frame.active, align 1
  %.splatinsert895 = insertelement <8 x i1> poison, i1 %5471, i64 0
  %.splat896 = shufflevector <8 x i1> %.splatinsert895, <8 x i1> poison, <8 x i32> zeroinitializer
  %5490 = and <8 x i1> %convergence.cascade.flow891, %.splat896
  %5491 = load <8 x i1>, ptr %runnable.mask, align 1
  %5492 = xor <8 x i1> %5490, splat (i1 true)
  %5493 = and <8 x i1> %5491, %5492
  store <8 x i1> %5493, ptr %runnable.mask, align 1
  %.splatinsert897 = insertelement <8 x i1> poison, i1 %5481, i64 0
  %.splat898 = shufflevector <8 x i1> %.splatinsert897, <8 x i1> poison, <8 x i32> zeroinitializer
  %5494 = select <8 x i1> %.splat898, <8 x i1> %5476, <8 x i1> zeroinitializer
  %5495 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5496 = extractelement <8 x i32> %5495, i32 %5461
  %5497 = select i1 %5481, i32 %5496, i32 %5457
  store i32 %5497, ptr %current.token, align 4
  %.splatinsert899 = insertelement <8 x i1> poison, i1 %5471, i64 0
  %.splat900 = shufflevector <8 x i1> %.splatinsert899, <8 x i1> poison, <8 x i32> zeroinitializer
  %5498 = select <8 x i1> %.splat900, <8 x i1> %5494, <8 x i1> %convergence.cascade.flow891
  %5499 = add i32 %convergence.cascade.depth892, 1
  %5500 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5498)
  %5501 = icmp ult i32 %5499, 8
  %5502 = and i1 %5500, %5501
  %5503 = and i1 %5471, %5502
  %convergence.parent.token901 = load i32, ptr %current.token, align 4
  %convergence.parent.present902 = icmp ne i32 %convergence.parent.token901, 0
  %5504 = and i1 %5503, %convergence.parent.present902
  br i1 %5504, label %convergence.cascade887, label %convergence.cascade.exit888

convergence.cascade.exit888:                      ; preds = %convergence.cascade887, %schedule.41
  %convergence.cascade.result903 = phi <8 x i1> [ %906, %schedule.41 ], [ %5498, %convergence.cascade887 ]
  %5505 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result903)
  br i1 %5505, label %convergence.target.41.ready, label %scheduler.loop

convergence.target.41.ready:                      ; preds = %convergence.cascade.exit888
  %5506 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result903)
  %5507 = bitcast <8 x i1> %convergence.cascade.result903 to i8
  %5508 = call i8 @llvm.cttz.i8(i8 %5507, i1 false)
  %5509 = zext i8 %5508 to i32
  %5510 = select i1 %5506, i32 %5509, i32 0
  %.spill.load904 = load float, ptr %.spill49, align 4
  %.splatinsert905 = insertelement <8 x float> poison, float %.spill.load904, i64 0
  %.splat906 = shufflevector <8 x float> %.splatinsert905, <8 x float> poison, <8 x i32> zeroinitializer
  %.state907 = load <8 x float>, ptr %.slot94, align 32
  %.spill.load908 = load volatile <8 x i1>, ptr %.spill92, align 1
  %5511 = select <8 x i1> %.spill.load908, <8 x float> %.state907, <8 x float> %.splat906
  %tile_snapshot.spill.load909 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill90, align 64
  %5512 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load909, 0
  %5513 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load909, 1
  %.state910 = load <8 x i64>, ptr %.slot91, align 64
  %5514 = mul <8 x i64> %.state910, splat (i64 32)
  %5515 = add <8 x i64> %5513, %5514
  %5516 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5512, 0
  %5517 = insertvalue { <8 x ptr>, <8 x i64> } %5516, <8 x i64> %5515, 1
  %5518 = extractvalue { <8 x ptr>, <8 x i64> } %5517, 0
  %5519 = extractvalue { <8 x ptr>, <8 x i64> } %5517, 1
  %5520 = getelementptr i8, <8 x ptr> %5518, <8 x i64> %5519
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5511, <8 x ptr> %5520, i32 1, <8 x i1> %convergence.cascade.result903)
  %.state911 = load <8 x i64>, ptr %.slot91, align 64
  %5521 = add <8 x i64> %.state911, splat (i64 1)
  %5522 = load <8 x i64>, ptr %.slot91, align 64
  %5523 = select <8 x i1> %convergence.cascade.result903, <8 x i64> %5521, <8 x i64> %5522
  store <8 x i64> %5523, ptr %.slot91, align 64
  store <8 x i1> %convergence.cascade.result903, ptr %current.mask, align 1
  %5524 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result903)
  br i1 %5524, label %schedule.38, label %scheduler.loop

convergence.cascade912:                           ; preds = %convergence.cascade912, %schedule.42
  %convergence.cascade.flow916 = phi <8 x i1> [ %907, %schedule.42 ], [ %5567, %convergence.cascade912 ]
  %convergence.cascade.depth917 = phi i32 [ 0, %schedule.42 ], [ %5568, %convergence.cascade912 ]
  %5525 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow916)
  %5526 = load i32, ptr %current.token, align 4
  %5527 = icmp ne i32 %5526, 0
  %5528 = and i1 %5525, %5527
  %5529 = sub i32 %5526, 1
  %5530 = select i1 %5528, i32 %5529, i32 0
  %5531 = load i8, ptr %frame.active, align 1
  %5532 = trunc i32 %5530 to i8
  %5533 = shl i8 1, %5532
  %5534 = and i8 %5531, %5533
  %5535 = icmp ne i8 %5534, 0
  %5536 = load <8 x i32>, ptr %frame.static.id, align 32
  %5537 = extractelement <8 x i32> %5536, i32 %5530
  %convergence.target.pointer918 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %5537
  %convergence.dynamic.target919 = load i32, ptr %convergence.target.pointer918, align 4
  %5538 = icmp eq i32 %convergence.dynamic.target919, 42
  %5539 = and i1 %5535, %5538
  %5540 = and i1 %5528, %5539
  %5541 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5530
  %5542 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5530
  %5543 = load <8 x i1>, ptr %5541, align 1
  %5544 = load <8 x i1>, ptr %5542, align 1
  %5545 = or <8 x i1> %5544, %convergence.cascade.flow916
  %5546 = load <8 x i1>, ptr %live.mask, align 1
  %5547 = and <8 x i1> %5543, %5546
  %5548 = icmp eq <8 x i1> %5545, %5547
  %5549 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5548)
  %5550 = and i1 %5540, %5549
  %5551 = select i1 %5550, <8 x i1> zeroinitializer, <8 x i1> %5545
  %5552 = select i1 %5540, <8 x i1> %5551, <8 x i1> %5544
  store <8 x i1> %5552, ptr %5542, align 1
  %5553 = select i1 %5550, <8 x i1> zeroinitializer, <8 x i1> %5543
  store <8 x i1> %5553, ptr %5541, align 1
  %5554 = trunc i32 %5530 to i8
  %5555 = shl i8 1, %5554
  %5556 = xor i8 %5555, -1
  %5557 = and i8 %5531, %5556
  %5558 = select i1 %5550, i8 %5557, i8 %5531
  store i8 %5558, ptr %frame.active, align 1
  %.splatinsert920 = insertelement <8 x i1> poison, i1 %5540, i64 0
  %.splat921 = shufflevector <8 x i1> %.splatinsert920, <8 x i1> poison, <8 x i32> zeroinitializer
  %5559 = and <8 x i1> %convergence.cascade.flow916, %.splat921
  %5560 = load <8 x i1>, ptr %runnable.mask, align 1
  %5561 = xor <8 x i1> %5559, splat (i1 true)
  %5562 = and <8 x i1> %5560, %5561
  store <8 x i1> %5562, ptr %runnable.mask, align 1
  %.splatinsert922 = insertelement <8 x i1> poison, i1 %5550, i64 0
  %.splat923 = shufflevector <8 x i1> %.splatinsert922, <8 x i1> poison, <8 x i32> zeroinitializer
  %5563 = select <8 x i1> %.splat923, <8 x i1> %5545, <8 x i1> zeroinitializer
  %5564 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5565 = extractelement <8 x i32> %5564, i32 %5530
  %5566 = select i1 %5550, i32 %5565, i32 %5526
  store i32 %5566, ptr %current.token, align 4
  %.splatinsert924 = insertelement <8 x i1> poison, i1 %5540, i64 0
  %.splat925 = shufflevector <8 x i1> %.splatinsert924, <8 x i1> poison, <8 x i32> zeroinitializer
  %5567 = select <8 x i1> %.splat925, <8 x i1> %5563, <8 x i1> %convergence.cascade.flow916
  %5568 = add i32 %convergence.cascade.depth917, 1
  %5569 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5567)
  %5570 = icmp ult i32 %5568, 8
  %5571 = and i1 %5569, %5570
  %5572 = and i1 %5540, %5571
  %convergence.parent.token926 = load i32, ptr %current.token, align 4
  %convergence.parent.present927 = icmp ne i32 %convergence.parent.token926, 0
  %5573 = and i1 %5572, %convergence.parent.present927
  br i1 %5573, label %convergence.cascade912, label %convergence.cascade.exit913

convergence.cascade.exit913:                      ; preds = %convergence.cascade912, %schedule.42
  %convergence.cascade.result928 = phi <8 x i1> [ %907, %schedule.42 ], [ %5567, %convergence.cascade912 ]
  %5574 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result928)
  br i1 %5574, label %convergence.target.42.ready, label %scheduler.loop

convergence.target.42.ready:                      ; preds = %convergence.cascade.exit913
  %5575 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result928)
  %5576 = bitcast <8 x i1> %convergence.cascade.result928 to i8
  %5577 = call i8 @llvm.cttz.i8(i8 %5576, i1 false)
  %5578 = zext i8 %5577 to i32
  %5579 = select i1 %5575, i32 %5578, i32 0
  %5580 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %5581 = extractvalue { <8 x ptr>, <8 x i64> } %33, 0
  %5582 = extractvalue { <8 x ptr>, <8 x i64> } %5580, 0
  %5583 = select <8 x i1> %convergence.cascade.result928, <8 x ptr> %5581, <8 x ptr> %5582
  %5584 = extractvalue { <8 x ptr>, <8 x i64> } %33, 1
  %5585 = extractvalue { <8 x ptr>, <8 x i64> } %5580, 1
  %5586 = select <8 x i1> %convergence.cascade.result928, <8 x i64> %5584, <8 x i64> %5585
  %5587 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5583, 0
  %5588 = insertvalue { <8 x ptr>, <8 x i64> } %5587, <8 x i64> %5586, 1
  store { <8 x ptr>, <8 x i64> } %5588, ptr %tile_snapshot.spill95, align 64
  %5589 = load <8 x i64>, ptr %.slot96, align 64
  %5590 = select <8 x i1> %convergence.cascade.result928, <8 x i64> zeroinitializer, <8 x i64> %5589
  store <8 x i64> %5590, ptr %.slot96, align 64
  store <8 x i1> %convergence.cascade.result928, ptr %current.mask, align 1
  %5591 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result928)
  br i1 %5591, label %schedule.43, label %scheduler.loop

varying.divergent930:                             ; preds = %schedule.43
  %5592 = load i32, ptr %current.token, align 4
  %5593 = icmp ne i32 %5592, 0
  %5594 = sub i32 %5592, 1
  %5595 = select i1 %5593, i32 %5594, i32 0
  %5596 = load i8, ptr %frame.active, align 1
  %5597 = trunc i32 %5595 to i8
  %5598 = shl i8 1, %5597
  %5599 = and i8 %5596, %5598
  %5600 = icmp ne i8 %5599, 0
  %5601 = load <8 x i32>, ptr %frame.static.id, align 32
  %5602 = extractelement <8 x i32> %5601, i32 %5595
  %5603 = icmp eq i32 %5602, 16
  %5604 = and i1 %5600, %5603
  %5605 = and i1 %5593, %5604
  %5606 = xor i1 %5605, true
  %5607 = and i1 true, %5606
  %5608 = xor i8 %5596, -1
  %5609 = icmp ne i8 %5608, 0
  %5610 = xor i1 %5609, true
  %5611 = and i1 %5607, %5610
  br i1 %5611, label %convergence.overflow.trap932, label %convergence.overflow.resume933

varying.coherent931:                              ; preds = %schedule.43
  br i1 %918, label %varying.coherent.true936, label %varying.coherent.false937

convergence.overflow.trap932:                     ; preds = %varying.divergent930
  call void @llvm.trap()
  unreachable

convergence.overflow.resume933:                   ; preds = %varying.divergent930
  %5612 = call i8 @llvm.cttz.i8(i8 %5608, i1 false)
  %5613 = zext i8 %5612 to i32
  %5614 = select i1 %5609, i32 %5613, i32 0
  %5615 = trunc i32 %5614 to i8
  %5616 = shl i8 1, %5615
  %5617 = or i8 %5596, %5616
  %5618 = select i1 %5607, i8 %5617, i8 %5596
  store i8 %5618, ptr %frame.active, align 1
  %5619 = load <8 x i32>, ptr %frame.static.id, align 32
  %5620 = extractelement <8 x i32> %5619, i32 %5614
  %5621 = select i1 %5607, i32 16, i32 %5620
  %5622 = load <8 x i32>, ptr %frame.static.id, align 32
  %5623 = insertelement <8 x i32> %5622, i32 %5621, i32 %5614
  store <8 x i32> %5623, ptr %frame.static.id, align 32
  %5624 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5625 = extractelement <8 x i32> %5624, i32 %5614
  %5626 = select i1 %5607, i32 %5592, i32 %5625
  %5627 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5628 = insertelement <8 x i32> %5627, i32 %5626, i32 %5614
  store <8 x i32> %5628, ptr %frame.parent.token, align 32
  %5629 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5614
  %5630 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5614
  %5631 = load <8 x i1>, ptr %5629, align 1
  %5632 = load <8 x i1>, ptr %5630, align 1
  %5633 = select i1 %5607, <8 x i1> %908, <8 x i1> %5631
  store <8 x i1> %5633, ptr %5629, align 1
  %5634 = select i1 %5607, <8 x i1> zeroinitializer, <8 x i1> %5632
  store <8 x i1> %5634, ptr %5630, align 1
  %5635 = add i32 %5614, 1
  %5636 = select i1 %5605, i32 %5592, i32 %5635
  %5637 = select i1 true, i32 %5636, i32 %5592
  store i32 %5637, ptr %current.token, align 4
  %5638 = load i32, ptr %current.token, align 4
  %5639 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %915)
  %5640 = load i32, ptr %ready.count, align 4
  %5641 = icmp uge i32 %5640, 8
  %5642 = and i1 %5639, %5641
  br i1 %5642, label %ready.overflow.trap934, label %ready.overflow.resume935

ready.overflow.trap934:                           ; preds = %convergence.overflow.resume933
  call void @llvm.trap()
  unreachable

ready.overflow.resume935:                         ; preds = %convergence.overflow.resume933
  %5643 = select i1 %5639, i32 %5640, i32 0
  %5644 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5643
  %5645 = load <8 x i1>, ptr %5644, align 1
  %5646 = select i1 %5639, <8 x i1> %915, <8 x i1> %5645
  store <8 x i1> %5646, ptr %5644, align 1
  %5647 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5643
  %5648 = load i32, ptr %5647, align 4
  %5649 = select i1 %5639, i32 44, i32 %5648
  store i32 %5649, ptr %5647, align 4
  %5650 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5643
  %5651 = load i32, ptr %5650, align 4
  %5652 = select i1 %5639, i32 %5638, i32 %5651
  store i32 %5652, ptr %5650, align 4
  %5653 = add i32 %5640, 1
  %5654 = select i1 %5639, i32 %5653, i32 %5640
  store i32 %5654, ptr %ready.count, align 4
  %5655 = load <8 x i1>, ptr %runnable.mask, align 1
  %5656 = or <8 x i1> %5655, %915
  store <8 x i1> %5656, ptr %runnable.mask, align 1
  store <8 x i1> %917, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true936:                         ; preds = %varying.coherent931
  store <8 x i1> %908, ptr %current.mask, align 1
  %5657 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %908)
  br i1 %5657, label %schedule.44, label %scheduler.loop

varying.coherent.false937:                        ; preds = %varying.coherent931
  store <8 x i1> %908, ptr %current.mask, align 1
  %5658 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %908)
  br i1 %5658, label %schedule.45, label %scheduler.loop

convergence.cascade946:                           ; preds = %convergence.cascade946, %schedule.45
  %convergence.cascade.flow950 = phi <8 x i1> [ %990, %schedule.45 ], [ %5701, %convergence.cascade946 ]
  %convergence.cascade.depth951 = phi i32 [ 0, %schedule.45 ], [ %5702, %convergence.cascade946 ]
  %5659 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow950)
  %5660 = load i32, ptr %current.token, align 4
  %5661 = icmp ne i32 %5660, 0
  %5662 = and i1 %5659, %5661
  %5663 = sub i32 %5660, 1
  %5664 = select i1 %5662, i32 %5663, i32 0
  %5665 = load i8, ptr %frame.active, align 1
  %5666 = trunc i32 %5664 to i8
  %5667 = shl i8 1, %5666
  %5668 = and i8 %5665, %5667
  %5669 = icmp ne i8 %5668, 0
  %5670 = load <8 x i32>, ptr %frame.static.id, align 32
  %5671 = extractelement <8 x i32> %5670, i32 %5664
  %convergence.target.pointer952 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %5671
  %convergence.dynamic.target953 = load i32, ptr %convergence.target.pointer952, align 4
  %5672 = icmp eq i32 %convergence.dynamic.target953, 45
  %5673 = and i1 %5669, %5672
  %5674 = and i1 %5662, %5673
  %5675 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5664
  %5676 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5664
  %5677 = load <8 x i1>, ptr %5675, align 1
  %5678 = load <8 x i1>, ptr %5676, align 1
  %5679 = or <8 x i1> %5678, %convergence.cascade.flow950
  %5680 = load <8 x i1>, ptr %live.mask, align 1
  %5681 = and <8 x i1> %5677, %5680
  %5682 = icmp eq <8 x i1> %5679, %5681
  %5683 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5682)
  %5684 = and i1 %5674, %5683
  %5685 = select i1 %5684, <8 x i1> zeroinitializer, <8 x i1> %5679
  %5686 = select i1 %5674, <8 x i1> %5685, <8 x i1> %5678
  store <8 x i1> %5686, ptr %5676, align 1
  %5687 = select i1 %5684, <8 x i1> zeroinitializer, <8 x i1> %5677
  store <8 x i1> %5687, ptr %5675, align 1
  %5688 = trunc i32 %5664 to i8
  %5689 = shl i8 1, %5688
  %5690 = xor i8 %5689, -1
  %5691 = and i8 %5665, %5690
  %5692 = select i1 %5684, i8 %5691, i8 %5665
  store i8 %5692, ptr %frame.active, align 1
  %.splatinsert954 = insertelement <8 x i1> poison, i1 %5674, i64 0
  %.splat955 = shufflevector <8 x i1> %.splatinsert954, <8 x i1> poison, <8 x i32> zeroinitializer
  %5693 = and <8 x i1> %convergence.cascade.flow950, %.splat955
  %5694 = load <8 x i1>, ptr %runnable.mask, align 1
  %5695 = xor <8 x i1> %5693, splat (i1 true)
  %5696 = and <8 x i1> %5694, %5695
  store <8 x i1> %5696, ptr %runnable.mask, align 1
  %.splatinsert956 = insertelement <8 x i1> poison, i1 %5684, i64 0
  %.splat957 = shufflevector <8 x i1> %.splatinsert956, <8 x i1> poison, <8 x i32> zeroinitializer
  %5697 = select <8 x i1> %.splat957, <8 x i1> %5679, <8 x i1> zeroinitializer
  %5698 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5699 = extractelement <8 x i32> %5698, i32 %5664
  %5700 = select i1 %5684, i32 %5699, i32 %5660
  store i32 %5700, ptr %current.token, align 4
  %.splatinsert958 = insertelement <8 x i1> poison, i1 %5674, i64 0
  %.splat959 = shufflevector <8 x i1> %.splatinsert958, <8 x i1> poison, <8 x i32> zeroinitializer
  %5701 = select <8 x i1> %.splat959, <8 x i1> %5697, <8 x i1> %convergence.cascade.flow950
  %5702 = add i32 %convergence.cascade.depth951, 1
  %5703 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5701)
  %5704 = icmp ult i32 %5702, 8
  %5705 = and i1 %5703, %5704
  %5706 = and i1 %5674, %5705
  %convergence.parent.token960 = load i32, ptr %current.token, align 4
  %convergence.parent.present961 = icmp ne i32 %convergence.parent.token960, 0
  %5707 = and i1 %5706, %convergence.parent.present961
  br i1 %5707, label %convergence.cascade946, label %convergence.cascade.exit947

convergence.cascade.exit947:                      ; preds = %convergence.cascade946, %schedule.45
  %convergence.cascade.result962 = phi <8 x i1> [ %990, %schedule.45 ], [ %5701, %convergence.cascade946 ]
  %5708 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result962)
  br i1 %5708, label %convergence.target.45.ready, label %scheduler.loop

convergence.target.45.ready:                      ; preds = %convergence.cascade.exit947
  %5709 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result962)
  %5710 = bitcast <8 x i1> %convergence.cascade.result962 to i8
  %5711 = call i8 @llvm.cttz.i8(i8 %5710, i1 false)
  %5712 = zext i8 %5711 to i32
  %5713 = select i1 %5709, i32 %5712, i32 0
  %5714 = load <8 x i64>, ptr %.slot97, align 64
  %5715 = select <8 x i1> %convergence.cascade.result962, <8 x i64> zeroinitializer, <8 x i64> %5714
  store <8 x i64> %5715, ptr %.slot97, align 64
  store <8 x i1> %convergence.cascade.result962, ptr %current.mask, align 1
  %5716 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result962)
  br i1 %5716, label %schedule.46, label %scheduler.loop

varying.divergent964:                             ; preds = %schedule.46
  %5717 = load i32, ptr %current.token, align 4
  %5718 = icmp ne i32 %5717, 0
  %5719 = sub i32 %5717, 1
  %5720 = select i1 %5718, i32 %5719, i32 0
  %5721 = load i8, ptr %frame.active, align 1
  %5722 = trunc i32 %5720 to i8
  %5723 = shl i8 1, %5722
  %5724 = and i8 %5721, %5723
  %5725 = icmp ne i8 %5724, 0
  %5726 = load <8 x i32>, ptr %frame.static.id, align 32
  %5727 = extractelement <8 x i32> %5726, i32 %5720
  %5728 = icmp eq i32 %5727, 17
  %5729 = and i1 %5725, %5728
  %5730 = and i1 %5718, %5729
  %5731 = xor i1 %5730, true
  %5732 = and i1 true, %5731
  %5733 = xor i8 %5721, -1
  %5734 = icmp ne i8 %5733, 0
  %5735 = xor i1 %5734, true
  %5736 = and i1 %5732, %5735
  br i1 %5736, label %convergence.overflow.trap966, label %convergence.overflow.resume967

varying.coherent965:                              ; preds = %schedule.46
  br i1 %1001, label %varying.coherent.true970, label %varying.coherent.false971

convergence.overflow.trap966:                     ; preds = %varying.divergent964
  call void @llvm.trap()
  unreachable

convergence.overflow.resume967:                   ; preds = %varying.divergent964
  %5737 = call i8 @llvm.cttz.i8(i8 %5733, i1 false)
  %5738 = zext i8 %5737 to i32
  %5739 = select i1 %5734, i32 %5738, i32 0
  %5740 = trunc i32 %5739 to i8
  %5741 = shl i8 1, %5740
  %5742 = or i8 %5721, %5741
  %5743 = select i1 %5732, i8 %5742, i8 %5721
  store i8 %5743, ptr %frame.active, align 1
  %5744 = load <8 x i32>, ptr %frame.static.id, align 32
  %5745 = extractelement <8 x i32> %5744, i32 %5739
  %5746 = select i1 %5732, i32 17, i32 %5745
  %5747 = load <8 x i32>, ptr %frame.static.id, align 32
  %5748 = insertelement <8 x i32> %5747, i32 %5746, i32 %5739
  store <8 x i32> %5748, ptr %frame.static.id, align 32
  %5749 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5750 = extractelement <8 x i32> %5749, i32 %5739
  %5751 = select i1 %5732, i32 %5717, i32 %5750
  %5752 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5753 = insertelement <8 x i32> %5752, i32 %5751, i32 %5739
  store <8 x i32> %5753, ptr %frame.parent.token, align 32
  %5754 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5739
  %5755 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5739
  %5756 = load <8 x i1>, ptr %5754, align 1
  %5757 = load <8 x i1>, ptr %5755, align 1
  %5758 = select i1 %5732, <8 x i1> %991, <8 x i1> %5756
  store <8 x i1> %5758, ptr %5754, align 1
  %5759 = select i1 %5732, <8 x i1> zeroinitializer, <8 x i1> %5757
  store <8 x i1> %5759, ptr %5755, align 1
  %5760 = add i32 %5739, 1
  %5761 = select i1 %5730, i32 %5717, i32 %5760
  %5762 = select i1 true, i32 %5761, i32 %5717
  store i32 %5762, ptr %current.token, align 4
  %5763 = load i32, ptr %current.token, align 4
  %5764 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %998)
  %5765 = load i32, ptr %ready.count, align 4
  %5766 = icmp uge i32 %5765, 8
  %5767 = and i1 %5764, %5766
  br i1 %5767, label %ready.overflow.trap968, label %ready.overflow.resume969

ready.overflow.trap968:                           ; preds = %convergence.overflow.resume967
  call void @llvm.trap()
  unreachable

ready.overflow.resume969:                         ; preds = %convergence.overflow.resume967
  %5768 = select i1 %5764, i32 %5765, i32 0
  %5769 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5768
  %5770 = load <8 x i1>, ptr %5769, align 1
  %5771 = select i1 %5764, <8 x i1> %998, <8 x i1> %5770
  store <8 x i1> %5771, ptr %5769, align 1
  %5772 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5768
  %5773 = load i32, ptr %5772, align 4
  %5774 = select i1 %5764, i32 47, i32 %5773
  store i32 %5774, ptr %5772, align 4
  %5775 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5768
  %5776 = load i32, ptr %5775, align 4
  %5777 = select i1 %5764, i32 %5763, i32 %5776
  store i32 %5777, ptr %5775, align 4
  %5778 = add i32 %5765, 1
  %5779 = select i1 %5764, i32 %5778, i32 %5765
  store i32 %5779, ptr %ready.count, align 4
  %5780 = load <8 x i1>, ptr %runnable.mask, align 1
  %5781 = or <8 x i1> %5780, %998
  store <8 x i1> %5781, ptr %runnable.mask, align 1
  store <8 x i1> %1000, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true970:                         ; preds = %varying.coherent965
  store <8 x i1> %991, ptr %current.mask, align 1
  %5782 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %991)
  br i1 %5782, label %schedule.47, label %scheduler.loop

varying.coherent.false971:                        ; preds = %varying.coherent965
  store <8 x i1> %991, ptr %current.mask, align 1
  %5783 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %991)
  br i1 %5783, label %schedule.48, label %scheduler.loop

convergence.cascade981:                           ; preds = %convergence.cascade981, %schedule.48
  %convergence.cascade.flow985 = phi <8 x i1> [ %1038, %schedule.48 ], [ %5826, %convergence.cascade981 ]
  %convergence.cascade.depth986 = phi i32 [ 0, %schedule.48 ], [ %5827, %convergence.cascade981 ]
  %5784 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow985)
  %5785 = load i32, ptr %current.token, align 4
  %5786 = icmp ne i32 %5785, 0
  %5787 = and i1 %5784, %5786
  %5788 = sub i32 %5785, 1
  %5789 = select i1 %5787, i32 %5788, i32 0
  %5790 = load i8, ptr %frame.active, align 1
  %5791 = trunc i32 %5789 to i8
  %5792 = shl i8 1, %5791
  %5793 = and i8 %5790, %5792
  %5794 = icmp ne i8 %5793, 0
  %5795 = load <8 x i32>, ptr %frame.static.id, align 32
  %5796 = extractelement <8 x i32> %5795, i32 %5789
  %convergence.target.pointer987 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %5796
  %convergence.dynamic.target988 = load i32, ptr %convergence.target.pointer987, align 4
  %5797 = icmp eq i32 %convergence.dynamic.target988, 48
  %5798 = and i1 %5794, %5797
  %5799 = and i1 %5787, %5798
  %5800 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5789
  %5801 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5789
  %5802 = load <8 x i1>, ptr %5800, align 1
  %5803 = load <8 x i1>, ptr %5801, align 1
  %5804 = or <8 x i1> %5803, %convergence.cascade.flow985
  %5805 = load <8 x i1>, ptr %live.mask, align 1
  %5806 = and <8 x i1> %5802, %5805
  %5807 = icmp eq <8 x i1> %5804, %5806
  %5808 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5807)
  %5809 = and i1 %5799, %5808
  %5810 = select i1 %5809, <8 x i1> zeroinitializer, <8 x i1> %5804
  %5811 = select i1 %5799, <8 x i1> %5810, <8 x i1> %5803
  store <8 x i1> %5811, ptr %5801, align 1
  %5812 = select i1 %5809, <8 x i1> zeroinitializer, <8 x i1> %5802
  store <8 x i1> %5812, ptr %5800, align 1
  %5813 = trunc i32 %5789 to i8
  %5814 = shl i8 1, %5813
  %5815 = xor i8 %5814, -1
  %5816 = and i8 %5790, %5815
  %5817 = select i1 %5809, i8 %5816, i8 %5790
  store i8 %5817, ptr %frame.active, align 1
  %.splatinsert989 = insertelement <8 x i1> poison, i1 %5799, i64 0
  %.splat990 = shufflevector <8 x i1> %.splatinsert989, <8 x i1> poison, <8 x i32> zeroinitializer
  %5818 = and <8 x i1> %convergence.cascade.flow985, %.splat990
  %5819 = load <8 x i1>, ptr %runnable.mask, align 1
  %5820 = xor <8 x i1> %5818, splat (i1 true)
  %5821 = and <8 x i1> %5819, %5820
  store <8 x i1> %5821, ptr %runnable.mask, align 1
  %.splatinsert991 = insertelement <8 x i1> poison, i1 %5809, i64 0
  %.splat992 = shufflevector <8 x i1> %.splatinsert991, <8 x i1> poison, <8 x i32> zeroinitializer
  %5822 = select <8 x i1> %.splat992, <8 x i1> %5804, <8 x i1> zeroinitializer
  %5823 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5824 = extractelement <8 x i32> %5823, i32 %5789
  %5825 = select i1 %5809, i32 %5824, i32 %5785
  store i32 %5825, ptr %current.token, align 4
  %.splatinsert993 = insertelement <8 x i1> poison, i1 %5799, i64 0
  %.splat994 = shufflevector <8 x i1> %.splatinsert993, <8 x i1> poison, <8 x i32> zeroinitializer
  %5826 = select <8 x i1> %.splat994, <8 x i1> %5822, <8 x i1> %convergence.cascade.flow985
  %5827 = add i32 %convergence.cascade.depth986, 1
  %5828 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5826)
  %5829 = icmp ult i32 %5827, 8
  %5830 = and i1 %5828, %5829
  %5831 = and i1 %5799, %5830
  %convergence.parent.token995 = load i32, ptr %current.token, align 4
  %convergence.parent.present996 = icmp ne i32 %convergence.parent.token995, 0
  %5832 = and i1 %5831, %convergence.parent.present996
  br i1 %5832, label %convergence.cascade981, label %convergence.cascade.exit982

convergence.cascade.exit982:                      ; preds = %convergence.cascade981, %schedule.48
  %convergence.cascade.result997 = phi <8 x i1> [ %1038, %schedule.48 ], [ %5826, %convergence.cascade981 ]
  %5833 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result997)
  br i1 %5833, label %convergence.target.48.ready, label %scheduler.loop

convergence.target.48.ready:                      ; preds = %convergence.cascade.exit982
  %5834 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result997)
  %5835 = bitcast <8 x i1> %convergence.cascade.result997 to i8
  %5836 = call i8 @llvm.cttz.i8(i8 %5835, i1 false)
  %5837 = zext i8 %5836 to i32
  %5838 = select i1 %5834, i32 %5837, i32 0
  %tile_snapshot.spill.load998 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %5839 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load998, 0
  %5840 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load998, 1
  %5841 = add <8 x i64> %5840, splat (i64 992)
  %5842 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5839, 0
  %5843 = insertvalue { <8 x ptr>, <8 x i64> } %5842, <8 x i64> %5841, 1
  %5844 = extractvalue { <8 x ptr>, <8 x i64> } %33, 0
  %5845 = extractvalue { <8 x ptr>, <8 x i64> } %5843, 1
  %5846 = extractelement <8 x ptr> %5844, i32 0
  %5847 = extractelement <8 x i64> %5845, i32 %5838
  %5848 = zext i32 %5838 to i64
  %5849 = mul i64 %5848, 4
  %5850 = sub i64 %5847, %5849
  %5851 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result997)
  %5852 = select i1 %5851, i64 %5850, i64 0
  %private.contiguous.address999 = getelementptr i8, ptr %5846, i64 %5852
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address999, align 4
  %5853 = select <8 x i1> %convergence.cascade.result997, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load1000 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %5854 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1000, 0
  %5855 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1000, 1
  %5856 = add <8 x i64> %5855, splat (i64 2016)
  %5857 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5854, 0
  %5858 = insertvalue { <8 x ptr>, <8 x i64> } %5857, <8 x i64> %5856, 1
  %5859 = extractvalue { <8 x ptr>, <8 x i64> } %33, 0
  %5860 = extractvalue { <8 x ptr>, <8 x i64> } %5858, 1
  %5861 = extractelement <8 x ptr> %5859, i32 0
  %5862 = extractelement <8 x i64> %5860, i32 %5838
  %5863 = zext i32 %5838 to i64
  %5864 = mul i64 %5863, 4
  %5865 = sub i64 %5862, %5864
  %5866 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result997)
  %5867 = select i1 %5866, i64 %5865, i64 0
  %private.contiguous.address1001 = getelementptr i8, ptr %5861, i64 %5867
  %private.contiguous.load1002 = load <8 x float>, ptr %private.contiguous.address1001, align 4
  %5868 = select <8 x i1> %convergence.cascade.result997, <8 x float> %private.contiguous.load1002, <8 x float> zeroinitializer
  %tile_snapshot.spill.load1003 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %5869 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1003, 0
  %5870 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1003, 1
  %5871 = add <8 x i64> %5870, splat (i64 3040)
  %5872 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5869, 0
  %5873 = insertvalue { <8 x ptr>, <8 x i64> } %5872, <8 x i64> %5871, 1
  %5874 = extractvalue { <8 x ptr>, <8 x i64> } %33, 0
  %5875 = extractvalue { <8 x ptr>, <8 x i64> } %5873, 1
  %5876 = extractelement <8 x ptr> %5874, i32 0
  %5877 = extractelement <8 x i64> %5875, i32 %5838
  %5878 = zext i32 %5838 to i64
  %5879 = mul i64 %5878, 4
  %5880 = sub i64 %5877, %5879
  %5881 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result997)
  %5882 = select i1 %5881, i64 %5880, i64 0
  %private.contiguous.address1004 = getelementptr i8, ptr %5876, i64 %5882
  %private.contiguous.load1005 = load <8 x float>, ptr %private.contiguous.address1004, align 4
  %5883 = select <8 x i1> %convergence.cascade.result997, <8 x float> %private.contiguous.load1005, <8 x float> zeroinitializer
  %tile_snapshot.spill.load1006 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %5884 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1006, 0
  %5885 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1006, 1
  %5886 = add <8 x i64> %5885, splat (i64 4064)
  %5887 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5884, 0
  %5888 = insertvalue { <8 x ptr>, <8 x i64> } %5887, <8 x i64> %5886, 1
  %5889 = extractvalue { <8 x ptr>, <8 x i64> } %33, 0
  %5890 = extractvalue { <8 x ptr>, <8 x i64> } %5888, 1
  %5891 = extractelement <8 x ptr> %5889, i32 0
  %5892 = extractelement <8 x i64> %5890, i32 %5838
  %5893 = zext i32 %5838 to i64
  %5894 = mul i64 %5893, 4
  %5895 = sub i64 %5892, %5894
  %5896 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result997)
  %5897 = select i1 %5896, i64 %5895, i64 0
  %private.contiguous.address1007 = getelementptr i8, ptr %5891, i64 %5897
  %private.contiguous.load1008 = load <8 x float>, ptr %private.contiguous.address1007, align 4
  %5898 = select <8 x i1> %convergence.cascade.result997, <8 x float> %private.contiguous.load1008, <8 x float> zeroinitializer
  %.state1009 = load <8 x i64>, ptr %.slot, align 64
  %5899 = add <8 x i64> %.state1009, splat (i64 1)
  %5900 = load <8 x i64>, ptr %.slot, align 64
  %5901 = select <8 x i1> %convergence.cascade.result997, <8 x i64> %5899, <8 x i64> %5900
  store <8 x i64> %5901, ptr %.slot, align 64
  %5902 = load volatile <8 x float>, ptr %.slot50, align 32
  %5903 = select <8 x i1> %convergence.cascade.result997, <8 x float> %5853, <8 x float> %5902
  store volatile <8 x float> %5903, ptr %.slot50, align 32
  %5904 = load volatile <8 x float>, ptr %.slot51, align 32
  %5905 = select <8 x i1> %convergence.cascade.result997, <8 x float> %5868, <8 x float> %5904
  store volatile <8 x float> %5905, ptr %.slot51, align 32
  %5906 = load volatile <8 x float>, ptr %.slot52, align 32
  %5907 = select <8 x i1> %convergence.cascade.result997, <8 x float> %5883, <8 x float> %5906
  store volatile <8 x float> %5907, ptr %.slot52, align 32
  %5908 = load volatile <8 x float>, ptr %.slot53, align 32
  %5909 = select <8 x i1> %convergence.cascade.result997, <8 x float> %5898, <8 x float> %5908
  store volatile <8 x float> %5909, ptr %.slot53, align 32
  store <8 x i1> %convergence.cascade.result997, ptr %current.mask, align 1
  %5910 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result997)
  br i1 %5910, label %schedule.1, label %scheduler.loop

convergence.cascade1010:                          ; preds = %convergence.cascade1010, %schedule.49
  %convergence.cascade.flow1014 = phi <8 x i1> [ %1039, %schedule.49 ], [ %5953, %convergence.cascade1010 ]
  %convergence.cascade.depth1015 = phi i32 [ 0, %schedule.49 ], [ %5954, %convergence.cascade1010 ]
  %5911 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1014)
  %5912 = load i32, ptr %current.token, align 4
  %5913 = icmp ne i32 %5912, 0
  %5914 = and i1 %5911, %5913
  %5915 = sub i32 %5912, 1
  %5916 = select i1 %5914, i32 %5915, i32 0
  %5917 = load i8, ptr %frame.active, align 1
  %5918 = trunc i32 %5916 to i8
  %5919 = shl i8 1, %5918
  %5920 = and i8 %5917, %5919
  %5921 = icmp ne i8 %5920, 0
  %5922 = load <8 x i32>, ptr %frame.static.id, align 32
  %5923 = extractelement <8 x i32> %5922, i32 %5916
  %convergence.target.pointer1016 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %5923
  %convergence.dynamic.target1017 = load i32, ptr %convergence.target.pointer1016, align 4
  %5924 = icmp eq i32 %convergence.dynamic.target1017, 49
  %5925 = and i1 %5921, %5924
  %5926 = and i1 %5914, %5925
  %5927 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5916
  %5928 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5916
  %5929 = load <8 x i1>, ptr %5927, align 1
  %5930 = load <8 x i1>, ptr %5928, align 1
  %5931 = or <8 x i1> %5930, %convergence.cascade.flow1014
  %5932 = load <8 x i1>, ptr %live.mask, align 1
  %5933 = and <8 x i1> %5929, %5932
  %5934 = icmp eq <8 x i1> %5931, %5933
  %5935 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5934)
  %5936 = and i1 %5926, %5935
  %5937 = select i1 %5936, <8 x i1> zeroinitializer, <8 x i1> %5931
  %5938 = select i1 %5926, <8 x i1> %5937, <8 x i1> %5930
  store <8 x i1> %5938, ptr %5928, align 1
  %5939 = select i1 %5936, <8 x i1> zeroinitializer, <8 x i1> %5929
  store <8 x i1> %5939, ptr %5927, align 1
  %5940 = trunc i32 %5916 to i8
  %5941 = shl i8 1, %5940
  %5942 = xor i8 %5941, -1
  %5943 = and i8 %5917, %5942
  %5944 = select i1 %5936, i8 %5943, i8 %5917
  store i8 %5944, ptr %frame.active, align 1
  %.splatinsert1018 = insertelement <8 x i1> poison, i1 %5926, i64 0
  %.splat1019 = shufflevector <8 x i1> %.splatinsert1018, <8 x i1> poison, <8 x i32> zeroinitializer
  %5945 = and <8 x i1> %convergence.cascade.flow1014, %.splat1019
  %5946 = load <8 x i1>, ptr %runnable.mask, align 1
  %5947 = xor <8 x i1> %5945, splat (i1 true)
  %5948 = and <8 x i1> %5946, %5947
  store <8 x i1> %5948, ptr %runnable.mask, align 1
  %.splatinsert1020 = insertelement <8 x i1> poison, i1 %5936, i64 0
  %.splat1021 = shufflevector <8 x i1> %.splatinsert1020, <8 x i1> poison, <8 x i32> zeroinitializer
  %5949 = select <8 x i1> %.splat1021, <8 x i1> %5931, <8 x i1> zeroinitializer
  %5950 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5951 = extractelement <8 x i32> %5950, i32 %5916
  %5952 = select i1 %5936, i32 %5951, i32 %5912
  store i32 %5952, ptr %current.token, align 4
  %.splatinsert1022 = insertelement <8 x i1> poison, i1 %5926, i64 0
  %.splat1023 = shufflevector <8 x i1> %.splatinsert1022, <8 x i1> poison, <8 x i32> zeroinitializer
  %5953 = select <8 x i1> %.splat1023, <8 x i1> %5949, <8 x i1> %convergence.cascade.flow1014
  %5954 = add i32 %convergence.cascade.depth1015, 1
  %5955 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5953)
  %5956 = icmp ult i32 %5954, 8
  %5957 = and i1 %5955, %5956
  %5958 = and i1 %5926, %5957
  %convergence.parent.token1024 = load i32, ptr %current.token, align 4
  %convergence.parent.present1025 = icmp ne i32 %convergence.parent.token1024, 0
  %5959 = and i1 %5958, %convergence.parent.present1025
  br i1 %5959, label %convergence.cascade1010, label %convergence.cascade.exit1011

convergence.cascade.exit1011:                     ; preds = %convergence.cascade1010, %schedule.49
  %convergence.cascade.result1026 = phi <8 x i1> [ %1039, %schedule.49 ], [ %5953, %convergence.cascade1010 ]
  %5960 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1026)
  br i1 %5960, label %convergence.target.49.ready, label %scheduler.loop

convergence.target.49.ready:                      ; preds = %convergence.cascade.exit1011
  %5961 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1026)
  %5962 = bitcast <8 x i1> %convergence.cascade.result1026 to i8
  %5963 = call i8 @llvm.cttz.i8(i8 %5962, i1 false)
  %5964 = zext i8 %5963 to i32
  %5965 = select i1 %5961, i32 %5964, i32 0
  %5966 = load <8 x i1>, ptr %live.mask, align 1
  %5967 = xor <8 x i1> %convergence.cascade.result1026, splat (i1 true)
  %5968 = and <8 x i1> %5966, %5967
  store <8 x i1> %5968, ptr %live.mask, align 1
  %5969 = load <8 x i1>, ptr %runnable.mask, align 1
  %5970 = xor <8 x i1> %convergence.cascade.result1026, splat (i1 true)
  %5971 = and <8 x i1> %5969, %5970
  store <8 x i1> %5971, ptr %runnable.mask, align 1
  %return.active.frames = load i8, ptr %frame.active, align 1
  %return.frames.present = icmp ne i8 %return.active.frames, 0
  br i1 %return.frames.present, label %return.frame.cleanup, label %return.frame.cleanup.done

return.frame.cleanup:                             ; preds = %convergence.target.49.ready
  %5972 = load i8, ptr %frame.active, align 1
  %5973 = and i8 %5972, 1
  %5974 = icmp ne i8 %5973, 0
  %5975 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 0
  %5976 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 0
  %5977 = load <8 x i1>, ptr %5975, align 1
  %5978 = load <8 x i1>, ptr %5976, align 1
  %5979 = and <8 x i1> %5977, %5968
  %5980 = icmp eq <8 x i1> %5978, %5979
  %5981 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5980)
  %5982 = and i1 %5974, %5981
  %.splatinsert1027 = insertelement <8 x i1> poison, i1 %5982, i64 0
  %.splat1028 = shufflevector <8 x i1> %.splatinsert1027, <8 x i1> poison, <8 x i32> zeroinitializer
  %5983 = select <8 x i1> %.splat1028, <8 x i1> %5978, <8 x i1> zeroinitializer
  %5984 = select i1 %5982, <8 x i1> zeroinitializer, <8 x i1> %5979
  store <8 x i1> %5984, ptr %5975, align 1
  %5985 = select i1 %5982, <8 x i1> zeroinitializer, <8 x i1> %5978
  store <8 x i1> %5985, ptr %5976, align 1
  %5986 = and i8 %5972, -2
  %5987 = select i1 %5982, i8 %5986, i8 %5972
  store i8 %5987, ptr %frame.active, align 1
  %5988 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5989 = extractelement <8 x i32> %5988, i32 0
  %5990 = load <8 x i32>, ptr %frame.static.id, align 32
  %5991 = extractelement <8 x i32> %5990, i32 0
  %convergence.target.pointer1029 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %5991
  %convergence.dynamic.target1030 = load i32, ptr %convergence.target.pointer1029, align 4
  %5992 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5983)
  %5993 = load i32, ptr %ready.count, align 4
  %5994 = icmp uge i32 %5993, 8
  %5995 = and i1 %5992, %5994
  br i1 %5995, label %ready.overflow.trap1031, label %ready.overflow.resume1032

return.frame.cleanup.done:                        ; preds = %ready.overflow.resume1074, %convergence.target.49.ready
  br label %scheduler.loop

ready.overflow.trap1031:                          ; preds = %return.frame.cleanup
  call void @llvm.trap()
  unreachable

ready.overflow.resume1032:                        ; preds = %return.frame.cleanup
  %5996 = select i1 %5992, i32 %5993, i32 0
  %5997 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5996
  %5998 = load <8 x i1>, ptr %5997, align 1
  %5999 = select i1 %5992, <8 x i1> %5983, <8 x i1> %5998
  store <8 x i1> %5999, ptr %5997, align 1
  %6000 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5996
  %6001 = load i32, ptr %6000, align 4
  %6002 = select i1 %5992, i32 %convergence.dynamic.target1030, i32 %6001
  store i32 %6002, ptr %6000, align 4
  %6003 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5996
  %6004 = load i32, ptr %6003, align 4
  %6005 = select i1 %5992, i32 %5989, i32 %6004
  store i32 %6005, ptr %6003, align 4
  %6006 = add i32 %5993, 1
  %6007 = select i1 %5992, i32 %6006, i32 %5993
  store i32 %6007, ptr %ready.count, align 4
  %6008 = load <8 x i1>, ptr %runnable.mask, align 1
  %6009 = or <8 x i1> %6008, %5983
  store <8 x i1> %6009, ptr %runnable.mask, align 1
  %6010 = load i8, ptr %frame.active, align 1
  %6011 = and i8 %6010, 2
  %6012 = icmp ne i8 %6011, 0
  %6013 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 1
  %6014 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 1
  %6015 = load <8 x i1>, ptr %6013, align 1
  %6016 = load <8 x i1>, ptr %6014, align 1
  %6017 = and <8 x i1> %6015, %5968
  %6018 = icmp eq <8 x i1> %6016, %6017
  %6019 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6018)
  %6020 = and i1 %6012, %6019
  %.splatinsert1033 = insertelement <8 x i1> poison, i1 %6020, i64 0
  %.splat1034 = shufflevector <8 x i1> %.splatinsert1033, <8 x i1> poison, <8 x i32> zeroinitializer
  %6021 = select <8 x i1> %.splat1034, <8 x i1> %6016, <8 x i1> zeroinitializer
  %6022 = select i1 %6020, <8 x i1> zeroinitializer, <8 x i1> %6017
  store <8 x i1> %6022, ptr %6013, align 1
  %6023 = select i1 %6020, <8 x i1> zeroinitializer, <8 x i1> %6016
  store <8 x i1> %6023, ptr %6014, align 1
  %6024 = and i8 %6010, -3
  %6025 = select i1 %6020, i8 %6024, i8 %6010
  store i8 %6025, ptr %frame.active, align 1
  %6026 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6027 = extractelement <8 x i32> %6026, i32 1
  %6028 = load <8 x i32>, ptr %frame.static.id, align 32
  %6029 = extractelement <8 x i32> %6028, i32 1
  %convergence.target.pointer1035 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %6029
  %convergence.dynamic.target1036 = load i32, ptr %convergence.target.pointer1035, align 4
  %6030 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6021)
  %6031 = load i32, ptr %ready.count, align 4
  %6032 = icmp uge i32 %6031, 8
  %6033 = and i1 %6030, %6032
  br i1 %6033, label %ready.overflow.trap1037, label %ready.overflow.resume1038

ready.overflow.trap1037:                          ; preds = %ready.overflow.resume1032
  call void @llvm.trap()
  unreachable

ready.overflow.resume1038:                        ; preds = %ready.overflow.resume1032
  %6034 = select i1 %6030, i32 %6031, i32 0
  %6035 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6034
  %6036 = load <8 x i1>, ptr %6035, align 1
  %6037 = select i1 %6030, <8 x i1> %6021, <8 x i1> %6036
  store <8 x i1> %6037, ptr %6035, align 1
  %6038 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6034
  %6039 = load i32, ptr %6038, align 4
  %6040 = select i1 %6030, i32 %convergence.dynamic.target1036, i32 %6039
  store i32 %6040, ptr %6038, align 4
  %6041 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6034
  %6042 = load i32, ptr %6041, align 4
  %6043 = select i1 %6030, i32 %6027, i32 %6042
  store i32 %6043, ptr %6041, align 4
  %6044 = add i32 %6031, 1
  %6045 = select i1 %6030, i32 %6044, i32 %6031
  store i32 %6045, ptr %ready.count, align 4
  %6046 = load <8 x i1>, ptr %runnable.mask, align 1
  %6047 = or <8 x i1> %6046, %6021
  store <8 x i1> %6047, ptr %runnable.mask, align 1
  %6048 = load i8, ptr %frame.active, align 1
  %6049 = and i8 %6048, 4
  %6050 = icmp ne i8 %6049, 0
  %6051 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 2
  %6052 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 2
  %6053 = load <8 x i1>, ptr %6051, align 1
  %6054 = load <8 x i1>, ptr %6052, align 1
  %6055 = and <8 x i1> %6053, %5968
  %6056 = icmp eq <8 x i1> %6054, %6055
  %6057 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6056)
  %6058 = and i1 %6050, %6057
  %.splatinsert1039 = insertelement <8 x i1> poison, i1 %6058, i64 0
  %.splat1040 = shufflevector <8 x i1> %.splatinsert1039, <8 x i1> poison, <8 x i32> zeroinitializer
  %6059 = select <8 x i1> %.splat1040, <8 x i1> %6054, <8 x i1> zeroinitializer
  %6060 = select i1 %6058, <8 x i1> zeroinitializer, <8 x i1> %6055
  store <8 x i1> %6060, ptr %6051, align 1
  %6061 = select i1 %6058, <8 x i1> zeroinitializer, <8 x i1> %6054
  store <8 x i1> %6061, ptr %6052, align 1
  %6062 = and i8 %6048, -5
  %6063 = select i1 %6058, i8 %6062, i8 %6048
  store i8 %6063, ptr %frame.active, align 1
  %6064 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6065 = extractelement <8 x i32> %6064, i32 2
  %6066 = load <8 x i32>, ptr %frame.static.id, align 32
  %6067 = extractelement <8 x i32> %6066, i32 2
  %convergence.target.pointer1041 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %6067
  %convergence.dynamic.target1042 = load i32, ptr %convergence.target.pointer1041, align 4
  %6068 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6059)
  %6069 = load i32, ptr %ready.count, align 4
  %6070 = icmp uge i32 %6069, 8
  %6071 = and i1 %6068, %6070
  br i1 %6071, label %ready.overflow.trap1043, label %ready.overflow.resume1044

ready.overflow.trap1043:                          ; preds = %ready.overflow.resume1038
  call void @llvm.trap()
  unreachable

ready.overflow.resume1044:                        ; preds = %ready.overflow.resume1038
  %6072 = select i1 %6068, i32 %6069, i32 0
  %6073 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6072
  %6074 = load <8 x i1>, ptr %6073, align 1
  %6075 = select i1 %6068, <8 x i1> %6059, <8 x i1> %6074
  store <8 x i1> %6075, ptr %6073, align 1
  %6076 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6072
  %6077 = load i32, ptr %6076, align 4
  %6078 = select i1 %6068, i32 %convergence.dynamic.target1042, i32 %6077
  store i32 %6078, ptr %6076, align 4
  %6079 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6072
  %6080 = load i32, ptr %6079, align 4
  %6081 = select i1 %6068, i32 %6065, i32 %6080
  store i32 %6081, ptr %6079, align 4
  %6082 = add i32 %6069, 1
  %6083 = select i1 %6068, i32 %6082, i32 %6069
  store i32 %6083, ptr %ready.count, align 4
  %6084 = load <8 x i1>, ptr %runnable.mask, align 1
  %6085 = or <8 x i1> %6084, %6059
  store <8 x i1> %6085, ptr %runnable.mask, align 1
  %6086 = load i8, ptr %frame.active, align 1
  %6087 = and i8 %6086, 8
  %6088 = icmp ne i8 %6087, 0
  %6089 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 3
  %6090 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 3
  %6091 = load <8 x i1>, ptr %6089, align 1
  %6092 = load <8 x i1>, ptr %6090, align 1
  %6093 = and <8 x i1> %6091, %5968
  %6094 = icmp eq <8 x i1> %6092, %6093
  %6095 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6094)
  %6096 = and i1 %6088, %6095
  %.splatinsert1045 = insertelement <8 x i1> poison, i1 %6096, i64 0
  %.splat1046 = shufflevector <8 x i1> %.splatinsert1045, <8 x i1> poison, <8 x i32> zeroinitializer
  %6097 = select <8 x i1> %.splat1046, <8 x i1> %6092, <8 x i1> zeroinitializer
  %6098 = select i1 %6096, <8 x i1> zeroinitializer, <8 x i1> %6093
  store <8 x i1> %6098, ptr %6089, align 1
  %6099 = select i1 %6096, <8 x i1> zeroinitializer, <8 x i1> %6092
  store <8 x i1> %6099, ptr %6090, align 1
  %6100 = and i8 %6086, -9
  %6101 = select i1 %6096, i8 %6100, i8 %6086
  store i8 %6101, ptr %frame.active, align 1
  %6102 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6103 = extractelement <8 x i32> %6102, i32 3
  %6104 = load <8 x i32>, ptr %frame.static.id, align 32
  %6105 = extractelement <8 x i32> %6104, i32 3
  %convergence.target.pointer1047 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %6105
  %convergence.dynamic.target1048 = load i32, ptr %convergence.target.pointer1047, align 4
  %6106 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6097)
  %6107 = load i32, ptr %ready.count, align 4
  %6108 = icmp uge i32 %6107, 8
  %6109 = and i1 %6106, %6108
  br i1 %6109, label %ready.overflow.trap1049, label %ready.overflow.resume1050

ready.overflow.trap1049:                          ; preds = %ready.overflow.resume1044
  call void @llvm.trap()
  unreachable

ready.overflow.resume1050:                        ; preds = %ready.overflow.resume1044
  %6110 = select i1 %6106, i32 %6107, i32 0
  %6111 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6110
  %6112 = load <8 x i1>, ptr %6111, align 1
  %6113 = select i1 %6106, <8 x i1> %6097, <8 x i1> %6112
  store <8 x i1> %6113, ptr %6111, align 1
  %6114 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6110
  %6115 = load i32, ptr %6114, align 4
  %6116 = select i1 %6106, i32 %convergence.dynamic.target1048, i32 %6115
  store i32 %6116, ptr %6114, align 4
  %6117 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6110
  %6118 = load i32, ptr %6117, align 4
  %6119 = select i1 %6106, i32 %6103, i32 %6118
  store i32 %6119, ptr %6117, align 4
  %6120 = add i32 %6107, 1
  %6121 = select i1 %6106, i32 %6120, i32 %6107
  store i32 %6121, ptr %ready.count, align 4
  %6122 = load <8 x i1>, ptr %runnable.mask, align 1
  %6123 = or <8 x i1> %6122, %6097
  store <8 x i1> %6123, ptr %runnable.mask, align 1
  %6124 = load i8, ptr %frame.active, align 1
  %6125 = and i8 %6124, 16
  %6126 = icmp ne i8 %6125, 0
  %6127 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 4
  %6128 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 4
  %6129 = load <8 x i1>, ptr %6127, align 1
  %6130 = load <8 x i1>, ptr %6128, align 1
  %6131 = and <8 x i1> %6129, %5968
  %6132 = icmp eq <8 x i1> %6130, %6131
  %6133 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6132)
  %6134 = and i1 %6126, %6133
  %.splatinsert1051 = insertelement <8 x i1> poison, i1 %6134, i64 0
  %.splat1052 = shufflevector <8 x i1> %.splatinsert1051, <8 x i1> poison, <8 x i32> zeroinitializer
  %6135 = select <8 x i1> %.splat1052, <8 x i1> %6130, <8 x i1> zeroinitializer
  %6136 = select i1 %6134, <8 x i1> zeroinitializer, <8 x i1> %6131
  store <8 x i1> %6136, ptr %6127, align 1
  %6137 = select i1 %6134, <8 x i1> zeroinitializer, <8 x i1> %6130
  store <8 x i1> %6137, ptr %6128, align 1
  %6138 = and i8 %6124, -17
  %6139 = select i1 %6134, i8 %6138, i8 %6124
  store i8 %6139, ptr %frame.active, align 1
  %6140 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6141 = extractelement <8 x i32> %6140, i32 4
  %6142 = load <8 x i32>, ptr %frame.static.id, align 32
  %6143 = extractelement <8 x i32> %6142, i32 4
  %convergence.target.pointer1053 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %6143
  %convergence.dynamic.target1054 = load i32, ptr %convergence.target.pointer1053, align 4
  %6144 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6135)
  %6145 = load i32, ptr %ready.count, align 4
  %6146 = icmp uge i32 %6145, 8
  %6147 = and i1 %6144, %6146
  br i1 %6147, label %ready.overflow.trap1055, label %ready.overflow.resume1056

ready.overflow.trap1055:                          ; preds = %ready.overflow.resume1050
  call void @llvm.trap()
  unreachable

ready.overflow.resume1056:                        ; preds = %ready.overflow.resume1050
  %6148 = select i1 %6144, i32 %6145, i32 0
  %6149 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6148
  %6150 = load <8 x i1>, ptr %6149, align 1
  %6151 = select i1 %6144, <8 x i1> %6135, <8 x i1> %6150
  store <8 x i1> %6151, ptr %6149, align 1
  %6152 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6148
  %6153 = load i32, ptr %6152, align 4
  %6154 = select i1 %6144, i32 %convergence.dynamic.target1054, i32 %6153
  store i32 %6154, ptr %6152, align 4
  %6155 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6148
  %6156 = load i32, ptr %6155, align 4
  %6157 = select i1 %6144, i32 %6141, i32 %6156
  store i32 %6157, ptr %6155, align 4
  %6158 = add i32 %6145, 1
  %6159 = select i1 %6144, i32 %6158, i32 %6145
  store i32 %6159, ptr %ready.count, align 4
  %6160 = load <8 x i1>, ptr %runnable.mask, align 1
  %6161 = or <8 x i1> %6160, %6135
  store <8 x i1> %6161, ptr %runnable.mask, align 1
  %6162 = load i8, ptr %frame.active, align 1
  %6163 = and i8 %6162, 32
  %6164 = icmp ne i8 %6163, 0
  %6165 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 5
  %6166 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 5
  %6167 = load <8 x i1>, ptr %6165, align 1
  %6168 = load <8 x i1>, ptr %6166, align 1
  %6169 = and <8 x i1> %6167, %5968
  %6170 = icmp eq <8 x i1> %6168, %6169
  %6171 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6170)
  %6172 = and i1 %6164, %6171
  %.splatinsert1057 = insertelement <8 x i1> poison, i1 %6172, i64 0
  %.splat1058 = shufflevector <8 x i1> %.splatinsert1057, <8 x i1> poison, <8 x i32> zeroinitializer
  %6173 = select <8 x i1> %.splat1058, <8 x i1> %6168, <8 x i1> zeroinitializer
  %6174 = select i1 %6172, <8 x i1> zeroinitializer, <8 x i1> %6169
  store <8 x i1> %6174, ptr %6165, align 1
  %6175 = select i1 %6172, <8 x i1> zeroinitializer, <8 x i1> %6168
  store <8 x i1> %6175, ptr %6166, align 1
  %6176 = and i8 %6162, -33
  %6177 = select i1 %6172, i8 %6176, i8 %6162
  store i8 %6177, ptr %frame.active, align 1
  %6178 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6179 = extractelement <8 x i32> %6178, i32 5
  %6180 = load <8 x i32>, ptr %frame.static.id, align 32
  %6181 = extractelement <8 x i32> %6180, i32 5
  %convergence.target.pointer1059 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %6181
  %convergence.dynamic.target1060 = load i32, ptr %convergence.target.pointer1059, align 4
  %6182 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6173)
  %6183 = load i32, ptr %ready.count, align 4
  %6184 = icmp uge i32 %6183, 8
  %6185 = and i1 %6182, %6184
  br i1 %6185, label %ready.overflow.trap1061, label %ready.overflow.resume1062

ready.overflow.trap1061:                          ; preds = %ready.overflow.resume1056
  call void @llvm.trap()
  unreachable

ready.overflow.resume1062:                        ; preds = %ready.overflow.resume1056
  %6186 = select i1 %6182, i32 %6183, i32 0
  %6187 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6186
  %6188 = load <8 x i1>, ptr %6187, align 1
  %6189 = select i1 %6182, <8 x i1> %6173, <8 x i1> %6188
  store <8 x i1> %6189, ptr %6187, align 1
  %6190 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6186
  %6191 = load i32, ptr %6190, align 4
  %6192 = select i1 %6182, i32 %convergence.dynamic.target1060, i32 %6191
  store i32 %6192, ptr %6190, align 4
  %6193 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6186
  %6194 = load i32, ptr %6193, align 4
  %6195 = select i1 %6182, i32 %6179, i32 %6194
  store i32 %6195, ptr %6193, align 4
  %6196 = add i32 %6183, 1
  %6197 = select i1 %6182, i32 %6196, i32 %6183
  store i32 %6197, ptr %ready.count, align 4
  %6198 = load <8 x i1>, ptr %runnable.mask, align 1
  %6199 = or <8 x i1> %6198, %6173
  store <8 x i1> %6199, ptr %runnable.mask, align 1
  %6200 = load i8, ptr %frame.active, align 1
  %6201 = and i8 %6200, 64
  %6202 = icmp ne i8 %6201, 0
  %6203 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 6
  %6204 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 6
  %6205 = load <8 x i1>, ptr %6203, align 1
  %6206 = load <8 x i1>, ptr %6204, align 1
  %6207 = and <8 x i1> %6205, %5968
  %6208 = icmp eq <8 x i1> %6206, %6207
  %6209 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6208)
  %6210 = and i1 %6202, %6209
  %.splatinsert1063 = insertelement <8 x i1> poison, i1 %6210, i64 0
  %.splat1064 = shufflevector <8 x i1> %.splatinsert1063, <8 x i1> poison, <8 x i32> zeroinitializer
  %6211 = select <8 x i1> %.splat1064, <8 x i1> %6206, <8 x i1> zeroinitializer
  %6212 = select i1 %6210, <8 x i1> zeroinitializer, <8 x i1> %6207
  store <8 x i1> %6212, ptr %6203, align 1
  %6213 = select i1 %6210, <8 x i1> zeroinitializer, <8 x i1> %6206
  store <8 x i1> %6213, ptr %6204, align 1
  %6214 = and i8 %6200, -65
  %6215 = select i1 %6210, i8 %6214, i8 %6200
  store i8 %6215, ptr %frame.active, align 1
  %6216 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6217 = extractelement <8 x i32> %6216, i32 6
  %6218 = load <8 x i32>, ptr %frame.static.id, align 32
  %6219 = extractelement <8 x i32> %6218, i32 6
  %convergence.target.pointer1065 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %6219
  %convergence.dynamic.target1066 = load i32, ptr %convergence.target.pointer1065, align 4
  %6220 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6211)
  %6221 = load i32, ptr %ready.count, align 4
  %6222 = icmp uge i32 %6221, 8
  %6223 = and i1 %6220, %6222
  br i1 %6223, label %ready.overflow.trap1067, label %ready.overflow.resume1068

ready.overflow.trap1067:                          ; preds = %ready.overflow.resume1062
  call void @llvm.trap()
  unreachable

ready.overflow.resume1068:                        ; preds = %ready.overflow.resume1062
  %6224 = select i1 %6220, i32 %6221, i32 0
  %6225 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6224
  %6226 = load <8 x i1>, ptr %6225, align 1
  %6227 = select i1 %6220, <8 x i1> %6211, <8 x i1> %6226
  store <8 x i1> %6227, ptr %6225, align 1
  %6228 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6224
  %6229 = load i32, ptr %6228, align 4
  %6230 = select i1 %6220, i32 %convergence.dynamic.target1066, i32 %6229
  store i32 %6230, ptr %6228, align 4
  %6231 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6224
  %6232 = load i32, ptr %6231, align 4
  %6233 = select i1 %6220, i32 %6217, i32 %6232
  store i32 %6233, ptr %6231, align 4
  %6234 = add i32 %6221, 1
  %6235 = select i1 %6220, i32 %6234, i32 %6221
  store i32 %6235, ptr %ready.count, align 4
  %6236 = load <8 x i1>, ptr %runnable.mask, align 1
  %6237 = or <8 x i1> %6236, %6211
  store <8 x i1> %6237, ptr %runnable.mask, align 1
  %6238 = load i8, ptr %frame.active, align 1
  %6239 = and i8 %6238, -128
  %6240 = icmp ne i8 %6239, 0
  %6241 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 7
  %6242 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 7
  %6243 = load <8 x i1>, ptr %6241, align 1
  %6244 = load <8 x i1>, ptr %6242, align 1
  %6245 = and <8 x i1> %6243, %5968
  %6246 = icmp eq <8 x i1> %6244, %6245
  %6247 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6246)
  %6248 = and i1 %6240, %6247
  %.splatinsert1069 = insertelement <8 x i1> poison, i1 %6248, i64 0
  %.splat1070 = shufflevector <8 x i1> %.splatinsert1069, <8 x i1> poison, <8 x i32> zeroinitializer
  %6249 = select <8 x i1> %.splat1070, <8 x i1> %6244, <8 x i1> zeroinitializer
  %6250 = select i1 %6248, <8 x i1> zeroinitializer, <8 x i1> %6245
  store <8 x i1> %6250, ptr %6241, align 1
  %6251 = select i1 %6248, <8 x i1> zeroinitializer, <8 x i1> %6244
  store <8 x i1> %6251, ptr %6242, align 1
  %6252 = and i8 %6238, 127
  %6253 = select i1 %6248, i8 %6252, i8 %6238
  store i8 %6253, ptr %frame.active, align 1
  %6254 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6255 = extractelement <8 x i32> %6254, i32 7
  %6256 = load <8 x i32>, ptr %frame.static.id, align 32
  %6257 = extractelement <8 x i32> %6256, i32 7
  %convergence.target.pointer1071 = getelementptr inbounds [18 x i32], ptr @convergence.targets, i32 0, i32 %6257
  %convergence.dynamic.target1072 = load i32, ptr %convergence.target.pointer1071, align 4
  %6258 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6249)
  %6259 = load i32, ptr %ready.count, align 4
  %6260 = icmp uge i32 %6259, 8
  %6261 = and i1 %6258, %6260
  br i1 %6261, label %ready.overflow.trap1073, label %ready.overflow.resume1074

ready.overflow.trap1073:                          ; preds = %ready.overflow.resume1068
  call void @llvm.trap()
  unreachable

ready.overflow.resume1074:                        ; preds = %ready.overflow.resume1068
  %6262 = select i1 %6258, i32 %6259, i32 0
  %6263 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6262
  %6264 = load <8 x i1>, ptr %6263, align 1
  %6265 = select i1 %6258, <8 x i1> %6249, <8 x i1> %6264
  store <8 x i1> %6265, ptr %6263, align 1
  %6266 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6262
  %6267 = load i32, ptr %6266, align 4
  %6268 = select i1 %6258, i32 %convergence.dynamic.target1072, i32 %6267
  store i32 %6268, ptr %6266, align 4
  %6269 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6262
  %6270 = load i32, ptr %6269, align 4
  %6271 = select i1 %6258, i32 %6255, i32 %6270
  store i32 %6271, ptr %6269, align 4
  %6272 = add i32 %6259, 1
  %6273 = select i1 %6258, i32 %6272, i32 %6259
  store i32 %6273, ptr %ready.count, align 4
  %6274 = load <8 x i1>, ptr %runnable.mask, align 1
  %6275 = or <8 x i1> %6274, %6249
  store <8 x i1> %6275, ptr %runnable.mask, align 1
  br label %return.frame.cleanup.done
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.and.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x i64>) #2

define dso_local void @tile_inclusive_scan.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(write) }

; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

@convergence.targets = private unnamed_addr constant [20 x i32] [i32 53, i32 7, i32 6, i32 12, i32 11, i32 15, i32 20, i32 19, i32 23, i32 28, i32 27, i32 31, i32 36, i32 35, i32 39, i32 44, i32 43, i32 47, i32 52, i32 51], align 4

define internal void @tile_inclusive_scan(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %live.mask = alloca <8 x i1>, align 1
  %runnable.mask = alloca <8 x i1>, align 1
  %ready.count = alloca i32, align 4
  %ready.mask = alloca [8 x <8 x i1>], align 1
  %ready.target = alloca [8 x i32], align 4
  %ready.token = alloca [8 x i32], align 4
  %current.mask = alloca <8 x i1>, align 1
  %current.token = alloca i32, align 4
  %frame.active = alloca i8, align 1
  %frame.static.id = alloca <8 x i32>, align 32
  %frame.parent.token = alloca <8 x i32>, align 32
  %frame.expected = alloca [8 x <8 x i1>], align 1
  %frame.arrived = alloca [8 x <8 x i1>], align 1
  store <8 x i1> zeroinitializer, ptr %live.mask, align 1
  store <8 x i1> zeroinitializer, ptr %runnable.mask, align 1
  store i32 0, ptr %ready.count, align 4
  store [8 x <8 x i1>] zeroinitializer, ptr %ready.mask, align 1
  store [8 x i32] zeroinitializer, ptr %ready.target, align 4
  store [8 x i32] zeroinitializer, ptr %ready.token, align 4
  store <8 x i1> zeroinitializer, ptr %current.mask, align 1
  store i32 0, ptr %current.token, align 4
  store i8 0, ptr %frame.active, align 1
  store <8 x i32> zeroinitializer, ptr %frame.static.id, align 32
  store <8 x i32> zeroinitializer, ptr %frame.parent.token, align 32
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.expected, align 1
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.arrived, align 1
  %tile_snapshot.local = alloca [128 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [4096 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local4 = alloca [2048 x i8], align 8
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local7 = alloca [4096 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local10 = alloca [4096 x i8], align 4
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %8 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %9 = insertvalue { <8 x ptr>, <8 x i64> } %8, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local13 = alloca [2048 x i8], align 8
  %.splatinsert14 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local13, i64 0
  %.splat15 = shufflevector <8 x ptr> %.splatinsert14, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat15, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local16 = alloca [4096 x i8], align 4
  %.splatinsert17 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local16, i64 0
  %.splat18 = shufflevector <8 x ptr> %.splatinsert17, <8 x ptr> poison, <8 x i32> zeroinitializer
  %12 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat18, 0
  %13 = insertvalue { <8 x ptr>, <8 x i64> } %12, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local19 = alloca [4096 x i8], align 4
  %.splatinsert20 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local19, i64 0
  %.splat21 = shufflevector <8 x ptr> %.splatinsert20, <8 x ptr> poison, <8 x i32> zeroinitializer
  %14 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat21, 0
  %15 = insertvalue { <8 x ptr>, <8 x i64> } %14, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local22 = alloca [2048 x i8], align 8
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local25 = alloca [4096 x i8], align 4
  %.splatinsert26 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local25, i64 0
  %.splat27 = shufflevector <8 x ptr> %.splatinsert26, <8 x ptr> poison, <8 x i32> zeroinitializer
  %18 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat27, 0
  %19 = insertvalue { <8 x ptr>, <8 x i64> } %18, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local28 = alloca [4096 x i8], align 4
  %.splatinsert29 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local28, i64 0
  %.splat30 = shufflevector <8 x ptr> %.splatinsert29, <8 x ptr> poison, <8 x i32> zeroinitializer
  %20 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat30, 0
  %21 = insertvalue { <8 x ptr>, <8 x i64> } %20, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local31 = alloca [2048 x i8], align 8
  %.splatinsert32 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local31, i64 0
  %.splat33 = shufflevector <8 x ptr> %.splatinsert32, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat33, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local34 = alloca [4096 x i8], align 4
  %.splatinsert35 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local34, i64 0
  %.splat36 = shufflevector <8 x ptr> %.splatinsert35, <8 x ptr> poison, <8 x i32> zeroinitializer
  %24 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat36, 0
  %25 = insertvalue { <8 x ptr>, <8 x i64> } %24, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local37 = alloca [4096 x i8], align 4
  %.splatinsert38 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local37, i64 0
  %.splat39 = shufflevector <8 x ptr> %.splatinsert38, <8 x ptr> poison, <8 x i32> zeroinitializer
  %26 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat39, 0
  %27 = insertvalue { <8 x ptr>, <8 x i64> } %26, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local40 = alloca [2048 x i8], align 8
  %.splatinsert41 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local40, i64 0
  %.splat42 = shufflevector <8 x ptr> %.splatinsert41, <8 x ptr> poison, <8 x i32> zeroinitializer
  %28 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat42, 0
  %29 = insertvalue { <8 x ptr>, <8 x i64> } %28, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local43 = alloca [4096 x i8], align 4
  %.splatinsert44 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local43, i64 0
  %.splat45 = shufflevector <8 x ptr> %.splatinsert44, <8 x ptr> poison, <8 x i32> zeroinitializer
  %30 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat45, 0
  %31 = insertvalue { <8 x ptr>, <8 x i64> } %30, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local46 = alloca [4096 x i8], align 4
  %.splatinsert47 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local46, i64 0
  %.splat48 = shufflevector <8 x ptr> %.splatinsert47, <8 x ptr> poison, <8 x i32> zeroinitializer
  %32 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat48, 0
  %33 = insertvalue { <8 x ptr>, <8 x i64> } %32, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill49 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill49, align 4
  %.slot = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot, align 64
  %.slot50 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.slot50, align 32
  %.slot51 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.slot51, align 32
  %.slot52 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.slot52, align 32
  %.slot53 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.slot53, align 32
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.spill54 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill54, align 64
  %tile_snapshot.spill55 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill55, align 64
  %.slot56 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot56, align 64
  %.spill57 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill57, align 64
  %.slot58 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot58, align 32
  %tile_snapshot.spill59 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill59, align 64
  %tile_snapshot.spill60 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill60, align 64
  %.slot61 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot61, align 64
  %.spill62 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill62, align 1
  %.spill63 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill63, align 64
  %.slot64 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot64, align 32
  %tile_snapshot.spill65 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill65, align 64
  %.slot66 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot66, align 64
  %tile_snapshot.spill67 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill67, align 64
  %tile_snapshot.spill68 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill68, align 64
  %.slot69 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot69, align 64
  %.spill70 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill70, align 1
  %.spill71 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill71, align 64
  %.slot72 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot72, align 32
  %tile_snapshot.spill73 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill73, align 64
  %.slot74 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot74, align 64
  %tile_snapshot.spill75 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill75, align 64
  %tile_snapshot.spill76 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill76, align 64
  %.slot77 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot77, align 64
  %.spill78 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill78, align 1
  %.spill79 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill79, align 64
  %.slot80 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot80, align 32
  %tile_snapshot.spill81 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill81, align 64
  %.slot82 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot82, align 64
  %tile_snapshot.spill83 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill83, align 64
  %tile_snapshot.spill84 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill84, align 64
  %.slot85 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot85, align 64
  %.spill86 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill86, align 1
  %.spill87 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill87, align 64
  %.slot88 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot88, align 32
  %tile_snapshot.spill89 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill89, align 64
  %.slot90 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot90, align 64
  %tile_snapshot.spill91 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill91, align 64
  %tile_snapshot.spill92 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill92, align 64
  %.slot93 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot93, align 64
  %.spill94 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill94, align 1
  %.spill95 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill95, align 64
  %.slot96 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot96, align 32
  %tile_snapshot.spill97 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill97, align 64
  %.slot98 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot98, align 64
  %.slot99 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot99, align 64
  %.spill100 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill100, align 64
  %.spill101 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill101, align 32
  %34 = getelementptr i8, ptr %argument_buffer, i64 0
  %35 = load ptr, ptr %34, align 16
  %36 = getelementptr i8, ptr %34, i64 8
  %37 = load i64, ptr %36, align 8
  %38 = insertvalue { ptr, i64 } poison, ptr %35, 0
  %39 = insertvalue { ptr, i64 } %38, i64 %37, 1
  %40 = getelementptr i8, ptr %argument_buffer, i64 16
  %41 = load ptr, ptr %40, align 16
  %42 = getelementptr i8, ptr %40, i64 8
  %43 = load i64, ptr %42, align 8
  %44 = insertvalue { ptr, i64 } poison, ptr %41, 0
  %45 = insertvalue { ptr, i64 } %44, i64 %43, 1
  %46 = load i32, ptr %launch_config, align 4
  %47 = getelementptr i8, ptr %launch_config, i64 12
  %48 = load i32, ptr %47, align 4
  %49 = getelementptr i8, ptr %launch_config, i64 4
  %50 = load i32, ptr %49, align 4
  %51 = getelementptr i8, ptr %launch_config, i64 16
  %52 = load i32, ptr %51, align 4
  %53 = getelementptr i8, ptr %launch_config, i64 8
  %54 = load i32, ptr %53, align 4
  %55 = getelementptr i8, ptr %launch_config, i64 20
  %56 = load i32, ptr %55, align 4
  %57 = getelementptr i8, ptr %launch_config, i64 36
  %58 = load i32, ptr %57, align 4
  %.splatinsert102 = insertelement <8 x i32> poison, i32 %58, i64 0
  %.splat103 = shufflevector <8 x i32> %.splatinsert102, <8 x i32> poison, <8 x i32> zeroinitializer
  %59 = add <8 x i32> %.splat103, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %60 = mul i32 %46, 32
  %.splatinsert104 = insertelement <8 x i32> poison, i32 %60, i64 0
  %.splat105 = shufflevector <8 x i32> %.splatinsert104, <8 x i32> poison, <8 x i32> zeroinitializer
  %61 = add <8 x i32> %.splat105, %59
  %62 = mul i32 %50, 1
  %.splatinsert106 = insertelement <8 x i32> poison, i32 %62, i64 0
  %.splat107 = shufflevector <8 x i32> %.splatinsert106, <8 x i32> poison, <8 x i32> zeroinitializer
  %63 = add <8 x i32> %.splat107, zeroinitializer
  %64 = mul i32 %54, 1
  %.splatinsert108 = insertelement <8 x i32> poison, i32 %64, i64 0
  %.splat109 = shufflevector <8 x i32> %.splatinsert108, <8 x i32> poison, <8 x i32> zeroinitializer
  %65 = add <8 x i32> %.splat109, zeroinitializer
  %66 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %61, 0
  %67 = insertvalue [3 x <8 x i32>] %66, <8 x i32> %63, 1
  %68 = insertvalue [3 x <8 x i32>] %67, <8 x i32> %65, 2
  %.splatinsert110 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat111 = shufflevector <8 x i32> %.splatinsert110, <8 x i32> poison, <8 x i32> zeroinitializer
  %69 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat111
  store <8 x i1> %69, ptr %live.mask, align 1
  %70 = load i32, ptr %current.token, align 4
  %71 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %69)
  %72 = load i32, ptr %ready.count, align 4
  %73 = icmp uge i32 %72, 8
  %74 = and i1 %71, %73
  br i1 %74, label %ready.overflow.trap, label %ready.overflow.resume

ready.overflow.trap:                              ; preds = %prologue
  call void @llvm.trap()
  unreachable

ready.overflow.resume:                            ; preds = %prologue
  %75 = select i1 %71, i32 %72, i32 0
  %76 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %75
  %77 = load <8 x i1>, ptr %76, align 1
  %78 = select i1 %71, <8 x i1> %69, <8 x i1> %77
  store <8 x i1> %78, ptr %76, align 1
  %79 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %75
  %80 = load i32, ptr %79, align 4
  %81 = select i1 %71, i32 0, i32 %80
  store i32 %81, ptr %79, align 4
  %82 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %75
  %83 = load i32, ptr %82, align 4
  %84 = select i1 %71, i32 %70, i32 %83
  store i32 %84, ptr %82, align 4
  %85 = add i32 %72, 1
  %86 = select i1 %71, i32 %85, i32 %72
  store i32 %86, ptr %ready.count, align 4
  %87 = load <8 x i1>, ptr %runnable.mask, align 1
  %88 = or <8 x i1> %87, %69
  store <8 x i1> %88, ptr %runnable.mask, align 1
  br label %scheduler.loop

scheduler.loop:                                   ; preds = %return.frame.cleanup.done, %convergence.cascade.exit1057, %convergence.target.52.ready, %convergence.cascade.exit1028, %convergence.target.51.ready, %convergence.cascade.exit1010, %schedule.50, %varying.coherent.false1006, %varying.coherent.true1005, %varying.coherent.false992, %varying.coherent.true991, %convergence.target.47.ready, %convergence.cascade.exit968, %schedule.46, %varying.coherent.false958, %varying.coherent.true957, %convergence.target.44.ready, %convergence.cascade.exit934, %convergence.target.43.ready, %convergence.cascade.exit909, %schedule.42, %varying.coherent.false905, %varying.coherent.true904, %varying.coherent.false894, %varying.coherent.true893, %convergence.target.39.ready, %convergence.cascade.exit806, %schedule.38, %varying.coherent.false797, %varying.coherent.true796, %convergence.target.36.ready, %convergence.cascade.exit773, %convergence.target.35.ready, %convergence.cascade.exit748, %schedule.34, %varying.coherent.false744, %varying.coherent.true743, %varying.coherent.false733, %varying.coherent.true732, %convergence.target.31.ready, %convergence.cascade.exit645, %schedule.30, %varying.coherent.false636, %varying.coherent.true635, %convergence.target.28.ready, %convergence.cascade.exit612, %convergence.target.27.ready, %convergence.cascade.exit587, %schedule.26, %varying.coherent.false583, %varying.coherent.true582, %varying.coherent.false572, %varying.coherent.true571, %convergence.target.23.ready, %convergence.cascade.exit484, %schedule.22, %varying.coherent.false475, %varying.coherent.true474, %convergence.target.20.ready, %convergence.cascade.exit451, %convergence.target.19.ready, %convergence.cascade.exit426, %schedule.18, %varying.coherent.false422, %varying.coherent.true421, %varying.coherent.false411, %varying.coherent.true410, %convergence.target.15.ready, %convergence.cascade.exit323, %schedule.14, %varying.coherent.false314, %varying.coherent.true313, %convergence.target.12.ready, %convergence.cascade.exit290, %convergence.target.11.ready, %convergence.cascade.exit265, %schedule.10, %varying.coherent.false261, %varying.coherent.true260, %varying.coherent.false250, %varying.coherent.true249, %convergence.target.7.ready, %convergence.cascade.exit162, %convergence.target.6.ready, %convergence.cascade.exit, %schedule.5, %varying.coherent.false147, %varying.coherent.true146, %varying.coherent.false133, %varying.coherent.true132, %schedule.2, %varying.coherent.false, %varying.coherent.true, %schedule.0, %ready.overflow.resume
  %89 = load i32, ptr %ready.count, align 4
  %90 = icmp ne i32 %89, 0
  br i1 %90, label %scheduler.dispatch, label %scheduler.done

scheduler.dispatch:                               ; preds = %scheduler.loop
  %91 = sub i32 %89, 1
  store i32 %91, ptr %ready.count, align 4
  %92 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %91
  %93 = load <8 x i1>, ptr %92, align 1
  store <8 x i1> %93, ptr %current.mask, align 1
  %94 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %91
  %95 = load i32, ptr %94, align 4
  %96 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %91
  %97 = load i32, ptr %96, align 4
  store i32 %97, ptr %current.token, align 4
  %98 = load <8 x i1>, ptr %runnable.mask, align 1
  %99 = xor <8 x i1> %93, splat (i1 true)
  %100 = and <8 x i1> %98, %99
  store <8 x i1> %100, ptr %runnable.mask, align 1
  br label %scheduler.dispatch.route

scheduler.dispatch.route:                         ; preds = %ready.overflow.resume1004, %ready.overflow.resume990, %ready.overflow.resume956, %ready.overflow.resume903, %ready.overflow.resume892, %ready.overflow.resume795, %ready.overflow.resume742, %ready.overflow.resume731, %ready.overflow.resume634, %ready.overflow.resume581, %ready.overflow.resume570, %ready.overflow.resume473, %ready.overflow.resume420, %ready.overflow.resume409, %ready.overflow.resume312, %ready.overflow.resume259, %ready.overflow.resume248, %ready.overflow.resume145, %ready.overflow.resume131, %ready.overflow.resume113, %scheduler.dispatch
  %scheduler.dispatch.pc = phi i32 [ %95, %scheduler.dispatch ], [ 53, %ready.overflow.resume113 ], [ 7, %ready.overflow.resume131 ], [ 6, %ready.overflow.resume145 ], [ 12, %ready.overflow.resume248 ], [ 11, %ready.overflow.resume259 ], [ 15, %ready.overflow.resume312 ], [ 20, %ready.overflow.resume409 ], [ 19, %ready.overflow.resume420 ], [ 23, %ready.overflow.resume473 ], [ 28, %ready.overflow.resume570 ], [ 27, %ready.overflow.resume581 ], [ 31, %ready.overflow.resume634 ], [ 36, %ready.overflow.resume731 ], [ 35, %ready.overflow.resume742 ], [ 39, %ready.overflow.resume795 ], [ 44, %ready.overflow.resume892 ], [ 43, %ready.overflow.resume903 ], [ 47, %ready.overflow.resume956 ], [ 52, %ready.overflow.resume990 ], [ 51, %ready.overflow.resume1004 ]
  switch i32 %scheduler.dispatch.pc, label %scheduler.invalid [
    i32 0, label %schedule.0
    i32 1, label %schedule.1
    i32 2, label %schedule.2
    i32 3, label %schedule.3
    i32 4, label %schedule.4
    i32 5, label %schedule.5
    i32 6, label %schedule.6
    i32 7, label %schedule.7
    i32 8, label %schedule.8
    i32 9, label %schedule.9
    i32 10, label %schedule.10
    i32 11, label %schedule.11
    i32 12, label %schedule.12
    i32 13, label %schedule.13
    i32 14, label %schedule.14
    i32 15, label %schedule.15
    i32 16, label %schedule.16
    i32 17, label %schedule.17
    i32 18, label %schedule.18
    i32 19, label %schedule.19
    i32 20, label %schedule.20
    i32 21, label %schedule.21
    i32 22, label %schedule.22
    i32 23, label %schedule.23
    i32 24, label %schedule.24
    i32 25, label %schedule.25
    i32 26, label %schedule.26
    i32 27, label %schedule.27
    i32 28, label %schedule.28
    i32 29, label %schedule.29
    i32 30, label %schedule.30
    i32 31, label %schedule.31
    i32 32, label %schedule.32
    i32 33, label %schedule.33
    i32 34, label %schedule.34
    i32 35, label %schedule.35
    i32 36, label %schedule.36
    i32 37, label %schedule.37
    i32 38, label %schedule.38
    i32 39, label %schedule.39
    i32 40, label %schedule.40
    i32 41, label %schedule.41
    i32 42, label %schedule.42
    i32 43, label %schedule.43
    i32 44, label %schedule.44
    i32 45, label %schedule.45
    i32 46, label %schedule.46
    i32 47, label %schedule.47
    i32 48, label %schedule.48
    i32 49, label %schedule.49
    i32 50, label %schedule.50
    i32 51, label %schedule.51
    i32 52, label %schedule.52
    i32 53, label %schedule.53
  ]

scheduler.done:                                   ; preds = %scheduler.loop
  %101 = load <8 x i1>, ptr %live.mask, align 1
  %102 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %101)
  br i1 %102, label %scheduler.stalled, label %scheduler.exit

scheduler.exit:                                   ; preds = %scheduler.done
  ret void

scheduler.stalled:                                ; preds = %scheduler.done
  call void @llvm.trap()
  unreachable

scheduler.invalid:                                ; preds = %scheduler.dispatch.route
  call void @llvm.trap()
  unreachable

schedule.0:                                       ; preds = %scheduler.dispatch.route
  %103 = load <8 x i1>, ptr %current.mask, align 1
  %104 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %103)
  %105 = bitcast <8 x i1> %103 to i8
  %106 = call i8 @llvm.cttz.i8(i8 %105, i1 false)
  %107 = zext i8 %106 to i32
  %108 = select i1 %104, i32 %107, i32 0
  %109 = extractvalue [3 x <8 x i32>] %68, 0
  %110 = zext <8 x i32> %109 to <8 x i64>
  %111 = select <8 x i1> %103, <8 x i64> %110, <8 x i64> zeroinitializer
  %112 = select <8 x i1> %103, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %113 = sdiv <8 x i64> %111, %112
  %114 = mul <8 x i64> %113, splat (i64 4)
  %115 = load volatile <8 x i64>, ptr %.spill, align 64
  %116 = select <8 x i1> %103, <8 x i64> %114, <8 x i64> %115
  store volatile <8 x i64> %116, ptr %.spill, align 64
  store float 0.000000e+00, ptr %.spill49, align 4
  %117 = load <8 x i64>, ptr %.slot, align 64
  %118 = select <8 x i1> %103, <8 x i64> zeroinitializer, <8 x i64> %117
  store <8 x i64> %118, ptr %.slot, align 64
  %119 = load volatile <8 x float>, ptr %.slot50, align 32
  %120 = select <8 x i1> %103, <8 x float> zeroinitializer, <8 x float> %119
  store volatile <8 x float> %120, ptr %.slot50, align 32
  %121 = load volatile <8 x float>, ptr %.slot51, align 32
  %122 = select <8 x i1> %103, <8 x float> zeroinitializer, <8 x float> %121
  store volatile <8 x float> %122, ptr %.slot51, align 32
  %123 = load volatile <8 x float>, ptr %.slot52, align 32
  %124 = select <8 x i1> %103, <8 x float> zeroinitializer, <8 x float> %123
  store volatile <8 x float> %124, ptr %.slot52, align 32
  %125 = load volatile <8 x float>, ptr %.slot53, align 32
  %126 = select <8 x i1> %103, <8 x float> zeroinitializer, <8 x float> %125
  store volatile <8 x float> %126, ptr %.slot53, align 32
  store <8 x i1> %103, ptr %current.mask, align 1
  %127 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %103)
  br i1 %127, label %schedule.1, label %scheduler.loop

schedule.1:                                       ; preds = %convergence.target.52.ready, %schedule.0, %scheduler.dispatch.route
  %128 = load <8 x i1>, ptr %current.mask, align 1
  %129 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %128)
  %130 = bitcast <8 x i1> %128 to i8
  %131 = call i8 @llvm.cttz.i8(i8 %130, i1 false)
  %132 = zext i8 %131 to i32
  %133 = select i1 %129, i32 %132, i32 0
  %.state = load <8 x i64>, ptr %.slot, align 64
  %134 = icmp slt <8 x i64> %.state, splat (i64 3)
  %135 = and <8 x i1> %128, %134
  %136 = xor <8 x i1> %134, splat (i1 true)
  %137 = and <8 x i1> %128, %136
  %138 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %135)
  %139 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %137)
  %140 = and i1 %138, %139
  br i1 %140, label %varying.divergent, label %varying.coherent

schedule.2:                                       ; preds = %varying.coherent.true, %scheduler.dispatch.route
  %141 = load <8 x i1>, ptr %current.mask, align 1
  %142 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %141)
  %143 = bitcast <8 x i1> %141 to i8
  %144 = call i8 @llvm.cttz.i8(i8 %143, i1 false)
  %145 = zext i8 %144 to i32
  %146 = select i1 %142, i32 %145, i32 0
  %147 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %148 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %147, 0
  %150 = select <8 x i1> %141, <8 x ptr> %148, <8 x ptr> %149
  %151 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %152 = extractvalue { <8 x ptr>, <8 x i64> } %147, 1
  %153 = select <8 x i1> %141, <8 x i64> %151, <8 x i64> %152
  %154 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %150, 0
  %155 = insertvalue { <8 x ptr>, <8 x i64> } %154, <8 x i64> %153, 1
  store volatile { <8 x ptr>, <8 x i64> } %155, ptr %tile_snapshot.spill, align 64
  %156 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %157 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %158 = add <8 x i64> %157, zeroinitializer
  %159 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %156, 0
  %160 = insertvalue { <8 x ptr>, <8 x i64> } %159, <8 x i64> %158, 1
  %.state114 = load volatile <8 x float>, ptr %.slot50, align 32
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %160, 1
  %163 = extractelement <8 x ptr> %161, i32 0
  %164 = extractelement <8 x i64> %162, i32 %146
  %165 = zext i32 %146 to i64
  %166 = mul i64 %165, 4
  %167 = sub i64 %164, %166
  %168 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %141)
  %169 = select i1 %168, i64 %167, i64 0
  %private.contiguous.address = getelementptr i8, ptr %163, i64 %169
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %170 = select <8 x i1> %141, <8 x float> %.state114, <8 x float> %private.contiguous.preserve
  store <8 x float> %170, ptr %private.contiguous.address, align 4
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %173 = add <8 x i64> %172, splat (i64 32)
  %174 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %171, 0
  %175 = insertvalue { <8 x ptr>, <8 x i64> } %174, <8 x i64> %173, 1
  %.state115 = load volatile <8 x float>, ptr %.slot51, align 32
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %177 = extractvalue { <8 x ptr>, <8 x i64> } %175, 1
  %178 = extractelement <8 x ptr> %176, i32 0
  %179 = extractelement <8 x i64> %177, i32 %146
  %180 = zext i32 %146 to i64
  %181 = mul i64 %180, 4
  %182 = sub i64 %179, %181
  %183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %141)
  %184 = select i1 %183, i64 %182, i64 0
  %private.contiguous.address116 = getelementptr i8, ptr %178, i64 %184
  %private.contiguous.preserve117 = load <8 x float>, ptr %private.contiguous.address116, align 4
  %185 = select <8 x i1> %141, <8 x float> %.state115, <8 x float> %private.contiguous.preserve117
  store <8 x float> %185, ptr %private.contiguous.address116, align 4
  %186 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %188 = add <8 x i64> %187, splat (i64 64)
  %189 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %186, 0
  %190 = insertvalue { <8 x ptr>, <8 x i64> } %189, <8 x i64> %188, 1
  %.state118 = load volatile <8 x float>, ptr %.slot52, align 32
  %191 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %190, 1
  %193 = extractelement <8 x ptr> %191, i32 0
  %194 = extractelement <8 x i64> %192, i32 %146
  %195 = zext i32 %146 to i64
  %196 = mul i64 %195, 4
  %197 = sub i64 %194, %196
  %198 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %141)
  %199 = select i1 %198, i64 %197, i64 0
  %private.contiguous.address119 = getelementptr i8, ptr %193, i64 %199
  %private.contiguous.preserve120 = load <8 x float>, ptr %private.contiguous.address119, align 4
  %200 = select <8 x i1> %141, <8 x float> %.state118, <8 x float> %private.contiguous.preserve120
  store <8 x float> %200, ptr %private.contiguous.address119, align 4
  %201 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %202 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %203 = add <8 x i64> %202, splat (i64 96)
  %204 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %201, 0
  %205 = insertvalue { <8 x ptr>, <8 x i64> } %204, <8 x i64> %203, 1
  %.state121 = load volatile <8 x float>, ptr %.slot53, align 32
  %206 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %207 = extractvalue { <8 x ptr>, <8 x i64> } %205, 1
  %208 = extractelement <8 x ptr> %206, i32 0
  %209 = extractelement <8 x i64> %207, i32 %146
  %210 = zext i32 %146 to i64
  %211 = mul i64 %210, 4
  %212 = sub i64 %209, %211
  %213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %141)
  %214 = select i1 %213, i64 %212, i64 0
  %private.contiguous.address122 = getelementptr i8, ptr %208, i64 %214
  %private.contiguous.preserve123 = load <8 x float>, ptr %private.contiguous.address122, align 4
  %215 = select <8 x i1> %141, <8 x float> %.state121, <8 x float> %private.contiguous.preserve123
  store <8 x float> %215, ptr %private.contiguous.address122, align 4
  %.state124 = load <8 x i64>, ptr %.slot, align 64
  %216 = select <8 x i1> %141, <8 x i64> %.state124, <8 x i64> zeroinitializer
  %217 = select <8 x i1> %141, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %218 = sdiv <8 x i64> %216, %217
  %219 = mul <8 x i64> %218, splat (i64 32)
  %220 = load volatile <8 x i64>, ptr %.spill54, align 64
  %221 = select <8 x i1> %141, <8 x i64> %219, <8 x i64> %220
  store volatile <8 x i64> %221, ptr %.spill54, align 64
  %222 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %224 = extractvalue { <8 x ptr>, <8 x i64> } %222, 0
  %225 = select <8 x i1> %141, <8 x ptr> %223, <8 x ptr> %224
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %222, 1
  %228 = select <8 x i1> %141, <8 x i64> %226, <8 x i64> %227
  %229 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %225, 0
  %230 = insertvalue { <8 x ptr>, <8 x i64> } %229, <8 x i64> %228, 1
  store volatile { <8 x ptr>, <8 x i64> } %230, ptr %tile_snapshot.spill55, align 64
  %231 = load <8 x i64>, ptr %.slot56, align 64
  %232 = select <8 x i1> %141, <8 x i64> zeroinitializer, <8 x i64> %231
  store <8 x i64> %232, ptr %.slot56, align 64
  store <8 x i1> %141, ptr %current.mask, align 1
  %233 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %141)
  br i1 %233, label %schedule.3, label %scheduler.loop

schedule.3:                                       ; preds = %convergence.target.6.ready, %schedule.2, %scheduler.dispatch.route
  %234 = load <8 x i1>, ptr %current.mask, align 1
  %235 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %234)
  %236 = bitcast <8 x i1> %234 to i8
  %237 = call i8 @llvm.cttz.i8(i8 %236, i1 false)
  %238 = zext i8 %237 to i32
  %239 = select i1 %235, i32 %238, i32 0
  %.state125 = load <8 x i64>, ptr %.slot56, align 64
  %240 = icmp slt <8 x i64> %.state125, splat (i64 128)
  %241 = and <8 x i1> %234, %240
  %242 = xor <8 x i1> %240, splat (i1 true)
  %243 = and <8 x i1> %234, %242
  %244 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %241)
  %245 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %243)
  %246 = and i1 %244, %245
  br i1 %246, label %varying.divergent126, label %varying.coherent127

schedule.4:                                       ; preds = %varying.coherent.true132, %scheduler.dispatch.route
  %247 = load <8 x i1>, ptr %current.mask, align 1
  %248 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %247)
  %249 = bitcast <8 x i1> %247 to i8
  %250 = call i8 @llvm.cttz.i8(i8 %249, i1 false)
  %251 = zext i8 %250 to i32
  %252 = select i1 %248, i32 %251, i32 0
  %.state134 = load <8 x i64>, ptr %.slot56, align 64
  %253 = select <8 x i1> %247, <8 x i64> %.state134, <8 x i64> zeroinitializer
  %254 = select <8 x i1> %247, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %255 = srem <8 x i64> %253, %254
  %.state135 = load <8 x i64>, ptr %.slot56, align 64
  %256 = select <8 x i1> %247, <8 x i64> %.state135, <8 x i64> zeroinitializer
  %257 = select <8 x i1> %247, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %258 = sdiv <8 x i64> %256, %257
  %.spill.load = load volatile <8 x i64>, ptr %.spill, align 64
  %259 = add <8 x i64> %.spill.load, %258
  %260 = add <8 x i64> zeroinitializer, %259
  %261 = icmp sge <8 x i64> %259, zeroinitializer
  %262 = and <8 x i1> splat (i1 true), %261
  %263 = icmp slt <8 x i64> %259, splat (i64 17)
  %264 = and <8 x i1> %262, %263
  %.spill.load136 = load volatile <8 x i64>, ptr %.spill54, align 64
  %265 = add <8 x i64> %.spill.load136, %255
  %266 = mul <8 x i64> %260, splat (i64 65)
  %267 = add <8 x i64> %266, %265
  %268 = icmp sge <8 x i64> %265, zeroinitializer
  %269 = and <8 x i1> %264, %268
  %270 = icmp slt <8 x i64> %265, splat (i64 65)
  %271 = and <8 x i1> %269, %270
  %272 = load volatile <8 x i64>, ptr %.spill57, align 64
  %273 = select <8 x i1> %247, <8 x i64> %267, <8 x i64> %272
  store volatile <8 x i64> %273, ptr %.spill57, align 64
  %274 = and <8 x i1> %247, %271
  %275 = xor <8 x i1> %271, splat (i1 true)
  %276 = and <8 x i1> %247, %275
  %277 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %274)
  %278 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %276)
  %279 = and i1 %277, %278
  br i1 %279, label %varying.divergent137, label %varying.coherent138

schedule.5:                                       ; preds = %varying.coherent.true146, %scheduler.dispatch.route
  %280 = load <8 x i1>, ptr %current.mask, align 1
  %281 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %280)
  %282 = bitcast <8 x i1> %280 to i8
  %283 = call i8 @llvm.cttz.i8(i8 %282, i1 false)
  %284 = zext i8 %283 to i32
  %285 = select i1 %281, i32 %284, i32 0
  %.spill.load151 = load volatile <8 x i64>, ptr %.spill57, align 64
  %286 = extractvalue { ptr, i64 } %39, 0
  %287 = mul <8 x i64> %.spill.load151, splat (i64 4)
  %288 = getelementptr i8, ptr %286, <8 x i64> %287
  %289 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %288, i32 1, <8 x i1> %280, <8 x float> zeroinitializer)
  %290 = load <8 x float>, ptr %.slot58, align 32
  %291 = select <8 x i1> %280, <8 x float> %289, <8 x float> %290
  store <8 x float> %291, ptr %.slot58, align 32
  store <8 x i1> %280, ptr %current.mask, align 1
  %292 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %280)
  br i1 %292, label %schedule.6, label %scheduler.loop

schedule.6:                                       ; preds = %schedule.5, %varying.coherent.false147, %scheduler.dispatch.route
  %293 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token = load i32, ptr %current.token, align 4
  %convergence.token.present = icmp ne i32 %convergence.current.token, 0
  br i1 %convergence.token.present, label %convergence.cascade, label %convergence.cascade.exit

schedule.7:                                       ; preds = %varying.coherent.false133, %scheduler.dispatch.route
  %294 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token163 = load i32, ptr %current.token, align 4
  %convergence.token.present164 = icmp ne i32 %convergence.current.token163, 0
  br i1 %convergence.token.present164, label %convergence.cascade161, label %convergence.cascade.exit162

schedule.8:                                       ; preds = %convergence.target.11.ready, %convergence.target.7.ready, %scheduler.dispatch.route
  %295 = load <8 x i1>, ptr %current.mask, align 1
  %296 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %295)
  %297 = bitcast <8 x i1> %295 to i8
  %298 = call i8 @llvm.cttz.i8(i8 %297, i1 false)
  %299 = zext i8 %298 to i32
  %300 = select i1 %296, i32 %299, i32 0
  %.state242 = load <8 x i64>, ptr %.slot61, align 64
  %301 = icmp slt <8 x i64> %.state242, splat (i64 128)
  %302 = and <8 x i1> %295, %301
  %303 = xor <8 x i1> %301, splat (i1 true)
  %304 = and <8 x i1> %295, %303
  %305 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %302)
  %306 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %304)
  %307 = and i1 %305, %306
  br i1 %307, label %varying.divergent243, label %varying.coherent244

schedule.9:                                       ; preds = %varying.coherent.true249, %scheduler.dispatch.route
  %308 = load <8 x i1>, ptr %current.mask, align 1
  %309 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %308)
  %310 = bitcast <8 x i1> %308 to i8
  %311 = call i8 @llvm.cttz.i8(i8 %310, i1 false)
  %312 = zext i8 %311 to i32
  %313 = select i1 %309, i32 %312, i32 0
  %.state251 = load <8 x i64>, ptr %.slot61, align 64
  %314 = select <8 x i1> %308, <8 x i64> %.state251, <8 x i64> zeroinitializer
  %315 = select <8 x i1> %308, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %316 = srem <8 x i64> %314, %315
  %.state252 = load <8 x i64>, ptr %.slot61, align 64
  %317 = select <8 x i1> %308, <8 x i64> %.state252, <8 x i64> zeroinitializer
  %318 = select <8 x i1> %308, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %319 = sdiv <8 x i64> %317, %318
  %320 = add <8 x i64> zeroinitializer, %316
  %tile_snapshot.spill.load253 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill59, align 64
  %321 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load253, 0
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load253, 1
  %323 = mul <8 x i64> %320, splat (i64 64)
  %324 = add <8 x i64> %322, %323
  %325 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %321, 0
  %326 = insertvalue { <8 x ptr>, <8 x i64> } %325, <8 x i64> %324, 1
  %327 = extractvalue { <8 x ptr>, <8 x i64> } %326, 0
  %328 = extractvalue { <8 x ptr>, <8 x i64> } %326, 1
  %329 = getelementptr i8, <8 x ptr> %327, <8 x i64> %328
  %330 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> %329, i32 1, <8 x i1> %308, <8 x i64> zeroinitializer)
  %331 = icmp sge <8 x i64> %330, zeroinitializer
  %332 = icmp slt <8 x i64> %330, splat (i64 32)
  %333 = and <8 x i1> %331, %332
  %334 = load volatile <8 x i1>, ptr %.spill62, align 1
  %335 = select <8 x i1> %308, <8 x i1> %333, <8 x i1> %334
  store volatile <8 x i1> %335, ptr %.spill62, align 1
  %336 = add <8 x i64> zeroinitializer, %319
  %337 = mul <8 x i64> %336, splat (i64 32)
  %338 = add <8 x i64> %337, %330
  %339 = load volatile <8 x i64>, ptr %.spill63, align 64
  %340 = select <8 x i1> %308, <8 x i64> %338, <8 x i64> %339
  store volatile <8 x i64> %340, ptr %.spill63, align 64
  %341 = icmp sge <8 x i64> %338, zeroinitializer
  %342 = icmp slt <8 x i64> %338, splat (i64 128)
  %343 = and <8 x i1> %341, %342
  %344 = and <8 x i1> %308, %343
  %345 = xor <8 x i1> %343, splat (i1 true)
  %346 = and <8 x i1> %308, %345
  %347 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %344)
  %348 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %346)
  %349 = and i1 %347, %348
  br i1 %349, label %varying.divergent254, label %varying.coherent255

schedule.10:                                      ; preds = %varying.coherent.true260, %scheduler.dispatch.route
  %350 = load <8 x i1>, ptr %current.mask, align 1
  %351 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %350)
  %352 = bitcast <8 x i1> %350 to i8
  %353 = call i8 @llvm.cttz.i8(i8 %352, i1 false)
  %354 = zext i8 %353 to i32
  %355 = select i1 %351, i32 %354, i32 0
  %tile_snapshot.spill.load262 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %356 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load262, 0
  %357 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load262, 1
  %.spill.load263 = load volatile <8 x i64>, ptr %.spill63, align 64
  %358 = mul <8 x i64> %.spill.load263, splat (i64 32)
  %359 = add <8 x i64> %357, %358
  %360 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %356, 0
  %361 = insertvalue { <8 x ptr>, <8 x i64> } %360, <8 x i64> %359, 1
  %362 = extractvalue { <8 x ptr>, <8 x i64> } %361, 0
  %363 = extractvalue { <8 x ptr>, <8 x i64> } %361, 1
  %364 = getelementptr i8, <8 x ptr> %362, <8 x i64> %363
  %365 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %364, i32 1, <8 x i1> %350, <8 x float> zeroinitializer)
  %366 = load <8 x float>, ptr %.slot64, align 32
  %367 = select <8 x i1> %350, <8 x float> %365, <8 x float> %366
  store <8 x float> %367, ptr %.slot64, align 32
  store <8 x i1> %350, ptr %current.mask, align 1
  %368 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %350)
  br i1 %368, label %schedule.11, label %scheduler.loop

schedule.11:                                      ; preds = %schedule.10, %varying.coherent.false261, %scheduler.dispatch.route
  %369 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token266 = load i32, ptr %current.token, align 4
  %convergence.token.present267 = icmp ne i32 %convergence.current.token266, 0
  br i1 %convergence.token.present267, label %convergence.cascade264, label %convergence.cascade.exit265

schedule.12:                                      ; preds = %varying.coherent.false250, %scheduler.dispatch.route
  %370 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token291 = load i32, ptr %current.token, align 4
  %convergence.token.present292 = icmp ne i32 %convergence.current.token291, 0
  br i1 %convergence.token.present292, label %convergence.cascade289, label %convergence.cascade.exit290

schedule.13:                                      ; preds = %schedule.14, %convergence.target.12.ready, %scheduler.dispatch.route
  %371 = load <8 x i1>, ptr %current.mask, align 1
  %372 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %371)
  %373 = bitcast <8 x i1> %371 to i8
  %374 = call i8 @llvm.cttz.i8(i8 %373, i1 false)
  %375 = zext i8 %374 to i32
  %376 = select i1 %372, i32 %375, i32 0
  %.state306 = load <8 x i64>, ptr %.slot66, align 64
  %377 = icmp slt <8 x i64> %.state306, splat (i64 128)
  %378 = and <8 x i1> %371, %377
  %379 = xor <8 x i1> %377, splat (i1 true)
  %380 = and <8 x i1> %371, %379
  %381 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %378)
  %382 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %380)
  %383 = and i1 %381, %382
  br i1 %383, label %varying.divergent307, label %varying.coherent308

schedule.14:                                      ; preds = %varying.coherent.true313, %scheduler.dispatch.route
  %384 = load <8 x i1>, ptr %current.mask, align 1
  %385 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %384)
  %386 = bitcast <8 x i1> %384 to i8
  %387 = call i8 @llvm.cttz.i8(i8 %386, i1 false)
  %388 = zext i8 %387 to i32
  %389 = select i1 %385, i32 %388, i32 0
  %.state315 = load <8 x i64>, ptr %.slot66, align 64
  %390 = select <8 x i1> %384, <8 x i64> %.state315, <8 x i64> zeroinitializer
  %391 = select <8 x i1> %384, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %392 = srem <8 x i64> %390, %391
  %.state316 = load <8 x i64>, ptr %.slot66, align 64
  %393 = select <8 x i1> %384, <8 x i64> %.state316, <8 x i64> zeroinitializer
  %394 = select <8 x i1> %384, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %395 = sdiv <8 x i64> %393, %394
  %396 = add <8 x i64> zeroinitializer, %395
  %397 = mul <8 x i64> %396, splat (i64 32)
  %398 = add <8 x i64> %397, %392
  %tile_snapshot.spill.load317 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %399 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load317, 0
  %400 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load317, 1
  %401 = mul <8 x i64> %398, splat (i64 32)
  %402 = add <8 x i64> %400, %401
  %403 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %399, 0
  %404 = insertvalue { <8 x ptr>, <8 x i64> } %403, <8 x i64> %402, 1
  %405 = extractvalue { <8 x ptr>, <8 x i64> } %404, 0
  %406 = extractvalue { <8 x ptr>, <8 x i64> } %404, 1
  %407 = getelementptr i8, <8 x ptr> %405, <8 x i64> %406
  %408 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %407, i32 1, <8 x i1> %384, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load318 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill60, align 64
  %409 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load318, 0
  %410 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load318, 1
  %411 = mul <8 x i64> %398, splat (i64 32)
  %412 = add <8 x i64> %410, %411
  %413 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %409, 0
  %414 = insertvalue { <8 x ptr>, <8 x i64> } %413, <8 x i64> %412, 1
  %415 = extractvalue { <8 x ptr>, <8 x i64> } %414, 0
  %416 = extractvalue { <8 x ptr>, <8 x i64> } %414, 1
  %417 = getelementptr i8, <8 x ptr> %415, <8 x i64> %416
  %418 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %417, i32 1, <8 x i1> %384, <8 x float> zeroinitializer)
  %419 = fadd <8 x float> %408, %418
  %tile_snapshot.spill.load319 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %420 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load319, 0
  %421 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load319, 1
  %.state320 = load <8 x i64>, ptr %.slot66, align 64
  %422 = mul <8 x i64> %.state320, splat (i64 32)
  %423 = add <8 x i64> %421, %422
  %424 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %420, 0
  %425 = insertvalue { <8 x ptr>, <8 x i64> } %424, <8 x i64> %423, 1
  %426 = extractvalue { <8 x ptr>, <8 x i64> } %425, 0
  %427 = extractvalue { <8 x ptr>, <8 x i64> } %425, 1
  %428 = getelementptr i8, <8 x ptr> %426, <8 x i64> %427
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %419, <8 x ptr> %428, i32 1, <8 x i1> %384)
  %.state321 = load <8 x i64>, ptr %.slot66, align 64
  %429 = add <8 x i64> %.state321, splat (i64 1)
  %430 = load <8 x i64>, ptr %.slot66, align 64
  %431 = select <8 x i1> %384, <8 x i64> %429, <8 x i64> %430
  store <8 x i64> %431, ptr %.slot66, align 64
  store <8 x i1> %384, ptr %current.mask, align 1
  %432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %384)
  br i1 %432, label %schedule.13, label %scheduler.loop

schedule.15:                                      ; preds = %varying.coherent.false314, %scheduler.dispatch.route
  %433 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token324 = load i32, ptr %current.token, align 4
  %convergence.token.present325 = icmp ne i32 %convergence.current.token324, 0
  br i1 %convergence.token.present325, label %convergence.cascade322, label %convergence.cascade.exit323

schedule.16:                                      ; preds = %convergence.target.19.ready, %convergence.target.15.ready, %scheduler.dispatch.route
  %434 = load <8 x i1>, ptr %current.mask, align 1
  %435 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %434)
  %436 = bitcast <8 x i1> %434 to i8
  %437 = call i8 @llvm.cttz.i8(i8 %436, i1 false)
  %438 = zext i8 %437 to i32
  %439 = select i1 %435, i32 %438, i32 0
  %.state403 = load <8 x i64>, ptr %.slot69, align 64
  %440 = icmp slt <8 x i64> %.state403, splat (i64 128)
  %441 = and <8 x i1> %434, %440
  %442 = xor <8 x i1> %440, splat (i1 true)
  %443 = and <8 x i1> %434, %442
  %444 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %441)
  %445 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %443)
  %446 = and i1 %444, %445
  br i1 %446, label %varying.divergent404, label %varying.coherent405

schedule.17:                                      ; preds = %varying.coherent.true410, %scheduler.dispatch.route
  %447 = load <8 x i1>, ptr %current.mask, align 1
  %448 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %447)
  %449 = bitcast <8 x i1> %447 to i8
  %450 = call i8 @llvm.cttz.i8(i8 %449, i1 false)
  %451 = zext i8 %450 to i32
  %452 = select i1 %448, i32 %451, i32 0
  %.state412 = load <8 x i64>, ptr %.slot69, align 64
  %453 = select <8 x i1> %447, <8 x i64> %.state412, <8 x i64> zeroinitializer
  %454 = select <8 x i1> %447, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %455 = srem <8 x i64> %453, %454
  %.state413 = load <8 x i64>, ptr %.slot69, align 64
  %456 = select <8 x i1> %447, <8 x i64> %.state413, <8 x i64> zeroinitializer
  %457 = select <8 x i1> %447, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %458 = sdiv <8 x i64> %456, %457
  %459 = add <8 x i64> zeroinitializer, %455
  %tile_snapshot.spill.load414 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill67, align 64
  %460 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load414, 0
  %461 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load414, 1
  %462 = mul <8 x i64> %459, splat (i64 64)
  %463 = add <8 x i64> %461, %462
  %464 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %460, 0
  %465 = insertvalue { <8 x ptr>, <8 x i64> } %464, <8 x i64> %463, 1
  %466 = extractvalue { <8 x ptr>, <8 x i64> } %465, 0
  %467 = extractvalue { <8 x ptr>, <8 x i64> } %465, 1
  %468 = getelementptr i8, <8 x ptr> %466, <8 x i64> %467
  %469 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> %468, i32 1, <8 x i1> %447, <8 x i64> zeroinitializer)
  %470 = icmp sge <8 x i64> %469, zeroinitializer
  %471 = icmp slt <8 x i64> %469, splat (i64 32)
  %472 = and <8 x i1> %470, %471
  %473 = load volatile <8 x i1>, ptr %.spill70, align 1
  %474 = select <8 x i1> %447, <8 x i1> %472, <8 x i1> %473
  store volatile <8 x i1> %474, ptr %.spill70, align 1
  %475 = add <8 x i64> zeroinitializer, %458
  %476 = mul <8 x i64> %475, splat (i64 32)
  %477 = add <8 x i64> %476, %469
  %478 = load volatile <8 x i64>, ptr %.spill71, align 64
  %479 = select <8 x i1> %447, <8 x i64> %477, <8 x i64> %478
  store volatile <8 x i64> %479, ptr %.spill71, align 64
  %480 = icmp sge <8 x i64> %477, zeroinitializer
  %481 = icmp slt <8 x i64> %477, splat (i64 128)
  %482 = and <8 x i1> %480, %481
  %483 = and <8 x i1> %447, %482
  %484 = xor <8 x i1> %482, splat (i1 true)
  %485 = and <8 x i1> %447, %484
  %486 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %483)
  %487 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %485)
  %488 = and i1 %486, %487
  br i1 %488, label %varying.divergent415, label %varying.coherent416

schedule.18:                                      ; preds = %varying.coherent.true421, %scheduler.dispatch.route
  %489 = load <8 x i1>, ptr %current.mask, align 1
  %490 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %489)
  %491 = bitcast <8 x i1> %489 to i8
  %492 = call i8 @llvm.cttz.i8(i8 %491, i1 false)
  %493 = zext i8 %492 to i32
  %494 = select i1 %490, i32 %493, i32 0
  %tile_snapshot.spill.load423 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %495 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load423, 0
  %496 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load423, 1
  %.spill.load424 = load volatile <8 x i64>, ptr %.spill71, align 64
  %497 = mul <8 x i64> %.spill.load424, splat (i64 32)
  %498 = add <8 x i64> %496, %497
  %499 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %495, 0
  %500 = insertvalue { <8 x ptr>, <8 x i64> } %499, <8 x i64> %498, 1
  %501 = extractvalue { <8 x ptr>, <8 x i64> } %500, 0
  %502 = extractvalue { <8 x ptr>, <8 x i64> } %500, 1
  %503 = getelementptr i8, <8 x ptr> %501, <8 x i64> %502
  %504 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %503, i32 1, <8 x i1> %489, <8 x float> zeroinitializer)
  %505 = load <8 x float>, ptr %.slot72, align 32
  %506 = select <8 x i1> %489, <8 x float> %504, <8 x float> %505
  store <8 x float> %506, ptr %.slot72, align 32
  store <8 x i1> %489, ptr %current.mask, align 1
  %507 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %489)
  br i1 %507, label %schedule.19, label %scheduler.loop

schedule.19:                                      ; preds = %schedule.18, %varying.coherent.false422, %scheduler.dispatch.route
  %508 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token427 = load i32, ptr %current.token, align 4
  %convergence.token.present428 = icmp ne i32 %convergence.current.token427, 0
  br i1 %convergence.token.present428, label %convergence.cascade425, label %convergence.cascade.exit426

schedule.20:                                      ; preds = %varying.coherent.false411, %scheduler.dispatch.route
  %509 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token452 = load i32, ptr %current.token, align 4
  %convergence.token.present453 = icmp ne i32 %convergence.current.token452, 0
  br i1 %convergence.token.present453, label %convergence.cascade450, label %convergence.cascade.exit451

schedule.21:                                      ; preds = %schedule.22, %convergence.target.20.ready, %scheduler.dispatch.route
  %510 = load <8 x i1>, ptr %current.mask, align 1
  %511 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %510)
  %512 = bitcast <8 x i1> %510 to i8
  %513 = call i8 @llvm.cttz.i8(i8 %512, i1 false)
  %514 = zext i8 %513 to i32
  %515 = select i1 %511, i32 %514, i32 0
  %.state467 = load <8 x i64>, ptr %.slot74, align 64
  %516 = icmp slt <8 x i64> %.state467, splat (i64 128)
  %517 = and <8 x i1> %510, %516
  %518 = xor <8 x i1> %516, splat (i1 true)
  %519 = and <8 x i1> %510, %518
  %520 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %517)
  %521 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %519)
  %522 = and i1 %520, %521
  br i1 %522, label %varying.divergent468, label %varying.coherent469

schedule.22:                                      ; preds = %varying.coherent.true474, %scheduler.dispatch.route
  %523 = load <8 x i1>, ptr %current.mask, align 1
  %524 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %523)
  %525 = bitcast <8 x i1> %523 to i8
  %526 = call i8 @llvm.cttz.i8(i8 %525, i1 false)
  %527 = zext i8 %526 to i32
  %528 = select i1 %524, i32 %527, i32 0
  %.state476 = load <8 x i64>, ptr %.slot74, align 64
  %529 = select <8 x i1> %523, <8 x i64> %.state476, <8 x i64> zeroinitializer
  %530 = select <8 x i1> %523, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %531 = srem <8 x i64> %529, %530
  %.state477 = load <8 x i64>, ptr %.slot74, align 64
  %532 = select <8 x i1> %523, <8 x i64> %.state477, <8 x i64> zeroinitializer
  %533 = select <8 x i1> %523, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %534 = sdiv <8 x i64> %532, %533
  %535 = add <8 x i64> zeroinitializer, %534
  %536 = mul <8 x i64> %535, splat (i64 32)
  %537 = add <8 x i64> %536, %531
  %tile_snapshot.spill.load478 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %538 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load478, 0
  %539 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load478, 1
  %540 = mul <8 x i64> %537, splat (i64 32)
  %541 = add <8 x i64> %539, %540
  %542 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %538, 0
  %543 = insertvalue { <8 x ptr>, <8 x i64> } %542, <8 x i64> %541, 1
  %544 = extractvalue { <8 x ptr>, <8 x i64> } %543, 0
  %545 = extractvalue { <8 x ptr>, <8 x i64> } %543, 1
  %546 = getelementptr i8, <8 x ptr> %544, <8 x i64> %545
  %547 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %546, i32 1, <8 x i1> %523, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load479 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill68, align 64
  %548 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load479, 0
  %549 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load479, 1
  %550 = mul <8 x i64> %537, splat (i64 32)
  %551 = add <8 x i64> %549, %550
  %552 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %548, 0
  %553 = insertvalue { <8 x ptr>, <8 x i64> } %552, <8 x i64> %551, 1
  %554 = extractvalue { <8 x ptr>, <8 x i64> } %553, 0
  %555 = extractvalue { <8 x ptr>, <8 x i64> } %553, 1
  %556 = getelementptr i8, <8 x ptr> %554, <8 x i64> %555
  %557 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %556, i32 1, <8 x i1> %523, <8 x float> zeroinitializer)
  %558 = fadd <8 x float> %547, %557
  %tile_snapshot.spill.load480 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill73, align 64
  %559 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load480, 0
  %560 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load480, 1
  %.state481 = load <8 x i64>, ptr %.slot74, align 64
  %561 = mul <8 x i64> %.state481, splat (i64 32)
  %562 = add <8 x i64> %560, %561
  %563 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %559, 0
  %564 = insertvalue { <8 x ptr>, <8 x i64> } %563, <8 x i64> %562, 1
  %565 = extractvalue { <8 x ptr>, <8 x i64> } %564, 0
  %566 = extractvalue { <8 x ptr>, <8 x i64> } %564, 1
  %567 = getelementptr i8, <8 x ptr> %565, <8 x i64> %566
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %558, <8 x ptr> %567, i32 1, <8 x i1> %523)
  %.state482 = load <8 x i64>, ptr %.slot74, align 64
  %568 = add <8 x i64> %.state482, splat (i64 1)
  %569 = load <8 x i64>, ptr %.slot74, align 64
  %570 = select <8 x i1> %523, <8 x i64> %568, <8 x i64> %569
  store <8 x i64> %570, ptr %.slot74, align 64
  store <8 x i1> %523, ptr %current.mask, align 1
  %571 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %523)
  br i1 %571, label %schedule.21, label %scheduler.loop

schedule.23:                                      ; preds = %varying.coherent.false475, %scheduler.dispatch.route
  %572 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token485 = load i32, ptr %current.token, align 4
  %convergence.token.present486 = icmp ne i32 %convergence.current.token485, 0
  br i1 %convergence.token.present486, label %convergence.cascade483, label %convergence.cascade.exit484

schedule.24:                                      ; preds = %convergence.target.27.ready, %convergence.target.23.ready, %scheduler.dispatch.route
  %573 = load <8 x i1>, ptr %current.mask, align 1
  %574 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %573)
  %575 = bitcast <8 x i1> %573 to i8
  %576 = call i8 @llvm.cttz.i8(i8 %575, i1 false)
  %577 = zext i8 %576 to i32
  %578 = select i1 %574, i32 %577, i32 0
  %.state564 = load <8 x i64>, ptr %.slot77, align 64
  %579 = icmp slt <8 x i64> %.state564, splat (i64 128)
  %580 = and <8 x i1> %573, %579
  %581 = xor <8 x i1> %579, splat (i1 true)
  %582 = and <8 x i1> %573, %581
  %583 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %580)
  %584 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %582)
  %585 = and i1 %583, %584
  br i1 %585, label %varying.divergent565, label %varying.coherent566

schedule.25:                                      ; preds = %varying.coherent.true571, %scheduler.dispatch.route
  %586 = load <8 x i1>, ptr %current.mask, align 1
  %587 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %586)
  %588 = bitcast <8 x i1> %586 to i8
  %589 = call i8 @llvm.cttz.i8(i8 %588, i1 false)
  %590 = zext i8 %589 to i32
  %591 = select i1 %587, i32 %590, i32 0
  %.state573 = load <8 x i64>, ptr %.slot77, align 64
  %592 = select <8 x i1> %586, <8 x i64> %.state573, <8 x i64> zeroinitializer
  %593 = select <8 x i1> %586, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %594 = srem <8 x i64> %592, %593
  %.state574 = load <8 x i64>, ptr %.slot77, align 64
  %595 = select <8 x i1> %586, <8 x i64> %.state574, <8 x i64> zeroinitializer
  %596 = select <8 x i1> %586, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %597 = sdiv <8 x i64> %595, %596
  %598 = add <8 x i64> zeroinitializer, %594
  %tile_snapshot.spill.load575 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill75, align 64
  %599 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load575, 0
  %600 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load575, 1
  %601 = mul <8 x i64> %598, splat (i64 64)
  %602 = add <8 x i64> %600, %601
  %603 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %599, 0
  %604 = insertvalue { <8 x ptr>, <8 x i64> } %603, <8 x i64> %602, 1
  %605 = extractvalue { <8 x ptr>, <8 x i64> } %604, 0
  %606 = extractvalue { <8 x ptr>, <8 x i64> } %604, 1
  %607 = getelementptr i8, <8 x ptr> %605, <8 x i64> %606
  %608 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> %607, i32 1, <8 x i1> %586, <8 x i64> zeroinitializer)
  %609 = icmp sge <8 x i64> %608, zeroinitializer
  %610 = icmp slt <8 x i64> %608, splat (i64 32)
  %611 = and <8 x i1> %609, %610
  %612 = load volatile <8 x i1>, ptr %.spill78, align 1
  %613 = select <8 x i1> %586, <8 x i1> %611, <8 x i1> %612
  store volatile <8 x i1> %613, ptr %.spill78, align 1
  %614 = add <8 x i64> zeroinitializer, %597
  %615 = mul <8 x i64> %614, splat (i64 32)
  %616 = add <8 x i64> %615, %608
  %617 = load volatile <8 x i64>, ptr %.spill79, align 64
  %618 = select <8 x i1> %586, <8 x i64> %616, <8 x i64> %617
  store volatile <8 x i64> %618, ptr %.spill79, align 64
  %619 = icmp sge <8 x i64> %616, zeroinitializer
  %620 = icmp slt <8 x i64> %616, splat (i64 128)
  %621 = and <8 x i1> %619, %620
  %622 = and <8 x i1> %586, %621
  %623 = xor <8 x i1> %621, splat (i1 true)
  %624 = and <8 x i1> %586, %623
  %625 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %622)
  %626 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %624)
  %627 = and i1 %625, %626
  br i1 %627, label %varying.divergent576, label %varying.coherent577

schedule.26:                                      ; preds = %varying.coherent.true582, %scheduler.dispatch.route
  %628 = load <8 x i1>, ptr %current.mask, align 1
  %629 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %628)
  %630 = bitcast <8 x i1> %628 to i8
  %631 = call i8 @llvm.cttz.i8(i8 %630, i1 false)
  %632 = zext i8 %631 to i32
  %633 = select i1 %629, i32 %632, i32 0
  %tile_snapshot.spill.load584 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill73, align 64
  %634 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load584, 0
  %635 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load584, 1
  %.spill.load585 = load volatile <8 x i64>, ptr %.spill79, align 64
  %636 = mul <8 x i64> %.spill.load585, splat (i64 32)
  %637 = add <8 x i64> %635, %636
  %638 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %634, 0
  %639 = insertvalue { <8 x ptr>, <8 x i64> } %638, <8 x i64> %637, 1
  %640 = extractvalue { <8 x ptr>, <8 x i64> } %639, 0
  %641 = extractvalue { <8 x ptr>, <8 x i64> } %639, 1
  %642 = getelementptr i8, <8 x ptr> %640, <8 x i64> %641
  %643 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %642, i32 1, <8 x i1> %628, <8 x float> zeroinitializer)
  %644 = load <8 x float>, ptr %.slot80, align 32
  %645 = select <8 x i1> %628, <8 x float> %643, <8 x float> %644
  store <8 x float> %645, ptr %.slot80, align 32
  store <8 x i1> %628, ptr %current.mask, align 1
  %646 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %628)
  br i1 %646, label %schedule.27, label %scheduler.loop

schedule.27:                                      ; preds = %schedule.26, %varying.coherent.false583, %scheduler.dispatch.route
  %647 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token588 = load i32, ptr %current.token, align 4
  %convergence.token.present589 = icmp ne i32 %convergence.current.token588, 0
  br i1 %convergence.token.present589, label %convergence.cascade586, label %convergence.cascade.exit587

schedule.28:                                      ; preds = %varying.coherent.false572, %scheduler.dispatch.route
  %648 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token613 = load i32, ptr %current.token, align 4
  %convergence.token.present614 = icmp ne i32 %convergence.current.token613, 0
  br i1 %convergence.token.present614, label %convergence.cascade611, label %convergence.cascade.exit612

schedule.29:                                      ; preds = %schedule.30, %convergence.target.28.ready, %scheduler.dispatch.route
  %649 = load <8 x i1>, ptr %current.mask, align 1
  %650 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %649)
  %651 = bitcast <8 x i1> %649 to i8
  %652 = call i8 @llvm.cttz.i8(i8 %651, i1 false)
  %653 = zext i8 %652 to i32
  %654 = select i1 %650, i32 %653, i32 0
  %.state628 = load <8 x i64>, ptr %.slot82, align 64
  %655 = icmp slt <8 x i64> %.state628, splat (i64 128)
  %656 = and <8 x i1> %649, %655
  %657 = xor <8 x i1> %655, splat (i1 true)
  %658 = and <8 x i1> %649, %657
  %659 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %656)
  %660 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %658)
  %661 = and i1 %659, %660
  br i1 %661, label %varying.divergent629, label %varying.coherent630

schedule.30:                                      ; preds = %varying.coherent.true635, %scheduler.dispatch.route
  %662 = load <8 x i1>, ptr %current.mask, align 1
  %663 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %662)
  %664 = bitcast <8 x i1> %662 to i8
  %665 = call i8 @llvm.cttz.i8(i8 %664, i1 false)
  %666 = zext i8 %665 to i32
  %667 = select i1 %663, i32 %666, i32 0
  %.state637 = load <8 x i64>, ptr %.slot82, align 64
  %668 = select <8 x i1> %662, <8 x i64> %.state637, <8 x i64> zeroinitializer
  %669 = select <8 x i1> %662, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %670 = srem <8 x i64> %668, %669
  %.state638 = load <8 x i64>, ptr %.slot82, align 64
  %671 = select <8 x i1> %662, <8 x i64> %.state638, <8 x i64> zeroinitializer
  %672 = select <8 x i1> %662, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %673 = sdiv <8 x i64> %671, %672
  %674 = add <8 x i64> zeroinitializer, %673
  %675 = mul <8 x i64> %674, splat (i64 32)
  %676 = add <8 x i64> %675, %670
  %tile_snapshot.spill.load639 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill73, align 64
  %677 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load639, 0
  %678 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load639, 1
  %679 = mul <8 x i64> %676, splat (i64 32)
  %680 = add <8 x i64> %678, %679
  %681 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %677, 0
  %682 = insertvalue { <8 x ptr>, <8 x i64> } %681, <8 x i64> %680, 1
  %683 = extractvalue { <8 x ptr>, <8 x i64> } %682, 0
  %684 = extractvalue { <8 x ptr>, <8 x i64> } %682, 1
  %685 = getelementptr i8, <8 x ptr> %683, <8 x i64> %684
  %686 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %685, i32 1, <8 x i1> %662, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load640 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill76, align 64
  %687 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load640, 0
  %688 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load640, 1
  %689 = mul <8 x i64> %676, splat (i64 32)
  %690 = add <8 x i64> %688, %689
  %691 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %687, 0
  %692 = insertvalue { <8 x ptr>, <8 x i64> } %691, <8 x i64> %690, 1
  %693 = extractvalue { <8 x ptr>, <8 x i64> } %692, 0
  %694 = extractvalue { <8 x ptr>, <8 x i64> } %692, 1
  %695 = getelementptr i8, <8 x ptr> %693, <8 x i64> %694
  %696 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %695, i32 1, <8 x i1> %662, <8 x float> zeroinitializer)
  %697 = fadd <8 x float> %686, %696
  %tile_snapshot.spill.load641 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill81, align 64
  %698 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load641, 0
  %699 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load641, 1
  %.state642 = load <8 x i64>, ptr %.slot82, align 64
  %700 = mul <8 x i64> %.state642, splat (i64 32)
  %701 = add <8 x i64> %699, %700
  %702 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %698, 0
  %703 = insertvalue { <8 x ptr>, <8 x i64> } %702, <8 x i64> %701, 1
  %704 = extractvalue { <8 x ptr>, <8 x i64> } %703, 0
  %705 = extractvalue { <8 x ptr>, <8 x i64> } %703, 1
  %706 = getelementptr i8, <8 x ptr> %704, <8 x i64> %705
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %697, <8 x ptr> %706, i32 1, <8 x i1> %662)
  %.state643 = load <8 x i64>, ptr %.slot82, align 64
  %707 = add <8 x i64> %.state643, splat (i64 1)
  %708 = load <8 x i64>, ptr %.slot82, align 64
  %709 = select <8 x i1> %662, <8 x i64> %707, <8 x i64> %708
  store <8 x i64> %709, ptr %.slot82, align 64
  store <8 x i1> %662, ptr %current.mask, align 1
  %710 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %662)
  br i1 %710, label %schedule.29, label %scheduler.loop

schedule.31:                                      ; preds = %varying.coherent.false636, %scheduler.dispatch.route
  %711 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token646 = load i32, ptr %current.token, align 4
  %convergence.token.present647 = icmp ne i32 %convergence.current.token646, 0
  br i1 %convergence.token.present647, label %convergence.cascade644, label %convergence.cascade.exit645

schedule.32:                                      ; preds = %convergence.target.35.ready, %convergence.target.31.ready, %scheduler.dispatch.route
  %712 = load <8 x i1>, ptr %current.mask, align 1
  %713 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %712)
  %714 = bitcast <8 x i1> %712 to i8
  %715 = call i8 @llvm.cttz.i8(i8 %714, i1 false)
  %716 = zext i8 %715 to i32
  %717 = select i1 %713, i32 %716, i32 0
  %.state725 = load <8 x i64>, ptr %.slot85, align 64
  %718 = icmp slt <8 x i64> %.state725, splat (i64 128)
  %719 = and <8 x i1> %712, %718
  %720 = xor <8 x i1> %718, splat (i1 true)
  %721 = and <8 x i1> %712, %720
  %722 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %719)
  %723 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %721)
  %724 = and i1 %722, %723
  br i1 %724, label %varying.divergent726, label %varying.coherent727

schedule.33:                                      ; preds = %varying.coherent.true732, %scheduler.dispatch.route
  %725 = load <8 x i1>, ptr %current.mask, align 1
  %726 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %725)
  %727 = bitcast <8 x i1> %725 to i8
  %728 = call i8 @llvm.cttz.i8(i8 %727, i1 false)
  %729 = zext i8 %728 to i32
  %730 = select i1 %726, i32 %729, i32 0
  %.state734 = load <8 x i64>, ptr %.slot85, align 64
  %731 = select <8 x i1> %725, <8 x i64> %.state734, <8 x i64> zeroinitializer
  %732 = select <8 x i1> %725, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %733 = srem <8 x i64> %731, %732
  %.state735 = load <8 x i64>, ptr %.slot85, align 64
  %734 = select <8 x i1> %725, <8 x i64> %.state735, <8 x i64> zeroinitializer
  %735 = select <8 x i1> %725, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %736 = sdiv <8 x i64> %734, %735
  %737 = add <8 x i64> zeroinitializer, %733
  %tile_snapshot.spill.load736 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill83, align 64
  %738 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load736, 0
  %739 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load736, 1
  %740 = mul <8 x i64> %737, splat (i64 64)
  %741 = add <8 x i64> %739, %740
  %742 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %738, 0
  %743 = insertvalue { <8 x ptr>, <8 x i64> } %742, <8 x i64> %741, 1
  %744 = extractvalue { <8 x ptr>, <8 x i64> } %743, 0
  %745 = extractvalue { <8 x ptr>, <8 x i64> } %743, 1
  %746 = getelementptr i8, <8 x ptr> %744, <8 x i64> %745
  %747 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> %746, i32 1, <8 x i1> %725, <8 x i64> zeroinitializer)
  %748 = icmp sge <8 x i64> %747, zeroinitializer
  %749 = icmp slt <8 x i64> %747, splat (i64 32)
  %750 = and <8 x i1> %748, %749
  %751 = load volatile <8 x i1>, ptr %.spill86, align 1
  %752 = select <8 x i1> %725, <8 x i1> %750, <8 x i1> %751
  store volatile <8 x i1> %752, ptr %.spill86, align 1
  %753 = add <8 x i64> zeroinitializer, %736
  %754 = mul <8 x i64> %753, splat (i64 32)
  %755 = add <8 x i64> %754, %747
  %756 = load volatile <8 x i64>, ptr %.spill87, align 64
  %757 = select <8 x i1> %725, <8 x i64> %755, <8 x i64> %756
  store volatile <8 x i64> %757, ptr %.spill87, align 64
  %758 = icmp sge <8 x i64> %755, zeroinitializer
  %759 = icmp slt <8 x i64> %755, splat (i64 128)
  %760 = and <8 x i1> %758, %759
  %761 = and <8 x i1> %725, %760
  %762 = xor <8 x i1> %760, splat (i1 true)
  %763 = and <8 x i1> %725, %762
  %764 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %761)
  %765 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %763)
  %766 = and i1 %764, %765
  br i1 %766, label %varying.divergent737, label %varying.coherent738

schedule.34:                                      ; preds = %varying.coherent.true743, %scheduler.dispatch.route
  %767 = load <8 x i1>, ptr %current.mask, align 1
  %768 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %767)
  %769 = bitcast <8 x i1> %767 to i8
  %770 = call i8 @llvm.cttz.i8(i8 %769, i1 false)
  %771 = zext i8 %770 to i32
  %772 = select i1 %768, i32 %771, i32 0
  %tile_snapshot.spill.load745 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill81, align 64
  %773 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load745, 0
  %774 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load745, 1
  %.spill.load746 = load volatile <8 x i64>, ptr %.spill87, align 64
  %775 = mul <8 x i64> %.spill.load746, splat (i64 32)
  %776 = add <8 x i64> %774, %775
  %777 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %773, 0
  %778 = insertvalue { <8 x ptr>, <8 x i64> } %777, <8 x i64> %776, 1
  %779 = extractvalue { <8 x ptr>, <8 x i64> } %778, 0
  %780 = extractvalue { <8 x ptr>, <8 x i64> } %778, 1
  %781 = getelementptr i8, <8 x ptr> %779, <8 x i64> %780
  %782 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %781, i32 1, <8 x i1> %767, <8 x float> zeroinitializer)
  %783 = load <8 x float>, ptr %.slot88, align 32
  %784 = select <8 x i1> %767, <8 x float> %782, <8 x float> %783
  store <8 x float> %784, ptr %.slot88, align 32
  store <8 x i1> %767, ptr %current.mask, align 1
  %785 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %767)
  br i1 %785, label %schedule.35, label %scheduler.loop

schedule.35:                                      ; preds = %schedule.34, %varying.coherent.false744, %scheduler.dispatch.route
  %786 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token749 = load i32, ptr %current.token, align 4
  %convergence.token.present750 = icmp ne i32 %convergence.current.token749, 0
  br i1 %convergence.token.present750, label %convergence.cascade747, label %convergence.cascade.exit748

schedule.36:                                      ; preds = %varying.coherent.false733, %scheduler.dispatch.route
  %787 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token774 = load i32, ptr %current.token, align 4
  %convergence.token.present775 = icmp ne i32 %convergence.current.token774, 0
  br i1 %convergence.token.present775, label %convergence.cascade772, label %convergence.cascade.exit773

schedule.37:                                      ; preds = %schedule.38, %convergence.target.36.ready, %scheduler.dispatch.route
  %788 = load <8 x i1>, ptr %current.mask, align 1
  %789 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %788)
  %790 = bitcast <8 x i1> %788 to i8
  %791 = call i8 @llvm.cttz.i8(i8 %790, i1 false)
  %792 = zext i8 %791 to i32
  %793 = select i1 %789, i32 %792, i32 0
  %.state789 = load <8 x i64>, ptr %.slot90, align 64
  %794 = icmp slt <8 x i64> %.state789, splat (i64 128)
  %795 = and <8 x i1> %788, %794
  %796 = xor <8 x i1> %794, splat (i1 true)
  %797 = and <8 x i1> %788, %796
  %798 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %795)
  %799 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %797)
  %800 = and i1 %798, %799
  br i1 %800, label %varying.divergent790, label %varying.coherent791

schedule.38:                                      ; preds = %varying.coherent.true796, %scheduler.dispatch.route
  %801 = load <8 x i1>, ptr %current.mask, align 1
  %802 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %801)
  %803 = bitcast <8 x i1> %801 to i8
  %804 = call i8 @llvm.cttz.i8(i8 %803, i1 false)
  %805 = zext i8 %804 to i32
  %806 = select i1 %802, i32 %805, i32 0
  %.state798 = load <8 x i64>, ptr %.slot90, align 64
  %807 = select <8 x i1> %801, <8 x i64> %.state798, <8 x i64> zeroinitializer
  %808 = select <8 x i1> %801, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %809 = srem <8 x i64> %807, %808
  %.state799 = load <8 x i64>, ptr %.slot90, align 64
  %810 = select <8 x i1> %801, <8 x i64> %.state799, <8 x i64> zeroinitializer
  %811 = select <8 x i1> %801, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %812 = sdiv <8 x i64> %810, %811
  %813 = add <8 x i64> zeroinitializer, %812
  %814 = mul <8 x i64> %813, splat (i64 32)
  %815 = add <8 x i64> %814, %809
  %tile_snapshot.spill.load800 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill81, align 64
  %816 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load800, 0
  %817 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load800, 1
  %818 = mul <8 x i64> %815, splat (i64 32)
  %819 = add <8 x i64> %817, %818
  %820 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %816, 0
  %821 = insertvalue { <8 x ptr>, <8 x i64> } %820, <8 x i64> %819, 1
  %822 = extractvalue { <8 x ptr>, <8 x i64> } %821, 0
  %823 = extractvalue { <8 x ptr>, <8 x i64> } %821, 1
  %824 = getelementptr i8, <8 x ptr> %822, <8 x i64> %823
  %825 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %824, i32 1, <8 x i1> %801, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load801 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill84, align 64
  %826 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load801, 0
  %827 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load801, 1
  %828 = mul <8 x i64> %815, splat (i64 32)
  %829 = add <8 x i64> %827, %828
  %830 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %826, 0
  %831 = insertvalue { <8 x ptr>, <8 x i64> } %830, <8 x i64> %829, 1
  %832 = extractvalue { <8 x ptr>, <8 x i64> } %831, 0
  %833 = extractvalue { <8 x ptr>, <8 x i64> } %831, 1
  %834 = getelementptr i8, <8 x ptr> %832, <8 x i64> %833
  %835 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %834, i32 1, <8 x i1> %801, <8 x float> zeroinitializer)
  %836 = fadd <8 x float> %825, %835
  %tile_snapshot.spill.load802 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill89, align 64
  %837 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load802, 0
  %838 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load802, 1
  %.state803 = load <8 x i64>, ptr %.slot90, align 64
  %839 = mul <8 x i64> %.state803, splat (i64 32)
  %840 = add <8 x i64> %838, %839
  %841 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %837, 0
  %842 = insertvalue { <8 x ptr>, <8 x i64> } %841, <8 x i64> %840, 1
  %843 = extractvalue { <8 x ptr>, <8 x i64> } %842, 0
  %844 = extractvalue { <8 x ptr>, <8 x i64> } %842, 1
  %845 = getelementptr i8, <8 x ptr> %843, <8 x i64> %844
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %836, <8 x ptr> %845, i32 1, <8 x i1> %801)
  %.state804 = load <8 x i64>, ptr %.slot90, align 64
  %846 = add <8 x i64> %.state804, splat (i64 1)
  %847 = load <8 x i64>, ptr %.slot90, align 64
  %848 = select <8 x i1> %801, <8 x i64> %846, <8 x i64> %847
  store <8 x i64> %848, ptr %.slot90, align 64
  store <8 x i1> %801, ptr %current.mask, align 1
  %849 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %801)
  br i1 %849, label %schedule.37, label %scheduler.loop

schedule.39:                                      ; preds = %varying.coherent.false797, %scheduler.dispatch.route
  %850 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token807 = load i32, ptr %current.token, align 4
  %convergence.token.present808 = icmp ne i32 %convergence.current.token807, 0
  br i1 %convergence.token.present808, label %convergence.cascade805, label %convergence.cascade.exit806

schedule.40:                                      ; preds = %convergence.target.43.ready, %convergence.target.39.ready, %scheduler.dispatch.route
  %851 = load <8 x i1>, ptr %current.mask, align 1
  %852 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %851)
  %853 = bitcast <8 x i1> %851 to i8
  %854 = call i8 @llvm.cttz.i8(i8 %853, i1 false)
  %855 = zext i8 %854 to i32
  %856 = select i1 %852, i32 %855, i32 0
  %.state886 = load <8 x i64>, ptr %.slot93, align 64
  %857 = icmp slt <8 x i64> %.state886, splat (i64 128)
  %858 = and <8 x i1> %851, %857
  %859 = xor <8 x i1> %857, splat (i1 true)
  %860 = and <8 x i1> %851, %859
  %861 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %858)
  %862 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %860)
  %863 = and i1 %861, %862
  br i1 %863, label %varying.divergent887, label %varying.coherent888

schedule.41:                                      ; preds = %varying.coherent.true893, %scheduler.dispatch.route
  %864 = load <8 x i1>, ptr %current.mask, align 1
  %865 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %864)
  %866 = bitcast <8 x i1> %864 to i8
  %867 = call i8 @llvm.cttz.i8(i8 %866, i1 false)
  %868 = zext i8 %867 to i32
  %869 = select i1 %865, i32 %868, i32 0
  %.state895 = load <8 x i64>, ptr %.slot93, align 64
  %870 = select <8 x i1> %864, <8 x i64> %.state895, <8 x i64> zeroinitializer
  %871 = select <8 x i1> %864, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %872 = srem <8 x i64> %870, %871
  %.state896 = load <8 x i64>, ptr %.slot93, align 64
  %873 = select <8 x i1> %864, <8 x i64> %.state896, <8 x i64> zeroinitializer
  %874 = select <8 x i1> %864, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %875 = sdiv <8 x i64> %873, %874
  %876 = add <8 x i64> zeroinitializer, %872
  %tile_snapshot.spill.load897 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill91, align 64
  %877 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load897, 0
  %878 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load897, 1
  %879 = mul <8 x i64> %876, splat (i64 64)
  %880 = add <8 x i64> %878, %879
  %881 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %877, 0
  %882 = insertvalue { <8 x ptr>, <8 x i64> } %881, <8 x i64> %880, 1
  %883 = extractvalue { <8 x ptr>, <8 x i64> } %882, 0
  %884 = extractvalue { <8 x ptr>, <8 x i64> } %882, 1
  %885 = getelementptr i8, <8 x ptr> %883, <8 x i64> %884
  %886 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> %885, i32 1, <8 x i1> %864, <8 x i64> zeroinitializer)
  %887 = icmp sge <8 x i64> %886, zeroinitializer
  %888 = icmp slt <8 x i64> %886, splat (i64 32)
  %889 = and <8 x i1> %887, %888
  %890 = load volatile <8 x i1>, ptr %.spill94, align 1
  %891 = select <8 x i1> %864, <8 x i1> %889, <8 x i1> %890
  store volatile <8 x i1> %891, ptr %.spill94, align 1
  %892 = add <8 x i64> zeroinitializer, %875
  %893 = mul <8 x i64> %892, splat (i64 32)
  %894 = add <8 x i64> %893, %886
  %895 = load volatile <8 x i64>, ptr %.spill95, align 64
  %896 = select <8 x i1> %864, <8 x i64> %894, <8 x i64> %895
  store volatile <8 x i64> %896, ptr %.spill95, align 64
  %897 = icmp sge <8 x i64> %894, zeroinitializer
  %898 = icmp slt <8 x i64> %894, splat (i64 128)
  %899 = and <8 x i1> %897, %898
  %900 = and <8 x i1> %864, %899
  %901 = xor <8 x i1> %899, splat (i1 true)
  %902 = and <8 x i1> %864, %901
  %903 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %900)
  %904 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %902)
  %905 = and i1 %903, %904
  br i1 %905, label %varying.divergent898, label %varying.coherent899

schedule.42:                                      ; preds = %varying.coherent.true904, %scheduler.dispatch.route
  %906 = load <8 x i1>, ptr %current.mask, align 1
  %907 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %906)
  %908 = bitcast <8 x i1> %906 to i8
  %909 = call i8 @llvm.cttz.i8(i8 %908, i1 false)
  %910 = zext i8 %909 to i32
  %911 = select i1 %907, i32 %910, i32 0
  %tile_snapshot.spill.load906 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill89, align 64
  %912 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load906, 0
  %913 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load906, 1
  %.spill.load907 = load volatile <8 x i64>, ptr %.spill95, align 64
  %914 = mul <8 x i64> %.spill.load907, splat (i64 32)
  %915 = add <8 x i64> %913, %914
  %916 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %912, 0
  %917 = insertvalue { <8 x ptr>, <8 x i64> } %916, <8 x i64> %915, 1
  %918 = extractvalue { <8 x ptr>, <8 x i64> } %917, 0
  %919 = extractvalue { <8 x ptr>, <8 x i64> } %917, 1
  %920 = getelementptr i8, <8 x ptr> %918, <8 x i64> %919
  %921 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %920, i32 1, <8 x i1> %906, <8 x float> zeroinitializer)
  %922 = load <8 x float>, ptr %.slot96, align 32
  %923 = select <8 x i1> %906, <8 x float> %921, <8 x float> %922
  store <8 x float> %923, ptr %.slot96, align 32
  store <8 x i1> %906, ptr %current.mask, align 1
  %924 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %906)
  br i1 %924, label %schedule.43, label %scheduler.loop

schedule.43:                                      ; preds = %schedule.42, %varying.coherent.false905, %scheduler.dispatch.route
  %925 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token910 = load i32, ptr %current.token, align 4
  %convergence.token.present911 = icmp ne i32 %convergence.current.token910, 0
  br i1 %convergence.token.present911, label %convergence.cascade908, label %convergence.cascade.exit909

schedule.44:                                      ; preds = %varying.coherent.false894, %scheduler.dispatch.route
  %926 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token935 = load i32, ptr %current.token, align 4
  %convergence.token.present936 = icmp ne i32 %convergence.current.token935, 0
  br i1 %convergence.token.present936, label %convergence.cascade933, label %convergence.cascade.exit934

schedule.45:                                      ; preds = %schedule.46, %convergence.target.44.ready, %scheduler.dispatch.route
  %927 = load <8 x i1>, ptr %current.mask, align 1
  %928 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %927)
  %929 = bitcast <8 x i1> %927 to i8
  %930 = call i8 @llvm.cttz.i8(i8 %929, i1 false)
  %931 = zext i8 %930 to i32
  %932 = select i1 %928, i32 %931, i32 0
  %.state950 = load <8 x i64>, ptr %.slot98, align 64
  %933 = icmp slt <8 x i64> %.state950, splat (i64 128)
  %934 = and <8 x i1> %927, %933
  %935 = xor <8 x i1> %933, splat (i1 true)
  %936 = and <8 x i1> %927, %935
  %937 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %934)
  %938 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %936)
  %939 = and i1 %937, %938
  br i1 %939, label %varying.divergent951, label %varying.coherent952

schedule.46:                                      ; preds = %varying.coherent.true957, %scheduler.dispatch.route
  %940 = load <8 x i1>, ptr %current.mask, align 1
  %941 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %940)
  %942 = bitcast <8 x i1> %940 to i8
  %943 = call i8 @llvm.cttz.i8(i8 %942, i1 false)
  %944 = zext i8 %943 to i32
  %945 = select i1 %941, i32 %944, i32 0
  %.state959 = load <8 x i64>, ptr %.slot98, align 64
  %946 = select <8 x i1> %940, <8 x i64> %.state959, <8 x i64> zeroinitializer
  %947 = select <8 x i1> %940, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %948 = srem <8 x i64> %946, %947
  %.state960 = load <8 x i64>, ptr %.slot98, align 64
  %949 = select <8 x i1> %940, <8 x i64> %.state960, <8 x i64> zeroinitializer
  %950 = select <8 x i1> %940, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %951 = sdiv <8 x i64> %949, %950
  %952 = add <8 x i64> zeroinitializer, %951
  %953 = mul <8 x i64> %952, splat (i64 32)
  %954 = add <8 x i64> %953, %948
  %955 = select <8 x i1> %940, <8 x i64> %954, <8 x i64> zeroinitializer
  %956 = select <8 x i1> %940, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %957 = srem <8 x i64> %955, %956
  %958 = select <8 x i1> %940, <8 x i64> %954, <8 x i64> zeroinitializer
  %959 = select <8 x i1> %940, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %960 = sdiv <8 x i64> %958, %959
  %961 = add <8 x i64> zeroinitializer, %960
  %962 = mul <8 x i64> %961, splat (i64 32)
  %963 = add <8 x i64> %962, %957
  %tile_snapshot.spill.load961 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill89, align 64
  %964 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load961, 0
  %965 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load961, 1
  %966 = mul <8 x i64> %963, splat (i64 32)
  %967 = add <8 x i64> %965, %966
  %968 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %964, 0
  %969 = insertvalue { <8 x ptr>, <8 x i64> } %968, <8 x i64> %967, 1
  %970 = extractvalue { <8 x ptr>, <8 x i64> } %969, 0
  %971 = extractvalue { <8 x ptr>, <8 x i64> } %969, 1
  %972 = getelementptr i8, <8 x ptr> %970, <8 x i64> %971
  %973 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %972, i32 1, <8 x i1> %940, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load962 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill92, align 64
  %974 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load962, 0
  %975 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load962, 1
  %976 = mul <8 x i64> %963, splat (i64 32)
  %977 = add <8 x i64> %975, %976
  %978 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %974, 0
  %979 = insertvalue { <8 x ptr>, <8 x i64> } %978, <8 x i64> %977, 1
  %980 = extractvalue { <8 x ptr>, <8 x i64> } %979, 0
  %981 = extractvalue { <8 x ptr>, <8 x i64> } %979, 1
  %982 = getelementptr i8, <8 x ptr> %980, <8 x i64> %981
  %983 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %982, i32 1, <8 x i1> %940, <8 x float> zeroinitializer)
  %984 = fadd <8 x float> %973, %983
  %tile_snapshot.spill.load963 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %985 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load963, 0
  %986 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load963, 1
  %987 = mul <8 x i64> %952, splat (i64 32)
  %988 = add <8 x i64> %986, %987
  %989 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %985, 0
  %990 = insertvalue { <8 x ptr>, <8 x i64> } %989, <8 x i64> %988, 1
  %991 = extractvalue { <8 x ptr>, <8 x i64> } %990, 0
  %992 = extractvalue { <8 x ptr>, <8 x i64> } %990, 1
  %993 = getelementptr i8, <8 x ptr> %991, <8 x i64> %992
  %994 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %993, i32 1, <8 x i1> %940, <8 x float> zeroinitializer)
  %995 = fadd <8 x float> %984, %994
  %tile_snapshot.spill.load964 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %996 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load964, 0
  %997 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load964, 1
  %.state965 = load <8 x i64>, ptr %.slot98, align 64
  %998 = mul <8 x i64> %.state965, splat (i64 32)
  %999 = add <8 x i64> %997, %998
  %1000 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %996, 0
  %1001 = insertvalue { <8 x ptr>, <8 x i64> } %1000, <8 x i64> %999, 1
  %1002 = extractvalue { <8 x ptr>, <8 x i64> } %1001, 0
  %1003 = extractvalue { <8 x ptr>, <8 x i64> } %1001, 1
  %1004 = getelementptr i8, <8 x ptr> %1002, <8 x i64> %1003
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %995, <8 x ptr> %1004, i32 1, <8 x i1> %940)
  %.state966 = load <8 x i64>, ptr %.slot98, align 64
  %1005 = add <8 x i64> %.state966, splat (i64 1)
  %1006 = load <8 x i64>, ptr %.slot98, align 64
  %1007 = select <8 x i1> %940, <8 x i64> %1005, <8 x i64> %1006
  store <8 x i64> %1007, ptr %.slot98, align 64
  store <8 x i1> %940, ptr %current.mask, align 1
  %1008 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %940)
  br i1 %1008, label %schedule.45, label %scheduler.loop

schedule.47:                                      ; preds = %varying.coherent.false958, %scheduler.dispatch.route
  %1009 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token969 = load i32, ptr %current.token, align 4
  %convergence.token.present970 = icmp ne i32 %convergence.current.token969, 0
  br i1 %convergence.token.present970, label %convergence.cascade967, label %convergence.cascade.exit968

schedule.48:                                      ; preds = %convergence.target.51.ready, %convergence.target.47.ready, %scheduler.dispatch.route
  %1010 = load <8 x i1>, ptr %current.mask, align 1
  %1011 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1010)
  %1012 = bitcast <8 x i1> %1010 to i8
  %1013 = call i8 @llvm.cttz.i8(i8 %1012, i1 false)
  %1014 = zext i8 %1013 to i32
  %1015 = select i1 %1011, i32 %1014, i32 0
  %.state984 = load <8 x i64>, ptr %.slot99, align 64
  %1016 = icmp slt <8 x i64> %.state984, splat (i64 128)
  %1017 = and <8 x i1> %1010, %1016
  %1018 = xor <8 x i1> %1016, splat (i1 true)
  %1019 = and <8 x i1> %1010, %1018
  %1020 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1017)
  %1021 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1019)
  %1022 = and i1 %1020, %1021
  br i1 %1022, label %varying.divergent985, label %varying.coherent986

schedule.49:                                      ; preds = %varying.coherent.true991, %scheduler.dispatch.route
  %1023 = load <8 x i1>, ptr %current.mask, align 1
  %1024 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1023)
  %1025 = bitcast <8 x i1> %1023 to i8
  %1026 = call i8 @llvm.cttz.i8(i8 %1025, i1 false)
  %1027 = zext i8 %1026 to i32
  %1028 = select i1 %1024, i32 %1027, i32 0
  %.state993 = load <8 x i64>, ptr %.slot99, align 64
  %1029 = select <8 x i1> %1023, <8 x i64> %.state993, <8 x i64> zeroinitializer
  %1030 = select <8 x i1> %1023, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %1031 = srem <8 x i64> %1029, %1030
  %.state994 = load <8 x i64>, ptr %.slot99, align 64
  %1032 = select <8 x i1> %1023, <8 x i64> %.state994, <8 x i64> zeroinitializer
  %1033 = select <8 x i1> %1023, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %1034 = sdiv <8 x i64> %1032, %1033
  %.spill.load995 = load volatile <8 x i64>, ptr %.spill, align 64
  %1035 = add <8 x i64> %.spill.load995, %1034
  %1036 = add <8 x i64> zeroinitializer, %1035
  %1037 = icmp sge <8 x i64> %1035, zeroinitializer
  %1038 = and <8 x i1> splat (i1 true), %1037
  %1039 = icmp slt <8 x i64> %1035, splat (i64 17)
  %1040 = and <8 x i1> %1038, %1039
  %.spill.load996 = load volatile <8 x i64>, ptr %.spill54, align 64
  %1041 = add <8 x i64> %.spill.load996, %1031
  %1042 = mul <8 x i64> %1036, splat (i64 65)
  %1043 = add <8 x i64> %1042, %1041
  %1044 = icmp sge <8 x i64> %1041, zeroinitializer
  %1045 = and <8 x i1> %1040, %1044
  %1046 = icmp slt <8 x i64> %1041, splat (i64 65)
  %1047 = and <8 x i1> %1045, %1046
  %1048 = load volatile <8 x i64>, ptr %.spill100, align 64
  %1049 = select <8 x i1> %1023, <8 x i64> %1043, <8 x i64> %1048
  store volatile <8 x i64> %1049, ptr %.spill100, align 64
  %tile_snapshot.spill.load997 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %1050 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load997, 0
  %1051 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load997, 1
  %.state998 = load <8 x i64>, ptr %.slot99, align 64
  %1052 = mul <8 x i64> %.state998, splat (i64 32)
  %1053 = add <8 x i64> %1051, %1052
  %1054 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1050, 0
  %1055 = insertvalue { <8 x ptr>, <8 x i64> } %1054, <8 x i64> %1053, 1
  %1056 = extractvalue { <8 x ptr>, <8 x i64> } %1055, 0
  %1057 = extractvalue { <8 x ptr>, <8 x i64> } %1055, 1
  %1058 = getelementptr i8, <8 x ptr> %1056, <8 x i64> %1057
  %1059 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %1058, i32 1, <8 x i1> %1023, <8 x float> zeroinitializer)
  %1060 = load volatile <8 x float>, ptr %.spill101, align 32
  %1061 = select <8 x i1> %1023, <8 x float> %1059, <8 x float> %1060
  store volatile <8 x float> %1061, ptr %.spill101, align 32
  %1062 = and <8 x i1> %1023, %1047
  %1063 = xor <8 x i1> %1047, splat (i1 true)
  %1064 = and <8 x i1> %1023, %1063
  %1065 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1062)
  %1066 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1064)
  %1067 = and i1 %1065, %1066
  br i1 %1067, label %varying.divergent999, label %varying.coherent1000

schedule.50:                                      ; preds = %varying.coherent.true1005, %scheduler.dispatch.route
  %1068 = load <8 x i1>, ptr %current.mask, align 1
  %1069 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1068)
  %1070 = bitcast <8 x i1> %1068 to i8
  %1071 = call i8 @llvm.cttz.i8(i8 %1070, i1 false)
  %1072 = zext i8 %1071 to i32
  %1073 = select i1 %1069, i32 %1072, i32 0
  %.spill.load1007 = load volatile <8 x i64>, ptr %.spill100, align 64
  %.spill.load1008 = load volatile <8 x float>, ptr %.spill101, align 32
  %1074 = extractvalue { ptr, i64 } %45, 0
  %1075 = mul <8 x i64> %.spill.load1007, splat (i64 4)
  %1076 = getelementptr i8, ptr %1074, <8 x i64> %1075
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.spill.load1008, <8 x ptr> %1076, i32 1, <8 x i1> %1068)
  store <8 x i1> %1068, ptr %current.mask, align 1
  %1077 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1068)
  br i1 %1077, label %schedule.51, label %scheduler.loop

schedule.51:                                      ; preds = %schedule.50, %varying.coherent.false1006, %scheduler.dispatch.route
  %1078 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1011 = load i32, ptr %current.token, align 4
  %convergence.token.present1012 = icmp ne i32 %convergence.current.token1011, 0
  br i1 %convergence.token.present1012, label %convergence.cascade1009, label %convergence.cascade.exit1010

schedule.52:                                      ; preds = %varying.coherent.false992, %scheduler.dispatch.route
  %1079 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1029 = load i32, ptr %current.token, align 4
  %convergence.token.present1030 = icmp ne i32 %convergence.current.token1029, 0
  br i1 %convergence.token.present1030, label %convergence.cascade1027, label %convergence.cascade.exit1028

schedule.53:                                      ; preds = %varying.coherent.false, %scheduler.dispatch.route
  %1080 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1058 = load i32, ptr %current.token, align 4
  %convergence.token.present1059 = icmp ne i32 %convergence.current.token1058, 0
  br i1 %convergence.token.present1059, label %convergence.cascade1056, label %convergence.cascade.exit1057

varying.divergent:                                ; preds = %schedule.1
  %1081 = load i32, ptr %current.token, align 4
  %1082 = icmp ne i32 %1081, 0
  %1083 = sub i32 %1081, 1
  %1084 = select i1 %1082, i32 %1083, i32 0
  %1085 = load i8, ptr %frame.active, align 1
  %1086 = trunc i32 %1084 to i8
  %1087 = shl i8 1, %1086
  %1088 = and i8 %1085, %1087
  %1089 = icmp ne i8 %1088, 0
  %1090 = load <8 x i32>, ptr %frame.static.id, align 32
  %1091 = extractelement <8 x i32> %1090, i32 %1084
  %1092 = icmp eq i32 %1091, 0
  %1093 = and i1 %1089, %1092
  %1094 = and i1 %1082, %1093
  %1095 = xor i1 %1094, true
  %1096 = and i1 true, %1095
  %1097 = xor i8 %1085, -1
  %1098 = icmp ne i8 %1097, 0
  %1099 = xor i1 %1098, true
  %1100 = and i1 %1096, %1099
  br i1 %1100, label %convergence.overflow.trap, label %convergence.overflow.resume

varying.coherent:                                 ; preds = %schedule.1
  br i1 %138, label %varying.coherent.true, label %varying.coherent.false

convergence.overflow.trap:                        ; preds = %varying.divergent
  call void @llvm.trap()
  unreachable

convergence.overflow.resume:                      ; preds = %varying.divergent
  %1101 = call i8 @llvm.cttz.i8(i8 %1097, i1 false)
  %1102 = zext i8 %1101 to i32
  %1103 = select i1 %1098, i32 %1102, i32 0
  %1104 = trunc i32 %1103 to i8
  %1105 = shl i8 1, %1104
  %1106 = or i8 %1085, %1105
  %1107 = select i1 %1096, i8 %1106, i8 %1085
  store i8 %1107, ptr %frame.active, align 1
  %1108 = load <8 x i32>, ptr %frame.static.id, align 32
  %1109 = extractelement <8 x i32> %1108, i32 %1103
  %1110 = select i1 %1096, i32 0, i32 %1109
  %1111 = load <8 x i32>, ptr %frame.static.id, align 32
  %1112 = insertelement <8 x i32> %1111, i32 %1110, i32 %1103
  store <8 x i32> %1112, ptr %frame.static.id, align 32
  %1113 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1114 = extractelement <8 x i32> %1113, i32 %1103
  %1115 = select i1 %1096, i32 %1081, i32 %1114
  %1116 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1117 = insertelement <8 x i32> %1116, i32 %1115, i32 %1103
  store <8 x i32> %1117, ptr %frame.parent.token, align 32
  %1118 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1103
  %1119 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1103
  %1120 = load <8 x i1>, ptr %1118, align 1
  %1121 = load <8 x i1>, ptr %1119, align 1
  %1122 = select i1 %1096, <8 x i1> %128, <8 x i1> %1120
  store <8 x i1> %1122, ptr %1118, align 1
  %1123 = select i1 %1096, <8 x i1> zeroinitializer, <8 x i1> %1121
  store <8 x i1> %1123, ptr %1119, align 1
  %1124 = add i32 %1103, 1
  %1125 = select i1 %1094, i32 %1081, i32 %1124
  %1126 = select i1 true, i32 %1125, i32 %1081
  store i32 %1126, ptr %current.token, align 4
  %1127 = load i32, ptr %current.token, align 4
  %1128 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %135)
  %1129 = load i32, ptr %ready.count, align 4
  %1130 = icmp uge i32 %1129, 8
  %1131 = and i1 %1128, %1130
  br i1 %1131, label %ready.overflow.trap112, label %ready.overflow.resume113

ready.overflow.trap112:                           ; preds = %convergence.overflow.resume
  call void @llvm.trap()
  unreachable

ready.overflow.resume113:                         ; preds = %convergence.overflow.resume
  %1132 = select i1 %1128, i32 %1129, i32 0
  %1133 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1132
  %1134 = load <8 x i1>, ptr %1133, align 1
  %1135 = select i1 %1128, <8 x i1> %135, <8 x i1> %1134
  store <8 x i1> %1135, ptr %1133, align 1
  %1136 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1132
  %1137 = load i32, ptr %1136, align 4
  %1138 = select i1 %1128, i32 2, i32 %1137
  store i32 %1138, ptr %1136, align 4
  %1139 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1132
  %1140 = load i32, ptr %1139, align 4
  %1141 = select i1 %1128, i32 %1127, i32 %1140
  store i32 %1141, ptr %1139, align 4
  %1142 = add i32 %1129, 1
  %1143 = select i1 %1128, i32 %1142, i32 %1129
  store i32 %1143, ptr %ready.count, align 4
  %1144 = load <8 x i1>, ptr %runnable.mask, align 1
  %1145 = or <8 x i1> %1144, %135
  store <8 x i1> %1145, ptr %runnable.mask, align 1
  store <8 x i1> %137, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true:                            ; preds = %varying.coherent
  store <8 x i1> %128, ptr %current.mask, align 1
  %1146 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %128)
  br i1 %1146, label %schedule.2, label %scheduler.loop

varying.coherent.false:                           ; preds = %varying.coherent
  store <8 x i1> %128, ptr %current.mask, align 1
  %1147 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %128)
  br i1 %1147, label %schedule.53, label %scheduler.loop

varying.divergent126:                             ; preds = %schedule.3
  %1148 = load i32, ptr %current.token, align 4
  %1149 = icmp ne i32 %1148, 0
  %1150 = sub i32 %1148, 1
  %1151 = select i1 %1149, i32 %1150, i32 0
  %1152 = load i8, ptr %frame.active, align 1
  %1153 = trunc i32 %1151 to i8
  %1154 = shl i8 1, %1153
  %1155 = and i8 %1152, %1154
  %1156 = icmp ne i8 %1155, 0
  %1157 = load <8 x i32>, ptr %frame.static.id, align 32
  %1158 = extractelement <8 x i32> %1157, i32 %1151
  %1159 = icmp eq i32 %1158, 1
  %1160 = and i1 %1156, %1159
  %1161 = and i1 %1149, %1160
  %1162 = xor i1 %1161, true
  %1163 = and i1 true, %1162
  %1164 = xor i8 %1152, -1
  %1165 = icmp ne i8 %1164, 0
  %1166 = xor i1 %1165, true
  %1167 = and i1 %1163, %1166
  br i1 %1167, label %convergence.overflow.trap128, label %convergence.overflow.resume129

varying.coherent127:                              ; preds = %schedule.3
  br i1 %244, label %varying.coherent.true132, label %varying.coherent.false133

convergence.overflow.trap128:                     ; preds = %varying.divergent126
  call void @llvm.trap()
  unreachable

convergence.overflow.resume129:                   ; preds = %varying.divergent126
  %1168 = call i8 @llvm.cttz.i8(i8 %1164, i1 false)
  %1169 = zext i8 %1168 to i32
  %1170 = select i1 %1165, i32 %1169, i32 0
  %1171 = trunc i32 %1170 to i8
  %1172 = shl i8 1, %1171
  %1173 = or i8 %1152, %1172
  %1174 = select i1 %1163, i8 %1173, i8 %1152
  store i8 %1174, ptr %frame.active, align 1
  %1175 = load <8 x i32>, ptr %frame.static.id, align 32
  %1176 = extractelement <8 x i32> %1175, i32 %1170
  %1177 = select i1 %1163, i32 1, i32 %1176
  %1178 = load <8 x i32>, ptr %frame.static.id, align 32
  %1179 = insertelement <8 x i32> %1178, i32 %1177, i32 %1170
  store <8 x i32> %1179, ptr %frame.static.id, align 32
  %1180 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1181 = extractelement <8 x i32> %1180, i32 %1170
  %1182 = select i1 %1163, i32 %1148, i32 %1181
  %1183 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1184 = insertelement <8 x i32> %1183, i32 %1182, i32 %1170
  store <8 x i32> %1184, ptr %frame.parent.token, align 32
  %1185 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1170
  %1186 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1170
  %1187 = load <8 x i1>, ptr %1185, align 1
  %1188 = load <8 x i1>, ptr %1186, align 1
  %1189 = select i1 %1163, <8 x i1> %234, <8 x i1> %1187
  store <8 x i1> %1189, ptr %1185, align 1
  %1190 = select i1 %1163, <8 x i1> zeroinitializer, <8 x i1> %1188
  store <8 x i1> %1190, ptr %1186, align 1
  %1191 = add i32 %1170, 1
  %1192 = select i1 %1161, i32 %1148, i32 %1191
  %1193 = select i1 true, i32 %1192, i32 %1148
  store i32 %1193, ptr %current.token, align 4
  %1194 = load i32, ptr %current.token, align 4
  %1195 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %241)
  %1196 = load i32, ptr %ready.count, align 4
  %1197 = icmp uge i32 %1196, 8
  %1198 = and i1 %1195, %1197
  br i1 %1198, label %ready.overflow.trap130, label %ready.overflow.resume131

ready.overflow.trap130:                           ; preds = %convergence.overflow.resume129
  call void @llvm.trap()
  unreachable

ready.overflow.resume131:                         ; preds = %convergence.overflow.resume129
  %1199 = select i1 %1195, i32 %1196, i32 0
  %1200 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1199
  %1201 = load <8 x i1>, ptr %1200, align 1
  %1202 = select i1 %1195, <8 x i1> %241, <8 x i1> %1201
  store <8 x i1> %1202, ptr %1200, align 1
  %1203 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1199
  %1204 = load i32, ptr %1203, align 4
  %1205 = select i1 %1195, i32 4, i32 %1204
  store i32 %1205, ptr %1203, align 4
  %1206 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1199
  %1207 = load i32, ptr %1206, align 4
  %1208 = select i1 %1195, i32 %1194, i32 %1207
  store i32 %1208, ptr %1206, align 4
  %1209 = add i32 %1196, 1
  %1210 = select i1 %1195, i32 %1209, i32 %1196
  store i32 %1210, ptr %ready.count, align 4
  %1211 = load <8 x i1>, ptr %runnable.mask, align 1
  %1212 = or <8 x i1> %1211, %241
  store <8 x i1> %1212, ptr %runnable.mask, align 1
  store <8 x i1> %243, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true132:                         ; preds = %varying.coherent127
  store <8 x i1> %234, ptr %current.mask, align 1
  %1213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %234)
  br i1 %1213, label %schedule.4, label %scheduler.loop

varying.coherent.false133:                        ; preds = %varying.coherent127
  store <8 x i1> %234, ptr %current.mask, align 1
  %1214 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %234)
  br i1 %1214, label %schedule.7, label %scheduler.loop

varying.divergent137:                             ; preds = %schedule.4
  %1215 = load i32, ptr %current.token, align 4
  %1216 = icmp ne i32 %1215, 0
  %1217 = sub i32 %1215, 1
  %1218 = select i1 %1216, i32 %1217, i32 0
  %1219 = load i8, ptr %frame.active, align 1
  %1220 = trunc i32 %1218 to i8
  %1221 = shl i8 1, %1220
  %1222 = and i8 %1219, %1221
  %1223 = icmp ne i8 %1222, 0
  %1224 = load <8 x i32>, ptr %frame.static.id, align 32
  %1225 = extractelement <8 x i32> %1224, i32 %1218
  %1226 = icmp eq i32 %1225, 2
  %1227 = and i1 %1223, %1226
  %1228 = and i1 %1216, %1227
  %1229 = xor i1 %1228, true
  %1230 = and i1 true, %1229
  %1231 = xor i8 %1219, -1
  %1232 = icmp ne i8 %1231, 0
  %1233 = xor i1 %1232, true
  %1234 = and i1 %1230, %1233
  br i1 %1234, label %convergence.overflow.trap139, label %convergence.overflow.resume140

varying.coherent138:                              ; preds = %schedule.4
  br i1 %277, label %varying.coherent.true146, label %varying.coherent.false147

convergence.overflow.trap139:                     ; preds = %varying.divergent137
  call void @llvm.trap()
  unreachable

convergence.overflow.resume140:                   ; preds = %varying.divergent137
  %1235 = call i8 @llvm.cttz.i8(i8 %1231, i1 false)
  %1236 = zext i8 %1235 to i32
  %1237 = select i1 %1232, i32 %1236, i32 0
  %1238 = trunc i32 %1237 to i8
  %1239 = shl i8 1, %1238
  %1240 = or i8 %1219, %1239
  %1241 = select i1 %1230, i8 %1240, i8 %1219
  store i8 %1241, ptr %frame.active, align 1
  %1242 = load <8 x i32>, ptr %frame.static.id, align 32
  %1243 = extractelement <8 x i32> %1242, i32 %1237
  %1244 = select i1 %1230, i32 2, i32 %1243
  %1245 = load <8 x i32>, ptr %frame.static.id, align 32
  %1246 = insertelement <8 x i32> %1245, i32 %1244, i32 %1237
  store <8 x i32> %1246, ptr %frame.static.id, align 32
  %1247 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1248 = extractelement <8 x i32> %1247, i32 %1237
  %1249 = select i1 %1230, i32 %1215, i32 %1248
  %1250 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1251 = insertelement <8 x i32> %1250, i32 %1249, i32 %1237
  store <8 x i32> %1251, ptr %frame.parent.token, align 32
  %1252 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1237
  %1253 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1237
  %1254 = load <8 x i1>, ptr %1252, align 1
  %1255 = load <8 x i1>, ptr %1253, align 1
  %1256 = select i1 %1230, <8 x i1> %247, <8 x i1> %1254
  store <8 x i1> %1256, ptr %1252, align 1
  %1257 = select i1 %1230, <8 x i1> zeroinitializer, <8 x i1> %1255
  store <8 x i1> %1257, ptr %1253, align 1
  %1258 = add i32 %1237, 1
  %1259 = select i1 %1228, i32 %1215, i32 %1258
  %1260 = select i1 true, i32 %1259, i32 %1215
  store i32 %1260, ptr %current.token, align 4
  %.spill.load141 = load float, ptr %.spill49, align 4
  %.splatinsert142 = insertelement <8 x float> poison, float %.spill.load141, i64 0
  %.splat143 = shufflevector <8 x float> %.splatinsert142, <8 x float> poison, <8 x i32> zeroinitializer
  %1261 = load <8 x float>, ptr %.slot58, align 32
  %1262 = select <8 x i1> %276, <8 x float> %.splat143, <8 x float> %1261
  store <8 x float> %1262, ptr %.slot58, align 32
  %1263 = load i32, ptr %current.token, align 4
  %1264 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %274)
  %1265 = load i32, ptr %ready.count, align 4
  %1266 = icmp uge i32 %1265, 8
  %1267 = and i1 %1264, %1266
  br i1 %1267, label %ready.overflow.trap144, label %ready.overflow.resume145

ready.overflow.trap144:                           ; preds = %convergence.overflow.resume140
  call void @llvm.trap()
  unreachable

ready.overflow.resume145:                         ; preds = %convergence.overflow.resume140
  %1268 = select i1 %1264, i32 %1265, i32 0
  %1269 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1268
  %1270 = load <8 x i1>, ptr %1269, align 1
  %1271 = select i1 %1264, <8 x i1> %274, <8 x i1> %1270
  store <8 x i1> %1271, ptr %1269, align 1
  %1272 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1268
  %1273 = load i32, ptr %1272, align 4
  %1274 = select i1 %1264, i32 5, i32 %1273
  store i32 %1274, ptr %1272, align 4
  %1275 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1268
  %1276 = load i32, ptr %1275, align 4
  %1277 = select i1 %1264, i32 %1263, i32 %1276
  store i32 %1277, ptr %1275, align 4
  %1278 = add i32 %1265, 1
  %1279 = select i1 %1264, i32 %1278, i32 %1265
  store i32 %1279, ptr %ready.count, align 4
  %1280 = load <8 x i1>, ptr %runnable.mask, align 1
  %1281 = or <8 x i1> %1280, %274
  store <8 x i1> %1281, ptr %runnable.mask, align 1
  store <8 x i1> %276, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true146:                         ; preds = %varying.coherent138
  store <8 x i1> %247, ptr %current.mask, align 1
  %1282 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %247)
  br i1 %1282, label %schedule.5, label %scheduler.loop

varying.coherent.false147:                        ; preds = %varying.coherent138
  %.spill.load148 = load float, ptr %.spill49, align 4
  %.splatinsert149 = insertelement <8 x float> poison, float %.spill.load148, i64 0
  %.splat150 = shufflevector <8 x float> %.splatinsert149, <8 x float> poison, <8 x i32> zeroinitializer
  %1283 = load <8 x float>, ptr %.slot58, align 32
  %1284 = select <8 x i1> %247, <8 x float> %.splat150, <8 x float> %1283
  store <8 x float> %1284, ptr %.slot58, align 32
  store <8 x i1> %247, ptr %current.mask, align 1
  %1285 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %247)
  br i1 %1285, label %schedule.6, label %scheduler.loop

convergence.cascade:                              ; preds = %convergence.cascade, %schedule.6
  %convergence.cascade.flow = phi <8 x i1> [ %293, %schedule.6 ], [ %1328, %convergence.cascade ]
  %convergence.cascade.depth = phi i32 [ 0, %schedule.6 ], [ %1329, %convergence.cascade ]
  %1286 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow)
  %1287 = load i32, ptr %current.token, align 4
  %1288 = icmp ne i32 %1287, 0
  %1289 = and i1 %1286, %1288
  %1290 = sub i32 %1287, 1
  %1291 = select i1 %1289, i32 %1290, i32 0
  %1292 = load i8, ptr %frame.active, align 1
  %1293 = trunc i32 %1291 to i8
  %1294 = shl i8 1, %1293
  %1295 = and i8 %1292, %1294
  %1296 = icmp ne i8 %1295, 0
  %1297 = load <8 x i32>, ptr %frame.static.id, align 32
  %1298 = extractelement <8 x i32> %1297, i32 %1291
  %convergence.target.pointer = getelementptr inbounds [20 x i32], ptr @convergence.targets, i32 0, i32 %1298
  %convergence.dynamic.target = load i32, ptr %convergence.target.pointer, align 4
  %1299 = icmp eq i32 %convergence.dynamic.target, 6
  %1300 = and i1 %1296, %1299
  %1301 = and i1 %1289, %1300
  %1302 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1291
  %1303 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1291
  %1304 = load <8 x i1>, ptr %1302, align 1
  %1305 = load <8 x i1>, ptr %1303, align 1
  %1306 = or <8 x i1> %1305, %convergence.cascade.flow
  %1307 = load <8 x i1>, ptr %live.mask, align 1
  %1308 = and <8 x i1> %1304, %1307
  %1309 = icmp eq <8 x i1> %1306, %1308
  %1310 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1309)
  %1311 = and i1 %1301, %1310
  %1312 = select i1 %1311, <8 x i1> zeroinitializer, <8 x i1> %1306
  %1313 = select i1 %1301, <8 x i1> %1312, <8 x i1> %1305
  store <8 x i1> %1313, ptr %1303, align 1
  %1314 = select i1 %1311, <8 x i1> zeroinitializer, <8 x i1> %1304
  store <8 x i1> %1314, ptr %1302, align 1
  %1315 = trunc i32 %1291 to i8
  %1316 = shl i8 1, %1315
  %1317 = xor i8 %1316, -1
  %1318 = and i8 %1292, %1317
  %1319 = select i1 %1311, i8 %1318, i8 %1292
  store i8 %1319, ptr %frame.active, align 1
  %.splatinsert152 = insertelement <8 x i1> poison, i1 %1301, i64 0
  %.splat153 = shufflevector <8 x i1> %.splatinsert152, <8 x i1> poison, <8 x i32> zeroinitializer
  %1320 = and <8 x i1> %convergence.cascade.flow, %.splat153
  %1321 = load <8 x i1>, ptr %runnable.mask, align 1
  %1322 = xor <8 x i1> %1320, splat (i1 true)
  %1323 = and <8 x i1> %1321, %1322
  store <8 x i1> %1323, ptr %runnable.mask, align 1
  %.splatinsert154 = insertelement <8 x i1> poison, i1 %1311, i64 0
  %.splat155 = shufflevector <8 x i1> %.splatinsert154, <8 x i1> poison, <8 x i32> zeroinitializer
  %1324 = select <8 x i1> %.splat155, <8 x i1> %1306, <8 x i1> zeroinitializer
  %1325 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1326 = extractelement <8 x i32> %1325, i32 %1291
  %1327 = select i1 %1311, i32 %1326, i32 %1287
  store i32 %1327, ptr %current.token, align 4
  %.splatinsert156 = insertelement <8 x i1> poison, i1 %1301, i64 0
  %.splat157 = shufflevector <8 x i1> %.splatinsert156, <8 x i1> poison, <8 x i32> zeroinitializer
  %1328 = select <8 x i1> %.splat157, <8 x i1> %1324, <8 x i1> %convergence.cascade.flow
  %1329 = add i32 %convergence.cascade.depth, 1
  %1330 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1328)
  %1331 = icmp ult i32 %1329, 8
  %1332 = and i1 %1330, %1331
  %1333 = and i1 %1301, %1332
  %convergence.parent.token = load i32, ptr %current.token, align 4
  %convergence.parent.present = icmp ne i32 %convergence.parent.token, 0
  %1334 = and i1 %1333, %convergence.parent.present
  br i1 %1334, label %convergence.cascade, label %convergence.cascade.exit

convergence.cascade.exit:                         ; preds = %convergence.cascade, %schedule.6
  %convergence.cascade.result = phi <8 x i1> [ %293, %schedule.6 ], [ %1328, %convergence.cascade ]
  %1335 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %1335, label %convergence.target.6.ready, label %scheduler.loop

convergence.target.6.ready:                       ; preds = %convergence.cascade.exit
  %1336 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1337 = bitcast <8 x i1> %convergence.cascade.result to i8
  %1338 = call i8 @llvm.cttz.i8(i8 %1337, i1 false)
  %1339 = zext i8 %1338 to i32
  %1340 = select i1 %1336, i32 %1339, i32 0
  %tile_snapshot.spill.load = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1341 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %1342 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state158 = load <8 x i64>, ptr %.slot56, align 64
  %1343 = mul <8 x i64> %.state158, splat (i64 32)
  %1344 = add <8 x i64> %1342, %1343
  %1345 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1341, 0
  %1346 = insertvalue { <8 x ptr>, <8 x i64> } %1345, <8 x i64> %1344, 1
  %.state159 = load <8 x float>, ptr %.slot58, align 32
  %1347 = extractvalue { <8 x ptr>, <8 x i64> } %1346, 0
  %1348 = extractvalue { <8 x ptr>, <8 x i64> } %1346, 1
  %1349 = getelementptr i8, <8 x ptr> %1347, <8 x i64> %1348
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state159, <8 x ptr> %1349, i32 1, <8 x i1> %convergence.cascade.result)
  %.state160 = load <8 x i64>, ptr %.slot56, align 64
  %1350 = add <8 x i64> %.state160, splat (i64 1)
  %1351 = load <8 x i64>, ptr %.slot56, align 64
  %1352 = select <8 x i1> %convergence.cascade.result, <8 x i64> %1350, <8 x i64> %1351
  store <8 x i64> %1352, ptr %.slot56, align 64
  store <8 x i1> %convergence.cascade.result, ptr %current.mask, align 1
  %1353 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %1353, label %schedule.3, label %scheduler.loop

convergence.cascade161:                           ; preds = %convergence.cascade161, %schedule.7
  %convergence.cascade.flow165 = phi <8 x i1> [ %294, %schedule.7 ], [ %1396, %convergence.cascade161 ]
  %convergence.cascade.depth166 = phi i32 [ 0, %schedule.7 ], [ %1397, %convergence.cascade161 ]
  %1354 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow165)
  %1355 = load i32, ptr %current.token, align 4
  %1356 = icmp ne i32 %1355, 0
  %1357 = and i1 %1354, %1356
  %1358 = sub i32 %1355, 1
  %1359 = select i1 %1357, i32 %1358, i32 0
  %1360 = load i8, ptr %frame.active, align 1
  %1361 = trunc i32 %1359 to i8
  %1362 = shl i8 1, %1361
  %1363 = and i8 %1360, %1362
  %1364 = icmp ne i8 %1363, 0
  %1365 = load <8 x i32>, ptr %frame.static.id, align 32
  %1366 = extractelement <8 x i32> %1365, i32 %1359
  %convergence.target.pointer167 = getelementptr inbounds [20 x i32], ptr @convergence.targets, i32 0, i32 %1366
  %convergence.dynamic.target168 = load i32, ptr %convergence.target.pointer167, align 4
  %1367 = icmp eq i32 %convergence.dynamic.target168, 7
  %1368 = and i1 %1364, %1367
  %1369 = and i1 %1357, %1368
  %1370 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1359
  %1371 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1359
  %1372 = load <8 x i1>, ptr %1370, align 1
  %1373 = load <8 x i1>, ptr %1371, align 1
  %1374 = or <8 x i1> %1373, %convergence.cascade.flow165
  %1375 = load <8 x i1>, ptr %live.mask, align 1
  %1376 = and <8 x i1> %1372, %1375
  %1377 = icmp eq <8 x i1> %1374, %1376
  %1378 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1377)
  %1379 = and i1 %1369, %1378
  %1380 = select i1 %1379, <8 x i1> zeroinitializer, <8 x i1> %1374
  %1381 = select i1 %1369, <8 x i1> %1380, <8 x i1> %1373
  store <8 x i1> %1381, ptr %1371, align 1
  %1382 = select i1 %1379, <8 x i1> zeroinitializer, <8 x i1> %1372
  store <8 x i1> %1382, ptr %1370, align 1
  %1383 = trunc i32 %1359 to i8
  %1384 = shl i8 1, %1383
  %1385 = xor i8 %1384, -1
  %1386 = and i8 %1360, %1385
  %1387 = select i1 %1379, i8 %1386, i8 %1360
  store i8 %1387, ptr %frame.active, align 1
  %.splatinsert169 = insertelement <8 x i1> poison, i1 %1369, i64 0
  %.splat170 = shufflevector <8 x i1> %.splatinsert169, <8 x i1> poison, <8 x i32> zeroinitializer
  %1388 = and <8 x i1> %convergence.cascade.flow165, %.splat170
  %1389 = load <8 x i1>, ptr %runnable.mask, align 1
  %1390 = xor <8 x i1> %1388, splat (i1 true)
  %1391 = and <8 x i1> %1389, %1390
  store <8 x i1> %1391, ptr %runnable.mask, align 1
  %.splatinsert171 = insertelement <8 x i1> poison, i1 %1379, i64 0
  %.splat172 = shufflevector <8 x i1> %.splatinsert171, <8 x i1> poison, <8 x i32> zeroinitializer
  %1392 = select <8 x i1> %.splat172, <8 x i1> %1374, <8 x i1> zeroinitializer
  %1393 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1394 = extractelement <8 x i32> %1393, i32 %1359
  %1395 = select i1 %1379, i32 %1394, i32 %1355
  store i32 %1395, ptr %current.token, align 4
  %.splatinsert173 = insertelement <8 x i1> poison, i1 %1369, i64 0
  %.splat174 = shufflevector <8 x i1> %.splatinsert173, <8 x i1> poison, <8 x i32> zeroinitializer
  %1396 = select <8 x i1> %.splat174, <8 x i1> %1392, <8 x i1> %convergence.cascade.flow165
  %1397 = add i32 %convergence.cascade.depth166, 1
  %1398 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1396)
  %1399 = icmp ult i32 %1397, 8
  %1400 = and i1 %1398, %1399
  %1401 = and i1 %1369, %1400
  %convergence.parent.token175 = load i32, ptr %current.token, align 4
  %convergence.parent.present176 = icmp ne i32 %convergence.parent.token175, 0
  %1402 = and i1 %1401, %convergence.parent.present176
  br i1 %1402, label %convergence.cascade161, label %convergence.cascade.exit162

convergence.cascade.exit162:                      ; preds = %convergence.cascade161, %schedule.7
  %convergence.cascade.result177 = phi <8 x i1> [ %294, %schedule.7 ], [ %1396, %convergence.cascade161 ]
  %1403 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  br i1 %1403, label %convergence.target.7.ready, label %scheduler.loop

convergence.target.7.ready:                       ; preds = %convergence.cascade.exit162
  %1404 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1405 = bitcast <8 x i1> %convergence.cascade.result177 to i8
  %1406 = call i8 @llvm.cttz.i8(i8 %1405, i1 false)
  %1407 = zext i8 %1406 to i32
  %1408 = select i1 %1404, i32 %1407, i32 0
  %1409 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill59, align 64
  %1410 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1411 = extractvalue { <8 x ptr>, <8 x i64> } %1409, 0
  %1412 = select <8 x i1> %convergence.cascade.result177, <8 x ptr> %1410, <8 x ptr> %1411
  %1413 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1414 = extractvalue { <8 x ptr>, <8 x i64> } %1409, 1
  %1415 = select <8 x i1> %convergence.cascade.result177, <8 x i64> %1413, <8 x i64> %1414
  %1416 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1412, 0
  %1417 = insertvalue { <8 x ptr>, <8 x i64> } %1416, <8 x i64> %1415, 1
  store volatile { <8 x ptr>, <8 x i64> } %1417, ptr %tile_snapshot.spill59, align 64
  %1418 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1419 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1420 = add <8 x i64> %1419, zeroinitializer
  %1421 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1418, 0
  %1422 = insertvalue { <8 x ptr>, <8 x i64> } %1421, <8 x i64> %1420, 1
  %1423 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1424 = extractvalue { <8 x ptr>, <8 x i64> } %1422, 1
  %1425 = extractelement <8 x ptr> %1423, i32 0
  %1426 = extractelement <8 x i64> %1424, i32 %1408
  %1427 = zext i32 %1408 to i64
  %1428 = mul i64 %1427, 8
  %1429 = sub i64 %1426, %1428
  %1430 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1431 = select i1 %1430, i64 %1429, i64 0
  %private.contiguous.address178 = getelementptr i8, ptr %1425, i64 %1431
  %private.contiguous.preserve179 = load <8 x i64>, ptr %private.contiguous.address178, align 8
  %1432 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 -1), <8 x i64> %private.contiguous.preserve179
  store <8 x i64> %1432, ptr %private.contiguous.address178, align 8
  %1433 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1434 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1435 = add <8 x i64> %1434, splat (i64 64)
  %1436 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1433, 0
  %1437 = insertvalue { <8 x ptr>, <8 x i64> } %1436, <8 x i64> %1435, 1
  %1438 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1439 = extractvalue { <8 x ptr>, <8 x i64> } %1437, 1
  %1440 = extractelement <8 x ptr> %1438, i32 0
  %1441 = extractelement <8 x i64> %1439, i32 %1408
  %1442 = zext i32 %1408 to i64
  %1443 = mul i64 %1442, 8
  %1444 = sub i64 %1441, %1443
  %1445 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1446 = select i1 %1445, i64 %1444, i64 0
  %private.contiguous.address180 = getelementptr i8, ptr %1440, i64 %1446
  %private.contiguous.preserve181 = load <8 x i64>, ptr %private.contiguous.address180, align 8
  %1447 = select <8 x i1> %convergence.cascade.result177, <8 x i64> zeroinitializer, <8 x i64> %private.contiguous.preserve181
  store <8 x i64> %1447, ptr %private.contiguous.address180, align 8
  %1448 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1449 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1450 = add <8 x i64> %1449, splat (i64 128)
  %1451 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1448, 0
  %1452 = insertvalue { <8 x ptr>, <8 x i64> } %1451, <8 x i64> %1450, 1
  %1453 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1454 = extractvalue { <8 x ptr>, <8 x i64> } %1452, 1
  %1455 = extractelement <8 x ptr> %1453, i32 0
  %1456 = extractelement <8 x i64> %1454, i32 %1408
  %1457 = zext i32 %1408 to i64
  %1458 = mul i64 %1457, 8
  %1459 = sub i64 %1456, %1458
  %1460 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1461 = select i1 %1460, i64 %1459, i64 0
  %private.contiguous.address182 = getelementptr i8, ptr %1455, i64 %1461
  %private.contiguous.preserve183 = load <8 x i64>, ptr %private.contiguous.address182, align 8
  %1462 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 1), <8 x i64> %private.contiguous.preserve183
  store <8 x i64> %1462, ptr %private.contiguous.address182, align 8
  %1463 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1464 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1465 = add <8 x i64> %1464, splat (i64 192)
  %1466 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1463, 0
  %1467 = insertvalue { <8 x ptr>, <8 x i64> } %1466, <8 x i64> %1465, 1
  %1468 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1469 = extractvalue { <8 x ptr>, <8 x i64> } %1467, 1
  %1470 = extractelement <8 x ptr> %1468, i32 0
  %1471 = extractelement <8 x i64> %1469, i32 %1408
  %1472 = zext i32 %1408 to i64
  %1473 = mul i64 %1472, 8
  %1474 = sub i64 %1471, %1473
  %1475 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1476 = select i1 %1475, i64 %1474, i64 0
  %private.contiguous.address184 = getelementptr i8, ptr %1470, i64 %1476
  %private.contiguous.preserve185 = load <8 x i64>, ptr %private.contiguous.address184, align 8
  %1477 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 2), <8 x i64> %private.contiguous.preserve185
  store <8 x i64> %1477, ptr %private.contiguous.address184, align 8
  %1478 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1479 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1480 = add <8 x i64> %1479, splat (i64 256)
  %1481 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1478, 0
  %1482 = insertvalue { <8 x ptr>, <8 x i64> } %1481, <8 x i64> %1480, 1
  %1483 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1484 = extractvalue { <8 x ptr>, <8 x i64> } %1482, 1
  %1485 = extractelement <8 x ptr> %1483, i32 0
  %1486 = extractelement <8 x i64> %1484, i32 %1408
  %1487 = zext i32 %1408 to i64
  %1488 = mul i64 %1487, 8
  %1489 = sub i64 %1486, %1488
  %1490 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1491 = select i1 %1490, i64 %1489, i64 0
  %private.contiguous.address186 = getelementptr i8, ptr %1485, i64 %1491
  %private.contiguous.preserve187 = load <8 x i64>, ptr %private.contiguous.address186, align 8
  %1492 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 3), <8 x i64> %private.contiguous.preserve187
  store <8 x i64> %1492, ptr %private.contiguous.address186, align 8
  %1493 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1494 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1495 = add <8 x i64> %1494, splat (i64 320)
  %1496 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1493, 0
  %1497 = insertvalue { <8 x ptr>, <8 x i64> } %1496, <8 x i64> %1495, 1
  %1498 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1499 = extractvalue { <8 x ptr>, <8 x i64> } %1497, 1
  %1500 = extractelement <8 x ptr> %1498, i32 0
  %1501 = extractelement <8 x i64> %1499, i32 %1408
  %1502 = zext i32 %1408 to i64
  %1503 = mul i64 %1502, 8
  %1504 = sub i64 %1501, %1503
  %1505 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1506 = select i1 %1505, i64 %1504, i64 0
  %private.contiguous.address188 = getelementptr i8, ptr %1500, i64 %1506
  %private.contiguous.preserve189 = load <8 x i64>, ptr %private.contiguous.address188, align 8
  %1507 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 4), <8 x i64> %private.contiguous.preserve189
  store <8 x i64> %1507, ptr %private.contiguous.address188, align 8
  %1508 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1509 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1510 = add <8 x i64> %1509, splat (i64 384)
  %1511 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1508, 0
  %1512 = insertvalue { <8 x ptr>, <8 x i64> } %1511, <8 x i64> %1510, 1
  %1513 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1514 = extractvalue { <8 x ptr>, <8 x i64> } %1512, 1
  %1515 = extractelement <8 x ptr> %1513, i32 0
  %1516 = extractelement <8 x i64> %1514, i32 %1408
  %1517 = zext i32 %1408 to i64
  %1518 = mul i64 %1517, 8
  %1519 = sub i64 %1516, %1518
  %1520 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1521 = select i1 %1520, i64 %1519, i64 0
  %private.contiguous.address190 = getelementptr i8, ptr %1515, i64 %1521
  %private.contiguous.preserve191 = load <8 x i64>, ptr %private.contiguous.address190, align 8
  %1522 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 5), <8 x i64> %private.contiguous.preserve191
  store <8 x i64> %1522, ptr %private.contiguous.address190, align 8
  %1523 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1524 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1525 = add <8 x i64> %1524, splat (i64 448)
  %1526 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1523, 0
  %1527 = insertvalue { <8 x ptr>, <8 x i64> } %1526, <8 x i64> %1525, 1
  %1528 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1529 = extractvalue { <8 x ptr>, <8 x i64> } %1527, 1
  %1530 = extractelement <8 x ptr> %1528, i32 0
  %1531 = extractelement <8 x i64> %1529, i32 %1408
  %1532 = zext i32 %1408 to i64
  %1533 = mul i64 %1532, 8
  %1534 = sub i64 %1531, %1533
  %1535 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1536 = select i1 %1535, i64 %1534, i64 0
  %private.contiguous.address192 = getelementptr i8, ptr %1530, i64 %1536
  %private.contiguous.preserve193 = load <8 x i64>, ptr %private.contiguous.address192, align 8
  %1537 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 6), <8 x i64> %private.contiguous.preserve193
  store <8 x i64> %1537, ptr %private.contiguous.address192, align 8
  %1538 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1539 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1540 = add <8 x i64> %1539, splat (i64 512)
  %1541 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1538, 0
  %1542 = insertvalue { <8 x ptr>, <8 x i64> } %1541, <8 x i64> %1540, 1
  %1543 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1544 = extractvalue { <8 x ptr>, <8 x i64> } %1542, 1
  %1545 = extractelement <8 x ptr> %1543, i32 0
  %1546 = extractelement <8 x i64> %1544, i32 %1408
  %1547 = zext i32 %1408 to i64
  %1548 = mul i64 %1547, 8
  %1549 = sub i64 %1546, %1548
  %1550 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1551 = select i1 %1550, i64 %1549, i64 0
  %private.contiguous.address194 = getelementptr i8, ptr %1545, i64 %1551
  %private.contiguous.preserve195 = load <8 x i64>, ptr %private.contiguous.address194, align 8
  %1552 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 7), <8 x i64> %private.contiguous.preserve195
  store <8 x i64> %1552, ptr %private.contiguous.address194, align 8
  %1553 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1554 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1555 = add <8 x i64> %1554, splat (i64 576)
  %1556 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1553, 0
  %1557 = insertvalue { <8 x ptr>, <8 x i64> } %1556, <8 x i64> %1555, 1
  %1558 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1559 = extractvalue { <8 x ptr>, <8 x i64> } %1557, 1
  %1560 = extractelement <8 x ptr> %1558, i32 0
  %1561 = extractelement <8 x i64> %1559, i32 %1408
  %1562 = zext i32 %1408 to i64
  %1563 = mul i64 %1562, 8
  %1564 = sub i64 %1561, %1563
  %1565 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1566 = select i1 %1565, i64 %1564, i64 0
  %private.contiguous.address196 = getelementptr i8, ptr %1560, i64 %1566
  %private.contiguous.preserve197 = load <8 x i64>, ptr %private.contiguous.address196, align 8
  %1567 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 8), <8 x i64> %private.contiguous.preserve197
  store <8 x i64> %1567, ptr %private.contiguous.address196, align 8
  %1568 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1569 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1570 = add <8 x i64> %1569, splat (i64 640)
  %1571 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1568, 0
  %1572 = insertvalue { <8 x ptr>, <8 x i64> } %1571, <8 x i64> %1570, 1
  %1573 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1574 = extractvalue { <8 x ptr>, <8 x i64> } %1572, 1
  %1575 = extractelement <8 x ptr> %1573, i32 0
  %1576 = extractelement <8 x i64> %1574, i32 %1408
  %1577 = zext i32 %1408 to i64
  %1578 = mul i64 %1577, 8
  %1579 = sub i64 %1576, %1578
  %1580 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1581 = select i1 %1580, i64 %1579, i64 0
  %private.contiguous.address198 = getelementptr i8, ptr %1575, i64 %1581
  %private.contiguous.preserve199 = load <8 x i64>, ptr %private.contiguous.address198, align 8
  %1582 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 9), <8 x i64> %private.contiguous.preserve199
  store <8 x i64> %1582, ptr %private.contiguous.address198, align 8
  %1583 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1584 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1585 = add <8 x i64> %1584, splat (i64 704)
  %1586 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1583, 0
  %1587 = insertvalue { <8 x ptr>, <8 x i64> } %1586, <8 x i64> %1585, 1
  %1588 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1589 = extractvalue { <8 x ptr>, <8 x i64> } %1587, 1
  %1590 = extractelement <8 x ptr> %1588, i32 0
  %1591 = extractelement <8 x i64> %1589, i32 %1408
  %1592 = zext i32 %1408 to i64
  %1593 = mul i64 %1592, 8
  %1594 = sub i64 %1591, %1593
  %1595 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1596 = select i1 %1595, i64 %1594, i64 0
  %private.contiguous.address200 = getelementptr i8, ptr %1590, i64 %1596
  %private.contiguous.preserve201 = load <8 x i64>, ptr %private.contiguous.address200, align 8
  %1597 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 10), <8 x i64> %private.contiguous.preserve201
  store <8 x i64> %1597, ptr %private.contiguous.address200, align 8
  %1598 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1599 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1600 = add <8 x i64> %1599, splat (i64 768)
  %1601 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1598, 0
  %1602 = insertvalue { <8 x ptr>, <8 x i64> } %1601, <8 x i64> %1600, 1
  %1603 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1604 = extractvalue { <8 x ptr>, <8 x i64> } %1602, 1
  %1605 = extractelement <8 x ptr> %1603, i32 0
  %1606 = extractelement <8 x i64> %1604, i32 %1408
  %1607 = zext i32 %1408 to i64
  %1608 = mul i64 %1607, 8
  %1609 = sub i64 %1606, %1608
  %1610 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1611 = select i1 %1610, i64 %1609, i64 0
  %private.contiguous.address202 = getelementptr i8, ptr %1605, i64 %1611
  %private.contiguous.preserve203 = load <8 x i64>, ptr %private.contiguous.address202, align 8
  %1612 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 11), <8 x i64> %private.contiguous.preserve203
  store <8 x i64> %1612, ptr %private.contiguous.address202, align 8
  %1613 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1614 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1615 = add <8 x i64> %1614, splat (i64 832)
  %1616 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1613, 0
  %1617 = insertvalue { <8 x ptr>, <8 x i64> } %1616, <8 x i64> %1615, 1
  %1618 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1619 = extractvalue { <8 x ptr>, <8 x i64> } %1617, 1
  %1620 = extractelement <8 x ptr> %1618, i32 0
  %1621 = extractelement <8 x i64> %1619, i32 %1408
  %1622 = zext i32 %1408 to i64
  %1623 = mul i64 %1622, 8
  %1624 = sub i64 %1621, %1623
  %1625 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1626 = select i1 %1625, i64 %1624, i64 0
  %private.contiguous.address204 = getelementptr i8, ptr %1620, i64 %1626
  %private.contiguous.preserve205 = load <8 x i64>, ptr %private.contiguous.address204, align 8
  %1627 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 12), <8 x i64> %private.contiguous.preserve205
  store <8 x i64> %1627, ptr %private.contiguous.address204, align 8
  %1628 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1629 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1630 = add <8 x i64> %1629, splat (i64 896)
  %1631 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1628, 0
  %1632 = insertvalue { <8 x ptr>, <8 x i64> } %1631, <8 x i64> %1630, 1
  %1633 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1634 = extractvalue { <8 x ptr>, <8 x i64> } %1632, 1
  %1635 = extractelement <8 x ptr> %1633, i32 0
  %1636 = extractelement <8 x i64> %1634, i32 %1408
  %1637 = zext i32 %1408 to i64
  %1638 = mul i64 %1637, 8
  %1639 = sub i64 %1636, %1638
  %1640 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1641 = select i1 %1640, i64 %1639, i64 0
  %private.contiguous.address206 = getelementptr i8, ptr %1635, i64 %1641
  %private.contiguous.preserve207 = load <8 x i64>, ptr %private.contiguous.address206, align 8
  %1642 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 13), <8 x i64> %private.contiguous.preserve207
  store <8 x i64> %1642, ptr %private.contiguous.address206, align 8
  %1643 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1644 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1645 = add <8 x i64> %1644, splat (i64 960)
  %1646 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1643, 0
  %1647 = insertvalue { <8 x ptr>, <8 x i64> } %1646, <8 x i64> %1645, 1
  %1648 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1649 = extractvalue { <8 x ptr>, <8 x i64> } %1647, 1
  %1650 = extractelement <8 x ptr> %1648, i32 0
  %1651 = extractelement <8 x i64> %1649, i32 %1408
  %1652 = zext i32 %1408 to i64
  %1653 = mul i64 %1652, 8
  %1654 = sub i64 %1651, %1653
  %1655 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1656 = select i1 %1655, i64 %1654, i64 0
  %private.contiguous.address208 = getelementptr i8, ptr %1650, i64 %1656
  %private.contiguous.preserve209 = load <8 x i64>, ptr %private.contiguous.address208, align 8
  %1657 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 14), <8 x i64> %private.contiguous.preserve209
  store <8 x i64> %1657, ptr %private.contiguous.address208, align 8
  %1658 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1659 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1660 = add <8 x i64> %1659, splat (i64 1024)
  %1661 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1658, 0
  %1662 = insertvalue { <8 x ptr>, <8 x i64> } %1661, <8 x i64> %1660, 1
  %1663 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1664 = extractvalue { <8 x ptr>, <8 x i64> } %1662, 1
  %1665 = extractelement <8 x ptr> %1663, i32 0
  %1666 = extractelement <8 x i64> %1664, i32 %1408
  %1667 = zext i32 %1408 to i64
  %1668 = mul i64 %1667, 8
  %1669 = sub i64 %1666, %1668
  %1670 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1671 = select i1 %1670, i64 %1669, i64 0
  %private.contiguous.address210 = getelementptr i8, ptr %1665, i64 %1671
  %private.contiguous.preserve211 = load <8 x i64>, ptr %private.contiguous.address210, align 8
  %1672 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 15), <8 x i64> %private.contiguous.preserve211
  store <8 x i64> %1672, ptr %private.contiguous.address210, align 8
  %1673 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1674 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1675 = add <8 x i64> %1674, splat (i64 1088)
  %1676 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1673, 0
  %1677 = insertvalue { <8 x ptr>, <8 x i64> } %1676, <8 x i64> %1675, 1
  %1678 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1679 = extractvalue { <8 x ptr>, <8 x i64> } %1677, 1
  %1680 = extractelement <8 x ptr> %1678, i32 0
  %1681 = extractelement <8 x i64> %1679, i32 %1408
  %1682 = zext i32 %1408 to i64
  %1683 = mul i64 %1682, 8
  %1684 = sub i64 %1681, %1683
  %1685 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1686 = select i1 %1685, i64 %1684, i64 0
  %private.contiguous.address212 = getelementptr i8, ptr %1680, i64 %1686
  %private.contiguous.preserve213 = load <8 x i64>, ptr %private.contiguous.address212, align 8
  %1687 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 16), <8 x i64> %private.contiguous.preserve213
  store <8 x i64> %1687, ptr %private.contiguous.address212, align 8
  %1688 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1689 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1690 = add <8 x i64> %1689, splat (i64 1152)
  %1691 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1688, 0
  %1692 = insertvalue { <8 x ptr>, <8 x i64> } %1691, <8 x i64> %1690, 1
  %1693 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1694 = extractvalue { <8 x ptr>, <8 x i64> } %1692, 1
  %1695 = extractelement <8 x ptr> %1693, i32 0
  %1696 = extractelement <8 x i64> %1694, i32 %1408
  %1697 = zext i32 %1408 to i64
  %1698 = mul i64 %1697, 8
  %1699 = sub i64 %1696, %1698
  %1700 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1701 = select i1 %1700, i64 %1699, i64 0
  %private.contiguous.address214 = getelementptr i8, ptr %1695, i64 %1701
  %private.contiguous.preserve215 = load <8 x i64>, ptr %private.contiguous.address214, align 8
  %1702 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 17), <8 x i64> %private.contiguous.preserve215
  store <8 x i64> %1702, ptr %private.contiguous.address214, align 8
  %1703 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1704 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1705 = add <8 x i64> %1704, splat (i64 1216)
  %1706 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1703, 0
  %1707 = insertvalue { <8 x ptr>, <8 x i64> } %1706, <8 x i64> %1705, 1
  %1708 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1709 = extractvalue { <8 x ptr>, <8 x i64> } %1707, 1
  %1710 = extractelement <8 x ptr> %1708, i32 0
  %1711 = extractelement <8 x i64> %1709, i32 %1408
  %1712 = zext i32 %1408 to i64
  %1713 = mul i64 %1712, 8
  %1714 = sub i64 %1711, %1713
  %1715 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1716 = select i1 %1715, i64 %1714, i64 0
  %private.contiguous.address216 = getelementptr i8, ptr %1710, i64 %1716
  %private.contiguous.preserve217 = load <8 x i64>, ptr %private.contiguous.address216, align 8
  %1717 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 18), <8 x i64> %private.contiguous.preserve217
  store <8 x i64> %1717, ptr %private.contiguous.address216, align 8
  %1718 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1719 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1720 = add <8 x i64> %1719, splat (i64 1280)
  %1721 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1718, 0
  %1722 = insertvalue { <8 x ptr>, <8 x i64> } %1721, <8 x i64> %1720, 1
  %1723 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1724 = extractvalue { <8 x ptr>, <8 x i64> } %1722, 1
  %1725 = extractelement <8 x ptr> %1723, i32 0
  %1726 = extractelement <8 x i64> %1724, i32 %1408
  %1727 = zext i32 %1408 to i64
  %1728 = mul i64 %1727, 8
  %1729 = sub i64 %1726, %1728
  %1730 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1731 = select i1 %1730, i64 %1729, i64 0
  %private.contiguous.address218 = getelementptr i8, ptr %1725, i64 %1731
  %private.contiguous.preserve219 = load <8 x i64>, ptr %private.contiguous.address218, align 8
  %1732 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 19), <8 x i64> %private.contiguous.preserve219
  store <8 x i64> %1732, ptr %private.contiguous.address218, align 8
  %1733 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1734 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1735 = add <8 x i64> %1734, splat (i64 1344)
  %1736 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1733, 0
  %1737 = insertvalue { <8 x ptr>, <8 x i64> } %1736, <8 x i64> %1735, 1
  %1738 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1739 = extractvalue { <8 x ptr>, <8 x i64> } %1737, 1
  %1740 = extractelement <8 x ptr> %1738, i32 0
  %1741 = extractelement <8 x i64> %1739, i32 %1408
  %1742 = zext i32 %1408 to i64
  %1743 = mul i64 %1742, 8
  %1744 = sub i64 %1741, %1743
  %1745 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1746 = select i1 %1745, i64 %1744, i64 0
  %private.contiguous.address220 = getelementptr i8, ptr %1740, i64 %1746
  %private.contiguous.preserve221 = load <8 x i64>, ptr %private.contiguous.address220, align 8
  %1747 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 20), <8 x i64> %private.contiguous.preserve221
  store <8 x i64> %1747, ptr %private.contiguous.address220, align 8
  %1748 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1749 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1750 = add <8 x i64> %1749, splat (i64 1408)
  %1751 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1748, 0
  %1752 = insertvalue { <8 x ptr>, <8 x i64> } %1751, <8 x i64> %1750, 1
  %1753 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1754 = extractvalue { <8 x ptr>, <8 x i64> } %1752, 1
  %1755 = extractelement <8 x ptr> %1753, i32 0
  %1756 = extractelement <8 x i64> %1754, i32 %1408
  %1757 = zext i32 %1408 to i64
  %1758 = mul i64 %1757, 8
  %1759 = sub i64 %1756, %1758
  %1760 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1761 = select i1 %1760, i64 %1759, i64 0
  %private.contiguous.address222 = getelementptr i8, ptr %1755, i64 %1761
  %private.contiguous.preserve223 = load <8 x i64>, ptr %private.contiguous.address222, align 8
  %1762 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 21), <8 x i64> %private.contiguous.preserve223
  store <8 x i64> %1762, ptr %private.contiguous.address222, align 8
  %1763 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1764 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1765 = add <8 x i64> %1764, splat (i64 1472)
  %1766 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1763, 0
  %1767 = insertvalue { <8 x ptr>, <8 x i64> } %1766, <8 x i64> %1765, 1
  %1768 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1769 = extractvalue { <8 x ptr>, <8 x i64> } %1767, 1
  %1770 = extractelement <8 x ptr> %1768, i32 0
  %1771 = extractelement <8 x i64> %1769, i32 %1408
  %1772 = zext i32 %1408 to i64
  %1773 = mul i64 %1772, 8
  %1774 = sub i64 %1771, %1773
  %1775 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1776 = select i1 %1775, i64 %1774, i64 0
  %private.contiguous.address224 = getelementptr i8, ptr %1770, i64 %1776
  %private.contiguous.preserve225 = load <8 x i64>, ptr %private.contiguous.address224, align 8
  %1777 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 22), <8 x i64> %private.contiguous.preserve225
  store <8 x i64> %1777, ptr %private.contiguous.address224, align 8
  %1778 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1779 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1780 = add <8 x i64> %1779, splat (i64 1536)
  %1781 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1778, 0
  %1782 = insertvalue { <8 x ptr>, <8 x i64> } %1781, <8 x i64> %1780, 1
  %1783 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1784 = extractvalue { <8 x ptr>, <8 x i64> } %1782, 1
  %1785 = extractelement <8 x ptr> %1783, i32 0
  %1786 = extractelement <8 x i64> %1784, i32 %1408
  %1787 = zext i32 %1408 to i64
  %1788 = mul i64 %1787, 8
  %1789 = sub i64 %1786, %1788
  %1790 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1791 = select i1 %1790, i64 %1789, i64 0
  %private.contiguous.address226 = getelementptr i8, ptr %1785, i64 %1791
  %private.contiguous.preserve227 = load <8 x i64>, ptr %private.contiguous.address226, align 8
  %1792 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 23), <8 x i64> %private.contiguous.preserve227
  store <8 x i64> %1792, ptr %private.contiguous.address226, align 8
  %1793 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1794 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1795 = add <8 x i64> %1794, splat (i64 1600)
  %1796 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1793, 0
  %1797 = insertvalue { <8 x ptr>, <8 x i64> } %1796, <8 x i64> %1795, 1
  %1798 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1799 = extractvalue { <8 x ptr>, <8 x i64> } %1797, 1
  %1800 = extractelement <8 x ptr> %1798, i32 0
  %1801 = extractelement <8 x i64> %1799, i32 %1408
  %1802 = zext i32 %1408 to i64
  %1803 = mul i64 %1802, 8
  %1804 = sub i64 %1801, %1803
  %1805 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1806 = select i1 %1805, i64 %1804, i64 0
  %private.contiguous.address228 = getelementptr i8, ptr %1800, i64 %1806
  %private.contiguous.preserve229 = load <8 x i64>, ptr %private.contiguous.address228, align 8
  %1807 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 24), <8 x i64> %private.contiguous.preserve229
  store <8 x i64> %1807, ptr %private.contiguous.address228, align 8
  %1808 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1809 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1810 = add <8 x i64> %1809, splat (i64 1664)
  %1811 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1808, 0
  %1812 = insertvalue { <8 x ptr>, <8 x i64> } %1811, <8 x i64> %1810, 1
  %1813 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1814 = extractvalue { <8 x ptr>, <8 x i64> } %1812, 1
  %1815 = extractelement <8 x ptr> %1813, i32 0
  %1816 = extractelement <8 x i64> %1814, i32 %1408
  %1817 = zext i32 %1408 to i64
  %1818 = mul i64 %1817, 8
  %1819 = sub i64 %1816, %1818
  %1820 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1821 = select i1 %1820, i64 %1819, i64 0
  %private.contiguous.address230 = getelementptr i8, ptr %1815, i64 %1821
  %private.contiguous.preserve231 = load <8 x i64>, ptr %private.contiguous.address230, align 8
  %1822 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 25), <8 x i64> %private.contiguous.preserve231
  store <8 x i64> %1822, ptr %private.contiguous.address230, align 8
  %1823 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1824 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1825 = add <8 x i64> %1824, splat (i64 1728)
  %1826 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1823, 0
  %1827 = insertvalue { <8 x ptr>, <8 x i64> } %1826, <8 x i64> %1825, 1
  %1828 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1829 = extractvalue { <8 x ptr>, <8 x i64> } %1827, 1
  %1830 = extractelement <8 x ptr> %1828, i32 0
  %1831 = extractelement <8 x i64> %1829, i32 %1408
  %1832 = zext i32 %1408 to i64
  %1833 = mul i64 %1832, 8
  %1834 = sub i64 %1831, %1833
  %1835 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1836 = select i1 %1835, i64 %1834, i64 0
  %private.contiguous.address232 = getelementptr i8, ptr %1830, i64 %1836
  %private.contiguous.preserve233 = load <8 x i64>, ptr %private.contiguous.address232, align 8
  %1837 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 26), <8 x i64> %private.contiguous.preserve233
  store <8 x i64> %1837, ptr %private.contiguous.address232, align 8
  %1838 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1839 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1840 = add <8 x i64> %1839, splat (i64 1792)
  %1841 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1838, 0
  %1842 = insertvalue { <8 x ptr>, <8 x i64> } %1841, <8 x i64> %1840, 1
  %1843 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1844 = extractvalue { <8 x ptr>, <8 x i64> } %1842, 1
  %1845 = extractelement <8 x ptr> %1843, i32 0
  %1846 = extractelement <8 x i64> %1844, i32 %1408
  %1847 = zext i32 %1408 to i64
  %1848 = mul i64 %1847, 8
  %1849 = sub i64 %1846, %1848
  %1850 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1851 = select i1 %1850, i64 %1849, i64 0
  %private.contiguous.address234 = getelementptr i8, ptr %1845, i64 %1851
  %private.contiguous.preserve235 = load <8 x i64>, ptr %private.contiguous.address234, align 8
  %1852 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 27), <8 x i64> %private.contiguous.preserve235
  store <8 x i64> %1852, ptr %private.contiguous.address234, align 8
  %1853 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1854 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1855 = add <8 x i64> %1854, splat (i64 1856)
  %1856 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1853, 0
  %1857 = insertvalue { <8 x ptr>, <8 x i64> } %1856, <8 x i64> %1855, 1
  %1858 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1859 = extractvalue { <8 x ptr>, <8 x i64> } %1857, 1
  %1860 = extractelement <8 x ptr> %1858, i32 0
  %1861 = extractelement <8 x i64> %1859, i32 %1408
  %1862 = zext i32 %1408 to i64
  %1863 = mul i64 %1862, 8
  %1864 = sub i64 %1861, %1863
  %1865 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1866 = select i1 %1865, i64 %1864, i64 0
  %private.contiguous.address236 = getelementptr i8, ptr %1860, i64 %1866
  %private.contiguous.preserve237 = load <8 x i64>, ptr %private.contiguous.address236, align 8
  %1867 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 28), <8 x i64> %private.contiguous.preserve237
  store <8 x i64> %1867, ptr %private.contiguous.address236, align 8
  %1868 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1869 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1870 = add <8 x i64> %1869, splat (i64 1920)
  %1871 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1868, 0
  %1872 = insertvalue { <8 x ptr>, <8 x i64> } %1871, <8 x i64> %1870, 1
  %1873 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1874 = extractvalue { <8 x ptr>, <8 x i64> } %1872, 1
  %1875 = extractelement <8 x ptr> %1873, i32 0
  %1876 = extractelement <8 x i64> %1874, i32 %1408
  %1877 = zext i32 %1408 to i64
  %1878 = mul i64 %1877, 8
  %1879 = sub i64 %1876, %1878
  %1880 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1881 = select i1 %1880, i64 %1879, i64 0
  %private.contiguous.address238 = getelementptr i8, ptr %1875, i64 %1881
  %private.contiguous.preserve239 = load <8 x i64>, ptr %private.contiguous.address238, align 8
  %1882 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 29), <8 x i64> %private.contiguous.preserve239
  store <8 x i64> %1882, ptr %private.contiguous.address238, align 8
  %1883 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1884 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1885 = add <8 x i64> %1884, splat (i64 1984)
  %1886 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1883, 0
  %1887 = insertvalue { <8 x ptr>, <8 x i64> } %1886, <8 x i64> %1885, 1
  %1888 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1889 = extractvalue { <8 x ptr>, <8 x i64> } %1887, 1
  %1890 = extractelement <8 x ptr> %1888, i32 0
  %1891 = extractelement <8 x i64> %1889, i32 %1408
  %1892 = zext i32 %1408 to i64
  %1893 = mul i64 %1892, 8
  %1894 = sub i64 %1891, %1893
  %1895 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1896 = select i1 %1895, i64 %1894, i64 0
  %private.contiguous.address240 = getelementptr i8, ptr %1890, i64 %1896
  %private.contiguous.preserve241 = load <8 x i64>, ptr %private.contiguous.address240, align 8
  %1897 = select <8 x i1> %convergence.cascade.result177, <8 x i64> splat (i64 30), <8 x i64> %private.contiguous.preserve241
  store <8 x i64> %1897, ptr %private.contiguous.address240, align 8
  %1898 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill60, align 64
  %1899 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1900 = extractvalue { <8 x ptr>, <8 x i64> } %1898, 0
  %1901 = select <8 x i1> %convergence.cascade.result177, <8 x ptr> %1899, <8 x ptr> %1900
  %1902 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %1903 = extractvalue { <8 x ptr>, <8 x i64> } %1898, 1
  %1904 = select <8 x i1> %convergence.cascade.result177, <8 x i64> %1902, <8 x i64> %1903
  %1905 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1901, 0
  %1906 = insertvalue { <8 x ptr>, <8 x i64> } %1905, <8 x i64> %1904, 1
  store volatile { <8 x ptr>, <8 x i64> } %1906, ptr %tile_snapshot.spill60, align 64
  %1907 = load <8 x i64>, ptr %.slot61, align 64
  %1908 = select <8 x i1> %convergence.cascade.result177, <8 x i64> zeroinitializer, <8 x i64> %1907
  store <8 x i64> %1908, ptr %.slot61, align 64
  store <8 x i1> %convergence.cascade.result177, ptr %current.mask, align 1
  %1909 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  br i1 %1909, label %schedule.8, label %scheduler.loop

varying.divergent243:                             ; preds = %schedule.8
  %1910 = load i32, ptr %current.token, align 4
  %1911 = icmp ne i32 %1910, 0
  %1912 = sub i32 %1910, 1
  %1913 = select i1 %1911, i32 %1912, i32 0
  %1914 = load i8, ptr %frame.active, align 1
  %1915 = trunc i32 %1913 to i8
  %1916 = shl i8 1, %1915
  %1917 = and i8 %1914, %1916
  %1918 = icmp ne i8 %1917, 0
  %1919 = load <8 x i32>, ptr %frame.static.id, align 32
  %1920 = extractelement <8 x i32> %1919, i32 %1913
  %1921 = icmp eq i32 %1920, 3
  %1922 = and i1 %1918, %1921
  %1923 = and i1 %1911, %1922
  %1924 = xor i1 %1923, true
  %1925 = and i1 true, %1924
  %1926 = xor i8 %1914, -1
  %1927 = icmp ne i8 %1926, 0
  %1928 = xor i1 %1927, true
  %1929 = and i1 %1925, %1928
  br i1 %1929, label %convergence.overflow.trap245, label %convergence.overflow.resume246

varying.coherent244:                              ; preds = %schedule.8
  br i1 %305, label %varying.coherent.true249, label %varying.coherent.false250

convergence.overflow.trap245:                     ; preds = %varying.divergent243
  call void @llvm.trap()
  unreachable

convergence.overflow.resume246:                   ; preds = %varying.divergent243
  %1930 = call i8 @llvm.cttz.i8(i8 %1926, i1 false)
  %1931 = zext i8 %1930 to i32
  %1932 = select i1 %1927, i32 %1931, i32 0
  %1933 = trunc i32 %1932 to i8
  %1934 = shl i8 1, %1933
  %1935 = or i8 %1914, %1934
  %1936 = select i1 %1925, i8 %1935, i8 %1914
  store i8 %1936, ptr %frame.active, align 1
  %1937 = load <8 x i32>, ptr %frame.static.id, align 32
  %1938 = extractelement <8 x i32> %1937, i32 %1932
  %1939 = select i1 %1925, i32 3, i32 %1938
  %1940 = load <8 x i32>, ptr %frame.static.id, align 32
  %1941 = insertelement <8 x i32> %1940, i32 %1939, i32 %1932
  store <8 x i32> %1941, ptr %frame.static.id, align 32
  %1942 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1943 = extractelement <8 x i32> %1942, i32 %1932
  %1944 = select i1 %1925, i32 %1910, i32 %1943
  %1945 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1946 = insertelement <8 x i32> %1945, i32 %1944, i32 %1932
  store <8 x i32> %1946, ptr %frame.parent.token, align 32
  %1947 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1932
  %1948 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1932
  %1949 = load <8 x i1>, ptr %1947, align 1
  %1950 = load <8 x i1>, ptr %1948, align 1
  %1951 = select i1 %1925, <8 x i1> %295, <8 x i1> %1949
  store <8 x i1> %1951, ptr %1947, align 1
  %1952 = select i1 %1925, <8 x i1> zeroinitializer, <8 x i1> %1950
  store <8 x i1> %1952, ptr %1948, align 1
  %1953 = add i32 %1932, 1
  %1954 = select i1 %1923, i32 %1910, i32 %1953
  %1955 = select i1 true, i32 %1954, i32 %1910
  store i32 %1955, ptr %current.token, align 4
  %1956 = load i32, ptr %current.token, align 4
  %1957 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %302)
  %1958 = load i32, ptr %ready.count, align 4
  %1959 = icmp uge i32 %1958, 8
  %1960 = and i1 %1957, %1959
  br i1 %1960, label %ready.overflow.trap247, label %ready.overflow.resume248

ready.overflow.trap247:                           ; preds = %convergence.overflow.resume246
  call void @llvm.trap()
  unreachable

ready.overflow.resume248:                         ; preds = %convergence.overflow.resume246
  %1961 = select i1 %1957, i32 %1958, i32 0
  %1962 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1961
  %1963 = load <8 x i1>, ptr %1962, align 1
  %1964 = select i1 %1957, <8 x i1> %302, <8 x i1> %1963
  store <8 x i1> %1964, ptr %1962, align 1
  %1965 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1961
  %1966 = load i32, ptr %1965, align 4
  %1967 = select i1 %1957, i32 9, i32 %1966
  store i32 %1967, ptr %1965, align 4
  %1968 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1961
  %1969 = load i32, ptr %1968, align 4
  %1970 = select i1 %1957, i32 %1956, i32 %1969
  store i32 %1970, ptr %1968, align 4
  %1971 = add i32 %1958, 1
  %1972 = select i1 %1957, i32 %1971, i32 %1958
  store i32 %1972, ptr %ready.count, align 4
  %1973 = load <8 x i1>, ptr %runnable.mask, align 1
  %1974 = or <8 x i1> %1973, %302
  store <8 x i1> %1974, ptr %runnable.mask, align 1
  store <8 x i1> %304, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true249:                         ; preds = %varying.coherent244
  store <8 x i1> %295, ptr %current.mask, align 1
  %1975 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %295)
  br i1 %1975, label %schedule.9, label %scheduler.loop

varying.coherent.false250:                        ; preds = %varying.coherent244
  store <8 x i1> %295, ptr %current.mask, align 1
  %1976 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %295)
  br i1 %1976, label %schedule.12, label %scheduler.loop

varying.divergent254:                             ; preds = %schedule.9
  %1977 = load i32, ptr %current.token, align 4
  %1978 = icmp ne i32 %1977, 0
  %1979 = sub i32 %1977, 1
  %1980 = select i1 %1978, i32 %1979, i32 0
  %1981 = load i8, ptr %frame.active, align 1
  %1982 = trunc i32 %1980 to i8
  %1983 = shl i8 1, %1982
  %1984 = and i8 %1981, %1983
  %1985 = icmp ne i8 %1984, 0
  %1986 = load <8 x i32>, ptr %frame.static.id, align 32
  %1987 = extractelement <8 x i32> %1986, i32 %1980
  %1988 = icmp eq i32 %1987, 4
  %1989 = and i1 %1985, %1988
  %1990 = and i1 %1978, %1989
  %1991 = xor i1 %1990, true
  %1992 = and i1 true, %1991
  %1993 = xor i8 %1981, -1
  %1994 = icmp ne i8 %1993, 0
  %1995 = xor i1 %1994, true
  %1996 = and i1 %1992, %1995
  br i1 %1996, label %convergence.overflow.trap256, label %convergence.overflow.resume257

varying.coherent255:                              ; preds = %schedule.9
  br i1 %347, label %varying.coherent.true260, label %varying.coherent.false261

convergence.overflow.trap256:                     ; preds = %varying.divergent254
  call void @llvm.trap()
  unreachable

convergence.overflow.resume257:                   ; preds = %varying.divergent254
  %1997 = call i8 @llvm.cttz.i8(i8 %1993, i1 false)
  %1998 = zext i8 %1997 to i32
  %1999 = select i1 %1994, i32 %1998, i32 0
  %2000 = trunc i32 %1999 to i8
  %2001 = shl i8 1, %2000
  %2002 = or i8 %1981, %2001
  %2003 = select i1 %1992, i8 %2002, i8 %1981
  store i8 %2003, ptr %frame.active, align 1
  %2004 = load <8 x i32>, ptr %frame.static.id, align 32
  %2005 = extractelement <8 x i32> %2004, i32 %1999
  %2006 = select i1 %1992, i32 4, i32 %2005
  %2007 = load <8 x i32>, ptr %frame.static.id, align 32
  %2008 = insertelement <8 x i32> %2007, i32 %2006, i32 %1999
  store <8 x i32> %2008, ptr %frame.static.id, align 32
  %2009 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2010 = extractelement <8 x i32> %2009, i32 %1999
  %2011 = select i1 %1992, i32 %1977, i32 %2010
  %2012 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2013 = insertelement <8 x i32> %2012, i32 %2011, i32 %1999
  store <8 x i32> %2013, ptr %frame.parent.token, align 32
  %2014 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1999
  %2015 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1999
  %2016 = load <8 x i1>, ptr %2014, align 1
  %2017 = load <8 x i1>, ptr %2015, align 1
  %2018 = select i1 %1992, <8 x i1> %308, <8 x i1> %2016
  store <8 x i1> %2018, ptr %2014, align 1
  %2019 = select i1 %1992, <8 x i1> zeroinitializer, <8 x i1> %2017
  store <8 x i1> %2019, ptr %2015, align 1
  %2020 = add i32 %1999, 1
  %2021 = select i1 %1990, i32 %1977, i32 %2020
  %2022 = select i1 true, i32 %2021, i32 %1977
  store i32 %2022, ptr %current.token, align 4
  %2023 = load <8 x float>, ptr %.slot64, align 32
  %2024 = select <8 x i1> %346, <8 x float> zeroinitializer, <8 x float> %2023
  store <8 x float> %2024, ptr %.slot64, align 32
  %2025 = load i32, ptr %current.token, align 4
  %2026 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %344)
  %2027 = load i32, ptr %ready.count, align 4
  %2028 = icmp uge i32 %2027, 8
  %2029 = and i1 %2026, %2028
  br i1 %2029, label %ready.overflow.trap258, label %ready.overflow.resume259

ready.overflow.trap258:                           ; preds = %convergence.overflow.resume257
  call void @llvm.trap()
  unreachable

ready.overflow.resume259:                         ; preds = %convergence.overflow.resume257
  %2030 = select i1 %2026, i32 %2027, i32 0
  %2031 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2030
  %2032 = load <8 x i1>, ptr %2031, align 1
  %2033 = select i1 %2026, <8 x i1> %344, <8 x i1> %2032
  store <8 x i1> %2033, ptr %2031, align 1
  %2034 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2030
  %2035 = load i32, ptr %2034, align 4
  %2036 = select i1 %2026, i32 10, i32 %2035
  store i32 %2036, ptr %2034, align 4
  %2037 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2030
  %2038 = load i32, ptr %2037, align 4
  %2039 = select i1 %2026, i32 %2025, i32 %2038
  store i32 %2039, ptr %2037, align 4
  %2040 = add i32 %2027, 1
  %2041 = select i1 %2026, i32 %2040, i32 %2027
  store i32 %2041, ptr %ready.count, align 4
  %2042 = load <8 x i1>, ptr %runnable.mask, align 1
  %2043 = or <8 x i1> %2042, %344
  store <8 x i1> %2043, ptr %runnable.mask, align 1
  store <8 x i1> %346, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true260:                         ; preds = %varying.coherent255
  store <8 x i1> %308, ptr %current.mask, align 1
  %2044 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %308)
  br i1 %2044, label %schedule.10, label %scheduler.loop

varying.coherent.false261:                        ; preds = %varying.coherent255
  %2045 = load <8 x float>, ptr %.slot64, align 32
  %2046 = select <8 x i1> %308, <8 x float> zeroinitializer, <8 x float> %2045
  store <8 x float> %2046, ptr %.slot64, align 32
  store <8 x i1> %308, ptr %current.mask, align 1
  %2047 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %308)
  br i1 %2047, label %schedule.11, label %scheduler.loop

convergence.cascade264:                           ; preds = %convergence.cascade264, %schedule.11
  %convergence.cascade.flow268 = phi <8 x i1> [ %369, %schedule.11 ], [ %2090, %convergence.cascade264 ]
  %convergence.cascade.depth269 = phi i32 [ 0, %schedule.11 ], [ %2091, %convergence.cascade264 ]
  %2048 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow268)
  %2049 = load i32, ptr %current.token, align 4
  %2050 = icmp ne i32 %2049, 0
  %2051 = and i1 %2048, %2050
  %2052 = sub i32 %2049, 1
  %2053 = select i1 %2051, i32 %2052, i32 0
  %2054 = load i8, ptr %frame.active, align 1
  %2055 = trunc i32 %2053 to i8
  %2056 = shl i8 1, %2055
  %2057 = and i8 %2054, %2056
  %2058 = icmp ne i8 %2057, 0
  %2059 = load <8 x i32>, ptr %frame.static.id, align 32
  %2060 = extractelement <8 x i32> %2059, i32 %2053
  %convergence.target.pointer270 = getelementptr inbounds [20 x i32], ptr @convergence.targets, i32 0, i32 %2060
  %convergence.dynamic.target271 = load i32, ptr %convergence.target.pointer270, align 4
  %2061 = icmp eq i32 %convergence.dynamic.target271, 11
  %2062 = and i1 %2058, %2061
  %2063 = and i1 %2051, %2062
  %2064 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2053
  %2065 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2053
  %2066 = load <8 x i1>, ptr %2064, align 1
  %2067 = load <8 x i1>, ptr %2065, align 1
  %2068 = or <8 x i1> %2067, %convergence.cascade.flow268
  %2069 = load <8 x i1>, ptr %live.mask, align 1
  %2070 = and <8 x i1> %2066, %2069
  %2071 = icmp eq <8 x i1> %2068, %2070
  %2072 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2071)
  %2073 = and i1 %2063, %2072
  %2074 = select i1 %2073, <8 x i1> zeroinitializer, <8 x i1> %2068
  %2075 = select i1 %2063, <8 x i1> %2074, <8 x i1> %2067
  store <8 x i1> %2075, ptr %2065, align 1
  %2076 = select i1 %2073, <8 x i1> zeroinitializer, <8 x i1> %2066
  store <8 x i1> %2076, ptr %2064, align 1
  %2077 = trunc i32 %2053 to i8
  %2078 = shl i8 1, %2077
  %2079 = xor i8 %2078, -1
  %2080 = and i8 %2054, %2079
  %2081 = select i1 %2073, i8 %2080, i8 %2054
  store i8 %2081, ptr %frame.active, align 1
  %.splatinsert272 = insertelement <8 x i1> poison, i1 %2063, i64 0
  %.splat273 = shufflevector <8 x i1> %.splatinsert272, <8 x i1> poison, <8 x i32> zeroinitializer
  %2082 = and <8 x i1> %convergence.cascade.flow268, %.splat273
  %2083 = load <8 x i1>, ptr %runnable.mask, align 1
  %2084 = xor <8 x i1> %2082, splat (i1 true)
  %2085 = and <8 x i1> %2083, %2084
  store <8 x i1> %2085, ptr %runnable.mask, align 1
  %.splatinsert274 = insertelement <8 x i1> poison, i1 %2073, i64 0
  %.splat275 = shufflevector <8 x i1> %.splatinsert274, <8 x i1> poison, <8 x i32> zeroinitializer
  %2086 = select <8 x i1> %.splat275, <8 x i1> %2068, <8 x i1> zeroinitializer
  %2087 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2088 = extractelement <8 x i32> %2087, i32 %2053
  %2089 = select i1 %2073, i32 %2088, i32 %2049
  store i32 %2089, ptr %current.token, align 4
  %.splatinsert276 = insertelement <8 x i1> poison, i1 %2063, i64 0
  %.splat277 = shufflevector <8 x i1> %.splatinsert276, <8 x i1> poison, <8 x i32> zeroinitializer
  %2090 = select <8 x i1> %.splat277, <8 x i1> %2086, <8 x i1> %convergence.cascade.flow268
  %2091 = add i32 %convergence.cascade.depth269, 1
  %2092 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2090)
  %2093 = icmp ult i32 %2091, 8
  %2094 = and i1 %2092, %2093
  %2095 = and i1 %2063, %2094
  %convergence.parent.token278 = load i32, ptr %current.token, align 4
  %convergence.parent.present279 = icmp ne i32 %convergence.parent.token278, 0
  %2096 = and i1 %2095, %convergence.parent.present279
  br i1 %2096, label %convergence.cascade264, label %convergence.cascade.exit265

convergence.cascade.exit265:                      ; preds = %convergence.cascade264, %schedule.11
  %convergence.cascade.result280 = phi <8 x i1> [ %369, %schedule.11 ], [ %2090, %convergence.cascade264 ]
  %2097 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result280)
  br i1 %2097, label %convergence.target.11.ready, label %scheduler.loop

convergence.target.11.ready:                      ; preds = %convergence.cascade.exit265
  %2098 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result280)
  %2099 = bitcast <8 x i1> %convergence.cascade.result280 to i8
  %2100 = call i8 @llvm.cttz.i8(i8 %2099, i1 false)
  %2101 = zext i8 %2100 to i32
  %2102 = select i1 %2098, i32 %2101, i32 0
  %.spill.load281 = load float, ptr %.spill49, align 4
  %.splatinsert282 = insertelement <8 x float> poison, float %.spill.load281, i64 0
  %.splat283 = shufflevector <8 x float> %.splatinsert282, <8 x float> poison, <8 x i32> zeroinitializer
  %.state284 = load <8 x float>, ptr %.slot64, align 32
  %.spill.load285 = load volatile <8 x i1>, ptr %.spill62, align 1
  %2103 = select <8 x i1> %.spill.load285, <8 x float> %.state284, <8 x float> %.splat283
  %tile_snapshot.spill.load286 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill60, align 64
  %2104 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load286, 0
  %2105 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load286, 1
  %.state287 = load <8 x i64>, ptr %.slot61, align 64
  %2106 = mul <8 x i64> %.state287, splat (i64 32)
  %2107 = add <8 x i64> %2105, %2106
  %2108 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2104, 0
  %2109 = insertvalue { <8 x ptr>, <8 x i64> } %2108, <8 x i64> %2107, 1
  %2110 = extractvalue { <8 x ptr>, <8 x i64> } %2109, 0
  %2111 = extractvalue { <8 x ptr>, <8 x i64> } %2109, 1
  %2112 = getelementptr i8, <8 x ptr> %2110, <8 x i64> %2111
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %2103, <8 x ptr> %2112, i32 1, <8 x i1> %convergence.cascade.result280)
  %.state288 = load <8 x i64>, ptr %.slot61, align 64
  %2113 = add <8 x i64> %.state288, splat (i64 1)
  %2114 = load <8 x i64>, ptr %.slot61, align 64
  %2115 = select <8 x i1> %convergence.cascade.result280, <8 x i64> %2113, <8 x i64> %2114
  store <8 x i64> %2115, ptr %.slot61, align 64
  store <8 x i1> %convergence.cascade.result280, ptr %current.mask, align 1
  %2116 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result280)
  br i1 %2116, label %schedule.8, label %scheduler.loop

convergence.cascade289:                           ; preds = %convergence.cascade289, %schedule.12
  %convergence.cascade.flow293 = phi <8 x i1> [ %370, %schedule.12 ], [ %2159, %convergence.cascade289 ]
  %convergence.cascade.depth294 = phi i32 [ 0, %schedule.12 ], [ %2160, %convergence.cascade289 ]
  %2117 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow293)
  %2118 = load i32, ptr %current.token, align 4
  %2119 = icmp ne i32 %2118, 0
  %2120 = and i1 %2117, %2119
  %2121 = sub i32 %2118, 1
  %2122 = select i1 %2120, i32 %2121, i32 0
  %2123 = load i8, ptr %frame.active, align 1
  %2124 = trunc i32 %2122 to i8
  %2125 = shl i8 1, %2124
  %2126 = and i8 %2123, %2125
  %2127 = icmp ne i8 %2126, 0
  %2128 = load <8 x i32>, ptr %frame.static.id, align 32
  %2129 = extractelement <8 x i32> %2128, i32 %2122
  %convergence.target.pointer295 = getelementptr inbounds [20 x i32], ptr @convergence.targets, i32 0, i32 %2129
  %convergence.dynamic.target296 = load i32, ptr %convergence.target.pointer295, align 4
  %2130 = icmp eq i32 %convergence.dynamic.target296, 12
  %2131 = and i1 %2127, %2130
  %2132 = and i1 %2120, %2131
  %2133 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2122
  %2134 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2122
  %2135 = load <8 x i1>, ptr %2133, align 1
  %2136 = load <8 x i1>, ptr %2134, align 1
  %2137 = or <8 x i1> %2136, %convergence.cascade.flow293
  %2138 = load <8 x i1>, ptr %live.mask, align 1
  %2139 = and <8 x i1> %2135, %2138
  %2140 = icmp eq <8 x i1> %2137, %2139
  %2141 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2140)
  %2142 = and i1 %2132, %2141
  %2143 = select i1 %2142, <8 x i1> zeroinitializer, <8 x i1> %2137
  %2144 = select i1 %2132, <8 x i1> %2143, <8 x i1> %2136
  store <8 x i1> %2144, ptr %2134, align 1
  %2145 = select i1 %2142, <8 x i1> zeroinitializer, <8 x i1> %2135
  store <8 x i1> %2145, ptr %2133, align 1
  %2146 = trunc i32 %2122 to i8
  %2147 = shl i8 1, %2146
  %2148 = xor i8 %2147, -1
  %2149 = and i8 %2123, %2148
  %2150 = select i1 %2142, i8 %2149, i8 %2123
  store i8 %2150, ptr %frame.active, align 1
  %.splatinsert297 = insertelement <8 x i1> poison, i1 %2132, i64 0
  %.splat298 = shufflevector <8 x i1> %.splatinsert297, <8 x i1> poison, <8 x i32> zeroinitializer
  %2151 = and <8 x i1> %convergence.cascade.flow293, %.splat298
  %2152 = load <8 x i1>, ptr %runnable.mask, align 1
  %2153 = xor <8 x i1> %2151, splat (i1 true)
  %2154 = and <8 x i1> %2152, %2153
  store <8 x i1> %2154, ptr %runnable.mask, align 1
  %.splatinsert299 = insertelement <8 x i1> poison, i1 %2142, i64 0
  %.splat300 = shufflevector <8 x i1> %.splatinsert299, <8 x i1> poison, <8 x i32> zeroinitializer
  %2155 = select <8 x i1> %.splat300, <8 x i1> %2137, <8 x i1> zeroinitializer
  %2156 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2157 = extractelement <8 x i32> %2156, i32 %2122
  %2158 = select i1 %2142, i32 %2157, i32 %2118
  store i32 %2158, ptr %current.token, align 4
  %.splatinsert301 = insertelement <8 x i1> poison, i1 %2132, i64 0
  %.splat302 = shufflevector <8 x i1> %.splatinsert301, <8 x i1> poison, <8 x i32> zeroinitializer
  %2159 = select <8 x i1> %.splat302, <8 x i1> %2155, <8 x i1> %convergence.cascade.flow293
  %2160 = add i32 %convergence.cascade.depth294, 1
  %2161 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2159)
  %2162 = icmp ult i32 %2160, 8
  %2163 = and i1 %2161, %2162
  %2164 = and i1 %2132, %2163
  %convergence.parent.token303 = load i32, ptr %current.token, align 4
  %convergence.parent.present304 = icmp ne i32 %convergence.parent.token303, 0
  %2165 = and i1 %2164, %convergence.parent.present304
  br i1 %2165, label %convergence.cascade289, label %convergence.cascade.exit290

convergence.cascade.exit290:                      ; preds = %convergence.cascade289, %schedule.12
  %convergence.cascade.result305 = phi <8 x i1> [ %370, %schedule.12 ], [ %2159, %convergence.cascade289 ]
  %2166 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  br i1 %2166, label %convergence.target.12.ready, label %scheduler.loop

convergence.target.12.ready:                      ; preds = %convergence.cascade.exit290
  %2167 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  %2168 = bitcast <8 x i1> %convergence.cascade.result305 to i8
  %2169 = call i8 @llvm.cttz.i8(i8 %2168, i1 false)
  %2170 = zext i8 %2169 to i32
  %2171 = select i1 %2167, i32 %2170, i32 0
  %2172 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %2173 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %2174 = extractvalue { <8 x ptr>, <8 x i64> } %2172, 0
  %2175 = select <8 x i1> %convergence.cascade.result305, <8 x ptr> %2173, <8 x ptr> %2174
  %2176 = extractvalue { <8 x ptr>, <8 x i64> } %9, 1
  %2177 = extractvalue { <8 x ptr>, <8 x i64> } %2172, 1
  %2178 = select <8 x i1> %convergence.cascade.result305, <8 x i64> %2176, <8 x i64> %2177
  %2179 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2175, 0
  %2180 = insertvalue { <8 x ptr>, <8 x i64> } %2179, <8 x i64> %2178, 1
  store volatile { <8 x ptr>, <8 x i64> } %2180, ptr %tile_snapshot.spill65, align 64
  %2181 = load <8 x i64>, ptr %.slot66, align 64
  %2182 = select <8 x i1> %convergence.cascade.result305, <8 x i64> zeroinitializer, <8 x i64> %2181
  store <8 x i64> %2182, ptr %.slot66, align 64
  store <8 x i1> %convergence.cascade.result305, ptr %current.mask, align 1
  %2183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result305)
  br i1 %2183, label %schedule.13, label %scheduler.loop

varying.divergent307:                             ; preds = %schedule.13
  %2184 = load i32, ptr %current.token, align 4
  %2185 = icmp ne i32 %2184, 0
  %2186 = sub i32 %2184, 1
  %2187 = select i1 %2185, i32 %2186, i32 0
  %2188 = load i8, ptr %frame.active, align 1
  %2189 = trunc i32 %2187 to i8
  %2190 = shl i8 1, %2189
  %2191 = and i8 %2188, %2190
  %2192 = icmp ne i8 %2191, 0
  %2193 = load <8 x i32>, ptr %frame.static.id, align 32
  %2194 = extractelement <8 x i32> %2193, i32 %2187
  %2195 = icmp eq i32 %2194, 5
  %2196 = and i1 %2192, %2195
  %2197 = and i1 %2185, %2196
  %2198 = xor i1 %2197, true
  %2199 = and i1 true, %2198
  %2200 = xor i8 %2188, -1
  %2201 = icmp ne i8 %2200, 0
  %2202 = xor i1 %2201, true
  %2203 = and i1 %2199, %2202
  br i1 %2203, label %convergence.overflow.trap309, label %convergence.overflow.resume310

varying.coherent308:                              ; preds = %schedule.13
  br i1 %381, label %varying.coherent.true313, label %varying.coherent.false314

convergence.overflow.trap309:                     ; preds = %varying.divergent307
  call void @llvm.trap()
  unreachable

convergence.overflow.resume310:                   ; preds = %varying.divergent307
  %2204 = call i8 @llvm.cttz.i8(i8 %2200, i1 false)
  %2205 = zext i8 %2204 to i32
  %2206 = select i1 %2201, i32 %2205, i32 0
  %2207 = trunc i32 %2206 to i8
  %2208 = shl i8 1, %2207
  %2209 = or i8 %2188, %2208
  %2210 = select i1 %2199, i8 %2209, i8 %2188
  store i8 %2210, ptr %frame.active, align 1
  %2211 = load <8 x i32>, ptr %frame.static.id, align 32
  %2212 = extractelement <8 x i32> %2211, i32 %2206
  %2213 = select i1 %2199, i32 5, i32 %2212
  %2214 = load <8 x i32>, ptr %frame.static.id, align 32
  %2215 = insertelement <8 x i32> %2214, i32 %2213, i32 %2206
  store <8 x i32> %2215, ptr %frame.static.id, align 32
  %2216 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2217 = extractelement <8 x i32> %2216, i32 %2206
  %2218 = select i1 %2199, i32 %2184, i32 %2217
  %2219 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2220 = insertelement <8 x i32> %2219, i32 %2218, i32 %2206
  store <8 x i32> %2220, ptr %frame.parent.token, align 32
  %2221 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2206
  %2222 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2206
  %2223 = load <8 x i1>, ptr %2221, align 1
  %2224 = load <8 x i1>, ptr %2222, align 1
  %2225 = select i1 %2199, <8 x i1> %371, <8 x i1> %2223
  store <8 x i1> %2225, ptr %2221, align 1
  %2226 = select i1 %2199, <8 x i1> zeroinitializer, <8 x i1> %2224
  store <8 x i1> %2226, ptr %2222, align 1
  %2227 = add i32 %2206, 1
  %2228 = select i1 %2197, i32 %2184, i32 %2227
  %2229 = select i1 true, i32 %2228, i32 %2184
  store i32 %2229, ptr %current.token, align 4
  %2230 = load i32, ptr %current.token, align 4
  %2231 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %378)
  %2232 = load i32, ptr %ready.count, align 4
  %2233 = icmp uge i32 %2232, 8
  %2234 = and i1 %2231, %2233
  br i1 %2234, label %ready.overflow.trap311, label %ready.overflow.resume312

ready.overflow.trap311:                           ; preds = %convergence.overflow.resume310
  call void @llvm.trap()
  unreachable

ready.overflow.resume312:                         ; preds = %convergence.overflow.resume310
  %2235 = select i1 %2231, i32 %2232, i32 0
  %2236 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2235
  %2237 = load <8 x i1>, ptr %2236, align 1
  %2238 = select i1 %2231, <8 x i1> %378, <8 x i1> %2237
  store <8 x i1> %2238, ptr %2236, align 1
  %2239 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2235
  %2240 = load i32, ptr %2239, align 4
  %2241 = select i1 %2231, i32 14, i32 %2240
  store i32 %2241, ptr %2239, align 4
  %2242 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2235
  %2243 = load i32, ptr %2242, align 4
  %2244 = select i1 %2231, i32 %2230, i32 %2243
  store i32 %2244, ptr %2242, align 4
  %2245 = add i32 %2232, 1
  %2246 = select i1 %2231, i32 %2245, i32 %2232
  store i32 %2246, ptr %ready.count, align 4
  %2247 = load <8 x i1>, ptr %runnable.mask, align 1
  %2248 = or <8 x i1> %2247, %378
  store <8 x i1> %2248, ptr %runnable.mask, align 1
  store <8 x i1> %380, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true313:                         ; preds = %varying.coherent308
  store <8 x i1> %371, ptr %current.mask, align 1
  %2249 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %371)
  br i1 %2249, label %schedule.14, label %scheduler.loop

varying.coherent.false314:                        ; preds = %varying.coherent308
  store <8 x i1> %371, ptr %current.mask, align 1
  %2250 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %371)
  br i1 %2250, label %schedule.15, label %scheduler.loop

convergence.cascade322:                           ; preds = %convergence.cascade322, %schedule.15
  %convergence.cascade.flow326 = phi <8 x i1> [ %433, %schedule.15 ], [ %2293, %convergence.cascade322 ]
  %convergence.cascade.depth327 = phi i32 [ 0, %schedule.15 ], [ %2294, %convergence.cascade322 ]
  %2251 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow326)
  %2252 = load i32, ptr %current.token, align 4
  %2253 = icmp ne i32 %2252, 0
  %2254 = and i1 %2251, %2253
  %2255 = sub i32 %2252, 1
  %2256 = select i1 %2254, i32 %2255, i32 0
  %2257 = load i8, ptr %frame.active, align 1
  %2258 = trunc i32 %2256 to i8
  %2259 = shl i8 1, %2258
  %2260 = and i8 %2257, %2259
  %2261 = icmp ne i8 %2260, 0
  %2262 = load <8 x i32>, ptr %frame.static.id, align 32
  %2263 = extractelement <8 x i32> %2262, i32 %2256
  %convergence.target.pointer328 = getelementptr inbounds [20 x i32], ptr @convergence.targets, i32 0, i32 %2263
  %convergence.dynamic.target329 = load i32, ptr %convergence.target.pointer328, align 4
  %2264 = icmp eq i32 %convergence.dynamic.target329, 15
  %2265 = and i1 %2261, %2264
  %2266 = and i1 %2254, %2265
  %2267 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2256
  %2268 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2256
  %2269 = load <8 x i1>, ptr %2267, align 1
  %2270 = load <8 x i1>, ptr %2268, align 1
  %2271 = or <8 x i1> %2270, %convergence.cascade.flow326
  %2272 = load <8 x i1>, ptr %live.mask, align 1
  %2273 = and <8 x i1> %2269, %2272
  %2274 = icmp eq <8 x i1> %2271, %2273
  %2275 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2274)
  %2276 = and i1 %2266, %2275
  %2277 = select i1 %2276, <8 x i1> zeroinitializer, <8 x i1> %2271
  %2278 = select i1 %2266, <8 x i1> %2277, <8 x i1> %2270
  store <8 x i1> %2278, ptr %2268, align 1
  %2279 = select i1 %2276, <8 x i1> zeroinitializer, <8 x i1> %2269
  store <8 x i1> %2279, ptr %2267, align 1
  %2280 = trunc i32 %2256 to i8
  %2281 = shl i8 1, %2280
  %2282 = xor i8 %2281, -1
  %2283 = and i8 %2257, %2282
  %2284 = select i1 %2276, i8 %2283, i8 %2257
  store i8 %2284, ptr %frame.active, align 1
  %.splatinsert330 = insertelement <8 x i1> poison, i1 %2266, i64 0
  %.splat331 = shufflevector <8 x i1> %.splatinsert330, <8 x i1> poison, <8 x i32> zeroinitializer
  %2285 = and <8 x i1> %convergence.cascade.flow326, %.splat331
  %2286 = load <8 x i1>, ptr %runnable.mask, align 1
  %2287 = xor <8 x i1> %2285, splat (i1 true)
  %2288 = and <8 x i1> %2286, %2287
  store <8 x i1> %2288, ptr %runnable.mask, align 1
  %.splatinsert332 = insertelement <8 x i1> poison, i1 %2276, i64 0
  %.splat333 = shufflevector <8 x i1> %.splatinsert332, <8 x i1> poison, <8 x i32> zeroinitializer
  %2289 = select <8 x i1> %.splat333, <8 x i1> %2271, <8 x i1> zeroinitializer
  %2290 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2291 = extractelement <8 x i32> %2290, i32 %2256
  %2292 = select i1 %2276, i32 %2291, i32 %2252
  store i32 %2292, ptr %current.token, align 4
  %.splatinsert334 = insertelement <8 x i1> poison, i1 %2266, i64 0
  %.splat335 = shufflevector <8 x i1> %.splatinsert334, <8 x i1> poison, <8 x i32> zeroinitializer
  %2293 = select <8 x i1> %.splat335, <8 x i1> %2289, <8 x i1> %convergence.cascade.flow326
  %2294 = add i32 %convergence.cascade.depth327, 1
  %2295 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2293)
  %2296 = icmp ult i32 %2294, 8
  %2297 = and i1 %2295, %2296
  %2298 = and i1 %2266, %2297
  %convergence.parent.token336 = load i32, ptr %current.token, align 4
  %convergence.parent.present337 = icmp ne i32 %convergence.parent.token336, 0
  %2299 = and i1 %2298, %convergence.parent.present337
  br i1 %2299, label %convergence.cascade322, label %convergence.cascade.exit323

convergence.cascade.exit323:                      ; preds = %convergence.cascade322, %schedule.15
  %convergence.cascade.result338 = phi <8 x i1> [ %433, %schedule.15 ], [ %2293, %convergence.cascade322 ]
  %2300 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  br i1 %2300, label %convergence.target.15.ready, label %scheduler.loop

convergence.target.15.ready:                      ; preds = %convergence.cascade.exit323
  %2301 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2302 = bitcast <8 x i1> %convergence.cascade.result338 to i8
  %2303 = call i8 @llvm.cttz.i8(i8 %2302, i1 false)
  %2304 = zext i8 %2303 to i32
  %2305 = select i1 %2301, i32 %2304, i32 0
  %2306 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill67, align 64
  %2307 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2308 = extractvalue { <8 x ptr>, <8 x i64> } %2306, 0
  %2309 = select <8 x i1> %convergence.cascade.result338, <8 x ptr> %2307, <8 x ptr> %2308
  %2310 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2311 = extractvalue { <8 x ptr>, <8 x i64> } %2306, 1
  %2312 = select <8 x i1> %convergence.cascade.result338, <8 x i64> %2310, <8 x i64> %2311
  %2313 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2309, 0
  %2314 = insertvalue { <8 x ptr>, <8 x i64> } %2313, <8 x i64> %2312, 1
  store volatile { <8 x ptr>, <8 x i64> } %2314, ptr %tile_snapshot.spill67, align 64
  %2315 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2316 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2317 = add <8 x i64> %2316, zeroinitializer
  %2318 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2315, 0
  %2319 = insertvalue { <8 x ptr>, <8 x i64> } %2318, <8 x i64> %2317, 1
  %2320 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2321 = extractvalue { <8 x ptr>, <8 x i64> } %2319, 1
  %2322 = extractelement <8 x ptr> %2320, i32 0
  %2323 = extractelement <8 x i64> %2321, i32 %2305
  %2324 = zext i32 %2305 to i64
  %2325 = mul i64 %2324, 8
  %2326 = sub i64 %2323, %2325
  %2327 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2328 = select i1 %2327, i64 %2326, i64 0
  %private.contiguous.address339 = getelementptr i8, ptr %2322, i64 %2328
  %private.contiguous.preserve340 = load <8 x i64>, ptr %private.contiguous.address339, align 8
  %2329 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 -2), <8 x i64> %private.contiguous.preserve340
  store <8 x i64> %2329, ptr %private.contiguous.address339, align 8
  %2330 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2331 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2332 = add <8 x i64> %2331, splat (i64 64)
  %2333 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2330, 0
  %2334 = insertvalue { <8 x ptr>, <8 x i64> } %2333, <8 x i64> %2332, 1
  %2335 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2336 = extractvalue { <8 x ptr>, <8 x i64> } %2334, 1
  %2337 = extractelement <8 x ptr> %2335, i32 0
  %2338 = extractelement <8 x i64> %2336, i32 %2305
  %2339 = zext i32 %2305 to i64
  %2340 = mul i64 %2339, 8
  %2341 = sub i64 %2338, %2340
  %2342 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2343 = select i1 %2342, i64 %2341, i64 0
  %private.contiguous.address341 = getelementptr i8, ptr %2337, i64 %2343
  %private.contiguous.preserve342 = load <8 x i64>, ptr %private.contiguous.address341, align 8
  %2344 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 -1), <8 x i64> %private.contiguous.preserve342
  store <8 x i64> %2344, ptr %private.contiguous.address341, align 8
  %2345 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2346 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2347 = add <8 x i64> %2346, splat (i64 128)
  %2348 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2345, 0
  %2349 = insertvalue { <8 x ptr>, <8 x i64> } %2348, <8 x i64> %2347, 1
  %2350 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2351 = extractvalue { <8 x ptr>, <8 x i64> } %2349, 1
  %2352 = extractelement <8 x ptr> %2350, i32 0
  %2353 = extractelement <8 x i64> %2351, i32 %2305
  %2354 = zext i32 %2305 to i64
  %2355 = mul i64 %2354, 8
  %2356 = sub i64 %2353, %2355
  %2357 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2358 = select i1 %2357, i64 %2356, i64 0
  %private.contiguous.address343 = getelementptr i8, ptr %2352, i64 %2358
  %private.contiguous.preserve344 = load <8 x i64>, ptr %private.contiguous.address343, align 8
  %2359 = select <8 x i1> %convergence.cascade.result338, <8 x i64> zeroinitializer, <8 x i64> %private.contiguous.preserve344
  store <8 x i64> %2359, ptr %private.contiguous.address343, align 8
  %2360 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2361 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2362 = add <8 x i64> %2361, splat (i64 192)
  %2363 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2360, 0
  %2364 = insertvalue { <8 x ptr>, <8 x i64> } %2363, <8 x i64> %2362, 1
  %2365 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2366 = extractvalue { <8 x ptr>, <8 x i64> } %2364, 1
  %2367 = extractelement <8 x ptr> %2365, i32 0
  %2368 = extractelement <8 x i64> %2366, i32 %2305
  %2369 = zext i32 %2305 to i64
  %2370 = mul i64 %2369, 8
  %2371 = sub i64 %2368, %2370
  %2372 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2373 = select i1 %2372, i64 %2371, i64 0
  %private.contiguous.address345 = getelementptr i8, ptr %2367, i64 %2373
  %private.contiguous.preserve346 = load <8 x i64>, ptr %private.contiguous.address345, align 8
  %2374 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 1), <8 x i64> %private.contiguous.preserve346
  store <8 x i64> %2374, ptr %private.contiguous.address345, align 8
  %2375 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2376 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2377 = add <8 x i64> %2376, splat (i64 256)
  %2378 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2375, 0
  %2379 = insertvalue { <8 x ptr>, <8 x i64> } %2378, <8 x i64> %2377, 1
  %2380 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2381 = extractvalue { <8 x ptr>, <8 x i64> } %2379, 1
  %2382 = extractelement <8 x ptr> %2380, i32 0
  %2383 = extractelement <8 x i64> %2381, i32 %2305
  %2384 = zext i32 %2305 to i64
  %2385 = mul i64 %2384, 8
  %2386 = sub i64 %2383, %2385
  %2387 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2388 = select i1 %2387, i64 %2386, i64 0
  %private.contiguous.address347 = getelementptr i8, ptr %2382, i64 %2388
  %private.contiguous.preserve348 = load <8 x i64>, ptr %private.contiguous.address347, align 8
  %2389 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 2), <8 x i64> %private.contiguous.preserve348
  store <8 x i64> %2389, ptr %private.contiguous.address347, align 8
  %2390 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2391 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2392 = add <8 x i64> %2391, splat (i64 320)
  %2393 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2390, 0
  %2394 = insertvalue { <8 x ptr>, <8 x i64> } %2393, <8 x i64> %2392, 1
  %2395 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2396 = extractvalue { <8 x ptr>, <8 x i64> } %2394, 1
  %2397 = extractelement <8 x ptr> %2395, i32 0
  %2398 = extractelement <8 x i64> %2396, i32 %2305
  %2399 = zext i32 %2305 to i64
  %2400 = mul i64 %2399, 8
  %2401 = sub i64 %2398, %2400
  %2402 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2403 = select i1 %2402, i64 %2401, i64 0
  %private.contiguous.address349 = getelementptr i8, ptr %2397, i64 %2403
  %private.contiguous.preserve350 = load <8 x i64>, ptr %private.contiguous.address349, align 8
  %2404 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 3), <8 x i64> %private.contiguous.preserve350
  store <8 x i64> %2404, ptr %private.contiguous.address349, align 8
  %2405 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2406 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2407 = add <8 x i64> %2406, splat (i64 384)
  %2408 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2405, 0
  %2409 = insertvalue { <8 x ptr>, <8 x i64> } %2408, <8 x i64> %2407, 1
  %2410 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2411 = extractvalue { <8 x ptr>, <8 x i64> } %2409, 1
  %2412 = extractelement <8 x ptr> %2410, i32 0
  %2413 = extractelement <8 x i64> %2411, i32 %2305
  %2414 = zext i32 %2305 to i64
  %2415 = mul i64 %2414, 8
  %2416 = sub i64 %2413, %2415
  %2417 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2418 = select i1 %2417, i64 %2416, i64 0
  %private.contiguous.address351 = getelementptr i8, ptr %2412, i64 %2418
  %private.contiguous.preserve352 = load <8 x i64>, ptr %private.contiguous.address351, align 8
  %2419 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 4), <8 x i64> %private.contiguous.preserve352
  store <8 x i64> %2419, ptr %private.contiguous.address351, align 8
  %2420 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2421 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2422 = add <8 x i64> %2421, splat (i64 448)
  %2423 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2420, 0
  %2424 = insertvalue { <8 x ptr>, <8 x i64> } %2423, <8 x i64> %2422, 1
  %2425 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2426 = extractvalue { <8 x ptr>, <8 x i64> } %2424, 1
  %2427 = extractelement <8 x ptr> %2425, i32 0
  %2428 = extractelement <8 x i64> %2426, i32 %2305
  %2429 = zext i32 %2305 to i64
  %2430 = mul i64 %2429, 8
  %2431 = sub i64 %2428, %2430
  %2432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2433 = select i1 %2432, i64 %2431, i64 0
  %private.contiguous.address353 = getelementptr i8, ptr %2427, i64 %2433
  %private.contiguous.preserve354 = load <8 x i64>, ptr %private.contiguous.address353, align 8
  %2434 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 5), <8 x i64> %private.contiguous.preserve354
  store <8 x i64> %2434, ptr %private.contiguous.address353, align 8
  %2435 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2436 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2437 = add <8 x i64> %2436, splat (i64 512)
  %2438 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2435, 0
  %2439 = insertvalue { <8 x ptr>, <8 x i64> } %2438, <8 x i64> %2437, 1
  %2440 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2441 = extractvalue { <8 x ptr>, <8 x i64> } %2439, 1
  %2442 = extractelement <8 x ptr> %2440, i32 0
  %2443 = extractelement <8 x i64> %2441, i32 %2305
  %2444 = zext i32 %2305 to i64
  %2445 = mul i64 %2444, 8
  %2446 = sub i64 %2443, %2445
  %2447 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2448 = select i1 %2447, i64 %2446, i64 0
  %private.contiguous.address355 = getelementptr i8, ptr %2442, i64 %2448
  %private.contiguous.preserve356 = load <8 x i64>, ptr %private.contiguous.address355, align 8
  %2449 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 6), <8 x i64> %private.contiguous.preserve356
  store <8 x i64> %2449, ptr %private.contiguous.address355, align 8
  %2450 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2451 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2452 = add <8 x i64> %2451, splat (i64 576)
  %2453 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2450, 0
  %2454 = insertvalue { <8 x ptr>, <8 x i64> } %2453, <8 x i64> %2452, 1
  %2455 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2456 = extractvalue { <8 x ptr>, <8 x i64> } %2454, 1
  %2457 = extractelement <8 x ptr> %2455, i32 0
  %2458 = extractelement <8 x i64> %2456, i32 %2305
  %2459 = zext i32 %2305 to i64
  %2460 = mul i64 %2459, 8
  %2461 = sub i64 %2458, %2460
  %2462 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2463 = select i1 %2462, i64 %2461, i64 0
  %private.contiguous.address357 = getelementptr i8, ptr %2457, i64 %2463
  %private.contiguous.preserve358 = load <8 x i64>, ptr %private.contiguous.address357, align 8
  %2464 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 7), <8 x i64> %private.contiguous.preserve358
  store <8 x i64> %2464, ptr %private.contiguous.address357, align 8
  %2465 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2466 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2467 = add <8 x i64> %2466, splat (i64 640)
  %2468 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2465, 0
  %2469 = insertvalue { <8 x ptr>, <8 x i64> } %2468, <8 x i64> %2467, 1
  %2470 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2471 = extractvalue { <8 x ptr>, <8 x i64> } %2469, 1
  %2472 = extractelement <8 x ptr> %2470, i32 0
  %2473 = extractelement <8 x i64> %2471, i32 %2305
  %2474 = zext i32 %2305 to i64
  %2475 = mul i64 %2474, 8
  %2476 = sub i64 %2473, %2475
  %2477 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2478 = select i1 %2477, i64 %2476, i64 0
  %private.contiguous.address359 = getelementptr i8, ptr %2472, i64 %2478
  %private.contiguous.preserve360 = load <8 x i64>, ptr %private.contiguous.address359, align 8
  %2479 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 8), <8 x i64> %private.contiguous.preserve360
  store <8 x i64> %2479, ptr %private.contiguous.address359, align 8
  %2480 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2481 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2482 = add <8 x i64> %2481, splat (i64 704)
  %2483 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2480, 0
  %2484 = insertvalue { <8 x ptr>, <8 x i64> } %2483, <8 x i64> %2482, 1
  %2485 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2486 = extractvalue { <8 x ptr>, <8 x i64> } %2484, 1
  %2487 = extractelement <8 x ptr> %2485, i32 0
  %2488 = extractelement <8 x i64> %2486, i32 %2305
  %2489 = zext i32 %2305 to i64
  %2490 = mul i64 %2489, 8
  %2491 = sub i64 %2488, %2490
  %2492 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2493 = select i1 %2492, i64 %2491, i64 0
  %private.contiguous.address361 = getelementptr i8, ptr %2487, i64 %2493
  %private.contiguous.preserve362 = load <8 x i64>, ptr %private.contiguous.address361, align 8
  %2494 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 9), <8 x i64> %private.contiguous.preserve362
  store <8 x i64> %2494, ptr %private.contiguous.address361, align 8
  %2495 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2496 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2497 = add <8 x i64> %2496, splat (i64 768)
  %2498 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2495, 0
  %2499 = insertvalue { <8 x ptr>, <8 x i64> } %2498, <8 x i64> %2497, 1
  %2500 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2501 = extractvalue { <8 x ptr>, <8 x i64> } %2499, 1
  %2502 = extractelement <8 x ptr> %2500, i32 0
  %2503 = extractelement <8 x i64> %2501, i32 %2305
  %2504 = zext i32 %2305 to i64
  %2505 = mul i64 %2504, 8
  %2506 = sub i64 %2503, %2505
  %2507 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2508 = select i1 %2507, i64 %2506, i64 0
  %private.contiguous.address363 = getelementptr i8, ptr %2502, i64 %2508
  %private.contiguous.preserve364 = load <8 x i64>, ptr %private.contiguous.address363, align 8
  %2509 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 10), <8 x i64> %private.contiguous.preserve364
  store <8 x i64> %2509, ptr %private.contiguous.address363, align 8
  %2510 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2511 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2512 = add <8 x i64> %2511, splat (i64 832)
  %2513 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2510, 0
  %2514 = insertvalue { <8 x ptr>, <8 x i64> } %2513, <8 x i64> %2512, 1
  %2515 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2516 = extractvalue { <8 x ptr>, <8 x i64> } %2514, 1
  %2517 = extractelement <8 x ptr> %2515, i32 0
  %2518 = extractelement <8 x i64> %2516, i32 %2305
  %2519 = zext i32 %2305 to i64
  %2520 = mul i64 %2519, 8
  %2521 = sub i64 %2518, %2520
  %2522 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2523 = select i1 %2522, i64 %2521, i64 0
  %private.contiguous.address365 = getelementptr i8, ptr %2517, i64 %2523
  %private.contiguous.preserve366 = load <8 x i64>, ptr %private.contiguous.address365, align 8
  %2524 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 11), <8 x i64> %private.contiguous.preserve366
  store <8 x i64> %2524, ptr %private.contiguous.address365, align 8
  %2525 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2526 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2527 = add <8 x i64> %2526, splat (i64 896)
  %2528 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2525, 0
  %2529 = insertvalue { <8 x ptr>, <8 x i64> } %2528, <8 x i64> %2527, 1
  %2530 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2531 = extractvalue { <8 x ptr>, <8 x i64> } %2529, 1
  %2532 = extractelement <8 x ptr> %2530, i32 0
  %2533 = extractelement <8 x i64> %2531, i32 %2305
  %2534 = zext i32 %2305 to i64
  %2535 = mul i64 %2534, 8
  %2536 = sub i64 %2533, %2535
  %2537 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2538 = select i1 %2537, i64 %2536, i64 0
  %private.contiguous.address367 = getelementptr i8, ptr %2532, i64 %2538
  %private.contiguous.preserve368 = load <8 x i64>, ptr %private.contiguous.address367, align 8
  %2539 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 12), <8 x i64> %private.contiguous.preserve368
  store <8 x i64> %2539, ptr %private.contiguous.address367, align 8
  %2540 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2541 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2542 = add <8 x i64> %2541, splat (i64 960)
  %2543 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2540, 0
  %2544 = insertvalue { <8 x ptr>, <8 x i64> } %2543, <8 x i64> %2542, 1
  %2545 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2546 = extractvalue { <8 x ptr>, <8 x i64> } %2544, 1
  %2547 = extractelement <8 x ptr> %2545, i32 0
  %2548 = extractelement <8 x i64> %2546, i32 %2305
  %2549 = zext i32 %2305 to i64
  %2550 = mul i64 %2549, 8
  %2551 = sub i64 %2548, %2550
  %2552 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2553 = select i1 %2552, i64 %2551, i64 0
  %private.contiguous.address369 = getelementptr i8, ptr %2547, i64 %2553
  %private.contiguous.preserve370 = load <8 x i64>, ptr %private.contiguous.address369, align 8
  %2554 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 13), <8 x i64> %private.contiguous.preserve370
  store <8 x i64> %2554, ptr %private.contiguous.address369, align 8
  %2555 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2556 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2557 = add <8 x i64> %2556, splat (i64 1024)
  %2558 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2555, 0
  %2559 = insertvalue { <8 x ptr>, <8 x i64> } %2558, <8 x i64> %2557, 1
  %2560 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2561 = extractvalue { <8 x ptr>, <8 x i64> } %2559, 1
  %2562 = extractelement <8 x ptr> %2560, i32 0
  %2563 = extractelement <8 x i64> %2561, i32 %2305
  %2564 = zext i32 %2305 to i64
  %2565 = mul i64 %2564, 8
  %2566 = sub i64 %2563, %2565
  %2567 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2568 = select i1 %2567, i64 %2566, i64 0
  %private.contiguous.address371 = getelementptr i8, ptr %2562, i64 %2568
  %private.contiguous.preserve372 = load <8 x i64>, ptr %private.contiguous.address371, align 8
  %2569 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 14), <8 x i64> %private.contiguous.preserve372
  store <8 x i64> %2569, ptr %private.contiguous.address371, align 8
  %2570 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2571 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2572 = add <8 x i64> %2571, splat (i64 1088)
  %2573 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2570, 0
  %2574 = insertvalue { <8 x ptr>, <8 x i64> } %2573, <8 x i64> %2572, 1
  %2575 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2576 = extractvalue { <8 x ptr>, <8 x i64> } %2574, 1
  %2577 = extractelement <8 x ptr> %2575, i32 0
  %2578 = extractelement <8 x i64> %2576, i32 %2305
  %2579 = zext i32 %2305 to i64
  %2580 = mul i64 %2579, 8
  %2581 = sub i64 %2578, %2580
  %2582 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2583 = select i1 %2582, i64 %2581, i64 0
  %private.contiguous.address373 = getelementptr i8, ptr %2577, i64 %2583
  %private.contiguous.preserve374 = load <8 x i64>, ptr %private.contiguous.address373, align 8
  %2584 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 15), <8 x i64> %private.contiguous.preserve374
  store <8 x i64> %2584, ptr %private.contiguous.address373, align 8
  %2585 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2586 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2587 = add <8 x i64> %2586, splat (i64 1152)
  %2588 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2585, 0
  %2589 = insertvalue { <8 x ptr>, <8 x i64> } %2588, <8 x i64> %2587, 1
  %2590 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2591 = extractvalue { <8 x ptr>, <8 x i64> } %2589, 1
  %2592 = extractelement <8 x ptr> %2590, i32 0
  %2593 = extractelement <8 x i64> %2591, i32 %2305
  %2594 = zext i32 %2305 to i64
  %2595 = mul i64 %2594, 8
  %2596 = sub i64 %2593, %2595
  %2597 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2598 = select i1 %2597, i64 %2596, i64 0
  %private.contiguous.address375 = getelementptr i8, ptr %2592, i64 %2598
  %private.contiguous.preserve376 = load <8 x i64>, ptr %private.contiguous.address375, align 8
  %2599 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 16), <8 x i64> %private.contiguous.preserve376
  store <8 x i64> %2599, ptr %private.contiguous.address375, align 8
  %2600 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2601 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2602 = add <8 x i64> %2601, splat (i64 1216)
  %2603 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2600, 0
  %2604 = insertvalue { <8 x ptr>, <8 x i64> } %2603, <8 x i64> %2602, 1
  %2605 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2606 = extractvalue { <8 x ptr>, <8 x i64> } %2604, 1
  %2607 = extractelement <8 x ptr> %2605, i32 0
  %2608 = extractelement <8 x i64> %2606, i32 %2305
  %2609 = zext i32 %2305 to i64
  %2610 = mul i64 %2609, 8
  %2611 = sub i64 %2608, %2610
  %2612 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2613 = select i1 %2612, i64 %2611, i64 0
  %private.contiguous.address377 = getelementptr i8, ptr %2607, i64 %2613
  %private.contiguous.preserve378 = load <8 x i64>, ptr %private.contiguous.address377, align 8
  %2614 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 17), <8 x i64> %private.contiguous.preserve378
  store <8 x i64> %2614, ptr %private.contiguous.address377, align 8
  %2615 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2616 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2617 = add <8 x i64> %2616, splat (i64 1280)
  %2618 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2615, 0
  %2619 = insertvalue { <8 x ptr>, <8 x i64> } %2618, <8 x i64> %2617, 1
  %2620 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2621 = extractvalue { <8 x ptr>, <8 x i64> } %2619, 1
  %2622 = extractelement <8 x ptr> %2620, i32 0
  %2623 = extractelement <8 x i64> %2621, i32 %2305
  %2624 = zext i32 %2305 to i64
  %2625 = mul i64 %2624, 8
  %2626 = sub i64 %2623, %2625
  %2627 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2628 = select i1 %2627, i64 %2626, i64 0
  %private.contiguous.address379 = getelementptr i8, ptr %2622, i64 %2628
  %private.contiguous.preserve380 = load <8 x i64>, ptr %private.contiguous.address379, align 8
  %2629 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 18), <8 x i64> %private.contiguous.preserve380
  store <8 x i64> %2629, ptr %private.contiguous.address379, align 8
  %2630 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2631 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2632 = add <8 x i64> %2631, splat (i64 1344)
  %2633 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2630, 0
  %2634 = insertvalue { <8 x ptr>, <8 x i64> } %2633, <8 x i64> %2632, 1
  %2635 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2636 = extractvalue { <8 x ptr>, <8 x i64> } %2634, 1
  %2637 = extractelement <8 x ptr> %2635, i32 0
  %2638 = extractelement <8 x i64> %2636, i32 %2305
  %2639 = zext i32 %2305 to i64
  %2640 = mul i64 %2639, 8
  %2641 = sub i64 %2638, %2640
  %2642 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2643 = select i1 %2642, i64 %2641, i64 0
  %private.contiguous.address381 = getelementptr i8, ptr %2637, i64 %2643
  %private.contiguous.preserve382 = load <8 x i64>, ptr %private.contiguous.address381, align 8
  %2644 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 19), <8 x i64> %private.contiguous.preserve382
  store <8 x i64> %2644, ptr %private.contiguous.address381, align 8
  %2645 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2646 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2647 = add <8 x i64> %2646, splat (i64 1408)
  %2648 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2645, 0
  %2649 = insertvalue { <8 x ptr>, <8 x i64> } %2648, <8 x i64> %2647, 1
  %2650 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2651 = extractvalue { <8 x ptr>, <8 x i64> } %2649, 1
  %2652 = extractelement <8 x ptr> %2650, i32 0
  %2653 = extractelement <8 x i64> %2651, i32 %2305
  %2654 = zext i32 %2305 to i64
  %2655 = mul i64 %2654, 8
  %2656 = sub i64 %2653, %2655
  %2657 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2658 = select i1 %2657, i64 %2656, i64 0
  %private.contiguous.address383 = getelementptr i8, ptr %2652, i64 %2658
  %private.contiguous.preserve384 = load <8 x i64>, ptr %private.contiguous.address383, align 8
  %2659 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 20), <8 x i64> %private.contiguous.preserve384
  store <8 x i64> %2659, ptr %private.contiguous.address383, align 8
  %2660 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2661 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2662 = add <8 x i64> %2661, splat (i64 1472)
  %2663 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2660, 0
  %2664 = insertvalue { <8 x ptr>, <8 x i64> } %2663, <8 x i64> %2662, 1
  %2665 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2666 = extractvalue { <8 x ptr>, <8 x i64> } %2664, 1
  %2667 = extractelement <8 x ptr> %2665, i32 0
  %2668 = extractelement <8 x i64> %2666, i32 %2305
  %2669 = zext i32 %2305 to i64
  %2670 = mul i64 %2669, 8
  %2671 = sub i64 %2668, %2670
  %2672 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2673 = select i1 %2672, i64 %2671, i64 0
  %private.contiguous.address385 = getelementptr i8, ptr %2667, i64 %2673
  %private.contiguous.preserve386 = load <8 x i64>, ptr %private.contiguous.address385, align 8
  %2674 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 21), <8 x i64> %private.contiguous.preserve386
  store <8 x i64> %2674, ptr %private.contiguous.address385, align 8
  %2675 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2676 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2677 = add <8 x i64> %2676, splat (i64 1536)
  %2678 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2675, 0
  %2679 = insertvalue { <8 x ptr>, <8 x i64> } %2678, <8 x i64> %2677, 1
  %2680 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2681 = extractvalue { <8 x ptr>, <8 x i64> } %2679, 1
  %2682 = extractelement <8 x ptr> %2680, i32 0
  %2683 = extractelement <8 x i64> %2681, i32 %2305
  %2684 = zext i32 %2305 to i64
  %2685 = mul i64 %2684, 8
  %2686 = sub i64 %2683, %2685
  %2687 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2688 = select i1 %2687, i64 %2686, i64 0
  %private.contiguous.address387 = getelementptr i8, ptr %2682, i64 %2688
  %private.contiguous.preserve388 = load <8 x i64>, ptr %private.contiguous.address387, align 8
  %2689 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 22), <8 x i64> %private.contiguous.preserve388
  store <8 x i64> %2689, ptr %private.contiguous.address387, align 8
  %2690 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2691 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2692 = add <8 x i64> %2691, splat (i64 1600)
  %2693 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2690, 0
  %2694 = insertvalue { <8 x ptr>, <8 x i64> } %2693, <8 x i64> %2692, 1
  %2695 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2696 = extractvalue { <8 x ptr>, <8 x i64> } %2694, 1
  %2697 = extractelement <8 x ptr> %2695, i32 0
  %2698 = extractelement <8 x i64> %2696, i32 %2305
  %2699 = zext i32 %2305 to i64
  %2700 = mul i64 %2699, 8
  %2701 = sub i64 %2698, %2700
  %2702 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2703 = select i1 %2702, i64 %2701, i64 0
  %private.contiguous.address389 = getelementptr i8, ptr %2697, i64 %2703
  %private.contiguous.preserve390 = load <8 x i64>, ptr %private.contiguous.address389, align 8
  %2704 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 23), <8 x i64> %private.contiguous.preserve390
  store <8 x i64> %2704, ptr %private.contiguous.address389, align 8
  %2705 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2706 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2707 = add <8 x i64> %2706, splat (i64 1664)
  %2708 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2705, 0
  %2709 = insertvalue { <8 x ptr>, <8 x i64> } %2708, <8 x i64> %2707, 1
  %2710 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2711 = extractvalue { <8 x ptr>, <8 x i64> } %2709, 1
  %2712 = extractelement <8 x ptr> %2710, i32 0
  %2713 = extractelement <8 x i64> %2711, i32 %2305
  %2714 = zext i32 %2305 to i64
  %2715 = mul i64 %2714, 8
  %2716 = sub i64 %2713, %2715
  %2717 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2718 = select i1 %2717, i64 %2716, i64 0
  %private.contiguous.address391 = getelementptr i8, ptr %2712, i64 %2718
  %private.contiguous.preserve392 = load <8 x i64>, ptr %private.contiguous.address391, align 8
  %2719 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 24), <8 x i64> %private.contiguous.preserve392
  store <8 x i64> %2719, ptr %private.contiguous.address391, align 8
  %2720 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2721 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2722 = add <8 x i64> %2721, splat (i64 1728)
  %2723 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2720, 0
  %2724 = insertvalue { <8 x ptr>, <8 x i64> } %2723, <8 x i64> %2722, 1
  %2725 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2726 = extractvalue { <8 x ptr>, <8 x i64> } %2724, 1
  %2727 = extractelement <8 x ptr> %2725, i32 0
  %2728 = extractelement <8 x i64> %2726, i32 %2305
  %2729 = zext i32 %2305 to i64
  %2730 = mul i64 %2729, 8
  %2731 = sub i64 %2728, %2730
  %2732 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2733 = select i1 %2732, i64 %2731, i64 0
  %private.contiguous.address393 = getelementptr i8, ptr %2727, i64 %2733
  %private.contiguous.preserve394 = load <8 x i64>, ptr %private.contiguous.address393, align 8
  %2734 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 25), <8 x i64> %private.contiguous.preserve394
  store <8 x i64> %2734, ptr %private.contiguous.address393, align 8
  %2735 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2736 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2737 = add <8 x i64> %2736, splat (i64 1792)
  %2738 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2735, 0
  %2739 = insertvalue { <8 x ptr>, <8 x i64> } %2738, <8 x i64> %2737, 1
  %2740 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2741 = extractvalue { <8 x ptr>, <8 x i64> } %2739, 1
  %2742 = extractelement <8 x ptr> %2740, i32 0
  %2743 = extractelement <8 x i64> %2741, i32 %2305
  %2744 = zext i32 %2305 to i64
  %2745 = mul i64 %2744, 8
  %2746 = sub i64 %2743, %2745
  %2747 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2748 = select i1 %2747, i64 %2746, i64 0
  %private.contiguous.address395 = getelementptr i8, ptr %2742, i64 %2748
  %private.contiguous.preserve396 = load <8 x i64>, ptr %private.contiguous.address395, align 8
  %2749 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 26), <8 x i64> %private.contiguous.preserve396
  store <8 x i64> %2749, ptr %private.contiguous.address395, align 8
  %2750 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2751 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2752 = add <8 x i64> %2751, splat (i64 1856)
  %2753 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2750, 0
  %2754 = insertvalue { <8 x ptr>, <8 x i64> } %2753, <8 x i64> %2752, 1
  %2755 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2756 = extractvalue { <8 x ptr>, <8 x i64> } %2754, 1
  %2757 = extractelement <8 x ptr> %2755, i32 0
  %2758 = extractelement <8 x i64> %2756, i32 %2305
  %2759 = zext i32 %2305 to i64
  %2760 = mul i64 %2759, 8
  %2761 = sub i64 %2758, %2760
  %2762 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2763 = select i1 %2762, i64 %2761, i64 0
  %private.contiguous.address397 = getelementptr i8, ptr %2757, i64 %2763
  %private.contiguous.preserve398 = load <8 x i64>, ptr %private.contiguous.address397, align 8
  %2764 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 27), <8 x i64> %private.contiguous.preserve398
  store <8 x i64> %2764, ptr %private.contiguous.address397, align 8
  %2765 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2766 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2767 = add <8 x i64> %2766, splat (i64 1920)
  %2768 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2765, 0
  %2769 = insertvalue { <8 x ptr>, <8 x i64> } %2768, <8 x i64> %2767, 1
  %2770 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2771 = extractvalue { <8 x ptr>, <8 x i64> } %2769, 1
  %2772 = extractelement <8 x ptr> %2770, i32 0
  %2773 = extractelement <8 x i64> %2771, i32 %2305
  %2774 = zext i32 %2305 to i64
  %2775 = mul i64 %2774, 8
  %2776 = sub i64 %2773, %2775
  %2777 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2778 = select i1 %2777, i64 %2776, i64 0
  %private.contiguous.address399 = getelementptr i8, ptr %2772, i64 %2778
  %private.contiguous.preserve400 = load <8 x i64>, ptr %private.contiguous.address399, align 8
  %2779 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 28), <8 x i64> %private.contiguous.preserve400
  store <8 x i64> %2779, ptr %private.contiguous.address399, align 8
  %2780 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2781 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %2782 = add <8 x i64> %2781, splat (i64 1984)
  %2783 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2780, 0
  %2784 = insertvalue { <8 x ptr>, <8 x i64> } %2783, <8 x i64> %2782, 1
  %2785 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %2786 = extractvalue { <8 x ptr>, <8 x i64> } %2784, 1
  %2787 = extractelement <8 x ptr> %2785, i32 0
  %2788 = extractelement <8 x i64> %2786, i32 %2305
  %2789 = zext i32 %2305 to i64
  %2790 = mul i64 %2789, 8
  %2791 = sub i64 %2788, %2790
  %2792 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  %2793 = select i1 %2792, i64 %2791, i64 0
  %private.contiguous.address401 = getelementptr i8, ptr %2787, i64 %2793
  %private.contiguous.preserve402 = load <8 x i64>, ptr %private.contiguous.address401, align 8
  %2794 = select <8 x i1> %convergence.cascade.result338, <8 x i64> splat (i64 29), <8 x i64> %private.contiguous.preserve402
  store <8 x i64> %2794, ptr %private.contiguous.address401, align 8
  %2795 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill68, align 64
  %2796 = extractvalue { <8 x ptr>, <8 x i64> } %13, 0
  %2797 = extractvalue { <8 x ptr>, <8 x i64> } %2795, 0
  %2798 = select <8 x i1> %convergence.cascade.result338, <8 x ptr> %2796, <8 x ptr> %2797
  %2799 = extractvalue { <8 x ptr>, <8 x i64> } %13, 1
  %2800 = extractvalue { <8 x ptr>, <8 x i64> } %2795, 1
  %2801 = select <8 x i1> %convergence.cascade.result338, <8 x i64> %2799, <8 x i64> %2800
  %2802 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2798, 0
  %2803 = insertvalue { <8 x ptr>, <8 x i64> } %2802, <8 x i64> %2801, 1
  store volatile { <8 x ptr>, <8 x i64> } %2803, ptr %tile_snapshot.spill68, align 64
  %2804 = load <8 x i64>, ptr %.slot69, align 64
  %2805 = select <8 x i1> %convergence.cascade.result338, <8 x i64> zeroinitializer, <8 x i64> %2804
  store <8 x i64> %2805, ptr %.slot69, align 64
  store <8 x i1> %convergence.cascade.result338, ptr %current.mask, align 1
  %2806 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result338)
  br i1 %2806, label %schedule.16, label %scheduler.loop

varying.divergent404:                             ; preds = %schedule.16
  %2807 = load i32, ptr %current.token, align 4
  %2808 = icmp ne i32 %2807, 0
  %2809 = sub i32 %2807, 1
  %2810 = select i1 %2808, i32 %2809, i32 0
  %2811 = load i8, ptr %frame.active, align 1
  %2812 = trunc i32 %2810 to i8
  %2813 = shl i8 1, %2812
  %2814 = and i8 %2811, %2813
  %2815 = icmp ne i8 %2814, 0
  %2816 = load <8 x i32>, ptr %frame.static.id, align 32
  %2817 = extractelement <8 x i32> %2816, i32 %2810
  %2818 = icmp eq i32 %2817, 6
  %2819 = and i1 %2815, %2818
  %2820 = and i1 %2808, %2819
  %2821 = xor i1 %2820, true
  %2822 = and i1 true, %2821
  %2823 = xor i8 %2811, -1
  %2824 = icmp ne i8 %2823, 0
  %2825 = xor i1 %2824, true
  %2826 = and i1 %2822, %2825
  br i1 %2826, label %convergence.overflow.trap406, label %convergence.overflow.resume407

varying.coherent405:                              ; preds = %schedule.16
  br i1 %444, label %varying.coherent.true410, label %varying.coherent.false411

convergence.overflow.trap406:                     ; preds = %varying.divergent404
  call void @llvm.trap()
  unreachable

convergence.overflow.resume407:                   ; preds = %varying.divergent404
  %2827 = call i8 @llvm.cttz.i8(i8 %2823, i1 false)
  %2828 = zext i8 %2827 to i32
  %2829 = select i1 %2824, i32 %2828, i32 0
  %2830 = trunc i32 %2829 to i8
  %2831 = shl i8 1, %2830
  %2832 = or i8 %2811, %2831
  %2833 = select i1 %2822, i8 %2832, i8 %2811
  store i8 %2833, ptr %frame.active, align 1
  %2834 = load <8 x i32>, ptr %frame.static.id, align 32
  %2835 = extractelement <8 x i32> %2834, i32 %2829
  %2836 = select i1 %2822, i32 6, i32 %2835
  %2837 = load <8 x i32>, ptr %frame.static.id, align 32
  %2838 = insertelement <8 x i32> %2837, i32 %2836, i32 %2829
  store <8 x i32> %2838, ptr %frame.static.id, align 32
  %2839 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2840 = extractelement <8 x i32> %2839, i32 %2829
  %2841 = select i1 %2822, i32 %2807, i32 %2840
  %2842 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2843 = insertelement <8 x i32> %2842, i32 %2841, i32 %2829
  store <8 x i32> %2843, ptr %frame.parent.token, align 32
  %2844 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2829
  %2845 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2829
  %2846 = load <8 x i1>, ptr %2844, align 1
  %2847 = load <8 x i1>, ptr %2845, align 1
  %2848 = select i1 %2822, <8 x i1> %434, <8 x i1> %2846
  store <8 x i1> %2848, ptr %2844, align 1
  %2849 = select i1 %2822, <8 x i1> zeroinitializer, <8 x i1> %2847
  store <8 x i1> %2849, ptr %2845, align 1
  %2850 = add i32 %2829, 1
  %2851 = select i1 %2820, i32 %2807, i32 %2850
  %2852 = select i1 true, i32 %2851, i32 %2807
  store i32 %2852, ptr %current.token, align 4
  %2853 = load i32, ptr %current.token, align 4
  %2854 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %441)
  %2855 = load i32, ptr %ready.count, align 4
  %2856 = icmp uge i32 %2855, 8
  %2857 = and i1 %2854, %2856
  br i1 %2857, label %ready.overflow.trap408, label %ready.overflow.resume409

ready.overflow.trap408:                           ; preds = %convergence.overflow.resume407
  call void @llvm.trap()
  unreachable

ready.overflow.resume409:                         ; preds = %convergence.overflow.resume407
  %2858 = select i1 %2854, i32 %2855, i32 0
  %2859 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2858
  %2860 = load <8 x i1>, ptr %2859, align 1
  %2861 = select i1 %2854, <8 x i1> %441, <8 x i1> %2860
  store <8 x i1> %2861, ptr %2859, align 1
  %2862 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2858
  %2863 = load i32, ptr %2862, align 4
  %2864 = select i1 %2854, i32 17, i32 %2863
  store i32 %2864, ptr %2862, align 4
  %2865 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2858
  %2866 = load i32, ptr %2865, align 4
  %2867 = select i1 %2854, i32 %2853, i32 %2866
  store i32 %2867, ptr %2865, align 4
  %2868 = add i32 %2855, 1
  %2869 = select i1 %2854, i32 %2868, i32 %2855
  store i32 %2869, ptr %ready.count, align 4
  %2870 = load <8 x i1>, ptr %runnable.mask, align 1
  %2871 = or <8 x i1> %2870, %441
  store <8 x i1> %2871, ptr %runnable.mask, align 1
  store <8 x i1> %443, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true410:                         ; preds = %varying.coherent405
  store <8 x i1> %434, ptr %current.mask, align 1
  %2872 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %434)
  br i1 %2872, label %schedule.17, label %scheduler.loop

varying.coherent.false411:                        ; preds = %varying.coherent405
  store <8 x i1> %434, ptr %current.mask, align 1
  %2873 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %434)
  br i1 %2873, label %schedule.20, label %scheduler.loop

varying.divergent415:                             ; preds = %schedule.17
  %2874 = load i32, ptr %current.token, align 4
  %2875 = icmp ne i32 %2874, 0
  %2876 = sub i32 %2874, 1
  %2877 = select i1 %2875, i32 %2876, i32 0
  %2878 = load i8, ptr %frame.active, align 1
  %2879 = trunc i32 %2877 to i8
  %2880 = shl i8 1, %2879
  %2881 = and i8 %2878, %2880
  %2882 = icmp ne i8 %2881, 0
  %2883 = load <8 x i32>, ptr %frame.static.id, align 32
  %2884 = extractelement <8 x i32> %2883, i32 %2877
  %2885 = icmp eq i32 %2884, 7
  %2886 = and i1 %2882, %2885
  %2887 = and i1 %2875, %2886
  %2888 = xor i1 %2887, true
  %2889 = and i1 true, %2888
  %2890 = xor i8 %2878, -1
  %2891 = icmp ne i8 %2890, 0
  %2892 = xor i1 %2891, true
  %2893 = and i1 %2889, %2892
  br i1 %2893, label %convergence.overflow.trap417, label %convergence.overflow.resume418

varying.coherent416:                              ; preds = %schedule.17
  br i1 %486, label %varying.coherent.true421, label %varying.coherent.false422

convergence.overflow.trap417:                     ; preds = %varying.divergent415
  call void @llvm.trap()
  unreachable

convergence.overflow.resume418:                   ; preds = %varying.divergent415
  %2894 = call i8 @llvm.cttz.i8(i8 %2890, i1 false)
  %2895 = zext i8 %2894 to i32
  %2896 = select i1 %2891, i32 %2895, i32 0
  %2897 = trunc i32 %2896 to i8
  %2898 = shl i8 1, %2897
  %2899 = or i8 %2878, %2898
  %2900 = select i1 %2889, i8 %2899, i8 %2878
  store i8 %2900, ptr %frame.active, align 1
  %2901 = load <8 x i32>, ptr %frame.static.id, align 32
  %2902 = extractelement <8 x i32> %2901, i32 %2896
  %2903 = select i1 %2889, i32 7, i32 %2902
  %2904 = load <8 x i32>, ptr %frame.static.id, align 32
  %2905 = insertelement <8 x i32> %2904, i32 %2903, i32 %2896
  store <8 x i32> %2905, ptr %frame.static.id, align 32
  %2906 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2907 = extractelement <8 x i32> %2906, i32 %2896
  %2908 = select i1 %2889, i32 %2874, i32 %2907
  %2909 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2910 = insertelement <8 x i32> %2909, i32 %2908, i32 %2896
  store <8 x i32> %2910, ptr %frame.parent.token, align 32
  %2911 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2896
  %2912 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2896
  %2913 = load <8 x i1>, ptr %2911, align 1
  %2914 = load <8 x i1>, ptr %2912, align 1
  %2915 = select i1 %2889, <8 x i1> %447, <8 x i1> %2913
  store <8 x i1> %2915, ptr %2911, align 1
  %2916 = select i1 %2889, <8 x i1> zeroinitializer, <8 x i1> %2914
  store <8 x i1> %2916, ptr %2912, align 1
  %2917 = add i32 %2896, 1
  %2918 = select i1 %2887, i32 %2874, i32 %2917
  %2919 = select i1 true, i32 %2918, i32 %2874
  store i32 %2919, ptr %current.token, align 4
  %2920 = load <8 x float>, ptr %.slot72, align 32
  %2921 = select <8 x i1> %485, <8 x float> zeroinitializer, <8 x float> %2920
  store <8 x float> %2921, ptr %.slot72, align 32
  %2922 = load i32, ptr %current.token, align 4
  %2923 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %483)
  %2924 = load i32, ptr %ready.count, align 4
  %2925 = icmp uge i32 %2924, 8
  %2926 = and i1 %2923, %2925
  br i1 %2926, label %ready.overflow.trap419, label %ready.overflow.resume420

ready.overflow.trap419:                           ; preds = %convergence.overflow.resume418
  call void @llvm.trap()
  unreachable

ready.overflow.resume420:                         ; preds = %convergence.overflow.resume418
  %2927 = select i1 %2923, i32 %2924, i32 0
  %2928 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2927
  %2929 = load <8 x i1>, ptr %2928, align 1
  %2930 = select i1 %2923, <8 x i1> %483, <8 x i1> %2929
  store <8 x i1> %2930, ptr %2928, align 1
  %2931 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2927
  %2932 = load i32, ptr %2931, align 4
  %2933 = select i1 %2923, i32 18, i32 %2932
  store i32 %2933, ptr %2931, align 4
  %2934 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2927
  %2935 = load i32, ptr %2934, align 4
  %2936 = select i1 %2923, i32 %2922, i32 %2935
  store i32 %2936, ptr %2934, align 4
  %2937 = add i32 %2924, 1
  %2938 = select i1 %2923, i32 %2937, i32 %2924
  store i32 %2938, ptr %ready.count, align 4
  %2939 = load <8 x i1>, ptr %runnable.mask, align 1
  %2940 = or <8 x i1> %2939, %483
  store <8 x i1> %2940, ptr %runnable.mask, align 1
  store <8 x i1> %485, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true421:                         ; preds = %varying.coherent416
  store <8 x i1> %447, ptr %current.mask, align 1
  %2941 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %447)
  br i1 %2941, label %schedule.18, label %scheduler.loop

varying.coherent.false422:                        ; preds = %varying.coherent416
  %2942 = load <8 x float>, ptr %.slot72, align 32
  %2943 = select <8 x i1> %447, <8 x float> zeroinitializer, <8 x float> %2942
  store <8 x float> %2943, ptr %.slot72, align 32
  store <8 x i1> %447, ptr %current.mask, align 1
  %2944 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %447)
  br i1 %2944, label %schedule.19, label %scheduler.loop

convergence.cascade425:                           ; preds = %convergence.cascade425, %schedule.19
  %convergence.cascade.flow429 = phi <8 x i1> [ %508, %schedule.19 ], [ %2987, %convergence.cascade425 ]
  %convergence.cascade.depth430 = phi i32 [ 0, %schedule.19 ], [ %2988, %convergence.cascade425 ]
  %2945 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow429)
  %2946 = load i32, ptr %current.token, align 4
  %2947 = icmp ne i32 %2946, 0
  %2948 = and i1 %2945, %2947
  %2949 = sub i32 %2946, 1
  %2950 = select i1 %2948, i32 %2949, i32 0
  %2951 = load i8, ptr %frame.active, align 1
  %2952 = trunc i32 %2950 to i8
  %2953 = shl i8 1, %2952
  %2954 = and i8 %2951, %2953
  %2955 = icmp ne i8 %2954, 0
  %2956 = load <8 x i32>, ptr %frame.static.id, align 32
  %2957 = extractelement <8 x i32> %2956, i32 %2950
  %convergence.target.pointer431 = getelementptr inbounds [20 x i32], ptr @convergence.targets, i32 0, i32 %2957
  %convergence.dynamic.target432 = load i32, ptr %convergence.target.pointer431, align 4
  %2958 = icmp eq i32 %convergence.dynamic.target432, 19
  %2959 = and i1 %2955, %2958
  %2960 = and i1 %2948, %2959
  %2961 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2950
  %2962 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2950
  %2963 = load <8 x i1>, ptr %2961, align 1
  %2964 = load <8 x i1>, ptr %2962, align 1
  %2965 = or <8 x i1> %2964, %convergence.cascade.flow429
  %2966 = load <8 x i1>, ptr %live.mask, align 1
  %2967 = and <8 x i1> %2963, %2966
  %2968 = icmp eq <8 x i1> %2965, %2967
  %2969 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2968)
  %2970 = and i1 %2960, %2969
  %2971 = select i1 %2970, <8 x i1> zeroinitializer, <8 x i1> %2965
  %2972 = select i1 %2960, <8 x i1> %2971, <8 x i1> %2964
  store <8 x i1> %2972, ptr %2962, align 1
  %2973 = select i1 %2970, <8 x i1> zeroinitializer, <8 x i1> %2963
  store <8 x i1> %2973, ptr %2961, align 1
  %2974 = trunc i32 %2950 to i8
  %2975 = shl i8 1, %2974
  %2976 = xor i8 %2975, -1
  %2977 = and i8 %2951, %2976
  %2978 = select i1 %2970, i8 %2977, i8 %2951
  store i8 %2978, ptr %frame.active, align 1
  %.splatinsert433 = insertelement <8 x i1> poison, i1 %2960, i64 0
  %.splat434 = shufflevector <8 x i1> %.splatinsert433, <8 x i1> poison, <8 x i32> zeroinitializer
  %2979 = and <8 x i1> %convergence.cascade.flow429, %.splat434
  %2980 = load <8 x i1>, ptr %runnable.mask, align 1
  %2981 = xor <8 x i1> %2979, splat (i1 true)
  %2982 = and <8 x i1> %2980, %2981
  store <8 x i1> %2982, ptr %runnable.mask, align 1
  %.splatinsert435 = insertelement <8 x i1> poison, i1 %2970, i64 0
  %.splat436 = shufflevector <8 x i1> %.splatinsert435, <8 x i1> poison, <8 x i32> zeroinitializer
  %2983 = select <8 x i1> %.splat436, <8 x i1> %2965, <8 x i1> zeroinitializer
  %2984 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2985 = extractelement <8 x i32> %2984, i32 %2950
  %2986 = select i1 %2970, i32 %2985, i32 %2946
  store i32 %2986, ptr %current.token, align 4
  %.splatinsert437 = insertelement <8 x i1> poison, i1 %2960, i64 0
  %.splat438 = shufflevector <8 x i1> %.splatinsert437, <8 x i1> poison, <8 x i32> zeroinitializer
  %2987 = select <8 x i1> %.splat438, <8 x i1> %2983, <8 x i1> %convergence.cascade.flow429
  %2988 = add i32 %convergence.cascade.depth430, 1
  %2989 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2987)
  %2990 = icmp ult i32 %2988, 8
  %2991 = and i1 %2989, %2990
  %2992 = and i1 %2960, %2991
  %convergence.parent.token439 = load i32, ptr %current.token, align 4
  %convergence.parent.present440 = icmp ne i32 %convergence.parent.token439, 0
  %2993 = and i1 %2992, %convergence.parent.present440
  br i1 %2993, label %convergence.cascade425, label %convergence.cascade.exit426

convergence.cascade.exit426:                      ; preds = %convergence.cascade425, %schedule.19
  %convergence.cascade.result441 = phi <8 x i1> [ %508, %schedule.19 ], [ %2987, %convergence.cascade425 ]
  %2994 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result441)
  br i1 %2994, label %convergence.target.19.ready, label %scheduler.loop

convergence.target.19.ready:                      ; preds = %convergence.cascade.exit426
  %2995 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result441)
  %2996 = bitcast <8 x i1> %convergence.cascade.result441 to i8
  %2997 = call i8 @llvm.cttz.i8(i8 %2996, i1 false)
  %2998 = zext i8 %2997 to i32
  %2999 = select i1 %2995, i32 %2998, i32 0
  %.spill.load442 = load float, ptr %.spill49, align 4
  %.splatinsert443 = insertelement <8 x float> poison, float %.spill.load442, i64 0
  %.splat444 = shufflevector <8 x float> %.splatinsert443, <8 x float> poison, <8 x i32> zeroinitializer
  %.state445 = load <8 x float>, ptr %.slot72, align 32
  %.spill.load446 = load volatile <8 x i1>, ptr %.spill70, align 1
  %3000 = select <8 x i1> %.spill.load446, <8 x float> %.state445, <8 x float> %.splat444
  %tile_snapshot.spill.load447 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill68, align 64
  %3001 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load447, 0
  %3002 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load447, 1
  %.state448 = load <8 x i64>, ptr %.slot69, align 64
  %3003 = mul <8 x i64> %.state448, splat (i64 32)
  %3004 = add <8 x i64> %3002, %3003
  %3005 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3001, 0
  %3006 = insertvalue { <8 x ptr>, <8 x i64> } %3005, <8 x i64> %3004, 1
  %3007 = extractvalue { <8 x ptr>, <8 x i64> } %3006, 0
  %3008 = extractvalue { <8 x ptr>, <8 x i64> } %3006, 1
  %3009 = getelementptr i8, <8 x ptr> %3007, <8 x i64> %3008
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %3000, <8 x ptr> %3009, i32 1, <8 x i1> %convergence.cascade.result441)
  %.state449 = load <8 x i64>, ptr %.slot69, align 64
  %3010 = add <8 x i64> %.state449, splat (i64 1)
  %3011 = load <8 x i64>, ptr %.slot69, align 64
  %3012 = select <8 x i1> %convergence.cascade.result441, <8 x i64> %3010, <8 x i64> %3011
  store <8 x i64> %3012, ptr %.slot69, align 64
  store <8 x i1> %convergence.cascade.result441, ptr %current.mask, align 1
  %3013 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result441)
  br i1 %3013, label %schedule.16, label %scheduler.loop

convergence.cascade450:                           ; preds = %convergence.cascade450, %schedule.20
  %convergence.cascade.flow454 = phi <8 x i1> [ %509, %schedule.20 ], [ %3056, %convergence.cascade450 ]
  %convergence.cascade.depth455 = phi i32 [ 0, %schedule.20 ], [ %3057, %convergence.cascade450 ]
  %3014 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow454)
  %3015 = load i32, ptr %current.token, align 4
  %3016 = icmp ne i32 %3015, 0
  %3017 = and i1 %3014, %3016
  %3018 = sub i32 %3015, 1
  %3019 = select i1 %3017, i32 %3018, i32 0
  %3020 = load i8, ptr %frame.active, align 1
  %3021 = trunc i32 %3019 to i8
  %3022 = shl i8 1, %3021
  %3023 = and i8 %3020, %3022
  %3024 = icmp ne i8 %3023, 0
  %3025 = load <8 x i32>, ptr %frame.static.id, align 32
  %3026 = extractelement <8 x i32> %3025, i32 %3019
  %convergence.target.pointer456 = getelementptr inbounds [20 x i32], ptr @convergence.targets, i32 0, i32 %3026
  %convergence.dynamic.target457 = load i32, ptr %convergence.target.pointer456, align 4
  %3027 = icmp eq i32 %convergence.dynamic.target457, 20
  %3028 = and i1 %3024, %3027
  %3029 = and i1 %3017, %3028
  %3030 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3019
  %3031 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3019
  %3032 = load <8 x i1>, ptr %3030, align 1
  %3033 = load <8 x i1>, ptr %3031, align 1
  %3034 = or <8 x i1> %3033, %convergence.cascade.flow454
  %3035 = load <8 x i1>, ptr %live.mask, align 1
  %3036 = and <8 x i1> %3032, %3035
  %3037 = icmp eq <8 x i1> %3034, %3036
  %3038 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3037)
  %3039 = and i1 %3029, %3038
  %3040 = select i1 %3039, <8 x i1> zeroinitializer, <8 x i1> %3034
  %3041 = select i1 %3029, <8 x i1> %3040, <8 x i1> %3033
  store <8 x i1> %3041, ptr %3031, align 1
  %3042 = select i1 %3039, <8 x i1> zeroinitializer, <8 x i1> %3032
  store <8 x i1> %3042, ptr %3030, align 1
  %3043 = trunc i32 %3019 to i8
  %3044 = shl i8 1, %3043
  %3045 = xor i8 %3044, -1
  %3046 = and i8 %3020, %3045
  %3047 = select i1 %3039, i8 %3046, i8 %3020
  store i8 %3047, ptr %frame.active, align 1
  %.splatinsert458 = insertelement <8 x i1> poison, i1 %3029, i64 0
  %.splat459 = shufflevector <8 x i1> %.splatinsert458, <8 x i1> poison, <8 x i32> zeroinitializer
  %3048 = and <8 x i1> %convergence.cascade.flow454, %.splat459
  %3049 = load <8 x i1>, ptr %runnable.mask, align 1
  %3050 = xor <8 x i1> %3048, splat (i1 true)
  %3051 = and <8 x i1> %3049, %3050
  store <8 x i1> %3051, ptr %runnable.mask, align 1
  %.splatinsert460 = insertelement <8 x i1> poison, i1 %3039, i64 0
  %.splat461 = shufflevector <8 x i1> %.splatinsert460, <8 x i1> poison, <8 x i32> zeroinitializer
  %3052 = select <8 x i1> %.splat461, <8 x i1> %3034, <8 x i1> zeroinitializer
  %3053 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3054 = extractelement <8 x i32> %3053, i32 %3019
  %3055 = select i1 %3039, i32 %3054, i32 %3015
  store i32 %3055, ptr %current.token, align 4
  %.splatinsert462 = insertelement <8 x i1> poison, i1 %3029, i64 0
  %.splat463 = shufflevector <8 x i1> %.splatinsert462, <8 x i1> poison, <8 x i32> zeroinitializer
  %3056 = select <8 x i1> %.splat463, <8 x i1> %3052, <8 x i1> %convergence.cascade.flow454
  %3057 = add i32 %convergence.cascade.depth455, 1
  %3058 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3056)
  %3059 = icmp ult i32 %3057, 8
  %3060 = and i1 %3058, %3059
  %3061 = and i1 %3029, %3060
  %convergence.parent.token464 = load i32, ptr %current.token, align 4
  %convergence.parent.present465 = icmp ne i32 %convergence.parent.token464, 0
  %3062 = and i1 %3061, %convergence.parent.present465
  br i1 %3062, label %convergence.cascade450, label %convergence.cascade.exit451

convergence.cascade.exit451:                      ; preds = %convergence.cascade450, %schedule.20
  %convergence.cascade.result466 = phi <8 x i1> [ %509, %schedule.20 ], [ %3056, %convergence.cascade450 ]
  %3063 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result466)
  br i1 %3063, label %convergence.target.20.ready, label %scheduler.loop

convergence.target.20.ready:                      ; preds = %convergence.cascade.exit451
  %3064 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result466)
  %3065 = bitcast <8 x i1> %convergence.cascade.result466 to i8
  %3066 = call i8 @llvm.cttz.i8(i8 %3065, i1 false)
  %3067 = zext i8 %3066 to i32
  %3068 = select i1 %3064, i32 %3067, i32 0
  %3069 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill73, align 64
  %3070 = extractvalue { <8 x ptr>, <8 x i64> } %15, 0
  %3071 = extractvalue { <8 x ptr>, <8 x i64> } %3069, 0
  %3072 = select <8 x i1> %convergence.cascade.result466, <8 x ptr> %3070, <8 x ptr> %3071
  %3073 = extractvalue { <8 x ptr>, <8 x i64> } %15, 1
  %3074 = extractvalue { <8 x ptr>, <8 x i64> } %3069, 1
  %3075 = select <8 x i1> %convergence.cascade.result466, <8 x i64> %3073, <8 x i64> %3074
  %3076 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3072, 0
  %3077 = insertvalue { <8 x ptr>, <8 x i64> } %3076, <8 x i64> %3075, 1
  store volatile { <8 x ptr>, <8 x i64> } %3077, ptr %tile_snapshot.spill73, align 64
  %3078 = load <8 x i64>, ptr %.slot74, align 64
  %3079 = select <8 x i1> %convergence.cascade.result466, <8 x i64> zeroinitializer, <8 x i64> %3078
  store <8 x i64> %3079, ptr %.slot74, align 64
  store <8 x i1> %convergence.cascade.result466, ptr %current.mask, align 1
  %3080 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result466)
  br i1 %3080, label %schedule.21, label %scheduler.loop

varying.divergent468:                             ; preds = %schedule.21
  %3081 = load i32, ptr %current.token, align 4
  %3082 = icmp ne i32 %3081, 0
  %3083 = sub i32 %3081, 1
  %3084 = select i1 %3082, i32 %3083, i32 0
  %3085 = load i8, ptr %frame.active, align 1
  %3086 = trunc i32 %3084 to i8
  %3087 = shl i8 1, %3086
  %3088 = and i8 %3085, %3087
  %3089 = icmp ne i8 %3088, 0
  %3090 = load <8 x i32>, ptr %frame.static.id, align 32
  %3091 = extractelement <8 x i32> %3090, i32 %3084
  %3092 = icmp eq i32 %3091, 8
  %3093 = and i1 %3089, %3092
  %3094 = and i1 %3082, %3093
  %3095 = xor i1 %3094, true
  %3096 = and i1 true, %3095
  %3097 = xor i8 %3085, -1
  %3098 = icmp ne i8 %3097, 0
  %3099 = xor i1 %3098, true
  %3100 = and i1 %3096, %3099
  br i1 %3100, label %convergence.overflow.trap470, label %convergence.overflow.resume471

varying.coherent469:                              ; preds = %schedule.21
  br i1 %520, label %varying.coherent.true474, label %varying.coherent.false475

convergence.overflow.trap470:                     ; preds = %varying.divergent468
  call void @llvm.trap()
  unreachable

convergence.overflow.resume471:                   ; preds = %varying.divergent468
  %3101 = call i8 @llvm.cttz.i8(i8 %3097, i1 false)
  %3102 = zext i8 %3101 to i32
  %3103 = select i1 %3098, i32 %3102, i32 0
  %3104 = trunc i32 %3103 to i8
  %3105 = shl i8 1, %3104
  %3106 = or i8 %3085, %3105
  %3107 = select i1 %3096, i8 %3106, i8 %3085
  store i8 %3107, ptr %frame.active, align 1
  %3108 = load <8 x i32>, ptr %frame.static.id, align 32
  %3109 = extractelement <8 x i32> %3108, i32 %3103
  %3110 = select i1 %3096, i32 8, i32 %3109
  %3111 = load <8 x i32>, ptr %frame.static.id, align 32
  %3112 = insertelement <8 x i32> %3111, i32 %3110, i32 %3103
  store <8 x i32> %3112, ptr %frame.static.id, align 32
  %3113 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3114 = extractelement <8 x i32> %3113, i32 %3103
  %3115 = select i1 %3096, i32 %3081, i32 %3114
  %3116 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3117 = insertelement <8 x i32> %3116, i32 %3115, i32 %3103
  store <8 x i32> %3117, ptr %frame.parent.token, align 32
  %3118 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3103
  %3119 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3103
  %3120 = load <8 x i1>, ptr %3118, align 1
  %3121 = load <8 x i1>, ptr %3119, align 1
  %3122 = select i1 %3096, <8 x i1> %510, <8 x i1> %3120
  store <8 x i1> %3122, ptr %3118, align 1
  %3123 = select i1 %3096, <8 x i1> zeroinitializer, <8 x i1> %3121
  store <8 x i1> %3123, ptr %3119, align 1
  %3124 = add i32 %3103, 1
  %3125 = select i1 %3094, i32 %3081, i32 %3124
  %3126 = select i1 true, i32 %3125, i32 %3081
  store i32 %3126, ptr %current.token, align 4
  %3127 = load i32, ptr %current.token, align 4
  %3128 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %517)
  %3129 = load i32, ptr %ready.count, align 4
  %3130 = icmp uge i32 %3129, 8
  %3131 = and i1 %3128, %3130
  br i1 %3131, label %ready.overflow.trap472, label %ready.overflow.resume473

ready.overflow.trap472:                           ; preds = %convergence.overflow.resume471
  call void @llvm.trap()
  unreachable

ready.overflow.resume473:                         ; preds = %convergence.overflow.resume471
  %3132 = select i1 %3128, i32 %3129, i32 0
  %3133 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3132
  %3134 = load <8 x i1>, ptr %3133, align 1
  %3135 = select i1 %3128, <8 x i1> %517, <8 x i1> %3134
  store <8 x i1> %3135, ptr %3133, align 1
  %3136 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3132
  %3137 = load i32, ptr %3136, align 4
  %3138 = select i1 %3128, i32 22, i32 %3137
  store i32 %3138, ptr %3136, align 4
  %3139 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3132
  %3140 = load i32, ptr %3139, align 4
  %3141 = select i1 %3128, i32 %3127, i32 %3140
  store i32 %3141, ptr %3139, align 4
  %3142 = add i32 %3129, 1
  %3143 = select i1 %3128, i32 %3142, i32 %3129
  store i32 %3143, ptr %ready.count, align 4
  %3144 = load <8 x i1>, ptr %runnable.mask, align 1
  %3145 = or <8 x i1> %3144, %517
  store <8 x i1> %3145, ptr %runnable.mask, align 1
  store <8 x i1> %519, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true474:                         ; preds = %varying.coherent469
  store <8 x i1> %510, ptr %current.mask, align 1
  %3146 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %510)
  br i1 %3146, label %schedule.22, label %scheduler.loop

varying.coherent.false475:                        ; preds = %varying.coherent469
  store <8 x i1> %510, ptr %current.mask, align 1
  %3147 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %510)
  br i1 %3147, label %schedule.23, label %scheduler.loop

convergence.cascade483:                           ; preds = %convergence.cascade483, %schedule.23
  %convergence.cascade.flow487 = phi <8 x i1> [ %572, %schedule.23 ], [ %3190, %convergence.cascade483 ]
  %convergence.cascade.depth488 = phi i32 [ 0, %schedule.23 ], [ %3191, %convergence.cascade483 ]
  %3148 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow487)
  %3149 = load i32, ptr %current.token, align 4
  %3150 = icmp ne i32 %3149, 0
  %3151 = and i1 %3148, %3150
  %3152 = sub i32 %3149, 1
  %3153 = select i1 %3151, i32 %3152, i32 0
  %3154 = load i8, ptr %frame.active, align 1
  %3155 = trunc i32 %3153 to i8
  %3156 = shl i8 1, %3155
  %3157 = and i8 %3154, %3156
  %3158 = icmp ne i8 %3157, 0
  %3159 = load <8 x i32>, ptr %frame.static.id, align 32
  %3160 = extractelement <8 x i32> %3159, i32 %3153
  %convergence.target.pointer489 = getelementptr inbounds [20 x i32], ptr @convergence.targets, i32 0, i32 %3160
  %convergence.dynamic.target490 = load i32, ptr %convergence.target.pointer489, align 4
  %3161 = icmp eq i32 %convergence.dynamic.target490, 23
  %3162 = and i1 %3158, %3161
  %3163 = and i1 %3151, %3162
  %3164 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3153
  %3165 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3153
  %3166 = load <8 x i1>, ptr %3164, align 1
  %3167 = load <8 x i1>, ptr %3165, align 1
  %3168 = or <8 x i1> %3167, %convergence.cascade.flow487
  %3169 = load <8 x i1>, ptr %live.mask, align 1
  %3170 = and <8 x i1> %3166, %3169
  %3171 = icmp eq <8 x i1> %3168, %3170
  %3172 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3171)
  %3173 = and i1 %3163, %3172
  %3174 = select i1 %3173, <8 x i1> zeroinitializer, <8 x i1> %3168
  %3175 = select i1 %3163, <8 x i1> %3174, <8 x i1> %3167
  store <8 x i1> %3175, ptr %3165, align 1
  %3176 = select i1 %3173, <8 x i1> zeroinitializer, <8 x i1> %3166
  store <8 x i1> %3176, ptr %3164, align 1
  %3177 = trunc i32 %3153 to i8
  %3178 = shl i8 1, %3177
  %3179 = xor i8 %3178, -1
  %3180 = and i8 %3154, %3179
  %3181 = select i1 %3173, i8 %3180, i8 %3154
  store i8 %3181, ptr %frame.active, align 1
  %.splatinsert491 = insertelement <8 x i1> poison, i1 %3163, i64 0
  %.splat492 = shufflevector <8 x i1> %.splatinsert491, <8 x i1> poison, <8 x i32> zeroinitializer
  %3182 = and <8 x i1> %convergence.cascade.flow487, %.splat492
  %3183 = load <8 x i1>, ptr %runnable.mask, align 1
  %3184 = xor <8 x i1> %3182, splat (i1 true)
  %3185 = and <8 x i1> %3183, %3184
  store <8 x i1> %3185, ptr %runnable.mask, align 1
  %.splatinsert493 = insertelement <8 x i1> poison, i1 %3173, i64 0
  %.splat494 = shufflevector <8 x i1> %.splatinsert493, <8 x i1> poison, <8 x i32> zeroinitializer
  %3186 = select <8 x i1> %.splat494, <8 x i1> %3168, <8 x i1> zeroinitializer
  %3187 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3188 = extractelement <8 x i32> %3187, i32 %3153
  %3189 = select i1 %3173, i32 %3188, i32 %3149
  store i32 %3189, ptr %current.token, align 4
  %.splatinsert495 = insertelement <8 x i1> poison, i1 %3163, i64 0
  %.splat496 = shufflevector <8 x i1> %.splatinsert495, <8 x i1> poison, <8 x i32> zeroinitializer
  %3190 = select <8 x i1> %.splat496, <8 x i1> %3186, <8 x i1> %convergence.cascade.flow487
  %3191 = add i32 %convergence.cascade.depth488, 1
  %3192 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3190)
  %3193 = icmp ult i32 %3191, 8
  %3194 = and i1 %3192, %3193
  %3195 = and i1 %3163, %3194
  %convergence.parent.token497 = load i32, ptr %current.token, align 4
  %convergence.parent.present498 = icmp ne i32 %convergence.parent.token497, 0
  %3196 = and i1 %3195, %convergence.parent.present498
  br i1 %3196, label %convergence.cascade483, label %convergence.cascade.exit484

convergence.cascade.exit484:                      ; preds = %convergence.cascade483, %schedule.23
  %convergence.cascade.result499 = phi <8 x i1> [ %572, %schedule.23 ], [ %3190, %convergence.cascade483 ]
  %3197 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  br i1 %3197, label %convergence.target.23.ready, label %scheduler.loop

convergence.target.23.ready:                      ; preds = %convergence.cascade.exit484
  %3198 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3199 = bitcast <8 x i1> %convergence.cascade.result499 to i8
  %3200 = call i8 @llvm.cttz.i8(i8 %3199, i1 false)
  %3201 = zext i8 %3200 to i32
  %3202 = select i1 %3198, i32 %3201, i32 0
  %3203 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill75, align 64
  %3204 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3205 = extractvalue { <8 x ptr>, <8 x i64> } %3203, 0
  %3206 = select <8 x i1> %convergence.cascade.result499, <8 x ptr> %3204, <8 x ptr> %3205
  %3207 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3208 = extractvalue { <8 x ptr>, <8 x i64> } %3203, 1
  %3209 = select <8 x i1> %convergence.cascade.result499, <8 x i64> %3207, <8 x i64> %3208
  %3210 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3206, 0
  %3211 = insertvalue { <8 x ptr>, <8 x i64> } %3210, <8 x i64> %3209, 1
  store volatile { <8 x ptr>, <8 x i64> } %3211, ptr %tile_snapshot.spill75, align 64
  %3212 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3213 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3214 = add <8 x i64> %3213, zeroinitializer
  %3215 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3212, 0
  %3216 = insertvalue { <8 x ptr>, <8 x i64> } %3215, <8 x i64> %3214, 1
  %3217 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3218 = extractvalue { <8 x ptr>, <8 x i64> } %3216, 1
  %3219 = extractelement <8 x ptr> %3217, i32 0
  %3220 = extractelement <8 x i64> %3218, i32 %3202
  %3221 = zext i32 %3202 to i64
  %3222 = mul i64 %3221, 8
  %3223 = sub i64 %3220, %3222
  %3224 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3225 = select i1 %3224, i64 %3223, i64 0
  %private.contiguous.address500 = getelementptr i8, ptr %3219, i64 %3225
  %private.contiguous.preserve501 = load <8 x i64>, ptr %private.contiguous.address500, align 8
  %3226 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 -4), <8 x i64> %private.contiguous.preserve501
  store <8 x i64> %3226, ptr %private.contiguous.address500, align 8
  %3227 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3228 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3229 = add <8 x i64> %3228, splat (i64 64)
  %3230 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3227, 0
  %3231 = insertvalue { <8 x ptr>, <8 x i64> } %3230, <8 x i64> %3229, 1
  %3232 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3233 = extractvalue { <8 x ptr>, <8 x i64> } %3231, 1
  %3234 = extractelement <8 x ptr> %3232, i32 0
  %3235 = extractelement <8 x i64> %3233, i32 %3202
  %3236 = zext i32 %3202 to i64
  %3237 = mul i64 %3236, 8
  %3238 = sub i64 %3235, %3237
  %3239 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3240 = select i1 %3239, i64 %3238, i64 0
  %private.contiguous.address502 = getelementptr i8, ptr %3234, i64 %3240
  %private.contiguous.preserve503 = load <8 x i64>, ptr %private.contiguous.address502, align 8
  %3241 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 -3), <8 x i64> %private.contiguous.preserve503
  store <8 x i64> %3241, ptr %private.contiguous.address502, align 8
  %3242 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3243 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3244 = add <8 x i64> %3243, splat (i64 128)
  %3245 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3242, 0
  %3246 = insertvalue { <8 x ptr>, <8 x i64> } %3245, <8 x i64> %3244, 1
  %3247 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3248 = extractvalue { <8 x ptr>, <8 x i64> } %3246, 1
  %3249 = extractelement <8 x ptr> %3247, i32 0
  %3250 = extractelement <8 x i64> %3248, i32 %3202
  %3251 = zext i32 %3202 to i64
  %3252 = mul i64 %3251, 8
  %3253 = sub i64 %3250, %3252
  %3254 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3255 = select i1 %3254, i64 %3253, i64 0
  %private.contiguous.address504 = getelementptr i8, ptr %3249, i64 %3255
  %private.contiguous.preserve505 = load <8 x i64>, ptr %private.contiguous.address504, align 8
  %3256 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 -2), <8 x i64> %private.contiguous.preserve505
  store <8 x i64> %3256, ptr %private.contiguous.address504, align 8
  %3257 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3258 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3259 = add <8 x i64> %3258, splat (i64 192)
  %3260 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3257, 0
  %3261 = insertvalue { <8 x ptr>, <8 x i64> } %3260, <8 x i64> %3259, 1
  %3262 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3263 = extractvalue { <8 x ptr>, <8 x i64> } %3261, 1
  %3264 = extractelement <8 x ptr> %3262, i32 0
  %3265 = extractelement <8 x i64> %3263, i32 %3202
  %3266 = zext i32 %3202 to i64
  %3267 = mul i64 %3266, 8
  %3268 = sub i64 %3265, %3267
  %3269 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3270 = select i1 %3269, i64 %3268, i64 0
  %private.contiguous.address506 = getelementptr i8, ptr %3264, i64 %3270
  %private.contiguous.preserve507 = load <8 x i64>, ptr %private.contiguous.address506, align 8
  %3271 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 -1), <8 x i64> %private.contiguous.preserve507
  store <8 x i64> %3271, ptr %private.contiguous.address506, align 8
  %3272 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3273 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3274 = add <8 x i64> %3273, splat (i64 256)
  %3275 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3272, 0
  %3276 = insertvalue { <8 x ptr>, <8 x i64> } %3275, <8 x i64> %3274, 1
  %3277 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3278 = extractvalue { <8 x ptr>, <8 x i64> } %3276, 1
  %3279 = extractelement <8 x ptr> %3277, i32 0
  %3280 = extractelement <8 x i64> %3278, i32 %3202
  %3281 = zext i32 %3202 to i64
  %3282 = mul i64 %3281, 8
  %3283 = sub i64 %3280, %3282
  %3284 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3285 = select i1 %3284, i64 %3283, i64 0
  %private.contiguous.address508 = getelementptr i8, ptr %3279, i64 %3285
  %private.contiguous.preserve509 = load <8 x i64>, ptr %private.contiguous.address508, align 8
  %3286 = select <8 x i1> %convergence.cascade.result499, <8 x i64> zeroinitializer, <8 x i64> %private.contiguous.preserve509
  store <8 x i64> %3286, ptr %private.contiguous.address508, align 8
  %3287 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3288 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3289 = add <8 x i64> %3288, splat (i64 320)
  %3290 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3287, 0
  %3291 = insertvalue { <8 x ptr>, <8 x i64> } %3290, <8 x i64> %3289, 1
  %3292 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3293 = extractvalue { <8 x ptr>, <8 x i64> } %3291, 1
  %3294 = extractelement <8 x ptr> %3292, i32 0
  %3295 = extractelement <8 x i64> %3293, i32 %3202
  %3296 = zext i32 %3202 to i64
  %3297 = mul i64 %3296, 8
  %3298 = sub i64 %3295, %3297
  %3299 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3300 = select i1 %3299, i64 %3298, i64 0
  %private.contiguous.address510 = getelementptr i8, ptr %3294, i64 %3300
  %private.contiguous.preserve511 = load <8 x i64>, ptr %private.contiguous.address510, align 8
  %3301 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 1), <8 x i64> %private.contiguous.preserve511
  store <8 x i64> %3301, ptr %private.contiguous.address510, align 8
  %3302 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3303 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3304 = add <8 x i64> %3303, splat (i64 384)
  %3305 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3302, 0
  %3306 = insertvalue { <8 x ptr>, <8 x i64> } %3305, <8 x i64> %3304, 1
  %3307 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3308 = extractvalue { <8 x ptr>, <8 x i64> } %3306, 1
  %3309 = extractelement <8 x ptr> %3307, i32 0
  %3310 = extractelement <8 x i64> %3308, i32 %3202
  %3311 = zext i32 %3202 to i64
  %3312 = mul i64 %3311, 8
  %3313 = sub i64 %3310, %3312
  %3314 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3315 = select i1 %3314, i64 %3313, i64 0
  %private.contiguous.address512 = getelementptr i8, ptr %3309, i64 %3315
  %private.contiguous.preserve513 = load <8 x i64>, ptr %private.contiguous.address512, align 8
  %3316 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 2), <8 x i64> %private.contiguous.preserve513
  store <8 x i64> %3316, ptr %private.contiguous.address512, align 8
  %3317 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3318 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3319 = add <8 x i64> %3318, splat (i64 448)
  %3320 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3317, 0
  %3321 = insertvalue { <8 x ptr>, <8 x i64> } %3320, <8 x i64> %3319, 1
  %3322 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3323 = extractvalue { <8 x ptr>, <8 x i64> } %3321, 1
  %3324 = extractelement <8 x ptr> %3322, i32 0
  %3325 = extractelement <8 x i64> %3323, i32 %3202
  %3326 = zext i32 %3202 to i64
  %3327 = mul i64 %3326, 8
  %3328 = sub i64 %3325, %3327
  %3329 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3330 = select i1 %3329, i64 %3328, i64 0
  %private.contiguous.address514 = getelementptr i8, ptr %3324, i64 %3330
  %private.contiguous.preserve515 = load <8 x i64>, ptr %private.contiguous.address514, align 8
  %3331 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 3), <8 x i64> %private.contiguous.preserve515
  store <8 x i64> %3331, ptr %private.contiguous.address514, align 8
  %3332 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3333 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3334 = add <8 x i64> %3333, splat (i64 512)
  %3335 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3332, 0
  %3336 = insertvalue { <8 x ptr>, <8 x i64> } %3335, <8 x i64> %3334, 1
  %3337 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3338 = extractvalue { <8 x ptr>, <8 x i64> } %3336, 1
  %3339 = extractelement <8 x ptr> %3337, i32 0
  %3340 = extractelement <8 x i64> %3338, i32 %3202
  %3341 = zext i32 %3202 to i64
  %3342 = mul i64 %3341, 8
  %3343 = sub i64 %3340, %3342
  %3344 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3345 = select i1 %3344, i64 %3343, i64 0
  %private.contiguous.address516 = getelementptr i8, ptr %3339, i64 %3345
  %private.contiguous.preserve517 = load <8 x i64>, ptr %private.contiguous.address516, align 8
  %3346 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 4), <8 x i64> %private.contiguous.preserve517
  store <8 x i64> %3346, ptr %private.contiguous.address516, align 8
  %3347 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3348 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3349 = add <8 x i64> %3348, splat (i64 576)
  %3350 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3347, 0
  %3351 = insertvalue { <8 x ptr>, <8 x i64> } %3350, <8 x i64> %3349, 1
  %3352 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3353 = extractvalue { <8 x ptr>, <8 x i64> } %3351, 1
  %3354 = extractelement <8 x ptr> %3352, i32 0
  %3355 = extractelement <8 x i64> %3353, i32 %3202
  %3356 = zext i32 %3202 to i64
  %3357 = mul i64 %3356, 8
  %3358 = sub i64 %3355, %3357
  %3359 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3360 = select i1 %3359, i64 %3358, i64 0
  %private.contiguous.address518 = getelementptr i8, ptr %3354, i64 %3360
  %private.contiguous.preserve519 = load <8 x i64>, ptr %private.contiguous.address518, align 8
  %3361 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 5), <8 x i64> %private.contiguous.preserve519
  store <8 x i64> %3361, ptr %private.contiguous.address518, align 8
  %3362 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3363 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3364 = add <8 x i64> %3363, splat (i64 640)
  %3365 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3362, 0
  %3366 = insertvalue { <8 x ptr>, <8 x i64> } %3365, <8 x i64> %3364, 1
  %3367 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3368 = extractvalue { <8 x ptr>, <8 x i64> } %3366, 1
  %3369 = extractelement <8 x ptr> %3367, i32 0
  %3370 = extractelement <8 x i64> %3368, i32 %3202
  %3371 = zext i32 %3202 to i64
  %3372 = mul i64 %3371, 8
  %3373 = sub i64 %3370, %3372
  %3374 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3375 = select i1 %3374, i64 %3373, i64 0
  %private.contiguous.address520 = getelementptr i8, ptr %3369, i64 %3375
  %private.contiguous.preserve521 = load <8 x i64>, ptr %private.contiguous.address520, align 8
  %3376 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 6), <8 x i64> %private.contiguous.preserve521
  store <8 x i64> %3376, ptr %private.contiguous.address520, align 8
  %3377 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3378 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3379 = add <8 x i64> %3378, splat (i64 704)
  %3380 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3377, 0
  %3381 = insertvalue { <8 x ptr>, <8 x i64> } %3380, <8 x i64> %3379, 1
  %3382 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3383 = extractvalue { <8 x ptr>, <8 x i64> } %3381, 1
  %3384 = extractelement <8 x ptr> %3382, i32 0
  %3385 = extractelement <8 x i64> %3383, i32 %3202
  %3386 = zext i32 %3202 to i64
  %3387 = mul i64 %3386, 8
  %3388 = sub i64 %3385, %3387
  %3389 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3390 = select i1 %3389, i64 %3388, i64 0
  %private.contiguous.address522 = getelementptr i8, ptr %3384, i64 %3390
  %private.contiguous.preserve523 = load <8 x i64>, ptr %private.contiguous.address522, align 8
  %3391 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 7), <8 x i64> %private.contiguous.preserve523
  store <8 x i64> %3391, ptr %private.contiguous.address522, align 8
  %3392 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3393 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3394 = add <8 x i64> %3393, splat (i64 768)
  %3395 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3392, 0
  %3396 = insertvalue { <8 x ptr>, <8 x i64> } %3395, <8 x i64> %3394, 1
  %3397 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3398 = extractvalue { <8 x ptr>, <8 x i64> } %3396, 1
  %3399 = extractelement <8 x ptr> %3397, i32 0
  %3400 = extractelement <8 x i64> %3398, i32 %3202
  %3401 = zext i32 %3202 to i64
  %3402 = mul i64 %3401, 8
  %3403 = sub i64 %3400, %3402
  %3404 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3405 = select i1 %3404, i64 %3403, i64 0
  %private.contiguous.address524 = getelementptr i8, ptr %3399, i64 %3405
  %private.contiguous.preserve525 = load <8 x i64>, ptr %private.contiguous.address524, align 8
  %3406 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 8), <8 x i64> %private.contiguous.preserve525
  store <8 x i64> %3406, ptr %private.contiguous.address524, align 8
  %3407 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3408 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3409 = add <8 x i64> %3408, splat (i64 832)
  %3410 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3407, 0
  %3411 = insertvalue { <8 x ptr>, <8 x i64> } %3410, <8 x i64> %3409, 1
  %3412 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3413 = extractvalue { <8 x ptr>, <8 x i64> } %3411, 1
  %3414 = extractelement <8 x ptr> %3412, i32 0
  %3415 = extractelement <8 x i64> %3413, i32 %3202
  %3416 = zext i32 %3202 to i64
  %3417 = mul i64 %3416, 8
  %3418 = sub i64 %3415, %3417
  %3419 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3420 = select i1 %3419, i64 %3418, i64 0
  %private.contiguous.address526 = getelementptr i8, ptr %3414, i64 %3420
  %private.contiguous.preserve527 = load <8 x i64>, ptr %private.contiguous.address526, align 8
  %3421 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 9), <8 x i64> %private.contiguous.preserve527
  store <8 x i64> %3421, ptr %private.contiguous.address526, align 8
  %3422 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3423 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3424 = add <8 x i64> %3423, splat (i64 896)
  %3425 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3422, 0
  %3426 = insertvalue { <8 x ptr>, <8 x i64> } %3425, <8 x i64> %3424, 1
  %3427 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3428 = extractvalue { <8 x ptr>, <8 x i64> } %3426, 1
  %3429 = extractelement <8 x ptr> %3427, i32 0
  %3430 = extractelement <8 x i64> %3428, i32 %3202
  %3431 = zext i32 %3202 to i64
  %3432 = mul i64 %3431, 8
  %3433 = sub i64 %3430, %3432
  %3434 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3435 = select i1 %3434, i64 %3433, i64 0
  %private.contiguous.address528 = getelementptr i8, ptr %3429, i64 %3435
  %private.contiguous.preserve529 = load <8 x i64>, ptr %private.contiguous.address528, align 8
  %3436 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 10), <8 x i64> %private.contiguous.preserve529
  store <8 x i64> %3436, ptr %private.contiguous.address528, align 8
  %3437 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3438 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3439 = add <8 x i64> %3438, splat (i64 960)
  %3440 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3437, 0
  %3441 = insertvalue { <8 x ptr>, <8 x i64> } %3440, <8 x i64> %3439, 1
  %3442 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3443 = extractvalue { <8 x ptr>, <8 x i64> } %3441, 1
  %3444 = extractelement <8 x ptr> %3442, i32 0
  %3445 = extractelement <8 x i64> %3443, i32 %3202
  %3446 = zext i32 %3202 to i64
  %3447 = mul i64 %3446, 8
  %3448 = sub i64 %3445, %3447
  %3449 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3450 = select i1 %3449, i64 %3448, i64 0
  %private.contiguous.address530 = getelementptr i8, ptr %3444, i64 %3450
  %private.contiguous.preserve531 = load <8 x i64>, ptr %private.contiguous.address530, align 8
  %3451 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 11), <8 x i64> %private.contiguous.preserve531
  store <8 x i64> %3451, ptr %private.contiguous.address530, align 8
  %3452 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3453 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3454 = add <8 x i64> %3453, splat (i64 1024)
  %3455 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3452, 0
  %3456 = insertvalue { <8 x ptr>, <8 x i64> } %3455, <8 x i64> %3454, 1
  %3457 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3458 = extractvalue { <8 x ptr>, <8 x i64> } %3456, 1
  %3459 = extractelement <8 x ptr> %3457, i32 0
  %3460 = extractelement <8 x i64> %3458, i32 %3202
  %3461 = zext i32 %3202 to i64
  %3462 = mul i64 %3461, 8
  %3463 = sub i64 %3460, %3462
  %3464 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3465 = select i1 %3464, i64 %3463, i64 0
  %private.contiguous.address532 = getelementptr i8, ptr %3459, i64 %3465
  %private.contiguous.preserve533 = load <8 x i64>, ptr %private.contiguous.address532, align 8
  %3466 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 12), <8 x i64> %private.contiguous.preserve533
  store <8 x i64> %3466, ptr %private.contiguous.address532, align 8
  %3467 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3468 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3469 = add <8 x i64> %3468, splat (i64 1088)
  %3470 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3467, 0
  %3471 = insertvalue { <8 x ptr>, <8 x i64> } %3470, <8 x i64> %3469, 1
  %3472 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3473 = extractvalue { <8 x ptr>, <8 x i64> } %3471, 1
  %3474 = extractelement <8 x ptr> %3472, i32 0
  %3475 = extractelement <8 x i64> %3473, i32 %3202
  %3476 = zext i32 %3202 to i64
  %3477 = mul i64 %3476, 8
  %3478 = sub i64 %3475, %3477
  %3479 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3480 = select i1 %3479, i64 %3478, i64 0
  %private.contiguous.address534 = getelementptr i8, ptr %3474, i64 %3480
  %private.contiguous.preserve535 = load <8 x i64>, ptr %private.contiguous.address534, align 8
  %3481 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 13), <8 x i64> %private.contiguous.preserve535
  store <8 x i64> %3481, ptr %private.contiguous.address534, align 8
  %3482 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3483 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3484 = add <8 x i64> %3483, splat (i64 1152)
  %3485 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3482, 0
  %3486 = insertvalue { <8 x ptr>, <8 x i64> } %3485, <8 x i64> %3484, 1
  %3487 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3488 = extractvalue { <8 x ptr>, <8 x i64> } %3486, 1
  %3489 = extractelement <8 x ptr> %3487, i32 0
  %3490 = extractelement <8 x i64> %3488, i32 %3202
  %3491 = zext i32 %3202 to i64
  %3492 = mul i64 %3491, 8
  %3493 = sub i64 %3490, %3492
  %3494 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3495 = select i1 %3494, i64 %3493, i64 0
  %private.contiguous.address536 = getelementptr i8, ptr %3489, i64 %3495
  %private.contiguous.preserve537 = load <8 x i64>, ptr %private.contiguous.address536, align 8
  %3496 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 14), <8 x i64> %private.contiguous.preserve537
  store <8 x i64> %3496, ptr %private.contiguous.address536, align 8
  %3497 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3498 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3499 = add <8 x i64> %3498, splat (i64 1216)
  %3500 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3497, 0
  %3501 = insertvalue { <8 x ptr>, <8 x i64> } %3500, <8 x i64> %3499, 1
  %3502 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3503 = extractvalue { <8 x ptr>, <8 x i64> } %3501, 1
  %3504 = extractelement <8 x ptr> %3502, i32 0
  %3505 = extractelement <8 x i64> %3503, i32 %3202
  %3506 = zext i32 %3202 to i64
  %3507 = mul i64 %3506, 8
  %3508 = sub i64 %3505, %3507
  %3509 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3510 = select i1 %3509, i64 %3508, i64 0
  %private.contiguous.address538 = getelementptr i8, ptr %3504, i64 %3510
  %private.contiguous.preserve539 = load <8 x i64>, ptr %private.contiguous.address538, align 8
  %3511 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 15), <8 x i64> %private.contiguous.preserve539
  store <8 x i64> %3511, ptr %private.contiguous.address538, align 8
  %3512 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3513 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3514 = add <8 x i64> %3513, splat (i64 1280)
  %3515 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3512, 0
  %3516 = insertvalue { <8 x ptr>, <8 x i64> } %3515, <8 x i64> %3514, 1
  %3517 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3518 = extractvalue { <8 x ptr>, <8 x i64> } %3516, 1
  %3519 = extractelement <8 x ptr> %3517, i32 0
  %3520 = extractelement <8 x i64> %3518, i32 %3202
  %3521 = zext i32 %3202 to i64
  %3522 = mul i64 %3521, 8
  %3523 = sub i64 %3520, %3522
  %3524 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3525 = select i1 %3524, i64 %3523, i64 0
  %private.contiguous.address540 = getelementptr i8, ptr %3519, i64 %3525
  %private.contiguous.preserve541 = load <8 x i64>, ptr %private.contiguous.address540, align 8
  %3526 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 16), <8 x i64> %private.contiguous.preserve541
  store <8 x i64> %3526, ptr %private.contiguous.address540, align 8
  %3527 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3528 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3529 = add <8 x i64> %3528, splat (i64 1344)
  %3530 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3527, 0
  %3531 = insertvalue { <8 x ptr>, <8 x i64> } %3530, <8 x i64> %3529, 1
  %3532 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3533 = extractvalue { <8 x ptr>, <8 x i64> } %3531, 1
  %3534 = extractelement <8 x ptr> %3532, i32 0
  %3535 = extractelement <8 x i64> %3533, i32 %3202
  %3536 = zext i32 %3202 to i64
  %3537 = mul i64 %3536, 8
  %3538 = sub i64 %3535, %3537
  %3539 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3540 = select i1 %3539, i64 %3538, i64 0
  %private.contiguous.address542 = getelementptr i8, ptr %3534, i64 %3540
  %private.contiguous.preserve543 = load <8 x i64>, ptr %private.contiguous.address542, align 8
  %3541 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 17), <8 x i64> %private.contiguous.preserve543
  store <8 x i64> %3541, ptr %private.contiguous.address542, align 8
  %3542 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3543 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3544 = add <8 x i64> %3543, splat (i64 1408)
  %3545 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3542, 0
  %3546 = insertvalue { <8 x ptr>, <8 x i64> } %3545, <8 x i64> %3544, 1
  %3547 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3548 = extractvalue { <8 x ptr>, <8 x i64> } %3546, 1
  %3549 = extractelement <8 x ptr> %3547, i32 0
  %3550 = extractelement <8 x i64> %3548, i32 %3202
  %3551 = zext i32 %3202 to i64
  %3552 = mul i64 %3551, 8
  %3553 = sub i64 %3550, %3552
  %3554 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3555 = select i1 %3554, i64 %3553, i64 0
  %private.contiguous.address544 = getelementptr i8, ptr %3549, i64 %3555
  %private.contiguous.preserve545 = load <8 x i64>, ptr %private.contiguous.address544, align 8
  %3556 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 18), <8 x i64> %private.contiguous.preserve545
  store <8 x i64> %3556, ptr %private.contiguous.address544, align 8
  %3557 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3558 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3559 = add <8 x i64> %3558, splat (i64 1472)
  %3560 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3557, 0
  %3561 = insertvalue { <8 x ptr>, <8 x i64> } %3560, <8 x i64> %3559, 1
  %3562 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3563 = extractvalue { <8 x ptr>, <8 x i64> } %3561, 1
  %3564 = extractelement <8 x ptr> %3562, i32 0
  %3565 = extractelement <8 x i64> %3563, i32 %3202
  %3566 = zext i32 %3202 to i64
  %3567 = mul i64 %3566, 8
  %3568 = sub i64 %3565, %3567
  %3569 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3570 = select i1 %3569, i64 %3568, i64 0
  %private.contiguous.address546 = getelementptr i8, ptr %3564, i64 %3570
  %private.contiguous.preserve547 = load <8 x i64>, ptr %private.contiguous.address546, align 8
  %3571 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 19), <8 x i64> %private.contiguous.preserve547
  store <8 x i64> %3571, ptr %private.contiguous.address546, align 8
  %3572 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3573 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3574 = add <8 x i64> %3573, splat (i64 1536)
  %3575 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3572, 0
  %3576 = insertvalue { <8 x ptr>, <8 x i64> } %3575, <8 x i64> %3574, 1
  %3577 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3578 = extractvalue { <8 x ptr>, <8 x i64> } %3576, 1
  %3579 = extractelement <8 x ptr> %3577, i32 0
  %3580 = extractelement <8 x i64> %3578, i32 %3202
  %3581 = zext i32 %3202 to i64
  %3582 = mul i64 %3581, 8
  %3583 = sub i64 %3580, %3582
  %3584 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3585 = select i1 %3584, i64 %3583, i64 0
  %private.contiguous.address548 = getelementptr i8, ptr %3579, i64 %3585
  %private.contiguous.preserve549 = load <8 x i64>, ptr %private.contiguous.address548, align 8
  %3586 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 20), <8 x i64> %private.contiguous.preserve549
  store <8 x i64> %3586, ptr %private.contiguous.address548, align 8
  %3587 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3588 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3589 = add <8 x i64> %3588, splat (i64 1600)
  %3590 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3587, 0
  %3591 = insertvalue { <8 x ptr>, <8 x i64> } %3590, <8 x i64> %3589, 1
  %3592 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3593 = extractvalue { <8 x ptr>, <8 x i64> } %3591, 1
  %3594 = extractelement <8 x ptr> %3592, i32 0
  %3595 = extractelement <8 x i64> %3593, i32 %3202
  %3596 = zext i32 %3202 to i64
  %3597 = mul i64 %3596, 8
  %3598 = sub i64 %3595, %3597
  %3599 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3600 = select i1 %3599, i64 %3598, i64 0
  %private.contiguous.address550 = getelementptr i8, ptr %3594, i64 %3600
  %private.contiguous.preserve551 = load <8 x i64>, ptr %private.contiguous.address550, align 8
  %3601 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 21), <8 x i64> %private.contiguous.preserve551
  store <8 x i64> %3601, ptr %private.contiguous.address550, align 8
  %3602 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3603 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3604 = add <8 x i64> %3603, splat (i64 1664)
  %3605 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3602, 0
  %3606 = insertvalue { <8 x ptr>, <8 x i64> } %3605, <8 x i64> %3604, 1
  %3607 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3608 = extractvalue { <8 x ptr>, <8 x i64> } %3606, 1
  %3609 = extractelement <8 x ptr> %3607, i32 0
  %3610 = extractelement <8 x i64> %3608, i32 %3202
  %3611 = zext i32 %3202 to i64
  %3612 = mul i64 %3611, 8
  %3613 = sub i64 %3610, %3612
  %3614 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3615 = select i1 %3614, i64 %3613, i64 0
  %private.contiguous.address552 = getelementptr i8, ptr %3609, i64 %3615
  %private.contiguous.preserve553 = load <8 x i64>, ptr %private.contiguous.address552, align 8
  %3616 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 22), <8 x i64> %private.contiguous.preserve553
  store <8 x i64> %3616, ptr %private.contiguous.address552, align 8
  %3617 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3618 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3619 = add <8 x i64> %3618, splat (i64 1728)
  %3620 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3617, 0
  %3621 = insertvalue { <8 x ptr>, <8 x i64> } %3620, <8 x i64> %3619, 1
  %3622 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3623 = extractvalue { <8 x ptr>, <8 x i64> } %3621, 1
  %3624 = extractelement <8 x ptr> %3622, i32 0
  %3625 = extractelement <8 x i64> %3623, i32 %3202
  %3626 = zext i32 %3202 to i64
  %3627 = mul i64 %3626, 8
  %3628 = sub i64 %3625, %3627
  %3629 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3630 = select i1 %3629, i64 %3628, i64 0
  %private.contiguous.address554 = getelementptr i8, ptr %3624, i64 %3630
  %private.contiguous.preserve555 = load <8 x i64>, ptr %private.contiguous.address554, align 8
  %3631 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 23), <8 x i64> %private.contiguous.preserve555
  store <8 x i64> %3631, ptr %private.contiguous.address554, align 8
  %3632 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3633 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3634 = add <8 x i64> %3633, splat (i64 1792)
  %3635 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3632, 0
  %3636 = insertvalue { <8 x ptr>, <8 x i64> } %3635, <8 x i64> %3634, 1
  %3637 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3638 = extractvalue { <8 x ptr>, <8 x i64> } %3636, 1
  %3639 = extractelement <8 x ptr> %3637, i32 0
  %3640 = extractelement <8 x i64> %3638, i32 %3202
  %3641 = zext i32 %3202 to i64
  %3642 = mul i64 %3641, 8
  %3643 = sub i64 %3640, %3642
  %3644 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3645 = select i1 %3644, i64 %3643, i64 0
  %private.contiguous.address556 = getelementptr i8, ptr %3639, i64 %3645
  %private.contiguous.preserve557 = load <8 x i64>, ptr %private.contiguous.address556, align 8
  %3646 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 24), <8 x i64> %private.contiguous.preserve557
  store <8 x i64> %3646, ptr %private.contiguous.address556, align 8
  %3647 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3648 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3649 = add <8 x i64> %3648, splat (i64 1856)
  %3650 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3647, 0
  %3651 = insertvalue { <8 x ptr>, <8 x i64> } %3650, <8 x i64> %3649, 1
  %3652 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3653 = extractvalue { <8 x ptr>, <8 x i64> } %3651, 1
  %3654 = extractelement <8 x ptr> %3652, i32 0
  %3655 = extractelement <8 x i64> %3653, i32 %3202
  %3656 = zext i32 %3202 to i64
  %3657 = mul i64 %3656, 8
  %3658 = sub i64 %3655, %3657
  %3659 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3660 = select i1 %3659, i64 %3658, i64 0
  %private.contiguous.address558 = getelementptr i8, ptr %3654, i64 %3660
  %private.contiguous.preserve559 = load <8 x i64>, ptr %private.contiguous.address558, align 8
  %3661 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 25), <8 x i64> %private.contiguous.preserve559
  store <8 x i64> %3661, ptr %private.contiguous.address558, align 8
  %3662 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3663 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3664 = add <8 x i64> %3663, splat (i64 1920)
  %3665 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3662, 0
  %3666 = insertvalue { <8 x ptr>, <8 x i64> } %3665, <8 x i64> %3664, 1
  %3667 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3668 = extractvalue { <8 x ptr>, <8 x i64> } %3666, 1
  %3669 = extractelement <8 x ptr> %3667, i32 0
  %3670 = extractelement <8 x i64> %3668, i32 %3202
  %3671 = zext i32 %3202 to i64
  %3672 = mul i64 %3671, 8
  %3673 = sub i64 %3670, %3672
  %3674 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3675 = select i1 %3674, i64 %3673, i64 0
  %private.contiguous.address560 = getelementptr i8, ptr %3669, i64 %3675
  %private.contiguous.preserve561 = load <8 x i64>, ptr %private.contiguous.address560, align 8
  %3676 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 26), <8 x i64> %private.contiguous.preserve561
  store <8 x i64> %3676, ptr %private.contiguous.address560, align 8
  %3677 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3678 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %3679 = add <8 x i64> %3678, splat (i64 1984)
  %3680 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3677, 0
  %3681 = insertvalue { <8 x ptr>, <8 x i64> } %3680, <8 x i64> %3679, 1
  %3682 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %3683 = extractvalue { <8 x ptr>, <8 x i64> } %3681, 1
  %3684 = extractelement <8 x ptr> %3682, i32 0
  %3685 = extractelement <8 x i64> %3683, i32 %3202
  %3686 = zext i32 %3202 to i64
  %3687 = mul i64 %3686, 8
  %3688 = sub i64 %3685, %3687
  %3689 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  %3690 = select i1 %3689, i64 %3688, i64 0
  %private.contiguous.address562 = getelementptr i8, ptr %3684, i64 %3690
  %private.contiguous.preserve563 = load <8 x i64>, ptr %private.contiguous.address562, align 8
  %3691 = select <8 x i1> %convergence.cascade.result499, <8 x i64> splat (i64 27), <8 x i64> %private.contiguous.preserve563
  store <8 x i64> %3691, ptr %private.contiguous.address562, align 8
  %3692 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill76, align 64
  %3693 = extractvalue { <8 x ptr>, <8 x i64> } %19, 0
  %3694 = extractvalue { <8 x ptr>, <8 x i64> } %3692, 0
  %3695 = select <8 x i1> %convergence.cascade.result499, <8 x ptr> %3693, <8 x ptr> %3694
  %3696 = extractvalue { <8 x ptr>, <8 x i64> } %19, 1
  %3697 = extractvalue { <8 x ptr>, <8 x i64> } %3692, 1
  %3698 = select <8 x i1> %convergence.cascade.result499, <8 x i64> %3696, <8 x i64> %3697
  %3699 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3695, 0
  %3700 = insertvalue { <8 x ptr>, <8 x i64> } %3699, <8 x i64> %3698, 1
  store volatile { <8 x ptr>, <8 x i64> } %3700, ptr %tile_snapshot.spill76, align 64
  %3701 = load <8 x i64>, ptr %.slot77, align 64
  %3702 = select <8 x i1> %convergence.cascade.result499, <8 x i64> zeroinitializer, <8 x i64> %3701
  store <8 x i64> %3702, ptr %.slot77, align 64
  store <8 x i1> %convergence.cascade.result499, ptr %current.mask, align 1
  %3703 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result499)
  br i1 %3703, label %schedule.24, label %scheduler.loop

varying.divergent565:                             ; preds = %schedule.24
  %3704 = load i32, ptr %current.token, align 4
  %3705 = icmp ne i32 %3704, 0
  %3706 = sub i32 %3704, 1
  %3707 = select i1 %3705, i32 %3706, i32 0
  %3708 = load i8, ptr %frame.active, align 1
  %3709 = trunc i32 %3707 to i8
  %3710 = shl i8 1, %3709
  %3711 = and i8 %3708, %3710
  %3712 = icmp ne i8 %3711, 0
  %3713 = load <8 x i32>, ptr %frame.static.id, align 32
  %3714 = extractelement <8 x i32> %3713, i32 %3707
  %3715 = icmp eq i32 %3714, 9
  %3716 = and i1 %3712, %3715
  %3717 = and i1 %3705, %3716
  %3718 = xor i1 %3717, true
  %3719 = and i1 true, %3718
  %3720 = xor i8 %3708, -1
  %3721 = icmp ne i8 %3720, 0
  %3722 = xor i1 %3721, true
  %3723 = and i1 %3719, %3722
  br i1 %3723, label %convergence.overflow.trap567, label %convergence.overflow.resume568

varying.coherent566:                              ; preds = %schedule.24
  br i1 %583, label %varying.coherent.true571, label %varying.coherent.false572

convergence.overflow.trap567:                     ; preds = %varying.divergent565
  call void @llvm.trap()
  unreachable

convergence.overflow.resume568:                   ; preds = %varying.divergent565
  %3724 = call i8 @llvm.cttz.i8(i8 %3720, i1 false)
  %3725 = zext i8 %3724 to i32
  %3726 = select i1 %3721, i32 %3725, i32 0
  %3727 = trunc i32 %3726 to i8
  %3728 = shl i8 1, %3727
  %3729 = or i8 %3708, %3728
  %3730 = select i1 %3719, i8 %3729, i8 %3708
  store i8 %3730, ptr %frame.active, align 1
  %3731 = load <8 x i32>, ptr %frame.static.id, align 32
  %3732 = extractelement <8 x i32> %3731, i32 %3726
  %3733 = select i1 %3719, i32 9, i32 %3732
  %3734 = load <8 x i32>, ptr %frame.static.id, align 32
  %3735 = insertelement <8 x i32> %3734, i32 %3733, i32 %3726
  store <8 x i32> %3735, ptr %frame.static.id, align 32
  %3736 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3737 = extractelement <8 x i32> %3736, i32 %3726
  %3738 = select i1 %3719, i32 %3704, i32 %3737
  %3739 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3740 = insertelement <8 x i32> %3739, i32 %3738, i32 %3726
  store <8 x i32> %3740, ptr %frame.parent.token, align 32
  %3741 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3726
  %3742 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3726
  %3743 = load <8 x i1>, ptr %3741, align 1
  %3744 = load <8 x i1>, ptr %3742, align 1
  %3745 = select i1 %3719, <8 x i1> %573, <8 x i1> %3743
  store <8 x i1> %3745, ptr %3741, align 1
  %3746 = select i1 %3719, <8 x i1> zeroinitializer, <8 x i1> %3744
  store <8 x i1> %3746, ptr %3742, align 1
  %3747 = add i32 %3726, 1
  %3748 = select i1 %3717, i32 %3704, i32 %3747
  %3749 = select i1 true, i32 %3748, i32 %3704
  store i32 %3749, ptr %current.token, align 4
  %3750 = load i32, ptr %current.token, align 4
  %3751 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %580)
  %3752 = load i32, ptr %ready.count, align 4
  %3753 = icmp uge i32 %3752, 8
  %3754 = and i1 %3751, %3753
  br i1 %3754, label %ready.overflow.trap569, label %ready.overflow.resume570

ready.overflow.trap569:                           ; preds = %convergence.overflow.resume568
  call void @llvm.trap()
  unreachable

ready.overflow.resume570:                         ; preds = %convergence.overflow.resume568
  %3755 = select i1 %3751, i32 %3752, i32 0
  %3756 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3755
  %3757 = load <8 x i1>, ptr %3756, align 1
  %3758 = select i1 %3751, <8 x i1> %580, <8 x i1> %3757
  store <8 x i1> %3758, ptr %3756, align 1
  %3759 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3755
  %3760 = load i32, ptr %3759, align 4
  %3761 = select i1 %3751, i32 25, i32 %3760
  store i32 %3761, ptr %3759, align 4
  %3762 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3755
  %3763 = load i32, ptr %3762, align 4
  %3764 = select i1 %3751, i32 %3750, i32 %3763
  store i32 %3764, ptr %3762, align 4
  %3765 = add i32 %3752, 1
  %3766 = select i1 %3751, i32 %3765, i32 %3752
  store i32 %3766, ptr %ready.count, align 4
  %3767 = load <8 x i1>, ptr %runnable.mask, align 1
  %3768 = or <8 x i1> %3767, %580
  store <8 x i1> %3768, ptr %runnable.mask, align 1
  store <8 x i1> %582, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true571:                         ; preds = %varying.coherent566
  store <8 x i1> %573, ptr %current.mask, align 1
  %3769 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %573)
  br i1 %3769, label %schedule.25, label %scheduler.loop

varying.coherent.false572:                        ; preds = %varying.coherent566
  store <8 x i1> %573, ptr %current.mask, align 1
  %3770 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %573)
  br i1 %3770, label %schedule.28, label %scheduler.loop

varying.divergent576:                             ; preds = %schedule.25
  %3771 = load i32, ptr %current.token, align 4
  %3772 = icmp ne i32 %3771, 0
  %3773 = sub i32 %3771, 1
  %3774 = select i1 %3772, i32 %3773, i32 0
  %3775 = load i8, ptr %frame.active, align 1
  %3776 = trunc i32 %3774 to i8
  %3777 = shl i8 1, %3776
  %3778 = and i8 %3775, %3777
  %3779 = icmp ne i8 %3778, 0
  %3780 = load <8 x i32>, ptr %frame.static.id, align 32
  %3781 = extractelement <8 x i32> %3780, i32 %3774
  %3782 = icmp eq i32 %3781, 10
  %3783 = and i1 %3779, %3782
  %3784 = and i1 %3772, %3783
  %3785 = xor i1 %3784, true
  %3786 = and i1 true, %3785
  %3787 = xor i8 %3775, -1
  %3788 = icmp ne i8 %3787, 0
  %3789 = xor i1 %3788, true
  %3790 = and i1 %3786, %3789
  br i1 %3790, label %convergence.overflow.trap578, label %convergence.overflow.resume579

varying.coherent577:                              ; preds = %schedule.25
  br i1 %625, label %varying.coherent.true582, label %varying.coherent.false583

convergence.overflow.trap578:                     ; preds = %varying.divergent576
  call void @llvm.trap()
  unreachable

convergence.overflow.resume579:                   ; preds = %varying.divergent576
  %3791 = call i8 @llvm.cttz.i8(i8 %3787, i1 false)
  %3792 = zext i8 %3791 to i32
  %3793 = select i1 %3788, i32 %3792, i32 0
  %3794 = trunc i32 %3793 to i8
  %3795 = shl i8 1, %3794
  %3796 = or i8 %3775, %3795
  %3797 = select i1 %3786, i8 %3796, i8 %3775
  store i8 %3797, ptr %frame.active, align 1
  %3798 = load <8 x i32>, ptr %frame.static.id, align 32
  %3799 = extractelement <8 x i32> %3798, i32 %3793
  %3800 = select i1 %3786, i32 10, i32 %3799
  %3801 = load <8 x i32>, ptr %frame.static.id, align 32
  %3802 = insertelement <8 x i32> %3801, i32 %3800, i32 %3793
  store <8 x i32> %3802, ptr %frame.static.id, align 32
  %3803 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3804 = extractelement <8 x i32> %3803, i32 %3793
  %3805 = select i1 %3786, i32 %3771, i32 %3804
  %3806 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3807 = insertelement <8 x i32> %3806, i32 %3805, i32 %3793
  store <8 x i32> %3807, ptr %frame.parent.token, align 32
  %3808 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3793
  %3809 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3793
  %3810 = load <8 x i1>, ptr %3808, align 1
  %3811 = load <8 x i1>, ptr %3809, align 1
  %3812 = select i1 %3786, <8 x i1> %586, <8 x i1> %3810
  store <8 x i1> %3812, ptr %3808, align 1
  %3813 = select i1 %3786, <8 x i1> zeroinitializer, <8 x i1> %3811
  store <8 x i1> %3813, ptr %3809, align 1
  %3814 = add i32 %3793, 1
  %3815 = select i1 %3784, i32 %3771, i32 %3814
  %3816 = select i1 true, i32 %3815, i32 %3771
  store i32 %3816, ptr %current.token, align 4
  %3817 = load <8 x float>, ptr %.slot80, align 32
  %3818 = select <8 x i1> %624, <8 x float> zeroinitializer, <8 x float> %3817
  store <8 x float> %3818, ptr %.slot80, align 32
  %3819 = load i32, ptr %current.token, align 4
  %3820 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %622)
  %3821 = load i32, ptr %ready.count, align 4
  %3822 = icmp uge i32 %3821, 8
  %3823 = and i1 %3820, %3822
  br i1 %3823, label %ready.overflow.trap580, label %ready.overflow.resume581

ready.overflow.trap580:                           ; preds = %convergence.overflow.resume579
  call void @llvm.trap()
  unreachable

ready.overflow.resume581:                         ; preds = %convergence.overflow.resume579
  %3824 = select i1 %3820, i32 %3821, i32 0
  %3825 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3824
  %3826 = load <8 x i1>, ptr %3825, align 1
  %3827 = select i1 %3820, <8 x i1> %622, <8 x i1> %3826
  store <8 x i1> %3827, ptr %3825, align 1
  %3828 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3824
  %3829 = load i32, ptr %3828, align 4
  %3830 = select i1 %3820, i32 26, i32 %3829
  store i32 %3830, ptr %3828, align 4
  %3831 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3824
  %3832 = load i32, ptr %3831, align 4
  %3833 = select i1 %3820, i32 %3819, i32 %3832
  store i32 %3833, ptr %3831, align 4
  %3834 = add i32 %3821, 1
  %3835 = select i1 %3820, i32 %3834, i32 %3821
  store i32 %3835, ptr %ready.count, align 4
  %3836 = load <8 x i1>, ptr %runnable.mask, align 1
  %3837 = or <8 x i1> %3836, %622
  store <8 x i1> %3837, ptr %runnable.mask, align 1
  store <8 x i1> %624, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true582:                         ; preds = %varying.coherent577
  store <8 x i1> %586, ptr %current.mask, align 1
  %3838 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %586)
  br i1 %3838, label %schedule.26, label %scheduler.loop

varying.coherent.false583:                        ; preds = %varying.coherent577
  %3839 = load <8 x float>, ptr %.slot80, align 32
  %3840 = select <8 x i1> %586, <8 x float> zeroinitializer, <8 x float> %3839
  store <8 x float> %3840, ptr %.slot80, align 32
  store <8 x i1> %586, ptr %current.mask, align 1
  %3841 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %586)
  br i1 %3841, label %schedule.27, label %scheduler.loop

convergence.cascade586:                           ; preds = %convergence.cascade586, %schedule.27
  %convergence.cascade.flow590 = phi <8 x i1> [ %647, %schedule.27 ], [ %3884, %convergence.cascade586 ]
  %convergence.cascade.depth591 = phi i32 [ 0, %schedule.27 ], [ %3885, %convergence.cascade586 ]
  %3842 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow590)
  %3843 = load i32, ptr %current.token, align 4
  %3844 = icmp ne i32 %3843, 0
  %3845 = and i1 %3842, %3844
  %3846 = sub i32 %3843, 1
  %3847 = select i1 %3845, i32 %3846, i32 0
  %3848 = load i8, ptr %frame.active, align 1
  %3849 = trunc i32 %3847 to i8
  %3850 = shl i8 1, %3849
  %3851 = and i8 %3848, %3850
  %3852 = icmp ne i8 %3851, 0
  %3853 = load <8 x i32>, ptr %frame.static.id, align 32
  %3854 = extractelement <8 x i32> %3853, i32 %3847
  %convergence.target.pointer592 = getelementptr inbounds [20 x i32], ptr @convergence.targets, i32 0, i32 %3854
  %convergence.dynamic.target593 = load i32, ptr %convergence.target.pointer592, align 4
  %3855 = icmp eq i32 %convergence.dynamic.target593, 27
  %3856 = and i1 %3852, %3855
  %3857 = and i1 %3845, %3856
  %3858 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3847
  %3859 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3847
  %3860 = load <8 x i1>, ptr %3858, align 1
  %3861 = load <8 x i1>, ptr %3859, align 1
  %3862 = or <8 x i1> %3861, %convergence.cascade.flow590
  %3863 = load <8 x i1>, ptr %live.mask, align 1
  %3864 = and <8 x i1> %3860, %3863
  %3865 = icmp eq <8 x i1> %3862, %3864
  %3866 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3865)
  %3867 = and i1 %3857, %3866
  %3868 = select i1 %3867, <8 x i1> zeroinitializer, <8 x i1> %3862
  %3869 = select i1 %3857, <8 x i1> %3868, <8 x i1> %3861
  store <8 x i1> %3869, ptr %3859, align 1
  %3870 = select i1 %3867, <8 x i1> zeroinitializer, <8 x i1> %3860
  store <8 x i1> %3870, ptr %3858, align 1
  %3871 = trunc i32 %3847 to i8
  %3872 = shl i8 1, %3871
  %3873 = xor i8 %3872, -1
  %3874 = and i8 %3848, %3873
  %3875 = select i1 %3867, i8 %3874, i8 %3848
  store i8 %3875, ptr %frame.active, align 1
  %.splatinsert594 = insertelement <8 x i1> poison, i1 %3857, i64 0
  %.splat595 = shufflevector <8 x i1> %.splatinsert594, <8 x i1> poison, <8 x i32> zeroinitializer
  %3876 = and <8 x i1> %convergence.cascade.flow590, %.splat595
  %3877 = load <8 x i1>, ptr %runnable.mask, align 1
  %3878 = xor <8 x i1> %3876, splat (i1 true)
  %3879 = and <8 x i1> %3877, %3878
  store <8 x i1> %3879, ptr %runnable.mask, align 1
  %.splatinsert596 = insertelement <8 x i1> poison, i1 %3867, i64 0
  %.splat597 = shufflevector <8 x i1> %.splatinsert596, <8 x i1> poison, <8 x i32> zeroinitializer
  %3880 = select <8 x i1> %.splat597, <8 x i1> %3862, <8 x i1> zeroinitializer
  %3881 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3882 = extractelement <8 x i32> %3881, i32 %3847
  %3883 = select i1 %3867, i32 %3882, i32 %3843
  store i32 %3883, ptr %current.token, align 4
  %.splatinsert598 = insertelement <8 x i1> poison, i1 %3857, i64 0
  %.splat599 = shufflevector <8 x i1> %.splatinsert598, <8 x i1> poison, <8 x i32> zeroinitializer
  %3884 = select <8 x i1> %.splat599, <8 x i1> %3880, <8 x i1> %convergence.cascade.flow590
  %3885 = add i32 %convergence.cascade.depth591, 1
  %3886 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3884)
  %3887 = icmp ult i32 %3885, 8
  %3888 = and i1 %3886, %3887
  %3889 = and i1 %3857, %3888
  %convergence.parent.token600 = load i32, ptr %current.token, align 4
  %convergence.parent.present601 = icmp ne i32 %convergence.parent.token600, 0
  %3890 = and i1 %3889, %convergence.parent.present601
  br i1 %3890, label %convergence.cascade586, label %convergence.cascade.exit587

convergence.cascade.exit587:                      ; preds = %convergence.cascade586, %schedule.27
  %convergence.cascade.result602 = phi <8 x i1> [ %647, %schedule.27 ], [ %3884, %convergence.cascade586 ]
  %3891 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result602)
  br i1 %3891, label %convergence.target.27.ready, label %scheduler.loop

convergence.target.27.ready:                      ; preds = %convergence.cascade.exit587
  %3892 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result602)
  %3893 = bitcast <8 x i1> %convergence.cascade.result602 to i8
  %3894 = call i8 @llvm.cttz.i8(i8 %3893, i1 false)
  %3895 = zext i8 %3894 to i32
  %3896 = select i1 %3892, i32 %3895, i32 0
  %.spill.load603 = load float, ptr %.spill49, align 4
  %.splatinsert604 = insertelement <8 x float> poison, float %.spill.load603, i64 0
  %.splat605 = shufflevector <8 x float> %.splatinsert604, <8 x float> poison, <8 x i32> zeroinitializer
  %.state606 = load <8 x float>, ptr %.slot80, align 32
  %.spill.load607 = load volatile <8 x i1>, ptr %.spill78, align 1
  %3897 = select <8 x i1> %.spill.load607, <8 x float> %.state606, <8 x float> %.splat605
  %tile_snapshot.spill.load608 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill76, align 64
  %3898 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load608, 0
  %3899 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load608, 1
  %.state609 = load <8 x i64>, ptr %.slot77, align 64
  %3900 = mul <8 x i64> %.state609, splat (i64 32)
  %3901 = add <8 x i64> %3899, %3900
  %3902 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3898, 0
  %3903 = insertvalue { <8 x ptr>, <8 x i64> } %3902, <8 x i64> %3901, 1
  %3904 = extractvalue { <8 x ptr>, <8 x i64> } %3903, 0
  %3905 = extractvalue { <8 x ptr>, <8 x i64> } %3903, 1
  %3906 = getelementptr i8, <8 x ptr> %3904, <8 x i64> %3905
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %3897, <8 x ptr> %3906, i32 1, <8 x i1> %convergence.cascade.result602)
  %.state610 = load <8 x i64>, ptr %.slot77, align 64
  %3907 = add <8 x i64> %.state610, splat (i64 1)
  %3908 = load <8 x i64>, ptr %.slot77, align 64
  %3909 = select <8 x i1> %convergence.cascade.result602, <8 x i64> %3907, <8 x i64> %3908
  store <8 x i64> %3909, ptr %.slot77, align 64
  store <8 x i1> %convergence.cascade.result602, ptr %current.mask, align 1
  %3910 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result602)
  br i1 %3910, label %schedule.24, label %scheduler.loop

convergence.cascade611:                           ; preds = %convergence.cascade611, %schedule.28
  %convergence.cascade.flow615 = phi <8 x i1> [ %648, %schedule.28 ], [ %3953, %convergence.cascade611 ]
  %convergence.cascade.depth616 = phi i32 [ 0, %schedule.28 ], [ %3954, %convergence.cascade611 ]
  %3911 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow615)
  %3912 = load i32, ptr %current.token, align 4
  %3913 = icmp ne i32 %3912, 0
  %3914 = and i1 %3911, %3913
  %3915 = sub i32 %3912, 1
  %3916 = select i1 %3914, i32 %3915, i32 0
  %3917 = load i8, ptr %frame.active, align 1
  %3918 = trunc i32 %3916 to i8
  %3919 = shl i8 1, %3918
  %3920 = and i8 %3917, %3919
  %3921 = icmp ne i8 %3920, 0
  %3922 = load <8 x i32>, ptr %frame.static.id, align 32
  %3923 = extractelement <8 x i32> %3922, i32 %3916
  %convergence.target.pointer617 = getelementptr inbounds [20 x i32], ptr @convergence.targets, i32 0, i32 %3923
  %convergence.dynamic.target618 = load i32, ptr %convergence.target.pointer617, align 4
  %3924 = icmp eq i32 %convergence.dynamic.target618, 28
  %3925 = and i1 %3921, %3924
  %3926 = and i1 %3914, %3925
  %3927 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3916
  %3928 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3916
  %3929 = load <8 x i1>, ptr %3927, align 1
  %3930 = load <8 x i1>, ptr %3928, align 1
  %3931 = or <8 x i1> %3930, %convergence.cascade.flow615
  %3932 = load <8 x i1>, ptr %live.mask, align 1
  %3933 = and <8 x i1> %3929, %3932
  %3934 = icmp eq <8 x i1> %3931, %3933
  %3935 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3934)
  %3936 = and i1 %3926, %3935
  %3937 = select i1 %3936, <8 x i1> zeroinitializer, <8 x i1> %3931
  %3938 = select i1 %3926, <8 x i1> %3937, <8 x i1> %3930
  store <8 x i1> %3938, ptr %3928, align 1
  %3939 = select i1 %3936, <8 x i1> zeroinitializer, <8 x i1> %3929
  store <8 x i1> %3939, ptr %3927, align 1
  %3940 = trunc i32 %3916 to i8
  %3941 = shl i8 1, %3940
  %3942 = xor i8 %3941, -1
  %3943 = and i8 %3917, %3942
  %3944 = select i1 %3936, i8 %3943, i8 %3917
  store i8 %3944, ptr %frame.active, align 1
  %.splatinsert619 = insertelement <8 x i1> poison, i1 %3926, i64 0
  %.splat620 = shufflevector <8 x i1> %.splatinsert619, <8 x i1> poison, <8 x i32> zeroinitializer
  %3945 = and <8 x i1> %convergence.cascade.flow615, %.splat620
  %3946 = load <8 x i1>, ptr %runnable.mask, align 1
  %3947 = xor <8 x i1> %3945, splat (i1 true)
  %3948 = and <8 x i1> %3946, %3947
  store <8 x i1> %3948, ptr %runnable.mask, align 1
  %.splatinsert621 = insertelement <8 x i1> poison, i1 %3936, i64 0
  %.splat622 = shufflevector <8 x i1> %.splatinsert621, <8 x i1> poison, <8 x i32> zeroinitializer
  %3949 = select <8 x i1> %.splat622, <8 x i1> %3931, <8 x i1> zeroinitializer
  %3950 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3951 = extractelement <8 x i32> %3950, i32 %3916
  %3952 = select i1 %3936, i32 %3951, i32 %3912
  store i32 %3952, ptr %current.token, align 4
  %.splatinsert623 = insertelement <8 x i1> poison, i1 %3926, i64 0
  %.splat624 = shufflevector <8 x i1> %.splatinsert623, <8 x i1> poison, <8 x i32> zeroinitializer
  %3953 = select <8 x i1> %.splat624, <8 x i1> %3949, <8 x i1> %convergence.cascade.flow615
  %3954 = add i32 %convergence.cascade.depth616, 1
  %3955 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3953)
  %3956 = icmp ult i32 %3954, 8
  %3957 = and i1 %3955, %3956
  %3958 = and i1 %3926, %3957
  %convergence.parent.token625 = load i32, ptr %current.token, align 4
  %convergence.parent.present626 = icmp ne i32 %convergence.parent.token625, 0
  %3959 = and i1 %3958, %convergence.parent.present626
  br i1 %3959, label %convergence.cascade611, label %convergence.cascade.exit612

convergence.cascade.exit612:                      ; preds = %convergence.cascade611, %schedule.28
  %convergence.cascade.result627 = phi <8 x i1> [ %648, %schedule.28 ], [ %3953, %convergence.cascade611 ]
  %3960 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result627)
  br i1 %3960, label %convergence.target.28.ready, label %scheduler.loop

convergence.target.28.ready:                      ; preds = %convergence.cascade.exit612
  %3961 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result627)
  %3962 = bitcast <8 x i1> %convergence.cascade.result627 to i8
  %3963 = call i8 @llvm.cttz.i8(i8 %3962, i1 false)
  %3964 = zext i8 %3963 to i32
  %3965 = select i1 %3961, i32 %3964, i32 0
  %3966 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill81, align 64
  %3967 = extractvalue { <8 x ptr>, <8 x i64> } %21, 0
  %3968 = extractvalue { <8 x ptr>, <8 x i64> } %3966, 0
  %3969 = select <8 x i1> %convergence.cascade.result627, <8 x ptr> %3967, <8 x ptr> %3968
  %3970 = extractvalue { <8 x ptr>, <8 x i64> } %21, 1
  %3971 = extractvalue { <8 x ptr>, <8 x i64> } %3966, 1
  %3972 = select <8 x i1> %convergence.cascade.result627, <8 x i64> %3970, <8 x i64> %3971
  %3973 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3969, 0
  %3974 = insertvalue { <8 x ptr>, <8 x i64> } %3973, <8 x i64> %3972, 1
  store volatile { <8 x ptr>, <8 x i64> } %3974, ptr %tile_snapshot.spill81, align 64
  %3975 = load <8 x i64>, ptr %.slot82, align 64
  %3976 = select <8 x i1> %convergence.cascade.result627, <8 x i64> zeroinitializer, <8 x i64> %3975
  store <8 x i64> %3976, ptr %.slot82, align 64
  store <8 x i1> %convergence.cascade.result627, ptr %current.mask, align 1
  %3977 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result627)
  br i1 %3977, label %schedule.29, label %scheduler.loop

varying.divergent629:                             ; preds = %schedule.29
  %3978 = load i32, ptr %current.token, align 4
  %3979 = icmp ne i32 %3978, 0
  %3980 = sub i32 %3978, 1
  %3981 = select i1 %3979, i32 %3980, i32 0
  %3982 = load i8, ptr %frame.active, align 1
  %3983 = trunc i32 %3981 to i8
  %3984 = shl i8 1, %3983
  %3985 = and i8 %3982, %3984
  %3986 = icmp ne i8 %3985, 0
  %3987 = load <8 x i32>, ptr %frame.static.id, align 32
  %3988 = extractelement <8 x i32> %3987, i32 %3981
  %3989 = icmp eq i32 %3988, 11
  %3990 = and i1 %3986, %3989
  %3991 = and i1 %3979, %3990
  %3992 = xor i1 %3991, true
  %3993 = and i1 true, %3992
  %3994 = xor i8 %3982, -1
  %3995 = icmp ne i8 %3994, 0
  %3996 = xor i1 %3995, true
  %3997 = and i1 %3993, %3996
  br i1 %3997, label %convergence.overflow.trap631, label %convergence.overflow.resume632

varying.coherent630:                              ; preds = %schedule.29
  br i1 %659, label %varying.coherent.true635, label %varying.coherent.false636

convergence.overflow.trap631:                     ; preds = %varying.divergent629
  call void @llvm.trap()
  unreachable

convergence.overflow.resume632:                   ; preds = %varying.divergent629
  %3998 = call i8 @llvm.cttz.i8(i8 %3994, i1 false)
  %3999 = zext i8 %3998 to i32
  %4000 = select i1 %3995, i32 %3999, i32 0
  %4001 = trunc i32 %4000 to i8
  %4002 = shl i8 1, %4001
  %4003 = or i8 %3982, %4002
  %4004 = select i1 %3993, i8 %4003, i8 %3982
  store i8 %4004, ptr %frame.active, align 1
  %4005 = load <8 x i32>, ptr %frame.static.id, align 32
  %4006 = extractelement <8 x i32> %4005, i32 %4000
  %4007 = select i1 %3993, i32 11, i32 %4006
  %4008 = load <8 x i32>, ptr %frame.static.id, align 32
  %4009 = insertelement <8 x i32> %4008, i32 %4007, i32 %4000
  store <8 x i32> %4009, ptr %frame.static.id, align 32
  %4010 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4011 = extractelement <8 x i32> %4010, i32 %4000
  %4012 = select i1 %3993, i32 %3978, i32 %4011
  %4013 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4014 = insertelement <8 x i32> %4013, i32 %4012, i32 %4000
  store <8 x i32> %4014, ptr %frame.parent.token, align 32
  %4015 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4000
  %4016 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4000
  %4017 = load <8 x i1>, ptr %4015, align 1
  %4018 = load <8 x i1>, ptr %4016, align 1
  %4019 = select i1 %3993, <8 x i1> %649, <8 x i1> %4017
  store <8 x i1> %4019, ptr %4015, align 1
  %4020 = select i1 %3993, <8 x i1> zeroinitializer, <8 x i1> %4018
  store <8 x i1> %4020, ptr %4016, align 1
  %4021 = add i32 %4000, 1
  %4022 = select i1 %3991, i32 %3978, i32 %4021
  %4023 = select i1 true, i32 %4022, i32 %3978
  store i32 %4023, ptr %current.token, align 4
  %4024 = load i32, ptr %current.token, align 4
  %4025 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %656)
  %4026 = load i32, ptr %ready.count, align 4
  %4027 = icmp uge i32 %4026, 8
  %4028 = and i1 %4025, %4027
  br i1 %4028, label %ready.overflow.trap633, label %ready.overflow.resume634

ready.overflow.trap633:                           ; preds = %convergence.overflow.resume632
  call void @llvm.trap()
  unreachable

ready.overflow.resume634:                         ; preds = %convergence.overflow.resume632
  %4029 = select i1 %4025, i32 %4026, i32 0
  %4030 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4029
  %4031 = load <8 x i1>, ptr %4030, align 1
  %4032 = select i1 %4025, <8 x i1> %656, <8 x i1> %4031
  store <8 x i1> %4032, ptr %4030, align 1
  %4033 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4029
  %4034 = load i32, ptr %4033, align 4
  %4035 = select i1 %4025, i32 30, i32 %4034
  store i32 %4035, ptr %4033, align 4
  %4036 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4029
  %4037 = load i32, ptr %4036, align 4
  %4038 = select i1 %4025, i32 %4024, i32 %4037
  store i32 %4038, ptr %4036, align 4
  %4039 = add i32 %4026, 1
  %4040 = select i1 %4025, i32 %4039, i32 %4026
  store i32 %4040, ptr %ready.count, align 4
  %4041 = load <8 x i1>, ptr %runnable.mask, align 1
  %4042 = or <8 x i1> %4041, %656
  store <8 x i1> %4042, ptr %runnable.mask, align 1
  store <8 x i1> %658, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true635:                         ; preds = %varying.coherent630
  store <8 x i1> %649, ptr %current.mask, align 1
  %4043 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %649)
  br i1 %4043, label %schedule.30, label %scheduler.loop

varying.coherent.false636:                        ; preds = %varying.coherent630
  store <8 x i1> %649, ptr %current.mask, align 1
  %4044 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %649)
  br i1 %4044, label %schedule.31, label %scheduler.loop

convergence.cascade644:                           ; preds = %convergence.cascade644, %schedule.31
  %convergence.cascade.flow648 = phi <8 x i1> [ %711, %schedule.31 ], [ %4087, %convergence.cascade644 ]
  %convergence.cascade.depth649 = phi i32 [ 0, %schedule.31 ], [ %4088, %convergence.cascade644 ]
  %4045 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow648)
  %4046 = load i32, ptr %current.token, align 4
  %4047 = icmp ne i32 %4046, 0
  %4048 = and i1 %4045, %4047
  %4049 = sub i32 %4046, 1
  %4050 = select i1 %4048, i32 %4049, i32 0
  %4051 = load i8, ptr %frame.active, align 1
  %4052 = trunc i32 %4050 to i8
  %4053 = shl i8 1, %4052
  %4054 = and i8 %4051, %4053
  %4055 = icmp ne i8 %4054, 0
  %4056 = load <8 x i32>, ptr %frame.static.id, align 32
  %4057 = extractelement <8 x i32> %4056, i32 %4050
  %convergence.target.pointer650 = getelementptr inbounds [20 x i32], ptr @convergence.targets, i32 0, i32 %4057
  %convergence.dynamic.target651 = load i32, ptr %convergence.target.pointer650, align 4
  %4058 = icmp eq i32 %convergence.dynamic.target651, 31
  %4059 = and i1 %4055, %4058
  %4060 = and i1 %4048, %4059
  %4061 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4050
  %4062 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4050
  %4063 = load <8 x i1>, ptr %4061, align 1
  %4064 = load <8 x i1>, ptr %4062, align 1
  %4065 = or <8 x i1> %4064, %convergence.cascade.flow648
  %4066 = load <8 x i1>, ptr %live.mask, align 1
  %4067 = and <8 x i1> %4063, %4066
  %4068 = icmp eq <8 x i1> %4065, %4067
  %4069 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4068)
  %4070 = and i1 %4060, %4069
  %4071 = select i1 %4070, <8 x i1> zeroinitializer, <8 x i1> %4065
  %4072 = select i1 %4060, <8 x i1> %4071, <8 x i1> %4064
  store <8 x i1> %4072, ptr %4062, align 1
  %4073 = select i1 %4070, <8 x i1> zeroinitializer, <8 x i1> %4063
  store <8 x i1> %4073, ptr %4061, align 1
  %4074 = trunc i32 %4050 to i8
  %4075 = shl i8 1, %4074
  %4076 = xor i8 %4075, -1
  %4077 = and i8 %4051, %4076
  %4078 = select i1 %4070, i8 %4077, i8 %4051
  store i8 %4078, ptr %frame.active, align 1
  %.splatinsert652 = insertelement <8 x i1> poison, i1 %4060, i64 0
  %.splat653 = shufflevector <8 x i1> %.splatinsert652, <8 x i1> poison, <8 x i32> zeroinitializer
  %4079 = and <8 x i1> %convergence.cascade.flow648, %.splat653
  %4080 = load <8 x i1>, ptr %runnable.mask, align 1
  %4081 = xor <8 x i1> %4079, splat (i1 true)
  %4082 = and <8 x i1> %4080, %4081
  store <8 x i1> %4082, ptr %runnable.mask, align 1
  %.splatinsert654 = insertelement <8 x i1> poison, i1 %4070, i64 0
  %.splat655 = shufflevector <8 x i1> %.splatinsert654, <8 x i1> poison, <8 x i32> zeroinitializer
  %4083 = select <8 x i1> %.splat655, <8 x i1> %4065, <8 x i1> zeroinitializer
  %4084 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4085 = extractelement <8 x i32> %4084, i32 %4050
  %4086 = select i1 %4070, i32 %4085, i32 %4046
  store i32 %4086, ptr %current.token, align 4
  %.splatinsert656 = insertelement <8 x i1> poison, i1 %4060, i64 0
  %.splat657 = shufflevector <8 x i1> %.splatinsert656, <8 x i1> poison, <8 x i32> zeroinitializer
  %4087 = select <8 x i1> %.splat657, <8 x i1> %4083, <8 x i1> %convergence.cascade.flow648
  %4088 = add i32 %convergence.cascade.depth649, 1
  %4089 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4087)
  %4090 = icmp ult i32 %4088, 8
  %4091 = and i1 %4089, %4090
  %4092 = and i1 %4060, %4091
  %convergence.parent.token658 = load i32, ptr %current.token, align 4
  %convergence.parent.present659 = icmp ne i32 %convergence.parent.token658, 0
  %4093 = and i1 %4092, %convergence.parent.present659
  br i1 %4093, label %convergence.cascade644, label %convergence.cascade.exit645

convergence.cascade.exit645:                      ; preds = %convergence.cascade644, %schedule.31
  %convergence.cascade.result660 = phi <8 x i1> [ %711, %schedule.31 ], [ %4087, %convergence.cascade644 ]
  %4094 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  br i1 %4094, label %convergence.target.31.ready, label %scheduler.loop

convergence.target.31.ready:                      ; preds = %convergence.cascade.exit645
  %4095 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4096 = bitcast <8 x i1> %convergence.cascade.result660 to i8
  %4097 = call i8 @llvm.cttz.i8(i8 %4096, i1 false)
  %4098 = zext i8 %4097 to i32
  %4099 = select i1 %4095, i32 %4098, i32 0
  %4100 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill83, align 64
  %4101 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4102 = extractvalue { <8 x ptr>, <8 x i64> } %4100, 0
  %4103 = select <8 x i1> %convergence.cascade.result660, <8 x ptr> %4101, <8 x ptr> %4102
  %4104 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4105 = extractvalue { <8 x ptr>, <8 x i64> } %4100, 1
  %4106 = select <8 x i1> %convergence.cascade.result660, <8 x i64> %4104, <8 x i64> %4105
  %4107 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4103, 0
  %4108 = insertvalue { <8 x ptr>, <8 x i64> } %4107, <8 x i64> %4106, 1
  store volatile { <8 x ptr>, <8 x i64> } %4108, ptr %tile_snapshot.spill83, align 64
  %4109 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4110 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4111 = add <8 x i64> %4110, zeroinitializer
  %4112 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4109, 0
  %4113 = insertvalue { <8 x ptr>, <8 x i64> } %4112, <8 x i64> %4111, 1
  %4114 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4115 = extractvalue { <8 x ptr>, <8 x i64> } %4113, 1
  %4116 = extractelement <8 x ptr> %4114, i32 0
  %4117 = extractelement <8 x i64> %4115, i32 %4099
  %4118 = zext i32 %4099 to i64
  %4119 = mul i64 %4118, 8
  %4120 = sub i64 %4117, %4119
  %4121 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4122 = select i1 %4121, i64 %4120, i64 0
  %private.contiguous.address661 = getelementptr i8, ptr %4116, i64 %4122
  %private.contiguous.preserve662 = load <8 x i64>, ptr %private.contiguous.address661, align 8
  %4123 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 -8), <8 x i64> %private.contiguous.preserve662
  store <8 x i64> %4123, ptr %private.contiguous.address661, align 8
  %4124 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4125 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4126 = add <8 x i64> %4125, splat (i64 64)
  %4127 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4124, 0
  %4128 = insertvalue { <8 x ptr>, <8 x i64> } %4127, <8 x i64> %4126, 1
  %4129 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4130 = extractvalue { <8 x ptr>, <8 x i64> } %4128, 1
  %4131 = extractelement <8 x ptr> %4129, i32 0
  %4132 = extractelement <8 x i64> %4130, i32 %4099
  %4133 = zext i32 %4099 to i64
  %4134 = mul i64 %4133, 8
  %4135 = sub i64 %4132, %4134
  %4136 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4137 = select i1 %4136, i64 %4135, i64 0
  %private.contiguous.address663 = getelementptr i8, ptr %4131, i64 %4137
  %private.contiguous.preserve664 = load <8 x i64>, ptr %private.contiguous.address663, align 8
  %4138 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 -7), <8 x i64> %private.contiguous.preserve664
  store <8 x i64> %4138, ptr %private.contiguous.address663, align 8
  %4139 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4140 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4141 = add <8 x i64> %4140, splat (i64 128)
  %4142 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4139, 0
  %4143 = insertvalue { <8 x ptr>, <8 x i64> } %4142, <8 x i64> %4141, 1
  %4144 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4145 = extractvalue { <8 x ptr>, <8 x i64> } %4143, 1
  %4146 = extractelement <8 x ptr> %4144, i32 0
  %4147 = extractelement <8 x i64> %4145, i32 %4099
  %4148 = zext i32 %4099 to i64
  %4149 = mul i64 %4148, 8
  %4150 = sub i64 %4147, %4149
  %4151 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4152 = select i1 %4151, i64 %4150, i64 0
  %private.contiguous.address665 = getelementptr i8, ptr %4146, i64 %4152
  %private.contiguous.preserve666 = load <8 x i64>, ptr %private.contiguous.address665, align 8
  %4153 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 -6), <8 x i64> %private.contiguous.preserve666
  store <8 x i64> %4153, ptr %private.contiguous.address665, align 8
  %4154 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4155 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4156 = add <8 x i64> %4155, splat (i64 192)
  %4157 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4154, 0
  %4158 = insertvalue { <8 x ptr>, <8 x i64> } %4157, <8 x i64> %4156, 1
  %4159 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4160 = extractvalue { <8 x ptr>, <8 x i64> } %4158, 1
  %4161 = extractelement <8 x ptr> %4159, i32 0
  %4162 = extractelement <8 x i64> %4160, i32 %4099
  %4163 = zext i32 %4099 to i64
  %4164 = mul i64 %4163, 8
  %4165 = sub i64 %4162, %4164
  %4166 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4167 = select i1 %4166, i64 %4165, i64 0
  %private.contiguous.address667 = getelementptr i8, ptr %4161, i64 %4167
  %private.contiguous.preserve668 = load <8 x i64>, ptr %private.contiguous.address667, align 8
  %4168 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 -5), <8 x i64> %private.contiguous.preserve668
  store <8 x i64> %4168, ptr %private.contiguous.address667, align 8
  %4169 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4170 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4171 = add <8 x i64> %4170, splat (i64 256)
  %4172 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4169, 0
  %4173 = insertvalue { <8 x ptr>, <8 x i64> } %4172, <8 x i64> %4171, 1
  %4174 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4175 = extractvalue { <8 x ptr>, <8 x i64> } %4173, 1
  %4176 = extractelement <8 x ptr> %4174, i32 0
  %4177 = extractelement <8 x i64> %4175, i32 %4099
  %4178 = zext i32 %4099 to i64
  %4179 = mul i64 %4178, 8
  %4180 = sub i64 %4177, %4179
  %4181 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4182 = select i1 %4181, i64 %4180, i64 0
  %private.contiguous.address669 = getelementptr i8, ptr %4176, i64 %4182
  %private.contiguous.preserve670 = load <8 x i64>, ptr %private.contiguous.address669, align 8
  %4183 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 -4), <8 x i64> %private.contiguous.preserve670
  store <8 x i64> %4183, ptr %private.contiguous.address669, align 8
  %4184 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4185 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4186 = add <8 x i64> %4185, splat (i64 320)
  %4187 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4184, 0
  %4188 = insertvalue { <8 x ptr>, <8 x i64> } %4187, <8 x i64> %4186, 1
  %4189 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4190 = extractvalue { <8 x ptr>, <8 x i64> } %4188, 1
  %4191 = extractelement <8 x ptr> %4189, i32 0
  %4192 = extractelement <8 x i64> %4190, i32 %4099
  %4193 = zext i32 %4099 to i64
  %4194 = mul i64 %4193, 8
  %4195 = sub i64 %4192, %4194
  %4196 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4197 = select i1 %4196, i64 %4195, i64 0
  %private.contiguous.address671 = getelementptr i8, ptr %4191, i64 %4197
  %private.contiguous.preserve672 = load <8 x i64>, ptr %private.contiguous.address671, align 8
  %4198 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 -3), <8 x i64> %private.contiguous.preserve672
  store <8 x i64> %4198, ptr %private.contiguous.address671, align 8
  %4199 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4200 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4201 = add <8 x i64> %4200, splat (i64 384)
  %4202 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4199, 0
  %4203 = insertvalue { <8 x ptr>, <8 x i64> } %4202, <8 x i64> %4201, 1
  %4204 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4205 = extractvalue { <8 x ptr>, <8 x i64> } %4203, 1
  %4206 = extractelement <8 x ptr> %4204, i32 0
  %4207 = extractelement <8 x i64> %4205, i32 %4099
  %4208 = zext i32 %4099 to i64
  %4209 = mul i64 %4208, 8
  %4210 = sub i64 %4207, %4209
  %4211 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4212 = select i1 %4211, i64 %4210, i64 0
  %private.contiguous.address673 = getelementptr i8, ptr %4206, i64 %4212
  %private.contiguous.preserve674 = load <8 x i64>, ptr %private.contiguous.address673, align 8
  %4213 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 -2), <8 x i64> %private.contiguous.preserve674
  store <8 x i64> %4213, ptr %private.contiguous.address673, align 8
  %4214 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4215 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4216 = add <8 x i64> %4215, splat (i64 448)
  %4217 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4214, 0
  %4218 = insertvalue { <8 x ptr>, <8 x i64> } %4217, <8 x i64> %4216, 1
  %4219 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4220 = extractvalue { <8 x ptr>, <8 x i64> } %4218, 1
  %4221 = extractelement <8 x ptr> %4219, i32 0
  %4222 = extractelement <8 x i64> %4220, i32 %4099
  %4223 = zext i32 %4099 to i64
  %4224 = mul i64 %4223, 8
  %4225 = sub i64 %4222, %4224
  %4226 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4227 = select i1 %4226, i64 %4225, i64 0
  %private.contiguous.address675 = getelementptr i8, ptr %4221, i64 %4227
  %private.contiguous.preserve676 = load <8 x i64>, ptr %private.contiguous.address675, align 8
  %4228 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 -1), <8 x i64> %private.contiguous.preserve676
  store <8 x i64> %4228, ptr %private.contiguous.address675, align 8
  %4229 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4230 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4231 = add <8 x i64> %4230, splat (i64 512)
  %4232 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4229, 0
  %4233 = insertvalue { <8 x ptr>, <8 x i64> } %4232, <8 x i64> %4231, 1
  %4234 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4235 = extractvalue { <8 x ptr>, <8 x i64> } %4233, 1
  %4236 = extractelement <8 x ptr> %4234, i32 0
  %4237 = extractelement <8 x i64> %4235, i32 %4099
  %4238 = zext i32 %4099 to i64
  %4239 = mul i64 %4238, 8
  %4240 = sub i64 %4237, %4239
  %4241 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4242 = select i1 %4241, i64 %4240, i64 0
  %private.contiguous.address677 = getelementptr i8, ptr %4236, i64 %4242
  %private.contiguous.preserve678 = load <8 x i64>, ptr %private.contiguous.address677, align 8
  %4243 = select <8 x i1> %convergence.cascade.result660, <8 x i64> zeroinitializer, <8 x i64> %private.contiguous.preserve678
  store <8 x i64> %4243, ptr %private.contiguous.address677, align 8
  %4244 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4245 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4246 = add <8 x i64> %4245, splat (i64 576)
  %4247 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4244, 0
  %4248 = insertvalue { <8 x ptr>, <8 x i64> } %4247, <8 x i64> %4246, 1
  %4249 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4250 = extractvalue { <8 x ptr>, <8 x i64> } %4248, 1
  %4251 = extractelement <8 x ptr> %4249, i32 0
  %4252 = extractelement <8 x i64> %4250, i32 %4099
  %4253 = zext i32 %4099 to i64
  %4254 = mul i64 %4253, 8
  %4255 = sub i64 %4252, %4254
  %4256 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4257 = select i1 %4256, i64 %4255, i64 0
  %private.contiguous.address679 = getelementptr i8, ptr %4251, i64 %4257
  %private.contiguous.preserve680 = load <8 x i64>, ptr %private.contiguous.address679, align 8
  %4258 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 1), <8 x i64> %private.contiguous.preserve680
  store <8 x i64> %4258, ptr %private.contiguous.address679, align 8
  %4259 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4260 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4261 = add <8 x i64> %4260, splat (i64 640)
  %4262 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4259, 0
  %4263 = insertvalue { <8 x ptr>, <8 x i64> } %4262, <8 x i64> %4261, 1
  %4264 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4265 = extractvalue { <8 x ptr>, <8 x i64> } %4263, 1
  %4266 = extractelement <8 x ptr> %4264, i32 0
  %4267 = extractelement <8 x i64> %4265, i32 %4099
  %4268 = zext i32 %4099 to i64
  %4269 = mul i64 %4268, 8
  %4270 = sub i64 %4267, %4269
  %4271 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4272 = select i1 %4271, i64 %4270, i64 0
  %private.contiguous.address681 = getelementptr i8, ptr %4266, i64 %4272
  %private.contiguous.preserve682 = load <8 x i64>, ptr %private.contiguous.address681, align 8
  %4273 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 2), <8 x i64> %private.contiguous.preserve682
  store <8 x i64> %4273, ptr %private.contiguous.address681, align 8
  %4274 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4275 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4276 = add <8 x i64> %4275, splat (i64 704)
  %4277 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4274, 0
  %4278 = insertvalue { <8 x ptr>, <8 x i64> } %4277, <8 x i64> %4276, 1
  %4279 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4280 = extractvalue { <8 x ptr>, <8 x i64> } %4278, 1
  %4281 = extractelement <8 x ptr> %4279, i32 0
  %4282 = extractelement <8 x i64> %4280, i32 %4099
  %4283 = zext i32 %4099 to i64
  %4284 = mul i64 %4283, 8
  %4285 = sub i64 %4282, %4284
  %4286 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4287 = select i1 %4286, i64 %4285, i64 0
  %private.contiguous.address683 = getelementptr i8, ptr %4281, i64 %4287
  %private.contiguous.preserve684 = load <8 x i64>, ptr %private.contiguous.address683, align 8
  %4288 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 3), <8 x i64> %private.contiguous.preserve684
  store <8 x i64> %4288, ptr %private.contiguous.address683, align 8
  %4289 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4290 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4291 = add <8 x i64> %4290, splat (i64 768)
  %4292 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4289, 0
  %4293 = insertvalue { <8 x ptr>, <8 x i64> } %4292, <8 x i64> %4291, 1
  %4294 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4295 = extractvalue { <8 x ptr>, <8 x i64> } %4293, 1
  %4296 = extractelement <8 x ptr> %4294, i32 0
  %4297 = extractelement <8 x i64> %4295, i32 %4099
  %4298 = zext i32 %4099 to i64
  %4299 = mul i64 %4298, 8
  %4300 = sub i64 %4297, %4299
  %4301 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4302 = select i1 %4301, i64 %4300, i64 0
  %private.contiguous.address685 = getelementptr i8, ptr %4296, i64 %4302
  %private.contiguous.preserve686 = load <8 x i64>, ptr %private.contiguous.address685, align 8
  %4303 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 4), <8 x i64> %private.contiguous.preserve686
  store <8 x i64> %4303, ptr %private.contiguous.address685, align 8
  %4304 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4305 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4306 = add <8 x i64> %4305, splat (i64 832)
  %4307 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4304, 0
  %4308 = insertvalue { <8 x ptr>, <8 x i64> } %4307, <8 x i64> %4306, 1
  %4309 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4310 = extractvalue { <8 x ptr>, <8 x i64> } %4308, 1
  %4311 = extractelement <8 x ptr> %4309, i32 0
  %4312 = extractelement <8 x i64> %4310, i32 %4099
  %4313 = zext i32 %4099 to i64
  %4314 = mul i64 %4313, 8
  %4315 = sub i64 %4312, %4314
  %4316 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4317 = select i1 %4316, i64 %4315, i64 0
  %private.contiguous.address687 = getelementptr i8, ptr %4311, i64 %4317
  %private.contiguous.preserve688 = load <8 x i64>, ptr %private.contiguous.address687, align 8
  %4318 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 5), <8 x i64> %private.contiguous.preserve688
  store <8 x i64> %4318, ptr %private.contiguous.address687, align 8
  %4319 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4320 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4321 = add <8 x i64> %4320, splat (i64 896)
  %4322 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4319, 0
  %4323 = insertvalue { <8 x ptr>, <8 x i64> } %4322, <8 x i64> %4321, 1
  %4324 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4325 = extractvalue { <8 x ptr>, <8 x i64> } %4323, 1
  %4326 = extractelement <8 x ptr> %4324, i32 0
  %4327 = extractelement <8 x i64> %4325, i32 %4099
  %4328 = zext i32 %4099 to i64
  %4329 = mul i64 %4328, 8
  %4330 = sub i64 %4327, %4329
  %4331 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4332 = select i1 %4331, i64 %4330, i64 0
  %private.contiguous.address689 = getelementptr i8, ptr %4326, i64 %4332
  %private.contiguous.preserve690 = load <8 x i64>, ptr %private.contiguous.address689, align 8
  %4333 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 6), <8 x i64> %private.contiguous.preserve690
  store <8 x i64> %4333, ptr %private.contiguous.address689, align 8
  %4334 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4335 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4336 = add <8 x i64> %4335, splat (i64 960)
  %4337 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4334, 0
  %4338 = insertvalue { <8 x ptr>, <8 x i64> } %4337, <8 x i64> %4336, 1
  %4339 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4340 = extractvalue { <8 x ptr>, <8 x i64> } %4338, 1
  %4341 = extractelement <8 x ptr> %4339, i32 0
  %4342 = extractelement <8 x i64> %4340, i32 %4099
  %4343 = zext i32 %4099 to i64
  %4344 = mul i64 %4343, 8
  %4345 = sub i64 %4342, %4344
  %4346 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4347 = select i1 %4346, i64 %4345, i64 0
  %private.contiguous.address691 = getelementptr i8, ptr %4341, i64 %4347
  %private.contiguous.preserve692 = load <8 x i64>, ptr %private.contiguous.address691, align 8
  %4348 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 7), <8 x i64> %private.contiguous.preserve692
  store <8 x i64> %4348, ptr %private.contiguous.address691, align 8
  %4349 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4350 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4351 = add <8 x i64> %4350, splat (i64 1024)
  %4352 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4349, 0
  %4353 = insertvalue { <8 x ptr>, <8 x i64> } %4352, <8 x i64> %4351, 1
  %4354 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4355 = extractvalue { <8 x ptr>, <8 x i64> } %4353, 1
  %4356 = extractelement <8 x ptr> %4354, i32 0
  %4357 = extractelement <8 x i64> %4355, i32 %4099
  %4358 = zext i32 %4099 to i64
  %4359 = mul i64 %4358, 8
  %4360 = sub i64 %4357, %4359
  %4361 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4362 = select i1 %4361, i64 %4360, i64 0
  %private.contiguous.address693 = getelementptr i8, ptr %4356, i64 %4362
  %private.contiguous.preserve694 = load <8 x i64>, ptr %private.contiguous.address693, align 8
  %4363 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 8), <8 x i64> %private.contiguous.preserve694
  store <8 x i64> %4363, ptr %private.contiguous.address693, align 8
  %4364 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4365 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4366 = add <8 x i64> %4365, splat (i64 1088)
  %4367 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4364, 0
  %4368 = insertvalue { <8 x ptr>, <8 x i64> } %4367, <8 x i64> %4366, 1
  %4369 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4370 = extractvalue { <8 x ptr>, <8 x i64> } %4368, 1
  %4371 = extractelement <8 x ptr> %4369, i32 0
  %4372 = extractelement <8 x i64> %4370, i32 %4099
  %4373 = zext i32 %4099 to i64
  %4374 = mul i64 %4373, 8
  %4375 = sub i64 %4372, %4374
  %4376 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4377 = select i1 %4376, i64 %4375, i64 0
  %private.contiguous.address695 = getelementptr i8, ptr %4371, i64 %4377
  %private.contiguous.preserve696 = load <8 x i64>, ptr %private.contiguous.address695, align 8
  %4378 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 9), <8 x i64> %private.contiguous.preserve696
  store <8 x i64> %4378, ptr %private.contiguous.address695, align 8
  %4379 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4380 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4381 = add <8 x i64> %4380, splat (i64 1152)
  %4382 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4379, 0
  %4383 = insertvalue { <8 x ptr>, <8 x i64> } %4382, <8 x i64> %4381, 1
  %4384 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4385 = extractvalue { <8 x ptr>, <8 x i64> } %4383, 1
  %4386 = extractelement <8 x ptr> %4384, i32 0
  %4387 = extractelement <8 x i64> %4385, i32 %4099
  %4388 = zext i32 %4099 to i64
  %4389 = mul i64 %4388, 8
  %4390 = sub i64 %4387, %4389
  %4391 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4392 = select i1 %4391, i64 %4390, i64 0
  %private.contiguous.address697 = getelementptr i8, ptr %4386, i64 %4392
  %private.contiguous.preserve698 = load <8 x i64>, ptr %private.contiguous.address697, align 8
  %4393 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 10), <8 x i64> %private.contiguous.preserve698
  store <8 x i64> %4393, ptr %private.contiguous.address697, align 8
  %4394 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4395 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4396 = add <8 x i64> %4395, splat (i64 1216)
  %4397 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4394, 0
  %4398 = insertvalue { <8 x ptr>, <8 x i64> } %4397, <8 x i64> %4396, 1
  %4399 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4400 = extractvalue { <8 x ptr>, <8 x i64> } %4398, 1
  %4401 = extractelement <8 x ptr> %4399, i32 0
  %4402 = extractelement <8 x i64> %4400, i32 %4099
  %4403 = zext i32 %4099 to i64
  %4404 = mul i64 %4403, 8
  %4405 = sub i64 %4402, %4404
  %4406 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4407 = select i1 %4406, i64 %4405, i64 0
  %private.contiguous.address699 = getelementptr i8, ptr %4401, i64 %4407
  %private.contiguous.preserve700 = load <8 x i64>, ptr %private.contiguous.address699, align 8
  %4408 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 11), <8 x i64> %private.contiguous.preserve700
  store <8 x i64> %4408, ptr %private.contiguous.address699, align 8
  %4409 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4410 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4411 = add <8 x i64> %4410, splat (i64 1280)
  %4412 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4409, 0
  %4413 = insertvalue { <8 x ptr>, <8 x i64> } %4412, <8 x i64> %4411, 1
  %4414 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4415 = extractvalue { <8 x ptr>, <8 x i64> } %4413, 1
  %4416 = extractelement <8 x ptr> %4414, i32 0
  %4417 = extractelement <8 x i64> %4415, i32 %4099
  %4418 = zext i32 %4099 to i64
  %4419 = mul i64 %4418, 8
  %4420 = sub i64 %4417, %4419
  %4421 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4422 = select i1 %4421, i64 %4420, i64 0
  %private.contiguous.address701 = getelementptr i8, ptr %4416, i64 %4422
  %private.contiguous.preserve702 = load <8 x i64>, ptr %private.contiguous.address701, align 8
  %4423 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 12), <8 x i64> %private.contiguous.preserve702
  store <8 x i64> %4423, ptr %private.contiguous.address701, align 8
  %4424 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4425 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4426 = add <8 x i64> %4425, splat (i64 1344)
  %4427 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4424, 0
  %4428 = insertvalue { <8 x ptr>, <8 x i64> } %4427, <8 x i64> %4426, 1
  %4429 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4430 = extractvalue { <8 x ptr>, <8 x i64> } %4428, 1
  %4431 = extractelement <8 x ptr> %4429, i32 0
  %4432 = extractelement <8 x i64> %4430, i32 %4099
  %4433 = zext i32 %4099 to i64
  %4434 = mul i64 %4433, 8
  %4435 = sub i64 %4432, %4434
  %4436 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4437 = select i1 %4436, i64 %4435, i64 0
  %private.contiguous.address703 = getelementptr i8, ptr %4431, i64 %4437
  %private.contiguous.preserve704 = load <8 x i64>, ptr %private.contiguous.address703, align 8
  %4438 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 13), <8 x i64> %private.contiguous.preserve704
  store <8 x i64> %4438, ptr %private.contiguous.address703, align 8
  %4439 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4440 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4441 = add <8 x i64> %4440, splat (i64 1408)
  %4442 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4439, 0
  %4443 = insertvalue { <8 x ptr>, <8 x i64> } %4442, <8 x i64> %4441, 1
  %4444 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4445 = extractvalue { <8 x ptr>, <8 x i64> } %4443, 1
  %4446 = extractelement <8 x ptr> %4444, i32 0
  %4447 = extractelement <8 x i64> %4445, i32 %4099
  %4448 = zext i32 %4099 to i64
  %4449 = mul i64 %4448, 8
  %4450 = sub i64 %4447, %4449
  %4451 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4452 = select i1 %4451, i64 %4450, i64 0
  %private.contiguous.address705 = getelementptr i8, ptr %4446, i64 %4452
  %private.contiguous.preserve706 = load <8 x i64>, ptr %private.contiguous.address705, align 8
  %4453 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 14), <8 x i64> %private.contiguous.preserve706
  store <8 x i64> %4453, ptr %private.contiguous.address705, align 8
  %4454 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4455 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4456 = add <8 x i64> %4455, splat (i64 1472)
  %4457 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4454, 0
  %4458 = insertvalue { <8 x ptr>, <8 x i64> } %4457, <8 x i64> %4456, 1
  %4459 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4460 = extractvalue { <8 x ptr>, <8 x i64> } %4458, 1
  %4461 = extractelement <8 x ptr> %4459, i32 0
  %4462 = extractelement <8 x i64> %4460, i32 %4099
  %4463 = zext i32 %4099 to i64
  %4464 = mul i64 %4463, 8
  %4465 = sub i64 %4462, %4464
  %4466 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4467 = select i1 %4466, i64 %4465, i64 0
  %private.contiguous.address707 = getelementptr i8, ptr %4461, i64 %4467
  %private.contiguous.preserve708 = load <8 x i64>, ptr %private.contiguous.address707, align 8
  %4468 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 15), <8 x i64> %private.contiguous.preserve708
  store <8 x i64> %4468, ptr %private.contiguous.address707, align 8
  %4469 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4470 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4471 = add <8 x i64> %4470, splat (i64 1536)
  %4472 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4469, 0
  %4473 = insertvalue { <8 x ptr>, <8 x i64> } %4472, <8 x i64> %4471, 1
  %4474 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4475 = extractvalue { <8 x ptr>, <8 x i64> } %4473, 1
  %4476 = extractelement <8 x ptr> %4474, i32 0
  %4477 = extractelement <8 x i64> %4475, i32 %4099
  %4478 = zext i32 %4099 to i64
  %4479 = mul i64 %4478, 8
  %4480 = sub i64 %4477, %4479
  %4481 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4482 = select i1 %4481, i64 %4480, i64 0
  %private.contiguous.address709 = getelementptr i8, ptr %4476, i64 %4482
  %private.contiguous.preserve710 = load <8 x i64>, ptr %private.contiguous.address709, align 8
  %4483 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 16), <8 x i64> %private.contiguous.preserve710
  store <8 x i64> %4483, ptr %private.contiguous.address709, align 8
  %4484 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4485 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4486 = add <8 x i64> %4485, splat (i64 1600)
  %4487 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4484, 0
  %4488 = insertvalue { <8 x ptr>, <8 x i64> } %4487, <8 x i64> %4486, 1
  %4489 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4490 = extractvalue { <8 x ptr>, <8 x i64> } %4488, 1
  %4491 = extractelement <8 x ptr> %4489, i32 0
  %4492 = extractelement <8 x i64> %4490, i32 %4099
  %4493 = zext i32 %4099 to i64
  %4494 = mul i64 %4493, 8
  %4495 = sub i64 %4492, %4494
  %4496 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4497 = select i1 %4496, i64 %4495, i64 0
  %private.contiguous.address711 = getelementptr i8, ptr %4491, i64 %4497
  %private.contiguous.preserve712 = load <8 x i64>, ptr %private.contiguous.address711, align 8
  %4498 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 17), <8 x i64> %private.contiguous.preserve712
  store <8 x i64> %4498, ptr %private.contiguous.address711, align 8
  %4499 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4500 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4501 = add <8 x i64> %4500, splat (i64 1664)
  %4502 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4499, 0
  %4503 = insertvalue { <8 x ptr>, <8 x i64> } %4502, <8 x i64> %4501, 1
  %4504 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4505 = extractvalue { <8 x ptr>, <8 x i64> } %4503, 1
  %4506 = extractelement <8 x ptr> %4504, i32 0
  %4507 = extractelement <8 x i64> %4505, i32 %4099
  %4508 = zext i32 %4099 to i64
  %4509 = mul i64 %4508, 8
  %4510 = sub i64 %4507, %4509
  %4511 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4512 = select i1 %4511, i64 %4510, i64 0
  %private.contiguous.address713 = getelementptr i8, ptr %4506, i64 %4512
  %private.contiguous.preserve714 = load <8 x i64>, ptr %private.contiguous.address713, align 8
  %4513 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 18), <8 x i64> %private.contiguous.preserve714
  store <8 x i64> %4513, ptr %private.contiguous.address713, align 8
  %4514 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4515 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4516 = add <8 x i64> %4515, splat (i64 1728)
  %4517 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4514, 0
  %4518 = insertvalue { <8 x ptr>, <8 x i64> } %4517, <8 x i64> %4516, 1
  %4519 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4520 = extractvalue { <8 x ptr>, <8 x i64> } %4518, 1
  %4521 = extractelement <8 x ptr> %4519, i32 0
  %4522 = extractelement <8 x i64> %4520, i32 %4099
  %4523 = zext i32 %4099 to i64
  %4524 = mul i64 %4523, 8
  %4525 = sub i64 %4522, %4524
  %4526 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4527 = select i1 %4526, i64 %4525, i64 0
  %private.contiguous.address715 = getelementptr i8, ptr %4521, i64 %4527
  %private.contiguous.preserve716 = load <8 x i64>, ptr %private.contiguous.address715, align 8
  %4528 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 19), <8 x i64> %private.contiguous.preserve716
  store <8 x i64> %4528, ptr %private.contiguous.address715, align 8
  %4529 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4530 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4531 = add <8 x i64> %4530, splat (i64 1792)
  %4532 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4529, 0
  %4533 = insertvalue { <8 x ptr>, <8 x i64> } %4532, <8 x i64> %4531, 1
  %4534 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4535 = extractvalue { <8 x ptr>, <8 x i64> } %4533, 1
  %4536 = extractelement <8 x ptr> %4534, i32 0
  %4537 = extractelement <8 x i64> %4535, i32 %4099
  %4538 = zext i32 %4099 to i64
  %4539 = mul i64 %4538, 8
  %4540 = sub i64 %4537, %4539
  %4541 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4542 = select i1 %4541, i64 %4540, i64 0
  %private.contiguous.address717 = getelementptr i8, ptr %4536, i64 %4542
  %private.contiguous.preserve718 = load <8 x i64>, ptr %private.contiguous.address717, align 8
  %4543 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 20), <8 x i64> %private.contiguous.preserve718
  store <8 x i64> %4543, ptr %private.contiguous.address717, align 8
  %4544 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4545 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4546 = add <8 x i64> %4545, splat (i64 1856)
  %4547 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4544, 0
  %4548 = insertvalue { <8 x ptr>, <8 x i64> } %4547, <8 x i64> %4546, 1
  %4549 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4550 = extractvalue { <8 x ptr>, <8 x i64> } %4548, 1
  %4551 = extractelement <8 x ptr> %4549, i32 0
  %4552 = extractelement <8 x i64> %4550, i32 %4099
  %4553 = zext i32 %4099 to i64
  %4554 = mul i64 %4553, 8
  %4555 = sub i64 %4552, %4554
  %4556 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4557 = select i1 %4556, i64 %4555, i64 0
  %private.contiguous.address719 = getelementptr i8, ptr %4551, i64 %4557
  %private.contiguous.preserve720 = load <8 x i64>, ptr %private.contiguous.address719, align 8
  %4558 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 21), <8 x i64> %private.contiguous.preserve720
  store <8 x i64> %4558, ptr %private.contiguous.address719, align 8
  %4559 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4560 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4561 = add <8 x i64> %4560, splat (i64 1920)
  %4562 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4559, 0
  %4563 = insertvalue { <8 x ptr>, <8 x i64> } %4562, <8 x i64> %4561, 1
  %4564 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4565 = extractvalue { <8 x ptr>, <8 x i64> } %4563, 1
  %4566 = extractelement <8 x ptr> %4564, i32 0
  %4567 = extractelement <8 x i64> %4565, i32 %4099
  %4568 = zext i32 %4099 to i64
  %4569 = mul i64 %4568, 8
  %4570 = sub i64 %4567, %4569
  %4571 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4572 = select i1 %4571, i64 %4570, i64 0
  %private.contiguous.address721 = getelementptr i8, ptr %4566, i64 %4572
  %private.contiguous.preserve722 = load <8 x i64>, ptr %private.contiguous.address721, align 8
  %4573 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 22), <8 x i64> %private.contiguous.preserve722
  store <8 x i64> %4573, ptr %private.contiguous.address721, align 8
  %4574 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4575 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4576 = add <8 x i64> %4575, splat (i64 1984)
  %4577 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4574, 0
  %4578 = insertvalue { <8 x ptr>, <8 x i64> } %4577, <8 x i64> %4576, 1
  %4579 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4580 = extractvalue { <8 x ptr>, <8 x i64> } %4578, 1
  %4581 = extractelement <8 x ptr> %4579, i32 0
  %4582 = extractelement <8 x i64> %4580, i32 %4099
  %4583 = zext i32 %4099 to i64
  %4584 = mul i64 %4583, 8
  %4585 = sub i64 %4582, %4584
  %4586 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  %4587 = select i1 %4586, i64 %4585, i64 0
  %private.contiguous.address723 = getelementptr i8, ptr %4581, i64 %4587
  %private.contiguous.preserve724 = load <8 x i64>, ptr %private.contiguous.address723, align 8
  %4588 = select <8 x i1> %convergence.cascade.result660, <8 x i64> splat (i64 23), <8 x i64> %private.contiguous.preserve724
  store <8 x i64> %4588, ptr %private.contiguous.address723, align 8
  %4589 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill84, align 64
  %4590 = extractvalue { <8 x ptr>, <8 x i64> } %25, 0
  %4591 = extractvalue { <8 x ptr>, <8 x i64> } %4589, 0
  %4592 = select <8 x i1> %convergence.cascade.result660, <8 x ptr> %4590, <8 x ptr> %4591
  %4593 = extractvalue { <8 x ptr>, <8 x i64> } %25, 1
  %4594 = extractvalue { <8 x ptr>, <8 x i64> } %4589, 1
  %4595 = select <8 x i1> %convergence.cascade.result660, <8 x i64> %4593, <8 x i64> %4594
  %4596 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4592, 0
  %4597 = insertvalue { <8 x ptr>, <8 x i64> } %4596, <8 x i64> %4595, 1
  store volatile { <8 x ptr>, <8 x i64> } %4597, ptr %tile_snapshot.spill84, align 64
  %4598 = load <8 x i64>, ptr %.slot85, align 64
  %4599 = select <8 x i1> %convergence.cascade.result660, <8 x i64> zeroinitializer, <8 x i64> %4598
  store <8 x i64> %4599, ptr %.slot85, align 64
  store <8 x i1> %convergence.cascade.result660, ptr %current.mask, align 1
  %4600 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result660)
  br i1 %4600, label %schedule.32, label %scheduler.loop

varying.divergent726:                             ; preds = %schedule.32
  %4601 = load i32, ptr %current.token, align 4
  %4602 = icmp ne i32 %4601, 0
  %4603 = sub i32 %4601, 1
  %4604 = select i1 %4602, i32 %4603, i32 0
  %4605 = load i8, ptr %frame.active, align 1
  %4606 = trunc i32 %4604 to i8
  %4607 = shl i8 1, %4606
  %4608 = and i8 %4605, %4607
  %4609 = icmp ne i8 %4608, 0
  %4610 = load <8 x i32>, ptr %frame.static.id, align 32
  %4611 = extractelement <8 x i32> %4610, i32 %4604
  %4612 = icmp eq i32 %4611, 12
  %4613 = and i1 %4609, %4612
  %4614 = and i1 %4602, %4613
  %4615 = xor i1 %4614, true
  %4616 = and i1 true, %4615
  %4617 = xor i8 %4605, -1
  %4618 = icmp ne i8 %4617, 0
  %4619 = xor i1 %4618, true
  %4620 = and i1 %4616, %4619
  br i1 %4620, label %convergence.overflow.trap728, label %convergence.overflow.resume729

varying.coherent727:                              ; preds = %schedule.32
  br i1 %722, label %varying.coherent.true732, label %varying.coherent.false733

convergence.overflow.trap728:                     ; preds = %varying.divergent726
  call void @llvm.trap()
  unreachable

convergence.overflow.resume729:                   ; preds = %varying.divergent726
  %4621 = call i8 @llvm.cttz.i8(i8 %4617, i1 false)
  %4622 = zext i8 %4621 to i32
  %4623 = select i1 %4618, i32 %4622, i32 0
  %4624 = trunc i32 %4623 to i8
  %4625 = shl i8 1, %4624
  %4626 = or i8 %4605, %4625
  %4627 = select i1 %4616, i8 %4626, i8 %4605
  store i8 %4627, ptr %frame.active, align 1
  %4628 = load <8 x i32>, ptr %frame.static.id, align 32
  %4629 = extractelement <8 x i32> %4628, i32 %4623
  %4630 = select i1 %4616, i32 12, i32 %4629
  %4631 = load <8 x i32>, ptr %frame.static.id, align 32
  %4632 = insertelement <8 x i32> %4631, i32 %4630, i32 %4623
  store <8 x i32> %4632, ptr %frame.static.id, align 32
  %4633 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4634 = extractelement <8 x i32> %4633, i32 %4623
  %4635 = select i1 %4616, i32 %4601, i32 %4634
  %4636 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4637 = insertelement <8 x i32> %4636, i32 %4635, i32 %4623
  store <8 x i32> %4637, ptr %frame.parent.token, align 32
  %4638 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4623
  %4639 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4623
  %4640 = load <8 x i1>, ptr %4638, align 1
  %4641 = load <8 x i1>, ptr %4639, align 1
  %4642 = select i1 %4616, <8 x i1> %712, <8 x i1> %4640
  store <8 x i1> %4642, ptr %4638, align 1
  %4643 = select i1 %4616, <8 x i1> zeroinitializer, <8 x i1> %4641
  store <8 x i1> %4643, ptr %4639, align 1
  %4644 = add i32 %4623, 1
  %4645 = select i1 %4614, i32 %4601, i32 %4644
  %4646 = select i1 true, i32 %4645, i32 %4601
  store i32 %4646, ptr %current.token, align 4
  %4647 = load i32, ptr %current.token, align 4
  %4648 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %719)
  %4649 = load i32, ptr %ready.count, align 4
  %4650 = icmp uge i32 %4649, 8
  %4651 = and i1 %4648, %4650
  br i1 %4651, label %ready.overflow.trap730, label %ready.overflow.resume731

ready.overflow.trap730:                           ; preds = %convergence.overflow.resume729
  call void @llvm.trap()
  unreachable

ready.overflow.resume731:                         ; preds = %convergence.overflow.resume729
  %4652 = select i1 %4648, i32 %4649, i32 0
  %4653 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4652
  %4654 = load <8 x i1>, ptr %4653, align 1
  %4655 = select i1 %4648, <8 x i1> %719, <8 x i1> %4654
  store <8 x i1> %4655, ptr %4653, align 1
  %4656 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4652
  %4657 = load i32, ptr %4656, align 4
  %4658 = select i1 %4648, i32 33, i32 %4657
  store i32 %4658, ptr %4656, align 4
  %4659 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4652
  %4660 = load i32, ptr %4659, align 4
  %4661 = select i1 %4648, i32 %4647, i32 %4660
  store i32 %4661, ptr %4659, align 4
  %4662 = add i32 %4649, 1
  %4663 = select i1 %4648, i32 %4662, i32 %4649
  store i32 %4663, ptr %ready.count, align 4
  %4664 = load <8 x i1>, ptr %runnable.mask, align 1
  %4665 = or <8 x i1> %4664, %719
  store <8 x i1> %4665, ptr %runnable.mask, align 1
  store <8 x i1> %721, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true732:                         ; preds = %varying.coherent727
  store <8 x i1> %712, ptr %current.mask, align 1
  %4666 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %712)
  br i1 %4666, label %schedule.33, label %scheduler.loop

varying.coherent.false733:                        ; preds = %varying.coherent727
  store <8 x i1> %712, ptr %current.mask, align 1
  %4667 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %712)
  br i1 %4667, label %schedule.36, label %scheduler.loop

varying.divergent737:                             ; preds = %schedule.33
  %4668 = load i32, ptr %current.token, align 4
  %4669 = icmp ne i32 %4668, 0
  %4670 = sub i32 %4668, 1
  %4671 = select i1 %4669, i32 %4670, i32 0
  %4672 = load i8, ptr %frame.active, align 1
  %4673 = trunc i32 %4671 to i8
  %4674 = shl i8 1, %4673
  %4675 = and i8 %4672, %4674
  %4676 = icmp ne i8 %4675, 0
  %4677 = load <8 x i32>, ptr %frame.static.id, align 32
  %4678 = extractelement <8 x i32> %4677, i32 %4671
  %4679 = icmp eq i32 %4678, 13
  %4680 = and i1 %4676, %4679
  %4681 = and i1 %4669, %4680
  %4682 = xor i1 %4681, true
  %4683 = and i1 true, %4682
  %4684 = xor i8 %4672, -1
  %4685 = icmp ne i8 %4684, 0
  %4686 = xor i1 %4685, true
  %4687 = and i1 %4683, %4686
  br i1 %4687, label %convergence.overflow.trap739, label %convergence.overflow.resume740

varying.coherent738:                              ; preds = %schedule.33
  br i1 %764, label %varying.coherent.true743, label %varying.coherent.false744

convergence.overflow.trap739:                     ; preds = %varying.divergent737
  call void @llvm.trap()
  unreachable

convergence.overflow.resume740:                   ; preds = %varying.divergent737
  %4688 = call i8 @llvm.cttz.i8(i8 %4684, i1 false)
  %4689 = zext i8 %4688 to i32
  %4690 = select i1 %4685, i32 %4689, i32 0
  %4691 = trunc i32 %4690 to i8
  %4692 = shl i8 1, %4691
  %4693 = or i8 %4672, %4692
  %4694 = select i1 %4683, i8 %4693, i8 %4672
  store i8 %4694, ptr %frame.active, align 1
  %4695 = load <8 x i32>, ptr %frame.static.id, align 32
  %4696 = extractelement <8 x i32> %4695, i32 %4690
  %4697 = select i1 %4683, i32 13, i32 %4696
  %4698 = load <8 x i32>, ptr %frame.static.id, align 32
  %4699 = insertelement <8 x i32> %4698, i32 %4697, i32 %4690
  store <8 x i32> %4699, ptr %frame.static.id, align 32
  %4700 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4701 = extractelement <8 x i32> %4700, i32 %4690
  %4702 = select i1 %4683, i32 %4668, i32 %4701
  %4703 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4704 = insertelement <8 x i32> %4703, i32 %4702, i32 %4690
  store <8 x i32> %4704, ptr %frame.parent.token, align 32
  %4705 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4690
  %4706 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4690
  %4707 = load <8 x i1>, ptr %4705, align 1
  %4708 = load <8 x i1>, ptr %4706, align 1
  %4709 = select i1 %4683, <8 x i1> %725, <8 x i1> %4707
  store <8 x i1> %4709, ptr %4705, align 1
  %4710 = select i1 %4683, <8 x i1> zeroinitializer, <8 x i1> %4708
  store <8 x i1> %4710, ptr %4706, align 1
  %4711 = add i32 %4690, 1
  %4712 = select i1 %4681, i32 %4668, i32 %4711
  %4713 = select i1 true, i32 %4712, i32 %4668
  store i32 %4713, ptr %current.token, align 4
  %4714 = load <8 x float>, ptr %.slot88, align 32
  %4715 = select <8 x i1> %763, <8 x float> zeroinitializer, <8 x float> %4714
  store <8 x float> %4715, ptr %.slot88, align 32
  %4716 = load i32, ptr %current.token, align 4
  %4717 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %761)
  %4718 = load i32, ptr %ready.count, align 4
  %4719 = icmp uge i32 %4718, 8
  %4720 = and i1 %4717, %4719
  br i1 %4720, label %ready.overflow.trap741, label %ready.overflow.resume742

ready.overflow.trap741:                           ; preds = %convergence.overflow.resume740
  call void @llvm.trap()
  unreachable

ready.overflow.resume742:                         ; preds = %convergence.overflow.resume740
  %4721 = select i1 %4717, i32 %4718, i32 0
  %4722 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4721
  %4723 = load <8 x i1>, ptr %4722, align 1
  %4724 = select i1 %4717, <8 x i1> %761, <8 x i1> %4723
  store <8 x i1> %4724, ptr %4722, align 1
  %4725 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4721
  %4726 = load i32, ptr %4725, align 4
  %4727 = select i1 %4717, i32 34, i32 %4726
  store i32 %4727, ptr %4725, align 4
  %4728 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4721
  %4729 = load i32, ptr %4728, align 4
  %4730 = select i1 %4717, i32 %4716, i32 %4729
  store i32 %4730, ptr %4728, align 4
  %4731 = add i32 %4718, 1
  %4732 = select i1 %4717, i32 %4731, i32 %4718
  store i32 %4732, ptr %ready.count, align 4
  %4733 = load <8 x i1>, ptr %runnable.mask, align 1
  %4734 = or <8 x i1> %4733, %761
  store <8 x i1> %4734, ptr %runnable.mask, align 1
  store <8 x i1> %763, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true743:                         ; preds = %varying.coherent738
  store <8 x i1> %725, ptr %current.mask, align 1
  %4735 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %725)
  br i1 %4735, label %schedule.34, label %scheduler.loop

varying.coherent.false744:                        ; preds = %varying.coherent738
  %4736 = load <8 x float>, ptr %.slot88, align 32
  %4737 = select <8 x i1> %725, <8 x float> zeroinitializer, <8 x float> %4736
  store <8 x float> %4737, ptr %.slot88, align 32
  store <8 x i1> %725, ptr %current.mask, align 1
  %4738 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %725)
  br i1 %4738, label %schedule.35, label %scheduler.loop

convergence.cascade747:                           ; preds = %convergence.cascade747, %schedule.35
  %convergence.cascade.flow751 = phi <8 x i1> [ %786, %schedule.35 ], [ %4781, %convergence.cascade747 ]
  %convergence.cascade.depth752 = phi i32 [ 0, %schedule.35 ], [ %4782, %convergence.cascade747 ]
  %4739 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow751)
  %4740 = load i32, ptr %current.token, align 4
  %4741 = icmp ne i32 %4740, 0
  %4742 = and i1 %4739, %4741
  %4743 = sub i32 %4740, 1
  %4744 = select i1 %4742, i32 %4743, i32 0
  %4745 = load i8, ptr %frame.active, align 1
  %4746 = trunc i32 %4744 to i8
  %4747 = shl i8 1, %4746
  %4748 = and i8 %4745, %4747
  %4749 = icmp ne i8 %4748, 0
  %4750 = load <8 x i32>, ptr %frame.static.id, align 32
  %4751 = extractelement <8 x i32> %4750, i32 %4744
  %convergence.target.pointer753 = getelementptr inbounds [20 x i32], ptr @convergence.targets, i32 0, i32 %4751
  %convergence.dynamic.target754 = load i32, ptr %convergence.target.pointer753, align 4
  %4752 = icmp eq i32 %convergence.dynamic.target754, 35
  %4753 = and i1 %4749, %4752
  %4754 = and i1 %4742, %4753
  %4755 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4744
  %4756 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4744
  %4757 = load <8 x i1>, ptr %4755, align 1
  %4758 = load <8 x i1>, ptr %4756, align 1
  %4759 = or <8 x i1> %4758, %convergence.cascade.flow751
  %4760 = load <8 x i1>, ptr %live.mask, align 1
  %4761 = and <8 x i1> %4757, %4760
  %4762 = icmp eq <8 x i1> %4759, %4761
  %4763 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4762)
  %4764 = and i1 %4754, %4763
  %4765 = select i1 %4764, <8 x i1> zeroinitializer, <8 x i1> %4759
  %4766 = select i1 %4754, <8 x i1> %4765, <8 x i1> %4758
  store <8 x i1> %4766, ptr %4756, align 1
  %4767 = select i1 %4764, <8 x i1> zeroinitializer, <8 x i1> %4757
  store <8 x i1> %4767, ptr %4755, align 1
  %4768 = trunc i32 %4744 to i8
  %4769 = shl i8 1, %4768
  %4770 = xor i8 %4769, -1
  %4771 = and i8 %4745, %4770
  %4772 = select i1 %4764, i8 %4771, i8 %4745
  store i8 %4772, ptr %frame.active, align 1
  %.splatinsert755 = insertelement <8 x i1> poison, i1 %4754, i64 0
  %.splat756 = shufflevector <8 x i1> %.splatinsert755, <8 x i1> poison, <8 x i32> zeroinitializer
  %4773 = and <8 x i1> %convergence.cascade.flow751, %.splat756
  %4774 = load <8 x i1>, ptr %runnable.mask, align 1
  %4775 = xor <8 x i1> %4773, splat (i1 true)
  %4776 = and <8 x i1> %4774, %4775
  store <8 x i1> %4776, ptr %runnable.mask, align 1
  %.splatinsert757 = insertelement <8 x i1> poison, i1 %4764, i64 0
  %.splat758 = shufflevector <8 x i1> %.splatinsert757, <8 x i1> poison, <8 x i32> zeroinitializer
  %4777 = select <8 x i1> %.splat758, <8 x i1> %4759, <8 x i1> zeroinitializer
  %4778 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4779 = extractelement <8 x i32> %4778, i32 %4744
  %4780 = select i1 %4764, i32 %4779, i32 %4740
  store i32 %4780, ptr %current.token, align 4
  %.splatinsert759 = insertelement <8 x i1> poison, i1 %4754, i64 0
  %.splat760 = shufflevector <8 x i1> %.splatinsert759, <8 x i1> poison, <8 x i32> zeroinitializer
  %4781 = select <8 x i1> %.splat760, <8 x i1> %4777, <8 x i1> %convergence.cascade.flow751
  %4782 = add i32 %convergence.cascade.depth752, 1
  %4783 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4781)
  %4784 = icmp ult i32 %4782, 8
  %4785 = and i1 %4783, %4784
  %4786 = and i1 %4754, %4785
  %convergence.parent.token761 = load i32, ptr %current.token, align 4
  %convergence.parent.present762 = icmp ne i32 %convergence.parent.token761, 0
  %4787 = and i1 %4786, %convergence.parent.present762
  br i1 %4787, label %convergence.cascade747, label %convergence.cascade.exit748

convergence.cascade.exit748:                      ; preds = %convergence.cascade747, %schedule.35
  %convergence.cascade.result763 = phi <8 x i1> [ %786, %schedule.35 ], [ %4781, %convergence.cascade747 ]
  %4788 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result763)
  br i1 %4788, label %convergence.target.35.ready, label %scheduler.loop

convergence.target.35.ready:                      ; preds = %convergence.cascade.exit748
  %4789 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result763)
  %4790 = bitcast <8 x i1> %convergence.cascade.result763 to i8
  %4791 = call i8 @llvm.cttz.i8(i8 %4790, i1 false)
  %4792 = zext i8 %4791 to i32
  %4793 = select i1 %4789, i32 %4792, i32 0
  %.spill.load764 = load float, ptr %.spill49, align 4
  %.splatinsert765 = insertelement <8 x float> poison, float %.spill.load764, i64 0
  %.splat766 = shufflevector <8 x float> %.splatinsert765, <8 x float> poison, <8 x i32> zeroinitializer
  %.state767 = load <8 x float>, ptr %.slot88, align 32
  %.spill.load768 = load volatile <8 x i1>, ptr %.spill86, align 1
  %4794 = select <8 x i1> %.spill.load768, <8 x float> %.state767, <8 x float> %.splat766
  %tile_snapshot.spill.load769 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill84, align 64
  %4795 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load769, 0
  %4796 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load769, 1
  %.state770 = load <8 x i64>, ptr %.slot85, align 64
  %4797 = mul <8 x i64> %.state770, splat (i64 32)
  %4798 = add <8 x i64> %4796, %4797
  %4799 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4795, 0
  %4800 = insertvalue { <8 x ptr>, <8 x i64> } %4799, <8 x i64> %4798, 1
  %4801 = extractvalue { <8 x ptr>, <8 x i64> } %4800, 0
  %4802 = extractvalue { <8 x ptr>, <8 x i64> } %4800, 1
  %4803 = getelementptr i8, <8 x ptr> %4801, <8 x i64> %4802
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %4794, <8 x ptr> %4803, i32 1, <8 x i1> %convergence.cascade.result763)
  %.state771 = load <8 x i64>, ptr %.slot85, align 64
  %4804 = add <8 x i64> %.state771, splat (i64 1)
  %4805 = load <8 x i64>, ptr %.slot85, align 64
  %4806 = select <8 x i1> %convergence.cascade.result763, <8 x i64> %4804, <8 x i64> %4805
  store <8 x i64> %4806, ptr %.slot85, align 64
  store <8 x i1> %convergence.cascade.result763, ptr %current.mask, align 1
  %4807 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result763)
  br i1 %4807, label %schedule.32, label %scheduler.loop

convergence.cascade772:                           ; preds = %convergence.cascade772, %schedule.36
  %convergence.cascade.flow776 = phi <8 x i1> [ %787, %schedule.36 ], [ %4850, %convergence.cascade772 ]
  %convergence.cascade.depth777 = phi i32 [ 0, %schedule.36 ], [ %4851, %convergence.cascade772 ]
  %4808 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow776)
  %4809 = load i32, ptr %current.token, align 4
  %4810 = icmp ne i32 %4809, 0
  %4811 = and i1 %4808, %4810
  %4812 = sub i32 %4809, 1
  %4813 = select i1 %4811, i32 %4812, i32 0
  %4814 = load i8, ptr %frame.active, align 1
  %4815 = trunc i32 %4813 to i8
  %4816 = shl i8 1, %4815
  %4817 = and i8 %4814, %4816
  %4818 = icmp ne i8 %4817, 0
  %4819 = load <8 x i32>, ptr %frame.static.id, align 32
  %4820 = extractelement <8 x i32> %4819, i32 %4813
  %convergence.target.pointer778 = getelementptr inbounds [20 x i32], ptr @convergence.targets, i32 0, i32 %4820
  %convergence.dynamic.target779 = load i32, ptr %convergence.target.pointer778, align 4
  %4821 = icmp eq i32 %convergence.dynamic.target779, 36
  %4822 = and i1 %4818, %4821
  %4823 = and i1 %4811, %4822
  %4824 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4813
  %4825 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4813
  %4826 = load <8 x i1>, ptr %4824, align 1
  %4827 = load <8 x i1>, ptr %4825, align 1
  %4828 = or <8 x i1> %4827, %convergence.cascade.flow776
  %4829 = load <8 x i1>, ptr %live.mask, align 1
  %4830 = and <8 x i1> %4826, %4829
  %4831 = icmp eq <8 x i1> %4828, %4830
  %4832 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4831)
  %4833 = and i1 %4823, %4832
  %4834 = select i1 %4833, <8 x i1> zeroinitializer, <8 x i1> %4828
  %4835 = select i1 %4823, <8 x i1> %4834, <8 x i1> %4827
  store <8 x i1> %4835, ptr %4825, align 1
  %4836 = select i1 %4833, <8 x i1> zeroinitializer, <8 x i1> %4826
  store <8 x i1> %4836, ptr %4824, align 1
  %4837 = trunc i32 %4813 to i8
  %4838 = shl i8 1, %4837
  %4839 = xor i8 %4838, -1
  %4840 = and i8 %4814, %4839
  %4841 = select i1 %4833, i8 %4840, i8 %4814
  store i8 %4841, ptr %frame.active, align 1
  %.splatinsert780 = insertelement <8 x i1> poison, i1 %4823, i64 0
  %.splat781 = shufflevector <8 x i1> %.splatinsert780, <8 x i1> poison, <8 x i32> zeroinitializer
  %4842 = and <8 x i1> %convergence.cascade.flow776, %.splat781
  %4843 = load <8 x i1>, ptr %runnable.mask, align 1
  %4844 = xor <8 x i1> %4842, splat (i1 true)
  %4845 = and <8 x i1> %4843, %4844
  store <8 x i1> %4845, ptr %runnable.mask, align 1
  %.splatinsert782 = insertelement <8 x i1> poison, i1 %4833, i64 0
  %.splat783 = shufflevector <8 x i1> %.splatinsert782, <8 x i1> poison, <8 x i32> zeroinitializer
  %4846 = select <8 x i1> %.splat783, <8 x i1> %4828, <8 x i1> zeroinitializer
  %4847 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4848 = extractelement <8 x i32> %4847, i32 %4813
  %4849 = select i1 %4833, i32 %4848, i32 %4809
  store i32 %4849, ptr %current.token, align 4
  %.splatinsert784 = insertelement <8 x i1> poison, i1 %4823, i64 0
  %.splat785 = shufflevector <8 x i1> %.splatinsert784, <8 x i1> poison, <8 x i32> zeroinitializer
  %4850 = select <8 x i1> %.splat785, <8 x i1> %4846, <8 x i1> %convergence.cascade.flow776
  %4851 = add i32 %convergence.cascade.depth777, 1
  %4852 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4850)
  %4853 = icmp ult i32 %4851, 8
  %4854 = and i1 %4852, %4853
  %4855 = and i1 %4823, %4854
  %convergence.parent.token786 = load i32, ptr %current.token, align 4
  %convergence.parent.present787 = icmp ne i32 %convergence.parent.token786, 0
  %4856 = and i1 %4855, %convergence.parent.present787
  br i1 %4856, label %convergence.cascade772, label %convergence.cascade.exit773

convergence.cascade.exit773:                      ; preds = %convergence.cascade772, %schedule.36
  %convergence.cascade.result788 = phi <8 x i1> [ %787, %schedule.36 ], [ %4850, %convergence.cascade772 ]
  %4857 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result788)
  br i1 %4857, label %convergence.target.36.ready, label %scheduler.loop

convergence.target.36.ready:                      ; preds = %convergence.cascade.exit773
  %4858 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result788)
  %4859 = bitcast <8 x i1> %convergence.cascade.result788 to i8
  %4860 = call i8 @llvm.cttz.i8(i8 %4859, i1 false)
  %4861 = zext i8 %4860 to i32
  %4862 = select i1 %4858, i32 %4861, i32 0
  %4863 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill89, align 64
  %4864 = extractvalue { <8 x ptr>, <8 x i64> } %27, 0
  %4865 = extractvalue { <8 x ptr>, <8 x i64> } %4863, 0
  %4866 = select <8 x i1> %convergence.cascade.result788, <8 x ptr> %4864, <8 x ptr> %4865
  %4867 = extractvalue { <8 x ptr>, <8 x i64> } %27, 1
  %4868 = extractvalue { <8 x ptr>, <8 x i64> } %4863, 1
  %4869 = select <8 x i1> %convergence.cascade.result788, <8 x i64> %4867, <8 x i64> %4868
  %4870 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4866, 0
  %4871 = insertvalue { <8 x ptr>, <8 x i64> } %4870, <8 x i64> %4869, 1
  store volatile { <8 x ptr>, <8 x i64> } %4871, ptr %tile_snapshot.spill89, align 64
  %4872 = load <8 x i64>, ptr %.slot90, align 64
  %4873 = select <8 x i1> %convergence.cascade.result788, <8 x i64> zeroinitializer, <8 x i64> %4872
  store <8 x i64> %4873, ptr %.slot90, align 64
  store <8 x i1> %convergence.cascade.result788, ptr %current.mask, align 1
  %4874 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result788)
  br i1 %4874, label %schedule.37, label %scheduler.loop

varying.divergent790:                             ; preds = %schedule.37
  %4875 = load i32, ptr %current.token, align 4
  %4876 = icmp ne i32 %4875, 0
  %4877 = sub i32 %4875, 1
  %4878 = select i1 %4876, i32 %4877, i32 0
  %4879 = load i8, ptr %frame.active, align 1
  %4880 = trunc i32 %4878 to i8
  %4881 = shl i8 1, %4880
  %4882 = and i8 %4879, %4881
  %4883 = icmp ne i8 %4882, 0
  %4884 = load <8 x i32>, ptr %frame.static.id, align 32
  %4885 = extractelement <8 x i32> %4884, i32 %4878
  %4886 = icmp eq i32 %4885, 14
  %4887 = and i1 %4883, %4886
  %4888 = and i1 %4876, %4887
  %4889 = xor i1 %4888, true
  %4890 = and i1 true, %4889
  %4891 = xor i8 %4879, -1
  %4892 = icmp ne i8 %4891, 0
  %4893 = xor i1 %4892, true
  %4894 = and i1 %4890, %4893
  br i1 %4894, label %convergence.overflow.trap792, label %convergence.overflow.resume793

varying.coherent791:                              ; preds = %schedule.37
  br i1 %798, label %varying.coherent.true796, label %varying.coherent.false797

convergence.overflow.trap792:                     ; preds = %varying.divergent790
  call void @llvm.trap()
  unreachable

convergence.overflow.resume793:                   ; preds = %varying.divergent790
  %4895 = call i8 @llvm.cttz.i8(i8 %4891, i1 false)
  %4896 = zext i8 %4895 to i32
  %4897 = select i1 %4892, i32 %4896, i32 0
  %4898 = trunc i32 %4897 to i8
  %4899 = shl i8 1, %4898
  %4900 = or i8 %4879, %4899
  %4901 = select i1 %4890, i8 %4900, i8 %4879
  store i8 %4901, ptr %frame.active, align 1
  %4902 = load <8 x i32>, ptr %frame.static.id, align 32
  %4903 = extractelement <8 x i32> %4902, i32 %4897
  %4904 = select i1 %4890, i32 14, i32 %4903
  %4905 = load <8 x i32>, ptr %frame.static.id, align 32
  %4906 = insertelement <8 x i32> %4905, i32 %4904, i32 %4897
  store <8 x i32> %4906, ptr %frame.static.id, align 32
  %4907 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4908 = extractelement <8 x i32> %4907, i32 %4897
  %4909 = select i1 %4890, i32 %4875, i32 %4908
  %4910 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4911 = insertelement <8 x i32> %4910, i32 %4909, i32 %4897
  store <8 x i32> %4911, ptr %frame.parent.token, align 32
  %4912 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4897
  %4913 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4897
  %4914 = load <8 x i1>, ptr %4912, align 1
  %4915 = load <8 x i1>, ptr %4913, align 1
  %4916 = select i1 %4890, <8 x i1> %788, <8 x i1> %4914
  store <8 x i1> %4916, ptr %4912, align 1
  %4917 = select i1 %4890, <8 x i1> zeroinitializer, <8 x i1> %4915
  store <8 x i1> %4917, ptr %4913, align 1
  %4918 = add i32 %4897, 1
  %4919 = select i1 %4888, i32 %4875, i32 %4918
  %4920 = select i1 true, i32 %4919, i32 %4875
  store i32 %4920, ptr %current.token, align 4
  %4921 = load i32, ptr %current.token, align 4
  %4922 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %795)
  %4923 = load i32, ptr %ready.count, align 4
  %4924 = icmp uge i32 %4923, 8
  %4925 = and i1 %4922, %4924
  br i1 %4925, label %ready.overflow.trap794, label %ready.overflow.resume795

ready.overflow.trap794:                           ; preds = %convergence.overflow.resume793
  call void @llvm.trap()
  unreachable

ready.overflow.resume795:                         ; preds = %convergence.overflow.resume793
  %4926 = select i1 %4922, i32 %4923, i32 0
  %4927 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4926
  %4928 = load <8 x i1>, ptr %4927, align 1
  %4929 = select i1 %4922, <8 x i1> %795, <8 x i1> %4928
  store <8 x i1> %4929, ptr %4927, align 1
  %4930 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4926
  %4931 = load i32, ptr %4930, align 4
  %4932 = select i1 %4922, i32 38, i32 %4931
  store i32 %4932, ptr %4930, align 4
  %4933 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4926
  %4934 = load i32, ptr %4933, align 4
  %4935 = select i1 %4922, i32 %4921, i32 %4934
  store i32 %4935, ptr %4933, align 4
  %4936 = add i32 %4923, 1
  %4937 = select i1 %4922, i32 %4936, i32 %4923
  store i32 %4937, ptr %ready.count, align 4
  %4938 = load <8 x i1>, ptr %runnable.mask, align 1
  %4939 = or <8 x i1> %4938, %795
  store <8 x i1> %4939, ptr %runnable.mask, align 1
  store <8 x i1> %797, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true796:                         ; preds = %varying.coherent791
  store <8 x i1> %788, ptr %current.mask, align 1
  %4940 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %788)
  br i1 %4940, label %schedule.38, label %scheduler.loop

varying.coherent.false797:                        ; preds = %varying.coherent791
  store <8 x i1> %788, ptr %current.mask, align 1
  %4941 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %788)
  br i1 %4941, label %schedule.39, label %scheduler.loop

convergence.cascade805:                           ; preds = %convergence.cascade805, %schedule.39
  %convergence.cascade.flow809 = phi <8 x i1> [ %850, %schedule.39 ], [ %4984, %convergence.cascade805 ]
  %convergence.cascade.depth810 = phi i32 [ 0, %schedule.39 ], [ %4985, %convergence.cascade805 ]
  %4942 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow809)
  %4943 = load i32, ptr %current.token, align 4
  %4944 = icmp ne i32 %4943, 0
  %4945 = and i1 %4942, %4944
  %4946 = sub i32 %4943, 1
  %4947 = select i1 %4945, i32 %4946, i32 0
  %4948 = load i8, ptr %frame.active, align 1
  %4949 = trunc i32 %4947 to i8
  %4950 = shl i8 1, %4949
  %4951 = and i8 %4948, %4950
  %4952 = icmp ne i8 %4951, 0
  %4953 = load <8 x i32>, ptr %frame.static.id, align 32
  %4954 = extractelement <8 x i32> %4953, i32 %4947
  %convergence.target.pointer811 = getelementptr inbounds [20 x i32], ptr @convergence.targets, i32 0, i32 %4954
  %convergence.dynamic.target812 = load i32, ptr %convergence.target.pointer811, align 4
  %4955 = icmp eq i32 %convergence.dynamic.target812, 39
  %4956 = and i1 %4952, %4955
  %4957 = and i1 %4945, %4956
  %4958 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4947
  %4959 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4947
  %4960 = load <8 x i1>, ptr %4958, align 1
  %4961 = load <8 x i1>, ptr %4959, align 1
  %4962 = or <8 x i1> %4961, %convergence.cascade.flow809
  %4963 = load <8 x i1>, ptr %live.mask, align 1
  %4964 = and <8 x i1> %4960, %4963
  %4965 = icmp eq <8 x i1> %4962, %4964
  %4966 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4965)
  %4967 = and i1 %4957, %4966
  %4968 = select i1 %4967, <8 x i1> zeroinitializer, <8 x i1> %4962
  %4969 = select i1 %4957, <8 x i1> %4968, <8 x i1> %4961
  store <8 x i1> %4969, ptr %4959, align 1
  %4970 = select i1 %4967, <8 x i1> zeroinitializer, <8 x i1> %4960
  store <8 x i1> %4970, ptr %4958, align 1
  %4971 = trunc i32 %4947 to i8
  %4972 = shl i8 1, %4971
  %4973 = xor i8 %4972, -1
  %4974 = and i8 %4948, %4973
  %4975 = select i1 %4967, i8 %4974, i8 %4948
  store i8 %4975, ptr %frame.active, align 1
  %.splatinsert813 = insertelement <8 x i1> poison, i1 %4957, i64 0
  %.splat814 = shufflevector <8 x i1> %.splatinsert813, <8 x i1> poison, <8 x i32> zeroinitializer
  %4976 = and <8 x i1> %convergence.cascade.flow809, %.splat814
  %4977 = load <8 x i1>, ptr %runnable.mask, align 1
  %4978 = xor <8 x i1> %4976, splat (i1 true)
  %4979 = and <8 x i1> %4977, %4978
  store <8 x i1> %4979, ptr %runnable.mask, align 1
  %.splatinsert815 = insertelement <8 x i1> poison, i1 %4967, i64 0
  %.splat816 = shufflevector <8 x i1> %.splatinsert815, <8 x i1> poison, <8 x i32> zeroinitializer
  %4980 = select <8 x i1> %.splat816, <8 x i1> %4962, <8 x i1> zeroinitializer
  %4981 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4982 = extractelement <8 x i32> %4981, i32 %4947
  %4983 = select i1 %4967, i32 %4982, i32 %4943
  store i32 %4983, ptr %current.token, align 4
  %.splatinsert817 = insertelement <8 x i1> poison, i1 %4957, i64 0
  %.splat818 = shufflevector <8 x i1> %.splatinsert817, <8 x i1> poison, <8 x i32> zeroinitializer
  %4984 = select <8 x i1> %.splat818, <8 x i1> %4980, <8 x i1> %convergence.cascade.flow809
  %4985 = add i32 %convergence.cascade.depth810, 1
  %4986 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4984)
  %4987 = icmp ult i32 %4985, 8
  %4988 = and i1 %4986, %4987
  %4989 = and i1 %4957, %4988
  %convergence.parent.token819 = load i32, ptr %current.token, align 4
  %convergence.parent.present820 = icmp ne i32 %convergence.parent.token819, 0
  %4990 = and i1 %4989, %convergence.parent.present820
  br i1 %4990, label %convergence.cascade805, label %convergence.cascade.exit806

convergence.cascade.exit806:                      ; preds = %convergence.cascade805, %schedule.39
  %convergence.cascade.result821 = phi <8 x i1> [ %850, %schedule.39 ], [ %4984, %convergence.cascade805 ]
  %4991 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  br i1 %4991, label %convergence.target.39.ready, label %scheduler.loop

convergence.target.39.ready:                      ; preds = %convergence.cascade.exit806
  %4992 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %4993 = bitcast <8 x i1> %convergence.cascade.result821 to i8
  %4994 = call i8 @llvm.cttz.i8(i8 %4993, i1 false)
  %4995 = zext i8 %4994 to i32
  %4996 = select i1 %4992, i32 %4995, i32 0
  %4997 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill91, align 64
  %4998 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %4999 = extractvalue { <8 x ptr>, <8 x i64> } %4997, 0
  %5000 = select <8 x i1> %convergence.cascade.result821, <8 x ptr> %4998, <8 x ptr> %4999
  %5001 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5002 = extractvalue { <8 x ptr>, <8 x i64> } %4997, 1
  %5003 = select <8 x i1> %convergence.cascade.result821, <8 x i64> %5001, <8 x i64> %5002
  %5004 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5000, 0
  %5005 = insertvalue { <8 x ptr>, <8 x i64> } %5004, <8 x i64> %5003, 1
  store volatile { <8 x ptr>, <8 x i64> } %5005, ptr %tile_snapshot.spill91, align 64
  %5006 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5007 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5008 = add <8 x i64> %5007, zeroinitializer
  %5009 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5006, 0
  %5010 = insertvalue { <8 x ptr>, <8 x i64> } %5009, <8 x i64> %5008, 1
  %5011 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5012 = extractvalue { <8 x ptr>, <8 x i64> } %5010, 1
  %5013 = extractelement <8 x ptr> %5011, i32 0
  %5014 = extractelement <8 x i64> %5012, i32 %4996
  %5015 = zext i32 %4996 to i64
  %5016 = mul i64 %5015, 8
  %5017 = sub i64 %5014, %5016
  %5018 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5019 = select i1 %5018, i64 %5017, i64 0
  %private.contiguous.address822 = getelementptr i8, ptr %5013, i64 %5019
  %private.contiguous.preserve823 = load <8 x i64>, ptr %private.contiguous.address822, align 8
  %5020 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 -16), <8 x i64> %private.contiguous.preserve823
  store <8 x i64> %5020, ptr %private.contiguous.address822, align 8
  %5021 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5022 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5023 = add <8 x i64> %5022, splat (i64 64)
  %5024 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5021, 0
  %5025 = insertvalue { <8 x ptr>, <8 x i64> } %5024, <8 x i64> %5023, 1
  %5026 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5027 = extractvalue { <8 x ptr>, <8 x i64> } %5025, 1
  %5028 = extractelement <8 x ptr> %5026, i32 0
  %5029 = extractelement <8 x i64> %5027, i32 %4996
  %5030 = zext i32 %4996 to i64
  %5031 = mul i64 %5030, 8
  %5032 = sub i64 %5029, %5031
  %5033 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5034 = select i1 %5033, i64 %5032, i64 0
  %private.contiguous.address824 = getelementptr i8, ptr %5028, i64 %5034
  %private.contiguous.preserve825 = load <8 x i64>, ptr %private.contiguous.address824, align 8
  %5035 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 -15), <8 x i64> %private.contiguous.preserve825
  store <8 x i64> %5035, ptr %private.contiguous.address824, align 8
  %5036 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5037 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5038 = add <8 x i64> %5037, splat (i64 128)
  %5039 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5036, 0
  %5040 = insertvalue { <8 x ptr>, <8 x i64> } %5039, <8 x i64> %5038, 1
  %5041 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5042 = extractvalue { <8 x ptr>, <8 x i64> } %5040, 1
  %5043 = extractelement <8 x ptr> %5041, i32 0
  %5044 = extractelement <8 x i64> %5042, i32 %4996
  %5045 = zext i32 %4996 to i64
  %5046 = mul i64 %5045, 8
  %5047 = sub i64 %5044, %5046
  %5048 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5049 = select i1 %5048, i64 %5047, i64 0
  %private.contiguous.address826 = getelementptr i8, ptr %5043, i64 %5049
  %private.contiguous.preserve827 = load <8 x i64>, ptr %private.contiguous.address826, align 8
  %5050 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 -14), <8 x i64> %private.contiguous.preserve827
  store <8 x i64> %5050, ptr %private.contiguous.address826, align 8
  %5051 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5052 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5053 = add <8 x i64> %5052, splat (i64 192)
  %5054 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5051, 0
  %5055 = insertvalue { <8 x ptr>, <8 x i64> } %5054, <8 x i64> %5053, 1
  %5056 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5057 = extractvalue { <8 x ptr>, <8 x i64> } %5055, 1
  %5058 = extractelement <8 x ptr> %5056, i32 0
  %5059 = extractelement <8 x i64> %5057, i32 %4996
  %5060 = zext i32 %4996 to i64
  %5061 = mul i64 %5060, 8
  %5062 = sub i64 %5059, %5061
  %5063 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5064 = select i1 %5063, i64 %5062, i64 0
  %private.contiguous.address828 = getelementptr i8, ptr %5058, i64 %5064
  %private.contiguous.preserve829 = load <8 x i64>, ptr %private.contiguous.address828, align 8
  %5065 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 -13), <8 x i64> %private.contiguous.preserve829
  store <8 x i64> %5065, ptr %private.contiguous.address828, align 8
  %5066 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5067 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5068 = add <8 x i64> %5067, splat (i64 256)
  %5069 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5066, 0
  %5070 = insertvalue { <8 x ptr>, <8 x i64> } %5069, <8 x i64> %5068, 1
  %5071 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5072 = extractvalue { <8 x ptr>, <8 x i64> } %5070, 1
  %5073 = extractelement <8 x ptr> %5071, i32 0
  %5074 = extractelement <8 x i64> %5072, i32 %4996
  %5075 = zext i32 %4996 to i64
  %5076 = mul i64 %5075, 8
  %5077 = sub i64 %5074, %5076
  %5078 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5079 = select i1 %5078, i64 %5077, i64 0
  %private.contiguous.address830 = getelementptr i8, ptr %5073, i64 %5079
  %private.contiguous.preserve831 = load <8 x i64>, ptr %private.contiguous.address830, align 8
  %5080 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 -12), <8 x i64> %private.contiguous.preserve831
  store <8 x i64> %5080, ptr %private.contiguous.address830, align 8
  %5081 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5082 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5083 = add <8 x i64> %5082, splat (i64 320)
  %5084 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5081, 0
  %5085 = insertvalue { <8 x ptr>, <8 x i64> } %5084, <8 x i64> %5083, 1
  %5086 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5087 = extractvalue { <8 x ptr>, <8 x i64> } %5085, 1
  %5088 = extractelement <8 x ptr> %5086, i32 0
  %5089 = extractelement <8 x i64> %5087, i32 %4996
  %5090 = zext i32 %4996 to i64
  %5091 = mul i64 %5090, 8
  %5092 = sub i64 %5089, %5091
  %5093 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5094 = select i1 %5093, i64 %5092, i64 0
  %private.contiguous.address832 = getelementptr i8, ptr %5088, i64 %5094
  %private.contiguous.preserve833 = load <8 x i64>, ptr %private.contiguous.address832, align 8
  %5095 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 -11), <8 x i64> %private.contiguous.preserve833
  store <8 x i64> %5095, ptr %private.contiguous.address832, align 8
  %5096 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5097 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5098 = add <8 x i64> %5097, splat (i64 384)
  %5099 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5096, 0
  %5100 = insertvalue { <8 x ptr>, <8 x i64> } %5099, <8 x i64> %5098, 1
  %5101 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5102 = extractvalue { <8 x ptr>, <8 x i64> } %5100, 1
  %5103 = extractelement <8 x ptr> %5101, i32 0
  %5104 = extractelement <8 x i64> %5102, i32 %4996
  %5105 = zext i32 %4996 to i64
  %5106 = mul i64 %5105, 8
  %5107 = sub i64 %5104, %5106
  %5108 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5109 = select i1 %5108, i64 %5107, i64 0
  %private.contiguous.address834 = getelementptr i8, ptr %5103, i64 %5109
  %private.contiguous.preserve835 = load <8 x i64>, ptr %private.contiguous.address834, align 8
  %5110 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 -10), <8 x i64> %private.contiguous.preserve835
  store <8 x i64> %5110, ptr %private.contiguous.address834, align 8
  %5111 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5112 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5113 = add <8 x i64> %5112, splat (i64 448)
  %5114 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5111, 0
  %5115 = insertvalue { <8 x ptr>, <8 x i64> } %5114, <8 x i64> %5113, 1
  %5116 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5117 = extractvalue { <8 x ptr>, <8 x i64> } %5115, 1
  %5118 = extractelement <8 x ptr> %5116, i32 0
  %5119 = extractelement <8 x i64> %5117, i32 %4996
  %5120 = zext i32 %4996 to i64
  %5121 = mul i64 %5120, 8
  %5122 = sub i64 %5119, %5121
  %5123 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5124 = select i1 %5123, i64 %5122, i64 0
  %private.contiguous.address836 = getelementptr i8, ptr %5118, i64 %5124
  %private.contiguous.preserve837 = load <8 x i64>, ptr %private.contiguous.address836, align 8
  %5125 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 -9), <8 x i64> %private.contiguous.preserve837
  store <8 x i64> %5125, ptr %private.contiguous.address836, align 8
  %5126 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5127 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5128 = add <8 x i64> %5127, splat (i64 512)
  %5129 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5126, 0
  %5130 = insertvalue { <8 x ptr>, <8 x i64> } %5129, <8 x i64> %5128, 1
  %5131 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5132 = extractvalue { <8 x ptr>, <8 x i64> } %5130, 1
  %5133 = extractelement <8 x ptr> %5131, i32 0
  %5134 = extractelement <8 x i64> %5132, i32 %4996
  %5135 = zext i32 %4996 to i64
  %5136 = mul i64 %5135, 8
  %5137 = sub i64 %5134, %5136
  %5138 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5139 = select i1 %5138, i64 %5137, i64 0
  %private.contiguous.address838 = getelementptr i8, ptr %5133, i64 %5139
  %private.contiguous.preserve839 = load <8 x i64>, ptr %private.contiguous.address838, align 8
  %5140 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 -8), <8 x i64> %private.contiguous.preserve839
  store <8 x i64> %5140, ptr %private.contiguous.address838, align 8
  %5141 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5142 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5143 = add <8 x i64> %5142, splat (i64 576)
  %5144 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5141, 0
  %5145 = insertvalue { <8 x ptr>, <8 x i64> } %5144, <8 x i64> %5143, 1
  %5146 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5147 = extractvalue { <8 x ptr>, <8 x i64> } %5145, 1
  %5148 = extractelement <8 x ptr> %5146, i32 0
  %5149 = extractelement <8 x i64> %5147, i32 %4996
  %5150 = zext i32 %4996 to i64
  %5151 = mul i64 %5150, 8
  %5152 = sub i64 %5149, %5151
  %5153 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5154 = select i1 %5153, i64 %5152, i64 0
  %private.contiguous.address840 = getelementptr i8, ptr %5148, i64 %5154
  %private.contiguous.preserve841 = load <8 x i64>, ptr %private.contiguous.address840, align 8
  %5155 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 -7), <8 x i64> %private.contiguous.preserve841
  store <8 x i64> %5155, ptr %private.contiguous.address840, align 8
  %5156 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5157 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5158 = add <8 x i64> %5157, splat (i64 640)
  %5159 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5156, 0
  %5160 = insertvalue { <8 x ptr>, <8 x i64> } %5159, <8 x i64> %5158, 1
  %5161 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5162 = extractvalue { <8 x ptr>, <8 x i64> } %5160, 1
  %5163 = extractelement <8 x ptr> %5161, i32 0
  %5164 = extractelement <8 x i64> %5162, i32 %4996
  %5165 = zext i32 %4996 to i64
  %5166 = mul i64 %5165, 8
  %5167 = sub i64 %5164, %5166
  %5168 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5169 = select i1 %5168, i64 %5167, i64 0
  %private.contiguous.address842 = getelementptr i8, ptr %5163, i64 %5169
  %private.contiguous.preserve843 = load <8 x i64>, ptr %private.contiguous.address842, align 8
  %5170 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 -6), <8 x i64> %private.contiguous.preserve843
  store <8 x i64> %5170, ptr %private.contiguous.address842, align 8
  %5171 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5172 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5173 = add <8 x i64> %5172, splat (i64 704)
  %5174 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5171, 0
  %5175 = insertvalue { <8 x ptr>, <8 x i64> } %5174, <8 x i64> %5173, 1
  %5176 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5177 = extractvalue { <8 x ptr>, <8 x i64> } %5175, 1
  %5178 = extractelement <8 x ptr> %5176, i32 0
  %5179 = extractelement <8 x i64> %5177, i32 %4996
  %5180 = zext i32 %4996 to i64
  %5181 = mul i64 %5180, 8
  %5182 = sub i64 %5179, %5181
  %5183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5184 = select i1 %5183, i64 %5182, i64 0
  %private.contiguous.address844 = getelementptr i8, ptr %5178, i64 %5184
  %private.contiguous.preserve845 = load <8 x i64>, ptr %private.contiguous.address844, align 8
  %5185 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 -5), <8 x i64> %private.contiguous.preserve845
  store <8 x i64> %5185, ptr %private.contiguous.address844, align 8
  %5186 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5187 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5188 = add <8 x i64> %5187, splat (i64 768)
  %5189 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5186, 0
  %5190 = insertvalue { <8 x ptr>, <8 x i64> } %5189, <8 x i64> %5188, 1
  %5191 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5192 = extractvalue { <8 x ptr>, <8 x i64> } %5190, 1
  %5193 = extractelement <8 x ptr> %5191, i32 0
  %5194 = extractelement <8 x i64> %5192, i32 %4996
  %5195 = zext i32 %4996 to i64
  %5196 = mul i64 %5195, 8
  %5197 = sub i64 %5194, %5196
  %5198 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5199 = select i1 %5198, i64 %5197, i64 0
  %private.contiguous.address846 = getelementptr i8, ptr %5193, i64 %5199
  %private.contiguous.preserve847 = load <8 x i64>, ptr %private.contiguous.address846, align 8
  %5200 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 -4), <8 x i64> %private.contiguous.preserve847
  store <8 x i64> %5200, ptr %private.contiguous.address846, align 8
  %5201 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5202 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5203 = add <8 x i64> %5202, splat (i64 832)
  %5204 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5201, 0
  %5205 = insertvalue { <8 x ptr>, <8 x i64> } %5204, <8 x i64> %5203, 1
  %5206 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5207 = extractvalue { <8 x ptr>, <8 x i64> } %5205, 1
  %5208 = extractelement <8 x ptr> %5206, i32 0
  %5209 = extractelement <8 x i64> %5207, i32 %4996
  %5210 = zext i32 %4996 to i64
  %5211 = mul i64 %5210, 8
  %5212 = sub i64 %5209, %5211
  %5213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5214 = select i1 %5213, i64 %5212, i64 0
  %private.contiguous.address848 = getelementptr i8, ptr %5208, i64 %5214
  %private.contiguous.preserve849 = load <8 x i64>, ptr %private.contiguous.address848, align 8
  %5215 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 -3), <8 x i64> %private.contiguous.preserve849
  store <8 x i64> %5215, ptr %private.contiguous.address848, align 8
  %5216 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5217 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5218 = add <8 x i64> %5217, splat (i64 896)
  %5219 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5216, 0
  %5220 = insertvalue { <8 x ptr>, <8 x i64> } %5219, <8 x i64> %5218, 1
  %5221 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5222 = extractvalue { <8 x ptr>, <8 x i64> } %5220, 1
  %5223 = extractelement <8 x ptr> %5221, i32 0
  %5224 = extractelement <8 x i64> %5222, i32 %4996
  %5225 = zext i32 %4996 to i64
  %5226 = mul i64 %5225, 8
  %5227 = sub i64 %5224, %5226
  %5228 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5229 = select i1 %5228, i64 %5227, i64 0
  %private.contiguous.address850 = getelementptr i8, ptr %5223, i64 %5229
  %private.contiguous.preserve851 = load <8 x i64>, ptr %private.contiguous.address850, align 8
  %5230 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 -2), <8 x i64> %private.contiguous.preserve851
  store <8 x i64> %5230, ptr %private.contiguous.address850, align 8
  %5231 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5232 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5233 = add <8 x i64> %5232, splat (i64 960)
  %5234 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5231, 0
  %5235 = insertvalue { <8 x ptr>, <8 x i64> } %5234, <8 x i64> %5233, 1
  %5236 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5237 = extractvalue { <8 x ptr>, <8 x i64> } %5235, 1
  %5238 = extractelement <8 x ptr> %5236, i32 0
  %5239 = extractelement <8 x i64> %5237, i32 %4996
  %5240 = zext i32 %4996 to i64
  %5241 = mul i64 %5240, 8
  %5242 = sub i64 %5239, %5241
  %5243 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5244 = select i1 %5243, i64 %5242, i64 0
  %private.contiguous.address852 = getelementptr i8, ptr %5238, i64 %5244
  %private.contiguous.preserve853 = load <8 x i64>, ptr %private.contiguous.address852, align 8
  %5245 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 -1), <8 x i64> %private.contiguous.preserve853
  store <8 x i64> %5245, ptr %private.contiguous.address852, align 8
  %5246 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5247 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5248 = add <8 x i64> %5247, splat (i64 1024)
  %5249 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5246, 0
  %5250 = insertvalue { <8 x ptr>, <8 x i64> } %5249, <8 x i64> %5248, 1
  %5251 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5252 = extractvalue { <8 x ptr>, <8 x i64> } %5250, 1
  %5253 = extractelement <8 x ptr> %5251, i32 0
  %5254 = extractelement <8 x i64> %5252, i32 %4996
  %5255 = zext i32 %4996 to i64
  %5256 = mul i64 %5255, 8
  %5257 = sub i64 %5254, %5256
  %5258 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5259 = select i1 %5258, i64 %5257, i64 0
  %private.contiguous.address854 = getelementptr i8, ptr %5253, i64 %5259
  %private.contiguous.preserve855 = load <8 x i64>, ptr %private.contiguous.address854, align 8
  %5260 = select <8 x i1> %convergence.cascade.result821, <8 x i64> zeroinitializer, <8 x i64> %private.contiguous.preserve855
  store <8 x i64> %5260, ptr %private.contiguous.address854, align 8
  %5261 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5262 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5263 = add <8 x i64> %5262, splat (i64 1088)
  %5264 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5261, 0
  %5265 = insertvalue { <8 x ptr>, <8 x i64> } %5264, <8 x i64> %5263, 1
  %5266 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5267 = extractvalue { <8 x ptr>, <8 x i64> } %5265, 1
  %5268 = extractelement <8 x ptr> %5266, i32 0
  %5269 = extractelement <8 x i64> %5267, i32 %4996
  %5270 = zext i32 %4996 to i64
  %5271 = mul i64 %5270, 8
  %5272 = sub i64 %5269, %5271
  %5273 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5274 = select i1 %5273, i64 %5272, i64 0
  %private.contiguous.address856 = getelementptr i8, ptr %5268, i64 %5274
  %private.contiguous.preserve857 = load <8 x i64>, ptr %private.contiguous.address856, align 8
  %5275 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 1), <8 x i64> %private.contiguous.preserve857
  store <8 x i64> %5275, ptr %private.contiguous.address856, align 8
  %5276 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5277 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5278 = add <8 x i64> %5277, splat (i64 1152)
  %5279 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5276, 0
  %5280 = insertvalue { <8 x ptr>, <8 x i64> } %5279, <8 x i64> %5278, 1
  %5281 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5282 = extractvalue { <8 x ptr>, <8 x i64> } %5280, 1
  %5283 = extractelement <8 x ptr> %5281, i32 0
  %5284 = extractelement <8 x i64> %5282, i32 %4996
  %5285 = zext i32 %4996 to i64
  %5286 = mul i64 %5285, 8
  %5287 = sub i64 %5284, %5286
  %5288 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5289 = select i1 %5288, i64 %5287, i64 0
  %private.contiguous.address858 = getelementptr i8, ptr %5283, i64 %5289
  %private.contiguous.preserve859 = load <8 x i64>, ptr %private.contiguous.address858, align 8
  %5290 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 2), <8 x i64> %private.contiguous.preserve859
  store <8 x i64> %5290, ptr %private.contiguous.address858, align 8
  %5291 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5292 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5293 = add <8 x i64> %5292, splat (i64 1216)
  %5294 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5291, 0
  %5295 = insertvalue { <8 x ptr>, <8 x i64> } %5294, <8 x i64> %5293, 1
  %5296 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5297 = extractvalue { <8 x ptr>, <8 x i64> } %5295, 1
  %5298 = extractelement <8 x ptr> %5296, i32 0
  %5299 = extractelement <8 x i64> %5297, i32 %4996
  %5300 = zext i32 %4996 to i64
  %5301 = mul i64 %5300, 8
  %5302 = sub i64 %5299, %5301
  %5303 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5304 = select i1 %5303, i64 %5302, i64 0
  %private.contiguous.address860 = getelementptr i8, ptr %5298, i64 %5304
  %private.contiguous.preserve861 = load <8 x i64>, ptr %private.contiguous.address860, align 8
  %5305 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 3), <8 x i64> %private.contiguous.preserve861
  store <8 x i64> %5305, ptr %private.contiguous.address860, align 8
  %5306 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5307 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5308 = add <8 x i64> %5307, splat (i64 1280)
  %5309 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5306, 0
  %5310 = insertvalue { <8 x ptr>, <8 x i64> } %5309, <8 x i64> %5308, 1
  %5311 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5312 = extractvalue { <8 x ptr>, <8 x i64> } %5310, 1
  %5313 = extractelement <8 x ptr> %5311, i32 0
  %5314 = extractelement <8 x i64> %5312, i32 %4996
  %5315 = zext i32 %4996 to i64
  %5316 = mul i64 %5315, 8
  %5317 = sub i64 %5314, %5316
  %5318 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5319 = select i1 %5318, i64 %5317, i64 0
  %private.contiguous.address862 = getelementptr i8, ptr %5313, i64 %5319
  %private.contiguous.preserve863 = load <8 x i64>, ptr %private.contiguous.address862, align 8
  %5320 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 4), <8 x i64> %private.contiguous.preserve863
  store <8 x i64> %5320, ptr %private.contiguous.address862, align 8
  %5321 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5322 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5323 = add <8 x i64> %5322, splat (i64 1344)
  %5324 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5321, 0
  %5325 = insertvalue { <8 x ptr>, <8 x i64> } %5324, <8 x i64> %5323, 1
  %5326 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5327 = extractvalue { <8 x ptr>, <8 x i64> } %5325, 1
  %5328 = extractelement <8 x ptr> %5326, i32 0
  %5329 = extractelement <8 x i64> %5327, i32 %4996
  %5330 = zext i32 %4996 to i64
  %5331 = mul i64 %5330, 8
  %5332 = sub i64 %5329, %5331
  %5333 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5334 = select i1 %5333, i64 %5332, i64 0
  %private.contiguous.address864 = getelementptr i8, ptr %5328, i64 %5334
  %private.contiguous.preserve865 = load <8 x i64>, ptr %private.contiguous.address864, align 8
  %5335 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 5), <8 x i64> %private.contiguous.preserve865
  store <8 x i64> %5335, ptr %private.contiguous.address864, align 8
  %5336 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5337 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5338 = add <8 x i64> %5337, splat (i64 1408)
  %5339 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5336, 0
  %5340 = insertvalue { <8 x ptr>, <8 x i64> } %5339, <8 x i64> %5338, 1
  %5341 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5342 = extractvalue { <8 x ptr>, <8 x i64> } %5340, 1
  %5343 = extractelement <8 x ptr> %5341, i32 0
  %5344 = extractelement <8 x i64> %5342, i32 %4996
  %5345 = zext i32 %4996 to i64
  %5346 = mul i64 %5345, 8
  %5347 = sub i64 %5344, %5346
  %5348 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5349 = select i1 %5348, i64 %5347, i64 0
  %private.contiguous.address866 = getelementptr i8, ptr %5343, i64 %5349
  %private.contiguous.preserve867 = load <8 x i64>, ptr %private.contiguous.address866, align 8
  %5350 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 6), <8 x i64> %private.contiguous.preserve867
  store <8 x i64> %5350, ptr %private.contiguous.address866, align 8
  %5351 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5352 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5353 = add <8 x i64> %5352, splat (i64 1472)
  %5354 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5351, 0
  %5355 = insertvalue { <8 x ptr>, <8 x i64> } %5354, <8 x i64> %5353, 1
  %5356 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5357 = extractvalue { <8 x ptr>, <8 x i64> } %5355, 1
  %5358 = extractelement <8 x ptr> %5356, i32 0
  %5359 = extractelement <8 x i64> %5357, i32 %4996
  %5360 = zext i32 %4996 to i64
  %5361 = mul i64 %5360, 8
  %5362 = sub i64 %5359, %5361
  %5363 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5364 = select i1 %5363, i64 %5362, i64 0
  %private.contiguous.address868 = getelementptr i8, ptr %5358, i64 %5364
  %private.contiguous.preserve869 = load <8 x i64>, ptr %private.contiguous.address868, align 8
  %5365 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 7), <8 x i64> %private.contiguous.preserve869
  store <8 x i64> %5365, ptr %private.contiguous.address868, align 8
  %5366 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5367 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5368 = add <8 x i64> %5367, splat (i64 1536)
  %5369 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5366, 0
  %5370 = insertvalue { <8 x ptr>, <8 x i64> } %5369, <8 x i64> %5368, 1
  %5371 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5372 = extractvalue { <8 x ptr>, <8 x i64> } %5370, 1
  %5373 = extractelement <8 x ptr> %5371, i32 0
  %5374 = extractelement <8 x i64> %5372, i32 %4996
  %5375 = zext i32 %4996 to i64
  %5376 = mul i64 %5375, 8
  %5377 = sub i64 %5374, %5376
  %5378 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5379 = select i1 %5378, i64 %5377, i64 0
  %private.contiguous.address870 = getelementptr i8, ptr %5373, i64 %5379
  %private.contiguous.preserve871 = load <8 x i64>, ptr %private.contiguous.address870, align 8
  %5380 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 8), <8 x i64> %private.contiguous.preserve871
  store <8 x i64> %5380, ptr %private.contiguous.address870, align 8
  %5381 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5382 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5383 = add <8 x i64> %5382, splat (i64 1600)
  %5384 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5381, 0
  %5385 = insertvalue { <8 x ptr>, <8 x i64> } %5384, <8 x i64> %5383, 1
  %5386 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5387 = extractvalue { <8 x ptr>, <8 x i64> } %5385, 1
  %5388 = extractelement <8 x ptr> %5386, i32 0
  %5389 = extractelement <8 x i64> %5387, i32 %4996
  %5390 = zext i32 %4996 to i64
  %5391 = mul i64 %5390, 8
  %5392 = sub i64 %5389, %5391
  %5393 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5394 = select i1 %5393, i64 %5392, i64 0
  %private.contiguous.address872 = getelementptr i8, ptr %5388, i64 %5394
  %private.contiguous.preserve873 = load <8 x i64>, ptr %private.contiguous.address872, align 8
  %5395 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 9), <8 x i64> %private.contiguous.preserve873
  store <8 x i64> %5395, ptr %private.contiguous.address872, align 8
  %5396 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5397 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5398 = add <8 x i64> %5397, splat (i64 1664)
  %5399 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5396, 0
  %5400 = insertvalue { <8 x ptr>, <8 x i64> } %5399, <8 x i64> %5398, 1
  %5401 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5402 = extractvalue { <8 x ptr>, <8 x i64> } %5400, 1
  %5403 = extractelement <8 x ptr> %5401, i32 0
  %5404 = extractelement <8 x i64> %5402, i32 %4996
  %5405 = zext i32 %4996 to i64
  %5406 = mul i64 %5405, 8
  %5407 = sub i64 %5404, %5406
  %5408 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5409 = select i1 %5408, i64 %5407, i64 0
  %private.contiguous.address874 = getelementptr i8, ptr %5403, i64 %5409
  %private.contiguous.preserve875 = load <8 x i64>, ptr %private.contiguous.address874, align 8
  %5410 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 10), <8 x i64> %private.contiguous.preserve875
  store <8 x i64> %5410, ptr %private.contiguous.address874, align 8
  %5411 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5412 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5413 = add <8 x i64> %5412, splat (i64 1728)
  %5414 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5411, 0
  %5415 = insertvalue { <8 x ptr>, <8 x i64> } %5414, <8 x i64> %5413, 1
  %5416 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5417 = extractvalue { <8 x ptr>, <8 x i64> } %5415, 1
  %5418 = extractelement <8 x ptr> %5416, i32 0
  %5419 = extractelement <8 x i64> %5417, i32 %4996
  %5420 = zext i32 %4996 to i64
  %5421 = mul i64 %5420, 8
  %5422 = sub i64 %5419, %5421
  %5423 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5424 = select i1 %5423, i64 %5422, i64 0
  %private.contiguous.address876 = getelementptr i8, ptr %5418, i64 %5424
  %private.contiguous.preserve877 = load <8 x i64>, ptr %private.contiguous.address876, align 8
  %5425 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 11), <8 x i64> %private.contiguous.preserve877
  store <8 x i64> %5425, ptr %private.contiguous.address876, align 8
  %5426 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5427 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5428 = add <8 x i64> %5427, splat (i64 1792)
  %5429 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5426, 0
  %5430 = insertvalue { <8 x ptr>, <8 x i64> } %5429, <8 x i64> %5428, 1
  %5431 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5432 = extractvalue { <8 x ptr>, <8 x i64> } %5430, 1
  %5433 = extractelement <8 x ptr> %5431, i32 0
  %5434 = extractelement <8 x i64> %5432, i32 %4996
  %5435 = zext i32 %4996 to i64
  %5436 = mul i64 %5435, 8
  %5437 = sub i64 %5434, %5436
  %5438 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5439 = select i1 %5438, i64 %5437, i64 0
  %private.contiguous.address878 = getelementptr i8, ptr %5433, i64 %5439
  %private.contiguous.preserve879 = load <8 x i64>, ptr %private.contiguous.address878, align 8
  %5440 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 12), <8 x i64> %private.contiguous.preserve879
  store <8 x i64> %5440, ptr %private.contiguous.address878, align 8
  %5441 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5442 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5443 = add <8 x i64> %5442, splat (i64 1856)
  %5444 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5441, 0
  %5445 = insertvalue { <8 x ptr>, <8 x i64> } %5444, <8 x i64> %5443, 1
  %5446 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5447 = extractvalue { <8 x ptr>, <8 x i64> } %5445, 1
  %5448 = extractelement <8 x ptr> %5446, i32 0
  %5449 = extractelement <8 x i64> %5447, i32 %4996
  %5450 = zext i32 %4996 to i64
  %5451 = mul i64 %5450, 8
  %5452 = sub i64 %5449, %5451
  %5453 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5454 = select i1 %5453, i64 %5452, i64 0
  %private.contiguous.address880 = getelementptr i8, ptr %5448, i64 %5454
  %private.contiguous.preserve881 = load <8 x i64>, ptr %private.contiguous.address880, align 8
  %5455 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 13), <8 x i64> %private.contiguous.preserve881
  store <8 x i64> %5455, ptr %private.contiguous.address880, align 8
  %5456 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5457 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5458 = add <8 x i64> %5457, splat (i64 1920)
  %5459 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5456, 0
  %5460 = insertvalue { <8 x ptr>, <8 x i64> } %5459, <8 x i64> %5458, 1
  %5461 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5462 = extractvalue { <8 x ptr>, <8 x i64> } %5460, 1
  %5463 = extractelement <8 x ptr> %5461, i32 0
  %5464 = extractelement <8 x i64> %5462, i32 %4996
  %5465 = zext i32 %4996 to i64
  %5466 = mul i64 %5465, 8
  %5467 = sub i64 %5464, %5466
  %5468 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5469 = select i1 %5468, i64 %5467, i64 0
  %private.contiguous.address882 = getelementptr i8, ptr %5463, i64 %5469
  %private.contiguous.preserve883 = load <8 x i64>, ptr %private.contiguous.address882, align 8
  %5470 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 14), <8 x i64> %private.contiguous.preserve883
  store <8 x i64> %5470, ptr %private.contiguous.address882, align 8
  %5471 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5472 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5473 = add <8 x i64> %5472, splat (i64 1984)
  %5474 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5471, 0
  %5475 = insertvalue { <8 x ptr>, <8 x i64> } %5474, <8 x i64> %5473, 1
  %5476 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5477 = extractvalue { <8 x ptr>, <8 x i64> } %5475, 1
  %5478 = extractelement <8 x ptr> %5476, i32 0
  %5479 = extractelement <8 x i64> %5477, i32 %4996
  %5480 = zext i32 %4996 to i64
  %5481 = mul i64 %5480, 8
  %5482 = sub i64 %5479, %5481
  %5483 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  %5484 = select i1 %5483, i64 %5482, i64 0
  %private.contiguous.address884 = getelementptr i8, ptr %5478, i64 %5484
  %private.contiguous.preserve885 = load <8 x i64>, ptr %private.contiguous.address884, align 8
  %5485 = select <8 x i1> %convergence.cascade.result821, <8 x i64> splat (i64 15), <8 x i64> %private.contiguous.preserve885
  store <8 x i64> %5485, ptr %private.contiguous.address884, align 8
  %5486 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill92, align 64
  %5487 = extractvalue { <8 x ptr>, <8 x i64> } %31, 0
  %5488 = extractvalue { <8 x ptr>, <8 x i64> } %5486, 0
  %5489 = select <8 x i1> %convergence.cascade.result821, <8 x ptr> %5487, <8 x ptr> %5488
  %5490 = extractvalue { <8 x ptr>, <8 x i64> } %31, 1
  %5491 = extractvalue { <8 x ptr>, <8 x i64> } %5486, 1
  %5492 = select <8 x i1> %convergence.cascade.result821, <8 x i64> %5490, <8 x i64> %5491
  %5493 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5489, 0
  %5494 = insertvalue { <8 x ptr>, <8 x i64> } %5493, <8 x i64> %5492, 1
  store volatile { <8 x ptr>, <8 x i64> } %5494, ptr %tile_snapshot.spill92, align 64
  %5495 = load <8 x i64>, ptr %.slot93, align 64
  %5496 = select <8 x i1> %convergence.cascade.result821, <8 x i64> zeroinitializer, <8 x i64> %5495
  store <8 x i64> %5496, ptr %.slot93, align 64
  store <8 x i1> %convergence.cascade.result821, ptr %current.mask, align 1
  %5497 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result821)
  br i1 %5497, label %schedule.40, label %scheduler.loop

varying.divergent887:                             ; preds = %schedule.40
  %5498 = load i32, ptr %current.token, align 4
  %5499 = icmp ne i32 %5498, 0
  %5500 = sub i32 %5498, 1
  %5501 = select i1 %5499, i32 %5500, i32 0
  %5502 = load i8, ptr %frame.active, align 1
  %5503 = trunc i32 %5501 to i8
  %5504 = shl i8 1, %5503
  %5505 = and i8 %5502, %5504
  %5506 = icmp ne i8 %5505, 0
  %5507 = load <8 x i32>, ptr %frame.static.id, align 32
  %5508 = extractelement <8 x i32> %5507, i32 %5501
  %5509 = icmp eq i32 %5508, 15
  %5510 = and i1 %5506, %5509
  %5511 = and i1 %5499, %5510
  %5512 = xor i1 %5511, true
  %5513 = and i1 true, %5512
  %5514 = xor i8 %5502, -1
  %5515 = icmp ne i8 %5514, 0
  %5516 = xor i1 %5515, true
  %5517 = and i1 %5513, %5516
  br i1 %5517, label %convergence.overflow.trap889, label %convergence.overflow.resume890

varying.coherent888:                              ; preds = %schedule.40
  br i1 %861, label %varying.coherent.true893, label %varying.coherent.false894

convergence.overflow.trap889:                     ; preds = %varying.divergent887
  call void @llvm.trap()
  unreachable

convergence.overflow.resume890:                   ; preds = %varying.divergent887
  %5518 = call i8 @llvm.cttz.i8(i8 %5514, i1 false)
  %5519 = zext i8 %5518 to i32
  %5520 = select i1 %5515, i32 %5519, i32 0
  %5521 = trunc i32 %5520 to i8
  %5522 = shl i8 1, %5521
  %5523 = or i8 %5502, %5522
  %5524 = select i1 %5513, i8 %5523, i8 %5502
  store i8 %5524, ptr %frame.active, align 1
  %5525 = load <8 x i32>, ptr %frame.static.id, align 32
  %5526 = extractelement <8 x i32> %5525, i32 %5520
  %5527 = select i1 %5513, i32 15, i32 %5526
  %5528 = load <8 x i32>, ptr %frame.static.id, align 32
  %5529 = insertelement <8 x i32> %5528, i32 %5527, i32 %5520
  store <8 x i32> %5529, ptr %frame.static.id, align 32
  %5530 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5531 = extractelement <8 x i32> %5530, i32 %5520
  %5532 = select i1 %5513, i32 %5498, i32 %5531
  %5533 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5534 = insertelement <8 x i32> %5533, i32 %5532, i32 %5520
  store <8 x i32> %5534, ptr %frame.parent.token, align 32
  %5535 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5520
  %5536 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5520
  %5537 = load <8 x i1>, ptr %5535, align 1
  %5538 = load <8 x i1>, ptr %5536, align 1
  %5539 = select i1 %5513, <8 x i1> %851, <8 x i1> %5537
  store <8 x i1> %5539, ptr %5535, align 1
  %5540 = select i1 %5513, <8 x i1> zeroinitializer, <8 x i1> %5538
  store <8 x i1> %5540, ptr %5536, align 1
  %5541 = add i32 %5520, 1
  %5542 = select i1 %5511, i32 %5498, i32 %5541
  %5543 = select i1 true, i32 %5542, i32 %5498
  store i32 %5543, ptr %current.token, align 4
  %5544 = load i32, ptr %current.token, align 4
  %5545 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %858)
  %5546 = load i32, ptr %ready.count, align 4
  %5547 = icmp uge i32 %5546, 8
  %5548 = and i1 %5545, %5547
  br i1 %5548, label %ready.overflow.trap891, label %ready.overflow.resume892

ready.overflow.trap891:                           ; preds = %convergence.overflow.resume890
  call void @llvm.trap()
  unreachable

ready.overflow.resume892:                         ; preds = %convergence.overflow.resume890
  %5549 = select i1 %5545, i32 %5546, i32 0
  %5550 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5549
  %5551 = load <8 x i1>, ptr %5550, align 1
  %5552 = select i1 %5545, <8 x i1> %858, <8 x i1> %5551
  store <8 x i1> %5552, ptr %5550, align 1
  %5553 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5549
  %5554 = load i32, ptr %5553, align 4
  %5555 = select i1 %5545, i32 41, i32 %5554
  store i32 %5555, ptr %5553, align 4
  %5556 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5549
  %5557 = load i32, ptr %5556, align 4
  %5558 = select i1 %5545, i32 %5544, i32 %5557
  store i32 %5558, ptr %5556, align 4
  %5559 = add i32 %5546, 1
  %5560 = select i1 %5545, i32 %5559, i32 %5546
  store i32 %5560, ptr %ready.count, align 4
  %5561 = load <8 x i1>, ptr %runnable.mask, align 1
  %5562 = or <8 x i1> %5561, %858
  store <8 x i1> %5562, ptr %runnable.mask, align 1
  store <8 x i1> %860, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true893:                         ; preds = %varying.coherent888
  store <8 x i1> %851, ptr %current.mask, align 1
  %5563 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %851)
  br i1 %5563, label %schedule.41, label %scheduler.loop

varying.coherent.false894:                        ; preds = %varying.coherent888
  store <8 x i1> %851, ptr %current.mask, align 1
  %5564 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %851)
  br i1 %5564, label %schedule.44, label %scheduler.loop

varying.divergent898:                             ; preds = %schedule.41
  %5565 = load i32, ptr %current.token, align 4
  %5566 = icmp ne i32 %5565, 0
  %5567 = sub i32 %5565, 1
  %5568 = select i1 %5566, i32 %5567, i32 0
  %5569 = load i8, ptr %frame.active, align 1
  %5570 = trunc i32 %5568 to i8
  %5571 = shl i8 1, %5570
  %5572 = and i8 %5569, %5571
  %5573 = icmp ne i8 %5572, 0
  %5574 = load <8 x i32>, ptr %frame.static.id, align 32
  %5575 = extractelement <8 x i32> %5574, i32 %5568
  %5576 = icmp eq i32 %5575, 16
  %5577 = and i1 %5573, %5576
  %5578 = and i1 %5566, %5577
  %5579 = xor i1 %5578, true
  %5580 = and i1 true, %5579
  %5581 = xor i8 %5569, -1
  %5582 = icmp ne i8 %5581, 0
  %5583 = xor i1 %5582, true
  %5584 = and i1 %5580, %5583
  br i1 %5584, label %convergence.overflow.trap900, label %convergence.overflow.resume901

varying.coherent899:                              ; preds = %schedule.41
  br i1 %903, label %varying.coherent.true904, label %varying.coherent.false905

convergence.overflow.trap900:                     ; preds = %varying.divergent898
  call void @llvm.trap()
  unreachable

convergence.overflow.resume901:                   ; preds = %varying.divergent898
  %5585 = call i8 @llvm.cttz.i8(i8 %5581, i1 false)
  %5586 = zext i8 %5585 to i32
  %5587 = select i1 %5582, i32 %5586, i32 0
  %5588 = trunc i32 %5587 to i8
  %5589 = shl i8 1, %5588
  %5590 = or i8 %5569, %5589
  %5591 = select i1 %5580, i8 %5590, i8 %5569
  store i8 %5591, ptr %frame.active, align 1
  %5592 = load <8 x i32>, ptr %frame.static.id, align 32
  %5593 = extractelement <8 x i32> %5592, i32 %5587
  %5594 = select i1 %5580, i32 16, i32 %5593
  %5595 = load <8 x i32>, ptr %frame.static.id, align 32
  %5596 = insertelement <8 x i32> %5595, i32 %5594, i32 %5587
  store <8 x i32> %5596, ptr %frame.static.id, align 32
  %5597 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5598 = extractelement <8 x i32> %5597, i32 %5587
  %5599 = select i1 %5580, i32 %5565, i32 %5598
  %5600 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5601 = insertelement <8 x i32> %5600, i32 %5599, i32 %5587
  store <8 x i32> %5601, ptr %frame.parent.token, align 32
  %5602 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5587
  %5603 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5587
  %5604 = load <8 x i1>, ptr %5602, align 1
  %5605 = load <8 x i1>, ptr %5603, align 1
  %5606 = select i1 %5580, <8 x i1> %864, <8 x i1> %5604
  store <8 x i1> %5606, ptr %5602, align 1
  %5607 = select i1 %5580, <8 x i1> zeroinitializer, <8 x i1> %5605
  store <8 x i1> %5607, ptr %5603, align 1
  %5608 = add i32 %5587, 1
  %5609 = select i1 %5578, i32 %5565, i32 %5608
  %5610 = select i1 true, i32 %5609, i32 %5565
  store i32 %5610, ptr %current.token, align 4
  %5611 = load <8 x float>, ptr %.slot96, align 32
  %5612 = select <8 x i1> %902, <8 x float> zeroinitializer, <8 x float> %5611
  store <8 x float> %5612, ptr %.slot96, align 32
  %5613 = load i32, ptr %current.token, align 4
  %5614 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %900)
  %5615 = load i32, ptr %ready.count, align 4
  %5616 = icmp uge i32 %5615, 8
  %5617 = and i1 %5614, %5616
  br i1 %5617, label %ready.overflow.trap902, label %ready.overflow.resume903

ready.overflow.trap902:                           ; preds = %convergence.overflow.resume901
  call void @llvm.trap()
  unreachable

ready.overflow.resume903:                         ; preds = %convergence.overflow.resume901
  %5618 = select i1 %5614, i32 %5615, i32 0
  %5619 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5618
  %5620 = load <8 x i1>, ptr %5619, align 1
  %5621 = select i1 %5614, <8 x i1> %900, <8 x i1> %5620
  store <8 x i1> %5621, ptr %5619, align 1
  %5622 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5618
  %5623 = load i32, ptr %5622, align 4
  %5624 = select i1 %5614, i32 42, i32 %5623
  store i32 %5624, ptr %5622, align 4
  %5625 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5618
  %5626 = load i32, ptr %5625, align 4
  %5627 = select i1 %5614, i32 %5613, i32 %5626
  store i32 %5627, ptr %5625, align 4
  %5628 = add i32 %5615, 1
  %5629 = select i1 %5614, i32 %5628, i32 %5615
  store i32 %5629, ptr %ready.count, align 4
  %5630 = load <8 x i1>, ptr %runnable.mask, align 1
  %5631 = or <8 x i1> %5630, %900
  store <8 x i1> %5631, ptr %runnable.mask, align 1
  store <8 x i1> %902, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true904:                         ; preds = %varying.coherent899
  store <8 x i1> %864, ptr %current.mask, align 1
  %5632 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %864)
  br i1 %5632, label %schedule.42, label %scheduler.loop

varying.coherent.false905:                        ; preds = %varying.coherent899
  %5633 = load <8 x float>, ptr %.slot96, align 32
  %5634 = select <8 x i1> %864, <8 x float> zeroinitializer, <8 x float> %5633
  store <8 x float> %5634, ptr %.slot96, align 32
  store <8 x i1> %864, ptr %current.mask, align 1
  %5635 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %864)
  br i1 %5635, label %schedule.43, label %scheduler.loop

convergence.cascade908:                           ; preds = %convergence.cascade908, %schedule.43
  %convergence.cascade.flow912 = phi <8 x i1> [ %925, %schedule.43 ], [ %5678, %convergence.cascade908 ]
  %convergence.cascade.depth913 = phi i32 [ 0, %schedule.43 ], [ %5679, %convergence.cascade908 ]
  %5636 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow912)
  %5637 = load i32, ptr %current.token, align 4
  %5638 = icmp ne i32 %5637, 0
  %5639 = and i1 %5636, %5638
  %5640 = sub i32 %5637, 1
  %5641 = select i1 %5639, i32 %5640, i32 0
  %5642 = load i8, ptr %frame.active, align 1
  %5643 = trunc i32 %5641 to i8
  %5644 = shl i8 1, %5643
  %5645 = and i8 %5642, %5644
  %5646 = icmp ne i8 %5645, 0
  %5647 = load <8 x i32>, ptr %frame.static.id, align 32
  %5648 = extractelement <8 x i32> %5647, i32 %5641
  %convergence.target.pointer914 = getelementptr inbounds [20 x i32], ptr @convergence.targets, i32 0, i32 %5648
  %convergence.dynamic.target915 = load i32, ptr %convergence.target.pointer914, align 4
  %5649 = icmp eq i32 %convergence.dynamic.target915, 43
  %5650 = and i1 %5646, %5649
  %5651 = and i1 %5639, %5650
  %5652 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5641
  %5653 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5641
  %5654 = load <8 x i1>, ptr %5652, align 1
  %5655 = load <8 x i1>, ptr %5653, align 1
  %5656 = or <8 x i1> %5655, %convergence.cascade.flow912
  %5657 = load <8 x i1>, ptr %live.mask, align 1
  %5658 = and <8 x i1> %5654, %5657
  %5659 = icmp eq <8 x i1> %5656, %5658
  %5660 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5659)
  %5661 = and i1 %5651, %5660
  %5662 = select i1 %5661, <8 x i1> zeroinitializer, <8 x i1> %5656
  %5663 = select i1 %5651, <8 x i1> %5662, <8 x i1> %5655
  store <8 x i1> %5663, ptr %5653, align 1
  %5664 = select i1 %5661, <8 x i1> zeroinitializer, <8 x i1> %5654
  store <8 x i1> %5664, ptr %5652, align 1
  %5665 = trunc i32 %5641 to i8
  %5666 = shl i8 1, %5665
  %5667 = xor i8 %5666, -1
  %5668 = and i8 %5642, %5667
  %5669 = select i1 %5661, i8 %5668, i8 %5642
  store i8 %5669, ptr %frame.active, align 1
  %.splatinsert916 = insertelement <8 x i1> poison, i1 %5651, i64 0
  %.splat917 = shufflevector <8 x i1> %.splatinsert916, <8 x i1> poison, <8 x i32> zeroinitializer
  %5670 = and <8 x i1> %convergence.cascade.flow912, %.splat917
  %5671 = load <8 x i1>, ptr %runnable.mask, align 1
  %5672 = xor <8 x i1> %5670, splat (i1 true)
  %5673 = and <8 x i1> %5671, %5672
  store <8 x i1> %5673, ptr %runnable.mask, align 1
  %.splatinsert918 = insertelement <8 x i1> poison, i1 %5661, i64 0
  %.splat919 = shufflevector <8 x i1> %.splatinsert918, <8 x i1> poison, <8 x i32> zeroinitializer
  %5674 = select <8 x i1> %.splat919, <8 x i1> %5656, <8 x i1> zeroinitializer
  %5675 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5676 = extractelement <8 x i32> %5675, i32 %5641
  %5677 = select i1 %5661, i32 %5676, i32 %5637
  store i32 %5677, ptr %current.token, align 4
  %.splatinsert920 = insertelement <8 x i1> poison, i1 %5651, i64 0
  %.splat921 = shufflevector <8 x i1> %.splatinsert920, <8 x i1> poison, <8 x i32> zeroinitializer
  %5678 = select <8 x i1> %.splat921, <8 x i1> %5674, <8 x i1> %convergence.cascade.flow912
  %5679 = add i32 %convergence.cascade.depth913, 1
  %5680 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5678)
  %5681 = icmp ult i32 %5679, 8
  %5682 = and i1 %5680, %5681
  %5683 = and i1 %5651, %5682
  %convergence.parent.token922 = load i32, ptr %current.token, align 4
  %convergence.parent.present923 = icmp ne i32 %convergence.parent.token922, 0
  %5684 = and i1 %5683, %convergence.parent.present923
  br i1 %5684, label %convergence.cascade908, label %convergence.cascade.exit909

convergence.cascade.exit909:                      ; preds = %convergence.cascade908, %schedule.43
  %convergence.cascade.result924 = phi <8 x i1> [ %925, %schedule.43 ], [ %5678, %convergence.cascade908 ]
  %5685 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result924)
  br i1 %5685, label %convergence.target.43.ready, label %scheduler.loop

convergence.target.43.ready:                      ; preds = %convergence.cascade.exit909
  %5686 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result924)
  %5687 = bitcast <8 x i1> %convergence.cascade.result924 to i8
  %5688 = call i8 @llvm.cttz.i8(i8 %5687, i1 false)
  %5689 = zext i8 %5688 to i32
  %5690 = select i1 %5686, i32 %5689, i32 0
  %.spill.load925 = load float, ptr %.spill49, align 4
  %.splatinsert926 = insertelement <8 x float> poison, float %.spill.load925, i64 0
  %.splat927 = shufflevector <8 x float> %.splatinsert926, <8 x float> poison, <8 x i32> zeroinitializer
  %.state928 = load <8 x float>, ptr %.slot96, align 32
  %.spill.load929 = load volatile <8 x i1>, ptr %.spill94, align 1
  %5691 = select <8 x i1> %.spill.load929, <8 x float> %.state928, <8 x float> %.splat927
  %tile_snapshot.spill.load930 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill92, align 64
  %5692 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load930, 0
  %5693 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load930, 1
  %.state931 = load <8 x i64>, ptr %.slot93, align 64
  %5694 = mul <8 x i64> %.state931, splat (i64 32)
  %5695 = add <8 x i64> %5693, %5694
  %5696 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5692, 0
  %5697 = insertvalue { <8 x ptr>, <8 x i64> } %5696, <8 x i64> %5695, 1
  %5698 = extractvalue { <8 x ptr>, <8 x i64> } %5697, 0
  %5699 = extractvalue { <8 x ptr>, <8 x i64> } %5697, 1
  %5700 = getelementptr i8, <8 x ptr> %5698, <8 x i64> %5699
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5691, <8 x ptr> %5700, i32 1, <8 x i1> %convergence.cascade.result924)
  %.state932 = load <8 x i64>, ptr %.slot93, align 64
  %5701 = add <8 x i64> %.state932, splat (i64 1)
  %5702 = load <8 x i64>, ptr %.slot93, align 64
  %5703 = select <8 x i1> %convergence.cascade.result924, <8 x i64> %5701, <8 x i64> %5702
  store <8 x i64> %5703, ptr %.slot93, align 64
  store <8 x i1> %convergence.cascade.result924, ptr %current.mask, align 1
  %5704 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result924)
  br i1 %5704, label %schedule.40, label %scheduler.loop

convergence.cascade933:                           ; preds = %convergence.cascade933, %schedule.44
  %convergence.cascade.flow937 = phi <8 x i1> [ %926, %schedule.44 ], [ %5747, %convergence.cascade933 ]
  %convergence.cascade.depth938 = phi i32 [ 0, %schedule.44 ], [ %5748, %convergence.cascade933 ]
  %5705 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow937)
  %5706 = load i32, ptr %current.token, align 4
  %5707 = icmp ne i32 %5706, 0
  %5708 = and i1 %5705, %5707
  %5709 = sub i32 %5706, 1
  %5710 = select i1 %5708, i32 %5709, i32 0
  %5711 = load i8, ptr %frame.active, align 1
  %5712 = trunc i32 %5710 to i8
  %5713 = shl i8 1, %5712
  %5714 = and i8 %5711, %5713
  %5715 = icmp ne i8 %5714, 0
  %5716 = load <8 x i32>, ptr %frame.static.id, align 32
  %5717 = extractelement <8 x i32> %5716, i32 %5710
  %convergence.target.pointer939 = getelementptr inbounds [20 x i32], ptr @convergence.targets, i32 0, i32 %5717
  %convergence.dynamic.target940 = load i32, ptr %convergence.target.pointer939, align 4
  %5718 = icmp eq i32 %convergence.dynamic.target940, 44
  %5719 = and i1 %5715, %5718
  %5720 = and i1 %5708, %5719
  %5721 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5710
  %5722 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5710
  %5723 = load <8 x i1>, ptr %5721, align 1
  %5724 = load <8 x i1>, ptr %5722, align 1
  %5725 = or <8 x i1> %5724, %convergence.cascade.flow937
  %5726 = load <8 x i1>, ptr %live.mask, align 1
  %5727 = and <8 x i1> %5723, %5726
  %5728 = icmp eq <8 x i1> %5725, %5727
  %5729 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5728)
  %5730 = and i1 %5720, %5729
  %5731 = select i1 %5730, <8 x i1> zeroinitializer, <8 x i1> %5725
  %5732 = select i1 %5720, <8 x i1> %5731, <8 x i1> %5724
  store <8 x i1> %5732, ptr %5722, align 1
  %5733 = select i1 %5730, <8 x i1> zeroinitializer, <8 x i1> %5723
  store <8 x i1> %5733, ptr %5721, align 1
  %5734 = trunc i32 %5710 to i8
  %5735 = shl i8 1, %5734
  %5736 = xor i8 %5735, -1
  %5737 = and i8 %5711, %5736
  %5738 = select i1 %5730, i8 %5737, i8 %5711
  store i8 %5738, ptr %frame.active, align 1
  %.splatinsert941 = insertelement <8 x i1> poison, i1 %5720, i64 0
  %.splat942 = shufflevector <8 x i1> %.splatinsert941, <8 x i1> poison, <8 x i32> zeroinitializer
  %5739 = and <8 x i1> %convergence.cascade.flow937, %.splat942
  %5740 = load <8 x i1>, ptr %runnable.mask, align 1
  %5741 = xor <8 x i1> %5739, splat (i1 true)
  %5742 = and <8 x i1> %5740, %5741
  store <8 x i1> %5742, ptr %runnable.mask, align 1
  %.splatinsert943 = insertelement <8 x i1> poison, i1 %5730, i64 0
  %.splat944 = shufflevector <8 x i1> %.splatinsert943, <8 x i1> poison, <8 x i32> zeroinitializer
  %5743 = select <8 x i1> %.splat944, <8 x i1> %5725, <8 x i1> zeroinitializer
  %5744 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5745 = extractelement <8 x i32> %5744, i32 %5710
  %5746 = select i1 %5730, i32 %5745, i32 %5706
  store i32 %5746, ptr %current.token, align 4
  %.splatinsert945 = insertelement <8 x i1> poison, i1 %5720, i64 0
  %.splat946 = shufflevector <8 x i1> %.splatinsert945, <8 x i1> poison, <8 x i32> zeroinitializer
  %5747 = select <8 x i1> %.splat946, <8 x i1> %5743, <8 x i1> %convergence.cascade.flow937
  %5748 = add i32 %convergence.cascade.depth938, 1
  %5749 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5747)
  %5750 = icmp ult i32 %5748, 8
  %5751 = and i1 %5749, %5750
  %5752 = and i1 %5720, %5751
  %convergence.parent.token947 = load i32, ptr %current.token, align 4
  %convergence.parent.present948 = icmp ne i32 %convergence.parent.token947, 0
  %5753 = and i1 %5752, %convergence.parent.present948
  br i1 %5753, label %convergence.cascade933, label %convergence.cascade.exit934

convergence.cascade.exit934:                      ; preds = %convergence.cascade933, %schedule.44
  %convergence.cascade.result949 = phi <8 x i1> [ %926, %schedule.44 ], [ %5747, %convergence.cascade933 ]
  %5754 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result949)
  br i1 %5754, label %convergence.target.44.ready, label %scheduler.loop

convergence.target.44.ready:                      ; preds = %convergence.cascade.exit934
  %5755 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result949)
  %5756 = bitcast <8 x i1> %convergence.cascade.result949 to i8
  %5757 = call i8 @llvm.cttz.i8(i8 %5756, i1 false)
  %5758 = zext i8 %5757 to i32
  %5759 = select i1 %5755, i32 %5758, i32 0
  %5760 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %5761 = extractvalue { <8 x ptr>, <8 x i64> } %33, 0
  %5762 = extractvalue { <8 x ptr>, <8 x i64> } %5760, 0
  %5763 = select <8 x i1> %convergence.cascade.result949, <8 x ptr> %5761, <8 x ptr> %5762
  %5764 = extractvalue { <8 x ptr>, <8 x i64> } %33, 1
  %5765 = extractvalue { <8 x ptr>, <8 x i64> } %5760, 1
  %5766 = select <8 x i1> %convergence.cascade.result949, <8 x i64> %5764, <8 x i64> %5765
  %5767 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5763, 0
  %5768 = insertvalue { <8 x ptr>, <8 x i64> } %5767, <8 x i64> %5766, 1
  store { <8 x ptr>, <8 x i64> } %5768, ptr %tile_snapshot.spill97, align 64
  %5769 = load <8 x i64>, ptr %.slot98, align 64
  %5770 = select <8 x i1> %convergence.cascade.result949, <8 x i64> zeroinitializer, <8 x i64> %5769
  store <8 x i64> %5770, ptr %.slot98, align 64
  store <8 x i1> %convergence.cascade.result949, ptr %current.mask, align 1
  %5771 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result949)
  br i1 %5771, label %schedule.45, label %scheduler.loop

varying.divergent951:                             ; preds = %schedule.45
  %5772 = load i32, ptr %current.token, align 4
  %5773 = icmp ne i32 %5772, 0
  %5774 = sub i32 %5772, 1
  %5775 = select i1 %5773, i32 %5774, i32 0
  %5776 = load i8, ptr %frame.active, align 1
  %5777 = trunc i32 %5775 to i8
  %5778 = shl i8 1, %5777
  %5779 = and i8 %5776, %5778
  %5780 = icmp ne i8 %5779, 0
  %5781 = load <8 x i32>, ptr %frame.static.id, align 32
  %5782 = extractelement <8 x i32> %5781, i32 %5775
  %5783 = icmp eq i32 %5782, 17
  %5784 = and i1 %5780, %5783
  %5785 = and i1 %5773, %5784
  %5786 = xor i1 %5785, true
  %5787 = and i1 true, %5786
  %5788 = xor i8 %5776, -1
  %5789 = icmp ne i8 %5788, 0
  %5790 = xor i1 %5789, true
  %5791 = and i1 %5787, %5790
  br i1 %5791, label %convergence.overflow.trap953, label %convergence.overflow.resume954

varying.coherent952:                              ; preds = %schedule.45
  br i1 %937, label %varying.coherent.true957, label %varying.coherent.false958

convergence.overflow.trap953:                     ; preds = %varying.divergent951
  call void @llvm.trap()
  unreachable

convergence.overflow.resume954:                   ; preds = %varying.divergent951
  %5792 = call i8 @llvm.cttz.i8(i8 %5788, i1 false)
  %5793 = zext i8 %5792 to i32
  %5794 = select i1 %5789, i32 %5793, i32 0
  %5795 = trunc i32 %5794 to i8
  %5796 = shl i8 1, %5795
  %5797 = or i8 %5776, %5796
  %5798 = select i1 %5787, i8 %5797, i8 %5776
  store i8 %5798, ptr %frame.active, align 1
  %5799 = load <8 x i32>, ptr %frame.static.id, align 32
  %5800 = extractelement <8 x i32> %5799, i32 %5794
  %5801 = select i1 %5787, i32 17, i32 %5800
  %5802 = load <8 x i32>, ptr %frame.static.id, align 32
  %5803 = insertelement <8 x i32> %5802, i32 %5801, i32 %5794
  store <8 x i32> %5803, ptr %frame.static.id, align 32
  %5804 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5805 = extractelement <8 x i32> %5804, i32 %5794
  %5806 = select i1 %5787, i32 %5772, i32 %5805
  %5807 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5808 = insertelement <8 x i32> %5807, i32 %5806, i32 %5794
  store <8 x i32> %5808, ptr %frame.parent.token, align 32
  %5809 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5794
  %5810 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5794
  %5811 = load <8 x i1>, ptr %5809, align 1
  %5812 = load <8 x i1>, ptr %5810, align 1
  %5813 = select i1 %5787, <8 x i1> %927, <8 x i1> %5811
  store <8 x i1> %5813, ptr %5809, align 1
  %5814 = select i1 %5787, <8 x i1> zeroinitializer, <8 x i1> %5812
  store <8 x i1> %5814, ptr %5810, align 1
  %5815 = add i32 %5794, 1
  %5816 = select i1 %5785, i32 %5772, i32 %5815
  %5817 = select i1 true, i32 %5816, i32 %5772
  store i32 %5817, ptr %current.token, align 4
  %5818 = load i32, ptr %current.token, align 4
  %5819 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %934)
  %5820 = load i32, ptr %ready.count, align 4
  %5821 = icmp uge i32 %5820, 8
  %5822 = and i1 %5819, %5821
  br i1 %5822, label %ready.overflow.trap955, label %ready.overflow.resume956

ready.overflow.trap955:                           ; preds = %convergence.overflow.resume954
  call void @llvm.trap()
  unreachable

ready.overflow.resume956:                         ; preds = %convergence.overflow.resume954
  %5823 = select i1 %5819, i32 %5820, i32 0
  %5824 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5823
  %5825 = load <8 x i1>, ptr %5824, align 1
  %5826 = select i1 %5819, <8 x i1> %934, <8 x i1> %5825
  store <8 x i1> %5826, ptr %5824, align 1
  %5827 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5823
  %5828 = load i32, ptr %5827, align 4
  %5829 = select i1 %5819, i32 46, i32 %5828
  store i32 %5829, ptr %5827, align 4
  %5830 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5823
  %5831 = load i32, ptr %5830, align 4
  %5832 = select i1 %5819, i32 %5818, i32 %5831
  store i32 %5832, ptr %5830, align 4
  %5833 = add i32 %5820, 1
  %5834 = select i1 %5819, i32 %5833, i32 %5820
  store i32 %5834, ptr %ready.count, align 4
  %5835 = load <8 x i1>, ptr %runnable.mask, align 1
  %5836 = or <8 x i1> %5835, %934
  store <8 x i1> %5836, ptr %runnable.mask, align 1
  store <8 x i1> %936, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true957:                         ; preds = %varying.coherent952
  store <8 x i1> %927, ptr %current.mask, align 1
  %5837 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %927)
  br i1 %5837, label %schedule.46, label %scheduler.loop

varying.coherent.false958:                        ; preds = %varying.coherent952
  store <8 x i1> %927, ptr %current.mask, align 1
  %5838 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %927)
  br i1 %5838, label %schedule.47, label %scheduler.loop

convergence.cascade967:                           ; preds = %convergence.cascade967, %schedule.47
  %convergence.cascade.flow971 = phi <8 x i1> [ %1009, %schedule.47 ], [ %5881, %convergence.cascade967 ]
  %convergence.cascade.depth972 = phi i32 [ 0, %schedule.47 ], [ %5882, %convergence.cascade967 ]
  %5839 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow971)
  %5840 = load i32, ptr %current.token, align 4
  %5841 = icmp ne i32 %5840, 0
  %5842 = and i1 %5839, %5841
  %5843 = sub i32 %5840, 1
  %5844 = select i1 %5842, i32 %5843, i32 0
  %5845 = load i8, ptr %frame.active, align 1
  %5846 = trunc i32 %5844 to i8
  %5847 = shl i8 1, %5846
  %5848 = and i8 %5845, %5847
  %5849 = icmp ne i8 %5848, 0
  %5850 = load <8 x i32>, ptr %frame.static.id, align 32
  %5851 = extractelement <8 x i32> %5850, i32 %5844
  %convergence.target.pointer973 = getelementptr inbounds [20 x i32], ptr @convergence.targets, i32 0, i32 %5851
  %convergence.dynamic.target974 = load i32, ptr %convergence.target.pointer973, align 4
  %5852 = icmp eq i32 %convergence.dynamic.target974, 47
  %5853 = and i1 %5849, %5852
  %5854 = and i1 %5842, %5853
  %5855 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5844
  %5856 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5844
  %5857 = load <8 x i1>, ptr %5855, align 1
  %5858 = load <8 x i1>, ptr %5856, align 1
  %5859 = or <8 x i1> %5858, %convergence.cascade.flow971
  %5860 = load <8 x i1>, ptr %live.mask, align 1
  %5861 = and <8 x i1> %5857, %5860
  %5862 = icmp eq <8 x i1> %5859, %5861
  %5863 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5862)
  %5864 = and i1 %5854, %5863
  %5865 = select i1 %5864, <8 x i1> zeroinitializer, <8 x i1> %5859
  %5866 = select i1 %5854, <8 x i1> %5865, <8 x i1> %5858
  store <8 x i1> %5866, ptr %5856, align 1
  %5867 = select i1 %5864, <8 x i1> zeroinitializer, <8 x i1> %5857
  store <8 x i1> %5867, ptr %5855, align 1
  %5868 = trunc i32 %5844 to i8
  %5869 = shl i8 1, %5868
  %5870 = xor i8 %5869, -1
  %5871 = and i8 %5845, %5870
  %5872 = select i1 %5864, i8 %5871, i8 %5845
  store i8 %5872, ptr %frame.active, align 1
  %.splatinsert975 = insertelement <8 x i1> poison, i1 %5854, i64 0
  %.splat976 = shufflevector <8 x i1> %.splatinsert975, <8 x i1> poison, <8 x i32> zeroinitializer
  %5873 = and <8 x i1> %convergence.cascade.flow971, %.splat976
  %5874 = load <8 x i1>, ptr %runnable.mask, align 1
  %5875 = xor <8 x i1> %5873, splat (i1 true)
  %5876 = and <8 x i1> %5874, %5875
  store <8 x i1> %5876, ptr %runnable.mask, align 1
  %.splatinsert977 = insertelement <8 x i1> poison, i1 %5864, i64 0
  %.splat978 = shufflevector <8 x i1> %.splatinsert977, <8 x i1> poison, <8 x i32> zeroinitializer
  %5877 = select <8 x i1> %.splat978, <8 x i1> %5859, <8 x i1> zeroinitializer
  %5878 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5879 = extractelement <8 x i32> %5878, i32 %5844
  %5880 = select i1 %5864, i32 %5879, i32 %5840
  store i32 %5880, ptr %current.token, align 4
  %.splatinsert979 = insertelement <8 x i1> poison, i1 %5854, i64 0
  %.splat980 = shufflevector <8 x i1> %.splatinsert979, <8 x i1> poison, <8 x i32> zeroinitializer
  %5881 = select <8 x i1> %.splat980, <8 x i1> %5877, <8 x i1> %convergence.cascade.flow971
  %5882 = add i32 %convergence.cascade.depth972, 1
  %5883 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5881)
  %5884 = icmp ult i32 %5882, 8
  %5885 = and i1 %5883, %5884
  %5886 = and i1 %5854, %5885
  %convergence.parent.token981 = load i32, ptr %current.token, align 4
  %convergence.parent.present982 = icmp ne i32 %convergence.parent.token981, 0
  %5887 = and i1 %5886, %convergence.parent.present982
  br i1 %5887, label %convergence.cascade967, label %convergence.cascade.exit968

convergence.cascade.exit968:                      ; preds = %convergence.cascade967, %schedule.47
  %convergence.cascade.result983 = phi <8 x i1> [ %1009, %schedule.47 ], [ %5881, %convergence.cascade967 ]
  %5888 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result983)
  br i1 %5888, label %convergence.target.47.ready, label %scheduler.loop

convergence.target.47.ready:                      ; preds = %convergence.cascade.exit968
  %5889 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result983)
  %5890 = bitcast <8 x i1> %convergence.cascade.result983 to i8
  %5891 = call i8 @llvm.cttz.i8(i8 %5890, i1 false)
  %5892 = zext i8 %5891 to i32
  %5893 = select i1 %5889, i32 %5892, i32 0
  %5894 = load <8 x i64>, ptr %.slot99, align 64
  %5895 = select <8 x i1> %convergence.cascade.result983, <8 x i64> zeroinitializer, <8 x i64> %5894
  store <8 x i64> %5895, ptr %.slot99, align 64
  store <8 x i1> %convergence.cascade.result983, ptr %current.mask, align 1
  %5896 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result983)
  br i1 %5896, label %schedule.48, label %scheduler.loop

varying.divergent985:                             ; preds = %schedule.48
  %5897 = load i32, ptr %current.token, align 4
  %5898 = icmp ne i32 %5897, 0
  %5899 = sub i32 %5897, 1
  %5900 = select i1 %5898, i32 %5899, i32 0
  %5901 = load i8, ptr %frame.active, align 1
  %5902 = trunc i32 %5900 to i8
  %5903 = shl i8 1, %5902
  %5904 = and i8 %5901, %5903
  %5905 = icmp ne i8 %5904, 0
  %5906 = load <8 x i32>, ptr %frame.static.id, align 32
  %5907 = extractelement <8 x i32> %5906, i32 %5900
  %5908 = icmp eq i32 %5907, 18
  %5909 = and i1 %5905, %5908
  %5910 = and i1 %5898, %5909
  %5911 = xor i1 %5910, true
  %5912 = and i1 true, %5911
  %5913 = xor i8 %5901, -1
  %5914 = icmp ne i8 %5913, 0
  %5915 = xor i1 %5914, true
  %5916 = and i1 %5912, %5915
  br i1 %5916, label %convergence.overflow.trap987, label %convergence.overflow.resume988

varying.coherent986:                              ; preds = %schedule.48
  br i1 %1020, label %varying.coherent.true991, label %varying.coherent.false992

convergence.overflow.trap987:                     ; preds = %varying.divergent985
  call void @llvm.trap()
  unreachable

convergence.overflow.resume988:                   ; preds = %varying.divergent985
  %5917 = call i8 @llvm.cttz.i8(i8 %5913, i1 false)
  %5918 = zext i8 %5917 to i32
  %5919 = select i1 %5914, i32 %5918, i32 0
  %5920 = trunc i32 %5919 to i8
  %5921 = shl i8 1, %5920
  %5922 = or i8 %5901, %5921
  %5923 = select i1 %5912, i8 %5922, i8 %5901
  store i8 %5923, ptr %frame.active, align 1
  %5924 = load <8 x i32>, ptr %frame.static.id, align 32
  %5925 = extractelement <8 x i32> %5924, i32 %5919
  %5926 = select i1 %5912, i32 18, i32 %5925
  %5927 = load <8 x i32>, ptr %frame.static.id, align 32
  %5928 = insertelement <8 x i32> %5927, i32 %5926, i32 %5919
  store <8 x i32> %5928, ptr %frame.static.id, align 32
  %5929 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5930 = extractelement <8 x i32> %5929, i32 %5919
  %5931 = select i1 %5912, i32 %5897, i32 %5930
  %5932 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5933 = insertelement <8 x i32> %5932, i32 %5931, i32 %5919
  store <8 x i32> %5933, ptr %frame.parent.token, align 32
  %5934 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5919
  %5935 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5919
  %5936 = load <8 x i1>, ptr %5934, align 1
  %5937 = load <8 x i1>, ptr %5935, align 1
  %5938 = select i1 %5912, <8 x i1> %1010, <8 x i1> %5936
  store <8 x i1> %5938, ptr %5934, align 1
  %5939 = select i1 %5912, <8 x i1> zeroinitializer, <8 x i1> %5937
  store <8 x i1> %5939, ptr %5935, align 1
  %5940 = add i32 %5919, 1
  %5941 = select i1 %5910, i32 %5897, i32 %5940
  %5942 = select i1 true, i32 %5941, i32 %5897
  store i32 %5942, ptr %current.token, align 4
  %5943 = load i32, ptr %current.token, align 4
  %5944 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1017)
  %5945 = load i32, ptr %ready.count, align 4
  %5946 = icmp uge i32 %5945, 8
  %5947 = and i1 %5944, %5946
  br i1 %5947, label %ready.overflow.trap989, label %ready.overflow.resume990

ready.overflow.trap989:                           ; preds = %convergence.overflow.resume988
  call void @llvm.trap()
  unreachable

ready.overflow.resume990:                         ; preds = %convergence.overflow.resume988
  %5948 = select i1 %5944, i32 %5945, i32 0
  %5949 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5948
  %5950 = load <8 x i1>, ptr %5949, align 1
  %5951 = select i1 %5944, <8 x i1> %1017, <8 x i1> %5950
  store <8 x i1> %5951, ptr %5949, align 1
  %5952 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5948
  %5953 = load i32, ptr %5952, align 4
  %5954 = select i1 %5944, i32 49, i32 %5953
  store i32 %5954, ptr %5952, align 4
  %5955 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5948
  %5956 = load i32, ptr %5955, align 4
  %5957 = select i1 %5944, i32 %5943, i32 %5956
  store i32 %5957, ptr %5955, align 4
  %5958 = add i32 %5945, 1
  %5959 = select i1 %5944, i32 %5958, i32 %5945
  store i32 %5959, ptr %ready.count, align 4
  %5960 = load <8 x i1>, ptr %runnable.mask, align 1
  %5961 = or <8 x i1> %5960, %1017
  store <8 x i1> %5961, ptr %runnable.mask, align 1
  store <8 x i1> %1019, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true991:                         ; preds = %varying.coherent986
  store <8 x i1> %1010, ptr %current.mask, align 1
  %5962 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1010)
  br i1 %5962, label %schedule.49, label %scheduler.loop

varying.coherent.false992:                        ; preds = %varying.coherent986
  store <8 x i1> %1010, ptr %current.mask, align 1
  %5963 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1010)
  br i1 %5963, label %schedule.52, label %scheduler.loop

varying.divergent999:                             ; preds = %schedule.49
  %5964 = load i32, ptr %current.token, align 4
  %5965 = icmp ne i32 %5964, 0
  %5966 = sub i32 %5964, 1
  %5967 = select i1 %5965, i32 %5966, i32 0
  %5968 = load i8, ptr %frame.active, align 1
  %5969 = trunc i32 %5967 to i8
  %5970 = shl i8 1, %5969
  %5971 = and i8 %5968, %5970
  %5972 = icmp ne i8 %5971, 0
  %5973 = load <8 x i32>, ptr %frame.static.id, align 32
  %5974 = extractelement <8 x i32> %5973, i32 %5967
  %5975 = icmp eq i32 %5974, 19
  %5976 = and i1 %5972, %5975
  %5977 = and i1 %5965, %5976
  %5978 = xor i1 %5977, true
  %5979 = and i1 true, %5978
  %5980 = xor i8 %5968, -1
  %5981 = icmp ne i8 %5980, 0
  %5982 = xor i1 %5981, true
  %5983 = and i1 %5979, %5982
  br i1 %5983, label %convergence.overflow.trap1001, label %convergence.overflow.resume1002

varying.coherent1000:                             ; preds = %schedule.49
  br i1 %1065, label %varying.coherent.true1005, label %varying.coherent.false1006

convergence.overflow.trap1001:                    ; preds = %varying.divergent999
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1002:                  ; preds = %varying.divergent999
  %5984 = call i8 @llvm.cttz.i8(i8 %5980, i1 false)
  %5985 = zext i8 %5984 to i32
  %5986 = select i1 %5981, i32 %5985, i32 0
  %5987 = trunc i32 %5986 to i8
  %5988 = shl i8 1, %5987
  %5989 = or i8 %5968, %5988
  %5990 = select i1 %5979, i8 %5989, i8 %5968
  store i8 %5990, ptr %frame.active, align 1
  %5991 = load <8 x i32>, ptr %frame.static.id, align 32
  %5992 = extractelement <8 x i32> %5991, i32 %5986
  %5993 = select i1 %5979, i32 19, i32 %5992
  %5994 = load <8 x i32>, ptr %frame.static.id, align 32
  %5995 = insertelement <8 x i32> %5994, i32 %5993, i32 %5986
  store <8 x i32> %5995, ptr %frame.static.id, align 32
  %5996 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5997 = extractelement <8 x i32> %5996, i32 %5986
  %5998 = select i1 %5979, i32 %5964, i32 %5997
  %5999 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6000 = insertelement <8 x i32> %5999, i32 %5998, i32 %5986
  store <8 x i32> %6000, ptr %frame.parent.token, align 32
  %6001 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5986
  %6002 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5986
  %6003 = load <8 x i1>, ptr %6001, align 1
  %6004 = load <8 x i1>, ptr %6002, align 1
  %6005 = select i1 %5979, <8 x i1> %1023, <8 x i1> %6003
  store <8 x i1> %6005, ptr %6001, align 1
  %6006 = select i1 %5979, <8 x i1> zeroinitializer, <8 x i1> %6004
  store <8 x i1> %6006, ptr %6002, align 1
  %6007 = add i32 %5986, 1
  %6008 = select i1 %5977, i32 %5964, i32 %6007
  %6009 = select i1 true, i32 %6008, i32 %5964
  store i32 %6009, ptr %current.token, align 4
  %6010 = load i32, ptr %current.token, align 4
  %6011 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1062)
  %6012 = load i32, ptr %ready.count, align 4
  %6013 = icmp uge i32 %6012, 8
  %6014 = and i1 %6011, %6013
  br i1 %6014, label %ready.overflow.trap1003, label %ready.overflow.resume1004

ready.overflow.trap1003:                          ; preds = %convergence.overflow.resume1002
  call void @llvm.trap()
  unreachable

ready.overflow.resume1004:                        ; preds = %convergence.overflow.resume1002
  %6015 = select i1 %6011, i32 %6012, i32 0
  %6016 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6015
  %6017 = load <8 x i1>, ptr %6016, align 1
  %6018 = select i1 %6011, <8 x i1> %1062, <8 x i1> %6017
  store <8 x i1> %6018, ptr %6016, align 1
  %6019 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6015
  %6020 = load i32, ptr %6019, align 4
  %6021 = select i1 %6011, i32 50, i32 %6020
  store i32 %6021, ptr %6019, align 4
  %6022 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6015
  %6023 = load i32, ptr %6022, align 4
  %6024 = select i1 %6011, i32 %6010, i32 %6023
  store i32 %6024, ptr %6022, align 4
  %6025 = add i32 %6012, 1
  %6026 = select i1 %6011, i32 %6025, i32 %6012
  store i32 %6026, ptr %ready.count, align 4
  %6027 = load <8 x i1>, ptr %runnable.mask, align 1
  %6028 = or <8 x i1> %6027, %1062
  store <8 x i1> %6028, ptr %runnable.mask, align 1
  store <8 x i1> %1064, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1005:                        ; preds = %varying.coherent1000
  store <8 x i1> %1023, ptr %current.mask, align 1
  %6029 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1023)
  br i1 %6029, label %schedule.50, label %scheduler.loop

varying.coherent.false1006:                       ; preds = %varying.coherent1000
  store <8 x i1> %1023, ptr %current.mask, align 1
  %6030 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1023)
  br i1 %6030, label %schedule.51, label %scheduler.loop

convergence.cascade1009:                          ; preds = %convergence.cascade1009, %schedule.51
  %convergence.cascade.flow1013 = phi <8 x i1> [ %1078, %schedule.51 ], [ %6073, %convergence.cascade1009 ]
  %convergence.cascade.depth1014 = phi i32 [ 0, %schedule.51 ], [ %6074, %convergence.cascade1009 ]
  %6031 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1013)
  %6032 = load i32, ptr %current.token, align 4
  %6033 = icmp ne i32 %6032, 0
  %6034 = and i1 %6031, %6033
  %6035 = sub i32 %6032, 1
  %6036 = select i1 %6034, i32 %6035, i32 0
  %6037 = load i8, ptr %frame.active, align 1
  %6038 = trunc i32 %6036 to i8
  %6039 = shl i8 1, %6038
  %6040 = and i8 %6037, %6039
  %6041 = icmp ne i8 %6040, 0
  %6042 = load <8 x i32>, ptr %frame.static.id, align 32
  %6043 = extractelement <8 x i32> %6042, i32 %6036
  %convergence.target.pointer1015 = getelementptr inbounds [20 x i32], ptr @convergence.targets, i32 0, i32 %6043
  %convergence.dynamic.target1016 = load i32, ptr %convergence.target.pointer1015, align 4
  %6044 = icmp eq i32 %convergence.dynamic.target1016, 51
  %6045 = and i1 %6041, %6044
  %6046 = and i1 %6034, %6045
  %6047 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6036
  %6048 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6036
  %6049 = load <8 x i1>, ptr %6047, align 1
  %6050 = load <8 x i1>, ptr %6048, align 1
  %6051 = or <8 x i1> %6050, %convergence.cascade.flow1013
  %6052 = load <8 x i1>, ptr %live.mask, align 1
  %6053 = and <8 x i1> %6049, %6052
  %6054 = icmp eq <8 x i1> %6051, %6053
  %6055 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6054)
  %6056 = and i1 %6046, %6055
  %6057 = select i1 %6056, <8 x i1> zeroinitializer, <8 x i1> %6051
  %6058 = select i1 %6046, <8 x i1> %6057, <8 x i1> %6050
  store <8 x i1> %6058, ptr %6048, align 1
  %6059 = select i1 %6056, <8 x i1> zeroinitializer, <8 x i1> %6049
  store <8 x i1> %6059, ptr %6047, align 1
  %6060 = trunc i32 %6036 to i8
  %6061 = shl i8 1, %6060
  %6062 = xor i8 %6061, -1
  %6063 = and i8 %6037, %6062
  %6064 = select i1 %6056, i8 %6063, i8 %6037
  store i8 %6064, ptr %frame.active, align 1
  %.splatinsert1017 = insertelement <8 x i1> poison, i1 %6046, i64 0
  %.splat1018 = shufflevector <8 x i1> %.splatinsert1017, <8 x i1> poison, <8 x i32> zeroinitializer
  %6065 = and <8 x i1> %convergence.cascade.flow1013, %.splat1018
  %6066 = load <8 x i1>, ptr %runnable.mask, align 1
  %6067 = xor <8 x i1> %6065, splat (i1 true)
  %6068 = and <8 x i1> %6066, %6067
  store <8 x i1> %6068, ptr %runnable.mask, align 1
  %.splatinsert1019 = insertelement <8 x i1> poison, i1 %6056, i64 0
  %.splat1020 = shufflevector <8 x i1> %.splatinsert1019, <8 x i1> poison, <8 x i32> zeroinitializer
  %6069 = select <8 x i1> %.splat1020, <8 x i1> %6051, <8 x i1> zeroinitializer
  %6070 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6071 = extractelement <8 x i32> %6070, i32 %6036
  %6072 = select i1 %6056, i32 %6071, i32 %6032
  store i32 %6072, ptr %current.token, align 4
  %.splatinsert1021 = insertelement <8 x i1> poison, i1 %6046, i64 0
  %.splat1022 = shufflevector <8 x i1> %.splatinsert1021, <8 x i1> poison, <8 x i32> zeroinitializer
  %6073 = select <8 x i1> %.splat1022, <8 x i1> %6069, <8 x i1> %convergence.cascade.flow1013
  %6074 = add i32 %convergence.cascade.depth1014, 1
  %6075 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6073)
  %6076 = icmp ult i32 %6074, 8
  %6077 = and i1 %6075, %6076
  %6078 = and i1 %6046, %6077
  %convergence.parent.token1023 = load i32, ptr %current.token, align 4
  %convergence.parent.present1024 = icmp ne i32 %convergence.parent.token1023, 0
  %6079 = and i1 %6078, %convergence.parent.present1024
  br i1 %6079, label %convergence.cascade1009, label %convergence.cascade.exit1010

convergence.cascade.exit1010:                     ; preds = %convergence.cascade1009, %schedule.51
  %convergence.cascade.result1025 = phi <8 x i1> [ %1078, %schedule.51 ], [ %6073, %convergence.cascade1009 ]
  %6080 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1025)
  br i1 %6080, label %convergence.target.51.ready, label %scheduler.loop

convergence.target.51.ready:                      ; preds = %convergence.cascade.exit1010
  %6081 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1025)
  %6082 = bitcast <8 x i1> %convergence.cascade.result1025 to i8
  %6083 = call i8 @llvm.cttz.i8(i8 %6082, i1 false)
  %6084 = zext i8 %6083 to i32
  %6085 = select i1 %6081, i32 %6084, i32 0
  %.state1026 = load <8 x i64>, ptr %.slot99, align 64
  %6086 = add <8 x i64> %.state1026, splat (i64 1)
  %6087 = load <8 x i64>, ptr %.slot99, align 64
  %6088 = select <8 x i1> %convergence.cascade.result1025, <8 x i64> %6086, <8 x i64> %6087
  store <8 x i64> %6088, ptr %.slot99, align 64
  store <8 x i1> %convergence.cascade.result1025, ptr %current.mask, align 1
  %6089 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1025)
  br i1 %6089, label %schedule.48, label %scheduler.loop

convergence.cascade1027:                          ; preds = %convergence.cascade1027, %schedule.52
  %convergence.cascade.flow1031 = phi <8 x i1> [ %1079, %schedule.52 ], [ %6132, %convergence.cascade1027 ]
  %convergence.cascade.depth1032 = phi i32 [ 0, %schedule.52 ], [ %6133, %convergence.cascade1027 ]
  %6090 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1031)
  %6091 = load i32, ptr %current.token, align 4
  %6092 = icmp ne i32 %6091, 0
  %6093 = and i1 %6090, %6092
  %6094 = sub i32 %6091, 1
  %6095 = select i1 %6093, i32 %6094, i32 0
  %6096 = load i8, ptr %frame.active, align 1
  %6097 = trunc i32 %6095 to i8
  %6098 = shl i8 1, %6097
  %6099 = and i8 %6096, %6098
  %6100 = icmp ne i8 %6099, 0
  %6101 = load <8 x i32>, ptr %frame.static.id, align 32
  %6102 = extractelement <8 x i32> %6101, i32 %6095
  %convergence.target.pointer1033 = getelementptr inbounds [20 x i32], ptr @convergence.targets, i32 0, i32 %6102
  %convergence.dynamic.target1034 = load i32, ptr %convergence.target.pointer1033, align 4
  %6103 = icmp eq i32 %convergence.dynamic.target1034, 52
  %6104 = and i1 %6100, %6103
  %6105 = and i1 %6093, %6104
  %6106 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6095
  %6107 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6095
  %6108 = load <8 x i1>, ptr %6106, align 1
  %6109 = load <8 x i1>, ptr %6107, align 1
  %6110 = or <8 x i1> %6109, %convergence.cascade.flow1031
  %6111 = load <8 x i1>, ptr %live.mask, align 1
  %6112 = and <8 x i1> %6108, %6111
  %6113 = icmp eq <8 x i1> %6110, %6112
  %6114 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6113)
  %6115 = and i1 %6105, %6114
  %6116 = select i1 %6115, <8 x i1> zeroinitializer, <8 x i1> %6110
  %6117 = select i1 %6105, <8 x i1> %6116, <8 x i1> %6109
  store <8 x i1> %6117, ptr %6107, align 1
  %6118 = select i1 %6115, <8 x i1> zeroinitializer, <8 x i1> %6108
  store <8 x i1> %6118, ptr %6106, align 1
  %6119 = trunc i32 %6095 to i8
  %6120 = shl i8 1, %6119
  %6121 = xor i8 %6120, -1
  %6122 = and i8 %6096, %6121
  %6123 = select i1 %6115, i8 %6122, i8 %6096
  store i8 %6123, ptr %frame.active, align 1
  %.splatinsert1035 = insertelement <8 x i1> poison, i1 %6105, i64 0
  %.splat1036 = shufflevector <8 x i1> %.splatinsert1035, <8 x i1> poison, <8 x i32> zeroinitializer
  %6124 = and <8 x i1> %convergence.cascade.flow1031, %.splat1036
  %6125 = load <8 x i1>, ptr %runnable.mask, align 1
  %6126 = xor <8 x i1> %6124, splat (i1 true)
  %6127 = and <8 x i1> %6125, %6126
  store <8 x i1> %6127, ptr %runnable.mask, align 1
  %.splatinsert1037 = insertelement <8 x i1> poison, i1 %6115, i64 0
  %.splat1038 = shufflevector <8 x i1> %.splatinsert1037, <8 x i1> poison, <8 x i32> zeroinitializer
  %6128 = select <8 x i1> %.splat1038, <8 x i1> %6110, <8 x i1> zeroinitializer
  %6129 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6130 = extractelement <8 x i32> %6129, i32 %6095
  %6131 = select i1 %6115, i32 %6130, i32 %6091
  store i32 %6131, ptr %current.token, align 4
  %.splatinsert1039 = insertelement <8 x i1> poison, i1 %6105, i64 0
  %.splat1040 = shufflevector <8 x i1> %.splatinsert1039, <8 x i1> poison, <8 x i32> zeroinitializer
  %6132 = select <8 x i1> %.splat1040, <8 x i1> %6128, <8 x i1> %convergence.cascade.flow1031
  %6133 = add i32 %convergence.cascade.depth1032, 1
  %6134 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6132)
  %6135 = icmp ult i32 %6133, 8
  %6136 = and i1 %6134, %6135
  %6137 = and i1 %6105, %6136
  %convergence.parent.token1041 = load i32, ptr %current.token, align 4
  %convergence.parent.present1042 = icmp ne i32 %convergence.parent.token1041, 0
  %6138 = and i1 %6137, %convergence.parent.present1042
  br i1 %6138, label %convergence.cascade1027, label %convergence.cascade.exit1028

convergence.cascade.exit1028:                     ; preds = %convergence.cascade1027, %schedule.52
  %convergence.cascade.result1043 = phi <8 x i1> [ %1079, %schedule.52 ], [ %6132, %convergence.cascade1027 ]
  %6139 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1043)
  br i1 %6139, label %convergence.target.52.ready, label %scheduler.loop

convergence.target.52.ready:                      ; preds = %convergence.cascade.exit1028
  %6140 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1043)
  %6141 = bitcast <8 x i1> %convergence.cascade.result1043 to i8
  %6142 = call i8 @llvm.cttz.i8(i8 %6141, i1 false)
  %6143 = zext i8 %6142 to i32
  %6144 = select i1 %6140, i32 %6143, i32 0
  %tile_snapshot.spill.load1044 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %6145 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1044, 0
  %6146 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1044, 1
  %6147 = add <8 x i64> %6146, splat (i64 992)
  %6148 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6145, 0
  %6149 = insertvalue { <8 x ptr>, <8 x i64> } %6148, <8 x i64> %6147, 1
  %6150 = extractvalue { <8 x ptr>, <8 x i64> } %33, 0
  %6151 = extractvalue { <8 x ptr>, <8 x i64> } %6149, 1
  %6152 = extractelement <8 x ptr> %6150, i32 0
  %6153 = extractelement <8 x i64> %6151, i32 %6144
  %6154 = zext i32 %6144 to i64
  %6155 = mul i64 %6154, 4
  %6156 = sub i64 %6153, %6155
  %6157 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1043)
  %6158 = select i1 %6157, i64 %6156, i64 0
  %private.contiguous.address1045 = getelementptr i8, ptr %6152, i64 %6158
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address1045, align 4
  %6159 = select <8 x i1> %convergence.cascade.result1043, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load1046 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %6160 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1046, 0
  %6161 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1046, 1
  %6162 = add <8 x i64> %6161, splat (i64 2016)
  %6163 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6160, 0
  %6164 = insertvalue { <8 x ptr>, <8 x i64> } %6163, <8 x i64> %6162, 1
  %6165 = extractvalue { <8 x ptr>, <8 x i64> } %33, 0
  %6166 = extractvalue { <8 x ptr>, <8 x i64> } %6164, 1
  %6167 = extractelement <8 x ptr> %6165, i32 0
  %6168 = extractelement <8 x i64> %6166, i32 %6144
  %6169 = zext i32 %6144 to i64
  %6170 = mul i64 %6169, 4
  %6171 = sub i64 %6168, %6170
  %6172 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1043)
  %6173 = select i1 %6172, i64 %6171, i64 0
  %private.contiguous.address1047 = getelementptr i8, ptr %6167, i64 %6173
  %private.contiguous.load1048 = load <8 x float>, ptr %private.contiguous.address1047, align 4
  %6174 = select <8 x i1> %convergence.cascade.result1043, <8 x float> %private.contiguous.load1048, <8 x float> zeroinitializer
  %tile_snapshot.spill.load1049 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %6175 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1049, 0
  %6176 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1049, 1
  %6177 = add <8 x i64> %6176, splat (i64 3040)
  %6178 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6175, 0
  %6179 = insertvalue { <8 x ptr>, <8 x i64> } %6178, <8 x i64> %6177, 1
  %6180 = extractvalue { <8 x ptr>, <8 x i64> } %33, 0
  %6181 = extractvalue { <8 x ptr>, <8 x i64> } %6179, 1
  %6182 = extractelement <8 x ptr> %6180, i32 0
  %6183 = extractelement <8 x i64> %6181, i32 %6144
  %6184 = zext i32 %6144 to i64
  %6185 = mul i64 %6184, 4
  %6186 = sub i64 %6183, %6185
  %6187 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1043)
  %6188 = select i1 %6187, i64 %6186, i64 0
  %private.contiguous.address1050 = getelementptr i8, ptr %6182, i64 %6188
  %private.contiguous.load1051 = load <8 x float>, ptr %private.contiguous.address1050, align 4
  %6189 = select <8 x i1> %convergence.cascade.result1043, <8 x float> %private.contiguous.load1051, <8 x float> zeroinitializer
  %tile_snapshot.spill.load1052 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %6190 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1052, 0
  %6191 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1052, 1
  %6192 = add <8 x i64> %6191, splat (i64 4064)
  %6193 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6190, 0
  %6194 = insertvalue { <8 x ptr>, <8 x i64> } %6193, <8 x i64> %6192, 1
  %6195 = extractvalue { <8 x ptr>, <8 x i64> } %33, 0
  %6196 = extractvalue { <8 x ptr>, <8 x i64> } %6194, 1
  %6197 = extractelement <8 x ptr> %6195, i32 0
  %6198 = extractelement <8 x i64> %6196, i32 %6144
  %6199 = zext i32 %6144 to i64
  %6200 = mul i64 %6199, 4
  %6201 = sub i64 %6198, %6200
  %6202 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1043)
  %6203 = select i1 %6202, i64 %6201, i64 0
  %private.contiguous.address1053 = getelementptr i8, ptr %6197, i64 %6203
  %private.contiguous.load1054 = load <8 x float>, ptr %private.contiguous.address1053, align 4
  %6204 = select <8 x i1> %convergence.cascade.result1043, <8 x float> %private.contiguous.load1054, <8 x float> zeroinitializer
  %.state1055 = load <8 x i64>, ptr %.slot, align 64
  %6205 = add <8 x i64> %.state1055, splat (i64 1)
  %6206 = load <8 x i64>, ptr %.slot, align 64
  %6207 = select <8 x i1> %convergence.cascade.result1043, <8 x i64> %6205, <8 x i64> %6206
  store <8 x i64> %6207, ptr %.slot, align 64
  %6208 = load volatile <8 x float>, ptr %.slot50, align 32
  %6209 = select <8 x i1> %convergence.cascade.result1043, <8 x float> %6159, <8 x float> %6208
  store volatile <8 x float> %6209, ptr %.slot50, align 32
  %6210 = load volatile <8 x float>, ptr %.slot51, align 32
  %6211 = select <8 x i1> %convergence.cascade.result1043, <8 x float> %6174, <8 x float> %6210
  store volatile <8 x float> %6211, ptr %.slot51, align 32
  %6212 = load volatile <8 x float>, ptr %.slot52, align 32
  %6213 = select <8 x i1> %convergence.cascade.result1043, <8 x float> %6189, <8 x float> %6212
  store volatile <8 x float> %6213, ptr %.slot52, align 32
  %6214 = load volatile <8 x float>, ptr %.slot53, align 32
  %6215 = select <8 x i1> %convergence.cascade.result1043, <8 x float> %6204, <8 x float> %6214
  store volatile <8 x float> %6215, ptr %.slot53, align 32
  store <8 x i1> %convergence.cascade.result1043, ptr %current.mask, align 1
  %6216 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1043)
  br i1 %6216, label %schedule.1, label %scheduler.loop

convergence.cascade1056:                          ; preds = %convergence.cascade1056, %schedule.53
  %convergence.cascade.flow1060 = phi <8 x i1> [ %1080, %schedule.53 ], [ %6259, %convergence.cascade1056 ]
  %convergence.cascade.depth1061 = phi i32 [ 0, %schedule.53 ], [ %6260, %convergence.cascade1056 ]
  %6217 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1060)
  %6218 = load i32, ptr %current.token, align 4
  %6219 = icmp ne i32 %6218, 0
  %6220 = and i1 %6217, %6219
  %6221 = sub i32 %6218, 1
  %6222 = select i1 %6220, i32 %6221, i32 0
  %6223 = load i8, ptr %frame.active, align 1
  %6224 = trunc i32 %6222 to i8
  %6225 = shl i8 1, %6224
  %6226 = and i8 %6223, %6225
  %6227 = icmp ne i8 %6226, 0
  %6228 = load <8 x i32>, ptr %frame.static.id, align 32
  %6229 = extractelement <8 x i32> %6228, i32 %6222
  %convergence.target.pointer1062 = getelementptr inbounds [20 x i32], ptr @convergence.targets, i32 0, i32 %6229
  %convergence.dynamic.target1063 = load i32, ptr %convergence.target.pointer1062, align 4
  %6230 = icmp eq i32 %convergence.dynamic.target1063, 53
  %6231 = and i1 %6227, %6230
  %6232 = and i1 %6220, %6231
  %6233 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6222
  %6234 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6222
  %6235 = load <8 x i1>, ptr %6233, align 1
  %6236 = load <8 x i1>, ptr %6234, align 1
  %6237 = or <8 x i1> %6236, %convergence.cascade.flow1060
  %6238 = load <8 x i1>, ptr %live.mask, align 1
  %6239 = and <8 x i1> %6235, %6238
  %6240 = icmp eq <8 x i1> %6237, %6239
  %6241 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6240)
  %6242 = and i1 %6232, %6241
  %6243 = select i1 %6242, <8 x i1> zeroinitializer, <8 x i1> %6237
  %6244 = select i1 %6232, <8 x i1> %6243, <8 x i1> %6236
  store <8 x i1> %6244, ptr %6234, align 1
  %6245 = select i1 %6242, <8 x i1> zeroinitializer, <8 x i1> %6235
  store <8 x i1> %6245, ptr %6233, align 1
  %6246 = trunc i32 %6222 to i8
  %6247 = shl i8 1, %6246
  %6248 = xor i8 %6247, -1
  %6249 = and i8 %6223, %6248
  %6250 = select i1 %6242, i8 %6249, i8 %6223
  store i8 %6250, ptr %frame.active, align 1
  %.splatinsert1064 = insertelement <8 x i1> poison, i1 %6232, i64 0
  %.splat1065 = shufflevector <8 x i1> %.splatinsert1064, <8 x i1> poison, <8 x i32> zeroinitializer
  %6251 = and <8 x i1> %convergence.cascade.flow1060, %.splat1065
  %6252 = load <8 x i1>, ptr %runnable.mask, align 1
  %6253 = xor <8 x i1> %6251, splat (i1 true)
  %6254 = and <8 x i1> %6252, %6253
  store <8 x i1> %6254, ptr %runnable.mask, align 1
  %.splatinsert1066 = insertelement <8 x i1> poison, i1 %6242, i64 0
  %.splat1067 = shufflevector <8 x i1> %.splatinsert1066, <8 x i1> poison, <8 x i32> zeroinitializer
  %6255 = select <8 x i1> %.splat1067, <8 x i1> %6237, <8 x i1> zeroinitializer
  %6256 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6257 = extractelement <8 x i32> %6256, i32 %6222
  %6258 = select i1 %6242, i32 %6257, i32 %6218
  store i32 %6258, ptr %current.token, align 4
  %.splatinsert1068 = insertelement <8 x i1> poison, i1 %6232, i64 0
  %.splat1069 = shufflevector <8 x i1> %.splatinsert1068, <8 x i1> poison, <8 x i32> zeroinitializer
  %6259 = select <8 x i1> %.splat1069, <8 x i1> %6255, <8 x i1> %convergence.cascade.flow1060
  %6260 = add i32 %convergence.cascade.depth1061, 1
  %6261 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6259)
  %6262 = icmp ult i32 %6260, 8
  %6263 = and i1 %6261, %6262
  %6264 = and i1 %6232, %6263
  %convergence.parent.token1070 = load i32, ptr %current.token, align 4
  %convergence.parent.present1071 = icmp ne i32 %convergence.parent.token1070, 0
  %6265 = and i1 %6264, %convergence.parent.present1071
  br i1 %6265, label %convergence.cascade1056, label %convergence.cascade.exit1057

convergence.cascade.exit1057:                     ; preds = %convergence.cascade1056, %schedule.53
  %convergence.cascade.result1072 = phi <8 x i1> [ %1080, %schedule.53 ], [ %6259, %convergence.cascade1056 ]
  %6266 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1072)
  br i1 %6266, label %convergence.target.53.ready, label %scheduler.loop

convergence.target.53.ready:                      ; preds = %convergence.cascade.exit1057
  %6267 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1072)
  %6268 = bitcast <8 x i1> %convergence.cascade.result1072 to i8
  %6269 = call i8 @llvm.cttz.i8(i8 %6268, i1 false)
  %6270 = zext i8 %6269 to i32
  %6271 = select i1 %6267, i32 %6270, i32 0
  %6272 = load <8 x i1>, ptr %live.mask, align 1
  %6273 = xor <8 x i1> %convergence.cascade.result1072, splat (i1 true)
  %6274 = and <8 x i1> %6272, %6273
  store <8 x i1> %6274, ptr %live.mask, align 1
  %6275 = load <8 x i1>, ptr %runnable.mask, align 1
  %6276 = xor <8 x i1> %convergence.cascade.result1072, splat (i1 true)
  %6277 = and <8 x i1> %6275, %6276
  store <8 x i1> %6277, ptr %runnable.mask, align 1
  %return.active.frames = load i8, ptr %frame.active, align 1
  %return.frames.present = icmp ne i8 %return.active.frames, 0
  br i1 %return.frames.present, label %return.frame.cleanup, label %return.frame.cleanup.done

return.frame.cleanup:                             ; preds = %convergence.target.53.ready
  %6278 = load i8, ptr %frame.active, align 1
  %6279 = and i8 %6278, 1
  %6280 = icmp ne i8 %6279, 0
  %6281 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 0
  %6282 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 0
  %6283 = load <8 x i1>, ptr %6281, align 1
  %6284 = load <8 x i1>, ptr %6282, align 1
  %6285 = and <8 x i1> %6283, %6274
  %6286 = icmp eq <8 x i1> %6284, %6285
  %6287 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6286)
  %6288 = and i1 %6280, %6287
  %.splatinsert1073 = insertelement <8 x i1> poison, i1 %6288, i64 0
  %.splat1074 = shufflevector <8 x i1> %.splatinsert1073, <8 x i1> poison, <8 x i32> zeroinitializer
  %6289 = select <8 x i1> %.splat1074, <8 x i1> %6284, <8 x i1> zeroinitializer
  %6290 = select i1 %6288, <8 x i1> zeroinitializer, <8 x i1> %6285
  store <8 x i1> %6290, ptr %6281, align 1
  %6291 = select i1 %6288, <8 x i1> zeroinitializer, <8 x i1> %6284
  store <8 x i1> %6291, ptr %6282, align 1
  %6292 = and i8 %6278, -2
  %6293 = select i1 %6288, i8 %6292, i8 %6278
  store i8 %6293, ptr %frame.active, align 1
  %6294 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6295 = extractelement <8 x i32> %6294, i32 0
  %6296 = load <8 x i32>, ptr %frame.static.id, align 32
  %6297 = extractelement <8 x i32> %6296, i32 0
  %convergence.target.pointer1075 = getelementptr inbounds [20 x i32], ptr @convergence.targets, i32 0, i32 %6297
  %convergence.dynamic.target1076 = load i32, ptr %convergence.target.pointer1075, align 4
  %6298 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6289)
  %6299 = load i32, ptr %ready.count, align 4
  %6300 = icmp uge i32 %6299, 8
  %6301 = and i1 %6298, %6300
  br i1 %6301, label %ready.overflow.trap1077, label %ready.overflow.resume1078

return.frame.cleanup.done:                        ; preds = %ready.overflow.resume1120, %convergence.target.53.ready
  br label %scheduler.loop

ready.overflow.trap1077:                          ; preds = %return.frame.cleanup
  call void @llvm.trap()
  unreachable

ready.overflow.resume1078:                        ; preds = %return.frame.cleanup
  %6302 = select i1 %6298, i32 %6299, i32 0
  %6303 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6302
  %6304 = load <8 x i1>, ptr %6303, align 1
  %6305 = select i1 %6298, <8 x i1> %6289, <8 x i1> %6304
  store <8 x i1> %6305, ptr %6303, align 1
  %6306 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6302
  %6307 = load i32, ptr %6306, align 4
  %6308 = select i1 %6298, i32 %convergence.dynamic.target1076, i32 %6307
  store i32 %6308, ptr %6306, align 4
  %6309 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6302
  %6310 = load i32, ptr %6309, align 4
  %6311 = select i1 %6298, i32 %6295, i32 %6310
  store i32 %6311, ptr %6309, align 4
  %6312 = add i32 %6299, 1
  %6313 = select i1 %6298, i32 %6312, i32 %6299
  store i32 %6313, ptr %ready.count, align 4
  %6314 = load <8 x i1>, ptr %runnable.mask, align 1
  %6315 = or <8 x i1> %6314, %6289
  store <8 x i1> %6315, ptr %runnable.mask, align 1
  %6316 = load i8, ptr %frame.active, align 1
  %6317 = and i8 %6316, 2
  %6318 = icmp ne i8 %6317, 0
  %6319 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 1
  %6320 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 1
  %6321 = load <8 x i1>, ptr %6319, align 1
  %6322 = load <8 x i1>, ptr %6320, align 1
  %6323 = and <8 x i1> %6321, %6274
  %6324 = icmp eq <8 x i1> %6322, %6323
  %6325 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6324)
  %6326 = and i1 %6318, %6325
  %.splatinsert1079 = insertelement <8 x i1> poison, i1 %6326, i64 0
  %.splat1080 = shufflevector <8 x i1> %.splatinsert1079, <8 x i1> poison, <8 x i32> zeroinitializer
  %6327 = select <8 x i1> %.splat1080, <8 x i1> %6322, <8 x i1> zeroinitializer
  %6328 = select i1 %6326, <8 x i1> zeroinitializer, <8 x i1> %6323
  store <8 x i1> %6328, ptr %6319, align 1
  %6329 = select i1 %6326, <8 x i1> zeroinitializer, <8 x i1> %6322
  store <8 x i1> %6329, ptr %6320, align 1
  %6330 = and i8 %6316, -3
  %6331 = select i1 %6326, i8 %6330, i8 %6316
  store i8 %6331, ptr %frame.active, align 1
  %6332 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6333 = extractelement <8 x i32> %6332, i32 1
  %6334 = load <8 x i32>, ptr %frame.static.id, align 32
  %6335 = extractelement <8 x i32> %6334, i32 1
  %convergence.target.pointer1081 = getelementptr inbounds [20 x i32], ptr @convergence.targets, i32 0, i32 %6335
  %convergence.dynamic.target1082 = load i32, ptr %convergence.target.pointer1081, align 4
  %6336 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6327)
  %6337 = load i32, ptr %ready.count, align 4
  %6338 = icmp uge i32 %6337, 8
  %6339 = and i1 %6336, %6338
  br i1 %6339, label %ready.overflow.trap1083, label %ready.overflow.resume1084

ready.overflow.trap1083:                          ; preds = %ready.overflow.resume1078
  call void @llvm.trap()
  unreachable

ready.overflow.resume1084:                        ; preds = %ready.overflow.resume1078
  %6340 = select i1 %6336, i32 %6337, i32 0
  %6341 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6340
  %6342 = load <8 x i1>, ptr %6341, align 1
  %6343 = select i1 %6336, <8 x i1> %6327, <8 x i1> %6342
  store <8 x i1> %6343, ptr %6341, align 1
  %6344 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6340
  %6345 = load i32, ptr %6344, align 4
  %6346 = select i1 %6336, i32 %convergence.dynamic.target1082, i32 %6345
  store i32 %6346, ptr %6344, align 4
  %6347 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6340
  %6348 = load i32, ptr %6347, align 4
  %6349 = select i1 %6336, i32 %6333, i32 %6348
  store i32 %6349, ptr %6347, align 4
  %6350 = add i32 %6337, 1
  %6351 = select i1 %6336, i32 %6350, i32 %6337
  store i32 %6351, ptr %ready.count, align 4
  %6352 = load <8 x i1>, ptr %runnable.mask, align 1
  %6353 = or <8 x i1> %6352, %6327
  store <8 x i1> %6353, ptr %runnable.mask, align 1
  %6354 = load i8, ptr %frame.active, align 1
  %6355 = and i8 %6354, 4
  %6356 = icmp ne i8 %6355, 0
  %6357 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 2
  %6358 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 2
  %6359 = load <8 x i1>, ptr %6357, align 1
  %6360 = load <8 x i1>, ptr %6358, align 1
  %6361 = and <8 x i1> %6359, %6274
  %6362 = icmp eq <8 x i1> %6360, %6361
  %6363 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6362)
  %6364 = and i1 %6356, %6363
  %.splatinsert1085 = insertelement <8 x i1> poison, i1 %6364, i64 0
  %.splat1086 = shufflevector <8 x i1> %.splatinsert1085, <8 x i1> poison, <8 x i32> zeroinitializer
  %6365 = select <8 x i1> %.splat1086, <8 x i1> %6360, <8 x i1> zeroinitializer
  %6366 = select i1 %6364, <8 x i1> zeroinitializer, <8 x i1> %6361
  store <8 x i1> %6366, ptr %6357, align 1
  %6367 = select i1 %6364, <8 x i1> zeroinitializer, <8 x i1> %6360
  store <8 x i1> %6367, ptr %6358, align 1
  %6368 = and i8 %6354, -5
  %6369 = select i1 %6364, i8 %6368, i8 %6354
  store i8 %6369, ptr %frame.active, align 1
  %6370 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6371 = extractelement <8 x i32> %6370, i32 2
  %6372 = load <8 x i32>, ptr %frame.static.id, align 32
  %6373 = extractelement <8 x i32> %6372, i32 2
  %convergence.target.pointer1087 = getelementptr inbounds [20 x i32], ptr @convergence.targets, i32 0, i32 %6373
  %convergence.dynamic.target1088 = load i32, ptr %convergence.target.pointer1087, align 4
  %6374 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6365)
  %6375 = load i32, ptr %ready.count, align 4
  %6376 = icmp uge i32 %6375, 8
  %6377 = and i1 %6374, %6376
  br i1 %6377, label %ready.overflow.trap1089, label %ready.overflow.resume1090

ready.overflow.trap1089:                          ; preds = %ready.overflow.resume1084
  call void @llvm.trap()
  unreachable

ready.overflow.resume1090:                        ; preds = %ready.overflow.resume1084
  %6378 = select i1 %6374, i32 %6375, i32 0
  %6379 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6378
  %6380 = load <8 x i1>, ptr %6379, align 1
  %6381 = select i1 %6374, <8 x i1> %6365, <8 x i1> %6380
  store <8 x i1> %6381, ptr %6379, align 1
  %6382 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6378
  %6383 = load i32, ptr %6382, align 4
  %6384 = select i1 %6374, i32 %convergence.dynamic.target1088, i32 %6383
  store i32 %6384, ptr %6382, align 4
  %6385 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6378
  %6386 = load i32, ptr %6385, align 4
  %6387 = select i1 %6374, i32 %6371, i32 %6386
  store i32 %6387, ptr %6385, align 4
  %6388 = add i32 %6375, 1
  %6389 = select i1 %6374, i32 %6388, i32 %6375
  store i32 %6389, ptr %ready.count, align 4
  %6390 = load <8 x i1>, ptr %runnable.mask, align 1
  %6391 = or <8 x i1> %6390, %6365
  store <8 x i1> %6391, ptr %runnable.mask, align 1
  %6392 = load i8, ptr %frame.active, align 1
  %6393 = and i8 %6392, 8
  %6394 = icmp ne i8 %6393, 0
  %6395 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 3
  %6396 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 3
  %6397 = load <8 x i1>, ptr %6395, align 1
  %6398 = load <8 x i1>, ptr %6396, align 1
  %6399 = and <8 x i1> %6397, %6274
  %6400 = icmp eq <8 x i1> %6398, %6399
  %6401 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6400)
  %6402 = and i1 %6394, %6401
  %.splatinsert1091 = insertelement <8 x i1> poison, i1 %6402, i64 0
  %.splat1092 = shufflevector <8 x i1> %.splatinsert1091, <8 x i1> poison, <8 x i32> zeroinitializer
  %6403 = select <8 x i1> %.splat1092, <8 x i1> %6398, <8 x i1> zeroinitializer
  %6404 = select i1 %6402, <8 x i1> zeroinitializer, <8 x i1> %6399
  store <8 x i1> %6404, ptr %6395, align 1
  %6405 = select i1 %6402, <8 x i1> zeroinitializer, <8 x i1> %6398
  store <8 x i1> %6405, ptr %6396, align 1
  %6406 = and i8 %6392, -9
  %6407 = select i1 %6402, i8 %6406, i8 %6392
  store i8 %6407, ptr %frame.active, align 1
  %6408 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6409 = extractelement <8 x i32> %6408, i32 3
  %6410 = load <8 x i32>, ptr %frame.static.id, align 32
  %6411 = extractelement <8 x i32> %6410, i32 3
  %convergence.target.pointer1093 = getelementptr inbounds [20 x i32], ptr @convergence.targets, i32 0, i32 %6411
  %convergence.dynamic.target1094 = load i32, ptr %convergence.target.pointer1093, align 4
  %6412 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6403)
  %6413 = load i32, ptr %ready.count, align 4
  %6414 = icmp uge i32 %6413, 8
  %6415 = and i1 %6412, %6414
  br i1 %6415, label %ready.overflow.trap1095, label %ready.overflow.resume1096

ready.overflow.trap1095:                          ; preds = %ready.overflow.resume1090
  call void @llvm.trap()
  unreachable

ready.overflow.resume1096:                        ; preds = %ready.overflow.resume1090
  %6416 = select i1 %6412, i32 %6413, i32 0
  %6417 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6416
  %6418 = load <8 x i1>, ptr %6417, align 1
  %6419 = select i1 %6412, <8 x i1> %6403, <8 x i1> %6418
  store <8 x i1> %6419, ptr %6417, align 1
  %6420 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6416
  %6421 = load i32, ptr %6420, align 4
  %6422 = select i1 %6412, i32 %convergence.dynamic.target1094, i32 %6421
  store i32 %6422, ptr %6420, align 4
  %6423 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6416
  %6424 = load i32, ptr %6423, align 4
  %6425 = select i1 %6412, i32 %6409, i32 %6424
  store i32 %6425, ptr %6423, align 4
  %6426 = add i32 %6413, 1
  %6427 = select i1 %6412, i32 %6426, i32 %6413
  store i32 %6427, ptr %ready.count, align 4
  %6428 = load <8 x i1>, ptr %runnable.mask, align 1
  %6429 = or <8 x i1> %6428, %6403
  store <8 x i1> %6429, ptr %runnable.mask, align 1
  %6430 = load i8, ptr %frame.active, align 1
  %6431 = and i8 %6430, 16
  %6432 = icmp ne i8 %6431, 0
  %6433 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 4
  %6434 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 4
  %6435 = load <8 x i1>, ptr %6433, align 1
  %6436 = load <8 x i1>, ptr %6434, align 1
  %6437 = and <8 x i1> %6435, %6274
  %6438 = icmp eq <8 x i1> %6436, %6437
  %6439 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6438)
  %6440 = and i1 %6432, %6439
  %.splatinsert1097 = insertelement <8 x i1> poison, i1 %6440, i64 0
  %.splat1098 = shufflevector <8 x i1> %.splatinsert1097, <8 x i1> poison, <8 x i32> zeroinitializer
  %6441 = select <8 x i1> %.splat1098, <8 x i1> %6436, <8 x i1> zeroinitializer
  %6442 = select i1 %6440, <8 x i1> zeroinitializer, <8 x i1> %6437
  store <8 x i1> %6442, ptr %6433, align 1
  %6443 = select i1 %6440, <8 x i1> zeroinitializer, <8 x i1> %6436
  store <8 x i1> %6443, ptr %6434, align 1
  %6444 = and i8 %6430, -17
  %6445 = select i1 %6440, i8 %6444, i8 %6430
  store i8 %6445, ptr %frame.active, align 1
  %6446 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6447 = extractelement <8 x i32> %6446, i32 4
  %6448 = load <8 x i32>, ptr %frame.static.id, align 32
  %6449 = extractelement <8 x i32> %6448, i32 4
  %convergence.target.pointer1099 = getelementptr inbounds [20 x i32], ptr @convergence.targets, i32 0, i32 %6449
  %convergence.dynamic.target1100 = load i32, ptr %convergence.target.pointer1099, align 4
  %6450 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6441)
  %6451 = load i32, ptr %ready.count, align 4
  %6452 = icmp uge i32 %6451, 8
  %6453 = and i1 %6450, %6452
  br i1 %6453, label %ready.overflow.trap1101, label %ready.overflow.resume1102

ready.overflow.trap1101:                          ; preds = %ready.overflow.resume1096
  call void @llvm.trap()
  unreachable

ready.overflow.resume1102:                        ; preds = %ready.overflow.resume1096
  %6454 = select i1 %6450, i32 %6451, i32 0
  %6455 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6454
  %6456 = load <8 x i1>, ptr %6455, align 1
  %6457 = select i1 %6450, <8 x i1> %6441, <8 x i1> %6456
  store <8 x i1> %6457, ptr %6455, align 1
  %6458 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6454
  %6459 = load i32, ptr %6458, align 4
  %6460 = select i1 %6450, i32 %convergence.dynamic.target1100, i32 %6459
  store i32 %6460, ptr %6458, align 4
  %6461 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6454
  %6462 = load i32, ptr %6461, align 4
  %6463 = select i1 %6450, i32 %6447, i32 %6462
  store i32 %6463, ptr %6461, align 4
  %6464 = add i32 %6451, 1
  %6465 = select i1 %6450, i32 %6464, i32 %6451
  store i32 %6465, ptr %ready.count, align 4
  %6466 = load <8 x i1>, ptr %runnable.mask, align 1
  %6467 = or <8 x i1> %6466, %6441
  store <8 x i1> %6467, ptr %runnable.mask, align 1
  %6468 = load i8, ptr %frame.active, align 1
  %6469 = and i8 %6468, 32
  %6470 = icmp ne i8 %6469, 0
  %6471 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 5
  %6472 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 5
  %6473 = load <8 x i1>, ptr %6471, align 1
  %6474 = load <8 x i1>, ptr %6472, align 1
  %6475 = and <8 x i1> %6473, %6274
  %6476 = icmp eq <8 x i1> %6474, %6475
  %6477 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6476)
  %6478 = and i1 %6470, %6477
  %.splatinsert1103 = insertelement <8 x i1> poison, i1 %6478, i64 0
  %.splat1104 = shufflevector <8 x i1> %.splatinsert1103, <8 x i1> poison, <8 x i32> zeroinitializer
  %6479 = select <8 x i1> %.splat1104, <8 x i1> %6474, <8 x i1> zeroinitializer
  %6480 = select i1 %6478, <8 x i1> zeroinitializer, <8 x i1> %6475
  store <8 x i1> %6480, ptr %6471, align 1
  %6481 = select i1 %6478, <8 x i1> zeroinitializer, <8 x i1> %6474
  store <8 x i1> %6481, ptr %6472, align 1
  %6482 = and i8 %6468, -33
  %6483 = select i1 %6478, i8 %6482, i8 %6468
  store i8 %6483, ptr %frame.active, align 1
  %6484 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6485 = extractelement <8 x i32> %6484, i32 5
  %6486 = load <8 x i32>, ptr %frame.static.id, align 32
  %6487 = extractelement <8 x i32> %6486, i32 5
  %convergence.target.pointer1105 = getelementptr inbounds [20 x i32], ptr @convergence.targets, i32 0, i32 %6487
  %convergence.dynamic.target1106 = load i32, ptr %convergence.target.pointer1105, align 4
  %6488 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6479)
  %6489 = load i32, ptr %ready.count, align 4
  %6490 = icmp uge i32 %6489, 8
  %6491 = and i1 %6488, %6490
  br i1 %6491, label %ready.overflow.trap1107, label %ready.overflow.resume1108

ready.overflow.trap1107:                          ; preds = %ready.overflow.resume1102
  call void @llvm.trap()
  unreachable

ready.overflow.resume1108:                        ; preds = %ready.overflow.resume1102
  %6492 = select i1 %6488, i32 %6489, i32 0
  %6493 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6492
  %6494 = load <8 x i1>, ptr %6493, align 1
  %6495 = select i1 %6488, <8 x i1> %6479, <8 x i1> %6494
  store <8 x i1> %6495, ptr %6493, align 1
  %6496 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6492
  %6497 = load i32, ptr %6496, align 4
  %6498 = select i1 %6488, i32 %convergence.dynamic.target1106, i32 %6497
  store i32 %6498, ptr %6496, align 4
  %6499 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6492
  %6500 = load i32, ptr %6499, align 4
  %6501 = select i1 %6488, i32 %6485, i32 %6500
  store i32 %6501, ptr %6499, align 4
  %6502 = add i32 %6489, 1
  %6503 = select i1 %6488, i32 %6502, i32 %6489
  store i32 %6503, ptr %ready.count, align 4
  %6504 = load <8 x i1>, ptr %runnable.mask, align 1
  %6505 = or <8 x i1> %6504, %6479
  store <8 x i1> %6505, ptr %runnable.mask, align 1
  %6506 = load i8, ptr %frame.active, align 1
  %6507 = and i8 %6506, 64
  %6508 = icmp ne i8 %6507, 0
  %6509 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 6
  %6510 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 6
  %6511 = load <8 x i1>, ptr %6509, align 1
  %6512 = load <8 x i1>, ptr %6510, align 1
  %6513 = and <8 x i1> %6511, %6274
  %6514 = icmp eq <8 x i1> %6512, %6513
  %6515 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6514)
  %6516 = and i1 %6508, %6515
  %.splatinsert1109 = insertelement <8 x i1> poison, i1 %6516, i64 0
  %.splat1110 = shufflevector <8 x i1> %.splatinsert1109, <8 x i1> poison, <8 x i32> zeroinitializer
  %6517 = select <8 x i1> %.splat1110, <8 x i1> %6512, <8 x i1> zeroinitializer
  %6518 = select i1 %6516, <8 x i1> zeroinitializer, <8 x i1> %6513
  store <8 x i1> %6518, ptr %6509, align 1
  %6519 = select i1 %6516, <8 x i1> zeroinitializer, <8 x i1> %6512
  store <8 x i1> %6519, ptr %6510, align 1
  %6520 = and i8 %6506, -65
  %6521 = select i1 %6516, i8 %6520, i8 %6506
  store i8 %6521, ptr %frame.active, align 1
  %6522 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6523 = extractelement <8 x i32> %6522, i32 6
  %6524 = load <8 x i32>, ptr %frame.static.id, align 32
  %6525 = extractelement <8 x i32> %6524, i32 6
  %convergence.target.pointer1111 = getelementptr inbounds [20 x i32], ptr @convergence.targets, i32 0, i32 %6525
  %convergence.dynamic.target1112 = load i32, ptr %convergence.target.pointer1111, align 4
  %6526 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6517)
  %6527 = load i32, ptr %ready.count, align 4
  %6528 = icmp uge i32 %6527, 8
  %6529 = and i1 %6526, %6528
  br i1 %6529, label %ready.overflow.trap1113, label %ready.overflow.resume1114

ready.overflow.trap1113:                          ; preds = %ready.overflow.resume1108
  call void @llvm.trap()
  unreachable

ready.overflow.resume1114:                        ; preds = %ready.overflow.resume1108
  %6530 = select i1 %6526, i32 %6527, i32 0
  %6531 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6530
  %6532 = load <8 x i1>, ptr %6531, align 1
  %6533 = select i1 %6526, <8 x i1> %6517, <8 x i1> %6532
  store <8 x i1> %6533, ptr %6531, align 1
  %6534 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6530
  %6535 = load i32, ptr %6534, align 4
  %6536 = select i1 %6526, i32 %convergence.dynamic.target1112, i32 %6535
  store i32 %6536, ptr %6534, align 4
  %6537 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6530
  %6538 = load i32, ptr %6537, align 4
  %6539 = select i1 %6526, i32 %6523, i32 %6538
  store i32 %6539, ptr %6537, align 4
  %6540 = add i32 %6527, 1
  %6541 = select i1 %6526, i32 %6540, i32 %6527
  store i32 %6541, ptr %ready.count, align 4
  %6542 = load <8 x i1>, ptr %runnable.mask, align 1
  %6543 = or <8 x i1> %6542, %6517
  store <8 x i1> %6543, ptr %runnable.mask, align 1
  %6544 = load i8, ptr %frame.active, align 1
  %6545 = and i8 %6544, -128
  %6546 = icmp ne i8 %6545, 0
  %6547 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 7
  %6548 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 7
  %6549 = load <8 x i1>, ptr %6547, align 1
  %6550 = load <8 x i1>, ptr %6548, align 1
  %6551 = and <8 x i1> %6549, %6274
  %6552 = icmp eq <8 x i1> %6550, %6551
  %6553 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6552)
  %6554 = and i1 %6546, %6553
  %.splatinsert1115 = insertelement <8 x i1> poison, i1 %6554, i64 0
  %.splat1116 = shufflevector <8 x i1> %.splatinsert1115, <8 x i1> poison, <8 x i32> zeroinitializer
  %6555 = select <8 x i1> %.splat1116, <8 x i1> %6550, <8 x i1> zeroinitializer
  %6556 = select i1 %6554, <8 x i1> zeroinitializer, <8 x i1> %6551
  store <8 x i1> %6556, ptr %6547, align 1
  %6557 = select i1 %6554, <8 x i1> zeroinitializer, <8 x i1> %6550
  store <8 x i1> %6557, ptr %6548, align 1
  %6558 = and i8 %6544, 127
  %6559 = select i1 %6554, i8 %6558, i8 %6544
  store i8 %6559, ptr %frame.active, align 1
  %6560 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6561 = extractelement <8 x i32> %6560, i32 7
  %6562 = load <8 x i32>, ptr %frame.static.id, align 32
  %6563 = extractelement <8 x i32> %6562, i32 7
  %convergence.target.pointer1117 = getelementptr inbounds [20 x i32], ptr @convergence.targets, i32 0, i32 %6563
  %convergence.dynamic.target1118 = load i32, ptr %convergence.target.pointer1117, align 4
  %6564 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6555)
  %6565 = load i32, ptr %ready.count, align 4
  %6566 = icmp uge i32 %6565, 8
  %6567 = and i1 %6564, %6566
  br i1 %6567, label %ready.overflow.trap1119, label %ready.overflow.resume1120

ready.overflow.trap1119:                          ; preds = %ready.overflow.resume1114
  call void @llvm.trap()
  unreachable

ready.overflow.resume1120:                        ; preds = %ready.overflow.resume1114
  %6568 = select i1 %6564, i32 %6565, i32 0
  %6569 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6568
  %6570 = load <8 x i1>, ptr %6569, align 1
  %6571 = select i1 %6564, <8 x i1> %6555, <8 x i1> %6570
  store <8 x i1> %6571, ptr %6569, align 1
  %6572 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6568
  %6573 = load i32, ptr %6572, align 4
  %6574 = select i1 %6564, i32 %convergence.dynamic.target1118, i32 %6573
  store i32 %6574, ptr %6572, align 4
  %6575 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6568
  %6576 = load i32, ptr %6575, align 4
  %6577 = select i1 %6564, i32 %6561, i32 %6576
  store i32 %6577, ptr %6575, align 4
  %6578 = add i32 %6565, 1
  %6579 = select i1 %6564, i32 %6578, i32 %6565
  store i32 %6579, ptr %ready.count, align 4
  %6580 = load <8 x i1>, ptr %runnable.mask, align 1
  %6581 = or <8 x i1> %6580, %6555
  store <8 x i1> %6581, ptr %runnable.mask, align 1
  br label %return.frame.cleanup.done
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.and.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x i64>) #2

define dso_local void @tile_inclusive_scan.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(write) }

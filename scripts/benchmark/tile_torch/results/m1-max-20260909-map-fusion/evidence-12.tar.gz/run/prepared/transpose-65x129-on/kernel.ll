; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

@convergence.targets = private unnamed_addr constant [4 x i32] [i32 5, i32 4, i32 10, i32 9], align 4

define internal void @tile_transpose(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %live.mask = alloca <8 x i1>, align 1
  %runnable.mask = alloca <8 x i1>, align 1
  %ready.count = alloca i32, align 4
  %ready.mask = alloca [8 x <8 x i1>], align 1
  %ready.target = alloca [8 x i32], align 4
  %ready.token = alloca [8 x i32], align 4
  %current.mask = alloca <8 x i1>, align 1
  %current.token = alloca i32, align 4
  %frame.active = alloca i8, align 1
  %frame.static.id = alloca <8 x i32>, align 32
  %frame.parent.token = alloca <8 x i32>, align 32
  %frame.expected = alloca [8 x <8 x i1>], align 1
  %frame.arrived = alloca [8 x <8 x i1>], align 1
  store <8 x i1> zeroinitializer, ptr %live.mask, align 1
  store <8 x i1> zeroinitializer, ptr %runnable.mask, align 1
  store i32 0, ptr %ready.count, align 4
  store [8 x <8 x i1>] zeroinitializer, ptr %ready.mask, align 1
  store [8 x i32] zeroinitializer, ptr %ready.target, align 4
  store [8 x i32] zeroinitializer, ptr %ready.token, align 4
  store <8 x i1> zeroinitializer, ptr %current.mask, align 1
  store i32 0, ptr %current.token, align 4
  store i8 0, ptr %frame.active, align 1
  store <8 x i32> zeroinitializer, ptr %frame.static.id, align 32
  store <8 x i32> zeroinitializer, ptr %frame.parent.token, align 32
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.expected, align 1
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.arrived, align 1
  %tile_snapshot.local = alloca [8192 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill1 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill1, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot, align 64
  %.spill2 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill2, align 64
  %.slot3 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot3, align 32
  %.slot4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot4, align 64
  %.spill5 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill5, align 64
  %.spill6 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill6, align 32
  %2 = getelementptr i8, ptr %argument_buffer, i64 0
  %3 = load ptr, ptr %2, align 16
  %4 = getelementptr i8, ptr %2, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = insertvalue { ptr, i64 } poison, ptr %3, 0
  %7 = insertvalue { ptr, i64 } %6, i64 %5, 1
  %8 = getelementptr i8, ptr %argument_buffer, i64 16
  %9 = load ptr, ptr %8, align 16
  %10 = getelementptr i8, ptr %8, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = insertvalue { ptr, i64 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %11, 1
  %14 = load i32, ptr %launch_config, align 4
  %15 = getelementptr i8, ptr %launch_config, i64 12
  %16 = load i32, ptr %15, align 4
  %17 = getelementptr i8, ptr %launch_config, i64 4
  %18 = load i32, ptr %17, align 4
  %19 = getelementptr i8, ptr %launch_config, i64 16
  %20 = load i32, ptr %19, align 4
  %21 = getelementptr i8, ptr %launch_config, i64 8
  %22 = load i32, ptr %21, align 4
  %23 = getelementptr i8, ptr %launch_config, i64 20
  %24 = load i32, ptr %23, align 4
  %25 = getelementptr i8, ptr %launch_config, i64 36
  %26 = load i32, ptr %25, align 4
  %.splatinsert7 = insertelement <8 x i32> poison, i32 %26, i64 0
  %.splat8 = shufflevector <8 x i32> %.splatinsert7, <8 x i32> poison, <8 x i32> zeroinitializer
  %27 = add <8 x i32> %.splat8, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %28 = mul i32 %14, 64
  %.splatinsert9 = insertelement <8 x i32> poison, i32 %28, i64 0
  %.splat10 = shufflevector <8 x i32> %.splatinsert9, <8 x i32> poison, <8 x i32> zeroinitializer
  %29 = add <8 x i32> %.splat10, %27
  %30 = mul i32 %18, 1
  %.splatinsert11 = insertelement <8 x i32> poison, i32 %30, i64 0
  %.splat12 = shufflevector <8 x i32> %.splatinsert11, <8 x i32> poison, <8 x i32> zeroinitializer
  %31 = add <8 x i32> %.splat12, zeroinitializer
  %32 = mul i32 %22, 1
  %.splatinsert13 = insertelement <8 x i32> poison, i32 %32, i64 0
  %.splat14 = shufflevector <8 x i32> %.splatinsert13, <8 x i32> poison, <8 x i32> zeroinitializer
  %33 = add <8 x i32> %.splat14, zeroinitializer
  %34 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %29, 0
  %35 = insertvalue [3 x <8 x i32>] %34, <8 x i32> %31, 1
  %36 = insertvalue [3 x <8 x i32>] %35, <8 x i32> %33, 2
  %.splatinsert15 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat16 = shufflevector <8 x i32> %.splatinsert15, <8 x i32> poison, <8 x i32> zeroinitializer
  %37 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat16
  store <8 x i1> %37, ptr %live.mask, align 1
  %38 = load i32, ptr %current.token, align 4
  %39 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %37)
  %40 = load i32, ptr %ready.count, align 4
  %41 = icmp uge i32 %40, 8
  %42 = and i1 %39, %41
  br i1 %42, label %ready.overflow.trap, label %ready.overflow.resume

ready.overflow.trap:                              ; preds = %prologue
  call void @llvm.trap()
  unreachable

ready.overflow.resume:                            ; preds = %prologue
  %43 = select i1 %39, i32 %40, i32 0
  %44 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %43
  %45 = load <8 x i1>, ptr %44, align 1
  %46 = select i1 %39, <8 x i1> %37, <8 x i1> %45
  store <8 x i1> %46, ptr %44, align 1
  %47 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %43
  %48 = load i32, ptr %47, align 4
  %49 = select i1 %39, i32 0, i32 %48
  store i32 %49, ptr %47, align 4
  %50 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %43
  %51 = load i32, ptr %50, align 4
  %52 = select i1 %39, i32 %38, i32 %51
  store i32 %52, ptr %50, align 4
  %53 = add i32 %40, 1
  %54 = select i1 %39, i32 %53, i32 %40
  store i32 %54, ptr %ready.count, align 4
  %55 = load <8 x i1>, ptr %runnable.mask, align 1
  %56 = or <8 x i1> %55, %37
  store <8 x i1> %56, ptr %runnable.mask, align 1
  br label %scheduler.loop

scheduler.loop:                                   ; preds = %return.frame.cleanup.done, %convergence.cascade.exit108, %convergence.target.9.ready, %convergence.cascade.exit90, %schedule.8, %varying.coherent.false86, %varying.coherent.true85, %ready.overflow.resume84, %varying.coherent.false71, %varying.coherent.true70, %ready.overflow.resume69, %convergence.target.5.ready, %convergence.cascade.exit45, %convergence.target.4.ready, %convergence.cascade.exit, %schedule.3, %varying.coherent.false33, %varying.coherent.true32, %ready.overflow.resume31, %varying.coherent.false, %varying.coherent.true, %ready.overflow.resume20, %schedule.0, %ready.overflow.resume
  %57 = load i32, ptr %ready.count, align 4
  %58 = icmp ne i32 %57, 0
  br i1 %58, label %scheduler.dispatch, label %scheduler.done

scheduler.dispatch:                               ; preds = %scheduler.loop
  %59 = sub i32 %57, 1
  store i32 %59, ptr %ready.count, align 4
  %60 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %59
  %61 = load <8 x i1>, ptr %60, align 1
  store <8 x i1> %61, ptr %current.mask, align 1
  %62 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %59
  %63 = load i32, ptr %62, align 4
  %64 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %59
  %65 = load i32, ptr %64, align 4
  store i32 %65, ptr %current.token, align 4
  %66 = load <8 x i1>, ptr %runnable.mask, align 1
  %67 = xor <8 x i1> %61, splat (i1 true)
  %68 = and <8 x i1> %66, %67
  store <8 x i1> %68, ptr %runnable.mask, align 1
  br label %scheduler.dispatch.route

scheduler.dispatch.route:                         ; preds = %scheduler.dispatch
  %scheduler.dispatch.pc = phi i32 [ %63, %scheduler.dispatch ]
  switch i32 %scheduler.dispatch.pc, label %scheduler.invalid [
    i32 0, label %schedule.0
    i32 1, label %schedule.1
    i32 2, label %schedule.2
    i32 3, label %schedule.3
    i32 4, label %schedule.4
    i32 5, label %schedule.5
    i32 6, label %schedule.6
    i32 7, label %schedule.7
    i32 8, label %schedule.8
    i32 9, label %schedule.9
    i32 10, label %schedule.10
  ]

scheduler.done:                                   ; preds = %scheduler.loop
  %69 = load <8 x i1>, ptr %live.mask, align 1
  %70 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %69)
  br i1 %70, label %scheduler.stalled, label %scheduler.exit

scheduler.exit:                                   ; preds = %scheduler.done
  ret void

scheduler.stalled:                                ; preds = %scheduler.done
  call void @llvm.trap()
  unreachable

scheduler.invalid:                                ; preds = %scheduler.dispatch.route
  call void @llvm.trap()
  unreachable

schedule.0:                                       ; preds = %scheduler.dispatch.route
  %71 = load <8 x i1>, ptr %current.mask, align 1
  %72 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %73 = bitcast <8 x i1> %71 to i8
  %74 = call i8 @llvm.cttz.i8(i8 %73, i1 false)
  %75 = zext i8 %74 to i32
  %76 = select i1 %72, i32 %75, i32 0
  %77 = extractvalue [3 x <8 x i32>] %36, 0
  %78 = zext <8 x i32> %77 to <8 x i64>
  %79 = select <8 x i1> %71, <8 x i64> %78, <8 x i64> zeroinitializer
  %80 = select <8 x i1> %71, <8 x i64> splat (i64 9), <8 x i64> splat (i64 1)
  %81 = sdiv <8 x i64> %79, %80
  %82 = select <8 x i1> %71, <8 x i64> %78, <8 x i64> zeroinitializer
  %83 = select <8 x i1> %71, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %84 = sdiv <8 x i64> %82, %83
  %85 = select <8 x i1> %71, <8 x i64> %84, <8 x i64> zeroinitializer
  %86 = select <8 x i1> %71, <8 x i64> splat (i64 9), <8 x i64> splat (i64 1)
  %87 = srem <8 x i64> %85, %86
  %88 = mul <8 x i64> %81, splat (i64 16)
  %89 = load volatile <8 x i64>, ptr %.spill, align 64
  %90 = select <8 x i1> %71, <8 x i64> %88, <8 x i64> %89
  store volatile <8 x i64> %90, ptr %.spill, align 64
  %91 = mul <8 x i64> %87, splat (i64 16)
  %92 = load volatile <8 x i64>, ptr %.spill1, align 64
  %93 = select <8 x i1> %71, <8 x i64> %91, <8 x i64> %92
  store volatile <8 x i64> %93, ptr %.spill1, align 64
  %94 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %95 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %96 = extractvalue { <8 x ptr>, <8 x i64> } %94, 0
  %97 = select <8 x i1> %71, <8 x ptr> %95, <8 x ptr> %96
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %99 = extractvalue { <8 x ptr>, <8 x i64> } %94, 1
  %100 = select <8 x i1> %71, <8 x i64> %98, <8 x i64> %99
  %101 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %97, 0
  %102 = insertvalue { <8 x ptr>, <8 x i64> } %101, <8 x i64> %100, 1
  store volatile { <8 x ptr>, <8 x i64> } %102, ptr %tile_snapshot.spill, align 64
  %103 = load <8 x i64>, ptr %.slot, align 64
  %104 = select <8 x i1> %71, <8 x i64> zeroinitializer, <8 x i64> %103
  store <8 x i64> %104, ptr %.slot, align 64
  store <8 x i1> %71, ptr %current.mask, align 1
  %105 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  br i1 %105, label %schedule.1, label %scheduler.loop

schedule.1:                                       ; preds = %convergence.target.4.ready, %schedule.0, %scheduler.dispatch.route
  %106 = load <8 x i1>, ptr %current.mask, align 1
  %107 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %106)
  %108 = bitcast <8 x i1> %106 to i8
  %109 = call i8 @llvm.cttz.i8(i8 %108, i1 false)
  %110 = zext i8 %109 to i32
  %111 = select i1 %107, i32 %110, i32 0
  %.state = load <8 x i64>, ptr %.slot, align 64
  %112 = icmp slt <8 x i64> %.state, splat (i64 256)
  %113 = and <8 x i1> %106, %112
  %114 = xor <8 x i1> %112, splat (i1 true)
  %115 = and <8 x i1> %106, %114
  %116 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %113)
  %117 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %115)
  %118 = and i1 %116, %117
  br i1 %118, label %varying.divergent, label %varying.coherent

schedule.2:                                       ; preds = %varying.coherent.true, %scheduler.dispatch.route
  %119 = load <8 x i1>, ptr %current.mask, align 1
  %120 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %119)
  %121 = bitcast <8 x i1> %119 to i8
  %122 = call i8 @llvm.cttz.i8(i8 %121, i1 false)
  %123 = zext i8 %122 to i32
  %124 = select i1 %120, i32 %123, i32 0
  %.state21 = load <8 x i64>, ptr %.slot, align 64
  %125 = select <8 x i1> %119, <8 x i64> %.state21, <8 x i64> zeroinitializer
  %126 = select <8 x i1> %119, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %127 = srem <8 x i64> %125, %126
  %.state22 = load <8 x i64>, ptr %.slot, align 64
  %128 = select <8 x i1> %119, <8 x i64> %.state22, <8 x i64> zeroinitializer
  %129 = select <8 x i1> %119, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %130 = sdiv <8 x i64> %128, %129
  %.spill.load = load volatile <8 x i64>, ptr %.spill, align 64
  %131 = add <8 x i64> %.spill.load, %130
  %132 = add <8 x i64> zeroinitializer, %131
  %133 = icmp sge <8 x i64> %131, zeroinitializer
  %134 = and <8 x i1> splat (i1 true), %133
  %135 = icmp slt <8 x i64> %131, splat (i64 65)
  %136 = and <8 x i1> %134, %135
  %.spill.load23 = load volatile <8 x i64>, ptr %.spill1, align 64
  %137 = add <8 x i64> %.spill.load23, %127
  %138 = mul <8 x i64> %132, splat (i64 129)
  %139 = add <8 x i64> %138, %137
  %140 = icmp sge <8 x i64> %137, zeroinitializer
  %141 = and <8 x i1> %136, %140
  %142 = icmp slt <8 x i64> %137, splat (i64 129)
  %143 = and <8 x i1> %141, %142
  %144 = load volatile <8 x i64>, ptr %.spill2, align 64
  %145 = select <8 x i1> %119, <8 x i64> %139, <8 x i64> %144
  store volatile <8 x i64> %145, ptr %.spill2, align 64
  %146 = and <8 x i1> %119, %143
  %147 = xor <8 x i1> %143, splat (i1 true)
  %148 = and <8 x i1> %119, %147
  %149 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %146)
  %150 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %148)
  %151 = and i1 %149, %150
  br i1 %151, label %varying.divergent24, label %varying.coherent25

schedule.3:                                       ; preds = %varying.coherent.true32, %scheduler.dispatch.route
  %152 = load <8 x i1>, ptr %current.mask, align 1
  %153 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %152)
  %154 = bitcast <8 x i1> %152 to i8
  %155 = call i8 @llvm.cttz.i8(i8 %154, i1 false)
  %156 = zext i8 %155 to i32
  %157 = select i1 %153, i32 %156, i32 0
  %.spill.load34 = load volatile <8 x i64>, ptr %.spill2, align 64
  %158 = extractvalue { ptr, i64 } %7, 0
  %159 = mul <8 x i64> %.spill.load34, splat (i64 4)
  %160 = getelementptr i8, ptr %158, <8 x i64> %159
  %161 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %160, i32 1, <8 x i1> %152, <8 x float> zeroinitializer)
  %162 = load <8 x float>, ptr %.slot3, align 32
  %163 = select <8 x i1> %152, <8 x float> %161, <8 x float> %162
  store <8 x float> %163, ptr %.slot3, align 32
  store <8 x i1> %152, ptr %current.mask, align 1
  %164 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %152)
  br i1 %164, label %schedule.4, label %scheduler.loop

schedule.4:                                       ; preds = %schedule.3, %varying.coherent.false33, %scheduler.dispatch.route
  %165 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token = load i32, ptr %current.token, align 4
  %convergence.token.present = icmp ne i32 %convergence.current.token, 0
  br i1 %convergence.token.present, label %convergence.cascade, label %convergence.cascade.exit

schedule.5:                                       ; preds = %varying.coherent.false, %scheduler.dispatch.route
  %166 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token46 = load i32, ptr %current.token, align 4
  %convergence.token.present47 = icmp ne i32 %convergence.current.token46, 0
  br i1 %convergence.token.present47, label %convergence.cascade44, label %convergence.cascade.exit45

schedule.6:                                       ; preds = %convergence.target.9.ready, %convergence.target.5.ready, %scheduler.dispatch.route
  %167 = load <8 x i1>, ptr %current.mask, align 1
  %168 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %167)
  %169 = bitcast <8 x i1> %167 to i8
  %170 = call i8 @llvm.cttz.i8(i8 %169, i1 false)
  %171 = zext i8 %170 to i32
  %172 = select i1 %168, i32 %171, i32 0
  %.state61 = load <8 x i64>, ptr %.slot4, align 64
  %173 = icmp slt <8 x i64> %.state61, splat (i64 256)
  %174 = and <8 x i1> %167, %173
  %175 = xor <8 x i1> %173, splat (i1 true)
  %176 = and <8 x i1> %167, %175
  %177 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %174)
  %178 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %176)
  %179 = and i1 %177, %178
  br i1 %179, label %varying.divergent62, label %varying.coherent63

schedule.7:                                       ; preds = %varying.coherent.true70, %scheduler.dispatch.route
  %180 = load <8 x i1>, ptr %current.mask, align 1
  %181 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %180)
  %182 = bitcast <8 x i1> %180 to i8
  %183 = call i8 @llvm.cttz.i8(i8 %182, i1 false)
  %184 = zext i8 %183 to i32
  %185 = select i1 %181, i32 %184, i32 0
  %.state72 = load <8 x i64>, ptr %.slot4, align 64
  %186 = select <8 x i1> %180, <8 x i64> %.state72, <8 x i64> zeroinitializer
  %187 = select <8 x i1> %180, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %188 = srem <8 x i64> %186, %187
  %.state73 = load <8 x i64>, ptr %.slot4, align 64
  %189 = select <8 x i1> %180, <8 x i64> %.state73, <8 x i64> zeroinitializer
  %190 = select <8 x i1> %180, <8 x i64> splat (i64 16), <8 x i64> splat (i64 1)
  %191 = sdiv <8 x i64> %189, %190
  %.spill.load74 = load volatile <8 x i64>, ptr %.spill1, align 64
  %192 = add <8 x i64> %.spill.load74, %191
  %193 = add <8 x i64> zeroinitializer, %192
  %194 = icmp sge <8 x i64> %192, zeroinitializer
  %195 = and <8 x i1> splat (i1 true), %194
  %196 = icmp slt <8 x i64> %192, splat (i64 129)
  %197 = and <8 x i1> %195, %196
  %.spill.load75 = load volatile <8 x i64>, ptr %.spill, align 64
  %198 = add <8 x i64> %.spill.load75, %188
  %199 = mul <8 x i64> %193, splat (i64 65)
  %200 = add <8 x i64> %199, %198
  %201 = icmp sge <8 x i64> %198, zeroinitializer
  %202 = and <8 x i1> %197, %201
  %203 = icmp slt <8 x i64> %198, splat (i64 65)
  %204 = and <8 x i1> %202, %203
  %205 = load volatile <8 x i64>, ptr %.spill5, align 64
  %206 = select <8 x i1> %180, <8 x i64> %200, <8 x i64> %205
  store volatile <8 x i64> %206, ptr %.spill5, align 64
  %207 = add <8 x i64> zeroinitializer, %188
  %208 = mul <8 x i64> %207, splat (i64 16)
  %209 = add <8 x i64> %208, %191
  %tile_snapshot.spill.load76 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %210 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load76, 0
  %211 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load76, 1
  %212 = mul <8 x i64> %209, splat (i64 32)
  %213 = add <8 x i64> %211, %212
  %214 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %210, 0
  %215 = insertvalue { <8 x ptr>, <8 x i64> } %214, <8 x i64> %213, 1
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %215, 0
  %217 = extractvalue { <8 x ptr>, <8 x i64> } %215, 1
  %218 = getelementptr i8, <8 x ptr> %216, <8 x i64> %217
  %219 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %218, i32 1, <8 x i1> %180, <8 x float> zeroinitializer)
  %220 = load volatile <8 x float>, ptr %.spill6, align 32
  %221 = select <8 x i1> %180, <8 x float> %219, <8 x float> %220
  store volatile <8 x float> %221, ptr %.spill6, align 32
  %222 = and <8 x i1> %180, %204
  %223 = xor <8 x i1> %204, splat (i1 true)
  %224 = and <8 x i1> %180, %223
  %225 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %222)
  %226 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %224)
  %227 = and i1 %225, %226
  br i1 %227, label %varying.divergent77, label %varying.coherent78

schedule.8:                                       ; preds = %varying.coherent.true85, %scheduler.dispatch.route
  %228 = load <8 x i1>, ptr %current.mask, align 1
  %229 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %228)
  %230 = bitcast <8 x i1> %228 to i8
  %231 = call i8 @llvm.cttz.i8(i8 %230, i1 false)
  %232 = zext i8 %231 to i32
  %233 = select i1 %229, i32 %232, i32 0
  %.spill.load87 = load volatile <8 x i64>, ptr %.spill5, align 64
  %.spill.load88 = load volatile <8 x float>, ptr %.spill6, align 32
  %234 = extractvalue { ptr, i64 } %13, 0
  %235 = mul <8 x i64> %.spill.load87, splat (i64 4)
  %236 = getelementptr i8, ptr %234, <8 x i64> %235
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.spill.load88, <8 x ptr> %236, i32 1, <8 x i1> %228)
  store <8 x i1> %228, ptr %current.mask, align 1
  %237 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %228)
  br i1 %237, label %schedule.9, label %scheduler.loop

schedule.9:                                       ; preds = %schedule.8, %varying.coherent.false86, %scheduler.dispatch.route
  %238 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token91 = load i32, ptr %current.token, align 4
  %convergence.token.present92 = icmp ne i32 %convergence.current.token91, 0
  br i1 %convergence.token.present92, label %convergence.cascade89, label %convergence.cascade.exit90

schedule.10:                                      ; preds = %varying.coherent.false71, %scheduler.dispatch.route
  %239 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token109 = load i32, ptr %current.token, align 4
  %convergence.token.present110 = icmp ne i32 %convergence.current.token109, 0
  br i1 %convergence.token.present110, label %convergence.cascade107, label %convergence.cascade.exit108

varying.divergent:                                ; preds = %schedule.1
  %240 = load i32, ptr %current.token, align 4
  %241 = icmp ne i32 %240, 0
  %242 = sub i32 %240, 1
  %243 = select i1 %241, i32 %242, i32 0
  %244 = load i8, ptr %frame.active, align 1
  %245 = trunc i32 %243 to i8
  %246 = shl i8 1, %245
  %247 = and i8 %244, %246
  %248 = icmp ne i8 %247, 0
  %249 = load <8 x i32>, ptr %frame.static.id, align 32
  %250 = extractelement <8 x i32> %249, i32 %243
  %251 = icmp eq i32 %250, 0
  %252 = and i1 %248, %251
  %253 = and i1 %241, %252
  %254 = xor i1 %253, true
  %255 = and i1 true, %254
  %256 = xor i8 %244, -1
  %257 = icmp ne i8 %256, 0
  %258 = xor i1 %257, true
  %259 = and i1 %255, %258
  br i1 %259, label %convergence.overflow.trap, label %convergence.overflow.resume

varying.coherent:                                 ; preds = %schedule.1
  br i1 %116, label %varying.coherent.true, label %varying.coherent.false

convergence.overflow.trap:                        ; preds = %varying.divergent
  call void @llvm.trap()
  unreachable

convergence.overflow.resume:                      ; preds = %varying.divergent
  %260 = call i8 @llvm.cttz.i8(i8 %256, i1 false)
  %261 = zext i8 %260 to i32
  %262 = select i1 %257, i32 %261, i32 0
  %263 = trunc i32 %262 to i8
  %264 = shl i8 1, %263
  %265 = or i8 %244, %264
  %266 = select i1 %255, i8 %265, i8 %244
  store i8 %266, ptr %frame.active, align 1
  %267 = load <8 x i32>, ptr %frame.static.id, align 32
  %268 = extractelement <8 x i32> %267, i32 %262
  %269 = select i1 %255, i32 0, i32 %268
  %270 = load <8 x i32>, ptr %frame.static.id, align 32
  %271 = insertelement <8 x i32> %270, i32 %269, i32 %262
  store <8 x i32> %271, ptr %frame.static.id, align 32
  %272 = load <8 x i32>, ptr %frame.parent.token, align 32
  %273 = extractelement <8 x i32> %272, i32 %262
  %274 = select i1 %255, i32 %240, i32 %273
  %275 = load <8 x i32>, ptr %frame.parent.token, align 32
  %276 = insertelement <8 x i32> %275, i32 %274, i32 %262
  store <8 x i32> %276, ptr %frame.parent.token, align 32
  %277 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %262
  %278 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %262
  %279 = load <8 x i1>, ptr %277, align 1
  %280 = load <8 x i1>, ptr %278, align 1
  %281 = select i1 %255, <8 x i1> %106, <8 x i1> %279
  store <8 x i1> %281, ptr %277, align 1
  %282 = select i1 %255, <8 x i1> zeroinitializer, <8 x i1> %280
  store <8 x i1> %282, ptr %278, align 1
  %283 = add i32 %262, 1
  %284 = select i1 %253, i32 %240, i32 %283
  %285 = select i1 true, i32 %284, i32 %240
  store i32 %285, ptr %current.token, align 4
  %286 = load i32, ptr %current.token, align 4
  %287 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %113)
  %288 = load i32, ptr %ready.count, align 4
  %289 = icmp uge i32 %288, 8
  %290 = and i1 %287, %289
  br i1 %290, label %ready.overflow.trap17, label %ready.overflow.resume18

ready.overflow.trap17:                            ; preds = %convergence.overflow.resume
  call void @llvm.trap()
  unreachable

ready.overflow.resume18:                          ; preds = %convergence.overflow.resume
  %291 = select i1 %287, i32 %288, i32 0
  %292 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %291
  %293 = load <8 x i1>, ptr %292, align 1
  %294 = select i1 %287, <8 x i1> %113, <8 x i1> %293
  store <8 x i1> %294, ptr %292, align 1
  %295 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %291
  %296 = load i32, ptr %295, align 4
  %297 = select i1 %287, i32 2, i32 %296
  store i32 %297, ptr %295, align 4
  %298 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %291
  %299 = load i32, ptr %298, align 4
  %300 = select i1 %287, i32 %286, i32 %299
  store i32 %300, ptr %298, align 4
  %301 = add i32 %288, 1
  %302 = select i1 %287, i32 %301, i32 %288
  store i32 %302, ptr %ready.count, align 4
  %303 = load <8 x i1>, ptr %runnable.mask, align 1
  %304 = or <8 x i1> %303, %113
  store <8 x i1> %304, ptr %runnable.mask, align 1
  %305 = load i32, ptr %current.token, align 4
  %306 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %115)
  %307 = load i32, ptr %ready.count, align 4
  %308 = icmp uge i32 %307, 8
  %309 = and i1 %306, %308
  br i1 %309, label %ready.overflow.trap19, label %ready.overflow.resume20

ready.overflow.trap19:                            ; preds = %ready.overflow.resume18
  call void @llvm.trap()
  unreachable

ready.overflow.resume20:                          ; preds = %ready.overflow.resume18
  %310 = select i1 %306, i32 %307, i32 0
  %311 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %310
  %312 = load <8 x i1>, ptr %311, align 1
  %313 = select i1 %306, <8 x i1> %115, <8 x i1> %312
  store <8 x i1> %313, ptr %311, align 1
  %314 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %310
  %315 = load i32, ptr %314, align 4
  %316 = select i1 %306, i32 5, i32 %315
  store i32 %316, ptr %314, align 4
  %317 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %310
  %318 = load i32, ptr %317, align 4
  %319 = select i1 %306, i32 %305, i32 %318
  store i32 %319, ptr %317, align 4
  %320 = add i32 %307, 1
  %321 = select i1 %306, i32 %320, i32 %307
  store i32 %321, ptr %ready.count, align 4
  %322 = load <8 x i1>, ptr %runnable.mask, align 1
  %323 = or <8 x i1> %322, %115
  store <8 x i1> %323, ptr %runnable.mask, align 1
  br label %scheduler.loop

varying.coherent.true:                            ; preds = %varying.coherent
  store <8 x i1> %106, ptr %current.mask, align 1
  %324 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %106)
  br i1 %324, label %schedule.2, label %scheduler.loop

varying.coherent.false:                           ; preds = %varying.coherent
  store <8 x i1> %106, ptr %current.mask, align 1
  %325 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %106)
  br i1 %325, label %schedule.5, label %scheduler.loop

varying.divergent24:                              ; preds = %schedule.2
  %326 = load i32, ptr %current.token, align 4
  %327 = icmp ne i32 %326, 0
  %328 = sub i32 %326, 1
  %329 = select i1 %327, i32 %328, i32 0
  %330 = load i8, ptr %frame.active, align 1
  %331 = trunc i32 %329 to i8
  %332 = shl i8 1, %331
  %333 = and i8 %330, %332
  %334 = icmp ne i8 %333, 0
  %335 = load <8 x i32>, ptr %frame.static.id, align 32
  %336 = extractelement <8 x i32> %335, i32 %329
  %337 = icmp eq i32 %336, 1
  %338 = and i1 %334, %337
  %339 = and i1 %327, %338
  %340 = xor i1 %339, true
  %341 = and i1 true, %340
  %342 = xor i8 %330, -1
  %343 = icmp ne i8 %342, 0
  %344 = xor i1 %343, true
  %345 = and i1 %341, %344
  br i1 %345, label %convergence.overflow.trap26, label %convergence.overflow.resume27

varying.coherent25:                               ; preds = %schedule.2
  br i1 %149, label %varying.coherent.true32, label %varying.coherent.false33

convergence.overflow.trap26:                      ; preds = %varying.divergent24
  call void @llvm.trap()
  unreachable

convergence.overflow.resume27:                    ; preds = %varying.divergent24
  %346 = call i8 @llvm.cttz.i8(i8 %342, i1 false)
  %347 = zext i8 %346 to i32
  %348 = select i1 %343, i32 %347, i32 0
  %349 = trunc i32 %348 to i8
  %350 = shl i8 1, %349
  %351 = or i8 %330, %350
  %352 = select i1 %341, i8 %351, i8 %330
  store i8 %352, ptr %frame.active, align 1
  %353 = load <8 x i32>, ptr %frame.static.id, align 32
  %354 = extractelement <8 x i32> %353, i32 %348
  %355 = select i1 %341, i32 1, i32 %354
  %356 = load <8 x i32>, ptr %frame.static.id, align 32
  %357 = insertelement <8 x i32> %356, i32 %355, i32 %348
  store <8 x i32> %357, ptr %frame.static.id, align 32
  %358 = load <8 x i32>, ptr %frame.parent.token, align 32
  %359 = extractelement <8 x i32> %358, i32 %348
  %360 = select i1 %341, i32 %326, i32 %359
  %361 = load <8 x i32>, ptr %frame.parent.token, align 32
  %362 = insertelement <8 x i32> %361, i32 %360, i32 %348
  store <8 x i32> %362, ptr %frame.parent.token, align 32
  %363 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %348
  %364 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %348
  %365 = load <8 x i1>, ptr %363, align 1
  %366 = load <8 x i1>, ptr %364, align 1
  %367 = select i1 %341, <8 x i1> %119, <8 x i1> %365
  store <8 x i1> %367, ptr %363, align 1
  %368 = select i1 %341, <8 x i1> zeroinitializer, <8 x i1> %366
  store <8 x i1> %368, ptr %364, align 1
  %369 = add i32 %348, 1
  %370 = select i1 %339, i32 %326, i32 %369
  %371 = select i1 true, i32 %370, i32 %326
  store i32 %371, ptr %current.token, align 4
  %372 = load <8 x float>, ptr %.slot3, align 32
  %373 = select <8 x i1> %148, <8 x float> zeroinitializer, <8 x float> %372
  store <8 x float> %373, ptr %.slot3, align 32
  %374 = load i32, ptr %current.token, align 4
  %375 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %146)
  %376 = load i32, ptr %ready.count, align 4
  %377 = icmp uge i32 %376, 8
  %378 = and i1 %375, %377
  br i1 %378, label %ready.overflow.trap28, label %ready.overflow.resume29

ready.overflow.trap28:                            ; preds = %convergence.overflow.resume27
  call void @llvm.trap()
  unreachable

ready.overflow.resume29:                          ; preds = %convergence.overflow.resume27
  %379 = select i1 %375, i32 %376, i32 0
  %380 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %379
  %381 = load <8 x i1>, ptr %380, align 1
  %382 = select i1 %375, <8 x i1> %146, <8 x i1> %381
  store <8 x i1> %382, ptr %380, align 1
  %383 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %379
  %384 = load i32, ptr %383, align 4
  %385 = select i1 %375, i32 3, i32 %384
  store i32 %385, ptr %383, align 4
  %386 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %379
  %387 = load i32, ptr %386, align 4
  %388 = select i1 %375, i32 %374, i32 %387
  store i32 %388, ptr %386, align 4
  %389 = add i32 %376, 1
  %390 = select i1 %375, i32 %389, i32 %376
  store i32 %390, ptr %ready.count, align 4
  %391 = load <8 x i1>, ptr %runnable.mask, align 1
  %392 = or <8 x i1> %391, %146
  store <8 x i1> %392, ptr %runnable.mask, align 1
  %393 = load i32, ptr %current.token, align 4
  %394 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %148)
  %395 = load i32, ptr %ready.count, align 4
  %396 = icmp uge i32 %395, 8
  %397 = and i1 %394, %396
  br i1 %397, label %ready.overflow.trap30, label %ready.overflow.resume31

ready.overflow.trap30:                            ; preds = %ready.overflow.resume29
  call void @llvm.trap()
  unreachable

ready.overflow.resume31:                          ; preds = %ready.overflow.resume29
  %398 = select i1 %394, i32 %395, i32 0
  %399 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %398
  %400 = load <8 x i1>, ptr %399, align 1
  %401 = select i1 %394, <8 x i1> %148, <8 x i1> %400
  store <8 x i1> %401, ptr %399, align 1
  %402 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %398
  %403 = load i32, ptr %402, align 4
  %404 = select i1 %394, i32 4, i32 %403
  store i32 %404, ptr %402, align 4
  %405 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %398
  %406 = load i32, ptr %405, align 4
  %407 = select i1 %394, i32 %393, i32 %406
  store i32 %407, ptr %405, align 4
  %408 = add i32 %395, 1
  %409 = select i1 %394, i32 %408, i32 %395
  store i32 %409, ptr %ready.count, align 4
  %410 = load <8 x i1>, ptr %runnable.mask, align 1
  %411 = or <8 x i1> %410, %148
  store <8 x i1> %411, ptr %runnable.mask, align 1
  br label %scheduler.loop

varying.coherent.true32:                          ; preds = %varying.coherent25
  store <8 x i1> %119, ptr %current.mask, align 1
  %412 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %119)
  br i1 %412, label %schedule.3, label %scheduler.loop

varying.coherent.false33:                         ; preds = %varying.coherent25
  %413 = load <8 x float>, ptr %.slot3, align 32
  %414 = select <8 x i1> %119, <8 x float> zeroinitializer, <8 x float> %413
  store <8 x float> %414, ptr %.slot3, align 32
  store <8 x i1> %119, ptr %current.mask, align 1
  %415 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %119)
  br i1 %415, label %schedule.4, label %scheduler.loop

convergence.cascade:                              ; preds = %convergence.cascade, %schedule.4
  %convergence.cascade.flow = phi <8 x i1> [ %165, %schedule.4 ], [ %458, %convergence.cascade ]
  %convergence.cascade.depth = phi i32 [ 0, %schedule.4 ], [ %459, %convergence.cascade ]
  %416 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow)
  %417 = load i32, ptr %current.token, align 4
  %418 = icmp ne i32 %417, 0
  %419 = and i1 %416, %418
  %420 = sub i32 %417, 1
  %421 = select i1 %419, i32 %420, i32 0
  %422 = load i8, ptr %frame.active, align 1
  %423 = trunc i32 %421 to i8
  %424 = shl i8 1, %423
  %425 = and i8 %422, %424
  %426 = icmp ne i8 %425, 0
  %427 = load <8 x i32>, ptr %frame.static.id, align 32
  %428 = extractelement <8 x i32> %427, i32 %421
  %convergence.target.pointer = getelementptr inbounds [4 x i32], ptr @convergence.targets, i32 0, i32 %428
  %convergence.dynamic.target = load i32, ptr %convergence.target.pointer, align 4
  %429 = icmp eq i32 %convergence.dynamic.target, 4
  %430 = and i1 %426, %429
  %431 = and i1 %419, %430
  %432 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %421
  %433 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %421
  %434 = load <8 x i1>, ptr %432, align 1
  %435 = load <8 x i1>, ptr %433, align 1
  %436 = or <8 x i1> %435, %convergence.cascade.flow
  %437 = load <8 x i1>, ptr %live.mask, align 1
  %438 = and <8 x i1> %434, %437
  %439 = icmp eq <8 x i1> %436, %438
  %440 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %439)
  %441 = and i1 %431, %440
  %442 = select i1 %441, <8 x i1> zeroinitializer, <8 x i1> %436
  %443 = select i1 %431, <8 x i1> %442, <8 x i1> %435
  store <8 x i1> %443, ptr %433, align 1
  %444 = select i1 %441, <8 x i1> zeroinitializer, <8 x i1> %434
  store <8 x i1> %444, ptr %432, align 1
  %445 = trunc i32 %421 to i8
  %446 = shl i8 1, %445
  %447 = xor i8 %446, -1
  %448 = and i8 %422, %447
  %449 = select i1 %441, i8 %448, i8 %422
  store i8 %449, ptr %frame.active, align 1
  %.splatinsert35 = insertelement <8 x i1> poison, i1 %431, i64 0
  %.splat36 = shufflevector <8 x i1> %.splatinsert35, <8 x i1> poison, <8 x i32> zeroinitializer
  %450 = and <8 x i1> %convergence.cascade.flow, %.splat36
  %451 = load <8 x i1>, ptr %runnable.mask, align 1
  %452 = xor <8 x i1> %450, splat (i1 true)
  %453 = and <8 x i1> %451, %452
  store <8 x i1> %453, ptr %runnable.mask, align 1
  %.splatinsert37 = insertelement <8 x i1> poison, i1 %441, i64 0
  %.splat38 = shufflevector <8 x i1> %.splatinsert37, <8 x i1> poison, <8 x i32> zeroinitializer
  %454 = select <8 x i1> %.splat38, <8 x i1> %436, <8 x i1> zeroinitializer
  %455 = load <8 x i32>, ptr %frame.parent.token, align 32
  %456 = extractelement <8 x i32> %455, i32 %421
  %457 = select i1 %441, i32 %456, i32 %417
  store i32 %457, ptr %current.token, align 4
  %.splatinsert39 = insertelement <8 x i1> poison, i1 %431, i64 0
  %.splat40 = shufflevector <8 x i1> %.splatinsert39, <8 x i1> poison, <8 x i32> zeroinitializer
  %458 = select <8 x i1> %.splat40, <8 x i1> %454, <8 x i1> %convergence.cascade.flow
  %459 = add i32 %convergence.cascade.depth, 1
  %460 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %458)
  %461 = icmp ult i32 %459, 8
  %462 = and i1 %460, %461
  %463 = and i1 %431, %462
  %convergence.parent.token = load i32, ptr %current.token, align 4
  %convergence.parent.present = icmp ne i32 %convergence.parent.token, 0
  %464 = and i1 %463, %convergence.parent.present
  br i1 %464, label %convergence.cascade, label %convergence.cascade.exit

convergence.cascade.exit:                         ; preds = %convergence.cascade, %schedule.4
  %convergence.cascade.result = phi <8 x i1> [ %165, %schedule.4 ], [ %458, %convergence.cascade ]
  %465 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %465, label %convergence.target.4.ready, label %scheduler.loop

convergence.target.4.ready:                       ; preds = %convergence.cascade.exit
  %466 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %467 = bitcast <8 x i1> %convergence.cascade.result to i8
  %468 = call i8 @llvm.cttz.i8(i8 %467, i1 false)
  %469 = zext i8 %468 to i32
  %470 = select i1 %466, i32 %469, i32 0
  %tile_snapshot.spill.load = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %471 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %472 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state41 = load <8 x i64>, ptr %.slot, align 64
  %473 = mul <8 x i64> %.state41, splat (i64 32)
  %474 = add <8 x i64> %472, %473
  %475 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %471, 0
  %476 = insertvalue { <8 x ptr>, <8 x i64> } %475, <8 x i64> %474, 1
  %.state42 = load <8 x float>, ptr %.slot3, align 32
  %477 = extractvalue { <8 x ptr>, <8 x i64> } %476, 0
  %478 = extractvalue { <8 x ptr>, <8 x i64> } %476, 1
  %479 = getelementptr i8, <8 x ptr> %477, <8 x i64> %478
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state42, <8 x ptr> %479, i32 1, <8 x i1> %convergence.cascade.result)
  %.state43 = load <8 x i64>, ptr %.slot, align 64
  %480 = add <8 x i64> %.state43, splat (i64 1)
  %481 = load <8 x i64>, ptr %.slot, align 64
  %482 = select <8 x i1> %convergence.cascade.result, <8 x i64> %480, <8 x i64> %481
  store <8 x i64> %482, ptr %.slot, align 64
  store <8 x i1> %convergence.cascade.result, ptr %current.mask, align 1
  %483 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %483, label %schedule.1, label %scheduler.loop

convergence.cascade44:                            ; preds = %convergence.cascade44, %schedule.5
  %convergence.cascade.flow48 = phi <8 x i1> [ %166, %schedule.5 ], [ %526, %convergence.cascade44 ]
  %convergence.cascade.depth49 = phi i32 [ 0, %schedule.5 ], [ %527, %convergence.cascade44 ]
  %484 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow48)
  %485 = load i32, ptr %current.token, align 4
  %486 = icmp ne i32 %485, 0
  %487 = and i1 %484, %486
  %488 = sub i32 %485, 1
  %489 = select i1 %487, i32 %488, i32 0
  %490 = load i8, ptr %frame.active, align 1
  %491 = trunc i32 %489 to i8
  %492 = shl i8 1, %491
  %493 = and i8 %490, %492
  %494 = icmp ne i8 %493, 0
  %495 = load <8 x i32>, ptr %frame.static.id, align 32
  %496 = extractelement <8 x i32> %495, i32 %489
  %convergence.target.pointer50 = getelementptr inbounds [4 x i32], ptr @convergence.targets, i32 0, i32 %496
  %convergence.dynamic.target51 = load i32, ptr %convergence.target.pointer50, align 4
  %497 = icmp eq i32 %convergence.dynamic.target51, 5
  %498 = and i1 %494, %497
  %499 = and i1 %487, %498
  %500 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %489
  %501 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %489
  %502 = load <8 x i1>, ptr %500, align 1
  %503 = load <8 x i1>, ptr %501, align 1
  %504 = or <8 x i1> %503, %convergence.cascade.flow48
  %505 = load <8 x i1>, ptr %live.mask, align 1
  %506 = and <8 x i1> %502, %505
  %507 = icmp eq <8 x i1> %504, %506
  %508 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %507)
  %509 = and i1 %499, %508
  %510 = select i1 %509, <8 x i1> zeroinitializer, <8 x i1> %504
  %511 = select i1 %499, <8 x i1> %510, <8 x i1> %503
  store <8 x i1> %511, ptr %501, align 1
  %512 = select i1 %509, <8 x i1> zeroinitializer, <8 x i1> %502
  store <8 x i1> %512, ptr %500, align 1
  %513 = trunc i32 %489 to i8
  %514 = shl i8 1, %513
  %515 = xor i8 %514, -1
  %516 = and i8 %490, %515
  %517 = select i1 %509, i8 %516, i8 %490
  store i8 %517, ptr %frame.active, align 1
  %.splatinsert52 = insertelement <8 x i1> poison, i1 %499, i64 0
  %.splat53 = shufflevector <8 x i1> %.splatinsert52, <8 x i1> poison, <8 x i32> zeroinitializer
  %518 = and <8 x i1> %convergence.cascade.flow48, %.splat53
  %519 = load <8 x i1>, ptr %runnable.mask, align 1
  %520 = xor <8 x i1> %518, splat (i1 true)
  %521 = and <8 x i1> %519, %520
  store <8 x i1> %521, ptr %runnable.mask, align 1
  %.splatinsert54 = insertelement <8 x i1> poison, i1 %509, i64 0
  %.splat55 = shufflevector <8 x i1> %.splatinsert54, <8 x i1> poison, <8 x i32> zeroinitializer
  %522 = select <8 x i1> %.splat55, <8 x i1> %504, <8 x i1> zeroinitializer
  %523 = load <8 x i32>, ptr %frame.parent.token, align 32
  %524 = extractelement <8 x i32> %523, i32 %489
  %525 = select i1 %509, i32 %524, i32 %485
  store i32 %525, ptr %current.token, align 4
  %.splatinsert56 = insertelement <8 x i1> poison, i1 %499, i64 0
  %.splat57 = shufflevector <8 x i1> %.splatinsert56, <8 x i1> poison, <8 x i32> zeroinitializer
  %526 = select <8 x i1> %.splat57, <8 x i1> %522, <8 x i1> %convergence.cascade.flow48
  %527 = add i32 %convergence.cascade.depth49, 1
  %528 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %526)
  %529 = icmp ult i32 %527, 8
  %530 = and i1 %528, %529
  %531 = and i1 %499, %530
  %convergence.parent.token58 = load i32, ptr %current.token, align 4
  %convergence.parent.present59 = icmp ne i32 %convergence.parent.token58, 0
  %532 = and i1 %531, %convergence.parent.present59
  br i1 %532, label %convergence.cascade44, label %convergence.cascade.exit45

convergence.cascade.exit45:                       ; preds = %convergence.cascade44, %schedule.5
  %convergence.cascade.result60 = phi <8 x i1> [ %166, %schedule.5 ], [ %526, %convergence.cascade44 ]
  %533 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result60)
  br i1 %533, label %convergence.target.5.ready, label %scheduler.loop

convergence.target.5.ready:                       ; preds = %convergence.cascade.exit45
  %534 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result60)
  %535 = bitcast <8 x i1> %convergence.cascade.result60 to i8
  %536 = call i8 @llvm.cttz.i8(i8 %535, i1 false)
  %537 = zext i8 %536 to i32
  %538 = select i1 %534, i32 %537, i32 0
  %539 = load <8 x i64>, ptr %.slot4, align 64
  %540 = select <8 x i1> %convergence.cascade.result60, <8 x i64> zeroinitializer, <8 x i64> %539
  store <8 x i64> %540, ptr %.slot4, align 64
  store <8 x i1> %convergence.cascade.result60, ptr %current.mask, align 1
  %541 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result60)
  br i1 %541, label %schedule.6, label %scheduler.loop

varying.divergent62:                              ; preds = %schedule.6
  %542 = load i32, ptr %current.token, align 4
  %543 = icmp ne i32 %542, 0
  %544 = sub i32 %542, 1
  %545 = select i1 %543, i32 %544, i32 0
  %546 = load i8, ptr %frame.active, align 1
  %547 = trunc i32 %545 to i8
  %548 = shl i8 1, %547
  %549 = and i8 %546, %548
  %550 = icmp ne i8 %549, 0
  %551 = load <8 x i32>, ptr %frame.static.id, align 32
  %552 = extractelement <8 x i32> %551, i32 %545
  %553 = icmp eq i32 %552, 2
  %554 = and i1 %550, %553
  %555 = and i1 %543, %554
  %556 = xor i1 %555, true
  %557 = and i1 true, %556
  %558 = xor i8 %546, -1
  %559 = icmp ne i8 %558, 0
  %560 = xor i1 %559, true
  %561 = and i1 %557, %560
  br i1 %561, label %convergence.overflow.trap64, label %convergence.overflow.resume65

varying.coherent63:                               ; preds = %schedule.6
  br i1 %177, label %varying.coherent.true70, label %varying.coherent.false71

convergence.overflow.trap64:                      ; preds = %varying.divergent62
  call void @llvm.trap()
  unreachable

convergence.overflow.resume65:                    ; preds = %varying.divergent62
  %562 = call i8 @llvm.cttz.i8(i8 %558, i1 false)
  %563 = zext i8 %562 to i32
  %564 = select i1 %559, i32 %563, i32 0
  %565 = trunc i32 %564 to i8
  %566 = shl i8 1, %565
  %567 = or i8 %546, %566
  %568 = select i1 %557, i8 %567, i8 %546
  store i8 %568, ptr %frame.active, align 1
  %569 = load <8 x i32>, ptr %frame.static.id, align 32
  %570 = extractelement <8 x i32> %569, i32 %564
  %571 = select i1 %557, i32 2, i32 %570
  %572 = load <8 x i32>, ptr %frame.static.id, align 32
  %573 = insertelement <8 x i32> %572, i32 %571, i32 %564
  store <8 x i32> %573, ptr %frame.static.id, align 32
  %574 = load <8 x i32>, ptr %frame.parent.token, align 32
  %575 = extractelement <8 x i32> %574, i32 %564
  %576 = select i1 %557, i32 %542, i32 %575
  %577 = load <8 x i32>, ptr %frame.parent.token, align 32
  %578 = insertelement <8 x i32> %577, i32 %576, i32 %564
  store <8 x i32> %578, ptr %frame.parent.token, align 32
  %579 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %564
  %580 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %564
  %581 = load <8 x i1>, ptr %579, align 1
  %582 = load <8 x i1>, ptr %580, align 1
  %583 = select i1 %557, <8 x i1> %167, <8 x i1> %581
  store <8 x i1> %583, ptr %579, align 1
  %584 = select i1 %557, <8 x i1> zeroinitializer, <8 x i1> %582
  store <8 x i1> %584, ptr %580, align 1
  %585 = add i32 %564, 1
  %586 = select i1 %555, i32 %542, i32 %585
  %587 = select i1 true, i32 %586, i32 %542
  store i32 %587, ptr %current.token, align 4
  %588 = load i32, ptr %current.token, align 4
  %589 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %174)
  %590 = load i32, ptr %ready.count, align 4
  %591 = icmp uge i32 %590, 8
  %592 = and i1 %589, %591
  br i1 %592, label %ready.overflow.trap66, label %ready.overflow.resume67

ready.overflow.trap66:                            ; preds = %convergence.overflow.resume65
  call void @llvm.trap()
  unreachable

ready.overflow.resume67:                          ; preds = %convergence.overflow.resume65
  %593 = select i1 %589, i32 %590, i32 0
  %594 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %593
  %595 = load <8 x i1>, ptr %594, align 1
  %596 = select i1 %589, <8 x i1> %174, <8 x i1> %595
  store <8 x i1> %596, ptr %594, align 1
  %597 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %593
  %598 = load i32, ptr %597, align 4
  %599 = select i1 %589, i32 7, i32 %598
  store i32 %599, ptr %597, align 4
  %600 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %593
  %601 = load i32, ptr %600, align 4
  %602 = select i1 %589, i32 %588, i32 %601
  store i32 %602, ptr %600, align 4
  %603 = add i32 %590, 1
  %604 = select i1 %589, i32 %603, i32 %590
  store i32 %604, ptr %ready.count, align 4
  %605 = load <8 x i1>, ptr %runnable.mask, align 1
  %606 = or <8 x i1> %605, %174
  store <8 x i1> %606, ptr %runnable.mask, align 1
  %607 = load i32, ptr %current.token, align 4
  %608 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %176)
  %609 = load i32, ptr %ready.count, align 4
  %610 = icmp uge i32 %609, 8
  %611 = and i1 %608, %610
  br i1 %611, label %ready.overflow.trap68, label %ready.overflow.resume69

ready.overflow.trap68:                            ; preds = %ready.overflow.resume67
  call void @llvm.trap()
  unreachable

ready.overflow.resume69:                          ; preds = %ready.overflow.resume67
  %612 = select i1 %608, i32 %609, i32 0
  %613 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %612
  %614 = load <8 x i1>, ptr %613, align 1
  %615 = select i1 %608, <8 x i1> %176, <8 x i1> %614
  store <8 x i1> %615, ptr %613, align 1
  %616 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %612
  %617 = load i32, ptr %616, align 4
  %618 = select i1 %608, i32 10, i32 %617
  store i32 %618, ptr %616, align 4
  %619 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %612
  %620 = load i32, ptr %619, align 4
  %621 = select i1 %608, i32 %607, i32 %620
  store i32 %621, ptr %619, align 4
  %622 = add i32 %609, 1
  %623 = select i1 %608, i32 %622, i32 %609
  store i32 %623, ptr %ready.count, align 4
  %624 = load <8 x i1>, ptr %runnable.mask, align 1
  %625 = or <8 x i1> %624, %176
  store <8 x i1> %625, ptr %runnable.mask, align 1
  br label %scheduler.loop

varying.coherent.true70:                          ; preds = %varying.coherent63
  store <8 x i1> %167, ptr %current.mask, align 1
  %626 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %167)
  br i1 %626, label %schedule.7, label %scheduler.loop

varying.coherent.false71:                         ; preds = %varying.coherent63
  store <8 x i1> %167, ptr %current.mask, align 1
  %627 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %167)
  br i1 %627, label %schedule.10, label %scheduler.loop

varying.divergent77:                              ; preds = %schedule.7
  %628 = load i32, ptr %current.token, align 4
  %629 = icmp ne i32 %628, 0
  %630 = sub i32 %628, 1
  %631 = select i1 %629, i32 %630, i32 0
  %632 = load i8, ptr %frame.active, align 1
  %633 = trunc i32 %631 to i8
  %634 = shl i8 1, %633
  %635 = and i8 %632, %634
  %636 = icmp ne i8 %635, 0
  %637 = load <8 x i32>, ptr %frame.static.id, align 32
  %638 = extractelement <8 x i32> %637, i32 %631
  %639 = icmp eq i32 %638, 3
  %640 = and i1 %636, %639
  %641 = and i1 %629, %640
  %642 = xor i1 %641, true
  %643 = and i1 true, %642
  %644 = xor i8 %632, -1
  %645 = icmp ne i8 %644, 0
  %646 = xor i1 %645, true
  %647 = and i1 %643, %646
  br i1 %647, label %convergence.overflow.trap79, label %convergence.overflow.resume80

varying.coherent78:                               ; preds = %schedule.7
  br i1 %225, label %varying.coherent.true85, label %varying.coherent.false86

convergence.overflow.trap79:                      ; preds = %varying.divergent77
  call void @llvm.trap()
  unreachable

convergence.overflow.resume80:                    ; preds = %varying.divergent77
  %648 = call i8 @llvm.cttz.i8(i8 %644, i1 false)
  %649 = zext i8 %648 to i32
  %650 = select i1 %645, i32 %649, i32 0
  %651 = trunc i32 %650 to i8
  %652 = shl i8 1, %651
  %653 = or i8 %632, %652
  %654 = select i1 %643, i8 %653, i8 %632
  store i8 %654, ptr %frame.active, align 1
  %655 = load <8 x i32>, ptr %frame.static.id, align 32
  %656 = extractelement <8 x i32> %655, i32 %650
  %657 = select i1 %643, i32 3, i32 %656
  %658 = load <8 x i32>, ptr %frame.static.id, align 32
  %659 = insertelement <8 x i32> %658, i32 %657, i32 %650
  store <8 x i32> %659, ptr %frame.static.id, align 32
  %660 = load <8 x i32>, ptr %frame.parent.token, align 32
  %661 = extractelement <8 x i32> %660, i32 %650
  %662 = select i1 %643, i32 %628, i32 %661
  %663 = load <8 x i32>, ptr %frame.parent.token, align 32
  %664 = insertelement <8 x i32> %663, i32 %662, i32 %650
  store <8 x i32> %664, ptr %frame.parent.token, align 32
  %665 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %650
  %666 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %650
  %667 = load <8 x i1>, ptr %665, align 1
  %668 = load <8 x i1>, ptr %666, align 1
  %669 = select i1 %643, <8 x i1> %180, <8 x i1> %667
  store <8 x i1> %669, ptr %665, align 1
  %670 = select i1 %643, <8 x i1> zeroinitializer, <8 x i1> %668
  store <8 x i1> %670, ptr %666, align 1
  %671 = add i32 %650, 1
  %672 = select i1 %641, i32 %628, i32 %671
  %673 = select i1 true, i32 %672, i32 %628
  store i32 %673, ptr %current.token, align 4
  %674 = load i32, ptr %current.token, align 4
  %675 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %222)
  %676 = load i32, ptr %ready.count, align 4
  %677 = icmp uge i32 %676, 8
  %678 = and i1 %675, %677
  br i1 %678, label %ready.overflow.trap81, label %ready.overflow.resume82

ready.overflow.trap81:                            ; preds = %convergence.overflow.resume80
  call void @llvm.trap()
  unreachable

ready.overflow.resume82:                          ; preds = %convergence.overflow.resume80
  %679 = select i1 %675, i32 %676, i32 0
  %680 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %679
  %681 = load <8 x i1>, ptr %680, align 1
  %682 = select i1 %675, <8 x i1> %222, <8 x i1> %681
  store <8 x i1> %682, ptr %680, align 1
  %683 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %679
  %684 = load i32, ptr %683, align 4
  %685 = select i1 %675, i32 8, i32 %684
  store i32 %685, ptr %683, align 4
  %686 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %679
  %687 = load i32, ptr %686, align 4
  %688 = select i1 %675, i32 %674, i32 %687
  store i32 %688, ptr %686, align 4
  %689 = add i32 %676, 1
  %690 = select i1 %675, i32 %689, i32 %676
  store i32 %690, ptr %ready.count, align 4
  %691 = load <8 x i1>, ptr %runnable.mask, align 1
  %692 = or <8 x i1> %691, %222
  store <8 x i1> %692, ptr %runnable.mask, align 1
  %693 = load i32, ptr %current.token, align 4
  %694 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %224)
  %695 = load i32, ptr %ready.count, align 4
  %696 = icmp uge i32 %695, 8
  %697 = and i1 %694, %696
  br i1 %697, label %ready.overflow.trap83, label %ready.overflow.resume84

ready.overflow.trap83:                            ; preds = %ready.overflow.resume82
  call void @llvm.trap()
  unreachable

ready.overflow.resume84:                          ; preds = %ready.overflow.resume82
  %698 = select i1 %694, i32 %695, i32 0
  %699 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %698
  %700 = load <8 x i1>, ptr %699, align 1
  %701 = select i1 %694, <8 x i1> %224, <8 x i1> %700
  store <8 x i1> %701, ptr %699, align 1
  %702 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %698
  %703 = load i32, ptr %702, align 4
  %704 = select i1 %694, i32 9, i32 %703
  store i32 %704, ptr %702, align 4
  %705 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %698
  %706 = load i32, ptr %705, align 4
  %707 = select i1 %694, i32 %693, i32 %706
  store i32 %707, ptr %705, align 4
  %708 = add i32 %695, 1
  %709 = select i1 %694, i32 %708, i32 %695
  store i32 %709, ptr %ready.count, align 4
  %710 = load <8 x i1>, ptr %runnable.mask, align 1
  %711 = or <8 x i1> %710, %224
  store <8 x i1> %711, ptr %runnable.mask, align 1
  br label %scheduler.loop

varying.coherent.true85:                          ; preds = %varying.coherent78
  store <8 x i1> %180, ptr %current.mask, align 1
  %712 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %180)
  br i1 %712, label %schedule.8, label %scheduler.loop

varying.coherent.false86:                         ; preds = %varying.coherent78
  store <8 x i1> %180, ptr %current.mask, align 1
  %713 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %180)
  br i1 %713, label %schedule.9, label %scheduler.loop

convergence.cascade89:                            ; preds = %convergence.cascade89, %schedule.9
  %convergence.cascade.flow93 = phi <8 x i1> [ %238, %schedule.9 ], [ %756, %convergence.cascade89 ]
  %convergence.cascade.depth94 = phi i32 [ 0, %schedule.9 ], [ %757, %convergence.cascade89 ]
  %714 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow93)
  %715 = load i32, ptr %current.token, align 4
  %716 = icmp ne i32 %715, 0
  %717 = and i1 %714, %716
  %718 = sub i32 %715, 1
  %719 = select i1 %717, i32 %718, i32 0
  %720 = load i8, ptr %frame.active, align 1
  %721 = trunc i32 %719 to i8
  %722 = shl i8 1, %721
  %723 = and i8 %720, %722
  %724 = icmp ne i8 %723, 0
  %725 = load <8 x i32>, ptr %frame.static.id, align 32
  %726 = extractelement <8 x i32> %725, i32 %719
  %convergence.target.pointer95 = getelementptr inbounds [4 x i32], ptr @convergence.targets, i32 0, i32 %726
  %convergence.dynamic.target96 = load i32, ptr %convergence.target.pointer95, align 4
  %727 = icmp eq i32 %convergence.dynamic.target96, 9
  %728 = and i1 %724, %727
  %729 = and i1 %717, %728
  %730 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %719
  %731 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %719
  %732 = load <8 x i1>, ptr %730, align 1
  %733 = load <8 x i1>, ptr %731, align 1
  %734 = or <8 x i1> %733, %convergence.cascade.flow93
  %735 = load <8 x i1>, ptr %live.mask, align 1
  %736 = and <8 x i1> %732, %735
  %737 = icmp eq <8 x i1> %734, %736
  %738 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %737)
  %739 = and i1 %729, %738
  %740 = select i1 %739, <8 x i1> zeroinitializer, <8 x i1> %734
  %741 = select i1 %729, <8 x i1> %740, <8 x i1> %733
  store <8 x i1> %741, ptr %731, align 1
  %742 = select i1 %739, <8 x i1> zeroinitializer, <8 x i1> %732
  store <8 x i1> %742, ptr %730, align 1
  %743 = trunc i32 %719 to i8
  %744 = shl i8 1, %743
  %745 = xor i8 %744, -1
  %746 = and i8 %720, %745
  %747 = select i1 %739, i8 %746, i8 %720
  store i8 %747, ptr %frame.active, align 1
  %.splatinsert97 = insertelement <8 x i1> poison, i1 %729, i64 0
  %.splat98 = shufflevector <8 x i1> %.splatinsert97, <8 x i1> poison, <8 x i32> zeroinitializer
  %748 = and <8 x i1> %convergence.cascade.flow93, %.splat98
  %749 = load <8 x i1>, ptr %runnable.mask, align 1
  %750 = xor <8 x i1> %748, splat (i1 true)
  %751 = and <8 x i1> %749, %750
  store <8 x i1> %751, ptr %runnable.mask, align 1
  %.splatinsert99 = insertelement <8 x i1> poison, i1 %739, i64 0
  %.splat100 = shufflevector <8 x i1> %.splatinsert99, <8 x i1> poison, <8 x i32> zeroinitializer
  %752 = select <8 x i1> %.splat100, <8 x i1> %734, <8 x i1> zeroinitializer
  %753 = load <8 x i32>, ptr %frame.parent.token, align 32
  %754 = extractelement <8 x i32> %753, i32 %719
  %755 = select i1 %739, i32 %754, i32 %715
  store i32 %755, ptr %current.token, align 4
  %.splatinsert101 = insertelement <8 x i1> poison, i1 %729, i64 0
  %.splat102 = shufflevector <8 x i1> %.splatinsert101, <8 x i1> poison, <8 x i32> zeroinitializer
  %756 = select <8 x i1> %.splat102, <8 x i1> %752, <8 x i1> %convergence.cascade.flow93
  %757 = add i32 %convergence.cascade.depth94, 1
  %758 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %756)
  %759 = icmp ult i32 %757, 8
  %760 = and i1 %758, %759
  %761 = and i1 %729, %760
  %convergence.parent.token103 = load i32, ptr %current.token, align 4
  %convergence.parent.present104 = icmp ne i32 %convergence.parent.token103, 0
  %762 = and i1 %761, %convergence.parent.present104
  br i1 %762, label %convergence.cascade89, label %convergence.cascade.exit90

convergence.cascade.exit90:                       ; preds = %convergence.cascade89, %schedule.9
  %convergence.cascade.result105 = phi <8 x i1> [ %238, %schedule.9 ], [ %756, %convergence.cascade89 ]
  %763 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result105)
  br i1 %763, label %convergence.target.9.ready, label %scheduler.loop

convergence.target.9.ready:                       ; preds = %convergence.cascade.exit90
  %764 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result105)
  %765 = bitcast <8 x i1> %convergence.cascade.result105 to i8
  %766 = call i8 @llvm.cttz.i8(i8 %765, i1 false)
  %767 = zext i8 %766 to i32
  %768 = select i1 %764, i32 %767, i32 0
  %.state106 = load <8 x i64>, ptr %.slot4, align 64
  %769 = add <8 x i64> %.state106, splat (i64 1)
  %770 = load <8 x i64>, ptr %.slot4, align 64
  %771 = select <8 x i1> %convergence.cascade.result105, <8 x i64> %769, <8 x i64> %770
  store <8 x i64> %771, ptr %.slot4, align 64
  store <8 x i1> %convergence.cascade.result105, ptr %current.mask, align 1
  %772 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result105)
  br i1 %772, label %schedule.6, label %scheduler.loop

convergence.cascade107:                           ; preds = %convergence.cascade107, %schedule.10
  %convergence.cascade.flow111 = phi <8 x i1> [ %239, %schedule.10 ], [ %815, %convergence.cascade107 ]
  %convergence.cascade.depth112 = phi i32 [ 0, %schedule.10 ], [ %816, %convergence.cascade107 ]
  %773 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow111)
  %774 = load i32, ptr %current.token, align 4
  %775 = icmp ne i32 %774, 0
  %776 = and i1 %773, %775
  %777 = sub i32 %774, 1
  %778 = select i1 %776, i32 %777, i32 0
  %779 = load i8, ptr %frame.active, align 1
  %780 = trunc i32 %778 to i8
  %781 = shl i8 1, %780
  %782 = and i8 %779, %781
  %783 = icmp ne i8 %782, 0
  %784 = load <8 x i32>, ptr %frame.static.id, align 32
  %785 = extractelement <8 x i32> %784, i32 %778
  %convergence.target.pointer113 = getelementptr inbounds [4 x i32], ptr @convergence.targets, i32 0, i32 %785
  %convergence.dynamic.target114 = load i32, ptr %convergence.target.pointer113, align 4
  %786 = icmp eq i32 %convergence.dynamic.target114, 10
  %787 = and i1 %783, %786
  %788 = and i1 %776, %787
  %789 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %778
  %790 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %778
  %791 = load <8 x i1>, ptr %789, align 1
  %792 = load <8 x i1>, ptr %790, align 1
  %793 = or <8 x i1> %792, %convergence.cascade.flow111
  %794 = load <8 x i1>, ptr %live.mask, align 1
  %795 = and <8 x i1> %791, %794
  %796 = icmp eq <8 x i1> %793, %795
  %797 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %796)
  %798 = and i1 %788, %797
  %799 = select i1 %798, <8 x i1> zeroinitializer, <8 x i1> %793
  %800 = select i1 %788, <8 x i1> %799, <8 x i1> %792
  store <8 x i1> %800, ptr %790, align 1
  %801 = select i1 %798, <8 x i1> zeroinitializer, <8 x i1> %791
  store <8 x i1> %801, ptr %789, align 1
  %802 = trunc i32 %778 to i8
  %803 = shl i8 1, %802
  %804 = xor i8 %803, -1
  %805 = and i8 %779, %804
  %806 = select i1 %798, i8 %805, i8 %779
  store i8 %806, ptr %frame.active, align 1
  %.splatinsert115 = insertelement <8 x i1> poison, i1 %788, i64 0
  %.splat116 = shufflevector <8 x i1> %.splatinsert115, <8 x i1> poison, <8 x i32> zeroinitializer
  %807 = and <8 x i1> %convergence.cascade.flow111, %.splat116
  %808 = load <8 x i1>, ptr %runnable.mask, align 1
  %809 = xor <8 x i1> %807, splat (i1 true)
  %810 = and <8 x i1> %808, %809
  store <8 x i1> %810, ptr %runnable.mask, align 1
  %.splatinsert117 = insertelement <8 x i1> poison, i1 %798, i64 0
  %.splat118 = shufflevector <8 x i1> %.splatinsert117, <8 x i1> poison, <8 x i32> zeroinitializer
  %811 = select <8 x i1> %.splat118, <8 x i1> %793, <8 x i1> zeroinitializer
  %812 = load <8 x i32>, ptr %frame.parent.token, align 32
  %813 = extractelement <8 x i32> %812, i32 %778
  %814 = select i1 %798, i32 %813, i32 %774
  store i32 %814, ptr %current.token, align 4
  %.splatinsert119 = insertelement <8 x i1> poison, i1 %788, i64 0
  %.splat120 = shufflevector <8 x i1> %.splatinsert119, <8 x i1> poison, <8 x i32> zeroinitializer
  %815 = select <8 x i1> %.splat120, <8 x i1> %811, <8 x i1> %convergence.cascade.flow111
  %816 = add i32 %convergence.cascade.depth112, 1
  %817 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %815)
  %818 = icmp ult i32 %816, 8
  %819 = and i1 %817, %818
  %820 = and i1 %788, %819
  %convergence.parent.token121 = load i32, ptr %current.token, align 4
  %convergence.parent.present122 = icmp ne i32 %convergence.parent.token121, 0
  %821 = and i1 %820, %convergence.parent.present122
  br i1 %821, label %convergence.cascade107, label %convergence.cascade.exit108

convergence.cascade.exit108:                      ; preds = %convergence.cascade107, %schedule.10
  %convergence.cascade.result123 = phi <8 x i1> [ %239, %schedule.10 ], [ %815, %convergence.cascade107 ]
  %822 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result123)
  br i1 %822, label %convergence.target.10.ready, label %scheduler.loop

convergence.target.10.ready:                      ; preds = %convergence.cascade.exit108
  %823 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result123)
  %824 = bitcast <8 x i1> %convergence.cascade.result123 to i8
  %825 = call i8 @llvm.cttz.i8(i8 %824, i1 false)
  %826 = zext i8 %825 to i32
  %827 = select i1 %823, i32 %826, i32 0
  %828 = load <8 x i1>, ptr %live.mask, align 1
  %829 = xor <8 x i1> %convergence.cascade.result123, splat (i1 true)
  %830 = and <8 x i1> %828, %829
  store <8 x i1> %830, ptr %live.mask, align 1
  %831 = load <8 x i1>, ptr %runnable.mask, align 1
  %832 = xor <8 x i1> %convergence.cascade.result123, splat (i1 true)
  %833 = and <8 x i1> %831, %832
  store <8 x i1> %833, ptr %runnable.mask, align 1
  %return.active.frames = load i8, ptr %frame.active, align 1
  %return.frames.present = icmp ne i8 %return.active.frames, 0
  br i1 %return.frames.present, label %return.frame.cleanup, label %return.frame.cleanup.done

return.frame.cleanup:                             ; preds = %convergence.target.10.ready
  %834 = load i8, ptr %frame.active, align 1
  %835 = and i8 %834, 1
  %836 = icmp ne i8 %835, 0
  %837 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 0
  %838 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 0
  %839 = load <8 x i1>, ptr %837, align 1
  %840 = load <8 x i1>, ptr %838, align 1
  %841 = and <8 x i1> %839, %830
  %842 = icmp eq <8 x i1> %840, %841
  %843 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %842)
  %844 = and i1 %836, %843
  %.splatinsert124 = insertelement <8 x i1> poison, i1 %844, i64 0
  %.splat125 = shufflevector <8 x i1> %.splatinsert124, <8 x i1> poison, <8 x i32> zeroinitializer
  %845 = select <8 x i1> %.splat125, <8 x i1> %840, <8 x i1> zeroinitializer
  %846 = select i1 %844, <8 x i1> zeroinitializer, <8 x i1> %841
  store <8 x i1> %846, ptr %837, align 1
  %847 = select i1 %844, <8 x i1> zeroinitializer, <8 x i1> %840
  store <8 x i1> %847, ptr %838, align 1
  %848 = and i8 %834, -2
  %849 = select i1 %844, i8 %848, i8 %834
  store i8 %849, ptr %frame.active, align 1
  %850 = load <8 x i32>, ptr %frame.parent.token, align 32
  %851 = extractelement <8 x i32> %850, i32 0
  %852 = load <8 x i32>, ptr %frame.static.id, align 32
  %853 = extractelement <8 x i32> %852, i32 0
  %convergence.target.pointer126 = getelementptr inbounds [4 x i32], ptr @convergence.targets, i32 0, i32 %853
  %convergence.dynamic.target127 = load i32, ptr %convergence.target.pointer126, align 4
  %854 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %845)
  %855 = load i32, ptr %ready.count, align 4
  %856 = icmp uge i32 %855, 8
  %857 = and i1 %854, %856
  br i1 %857, label %ready.overflow.trap128, label %ready.overflow.resume129

return.frame.cleanup.done:                        ; preds = %ready.overflow.resume171, %convergence.target.10.ready
  br label %scheduler.loop

ready.overflow.trap128:                           ; preds = %return.frame.cleanup
  call void @llvm.trap()
  unreachable

ready.overflow.resume129:                         ; preds = %return.frame.cleanup
  %858 = select i1 %854, i32 %855, i32 0
  %859 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %858
  %860 = load <8 x i1>, ptr %859, align 1
  %861 = select i1 %854, <8 x i1> %845, <8 x i1> %860
  store <8 x i1> %861, ptr %859, align 1
  %862 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %858
  %863 = load i32, ptr %862, align 4
  %864 = select i1 %854, i32 %convergence.dynamic.target127, i32 %863
  store i32 %864, ptr %862, align 4
  %865 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %858
  %866 = load i32, ptr %865, align 4
  %867 = select i1 %854, i32 %851, i32 %866
  store i32 %867, ptr %865, align 4
  %868 = add i32 %855, 1
  %869 = select i1 %854, i32 %868, i32 %855
  store i32 %869, ptr %ready.count, align 4
  %870 = load <8 x i1>, ptr %runnable.mask, align 1
  %871 = or <8 x i1> %870, %845
  store <8 x i1> %871, ptr %runnable.mask, align 1
  %872 = load i8, ptr %frame.active, align 1
  %873 = and i8 %872, 2
  %874 = icmp ne i8 %873, 0
  %875 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 1
  %876 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 1
  %877 = load <8 x i1>, ptr %875, align 1
  %878 = load <8 x i1>, ptr %876, align 1
  %879 = and <8 x i1> %877, %830
  %880 = icmp eq <8 x i1> %878, %879
  %881 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %880)
  %882 = and i1 %874, %881
  %.splatinsert130 = insertelement <8 x i1> poison, i1 %882, i64 0
  %.splat131 = shufflevector <8 x i1> %.splatinsert130, <8 x i1> poison, <8 x i32> zeroinitializer
  %883 = select <8 x i1> %.splat131, <8 x i1> %878, <8 x i1> zeroinitializer
  %884 = select i1 %882, <8 x i1> zeroinitializer, <8 x i1> %879
  store <8 x i1> %884, ptr %875, align 1
  %885 = select i1 %882, <8 x i1> zeroinitializer, <8 x i1> %878
  store <8 x i1> %885, ptr %876, align 1
  %886 = and i8 %872, -3
  %887 = select i1 %882, i8 %886, i8 %872
  store i8 %887, ptr %frame.active, align 1
  %888 = load <8 x i32>, ptr %frame.parent.token, align 32
  %889 = extractelement <8 x i32> %888, i32 1
  %890 = load <8 x i32>, ptr %frame.static.id, align 32
  %891 = extractelement <8 x i32> %890, i32 1
  %convergence.target.pointer132 = getelementptr inbounds [4 x i32], ptr @convergence.targets, i32 0, i32 %891
  %convergence.dynamic.target133 = load i32, ptr %convergence.target.pointer132, align 4
  %892 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %883)
  %893 = load i32, ptr %ready.count, align 4
  %894 = icmp uge i32 %893, 8
  %895 = and i1 %892, %894
  br i1 %895, label %ready.overflow.trap134, label %ready.overflow.resume135

ready.overflow.trap134:                           ; preds = %ready.overflow.resume129
  call void @llvm.trap()
  unreachable

ready.overflow.resume135:                         ; preds = %ready.overflow.resume129
  %896 = select i1 %892, i32 %893, i32 0
  %897 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %896
  %898 = load <8 x i1>, ptr %897, align 1
  %899 = select i1 %892, <8 x i1> %883, <8 x i1> %898
  store <8 x i1> %899, ptr %897, align 1
  %900 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %896
  %901 = load i32, ptr %900, align 4
  %902 = select i1 %892, i32 %convergence.dynamic.target133, i32 %901
  store i32 %902, ptr %900, align 4
  %903 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %896
  %904 = load i32, ptr %903, align 4
  %905 = select i1 %892, i32 %889, i32 %904
  store i32 %905, ptr %903, align 4
  %906 = add i32 %893, 1
  %907 = select i1 %892, i32 %906, i32 %893
  store i32 %907, ptr %ready.count, align 4
  %908 = load <8 x i1>, ptr %runnable.mask, align 1
  %909 = or <8 x i1> %908, %883
  store <8 x i1> %909, ptr %runnable.mask, align 1
  %910 = load i8, ptr %frame.active, align 1
  %911 = and i8 %910, 4
  %912 = icmp ne i8 %911, 0
  %913 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 2
  %914 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 2
  %915 = load <8 x i1>, ptr %913, align 1
  %916 = load <8 x i1>, ptr %914, align 1
  %917 = and <8 x i1> %915, %830
  %918 = icmp eq <8 x i1> %916, %917
  %919 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %918)
  %920 = and i1 %912, %919
  %.splatinsert136 = insertelement <8 x i1> poison, i1 %920, i64 0
  %.splat137 = shufflevector <8 x i1> %.splatinsert136, <8 x i1> poison, <8 x i32> zeroinitializer
  %921 = select <8 x i1> %.splat137, <8 x i1> %916, <8 x i1> zeroinitializer
  %922 = select i1 %920, <8 x i1> zeroinitializer, <8 x i1> %917
  store <8 x i1> %922, ptr %913, align 1
  %923 = select i1 %920, <8 x i1> zeroinitializer, <8 x i1> %916
  store <8 x i1> %923, ptr %914, align 1
  %924 = and i8 %910, -5
  %925 = select i1 %920, i8 %924, i8 %910
  store i8 %925, ptr %frame.active, align 1
  %926 = load <8 x i32>, ptr %frame.parent.token, align 32
  %927 = extractelement <8 x i32> %926, i32 2
  %928 = load <8 x i32>, ptr %frame.static.id, align 32
  %929 = extractelement <8 x i32> %928, i32 2
  %convergence.target.pointer138 = getelementptr inbounds [4 x i32], ptr @convergence.targets, i32 0, i32 %929
  %convergence.dynamic.target139 = load i32, ptr %convergence.target.pointer138, align 4
  %930 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %921)
  %931 = load i32, ptr %ready.count, align 4
  %932 = icmp uge i32 %931, 8
  %933 = and i1 %930, %932
  br i1 %933, label %ready.overflow.trap140, label %ready.overflow.resume141

ready.overflow.trap140:                           ; preds = %ready.overflow.resume135
  call void @llvm.trap()
  unreachable

ready.overflow.resume141:                         ; preds = %ready.overflow.resume135
  %934 = select i1 %930, i32 %931, i32 0
  %935 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %934
  %936 = load <8 x i1>, ptr %935, align 1
  %937 = select i1 %930, <8 x i1> %921, <8 x i1> %936
  store <8 x i1> %937, ptr %935, align 1
  %938 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %934
  %939 = load i32, ptr %938, align 4
  %940 = select i1 %930, i32 %convergence.dynamic.target139, i32 %939
  store i32 %940, ptr %938, align 4
  %941 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %934
  %942 = load i32, ptr %941, align 4
  %943 = select i1 %930, i32 %927, i32 %942
  store i32 %943, ptr %941, align 4
  %944 = add i32 %931, 1
  %945 = select i1 %930, i32 %944, i32 %931
  store i32 %945, ptr %ready.count, align 4
  %946 = load <8 x i1>, ptr %runnable.mask, align 1
  %947 = or <8 x i1> %946, %921
  store <8 x i1> %947, ptr %runnable.mask, align 1
  %948 = load i8, ptr %frame.active, align 1
  %949 = and i8 %948, 8
  %950 = icmp ne i8 %949, 0
  %951 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 3
  %952 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 3
  %953 = load <8 x i1>, ptr %951, align 1
  %954 = load <8 x i1>, ptr %952, align 1
  %955 = and <8 x i1> %953, %830
  %956 = icmp eq <8 x i1> %954, %955
  %957 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %956)
  %958 = and i1 %950, %957
  %.splatinsert142 = insertelement <8 x i1> poison, i1 %958, i64 0
  %.splat143 = shufflevector <8 x i1> %.splatinsert142, <8 x i1> poison, <8 x i32> zeroinitializer
  %959 = select <8 x i1> %.splat143, <8 x i1> %954, <8 x i1> zeroinitializer
  %960 = select i1 %958, <8 x i1> zeroinitializer, <8 x i1> %955
  store <8 x i1> %960, ptr %951, align 1
  %961 = select i1 %958, <8 x i1> zeroinitializer, <8 x i1> %954
  store <8 x i1> %961, ptr %952, align 1
  %962 = and i8 %948, -9
  %963 = select i1 %958, i8 %962, i8 %948
  store i8 %963, ptr %frame.active, align 1
  %964 = load <8 x i32>, ptr %frame.parent.token, align 32
  %965 = extractelement <8 x i32> %964, i32 3
  %966 = load <8 x i32>, ptr %frame.static.id, align 32
  %967 = extractelement <8 x i32> %966, i32 3
  %convergence.target.pointer144 = getelementptr inbounds [4 x i32], ptr @convergence.targets, i32 0, i32 %967
  %convergence.dynamic.target145 = load i32, ptr %convergence.target.pointer144, align 4
  %968 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %959)
  %969 = load i32, ptr %ready.count, align 4
  %970 = icmp uge i32 %969, 8
  %971 = and i1 %968, %970
  br i1 %971, label %ready.overflow.trap146, label %ready.overflow.resume147

ready.overflow.trap146:                           ; preds = %ready.overflow.resume141
  call void @llvm.trap()
  unreachable

ready.overflow.resume147:                         ; preds = %ready.overflow.resume141
  %972 = select i1 %968, i32 %969, i32 0
  %973 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %972
  %974 = load <8 x i1>, ptr %973, align 1
  %975 = select i1 %968, <8 x i1> %959, <8 x i1> %974
  store <8 x i1> %975, ptr %973, align 1
  %976 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %972
  %977 = load i32, ptr %976, align 4
  %978 = select i1 %968, i32 %convergence.dynamic.target145, i32 %977
  store i32 %978, ptr %976, align 4
  %979 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %972
  %980 = load i32, ptr %979, align 4
  %981 = select i1 %968, i32 %965, i32 %980
  store i32 %981, ptr %979, align 4
  %982 = add i32 %969, 1
  %983 = select i1 %968, i32 %982, i32 %969
  store i32 %983, ptr %ready.count, align 4
  %984 = load <8 x i1>, ptr %runnable.mask, align 1
  %985 = or <8 x i1> %984, %959
  store <8 x i1> %985, ptr %runnable.mask, align 1
  %986 = load i8, ptr %frame.active, align 1
  %987 = and i8 %986, 16
  %988 = icmp ne i8 %987, 0
  %989 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 4
  %990 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 4
  %991 = load <8 x i1>, ptr %989, align 1
  %992 = load <8 x i1>, ptr %990, align 1
  %993 = and <8 x i1> %991, %830
  %994 = icmp eq <8 x i1> %992, %993
  %995 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %994)
  %996 = and i1 %988, %995
  %.splatinsert148 = insertelement <8 x i1> poison, i1 %996, i64 0
  %.splat149 = shufflevector <8 x i1> %.splatinsert148, <8 x i1> poison, <8 x i32> zeroinitializer
  %997 = select <8 x i1> %.splat149, <8 x i1> %992, <8 x i1> zeroinitializer
  %998 = select i1 %996, <8 x i1> zeroinitializer, <8 x i1> %993
  store <8 x i1> %998, ptr %989, align 1
  %999 = select i1 %996, <8 x i1> zeroinitializer, <8 x i1> %992
  store <8 x i1> %999, ptr %990, align 1
  %1000 = and i8 %986, -17
  %1001 = select i1 %996, i8 %1000, i8 %986
  store i8 %1001, ptr %frame.active, align 1
  %1002 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1003 = extractelement <8 x i32> %1002, i32 4
  %1004 = load <8 x i32>, ptr %frame.static.id, align 32
  %1005 = extractelement <8 x i32> %1004, i32 4
  %convergence.target.pointer150 = getelementptr inbounds [4 x i32], ptr @convergence.targets, i32 0, i32 %1005
  %convergence.dynamic.target151 = load i32, ptr %convergence.target.pointer150, align 4
  %1006 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %997)
  %1007 = load i32, ptr %ready.count, align 4
  %1008 = icmp uge i32 %1007, 8
  %1009 = and i1 %1006, %1008
  br i1 %1009, label %ready.overflow.trap152, label %ready.overflow.resume153

ready.overflow.trap152:                           ; preds = %ready.overflow.resume147
  call void @llvm.trap()
  unreachable

ready.overflow.resume153:                         ; preds = %ready.overflow.resume147
  %1010 = select i1 %1006, i32 %1007, i32 0
  %1011 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1010
  %1012 = load <8 x i1>, ptr %1011, align 1
  %1013 = select i1 %1006, <8 x i1> %997, <8 x i1> %1012
  store <8 x i1> %1013, ptr %1011, align 1
  %1014 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1010
  %1015 = load i32, ptr %1014, align 4
  %1016 = select i1 %1006, i32 %convergence.dynamic.target151, i32 %1015
  store i32 %1016, ptr %1014, align 4
  %1017 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1010
  %1018 = load i32, ptr %1017, align 4
  %1019 = select i1 %1006, i32 %1003, i32 %1018
  store i32 %1019, ptr %1017, align 4
  %1020 = add i32 %1007, 1
  %1021 = select i1 %1006, i32 %1020, i32 %1007
  store i32 %1021, ptr %ready.count, align 4
  %1022 = load <8 x i1>, ptr %runnable.mask, align 1
  %1023 = or <8 x i1> %1022, %997
  store <8 x i1> %1023, ptr %runnable.mask, align 1
  %1024 = load i8, ptr %frame.active, align 1
  %1025 = and i8 %1024, 32
  %1026 = icmp ne i8 %1025, 0
  %1027 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 5
  %1028 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 5
  %1029 = load <8 x i1>, ptr %1027, align 1
  %1030 = load <8 x i1>, ptr %1028, align 1
  %1031 = and <8 x i1> %1029, %830
  %1032 = icmp eq <8 x i1> %1030, %1031
  %1033 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1032)
  %1034 = and i1 %1026, %1033
  %.splatinsert154 = insertelement <8 x i1> poison, i1 %1034, i64 0
  %.splat155 = shufflevector <8 x i1> %.splatinsert154, <8 x i1> poison, <8 x i32> zeroinitializer
  %1035 = select <8 x i1> %.splat155, <8 x i1> %1030, <8 x i1> zeroinitializer
  %1036 = select i1 %1034, <8 x i1> zeroinitializer, <8 x i1> %1031
  store <8 x i1> %1036, ptr %1027, align 1
  %1037 = select i1 %1034, <8 x i1> zeroinitializer, <8 x i1> %1030
  store <8 x i1> %1037, ptr %1028, align 1
  %1038 = and i8 %1024, -33
  %1039 = select i1 %1034, i8 %1038, i8 %1024
  store i8 %1039, ptr %frame.active, align 1
  %1040 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1041 = extractelement <8 x i32> %1040, i32 5
  %1042 = load <8 x i32>, ptr %frame.static.id, align 32
  %1043 = extractelement <8 x i32> %1042, i32 5
  %convergence.target.pointer156 = getelementptr inbounds [4 x i32], ptr @convergence.targets, i32 0, i32 %1043
  %convergence.dynamic.target157 = load i32, ptr %convergence.target.pointer156, align 4
  %1044 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1035)
  %1045 = load i32, ptr %ready.count, align 4
  %1046 = icmp uge i32 %1045, 8
  %1047 = and i1 %1044, %1046
  br i1 %1047, label %ready.overflow.trap158, label %ready.overflow.resume159

ready.overflow.trap158:                           ; preds = %ready.overflow.resume153
  call void @llvm.trap()
  unreachable

ready.overflow.resume159:                         ; preds = %ready.overflow.resume153
  %1048 = select i1 %1044, i32 %1045, i32 0
  %1049 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1048
  %1050 = load <8 x i1>, ptr %1049, align 1
  %1051 = select i1 %1044, <8 x i1> %1035, <8 x i1> %1050
  store <8 x i1> %1051, ptr %1049, align 1
  %1052 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1048
  %1053 = load i32, ptr %1052, align 4
  %1054 = select i1 %1044, i32 %convergence.dynamic.target157, i32 %1053
  store i32 %1054, ptr %1052, align 4
  %1055 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1048
  %1056 = load i32, ptr %1055, align 4
  %1057 = select i1 %1044, i32 %1041, i32 %1056
  store i32 %1057, ptr %1055, align 4
  %1058 = add i32 %1045, 1
  %1059 = select i1 %1044, i32 %1058, i32 %1045
  store i32 %1059, ptr %ready.count, align 4
  %1060 = load <8 x i1>, ptr %runnable.mask, align 1
  %1061 = or <8 x i1> %1060, %1035
  store <8 x i1> %1061, ptr %runnable.mask, align 1
  %1062 = load i8, ptr %frame.active, align 1
  %1063 = and i8 %1062, 64
  %1064 = icmp ne i8 %1063, 0
  %1065 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 6
  %1066 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 6
  %1067 = load <8 x i1>, ptr %1065, align 1
  %1068 = load <8 x i1>, ptr %1066, align 1
  %1069 = and <8 x i1> %1067, %830
  %1070 = icmp eq <8 x i1> %1068, %1069
  %1071 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1070)
  %1072 = and i1 %1064, %1071
  %.splatinsert160 = insertelement <8 x i1> poison, i1 %1072, i64 0
  %.splat161 = shufflevector <8 x i1> %.splatinsert160, <8 x i1> poison, <8 x i32> zeroinitializer
  %1073 = select <8 x i1> %.splat161, <8 x i1> %1068, <8 x i1> zeroinitializer
  %1074 = select i1 %1072, <8 x i1> zeroinitializer, <8 x i1> %1069
  store <8 x i1> %1074, ptr %1065, align 1
  %1075 = select i1 %1072, <8 x i1> zeroinitializer, <8 x i1> %1068
  store <8 x i1> %1075, ptr %1066, align 1
  %1076 = and i8 %1062, -65
  %1077 = select i1 %1072, i8 %1076, i8 %1062
  store i8 %1077, ptr %frame.active, align 1
  %1078 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1079 = extractelement <8 x i32> %1078, i32 6
  %1080 = load <8 x i32>, ptr %frame.static.id, align 32
  %1081 = extractelement <8 x i32> %1080, i32 6
  %convergence.target.pointer162 = getelementptr inbounds [4 x i32], ptr @convergence.targets, i32 0, i32 %1081
  %convergence.dynamic.target163 = load i32, ptr %convergence.target.pointer162, align 4
  %1082 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1073)
  %1083 = load i32, ptr %ready.count, align 4
  %1084 = icmp uge i32 %1083, 8
  %1085 = and i1 %1082, %1084
  br i1 %1085, label %ready.overflow.trap164, label %ready.overflow.resume165

ready.overflow.trap164:                           ; preds = %ready.overflow.resume159
  call void @llvm.trap()
  unreachable

ready.overflow.resume165:                         ; preds = %ready.overflow.resume159
  %1086 = select i1 %1082, i32 %1083, i32 0
  %1087 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1086
  %1088 = load <8 x i1>, ptr %1087, align 1
  %1089 = select i1 %1082, <8 x i1> %1073, <8 x i1> %1088
  store <8 x i1> %1089, ptr %1087, align 1
  %1090 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1086
  %1091 = load i32, ptr %1090, align 4
  %1092 = select i1 %1082, i32 %convergence.dynamic.target163, i32 %1091
  store i32 %1092, ptr %1090, align 4
  %1093 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1086
  %1094 = load i32, ptr %1093, align 4
  %1095 = select i1 %1082, i32 %1079, i32 %1094
  store i32 %1095, ptr %1093, align 4
  %1096 = add i32 %1083, 1
  %1097 = select i1 %1082, i32 %1096, i32 %1083
  store i32 %1097, ptr %ready.count, align 4
  %1098 = load <8 x i1>, ptr %runnable.mask, align 1
  %1099 = or <8 x i1> %1098, %1073
  store <8 x i1> %1099, ptr %runnable.mask, align 1
  %1100 = load i8, ptr %frame.active, align 1
  %1101 = and i8 %1100, -128
  %1102 = icmp ne i8 %1101, 0
  %1103 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 7
  %1104 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 7
  %1105 = load <8 x i1>, ptr %1103, align 1
  %1106 = load <8 x i1>, ptr %1104, align 1
  %1107 = and <8 x i1> %1105, %830
  %1108 = icmp eq <8 x i1> %1106, %1107
  %1109 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1108)
  %1110 = and i1 %1102, %1109
  %.splatinsert166 = insertelement <8 x i1> poison, i1 %1110, i64 0
  %.splat167 = shufflevector <8 x i1> %.splatinsert166, <8 x i1> poison, <8 x i32> zeroinitializer
  %1111 = select <8 x i1> %.splat167, <8 x i1> %1106, <8 x i1> zeroinitializer
  %1112 = select i1 %1110, <8 x i1> zeroinitializer, <8 x i1> %1107
  store <8 x i1> %1112, ptr %1103, align 1
  %1113 = select i1 %1110, <8 x i1> zeroinitializer, <8 x i1> %1106
  store <8 x i1> %1113, ptr %1104, align 1
  %1114 = and i8 %1100, 127
  %1115 = select i1 %1110, i8 %1114, i8 %1100
  store i8 %1115, ptr %frame.active, align 1
  %1116 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1117 = extractelement <8 x i32> %1116, i32 7
  %1118 = load <8 x i32>, ptr %frame.static.id, align 32
  %1119 = extractelement <8 x i32> %1118, i32 7
  %convergence.target.pointer168 = getelementptr inbounds [4 x i32], ptr @convergence.targets, i32 0, i32 %1119
  %convergence.dynamic.target169 = load i32, ptr %convergence.target.pointer168, align 4
  %1120 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1111)
  %1121 = load i32, ptr %ready.count, align 4
  %1122 = icmp uge i32 %1121, 8
  %1123 = and i1 %1120, %1122
  br i1 %1123, label %ready.overflow.trap170, label %ready.overflow.resume171

ready.overflow.trap170:                           ; preds = %ready.overflow.resume165
  call void @llvm.trap()
  unreachable

ready.overflow.resume171:                         ; preds = %ready.overflow.resume165
  %1124 = select i1 %1120, i32 %1121, i32 0
  %1125 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1124
  %1126 = load <8 x i1>, ptr %1125, align 1
  %1127 = select i1 %1120, <8 x i1> %1111, <8 x i1> %1126
  store <8 x i1> %1127, ptr %1125, align 1
  %1128 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1124
  %1129 = load i32, ptr %1128, align 4
  %1130 = select i1 %1120, i32 %convergence.dynamic.target169, i32 %1129
  store i32 %1130, ptr %1128, align 4
  %1131 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1124
  %1132 = load i32, ptr %1131, align 4
  %1133 = select i1 %1120, i32 %1117, i32 %1132
  store i32 %1133, ptr %1131, align 4
  %1134 = add i32 %1121, 1
  %1135 = select i1 %1120, i32 %1134, i32 %1121
  store i32 %1135, ptr %ready.count, align 4
  %1136 = load <8 x i1>, ptr %runnable.mask, align 1
  %1137 = or <8 x i1> %1136, %1111
  store <8 x i1> %1137, ptr %runnable.mask, align 1
  br label %return.frame.cleanup.done
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.and.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #3

define dso_local void @tile_transpose.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 64
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 64
  %3 = sub i64 64, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 8
  %8 = icmp uge i64 %packet.range.remaining, 64
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @tile_transpose(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @tile_transpose(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @tile_transpose(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @tile_transpose(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index3 = add i32 %base.thread.index, 32
  store i32 %packet.thread.index3, ptr %thread.index.address, align 4
  call void @tile_transpose(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index4 = add i32 %base.thread.index, 40
  store i32 %packet.thread.index4, ptr %thread.index.address, align 4
  call void @tile_transpose(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index5 = add i32 %base.thread.index, 48
  store i32 %packet.thread.index5, ptr %thread.index.address, align 4
  call void @tile_transpose(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index6 = add i32 %base.thread.index, 56
  store i32 %packet.thread.index6, ptr %thread.index.address, align 4
  call void @tile_transpose(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @tile_transpose(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @tile_transpose(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(write) }

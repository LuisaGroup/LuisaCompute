; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

@convergence.targets = private unnamed_addr constant [15 x i32] [i32 38, i32 7, i32 6, i32 12, i32 11, i32 17, i32 16, i32 22, i32 21, i32 27, i32 26, i32 32, i32 31, i32 37, i32 36], align 4

define internal void @tile_inclusive_scan(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %live.mask = alloca <8 x i1>, align 1
  %runnable.mask = alloca <8 x i1>, align 1
  %ready.count = alloca i32, align 4
  %ready.mask = alloca [8 x <8 x i1>], align 1
  %ready.target = alloca [8 x i32], align 4
  %ready.token = alloca [8 x i32], align 4
  %current.mask = alloca <8 x i1>, align 1
  %current.token = alloca i32, align 4
  %frame.active = alloca i8, align 1
  %frame.static.id = alloca <8 x i32>, align 32
  %frame.parent.token = alloca <8 x i32>, align 32
  %frame.expected = alloca [8 x <8 x i1>], align 1
  %frame.arrived = alloca [8 x <8 x i1>], align 1
  store <8 x i1> zeroinitializer, ptr %live.mask, align 1
  store <8 x i1> zeroinitializer, ptr %runnable.mask, align 1
  store i32 0, ptr %ready.count, align 4
  store [8 x <8 x i1>] zeroinitializer, ptr %ready.mask, align 1
  store [8 x i32] zeroinitializer, ptr %ready.target, align 4
  store [8 x i32] zeroinitializer, ptr %ready.token, align 4
  store <8 x i1> zeroinitializer, ptr %current.mask, align 1
  store i32 0, ptr %current.token, align 4
  store i8 0, ptr %frame.active, align 1
  store <8 x i32> zeroinitializer, ptr %frame.static.id, align 32
  store <8 x i32> zeroinitializer, ptr %frame.parent.token, align 32
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.expected, align 1
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.arrived, align 1
  %tile_snapshot.local = alloca [128 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [4096 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local4 = alloca [4096 x i8], align 4
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local7 = alloca [4096 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local10 = alloca [4096 x i8], align 4
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %8 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %9 = insertvalue { <8 x ptr>, <8 x i64> } %8, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local13 = alloca [4096 x i8], align 4
  %.splatinsert14 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local13, i64 0
  %.splat15 = shufflevector <8 x ptr> %.splatinsert14, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat15, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local16 = alloca [4096 x i8], align 4
  %.splatinsert17 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local16, i64 0
  %.splat18 = shufflevector <8 x ptr> %.splatinsert17, <8 x ptr> poison, <8 x i32> zeroinitializer
  %12 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat18, 0
  %13 = insertvalue { <8 x ptr>, <8 x i64> } %12, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill19 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill19, align 4
  %.slot = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot, align 64
  %.slot20 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.slot20, align 32
  %.slot21 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.slot21, align 32
  %.slot22 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.slot22, align 32
  %.slot23 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.slot23, align 32
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.spill24 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill24, align 64
  %tile_snapshot.spill25 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill25, align 64
  %.slot26 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot26, align 64
  %.spill27 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill27, align 64
  %.slot28 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot28, align 32
  %tile_snapshot.spill29 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill29, align 64
  %.slot30 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot30, align 64
  %.spill31 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill31, align 32
  %.spill32 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill32, align 1
  %.spill33 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill33, align 64
  %.slot34 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot34, align 32
  %tile_snapshot.spill35 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill35, align 64
  %.slot36 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot36, align 64
  %.spill37 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill37, align 32
  %.spill38 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill38, align 1
  %.spill39 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill39, align 64
  %.slot40 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot40, align 32
  %tile_snapshot.spill41 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill41, align 64
  %.slot42 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot42, align 64
  %.spill43 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill43, align 32
  %.spill44 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill44, align 1
  %.spill45 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill45, align 64
  %.slot46 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot46, align 32
  %tile_snapshot.spill47 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill47, align 64
  %.slot48 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot48, align 64
  %.spill49 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill49, align 32
  %.spill50 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill50, align 1
  %.spill51 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill51, align 64
  %.slot52 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot52, align 32
  %tile_snapshot.spill53 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill53, align 64
  %.slot54 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot54, align 64
  %.spill55 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill55, align 64
  %.spill56 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill56, align 32
  %.spill57 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill57, align 1
  %.spill58 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill58, align 64
  %.slot59 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot59, align 32
  %.slot60 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot60, align 64
  %.spill61 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill61, align 64
  %.spill62 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill62, align 32
  %14 = getelementptr i8, ptr %argument_buffer, i64 0
  %15 = load ptr, ptr %14, align 16
  %16 = getelementptr i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = insertvalue { ptr, i64 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i64 } %18, i64 %17, 1
  %20 = getelementptr i8, ptr %argument_buffer, i64 16
  %21 = load ptr, ptr %20, align 16
  %22 = getelementptr i8, ptr %20, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = insertvalue { ptr, i64 } poison, ptr %21, 0
  %25 = insertvalue { ptr, i64 } %24, i64 %23, 1
  %26 = load i32, ptr %launch_config, align 4
  %27 = getelementptr i8, ptr %launch_config, i64 12
  %28 = load i32, ptr %27, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 4
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 16
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 8
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 20
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 36
  %38 = load i32, ptr %37, align 4
  %.splatinsert63 = insertelement <8 x i32> poison, i32 %38, i64 0
  %.splat64 = shufflevector <8 x i32> %.splatinsert63, <8 x i32> poison, <8 x i32> zeroinitializer
  %39 = add <8 x i32> %.splat64, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %40 = mul i32 %26, 32
  %.splatinsert65 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat66 = shufflevector <8 x i32> %.splatinsert65, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat66, %39
  %42 = mul i32 %30, 1
  %.splatinsert67 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat68 = shufflevector <8 x i32> %.splatinsert67, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat68, zeroinitializer
  %44 = mul i32 %34, 1
  %.splatinsert69 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat70 = shufflevector <8 x i32> %.splatinsert69, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat70, zeroinitializer
  %46 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %41, 0
  %47 = insertvalue [3 x <8 x i32>] %46, <8 x i32> %43, 1
  %48 = insertvalue [3 x <8 x i32>] %47, <8 x i32> %45, 2
  %.splatinsert71 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat72 = shufflevector <8 x i32> %.splatinsert71, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat72
  store <8 x i1> %49, ptr %live.mask, align 1
  %50 = load i32, ptr %current.token, align 4
  %51 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %49)
  %52 = load i32, ptr %ready.count, align 4
  %53 = icmp uge i32 %52, 8
  %54 = and i1 %51, %53
  br i1 %54, label %ready.overflow.trap, label %ready.overflow.resume

ready.overflow.trap:                              ; preds = %prologue
  call void @llvm.trap()
  unreachable

ready.overflow.resume:                            ; preds = %prologue
  %55 = select i1 %51, i32 %52, i32 0
  %56 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %55
  %57 = load <8 x i1>, ptr %56, align 1
  %58 = select i1 %51, <8 x i1> %49, <8 x i1> %57
  store <8 x i1> %58, ptr %56, align 1
  %59 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %55
  %60 = load i32, ptr %59, align 4
  %61 = select i1 %51, i32 0, i32 %60
  store i32 %61, ptr %59, align 4
  %62 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %55
  %63 = load i32, ptr %62, align 4
  %64 = select i1 %51, i32 %50, i32 %63
  store i32 %64, ptr %62, align 4
  %65 = add i32 %52, 1
  %66 = select i1 %51, i32 %65, i32 %52
  store i32 %66, ptr %ready.count, align 4
  %67 = load <8 x i1>, ptr %runnable.mask, align 1
  %68 = or <8 x i1> %67, %49
  store <8 x i1> %68, ptr %runnable.mask, align 1
  br label %scheduler.loop

scheduler.loop:                                   ; preds = %return.frame.cleanup.done, %convergence.cascade.exit539, %convergence.target.37.ready, %convergence.cascade.exit510, %convergence.target.36.ready, %convergence.cascade.exit492, %schedule.35, %varying.coherent.false488, %varying.coherent.true487, %varying.coherent.false474, %varying.coherent.true473, %convergence.target.32.ready, %convergence.cascade.exit450, %convergence.target.31.ready, %convergence.cascade.exit422, %schedule.30, %varying.coherent.false418, %varying.coherent.true417, %varying.coherent.false407, %varying.coherent.true406, %convergence.target.27.ready, %convergence.cascade.exit383, %convergence.target.26.ready, %convergence.cascade.exit357, %schedule.25, %varying.coherent.false353, %varying.coherent.true352, %varying.coherent.false342, %varying.coherent.true341, %convergence.target.22.ready, %convergence.cascade.exit318, %convergence.target.21.ready, %convergence.cascade.exit292, %schedule.20, %varying.coherent.false288, %varying.coherent.true287, %varying.coherent.false277, %varying.coherent.true276, %convergence.target.17.ready, %convergence.cascade.exit253, %convergence.target.16.ready, %convergence.cascade.exit227, %schedule.15, %varying.coherent.false223, %varying.coherent.true222, %varying.coherent.false212, %varying.coherent.true211, %convergence.target.12.ready, %convergence.cascade.exit188, %convergence.target.11.ready, %convergence.cascade.exit162, %schedule.10, %varying.coherent.false158, %varying.coherent.true157, %varying.coherent.false147, %varying.coherent.true146, %convergence.target.7.ready, %convergence.cascade.exit123, %convergence.target.6.ready, %convergence.cascade.exit, %schedule.5, %varying.coherent.false108, %varying.coherent.true107, %varying.coherent.false94, %varying.coherent.true93, %schedule.2, %varying.coherent.false, %varying.coherent.true, %schedule.0, %ready.overflow.resume
  %69 = load i32, ptr %ready.count, align 4
  %70 = icmp ne i32 %69, 0
  br i1 %70, label %scheduler.dispatch, label %scheduler.done

scheduler.dispatch:                               ; preds = %scheduler.loop
  %71 = sub i32 %69, 1
  store i32 %71, ptr %ready.count, align 4
  %72 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %71
  %73 = load <8 x i1>, ptr %72, align 1
  store <8 x i1> %73, ptr %current.mask, align 1
  %74 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %71
  %75 = load i32, ptr %74, align 4
  %76 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %71
  %77 = load i32, ptr %76, align 4
  store i32 %77, ptr %current.token, align 4
  %78 = load <8 x i1>, ptr %runnable.mask, align 1
  %79 = xor <8 x i1> %73, splat (i1 true)
  %80 = and <8 x i1> %78, %79
  store <8 x i1> %80, ptr %runnable.mask, align 1
  br label %scheduler.dispatch.route

scheduler.dispatch.route:                         ; preds = %ready.overflow.resume486, %ready.overflow.resume472, %ready.overflow.resume416, %ready.overflow.resume405, %ready.overflow.resume351, %ready.overflow.resume340, %ready.overflow.resume286, %ready.overflow.resume275, %ready.overflow.resume221, %ready.overflow.resume210, %ready.overflow.resume156, %ready.overflow.resume145, %ready.overflow.resume106, %ready.overflow.resume92, %ready.overflow.resume74, %scheduler.dispatch
  %scheduler.dispatch.pc = phi i32 [ %75, %scheduler.dispatch ], [ 38, %ready.overflow.resume74 ], [ 7, %ready.overflow.resume92 ], [ 6, %ready.overflow.resume106 ], [ 12, %ready.overflow.resume145 ], [ 11, %ready.overflow.resume156 ], [ 17, %ready.overflow.resume210 ], [ 16, %ready.overflow.resume221 ], [ 22, %ready.overflow.resume275 ], [ 21, %ready.overflow.resume286 ], [ 27, %ready.overflow.resume340 ], [ 26, %ready.overflow.resume351 ], [ 32, %ready.overflow.resume405 ], [ 31, %ready.overflow.resume416 ], [ 37, %ready.overflow.resume472 ], [ 36, %ready.overflow.resume486 ]
  switch i32 %scheduler.dispatch.pc, label %scheduler.invalid [
    i32 0, label %schedule.0
    i32 1, label %schedule.1
    i32 2, label %schedule.2
    i32 3, label %schedule.3
    i32 4, label %schedule.4
    i32 5, label %schedule.5
    i32 6, label %schedule.6
    i32 7, label %schedule.7
    i32 8, label %schedule.8
    i32 9, label %schedule.9
    i32 10, label %schedule.10
    i32 11, label %schedule.11
    i32 12, label %schedule.12
    i32 13, label %schedule.13
    i32 14, label %schedule.14
    i32 15, label %schedule.15
    i32 16, label %schedule.16
    i32 17, label %schedule.17
    i32 18, label %schedule.18
    i32 19, label %schedule.19
    i32 20, label %schedule.20
    i32 21, label %schedule.21
    i32 22, label %schedule.22
    i32 23, label %schedule.23
    i32 24, label %schedule.24
    i32 25, label %schedule.25
    i32 26, label %schedule.26
    i32 27, label %schedule.27
    i32 28, label %schedule.28
    i32 29, label %schedule.29
    i32 30, label %schedule.30
    i32 31, label %schedule.31
    i32 32, label %schedule.32
    i32 33, label %schedule.33
    i32 34, label %schedule.34
    i32 35, label %schedule.35
    i32 36, label %schedule.36
    i32 37, label %schedule.37
    i32 38, label %schedule.38
  ]

scheduler.done:                                   ; preds = %scheduler.loop
  %81 = load <8 x i1>, ptr %live.mask, align 1
  %82 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %81)
  br i1 %82, label %scheduler.stalled, label %scheduler.exit

scheduler.exit:                                   ; preds = %scheduler.done
  ret void

scheduler.stalled:                                ; preds = %scheduler.done
  call void @llvm.trap()
  unreachable

scheduler.invalid:                                ; preds = %scheduler.dispatch.route
  call void @llvm.trap()
  unreachable

schedule.0:                                       ; preds = %scheduler.dispatch.route
  %83 = load <8 x i1>, ptr %current.mask, align 1
  %84 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %83)
  %85 = bitcast <8 x i1> %83 to i8
  %86 = call i8 @llvm.cttz.i8(i8 %85, i1 false)
  %87 = zext i8 %86 to i32
  %88 = select i1 %84, i32 %87, i32 0
  %89 = extractvalue [3 x <8 x i32>] %48, 0
  %90 = zext <8 x i32> %89 to <8 x i64>
  %91 = select <8 x i1> %83, <8 x i64> %90, <8 x i64> zeroinitializer
  %92 = select <8 x i1> %83, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %93 = sdiv <8 x i64> %91, %92
  %94 = mul <8 x i64> %93, splat (i64 4)
  %95 = load volatile <8 x i64>, ptr %.spill, align 64
  %96 = select <8 x i1> %83, <8 x i64> %94, <8 x i64> %95
  store volatile <8 x i64> %96, ptr %.spill, align 64
  store float 0.000000e+00, ptr %.spill19, align 4
  %97 = load <8 x i64>, ptr %.slot, align 64
  %98 = select <8 x i1> %83, <8 x i64> zeroinitializer, <8 x i64> %97
  store <8 x i64> %98, ptr %.slot, align 64
  %99 = load volatile <8 x float>, ptr %.slot20, align 32
  %100 = select <8 x i1> %83, <8 x float> zeroinitializer, <8 x float> %99
  store volatile <8 x float> %100, ptr %.slot20, align 32
  %101 = load volatile <8 x float>, ptr %.slot21, align 32
  %102 = select <8 x i1> %83, <8 x float> zeroinitializer, <8 x float> %101
  store volatile <8 x float> %102, ptr %.slot21, align 32
  %103 = load volatile <8 x float>, ptr %.slot22, align 32
  %104 = select <8 x i1> %83, <8 x float> zeroinitializer, <8 x float> %103
  store volatile <8 x float> %104, ptr %.slot22, align 32
  %105 = load volatile <8 x float>, ptr %.slot23, align 32
  %106 = select <8 x i1> %83, <8 x float> zeroinitializer, <8 x float> %105
  store volatile <8 x float> %106, ptr %.slot23, align 32
  store <8 x i1> %83, ptr %current.mask, align 1
  %107 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %83)
  br i1 %107, label %schedule.1, label %scheduler.loop

schedule.1:                                       ; preds = %convergence.target.37.ready, %schedule.0, %scheduler.dispatch.route
  %108 = load <8 x i1>, ptr %current.mask, align 1
  %109 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %108)
  %110 = bitcast <8 x i1> %108 to i8
  %111 = call i8 @llvm.cttz.i8(i8 %110, i1 false)
  %112 = zext i8 %111 to i32
  %113 = select i1 %109, i32 %112, i32 0
  %.state = load <8 x i64>, ptr %.slot, align 64
  %114 = icmp slt <8 x i64> %.state, splat (i64 3)
  %115 = and <8 x i1> %108, %114
  %116 = xor <8 x i1> %114, splat (i1 true)
  %117 = and <8 x i1> %108, %116
  %118 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %115)
  %119 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %117)
  %120 = and i1 %118, %119
  br i1 %120, label %varying.divergent, label %varying.coherent

schedule.2:                                       ; preds = %varying.coherent.true, %scheduler.dispatch.route
  %121 = load <8 x i1>, ptr %current.mask, align 1
  %122 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %121)
  %123 = bitcast <8 x i1> %121 to i8
  %124 = call i8 @llvm.cttz.i8(i8 %123, i1 false)
  %125 = zext i8 %124 to i32
  %126 = select i1 %122, i32 %125, i32 0
  %127 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %127, 0
  %130 = select <8 x i1> %121, <8 x ptr> %128, <8 x ptr> %129
  %131 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %132 = extractvalue { <8 x ptr>, <8 x i64> } %127, 1
  %133 = select <8 x i1> %121, <8 x i64> %131, <8 x i64> %132
  %134 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %130, 0
  %135 = insertvalue { <8 x ptr>, <8 x i64> } %134, <8 x i64> %133, 1
  store volatile { <8 x ptr>, <8 x i64> } %135, ptr %tile_snapshot.spill, align 64
  %136 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %138 = add <8 x i64> %137, zeroinitializer
  %139 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %136, 0
  %140 = insertvalue { <8 x ptr>, <8 x i64> } %139, <8 x i64> %138, 1
  %.state75 = load volatile <8 x float>, ptr %.slot20, align 32
  %141 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %140, 1
  %143 = extractelement <8 x ptr> %141, i32 0
  %144 = extractelement <8 x i64> %142, i32 %126
  %145 = zext i32 %126 to i64
  %146 = mul i64 %145, 4
  %147 = sub i64 %144, %146
  %148 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %121)
  %149 = select i1 %148, i64 %147, i64 0
  %private.contiguous.address = getelementptr i8, ptr %143, i64 %149
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %150 = select <8 x i1> %121, <8 x float> %.state75, <8 x float> %private.contiguous.preserve
  store <8 x float> %150, ptr %private.contiguous.address, align 4
  %151 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %152 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %153 = add <8 x i64> %152, splat (i64 32)
  %154 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %151, 0
  %155 = insertvalue { <8 x ptr>, <8 x i64> } %154, <8 x i64> %153, 1
  %.state76 = load volatile <8 x float>, ptr %.slot21, align 32
  %156 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %157 = extractvalue { <8 x ptr>, <8 x i64> } %155, 1
  %158 = extractelement <8 x ptr> %156, i32 0
  %159 = extractelement <8 x i64> %157, i32 %126
  %160 = zext i32 %126 to i64
  %161 = mul i64 %160, 4
  %162 = sub i64 %159, %161
  %163 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %121)
  %164 = select i1 %163, i64 %162, i64 0
  %private.contiguous.address77 = getelementptr i8, ptr %158, i64 %164
  %private.contiguous.preserve78 = load <8 x float>, ptr %private.contiguous.address77, align 4
  %165 = select <8 x i1> %121, <8 x float> %.state76, <8 x float> %private.contiguous.preserve78
  store <8 x float> %165, ptr %private.contiguous.address77, align 4
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %168 = add <8 x i64> %167, splat (i64 64)
  %169 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %166, 0
  %170 = insertvalue { <8 x ptr>, <8 x i64> } %169, <8 x i64> %168, 1
  %.state79 = load volatile <8 x float>, ptr %.slot22, align 32
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %170, 1
  %173 = extractelement <8 x ptr> %171, i32 0
  %174 = extractelement <8 x i64> %172, i32 %126
  %175 = zext i32 %126 to i64
  %176 = mul i64 %175, 4
  %177 = sub i64 %174, %176
  %178 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %121)
  %179 = select i1 %178, i64 %177, i64 0
  %private.contiguous.address80 = getelementptr i8, ptr %173, i64 %179
  %private.contiguous.preserve81 = load <8 x float>, ptr %private.contiguous.address80, align 4
  %180 = select <8 x i1> %121, <8 x float> %.state79, <8 x float> %private.contiguous.preserve81
  store <8 x float> %180, ptr %private.contiguous.address80, align 4
  %181 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %182 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %183 = add <8 x i64> %182, splat (i64 96)
  %184 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %181, 0
  %185 = insertvalue { <8 x ptr>, <8 x i64> } %184, <8 x i64> %183, 1
  %.state82 = load volatile <8 x float>, ptr %.slot23, align 32
  %186 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %185, 1
  %188 = extractelement <8 x ptr> %186, i32 0
  %189 = extractelement <8 x i64> %187, i32 %126
  %190 = zext i32 %126 to i64
  %191 = mul i64 %190, 4
  %192 = sub i64 %189, %191
  %193 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %121)
  %194 = select i1 %193, i64 %192, i64 0
  %private.contiguous.address83 = getelementptr i8, ptr %188, i64 %194
  %private.contiguous.preserve84 = load <8 x float>, ptr %private.contiguous.address83, align 4
  %195 = select <8 x i1> %121, <8 x float> %.state82, <8 x float> %private.contiguous.preserve84
  store <8 x float> %195, ptr %private.contiguous.address83, align 4
  %.state85 = load <8 x i64>, ptr %.slot, align 64
  %196 = select <8 x i1> %121, <8 x i64> %.state85, <8 x i64> zeroinitializer
  %197 = select <8 x i1> %121, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %198 = sdiv <8 x i64> %196, %197
  %199 = mul <8 x i64> %198, splat (i64 32)
  %200 = load volatile <8 x i64>, ptr %.spill24, align 64
  %201 = select <8 x i1> %121, <8 x i64> %199, <8 x i64> %200
  store volatile <8 x i64> %201, ptr %.spill24, align 64
  %202 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %203 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %204 = extractvalue { <8 x ptr>, <8 x i64> } %202, 0
  %205 = select <8 x i1> %121, <8 x ptr> %203, <8 x ptr> %204
  %206 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %207 = extractvalue { <8 x ptr>, <8 x i64> } %202, 1
  %208 = select <8 x i1> %121, <8 x i64> %206, <8 x i64> %207
  %209 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %205, 0
  %210 = insertvalue { <8 x ptr>, <8 x i64> } %209, <8 x i64> %208, 1
  store volatile { <8 x ptr>, <8 x i64> } %210, ptr %tile_snapshot.spill25, align 64
  %211 = load <8 x i64>, ptr %.slot26, align 64
  %212 = select <8 x i1> %121, <8 x i64> zeroinitializer, <8 x i64> %211
  store <8 x i64> %212, ptr %.slot26, align 64
  store <8 x i1> %121, ptr %current.mask, align 1
  %213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %121)
  br i1 %213, label %schedule.3, label %scheduler.loop

schedule.3:                                       ; preds = %convergence.target.6.ready, %schedule.2, %scheduler.dispatch.route
  %214 = load <8 x i1>, ptr %current.mask, align 1
  %215 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %214)
  %216 = bitcast <8 x i1> %214 to i8
  %217 = call i8 @llvm.cttz.i8(i8 %216, i1 false)
  %218 = zext i8 %217 to i32
  %219 = select i1 %215, i32 %218, i32 0
  %.state86 = load <8 x i64>, ptr %.slot26, align 64
  %220 = icmp slt <8 x i64> %.state86, splat (i64 128)
  %221 = and <8 x i1> %214, %220
  %222 = xor <8 x i1> %220, splat (i1 true)
  %223 = and <8 x i1> %214, %222
  %224 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %221)
  %225 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %223)
  %226 = and i1 %224, %225
  br i1 %226, label %varying.divergent87, label %varying.coherent88

schedule.4:                                       ; preds = %varying.coherent.true93, %scheduler.dispatch.route
  %227 = load <8 x i1>, ptr %current.mask, align 1
  %228 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %227)
  %229 = bitcast <8 x i1> %227 to i8
  %230 = call i8 @llvm.cttz.i8(i8 %229, i1 false)
  %231 = zext i8 %230 to i32
  %232 = select i1 %228, i32 %231, i32 0
  %.state95 = load <8 x i64>, ptr %.slot26, align 64
  %233 = select <8 x i1> %227, <8 x i64> %.state95, <8 x i64> zeroinitializer
  %234 = select <8 x i1> %227, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %235 = srem <8 x i64> %233, %234
  %.state96 = load <8 x i64>, ptr %.slot26, align 64
  %236 = select <8 x i1> %227, <8 x i64> %.state96, <8 x i64> zeroinitializer
  %237 = select <8 x i1> %227, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %238 = sdiv <8 x i64> %236, %237
  %.spill.load = load volatile <8 x i64>, ptr %.spill, align 64
  %239 = add <8 x i64> %.spill.load, %238
  %240 = add <8 x i64> zeroinitializer, %239
  %241 = icmp sge <8 x i64> %239, zeroinitializer
  %242 = and <8 x i1> splat (i1 true), %241
  %243 = icmp slt <8 x i64> %239, splat (i64 17)
  %244 = and <8 x i1> %242, %243
  %.spill.load97 = load volatile <8 x i64>, ptr %.spill24, align 64
  %245 = add <8 x i64> %.spill.load97, %235
  %246 = mul <8 x i64> %240, splat (i64 65)
  %247 = add <8 x i64> %246, %245
  %248 = icmp sge <8 x i64> %245, zeroinitializer
  %249 = and <8 x i1> %244, %248
  %250 = icmp slt <8 x i64> %245, splat (i64 65)
  %251 = and <8 x i1> %249, %250
  %252 = load volatile <8 x i64>, ptr %.spill27, align 64
  %253 = select <8 x i1> %227, <8 x i64> %247, <8 x i64> %252
  store volatile <8 x i64> %253, ptr %.spill27, align 64
  %254 = and <8 x i1> %227, %251
  %255 = xor <8 x i1> %251, splat (i1 true)
  %256 = and <8 x i1> %227, %255
  %257 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %254)
  %258 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %256)
  %259 = and i1 %257, %258
  br i1 %259, label %varying.divergent98, label %varying.coherent99

schedule.5:                                       ; preds = %varying.coherent.true107, %scheduler.dispatch.route
  %260 = load <8 x i1>, ptr %current.mask, align 1
  %261 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %260)
  %262 = bitcast <8 x i1> %260 to i8
  %263 = call i8 @llvm.cttz.i8(i8 %262, i1 false)
  %264 = zext i8 %263 to i32
  %265 = select i1 %261, i32 %264, i32 0
  %.spill.load112 = load volatile <8 x i64>, ptr %.spill27, align 64
  %266 = extractvalue { ptr, i64 } %19, 0
  %267 = mul <8 x i64> %.spill.load112, splat (i64 4)
  %268 = getelementptr i8, ptr %266, <8 x i64> %267
  %269 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %268, i32 1, <8 x i1> %260, <8 x float> zeroinitializer)
  %270 = load <8 x float>, ptr %.slot28, align 32
  %271 = select <8 x i1> %260, <8 x float> %269, <8 x float> %270
  store <8 x float> %271, ptr %.slot28, align 32
  store <8 x i1> %260, ptr %current.mask, align 1
  %272 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %260)
  br i1 %272, label %schedule.6, label %scheduler.loop

schedule.6:                                       ; preds = %schedule.5, %varying.coherent.false108, %scheduler.dispatch.route
  %273 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token = load i32, ptr %current.token, align 4
  %convergence.token.present = icmp ne i32 %convergence.current.token, 0
  br i1 %convergence.token.present, label %convergence.cascade, label %convergence.cascade.exit

schedule.7:                                       ; preds = %varying.coherent.false94, %scheduler.dispatch.route
  %274 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token124 = load i32, ptr %current.token, align 4
  %convergence.token.present125 = icmp ne i32 %convergence.current.token124, 0
  br i1 %convergence.token.present125, label %convergence.cascade122, label %convergence.cascade.exit123

schedule.8:                                       ; preds = %convergence.target.11.ready, %convergence.target.7.ready, %scheduler.dispatch.route
  %275 = load <8 x i1>, ptr %current.mask, align 1
  %276 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %275)
  %277 = bitcast <8 x i1> %275 to i8
  %278 = call i8 @llvm.cttz.i8(i8 %277, i1 false)
  %279 = zext i8 %278 to i32
  %280 = select i1 %276, i32 %279, i32 0
  %.state139 = load <8 x i64>, ptr %.slot30, align 64
  %281 = icmp slt <8 x i64> %.state139, splat (i64 128)
  %282 = and <8 x i1> %275, %281
  %283 = xor <8 x i1> %281, splat (i1 true)
  %284 = and <8 x i1> %275, %283
  %285 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %282)
  %286 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %284)
  %287 = and i1 %285, %286
  br i1 %287, label %varying.divergent140, label %varying.coherent141

schedule.9:                                       ; preds = %varying.coherent.true146, %scheduler.dispatch.route
  %288 = load <8 x i1>, ptr %current.mask, align 1
  %289 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %288)
  %290 = bitcast <8 x i1> %288 to i8
  %291 = call i8 @llvm.cttz.i8(i8 %290, i1 false)
  %292 = zext i8 %291 to i32
  %293 = select i1 %289, i32 %292, i32 0
  %.state148 = load <8 x i64>, ptr %.slot30, align 64
  %294 = select <8 x i1> %288, <8 x i64> %.state148, <8 x i64> zeroinitializer
  %295 = select <8 x i1> %288, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %296 = srem <8 x i64> %294, %295
  %.state149 = load <8 x i64>, ptr %.slot30, align 64
  %297 = select <8 x i1> %288, <8 x i64> %.state149, <8 x i64> zeroinitializer
  %298 = select <8 x i1> %288, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %299 = sdiv <8 x i64> %297, %298
  %300 = add <8 x i64> zeroinitializer, %299
  %301 = mul <8 x i64> %300, splat (i64 32)
  %302 = add <8 x i64> %301, %296
  %tile_snapshot.spill.load150 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %303 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load150, 0
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load150, 1
  %305 = mul <8 x i64> %302, splat (i64 32)
  %306 = add <8 x i64> %304, %305
  %307 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %303, 0
  %308 = insertvalue { <8 x ptr>, <8 x i64> } %307, <8 x i64> %306, 1
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %308, 0
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %308, 1
  %311 = getelementptr i8, <8 x ptr> %309, <8 x i64> %310
  %312 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %311, i32 1, <8 x i1> %288, <8 x float> zeroinitializer)
  %313 = load volatile <8 x float>, ptr %.spill31, align 32
  %314 = select <8 x i1> %288, <8 x float> %312, <8 x float> %313
  store volatile <8 x float> %314, ptr %.spill31, align 32
  %315 = select <8 x i1> %288, <8 x i64> %302, <8 x i64> zeroinitializer
  %316 = select <8 x i1> %288, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %317 = srem <8 x i64> %315, %316
  %318 = select <8 x i1> %288, <8 x i64> %302, <8 x i64> zeroinitializer
  %319 = select <8 x i1> %288, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %320 = sdiv <8 x i64> %318, %319
  %321 = add <8 x i64> zeroinitializer, %317
  %322 = add <8 x i64> zeroinitializer, %321
  %323 = sub <8 x i64> %322, splat (i64 1)
  %324 = icmp sge <8 x i64> %323, zeroinitializer
  %325 = icmp slt <8 x i64> %323, splat (i64 32)
  %326 = and <8 x i1> %324, %325
  %327 = load volatile <8 x i1>, ptr %.spill32, align 1
  %328 = select <8 x i1> %288, <8 x i1> %326, <8 x i1> %327
  store volatile <8 x i1> %328, ptr %.spill32, align 1
  %329 = add <8 x i64> zeroinitializer, %320
  %330 = mul <8 x i64> %329, splat (i64 32)
  %331 = add <8 x i64> %330, %323
  %332 = load volatile <8 x i64>, ptr %.spill33, align 64
  %333 = select <8 x i1> %288, <8 x i64> %331, <8 x i64> %332
  store volatile <8 x i64> %333, ptr %.spill33, align 64
  %334 = icmp sge <8 x i64> %331, zeroinitializer
  %335 = icmp slt <8 x i64> %331, splat (i64 128)
  %336 = and <8 x i1> %334, %335
  %337 = and <8 x i1> %288, %336
  %338 = xor <8 x i1> %336, splat (i1 true)
  %339 = and <8 x i1> %288, %338
  %340 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %337)
  %341 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %339)
  %342 = and i1 %340, %341
  br i1 %342, label %varying.divergent151, label %varying.coherent152

schedule.10:                                      ; preds = %varying.coherent.true157, %scheduler.dispatch.route
  %343 = load <8 x i1>, ptr %current.mask, align 1
  %344 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %343)
  %345 = bitcast <8 x i1> %343 to i8
  %346 = call i8 @llvm.cttz.i8(i8 %345, i1 false)
  %347 = zext i8 %346 to i32
  %348 = select i1 %344, i32 %347, i32 0
  %tile_snapshot.spill.load159 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %349 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load159, 0
  %350 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load159, 1
  %.spill.load160 = load volatile <8 x i64>, ptr %.spill33, align 64
  %351 = mul <8 x i64> %.spill.load160, splat (i64 32)
  %352 = add <8 x i64> %350, %351
  %353 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %349, 0
  %354 = insertvalue { <8 x ptr>, <8 x i64> } %353, <8 x i64> %352, 1
  %355 = extractvalue { <8 x ptr>, <8 x i64> } %354, 0
  %356 = extractvalue { <8 x ptr>, <8 x i64> } %354, 1
  %357 = getelementptr i8, <8 x ptr> %355, <8 x i64> %356
  %358 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %357, i32 1, <8 x i1> %343, <8 x float> zeroinitializer)
  %359 = load <8 x float>, ptr %.slot34, align 32
  %360 = select <8 x i1> %343, <8 x float> %358, <8 x float> %359
  store <8 x float> %360, ptr %.slot34, align 32
  store <8 x i1> %343, ptr %current.mask, align 1
  %361 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %343)
  br i1 %361, label %schedule.11, label %scheduler.loop

schedule.11:                                      ; preds = %schedule.10, %varying.coherent.false158, %scheduler.dispatch.route
  %362 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token163 = load i32, ptr %current.token, align 4
  %convergence.token.present164 = icmp ne i32 %convergence.current.token163, 0
  br i1 %convergence.token.present164, label %convergence.cascade161, label %convergence.cascade.exit162

schedule.12:                                      ; preds = %varying.coherent.false147, %scheduler.dispatch.route
  %363 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token189 = load i32, ptr %current.token, align 4
  %convergence.token.present190 = icmp ne i32 %convergence.current.token189, 0
  br i1 %convergence.token.present190, label %convergence.cascade187, label %convergence.cascade.exit188

schedule.13:                                      ; preds = %convergence.target.16.ready, %convergence.target.12.ready, %scheduler.dispatch.route
  %364 = load <8 x i1>, ptr %current.mask, align 1
  %365 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %364)
  %366 = bitcast <8 x i1> %364 to i8
  %367 = call i8 @llvm.cttz.i8(i8 %366, i1 false)
  %368 = zext i8 %367 to i32
  %369 = select i1 %365, i32 %368, i32 0
  %.state204 = load <8 x i64>, ptr %.slot36, align 64
  %370 = icmp slt <8 x i64> %.state204, splat (i64 128)
  %371 = and <8 x i1> %364, %370
  %372 = xor <8 x i1> %370, splat (i1 true)
  %373 = and <8 x i1> %364, %372
  %374 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %371)
  %375 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %373)
  %376 = and i1 %374, %375
  br i1 %376, label %varying.divergent205, label %varying.coherent206

schedule.14:                                      ; preds = %varying.coherent.true211, %scheduler.dispatch.route
  %377 = load <8 x i1>, ptr %current.mask, align 1
  %378 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %377)
  %379 = bitcast <8 x i1> %377 to i8
  %380 = call i8 @llvm.cttz.i8(i8 %379, i1 false)
  %381 = zext i8 %380 to i32
  %382 = select i1 %378, i32 %381, i32 0
  %.state213 = load <8 x i64>, ptr %.slot36, align 64
  %383 = select <8 x i1> %377, <8 x i64> %.state213, <8 x i64> zeroinitializer
  %384 = select <8 x i1> %377, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %385 = srem <8 x i64> %383, %384
  %.state214 = load <8 x i64>, ptr %.slot36, align 64
  %386 = select <8 x i1> %377, <8 x i64> %.state214, <8 x i64> zeroinitializer
  %387 = select <8 x i1> %377, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %388 = sdiv <8 x i64> %386, %387
  %389 = add <8 x i64> zeroinitializer, %388
  %390 = mul <8 x i64> %389, splat (i64 32)
  %391 = add <8 x i64> %390, %385
  %tile_snapshot.spill.load215 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %392 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load215, 0
  %393 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load215, 1
  %394 = mul <8 x i64> %391, splat (i64 32)
  %395 = add <8 x i64> %393, %394
  %396 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %392, 0
  %397 = insertvalue { <8 x ptr>, <8 x i64> } %396, <8 x i64> %395, 1
  %398 = extractvalue { <8 x ptr>, <8 x i64> } %397, 0
  %399 = extractvalue { <8 x ptr>, <8 x i64> } %397, 1
  %400 = getelementptr i8, <8 x ptr> %398, <8 x i64> %399
  %401 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %400, i32 1, <8 x i1> %377, <8 x float> zeroinitializer)
  %402 = load volatile <8 x float>, ptr %.spill37, align 32
  %403 = select <8 x i1> %377, <8 x float> %401, <8 x float> %402
  store volatile <8 x float> %403, ptr %.spill37, align 32
  %404 = select <8 x i1> %377, <8 x i64> %391, <8 x i64> zeroinitializer
  %405 = select <8 x i1> %377, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %406 = srem <8 x i64> %404, %405
  %407 = select <8 x i1> %377, <8 x i64> %391, <8 x i64> zeroinitializer
  %408 = select <8 x i1> %377, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %409 = sdiv <8 x i64> %407, %408
  %410 = add <8 x i64> zeroinitializer, %406
  %411 = add <8 x i64> zeroinitializer, %410
  %412 = sub <8 x i64> %411, splat (i64 2)
  %413 = icmp sge <8 x i64> %412, zeroinitializer
  %414 = icmp slt <8 x i64> %412, splat (i64 32)
  %415 = and <8 x i1> %413, %414
  %416 = load volatile <8 x i1>, ptr %.spill38, align 1
  %417 = select <8 x i1> %377, <8 x i1> %415, <8 x i1> %416
  store volatile <8 x i1> %417, ptr %.spill38, align 1
  %418 = add <8 x i64> zeroinitializer, %409
  %419 = mul <8 x i64> %418, splat (i64 32)
  %420 = add <8 x i64> %419, %412
  %421 = load volatile <8 x i64>, ptr %.spill39, align 64
  %422 = select <8 x i1> %377, <8 x i64> %420, <8 x i64> %421
  store volatile <8 x i64> %422, ptr %.spill39, align 64
  %423 = icmp sge <8 x i64> %420, zeroinitializer
  %424 = icmp slt <8 x i64> %420, splat (i64 128)
  %425 = and <8 x i1> %423, %424
  %426 = and <8 x i1> %377, %425
  %427 = xor <8 x i1> %425, splat (i1 true)
  %428 = and <8 x i1> %377, %427
  %429 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %426)
  %430 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %428)
  %431 = and i1 %429, %430
  br i1 %431, label %varying.divergent216, label %varying.coherent217

schedule.15:                                      ; preds = %varying.coherent.true222, %scheduler.dispatch.route
  %432 = load <8 x i1>, ptr %current.mask, align 1
  %433 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %432)
  %434 = bitcast <8 x i1> %432 to i8
  %435 = call i8 @llvm.cttz.i8(i8 %434, i1 false)
  %436 = zext i8 %435 to i32
  %437 = select i1 %433, i32 %436, i32 0
  %tile_snapshot.spill.load224 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %438 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load224, 0
  %439 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load224, 1
  %.spill.load225 = load volatile <8 x i64>, ptr %.spill39, align 64
  %440 = mul <8 x i64> %.spill.load225, splat (i64 32)
  %441 = add <8 x i64> %439, %440
  %442 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %438, 0
  %443 = insertvalue { <8 x ptr>, <8 x i64> } %442, <8 x i64> %441, 1
  %444 = extractvalue { <8 x ptr>, <8 x i64> } %443, 0
  %445 = extractvalue { <8 x ptr>, <8 x i64> } %443, 1
  %446 = getelementptr i8, <8 x ptr> %444, <8 x i64> %445
  %447 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %446, i32 1, <8 x i1> %432, <8 x float> zeroinitializer)
  %448 = load <8 x float>, ptr %.slot40, align 32
  %449 = select <8 x i1> %432, <8 x float> %447, <8 x float> %448
  store <8 x float> %449, ptr %.slot40, align 32
  store <8 x i1> %432, ptr %current.mask, align 1
  %450 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %432)
  br i1 %450, label %schedule.16, label %scheduler.loop

schedule.16:                                      ; preds = %schedule.15, %varying.coherent.false223, %scheduler.dispatch.route
  %451 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token228 = load i32, ptr %current.token, align 4
  %convergence.token.present229 = icmp ne i32 %convergence.current.token228, 0
  br i1 %convergence.token.present229, label %convergence.cascade226, label %convergence.cascade.exit227

schedule.17:                                      ; preds = %varying.coherent.false212, %scheduler.dispatch.route
  %452 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token254 = load i32, ptr %current.token, align 4
  %convergence.token.present255 = icmp ne i32 %convergence.current.token254, 0
  br i1 %convergence.token.present255, label %convergence.cascade252, label %convergence.cascade.exit253

schedule.18:                                      ; preds = %convergence.target.21.ready, %convergence.target.17.ready, %scheduler.dispatch.route
  %453 = load <8 x i1>, ptr %current.mask, align 1
  %454 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %453)
  %455 = bitcast <8 x i1> %453 to i8
  %456 = call i8 @llvm.cttz.i8(i8 %455, i1 false)
  %457 = zext i8 %456 to i32
  %458 = select i1 %454, i32 %457, i32 0
  %.state269 = load <8 x i64>, ptr %.slot42, align 64
  %459 = icmp slt <8 x i64> %.state269, splat (i64 128)
  %460 = and <8 x i1> %453, %459
  %461 = xor <8 x i1> %459, splat (i1 true)
  %462 = and <8 x i1> %453, %461
  %463 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %460)
  %464 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %462)
  %465 = and i1 %463, %464
  br i1 %465, label %varying.divergent270, label %varying.coherent271

schedule.19:                                      ; preds = %varying.coherent.true276, %scheduler.dispatch.route
  %466 = load <8 x i1>, ptr %current.mask, align 1
  %467 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %466)
  %468 = bitcast <8 x i1> %466 to i8
  %469 = call i8 @llvm.cttz.i8(i8 %468, i1 false)
  %470 = zext i8 %469 to i32
  %471 = select i1 %467, i32 %470, i32 0
  %.state278 = load <8 x i64>, ptr %.slot42, align 64
  %472 = select <8 x i1> %466, <8 x i64> %.state278, <8 x i64> zeroinitializer
  %473 = select <8 x i1> %466, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %474 = srem <8 x i64> %472, %473
  %.state279 = load <8 x i64>, ptr %.slot42, align 64
  %475 = select <8 x i1> %466, <8 x i64> %.state279, <8 x i64> zeroinitializer
  %476 = select <8 x i1> %466, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %477 = sdiv <8 x i64> %475, %476
  %478 = add <8 x i64> zeroinitializer, %477
  %479 = mul <8 x i64> %478, splat (i64 32)
  %480 = add <8 x i64> %479, %474
  %tile_snapshot.spill.load280 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %481 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 0
  %482 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 1
  %483 = mul <8 x i64> %480, splat (i64 32)
  %484 = add <8 x i64> %482, %483
  %485 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %481, 0
  %486 = insertvalue { <8 x ptr>, <8 x i64> } %485, <8 x i64> %484, 1
  %487 = extractvalue { <8 x ptr>, <8 x i64> } %486, 0
  %488 = extractvalue { <8 x ptr>, <8 x i64> } %486, 1
  %489 = getelementptr i8, <8 x ptr> %487, <8 x i64> %488
  %490 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %489, i32 1, <8 x i1> %466, <8 x float> zeroinitializer)
  %491 = load volatile <8 x float>, ptr %.spill43, align 32
  %492 = select <8 x i1> %466, <8 x float> %490, <8 x float> %491
  store volatile <8 x float> %492, ptr %.spill43, align 32
  %493 = select <8 x i1> %466, <8 x i64> %480, <8 x i64> zeroinitializer
  %494 = select <8 x i1> %466, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %495 = srem <8 x i64> %493, %494
  %496 = select <8 x i1> %466, <8 x i64> %480, <8 x i64> zeroinitializer
  %497 = select <8 x i1> %466, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %498 = sdiv <8 x i64> %496, %497
  %499 = add <8 x i64> zeroinitializer, %495
  %500 = add <8 x i64> zeroinitializer, %499
  %501 = sub <8 x i64> %500, splat (i64 4)
  %502 = icmp sge <8 x i64> %501, zeroinitializer
  %503 = icmp slt <8 x i64> %501, splat (i64 32)
  %504 = and <8 x i1> %502, %503
  %505 = load volatile <8 x i1>, ptr %.spill44, align 1
  %506 = select <8 x i1> %466, <8 x i1> %504, <8 x i1> %505
  store volatile <8 x i1> %506, ptr %.spill44, align 1
  %507 = add <8 x i64> zeroinitializer, %498
  %508 = mul <8 x i64> %507, splat (i64 32)
  %509 = add <8 x i64> %508, %501
  %510 = load volatile <8 x i64>, ptr %.spill45, align 64
  %511 = select <8 x i1> %466, <8 x i64> %509, <8 x i64> %510
  store volatile <8 x i64> %511, ptr %.spill45, align 64
  %512 = icmp sge <8 x i64> %509, zeroinitializer
  %513 = icmp slt <8 x i64> %509, splat (i64 128)
  %514 = and <8 x i1> %512, %513
  %515 = and <8 x i1> %466, %514
  %516 = xor <8 x i1> %514, splat (i1 true)
  %517 = and <8 x i1> %466, %516
  %518 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %515)
  %519 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %517)
  %520 = and i1 %518, %519
  br i1 %520, label %varying.divergent281, label %varying.coherent282

schedule.20:                                      ; preds = %varying.coherent.true287, %scheduler.dispatch.route
  %521 = load <8 x i1>, ptr %current.mask, align 1
  %522 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %521)
  %523 = bitcast <8 x i1> %521 to i8
  %524 = call i8 @llvm.cttz.i8(i8 %523, i1 false)
  %525 = zext i8 %524 to i32
  %526 = select i1 %522, i32 %525, i32 0
  %tile_snapshot.spill.load289 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %527 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load289, 0
  %528 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load289, 1
  %.spill.load290 = load volatile <8 x i64>, ptr %.spill45, align 64
  %529 = mul <8 x i64> %.spill.load290, splat (i64 32)
  %530 = add <8 x i64> %528, %529
  %531 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %527, 0
  %532 = insertvalue { <8 x ptr>, <8 x i64> } %531, <8 x i64> %530, 1
  %533 = extractvalue { <8 x ptr>, <8 x i64> } %532, 0
  %534 = extractvalue { <8 x ptr>, <8 x i64> } %532, 1
  %535 = getelementptr i8, <8 x ptr> %533, <8 x i64> %534
  %536 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %535, i32 1, <8 x i1> %521, <8 x float> zeroinitializer)
  %537 = load <8 x float>, ptr %.slot46, align 32
  %538 = select <8 x i1> %521, <8 x float> %536, <8 x float> %537
  store <8 x float> %538, ptr %.slot46, align 32
  store <8 x i1> %521, ptr %current.mask, align 1
  %539 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %521)
  br i1 %539, label %schedule.21, label %scheduler.loop

schedule.21:                                      ; preds = %schedule.20, %varying.coherent.false288, %scheduler.dispatch.route
  %540 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token293 = load i32, ptr %current.token, align 4
  %convergence.token.present294 = icmp ne i32 %convergence.current.token293, 0
  br i1 %convergence.token.present294, label %convergence.cascade291, label %convergence.cascade.exit292

schedule.22:                                      ; preds = %varying.coherent.false277, %scheduler.dispatch.route
  %541 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token319 = load i32, ptr %current.token, align 4
  %convergence.token.present320 = icmp ne i32 %convergence.current.token319, 0
  br i1 %convergence.token.present320, label %convergence.cascade317, label %convergence.cascade.exit318

schedule.23:                                      ; preds = %convergence.target.26.ready, %convergence.target.22.ready, %scheduler.dispatch.route
  %542 = load <8 x i1>, ptr %current.mask, align 1
  %543 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %542)
  %544 = bitcast <8 x i1> %542 to i8
  %545 = call i8 @llvm.cttz.i8(i8 %544, i1 false)
  %546 = zext i8 %545 to i32
  %547 = select i1 %543, i32 %546, i32 0
  %.state334 = load <8 x i64>, ptr %.slot48, align 64
  %548 = icmp slt <8 x i64> %.state334, splat (i64 128)
  %549 = and <8 x i1> %542, %548
  %550 = xor <8 x i1> %548, splat (i1 true)
  %551 = and <8 x i1> %542, %550
  %552 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %549)
  %553 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %551)
  %554 = and i1 %552, %553
  br i1 %554, label %varying.divergent335, label %varying.coherent336

schedule.24:                                      ; preds = %varying.coherent.true341, %scheduler.dispatch.route
  %555 = load <8 x i1>, ptr %current.mask, align 1
  %556 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %555)
  %557 = bitcast <8 x i1> %555 to i8
  %558 = call i8 @llvm.cttz.i8(i8 %557, i1 false)
  %559 = zext i8 %558 to i32
  %560 = select i1 %556, i32 %559, i32 0
  %.state343 = load <8 x i64>, ptr %.slot48, align 64
  %561 = select <8 x i1> %555, <8 x i64> %.state343, <8 x i64> zeroinitializer
  %562 = select <8 x i1> %555, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %563 = srem <8 x i64> %561, %562
  %.state344 = load <8 x i64>, ptr %.slot48, align 64
  %564 = select <8 x i1> %555, <8 x i64> %.state344, <8 x i64> zeroinitializer
  %565 = select <8 x i1> %555, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %566 = sdiv <8 x i64> %564, %565
  %567 = add <8 x i64> zeroinitializer, %566
  %568 = mul <8 x i64> %567, splat (i64 32)
  %569 = add <8 x i64> %568, %563
  %tile_snapshot.spill.load345 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill41, align 64
  %570 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load345, 0
  %571 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load345, 1
  %572 = mul <8 x i64> %569, splat (i64 32)
  %573 = add <8 x i64> %571, %572
  %574 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %570, 0
  %575 = insertvalue { <8 x ptr>, <8 x i64> } %574, <8 x i64> %573, 1
  %576 = extractvalue { <8 x ptr>, <8 x i64> } %575, 0
  %577 = extractvalue { <8 x ptr>, <8 x i64> } %575, 1
  %578 = getelementptr i8, <8 x ptr> %576, <8 x i64> %577
  %579 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %578, i32 1, <8 x i1> %555, <8 x float> zeroinitializer)
  %580 = load volatile <8 x float>, ptr %.spill49, align 32
  %581 = select <8 x i1> %555, <8 x float> %579, <8 x float> %580
  store volatile <8 x float> %581, ptr %.spill49, align 32
  %582 = select <8 x i1> %555, <8 x i64> %569, <8 x i64> zeroinitializer
  %583 = select <8 x i1> %555, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %584 = srem <8 x i64> %582, %583
  %585 = select <8 x i1> %555, <8 x i64> %569, <8 x i64> zeroinitializer
  %586 = select <8 x i1> %555, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %587 = sdiv <8 x i64> %585, %586
  %588 = add <8 x i64> zeroinitializer, %584
  %589 = add <8 x i64> zeroinitializer, %588
  %590 = sub <8 x i64> %589, splat (i64 8)
  %591 = icmp sge <8 x i64> %590, zeroinitializer
  %592 = icmp slt <8 x i64> %590, splat (i64 32)
  %593 = and <8 x i1> %591, %592
  %594 = load volatile <8 x i1>, ptr %.spill50, align 1
  %595 = select <8 x i1> %555, <8 x i1> %593, <8 x i1> %594
  store volatile <8 x i1> %595, ptr %.spill50, align 1
  %596 = add <8 x i64> zeroinitializer, %587
  %597 = mul <8 x i64> %596, splat (i64 32)
  %598 = add <8 x i64> %597, %590
  %599 = load volatile <8 x i64>, ptr %.spill51, align 64
  %600 = select <8 x i1> %555, <8 x i64> %598, <8 x i64> %599
  store volatile <8 x i64> %600, ptr %.spill51, align 64
  %601 = icmp sge <8 x i64> %598, zeroinitializer
  %602 = icmp slt <8 x i64> %598, splat (i64 128)
  %603 = and <8 x i1> %601, %602
  %604 = and <8 x i1> %555, %603
  %605 = xor <8 x i1> %603, splat (i1 true)
  %606 = and <8 x i1> %555, %605
  %607 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %604)
  %608 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %606)
  %609 = and i1 %607, %608
  br i1 %609, label %varying.divergent346, label %varying.coherent347

schedule.25:                                      ; preds = %varying.coherent.true352, %scheduler.dispatch.route
  %610 = load <8 x i1>, ptr %current.mask, align 1
  %611 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %610)
  %612 = bitcast <8 x i1> %610 to i8
  %613 = call i8 @llvm.cttz.i8(i8 %612, i1 false)
  %614 = zext i8 %613 to i32
  %615 = select i1 %611, i32 %614, i32 0
  %tile_snapshot.spill.load354 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill41, align 64
  %616 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load354, 0
  %617 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load354, 1
  %.spill.load355 = load volatile <8 x i64>, ptr %.spill51, align 64
  %618 = mul <8 x i64> %.spill.load355, splat (i64 32)
  %619 = add <8 x i64> %617, %618
  %620 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %616, 0
  %621 = insertvalue { <8 x ptr>, <8 x i64> } %620, <8 x i64> %619, 1
  %622 = extractvalue { <8 x ptr>, <8 x i64> } %621, 0
  %623 = extractvalue { <8 x ptr>, <8 x i64> } %621, 1
  %624 = getelementptr i8, <8 x ptr> %622, <8 x i64> %623
  %625 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %624, i32 1, <8 x i1> %610, <8 x float> zeroinitializer)
  %626 = load <8 x float>, ptr %.slot52, align 32
  %627 = select <8 x i1> %610, <8 x float> %625, <8 x float> %626
  store <8 x float> %627, ptr %.slot52, align 32
  store <8 x i1> %610, ptr %current.mask, align 1
  %628 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %610)
  br i1 %628, label %schedule.26, label %scheduler.loop

schedule.26:                                      ; preds = %schedule.25, %varying.coherent.false353, %scheduler.dispatch.route
  %629 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token358 = load i32, ptr %current.token, align 4
  %convergence.token.present359 = icmp ne i32 %convergence.current.token358, 0
  br i1 %convergence.token.present359, label %convergence.cascade356, label %convergence.cascade.exit357

schedule.27:                                      ; preds = %varying.coherent.false342, %scheduler.dispatch.route
  %630 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token384 = load i32, ptr %current.token, align 4
  %convergence.token.present385 = icmp ne i32 %convergence.current.token384, 0
  br i1 %convergence.token.present385, label %convergence.cascade382, label %convergence.cascade.exit383

schedule.28:                                      ; preds = %convergence.target.31.ready, %convergence.target.27.ready, %scheduler.dispatch.route
  %631 = load <8 x i1>, ptr %current.mask, align 1
  %632 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %631)
  %633 = bitcast <8 x i1> %631 to i8
  %634 = call i8 @llvm.cttz.i8(i8 %633, i1 false)
  %635 = zext i8 %634 to i32
  %636 = select i1 %632, i32 %635, i32 0
  %.state399 = load <8 x i64>, ptr %.slot54, align 64
  %637 = icmp slt <8 x i64> %.state399, splat (i64 128)
  %638 = and <8 x i1> %631, %637
  %639 = xor <8 x i1> %637, splat (i1 true)
  %640 = and <8 x i1> %631, %639
  %641 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %638)
  %642 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %640)
  %643 = and i1 %641, %642
  br i1 %643, label %varying.divergent400, label %varying.coherent401

schedule.29:                                      ; preds = %varying.coherent.true406, %scheduler.dispatch.route
  %644 = load <8 x i1>, ptr %current.mask, align 1
  %645 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %644)
  %646 = bitcast <8 x i1> %644 to i8
  %647 = call i8 @llvm.cttz.i8(i8 %646, i1 false)
  %648 = zext i8 %647 to i32
  %649 = select i1 %645, i32 %648, i32 0
  %.state408 = load <8 x i64>, ptr %.slot54, align 64
  %650 = select <8 x i1> %644, <8 x i64> %.state408, <8 x i64> zeroinitializer
  %651 = select <8 x i1> %644, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %652 = srem <8 x i64> %650, %651
  %.state409 = load <8 x i64>, ptr %.slot54, align 64
  %653 = select <8 x i1> %644, <8 x i64> %.state409, <8 x i64> zeroinitializer
  %654 = select <8 x i1> %644, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %655 = sdiv <8 x i64> %653, %654
  %656 = add <8 x i64> zeroinitializer, %655
  %657 = load volatile <8 x i64>, ptr %.spill55, align 64
  %658 = select <8 x i1> %644, <8 x i64> %656, <8 x i64> %657
  store volatile <8 x i64> %658, ptr %.spill55, align 64
  %659 = mul <8 x i64> %656, splat (i64 32)
  %660 = add <8 x i64> %659, %652
  %661 = select <8 x i1> %644, <8 x i64> %660, <8 x i64> zeroinitializer
  %662 = select <8 x i1> %644, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %663 = srem <8 x i64> %661, %662
  %664 = select <8 x i1> %644, <8 x i64> %660, <8 x i64> zeroinitializer
  %665 = select <8 x i1> %644, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %666 = sdiv <8 x i64> %664, %665
  %667 = add <8 x i64> zeroinitializer, %666
  %668 = mul <8 x i64> %667, splat (i64 32)
  %669 = add <8 x i64> %668, %663
  %tile_snapshot.spill.load410 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill47, align 64
  %670 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 0
  %671 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 1
  %672 = mul <8 x i64> %669, splat (i64 32)
  %673 = add <8 x i64> %671, %672
  %674 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %670, 0
  %675 = insertvalue { <8 x ptr>, <8 x i64> } %674, <8 x i64> %673, 1
  %676 = extractvalue { <8 x ptr>, <8 x i64> } %675, 0
  %677 = extractvalue { <8 x ptr>, <8 x i64> } %675, 1
  %678 = getelementptr i8, <8 x ptr> %676, <8 x i64> %677
  %679 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %678, i32 1, <8 x i1> %644, <8 x float> zeroinitializer)
  %680 = load volatile <8 x float>, ptr %.spill56, align 32
  %681 = select <8 x i1> %644, <8 x float> %679, <8 x float> %680
  store volatile <8 x float> %681, ptr %.spill56, align 32
  %682 = select <8 x i1> %644, <8 x i64> %669, <8 x i64> zeroinitializer
  %683 = select <8 x i1> %644, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %684 = srem <8 x i64> %682, %683
  %685 = select <8 x i1> %644, <8 x i64> %669, <8 x i64> zeroinitializer
  %686 = select <8 x i1> %644, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %687 = sdiv <8 x i64> %685, %686
  %688 = add <8 x i64> zeroinitializer, %684
  %689 = add <8 x i64> zeroinitializer, %688
  %690 = sub <8 x i64> %689, splat (i64 16)
  %691 = icmp sge <8 x i64> %690, zeroinitializer
  %692 = icmp slt <8 x i64> %690, splat (i64 32)
  %693 = and <8 x i1> %691, %692
  %694 = load volatile <8 x i1>, ptr %.spill57, align 1
  %695 = select <8 x i1> %644, <8 x i1> %693, <8 x i1> %694
  store volatile <8 x i1> %695, ptr %.spill57, align 1
  %696 = add <8 x i64> zeroinitializer, %687
  %697 = mul <8 x i64> %696, splat (i64 32)
  %698 = add <8 x i64> %697, %690
  %699 = load volatile <8 x i64>, ptr %.spill58, align 64
  %700 = select <8 x i1> %644, <8 x i64> %698, <8 x i64> %699
  store volatile <8 x i64> %700, ptr %.spill58, align 64
  %701 = icmp sge <8 x i64> %698, zeroinitializer
  %702 = icmp slt <8 x i64> %698, splat (i64 128)
  %703 = and <8 x i1> %701, %702
  %704 = and <8 x i1> %644, %703
  %705 = xor <8 x i1> %703, splat (i1 true)
  %706 = and <8 x i1> %644, %705
  %707 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %704)
  %708 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %706)
  %709 = and i1 %707, %708
  br i1 %709, label %varying.divergent411, label %varying.coherent412

schedule.30:                                      ; preds = %varying.coherent.true417, %scheduler.dispatch.route
  %710 = load <8 x i1>, ptr %current.mask, align 1
  %711 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %710)
  %712 = bitcast <8 x i1> %710 to i8
  %713 = call i8 @llvm.cttz.i8(i8 %712, i1 false)
  %714 = zext i8 %713 to i32
  %715 = select i1 %711, i32 %714, i32 0
  %tile_snapshot.spill.load419 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill47, align 64
  %716 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load419, 0
  %717 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load419, 1
  %.spill.load420 = load volatile <8 x i64>, ptr %.spill58, align 64
  %718 = mul <8 x i64> %.spill.load420, splat (i64 32)
  %719 = add <8 x i64> %717, %718
  %720 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %716, 0
  %721 = insertvalue { <8 x ptr>, <8 x i64> } %720, <8 x i64> %719, 1
  %722 = extractvalue { <8 x ptr>, <8 x i64> } %721, 0
  %723 = extractvalue { <8 x ptr>, <8 x i64> } %721, 1
  %724 = getelementptr i8, <8 x ptr> %722, <8 x i64> %723
  %725 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %724, i32 1, <8 x i1> %710, <8 x float> zeroinitializer)
  %726 = load <8 x float>, ptr %.slot59, align 32
  %727 = select <8 x i1> %710, <8 x float> %725, <8 x float> %726
  store <8 x float> %727, ptr %.slot59, align 32
  store <8 x i1> %710, ptr %current.mask, align 1
  %728 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %710)
  br i1 %728, label %schedule.31, label %scheduler.loop

schedule.31:                                      ; preds = %schedule.30, %varying.coherent.false418, %scheduler.dispatch.route
  %729 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token423 = load i32, ptr %current.token, align 4
  %convergence.token.present424 = icmp ne i32 %convergence.current.token423, 0
  br i1 %convergence.token.present424, label %convergence.cascade421, label %convergence.cascade.exit422

schedule.32:                                      ; preds = %varying.coherent.false407, %scheduler.dispatch.route
  %730 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token451 = load i32, ptr %current.token, align 4
  %convergence.token.present452 = icmp ne i32 %convergence.current.token451, 0
  br i1 %convergence.token.present452, label %convergence.cascade449, label %convergence.cascade.exit450

schedule.33:                                      ; preds = %convergence.target.36.ready, %convergence.target.32.ready, %scheduler.dispatch.route
  %731 = load <8 x i1>, ptr %current.mask, align 1
  %732 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %731)
  %733 = bitcast <8 x i1> %731 to i8
  %734 = call i8 @llvm.cttz.i8(i8 %733, i1 false)
  %735 = zext i8 %734 to i32
  %736 = select i1 %732, i32 %735, i32 0
  %.state466 = load <8 x i64>, ptr %.slot60, align 64
  %737 = icmp slt <8 x i64> %.state466, splat (i64 128)
  %738 = and <8 x i1> %731, %737
  %739 = xor <8 x i1> %737, splat (i1 true)
  %740 = and <8 x i1> %731, %739
  %741 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %738)
  %742 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %740)
  %743 = and i1 %741, %742
  br i1 %743, label %varying.divergent467, label %varying.coherent468

schedule.34:                                      ; preds = %varying.coherent.true473, %scheduler.dispatch.route
  %744 = load <8 x i1>, ptr %current.mask, align 1
  %745 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %744)
  %746 = bitcast <8 x i1> %744 to i8
  %747 = call i8 @llvm.cttz.i8(i8 %746, i1 false)
  %748 = zext i8 %747 to i32
  %749 = select i1 %745, i32 %748, i32 0
  %.state475 = load <8 x i64>, ptr %.slot60, align 64
  %750 = select <8 x i1> %744, <8 x i64> %.state475, <8 x i64> zeroinitializer
  %751 = select <8 x i1> %744, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %752 = srem <8 x i64> %750, %751
  %.state476 = load <8 x i64>, ptr %.slot60, align 64
  %753 = select <8 x i1> %744, <8 x i64> %.state476, <8 x i64> zeroinitializer
  %754 = select <8 x i1> %744, <8 x i64> splat (i64 32), <8 x i64> splat (i64 1)
  %755 = sdiv <8 x i64> %753, %754
  %.spill.load477 = load volatile <8 x i64>, ptr %.spill, align 64
  %756 = add <8 x i64> %.spill.load477, %755
  %757 = add <8 x i64> zeroinitializer, %756
  %758 = icmp sge <8 x i64> %756, zeroinitializer
  %759 = and <8 x i1> splat (i1 true), %758
  %760 = icmp slt <8 x i64> %756, splat (i64 17)
  %761 = and <8 x i1> %759, %760
  %.spill.load478 = load volatile <8 x i64>, ptr %.spill24, align 64
  %762 = add <8 x i64> %.spill.load478, %752
  %763 = mul <8 x i64> %757, splat (i64 65)
  %764 = add <8 x i64> %763, %762
  %765 = icmp sge <8 x i64> %762, zeroinitializer
  %766 = and <8 x i1> %761, %765
  %767 = icmp slt <8 x i64> %762, splat (i64 65)
  %768 = and <8 x i1> %766, %767
  %769 = load volatile <8 x i64>, ptr %.spill61, align 64
  %770 = select <8 x i1> %744, <8 x i64> %764, <8 x i64> %769
  store volatile <8 x i64> %770, ptr %.spill61, align 64
  %tile_snapshot.spill.load479 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill53, align 64
  %771 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load479, 0
  %772 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load479, 1
  %.state480 = load <8 x i64>, ptr %.slot60, align 64
  %773 = mul <8 x i64> %.state480, splat (i64 32)
  %774 = add <8 x i64> %772, %773
  %775 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %771, 0
  %776 = insertvalue { <8 x ptr>, <8 x i64> } %775, <8 x i64> %774, 1
  %777 = extractvalue { <8 x ptr>, <8 x i64> } %776, 0
  %778 = extractvalue { <8 x ptr>, <8 x i64> } %776, 1
  %779 = getelementptr i8, <8 x ptr> %777, <8 x i64> %778
  %780 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %779, i32 1, <8 x i1> %744, <8 x float> zeroinitializer)
  %781 = load volatile <8 x float>, ptr %.spill62, align 32
  %782 = select <8 x i1> %744, <8 x float> %780, <8 x float> %781
  store volatile <8 x float> %782, ptr %.spill62, align 32
  %783 = and <8 x i1> %744, %768
  %784 = xor <8 x i1> %768, splat (i1 true)
  %785 = and <8 x i1> %744, %784
  %786 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %783)
  %787 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %785)
  %788 = and i1 %786, %787
  br i1 %788, label %varying.divergent481, label %varying.coherent482

schedule.35:                                      ; preds = %varying.coherent.true487, %scheduler.dispatch.route
  %789 = load <8 x i1>, ptr %current.mask, align 1
  %790 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %789)
  %791 = bitcast <8 x i1> %789 to i8
  %792 = call i8 @llvm.cttz.i8(i8 %791, i1 false)
  %793 = zext i8 %792 to i32
  %794 = select i1 %790, i32 %793, i32 0
  %.spill.load489 = load volatile <8 x i64>, ptr %.spill61, align 64
  %.spill.load490 = load volatile <8 x float>, ptr %.spill62, align 32
  %795 = extractvalue { ptr, i64 } %25, 0
  %796 = mul <8 x i64> %.spill.load489, splat (i64 4)
  %797 = getelementptr i8, ptr %795, <8 x i64> %796
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.spill.load490, <8 x ptr> %797, i32 1, <8 x i1> %789)
  store <8 x i1> %789, ptr %current.mask, align 1
  %798 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %789)
  br i1 %798, label %schedule.36, label %scheduler.loop

schedule.36:                                      ; preds = %schedule.35, %varying.coherent.false488, %scheduler.dispatch.route
  %799 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token493 = load i32, ptr %current.token, align 4
  %convergence.token.present494 = icmp ne i32 %convergence.current.token493, 0
  br i1 %convergence.token.present494, label %convergence.cascade491, label %convergence.cascade.exit492

schedule.37:                                      ; preds = %varying.coherent.false474, %scheduler.dispatch.route
  %800 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token511 = load i32, ptr %current.token, align 4
  %convergence.token.present512 = icmp ne i32 %convergence.current.token511, 0
  br i1 %convergence.token.present512, label %convergence.cascade509, label %convergence.cascade.exit510

schedule.38:                                      ; preds = %varying.coherent.false, %scheduler.dispatch.route
  %801 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token540 = load i32, ptr %current.token, align 4
  %convergence.token.present541 = icmp ne i32 %convergence.current.token540, 0
  br i1 %convergence.token.present541, label %convergence.cascade538, label %convergence.cascade.exit539

varying.divergent:                                ; preds = %schedule.1
  %802 = load i32, ptr %current.token, align 4
  %803 = icmp ne i32 %802, 0
  %804 = sub i32 %802, 1
  %805 = select i1 %803, i32 %804, i32 0
  %806 = load i8, ptr %frame.active, align 1
  %807 = trunc i32 %805 to i8
  %808 = shl i8 1, %807
  %809 = and i8 %806, %808
  %810 = icmp ne i8 %809, 0
  %811 = load <8 x i32>, ptr %frame.static.id, align 32
  %812 = extractelement <8 x i32> %811, i32 %805
  %813 = icmp eq i32 %812, 0
  %814 = and i1 %810, %813
  %815 = and i1 %803, %814
  %816 = xor i1 %815, true
  %817 = and i1 true, %816
  %818 = xor i8 %806, -1
  %819 = icmp ne i8 %818, 0
  %820 = xor i1 %819, true
  %821 = and i1 %817, %820
  br i1 %821, label %convergence.overflow.trap, label %convergence.overflow.resume

varying.coherent:                                 ; preds = %schedule.1
  br i1 %118, label %varying.coherent.true, label %varying.coherent.false

convergence.overflow.trap:                        ; preds = %varying.divergent
  call void @llvm.trap()
  unreachable

convergence.overflow.resume:                      ; preds = %varying.divergent
  %822 = call i8 @llvm.cttz.i8(i8 %818, i1 false)
  %823 = zext i8 %822 to i32
  %824 = select i1 %819, i32 %823, i32 0
  %825 = trunc i32 %824 to i8
  %826 = shl i8 1, %825
  %827 = or i8 %806, %826
  %828 = select i1 %817, i8 %827, i8 %806
  store i8 %828, ptr %frame.active, align 1
  %829 = load <8 x i32>, ptr %frame.static.id, align 32
  %830 = extractelement <8 x i32> %829, i32 %824
  %831 = select i1 %817, i32 0, i32 %830
  %832 = load <8 x i32>, ptr %frame.static.id, align 32
  %833 = insertelement <8 x i32> %832, i32 %831, i32 %824
  store <8 x i32> %833, ptr %frame.static.id, align 32
  %834 = load <8 x i32>, ptr %frame.parent.token, align 32
  %835 = extractelement <8 x i32> %834, i32 %824
  %836 = select i1 %817, i32 %802, i32 %835
  %837 = load <8 x i32>, ptr %frame.parent.token, align 32
  %838 = insertelement <8 x i32> %837, i32 %836, i32 %824
  store <8 x i32> %838, ptr %frame.parent.token, align 32
  %839 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %824
  %840 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %824
  %841 = load <8 x i1>, ptr %839, align 1
  %842 = load <8 x i1>, ptr %840, align 1
  %843 = select i1 %817, <8 x i1> %108, <8 x i1> %841
  store <8 x i1> %843, ptr %839, align 1
  %844 = select i1 %817, <8 x i1> zeroinitializer, <8 x i1> %842
  store <8 x i1> %844, ptr %840, align 1
  %845 = add i32 %824, 1
  %846 = select i1 %815, i32 %802, i32 %845
  %847 = select i1 true, i32 %846, i32 %802
  store i32 %847, ptr %current.token, align 4
  %848 = load i32, ptr %current.token, align 4
  %849 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %115)
  %850 = load i32, ptr %ready.count, align 4
  %851 = icmp uge i32 %850, 8
  %852 = and i1 %849, %851
  br i1 %852, label %ready.overflow.trap73, label %ready.overflow.resume74

ready.overflow.trap73:                            ; preds = %convergence.overflow.resume
  call void @llvm.trap()
  unreachable

ready.overflow.resume74:                          ; preds = %convergence.overflow.resume
  %853 = select i1 %849, i32 %850, i32 0
  %854 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %853
  %855 = load <8 x i1>, ptr %854, align 1
  %856 = select i1 %849, <8 x i1> %115, <8 x i1> %855
  store <8 x i1> %856, ptr %854, align 1
  %857 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %853
  %858 = load i32, ptr %857, align 4
  %859 = select i1 %849, i32 2, i32 %858
  store i32 %859, ptr %857, align 4
  %860 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %853
  %861 = load i32, ptr %860, align 4
  %862 = select i1 %849, i32 %848, i32 %861
  store i32 %862, ptr %860, align 4
  %863 = add i32 %850, 1
  %864 = select i1 %849, i32 %863, i32 %850
  store i32 %864, ptr %ready.count, align 4
  %865 = load <8 x i1>, ptr %runnable.mask, align 1
  %866 = or <8 x i1> %865, %115
  store <8 x i1> %866, ptr %runnable.mask, align 1
  store <8 x i1> %117, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true:                            ; preds = %varying.coherent
  store <8 x i1> %108, ptr %current.mask, align 1
  %867 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %108)
  br i1 %867, label %schedule.2, label %scheduler.loop

varying.coherent.false:                           ; preds = %varying.coherent
  store <8 x i1> %108, ptr %current.mask, align 1
  %868 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %108)
  br i1 %868, label %schedule.38, label %scheduler.loop

varying.divergent87:                              ; preds = %schedule.3
  %869 = load i32, ptr %current.token, align 4
  %870 = icmp ne i32 %869, 0
  %871 = sub i32 %869, 1
  %872 = select i1 %870, i32 %871, i32 0
  %873 = load i8, ptr %frame.active, align 1
  %874 = trunc i32 %872 to i8
  %875 = shl i8 1, %874
  %876 = and i8 %873, %875
  %877 = icmp ne i8 %876, 0
  %878 = load <8 x i32>, ptr %frame.static.id, align 32
  %879 = extractelement <8 x i32> %878, i32 %872
  %880 = icmp eq i32 %879, 1
  %881 = and i1 %877, %880
  %882 = and i1 %870, %881
  %883 = xor i1 %882, true
  %884 = and i1 true, %883
  %885 = xor i8 %873, -1
  %886 = icmp ne i8 %885, 0
  %887 = xor i1 %886, true
  %888 = and i1 %884, %887
  br i1 %888, label %convergence.overflow.trap89, label %convergence.overflow.resume90

varying.coherent88:                               ; preds = %schedule.3
  br i1 %224, label %varying.coherent.true93, label %varying.coherent.false94

convergence.overflow.trap89:                      ; preds = %varying.divergent87
  call void @llvm.trap()
  unreachable

convergence.overflow.resume90:                    ; preds = %varying.divergent87
  %889 = call i8 @llvm.cttz.i8(i8 %885, i1 false)
  %890 = zext i8 %889 to i32
  %891 = select i1 %886, i32 %890, i32 0
  %892 = trunc i32 %891 to i8
  %893 = shl i8 1, %892
  %894 = or i8 %873, %893
  %895 = select i1 %884, i8 %894, i8 %873
  store i8 %895, ptr %frame.active, align 1
  %896 = load <8 x i32>, ptr %frame.static.id, align 32
  %897 = extractelement <8 x i32> %896, i32 %891
  %898 = select i1 %884, i32 1, i32 %897
  %899 = load <8 x i32>, ptr %frame.static.id, align 32
  %900 = insertelement <8 x i32> %899, i32 %898, i32 %891
  store <8 x i32> %900, ptr %frame.static.id, align 32
  %901 = load <8 x i32>, ptr %frame.parent.token, align 32
  %902 = extractelement <8 x i32> %901, i32 %891
  %903 = select i1 %884, i32 %869, i32 %902
  %904 = load <8 x i32>, ptr %frame.parent.token, align 32
  %905 = insertelement <8 x i32> %904, i32 %903, i32 %891
  store <8 x i32> %905, ptr %frame.parent.token, align 32
  %906 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %891
  %907 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %891
  %908 = load <8 x i1>, ptr %906, align 1
  %909 = load <8 x i1>, ptr %907, align 1
  %910 = select i1 %884, <8 x i1> %214, <8 x i1> %908
  store <8 x i1> %910, ptr %906, align 1
  %911 = select i1 %884, <8 x i1> zeroinitializer, <8 x i1> %909
  store <8 x i1> %911, ptr %907, align 1
  %912 = add i32 %891, 1
  %913 = select i1 %882, i32 %869, i32 %912
  %914 = select i1 true, i32 %913, i32 %869
  store i32 %914, ptr %current.token, align 4
  %915 = load i32, ptr %current.token, align 4
  %916 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %221)
  %917 = load i32, ptr %ready.count, align 4
  %918 = icmp uge i32 %917, 8
  %919 = and i1 %916, %918
  br i1 %919, label %ready.overflow.trap91, label %ready.overflow.resume92

ready.overflow.trap91:                            ; preds = %convergence.overflow.resume90
  call void @llvm.trap()
  unreachable

ready.overflow.resume92:                          ; preds = %convergence.overflow.resume90
  %920 = select i1 %916, i32 %917, i32 0
  %921 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %920
  %922 = load <8 x i1>, ptr %921, align 1
  %923 = select i1 %916, <8 x i1> %221, <8 x i1> %922
  store <8 x i1> %923, ptr %921, align 1
  %924 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %920
  %925 = load i32, ptr %924, align 4
  %926 = select i1 %916, i32 4, i32 %925
  store i32 %926, ptr %924, align 4
  %927 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %920
  %928 = load i32, ptr %927, align 4
  %929 = select i1 %916, i32 %915, i32 %928
  store i32 %929, ptr %927, align 4
  %930 = add i32 %917, 1
  %931 = select i1 %916, i32 %930, i32 %917
  store i32 %931, ptr %ready.count, align 4
  %932 = load <8 x i1>, ptr %runnable.mask, align 1
  %933 = or <8 x i1> %932, %221
  store <8 x i1> %933, ptr %runnable.mask, align 1
  store <8 x i1> %223, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true93:                          ; preds = %varying.coherent88
  store <8 x i1> %214, ptr %current.mask, align 1
  %934 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %214)
  br i1 %934, label %schedule.4, label %scheduler.loop

varying.coherent.false94:                         ; preds = %varying.coherent88
  store <8 x i1> %214, ptr %current.mask, align 1
  %935 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %214)
  br i1 %935, label %schedule.7, label %scheduler.loop

varying.divergent98:                              ; preds = %schedule.4
  %936 = load i32, ptr %current.token, align 4
  %937 = icmp ne i32 %936, 0
  %938 = sub i32 %936, 1
  %939 = select i1 %937, i32 %938, i32 0
  %940 = load i8, ptr %frame.active, align 1
  %941 = trunc i32 %939 to i8
  %942 = shl i8 1, %941
  %943 = and i8 %940, %942
  %944 = icmp ne i8 %943, 0
  %945 = load <8 x i32>, ptr %frame.static.id, align 32
  %946 = extractelement <8 x i32> %945, i32 %939
  %947 = icmp eq i32 %946, 2
  %948 = and i1 %944, %947
  %949 = and i1 %937, %948
  %950 = xor i1 %949, true
  %951 = and i1 true, %950
  %952 = xor i8 %940, -1
  %953 = icmp ne i8 %952, 0
  %954 = xor i1 %953, true
  %955 = and i1 %951, %954
  br i1 %955, label %convergence.overflow.trap100, label %convergence.overflow.resume101

varying.coherent99:                               ; preds = %schedule.4
  br i1 %257, label %varying.coherent.true107, label %varying.coherent.false108

convergence.overflow.trap100:                     ; preds = %varying.divergent98
  call void @llvm.trap()
  unreachable

convergence.overflow.resume101:                   ; preds = %varying.divergent98
  %956 = call i8 @llvm.cttz.i8(i8 %952, i1 false)
  %957 = zext i8 %956 to i32
  %958 = select i1 %953, i32 %957, i32 0
  %959 = trunc i32 %958 to i8
  %960 = shl i8 1, %959
  %961 = or i8 %940, %960
  %962 = select i1 %951, i8 %961, i8 %940
  store i8 %962, ptr %frame.active, align 1
  %963 = load <8 x i32>, ptr %frame.static.id, align 32
  %964 = extractelement <8 x i32> %963, i32 %958
  %965 = select i1 %951, i32 2, i32 %964
  %966 = load <8 x i32>, ptr %frame.static.id, align 32
  %967 = insertelement <8 x i32> %966, i32 %965, i32 %958
  store <8 x i32> %967, ptr %frame.static.id, align 32
  %968 = load <8 x i32>, ptr %frame.parent.token, align 32
  %969 = extractelement <8 x i32> %968, i32 %958
  %970 = select i1 %951, i32 %936, i32 %969
  %971 = load <8 x i32>, ptr %frame.parent.token, align 32
  %972 = insertelement <8 x i32> %971, i32 %970, i32 %958
  store <8 x i32> %972, ptr %frame.parent.token, align 32
  %973 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %958
  %974 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %958
  %975 = load <8 x i1>, ptr %973, align 1
  %976 = load <8 x i1>, ptr %974, align 1
  %977 = select i1 %951, <8 x i1> %227, <8 x i1> %975
  store <8 x i1> %977, ptr %973, align 1
  %978 = select i1 %951, <8 x i1> zeroinitializer, <8 x i1> %976
  store <8 x i1> %978, ptr %974, align 1
  %979 = add i32 %958, 1
  %980 = select i1 %949, i32 %936, i32 %979
  %981 = select i1 true, i32 %980, i32 %936
  store i32 %981, ptr %current.token, align 4
  %.spill.load102 = load float, ptr %.spill19, align 4
  %.splatinsert103 = insertelement <8 x float> poison, float %.spill.load102, i64 0
  %.splat104 = shufflevector <8 x float> %.splatinsert103, <8 x float> poison, <8 x i32> zeroinitializer
  %982 = load <8 x float>, ptr %.slot28, align 32
  %983 = select <8 x i1> %256, <8 x float> %.splat104, <8 x float> %982
  store <8 x float> %983, ptr %.slot28, align 32
  %984 = load i32, ptr %current.token, align 4
  %985 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %254)
  %986 = load i32, ptr %ready.count, align 4
  %987 = icmp uge i32 %986, 8
  %988 = and i1 %985, %987
  br i1 %988, label %ready.overflow.trap105, label %ready.overflow.resume106

ready.overflow.trap105:                           ; preds = %convergence.overflow.resume101
  call void @llvm.trap()
  unreachable

ready.overflow.resume106:                         ; preds = %convergence.overflow.resume101
  %989 = select i1 %985, i32 %986, i32 0
  %990 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %989
  %991 = load <8 x i1>, ptr %990, align 1
  %992 = select i1 %985, <8 x i1> %254, <8 x i1> %991
  store <8 x i1> %992, ptr %990, align 1
  %993 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %989
  %994 = load i32, ptr %993, align 4
  %995 = select i1 %985, i32 5, i32 %994
  store i32 %995, ptr %993, align 4
  %996 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %989
  %997 = load i32, ptr %996, align 4
  %998 = select i1 %985, i32 %984, i32 %997
  store i32 %998, ptr %996, align 4
  %999 = add i32 %986, 1
  %1000 = select i1 %985, i32 %999, i32 %986
  store i32 %1000, ptr %ready.count, align 4
  %1001 = load <8 x i1>, ptr %runnable.mask, align 1
  %1002 = or <8 x i1> %1001, %254
  store <8 x i1> %1002, ptr %runnable.mask, align 1
  store <8 x i1> %256, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true107:                         ; preds = %varying.coherent99
  store <8 x i1> %227, ptr %current.mask, align 1
  %1003 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %227)
  br i1 %1003, label %schedule.5, label %scheduler.loop

varying.coherent.false108:                        ; preds = %varying.coherent99
  %.spill.load109 = load float, ptr %.spill19, align 4
  %.splatinsert110 = insertelement <8 x float> poison, float %.spill.load109, i64 0
  %.splat111 = shufflevector <8 x float> %.splatinsert110, <8 x float> poison, <8 x i32> zeroinitializer
  %1004 = load <8 x float>, ptr %.slot28, align 32
  %1005 = select <8 x i1> %227, <8 x float> %.splat111, <8 x float> %1004
  store <8 x float> %1005, ptr %.slot28, align 32
  store <8 x i1> %227, ptr %current.mask, align 1
  %1006 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %227)
  br i1 %1006, label %schedule.6, label %scheduler.loop

convergence.cascade:                              ; preds = %convergence.cascade, %schedule.6
  %convergence.cascade.flow = phi <8 x i1> [ %273, %schedule.6 ], [ %1049, %convergence.cascade ]
  %convergence.cascade.depth = phi i32 [ 0, %schedule.6 ], [ %1050, %convergence.cascade ]
  %1007 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow)
  %1008 = load i32, ptr %current.token, align 4
  %1009 = icmp ne i32 %1008, 0
  %1010 = and i1 %1007, %1009
  %1011 = sub i32 %1008, 1
  %1012 = select i1 %1010, i32 %1011, i32 0
  %1013 = load i8, ptr %frame.active, align 1
  %1014 = trunc i32 %1012 to i8
  %1015 = shl i8 1, %1014
  %1016 = and i8 %1013, %1015
  %1017 = icmp ne i8 %1016, 0
  %1018 = load <8 x i32>, ptr %frame.static.id, align 32
  %1019 = extractelement <8 x i32> %1018, i32 %1012
  %convergence.target.pointer = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %1019
  %convergence.dynamic.target = load i32, ptr %convergence.target.pointer, align 4
  %1020 = icmp eq i32 %convergence.dynamic.target, 6
  %1021 = and i1 %1017, %1020
  %1022 = and i1 %1010, %1021
  %1023 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1012
  %1024 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1012
  %1025 = load <8 x i1>, ptr %1023, align 1
  %1026 = load <8 x i1>, ptr %1024, align 1
  %1027 = or <8 x i1> %1026, %convergence.cascade.flow
  %1028 = load <8 x i1>, ptr %live.mask, align 1
  %1029 = and <8 x i1> %1025, %1028
  %1030 = icmp eq <8 x i1> %1027, %1029
  %1031 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1030)
  %1032 = and i1 %1022, %1031
  %1033 = select i1 %1032, <8 x i1> zeroinitializer, <8 x i1> %1027
  %1034 = select i1 %1022, <8 x i1> %1033, <8 x i1> %1026
  store <8 x i1> %1034, ptr %1024, align 1
  %1035 = select i1 %1032, <8 x i1> zeroinitializer, <8 x i1> %1025
  store <8 x i1> %1035, ptr %1023, align 1
  %1036 = trunc i32 %1012 to i8
  %1037 = shl i8 1, %1036
  %1038 = xor i8 %1037, -1
  %1039 = and i8 %1013, %1038
  %1040 = select i1 %1032, i8 %1039, i8 %1013
  store i8 %1040, ptr %frame.active, align 1
  %.splatinsert113 = insertelement <8 x i1> poison, i1 %1022, i64 0
  %.splat114 = shufflevector <8 x i1> %.splatinsert113, <8 x i1> poison, <8 x i32> zeroinitializer
  %1041 = and <8 x i1> %convergence.cascade.flow, %.splat114
  %1042 = load <8 x i1>, ptr %runnable.mask, align 1
  %1043 = xor <8 x i1> %1041, splat (i1 true)
  %1044 = and <8 x i1> %1042, %1043
  store <8 x i1> %1044, ptr %runnable.mask, align 1
  %.splatinsert115 = insertelement <8 x i1> poison, i1 %1032, i64 0
  %.splat116 = shufflevector <8 x i1> %.splatinsert115, <8 x i1> poison, <8 x i32> zeroinitializer
  %1045 = select <8 x i1> %.splat116, <8 x i1> %1027, <8 x i1> zeroinitializer
  %1046 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1047 = extractelement <8 x i32> %1046, i32 %1012
  %1048 = select i1 %1032, i32 %1047, i32 %1008
  store i32 %1048, ptr %current.token, align 4
  %.splatinsert117 = insertelement <8 x i1> poison, i1 %1022, i64 0
  %.splat118 = shufflevector <8 x i1> %.splatinsert117, <8 x i1> poison, <8 x i32> zeroinitializer
  %1049 = select <8 x i1> %.splat118, <8 x i1> %1045, <8 x i1> %convergence.cascade.flow
  %1050 = add i32 %convergence.cascade.depth, 1
  %1051 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1049)
  %1052 = icmp ult i32 %1050, 8
  %1053 = and i1 %1051, %1052
  %1054 = and i1 %1022, %1053
  %convergence.parent.token = load i32, ptr %current.token, align 4
  %convergence.parent.present = icmp ne i32 %convergence.parent.token, 0
  %1055 = and i1 %1054, %convergence.parent.present
  br i1 %1055, label %convergence.cascade, label %convergence.cascade.exit

convergence.cascade.exit:                         ; preds = %convergence.cascade, %schedule.6
  %convergence.cascade.result = phi <8 x i1> [ %273, %schedule.6 ], [ %1049, %convergence.cascade ]
  %1056 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %1056, label %convergence.target.6.ready, label %scheduler.loop

convergence.target.6.ready:                       ; preds = %convergence.cascade.exit
  %1057 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1058 = bitcast <8 x i1> %convergence.cascade.result to i8
  %1059 = call i8 @llvm.cttz.i8(i8 %1058, i1 false)
  %1060 = zext i8 %1059 to i32
  %1061 = select i1 %1057, i32 %1060, i32 0
  %tile_snapshot.spill.load = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %1062 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %1063 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state119 = load <8 x i64>, ptr %.slot26, align 64
  %1064 = mul <8 x i64> %.state119, splat (i64 32)
  %1065 = add <8 x i64> %1063, %1064
  %1066 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1062, 0
  %1067 = insertvalue { <8 x ptr>, <8 x i64> } %1066, <8 x i64> %1065, 1
  %.state120 = load <8 x float>, ptr %.slot28, align 32
  %1068 = extractvalue { <8 x ptr>, <8 x i64> } %1067, 0
  %1069 = extractvalue { <8 x ptr>, <8 x i64> } %1067, 1
  %1070 = getelementptr i8, <8 x ptr> %1068, <8 x i64> %1069
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state120, <8 x ptr> %1070, i32 1, <8 x i1> %convergence.cascade.result)
  %.state121 = load <8 x i64>, ptr %.slot26, align 64
  %1071 = add <8 x i64> %.state121, splat (i64 1)
  %1072 = load <8 x i64>, ptr %.slot26, align 64
  %1073 = select <8 x i1> %convergence.cascade.result, <8 x i64> %1071, <8 x i64> %1072
  store <8 x i64> %1073, ptr %.slot26, align 64
  store <8 x i1> %convergence.cascade.result, ptr %current.mask, align 1
  %1074 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %1074, label %schedule.3, label %scheduler.loop

convergence.cascade122:                           ; preds = %convergence.cascade122, %schedule.7
  %convergence.cascade.flow126 = phi <8 x i1> [ %274, %schedule.7 ], [ %1117, %convergence.cascade122 ]
  %convergence.cascade.depth127 = phi i32 [ 0, %schedule.7 ], [ %1118, %convergence.cascade122 ]
  %1075 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow126)
  %1076 = load i32, ptr %current.token, align 4
  %1077 = icmp ne i32 %1076, 0
  %1078 = and i1 %1075, %1077
  %1079 = sub i32 %1076, 1
  %1080 = select i1 %1078, i32 %1079, i32 0
  %1081 = load i8, ptr %frame.active, align 1
  %1082 = trunc i32 %1080 to i8
  %1083 = shl i8 1, %1082
  %1084 = and i8 %1081, %1083
  %1085 = icmp ne i8 %1084, 0
  %1086 = load <8 x i32>, ptr %frame.static.id, align 32
  %1087 = extractelement <8 x i32> %1086, i32 %1080
  %convergence.target.pointer128 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %1087
  %convergence.dynamic.target129 = load i32, ptr %convergence.target.pointer128, align 4
  %1088 = icmp eq i32 %convergence.dynamic.target129, 7
  %1089 = and i1 %1085, %1088
  %1090 = and i1 %1078, %1089
  %1091 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1080
  %1092 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1080
  %1093 = load <8 x i1>, ptr %1091, align 1
  %1094 = load <8 x i1>, ptr %1092, align 1
  %1095 = or <8 x i1> %1094, %convergence.cascade.flow126
  %1096 = load <8 x i1>, ptr %live.mask, align 1
  %1097 = and <8 x i1> %1093, %1096
  %1098 = icmp eq <8 x i1> %1095, %1097
  %1099 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1098)
  %1100 = and i1 %1090, %1099
  %1101 = select i1 %1100, <8 x i1> zeroinitializer, <8 x i1> %1095
  %1102 = select i1 %1090, <8 x i1> %1101, <8 x i1> %1094
  store <8 x i1> %1102, ptr %1092, align 1
  %1103 = select i1 %1100, <8 x i1> zeroinitializer, <8 x i1> %1093
  store <8 x i1> %1103, ptr %1091, align 1
  %1104 = trunc i32 %1080 to i8
  %1105 = shl i8 1, %1104
  %1106 = xor i8 %1105, -1
  %1107 = and i8 %1081, %1106
  %1108 = select i1 %1100, i8 %1107, i8 %1081
  store i8 %1108, ptr %frame.active, align 1
  %.splatinsert130 = insertelement <8 x i1> poison, i1 %1090, i64 0
  %.splat131 = shufflevector <8 x i1> %.splatinsert130, <8 x i1> poison, <8 x i32> zeroinitializer
  %1109 = and <8 x i1> %convergence.cascade.flow126, %.splat131
  %1110 = load <8 x i1>, ptr %runnable.mask, align 1
  %1111 = xor <8 x i1> %1109, splat (i1 true)
  %1112 = and <8 x i1> %1110, %1111
  store <8 x i1> %1112, ptr %runnable.mask, align 1
  %.splatinsert132 = insertelement <8 x i1> poison, i1 %1100, i64 0
  %.splat133 = shufflevector <8 x i1> %.splatinsert132, <8 x i1> poison, <8 x i32> zeroinitializer
  %1113 = select <8 x i1> %.splat133, <8 x i1> %1095, <8 x i1> zeroinitializer
  %1114 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1115 = extractelement <8 x i32> %1114, i32 %1080
  %1116 = select i1 %1100, i32 %1115, i32 %1076
  store i32 %1116, ptr %current.token, align 4
  %.splatinsert134 = insertelement <8 x i1> poison, i1 %1090, i64 0
  %.splat135 = shufflevector <8 x i1> %.splatinsert134, <8 x i1> poison, <8 x i32> zeroinitializer
  %1117 = select <8 x i1> %.splat135, <8 x i1> %1113, <8 x i1> %convergence.cascade.flow126
  %1118 = add i32 %convergence.cascade.depth127, 1
  %1119 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1117)
  %1120 = icmp ult i32 %1118, 8
  %1121 = and i1 %1119, %1120
  %1122 = and i1 %1090, %1121
  %convergence.parent.token136 = load i32, ptr %current.token, align 4
  %convergence.parent.present137 = icmp ne i32 %convergence.parent.token136, 0
  %1123 = and i1 %1122, %convergence.parent.present137
  br i1 %1123, label %convergence.cascade122, label %convergence.cascade.exit123

convergence.cascade.exit123:                      ; preds = %convergence.cascade122, %schedule.7
  %convergence.cascade.result138 = phi <8 x i1> [ %274, %schedule.7 ], [ %1117, %convergence.cascade122 ]
  %1124 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result138)
  br i1 %1124, label %convergence.target.7.ready, label %scheduler.loop

convergence.target.7.ready:                       ; preds = %convergence.cascade.exit123
  %1125 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result138)
  %1126 = bitcast <8 x i1> %convergence.cascade.result138 to i8
  %1127 = call i8 @llvm.cttz.i8(i8 %1126, i1 false)
  %1128 = zext i8 %1127 to i32
  %1129 = select i1 %1125, i32 %1128, i32 0
  %1130 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %1131 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1132 = extractvalue { <8 x ptr>, <8 x i64> } %1130, 0
  %1133 = select <8 x i1> %convergence.cascade.result138, <8 x ptr> %1131, <8 x ptr> %1132
  %1134 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1135 = extractvalue { <8 x ptr>, <8 x i64> } %1130, 1
  %1136 = select <8 x i1> %convergence.cascade.result138, <8 x i64> %1134, <8 x i64> %1135
  %1137 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1133, 0
  %1138 = insertvalue { <8 x ptr>, <8 x i64> } %1137, <8 x i64> %1136, 1
  store volatile { <8 x ptr>, <8 x i64> } %1138, ptr %tile_snapshot.spill29, align 64
  %1139 = load <8 x i64>, ptr %.slot30, align 64
  %1140 = select <8 x i1> %convergence.cascade.result138, <8 x i64> zeroinitializer, <8 x i64> %1139
  store <8 x i64> %1140, ptr %.slot30, align 64
  store <8 x i1> %convergence.cascade.result138, ptr %current.mask, align 1
  %1141 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result138)
  br i1 %1141, label %schedule.8, label %scheduler.loop

varying.divergent140:                             ; preds = %schedule.8
  %1142 = load i32, ptr %current.token, align 4
  %1143 = icmp ne i32 %1142, 0
  %1144 = sub i32 %1142, 1
  %1145 = select i1 %1143, i32 %1144, i32 0
  %1146 = load i8, ptr %frame.active, align 1
  %1147 = trunc i32 %1145 to i8
  %1148 = shl i8 1, %1147
  %1149 = and i8 %1146, %1148
  %1150 = icmp ne i8 %1149, 0
  %1151 = load <8 x i32>, ptr %frame.static.id, align 32
  %1152 = extractelement <8 x i32> %1151, i32 %1145
  %1153 = icmp eq i32 %1152, 3
  %1154 = and i1 %1150, %1153
  %1155 = and i1 %1143, %1154
  %1156 = xor i1 %1155, true
  %1157 = and i1 true, %1156
  %1158 = xor i8 %1146, -1
  %1159 = icmp ne i8 %1158, 0
  %1160 = xor i1 %1159, true
  %1161 = and i1 %1157, %1160
  br i1 %1161, label %convergence.overflow.trap142, label %convergence.overflow.resume143

varying.coherent141:                              ; preds = %schedule.8
  br i1 %285, label %varying.coherent.true146, label %varying.coherent.false147

convergence.overflow.trap142:                     ; preds = %varying.divergent140
  call void @llvm.trap()
  unreachable

convergence.overflow.resume143:                   ; preds = %varying.divergent140
  %1162 = call i8 @llvm.cttz.i8(i8 %1158, i1 false)
  %1163 = zext i8 %1162 to i32
  %1164 = select i1 %1159, i32 %1163, i32 0
  %1165 = trunc i32 %1164 to i8
  %1166 = shl i8 1, %1165
  %1167 = or i8 %1146, %1166
  %1168 = select i1 %1157, i8 %1167, i8 %1146
  store i8 %1168, ptr %frame.active, align 1
  %1169 = load <8 x i32>, ptr %frame.static.id, align 32
  %1170 = extractelement <8 x i32> %1169, i32 %1164
  %1171 = select i1 %1157, i32 3, i32 %1170
  %1172 = load <8 x i32>, ptr %frame.static.id, align 32
  %1173 = insertelement <8 x i32> %1172, i32 %1171, i32 %1164
  store <8 x i32> %1173, ptr %frame.static.id, align 32
  %1174 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1175 = extractelement <8 x i32> %1174, i32 %1164
  %1176 = select i1 %1157, i32 %1142, i32 %1175
  %1177 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1178 = insertelement <8 x i32> %1177, i32 %1176, i32 %1164
  store <8 x i32> %1178, ptr %frame.parent.token, align 32
  %1179 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1164
  %1180 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1164
  %1181 = load <8 x i1>, ptr %1179, align 1
  %1182 = load <8 x i1>, ptr %1180, align 1
  %1183 = select i1 %1157, <8 x i1> %275, <8 x i1> %1181
  store <8 x i1> %1183, ptr %1179, align 1
  %1184 = select i1 %1157, <8 x i1> zeroinitializer, <8 x i1> %1182
  store <8 x i1> %1184, ptr %1180, align 1
  %1185 = add i32 %1164, 1
  %1186 = select i1 %1155, i32 %1142, i32 %1185
  %1187 = select i1 true, i32 %1186, i32 %1142
  store i32 %1187, ptr %current.token, align 4
  %1188 = load i32, ptr %current.token, align 4
  %1189 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %282)
  %1190 = load i32, ptr %ready.count, align 4
  %1191 = icmp uge i32 %1190, 8
  %1192 = and i1 %1189, %1191
  br i1 %1192, label %ready.overflow.trap144, label %ready.overflow.resume145

ready.overflow.trap144:                           ; preds = %convergence.overflow.resume143
  call void @llvm.trap()
  unreachable

ready.overflow.resume145:                         ; preds = %convergence.overflow.resume143
  %1193 = select i1 %1189, i32 %1190, i32 0
  %1194 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1193
  %1195 = load <8 x i1>, ptr %1194, align 1
  %1196 = select i1 %1189, <8 x i1> %282, <8 x i1> %1195
  store <8 x i1> %1196, ptr %1194, align 1
  %1197 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1193
  %1198 = load i32, ptr %1197, align 4
  %1199 = select i1 %1189, i32 9, i32 %1198
  store i32 %1199, ptr %1197, align 4
  %1200 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1193
  %1201 = load i32, ptr %1200, align 4
  %1202 = select i1 %1189, i32 %1188, i32 %1201
  store i32 %1202, ptr %1200, align 4
  %1203 = add i32 %1190, 1
  %1204 = select i1 %1189, i32 %1203, i32 %1190
  store i32 %1204, ptr %ready.count, align 4
  %1205 = load <8 x i1>, ptr %runnable.mask, align 1
  %1206 = or <8 x i1> %1205, %282
  store <8 x i1> %1206, ptr %runnable.mask, align 1
  store <8 x i1> %284, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true146:                         ; preds = %varying.coherent141
  store <8 x i1> %275, ptr %current.mask, align 1
  %1207 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %275)
  br i1 %1207, label %schedule.9, label %scheduler.loop

varying.coherent.false147:                        ; preds = %varying.coherent141
  store <8 x i1> %275, ptr %current.mask, align 1
  %1208 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %275)
  br i1 %1208, label %schedule.12, label %scheduler.loop

varying.divergent151:                             ; preds = %schedule.9
  %1209 = load i32, ptr %current.token, align 4
  %1210 = icmp ne i32 %1209, 0
  %1211 = sub i32 %1209, 1
  %1212 = select i1 %1210, i32 %1211, i32 0
  %1213 = load i8, ptr %frame.active, align 1
  %1214 = trunc i32 %1212 to i8
  %1215 = shl i8 1, %1214
  %1216 = and i8 %1213, %1215
  %1217 = icmp ne i8 %1216, 0
  %1218 = load <8 x i32>, ptr %frame.static.id, align 32
  %1219 = extractelement <8 x i32> %1218, i32 %1212
  %1220 = icmp eq i32 %1219, 4
  %1221 = and i1 %1217, %1220
  %1222 = and i1 %1210, %1221
  %1223 = xor i1 %1222, true
  %1224 = and i1 true, %1223
  %1225 = xor i8 %1213, -1
  %1226 = icmp ne i8 %1225, 0
  %1227 = xor i1 %1226, true
  %1228 = and i1 %1224, %1227
  br i1 %1228, label %convergence.overflow.trap153, label %convergence.overflow.resume154

varying.coherent152:                              ; preds = %schedule.9
  br i1 %340, label %varying.coherent.true157, label %varying.coherent.false158

convergence.overflow.trap153:                     ; preds = %varying.divergent151
  call void @llvm.trap()
  unreachable

convergence.overflow.resume154:                   ; preds = %varying.divergent151
  %1229 = call i8 @llvm.cttz.i8(i8 %1225, i1 false)
  %1230 = zext i8 %1229 to i32
  %1231 = select i1 %1226, i32 %1230, i32 0
  %1232 = trunc i32 %1231 to i8
  %1233 = shl i8 1, %1232
  %1234 = or i8 %1213, %1233
  %1235 = select i1 %1224, i8 %1234, i8 %1213
  store i8 %1235, ptr %frame.active, align 1
  %1236 = load <8 x i32>, ptr %frame.static.id, align 32
  %1237 = extractelement <8 x i32> %1236, i32 %1231
  %1238 = select i1 %1224, i32 4, i32 %1237
  %1239 = load <8 x i32>, ptr %frame.static.id, align 32
  %1240 = insertelement <8 x i32> %1239, i32 %1238, i32 %1231
  store <8 x i32> %1240, ptr %frame.static.id, align 32
  %1241 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1242 = extractelement <8 x i32> %1241, i32 %1231
  %1243 = select i1 %1224, i32 %1209, i32 %1242
  %1244 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1245 = insertelement <8 x i32> %1244, i32 %1243, i32 %1231
  store <8 x i32> %1245, ptr %frame.parent.token, align 32
  %1246 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1231
  %1247 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1231
  %1248 = load <8 x i1>, ptr %1246, align 1
  %1249 = load <8 x i1>, ptr %1247, align 1
  %1250 = select i1 %1224, <8 x i1> %288, <8 x i1> %1248
  store <8 x i1> %1250, ptr %1246, align 1
  %1251 = select i1 %1224, <8 x i1> zeroinitializer, <8 x i1> %1249
  store <8 x i1> %1251, ptr %1247, align 1
  %1252 = add i32 %1231, 1
  %1253 = select i1 %1222, i32 %1209, i32 %1252
  %1254 = select i1 true, i32 %1253, i32 %1209
  store i32 %1254, ptr %current.token, align 4
  %1255 = load <8 x float>, ptr %.slot34, align 32
  %1256 = select <8 x i1> %339, <8 x float> zeroinitializer, <8 x float> %1255
  store <8 x float> %1256, ptr %.slot34, align 32
  %1257 = load i32, ptr %current.token, align 4
  %1258 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %337)
  %1259 = load i32, ptr %ready.count, align 4
  %1260 = icmp uge i32 %1259, 8
  %1261 = and i1 %1258, %1260
  br i1 %1261, label %ready.overflow.trap155, label %ready.overflow.resume156

ready.overflow.trap155:                           ; preds = %convergence.overflow.resume154
  call void @llvm.trap()
  unreachable

ready.overflow.resume156:                         ; preds = %convergence.overflow.resume154
  %1262 = select i1 %1258, i32 %1259, i32 0
  %1263 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1262
  %1264 = load <8 x i1>, ptr %1263, align 1
  %1265 = select i1 %1258, <8 x i1> %337, <8 x i1> %1264
  store <8 x i1> %1265, ptr %1263, align 1
  %1266 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1262
  %1267 = load i32, ptr %1266, align 4
  %1268 = select i1 %1258, i32 10, i32 %1267
  store i32 %1268, ptr %1266, align 4
  %1269 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1262
  %1270 = load i32, ptr %1269, align 4
  %1271 = select i1 %1258, i32 %1257, i32 %1270
  store i32 %1271, ptr %1269, align 4
  %1272 = add i32 %1259, 1
  %1273 = select i1 %1258, i32 %1272, i32 %1259
  store i32 %1273, ptr %ready.count, align 4
  %1274 = load <8 x i1>, ptr %runnable.mask, align 1
  %1275 = or <8 x i1> %1274, %337
  store <8 x i1> %1275, ptr %runnable.mask, align 1
  store <8 x i1> %339, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true157:                         ; preds = %varying.coherent152
  store <8 x i1> %288, ptr %current.mask, align 1
  %1276 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %288)
  br i1 %1276, label %schedule.10, label %scheduler.loop

varying.coherent.false158:                        ; preds = %varying.coherent152
  %1277 = load <8 x float>, ptr %.slot34, align 32
  %1278 = select <8 x i1> %288, <8 x float> zeroinitializer, <8 x float> %1277
  store <8 x float> %1278, ptr %.slot34, align 32
  store <8 x i1> %288, ptr %current.mask, align 1
  %1279 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %288)
  br i1 %1279, label %schedule.11, label %scheduler.loop

convergence.cascade161:                           ; preds = %convergence.cascade161, %schedule.11
  %convergence.cascade.flow165 = phi <8 x i1> [ %362, %schedule.11 ], [ %1322, %convergence.cascade161 ]
  %convergence.cascade.depth166 = phi i32 [ 0, %schedule.11 ], [ %1323, %convergence.cascade161 ]
  %1280 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow165)
  %1281 = load i32, ptr %current.token, align 4
  %1282 = icmp ne i32 %1281, 0
  %1283 = and i1 %1280, %1282
  %1284 = sub i32 %1281, 1
  %1285 = select i1 %1283, i32 %1284, i32 0
  %1286 = load i8, ptr %frame.active, align 1
  %1287 = trunc i32 %1285 to i8
  %1288 = shl i8 1, %1287
  %1289 = and i8 %1286, %1288
  %1290 = icmp ne i8 %1289, 0
  %1291 = load <8 x i32>, ptr %frame.static.id, align 32
  %1292 = extractelement <8 x i32> %1291, i32 %1285
  %convergence.target.pointer167 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %1292
  %convergence.dynamic.target168 = load i32, ptr %convergence.target.pointer167, align 4
  %1293 = icmp eq i32 %convergence.dynamic.target168, 11
  %1294 = and i1 %1290, %1293
  %1295 = and i1 %1283, %1294
  %1296 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1285
  %1297 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1285
  %1298 = load <8 x i1>, ptr %1296, align 1
  %1299 = load <8 x i1>, ptr %1297, align 1
  %1300 = or <8 x i1> %1299, %convergence.cascade.flow165
  %1301 = load <8 x i1>, ptr %live.mask, align 1
  %1302 = and <8 x i1> %1298, %1301
  %1303 = icmp eq <8 x i1> %1300, %1302
  %1304 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1303)
  %1305 = and i1 %1295, %1304
  %1306 = select i1 %1305, <8 x i1> zeroinitializer, <8 x i1> %1300
  %1307 = select i1 %1295, <8 x i1> %1306, <8 x i1> %1299
  store <8 x i1> %1307, ptr %1297, align 1
  %1308 = select i1 %1305, <8 x i1> zeroinitializer, <8 x i1> %1298
  store <8 x i1> %1308, ptr %1296, align 1
  %1309 = trunc i32 %1285 to i8
  %1310 = shl i8 1, %1309
  %1311 = xor i8 %1310, -1
  %1312 = and i8 %1286, %1311
  %1313 = select i1 %1305, i8 %1312, i8 %1286
  store i8 %1313, ptr %frame.active, align 1
  %.splatinsert169 = insertelement <8 x i1> poison, i1 %1295, i64 0
  %.splat170 = shufflevector <8 x i1> %.splatinsert169, <8 x i1> poison, <8 x i32> zeroinitializer
  %1314 = and <8 x i1> %convergence.cascade.flow165, %.splat170
  %1315 = load <8 x i1>, ptr %runnable.mask, align 1
  %1316 = xor <8 x i1> %1314, splat (i1 true)
  %1317 = and <8 x i1> %1315, %1316
  store <8 x i1> %1317, ptr %runnable.mask, align 1
  %.splatinsert171 = insertelement <8 x i1> poison, i1 %1305, i64 0
  %.splat172 = shufflevector <8 x i1> %.splatinsert171, <8 x i1> poison, <8 x i32> zeroinitializer
  %1318 = select <8 x i1> %.splat172, <8 x i1> %1300, <8 x i1> zeroinitializer
  %1319 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1320 = extractelement <8 x i32> %1319, i32 %1285
  %1321 = select i1 %1305, i32 %1320, i32 %1281
  store i32 %1321, ptr %current.token, align 4
  %.splatinsert173 = insertelement <8 x i1> poison, i1 %1295, i64 0
  %.splat174 = shufflevector <8 x i1> %.splatinsert173, <8 x i1> poison, <8 x i32> zeroinitializer
  %1322 = select <8 x i1> %.splat174, <8 x i1> %1318, <8 x i1> %convergence.cascade.flow165
  %1323 = add i32 %convergence.cascade.depth166, 1
  %1324 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1322)
  %1325 = icmp ult i32 %1323, 8
  %1326 = and i1 %1324, %1325
  %1327 = and i1 %1295, %1326
  %convergence.parent.token175 = load i32, ptr %current.token, align 4
  %convergence.parent.present176 = icmp ne i32 %convergence.parent.token175, 0
  %1328 = and i1 %1327, %convergence.parent.present176
  br i1 %1328, label %convergence.cascade161, label %convergence.cascade.exit162

convergence.cascade.exit162:                      ; preds = %convergence.cascade161, %schedule.11
  %convergence.cascade.result177 = phi <8 x i1> [ %362, %schedule.11 ], [ %1322, %convergence.cascade161 ]
  %1329 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  br i1 %1329, label %convergence.target.11.ready, label %scheduler.loop

convergence.target.11.ready:                      ; preds = %convergence.cascade.exit162
  %1330 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  %1331 = bitcast <8 x i1> %convergence.cascade.result177 to i8
  %1332 = call i8 @llvm.cttz.i8(i8 %1331, i1 false)
  %1333 = zext i8 %1332 to i32
  %1334 = select i1 %1330, i32 %1333, i32 0
  %.spill.load178 = load float, ptr %.spill19, align 4
  %.splatinsert179 = insertelement <8 x float> poison, float %.spill.load178, i64 0
  %.splat180 = shufflevector <8 x float> %.splatinsert179, <8 x float> poison, <8 x i32> zeroinitializer
  %.state181 = load <8 x float>, ptr %.slot34, align 32
  %.spill.load182 = load volatile <8 x i1>, ptr %.spill32, align 1
  %1335 = select <8 x i1> %.spill.load182, <8 x float> %.state181, <8 x float> %.splat180
  %.spill.load183 = load volatile <8 x float>, ptr %.spill31, align 32
  %1336 = fadd <8 x float> %.spill.load183, %1335
  %tile_snapshot.spill.load184 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %1337 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load184, 0
  %1338 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load184, 1
  %.state185 = load <8 x i64>, ptr %.slot30, align 64
  %1339 = mul <8 x i64> %.state185, splat (i64 32)
  %1340 = add <8 x i64> %1338, %1339
  %1341 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1337, 0
  %1342 = insertvalue { <8 x ptr>, <8 x i64> } %1341, <8 x i64> %1340, 1
  %1343 = extractvalue { <8 x ptr>, <8 x i64> } %1342, 0
  %1344 = extractvalue { <8 x ptr>, <8 x i64> } %1342, 1
  %1345 = getelementptr i8, <8 x ptr> %1343, <8 x i64> %1344
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1336, <8 x ptr> %1345, i32 1, <8 x i1> %convergence.cascade.result177)
  %.state186 = load <8 x i64>, ptr %.slot30, align 64
  %1346 = add <8 x i64> %.state186, splat (i64 1)
  %1347 = load <8 x i64>, ptr %.slot30, align 64
  %1348 = select <8 x i1> %convergence.cascade.result177, <8 x i64> %1346, <8 x i64> %1347
  store <8 x i64> %1348, ptr %.slot30, align 64
  store <8 x i1> %convergence.cascade.result177, ptr %current.mask, align 1
  %1349 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result177)
  br i1 %1349, label %schedule.8, label %scheduler.loop

convergence.cascade187:                           ; preds = %convergence.cascade187, %schedule.12
  %convergence.cascade.flow191 = phi <8 x i1> [ %363, %schedule.12 ], [ %1392, %convergence.cascade187 ]
  %convergence.cascade.depth192 = phi i32 [ 0, %schedule.12 ], [ %1393, %convergence.cascade187 ]
  %1350 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow191)
  %1351 = load i32, ptr %current.token, align 4
  %1352 = icmp ne i32 %1351, 0
  %1353 = and i1 %1350, %1352
  %1354 = sub i32 %1351, 1
  %1355 = select i1 %1353, i32 %1354, i32 0
  %1356 = load i8, ptr %frame.active, align 1
  %1357 = trunc i32 %1355 to i8
  %1358 = shl i8 1, %1357
  %1359 = and i8 %1356, %1358
  %1360 = icmp ne i8 %1359, 0
  %1361 = load <8 x i32>, ptr %frame.static.id, align 32
  %1362 = extractelement <8 x i32> %1361, i32 %1355
  %convergence.target.pointer193 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %1362
  %convergence.dynamic.target194 = load i32, ptr %convergence.target.pointer193, align 4
  %1363 = icmp eq i32 %convergence.dynamic.target194, 12
  %1364 = and i1 %1360, %1363
  %1365 = and i1 %1353, %1364
  %1366 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1355
  %1367 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1355
  %1368 = load <8 x i1>, ptr %1366, align 1
  %1369 = load <8 x i1>, ptr %1367, align 1
  %1370 = or <8 x i1> %1369, %convergence.cascade.flow191
  %1371 = load <8 x i1>, ptr %live.mask, align 1
  %1372 = and <8 x i1> %1368, %1371
  %1373 = icmp eq <8 x i1> %1370, %1372
  %1374 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1373)
  %1375 = and i1 %1365, %1374
  %1376 = select i1 %1375, <8 x i1> zeroinitializer, <8 x i1> %1370
  %1377 = select i1 %1365, <8 x i1> %1376, <8 x i1> %1369
  store <8 x i1> %1377, ptr %1367, align 1
  %1378 = select i1 %1375, <8 x i1> zeroinitializer, <8 x i1> %1368
  store <8 x i1> %1378, ptr %1366, align 1
  %1379 = trunc i32 %1355 to i8
  %1380 = shl i8 1, %1379
  %1381 = xor i8 %1380, -1
  %1382 = and i8 %1356, %1381
  %1383 = select i1 %1375, i8 %1382, i8 %1356
  store i8 %1383, ptr %frame.active, align 1
  %.splatinsert195 = insertelement <8 x i1> poison, i1 %1365, i64 0
  %.splat196 = shufflevector <8 x i1> %.splatinsert195, <8 x i1> poison, <8 x i32> zeroinitializer
  %1384 = and <8 x i1> %convergence.cascade.flow191, %.splat196
  %1385 = load <8 x i1>, ptr %runnable.mask, align 1
  %1386 = xor <8 x i1> %1384, splat (i1 true)
  %1387 = and <8 x i1> %1385, %1386
  store <8 x i1> %1387, ptr %runnable.mask, align 1
  %.splatinsert197 = insertelement <8 x i1> poison, i1 %1375, i64 0
  %.splat198 = shufflevector <8 x i1> %.splatinsert197, <8 x i1> poison, <8 x i32> zeroinitializer
  %1388 = select <8 x i1> %.splat198, <8 x i1> %1370, <8 x i1> zeroinitializer
  %1389 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1390 = extractelement <8 x i32> %1389, i32 %1355
  %1391 = select i1 %1375, i32 %1390, i32 %1351
  store i32 %1391, ptr %current.token, align 4
  %.splatinsert199 = insertelement <8 x i1> poison, i1 %1365, i64 0
  %.splat200 = shufflevector <8 x i1> %.splatinsert199, <8 x i1> poison, <8 x i32> zeroinitializer
  %1392 = select <8 x i1> %.splat200, <8 x i1> %1388, <8 x i1> %convergence.cascade.flow191
  %1393 = add i32 %convergence.cascade.depth192, 1
  %1394 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1392)
  %1395 = icmp ult i32 %1393, 8
  %1396 = and i1 %1394, %1395
  %1397 = and i1 %1365, %1396
  %convergence.parent.token201 = load i32, ptr %current.token, align 4
  %convergence.parent.present202 = icmp ne i32 %convergence.parent.token201, 0
  %1398 = and i1 %1397, %convergence.parent.present202
  br i1 %1398, label %convergence.cascade187, label %convergence.cascade.exit188

convergence.cascade.exit188:                      ; preds = %convergence.cascade187, %schedule.12
  %convergence.cascade.result203 = phi <8 x i1> [ %363, %schedule.12 ], [ %1392, %convergence.cascade187 ]
  %1399 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result203)
  br i1 %1399, label %convergence.target.12.ready, label %scheduler.loop

convergence.target.12.ready:                      ; preds = %convergence.cascade.exit188
  %1400 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result203)
  %1401 = bitcast <8 x i1> %convergence.cascade.result203 to i8
  %1402 = call i8 @llvm.cttz.i8(i8 %1401, i1 false)
  %1403 = zext i8 %1402 to i32
  %1404 = select i1 %1400, i32 %1403, i32 0
  %1405 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1406 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1407 = extractvalue { <8 x ptr>, <8 x i64> } %1405, 0
  %1408 = select <8 x i1> %convergence.cascade.result203, <8 x ptr> %1406, <8 x ptr> %1407
  %1409 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %1410 = extractvalue { <8 x ptr>, <8 x i64> } %1405, 1
  %1411 = select <8 x i1> %convergence.cascade.result203, <8 x i64> %1409, <8 x i64> %1410
  %1412 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1408, 0
  %1413 = insertvalue { <8 x ptr>, <8 x i64> } %1412, <8 x i64> %1411, 1
  store volatile { <8 x ptr>, <8 x i64> } %1413, ptr %tile_snapshot.spill35, align 64
  %1414 = load <8 x i64>, ptr %.slot36, align 64
  %1415 = select <8 x i1> %convergence.cascade.result203, <8 x i64> zeroinitializer, <8 x i64> %1414
  store <8 x i64> %1415, ptr %.slot36, align 64
  store <8 x i1> %convergence.cascade.result203, ptr %current.mask, align 1
  %1416 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result203)
  br i1 %1416, label %schedule.13, label %scheduler.loop

varying.divergent205:                             ; preds = %schedule.13
  %1417 = load i32, ptr %current.token, align 4
  %1418 = icmp ne i32 %1417, 0
  %1419 = sub i32 %1417, 1
  %1420 = select i1 %1418, i32 %1419, i32 0
  %1421 = load i8, ptr %frame.active, align 1
  %1422 = trunc i32 %1420 to i8
  %1423 = shl i8 1, %1422
  %1424 = and i8 %1421, %1423
  %1425 = icmp ne i8 %1424, 0
  %1426 = load <8 x i32>, ptr %frame.static.id, align 32
  %1427 = extractelement <8 x i32> %1426, i32 %1420
  %1428 = icmp eq i32 %1427, 5
  %1429 = and i1 %1425, %1428
  %1430 = and i1 %1418, %1429
  %1431 = xor i1 %1430, true
  %1432 = and i1 true, %1431
  %1433 = xor i8 %1421, -1
  %1434 = icmp ne i8 %1433, 0
  %1435 = xor i1 %1434, true
  %1436 = and i1 %1432, %1435
  br i1 %1436, label %convergence.overflow.trap207, label %convergence.overflow.resume208

varying.coherent206:                              ; preds = %schedule.13
  br i1 %374, label %varying.coherent.true211, label %varying.coherent.false212

convergence.overflow.trap207:                     ; preds = %varying.divergent205
  call void @llvm.trap()
  unreachable

convergence.overflow.resume208:                   ; preds = %varying.divergent205
  %1437 = call i8 @llvm.cttz.i8(i8 %1433, i1 false)
  %1438 = zext i8 %1437 to i32
  %1439 = select i1 %1434, i32 %1438, i32 0
  %1440 = trunc i32 %1439 to i8
  %1441 = shl i8 1, %1440
  %1442 = or i8 %1421, %1441
  %1443 = select i1 %1432, i8 %1442, i8 %1421
  store i8 %1443, ptr %frame.active, align 1
  %1444 = load <8 x i32>, ptr %frame.static.id, align 32
  %1445 = extractelement <8 x i32> %1444, i32 %1439
  %1446 = select i1 %1432, i32 5, i32 %1445
  %1447 = load <8 x i32>, ptr %frame.static.id, align 32
  %1448 = insertelement <8 x i32> %1447, i32 %1446, i32 %1439
  store <8 x i32> %1448, ptr %frame.static.id, align 32
  %1449 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1450 = extractelement <8 x i32> %1449, i32 %1439
  %1451 = select i1 %1432, i32 %1417, i32 %1450
  %1452 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1453 = insertelement <8 x i32> %1452, i32 %1451, i32 %1439
  store <8 x i32> %1453, ptr %frame.parent.token, align 32
  %1454 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1439
  %1455 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1439
  %1456 = load <8 x i1>, ptr %1454, align 1
  %1457 = load <8 x i1>, ptr %1455, align 1
  %1458 = select i1 %1432, <8 x i1> %364, <8 x i1> %1456
  store <8 x i1> %1458, ptr %1454, align 1
  %1459 = select i1 %1432, <8 x i1> zeroinitializer, <8 x i1> %1457
  store <8 x i1> %1459, ptr %1455, align 1
  %1460 = add i32 %1439, 1
  %1461 = select i1 %1430, i32 %1417, i32 %1460
  %1462 = select i1 true, i32 %1461, i32 %1417
  store i32 %1462, ptr %current.token, align 4
  %1463 = load i32, ptr %current.token, align 4
  %1464 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %371)
  %1465 = load i32, ptr %ready.count, align 4
  %1466 = icmp uge i32 %1465, 8
  %1467 = and i1 %1464, %1466
  br i1 %1467, label %ready.overflow.trap209, label %ready.overflow.resume210

ready.overflow.trap209:                           ; preds = %convergence.overflow.resume208
  call void @llvm.trap()
  unreachable

ready.overflow.resume210:                         ; preds = %convergence.overflow.resume208
  %1468 = select i1 %1464, i32 %1465, i32 0
  %1469 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1468
  %1470 = load <8 x i1>, ptr %1469, align 1
  %1471 = select i1 %1464, <8 x i1> %371, <8 x i1> %1470
  store <8 x i1> %1471, ptr %1469, align 1
  %1472 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1468
  %1473 = load i32, ptr %1472, align 4
  %1474 = select i1 %1464, i32 14, i32 %1473
  store i32 %1474, ptr %1472, align 4
  %1475 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1468
  %1476 = load i32, ptr %1475, align 4
  %1477 = select i1 %1464, i32 %1463, i32 %1476
  store i32 %1477, ptr %1475, align 4
  %1478 = add i32 %1465, 1
  %1479 = select i1 %1464, i32 %1478, i32 %1465
  store i32 %1479, ptr %ready.count, align 4
  %1480 = load <8 x i1>, ptr %runnable.mask, align 1
  %1481 = or <8 x i1> %1480, %371
  store <8 x i1> %1481, ptr %runnable.mask, align 1
  store <8 x i1> %373, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true211:                         ; preds = %varying.coherent206
  store <8 x i1> %364, ptr %current.mask, align 1
  %1482 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %364)
  br i1 %1482, label %schedule.14, label %scheduler.loop

varying.coherent.false212:                        ; preds = %varying.coherent206
  store <8 x i1> %364, ptr %current.mask, align 1
  %1483 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %364)
  br i1 %1483, label %schedule.17, label %scheduler.loop

varying.divergent216:                             ; preds = %schedule.14
  %1484 = load i32, ptr %current.token, align 4
  %1485 = icmp ne i32 %1484, 0
  %1486 = sub i32 %1484, 1
  %1487 = select i1 %1485, i32 %1486, i32 0
  %1488 = load i8, ptr %frame.active, align 1
  %1489 = trunc i32 %1487 to i8
  %1490 = shl i8 1, %1489
  %1491 = and i8 %1488, %1490
  %1492 = icmp ne i8 %1491, 0
  %1493 = load <8 x i32>, ptr %frame.static.id, align 32
  %1494 = extractelement <8 x i32> %1493, i32 %1487
  %1495 = icmp eq i32 %1494, 6
  %1496 = and i1 %1492, %1495
  %1497 = and i1 %1485, %1496
  %1498 = xor i1 %1497, true
  %1499 = and i1 true, %1498
  %1500 = xor i8 %1488, -1
  %1501 = icmp ne i8 %1500, 0
  %1502 = xor i1 %1501, true
  %1503 = and i1 %1499, %1502
  br i1 %1503, label %convergence.overflow.trap218, label %convergence.overflow.resume219

varying.coherent217:                              ; preds = %schedule.14
  br i1 %429, label %varying.coherent.true222, label %varying.coherent.false223

convergence.overflow.trap218:                     ; preds = %varying.divergent216
  call void @llvm.trap()
  unreachable

convergence.overflow.resume219:                   ; preds = %varying.divergent216
  %1504 = call i8 @llvm.cttz.i8(i8 %1500, i1 false)
  %1505 = zext i8 %1504 to i32
  %1506 = select i1 %1501, i32 %1505, i32 0
  %1507 = trunc i32 %1506 to i8
  %1508 = shl i8 1, %1507
  %1509 = or i8 %1488, %1508
  %1510 = select i1 %1499, i8 %1509, i8 %1488
  store i8 %1510, ptr %frame.active, align 1
  %1511 = load <8 x i32>, ptr %frame.static.id, align 32
  %1512 = extractelement <8 x i32> %1511, i32 %1506
  %1513 = select i1 %1499, i32 6, i32 %1512
  %1514 = load <8 x i32>, ptr %frame.static.id, align 32
  %1515 = insertelement <8 x i32> %1514, i32 %1513, i32 %1506
  store <8 x i32> %1515, ptr %frame.static.id, align 32
  %1516 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1517 = extractelement <8 x i32> %1516, i32 %1506
  %1518 = select i1 %1499, i32 %1484, i32 %1517
  %1519 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1520 = insertelement <8 x i32> %1519, i32 %1518, i32 %1506
  store <8 x i32> %1520, ptr %frame.parent.token, align 32
  %1521 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1506
  %1522 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1506
  %1523 = load <8 x i1>, ptr %1521, align 1
  %1524 = load <8 x i1>, ptr %1522, align 1
  %1525 = select i1 %1499, <8 x i1> %377, <8 x i1> %1523
  store <8 x i1> %1525, ptr %1521, align 1
  %1526 = select i1 %1499, <8 x i1> zeroinitializer, <8 x i1> %1524
  store <8 x i1> %1526, ptr %1522, align 1
  %1527 = add i32 %1506, 1
  %1528 = select i1 %1497, i32 %1484, i32 %1527
  %1529 = select i1 true, i32 %1528, i32 %1484
  store i32 %1529, ptr %current.token, align 4
  %1530 = load <8 x float>, ptr %.slot40, align 32
  %1531 = select <8 x i1> %428, <8 x float> zeroinitializer, <8 x float> %1530
  store <8 x float> %1531, ptr %.slot40, align 32
  %1532 = load i32, ptr %current.token, align 4
  %1533 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %426)
  %1534 = load i32, ptr %ready.count, align 4
  %1535 = icmp uge i32 %1534, 8
  %1536 = and i1 %1533, %1535
  br i1 %1536, label %ready.overflow.trap220, label %ready.overflow.resume221

ready.overflow.trap220:                           ; preds = %convergence.overflow.resume219
  call void @llvm.trap()
  unreachable

ready.overflow.resume221:                         ; preds = %convergence.overflow.resume219
  %1537 = select i1 %1533, i32 %1534, i32 0
  %1538 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1537
  %1539 = load <8 x i1>, ptr %1538, align 1
  %1540 = select i1 %1533, <8 x i1> %426, <8 x i1> %1539
  store <8 x i1> %1540, ptr %1538, align 1
  %1541 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1537
  %1542 = load i32, ptr %1541, align 4
  %1543 = select i1 %1533, i32 15, i32 %1542
  store i32 %1543, ptr %1541, align 4
  %1544 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1537
  %1545 = load i32, ptr %1544, align 4
  %1546 = select i1 %1533, i32 %1532, i32 %1545
  store i32 %1546, ptr %1544, align 4
  %1547 = add i32 %1534, 1
  %1548 = select i1 %1533, i32 %1547, i32 %1534
  store i32 %1548, ptr %ready.count, align 4
  %1549 = load <8 x i1>, ptr %runnable.mask, align 1
  %1550 = or <8 x i1> %1549, %426
  store <8 x i1> %1550, ptr %runnable.mask, align 1
  store <8 x i1> %428, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true222:                         ; preds = %varying.coherent217
  store <8 x i1> %377, ptr %current.mask, align 1
  %1551 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %377)
  br i1 %1551, label %schedule.15, label %scheduler.loop

varying.coherent.false223:                        ; preds = %varying.coherent217
  %1552 = load <8 x float>, ptr %.slot40, align 32
  %1553 = select <8 x i1> %377, <8 x float> zeroinitializer, <8 x float> %1552
  store <8 x float> %1553, ptr %.slot40, align 32
  store <8 x i1> %377, ptr %current.mask, align 1
  %1554 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %377)
  br i1 %1554, label %schedule.16, label %scheduler.loop

convergence.cascade226:                           ; preds = %convergence.cascade226, %schedule.16
  %convergence.cascade.flow230 = phi <8 x i1> [ %451, %schedule.16 ], [ %1597, %convergence.cascade226 ]
  %convergence.cascade.depth231 = phi i32 [ 0, %schedule.16 ], [ %1598, %convergence.cascade226 ]
  %1555 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow230)
  %1556 = load i32, ptr %current.token, align 4
  %1557 = icmp ne i32 %1556, 0
  %1558 = and i1 %1555, %1557
  %1559 = sub i32 %1556, 1
  %1560 = select i1 %1558, i32 %1559, i32 0
  %1561 = load i8, ptr %frame.active, align 1
  %1562 = trunc i32 %1560 to i8
  %1563 = shl i8 1, %1562
  %1564 = and i8 %1561, %1563
  %1565 = icmp ne i8 %1564, 0
  %1566 = load <8 x i32>, ptr %frame.static.id, align 32
  %1567 = extractelement <8 x i32> %1566, i32 %1560
  %convergence.target.pointer232 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %1567
  %convergence.dynamic.target233 = load i32, ptr %convergence.target.pointer232, align 4
  %1568 = icmp eq i32 %convergence.dynamic.target233, 16
  %1569 = and i1 %1565, %1568
  %1570 = and i1 %1558, %1569
  %1571 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1560
  %1572 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1560
  %1573 = load <8 x i1>, ptr %1571, align 1
  %1574 = load <8 x i1>, ptr %1572, align 1
  %1575 = or <8 x i1> %1574, %convergence.cascade.flow230
  %1576 = load <8 x i1>, ptr %live.mask, align 1
  %1577 = and <8 x i1> %1573, %1576
  %1578 = icmp eq <8 x i1> %1575, %1577
  %1579 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1578)
  %1580 = and i1 %1570, %1579
  %1581 = select i1 %1580, <8 x i1> zeroinitializer, <8 x i1> %1575
  %1582 = select i1 %1570, <8 x i1> %1581, <8 x i1> %1574
  store <8 x i1> %1582, ptr %1572, align 1
  %1583 = select i1 %1580, <8 x i1> zeroinitializer, <8 x i1> %1573
  store <8 x i1> %1583, ptr %1571, align 1
  %1584 = trunc i32 %1560 to i8
  %1585 = shl i8 1, %1584
  %1586 = xor i8 %1585, -1
  %1587 = and i8 %1561, %1586
  %1588 = select i1 %1580, i8 %1587, i8 %1561
  store i8 %1588, ptr %frame.active, align 1
  %.splatinsert234 = insertelement <8 x i1> poison, i1 %1570, i64 0
  %.splat235 = shufflevector <8 x i1> %.splatinsert234, <8 x i1> poison, <8 x i32> zeroinitializer
  %1589 = and <8 x i1> %convergence.cascade.flow230, %.splat235
  %1590 = load <8 x i1>, ptr %runnable.mask, align 1
  %1591 = xor <8 x i1> %1589, splat (i1 true)
  %1592 = and <8 x i1> %1590, %1591
  store <8 x i1> %1592, ptr %runnable.mask, align 1
  %.splatinsert236 = insertelement <8 x i1> poison, i1 %1580, i64 0
  %.splat237 = shufflevector <8 x i1> %.splatinsert236, <8 x i1> poison, <8 x i32> zeroinitializer
  %1593 = select <8 x i1> %.splat237, <8 x i1> %1575, <8 x i1> zeroinitializer
  %1594 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1595 = extractelement <8 x i32> %1594, i32 %1560
  %1596 = select i1 %1580, i32 %1595, i32 %1556
  store i32 %1596, ptr %current.token, align 4
  %.splatinsert238 = insertelement <8 x i1> poison, i1 %1570, i64 0
  %.splat239 = shufflevector <8 x i1> %.splatinsert238, <8 x i1> poison, <8 x i32> zeroinitializer
  %1597 = select <8 x i1> %.splat239, <8 x i1> %1593, <8 x i1> %convergence.cascade.flow230
  %1598 = add i32 %convergence.cascade.depth231, 1
  %1599 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1597)
  %1600 = icmp ult i32 %1598, 8
  %1601 = and i1 %1599, %1600
  %1602 = and i1 %1570, %1601
  %convergence.parent.token240 = load i32, ptr %current.token, align 4
  %convergence.parent.present241 = icmp ne i32 %convergence.parent.token240, 0
  %1603 = and i1 %1602, %convergence.parent.present241
  br i1 %1603, label %convergence.cascade226, label %convergence.cascade.exit227

convergence.cascade.exit227:                      ; preds = %convergence.cascade226, %schedule.16
  %convergence.cascade.result242 = phi <8 x i1> [ %451, %schedule.16 ], [ %1597, %convergence.cascade226 ]
  %1604 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result242)
  br i1 %1604, label %convergence.target.16.ready, label %scheduler.loop

convergence.target.16.ready:                      ; preds = %convergence.cascade.exit227
  %1605 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result242)
  %1606 = bitcast <8 x i1> %convergence.cascade.result242 to i8
  %1607 = call i8 @llvm.cttz.i8(i8 %1606, i1 false)
  %1608 = zext i8 %1607 to i32
  %1609 = select i1 %1605, i32 %1608, i32 0
  %.spill.load243 = load float, ptr %.spill19, align 4
  %.splatinsert244 = insertelement <8 x float> poison, float %.spill.load243, i64 0
  %.splat245 = shufflevector <8 x float> %.splatinsert244, <8 x float> poison, <8 x i32> zeroinitializer
  %.state246 = load <8 x float>, ptr %.slot40, align 32
  %.spill.load247 = load volatile <8 x i1>, ptr %.spill38, align 1
  %1610 = select <8 x i1> %.spill.load247, <8 x float> %.state246, <8 x float> %.splat245
  %.spill.load248 = load volatile <8 x float>, ptr %.spill37, align 32
  %1611 = fadd <8 x float> %.spill.load248, %1610
  %tile_snapshot.spill.load249 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1612 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load249, 0
  %1613 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load249, 1
  %.state250 = load <8 x i64>, ptr %.slot36, align 64
  %1614 = mul <8 x i64> %.state250, splat (i64 32)
  %1615 = add <8 x i64> %1613, %1614
  %1616 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1612, 0
  %1617 = insertvalue { <8 x ptr>, <8 x i64> } %1616, <8 x i64> %1615, 1
  %1618 = extractvalue { <8 x ptr>, <8 x i64> } %1617, 0
  %1619 = extractvalue { <8 x ptr>, <8 x i64> } %1617, 1
  %1620 = getelementptr i8, <8 x ptr> %1618, <8 x i64> %1619
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1611, <8 x ptr> %1620, i32 1, <8 x i1> %convergence.cascade.result242)
  %.state251 = load <8 x i64>, ptr %.slot36, align 64
  %1621 = add <8 x i64> %.state251, splat (i64 1)
  %1622 = load <8 x i64>, ptr %.slot36, align 64
  %1623 = select <8 x i1> %convergence.cascade.result242, <8 x i64> %1621, <8 x i64> %1622
  store <8 x i64> %1623, ptr %.slot36, align 64
  store <8 x i1> %convergence.cascade.result242, ptr %current.mask, align 1
  %1624 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result242)
  br i1 %1624, label %schedule.13, label %scheduler.loop

convergence.cascade252:                           ; preds = %convergence.cascade252, %schedule.17
  %convergence.cascade.flow256 = phi <8 x i1> [ %452, %schedule.17 ], [ %1667, %convergence.cascade252 ]
  %convergence.cascade.depth257 = phi i32 [ 0, %schedule.17 ], [ %1668, %convergence.cascade252 ]
  %1625 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow256)
  %1626 = load i32, ptr %current.token, align 4
  %1627 = icmp ne i32 %1626, 0
  %1628 = and i1 %1625, %1627
  %1629 = sub i32 %1626, 1
  %1630 = select i1 %1628, i32 %1629, i32 0
  %1631 = load i8, ptr %frame.active, align 1
  %1632 = trunc i32 %1630 to i8
  %1633 = shl i8 1, %1632
  %1634 = and i8 %1631, %1633
  %1635 = icmp ne i8 %1634, 0
  %1636 = load <8 x i32>, ptr %frame.static.id, align 32
  %1637 = extractelement <8 x i32> %1636, i32 %1630
  %convergence.target.pointer258 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %1637
  %convergence.dynamic.target259 = load i32, ptr %convergence.target.pointer258, align 4
  %1638 = icmp eq i32 %convergence.dynamic.target259, 17
  %1639 = and i1 %1635, %1638
  %1640 = and i1 %1628, %1639
  %1641 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1630
  %1642 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1630
  %1643 = load <8 x i1>, ptr %1641, align 1
  %1644 = load <8 x i1>, ptr %1642, align 1
  %1645 = or <8 x i1> %1644, %convergence.cascade.flow256
  %1646 = load <8 x i1>, ptr %live.mask, align 1
  %1647 = and <8 x i1> %1643, %1646
  %1648 = icmp eq <8 x i1> %1645, %1647
  %1649 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1648)
  %1650 = and i1 %1640, %1649
  %1651 = select i1 %1650, <8 x i1> zeroinitializer, <8 x i1> %1645
  %1652 = select i1 %1640, <8 x i1> %1651, <8 x i1> %1644
  store <8 x i1> %1652, ptr %1642, align 1
  %1653 = select i1 %1650, <8 x i1> zeroinitializer, <8 x i1> %1643
  store <8 x i1> %1653, ptr %1641, align 1
  %1654 = trunc i32 %1630 to i8
  %1655 = shl i8 1, %1654
  %1656 = xor i8 %1655, -1
  %1657 = and i8 %1631, %1656
  %1658 = select i1 %1650, i8 %1657, i8 %1631
  store i8 %1658, ptr %frame.active, align 1
  %.splatinsert260 = insertelement <8 x i1> poison, i1 %1640, i64 0
  %.splat261 = shufflevector <8 x i1> %.splatinsert260, <8 x i1> poison, <8 x i32> zeroinitializer
  %1659 = and <8 x i1> %convergence.cascade.flow256, %.splat261
  %1660 = load <8 x i1>, ptr %runnable.mask, align 1
  %1661 = xor <8 x i1> %1659, splat (i1 true)
  %1662 = and <8 x i1> %1660, %1661
  store <8 x i1> %1662, ptr %runnable.mask, align 1
  %.splatinsert262 = insertelement <8 x i1> poison, i1 %1650, i64 0
  %.splat263 = shufflevector <8 x i1> %.splatinsert262, <8 x i1> poison, <8 x i32> zeroinitializer
  %1663 = select <8 x i1> %.splat263, <8 x i1> %1645, <8 x i1> zeroinitializer
  %1664 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1665 = extractelement <8 x i32> %1664, i32 %1630
  %1666 = select i1 %1650, i32 %1665, i32 %1626
  store i32 %1666, ptr %current.token, align 4
  %.splatinsert264 = insertelement <8 x i1> poison, i1 %1640, i64 0
  %.splat265 = shufflevector <8 x i1> %.splatinsert264, <8 x i1> poison, <8 x i32> zeroinitializer
  %1667 = select <8 x i1> %.splat265, <8 x i1> %1663, <8 x i1> %convergence.cascade.flow256
  %1668 = add i32 %convergence.cascade.depth257, 1
  %1669 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1667)
  %1670 = icmp ult i32 %1668, 8
  %1671 = and i1 %1669, %1670
  %1672 = and i1 %1640, %1671
  %convergence.parent.token266 = load i32, ptr %current.token, align 4
  %convergence.parent.present267 = icmp ne i32 %convergence.parent.token266, 0
  %1673 = and i1 %1672, %convergence.parent.present267
  br i1 %1673, label %convergence.cascade252, label %convergence.cascade.exit253

convergence.cascade.exit253:                      ; preds = %convergence.cascade252, %schedule.17
  %convergence.cascade.result268 = phi <8 x i1> [ %452, %schedule.17 ], [ %1667, %convergence.cascade252 ]
  %1674 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result268)
  br i1 %1674, label %convergence.target.17.ready, label %scheduler.loop

convergence.target.17.ready:                      ; preds = %convergence.cascade.exit253
  %1675 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result268)
  %1676 = bitcast <8 x i1> %convergence.cascade.result268 to i8
  %1677 = call i8 @llvm.cttz.i8(i8 %1676, i1 false)
  %1678 = zext i8 %1677 to i32
  %1679 = select i1 %1675, i32 %1678, i32 0
  %1680 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill41, align 64
  %1681 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1682 = extractvalue { <8 x ptr>, <8 x i64> } %1680, 0
  %1683 = select <8 x i1> %convergence.cascade.result268, <8 x ptr> %1681, <8 x ptr> %1682
  %1684 = extractvalue { <8 x ptr>, <8 x i64> } %9, 1
  %1685 = extractvalue { <8 x ptr>, <8 x i64> } %1680, 1
  %1686 = select <8 x i1> %convergence.cascade.result268, <8 x i64> %1684, <8 x i64> %1685
  %1687 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1683, 0
  %1688 = insertvalue { <8 x ptr>, <8 x i64> } %1687, <8 x i64> %1686, 1
  store volatile { <8 x ptr>, <8 x i64> } %1688, ptr %tile_snapshot.spill41, align 64
  %1689 = load <8 x i64>, ptr %.slot42, align 64
  %1690 = select <8 x i1> %convergence.cascade.result268, <8 x i64> zeroinitializer, <8 x i64> %1689
  store <8 x i64> %1690, ptr %.slot42, align 64
  store <8 x i1> %convergence.cascade.result268, ptr %current.mask, align 1
  %1691 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result268)
  br i1 %1691, label %schedule.18, label %scheduler.loop

varying.divergent270:                             ; preds = %schedule.18
  %1692 = load i32, ptr %current.token, align 4
  %1693 = icmp ne i32 %1692, 0
  %1694 = sub i32 %1692, 1
  %1695 = select i1 %1693, i32 %1694, i32 0
  %1696 = load i8, ptr %frame.active, align 1
  %1697 = trunc i32 %1695 to i8
  %1698 = shl i8 1, %1697
  %1699 = and i8 %1696, %1698
  %1700 = icmp ne i8 %1699, 0
  %1701 = load <8 x i32>, ptr %frame.static.id, align 32
  %1702 = extractelement <8 x i32> %1701, i32 %1695
  %1703 = icmp eq i32 %1702, 7
  %1704 = and i1 %1700, %1703
  %1705 = and i1 %1693, %1704
  %1706 = xor i1 %1705, true
  %1707 = and i1 true, %1706
  %1708 = xor i8 %1696, -1
  %1709 = icmp ne i8 %1708, 0
  %1710 = xor i1 %1709, true
  %1711 = and i1 %1707, %1710
  br i1 %1711, label %convergence.overflow.trap272, label %convergence.overflow.resume273

varying.coherent271:                              ; preds = %schedule.18
  br i1 %463, label %varying.coherent.true276, label %varying.coherent.false277

convergence.overflow.trap272:                     ; preds = %varying.divergent270
  call void @llvm.trap()
  unreachable

convergence.overflow.resume273:                   ; preds = %varying.divergent270
  %1712 = call i8 @llvm.cttz.i8(i8 %1708, i1 false)
  %1713 = zext i8 %1712 to i32
  %1714 = select i1 %1709, i32 %1713, i32 0
  %1715 = trunc i32 %1714 to i8
  %1716 = shl i8 1, %1715
  %1717 = or i8 %1696, %1716
  %1718 = select i1 %1707, i8 %1717, i8 %1696
  store i8 %1718, ptr %frame.active, align 1
  %1719 = load <8 x i32>, ptr %frame.static.id, align 32
  %1720 = extractelement <8 x i32> %1719, i32 %1714
  %1721 = select i1 %1707, i32 7, i32 %1720
  %1722 = load <8 x i32>, ptr %frame.static.id, align 32
  %1723 = insertelement <8 x i32> %1722, i32 %1721, i32 %1714
  store <8 x i32> %1723, ptr %frame.static.id, align 32
  %1724 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1725 = extractelement <8 x i32> %1724, i32 %1714
  %1726 = select i1 %1707, i32 %1692, i32 %1725
  %1727 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1728 = insertelement <8 x i32> %1727, i32 %1726, i32 %1714
  store <8 x i32> %1728, ptr %frame.parent.token, align 32
  %1729 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1714
  %1730 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1714
  %1731 = load <8 x i1>, ptr %1729, align 1
  %1732 = load <8 x i1>, ptr %1730, align 1
  %1733 = select i1 %1707, <8 x i1> %453, <8 x i1> %1731
  store <8 x i1> %1733, ptr %1729, align 1
  %1734 = select i1 %1707, <8 x i1> zeroinitializer, <8 x i1> %1732
  store <8 x i1> %1734, ptr %1730, align 1
  %1735 = add i32 %1714, 1
  %1736 = select i1 %1705, i32 %1692, i32 %1735
  %1737 = select i1 true, i32 %1736, i32 %1692
  store i32 %1737, ptr %current.token, align 4
  %1738 = load i32, ptr %current.token, align 4
  %1739 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %460)
  %1740 = load i32, ptr %ready.count, align 4
  %1741 = icmp uge i32 %1740, 8
  %1742 = and i1 %1739, %1741
  br i1 %1742, label %ready.overflow.trap274, label %ready.overflow.resume275

ready.overflow.trap274:                           ; preds = %convergence.overflow.resume273
  call void @llvm.trap()
  unreachable

ready.overflow.resume275:                         ; preds = %convergence.overflow.resume273
  %1743 = select i1 %1739, i32 %1740, i32 0
  %1744 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1743
  %1745 = load <8 x i1>, ptr %1744, align 1
  %1746 = select i1 %1739, <8 x i1> %460, <8 x i1> %1745
  store <8 x i1> %1746, ptr %1744, align 1
  %1747 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1743
  %1748 = load i32, ptr %1747, align 4
  %1749 = select i1 %1739, i32 19, i32 %1748
  store i32 %1749, ptr %1747, align 4
  %1750 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1743
  %1751 = load i32, ptr %1750, align 4
  %1752 = select i1 %1739, i32 %1738, i32 %1751
  store i32 %1752, ptr %1750, align 4
  %1753 = add i32 %1740, 1
  %1754 = select i1 %1739, i32 %1753, i32 %1740
  store i32 %1754, ptr %ready.count, align 4
  %1755 = load <8 x i1>, ptr %runnable.mask, align 1
  %1756 = or <8 x i1> %1755, %460
  store <8 x i1> %1756, ptr %runnable.mask, align 1
  store <8 x i1> %462, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true276:                         ; preds = %varying.coherent271
  store <8 x i1> %453, ptr %current.mask, align 1
  %1757 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %453)
  br i1 %1757, label %schedule.19, label %scheduler.loop

varying.coherent.false277:                        ; preds = %varying.coherent271
  store <8 x i1> %453, ptr %current.mask, align 1
  %1758 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %453)
  br i1 %1758, label %schedule.22, label %scheduler.loop

varying.divergent281:                             ; preds = %schedule.19
  %1759 = load i32, ptr %current.token, align 4
  %1760 = icmp ne i32 %1759, 0
  %1761 = sub i32 %1759, 1
  %1762 = select i1 %1760, i32 %1761, i32 0
  %1763 = load i8, ptr %frame.active, align 1
  %1764 = trunc i32 %1762 to i8
  %1765 = shl i8 1, %1764
  %1766 = and i8 %1763, %1765
  %1767 = icmp ne i8 %1766, 0
  %1768 = load <8 x i32>, ptr %frame.static.id, align 32
  %1769 = extractelement <8 x i32> %1768, i32 %1762
  %1770 = icmp eq i32 %1769, 8
  %1771 = and i1 %1767, %1770
  %1772 = and i1 %1760, %1771
  %1773 = xor i1 %1772, true
  %1774 = and i1 true, %1773
  %1775 = xor i8 %1763, -1
  %1776 = icmp ne i8 %1775, 0
  %1777 = xor i1 %1776, true
  %1778 = and i1 %1774, %1777
  br i1 %1778, label %convergence.overflow.trap283, label %convergence.overflow.resume284

varying.coherent282:                              ; preds = %schedule.19
  br i1 %518, label %varying.coherent.true287, label %varying.coherent.false288

convergence.overflow.trap283:                     ; preds = %varying.divergent281
  call void @llvm.trap()
  unreachable

convergence.overflow.resume284:                   ; preds = %varying.divergent281
  %1779 = call i8 @llvm.cttz.i8(i8 %1775, i1 false)
  %1780 = zext i8 %1779 to i32
  %1781 = select i1 %1776, i32 %1780, i32 0
  %1782 = trunc i32 %1781 to i8
  %1783 = shl i8 1, %1782
  %1784 = or i8 %1763, %1783
  %1785 = select i1 %1774, i8 %1784, i8 %1763
  store i8 %1785, ptr %frame.active, align 1
  %1786 = load <8 x i32>, ptr %frame.static.id, align 32
  %1787 = extractelement <8 x i32> %1786, i32 %1781
  %1788 = select i1 %1774, i32 8, i32 %1787
  %1789 = load <8 x i32>, ptr %frame.static.id, align 32
  %1790 = insertelement <8 x i32> %1789, i32 %1788, i32 %1781
  store <8 x i32> %1790, ptr %frame.static.id, align 32
  %1791 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1792 = extractelement <8 x i32> %1791, i32 %1781
  %1793 = select i1 %1774, i32 %1759, i32 %1792
  %1794 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1795 = insertelement <8 x i32> %1794, i32 %1793, i32 %1781
  store <8 x i32> %1795, ptr %frame.parent.token, align 32
  %1796 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1781
  %1797 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1781
  %1798 = load <8 x i1>, ptr %1796, align 1
  %1799 = load <8 x i1>, ptr %1797, align 1
  %1800 = select i1 %1774, <8 x i1> %466, <8 x i1> %1798
  store <8 x i1> %1800, ptr %1796, align 1
  %1801 = select i1 %1774, <8 x i1> zeroinitializer, <8 x i1> %1799
  store <8 x i1> %1801, ptr %1797, align 1
  %1802 = add i32 %1781, 1
  %1803 = select i1 %1772, i32 %1759, i32 %1802
  %1804 = select i1 true, i32 %1803, i32 %1759
  store i32 %1804, ptr %current.token, align 4
  %1805 = load <8 x float>, ptr %.slot46, align 32
  %1806 = select <8 x i1> %517, <8 x float> zeroinitializer, <8 x float> %1805
  store <8 x float> %1806, ptr %.slot46, align 32
  %1807 = load i32, ptr %current.token, align 4
  %1808 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %515)
  %1809 = load i32, ptr %ready.count, align 4
  %1810 = icmp uge i32 %1809, 8
  %1811 = and i1 %1808, %1810
  br i1 %1811, label %ready.overflow.trap285, label %ready.overflow.resume286

ready.overflow.trap285:                           ; preds = %convergence.overflow.resume284
  call void @llvm.trap()
  unreachable

ready.overflow.resume286:                         ; preds = %convergence.overflow.resume284
  %1812 = select i1 %1808, i32 %1809, i32 0
  %1813 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1812
  %1814 = load <8 x i1>, ptr %1813, align 1
  %1815 = select i1 %1808, <8 x i1> %515, <8 x i1> %1814
  store <8 x i1> %1815, ptr %1813, align 1
  %1816 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1812
  %1817 = load i32, ptr %1816, align 4
  %1818 = select i1 %1808, i32 20, i32 %1817
  store i32 %1818, ptr %1816, align 4
  %1819 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1812
  %1820 = load i32, ptr %1819, align 4
  %1821 = select i1 %1808, i32 %1807, i32 %1820
  store i32 %1821, ptr %1819, align 4
  %1822 = add i32 %1809, 1
  %1823 = select i1 %1808, i32 %1822, i32 %1809
  store i32 %1823, ptr %ready.count, align 4
  %1824 = load <8 x i1>, ptr %runnable.mask, align 1
  %1825 = or <8 x i1> %1824, %515
  store <8 x i1> %1825, ptr %runnable.mask, align 1
  store <8 x i1> %517, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true287:                         ; preds = %varying.coherent282
  store <8 x i1> %466, ptr %current.mask, align 1
  %1826 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %466)
  br i1 %1826, label %schedule.20, label %scheduler.loop

varying.coherent.false288:                        ; preds = %varying.coherent282
  %1827 = load <8 x float>, ptr %.slot46, align 32
  %1828 = select <8 x i1> %466, <8 x float> zeroinitializer, <8 x float> %1827
  store <8 x float> %1828, ptr %.slot46, align 32
  store <8 x i1> %466, ptr %current.mask, align 1
  %1829 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %466)
  br i1 %1829, label %schedule.21, label %scheduler.loop

convergence.cascade291:                           ; preds = %convergence.cascade291, %schedule.21
  %convergence.cascade.flow295 = phi <8 x i1> [ %540, %schedule.21 ], [ %1872, %convergence.cascade291 ]
  %convergence.cascade.depth296 = phi i32 [ 0, %schedule.21 ], [ %1873, %convergence.cascade291 ]
  %1830 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow295)
  %1831 = load i32, ptr %current.token, align 4
  %1832 = icmp ne i32 %1831, 0
  %1833 = and i1 %1830, %1832
  %1834 = sub i32 %1831, 1
  %1835 = select i1 %1833, i32 %1834, i32 0
  %1836 = load i8, ptr %frame.active, align 1
  %1837 = trunc i32 %1835 to i8
  %1838 = shl i8 1, %1837
  %1839 = and i8 %1836, %1838
  %1840 = icmp ne i8 %1839, 0
  %1841 = load <8 x i32>, ptr %frame.static.id, align 32
  %1842 = extractelement <8 x i32> %1841, i32 %1835
  %convergence.target.pointer297 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %1842
  %convergence.dynamic.target298 = load i32, ptr %convergence.target.pointer297, align 4
  %1843 = icmp eq i32 %convergence.dynamic.target298, 21
  %1844 = and i1 %1840, %1843
  %1845 = and i1 %1833, %1844
  %1846 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1835
  %1847 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1835
  %1848 = load <8 x i1>, ptr %1846, align 1
  %1849 = load <8 x i1>, ptr %1847, align 1
  %1850 = or <8 x i1> %1849, %convergence.cascade.flow295
  %1851 = load <8 x i1>, ptr %live.mask, align 1
  %1852 = and <8 x i1> %1848, %1851
  %1853 = icmp eq <8 x i1> %1850, %1852
  %1854 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1853)
  %1855 = and i1 %1845, %1854
  %1856 = select i1 %1855, <8 x i1> zeroinitializer, <8 x i1> %1850
  %1857 = select i1 %1845, <8 x i1> %1856, <8 x i1> %1849
  store <8 x i1> %1857, ptr %1847, align 1
  %1858 = select i1 %1855, <8 x i1> zeroinitializer, <8 x i1> %1848
  store <8 x i1> %1858, ptr %1846, align 1
  %1859 = trunc i32 %1835 to i8
  %1860 = shl i8 1, %1859
  %1861 = xor i8 %1860, -1
  %1862 = and i8 %1836, %1861
  %1863 = select i1 %1855, i8 %1862, i8 %1836
  store i8 %1863, ptr %frame.active, align 1
  %.splatinsert299 = insertelement <8 x i1> poison, i1 %1845, i64 0
  %.splat300 = shufflevector <8 x i1> %.splatinsert299, <8 x i1> poison, <8 x i32> zeroinitializer
  %1864 = and <8 x i1> %convergence.cascade.flow295, %.splat300
  %1865 = load <8 x i1>, ptr %runnable.mask, align 1
  %1866 = xor <8 x i1> %1864, splat (i1 true)
  %1867 = and <8 x i1> %1865, %1866
  store <8 x i1> %1867, ptr %runnable.mask, align 1
  %.splatinsert301 = insertelement <8 x i1> poison, i1 %1855, i64 0
  %.splat302 = shufflevector <8 x i1> %.splatinsert301, <8 x i1> poison, <8 x i32> zeroinitializer
  %1868 = select <8 x i1> %.splat302, <8 x i1> %1850, <8 x i1> zeroinitializer
  %1869 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1870 = extractelement <8 x i32> %1869, i32 %1835
  %1871 = select i1 %1855, i32 %1870, i32 %1831
  store i32 %1871, ptr %current.token, align 4
  %.splatinsert303 = insertelement <8 x i1> poison, i1 %1845, i64 0
  %.splat304 = shufflevector <8 x i1> %.splatinsert303, <8 x i1> poison, <8 x i32> zeroinitializer
  %1872 = select <8 x i1> %.splat304, <8 x i1> %1868, <8 x i1> %convergence.cascade.flow295
  %1873 = add i32 %convergence.cascade.depth296, 1
  %1874 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1872)
  %1875 = icmp ult i32 %1873, 8
  %1876 = and i1 %1874, %1875
  %1877 = and i1 %1845, %1876
  %convergence.parent.token305 = load i32, ptr %current.token, align 4
  %convergence.parent.present306 = icmp ne i32 %convergence.parent.token305, 0
  %1878 = and i1 %1877, %convergence.parent.present306
  br i1 %1878, label %convergence.cascade291, label %convergence.cascade.exit292

convergence.cascade.exit292:                      ; preds = %convergence.cascade291, %schedule.21
  %convergence.cascade.result307 = phi <8 x i1> [ %540, %schedule.21 ], [ %1872, %convergence.cascade291 ]
  %1879 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result307)
  br i1 %1879, label %convergence.target.21.ready, label %scheduler.loop

convergence.target.21.ready:                      ; preds = %convergence.cascade.exit292
  %1880 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result307)
  %1881 = bitcast <8 x i1> %convergence.cascade.result307 to i8
  %1882 = call i8 @llvm.cttz.i8(i8 %1881, i1 false)
  %1883 = zext i8 %1882 to i32
  %1884 = select i1 %1880, i32 %1883, i32 0
  %.spill.load308 = load float, ptr %.spill19, align 4
  %.splatinsert309 = insertelement <8 x float> poison, float %.spill.load308, i64 0
  %.splat310 = shufflevector <8 x float> %.splatinsert309, <8 x float> poison, <8 x i32> zeroinitializer
  %.state311 = load <8 x float>, ptr %.slot46, align 32
  %.spill.load312 = load volatile <8 x i1>, ptr %.spill44, align 1
  %1885 = select <8 x i1> %.spill.load312, <8 x float> %.state311, <8 x float> %.splat310
  %.spill.load313 = load volatile <8 x float>, ptr %.spill43, align 32
  %1886 = fadd <8 x float> %.spill.load313, %1885
  %tile_snapshot.spill.load314 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill41, align 64
  %1887 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load314, 0
  %1888 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load314, 1
  %.state315 = load <8 x i64>, ptr %.slot42, align 64
  %1889 = mul <8 x i64> %.state315, splat (i64 32)
  %1890 = add <8 x i64> %1888, %1889
  %1891 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1887, 0
  %1892 = insertvalue { <8 x ptr>, <8 x i64> } %1891, <8 x i64> %1890, 1
  %1893 = extractvalue { <8 x ptr>, <8 x i64> } %1892, 0
  %1894 = extractvalue { <8 x ptr>, <8 x i64> } %1892, 1
  %1895 = getelementptr i8, <8 x ptr> %1893, <8 x i64> %1894
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1886, <8 x ptr> %1895, i32 1, <8 x i1> %convergence.cascade.result307)
  %.state316 = load <8 x i64>, ptr %.slot42, align 64
  %1896 = add <8 x i64> %.state316, splat (i64 1)
  %1897 = load <8 x i64>, ptr %.slot42, align 64
  %1898 = select <8 x i1> %convergence.cascade.result307, <8 x i64> %1896, <8 x i64> %1897
  store <8 x i64> %1898, ptr %.slot42, align 64
  store <8 x i1> %convergence.cascade.result307, ptr %current.mask, align 1
  %1899 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result307)
  br i1 %1899, label %schedule.18, label %scheduler.loop

convergence.cascade317:                           ; preds = %convergence.cascade317, %schedule.22
  %convergence.cascade.flow321 = phi <8 x i1> [ %541, %schedule.22 ], [ %1942, %convergence.cascade317 ]
  %convergence.cascade.depth322 = phi i32 [ 0, %schedule.22 ], [ %1943, %convergence.cascade317 ]
  %1900 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow321)
  %1901 = load i32, ptr %current.token, align 4
  %1902 = icmp ne i32 %1901, 0
  %1903 = and i1 %1900, %1902
  %1904 = sub i32 %1901, 1
  %1905 = select i1 %1903, i32 %1904, i32 0
  %1906 = load i8, ptr %frame.active, align 1
  %1907 = trunc i32 %1905 to i8
  %1908 = shl i8 1, %1907
  %1909 = and i8 %1906, %1908
  %1910 = icmp ne i8 %1909, 0
  %1911 = load <8 x i32>, ptr %frame.static.id, align 32
  %1912 = extractelement <8 x i32> %1911, i32 %1905
  %convergence.target.pointer323 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %1912
  %convergence.dynamic.target324 = load i32, ptr %convergence.target.pointer323, align 4
  %1913 = icmp eq i32 %convergence.dynamic.target324, 22
  %1914 = and i1 %1910, %1913
  %1915 = and i1 %1903, %1914
  %1916 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1905
  %1917 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1905
  %1918 = load <8 x i1>, ptr %1916, align 1
  %1919 = load <8 x i1>, ptr %1917, align 1
  %1920 = or <8 x i1> %1919, %convergence.cascade.flow321
  %1921 = load <8 x i1>, ptr %live.mask, align 1
  %1922 = and <8 x i1> %1918, %1921
  %1923 = icmp eq <8 x i1> %1920, %1922
  %1924 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1923)
  %1925 = and i1 %1915, %1924
  %1926 = select i1 %1925, <8 x i1> zeroinitializer, <8 x i1> %1920
  %1927 = select i1 %1915, <8 x i1> %1926, <8 x i1> %1919
  store <8 x i1> %1927, ptr %1917, align 1
  %1928 = select i1 %1925, <8 x i1> zeroinitializer, <8 x i1> %1918
  store <8 x i1> %1928, ptr %1916, align 1
  %1929 = trunc i32 %1905 to i8
  %1930 = shl i8 1, %1929
  %1931 = xor i8 %1930, -1
  %1932 = and i8 %1906, %1931
  %1933 = select i1 %1925, i8 %1932, i8 %1906
  store i8 %1933, ptr %frame.active, align 1
  %.splatinsert325 = insertelement <8 x i1> poison, i1 %1915, i64 0
  %.splat326 = shufflevector <8 x i1> %.splatinsert325, <8 x i1> poison, <8 x i32> zeroinitializer
  %1934 = and <8 x i1> %convergence.cascade.flow321, %.splat326
  %1935 = load <8 x i1>, ptr %runnable.mask, align 1
  %1936 = xor <8 x i1> %1934, splat (i1 true)
  %1937 = and <8 x i1> %1935, %1936
  store <8 x i1> %1937, ptr %runnable.mask, align 1
  %.splatinsert327 = insertelement <8 x i1> poison, i1 %1925, i64 0
  %.splat328 = shufflevector <8 x i1> %.splatinsert327, <8 x i1> poison, <8 x i32> zeroinitializer
  %1938 = select <8 x i1> %.splat328, <8 x i1> %1920, <8 x i1> zeroinitializer
  %1939 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1940 = extractelement <8 x i32> %1939, i32 %1905
  %1941 = select i1 %1925, i32 %1940, i32 %1901
  store i32 %1941, ptr %current.token, align 4
  %.splatinsert329 = insertelement <8 x i1> poison, i1 %1915, i64 0
  %.splat330 = shufflevector <8 x i1> %.splatinsert329, <8 x i1> poison, <8 x i32> zeroinitializer
  %1942 = select <8 x i1> %.splat330, <8 x i1> %1938, <8 x i1> %convergence.cascade.flow321
  %1943 = add i32 %convergence.cascade.depth322, 1
  %1944 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1942)
  %1945 = icmp ult i32 %1943, 8
  %1946 = and i1 %1944, %1945
  %1947 = and i1 %1915, %1946
  %convergence.parent.token331 = load i32, ptr %current.token, align 4
  %convergence.parent.present332 = icmp ne i32 %convergence.parent.token331, 0
  %1948 = and i1 %1947, %convergence.parent.present332
  br i1 %1948, label %convergence.cascade317, label %convergence.cascade.exit318

convergence.cascade.exit318:                      ; preds = %convergence.cascade317, %schedule.22
  %convergence.cascade.result333 = phi <8 x i1> [ %541, %schedule.22 ], [ %1942, %convergence.cascade317 ]
  %1949 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result333)
  br i1 %1949, label %convergence.target.22.ready, label %scheduler.loop

convergence.target.22.ready:                      ; preds = %convergence.cascade.exit318
  %1950 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result333)
  %1951 = bitcast <8 x i1> %convergence.cascade.result333 to i8
  %1952 = call i8 @llvm.cttz.i8(i8 %1951, i1 false)
  %1953 = zext i8 %1952 to i32
  %1954 = select i1 %1950, i32 %1953, i32 0
  %1955 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill47, align 64
  %1956 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1957 = extractvalue { <8 x ptr>, <8 x i64> } %1955, 0
  %1958 = select <8 x i1> %convergence.cascade.result333, <8 x ptr> %1956, <8 x ptr> %1957
  %1959 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %1960 = extractvalue { <8 x ptr>, <8 x i64> } %1955, 1
  %1961 = select <8 x i1> %convergence.cascade.result333, <8 x i64> %1959, <8 x i64> %1960
  %1962 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1958, 0
  %1963 = insertvalue { <8 x ptr>, <8 x i64> } %1962, <8 x i64> %1961, 1
  store volatile { <8 x ptr>, <8 x i64> } %1963, ptr %tile_snapshot.spill47, align 64
  %1964 = load <8 x i64>, ptr %.slot48, align 64
  %1965 = select <8 x i1> %convergence.cascade.result333, <8 x i64> zeroinitializer, <8 x i64> %1964
  store <8 x i64> %1965, ptr %.slot48, align 64
  store <8 x i1> %convergence.cascade.result333, ptr %current.mask, align 1
  %1966 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result333)
  br i1 %1966, label %schedule.23, label %scheduler.loop

varying.divergent335:                             ; preds = %schedule.23
  %1967 = load i32, ptr %current.token, align 4
  %1968 = icmp ne i32 %1967, 0
  %1969 = sub i32 %1967, 1
  %1970 = select i1 %1968, i32 %1969, i32 0
  %1971 = load i8, ptr %frame.active, align 1
  %1972 = trunc i32 %1970 to i8
  %1973 = shl i8 1, %1972
  %1974 = and i8 %1971, %1973
  %1975 = icmp ne i8 %1974, 0
  %1976 = load <8 x i32>, ptr %frame.static.id, align 32
  %1977 = extractelement <8 x i32> %1976, i32 %1970
  %1978 = icmp eq i32 %1977, 9
  %1979 = and i1 %1975, %1978
  %1980 = and i1 %1968, %1979
  %1981 = xor i1 %1980, true
  %1982 = and i1 true, %1981
  %1983 = xor i8 %1971, -1
  %1984 = icmp ne i8 %1983, 0
  %1985 = xor i1 %1984, true
  %1986 = and i1 %1982, %1985
  br i1 %1986, label %convergence.overflow.trap337, label %convergence.overflow.resume338

varying.coherent336:                              ; preds = %schedule.23
  br i1 %552, label %varying.coherent.true341, label %varying.coherent.false342

convergence.overflow.trap337:                     ; preds = %varying.divergent335
  call void @llvm.trap()
  unreachable

convergence.overflow.resume338:                   ; preds = %varying.divergent335
  %1987 = call i8 @llvm.cttz.i8(i8 %1983, i1 false)
  %1988 = zext i8 %1987 to i32
  %1989 = select i1 %1984, i32 %1988, i32 0
  %1990 = trunc i32 %1989 to i8
  %1991 = shl i8 1, %1990
  %1992 = or i8 %1971, %1991
  %1993 = select i1 %1982, i8 %1992, i8 %1971
  store i8 %1993, ptr %frame.active, align 1
  %1994 = load <8 x i32>, ptr %frame.static.id, align 32
  %1995 = extractelement <8 x i32> %1994, i32 %1989
  %1996 = select i1 %1982, i32 9, i32 %1995
  %1997 = load <8 x i32>, ptr %frame.static.id, align 32
  %1998 = insertelement <8 x i32> %1997, i32 %1996, i32 %1989
  store <8 x i32> %1998, ptr %frame.static.id, align 32
  %1999 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2000 = extractelement <8 x i32> %1999, i32 %1989
  %2001 = select i1 %1982, i32 %1967, i32 %2000
  %2002 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2003 = insertelement <8 x i32> %2002, i32 %2001, i32 %1989
  store <8 x i32> %2003, ptr %frame.parent.token, align 32
  %2004 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1989
  %2005 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1989
  %2006 = load <8 x i1>, ptr %2004, align 1
  %2007 = load <8 x i1>, ptr %2005, align 1
  %2008 = select i1 %1982, <8 x i1> %542, <8 x i1> %2006
  store <8 x i1> %2008, ptr %2004, align 1
  %2009 = select i1 %1982, <8 x i1> zeroinitializer, <8 x i1> %2007
  store <8 x i1> %2009, ptr %2005, align 1
  %2010 = add i32 %1989, 1
  %2011 = select i1 %1980, i32 %1967, i32 %2010
  %2012 = select i1 true, i32 %2011, i32 %1967
  store i32 %2012, ptr %current.token, align 4
  %2013 = load i32, ptr %current.token, align 4
  %2014 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %549)
  %2015 = load i32, ptr %ready.count, align 4
  %2016 = icmp uge i32 %2015, 8
  %2017 = and i1 %2014, %2016
  br i1 %2017, label %ready.overflow.trap339, label %ready.overflow.resume340

ready.overflow.trap339:                           ; preds = %convergence.overflow.resume338
  call void @llvm.trap()
  unreachable

ready.overflow.resume340:                         ; preds = %convergence.overflow.resume338
  %2018 = select i1 %2014, i32 %2015, i32 0
  %2019 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2018
  %2020 = load <8 x i1>, ptr %2019, align 1
  %2021 = select i1 %2014, <8 x i1> %549, <8 x i1> %2020
  store <8 x i1> %2021, ptr %2019, align 1
  %2022 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2018
  %2023 = load i32, ptr %2022, align 4
  %2024 = select i1 %2014, i32 24, i32 %2023
  store i32 %2024, ptr %2022, align 4
  %2025 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2018
  %2026 = load i32, ptr %2025, align 4
  %2027 = select i1 %2014, i32 %2013, i32 %2026
  store i32 %2027, ptr %2025, align 4
  %2028 = add i32 %2015, 1
  %2029 = select i1 %2014, i32 %2028, i32 %2015
  store i32 %2029, ptr %ready.count, align 4
  %2030 = load <8 x i1>, ptr %runnable.mask, align 1
  %2031 = or <8 x i1> %2030, %549
  store <8 x i1> %2031, ptr %runnable.mask, align 1
  store <8 x i1> %551, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true341:                         ; preds = %varying.coherent336
  store <8 x i1> %542, ptr %current.mask, align 1
  %2032 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %542)
  br i1 %2032, label %schedule.24, label %scheduler.loop

varying.coherent.false342:                        ; preds = %varying.coherent336
  store <8 x i1> %542, ptr %current.mask, align 1
  %2033 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %542)
  br i1 %2033, label %schedule.27, label %scheduler.loop

varying.divergent346:                             ; preds = %schedule.24
  %2034 = load i32, ptr %current.token, align 4
  %2035 = icmp ne i32 %2034, 0
  %2036 = sub i32 %2034, 1
  %2037 = select i1 %2035, i32 %2036, i32 0
  %2038 = load i8, ptr %frame.active, align 1
  %2039 = trunc i32 %2037 to i8
  %2040 = shl i8 1, %2039
  %2041 = and i8 %2038, %2040
  %2042 = icmp ne i8 %2041, 0
  %2043 = load <8 x i32>, ptr %frame.static.id, align 32
  %2044 = extractelement <8 x i32> %2043, i32 %2037
  %2045 = icmp eq i32 %2044, 10
  %2046 = and i1 %2042, %2045
  %2047 = and i1 %2035, %2046
  %2048 = xor i1 %2047, true
  %2049 = and i1 true, %2048
  %2050 = xor i8 %2038, -1
  %2051 = icmp ne i8 %2050, 0
  %2052 = xor i1 %2051, true
  %2053 = and i1 %2049, %2052
  br i1 %2053, label %convergence.overflow.trap348, label %convergence.overflow.resume349

varying.coherent347:                              ; preds = %schedule.24
  br i1 %607, label %varying.coherent.true352, label %varying.coherent.false353

convergence.overflow.trap348:                     ; preds = %varying.divergent346
  call void @llvm.trap()
  unreachable

convergence.overflow.resume349:                   ; preds = %varying.divergent346
  %2054 = call i8 @llvm.cttz.i8(i8 %2050, i1 false)
  %2055 = zext i8 %2054 to i32
  %2056 = select i1 %2051, i32 %2055, i32 0
  %2057 = trunc i32 %2056 to i8
  %2058 = shl i8 1, %2057
  %2059 = or i8 %2038, %2058
  %2060 = select i1 %2049, i8 %2059, i8 %2038
  store i8 %2060, ptr %frame.active, align 1
  %2061 = load <8 x i32>, ptr %frame.static.id, align 32
  %2062 = extractelement <8 x i32> %2061, i32 %2056
  %2063 = select i1 %2049, i32 10, i32 %2062
  %2064 = load <8 x i32>, ptr %frame.static.id, align 32
  %2065 = insertelement <8 x i32> %2064, i32 %2063, i32 %2056
  store <8 x i32> %2065, ptr %frame.static.id, align 32
  %2066 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2067 = extractelement <8 x i32> %2066, i32 %2056
  %2068 = select i1 %2049, i32 %2034, i32 %2067
  %2069 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2070 = insertelement <8 x i32> %2069, i32 %2068, i32 %2056
  store <8 x i32> %2070, ptr %frame.parent.token, align 32
  %2071 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2056
  %2072 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2056
  %2073 = load <8 x i1>, ptr %2071, align 1
  %2074 = load <8 x i1>, ptr %2072, align 1
  %2075 = select i1 %2049, <8 x i1> %555, <8 x i1> %2073
  store <8 x i1> %2075, ptr %2071, align 1
  %2076 = select i1 %2049, <8 x i1> zeroinitializer, <8 x i1> %2074
  store <8 x i1> %2076, ptr %2072, align 1
  %2077 = add i32 %2056, 1
  %2078 = select i1 %2047, i32 %2034, i32 %2077
  %2079 = select i1 true, i32 %2078, i32 %2034
  store i32 %2079, ptr %current.token, align 4
  %2080 = load <8 x float>, ptr %.slot52, align 32
  %2081 = select <8 x i1> %606, <8 x float> zeroinitializer, <8 x float> %2080
  store <8 x float> %2081, ptr %.slot52, align 32
  %2082 = load i32, ptr %current.token, align 4
  %2083 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %604)
  %2084 = load i32, ptr %ready.count, align 4
  %2085 = icmp uge i32 %2084, 8
  %2086 = and i1 %2083, %2085
  br i1 %2086, label %ready.overflow.trap350, label %ready.overflow.resume351

ready.overflow.trap350:                           ; preds = %convergence.overflow.resume349
  call void @llvm.trap()
  unreachable

ready.overflow.resume351:                         ; preds = %convergence.overflow.resume349
  %2087 = select i1 %2083, i32 %2084, i32 0
  %2088 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2087
  %2089 = load <8 x i1>, ptr %2088, align 1
  %2090 = select i1 %2083, <8 x i1> %604, <8 x i1> %2089
  store <8 x i1> %2090, ptr %2088, align 1
  %2091 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2087
  %2092 = load i32, ptr %2091, align 4
  %2093 = select i1 %2083, i32 25, i32 %2092
  store i32 %2093, ptr %2091, align 4
  %2094 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2087
  %2095 = load i32, ptr %2094, align 4
  %2096 = select i1 %2083, i32 %2082, i32 %2095
  store i32 %2096, ptr %2094, align 4
  %2097 = add i32 %2084, 1
  %2098 = select i1 %2083, i32 %2097, i32 %2084
  store i32 %2098, ptr %ready.count, align 4
  %2099 = load <8 x i1>, ptr %runnable.mask, align 1
  %2100 = or <8 x i1> %2099, %604
  store <8 x i1> %2100, ptr %runnable.mask, align 1
  store <8 x i1> %606, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true352:                         ; preds = %varying.coherent347
  store <8 x i1> %555, ptr %current.mask, align 1
  %2101 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %555)
  br i1 %2101, label %schedule.25, label %scheduler.loop

varying.coherent.false353:                        ; preds = %varying.coherent347
  %2102 = load <8 x float>, ptr %.slot52, align 32
  %2103 = select <8 x i1> %555, <8 x float> zeroinitializer, <8 x float> %2102
  store <8 x float> %2103, ptr %.slot52, align 32
  store <8 x i1> %555, ptr %current.mask, align 1
  %2104 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %555)
  br i1 %2104, label %schedule.26, label %scheduler.loop

convergence.cascade356:                           ; preds = %convergence.cascade356, %schedule.26
  %convergence.cascade.flow360 = phi <8 x i1> [ %629, %schedule.26 ], [ %2147, %convergence.cascade356 ]
  %convergence.cascade.depth361 = phi i32 [ 0, %schedule.26 ], [ %2148, %convergence.cascade356 ]
  %2105 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow360)
  %2106 = load i32, ptr %current.token, align 4
  %2107 = icmp ne i32 %2106, 0
  %2108 = and i1 %2105, %2107
  %2109 = sub i32 %2106, 1
  %2110 = select i1 %2108, i32 %2109, i32 0
  %2111 = load i8, ptr %frame.active, align 1
  %2112 = trunc i32 %2110 to i8
  %2113 = shl i8 1, %2112
  %2114 = and i8 %2111, %2113
  %2115 = icmp ne i8 %2114, 0
  %2116 = load <8 x i32>, ptr %frame.static.id, align 32
  %2117 = extractelement <8 x i32> %2116, i32 %2110
  %convergence.target.pointer362 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %2117
  %convergence.dynamic.target363 = load i32, ptr %convergence.target.pointer362, align 4
  %2118 = icmp eq i32 %convergence.dynamic.target363, 26
  %2119 = and i1 %2115, %2118
  %2120 = and i1 %2108, %2119
  %2121 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2110
  %2122 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2110
  %2123 = load <8 x i1>, ptr %2121, align 1
  %2124 = load <8 x i1>, ptr %2122, align 1
  %2125 = or <8 x i1> %2124, %convergence.cascade.flow360
  %2126 = load <8 x i1>, ptr %live.mask, align 1
  %2127 = and <8 x i1> %2123, %2126
  %2128 = icmp eq <8 x i1> %2125, %2127
  %2129 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2128)
  %2130 = and i1 %2120, %2129
  %2131 = select i1 %2130, <8 x i1> zeroinitializer, <8 x i1> %2125
  %2132 = select i1 %2120, <8 x i1> %2131, <8 x i1> %2124
  store <8 x i1> %2132, ptr %2122, align 1
  %2133 = select i1 %2130, <8 x i1> zeroinitializer, <8 x i1> %2123
  store <8 x i1> %2133, ptr %2121, align 1
  %2134 = trunc i32 %2110 to i8
  %2135 = shl i8 1, %2134
  %2136 = xor i8 %2135, -1
  %2137 = and i8 %2111, %2136
  %2138 = select i1 %2130, i8 %2137, i8 %2111
  store i8 %2138, ptr %frame.active, align 1
  %.splatinsert364 = insertelement <8 x i1> poison, i1 %2120, i64 0
  %.splat365 = shufflevector <8 x i1> %.splatinsert364, <8 x i1> poison, <8 x i32> zeroinitializer
  %2139 = and <8 x i1> %convergence.cascade.flow360, %.splat365
  %2140 = load <8 x i1>, ptr %runnable.mask, align 1
  %2141 = xor <8 x i1> %2139, splat (i1 true)
  %2142 = and <8 x i1> %2140, %2141
  store <8 x i1> %2142, ptr %runnable.mask, align 1
  %.splatinsert366 = insertelement <8 x i1> poison, i1 %2130, i64 0
  %.splat367 = shufflevector <8 x i1> %.splatinsert366, <8 x i1> poison, <8 x i32> zeroinitializer
  %2143 = select <8 x i1> %.splat367, <8 x i1> %2125, <8 x i1> zeroinitializer
  %2144 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2145 = extractelement <8 x i32> %2144, i32 %2110
  %2146 = select i1 %2130, i32 %2145, i32 %2106
  store i32 %2146, ptr %current.token, align 4
  %.splatinsert368 = insertelement <8 x i1> poison, i1 %2120, i64 0
  %.splat369 = shufflevector <8 x i1> %.splatinsert368, <8 x i1> poison, <8 x i32> zeroinitializer
  %2147 = select <8 x i1> %.splat369, <8 x i1> %2143, <8 x i1> %convergence.cascade.flow360
  %2148 = add i32 %convergence.cascade.depth361, 1
  %2149 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2147)
  %2150 = icmp ult i32 %2148, 8
  %2151 = and i1 %2149, %2150
  %2152 = and i1 %2120, %2151
  %convergence.parent.token370 = load i32, ptr %current.token, align 4
  %convergence.parent.present371 = icmp ne i32 %convergence.parent.token370, 0
  %2153 = and i1 %2152, %convergence.parent.present371
  br i1 %2153, label %convergence.cascade356, label %convergence.cascade.exit357

convergence.cascade.exit357:                      ; preds = %convergence.cascade356, %schedule.26
  %convergence.cascade.result372 = phi <8 x i1> [ %629, %schedule.26 ], [ %2147, %convergence.cascade356 ]
  %2154 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result372)
  br i1 %2154, label %convergence.target.26.ready, label %scheduler.loop

convergence.target.26.ready:                      ; preds = %convergence.cascade.exit357
  %2155 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result372)
  %2156 = bitcast <8 x i1> %convergence.cascade.result372 to i8
  %2157 = call i8 @llvm.cttz.i8(i8 %2156, i1 false)
  %2158 = zext i8 %2157 to i32
  %2159 = select i1 %2155, i32 %2158, i32 0
  %.spill.load373 = load float, ptr %.spill19, align 4
  %.splatinsert374 = insertelement <8 x float> poison, float %.spill.load373, i64 0
  %.splat375 = shufflevector <8 x float> %.splatinsert374, <8 x float> poison, <8 x i32> zeroinitializer
  %.state376 = load <8 x float>, ptr %.slot52, align 32
  %.spill.load377 = load volatile <8 x i1>, ptr %.spill50, align 1
  %2160 = select <8 x i1> %.spill.load377, <8 x float> %.state376, <8 x float> %.splat375
  %.spill.load378 = load volatile <8 x float>, ptr %.spill49, align 32
  %2161 = fadd <8 x float> %.spill.load378, %2160
  %tile_snapshot.spill.load379 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill47, align 64
  %2162 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load379, 0
  %2163 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load379, 1
  %.state380 = load <8 x i64>, ptr %.slot48, align 64
  %2164 = mul <8 x i64> %.state380, splat (i64 32)
  %2165 = add <8 x i64> %2163, %2164
  %2166 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2162, 0
  %2167 = insertvalue { <8 x ptr>, <8 x i64> } %2166, <8 x i64> %2165, 1
  %2168 = extractvalue { <8 x ptr>, <8 x i64> } %2167, 0
  %2169 = extractvalue { <8 x ptr>, <8 x i64> } %2167, 1
  %2170 = getelementptr i8, <8 x ptr> %2168, <8 x i64> %2169
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %2161, <8 x ptr> %2170, i32 1, <8 x i1> %convergence.cascade.result372)
  %.state381 = load <8 x i64>, ptr %.slot48, align 64
  %2171 = add <8 x i64> %.state381, splat (i64 1)
  %2172 = load <8 x i64>, ptr %.slot48, align 64
  %2173 = select <8 x i1> %convergence.cascade.result372, <8 x i64> %2171, <8 x i64> %2172
  store <8 x i64> %2173, ptr %.slot48, align 64
  store <8 x i1> %convergence.cascade.result372, ptr %current.mask, align 1
  %2174 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result372)
  br i1 %2174, label %schedule.23, label %scheduler.loop

convergence.cascade382:                           ; preds = %convergence.cascade382, %schedule.27
  %convergence.cascade.flow386 = phi <8 x i1> [ %630, %schedule.27 ], [ %2217, %convergence.cascade382 ]
  %convergence.cascade.depth387 = phi i32 [ 0, %schedule.27 ], [ %2218, %convergence.cascade382 ]
  %2175 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow386)
  %2176 = load i32, ptr %current.token, align 4
  %2177 = icmp ne i32 %2176, 0
  %2178 = and i1 %2175, %2177
  %2179 = sub i32 %2176, 1
  %2180 = select i1 %2178, i32 %2179, i32 0
  %2181 = load i8, ptr %frame.active, align 1
  %2182 = trunc i32 %2180 to i8
  %2183 = shl i8 1, %2182
  %2184 = and i8 %2181, %2183
  %2185 = icmp ne i8 %2184, 0
  %2186 = load <8 x i32>, ptr %frame.static.id, align 32
  %2187 = extractelement <8 x i32> %2186, i32 %2180
  %convergence.target.pointer388 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %2187
  %convergence.dynamic.target389 = load i32, ptr %convergence.target.pointer388, align 4
  %2188 = icmp eq i32 %convergence.dynamic.target389, 27
  %2189 = and i1 %2185, %2188
  %2190 = and i1 %2178, %2189
  %2191 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2180
  %2192 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2180
  %2193 = load <8 x i1>, ptr %2191, align 1
  %2194 = load <8 x i1>, ptr %2192, align 1
  %2195 = or <8 x i1> %2194, %convergence.cascade.flow386
  %2196 = load <8 x i1>, ptr %live.mask, align 1
  %2197 = and <8 x i1> %2193, %2196
  %2198 = icmp eq <8 x i1> %2195, %2197
  %2199 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2198)
  %2200 = and i1 %2190, %2199
  %2201 = select i1 %2200, <8 x i1> zeroinitializer, <8 x i1> %2195
  %2202 = select i1 %2190, <8 x i1> %2201, <8 x i1> %2194
  store <8 x i1> %2202, ptr %2192, align 1
  %2203 = select i1 %2200, <8 x i1> zeroinitializer, <8 x i1> %2193
  store <8 x i1> %2203, ptr %2191, align 1
  %2204 = trunc i32 %2180 to i8
  %2205 = shl i8 1, %2204
  %2206 = xor i8 %2205, -1
  %2207 = and i8 %2181, %2206
  %2208 = select i1 %2200, i8 %2207, i8 %2181
  store i8 %2208, ptr %frame.active, align 1
  %.splatinsert390 = insertelement <8 x i1> poison, i1 %2190, i64 0
  %.splat391 = shufflevector <8 x i1> %.splatinsert390, <8 x i1> poison, <8 x i32> zeroinitializer
  %2209 = and <8 x i1> %convergence.cascade.flow386, %.splat391
  %2210 = load <8 x i1>, ptr %runnable.mask, align 1
  %2211 = xor <8 x i1> %2209, splat (i1 true)
  %2212 = and <8 x i1> %2210, %2211
  store <8 x i1> %2212, ptr %runnable.mask, align 1
  %.splatinsert392 = insertelement <8 x i1> poison, i1 %2200, i64 0
  %.splat393 = shufflevector <8 x i1> %.splatinsert392, <8 x i1> poison, <8 x i32> zeroinitializer
  %2213 = select <8 x i1> %.splat393, <8 x i1> %2195, <8 x i1> zeroinitializer
  %2214 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2215 = extractelement <8 x i32> %2214, i32 %2180
  %2216 = select i1 %2200, i32 %2215, i32 %2176
  store i32 %2216, ptr %current.token, align 4
  %.splatinsert394 = insertelement <8 x i1> poison, i1 %2190, i64 0
  %.splat395 = shufflevector <8 x i1> %.splatinsert394, <8 x i1> poison, <8 x i32> zeroinitializer
  %2217 = select <8 x i1> %.splat395, <8 x i1> %2213, <8 x i1> %convergence.cascade.flow386
  %2218 = add i32 %convergence.cascade.depth387, 1
  %2219 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2217)
  %2220 = icmp ult i32 %2218, 8
  %2221 = and i1 %2219, %2220
  %2222 = and i1 %2190, %2221
  %convergence.parent.token396 = load i32, ptr %current.token, align 4
  %convergence.parent.present397 = icmp ne i32 %convergence.parent.token396, 0
  %2223 = and i1 %2222, %convergence.parent.present397
  br i1 %2223, label %convergence.cascade382, label %convergence.cascade.exit383

convergence.cascade.exit383:                      ; preds = %convergence.cascade382, %schedule.27
  %convergence.cascade.result398 = phi <8 x i1> [ %630, %schedule.27 ], [ %2217, %convergence.cascade382 ]
  %2224 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result398)
  br i1 %2224, label %convergence.target.27.ready, label %scheduler.loop

convergence.target.27.ready:                      ; preds = %convergence.cascade.exit383
  %2225 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result398)
  %2226 = bitcast <8 x i1> %convergence.cascade.result398 to i8
  %2227 = call i8 @llvm.cttz.i8(i8 %2226, i1 false)
  %2228 = zext i8 %2227 to i32
  %2229 = select i1 %2225, i32 %2228, i32 0
  %2230 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill53, align 64
  %2231 = extractvalue { <8 x ptr>, <8 x i64> } %13, 0
  %2232 = extractvalue { <8 x ptr>, <8 x i64> } %2230, 0
  %2233 = select <8 x i1> %convergence.cascade.result398, <8 x ptr> %2231, <8 x ptr> %2232
  %2234 = extractvalue { <8 x ptr>, <8 x i64> } %13, 1
  %2235 = extractvalue { <8 x ptr>, <8 x i64> } %2230, 1
  %2236 = select <8 x i1> %convergence.cascade.result398, <8 x i64> %2234, <8 x i64> %2235
  %2237 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2233, 0
  %2238 = insertvalue { <8 x ptr>, <8 x i64> } %2237, <8 x i64> %2236, 1
  store { <8 x ptr>, <8 x i64> } %2238, ptr %tile_snapshot.spill53, align 64
  %2239 = load <8 x i64>, ptr %.slot54, align 64
  %2240 = select <8 x i1> %convergence.cascade.result398, <8 x i64> zeroinitializer, <8 x i64> %2239
  store <8 x i64> %2240, ptr %.slot54, align 64
  store <8 x i1> %convergence.cascade.result398, ptr %current.mask, align 1
  %2241 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result398)
  br i1 %2241, label %schedule.28, label %scheduler.loop

varying.divergent400:                             ; preds = %schedule.28
  %2242 = load i32, ptr %current.token, align 4
  %2243 = icmp ne i32 %2242, 0
  %2244 = sub i32 %2242, 1
  %2245 = select i1 %2243, i32 %2244, i32 0
  %2246 = load i8, ptr %frame.active, align 1
  %2247 = trunc i32 %2245 to i8
  %2248 = shl i8 1, %2247
  %2249 = and i8 %2246, %2248
  %2250 = icmp ne i8 %2249, 0
  %2251 = load <8 x i32>, ptr %frame.static.id, align 32
  %2252 = extractelement <8 x i32> %2251, i32 %2245
  %2253 = icmp eq i32 %2252, 11
  %2254 = and i1 %2250, %2253
  %2255 = and i1 %2243, %2254
  %2256 = xor i1 %2255, true
  %2257 = and i1 true, %2256
  %2258 = xor i8 %2246, -1
  %2259 = icmp ne i8 %2258, 0
  %2260 = xor i1 %2259, true
  %2261 = and i1 %2257, %2260
  br i1 %2261, label %convergence.overflow.trap402, label %convergence.overflow.resume403

varying.coherent401:                              ; preds = %schedule.28
  br i1 %641, label %varying.coherent.true406, label %varying.coherent.false407

convergence.overflow.trap402:                     ; preds = %varying.divergent400
  call void @llvm.trap()
  unreachable

convergence.overflow.resume403:                   ; preds = %varying.divergent400
  %2262 = call i8 @llvm.cttz.i8(i8 %2258, i1 false)
  %2263 = zext i8 %2262 to i32
  %2264 = select i1 %2259, i32 %2263, i32 0
  %2265 = trunc i32 %2264 to i8
  %2266 = shl i8 1, %2265
  %2267 = or i8 %2246, %2266
  %2268 = select i1 %2257, i8 %2267, i8 %2246
  store i8 %2268, ptr %frame.active, align 1
  %2269 = load <8 x i32>, ptr %frame.static.id, align 32
  %2270 = extractelement <8 x i32> %2269, i32 %2264
  %2271 = select i1 %2257, i32 11, i32 %2270
  %2272 = load <8 x i32>, ptr %frame.static.id, align 32
  %2273 = insertelement <8 x i32> %2272, i32 %2271, i32 %2264
  store <8 x i32> %2273, ptr %frame.static.id, align 32
  %2274 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2275 = extractelement <8 x i32> %2274, i32 %2264
  %2276 = select i1 %2257, i32 %2242, i32 %2275
  %2277 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2278 = insertelement <8 x i32> %2277, i32 %2276, i32 %2264
  store <8 x i32> %2278, ptr %frame.parent.token, align 32
  %2279 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2264
  %2280 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2264
  %2281 = load <8 x i1>, ptr %2279, align 1
  %2282 = load <8 x i1>, ptr %2280, align 1
  %2283 = select i1 %2257, <8 x i1> %631, <8 x i1> %2281
  store <8 x i1> %2283, ptr %2279, align 1
  %2284 = select i1 %2257, <8 x i1> zeroinitializer, <8 x i1> %2282
  store <8 x i1> %2284, ptr %2280, align 1
  %2285 = add i32 %2264, 1
  %2286 = select i1 %2255, i32 %2242, i32 %2285
  %2287 = select i1 true, i32 %2286, i32 %2242
  store i32 %2287, ptr %current.token, align 4
  %2288 = load i32, ptr %current.token, align 4
  %2289 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %638)
  %2290 = load i32, ptr %ready.count, align 4
  %2291 = icmp uge i32 %2290, 8
  %2292 = and i1 %2289, %2291
  br i1 %2292, label %ready.overflow.trap404, label %ready.overflow.resume405

ready.overflow.trap404:                           ; preds = %convergence.overflow.resume403
  call void @llvm.trap()
  unreachable

ready.overflow.resume405:                         ; preds = %convergence.overflow.resume403
  %2293 = select i1 %2289, i32 %2290, i32 0
  %2294 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2293
  %2295 = load <8 x i1>, ptr %2294, align 1
  %2296 = select i1 %2289, <8 x i1> %638, <8 x i1> %2295
  store <8 x i1> %2296, ptr %2294, align 1
  %2297 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2293
  %2298 = load i32, ptr %2297, align 4
  %2299 = select i1 %2289, i32 29, i32 %2298
  store i32 %2299, ptr %2297, align 4
  %2300 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2293
  %2301 = load i32, ptr %2300, align 4
  %2302 = select i1 %2289, i32 %2288, i32 %2301
  store i32 %2302, ptr %2300, align 4
  %2303 = add i32 %2290, 1
  %2304 = select i1 %2289, i32 %2303, i32 %2290
  store i32 %2304, ptr %ready.count, align 4
  %2305 = load <8 x i1>, ptr %runnable.mask, align 1
  %2306 = or <8 x i1> %2305, %638
  store <8 x i1> %2306, ptr %runnable.mask, align 1
  store <8 x i1> %640, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true406:                         ; preds = %varying.coherent401
  store <8 x i1> %631, ptr %current.mask, align 1
  %2307 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %631)
  br i1 %2307, label %schedule.29, label %scheduler.loop

varying.coherent.false407:                        ; preds = %varying.coherent401
  store <8 x i1> %631, ptr %current.mask, align 1
  %2308 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %631)
  br i1 %2308, label %schedule.32, label %scheduler.loop

varying.divergent411:                             ; preds = %schedule.29
  %2309 = load i32, ptr %current.token, align 4
  %2310 = icmp ne i32 %2309, 0
  %2311 = sub i32 %2309, 1
  %2312 = select i1 %2310, i32 %2311, i32 0
  %2313 = load i8, ptr %frame.active, align 1
  %2314 = trunc i32 %2312 to i8
  %2315 = shl i8 1, %2314
  %2316 = and i8 %2313, %2315
  %2317 = icmp ne i8 %2316, 0
  %2318 = load <8 x i32>, ptr %frame.static.id, align 32
  %2319 = extractelement <8 x i32> %2318, i32 %2312
  %2320 = icmp eq i32 %2319, 12
  %2321 = and i1 %2317, %2320
  %2322 = and i1 %2310, %2321
  %2323 = xor i1 %2322, true
  %2324 = and i1 true, %2323
  %2325 = xor i8 %2313, -1
  %2326 = icmp ne i8 %2325, 0
  %2327 = xor i1 %2326, true
  %2328 = and i1 %2324, %2327
  br i1 %2328, label %convergence.overflow.trap413, label %convergence.overflow.resume414

varying.coherent412:                              ; preds = %schedule.29
  br i1 %707, label %varying.coherent.true417, label %varying.coherent.false418

convergence.overflow.trap413:                     ; preds = %varying.divergent411
  call void @llvm.trap()
  unreachable

convergence.overflow.resume414:                   ; preds = %varying.divergent411
  %2329 = call i8 @llvm.cttz.i8(i8 %2325, i1 false)
  %2330 = zext i8 %2329 to i32
  %2331 = select i1 %2326, i32 %2330, i32 0
  %2332 = trunc i32 %2331 to i8
  %2333 = shl i8 1, %2332
  %2334 = or i8 %2313, %2333
  %2335 = select i1 %2324, i8 %2334, i8 %2313
  store i8 %2335, ptr %frame.active, align 1
  %2336 = load <8 x i32>, ptr %frame.static.id, align 32
  %2337 = extractelement <8 x i32> %2336, i32 %2331
  %2338 = select i1 %2324, i32 12, i32 %2337
  %2339 = load <8 x i32>, ptr %frame.static.id, align 32
  %2340 = insertelement <8 x i32> %2339, i32 %2338, i32 %2331
  store <8 x i32> %2340, ptr %frame.static.id, align 32
  %2341 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2342 = extractelement <8 x i32> %2341, i32 %2331
  %2343 = select i1 %2324, i32 %2309, i32 %2342
  %2344 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2345 = insertelement <8 x i32> %2344, i32 %2343, i32 %2331
  store <8 x i32> %2345, ptr %frame.parent.token, align 32
  %2346 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2331
  %2347 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2331
  %2348 = load <8 x i1>, ptr %2346, align 1
  %2349 = load <8 x i1>, ptr %2347, align 1
  %2350 = select i1 %2324, <8 x i1> %644, <8 x i1> %2348
  store <8 x i1> %2350, ptr %2346, align 1
  %2351 = select i1 %2324, <8 x i1> zeroinitializer, <8 x i1> %2349
  store <8 x i1> %2351, ptr %2347, align 1
  %2352 = add i32 %2331, 1
  %2353 = select i1 %2322, i32 %2309, i32 %2352
  %2354 = select i1 true, i32 %2353, i32 %2309
  store i32 %2354, ptr %current.token, align 4
  %2355 = load <8 x float>, ptr %.slot59, align 32
  %2356 = select <8 x i1> %706, <8 x float> zeroinitializer, <8 x float> %2355
  store <8 x float> %2356, ptr %.slot59, align 32
  %2357 = load i32, ptr %current.token, align 4
  %2358 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %704)
  %2359 = load i32, ptr %ready.count, align 4
  %2360 = icmp uge i32 %2359, 8
  %2361 = and i1 %2358, %2360
  br i1 %2361, label %ready.overflow.trap415, label %ready.overflow.resume416

ready.overflow.trap415:                           ; preds = %convergence.overflow.resume414
  call void @llvm.trap()
  unreachable

ready.overflow.resume416:                         ; preds = %convergence.overflow.resume414
  %2362 = select i1 %2358, i32 %2359, i32 0
  %2363 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2362
  %2364 = load <8 x i1>, ptr %2363, align 1
  %2365 = select i1 %2358, <8 x i1> %704, <8 x i1> %2364
  store <8 x i1> %2365, ptr %2363, align 1
  %2366 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2362
  %2367 = load i32, ptr %2366, align 4
  %2368 = select i1 %2358, i32 30, i32 %2367
  store i32 %2368, ptr %2366, align 4
  %2369 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2362
  %2370 = load i32, ptr %2369, align 4
  %2371 = select i1 %2358, i32 %2357, i32 %2370
  store i32 %2371, ptr %2369, align 4
  %2372 = add i32 %2359, 1
  %2373 = select i1 %2358, i32 %2372, i32 %2359
  store i32 %2373, ptr %ready.count, align 4
  %2374 = load <8 x i1>, ptr %runnable.mask, align 1
  %2375 = or <8 x i1> %2374, %704
  store <8 x i1> %2375, ptr %runnable.mask, align 1
  store <8 x i1> %706, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true417:                         ; preds = %varying.coherent412
  store <8 x i1> %644, ptr %current.mask, align 1
  %2376 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %644)
  br i1 %2376, label %schedule.30, label %scheduler.loop

varying.coherent.false418:                        ; preds = %varying.coherent412
  %2377 = load <8 x float>, ptr %.slot59, align 32
  %2378 = select <8 x i1> %644, <8 x float> zeroinitializer, <8 x float> %2377
  store <8 x float> %2378, ptr %.slot59, align 32
  store <8 x i1> %644, ptr %current.mask, align 1
  %2379 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %644)
  br i1 %2379, label %schedule.31, label %scheduler.loop

convergence.cascade421:                           ; preds = %convergence.cascade421, %schedule.31
  %convergence.cascade.flow425 = phi <8 x i1> [ %729, %schedule.31 ], [ %2422, %convergence.cascade421 ]
  %convergence.cascade.depth426 = phi i32 [ 0, %schedule.31 ], [ %2423, %convergence.cascade421 ]
  %2380 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow425)
  %2381 = load i32, ptr %current.token, align 4
  %2382 = icmp ne i32 %2381, 0
  %2383 = and i1 %2380, %2382
  %2384 = sub i32 %2381, 1
  %2385 = select i1 %2383, i32 %2384, i32 0
  %2386 = load i8, ptr %frame.active, align 1
  %2387 = trunc i32 %2385 to i8
  %2388 = shl i8 1, %2387
  %2389 = and i8 %2386, %2388
  %2390 = icmp ne i8 %2389, 0
  %2391 = load <8 x i32>, ptr %frame.static.id, align 32
  %2392 = extractelement <8 x i32> %2391, i32 %2385
  %convergence.target.pointer427 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %2392
  %convergence.dynamic.target428 = load i32, ptr %convergence.target.pointer427, align 4
  %2393 = icmp eq i32 %convergence.dynamic.target428, 31
  %2394 = and i1 %2390, %2393
  %2395 = and i1 %2383, %2394
  %2396 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2385
  %2397 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2385
  %2398 = load <8 x i1>, ptr %2396, align 1
  %2399 = load <8 x i1>, ptr %2397, align 1
  %2400 = or <8 x i1> %2399, %convergence.cascade.flow425
  %2401 = load <8 x i1>, ptr %live.mask, align 1
  %2402 = and <8 x i1> %2398, %2401
  %2403 = icmp eq <8 x i1> %2400, %2402
  %2404 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2403)
  %2405 = and i1 %2395, %2404
  %2406 = select i1 %2405, <8 x i1> zeroinitializer, <8 x i1> %2400
  %2407 = select i1 %2395, <8 x i1> %2406, <8 x i1> %2399
  store <8 x i1> %2407, ptr %2397, align 1
  %2408 = select i1 %2405, <8 x i1> zeroinitializer, <8 x i1> %2398
  store <8 x i1> %2408, ptr %2396, align 1
  %2409 = trunc i32 %2385 to i8
  %2410 = shl i8 1, %2409
  %2411 = xor i8 %2410, -1
  %2412 = and i8 %2386, %2411
  %2413 = select i1 %2405, i8 %2412, i8 %2386
  store i8 %2413, ptr %frame.active, align 1
  %.splatinsert429 = insertelement <8 x i1> poison, i1 %2395, i64 0
  %.splat430 = shufflevector <8 x i1> %.splatinsert429, <8 x i1> poison, <8 x i32> zeroinitializer
  %2414 = and <8 x i1> %convergence.cascade.flow425, %.splat430
  %2415 = load <8 x i1>, ptr %runnable.mask, align 1
  %2416 = xor <8 x i1> %2414, splat (i1 true)
  %2417 = and <8 x i1> %2415, %2416
  store <8 x i1> %2417, ptr %runnable.mask, align 1
  %.splatinsert431 = insertelement <8 x i1> poison, i1 %2405, i64 0
  %.splat432 = shufflevector <8 x i1> %.splatinsert431, <8 x i1> poison, <8 x i32> zeroinitializer
  %2418 = select <8 x i1> %.splat432, <8 x i1> %2400, <8 x i1> zeroinitializer
  %2419 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2420 = extractelement <8 x i32> %2419, i32 %2385
  %2421 = select i1 %2405, i32 %2420, i32 %2381
  store i32 %2421, ptr %current.token, align 4
  %.splatinsert433 = insertelement <8 x i1> poison, i1 %2395, i64 0
  %.splat434 = shufflevector <8 x i1> %.splatinsert433, <8 x i1> poison, <8 x i32> zeroinitializer
  %2422 = select <8 x i1> %.splat434, <8 x i1> %2418, <8 x i1> %convergence.cascade.flow425
  %2423 = add i32 %convergence.cascade.depth426, 1
  %2424 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2422)
  %2425 = icmp ult i32 %2423, 8
  %2426 = and i1 %2424, %2425
  %2427 = and i1 %2395, %2426
  %convergence.parent.token435 = load i32, ptr %current.token, align 4
  %convergence.parent.present436 = icmp ne i32 %convergence.parent.token435, 0
  %2428 = and i1 %2427, %convergence.parent.present436
  br i1 %2428, label %convergence.cascade421, label %convergence.cascade.exit422

convergence.cascade.exit422:                      ; preds = %convergence.cascade421, %schedule.31
  %convergence.cascade.result437 = phi <8 x i1> [ %729, %schedule.31 ], [ %2422, %convergence.cascade421 ]
  %2429 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result437)
  br i1 %2429, label %convergence.target.31.ready, label %scheduler.loop

convergence.target.31.ready:                      ; preds = %convergence.cascade.exit422
  %2430 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result437)
  %2431 = bitcast <8 x i1> %convergence.cascade.result437 to i8
  %2432 = call i8 @llvm.cttz.i8(i8 %2431, i1 false)
  %2433 = zext i8 %2432 to i32
  %2434 = select i1 %2430, i32 %2433, i32 0
  %.spill.load438 = load float, ptr %.spill19, align 4
  %.splatinsert439 = insertelement <8 x float> poison, float %.spill.load438, i64 0
  %.splat440 = shufflevector <8 x float> %.splatinsert439, <8 x float> poison, <8 x i32> zeroinitializer
  %.state441 = load <8 x float>, ptr %.slot59, align 32
  %.spill.load442 = load volatile <8 x i1>, ptr %.spill57, align 1
  %2435 = select <8 x i1> %.spill.load442, <8 x float> %.state441, <8 x float> %.splat440
  %.spill.load443 = load volatile <8 x float>, ptr %.spill56, align 32
  %2436 = fadd <8 x float> %.spill.load443, %2435
  %tile_snapshot.spill.load444 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %2437 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load444, 0
  %2438 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load444, 1
  %.spill.load445 = load volatile <8 x i64>, ptr %.spill55, align 64
  %2439 = mul <8 x i64> %.spill.load445, splat (i64 32)
  %2440 = add <8 x i64> %2438, %2439
  %2441 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2437, 0
  %2442 = insertvalue { <8 x ptr>, <8 x i64> } %2441, <8 x i64> %2440, 1
  %2443 = extractvalue { <8 x ptr>, <8 x i64> } %2442, 0
  %2444 = extractvalue { <8 x ptr>, <8 x i64> } %2442, 1
  %2445 = getelementptr i8, <8 x ptr> %2443, <8 x i64> %2444
  %2446 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %2445, i32 1, <8 x i1> %convergence.cascade.result437, <8 x float> zeroinitializer)
  %2447 = fadd <8 x float> %2436, %2446
  %tile_snapshot.spill.load446 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill53, align 64
  %2448 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load446, 0
  %2449 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load446, 1
  %.state447 = load <8 x i64>, ptr %.slot54, align 64
  %2450 = mul <8 x i64> %.state447, splat (i64 32)
  %2451 = add <8 x i64> %2449, %2450
  %2452 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2448, 0
  %2453 = insertvalue { <8 x ptr>, <8 x i64> } %2452, <8 x i64> %2451, 1
  %2454 = extractvalue { <8 x ptr>, <8 x i64> } %2453, 0
  %2455 = extractvalue { <8 x ptr>, <8 x i64> } %2453, 1
  %2456 = getelementptr i8, <8 x ptr> %2454, <8 x i64> %2455
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %2447, <8 x ptr> %2456, i32 1, <8 x i1> %convergence.cascade.result437)
  %.state448 = load <8 x i64>, ptr %.slot54, align 64
  %2457 = add <8 x i64> %.state448, splat (i64 1)
  %2458 = load <8 x i64>, ptr %.slot54, align 64
  %2459 = select <8 x i1> %convergence.cascade.result437, <8 x i64> %2457, <8 x i64> %2458
  store <8 x i64> %2459, ptr %.slot54, align 64
  store <8 x i1> %convergence.cascade.result437, ptr %current.mask, align 1
  %2460 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result437)
  br i1 %2460, label %schedule.28, label %scheduler.loop

convergence.cascade449:                           ; preds = %convergence.cascade449, %schedule.32
  %convergence.cascade.flow453 = phi <8 x i1> [ %730, %schedule.32 ], [ %2503, %convergence.cascade449 ]
  %convergence.cascade.depth454 = phi i32 [ 0, %schedule.32 ], [ %2504, %convergence.cascade449 ]
  %2461 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow453)
  %2462 = load i32, ptr %current.token, align 4
  %2463 = icmp ne i32 %2462, 0
  %2464 = and i1 %2461, %2463
  %2465 = sub i32 %2462, 1
  %2466 = select i1 %2464, i32 %2465, i32 0
  %2467 = load i8, ptr %frame.active, align 1
  %2468 = trunc i32 %2466 to i8
  %2469 = shl i8 1, %2468
  %2470 = and i8 %2467, %2469
  %2471 = icmp ne i8 %2470, 0
  %2472 = load <8 x i32>, ptr %frame.static.id, align 32
  %2473 = extractelement <8 x i32> %2472, i32 %2466
  %convergence.target.pointer455 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %2473
  %convergence.dynamic.target456 = load i32, ptr %convergence.target.pointer455, align 4
  %2474 = icmp eq i32 %convergence.dynamic.target456, 32
  %2475 = and i1 %2471, %2474
  %2476 = and i1 %2464, %2475
  %2477 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2466
  %2478 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2466
  %2479 = load <8 x i1>, ptr %2477, align 1
  %2480 = load <8 x i1>, ptr %2478, align 1
  %2481 = or <8 x i1> %2480, %convergence.cascade.flow453
  %2482 = load <8 x i1>, ptr %live.mask, align 1
  %2483 = and <8 x i1> %2479, %2482
  %2484 = icmp eq <8 x i1> %2481, %2483
  %2485 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2484)
  %2486 = and i1 %2476, %2485
  %2487 = select i1 %2486, <8 x i1> zeroinitializer, <8 x i1> %2481
  %2488 = select i1 %2476, <8 x i1> %2487, <8 x i1> %2480
  store <8 x i1> %2488, ptr %2478, align 1
  %2489 = select i1 %2486, <8 x i1> zeroinitializer, <8 x i1> %2479
  store <8 x i1> %2489, ptr %2477, align 1
  %2490 = trunc i32 %2466 to i8
  %2491 = shl i8 1, %2490
  %2492 = xor i8 %2491, -1
  %2493 = and i8 %2467, %2492
  %2494 = select i1 %2486, i8 %2493, i8 %2467
  store i8 %2494, ptr %frame.active, align 1
  %.splatinsert457 = insertelement <8 x i1> poison, i1 %2476, i64 0
  %.splat458 = shufflevector <8 x i1> %.splatinsert457, <8 x i1> poison, <8 x i32> zeroinitializer
  %2495 = and <8 x i1> %convergence.cascade.flow453, %.splat458
  %2496 = load <8 x i1>, ptr %runnable.mask, align 1
  %2497 = xor <8 x i1> %2495, splat (i1 true)
  %2498 = and <8 x i1> %2496, %2497
  store <8 x i1> %2498, ptr %runnable.mask, align 1
  %.splatinsert459 = insertelement <8 x i1> poison, i1 %2486, i64 0
  %.splat460 = shufflevector <8 x i1> %.splatinsert459, <8 x i1> poison, <8 x i32> zeroinitializer
  %2499 = select <8 x i1> %.splat460, <8 x i1> %2481, <8 x i1> zeroinitializer
  %2500 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2501 = extractelement <8 x i32> %2500, i32 %2466
  %2502 = select i1 %2486, i32 %2501, i32 %2462
  store i32 %2502, ptr %current.token, align 4
  %.splatinsert461 = insertelement <8 x i1> poison, i1 %2476, i64 0
  %.splat462 = shufflevector <8 x i1> %.splatinsert461, <8 x i1> poison, <8 x i32> zeroinitializer
  %2503 = select <8 x i1> %.splat462, <8 x i1> %2499, <8 x i1> %convergence.cascade.flow453
  %2504 = add i32 %convergence.cascade.depth454, 1
  %2505 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2503)
  %2506 = icmp ult i32 %2504, 8
  %2507 = and i1 %2505, %2506
  %2508 = and i1 %2476, %2507
  %convergence.parent.token463 = load i32, ptr %current.token, align 4
  %convergence.parent.present464 = icmp ne i32 %convergence.parent.token463, 0
  %2509 = and i1 %2508, %convergence.parent.present464
  br i1 %2509, label %convergence.cascade449, label %convergence.cascade.exit450

convergence.cascade.exit450:                      ; preds = %convergence.cascade449, %schedule.32
  %convergence.cascade.result465 = phi <8 x i1> [ %730, %schedule.32 ], [ %2503, %convergence.cascade449 ]
  %2510 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result465)
  br i1 %2510, label %convergence.target.32.ready, label %scheduler.loop

convergence.target.32.ready:                      ; preds = %convergence.cascade.exit450
  %2511 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result465)
  %2512 = bitcast <8 x i1> %convergence.cascade.result465 to i8
  %2513 = call i8 @llvm.cttz.i8(i8 %2512, i1 false)
  %2514 = zext i8 %2513 to i32
  %2515 = select i1 %2511, i32 %2514, i32 0
  %2516 = load <8 x i64>, ptr %.slot60, align 64
  %2517 = select <8 x i1> %convergence.cascade.result465, <8 x i64> zeroinitializer, <8 x i64> %2516
  store <8 x i64> %2517, ptr %.slot60, align 64
  store <8 x i1> %convergence.cascade.result465, ptr %current.mask, align 1
  %2518 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result465)
  br i1 %2518, label %schedule.33, label %scheduler.loop

varying.divergent467:                             ; preds = %schedule.33
  %2519 = load i32, ptr %current.token, align 4
  %2520 = icmp ne i32 %2519, 0
  %2521 = sub i32 %2519, 1
  %2522 = select i1 %2520, i32 %2521, i32 0
  %2523 = load i8, ptr %frame.active, align 1
  %2524 = trunc i32 %2522 to i8
  %2525 = shl i8 1, %2524
  %2526 = and i8 %2523, %2525
  %2527 = icmp ne i8 %2526, 0
  %2528 = load <8 x i32>, ptr %frame.static.id, align 32
  %2529 = extractelement <8 x i32> %2528, i32 %2522
  %2530 = icmp eq i32 %2529, 13
  %2531 = and i1 %2527, %2530
  %2532 = and i1 %2520, %2531
  %2533 = xor i1 %2532, true
  %2534 = and i1 true, %2533
  %2535 = xor i8 %2523, -1
  %2536 = icmp ne i8 %2535, 0
  %2537 = xor i1 %2536, true
  %2538 = and i1 %2534, %2537
  br i1 %2538, label %convergence.overflow.trap469, label %convergence.overflow.resume470

varying.coherent468:                              ; preds = %schedule.33
  br i1 %741, label %varying.coherent.true473, label %varying.coherent.false474

convergence.overflow.trap469:                     ; preds = %varying.divergent467
  call void @llvm.trap()
  unreachable

convergence.overflow.resume470:                   ; preds = %varying.divergent467
  %2539 = call i8 @llvm.cttz.i8(i8 %2535, i1 false)
  %2540 = zext i8 %2539 to i32
  %2541 = select i1 %2536, i32 %2540, i32 0
  %2542 = trunc i32 %2541 to i8
  %2543 = shl i8 1, %2542
  %2544 = or i8 %2523, %2543
  %2545 = select i1 %2534, i8 %2544, i8 %2523
  store i8 %2545, ptr %frame.active, align 1
  %2546 = load <8 x i32>, ptr %frame.static.id, align 32
  %2547 = extractelement <8 x i32> %2546, i32 %2541
  %2548 = select i1 %2534, i32 13, i32 %2547
  %2549 = load <8 x i32>, ptr %frame.static.id, align 32
  %2550 = insertelement <8 x i32> %2549, i32 %2548, i32 %2541
  store <8 x i32> %2550, ptr %frame.static.id, align 32
  %2551 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2552 = extractelement <8 x i32> %2551, i32 %2541
  %2553 = select i1 %2534, i32 %2519, i32 %2552
  %2554 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2555 = insertelement <8 x i32> %2554, i32 %2553, i32 %2541
  store <8 x i32> %2555, ptr %frame.parent.token, align 32
  %2556 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2541
  %2557 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2541
  %2558 = load <8 x i1>, ptr %2556, align 1
  %2559 = load <8 x i1>, ptr %2557, align 1
  %2560 = select i1 %2534, <8 x i1> %731, <8 x i1> %2558
  store <8 x i1> %2560, ptr %2556, align 1
  %2561 = select i1 %2534, <8 x i1> zeroinitializer, <8 x i1> %2559
  store <8 x i1> %2561, ptr %2557, align 1
  %2562 = add i32 %2541, 1
  %2563 = select i1 %2532, i32 %2519, i32 %2562
  %2564 = select i1 true, i32 %2563, i32 %2519
  store i32 %2564, ptr %current.token, align 4
  %2565 = load i32, ptr %current.token, align 4
  %2566 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %738)
  %2567 = load i32, ptr %ready.count, align 4
  %2568 = icmp uge i32 %2567, 8
  %2569 = and i1 %2566, %2568
  br i1 %2569, label %ready.overflow.trap471, label %ready.overflow.resume472

ready.overflow.trap471:                           ; preds = %convergence.overflow.resume470
  call void @llvm.trap()
  unreachable

ready.overflow.resume472:                         ; preds = %convergence.overflow.resume470
  %2570 = select i1 %2566, i32 %2567, i32 0
  %2571 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2570
  %2572 = load <8 x i1>, ptr %2571, align 1
  %2573 = select i1 %2566, <8 x i1> %738, <8 x i1> %2572
  store <8 x i1> %2573, ptr %2571, align 1
  %2574 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2570
  %2575 = load i32, ptr %2574, align 4
  %2576 = select i1 %2566, i32 34, i32 %2575
  store i32 %2576, ptr %2574, align 4
  %2577 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2570
  %2578 = load i32, ptr %2577, align 4
  %2579 = select i1 %2566, i32 %2565, i32 %2578
  store i32 %2579, ptr %2577, align 4
  %2580 = add i32 %2567, 1
  %2581 = select i1 %2566, i32 %2580, i32 %2567
  store i32 %2581, ptr %ready.count, align 4
  %2582 = load <8 x i1>, ptr %runnable.mask, align 1
  %2583 = or <8 x i1> %2582, %738
  store <8 x i1> %2583, ptr %runnable.mask, align 1
  store <8 x i1> %740, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true473:                         ; preds = %varying.coherent468
  store <8 x i1> %731, ptr %current.mask, align 1
  %2584 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %731)
  br i1 %2584, label %schedule.34, label %scheduler.loop

varying.coherent.false474:                        ; preds = %varying.coherent468
  store <8 x i1> %731, ptr %current.mask, align 1
  %2585 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %731)
  br i1 %2585, label %schedule.37, label %scheduler.loop

varying.divergent481:                             ; preds = %schedule.34
  %2586 = load i32, ptr %current.token, align 4
  %2587 = icmp ne i32 %2586, 0
  %2588 = sub i32 %2586, 1
  %2589 = select i1 %2587, i32 %2588, i32 0
  %2590 = load i8, ptr %frame.active, align 1
  %2591 = trunc i32 %2589 to i8
  %2592 = shl i8 1, %2591
  %2593 = and i8 %2590, %2592
  %2594 = icmp ne i8 %2593, 0
  %2595 = load <8 x i32>, ptr %frame.static.id, align 32
  %2596 = extractelement <8 x i32> %2595, i32 %2589
  %2597 = icmp eq i32 %2596, 14
  %2598 = and i1 %2594, %2597
  %2599 = and i1 %2587, %2598
  %2600 = xor i1 %2599, true
  %2601 = and i1 true, %2600
  %2602 = xor i8 %2590, -1
  %2603 = icmp ne i8 %2602, 0
  %2604 = xor i1 %2603, true
  %2605 = and i1 %2601, %2604
  br i1 %2605, label %convergence.overflow.trap483, label %convergence.overflow.resume484

varying.coherent482:                              ; preds = %schedule.34
  br i1 %786, label %varying.coherent.true487, label %varying.coherent.false488

convergence.overflow.trap483:                     ; preds = %varying.divergent481
  call void @llvm.trap()
  unreachable

convergence.overflow.resume484:                   ; preds = %varying.divergent481
  %2606 = call i8 @llvm.cttz.i8(i8 %2602, i1 false)
  %2607 = zext i8 %2606 to i32
  %2608 = select i1 %2603, i32 %2607, i32 0
  %2609 = trunc i32 %2608 to i8
  %2610 = shl i8 1, %2609
  %2611 = or i8 %2590, %2610
  %2612 = select i1 %2601, i8 %2611, i8 %2590
  store i8 %2612, ptr %frame.active, align 1
  %2613 = load <8 x i32>, ptr %frame.static.id, align 32
  %2614 = extractelement <8 x i32> %2613, i32 %2608
  %2615 = select i1 %2601, i32 14, i32 %2614
  %2616 = load <8 x i32>, ptr %frame.static.id, align 32
  %2617 = insertelement <8 x i32> %2616, i32 %2615, i32 %2608
  store <8 x i32> %2617, ptr %frame.static.id, align 32
  %2618 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2619 = extractelement <8 x i32> %2618, i32 %2608
  %2620 = select i1 %2601, i32 %2586, i32 %2619
  %2621 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2622 = insertelement <8 x i32> %2621, i32 %2620, i32 %2608
  store <8 x i32> %2622, ptr %frame.parent.token, align 32
  %2623 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2608
  %2624 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2608
  %2625 = load <8 x i1>, ptr %2623, align 1
  %2626 = load <8 x i1>, ptr %2624, align 1
  %2627 = select i1 %2601, <8 x i1> %744, <8 x i1> %2625
  store <8 x i1> %2627, ptr %2623, align 1
  %2628 = select i1 %2601, <8 x i1> zeroinitializer, <8 x i1> %2626
  store <8 x i1> %2628, ptr %2624, align 1
  %2629 = add i32 %2608, 1
  %2630 = select i1 %2599, i32 %2586, i32 %2629
  %2631 = select i1 true, i32 %2630, i32 %2586
  store i32 %2631, ptr %current.token, align 4
  %2632 = load i32, ptr %current.token, align 4
  %2633 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %783)
  %2634 = load i32, ptr %ready.count, align 4
  %2635 = icmp uge i32 %2634, 8
  %2636 = and i1 %2633, %2635
  br i1 %2636, label %ready.overflow.trap485, label %ready.overflow.resume486

ready.overflow.trap485:                           ; preds = %convergence.overflow.resume484
  call void @llvm.trap()
  unreachable

ready.overflow.resume486:                         ; preds = %convergence.overflow.resume484
  %2637 = select i1 %2633, i32 %2634, i32 0
  %2638 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2637
  %2639 = load <8 x i1>, ptr %2638, align 1
  %2640 = select i1 %2633, <8 x i1> %783, <8 x i1> %2639
  store <8 x i1> %2640, ptr %2638, align 1
  %2641 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2637
  %2642 = load i32, ptr %2641, align 4
  %2643 = select i1 %2633, i32 35, i32 %2642
  store i32 %2643, ptr %2641, align 4
  %2644 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2637
  %2645 = load i32, ptr %2644, align 4
  %2646 = select i1 %2633, i32 %2632, i32 %2645
  store i32 %2646, ptr %2644, align 4
  %2647 = add i32 %2634, 1
  %2648 = select i1 %2633, i32 %2647, i32 %2634
  store i32 %2648, ptr %ready.count, align 4
  %2649 = load <8 x i1>, ptr %runnable.mask, align 1
  %2650 = or <8 x i1> %2649, %783
  store <8 x i1> %2650, ptr %runnable.mask, align 1
  store <8 x i1> %785, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true487:                         ; preds = %varying.coherent482
  store <8 x i1> %744, ptr %current.mask, align 1
  %2651 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %744)
  br i1 %2651, label %schedule.35, label %scheduler.loop

varying.coherent.false488:                        ; preds = %varying.coherent482
  store <8 x i1> %744, ptr %current.mask, align 1
  %2652 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %744)
  br i1 %2652, label %schedule.36, label %scheduler.loop

convergence.cascade491:                           ; preds = %convergence.cascade491, %schedule.36
  %convergence.cascade.flow495 = phi <8 x i1> [ %799, %schedule.36 ], [ %2695, %convergence.cascade491 ]
  %convergence.cascade.depth496 = phi i32 [ 0, %schedule.36 ], [ %2696, %convergence.cascade491 ]
  %2653 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow495)
  %2654 = load i32, ptr %current.token, align 4
  %2655 = icmp ne i32 %2654, 0
  %2656 = and i1 %2653, %2655
  %2657 = sub i32 %2654, 1
  %2658 = select i1 %2656, i32 %2657, i32 0
  %2659 = load i8, ptr %frame.active, align 1
  %2660 = trunc i32 %2658 to i8
  %2661 = shl i8 1, %2660
  %2662 = and i8 %2659, %2661
  %2663 = icmp ne i8 %2662, 0
  %2664 = load <8 x i32>, ptr %frame.static.id, align 32
  %2665 = extractelement <8 x i32> %2664, i32 %2658
  %convergence.target.pointer497 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %2665
  %convergence.dynamic.target498 = load i32, ptr %convergence.target.pointer497, align 4
  %2666 = icmp eq i32 %convergence.dynamic.target498, 36
  %2667 = and i1 %2663, %2666
  %2668 = and i1 %2656, %2667
  %2669 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2658
  %2670 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2658
  %2671 = load <8 x i1>, ptr %2669, align 1
  %2672 = load <8 x i1>, ptr %2670, align 1
  %2673 = or <8 x i1> %2672, %convergence.cascade.flow495
  %2674 = load <8 x i1>, ptr %live.mask, align 1
  %2675 = and <8 x i1> %2671, %2674
  %2676 = icmp eq <8 x i1> %2673, %2675
  %2677 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2676)
  %2678 = and i1 %2668, %2677
  %2679 = select i1 %2678, <8 x i1> zeroinitializer, <8 x i1> %2673
  %2680 = select i1 %2668, <8 x i1> %2679, <8 x i1> %2672
  store <8 x i1> %2680, ptr %2670, align 1
  %2681 = select i1 %2678, <8 x i1> zeroinitializer, <8 x i1> %2671
  store <8 x i1> %2681, ptr %2669, align 1
  %2682 = trunc i32 %2658 to i8
  %2683 = shl i8 1, %2682
  %2684 = xor i8 %2683, -1
  %2685 = and i8 %2659, %2684
  %2686 = select i1 %2678, i8 %2685, i8 %2659
  store i8 %2686, ptr %frame.active, align 1
  %.splatinsert499 = insertelement <8 x i1> poison, i1 %2668, i64 0
  %.splat500 = shufflevector <8 x i1> %.splatinsert499, <8 x i1> poison, <8 x i32> zeroinitializer
  %2687 = and <8 x i1> %convergence.cascade.flow495, %.splat500
  %2688 = load <8 x i1>, ptr %runnable.mask, align 1
  %2689 = xor <8 x i1> %2687, splat (i1 true)
  %2690 = and <8 x i1> %2688, %2689
  store <8 x i1> %2690, ptr %runnable.mask, align 1
  %.splatinsert501 = insertelement <8 x i1> poison, i1 %2678, i64 0
  %.splat502 = shufflevector <8 x i1> %.splatinsert501, <8 x i1> poison, <8 x i32> zeroinitializer
  %2691 = select <8 x i1> %.splat502, <8 x i1> %2673, <8 x i1> zeroinitializer
  %2692 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2693 = extractelement <8 x i32> %2692, i32 %2658
  %2694 = select i1 %2678, i32 %2693, i32 %2654
  store i32 %2694, ptr %current.token, align 4
  %.splatinsert503 = insertelement <8 x i1> poison, i1 %2668, i64 0
  %.splat504 = shufflevector <8 x i1> %.splatinsert503, <8 x i1> poison, <8 x i32> zeroinitializer
  %2695 = select <8 x i1> %.splat504, <8 x i1> %2691, <8 x i1> %convergence.cascade.flow495
  %2696 = add i32 %convergence.cascade.depth496, 1
  %2697 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2695)
  %2698 = icmp ult i32 %2696, 8
  %2699 = and i1 %2697, %2698
  %2700 = and i1 %2668, %2699
  %convergence.parent.token505 = load i32, ptr %current.token, align 4
  %convergence.parent.present506 = icmp ne i32 %convergence.parent.token505, 0
  %2701 = and i1 %2700, %convergence.parent.present506
  br i1 %2701, label %convergence.cascade491, label %convergence.cascade.exit492

convergence.cascade.exit492:                      ; preds = %convergence.cascade491, %schedule.36
  %convergence.cascade.result507 = phi <8 x i1> [ %799, %schedule.36 ], [ %2695, %convergence.cascade491 ]
  %2702 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result507)
  br i1 %2702, label %convergence.target.36.ready, label %scheduler.loop

convergence.target.36.ready:                      ; preds = %convergence.cascade.exit492
  %2703 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result507)
  %2704 = bitcast <8 x i1> %convergence.cascade.result507 to i8
  %2705 = call i8 @llvm.cttz.i8(i8 %2704, i1 false)
  %2706 = zext i8 %2705 to i32
  %2707 = select i1 %2703, i32 %2706, i32 0
  %.state508 = load <8 x i64>, ptr %.slot60, align 64
  %2708 = add <8 x i64> %.state508, splat (i64 1)
  %2709 = load <8 x i64>, ptr %.slot60, align 64
  %2710 = select <8 x i1> %convergence.cascade.result507, <8 x i64> %2708, <8 x i64> %2709
  store <8 x i64> %2710, ptr %.slot60, align 64
  store <8 x i1> %convergence.cascade.result507, ptr %current.mask, align 1
  %2711 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result507)
  br i1 %2711, label %schedule.33, label %scheduler.loop

convergence.cascade509:                           ; preds = %convergence.cascade509, %schedule.37
  %convergence.cascade.flow513 = phi <8 x i1> [ %800, %schedule.37 ], [ %2754, %convergence.cascade509 ]
  %convergence.cascade.depth514 = phi i32 [ 0, %schedule.37 ], [ %2755, %convergence.cascade509 ]
  %2712 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow513)
  %2713 = load i32, ptr %current.token, align 4
  %2714 = icmp ne i32 %2713, 0
  %2715 = and i1 %2712, %2714
  %2716 = sub i32 %2713, 1
  %2717 = select i1 %2715, i32 %2716, i32 0
  %2718 = load i8, ptr %frame.active, align 1
  %2719 = trunc i32 %2717 to i8
  %2720 = shl i8 1, %2719
  %2721 = and i8 %2718, %2720
  %2722 = icmp ne i8 %2721, 0
  %2723 = load <8 x i32>, ptr %frame.static.id, align 32
  %2724 = extractelement <8 x i32> %2723, i32 %2717
  %convergence.target.pointer515 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %2724
  %convergence.dynamic.target516 = load i32, ptr %convergence.target.pointer515, align 4
  %2725 = icmp eq i32 %convergence.dynamic.target516, 37
  %2726 = and i1 %2722, %2725
  %2727 = and i1 %2715, %2726
  %2728 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2717
  %2729 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2717
  %2730 = load <8 x i1>, ptr %2728, align 1
  %2731 = load <8 x i1>, ptr %2729, align 1
  %2732 = or <8 x i1> %2731, %convergence.cascade.flow513
  %2733 = load <8 x i1>, ptr %live.mask, align 1
  %2734 = and <8 x i1> %2730, %2733
  %2735 = icmp eq <8 x i1> %2732, %2734
  %2736 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2735)
  %2737 = and i1 %2727, %2736
  %2738 = select i1 %2737, <8 x i1> zeroinitializer, <8 x i1> %2732
  %2739 = select i1 %2727, <8 x i1> %2738, <8 x i1> %2731
  store <8 x i1> %2739, ptr %2729, align 1
  %2740 = select i1 %2737, <8 x i1> zeroinitializer, <8 x i1> %2730
  store <8 x i1> %2740, ptr %2728, align 1
  %2741 = trunc i32 %2717 to i8
  %2742 = shl i8 1, %2741
  %2743 = xor i8 %2742, -1
  %2744 = and i8 %2718, %2743
  %2745 = select i1 %2737, i8 %2744, i8 %2718
  store i8 %2745, ptr %frame.active, align 1
  %.splatinsert517 = insertelement <8 x i1> poison, i1 %2727, i64 0
  %.splat518 = shufflevector <8 x i1> %.splatinsert517, <8 x i1> poison, <8 x i32> zeroinitializer
  %2746 = and <8 x i1> %convergence.cascade.flow513, %.splat518
  %2747 = load <8 x i1>, ptr %runnable.mask, align 1
  %2748 = xor <8 x i1> %2746, splat (i1 true)
  %2749 = and <8 x i1> %2747, %2748
  store <8 x i1> %2749, ptr %runnable.mask, align 1
  %.splatinsert519 = insertelement <8 x i1> poison, i1 %2737, i64 0
  %.splat520 = shufflevector <8 x i1> %.splatinsert519, <8 x i1> poison, <8 x i32> zeroinitializer
  %2750 = select <8 x i1> %.splat520, <8 x i1> %2732, <8 x i1> zeroinitializer
  %2751 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2752 = extractelement <8 x i32> %2751, i32 %2717
  %2753 = select i1 %2737, i32 %2752, i32 %2713
  store i32 %2753, ptr %current.token, align 4
  %.splatinsert521 = insertelement <8 x i1> poison, i1 %2727, i64 0
  %.splat522 = shufflevector <8 x i1> %.splatinsert521, <8 x i1> poison, <8 x i32> zeroinitializer
  %2754 = select <8 x i1> %.splat522, <8 x i1> %2750, <8 x i1> %convergence.cascade.flow513
  %2755 = add i32 %convergence.cascade.depth514, 1
  %2756 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2754)
  %2757 = icmp ult i32 %2755, 8
  %2758 = and i1 %2756, %2757
  %2759 = and i1 %2727, %2758
  %convergence.parent.token523 = load i32, ptr %current.token, align 4
  %convergence.parent.present524 = icmp ne i32 %convergence.parent.token523, 0
  %2760 = and i1 %2759, %convergence.parent.present524
  br i1 %2760, label %convergence.cascade509, label %convergence.cascade.exit510

convergence.cascade.exit510:                      ; preds = %convergence.cascade509, %schedule.37
  %convergence.cascade.result525 = phi <8 x i1> [ %800, %schedule.37 ], [ %2754, %convergence.cascade509 ]
  %2761 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result525)
  br i1 %2761, label %convergence.target.37.ready, label %scheduler.loop

convergence.target.37.ready:                      ; preds = %convergence.cascade.exit510
  %2762 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result525)
  %2763 = bitcast <8 x i1> %convergence.cascade.result525 to i8
  %2764 = call i8 @llvm.cttz.i8(i8 %2763, i1 false)
  %2765 = zext i8 %2764 to i32
  %2766 = select i1 %2762, i32 %2765, i32 0
  %tile_snapshot.spill.load526 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill53, align 64
  %2767 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load526, 0
  %2768 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load526, 1
  %2769 = add <8 x i64> %2768, splat (i64 992)
  %2770 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2767, 0
  %2771 = insertvalue { <8 x ptr>, <8 x i64> } %2770, <8 x i64> %2769, 1
  %2772 = extractvalue { <8 x ptr>, <8 x i64> } %13, 0
  %2773 = extractvalue { <8 x ptr>, <8 x i64> } %2771, 1
  %2774 = extractelement <8 x ptr> %2772, i32 0
  %2775 = extractelement <8 x i64> %2773, i32 %2766
  %2776 = zext i32 %2766 to i64
  %2777 = mul i64 %2776, 4
  %2778 = sub i64 %2775, %2777
  %2779 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result525)
  %2780 = select i1 %2779, i64 %2778, i64 0
  %private.contiguous.address527 = getelementptr i8, ptr %2774, i64 %2780
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address527, align 4
  %2781 = select <8 x i1> %convergence.cascade.result525, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load528 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill53, align 64
  %2782 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load528, 0
  %2783 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load528, 1
  %2784 = add <8 x i64> %2783, splat (i64 2016)
  %2785 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2782, 0
  %2786 = insertvalue { <8 x ptr>, <8 x i64> } %2785, <8 x i64> %2784, 1
  %2787 = extractvalue { <8 x ptr>, <8 x i64> } %13, 0
  %2788 = extractvalue { <8 x ptr>, <8 x i64> } %2786, 1
  %2789 = extractelement <8 x ptr> %2787, i32 0
  %2790 = extractelement <8 x i64> %2788, i32 %2766
  %2791 = zext i32 %2766 to i64
  %2792 = mul i64 %2791, 4
  %2793 = sub i64 %2790, %2792
  %2794 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result525)
  %2795 = select i1 %2794, i64 %2793, i64 0
  %private.contiguous.address529 = getelementptr i8, ptr %2789, i64 %2795
  %private.contiguous.load530 = load <8 x float>, ptr %private.contiguous.address529, align 4
  %2796 = select <8 x i1> %convergence.cascade.result525, <8 x float> %private.contiguous.load530, <8 x float> zeroinitializer
  %tile_snapshot.spill.load531 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill53, align 64
  %2797 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load531, 0
  %2798 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load531, 1
  %2799 = add <8 x i64> %2798, splat (i64 3040)
  %2800 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2797, 0
  %2801 = insertvalue { <8 x ptr>, <8 x i64> } %2800, <8 x i64> %2799, 1
  %2802 = extractvalue { <8 x ptr>, <8 x i64> } %13, 0
  %2803 = extractvalue { <8 x ptr>, <8 x i64> } %2801, 1
  %2804 = extractelement <8 x ptr> %2802, i32 0
  %2805 = extractelement <8 x i64> %2803, i32 %2766
  %2806 = zext i32 %2766 to i64
  %2807 = mul i64 %2806, 4
  %2808 = sub i64 %2805, %2807
  %2809 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result525)
  %2810 = select i1 %2809, i64 %2808, i64 0
  %private.contiguous.address532 = getelementptr i8, ptr %2804, i64 %2810
  %private.contiguous.load533 = load <8 x float>, ptr %private.contiguous.address532, align 4
  %2811 = select <8 x i1> %convergence.cascade.result525, <8 x float> %private.contiguous.load533, <8 x float> zeroinitializer
  %tile_snapshot.spill.load534 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill53, align 64
  %2812 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load534, 0
  %2813 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load534, 1
  %2814 = add <8 x i64> %2813, splat (i64 4064)
  %2815 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2812, 0
  %2816 = insertvalue { <8 x ptr>, <8 x i64> } %2815, <8 x i64> %2814, 1
  %2817 = extractvalue { <8 x ptr>, <8 x i64> } %13, 0
  %2818 = extractvalue { <8 x ptr>, <8 x i64> } %2816, 1
  %2819 = extractelement <8 x ptr> %2817, i32 0
  %2820 = extractelement <8 x i64> %2818, i32 %2766
  %2821 = zext i32 %2766 to i64
  %2822 = mul i64 %2821, 4
  %2823 = sub i64 %2820, %2822
  %2824 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result525)
  %2825 = select i1 %2824, i64 %2823, i64 0
  %private.contiguous.address535 = getelementptr i8, ptr %2819, i64 %2825
  %private.contiguous.load536 = load <8 x float>, ptr %private.contiguous.address535, align 4
  %2826 = select <8 x i1> %convergence.cascade.result525, <8 x float> %private.contiguous.load536, <8 x float> zeroinitializer
  %.state537 = load <8 x i64>, ptr %.slot, align 64
  %2827 = add <8 x i64> %.state537, splat (i64 1)
  %2828 = load <8 x i64>, ptr %.slot, align 64
  %2829 = select <8 x i1> %convergence.cascade.result525, <8 x i64> %2827, <8 x i64> %2828
  store <8 x i64> %2829, ptr %.slot, align 64
  %2830 = load volatile <8 x float>, ptr %.slot20, align 32
  %2831 = select <8 x i1> %convergence.cascade.result525, <8 x float> %2781, <8 x float> %2830
  store volatile <8 x float> %2831, ptr %.slot20, align 32
  %2832 = load volatile <8 x float>, ptr %.slot21, align 32
  %2833 = select <8 x i1> %convergence.cascade.result525, <8 x float> %2796, <8 x float> %2832
  store volatile <8 x float> %2833, ptr %.slot21, align 32
  %2834 = load volatile <8 x float>, ptr %.slot22, align 32
  %2835 = select <8 x i1> %convergence.cascade.result525, <8 x float> %2811, <8 x float> %2834
  store volatile <8 x float> %2835, ptr %.slot22, align 32
  %2836 = load volatile <8 x float>, ptr %.slot23, align 32
  %2837 = select <8 x i1> %convergence.cascade.result525, <8 x float> %2826, <8 x float> %2836
  store volatile <8 x float> %2837, ptr %.slot23, align 32
  store <8 x i1> %convergence.cascade.result525, ptr %current.mask, align 1
  %2838 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result525)
  br i1 %2838, label %schedule.1, label %scheduler.loop

convergence.cascade538:                           ; preds = %convergence.cascade538, %schedule.38
  %convergence.cascade.flow542 = phi <8 x i1> [ %801, %schedule.38 ], [ %2881, %convergence.cascade538 ]
  %convergence.cascade.depth543 = phi i32 [ 0, %schedule.38 ], [ %2882, %convergence.cascade538 ]
  %2839 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow542)
  %2840 = load i32, ptr %current.token, align 4
  %2841 = icmp ne i32 %2840, 0
  %2842 = and i1 %2839, %2841
  %2843 = sub i32 %2840, 1
  %2844 = select i1 %2842, i32 %2843, i32 0
  %2845 = load i8, ptr %frame.active, align 1
  %2846 = trunc i32 %2844 to i8
  %2847 = shl i8 1, %2846
  %2848 = and i8 %2845, %2847
  %2849 = icmp ne i8 %2848, 0
  %2850 = load <8 x i32>, ptr %frame.static.id, align 32
  %2851 = extractelement <8 x i32> %2850, i32 %2844
  %convergence.target.pointer544 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %2851
  %convergence.dynamic.target545 = load i32, ptr %convergence.target.pointer544, align 4
  %2852 = icmp eq i32 %convergence.dynamic.target545, 38
  %2853 = and i1 %2849, %2852
  %2854 = and i1 %2842, %2853
  %2855 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2844
  %2856 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2844
  %2857 = load <8 x i1>, ptr %2855, align 1
  %2858 = load <8 x i1>, ptr %2856, align 1
  %2859 = or <8 x i1> %2858, %convergence.cascade.flow542
  %2860 = load <8 x i1>, ptr %live.mask, align 1
  %2861 = and <8 x i1> %2857, %2860
  %2862 = icmp eq <8 x i1> %2859, %2861
  %2863 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2862)
  %2864 = and i1 %2854, %2863
  %2865 = select i1 %2864, <8 x i1> zeroinitializer, <8 x i1> %2859
  %2866 = select i1 %2854, <8 x i1> %2865, <8 x i1> %2858
  store <8 x i1> %2866, ptr %2856, align 1
  %2867 = select i1 %2864, <8 x i1> zeroinitializer, <8 x i1> %2857
  store <8 x i1> %2867, ptr %2855, align 1
  %2868 = trunc i32 %2844 to i8
  %2869 = shl i8 1, %2868
  %2870 = xor i8 %2869, -1
  %2871 = and i8 %2845, %2870
  %2872 = select i1 %2864, i8 %2871, i8 %2845
  store i8 %2872, ptr %frame.active, align 1
  %.splatinsert546 = insertelement <8 x i1> poison, i1 %2854, i64 0
  %.splat547 = shufflevector <8 x i1> %.splatinsert546, <8 x i1> poison, <8 x i32> zeroinitializer
  %2873 = and <8 x i1> %convergence.cascade.flow542, %.splat547
  %2874 = load <8 x i1>, ptr %runnable.mask, align 1
  %2875 = xor <8 x i1> %2873, splat (i1 true)
  %2876 = and <8 x i1> %2874, %2875
  store <8 x i1> %2876, ptr %runnable.mask, align 1
  %.splatinsert548 = insertelement <8 x i1> poison, i1 %2864, i64 0
  %.splat549 = shufflevector <8 x i1> %.splatinsert548, <8 x i1> poison, <8 x i32> zeroinitializer
  %2877 = select <8 x i1> %.splat549, <8 x i1> %2859, <8 x i1> zeroinitializer
  %2878 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2879 = extractelement <8 x i32> %2878, i32 %2844
  %2880 = select i1 %2864, i32 %2879, i32 %2840
  store i32 %2880, ptr %current.token, align 4
  %.splatinsert550 = insertelement <8 x i1> poison, i1 %2854, i64 0
  %.splat551 = shufflevector <8 x i1> %.splatinsert550, <8 x i1> poison, <8 x i32> zeroinitializer
  %2881 = select <8 x i1> %.splat551, <8 x i1> %2877, <8 x i1> %convergence.cascade.flow542
  %2882 = add i32 %convergence.cascade.depth543, 1
  %2883 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2881)
  %2884 = icmp ult i32 %2882, 8
  %2885 = and i1 %2883, %2884
  %2886 = and i1 %2854, %2885
  %convergence.parent.token552 = load i32, ptr %current.token, align 4
  %convergence.parent.present553 = icmp ne i32 %convergence.parent.token552, 0
  %2887 = and i1 %2886, %convergence.parent.present553
  br i1 %2887, label %convergence.cascade538, label %convergence.cascade.exit539

convergence.cascade.exit539:                      ; preds = %convergence.cascade538, %schedule.38
  %convergence.cascade.result554 = phi <8 x i1> [ %801, %schedule.38 ], [ %2881, %convergence.cascade538 ]
  %2888 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result554)
  br i1 %2888, label %convergence.target.38.ready, label %scheduler.loop

convergence.target.38.ready:                      ; preds = %convergence.cascade.exit539
  %2889 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result554)
  %2890 = bitcast <8 x i1> %convergence.cascade.result554 to i8
  %2891 = call i8 @llvm.cttz.i8(i8 %2890, i1 false)
  %2892 = zext i8 %2891 to i32
  %2893 = select i1 %2889, i32 %2892, i32 0
  %2894 = load <8 x i1>, ptr %live.mask, align 1
  %2895 = xor <8 x i1> %convergence.cascade.result554, splat (i1 true)
  %2896 = and <8 x i1> %2894, %2895
  store <8 x i1> %2896, ptr %live.mask, align 1
  %2897 = load <8 x i1>, ptr %runnable.mask, align 1
  %2898 = xor <8 x i1> %convergence.cascade.result554, splat (i1 true)
  %2899 = and <8 x i1> %2897, %2898
  store <8 x i1> %2899, ptr %runnable.mask, align 1
  %return.active.frames = load i8, ptr %frame.active, align 1
  %return.frames.present = icmp ne i8 %return.active.frames, 0
  br i1 %return.frames.present, label %return.frame.cleanup, label %return.frame.cleanup.done

return.frame.cleanup:                             ; preds = %convergence.target.38.ready
  %2900 = load i8, ptr %frame.active, align 1
  %2901 = and i8 %2900, 1
  %2902 = icmp ne i8 %2901, 0
  %2903 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 0
  %2904 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 0
  %2905 = load <8 x i1>, ptr %2903, align 1
  %2906 = load <8 x i1>, ptr %2904, align 1
  %2907 = and <8 x i1> %2905, %2896
  %2908 = icmp eq <8 x i1> %2906, %2907
  %2909 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2908)
  %2910 = and i1 %2902, %2909
  %.splatinsert555 = insertelement <8 x i1> poison, i1 %2910, i64 0
  %.splat556 = shufflevector <8 x i1> %.splatinsert555, <8 x i1> poison, <8 x i32> zeroinitializer
  %2911 = select <8 x i1> %.splat556, <8 x i1> %2906, <8 x i1> zeroinitializer
  %2912 = select i1 %2910, <8 x i1> zeroinitializer, <8 x i1> %2907
  store <8 x i1> %2912, ptr %2903, align 1
  %2913 = select i1 %2910, <8 x i1> zeroinitializer, <8 x i1> %2906
  store <8 x i1> %2913, ptr %2904, align 1
  %2914 = and i8 %2900, -2
  %2915 = select i1 %2910, i8 %2914, i8 %2900
  store i8 %2915, ptr %frame.active, align 1
  %2916 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2917 = extractelement <8 x i32> %2916, i32 0
  %2918 = load <8 x i32>, ptr %frame.static.id, align 32
  %2919 = extractelement <8 x i32> %2918, i32 0
  %convergence.target.pointer557 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %2919
  %convergence.dynamic.target558 = load i32, ptr %convergence.target.pointer557, align 4
  %2920 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2911)
  %2921 = load i32, ptr %ready.count, align 4
  %2922 = icmp uge i32 %2921, 8
  %2923 = and i1 %2920, %2922
  br i1 %2923, label %ready.overflow.trap559, label %ready.overflow.resume560

return.frame.cleanup.done:                        ; preds = %ready.overflow.resume602, %convergence.target.38.ready
  br label %scheduler.loop

ready.overflow.trap559:                           ; preds = %return.frame.cleanup
  call void @llvm.trap()
  unreachable

ready.overflow.resume560:                         ; preds = %return.frame.cleanup
  %2924 = select i1 %2920, i32 %2921, i32 0
  %2925 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2924
  %2926 = load <8 x i1>, ptr %2925, align 1
  %2927 = select i1 %2920, <8 x i1> %2911, <8 x i1> %2926
  store <8 x i1> %2927, ptr %2925, align 1
  %2928 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2924
  %2929 = load i32, ptr %2928, align 4
  %2930 = select i1 %2920, i32 %convergence.dynamic.target558, i32 %2929
  store i32 %2930, ptr %2928, align 4
  %2931 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2924
  %2932 = load i32, ptr %2931, align 4
  %2933 = select i1 %2920, i32 %2917, i32 %2932
  store i32 %2933, ptr %2931, align 4
  %2934 = add i32 %2921, 1
  %2935 = select i1 %2920, i32 %2934, i32 %2921
  store i32 %2935, ptr %ready.count, align 4
  %2936 = load <8 x i1>, ptr %runnable.mask, align 1
  %2937 = or <8 x i1> %2936, %2911
  store <8 x i1> %2937, ptr %runnable.mask, align 1
  %2938 = load i8, ptr %frame.active, align 1
  %2939 = and i8 %2938, 2
  %2940 = icmp ne i8 %2939, 0
  %2941 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 1
  %2942 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 1
  %2943 = load <8 x i1>, ptr %2941, align 1
  %2944 = load <8 x i1>, ptr %2942, align 1
  %2945 = and <8 x i1> %2943, %2896
  %2946 = icmp eq <8 x i1> %2944, %2945
  %2947 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2946)
  %2948 = and i1 %2940, %2947
  %.splatinsert561 = insertelement <8 x i1> poison, i1 %2948, i64 0
  %.splat562 = shufflevector <8 x i1> %.splatinsert561, <8 x i1> poison, <8 x i32> zeroinitializer
  %2949 = select <8 x i1> %.splat562, <8 x i1> %2944, <8 x i1> zeroinitializer
  %2950 = select i1 %2948, <8 x i1> zeroinitializer, <8 x i1> %2945
  store <8 x i1> %2950, ptr %2941, align 1
  %2951 = select i1 %2948, <8 x i1> zeroinitializer, <8 x i1> %2944
  store <8 x i1> %2951, ptr %2942, align 1
  %2952 = and i8 %2938, -3
  %2953 = select i1 %2948, i8 %2952, i8 %2938
  store i8 %2953, ptr %frame.active, align 1
  %2954 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2955 = extractelement <8 x i32> %2954, i32 1
  %2956 = load <8 x i32>, ptr %frame.static.id, align 32
  %2957 = extractelement <8 x i32> %2956, i32 1
  %convergence.target.pointer563 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %2957
  %convergence.dynamic.target564 = load i32, ptr %convergence.target.pointer563, align 4
  %2958 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2949)
  %2959 = load i32, ptr %ready.count, align 4
  %2960 = icmp uge i32 %2959, 8
  %2961 = and i1 %2958, %2960
  br i1 %2961, label %ready.overflow.trap565, label %ready.overflow.resume566

ready.overflow.trap565:                           ; preds = %ready.overflow.resume560
  call void @llvm.trap()
  unreachable

ready.overflow.resume566:                         ; preds = %ready.overflow.resume560
  %2962 = select i1 %2958, i32 %2959, i32 0
  %2963 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2962
  %2964 = load <8 x i1>, ptr %2963, align 1
  %2965 = select i1 %2958, <8 x i1> %2949, <8 x i1> %2964
  store <8 x i1> %2965, ptr %2963, align 1
  %2966 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2962
  %2967 = load i32, ptr %2966, align 4
  %2968 = select i1 %2958, i32 %convergence.dynamic.target564, i32 %2967
  store i32 %2968, ptr %2966, align 4
  %2969 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2962
  %2970 = load i32, ptr %2969, align 4
  %2971 = select i1 %2958, i32 %2955, i32 %2970
  store i32 %2971, ptr %2969, align 4
  %2972 = add i32 %2959, 1
  %2973 = select i1 %2958, i32 %2972, i32 %2959
  store i32 %2973, ptr %ready.count, align 4
  %2974 = load <8 x i1>, ptr %runnable.mask, align 1
  %2975 = or <8 x i1> %2974, %2949
  store <8 x i1> %2975, ptr %runnable.mask, align 1
  %2976 = load i8, ptr %frame.active, align 1
  %2977 = and i8 %2976, 4
  %2978 = icmp ne i8 %2977, 0
  %2979 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 2
  %2980 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 2
  %2981 = load <8 x i1>, ptr %2979, align 1
  %2982 = load <8 x i1>, ptr %2980, align 1
  %2983 = and <8 x i1> %2981, %2896
  %2984 = icmp eq <8 x i1> %2982, %2983
  %2985 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2984)
  %2986 = and i1 %2978, %2985
  %.splatinsert567 = insertelement <8 x i1> poison, i1 %2986, i64 0
  %.splat568 = shufflevector <8 x i1> %.splatinsert567, <8 x i1> poison, <8 x i32> zeroinitializer
  %2987 = select <8 x i1> %.splat568, <8 x i1> %2982, <8 x i1> zeroinitializer
  %2988 = select i1 %2986, <8 x i1> zeroinitializer, <8 x i1> %2983
  store <8 x i1> %2988, ptr %2979, align 1
  %2989 = select i1 %2986, <8 x i1> zeroinitializer, <8 x i1> %2982
  store <8 x i1> %2989, ptr %2980, align 1
  %2990 = and i8 %2976, -5
  %2991 = select i1 %2986, i8 %2990, i8 %2976
  store i8 %2991, ptr %frame.active, align 1
  %2992 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2993 = extractelement <8 x i32> %2992, i32 2
  %2994 = load <8 x i32>, ptr %frame.static.id, align 32
  %2995 = extractelement <8 x i32> %2994, i32 2
  %convergence.target.pointer569 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %2995
  %convergence.dynamic.target570 = load i32, ptr %convergence.target.pointer569, align 4
  %2996 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2987)
  %2997 = load i32, ptr %ready.count, align 4
  %2998 = icmp uge i32 %2997, 8
  %2999 = and i1 %2996, %2998
  br i1 %2999, label %ready.overflow.trap571, label %ready.overflow.resume572

ready.overflow.trap571:                           ; preds = %ready.overflow.resume566
  call void @llvm.trap()
  unreachable

ready.overflow.resume572:                         ; preds = %ready.overflow.resume566
  %3000 = select i1 %2996, i32 %2997, i32 0
  %3001 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3000
  %3002 = load <8 x i1>, ptr %3001, align 1
  %3003 = select i1 %2996, <8 x i1> %2987, <8 x i1> %3002
  store <8 x i1> %3003, ptr %3001, align 1
  %3004 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3000
  %3005 = load i32, ptr %3004, align 4
  %3006 = select i1 %2996, i32 %convergence.dynamic.target570, i32 %3005
  store i32 %3006, ptr %3004, align 4
  %3007 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3000
  %3008 = load i32, ptr %3007, align 4
  %3009 = select i1 %2996, i32 %2993, i32 %3008
  store i32 %3009, ptr %3007, align 4
  %3010 = add i32 %2997, 1
  %3011 = select i1 %2996, i32 %3010, i32 %2997
  store i32 %3011, ptr %ready.count, align 4
  %3012 = load <8 x i1>, ptr %runnable.mask, align 1
  %3013 = or <8 x i1> %3012, %2987
  store <8 x i1> %3013, ptr %runnable.mask, align 1
  %3014 = load i8, ptr %frame.active, align 1
  %3015 = and i8 %3014, 8
  %3016 = icmp ne i8 %3015, 0
  %3017 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 3
  %3018 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 3
  %3019 = load <8 x i1>, ptr %3017, align 1
  %3020 = load <8 x i1>, ptr %3018, align 1
  %3021 = and <8 x i1> %3019, %2896
  %3022 = icmp eq <8 x i1> %3020, %3021
  %3023 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3022)
  %3024 = and i1 %3016, %3023
  %.splatinsert573 = insertelement <8 x i1> poison, i1 %3024, i64 0
  %.splat574 = shufflevector <8 x i1> %.splatinsert573, <8 x i1> poison, <8 x i32> zeroinitializer
  %3025 = select <8 x i1> %.splat574, <8 x i1> %3020, <8 x i1> zeroinitializer
  %3026 = select i1 %3024, <8 x i1> zeroinitializer, <8 x i1> %3021
  store <8 x i1> %3026, ptr %3017, align 1
  %3027 = select i1 %3024, <8 x i1> zeroinitializer, <8 x i1> %3020
  store <8 x i1> %3027, ptr %3018, align 1
  %3028 = and i8 %3014, -9
  %3029 = select i1 %3024, i8 %3028, i8 %3014
  store i8 %3029, ptr %frame.active, align 1
  %3030 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3031 = extractelement <8 x i32> %3030, i32 3
  %3032 = load <8 x i32>, ptr %frame.static.id, align 32
  %3033 = extractelement <8 x i32> %3032, i32 3
  %convergence.target.pointer575 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %3033
  %convergence.dynamic.target576 = load i32, ptr %convergence.target.pointer575, align 4
  %3034 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3025)
  %3035 = load i32, ptr %ready.count, align 4
  %3036 = icmp uge i32 %3035, 8
  %3037 = and i1 %3034, %3036
  br i1 %3037, label %ready.overflow.trap577, label %ready.overflow.resume578

ready.overflow.trap577:                           ; preds = %ready.overflow.resume572
  call void @llvm.trap()
  unreachable

ready.overflow.resume578:                         ; preds = %ready.overflow.resume572
  %3038 = select i1 %3034, i32 %3035, i32 0
  %3039 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3038
  %3040 = load <8 x i1>, ptr %3039, align 1
  %3041 = select i1 %3034, <8 x i1> %3025, <8 x i1> %3040
  store <8 x i1> %3041, ptr %3039, align 1
  %3042 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3038
  %3043 = load i32, ptr %3042, align 4
  %3044 = select i1 %3034, i32 %convergence.dynamic.target576, i32 %3043
  store i32 %3044, ptr %3042, align 4
  %3045 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3038
  %3046 = load i32, ptr %3045, align 4
  %3047 = select i1 %3034, i32 %3031, i32 %3046
  store i32 %3047, ptr %3045, align 4
  %3048 = add i32 %3035, 1
  %3049 = select i1 %3034, i32 %3048, i32 %3035
  store i32 %3049, ptr %ready.count, align 4
  %3050 = load <8 x i1>, ptr %runnable.mask, align 1
  %3051 = or <8 x i1> %3050, %3025
  store <8 x i1> %3051, ptr %runnable.mask, align 1
  %3052 = load i8, ptr %frame.active, align 1
  %3053 = and i8 %3052, 16
  %3054 = icmp ne i8 %3053, 0
  %3055 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 4
  %3056 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 4
  %3057 = load <8 x i1>, ptr %3055, align 1
  %3058 = load <8 x i1>, ptr %3056, align 1
  %3059 = and <8 x i1> %3057, %2896
  %3060 = icmp eq <8 x i1> %3058, %3059
  %3061 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3060)
  %3062 = and i1 %3054, %3061
  %.splatinsert579 = insertelement <8 x i1> poison, i1 %3062, i64 0
  %.splat580 = shufflevector <8 x i1> %.splatinsert579, <8 x i1> poison, <8 x i32> zeroinitializer
  %3063 = select <8 x i1> %.splat580, <8 x i1> %3058, <8 x i1> zeroinitializer
  %3064 = select i1 %3062, <8 x i1> zeroinitializer, <8 x i1> %3059
  store <8 x i1> %3064, ptr %3055, align 1
  %3065 = select i1 %3062, <8 x i1> zeroinitializer, <8 x i1> %3058
  store <8 x i1> %3065, ptr %3056, align 1
  %3066 = and i8 %3052, -17
  %3067 = select i1 %3062, i8 %3066, i8 %3052
  store i8 %3067, ptr %frame.active, align 1
  %3068 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3069 = extractelement <8 x i32> %3068, i32 4
  %3070 = load <8 x i32>, ptr %frame.static.id, align 32
  %3071 = extractelement <8 x i32> %3070, i32 4
  %convergence.target.pointer581 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %3071
  %convergence.dynamic.target582 = load i32, ptr %convergence.target.pointer581, align 4
  %3072 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3063)
  %3073 = load i32, ptr %ready.count, align 4
  %3074 = icmp uge i32 %3073, 8
  %3075 = and i1 %3072, %3074
  br i1 %3075, label %ready.overflow.trap583, label %ready.overflow.resume584

ready.overflow.trap583:                           ; preds = %ready.overflow.resume578
  call void @llvm.trap()
  unreachable

ready.overflow.resume584:                         ; preds = %ready.overflow.resume578
  %3076 = select i1 %3072, i32 %3073, i32 0
  %3077 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3076
  %3078 = load <8 x i1>, ptr %3077, align 1
  %3079 = select i1 %3072, <8 x i1> %3063, <8 x i1> %3078
  store <8 x i1> %3079, ptr %3077, align 1
  %3080 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3076
  %3081 = load i32, ptr %3080, align 4
  %3082 = select i1 %3072, i32 %convergence.dynamic.target582, i32 %3081
  store i32 %3082, ptr %3080, align 4
  %3083 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3076
  %3084 = load i32, ptr %3083, align 4
  %3085 = select i1 %3072, i32 %3069, i32 %3084
  store i32 %3085, ptr %3083, align 4
  %3086 = add i32 %3073, 1
  %3087 = select i1 %3072, i32 %3086, i32 %3073
  store i32 %3087, ptr %ready.count, align 4
  %3088 = load <8 x i1>, ptr %runnable.mask, align 1
  %3089 = or <8 x i1> %3088, %3063
  store <8 x i1> %3089, ptr %runnable.mask, align 1
  %3090 = load i8, ptr %frame.active, align 1
  %3091 = and i8 %3090, 32
  %3092 = icmp ne i8 %3091, 0
  %3093 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 5
  %3094 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 5
  %3095 = load <8 x i1>, ptr %3093, align 1
  %3096 = load <8 x i1>, ptr %3094, align 1
  %3097 = and <8 x i1> %3095, %2896
  %3098 = icmp eq <8 x i1> %3096, %3097
  %3099 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3098)
  %3100 = and i1 %3092, %3099
  %.splatinsert585 = insertelement <8 x i1> poison, i1 %3100, i64 0
  %.splat586 = shufflevector <8 x i1> %.splatinsert585, <8 x i1> poison, <8 x i32> zeroinitializer
  %3101 = select <8 x i1> %.splat586, <8 x i1> %3096, <8 x i1> zeroinitializer
  %3102 = select i1 %3100, <8 x i1> zeroinitializer, <8 x i1> %3097
  store <8 x i1> %3102, ptr %3093, align 1
  %3103 = select i1 %3100, <8 x i1> zeroinitializer, <8 x i1> %3096
  store <8 x i1> %3103, ptr %3094, align 1
  %3104 = and i8 %3090, -33
  %3105 = select i1 %3100, i8 %3104, i8 %3090
  store i8 %3105, ptr %frame.active, align 1
  %3106 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3107 = extractelement <8 x i32> %3106, i32 5
  %3108 = load <8 x i32>, ptr %frame.static.id, align 32
  %3109 = extractelement <8 x i32> %3108, i32 5
  %convergence.target.pointer587 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %3109
  %convergence.dynamic.target588 = load i32, ptr %convergence.target.pointer587, align 4
  %3110 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3101)
  %3111 = load i32, ptr %ready.count, align 4
  %3112 = icmp uge i32 %3111, 8
  %3113 = and i1 %3110, %3112
  br i1 %3113, label %ready.overflow.trap589, label %ready.overflow.resume590

ready.overflow.trap589:                           ; preds = %ready.overflow.resume584
  call void @llvm.trap()
  unreachable

ready.overflow.resume590:                         ; preds = %ready.overflow.resume584
  %3114 = select i1 %3110, i32 %3111, i32 0
  %3115 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3114
  %3116 = load <8 x i1>, ptr %3115, align 1
  %3117 = select i1 %3110, <8 x i1> %3101, <8 x i1> %3116
  store <8 x i1> %3117, ptr %3115, align 1
  %3118 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3114
  %3119 = load i32, ptr %3118, align 4
  %3120 = select i1 %3110, i32 %convergence.dynamic.target588, i32 %3119
  store i32 %3120, ptr %3118, align 4
  %3121 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3114
  %3122 = load i32, ptr %3121, align 4
  %3123 = select i1 %3110, i32 %3107, i32 %3122
  store i32 %3123, ptr %3121, align 4
  %3124 = add i32 %3111, 1
  %3125 = select i1 %3110, i32 %3124, i32 %3111
  store i32 %3125, ptr %ready.count, align 4
  %3126 = load <8 x i1>, ptr %runnable.mask, align 1
  %3127 = or <8 x i1> %3126, %3101
  store <8 x i1> %3127, ptr %runnable.mask, align 1
  %3128 = load i8, ptr %frame.active, align 1
  %3129 = and i8 %3128, 64
  %3130 = icmp ne i8 %3129, 0
  %3131 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 6
  %3132 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 6
  %3133 = load <8 x i1>, ptr %3131, align 1
  %3134 = load <8 x i1>, ptr %3132, align 1
  %3135 = and <8 x i1> %3133, %2896
  %3136 = icmp eq <8 x i1> %3134, %3135
  %3137 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3136)
  %3138 = and i1 %3130, %3137
  %.splatinsert591 = insertelement <8 x i1> poison, i1 %3138, i64 0
  %.splat592 = shufflevector <8 x i1> %.splatinsert591, <8 x i1> poison, <8 x i32> zeroinitializer
  %3139 = select <8 x i1> %.splat592, <8 x i1> %3134, <8 x i1> zeroinitializer
  %3140 = select i1 %3138, <8 x i1> zeroinitializer, <8 x i1> %3135
  store <8 x i1> %3140, ptr %3131, align 1
  %3141 = select i1 %3138, <8 x i1> zeroinitializer, <8 x i1> %3134
  store <8 x i1> %3141, ptr %3132, align 1
  %3142 = and i8 %3128, -65
  %3143 = select i1 %3138, i8 %3142, i8 %3128
  store i8 %3143, ptr %frame.active, align 1
  %3144 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3145 = extractelement <8 x i32> %3144, i32 6
  %3146 = load <8 x i32>, ptr %frame.static.id, align 32
  %3147 = extractelement <8 x i32> %3146, i32 6
  %convergence.target.pointer593 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %3147
  %convergence.dynamic.target594 = load i32, ptr %convergence.target.pointer593, align 4
  %3148 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3139)
  %3149 = load i32, ptr %ready.count, align 4
  %3150 = icmp uge i32 %3149, 8
  %3151 = and i1 %3148, %3150
  br i1 %3151, label %ready.overflow.trap595, label %ready.overflow.resume596

ready.overflow.trap595:                           ; preds = %ready.overflow.resume590
  call void @llvm.trap()
  unreachable

ready.overflow.resume596:                         ; preds = %ready.overflow.resume590
  %3152 = select i1 %3148, i32 %3149, i32 0
  %3153 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3152
  %3154 = load <8 x i1>, ptr %3153, align 1
  %3155 = select i1 %3148, <8 x i1> %3139, <8 x i1> %3154
  store <8 x i1> %3155, ptr %3153, align 1
  %3156 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3152
  %3157 = load i32, ptr %3156, align 4
  %3158 = select i1 %3148, i32 %convergence.dynamic.target594, i32 %3157
  store i32 %3158, ptr %3156, align 4
  %3159 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3152
  %3160 = load i32, ptr %3159, align 4
  %3161 = select i1 %3148, i32 %3145, i32 %3160
  store i32 %3161, ptr %3159, align 4
  %3162 = add i32 %3149, 1
  %3163 = select i1 %3148, i32 %3162, i32 %3149
  store i32 %3163, ptr %ready.count, align 4
  %3164 = load <8 x i1>, ptr %runnable.mask, align 1
  %3165 = or <8 x i1> %3164, %3139
  store <8 x i1> %3165, ptr %runnable.mask, align 1
  %3166 = load i8, ptr %frame.active, align 1
  %3167 = and i8 %3166, -128
  %3168 = icmp ne i8 %3167, 0
  %3169 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 7
  %3170 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 7
  %3171 = load <8 x i1>, ptr %3169, align 1
  %3172 = load <8 x i1>, ptr %3170, align 1
  %3173 = and <8 x i1> %3171, %2896
  %3174 = icmp eq <8 x i1> %3172, %3173
  %3175 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3174)
  %3176 = and i1 %3168, %3175
  %.splatinsert597 = insertelement <8 x i1> poison, i1 %3176, i64 0
  %.splat598 = shufflevector <8 x i1> %.splatinsert597, <8 x i1> poison, <8 x i32> zeroinitializer
  %3177 = select <8 x i1> %.splat598, <8 x i1> %3172, <8 x i1> zeroinitializer
  %3178 = select i1 %3176, <8 x i1> zeroinitializer, <8 x i1> %3173
  store <8 x i1> %3178, ptr %3169, align 1
  %3179 = select i1 %3176, <8 x i1> zeroinitializer, <8 x i1> %3172
  store <8 x i1> %3179, ptr %3170, align 1
  %3180 = and i8 %3166, 127
  %3181 = select i1 %3176, i8 %3180, i8 %3166
  store i8 %3181, ptr %frame.active, align 1
  %3182 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3183 = extractelement <8 x i32> %3182, i32 7
  %3184 = load <8 x i32>, ptr %frame.static.id, align 32
  %3185 = extractelement <8 x i32> %3184, i32 7
  %convergence.target.pointer599 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %3185
  %convergence.dynamic.target600 = load i32, ptr %convergence.target.pointer599, align 4
  %3186 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3177)
  %3187 = load i32, ptr %ready.count, align 4
  %3188 = icmp uge i32 %3187, 8
  %3189 = and i1 %3186, %3188
  br i1 %3189, label %ready.overflow.trap601, label %ready.overflow.resume602

ready.overflow.trap601:                           ; preds = %ready.overflow.resume596
  call void @llvm.trap()
  unreachable

ready.overflow.resume602:                         ; preds = %ready.overflow.resume596
  %3190 = select i1 %3186, i32 %3187, i32 0
  %3191 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3190
  %3192 = load <8 x i1>, ptr %3191, align 1
  %3193 = select i1 %3186, <8 x i1> %3177, <8 x i1> %3192
  store <8 x i1> %3193, ptr %3191, align 1
  %3194 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3190
  %3195 = load i32, ptr %3194, align 4
  %3196 = select i1 %3186, i32 %convergence.dynamic.target600, i32 %3195
  store i32 %3196, ptr %3194, align 4
  %3197 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3190
  %3198 = load i32, ptr %3197, align 4
  %3199 = select i1 %3186, i32 %3183, i32 %3198
  store i32 %3199, ptr %3197, align 4
  %3200 = add i32 %3187, 1
  %3201 = select i1 %3186, i32 %3200, i32 %3187
  store i32 %3201, ptr %ready.count, align 4
  %3202 = load <8 x i1>, ptr %runnable.mask, align 1
  %3203 = or <8 x i1> %3202, %3177
  store <8 x i1> %3203, ptr %runnable.mask, align 1
  br label %return.frame.cleanup.done
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.and.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #3

define dso_local void @tile_inclusive_scan.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @tile_inclusive_scan(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(write) }

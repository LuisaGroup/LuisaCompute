	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function tile_inclusive_scan
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_tile_inclusive_scan:                   ; @tile_inclusive_scan
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-80]!           ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #6, lsl #12             ; =24576
	sub	sp, sp, #512
	dup.4s	v1, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q2, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q3, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v0, v1, v3
	cmhi.4s	v1, v1, v2
	uzp1.8h	v4, v1, v0
	str	q4, [sp, #304]                  ; 16-byte Folded Spill
	umaxv.8h	h4, v4
	fmov	w8, s4
	tbz	w8, #0, LBB0_59
; %bb.1:                                ; %direct.activate
	mov	x8, #0                          ; =0x0
	sshll.2d	v4, v1, #0
	sshll.2d	v5, v0, #0
	sshll2.2d	v6, v1, #0
	sshll2.2d	v7, v0, #0
	ldr	w9, [x1]
	ldr	w10, [x1, #36]
	add	w9, w10, w9, lsl #5
	dup.4s	v16, w9
	add.4s	v3, v16, v3
	add	x9, sp, #384
	add.4s	v2, v16, v2
	ldr	x10, [x0]
	and.16b	v2, v1, v2
	ldr	x11, [x0, #16]
	and.16b	v3, v0, v3
	ushll.2d	v16, v2, #2
	ushll.2d	v17, v3, #2
	ushll2.2d	v2, v2, #2
	ushll2.2d	v3, v3, #2
	and.16b	v3, v7, v3
	and.16b	v2, v6, v2
	stp	q2, q3, [sp, #336]              ; 32-byte Folded Spill
	and.16b	v5, v5, v17
	and.16b	v6, v4, v16
	mvni.4s	v7, #127, msl #16
	and.16b	v2, v0, v7
	and.16b	v3, v1, v7
	movi.2d	v18, #0000000000000000
Lloh4:
	adrp	x12, lCPI0_2@PAGE
Lloh5:
	ldr	q4, [x12, lCPI0_2@PAGEOFF]
	str	q4, [sp, #288]                  ; 16-byte Folded Spill
	add	x12, sp, #5, lsl #12            ; =20480
	add	x12, x12, #384
	add	x13, sp, #4, lsl #12            ; =16384
	add	x13, x13, #384
	add	x14, sp, #3, lsl #12            ; =12288
	add	x14, x14, #384
	add	x15, sp, #2, lsl #12            ; =8192
	add	x15, x15, #384
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #384
	add	x17, sp, #6, lsl #12            ; =24576
	add	x17, x17, #384
                                        ; implicit-def: $q4
                                        ; kill: killed $q4
                                        ; implicit-def: $q4
                                        ; kill: killed $q4
                                        ; implicit-def: $q4
                                        ; kill: killed $q4
                                        ; implicit-def: $q4
                                        ; kill: killed $q4
                                        ; implicit-def: $q4
                                        ; kill: killed $q4
                                        ; implicit-def: $q4
                                        ; kill: killed $q4
                                        ; implicit-def: $q4
                                        ; kill: killed $q4
                                        ; implicit-def: $q4
                                        ; kill: killed $q4
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v31, #0000000000000000
	movi.2d	v8, #0000000000000000
	movi.2d	v9, #0000000000000000
	movi.2d	v10, #0000000000000000
	movi.2d	v11, #0000000000000000
	movi.2d	v12, #0000000000000000
	movi.2d	v13, #0000000000000000
	movi.2d	v14, #0000000000000000
	movi.2d	v15, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
	str	q3, [sp, #272]                  ; 16-byte Folded Spill
	mov.16b	v4, v2
	movi.2d	v27, #0000000000000000
	mov.16b	v16, v3
	mov.16b	v26, v2
	str	q3, [sp, #320]                  ; 16-byte Folded Spill
	mov.16b	v19, v2
	b	LBB0_3
LBB0_2:                                 ; %direct.false268
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldp	q4, q3, [x9, #992]
	ldr	q2, [x9, #2016]
	str	q2, [sp, #32]                   ; 16-byte Folded Spill
	ldr	q16, [x9, #2032]
	ldr	q2, [x9, #3040]
	str	q2, [sp, #16]                   ; 16-byte Folded Spill
	ldr	q19, [x9, #3056]
	ldr	q2, [x9, #4064]
	str	q2, [sp]                        ; 16-byte Folded Spill
	ldr	q2, [sp, #48]                   ; 16-byte Folded Reload
	bit.16b	v2, v3, v0
	bit.16b	v26, v4, v1
	str	q26, [sp, #320]                 ; 16-byte Folded Spill
	ldr	q17, [x9, #4080]
	add	x8, x8, #1
	ldr	q26, [sp, #64]                  ; 16-byte Folded Reload
	bit.16b	v26, v16, v0
	ldp	q16, q4, [sp, #80]              ; 32-byte Folded Reload
	ldr	q3, [sp, #32]                   ; 16-byte Folded Reload
	bit.16b	v16, v3, v1
	bit.16b	v4, v19, v0
	ldr	q19, [sp, #16]                  ; 16-byte Folded Reload
	ldr	q3, [sp, #272]                  ; 16-byte Folded Reload
	bit.16b	v3, v19, v1
	str	q3, [sp, #272]                  ; 16-byte Folded Spill
	ldp	q3, q19, [sp, #240]             ; 32-byte Folded Reload
	bit.16b	v19, v17, v0
	ldr	q17, [sp]                       ; 16-byte Folded Reload
	bit.16b	v3, v17, v1
	cmp	x8, #32
	b.eq	LBB0_59
LBB0_3:                                 ; %direct.true
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_5 Depth 2
                                        ;     Child Loop BB0_23 Depth 2
                                        ;     Child Loop BB0_27 Depth 2
                                        ;     Child Loop BB0_31 Depth 2
                                        ;     Child Loop BB0_35 Depth 2
                                        ;     Child Loop BB0_39 Depth 2
                                        ;     Child Loop BB0_43 Depth 2
	str	q19, [sp, #256]                 ; 16-byte Folded Spill
	mov	x1, #0                          ; =0x0
	mov.16b	v19, v4
	ldr	q4, [sp, #112]                  ; 16-byte Folded Reload
	stp	q2, q26, [sp, #48]              ; 32-byte Folded Spill
	bit.16b	v4, v2, v0
	stp	q19, q4, [sp, #96]              ; 32-byte Folded Spill
	str	q4, [x9, #24592]
	ldr	q4, [sp, #128]                  ; 16-byte Folded Reload
	ldr	q2, [sp, #320]                  ; 16-byte Folded Reload
	bit.16b	v4, v2, v1
	str	q4, [sp, #128]                  ; 16-byte Folded Spill
	str	q4, [x9, #24576]
	ldr	q4, [sp, #160]                  ; 16-byte Folded Reload
	str	q16, [sp, #80]                  ; 16-byte Folded Spill
	bit.16b	v4, v16, v1
	ldr	q16, [sp, #144]                 ; 16-byte Folded Reload
	bit.16b	v16, v26, v0
	stp	q16, q4, [sp, #144]             ; 32-byte Folded Spill
	str	q16, [x9, #24624]
	str	q4, [x9, #24608]
	ldp	q16, q4, [sp, #176]             ; 32-byte Folded Reload
	ldr	q2, [sp, #272]                  ; 16-byte Folded Reload
	bit.16b	v4, v2, v1
	bit.16b	v16, v19, v0
	stp	q16, q4, [sp, #176]             ; 32-byte Folded Spill
	str	q16, [x9, #24656]
	str	q4, [x9, #24640]
	str	q3, [sp, #240]                  ; 16-byte Folded Spill
	ldr	q4, [sp, #224]                  ; 16-byte Folded Reload
	bit.16b	v4, v3, v1
	ldr	q3, [sp, #208]                  ; 16-byte Folded Reload
	ldr	q2, [sp, #256]                  ; 16-byte Folded Reload
	bit.16b	v3, v2, v0
	stp	q3, q4, [sp, #208]              ; 32-byte Folded Spill
	str	q3, [x9, #24688]
	lsl	x0, x8, #5
	str	q4, [x9, #24672]
	b	LBB0_5
LBB0_4:                                 ; %else58
                                        ;   in Loop: Header=BB0_5 Depth=2
	add	x2, x12, x1, lsl #5
	ldp	q2, q3, [x2]
	bit.16b	v3, v26, v0
	bit.16b	v2, v16, v1
	stp	q2, q3, [x2]
	add	x1, x1, #1
	cmp	x1, #128
	b.eq	LBB0_21
LBB0_5:                                 ; %direct.true81
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q3, q2, [sp, #288]              ; 32-byte Folded Reload
	and.16b	v2, v2, v3
	addv.8h	h17, v2
	fmov	w2, s17
	and	x3, x1, #0x1f
	lsr	x4, x1, #5
	dup.2d	v2, x4
	add.2d	v3, v2, v6
	orr	x3, x3, x0
	shl.2d	v3, v3, #12
	lsl	x3, x3, #2
	dup.2d	v19, x3
	orr.16b	v4, v3, v19
	dup.2d	v3, x10
	add.2d	v4, v3, v4
	movi.2d	v16, #0000000000000000
	movi.2d	v26, #0000000000000000
	tbnz	w2, #0, LBB0_13
; %bb.6:                                ; %else
                                        ;   in Loop: Header=BB0_5 Depth=2
	and	w2, w2, #0xff
	tbnz	w2, #1, LBB0_14
LBB0_7:                                 ; %else40
                                        ;   in Loop: Header=BB0_5 Depth=2
	ldr	q4, [sp, #336]                  ; 16-byte Folded Reload
	add.2d	v4, v2, v4
	shl.2d	v4, v4, #12
	orr.16b	v4, v4, v19
	add.2d	v4, v3, v4
	tbnz	w2, #2, LBB0_15
LBB0_8:                                 ; %else43
                                        ;   in Loop: Header=BB0_5 Depth=2
	tbnz	w2, #3, LBB0_16
LBB0_9:                                 ; %else46
                                        ;   in Loop: Header=BB0_5 Depth=2
	add.2d	v4, v2, v5
	shl.2d	v4, v4, #12
	orr.16b	v4, v4, v19
	add.2d	v4, v3, v4
	tbnz	w2, #4, LBB0_17
LBB0_10:                                ; %else49
                                        ;   in Loop: Header=BB0_5 Depth=2
	tbnz	w2, #5, LBB0_18
LBB0_11:                                ; %else52
                                        ;   in Loop: Header=BB0_5 Depth=2
	ldr	q4, [sp, #352]                  ; 16-byte Folded Reload
	add.2d	v2, v2, v4
	shl.2d	v2, v2, #12
	orr.16b	v2, v2, v19
	add.2d	v2, v3, v2
	tbnz	w2, #6, LBB0_19
LBB0_12:                                ; %else55
                                        ;   in Loop: Header=BB0_5 Depth=2
	tbz	w2, #7, LBB0_4
	b	LBB0_20
LBB0_13:                                ; %cond.load
                                        ;   in Loop: Header=BB0_5 Depth=2
	fmov	x3, d4
	ldr	s16, [x3]
	and	w2, w2, #0xff
	tbz	w2, #1, LBB0_7
LBB0_14:                                ; %cond.load39
                                        ;   in Loop: Header=BB0_5 Depth=2
	mov.d	x3, v4[1]
	ld1.s	{ v16 }[1], [x3]
	ldr	q4, [sp, #336]                  ; 16-byte Folded Reload
	add.2d	v4, v2, v4
	shl.2d	v4, v4, #12
	orr.16b	v4, v4, v19
	add.2d	v4, v3, v4
	tbz	w2, #2, LBB0_8
LBB0_15:                                ; %cond.load42
                                        ;   in Loop: Header=BB0_5 Depth=2
	fmov	x3, d4
	ld1.s	{ v16 }[2], [x3]
	tbz	w2, #3, LBB0_9
LBB0_16:                                ; %cond.load45
                                        ;   in Loop: Header=BB0_5 Depth=2
	mov.d	x3, v4[1]
	ld1.s	{ v16 }[3], [x3]
	add.2d	v4, v2, v5
	shl.2d	v4, v4, #12
	orr.16b	v4, v4, v19
	add.2d	v4, v3, v4
	tbz	w2, #4, LBB0_10
LBB0_17:                                ; %cond.load48
                                        ;   in Loop: Header=BB0_5 Depth=2
	fmov	x3, d4
	ld1.s	{ v26 }[0], [x3]
	tbz	w2, #5, LBB0_11
LBB0_18:                                ; %cond.load51
                                        ;   in Loop: Header=BB0_5 Depth=2
	mov.d	x3, v4[1]
	ld1.s	{ v26 }[1], [x3]
	ldr	q4, [sp, #352]                  ; 16-byte Folded Reload
	add.2d	v2, v2, v4
	shl.2d	v2, v2, #12
	orr.16b	v2, v2, v19
	add.2d	v2, v3, v2
	tbz	w2, #6, LBB0_12
LBB0_19:                                ; %cond.load54
                                        ;   in Loop: Header=BB0_5 Depth=2
	fmov	x3, d2
	ld1.s	{ v26 }[2], [x3]
	tbz	w2, #7, LBB0_4
LBB0_20:                                ; %cond.load57
                                        ;   in Loop: Header=BB0_5 Depth=2
	mov.d	x2, v2[1]
	ld1.s	{ v26 }[3], [x2]
	b	LBB0_4
LBB0_21:                                ; %direct.true97.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x1, #0                          ; =0x0
	b	LBB0_23
LBB0_22:                                ; %direct.schedule.9
                                        ;   in Loop: Header=BB0_23 Depth=2
	bit.16b	v27, v3, v0
	bit.16b	v25, v2, v1
	tst	x1, #0x1f
	cset	w2, ne
	bit.16b	v23, v4, v1
	bit.16b	v24, v16, v0
	dup.4h	v2, w2
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	mov.16b	v3, v2
	bsl.16b	v3, v24, v7
	bsl.16b	v2, v23, v7
	fmaxnm.4s	v2, v25, v2
	fmaxnm.4s	v3, v27, v3
	add	x2, x13, x1, lsl #5
	ldp	q4, q16, [x2]
	bif.16b	v3, v16, v0
	bif.16b	v2, v4, v1
	stp	q2, q3, [x2]
	add	x1, x1, #1
	cmp	x1, #128
	b.eq	LBB0_25
LBB0_23:                                ; %direct.true97
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x2, x12, x1, lsl #5
	ldp	q2, q3, [x2]
	and	x2, x1, #0x7f
	sub	x2, x2, #1
	movi.2d	v4, #0000000000000000
	movi.2d	v16, #0000000000000000
	cmp	x2, #127
	b.hi	LBB0_22
; %bb.24:                               ; %direct.true105
                                        ;   in Loop: Header=BB0_23 Depth=2
	add	x2, x12, x2, lsl #5
	ldp	q4, q16, [x2]
	b	LBB0_22
LBB0_25:                                ; %direct.true129.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x1, #0                          ; =0x0
	b	LBB0_27
LBB0_26:                                ; %direct.schedule.14
                                        ;   in Loop: Header=BB0_27 Depth=2
	bit.16b	v22, v3, v0
	bit.16b	v21, v2, v1
	and	x2, x1, #0x1f
	cmp	x2, #1
	cset	w2, hi
	bit.16b	v15, v4, v1
	bit.16b	v20, v16, v0
	dup.4h	v2, w2
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	mov.16b	v3, v2
	bsl.16b	v3, v20, v7
	bsl.16b	v2, v15, v7
	fmaxnm.4s	v2, v21, v2
	fmaxnm.4s	v3, v22, v3
	add	x2, x14, x1, lsl #5
	ldp	q4, q16, [x2]
	bif.16b	v3, v16, v0
	bif.16b	v2, v4, v1
	stp	q2, q3, [x2]
	add	x1, x1, #1
	cmp	x1, #128
	b.eq	LBB0_29
LBB0_27:                                ; %direct.true129
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x2, x13, x1, lsl #5
	ldp	q2, q3, [x2]
	and	x2, x1, #0x7f
	sub	x2, x2, #2
	movi.2d	v4, #0000000000000000
	movi.2d	v16, #0000000000000000
	cmp	x2, #127
	b.hi	LBB0_26
; %bb.28:                               ; %direct.true138
                                        ;   in Loop: Header=BB0_27 Depth=2
	add	x2, x13, x2, lsl #5
	ldp	q4, q16, [x2]
	b	LBB0_26
LBB0_29:                                ; %direct.true162.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x1, #0                          ; =0x0
	b	LBB0_31
LBB0_30:                                ; %direct.schedule.19
                                        ;   in Loop: Header=BB0_31 Depth=2
	bit.16b	v14, v3, v0
	bit.16b	v13, v2, v1
	and	x2, x1, #0x1f
	cmp	x2, #3
	cset	w2, hi
	bit.16b	v11, v4, v1
	bit.16b	v12, v16, v0
	dup.4h	v2, w2
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	mov.16b	v3, v2
	bsl.16b	v3, v12, v7
	bsl.16b	v2, v11, v7
	fmaxnm.4s	v2, v13, v2
	fmaxnm.4s	v3, v14, v3
	add	x2, x15, x1, lsl #5
	ldp	q4, q16, [x2]
	bif.16b	v3, v16, v0
	bif.16b	v2, v4, v1
	stp	q2, q3, [x2]
	add	x1, x1, #1
	cmp	x1, #128
	b.eq	LBB0_33
LBB0_31:                                ; %direct.true162
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x2, x14, x1, lsl #5
	ldp	q2, q3, [x2]
	and	x2, x1, #0x7f
	sub	x2, x2, #4
	movi.2d	v4, #0000000000000000
	movi.2d	v16, #0000000000000000
	cmp	x2, #127
	b.hi	LBB0_30
; %bb.32:                               ; %direct.true171
                                        ;   in Loop: Header=BB0_31 Depth=2
	add	x2, x14, x2, lsl #5
	ldp	q4, q16, [x2]
	b	LBB0_30
LBB0_33:                                ; %direct.true195.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x1, #0                          ; =0x0
	b	LBB0_35
LBB0_34:                                ; %direct.schedule.24
                                        ;   in Loop: Header=BB0_35 Depth=2
	bit.16b	v10, v3, v0
	bit.16b	v9, v2, v1
	and	x2, x1, #0x1f
	cmp	x2, #7
	cset	w2, hi
	bit.16b	v31, v4, v1
	bit.16b	v8, v16, v0
	dup.4h	v2, w2
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	mov.16b	v3, v2
	bsl.16b	v3, v8, v7
	bsl.16b	v2, v31, v7
	fmaxnm.4s	v2, v9, v2
	fmaxnm.4s	v3, v10, v3
	add	x2, x16, x1, lsl #5
	ldp	q4, q16, [x2]
	bif.16b	v3, v16, v0
	bif.16b	v2, v4, v1
	stp	q2, q3, [x2]
	add	x1, x1, #1
	cmp	x1, #128
	b.eq	LBB0_37
LBB0_35:                                ; %direct.true195
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x2, x15, x1, lsl #5
	ldp	q2, q3, [x2]
	and	x2, x1, #0x7f
	sub	x2, x2, #8
	movi.2d	v4, #0000000000000000
	movi.2d	v16, #0000000000000000
	cmp	x2, #127
	b.hi	LBB0_34
; %bb.36:                               ; %direct.true204
                                        ;   in Loop: Header=BB0_35 Depth=2
	add	x2, x15, x2, lsl #5
	ldp	q4, q16, [x2]
	b	LBB0_34
LBB0_37:                                ; %direct.true228.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x1, #0                          ; =0x0
	b	LBB0_39
LBB0_38:                                ; %direct.schedule.29
                                        ;   in Loop: Header=BB0_39 Depth=2
	bit.16b	v30, v16, v0
	bit.16b	v29, v2, v1
	and	x3, x1, #0x1f
	cmp	x3, #15
	cset	w3, hi
	bit.16b	v28, v4, v0
	dup.4h	v2, w3
	bit.16b	v18, v3, v1
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	mov.16b	v3, v2
	bsl.16b	v3, v18, v7
	bsl.16b	v2, v28, v7
	fmaxnm.4s	v2, v30, v2
	fmaxnm.4s	v3, v29, v3
	add	x2, x17, x2
	ldp	q4, q16, [x2]
	and.16b	v16, v0, v16
	and.16b	v4, v1, v4
	fmaxnm.4s	v3, v3, v4
	fmaxnm.4s	v2, v2, v16
	add	x2, x9, x1, lsl #5
	ldp	q4, q16, [x2]
	bif.16b	v2, v16, v0
	bif.16b	v3, v4, v1
	stp	q3, q2, [x2]
	add	x1, x1, #1
	cmp	x1, #128
	b.eq	LBB0_41
LBB0_39:                                ; %direct.true228
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	x2, x1, #0x60
	add	x3, x16, x1, lsl #5
	ldp	q2, q16, [x3]
	mov	x3, x2
	bfxil	x3, x1, #0, #5
	sub	x3, x3, #16
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	cmp	x3, #127
	b.hi	LBB0_38
; %bb.40:                               ; %direct.true237
                                        ;   in Loop: Header=BB0_39 Depth=2
	add	x3, x16, x3, lsl #5
	ldp	q3, q4, [x3]
	b	LBB0_38
LBB0_41:                                ; %direct.true267.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x1, #0                          ; =0x0
	b	LBB0_43
LBB0_42:                                ; %else83
                                        ;   in Loop: Header=BB0_43 Depth=2
	add	x1, x1, #1
	cmp	x1, #128
	b.eq	LBB0_2
LBB0_43:                                ; %direct.true267
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w2, s17
	and	x3, x1, #0x1f
	lsr	x4, x1, #5
	dup.2d	v2, x4
	add.2d	v3, v2, v6
	orr	x3, x3, x0
	add	x4, x9, x1, lsl #5
	ldp	q4, q19, [x4]
	and.16b	v26, v1, v4
	shl.2d	v4, v3, #12
	lsl	x3, x3, #2
	dup.2d	v3, x3
	orr.16b	v4, v4, v3
	dup.2d	v16, x11
	add.2d	v4, v16, v4
	tbnz	w2, #0, LBB0_51
; %bb.44:                               ; %else62
                                        ;   in Loop: Header=BB0_43 Depth=2
	and	w2, w2, #0xff
	tbnz	w2, #1, LBB0_52
LBB0_45:                                ; %else65
                                        ;   in Loop: Header=BB0_43 Depth=2
	ldr	q4, [sp, #336]                  ; 16-byte Folded Reload
	add.2d	v4, v2, v4
	shl.2d	v4, v4, #12
	orr.16b	v4, v4, v3
	add.2d	v4, v16, v4
	tbnz	w2, #2, LBB0_53
LBB0_46:                                ; %else68
                                        ;   in Loop: Header=BB0_43 Depth=2
	tbnz	w2, #3, LBB0_54
LBB0_47:                                ; %else71
                                        ;   in Loop: Header=BB0_43 Depth=2
	add.2d	v4, v2, v5
	and.16b	v19, v0, v19
	shl.2d	v4, v4, #12
	orr.16b	v4, v4, v3
	add.2d	v4, v16, v4
	tbnz	w2, #4, LBB0_55
LBB0_48:                                ; %else74
                                        ;   in Loop: Header=BB0_43 Depth=2
	ldr	q26, [sp, #320]                 ; 16-byte Folded Reload
	tbnz	w2, #5, LBB0_56
LBB0_49:                                ; %else77
                                        ;   in Loop: Header=BB0_43 Depth=2
	ldr	q4, [sp, #352]                  ; 16-byte Folded Reload
	add.2d	v2, v2, v4
	shl.2d	v2, v2, #12
	orr.16b	v2, v2, v3
	add.2d	v2, v16, v2
	tbnz	w2, #6, LBB0_57
LBB0_50:                                ; %else80
                                        ;   in Loop: Header=BB0_43 Depth=2
	tbz	w2, #7, LBB0_42
	b	LBB0_58
LBB0_51:                                ; %cond.store
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x3, d4
	str	s26, [x3]
	and	w2, w2, #0xff
	tbz	w2, #1, LBB0_45
LBB0_52:                                ; %cond.store63
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x3, v4[1]
	st1.s	{ v26 }[1], [x3]
	ldr	q4, [sp, #336]                  ; 16-byte Folded Reload
	add.2d	v4, v2, v4
	shl.2d	v4, v4, #12
	orr.16b	v4, v4, v3
	add.2d	v4, v16, v4
	tbz	w2, #2, LBB0_46
LBB0_53:                                ; %cond.store66
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x3, d4
	st1.s	{ v26 }[2], [x3]
	tbz	w2, #3, LBB0_47
LBB0_54:                                ; %cond.store69
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x3, v4[1]
	st1.s	{ v26 }[3], [x3]
	add.2d	v4, v2, v5
	and.16b	v19, v0, v19
	shl.2d	v4, v4, #12
	orr.16b	v4, v4, v3
	add.2d	v4, v16, v4
	tbz	w2, #4, LBB0_48
LBB0_55:                                ; %cond.store72
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x3, d4
	str	s19, [x3]
	ldr	q26, [sp, #320]                 ; 16-byte Folded Reload
	tbz	w2, #5, LBB0_49
LBB0_56:                                ; %cond.store75
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x3, v4[1]
	st1.s	{ v19 }[1], [x3]
	ldr	q4, [sp, #352]                  ; 16-byte Folded Reload
	add.2d	v2, v2, v4
	shl.2d	v2, v2, #12
	orr.16b	v2, v2, v3
	add.2d	v2, v16, v2
	tbz	w2, #6, LBB0_50
LBB0_57:                                ; %cond.store78
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x3, d2
	st1.s	{ v19 }[2], [x3]
	tbz	w2, #7, LBB0_42
LBB0_58:                                ; %cond.store81
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x2, v2[1]
	st1.s	{ v19 }[3], [x2]
	b	LBB0_42
LBB0_59:                                ; %common.ret
	add	sp, sp, #6, lsl #12             ; =24576
	add	sp, sp, #512
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #80             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
                                        ; -- End function
	.globl	_tile_inclusive_scan.packet_batch.blocks ; -- Begin function tile_inclusive_scan.packet_batch.blocks
	.p2align	2
_tile_inclusive_scan.packet_batch.blocks: ; @tile_inclusive_scan.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_13
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w24, w25, [x2]
	ldp	w27, w26, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Folded Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
LBB1_3:                                 ; %tile_inclusive_scan.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w24, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w24, wzr, w24, eq
	cinc	w9, w25, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w25, wzr, w9, ne
	add	w27, w27, w8
	subs	w19, w19, #1
	b.eq	LBB1_12
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x24, #5, #32
	cmp	x8, x26
	csel	x9, x8, xzr, ls
	subs	x10, x26, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x26, x9
	stp	w24, w25, [x20]
	str	w27, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x26, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cmp	x22, #8
	b.lo	LBB1_9
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	cmp	x28, #1
	b.eq	LBB1_9
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	cmp	x28, #2
	b.eq	LBB1_9
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
LBB1_9:                                 ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_11
; %bb.10:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_tile_inclusive_scan
LBB1_11:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Folded Reload
	b	LBB1_3
LBB1_12:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_13:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function tile_inclusive_scan
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_tile_inclusive_scan:                   ; @tile_inclusive_scan
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-80]!           ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #6, lsl #12             ; =24576
	sub	sp, sp, #320
	dup.4s	v1, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q3, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q4, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v0, v1, v4
	cmhi.4s	v1, v1, v3
	uzp1.8h	v2, v1, v0
	umaxv.8h	h5, v2
	fmov	w8, s5
	tbz	w8, #0, LBB0_59
; %bb.1:                                ; %direct.activate
	mov	x8, #0                          ; =0x0
	sshll.2d	v6, v1, #0
	sshll.2d	v5, v0, #0
	sshll2.2d	v7, v1, #0
	sshll2.2d	v16, v0, #0
	ldr	w9, [x1]
	ldr	w10, [x1, #36]
	add	w9, w10, w9, lsl #8
	dup.4s	v17, w9
	add.4s	v4, v17, v4
	add	x9, sp, #192
	add.4s	v3, v17, v3
	ldr	x10, [x0]
	and.16b	v3, v1, v3
	ldr	x11, [x0, #16]
	and.16b	v4, v0, v4
	ushll.2d	v17, v3, #2
	ushll.2d	v18, v4, #2
	ushll2.2d	v19, v3, #2
	ushll2.2d	v3, v4, #2
	and.16b	v3, v16, v3
	and.16b	v4, v7, v19
	and.16b	v5, v5, v18
	and.16b	v6, v6, v17
	movi.2d	v7, #0000000000000000
Lloh4:
	adrp	x12, lCPI0_2@PAGE
Lloh5:
	ldr	q16, [x12, lCPI0_2@PAGEOFF]
	add	x12, sp, #5, lsl #12            ; =20480
	add	x12, x12, #192
	add	x13, sp, #4, lsl #12            ; =16384
	add	x13, x13, #192
	add	x14, sp, #3, lsl #12            ; =12288
	add	x14, x14, #192
	add	x15, sp, #2, lsl #12            ; =8192
	add	x15, x15, #192
	add	x16, sp, #1, lsl #12            ; =4096
	add	x16, x16, #192
	add	x17, sp, #6, lsl #12            ; =24576
	add	x17, x17, #192
                                        ; implicit-def: $q17
                                        ; kill: killed $q17
                                        ; implicit-def: $q17
                                        ; kill: killed $q17
                                        ; implicit-def: $q17
                                        ; kill: killed $q17
                                        ; implicit-def: $q17
                                        ; kill: killed $q17
                                        ; implicit-def: $q17
                                        ; kill: killed $q17
                                        ; implicit-def: $q17
                                        ; kill: killed $q17
                                        ; implicit-def: $q17
                                        ; kill: killed $q17
                                        ; implicit-def: $q17
                                        ; kill: killed $q17
	movi.2d	v25, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v31, #0000000000000000
	movi.2d	v8, #0000000000000000
	movi.2d	v9, #0000000000000000
	movi.2d	v10, #0000000000000000
	movi.2d	v11, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v12, #0000000000000000
	movi.2d	v15, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	b	LBB0_3
LBB0_2:                                 ; %direct.false268
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldp	q21, q22, [x9, #992]
	ldr	q23, [x9, #2016]
	ldr	q24, [x9, #2032]
	ldr	q12, [x9, #3040]
	ldr	q13, [x9, #3056]
	ldr	q14, [x9, #4064]
	bit.16b	v20, v22, v0
	bit.16b	v19, v21, v1
	ldr	q21, [x9, #4080]
	add	x8, x8, #1
	bit.16b	v18, v24, v0
	bit.16b	v17, v23, v1
	bit.16b	v15, v13, v0
	ldp	q22, q24, [sp]                  ; 32-byte Folded Reload
	bif.16b	v12, v22, v1
	bit.16b	v24, v21, v0
	ldr	q23, [sp, #32]                  ; 16-byte Folded Reload
	bit.16b	v23, v14, v1
	cmp	x8, #128
	b.eq	LBB0_59
LBB0_3:                                 ; %direct.true
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_5 Depth 2
                                        ;     Child Loop BB0_23 Depth 2
                                        ;     Child Loop BB0_27 Depth 2
                                        ;     Child Loop BB0_31 Depth 2
                                        ;     Child Loop BB0_35 Depth 2
                                        ;     Child Loop BB0_39 Depth 2
                                        ;     Child Loop BB0_43 Depth 2
	mov	x1, #0                          ; =0x0
	ldr	q21, [sp, #48]                  ; 16-byte Folded Reload
	bit.16b	v21, v20, v0
	stp	q23, q21, [sp, #32]             ; 32-byte Folded Spill
	str	q21, [x9, #24592]
	ldp	q21, q22, [sp, #64]             ; 32-byte Folded Reload
	bit.16b	v21, v19, v1
	str	q21, [sp, #64]                  ; 16-byte Folded Spill
	str	q21, [x9, #24576]
	ldr	q21, [sp, #96]                  ; 16-byte Folded Reload
	bit.16b	v21, v17, v1
	bit.16b	v22, v18, v0
	stp	q22, q21, [sp, #80]             ; 32-byte Folded Spill
	str	q22, [x9, #24624]
	str	q21, [x9, #24608]
	ldp	q22, q21, [sp, #112]            ; 32-byte Folded Reload
	stp	q12, q24, [sp]                  ; 32-byte Folded Spill
	bit.16b	v21, v12, v1
	bit.16b	v22, v15, v0
	stp	q22, q21, [sp, #112]            ; 32-byte Folded Spill
	str	q22, [x9, #24656]
	str	q21, [x9, #24640]
	ldp	q22, q21, [sp, #144]            ; 32-byte Folded Reload
	bit.16b	v21, v23, v1
	bit.16b	v22, v24, v0
	stp	q22, q21, [sp, #144]            ; 32-byte Folded Spill
	str	q22, [x9, #24688]
	lsl	x0, x8, #5
	str	q21, [x9, #24672]
	b	LBB0_5
LBB0_4:                                 ; %else46
                                        ;   in Loop: Header=BB0_5 Depth=2
	add	x2, x12, x1, lsl #5
	ldp	q24, q12, [x2]
	bif.16b	v23, v12, v0
	bif.16b	v22, v24, v1
	stp	q22, q23, [x2]
	add	x1, x1, #1
	cmp	x1, #128
	b.eq	LBB0_21
LBB0_5:                                 ; %direct.true81
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and.16b	v21, v2, v16
	addv.8h	h21, v21
	fmov	w2, s21
	and	x3, x1, #0x1f
	lsr	x4, x1, #5
	dup.2d	v24, x4
	add.2d	v22, v24, v6
	orr	x3, x3, x0
	shl.2d	v22, v22, #14
	lsl	x3, x3, #2
	dup.2d	v12, x3
	orr.16b	v22, v22, v12
	dup.2d	v13, x10
	add.2d	v14, v13, v22
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	tbnz	w2, #0, LBB0_13
; %bb.6:                                ; %else
                                        ;   in Loop: Header=BB0_5 Depth=2
	and	w2, w2, #0xff
	tbnz	w2, #1, LBB0_14
LBB0_7:                                 ; %else28
                                        ;   in Loop: Header=BB0_5 Depth=2
	add.2d	v14, v24, v4
	shl.2d	v14, v14, #14
	orr.16b	v14, v14, v12
	add.2d	v14, v13, v14
	tbnz	w2, #2, LBB0_15
LBB0_8:                                 ; %else31
                                        ;   in Loop: Header=BB0_5 Depth=2
	tbnz	w2, #3, LBB0_16
LBB0_9:                                 ; %else34
                                        ;   in Loop: Header=BB0_5 Depth=2
	add.2d	v14, v24, v5
	shl.2d	v14, v14, #14
	orr.16b	v14, v14, v12
	add.2d	v14, v13, v14
	tbnz	w2, #4, LBB0_17
LBB0_10:                                ; %else37
                                        ;   in Loop: Header=BB0_5 Depth=2
	tbnz	w2, #5, LBB0_18
LBB0_11:                                ; %else40
                                        ;   in Loop: Header=BB0_5 Depth=2
	add.2d	v24, v24, v3
	shl.2d	v24, v24, #14
	orr.16b	v24, v24, v12
	add.2d	v24, v13, v24
	tbnz	w2, #6, LBB0_19
LBB0_12:                                ; %else43
                                        ;   in Loop: Header=BB0_5 Depth=2
	tbz	w2, #7, LBB0_4
	b	LBB0_20
LBB0_13:                                ; %cond.load
                                        ;   in Loop: Header=BB0_5 Depth=2
	fmov	x3, d14
	ldr	s22, [x3]
	and	w2, w2, #0xff
	tbz	w2, #1, LBB0_7
LBB0_14:                                ; %cond.load27
                                        ;   in Loop: Header=BB0_5 Depth=2
	mov.d	x3, v14[1]
	ld1.s	{ v22 }[1], [x3]
	add.2d	v14, v24, v4
	shl.2d	v14, v14, #14
	orr.16b	v14, v14, v12
	add.2d	v14, v13, v14
	tbz	w2, #2, LBB0_8
LBB0_15:                                ; %cond.load30
                                        ;   in Loop: Header=BB0_5 Depth=2
	fmov	x3, d14
	ld1.s	{ v22 }[2], [x3]
	tbz	w2, #3, LBB0_9
LBB0_16:                                ; %cond.load33
                                        ;   in Loop: Header=BB0_5 Depth=2
	mov.d	x3, v14[1]
	ld1.s	{ v22 }[3], [x3]
	add.2d	v14, v24, v5
	shl.2d	v14, v14, #14
	orr.16b	v14, v14, v12
	add.2d	v14, v13, v14
	tbz	w2, #4, LBB0_10
LBB0_17:                                ; %cond.load36
                                        ;   in Loop: Header=BB0_5 Depth=2
	fmov	x3, d14
	ld1.s	{ v23 }[0], [x3]
	tbz	w2, #5, LBB0_11
LBB0_18:                                ; %cond.load39
                                        ;   in Loop: Header=BB0_5 Depth=2
	mov.d	x3, v14[1]
	ld1.s	{ v23 }[1], [x3]
	add.2d	v24, v24, v3
	shl.2d	v24, v24, #14
	orr.16b	v24, v24, v12
	add.2d	v24, v13, v24
	tbz	w2, #6, LBB0_12
LBB0_19:                                ; %cond.load42
                                        ;   in Loop: Header=BB0_5 Depth=2
	fmov	x3, d24
	ld1.s	{ v23 }[2], [x3]
	tbz	w2, #7, LBB0_4
LBB0_20:                                ; %cond.load45
                                        ;   in Loop: Header=BB0_5 Depth=2
	mov.d	x2, v24[1]
	ld1.s	{ v23 }[3], [x2]
	b	LBB0_4
LBB0_21:                                ; %direct.true97.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x1, #0                          ; =0x0
	b	LBB0_23
LBB0_22:                                ; %direct.schedule.9
                                        ;   in Loop: Header=BB0_23 Depth=2
	tst	x1, #0x1f
	cset	w2, ne
	bit.16b	v10, v24, v1
	bit.16b	v11, v12, v0
	dup.4h	v24, w2
	ushll.4s	v24, v24, #0
	shl.4s	v24, v24, #31
	cmlt.4s	v24, v24, #0
	and.16b	v12, v24, v11
	and.16b	v24, v24, v10
	fadd.4s	v23, v23, v24
	fadd.4s	v22, v22, v12
	add	x2, x13, x1, lsl #5
	ldp	q24, q12, [x2]
	bif.16b	v22, v12, v0
	bif.16b	v23, v24, v1
	stp	q23, q22, [x2]
	add	x1, x1, #1
	cmp	x1, #128
	b.eq	LBB0_25
LBB0_23:                                ; %direct.true97
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x2, x12, x1, lsl #5
	ldp	q23, q22, [x2]
	and	x2, x1, #0x7f
	sub	x2, x2, #1
	movi.2d	v24, #0000000000000000
	movi.2d	v12, #0000000000000000
	cmp	x2, #127
	b.hi	LBB0_22
; %bb.24:                               ; %direct.true105
                                        ;   in Loop: Header=BB0_23 Depth=2
	add	x2, x12, x2, lsl #5
	ldp	q24, q12, [x2]
	b	LBB0_22
LBB0_25:                                ; %direct.true129.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x1, #0                          ; =0x0
	b	LBB0_27
LBB0_26:                                ; %direct.schedule.14
                                        ;   in Loop: Header=BB0_27 Depth=2
	and	x2, x1, #0x1f
	cmp	x2, #1
	cset	w2, hi
	bit.16b	v8, v24, v1
	bit.16b	v9, v12, v0
	dup.4h	v24, w2
	ushll.4s	v24, v24, #0
	shl.4s	v24, v24, #31
	cmlt.4s	v24, v24, #0
	and.16b	v12, v24, v9
	and.16b	v24, v24, v8
	fadd.4s	v23, v23, v24
	fadd.4s	v22, v22, v12
	add	x2, x14, x1, lsl #5
	ldp	q24, q12, [x2]
	bif.16b	v22, v12, v0
	bif.16b	v23, v24, v1
	stp	q23, q22, [x2]
	add	x1, x1, #1
	cmp	x1, #128
	b.eq	LBB0_29
LBB0_27:                                ; %direct.true129
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x2, x13, x1, lsl #5
	ldp	q23, q22, [x2]
	and	x2, x1, #0x7f
	sub	x2, x2, #2
	movi.2d	v24, #0000000000000000
	movi.2d	v12, #0000000000000000
	cmp	x2, #127
	b.hi	LBB0_26
; %bb.28:                               ; %direct.true138
                                        ;   in Loop: Header=BB0_27 Depth=2
	add	x2, x13, x2, lsl #5
	ldp	q24, q12, [x2]
	b	LBB0_26
LBB0_29:                                ; %direct.true162.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x1, #0                          ; =0x0
	b	LBB0_31
LBB0_30:                                ; %direct.schedule.19
                                        ;   in Loop: Header=BB0_31 Depth=2
	and	x2, x1, #0x1f
	cmp	x2, #3
	cset	w2, hi
	bit.16b	v30, v24, v1
	bit.16b	v31, v12, v0
	dup.4h	v24, w2
	ushll.4s	v24, v24, #0
	shl.4s	v24, v24, #31
	cmlt.4s	v24, v24, #0
	and.16b	v12, v24, v31
	and.16b	v24, v24, v30
	fadd.4s	v23, v23, v24
	fadd.4s	v22, v22, v12
	add	x2, x15, x1, lsl #5
	ldp	q24, q12, [x2]
	bif.16b	v22, v12, v0
	bif.16b	v23, v24, v1
	stp	q23, q22, [x2]
	add	x1, x1, #1
	cmp	x1, #128
	b.eq	LBB0_33
LBB0_31:                                ; %direct.true162
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x2, x14, x1, lsl #5
	ldp	q23, q22, [x2]
	and	x2, x1, #0x7f
	sub	x2, x2, #4
	movi.2d	v24, #0000000000000000
	movi.2d	v12, #0000000000000000
	cmp	x2, #127
	b.hi	LBB0_30
; %bb.32:                               ; %direct.true171
                                        ;   in Loop: Header=BB0_31 Depth=2
	add	x2, x14, x2, lsl #5
	ldp	q24, q12, [x2]
	b	LBB0_30
LBB0_33:                                ; %direct.true195.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x1, #0                          ; =0x0
	b	LBB0_35
LBB0_34:                                ; %direct.schedule.24
                                        ;   in Loop: Header=BB0_35 Depth=2
	and	x2, x1, #0x1f
	cmp	x2, #7
	cset	w2, hi
	bit.16b	v28, v24, v1
	bit.16b	v29, v12, v0
	dup.4h	v24, w2
	ushll.4s	v24, v24, #0
	shl.4s	v24, v24, #31
	cmlt.4s	v24, v24, #0
	and.16b	v12, v24, v29
	and.16b	v24, v24, v28
	fadd.4s	v23, v23, v24
	fadd.4s	v22, v22, v12
	add	x2, x16, x1, lsl #5
	ldp	q24, q12, [x2]
	bif.16b	v22, v12, v0
	bif.16b	v23, v24, v1
	stp	q23, q22, [x2]
	add	x1, x1, #1
	cmp	x1, #128
	b.eq	LBB0_37
LBB0_35:                                ; %direct.true195
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x2, x15, x1, lsl #5
	ldp	q23, q22, [x2]
	and	x2, x1, #0x7f
	sub	x2, x2, #8
	movi.2d	v24, #0000000000000000
	movi.2d	v12, #0000000000000000
	cmp	x2, #127
	b.hi	LBB0_34
; %bb.36:                               ; %direct.true204
                                        ;   in Loop: Header=BB0_35 Depth=2
	add	x2, x15, x2, lsl #5
	ldp	q24, q12, [x2]
	b	LBB0_34
LBB0_37:                                ; %direct.true228.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x1, #0                          ; =0x0
	b	LBB0_39
LBB0_38:                                ; %direct.schedule.29
                                        ;   in Loop: Header=BB0_39 Depth=2
	bit.16b	v27, v23, v0
	bit.16b	v26, v22, v1
	and	x3, x1, #0x1f
	cmp	x3, #15
	cset	w3, hi
	bit.16b	v25, v12, v0
	bit.16b	v7, v24, v1
	dup.4h	v22, w3
	ushll.4s	v22, v22, #0
	shl.4s	v22, v22, #31
	cmlt.4s	v22, v22, #0
	and.16b	v23, v22, v7
	and.16b	v22, v22, v25
	fadd.4s	v22, v27, v22
	fadd.4s	v23, v26, v23
	add	x2, x17, x2
	ldp	q12, q24, [x2]
	fadd.4s	v23, v12, v23
	fadd.4s	v22, v24, v22
	add	x2, x9, x1, lsl #5
	ldp	q24, q12, [x2]
	bif.16b	v22, v12, v0
	bif.16b	v23, v24, v1
	stp	q23, q22, [x2]
	add	x1, x1, #1
	cmp	x1, #128
	b.eq	LBB0_41
LBB0_39:                                ; %direct.true228
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	x2, x1, #0x60
	add	x3, x16, x1, lsl #5
	ldp	q22, q23, [x3]
	mov	x3, x2
	bfxil	x3, x1, #0, #5
	sub	x3, x3, #16
	movi.2d	v24, #0000000000000000
	movi.2d	v12, #0000000000000000
	cmp	x3, #127
	b.hi	LBB0_38
; %bb.40:                               ; %direct.true237
                                        ;   in Loop: Header=BB0_39 Depth=2
	add	x3, x16, x3, lsl #5
	ldp	q24, q12, [x3]
	b	LBB0_38
LBB0_41:                                ; %direct.true267.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x1, #0                          ; =0x0
	b	LBB0_43
LBB0_42:                                ; %else71
                                        ;   in Loop: Header=BB0_43 Depth=2
	add	x1, x1, #1
	cmp	x1, #128
	b.eq	LBB0_2
LBB0_43:                                ; %direct.true267
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w2, s21
	and	x3, x1, #0x1f
	lsr	x4, x1, #5
	dup.2d	v22, x4
	add.2d	v23, v22, v6
	orr	x3, x3, x0
	add	x4, x9, x1, lsl #5
	ldp	q24, q12, [x4]
	and.16b	v13, v1, v24
	shl.2d	v24, v23, #14
	lsl	x3, x3, #2
	dup.2d	v23, x3
	orr.16b	v14, v24, v23
	dup.2d	v24, x11
	add.2d	v14, v24, v14
	tbnz	w2, #0, LBB0_51
; %bb.44:                               ; %else50
                                        ;   in Loop: Header=BB0_43 Depth=2
	and	w2, w2, #0xff
	tbnz	w2, #1, LBB0_52
LBB0_45:                                ; %else53
                                        ;   in Loop: Header=BB0_43 Depth=2
	add.2d	v14, v22, v4
	shl.2d	v14, v14, #14
	orr.16b	v14, v14, v23
	add.2d	v14, v24, v14
	tbnz	w2, #2, LBB0_53
LBB0_46:                                ; %else56
                                        ;   in Loop: Header=BB0_43 Depth=2
	tbnz	w2, #3, LBB0_54
LBB0_47:                                ; %else59
                                        ;   in Loop: Header=BB0_43 Depth=2
	add.2d	v13, v22, v5
	and.16b	v12, v0, v12
	shl.2d	v13, v13, #14
	orr.16b	v13, v13, v23
	add.2d	v13, v24, v13
	tbnz	w2, #4, LBB0_55
LBB0_48:                                ; %else62
                                        ;   in Loop: Header=BB0_43 Depth=2
	tbnz	w2, #5, LBB0_56
LBB0_49:                                ; %else65
                                        ;   in Loop: Header=BB0_43 Depth=2
	add.2d	v22, v22, v3
	shl.2d	v22, v22, #14
	orr.16b	v22, v22, v23
	add.2d	v22, v24, v22
	tbnz	w2, #6, LBB0_57
LBB0_50:                                ; %else68
                                        ;   in Loop: Header=BB0_43 Depth=2
	tbz	w2, #7, LBB0_42
	b	LBB0_58
LBB0_51:                                ; %cond.store
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x3, d14
	str	s13, [x3]
	and	w2, w2, #0xff
	tbz	w2, #1, LBB0_45
LBB0_52:                                ; %cond.store51
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x3, v14[1]
	st1.s	{ v13 }[1], [x3]
	add.2d	v14, v22, v4
	shl.2d	v14, v14, #14
	orr.16b	v14, v14, v23
	add.2d	v14, v24, v14
	tbz	w2, #2, LBB0_46
LBB0_53:                                ; %cond.store54
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x3, d14
	st1.s	{ v13 }[2], [x3]
	tbz	w2, #3, LBB0_47
LBB0_54:                                ; %cond.store57
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x3, v14[1]
	st1.s	{ v13 }[3], [x3]
	add.2d	v13, v22, v5
	and.16b	v12, v0, v12
	shl.2d	v13, v13, #14
	orr.16b	v13, v13, v23
	add.2d	v13, v24, v13
	tbz	w2, #4, LBB0_48
LBB0_55:                                ; %cond.store60
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x3, d13
	str	s12, [x3]
	tbz	w2, #5, LBB0_49
LBB0_56:                                ; %cond.store63
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x3, v13[1]
	st1.s	{ v12 }[1], [x3]
	add.2d	v22, v22, v3
	shl.2d	v22, v22, #14
	orr.16b	v22, v22, v23
	add.2d	v22, v24, v22
	tbz	w2, #6, LBB0_50
LBB0_57:                                ; %cond.store66
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x3, d22
	st1.s	{ v12 }[2], [x3]
	tbz	w2, #7, LBB0_42
LBB0_58:                                ; %cond.store69
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x2, v22[1]
	st1.s	{ v12 }[3], [x2]
	b	LBB0_42
LBB0_59:                                ; %common.ret
	add	sp, sp, #6, lsl #12             ; =24576
	add	sp, sp, #320
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #80             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
                                        ; -- End function
	.globl	_tile_inclusive_scan.packet_batch.blocks ; -- Begin function tile_inclusive_scan.packet_batch.blocks
	.p2align	2
_tile_inclusive_scan.packet_batch.blocks: ; @tile_inclusive_scan.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_12
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #128
	stp	x28, x27, [sp, #32]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	mov	w22, #0                         ; =0x0
	mov	w23, #256                       ; =0x100
	ldp	w27, w28, [x2, #44]
	ldp	w24, w11, [x2]
	ldp	w25, w8, [x2, #8]
	str	x8, [sp, #16]                   ; 8-byte Folded Spill
	str	w28, [sp, #12]                  ; 4-byte Folded Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #56                         ; =0x38
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #64                         ; =0x40
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #72                         ; =0x48
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #80                         ; =0x50
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #88                         ; =0x58
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #96                         ; =0x60
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #104                        ; =0x68
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #112                        ; =0x70
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #120                        ; =0x78
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #128                        ; =0x80
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #136                        ; =0x88
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #144                        ; =0x90
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #152                        ; =0x98
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #160                        ; =0xa0
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #168                        ; =0xa8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #176                        ; =0xb0
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #184                        ; =0xb8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #192                        ; =0xc0
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #200                        ; =0xc8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #208                        ; =0xd0
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #216                        ; =0xd8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #224                        ; =0xe0
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #232                        ; =0xe8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #240                        ; =0xf0
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #248                        ; =0xf8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
LBB1_3:                                 ; %tile_inclusive_scan.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w24, #1
	cmp	w8, w27
	cset	w8, eq
	csinc	w24, wzr, w24, eq
	ldr	w9, [sp, #28]                   ; 4-byte Folded Reload
	cinc	w9, w9, eq
	cmp	w9, w28
	cset	w10, eq
	ands	w8, w8, w10
	csel	w11, wzr, w9, ne
	add	w25, w25, w8
	add	w22, w22, #1
	cmp	w22, w19
	b.eq	LBB1_11
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_7 Depth 2
	ubfiz	x8, x24, #8, #32
	ldr	x12, [sp, #16]                  ; 8-byte Folded Reload
	cmp	x8, x12
	csel	x9, x8, xzr, ls
	subs	x10, x12, x9
	cmp	x10, #256
	csel	x10, x10, x23, lo
	cmp	x12, x9
	stp	w24, w11, [x20]
	str	w11, [sp, #28]                  ; 4-byte Folded Spill
	str	w25, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x12, #2, hi
	csel	x26, x10, xzr, ls
	cmp	x26, #256
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x28, x27
	mov	x23, x19
	lsr	x8, x26, #3
	lsl	w27, w8, #3
	cmp	x26, #8
	b.lo	LBB1_8
; %bb.6:                                ; %packet.batch.partial.full.loop.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w19, #0                         ; =0x0
LBB1_7:                                 ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	str	w19, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	add	w19, w19, #8
	cmp	w27, w19
	b.ne	LBB1_7
LBB1_8:                                 ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w26, #0x7
	cbz	w2, LBB1_10
; %bb.9:                                ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	w27, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_tile_inclusive_scan
LBB1_10:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #248                        ; =0xf8
	str	w8, [x20, #36]
	mov	x19, x23
	mov	w23, #256                       ; =0x100
	mov	x27, x28
	ldr	w28, [sp, #12]                  ; 4-byte Folded Reload
	b	LBB1_3
LBB1_11:
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #32]             ; 16-byte Folded Reload
	add	sp, sp, #128
LBB1_12:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

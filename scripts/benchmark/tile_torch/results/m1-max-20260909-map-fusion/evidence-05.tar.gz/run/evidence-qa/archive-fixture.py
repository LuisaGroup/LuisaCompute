import argparse
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import shutil
import tarfile

ROOT = Path(__file__).resolve().parent
SCRIPT = Path('/Users/mike/CLionProjects/luisa/scripts/benchmark/tile_torch/results/m1-max-20260909-map-fusion/archive.py')
SPEC = importlib.util.spec_from_file_location('archive', SCRIPT)
A = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(A)


def fail(fn, label):
    try:
        fn()
    except (ValueError, OSError, tarfile.TarError):
        print('PASS rejection:', label)
    else:
        raise AssertionError(label)


run = ROOT / 'run'
source = ROOT / 'source'
run.mkdir()
source.mkdir()
(run / 'captures').mkdir()
(run / 'captures' / 'input.f32').write_bytes(bytes(range(256)) * 5000)
(run / 'build-v1.log').write_text('intentional failure retained\n')
(source / 'small.cpp').write_text('int fixture() { return 1; }\n')
output = ROOT / 'archive'
A.create(argparse.Namespace(run=run, final_source=source, base_commit='a' * 40, output=output))
manifest = json.loads((output / 'manifest.json').read_text())
expected = {m['path']: Path(m['original_path']).read_bytes()
            for b in manifest['bundles'] for m in b['members']}
for bundle in manifest['bundles']:
    with tarfile.open(output / bundle['path'], 'r:gz') as tar:
        for info in tar:
            assert tar.extractfile(info).read() == expected[info.name]
# Delete no inputs: rename them to prove verification never consults source paths.
run.rename(ROOT / 'run-hidden')
source.rename(ROOT / 'source-hidden')
A.verify(output)
print('PASS exact original bytes and verification without original source paths')
for value in ['', '/', '../x', 'x/../y', '/x', 'a//b', 'a/./b', 'C:/x', 'a\\b', 'a\x00b']:
    fail(lambda: A.safe_name(value), repr(value))
fail(lambda: A.create(argparse.Namespace(run=ROOT/'run-hidden', final_source=ROOT/'source-hidden', base_commit='a'*40, output=output)), 'existing output')


def altered(label, fn):
    destination = ROOT / label
    shutil.copytree(output, destination)
    local = json.loads((destination / 'manifest.json').read_text())
    fn(destination, local)
    (destination / 'manifest.json').write_text(json.dumps(local))
    fail(lambda: A.verify(destination), label)


altered('bad-content', lambda d, m: (d/m['bundles'][0]['path']).write_bytes(b'bad gzip'))
altered('duplicate-members', lambda d, m: m['bundles'][0]['members'].append(m['bundles'][0]['members'][0]))
altered('duplicate-bundles', lambda d, m: m['bundles'].append(m['bundles'][0]))
altered('wrong-member-sha', lambda d, m: m['bundles'][0]['members'][0].update(sha256='0'*64))
altered('wrong-member-size', lambda d, m: m['bundles'][0]['members'][0].update(size=1))
altered('unsafe-member', lambda d, m: m['bundles'][0]['members'][0].update(path='../escape'))


def nonregular(destination, manifest):
    bundle = manifest['bundles'][0]
    with tarfile.open(destination/bundle['path'], 'w:gz') as tar:
        info = tarfile.TarInfo(bundle['members'][0]['path'])
        info.type = tarfile.SYMTYPE
        info.linkname = '/etc/passwd'
        tar.addfile(info)
    size, digest = A.hash_file(destination/bundle['path'])
    bundle.update(size=size, sha256=digest)


altered('symlink-tar', nonregular)
duplicate = ROOT / 'duplicate-json'
shutil.copytree(output, duplicate)
(duplicate/'manifest.json').write_text('{"schema": "a", "schema": "b"}')
fail(lambda: A.verify(duplicate), 'duplicate JSON key')

source_symlink = ROOT/'source-symlink'
source_symlink.mkdir()
(source_symlink/'external.cpp').symlink_to(ROOT/'source-hidden'/'small.cpp')
fail(lambda: A.inventory_tree(source_symlink, 'final-source'), 'source symlink')
poison = ROOT/'run-hidden'/'.poison'
poison.write_text('must not be opened by inventory\n')
fail(lambda: A.inventory_run(ROOT/'run-hidden'), 'unreviewed hidden root file')
print('ALL ARCHIVE FIXTURES PASSED')

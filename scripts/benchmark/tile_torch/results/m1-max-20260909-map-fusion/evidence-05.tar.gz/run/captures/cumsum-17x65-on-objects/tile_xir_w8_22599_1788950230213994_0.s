	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function tile_inclusive_scan
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_4:
	.quad	120                             ; 0x78
	.quad	124                             ; 0x7c
lCPI0_5:
	.quad	112                             ; 0x70
	.quad	116                             ; 0x74
lCPI0_6:
	.quad	104                             ; 0x68
	.quad	108                             ; 0x6c
lCPI0_7:
	.quad	96                              ; 0x60
	.quad	100                             ; 0x64
lCPI0_8:
	.quad	88                              ; 0x58
	.quad	92                              ; 0x5c
lCPI0_9:
	.quad	80                              ; 0x50
	.quad	84                              ; 0x54
lCPI0_10:
	.quad	72                              ; 0x48
	.quad	76                              ; 0x4c
lCPI0_11:
	.quad	64                              ; 0x40
	.quad	68                              ; 0x44
lCPI0_12:
	.quad	56                              ; 0x38
	.quad	60                              ; 0x3c
lCPI0_13:
	.quad	48                              ; 0x30
	.quad	52                              ; 0x34
lCPI0_14:
	.quad	40                              ; 0x28
	.quad	44                              ; 0x2c
lCPI0_15:
	.quad	32                              ; 0x20
	.quad	36                              ; 0x24
lCPI0_16:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_17:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_18:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_19:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_3:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_tile_inclusive_scan:                   ; @tile_inclusive_scan
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	sub	x9, sp, #7, lsl #12             ; =28672
	sub	x9, x9, #2912
	and	sp, x9, #0xffffffffffffffc0
	fmov	s1, wzr
	add	x8, sp, #7, lsl #12             ; =28672
	add	x8, x8, #2792
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #1119
	str	wzr, [x8, #84]
	stur	wzr, [x8, #81]
	stur	xzr, [x8, #52]
	stur	xzr, [x8, #68]
	stur	xzr, [x8, #60]
	str	wzr, [x8, #76]
	stur	xzr, [x8, #20]
	stur	xzr, [x8, #36]
	stur	xzr, [x8, #28]
	str	wzr, [x8, #44]
	str	xzr, [sp, #31472]
	str	xzr, [sp, #31464]
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #6704]
	str	q0, [sp, #6688]
	str	q0, [sp, #6672]
	str	q0, [sp, #6656]
	str	q0, [sp, #6640]
	str	q0, [sp, #6624]
	str	q0, [sp, #6608]
	str	q0, [sp, #6592]
	str	q0, [sp, #6576]
	str	q0, [sp, #6560]
	str	q0, [sp, #6544]
	str	q0, [sp, #6528]
	str	q0, [sp, #6512]
	str	q0, [sp, #6496]
	str	q0, [sp, #6480]
	str	q0, [sp, #6464]
	str	q0, [sp, #6448]
	str	q0, [sp, #6432]
	str	q0, [sp, #6416]
	str	q0, [sp, #6400]
	str	q0, [sp, #6384]
	str	q0, [sp, #6336]
	str	q0, [sp, #6352]
	str	q0, [sp, #6368]
	str	q0, [sp, #6320]
	str	q0, [sp, #6272]
	str	q0, [sp, #6288]
	str	q0, [sp, #6240]
	str	q0, [sp, #6256]
	str	q0, [sp, #6208]
	str	q0, [sp, #6224]
	str	q0, [sp, #6304]
	str	q0, [sp, #6192]
	str	q0, [sp, #6144]
	str	q0, [sp, #6160]
	str	q0, [sp, #6176]
	str	q0, [sp, #6128]
	str	q0, [sp, #6080]
	str	q0, [sp, #6096]
	str	q0, [sp, #6048]
	str	q0, [sp, #6064]
	str	q0, [sp, #6016]
	str	q0, [sp, #6032]
	str	q0, [sp, #6112]
	str	q0, [sp, #6000]
	str	q0, [sp, #5984]
	strb	wzr, [x9, #768]
	str	q0, [sp, #5936]
	str	q0, [sp, #5920]
	str	q0, [sp, #5904]
	str	q0, [sp, #5888]
	str	q0, [sp, #5872]
	str	q0, [sp, #5824]
	str	q0, [sp, #5840]
	str	q0, [sp, #5792]
	str	q0, [sp, #5808]
	str	q0, [sp, #5760]
	str	q0, [sp, #5776]
	str	q0, [sp, #5856]
	str	q0, [sp, #5744]
	str	q0, [sp, #5728]
	strb	wzr, [x9, #512]
	str	q0, [sp, #5680]
	str	q0, [sp, #5664]
	str	q0, [sp, #5648]
	str	q0, [sp, #5632]
	str	q0, [sp, #5616]
	str	q0, [sp, #5568]
	str	q0, [sp, #5584]
	str	q0, [sp, #5536]
	str	q0, [sp, #5552]
	str	q0, [sp, #5504]
	str	q0, [sp, #5520]
	str	q0, [sp, #5600]
	str	q0, [sp, #5488]
	str	q0, [sp, #5472]
	strb	wzr, [x9, #256]
	str	q0, [sp, #5424]
	str	q0, [sp, #5408]
	str	q0, [sp, #5392]
	str	q0, [sp, #5376]
	str	q0, [sp, #5360]
	str	q0, [sp, #5312]
	str	q0, [sp, #5328]
	str	q0, [sp, #5280]
	str	q0, [sp, #5296]
	str	q0, [sp, #5248]
	str	q0, [sp, #5264]
	str	q0, [sp, #5344]
	str	q0, [sp, #5232]
	str	q0, [sp, #5216]
	strb	wzr, [x9]
	str	q0, [sp, #5168]
	str	q0, [sp, #5152]
	str	q0, [sp, #5136]
	str	q0, [sp, #5120]
	str	q0, [sp, #5104]
	str	q0, [sp, #5056]
	str	q0, [sp, #5072]
	str	q0, [sp, #5088]
	str	q0, [sp, #5040]
	str	q0, [sp, #5024]
	add	x10, sp, #928
	strb	wzr, [x10, #4095]
	str	q0, [sp, #4976]
	str	q0, [sp, #4960]
	str	q0, [sp, #4944]
	str	q0, [sp, #4928]
	str	q0, [sp, #4912]
	str	q0, [sp, #4864]
	str	q0, [sp, #4880]
	str	q0, [sp, #4896]
	str	q0, [sp, #4848]
	movi.2d	v2, #0000000000000000
	str	q2, [sp, #928]                  ; 16-byte Folded Spill
	str	q0, [sp, #4832]
	ldr	x10, [x0]
	ldr	x11, [x0, #16]
	ldr	w12, [x1]
	ldr	w13, [x1, #36]
	dup.4s	v2, w2
Lloh0:
	adrp	x14, lCPI0_0@PAGE
Lloh1:
	ldr	q3, [x14, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x14, lCPI0_1@PAGE
Lloh3:
	ldr	q4, [x14, lCPI0_1@PAGEOFF]
	cmhi.4s	v5, v2, v4
	cmhi.4s	v2, v2, v3
	uzp1.8h	v2, v2, v5
Lloh4:
	adrp	x14, lCPI0_2@PAGE
Lloh5:
	ldr	q5, [x14, lCPI0_2@PAGEOFF]
	and.16b	v5, v2, v5
	addv.8h	h5, v5
	fmov	w14, s5
	and	w14, w14, #0xff
	fmov	s5, w14
	cmeq.8b	v1, v5, v1
	umov.b	w14, v1[0]
	and	w15, w14, #0x1
	fmov	s5, w15
	ubfx	w15, w14, #1, #1
	mov.b	v5[1], w15
	ubfx	w15, w14, #2, #1
	mov.b	v5[2], w15
	ubfx	w15, w14, #3, #1
	mov.b	v5[3], w15
	ubfx	w15, w14, #4, #1
	mov.b	v5[4], w15
	ubfx	w15, w14, #5, #1
	mov.b	v5[5], w15
	ubfx	w15, w14, #6, #1
	mov.b	v5[6], w15
	xtn.8b	v0, v2
	ubfx	w14, w14, #7, #1
	mov.b	v5[7], w14
	movi.8b	v6, #1
	eor.8b	v5, v5, v6
	str	d0, [sp, #1064]                 ; 8-byte Folded Spill
	and.8b	v5, v5, v0
	umaxv.8h	h2, v2
	fmov	w14, s2
	shl.8b	v2, v5, #7
	cmlt.8b	v5, v2, #0
Lloh6:
	adrp	x15, lCPI0_3@PAGE
Lloh7:
	ldr	d2, [x15, lCPI0_3@PAGEOFF]
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x8, #80]
	str	wzr, [x8, #48]
	str	wzr, [x8, #16]
	tbnz	w14, #0, LBB0_1
	b	LBB0_744
LBB0_1:                                 ; %scheduler.dispatch.lr.ph.lr.ph
	mov	w16, #0                         ; =0x0
	add	x14, sp, #7, lsl #12            ; =28672
	add	x14, x14, #2664
	dup.2d	v0, x14
	add	x14, sp, #6, lsl #12            ; =24576
	add	x14, x14, #2664
	dup.2d	v5, x14
	stp	q5, q0, [sp, #96]               ; 32-byte Folded Spill
	add	x14, sp, #5, lsl #12            ; =20480
	add	x14, x14, #2664
	dup.2d	v0, x14
	add	x14, sp, #4, lsl #12            ; =16384
	add	x14, x14, #2664
	dup.2d	v5, x14
	stp	q5, q0, [sp, #176]              ; 32-byte Folded Spill
	add	x14, sp, #3, lsl #12            ; =12288
	add	x14, x14, #2664
	dup.2d	v0, x14
	add	x14, sp, #2, lsl #12            ; =8192
	add	x14, x14, #2664
	dup.2d	v5, x14
	stp	q5, q0, [sp, #144]              ; 32-byte Folded Spill
	add	x14, sp, #1, lsl #12            ; =4096
	add	x14, x14, #2664
	dup.2d	v5, x14
	str	q5, [sp, #128]                  ; 16-byte Folded Spill
	add	w12, w13, w12, lsl #5
	dup.4s	v5, w12
	add.4s	v4, v5, v4
	add.4s	v3, v5, v3
	ushll2.2d	v0, v4, #2
	ushll2.2d	v5, v3, #2
	stp	q5, q0, [sp, #48]               ; 32-byte Folded Spill
	ushll.2d	v4, v4, #2
	ushll.2d	v3, v3, #2
	stp	q3, q4, [sp, #16]               ; 32-byte Folded Spill
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #880]                  ; 16-byte Folded Spill
	movi.2d	v9, #0000000000000000
	movi.2d	v3, #0000000000000000
	stp	q3, q3, [sp, #400]              ; 32-byte Folded Spill
	mov	w17, #1                         ; =0x1
	add	x12, sp, #7, lsl #12            ; =28672
	add	x12, x12, #2872
	movi.2d	v4, #0000000000000000
	add	x13, sp, #7, lsl #12            ; =28672
	add	x13, x13, #2840
	stp	q0, q0, [sp, #992]              ; 32-byte Folded Spill
	add	x14, sp, #7, lsl #12            ; =28672
	add	x14, x14, #2808
	movi.2d	v22, #0000000000000000
	movi.2d	v12, #0000000000000000
Lloh8:
	adrp	x15, LJTI0_0@PAGE
Lloh9:
	add	x15, x15, LJTI0_0@PAGEOFF
	stp	q3, q3, [sp, #240]              ; 32-byte Folded Spill
	stp	q3, q3, [sp, #208]              ; 32-byte Folded Spill
	stp	q3, q3, [sp, #480]              ; 32-byte Folded Spill
	stp	q3, q3, [sp, #448]              ; 32-byte Folded Spill
	stp	q3, q3, [sp, #368]              ; 32-byte Folded Spill
	stp	q0, q3, [sp, #624]              ; 32-byte Folded Spill
	stp	q0, q0, [sp, #960]              ; 32-byte Folded Spill
	movi.2d	v13, #0000000000000000
	stp	q3, q3, [sp, #656]              ; 32-byte Folded Spill
	stp	q3, q3, [sp, #336]              ; 32-byte Folded Spill
	movi.2d	v14, #0000000000000000
	stp	q3, q3, [sp, #304]              ; 32-byte Folded Spill
	movi.2d	v15, #0000000000000000
	str	q0, [sp, #944]                  ; 16-byte Folded Spill
	movi.2d	v30, #0000000000000000
	stp	q3, q3, [sp, #272]              ; 32-byte Folded Spill
	str	q0, [sp, #1040]                 ; 16-byte Folded Spill
	str	q0, [sp, #896]                  ; 16-byte Folded Spill
	movi.2d	v26, #0000000000000000
	str	q0, [sp, #832]                  ; 16-byte Folded Spill
	stp	q0, q0, [sp, #512]              ; 32-byte Folded Spill
	str	q0, [sp, #1024]                 ; 16-byte Folded Spill
	movi.2d	v29, #0000000000000000
	movi.2d	v8, #0000000000000000
	movi.2d	v31, #0000000000000000
	str	q3, [sp, #432]                  ; 16-byte Folded Spill
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v25, #0000000000000000
	str	q3, [sp, #1072]                 ; 16-byte Folded Spill
	str	q3, [sp, #1088]                 ; 16-byte Folded Spill
	str	q3, [sp, #1104]                 ; 16-byte Folded Spill
LBB0_2:                                 ; %scheduler.dispatch.lr.ph
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_6 Depth 2
                                        ;       Child Loop BB0_10 Depth 3
                                        ;         Child Loop BB0_203 Depth 4
                                        ;         Child Loop BB0_263 Depth 4
                                        ;         Child Loop BB0_345 Depth 4
                                        ;         Child Loop BB0_453 Depth 4
                                        ;         Child Loop BB0_538 Depth 4
                                        ;         Child Loop BB0_636 Depth 4
                                        ;         Child Loop BB0_690 Depth 4
                                        ;         Child Loop BB0_707 Depth 4
                                        ;         Child Loop BB0_595 Depth 4
                                        ;         Child Loop BB0_513 Depth 4
                                        ;         Child Loop BB0_428 Depth 4
                                        ;         Child Loop BB0_354 Depth 4
                                        ;         Child Loop BB0_272 Depth 4
                                        ;         Child Loop BB0_62 Depth 4
                                        ;       Child Loop BB0_722 Depth 3
	stp	q19, q18, [sp, #544]            ; 32-byte Folded Spill
	str	q0, [sp, #576]                  ; 16-byte Folded Spill
	mov.16b	v19, v1
	b	LBB0_6
LBB0_3:                                 ; %schedule.38.convergence.cascade.exit539_crit_edge
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_4:                                 ; %convergence.cascade.exit539
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w2, #0xff
	b.ne	LBB0_730
LBB0_5:                                 ; %scheduler.loop.backedge
                                        ;   in Loop: Header=BB0_6 Depth=2
	cbz	x17, LBB0_744
LBB0_6:                                 ; %scheduler.dispatch
                                        ;   Parent Loop BB0_2 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_10 Depth 3
                                        ;         Child Loop BB0_203 Depth 4
                                        ;         Child Loop BB0_263 Depth 4
                                        ;         Child Loop BB0_345 Depth 4
                                        ;         Child Loop BB0_453 Depth 4
                                        ;         Child Loop BB0_538 Depth 4
                                        ;         Child Loop BB0_636 Depth 4
                                        ;         Child Loop BB0_690 Depth 4
                                        ;         Child Loop BB0_707 Depth 4
                                        ;         Child Loop BB0_595 Depth 4
                                        ;         Child Loop BB0_513 Depth 4
                                        ;         Child Loop BB0_428 Depth 4
                                        ;         Child Loop BB0_354 Depth 4
                                        ;         Child Loop BB0_272 Depth 4
                                        ;         Child Loop BB0_62 Depth 4
                                        ;       Child Loop BB0_722 Depth 3
	sub	w17, w17, #1
	ldrb	w0, [x12, w17, sxtw]
	and	w1, w0, #0x1
	fmov	s24, w1
	ubfx	w1, w0, #1, #1
	mov.b	v24[1], w1
	ubfx	w1, w0, #2, #1
	mov.b	v24[2], w1
	ubfx	w1, w0, #3, #1
	mov.b	v24[3], w1
	ubfx	w1, w0, #4, #1
	mov.b	v24[4], w1
	ubfx	w1, w0, #5, #1
	mov.b	v24[5], w1
	ubfx	w1, w0, #6, #1
	mov.b	v24[6], w1
	lsr	w0, w0, #7
	mov.b	v24[7], w0
	ldr	w2, [x13, w17, sxtw #2]
	ldr	w0, [x14, w17, sxtw #2]
	b	LBB0_10
LBB0_7:                                 ; %convergence.overflow.resume414
                                        ;   in Loop: Header=BB0_10 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #7, lsl #12             ; =28672
	add	x2, x2, #2800
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s3, w4
	ubfx	w4, w5, #1, #1
	mov.b	v3[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v3[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v3[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v3[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v3[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v3[6], w4
	add	x4, sp, #7, lsl #12             ; =28672
	add	x4, x4, #2792
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s5, w6
	ubfx	w6, w5, #1, #1
	mov.b	v5[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v5[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v5[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v5[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v5[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v5[6], w6
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v6, w5
	bit.8b	v3, v24, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x2, w3, uxtw]
	bic.8b	v3, v5, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	ldr	q19, [sp, #992]                 ; 16-byte Folded Reload
	ldr	q6, [sp, #784]                  ; 16-byte Folded Reload
	ldr	q17, [sp, #1040]                ; 16-byte Folded Reload
	ldr	q29, [sp, #864]                 ; 16-byte Folded Reload
	ldr	q21, [sp, #1024]                ; 16-byte Folded Reload
	ldr	q31, [sp, #720]                 ; 16-byte Folded Reload
	b.hs	LBB0_746
; %bb.8:                                ; %ready.overflow.resume416
                                        ;   in Loop: Header=BB0_10 Depth=3
	zip2.8b	v3, v28, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldr	q5, [sp, #400]                  ; 16-byte Folded Reload
	and.16b	v5, v3, v5
	str	q5, [sp, #400]                  ; 16-byte Folded Spill
	zip1.8b	v3, v28, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldr	q5, [sp, #416]                  ; 16-byte Folded Reload
	and.16b	v5, v3, v5
	str	q5, [sp, #416]                  ; 16-byte Folded Spill
	str	q31, [sp, #3456]
	ldr	q3, [sp, #1072]                 ; 16-byte Folded Reload
	str	q3, [sp, #3472]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #3456
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q31, [sp, #3424]
	str	q3, [sp, #3440]
	add	x5, sp, #3424
	str	w4, [x5, x2]
	ldr	q3, [sp, #3440]
	str	q3, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q25, [sp, #3424]
	str	q7, [sp, #3392]
	str	q0, [sp, #3408]
	add	x4, sp, #3392
	ldr	w4, [x4, x2]
	mov	w5, #12                         ; =0xc
	csel	w4, w5, w4, ne
	str	q7, [sp, #3360]
	str	q0, [sp, #3376]
	add	x5, sp, #3360
	str	w4, [x5, x2]
	mov	w2, #31                         ; =0x1f
	mov	w4, #30                         ; =0x1e
	ldr	q0, [sp, #3376]
	str	q0, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #3360]
	str	q0, [sp, #1088]                 ; 16-byte Folded Spill
                                        ; kill: def $w3 killed $w3 killed $x3 def $x3
	ldr	q0, [sp, #816]                  ; 16-byte Folded Reload
	mov.16b	v13, v1
	ldr	q9, [sp, #688]                  ; 16-byte Folded Reload
	ldr	q12, [sp, #848]                 ; 16-byte Folded Reload
	str	q17, [sp, #1040]                ; 16-byte Folded Spill
	ldr	q31, [sp, #912]                 ; 16-byte Folded Reload
	stp	q19, q15, [sp, #992]            ; 32-byte Folded Spill
	mov.16b	v15, v6
	mov.16b	v22, v4
	mov.16b	v4, v26
	mov.16b	v26, v0
	mov.16b	v19, v20
	str	q21, [sp, #1024]                ; 16-byte Folded Spill
LBB0_9:                                 ; %scheduler.dispatch.route.backedge
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov	w5, #1                          ; =0x1
	lsl	w3, w5, w3
	cmp	w1, #0
	csel	w1, w3, wzr, ne
	add	x3, sp, #7, lsl #12             ; =28672
	add	x3, x3, #2872
	shl.8b	v3, v27, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x3, x17]
	add	x3, sp, #7, lsl #12             ; =28672
	add	x3, x3, #2840
	str	w4, [x3, x17, lsl #2]
	orr	w16, w1, w16
	add	x1, sp, #7, lsl #12             ; =28672
	add	x1, x1, #2808
	str	w0, [x1, x17, lsl #2]
	add	x17, x17, #1
	fmov	d24, d28
LBB0_10:                                ; %scheduler.dispatch.route
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB0_203 Depth 4
                                        ;         Child Loop BB0_263 Depth 4
                                        ;         Child Loop BB0_345 Depth 4
                                        ;         Child Loop BB0_453 Depth 4
                                        ;         Child Loop BB0_538 Depth 4
                                        ;         Child Loop BB0_636 Depth 4
                                        ;         Child Loop BB0_690 Depth 4
                                        ;         Child Loop BB0_707 Depth 4
                                        ;         Child Loop BB0_595 Depth 4
                                        ;         Child Loop BB0_513 Depth 4
                                        ;         Child Loop BB0_428 Depth 4
                                        ;         Child Loop BB0_354 Depth 4
                                        ;         Child Loop BB0_272 Depth 4
                                        ;         Child Loop BB0_62 Depth 4
	cmp	w2, #38
	b.hi	LBB0_746
; %bb.11:                               ; %scheduler.dispatch.route
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov	w2, w2
	adr	x1, LBB0_12
	ldrh	w3, [x15, x2, lsl #1]
	add	x1, x1, x3, lsl #2
	br	x1
LBB0_12:                                ; %schedule.0
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w1, s3
	ldr	q3, [sp, #6704]
	ldr	q5, [sp, #6656]
	ldr	q16, [sp, #6672]
	mov	b17, v24[4]
	mov.b	v17[4], v24[5]
	mov.16b	v0, v19
	ldr	q19, [sp, #6688]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	ldp	q1, q6, [sp, #32]               ; 32-byte Folded Reload
	bit.16b	v19, v1, v17
	mov	b20, v24[2]
	mov.b	v20[4], v24[3]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	bit.16b	v16, v6, v20
	mov	b21, v24[0]
	mov.b	v21[4], v24[1]
	ushll.2d	v21, v21, #0
	shl.2d	v21, v21, #63
	cmlt.2d	v21, v21, #0
	ldr	q6, [sp, #16]                   ; 16-byte Folded Reload
	bit.16b	v5, v6, v21
	mov	b27, v24[6]
	mov.b	v27[4], v24[7]
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	ldr	q6, [sp, #64]                   ; 16-byte Folded Reload
	bit.16b	v3, v6, v27
	zip2.8b	v28, v24, v0
	ushll.4s	v28, v28, #0
	shl.4s	v28, v28, #31
	mov.16b	v7, v29
	zip1.8b	v29, v24, v0
	ushll.4s	v29, v29, #0
	shl.4s	v29, v29, #31
	str	q3, [sp, #6704]
	str	q5, [sp, #6656]
	str	q16, [sp, #6672]
	str	q19, [sp, #6688]
	mov.16b	v19, v0
	ldp	q3, q0, [sp, #544]              ; 32-byte Folded Reload
	bic.16b	v1, v3, v27
	bic.16b	v0, v0, v17
	stp	q1, q0, [sp, #544]              ; 32-byte Folded Spill
	ldr	q0, [sp, #432]                  ; 16-byte Folded Reload
	bic.16b	v0, v0, v20
	str	q0, [sp, #432]                  ; 16-byte Folded Spill
	ldr	q0, [sp, #576]                  ; 16-byte Folded Reload
	bic.16b	v0, v0, v21
	str	q0, [sp, #576]                  ; 16-byte Folded Spill
	ldr	q3, [sp, #6640]
	ldr	q5, [sp, #6624]
	cmge.4s	v16, v29, #0
	mov.16b	v29, v7
	and.16b	v5, v16, v5
	cmge.4s	v17, v28, #0
	and.16b	v3, v17, v3
	str	q3, [sp, #6640]
	str	q5, [sp, #6624]
	ldr	q3, [sp, #6608]
	ldr	q5, [sp, #6592]
	and.16b	v5, v16, v5
	and.16b	v3, v17, v3
	str	q3, [sp, #6608]
	str	q5, [sp, #6592]
	ldr	q3, [sp, #6576]
	ldr	q5, [sp, #6560]
	and.16b	v5, v16, v5
	and.16b	v3, v17, v3
	str	q3, [sp, #6576]
	str	q5, [sp, #6560]
	ldr	q3, [sp, #6544]
	ldr	q5, [sp, #6528]
	and.16b	v5, v16, v5
	and.16b	v3, v17, v3
	str	q3, [sp, #6544]
	str	q5, [sp, #6528]
	tbnz	w1, #0, LBB0_145
	b	LBB0_5
LBB0_13:                                ; %schedule.30
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v3, v13
	mov.16b	v13, v31
	str	q15, [sp, #784]                 ; 16-byte Folded Spill
	mov.16b	v16, v29
	mov.16b	v1, v22
	str	q3, [sp, #736]                  ; 16-byte Folded Spill
	mov.16b	v15, v26
	mov.16b	v3, v12
	mov.16b	v12, v4
	mov.16b	v4, v3
	mov.16b	v7, v8
	ldr	q22, [sp, #976]                 ; 16-byte Folded Reload
	mov.16b	v0, v19
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w1, s3
	ldr	q3, [sp, #5248]
	ldr	q28, [sp, #5264]
	ldr	q20, [sp, #5280]
	ldr	q23, [sp, #5296]
	ldr	q11, [sp, #5360]
	ldr	q21, [sp, #5344]
	ldr	q29, [sp, #5328]
	ldr	q5, [sp, #5312]
	ldr	q6, [sp, #4928]
	ldr	q19, [sp, #4944]
	ldr	q27, [sp, #4960]
	ldr	q10, [sp, #4976]
	shl.2d	v6, v6, #5
	add.2d	v3, v3, v5
	add.2d	v8, v3, v6
	movi.2d	v3, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbnz	w1, #0, LBB0_100
; %bb.14:                               ; %else3148
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #1, LBB0_101
LBB0_15:                                ; %else3154
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v8, v7
	shl.2d	v6, v19, #5
	add.2d	v7, v28, v29
	add.2d	v28, v7, v6
	tbnz	w1, #2, LBB0_102
LBB0_16:                                ; %else3160
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v19, v12
	str	q22, [sp, #976]                 ; 16-byte Folded Spill
	tbz	w1, #3, LBB0_18
LBB0_17:                                ; %cond.load3162
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v28[1]
	ld1.s	{ v3 }[3], [x2]
LBB0_18:                                ; %else3166
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v29, v16
	shl.2d	v6, v27, #5
	add.2d	v7, v20, v21
	add.2d	v20, v7, v6
	mov.16b	v12, v4
	mov.16b	v26, v15
	ldr	q6, [sp, #736]                  ; 16-byte Folded Reload
	mov.16b	v31, v13
	tbnz	w1, #4, LBB0_103
; %bb.19:                               ; %else3172
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v22, v1
	ldr	q15, [sp, #784]                 ; 16-byte Folded Reload
	mov.16b	v4, v19
	mov.16b	v19, v0
	mov.16b	v13, v6
	tbnz	w1, #5, LBB0_104
LBB0_20:                                ; %else3178
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.2d	v6, v10, #5
	add.2d	v7, v23, v11
	add.2d	v16, v7, v6
	tbnz	w1, #6, LBB0_105
LBB0_21:                                ; %else3184
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbz	w1, #7, LBB0_23
LBB0_22:                                ; %cond.load3186
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v16[1]
	ld1.s	{ v5 }[3], [x2]
LBB0_23:                                ; %else3190
                                        ;   in Loop: Header=BB0_10 Depth=3
	zip2.8b	v6, v24, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	ldr	q7, [sp, #400]                  ; 16-byte Folded Reload
	bit.16b	v7, v5, v6
	zip1.8b	v5, v24, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q6, [sp, #416]                  ; 16-byte Folded Reload
	bit.16b	v6, v3, v5
	stp	q7, q6, [sp, #400]              ; 32-byte Folded Spill
	tst	w1, #0xff
	b.ne	LBB0_593
	b	LBB0_5
LBB0_24:                                ; %schedule.35
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v0, v19
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w1, s3
	ldr	q5, [sp, #4912]
	ldr	q17, [sp, #4896]
	ldr	q20, [sp, #4880]
	ldr	q6, [sp, #4864]
	ldr	q3, [sp, #4848]
	ldr	q19, [sp, #4832]
	shl.2d	v6, v6, #2
	dup.2d	v16, x11
	add.2d	v21, v16, v6
	tbnz	w1, #0, LBB0_106
; %bb.25:                               ; %else3243
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #1, LBB0_107
LBB0_26:                                ; %else3246
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.2d	v6, v20, #2
	add.2d	v20, v16, v6
	tbnz	w1, #2, LBB0_108
LBB0_27:                                ; %else3249
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #3, LBB0_109
LBB0_28:                                ; %else3252
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.2d	v6, v17, #2
	add.2d	v17, v16, v6
	tbnz	w1, #4, LBB0_110
LBB0_29:                                ; %else3255
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v19, v0
	tbnz	w1, #5, LBB0_111
LBB0_30:                                ; %else3258
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.2d	v5, v5, #2
	add.2d	v5, v16, v5
	tbnz	w1, #6, LBB0_112
LBB0_31:                                ; %else3261
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #7, LBB0_113
LBB0_32:                                ; %else3264
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w1, #0xff
	b.ne	LBB0_705
	b	LBB0_5
LBB0_33:                                ; %scheduler.dispatch.route.schedule.29_crit_edge
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w1, s3
	eor	w1, w1, #0x1
	b	LBB0_557
LBB0_34:                                ; %scheduler.dispatch.route.schedule.4_crit_edge
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w1, s3
	eor	w1, w1, #0x1
	b	LBB0_162
LBB0_35:                                ; %scheduler.dispatch.route.schedule.2_crit_edge
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w1, s3
	b	LBB0_153
LBB0_36:                                ; %schedule.10
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v3, v13
	mov.16b	v13, v31
	str	q15, [sp, #784]                 ; 16-byte Folded Spill
	mov.16b	v16, v29
	mov.16b	v1, v22
	str	q3, [sp, #736]                  ; 16-byte Folded Spill
	mov.16b	v15, v26
	mov.16b	v3, v12
	mov.16b	v12, v4
	mov.16b	v4, v3
	mov.16b	v7, v8
	ldr	q22, [sp, #976]                 ; 16-byte Folded Reload
	mov.16b	v0, v19
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w1, s3
	ldr	q3, [sp, #6208]
	ldr	q28, [sp, #6224]
	ldr	q20, [sp, #6240]
	ldr	q23, [sp, #6256]
	ldr	q11, [sp, #6320]
	ldr	q21, [sp, #6304]
	ldr	q29, [sp, #6288]
	ldr	q5, [sp, #6272]
	ldr	q6, [sp, #5888]
	ldr	q19, [sp, #5904]
	ldr	q27, [sp, #5920]
	ldr	q10, [sp, #5936]
	shl.2d	v6, v6, #5
	add.2d	v3, v3, v5
	add.2d	v8, v3, v6
	movi.2d	v3, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbnz	w1, #0, LBB0_114
; %bb.37:                               ; %else2756
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #1, LBB0_115
LBB0_38:                                ; %else2762
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v8, v7
	shl.2d	v6, v19, #5
	add.2d	v7, v28, v29
	add.2d	v28, v7, v6
	tbnz	w1, #2, LBB0_116
LBB0_39:                                ; %else2768
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v19, v12
	str	q22, [sp, #976]                 ; 16-byte Folded Spill
	tbz	w1, #3, LBB0_41
LBB0_40:                                ; %cond.load2770
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v28[1]
	ld1.s	{ v3 }[3], [x2]
LBB0_41:                                ; %else2774
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v29, v16
	shl.2d	v6, v27, #5
	add.2d	v7, v20, v21
	add.2d	v20, v7, v6
	mov.16b	v12, v4
	mov.16b	v26, v15
	ldr	q6, [sp, #736]                  ; 16-byte Folded Reload
	mov.16b	v31, v13
	tbnz	w1, #4, LBB0_117
; %bb.42:                               ; %else2780
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v22, v1
	ldr	q15, [sp, #784]                 ; 16-byte Folded Reload
	mov.16b	v4, v19
	mov.16b	v19, v0
	mov.16b	v13, v6
	tbnz	w1, #5, LBB0_118
LBB0_43:                                ; %else2786
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.2d	v6, v10, #5
	add.2d	v7, v23, v11
	add.2d	v16, v7, v6
	tbnz	w1, #6, LBB0_119
LBB0_44:                                ; %else2792
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbz	w1, #7, LBB0_46
LBB0_45:                                ; %cond.load2794
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v16[1]
	ld1.s	{ v5 }[3], [x2]
LBB0_46:                                ; %else2798
                                        ;   in Loop: Header=BB0_10 Depth=3
	zip2.8b	v6, v24, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	ldr	q7, [sp, #272]                  ; 16-byte Folded Reload
	bit.16b	v7, v5, v6
	zip1.8b	v5, v24, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q6, [sp, #288]                  ; 16-byte Folded Reload
	bit.16b	v6, v3, v5
	stp	q7, q6, [sp, #272]              ; 32-byte Folded Spill
	tst	w1, #0xff
	b.ne	LBB0_270
	b	LBB0_5
LBB0_47:                                ; %scheduler.dispatch.route.schedule.24_crit_edge
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w1, s3
	eor	w1, w1, #0x1
	b	LBB0_474
LBB0_48:                                ; %scheduler.dispatch.route.schedule.34_crit_edge
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w1, s3
	eor	w1, w1, #0x1
	b	LBB0_655
LBB0_49:                                ; %scheduler.dispatch.route.schedule.19_crit_edge
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w1, s3
	eor	w1, w1, #0x1
	b	LBB0_390
LBB0_50:                                ; %schedule.5
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v0, v19
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w1, s3
	ldr	q16, [sp, #6192]
	ldr	q19, [sp, #6176]
	ldr	q20, [sp, #6160]
	ldr	q3, [sp, #6144]
	shl.2d	v3, v3, #2
	dup.2d	v17, x10
	add.2d	v21, v17, v3
	movi.2d	v3, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbnz	w1, #0, LBB0_120
; %bb.51:                               ; %else
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #1, LBB0_121
LBB0_52:                                ; %else2682
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.2d	v20, v20, #2
	add.2d	v20, v17, v20
	tbnz	w1, #2, LBB0_122
LBB0_53:                                ; %else2685
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #3, LBB0_123
LBB0_54:                                ; %else2688
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.2d	v19, v19, #2
	add.2d	v19, v17, v19
	tbnz	w1, #4, LBB0_124
LBB0_55:                                ; %else2691
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #5, LBB0_125
LBB0_56:                                ; %else2694
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v19, v0
	shl.2d	v16, v16, #2
	add.2d	v16, v17, v16
	tbnz	w1, #6, LBB0_126
LBB0_57:                                ; %else2697
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbz	w1, #7, LBB0_59
LBB0_58:                                ; %cond.load2699
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v16[1]
	ld1.s	{ v5 }[3], [x2]
LBB0_59:                                ; %else2700
                                        ;   in Loop: Header=BB0_10 Depth=3
	zip2.8b	v16, v24, v0
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	ldr	q0, [sp, #512]                  ; 16-byte Folded Reload
	bit.16b	v0, v5, v16
	str	q0, [sp, #512]                  ; 16-byte Folded Spill
	zip1.8b	v5, v24, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q0, [sp, #528]                  ; 16-byte Folded Reload
	bit.16b	v0, v3, v5
	str	q0, [sp, #528]                  ; 16-byte Folded Spill
	tst	w1, #0xff
	b.eq	LBB0_5
LBB0_60:                                ; %schedule.6
                                        ;   in Loop: Header=BB0_10 Depth=3
	cbz	w0, LBB0_180
LBB0_61:                                ; %convergence.cascade.preheader
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v28, v19
	mov.16b	v27, v26
	mov	w1, #0                          ; =0x0
LBB0_62:                                ; %convergence.cascade
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_10 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v5, v3, v2
	addv.8b	b5, v5
	fmov	w2, s5
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #1632]
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	str	q0, [sp, #1648]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #1632
	ldr	w6, [x6, x2]
	cmp	w6, #2
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #7, lsl #12             ; =28672
	add	x5, x5, #2800
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s3, w19
	ubfx	w19, w20, #1, #1
	mov.b	v3[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v3[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v3[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v3[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v3[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v3[6], w19
	add	x19, sp, #7, lsl #12            ; =28672
	add	x19, x19, #2792
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s5, w21
	ubfx	w21, w20, #1, #1
	mov.b	v5[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v5[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v5[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v5[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v5[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v5[6], w21
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	orr.8b	v6, v24, v5
	ldr	d0, [sp, #1064]                 ; 8-byte Folded Reload
	and.8b	v7, v0, v3
	eor.8b	v7, v7, v6
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v6, v7
	dup.8b	v17, w7
	bit.8b	v5, v16, v17
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x19, w3, sxtw]
	bic.8b	v3, v3, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v5, v5, v6
	str	q25, [sp, #1600]
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	str	q0, [sp, #1616]
	add	x3, sp, #1600
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v24, v5, v3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_181
; %bb.63:                               ; %convergence.cascade
                                        ;   in Loop: Header=BB0_62 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_181
; %bb.64:                               ; %convergence.cascade
                                        ;   in Loop: Header=BB0_62 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_62
	b	LBB0_181
LBB0_65:                                ; %schedule.20
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v3, v13
	mov.16b	v13, v31
	str	q15, [sp, #784]                 ; 16-byte Folded Spill
	mov.16b	v16, v29
	mov.16b	v1, v22
	str	q3, [sp, #736]                  ; 16-byte Folded Spill
	mov.16b	v15, v26
	mov.16b	v3, v12
	mov.16b	v12, v4
	mov.16b	v4, v3
	mov.16b	v7, v8
	ldr	q22, [sp, #976]                 ; 16-byte Folded Reload
	mov.16b	v0, v19
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w1, s3
	ldr	q3, [sp, #5760]
	ldr	q28, [sp, #5776]
	ldr	q20, [sp, #5792]
	ldr	q23, [sp, #5808]
	ldr	q11, [sp, #5872]
	ldr	q21, [sp, #5856]
	ldr	q29, [sp, #5840]
	ldr	q5, [sp, #5824]
	ldr	q6, [sp, #5376]
	ldr	q19, [sp, #5392]
	ldr	q27, [sp, #5408]
	ldr	q10, [sp, #5424]
	shl.2d	v6, v6, #5
	add.2d	v3, v3, v5
	add.2d	v8, v3, v6
	movi.2d	v3, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbnz	w1, #0, LBB0_127
; %bb.66:                               ; %else2952
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #1, LBB0_128
LBB0_67:                                ; %else2958
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v8, v7
	shl.2d	v6, v19, #5
	add.2d	v7, v28, v29
	add.2d	v28, v7, v6
	tbnz	w1, #2, LBB0_129
LBB0_68:                                ; %else2964
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v19, v12
	str	q22, [sp, #976]                 ; 16-byte Folded Spill
	tbz	w1, #3, LBB0_70
LBB0_69:                                ; %cond.load2966
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v28[1]
	ld1.s	{ v3 }[3], [x2]
LBB0_70:                                ; %else2970
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v29, v16
	shl.2d	v6, v27, #5
	add.2d	v7, v20, v21
	add.2d	v20, v7, v6
	mov.16b	v12, v4
	mov.16b	v26, v15
	ldr	q6, [sp, #736]                  ; 16-byte Folded Reload
	mov.16b	v31, v13
	tbnz	w1, #4, LBB0_130
; %bb.71:                               ; %else2976
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v22, v1
	ldr	q15, [sp, #784]                 ; 16-byte Folded Reload
	mov.16b	v4, v19
	mov.16b	v19, v0
	mov.16b	v13, v6
	tbnz	w1, #5, LBB0_131
LBB0_72:                                ; %else2982
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.2d	v6, v10, #5
	add.2d	v7, v23, v11
	add.2d	v16, v7, v6
	tbnz	w1, #6, LBB0_132
LBB0_73:                                ; %else2988
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbz	w1, #7, LBB0_75
LBB0_74:                                ; %cond.load2990
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v16[1]
	ld1.s	{ v5 }[3], [x2]
LBB0_75:                                ; %else2994
                                        ;   in Loop: Header=BB0_10 Depth=3
	zip2.8b	v6, v24, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	ldr	q7, [sp, #336]                  ; 16-byte Folded Reload
	bit.16b	v7, v5, v6
	zip1.8b	v5, v24, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q6, [sp, #352]                  ; 16-byte Folded Reload
	bit.16b	v6, v3, v5
	stp	q7, q6, [sp, #336]              ; 32-byte Folded Spill
	tst	w1, #0xff
	b.ne	LBB0_426
	b	LBB0_5
LBB0_76:                                ; %scheduler.dispatch.route.schedule.9_crit_edge
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w1, s3
	eor	w1, w1, #0x1
	b	LBB0_224
LBB0_77:                                ; %scheduler.dispatch.route.schedule.14_crit_edge
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w1, s3
	eor	w1, w1, #0x1
	b	LBB0_307
LBB0_78:                                ; %schedule.15
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v3, v13
	mov.16b	v13, v31
	str	q15, [sp, #784]                 ; 16-byte Folded Spill
	mov.16b	v16, v29
	mov.16b	v1, v22
	str	q3, [sp, #736]                  ; 16-byte Folded Spill
	mov.16b	v15, v26
	mov.16b	v3, v12
	mov.16b	v12, v4
	mov.16b	v4, v3
	mov.16b	v7, v8
	ldr	q22, [sp, #976]                 ; 16-byte Folded Reload
	mov.16b	v0, v19
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w1, s3
	ldr	q3, [sp, #6016]
	ldr	q28, [sp, #6032]
	ldr	q20, [sp, #6048]
	ldr	q23, [sp, #6064]
	ldr	q11, [sp, #6128]
	ldr	q21, [sp, #6112]
	ldr	q29, [sp, #6096]
	ldr	q5, [sp, #6080]
	ldr	q6, [sp, #5632]
	ldr	q19, [sp, #5648]
	ldr	q27, [sp, #5664]
	ldr	q10, [sp, #5680]
	shl.2d	v6, v6, #5
	add.2d	v3, v3, v5
	add.2d	v8, v3, v6
	movi.2d	v3, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbnz	w1, #0, LBB0_133
; %bb.79:                               ; %else2854
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #1, LBB0_134
LBB0_80:                                ; %else2860
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v8, v7
	shl.2d	v6, v19, #5
	add.2d	v7, v28, v29
	add.2d	v28, v7, v6
	tbnz	w1, #2, LBB0_135
LBB0_81:                                ; %else2866
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v19, v12
	str	q22, [sp, #976]                 ; 16-byte Folded Spill
	tbz	w1, #3, LBB0_83
LBB0_82:                                ; %cond.load2868
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v28[1]
	ld1.s	{ v3 }[3], [x2]
LBB0_83:                                ; %else2872
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v29, v16
	shl.2d	v6, v27, #5
	add.2d	v7, v20, v21
	add.2d	v20, v7, v6
	mov.16b	v12, v4
	mov.16b	v26, v15
	ldr	q6, [sp, #736]                  ; 16-byte Folded Reload
	mov.16b	v31, v13
	tbnz	w1, #4, LBB0_136
; %bb.84:                               ; %else2878
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v22, v1
	ldr	q15, [sp, #784]                 ; 16-byte Folded Reload
	mov.16b	v4, v19
	mov.16b	v19, v0
	mov.16b	v13, v6
	tbnz	w1, #5, LBB0_137
LBB0_85:                                ; %else2884
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.2d	v6, v10, #5
	add.2d	v7, v23, v11
	add.2d	v16, v7, v6
	tbnz	w1, #6, LBB0_138
LBB0_86:                                ; %else2890
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbz	w1, #7, LBB0_88
LBB0_87:                                ; %cond.load2892
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v16[1]
	ld1.s	{ v5 }[3], [x2]
LBB0_88:                                ; %else2896
                                        ;   in Loop: Header=BB0_10 Depth=3
	zip2.8b	v6, v24, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	ldr	q7, [sp, #304]                  ; 16-byte Folded Reload
	bit.16b	v7, v5, v6
	zip1.8b	v5, v24, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q6, [sp, #320]                  ; 16-byte Folded Reload
	bit.16b	v6, v3, v5
	stp	q7, q6, [sp, #304]              ; 32-byte Folded Spill
	tst	w1, #0xff
	b.ne	LBB0_352
	b	LBB0_5
LBB0_89:                                ; %schedule.25
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v3, v13
	mov.16b	v13, v31
	str	q15, [sp, #784]                 ; 16-byte Folded Spill
	mov.16b	v16, v29
	mov.16b	v1, v22
	str	q3, [sp, #736]                  ; 16-byte Folded Spill
	mov.16b	v15, v26
	mov.16b	v3, v12
	mov.16b	v12, v4
	mov.16b	v4, v3
	mov.16b	v7, v8
	ldr	q22, [sp, #976]                 ; 16-byte Folded Reload
	mov.16b	v0, v19
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w1, s3
	ldr	q3, [sp, #5504]
	ldr	q28, [sp, #5520]
	ldr	q20, [sp, #5536]
	ldr	q23, [sp, #5552]
	ldr	q11, [sp, #5616]
	ldr	q21, [sp, #5600]
	ldr	q29, [sp, #5584]
	ldr	q5, [sp, #5568]
	ldr	q6, [sp, #5120]
	ldr	q19, [sp, #5136]
	ldr	q27, [sp, #5152]
	ldr	q10, [sp, #5168]
	shl.2d	v6, v6, #5
	add.2d	v3, v3, v5
	add.2d	v8, v3, v6
	movi.2d	v3, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbnz	w1, #0, LBB0_139
; %bb.90:                               ; %else3050
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #1, LBB0_140
LBB0_91:                                ; %else3056
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v8, v7
	shl.2d	v6, v19, #5
	add.2d	v7, v28, v29
	add.2d	v28, v7, v6
	tbnz	w1, #2, LBB0_141
LBB0_92:                                ; %else3062
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v19, v12
	str	q22, [sp, #976]                 ; 16-byte Folded Spill
	tbz	w1, #3, LBB0_94
LBB0_93:                                ; %cond.load3064
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v28[1]
	ld1.s	{ v3 }[3], [x2]
LBB0_94:                                ; %else3068
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v29, v16
	shl.2d	v6, v27, #5
	add.2d	v7, v20, v21
	add.2d	v20, v7, v6
	mov.16b	v12, v4
	mov.16b	v26, v15
	ldr	q6, [sp, #736]                  ; 16-byte Folded Reload
	mov.16b	v31, v13
	tbnz	w1, #4, LBB0_142
; %bb.95:                               ; %else3074
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v22, v1
	ldr	q15, [sp, #784]                 ; 16-byte Folded Reload
	mov.16b	v4, v19
	mov.16b	v19, v0
	mov.16b	v13, v6
	tbnz	w1, #5, LBB0_143
LBB0_96:                                ; %else3080
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.2d	v6, v10, #5
	add.2d	v7, v23, v11
	add.2d	v16, v7, v6
	tbnz	w1, #6, LBB0_144
LBB0_97:                                ; %else3086
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbz	w1, #7, LBB0_99
LBB0_98:                                ; %cond.load3088
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v16[1]
	ld1.s	{ v5 }[3], [x2]
LBB0_99:                                ; %else3092
                                        ;   in Loop: Header=BB0_10 Depth=3
	zip2.8b	v6, v24, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	ldr	q7, [sp, #368]                  ; 16-byte Folded Reload
	bit.16b	v7, v5, v6
	zip1.8b	v5, v24, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q6, [sp, #384]                  ; 16-byte Folded Reload
	bit.16b	v6, v3, v5
	stp	q7, q6, [sp, #368]              ; 32-byte Folded Spill
	tst	w1, #0xff
	b.ne	LBB0_511
	b	LBB0_5
LBB0_100:                               ; %cond.load3144
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d8
	ldr	s3, [x2]
	tbz	w1, #1, LBB0_15
LBB0_101:                               ; %cond.load3150
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v8[1]
	ld1.s	{ v3 }[1], [x2]
	mov.16b	v8, v7
	shl.2d	v6, v19, #5
	add.2d	v7, v28, v29
	add.2d	v28, v7, v6
	tbz	w1, #2, LBB0_16
LBB0_102:                               ; %cond.load3156
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d28
	ld1.s	{ v3 }[2], [x2]
	mov.16b	v19, v12
	str	q22, [sp, #976]                 ; 16-byte Folded Spill
	tbnz	w1, #3, LBB0_17
	b	LBB0_18
LBB0_103:                               ; %cond.load3168
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d20
	ld1.s	{ v5 }[0], [x2]
	mov.16b	v22, v1
	ldr	q15, [sp, #784]                 ; 16-byte Folded Reload
	mov.16b	v4, v19
	mov.16b	v19, v0
	mov.16b	v13, v6
	tbz	w1, #5, LBB0_20
LBB0_104:                               ; %cond.load3174
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v20[1]
	ld1.s	{ v5 }[1], [x2]
	shl.2d	v6, v10, #5
	add.2d	v7, v23, v11
	add.2d	v16, v7, v6
	tbz	w1, #6, LBB0_21
LBB0_105:                               ; %cond.load3180
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d16
	ld1.s	{ v5 }[2], [x2]
	tbnz	w1, #7, LBB0_22
	b	LBB0_23
LBB0_106:                               ; %cond.store
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d21
	str	s19, [x2]
	tbz	w1, #1, LBB0_26
LBB0_107:                               ; %cond.store3244
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v21[1]
	st1.s	{ v19 }[1], [x2]
	shl.2d	v6, v20, #2
	add.2d	v20, v16, v6
	tbz	w1, #2, LBB0_27
LBB0_108:                               ; %cond.store3247
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d20
	st1.s	{ v19 }[2], [x2]
	tbz	w1, #3, LBB0_28
LBB0_109:                               ; %cond.store3250
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v20[1]
	st1.s	{ v19 }[3], [x2]
	shl.2d	v6, v17, #2
	add.2d	v17, v16, v6
	tbz	w1, #4, LBB0_29
LBB0_110:                               ; %cond.store3253
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d17
	str	s3, [x2]
	mov.16b	v19, v0
	tbz	w1, #5, LBB0_30
LBB0_111:                               ; %cond.store3256
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v17[1]
	st1.s	{ v3 }[1], [x2]
	shl.2d	v5, v5, #2
	add.2d	v5, v16, v5
	tbz	w1, #6, LBB0_31
LBB0_112:                               ; %cond.store3259
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d5
	st1.s	{ v3 }[2], [x2]
	tbz	w1, #7, LBB0_32
LBB0_113:                               ; %cond.store3262
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v5[1]
	st1.s	{ v3 }[3], [x2]
	tst	w1, #0xff
	b.ne	LBB0_705
	b	LBB0_5
LBB0_114:                               ; %cond.load2752
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d8
	ldr	s3, [x2]
	tbz	w1, #1, LBB0_38
LBB0_115:                               ; %cond.load2758
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v8[1]
	ld1.s	{ v3 }[1], [x2]
	mov.16b	v8, v7
	shl.2d	v6, v19, #5
	add.2d	v7, v28, v29
	add.2d	v28, v7, v6
	tbz	w1, #2, LBB0_39
LBB0_116:                               ; %cond.load2764
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d28
	ld1.s	{ v3 }[2], [x2]
	mov.16b	v19, v12
	str	q22, [sp, #976]                 ; 16-byte Folded Spill
	tbnz	w1, #3, LBB0_40
	b	LBB0_41
LBB0_117:                               ; %cond.load2776
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d20
	ld1.s	{ v5 }[0], [x2]
	mov.16b	v22, v1
	ldr	q15, [sp, #784]                 ; 16-byte Folded Reload
	mov.16b	v4, v19
	mov.16b	v19, v0
	mov.16b	v13, v6
	tbz	w1, #5, LBB0_43
LBB0_118:                               ; %cond.load2782
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v20[1]
	ld1.s	{ v5 }[1], [x2]
	shl.2d	v6, v10, #5
	add.2d	v7, v23, v11
	add.2d	v16, v7, v6
	tbz	w1, #6, LBB0_44
LBB0_119:                               ; %cond.load2788
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d16
	ld1.s	{ v5 }[2], [x2]
	tbnz	w1, #7, LBB0_45
	b	LBB0_46
LBB0_120:                               ; %cond.load
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d21
	ldr	s3, [x2]
	tbz	w1, #1, LBB0_52
LBB0_121:                               ; %cond.load2681
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v21[1]
	ld1.s	{ v3 }[1], [x2]
	shl.2d	v20, v20, #2
	add.2d	v20, v17, v20
	tbz	w1, #2, LBB0_53
LBB0_122:                               ; %cond.load2684
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d20
	ld1.s	{ v3 }[2], [x2]
	tbz	w1, #3, LBB0_54
LBB0_123:                               ; %cond.load2687
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v20[1]
	ld1.s	{ v3 }[3], [x2]
	shl.2d	v19, v19, #2
	add.2d	v19, v17, v19
	tbz	w1, #4, LBB0_55
LBB0_124:                               ; %cond.load2690
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d19
	ld1.s	{ v5 }[0], [x2]
	tbz	w1, #5, LBB0_56
LBB0_125:                               ; %cond.load2693
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v19[1]
	ld1.s	{ v5 }[1], [x2]
	mov.16b	v19, v0
	shl.2d	v16, v16, #2
	add.2d	v16, v17, v16
	tbz	w1, #6, LBB0_57
LBB0_126:                               ; %cond.load2696
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d16
	ld1.s	{ v5 }[2], [x2]
	tbnz	w1, #7, LBB0_58
	b	LBB0_59
LBB0_127:                               ; %cond.load2948
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d8
	ldr	s3, [x2]
	tbz	w1, #1, LBB0_67
LBB0_128:                               ; %cond.load2954
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v8[1]
	ld1.s	{ v3 }[1], [x2]
	mov.16b	v8, v7
	shl.2d	v6, v19, #5
	add.2d	v7, v28, v29
	add.2d	v28, v7, v6
	tbz	w1, #2, LBB0_68
LBB0_129:                               ; %cond.load2960
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d28
	ld1.s	{ v3 }[2], [x2]
	mov.16b	v19, v12
	str	q22, [sp, #976]                 ; 16-byte Folded Spill
	tbnz	w1, #3, LBB0_69
	b	LBB0_70
LBB0_130:                               ; %cond.load2972
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d20
	ld1.s	{ v5 }[0], [x2]
	mov.16b	v22, v1
	ldr	q15, [sp, #784]                 ; 16-byte Folded Reload
	mov.16b	v4, v19
	mov.16b	v19, v0
	mov.16b	v13, v6
	tbz	w1, #5, LBB0_72
LBB0_131:                               ; %cond.load2978
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v20[1]
	ld1.s	{ v5 }[1], [x2]
	shl.2d	v6, v10, #5
	add.2d	v7, v23, v11
	add.2d	v16, v7, v6
	tbz	w1, #6, LBB0_73
LBB0_132:                               ; %cond.load2984
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d16
	ld1.s	{ v5 }[2], [x2]
	tbnz	w1, #7, LBB0_74
	b	LBB0_75
LBB0_133:                               ; %cond.load2850
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d8
	ldr	s3, [x2]
	tbz	w1, #1, LBB0_80
LBB0_134:                               ; %cond.load2856
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v8[1]
	ld1.s	{ v3 }[1], [x2]
	mov.16b	v8, v7
	shl.2d	v6, v19, #5
	add.2d	v7, v28, v29
	add.2d	v28, v7, v6
	tbz	w1, #2, LBB0_81
LBB0_135:                               ; %cond.load2862
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d28
	ld1.s	{ v3 }[2], [x2]
	mov.16b	v19, v12
	str	q22, [sp, #976]                 ; 16-byte Folded Spill
	tbnz	w1, #3, LBB0_82
	b	LBB0_83
LBB0_136:                               ; %cond.load2874
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d20
	ld1.s	{ v5 }[0], [x2]
	mov.16b	v22, v1
	ldr	q15, [sp, #784]                 ; 16-byte Folded Reload
	mov.16b	v4, v19
	mov.16b	v19, v0
	mov.16b	v13, v6
	tbz	w1, #5, LBB0_85
LBB0_137:                               ; %cond.load2880
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v20[1]
	ld1.s	{ v5 }[1], [x2]
	shl.2d	v6, v10, #5
	add.2d	v7, v23, v11
	add.2d	v16, v7, v6
	tbz	w1, #6, LBB0_86
LBB0_138:                               ; %cond.load2886
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d16
	ld1.s	{ v5 }[2], [x2]
	tbnz	w1, #7, LBB0_87
	b	LBB0_88
LBB0_139:                               ; %cond.load3046
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d8
	ldr	s3, [x2]
	tbz	w1, #1, LBB0_91
LBB0_140:                               ; %cond.load3052
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v8[1]
	ld1.s	{ v3 }[1], [x2]
	mov.16b	v8, v7
	shl.2d	v6, v19, #5
	add.2d	v7, v28, v29
	add.2d	v28, v7, v6
	tbz	w1, #2, LBB0_92
LBB0_141:                               ; %cond.load3058
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d28
	ld1.s	{ v3 }[2], [x2]
	mov.16b	v19, v12
	str	q22, [sp, #976]                 ; 16-byte Folded Spill
	tbnz	w1, #3, LBB0_93
	b	LBB0_94
LBB0_142:                               ; %cond.load3070
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d20
	ld1.s	{ v5 }[0], [x2]
	mov.16b	v22, v1
	ldr	q15, [sp, #784]                 ; 16-byte Folded Reload
	mov.16b	v4, v19
	mov.16b	v19, v0
	mov.16b	v13, v6
	tbz	w1, #5, LBB0_96
LBB0_143:                               ; %cond.load3076
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v20[1]
	ld1.s	{ v5 }[1], [x2]
	shl.2d	v6, v10, #5
	add.2d	v7, v23, v11
	add.2d	v16, v7, v6
	tbz	w1, #6, LBB0_97
LBB0_144:                               ; %cond.load3082
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d16
	ld1.s	{ v5 }[2], [x2]
	tbnz	w1, #7, LBB0_98
	b	LBB0_99
LBB0_145:                               ; %schedule.1
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w1, s3
	mov	w2, #3                          ; =0x3
	dup.2d	v3, x2
	ldr	q6, [sp, #432]                  ; 16-byte Folded Reload
	cmgt.2d	v5, v3, v6
	ldp	q7, q0, [sp, #560]              ; 32-byte Folded Reload
	cmgt.2d	v16, v3, v0
	uzp1.4s	v5, v16, v5
	cmgt.2d	v16, v3, v7
	ldr	q18, [sp, #544]                 ; 16-byte Folded Reload
	cmgt.2d	v17, v3, v18
	uzp1.4s	v16, v16, v17
	uzp1.8h	v5, v5, v16
	xtn.8b	v5, v5
	and.8b	v27, v24, v5
	shl.8b	v5, v27, #7
	cmlt.8b	v5, v5, #0
	and.8b	v16, v5, v2
	addv.8b	b16, v16
	fmov	w2, s16
	umaxv.8b	b5, v5
	fmov	w3, s5
	tbz	w3, #0, LBB0_151
; %bb.146:                              ; %schedule.1
                                        ;   in Loop: Header=BB0_10 Depth=3
	cmge.2d	v5, v6, v3
	cmge.2d	v16, v0, v3
	uzp1.4s	v5, v16, v5
	cmge.2d	v16, v7, v3
	cmge.2d	v3, v18, v3
	uzp1.4s	v3, v16, v3
	uzp1.8h	v3, v5, v3
	xtn.8b	v3, v3
	and.8b	v28, v24, v3
	shl.8b	v3, v28, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_151
; %bb.147:                              ; %varying.divergent
                                        ;   in Loop: Header=BB0_10 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #1248]
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	str	q0, [sp, #1264]
	and	x1, x1, #0x7
	add	x3, sp, #1248
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #0, #0, ne
	cset	w1, ne
	cmp	w2, #255
	b.ne	LBB0_149
; %bb.148:                              ; %varying.divergent
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbz	w1, #0, LBB0_149
	b	LBB0_746
LBB0_149:                               ; %convergence.overflow.resume
                                        ;   in Loop: Header=BB0_10 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #7, lsl #12             ; =28672
	add	x2, x2, #2800
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s3, w4
	ubfx	w4, w5, #1, #1
	mov.b	v3[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v3[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v3[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v3[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v3[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v3[6], w4
	add	x4, sp, #7, lsl #12             ; =28672
	add	x4, x4, #2792
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s5, w6
	ubfx	w6, w5, #1, #1
	mov.b	v5[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v5[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v5[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v5[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v5[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v5[6], w6
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v6, w5
	bit.8b	v3, v24, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x2, w3, uxtw]
	bic.8b	v3, v5, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_746
; %bb.150:                              ; %ready.overflow.resume74
                                        ;   in Loop: Header=BB0_10 Depth=3
	str	q25, [sp, #1216]
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	str	q0, [sp, #1232]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #1216
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	str	q25, [sp, #1184]
	str	q0, [sp, #1200]
	add	x5, sp, #1184
	str	w4, [x5, x2]
	ldr	q0, [sp, #1200]
	str	q0, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q25, [sp, #1184]
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #1152]
	ldr	q1, [sp, #1104]                 ; 16-byte Folded Reload
	str	q1, [sp, #1168]
	add	x4, sp, #1152
	ldr	w4, [x4, x2]
	csel	w4, wzr, w4, ne
	str	q0, [sp, #1120]
	str	q1, [sp, #1136]
	add	x5, sp, #1120
	str	w4, [x5, x2]
	csinc	w0, w0, w3, eq
	mov	w2, #38                         ; =0x26
	mov	w4, #2                          ; =0x2
	ldr	q0, [sp, #1136]
	str	q0, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #1120]
	str	q0, [sp, #1088]                 ; 16-byte Folded Spill
	b	LBB0_9
LBB0_151:                               ; %varying.coherent
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_719
; %bb.152:                              ; %varying.coherent.true
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w1, #0xff
	b.eq	LBB0_5
LBB0_153:                               ; %schedule.2
                                        ;   in Loop: Header=BB0_10 Depth=3
	str	q19, [sp, #592]                 ; 16-byte Folded Spill
	str	q31, [sp, #912]                 ; 16-byte Folded Spill
	str	q29, [sp, #864]                 ; 16-byte Folded Spill
	str	q14, [sp, #704]                 ; 16-byte Folded Spill
	stp	q15, q30, [sp, #784]            ; 32-byte Folded Spill
	rbit	w2, w1
	clz	w2, w2
	tst	w1, #0xff
	csel	w2, wzr, w2, eq
	ubfiz	x4, x2, #3, #3
	lsl	w5, w2, #2
Lloh10:
	adrp	x2, lCPI0_4@PAGE
Lloh11:
	ldr	q3, [x2, lCPI0_4@PAGEOFF]
Lloh12:
	adrp	x2, lCPI0_5@PAGE
Lloh13:
	ldr	q5, [x2, lCPI0_5@PAGEOFF]
	str	q3, [sp, #4720]
	str	q5, [sp, #4704]
Lloh14:
	adrp	x2, lCPI0_6@PAGE
Lloh15:
	ldr	q3, [x2, lCPI0_6@PAGEOFF]
Lloh16:
	adrp	x2, lCPI0_7@PAGE
Lloh17:
	ldr	q5, [x2, lCPI0_7@PAGEOFF]
	str	q3, [sp, #4688]
	str	q5, [sp, #4672]
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #576
	ldr	x2, [x2, x4]
	sub	x2, x2, x5
	tst	w1, #0xff
Lloh18:
	adrp	x3, lCPI0_8@PAGE
Lloh19:
	ldr	q3, [x3, lCPI0_8@PAGEOFF]
Lloh20:
	adrp	x3, lCPI0_9@PAGE
Lloh21:
	ldr	q5, [x3, lCPI0_9@PAGEOFF]
	str	q3, [sp, #4656]
	str	q5, [sp, #4640]
Lloh22:
	adrp	x3, lCPI0_10@PAGE
Lloh23:
	ldr	q3, [x3, lCPI0_10@PAGEOFF]
Lloh24:
	adrp	x3, lCPI0_11@PAGE
Lloh25:
	ldr	q5, [x3, lCPI0_11@PAGEOFF]
	str	q3, [sp, #4624]
	str	q5, [sp, #4608]
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #512
	ldr	x3, [x3, x4]
	csel	x2, xzr, x2, eq
	sub	x3, x3, x5
	tst	w1, #0xff
Lloh26:
	adrp	x6, lCPI0_12@PAGE
Lloh27:
	ldr	q3, [x6, lCPI0_12@PAGEOFF]
Lloh28:
	adrp	x6, lCPI0_13@PAGE
Lloh29:
	ldr	q5, [x6, lCPI0_13@PAGEOFF]
	str	q3, [sp, #4592]
	str	q5, [sp, #4576]
Lloh30:
	adrp	x6, lCPI0_14@PAGE
Lloh31:
	ldr	q3, [x6, lCPI0_14@PAGEOFF]
Lloh32:
	adrp	x6, lCPI0_15@PAGE
Lloh33:
	ldr	q5, [x6, lCPI0_15@PAGEOFF]
	str	q3, [sp, #4560]
	str	q5, [sp, #4544]
	add	x6, sp, #1, lsl #12             ; =4096
	add	x6, x6, #448
	ldr	x6, [x6, x4]
	csel	x3, xzr, x3, eq
	sub	x6, x6, x5
	tst	w1, #0xff
Lloh34:
	adrp	x7, lCPI0_16@PAGE
Lloh35:
	ldr	q1, [x7, lCPI0_16@PAGEOFF]
Lloh36:
	adrp	x7, lCPI0_17@PAGE
Lloh37:
	ldr	q3, [x7, lCPI0_17@PAGEOFF]
Lloh38:
	adrp	x7, lCPI0_18@PAGE
Lloh39:
	ldr	q19, [x7, lCPI0_18@PAGEOFF]
Lloh40:
	adrp	x7, lCPI0_19@PAGE
Lloh41:
	ldr	q14, [x7, lCPI0_19@PAGEOFF]
	str	q14, [sp, #4528]
	str	q19, [sp, #4512]
	str	q3, [sp, #4496]
	str	q1, [sp, #4480]
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #384
	ldr	x7, [x7, x4]
	csel	x4, xzr, x6, eq
	sub	x5, x7, x5
	ands	w1, w1, #0xff
	ldr	q28, [sp, #6512]
	ldr	q29, [sp, #6464]
	mov.16b	v18, v8
	str	q22, [sp, #752]                 ; 16-byte Folded Spill
	ldr	q30, [sp, #6480]
	ldr	q8, [sp, #6496]
	mov.16b	v21, v9
	ldr	q9, [sp, #6432]
	ldr	q27, [sp, #6448]
	ldr	q17, [sp, #6400]
	ldr	q16, [sp, #6416]
	mov	b5, v24[2]
	mov.b	v5[4], v24[3]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	ldr	q6, [sp, #112]                  ; 16-byte Folded Reload
	mov.16b	v23, v5
	bsl.16b	v23, v6, v16
	mov	b16, v24[0]
	mov.b	v16[4], v24[1]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	mov.16b	v31, v26
	ldr	q20, [sp, #1024]                ; 16-byte Folded Reload
	mov.16b	v22, v13
	mov.16b	v13, v12
	mov	b11, v24[6]
	mov.b	v11[4], v24[7]
	mov.16b	v7, v4
	mov.16b	v4, v25
	mov.16b	v12, v16
	bsl.16b	v12, v6, v17
	ushll.2d	v17, v11, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	mov.16b	v11, v17
	bsl.16b	v11, v6, v27
	mov	b27, v24[4]
	mov.b	v27[4], v24[5]
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	bit.16b	v9, v6, v27
	bit.16b	v8, v19, v27
	bit.16b	v30, v3, v5
	bit.16b	v29, v1, v16
	bit.16b	v28, v14, v17
	zip2.8b	v25, v24, v0
	ushll.4s	v25, v25, #0
	shl.4s	v25, v25, #31
	cmlt.4s	v25, v25, #0
	zip1.8b	v26, v24, v0
	ushll.4s	v26, v26, #0
	shl.4s	v26, v26, #31
	cmlt.4s	v26, v26, #0
	str	q28, [sp, #6512]
	str	q29, [sp, #6464]
	str	q30, [sp, #6480]
	str	q9, [sp, #6432]
	str	q11, [sp, #6448]
	mov.16b	v11, v20
	mov.16b	v15, v31
	str	q12, [sp, #6400]
	mov.16b	v31, v4
	str	q23, [sp, #6416]
	mov.16b	v12, v21
	str	q8, [sp, #6496]
	ldr	q28, [sp, #6640]
	ldr	q29, [sp, #6624]
	csel	x5, xzr, x5, eq
	add	x6, sp, #7, lsl #12             ; =28672
	add	x6, x6, #2664
	add	x5, x6, x5
	ldp	q8, q30, [x5]
	bif.16b	v29, v8, v26
	bif.16b	v28, v30, v25
	stp	q29, q28, [x5]
	ldr	q28, [sp, #6608]
	ldr	q29, [sp, #6592]
	add	x4, x6, x4
	ldp	q8, q30, [x4]
	bif.16b	v29, v8, v26
	bif.16b	v28, v30, v25
	stp	q29, q28, [x4]
	ldr	q28, [sp, #6576]
	ldr	q29, [sp, #6560]
	add	x3, x6, x3
	ldp	q8, q30, [x3]
	bif.16b	v29, v8, v26
	bif.16b	v28, v30, v25
	stp	q29, q28, [x3]
	ldr	q28, [sp, #6528]
	ldr	q29, [sp, #6544]
	add	x2, x6, x2
	ldp	q30, q8, [x2]
	bsl.16b	v25, v29, v8
	bsl.16b	v26, v28, v30
	stp	q26, q25, [x2]
	ldp	q6, q0, [sp, #544]              ; 32-byte Folded Reload
	shl.2d	v25, v6, #5
	shl.2d	v26, v0, #5
	ldr	q0, [sp, #432]                  ; 16-byte Folded Reload
	shl.2d	v28, v0, #5
	ldr	q0, [sp, #576]                  ; 16-byte Folded Reload
	shl.2d	v29, v0, #5
	ldr	q30, [sp, #6384]
	ldr	q8, [sp, #6368]
	ldr	q9, [sp, #6352]
	ldr	q10, [sp, #6336]
	bif.16b	v29, v10, v16
	bif.16b	v28, v9, v5
	bif.16b	v26, v8, v27
	bif.16b	v25, v30, v17
	str	q25, [sp, #6384]
	str	q26, [sp, #6368]
	str	q28, [sp, #6352]
	str	q29, [sp, #6336]
	ldr	q25, [sp, #6272]
	ldr	q26, [sp, #6288]
	ldr	q28, [sp, #6320]
	ldr	q29, [sp, #6304]
	ldr	q30, [sp, #6208]
	ldr	q8, [sp, #6224]
	ldr	q9, [sp, #6256]
	ldr	q10, [sp, #6240]
	ldr	q6, [sp, #96]                   ; 16-byte Folded Reload
	bit.16b	v10, v6, v27
	bit.16b	v9, v6, v17
	bit.16b	v8, v6, v5
	bit.16b	v30, v6, v16
	mov.16b	v20, v27
	bsl.16b	v20, v19, v29
	mov.16b	v21, v17
	bsl.16b	v21, v14, v28
	mov.16b	v19, v5
	bsl.16b	v19, v3, v26
	ldr	q4, [sp, #912]                  ; 16-byte Folded Reload
	mov.16b	v3, v16
	bsl.16b	v3, v1, v25
	mov.16b	v25, v31
	ldr	q29, [sp, #864]                 ; 16-byte Folded Reload
	str	q3, [sp, #6272]
	str	q19, [sp, #6288]
	str	q21, [sp, #6320]
	str	q20, [sp, #6304]
	str	q30, [sp, #6208]
	mov.16b	v31, v4
	mov.16b	v4, v7
	str	q8, [sp, #6224]
	ldr	q19, [sp, #592]                 ; 16-byte Folded Reload
	str	q9, [sp, #6256]
	mov.16b	v9, v12
	mov.16b	v12, v13
	ldr	q6, [sp, #752]                  ; 16-byte Folded Reload
	mov.16b	v13, v22
	mov.16b	v22, v6
	mov.16b	v26, v15
	ldr	q14, [sp, #704]                 ; 16-byte Folded Reload
	ldp	q15, q30, [sp, #784]            ; 32-byte Folded Reload
	str	q10, [sp, #6240]
	bic.16b	v31, v31, v17
	bic.16b	v8, v18, v27
	bic.16b	v29, v29, v5
	bic.16b	v0, v11, v16
	str	q0, [sp, #1024]                 ; 16-byte Folded Spill
	cbz	w1, LBB0_5
LBB0_154:                               ; %schedule.3
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	mov	w1, #128                        ; =0x80
	dup.2d	v3, x1
	cmgt.2d	v5, v3, v29
	ldr	q0, [sp, #1024]                 ; 16-byte Folded Reload
	cmgt.2d	v16, v3, v0
	uzp1.4s	v5, v16, v5
	cmgt.2d	v16, v3, v8
	cmgt.2d	v17, v3, v31
	uzp1.4s	v16, v16, v17
	uzp1.8h	v5, v5, v16
	xtn.8b	v5, v5
	and.8b	v27, v24, v5
	shl.8b	v5, v27, #7
	cmlt.8b	v5, v5, #0
	and.8b	v16, v5, v2
	addv.8b	b16, v16
	fmov	w1, s16
	umaxv.8b	b5, v5
	fmov	w3, s5
	tbz	w3, #0, LBB0_160
; %bb.155:                              ; %schedule.3
                                        ;   in Loop: Header=BB0_10 Depth=3
	cmge.2d	v5, v29, v3
	ldr	q0, [sp, #1024]                 ; 16-byte Folded Reload
	cmge.2d	v16, v0, v3
	uzp1.4s	v5, v16, v5
	cmge.2d	v16, v8, v3
	cmge.2d	v3, v31, v3
	uzp1.4s	v3, v16, v3
	uzp1.8h	v3, v5, v3
	xtn.8b	v3, v3
	and.8b	v28, v24, v3
	shl.8b	v3, v28, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_160
; %bb.156:                              ; %varying.divergent87
                                        ;   in Loop: Header=BB0_10 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #1408]
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	str	q0, [sp, #1424]
	and	x1, x1, #0x7
	add	x3, sp, #1408
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #1, #0, ne
	cset	w1, ne
	cmp	w2, #255
	b.ne	LBB0_158
; %bb.157:                              ; %varying.divergent87
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbz	w1, #0, LBB0_158
	b	LBB0_746
LBB0_158:                               ; %convergence.overflow.resume90
                                        ;   in Loop: Header=BB0_10 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #7, lsl #12             ; =28672
	add	x2, x2, #2800
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s3, w4
	ubfx	w4, w5, #1, #1
	mov.b	v3[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v3[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v3[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v3[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v3[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v3[6], w4
	add	x4, sp, #7, lsl #12             ; =28672
	add	x4, x4, #2792
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s5, w6
	ubfx	w6, w5, #1, #1
	mov.b	v5[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v5[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v5[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v5[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v5[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v5[6], w6
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v6, w5
	bit.8b	v3, v24, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x2, w3, uxtw]
	bic.8b	v3, v5, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_746
; %bb.159:                              ; %ready.overflow.resume92
                                        ;   in Loop: Header=BB0_10 Depth=3
	str	q25, [sp, #1376]
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	str	q0, [sp, #1392]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #1376
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q25, [sp, #1344]
	str	q0, [sp, #1360]
	add	x5, sp, #1344
	str	w4, [x5, x2]
	ldr	q0, [sp, #1360]
	str	q0, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q25, [sp, #1344]
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #1312]
	ldr	q1, [sp, #1104]                 ; 16-byte Folded Reload
	str	q1, [sp, #1328]
	add	x4, sp, #1312
	ldr	w4, [x4, x2]
	csinc	w4, w4, wzr, eq
	str	q0, [sp, #1280]
	str	q1, [sp, #1296]
	add	x5, sp, #1280
	str	w4, [x5, x2]
	mov	w2, #7                          ; =0x7
	mov	w4, #4                          ; =0x4
	ldr	q0, [sp, #1296]
	str	q0, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #1280]
	str	q0, [sp, #1088]                 ; 16-byte Folded Spill
                                        ; kill: def $w3 killed $w3 killed $x3 def $x3
	b	LBB0_9
LBB0_160:                               ; %varying.coherent88
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w1, #0xff
	b.eq	LBB0_200
; %bb.161:                              ; %varying.coherent.true93
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov	w1, #0                          ; =0x0
	tst	w2, #0xff
	b.eq	LBB0_5
LBB0_162:                               ; %schedule.4
                                        ;   in Loop: Header=BB0_10 Depth=3
	stp	q30, q26, [sp, #800]            ; 32-byte Folded Spill
	stp	q14, q25, [sp, #704]            ; 32-byte Folded Spill
	str	q29, [sp, #864]                 ; 16-byte Folded Spill
	stp	q19, q4, [sp, #592]             ; 32-byte Folded Spill
	mov	b3, v24[0]
	mov.b	v3[4], v24[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v6, v3, #0
	ldr	q11, [sp, #1024]                ; 16-byte Folded Reload
	and.16b	v0, v6, v11
	mov	b5, v24[2]
	mov.b	v5[4], v24[3]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v23, v5, #0
	and.16b	v5, v23, v29
	mov	b16, v24[4]
	mov.b	v16[4], v24[5]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v27, v16, #0
	and.16b	v16, v27, v8
	mov	b17, v24[6]
	mov.b	v17[4], v24[7]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v1, v17, #0
	and.16b	v17, v1, v31
	mov	w2, #32                         ; =0x20
	dup.2d	v25, x2
	and.16b	v21, v6, v25
	mvn.16b	v26, v6
	sub.2d	v21, v21, v26
	and.16b	v26, v23, v25
	mvn.16b	v29, v23
	sub.2d	v29, v26, v29
	and.16b	v26, v27, v25
	mov.16b	v7, v22
	mvn.16b	v30, v27
	sub.2d	v26, v26, v30
	mov.16b	v22, v1
	and.16b	v25, v1, v25
	mvn.16b	v30, v1
	sub.2d	v25, v25, v30
	mov.d	x2, v25[1]
	mov.d	x3, v17[1]
	sdiv	x3, x3, x2
	fmov	x4, d25
	fmov	x5, d17
	sdiv	x5, x5, x4
	mul	x4, x5, x4
	fmov	d25, x5
	mov.d	v25[1], x3
	mov.d	x5, v26[1]
	mov.d	x6, v16[1]
	sdiv	x6, x6, x5
	fmov	x7, d26
	fmov	x19, d16
	sdiv	x19, x19, x7
	mul	x7, x19, x7
	fmov	d26, x19
	mov.d	v26[1], x6
	mov.d	x19, v29[1]
	mov.d	x20, v5[1]
	sdiv	x20, x20, x19
	fmov	x21, d29
	fmov	x22, d5
	sdiv	x22, x22, x21
	mul	x21, x22, x21
	fmov	d29, x22
	mov.d	v29[1], x20
	mov.d	x22, v21[1]
	mov.d	x23, v0[1]
	fmov	x24, d21
	fmov	x25, d0
	sdiv	x25, x25, x24
	mul	x24, x25, x24
	fmov	d21, x25
	sdiv	x23, x23, x22
	mov.d	v21[1], x23
	mul	x19, x20, x19
	fmov	d30, x21
	mov.d	v30[1], x19
	mul	x19, x23, x22
	mov.16b	v3, v8
	fmov	d8, x24
	mov.d	v8[1], x19
	mul	x2, x3, x2
	mov.16b	v1, v13
	mov.16b	v13, v31
	mov.16b	v31, v9
	fmov	d9, x4
	mov.d	v9[1], x2
	mul	x2, x6, x5
	fmov	d10, x7
	mov.d	v10[1], x2
	sub.2d	v20, v16, v10
	sub.2d	v19, v17, v9
	sub.2d	v18, v0, v8
	sub.2d	v28, v5, v30
	ldr	q30, [sp, #6704]
	ldr	q8, [sp, #6688]
	ldr	q9, [sp, #6672]
	ldr	q10, [sp, #6656]
	add.2d	v21, v10, v21
	add.2d	v29, v9, v29
	add.2d	v26, v8, v26
	mov	w2, #17                         ; =0x11
	dup.2d	v8, x2
	add.2d	v25, v30, v25
	cmhi.2d	v30, v8, v25
	cmhi.2d	v9, v8, v26
	uzp1.4s	v30, v9, v30
	cmhi.2d	v9, v8, v29
	cmhi.2d	v8, v8, v21
	uzp1.4s	v8, v8, v9
	uzp1.8h	v14, v8, v30
	ldr	q8, [sp, #6368]
	ldr	q9, [sp, #6384]
	ldr	q10, [sp, #6336]
	mov.16b	v16, v13
	mov.16b	v13, v1
	str	q11, [sp, #1024]                ; 16-byte Folded Spill
	mov.16b	v30, v3
	ldr	q11, [sp, #6352]
	add.2d	v28, v11, v28
	mov.16b	v4, v12
	add.2d	v3, v10, v18
	add.2d	v17, v9, v19
	mov.16b	v9, v31
	mov.16b	v31, v16
	ldr	q19, [sp, #864]                 ; 16-byte Folded Reload
	ldr	q12, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v16, v8, v20
	mov.d	x2, v29[1]
	fmov	x3, d29
	add	x3, x3, x3, lsl #6
	fmov	d29, x3
	add	x2, x2, x2, lsl #6
	mov.d	v29[1], x2
	mov.d	x2, v21[1]
	fmov	x3, d21
	add	x3, x3, x3, lsl #6
	fmov	d21, x3
	add	x2, x2, x2, lsl #6
	mov.d	v21[1], x2
	mov.d	x2, v25[1]
	fmov	x3, d25
	add	x3, x3, x3, lsl #6
	fmov	d25, x3
	add	x2, x2, x2, lsl #6
	mov.d	v25[1], x2
	mov.d	x2, v26[1]
	fmov	x3, d26
	add	x3, x3, x3, lsl #6
	fmov	d26, x3
	add	x2, x2, x2, lsl #6
	mov.d	v26[1], x2
	mov	w2, #65                         ; =0x41
	dup.2d	v8, x2
	add.2d	v26, v26, v16
	add.2d	v25, v25, v17
	add.2d	v21, v21, v3
	add.2d	v29, v29, v28
	cmhi.2d	v17, v8, v17
	cmhi.2d	v16, v8, v16
	uzp1.4s	v16, v16, v17
	cmhi.2d	v5, v8, v28
	cmhi.2d	v3, v8, v3
	mov.16b	v8, v30
	ldr	q0, [sp, #592]                  ; 16-byte Folded Reload
	uzp1.4s	v3, v3, v5
	uzp1.8h	v3, v3, v16
	and.16b	v3, v14, v3
	xtn.8b	v3, v3
	ldr	q5, [sp, #6176]
	ldr	q16, [sp, #6192]
	ldr	q17, [sp, #6144]
	ldr	q30, [sp, #6160]
	mov.16b	v20, v23
	bsl.16b	v20, v29, v30
	mov.16b	v29, v19
	mov.16b	v19, v0
	mov.16b	v14, v12
	mov.16b	v12, v4
	ldp	q30, q0, [sp, #800]             ; 32-byte Folded Reload
	ldr	q4, [sp, #608]                  ; 16-byte Folded Reload
	bit.16b	v17, v21, v6
	bit.16b	v16, v25, v22
	mov.16b	v22, v7
	bit.16b	v5, v26, v27
	mov.16b	v26, v0
	str	q5, [sp, #6176]
	str	q16, [sp, #6192]
	str	q17, [sp, #6144]
	str	q20, [sp, #6160]
	and.8b	v27, v24, v3
	shl.8b	v5, v27, #7
	cmlt.8b	v5, v5, #0
	and.8b	v16, v5, v2
	addv.8b	b16, v16
	fmov	w2, s16
	umaxv.8b	b5, v5
	fmov	w3, s5
	tbz	w3, #0, LBB0_168
; %bb.163:                              ; %schedule.4
                                        ;   in Loop: Header=BB0_10 Depth=3
	bic.8b	v28, v24, v3
	shl.8b	v3, v28, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_168
; %bb.164:                              ; %varying.divergent98
                                        ;   in Loop: Header=BB0_10 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #1568]
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	str	q0, [sp, #1584]
	and	x1, x1, #0x7
	add	x3, sp, #1568
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #2, #0, ne
	cset	w1, ne
	cmp	w2, #255
	b.ne	LBB0_166
; %bb.165:                              ; %varying.divergent98
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbz	w1, #0, LBB0_166
	b	LBB0_746
LBB0_166:                               ; %convergence.overflow.resume101
                                        ;   in Loop: Header=BB0_10 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #7, lsl #12             ; =28672
	add	x2, x2, #2800
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s3, w4
	ubfx	w4, w5, #1, #1
	mov.b	v3[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v3[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v3[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v3[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v3[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v3[6], w4
	add	x4, sp, #7, lsl #12             ; =28672
	add	x4, x4, #2792
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s5, w6
	ubfx	w6, w5, #1, #1
	mov.b	v5[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v5[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v5[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v5[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v5[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v5[6], w6
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v6, w5
	bit.8b	v3, v24, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x2, w3, uxtw]
	bic.8b	v3, v5, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	ldr	q1, [sp, #1072]                 ; 16-byte Folded Reload
	ldr	q5, [sp, #720]                  ; 16-byte Folded Reload
	b.hs	LBB0_746
; %bb.167:                              ; %ready.overflow.resume106
                                        ;   in Loop: Header=BB0_10 Depth=3
	zip2.8b	v3, v28, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldp	q7, q0, [sp, #512]              ; 32-byte Folded Reload
	and.16b	v6, v3, v7
	zip1.8b	v3, v28, v7
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v0, v3, v0
	stp	q6, q0, [sp, #512]              ; 32-byte Folded Spill
	str	q5, [sp, #1536]
	str	q1, [sp, #1552]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #1536
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q5, [sp, #1504]
	str	q1, [sp, #1520]
	add	x5, sp, #1504
	str	w4, [x5, x2]
	ldr	q0, [sp, #1520]
	str	q0, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q25, [sp, #1504]
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #1472]
	ldr	q1, [sp, #1104]                 ; 16-byte Folded Reload
	str	q1, [sp, #1488]
	add	x4, sp, #1472
	ldr	w4, [x4, x2]
	mov	w5, #2                          ; =0x2
	csel	w4, w5, w4, ne
	str	q0, [sp, #1440]
	str	q1, [sp, #1456]
	add	x5, sp, #1440
	str	w4, [x5, x2]
	mov	w2, #6                          ; =0x6
	mov	w4, #5                          ; =0x5
	ldr	q0, [sp, #1456]
	str	q0, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #1440]
	str	q0, [sp, #1088]                 ; 16-byte Folded Spill
                                        ; kill: def $w3 killed $w3 killed $x3 def $x3
	b	LBB0_9
LBB0_168:                               ; %varying.coherent99
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_199
; %bb.169:                              ; %varying.coherent.true107
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q25, [sp, #720]                 ; 16-byte Folded Reload
	tbnz	w1, #0, LBB0_5
; %bb.170:                              ; %schedule.5.thread
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v0, v19
	ldr	q3, [sp, #6192]
	ldr	q5, [sp, #6176]
	ldr	q6, [sp, #6160]
	ldr	q7, [sp, #6144]
	shl.2d	v7, v7, #2
	shl.2d	v6, v6, #2
	shl.2d	v16, v5, #2
	dup.2d	v18, x10
	shl.2d	v3, v3, #2
	add.2d	v5, v18, v3
	add.2d	v17, v18, v16
	add.2d	v19, v18, v6
	add.2d	v20, v18, v7
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w1, s3
	movi.2d	v3, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbnz	w1, #0, LBB0_209
; %bb.171:                              ; %else3270
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #1, LBB0_210
LBB0_172:                               ; %else3276
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #2, LBB0_211
LBB0_173:                               ; %else3282
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #3, LBB0_212
LBB0_174:                               ; %else3288
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v19, v0
	tbnz	w1, #4, LBB0_213
LBB0_175:                               ; %else3294
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #5, LBB0_214
LBB0_176:                               ; %else3300
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #6, LBB0_215
LBB0_177:                               ; %else3306
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbz	w1, #7, LBB0_179
LBB0_178:                               ; %cond.load3308
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x1, v5[1]
	ld1.s	{ v16 }[3], [x1]
LBB0_179:                               ; %else3312
                                        ;   in Loop: Header=BB0_10 Depth=3
	zip2.8b	v5, v24, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q0, [sp, #512]                  ; 16-byte Folded Reload
	bit.16b	v0, v16, v5
	str	q0, [sp, #512]                  ; 16-byte Folded Spill
	zip1.8b	v5, v24, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q0, [sp, #528]                  ; 16-byte Folded Reload
	bit.16b	v0, v3, v5
	str	q0, [sp, #528]                  ; 16-byte Folded Spill
	cbnz	w0, LBB0_61
LBB0_180:                               ; %schedule.6.convergence.cascade.exit_crit_edge
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v28, v19
	mov.16b	v27, v26
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_181:                               ; %convergence.cascade.exit
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_716
; %bb.182:                              ; %convergence.target.6.ready
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v1, v25
	ldr	q3, [sp, #6256]
	ldr	q5, [sp, #6240]
	ldr	q6, [sp, #6224]
	ldr	q7, [sp, #6208]
	ldr	q16, [sp, #6272]
	ldr	q17, [sp, #6288]
	ldr	q18, [sp, #6304]
	ldr	q19, [sp, #6320]
	ldr	q0, [sp, #1024]                 ; 16-byte Folded Reload
	shl.2d	v20, v0, #5
	shl.2d	v21, v29, #5
	shl.2d	v25, v8, #5
	shl.2d	v26, v31, #5
	add.2d	v19, v19, v26
	add.2d	v18, v18, v25
	add.2d	v21, v17, v21
	add.2d	v16, v16, v20
	add.2d	v17, v7, v16
	add.2d	v16, v6, v21
	add.2d	v5, v5, v18
	add.2d	v3, v3, v19
	shl.8b	v6, v24, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	fmov	w1, s6
	tbnz	w1, #0, LBB0_192
; %bb.183:                              ; %else3318
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #1, LBB0_193
LBB0_184:                               ; %else3322
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v25, v1
	mov.16b	v26, v27
	mov.16b	v19, v28
	tbnz	w1, #2, LBB0_194
LBB0_185:                               ; %else3326
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #3, LBB0_195
LBB0_186:                               ; %else3330
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #4, LBB0_196
LBB0_187:                               ; %else3334
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #5, LBB0_197
LBB0_188:                               ; %else3338
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #6, LBB0_198
LBB0_189:                               ; %else3342
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbz	w1, #7, LBB0_191
LBB0_190:                               ; %cond.store3343
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x1, v3[1]
	ldr	q0, [sp, #512]                  ; 16-byte Folded Reload
	st1.s	{ v0 }[3], [x1]
LBB0_191:                               ; %else3346
                                        ;   in Loop: Header=BB0_10 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v24, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v5, v3, #0
	ushll2.4s	v3, v3, #0
	uaddw2.2d	v31, v31, v3
	uaddw.2d	v8, v8, v3
	uaddw2.2d	v29, v29, v5
	ldr	q0, [sp, #1024]                 ; 16-byte Folded Reload
	uaddw.2d	v0, v0, v5
	str	q0, [sp, #1024]                 ; 16-byte Folded Spill
	b	LBB0_154
LBB0_192:                               ; %cond.store3315
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d17
	ldr	q0, [sp, #528]                  ; 16-byte Folded Reload
	str	s0, [x2]
	tbz	w1, #1, LBB0_184
LBB0_193:                               ; %cond.store3319
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v17[1]
	ldr	q0, [sp, #528]                  ; 16-byte Folded Reload
	st1.s	{ v0 }[1], [x2]
	mov.16b	v25, v1
	mov.16b	v26, v27
	mov.16b	v19, v28
	tbz	w1, #2, LBB0_185
LBB0_194:                               ; %cond.store3323
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d16
	ldr	q0, [sp, #528]                  ; 16-byte Folded Reload
	st1.s	{ v0 }[2], [x2]
	tbz	w1, #3, LBB0_186
LBB0_195:                               ; %cond.store3327
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v16[1]
	ldr	q0, [sp, #528]                  ; 16-byte Folded Reload
	st1.s	{ v0 }[3], [x2]
	tbz	w1, #4, LBB0_187
LBB0_196:                               ; %cond.store3331
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d5
	ldr	q0, [sp, #512]                  ; 16-byte Folded Reload
	str	s0, [x2]
	tbz	w1, #5, LBB0_188
LBB0_197:                               ; %cond.store3335
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v5[1]
	ldr	q0, [sp, #512]                  ; 16-byte Folded Reload
	st1.s	{ v0 }[1], [x2]
	tbz	w1, #6, LBB0_189
LBB0_198:                               ; %cond.store3339
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d3
	ldr	q0, [sp, #512]                  ; 16-byte Folded Reload
	st1.s	{ v0 }[2], [x2]
	tbnz	w1, #7, LBB0_190
	b	LBB0_191
LBB0_199:                               ; %varying.coherent.false108
                                        ;   in Loop: Header=BB0_10 Depth=3
	zip2.8b	v3, v24, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldp	q5, q0, [sp, #512]              ; 32-byte Folded Reload
	and.16b	v1, v3, v5
	zip1.8b	v3, v24, v5
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v0, v3, v0
	stp	q1, q0, [sp, #512]              ; 32-byte Folded Spill
	ldr	q25, [sp, #720]                 ; 16-byte Folded Reload
	tbz	w1, #0, LBB0_60
	b	LBB0_5
LBB0_200:                               ; %varying.coherent.false94
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_5
LBB0_201:                               ; %schedule.7
                                        ;   in Loop: Header=BB0_10 Depth=3
	cbz	w0, LBB0_206
; %bb.202:                              ; %convergence.cascade122.preheader
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov	w1, #0                          ; =0x0
LBB0_203:                               ; %convergence.cascade122
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_10 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v5, v3, v2
	addv.8b	b5, v5
	fmov	w2, s5
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #4448]
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	str	q0, [sp, #4464]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #1, lsl #12             ; =4096
	add	x6, x6, #352
	ldr	w6, [x6, x2]
	cmp	w6, #1
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #7, lsl #12             ; =28672
	add	x5, x5, #2800
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s3, w19
	ubfx	w19, w20, #1, #1
	mov.b	v3[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v3[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v3[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v3[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v3[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v3[6], w19
	add	x19, sp, #7, lsl #12            ; =28672
	add	x19, x19, #2792
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s5, w21
	ubfx	w21, w20, #1, #1
	mov.b	v5[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v5[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v5[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v5[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v5[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v5[6], w21
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	orr.8b	v6, v24, v5
	ldr	d0, [sp, #1064]                 ; 8-byte Folded Reload
	and.8b	v7, v0, v3
	eor.8b	v7, v7, v6
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v6, v7
	dup.8b	v17, w7
	bit.8b	v5, v16, v17
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x19, w3, sxtw]
	bic.8b	v3, v3, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v5, v5, v6
	str	q25, [sp, #4416]
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	str	q0, [sp, #4432]
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #320
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v24, v5, v3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_207
; %bb.204:                              ; %convergence.cascade122
                                        ;   in Loop: Header=BB0_203 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_207
; %bb.205:                              ; %convergence.cascade122
                                        ;   in Loop: Header=BB0_203 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_203
	b	LBB0_207
LBB0_206:                               ; %schedule.7.convergence.cascade.exit123_crit_edge
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_207:                               ; %convergence.cascade.exit123
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_5
; %bb.208:                              ; %convergence.target.7.ready
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q17, [sp, #6112]
	ldr	q5, [sp, #6128]
	ldr	q3, [sp, #6080]
	ldr	q6, [sp, #6096]
	ldr	q16, [sp, #6048]
	ldr	q7, [sp, #6064]
	ldr	q18, [sp, #6016]
	ldr	q20, [sp, #6032]
	mov.16b	v11, v8
	mov.16b	v8, v29
	mov.16b	v29, v4
	mov.16b	v4, v31
	mov.16b	v31, v15
	mov.16b	v15, v12
	mov.16b	v12, v14
	mov.16b	v14, v13
	mov.16b	v13, v9
	mov.16b	v9, v30
	mov.16b	v30, v19
	mov	b19, v24[2]
	mov.b	v19[4], v24[3]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	ldr	q28, [sp, #192]                 ; 16-byte Folded Reload
	bit.16b	v20, v28, v19
	mov	b21, v24[0]
	mov.b	v21[4], v24[1]
	ushll.2d	v21, v21, #0
	shl.2d	v21, v21, #63
	cmlt.2d	v21, v21, #0
	mov.16b	v0, v25
	mov	b25, v24[6]
	mov.b	v25[4], v24[7]
	bit.16b	v18, v28, v21
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	bit.16b	v7, v28, v25
	mov.16b	v1, v26
	mov	b26, v24[4]
	mov.b	v26[4], v24[5]
	ushll.2d	v26, v26, #0
	shl.2d	v26, v26, #63
	cmlt.2d	v26, v26, #0
Lloh42:
	adrp	x1, lCPI0_17@PAGE
Lloh43:
	ldr	q27, [x1, lCPI0_17@PAGEOFF]
	bit.16b	v6, v27, v19
Lloh44:
	adrp	x1, lCPI0_18@PAGE
Lloh45:
	ldr	q27, [x1, lCPI0_18@PAGEOFF]
	bit.16b	v17, v27, v26
Lloh46:
	adrp	x1, lCPI0_16@PAGE
Lloh47:
	ldr	q27, [x1, lCPI0_16@PAGEOFF]
	str	q17, [sp, #6112]
Lloh48:
	adrp	x1, lCPI0_19@PAGE
Lloh49:
	ldr	q17, [x1, lCPI0_19@PAGEOFF]
	bit.16b	v16, v28, v26
	bit.16b	v5, v17, v25
	str	q5, [sp, #6128]
	bit.16b	v3, v27, v21
	str	q3, [sp, #6080]
	str	q6, [sp, #6096]
	str	q16, [sp, #6048]
	str	q7, [sp, #6064]
	str	q18, [sp, #6016]
	str	q20, [sp, #6032]
	ldr	q3, [sp, #832]                  ; 16-byte Folded Reload
	bic.16b	v3, v3, v25
	str	q3, [sp, #832]                  ; 16-byte Folded Spill
	mov.16b	v25, v0
	bic.16b	v26, v1, v26
	ldr	q0, [sp, #896]                  ; 16-byte Folded Reload
	bic.16b	v0, v0, v19
	mov.16b	v19, v30
	mov.16b	v30, v9
	mov.16b	v9, v13
	mov.16b	v13, v14
	mov.16b	v14, v12
	mov.16b	v12, v15
	mov.16b	v15, v31
	mov.16b	v31, v4
	mov.16b	v4, v29
	mov.16b	v29, v8
	mov.16b	v8, v11
	str	q0, [sp, #896]                  ; 16-byte Folded Spill
	ldr	q0, [sp, #1040]                 ; 16-byte Folded Reload
	bic.16b	v0, v0, v21
	str	q0, [sp, #1040]                 ; 16-byte Folded Spill
	b	LBB0_216
LBB0_209:                               ; %cond.load3266
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d20
	ldr	s3, [x2]
	tbz	w1, #1, LBB0_172
LBB0_210:                               ; %cond.load3272
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v20[1]
	ld1.s	{ v3 }[1], [x2]
	tbz	w1, #2, LBB0_173
LBB0_211:                               ; %cond.load3278
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d19
	ld1.s	{ v3 }[2], [x2]
	tbz	w1, #3, LBB0_174
LBB0_212:                               ; %cond.load3284
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v19[1]
	ld1.s	{ v3 }[3], [x2]
	mov.16b	v19, v0
	tbz	w1, #4, LBB0_175
LBB0_213:                               ; %cond.load3290
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d17
	ld1.s	{ v16 }[0], [x2]
	tbz	w1, #5, LBB0_176
LBB0_214:                               ; %cond.load3296
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v17[1]
	ld1.s	{ v16 }[1], [x2]
	tbz	w1, #6, LBB0_177
LBB0_215:                               ; %cond.load3302
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d5
	ld1.s	{ v16 }[2], [x2]
	tbnz	w1, #7, LBB0_178
	b	LBB0_179
LBB0_216:                               ; %schedule.8
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	mov	w1, #128                        ; =0x80
	dup.2d	v3, x1
	ldr	q0, [sp, #896]                  ; 16-byte Folded Reload
	cmgt.2d	v5, v3, v0
	ldr	q0, [sp, #1040]                 ; 16-byte Folded Reload
	cmgt.2d	v16, v3, v0
	uzp1.4s	v5, v16, v5
	cmgt.2d	v16, v3, v26
	ldr	q1, [sp, #832]                  ; 16-byte Folded Reload
	cmgt.2d	v17, v3, v1
	uzp1.4s	v16, v16, v17
	uzp1.8h	v5, v5, v16
	xtn.8b	v5, v5
	and.8b	v27, v24, v5
	shl.8b	v5, v27, #7
	cmlt.8b	v5, v5, #0
	and.8b	v16, v5, v2
	addv.8b	b16, v16
	fmov	w1, s16
	umaxv.8b	b5, v5
	fmov	w3, s5
	tbz	w3, #0, LBB0_222
; %bb.217:                              ; %schedule.8
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q0, [sp, #896]                  ; 16-byte Folded Reload
	cmge.2d	v5, v0, v3
	ldr	q0, [sp, #1040]                 ; 16-byte Folded Reload
	cmge.2d	v16, v0, v3
	uzp1.4s	v5, v16, v5
	cmge.2d	v16, v26, v3
	cmge.2d	v3, v1, v3
	uzp1.4s	v3, v16, v3
	uzp1.8h	v3, v5, v3
	xtn.8b	v3, v3
	and.8b	v28, v24, v3
	shl.8b	v3, v28, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_222
; %bb.218:                              ; %varying.divergent140
                                        ;   in Loop: Header=BB0_10 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #1792]
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	str	q0, [sp, #1808]
	and	x1, x1, #0x7
	add	x3, sp, #1792
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #3, #0, ne
	cset	w1, ne
	cmp	w2, #255
	b.ne	LBB0_220
; %bb.219:                              ; %varying.divergent140
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbz	w1, #0, LBB0_220
	b	LBB0_746
LBB0_220:                               ; %convergence.overflow.resume143
                                        ;   in Loop: Header=BB0_10 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #7, lsl #12             ; =28672
	add	x2, x2, #2800
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s3, w4
	ubfx	w4, w5, #1, #1
	mov.b	v3[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v3[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v3[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v3[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v3[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v3[6], w4
	add	x4, sp, #7, lsl #12             ; =28672
	add	x4, x4, #2792
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s5, w6
	ubfx	w6, w5, #1, #1
	mov.b	v5[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v5[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v5[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v5[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v5[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v5[6], w6
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v6, w5
	bit.8b	v3, v24, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x2, w3, uxtw]
	bic.8b	v3, v5, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_746
; %bb.221:                              ; %ready.overflow.resume145
                                        ;   in Loop: Header=BB0_10 Depth=3
	str	q25, [sp, #1760]
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	str	q0, [sp, #1776]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #1760
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q25, [sp, #1728]
	str	q0, [sp, #1744]
	add	x5, sp, #1728
	str	w4, [x5, x2]
	ldr	q0, [sp, #1744]
	str	q0, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q25, [sp, #1728]
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #1696]
	ldr	q1, [sp, #1104]                 ; 16-byte Folded Reload
	str	q1, [sp, #1712]
	add	x4, sp, #1696
	ldr	w4, [x4, x2]
	mov	w5, #3                          ; =0x3
	csel	w4, w5, w4, ne
	str	q0, [sp, #1664]
	str	q1, [sp, #1680]
	add	x5, sp, #1664
	str	w4, [x5, x2]
	mov	w2, #12                         ; =0xc
	mov	w4, #9                          ; =0x9
	ldr	q0, [sp, #1680]
	str	q0, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #1664]
	str	q0, [sp, #1088]                 ; 16-byte Folded Spill
                                        ; kill: def $w3 killed $w3 killed $x3 def $x3
	b	LBB0_9
LBB0_222:                               ; %varying.coherent141
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w1, #0xff
	b.eq	LBB0_260
; %bb.223:                              ; %varying.coherent.true146
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov	w1, #0                          ; =0x0
	tst	w2, #0xff
	b.eq	LBB0_5
LBB0_224:                               ; %schedule.9
                                        ;   in Loop: Header=BB0_10 Depth=3
	stp	q14, q25, [sp, #704]            ; 32-byte Folded Spill
	str	q31, [sp, #912]                 ; 16-byte Folded Spill
	stp	q8, q15, [sp, #768]             ; 32-byte Folded Spill
	str	q29, [sp, #864]                 ; 16-byte Folded Spill
	stp	q30, q26, [sp, #800]            ; 32-byte Folded Spill
	stp	q13, q22, [sp, #736]            ; 32-byte Folded Spill
	str	q9, [sp, #688]                  ; 16-byte Folded Spill
	mov.16b	v1, v19
	mov.16b	v19, v12
	str	q4, [sp, #608]                  ; 16-byte Folded Spill
	ldr	q0, [sp, #896]                  ; 16-byte Folded Reload
	mov.16b	v22, v1
	mov	b3, v24[6]
	mov.b	v3[4], v24[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v20, v3, #0
	ldr	q1, [sp, #832]                  ; 16-byte Folded Reload
	and.16b	v3, v20, v1
	mov	b5, v24[4]
	mov.b	v5[4], v24[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v25, v5, #0
	and.16b	v5, v25, v26
	mov	b16, v24[2]
	mov.b	v16[4], v24[3]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v26, v16, #0
	and.16b	v16, v26, v0
	mov	b17, v24[0]
	mov.b	v17[4], v24[1]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v28, v17, #0
	ldr	q0, [sp, #1040]                 ; 16-byte Folded Reload
	and.16b	v21, v28, v0
	shl.8b	v17, v24, #7
	cmlt.8b	v31, v17, #0
	and.8b	v17, v31, v2
	mov	w2, #32                         ; =0x20
	dup.2d	v29, x2
	and.16b	v27, v20, v29
	mvn.16b	v20, v20
	sub.2d	v27, v27, v20
	and.16b	v20, v25, v29
	mvn.16b	v25, v25
	sub.2d	v30, v20, v25
	and.16b	v20, v26, v29
	mvn.16b	v25, v26
	and.16b	v26, v28, v29
	mvn.16b	v28, v28
	sub.2d	v28, v26, v28
	mov.d	x2, v28[1]
	mov.d	x3, v21[1]
	sdiv	x6, x3, x2
	sub.2d	v20, v20, v25
	fmov	x3, d28
	fmov	x4, d21
	sdiv	x4, x4, x3
	mul	x7, x4, x3
	fmov	d25, x4
	mov.d	v25[1], x6
	mov.d	x3, v20[1]
	mov.d	x4, v16[1]
	sdiv	x19, x4, x3
	fmov	x4, d20
	fmov	x5, d16
	sdiv	x5, x5, x4
	mul	x20, x5, x4
	fmov	d26, x5
	mov.d	v26[1], x19
	mov.d	x4, v30[1]
	mov.d	x5, v5[1]
	sdiv	x21, x5, x4
	fmov	x5, d30
	fmov	x22, d5
	sdiv	x22, x22, x5
	mul	x23, x22, x5
	fmov	d8, x22
	mov.d	v8[1], x21
	mov.d	x5, v27[1]
	mov.d	x22, v3[1]
	fmov	x24, d27
	fmov	x25, d3
	sdiv	x25, x25, x24
	mul	x24, x25, x24
	fmov	d9, x25
	sdiv	x22, x22, x5
	mov.d	v9[1], x22
	mul	x6, x6, x2
	fmov	d10, x7
	mov.d	v10[1], x6
	mul	x6, x19, x3
	fmov	d11, x20
	mov.d	v11[1], x6
	mul	x6, x21, x4
	fmov	d12, x23
	mov.d	v12[1], x6
	mul	x6, x22, x5
	fmov	d15, x24
	mov.d	v15[1], x6
	addv.8b	b4, v17
	sub.2d	v3, v3, v15
	sub.2d	v5, v5, v12
	fmov	w6, s4
	sub.2d	v16, v16, v11
	sub.2d	v17, v21, v10
	shl.2d	v11, v9, #5
	shl.2d	v21, v8, #5
	shl.2d	v26, v26, #5
	shl.2d	v25, v25, #5
	add.2d	v10, v25, v17
	add.2d	v9, v26, v16
	add.2d	v21, v21, v5
	add.2d	v8, v11, v3
	ldr	q3, [sp, #6208]
	ldr	q5, [sp, #6224]
	ldr	q17, [sp, #6240]
	ldr	q16, [sp, #6256]
	ldr	q25, [sp, #6320]
	ldr	q26, [sp, #6304]
	ldr	q11, [sp, #6288]
	shl.2d	v12, v8, #5
	shl.2d	v15, v21, #5
	ldr	q18, [sp, #6272]
	shl.2d	v6, v9, #5
	shl.2d	v7, v10, #5
	add.2d	v16, v16, v25
	add.2d	v16, v16, v12
	add.2d	v17, v17, v26
	add.2d	v17, v17, v15
	add.2d	v5, v5, v11
	add.2d	v11, v5, v6
	add.2d	v3, v3, v18
	add.2d	v12, v3, v7
	movi.2d	v3, #0000000000000000
	movi.2d	v5, #0000000000000000
	stp	q1, q19, [sp, #832]             ; 32-byte Folded Spill
	str	q22, [sp, #592]                 ; 16-byte Folded Spill
	tbnz	w6, #0, LBB0_253
; %bb.225:                              ; %else2707
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w6, #1, LBB0_254
LBB0_226:                               ; %else2713
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w6, #2, LBB0_255
LBB0_227:                               ; %else2719
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q1, [sp, #976]                  ; 16-byte Folded Reload
	ldr	q13, [sp, #736]                 ; 16-byte Folded Reload
	ldr	q26, [sp, #928]                 ; 16-byte Folded Reload
	tbnz	w6, #3, LBB0_256
LBB0_228:                               ; %else2725
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w6, #4, LBB0_257
LBB0_229:                               ; %else2731
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w6, #5, LBB0_258
LBB0_230:                               ; %else2737
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w6, #6, LBB0_259
LBB0_231:                               ; %else2743
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbz	w6, #7, LBB0_233
LBB0_232:                               ; %cond.load2745
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x6, v16[1]
	ld1.s	{ v5 }[3], [x6]
LBB0_233:                               ; %else2749
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q6, [sp, #6000]
	ldr	q7, [sp, #5984]
	zip1.8b	v16, v24, v0
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	bif.16b	v3, v7, v16
	zip2.8b	v7, v24, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	bif.16b	v5, v6, v7
	str	q5, [sp, #6000]
	str	q3, [sp, #5984]
	mov	b3, v24[2]
	mov.b	v3[4], v24[3]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	and.16b	v5, v3, v9
	mov	b6, v24[0]
	mov.b	v6[4], v24[1]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v9, v6, #0
	mov	b6, v24[6]
	mov.b	v6[4], v24[7]
	and.16b	v11, v9, v10
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v10, v6, #0
	and.16b	v16, v10, v8
	mov	b6, v24[4]
	mov.b	v6[4], v24[5]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v8, v6, #0
	and.16b	v12, v8, v21
	mov.d	x6, v12[1]
	sdiv	x6, x6, x4
	fmov	x7, d12
	fmov	x19, d30
	sdiv	x7, x7, x19
	mul	x19, x7, x19
	fmov	d17, x7
	mov.d	v17[1], x6
	mov.d	x7, v16[1]
	sdiv	x7, x7, x5
	fmov	x20, d16
	fmov	x21, d27
	sdiv	x20, x20, x21
	mul	x21, x20, x21
	fmov	d21, x20
	mov.d	v21[1], x7
	mov.d	x20, v11[1]
	sdiv	x20, x20, x2
	fmov	x22, d11
	fmov	x23, d28
	sdiv	x22, x22, x23
	mul	x23, x22, x23
	fmov	d27, x22
	mov.d	v27[1], x20
	mov.d	x22, v5[1]
	fmov	x24, d5
	fmov	x25, d20
	sdiv	x24, x24, x25
	mul	x25, x24, x25
	fmov	d20, x24
	sdiv	x22, x22, x3
	mov.d	v20[1], x22
	mul	x5, x7, x5
	fmov	d6, x21
	mov.d	v6[1], x5
	mul	x4, x6, x4
	fmov	d7, x19
	mov.d	v7[1], x4
	mul	x3, x22, x3
	fmov	d18, x25
	mov.d	v18[1], x3
	mul	x2, x20, x2
	fmov	d25, x23
	mov.d	v25[1], x2
	mvn.16b	v25, v25
	add.2d	v28, v25, v11
	mvn.16b	v18, v18
	add.2d	v5, v18, v5
	mvn.16b	v7, v7
	add.2d	v7, v7, v12
	mvn.16b	v6, v6
	mov	w2, #32                         ; =0x20
	dup.2d	v18, x2
	add.2d	v6, v6, v16
	cmhi.2d	v16, v18, v6
	cmhi.2d	v25, v18, v7
	uzp1.4s	v16, v25, v16
	cmhi.2d	v25, v18, v5
	cmhi.2d	v18, v18, v28
	uzp1.4s	v18, v18, v25
	uzp1.8h	v16, v18, v16
	xtn.8b	v16, v16
	ldrb	w2, [x9, #768]
	and	w3, w2, #0x1
	fmov	s18, w3
	ubfx	w3, w2, #1, #1
	mov.b	v18[1], w3
	ubfx	w3, w2, #2, #1
	mov.b	v18[2], w3
	ubfx	w3, w2, #3, #1
	mov.b	v18[3], w3
	ubfx	w3, w2, #4, #1
	mov.b	v18[4], w3
	ubfx	w3, w2, #5, #1
	mov.b	v18[5], w3
	ubfx	w3, w2, #6, #1
	mov.b	v18[6], w3
	lsr	w2, w2, #7
	mov.b	v18[7], w2
	bif.8b	v16, v18, v31
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v2
	addv.8b	b16, v16
	str	b16, [x9, #768]
	shl.2d	v18, v20, #5
	shl.2d	v16, v27, #5
	shl.2d	v19, v21, #5
	shl.2d	v17, v17, #5
	add.2d	v17, v17, v7
	add.2d	v19, v19, v6
	add.2d	v16, v16, v28
	add.2d	v5, v18, v5
	ldr	q6, [sp, #5920]
	ldr	q7, [sp, #5936]
	ldr	q18, [sp, #5888]
	ldr	q20, [sp, #5904]
	bsl.16b	v3, v5, v20
	bit.16b	v18, v16, v9
	bit.16b	v7, v19, v10
	bit.16b	v6, v17, v8
	str	q6, [sp, #5920]
	str	q7, [sp, #5936]
	str	q18, [sp, #5888]
	str	q3, [sp, #5904]
	mov	w2, #128                        ; =0x80
	dup.2d	v3, x2
	cmhi.2d	v6, v3, v19
	cmhi.2d	v7, v3, v17
	uzp1.4s	v6, v7, v6
	cmhi.2d	v7, v3, v5
	cmhi.2d	v18, v3, v16
	uzp1.4s	v7, v18, v7
	uzp1.8h	v6, v7, v6
	xtn.8b	v6, v6
	and.8b	v27, v24, v6
	shl.8b	v6, v27, #7
	cmlt.8b	v6, v6, #0
	and.8b	v7, v6, v2
	addv.8b	b7, v7
	fmov	w2, s7
	umaxv.8b	b6, v6
	fmov	w3, s6
	str	q26, [sp, #928]                 ; 16-byte Folded Spill
	str	q1, [sp, #976]                  ; 16-byte Folded Spill
	tbz	w3, #0, LBB0_239
; %bb.234:                              ; %else2749
                                        ;   in Loop: Header=BB0_10 Depth=3
	cmhs.2d	v6, v19, v3
	cmhs.2d	v7, v17, v3
	uzp1.4s	v6, v7, v6
	cmhs.2d	v5, v5, v3
	cmhs.2d	v3, v16, v3
	uzp1.4s	v3, v3, v5
	uzp1.8h	v3, v3, v6
	xtn.8b	v3, v3
	and.8b	v28, v24, v3
	shl.8b	v3, v28, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_239
; %bb.235:                              ; %varying.divergent151
                                        ;   in Loop: Header=BB0_10 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	ldr	q16, [sp, #1088]                ; 16-byte Folded Reload
	str	q16, [sp, #1952]
	ldr	q7, [sp, #1104]                 ; 16-byte Folded Reload
	str	q7, [sp, #1968]
	and	x1, x1, #0x7
	add	x3, sp, #1952
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #4, #0, ne
	cset	w1, ne
	cmp	w2, #255
	ldr	q8, [sp, #608]                  ; 16-byte Folded Reload
	ldr	q15, [sp, #1008]                ; 16-byte Folded Reload
	ldp	q20, q17, [sp, #752]            ; 32-byte Folded Reload
	ldr	q19, [sp, #704]                 ; 16-byte Folded Reload
	ldr	q30, [sp, #800]                 ; 16-byte Folded Reload
	b.ne	LBB0_237
; %bb.236:                              ; %varying.divergent151
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbz	w1, #0, LBB0_237
	b	LBB0_746
LBB0_237:                               ; %convergence.overflow.resume154
                                        ;   in Loop: Header=BB0_10 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #7, lsl #12             ; =28672
	add	x2, x2, #2800
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s3, w4
	ubfx	w4, w5, #1, #1
	mov.b	v3[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v3[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v3[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v3[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v3[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v3[6], w4
	add	x4, sp, #7, lsl #12             ; =28672
	add	x4, x4, #2792
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s5, w6
	ubfx	w6, w5, #1, #1
	mov.b	v5[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v5[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v5[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v5[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v5[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v5[6], w6
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v6, w5
	bit.8b	v3, v24, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x2, w3, uxtw]
	bic.8b	v3, v5, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	ldr	q9, [sp, #992]                  ; 16-byte Folded Reload
	ldr	q21, [sp, #784]                 ; 16-byte Folded Reload
	ldr	q24, [sp, #1040]                ; 16-byte Folded Reload
	ldr	q29, [sp, #864]                 ; 16-byte Folded Reload
	ldr	q31, [sp, #912]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	ldr	q4, [sp, #720]                  ; 16-byte Folded Reload
	b.hs	LBB0_746
; %bb.238:                              ; %ready.overflow.resume156
                                        ;   in Loop: Header=BB0_10 Depth=3
	zip2.8b	v3, v28, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldp	q6, q5, [sp, #272]              ; 32-byte Folded Reload
	and.16b	v1, v3, v6
	zip1.8b	v3, v28, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v5, v3, v5
	stp	q1, q5, [sp, #272]              ; 32-byte Folded Spill
	str	q4, [sp, #1920]
	str	q0, [sp, #1936]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #1920
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q4, [sp, #1888]
	str	q0, [sp, #1904]
	add	x5, sp, #1888
	str	w4, [x5, x2]
	ldr	q0, [sp, #1904]
	str	q0, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q25, [sp, #1888]
	str	q16, [sp, #1856]
	str	q7, [sp, #1872]
	add	x4, sp, #1856
	ldr	w4, [x4, x2]
	mov	w5, #4                          ; =0x4
	csel	w4, w5, w4, ne
	str	q16, [sp, #1824]
	str	q7, [sp, #1840]
	add	x5, sp, #1824
	str	w4, [x5, x2]
	mov	w2, #11                         ; =0xb
	mov	w4, #10                         ; =0xa
	ldr	q0, [sp, #1840]
	str	q0, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #1824]
	str	q0, [sp, #1088]                 ; 16-byte Folded Spill
                                        ; kill: def $w3 killed $w3 killed $x3 def $x3
	ldr	q26, [sp, #816]                 ; 16-byte Folded Reload
	ldr	q12, [sp, #848]                 ; 16-byte Folded Reload
	ldr	q1, [sp, #688]                  ; 16-byte Folded Reload
	stp	q9, q15, [sp, #992]             ; 32-byte Folded Spill
	mov.16b	v15, v21
	str	q24, [sp, #1040]                ; 16-byte Folded Spill
	mov.16b	v4, v8
	mov.16b	v8, v17
	mov.16b	v14, v19
	mov.16b	v19, v22
	mov.16b	v9, v1
	mov.16b	v22, v20
	b	LBB0_9
LBB0_239:                               ; %varying.coherent152
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	ldr	q9, [sp, #704]                  ; 16-byte Folded Reload
	ldr	q28, [sp, #768]                 ; 16-byte Folded Reload
	b.eq	LBB0_269
; %bb.240:                              ; %varying.coherent.true157
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q14, [sp, #992]                 ; 16-byte Folded Reload
	ldr	q15, [sp, #784]                 ; 16-byte Folded Reload
	ldr	q30, [sp, #864]                 ; 16-byte Folded Reload
	ldp	q29, q31, [sp, #896]            ; 32-byte Folded Reload
	ldr	q23, [sp, #1072]                ; 16-byte Folded Reload
	str	q14, [sp, #992]                 ; 16-byte Folded Spill
	str	q23, [sp, #1072]                ; 16-byte Folded Spill
	str	q29, [sp, #896]                 ; 16-byte Folded Spill
	tbnz	w1, #0, LBB0_726
; %bb.241:                              ; %schedule.10.thread
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q3, [sp, #6208]
	ldr	q5, [sp, #6224]
	ldr	q6, [sp, #6240]
	ldr	q7, [sp, #6256]
	ldr	q16, [sp, #6320]
	ldr	q17, [sp, #6304]
	ldr	q18, [sp, #6288]
	ldr	q20, [sp, #6272]
	ldr	q19, [sp, #5888]
	ldr	q21, [sp, #5904]
	ldr	q25, [sp, #5920]
	ldr	q26, [sp, #5936]
	shl.2d	v26, v26, #5
	shl.2d	v25, v25, #5
	shl.2d	v21, v21, #5
	shl.2d	v27, v19, #5
	add.2d	v7, v7, v16
	add.2d	v1, v7, v26
	str	q1, [sp, #80]                   ; 16-byte Folded Spill
	add.2d	v6, v6, v17
	add.2d	v10, v6, v25
	add.2d	v5, v5, v18
	add.2d	v19, v5, v21
	add.2d	v3, v3, v20
	add.2d	v20, v3, v27
	fmov	w1, s4
	movi.2d	v3, #0000000000000000
	movi.2d	v5, #0000000000000000
	ldr	q26, [sp, #816]                 ; 16-byte Folded Reload
	ldr	q7, [sp, #1024]                 ; 16-byte Folded Reload
	ldr	q25, [sp, #720]                 ; 16-byte Folded Reload
	ldr	q1, [sp, #944]                  ; 16-byte Folded Reload
	ldr	q21, [sp, #880]                 ; 16-byte Folded Reload
	tbnz	w1, #0, LBB0_294
; %bb.242:                              ; %else3352
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q6, [sp, #848]                  ; 16-byte Folded Reload
	ldr	q27, [sp, #1008]                ; 16-byte Folded Reload
	mov.16b	v16, v9
	tbnz	w1, #1, LBB0_295
LBB0_243:                               ; %else3358
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q17, [sp, #960]                 ; 16-byte Folded Reload
	ldr	q18, [sp, #688]                 ; 16-byte Folded Reload
	ldr	q8, [sp, #592]                  ; 16-byte Folded Reload
	mov.16b	v9, v26
	ldr	q0, [sp, #800]                  ; 16-byte Folded Reload
	tbz	w1, #2, LBB0_245
LBB0_244:                               ; %cond.load3360
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d19
	ld1.s	{ v3 }[2], [x2]
LBB0_245:                               ; %else3364
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v20, v30
	mov.16b	v30, v8
	ldr	q22, [sp, #752]                 ; 16-byte Folded Reload
	ldr	q14, [sp, #1040]                ; 16-byte Folded Reload
	str	q1, [sp, #944]                  ; 16-byte Folded Spill
	stp	q27, q7, [sp, #1008]            ; 32-byte Folded Spill
	tbz	w1, #3, LBB0_247
; %bb.246:                              ; %cond.load3366
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v19[1]
	ld1.s	{ v3 }[3], [x2]
LBB0_247:                               ; %else3370
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q4, [sp, #608]                  ; 16-byte Folded Reload
	mov.16b	v8, v28
	mov.16b	v12, v6
	mov.16b	v29, v20
	mov.16b	v19, v30
	str	q14, [sp, #1040]                ; 16-byte Folded Spill
	tbnz	w1, #4, LBB0_296
; %bb.248:                              ; %else3376
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v30, v0
	mov.16b	v26, v9
	tbnz	w1, #5, LBB0_297
LBB0_249:                               ; %else3382
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v14, v16
	mov.16b	v9, v18
	str	q17, [sp, #960]                 ; 16-byte Folded Spill
	tbnz	w1, #6, LBB0_298
LBB0_250:                               ; %else3388
                                        ;   in Loop: Header=BB0_10 Depth=3
	str	q21, [sp, #880]                 ; 16-byte Folded Spill
	tbz	w1, #7, LBB0_252
LBB0_251:                               ; %cond.load3390
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q0, [sp, #80]                   ; 16-byte Folded Reload
	mov.d	x1, v0[1]
	ld1.s	{ v5 }[3], [x1]
LBB0_252:                               ; %else3394
                                        ;   in Loop: Header=BB0_10 Depth=3
	zip2.8b	v6, v24, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	ldr	q7, [sp, #272]                  ; 16-byte Folded Reload
	bit.16b	v7, v5, v6
	zip1.8b	v5, v24, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q6, [sp, #288]                  ; 16-byte Folded Reload
	bit.16b	v6, v3, v5
	stp	q7, q6, [sp, #272]              ; 32-byte Folded Spill
	b	LBB0_270
LBB0_253:                               ; %cond.load2703
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x7, d12
	ldr	s3, [x7]
	tbz	w6, #1, LBB0_226
LBB0_254:                               ; %cond.load2709
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x7, v12[1]
	ld1.s	{ v3 }[1], [x7]
	tbz	w6, #2, LBB0_227
LBB0_255:                               ; %cond.load2715
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x7, d11
	ld1.s	{ v3 }[2], [x7]
	ldr	q1, [sp, #976]                  ; 16-byte Folded Reload
	ldr	q13, [sp, #736]                 ; 16-byte Folded Reload
	ldr	q26, [sp, #928]                 ; 16-byte Folded Reload
	tbz	w6, #3, LBB0_228
LBB0_256:                               ; %cond.load2721
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x7, v11[1]
	ld1.s	{ v3 }[3], [x7]
	tbz	w6, #4, LBB0_229
LBB0_257:                               ; %cond.load2727
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x7, d17
	ld1.s	{ v5 }[0], [x7]
	tbz	w6, #5, LBB0_230
LBB0_258:                               ; %cond.load2733
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x7, v17[1]
	ld1.s	{ v5 }[1], [x7]
	tbz	w6, #6, LBB0_231
LBB0_259:                               ; %cond.load2739
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x7, d16
	ld1.s	{ v5 }[2], [x7]
	tbnz	w6, #7, LBB0_232
	b	LBB0_233
LBB0_260:                               ; %varying.coherent.false147
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_5
LBB0_261:                               ; %schedule.12
                                        ;   in Loop: Header=BB0_10 Depth=3
	cbz	w0, LBB0_266
; %bb.262:                              ; %convergence.cascade187.preheader
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov	w1, #0                          ; =0x0
LBB0_263:                               ; %convergence.cascade187
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_10 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v5, v3, v2
	addv.8b	b5, v5
	fmov	w2, s5
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #4384]
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	str	q0, [sp, #4400]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #1, lsl #12             ; =4096
	add	x6, x6, #288
	ldr	w6, [x6, x2]
	cmp	w6, #3
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #7, lsl #12             ; =28672
	add	x5, x5, #2800
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s3, w19
	ubfx	w19, w20, #1, #1
	mov.b	v3[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v3[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v3[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v3[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v3[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v3[6], w19
	add	x19, sp, #7, lsl #12            ; =28672
	add	x19, x19, #2792
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s5, w21
	ubfx	w21, w20, #1, #1
	mov.b	v5[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v5[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v5[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v5[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v5[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v5[6], w21
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	orr.8b	v6, v24, v5
	ldr	d0, [sp, #1064]                 ; 8-byte Folded Reload
	and.8b	v7, v0, v3
	eor.8b	v7, v7, v6
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v6, v7
	dup.8b	v17, w7
	bit.8b	v5, v16, v17
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x19, w3, sxtw]
	bic.8b	v3, v3, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v5, v5, v6
	str	q25, [sp, #4352]
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	str	q0, [sp, #4368]
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #256
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v24, v5, v3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_267
; %bb.264:                              ; %convergence.cascade187
                                        ;   in Loop: Header=BB0_263 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_267
; %bb.265:                              ; %convergence.cascade187
                                        ;   in Loop: Header=BB0_263 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_263
	b	LBB0_267
LBB0_266:                               ; %schedule.12.convergence.cascade.exit188_crit_edge
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_267:                               ; %convergence.cascade.exit188
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_5
; %bb.268:                              ; %convergence.target.12.ready
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q17, [sp, #5856]
	ldr	q5, [sp, #5872]
	ldr	q3, [sp, #5824]
	ldr	q6, [sp, #5840]
	ldr	q16, [sp, #5792]
	ldr	q7, [sp, #5808]
	ldr	q18, [sp, #5760]
	ldr	q20, [sp, #5776]
	mov.16b	v11, v8
	mov.16b	v8, v29
	mov.16b	v29, v4
	mov.16b	v4, v31
	mov.16b	v31, v15
	mov.16b	v15, v12
	mov.16b	v12, v14
	mov.16b	v14, v13
	mov.16b	v13, v9
	mov.16b	v9, v30
	mov.16b	v30, v19
	mov	b19, v24[2]
	mov.b	v19[4], v24[3]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	ldr	q28, [sp, #176]                 ; 16-byte Folded Reload
	bit.16b	v20, v28, v19
	mov	b21, v24[0]
	mov.b	v21[4], v24[1]
	ushll.2d	v21, v21, #0
	shl.2d	v21, v21, #63
	cmlt.2d	v21, v21, #0
	mov.16b	v0, v25
	mov	b25, v24[6]
	mov.b	v25[4], v24[7]
	bit.16b	v18, v28, v21
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	bit.16b	v7, v28, v25
	mov.16b	v1, v26
	mov	b26, v24[4]
	mov.b	v26[4], v24[5]
	ushll.2d	v26, v26, #0
	shl.2d	v26, v26, #63
	cmlt.2d	v26, v26, #0
Lloh50:
	adrp	x1, lCPI0_17@PAGE
Lloh51:
	ldr	q27, [x1, lCPI0_17@PAGEOFF]
	bit.16b	v6, v27, v19
Lloh52:
	adrp	x1, lCPI0_18@PAGE
Lloh53:
	ldr	q27, [x1, lCPI0_18@PAGEOFF]
	bit.16b	v17, v27, v26
Lloh54:
	adrp	x1, lCPI0_16@PAGE
Lloh55:
	ldr	q27, [x1, lCPI0_16@PAGEOFF]
	str	q17, [sp, #5856]
Lloh56:
	adrp	x1, lCPI0_19@PAGE
Lloh57:
	ldr	q17, [x1, lCPI0_19@PAGEOFF]
	bit.16b	v16, v28, v26
	bit.16b	v5, v17, v25
	str	q5, [sp, #5872]
	bit.16b	v3, v27, v21
	str	q3, [sp, #5824]
	str	q6, [sp, #5840]
	str	q16, [sp, #5792]
	str	q7, [sp, #5808]
	str	q18, [sp, #5760]
	str	q20, [sp, #5776]
	bic.16b	v9, v9, v25
	mov.16b	v25, v0
	ldr	q0, [sp, #944]                  ; 16-byte Folded Reload
	bic.16b	v0, v0, v26
	str	q0, [sp, #944]                  ; 16-byte Folded Spill
	mov.16b	v26, v1
	bic.16b	v31, v31, v19
	mov.16b	v19, v30
	mov.16b	v30, v9
	mov.16b	v9, v13
	mov.16b	v13, v14
	mov.16b	v14, v12
	mov.16b	v12, v15
	mov.16b	v15, v31
	mov.16b	v31, v4
	mov.16b	v4, v29
	mov.16b	v29, v8
	mov.16b	v8, v11
	ldr	q0, [sp, #992]                  ; 16-byte Folded Reload
	bic.16b	v0, v0, v21
	str	q0, [sp, #992]                  ; 16-byte Folded Spill
	b	LBB0_299
LBB0_269:                               ; %varying.coherent.false158
                                        ;   in Loop: Header=BB0_10 Depth=3
	zip2.8b	v3, v24, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldp	q4, q5, [sp, #272]              ; 32-byte Folded Reload
	and.16b	v1, v3, v4
	zip1.8b	v3, v24, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v5, v3, v5
	stp	q1, q5, [sp, #272]              ; 32-byte Folded Spill
	ldp	q15, q30, [sp, #784]            ; 32-byte Folded Reload
	ldr	q26, [sp, #816]                 ; 16-byte Folded Reload
	ldp	q12, q29, [sp, #848]            ; 32-byte Folded Reload
	ldr	q31, [sp, #912]                 ; 16-byte Folded Reload
	ldr	q25, [sp, #720]                 ; 16-byte Folded Reload
	ldr	q17, [sp, #688]                 ; 16-byte Folded Reload
	mov.16b	v8, v28
	mov.16b	v3, v9
	mov.16b	v9, v17
	mov.16b	v14, v3
	ldp	q19, q4, [sp, #592]             ; 32-byte Folded Reload
	ldr	q22, [sp, #752]                 ; 16-byte Folded Reload
	tbnz	w1, #0, LBB0_5
LBB0_270:                               ; %schedule.11
                                        ;   in Loop: Header=BB0_10 Depth=3
	str	q8, [sp, #768]                  ; 16-byte Folded Spill
	mov.16b	v8, v29
	mov.16b	v29, v4
	mov.16b	v4, v31
	mov.16b	v31, v15
	mov.16b	v15, v12
	mov.16b	v12, v14
	mov.16b	v14, v13
	mov.16b	v13, v9
	mov.16b	v9, v30
	cbz	w0, LBB0_275
; %bb.271:                              ; %convergence.cascade161.preheader
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v30, v19
	mov	w1, #0                          ; =0x0
LBB0_272:                               ; %convergence.cascade161
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_10 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v5, v3, v2
	addv.8b	b5, v5
	fmov	w2, s5
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #2016]
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	str	q0, [sp, #2032]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #2016
	ldr	w6, [x6, x2]
	cmp	w6, #4
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #7, lsl #12             ; =28672
	add	x5, x5, #2800
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s3, w19
	ubfx	w19, w20, #1, #1
	mov.b	v3[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v3[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v3[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v3[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v3[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v3[6], w19
	add	x19, sp, #7, lsl #12            ; =28672
	add	x19, x19, #2792
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s5, w21
	ubfx	w21, w20, #1, #1
	mov.b	v5[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v5[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v5[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v5[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v5[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v5[6], w21
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	orr.8b	v6, v24, v5
	ldr	d0, [sp, #1064]                 ; 8-byte Folded Reload
	and.8b	v7, v0, v3
	eor.8b	v7, v7, v6
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v6, v7
	dup.8b	v17, w7
	bit.8b	v5, v16, v17
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x19, w3, sxtw]
	bic.8b	v3, v3, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v5, v5, v6
	str	q25, [sp, #1984]
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	str	q0, [sp, #2000]
	add	x3, sp, #1984
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v24, v5, v3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_276
; %bb.273:                              ; %convergence.cascade161
                                        ;   in Loop: Header=BB0_272 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_276
; %bb.274:                              ; %convergence.cascade161
                                        ;   in Loop: Header=BB0_272 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_272
	b	LBB0_276
LBB0_275:                               ; %schedule.11.convergence.cascade.exit162_crit_edge
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v30, v19
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_276:                               ; %convergence.cascade.exit162
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_715
; %bb.277:                              ; %convergence.target.11.ready
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v0, v25
	ldrb	w1, [x9, #768]
	lsr	w2, w1, #7
	ubfx	w3, w1, #6, #1
	ubfx	w4, w1, #5, #1
	ubfx	w5, w1, #4, #1
	ubfx	w6, w1, #3, #1
	ubfx	w7, w1, #2, #1
	ubfx	w19, w1, #1, #1
	and	w1, w1, #0x1
	fmov	s3, w1
	mov.h	v3[1], w19
	mov.h	v3[2], w7
	mov.h	v3[3], w6
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	fmov	s5, w5
	mov.h	v5[1], w4
	mov.h	v5[2], w3
	ldr	q6, [sp, #288]                  ; 16-byte Folded Reload
	and.16b	v6, v3, v6
	mov.h	v5[3], w2
	ushll.4s	v3, v5, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q5, [sp, #272]                  ; 16-byte Folded Reload
	and.16b	v3, v3, v5
	ldr	q5, [sp, #5984]
	ldr	q7, [sp, #6000]
	fadd.4s	v3, v7, v3
	fadd.4s	v16, v5, v6
	ldr	q5, [sp, #6064]
	ldr	q6, [sp, #6048]
	ldr	q7, [sp, #6016]
	ldr	q17, [sp, #6032]
	ldr	q18, [sp, #6096]
	ldr	q19, [sp, #6080]
	ldr	q20, [sp, #6112]
	ldr	q21, [sp, #6128]
	ldr	q1, [sp, #896]                  ; 16-byte Folded Reload
	shl.2d	v25, v1, #5
	mov.16b	v27, v26
	ldr	q1, [sp, #1040]                 ; 16-byte Folded Reload
	shl.2d	v26, v1, #5
	mov.16b	v1, v27
	shl.2d	v27, v27, #5
	ldr	q28, [sp, #832]                 ; 16-byte Folded Reload
	shl.2d	v28, v28, #5
	add.2d	v21, v21, v28
	add.2d	v27, v20, v27
	add.2d	v20, v19, v26
	add.2d	v18, v18, v25
	add.2d	v19, v17, v18
	add.2d	v20, v7, v20
	add.2d	v17, v6, v27
	add.2d	v5, v5, v21
	shl.8b	v6, v24, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	fmov	w1, s6
	tbnz	w1, #0, LBB0_287
; %bb.278:                              ; %else3400
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #1, LBB0_288
LBB0_279:                               ; %else3404
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v25, v0
	mov.16b	v26, v1
	tbnz	w1, #2, LBB0_289
LBB0_280:                               ; %else3408
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #3, LBB0_290
LBB0_281:                               ; %else3412
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #4, LBB0_291
LBB0_282:                               ; %else3416
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v19, v30
	tbnz	w1, #5, LBB0_292
LBB0_283:                               ; %else3420
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v30, v9
	tbnz	w1, #6, LBB0_293
LBB0_284:                               ; %else3424
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v9, v13
	tbz	w1, #7, LBB0_286
LBB0_285:                               ; %cond.store3425
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x1, v5[1]
	st1.s	{ v3 }[3], [x1]
LBB0_286:                               ; %else3428
                                        ;   in Loop: Header=BB0_10 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v24, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v5, v3, #0
	ushll2.4s	v3, v3, #0
	ldr	q0, [sp, #832]                  ; 16-byte Folded Reload
	uaddw2.2d	v0, v0, v3
	str	q0, [sp, #832]                  ; 16-byte Folded Spill
	uaddw.2d	v26, v26, v3
	ldr	q0, [sp, #896]                  ; 16-byte Folded Reload
	uaddw2.2d	v0, v0, v5
	str	q0, [sp, #896]                  ; 16-byte Folded Spill
	ldr	q0, [sp, #1040]                 ; 16-byte Folded Reload
	uaddw.2d	v0, v0, v5
	str	q0, [sp, #1040]                 ; 16-byte Folded Spill
	mov.16b	v13, v14
	mov.16b	v14, v12
	mov.16b	v12, v15
	mov.16b	v15, v31
	mov.16b	v31, v4
	mov.16b	v4, v29
	mov.16b	v29, v8
	ldr	q8, [sp, #768]                  ; 16-byte Folded Reload
	b	LBB0_216
LBB0_287:                               ; %cond.store3397
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d20
	str	s16, [x2]
	tbz	w1, #1, LBB0_279
LBB0_288:                               ; %cond.store3401
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v20[1]
	st1.s	{ v16 }[1], [x2]
	mov.16b	v25, v0
	mov.16b	v26, v1
	tbz	w1, #2, LBB0_280
LBB0_289:                               ; %cond.store3405
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d19
	st1.s	{ v16 }[2], [x2]
	tbz	w1, #3, LBB0_281
LBB0_290:                               ; %cond.store3409
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v19[1]
	st1.s	{ v16 }[3], [x2]
	tbz	w1, #4, LBB0_282
LBB0_291:                               ; %cond.store3413
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d17
	str	s3, [x2]
	mov.16b	v19, v30
	tbz	w1, #5, LBB0_283
LBB0_292:                               ; %cond.store3417
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v17[1]
	st1.s	{ v3 }[1], [x2]
	mov.16b	v30, v9
	tbz	w1, #6, LBB0_284
LBB0_293:                               ; %cond.store3421
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d5
	st1.s	{ v3 }[2], [x2]
	mov.16b	v9, v13
	tbnz	w1, #7, LBB0_285
	b	LBB0_286
LBB0_294:                               ; %cond.load3348
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d20
	ldr	s3, [x2]
	ldr	q6, [sp, #848]                  ; 16-byte Folded Reload
	ldr	q27, [sp, #1008]                ; 16-byte Folded Reload
	mov.16b	v16, v9
	tbz	w1, #1, LBB0_243
LBB0_295:                               ; %cond.load3354
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v20[1]
	ld1.s	{ v3 }[1], [x2]
	ldr	q17, [sp, #960]                 ; 16-byte Folded Reload
	ldr	q18, [sp, #688]                 ; 16-byte Folded Reload
	ldr	q8, [sp, #592]                  ; 16-byte Folded Reload
	mov.16b	v9, v26
	ldr	q0, [sp, #800]                  ; 16-byte Folded Reload
	tbnz	w1, #2, LBB0_244
	b	LBB0_245
LBB0_296:                               ; %cond.load3372
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d10
	ld1.s	{ v5 }[0], [x2]
	mov.16b	v30, v0
	mov.16b	v26, v9
	tbz	w1, #5, LBB0_249
LBB0_297:                               ; %cond.load3378
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v10[1]
	ld1.s	{ v5 }[1], [x2]
	mov.16b	v14, v16
	mov.16b	v9, v18
	str	q17, [sp, #960]                 ; 16-byte Folded Spill
	tbz	w1, #6, LBB0_250
LBB0_298:                               ; %cond.load3384
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q0, [sp, #80]                   ; 16-byte Folded Reload
	fmov	x2, d0
	ld1.s	{ v5 }[2], [x2]
	str	q21, [sp, #880]                 ; 16-byte Folded Spill
	tbnz	w1, #7, LBB0_251
	b	LBB0_252
LBB0_299:                               ; %schedule.13
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	mov	w1, #128                        ; =0x80
	dup.2d	v3, x1
	cmgt.2d	v5, v3, v15
	ldr	q0, [sp, #992]                  ; 16-byte Folded Reload
	cmgt.2d	v6, v3, v0
	uzp1.4s	v5, v6, v5
	ldr	q1, [sp, #944]                  ; 16-byte Folded Reload
	cmgt.2d	v6, v3, v1
	cmgt.2d	v7, v3, v30
	uzp1.4s	v6, v6, v7
	uzp1.8h	v5, v5, v6
	xtn.8b	v5, v5
	and.8b	v27, v24, v5
	shl.8b	v5, v27, #7
	cmlt.8b	v5, v5, #0
	and.8b	v6, v5, v2
	addv.8b	b6, v6
	fmov	w1, s6
	umaxv.8b	b5, v5
	fmov	w3, s5
	tbz	w3, #0, LBB0_305
; %bb.300:                              ; %schedule.13
                                        ;   in Loop: Header=BB0_10 Depth=3
	cmge.2d	v5, v15, v3
	cmge.2d	v6, v0, v3
	uzp1.4s	v5, v6, v5
	ldr	q0, [sp, #944]                  ; 16-byte Folded Reload
	cmge.2d	v6, v0, v3
	cmge.2d	v3, v30, v3
	uzp1.4s	v3, v6, v3
	uzp1.8h	v3, v5, v3
	xtn.8b	v3, v3
	and.8b	v28, v24, v3
	shl.8b	v3, v28, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_305
; %bb.301:                              ; %varying.divergent205
                                        ;   in Loop: Header=BB0_10 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #2176]
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	str	q0, [sp, #2192]
	and	x1, x1, #0x7
	add	x3, sp, #2176
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #5, #0, ne
	cset	w1, ne
	cmp	w2, #255
	b.ne	LBB0_303
; %bb.302:                              ; %varying.divergent205
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #0, LBB0_746
LBB0_303:                               ; %convergence.overflow.resume208
                                        ;   in Loop: Header=BB0_10 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #7, lsl #12             ; =28672
	add	x2, x2, #2800
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s3, w4
	ubfx	w4, w5, #1, #1
	mov.b	v3[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v3[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v3[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v3[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v3[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v3[6], w4
	add	x4, sp, #7, lsl #12             ; =28672
	add	x4, x4, #2792
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s5, w6
	ubfx	w6, w5, #1, #1
	mov.b	v5[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v5[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v5[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v5[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v5[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v5[6], w6
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v6, w5
	bit.8b	v3, v24, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x2, w3, uxtw]
	bic.8b	v3, v5, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_746
; %bb.304:                              ; %ready.overflow.resume210
                                        ;   in Loop: Header=BB0_10 Depth=3
	str	q25, [sp, #2144]
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	str	q0, [sp, #2160]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #2144
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q25, [sp, #2112]
	str	q0, [sp, #2128]
	add	x5, sp, #2112
	str	w4, [x5, x2]
	ldr	q0, [sp, #2128]
	str	q0, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q25, [sp, #2112]
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #2080]
	ldr	q1, [sp, #1104]                 ; 16-byte Folded Reload
	str	q1, [sp, #2096]
	add	x4, sp, #2080
	ldr	w4, [x4, x2]
	mov	w5, #5                          ; =0x5
	csel	w4, w5, w4, ne
	str	q0, [sp, #2048]
	str	q1, [sp, #2064]
	add	x5, sp, #2048
	str	w4, [x5, x2]
	mov	w2, #17                         ; =0x11
	mov	w4, #14                         ; =0xe
	ldr	q0, [sp, #2064]
	str	q0, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #2048]
	str	q0, [sp, #1088]                 ; 16-byte Folded Spill
                                        ; kill: def $w3 killed $w3 killed $x3 def $x3
	b	LBB0_9
LBB0_305:                               ; %varying.coherent206
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w1, #0xff
	b.eq	LBB0_342
; %bb.306:                              ; %varying.coherent.true211
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov	w1, #0                          ; =0x0
	tst	w2, #0xff
	b.eq	LBB0_5
LBB0_307:                               ; %schedule.14
                                        ;   in Loop: Header=BB0_10 Depth=3
	stp	q14, q25, [sp, #704]            ; 32-byte Folded Spill
	str	q31, [sp, #912]                 ; 16-byte Folded Spill
	stp	q22, q8, [sp, #752]             ; 32-byte Folded Spill
	mov.16b	v23, v29
	ldr	q31, [sp, #832]                 ; 16-byte Folded Reload
	stp	q30, q26, [sp, #800]            ; 32-byte Folded Spill
	ldr	q16, [sp, #944]                 ; 16-byte Folded Reload
	str	q13, [sp, #736]                 ; 16-byte Folded Spill
	str	q9, [sp, #688]                  ; 16-byte Folded Spill
	mov.16b	v27, v12
	str	q4, [sp, #608]                  ; 16-byte Folded Spill
	mov.16b	v13, v19
	mov	b3, v24[6]
	mov.b	v3[4], v24[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v6, v3, #0
	and.16b	v3, v6, v30
	mov	b5, v24[4]
	mov.b	v5[4], v24[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v7, v5, #0
	and.16b	v5, v7, v16
	mov	b16, v24[2]
	mov.b	v16[4], v24[3]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v18, v16, #0
	str	q15, [sp, #784]                 ; 16-byte Folded Spill
	and.16b	v16, v18, v15
	mov	b17, v24[0]
	mov.b	v17[4], v24[1]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v19, v17, #0
	ldr	q0, [sp, #992]                  ; 16-byte Folded Reload
	and.16b	v21, v19, v0
	shl.8b	v17, v24, #7
	cmlt.8b	v4, v17, #0
	and.8b	v17, v4, v2
	mov	w2, #32                         ; =0x20
	dup.2d	v20, x2
	and.16b	v25, v6, v20
	mvn.16b	v6, v6
	sub.2d	v29, v25, v6
	and.16b	v6, v7, v20
	mvn.16b	v7, v7
	sub.2d	v30, v6, v7
	and.16b	v6, v18, v20
	mvn.16b	v7, v18
	and.16b	v18, v19, v20
	mvn.16b	v19, v19
	sub.2d	v28, v18, v19
	mov.d	x2, v28[1]
	mov.d	x3, v21[1]
	sdiv	x6, x3, x2
	sub.2d	v20, v6, v7
	fmov	x3, d28
	fmov	x4, d21
	sdiv	x4, x4, x3
	mul	x7, x4, x3
	fmov	d6, x4
	mov.d	v6[1], x6
	mov.d	x3, v20[1]
	mov.d	x4, v16[1]
	sdiv	x19, x4, x3
	fmov	x4, d20
	fmov	x5, d16
	sdiv	x5, x5, x4
	mul	x20, x5, x4
	fmov	d7, x5
	mov.d	v7[1], x19
	mov.d	x4, v30[1]
	mov.d	x5, v5[1]
	sdiv	x21, x5, x4
	fmov	x5, d30
	fmov	x22, d5
	sdiv	x22, x22, x5
	mul	x23, x22, x5
	fmov	d18, x22
	mov.d	v18[1], x21
	mov.d	x5, v29[1]
	mov.d	x22, v3[1]
	fmov	x24, d29
	fmov	x25, d3
	sdiv	x25, x25, x24
	mul	x24, x25, x24
	fmov	d25, x25
	sdiv	x22, x22, x5
	mov.d	v25[1], x22
	mul	x6, x6, x2
	fmov	d26, x7
	mov.d	v26[1], x6
	mul	x6, x19, x3
	fmov	d8, x20
	mov.d	v8[1], x6
	mul	x6, x21, x4
	fmov	d9, x23
	mov.d	v9[1], x6
	mul	x6, x22, x5
	fmov	d10, x24
	mov.d	v10[1], x6
	addv.8b	b22, v17
	sub.2d	v3, v3, v10
	sub.2d	v5, v5, v9
	fmov	w6, s22
	sub.2d	v16, v16, v8
	sub.2d	v17, v21, v26
	shl.2d	v25, v25, #5
	shl.2d	v18, v18, #5
	shl.2d	v7, v7, #5
	shl.2d	v6, v6, #5
	add.2d	v10, v6, v17
	add.2d	v8, v7, v16
	add.2d	v21, v18, v5
	add.2d	v9, v25, v3
	ldr	q3, [sp, #6016]
	ldr	q6, [sp, #6032]
	ldr	q7, [sp, #6048]
	ldr	q5, [sp, #6064]
	ldr	q16, [sp, #6128]
	ldr	q17, [sp, #6112]
	ldr	q18, [sp, #6096]
	shl.2d	v25, v9, #5
	shl.2d	v26, v21, #5
	ldr	q12, [sp, #6080]
	shl.2d	v11, v8, #5
	shl.2d	v15, v10, #5
	add.2d	v5, v5, v16
	add.2d	v5, v5, v25
	add.2d	v7, v7, v17
	add.2d	v17, v7, v26
	add.2d	v6, v6, v18
	add.2d	v11, v6, v11
	add.2d	v3, v3, v12
	add.2d	v12, v3, v15
	movi.2d	v3, #0000000000000000
	movi.2d	v16, #0000000000000000
	stp	q27, q23, [sp, #848]            ; 32-byte Folded Spill
	str	q13, [sp, #592]                 ; 16-byte Folded Spill
	str	q31, [sp, #832]                 ; 16-byte Folded Spill
	tbnz	w6, #0, LBB0_335
; %bb.308:                              ; %else2805
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w6, #1, LBB0_336
LBB0_309:                               ; %else2811
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v26, v13
	tbnz	w6, #2, LBB0_337
LBB0_310:                               ; %else2817
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldp	q23, q15, [sp, #960]            ; 32-byte Folded Reload
	ldr	q0, [sp, #736]                  ; 16-byte Folded Reload
	ldr	q1, [sp, #928]                  ; 16-byte Folded Reload
	tbnz	w6, #3, LBB0_338
LBB0_311:                               ; %else2823
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w6, #4, LBB0_339
LBB0_312:                               ; %else2829
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w6, #5, LBB0_340
LBB0_313:                               ; %else2835
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w6, #6, LBB0_341
LBB0_314:                               ; %else2841
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbz	w6, #7, LBB0_316
LBB0_315:                               ; %cond.load2843
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x6, v5[1]
	ld1.s	{ v16 }[3], [x6]
LBB0_316:                               ; %else2847
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q6, [sp, #5744]
	ldr	q5, [sp, #5728]
	zip1.8b	v7, v24, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	bit.16b	v5, v3, v7
	zip2.8b	v3, v24, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bsl.16b	v3, v16, v6
	mov	b6, v24[2]
	mov.b	v6[4], v24[3]
	str	q3, [sp, #5744]
	ushll.2d	v3, v6, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	and.16b	v16, v3, v8
	mov	b6, v24[0]
	mov.b	v6[4], v24[1]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v8, v6, #0
	and.16b	v17, v8, v10
	mov	b6, v24[6]
	mov.b	v6[4], v24[7]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v10, v6, #0
	and.16b	v11, v10, v9
	mov	b6, v24[4]
	mov.b	v6[4], v24[5]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v9, v6, #0
	and.16b	v12, v9, v21
	mov.d	x6, v12[1]
	sdiv	x6, x6, x4
	fmov	x7, d12
	fmov	x19, d30
	sdiv	x7, x7, x19
	mul	x19, x7, x19
	fmov	d21, x7
	mov.d	v21[1], x6
	mov.d	x7, v11[1]
	sdiv	x7, x7, x5
	fmov	x20, d11
	fmov	x21, d29
	sdiv	x20, x20, x21
	mul	x21, x20, x21
	fmov	d29, x20
	mov.d	v29[1], x7
	mov.d	x20, v17[1]
	sdiv	x20, x20, x2
	fmov	x22, d17
	fmov	x23, d28
	sdiv	x22, x22, x23
	mul	x23, x22, x23
	fmov	d28, x22
	mov.d	v28[1], x20
	mov.d	x22, v16[1]
	fmov	x24, d16
	fmov	x25, d20
	sdiv	x24, x24, x25
	mul	x25, x24, x25
	fmov	d20, x24
	sdiv	x22, x22, x3
	mov.d	v20[1], x22
	mul	x2, x20, x2
	fmov	d6, x23
	mov.d	v6[1], x2
	mul	x2, x22, x3
	fmov	d7, x25
	mov.d	v7[1], x2
	mul	x2, x6, x4
	fmov	d18, x19
	mov.d	v18[1], x2
	str	q5, [sp, #5728]
	mul	x2, x7, x5
	fmov	d5, x21
	mov.d	v5[1], x2
	sub.2d	v5, v11, v5
	sub.2d	v18, v12, v18
	sub.2d	v7, v16, v7
	sub.2d	v6, v17, v6
	mov	x2, #-2                         ; =0xfffffffffffffffe
	dup.2d	v16, x2
	add.2d	v6, v6, v16
	add.2d	v7, v7, v16
	add.2d	v17, v18, v16
	mov	w2, #32                         ; =0x20
	dup.2d	v18, x2
	add.2d	v5, v5, v16
	cmhi.2d	v16, v18, v5
	cmhi.2d	v25, v18, v17
	uzp1.4s	v16, v25, v16
	cmhi.2d	v25, v18, v7
	cmhi.2d	v18, v18, v6
	uzp1.4s	v18, v18, v25
	uzp1.8h	v16, v18, v16
	xtn.8b	v16, v16
	ldrb	w2, [x9, #512]
	and	w3, w2, #0x1
	fmov	s18, w3
	ubfx	w3, w2, #1, #1
	mov.b	v18[1], w3
	ubfx	w3, w2, #2, #1
	mov.b	v18[2], w3
	ubfx	w3, w2, #3, #1
	mov.b	v18[3], w3
	ubfx	w3, w2, #4, #1
	mov.b	v18[4], w3
	ubfx	w3, w2, #5, #1
	mov.b	v18[5], w3
	ubfx	w3, w2, #6, #1
	mov.b	v18[6], w3
	lsr	w2, w2, #7
	mov.b	v18[7], w2
	bif.8b	v16, v18, v4
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v2
	addv.8b	b16, v16
	str	b16, [x9, #512]
	shl.2d	v18, v20, #5
	shl.2d	v25, v28, #5
	shl.2d	v20, v29, #5
	shl.2d	v16, v21, #5
	add.2d	v16, v16, v17
	add.2d	v20, v20, v5
	add.2d	v5, v25, v6
	add.2d	v17, v18, v7
	ldr	q6, [sp, #5664]
	ldr	q7, [sp, #5680]
	ldr	q18, [sp, #5632]
	ldr	q21, [sp, #5648]
	bsl.16b	v3, v17, v21
	bit.16b	v18, v5, v8
	bit.16b	v7, v20, v10
	bit.16b	v6, v16, v9
	str	q6, [sp, #5664]
	str	q7, [sp, #5680]
	str	q18, [sp, #5632]
	str	q3, [sp, #5648]
	mov	w2, #128                        ; =0x80
	dup.2d	v3, x2
	cmhi.2d	v6, v3, v20
	cmhi.2d	v7, v3, v16
	uzp1.4s	v6, v7, v6
	cmhi.2d	v7, v3, v17
	cmhi.2d	v18, v3, v5
	uzp1.4s	v7, v18, v7
	uzp1.8h	v6, v7, v6
	xtn.8b	v6, v6
	and.8b	v27, v24, v6
	shl.8b	v6, v27, #7
	cmlt.8b	v6, v6, #0
	and.8b	v7, v6, v2
	addv.8b	b7, v7
	fmov	w2, s7
	umaxv.8b	b6, v6
	fmov	w3, s6
	str	q1, [sp, #928]                  ; 16-byte Folded Spill
	stp	q23, q15, [sp, #960]            ; 32-byte Folded Spill
	tbz	w3, #0, LBB0_322
; %bb.317:                              ; %else2847
                                        ;   in Loop: Header=BB0_10 Depth=3
	cmhs.2d	v6, v20, v3
	cmhs.2d	v7, v16, v3
	uzp1.4s	v6, v7, v6
	cmhs.2d	v7, v17, v3
	cmhs.2d	v3, v5, v3
	uzp1.4s	v3, v3, v7
	uzp1.8h	v3, v3, v6
	xtn.8b	v3, v3
	and.8b	v28, v24, v3
	shl.8b	v3, v28, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_322
; %bb.318:                              ; %varying.divergent216
                                        ;   in Loop: Header=BB0_10 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	ldr	q16, [sp, #1088]                ; 16-byte Folded Reload
	str	q16, [sp, #2336]
	ldr	q7, [sp, #1104]                 ; 16-byte Folded Reload
	str	q7, [sp, #2352]
	and	x1, x1, #0x7
	add	x3, sp, #2336
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #6, #0, ne
	cset	w1, ne
	cmp	w2, #255
	ldr	q4, [sp, #608]                  ; 16-byte Folded Reload
	ldr	q17, [sp, #1008]                ; 16-byte Folded Reload
	ldp	q21, q8, [sp, #752]             ; 32-byte Folded Reload
	ldr	q14, [sp, #704]                 ; 16-byte Folded Reload
	ldr	q13, [sp, #800]                 ; 16-byte Folded Reload
	mov.16b	v20, v0
	b.ne	LBB0_320
; %bb.319:                              ; %varying.divergent216
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #0, LBB0_746
LBB0_320:                               ; %convergence.overflow.resume219
                                        ;   in Loop: Header=BB0_10 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #7, lsl #12             ; =28672
	add	x2, x2, #2800
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s3, w4
	ubfx	w4, w5, #1, #1
	mov.b	v3[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v3[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v3[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v3[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v3[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v3[6], w4
	add	x4, sp, #7, lsl #12             ; =28672
	add	x4, x4, #2792
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s5, w6
	ubfx	w6, w5, #1, #1
	mov.b	v5[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v5[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v5[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v5[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v5[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v5[6], w6
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v6, w5
	bit.8b	v3, v24, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x2, w3, uxtw]
	bic.8b	v3, v5, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	ldr	q6, [sp, #992]                  ; 16-byte Folded Reload
	ldr	q15, [sp, #784]                 ; 16-byte Folded Reload
	ldr	q30, [sp, #1040]                ; 16-byte Folded Reload
	ldr	q0, [sp, #720]                  ; 16-byte Folded Reload
	ldr	q9, [sp, #688]                  ; 16-byte Folded Reload
	ldp	q12, q29, [sp, #848]            ; 32-byte Folded Reload
	ldr	q31, [sp, #912]                 ; 16-byte Folded Reload
	b.hs	LBB0_746
; %bb.321:                              ; %ready.overflow.resume221
                                        ;   in Loop: Header=BB0_10 Depth=3
	zip2.8b	v3, v28, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldr	q5, [sp, #304]                  ; 16-byte Folded Reload
	and.16b	v1, v3, v5
	zip1.8b	v3, v28, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldr	q5, [sp, #320]                  ; 16-byte Folded Reload
	and.16b	v5, v3, v5
	stp	q1, q5, [sp, #304]              ; 32-byte Folded Spill
	str	q0, [sp, #2304]
	ldr	q22, [sp, #1072]                ; 16-byte Folded Reload
	str	q22, [sp, #2320]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #2304
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q0, [sp, #2272]
	str	q22, [sp, #2288]
	add	x5, sp, #2272
	str	w4, [x5, x2]
	ldr	q0, [sp, #2288]
	str	q0, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q25, [sp, #2272]
	str	q16, [sp, #2240]
	str	q7, [sp, #2256]
	add	x4, sp, #2240
	ldr	w4, [x4, x2]
	mov	w5, #6                          ; =0x6
	csel	w4, w5, w4, ne
	str	q16, [sp, #2208]
	str	q7, [sp, #2224]
	add	x5, sp, #2208
	str	w4, [x5, x2]
	mov	w2, #16                         ; =0x10
	mov	w4, #15                         ; =0xf
	ldr	q0, [sp, #2224]
	str	q0, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #2208]
	str	q0, [sp, #1088]                 ; 16-byte Folded Spill
                                        ; kill: def $w3 killed $w3 killed $x3 def $x3
	ldr	q1, [sp, #816]                  ; 16-byte Folded Reload
	stp	q6, q17, [sp, #992]             ; 32-byte Folded Spill
	mov.16b	v22, v21
	mov.16b	v19, v26
	mov.16b	v26, v1
	str	q30, [sp, #1040]                ; 16-byte Folded Spill
	mov.16b	v30, v13
	mov.16b	v13, v20
	b	LBB0_9
LBB0_322:                               ; %varying.coherent217
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	ldr	q4, [sp, #608]                  ; 16-byte Folded Reload
	ldr	q29, [sp, #1008]                ; 16-byte Folded Reload
	ldr	q19, [sp, #752]                 ; 16-byte Folded Reload
	str	q29, [sp, #1008]                ; 16-byte Folded Spill
	b.eq	LBB0_351
; %bb.323:                              ; %varying.coherent.true222
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	d0, d22
	ldr	q14, [sp, #992]                 ; 16-byte Folded Reload
	ldr	q8, [sp, #784]                  ; 16-byte Folded Reload
	ldr	q22, [sp, #1040]                ; 16-byte Folded Reload
	ldr	q9, [sp, #688]                  ; 16-byte Folded Reload
	ldr	q1, [sp, #848]                  ; 16-byte Folded Reload
	str	q22, [sp, #1040]                ; 16-byte Folded Spill
	str	q14, [sp, #992]                 ; 16-byte Folded Spill
	tbnz	w1, #0, LBB0_727
; %bb.324:                              ; %schedule.15.thread
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q3, [sp, #6016]
	ldr	q5, [sp, #6032]
	ldr	q6, [sp, #6048]
	ldr	q7, [sp, #6064]
	ldr	q16, [sp, #6128]
	ldr	q17, [sp, #6112]
	ldr	q18, [sp, #6096]
	ldr	q21, [sp, #6080]
	ldr	q20, [sp, #5632]
	ldr	q25, [sp, #5648]
	ldr	q26, [sp, #5664]
	ldr	q27, [sp, #5680]
	shl.2d	v27, v27, #5
	shl.2d	v26, v26, #5
	shl.2d	v25, v25, #5
	shl.2d	v28, v20, #5
	add.2d	v7, v7, v16
	add.2d	v23, v7, v27
	add.2d	v6, v6, v17
	add.2d	v17, v6, v26
	add.2d	v5, v5, v18
	add.2d	v20, v5, v25
	add.2d	v3, v3, v21
	add.2d	v21, v3, v28
	fmov	w1, s0
	movi.2d	v3, #0000000000000000
	movi.2d	v5, #0000000000000000
	ldr	q26, [sp, #816]                 ; 16-byte Folded Reload
	ldr	q6, [sp, #1024]                 ; 16-byte Folded Reload
	ldr	q25, [sp, #720]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #944]                  ; 16-byte Folded Reload
	ldr	q7, [sp, #880]                  ; 16-byte Folded Reload
	mov.16b	v28, v19
	tbnz	w1, #0, LBB0_376
; %bb.325:                              ; %else3434
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q18, [sp, #912]                 ; 16-byte Folded Reload
	mov.16b	v12, v1
	mov.16b	v19, v4
	mov.16b	v16, v9
	tbnz	w1, #1, LBB0_377
LBB0_326:                               ; %else3440
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q4, [sp, #704]                  ; 16-byte Folded Reload
	ldr	q9, [sp, #736]                  ; 16-byte Folded Reload
	mov.16b	v31, v18
	tbz	w1, #2, LBB0_328
LBB0_327:                               ; %cond.load3442
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d20
	ld1.s	{ v3 }[2], [x2]
LBB0_328:                               ; %else3446
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q1, [sp, #592]                  ; 16-byte Folded Reload
	ldr	q27, [sp, #768]                 ; 16-byte Folded Reload
	mov.16b	v15, v8
	ldr	q30, [sp, #800]                 ; 16-byte Folded Reload
	str	q7, [sp, #880]                  ; 16-byte Folded Spill
	mov.16b	v13, v9
	str	q0, [sp, #944]                  ; 16-byte Folded Spill
	tbnz	w1, #3, LBB0_378
; %bb.329:                              ; %else3452
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q29, [sp, #864]                 ; 16-byte Folded Reload
	mov.16b	v8, v27
	mov.16b	v14, v4
	mov.16b	v9, v16
	str	q6, [sp, #1024]                 ; 16-byte Folded Spill
	tbnz	w1, #4, LBB0_379
LBB0_330:                               ; %else3458
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v4, v19
	mov.16b	v22, v28
	mov.16b	v19, v1
	tbnz	w1, #5, LBB0_380
LBB0_331:                               ; %else3464
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #6, LBB0_381
LBB0_332:                               ; %else3470
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbz	w1, #7, LBB0_334
LBB0_333:                               ; %cond.load3472
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x1, v23[1]
	ld1.s	{ v5 }[3], [x1]
LBB0_334:                               ; %else3476
                                        ;   in Loop: Header=BB0_10 Depth=3
	zip2.8b	v6, v24, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	ldr	q7, [sp, #304]                  ; 16-byte Folded Reload
	bit.16b	v7, v5, v6
	zip1.8b	v5, v24, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q6, [sp, #320]                  ; 16-byte Folded Reload
	bit.16b	v6, v3, v5
	stp	q7, q6, [sp, #304]              ; 32-byte Folded Spill
	b	LBB0_352
LBB0_335:                               ; %cond.load2801
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x7, d12
	ldr	s3, [x7]
	tbz	w6, #1, LBB0_309
LBB0_336:                               ; %cond.load2807
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x7, v12[1]
	ld1.s	{ v3 }[1], [x7]
	mov.16b	v26, v13
	tbz	w6, #2, LBB0_310
LBB0_337:                               ; %cond.load2813
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x7, d11
	ld1.s	{ v3 }[2], [x7]
	ldp	q23, q15, [sp, #960]            ; 32-byte Folded Reload
	ldr	q0, [sp, #736]                  ; 16-byte Folded Reload
	ldr	q1, [sp, #928]                  ; 16-byte Folded Reload
	tbz	w6, #3, LBB0_311
LBB0_338:                               ; %cond.load2819
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x7, v11[1]
	ld1.s	{ v3 }[3], [x7]
	tbz	w6, #4, LBB0_312
LBB0_339:                               ; %cond.load2825
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x7, d17
	ld1.s	{ v16 }[0], [x7]
	tbz	w6, #5, LBB0_313
LBB0_340:                               ; %cond.load2831
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x7, v17[1]
	ld1.s	{ v16 }[1], [x7]
	tbz	w6, #6, LBB0_314
LBB0_341:                               ; %cond.load2837
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x7, d5
	ld1.s	{ v16 }[2], [x7]
	tbnz	w6, #7, LBB0_315
	b	LBB0_316
LBB0_342:                               ; %varying.coherent.false212
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_5
LBB0_343:                               ; %schedule.17
                                        ;   in Loop: Header=BB0_10 Depth=3
	cbz	w0, LBB0_348
; %bb.344:                              ; %convergence.cascade252.preheader
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov	w1, #0                          ; =0x0
LBB0_345:                               ; %convergence.cascade252
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_10 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v5, v3, v2
	addv.8b	b5, v5
	fmov	w2, s5
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #4320]
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	str	q0, [sp, #4336]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #1, lsl #12             ; =4096
	add	x6, x6, #224
	ldr	w6, [x6, x2]
	cmp	w6, #5
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #7, lsl #12             ; =28672
	add	x5, x5, #2800
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s3, w19
	ubfx	w19, w20, #1, #1
	mov.b	v3[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v3[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v3[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v3[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v3[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v3[6], w19
	add	x19, sp, #7, lsl #12            ; =28672
	add	x19, x19, #2792
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s5, w21
	ubfx	w21, w20, #1, #1
	mov.b	v5[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v5[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v5[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v5[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v5[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v5[6], w21
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	orr.8b	v6, v24, v5
	ldr	d0, [sp, #1064]                 ; 8-byte Folded Reload
	and.8b	v7, v0, v3
	eor.8b	v7, v7, v6
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v6, v7
	dup.8b	v17, w7
	bit.8b	v5, v16, v17
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x19, w3, sxtw]
	bic.8b	v3, v3, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v5, v5, v6
	str	q25, [sp, #4288]
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	str	q0, [sp, #4304]
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #192
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v24, v5, v3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_349
; %bb.346:                              ; %convergence.cascade252
                                        ;   in Loop: Header=BB0_345 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_349
; %bb.347:                              ; %convergence.cascade252
                                        ;   in Loop: Header=BB0_345 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_345
	b	LBB0_349
LBB0_348:                               ; %schedule.17.convergence.cascade.exit253_crit_edge
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_349:                               ; %convergence.cascade.exit253
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_5
; %bb.350:                              ; %convergence.target.17.ready
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q17, [sp, #5600]
	ldr	q5, [sp, #5616]
	ldr	q3, [sp, #5568]
	ldr	q6, [sp, #5584]
	ldr	q16, [sp, #5536]
	ldr	q7, [sp, #5552]
	ldr	q18, [sp, #5504]
	ldr	q20, [sp, #5520]
	mov.16b	v11, v8
	mov.16b	v8, v29
	mov.16b	v29, v4
	mov.16b	v4, v31
	mov.16b	v31, v15
	mov.16b	v15, v12
	mov.16b	v12, v14
	mov.16b	v14, v13
	mov.16b	v13, v9
	mov.16b	v9, v30
	mov.16b	v30, v19
	mov	b19, v24[2]
	mov.b	v19[4], v24[3]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	ldr	q28, [sp, #160]                 ; 16-byte Folded Reload
	bit.16b	v20, v28, v19
	mov	b21, v24[0]
	mov.b	v21[4], v24[1]
	ushll.2d	v21, v21, #0
	shl.2d	v21, v21, #63
	cmlt.2d	v21, v21, #0
	mov.16b	v0, v25
	mov	b25, v24[6]
	mov.b	v25[4], v24[7]
	bit.16b	v18, v28, v21
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	bit.16b	v7, v28, v25
	mov.16b	v1, v26
	mov	b26, v24[4]
	mov.b	v26[4], v24[5]
	ushll.2d	v26, v26, #0
	shl.2d	v26, v26, #63
	cmlt.2d	v26, v26, #0
Lloh58:
	adrp	x1, lCPI0_17@PAGE
Lloh59:
	ldr	q27, [x1, lCPI0_17@PAGEOFF]
	bit.16b	v6, v27, v19
Lloh60:
	adrp	x1, lCPI0_18@PAGE
Lloh61:
	ldr	q27, [x1, lCPI0_18@PAGEOFF]
	bit.16b	v17, v27, v26
Lloh62:
	adrp	x1, lCPI0_16@PAGE
Lloh63:
	ldr	q27, [x1, lCPI0_16@PAGEOFF]
	str	q17, [sp, #5600]
Lloh64:
	adrp	x1, lCPI0_19@PAGE
Lloh65:
	ldr	q17, [x1, lCPI0_19@PAGEOFF]
	bit.16b	v16, v28, v26
	bit.16b	v5, v17, v25
	str	q5, [sp, #5616]
	bit.16b	v3, v27, v21
	str	q3, [sp, #5568]
	str	q6, [sp, #5584]
	str	q16, [sp, #5536]
	str	q7, [sp, #5552]
	str	q18, [sp, #5504]
	str	q20, [sp, #5520]
	ldr	q3, [sp, #960]                  ; 16-byte Folded Reload
	bic.16b	v3, v3, v25
	str	q3, [sp, #960]                  ; 16-byte Folded Spill
	mov.16b	v25, v0
	ldp	q6, q3, [sp, #640]              ; 32-byte Folded Reload
	bic.16b	v5, v6, v26
	mov.16b	v26, v1
	bic.16b	v12, v12, v19
	mov.16b	v19, v30
	mov.16b	v30, v9
	mov.16b	v9, v13
	mov.16b	v13, v14
	mov.16b	v14, v12
	mov.16b	v12, v15
	mov.16b	v15, v31
	mov.16b	v31, v4
	mov.16b	v4, v29
	mov.16b	v29, v8
	mov.16b	v8, v11
	bic.16b	v3, v3, v21
	stp	q5, q3, [sp, #640]              ; 32-byte Folded Spill
	b	LBB0_382
LBB0_351:                               ; %varying.coherent.false223
                                        ;   in Loop: Header=BB0_10 Depth=3
	zip2.8b	v3, v24, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldp	q6, q5, [sp, #304]              ; 32-byte Folded Reload
	and.16b	v1, v3, v6
	zip1.8b	v3, v24, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v5, v3, v5
	stp	q1, q5, [sp, #304]              ; 32-byte Folded Spill
	ldp	q15, q30, [sp, #784]            ; 32-byte Folded Reload
	ldr	q26, [sp, #816]                 ; 16-byte Folded Reload
	ldp	q14, q25, [sp, #704]            ; 32-byte Folded Reload
	ldr	q9, [sp, #688]                  ; 16-byte Folded Reload
	ldp	q12, q29, [sp, #848]            ; 32-byte Folded Reload
	ldr	q31, [sp, #912]                 ; 16-byte Folded Reload
	ldr	q13, [sp, #736]                 ; 16-byte Folded Reload
	ldr	q21, [sp, #592]                 ; 16-byte Folded Reload
	mov.16b	v22, v19
	ldr	q8, [sp, #768]                  ; 16-byte Folded Reload
	mov.16b	v19, v21
	tbnz	w1, #0, LBB0_5
LBB0_352:                               ; %schedule.16
                                        ;   in Loop: Header=BB0_10 Depth=3
	str	q29, [sp, #864]                 ; 16-byte Folded Spill
	mov.16b	v29, v4
	mov.16b	v4, v31
	mov.16b	v31, v15
	mov.16b	v15, v12
	mov.16b	v12, v14
	mov.16b	v14, v13
	mov.16b	v13, v9
	mov.16b	v9, v30
	cbz	w0, LBB0_357
; %bb.353:                              ; %convergence.cascade226.preheader
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v30, v19
	mov.16b	v1, v26
	mov	w1, #0                          ; =0x0
LBB0_354:                               ; %convergence.cascade226
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_10 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v5, v3, v2
	addv.8b	b5, v5
	fmov	w2, s5
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #2400]
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	str	q0, [sp, #2416]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #2400
	ldr	w6, [x6, x2]
	cmp	w6, #6
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #7, lsl #12             ; =28672
	add	x5, x5, #2800
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s3, w19
	ubfx	w19, w20, #1, #1
	mov.b	v3[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v3[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v3[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v3[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v3[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v3[6], w19
	add	x19, sp, #7, lsl #12            ; =28672
	add	x19, x19, #2792
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s5, w21
	ubfx	w21, w20, #1, #1
	mov.b	v5[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v5[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v5[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v5[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v5[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v5[6], w21
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	orr.8b	v6, v24, v5
	ldr	d0, [sp, #1064]                 ; 8-byte Folded Reload
	and.8b	v7, v0, v3
	eor.8b	v7, v7, v6
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v6, v7
	dup.8b	v17, w7
	bit.8b	v5, v16, v17
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x19, w3, sxtw]
	bic.8b	v3, v3, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v5, v5, v6
	str	q25, [sp, #2368]
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	str	q0, [sp, #2384]
	add	x3, sp, #2368
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v24, v5, v3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_358
; %bb.355:                              ; %convergence.cascade226
                                        ;   in Loop: Header=BB0_354 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_358
; %bb.356:                              ; %convergence.cascade226
                                        ;   in Loop: Header=BB0_354 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_354
	b	LBB0_358
LBB0_357:                               ; %schedule.16.convergence.cascade.exit227_crit_edge
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v30, v19
	mov.16b	v1, v26
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_358:                               ; %convergence.cascade.exit227
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_713
; %bb.359:                              ; %convergence.target.16.ready
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v0, v25
	ldrb	w1, [x9, #512]
	lsr	w2, w1, #7
	ubfx	w3, w1, #6, #1
	ubfx	w4, w1, #5, #1
	ubfx	w5, w1, #4, #1
	ubfx	w6, w1, #3, #1
	ubfx	w7, w1, #2, #1
	ubfx	w19, w1, #1, #1
	and	w1, w1, #0x1
	fmov	s3, w1
	mov.h	v3[1], w19
	mov.h	v3[2], w7
	mov.h	v3[3], w6
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	fmov	s5, w5
	mov.h	v5[1], w4
	mov.h	v5[2], w3
	ldr	q6, [sp, #320]                  ; 16-byte Folded Reload
	and.16b	v6, v3, v6
	mov.h	v5[3], w2
	ushll.4s	v3, v5, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q5, [sp, #304]                  ; 16-byte Folded Reload
	and.16b	v3, v3, v5
	ldr	q5, [sp, #5728]
	ldr	q7, [sp, #5744]
	fadd.4s	v3, v7, v3
	fadd.4s	v16, v5, v6
	ldr	q5, [sp, #5808]
	ldr	q6, [sp, #5792]
	ldr	q7, [sp, #5760]
	ldr	q17, [sp, #5776]
	ldr	q18, [sp, #5840]
	ldr	q19, [sp, #5824]
	ldr	q20, [sp, #5856]
	ldr	q21, [sp, #5872]
	shl.2d	v25, v31, #5
	ldr	q26, [sp, #992]                 ; 16-byte Folded Reload
	shl.2d	v26, v26, #5
	ldr	q23, [sp, #944]                 ; 16-byte Folded Reload
	shl.2d	v27, v23, #5
	shl.2d	v28, v9, #5
	add.2d	v21, v21, v28
	add.2d	v27, v20, v27
	add.2d	v20, v19, v26
	add.2d	v18, v18, v25
	add.2d	v19, v17, v18
	add.2d	v20, v7, v20
	add.2d	v17, v6, v27
	add.2d	v5, v5, v21
	shl.8b	v6, v24, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	fmov	w1, s6
	tbnz	w1, #0, LBB0_369
; %bb.360:                              ; %else3482
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #1, LBB0_370
LBB0_361:                               ; %else3486
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v25, v0
	mov.16b	v26, v1
	tbnz	w1, #2, LBB0_371
LBB0_362:                               ; %else3490
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #3, LBB0_372
LBB0_363:                               ; %else3494
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #4, LBB0_373
LBB0_364:                               ; %else3498
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v19, v30
	tbnz	w1, #5, LBB0_374
LBB0_365:                               ; %else3502
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v30, v9
	tbnz	w1, #6, LBB0_375
LBB0_366:                               ; %else3506
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v9, v13
	tbz	w1, #7, LBB0_368
LBB0_367:                               ; %cond.store3507
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x1, v5[1]
	st1.s	{ v3 }[3], [x1]
LBB0_368:                               ; %else3510
                                        ;   in Loop: Header=BB0_10 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v24, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v5, v3, #0
	ushll2.4s	v3, v3, #0
	uaddw2.2d	v30, v30, v3
	ldr	q0, [sp, #944]                  ; 16-byte Folded Reload
	uaddw.2d	v0, v0, v3
	str	q0, [sp, #944]                  ; 16-byte Folded Spill
	uaddw2.2d	v31, v31, v5
	ldr	q0, [sp, #992]                  ; 16-byte Folded Reload
	uaddw.2d	v0, v0, v5
	str	q0, [sp, #992]                  ; 16-byte Folded Spill
	mov.16b	v13, v14
	mov.16b	v14, v12
	mov.16b	v12, v15
	mov.16b	v15, v31
	mov.16b	v31, v4
	mov.16b	v4, v29
	ldr	q29, [sp, #864]                 ; 16-byte Folded Reload
	b	LBB0_299
LBB0_369:                               ; %cond.store3479
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d20
	str	s16, [x2]
	tbz	w1, #1, LBB0_361
LBB0_370:                               ; %cond.store3483
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v20[1]
	st1.s	{ v16 }[1], [x2]
	mov.16b	v25, v0
	mov.16b	v26, v1
	tbz	w1, #2, LBB0_362
LBB0_371:                               ; %cond.store3487
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d19
	st1.s	{ v16 }[2], [x2]
	tbz	w1, #3, LBB0_363
LBB0_372:                               ; %cond.store3491
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v19[1]
	st1.s	{ v16 }[3], [x2]
	tbz	w1, #4, LBB0_364
LBB0_373:                               ; %cond.store3495
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d17
	str	s3, [x2]
	mov.16b	v19, v30
	tbz	w1, #5, LBB0_365
LBB0_374:                               ; %cond.store3499
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v17[1]
	st1.s	{ v3 }[1], [x2]
	mov.16b	v30, v9
	tbz	w1, #6, LBB0_366
LBB0_375:                               ; %cond.store3503
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d5
	st1.s	{ v3 }[2], [x2]
	mov.16b	v9, v13
	tbnz	w1, #7, LBB0_367
	b	LBB0_368
LBB0_376:                               ; %cond.load3430
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d21
	ldr	s3, [x2]
	ldr	q18, [sp, #912]                 ; 16-byte Folded Reload
	mov.16b	v12, v1
	mov.16b	v19, v4
	mov.16b	v16, v9
	tbz	w1, #1, LBB0_326
LBB0_377:                               ; %cond.load3436
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v21[1]
	ld1.s	{ v3 }[1], [x2]
	ldr	q4, [sp, #704]                  ; 16-byte Folded Reload
	ldr	q9, [sp, #736]                  ; 16-byte Folded Reload
	mov.16b	v31, v18
	tbnz	w1, #2, LBB0_327
	b	LBB0_328
LBB0_378:                               ; %cond.load3448
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v20[1]
	ld1.s	{ v3 }[3], [x2]
	ldr	q29, [sp, #864]                 ; 16-byte Folded Reload
	mov.16b	v8, v27
	mov.16b	v14, v4
	mov.16b	v9, v16
	str	q6, [sp, #1024]                 ; 16-byte Folded Spill
	tbz	w1, #4, LBB0_330
LBB0_379:                               ; %cond.load3454
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d17
	ld1.s	{ v5 }[0], [x2]
	mov.16b	v4, v19
	mov.16b	v22, v28
	mov.16b	v19, v1
	tbz	w1, #5, LBB0_331
LBB0_380:                               ; %cond.load3460
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v17[1]
	ld1.s	{ v5 }[1], [x2]
	tbz	w1, #6, LBB0_332
LBB0_381:                               ; %cond.load3466
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d23
	ld1.s	{ v5 }[2], [x2]
	tbnz	w1, #7, LBB0_333
	b	LBB0_334
LBB0_382:                               ; %schedule.18
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	mov	w1, #128                        ; =0x80
	dup.2d	v3, x1
	cmgt.2d	v5, v3, v14
	ldr	q6, [sp, #656]                  ; 16-byte Folded Reload
	cmgt.2d	v6, v3, v6
	uzp1.4s	v5, v6, v5
	ldr	q6, [sp, #640]                  ; 16-byte Folded Reload
	cmgt.2d	v6, v3, v6
	ldr	q0, [sp, #960]                  ; 16-byte Folded Reload
	cmgt.2d	v7, v3, v0
	uzp1.4s	v6, v6, v7
	uzp1.8h	v5, v5, v6
	xtn.8b	v5, v5
	and.8b	v27, v24, v5
	shl.8b	v5, v27, #7
	cmlt.8b	v5, v5, #0
	and.8b	v6, v5, v2
	addv.8b	b6, v6
	fmov	w1, s6
	umaxv.8b	b5, v5
	fmov	w3, s5
	tbz	w3, #0, LBB0_388
; %bb.383:                              ; %schedule.18
                                        ;   in Loop: Header=BB0_10 Depth=3
	cmge.2d	v5, v14, v3
	ldr	q6, [sp, #656]                  ; 16-byte Folded Reload
	cmge.2d	v6, v6, v3
	uzp1.4s	v5, v6, v5
	ldr	q6, [sp, #640]                  ; 16-byte Folded Reload
	cmge.2d	v6, v6, v3
	ldr	q0, [sp, #960]                  ; 16-byte Folded Reload
	cmge.2d	v3, v0, v3
	uzp1.4s	v3, v6, v3
	uzp1.8h	v3, v5, v3
	xtn.8b	v3, v3
	and.8b	v28, v24, v3
	shl.8b	v3, v28, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_388
; %bb.384:                              ; %varying.divergent270
                                        ;   in Loop: Header=BB0_10 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #2560]
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	str	q0, [sp, #2576]
	and	x1, x1, #0x7
	add	x3, sp, #2560
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #7, #0, ne
	cset	w1, ne
	cmp	w2, #255
	b.ne	LBB0_386
; %bb.385:                              ; %varying.divergent270
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #0, LBB0_746
LBB0_386:                               ; %convergence.overflow.resume273
                                        ;   in Loop: Header=BB0_10 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #7, lsl #12             ; =28672
	add	x2, x2, #2800
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s3, w4
	ubfx	w4, w5, #1, #1
	mov.b	v3[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v3[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v3[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v3[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v3[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v3[6], w4
	add	x4, sp, #7, lsl #12             ; =28672
	add	x4, x4, #2792
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s5, w6
	ubfx	w6, w5, #1, #1
	mov.b	v5[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v5[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v5[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v5[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v5[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v5[6], w6
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v6, w5
	bit.8b	v3, v24, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x2, w3, uxtw]
	bic.8b	v3, v5, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_746
; %bb.387:                              ; %ready.overflow.resume275
                                        ;   in Loop: Header=BB0_10 Depth=3
	str	q25, [sp, #2528]
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	str	q0, [sp, #2544]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #2528
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q25, [sp, #2496]
	str	q0, [sp, #2512]
	add	x5, sp, #2496
	str	w4, [x5, x2]
	ldr	q0, [sp, #2512]
	str	q0, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q25, [sp, #2496]
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #2464]
	ldr	q1, [sp, #1104]                 ; 16-byte Folded Reload
	str	q1, [sp, #2480]
	add	x4, sp, #2464
	ldr	w4, [x4, x2]
	mov	w5, #7                          ; =0x7
	csel	w4, w5, w4, ne
	str	q0, [sp, #2432]
	str	q1, [sp, #2448]
	add	x5, sp, #2432
	str	w4, [x5, x2]
	mov	w2, #22                         ; =0x16
	mov	w4, #19                         ; =0x13
	ldr	q0, [sp, #2448]
	str	q0, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #2432]
	str	q0, [sp, #1088]                 ; 16-byte Folded Spill
                                        ; kill: def $w3 killed $w3 killed $x3 def $x3
	b	LBB0_9
LBB0_388:                               ; %varying.coherent271
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w1, #0xff
	b.eq	LBB0_450
; %bb.389:                              ; %varying.coherent.true276
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov	w1, #0                          ; =0x0
	tst	w2, #0xff
	b.eq	LBB0_5
LBB0_390:                               ; %schedule.19
                                        ;   in Loop: Header=BB0_10 Depth=3
	stp	q25, q13, [sp, #720]            ; 32-byte Folded Spill
	str	q31, [sp, #912]                 ; 16-byte Folded Spill
	stp	q8, q15, [sp, #768]             ; 32-byte Folded Spill
	str	q29, [sp, #864]                 ; 16-byte Folded Spill
	stp	q30, q26, [sp, #800]            ; 32-byte Folded Spill
	ldr	q5, [sp, #960]                  ; 16-byte Folded Reload
	mov.16b	v6, v4
	ldr	q4, [sp, #832]                  ; 16-byte Folded Reload
	str	q9, [sp, #688]                  ; 16-byte Folded Spill
	mov.16b	v27, v12
	str	q22, [sp, #752]                 ; 16-byte Folded Spill
	str	q6, [sp, #608]                  ; 16-byte Folded Spill
	mov.16b	v13, v19
	mov	b3, v24[6]
	mov.b	v3[4], v24[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v6, v3, #0
	and.16b	v3, v6, v5
	mov	b5, v24[4]
	mov.b	v5[4], v24[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v7, v5, #0
	ldr	q5, [sp, #640]                  ; 16-byte Folded Reload
	and.16b	v5, v7, v5
	mov	b16, v24[2]
	mov.b	v16[4], v24[3]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v18, v16, #0
	str	q14, [sp, #704]                 ; 16-byte Folded Spill
	and.16b	v16, v18, v14
	mov	b17, v24[0]
	mov.b	v17[4], v24[1]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v19, v17, #0
	ldr	q17, [sp, #656]                 ; 16-byte Folded Reload
	and.16b	v21, v19, v17
	shl.8b	v17, v24, #7
	cmlt.8b	v1, v17, #0
	and.8b	v17, v1, v2
	mov	w2, #32                         ; =0x20
	dup.2d	v20, x2
	and.16b	v25, v6, v20
	mvn.16b	v6, v6
	sub.2d	v29, v25, v6
	and.16b	v6, v7, v20
	mvn.16b	v7, v7
	sub.2d	v30, v6, v7
	and.16b	v6, v18, v20
	mvn.16b	v7, v18
	and.16b	v18, v19, v20
	mvn.16b	v19, v19
	sub.2d	v28, v18, v19
	mov.d	x2, v28[1]
	mov.d	x3, v21[1]
	sdiv	x6, x3, x2
	sub.2d	v20, v6, v7
	fmov	x3, d28
	fmov	x4, d21
	sdiv	x4, x4, x3
	mul	x7, x4, x3
	fmov	d6, x4
	mov.d	v6[1], x6
	mov.d	x3, v20[1]
	mov.d	x4, v16[1]
	sdiv	x19, x4, x3
	fmov	x4, d20
	fmov	x5, d16
	sdiv	x5, x5, x4
	mul	x20, x5, x4
	fmov	d7, x5
	mov.d	v7[1], x19
	mov.d	x4, v30[1]
	mov.d	x5, v5[1]
	sdiv	x21, x5, x4
	fmov	x5, d30
	fmov	x22, d5
	sdiv	x22, x22, x5
	mul	x23, x22, x5
	fmov	d18, x22
	mov.d	v18[1], x21
	mov.d	x5, v29[1]
	mov.d	x22, v3[1]
	fmov	x24, d29
	fmov	x25, d3
	sdiv	x25, x25, x24
	mul	x24, x25, x24
	fmov	d25, x25
	sdiv	x22, x22, x5
	mov.d	v25[1], x22
	mul	x6, x6, x2
	fmov	d26, x7
	mov.d	v26[1], x6
	mul	x6, x19, x3
	fmov	d8, x20
	mov.d	v8[1], x6
	mul	x6, x21, x4
	fmov	d9, x23
	mov.d	v9[1], x6
	mul	x6, x22, x5
	fmov	d10, x24
	mov.d	v10[1], x6
	addv.8b	b14, v17
	sub.2d	v3, v3, v10
	sub.2d	v5, v5, v9
	fmov	w6, s14
	sub.2d	v16, v16, v8
	sub.2d	v17, v21, v26
	shl.2d	v25, v25, #5
	shl.2d	v18, v18, #5
	shl.2d	v7, v7, #5
	shl.2d	v6, v6, #5
	add.2d	v10, v6, v17
	add.2d	v8, v7, v16
	add.2d	v21, v18, v5
	add.2d	v9, v25, v3
	ldr	q3, [sp, #5760]
	ldr	q6, [sp, #5776]
	ldr	q7, [sp, #5792]
	ldr	q5, [sp, #5808]
	ldr	q16, [sp, #5872]
	ldr	q17, [sp, #5856]
	ldr	q18, [sp, #5840]
	shl.2d	v25, v9, #5
	shl.2d	v26, v21, #5
	ldr	q12, [sp, #5824]
	shl.2d	v11, v8, #5
	shl.2d	v15, v10, #5
	add.2d	v5, v5, v16
	add.2d	v5, v5, v25
	add.2d	v7, v7, v17
	add.2d	v17, v7, v26
	add.2d	v6, v6, v18
	add.2d	v11, v6, v11
	add.2d	v3, v3, v12
	add.2d	v12, v3, v15
	movi.2d	v3, #0000000000000000
	movi.2d	v16, #0000000000000000
	stp	q4, q27, [sp, #832]             ; 32-byte Folded Spill
	tbnz	w6, #0, LBB0_418
; %bb.391:                              ; %else2903
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w6, #1, LBB0_419
LBB0_392:                               ; %else2909
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w6, #2, LBB0_420
LBB0_393:                               ; %else2915
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q26, [sp, #736]                 ; 16-byte Folded Reload
	tbnz	w6, #3, LBB0_421
LBB0_394:                               ; %else2921
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w6, #4, LBB0_422
LBB0_395:                               ; %else2927
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w6, #5, LBB0_423
LBB0_396:                               ; %else2933
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w6, #6, LBB0_424
LBB0_397:                               ; %else2939
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbz	w6, #7, LBB0_399
LBB0_398:                               ; %cond.load2941
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x6, v5[1]
	ld1.s	{ v16 }[3], [x6]
LBB0_399:                               ; %else2945
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q6, [sp, #5488]
	ldr	q5, [sp, #5472]
	zip1.8b	v7, v24, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	bit.16b	v5, v3, v7
	zip2.8b	v3, v24, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bsl.16b	v3, v16, v6
	mov	b6, v24[2]
	mov.b	v6[4], v24[3]
	str	q3, [sp, #5488]
	ushll.2d	v3, v6, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	and.16b	v16, v3, v8
	mov	b6, v24[0]
	mov.b	v6[4], v24[1]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v8, v6, #0
	and.16b	v17, v8, v10
	mov	b6, v24[6]
	mov.b	v6[4], v24[7]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v10, v6, #0
	and.16b	v11, v10, v9
	mov	b6, v24[4]
	mov.b	v6[4], v24[5]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v9, v6, #0
	and.16b	v12, v9, v21
	mov.d	x6, v12[1]
	sdiv	x6, x6, x4
	fmov	x7, d12
	fmov	x19, d30
	sdiv	x7, x7, x19
	mul	x19, x7, x19
	fmov	d21, x7
	mov.d	v21[1], x6
	mov.d	x7, v11[1]
	sdiv	x7, x7, x5
	fmov	x20, d11
	fmov	x21, d29
	sdiv	x20, x20, x21
	mul	x21, x20, x21
	fmov	d29, x20
	mov.d	v29[1], x7
	mov.d	x20, v17[1]
	sdiv	x20, x20, x2
	fmov	x22, d17
	fmov	x23, d28
	sdiv	x22, x22, x23
	mul	x23, x22, x23
	fmov	d28, x22
	mov.d	v28[1], x20
	mov.d	x22, v16[1]
	fmov	x24, d16
	fmov	x25, d20
	sdiv	x24, x24, x25
	mul	x25, x24, x25
	fmov	d20, x24
	sdiv	x22, x22, x3
	mov.d	v20[1], x22
	mul	x2, x20, x2
	fmov	d6, x23
	mov.d	v6[1], x2
	mul	x2, x22, x3
	fmov	d7, x25
	mov.d	v7[1], x2
	mul	x2, x6, x4
	fmov	d18, x19
	mov.d	v18[1], x2
	str	q5, [sp, #5472]
	mul	x2, x7, x5
	fmov	d5, x21
	mov.d	v5[1], x2
	sub.2d	v5, v11, v5
	sub.2d	v18, v12, v18
	sub.2d	v7, v16, v7
	sub.2d	v6, v17, v6
	mov	x2, #-4                         ; =0xfffffffffffffffc
	dup.2d	v16, x2
	add.2d	v6, v6, v16
	add.2d	v7, v7, v16
	add.2d	v17, v18, v16
	mov	w2, #32                         ; =0x20
	dup.2d	v18, x2
	add.2d	v5, v5, v16
	cmhi.2d	v16, v18, v5
	cmhi.2d	v25, v18, v17
	uzp1.4s	v16, v25, v16
	cmhi.2d	v25, v18, v7
	cmhi.2d	v18, v18, v6
	uzp1.4s	v18, v18, v25
	uzp1.8h	v16, v18, v16
	xtn.8b	v16, v16
	ldrb	w2, [x9, #256]
	and	w3, w2, #0x1
	fmov	s18, w3
	ubfx	w3, w2, #1, #1
	mov.b	v18[1], w3
	ubfx	w3, w2, #2, #1
	mov.b	v18[2], w3
	ubfx	w3, w2, #3, #1
	mov.b	v18[3], w3
	ubfx	w3, w2, #4, #1
	mov.b	v18[4], w3
	ubfx	w3, w2, #5, #1
	mov.b	v18[5], w3
	ubfx	w3, w2, #6, #1
	mov.b	v18[6], w3
	lsr	w2, w2, #7
	mov.b	v18[7], w2
	bif.8b	v16, v18, v1
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v2
	addv.8b	b16, v16
	str	b16, [x9, #256]
	shl.2d	v18, v20, #5
	shl.2d	v25, v28, #5
	shl.2d	v20, v29, #5
	shl.2d	v16, v21, #5
	add.2d	v16, v16, v17
	add.2d	v20, v20, v5
	add.2d	v5, v25, v6
	add.2d	v17, v18, v7
	ldr	q6, [sp, #5408]
	ldr	q7, [sp, #5424]
	ldr	q18, [sp, #5376]
	ldr	q21, [sp, #5392]
	bsl.16b	v3, v17, v21
	bit.16b	v18, v5, v8
	bit.16b	v7, v20, v10
	bit.16b	v6, v16, v9
	str	q6, [sp, #5408]
	str	q7, [sp, #5424]
	str	q18, [sp, #5376]
	str	q3, [sp, #5392]
	mov	w2, #128                        ; =0x80
	dup.2d	v3, x2
	cmhi.2d	v6, v3, v20
	cmhi.2d	v7, v3, v16
	uzp1.4s	v6, v7, v6
	cmhi.2d	v7, v3, v17
	cmhi.2d	v18, v3, v5
	uzp1.4s	v7, v18, v7
	uzp1.8h	v6, v7, v6
	xtn.8b	v6, v6
	and.8b	v27, v24, v6
	shl.8b	v6, v27, #7
	cmlt.8b	v6, v6, #0
	and.8b	v7, v6, v2
	addv.8b	b7, v7
	fmov	w2, s7
	umaxv.8b	b6, v6
	fmov	w3, s6
	tbz	w3, #0, LBB0_405
; %bb.400:                              ; %else2945
                                        ;   in Loop: Header=BB0_10 Depth=3
	cmhs.2d	v6, v20, v3
	cmhs.2d	v7, v16, v3
	uzp1.4s	v6, v7, v6
	cmhs.2d	v7, v17, v3
	cmhs.2d	v3, v5, v3
	uzp1.4s	v3, v3, v7
	uzp1.8h	v3, v3, v6
	xtn.8b	v3, v3
	and.8b	v28, v24, v3
	shl.8b	v3, v28, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_405
; %bb.401:                              ; %varying.divergent281
                                        ;   in Loop: Header=BB0_10 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	ldr	q16, [sp, #1088]                ; 16-byte Folded Reload
	str	q16, [sp, #2720]
	ldr	q7, [sp, #1104]                 ; 16-byte Folded Reload
	str	q7, [sp, #2736]
	and	x1, x1, #0x7
	add	x3, sp, #2720
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #8, #0, ne
	cset	w1, ne
	cmp	w2, #255
	ldr	q8, [sp, #608]                  ; 16-byte Folded Reload
	ldr	q15, [sp, #1008]                ; 16-byte Folded Reload
	ldp	q22, q17, [sp, #752]            ; 32-byte Folded Reload
	ldr	q14, [sp, #704]                 ; 16-byte Folded Reload
	ldr	q30, [sp, #800]                 ; 16-byte Folded Reload
	mov.16b	v31, v13
	b.ne	LBB0_403
; %bb.402:                              ; %varying.divergent281
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #0, LBB0_746
LBB0_403:                               ; %convergence.overflow.resume284
                                        ;   in Loop: Header=BB0_10 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #7, lsl #12             ; =28672
	add	x2, x2, #2800
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s3, w4
	ubfx	w4, w5, #1, #1
	mov.b	v3[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v3[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v3[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v3[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v3[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v3[6], w4
	add	x4, sp, #7, lsl #12             ; =28672
	add	x4, x4, #2792
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s5, w6
	ubfx	w6, w5, #1, #1
	mov.b	v5[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v5[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v5[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v5[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v5[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v5[6], w6
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v6, w5
	bit.8b	v3, v24, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x2, w3, uxtw]
	bic.8b	v3, v5, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	ldr	q19, [sp, #992]                 ; 16-byte Folded Reload
	ldr	q4, [sp, #784]                  ; 16-byte Folded Reload
	ldr	q24, [sp, #1040]                ; 16-byte Folded Reload
	ldr	q29, [sp, #864]                 ; 16-byte Folded Reload
	ldr	q18, [sp, #912]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	ldr	q6, [sp, #720]                  ; 16-byte Folded Reload
	b.hs	LBB0_746
; %bb.404:                              ; %ready.overflow.resume286
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v13, v26
	zip2.8b	v3, v28, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldr	q5, [sp, #336]                  ; 16-byte Folded Reload
	and.16b	v1, v3, v5
	zip1.8b	v3, v28, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldr	q5, [sp, #352]                  ; 16-byte Folded Reload
	and.16b	v5, v3, v5
	stp	q1, q5, [sp, #336]              ; 32-byte Folded Spill
	str	q6, [sp, #2688]
	str	q0, [sp, #2704]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #2688
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q6, [sp, #2656]
	str	q0, [sp, #2672]
	add	x5, sp, #2656
	str	w4, [x5, x2]
	ldr	q0, [sp, #2672]
	str	q0, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q25, [sp, #2656]
	str	q16, [sp, #2624]
	str	q7, [sp, #2640]
	add	x4, sp, #2624
	ldr	w4, [x4, x2]
	mov	w5, #8                          ; =0x8
	csel	w4, w5, w4, ne
	str	q16, [sp, #2592]
	str	q7, [sp, #2608]
	add	x5, sp, #2592
	str	w4, [x5, x2]
	mov	w2, #21                         ; =0x15
	mov	w4, #20                         ; =0x14
	ldr	q0, [sp, #2608]
	str	q0, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #2592]
	str	q0, [sp, #1088]                 ; 16-byte Folded Spill
                                        ; kill: def $w3 killed $w3 killed $x3 def $x3
	ldr	q26, [sp, #816]                 ; 16-byte Folded Reload
	ldr	q12, [sp, #848]                 ; 16-byte Folded Reload
	ldr	q1, [sp, #960]                  ; 16-byte Folded Reload
	ldr	q9, [sp, #688]                  ; 16-byte Folded Reload
	stp	q19, q15, [sp, #992]            ; 32-byte Folded Spill
	str	q1, [sp, #960]                  ; 16-byte Folded Spill
	mov.16b	v15, v4
	str	q24, [sp, #1040]                ; 16-byte Folded Spill
	mov.16b	v4, v8
	mov.16b	v8, v17
	mov.16b	v19, v31
	mov.16b	v31, v18
	b	LBB0_9
LBB0_405:                               ; %varying.coherent282
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	ldr	q19, [sp, #1008]                ; 16-byte Folded Reload
	ldr	q1, [sp, #704]                  ; 16-byte Folded Reload
	ldr	q30, [sp, #800]                 ; 16-byte Folded Reload
	ldr	q29, [sp, #768]                 ; 16-byte Folded Reload
	str	q19, [sp, #1008]                ; 16-byte Folded Spill
	b.eq	LBB0_425
; %bb.406:                              ; %varying.coherent.true287
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v9, v30
	mov.16b	v30, v13
	ldr	q4, [sp, #992]                  ; 16-byte Folded Reload
	ldr	q15, [sp, #784]                 ; 16-byte Folded Reload
	ldr	q22, [sp, #864]                 ; 16-byte Folded Reload
	ldr	q31, [sp, #912]                 ; 16-byte Folded Reload
	ldr	q23, [sp, #1072]                ; 16-byte Folded Reload
	mov.16b	v8, v26
	str	q4, [sp, #992]                  ; 16-byte Folded Spill
	str	q23, [sp, #1072]                ; 16-byte Folded Spill
	tbnz	w1, #0, LBB0_729
; %bb.407:                              ; %schedule.20.thread
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q3, [sp, #5760]
	ldr	q5, [sp, #5776]
	ldr	q6, [sp, #5792]
	ldr	q7, [sp, #5808]
	ldr	q16, [sp, #5872]
	ldr	q17, [sp, #5856]
	ldr	q18, [sp, #5840]
	ldr	q21, [sp, #5824]
	ldr	q20, [sp, #5376]
	ldr	q25, [sp, #5392]
	ldr	q26, [sp, #5408]
	ldr	q27, [sp, #5424]
	shl.2d	v27, v27, #5
	shl.2d	v26, v26, #5
	shl.2d	v25, v25, #5
	shl.2d	v28, v20, #5
	add.2d	v7, v7, v16
	add.2d	v16, v7, v27
	add.2d	v6, v6, v17
	add.2d	v17, v6, v26
	add.2d	v5, v5, v18
	add.2d	v20, v5, v25
	add.2d	v3, v3, v21
	add.2d	v21, v3, v28
	fmov	w1, s14
	movi.2d	v3, #0000000000000000
	movi.2d	v5, #0000000000000000
	ldr	q27, [sp, #816]                 ; 16-byte Folded Reload
	ldr	q25, [sp, #720]                 ; 16-byte Folded Reload
	ldr	q26, [sp, #896]                 ; 16-byte Folded Reload
	ldr	q12, [sp, #944]                 ; 16-byte Folded Reload
	tbnz	w1, #0, LBB0_459
; %bb.408:                              ; %else3516
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q7, [sp, #880]                  ; 16-byte Folded Reload
	tbnz	w1, #1, LBB0_460
LBB0_409:                               ; %else3522
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q0, [sp, #848]                  ; 16-byte Folded Reload
	ldp	q14, q18, [sp, #960]            ; 32-byte Folded Reload
	ldr	q6, [sp, #688]                  ; 16-byte Folded Reload
	ldr	q28, [sp, #928]                 ; 16-byte Folded Reload
	tbnz	w1, #2, LBB0_461
LBB0_410:                               ; %else3528
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q13, [sp, #1024]                ; 16-byte Folded Reload
	str	q28, [sp, #928]                 ; 16-byte Folded Spill
	str	q14, [sp, #960]                 ; 16-byte Folded Spill
	tbnz	w1, #3, LBB0_462
LBB0_411:                               ; %else3534
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v28, v9
	mov.16b	v20, v22
	mov.16b	v14, v1
	str	q13, [sp, #1024]                ; 16-byte Folded Spill
	str	q7, [sp, #880]                  ; 16-byte Folded Spill
	tbz	w1, #4, LBB0_413
LBB0_412:                               ; %cond.load3536
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d17
	ld1.s	{ v5 }[0], [x2]
LBB0_413:                               ; %else3540
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q22, [sp, #752]                 ; 16-byte Folded Reload
	mov.16b	v19, v30
	ldr	q4, [sp, #608]                  ; 16-byte Folded Reload
	mov.16b	v9, v6
	str	q18, [sp, #976]                 ; 16-byte Folded Spill
	str	q26, [sp, #896]                 ; 16-byte Folded Spill
	str	q12, [sp, #944]                 ; 16-byte Folded Spill
	mov.16b	v13, v8
	mov.16b	v30, v28
	tbnz	w1, #5, LBB0_463
; %bb.414:                              ; %else3546
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v26, v27
	mov.16b	v8, v29
	mov.16b	v12, v0
	mov.16b	v29, v20
	tbnz	w1, #6, LBB0_464
LBB0_415:                               ; %else3552
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbz	w1, #7, LBB0_417
LBB0_416:                               ; %cond.load3554
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x1, v16[1]
	ld1.s	{ v5 }[3], [x1]
LBB0_417:                               ; %else3558
                                        ;   in Loop: Header=BB0_10 Depth=3
	zip2.8b	v6, v24, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	ldr	q7, [sp, #336]                  ; 16-byte Folded Reload
	bit.16b	v7, v5, v6
	zip1.8b	v5, v24, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q6, [sp, #352]                  ; 16-byte Folded Reload
	bit.16b	v6, v3, v5
	stp	q7, q6, [sp, #336]              ; 32-byte Folded Spill
	b	LBB0_426
LBB0_418:                               ; %cond.load2899
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x7, d12
	ldr	s3, [x7]
	tbz	w6, #1, LBB0_392
LBB0_419:                               ; %cond.load2905
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x7, v12[1]
	ld1.s	{ v3 }[1], [x7]
	tbz	w6, #2, LBB0_393
LBB0_420:                               ; %cond.load2911
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x7, d11
	ld1.s	{ v3 }[2], [x7]
	ldr	q26, [sp, #736]                 ; 16-byte Folded Reload
	tbz	w6, #3, LBB0_394
LBB0_421:                               ; %cond.load2917
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x7, v11[1]
	ld1.s	{ v3 }[3], [x7]
	tbz	w6, #4, LBB0_395
LBB0_422:                               ; %cond.load2923
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x7, d17
	ld1.s	{ v16 }[0], [x7]
	tbz	w6, #5, LBB0_396
LBB0_423:                               ; %cond.load2929
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x7, v17[1]
	ld1.s	{ v16 }[1], [x7]
	tbz	w6, #6, LBB0_397
LBB0_424:                               ; %cond.load2935
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x7, d5
	ld1.s	{ v16 }[2], [x7]
	tbnz	w6, #7, LBB0_398
	b	LBB0_399
LBB0_425:                               ; %varying.coherent.false288
                                        ;   in Loop: Header=BB0_10 Depth=3
	zip2.8b	v3, v24, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldp	q6, q5, [sp, #336]              ; 32-byte Folded Reload
	and.16b	v4, v3, v6
	zip1.8b	v3, v24, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v5, v3, v5
	stp	q4, q5, [sp, #336]              ; 32-byte Folded Spill
	ldr	q15, [sp, #784]                 ; 16-byte Folded Reload
	ldr	q7, [sp, #816]                  ; 16-byte Folded Reload
	ldp	q12, q20, [sp, #848]            ; 32-byte Folded Reload
	ldr	q31, [sp, #912]                 ; 16-byte Folded Reload
	ldr	q25, [sp, #720]                 ; 16-byte Folded Reload
	mov.16b	v22, v26
	ldr	q9, [sp, #688]                  ; 16-byte Folded Reload
	mov.16b	v8, v29
	mov.16b	v29, v20
	mov.16b	v19, v13
	mov.16b	v14, v1
	mov.16b	v26, v7
	mov.16b	v13, v22
	ldr	q22, [sp, #752]                 ; 16-byte Folded Reload
	ldr	q4, [sp, #608]                  ; 16-byte Folded Reload
	tbnz	w1, #0, LBB0_5
LBB0_426:                               ; %schedule.21
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v6, v12
	ldp	q12, q23, [sp, #944]            ; 32-byte Folded Reload
	stp	q8, q15, [sp, #768]             ; 32-byte Folded Spill
	mov.16b	v0, v30
	mov.16b	v30, v22
	stp	q6, q29, [sp, #848]             ; 32-byte Folded Spill
	str	q13, [sp, #736]                 ; 16-byte Folded Spill
	stp	q0, q26, [sp, #800]             ; 32-byte Folded Spill
	str	q19, [sp, #592]                 ; 16-byte Folded Spill
	mov.16b	v7, v9
	mov.16b	v9, v14
	str	q31, [sp, #912]                 ; 16-byte Folded Spill
	str	q7, [sp, #688]                  ; 16-byte Folded Spill
	str	q12, [sp, #944]                 ; 16-byte Folded Spill
	cbz	w0, LBB0_431
; %bb.427:                              ; %convergence.cascade291.preheader
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov	w1, #0                          ; =0x0
LBB0_428:                               ; %convergence.cascade291
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_10 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v5, v3, v2
	addv.8b	b5, v5
	fmov	w2, s5
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #2784]
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	str	q0, [sp, #2800]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #2784
	ldr	w6, [x6, x2]
	cmp	w6, #8
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #7, lsl #12             ; =28672
	add	x5, x5, #2800
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s3, w19
	ubfx	w19, w20, #1, #1
	mov.b	v3[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v3[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v3[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v3[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v3[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v3[6], w19
	add	x19, sp, #7, lsl #12            ; =28672
	add	x19, x19, #2792
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s5, w21
	ubfx	w21, w20, #1, #1
	mov.b	v5[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v5[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v5[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v5[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v5[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v5[6], w21
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	orr.8b	v6, v24, v5
	ldr	d0, [sp, #1064]                 ; 8-byte Folded Reload
	and.8b	v7, v0, v3
	eor.8b	v7, v7, v6
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v6, v7
	dup.8b	v17, w7
	bit.8b	v5, v16, v17
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x19, w3, sxtw]
	bic.8b	v3, v3, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v5, v5, v6
	str	q25, [sp, #2752]
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	str	q0, [sp, #2768]
	add	x3, sp, #2752
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v24, v5, v3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_432
; %bb.429:                              ; %convergence.cascade291
                                        ;   in Loop: Header=BB0_428 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_432
; %bb.430:                              ; %convergence.cascade291
                                        ;   in Loop: Header=BB0_428 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_428
	b	LBB0_432
LBB0_431:                               ; %schedule.21.convergence.cascade.exit292_crit_edge
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_432:                               ; %convergence.cascade.exit292
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_717
; %bb.433:                              ; %convergence.target.21.ready
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v0, v25
	ldrb	w1, [x9, #256]
	lsr	w2, w1, #7
	ubfx	w3, w1, #6, #1
	ubfx	w4, w1, #5, #1
	ubfx	w5, w1, #4, #1
	ubfx	w6, w1, #3, #1
	ubfx	w7, w1, #2, #1
	ubfx	w19, w1, #1, #1
	and	w1, w1, #0x1
	fmov	s3, w1
	mov.h	v3[1], w19
	mov.h	v3[2], w7
	mov.h	v3[3], w6
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	fmov	s5, w5
	mov.h	v5[1], w4
	mov.h	v5[2], w3
	ldr	q6, [sp, #352]                  ; 16-byte Folded Reload
	and.16b	v6, v3, v6
	mov.h	v5[3], w2
	ushll.4s	v3, v5, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q5, [sp, #336]                  ; 16-byte Folded Reload
	and.16b	v3, v3, v5
	ldr	q5, [sp, #5472]
	ldr	q7, [sp, #5488]
	fadd.4s	v3, v7, v3
	fadd.4s	v16, v5, v6
	ldr	q5, [sp, #5552]
	ldr	q6, [sp, #5536]
	ldr	q7, [sp, #5504]
	ldr	q17, [sp, #5520]
	ldr	q18, [sp, #5584]
	ldr	q19, [sp, #5568]
	ldr	q20, [sp, #5600]
	ldr	q21, [sp, #5616]
	shl.2d	v25, v9, #5
	ldp	q22, q26, [sp, #640]            ; 32-byte Folded Reload
	shl.2d	v26, v26, #5
	shl.2d	v27, v22, #5
	shl.2d	v28, v23, #5
	add.2d	v21, v21, v28
	add.2d	v27, v20, v27
	add.2d	v20, v19, v26
	add.2d	v18, v18, v25
	add.2d	v19, v17, v18
	add.2d	v20, v7, v20
	add.2d	v17, v6, v27
	add.2d	v5, v5, v21
	shl.8b	v6, v24, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	fmov	w1, s6
	tbnz	w1, #0, LBB0_443
; %bb.434:                              ; %else3564
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #1, LBB0_444
LBB0_435:                               ; %else3568
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v25, v0
	tbnz	w1, #2, LBB0_445
LBB0_436:                               ; %else3572
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #3, LBB0_446
LBB0_437:                               ; %else3576
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q29, [sp, #864]                 ; 16-byte Folded Reload
	ldr	q8, [sp, #768]                  ; 16-byte Folded Reload
	mov.16b	v22, v30
	tbnz	w1, #4, LBB0_447
LBB0_438:                               ; %else3580
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q21, [sp, #1024]                ; 16-byte Folded Reload
	ldr	q7, [sp, #592]                  ; 16-byte Folded Reload
	ldr	q19, [sp, #992]                 ; 16-byte Folded Reload
	ldp	q30, q26, [sp, #800]            ; 32-byte Folded Reload
	tbnz	w1, #5, LBB0_448
LBB0_439:                               ; %else3584
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q17, [sp, #832]                 ; 16-byte Folded Reload
	ldr	q15, [sp, #784]                 ; 16-byte Folded Reload
	ldr	q31, [sp, #912]                 ; 16-byte Folded Reload
	mov.16b	v14, v9
	tbnz	w1, #6, LBB0_449
LBB0_440:                               ; %else3588
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q9, [sp, #688]                  ; 16-byte Folded Reload
	tbz	w1, #7, LBB0_442
LBB0_441:                               ; %cond.store3589
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x1, v5[1]
	st1.s	{ v3 }[3], [x1]
LBB0_442:                               ; %else3592
                                        ;   in Loop: Header=BB0_10 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v24, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v5, v3, #0
	ushll2.4s	v3, v3, #0
	uaddw2.2d	v1, v23, v3
	str	q1, [sp, #960]                  ; 16-byte Folded Spill
	ldr	q6, [sp, #640]                  ; 16-byte Folded Reload
	uaddw.2d	v6, v6, v3
	uaddw2.2d	v14, v14, v5
	ldr	q3, [sp, #656]                  ; 16-byte Folded Reload
	uaddw.2d	v3, v3, v5
	stp	q6, q3, [sp, #640]              ; 32-byte Folded Spill
	ldr	q12, [sp, #848]                 ; 16-byte Folded Reload
	ldr	q13, [sp, #736]                 ; 16-byte Folded Reload
	str	q19, [sp, #992]                 ; 16-byte Folded Spill
	str	q17, [sp, #832]                 ; 16-byte Folded Spill
	str	q21, [sp, #1024]                ; 16-byte Folded Spill
	mov.16b	v19, v7
	b	LBB0_382
LBB0_443:                               ; %cond.store3561
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d20
	str	s16, [x2]
	tbz	w1, #1, LBB0_435
LBB0_444:                               ; %cond.store3565
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v20[1]
	st1.s	{ v16 }[1], [x2]
	mov.16b	v25, v0
	tbz	w1, #2, LBB0_436
LBB0_445:                               ; %cond.store3569
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d19
	st1.s	{ v16 }[2], [x2]
	tbz	w1, #3, LBB0_437
LBB0_446:                               ; %cond.store3573
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v19[1]
	st1.s	{ v16 }[3], [x2]
	ldr	q29, [sp, #864]                 ; 16-byte Folded Reload
	ldr	q8, [sp, #768]                  ; 16-byte Folded Reload
	mov.16b	v22, v30
	tbz	w1, #4, LBB0_438
LBB0_447:                               ; %cond.store3577
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d17
	str	s3, [x2]
	ldr	q21, [sp, #1024]                ; 16-byte Folded Reload
	ldr	q7, [sp, #592]                  ; 16-byte Folded Reload
	ldr	q19, [sp, #992]                 ; 16-byte Folded Reload
	ldp	q30, q26, [sp, #800]            ; 32-byte Folded Reload
	tbz	w1, #5, LBB0_439
LBB0_448:                               ; %cond.store3581
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v17[1]
	st1.s	{ v3 }[1], [x2]
	ldr	q17, [sp, #832]                 ; 16-byte Folded Reload
	ldr	q15, [sp, #784]                 ; 16-byte Folded Reload
	ldr	q31, [sp, #912]                 ; 16-byte Folded Reload
	mov.16b	v14, v9
	tbz	w1, #6, LBB0_440
LBB0_449:                               ; %cond.store3585
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d5
	st1.s	{ v3 }[2], [x2]
	ldr	q9, [sp, #688]                  ; 16-byte Folded Reload
	tbnz	w1, #7, LBB0_441
	b	LBB0_442
LBB0_450:                               ; %varying.coherent.false277
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_5
LBB0_451:                               ; %schedule.22
                                        ;   in Loop: Header=BB0_10 Depth=3
	cbz	w0, LBB0_456
; %bb.452:                              ; %convergence.cascade317.preheader
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov	w1, #0                          ; =0x0
LBB0_453:                               ; %convergence.cascade317
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_10 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v5, v3, v2
	addv.8b	b5, v5
	fmov	w2, s5
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #4256]
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	str	q0, [sp, #4272]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #1, lsl #12             ; =4096
	add	x6, x6, #160
	ldr	w6, [x6, x2]
	cmp	w6, #7
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #7, lsl #12             ; =28672
	add	x5, x5, #2800
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s3, w19
	ubfx	w19, w20, #1, #1
	mov.b	v3[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v3[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v3[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v3[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v3[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v3[6], w19
	add	x19, sp, #7, lsl #12            ; =28672
	add	x19, x19, #2792
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s5, w21
	ubfx	w21, w20, #1, #1
	mov.b	v5[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v5[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v5[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v5[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v5[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v5[6], w21
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	orr.8b	v6, v24, v5
	ldr	d0, [sp, #1064]                 ; 8-byte Folded Reload
	and.8b	v7, v0, v3
	eor.8b	v7, v7, v6
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v6, v7
	dup.8b	v17, w7
	bit.8b	v5, v16, v17
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x19, w3, sxtw]
	bic.8b	v3, v3, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v5, v5, v6
	str	q25, [sp, #4224]
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	str	q0, [sp, #4240]
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #128
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v24, v5, v3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_457
; %bb.454:                              ; %convergence.cascade317
                                        ;   in Loop: Header=BB0_453 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_457
; %bb.455:                              ; %convergence.cascade317
                                        ;   in Loop: Header=BB0_453 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_453
	b	LBB0_457
LBB0_456:                               ; %schedule.22.convergence.cascade.exit318_crit_edge
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_457:                               ; %convergence.cascade.exit318
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_5
; %bb.458:                              ; %convergence.target.22.ready
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q17, [sp, #5344]
	ldr	q5, [sp, #5360]
	ldr	q3, [sp, #5312]
	ldr	q6, [sp, #5328]
	ldr	q16, [sp, #5280]
	ldr	q7, [sp, #5296]
	ldr	q18, [sp, #5248]
	ldr	q20, [sp, #5264]
	mov.16b	v11, v8
	mov.16b	v8, v29
	mov.16b	v29, v4
	mov.16b	v4, v31
	mov.16b	v31, v15
	mov.16b	v15, v12
	mov.16b	v12, v14
	mov.16b	v14, v13
	mov.16b	v13, v9
	mov.16b	v9, v30
	mov.16b	v30, v19
	mov	b19, v24[2]
	mov.b	v19[4], v24[3]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	ldr	q28, [sp, #144]                 ; 16-byte Folded Reload
	bit.16b	v20, v28, v19
	mov	b21, v24[0]
	mov.b	v21[4], v24[1]
	ushll.2d	v21, v21, #0
	shl.2d	v21, v21, #63
	cmlt.2d	v21, v21, #0
	mov.16b	v0, v25
	mov	b25, v24[6]
	mov.b	v25[4], v24[7]
	bit.16b	v18, v28, v21
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	bit.16b	v7, v28, v25
	mov.16b	v1, v26
	mov	b26, v24[4]
	mov.b	v26[4], v24[5]
	ushll.2d	v26, v26, #0
	shl.2d	v26, v26, #63
	cmlt.2d	v26, v26, #0
Lloh66:
	adrp	x1, lCPI0_17@PAGE
Lloh67:
	ldr	q27, [x1, lCPI0_17@PAGEOFF]
	bit.16b	v6, v27, v19
Lloh68:
	adrp	x1, lCPI0_18@PAGE
Lloh69:
	ldr	q27, [x1, lCPI0_18@PAGEOFF]
	bit.16b	v17, v27, v26
Lloh70:
	adrp	x1, lCPI0_16@PAGE
Lloh71:
	ldr	q27, [x1, lCPI0_16@PAGEOFF]
	str	q17, [sp, #5344]
Lloh72:
	adrp	x1, lCPI0_19@PAGE
Lloh73:
	ldr	q17, [x1, lCPI0_19@PAGEOFF]
	bit.16b	v16, v28, v26
	bit.16b	v5, v17, v25
	str	q5, [sp, #5360]
	bit.16b	v3, v27, v21
	str	q3, [sp, #5312]
	str	q6, [sp, #5328]
	str	q16, [sp, #5280]
	str	q7, [sp, #5296]
	str	q18, [sp, #5248]
	str	q20, [sp, #5264]
	ldr	q3, [sp, #672]                  ; 16-byte Folded Reload
	bic.16b	v3, v3, v25
	mov.16b	v25, v0
	str	q3, [sp, #672]                  ; 16-byte Folded Spill
	bic.16b	v14, v14, v26
	mov.16b	v26, v1
	ldr	q0, [sp, #976]                  ; 16-byte Folded Reload
	bic.16b	v0, v0, v19
	mov.16b	v19, v30
	mov.16b	v30, v9
	mov.16b	v9, v13
	mov.16b	v13, v14
	mov.16b	v14, v12
	mov.16b	v12, v15
	mov.16b	v15, v31
	mov.16b	v31, v4
	mov.16b	v4, v29
	mov.16b	v29, v8
	mov.16b	v8, v11
	str	q0, [sp, #976]                  ; 16-byte Folded Spill
	ldr	q0, [sp, #624]                  ; 16-byte Folded Reload
	bic.16b	v0, v0, v21
	b	LBB0_465
LBB0_459:                               ; %cond.load3512
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d21
	ldr	s3, [x2]
	ldr	q7, [sp, #880]                  ; 16-byte Folded Reload
	tbz	w1, #1, LBB0_409
LBB0_460:                               ; %cond.load3518
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v21[1]
	ld1.s	{ v3 }[1], [x2]
	ldr	q0, [sp, #848]                  ; 16-byte Folded Reload
	ldp	q14, q18, [sp, #960]            ; 32-byte Folded Reload
	ldr	q6, [sp, #688]                  ; 16-byte Folded Reload
	ldr	q28, [sp, #928]                 ; 16-byte Folded Reload
	tbz	w1, #2, LBB0_410
LBB0_461:                               ; %cond.load3524
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d20
	ld1.s	{ v3 }[2], [x2]
	ldr	q13, [sp, #1024]                ; 16-byte Folded Reload
	str	q28, [sp, #928]                 ; 16-byte Folded Spill
	str	q14, [sp, #960]                 ; 16-byte Folded Spill
	tbz	w1, #3, LBB0_411
LBB0_462:                               ; %cond.load3530
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v20[1]
	ld1.s	{ v3 }[3], [x2]
	mov.16b	v28, v9
	mov.16b	v20, v22
	mov.16b	v14, v1
	str	q13, [sp, #1024]                ; 16-byte Folded Spill
	str	q7, [sp, #880]                  ; 16-byte Folded Spill
	tbnz	w1, #4, LBB0_412
	b	LBB0_413
LBB0_463:                               ; %cond.load3542
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v17[1]
	ld1.s	{ v5 }[1], [x2]
	mov.16b	v26, v27
	mov.16b	v8, v29
	mov.16b	v12, v0
	mov.16b	v29, v20
	tbz	w1, #6, LBB0_415
LBB0_464:                               ; %cond.load3548
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d16
	ld1.s	{ v5 }[2], [x2]
	tbnz	w1, #7, LBB0_416
	b	LBB0_417
LBB0_465:                               ; %schedule.23
                                        ;   in Loop: Header=BB0_10 Depth=3
	str	q0, [sp, #624]                  ; 16-byte Folded Spill
LBB0_466:                               ; %schedule.23
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	mov	w1, #128                        ; =0x80
	dup.2d	v3, x1
	ldr	q0, [sp, #976]                  ; 16-byte Folded Reload
	cmgt.2d	v5, v3, v0
	ldr	q0, [sp, #624]                  ; 16-byte Folded Reload
	cmgt.2d	v6, v3, v0
	uzp1.4s	v5, v6, v5
	cmgt.2d	v6, v3, v13
	ldr	q7, [sp, #672]                  ; 16-byte Folded Reload
	cmgt.2d	v7, v3, v7
	uzp1.4s	v6, v6, v7
	uzp1.8h	v5, v5, v6
	xtn.8b	v5, v5
	and.8b	v27, v24, v5
	shl.8b	v5, v27, #7
	cmlt.8b	v5, v5, #0
	and.8b	v6, v5, v2
	addv.8b	b6, v6
	fmov	w1, s6
	umaxv.8b	b5, v5
	fmov	w3, s5
	tbz	w3, #0, LBB0_472
; %bb.467:                              ; %schedule.23
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q0, [sp, #976]                  ; 16-byte Folded Reload
	cmge.2d	v5, v0, v3
	ldr	q0, [sp, #624]                  ; 16-byte Folded Reload
	cmge.2d	v6, v0, v3
	uzp1.4s	v5, v6, v5
	cmge.2d	v6, v13, v3
	ldr	q7, [sp, #672]                  ; 16-byte Folded Reload
	cmge.2d	v3, v7, v3
	uzp1.4s	v3, v6, v3
	uzp1.8h	v3, v5, v3
	xtn.8b	v3, v3
	and.8b	v28, v24, v3
	shl.8b	v3, v28, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_472
; %bb.468:                              ; %varying.divergent335
                                        ;   in Loop: Header=BB0_10 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #2944]
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	str	q0, [sp, #2960]
	and	x1, x1, #0x7
	add	x3, sp, #2944
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #9, #0, ne
	cset	w1, ne
	cmp	w2, #255
	b.ne	LBB0_470
; %bb.469:                              ; %varying.divergent335
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #0, LBB0_746
LBB0_470:                               ; %convergence.overflow.resume338
                                        ;   in Loop: Header=BB0_10 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #7, lsl #12             ; =28672
	add	x2, x2, #2800
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s3, w4
	ubfx	w4, w5, #1, #1
	mov.b	v3[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v3[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v3[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v3[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v3[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v3[6], w4
	add	x4, sp, #7, lsl #12             ; =28672
	add	x4, x4, #2792
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s5, w6
	ubfx	w6, w5, #1, #1
	mov.b	v5[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v5[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v5[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v5[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v5[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v5[6], w6
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v6, w5
	bit.8b	v3, v24, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x2, w3, uxtw]
	bic.8b	v3, v5, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_746
; %bb.471:                              ; %ready.overflow.resume340
                                        ;   in Loop: Header=BB0_10 Depth=3
	str	q25, [sp, #2912]
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	str	q0, [sp, #2928]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #2912
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q25, [sp, #2880]
	str	q0, [sp, #2896]
	add	x5, sp, #2880
	str	w4, [x5, x2]
	ldr	q0, [sp, #2896]
	str	q0, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q25, [sp, #2880]
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #2848]
	ldr	q1, [sp, #1104]                 ; 16-byte Folded Reload
	str	q1, [sp, #2864]
	add	x4, sp, #2848
	ldr	w4, [x4, x2]
	mov	w5, #9                          ; =0x9
	csel	w4, w5, w4, ne
	str	q0, [sp, #2816]
	str	q1, [sp, #2832]
	add	x5, sp, #2816
	str	w4, [x5, x2]
	mov	w2, #27                         ; =0x1b
	mov	w4, #24                         ; =0x18
	ldr	q0, [sp, #2832]
	str	q0, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #2816]
	str	q0, [sp, #1088]                 ; 16-byte Folded Spill
                                        ; kill: def $w3 killed $w3 killed $x3 def $x3
	b	LBB0_9
LBB0_472:                               ; %varying.coherent336
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w1, #0xff
	b.eq	LBB0_535
; %bb.473:                              ; %varying.coherent.true341
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov	w1, #0                          ; =0x0
	tst	w2, #0xff
	b.eq	LBB0_5
LBB0_474:                               ; %schedule.24
                                        ;   in Loop: Header=BB0_10 Depth=3
	stp	q14, q25, [sp, #704]            ; 32-byte Folded Spill
	mov.16b	v7, v4
	str	q31, [sp, #912]                 ; 16-byte Folded Spill
	stp	q8, q15, [sp, #768]             ; 32-byte Folded Spill
	stp	q12, q29, [sp, #848]            ; 32-byte Folded Spill
	stp	q30, q26, [sp, #800]            ; 32-byte Folded Spill
	ldr	q4, [sp, #832]                  ; 16-byte Folded Reload
	ldr	q31, [sp, #896]                 ; 16-byte Folded Reload
	str	q9, [sp, #688]                  ; 16-byte Folded Spill
	str	q22, [sp, #752]                 ; 16-byte Folded Spill
	str	q7, [sp, #608]                  ; 16-byte Folded Spill
	ldr	q20, [sp, #624]                 ; 16-byte Folded Reload
	ldr	q17, [sp, #976]                 ; 16-byte Folded Reload
	mov.16b	v27, v19
	mov	b3, v24[6]
	mov.b	v3[4], v24[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v6, v3, #0
	ldr	q3, [sp, #672]                  ; 16-byte Folded Reload
	and.16b	v3, v6, v3
	mov	b5, v24[4]
	mov.b	v5[4], v24[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v7, v5, #0
	mov.16b	v1, v13
	and.16b	v5, v7, v13
	mov	b16, v24[2]
	mov.b	v16[4], v24[3]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v18, v16, #0
	and.16b	v16, v18, v17
	mov	b17, v24[0]
	mov.b	v17[4], v24[1]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v19, v17, #0
	and.16b	v21, v19, v20
	shl.8b	v17, v24, #7
	cmlt.8b	v13, v17, #0
	and.8b	v17, v13, v2
	mov	w2, #32                         ; =0x20
	dup.2d	v20, x2
	and.16b	v25, v6, v20
	mvn.16b	v6, v6
	sub.2d	v29, v25, v6
	and.16b	v6, v7, v20
	mvn.16b	v7, v7
	sub.2d	v30, v6, v7
	and.16b	v6, v18, v20
	mvn.16b	v7, v18
	and.16b	v18, v19, v20
	mvn.16b	v19, v19
	sub.2d	v28, v18, v19
	mov.d	x2, v28[1]
	mov.d	x3, v21[1]
	sdiv	x6, x3, x2
	sub.2d	v20, v6, v7
	fmov	x3, d28
	fmov	x4, d21
	sdiv	x4, x4, x3
	mul	x7, x4, x3
	fmov	d6, x4
	mov.d	v6[1], x6
	mov.d	x3, v20[1]
	mov.d	x4, v16[1]
	sdiv	x19, x4, x3
	fmov	x4, d20
	fmov	x5, d16
	sdiv	x5, x5, x4
	mul	x20, x5, x4
	fmov	d7, x5
	mov.d	v7[1], x19
	mov.d	x4, v30[1]
	mov.d	x5, v5[1]
	sdiv	x21, x5, x4
	fmov	x5, d30
	fmov	x22, d5
	sdiv	x22, x22, x5
	mul	x23, x22, x5
	fmov	d18, x22
	mov.d	v18[1], x21
	mov.d	x5, v29[1]
	mov.d	x22, v3[1]
	fmov	x24, d29
	fmov	x25, d3
	sdiv	x25, x25, x24
	mul	x24, x25, x24
	fmov	d25, x25
	sdiv	x22, x22, x5
	mov.d	v25[1], x22
	mul	x6, x6, x2
	fmov	d26, x7
	mov.d	v26[1], x6
	mul	x6, x19, x3
	fmov	d8, x20
	mov.d	v8[1], x6
	mul	x6, x21, x4
	fmov	d9, x23
	mov.d	v9[1], x6
	mul	x6, x22, x5
	fmov	d10, x24
	mov.d	v10[1], x6
	addv.8b	b0, v17
	sub.2d	v3, v3, v10
	sub.2d	v5, v5, v9
	str	d0, [sp, #736]                  ; 8-byte Folded Spill
	fmov	w6, s0
	sub.2d	v16, v16, v8
	sub.2d	v17, v21, v26
	shl.2d	v25, v25, #5
	shl.2d	v18, v18, #5
	shl.2d	v7, v7, #5
	shl.2d	v6, v6, #5
	add.2d	v10, v6, v17
	add.2d	v8, v7, v16
	add.2d	v21, v18, v5
	add.2d	v9, v25, v3
	ldr	q3, [sp, #5504]
	ldr	q6, [sp, #5520]
	ldr	q7, [sp, #5536]
	ldr	q5, [sp, #5552]
	ldr	q16, [sp, #5616]
	ldr	q17, [sp, #5600]
	ldr	q18, [sp, #5584]
	shl.2d	v25, v9, #5
	shl.2d	v26, v21, #5
	ldr	q12, [sp, #5568]
	shl.2d	v11, v8, #5
	shl.2d	v15, v10, #5
	add.2d	v5, v5, v16
	add.2d	v5, v5, v25
	add.2d	v7, v7, v17
	add.2d	v17, v7, v26
	add.2d	v6, v6, v18
	add.2d	v11, v6, v11
	add.2d	v3, v3, v12
	add.2d	v12, v3, v15
	movi.2d	v3, #0000000000000000
	movi.2d	v16, #0000000000000000
	str	q31, [sp, #896]                 ; 16-byte Folded Spill
	str	q4, [sp, #832]                  ; 16-byte Folded Spill
	tbnz	w6, #0, LBB0_503
; %bb.475:                              ; %else3001
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w6, #1, LBB0_504
LBB0_476:                               ; %else3007
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v26, v27
	ldr	q6, [sp, #880]                  ; 16-byte Folded Reload
	tbnz	w6, #2, LBB0_505
LBB0_477:                               ; %else3013
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q19, [sp, #928]                 ; 16-byte Folded Reload
	str	q6, [sp, #880]                  ; 16-byte Folded Spill
	tbnz	w6, #3, LBB0_506
LBB0_478:                               ; %else3019
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w6, #4, LBB0_507
LBB0_479:                               ; %else3025
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w6, #5, LBB0_508
LBB0_480:                               ; %else3031
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w6, #6, LBB0_509
LBB0_481:                               ; %else3037
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbz	w6, #7, LBB0_483
LBB0_482:                               ; %cond.load3039
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x6, v5[1]
	ld1.s	{ v16 }[3], [x6]
LBB0_483:                               ; %else3043
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q6, [sp, #5232]
	ldr	q5, [sp, #5216]
	zip1.8b	v7, v24, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	bit.16b	v5, v3, v7
	zip2.8b	v3, v24, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bsl.16b	v3, v16, v6
	mov	b6, v24[2]
	mov.b	v6[4], v24[3]
	str	q3, [sp, #5232]
	ushll.2d	v3, v6, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	and.16b	v16, v3, v8
	mov	b6, v24[0]
	mov.b	v6[4], v24[1]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v8, v6, #0
	and.16b	v17, v8, v10
	mov	b6, v24[6]
	mov.b	v6[4], v24[7]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v10, v6, #0
	and.16b	v11, v10, v9
	mov	b6, v24[4]
	mov.b	v6[4], v24[5]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v9, v6, #0
	and.16b	v12, v9, v21
	mov.d	x6, v12[1]
	sdiv	x6, x6, x4
	fmov	x7, d12
	fmov	x19, d30
	sdiv	x7, x7, x19
	mul	x19, x7, x19
	fmov	d21, x7
	mov.d	v21[1], x6
	mov.d	x7, v11[1]
	sdiv	x7, x7, x5
	fmov	x20, d11
	fmov	x21, d29
	sdiv	x20, x20, x21
	mul	x21, x20, x21
	fmov	d29, x20
	mov.d	v29[1], x7
	mov.d	x20, v17[1]
	sdiv	x20, x20, x2
	fmov	x22, d17
	fmov	x23, d28
	sdiv	x22, x22, x23
	mul	x23, x22, x23
	fmov	d28, x22
	mov.d	v28[1], x20
	mov.d	x22, v16[1]
	fmov	x24, d16
	fmov	x25, d20
	sdiv	x24, x24, x25
	mul	x25, x24, x25
	fmov	d20, x24
	sdiv	x22, x22, x3
	mov.d	v20[1], x22
	mul	x2, x20, x2
	fmov	d6, x23
	mov.d	v6[1], x2
	mul	x2, x22, x3
	fmov	d7, x25
	mov.d	v7[1], x2
	mul	x2, x6, x4
	fmov	d18, x19
	mov.d	v18[1], x2
	str	q5, [sp, #5216]
	mul	x2, x7, x5
	fmov	d5, x21
	mov.d	v5[1], x2
	sub.2d	v5, v11, v5
	sub.2d	v18, v12, v18
	sub.2d	v7, v16, v7
	sub.2d	v6, v17, v6
	mov	x2, #-8                         ; =0xfffffffffffffff8
	dup.2d	v16, x2
	add.2d	v6, v6, v16
	add.2d	v7, v7, v16
	add.2d	v17, v18, v16
	mov	w2, #32                         ; =0x20
	dup.2d	v18, x2
	add.2d	v5, v5, v16
	cmhi.2d	v16, v18, v5
	cmhi.2d	v25, v18, v17
	uzp1.4s	v16, v25, v16
	cmhi.2d	v25, v18, v7
	cmhi.2d	v18, v18, v6
	uzp1.4s	v18, v18, v25
	uzp1.8h	v16, v18, v16
	xtn.8b	v16, v16
	ldrb	w2, [x9]
	and	w3, w2, #0x1
	fmov	s18, w3
	ubfx	w3, w2, #1, #1
	mov.b	v18[1], w3
	ubfx	w3, w2, #2, #1
	mov.b	v18[2], w3
	ubfx	w3, w2, #3, #1
	mov.b	v18[3], w3
	ubfx	w3, w2, #4, #1
	mov.b	v18[4], w3
	ubfx	w3, w2, #5, #1
	mov.b	v18[5], w3
	ubfx	w3, w2, #6, #1
	mov.b	v18[6], w3
	lsr	w2, w2, #7
	mov.b	v18[7], w2
	bif.8b	v16, v18, v13
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v2
	addv.8b	b16, v16
	str	b16, [x9]
	shl.2d	v18, v20, #5
	shl.2d	v25, v28, #5
	shl.2d	v20, v29, #5
	shl.2d	v16, v21, #5
	add.2d	v16, v16, v17
	add.2d	v20, v20, v5
	add.2d	v5, v25, v6
	add.2d	v17, v18, v7
	ldr	q6, [sp, #5152]
	ldr	q7, [sp, #5168]
	ldr	q18, [sp, #5120]
	ldr	q21, [sp, #5136]
	bsl.16b	v3, v17, v21
	bit.16b	v18, v5, v8
	bit.16b	v7, v20, v10
	bit.16b	v6, v16, v9
	str	q6, [sp, #5152]
	str	q7, [sp, #5168]
	str	q18, [sp, #5120]
	str	q3, [sp, #5136]
	mov	w2, #128                        ; =0x80
	dup.2d	v3, x2
	cmhi.2d	v6, v3, v20
	cmhi.2d	v7, v3, v16
	uzp1.4s	v6, v7, v6
	cmhi.2d	v7, v3, v17
	cmhi.2d	v18, v3, v5
	uzp1.4s	v7, v18, v7
	uzp1.8h	v6, v7, v6
	xtn.8b	v6, v6
	and.8b	v27, v24, v6
	shl.8b	v6, v27, #7
	cmlt.8b	v6, v6, #0
	and.8b	v7, v6, v2
	addv.8b	b7, v7
	fmov	w2, s7
	umaxv.8b	b6, v6
	fmov	w3, s6
	str	q19, [sp, #928]                 ; 16-byte Folded Spill
	tbz	w3, #0, LBB0_489
; %bb.484:                              ; %else3043
                                        ;   in Loop: Header=BB0_10 Depth=3
	cmhs.2d	v6, v20, v3
	cmhs.2d	v7, v16, v3
	uzp1.4s	v6, v7, v6
	cmhs.2d	v7, v17, v3
	cmhs.2d	v3, v5, v3
	uzp1.4s	v3, v3, v7
	uzp1.8h	v3, v3, v6
	xtn.8b	v3, v3
	and.8b	v28, v24, v3
	shl.8b	v3, v28, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_489
; %bb.485:                              ; %varying.divergent346
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q18, [sp, #688]                 ; 16-byte Folded Reload
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	ldr	q16, [sp, #1088]                ; 16-byte Folded Reload
	str	q16, [sp, #3104]
	ldr	q7, [sp, #1104]                 ; 16-byte Folded Reload
	str	q7, [sp, #3120]
	and	x1, x1, #0x7
	add	x3, sp, #3104
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #10, #0, ne
	cset	w1, ne
	cmp	w2, #255
	ldr	q8, [sp, #608]                  ; 16-byte Folded Reload
	ldr	q17, [sp, #1008]                ; 16-byte Folded Reload
	ldp	q22, q12, [sp, #752]            ; 32-byte Folded Reload
	ldr	q9, [sp, #800]                  ; 16-byte Folded Reload
	mov.16b	v13, v1
	b.ne	LBB0_487
; %bb.486:                              ; %varying.divergent346
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #0, LBB0_746
LBB0_487:                               ; %convergence.overflow.resume349
                                        ;   in Loop: Header=BB0_10 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #7, lsl #12             ; =28672
	add	x2, x2, #2800
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s3, w4
	ubfx	w4, w5, #1, #1
	mov.b	v3[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v3[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v3[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v3[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v3[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v3[6], w4
	add	x4, sp, #7, lsl #12             ; =28672
	add	x4, x4, #2792
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s5, w6
	ubfx	w6, w5, #1, #1
	mov.b	v5[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v5[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v5[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v5[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v5[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v5[6], w6
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v6, w5
	bit.8b	v3, v24, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x2, w3, uxtw]
	bic.8b	v3, v5, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	ldr	q1, [sp, #992]                  ; 16-byte Folded Reload
	ldr	q24, [sp, #784]                 ; 16-byte Folded Reload
	ldr	q20, [sp, #1040]                ; 16-byte Folded Reload
	ldp	q30, q29, [sp, #848]            ; 32-byte Folded Reload
	ldr	q14, [sp, #912]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	ldr	q6, [sp, #720]                  ; 16-byte Folded Reload
	ldr	q31, [sp, #960]                 ; 16-byte Folded Reload
	b.hs	LBB0_746
; %bb.488:                              ; %ready.overflow.resume351
                                        ;   in Loop: Header=BB0_10 Depth=3
	zip2.8b	v3, v28, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldr	q5, [sp, #368]                  ; 16-byte Folded Reload
	and.16b	v4, v3, v5
	zip1.8b	v3, v28, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldr	q5, [sp, #384]                  ; 16-byte Folded Reload
	and.16b	v5, v3, v5
	stp	q4, q5, [sp, #368]              ; 32-byte Folded Spill
	str	q6, [sp, #3072]
	str	q0, [sp, #3088]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #3072
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q6, [sp, #3040]
	str	q0, [sp, #3056]
	add	x5, sp, #3040
	str	w4, [x5, x2]
	ldr	q0, [sp, #3056]
	str	q0, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q25, [sp, #3040]
	str	q16, [sp, #3008]
	str	q7, [sp, #3024]
	add	x4, sp, #3008
	ldr	w4, [x4, x2]
	mov	w5, #10                         ; =0xa
	csel	w4, w5, w4, ne
	str	q16, [sp, #2976]
	str	q7, [sp, #2992]
	add	x5, sp, #2976
	str	w4, [x5, x2]
	mov	w2, #26                         ; =0x1a
	mov	w4, #25                         ; =0x19
	ldr	q0, [sp, #2992]
	str	q0, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #2976]
	str	q0, [sp, #1088]                 ; 16-byte Folded Spill
                                        ; kill: def $w3 killed $w3 killed $x3 def $x3
	ldr	q3, [sp, #816]                  ; 16-byte Folded Reload
	stp	q1, q17, [sp, #992]             ; 32-byte Folded Spill
	str	q20, [sp, #1040]                ; 16-byte Folded Spill
	mov.16b	v4, v8
	mov.16b	v19, v26
	mov.16b	v26, v3
	mov.16b	v8, v12
	mov.16b	v15, v24
	str	q31, [sp, #960]                 ; 16-byte Folded Spill
	mov.16b	v12, v30
	mov.16b	v30, v9
	ldr	q0, [sp, #704]                  ; 16-byte Folded Reload
	mov.16b	v9, v18
	mov.16b	v31, v14
	mov.16b	v14, v0
	b	LBB0_9
LBB0_489:                               ; %varying.coherent347
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	ldr	q22, [sp, #1008]                ; 16-byte Folded Reload
	mov.16b	v30, v26
	mov.16b	v8, v1
	str	q22, [sp, #1008]                ; 16-byte Folded Spill
	b.eq	LBB0_510
; %bb.490:                              ; %varying.coherent.true352
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q1, [sp, #992]                  ; 16-byte Folded Reload
	ldr	q15, [sp, #784]                 ; 16-byte Folded Reload
	ldr	q4, [sp, #1040]                 ; 16-byte Folded Reload
	ldp	q13, q29, [sp, #848]            ; 32-byte Folded Reload
	ldr	q12, [sp, #912]                 ; 16-byte Folded Reload
	ldr	q14, [sp, #960]                 ; 16-byte Folded Reload
	str	q4, [sp, #1040]                 ; 16-byte Folded Spill
	str	q1, [sp, #992]                  ; 16-byte Folded Spill
	str	q14, [sp, #960]                 ; 16-byte Folded Spill
	tbnz	w1, #0, LBB0_728
; %bb.491:                              ; %schedule.25.thread
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q3, [sp, #5504]
	ldr	q5, [sp, #5520]
	ldr	q6, [sp, #5536]
	ldr	q7, [sp, #5552]
	ldr	q16, [sp, #5616]
	ldr	q17, [sp, #5600]
	ldr	q18, [sp, #5584]
	ldr	q21, [sp, #5568]
	ldr	q20, [sp, #5120]
	ldr	q25, [sp, #5136]
	ldr	q26, [sp, #5152]
	ldr	q27, [sp, #5168]
	shl.2d	v27, v27, #5
	shl.2d	v26, v26, #5
	shl.2d	v25, v25, #5
	shl.2d	v28, v20, #5
	add.2d	v7, v7, v16
	add.2d	v16, v7, v27
	add.2d	v6, v6, v17
	add.2d	v17, v6, v26
	add.2d	v5, v5, v18
	add.2d	v20, v5, v25
	add.2d	v3, v3, v21
	add.2d	v21, v3, v28
	ldr	d3, [sp, #736]                  ; 8-byte Folded Reload
	fmov	w1, s3
	movi.2d	v3, #0000000000000000
	movi.2d	v5, #0000000000000000
	ldr	q27, [sp, #816]                 ; 16-byte Folded Reload
	ldr	q25, [sp, #720]                 ; 16-byte Folded Reload
	ldr	q6, [sp, #1024]                 ; 16-byte Folded Reload
	tbnz	w1, #0, LBB0_544
; %bb.492:                              ; %else3598
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #1, LBB0_545
LBB0_493:                               ; %else3604
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v21, v8
	mov.16b	v18, v30
	tbz	w1, #2, LBB0_495
LBB0_494:                               ; %cond.load3606
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d20
	ld1.s	{ v3 }[2], [x2]
LBB0_495:                               ; %else3610
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q30, [sp, #800]                 ; 16-byte Folded Reload
	ldr	q8, [sp, #768]                  ; 16-byte Folded Reload
	ldr	q9, [sp, #688]                  ; 16-byte Folded Reload
	ldr	q28, [sp, #608]                 ; 16-byte Folded Reload
	ldr	q1, [sp, #976]                  ; 16-byte Folded Reload
	mov.16b	v31, v12
	mov.16b	v19, v18
	tbz	w1, #3, LBB0_497
; %bb.496:                              ; %cond.load3612
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v20[1]
	ld1.s	{ v3 }[3], [x2]
LBB0_497:                               ; %else3616
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q22, [sp, #752]                 ; 16-byte Folded Reload
	mov.16b	v12, v13
	ldr	q14, [sp, #704]                 ; 16-byte Folded Reload
	str	q1, [sp, #976]                  ; 16-byte Folded Spill
	mov.16b	v26, v27
	mov.16b	v13, v21
	str	q6, [sp, #1024]                 ; 16-byte Folded Spill
	tbnz	w1, #4, LBB0_546
; %bb.498:                              ; %else3622
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v4, v28
	tbnz	w1, #5, LBB0_547
LBB0_499:                               ; %else3628
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #6, LBB0_548
LBB0_500:                               ; %else3634
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbz	w1, #7, LBB0_502
LBB0_501:                               ; %cond.load3636
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x1, v16[1]
	ld1.s	{ v5 }[3], [x1]
LBB0_502:                               ; %else3640
                                        ;   in Loop: Header=BB0_10 Depth=3
	zip2.8b	v6, v24, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	ldr	q7, [sp, #368]                  ; 16-byte Folded Reload
	bit.16b	v7, v5, v6
	zip1.8b	v5, v24, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q6, [sp, #384]                  ; 16-byte Folded Reload
	bit.16b	v6, v3, v5
	stp	q7, q6, [sp, #368]              ; 32-byte Folded Spill
	b	LBB0_511
LBB0_503:                               ; %cond.load2997
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x7, d12
	ldr	s3, [x7]
	tbz	w6, #1, LBB0_476
LBB0_504:                               ; %cond.load3003
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x7, v12[1]
	ld1.s	{ v3 }[1], [x7]
	mov.16b	v26, v27
	ldr	q6, [sp, #880]                  ; 16-byte Folded Reload
	tbz	w6, #2, LBB0_477
LBB0_505:                               ; %cond.load3009
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x7, d11
	ld1.s	{ v3 }[2], [x7]
	ldr	q19, [sp, #928]                 ; 16-byte Folded Reload
	str	q6, [sp, #880]                  ; 16-byte Folded Spill
	tbz	w6, #3, LBB0_478
LBB0_506:                               ; %cond.load3015
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x7, v11[1]
	ld1.s	{ v3 }[3], [x7]
	tbz	w6, #4, LBB0_479
LBB0_507:                               ; %cond.load3021
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x7, d17
	ld1.s	{ v16 }[0], [x7]
	tbz	w6, #5, LBB0_480
LBB0_508:                               ; %cond.load3027
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x7, v17[1]
	ld1.s	{ v16 }[1], [x7]
	tbz	w6, #6, LBB0_481
LBB0_509:                               ; %cond.load3033
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x7, d5
	ld1.s	{ v16 }[2], [x7]
	tbnz	w6, #7, LBB0_482
	b	LBB0_483
LBB0_510:                               ; %varying.coherent.false353
                                        ;   in Loop: Header=BB0_10 Depth=3
	zip2.8b	v3, v24, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldp	q4, q5, [sp, #368]              ; 32-byte Folded Reload
	and.16b	v1, v3, v4
	zip1.8b	v3, v24, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v5, v3, v5
	stp	q1, q5, [sp, #368]              ; 32-byte Folded Spill
	ldr	q26, [sp, #816]                 ; 16-byte Folded Reload
	ldp	q12, q29, [sp, #848]            ; 32-byte Folded Reload
	ldr	q31, [sp, #912]                 ; 16-byte Folded Reload
	ldp	q14, q25, [sp, #704]            ; 32-byte Folded Reload
	mov.16b	v13, v8
	mov.16b	v7, v30
	ldp	q15, q30, [sp, #784]            ; 32-byte Folded Reload
	ldr	q9, [sp, #688]                  ; 16-byte Folded Reload
	ldp	q22, q8, [sp, #752]             ; 32-byte Folded Reload
	mov.16b	v19, v7
	ldr	q4, [sp, #608]                  ; 16-byte Folded Reload
	tbnz	w1, #0, LBB0_5
LBB0_511:                               ; %schedule.26
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q6, [sp, #1040]                 ; 16-byte Folded Reload
	mov.16b	v1, v4
	str	q26, [sp, #816]                 ; 16-byte Folded Spill
	stp	q12, q29, [sp, #848]            ; 32-byte Folded Spill
	mov.16b	v12, v15
	stp	q22, q8, [sp, #752]             ; 32-byte Folded Spill
	str	q14, [sp, #704]                 ; 16-byte Folded Spill
	ldr	q26, [sp, #976]                 ; 16-byte Folded Reload
	str	q1, [sp, #608]                  ; 16-byte Folded Spill
	mov.16b	v15, v9
	ldp	q4, q29, [sp, #944]             ; 32-byte Folded Reload
	mov.16b	v9, v13
	ldr	q0, [sp, #928]                  ; 16-byte Folded Reload
	mov.16b	v1, v19
	stp	q31, q0, [sp, #912]             ; 32-byte Folded Spill
	str	q6, [sp, #1040]                 ; 16-byte Folded Spill
	stp	q4, q29, [sp, #944]             ; 32-byte Folded Spill
	cbz	w0, LBB0_516
; %bb.512:                              ; %convergence.cascade356.preheader
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov	w1, #0                          ; =0x0
LBB0_513:                               ; %convergence.cascade356
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_10 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v5, v3, v2
	addv.8b	b5, v5
	fmov	w2, s5
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	ldr	q3, [sp, #1088]                 ; 16-byte Folded Reload
	str	q3, [sp, #3168]
	ldr	q3, [sp, #1104]                 ; 16-byte Folded Reload
	str	q3, [sp, #3184]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #3168
	ldr	w6, [x6, x2]
	cmp	w6, #10
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #7, lsl #12             ; =28672
	add	x5, x5, #2800
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s3, w19
	ubfx	w19, w20, #1, #1
	mov.b	v3[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v3[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v3[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v3[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v3[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v3[6], w19
	add	x19, sp, #7, lsl #12            ; =28672
	add	x19, x19, #2792
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s5, w21
	ubfx	w21, w20, #1, #1
	mov.b	v5[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v5[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v5[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v5[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v5[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v5[6], w21
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	orr.8b	v6, v24, v5
	ldr	d4, [sp, #1064]                 ; 8-byte Folded Reload
	and.8b	v7, v4, v3
	eor.8b	v7, v7, v6
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v6, v7
	dup.8b	v17, w7
	bit.8b	v5, v16, v17
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x19, w3, sxtw]
	bic.8b	v3, v3, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v5, v5, v6
	str	q25, [sp, #3136]
	ldr	q4, [sp, #1072]                 ; 16-byte Folded Reload
	str	q4, [sp, #3152]
	add	x3, sp, #3136
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v24, v5, v3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_517
; %bb.514:                              ; %convergence.cascade356
                                        ;   in Loop: Header=BB0_513 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_517
; %bb.515:                              ; %convergence.cascade356
                                        ;   in Loop: Header=BB0_513 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_513
	b	LBB0_517
LBB0_516:                               ; %schedule.26.convergence.cascade.exit357_crit_edge
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_517:                               ; %convergence.cascade.exit357
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_714
; %bb.518:                              ; %convergence.target.26.ready
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v13, v25
	ldrb	w1, [x9]
	lsr	w2, w1, #7
	ubfx	w3, w1, #6, #1
	ubfx	w4, w1, #5, #1
	ubfx	w5, w1, #4, #1
	ubfx	w6, w1, #3, #1
	ubfx	w7, w1, #2, #1
	ubfx	w19, w1, #1, #1
	and	w1, w1, #0x1
	fmov	s3, w1
	mov.h	v3[1], w19
	mov.h	v3[2], w7
	mov.h	v3[3], w6
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	fmov	s5, w5
	mov.h	v5[1], w4
	mov.h	v5[2], w3
	ldr	q6, [sp, #384]                  ; 16-byte Folded Reload
	and.16b	v6, v3, v6
	mov.h	v5[3], w2
	ushll.4s	v3, v5, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q5, [sp, #368]                  ; 16-byte Folded Reload
	and.16b	v3, v3, v5
	ldr	q5, [sp, #5216]
	ldr	q7, [sp, #5232]
	fadd.4s	v3, v7, v3
	fadd.4s	v16, v5, v6
	ldr	q5, [sp, #5296]
	ldr	q6, [sp, #5280]
	ldr	q7, [sp, #5248]
	ldr	q17, [sp, #5264]
	ldr	q18, [sp, #5328]
	ldr	q19, [sp, #5312]
	ldr	q20, [sp, #5344]
	ldr	q21, [sp, #5360]
	shl.2d	v25, v26, #5
	ldr	q4, [sp, #624]                  ; 16-byte Folded Reload
	shl.2d	v26, v4, #5
	shl.2d	v27, v9, #5
	ldr	q23, [sp, #672]                 ; 16-byte Folded Reload
	shl.2d	v28, v23, #5
	add.2d	v21, v21, v28
	add.2d	v27, v20, v27
	add.2d	v20, v19, v26
	add.2d	v18, v18, v25
	add.2d	v19, v17, v18
	add.2d	v20, v7, v20
	add.2d	v17, v6, v27
	add.2d	v5, v5, v21
	shl.8b	v6, v24, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	fmov	w1, s6
	tbnz	w1, #0, LBB0_531
; %bb.519:                              ; %else3646
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #1, LBB0_532
LBB0_520:                               ; %else3650
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v4, v15
	mov.16b	v25, v13
	tbz	w1, #2, LBB0_522
LBB0_521:                               ; %cond.store3651
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d19
	st1.s	{ v16 }[2], [x2]
LBB0_522:                               ; %else3654
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v27, v1
	ldr	q6, [sp, #848]                  ; 16-byte Folded Reload
	ldr	q7, [sp, #896]                  ; 16-byte Folded Reload
	ldr	q8, [sp, #768]                  ; 16-byte Folded Reload
	ldr	q1, [sp, #1008]                 ; 16-byte Folded Reload
	mov.16b	v15, v12
	tbz	w1, #3, LBB0_524
; %bb.523:                              ; %cond.store3655
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v19[1]
	st1.s	{ v16 }[3], [x2]
LBB0_524:                               ; %else3658
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q19, [sp, #1024]                ; 16-byte Folded Reload
	ldr	q31, [sp, #912]                 ; 16-byte Folded Reload
	ldr	q16, [sp, #704]                 ; 16-byte Folded Reload
	ldr	q26, [sp, #816]                 ; 16-byte Folded Reload
	tbz	w1, #4, LBB0_526
; %bb.525:                              ; %cond.store3659
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d17
	str	s3, [x2]
LBB0_526:                               ; %else3662
                                        ;   in Loop: Header=BB0_10 Depth=3
	str	q1, [sp, #1008]                 ; 16-byte Folded Spill
	mov.16b	v13, v9
	mov.16b	v9, v4
	ldr	q4, [sp, #608]                  ; 16-byte Folded Reload
	ldr	q22, [sp, #752]                 ; 16-byte Folded Reload
	mov.16b	v12, v6
	tbnz	w1, #5, LBB0_533
; %bb.527:                              ; %else3666
                                        ;   in Loop: Header=BB0_10 Depth=3
	str	q7, [sp, #896]                  ; 16-byte Folded Spill
	ldr	q29, [sp, #864]                 ; 16-byte Folded Reload
	mov.16b	v14, v16
	str	q19, [sp, #1024]                ; 16-byte Folded Spill
	tbnz	w1, #6, LBB0_534
LBB0_528:                               ; %else3670
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v19, v27
	tbz	w1, #7, LBB0_530
LBB0_529:                               ; %cond.store3671
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x1, v5[1]
	st1.s	{ v3 }[3], [x1]
LBB0_530:                               ; %else3674
                                        ;   in Loop: Header=BB0_10 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v24, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v5, v3, #0
	ushll2.4s	v3, v3, #0
	ldr	q6, [sp, #672]                  ; 16-byte Folded Reload
	uaddw2.2d	v6, v6, v3
	str	q6, [sp, #672]                  ; 16-byte Folded Spill
	uaddw.2d	v13, v13, v3
	ldr	q0, [sp, #976]                  ; 16-byte Folded Reload
	uaddw2.2d	v0, v0, v5
	str	q0, [sp, #976]                  ; 16-byte Folded Spill
	ldr	q0, [sp, #624]                  ; 16-byte Folded Reload
	uaddw.2d	v0, v0, v5
	b	LBB0_465
LBB0_531:                               ; %cond.store3643
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d20
	str	s16, [x2]
	tbz	w1, #1, LBB0_520
LBB0_532:                               ; %cond.store3647
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v20[1]
	st1.s	{ v16 }[1], [x2]
	mov.16b	v4, v15
	mov.16b	v25, v13
	tbnz	w1, #2, LBB0_521
	b	LBB0_522
LBB0_533:                               ; %cond.store3663
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v17[1]
	st1.s	{ v3 }[1], [x2]
	str	q7, [sp, #896]                  ; 16-byte Folded Spill
	ldr	q29, [sp, #864]                 ; 16-byte Folded Reload
	mov.16b	v14, v16
	str	q19, [sp, #1024]                ; 16-byte Folded Spill
	tbz	w1, #6, LBB0_528
LBB0_534:                               ; %cond.store3667
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d5
	st1.s	{ v3 }[2], [x2]
	mov.16b	v19, v27
	tbnz	w1, #7, LBB0_529
	b	LBB0_530
LBB0_535:                               ; %varying.coherent.false342
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_5
LBB0_536:                               ; %schedule.27
                                        ;   in Loop: Header=BB0_10 Depth=3
	cbz	w0, LBB0_541
; %bb.537:                              ; %convergence.cascade382.preheader
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov	w1, #0                          ; =0x0
LBB0_538:                               ; %convergence.cascade382
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_10 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v5, v3, v2
	addv.8b	b5, v5
	fmov	w2, s5
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #4192]
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	str	q0, [sp, #4208]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #1, lsl #12             ; =4096
	add	x6, x6, #96
	ldr	w6, [x6, x2]
	cmp	w6, #9
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #7, lsl #12             ; =28672
	add	x5, x5, #2800
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s3, w19
	ubfx	w19, w20, #1, #1
	mov.b	v3[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v3[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v3[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v3[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v3[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v3[6], w19
	add	x19, sp, #7, lsl #12            ; =28672
	add	x19, x19, #2792
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s5, w21
	ubfx	w21, w20, #1, #1
	mov.b	v5[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v5[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v5[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v5[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v5[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v5[6], w21
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	orr.8b	v6, v24, v5
	ldr	d0, [sp, #1064]                 ; 8-byte Folded Reload
	and.8b	v7, v0, v3
	eor.8b	v7, v7, v6
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v6, v7
	dup.8b	v17, w7
	bit.8b	v5, v16, v17
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x19, w3, sxtw]
	bic.8b	v3, v3, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v5, v5, v6
	str	q25, [sp, #4160]
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	str	q0, [sp, #4176]
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #64
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v24, v5, v3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_542
; %bb.539:                              ; %convergence.cascade382
                                        ;   in Loop: Header=BB0_538 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_542
; %bb.540:                              ; %convergence.cascade382
                                        ;   in Loop: Header=BB0_538 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_538
	b	LBB0_542
LBB0_541:                               ; %schedule.27.convergence.cascade.exit383_crit_edge
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_542:                               ; %convergence.cascade.exit383
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_5
; %bb.543:                              ; %convergence.target.27.ready
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov	b3, v24[6]
	mov.b	v3[4], v24[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q16, [sp, #128]                 ; 16-byte Folded Reload
	ldp	q5, q6, [sp, #208]              ; 32-byte Folded Reload
	bit.16b	v5, v16, v3
	str	q5, [sp, #208]                  ; 16-byte Folded Spill
	mov	b5, v24[4]
	mov.b	v5[4], v24[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	bit.16b	v6, v16, v5
	str	q6, [sp, #224]                  ; 16-byte Folded Spill
	mov	b6, v24[2]
	mov.b	v6[4], v24[3]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	ldp	q7, q17, [sp, #240]             ; 32-byte Folded Reload
	bit.16b	v7, v16, v6
	str	q7, [sp, #240]                  ; 16-byte Folded Spill
	mov	b7, v24[0]
	mov.b	v7[4], v24[1]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	bit.16b	v17, v16, v7
	str	q17, [sp, #256]                 ; 16-byte Folded Spill
Lloh74:
	adrp	x1, lCPI0_19@PAGE
Lloh75:
	ldr	q16, [x1, lCPI0_19@PAGEOFF]
	ldr	q17, [sp, #448]                 ; 16-byte Folded Reload
	bit.16b	v17, v16, v3
	str	q17, [sp, #448]                 ; 16-byte Folded Spill
Lloh76:
	adrp	x1, lCPI0_18@PAGE
Lloh77:
	ldr	q16, [x1, lCPI0_18@PAGEOFF]
	ldr	q17, [sp, #464]                 ; 16-byte Folded Reload
	bit.16b	v17, v16, v5
	str	q17, [sp, #464]                 ; 16-byte Folded Spill
Lloh78:
	adrp	x1, lCPI0_17@PAGE
Lloh79:
	ldr	q16, [x1, lCPI0_17@PAGEOFF]
	ldr	q17, [sp, #480]                 ; 16-byte Folded Reload
	bit.16b	v17, v16, v6
	str	q17, [sp, #480]                 ; 16-byte Folded Spill
Lloh80:
	adrp	x1, lCPI0_16@PAGE
Lloh81:
	ldr	q16, [x1, lCPI0_16@PAGEOFF]
	ldr	q17, [sp, #496]                 ; 16-byte Folded Reload
	bit.16b	v17, v16, v7
	str	q17, [sp, #496]                 ; 16-byte Folded Spill
	bic.16b	v12, v12, v3
	bic.16b	v22, v22, v5
	ldr	q0, [sp, #1008]                 ; 16-byte Folded Reload
	bic.16b	v0, v0, v6
	str	q0, [sp, #1008]                 ; 16-byte Folded Spill
	bic.16b	v4, v4, v7
	b	LBB0_549
LBB0_544:                               ; %cond.load3594
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d21
	ldr	s3, [x2]
	tbz	w1, #1, LBB0_493
LBB0_545:                               ; %cond.load3600
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v21[1]
	ld1.s	{ v3 }[1], [x2]
	mov.16b	v21, v8
	mov.16b	v18, v30
	tbnz	w1, #2, LBB0_494
	b	LBB0_495
LBB0_546:                               ; %cond.load3618
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d17
	ld1.s	{ v5 }[0], [x2]
	mov.16b	v4, v28
	tbz	w1, #5, LBB0_499
LBB0_547:                               ; %cond.load3624
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v17[1]
	ld1.s	{ v5 }[1], [x2]
	tbz	w1, #6, LBB0_500
LBB0_548:                               ; %cond.load3630
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d16
	ld1.s	{ v5 }[2], [x2]
	tbnz	w1, #7, LBB0_501
	b	LBB0_502
LBB0_549:                               ; %schedule.28
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	mov	w1, #128                        ; =0x80
	dup.2d	v3, x1
	ldr	q0, [sp, #1008]                 ; 16-byte Folded Reload
	cmgt.2d	v5, v3, v0
	cmgt.2d	v6, v3, v4
	uzp1.4s	v5, v6, v5
	cmgt.2d	v6, v3, v22
	cmgt.2d	v7, v3, v12
	uzp1.4s	v6, v6, v7
	uzp1.8h	v5, v5, v6
	xtn.8b	v5, v5
	and.8b	v27, v24, v5
	shl.8b	v5, v27, #7
	cmlt.8b	v5, v5, #0
	and.8b	v6, v5, v2
	addv.8b	b6, v6
	fmov	w1, s6
	umaxv.8b	b5, v5
	fmov	w3, s5
	tbz	w3, #0, LBB0_555
; %bb.550:                              ; %schedule.28
                                        ;   in Loop: Header=BB0_10 Depth=3
	cmge.2d	v5, v0, v3
	cmge.2d	v6, v4, v3
	uzp1.4s	v5, v6, v5
	cmge.2d	v6, v22, v3
	cmge.2d	v3, v12, v3
	uzp1.4s	v3, v6, v3
	uzp1.8h	v3, v5, v3
	xtn.8b	v3, v3
	and.8b	v28, v24, v3
	shl.8b	v3, v28, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_555
; %bb.551:                              ; %varying.divergent400
                                        ;   in Loop: Header=BB0_10 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #3328]
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	str	q0, [sp, #3344]
	and	x1, x1, #0x7
	add	x3, sp, #3328
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #11, #0, ne
	cset	w1, ne
	cmp	w2, #255
	b.ne	LBB0_553
; %bb.552:                              ; %varying.divergent400
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #0, LBB0_746
LBB0_553:                               ; %convergence.overflow.resume403
                                        ;   in Loop: Header=BB0_10 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #7, lsl #12             ; =28672
	add	x2, x2, #2800
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s3, w4
	ubfx	w4, w5, #1, #1
	mov.b	v3[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v3[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v3[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v3[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v3[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v3[6], w4
	add	x4, sp, #7, lsl #12             ; =28672
	add	x4, x4, #2792
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s5, w6
	ubfx	w6, w5, #1, #1
	mov.b	v5[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v5[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v5[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v5[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v5[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v5[6], w6
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v6, w5
	bit.8b	v3, v24, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x2, w3, uxtw]
	bic.8b	v3, v5, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_746
; %bb.554:                              ; %ready.overflow.resume405
                                        ;   in Loop: Header=BB0_10 Depth=3
	str	q25, [sp, #3296]
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	str	q0, [sp, #3312]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #3296
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q25, [sp, #3264]
	str	q0, [sp, #3280]
	add	x5, sp, #3264
	str	w4, [x5, x2]
	ldr	q0, [sp, #3280]
	str	q0, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q25, [sp, #3264]
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #3232]
	ldr	q1, [sp, #1104]                 ; 16-byte Folded Reload
	str	q1, [sp, #3248]
	add	x4, sp, #3232
	ldr	w4, [x4, x2]
	mov	w5, #11                         ; =0xb
	csel	w4, w5, w4, ne
	str	q0, [sp, #3200]
	str	q1, [sp, #3216]
	add	x5, sp, #3200
	str	w4, [x5, x2]
	mov	w2, #32                         ; =0x20
	mov	w4, #29                         ; =0x1d
	ldr	q0, [sp, #3216]
	str	q0, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #3200]
	str	q0, [sp, #1088]                 ; 16-byte Folded Spill
                                        ; kill: def $w3 killed $w3 killed $x3 def $x3
	b	LBB0_9
LBB0_555:                               ; %varying.coherent401
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w1, #0xff
	b.eq	LBB0_633
; %bb.556:                              ; %varying.coherent.true406
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov	w1, #0                          ; =0x0
	tst	w2, #0xff
	b.eq	LBB0_5
LBB0_557:                               ; %schedule.29
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v23, v25
	str	q31, [sp, #912]                 ; 16-byte Folded Spill
	stp	q9, q14, [sp, #688]             ; 32-byte Folded Spill
	mov.16b	v31, v8
	str	q29, [sp, #864]                 ; 16-byte Folded Spill
	stp	q30, q26, [sp, #800]            ; 32-byte Folded Spill
	str	q15, [sp, #784]                 ; 16-byte Folded Spill
	str	q13, [sp, #736]                 ; 16-byte Folded Spill
	mov.16b	v13, v19
	mov	b3, v24[0]
	mov.b	v3[4], v24[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v21, v3, #0
	mov.16b	v27, v4
	and.16b	v9, v21, v4
	mov	b3, v24[2]
	mov.b	v3[4], v24[3]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v8, v3, #0
	mov	b3, v24[4]
	mov.b	v3[4], v24[5]
	ldr	q1, [sp, #1008]                 ; 16-byte Folded Reload
	and.16b	v5, v8, v1
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	str	q22, [sp, #752]                 ; 16-byte Folded Spill
	and.16b	v16, v3, v22
	mov	b6, v24[6]
	mov.b	v6[4], v24[7]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v10, v6, #0
	mov.16b	v29, v12
	and.16b	v17, v10, v12
	shl.8b	v6, v24, #7
	cmlt.8b	v0, v6, #0
	and.8b	v6, v0, v2
	addv.8b	b4, v6
	fmov	w6, s4
	mov	w2, #32                         ; =0x20
	dup.2d	v6, x2
	and.16b	v7, v21, v6
	mvn.16b	v18, v21
	sub.2d	v30, v7, v18
	and.16b	v7, v8, v6
	mvn.16b	v18, v8
	sub.2d	v28, v7, v18
	and.16b	v7, v3, v6
	and.16b	v6, v10, v6
	mvn.16b	v18, v10
	sub.2d	v19, v6, v18
	mov.d	x2, v19[1]
	mov.d	x3, v17[1]
	sdiv	x21, x3, x2
	mvn.16b	v6, v3
	sub.2d	v20, v7, v6
	fmov	x7, d19
	fmov	x3, d17
	sdiv	x3, x3, x7
	mul	x23, x3, x7
	fmov	d6, x3
	mov.d	v6[1], x21
	mov.d	x3, v20[1]
	mov.d	x4, v16[1]
	sdiv	x24, x4, x3
	fmov	x19, d20
	fmov	x4, d16
	sdiv	x4, x4, x19
	mul	x25, x4, x19
	fmov	d7, x4
	mov.d	v7[1], x24
	mov.d	x4, v28[1]
	mov.d	x5, v5[1]
	sdiv	x26, x5, x4
	fmov	x20, d28
	fmov	x5, d5
	sdiv	x5, x5, x20
	mul	x27, x5, x20
	fmov	d18, x5
	mov.d	v18[1], x26
	mov.d	x5, v30[1]
	fmov	x22, d30
	fmov	x28, d9
	sdiv	x28, x28, x22
	mul	x30, x28, x22
	fmov	d25, x28
	mov.d	x28, v9[1]
	sdiv	x28, x28, x5
	mov.d	v25[1], x28
	mul	x28, x28, x5
	fmov	d26, x30
	mov.d	v26[1], x28
	mul	x26, x26, x4
	fmov	d11, x27
	mov.d	v11[1], x26
	mul	x24, x24, x3
	fmov	d12, x25
	mov.d	v12[1], x24
	mul	x21, x21, x2
	fmov	d15, x23
	mov.d	v15[1], x21
	sub.2d	v17, v17, v15
	sub.2d	v12, v16, v12
	sub.2d	v15, v5, v11
	sub.2d	v26, v9, v26
	ldr	q9, [sp, #5104]
	ldr	q11, [sp, #5088]
	ldr	q16, [sp, #5072]
	ldr	q5, [sp, #5056]
	bit.16b	v5, v25, v21
	bit.16b	v16, v18, v8
	bit.16b	v11, v7, v3
	bit.16b	v9, v6, v10
	str	q9, [sp, #5104]
	shl.2d	v6, v6, #5
	shl.2d	v7, v7, #5
	shl.2d	v18, v18, #5
	shl.2d	v25, v25, #5
	add.2d	v25, v25, v26
	add.2d	v18, v18, v15
	add.2d	v7, v7, v12
	add.2d	v6, v6, v17
	and.16b	v9, v10, v6
	and.16b	v17, v8, v18
	and.16b	v21, v21, v25
	mov.d	x21, v21[1]
	sdiv	x21, x21, x5
	fmov	x23, d21
	sdiv	x23, x23, x22
	mul	x22, x23, x22
	fmov	d6, x23
	mov.d	v6[1], x21
	mov.d	x23, v17[1]
	sdiv	x23, x23, x4
	fmov	x24, d17
	sdiv	x24, x24, x20
	mul	x20, x24, x20
	fmov	d18, x24
	mov.d	v18[1], x23
	and.16b	v3, v3, v7
	mov.d	x24, v3[1]
	sdiv	x24, x24, x3
	fmov	x25, d3
	sdiv	x25, x25, x19
	mul	x19, x25, x19
	fmov	d7, x25
	mov.d	v7[1], x24
	mov.d	x25, v9[1]
	str	q11, [sp, #5088]
	fmov	x26, d9
	sdiv	x26, x26, x7
	mul	x7, x26, x7
	fmov	d25, x26
	sdiv	x25, x25, x2
	mov.d	v25[1], x25
	mul	x21, x21, x5
	fmov	d26, x22
	mov.d	v26[1], x21
	mul	x21, x23, x4
	fmov	d8, x20
	mov.d	v8[1], x21
	mul	x20, x24, x3
	fmov	d10, x19
	mov.d	v10[1], x20
	mul	x19, x25, x2
	fmov	d11, x7
	mov.d	v11[1], x19
	str	q16, [sp, #5072]
	sub.2d	v16, v9, v11
	sub.2d	v3, v3, v10
	str	q5, [sp, #5056]
	sub.2d	v5, v17, v8
	sub.2d	v17, v21, v26
	shl.2d	v25, v25, #5
	shl.2d	v7, v7, #5
	shl.2d	v18, v18, #5
	shl.2d	v6, v6, #5
	add.2d	v10, v6, v17
	add.2d	v8, v18, v5
	add.2d	v21, v7, v3
	add.2d	v9, v25, v16
	ldr	q3, [sp, #5248]
	ldr	q6, [sp, #5264]
	ldr	q7, [sp, #5280]
	ldr	q5, [sp, #5296]
	ldr	q16, [sp, #5360]
	ldr	q17, [sp, #5344]
	ldr	q18, [sp, #5328]
	shl.2d	v25, v9, #5
	shl.2d	v26, v21, #5
	ldr	q12, [sp, #5312]
	shl.2d	v11, v8, #5
	shl.2d	v15, v10, #5
	add.2d	v5, v5, v16
	add.2d	v5, v5, v25
	add.2d	v7, v7, v17
	add.2d	v17, v7, v26
	add.2d	v6, v6, v18
	add.2d	v11, v6, v11
	add.2d	v3, v3, v12
	add.2d	v12, v3, v15
	movi.2d	v3, #0000000000000000
	movi.2d	v16, #0000000000000000
	str	q23, [sp, #720]                 ; 16-byte Folded Spill
	str	q29, [sp, #848]                 ; 16-byte Folded Spill
	str	q13, [sp, #592]                 ; 16-byte Folded Spill
	tbnz	w6, #0, LBB0_585
; %bb.558:                              ; %else3099
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w6, #1, LBB0_586
LBB0_559:                               ; %else3105
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v26, v27
	ldr	q12, [sp, #944]                 ; 16-byte Folded Reload
	tbnz	w6, #2, LBB0_587
LBB0_560:                               ; %else3111
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q22, [sp, #976]                 ; 16-byte Folded Reload
	ldr	q1, [sp, #736]                  ; 16-byte Folded Reload
	tbnz	w6, #3, LBB0_588
LBB0_561:                               ; %else3117
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w6, #4, LBB0_589
LBB0_562:                               ; %else3123
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w6, #5, LBB0_590
LBB0_563:                               ; %else3129
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w6, #6, LBB0_591
LBB0_564:                               ; %else3135
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbz	w6, #7, LBB0_566
LBB0_565:                               ; %cond.load3137
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x6, v5[1]
	ld1.s	{ v16 }[3], [x6]
LBB0_566:                               ; %else3141
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q6, [sp, #5040]
	ldr	q5, [sp, #5024]
	zip1.8b	v7, v24, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	bit.16b	v5, v3, v7
	zip2.8b	v3, v24, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bsl.16b	v3, v16, v6
	mov	b6, v24[2]
	mov.b	v6[4], v24[3]
	str	q3, [sp, #5040]
	ushll.2d	v3, v6, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	and.16b	v16, v3, v8
	mov	b6, v24[0]
	mov.b	v6[4], v24[1]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v8, v6, #0
	and.16b	v17, v8, v10
	mov	b6, v24[6]
	mov.b	v6[4], v24[7]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v10, v6, #0
	and.16b	v11, v10, v9
	mov	b6, v24[4]
	mov.b	v6[4], v24[5]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v9, v6, #0
	and.16b	v21, v9, v21
	mov.d	x6, v21[1]
	sdiv	x6, x6, x3
	fmov	x7, d21
	fmov	x19, d20
	sdiv	x7, x7, x19
	mul	x19, x7, x19
	fmov	d20, x7
	mov.d	v20[1], x6
	mov.d	x7, v11[1]
	sdiv	x7, x7, x2
	fmov	x20, d11
	fmov	x21, d19
	sdiv	x20, x20, x21
	mul	x21, x20, x21
	fmov	d19, x20
	mov.d	v19[1], x7
	mov.d	x20, v17[1]
	sdiv	x20, x20, x5
	fmov	x22, d17
	fmov	x23, d30
	sdiv	x22, x22, x23
	mul	x23, x22, x23
	fmov	d30, x22
	mov.d	v30[1], x20
	mov.d	x22, v16[1]
	fmov	x24, d16
	fmov	x25, d28
	sdiv	x24, x24, x25
	mul	x25, x24, x25
	fmov	d28, x24
	sdiv	x22, x22, x4
	mov.d	v28[1], x22
	mul	x5, x20, x5
	fmov	d6, x23
	mov.d	v6[1], x5
	mul	x4, x22, x4
	fmov	d7, x25
	mov.d	v7[1], x4
	mul	x3, x6, x3
	fmov	d18, x19
	mov.d	v18[1], x3
	str	q5, [sp, #5024]
	mul	x2, x7, x2
	fmov	d5, x21
	mov.d	v5[1], x2
	sub.2d	v5, v11, v5
	sub.2d	v18, v21, v18
	sub.2d	v7, v16, v7
	sub.2d	v6, v17, v6
	mov	x2, #-16                        ; =0xfffffffffffffff0
	dup.2d	v16, x2
	add.2d	v6, v6, v16
	add.2d	v7, v7, v16
	add.2d	v17, v18, v16
	mov	w2, #32                         ; =0x20
	dup.2d	v18, x2
	add.2d	v5, v5, v16
	cmhi.2d	v16, v18, v5
	cmhi.2d	v21, v18, v17
	uzp1.4s	v16, v21, v16
	cmhi.2d	v21, v18, v7
	cmhi.2d	v18, v18, v6
	uzp1.4s	v18, v18, v21
	uzp1.8h	v16, v18, v16
	xtn.8b	v16, v16
	add	x19, sp, #928
	ldrb	w2, [x19, #4095]
	and	w3, w2, #0x1
	fmov	s18, w3
	ubfx	w3, w2, #1, #1
	mov.b	v18[1], w3
	ubfx	w3, w2, #2, #1
	mov.b	v18[2], w3
	ubfx	w3, w2, #3, #1
	mov.b	v18[3], w3
	ubfx	w3, w2, #4, #1
	mov.b	v18[4], w3
	ubfx	w3, w2, #5, #1
	mov.b	v18[5], w3
	ubfx	w3, w2, #6, #1
	mov.b	v18[6], w3
	lsr	w2, w2, #7
	mov.b	v18[7], w2
	bif.8b	v16, v18, v0
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v2
	addv.8b	b16, v16
	add	x19, sp, #928
	str	b16, [x19, #4095]
	shl.2d	v18, v28, #5
	shl.2d	v21, v30, #5
	shl.2d	v19, v19, #5
	shl.2d	v16, v20, #5
	add.2d	v16, v16, v17
	add.2d	v19, v19, v5
	add.2d	v5, v21, v6
	add.2d	v17, v18, v7
	ldr	q6, [sp, #4960]
	ldr	q7, [sp, #4976]
	ldr	q18, [sp, #4928]
	ldr	q20, [sp, #4944]
	bsl.16b	v3, v17, v20
	bit.16b	v18, v5, v8
	bit.16b	v7, v19, v10
	bit.16b	v6, v16, v9
	str	q6, [sp, #4960]
	str	q7, [sp, #4976]
	str	q18, [sp, #4928]
	str	q3, [sp, #4944]
	mov	w2, #128                        ; =0x80
	dup.2d	v3, x2
	cmhi.2d	v6, v3, v19
	cmhi.2d	v7, v3, v16
	uzp1.4s	v6, v7, v6
	cmhi.2d	v7, v3, v17
	cmhi.2d	v18, v3, v5
	uzp1.4s	v7, v18, v7
	uzp1.8h	v6, v7, v6
	xtn.8b	v6, v6
	and.8b	v27, v24, v6
	shl.8b	v6, v27, #7
	cmlt.8b	v6, v6, #0
	and.8b	v7, v6, v2
	addv.8b	b7, v7
	fmov	w2, s7
	umaxv.8b	b6, v6
	fmov	w3, s6
	str	q22, [sp, #976]                 ; 16-byte Folded Spill
	str	q12, [sp, #944]                 ; 16-byte Folded Spill
	tbz	w3, #0, LBB0_570
; %bb.567:                              ; %else3141
                                        ;   in Loop: Header=BB0_10 Depth=3
	cmhs.2d	v6, v19, v3
	cmhs.2d	v7, v16, v3
	uzp1.4s	v6, v7, v6
	cmhs.2d	v7, v17, v3
	cmhs.2d	v3, v5, v3
	uzp1.4s	v3, v3, v7
	uzp1.8h	v3, v3, v6
	xtn.8b	v3, v3
	and.8b	v28, v24, v3
	shl.8b	v3, v28, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_570
; %bb.568:                              ; %varying.divergent411
                                        ;   in Loop: Header=BB0_10 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	ldr	q7, [sp, #1088]                 ; 16-byte Folded Reload
	str	q7, [sp, #3488]
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	str	q0, [sp, #3504]
	and	x1, x1, #0x7
	add	x3, sp, #3488
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #12, #0, ne
	cset	w1, ne
	cmp	w2, #255
	ldr	q15, [sp, #1008]                ; 16-byte Folded Reload
	ldr	q4, [sp, #752]                  ; 16-byte Folded Reload
	ldr	q14, [sp, #704]                 ; 16-byte Folded Reload
	ldr	q30, [sp, #800]                 ; 16-byte Folded Reload
	mov.16b	v20, v13
	mov.16b	v8, v31
	b.ne	LBB0_7
; %bb.569:                              ; %varying.divergent411
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #0, LBB0_746
	b	LBB0_7
LBB0_570:                               ; %varying.coherent412
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	ldr	q30, [sp, #800]                 ; 16-byte Folded Reload
	mov.16b	v0, v26
	mov.16b	v8, v31
	b.eq	LBB0_592
; %bb.571:                              ; %varying.coherent.true417
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v31, v8
	mov.16b	v14, v30
	ldr	q15, [sp, #992]                 ; 16-byte Folded Reload
	ldr	q28, [sp, #784]                 ; 16-byte Folded Reload
	ldr	q30, [sp, #1040]                ; 16-byte Folded Reload
	ldp	q8, q29, [sp, #848]             ; 32-byte Folded Reload
	ldr	q13, [sp, #1024]                ; 16-byte Folded Reload
	str	q30, [sp, #1040]                ; 16-byte Folded Spill
	str	q15, [sp, #992]                 ; 16-byte Folded Spill
	str	q13, [sp, #1024]                ; 16-byte Folded Spill
	tbnz	w1, #0, LBB0_725
; %bb.572:                              ; %schedule.30.thread
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q3, [sp, #5248]
	ldr	q5, [sp, #5264]
	ldr	q6, [sp, #5280]
	ldr	q7, [sp, #5296]
	ldr	q16, [sp, #5360]
	ldr	q17, [sp, #5344]
	ldr	q18, [sp, #5328]
	ldr	q20, [sp, #5312]
	ldr	q19, [sp, #4928]
	ldr	q21, [sp, #4944]
	ldr	q25, [sp, #4960]
	ldr	q26, [sp, #4976]
	shl.2d	v26, v26, #5
	shl.2d	v25, v25, #5
	shl.2d	v21, v21, #5
	shl.2d	v27, v19, #5
	add.2d	v7, v7, v16
	add.2d	v23, v7, v26
	add.2d	v6, v6, v17
	add.2d	v10, v6, v25
	add.2d	v5, v5, v18
	add.2d	v19, v5, v21
	add.2d	v3, v3, v20
	add.2d	v20, v3, v27
	fmov	w1, s4
	movi.2d	v3, #0000000000000000
	movi.2d	v5, #0000000000000000
	ldp	q6, q18, [sp, #816]             ; 32-byte Folded Reload
	ldr	q7, [sp, #928]                  ; 16-byte Folded Reload
	mov.16b	v16, v1
	mov.16b	v1, v0
	ldr	q27, [sp, #880]                 ; 16-byte Folded Reload
	ldr	q22, [sp, #752]                 ; 16-byte Folded Reload
	tbz	w1, #0, LBB0_574
; %bb.573:                              ; %cond.load3676
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d20
	ldr	s3, [x2]
LBB0_574:                               ; %else3680
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q9, [sp, #688]                  ; 16-byte Folded Reload
	ldr	q21, [sp, #960]                 ; 16-byte Folded Reload
	ldr	q30, [sp, #896]                 ; 16-byte Folded Reload
	str	q18, [sp, #832]                 ; 16-byte Folded Spill
	tbz	w1, #1, LBB0_576
; %bb.575:                              ; %cond.load3682
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v20[1]
	ld1.s	{ v3 }[1], [x2]
LBB0_576:                               ; %else3686
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldp	q0, q25, [sp, #704]             ; 32-byte Folded Reload
	ldr	q20, [sp, #592]                 ; 16-byte Folded Reload
	ldr	q12, [sp, #912]                 ; 16-byte Folded Reload
	mov.16b	v18, v6
	ldr	q6, [sp, #1008]                 ; 16-byte Folded Reload
	str	q7, [sp, #928]                  ; 16-byte Folded Spill
	stp	q27, q30, [sp, #880]            ; 32-byte Folded Spill
	tbz	w1, #2, LBB0_578
; %bb.577:                              ; %cond.load3688
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d19
	ld1.s	{ v3 }[2], [x2]
LBB0_578:                               ; %else3692
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v27, v1
	mov.16b	v7, v31
	mov.16b	v30, v14
	mov.16b	v14, v0
	mov.16b	v15, v28
	str	q6, [sp, #1008]                 ; 16-byte Folded Spill
	mov.16b	v26, v18
	str	q21, [sp, #960]                 ; 16-byte Folded Spill
	mov.16b	v31, v12
	tbnz	w1, #3, LBB0_642
; %bb.579:                              ; %else3698
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v12, v8
	mov.16b	v19, v20
	mov.16b	v8, v7
	mov.16b	v4, v27
	tbnz	w1, #4, LBB0_643
LBB0_580:                               ; %else3704
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v13, v16
	tbnz	w1, #5, LBB0_644
LBB0_581:                               ; %else3710
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #6, LBB0_645
LBB0_582:                               ; %else3716
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbz	w1, #7, LBB0_584
LBB0_583:                               ; %cond.load3718
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x1, v23[1]
	ld1.s	{ v5 }[3], [x1]
LBB0_584:                               ; %else3722
                                        ;   in Loop: Header=BB0_10 Depth=3
	zip2.8b	v6, v24, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	ldr	q7, [sp, #400]                  ; 16-byte Folded Reload
	bit.16b	v7, v5, v6
	zip1.8b	v5, v24, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q6, [sp, #416]                  ; 16-byte Folded Reload
	bit.16b	v6, v3, v5
	stp	q7, q6, [sp, #400]              ; 32-byte Folded Spill
	b	LBB0_593
LBB0_585:                               ; %cond.load3095
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x7, d12
	ldr	s3, [x7]
	tbz	w6, #1, LBB0_559
LBB0_586:                               ; %cond.load3101
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x7, v12[1]
	ld1.s	{ v3 }[1], [x7]
	mov.16b	v26, v27
	ldr	q12, [sp, #944]                 ; 16-byte Folded Reload
	tbz	w6, #2, LBB0_560
LBB0_587:                               ; %cond.load3107
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x7, d11
	ld1.s	{ v3 }[2], [x7]
	ldr	q22, [sp, #976]                 ; 16-byte Folded Reload
	ldr	q1, [sp, #736]                  ; 16-byte Folded Reload
	tbz	w6, #3, LBB0_561
LBB0_588:                               ; %cond.load3113
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x7, v11[1]
	ld1.s	{ v3 }[3], [x7]
	tbz	w6, #4, LBB0_562
LBB0_589:                               ; %cond.load3119
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x7, d17
	ld1.s	{ v16 }[0], [x7]
	tbz	w6, #5, LBB0_563
LBB0_590:                               ; %cond.load3125
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x7, v17[1]
	ld1.s	{ v16 }[1], [x7]
	tbz	w6, #6, LBB0_564
LBB0_591:                               ; %cond.load3131
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x7, d5
	ld1.s	{ v16 }[2], [x7]
	tbnz	w6, #7, LBB0_565
	b	LBB0_566
LBB0_592:                               ; %varying.coherent.false418
                                        ;   in Loop: Header=BB0_10 Depth=3
	zip2.8b	v3, v24, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldp	q6, q5, [sp, #400]              ; 32-byte Folded Reload
	and.16b	v4, v3, v6
	zip1.8b	v3, v24, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v5, v3, v5
	stp	q4, q5, [sp, #400]              ; 32-byte Folded Spill
	ldr	q15, [sp, #784]                 ; 16-byte Folded Reload
	ldr	q26, [sp, #816]                 ; 16-byte Folded Reload
	ldp	q12, q29, [sp, #848]            ; 32-byte Folded Reload
	mov.16b	v13, v1
	ldp	q9, q14, [sp, #688]             ; 32-byte Folded Reload
	ldr	q25, [sp, #720]                 ; 16-byte Folded Reload
	ldr	q31, [sp, #912]                 ; 16-byte Folded Reload
	ldr	q19, [sp, #592]                 ; 16-byte Folded Reload
	mov.16b	v4, v0
	ldr	q22, [sp, #752]                 ; 16-byte Folded Reload
	tbz	w1, #0, LBB0_593
	b	LBB0_5
LBB0_593:                               ; %schedule.31
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q3, [sp, #944]                  ; 16-byte Folded Reload
	str	q30, [sp, #800]                 ; 16-byte Folded Spill
	str	q12, [sp, #848]                 ; 16-byte Folded Spill
	str	q22, [sp, #752]                 ; 16-byte Folded Spill
	str	q31, [sp, #912]                 ; 16-byte Folded Spill
	mov.16b	v31, v14
	mov.16b	v14, v15
	mov.16b	v30, v19
	mov.16b	v15, v13
	str	q9, [sp, #688]                  ; 16-byte Folded Spill
	str	q3, [sp, #944]                  ; 16-byte Folded Spill
	cbz	w0, LBB0_598
; %bb.594:                              ; %convergence.cascade421.preheader
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v13, v26
	mov.16b	v9, v29
	mov	w1, #0                          ; =0x0
LBB0_595:                               ; %convergence.cascade421
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_10 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v5, v3, v2
	addv.8b	b5, v5
	fmov	w2, s5
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #3552]
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	str	q0, [sp, #3568]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #3552
	ldr	w6, [x6, x2]
	cmp	w6, #12
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #7, lsl #12             ; =28672
	add	x5, x5, #2800
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s3, w19
	ubfx	w19, w20, #1, #1
	mov.b	v3[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v3[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v3[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v3[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v3[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v3[6], w19
	add	x19, sp, #7, lsl #12            ; =28672
	add	x19, x19, #2792
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s5, w21
	ubfx	w21, w20, #1, #1
	mov.b	v5[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v5[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v5[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v5[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v5[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v5[6], w21
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	orr.8b	v6, v24, v5
	ldr	d0, [sp, #1064]                 ; 8-byte Folded Reload
	and.8b	v7, v0, v3
	eor.8b	v7, v7, v6
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v6, v7
	dup.8b	v17, w7
	bit.8b	v5, v16, v17
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x19, w3, sxtw]
	bic.8b	v3, v3, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v5, v5, v6
	str	q25, [sp, #3520]
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	str	q0, [sp, #3536]
	add	x3, sp, #3520
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v24, v5, v3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_599
; %bb.596:                              ; %convergence.cascade421
                                        ;   in Loop: Header=BB0_595 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_599
; %bb.597:                              ; %convergence.cascade421
                                        ;   in Loop: Header=BB0_595 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_595
	b	LBB0_599
LBB0_598:                               ; %schedule.31.convergence.cascade.exit422_crit_edge
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v13, v26
	mov.16b	v9, v29
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_599:                               ; %convergence.cascade.exit422
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_718
; %bb.600:                              ; %convergence.target.31.ready
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v0, v25
	add	x19, sp, #928
	ldrb	w1, [x19, #4095]
	lsr	w2, w1, #7
	ubfx	w3, w1, #6, #1
	ubfx	w4, w1, #5, #1
	ubfx	w5, w1, #4, #1
	ubfx	w6, w1, #3, #1
	ubfx	w7, w1, #2, #1
	ubfx	w19, w1, #1, #1
	and	w1, w1, #0x1
	fmov	s3, w1
	mov.h	v3[1], w19
	mov.h	v3[2], w7
	mov.h	v3[3], w6
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	fmov	s5, w5
	mov.h	v5[1], w4
	mov.h	v5[2], w3
	ldr	q6, [sp, #416]                  ; 16-byte Folded Reload
	and.16b	v6, v3, v6
	mov.h	v5[3], w2
	ushll.4s	v3, v5, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q5, [sp, #400]                  ; 16-byte Folded Reload
	and.16b	v3, v3, v5
	ldr	q5, [sp, #5024]
	ldr	q7, [sp, #5040]
	fadd.4s	v3, v7, v3
	fadd.4s	v19, v5, v6
	ldr	q5, [sp, #6400]
	ldr	q6, [sp, #6416]
	ldr	q7, [sp, #6432]
	ldr	q16, [sp, #6448]
	ldr	q17, [sp, #6512]
	ldr	q18, [sp, #6496]
	ldr	q20, [sp, #6480]
	ldr	q25, [sp, #6464]
	ldr	q21, [sp, #5056]
	ldr	q26, [sp, #5072]
	ldr	q27, [sp, #5088]
	ldr	q28, [sp, #5104]
	shl.2d	v28, v28, #5
	shl.2d	v27, v27, #5
	shl.2d	v26, v26, #5
	shl.2d	v29, v21, #5
	add.2d	v16, v16, v17
	add.2d	v16, v16, v28
	add.2d	v7, v7, v18
	add.2d	v21, v7, v27
	add.2d	v6, v6, v20
	add.2d	v27, v6, v26
	add.2d	v5, v5, v25
	add.2d	v28, v5, v29
	shl.8b	v5, v24, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	fmov	w1, s5
	movi.2d	v17, #0000000000000000
	movi.2d	v20, #0000000000000000
	tbnz	w1, #0, LBB0_620
; %bb.601:                              ; %else3729
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #1, LBB0_621
LBB0_602:                               ; %else3735
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v25, v0
	mov.16b	v29, v9
	mov.16b	v26, v13
	mov.16b	v0, v30
	mov.16b	v6, v31
	tbz	w1, #2, LBB0_604
LBB0_603:                               ; %cond.load3737
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d27
	ld1.s	{ v17 }[2], [x2]
LBB0_604:                               ; %else3741
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q30, [sp, #800]                 ; 16-byte Folded Reload
	mov.16b	v13, v15
	mov.16b	v15, v14
	ldr	q31, [sp, #912]                 ; 16-byte Folded Reload
	ldr	q12, [sp, #848]                 ; 16-byte Folded Reload
	mov.16b	v28, v0
	ldr	q22, [sp, #752]                 ; 16-byte Folded Reload
	mov.16b	v14, v6
	tbnz	w1, #3, LBB0_622
; %bb.605:                              ; %else3747
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q0, [sp, #880]                  ; 16-byte Folded Reload
	tbnz	w1, #4, LBB0_623
LBB0_606:                               ; %else3753
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q9, [sp, #688]                  ; 16-byte Folded Reload
	tbnz	w1, #5, LBB0_624
LBB0_607:                               ; %else3759
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #6, LBB0_625
LBB0_608:                               ; %else3765
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbz	w1, #7, LBB0_610
LBB0_609:                               ; %cond.load3767
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x1, v16[1]
	ld1.s	{ v20 }[3], [x1]
LBB0_610:                               ; %else3771
                                        ;   in Loop: Header=BB0_10 Depth=3
	fadd.4s	v17, v19, v17
	fadd.4s	v3, v3, v20
	shl.2d	v6, v4, #5
	ldr	q1, [sp, #1008]                 ; 16-byte Folded Reload
	shl.2d	v7, v1, #5
	shl.2d	v16, v22, #5
	shl.2d	v18, v12, #5
	ldr	q19, [sp, #256]                 ; 16-byte Folded Reload
	ldr	q20, [sp, #496]                 ; 16-byte Folded Reload
	add.2d	v19, v19, v20
	add.2d	v20, v19, v6
	ldr	q6, [sp, #240]                  ; 16-byte Folded Reload
	ldr	q19, [sp, #480]                 ; 16-byte Folded Reload
	add.2d	v6, v6, v19
	add.2d	v19, v6, v7
	ldr	q6, [sp, #224]                  ; 16-byte Folded Reload
	ldp	q7, q1, [sp, #448]              ; 32-byte Folded Reload
	add.2d	v6, v6, v1
	add.2d	v16, v6, v16
	ldr	q6, [sp, #208]                  ; 16-byte Folded Reload
	add.2d	v6, v6, v7
	fmov	w1, s5
	add.2d	v5, v6, v18
	tbnz	w1, #0, LBB0_626
; %bb.611:                              ; %else3777
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #1, LBB0_627
LBB0_612:                               ; %else3781
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #2, LBB0_628
LBB0_613:                               ; %else3785
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #3, LBB0_629
LBB0_614:                               ; %else3789
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #4, LBB0_630
LBB0_615:                               ; %else3793
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v19, v28
	tbnz	w1, #5, LBB0_631
LBB0_616:                               ; %else3797
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #6, LBB0_632
LBB0_617:                               ; %else3801
                                        ;   in Loop: Header=BB0_10 Depth=3
	str	q0, [sp, #880]                  ; 16-byte Folded Spill
	tbz	w1, #7, LBB0_619
LBB0_618:                               ; %cond.store3802
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x1, v5[1]
	st1.s	{ v3 }[3], [x1]
LBB0_619:                               ; %else3805
                                        ;   in Loop: Header=BB0_10 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v24, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v5, v3, #0
	ushll2.4s	v3, v3, #0
	uaddw2.2d	v12, v12, v3
	uaddw.2d	v22, v22, v3
	ldr	q0, [sp, #1008]                 ; 16-byte Folded Reload
	uaddw2.2d	v0, v0, v5
	str	q0, [sp, #1008]                 ; 16-byte Folded Spill
	uaddw.2d	v4, v4, v5
	b	LBB0_549
LBB0_620:                               ; %cond.load3725
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d28
	ldr	s17, [x2]
	tbz	w1, #1, LBB0_602
LBB0_621:                               ; %cond.load3731
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v28[1]
	ld1.s	{ v17 }[1], [x2]
	mov.16b	v25, v0
	mov.16b	v29, v9
	mov.16b	v26, v13
	mov.16b	v0, v30
	mov.16b	v6, v31
	tbnz	w1, #2, LBB0_603
	b	LBB0_604
LBB0_622:                               ; %cond.load3743
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v27[1]
	ld1.s	{ v17 }[3], [x2]
	ldr	q0, [sp, #880]                  ; 16-byte Folded Reload
	tbz	w1, #4, LBB0_606
LBB0_623:                               ; %cond.load3749
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d21
	ld1.s	{ v20 }[0], [x2]
	ldr	q9, [sp, #688]                  ; 16-byte Folded Reload
	tbz	w1, #5, LBB0_607
LBB0_624:                               ; %cond.load3755
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v21[1]
	ld1.s	{ v20 }[1], [x2]
	tbz	w1, #6, LBB0_608
LBB0_625:                               ; %cond.load3761
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d16
	ld1.s	{ v20 }[2], [x2]
	tbnz	w1, #7, LBB0_609
	b	LBB0_610
LBB0_626:                               ; %cond.store3774
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d20
	str	s17, [x2]
	tbz	w1, #1, LBB0_612
LBB0_627:                               ; %cond.store3778
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v20[1]
	st1.s	{ v17 }[1], [x2]
	tbz	w1, #2, LBB0_613
LBB0_628:                               ; %cond.store3782
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d19
	st1.s	{ v17 }[2], [x2]
	tbz	w1, #3, LBB0_614
LBB0_629:                               ; %cond.store3786
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v19[1]
	st1.s	{ v17 }[3], [x2]
	tbz	w1, #4, LBB0_615
LBB0_630:                               ; %cond.store3790
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d16
	str	s3, [x2]
	mov.16b	v19, v28
	tbz	w1, #5, LBB0_616
LBB0_631:                               ; %cond.store3794
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v16[1]
	st1.s	{ v3 }[1], [x2]
	tbz	w1, #6, LBB0_617
LBB0_632:                               ; %cond.store3798
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d5
	st1.s	{ v3 }[2], [x2]
	str	q0, [sp, #880]                  ; 16-byte Folded Spill
	tbnz	w1, #7, LBB0_618
	b	LBB0_619
LBB0_633:                               ; %varying.coherent.false407
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_5
LBB0_634:                               ; %schedule.32
                                        ;   in Loop: Header=BB0_10 Depth=3
	cbz	w0, LBB0_639
; %bb.635:                              ; %convergence.cascade449.preheader
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov	w1, #0                          ; =0x0
LBB0_636:                               ; %convergence.cascade449
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_10 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v5, v3, v2
	addv.8b	b5, v5
	fmov	w2, s5
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #4128]
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	str	q0, [sp, #4144]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #1, lsl #12             ; =4096
	add	x6, x6, #32
	ldr	w6, [x6, x2]
	cmp	w6, #11
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #7, lsl #12             ; =28672
	add	x5, x5, #2800
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s3, w19
	ubfx	w19, w20, #1, #1
	mov.b	v3[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v3[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v3[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v3[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v3[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v3[6], w19
	add	x19, sp, #7, lsl #12            ; =28672
	add	x19, x19, #2792
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s5, w21
	ubfx	w21, w20, #1, #1
	mov.b	v5[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v5[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v5[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v5[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v5[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v5[6], w21
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	orr.8b	v6, v24, v5
	ldr	d0, [sp, #1064]                 ; 8-byte Folded Reload
	and.8b	v7, v0, v3
	eor.8b	v7, v7, v6
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v6, v7
	dup.8b	v17, w7
	bit.8b	v5, v16, v17
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x19, w3, sxtw]
	bic.8b	v3, v3, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v5, v5, v6
	str	q25, [sp, #4096]
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	str	q0, [sp, #4112]
	add	x3, sp, #1, lsl #12             ; =4096
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v24, v5, v3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_640
; %bb.637:                              ; %convergence.cascade449
                                        ;   in Loop: Header=BB0_636 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_640
; %bb.638:                              ; %convergence.cascade449
                                        ;   in Loop: Header=BB0_636 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_636
	b	LBB0_640
LBB0_639:                               ; %schedule.32.convergence.cascade.exit450_crit_edge
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_640:                               ; %convergence.cascade.exit450
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_5
; %bb.641:                              ; %convergence.target.32.ready
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov	b3, v24[6]
	mov.b	v3[4], v24[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmge.2d	v3, v3, #0
	and.16b	v9, v3, v9
	mov	b3, v24[4]
	mov.b	v3[4], v24[5]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmge.2d	v3, v3, #0
	mov	b5, v24[2]
	mov.b	v5[4], v24[3]
	ldr	q0, [sp, #880]                  ; 16-byte Folded Reload
	and.16b	v0, v3, v0
	str	q0, [sp, #880]                  ; 16-byte Folded Spill
	ushll.2d	v3, v5, #0
	shl.2d	v3, v3, #63
	cmge.2d	v3, v3, #0
	and.16b	v19, v3, v19
	mov	b3, v24[0]
	mov.b	v3[4], v24[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmge.2d	v3, v3, #0
	ldr	q0, [sp, #928]                  ; 16-byte Folded Reload
	and.16b	v0, v3, v0
	b	LBB0_646
LBB0_642:                               ; %cond.load3694
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v19[1]
	ld1.s	{ v3 }[3], [x2]
	mov.16b	v12, v8
	mov.16b	v19, v20
	mov.16b	v8, v7
	mov.16b	v4, v27
	tbz	w1, #4, LBB0_580
LBB0_643:                               ; %cond.load3700
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d10
	ld1.s	{ v5 }[0], [x2]
	mov.16b	v13, v16
	tbz	w1, #5, LBB0_581
LBB0_644:                               ; %cond.load3706
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v10[1]
	ld1.s	{ v5 }[1], [x2]
	tbz	w1, #6, LBB0_582
LBB0_645:                               ; %cond.load3712
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d23
	ld1.s	{ v5 }[2], [x2]
	tbnz	w1, #7, LBB0_583
	b	LBB0_584
LBB0_646:                               ; %schedule.33
                                        ;   in Loop: Header=BB0_10 Depth=3
	str	q0, [sp, #928]                  ; 16-byte Folded Spill
LBB0_647:                               ; %schedule.33
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	mov	w1, #128                        ; =0x80
	dup.2d	v3, x1
	cmgt.2d	v5, v3, v19
	ldr	q0, [sp, #928]                  ; 16-byte Folded Reload
	cmgt.2d	v6, v3, v0
	uzp1.4s	v5, v6, v5
	ldr	q0, [sp, #880]                  ; 16-byte Folded Reload
	cmgt.2d	v6, v3, v0
	cmgt.2d	v7, v3, v9
	uzp1.4s	v6, v6, v7
	uzp1.8h	v5, v5, v6
	xtn.8b	v5, v5
	and.8b	v27, v24, v5
	shl.8b	v5, v27, #7
	cmlt.8b	v5, v5, #0
	and.8b	v6, v5, v2
	addv.8b	b6, v6
	fmov	w1, s6
	umaxv.8b	b5, v5
	fmov	w3, s5
	tbz	w3, #0, LBB0_653
; %bb.648:                              ; %schedule.33
                                        ;   in Loop: Header=BB0_10 Depth=3
	cmge.2d	v5, v19, v3
	ldr	q0, [sp, #928]                  ; 16-byte Folded Reload
	cmge.2d	v6, v0, v3
	uzp1.4s	v5, v6, v5
	ldr	q0, [sp, #880]                  ; 16-byte Folded Reload
	cmge.2d	v6, v0, v3
	cmge.2d	v3, v9, v3
	uzp1.4s	v3, v6, v3
	uzp1.8h	v3, v5, v3
	xtn.8b	v3, v3
	and.8b	v28, v24, v3
	shl.8b	v3, v28, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_653
; %bb.649:                              ; %varying.divergent467
                                        ;   in Loop: Header=BB0_10 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #3712]
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	str	q0, [sp, #3728]
	and	x1, x1, #0x7
	add	x3, sp, #3712
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #13, #0, ne
	cset	w1, ne
	cmp	w2, #255
	b.ne	LBB0_651
; %bb.650:                              ; %varying.divergent467
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #0, LBB0_746
LBB0_651:                               ; %convergence.overflow.resume470
                                        ;   in Loop: Header=BB0_10 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #7, lsl #12             ; =28672
	add	x2, x2, #2800
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s3, w4
	ubfx	w4, w5, #1, #1
	mov.b	v3[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v3[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v3[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v3[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v3[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v3[6], w4
	add	x4, sp, #7, lsl #12             ; =28672
	add	x4, x4, #2792
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s5, w6
	ubfx	w6, w5, #1, #1
	mov.b	v5[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v5[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v5[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v5[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v5[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v5[6], w6
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v6, w5
	bit.8b	v3, v24, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x2, w3, uxtw]
	bic.8b	v3, v5, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_746
; %bb.652:                              ; %ready.overflow.resume472
                                        ;   in Loop: Header=BB0_10 Depth=3
	str	q25, [sp, #3680]
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	str	q0, [sp, #3696]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #3680
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q25, [sp, #3648]
	str	q0, [sp, #3664]
	add	x5, sp, #3648
	str	w4, [x5, x2]
	ldr	q0, [sp, #3664]
	str	q0, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q25, [sp, #3648]
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #3616]
	ldr	q1, [sp, #1104]                 ; 16-byte Folded Reload
	str	q1, [sp, #3632]
	add	x4, sp, #3616
	ldr	w4, [x4, x2]
	mov	w5, #13                         ; =0xd
	csel	w4, w5, w4, ne
	str	q0, [sp, #3584]
	str	q1, [sp, #3600]
	add	x5, sp, #3584
	str	w4, [x5, x2]
	mov	w2, #37                         ; =0x25
	mov	w4, #34                         ; =0x22
	ldr	q0, [sp, #3600]
	str	q0, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #3584]
	str	q0, [sp, #1088]                 ; 16-byte Folded Spill
                                        ; kill: def $w3 killed $w3 killed $x3 def $x3
	b	LBB0_9
LBB0_653:                               ; %varying.coherent468
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w1, #0xff
	b.eq	LBB0_687
; %bb.654:                              ; %varying.coherent.true473
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov	w1, #0                          ; =0x0
	tst	w2, #0xff
	b.eq	LBB0_5
LBB0_655:                               ; %schedule.34
                                        ;   in Loop: Header=BB0_10 Depth=3
	str	q31, [sp, #912]                 ; 16-byte Folded Spill
	mov.16b	v1, v8
	mov.16b	v3, v15
	mov.16b	v8, v19
	mov.16b	v15, v22
	mov.16b	v16, v12
	mov.16b	v31, v14
	mov.16b	v12, v4
	stp	q25, q13, [sp, #720]            ; 32-byte Folded Spill
	ldr	q0, [sp, #976]                  ; 16-byte Folded Reload
	str	q16, [sp, #848]                 ; 16-byte Folded Spill
	str	q26, [sp, #816]                 ; 16-byte Folded Spill
	str	q1, [sp, #768]                  ; 16-byte Folded Spill
	ldr	q1, [sp, #880]                  ; 16-byte Folded Reload
	mov.16b	v10, v29
	mov.16b	v14, v9
	ldr	q23, [sp, #928]                 ; 16-byte Folded Reload
	mov.16b	v11, v30
	mov.16b	v22, v3
	mov	b3, v24[0]
	mov.b	v3[4], v24[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v20, v3, #0
	and.16b	v3, v20, v23
	mov	b5, v24[2]
	mov.b	v5[4], v24[3]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v27, v5, #0
	and.16b	v21, v27, v19
	mov	b5, v24[4]
	mov.b	v5[4], v24[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v28, v5, #0
	and.16b	v5, v28, v1
	mov	b6, v24[6]
	mov.b	v6[4], v24[7]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v29, v6, #0
	and.16b	v16, v29, v9
	shl.8b	v6, v24, #7
	cmlt.8b	v6, v6, #0
	and.8b	v17, v6, v2
	mov	w2, #32                         ; =0x20
	dup.2d	v6, x2
	and.16b	v7, v20, v6
	mvn.16b	v18, v20
	sub.2d	v19, v7, v18
	and.16b	v7, v27, v6
	mvn.16b	v18, v27
	sub.2d	v30, v7, v18
	and.16b	v7, v28, v6
	and.16b	v6, v29, v6
	mvn.16b	v18, v29
	sub.2d	v6, v6, v18
	mov.d	x2, v6[1]
	mov.d	x3, v16[1]
	mvn.16b	v18, v28
	sdiv	x3, x3, x2
	sub.2d	v7, v7, v18
	fmov	x4, d6
	fmov	x5, d16
	sdiv	x5, x5, x4
	mul	x4, x5, x4
	fmov	d6, x5
	mov.d	v6[1], x3
	mov.d	x5, v7[1]
	mov.d	x6, v5[1]
	sdiv	x6, x6, x5
	fmov	x7, d7
	fmov	x19, d5
	sdiv	x19, x19, x7
	mul	x7, x19, x7
	fmov	d7, x19
	mov.d	v7[1], x6
	mov.d	x19, v30[1]
	mov.d	x20, v21[1]
	sdiv	x20, x20, x19
	fmov	x21, d30
	fmov	x22, d21
	sdiv	x22, x22, x21
	mul	x21, x22, x21
	fmov	d18, x22
	mov.d	v18[1], x20
	mov.d	x22, v19[1]
	mov.d	x23, v3[1]
	fmov	x24, d19
	fmov	x25, d3
	sdiv	x25, x25, x24
	mul	x24, x25, x24
	fmov	d25, x25
	sdiv	x23, x23, x22
	mov.d	v25[1], x23
	mul	x19, x20, x19
	fmov	d26, x21
	mov.d	v26[1], x19
	mul	x19, x23, x22
	fmov	d30, x24
	mov.d	v30[1], x19
	addv.8b	b4, v17
	mul	x2, x3, x2
	fmov	d17, x4
	mov.d	v17[1], x2
	mul	x2, x6, x5
	mov.16b	v19, v8
	fmov	d8, x7
	mov.d	v8[1], x2
	sub.2d	v5, v5, v8
	sub.2d	v16, v16, v17
	sub.2d	v3, v3, v30
	sub.2d	v17, v21, v26
	ldr	q21, [sp, #6704]
	ldr	q26, [sp, #6688]
	ldr	q30, [sp, #6672]
	ldr	q8, [sp, #6656]
	add.2d	v25, v8, v25
	add.2d	v18, v30, v18
	add.2d	v7, v26, v7
	add.2d	v6, v21, v6
	mov	w2, #17                         ; =0x11
	dup.2d	v21, x2
	cmhi.2d	v26, v21, v6
	cmhi.2d	v30, v21, v7
	uzp1.4s	v26, v30, v26
	cmhi.2d	v30, v21, v18
	cmhi.2d	v21, v21, v25
	uzp1.4s	v21, v21, v30
	uzp1.8h	v21, v21, v26
	ldr	q26, [sp, #6368]
	ldr	q30, [sp, #6384]
	ldr	q8, [sp, #6336]
	ldr	q9, [sp, #6352]
	add.2d	v17, v9, v17
	add.2d	v3, v8, v3
	add.2d	v16, v30, v16
	mov.d	x2, v18[1]
	fmov	x3, d18
	add	x3, x3, x3, lsl #6
	fmov	d18, x3
	add	x2, x2, x2, lsl #6
	mov.d	v18[1], x2
	mov.d	x2, v25[1]
	fmov	x3, d25
	add	x3, x3, x3, lsl #6
	fmov	d25, x3
	add	x2, x2, x2, lsl #6
	mov.d	v25[1], x2
	add.2d	v5, v26, v5
	mov.d	x2, v6[1]
	fmov	x3, d6
	add	x3, x3, x3, lsl #6
	fmov	d6, x3
	add	x2, x2, x2, lsl #6
	mov.d	v6[1], x2
	mov.d	x2, v7[1]
	fmov	x3, d7
	add	x3, x3, x3, lsl #6
	fmov	d7, x3
	add	x2, x2, x2, lsl #6
	mov.d	v7[1], x2
	mov	w2, #65                         ; =0x41
	dup.2d	v26, x2
	add.2d	v7, v7, v5
	add.2d	v6, v6, v16
	add.2d	v25, v25, v3
	add.2d	v18, v18, v17
	cmhi.2d	v16, v26, v16
	cmhi.2d	v5, v26, v5
	uzp1.4s	v5, v5, v16
	cmhi.2d	v16, v26, v17
	cmhi.2d	v3, v26, v3
	uzp1.4s	v3, v3, v16
	uzp1.8h	v3, v3, v5
	and.16b	v3, v21, v3
	xtn.8b	v3, v3
	ldr	q5, [sp, #4896]
	ldr	q16, [sp, #4912]
	ldr	q17, [sp, #4864]
	ldr	q21, [sp, #4880]
	bif.16b	v18, v21, v27
	bit.16b	v17, v25, v20
	bif.16b	v6, v16, v29
	bit.16b	v5, v7, v28
	shl.2d	v7, v23, #5
	mov.16b	v25, v19
	shl.2d	v16, v19, #5
	fmov	d23, d4
	fmov	w2, s4
	str	q5, [sp, #4896]
	str	q6, [sp, #4912]
	str	q17, [sp, #4864]
	str	q18, [sp, #4880]
	shl.2d	v5, v1, #5
	mov.16b	v9, v14
	shl.2d	v6, v14, #5
	ldr	q17, [sp, #256]                 ; 16-byte Folded Reload
	ldr	q18, [sp, #496]                 ; 16-byte Folded Reload
	add.2d	v17, v17, v18
	add.2d	v27, v17, v7
	ldr	q7, [sp, #240]                  ; 16-byte Folded Reload
	ldr	q17, [sp, #480]                 ; 16-byte Folded Reload
	add.2d	v7, v7, v17
	add.2d	v21, v7, v16
	ldr	q7, [sp, #224]                  ; 16-byte Folded Reload
	ldr	q16, [sp, #464]                 ; 16-byte Folded Reload
	add.2d	v7, v7, v16
	add.2d	v20, v7, v5
	ldr	q5, [sp, #208]                  ; 16-byte Folded Reload
	ldr	q7, [sp, #448]                  ; 16-byte Folded Reload
	add.2d	v5, v5, v7
	add.2d	v17, v5, v6
	movi.2d	v5, #0000000000000000
	movi.2d	v16, #0000000000000000
	str	q0, [sp, #976]                  ; 16-byte Folded Spill
	tbz	w2, #0, LBB0_657
; %bb.656:                              ; %cond.load3193
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x3, d27
	ldr	s5, [x3]
LBB0_657:                               ; %else3197
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbz	w2, #1, LBB0_659
; %bb.658:                              ; %cond.load3199
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x3, v27[1]
	ld1.s	{ v5 }[1], [x3]
LBB0_659:                               ; %else3203
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.16b	v14, v31
	mov.16b	v30, v11
	mov.16b	v4, v12
	mov.16b	v0, v15
	mov.16b	v15, v22
	mov.16b	v29, v10
	ldr	q31, [sp, #912]                 ; 16-byte Folded Reload
	mov.16b	v19, v25
	tbnz	w2, #2, LBB0_682
; %bb.660:                              ; %else3209
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q26, [sp, #816]                 ; 16-byte Folded Reload
	ldp	q25, q13, [sp, #720]            ; 32-byte Folded Reload
	mov.16b	v22, v0
	ldr	q12, [sp, #848]                 ; 16-byte Folded Reload
	tbnz	w2, #3, LBB0_683
LBB0_661:                               ; %else3215
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q8, [sp, #768]                  ; 16-byte Folded Reload
	tbnz	w2, #4, LBB0_684
LBB0_662:                               ; %else3221
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w2, #5, LBB0_685
LBB0_663:                               ; %else3227
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w2, #6, LBB0_686
LBB0_664:                               ; %else3233
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbz	w2, #7, LBB0_666
LBB0_665:                               ; %cond.load3235
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v17[1]
	ld1.s	{ v16 }[3], [x2]
LBB0_666:                               ; %else3239
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q6, [sp, #4848]
	ldr	q7, [sp, #4832]
	zip1.8b	v17, v24, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	bif.16b	v5, v7, v17
	zip2.8b	v7, v24, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	bit.16b	v6, v16, v7
	str	q6, [sp, #4848]
	str	q5, [sp, #4832]
	and.8b	v27, v24, v3
	shl.8b	v5, v27, #7
	cmlt.8b	v5, v5, #0
	and.8b	v6, v5, v2
	addv.8b	b6, v6
	fmov	w2, s6
	umaxv.8b	b5, v5
	fmov	w3, s5
	tbz	w3, #0, LBB0_672
; %bb.667:                              ; %else3239
                                        ;   in Loop: Header=BB0_10 Depth=3
	bic.8b	v28, v24, v3
	shl.8b	v3, v28, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_672
; %bb.668:                              ; %varying.divergent481
                                        ;   in Loop: Header=BB0_10 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #3872]
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	str	q0, [sp, #3888]
	and	x1, x1, #0x7
	add	x3, sp, #3872
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #14, #0, ne
	cset	w1, ne
	cmp	w2, #255
	b.ne	LBB0_670
; %bb.669:                              ; %varying.divergent481
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #0, LBB0_746
LBB0_670:                               ; %convergence.overflow.resume484
                                        ;   in Loop: Header=BB0_10 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #7, lsl #12             ; =28672
	add	x2, x2, #2800
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s3, w4
	ubfx	w4, w5, #1, #1
	mov.b	v3[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v3[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v3[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v3[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v3[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v3[6], w4
	add	x4, sp, #7, lsl #12             ; =28672
	add	x4, x4, #2792
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s5, w6
	ubfx	w6, w5, #1, #1
	mov.b	v5[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v5[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v5[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v5[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v5[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v5[6], w6
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v6, w5
	bit.8b	v3, v24, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x2, w3, uxtw]
	bic.8b	v3, v5, v6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_746
; %bb.671:                              ; %ready.overflow.resume486
                                        ;   in Loop: Header=BB0_10 Depth=3
	str	q25, [sp, #3840]
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	str	q0, [sp, #3856]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #3840
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q25, [sp, #3808]
	str	q0, [sp, #3824]
	add	x5, sp, #3808
	str	w4, [x5, x2]
	ldr	q0, [sp, #3824]
	str	q0, [sp, #1072]                 ; 16-byte Folded Spill
	ldr	q25, [sp, #3808]
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #3776]
	ldr	q1, [sp, #1104]                 ; 16-byte Folded Reload
	str	q1, [sp, #3792]
	add	x4, sp, #3776
	ldr	w4, [x4, x2]
	mov	w5, #14                         ; =0xe
	csel	w4, w5, w4, ne
	str	q0, [sp, #3744]
	str	q1, [sp, #3760]
	add	x5, sp, #3744
	str	w4, [x5, x2]
	mov	w2, #36                         ; =0x24
	mov	w4, #35                         ; =0x23
	ldr	q0, [sp, #3760]
	str	q0, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #3744]
	str	q0, [sp, #1088]                 ; 16-byte Folded Spill
                                        ; kill: def $w3 killed $w3 killed $x3 def $x3
	b	LBB0_9
LBB0_672:                               ; %varying.coherent482
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_696
; %bb.673:                              ; %varying.coherent.true487
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbz	w1, #0, LBB0_674
	b	LBB0_5
LBB0_674:                               ; %schedule.35.thread
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q5, [sp, #4912]
	ldr	q6, [sp, #4896]
	ldr	q7, [sp, #4880]
	ldr	q16, [sp, #4864]
	ldr	q3, [sp, #4848]
	ldr	q17, [sp, #4832]
	shl.2d	v18, v16, #2
	shl.2d	v7, v7, #2
	shl.2d	v6, v6, #2
	dup.2d	v21, x11
	shl.2d	v5, v5, #2
	add.2d	v5, v21, v5
	add.2d	v16, v21, v6
	add.2d	v20, v21, v7
	add.2d	v21, v21, v18
	fmov	w1, s23
	tbnz	w1, #0, LBB0_697
; %bb.675:                              ; %else3810
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #1, LBB0_698
LBB0_676:                               ; %else3814
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #2, LBB0_699
LBB0_677:                               ; %else3818
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #3, LBB0_700
LBB0_678:                               ; %else3822
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #4, LBB0_701
LBB0_679:                               ; %else3826
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #5, LBB0_702
LBB0_680:                               ; %else3830
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #6, LBB0_703
LBB0_681:                               ; %else3834
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbnz	w1, #7, LBB0_704
	b	LBB0_705
LBB0_682:                               ; %cond.load3205
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x3, d21
	ld1.s	{ v5 }[2], [x3]
	ldr	q26, [sp, #816]                 ; 16-byte Folded Reload
	ldp	q25, q13, [sp, #720]            ; 32-byte Folded Reload
	mov.16b	v22, v0
	ldr	q12, [sp, #848]                 ; 16-byte Folded Reload
	tbz	w2, #3, LBB0_661
LBB0_683:                               ; %cond.load3211
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x3, v21[1]
	ld1.s	{ v5 }[3], [x3]
	ldr	q8, [sp, #768]                  ; 16-byte Folded Reload
	tbz	w2, #4, LBB0_662
LBB0_684:                               ; %cond.load3217
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x3, d20
	ld1.s	{ v16 }[0], [x3]
	tbz	w2, #5, LBB0_663
LBB0_685:                               ; %cond.load3223
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x3, v20[1]
	ld1.s	{ v16 }[1], [x3]
	tbz	w2, #6, LBB0_664
LBB0_686:                               ; %cond.load3229
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x3, d17
	ld1.s	{ v16 }[2], [x3]
	tbnz	w2, #7, LBB0_665
	b	LBB0_666
LBB0_687:                               ; %varying.coherent.false474
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_5
LBB0_688:                               ; %schedule.37
                                        ;   in Loop: Header=BB0_10 Depth=3
	ldr	q23, [sp, #432]                 ; 16-byte Folded Reload
	ldr	q28, [sp, #880]                 ; 16-byte Folded Reload
	str	q25, [sp, #720]                 ; 16-byte Folded Spill
	str	q28, [sp, #880]                 ; 16-byte Folded Spill
	cbz	w0, LBB0_693
; %bb.689:                              ; %convergence.cascade509.preheader
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov	w1, #0                          ; =0x0
LBB0_690:                               ; %convergence.cascade509
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_10 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v5, v3, v2
	addv.8b	b5, v5
	fmov	w2, s5
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #4064]
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	str	q0, [sp, #4080]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #4064
	ldr	w6, [x6, x2]
	cmp	w6, #13
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #7, lsl #12             ; =28672
	add	x5, x5, #2800
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s3, w19
	ubfx	w19, w20, #1, #1
	mov.b	v3[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v3[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v3[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v3[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v3[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v3[6], w19
	add	x19, sp, #7, lsl #12            ; =28672
	add	x19, x19, #2792
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s5, w21
	ubfx	w21, w20, #1, #1
	mov.b	v5[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v5[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v5[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v5[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v5[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v5[6], w21
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	orr.8b	v6, v24, v5
	ldr	d7, [sp, #1064]                 ; 8-byte Folded Reload
	and.8b	v7, v7, v3
	eor.8b	v7, v7, v6
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v6, v7
	dup.8b	v17, w7
	bit.8b	v5, v16, v17
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x19, w3, sxtw]
	bic.8b	v3, v3, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v5, v5, v6
	str	q25, [sp, #4032]
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	str	q0, [sp, #4048]
	add	x3, sp, #4032
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v24, v5, v3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_694
; %bb.691:                              ; %convergence.cascade509
                                        ;   in Loop: Header=BB0_690 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_694
; %bb.692:                              ; %convergence.cascade509
                                        ;   in Loop: Header=BB0_690 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_690
	b	LBB0_694
LBB0_693:                               ; %schedule.37.convergence.cascade.exit510_crit_edge
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_694:                               ; %convergence.cascade.exit510
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_5
; %bb.695:                              ; %convergence.target.37.ready
                                        ;   in Loop: Header=BB0_10 Depth=3
	rbit	w1, w2
	clz	w1, w1
	ldp	q3, q0, [sp, #480]              ; 32-byte Folded Reload
	str	q0, [sp, #3968]
	str	q3, [sp, #3984]
	ldp	q3, q0, [sp, #448]              ; 32-byte Folded Reload
	str	q0, [sp, #4000]
	str	q3, [sp, #4016]
	and	x2, x1, #0x7
	add	x3, sp, #3968
	ldr	x2, [x3, x2, lsl #3]
	lsl	w1, w1, #2
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #2664
	sub	x1, x2, x1
	add	x1, x1, x3
	ldp	q18, q27, [x1, #992]
	ldr	q17, [x1, #2032]
	ldr	q7, [x1, #2016]
	ldr	q0, [x1, #3056]
	str	q0, [sp, #912]                  ; 16-byte Folded Spill
	ldr	q10, [x1, #3040]
	ldr	q11, [x1, #4080]
	ldr	q0, [x1, #4064]
	str	q0, [sp, #864]                  ; 16-byte Folded Spill
	movi.8b	v20, #1
	and.8b	v20, v24, v20
	ushll.8h	v20, v20, #0
	ushll.4s	v21, v20, #0
	ushll2.4s	v20, v20, #0
	mov.16b	v1, v30
	mov.16b	v30, v19
	mov.16b	v19, v26
	mov.16b	v26, v22
	ldp	q3, q22, [sp, #544]             ; 32-byte Folded Reload
	uaddw2.2d	v0, v3, v20
	uaddw.2d	v22, v22, v20
	stp	q0, q22, [sp, #544]             ; 32-byte Folded Spill
	mov.16b	v22, v26
	mov.16b	v26, v19
	mov.16b	v19, v30
	mov.16b	v30, v1
	uaddw2.2d	v23, v23, v21
	str	q23, [sp, #432]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #576]                  ; 16-byte Folded Reload
	uaddw.2d	v0, v0, v21
	str	q0, [sp, #576]                  ; 16-byte Folded Spill
	ldr	q20, [sp, #6640]
	ldr	q21, [sp, #6624]
	zip1.8b	v25, v24, v0
	ushll.4s	v25, v25, #0
	shl.4s	v25, v25, #31
	cmlt.4s	v25, v25, #0
	mov.16b	v5, v25
	bsl.16b	v5, v18, v21
	zip2.8b	v21, v24, v0
	ushll.4s	v21, v21, #0
	shl.4s	v21, v21, #31
	cmlt.4s	v21, v21, #0
	mov.16b	v3, v21
	bsl.16b	v3, v27, v20
	str	q3, [sp, #6640]
	str	q5, [sp, #6624]
	ldr	q3, [sp, #6608]
	ldr	q5, [sp, #6592]
	bit.16b	v5, v7, v25
	bit.16b	v3, v17, v21
	str	q3, [sp, #6608]
	str	q5, [sp, #6592]
	ldr	q3, [sp, #6576]
	ldr	q5, [sp, #6560]
	bit.16b	v5, v10, v25
	ldr	q0, [sp, #912]                  ; 16-byte Folded Reload
	bit.16b	v3, v0, v21
	str	q3, [sp, #6576]
	str	q5, [sp, #6560]
	ldr	q3, [sp, #6544]
	ldr	q5, [sp, #6528]
	ldr	q0, [sp, #864]                  ; 16-byte Folded Reload
	bit.16b	v5, v0, v25
	ldr	q25, [sp, #720]                 ; 16-byte Folded Reload
	bit.16b	v3, v11, v21
	str	q3, [sp, #6544]
	str	q5, [sp, #6528]
	b	LBB0_145
LBB0_696:                               ; %varying.coherent.false488
                                        ;   in Loop: Header=BB0_10 Depth=3
	tbz	w1, #0, LBB0_705
	b	LBB0_5
LBB0_697:                               ; %cond.store3807
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d21
	str	s17, [x2]
	tbz	w1, #1, LBB0_676
LBB0_698:                               ; %cond.store3811
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v21[1]
	st1.s	{ v17 }[1], [x2]
	tbz	w1, #2, LBB0_677
LBB0_699:                               ; %cond.store3815
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d20
	st1.s	{ v17 }[2], [x2]
	tbz	w1, #3, LBB0_678
LBB0_700:                               ; %cond.store3819
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v20[1]
	st1.s	{ v17 }[3], [x2]
	tbz	w1, #4, LBB0_679
LBB0_701:                               ; %cond.store3823
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d16
	str	s3, [x2]
	tbz	w1, #5, LBB0_680
LBB0_702:                               ; %cond.store3827
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x2, v16[1]
	st1.s	{ v3 }[1], [x2]
	tbz	w1, #6, LBB0_681
LBB0_703:                               ; %cond.store3831
                                        ;   in Loop: Header=BB0_10 Depth=3
	fmov	x2, d5
	st1.s	{ v3 }[2], [x2]
	tbz	w1, #7, LBB0_705
LBB0_704:                               ; %cond.store3835
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov.d	x1, v5[1]
	st1.s	{ v3 }[3], [x1]
LBB0_705:                               ; %schedule.36
                                        ;   in Loop: Header=BB0_10 Depth=3
	cbz	w0, LBB0_710
; %bb.706:                              ; %convergence.cascade491.preheader
                                        ;   in Loop: Header=BB0_10 Depth=3
	mov	w1, #0                          ; =0x0
LBB0_707:                               ; %convergence.cascade491
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_10 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v5, v3, v2
	addv.8b	b5, v5
	fmov	w2, s5
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #3936]
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	str	q0, [sp, #3952]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #3936
	ldr	w6, [x6, x2]
	cmp	w6, #14
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #7, lsl #12             ; =28672
	add	x5, x5, #2800
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s3, w19
	ubfx	w19, w20, #1, #1
	mov.b	v3[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v3[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v3[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v3[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v3[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v3[6], w19
	add	x19, sp, #7, lsl #12            ; =28672
	add	x19, x19, #2792
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s5, w21
	ubfx	w21, w20, #1, #1
	mov.b	v5[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v5[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v5[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v5[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v5[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v5[6], w21
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	orr.8b	v6, v24, v5
	ldr	d0, [sp, #1064]                 ; 8-byte Folded Reload
	and.8b	v7, v0, v3
	eor.8b	v7, v7, v6
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v6, v7
	dup.8b	v17, w7
	bit.8b	v5, v16, v17
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x19, w3, sxtw]
	bic.8b	v3, v3, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v5, v5, v6
	str	q25, [sp, #3904]
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	str	q0, [sp, #3920]
	add	x3, sp, #3904
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v24, v5, v3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_711
; %bb.708:                              ; %convergence.cascade491
                                        ;   in Loop: Header=BB0_707 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_711
; %bb.709:                              ; %convergence.cascade491
                                        ;   in Loop: Header=BB0_707 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_707
	b	LBB0_711
LBB0_710:                               ; %schedule.36.convergence.cascade.exit492_crit_edge
                                        ;   in Loop: Header=BB0_10 Depth=3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_711:                               ; %convergence.cascade.exit492
                                        ;   in Loop: Header=BB0_10 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_5
; %bb.712:                              ; %convergence.target.36.ready
                                        ;   in Loop: Header=BB0_10 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v24, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v5, v3, #0
	ushll2.4s	v3, v3, #0
	uaddw2.2d	v9, v9, v3
	ldr	q0, [sp, #880]                  ; 16-byte Folded Reload
	uaddw.2d	v0, v0, v3
	str	q0, [sp, #880]                  ; 16-byte Folded Spill
	uaddw2.2d	v19, v19, v5
	ldr	q0, [sp, #928]                  ; 16-byte Folded Reload
	uaddw.2d	v0, v0, v5
	b	LBB0_646
LBB0_713:                               ;   in Loop: Header=BB0_6 Depth=2
	mov.16b	v26, v1
	mov.16b	v19, v30
	mov.16b	v30, v9
	mov.16b	v9, v13
	mov.16b	v13, v14
	mov.16b	v14, v12
	mov.16b	v12, v15
	mov.16b	v15, v31
	mov.16b	v31, v4
	mov.16b	v4, v29
	ldr	q29, [sp, #864]                 ; 16-byte Folded Reload
	cbnz	x17, LBB0_6
	b	LBB0_744
LBB0_714:                               ;   in Loop: Header=BB0_6 Depth=2
	mov.16b	v3, v15
	mov.16b	v13, v9
	ldr	q4, [sp, #608]                  ; 16-byte Folded Reload
	ldp	q22, q8, [sp, #752]             ; 32-byte Folded Reload
	ldp	q0, q29, [sp, #848]             ; 32-byte Folded Reload
	ldr	q31, [sp, #912]                 ; 16-byte Folded Reload
	ldr	q14, [sp, #704]                 ; 16-byte Folded Reload
	mov.16b	v19, v1
	mov.16b	v15, v12
	mov.16b	v12, v0
	mov.16b	v9, v3
	ldr	q26, [sp, #816]                 ; 16-byte Folded Reload
	cbnz	x17, LBB0_6
	b	LBB0_744
LBB0_715:                               ;   in Loop: Header=BB0_6 Depth=2
	mov.16b	v19, v30
	mov.16b	v30, v9
	mov.16b	v9, v13
	mov.16b	v13, v14
	mov.16b	v14, v12
	mov.16b	v12, v15
	mov.16b	v15, v31
	mov.16b	v31, v4
	mov.16b	v4, v29
	mov.16b	v29, v8
	ldr	q8, [sp, #768]                  ; 16-byte Folded Reload
	cbnz	x17, LBB0_6
	b	LBB0_744
LBB0_716:                               ;   in Loop: Header=BB0_6 Depth=2
	mov.16b	v26, v27
	mov.16b	v19, v28
	cbnz	x17, LBB0_6
	b	LBB0_744
LBB0_717:                               ;   in Loop: Header=BB0_6 Depth=2
	ldp	q12, q29, [sp, #848]            ; 32-byte Folded Reload
	ldr	q16, [sp, #688]                 ; 16-byte Folded Reload
	ldp	q8, q15, [sp, #768]             ; 32-byte Folded Reload
	ldr	q19, [sp, #592]                 ; 16-byte Folded Reload
	ldp	q1, q26, [sp, #800]             ; 32-byte Folded Reload
	ldr	q31, [sp, #912]                 ; 16-byte Folded Reload
	mov.16b	v6, v9
	mov.16b	v9, v16
	ldr	q13, [sp, #736]                 ; 16-byte Folded Reload
	mov.16b	v14, v6
	mov.16b	v22, v30
	mov.16b	v30, v1
	cbnz	x17, LBB0_6
	b	LBB0_744
LBB0_718:                               ;   in Loop: Header=BB0_6 Depth=2
	mov.16b	v16, v4
	mov.16b	v0, v30
	ldr	q30, [sp, #800]                 ; 16-byte Folded Reload
	ldr	q4, [sp, #912]                  ; 16-byte Folded Reload
	ldr	q12, [sp, #848]                 ; 16-byte Folded Reload
	ldr	q3, [sp, #688]                  ; 16-byte Folded Reload
	mov.16b	v29, v9
	mov.16b	v7, v31
	mov.16b	v31, v4
	mov.16b	v4, v16
	mov.16b	v1, v15
	mov.16b	v19, v0
	ldr	q22, [sp, #752]                 ; 16-byte Folded Reload
	mov.16b	v15, v14
	mov.16b	v14, v7
	mov.16b	v26, v13
	mov.16b	v13, v1
	mov.16b	v9, v3
	cbnz	x17, LBB0_6
	b	LBB0_744
LBB0_719:                               ; %varying.coherent.false
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w1, #0xff
	b.eq	LBB0_5
LBB0_720:                               ; %schedule.38
                                        ;   in Loop: Header=BB0_6 Depth=2
	cbz	w0, LBB0_3
; %bb.721:                              ; %convergence.cascade538.preheader
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w1, #0                          ; =0x0
LBB0_722:                               ; %convergence.cascade538
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v5, v3, v2
	addv.8b	b5, v5
	fmov	w2, s5
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	str	q0, [sp, #4784]
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	str	q0, [sp, #4800]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #1, lsl #12             ; =4096
	add	x6, x6, #688
	ldr	w6, [x6, x2]
	cmp	w6, #0
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #7, lsl #12             ; =28672
	add	x5, x5, #2800
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s3, w19
	ubfx	w19, w20, #1, #1
	mov.b	v3[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v3[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v3[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v3[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v3[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v3[6], w19
	add	x19, sp, #7, lsl #12            ; =28672
	add	x19, x19, #2792
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s5, w21
	ubfx	w21, w20, #1, #1
	mov.b	v5[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v5[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v5[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v5[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v5[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v5[6], w21
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	orr.8b	v6, v24, v5
	ldr	d0, [sp, #1064]                 ; 8-byte Folded Reload
	and.8b	v7, v0, v3
	eor.8b	v7, v7, v6
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v6, v7
	dup.8b	v17, w7
	bit.8b	v5, v16, v17
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x19, w3, sxtw]
	bic.8b	v3, v3, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v5, v5, v6
	str	q25, [sp, #4752]
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	str	q0, [sp, #4768]
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #656
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v24, v5, v3
	shl.8b	v3, v24, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_4
; %bb.723:                              ; %convergence.cascade538
                                        ;   in Loop: Header=BB0_722 Depth=3
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_4
; %bb.724:                              ; %convergence.cascade538
                                        ;   in Loop: Header=BB0_722 Depth=3
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_722
	b	LBB0_4
LBB0_725:                               ;   in Loop: Header=BB0_6 Depth=2
	ldr	q26, [sp, #816]                 ; 16-byte Folded Reload
	ldr	q25, [sp, #720]                 ; 16-byte Folded Reload
	mov.16b	v30, v14
	ldr	q3, [sp, #912]                  ; 16-byte Folded Reload
	ldr	q19, [sp, #592]                 ; 16-byte Folded Reload
	ldr	q22, [sp, #752]                 ; 16-byte Folded Reload
	ldp	q9, q14, [sp, #688]             ; 32-byte Folded Reload
	mov.16b	v5, v31
	mov.16b	v31, v3
	mov.16b	v15, v28
	mov.16b	v13, v1
	mov.16b	v4, v0
	mov.16b	v12, v8
	mov.16b	v8, v5
	cbnz	x17, LBB0_6
	b	LBB0_744
LBB0_726:                               ;   in Loop: Header=BB0_6 Depth=2
	ldp	q1, q26, [sp, #800]             ; 32-byte Folded Reload
	ldr	q5, [sp, #1024]                 ; 16-byte Folded Reload
	ldr	q25, [sp, #720]                 ; 16-byte Folded Reload
	ldr	q12, [sp, #848]                 ; 16-byte Folded Reload
	ldr	q18, [sp, #688]                 ; 16-byte Folded Reload
	mov.16b	v8, v28
	str	q5, [sp, #1024]                 ; 16-byte Folded Spill
	ldp	q21, q4, [sp, #592]             ; 32-byte Folded Reload
	mov.16b	v19, v30
	ldr	q22, [sp, #752]                 ; 16-byte Folded Reload
	mov.16b	v14, v9
	mov.16b	v9, v18
	mov.16b	v30, v1
	mov.16b	v29, v19
	mov.16b	v19, v21
	cbnz	x17, LBB0_6
	b	LBB0_744
LBB0_727:                               ;   in Loop: Header=BB0_6 Depth=2
	ldp	q30, q26, [sp, #800]            ; 32-byte Folded Reload
	ldp	q25, q13, [sp, #720]            ; 32-byte Folded Reload
	ldr	q0, [sp, #944]                  ; 16-byte Folded Reload
	ldr	q31, [sp, #912]                 ; 16-byte Folded Reload
	str	q0, [sp, #944]                  ; 16-byte Folded Spill
	ldr	q16, [sp, #592]                 ; 16-byte Folded Reload
	mov.16b	v12, v1
	ldr	q29, [sp, #864]                 ; 16-byte Folded Reload
	mov.16b	v21, v19
	mov.16b	v19, v4
	ldr	q4, [sp, #768]                  ; 16-byte Folded Reload
	ldr	q14, [sp, #704]                 ; 16-byte Folded Reload
	mov.16b	v22, v21
	mov.16b	v15, v8
	mov.16b	v8, v4
	mov.16b	v4, v19
	mov.16b	v19, v16
	cbnz	x17, LBB0_6
	b	LBB0_744
LBB0_728:                               ;   in Loop: Header=BB0_6 Depth=2
	ldp	q14, q25, [sp, #704]            ; 32-byte Folded Reload
	mov.16b	v16, v30
	ldp	q30, q26, [sp, #800]            ; 32-byte Folded Reload
	ldr	q9, [sp, #688]                  ; 16-byte Folded Reload
	ldp	q22, q21, [sp, #752]            ; 32-byte Folded Reload
	ldr	q4, [sp, #608]                  ; 16-byte Folded Reload
	mov.16b	v19, v16
	mov.16b	v31, v12
	mov.16b	v12, v13
	mov.16b	v13, v8
	mov.16b	v8, v21
	cbnz	x17, LBB0_6
	b	LBB0_744
LBB0_729:                               ;   in Loop: Header=BB0_6 Depth=2
	ldr	q26, [sp, #816]                 ; 16-byte Folded Reload
	ldr	q25, [sp, #720]                 ; 16-byte Folded Reload
	ldr	q12, [sp, #848]                 ; 16-byte Folded Reload
	ldr	q5, [sp, #688]                  ; 16-byte Folded Reload
	mov.16b	v13, v8
	mov.16b	v8, v29
	mov.16b	v20, v30
	mov.16b	v30, v9
	mov.16b	v14, v1
	mov.16b	v29, v22
	ldr	q22, [sp, #752]                 ; 16-byte Folded Reload
	ldr	q4, [sp, #608]                  ; 16-byte Folded Reload
	mov.16b	v9, v5
	mov.16b	v19, v20
	cbnz	x17, LBB0_6
	b	LBB0_744
LBB0_730:                               ; %convergence.target.38.ready
                                        ;   in Loop: Header=BB0_2 Depth=1
	mov.16b	v1, v19
	ldr	d0, [sp, #1064]                 ; 8-byte Folded Reload
	bic.8b	v0, v0, v24
	str	d0, [sp, #1064]                 ; 8-byte Folded Spill
	tst	w16, #0xff
	b.eq	LBB0_743
; %bb.731:                              ; %return.frame.cleanup
                                        ;   in Loop: Header=BB0_2 Depth=1
	ldrb	w0, [x8, #8]
	and	w1, w0, #0x1
	fmov	s3, w1
	ubfx	w1, w0, #1, #1
	mov.b	v3[1], w1
	ubfx	w1, w0, #2, #1
	mov.b	v3[2], w1
	ubfx	w1, w0, #3, #1
	mov.b	v3[3], w1
	ubfx	w1, w0, #4, #1
	mov.b	v3[4], w1
	ubfx	w1, w0, #5, #1
	mov.b	v3[5], w1
	ubfx	w1, w0, #6, #1
	mov.b	v3[6], w1
	lsr	w0, w0, #7
	mov.b	v3[7], w0
	ldrb	w0, [x8]
	and	w1, w0, #0x1
	fmov	s6, w1
	ubfx	w1, w0, #1, #1
	mov.b	v6[1], w1
	ubfx	w1, w0, #2, #1
	mov.b	v6[2], w1
	ubfx	w1, w0, #3, #1
	mov.b	v6[3], w1
	ubfx	w1, w0, #4, #1
	mov.b	v6[4], w1
	ubfx	w1, w0, #5, #1
	mov.b	v6[5], w1
	ubfx	w1, w0, #6, #1
	mov.b	v6[6], w1
	lsr	w0, w0, #7
	mov.b	v6[7], w0
	ldr	d0, [sp, #1064]                 ; 8-byte Folded Reload
	and.8b	v7, v0, v3
	eor.8b	v3, v6, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v5, v3, #0
	umaxv.8b	b3, v5
	fmov	w0, s3
	eor	w0, w0, #0x1
	and	w1, w16, w0
	dup.8b	v3, w1
	and.8b	v3, v3, v6
	shl.8b	v16, v3, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v2
	addv.8b	b16, v16
	fmov	w0, s16
	tst	w1, #0x1
	csetm	w1, ne
	dup.8b	v17, w1
	bic.8b	v7, v7, v17
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	str	b7, [x8, #8]
	bic.8b	v6, v6, v17
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	str	b6, [x8]
	cmp	x17, #8
	ldp	q18, q0, [sp, #560]             ; 32-byte Folded Reload
	ldr	q19, [sp, #544]                 ; 16-byte Folded Reload
	b.lo	LBB0_733
; %bb.732:                              ; %return.frame.cleanup
                                        ;   in Loop: Header=BB0_2 Depth=1
	tst	w0, #0xff
	b.ne	LBB0_746
LBB0_733:                               ; %ready.overflow.resume560
                                        ;   in Loop: Header=BB0_2 Depth=1
	fmov	s6, wzr
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	fmov	w1, s5
	cmeq.8b	v5, v16, v6
	mvn.8b	v5, v5
	umov.b	w2, v5[0]
	sbfx	w3, w2, #0, #1
	fmov	s5, w3
	sbfx	w3, w2, #1, #1
	mov.b	v5[1], w3
	sbfx	w3, w2, #2, #1
	mov.b	v5[2], w3
	sbfx	w3, w2, #3, #1
	mov.b	v5[3], w3
	sbfx	w3, w2, #4, #1
	mov.b	v5[4], w3
	sbfx	w3, w2, #5, #1
	mov.b	v5[5], w3
	sbfx	w3, w2, #6, #1
	mov.b	v5[6], w3
	sbfx	w2, w2, #7, #1
	mov.b	v5[7], w2
	and	w2, w16, #0xfffffffe
	tst	w1, #0xff
	csel	w1, w2, w16, eq
	sxtw	x16, w17
	tst	w0, #0xff
	csel	x2, x16, xzr, ne
	add	x16, sp, #7, lsl #12            ; =28672
	add	x16, x16, #2872
	ldrb	w0, [x16, x2]
	and	w3, w0, #0x1
	fmov	s6, w3
	ubfx	w3, w0, #1, #1
	mov.b	v6[1], w3
	ubfx	w3, w0, #2, #1
	mov.b	v6[2], w3
	ubfx	w3, w0, #3, #1
	mov.b	v6[3], w3
	ubfx	w3, w0, #4, #1
	mov.b	v6[4], w3
	ubfx	w3, w0, #5, #1
	mov.b	v6[5], w3
	ubfx	w3, w0, #6, #1
	mov.b	v6[6], w3
	lsr	w0, w0, #7
	mov.b	v6[7], w0
	bif.8b	v3, v6, v5
	ldr	q5, [sp, #1088]                 ; 16-byte Folded Reload
	fmov	w3, s5
Lloh82:
	adrp	x0, l_convergence.targets@PAGE
Lloh83:
	add	x0, x0, l_convergence.targets@PAGEOFF
	add	x4, x0, w3, sxtw #2
	fmov	w5, s25
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x16, x2]
	lsl	x6, x2, #2
	add	x3, sp, #7, lsl #12             ; =28672
	add	x3, x3, #2840
	add	x2, x3, x6
	csel	x4, x4, x2, ne
	ldr	w4, [x4]
	str	w4, [x2]
	add	x2, sp, #7, lsl #12             ; =28672
	add	x2, x2, #2808
	ldr	w4, [x2, x6]
	csel	w4, w5, w4, ne
	str	w4, [x2, x6]
	cinc	w17, w17, ne
	and	w4, w1, #0x2
	ldrb	w5, [x8, #9]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	ldrb	w5, [x8, #1]
	and	w6, w5, #0x1
	fmov	s6, w6
	ubfx	w6, w5, #1, #1
	mov.b	v6[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v6[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v6[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v6[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v6[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v6[6], w6
	lsr	w5, w5, #7
	mov.b	v6[7], w5
	ldr	d5, [sp, #1064]                 ; 8-byte Folded Reload
	and.8b	v7, v5, v3
	eor.8b	v3, v6, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v5, v3, #0
	umaxv.8b	b3, v5
	fmov	w5, s3
	eor	w5, w5, #0x1
	ands	w4, w5, w4, lsr #1
	dup.8b	v3, w4
	and.8b	v3, v3, v6
	shl.8b	v16, v3, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v2
	addv.8b	b16, v16
	fmov	w4, s16
	csetm	w5, ne
	dup.8b	v17, w5
	bic.8b	v7, v7, v17
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	stur	b7, [x8, #9]
	bic.8b	v6, v6, v17
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #1]
	cmp	w17, #8
	and	w5, w4, #0xff
	ccmp	w5, #0, #4, hs
	b.ne	LBB0_746
; %bb.734:                              ; %ready.overflow.resume566
                                        ;   in Loop: Header=BB0_2 Depth=1
	fmov	s6, wzr
	and.8b	v5, v5, v2
	cmeq.8b	v6, v16, v6
	mvn.8b	v6, v6
	umov.b	w5, v6[0]
	addv.8b	b6, v5
	sbfx	w6, w5, #0, #1
	fmov	s5, w6
	sbfx	w6, w5, #1, #1
	mov.b	v5[1], w6
	sbfx	w6, w5, #2, #1
	mov.b	v5[2], w6
	sbfx	w6, w5, #3, #1
	mov.b	v5[3], w6
	sbfx	w6, w5, #4, #1
	mov.b	v5[4], w6
	sbfx	w6, w5, #5, #1
	mov.b	v5[5], w6
	sbfx	w6, w5, #6, #1
	mov.b	v5[6], w6
	sbfx	w5, w5, #7, #1
	mov.b	v5[7], w5
	fmov	w5, s6
	and	w6, w1, #0xfffffffd
	tst	w5, #0xff
	csel	w1, w6, w1, eq
	sxtw	x5, w17
	tst	w4, #0xff
	csel	x4, x5, xzr, ne
	ldrb	w5, [x16, x4]
	and	w6, w5, #0x1
	fmov	s6, w6
	ubfx	w6, w5, #1, #1
	mov.b	v6[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v6[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v6[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v6[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v6[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v6[6], w6
	lsr	w5, w5, #7
	mov.b	v6[7], w5
	bif.8b	v3, v6, v5
	ldr	q5, [sp, #1088]                 ; 16-byte Folded Reload
	mov.s	w5, v5[1]
	add	x5, x0, w5, sxtw #2
	mov.s	w6, v25[1]
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x16, x4]
	lsl	x16, x4, #2
	add	x3, x3, x16
	csel	x4, x5, x3, ne
	ldr	w4, [x4]
	str	w4, [x3]
	ldr	w3, [x2, x16]
	csel	w3, w6, w3, ne
	str	w3, [x2, x16]
	cinc	w3, w17, ne
	and	w16, w1, #0x4
	ldrb	w17, [x8, #10]
	and	w2, w17, #0x1
	fmov	s3, w2
	ubfx	w2, w17, #1, #1
	mov.b	v3[1], w2
	ubfx	w2, w17, #2, #1
	mov.b	v3[2], w2
	ubfx	w2, w17, #3, #1
	mov.b	v3[3], w2
	ubfx	w2, w17, #4, #1
	mov.b	v3[4], w2
	ubfx	w2, w17, #5, #1
	mov.b	v3[5], w2
	ubfx	w2, w17, #6, #1
	mov.b	v3[6], w2
	lsr	w17, w17, #7
	mov.b	v3[7], w17
	ldrb	w17, [x8, #2]
	and	w2, w17, #0x1
	fmov	s6, w2
	ubfx	w2, w17, #1, #1
	mov.b	v6[1], w2
	ubfx	w2, w17, #2, #1
	mov.b	v6[2], w2
	ubfx	w2, w17, #3, #1
	mov.b	v6[3], w2
	ubfx	w2, w17, #4, #1
	mov.b	v6[4], w2
	ubfx	w2, w17, #5, #1
	mov.b	v6[5], w2
	ubfx	w2, w17, #6, #1
	mov.b	v6[6], w2
	lsr	w17, w17, #7
	mov.b	v6[7], w17
	ldr	d5, [sp, #1064]                 ; 8-byte Folded Reload
	and.8b	v7, v5, v3
	eor.8b	v3, v6, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v5, v3, #0
	umaxv.8b	b3, v5
	fmov	w17, s3
	eor	w17, w17, #0x1
	ands	w16, w17, w16, lsr #2
	dup.8b	v3, w16
	and.8b	v3, v3, v6
	shl.8b	v16, v3, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v2
	addv.8b	b16, v16
	fmov	w16, s16
	csetm	w17, ne
	dup.8b	v17, w17
	bic.8b	v7, v7, v17
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	stur	b7, [x8, #10]
	bic.8b	v6, v6, v17
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #2]
	cmp	w3, #8
	and	w17, w16, #0xff
	ccmp	w17, #0, #4, hs
	b.ne	LBB0_746
; %bb.735:                              ; %ready.overflow.resume572
                                        ;   in Loop: Header=BB0_2 Depth=1
	fmov	s6, wzr
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	fmov	w17, s5
	cmeq.8b	v5, v16, v6
	mvn.8b	v5, v5
	umov.b	w2, v5[0]
	sbfx	w4, w2, #0, #1
	fmov	s5, w4
	sbfx	w4, w2, #1, #1
	mov.b	v5[1], w4
	sbfx	w4, w2, #2, #1
	mov.b	v5[2], w4
	sbfx	w4, w2, #3, #1
	mov.b	v5[3], w4
	sbfx	w4, w2, #4, #1
	mov.b	v5[4], w4
	sbfx	w4, w2, #5, #1
	mov.b	v5[5], w4
	sbfx	w4, w2, #6, #1
	mov.b	v5[6], w4
	sbfx	w2, w2, #7, #1
	mov.b	v5[7], w2
	and	w2, w1, #0xfffffffb
	tst	w17, #0xff
	csel	w17, w2, w1, eq
	sxtw	x1, w3
	tst	w16, #0xff
	csel	x1, x1, xzr, ne
	add	x16, sp, #7, lsl #12            ; =28672
	add	x16, x16, #2872
	ldrb	w2, [x16, x1]
	and	w4, w2, #0x1
	fmov	s6, w4
	ubfx	w4, w2, #1, #1
	mov.b	v6[1], w4
	ubfx	w4, w2, #2, #1
	mov.b	v6[2], w4
	ubfx	w4, w2, #3, #1
	mov.b	v6[3], w4
	ubfx	w4, w2, #4, #1
	mov.b	v6[4], w4
	ubfx	w4, w2, #5, #1
	mov.b	v6[5], w4
	ubfx	w4, w2, #6, #1
	mov.b	v6[6], w4
	lsr	w2, w2, #7
	mov.b	v6[7], w2
	bif.8b	v3, v6, v5
	ldr	q5, [sp, #1088]                 ; 16-byte Folded Reload
	mov.s	w2, v5[2]
	add	x4, x0, w2, sxtw #2
	mov.s	w5, v25[2]
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x16, x1]
	lsl	x6, x1, #2
	add	x2, sp, #7, lsl #12             ; =28672
	add	x2, x2, #2840
	add	x1, x2, x6
	csel	x4, x4, x1, ne
	ldr	w4, [x4]
	str	w4, [x1]
	add	x1, sp, #7, lsl #12             ; =28672
	add	x1, x1, #2808
	ldr	w4, [x1, x6]
	csel	w4, w5, w4, ne
	str	w4, [x1, x6]
	cinc	w3, w3, ne
	and	w4, w17, #0x8
	ldrb	w5, [x8, #11]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	ldrb	w5, [x8, #3]
	and	w6, w5, #0x1
	fmov	s6, w6
	ubfx	w6, w5, #1, #1
	mov.b	v6[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v6[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v6[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v6[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v6[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v6[6], w6
	lsr	w5, w5, #7
	mov.b	v6[7], w5
	ldr	d5, [sp, #1064]                 ; 8-byte Folded Reload
	and.8b	v7, v5, v3
	eor.8b	v3, v6, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v5, v3, #0
	umaxv.8b	b3, v5
	fmov	w5, s3
	eor	w5, w5, #0x1
	ands	w4, w5, w4, lsr #3
	dup.8b	v3, w4
	and.8b	v3, v3, v6
	shl.8b	v16, v3, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v2
	addv.8b	b16, v16
	fmov	w5, s16
	csetm	w4, ne
	dup.8b	v17, w4
	bic.8b	v7, v7, v17
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	stur	b7, [x8, #11]
	bic.8b	v6, v6, v17
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #3]
	cmp	w3, #8
	and	w4, w5, #0xff
	ccmp	w4, #0, #4, hs
	b.ne	LBB0_746
; %bb.736:                              ; %ready.overflow.resume578
                                        ;   in Loop: Header=BB0_2 Depth=1
	fmov	s6, wzr
	and.8b	v5, v5, v2
	cmeq.8b	v6, v16, v6
	mvn.8b	v6, v6
	umov.b	w4, v6[0]
	addv.8b	b6, v5
	sbfx	w6, w4, #0, #1
	fmov	s5, w6
	sbfx	w6, w4, #1, #1
	mov.b	v5[1], w6
	sbfx	w6, w4, #2, #1
	mov.b	v5[2], w6
	sbfx	w6, w4, #3, #1
	mov.b	v5[3], w6
	sbfx	w6, w4, #4, #1
	mov.b	v5[4], w6
	sbfx	w6, w4, #5, #1
	mov.b	v5[5], w6
	sbfx	w6, w4, #6, #1
	mov.b	v5[6], w6
	sbfx	w4, w4, #7, #1
	mov.b	v5[7], w4
	fmov	w4, s6
	and	w6, w17, #0xfffffff7
	tst	w4, #0xff
	csel	w4, w6, w17, eq
	sxtw	x17, w3
	tst	w5, #0xff
	csel	x17, x17, xzr, ne
	ldrb	w5, [x16, x17]
	and	w6, w5, #0x1
	fmov	s6, w6
	ubfx	w6, w5, #1, #1
	mov.b	v6[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v6[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v6[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v6[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v6[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v6[6], w6
	lsr	w5, w5, #7
	mov.b	v6[7], w5
	bif.8b	v3, v6, v5
	ldr	q5, [sp, #1088]                 ; 16-byte Folded Reload
	mov.s	w5, v5[3]
	add	x5, x0, w5, sxtw #2
	mov.s	w6, v25[3]
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x16, x17]
	lsl	x16, x17, #2
	add	x17, x2, x16
	csel	x2, x5, x17, ne
	ldr	w2, [x2]
	str	w2, [x17]
	ldr	w17, [x1, x16]
	csel	w17, w6, w17, ne
	str	w17, [x1, x16]
	cinc	w17, w3, ne
	and	w16, w4, #0x10
	ldrb	w1, [x8, #12]
	and	w2, w1, #0x1
	fmov	s3, w2
	ubfx	w2, w1, #1, #1
	mov.b	v3[1], w2
	ubfx	w2, w1, #2, #1
	mov.b	v3[2], w2
	ubfx	w2, w1, #3, #1
	mov.b	v3[3], w2
	ubfx	w2, w1, #4, #1
	mov.b	v3[4], w2
	ubfx	w2, w1, #5, #1
	mov.b	v3[5], w2
	ubfx	w2, w1, #6, #1
	mov.b	v3[6], w2
	lsr	w1, w1, #7
	mov.b	v3[7], w1
	ldrb	w1, [x8, #4]
	and	w2, w1, #0x1
	fmov	s6, w2
	ubfx	w2, w1, #1, #1
	mov.b	v6[1], w2
	ubfx	w2, w1, #2, #1
	mov.b	v6[2], w2
	ubfx	w2, w1, #3, #1
	mov.b	v6[3], w2
	ubfx	w2, w1, #4, #1
	mov.b	v6[4], w2
	ubfx	w2, w1, #5, #1
	mov.b	v6[5], w2
	ubfx	w2, w1, #6, #1
	mov.b	v6[6], w2
	lsr	w1, w1, #7
	mov.b	v6[7], w1
	ldr	d5, [sp, #1064]                 ; 8-byte Folded Reload
	and.8b	v7, v5, v3
	eor.8b	v3, v6, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v5, v3, #0
	umaxv.8b	b3, v5
	fmov	w1, s3
	eor	w1, w1, #0x1
	ands	w16, w1, w16, lsr #4
	dup.8b	v3, w16
	and.8b	v3, v3, v6
	shl.8b	v16, v3, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v2
	addv.8b	b16, v16
	fmov	w16, s16
	csetm	w1, ne
	dup.8b	v17, w1
	bic.8b	v7, v7, v17
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	stur	b7, [x8, #12]
	bic.8b	v6, v6, v17
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #4]
	cmp	w17, #8
	and	w1, w16, #0xff
	ccmp	w1, #0, #4, hs
	b.ne	LBB0_746
; %bb.737:                              ; %ready.overflow.resume584
                                        ;   in Loop: Header=BB0_2 Depth=1
	fmov	s6, wzr
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	cmeq.8b	v6, v16, v6
	mvn.8b	v6, v6
	umov.b	w1, v6[0]
	fmov	w2, s5
	sbfx	w3, w1, #0, #1
	fmov	s5, w3
	sbfx	w3, w1, #1, #1
	mov.b	v5[1], w3
	sbfx	w3, w1, #2, #1
	mov.b	v5[2], w3
	sbfx	w3, w1, #3, #1
	mov.b	v5[3], w3
	sbfx	w3, w1, #4, #1
	mov.b	v5[4], w3
	sbfx	w3, w1, #5, #1
	mov.b	v5[5], w3
	sbfx	w3, w1, #6, #1
	mov.b	v5[6], w3
	sbfx	w1, w1, #7, #1
	mov.b	v5[7], w1
	and	w1, w4, #0xffffffef
	tst	w2, #0xff
	csel	w2, w1, w4, eq
	sxtw	x1, w17
	tst	w16, #0xff
	csel	x1, x1, xzr, ne
	add	x16, sp, #7, lsl #12            ; =28672
	add	x16, x16, #2872
	ldrb	w3, [x16, x1]
	and	w4, w3, #0x1
	fmov	s6, w4
	ubfx	w4, w3, #1, #1
	mov.b	v6[1], w4
	ubfx	w4, w3, #2, #1
	mov.b	v6[2], w4
	ubfx	w4, w3, #3, #1
	mov.b	v6[3], w4
	ubfx	w4, w3, #4, #1
	mov.b	v6[4], w4
	ubfx	w4, w3, #5, #1
	mov.b	v6[5], w4
	ubfx	w4, w3, #6, #1
	mov.b	v6[6], w4
	lsr	w3, w3, #7
	mov.b	v6[7], w3
	bif.8b	v3, v6, v5
	ldr	q5, [sp, #1104]                 ; 16-byte Folded Reload
	fmov	w3, s5
	add	x4, x0, w3, sxtw #2
	ldr	q5, [sp, #1072]                 ; 16-byte Folded Reload
	fmov	w5, s5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x16, x1]
	lsl	x6, x1, #2
	add	x3, sp, #7, lsl #12             ; =28672
	add	x3, x3, #2840
	add	x1, x3, x6
	csel	x4, x4, x1, ne
	ldr	w4, [x4]
	str	w4, [x1]
	add	x1, sp, #7, lsl #12             ; =28672
	add	x1, x1, #2808
	ldr	w4, [x1, x6]
	csel	w4, w5, w4, ne
	str	w4, [x1, x6]
	cinc	w4, w17, ne
	and	w17, w2, #0x20
	ldrb	w5, [x8, #13]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	ldrb	w5, [x8, #5]
	and	w6, w5, #0x1
	fmov	s6, w6
	ubfx	w6, w5, #1, #1
	mov.b	v6[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v6[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v6[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v6[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v6[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v6[6], w6
	lsr	w5, w5, #7
	mov.b	v6[7], w5
	ldr	d5, [sp, #1064]                 ; 8-byte Folded Reload
	and.8b	v7, v5, v3
	eor.8b	v3, v6, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v5, v3, #0
	umaxv.8b	b3, v5
	fmov	w5, s3
	eor	w5, w5, #0x1
	ands	w17, w5, w17, lsr #5
	dup.8b	v3, w17
	and.8b	v3, v3, v6
	shl.8b	v16, v3, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v2
	addv.8b	b16, v16
	fmov	w5, s16
	csetm	w17, ne
	dup.8b	v17, w17
	bic.8b	v7, v7, v17
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	stur	b7, [x8, #13]
	bic.8b	v6, v6, v17
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #5]
	cmp	w4, #8
	and	w17, w5, #0xff
	ccmp	w17, #0, #4, hs
	b.ne	LBB0_746
; %bb.738:                              ; %ready.overflow.resume590
                                        ;   in Loop: Header=BB0_2 Depth=1
	fmov	s6, wzr
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	fmov	w17, s5
	cmeq.8b	v5, v16, v6
	mvn.8b	v5, v5
	umov.b	w6, v5[0]
	sbfx	w7, w6, #0, #1
	fmov	s5, w7
	sbfx	w7, w6, #1, #1
	mov.b	v5[1], w7
	sbfx	w7, w6, #2, #1
	mov.b	v5[2], w7
	sbfx	w7, w6, #3, #1
	mov.b	v5[3], w7
	sbfx	w7, w6, #4, #1
	mov.b	v5[4], w7
	sbfx	w7, w6, #5, #1
	mov.b	v5[5], w7
	sbfx	w7, w6, #6, #1
	mov.b	v5[6], w7
	sbfx	w6, w6, #7, #1
	mov.b	v5[7], w6
	and	w6, w2, #0xffffffdf
	tst	w17, #0xff
	csel	w17, w6, w2, eq
	sxtw	x2, w4
	tst	w5, #0xff
	csel	x2, x2, xzr, ne
	ldrb	w5, [x16, x2]
	and	w6, w5, #0x1
	fmov	s6, w6
	ubfx	w6, w5, #1, #1
	mov.b	v6[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v6[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v6[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v6[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v6[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v6[6], w6
	lsr	w5, w5, #7
	mov.b	v6[7], w5
	ldr	q7, [sp, #1104]                 ; 16-byte Folded Reload
	mov.s	w5, v7[1]
	bif.8b	v3, v6, v5
	add	x5, x0, w5, sxtw #2
	ldr	q5, [sp, #1072]                 ; 16-byte Folded Reload
	mov.s	w6, v5[1]
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x16, x2]
	lsl	x16, x2, #2
	add	x2, x3, x16
	csel	x3, x5, x2, ne
	ldr	w3, [x3]
	str	w3, [x2]
	ldr	w2, [x1, x16]
	csel	w2, w6, w2, ne
	str	w2, [x1, x16]
	cinc	w16, w4, ne
	ldrb	w1, [x8, #14]
	and	w2, w1, #0x1
	fmov	s3, w2
	ubfx	w2, w1, #1, #1
	mov.b	v3[1], w2
	ubfx	w2, w1, #2, #1
	mov.b	v3[2], w2
	ubfx	w2, w1, #3, #1
	mov.b	v3[3], w2
	ubfx	w2, w1, #4, #1
	mov.b	v3[4], w2
	ubfx	w2, w1, #5, #1
	mov.b	v3[5], w2
	ubfx	w2, w1, #6, #1
	mov.b	v3[6], w2
	lsr	w1, w1, #7
	mov.b	v3[7], w1
	ldrb	w1, [x8, #6]
	and	w2, w1, #0x1
	fmov	s6, w2
	ubfx	w2, w1, #1, #1
	mov.b	v6[1], w2
	ubfx	w2, w1, #2, #1
	mov.b	v6[2], w2
	ubfx	w2, w1, #3, #1
	mov.b	v6[3], w2
	ubfx	w2, w1, #4, #1
	mov.b	v6[4], w2
	ubfx	w2, w1, #5, #1
	mov.b	v6[5], w2
	ubfx	w2, w1, #6, #1
	mov.b	v6[6], w2
	and	w2, w17, #0x40
	lsr	w1, w1, #7
	mov.b	v6[7], w1
	ldr	d5, [sp, #1064]                 ; 8-byte Folded Reload
	and.8b	v7, v5, v3
	eor.8b	v3, v6, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v5, v3, #0
	umaxv.8b	b3, v5
	fmov	w1, s3
	eor	w1, w1, #0x1
	ands	w1, w1, w2, lsr #6
	dup.8b	v3, w1
	and.8b	v3, v3, v6
	shl.8b	v16, v3, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v2
	addv.8b	b16, v16
	fmov	w1, s16
	csetm	w2, ne
	dup.8b	v17, w2
	bic.8b	v7, v7, v17
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	stur	b7, [x8, #14]
	bic.8b	v6, v6, v17
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #6]
	cmp	w16, #8
	b.lo	LBB0_740
; %bb.739:                              ; %ready.overflow.resume590
                                        ;   in Loop: Header=BB0_2 Depth=1
	tst	w1, #0xff
	b.ne	LBB0_746
LBB0_740:                               ; %ready.overflow.resume596
                                        ;   in Loop: Header=BB0_2 Depth=1
	fmov	s6, wzr
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	fmov	w2, s5
	cmeq.8b	v5, v16, v6
	mvn.8b	v5, v5
	umov.b	w3, v5[0]
	sbfx	w4, w3, #0, #1
	fmov	s5, w4
	sbfx	w4, w3, #1, #1
	mov.b	v5[1], w4
	sbfx	w4, w3, #2, #1
	mov.b	v5[2], w4
	sbfx	w4, w3, #3, #1
	mov.b	v5[3], w4
	sbfx	w4, w3, #4, #1
	mov.b	v5[4], w4
	sbfx	w4, w3, #5, #1
	mov.b	v5[5], w4
	sbfx	w4, w3, #6, #1
	mov.b	v5[6], w4
	sbfx	w3, w3, #7, #1
	mov.b	v5[7], w3
	and	w3, w17, #0xffffffbf
	tst	w2, #0xff
	csel	w3, w3, w17, eq
	sxtw	x17, w16
	tst	w1, #0xff
	csel	x1, x17, xzr, ne
	add	x17, sp, #7, lsl #12            ; =28672
	add	x17, x17, #2872
	ldrb	w2, [x17, x1]
	and	w4, w2, #0x1
	fmov	s6, w4
	ubfx	w4, w2, #1, #1
	mov.b	v6[1], w4
	ubfx	w4, w2, #2, #1
	mov.b	v6[2], w4
	ubfx	w4, w2, #3, #1
	mov.b	v6[3], w4
	ubfx	w4, w2, #4, #1
	mov.b	v6[4], w4
	ubfx	w4, w2, #5, #1
	mov.b	v6[5], w4
	ubfx	w4, w2, #6, #1
	mov.b	v6[6], w4
	lsr	w2, w2, #7
	mov.b	v6[7], w2
	bif.8b	v3, v6, v5
	ldr	q5, [sp, #1104]                 ; 16-byte Folded Reload
	mov.s	w2, v5[2]
	add	x4, x0, w2, sxtw #2
	ldr	q5, [sp, #1072]                 ; 16-byte Folded Reload
	mov.s	w5, v5[2]
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x17, x1]
	lsl	x6, x1, #2
	add	x2, sp, #7, lsl #12             ; =28672
	add	x2, x2, #2840
	add	x1, sp, #7, lsl #12             ; =28672
	add	x1, x1, #2808
	ldr	w7, [x1, x6]
	csel	w5, w5, w7, ne
	add	x7, x2, x6
	csel	x4, x4, x7, ne
	ldr	w19, [x4]
	str	w5, [x1, x6]
	sxtb	w4, w3
	str	w19, [x7]
	cinc	w3, w16, ne
	cmp	w4, #0
	ldrb	w16, [x8, #15]
	and	w5, w16, #0x1
	fmov	s3, w5
	ubfx	w5, w16, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w16, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w16, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w16, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w16, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w16, #6, #1
	mov.b	v3[6], w5
	lsr	w16, w16, #7
	mov.b	v3[7], w16
	ldrb	w16, [x8, #7]
	and	w5, w16, #0x1
	fmov	s6, w5
	ubfx	w5, w16, #1, #1
	mov.b	v6[1], w5
	ubfx	w5, w16, #2, #1
	mov.b	v6[2], w5
	ubfx	w5, w16, #3, #1
	mov.b	v6[3], w5
	ubfx	w5, w16, #4, #1
	mov.b	v6[4], w5
	ubfx	w5, w16, #5, #1
	mov.b	v6[5], w5
	ubfx	w5, w16, #6, #1
	mov.b	v6[6], w5
	cset	w5, lt
	lsr	w16, w16, #7
	mov.b	v6[7], w16
	ldr	d5, [sp, #1064]                 ; 8-byte Folded Reload
	and.8b	v7, v5, v3
	eor.8b	v3, v6, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v5, v3, #0
	umaxv.8b	b3, v5
	fmov	w16, s3
	eor	w16, w16, #0x1
	ands	w16, w5, w16
	dup.8b	v3, w16
	and.8b	v3, v3, v6
	shl.8b	v16, v3, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v2
	addv.8b	b16, v16
	fmov	w5, s16
	csetm	w16, ne
	dup.8b	v17, w16
	bic.8b	v7, v7, v17
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b7, v7
	stur	b7, [x8, #15]
	bic.8b	v6, v6, v17
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v2
	addv.8b	b6, v6
	stur	b6, [x8, #7]
	cmp	w3, #8
	b.lo	LBB0_742
; %bb.741:                              ; %ready.overflow.resume596
                                        ;   in Loop: Header=BB0_2 Depth=1
	tst	w5, #0xff
	b.ne	LBB0_746
LBB0_742:                               ; %ready.overflow.resume602
                                        ;   in Loop: Header=BB0_2 Depth=1
	fmov	s6, wzr
	cmeq.8b	v6, v16, v6
	and.8b	v5, v5, v2
	addv.8b	b7, v5
	mvn.8b	v5, v6
	umov.b	w16, v5[0]
	sbfx	w6, w16, #0, #1
	fmov	s5, w6
	sbfx	w6, w16, #1, #1
	mov.b	v5[1], w6
	sbfx	w6, w16, #2, #1
	mov.b	v5[2], w6
	sbfx	w6, w16, #3, #1
	mov.b	v5[3], w6
	sbfx	w6, w16, #4, #1
	mov.b	v5[4], w6
	sbfx	w6, w16, #5, #1
	mov.b	v5[5], w6
	sbfx	w6, w16, #6, #1
	mov.b	v5[6], w6
	fmov	w6, s7
	sbfx	w16, w16, #7, #1
	mov.b	v5[7], w16
	and	w16, w4, #0x7f
	tst	w6, #0xff
	csel	w16, w16, w4, eq
	sxtw	x4, w3
	tst	w5, #0xff
	csel	x4, x4, xzr, ne
	ldrb	w5, [x17, x4]
	and	w6, w5, #0x1
	fmov	s6, w6
	ubfx	w6, w5, #1, #1
	mov.b	v6[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v6[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v6[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v6[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v6[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v6[6], w6
	lsr	w5, w5, #7
	mov.b	v6[7], w5
	bif.8b	v3, v6, v5
	ldr	q5, [sp, #1104]                 ; 16-byte Folded Reload
	mov.s	w5, v5[3]
	ldr	q5, [sp, #1072]                 ; 16-byte Folded Reload
	mov.s	w6, v5[3]
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x17, x4]
	add	x17, x0, w5, sxtw #2
	lsl	x0, x4, #2
	add	x2, x2, x0
	csel	x17, x17, x2, ne
	ldr	w17, [x17]
	str	w17, [x2]
	ldr	w17, [x1, x0]
	csel	w17, w6, w17, ne
	str	w17, [x1, x0]
	cinc	w17, w3, ne
	cbnz	w17, LBB0_2
	b	LBB0_744
LBB0_743:                               ;   in Loop: Header=BB0_2 Depth=1
	mov	w16, #0                         ; =0x0
	ldp	q18, q0, [sp, #560]             ; 32-byte Folded Reload
	ldr	q19, [sp, #544]                 ; 16-byte Folded Reload
	cbnz	w17, LBB0_2
LBB0_744:                               ; %scheduler.done
	ldr	d0, [sp, #1064]                 ; 8-byte Folded Reload
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	umaxv.8b	b0, v0
	fmov	w8, s0
	tbnz	w8, #0, LBB0_746
; %bb.745:                              ; %scheduler.exit
	sub	sp, x29, #144
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
LBB0_746:                               ; %scheduler.stalled
	brk	#0x1
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpLdr	Lloh40, Lloh41
	.loh AdrpAdrp	Lloh38, Lloh40
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpAdrp	Lloh36, Lloh38
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpAdrp	Lloh34, Lloh36
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpLdr	Lloh32, Lloh33
	.loh AdrpAdrp	Lloh30, Lloh32
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdrp	Lloh28, Lloh30
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpLdr	Lloh48, Lloh49
	.loh AdrpAdrp	Lloh46, Lloh48
	.loh AdrpLdr	Lloh46, Lloh47
	.loh AdrpAdrp	Lloh44, Lloh46
	.loh AdrpLdr	Lloh44, Lloh45
	.loh AdrpAdrp	Lloh42, Lloh44
	.loh AdrpLdr	Lloh42, Lloh43
	.loh AdrpLdr	Lloh56, Lloh57
	.loh AdrpAdrp	Lloh54, Lloh56
	.loh AdrpLdr	Lloh54, Lloh55
	.loh AdrpAdrp	Lloh52, Lloh54
	.loh AdrpLdr	Lloh52, Lloh53
	.loh AdrpAdrp	Lloh50, Lloh52
	.loh AdrpLdr	Lloh50, Lloh51
	.loh AdrpLdr	Lloh64, Lloh65
	.loh AdrpAdrp	Lloh62, Lloh64
	.loh AdrpLdr	Lloh62, Lloh63
	.loh AdrpAdrp	Lloh60, Lloh62
	.loh AdrpLdr	Lloh60, Lloh61
	.loh AdrpAdrp	Lloh58, Lloh60
	.loh AdrpLdr	Lloh58, Lloh59
	.loh AdrpLdr	Lloh72, Lloh73
	.loh AdrpAdrp	Lloh70, Lloh72
	.loh AdrpLdr	Lloh70, Lloh71
	.loh AdrpAdrp	Lloh68, Lloh70
	.loh AdrpLdr	Lloh68, Lloh69
	.loh AdrpAdrp	Lloh66, Lloh68
	.loh AdrpLdr	Lloh66, Lloh67
	.loh AdrpLdr	Lloh80, Lloh81
	.loh AdrpAdrp	Lloh78, Lloh80
	.loh AdrpLdr	Lloh78, Lloh79
	.loh AdrpAdrp	Lloh76, Lloh78
	.loh AdrpLdr	Lloh76, Lloh77
	.loh AdrpAdrp	Lloh74, Lloh76
	.loh AdrpLdr	Lloh74, Lloh75
	.loh AdrpAdd	Lloh82, Lloh83
	.section	__TEXT,__const
	.p2align	1, 0x0
LJTI0_0:
	.short	(LBB0_12-LBB0_12)>>2
	.short	(LBB0_145-LBB0_12)>>2
	.short	(LBB0_35-LBB0_12)>>2
	.short	(LBB0_154-LBB0_12)>>2
	.short	(LBB0_34-LBB0_12)>>2
	.short	(LBB0_50-LBB0_12)>>2
	.short	(LBB0_60-LBB0_12)>>2
	.short	(LBB0_201-LBB0_12)>>2
	.short	(LBB0_216-LBB0_12)>>2
	.short	(LBB0_76-LBB0_12)>>2
	.short	(LBB0_36-LBB0_12)>>2
	.short	(LBB0_270-LBB0_12)>>2
	.short	(LBB0_261-LBB0_12)>>2
	.short	(LBB0_299-LBB0_12)>>2
	.short	(LBB0_77-LBB0_12)>>2
	.short	(LBB0_78-LBB0_12)>>2
	.short	(LBB0_352-LBB0_12)>>2
	.short	(LBB0_343-LBB0_12)>>2
	.short	(LBB0_382-LBB0_12)>>2
	.short	(LBB0_49-LBB0_12)>>2
	.short	(LBB0_65-LBB0_12)>>2
	.short	(LBB0_426-LBB0_12)>>2
	.short	(LBB0_451-LBB0_12)>>2
	.short	(LBB0_466-LBB0_12)>>2
	.short	(LBB0_47-LBB0_12)>>2
	.short	(LBB0_89-LBB0_12)>>2
	.short	(LBB0_511-LBB0_12)>>2
	.short	(LBB0_536-LBB0_12)>>2
	.short	(LBB0_549-LBB0_12)>>2
	.short	(LBB0_33-LBB0_12)>>2
	.short	(LBB0_13-LBB0_12)>>2
	.short	(LBB0_593-LBB0_12)>>2
	.short	(LBB0_634-LBB0_12)>>2
	.short	(LBB0_647-LBB0_12)>>2
	.short	(LBB0_48-LBB0_12)>>2
	.short	(LBB0_24-LBB0_12)>>2
	.short	(LBB0_705-LBB0_12)>>2
	.short	(LBB0_688-LBB0_12)>>2
	.short	(LBB0_720-LBB0_12)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_tile_inclusive_scan.packet_batch ; -- Begin function tile_inclusive_scan.packet_batch
	.p2align	2
_tile_inclusive_scan.packet_batch:      ; @tile_inclusive_scan.packet_batch
; %bb.0:                                ; %packet.batch.prologue
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	mov	x21, x3
	mov	x19, x2
	mov	x20, x0
	ldr	w23, [x2, #36]
	ldr	w8, [x2]
	ldr	w9, [x2, #12]
	lsl	x8, x8, #5
	cmp	x8, x9
	csel	x10, x8, xzr, ls
	add	x10, x10, x23
	subs	x11, x9, x10
	mov	w12, #32                        ; =0x20
	sub	x13, x12, x23
	cmp	x11, x13
	csel	x11, x11, x13, lo
	cmp	x9, x10
	ccmp	x23, x12, #2, hi
	ccmp	x8, x9, #2, lo
	csel	x8, x11, xzr, ls
	cmp	w3, #4
	b.ne	LBB1_3
; %bb.1:                                ; %packet.batch.prologue
	cmp	x8, #32
	b.lo	LBB1_3
; %bb.2:                                ; %packet.batch.full
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	add	w8, w23, #8
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	add	w8, w23, #16
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	add	w8, w23, #24
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	b	_tile_inclusive_scan
LBB1_3:                                 ; %packet.batch.partial
	ubfiz	x9, x21, #3, #32
	cmp	x8, x9
	csel	x8, x8, x9, lo
	lsr	x24, x8, #3
	and	w22, w8, #0x7
	cmp	x8, #8
	b.lo	LBB1_6
; %bb.4:                                ; %packet.batch.partial.full.loop.preheader
	mov	x25, x24
	mov	x26, x23
LBB1_5:                                 ; %packet.batch.partial.full.loop
                                        ; =>This Inner Loop Header: Depth=1
	str	w26, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	add	w26, w26, #8
	subs	w25, w25, #1
	b.ne	LBB1_5
LBB1_6:                                 ; %packet.batch.tail.check
	cbz	w22, LBB1_8
; %bb.7:                                ; %packet.batch.tail.call
	add	w8, w23, w24, lsl #3
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	x2, x22
	bl	_tile_inclusive_scan
LBB1_8:                                 ; %packet.batch.partial.finish
	lsl	w8, w21, #3
	sub	w8, w8, #8
	cmp	w21, #0
	csel	w8, wzr, w8, eq
	add	w8, w23, w8
	str	w8, [x19, #36]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.section	__TEXT,__const
	.p2align	2, 0x0                          ; @convergence.targets
l_convergence.targets:
	.long	38                              ; 0x26
	.long	7                               ; 0x7
	.long	6                               ; 0x6
	.long	12                              ; 0xc
	.long	11                              ; 0xb
	.long	17                              ; 0x11
	.long	16                              ; 0x10
	.long	22                              ; 0x16
	.long	21                              ; 0x15
	.long	27                              ; 0x1b
	.long	26                              ; 0x1a
	.long	32                              ; 0x20
	.long	31                              ; 0x1f
	.long	37                              ; 0x25
	.long	36                              ; 0x24

.subsections_via_symbols

	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function tile_transpose
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_4:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_5:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_6:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_7:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_3:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_tile_transpose:                        ; @tile_transpose
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	sub	x9, sp, #4, lsl #12             ; =16384
	sub	x9, x9, #2208
	and	sp, x9, #0xffffffffffffffc0
	fmov	s1, wzr
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #2088
	str	wzr, [x8, #84]
	stur	wzr, [x8, #81]
	stur	xzr, [x8, #52]
	stur	xzr, [x8, #68]
	stur	xzr, [x8, #60]
	str	wzr, [x8, #76]
	stur	xzr, [x8, #20]
	stur	xzr, [x8, #36]
	stur	xzr, [x8, #28]
	str	wzr, [x8, #44]
	str	xzr, [sp, #18480]
	str	xzr, [sp, #18472]
	movi.2d	v29, #0000000000000000
	str	q29, [sp, #2032]
	str	q29, [sp, #2016]
	str	q29, [sp, #2000]
	str	q29, [sp, #1984]
	str	q29, [sp, #1968]
	str	q29, [sp, #1920]
	str	q29, [sp, #1936]
	str	q29, [sp, #1952]
	str	q29, [sp, #1904]
	str	q29, [sp, #1856]
	str	q29, [sp, #1872]
	str	q29, [sp, #1824]
	str	q29, [sp, #1840]
	str	q29, [sp, #1792]
	str	q29, [sp, #1808]
	str	q29, [sp, #1888]
	str	q29, [sp, #1776]
	str	q29, [sp, #1728]
	str	q29, [sp, #1744]
	str	q29, [sp, #1760]
	str	q29, [sp, #1712]
	str	q29, [sp, #1664]
	str	q29, [sp, #1680]
	str	q29, [sp, #1632]
	str	q29, [sp, #1648]
	str	q29, [sp, #1600]
	str	q29, [sp, #1616]
	str	q29, [sp, #1696]
	str	q29, [sp, #1584]
	str	q29, [sp, #1536]
	str	q29, [sp, #1552]
	str	q29, [sp, #1568]
	str	q29, [sp, #1520]
	str	q29, [sp, #1504]
	ldr	x10, [x0]
	ldr	x9, [x0, #16]
	stp	x10, x9, [sp, #192]             ; 16-byte Folded Spill
	ldr	w9, [x1]
	ldr	w10, [x1, #36]
	dup.4s	v3, w2
Lloh0:
	adrp	x11, lCPI0_0@PAGE
Lloh1:
	ldr	q2, [x11, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x11, lCPI0_1@PAGE
Lloh3:
	ldr	q4, [x11, lCPI0_1@PAGEOFF]
	cmhi.4s	v5, v3, v4
	cmhi.4s	v3, v3, v2
	uzp1.8h	v3, v3, v5
Lloh4:
	adrp	x11, lCPI0_2@PAGE
Lloh5:
	ldr	q5, [x11, lCPI0_2@PAGEOFF]
	and.16b	v5, v3, v5
	addv.8h	h5, v5
	fmov	w11, s5
	and	w11, w11, #0xff
	fmov	s5, w11
	cmeq.8b	v1, v5, v1
	umov.b	w11, v1[0]
	and	w12, w11, #0x1
	fmov	s5, w12
	ubfx	w12, w11, #1, #1
	mov.b	v5[1], w12
	ubfx	w12, w11, #2, #1
	mov.b	v5[2], w12
	ubfx	w12, w11, #3, #1
	mov.b	v5[3], w12
	ubfx	w12, w11, #4, #1
	mov.b	v5[4], w12
	ubfx	w12, w11, #5, #1
	mov.b	v5[5], w12
	ubfx	w12, w11, #6, #1
	mov.b	v5[6], w12
	xtn.8b	v1, v3
	ubfx	w11, w11, #7, #1
	mov.b	v5[7], w11
	movi.8b	v11, #1
	eor.8b	v5, v5, v11
	and.8b	v5, v5, v1
	umaxv.8h	h3, v3
	fmov	w11, s3
	shl.8b	v3, v5, #7
	cmlt.8b	v5, v3, #0
Lloh6:
	adrp	x12, lCPI0_3@PAGE
Lloh7:
	ldr	d3, [x12, lCPI0_3@PAGEOFF]
	and.8b	v5, v5, v3
	addv.8b	b5, v5
	str	b5, [x8, #80]
	str	wzr, [x8, #48]
	str	wzr, [x8, #16]
	tbz	w11, #0, LBB0_251
; %bb.1:                                ; %scheduler.dispatch.lr.ph
	stp	xzr, xzr, [sp, #112]            ; 16-byte Folded Spill
	stp	xzr, xzr, [sp, #96]             ; 16-byte Folded Spill
	stp	xzr, xzr, [sp, #80]             ; 16-byte Folded Spill
	stp	xzr, xzr, [sp, #64]             ; 16-byte Folded Spill
	mov	w21, #0                         ; =0x0
	add	x11, sp, #2, lsl #12            ; =8192
	add	x11, x11, #2088
	dup.2d	v0, x11
	add	x11, sp, #2088
	dup.2d	v6, x11
	add	w9, w10, w9, lsl #6
	dup.4s	v5, w9
	add.4s	v4, v5, v4
	stp	q4, q0, [sp, #160]              ; 32-byte Folded Spill
	mov	w11, #1                         ; =0x1
	add.4s	v2, v5, v2
	stp	q6, q2, [sp, #128]              ; 32-byte Folded Spill
	add	x30, sp, #4, lsl #12            ; =16384
	add	x30, x30, #2168
	add	x0, sp, #4, lsl #12             ; =16384
	add	x0, x0, #2136
Lloh8:
	adrp	x26, LJTI0_0@PAGE
Lloh9:
	add	x26, x26, LJTI0_0@PAGEOFF
	add	x15, sp, #4, lsl #12            ; =16384
	add	x15, x15, #2104
	mov	w27, #256                       ; =0x100
	add	x20, sp, #4, lsl #12            ; =16384
	add	x20, x20, #2096
	add	x7, sp, #704
	movi.2d	v10, #0000000000000000
	movi.2d	v2, #0000000000000000
	stp	q2, q2, [sp, #320]              ; 32-byte Folded Spill
	movi.2d	v12, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v13, #0000000000000000
	movi.2d	v31, #0000000000000000
	stp	q2, q2, [sp, #288]              ; 32-byte Folded Spill
	movi.2d	v26, #0000000000000000
	movi.2d	v0, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v9, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v15, #0000000000000000
	movi.2d	v14, #0000000000000000
	mov	w19, #-1                        ; =0xffffffff
	add	x22, sp, #672
	add	x28, sp, #1456
	add	x3, sp, #1248
	add	x16, sp, #1216
	mov	w6, #1                          ; =0x1
	b	LBB0_5
LBB0_2:                                 ; %ready.overflow.resume124
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b17, [x30, w6, uxtw]
	orr	w21, w9, w21
	mov	w9, #12                         ; =0xc
LBB0_3:                                 ; %scheduler.loop.backedge
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	w9, [x0, w6, uxtw #2]
	add	w5, w6, #1
	str	w10, [x15, w6, uxtw #2]
LBB0_4:                                 ; %scheduler.loop.backedge
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	x6, x5
	cbz	w5, LBB0_251
LBB0_5:                                 ; %scheduler.dispatch
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_82 Depth 2
                                        ;     Child Loop BB0_164 Depth 2
                                        ;     Child Loop BB0_215 Depth 2
                                        ;     Child Loop BB0_245 Depth 2
                                        ;     Child Loop BB0_76 Depth 2
	sub	w5, w6, #1
	ldr	w10, [x0, w5, sxtw #2]
	cmp	w10, #13
	b.hi	LBB0_253
; %bb.6:                                ; %scheduler.dispatch
                                        ;   in Loop: Header=BB0_5 Depth=1
	sxtw	x24, w5
	ldrb	w9, [x30, x24]
	and	w1, w9, #0x1
	fmov	s6, w1
	ubfx	w1, w9, #1, #1
	mov.b	v6[1], w1
	ubfx	w1, w9, #2, #1
	mov.b	v6[2], w1
	ubfx	w1, w9, #3, #1
	mov.b	v6[3], w1
	ubfx	w1, w9, #4, #1
	mov.b	v6[4], w1
	ubfx	w1, w9, #5, #1
	mov.b	v6[5], w1
	ubfx	w1, w9, #6, #1
	mov.b	v6[6], w1
	lsr	w9, w9, #7
	mov.b	v6[7], w9
	ldr	w25, [x15, w5, sxtw #2]
	adr	x9, LBB0_7
	ldrh	w1, [x26, x10, lsl #1]
	add	x9, x9, x1, lsl #2
	br	x9
LBB0_7:                                 ; %schedule.0
                                        ;   in Loop: Header=BB0_5 Depth=1
	zip1.8b	v2, v6, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q7, [sp, #144]                  ; 16-byte Folded Reload
	and.16b	v16, v2, v7
	zip2.8b	v7, v6, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v17, v7, #0
	ldr	q7, [sp, #160]                  ; 16-byte Folded Reload
	and.16b	v7, v17, v7
	movi.4s	v19, #9
	and.16b	v18, v17, v19
	mvn.16b	v17, v17
	sub.4s	v18, v18, v17
	mov.s	w9, v18[1]
	and.16b	v17, v2, v19
	mov.s	w10, v7[1]
	udiv	w9, w10, w9
	fmov	w10, s18
	fmov	w1, s7
	udiv	w10, w1, w10
	fmov	s20, w10
	mov.s	v20[1], w9
	mov.s	w1, v18[2]
	mvn.16b	v2, v2
	mov.s	w2, v7[2]
	udiv	w1, w2, w1
	mov.s	v20[2], w1
	sub.4s	v17, v17, v2
	mov.s	w2, v18[3]
	mov.s	w4, v7[3]
	udiv	w2, w4, w2
	mov.s	v20[3], w2
	mov.s	w4, v17[1]
	mov.s	w23, v16[1]
	fmov	w14, s17
	fmov	w28, s16
	udiv	w14, w28, w14
	fmov	s19, w14
	udiv	w4, w23, w4
	mov.s	v19[1], w4
	mov.s	w23, v17[2]
	mov.s	w28, v16[2]
	udiv	w23, w28, w23
	mov.s	v19[2], w23
	mov.s	w28, v17[3]
	mov.s	w30, v16[3]
	udiv	w28, w30, w28
	mov.s	v19[3], w28
	fmov	s2, w10
	mov.s	v2[1], w9
	fmov	s21, w23
	mov.s	v21[1], w28
	fmov	s22, w14
	mov.s	v22[1], w4
	fmov	s23, w1
	mov.s	v23[1], w2
	mls.4s	v7, v20, v18
	ushll.2d	v23, v23, #4
	ushll.2d	v20, v22, #4
	ushll.2d	v18, v2, #4
	ldr	q24, [sp, #2032]
	ldr	q8, [sp, #1984]
	ldr	q22, [sp, #2000]
	mov.16b	v28, v9
	ldr	q9, [sp, #2016]
	mov	b2, v6[4]
	mov.b	v2[4], v6[5]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v2, v2, #0
	bit.16b	v9, v18, v2
	mov	b18, v6[2]
	mov.b	v18[4], v6[3]
	ushll.2d	v21, v21, #4
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	bif.16b	v21, v22, v18
	mov	b22, v6[0]
	mov.b	v22[4], v6[1]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	bit.16b	v8, v20, v22
	mov	b20, v6[6]
	mov.b	v20[4], v6[7]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	bif.16b	v23, v24, v20
	str	q23, [sp, #2032]
	str	q8, [sp, #1984]
	str	q21, [sp, #2000]
	str	q9, [sp, #2016]
	mls.4s	v16, v19, v17
	shl.4s	v16, v16, #4
	ldr	q17, [sp, #1968]
	ldr	q19, [sp, #1936]
	ldr	q21, [sp, #1952]
	ldr	q23, [sp, #1920]
	shl.4s	v7, v7, #4
	ushll2.2d	v24, v7, #0
	ushll2.2d	v8, v16, #0
	ushll.2d	v7, v7, #0
	bif.16b	v7, v21, v2
	bit.16b	v19, v8, v18
	bit.16b	v17, v24, v20
	str	q17, [sp, #1968]
	str	q19, [sp, #1936]
	str	q7, [sp, #1952]
	ushll.2d	v7, v16, #0
	bif.16b	v7, v23, v22
	str	q7, [sp, #1920]
	ldr	q7, [sp, #1856]
	ldr	q16, [sp, #1872]
	ldr	q17, [sp, #1904]
	ldr	q19, [sp, #1888]
	shl.8b	v21, v6, #7
	ldr	q23, [sp, #1792]
	ldr	q24, [sp, #1808]
	cmlt.8b	v21, v21, #0
	umaxv.8b	b21, v21
	fmov	w9, s21
	ldr	q21, [sp, #1840]
	ldr	q8, [sp, #1824]
Lloh10:
	adrp	x10, lCPI0_6@PAGE
Lloh11:
	ldr	q9, [x10, lCPI0_6@PAGEOFF]
	bit.16b	v16, v9, v18
Lloh12:
	adrp	x10, lCPI0_7@PAGE
Lloh13:
	ldr	q9, [x10, lCPI0_7@PAGEOFF]
	bit.16b	v7, v9, v22
Lloh14:
	adrp	x10, lCPI0_4@PAGE
Lloh15:
	ldr	q9, [x10, lCPI0_4@PAGEOFF]
	str	q7, [sp, #1856]
Lloh16:
	adrp	x10, lCPI0_5@PAGE
Lloh17:
	ldr	q7, [x10, lCPI0_5@PAGEOFF]
	str	q16, [sp, #1872]
	ldr	q25, [sp, #176]                 ; 16-byte Folded Reload
	mov.16b	v16, v2
	bsl.16b	v16, v25, v8
	bit.16b	v21, v25, v20
	bit.16b	v24, v25, v18
	bit.16b	v19, v9, v2
	bif.16b	v7, v17, v20
	str	q7, [sp, #1904]
	str	q19, [sp, #1888]
	mov.16b	v7, v22
	bsl.16b	v7, v25, v23
	str	q7, [sp, #1792]
	str	q24, [sp, #1808]
	str	q21, [sp, #1840]
	str	q16, [sp, #1824]
	bic.16b	v9, v28, v20
	bic.16b	v27, v27, v2
	bic.16b	v0, v0, v18
	bic.16b	v26, v26, v22
	add	x30, sp, #4, lsl #12            ; =16384
	add	x30, x30, #2168
	add	x28, sp, #1456
	tbnz	w9, #0, LBB0_45
	b	LBB0_4
LBB0_8:                                 ; %scheduler.dispatch.schedule.7_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v2, v6, #7
	cmlt.8b	v2, v2, #0
	umaxv.8b	b2, v2
	fmov	w9, s2
	eor	w9, w9, #0x1
	b	LBB0_128
LBB0_9:                                 ; %scheduler.dispatch.schedule.10_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v2, v6, #7
	cmlt.8b	v2, v2, #0
	umaxv.8b	b2, v2
	fmov	w9, s2
	eor	w9, w9, #0x1
	b	LBB0_180
LBB0_10:                                ; %scheduler.dispatch.schedule.2_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v2, v6, #7
	cmlt.8b	v2, v2, #0
	umaxv.8b	b2, v2
	fmov	w9, s2
	eor	w9, w9, #0x1
	b	LBB0_55
LBB0_11:                                ; %schedule.11
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v2, v6, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w9, s2
	ldr	q7, [sp, #1584]
	ldr	q17, [sp, #1568]
	ldr	q19, [sp, #1552]
	ldr	q16, [sp, #1536]
	ldr	q2, [sp, #1520]
	ldr	q18, [sp, #1504]
	shl.2d	v20, v16, #2
	ldr	x10, [sp, #200]                 ; 8-byte Folded Reload
	dup.2d	v16, x10
	add.2d	v20, v16, v20
	tbnz	w9, #0, LBB0_30
; %bb.12:                               ; %else210
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #1, LBB0_31
LBB0_13:                                ; %else214
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.2d	v19, v19, #2
	add.2d	v19, v16, v19
	tbnz	w9, #2, LBB0_32
LBB0_14:                                ; %else218
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #3, LBB0_33
LBB0_15:                                ; %else222
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.2d	v17, v17, #2
	add.2d	v17, v16, v17
	tbnz	w9, #4, LBB0_34
LBB0_16:                                ; %else226
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #5, LBB0_35
LBB0_17:                                ; %else230
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.2d	v7, v7, #2
	add.2d	v7, v16, v7
	tbnz	w9, #6, LBB0_36
LBB0_18:                                ; %else234
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #7, LBB0_37
LBB0_19:                                ; %else238
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w9, #0xff
	b.ne	LBB0_243
	b	LBB0_4
LBB0_20:                                ; %schedule.3
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v2, v6, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w9, s2
	ldr	q2, [sp, #1776]
	ldr	q18, [sp, #1760]
	ldr	q19, [sp, #1744]
	ldr	q7, [sp, #1728]
	shl.2d	v7, v7, #2
	ldr	x10, [sp, #192]                 ; 8-byte Folded Reload
	dup.2d	v17, x10
	add.2d	v20, v17, v7
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbnz	w9, #0, LBB0_38
; %bb.21:                               ; %else
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #1, LBB0_39
LBB0_22:                                ; %else64
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.2d	v19, v19, #2
	add.2d	v19, v17, v19
	tbnz	w9, #2, LBB0_40
LBB0_23:                                ; %else67
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #3, LBB0_41
LBB0_24:                                ; %else70
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.2d	v18, v18, #2
	add.2d	v18, v17, v18
	tbnz	w9, #4, LBB0_42
LBB0_25:                                ; %else73
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #5, LBB0_43
LBB0_26:                                ; %else76
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.2d	v2, v2, #2
	add.2d	v2, v17, v2
	tbnz	w9, #6, LBB0_44
LBB0_27:                                ; %else79
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w9, #7, LBB0_29
LBB0_28:                                ; %cond.load81
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v2[1]
	ld1.s	{ v16 }[3], [x10]
LBB0_29:                                ; %else82
                                        ;   in Loop: Header=BB0_5 Depth=1
	zip2.8b	v2, v6, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q17, [sp, #288]                 ; 16-byte Folded Reload
	bit.16b	v17, v16, v2
	zip1.8b	v2, v6, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q16, [sp, #304]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v2
	stp	q17, q16, [sp, #288]            ; 32-byte Folded Spill
	tst	w9, #0xff
	b.ne	LBB0_74
	b	LBB0_4
LBB0_30:                                ; %cond.store207
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d20
	str	s18, [x10]
	tbz	w9, #1, LBB0_13
LBB0_31:                                ; %cond.store211
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v20[1]
	st1.s	{ v18 }[1], [x10]
	shl.2d	v19, v19, #2
	add.2d	v19, v16, v19
	tbz	w9, #2, LBB0_14
LBB0_32:                                ; %cond.store215
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d19
	st1.s	{ v18 }[2], [x10]
	tbz	w9, #3, LBB0_15
LBB0_33:                                ; %cond.store219
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v19[1]
	st1.s	{ v18 }[3], [x10]
	shl.2d	v17, v17, #2
	add.2d	v17, v16, v17
	tbz	w9, #4, LBB0_16
LBB0_34:                                ; %cond.store223
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d17
	str	s2, [x10]
	tbz	w9, #5, LBB0_17
LBB0_35:                                ; %cond.store227
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v17[1]
	st1.s	{ v2 }[1], [x10]
	shl.2d	v7, v7, #2
	add.2d	v7, v16, v7
	tbz	w9, #6, LBB0_18
LBB0_36:                                ; %cond.store231
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d7
	st1.s	{ v2 }[2], [x10]
	tbz	w9, #7, LBB0_19
LBB0_37:                                ; %cond.store235
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v7[1]
	st1.s	{ v2 }[3], [x10]
	tst	w9, #0xff
	b.ne	LBB0_243
	b	LBB0_4
LBB0_38:                                ; %cond.load
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d20
	ldr	s7, [x10]
	tbz	w9, #1, LBB0_22
LBB0_39:                                ; %cond.load63
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v20[1]
	ld1.s	{ v7 }[1], [x10]
	shl.2d	v19, v19, #2
	add.2d	v19, v17, v19
	tbz	w9, #2, LBB0_23
LBB0_40:                                ; %cond.load66
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d19
	ld1.s	{ v7 }[2], [x10]
	tbz	w9, #3, LBB0_24
LBB0_41:                                ; %cond.load69
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v19[1]
	ld1.s	{ v7 }[3], [x10]
	shl.2d	v18, v18, #2
	add.2d	v18, v17, v18
	tbz	w9, #4, LBB0_25
LBB0_42:                                ; %cond.load72
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d18
	ld1.s	{ v16 }[0], [x10]
	tbz	w9, #5, LBB0_26
LBB0_43:                                ; %cond.load75
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v18[1]
	ld1.s	{ v16 }[1], [x10]
	shl.2d	v2, v2, #2
	add.2d	v2, v17, v2
	tbz	w9, #6, LBB0_27
LBB0_44:                                ; %cond.load78
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d2
	ld1.s	{ v16 }[2], [x10]
	tbnz	w9, #7, LBB0_28
	b	LBB0_29
LBB0_45:                                ; %schedule.1
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v2, v6, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w10, s2
	dup.2d	v2, x27
	cmgt.2d	v7, v2, v0
	cmgt.2d	v16, v2, v26
	uzp1.4s	v7, v16, v7
	cmgt.2d	v16, v2, v27
	cmgt.2d	v17, v2, v9
	uzp1.4s	v16, v16, v17
	uzp1.8h	v7, v7, v16
	xtn.8b	v7, v7
	and.8b	v7, v6, v7
	shl.8b	v7, v7, #7
	cmlt.8b	v16, v7, #0
	and.8b	v7, v16, v3
	addv.8b	b7, v7
	fmov	w9, s7
	umaxv.8b	b16, v16
	fmov	w14, s16
	tbz	w14, #0, LBB0_52
; %bb.46:                               ; %schedule.1
                                        ;   in Loop: Header=BB0_5 Depth=1
	cmge.2d	v16, v0, v2
	cmge.2d	v17, v26, v2
	uzp1.4s	v16, v17, v16
	cmge.2d	v17, v27, v2
	cmge.2d	v2, v9, v2
	uzp1.4s	v2, v17, v2
	uzp1.8h	v2, v16, v2
	xtn.8b	v2, v2
	and.8b	v2, v6, v2
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b16, v2
	fmov	w14, s16
	tst	w14, #0xff
	b.eq	LBB0_52
; %bb.47:                               ; %varying.divergent
                                        ;   in Loop: Header=BB0_5 Depth=1
	subs	w9, w25, #1
	csel	w9, wzr, w9, lo
	and	w10, w21, #0xff
	lsr	w12, w10, w9
	tst	w12, #0x1
	stp	q15, q14, [sp, #480]
	and	x9, x9, #0x7
	add	x12, sp, #480
	ldr	w9, [x12, x9, lsl #2]
	ccmp	w25, #0, #4, ne
	ccmp	w9, #0, #0, ne
	cset	w9, ne
	cmp	w10, #255
	b.ne	LBB0_49
; %bb.48:                               ; %varying.divergent
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #0, LBB0_253
LBB0_49:                                ; %convergence.overflow.resume
                                        ;   in Loop: Header=BB0_5 Depth=1
	mvn	w10, w21
	rbit	w10, w10
	clz	w10, w10
	mov	w12, #255                       ; =0xff
	bics	wzr, w12, w21
	csel	w10, wzr, w10, eq
	ubfiz	x12, x10, #2, #3
	lsl	w13, w11, w10
	stp	q15, q14, [sp, #448]
	add	x14, sp, #448
	ldr	w14, [x14, x12]
	cmp	w9, #0
	csel	w9, w13, wzr, ne
	csel	w13, wzr, w14, ne
	stp	q15, q14, [sp, #416]
	add	x14, sp, #416
	str	w13, [x14, x12]
	ldp	q15, q14, [sp, #416]
	stp	q5, q4, [sp, #384]
	add	x13, sp, #384
	ldr	w13, [x13, x12]
	csel	w13, w25, w13, ne
	stp	q5, q4, [sp, #352]
	add	x14, sp, #352
	str	w13, [x14, x12]
	ldrb	w12, [x20, x10]
	and	w13, w12, #0x1
	fmov	s2, w13
	ubfx	w13, w12, #1, #1
	mov.b	v2[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v2[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v2[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v2[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v2[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v2[6], w13
	ldp	q5, q4, [sp, #352]
	lsr	w12, w12, #7
	mov.b	v2[7], w12
	ldrb	w12, [x8, x10]
	and	w13, w12, #0x1
	fmov	s17, w13
	ubfx	w13, w12, #1, #1
	mov.b	v17[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v17[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v17[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v17[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v17[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v17[6], w13
	lsr	w12, w12, #7
	mov.b	v17[7], w12
	csetm	w12, ne
	dup.8b	v18, w12
	bit.8b	v2, v6, v18
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x20, x10]
	bic.8b	v2, v17, v18
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x8, x10]
	csinc	w10, w25, w10, eq
	cmp	w5, #8
	b.hs	LBB0_253
; %bb.50:                               ; %ready.overflow.resume23
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b7, [x30, x24]
	mov	w12, #2                         ; =0x2
	str	w12, [x0, x24, lsl #2]
	str	w10, [x15, x24, lsl #2]
	cmp	w6, #8
	b.hs	LBB0_253
; %bb.51:                               ; %ready.overflow.resume25
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b16, [x30, w6, uxtw]
	orr	w21, w9, w21
	mov	w9, #5                          ; =0x5
	b	LBB0_3
LBB0_52:                                ; %varying.coherent
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w9, #0xff
	b.eq	LBB0_79
; %bb.53:                               ; %varying.coherent.true
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w10, #0xff
	b.eq	LBB0_4
; %bb.54:                               ;   in Loop: Header=BB0_5 Depth=1
	mov	w9, #0                          ; =0x0
LBB0_55:                                ; %schedule.2
                                        ;   in Loop: Header=BB0_5 Depth=1
	stp	q29, q31, [sp, #256]            ; 32-byte Folded Spill
	mov.16b	v31, v13
	mov.16b	v13, v30
	mov.16b	v29, v12
	mov.16b	v11, v10
	mov	b2, v6[0]
	mov.b	v2[4], v6[1]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v7, v2, #0
	mov.16b	v12, v26
	and.16b	v19, v7, v26
	mov	b2, v6[2]
	mov.b	v2[4], v6[3]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v16, v2, #0
	mov	b2, v6[4]
	mov.b	v2[4], v6[5]
	and.16b	v22, v16, v0
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v17, v2, #0
	mov.16b	v28, v27
	and.16b	v2, v17, v27
	mov	b18, v6[6]
	mov.b	v18[4], v6[7]
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	mov.16b	v30, v9
	and.16b	v23, v18, v9
	mov	w10, #16                        ; =0x10
	dup.2d	v24, x10
	and.16b	v20, v7, v24
	mvn.16b	v21, v7
	sub.2d	v21, v20, v21
	and.16b	v20, v16, v24
	mvn.16b	v8, v16
	sub.2d	v20, v20, v8
	and.16b	v8, v17, v24
	mvn.16b	v9, v17
	sub.2d	v8, v8, v9
	and.16b	v24, v18, v24
	mvn.16b	v9, v18
	sub.2d	v24, v24, v9
	mov.d	x10, v24[1]
	mov.d	x14, v23[1]
	sdiv	x1, x14, x10
	fmov	x14, d24
	fmov	x2, d23
	sdiv	x2, x2, x14
	mul	x14, x2, x14
	fmov	d24, x2
	mov.d	v24[1], x1
	mov.d	x2, v8[1]
	mov.d	x4, v2[1]
	sdiv	x4, x4, x2
	fmov	x23, d8
	fmov	x28, d2
	sdiv	x28, x28, x23
	mul	x23, x28, x23
	fmov	d8, x28
	mov.d	v8[1], x4
	mov.d	x28, v20[1]
	mov.d	x30, v22[1]
	sdiv	x30, x30, x28
	fmov	x26, d20
	fmov	x27, d22
	sdiv	x27, x27, x26
	mul	x26, x27, x26
	fmov	d20, x27
	mov.d	v20[1], x30
	mov.d	x27, v21[1]
	mov.d	x17, v19[1]
	fmov	x0, d21
	fmov	x13, d19
	sdiv	x13, x13, x0
	mul	x0, x13, x0
	fmov	d21, x13
	sdiv	x13, x17, x27
	mov.d	v21[1], x13
	mul	x17, x30, x28
	fmov	d9, x26
	mov.d	v9[1], x17
	mul	x13, x13, x27
	fmov	d25, x0
	add	x0, sp, #4, lsl #12             ; =16384
	add	x0, x0, #2136
	mov.d	v25[1], x13
	mul	x10, x1, x10
	fmov	d26, x14
	mov.d	v26[1], x10
	mul	x10, x4, x2
	fmov	d27, x23
	mov.d	v27[1], x10
	sub.2d	v2, v2, v27
	sub.2d	v23, v23, v26
	sub.2d	v19, v19, v25
	sub.2d	v22, v22, v9
	ldr	q25, [sp, #2032]
	ldr	q26, [sp, #2016]
	ldr	q27, [sp, #2000]
	ldr	q9, [sp, #1984]
	add.2d	v21, v9, v21
	add.2d	v20, v27, v20
	add.2d	v26, v26, v8
	add.2d	v24, v25, v24
	mov	w10, #65                        ; =0x41
	dup.2d	v25, x10
	cmhi.2d	v27, v25, v24
	cmhi.2d	v8, v25, v26
	uzp1.4s	v27, v8, v27
	cmhi.2d	v8, v25, v20
	cmhi.2d	v25, v25, v21
	uzp1.4s	v25, v25, v8
	uzp1.8h	v25, v25, v27
	ldr	q27, [sp, #1952]
	ldr	q8, [sp, #1968]
	ldr	q9, [sp, #1920]
	ldr	q10, [sp, #1936]
	add.2d	v22, v10, v22
	add.2d	v19, v9, v19
	add.2d	v23, v8, v23
	mov.d	x10, v20[1]
	fmov	x13, d20
	add	x13, x13, x13, lsl #7
	fmov	d20, x13
	add	x10, x10, x10, lsl #7
	mov.d	v20[1], x10
	mov.d	x10, v21[1]
	fmov	x13, d21
	add	x13, x13, x13, lsl #7
	fmov	d21, x13
	add	x10, x10, x10, lsl #7
	mov.d	v21[1], x10
	mov.d	x10, v24[1]
	fmov	x13, d24
	add	x13, x13, x13, lsl #7
	fmov	d24, x13
	add	x10, x10, x10, lsl #7
	mov.d	v24[1], x10
	mov.d	x10, v26[1]
	fmov	x13, d26
	add	x13, x13, x13, lsl #7
	fmov	d26, x13
	add	x10, x10, x10, lsl #7
	mov.d	v26[1], x10
	add.2d	v2, v27, v2
	mov	w10, #129                       ; =0x81
	dup.2d	v27, x10
	add.2d	v26, v26, v2
	add.2d	v24, v24, v23
	add.2d	v21, v21, v19
	add.2d	v20, v20, v22
	cmhi.2d	v23, v27, v23
	cmhi.2d	v2, v27, v2
	uzp1.4s	v2, v2, v23
	cmhi.2d	v22, v27, v22
	cmhi.2d	v19, v27, v19
	uzp1.4s	v19, v19, v22
	uzp1.8h	v2, v19, v2
	and.16b	v2, v25, v2
	xtn.8b	v2, v2
	ldr	q19, [sp, #1760]
	ldr	q22, [sp, #1776]
	ldr	q23, [sp, #1728]
	ldr	q25, [sp, #1744]
	bsl.16b	v16, v20, v25
	bsl.16b	v7, v21, v23
	bsl.16b	v18, v24, v22
	bsl.16b	v17, v26, v19
	str	q17, [sp, #1760]
	str	q18, [sp, #1776]
	str	q7, [sp, #1728]
	str	q16, [sp, #1744]
	and.8b	v7, v6, v2
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v16, v7, v3
	addv.8b	b17, v16
	fmov	w10, s17
	umaxv.8b	b7, v7
	fmov	w13, s7
	tbz	w13, #0, LBB0_62
; %bb.56:                               ; %schedule.2
                                        ;   in Loop: Header=BB0_5 Depth=1
	bic.8b	v16, v6, v2
	shl.8b	v2, v16, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b7, v2
	fmov	w13, s7
	tst	w13, #0xff
	b.eq	LBB0_62
; %bb.57:                               ; %varying.divergent29
                                        ;   in Loop: Header=BB0_5 Depth=1
	subs	w9, w25, #1
	csel	w9, wzr, w9, lo
	and	w10, w21, #0xff
	lsr	w12, w10, w9
	tst	w12, #0x1
	stp	q15, q14, [sp, #640]
	and	x9, x9, #0x7
	add	x12, sp, #640
	ldr	w9, [x12, x9, lsl #2]
	ccmp	w25, #0, #4, ne
	ccmp	w9, #1, #0, ne
	cset	w9, ne
	cmp	w10, #255
	add	x30, sp, #4, lsl #12            ; =16384
	add	x30, x30, #2168
	b.ne	LBB0_59
; %bb.58:                               ; %varying.divergent29
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #0, LBB0_253
LBB0_59:                                ; %convergence.overflow.resume32
                                        ;   in Loop: Header=BB0_5 Depth=1
	mvn	w10, w21
	rbit	w10, w10
	clz	w10, w10
	mov	w12, #255                       ; =0xff
	bics	wzr, w12, w21
	csel	w10, wzr, w10, eq
	ubfiz	x12, x10, #2, #3
	lsl	w13, w11, w10
	stp	q15, q14, [sp, #608]
	add	x14, sp, #608
	ldr	w14, [x14, x12]
	cmp	w9, #0
	csel	w9, w13, wzr, ne
	csinc	w13, w14, wzr, eq
	stp	q15, q14, [sp, #576]
	add	x14, sp, #576
	str	w13, [x14, x12]
	ldp	q15, q14, [sp, #576]
	stp	q5, q4, [sp, #544]
	add	x13, sp, #544
	ldr	w13, [x13, x12]
	csel	w13, w25, w13, ne
	stp	q5, q4, [sp, #512]
	add	x14, sp, #512
	str	w13, [x14, x12]
	ldrb	w12, [x20, x10]
	and	w13, w12, #0x1
	fmov	s2, w13
	ubfx	w13, w12, #1, #1
	mov.b	v2[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v2[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v2[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v2[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v2[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v2[6], w13
	ldp	q5, q4, [sp, #512]
	lsr	w12, w12, #7
	mov.b	v2[7], w12
	ldrb	w12, [x8, x10]
	and	w13, w12, #0x1
	fmov	s18, w13
	ubfx	w13, w12, #1, #1
	mov.b	v18[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v18[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v18[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v18[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v18[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v18[6], w13
	lsr	w12, w12, #7
	mov.b	v18[7], w12
	csetm	w12, ne
	dup.8b	v19, w12
	bit.8b	v2, v6, v19
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x20, x10]
	bic.8b	v2, v18, v19
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x8, x10]
	csinc	w10, w25, w10, eq
	cmp	w5, #8
Lloh18:
	adrp	x26, LJTI0_0@PAGE
Lloh19:
	add	x26, x26, LJTI0_0@PAGEOFF
	mov	w27, #256                       ; =0x100
	add	x28, sp, #1456
	b.hs	LBB0_253
; %bb.60:                               ; %ready.overflow.resume34
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v10, v11
	str	b17, [x30, x24]
	mov	w12, #3                         ; =0x3
	str	w12, [x0, x24, lsl #2]
	str	w10, [x15, x24, lsl #2]
	cmp	w6, #8
	movi.8b	v11, #1
	b.hs	LBB0_253
; %bb.61:                               ; %ready.overflow.resume36
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v26, v12
	mov.16b	v27, v28
	mov.16b	v9, v30
	mov.16b	v12, v29
	mov.16b	v30, v13
	orr	w21, w9, w21
	zip2.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmge.4s	v2, v2, #0
	ldr	q6, [sp, #288]                  ; 16-byte Folded Reload
	and.16b	v6, v2, v6
	str	q6, [sp, #288]                  ; 16-byte Folded Spill
	zip1.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmge.4s	v2, v2, #0
	str	b7, [x30, w6, uxtw]
	ldr	q6, [sp, #304]                  ; 16-byte Folded Reload
	and.16b	v6, v2, v6
	str	q6, [sp, #304]                  ; 16-byte Folded Spill
	mov	w9, #4                          ; =0x4
	str	w9, [x0, w6, uxtw #2]
	str	w10, [x15, w6, uxtw #2]
	add	w5, w6, #1
	b	LBB0_90
LBB0_62:                                ; %varying.coherent30
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w10, #0xff
	add	x28, sp, #1456
	b.eq	LBB0_88
; %bb.63:                               ; %varying.coherent.true37
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x30, sp, #4, lsl #12            ; =16384
	add	x30, x30, #2168
Lloh20:
	adrp	x26, LJTI0_0@PAGE
Lloh21:
	add	x26, x26, LJTI0_0@PAGEOFF
	mov	w27, #256                       ; =0x100
	mov.16b	v10, v11
	mov.16b	v26, v12
	mov.16b	v27, v28
	mov.16b	v9, v30
	tbnz	w9, #0, LBB0_89
; %bb.64:                               ; %schedule.3.thread
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q2, [sp, #1776]
	ldr	q7, [sp, #1760]
	ldr	q16, [sp, #1744]
	ldr	q17, [sp, #1728]
	shl.2d	v19, v17, #2
	shl.2d	v16, v16, #2
	shl.2d	v7, v7, #2
	ldr	x9, [sp, #192]                  ; 8-byte Folded Reload
	dup.2d	v20, x9
	shl.2d	v2, v2, #2
	add.2d	v2, v20, v2
	add.2d	v17, v20, v7
	add.2d	v18, v20, v16
	add.2d	v19, v20, v19
	shl.8b	v7, v6, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v3
	addv.8b	b7, v7
	fmov	w9, s7
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.8b	v11, #1
	mov.16b	v12, v29
	mov.16b	v30, v13
	tbnz	w9, #0, LBB0_111
; %bb.65:                               ; %else244
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v13, v31
	ldr	q29, [sp, #256]                 ; 16-byte Folded Reload
	tbnz	w9, #1, LBB0_112
LBB0_66:                                ; %else250
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q31, [sp, #272]                 ; 16-byte Folded Reload
	tbnz	w9, #2, LBB0_113
LBB0_67:                                ; %else256
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #3, LBB0_114
LBB0_68:                                ; %else262
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #4, LBB0_115
LBB0_69:                                ; %else268
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #5, LBB0_116
LBB0_70:                                ; %else274
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #6, LBB0_117
LBB0_71:                                ; %else280
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w9, #7, LBB0_73
LBB0_72:                                ; %cond.load282
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x9, v2[1]
	ld1.s	{ v16 }[3], [x9]
LBB0_73:                                ; %else286
                                        ;   in Loop: Header=BB0_5 Depth=1
	zip2.8b	v2, v6, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q17, [sp, #288]                 ; 16-byte Folded Reload
	bit.16b	v17, v16, v2
	zip1.8b	v2, v6, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q16, [sp, #304]                 ; 16-byte Folded Reload
	bit.16b	v16, v7, v2
	stp	q17, q16, [sp, #288]            ; 32-byte Folded Spill
LBB0_74:                                ; %schedule.4
                                        ;   in Loop: Header=BB0_5 Depth=1
	cbz	w25, LBB0_92
LBB0_75:                                ; %convergence.cascade.preheader
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	w9, #0                          ; =0x0
LBB0_76:                                ; %convergence.cascade
                                        ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v2, v6, #7
	cmlt.8b	v2, v2, #0
	and.8b	v7, v2, v3
	addv.8b	b7, v7
	fmov	w10, s7
	umaxv.8b	b2, v2
	fmov	w12, s2
	sub	w13, w25, #1
	tst	w10, #0xff
	csel	w23, w13, wzr, ne
	lsl	w1, w11, w23
	and	w10, w1, w21
	tst	w10, #0xff
	cset	w13, ne
	stp	q15, q14, [sp, #704]
	ubfiz	x10, x23, #2, #3
	ldr	w14, [x7, x10]
	cmp	w14, #1
	cset	w4, eq
	and	w2, w13, w12
	ldrb	w12, [x20, w23, sxtw]
	and	w13, w12, #0x1
	fmov	s2, w13
	ubfx	w13, w12, #1, #1
	mov.b	v2[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v2[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v2[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v2[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v2[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v2[6], w13
	lsr	w12, w12, #7
	mov.b	v2[7], w12
	ldrb	w12, [x8, w23, sxtw]
	and	w13, w12, #0x1
	fmov	s7, w13
	ubfx	w13, w12, #1, #1
	mov.b	v7[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v7[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v7[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v7[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v7[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v7[6], w13
	lsr	w12, w12, #7
	mov.b	v7[7], w12
	orr.8b	v16, v6, v7
	and.8b	v17, v1, v2
	eor.8b	v17, v17, v16
	shl.8b	v17, v17, #7
	cmlt.8b	v17, v17, #0
	umaxv.8b	b17, v17
	fmov	w12, s17
	ands	w13, w2, w4
	csetm	w14, ne
	bics	w12, w13, w12
	csetm	w17, ne
	dup.8b	v17, w17
	dup.8b	v18, w14
	bic.8b	v19, v16, v17
	bit.8b	v7, v19, v18
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v3
	addv.8b	b7, v7
	str	b7, [x8, w23, sxtw]
	bic.8b	v2, v2, v17
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x20, w23, sxtw]
	csinv	w14, w19, w1, eq
	dup.8b	v2, w13
	and	w21, w14, w21
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	dup.8b	v7, w12
	and.8b	v7, v7, v16
	stp	q5, q4, [sp, #672]
	ldr	w10, [x22, x10]
	csel	w25, w10, w25, ne
	bit.8b	v6, v7, v2
	shl.8b	v2, v6, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w10, s2
	cmp	w13, #1
	b.ne	LBB0_93
; %bb.77:                               ; %convergence.cascade
                                        ;   in Loop: Header=BB0_76 Depth=2
	cmp	w25, #0
	ccmp	w9, #6, #2, ne
	b.hi	LBB0_93
; %bb.78:                               ; %convergence.cascade
                                        ;   in Loop: Header=BB0_76 Depth=2
	add	w9, w9, #1
	tst	w10, #0xff
	b.ne	LBB0_76
	b	LBB0_93
LBB0_79:                                ; %varying.coherent.false
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w10, #0xff
	b.eq	LBB0_4
LBB0_80:                                ; %schedule.5
                                        ;   in Loop: Header=BB0_5 Depth=1
	cbz	w25, LBB0_85
; %bb.81:                               ; %convergence.cascade49.preheader
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	w9, #0                          ; =0x0
LBB0_82:                                ; %convergence.cascade49
                                        ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v2, v6, #7
	cmlt.8b	v2, v2, #0
	and.8b	v7, v2, v3
	addv.8b	b7, v7
	fmov	w10, s7
	umaxv.8b	b2, v2
	fmov	w12, s2
	sub	w13, w25, #1
	tst	w10, #0xff
	csel	w23, w13, wzr, ne
	lsl	w1, w11, w23
	and	w10, w1, w21
	tst	w10, #0xff
	cset	w13, ne
	str	q15, [sp, #1456]
	str	q14, [sp, #1472]
	ubfiz	x10, x23, #2, #3
	ldr	w14, [x28, x10]
	cmp	w14, #0
	cset	w4, eq
	and	w2, w13, w12
	ldrb	w12, [x20, w23, sxtw]
	and	w13, w12, #0x1
	fmov	s2, w13
	ubfx	w13, w12, #1, #1
	mov.b	v2[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v2[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v2[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v2[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v2[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v2[6], w13
	lsr	w12, w12, #7
	mov.b	v2[7], w12
	ldrb	w12, [x8, w23, sxtw]
	and	w13, w12, #0x1
	fmov	s7, w13
	ubfx	w13, w12, #1, #1
	mov.b	v7[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v7[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v7[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v7[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v7[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v7[6], w13
	lsr	w12, w12, #7
	mov.b	v7[7], w12
	orr.8b	v16, v6, v7
	and.8b	v17, v1, v2
	eor.8b	v17, v17, v16
	shl.8b	v17, v17, #7
	cmlt.8b	v17, v17, #0
	umaxv.8b	b17, v17
	fmov	w12, s17
	ands	w13, w2, w4
	csetm	w14, ne
	bics	w12, w13, w12
	csetm	w17, ne
	dup.8b	v17, w17
	dup.8b	v18, w14
	bic.8b	v19, v16, v17
	bit.8b	v7, v19, v18
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v3
	addv.8b	b7, v7
	str	b7, [x8, w23, sxtw]
	bic.8b	v2, v2, v17
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x20, w23, sxtw]
	csinv	w14, w19, w1, eq
	dup.8b	v2, w13
	and	w21, w14, w21
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	dup.8b	v7, w12
	and.8b	v7, v7, v16
	str	q5, [sp, #1424]
	str	q4, [sp, #1440]
	add	x12, sp, #1424
	ldr	w10, [x12, x10]
	csel	w25, w10, w25, ne
	bit.8b	v6, v7, v2
	shl.8b	v2, v6, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w10, s2
	cmp	w13, #1
	b.ne	LBB0_86
; %bb.83:                               ; %convergence.cascade49
                                        ;   in Loop: Header=BB0_82 Depth=2
	cmp	w25, #0
	ccmp	w9, #6, #2, ne
	b.hi	LBB0_86
; %bb.84:                               ; %convergence.cascade49
                                        ;   in Loop: Header=BB0_82 Depth=2
	add	w9, w9, #1
	tst	w10, #0xff
	b.ne	LBB0_82
	b	LBB0_86
LBB0_85:                                ; %schedule.5.convergence.cascade.exit50_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v2, v6, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w10, s2
LBB0_86:                                ; %convergence.cascade.exit50
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w10, #0xff
	b.eq	LBB0_4
; %bb.87:                               ; %convergence.target.5.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q7, [sp, #1696]
	ldr	q16, [sp, #1712]
	ldr	q2, [sp, #1664]
	ldr	q17, [sp, #1680]
	ldr	q18, [sp, #1632]
	ldr	q19, [sp, #1648]
	ldr	q20, [sp, #1600]
	ldr	q21, [sp, #1616]
	mov	b22, v6[2]
	mov.b	v22[4], v6[3]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	mov.16b	v28, v27
	ldr	q27, [sp, #128]                 ; 16-byte Folded Reload
	bit.16b	v21, v27, v22
	mov	b23, v6[0]
	mov.b	v23[4], v6[1]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v23, v23, #0
	bit.16b	v20, v27, v23
	mov	b24, v6[6]
	mov.b	v24[4], v6[7]
	ushll.2d	v24, v24, #0
	shl.2d	v24, v24, #63
	cmlt.2d	v24, v24, #0
	bit.16b	v19, v27, v24
	mov	b25, v6[4]
	mov.b	v25[4], v6[5]
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
Lloh22:
	adrp	x9, lCPI0_6@PAGE
	mov.16b	v8, v0
	mov.16b	v0, v31
	mov.16b	v31, v26
Lloh23:
	ldr	q26, [x9, lCPI0_6@PAGEOFF]
	bit.16b	v17, v26, v22
Lloh24:
	adrp	x9, lCPI0_4@PAGE
Lloh25:
	ldr	q26, [x9, lCPI0_4@PAGEOFF]
	bit.16b	v7, v26, v25
Lloh26:
	adrp	x9, lCPI0_7@PAGE
Lloh27:
	ldr	q26, [x9, lCPI0_7@PAGEOFF]
	str	q7, [sp, #1696]
Lloh28:
	adrp	x9, lCPI0_5@PAGE
Lloh29:
	ldr	q7, [x9, lCPI0_5@PAGEOFF]
	bit.16b	v18, v27, v25
	mov.16b	v27, v28
	bif.16b	v7, v16, v24
	str	q7, [sp, #1712]
	bit.16b	v2, v26, v23
	mov.16b	v26, v31
	mov.16b	v31, v0
	mov.16b	v0, v8
	str	q2, [sp, #1664]
	str	q17, [sp, #1680]
	str	q18, [sp, #1632]
	str	q19, [sp, #1648]
	str	q20, [sp, #1600]
	str	q21, [sp, #1616]
	bic.16b	v31, v31, v24
	bic.16b	v13, v13, v25
	bic.16b	v30, v30, v22
	bic.16b	v12, v12, v23
	b	LBB0_118
LBB0_88:                                ; %varying.coherent.false38
                                        ;   in Loop: Header=BB0_5 Depth=1
	zip2.8b	v2, v6, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmge.4s	v2, v2, #0
	ldr	q7, [sp, #288]                  ; 16-byte Folded Reload
	and.16b	v7, v2, v7
	str	q7, [sp, #288]                  ; 16-byte Folded Spill
	zip1.8b	v2, v6, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmge.4s	v2, v2, #0
	ldr	q7, [sp, #304]                  ; 16-byte Folded Reload
	and.16b	v7, v2, v7
	str	q7, [sp, #304]                  ; 16-byte Folded Spill
	add	x30, sp, #4, lsl #12            ; =16384
	add	x30, x30, #2168
Lloh30:
	adrp	x26, LJTI0_0@PAGE
Lloh31:
	add	x26, x26, LJTI0_0@PAGEOFF
	mov	w27, #256                       ; =0x100
	mov.16b	v10, v11
	mov.16b	v26, v12
	mov.16b	v27, v28
	mov.16b	v9, v30
	tbz	w9, #0, LBB0_91
LBB0_89:                                ;   in Loop: Header=BB0_5 Depth=1
	movi.8b	v11, #1
	mov.16b	v12, v29
	mov.16b	v30, v13
LBB0_90:                                ; %scheduler.loop.backedge
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v13, v31
	ldp	q29, q31, [sp, #256]            ; 32-byte Folded Reload
	b	LBB0_4
LBB0_91:                                ;   in Loop: Header=BB0_5 Depth=1
	movi.8b	v11, #1
	mov.16b	v12, v29
	mov.16b	v30, v13
	mov.16b	v13, v31
	ldp	q29, q31, [sp, #256]            ; 32-byte Folded Reload
	cbnz	w25, LBB0_75
LBB0_92:                                ; %schedule.4.convergence.cascade.exit_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v2, v6, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w10, s2
LBB0_93:                                ; %convergence.cascade.exit
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w10, #0xff
	b.eq	LBB0_4
; %bb.94:                               ; %convergence.target.4.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q2, [sp, #1840]
	ldr	q7, [sp, #1824]
	ldr	q16, [sp, #1808]
	ldr	q17, [sp, #1792]
	ldr	q18, [sp, #1856]
	ldr	q19, [sp, #1872]
	ldr	q20, [sp, #1888]
	ldr	q21, [sp, #1904]
	shl.2d	v22, v26, #5
	shl.2d	v23, v0, #5
	shl.2d	v24, v27, #5
	shl.2d	v25, v9, #5
	add.2d	v21, v21, v25
	add.2d	v20, v20, v24
	add.2d	v19, v19, v23
	add.2d	v18, v18, v22
	add.2d	v17, v17, v18
	add.2d	v16, v16, v19
	add.2d	v7, v7, v20
	add.2d	v2, v2, v21
	shl.8b	v18, v6, #7
	cmlt.8b	v18, v18, #0
	and.8b	v18, v18, v3
	addv.8b	b18, v18
	fmov	w9, s18
	tbnz	w9, #0, LBB0_104
; %bb.95:                               ; %else292
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #1, LBB0_105
LBB0_96:                                ; %else296
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #2, LBB0_106
LBB0_97:                                ; %else300
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #3, LBB0_107
LBB0_98:                                ; %else304
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #4, LBB0_108
LBB0_99:                                ; %else308
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #5, LBB0_109
LBB0_100:                               ; %else312
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #6, LBB0_110
LBB0_101:                               ; %else316
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w9, #7, LBB0_103
LBB0_102:                               ; %cond.store317
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x9, v2[1]
	ldr	q2, [sp, #288]                  ; 16-byte Folded Reload
	st1.s	{ v2 }[3], [x9]
LBB0_103:                               ; %else320
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v2, v6, v11
	ushll.8h	v2, v2, #0
	ushll.4s	v7, v2, #0
	ushll2.4s	v2, v2, #0
	uaddw2.2d	v9, v9, v2
	uaddw.2d	v27, v27, v2
	uaddw2.2d	v0, v0, v7
	uaddw.2d	v26, v26, v7
	b	LBB0_45
LBB0_104:                               ; %cond.store289
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d17
	ldr	q18, [sp, #304]                 ; 16-byte Folded Reload
	str	s18, [x10]
	tbz	w9, #1, LBB0_96
LBB0_105:                               ; %cond.store293
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v17[1]
	ldr	q17, [sp, #304]                 ; 16-byte Folded Reload
	st1.s	{ v17 }[1], [x10]
	tbz	w9, #2, LBB0_97
LBB0_106:                               ; %cond.store297
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d16
	ldr	q17, [sp, #304]                 ; 16-byte Folded Reload
	st1.s	{ v17 }[2], [x10]
	tbz	w9, #3, LBB0_98
LBB0_107:                               ; %cond.store301
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v16[1]
	ldr	q16, [sp, #304]                 ; 16-byte Folded Reload
	st1.s	{ v16 }[3], [x10]
	tbz	w9, #4, LBB0_99
LBB0_108:                               ; %cond.store305
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d7
	ldr	q16, [sp, #288]                 ; 16-byte Folded Reload
	str	s16, [x10]
	tbz	w9, #5, LBB0_100
LBB0_109:                               ; %cond.store309
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v7[1]
	ldr	q7, [sp, #288]                  ; 16-byte Folded Reload
	st1.s	{ v7 }[1], [x10]
	tbz	w9, #6, LBB0_101
LBB0_110:                               ; %cond.store313
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d2
	ldr	q7, [sp, #288]                  ; 16-byte Folded Reload
	st1.s	{ v7 }[2], [x10]
	tbnz	w9, #7, LBB0_102
	b	LBB0_103
LBB0_111:                               ; %cond.load240
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d19
	ldr	s7, [x10]
	mov.16b	v13, v31
	ldr	q29, [sp, #256]                 ; 16-byte Folded Reload
	tbz	w9, #1, LBB0_66
LBB0_112:                               ; %cond.load246
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v19[1]
	ld1.s	{ v7 }[1], [x10]
	ldr	q31, [sp, #272]                 ; 16-byte Folded Reload
	tbz	w9, #2, LBB0_67
LBB0_113:                               ; %cond.load252
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d18
	ld1.s	{ v7 }[2], [x10]
	tbz	w9, #3, LBB0_68
LBB0_114:                               ; %cond.load258
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v18[1]
	ld1.s	{ v7 }[3], [x10]
	tbz	w9, #4, LBB0_69
LBB0_115:                               ; %cond.load264
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d17
	ld1.s	{ v16 }[0], [x10]
	tbz	w9, #5, LBB0_70
LBB0_116:                               ; %cond.load270
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v17[1]
	ld1.s	{ v16 }[1], [x10]
	tbz	w9, #6, LBB0_71
LBB0_117:                               ; %cond.load276
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d2
	ld1.s	{ v16 }[2], [x10]
	tbnz	w9, #7, LBB0_72
	b	LBB0_73
LBB0_118:                               ; %schedule.6
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v2, v6, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w10, s2
	dup.2d	v2, x27
	cmgt.2d	v7, v2, v30
	cmgt.2d	v16, v2, v12
	uzp1.4s	v7, v16, v7
	cmgt.2d	v16, v2, v13
	cmgt.2d	v17, v2, v31
	uzp1.4s	v16, v16, v17
	uzp1.8h	v7, v7, v16
	xtn.8b	v7, v7
	and.8b	v7, v6, v7
	shl.8b	v7, v7, #7
	cmlt.8b	v16, v7, #0
	and.8b	v7, v16, v3
	addv.8b	b7, v7
	fmov	w9, s7
	umaxv.8b	b16, v16
	fmov	w13, s16
	tbz	w13, #0, LBB0_125
; %bb.119:                              ; %schedule.6
                                        ;   in Loop: Header=BB0_5 Depth=1
	cmge.2d	v16, v30, v2
	cmge.2d	v17, v12, v2
	uzp1.4s	v16, v17, v16
	cmge.2d	v17, v13, v2
	cmge.2d	v2, v31, v2
	uzp1.4s	v2, v17, v2
	uzp1.8h	v2, v16, v2
	xtn.8b	v2, v2
	and.8b	v2, v6, v2
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b16, v2
	fmov	w13, s16
	tst	w13, #0xff
	b.eq	LBB0_125
; %bb.120:                              ; %varying.divergent67
                                        ;   in Loop: Header=BB0_5 Depth=1
	subs	w9, w25, #1
	csel	w9, wzr, w9, lo
	and	w10, w21, #0xff
	lsr	w12, w10, w9
	tst	w12, #0x1
	stp	q15, q14, [sp, #864]
	and	x9, x9, #0x7
	add	x12, sp, #864
	ldr	w9, [x12, x9, lsl #2]
	ccmp	w25, #0, #4, ne
	ccmp	w9, #2, #0, ne
	cset	w9, ne
	cmp	w10, #255
	b.ne	LBB0_122
; %bb.121:                              ; %varying.divergent67
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #0, LBB0_253
LBB0_122:                               ; %convergence.overflow.resume70
                                        ;   in Loop: Header=BB0_5 Depth=1
	mvn	w10, w21
	rbit	w10, w10
	clz	w10, w10
	mov	w12, #255                       ; =0xff
	bics	wzr, w12, w21
	csel	w10, wzr, w10, eq
	ubfiz	x12, x10, #2, #3
	lsl	w13, w11, w10
	stp	q15, q14, [sp, #832]
	add	x14, sp, #832
	ldr	w14, [x14, x12]
	cmp	w9, #0
	csel	w9, w13, wzr, ne
	mov	w13, #2                         ; =0x2
	csel	w13, w13, w14, ne
	stp	q15, q14, [sp, #800]
	add	x14, sp, #800
	str	w13, [x14, x12]
	ldp	q15, q14, [sp, #800]
	stp	q5, q4, [sp, #768]
	add	x13, sp, #768
	ldr	w13, [x13, x12]
	csel	w13, w25, w13, ne
	stp	q5, q4, [sp, #736]
	add	x14, sp, #736
	str	w13, [x14, x12]
	ldrb	w12, [x20, x10]
	and	w13, w12, #0x1
	fmov	s2, w13
	ubfx	w13, w12, #1, #1
	mov.b	v2[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v2[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v2[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v2[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v2[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v2[6], w13
	ldp	q5, q4, [sp, #736]
	lsr	w12, w12, #7
	mov.b	v2[7], w12
	ldrb	w12, [x8, x10]
	and	w13, w12, #0x1
	fmov	s17, w13
	ubfx	w13, w12, #1, #1
	mov.b	v17[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v17[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v17[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v17[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v17[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v17[6], w13
	lsr	w12, w12, #7
	mov.b	v17[7], w12
	csetm	w12, ne
	dup.8b	v18, w12
	bit.8b	v2, v6, v18
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x20, x10]
	bic.8b	v2, v17, v18
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x8, x10]
	csinc	w10, w25, w10, eq
	cmp	w5, #8
	b.hs	LBB0_253
; %bb.123:                              ; %ready.overflow.resume72
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b7, [x30, x24]
	mov	w12, #7                         ; =0x7
	str	w12, [x0, x24, lsl #2]
	str	w10, [x15, x24, lsl #2]
	cmp	w6, #8
	b.hs	LBB0_253
; %bb.124:                              ; %ready.overflow.resume74
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b16, [x30, w6, uxtw]
	orr	w21, w9, w21
	mov	w9, #8                          ; =0x8
	b	LBB0_3
LBB0_125:                               ; %varying.coherent68
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w9, #0xff
	b.eq	LBB0_161
; %bb.126:                              ; %varying.coherent.true75
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w10, #0xff
	b.eq	LBB0_4
; %bb.127:                              ;   in Loop: Header=BB0_5 Depth=1
	mov	w9, #0                          ; =0x0
LBB0_128:                               ; %schedule.7
                                        ;   in Loop: Header=BB0_5 Depth=1
	stp	q29, q27, [sp, #256]            ; 32-byte Folded Spill
	mov.16b	v28, v0
	mov.16b	v17, v30
	mov.16b	v30, v9
	mov.16b	v7, v12
	mov.16b	v12, v26
	mov.16b	v11, v10
	mov	b2, v6[0]
	mov.b	v2[4], v6[1]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v19, v2, #0
	mov.16b	v29, v7
	and.16b	v16, v19, v7
	mov	b2, v6[2]
	mov.b	v2[4], v6[3]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v20, v2, #0
	mov.16b	v7, v13
	mov.16b	v13, v17
	and.16b	v17, v20, v17
	mov	b2, v6[4]
	mov.b	v2[4], v6[5]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v21, v2, #0
	mov.16b	v23, v31
	mov.16b	v31, v7
	and.16b	v18, v21, v7
	mov	b2, v6[6]
	mov.b	v2[4], v6[7]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v22, v2, #0
	mov.16b	v0, v23
	and.16b	v2, v22, v23
	shl.8b	v7, v6, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v3
	addv.8b	b7, v7
	fmov	w10, s7
	mov	w12, #16                        ; =0x10
	dup.2d	v23, x12
	and.16b	v24, v19, v23
	mvn.16b	v19, v19
	sub.2d	v19, v24, v19
	and.16b	v24, v20, v23
	mvn.16b	v20, v20
	sub.2d	v20, v24, v20
	and.16b	v24, v21, v23
	and.16b	v23, v22, v23
	mvn.16b	v22, v22
	sub.2d	v22, v23, v22
	mov.d	x1, v22[1]
	mov.d	x13, v2[1]
	sdiv	x23, x13, x1
	mvn.16b	v21, v21
	sub.2d	v21, v24, v21
	fmov	x13, d22
	fmov	x14, d2
	sdiv	x14, x14, x13
	mul	x13, x14, x13
	fmov	d22, x14
	mov.d	v22[1], x23
	mov.d	x14, v21[1]
	mov.d	x17, v18[1]
	sdiv	x17, x17, x14
	fmov	x0, d21
	fmov	x2, d18
	sdiv	x2, x2, x0
	mul	x0, x2, x0
	fmov	d21, x2
	mov.d	v21[1], x17
	mov.d	x2, v20[1]
	mov.d	x4, v17[1]
	sdiv	x4, x4, x2
	fmov	x26, d20
	fmov	x27, d17
	sdiv	x27, x27, x26
	mul	x26, x27, x26
	fmov	d20, x27
	mov.d	v20[1], x4
	mov.d	x27, v19[1]
	mov.d	x28, v16[1]
	fmov	x30, d19
	fmov	x12, d16
	sdiv	x12, x12, x30
	mul	x30, x12, x30
	fmov	d19, x12
	sdiv	x12, x28, x27
	mov.d	v19[1], x12
	mul	x12, x12, x27
	fmov	d23, x30
	mov.d	v23[1], x12
	mul	x12, x4, x2
	fmov	d24, x26
	mov.d	v24[1], x12
	mul	x12, x17, x14
	fmov	d25, x0
	mov.d	v25[1], x12
	mul	x12, x23, x1
	fmov	d26, x13
	mov.d	v26[1], x12
	sub.2d	v2, v2, v26
	sub.2d	v18, v18, v25
	sub.2d	v17, v17, v24
	sub.2d	v16, v16, v23
	ldr	q23, [sp, #1792]
	ldr	q24, [sp, #1808]
	ldr	q25, [sp, #1824]
	ldr	q26, [sp, #1840]
	ldr	q27, [sp, #1904]
	ldr	q8, [sp, #1888]
	ldr	q9, [sp, #1872]
	ldr	q10, [sp, #1856]
	shl.2d	v16, v16, #9
	shl.2d	v17, v17, #9
	shl.2d	v18, v18, #9
	shl.2d	v2, v2, #9
	shl.2d	v19, v19, #5
	shl.2d	v20, v20, #5
	shl.2d	v21, v21, #5
	shl.2d	v22, v22, #5
	add.2d	v10, v19, v10
	add.2d	v19, v20, v9
	add.2d	v20, v21, v8
	add.2d	v21, v22, v27
	add.2d	v21, v26, v21
	add.2d	v2, v21, v2
	add.2d	v20, v25, v20
	add.2d	v18, v20, v18
	add.2d	v19, v24, v19
	add.2d	v19, v19, v17
	add.2d	v17, v23, v10
	add.2d	v20, v17, v16
	movi.2d	v17, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbz	w10, #0, LBB0_130
; %bb.129:                              ; %cond.load85
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x12, d20
	ldr	s17, [x12]
LBB0_130:                               ; %else89
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w10, #1, LBB0_132
; %bb.131:                              ; %cond.load91
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x12, v20[1]
	ld1.s	{ v17 }[1], [x12]
LBB0_132:                               ; %else95
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x30, sp, #4, lsl #12            ; =16384
	add	x30, x30, #2168
	add	x0, sp, #4, lsl #12             ; =16384
	add	x0, x0, #2136
Lloh32:
	adrp	x26, LJTI0_0@PAGE
Lloh33:
	add	x26, x26, LJTI0_0@PAGEOFF
	mov	w27, #256                       ; =0x100
	mov.16b	v10, v11
	mov.16b	v9, v30
	add	x28, sp, #1456
	movi.8b	v11, #1
	mov.16b	v30, v13
	tbnz	w10, #2, LBB0_149
; %bb.133:                              ; %else101
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v13, v31
	mov.16b	v31, v0
	tbnz	w10, #3, LBB0_150
LBB0_134:                               ; %else107
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v0, v28
	tbnz	w10, #4, LBB0_151
LBB0_135:                               ; %else113
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #5, LBB0_152
LBB0_136:                               ; %else119
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #6, LBB0_153
LBB0_137:                               ; %else125
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w10, #7, LBB0_139
LBB0_138:                               ; %cond.load127
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v2[1]
	ld1.s	{ v16 }[3], [x10]
LBB0_139:                               ; %else131
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q2, [sp, #1648]
	ldr	q18, [sp, #1632]
	ldr	q19, [sp, #1616]
	ldr	q20, [sp, #1600]
	ldr	q21, [sp, #1664]
	ldr	q22, [sp, #1680]
	ldr	q23, [sp, #1696]
	ldr	q24, [sp, #1712]
	shl.2d	v25, v29, #5
	shl.2d	v26, v30, #5
	shl.2d	v27, v13, #5
	shl.2d	v8, v31, #5
	add.2d	v24, v24, v8
	add.2d	v23, v23, v27
	add.2d	v22, v22, v26
	add.2d	v21, v21, v25
	add.2d	v20, v20, v21
	add.2d	v19, v19, v22
	add.2d	v18, v18, v23
	add.2d	v2, v2, v24
	fmov	w10, s7
	tbnz	w10, #0, LBB0_154
; %bb.140:                              ; %else135
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v26, v12
	ldr	q27, [sp, #272]                 ; 16-byte Folded Reload
	tbnz	w10, #1, LBB0_155
LBB0_141:                               ; %else138
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v12, v29
	tbnz	w10, #2, LBB0_156
LBB0_142:                               ; %else141
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q29, [sp, #256]                 ; 16-byte Folded Reload
	tbnz	w10, #3, LBB0_157
LBB0_143:                               ; %else144
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #4, LBB0_158
LBB0_144:                               ; %else147
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #5, LBB0_159
LBB0_145:                               ; %else150
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #6, LBB0_160
LBB0_146:                               ; %else153
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w10, #7, LBB0_148
LBB0_147:                               ; %cond.store154
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v2[1]
	st1.s	{ v16 }[3], [x10]
LBB0_148:                               ; %else156
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v2, v6, v11
	ushll.8h	v2, v2, #0
	ushll.4s	v7, v2, #0
	ushll2.4s	v2, v2, #0
	uaddw2.2d	v31, v31, v2
	uaddw.2d	v13, v13, v2
	uaddw2.2d	v30, v30, v7
	uaddw.2d	v12, v12, v7
	tbnz	w9, #0, LBB0_4
	b	LBB0_118
LBB0_149:                               ; %cond.load97
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x12, d19
	ld1.s	{ v17 }[2], [x12]
	mov.16b	v13, v31
	mov.16b	v31, v0
	tbz	w10, #3, LBB0_134
LBB0_150:                               ; %cond.load103
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x12, v19[1]
	ld1.s	{ v17 }[3], [x12]
	mov.16b	v0, v28
	tbz	w10, #4, LBB0_135
LBB0_151:                               ; %cond.load109
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x12, d18
	ld1.s	{ v16 }[0], [x12]
	tbz	w10, #5, LBB0_136
LBB0_152:                               ; %cond.load115
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x12, v18[1]
	ld1.s	{ v16 }[1], [x12]
	tbz	w10, #6, LBB0_137
LBB0_153:                               ; %cond.load121
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x12, d2
	ld1.s	{ v16 }[2], [x12]
	tbnz	w10, #7, LBB0_138
	b	LBB0_139
LBB0_154:                               ; %cond.store
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x12, d20
	str	s17, [x12]
	mov.16b	v26, v12
	ldr	q27, [sp, #272]                 ; 16-byte Folded Reload
	tbz	w10, #1, LBB0_141
LBB0_155:                               ; %cond.store136
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x12, v20[1]
	st1.s	{ v17 }[1], [x12]
	mov.16b	v12, v29
	tbz	w10, #2, LBB0_142
LBB0_156:                               ; %cond.store139
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x12, d19
	st1.s	{ v17 }[2], [x12]
	ldr	q29, [sp, #256]                 ; 16-byte Folded Reload
	tbz	w10, #3, LBB0_143
LBB0_157:                               ; %cond.store142
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x12, v19[1]
	st1.s	{ v17 }[3], [x12]
	tbz	w10, #4, LBB0_144
LBB0_158:                               ; %cond.store145
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x12, d18
	str	s16, [x12]
	tbz	w10, #5, LBB0_145
LBB0_159:                               ; %cond.store148
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x12, v18[1]
	st1.s	{ v16 }[1], [x12]
	tbz	w10, #6, LBB0_146
LBB0_160:                               ; %cond.store151
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x12, d2
	st1.s	{ v16 }[2], [x12]
	tbnz	w10, #7, LBB0_147
	b	LBB0_148
LBB0_161:                               ; %varying.coherent.false76
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w10, #0xff
	b.eq	LBB0_4
LBB0_162:                               ; %schedule.8
                                        ;   in Loop: Header=BB0_5 Depth=1
	cbz	w25, LBB0_167
; %bb.163:                              ; %convergence.cascade83.preheader
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	w9, #0                          ; =0x0
LBB0_164:                               ; %convergence.cascade83
                                        ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v2, v6, #7
	cmlt.8b	v2, v2, #0
	and.8b	v7, v2, v3
	addv.8b	b7, v7
	fmov	w10, s7
	umaxv.8b	b2, v2
	fmov	w12, s2
	sub	w13, w25, #1
	tst	w10, #0xff
	csel	w23, w13, wzr, ne
	lsl	w1, w11, w23
	and	w10, w1, w21
	tst	w10, #0xff
	cset	w13, ne
	str	q15, [sp, #1392]
	str	q14, [sp, #1408]
	ubfiz	x10, x23, #2, #3
	add	x14, sp, #1392
	ldr	w14, [x14, x10]
	cmp	w14, #2
	cset	w4, eq
	and	w2, w13, w12
	ldrb	w12, [x20, w23, sxtw]
	and	w13, w12, #0x1
	fmov	s2, w13
	ubfx	w13, w12, #1, #1
	mov.b	v2[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v2[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v2[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v2[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v2[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v2[6], w13
	lsr	w12, w12, #7
	mov.b	v2[7], w12
	ldrb	w12, [x8, w23, sxtw]
	and	w13, w12, #0x1
	fmov	s7, w13
	ubfx	w13, w12, #1, #1
	mov.b	v7[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v7[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v7[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v7[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v7[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v7[6], w13
	lsr	w12, w12, #7
	mov.b	v7[7], w12
	orr.8b	v16, v6, v7
	and.8b	v17, v1, v2
	eor.8b	v17, v17, v16
	shl.8b	v17, v17, #7
	cmlt.8b	v17, v17, #0
	umaxv.8b	b17, v17
	fmov	w12, s17
	ands	w13, w2, w4
	csetm	w14, ne
	bics	w12, w13, w12
	csetm	w17, ne
	dup.8b	v17, w17
	dup.8b	v18, w14
	bic.8b	v19, v16, v17
	bit.8b	v7, v19, v18
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v3
	addv.8b	b7, v7
	str	b7, [x8, w23, sxtw]
	bic.8b	v2, v2, v17
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x20, w23, sxtw]
	csinv	w14, w19, w1, eq
	dup.8b	v2, w13
	and	w21, w14, w21
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	dup.8b	v7, w12
	and.8b	v7, v7, v16
	str	q5, [sp, #1360]
	str	q4, [sp, #1376]
	add	x12, sp, #1360
	ldr	w10, [x12, x10]
	csel	w25, w10, w25, ne
	bit.8b	v6, v7, v2
	shl.8b	v2, v6, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w10, s2
	cmp	w13, #1
	b.ne	LBB0_168
; %bb.165:                              ; %convergence.cascade83
                                        ;   in Loop: Header=BB0_164 Depth=2
	cmp	w25, #0
	ccmp	w9, #6, #2, ne
	b.hi	LBB0_168
; %bb.166:                              ; %convergence.cascade83
                                        ;   in Loop: Header=BB0_164 Depth=2
	add	w9, w9, #1
	tst	w10, #0xff
	b.ne	LBB0_164
	b	LBB0_168
LBB0_167:                               ; %schedule.8.convergence.cascade.exit84_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v2, v6, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w10, s2
LBB0_168:                               ; %convergence.cascade.exit84
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w10, #0xff
	b.eq	LBB0_4
; %bb.169:                              ; %convergence.target.8.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	b2, v6[6]
	mov.b	v2[4], v6[7]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmge.2d	v2, v2, #0
	ldp	q7, q16, [sp, #320]             ; 32-byte Folded Reload
	and.16b	v7, v2, v7
	str	q7, [sp, #320]                  ; 16-byte Folded Spill
	mov	b2, v6[4]
	mov.b	v2[4], v6[5]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmge.2d	v2, v2, #0
	mov	b7, v6[2]
	mov.b	v7[4], v6[3]
	and.16b	v16, v2, v16
	str	q16, [sp, #336]                 ; 16-byte Folded Spill
	ushll.2d	v2, v7, #0
	shl.2d	v2, v2, #63
	cmge.2d	v2, v2, #0
	and.16b	v10, v2, v10
	mov	b2, v6[0]
	mov.b	v2[4], v6[1]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmge.2d	v2, v2, #0
	and.16b	v29, v2, v29
LBB0_170:                               ; %schedule.9
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v2, v6, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w10, s2
	dup.2d	v2, x27
	cmgt.2d	v7, v2, v10
	cmgt.2d	v16, v2, v29
	uzp1.4s	v7, v16, v7
	ldp	q17, q16, [sp, #320]            ; 32-byte Folded Reload
	cmgt.2d	v16, v2, v16
	cmgt.2d	v17, v2, v17
	uzp1.4s	v16, v16, v17
	uzp1.8h	v7, v7, v16
	xtn.8b	v7, v7
	and.8b	v7, v6, v7
	shl.8b	v7, v7, #7
	cmlt.8b	v16, v7, #0
	and.8b	v7, v16, v3
	addv.8b	b7, v7
	fmov	w9, s7
	umaxv.8b	b16, v16
	fmov	w12, s16
	tbz	w12, #0, LBB0_177
; %bb.171:                              ; %schedule.9
                                        ;   in Loop: Header=BB0_5 Depth=1
	cmge.2d	v16, v10, v2
	cmge.2d	v17, v29, v2
	uzp1.4s	v16, v17, v16
	ldp	q18, q17, [sp, #320]            ; 32-byte Folded Reload
	cmge.2d	v17, v17, v2
	cmge.2d	v2, v18, v2
	uzp1.4s	v2, v17, v2
	uzp1.8h	v2, v16, v2
	xtn.8b	v2, v2
	and.8b	v2, v6, v2
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b16, v2
	fmov	w12, s16
	tst	w12, #0xff
	b.eq	LBB0_177
; %bb.172:                              ; %varying.divergent101
                                        ;   in Loop: Header=BB0_5 Depth=1
	subs	w9, w25, #1
	csel	w9, wzr, w9, lo
	and	w10, w21, #0xff
	lsr	w12, w10, w9
	tst	w12, #0x1
	str	q15, [sp, #1024]
	str	q14, [sp, #1040]
	and	x9, x9, #0x7
	add	x12, sp, #1024
	ldr	w9, [x12, x9, lsl #2]
	ccmp	w25, #0, #4, ne
	ccmp	w9, #3, #0, ne
	cset	w9, ne
	cmp	w10, #255
	b.ne	LBB0_174
; %bb.173:                              ; %varying.divergent101
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #0, LBB0_253
LBB0_174:                               ; %convergence.overflow.resume104
                                        ;   in Loop: Header=BB0_5 Depth=1
	mvn	w10, w21
	rbit	w10, w10
	clz	w10, w10
	mov	w12, #255                       ; =0xff
	bics	wzr, w12, w21
	csel	w10, wzr, w10, eq
	ubfiz	x12, x10, #2, #3
	lsl	w13, w11, w10
	stp	q15, q14, [sp, #992]
	add	x14, sp, #992
	ldr	w14, [x14, x12]
	cmp	w9, #0
	csel	w9, w13, wzr, ne
	mov	w13, #3                         ; =0x3
	csel	w13, w13, w14, ne
	stp	q15, q14, [sp, #960]
	add	x14, sp, #960
	str	w13, [x14, x12]
	ldp	q15, q14, [sp, #960]
	stp	q5, q4, [sp, #928]
	add	x13, sp, #928
	ldr	w13, [x13, x12]
	csel	w13, w25, w13, ne
	stp	q5, q4, [sp, #896]
	add	x14, sp, #896
	str	w13, [x14, x12]
	ldrb	w12, [x20, x10]
	and	w13, w12, #0x1
	fmov	s2, w13
	ubfx	w13, w12, #1, #1
	mov.b	v2[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v2[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v2[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v2[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v2[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v2[6], w13
	ldp	q5, q4, [sp, #896]
	lsr	w12, w12, #7
	mov.b	v2[7], w12
	ldrb	w12, [x8, x10]
	and	w13, w12, #0x1
	fmov	s17, w13
	ubfx	w13, w12, #1, #1
	mov.b	v17[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v17[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v17[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v17[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v17[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v17[6], w13
	lsr	w12, w12, #7
	mov.b	v17[7], w12
	csetm	w12, ne
	dup.8b	v18, w12
	bit.8b	v2, v6, v18
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x20, x10]
	bic.8b	v2, v17, v18
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x8, x10]
	csinc	w10, w25, w10, eq
	cmp	w5, #8
	b.hs	LBB0_253
; %bb.175:                              ; %ready.overflow.resume106
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b7, [x30, x24]
	mov	w12, #10                        ; =0xa
	str	w12, [x0, x24, lsl #2]
	str	w10, [x15, x24, lsl #2]
	cmp	w6, #8
	b.hs	LBB0_253
; %bb.176:                              ; %ready.overflow.resume108
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b16, [x30, w6, uxtw]
	orr	w21, w9, w21
	mov	w9, #13                         ; =0xd
	b	LBB0_3
LBB0_177:                               ; %varying.coherent102
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w9, #0xff
	b.eq	LBB0_212
; %bb.178:                              ; %varying.coherent.true109
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w10, #0xff
	b.eq	LBB0_4
; %bb.179:                              ;   in Loop: Header=BB0_5 Depth=1
	mov	w9, #0                          ; =0x0
LBB0_180:                               ; %schedule.10
                                        ;   in Loop: Header=BB0_5 Depth=1
	stp	q9, q30, [sp, #208]             ; 32-byte Folded Spill
	mov.16b	v30, v27
	stp	q0, q13, [sp, #240]             ; 32-byte Folded Spill
	mov.16b	v0, v31
	mov.16b	v31, v26
	str	q0, [sp, #272]                  ; 16-byte Folded Spill
	mov.16b	v0, v29
	mov.16b	v29, v12
	mov	b2, v6[0]
	mov.b	v2[4], v6[1]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v16, v2, #0
	and.16b	v24, v16, v0
	mov	b2, v6[2]
	mov.b	v2[4], v6[3]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v17, v2, #0
	and.16b	v22, v17, v10
	mov	b2, v6[4]
	mov.b	v2[4], v6[5]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v18, v2, #0
	mov	b2, v6[6]
	mov.b	v2[4], v6[7]
	ldp	q28, q13, [sp, #320]            ; 32-byte Folded Reload
	and.16b	v23, v18, v13
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v19, v2, #0
	and.16b	v2, v19, v28
	shl.8b	v7, v6, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v3
	mov	w10, #16                        ; =0x10
	dup.2d	v25, x10
	and.16b	v20, v16, v25
	mvn.16b	v21, v16
	sub.2d	v21, v20, v21
	and.16b	v20, v17, v25
	mvn.16b	v26, v17
	sub.2d	v20, v20, v26
	and.16b	v26, v18, v25
	and.16b	v25, v19, v25
	mvn.16b	v27, v19
	sub.2d	v25, v25, v27
	mov.d	x10, v25[1]
	mov.d	x12, v2[1]
	mvn.16b	v27, v18
	sdiv	x1, x12, x10
	sub.2d	v26, v26, v27
	fmov	x12, d25
	fmov	x13, d2
	sdiv	x13, x13, x12
	mul	x12, x13, x12
	fmov	d25, x13
	mov.d	v25[1], x1
	mov.d	x13, v26[1]
	mov.d	x14, v23[1]
	sdiv	x14, x14, x13
	fmov	x17, d26
	fmov	x0, d23
	sdiv	x0, x0, x17
	mul	x17, x0, x17
	fmov	d26, x0
	mov.d	v26[1], x14
	mov.d	x0, v20[1]
	mov.d	x2, v22[1]
	sdiv	x2, x2, x0
	fmov	x4, d20
	fmov	x23, d22
	sdiv	x23, x23, x4
	mul	x4, x23, x4
	fmov	d20, x23
	mov.d	v20[1], x2
	mov.d	x23, v21[1]
	mov.d	x26, v24[1]
	fmov	x27, d21
	fmov	x28, d24
	sdiv	x28, x28, x27
	mul	x27, x28, x27
	fmov	d21, x28
	sdiv	x26, x26, x23
	mov.d	v21[1], x26
	mul	x23, x26, x23
	fmov	d27, x27
	mov.d	v27[1], x23
	mul	x0, x2, x0
	fmov	d8, x4
	mov.d	v8[1], x0
	addv.8b	b7, v7
	mul	x13, x14, x13
	fmov	d9, x17
	mov.d	v9[1], x13
	mul	x10, x1, x10
	mov.16b	v12, v10
	fmov	d10, x12
	mov.d	v10[1], x10
	sub.2d	v2, v2, v10
	sub.2d	v23, v23, v9
	sub.2d	v22, v22, v8
	sub.2d	v24, v24, v27
	ldr	q27, [sp, #1968]
	ldr	q8, [sp, #1952]
	ldr	q9, [sp, #1936]
	ldr	q10, [sp, #1920]
	add.2d	v21, v10, v21
	add.2d	v20, v9, v20
	add.2d	v26, v8, v26
	add.2d	v25, v27, v25
	mov	w10, #129                       ; =0x81
	dup.2d	v27, x10
	cmhi.2d	v8, v27, v25
	cmhi.2d	v9, v27, v26
	uzp1.4s	v8, v9, v8
	cmhi.2d	v9, v27, v20
	cmhi.2d	v27, v27, v21
	uzp1.4s	v27, v27, v9
	uzp1.8h	v27, v27, v8
	ldr	q8, [sp, #2032]
	ldr	q9, [sp, #2016]
	ldr	q10, [sp, #2000]
	ldr	q11, [sp, #1984]
	add.2d	v24, v11, v24
	add.2d	v22, v10, v22
	mov.16b	v10, v12
	add.2d	v23, v9, v23
	add.2d	v2, v8, v2
	mov.d	x10, v21[1]
	fmov	x12, d21
	add	x12, x12, x12, lsl #6
	fmov	d21, x12
	add	x10, x10, x10, lsl #6
	mov.d	v21[1], x10
	mov.d	x10, v20[1]
	fmov	x12, d20
	add	x12, x12, x12, lsl #6
	fmov	d20, x12
	add	x10, x10, x10, lsl #6
	mov.d	v20[1], x10
	mov.d	x10, v26[1]
	fmov	x12, d26
	add	x12, x12, x12, lsl #6
	fmov	d26, x12
	add	x10, x10, x10, lsl #6
	mov.d	v26[1], x10
	mov.d	x10, v25[1]
	fmov	x12, d25
	add	x12, x12, x12, lsl #6
	fmov	d25, x12
	add	x10, x10, x10, lsl #6
	mov.d	v25[1], x10
	mov	w10, #65                        ; =0x41
	dup.2d	v8, x10
	add.2d	v25, v25, v2
	add.2d	v26, v26, v23
	add.2d	v20, v20, v22
	add.2d	v21, v21, v24
	cmhi.2d	v2, v8, v2
	cmhi.2d	v23, v8, v23
	uzp1.4s	v2, v23, v2
	cmhi.2d	v22, v8, v22
	cmhi.2d	v23, v8, v24
	uzp1.4s	v22, v23, v22
	uzp1.8h	v2, v22, v2
	and.16b	v2, v27, v2
	xtn.8b	v24, v2
	ldr	q2, [sp, #1584]
	ldr	q22, [sp, #1568]
	ldr	q23, [sp, #1552]
	ldr	q27, [sp, #1536]
	bsl.16b	v16, v21, v27
	bsl.16b	v17, v20, v23
	bsl.16b	v18, v26, v22
	bit.16b	v2, v25, v19
	str	q2, [sp, #1584]
	str	q18, [sp, #1568]
	str	q17, [sp, #1552]
	str	q16, [sp, #1536]
	ldr	q16, [sp, #1600]
	ldr	q17, [sp, #1616]
	ldr	q18, [sp, #1632]
	ldr	q2, [sp, #1648]
	ldr	q19, [sp, #1712]
	ldr	q20, [sp, #1696]
	ldr	q21, [sp, #1680]
	ldr	q22, [sp, #1664]
	shl.2d	v23, v28, #5
	shl.2d	v25, v13, #5
	shl.2d	v26, v12, #5
	mov.16b	v8, v0
	shl.2d	v27, v0, #5
	add.2d	v22, v22, v27
	add.2d	v21, v21, v26
	add.2d	v20, v20, v25
	add.2d	v19, v19, v23
	fmov	w10, s7
	add.2d	v2, v2, v19
	add.2d	v18, v18, v20
	add.2d	v19, v17, v21
	add.2d	v20, v16, v22
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbz	w10, #0, LBB0_182
; %bb.181:                              ; %cond.load158
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x12, d20
	ldr	s16, [x12]
LBB0_182:                               ; %else162
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w10, #1, LBB0_184
; %bb.183:                              ; %cond.load164
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x12, v20[1]
	ld1.s	{ v16 }[1], [x12]
LBB0_184:                               ; %else168
                                        ;   in Loop: Header=BB0_5 Depth=1
	movi.8b	v11, #1
	add	x0, sp, #4, lsl #12             ; =16384
	add	x0, x0, #2136
Lloh34:
	adrp	x26, LJTI0_0@PAGE
Lloh35:
	add	x26, x26, LJTI0_0@PAGEOFF
	mov	w27, #256                       ; =0x100
	mov.16b	v12, v29
	mov.16b	v26, v31
	mov.16b	v27, v30
	ldp	q9, q30, [sp, #208]             ; 32-byte Folded Reload
	add	x28, sp, #1456
	ldr	q0, [sp, #240]                  ; 16-byte Folded Reload
	tbnz	w10, #2, LBB0_207
; %bb.185:                              ; %else174
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldp	q13, q31, [sp, #256]            ; 32-byte Folded Reload
	tbnz	w10, #3, LBB0_208
LBB0_186:                               ; %else180
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v29, v8
	tbnz	w10, #4, LBB0_209
LBB0_187:                               ; %else186
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #5, LBB0_210
LBB0_188:                               ; %else192
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #6, LBB0_211
LBB0_189:                               ; %else198
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w10, #7, LBB0_191
LBB0_190:                               ; %cond.load200
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v2[1]
	ld1.s	{ v17 }[3], [x10]
LBB0_191:                               ; %else204
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q2, [sp, #1520]
	ldr	q18, [sp, #1504]
	zip1.8b	v19, v6, v0
	ushll.4s	v19, v19, #0
	shl.4s	v19, v19, #31
	cmlt.4s	v19, v19, #0
	bif.16b	v16, v18, v19
	zip2.8b	v18, v6, v0
	ushll.4s	v18, v18, #0
	shl.4s	v18, v18, #31
	cmlt.4s	v18, v18, #0
	bit.16b	v2, v17, v18
	str	q2, [sp, #1520]
	str	q16, [sp, #1504]
	and.8b	v2, v6, v24
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v16, v2, v3
	addv.8b	b16, v16
	fmov	w10, s16
	umaxv.8b	b2, v2
	fmov	w12, s2
	tbz	w12, #0, LBB0_197
; %bb.192:                              ; %else204
                                        ;   in Loop: Header=BB0_5 Depth=1
	bic.8b	v2, v6, v24
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b17, v2
	fmov	w12, s17
	tst	w12, #0xff
	b.eq	LBB0_197
; %bb.193:                              ; %varying.divergent117
                                        ;   in Loop: Header=BB0_5 Depth=1
	subs	w9, w25, #1
	csel	w9, wzr, w9, lo
	and	w10, w21, #0xff
	lsr	w12, w10, w9
	tst	w12, #0x1
	str	q15, [sp, #1184]
	str	q14, [sp, #1200]
	and	x9, x9, #0x7
	add	x12, sp, #1184
	ldr	w9, [x12, x9, lsl #2]
	ccmp	w25, #0, #4, ne
	ccmp	w9, #4, #0, ne
	cset	w9, ne
	cmp	w10, #255
	b.ne	LBB0_195
; %bb.194:                              ; %varying.divergent117
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #0, LBB0_253
LBB0_195:                               ; %convergence.overflow.resume120
                                        ;   in Loop: Header=BB0_5 Depth=1
	mvn	w10, w21
	rbit	w10, w10
	clz	w10, w10
	mov	w12, #255                       ; =0xff
	bics	wzr, w12, w21
	csel	w10, wzr, w10, eq
	ubfiz	x12, x10, #2, #3
	lsl	w13, w11, w10
	str	q15, [sp, #1152]
	str	q14, [sp, #1168]
	add	x14, sp, #1152
	ldr	w14, [x14, x12]
	cmp	w9, #0
	csel	w9, w13, wzr, ne
	mov	w13, #4                         ; =0x4
	csel	w13, w13, w14, ne
	str	q15, [sp, #1120]
	str	q14, [sp, #1136]
	add	x14, sp, #1120
	str	w13, [x14, x12]
	ldr	q14, [sp, #1136]
	ldr	q15, [sp, #1120]
	str	q5, [sp, #1088]
	str	q4, [sp, #1104]
	add	x13, sp, #1088
	ldr	w13, [x13, x12]
	csel	w13, w25, w13, ne
	str	q5, [sp, #1056]
	str	q4, [sp, #1072]
	add	x14, sp, #1056
	str	w13, [x14, x12]
	ldrb	w12, [x20, x10]
	and	w13, w12, #0x1
	fmov	s2, w13
	ubfx	w13, w12, #1, #1
	mov.b	v2[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v2[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v2[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v2[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v2[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v2[6], w13
	ldr	q4, [sp, #1072]
	ldr	q5, [sp, #1056]
	lsr	w12, w12, #7
	mov.b	v2[7], w12
	ldrb	w12, [x8, x10]
	and	w13, w12, #0x1
	fmov	s7, w13
	ubfx	w13, w12, #1, #1
	mov.b	v7[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v7[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v7[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v7[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v7[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v7[6], w13
	lsr	w12, w12, #7
	mov.b	v7[7], w12
	csetm	w12, ne
	dup.8b	v18, w12
	bit.8b	v2, v6, v18
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x20, x10]
	bic.8b	v2, v7, v18
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x8, x10]
	csinc	w10, w25, w10, eq
	cmp	w5, #8
	b.hs	LBB0_253
; %bb.196:                              ; %ready.overflow.resume122
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b16, [x30, x24]
	mov	w12, #11                        ; =0xb
	str	w12, [x0, x24, lsl #2]
	str	w10, [x15, x24, lsl #2]
	cmp	w6, #8
	b.lo	LBB0_2
	b	LBB0_253
LBB0_197:                               ; %varying.coherent118
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w10, #0xff
	b.eq	LBB0_233
; %bb.198:                              ; %varying.coherent.true125
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #0, LBB0_4
; %bb.199:                              ; %schedule.11.thread
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q16, [sp, #1584]
	ldr	q17, [sp, #1568]
	ldr	q19, [sp, #1552]
	ldr	q20, [sp, #1536]
	ldr	q2, [sp, #1520]
	ldr	q18, [sp, #1504]
	shl.2d	v20, v20, #2
	shl.2d	v19, v19, #2
	shl.2d	v17, v17, #2
	ldr	x9, [sp, #200]                  ; 8-byte Folded Reload
	dup.2d	v21, x9
	shl.2d	v16, v16, #2
	add.2d	v16, v21, v16
	add.2d	v17, v21, v17
	add.2d	v19, v21, v19
	add.2d	v20, v21, v20
	fmov	w9, s7
	tbnz	w9, #0, LBB0_235
; %bb.200:                              ; %else325
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #1, LBB0_236
LBB0_201:                               ; %else329
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #2, LBB0_237
LBB0_202:                               ; %else333
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #3, LBB0_238
LBB0_203:                               ; %else337
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #4, LBB0_239
LBB0_204:                               ; %else341
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #5, LBB0_240
LBB0_205:                               ; %else345
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #6, LBB0_241
LBB0_206:                               ; %else349
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #7, LBB0_242
	b	LBB0_243
LBB0_207:                               ; %cond.load170
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x12, d19
	ld1.s	{ v16 }[2], [x12]
	ldp	q13, q31, [sp, #256]            ; 32-byte Folded Reload
	tbz	w10, #3, LBB0_186
LBB0_208:                               ; %cond.load176
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x12, v19[1]
	ld1.s	{ v16 }[3], [x12]
	mov.16b	v29, v8
	tbz	w10, #4, LBB0_187
LBB0_209:                               ; %cond.load182
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x12, d18
	ld1.s	{ v17 }[0], [x12]
	tbz	w10, #5, LBB0_188
LBB0_210:                               ; %cond.load188
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x12, v18[1]
	ld1.s	{ v17 }[1], [x12]
	tbz	w10, #6, LBB0_189
LBB0_211:                               ; %cond.load194
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x12, d2
	ld1.s	{ v17 }[2], [x12]
	tbnz	w10, #7, LBB0_190
	b	LBB0_191
LBB0_212:                               ; %varying.coherent.false110
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w10, #0xff
	b.eq	LBB0_4
LBB0_213:                               ; %schedule.13
                                        ;   in Loop: Header=BB0_5 Depth=1
	cbz	w25, LBB0_218
; %bb.214:                              ; %convergence.cascade147.preheader
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	w9, #0                          ; =0x0
LBB0_215:                               ; %convergence.cascade147
                                        ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v2, v6, #7
	cmlt.8b	v2, v2, #0
	and.8b	v7, v2, v3
	addv.8b	b7, v7
	fmov	w10, s7
	umaxv.8b	b2, v2
	fmov	w12, s2
	sub	w13, w25, #1
	tst	w10, #0xff
	csel	w23, w13, wzr, ne
	lsl	w1, w11, w23
	and	w10, w1, w21
	tst	w10, #0xff
	cset	w13, ne
	str	q15, [sp, #1328]
	str	q14, [sp, #1344]
	ubfiz	x10, x23, #2, #3
	add	x14, sp, #1328
	ldr	w14, [x14, x10]
	cmp	w14, #3
	cset	w4, eq
	and	w2, w13, w12
	ldrb	w12, [x20, w23, sxtw]
	and	w13, w12, #0x1
	fmov	s2, w13
	ubfx	w13, w12, #1, #1
	mov.b	v2[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v2[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v2[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v2[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v2[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v2[6], w13
	lsr	w12, w12, #7
	mov.b	v2[7], w12
	ldrb	w12, [x8, w23, sxtw]
	and	w13, w12, #0x1
	fmov	s7, w13
	ubfx	w13, w12, #1, #1
	mov.b	v7[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v7[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v7[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v7[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v7[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v7[6], w13
	lsr	w12, w12, #7
	mov.b	v7[7], w12
	orr.8b	v16, v6, v7
	and.8b	v17, v1, v2
	eor.8b	v17, v17, v16
	shl.8b	v17, v17, #7
	cmlt.8b	v17, v17, #0
	umaxv.8b	b17, v17
	fmov	w12, s17
	ands	w13, w2, w4
	csetm	w14, ne
	bics	w12, w13, w12
	csetm	w17, ne
	dup.8b	v17, w17
	dup.8b	v18, w14
	bic.8b	v19, v16, v17
	bit.8b	v7, v19, v18
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v3
	addv.8b	b7, v7
	str	b7, [x8, w23, sxtw]
	bic.8b	v2, v2, v17
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x20, w23, sxtw]
	csinv	w14, w19, w1, eq
	dup.8b	v2, w13
	and	w21, w14, w21
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	dup.8b	v7, w12
	and.8b	v7, v7, v16
	str	q5, [sp, #1296]
	str	q4, [sp, #1312]
	add	x12, sp, #1296
	ldr	w10, [x12, x10]
	csel	w25, w10, w25, ne
	bit.8b	v6, v7, v2
	shl.8b	v2, v6, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w10, s2
	cmp	w13, #1
	b.ne	LBB0_219
; %bb.216:                              ; %convergence.cascade147
                                        ;   in Loop: Header=BB0_215 Depth=2
	cmp	w25, #0
	ccmp	w9, #6, #2, ne
	b.hi	LBB0_219
; %bb.217:                              ; %convergence.cascade147
                                        ;   in Loop: Header=BB0_215 Depth=2
	add	w9, w9, #1
	tst	w10, #0xff
	b.ne	LBB0_215
	b	LBB0_219
LBB0_218:                               ; %schedule.13.convergence.cascade.exit148_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v2, v6, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w10, s2
LBB0_219:                               ; %convergence.cascade.exit148
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w10, #0xff
	b.eq	LBB0_4
; %bb.220:                              ; %convergence.target.13.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	bic.8b	v1, v1, v6
	tst	w21, #0xff
	b.eq	LBB0_234
; %bb.221:                              ; %return.frame.cleanup
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldrb	w9, [x8, #8]
	and	w10, w9, #0x1
	fmov	s2, w10
	ubfx	w10, w9, #1, #1
	mov.b	v2[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v2[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v2[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v2[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v2[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v2[6], w10
	lsr	w9, w9, #7
	mov.b	v2[7], w9
	ldrb	w9, [x8]
	and	w10, w9, #0x1
	fmov	s16, w10
	ubfx	w10, w9, #1, #1
	mov.b	v16[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v16[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v16[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v16[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v16[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v16[6], w10
	lsr	w9, w9, #7
	mov.b	v16[7], w9
	and.8b	v17, v1, v2
	eor.8b	v2, v16, v17
	shl.8b	v2, v2, #7
	cmlt.8b	v6, v2, #0
	umaxv.8b	b2, v6
	fmov	w9, s2
	eor	w9, w9, #0x1
	and	w9, w21, w9
	dup.8b	v2, w9
	and.8b	v2, v2, v16
	shl.8b	v7, v2, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v3
	addv.8b	b7, v7
	fmov	w10, s7
	tst	w9, #0x1
	csetm	w9, ne
	dup.8b	v18, w9
	bic.8b	v17, v17, v18
	shl.8b	v17, v17, #7
	cmlt.8b	v17, v17, #0
	and.8b	v17, v17, v3
	addv.8b	b17, v17
	str	b17, [x8, #8]
	bic.8b	v16, v16, v18
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v3
	addv.8b	b16, v16
	str	b16, [x8]
	cmp	w5, #8
	b.lo	LBB0_223
; %bb.222:                              ; %return.frame.cleanup
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w10, #0xff
	b.ne	LBB0_253
LBB0_223:                               ; %ready.overflow.resume169
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v6, v6, v3
	addv.8b	b6, v6
	fmov	w9, s6
	ldr	d6, [sp, #120]                  ; 8-byte Folded Reload
	cmeq.8b	v6, v7, v6
	mvn.8b	v6, v6
	umov.b	w12, v6[0]
	sbfx	w13, w12, #0, #1
	fmov	s6, w13
	sbfx	w13, w12, #1, #1
	mov.b	v6[1], w13
	sbfx	w13, w12, #2, #1
	mov.b	v6[2], w13
	sbfx	w13, w12, #3, #1
	mov.b	v6[3], w13
	sbfx	w13, w12, #4, #1
	mov.b	v6[4], w13
	sbfx	w13, w12, #5, #1
	mov.b	v6[5], w13
	sbfx	w13, w12, #6, #1
	mov.b	v6[6], w13
	sbfx	w12, w12, #7, #1
	mov.b	v6[7], w12
	and	w12, w21, #0xfffffffe
	tst	w9, #0xff
	csel	w9, w12, w21, eq
	tst	w10, #0xff
	csel	x10, x24, xzr, ne
	ldrb	w12, [x30, x10]
	and	w13, w12, #0x1
	fmov	s7, w13
	ubfx	w13, w12, #1, #1
	mov.b	v7[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v7[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v7[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v7[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v7[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v7[6], w13
	lsr	w12, w12, #7
	mov.b	v7[7], w12
	bif.8b	v2, v7, v6
	fmov	w12, s15
Lloh36:
	adrp	x2, l_convergence.targets@PAGE
Lloh37:
	add	x2, x2, l_convergence.targets@PAGEOFF
	add	x12, x2, w12, sxtw #2
	fmov	w13, s5
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x30, x10]
	lsl	x10, x10, #2
	add	x14, x0, x10
	csel	x12, x12, x14, ne
	ldr	w12, [x12]
	str	w12, [x14]
	ldr	w12, [x15, x10]
	csel	w12, w13, w12, ne
	str	w12, [x15, x10]
	csel	w10, w6, w5, ne
	and	w1, w9, #0x2
	ldrb	w12, [x8, #9]
	and	w13, w12, #0x1
	fmov	s2, w13
	ubfx	w13, w12, #1, #1
	mov.b	v2[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v2[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v2[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v2[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v2[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v2[6], w13
	lsr	w12, w12, #7
	mov.b	v2[7], w12
	ldrb	w12, [x8, #1]
	and	w13, w12, #0x1
	fmov	s16, w13
	ubfx	w13, w12, #1, #1
	mov.b	v16[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v16[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v16[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v16[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v16[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v16[6], w13
	lsr	w12, w12, #7
	mov.b	v16[7], w12
	and.8b	v17, v1, v2
	eor.8b	v2, v16, v17
	shl.8b	v2, v2, #7
	cmlt.8b	v6, v2, #0
	umaxv.8b	b2, v6
	fmov	w12, s2
	eor	w12, w12, #0x1
	ands	w12, w12, w1, lsr #1
	dup.8b	v2, w12
	and.8b	v2, v2, v16
	shl.8b	v7, v2, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v3
	addv.8b	b7, v7
	fmov	w1, s7
	csetm	w12, ne
	dup.8b	v18, w12
	bic.8b	v17, v17, v18
	shl.8b	v17, v17, #7
	cmlt.8b	v17, v17, #0
	and.8b	v17, v17, v3
	addv.8b	b17, v17
	stur	b17, [x8, #9]
	bic.8b	v16, v16, v18
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v3
	addv.8b	b16, v16
	stur	b16, [x8, #1]
	cmp	w10, #8
	and	w12, w1, #0xff
	ccmp	w12, #0, #4, hs
	b.ne	LBB0_253
; %bb.224:                              ; %ready.overflow.resume175
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v6, v6, v3
	ldr	d16, [sp, #112]                 ; 8-byte Folded Reload
	cmeq.8b	v7, v7, v16
	mvn.8b	v7, v7
	umov.b	w12, v7[0]
	addv.8b	b7, v6
	sbfx	w13, w12, #0, #1
	fmov	s6, w13
	sbfx	w13, w12, #1, #1
	mov.b	v6[1], w13
	sbfx	w13, w12, #2, #1
	mov.b	v6[2], w13
	sbfx	w13, w12, #3, #1
	mov.b	v6[3], w13
	sbfx	w13, w12, #4, #1
	mov.b	v6[4], w13
	sbfx	w13, w12, #5, #1
	mov.b	v6[5], w13
	sbfx	w13, w12, #6, #1
	mov.b	v6[6], w13
	sbfx	w12, w12, #7, #1
	mov.b	v6[7], w12
	fmov	w12, s7
	and	w13, w9, #0xfffffffd
	tst	w12, #0xff
	csel	w9, w13, w9, eq
	sxtw	x12, w10
	tst	w1, #0xff
	csel	x12, x12, xzr, ne
	ldrb	w13, [x30, x12]
	and	w14, w13, #0x1
	fmov	s7, w14
	ubfx	w14, w13, #1, #1
	mov.b	v7[1], w14
	ubfx	w14, w13, #2, #1
	mov.b	v7[2], w14
	ubfx	w14, w13, #3, #1
	mov.b	v7[3], w14
	ubfx	w14, w13, #4, #1
	mov.b	v7[4], w14
	ubfx	w14, w13, #5, #1
	mov.b	v7[5], w14
	ubfx	w14, w13, #6, #1
	mov.b	v7[6], w14
	lsr	w13, w13, #7
	mov.b	v7[7], w13
	bif.8b	v2, v7, v6
	mov.s	w13, v15[1]
	add	x13, x2, w13, sxtw #2
	mov.s	w14, v5[1]
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x30, x12]
	lsl	x12, x12, #2
	add	x17, x0, x12
	csel	x13, x13, x17, ne
	ldr	w13, [x13]
	str	w13, [x17]
	ldr	w13, [x15, x12]
	csel	w13, w14, w13, ne
	str	w13, [x15, x12]
	cinc	w10, w10, ne
	and	w1, w9, #0x4
	ldrb	w12, [x8, #10]
	and	w13, w12, #0x1
	fmov	s2, w13
	ubfx	w13, w12, #1, #1
	mov.b	v2[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v2[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v2[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v2[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v2[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v2[6], w13
	lsr	w12, w12, #7
	mov.b	v2[7], w12
	ldrb	w12, [x8, #2]
	and	w13, w12, #0x1
	fmov	s16, w13
	ubfx	w13, w12, #1, #1
	mov.b	v16[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v16[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v16[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v16[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v16[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v16[6], w13
	lsr	w12, w12, #7
	mov.b	v16[7], w12
	and.8b	v17, v1, v2
	eor.8b	v2, v16, v17
	shl.8b	v2, v2, #7
	cmlt.8b	v6, v2, #0
	umaxv.8b	b2, v6
	fmov	w12, s2
	eor	w12, w12, #0x1
	ands	w12, w12, w1, lsr #2
	dup.8b	v2, w12
	and.8b	v2, v2, v16
	shl.8b	v7, v2, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v3
	addv.8b	b7, v7
	fmov	w1, s7
	csetm	w12, ne
	dup.8b	v18, w12
	bic.8b	v17, v17, v18
	shl.8b	v17, v17, #7
	cmlt.8b	v17, v17, #0
	and.8b	v17, v17, v3
	addv.8b	b17, v17
	stur	b17, [x8, #10]
	bic.8b	v16, v16, v18
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v3
	addv.8b	b16, v16
	stur	b16, [x8, #2]
	cmp	w10, #8
	and	w12, w1, #0xff
	ccmp	w12, #0, #4, hs
	b.ne	LBB0_253
; %bb.225:                              ; %ready.overflow.resume181
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v6, v6, v3
	ldr	d16, [sp, #104]                 ; 8-byte Folded Reload
	cmeq.8b	v7, v7, v16
	mvn.8b	v7, v7
	umov.b	w12, v7[0]
	addv.8b	b7, v6
	sbfx	w13, w12, #0, #1
	fmov	s6, w13
	sbfx	w13, w12, #1, #1
	mov.b	v6[1], w13
	sbfx	w13, w12, #2, #1
	mov.b	v6[2], w13
	sbfx	w13, w12, #3, #1
	mov.b	v6[3], w13
	sbfx	w13, w12, #4, #1
	mov.b	v6[4], w13
	sbfx	w13, w12, #5, #1
	mov.b	v6[5], w13
	sbfx	w13, w12, #6, #1
	mov.b	v6[6], w13
	sbfx	w12, w12, #7, #1
	mov.b	v6[7], w12
	fmov	w12, s7
	and	w13, w9, #0xfffffffb
	tst	w12, #0xff
	csel	w9, w13, w9, eq
	sxtw	x12, w10
	tst	w1, #0xff
	csel	x12, x12, xzr, ne
	ldrb	w13, [x30, x12]
	and	w14, w13, #0x1
	fmov	s7, w14
	ubfx	w14, w13, #1, #1
	mov.b	v7[1], w14
	ubfx	w14, w13, #2, #1
	mov.b	v7[2], w14
	ubfx	w14, w13, #3, #1
	mov.b	v7[3], w14
	ubfx	w14, w13, #4, #1
	mov.b	v7[4], w14
	ubfx	w14, w13, #5, #1
	mov.b	v7[5], w14
	ubfx	w14, w13, #6, #1
	mov.b	v7[6], w14
	lsr	w13, w13, #7
	mov.b	v7[7], w13
	bif.8b	v2, v7, v6
	mov.s	w13, v15[2]
	add	x13, x2, w13, sxtw #2
	mov.s	w14, v5[2]
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x30, x12]
	lsl	x12, x12, #2
	add	x17, x0, x12
	csel	x13, x13, x17, ne
	ldr	w13, [x13]
	str	w13, [x17]
	ldr	w13, [x15, x12]
	csel	w13, w14, w13, ne
	str	w13, [x15, x12]
	cinc	w10, w10, ne
	and	w1, w9, #0x8
	ldrb	w12, [x8, #11]
	and	w13, w12, #0x1
	fmov	s2, w13
	ubfx	w13, w12, #1, #1
	mov.b	v2[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v2[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v2[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v2[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v2[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v2[6], w13
	lsr	w12, w12, #7
	mov.b	v2[7], w12
	ldrb	w12, [x8, #3]
	and	w13, w12, #0x1
	fmov	s16, w13
	ubfx	w13, w12, #1, #1
	mov.b	v16[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v16[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v16[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v16[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v16[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v16[6], w13
	lsr	w12, w12, #7
	mov.b	v16[7], w12
	and.8b	v17, v1, v2
	eor.8b	v2, v16, v17
	shl.8b	v2, v2, #7
	cmlt.8b	v6, v2, #0
	umaxv.8b	b2, v6
	fmov	w12, s2
	eor	w12, w12, #0x1
	ands	w12, w12, w1, lsr #3
	dup.8b	v2, w12
	and.8b	v2, v2, v16
	shl.8b	v7, v2, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v3
	addv.8b	b7, v7
	fmov	w1, s7
	csetm	w12, ne
	dup.8b	v18, w12
	bic.8b	v17, v17, v18
	shl.8b	v17, v17, #7
	cmlt.8b	v17, v17, #0
	and.8b	v17, v17, v3
	addv.8b	b17, v17
	stur	b17, [x8, #11]
	bic.8b	v16, v16, v18
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v3
	addv.8b	b16, v16
	stur	b16, [x8, #3]
	cmp	w10, #8
	and	w12, w1, #0xff
	ccmp	w12, #0, #4, hs
	b.ne	LBB0_253
; %bb.226:                              ; %ready.overflow.resume187
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v6, v6, v3
	ldr	d16, [sp, #96]                  ; 8-byte Folded Reload
	cmeq.8b	v7, v7, v16
	mvn.8b	v7, v7
	umov.b	w12, v7[0]
	addv.8b	b7, v6
	sbfx	w13, w12, #0, #1
	fmov	s6, w13
	sbfx	w13, w12, #1, #1
	mov.b	v6[1], w13
	sbfx	w13, w12, #2, #1
	mov.b	v6[2], w13
	sbfx	w13, w12, #3, #1
	mov.b	v6[3], w13
	sbfx	w13, w12, #4, #1
	mov.b	v6[4], w13
	sbfx	w13, w12, #5, #1
	mov.b	v6[5], w13
	sbfx	w13, w12, #6, #1
	mov.b	v6[6], w13
	sbfx	w12, w12, #7, #1
	mov.b	v6[7], w12
	fmov	w12, s7
	and	w13, w9, #0xfffffff7
	tst	w12, #0xff
	csel	w9, w13, w9, eq
	sxtw	x12, w10
	tst	w1, #0xff
	csel	x12, x12, xzr, ne
	ldrb	w13, [x30, x12]
	and	w14, w13, #0x1
	fmov	s7, w14
	ubfx	w14, w13, #1, #1
	mov.b	v7[1], w14
	ubfx	w14, w13, #2, #1
	mov.b	v7[2], w14
	ubfx	w14, w13, #3, #1
	mov.b	v7[3], w14
	ubfx	w14, w13, #4, #1
	mov.b	v7[4], w14
	ubfx	w14, w13, #5, #1
	mov.b	v7[5], w14
	ubfx	w14, w13, #6, #1
	mov.b	v7[6], w14
	lsr	w13, w13, #7
	mov.b	v7[7], w13
	bif.8b	v2, v7, v6
	mov.s	w13, v15[3]
	add	x13, x2, w13, sxtw #2
	mov.s	w14, v5[3]
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x30, x12]
	lsl	x12, x12, #2
	add	x17, x0, x12
	csel	x13, x13, x17, ne
	ldr	w13, [x13]
	str	w13, [x17]
	ldr	w13, [x15, x12]
	csel	w13, w14, w13, ne
	str	w13, [x15, x12]
	cinc	w5, w10, ne
	and	w10, w9, #0x10
	ldrb	w12, [x8, #12]
	and	w13, w12, #0x1
	fmov	s2, w13
	ubfx	w13, w12, #1, #1
	mov.b	v2[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v2[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v2[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v2[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v2[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v2[6], w13
	lsr	w12, w12, #7
	mov.b	v2[7], w12
	ldrb	w12, [x8, #4]
	and	w13, w12, #0x1
	fmov	s16, w13
	ubfx	w13, w12, #1, #1
	mov.b	v16[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v16[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v16[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v16[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v16[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v16[6], w13
	lsr	w12, w12, #7
	mov.b	v16[7], w12
	and.8b	v17, v1, v2
	eor.8b	v2, v16, v17
	shl.8b	v2, v2, #7
	cmlt.8b	v6, v2, #0
	umaxv.8b	b2, v6
	fmov	w12, s2
	eor	w12, w12, #0x1
	ands	w10, w12, w10, lsr #4
	dup.8b	v2, w10
	and.8b	v2, v2, v16
	shl.8b	v7, v2, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v3
	addv.8b	b7, v7
	fmov	w1, s7
	csetm	w10, ne
	dup.8b	v18, w10
	bic.8b	v17, v17, v18
	shl.8b	v17, v17, #7
	cmlt.8b	v17, v17, #0
	and.8b	v17, v17, v3
	addv.8b	b17, v17
	stur	b17, [x8, #12]
	bic.8b	v16, v16, v18
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v3
	addv.8b	b16, v16
	stur	b16, [x8, #4]
	cmp	w5, #8
	and	w10, w1, #0xff
	ccmp	w10, #0, #4, hs
	b.ne	LBB0_253
; %bb.227:                              ; %ready.overflow.resume193
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v6, v6, v3
	addv.8b	b6, v6
	fmov	w10, s6
	ldr	d6, [sp, #88]                   ; 8-byte Folded Reload
	cmeq.8b	v6, v7, v6
	mvn.8b	v6, v6
	umov.b	w12, v6[0]
	sbfx	w13, w12, #0, #1
	fmov	s6, w13
	sbfx	w13, w12, #1, #1
	mov.b	v6[1], w13
	sbfx	w13, w12, #2, #1
	mov.b	v6[2], w13
	sbfx	w13, w12, #3, #1
	mov.b	v6[3], w13
	sbfx	w13, w12, #4, #1
	mov.b	v6[4], w13
	sbfx	w13, w12, #5, #1
	mov.b	v6[5], w13
	sbfx	w13, w12, #6, #1
	mov.b	v6[6], w13
	sbfx	w12, w12, #7, #1
	mov.b	v6[7], w12
	and	w12, w9, #0xffffffef
	tst	w10, #0xff
	csel	w10, w12, w9, eq
	sxtw	x9, w5
	tst	w1, #0xff
	csel	x9, x9, xzr, ne
	ldrb	w12, [x30, x9]
	and	w13, w12, #0x1
	fmov	s7, w13
	ubfx	w13, w12, #1, #1
	mov.b	v7[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v7[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v7[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v7[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v7[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v7[6], w13
	lsr	w12, w12, #7
	mov.b	v7[7], w12
	bif.8b	v2, v7, v6
	fmov	w12, s14
	add	x12, x2, w12, sxtw #2
	fmov	w13, s4
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x30, x9]
	lsl	x9, x9, #2
	add	x14, x0, x9
	csel	x12, x12, x14, ne
	ldr	w12, [x12]
	str	w12, [x14]
	ldr	w12, [x15, x9]
	csel	w12, w13, w12, ne
	str	w12, [x15, x9]
	cinc	w9, w5, ne
	and	w1, w10, #0x20
	ldrb	w12, [x8, #13]
	and	w13, w12, #0x1
	fmov	s2, w13
	ubfx	w13, w12, #1, #1
	mov.b	v2[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v2[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v2[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v2[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v2[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v2[6], w13
	lsr	w12, w12, #7
	mov.b	v2[7], w12
	ldrb	w12, [x8, #5]
	and	w13, w12, #0x1
	fmov	s16, w13
	ubfx	w13, w12, #1, #1
	mov.b	v16[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v16[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v16[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v16[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v16[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v16[6], w13
	lsr	w12, w12, #7
	mov.b	v16[7], w12
	and.8b	v17, v1, v2
	eor.8b	v2, v16, v17
	shl.8b	v2, v2, #7
	cmlt.8b	v6, v2, #0
	umaxv.8b	b2, v6
	fmov	w12, s2
	eor	w12, w12, #0x1
	ands	w12, w12, w1, lsr #5
	dup.8b	v2, w12
	and.8b	v2, v2, v16
	shl.8b	v7, v2, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v3
	addv.8b	b7, v7
	fmov	w1, s7
	csetm	w12, ne
	dup.8b	v18, w12
	bic.8b	v17, v17, v18
	shl.8b	v17, v17, #7
	cmlt.8b	v17, v17, #0
	and.8b	v17, v17, v3
	addv.8b	b17, v17
	stur	b17, [x8, #13]
	bic.8b	v16, v16, v18
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v3
	addv.8b	b16, v16
	stur	b16, [x8, #5]
	cmp	w9, #8
	and	w12, w1, #0xff
	ccmp	w12, #0, #4, hs
	b.ne	LBB0_253
; %bb.228:                              ; %ready.overflow.resume199
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v6, v6, v3
	addv.8b	b6, v6
	fmov	w12, s6
	ldr	d6, [sp, #80]                   ; 8-byte Folded Reload
	cmeq.8b	v6, v7, v6
	mvn.8b	v6, v6
	umov.b	w13, v6[0]
	sbfx	w14, w13, #0, #1
	fmov	s6, w14
	sbfx	w14, w13, #1, #1
	mov.b	v6[1], w14
	sbfx	w14, w13, #2, #1
	mov.b	v6[2], w14
	sbfx	w14, w13, #3, #1
	mov.b	v6[3], w14
	sbfx	w14, w13, #4, #1
	mov.b	v6[4], w14
	sbfx	w14, w13, #5, #1
	mov.b	v6[5], w14
	sbfx	w14, w13, #6, #1
	mov.b	v6[6], w14
	sbfx	w13, w13, #7, #1
	mov.b	v6[7], w13
	and	w13, w10, #0xffffffdf
	tst	w12, #0xff
	csel	w10, w13, w10, eq
	sxtw	x12, w9
	tst	w1, #0xff
	csel	x12, x12, xzr, ne
	ldrb	w13, [x30, x12]
	and	w14, w13, #0x1
	fmov	s7, w14
	ubfx	w14, w13, #1, #1
	mov.b	v7[1], w14
	ubfx	w14, w13, #2, #1
	mov.b	v7[2], w14
	ubfx	w14, w13, #3, #1
	mov.b	v7[3], w14
	ubfx	w14, w13, #4, #1
	mov.b	v7[4], w14
	ubfx	w14, w13, #5, #1
	mov.b	v7[5], w14
	ubfx	w14, w13, #6, #1
	mov.b	v7[6], w14
	lsr	w13, w13, #7
	mov.b	v7[7], w13
	mov.s	w13, v14[1]
	bif.8b	v2, v7, v6
	add	x13, x2, w13, sxtw #2
	mov.s	w14, v4[1]
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x30, x12]
	lsl	x12, x12, #2
	add	x17, x0, x12
	csel	x13, x13, x17, ne
	ldr	w13, [x13]
	str	w13, [x17]
	ldr	w13, [x15, x12]
	csel	w13, w14, w13, ne
	str	w13, [x15, x12]
	cinc	w9, w9, ne
	ldrb	w12, [x8, #14]
	and	w13, w12, #0x1
	fmov	s2, w13
	ubfx	w13, w12, #1, #1
	mov.b	v2[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v2[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v2[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v2[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v2[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v2[6], w13
	lsr	w12, w12, #7
	mov.b	v2[7], w12
	ldrb	w12, [x8, #6]
	and	w13, w12, #0x1
	fmov	s16, w13
	ubfx	w13, w12, #1, #1
	mov.b	v16[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v16[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v16[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v16[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v16[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v16[6], w13
	and	w13, w10, #0x40
	lsr	w12, w12, #7
	mov.b	v16[7], w12
	and.8b	v17, v1, v2
	eor.8b	v2, v16, v17
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	umaxv.8b	b6, v2
	fmov	w12, s6
	eor	w12, w12, #0x1
	ands	w12, w12, w13, lsr #6
	dup.8b	v6, w12
	and.8b	v6, v6, v16
	shl.8b	v7, v6, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v3
	addv.8b	b7, v7
	fmov	w1, s7
	csetm	w12, ne
	dup.8b	v18, w12
	bic.8b	v17, v17, v18
	shl.8b	v17, v17, #7
	cmlt.8b	v17, v17, #0
	and.8b	v17, v17, v3
	addv.8b	b17, v17
	stur	b17, [x8, #14]
	bic.8b	v16, v16, v18
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v3
	addv.8b	b16, v16
	stur	b16, [x8, #6]
	cmp	w9, #8
	b.lo	LBB0_230
; %bb.229:                              ; %ready.overflow.resume199
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w1, #0xff
	b.ne	LBB0_253
LBB0_230:                               ; %ready.overflow.resume205
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v2, v2, v3
	ldr	d16, [sp, #72]                  ; 8-byte Folded Reload
	cmeq.8b	v7, v7, v16
	mvn.8b	v7, v7
	umov.b	w12, v7[0]
	addv.8b	b7, v2
	sbfx	w13, w12, #0, #1
	fmov	s2, w13
	sbfx	w13, w12, #1, #1
	mov.b	v2[1], w13
	sbfx	w13, w12, #2, #1
	mov.b	v2[2], w13
	sbfx	w13, w12, #3, #1
	mov.b	v2[3], w13
	sbfx	w13, w12, #4, #1
	mov.b	v2[4], w13
	sbfx	w13, w12, #5, #1
	mov.b	v2[5], w13
	sbfx	w13, w12, #6, #1
	mov.b	v2[6], w13
	sbfx	w12, w12, #7, #1
	mov.b	v2[7], w12
	fmov	w12, s7
	and	w13, w10, #0xffffffbf
	tst	w12, #0xff
	csel	w10, w13, w10, eq
	sxtw	x12, w9
	tst	w1, #0xff
	csel	x12, x12, xzr, ne
	ldrb	w13, [x30, x12]
	and	w14, w13, #0x1
	fmov	s7, w14
	ubfx	w14, w13, #1, #1
	mov.b	v7[1], w14
	ubfx	w14, w13, #2, #1
	mov.b	v7[2], w14
	ubfx	w14, w13, #3, #1
	mov.b	v7[3], w14
	ubfx	w14, w13, #4, #1
	mov.b	v7[4], w14
	ubfx	w14, w13, #5, #1
	mov.b	v7[5], w14
	ubfx	w14, w13, #6, #1
	mov.b	v7[6], w14
	lsr	w13, w13, #7
	mov.b	v7[7], w13
	bsl.8b	v2, v6, v7
	mov.s	w13, v14[2]
	add	x13, x2, w13, sxtw #2
	mov.s	w14, v4[2]
	sxtb	w10, w10
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x30, x12]
	lsl	x12, x12, #2
	ldr	w17, [x15, x12]
	csel	w14, w14, w17, ne
	add	x17, x0, x12
	csel	x13, x13, x17, ne
	ldr	w13, [x13]
	str	w14, [x15, x12]
	str	w13, [x17]
	cinc	w9, w9, ne
	cmp	w10, #0
	ldrb	w12, [x8, #15]
	and	w13, w12, #0x1
	fmov	s2, w13
	ubfx	w13, w12, #1, #1
	mov.b	v2[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v2[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v2[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v2[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v2[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v2[6], w13
	lsr	w12, w12, #7
	mov.b	v2[7], w12
	ldrb	w12, [x8, #7]
	and	w13, w12, #0x1
	fmov	s16, w13
	ubfx	w13, w12, #1, #1
	mov.b	v16[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v16[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v16[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v16[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v16[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v16[6], w13
	cset	w13, lt
	lsr	w12, w12, #7
	mov.b	v16[7], w12
	and.8b	v17, v1, v2
	eor.8b	v2, v16, v17
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	umaxv.8b	b6, v2
	fmov	w12, s6
	eor	w12, w12, #0x1
	ands	w12, w13, w12
	dup.8b	v6, w12
	and.8b	v6, v6, v16
	shl.8b	v7, v6, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v3
	addv.8b	b7, v7
	fmov	w1, s7
	csetm	w12, ne
	dup.8b	v18, w12
	bic.8b	v17, v17, v18
	shl.8b	v17, v17, #7
	cmlt.8b	v17, v17, #0
	and.8b	v17, v17, v3
	addv.8b	b17, v17
	stur	b17, [x8, #15]
	bic.8b	v16, v16, v18
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v3
	addv.8b	b16, v16
	stur	b16, [x8, #7]
	cmp	w9, #8
	b.lo	LBB0_232
; %bb.231:                              ; %ready.overflow.resume205
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w1, #0xff
	b.ne	LBB0_253
LBB0_232:                               ; %ready.overflow.resume211
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v2, v2, v3
	addv.8b	b16, v2
	ldr	d2, [sp, #64]                   ; 8-byte Folded Reload
	cmeq.8b	v2, v7, v2
	mvn.8b	v2, v2
	umov.b	w12, v2[0]
	sbfx	w13, w12, #0, #1
	fmov	s2, w13
	sbfx	w13, w12, #1, #1
	mov.b	v2[1], w13
	sbfx	w13, w12, #2, #1
	mov.b	v2[2], w13
	sbfx	w13, w12, #3, #1
	mov.b	v2[3], w13
	sbfx	w13, w12, #4, #1
	mov.b	v2[4], w13
	sbfx	w13, w12, #5, #1
	mov.b	v2[5], w13
	sbfx	w13, w12, #6, #1
	mov.b	v2[6], w13
	fmov	w13, s16
	sbfx	w12, w12, #7, #1
	mov.b	v2[7], w12
	and	w12, w10, #0x7f
	tst	w13, #0xff
	csel	w21, w12, w10, eq
	sxtw	x10, w9
	tst	w1, #0xff
	csel	x10, x10, xzr, ne
	ldrb	w12, [x30, x10]
	and	w13, w12, #0x1
	fmov	s7, w13
	ubfx	w13, w12, #1, #1
	mov.b	v7[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v7[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v7[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v7[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v7[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v7[6], w13
	lsr	w12, w12, #7
	mov.b	v7[7], w12
	bsl.8b	v2, v6, v7
	mov.s	w12, v14[3]
	mov.s	w13, v4[3]
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x30, x10]
Lloh38:
	adrp	x14, l_convergence.targets@PAGE
Lloh39:
	add	x14, x14, l_convergence.targets@PAGEOFF
	add	x12, x14, w12, sxtw #2
	lsl	x10, x10, #2
	add	x14, x0, x10
	csel	x12, x12, x14, ne
	ldr	w12, [x12]
	str	w12, [x14]
	ldr	w12, [x15, x10]
	csel	w12, w13, w12, ne
	str	w12, [x15, x10]
	cinc	w5, w9, ne
	b	LBB0_4
LBB0_233:                               ; %varying.coherent.false126
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #0, LBB0_4
	b	LBB0_243
LBB0_234:                               ;   in Loop: Header=BB0_5 Depth=1
	mov	w21, #0                         ; =0x0
	b	LBB0_4
LBB0_235:                               ; %cond.store322
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d20
	str	s18, [x10]
	tbz	w9, #1, LBB0_201
LBB0_236:                               ; %cond.store326
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v20[1]
	st1.s	{ v18 }[1], [x10]
	tbz	w9, #2, LBB0_202
LBB0_237:                               ; %cond.store330
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d19
	st1.s	{ v18 }[2], [x10]
	tbz	w9, #3, LBB0_203
LBB0_238:                               ; %cond.store334
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v19[1]
	st1.s	{ v18 }[3], [x10]
	tbz	w9, #4, LBB0_204
LBB0_239:                               ; %cond.store338
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d17
	str	s2, [x10]
	tbz	w9, #5, LBB0_205
LBB0_240:                               ; %cond.store342
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v17[1]
	st1.s	{ v2 }[1], [x10]
	tbz	w9, #6, LBB0_206
LBB0_241:                               ; %cond.store346
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d16
	st1.s	{ v2 }[2], [x10]
	tbz	w9, #7, LBB0_243
LBB0_242:                               ; %cond.store350
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x9, v16[1]
	st1.s	{ v2 }[3], [x9]
LBB0_243:                               ; %schedule.12
                                        ;   in Loop: Header=BB0_5 Depth=1
	cbz	w25, LBB0_248
; %bb.244:                              ; %convergence.cascade129.preheader
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	w9, #0                          ; =0x0
LBB0_245:                               ; %convergence.cascade129
                                        ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v2, v6, #7
	cmlt.8b	v2, v2, #0
	and.8b	v7, v2, v3
	addv.8b	b7, v7
	fmov	w10, s7
	umaxv.8b	b2, v2
	fmov	w12, s2
	sub	w13, w25, #1
	tst	w10, #0xff
	csel	w23, w13, wzr, ne
	lsl	w1, w11, w23
	and	w10, w1, w21
	tst	w10, #0xff
	cset	w13, ne
	str	q15, [sp, #1248]
	str	q14, [sp, #1264]
	ubfiz	x10, x23, #2, #3
	ldr	w14, [x3, x10]
	cmp	w14, #4
	cset	w4, eq
	and	w2, w13, w12
	ldrb	w12, [x20, w23, sxtw]
	and	w13, w12, #0x1
	fmov	s2, w13
	ubfx	w13, w12, #1, #1
	mov.b	v2[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v2[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v2[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v2[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v2[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v2[6], w13
	lsr	w12, w12, #7
	mov.b	v2[7], w12
	ldrb	w12, [x8, w23, sxtw]
	and	w13, w12, #0x1
	fmov	s7, w13
	ubfx	w13, w12, #1, #1
	mov.b	v7[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v7[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v7[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v7[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v7[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v7[6], w13
	lsr	w12, w12, #7
	mov.b	v7[7], w12
	orr.8b	v16, v6, v7
	and.8b	v17, v1, v2
	eor.8b	v17, v17, v16
	shl.8b	v17, v17, #7
	cmlt.8b	v17, v17, #0
	umaxv.8b	b17, v17
	fmov	w12, s17
	ands	w13, w2, w4
	csetm	w14, ne
	bics	w12, w13, w12
	csetm	w17, ne
	dup.8b	v17, w17
	dup.8b	v18, w14
	bic.8b	v19, v16, v17
	bit.8b	v7, v19, v18
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v3
	addv.8b	b7, v7
	str	b7, [x8, w23, sxtw]
	bic.8b	v2, v2, v17
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x20, w23, sxtw]
	csinv	w14, w19, w1, eq
	dup.8b	v2, w13
	and	w21, w14, w21
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	dup.8b	v7, w12
	and.8b	v7, v7, v16
	str	q5, [sp, #1216]
	str	q4, [sp, #1232]
	ldr	w10, [x16, x10]
	csel	w25, w10, w25, ne
	bit.8b	v6, v7, v2
	shl.8b	v2, v6, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w10, s2
	cmp	w13, #1
	b.ne	LBB0_249
; %bb.246:                              ; %convergence.cascade129
                                        ;   in Loop: Header=BB0_245 Depth=2
	cmp	w25, #0
	ccmp	w9, #6, #2, ne
	b.hi	LBB0_249
; %bb.247:                              ; %convergence.cascade129
                                        ;   in Loop: Header=BB0_245 Depth=2
	add	w9, w9, #1
	tst	w10, #0xff
	b.ne	LBB0_245
	b	LBB0_249
LBB0_248:                               ; %schedule.12.convergence.cascade.exit130_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v2, v6, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w10, s2
LBB0_249:                               ; %convergence.cascade.exit130
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w10, #0xff
	b.eq	LBB0_4
; %bb.250:                              ; %convergence.target.12.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v2, v6, v11
	ushll.8h	v2, v2, #0
	ushll.4s	v7, v2, #0
	ushll2.4s	v2, v2, #0
	ldp	q18, q16, [sp, #320]            ; 32-byte Folded Reload
	uaddw2.2d	v17, v18, v2
	uaddw.2d	v16, v16, v2
	stp	q17, q16, [sp, #320]            ; 32-byte Folded Spill
	uaddw2.2d	v10, v10, v7
	uaddw.2d	v29, v29, v7
	b	LBB0_170
LBB0_251:                               ; %scheduler.done
	shl.8b	v0, v1, #7
	cmlt.8b	v0, v0, #0
	umaxv.8b	b0, v0
	fmov	w8, s0
	tbnz	w8, #0, LBB0_253
; %bb.252:                              ; %scheduler.exit
	sub	sp, x29, #144
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
LBB0_253:                               ; %scheduler.stalled
	brk	#0x1
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdd	Lloh18, Lloh19
	.loh AdrpAdd	Lloh20, Lloh21
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdd	Lloh30, Lloh31
	.loh AdrpAdd	Lloh32, Lloh33
	.loh AdrpAdd	Lloh34, Lloh35
	.loh AdrpAdd	Lloh36, Lloh37
	.loh AdrpAdd	Lloh38, Lloh39
	.section	__TEXT,__const
	.p2align	1, 0x0
LJTI0_0:
	.short	(LBB0_7-LBB0_7)>>2
	.short	(LBB0_45-LBB0_7)>>2
	.short	(LBB0_10-LBB0_7)>>2
	.short	(LBB0_20-LBB0_7)>>2
	.short	(LBB0_74-LBB0_7)>>2
	.short	(LBB0_80-LBB0_7)>>2
	.short	(LBB0_118-LBB0_7)>>2
	.short	(LBB0_8-LBB0_7)>>2
	.short	(LBB0_162-LBB0_7)>>2
	.short	(LBB0_170-LBB0_7)>>2
	.short	(LBB0_9-LBB0_7)>>2
	.short	(LBB0_11-LBB0_7)>>2
	.short	(LBB0_243-LBB0_7)>>2
	.short	(LBB0_213-LBB0_7)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_tile_transpose.packet_batch    ; -- Begin function tile_transpose.packet_batch
	.p2align	2
_tile_transpose.packet_batch:           ; @tile_transpose.packet_batch
; %bb.0:                                ; %packet.batch.prologue
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	mov	x21, x3
	mov	x19, x2
	mov	x20, x0
	ldr	w23, [x2, #36]
	ldr	w8, [x2]
	ldr	w9, [x2, #12]
	lsl	x8, x8, #6
	cmp	x8, x9
	csel	x10, x8, xzr, ls
	add	x10, x10, x23
	subs	x11, x9, x10
	mov	w12, #64                        ; =0x40
	sub	x13, x12, x23
	cmp	x11, x13
	csel	x11, x11, x13, lo
	cmp	x9, x10
	ccmp	x23, x12, #2, hi
	ccmp	x8, x9, #2, lo
	csel	x8, x11, xzr, ls
	cmp	w3, #8
	b.ne	LBB1_3
; %bb.1:                                ; %packet.batch.prologue
	cmp	x8, #64
	b.lo	LBB1_3
; %bb.2:                                ; %packet.batch.full
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_transpose
	add	w8, w23, #8
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_transpose
	add	w8, w23, #16
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_transpose
	add	w8, w23, #24
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_transpose
	add	w8, w23, #32
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_transpose
	add	w8, w23, #40
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_transpose
	add	w8, w23, #48
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_transpose
	add	w8, w23, #56
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	b	_tile_transpose
LBB1_3:                                 ; %packet.batch.partial
	ubfiz	x9, x21, #3, #32
	cmp	x8, x9
	csel	x8, x8, x9, lo
	lsr	x24, x8, #3
	and	w22, w8, #0x7
	cmp	x8, #8
	b.lo	LBB1_6
; %bb.4:                                ; %packet.batch.partial.full.loop.preheader
	mov	x25, x24
	mov	x26, x23
LBB1_5:                                 ; %packet.batch.partial.full.loop
                                        ; =>This Inner Loop Header: Depth=1
	str	w26, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_transpose
	add	w26, w26, #8
	subs	w25, w25, #1
	b.ne	LBB1_5
LBB1_6:                                 ; %packet.batch.tail.check
	cbz	w22, LBB1_8
; %bb.7:                                ; %packet.batch.tail.call
	add	w8, w23, w24, lsl #3
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	x2, x22
	bl	_tile_transpose
LBB1_8:                                 ; %packet.batch.partial.finish
	lsl	w8, w21, #3
	sub	w8, w8, #8
	cmp	w21, #0
	csel	w8, wzr, w8, eq
	add	w8, w23, w8
	str	w8, [x19, #36]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.section	__TEXT,__const
	.p2align	2, 0x0                          ; @convergence.targets
l_convergence.targets:
	.long	5                               ; 0x5
	.long	4                               ; 0x4
	.long	8                               ; 0x8
	.long	13                              ; 0xd
	.long	12                              ; 0xc

.subsections_via_symbols

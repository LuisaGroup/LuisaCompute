	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function tile_inclusive_scan
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_4:
	.quad	120                             ; 0x78
	.quad	124                             ; 0x7c
lCPI0_5:
	.quad	112                             ; 0x70
	.quad	116                             ; 0x74
lCPI0_6:
	.quad	104                             ; 0x68
	.quad	108                             ; 0x6c
lCPI0_7:
	.quad	96                              ; 0x60
	.quad	100                             ; 0x64
lCPI0_8:
	.quad	88                              ; 0x58
	.quad	92                              ; 0x5c
lCPI0_9:
	.quad	80                              ; 0x50
	.quad	84                              ; 0x54
lCPI0_10:
	.quad	72                              ; 0x48
	.quad	76                              ; 0x4c
lCPI0_11:
	.quad	64                              ; 0x40
	.quad	68                              ; 0x44
lCPI0_12:
	.quad	56                              ; 0x38
	.quad	60                              ; 0x3c
lCPI0_13:
	.quad	48                              ; 0x30
	.quad	52                              ; 0x34
lCPI0_14:
	.quad	40                              ; 0x28
	.quad	44                              ; 0x2c
lCPI0_15:
	.quad	32                              ; 0x20
	.quad	36                              ; 0x24
lCPI0_16:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_17:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_18:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_19:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_20:
	.quad	16                              ; 0x10
	.quad	24                              ; 0x18
lCPI0_21:
	.quad	0                               ; 0x0
	.quad	8                               ; 0x8
lCPI0_22:
	.quad	48                              ; 0x30
	.quad	56                              ; 0x38
lCPI0_23:
	.quad	32                              ; 0x20
	.quad	40                              ; 0x28
lCPI0_24:
	.quad	112                             ; 0x70
	.quad	120                             ; 0x78
lCPI0_25:
	.quad	96                              ; 0x60
	.quad	104                             ; 0x68
lCPI0_26:
	.quad	80                              ; 0x50
	.quad	88                              ; 0x58
lCPI0_27:
	.quad	64                              ; 0x40
	.quad	72                              ; 0x48
lCPI0_28:
	.quad	176                             ; 0xb0
	.quad	184                             ; 0xb8
lCPI0_29:
	.quad	160                             ; 0xa0
	.quad	168                             ; 0xa8
lCPI0_30:
	.quad	144                             ; 0x90
	.quad	152                             ; 0x98
lCPI0_31:
	.quad	128                             ; 0x80
	.quad	136                             ; 0x88
lCPI0_32:
	.quad	240                             ; 0xf0
	.quad	248                             ; 0xf8
lCPI0_33:
	.quad	224                             ; 0xe0
	.quad	232                             ; 0xe8
lCPI0_34:
	.quad	208                             ; 0xd0
	.quad	216                             ; 0xd8
lCPI0_35:
	.quad	192                             ; 0xc0
	.quad	200                             ; 0xc8
lCPI0_36:
	.quad	304                             ; 0x130
	.quad	312                             ; 0x138
lCPI0_37:
	.quad	288                             ; 0x120
	.quad	296                             ; 0x128
lCPI0_38:
	.quad	272                             ; 0x110
	.quad	280                             ; 0x118
lCPI0_39:
	.quad	256                             ; 0x100
	.quad	264                             ; 0x108
lCPI0_40:
	.quad	368                             ; 0x170
	.quad	376                             ; 0x178
lCPI0_41:
	.quad	352                             ; 0x160
	.quad	360                             ; 0x168
lCPI0_42:
	.quad	336                             ; 0x150
	.quad	344                             ; 0x158
lCPI0_43:
	.quad	320                             ; 0x140
	.quad	328                             ; 0x148
lCPI0_44:
	.quad	432                             ; 0x1b0
	.quad	440                             ; 0x1b8
lCPI0_45:
	.quad	416                             ; 0x1a0
	.quad	424                             ; 0x1a8
lCPI0_46:
	.quad	400                             ; 0x190
	.quad	408                             ; 0x198
lCPI0_47:
	.quad	384                             ; 0x180
	.quad	392                             ; 0x188
lCPI0_48:
	.quad	496                             ; 0x1f0
	.quad	504                             ; 0x1f8
lCPI0_49:
	.quad	480                             ; 0x1e0
	.quad	488                             ; 0x1e8
lCPI0_50:
	.quad	464                             ; 0x1d0
	.quad	472                             ; 0x1d8
lCPI0_51:
	.quad	448                             ; 0x1c0
	.quad	456                             ; 0x1c8
lCPI0_52:
	.quad	560                             ; 0x230
	.quad	568                             ; 0x238
lCPI0_53:
	.quad	544                             ; 0x220
	.quad	552                             ; 0x228
lCPI0_54:
	.quad	528                             ; 0x210
	.quad	536                             ; 0x218
lCPI0_55:
	.quad	512                             ; 0x200
	.quad	520                             ; 0x208
lCPI0_56:
	.quad	624                             ; 0x270
	.quad	632                             ; 0x278
lCPI0_57:
	.quad	608                             ; 0x260
	.quad	616                             ; 0x268
lCPI0_58:
	.quad	592                             ; 0x250
	.quad	600                             ; 0x258
lCPI0_59:
	.quad	576                             ; 0x240
	.quad	584                             ; 0x248
lCPI0_60:
	.quad	688                             ; 0x2b0
	.quad	696                             ; 0x2b8
lCPI0_61:
	.quad	672                             ; 0x2a0
	.quad	680                             ; 0x2a8
lCPI0_62:
	.quad	656                             ; 0x290
	.quad	664                             ; 0x298
lCPI0_63:
	.quad	640                             ; 0x280
	.quad	648                             ; 0x288
lCPI0_64:
	.quad	752                             ; 0x2f0
	.quad	760                             ; 0x2f8
lCPI0_65:
	.quad	736                             ; 0x2e0
	.quad	744                             ; 0x2e8
lCPI0_66:
	.quad	720                             ; 0x2d0
	.quad	728                             ; 0x2d8
lCPI0_67:
	.quad	704                             ; 0x2c0
	.quad	712                             ; 0x2c8
lCPI0_68:
	.quad	816                             ; 0x330
	.quad	824                             ; 0x338
lCPI0_69:
	.quad	800                             ; 0x320
	.quad	808                             ; 0x328
lCPI0_70:
	.quad	784                             ; 0x310
	.quad	792                             ; 0x318
lCPI0_71:
	.quad	768                             ; 0x300
	.quad	776                             ; 0x308
lCPI0_72:
	.quad	880                             ; 0x370
	.quad	888                             ; 0x378
lCPI0_73:
	.quad	864                             ; 0x360
	.quad	872                             ; 0x368
lCPI0_74:
	.quad	848                             ; 0x350
	.quad	856                             ; 0x358
lCPI0_75:
	.quad	832                             ; 0x340
	.quad	840                             ; 0x348
lCPI0_76:
	.quad	944                             ; 0x3b0
	.quad	952                             ; 0x3b8
lCPI0_77:
	.quad	928                             ; 0x3a0
	.quad	936                             ; 0x3a8
lCPI0_78:
	.quad	912                             ; 0x390
	.quad	920                             ; 0x398
lCPI0_79:
	.quad	896                             ; 0x380
	.quad	904                             ; 0x388
lCPI0_80:
	.quad	1008                            ; 0x3f0
	.quad	1016                            ; 0x3f8
lCPI0_81:
	.quad	992                             ; 0x3e0
	.quad	1000                            ; 0x3e8
lCPI0_82:
	.quad	976                             ; 0x3d0
	.quad	984                             ; 0x3d8
lCPI0_83:
	.quad	960                             ; 0x3c0
	.quad	968                             ; 0x3c8
lCPI0_84:
	.quad	1072                            ; 0x430
	.quad	1080                            ; 0x438
lCPI0_85:
	.quad	1056                            ; 0x420
	.quad	1064                            ; 0x428
lCPI0_86:
	.quad	1040                            ; 0x410
	.quad	1048                            ; 0x418
lCPI0_87:
	.quad	1024                            ; 0x400
	.quad	1032                            ; 0x408
lCPI0_88:
	.quad	1136                            ; 0x470
	.quad	1144                            ; 0x478
lCPI0_89:
	.quad	1120                            ; 0x460
	.quad	1128                            ; 0x468
lCPI0_90:
	.quad	1104                            ; 0x450
	.quad	1112                            ; 0x458
lCPI0_91:
	.quad	1088                            ; 0x440
	.quad	1096                            ; 0x448
lCPI0_92:
	.quad	1200                            ; 0x4b0
	.quad	1208                            ; 0x4b8
lCPI0_93:
	.quad	1184                            ; 0x4a0
	.quad	1192                            ; 0x4a8
lCPI0_94:
	.quad	1168                            ; 0x490
	.quad	1176                            ; 0x498
lCPI0_95:
	.quad	1152                            ; 0x480
	.quad	1160                            ; 0x488
lCPI0_96:
	.quad	1264                            ; 0x4f0
	.quad	1272                            ; 0x4f8
lCPI0_97:
	.quad	1248                            ; 0x4e0
	.quad	1256                            ; 0x4e8
lCPI0_98:
	.quad	1232                            ; 0x4d0
	.quad	1240                            ; 0x4d8
lCPI0_99:
	.quad	1216                            ; 0x4c0
	.quad	1224                            ; 0x4c8
lCPI0_100:
	.quad	1328                            ; 0x530
	.quad	1336                            ; 0x538
lCPI0_101:
	.quad	1312                            ; 0x520
	.quad	1320                            ; 0x528
lCPI0_102:
	.quad	1296                            ; 0x510
	.quad	1304                            ; 0x518
lCPI0_103:
	.quad	1280                            ; 0x500
	.quad	1288                            ; 0x508
lCPI0_104:
	.quad	1392                            ; 0x570
	.quad	1400                            ; 0x578
lCPI0_105:
	.quad	1376                            ; 0x560
	.quad	1384                            ; 0x568
lCPI0_106:
	.quad	1360                            ; 0x550
	.quad	1368                            ; 0x558
lCPI0_107:
	.quad	1344                            ; 0x540
	.quad	1352                            ; 0x548
lCPI0_108:
	.quad	1456                            ; 0x5b0
	.quad	1464                            ; 0x5b8
lCPI0_109:
	.quad	1440                            ; 0x5a0
	.quad	1448                            ; 0x5a8
lCPI0_110:
	.quad	1424                            ; 0x590
	.quad	1432                            ; 0x598
lCPI0_111:
	.quad	1408                            ; 0x580
	.quad	1416                            ; 0x588
lCPI0_112:
	.quad	1520                            ; 0x5f0
	.quad	1528                            ; 0x5f8
lCPI0_113:
	.quad	1504                            ; 0x5e0
	.quad	1512                            ; 0x5e8
lCPI0_114:
	.quad	1488                            ; 0x5d0
	.quad	1496                            ; 0x5d8
lCPI0_115:
	.quad	1472                            ; 0x5c0
	.quad	1480                            ; 0x5c8
lCPI0_116:
	.quad	1584                            ; 0x630
	.quad	1592                            ; 0x638
lCPI0_117:
	.quad	1568                            ; 0x620
	.quad	1576                            ; 0x628
lCPI0_118:
	.quad	1552                            ; 0x610
	.quad	1560                            ; 0x618
lCPI0_119:
	.quad	1536                            ; 0x600
	.quad	1544                            ; 0x608
lCPI0_120:
	.quad	1648                            ; 0x670
	.quad	1656                            ; 0x678
lCPI0_121:
	.quad	1632                            ; 0x660
	.quad	1640                            ; 0x668
lCPI0_122:
	.quad	1616                            ; 0x650
	.quad	1624                            ; 0x658
lCPI0_123:
	.quad	1600                            ; 0x640
	.quad	1608                            ; 0x648
lCPI0_124:
	.quad	1712                            ; 0x6b0
	.quad	1720                            ; 0x6b8
lCPI0_125:
	.quad	1696                            ; 0x6a0
	.quad	1704                            ; 0x6a8
lCPI0_126:
	.quad	1680                            ; 0x690
	.quad	1688                            ; 0x698
lCPI0_127:
	.quad	1664                            ; 0x680
	.quad	1672                            ; 0x688
lCPI0_128:
	.quad	1776                            ; 0x6f0
	.quad	1784                            ; 0x6f8
lCPI0_129:
	.quad	1760                            ; 0x6e0
	.quad	1768                            ; 0x6e8
lCPI0_130:
	.quad	1744                            ; 0x6d0
	.quad	1752                            ; 0x6d8
lCPI0_131:
	.quad	1728                            ; 0x6c0
	.quad	1736                            ; 0x6c8
lCPI0_132:
	.quad	1840                            ; 0x730
	.quad	1848                            ; 0x738
lCPI0_133:
	.quad	1824                            ; 0x720
	.quad	1832                            ; 0x728
lCPI0_134:
	.quad	1808                            ; 0x710
	.quad	1816                            ; 0x718
lCPI0_135:
	.quad	1792                            ; 0x700
	.quad	1800                            ; 0x708
lCPI0_136:
	.quad	1904                            ; 0x770
	.quad	1912                            ; 0x778
lCPI0_137:
	.quad	1888                            ; 0x760
	.quad	1896                            ; 0x768
lCPI0_138:
	.quad	1872                            ; 0x750
	.quad	1880                            ; 0x758
lCPI0_139:
	.quad	1856                            ; 0x740
	.quad	1864                            ; 0x748
lCPI0_140:
	.quad	1968                            ; 0x7b0
	.quad	1976                            ; 0x7b8
lCPI0_141:
	.quad	1952                            ; 0x7a0
	.quad	1960                            ; 0x7a8
lCPI0_142:
	.quad	1936                            ; 0x790
	.quad	1944                            ; 0x798
lCPI0_143:
	.quad	1920                            ; 0x780
	.quad	1928                            ; 0x788
lCPI0_144:
	.quad	2032                            ; 0x7f0
	.quad	2040                            ; 0x7f8
lCPI0_145:
	.quad	2016                            ; 0x7e0
	.quad	2024                            ; 0x7e8
lCPI0_146:
	.quad	2000                            ; 0x7d0
	.quad	2008                            ; 0x7d8
lCPI0_147:
	.quad	1984                            ; 0x7c0
	.quad	1992                            ; 0x7c8
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_3:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_tile_inclusive_scan:                   ; @tile_inclusive_scan
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	sub	x9, sp, #18, lsl #12            ; =73728
	sub	x9, x9, #1632
	and	sp, x9, #0xffffffffffffffc0
	fmov	s2, wzr
	add	x8, sp, #18, lsl #12            ; =73728
	add	x8, x8, #1512
	str	wzr, [x8, #84]
	stur	wzr, [x8, #81]
	stur	xzr, [x8, #52]
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #511
	stur	xzr, [x8, #68]
	stur	xzr, [x8, #60]
	str	wzr, [x8, #76]
	stur	xzr, [x8, #20]
	stur	xzr, [x8, #36]
	stur	xzr, [x8, #28]
	str	wzr, [x8, #44]
	stp	xzr, xzr, [x8]
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #19760]
	str	q0, [sp, #19744]
	str	q0, [sp, #19728]
	str	q0, [sp, #19712]
	str	q0, [sp, #19696]
	str	q0, [sp, #19680]
	str	q0, [sp, #19664]
	str	q0, [sp, #19648]
	str	q0, [sp, #19632]
	str	q0, [sp, #19616]
	str	q0, [sp, #19600]
	str	q0, [sp, #19584]
	str	q0, [sp, #19568]
	str	q0, [sp, #19552]
	str	q0, [sp, #19536]
	str	q0, [sp, #19520]
	str	q0, [sp, #19504]
	str	q0, [sp, #19488]
	str	q0, [sp, #19472]
	str	q0, [sp, #19456]
	str	q0, [sp, #19440]
	str	q0, [sp, #19392]
	str	q0, [sp, #19408]
	str	q0, [sp, #19424]
	str	q0, [sp, #19376]
	str	q0, [sp, #19328]
	str	q0, [sp, #19344]
	str	q0, [sp, #19296]
	str	q0, [sp, #19312]
	str	q0, [sp, #19264]
	str	q0, [sp, #19280]
	str	q0, [sp, #19360]
	str	q0, [sp, #19248]
	str	q0, [sp, #19200]
	str	q0, [sp, #19216]
	str	q0, [sp, #19232]
	str	q0, [sp, #19184]
	str	q0, [sp, #19136]
	str	q0, [sp, #19152]
	str	q0, [sp, #19104]
	str	q0, [sp, #19120]
	str	q0, [sp, #19072]
	str	q0, [sp, #19088]
	str	q0, [sp, #19168]
	str	q0, [sp, #18992]
	str	q0, [sp, #18944]
	str	q0, [sp, #18960]
	str	q0, [sp, #19040]
	str	q0, [sp, #19056]
	str	q0, [sp, #19008]
	str	q0, [sp, #19024]
	str	q0, [sp, #18976]
	strb	wzr, [x9, #2048]
	str	q0, [sp, #18864]
	str	q0, [sp, #18848]
	str	q0, [sp, #18832]
	str	q0, [sp, #18816]
	str	q0, [sp, #18800]
	str	q0, [sp, #18752]
	str	q0, [sp, #18768]
	str	q0, [sp, #18720]
	str	q0, [sp, #18736]
	str	q0, [sp, #18688]
	str	q0, [sp, #18704]
	str	q0, [sp, #18784]
	str	q0, [sp, #18608]
	str	q0, [sp, #18560]
	str	q0, [sp, #18576]
	str	q0, [sp, #18656]
	str	q0, [sp, #18672]
	str	q0, [sp, #18624]
	str	q0, [sp, #18640]
	str	q0, [sp, #18592]
	str	q0, [sp, #18480]
	str	q0, [sp, #18432]
	str	q0, [sp, #18448]
	str	q0, [sp, #18528]
	str	q0, [sp, #18544]
	str	q0, [sp, #18496]
	str	q0, [sp, #18512]
	str	q0, [sp, #18464]
	strb	wzr, [x9, #1536]
	str	q0, [sp, #18352]
	str	q0, [sp, #18336]
	str	q0, [sp, #18320]
	str	q0, [sp, #18304]
	str	q0, [sp, #18288]
	str	q0, [sp, #18240]
	str	q0, [sp, #18256]
	str	q0, [sp, #18208]
	str	q0, [sp, #18224]
	str	q0, [sp, #18176]
	str	q0, [sp, #18192]
	str	q0, [sp, #18272]
	str	q0, [sp, #18096]
	str	q0, [sp, #18048]
	str	q0, [sp, #18064]
	str	q0, [sp, #18144]
	str	q0, [sp, #18160]
	str	q0, [sp, #18112]
	str	q0, [sp, #18128]
	str	q0, [sp, #18080]
	str	q0, [sp, #17968]
	str	q0, [sp, #17920]
	str	q0, [sp, #17936]
	str	q0, [sp, #18016]
	str	q0, [sp, #18032]
	str	q0, [sp, #17984]
	str	q0, [sp, #18000]
	str	q0, [sp, #17952]
	strb	wzr, [x9, #1024]
	str	q0, [sp, #17840]
	str	q0, [sp, #17824]
	str	q0, [sp, #17808]
	str	q0, [sp, #17792]
	str	q0, [sp, #17776]
	str	q0, [sp, #17728]
	str	q0, [sp, #17744]
	str	q0, [sp, #17696]
	str	q0, [sp, #17712]
	str	q0, [sp, #17664]
	str	q0, [sp, #17680]
	str	q0, [sp, #17760]
	str	q0, [sp, #17584]
	str	q0, [sp, #17536]
	str	q0, [sp, #17552]
	str	q0, [sp, #17632]
	str	q0, [sp, #17648]
	str	q0, [sp, #17600]
	str	q0, [sp, #17616]
	str	q0, [sp, #17568]
	str	q0, [sp, #17456]
	str	q0, [sp, #17408]
	str	q0, [sp, #17424]
	str	q0, [sp, #17504]
	str	q0, [sp, #17520]
	str	q0, [sp, #17472]
	str	q0, [sp, #17488]
	str	q0, [sp, #17440]
	strb	wzr, [x9, #512]
	str	q0, [sp, #17328]
	str	q0, [sp, #17312]
	str	q0, [sp, #17296]
	str	q0, [sp, #17280]
	str	q0, [sp, #17264]
	str	q0, [sp, #17216]
	str	q0, [sp, #17232]
	str	q0, [sp, #17184]
	str	q0, [sp, #17200]
	str	q0, [sp, #17152]
	str	q0, [sp, #17168]
	str	q0, [sp, #17248]
	str	q0, [sp, #17072]
	str	q0, [sp, #17024]
	str	q0, [sp, #17040]
	str	q0, [sp, #17120]
	str	q0, [sp, #17136]
	str	q0, [sp, #17088]
	str	q0, [sp, #17104]
	str	q0, [sp, #17056]
	str	q0, [sp, #16944]
	str	q0, [sp, #16896]
	str	q0, [sp, #16912]
	str	q0, [sp, #16992]
	str	q0, [sp, #17008]
	str	q0, [sp, #16960]
	str	q0, [sp, #16976]
	str	q0, [sp, #16928]
	strb	wzr, [x9]
	str	q0, [sp, #16816]
	str	q0, [sp, #16800]
	str	q0, [sp, #16784]
	str	q0, [sp, #16768]
	str	q0, [sp, #16752]
	str	q0, [sp, #16704]
	str	q0, [sp, #16720]
	str	q0, [sp, #16736]
	str	q0, [sp, #16688]
	dup.4s	v1, w2
Lloh0:
	adrp	x10, lCPI0_0@PAGE
Lloh1:
	ldr	q3, [x10, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x10, lCPI0_1@PAGE
Lloh3:
	ldr	q4, [x10, lCPI0_1@PAGEOFF]
	cmhi.4s	v5, v1, v4
	cmhi.4s	v1, v1, v3
	uzp1.8h	v5, v1, v5
	xtn.8b	v1, v5
Lloh4:
	adrp	x10, lCPI0_2@PAGE
Lloh5:
	ldr	q6, [x10, lCPI0_2@PAGEOFF]
	and.16b	v6, v5, v6
	str	q0, [sp, #16672]
	ldr	x10, [x0]
	ldr	x11, [x0, #16]
	ldr	w12, [x1]
	addv.8h	h6, v6
	fmov	w13, s6
	and	w13, w13, #0xff
	fmov	s6, w13
	cmeq.8b	v2, v6, v2
	umov.b	w13, v2[0]
	and	w14, w13, #0x1
	fmov	s2, w14
	ubfx	w14, w13, #1, #1
	mov.b	v2[1], w14
	ubfx	w14, w13, #2, #1
	mov.b	v2[2], w14
	ubfx	w14, w13, #3, #1
	mov.b	v2[3], w14
	ubfx	w14, w13, #4, #1
	mov.b	v2[4], w14
	ubfx	w14, w13, #5, #1
	mov.b	v2[5], w14
	ubfx	w14, w13, #6, #1
	ubfx	w15, w13, #7, #1
	ldr	w13, [x1, #36]
	movi.8b	v6, #1
	mov.b	v2[6], w14
	mov.b	v2[7], w15
	eor.8b	v2, v2, v6
	str	d1, [sp, #1592]                 ; 8-byte Folded Spill
	and.8b	v2, v2, v1
	umaxv.8h	h5, v5
	fmov	w14, s5
	shl.8b	v2, v2, #7
	cmlt.8b	v5, v2, #0
Lloh6:
	adrp	x15, lCPI0_3@PAGE
Lloh7:
	ldr	d2, [x15, lCPI0_3@PAGEOFF]
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x8, #80]
	str	wzr, [x8, #48]
	str	wzr, [x8, #16]
	tbnz	w14, #0, LBB0_1
	b	LBB0_1084
LBB0_1:                                 ; %scheduler.dispatch.lr.ph.lr.ph
	str	q0, [sp, #784]                  ; 16-byte Folded Spill
	mov	w16, #0                         ; =0x0
	add	x14, sp, #18, lsl #12           ; =73728
	add	x14, x14, #1384
	dup.2d	v0, x14
	add	x14, sp, #17, lsl #12           ; =69632
	add	x14, x14, #1384
	dup.2d	v5, x14
	stp	q5, q0, [sp, #80]               ; 32-byte Folded Spill
	add	x14, sp, #16, lsl #12           ; =65536
	add	x14, x14, #3432
	dup.2d	v0, x14
	add	x14, sp, #15, lsl #12           ; =61440
	add	x14, x14, #3432
	dup.2d	v5, x14
	stp	q5, q0, [sp, #320]              ; 32-byte Folded Spill
	add	x14, sp, #14, lsl #12           ; =57344
	add	x14, x14, #3432
	dup.2d	v0, x14
	add	x14, sp, #14, lsl #12           ; =57344
	add	x14, x14, #1384
	dup.2d	v5, x14
	stp	q5, q0, [sp, #288]              ; 32-byte Folded Spill
	add	x14, sp, #13, lsl #12           ; =53248
	add	x14, x14, #1384
	dup.2d	v0, x14
	add	x14, sp, #12, lsl #12           ; =49152
	add	x14, x14, #1384
	dup.2d	v5, x14
	stp	q5, q0, [sp, #256]              ; 32-byte Folded Spill
	add	x14, sp, #11, lsl #12           ; =45056
	add	x14, x14, #3432
	dup.2d	v0, x14
	add	x14, sp, #10, lsl #12           ; =40960
	add	x14, x14, #3432
	dup.2d	v5, x14
	stp	q5, q0, [sp, #224]              ; 32-byte Folded Spill
	add	x14, sp, #9, lsl #12            ; =36864
	add	x14, x14, #3432
	dup.2d	v0, x14
	add	x14, sp, #9, lsl #12            ; =36864
	add	x14, x14, #1384
	dup.2d	v5, x14
	stp	q5, q0, [sp, #192]              ; 32-byte Folded Spill
	add	x14, sp, #8, lsl #12            ; =32768
	add	x14, x14, #1384
	dup.2d	v0, x14
	add	x14, sp, #7, lsl #12            ; =28672
	add	x14, x14, #1384
	dup.2d	v5, x14
	stp	q5, q0, [sp, #160]              ; 32-byte Folded Spill
	add	x14, sp, #6, lsl #12            ; =24576
	add	x14, x14, #3432
	dup.2d	v0, x14
	add	x14, sp, #5, lsl #12            ; =20480
	add	x14, x14, #3432
	dup.2d	v5, x14
	stp	q5, q0, [sp, #128]              ; 32-byte Folded Spill
	add	x14, sp, #4, lsl #12            ; =16384
	add	x14, x14, #3432
	dup.2d	v5, x14
	str	q5, [sp, #112]                  ; 16-byte Folded Spill
	add	w12, w13, w12, lsl #5
	dup.4s	v5, w12
	add.4s	v4, v5, v4
	add.4s	v3, v5, v3
	ushll2.2d	v0, v4, #2
	ushll2.2d	v5, v3, #2
	stp	q5, q0, [sp, #48]               ; 32-byte Folded Spill
	ushll.2d	v4, v4, #2
	ushll.2d	v3, v3, #2
	stp	q3, q4, [sp, #16]               ; 32-byte Folded Spill
	movi	d0, #0000000000000000
	str	q0, [sp, #704]                  ; 16-byte Folded Spill
	movi.2d	v3, #0000000000000000
	str	q3, [sp, #800]                  ; 16-byte Folded Spill
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #1344]                 ; 16-byte Folded Spill
	stp	q0, q0, [sp, #848]              ; 32-byte Folded Spill
	stp	q3, q3, [sp, #384]              ; 32-byte Folded Spill
	stp	q3, q3, [sp, #352]              ; 32-byte Folded Spill
	mov	w17, #1                         ; =0x1
	add	x12, sp, #18, lsl #12           ; =73728
	add	x12, x12, #1592
	add	x13, sp, #18, lsl #12           ; =73728
	add	x13, x13, #1560
Lloh8:
	adrp	x14, LJTI0_0@PAGE
Lloh9:
	add	x14, x14, LJTI0_0@PAGEOFF
	add	x15, sp, #18, lsl #12           ; =73728
	add	x15, x15, #1528
	stp	q3, q3, [sp, #624]              ; 32-byte Folded Spill
	stp	q3, q3, [sp, #592]              ; 32-byte Folded Spill
	stp	q3, q3, [sp, #544]              ; 32-byte Folded Spill
	str	q0, [sp, #1264]                 ; 16-byte Folded Spill
	movi.2d	v20, #0000000000000000
	str	q0, [sp, #928]                  ; 16-byte Folded Spill
	movi.2d	v13, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v27, #0000000000000000
	str	q0, [sp, #1280]                 ; 16-byte Folded Spill
	stp	q3, q3, [sp, #512]              ; 32-byte Folded Spill
	str	q0, [sp, #768]                  ; 16-byte Folded Spill
	str	q3, [sp, #1136]                 ; 16-byte Folded Spill
	str	q3, [sp, #1120]                 ; 16-byte Folded Spill
	str	q3, [sp, #1104]                 ; 16-byte Folded Spill
	str	q3, [sp, #1152]                 ; 16-byte Folded Spill
	str	q0, [sp, #720]                  ; 16-byte Folded Spill
	str	q0, [sp, #1312]                 ; 16-byte Folded Spill
	movi.2d	v28, #0000000000000000
	stp	q3, q3, [sp, #480]              ; 32-byte Folded Spill
	str	q0, [sp, #1200]                 ; 16-byte Folded Spill
	str	q0, [sp, #1216]                 ; 16-byte Folded Spill
	movi.2d	v26, #0000000000000000
	str	q0, [sp, #1072]                 ; 16-byte Folded Spill
	str	q0, [sp, #1088]                 ; 16-byte Folded Spill
	movi.2d	v31, #0000000000000000
	str	q0, [sp, #1360]                 ; 16-byte Folded Spill
	movi.2d	v1, #0000000000000000
	stp	q1, q1, [sp, #448]              ; 32-byte Folded Spill
	stp	q1, q0, [sp, #992]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #960]              ; 32-byte Folded Spill
	str	q1, [sp, #944]                  ; 16-byte Folded Spill
	movi.2d	v6, #0000000000000000
	str	q1, [sp, #1056]                 ; 16-byte Folded Spill
	str	q0, [sp, #1296]                 ; 16-byte Folded Spill
	movi.2d	v30, #0000000000000000
	stp	q1, q1, [sp, #416]              ; 32-byte Folded Spill
	str	q1, [sp, #1040]                 ; 16-byte Folded Spill
	str	q1, [sp, #1248]                 ; 16-byte Folded Spill
	str	q1, [sp, #1184]                 ; 16-byte Folded Spill
	str	q1, [sp, #1424]                 ; 16-byte Folded Spill
	stp	q1, q1, [sp, #656]              ; 32-byte Folded Spill
	stp	q1, q1, [sp, #896]              ; 32-byte Folded Spill
	str	q1, [sp, #880]                  ; 16-byte Folded Spill
	movi.2d	v9, #0000000000000000
	movi.2d	v22, #0000000000000000
	str	q3, [sp, #576]                  ; 16-byte Folded Spill
	movi.2d	v8, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v11, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v12, #0000000000000000
	str	d2, [sp, #696]                  ; 8-byte Folded Spill
LBB0_2:                                 ; %scheduler.dispatch.lr.ph
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_3 Depth 2
                                        ;       Child Loop BB0_8 Depth 3
                                        ;         Child Loop BB0_227 Depth 4
                                        ;         Child Loop BB0_306 Depth 4
                                        ;         Child Loop BB0_372 Depth 4
                                        ;         Child Loop BB0_449 Depth 4
                                        ;         Child Loop BB0_517 Depth 4
                                        ;         Child Loop BB0_575 Depth 4
                                        ;         Child Loop BB0_666 Depth 4
                                        ;         Child Loop BB0_749 Depth 4
                                        ;         Child Loop BB0_815 Depth 4
                                        ;         Child Loop BB0_892 Depth 4
                                        ;         Child Loop BB0_975 Depth 4
                                        ;         Child Loop BB0_1031 Depth 4
                                        ;         Child Loop BB0_1040 Depth 4
                                        ;         Child Loop BB0_155 Depth 4
                                        ;         Child Loop BB0_724 Depth 4
                                        ;         Child Loop BB0_584 Depth 4
                                        ;         Child Loop BB0_160 Depth 4
                                        ;         Child Loop BB0_145 Depth 4
                                        ;         Child Loop BB0_150 Depth 4
                                        ;       Child Loop BB0_1054 Depth 3
	str	q20, [sp, #1024]                ; 16-byte Folded Spill
	stp	q19, q18, [sp, #816]            ; 32-byte Folded Spill
LBB0_3:                                 ; %scheduler.dispatch
                                        ;   Parent Loop BB0_2 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_8 Depth 3
                                        ;         Child Loop BB0_227 Depth 4
                                        ;         Child Loop BB0_306 Depth 4
                                        ;         Child Loop BB0_372 Depth 4
                                        ;         Child Loop BB0_449 Depth 4
                                        ;         Child Loop BB0_517 Depth 4
                                        ;         Child Loop BB0_575 Depth 4
                                        ;         Child Loop BB0_666 Depth 4
                                        ;         Child Loop BB0_749 Depth 4
                                        ;         Child Loop BB0_815 Depth 4
                                        ;         Child Loop BB0_892 Depth 4
                                        ;         Child Loop BB0_975 Depth 4
                                        ;         Child Loop BB0_1031 Depth 4
                                        ;         Child Loop BB0_1040 Depth 4
                                        ;         Child Loop BB0_155 Depth 4
                                        ;         Child Loop BB0_724 Depth 4
                                        ;         Child Loop BB0_584 Depth 4
                                        ;         Child Loop BB0_160 Depth 4
                                        ;         Child Loop BB0_145 Depth 4
                                        ;         Child Loop BB0_150 Depth 4
                                        ;       Child Loop BB0_1054 Depth 3
	str	q26, [sp, #1552]                ; 16-byte Folded Spill
	str	q27, [sp, #1520]                ; 16-byte Folded Spill
	str	q25, [sp, #1328]                ; 16-byte Folded Spill
	stp	q22, q1, [sp, #736]             ; 32-byte Folded Spill
	sub	w17, w17, #1
	ldrb	w0, [x12, w17, sxtw]
	and	w1, w0, #0x1
	fmov	s20, w1
	ubfx	w1, w0, #1, #1
	mov.b	v20[1], w1
	ubfx	w1, w0, #2, #1
	mov.b	v20[2], w1
	ubfx	w1, w0, #3, #1
	mov.b	v20[3], w1
	ubfx	w1, w0, #4, #1
	mov.b	v20[4], w1
	ubfx	w1, w0, #5, #1
	mov.b	v20[5], w1
	ubfx	w1, w0, #6, #1
	mov.b	v20[6], w1
	lsr	w0, w0, #7
	mov.b	v20[7], w0
	ldr	w2, [x13, w17, sxtw #2]
	ldr	w0, [x15, w17, sxtw #2]
	mov.16b	v14, v30
	mov.16b	v25, v8
	mov.16b	v22, v6
	b	LBB0_8
LBB0_4:                                 ; %convergence.overflow.resume1002
                                        ;   in Loop: Header=BB0_8 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #18, lsl #12            ; =73728
	add	x2, x2, #1520
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s5, w4
	ubfx	w4, w5, #1, #1
	mov.b	v5[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v5[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v5[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v5[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v5[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v5[6], w4
	add	x4, sp, #18, lsl #12            ; =73728
	add	x4, x4, #1512
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v4, w5
	bit.8b	v5, v20, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x2, w3, uxtw]
	bic.8b	v3, v3, v4
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_1086
; %bb.5:                                ; %ready.overflow.resume1004
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q23, [sp, #5120]
	str	q11, [sp, #5136]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #1024
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q23, [sp, #5088]
	str	q11, [sp, #5104]
	add	x5, sp, #1, lsl #12             ; =4096
	add	x5, x5, #992
	str	w4, [x5, x2]
	ldr	q11, [sp, #5104]
	ldr	q23, [sp, #5088]
	str	q24, [sp, #5056]
	str	q12, [sp, #5072]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #960
	ldr	w4, [x4, x2]
	mov	w5, #19                         ; =0x13
	csel	w4, w5, w4, ne
	str	q24, [sp, #5024]
	str	q12, [sp, #5040]
	add	x5, sp, #1, lsl #12             ; =4096
	add	x5, x5, #928
	str	w4, [x5, x2]
	mov	w2, #51                         ; =0x33
	mov	w4, #50                         ; =0x32
	ldr	q12, [sp, #5040]
	ldr	q24, [sp, #5024]
LBB0_6:                                 ; %scheduler.dispatch.route.backedge
                                        ;   in Loop: Header=BB0_8 Depth=3
                                        ; kill: def $w3 killed $w3 killed $x3 def $x3
LBB0_7:                                 ; %scheduler.dispatch.route.backedge
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w5, #1                          ; =0x1
	lsl	w3, w5, w3
	cmp	w1, #0
	csel	w1, w3, wzr, ne
	add	x3, sp, #18, lsl #12            ; =73728
	add	x3, x3, #1592
	shl.8b	v3, v21, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x3, x17]
	add	x3, sp, #18, lsl #12            ; =73728
	add	x3, x3, #1560
	str	w4, [x3, x17, lsl #2]
	orr	w16, w1, w16
	add	x1, sp, #18, lsl #12            ; =73728
	add	x1, x1, #1528
	str	w0, [x1, x17, lsl #2]
	add	x17, x17, #1
	fmov	d20, d10
LBB0_8:                                 ; %scheduler.dispatch.route
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_3 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB0_227 Depth 4
                                        ;         Child Loop BB0_306 Depth 4
                                        ;         Child Loop BB0_372 Depth 4
                                        ;         Child Loop BB0_449 Depth 4
                                        ;         Child Loop BB0_517 Depth 4
                                        ;         Child Loop BB0_575 Depth 4
                                        ;         Child Loop BB0_666 Depth 4
                                        ;         Child Loop BB0_749 Depth 4
                                        ;         Child Loop BB0_815 Depth 4
                                        ;         Child Loop BB0_892 Depth 4
                                        ;         Child Loop BB0_975 Depth 4
                                        ;         Child Loop BB0_1031 Depth 4
                                        ;         Child Loop BB0_1040 Depth 4
                                        ;         Child Loop BB0_155 Depth 4
                                        ;         Child Loop BB0_724 Depth 4
                                        ;         Child Loop BB0_584 Depth 4
                                        ;         Child Loop BB0_160 Depth 4
                                        ;         Child Loop BB0_145 Depth 4
                                        ;         Child Loop BB0_150 Depth 4
	cmp	w2, #53
	b.hi	LBB0_1086
; %bb.9:                                ; %scheduler.dispatch.route
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w2, w2
	adr	x1, LBB0_10
	ldrh	w3, [x14, x2, lsl #1]
	add	x1, x1, x3, lsl #2
	br	x1
LBB0_10:                                ; %schedule.0
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v5, v20, #7
	cmlt.8b	v5, v5, #0
	umaxv.8b	b5, v5
	fmov	w1, s5
	ldr	q5, [sp, #19760]
	ldr	q16, [sp, #19712]
	ldr	q17, [sp, #19728]
	ldr	q18, [sp, #19744]
	mov	b19, v20[4]
	mov.b	v19[4], v20[5]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	mov	b21, v20[2]
	mov.b	v21[4], v20[3]
	ldp	q1, q3, [sp, #32]               ; 32-byte Folded Reload
	bit.16b	v18, v1, v19
	ushll.2d	v21, v21, #0
	shl.2d	v21, v21, #63
	cmlt.2d	v21, v21, #0
	bit.16b	v17, v3, v21
	mov	b26, v20[0]
	mov.b	v26[4], v20[1]
	ushll.2d	v26, v26, #0
	shl.2d	v26, v26, #63
	cmlt.2d	v26, v26, #0
	ldr	q3, [sp, #16]                   ; 16-byte Folded Reload
	bit.16b	v16, v3, v26
	mov	b27, v20[6]
	mov.b	v27[4], v20[7]
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	ldr	q3, [sp, #64]                   ; 16-byte Folded Reload
	bit.16b	v5, v3, v27
	zip2.8b	v30, v20, v0
	ushll.4s	v30, v30, #0
	shl.4s	v30, v30, #31
	mov.16b	v3, v31
	zip1.8b	v31, v20, v0
	ushll.4s	v31, v31, #0
	shl.4s	v31, v31, #31
	str	q5, [sp, #19760]
	str	q16, [sp, #19712]
	str	q17, [sp, #19728]
	str	q18, [sp, #19744]
	bic.16b	v25, v25, v27
	ldr	q1, [sp, #576]                  ; 16-byte Folded Reload
	bic.16b	v1, v1, v19
	str	q1, [sp, #576]                  ; 16-byte Folded Spill
	ldp	q5, q1, [sp, #736]              ; 32-byte Folded Reload
	bic.16b	v4, v5, v21
	bic.16b	v1, v1, v26
	stp	q4, q1, [sp, #736]              ; 32-byte Folded Spill
	ldr	q5, [sp, #19696]
	ldr	q16, [sp, #19680]
	cmge.4s	v17, v31, #0
	mov.16b	v31, v3
	and.16b	v16, v17, v16
	cmge.4s	v18, v30, #0
	and.16b	v5, v18, v5
	str	q5, [sp, #19696]
	str	q16, [sp, #19680]
	ldr	q5, [sp, #19664]
	ldr	q16, [sp, #19648]
	and.16b	v16, v17, v16
	and.16b	v5, v18, v5
	str	q5, [sp, #19664]
	str	q16, [sp, #19648]
	ldr	q5, [sp, #19632]
	ldr	q16, [sp, #19616]
	and.16b	v16, v17, v16
	and.16b	v5, v18, v5
	str	q5, [sp, #19632]
	str	q16, [sp, #19616]
	ldr	q5, [sp, #19600]
	ldr	q16, [sp, #19584]
	and.16b	v16, v17, v16
	and.16b	v5, v18, v5
	str	q5, [sp, #19600]
	str	q16, [sp, #19584]
	movi	d1, #0000000000000000
	str	q1, [sp, #704]                  ; 16-byte Folded Spill
	tbnz	w1, #0, LBB0_163
	b	LBB0_1063
LBB0_11:                                ; %scheduler.dispatch.route.schedule.46_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v5, v20, #7
	cmlt.8b	v5, v5, #0
	umaxv.8b	b5, v5
	fmov	w1, s5
	eor	w1, w1, #0x1
	b	LBB0_907
LBB0_12:                                ; %schedule.26
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v6, v12
	mov.16b	v1, v11
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w1, s3
	ldr	q3, [sp, #18176]
	ldr	q27, [sp, #18192]
	ldr	q21, [sp, #18208]
	ldr	q17, [sp, #18224]
	ldr	q18, [sp, #18288]
	ldr	q26, [sp, #18272]
	ldr	q10, [sp, #18256]
	ldr	q4, [sp, #18240]
	ldr	q5, [sp, #17792]
	ldr	q11, [sp, #17808]
	ldr	q30, [sp, #17824]
	ldr	q19, [sp, #17840]
	shl.2d	v5, v5, #5
	add.2d	v3, v3, v4
	add.2d	v12, v3, v5
	movi.2d	v5, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbz	w1, #0, LBB0_20
; %bb.13:                               ; %cond.load4761
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d12
	ldr	s5, [x2]
	tbnz	w1, #1, LBB0_21
LBB0_14:                                ; %else4771
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v12, v6
	shl.2d	v3, v11, #5
	add.2d	v4, v27, v10
	add.2d	v27, v4, v3
	tbz	w1, #2, LBB0_22
LBB0_15:                                ; %cond.load4773
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d27
	ld1.s	{ v5 }[2], [x2]
	mov.16b	v11, v1
	tbnz	w1, #3, LBB0_23
LBB0_16:                                ; %else4783
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.2d	v3, v30, #5
	add.2d	v4, v21, v26
	add.2d	v21, v4, v3
	tbz	w1, #4, LBB0_24
LBB0_17:                                ; %cond.load4785
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d21
	ld1.s	{ v16 }[0], [x2]
	tbnz	w1, #5, LBB0_25
LBB0_18:                                ; %else4795
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.2d	v3, v19, #5
	add.2d	v4, v17, v18
	add.2d	v17, v4, v3
	tbz	w1, #6, LBB0_26
LBB0_19:                                ; %cond.load4797
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d17
	ld1.s	{ v16 }[2], [x2]
	tbnz	w1, #7, LBB0_27
	b	LBB0_28
LBB0_20:                                ; %else4765
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #1, LBB0_14
LBB0_21:                                ; %cond.load4767
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v12[1]
	ld1.s	{ v5 }[1], [x2]
	mov.16b	v12, v6
	shl.2d	v3, v11, #5
	add.2d	v4, v27, v10
	add.2d	v27, v4, v3
	tbnz	w1, #2, LBB0_15
LBB0_22:                                ; %else4777
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v11, v1
	tbz	w1, #3, LBB0_16
LBB0_23:                                ; %cond.load4779
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v27[1]
	ld1.s	{ v5 }[3], [x2]
	shl.2d	v3, v30, #5
	add.2d	v4, v21, v26
	add.2d	v21, v4, v3
	tbnz	w1, #4, LBB0_17
LBB0_24:                                ; %else4789
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #5, LBB0_18
LBB0_25:                                ; %cond.load4791
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v21[1]
	ld1.s	{ v16 }[1], [x2]
	shl.2d	v3, v19, #5
	add.2d	v4, v17, v18
	add.2d	v17, v4, v3
	tbnz	w1, #6, LBB0_19
LBB0_26:                                ; %else4801
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #7, LBB0_28
LBB0_27:                                ; %cond.load4803
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v17[1]
	ld1.s	{ v16 }[3], [x2]
LBB0_28:                                ; %else4807
                                        ;   in Loop: Header=BB0_8 Depth=3
	zip2.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q4, [sp, #480]                  ; 16-byte Folded Reload
	bit.16b	v4, v16, v3
	str	q4, [sp, #480]                  ; 16-byte Folded Spill
	zip1.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q4, [sp, #496]                  ; 16-byte Folded Reload
	bit.16b	v4, v5, v3
	str	q4, [sp, #496]                  ; 16-byte Folded Spill
	tst	w1, #0xff
	b.ne	LBB0_582
	b	LBB0_1063
LBB0_29:                                ; %schedule.10
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v6, v12
	mov.16b	v1, v11
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w1, s3
	ldr	q3, [sp, #19264]
	ldr	q27, [sp, #19280]
	ldr	q21, [sp, #19296]
	ldr	q17, [sp, #19312]
	ldr	q18, [sp, #19376]
	ldr	q26, [sp, #19360]
	ldr	q10, [sp, #19344]
	ldr	q4, [sp, #19328]
	ldr	q5, [sp, #18816]
	ldr	q11, [sp, #18832]
	ldr	q30, [sp, #18848]
	ldr	q19, [sp, #18864]
	shl.2d	v5, v5, #5
	add.2d	v3, v3, v4
	add.2d	v12, v3, v5
	movi.2d	v5, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbz	w1, #0, LBB0_37
; %bb.30:                               ; %cond.load4312
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d12
	ldr	s5, [x2]
	tbnz	w1, #1, LBB0_38
LBB0_31:                                ; %else4322
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v12, v6
	shl.2d	v3, v11, #5
	add.2d	v4, v27, v10
	add.2d	v27, v4, v3
	tbz	w1, #2, LBB0_39
LBB0_32:                                ; %cond.load4324
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d27
	ld1.s	{ v5 }[2], [x2]
	mov.16b	v11, v1
	tbnz	w1, #3, LBB0_40
LBB0_33:                                ; %else4334
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.2d	v3, v30, #5
	add.2d	v4, v21, v26
	add.2d	v21, v4, v3
	tbz	w1, #4, LBB0_41
LBB0_34:                                ; %cond.load4336
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d21
	ld1.s	{ v16 }[0], [x2]
	tbnz	w1, #5, LBB0_42
LBB0_35:                                ; %else4346
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.2d	v3, v19, #5
	add.2d	v4, v17, v18
	add.2d	v17, v4, v3
	tbz	w1, #6, LBB0_43
LBB0_36:                                ; %cond.load4348
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d17
	ld1.s	{ v16 }[2], [x2]
	tbnz	w1, #7, LBB0_44
	b	LBB0_45
LBB0_37:                                ; %else4316
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #1, LBB0_31
LBB0_38:                                ; %cond.load4318
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v12[1]
	ld1.s	{ v5 }[1], [x2]
	mov.16b	v12, v6
	shl.2d	v3, v11, #5
	add.2d	v4, v27, v10
	add.2d	v27, v4, v3
	tbnz	w1, #2, LBB0_32
LBB0_39:                                ; %else4328
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v11, v1
	tbz	w1, #3, LBB0_33
LBB0_40:                                ; %cond.load4330
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v27[1]
	ld1.s	{ v5 }[3], [x2]
	shl.2d	v3, v30, #5
	add.2d	v4, v21, v26
	add.2d	v21, v4, v3
	tbnz	w1, #4, LBB0_34
LBB0_41:                                ; %else4340
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #5, LBB0_35
LBB0_42:                                ; %cond.load4342
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v21[1]
	ld1.s	{ v16 }[1], [x2]
	shl.2d	v3, v19, #5
	add.2d	v4, v17, v18
	add.2d	v17, v4, v3
	tbnz	w1, #6, LBB0_36
LBB0_43:                                ; %else4352
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #7, LBB0_45
LBB0_44:                                ; %cond.load4354
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v17[1]
	ld1.s	{ v16 }[3], [x2]
LBB0_45:                                ; %else4358
                                        ;   in Loop: Header=BB0_8 Depth=3
	zip2.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q1, [sp, #416]                  ; 16-byte Folded Reload
	bit.16b	v1, v16, v3
	str	q1, [sp, #416]                  ; 16-byte Folded Spill
	zip1.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q1, [sp, #432]                  ; 16-byte Folded Reload
	bit.16b	v1, v5, v3
	str	q1, [sp, #432]                  ; 16-byte Folded Spill
	tst	w1, #0xff
	b.ne	LBB0_143
	b	LBB0_1063
LBB0_46:                                ; %scheduler.dispatch.route.schedule.38_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v5, v20, #7
	cmlt.8b	v5, v5, #0
	umaxv.8b	b5, v5
	fmov	w1, s5
	eor	w1, w1, #0x1
	b	LBB0_763
LBB0_47:                                ; %schedule.5
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w1, s3
	ldr	q17, [sp, #19248]
	ldr	q19, [sp, #19232]
	ldr	q21, [sp, #19216]
	ldr	q3, [sp, #19200]
	shl.2d	v3, v3, #2
	dup.2d	v18, x10
	add.2d	v26, v18, v3
	movi.2d	v5, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbz	w1, #0, LBB0_55
; %bb.48:                               ; %cond.load
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d26
	ldr	s5, [x2]
	tbnz	w1, #1, LBB0_56
LBB0_49:                                ; %else4242
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.2d	v3, v21, #2
	add.2d	v21, v18, v3
	tbz	w1, #2, LBB0_57
LBB0_50:                                ; %cond.load4244
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d21
	ld1.s	{ v5 }[2], [x2]
	tbnz	w1, #3, LBB0_58
LBB0_51:                                ; %else4248
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.2d	v3, v19, #2
	add.2d	v19, v18, v3
	tbz	w1, #4, LBB0_59
LBB0_52:                                ; %cond.load4250
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d19
	ld1.s	{ v16 }[0], [x2]
	tbnz	w1, #5, LBB0_60
LBB0_53:                                ; %else4254
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.2d	v3, v17, #2
	add.2d	v17, v18, v3
	tbz	w1, #6, LBB0_61
LBB0_54:                                ; %cond.load4256
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d17
	ld1.s	{ v16 }[2], [x2]
	tbnz	w1, #7, LBB0_62
	b	LBB0_63
LBB0_55:                                ; %else
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #1, LBB0_49
LBB0_56:                                ; %cond.load4241
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v26[1]
	ld1.s	{ v5 }[1], [x2]
	shl.2d	v3, v21, #2
	add.2d	v21, v18, v3
	tbnz	w1, #2, LBB0_50
LBB0_57:                                ; %else4245
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #3, LBB0_51
LBB0_58:                                ; %cond.load4247
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v21[1]
	ld1.s	{ v5 }[3], [x2]
	shl.2d	v3, v19, #2
	add.2d	v19, v18, v3
	tbnz	w1, #4, LBB0_52
LBB0_59:                                ; %else4251
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #5, LBB0_53
LBB0_60:                                ; %cond.load4253
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v19[1]
	ld1.s	{ v16 }[1], [x2]
	shl.2d	v3, v17, #2
	add.2d	v17, v18, v3
	tbnz	w1, #6, LBB0_54
LBB0_61:                                ; %else4257
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #7, LBB0_63
LBB0_62:                                ; %cond.load4259
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v17[1]
	ld1.s	{ v16 }[3], [x2]
LBB0_63:                                ; %else4260
                                        ;   in Loop: Header=BB0_8 Depth=3
	zip2.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q1, [sp, #656]                  ; 16-byte Folded Reload
	bit.16b	v1, v16, v3
	str	q1, [sp, #656]                  ; 16-byte Folded Spill
	zip1.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q1, [sp, #672]                  ; 16-byte Folded Reload
	bit.16b	v1, v5, v3
	str	q1, [sp, #672]                  ; 16-byte Folded Spill
	tst	w1, #0xff
	b.ne	LBB0_148
	b	LBB0_1063
LBB0_64:                                ; %scheduler.dispatch.route.schedule.9_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v5, v20, #7
	cmlt.8b	v5, v5, #0
	umaxv.8b	b5, v5
	fmov	w1, s5
	eor	w1, w1, #0x1
	b	LBB0_242
LBB0_65:                                ; %scheduler.dispatch.route.schedule.4_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v5, v20, #7
	cmlt.8b	v5, v5, #0
	umaxv.8b	b5, v5
	fmov	w1, s5
	eor	w1, w1, #0x1
	b	LBB0_180
LBB0_66:                                ; %scheduler.dispatch.route.schedule.30_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v5, v20, #7
	cmlt.8b	v5, v5, #0
	umaxv.8b	b5, v5
	fmov	w1, s5
	eor	w1, w1, #0x1
	b	LBB0_614
LBB0_67:                                ; %scheduler.dispatch.route.schedule.2_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v5, v20, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	fmov	w1, s5
	b	LBB0_171
LBB0_68:                                ; %scheduler.dispatch.route.schedule.41_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v5, v20, #7
	cmlt.8b	v5, v5, #0
	umaxv.8b	b5, v5
	fmov	w1, s5
	eor	w1, w1, #0x1
	b	LBB0_829
LBB0_69:                                ; %schedule.42
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v6, v12
	mov.16b	v1, v11
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w1, s3
	ldr	q3, [sp, #17152]
	ldr	q27, [sp, #17168]
	ldr	q21, [sp, #17184]
	ldr	q17, [sp, #17200]
	ldr	q18, [sp, #17264]
	ldr	q26, [sp, #17248]
	ldr	q10, [sp, #17232]
	ldr	q4, [sp, #17216]
	ldr	q5, [sp, #16768]
	ldr	q11, [sp, #16784]
	ldr	q30, [sp, #16800]
	ldr	q19, [sp, #16816]
	shl.2d	v5, v5, #5
	add.2d	v3, v3, v4
	add.2d	v12, v3, v5
	movi.2d	v5, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbz	w1, #0, LBB0_77
; %bb.70:                               ; %cond.load5219
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d12
	ldr	s5, [x2]
	tbnz	w1, #1, LBB0_78
LBB0_71:                                ; %else5229
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v12, v6
	shl.2d	v3, v11, #5
	add.2d	v4, v27, v10
	add.2d	v27, v4, v3
	tbz	w1, #2, LBB0_79
LBB0_72:                                ; %cond.load5231
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d27
	ld1.s	{ v5 }[2], [x2]
	mov.16b	v11, v1
	tbnz	w1, #3, LBB0_80
LBB0_73:                                ; %else5241
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.2d	v3, v30, #5
	add.2d	v4, v21, v26
	add.2d	v21, v4, v3
	tbz	w1, #4, LBB0_81
LBB0_74:                                ; %cond.load5243
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d21
	ld1.s	{ v16 }[0], [x2]
	tbnz	w1, #5, LBB0_82
LBB0_75:                                ; %else5253
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.2d	v3, v19, #5
	add.2d	v4, v17, v18
	add.2d	v17, v4, v3
	tbz	w1, #6, LBB0_83
LBB0_76:                                ; %cond.load5255
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d17
	ld1.s	{ v16 }[2], [x2]
	tbnz	w1, #7, LBB0_84
	b	LBB0_85
LBB0_77:                                ; %else5223
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #1, LBB0_71
LBB0_78:                                ; %cond.load5225
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v12[1]
	ld1.s	{ v5 }[1], [x2]
	mov.16b	v12, v6
	shl.2d	v3, v11, #5
	add.2d	v4, v27, v10
	add.2d	v27, v4, v3
	tbnz	w1, #2, LBB0_72
LBB0_79:                                ; %else5235
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v11, v1
	tbz	w1, #3, LBB0_73
LBB0_80:                                ; %cond.load5237
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v27[1]
	ld1.s	{ v5 }[3], [x2]
	shl.2d	v3, v30, #5
	add.2d	v4, v21, v26
	add.2d	v21, v4, v3
	tbnz	w1, #4, LBB0_74
LBB0_81:                                ; %else5247
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #5, LBB0_75
LBB0_82:                                ; %cond.load5249
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v21[1]
	ld1.s	{ v16 }[1], [x2]
	shl.2d	v3, v19, #5
	add.2d	v4, v17, v18
	add.2d	v17, v4, v3
	tbnz	w1, #6, LBB0_76
LBB0_83:                                ; %else5259
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #7, LBB0_85
LBB0_84:                                ; %cond.load5261
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v17[1]
	ld1.s	{ v16 }[3], [x2]
LBB0_85:                                ; %else5265
                                        ;   in Loop: Header=BB0_8 Depth=3
	zip2.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q4, [sp, #544]                  ; 16-byte Folded Reload
	bit.16b	v4, v16, v3
	str	q4, [sp, #544]                  ; 16-byte Folded Spill
	zip1.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q4, [sp, #560]                  ; 16-byte Folded Reload
	bit.16b	v4, v5, v3
	str	q4, [sp, #560]                  ; 16-byte Folded Spill
	tst	w1, #0xff
	b.ne	LBB0_153
	b	LBB0_1063
LBB0_86:                                ; %schedule.18
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v6, v12
	mov.16b	v1, v11
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w1, s3
	ldr	q3, [sp, #18688]
	ldr	q27, [sp, #18704]
	ldr	q21, [sp, #18720]
	ldr	q17, [sp, #18736]
	ldr	q18, [sp, #18800]
	ldr	q26, [sp, #18784]
	ldr	q10, [sp, #18768]
	ldr	q4, [sp, #18752]
	ldr	q5, [sp, #18304]
	ldr	q11, [sp, #18320]
	ldr	q30, [sp, #18336]
	ldr	q19, [sp, #18352]
	shl.2d	v5, v5, #5
	add.2d	v3, v3, v4
	add.2d	v12, v3, v5
	movi.2d	v5, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbz	w1, #0, LBB0_94
; %bb.87:                               ; %cond.load4532
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d12
	ldr	s5, [x2]
	tbnz	w1, #1, LBB0_95
LBB0_88:                                ; %else4542
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v12, v6
	shl.2d	v3, v11, #5
	add.2d	v4, v27, v10
	add.2d	v27, v4, v3
	tbz	w1, #2, LBB0_96
LBB0_89:                                ; %cond.load4544
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d27
	ld1.s	{ v5 }[2], [x2]
	mov.16b	v11, v1
	tbnz	w1, #3, LBB0_97
LBB0_90:                                ; %else4554
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.2d	v3, v30, #5
	add.2d	v4, v21, v26
	add.2d	v21, v4, v3
	tbz	w1, #4, LBB0_98
LBB0_91:                                ; %cond.load4556
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d21
	ld1.s	{ v16 }[0], [x2]
	tbnz	w1, #5, LBB0_99
LBB0_92:                                ; %else4566
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.2d	v3, v19, #5
	add.2d	v4, v17, v18
	add.2d	v17, v4, v3
	tbz	w1, #6, LBB0_100
LBB0_93:                                ; %cond.load4568
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d17
	ld1.s	{ v16 }[2], [x2]
	tbnz	w1, #7, LBB0_101
	b	LBB0_102
LBB0_94:                                ; %else4536
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #1, LBB0_88
LBB0_95:                                ; %cond.load4538
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v12[1]
	ld1.s	{ v5 }[1], [x2]
	mov.16b	v12, v6
	shl.2d	v3, v11, #5
	add.2d	v4, v27, v10
	add.2d	v27, v4, v3
	tbnz	w1, #2, LBB0_89
LBB0_96:                                ; %else4548
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v11, v1
	tbz	w1, #3, LBB0_90
LBB0_97:                                ; %cond.load4550
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v27[1]
	ld1.s	{ v5 }[3], [x2]
	shl.2d	v3, v30, #5
	add.2d	v4, v21, v26
	add.2d	v21, v4, v3
	tbnz	w1, #4, LBB0_91
LBB0_98:                                ; %else4560
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #5, LBB0_92
LBB0_99:                                ; %cond.load4562
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v21[1]
	ld1.s	{ v16 }[1], [x2]
	shl.2d	v3, v19, #5
	add.2d	v4, v17, v18
	add.2d	v17, v4, v3
	tbnz	w1, #6, LBB0_93
LBB0_100:                               ; %else4572
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #7, LBB0_102
LBB0_101:                               ; %cond.load4574
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v17[1]
	ld1.s	{ v16 }[3], [x2]
LBB0_102:                               ; %else4578
                                        ;   in Loop: Header=BB0_8 Depth=3
	zip2.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q1, [sp, #448]                  ; 16-byte Folded Reload
	bit.16b	v1, v16, v3
	str	q1, [sp, #448]                  ; 16-byte Folded Spill
	zip1.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q1, [sp, #464]                  ; 16-byte Folded Reload
	bit.16b	v1, v5, v3
	str	q1, [sp, #464]                  ; 16-byte Folded Spill
	tst	w1, #0xff
	b.ne	LBB0_158
	b	LBB0_1063
LBB0_103:                               ; %scheduler.dispatch.route.schedule.22_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v5, v20, #7
	cmlt.8b	v5, v5, #0
	umaxv.8b	b5, v5
	fmov	w1, s5
	eor	w1, w1, #0x1
	b	LBB0_465
LBB0_104:                               ; %scheduler.dispatch.route.schedule.33_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v5, v20, #7
	cmlt.8b	v5, v5, #0
	umaxv.8b	b5, v5
	fmov	w1, s5
	eor	w1, w1, #0x1
	b	LBB0_680
LBB0_105:                               ; %scheduler.dispatch.route.schedule.17_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v5, v20, #7
	cmlt.8b	v5, v5, #0
	umaxv.8b	b5, v5
	fmov	w1, s5
	eor	w1, w1, #0x1
	b	LBB0_386
LBB0_106:                               ; %scheduler.dispatch.route.schedule.25_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v5, v20, #7
	cmlt.8b	v5, v5, #0
	umaxv.8b	b5, v5
	fmov	w1, s5
	eor	w1, w1, #0x1
	b	LBB0_531
LBB0_107:                               ; %scheduler.dispatch.route.schedule.14_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v5, v20, #7
	cmlt.8b	v5, v5, #0
	umaxv.8b	b5, v5
	fmov	w1, s5
	eor	w1, w1, #0x1
	b	LBB0_320
LBB0_108:                               ; %schedule.50
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w1, s3
	ldr	q16, [sp, #16752]
	ldr	q18, [sp, #16736]
	ldr	q21, [sp, #16720]
	ldr	q3, [sp, #16704]
	ldr	q5, [sp, #16688]
	ldr	q19, [sp, #16672]
	shl.2d	v3, v3, #2
	dup.2d	v17, x11
	add.2d	v26, v17, v3
	tbz	w1, #0, LBB0_117
; %bb.109:                              ; %cond.store5497
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d26
	str	s19, [x2]
	tbnz	w1, #1, LBB0_118
LBB0_110:                               ; %else5504
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.2d	v3, v21, #2
	add.2d	v21, v17, v3
	tbz	w1, #2, LBB0_119
LBB0_111:                               ; %cond.store5505
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d21
	st1.s	{ v19 }[2], [x2]
	tbnz	w1, #3, LBB0_120
LBB0_112:                               ; %else5512
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.2d	v3, v18, #2
	add.2d	v18, v17, v3
	tbz	w1, #4, LBB0_121
LBB0_113:                               ; %cond.store5513
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d18
	str	s5, [x2]
	tbnz	w1, #5, LBB0_122
LBB0_114:                               ; %else5520
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.2d	v3, v16, #2
	add.2d	v16, v17, v3
	tbz	w1, #6, LBB0_123
LBB0_115:                               ; %cond.store5521
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d16
	st1.s	{ v5 }[2], [x2]
	tbnz	w1, #7, LBB0_124
LBB0_116:                               ; %else5528
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w1, #0xff
	b.ne	LBB0_1038
	b	LBB0_1063
LBB0_117:                               ; %else5500
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #1, LBB0_110
LBB0_118:                               ; %cond.store5501
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v26[1]
	st1.s	{ v19 }[1], [x2]
	shl.2d	v3, v21, #2
	add.2d	v21, v17, v3
	tbnz	w1, #2, LBB0_111
LBB0_119:                               ; %else5508
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #3, LBB0_112
LBB0_120:                               ; %cond.store5509
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v21[1]
	st1.s	{ v19 }[3], [x2]
	shl.2d	v3, v18, #2
	add.2d	v18, v17, v3
	tbnz	w1, #4, LBB0_113
LBB0_121:                               ; %else5516
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #5, LBB0_114
LBB0_122:                               ; %cond.store5517
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v18[1]
	st1.s	{ v5 }[1], [x2]
	shl.2d	v3, v16, #2
	add.2d	v16, v17, v3
	tbnz	w1, #6, LBB0_115
LBB0_123:                               ; %else5524
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #7, LBB0_116
LBB0_124:                               ; %cond.store5525
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v16[1]
	st1.s	{ v5 }[3], [x2]
	tst	w1, #0xff
	b.ne	LBB0_1038
	b	LBB0_1063
LBB0_125:                               ; %schedule.34
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v6, v12
	mov.16b	v1, v11
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w1, s3
	ldr	q3, [sp, #17664]
	ldr	q27, [sp, #17680]
	ldr	q21, [sp, #17696]
	ldr	q17, [sp, #17712]
	ldr	q18, [sp, #17776]
	ldr	q26, [sp, #17760]
	ldr	q10, [sp, #17744]
	ldr	q4, [sp, #17728]
	ldr	q5, [sp, #17280]
	ldr	q11, [sp, #17296]
	ldr	q30, [sp, #17312]
	ldr	q19, [sp, #17328]
	shl.2d	v5, v5, #5
	add.2d	v3, v3, v4
	add.2d	v12, v3, v5
	movi.2d	v5, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbz	w1, #0, LBB0_133
; %bb.126:                              ; %cond.load4990
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d12
	ldr	s5, [x2]
	tbnz	w1, #1, LBB0_134
LBB0_127:                               ; %else5000
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v12, v6
	shl.2d	v3, v11, #5
	add.2d	v4, v27, v10
	add.2d	v27, v4, v3
	tbz	w1, #2, LBB0_135
LBB0_128:                               ; %cond.load5002
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d27
	ld1.s	{ v5 }[2], [x2]
	mov.16b	v11, v1
	tbnz	w1, #3, LBB0_136
LBB0_129:                               ; %else5012
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.2d	v3, v30, #5
	add.2d	v4, v21, v26
	add.2d	v21, v4, v3
	tbz	w1, #4, LBB0_137
LBB0_130:                               ; %cond.load5014
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d21
	ld1.s	{ v16 }[0], [x2]
	tbnz	w1, #5, LBB0_138
LBB0_131:                               ; %else5024
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.2d	v3, v19, #5
	add.2d	v4, v17, v18
	add.2d	v17, v4, v3
	tbz	w1, #6, LBB0_139
LBB0_132:                               ; %cond.load5026
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d17
	ld1.s	{ v16 }[2], [x2]
	tbnz	w1, #7, LBB0_140
	b	LBB0_141
LBB0_133:                               ; %else4994
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #1, LBB0_127
LBB0_134:                               ; %cond.load4996
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v12[1]
	ld1.s	{ v5 }[1], [x2]
	mov.16b	v12, v6
	shl.2d	v3, v11, #5
	add.2d	v4, v27, v10
	add.2d	v27, v4, v3
	tbnz	w1, #2, LBB0_128
LBB0_135:                               ; %else5006
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v11, v1
	tbz	w1, #3, LBB0_129
LBB0_136:                               ; %cond.load5008
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v27[1]
	ld1.s	{ v5 }[3], [x2]
	shl.2d	v3, v30, #5
	add.2d	v4, v21, v26
	add.2d	v21, v4, v3
	tbnz	w1, #4, LBB0_130
LBB0_137:                               ; %else5018
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #5, LBB0_131
LBB0_138:                               ; %cond.load5020
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v21[1]
	ld1.s	{ v16 }[1], [x2]
	shl.2d	v3, v19, #5
	add.2d	v4, v17, v18
	add.2d	v17, v4, v3
	tbnz	w1, #6, LBB0_132
LBB0_139:                               ; %else5030
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #7, LBB0_141
LBB0_140:                               ; %cond.load5032
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v17[1]
	ld1.s	{ v16 }[3], [x2]
LBB0_141:                               ; %else5036
                                        ;   in Loop: Header=BB0_8 Depth=3
	zip2.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q4, [sp, #512]                  ; 16-byte Folded Reload
	bit.16b	v4, v16, v3
	str	q4, [sp, #512]                  ; 16-byte Folded Spill
	zip1.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q4, [sp, #528]                  ; 16-byte Folded Reload
	bit.16b	v4, v5, v3
	str	q4, [sp, #528]                  ; 16-byte Folded Spill
	tst	w1, #0xff
	b.ne	LBB0_722
	b	LBB0_1063
LBB0_142:                               ; %scheduler.dispatch.route.schedule.49_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v5, v20, #7
	cmlt.8b	v5, v5, #0
	umaxv.8b	b5, v5
	fmov	w1, s5
	eor	w1, w1, #0x1
	b	LBB0_990
LBB0_143:                               ; %schedule.11
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v6, v31
	cbz	w0, LBB0_283
LBB0_144:                               ; %convergence.cascade264.preheader
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
LBB0_145:                               ; %convergence.cascade264
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_3 Depth=2
                                        ;       Parent Loop BB0_8 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w2, s4
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	str	q24, [sp, #2496]
	str	q12, [sp, #2512]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #2496
	ldr	w6, [x6, x2]
	cmp	w6, #4
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #1520
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s5, w19
	ubfx	w19, w20, #1, #1
	mov.b	v5[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v5[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v5[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v5[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v5[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v5[6], w19
	add	x19, sp, #18, lsl #12           ; =73728
	add	x19, x19, #1512
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s3, w21
	ubfx	w21, w20, #1, #1
	mov.b	v3[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v3[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v3[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v3[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v3[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v3[6], w21
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	orr.8b	v4, v20, v3
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	and.8b	v7, v1, v5
	eor.8b	v7, v7, v4
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v4, v7
	dup.8b	v17, w7
	bit.8b	v3, v16, v17
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x19, w3, sxtw]
	bic.8b	v3, v5, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v4, v5, v4
	str	q23, [sp, #2464]
	str	q11, [sp, #2480]
	add	x3, sp, #2464
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v20, v4, v3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_284
; %bb.146:                              ; %convergence.cascade264
                                        ;   in Loop: Header=BB0_145 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_284
; %bb.147:                              ; %convergence.cascade264
                                        ;   in Loop: Header=BB0_145 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_145
	b	LBB0_284
LBB0_148:                               ; %schedule.6
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v6, v31
	cbz	w0, LBB0_205
LBB0_149:                               ; %convergence.cascade.preheader
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
LBB0_150:                               ; %convergence.cascade
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_3 Depth=2
                                        ;       Parent Loop BB0_8 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w2, s4
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	str	q24, [sp, #2112]
	str	q12, [sp, #2128]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #2112
	ldr	w6, [x6, x2]
	cmp	w6, #2
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #1520
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s5, w19
	ubfx	w19, w20, #1, #1
	mov.b	v5[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v5[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v5[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v5[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v5[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v5[6], w19
	add	x19, sp, #18, lsl #12           ; =73728
	add	x19, x19, #1512
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s3, w21
	ubfx	w21, w20, #1, #1
	mov.b	v3[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v3[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v3[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v3[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v3[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v3[6], w21
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	orr.8b	v4, v20, v3
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	and.8b	v7, v1, v5
	eor.8b	v7, v7, v4
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v4, v7
	dup.8b	v17, w7
	bit.8b	v3, v16, v17
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x19, w3, sxtw]
	bic.8b	v3, v5, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v4, v5, v4
	str	q23, [sp, #2080]
	str	q11, [sp, #2096]
	add	x3, sp, #2080
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v20, v4, v3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_206
; %bb.151:                              ; %convergence.cascade
                                        ;   in Loop: Header=BB0_150 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_206
; %bb.152:                              ; %convergence.cascade
                                        ;   in Loop: Header=BB0_150 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_150
	b	LBB0_206
LBB0_153:                               ; %schedule.43
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v6, v31
	cbz	w0, LBB0_864
LBB0_154:                               ; %convergence.cascade908.preheader
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v10, v29
	mov	w1, #0                          ; =0x0
LBB0_155:                               ; %convergence.cascade908
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_3 Depth=2
                                        ;       Parent Loop BB0_8 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w2, s4
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	str	q24, [sp, #4672]
	str	q12, [sp, #4688]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #1, lsl #12             ; =4096
	add	x6, x6, #576
	ldr	w6, [x6, x2]
	cmp	w6, #16
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #1520
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s5, w19
	ubfx	w19, w20, #1, #1
	mov.b	v5[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v5[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v5[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v5[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v5[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v5[6], w19
	add	x19, sp, #18, lsl #12           ; =73728
	add	x19, x19, #1512
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s3, w21
	ubfx	w21, w20, #1, #1
	mov.b	v3[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v3[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v3[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v3[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v3[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v3[6], w21
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	orr.8b	v4, v20, v3
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	and.8b	v7, v1, v5
	eor.8b	v7, v7, v4
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v4, v7
	dup.8b	v17, w7
	bit.8b	v3, v16, v17
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x19, w3, sxtw]
	bic.8b	v3, v5, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v4, v5, v4
	str	q23, [sp, #4640]
	str	q11, [sp, #4656]
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #544
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v20, v4, v3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_865
; %bb.156:                              ; %convergence.cascade908
                                        ;   in Loop: Header=BB0_155 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_865
; %bb.157:                              ; %convergence.cascade908
                                        ;   in Loop: Header=BB0_155 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_155
	b	LBB0_865
LBB0_158:                               ; %schedule.19
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v6, v31
	cbz	w0, LBB0_427
LBB0_159:                               ; %convergence.cascade425.preheader
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
LBB0_160:                               ; %convergence.cascade425
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_3 Depth=2
                                        ;       Parent Loop BB0_8 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w2, s4
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	str	q24, [sp, #3040]
	str	q12, [sp, #3056]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #3040
	ldr	w6, [x6, x2]
	cmp	w6, #7
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #1520
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s5, w19
	ubfx	w19, w20, #1, #1
	mov.b	v5[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v5[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v5[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v5[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v5[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v5[6], w19
	add	x19, sp, #18, lsl #12           ; =73728
	add	x19, x19, #1512
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s3, w21
	ubfx	w21, w20, #1, #1
	mov.b	v3[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v3[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v3[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v3[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v3[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v3[6], w21
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	orr.8b	v4, v20, v3
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	and.8b	v7, v1, v5
	eor.8b	v7, v7, v4
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v4, v7
	dup.8b	v17, w7
	bit.8b	v3, v16, v17
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x19, w3, sxtw]
	bic.8b	v3, v5, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v4, v5, v4
	str	q23, [sp, #3008]
	str	q11, [sp, #3024]
	add	x3, sp, #3008
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v20, v4, v3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_428
; %bb.161:                              ; %convergence.cascade425
                                        ;   in Loop: Header=BB0_160 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_428
; %bb.162:                              ; %convergence.cascade425
                                        ;   in Loop: Header=BB0_160 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_160
	b	LBB0_428
LBB0_163:                               ; %schedule.1
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v6, v22
	mov.16b	v30, v14
	ldr	q27, [sp, #1520]                ; 16-byte Folded Reload
	ldr	q26, [sp, #1552]                ; 16-byte Folded Reload
	mov.16b	v8, v25
	ldr	q25, [sp, #1328]                ; 16-byte Folded Reload
	shl.8b	v5, v20, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	fmov	w1, s5
	mov	w2, #3                          ; =0x3
	dup.2d	v5, x2
	ldp	q22, q1, [sp, #736]             ; 32-byte Folded Reload
	cmgt.2d	v16, v5, v22
	cmgt.2d	v17, v5, v1
	uzp1.4s	v16, v17, v16
	ldr	q3, [sp, #576]                  ; 16-byte Folded Reload
	cmgt.2d	v17, v5, v3
	cmgt.2d	v18, v5, v8
	uzp1.4s	v17, v17, v18
	uzp1.8h	v16, v16, v17
	xtn.8b	v16, v16
	and.8b	v21, v20, v16
	shl.8b	v16, v21, #7
	cmlt.8b	v16, v16, #0
	and.8b	v17, v16, v2
	addv.8b	b17, v17
	fmov	w2, s17
	umaxv.8b	b16, v16
	fmov	w3, s16
	tbz	w3, #0, LBB0_169
; %bb.164:                              ; %schedule.1
                                        ;   in Loop: Header=BB0_8 Depth=3
	cmge.2d	v16, v22, v5
	cmge.2d	v17, v1, v5
	uzp1.4s	v16, v17, v16
	cmge.2d	v17, v3, v5
	cmge.2d	v5, v8, v5
	uzp1.4s	v5, v17, v5
	uzp1.8h	v5, v16, v5
	xtn.8b	v5, v5
	and.8b	v10, v20, v5
	shl.8b	v5, v10, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	fmov	w3, s5
	tst	w3, #0xff
	b.eq	LBB0_169
; %bb.165:                              ; %varying.divergent
                                        ;   in Loop: Header=BB0_8 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	str	q24, [sp, #1728]
	str	q12, [sp, #1744]
	and	x1, x1, #0x7
	add	x3, sp, #1728
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #0, #0, ne
	cset	w1, ne
	cmp	w2, #255
	b.ne	LBB0_167
; %bb.166:                              ; %varying.divergent
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #0, LBB0_167
	b	LBB0_1086
LBB0_167:                               ; %convergence.overflow.resume
                                        ;   in Loop: Header=BB0_8 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #18, lsl #12            ; =73728
	add	x2, x2, #1520
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s5, w4
	ubfx	w4, w5, #1, #1
	mov.b	v5[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v5[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v5[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v5[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v5[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v5[6], w4
	add	x4, sp, #18, lsl #12            ; =73728
	add	x4, x4, #1512
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v4, w5
	bit.8b	v5, v20, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x2, w3, uxtw]
	bic.8b	v3, v3, v4
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_1086
; %bb.168:                              ; %ready.overflow.resume113
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v14, v30
	mov.16b	v25, v8
	mov.16b	v22, v6
	str	q23, [sp, #1696]
	str	q11, [sp, #1712]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #1696
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	str	q23, [sp, #1664]
	str	q11, [sp, #1680]
	add	x5, sp, #1664
	str	w4, [x5, x2]
	ldr	q11, [sp, #1680]
	ldr	q23, [sp, #1664]
	str	q24, [sp, #1632]
	str	q12, [sp, #1648]
	add	x4, sp, #1632
	ldr	w4, [x4, x2]
	csel	w4, wzr, w4, ne
	str	q24, [sp, #1600]
	str	q12, [sp, #1616]
	add	x5, sp, #1600
	str	w4, [x5, x2]
	csinc	w0, w0, w3, eq
	mov	w2, #53                         ; =0x35
	mov	w4, #2                          ; =0x2
	ldr	q12, [sp, #1616]
	ldr	q24, [sp, #1600]
	b	LBB0_7
LBB0_169:                               ; %varying.coherent
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1051
; %bb.170:                              ; %varying.coherent.true
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w1, #0xff
	mov.16b	v14, v30
	mov.16b	v25, v8
	mov.16b	v22, v6
	b.eq	LBB0_1063
LBB0_171:                               ; %schedule.2
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q28, [sp, #1408]                ; 16-byte Folded Spill
	str	q13, [sp, #1456]                ; 16-byte Folded Spill
	str	q0, [sp, #1488]                 ; 16-byte Folded Spill
	str	q12, [sp, #1536]                ; 16-byte Folded Spill
	str	q11, [sp, #1568]                ; 16-byte Folded Spill
	str	q14, [sp, #1440]                ; 16-byte Folded Spill
	rbit	w2, w1
	clz	w2, w2
	tst	w1, #0xff
	csel	w2, wzr, w2, eq
	ubfiz	x4, x2, #3, #3
	lsl	w5, w2, #2
Lloh10:
	adrp	x2, lCPI0_4@PAGE
Lloh11:
	ldr	q5, [x2, lCPI0_4@PAGEOFF]
Lloh12:
	adrp	x2, lCPI0_5@PAGE
Lloh13:
	ldr	q16, [x2, lCPI0_5@PAGEOFF]
	str	q5, [sp, #16560]
	str	q16, [sp, #16544]
Lloh14:
	adrp	x2, lCPI0_6@PAGE
Lloh15:
	ldr	q5, [x2, lCPI0_6@PAGEOFF]
Lloh16:
	adrp	x2, lCPI0_7@PAGE
Lloh17:
	ldr	q16, [x2, lCPI0_7@PAGEOFF]
	str	q5, [sp, #16528]
	str	q16, [sp, #16512]
	add	x2, sp, #4, lsl #12             ; =16384
	add	x2, x2, #128
	ldr	x2, [x2, x4]
	sub	x2, x2, x5
	tst	w1, #0xff
Lloh18:
	adrp	x3, lCPI0_8@PAGE
Lloh19:
	ldr	q5, [x3, lCPI0_8@PAGEOFF]
Lloh20:
	adrp	x3, lCPI0_9@PAGE
Lloh21:
	ldr	q16, [x3, lCPI0_9@PAGEOFF]
	str	q5, [sp, #16496]
	str	q16, [sp, #16480]
Lloh22:
	adrp	x3, lCPI0_10@PAGE
Lloh23:
	ldr	q5, [x3, lCPI0_10@PAGEOFF]
Lloh24:
	adrp	x3, lCPI0_11@PAGE
Lloh25:
	ldr	q16, [x3, lCPI0_11@PAGEOFF]
	str	q5, [sp, #16464]
	str	q16, [sp, #16448]
	add	x3, sp, #4, lsl #12             ; =16384
	add	x3, x3, #64
	ldr	x3, [x3, x4]
	csel	x2, xzr, x2, eq
	sub	x3, x3, x5
	tst	w1, #0xff
Lloh26:
	adrp	x6, lCPI0_12@PAGE
Lloh27:
	ldr	q5, [x6, lCPI0_12@PAGEOFF]
Lloh28:
	adrp	x6, lCPI0_13@PAGE
Lloh29:
	ldr	q16, [x6, lCPI0_13@PAGEOFF]
	str	q5, [sp, #16432]
	str	q16, [sp, #16416]
Lloh30:
	adrp	x6, lCPI0_14@PAGE
Lloh31:
	ldr	q5, [x6, lCPI0_14@PAGEOFF]
Lloh32:
	adrp	x6, lCPI0_15@PAGE
Lloh33:
	ldr	q16, [x6, lCPI0_15@PAGEOFF]
	str	q5, [sp, #16400]
	str	q16, [sp, #16384]
	add	x6, sp, #4, lsl #12             ; =16384
	ldr	x6, [x6, x4]
	csel	x3, xzr, x3, eq
	sub	x6, x6, x5
	tst	w1, #0xff
Lloh34:
	adrp	x7, lCPI0_16@PAGE
Lloh35:
	ldr	q5, [x7, lCPI0_16@PAGEOFF]
Lloh36:
	adrp	x7, lCPI0_17@PAGE
Lloh37:
	ldr	q16, [x7, lCPI0_17@PAGEOFF]
Lloh38:
	adrp	x7, lCPI0_18@PAGE
Lloh39:
	ldr	q17, [x7, lCPI0_18@PAGEOFF]
Lloh40:
	adrp	x7, lCPI0_19@PAGE
Lloh41:
	ldr	q18, [x7, lCPI0_19@PAGEOFF]
	str	q18, [sp, #16368]
	str	q17, [sp, #16352]
	str	q16, [sp, #16336]
	str	q5, [sp, #16320]
	add	x7, sp, #3, lsl #12             ; =12288
	add	x7, x7, #4032
	ldr	x7, [x7, x4]
	csel	x4, xzr, x6, eq
	sub	x5, x7, x5
	ands	w1, w1, #0xff
	ldr	q26, [sp, #19568]
	ldr	q27, [sp, #19520]
	mov.16b	v1, v22
	mov.16b	v22, v31
	ldr	q31, [sp, #19536]
	ldr	q11, [sp, #19552]
	ldr	q12, [sp, #19488]
	ldr	q10, [sp, #19504]
	ldr	q19, [sp, #19456]
	ldr	q30, [sp, #19472]
	mov	b21, v20[2]
	mov.b	v21[4], v20[3]
	ushll.2d	v21, v21, #0
	shl.2d	v21, v21, #63
	cmlt.2d	v21, v21, #0
	ldr	q4, [sp, #96]                   ; 16-byte Folded Reload
	mov.16b	v13, v21
	bsl.16b	v13, v4, v30
	mov	b30, v20[0]
	mov.b	v30[4], v20[1]
	ushll.2d	v30, v30, #0
	shl.2d	v30, v30, #63
	cmlt.2d	v30, v30, #0
	mov	b14, v20[6]
	mov.b	v14[4], v20[7]
	mov.16b	v3, v30
	bsl.16b	v3, v4, v19
	ushll.2d	v19, v14, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	mov.16b	v14, v19
	bsl.16b	v14, v4, v10
	mov	b10, v20[4]
	mov.b	v10[4], v20[5]
	ushll.2d	v10, v10, #0
	shl.2d	v10, v10, #63
	cmlt.2d	v10, v10, #0
	bit.16b	v12, v4, v10
	bit.16b	v11, v17, v10
	bit.16b	v31, v16, v21
	bit.16b	v27, v5, v30
	bit.16b	v26, v18, v19
	zip2.8b	v4, v20, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	zip1.8b	v15, v20, v0
	ushll.4s	v15, v15, #0
	shl.4s	v15, v15, #31
	cmlt.4s	v15, v15, #0
	str	q26, [sp, #19568]
	str	q27, [sp, #19520]
	str	q31, [sp, #19536]
	str	q12, [sp, #19488]
	str	q14, [sp, #19504]
	str	q3, [sp, #19456]
	str	q13, [sp, #19472]
	str	q11, [sp, #19552]
	ldr	q3, [sp, #19696]
	ldr	q26, [sp, #19680]
	csel	x5, xzr, x5, eq
	add	x6, sp, #18, lsl #12            ; =73728
	add	x6, x6, #1384
	add	x5, x6, x5
	ldp	q31, q27, [x5]
	bif.16b	v26, v31, v15
	bif.16b	v3, v27, v4
	stp	q26, q3, [x5]
	ldr	q3, [sp, #19664]
	ldr	q26, [sp, #19648]
	add	x4, x6, x4
	ldp	q31, q27, [x4]
	bif.16b	v26, v31, v15
	bif.16b	v3, v27, v4
	stp	q26, q3, [x4]
	ldr	q3, [sp, #19632]
	ldr	q26, [sp, #19616]
	add	x3, x6, x3
	ldp	q31, q27, [x3]
	bif.16b	v26, v31, v15
	bif.16b	v3, v27, v4
	stp	q26, q3, [x3]
	ldr	q3, [sp, #19584]
	ldr	q26, [sp, #19600]
	add	x2, x6, x2
	ldp	q27, q31, [x2]
	bsl.16b	v4, v26, v31
	bif.16b	v3, v27, v15
	stp	q3, q4, [x2]
	shl.2d	v3, v25, #5
	ldr	q0, [sp, #576]                  ; 16-byte Folded Reload
	shl.2d	v4, v0, #5
	ldp	q6, q0, [sp, #736]              ; 32-byte Folded Reload
	shl.2d	v26, v6, #5
	shl.2d	v27, v0, #5
	ldr	q31, [sp, #19440]
	ldr	q11, [sp, #19424]
	ldr	q12, [sp, #19408]
	ldr	q13, [sp, #19392]
	bif.16b	v27, v13, v30
	bif.16b	v26, v12, v21
	bif.16b	v4, v11, v10
	bif.16b	v3, v31, v19
	str	q3, [sp, #19440]
	str	q4, [sp, #19424]
	str	q26, [sp, #19408]
	str	q27, [sp, #19392]
	ldr	q3, [sp, #19328]
	ldr	q4, [sp, #19344]
	ldr	q26, [sp, #19376]
	ldr	q27, [sp, #19360]
	ldr	q31, [sp, #19264]
	ldr	q11, [sp, #19280]
	ldr	q12, [sp, #19312]
	ldr	q13, [sp, #19296]
	ldr	q7, [sp, #80]                   ; 16-byte Folded Reload
	bit.16b	v13, v7, v10
	bit.16b	v12, v7, v19
	bit.16b	v11, v7, v21
	bit.16b	v31, v7, v30
	bif.16b	v17, v27, v10
	bif.16b	v18, v26, v19
	bit.16b	v4, v16, v21
	bit.16b	v3, v5, v30
	str	q3, [sp, #19328]
	str	q4, [sp, #19344]
	str	q18, [sp, #19376]
	str	q17, [sp, #19360]
	str	q31, [sp, #19264]
	mov.16b	v31, v22
	str	q11, [sp, #19280]
	ldr	q11, [sp, #1568]                ; 16-byte Folded Reload
	str	q12, [sp, #19312]
	ldr	q12, [sp, #1536]                ; 16-byte Folded Reload
	str	q13, [sp, #19296]
	ldr	q28, [sp, #1408]                ; 16-byte Folded Reload
	mov.16b	v22, v1
	ldr	q13, [sp, #1456]                ; 16-byte Folded Reload
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	ldr	q14, [sp, #1440]                ; 16-byte Folded Reload
	bic.16b	v9, v9, v19
	ldp	q4, q1, [sp, #880]              ; 32-byte Folded Reload
	bic.16b	v3, v4, v10
	bic.16b	v1, v1, v21
	stp	q3, q1, [sp, #880]              ; 32-byte Folded Spill
	ldr	q1, [sp, #912]                  ; 16-byte Folded Reload
	bic.16b	v1, v1, v30
	str	q1, [sp, #912]                  ; 16-byte Folded Spill
	cbz	w1, LBB0_1063
LBB0_172:                               ; %schedule.3
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	mov	w1, #128                        ; =0x80
	dup.2d	v5, x1
	ldp	q6, q1, [sp, #896]              ; 32-byte Folded Reload
	cmgt.2d	v3, v5, v6
	cmgt.2d	v4, v5, v1
	uzp1.4s	v3, v4, v3
	ldr	q7, [sp, #880]                  ; 16-byte Folded Reload
	cmgt.2d	v4, v5, v7
	cmgt.2d	v16, v5, v9
	uzp1.4s	v4, v4, v16
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v21, v20, v3
	shl.8b	v3, v21, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w1, s4
	umaxv.8b	b3, v3
	fmov	w3, s3
	tbz	w3, #0, LBB0_178
; %bb.173:                              ; %schedule.3
                                        ;   in Loop: Header=BB0_8 Depth=3
	cmge.2d	v3, v6, v5
	cmge.2d	v4, v1, v5
	uzp1.4s	v3, v4, v3
	cmge.2d	v4, v7, v5
	cmge.2d	v5, v9, v5
	uzp1.4s	v4, v4, v5
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v10, v20, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_178
; %bb.174:                              ; %varying.divergent126
                                        ;   in Loop: Header=BB0_8 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	str	q24, [sp, #1888]
	str	q12, [sp, #1904]
	and	x1, x1, #0x7
	add	x3, sp, #1888
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #1, #0, ne
	cset	w1, ne
	cmp	w2, #255
	b.ne	LBB0_176
; %bb.175:                              ; %varying.divergent126
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #0, LBB0_176
	b	LBB0_1086
LBB0_176:                               ; %convergence.overflow.resume129
                                        ;   in Loop: Header=BB0_8 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #18, lsl #12            ; =73728
	add	x2, x2, #1520
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s5, w4
	ubfx	w4, w5, #1, #1
	mov.b	v5[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v5[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v5[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v5[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v5[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v5[6], w4
	add	x4, sp, #18, lsl #12            ; =73728
	add	x4, x4, #1512
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v4, w5
	bit.8b	v5, v20, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x2, w3, uxtw]
	bic.8b	v3, v3, v4
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_1086
; %bb.177:                              ; %ready.overflow.resume131
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q23, [sp, #1856]
	str	q11, [sp, #1872]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #1856
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q23, [sp, #1824]
	str	q11, [sp, #1840]
	add	x5, sp, #1824
	str	w4, [x5, x2]
	ldr	q11, [sp, #1840]
	ldr	q23, [sp, #1824]
	str	q24, [sp, #1792]
	str	q12, [sp, #1808]
	add	x4, sp, #1792
	ldr	w4, [x4, x2]
	csinc	w4, w4, wzr, eq
	str	q24, [sp, #1760]
	str	q12, [sp, #1776]
	add	x5, sp, #1760
	str	w4, [x5, x2]
	mov	w2, #7                          ; =0x7
	mov	w4, #4                          ; =0x4
	ldr	q12, [sp, #1776]
	ldr	q24, [sp, #1760]
	b	LBB0_6
LBB0_178:                               ; %varying.coherent127
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w1, #0xff
	b.eq	LBB0_224
; %bb.179:                              ; %varying.coherent.true132
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
	tst	w2, #0xff
	b.eq	LBB0_1063
LBB0_180:                               ; %schedule.4
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q29, [sp, #1472]                ; 16-byte Folded Spill
	str	q11, [sp, #1568]                ; 16-byte Folded Spill
	mov	b3, v20[0]
	mov.b	v3[4], v20[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v6, v3, #0
	ldp	q1, q4, [sp, #896]              ; 32-byte Folded Reload
	and.16b	v18, v6, v4
	mov	b3, v20[2]
	mov.b	v3[4], v20[3]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v29, v3, #0
	and.16b	v30, v29, v1
	mov	b3, v20[4]
	mov.b	v3[4], v20[5]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v17, v3, #0
	ldr	q1, [sp, #880]                  ; 16-byte Folded Reload
	and.16b	v19, v17, v1
	mov	b3, v20[6]
	mov.b	v3[4], v20[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v21, v3, #0
	and.16b	v10, v21, v9
	mov	w2, #32                         ; =0x20
	dup.2d	v3, x2
	and.16b	v4, v6, v3
	mvn.16b	v26, v6
	sub.2d	v11, v4, v26
	and.16b	v4, v29, v3
	mvn.16b	v26, v29
	sub.2d	v26, v4, v26
	and.16b	v4, v17, v3
	mvn.16b	v27, v17
	sub.2d	v4, v4, v27
	and.16b	v3, v21, v3
	mvn.16b	v27, v21
	sub.2d	v3, v3, v27
	mov.d	x2, v3[1]
	mov.d	x3, v10[1]
	sdiv	x3, x3, x2
	fmov	x4, d3
	fmov	x5, d10
	sdiv	x5, x5, x4
	mul	x4, x5, x4
	fmov	d3, x5
	mov.d	v3[1], x3
	mov.d	x5, v4[1]
	mov.d	x6, v19[1]
	sdiv	x6, x6, x5
	fmov	x7, d4
	fmov	x19, d19
	sdiv	x19, x19, x7
	mul	x7, x19, x7
	fmov	d4, x19
	mov.d	v4[1], x6
	mov.d	x19, v26[1]
	mov.d	x20, v30[1]
	sdiv	x20, x20, x19
	fmov	x21, d26
	fmov	x22, d30
	sdiv	x22, x22, x21
	mul	x21, x22, x21
	fmov	d26, x22
	mov.d	v26[1], x20
	mov.d	x22, v11[1]
	mov.d	x23, v18[1]
	fmov	x24, d11
	fmov	x25, d18
	sdiv	x25, x25, x24
	mul	x24, x25, x24
	fmov	d27, x25
	sdiv	x23, x23, x22
	mov.d	v27[1], x23
	mul	x19, x20, x19
	mov.16b	v1, v25
	mov.16b	v25, v31
	fmov	d31, x21
	mov.d	v31[1], x19
	mul	x19, x23, x22
	fmov	d11, x24
	mov.d	v11[1], x19
	mul	x2, x3, x2
	mov.16b	v16, v13
	mov.16b	v7, v0
	mov.16b	v15, v9
	mov.16b	v9, v14
	mov.16b	v0, v22
	mov.16b	v22, v12
	fmov	d12, x4
	mov.d	v12[1], x2
	mul	x2, x6, x5
	fmov	d13, x7
	mov.d	v13[1], x2
	sub.2d	v19, v19, v13
	sub.2d	v10, v10, v12
	sub.2d	v18, v18, v11
	sub.2d	v30, v30, v31
	ldr	q31, [sp, #19760]
	ldr	q11, [sp, #19744]
	ldr	q12, [sp, #19728]
	ldr	q13, [sp, #19712]
	add.2d	v27, v13, v27
	add.2d	v26, v12, v26
	add.2d	v4, v11, v4
	mov	w2, #17                         ; =0x11
	dup.2d	v11, x2
	add.2d	v3, v31, v3
	cmhi.2d	v31, v11, v3
	cmhi.2d	v12, v11, v4
	uzp1.4s	v31, v12, v31
	cmhi.2d	v12, v11, v26
	cmhi.2d	v11, v11, v27
	uzp1.4s	v11, v11, v12
	uzp1.8h	v31, v11, v31
	ldr	q11, [sp, #19424]
	ldr	q12, [sp, #19440]
	ldr	q13, [sp, #19392]
	ldr	q14, [sp, #19408]
	add.2d	v30, v14, v30
	add.2d	v18, v13, v18
	add.2d	v10, v12, v10
	mov.16b	v12, v22
	mov.16b	v22, v0
	mov.16b	v14, v9
	mov.16b	v9, v15
	mov.16b	v0, v7
	mov.16b	v13, v16
	add.2d	v19, v11, v19
	mov.d	x2, v26[1]
	fmov	x3, d26
	add	x3, x3, x3, lsl #6
	fmov	d26, x3
	add	x2, x2, x2, lsl #6
	mov.d	v26[1], x2
	mov.d	x2, v27[1]
	fmov	x3, d27
	add	x3, x3, x3, lsl #6
	fmov	d27, x3
	add	x2, x2, x2, lsl #6
	mov.d	v27[1], x2
	mov.d	x2, v3[1]
	fmov	x3, d3
	add	x3, x3, x3, lsl #6
	fmov	d3, x3
	add	x2, x2, x2, lsl #6
	mov.d	v3[1], x2
	mov.d	x2, v4[1]
	fmov	x3, d4
	add	x3, x3, x3, lsl #6
	fmov	d4, x3
	add	x2, x2, x2, lsl #6
	mov.d	v4[1], x2
	mov	w2, #65                         ; =0x41
	dup.2d	v11, x2
	add.2d	v4, v4, v19
	add.2d	v3, v3, v10
	add.2d	v27, v27, v18
	add.2d	v26, v26, v30
	cmhi.2d	v10, v11, v10
	cmhi.2d	v19, v11, v19
	uzp1.4s	v19, v19, v10
	cmhi.2d	v30, v11, v30
	cmhi.2d	v18, v11, v18
	ldr	q11, [sp, #1568]                ; 16-byte Folded Reload
	uzp1.4s	v18, v18, v30
	uzp1.8h	v18, v18, v19
	and.16b	v18, v31, v18
	xtn.8b	v18, v18
	ldr	q19, [sp, #19232]
	ldr	q30, [sp, #19248]
	ldr	q31, [sp, #19200]
	ldr	q10, [sp, #19216]
	mov.16b	v16, v29
	bsl.16b	v16, v26, v10
	mov.16b	v5, v6
	bsl.16b	v5, v27, v31
	mov.16b	v31, v25
	mov.16b	v25, v1
	ldr	q29, [sp, #1472]                ; 16-byte Folded Reload
	bif.16b	v3, v30, v21
	bif.16b	v4, v19, v17
	str	q4, [sp, #19232]
	str	q3, [sp, #19248]
	str	q5, [sp, #19200]
	str	q16, [sp, #19216]
	and.8b	v21, v20, v18
	shl.8b	v3, v21, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w2, s4
	umaxv.8b	b3, v3
	fmov	w3, s3
	tbz	w3, #0, LBB0_186
; %bb.181:                              ; %schedule.4
                                        ;   in Loop: Header=BB0_8 Depth=3
	bic.8b	v10, v20, v18
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_186
; %bb.182:                              ; %varying.divergent137
                                        ;   in Loop: Header=BB0_8 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	str	q24, [sp, #2048]
	str	q12, [sp, #2064]
	and	x1, x1, #0x7
	add	x3, sp, #2048
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #2, #0, ne
	cset	w1, ne
	cmp	w2, #255
	b.ne	LBB0_184
; %bb.183:                              ; %varying.divergent137
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #0, LBB0_184
	b	LBB0_1086
LBB0_184:                               ; %convergence.overflow.resume140
                                        ;   in Loop: Header=BB0_8 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #18, lsl #12            ; =73728
	add	x2, x2, #1520
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s5, w4
	ubfx	w4, w5, #1, #1
	mov.b	v5[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v5[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v5[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v5[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v5[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v5[6], w4
	add	x4, sp, #18, lsl #12            ; =73728
	add	x4, x4, #1512
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v4, w5
	bit.8b	v5, v20, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x2, w3, uxtw]
	bic.8b	v3, v3, v4
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_1086
; %bb.185:                              ; %ready.overflow.resume145
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q1, [sp, #704]                  ; 16-byte Folded Reload
	dup.4s	v3, v1[0]
	zip2.8b	v4, v10, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q1, [sp, #656]                  ; 16-byte Folded Reload
	bit.16b	v1, v3, v4
	str	q1, [sp, #656]                  ; 16-byte Folded Spill
	zip1.8b	v4, v10, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q1, [sp, #672]                  ; 16-byte Folded Reload
	bit.16b	v1, v3, v4
	str	q1, [sp, #672]                  ; 16-byte Folded Spill
	str	q23, [sp, #2016]
	str	q11, [sp, #2032]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #2016
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q23, [sp, #1984]
	str	q11, [sp, #2000]
	add	x5, sp, #1984
	str	w4, [x5, x2]
	ldr	q11, [sp, #2000]
	ldr	q23, [sp, #1984]
	str	q24, [sp, #1952]
	str	q12, [sp, #1968]
	add	x4, sp, #1952
	ldr	w4, [x4, x2]
	mov	w5, #2                          ; =0x2
	csel	w4, w5, w4, ne
	str	q24, [sp, #1920]
	str	q12, [sp, #1936]
	add	x5, sp, #1920
	str	w4, [x5, x2]
	mov	w2, #6                          ; =0x6
	mov	w4, #5                          ; =0x5
	ldr	q12, [sp, #1936]
	ldr	q24, [sp, #1920]
	b	LBB0_6
LBB0_186:                               ; %varying.coherent138
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_233
; %bb.187:                              ; %varying.coherent.true146
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #0, LBB0_188
	b	LBB0_1063
LBB0_188:                               ; %schedule.5.thread
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q3, [sp, #19248]
	ldr	q4, [sp, #19232]
	ldr	q5, [sp, #19216]
	ldr	q7, [sp, #19200]
	shl.2d	v7, v7, #2
	shl.2d	v5, v5, #2
	shl.2d	v4, v4, #2
	dup.2d	v17, x10
	shl.2d	v3, v3, #2
	add.2d	v16, v17, v3
	add.2d	v18, v17, v4
	add.2d	v19, v17, v5
	add.2d	v21, v17, v7
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w1, s3
	movi.2d	v5, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbz	w1, #0, LBB0_196
; %bb.189:                              ; %cond.load5530
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d21
	ldr	s5, [x2]
	tbnz	w1, #1, LBB0_197
LBB0_190:                               ; %else5540
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #2, LBB0_198
LBB0_191:                               ; %cond.load5542
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d19
	ld1.s	{ v5 }[2], [x2]
	tbnz	w1, #3, LBB0_199
LBB0_192:                               ; %else5552
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #4, LBB0_200
LBB0_193:                               ; %cond.load5554
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d18
	ld1.s	{ v17 }[0], [x2]
	tbnz	w1, #5, LBB0_201
LBB0_194:                               ; %else5564
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #6, LBB0_202
LBB0_195:                               ; %cond.load5566
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d16
	ld1.s	{ v17 }[2], [x2]
	tbnz	w1, #7, LBB0_203
	b	LBB0_204
LBB0_196:                               ; %else5534
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #1, LBB0_190
LBB0_197:                               ; %cond.load5536
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v21[1]
	ld1.s	{ v5 }[1], [x2]
	tbnz	w1, #2, LBB0_191
LBB0_198:                               ; %else5546
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #3, LBB0_192
LBB0_199:                               ; %cond.load5548
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v19[1]
	ld1.s	{ v5 }[3], [x2]
	tbnz	w1, #4, LBB0_193
LBB0_200:                               ; %else5558
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #5, LBB0_194
LBB0_201:                               ; %cond.load5560
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v18[1]
	ld1.s	{ v17 }[1], [x2]
	tbnz	w1, #6, LBB0_195
LBB0_202:                               ; %else5570
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #7, LBB0_204
LBB0_203:                               ; %cond.load5572
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x1, v16[1]
	ld1.s	{ v17 }[3], [x1]
LBB0_204:                               ; %else5576
                                        ;   in Loop: Header=BB0_8 Depth=3
	zip2.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q1, [sp, #656]                  ; 16-byte Folded Reload
	bit.16b	v1, v17, v3
	str	q1, [sp, #656]                  ; 16-byte Folded Spill
	zip1.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q1, [sp, #672]                  ; 16-byte Folded Reload
	bit.16b	v1, v5, v3
	str	q1, [sp, #672]                  ; 16-byte Folded Spill
	mov.16b	v6, v31
	cbnz	w0, LBB0_149
LBB0_205:                               ; %schedule.6.convergence.cascade.exit_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_206:                               ; %convergence.cascade.exit
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1046
; %bb.207:                              ; %convergence.target.6.ready
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q3, [sp, #19312]
	ldr	q4, [sp, #19296]
	ldr	q5, [sp, #19280]
	ldr	q7, [sp, #19264]
	ldr	q16, [sp, #19328]
	ldr	q17, [sp, #19344]
	ldr	q18, [sp, #19360]
	ldr	q19, [sp, #19376]
	ldr	q1, [sp, #912]                  ; 16-byte Folded Reload
	shl.2d	v21, v1, #5
	ldr	q1, [sp, #896]                  ; 16-byte Folded Reload
	shl.2d	v26, v1, #5
	ldr	q1, [sp, #880]                  ; 16-byte Folded Reload
	shl.2d	v27, v1, #5
	shl.2d	v30, v9, #5
	add.2d	v19, v19, v30
	add.2d	v27, v18, v27
	add.2d	v17, v17, v26
	add.2d	v16, v16, v21
	add.2d	v18, v7, v16
	add.2d	v17, v5, v17
	add.2d	v16, v4, v27
	add.2d	v5, v3, v19
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w1, s3
	mov.16b	v31, v6
	tbz	w1, #0, LBB0_215
; %bb.208:                              ; %cond.store5579
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d18
	ldr	q1, [sp, #672]                  ; 16-byte Folded Reload
	str	s1, [x2]
	tbnz	w1, #1, LBB0_216
LBB0_209:                               ; %else5586
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #2, LBB0_217
LBB0_210:                               ; %cond.store5587
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d17
	ldr	q1, [sp, #672]                  ; 16-byte Folded Reload
	st1.s	{ v1 }[2], [x2]
	tbnz	w1, #3, LBB0_218
LBB0_211:                               ; %else5594
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #4, LBB0_219
LBB0_212:                               ; %cond.store5595
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d16
	ldr	q1, [sp, #656]                  ; 16-byte Folded Reload
	str	s1, [x2]
	tbnz	w1, #5, LBB0_220
LBB0_213:                               ; %else5602
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #6, LBB0_221
LBB0_214:                               ; %cond.store5603
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d5
	ldr	q1, [sp, #656]                  ; 16-byte Folded Reload
	st1.s	{ v1 }[2], [x2]
	ldp	q7, q6, [sp, #896]              ; 32-byte Folded Reload
	ldr	q16, [sp, #880]                 ; 16-byte Folded Reload
	tbnz	w1, #7, LBB0_222
	b	LBB0_223
LBB0_215:                               ; %else5582
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #1, LBB0_209
LBB0_216:                               ; %cond.store5583
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v18[1]
	ldr	q1, [sp, #672]                  ; 16-byte Folded Reload
	st1.s	{ v1 }[1], [x2]
	tbnz	w1, #2, LBB0_210
LBB0_217:                               ; %else5590
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #3, LBB0_211
LBB0_218:                               ; %cond.store5591
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v17[1]
	ldr	q1, [sp, #672]                  ; 16-byte Folded Reload
	st1.s	{ v1 }[3], [x2]
	tbnz	w1, #4, LBB0_212
LBB0_219:                               ; %else5598
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #5, LBB0_213
LBB0_220:                               ; %cond.store5599
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v16[1]
	ldr	q1, [sp, #656]                  ; 16-byte Folded Reload
	st1.s	{ v1 }[1], [x2]
	tbnz	w1, #6, LBB0_214
LBB0_221:                               ; %else5606
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldp	q7, q6, [sp, #896]              ; 32-byte Folded Reload
	ldr	q16, [sp, #880]                 ; 16-byte Folded Reload
	tbz	w1, #7, LBB0_223
LBB0_222:                               ; %cond.store5607
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x1, v5[1]
	ldr	q1, [sp, #656]                  ; 16-byte Folded Reload
	st1.s	{ v1 }[3], [x1]
LBB0_223:                               ; %else5610
                                        ;   in Loop: Header=BB0_8 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v20, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v4, v3, #0
	ushll2.4s	v3, v3, #0
	uaddw2.2d	v9, v9, v3
	uaddw.2d	v16, v16, v3
	uaddw2.2d	v7, v7, v4
	stp	q16, q7, [sp, #880]             ; 32-byte Folded Spill
	uaddw.2d	v6, v6, v4
	str	q6, [sp, #912]                  ; 16-byte Folded Spill
	b	LBB0_172
LBB0_224:                               ; %varying.coherent.false133
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1063
LBB0_225:                               ; %schedule.7
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q31, [sp, #1456]                ; 16-byte Folded Spill
	ldr	q6, [sp, #1552]                 ; 16-byte Folded Reload
	str	q28, [sp, #1408]                ; 16-byte Folded Spill
	str	q25, [sp, #1168]                ; 16-byte Folded Spill
	str	q11, [sp, #1568]                ; 16-byte Folded Spill
	str	q23, [sp, #1392]                ; 16-byte Folded Spill
	str	q12, [sp, #1536]                ; 16-byte Folded Spill
	str	q24, [sp, #1376]                ; 16-byte Folded Spill
	str	q6, [sp, #1552]                 ; 16-byte Folded Spill
	cbz	w0, LBB0_230
; %bb.226:                              ; %convergence.cascade161.preheader
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
LBB0_227:                               ; %convergence.cascade161
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_3 Depth=2
                                        ;       Parent Loop BB0_8 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w2, s4
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	str	q24, [sp, #16288]
	str	q12, [sp, #16304]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #3, lsl #12             ; =12288
	add	x6, x6, #4000
	ldr	w6, [x6, x2]
	cmp	w6, #1
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #1520
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s5, w19
	ubfx	w19, w20, #1, #1
	mov.b	v5[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v5[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v5[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v5[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v5[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v5[6], w19
	add	x19, sp, #18, lsl #12           ; =73728
	add	x19, x19, #1512
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s3, w21
	ubfx	w21, w20, #1, #1
	mov.b	v3[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v3[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v3[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v3[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v3[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v3[6], w21
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	orr.8b	v4, v20, v3
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	and.8b	v7, v1, v5
	eor.8b	v7, v7, v4
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v4, v7
	dup.8b	v17, w7
	bit.8b	v3, v16, v17
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x19, w3, sxtw]
	bic.8b	v3, v5, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v4, v5, v4
	str	q23, [sp, #16256]
	str	q11, [sp, #16272]
	add	x3, sp, #3, lsl #12             ; =12288
	add	x3, x3, #3968
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v20, v4, v3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_231
; %bb.228:                              ; %convergence.cascade161
                                        ;   in Loop: Header=BB0_227 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_231
; %bb.229:                              ; %convergence.cascade161
                                        ;   in Loop: Header=BB0_227 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_227
	b	LBB0_231
LBB0_230:                               ; %schedule.7.convergence.cascade.exit162_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_231:                               ; %convergence.cascade.exit162
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1047
; %bb.232:                              ; %convergence.target.7.ready
                                        ;   in Loop: Header=BB0_8 Depth=3
	rbit	w1, w2
	clz	w1, w1
	ldr	q16, [sp, #19168]
	ldr	q3, [sp, #19184]
	ldr	q4, [sp, #19136]
	ldr	q7, [sp, #19152]
	ldr	q17, [sp, #19104]
	ldr	q5, [sp, #19120]
	ldr	q18, [sp, #19072]
	ldr	q19, [sp, #19088]
	mov	b21, v20[2]
	mov.b	v21[4], v20[3]
	ushll.2d	v21, v21, #0
	shl.2d	v21, v21, #63
	cmlt.2d	v21, v21, #0
	ldr	q27, [sp, #336]                 ; 16-byte Folded Reload
	mov.16b	v1, v21
	bsl.16b	v1, v27, v19
	str	q1, [sp, #1504]                 ; 16-byte Folded Spill
	mov	b26, v20[0]
	mov.b	v26[4], v20[1]
	ushll.2d	v26, v26, #0
	shl.2d	v26, v26, #63
	cmlt.2d	v10, v26, #0
	mov	b26, v20[6]
	mov.b	v26[4], v20[7]
	mov.16b	v1, v10
	bsl.16b	v1, v27, v18
	str	q1, [sp, #1488]                 ; 16-byte Folded Spill
	ushll.2d	v26, v26, #0
	shl.2d	v26, v26, #63
	cmlt.2d	v15, v26, #0
	mov.16b	v26, v15
	bsl.16b	v26, v27, v5
	mov	b5, v20[4]
	mov.b	v5[4], v20[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	mov.16b	v19, v0
	cmlt.2d	v0, v5, #0
	mov.16b	v5, v0
	bsl.16b	v5, v27, v17
Lloh42:
	adrp	x2, lCPI0_20@PAGE
Lloh43:
	ldr	q27, [x2, lCPI0_20@PAGEOFF]
	mov.16b	v25, v21
	bsl.16b	v25, v27, v7
Lloh44:
	adrp	x2, lCPI0_21@PAGE
Lloh45:
	ldr	q31, [x2, lCPI0_21@PAGEOFF]
	mov.16b	v6, v10
	bsl.16b	v6, v31, v4
Lloh46:
	adrp	x2, lCPI0_22@PAGE
Lloh47:
	ldr	q8, [x2, lCPI0_22@PAGEOFF]
	bit.16b	v3, v8, v15
Lloh48:
	adrp	x2, lCPI0_23@PAGE
	ldr	q30, [sp, #1424]                ; 16-byte Folded Reload
	mov.16b	v2, v9
Lloh49:
	ldr	q9, [x2, lCPI0_23@PAGEOFF]
	bit.16b	v16, v9, v0
	str	q16, [sp, #19168]
	str	q3, [sp, #19184]
	str	q6, [sp, #19136]
	str	q25, [sp, #19152]
	str	q5, [sp, #19104]
	str	q26, [sp, #19120]
	ldr	q1, [sp, #1488]                 ; 16-byte Folded Reload
	str	q1, [sp, #19072]
	ldr	q1, [sp, #1504]                 ; 16-byte Folded Reload
	str	q1, [sp, #19088]
	str	q8, [sp, #14256]
	str	q9, [sp, #14240]
	mov.16b	v9, v2
	ldr	q23, [sp, #1392]                ; 16-byte Folded Reload
	ldr	q5, [sp, #1248]                 ; 16-byte Folded Reload
	ldr	q6, [sp, #1040]                 ; 16-byte Folded Reload
	ldr	q24, [sp, #1376]                ; 16-byte Folded Reload
	ldr	q25, [sp, #1168]                ; 16-byte Folded Reload
	ldr	q12, [sp, #1536]                ; 16-byte Folded Reload
	ldr	q11, [sp, #1568]                ; 16-byte Folded Reload
	mov.16b	v8, v19
	ldr	q28, [sp, #1408]                ; 16-byte Folded Reload
	ldr	d2, [sp, #696]                  ; 8-byte Folded Reload
	str	q27, [sp, #14224]
	str	q31, [sp, #14208]
	lsl	w2, w1, #3
	and	x1, x2, #0x38
	add	x3, sp, #3, lsl #12             ; =12288
	add	x3, x3, #1920
	ldr	x4, [x3, x1]
	and	x2, x2, #0xf8
	add	x3, sp, #16, lsl #12            ; =65536
	add	x3, x3, #3432
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4, #32]
	ldp	q7, q16, [x4]
	orr.16b	v16, v21, v16
	orr.16b	v7, v10, v7
	orr.16b	v4, v15, v4
	orr.16b	v3, v0, v3
	stp	q3, q4, [x4, #32]
	stp	q7, q16, [x4]
Lloh50:
	adrp	x4, lCPI0_24@PAGE
Lloh51:
	ldr	q3, [x4, lCPI0_24@PAGEOFF]
Lloh52:
	adrp	x4, lCPI0_25@PAGE
Lloh53:
	ldr	q4, [x4, lCPI0_25@PAGEOFF]
	str	q3, [sp, #14320]
	str	q4, [sp, #14304]
Lloh54:
	adrp	x4, lCPI0_26@PAGE
Lloh55:
	ldr	q3, [x4, lCPI0_26@PAGEOFF]
Lloh56:
	adrp	x4, lCPI0_27@PAGE
Lloh57:
	ldr	q4, [x4, lCPI0_27@PAGEOFF]
	str	q3, [sp, #14288]
	str	q4, [sp, #14272]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #1984
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	bic.16b	v16, v16, v0
	bic.16b	v4, v4, v21
	bic.16b	v3, v3, v10
	bic.16b	v7, v7, v15
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh58:
	adrp	x4, lCPI0_28@PAGE
Lloh59:
	ldr	q3, [x4, lCPI0_28@PAGEOFF]
Lloh60:
	adrp	x4, lCPI0_29@PAGE
Lloh61:
	ldr	q4, [x4, lCPI0_29@PAGEOFF]
	str	q3, [sp, #14384]
	str	q4, [sp, #14368]
Lloh62:
	adrp	x4, lCPI0_30@PAGE
Lloh63:
	ldr	q3, [x4, lCPI0_30@PAGEOFF]
Lloh64:
	adrp	x4, lCPI0_31@PAGE
Lloh65:
	ldr	q4, [x4, lCPI0_31@PAGEOFF]
	str	q3, [sp, #14352]
	str	q4, [sp, #14336]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #2048
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	bic.16b	v16, v16, v0
	sub.2d	v16, v16, v0
	bic.16b	v4, v4, v21
	sub.2d	v4, v4, v21
	bic.16b	v3, v3, v10
	sub.2d	v3, v3, v10
	bic.16b	v7, v7, v15
	sub.2d	v7, v7, v15
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh66:
	adrp	x4, lCPI0_32@PAGE
Lloh67:
	ldr	q3, [x4, lCPI0_32@PAGEOFF]
Lloh68:
	adrp	x4, lCPI0_33@PAGE
Lloh69:
	ldr	q4, [x4, lCPI0_33@PAGEOFF]
	str	q3, [sp, #14448]
	str	q4, [sp, #14432]
Lloh70:
	adrp	x4, lCPI0_34@PAGE
Lloh71:
	ldr	q3, [x4, lCPI0_34@PAGEOFF]
Lloh72:
	adrp	x4, lCPI0_35@PAGE
Lloh73:
	ldr	q4, [x4, lCPI0_35@PAGEOFF]
	str	q3, [sp, #14416]
	str	q4, [sp, #14400]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #2112
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #2                          ; =0x2
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v0
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v10
	bif.16b	v7, v16, v15
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh74:
	adrp	x4, lCPI0_36@PAGE
Lloh75:
	ldr	q3, [x4, lCPI0_36@PAGEOFF]
Lloh76:
	adrp	x4, lCPI0_37@PAGE
Lloh77:
	ldr	q4, [x4, lCPI0_37@PAGEOFF]
	str	q3, [sp, #14512]
	str	q4, [sp, #14496]
Lloh78:
	adrp	x4, lCPI0_38@PAGE
Lloh79:
	ldr	q3, [x4, lCPI0_38@PAGEOFF]
Lloh80:
	adrp	x4, lCPI0_39@PAGE
Lloh81:
	ldr	q4, [x4, lCPI0_39@PAGEOFF]
	str	q3, [sp, #14480]
	str	q4, [sp, #14464]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #2176
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #3                          ; =0x3
	dup.2d	v17, x5
	bit.16b	v16, v17, v0
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v10
	bit.16b	v7, v17, v15
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh82:
	adrp	x4, lCPI0_40@PAGE
Lloh83:
	ldr	q3, [x4, lCPI0_40@PAGEOFF]
Lloh84:
	adrp	x4, lCPI0_41@PAGE
Lloh85:
	ldr	q4, [x4, lCPI0_41@PAGEOFF]
	str	q3, [sp, #14576]
	str	q4, [sp, #14560]
Lloh86:
	adrp	x4, lCPI0_42@PAGE
Lloh87:
	ldr	q3, [x4, lCPI0_42@PAGEOFF]
Lloh88:
	adrp	x4, lCPI0_43@PAGE
Lloh89:
	ldr	q4, [x4, lCPI0_43@PAGEOFF]
	str	q3, [sp, #14544]
	str	q4, [sp, #14528]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #2240
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #4                          ; =0x4
	dup.2d	v17, x5
	bit.16b	v16, v17, v0
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v10
	bit.16b	v7, v17, v15
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh90:
	adrp	x4, lCPI0_44@PAGE
Lloh91:
	ldr	q3, [x4, lCPI0_44@PAGEOFF]
Lloh92:
	adrp	x4, lCPI0_45@PAGE
Lloh93:
	ldr	q4, [x4, lCPI0_45@PAGEOFF]
	str	q3, [sp, #14640]
	str	q4, [sp, #14624]
Lloh94:
	adrp	x4, lCPI0_46@PAGE
Lloh95:
	ldr	q3, [x4, lCPI0_46@PAGEOFF]
Lloh96:
	adrp	x4, lCPI0_47@PAGE
Lloh97:
	ldr	q4, [x4, lCPI0_47@PAGEOFF]
	str	q3, [sp, #14608]
	str	q4, [sp, #14592]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #2304
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #5                          ; =0x5
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v0
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v10
	bif.16b	v7, v16, v15
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh98:
	adrp	x4, lCPI0_48@PAGE
Lloh99:
	ldr	q3, [x4, lCPI0_48@PAGEOFF]
Lloh100:
	adrp	x4, lCPI0_49@PAGE
Lloh101:
	ldr	q4, [x4, lCPI0_49@PAGEOFF]
	str	q3, [sp, #14704]
	str	q4, [sp, #14688]
Lloh102:
	adrp	x4, lCPI0_50@PAGE
Lloh103:
	ldr	q3, [x4, lCPI0_50@PAGEOFF]
Lloh104:
	adrp	x4, lCPI0_51@PAGE
Lloh105:
	ldr	q4, [x4, lCPI0_51@PAGEOFF]
	str	q3, [sp, #14672]
	str	q4, [sp, #14656]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #2368
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #6                          ; =0x6
	dup.2d	v17, x5
	bit.16b	v16, v17, v0
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v10
	bit.16b	v7, v17, v15
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh106:
	adrp	x4, lCPI0_52@PAGE
Lloh107:
	ldr	q3, [x4, lCPI0_52@PAGEOFF]
Lloh108:
	adrp	x4, lCPI0_53@PAGE
Lloh109:
	ldr	q4, [x4, lCPI0_53@PAGEOFF]
	str	q3, [sp, #14768]
	str	q4, [sp, #14752]
Lloh110:
	adrp	x4, lCPI0_54@PAGE
Lloh111:
	ldr	q3, [x4, lCPI0_54@PAGEOFF]
Lloh112:
	adrp	x4, lCPI0_55@PAGE
Lloh113:
	ldr	q4, [x4, lCPI0_55@PAGEOFF]
	str	q3, [sp, #14736]
	str	q4, [sp, #14720]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #2432
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #7                          ; =0x7
	dup.2d	v17, x5
	bit.16b	v16, v17, v0
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v10
	bit.16b	v7, v17, v15
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh114:
	adrp	x4, lCPI0_56@PAGE
Lloh115:
	ldr	q3, [x4, lCPI0_56@PAGEOFF]
Lloh116:
	adrp	x4, lCPI0_57@PAGE
Lloh117:
	ldr	q4, [x4, lCPI0_57@PAGEOFF]
	str	q3, [sp, #14832]
	str	q4, [sp, #14816]
Lloh118:
	adrp	x4, lCPI0_58@PAGE
Lloh119:
	ldr	q3, [x4, lCPI0_58@PAGEOFF]
Lloh120:
	adrp	x4, lCPI0_59@PAGE
Lloh121:
	ldr	q4, [x4, lCPI0_59@PAGEOFF]
	str	q3, [sp, #14800]
	str	q4, [sp, #14784]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #2496
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #8                          ; =0x8
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v0
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v10
	bif.16b	v7, v16, v15
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh122:
	adrp	x4, lCPI0_60@PAGE
Lloh123:
	ldr	q3, [x4, lCPI0_60@PAGEOFF]
Lloh124:
	adrp	x4, lCPI0_61@PAGE
Lloh125:
	ldr	q4, [x4, lCPI0_61@PAGEOFF]
	str	q3, [sp, #14896]
	str	q4, [sp, #14880]
Lloh126:
	adrp	x4, lCPI0_62@PAGE
Lloh127:
	ldr	q3, [x4, lCPI0_62@PAGEOFF]
Lloh128:
	adrp	x4, lCPI0_63@PAGE
Lloh129:
	ldr	q4, [x4, lCPI0_63@PAGEOFF]
	str	q3, [sp, #14864]
	str	q4, [sp, #14848]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #2560
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #9                          ; =0x9
	dup.2d	v17, x5
	bit.16b	v16, v17, v0
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v10
	bit.16b	v7, v17, v15
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh130:
	adrp	x4, lCPI0_64@PAGE
Lloh131:
	ldr	q3, [x4, lCPI0_64@PAGEOFF]
Lloh132:
	adrp	x4, lCPI0_65@PAGE
Lloh133:
	ldr	q4, [x4, lCPI0_65@PAGEOFF]
	str	q3, [sp, #14960]
	str	q4, [sp, #14944]
Lloh134:
	adrp	x4, lCPI0_66@PAGE
Lloh135:
	ldr	q3, [x4, lCPI0_66@PAGEOFF]
Lloh136:
	adrp	x4, lCPI0_67@PAGE
Lloh137:
	ldr	q4, [x4, lCPI0_67@PAGEOFF]
	str	q3, [sp, #14928]
	str	q4, [sp, #14912]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #2624
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #10                         ; =0xa
	dup.2d	v17, x5
	bit.16b	v16, v17, v0
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v10
	bit.16b	v7, v17, v15
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh138:
	adrp	x4, lCPI0_68@PAGE
Lloh139:
	ldr	q3, [x4, lCPI0_68@PAGEOFF]
Lloh140:
	adrp	x4, lCPI0_69@PAGE
Lloh141:
	ldr	q4, [x4, lCPI0_69@PAGEOFF]
	str	q3, [sp, #15024]
	str	q4, [sp, #15008]
Lloh142:
	adrp	x4, lCPI0_70@PAGE
Lloh143:
	ldr	q3, [x4, lCPI0_70@PAGEOFF]
Lloh144:
	adrp	x4, lCPI0_71@PAGE
Lloh145:
	ldr	q4, [x4, lCPI0_71@PAGEOFF]
	str	q3, [sp, #14992]
	str	q4, [sp, #14976]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #2688
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #11                         ; =0xb
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v0
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v10
	bif.16b	v7, v16, v15
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh146:
	adrp	x4, lCPI0_72@PAGE
Lloh147:
	ldr	q3, [x4, lCPI0_72@PAGEOFF]
Lloh148:
	adrp	x4, lCPI0_73@PAGE
Lloh149:
	ldr	q4, [x4, lCPI0_73@PAGEOFF]
	str	q3, [sp, #15088]
	str	q4, [sp, #15072]
Lloh150:
	adrp	x4, lCPI0_74@PAGE
Lloh151:
	ldr	q3, [x4, lCPI0_74@PAGEOFF]
Lloh152:
	adrp	x4, lCPI0_75@PAGE
Lloh153:
	ldr	q4, [x4, lCPI0_75@PAGEOFF]
	str	q3, [sp, #15056]
	str	q4, [sp, #15040]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #2752
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #12                         ; =0xc
	dup.2d	v17, x5
	bit.16b	v16, v17, v0
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v10
	bit.16b	v7, v17, v15
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh154:
	adrp	x4, lCPI0_76@PAGE
Lloh155:
	ldr	q3, [x4, lCPI0_76@PAGEOFF]
Lloh156:
	adrp	x4, lCPI0_77@PAGE
Lloh157:
	ldr	q4, [x4, lCPI0_77@PAGEOFF]
	str	q3, [sp, #15152]
	str	q4, [sp, #15136]
Lloh158:
	adrp	x4, lCPI0_78@PAGE
Lloh159:
	ldr	q3, [x4, lCPI0_78@PAGEOFF]
Lloh160:
	adrp	x4, lCPI0_79@PAGE
Lloh161:
	ldr	q4, [x4, lCPI0_79@PAGEOFF]
	str	q3, [sp, #15120]
	str	q4, [sp, #15104]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #2816
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #13                         ; =0xd
	dup.2d	v17, x5
	bit.16b	v16, v17, v0
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v10
	bit.16b	v7, v17, v15
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh162:
	adrp	x4, lCPI0_80@PAGE
Lloh163:
	ldr	q3, [x4, lCPI0_80@PAGEOFF]
Lloh164:
	adrp	x4, lCPI0_81@PAGE
Lloh165:
	ldr	q4, [x4, lCPI0_81@PAGEOFF]
	str	q3, [sp, #15216]
	str	q4, [sp, #15200]
Lloh166:
	adrp	x4, lCPI0_82@PAGE
Lloh167:
	ldr	q3, [x4, lCPI0_82@PAGEOFF]
Lloh168:
	adrp	x4, lCPI0_83@PAGE
Lloh169:
	ldr	q4, [x4, lCPI0_83@PAGEOFF]
	str	q3, [sp, #15184]
	str	q4, [sp, #15168]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #2880
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #14                         ; =0xe
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v0
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v10
	bif.16b	v7, v16, v15
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh170:
	adrp	x4, lCPI0_84@PAGE
Lloh171:
	ldr	q3, [x4, lCPI0_84@PAGEOFF]
Lloh172:
	adrp	x4, lCPI0_85@PAGE
Lloh173:
	ldr	q4, [x4, lCPI0_85@PAGEOFF]
	str	q3, [sp, #15280]
	str	q4, [sp, #15264]
Lloh174:
	adrp	x4, lCPI0_86@PAGE
Lloh175:
	ldr	q3, [x4, lCPI0_86@PAGEOFF]
Lloh176:
	adrp	x4, lCPI0_87@PAGE
Lloh177:
	ldr	q4, [x4, lCPI0_87@PAGEOFF]
	str	q3, [sp, #15248]
	str	q4, [sp, #15232]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #2944
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #15                         ; =0xf
	dup.2d	v17, x5
	bit.16b	v16, v17, v0
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v10
	bit.16b	v7, v17, v15
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh178:
	adrp	x4, lCPI0_88@PAGE
Lloh179:
	ldr	q3, [x4, lCPI0_88@PAGEOFF]
Lloh180:
	adrp	x4, lCPI0_89@PAGE
Lloh181:
	ldr	q4, [x4, lCPI0_89@PAGEOFF]
	str	q3, [sp, #15344]
	str	q4, [sp, #15328]
Lloh182:
	adrp	x4, lCPI0_90@PAGE
Lloh183:
	ldr	q3, [x4, lCPI0_90@PAGEOFF]
Lloh184:
	adrp	x4, lCPI0_91@PAGE
Lloh185:
	ldr	q4, [x4, lCPI0_91@PAGEOFF]
	str	q3, [sp, #15312]
	str	q4, [sp, #15296]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #3008
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #16                         ; =0x10
	dup.2d	v17, x5
	bit.16b	v16, v17, v0
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v10
	bit.16b	v7, v17, v15
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh186:
	adrp	x4, lCPI0_92@PAGE
Lloh187:
	ldr	q3, [x4, lCPI0_92@PAGEOFF]
Lloh188:
	adrp	x4, lCPI0_93@PAGE
Lloh189:
	ldr	q4, [x4, lCPI0_93@PAGEOFF]
	str	q3, [sp, #15408]
	str	q4, [sp, #15392]
Lloh190:
	adrp	x4, lCPI0_94@PAGE
Lloh191:
	ldr	q3, [x4, lCPI0_94@PAGEOFF]
Lloh192:
	adrp	x4, lCPI0_95@PAGE
Lloh193:
	ldr	q4, [x4, lCPI0_95@PAGEOFF]
	str	q3, [sp, #15376]
	str	q4, [sp, #15360]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #3072
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #17                         ; =0x11
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v0
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v10
	bif.16b	v7, v16, v15
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh194:
	adrp	x4, lCPI0_96@PAGE
Lloh195:
	ldr	q3, [x4, lCPI0_96@PAGEOFF]
Lloh196:
	adrp	x4, lCPI0_97@PAGE
Lloh197:
	ldr	q4, [x4, lCPI0_97@PAGEOFF]
	str	q3, [sp, #15472]
	str	q4, [sp, #15456]
Lloh198:
	adrp	x4, lCPI0_98@PAGE
Lloh199:
	ldr	q3, [x4, lCPI0_98@PAGEOFF]
Lloh200:
	adrp	x4, lCPI0_99@PAGE
Lloh201:
	ldr	q4, [x4, lCPI0_99@PAGEOFF]
	str	q3, [sp, #15440]
	str	q4, [sp, #15424]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #3136
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #18                         ; =0x12
	dup.2d	v17, x5
	bit.16b	v16, v17, v0
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v10
	bit.16b	v7, v17, v15
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh202:
	adrp	x4, lCPI0_100@PAGE
Lloh203:
	ldr	q3, [x4, lCPI0_100@PAGEOFF]
Lloh204:
	adrp	x4, lCPI0_101@PAGE
Lloh205:
	ldr	q4, [x4, lCPI0_101@PAGEOFF]
	str	q3, [sp, #15536]
	str	q4, [sp, #15520]
Lloh206:
	adrp	x4, lCPI0_102@PAGE
Lloh207:
	ldr	q3, [x4, lCPI0_102@PAGEOFF]
Lloh208:
	adrp	x4, lCPI0_103@PAGE
Lloh209:
	ldr	q4, [x4, lCPI0_103@PAGEOFF]
	str	q3, [sp, #15504]
	str	q4, [sp, #15488]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #3200
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #19                         ; =0x13
	dup.2d	v17, x5
	bit.16b	v16, v17, v0
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v10
	bit.16b	v7, v17, v15
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh210:
	adrp	x4, lCPI0_104@PAGE
Lloh211:
	ldr	q3, [x4, lCPI0_104@PAGEOFF]
Lloh212:
	adrp	x4, lCPI0_105@PAGE
Lloh213:
	ldr	q4, [x4, lCPI0_105@PAGEOFF]
	str	q3, [sp, #15600]
	str	q4, [sp, #15584]
Lloh214:
	adrp	x4, lCPI0_106@PAGE
Lloh215:
	ldr	q3, [x4, lCPI0_106@PAGEOFF]
Lloh216:
	adrp	x4, lCPI0_107@PAGE
Lloh217:
	ldr	q4, [x4, lCPI0_107@PAGEOFF]
	str	q3, [sp, #15568]
	str	q4, [sp, #15552]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #3264
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #20                         ; =0x14
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v0
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v10
	bif.16b	v7, v16, v15
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh218:
	adrp	x4, lCPI0_108@PAGE
Lloh219:
	ldr	q3, [x4, lCPI0_108@PAGEOFF]
Lloh220:
	adrp	x4, lCPI0_109@PAGE
Lloh221:
	ldr	q4, [x4, lCPI0_109@PAGEOFF]
	str	q3, [sp, #15664]
	str	q4, [sp, #15648]
Lloh222:
	adrp	x4, lCPI0_110@PAGE
Lloh223:
	ldr	q3, [x4, lCPI0_110@PAGEOFF]
Lloh224:
	adrp	x4, lCPI0_111@PAGE
Lloh225:
	ldr	q4, [x4, lCPI0_111@PAGEOFF]
	str	q3, [sp, #15632]
	str	q4, [sp, #15616]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #3328
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #21                         ; =0x15
	dup.2d	v17, x5
	bit.16b	v16, v17, v0
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v10
	bit.16b	v7, v17, v15
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh226:
	adrp	x4, lCPI0_112@PAGE
Lloh227:
	ldr	q3, [x4, lCPI0_112@PAGEOFF]
Lloh228:
	adrp	x4, lCPI0_113@PAGE
Lloh229:
	ldr	q4, [x4, lCPI0_113@PAGEOFF]
	str	q3, [sp, #15728]
	str	q4, [sp, #15712]
Lloh230:
	adrp	x4, lCPI0_114@PAGE
Lloh231:
	ldr	q3, [x4, lCPI0_114@PAGEOFF]
Lloh232:
	adrp	x4, lCPI0_115@PAGE
Lloh233:
	ldr	q4, [x4, lCPI0_115@PAGEOFF]
	str	q3, [sp, #15696]
	str	q4, [sp, #15680]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #3392
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #22                         ; =0x16
	dup.2d	v17, x5
	bit.16b	v16, v17, v0
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v10
	bit.16b	v7, v17, v15
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh234:
	adrp	x4, lCPI0_116@PAGE
Lloh235:
	ldr	q3, [x4, lCPI0_116@PAGEOFF]
Lloh236:
	adrp	x4, lCPI0_117@PAGE
Lloh237:
	ldr	q4, [x4, lCPI0_117@PAGEOFF]
	str	q3, [sp, #15792]
	str	q4, [sp, #15776]
Lloh238:
	adrp	x4, lCPI0_118@PAGE
Lloh239:
	ldr	q3, [x4, lCPI0_118@PAGEOFF]
Lloh240:
	adrp	x4, lCPI0_119@PAGE
Lloh241:
	ldr	q4, [x4, lCPI0_119@PAGEOFF]
	str	q3, [sp, #15760]
	str	q4, [sp, #15744]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #3456
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #23                         ; =0x17
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v0
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v10
	bif.16b	v7, v16, v15
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh242:
	adrp	x4, lCPI0_120@PAGE
Lloh243:
	ldr	q3, [x4, lCPI0_120@PAGEOFF]
Lloh244:
	adrp	x4, lCPI0_121@PAGE
Lloh245:
	ldr	q4, [x4, lCPI0_121@PAGEOFF]
	str	q3, [sp, #15856]
	str	q4, [sp, #15840]
Lloh246:
	adrp	x4, lCPI0_122@PAGE
Lloh247:
	ldr	q3, [x4, lCPI0_122@PAGEOFF]
Lloh248:
	adrp	x4, lCPI0_123@PAGE
Lloh249:
	ldr	q4, [x4, lCPI0_123@PAGEOFF]
	str	q3, [sp, #15824]
	str	q4, [sp, #15808]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #3520
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #24                         ; =0x18
	dup.2d	v17, x5
	bit.16b	v16, v17, v0
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v10
	bit.16b	v7, v17, v15
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh250:
	adrp	x4, lCPI0_124@PAGE
Lloh251:
	ldr	q3, [x4, lCPI0_124@PAGEOFF]
Lloh252:
	adrp	x4, lCPI0_125@PAGE
Lloh253:
	ldr	q4, [x4, lCPI0_125@PAGEOFF]
	str	q3, [sp, #15920]
	str	q4, [sp, #15904]
Lloh254:
	adrp	x4, lCPI0_126@PAGE
Lloh255:
	ldr	q3, [x4, lCPI0_126@PAGEOFF]
Lloh256:
	adrp	x4, lCPI0_127@PAGE
Lloh257:
	ldr	q4, [x4, lCPI0_127@PAGEOFF]
	str	q3, [sp, #15888]
	str	q4, [sp, #15872]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #3584
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #25                         ; =0x19
	dup.2d	v17, x5
	bit.16b	v16, v17, v0
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v10
	bit.16b	v7, v17, v15
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh258:
	adrp	x4, lCPI0_128@PAGE
Lloh259:
	ldr	q3, [x4, lCPI0_128@PAGEOFF]
Lloh260:
	adrp	x4, lCPI0_129@PAGE
Lloh261:
	ldr	q4, [x4, lCPI0_129@PAGEOFF]
	str	q3, [sp, #15984]
	str	q4, [sp, #15968]
Lloh262:
	adrp	x4, lCPI0_130@PAGE
Lloh263:
	ldr	q3, [x4, lCPI0_130@PAGEOFF]
Lloh264:
	adrp	x4, lCPI0_131@PAGE
Lloh265:
	ldr	q4, [x4, lCPI0_131@PAGEOFF]
	str	q3, [sp, #15952]
	str	q4, [sp, #15936]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #3648
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #26                         ; =0x1a
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v0
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v10
	bif.16b	v7, v16, v15
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh266:
	adrp	x4, lCPI0_132@PAGE
Lloh267:
	ldr	q3, [x4, lCPI0_132@PAGEOFF]
Lloh268:
	adrp	x4, lCPI0_133@PAGE
Lloh269:
	ldr	q4, [x4, lCPI0_133@PAGEOFF]
	str	q3, [sp, #16048]
	str	q4, [sp, #16032]
Lloh270:
	adrp	x4, lCPI0_134@PAGE
Lloh271:
	ldr	q3, [x4, lCPI0_134@PAGEOFF]
Lloh272:
	adrp	x4, lCPI0_135@PAGE
Lloh273:
	ldr	q4, [x4, lCPI0_135@PAGEOFF]
	str	q3, [sp, #16016]
	str	q4, [sp, #16000]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #3712
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #27                         ; =0x1b
	dup.2d	v17, x5
	bit.16b	v16, v17, v0
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v10
	bit.16b	v7, v17, v15
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh274:
	adrp	x4, lCPI0_136@PAGE
Lloh275:
	ldr	q3, [x4, lCPI0_136@PAGEOFF]
Lloh276:
	adrp	x4, lCPI0_137@PAGE
Lloh277:
	ldr	q4, [x4, lCPI0_137@PAGEOFF]
	str	q3, [sp, #16112]
	str	q4, [sp, #16096]
Lloh278:
	adrp	x4, lCPI0_138@PAGE
Lloh279:
	ldr	q3, [x4, lCPI0_138@PAGEOFF]
Lloh280:
	adrp	x4, lCPI0_139@PAGE
Lloh281:
	ldr	q4, [x4, lCPI0_139@PAGEOFF]
	str	q3, [sp, #16080]
	str	q4, [sp, #16064]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #3776
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #28                         ; =0x1c
	dup.2d	v17, x5
	bit.16b	v16, v17, v0
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v10
	bit.16b	v7, v17, v15
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh282:
	adrp	x4, lCPI0_140@PAGE
Lloh283:
	ldr	q3, [x4, lCPI0_140@PAGEOFF]
Lloh284:
	adrp	x4, lCPI0_141@PAGE
Lloh285:
	ldr	q4, [x4, lCPI0_141@PAGEOFF]
	str	q3, [sp, #16176]
	str	q4, [sp, #16160]
Lloh286:
	adrp	x4, lCPI0_142@PAGE
Lloh287:
	ldr	q3, [x4, lCPI0_142@PAGEOFF]
Lloh288:
	adrp	x4, lCPI0_143@PAGE
Lloh289:
	ldr	q4, [x4, lCPI0_143@PAGEOFF]
	str	q3, [sp, #16144]
	str	q4, [sp, #16128]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #3840
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #29                         ; =0x1d
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v0
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v10
	bif.16b	v7, v16, v15
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh290:
	adrp	x4, lCPI0_144@PAGE
Lloh291:
	ldr	q3, [x4, lCPI0_144@PAGEOFF]
Lloh292:
	adrp	x4, lCPI0_145@PAGE
Lloh293:
	ldr	q4, [x4, lCPI0_145@PAGEOFF]
	str	q3, [sp, #16240]
	str	q4, [sp, #16224]
Lloh294:
	adrp	x4, lCPI0_146@PAGE
Lloh295:
	ldr	q3, [x4, lCPI0_146@PAGEOFF]
Lloh296:
	adrp	x4, lCPI0_147@PAGE
Lloh297:
	ldr	q4, [x4, lCPI0_147@PAGEOFF]
	str	q3, [sp, #16208]
	str	q4, [sp, #16192]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #3904
	ldr	x1, [x4, x1]
	sub	x1, x1, x2
	add	x1, x3, x1
	ldp	q3, q4, [x1]
	ldp	q16, q7, [x1, #32]
	mov	w2, #30                         ; =0x1e
	dup.2d	v17, x2
	bit.16b	v16, v17, v0
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v10
	bit.16b	v7, v17, v15
	stp	q3, q4, [x1]
	stp	q16, q7, [x1, #32]
	ldr	q3, [sp, #19040]
	ldr	q4, [sp, #19056]
	ldr	q7, [sp, #19008]
	ldr	q16, [sp, #19024]
	ldr	q17, [sp, #18976]
	ldr	q18, [sp, #18992]
	ldr	q19, [sp, #18944]
	ldr	q26, [sp, #18960]
	ldr	q27, [sp, #320]                 ; 16-byte Folded Reload
	bit.16b	v26, v27, v21
	bit.16b	v19, v27, v10
	bit.16b	v18, v27, v15
	bit.16b	v17, v27, v0
Lloh298:
	adrp	x1, lCPI0_17@PAGE
Lloh299:
	ldr	q27, [x1, lCPI0_17@PAGEOFF]
	bit.16b	v16, v27, v21
Lloh300:
	adrp	x1, lCPI0_16@PAGE
Lloh301:
	ldr	q27, [x1, lCPI0_16@PAGEOFF]
	bit.16b	v7, v27, v10
Lloh302:
	adrp	x1, lCPI0_19@PAGE
Lloh303:
	ldr	q27, [x1, lCPI0_19@PAGEOFF]
	bit.16b	v4, v27, v15
Lloh304:
	adrp	x1, lCPI0_18@PAGE
Lloh305:
	ldr	q27, [x1, lCPI0_18@PAGEOFF]
	bit.16b	v3, v27, v0
	str	q3, [sp, #19040]
	str	q4, [sp, #19056]
	str	q7, [sp, #19008]
	str	q16, [sp, #19024]
	str	q17, [sp, #18976]
	str	q18, [sp, #18992]
	str	q19, [sp, #18944]
	str	q26, [sp, #18960]
	bic.16b	v30, v30, v15
	str	q30, [sp, #1424]                ; 16-byte Folded Spill
	ldr	q1, [sp, #1184]                 ; 16-byte Folded Reload
	bic.16b	v1, v1, v0
	mov.16b	v0, v8
	str	q1, [sp, #1184]                 ; 16-byte Folded Spill
	bic.16b	v5, v5, v21
	str	q5, [sp, #1248]                 ; 16-byte Folded Spill
	bic.16b	v6, v6, v10
	str	q6, [sp, #1040]                 ; 16-byte Folded Spill
	ldr	q31, [sp, #1456]                ; 16-byte Folded Reload
	b	LBB0_234
LBB0_233:                               ; %varying.coherent.false147
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q1, [sp, #704]                  ; 16-byte Folded Reload
	dup.4s	v3, v1[0]
	zip2.8b	v4, v20, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q1, [sp, #656]                  ; 16-byte Folded Reload
	bit.16b	v1, v3, v4
	str	q1, [sp, #656]                  ; 16-byte Folded Spill
	zip1.8b	v4, v20, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q1, [sp, #672]                  ; 16-byte Folded Reload
	bit.16b	v1, v3, v4
	str	q1, [sp, #672]                  ; 16-byte Folded Spill
	tbz	w1, #0, LBB0_148
	b	LBB0_1063
LBB0_234:                               ; %schedule.8
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	mov	w1, #128                        ; =0x80
	dup.2d	v5, x1
	ldr	q1, [sp, #1248]                 ; 16-byte Folded Reload
	cmgt.2d	v3, v5, v1
	ldr	q6, [sp, #1040]                 ; 16-byte Folded Reload
	cmgt.2d	v4, v5, v6
	uzp1.4s	v3, v4, v3
	ldr	q7, [sp, #1184]                 ; 16-byte Folded Reload
	cmgt.2d	v4, v5, v7
	ldr	q17, [sp, #1424]                ; 16-byte Folded Reload
	cmgt.2d	v16, v5, v17
	uzp1.4s	v4, v4, v16
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v21, v20, v3
	shl.8b	v3, v21, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w1, s4
	umaxv.8b	b3, v3
	fmov	w3, s3
	tbz	w3, #0, LBB0_240
; %bb.235:                              ; %schedule.8
                                        ;   in Loop: Header=BB0_8 Depth=3
	cmge.2d	v3, v1, v5
	cmge.2d	v4, v6, v5
	uzp1.4s	v3, v4, v3
	cmge.2d	v4, v7, v5
	cmge.2d	v5, v17, v5
	uzp1.4s	v4, v4, v5
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v10, v20, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_240
; %bb.236:                              ; %varying.divergent243
                                        ;   in Loop: Header=BB0_8 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	str	q24, [sp, #2272]
	str	q12, [sp, #2288]
	and	x1, x1, #0x7
	add	x3, sp, #2272
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #3, #0, ne
	cset	w1, ne
	cmp	w2, #255
	b.ne	LBB0_238
; %bb.237:                              ; %varying.divergent243
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #0, LBB0_238
	b	LBB0_1086
LBB0_238:                               ; %convergence.overflow.resume246
                                        ;   in Loop: Header=BB0_8 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #18, lsl #12            ; =73728
	add	x2, x2, #1520
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s5, w4
	ubfx	w4, w5, #1, #1
	mov.b	v5[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v5[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v5[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v5[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v5[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v5[6], w4
	add	x4, sp, #18, lsl #12            ; =73728
	add	x4, x4, #1512
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v4, w5
	bit.8b	v5, v20, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x2, w3, uxtw]
	bic.8b	v3, v3, v4
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_1086
; %bb.239:                              ; %ready.overflow.resume248
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q23, [sp, #2240]
	str	q11, [sp, #2256]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #2240
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q23, [sp, #2208]
	str	q11, [sp, #2224]
	add	x5, sp, #2208
	str	w4, [x5, x2]
	ldr	q11, [sp, #2224]
	ldr	q23, [sp, #2208]
	str	q24, [sp, #2176]
	str	q12, [sp, #2192]
	add	x4, sp, #2176
	ldr	w4, [x4, x2]
	mov	w5, #3                          ; =0x3
	csel	w4, w5, w4, ne
	str	q24, [sp, #2144]
	str	q12, [sp, #2160]
	add	x5, sp, #2144
	str	w4, [x5, x2]
	mov	w2, #12                         ; =0xc
	mov	w4, #9                          ; =0x9
	ldr	q12, [sp, #2160]
	ldr	q24, [sp, #2144]
	b	LBB0_6
LBB0_240:                               ; %varying.coherent244
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w1, #0xff
	b.eq	LBB0_303
; %bb.241:                              ; %varying.coherent.true249
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
	tst	w2, #0xff
	b.eq	LBB0_1063
LBB0_242:                               ; %schedule.9
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v1, v22
	mov.16b	v22, v31
	str	q14, [sp, #1440]                ; 16-byte Folded Spill
	str	q13, [sp, #1456]                ; 16-byte Folded Spill
	str	q29, [sp, #1472]                ; 16-byte Folded Spill
	str	q0, [sp, #1488]                 ; 16-byte Folded Spill
	mov.16b	v3, v9
	mov.16b	v9, v24
	mov.16b	v24, v12
	mov.16b	v29, v11
	mov.16b	v8, v25
	str	q3, [sp, #1504]                 ; 16-byte Folded Spill
	str	q1, [sp, #1232]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #1184]                 ; 16-byte Folded Reload
	mov	b3, v20[0]
	mov.b	v3[4], v20[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q1, [sp, #1040]                 ; 16-byte Folded Reload
	and.16b	v16, v3, v1
	mov	b4, v20[2]
	mov.b	v4[4], v20[3]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	ldr	q7, [sp, #1424]                 ; 16-byte Folded Reload
	ldr	q1, [sp, #1248]                 ; 16-byte Folded Reload
	and.16b	v17, v4, v1
	mov	b5, v20[4]
	mov.b	v5[4], v20[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v27, v5, #0
	and.16b	v18, v27, v0
	mov	b5, v20[6]
	mov.b	v5[4], v20[7]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v30, v5, #0
	and.16b	v19, v30, v7
	shl.8b	v5, v20, #7
	cmlt.8b	v21, v5, #0
	and.8b	v5, v21, v2
	addv.8b	b5, v5
	fmov	w2, s5
	mov	w3, #32                         ; =0x20
	dup.2d	v31, x3
	and.16b	v26, v3, v31
	mvn.16b	v3, v3
	sub.2d	v26, v26, v3
	and.16b	v3, v4, v31
	mvn.16b	v4, v4
	sub.2d	v11, v3, v4
	and.16b	v3, v27, v31
	and.16b	v4, v30, v31
	mvn.16b	v30, v30
	sub.2d	v4, v4, v30
	mov.d	x3, v4[1]
	mov.d	x4, v19[1]
	sdiv	x4, x4, x3
	mvn.16b	v27, v27
	sub.2d	v3, v3, v27
	fmov	x5, d4
	fmov	x6, d19
	sdiv	x6, x6, x5
	mul	x5, x6, x5
	fmov	d30, x6
	mov.d	v30[1], x4
	mov.d	x6, v3[1]
	mov.d	x7, v18[1]
	sdiv	x7, x7, x6
	fmov	x19, d3
	fmov	x20, d18
	sdiv	x20, x20, x19
	mul	x19, x20, x19
	fmov	d10, x20
	mov.d	v10[1], x7
	mov.d	x20, v11[1]
	mov.d	x21, v17[1]
	sdiv	x21, x21, x20
	fmov	x22, d11
	fmov	x23, d17
	sdiv	x23, x23, x22
	mul	x22, x23, x22
	fmov	d11, x23
	mov.d	v11[1], x21
	mov.d	x23, v26[1]
	mov.d	x24, v16[1]
	fmov	x25, d26
	fmov	x26, d16
	sdiv	x26, x26, x25
	mul	x25, x26, x25
	fmov	d12, x26
	sdiv	x24, x24, x23
	mov.d	v12[1], x24
	mul	x3, x4, x3
	fmov	d3, x5
	mov.d	v3[1], x3
	mul	x3, x7, x6
	fmov	d4, x19
	mov.d	v4[1], x3
	mul	x3, x21, x20
	fmov	d26, x22
	mov.d	v26[1], x3
	mul	x3, x24, x23
	fmov	d27, x25
	mov.d	v27[1], x3
	sub.2d	v16, v16, v27
	sub.2d	v17, v17, v26
	sub.2d	v4, v18, v4
	sub.2d	v3, v19, v3
	ldr	q27, [sp, #19072]
	ldr	q26, [sp, #19088]
	ldr	q19, [sp, #19104]
	ldr	q18, [sp, #19120]
	ldr	q31, [sp, #19184]
	ldr	q13, [sp, #19168]
	ldr	q14, [sp, #19152]
	shl.2d	v3, v3, #6
	shl.2d	v4, v4, #6
	shl.2d	v17, v17, #6
	shl.2d	v16, v16, #6
	ldr	q15, [sp, #19136]
	add.2d	v18, v18, v31
	add.2d	v18, v18, v3
	add.2d	v3, v19, v13
	add.2d	v19, v3, v4
	add.2d	v3, v26, v14
	add.2d	v26, v3, v17
	add.2d	v3, v27, v15
	add.2d	v27, v3, v16
	movi.2d	v13, #0000000000000000
	movi.2d	v14, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbz	w2, #0, LBB0_250
; %bb.243:                              ; %cond.load4263
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d27
	ldr	d13, [x3]
	tbnz	w2, #1, LBB0_251
LBB0_244:                               ; %else4273
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v31, v22
	tbz	w2, #2, LBB0_252
LBB0_245:                               ; %cond.load4275
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d26
	ld1.d	{ v14 }[0], [x3]
	tbnz	w2, #3, LBB0_253
LBB0_246:                               ; %else4285
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #4, LBB0_254
LBB0_247:                               ; %cond.load4287
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d19
	ld1.d	{ v16 }[0], [x3]
	tbnz	w2, #5, LBB0_255
LBB0_248:                               ; %else4297
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #6, LBB0_256
LBB0_249:                               ; %cond.load4299
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d18
	ld1.d	{ v17 }[0], [x3]
	tbnz	w2, #7, LBB0_257
	b	LBB0_258
LBB0_250:                               ; %else4267
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #1, LBB0_244
LBB0_251:                               ; %cond.load4269
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v27[1]
	ld1.d	{ v13 }[1], [x3]
	mov.16b	v31, v22
	tbnz	w2, #2, LBB0_245
LBB0_252:                               ; %else4279
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #3, LBB0_246
LBB0_253:                               ; %cond.load4281
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v26[1]
	ld1.d	{ v14 }[1], [x3]
	tbnz	w2, #4, LBB0_247
LBB0_254:                               ; %else4291
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #5, LBB0_248
LBB0_255:                               ; %cond.load4293
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v19[1]
	ld1.d	{ v16 }[1], [x3]
	tbnz	w2, #6, LBB0_249
LBB0_256:                               ; %else4303
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #7, LBB0_258
LBB0_257:                               ; %cond.load4305
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v18[1]
	ld1.d	{ v17 }[1], [x2]
LBB0_258:                               ; %else4309
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w2, #32                         ; =0x20
	dup.2d	v3, x2
	cmhi.2d	v4, v3, v14
	cmhi.2d	v18, v3, v13
	uzp1.4s	v4, v18, v4
	cmhi.2d	v18, v3, v16
	cmhi.2d	v3, v3, v17
	uzp1.4s	v3, v18, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	ldrb	w2, [x9, #2048]
	and	w3, w2, #0x1
	fmov	s4, w3
	ubfx	w3, w2, #1, #1
	mov.b	v4[1], w3
	ubfx	w3, w2, #2, #1
	mov.b	v4[2], w3
	ubfx	w3, w2, #3, #1
	mov.b	v4[3], w3
	ubfx	w3, w2, #4, #1
	mov.b	v4[4], w3
	ubfx	w3, w2, #5, #1
	mov.b	v4[5], w3
	ubfx	w3, w2, #6, #1
	mov.b	v4[6], w3
	lsr	w2, w2, #7
	mov.b	v4[7], w2
	bif.8b	v3, v4, v21
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x9, #2048]
	shl.2d	v3, v11, #5
	shl.2d	v4, v12, #5
	shl.2d	v18, v30, #5
	shl.2d	v19, v10, #5
	add.2d	v16, v16, v19
	add.2d	v17, v17, v18
	add.2d	v18, v13, v4
	add.2d	v19, v14, v3
	ldr	q3, [sp, #18848]
	ldr	q4, [sp, #18864]
	ldr	q21, [sp, #18816]
	ldr	q26, [sp, #18832]
	mov	b27, v20[2]
	mov.b	v27[4], v20[3]
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	mov	b30, v20[0]
	mov.b	v30[4], v20[1]
	bit.16b	v26, v19, v27
	ushll.2d	v27, v30, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	bit.16b	v21, v18, v27
	mov	b27, v20[6]
	mov.b	v27[4], v20[7]
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	bit.16b	v4, v17, v27
	mov	b27, v20[4]
	mov.b	v27[4], v20[5]
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	bit.16b	v3, v16, v27
	str	q3, [sp, #18848]
	str	q4, [sp, #18864]
	str	q21, [sp, #18816]
	str	q26, [sp, #18832]
	mov	w2, #128                        ; =0x80
	dup.2d	v26, x2
	cmhi.2d	v3, v26, v18
	cmhi.2d	v4, v26, v19
	uzp1.4s	v3, v3, v4
	cmhi.2d	v4, v26, v16
	cmhi.2d	v21, v26, v17
	uzp1.4s	v4, v4, v21
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v21, v20, v3
	shl.8b	v3, v21, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w2, s4
	umaxv.8b	b3, v3
	fmov	w3, s3
	tbz	w3, #0, LBB0_264
; %bb.259:                              ; %else4309
                                        ;   in Loop: Header=BB0_8 Depth=3
	cmhs.2d	v3, v18, v26
	cmhs.2d	v4, v19, v26
	uzp1.4s	v3, v3, v4
	cmhs.2d	v4, v16, v26
	cmhs.2d	v16, v17, v26
	uzp1.4s	v4, v4, v16
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v10, v20, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_264
; %bb.260:                              ; %varying.divergent254
                                        ;   in Loop: Header=BB0_8 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	str	q9, [sp, #2432]
	str	q24, [sp, #2448]
	and	x1, x1, #0x7
	add	x3, sp, #2432
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #4, #0, ne
	cset	w1, ne
	cmp	w2, #255
	mov.16b	v25, v8
	b.ne	LBB0_262
; %bb.261:                              ; %varying.divergent254
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #0, LBB0_262
	b	LBB0_1086
LBB0_262:                               ; %convergence.overflow.resume257
                                        ;   in Loop: Header=BB0_8 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #18, lsl #12            ; =73728
	add	x2, x2, #1520
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s5, w4
	ubfx	w4, w5, #1, #1
	mov.b	v5[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v5[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v5[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v5[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v5[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v5[6], w4
	add	x4, sp, #18, lsl #12            ; =73728
	add	x4, x4, #1512
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v4, w5
	bit.8b	v5, v20, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x2, w3, uxtw]
	bic.8b	v3, v3, v4
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_1086
; %bb.263:                              ; %ready.overflow.resume259
                                        ;   in Loop: Header=BB0_8 Depth=3
	zip2.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldp	q4, q0, [sp, #416]              ; 32-byte Folded Reload
	and.16b	v1, v3, v4
	zip1.8b	v3, v10, v4
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v0, v3, v0
	stp	q1, q0, [sp, #416]              ; 32-byte Folded Spill
	str	q23, [sp, #2400]
	str	q29, [sp, #2416]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #2400
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q23, [sp, #2368]
	str	q29, [sp, #2384]
	add	x5, sp, #2368
	str	w4, [x5, x2]
	ldr	q11, [sp, #2384]
	ldr	q23, [sp, #2368]
	str	q9, [sp, #2336]
	str	q24, [sp, #2352]
	add	x4, sp, #2336
	ldr	w4, [x4, x2]
	mov	w5, #4                          ; =0x4
	csel	w4, w5, w4, ne
	str	q9, [sp, #2304]
	str	q24, [sp, #2320]
	add	x5, sp, #2304
	str	w4, [x5, x2]
	mov	w2, #11                         ; =0xb
	mov	w4, #10                         ; =0xa
	ldr	q12, [sp, #2320]
	ldr	q24, [sp, #2304]
                                        ; kill: def $w3 killed $w3 killed $x3 def $x3
	ldr	q22, [sp, #1232]                ; 16-byte Folded Reload
	ldr	q9, [sp, #1504]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	ldr	q29, [sp, #1472]                ; 16-byte Folded Reload
	ldr	q13, [sp, #1456]                ; 16-byte Folded Reload
	ldr	q14, [sp, #1440]                ; 16-byte Folded Reload
	b	LBB0_7
LBB0_264:                               ; %varying.coherent255
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	mov.16b	v25, v8
	mov.16b	v12, v24
	b.eq	LBB0_302
; %bb.265:                              ; %varying.coherent.true260
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v24, v9
	tbz	w1, #0, LBB0_266
	b	LBB0_1061
LBB0_266:                               ; %schedule.10.thread
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q3, [sp, #19264]
	ldr	q4, [sp, #19280]
	ldr	q7, [sp, #19296]
	ldr	q16, [sp, #19312]
	ldr	q17, [sp, #19376]
	ldr	q18, [sp, #19360]
	ldr	q19, [sp, #19344]
	ldr	q21, [sp, #19328]
	ldr	q26, [sp, #18816]
	ldr	q27, [sp, #18832]
	ldr	q30, [sp, #18848]
	ldr	q31, [sp, #18864]
	shl.2d	v31, v31, #5
	shl.2d	v30, v30, #5
	shl.2d	v27, v27, #5
	shl.2d	v26, v26, #5
	add.2d	v16, v16, v17
	add.2d	v17, v16, v31
	add.2d	v7, v7, v18
	add.2d	v18, v7, v30
	add.2d	v4, v4, v19
	add.2d	v19, v4, v27
	add.2d	v3, v3, v21
	add.2d	v21, v3, v26
	fmov	w1, s5
	movi.2d	v5, #0000000000000000
	movi.2d	v16, #0000000000000000
	mov.16b	v11, v29
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	ldr	q13, [sp, #1456]                ; 16-byte Folded Reload
	tbz	w1, #0, LBB0_274
; %bb.267:                              ; %cond.load5612
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d21
	ldr	s5, [x2]
	ldr	q29, [sp, #1472]                ; 16-byte Folded Reload
	ldr	q1, [sp, #1520]                 ; 16-byte Folded Reload
	ldr	q3, [sp, #1440]                 ; 16-byte Folded Reload
	tbnz	w1, #1, LBB0_275
LBB0_268:                               ; %else5622
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q4, [sp, #1232]                 ; 16-byte Folded Reload
	mov.16b	v31, v22
	ldr	q9, [sp, #1504]                 ; 16-byte Folded Reload
	tbz	w1, #2, LBB0_276
LBB0_269:                               ; %cond.load5624
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d19
	ld1.s	{ v5 }[2], [x2]
	mov.16b	v22, v4
	str	q1, [sp, #1520]                 ; 16-byte Folded Spill
	mov.16b	v14, v3
	tbnz	w1, #3, LBB0_277
LBB0_270:                               ; %else5634
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #4, LBB0_278
LBB0_271:                               ; %cond.load5636
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d18
	ld1.s	{ v16 }[0], [x2]
	tbnz	w1, #5, LBB0_279
LBB0_272:                               ; %else5646
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #6, LBB0_280
LBB0_273:                               ; %cond.load5648
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d17
	ld1.s	{ v16 }[2], [x2]
	tbnz	w1, #7, LBB0_281
	b	LBB0_282
LBB0_274:                               ; %else5616
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q29, [sp, #1472]                ; 16-byte Folded Reload
	ldr	q1, [sp, #1520]                 ; 16-byte Folded Reload
	ldr	q3, [sp, #1440]                 ; 16-byte Folded Reload
	tbz	w1, #1, LBB0_268
LBB0_275:                               ; %cond.load5618
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v21[1]
	ld1.s	{ v5 }[1], [x2]
	ldr	q4, [sp, #1232]                 ; 16-byte Folded Reload
	mov.16b	v31, v22
	ldr	q9, [sp, #1504]                 ; 16-byte Folded Reload
	tbnz	w1, #2, LBB0_269
LBB0_276:                               ; %else5628
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v22, v4
	str	q1, [sp, #1520]                 ; 16-byte Folded Spill
	mov.16b	v14, v3
	tbz	w1, #3, LBB0_270
LBB0_277:                               ; %cond.load5630
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v19[1]
	ld1.s	{ v5 }[3], [x2]
	tbnz	w1, #4, LBB0_271
LBB0_278:                               ; %else5640
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #5, LBB0_272
LBB0_279:                               ; %cond.load5642
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v18[1]
	ld1.s	{ v16 }[1], [x2]
	tbnz	w1, #6, LBB0_273
LBB0_280:                               ; %else5652
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #7, LBB0_282
LBB0_281:                               ; %cond.load5654
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x1, v17[1]
	ld1.s	{ v16 }[3], [x1]
LBB0_282:                               ; %else5658
                                        ;   in Loop: Header=BB0_8 Depth=3
	zip2.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q1, [sp, #416]                  ; 16-byte Folded Reload
	bit.16b	v1, v16, v3
	str	q1, [sp, #416]                  ; 16-byte Folded Spill
	zip1.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q1, [sp, #432]                  ; 16-byte Folded Reload
	bit.16b	v1, v5, v3
	str	q1, [sp, #432]                  ; 16-byte Folded Spill
	mov.16b	v6, v31
	cbnz	w0, LBB0_144
LBB0_283:                               ; %schedule.11.convergence.cascade.exit265_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_284:                               ; %convergence.cascade.exit265
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1046
; %bb.285:                              ; %convergence.target.11.ready
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q1, [sp, #704]                  ; 16-byte Folded Reload
	dup.4s	v3, v1[0]
	ldrb	w1, [x9, #2048]
	ubfx	w2, w1, #3, #1
	ubfx	w3, w1, #2, #1
	ubfx	w4, w1, #1, #1
	and	w5, w1, #0x1
	lsr	w6, w1, #7
	ubfx	w7, w1, #6, #1
	ubfx	w19, w1, #5, #1
	ubfx	w1, w1, #4, #1
	fmov	s4, w1
	mov.h	v4[1], w19
	mov.h	v4[2], w7
	mov.h	v4[3], w6
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	fmov	s7, w5
	mov.h	v7[1], w4
	mov.h	v7[2], w3
	mov.h	v7[3], w2
	ldr	q1, [sp, #416]                  ; 16-byte Folded Reload
	mov.16b	v5, v4
	bsl.16b	v5, v1, v3
	ushll.4s	v4, v7, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q1, [sp, #432]                  ; 16-byte Folded Reload
	mov.16b	v17, v4
	bsl.16b	v17, v1, v3
	ldr	q3, [sp, #18992]
	ldr	q4, [sp, #18976]
	ldr	q7, [sp, #18960]
	ldr	q16, [sp, #18944]
	ldr	q18, [sp, #19008]
	ldr	q19, [sp, #19024]
	ldr	q21, [sp, #19040]
	ldr	q26, [sp, #19056]
	ldr	q1, [sp, #1040]                 ; 16-byte Folded Reload
	shl.2d	v27, v1, #5
	ldr	q1, [sp, #1248]                 ; 16-byte Folded Reload
	shl.2d	v30, v1, #5
	ldr	q1, [sp, #1184]                 ; 16-byte Folded Reload
	shl.2d	v31, v1, #5
	ldr	q1, [sp, #1424]                 ; 16-byte Folded Reload
	shl.2d	v8, v1, #5
	add.2d	v26, v26, v8
	add.2d	v31, v21, v31
	add.2d	v19, v19, v30
	add.2d	v18, v18, v27
	add.2d	v21, v16, v18
	add.2d	v19, v7, v19
	add.2d	v18, v4, v31
	add.2d	v16, v3, v26
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w1, s3
	mov.16b	v31, v6
	tbz	w1, #0, LBB0_293
; %bb.286:                              ; %cond.store5661
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d21
	str	s17, [x2]
	tbnz	w1, #1, LBB0_294
LBB0_287:                               ; %else5668
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #2, LBB0_295
LBB0_288:                               ; %cond.store5669
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d19
	st1.s	{ v17 }[2], [x2]
	tbnz	w1, #3, LBB0_296
LBB0_289:                               ; %else5676
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #4, LBB0_297
LBB0_290:                               ; %cond.store5677
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d18
	str	s5, [x2]
	tbnz	w1, #5, LBB0_298
LBB0_291:                               ; %else5684
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #6, LBB0_299
LBB0_292:                               ; %cond.store5685
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d16
	st1.s	{ v5 }[2], [x2]
	tbnz	w1, #7, LBB0_300
	b	LBB0_301
LBB0_293:                               ; %else5664
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #1, LBB0_287
LBB0_294:                               ; %cond.store5665
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v21[1]
	st1.s	{ v17 }[1], [x2]
	tbnz	w1, #2, LBB0_288
LBB0_295:                               ; %else5672
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #3, LBB0_289
LBB0_296:                               ; %cond.store5673
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v19[1]
	st1.s	{ v17 }[3], [x2]
	tbnz	w1, #4, LBB0_290
LBB0_297:                               ; %else5680
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #5, LBB0_291
LBB0_298:                               ; %cond.store5681
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v18[1]
	st1.s	{ v5 }[1], [x2]
	tbnz	w1, #6, LBB0_292
LBB0_299:                               ; %else5688
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #7, LBB0_301
LBB0_300:                               ; %cond.store5689
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x1, v16[1]
	st1.s	{ v5 }[3], [x1]
LBB0_301:                               ; %else5692
                                        ;   in Loop: Header=BB0_8 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v20, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v4, v3, #0
	ushll2.4s	v3, v3, #0
	ldr	q1, [sp, #1424]                 ; 16-byte Folded Reload
	uaddw2.2d	v1, v1, v3
	str	q1, [sp, #1424]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #1184]                 ; 16-byte Folded Reload
	uaddw.2d	v1, v1, v3
	str	q1, [sp, #1184]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #1248]                 ; 16-byte Folded Reload
	uaddw2.2d	v1, v1, v4
	str	q1, [sp, #1248]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #1040]                 ; 16-byte Folded Reload
	uaddw.2d	v1, v1, v4
	str	q1, [sp, #1040]                 ; 16-byte Folded Spill
	b	LBB0_234
LBB0_302:                               ; %varying.coherent.false261
                                        ;   in Loop: Header=BB0_8 Depth=3
	zip2.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldp	q4, q0, [sp, #416]              ; 32-byte Folded Reload
	and.16b	v1, v3, v4
	zip1.8b	v3, v20, v4
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v0, v3, v0
	stp	q1, q0, [sp, #416]              ; 32-byte Folded Spill
	ldr	q22, [sp, #1232]                ; 16-byte Folded Reload
	ldr	q1, [sp, #1504]                 ; 16-byte Folded Reload
	mov.16b	v11, v29
	mov.16b	v24, v9
	mov.16b	v9, v1
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	ldr	q29, [sp, #1472]                ; 16-byte Folded Reload
	ldr	q13, [sp, #1456]                ; 16-byte Folded Reload
	ldr	q14, [sp, #1440]                ; 16-byte Folded Reload
	tbz	w1, #0, LBB0_143
	b	LBB0_1063
LBB0_303:                               ; %varying.coherent.false250
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1063
LBB0_304:                               ; %schedule.12
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v6, v31
	cbz	w0, LBB0_309
; %bb.305:                              ; %convergence.cascade289.preheader
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
LBB0_306:                               ; %convergence.cascade289
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_3 Depth=2
                                        ;       Parent Loop BB0_8 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w2, s4
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	str	q24, [sp, #14176]
	str	q12, [sp, #14192]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #3, lsl #12             ; =12288
	add	x6, x6, #1888
	ldr	w6, [x6, x2]
	cmp	w6, #3
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #1520
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s5, w19
	ubfx	w19, w20, #1, #1
	mov.b	v5[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v5[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v5[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v5[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v5[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v5[6], w19
	add	x19, sp, #18, lsl #12           ; =73728
	add	x19, x19, #1512
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s3, w21
	ubfx	w21, w20, #1, #1
	mov.b	v3[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v3[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v3[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v3[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v3[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v3[6], w21
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	orr.8b	v4, v20, v3
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	and.8b	v7, v1, v5
	eor.8b	v7, v7, v4
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v4, v7
	dup.8b	v17, w7
	bit.8b	v3, v16, v17
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x19, w3, sxtw]
	bic.8b	v3, v5, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v4, v5, v4
	str	q23, [sp, #14144]
	str	q11, [sp, #14160]
	add	x3, sp, #3, lsl #12             ; =12288
	add	x3, x3, #1856
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v20, v4, v3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_310
; %bb.307:                              ; %convergence.cascade289
                                        ;   in Loop: Header=BB0_306 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_310
; %bb.308:                              ; %convergence.cascade289
                                        ;   in Loop: Header=BB0_306 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_306
	b	LBB0_310
LBB0_309:                               ; %schedule.12.convergence.cascade.exit290_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_310:                               ; %convergence.cascade.exit290
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1046
; %bb.311:                              ; %convergence.target.12.ready
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q18, [sp, #18784]
	ldr	q16, [sp, #18800]
	ldr	q5, [sp, #18752]
	ldr	q3, [sp, #18768]
	ldr	q17, [sp, #18720]
	ldr	q4, [sp, #18736]
	ldr	q7, [sp, #18688]
	ldr	q21, [sp, #18704]
	mov	b19, v20[2]
	mov.b	v19[4], v20[3]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	ldr	q8, [sp, #304]                  ; 16-byte Folded Reload
	bit.16b	v21, v8, v19
	mov	b26, v20[0]
	mov.b	v26[4], v20[1]
	ushll.2d	v26, v26, #0
	shl.2d	v26, v26, #63
	cmlt.2d	v26, v26, #0
	mov	b27, v20[6]
	mov.b	v27[4], v20[7]
	bit.16b	v7, v8, v26
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	bit.16b	v4, v8, v27
	mov	b30, v20[4]
	mov.b	v30[4], v20[5]
	ushll.2d	v30, v30, #0
	shl.2d	v30, v30, #63
	cmlt.2d	v30, v30, #0
Lloh306:
	adrp	x1, lCPI0_17@PAGE
Lloh307:
	ldr	q31, [x1, lCPI0_17@PAGEOFF]
	bit.16b	v3, v31, v19
Lloh308:
	adrp	x1, lCPI0_18@PAGE
Lloh309:
	ldr	q31, [x1, lCPI0_18@PAGEOFF]
	bit.16b	v18, v31, v30
Lloh310:
	adrp	x1, lCPI0_16@PAGE
Lloh311:
	ldr	q31, [x1, lCPI0_16@PAGEOFF]
	str	q18, [sp, #18784]
Lloh312:
	adrp	x1, lCPI0_19@PAGE
Lloh313:
	ldr	q18, [x1, lCPI0_19@PAGEOFF]
	bit.16b	v17, v8, v30
	bit.16b	v16, v18, v27
	str	q16, [sp, #18800]
	bit.16b	v5, v31, v26
	str	q5, [sp, #18752]
	str	q3, [sp, #18768]
	str	q17, [sp, #18720]
	str	q4, [sp, #18736]
	str	q7, [sp, #18688]
	str	q21, [sp, #18704]
	bic.16b	v14, v14, v27
	mov.16b	v1, v0
	ldr	q0, [sp, #1296]                 ; 16-byte Folded Reload
	bic.16b	v0, v0, v30
	str	q0, [sp, #1296]                 ; 16-byte Folded Spill
	mov.16b	v0, v1
	ldr	q1, [sp, #1056]                 ; 16-byte Folded Reload
	bic.16b	v1, v1, v19
	str	q1, [sp, #1056]                 ; 16-byte Folded Spill
	bic.16b	v22, v22, v26
	mov.16b	v31, v6
LBB0_312:                               ; %schedule.13
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v6, v0
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	mov	w1, #128                        ; =0x80
	dup.2d	v5, x1
	ldr	q1, [sp, #1056]                 ; 16-byte Folded Reload
	cmgt.2d	v3, v5, v1
	cmgt.2d	v4, v5, v22
	uzp1.4s	v3, v4, v3
	ldr	q0, [sp, #1296]                 ; 16-byte Folded Reload
	cmgt.2d	v4, v5, v0
	cmgt.2d	v16, v5, v14
	uzp1.4s	v4, v4, v16
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v21, v20, v3
	shl.8b	v3, v21, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w1, s4
	umaxv.8b	b3, v3
	fmov	w3, s3
	tbz	w3, #0, LBB0_318
; %bb.313:                              ; %schedule.13
                                        ;   in Loop: Header=BB0_8 Depth=3
	cmge.2d	v3, v1, v5
	cmge.2d	v4, v22, v5
	uzp1.4s	v3, v4, v3
	ldr	q0, [sp, #1296]                 ; 16-byte Folded Reload
	cmge.2d	v4, v0, v5
	cmge.2d	v5, v14, v5
	uzp1.4s	v4, v4, v5
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v10, v20, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_318
; %bb.314:                              ; %varying.divergent307
                                        ;   in Loop: Header=BB0_8 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	str	q24, [sp, #2656]
	str	q12, [sp, #2672]
	and	x1, x1, #0x7
	add	x3, sp, #2656
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #5, #0, ne
	cset	w1, ne
	cmp	w2, #255
	b.ne	LBB0_316
; %bb.315:                              ; %varying.divergent307
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #0, LBB0_316
	b	LBB0_1086
LBB0_316:                               ; %convergence.overflow.resume310
                                        ;   in Loop: Header=BB0_8 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #18, lsl #12            ; =73728
	add	x2, x2, #1520
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s5, w4
	ubfx	w4, w5, #1, #1
	mov.b	v5[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v5[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v5[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v5[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v5[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v5[6], w4
	add	x4, sp, #18, lsl #12            ; =73728
	add	x4, x4, #1512
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v4, w5
	bit.8b	v5, v20, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x2, w3, uxtw]
	bic.8b	v3, v3, v4
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_1086
; %bb.317:                              ; %ready.overflow.resume312
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v0, v6
	str	q23, [sp, #2624]
	str	q11, [sp, #2640]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #2624
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q23, [sp, #2592]
	str	q11, [sp, #2608]
	add	x5, sp, #2592
	str	w4, [x5, x2]
	ldr	q11, [sp, #2608]
	ldr	q23, [sp, #2592]
	str	q24, [sp, #2560]
	str	q12, [sp, #2576]
	add	x4, sp, #2560
	ldr	w4, [x4, x2]
	mov	w5, #5                          ; =0x5
	csel	w4, w5, w4, ne
	str	q24, [sp, #2528]
	str	q12, [sp, #2544]
	add	x5, sp, #2528
	str	w4, [x5, x2]
	mov	w2, #15                         ; =0xf
	mov	w4, #14                         ; =0xe
	ldr	q12, [sp, #2544]
	ldr	q24, [sp, #2528]
	b	LBB0_6
LBB0_318:                               ; %varying.coherent308
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w1, #0xff
	b.eq	LBB0_369
; %bb.319:                              ; %varying.coherent.true313
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
	tst	w2, #0xff
	mov.16b	v0, v6
	b.eq	LBB0_1063
LBB0_320:                               ; %schedule.14
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v7, v31
	str	q13, [sp, #1456]                ; 16-byte Folded Spill
	str	q29, [sp, #1472]                ; 16-byte Folded Spill
	str	q0, [sp, #1488]                 ; 16-byte Folded Spill
	str	q24, [sp, #1376]                ; 16-byte Folded Spill
	str	q12, [sp, #1536]                ; 16-byte Folded Spill
	str	q23, [sp, #1392]                ; 16-byte Folded Spill
	str	q11, [sp, #1568]                ; 16-byte Folded Spill
	mov.16b	v1, v25
	str	q9, [sp, #1504]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #1296]                 ; 16-byte Folded Reload
	mov	b3, v20[0]
	mov.b	v3[4], v20[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	mov.16b	v6, v22
	and.16b	v16, v3, v22
	mov	b4, v20[2]
	mov.b	v4[4], v20[3]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	ldr	q5, [sp, #1056]                 ; 16-byte Folded Reload
	and.16b	v17, v4, v5
	mov	b5, v20[4]
	mov.b	v5[4], v20[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v27, v5, #0
	and.16b	v18, v27, v0
	mov	b5, v20[6]
	mov.b	v5[4], v20[7]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v30, v5, #0
	mov.16b	v23, v14
	and.16b	v19, v30, v14
	shl.8b	v5, v20, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	mov	w2, #32                         ; =0x20
	dup.2d	v31, x2
	and.16b	v21, v3, v31
	mvn.16b	v3, v3
	sub.2d	v21, v21, v3
	and.16b	v3, v4, v31
	mvn.16b	v4, v4
	sub.2d	v26, v3, v4
	and.16b	v3, v27, v31
	mvn.16b	v4, v27
	and.16b	v27, v30, v31
	mvn.16b	v30, v30
	sub.2d	v27, v27, v30
	mov.d	x2, v27[1]
	mov.d	x3, v19[1]
	sdiv	x3, x3, x2
	sub.2d	v3, v3, v4
	fmov	x4, d27
	fmov	x5, d19
	sdiv	x5, x5, x4
	mul	x4, x5, x4
	fmov	d4, x5
	mov.d	v4[1], x3
	mov.d	x5, v3[1]
	mov.d	x6, v18[1]
	sdiv	x6, x6, x5
	fmov	x7, d3
	fmov	x19, d18
	sdiv	x19, x19, x7
	mul	x7, x19, x7
	fmov	d3, x19
	mov.d	v3[1], x6
	mov.d	x19, v26[1]
	mov.d	x20, v17[1]
	sdiv	x20, x20, x19
	fmov	x21, d26
	fmov	x22, d17
	sdiv	x22, x22, x21
	mul	x21, x22, x21
	fmov	d26, x22
	mov.d	v26[1], x20
	mov.d	x22, v21[1]
	mov.d	x23, v16[1]
	fmov	x24, d21
	fmov	x25, d16
	sdiv	x25, x25, x24
	mul	x24, x25, x24
	fmov	d21, x25
	sdiv	x23, x23, x22
	mov.d	v21[1], x23
	mul	x22, x23, x22
	fmov	d27, x24
	mov.d	v27[1], x22
	mul	x19, x20, x19
	fmov	d30, x21
	mov.d	v30[1], x19
	mul	x5, x6, x5
	fmov	d31, x7
	mov.d	v31[1], x5
	mul	x2, x3, x2
	fmov	d10, x4
	mov.d	v10[1], x2
	addv.8b	b5, v5
	sub.2d	v19, v19, v10
	sub.2d	v18, v18, v31
	fmov	w2, s5
	sub.2d	v17, v17, v30
	sub.2d	v16, v16, v27
	ldr	q27, [sp, #19264]
	ldr	q30, [sp, #19280]
	ldr	q31, [sp, #19296]
	ldr	q11, [sp, #19312]
	ldr	q12, [sp, #19376]
	ldr	q13, [sp, #19360]
	ldr	q14, [sp, #19344]
	shl.2d	v21, v21, #10
	shl.2d	v26, v26, #10
	shl.2d	v3, v3, #10
	shl.2d	v4, v4, #10
	shl.2d	v10, v16, #5
	shl.2d	v15, v17, #5
	shl.2d	v17, v18, #5
	shl.2d	v16, v19, #5
	add.2d	v16, v4, v16
	add.2d	v17, v3, v17
	ldr	q3, [sp, #19328]
	add.2d	v18, v26, v15
	add.2d	v10, v21, v10
	add.2d	v4, v11, v12
	add.2d	v19, v4, v16
	add.2d	v4, v31, v13
	add.2d	v11, v4, v17
	add.2d	v4, v30, v14
	add.2d	v26, v4, v18
	add.2d	v3, v27, v3
	add.2d	v27, v3, v10
	movi.2d	v21, #0000000000000000
	movi.2d	v30, #0000000000000000
	tbz	w2, #0, LBB0_324
; %bb.321:                              ; %cond.load4361
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d27
	ldr	s21, [x3]
	tbnz	w2, #1, LBB0_325
LBB0_322:                               ; %else4371
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v25, v1
	tbz	w2, #2, LBB0_326
LBB0_323:                               ; %cond.load4373
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d26
	ld1.s	{ v21 }[2], [x3]
	ldr	q0, [sp, #1360]                 ; 16-byte Folded Reload
	ldr	q29, [sp, #1472]                ; 16-byte Folded Reload
	str	q0, [sp, #1360]                 ; 16-byte Folded Spill
	tbnz	w2, #3, LBB0_327
	b	LBB0_328
LBB0_324:                               ; %else4365
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #1, LBB0_322
LBB0_325:                               ; %cond.load4367
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v27[1]
	ld1.s	{ v21 }[1], [x3]
	mov.16b	v25, v1
	tbnz	w2, #2, LBB0_323
LBB0_326:                               ; %else4377
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q0, [sp, #1360]                 ; 16-byte Folded Reload
	ldr	q29, [sp, #1472]                ; 16-byte Folded Reload
	str	q0, [sp, #1360]                 ; 16-byte Folded Spill
	tbz	w2, #3, LBB0_328
LBB0_327:                               ; %cond.load4379
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v26[1]
	ld1.s	{ v21 }[3], [x3]
LBB0_328:                               ; %else4383
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q24, [sp, #1376]                ; 16-byte Folded Reload
	mov.16b	v14, v23
	ldr	q9, [sp, #1504]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	ldr	q13, [sp, #1456]                ; 16-byte Folded Reload
	mov.16b	v22, v6
	tbz	w2, #4, LBB0_332
; %bb.329:                              ; %cond.load4385
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d11
	ld1.s	{ v30 }[0], [x3]
	ldr	q1, [sp, #1424]                 ; 16-byte Folded Reload
	ldr	q23, [sp, #1392]                ; 16-byte Folded Reload
	tbnz	w2, #5, LBB0_333
LBB0_330:                               ; %else4395
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #6, LBB0_334
LBB0_331:                               ; %cond.load4397
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d19
	ld1.s	{ v30 }[2], [x3]
	str	q1, [sp, #1424]                 ; 16-byte Folded Spill
	tbnz	w2, #7, LBB0_335
	b	LBB0_336
LBB0_332:                               ; %else4389
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q1, [sp, #1424]                 ; 16-byte Folded Reload
	ldr	q23, [sp, #1392]                ; 16-byte Folded Reload
	tbz	w2, #5, LBB0_330
LBB0_333:                               ; %cond.load4391
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v11[1]
	ld1.s	{ v30 }[1], [x3]
	tbnz	w2, #6, LBB0_331
LBB0_334:                               ; %else4401
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q1, [sp, #1424]                 ; 16-byte Folded Spill
	tbz	w2, #7, LBB0_336
LBB0_335:                               ; %cond.load4403
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v19[1]
	ld1.s	{ v30 }[3], [x2]
LBB0_336:                               ; %else4407
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q3, [sp, #18992]
	ldr	q4, [sp, #18976]
	ldr	q19, [sp, #18960]
	ldr	q26, [sp, #18944]
	ldr	q27, [sp, #19008]
	ldr	q31, [sp, #19024]
	ldr	q11, [sp, #19040]
	ldr	q12, [sp, #19056]
	add.2d	v26, v26, v27
	add.2d	v27, v26, v10
	add.2d	v19, v19, v31
	add.2d	v26, v19, v18
	add.2d	v4, v4, v11
	add.2d	v19, v4, v17
	add.2d	v3, v3, v12
	add.2d	v18, v3, v16
	fmov	w2, s5
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbz	w2, #0, LBB0_344
; %bb.337:                              ; %cond.load4410
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d27
	ldr	s16, [x3]
	tbnz	w2, #1, LBB0_345
LBB0_338:                               ; %else4420
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #2, LBB0_346
LBB0_339:                               ; %cond.load4422
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d26
	ld1.s	{ v16 }[2], [x3]
	tbnz	w2, #3, LBB0_347
LBB0_340:                               ; %else4432
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #4, LBB0_348
LBB0_341:                               ; %cond.load4434
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d19
	ld1.s	{ v17 }[0], [x3]
	tbnz	w2, #5, LBB0_349
LBB0_342:                               ; %else4444
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #6, LBB0_350
LBB0_343:                               ; %cond.load4446
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d18
	ld1.s	{ v17 }[2], [x3]
	mov.16b	v6, v0
	tbnz	w2, #7, LBB0_351
	b	LBB0_352
LBB0_344:                               ; %else4414
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #1, LBB0_338
LBB0_345:                               ; %cond.load4416
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v27[1]
	ld1.s	{ v16 }[1], [x3]
	tbnz	w2, #2, LBB0_339
LBB0_346:                               ; %else4426
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #3, LBB0_340
LBB0_347:                               ; %cond.load4428
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v26[1]
	ld1.s	{ v16 }[3], [x3]
	tbnz	w2, #4, LBB0_341
LBB0_348:                               ; %else4438
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #5, LBB0_342
LBB0_349:                               ; %cond.load4440
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v19[1]
	ld1.s	{ v17 }[1], [x3]
	tbnz	w2, #6, LBB0_343
LBB0_350:                               ; %else4450
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v6, v0
	tbz	w2, #7, LBB0_352
LBB0_351:                               ; %cond.load4452
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v18[1]
	ld1.s	{ v17 }[3], [x2]
LBB0_352:                               ; %else4456
                                        ;   in Loop: Header=BB0_8 Depth=3
	fadd.4s	v18, v21, v16
	fadd.4s	v16, v30, v17
	ldr	q3, [sp, #18736]
	ldr	q4, [sp, #18720]
	ldr	q17, [sp, #18704]
	ldr	q19, [sp, #18688]
	ldr	q21, [sp, #18752]
	ldr	q26, [sp, #18768]
	ldr	q27, [sp, #18784]
	ldr	q30, [sp, #18800]
	shl.2d	v31, v22, #5
	ldr	q1, [sp, #1056]                 ; 16-byte Folded Reload
	shl.2d	v10, v1, #5
	ldr	q0, [sp, #1296]                 ; 16-byte Folded Reload
	shl.2d	v11, v0, #5
	shl.2d	v12, v14, #5
	add.2d	v30, v30, v12
	add.2d	v27, v27, v11
	add.2d	v10, v26, v10
	add.2d	v21, v21, v31
	add.2d	v26, v19, v21
	add.2d	v21, v17, v10
	add.2d	v19, v4, v27
	add.2d	v17, v3, v30
	fmov	w2, s5
	tbz	w2, #0, LBB0_360
; %bb.353:                              ; %cond.store
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d26
	str	s18, [x3]
	ldr	q11, [sp, #1568]                ; 16-byte Folded Reload
	ldr	q12, [sp, #1536]                ; 16-byte Folded Reload
	mov.16b	v31, v7
	tbnz	w2, #1, LBB0_361
LBB0_354:                               ; %else4463
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #2, LBB0_362
LBB0_355:                               ; %cond.store4464
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d21
	st1.s	{ v18 }[2], [x3]
	tbnz	w2, #3, LBB0_363
LBB0_356:                               ; %else4469
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #4, LBB0_364
LBB0_357:                               ; %cond.store4470
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d19
	str	s16, [x3]
	tbnz	w2, #5, LBB0_365
LBB0_358:                               ; %else4475
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #6, LBB0_366
LBB0_359:                               ; %cond.store4476
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d17
	st1.s	{ v16 }[2], [x3]
	tbnz	w2, #7, LBB0_367
	b	LBB0_368
LBB0_360:                               ; %else4460
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q11, [sp, #1568]                ; 16-byte Folded Reload
	ldr	q12, [sp, #1536]                ; 16-byte Folded Reload
	mov.16b	v31, v7
	tbz	w2, #1, LBB0_354
LBB0_361:                               ; %cond.store4461
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v26[1]
	st1.s	{ v18 }[1], [x3]
	tbnz	w2, #2, LBB0_355
LBB0_362:                               ; %else4466
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #3, LBB0_356
LBB0_363:                               ; %cond.store4467
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v21[1]
	st1.s	{ v18 }[3], [x3]
	tbnz	w2, #4, LBB0_357
LBB0_364:                               ; %else4472
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #5, LBB0_358
LBB0_365:                               ; %cond.store4473
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v19[1]
	st1.s	{ v16 }[1], [x3]
	tbnz	w2, #6, LBB0_359
LBB0_366:                               ; %else4478
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #7, LBB0_368
LBB0_367:                               ; %cond.store4479
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v17[1]
	st1.s	{ v16 }[3], [x2]
LBB0_368:                               ; %else4481
                                        ;   in Loop: Header=BB0_8 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v20, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v4, v3, #0
	ushll2.4s	v3, v3, #0
	uaddw2.2d	v14, v14, v3
	ldr	q0, [sp, #1296]                 ; 16-byte Folded Reload
	uaddw.2d	v0, v0, v3
	str	q0, [sp, #1296]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #1056]                 ; 16-byte Folded Reload
	uaddw2.2d	v1, v1, v4
	str	q1, [sp, #1056]                 ; 16-byte Folded Spill
	uaddw.2d	v22, v22, v4
	mov.16b	v0, v6
	tbz	w1, #0, LBB0_312
	b	LBB0_1063
LBB0_369:                               ; %varying.coherent.false314
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	mov.16b	v0, v6
	b.eq	LBB0_1063
LBB0_370:                               ; %schedule.15
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q31, [sp, #1456]                ; 16-byte Folded Spill
	ldr	q6, [sp, #1552]                 ; 16-byte Folded Reload
	str	q28, [sp, #1408]                ; 16-byte Folded Spill
	str	q25, [sp, #1168]                ; 16-byte Folded Spill
	str	q11, [sp, #1568]                ; 16-byte Folded Spill
	str	q23, [sp, #1392]                ; 16-byte Folded Spill
	str	q12, [sp, #1536]                ; 16-byte Folded Spill
	str	q24, [sp, #1376]                ; 16-byte Folded Spill
	str	q6, [sp, #1552]                 ; 16-byte Folded Spill
	cbz	w0, LBB0_375
; %bb.371:                              ; %convergence.cascade322.preheader
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
LBB0_372:                               ; %convergence.cascade322
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_3 Depth=2
                                        ;       Parent Loop BB0_8 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w2, s4
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	str	q24, [sp, #14112]
	str	q12, [sp, #14128]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #3, lsl #12             ; =12288
	add	x6, x6, #1824
	ldr	w6, [x6, x2]
	cmp	w6, #5
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #1520
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s5, w19
	ubfx	w19, w20, #1, #1
	mov.b	v5[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v5[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v5[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v5[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v5[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v5[6], w19
	add	x19, sp, #18, lsl #12           ; =73728
	add	x19, x19, #1512
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s3, w21
	ubfx	w21, w20, #1, #1
	mov.b	v3[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v3[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v3[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v3[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v3[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v3[6], w21
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	orr.8b	v4, v20, v3
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	and.8b	v7, v1, v5
	eor.8b	v7, v7, v4
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v4, v7
	dup.8b	v17, w7
	bit.8b	v3, v16, v17
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x19, w3, sxtw]
	bic.8b	v3, v5, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v4, v5, v4
	str	q23, [sp, #14080]
	str	q11, [sp, #14096]
	add	x3, sp, #3, lsl #12             ; =12288
	add	x3, x3, #1792
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v20, v4, v3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_376
; %bb.373:                              ; %convergence.cascade322
                                        ;   in Loop: Header=BB0_372 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_376
; %bb.374:                              ; %convergence.cascade322
                                        ;   in Loop: Header=BB0_372 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_372
	b	LBB0_376
LBB0_375:                               ; %schedule.15.convergence.cascade.exit323_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_376:                               ; %convergence.cascade.exit323
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1047
; %bb.377:                              ; %convergence.target.15.ready
                                        ;   in Loop: Header=BB0_8 Depth=3
	rbit	w1, w2
	clz	w1, w1
	ldr	q16, [sp, #18656]
	ldr	q3, [sp, #18672]
	ldr	q4, [sp, #18624]
	ldr	q7, [sp, #18640]
	ldr	q17, [sp, #18592]
	ldr	q5, [sp, #18608]
	ldr	q18, [sp, #18560]
	ldr	q19, [sp, #18576]
	mov	b21, v20[2]
	mov.b	v21[4], v20[3]
	ushll.2d	v21, v21, #0
	shl.2d	v21, v21, #63
	cmlt.2d	v21, v21, #0
	mov	b26, v20[0]
	mov.b	v26[4], v20[1]
	ldr	q27, [sp, #288]                 ; 16-byte Folded Reload
	mov.16b	v15, v21
	bsl.16b	v15, v27, v19
	ushll.2d	v26, v26, #0
	shl.2d	v26, v26, #63
	cmlt.2d	v30, v26, #0
	mov.16b	v1, v30
	bsl.16b	v1, v27, v18
	str	q1, [sp, #1504]                 ; 16-byte Folded Spill
	mov	b26, v20[6]
	mov.b	v26[4], v20[7]
	ushll.2d	v26, v26, #0
	shl.2d	v26, v26, #63
	cmlt.2d	v10, v26, #0
	mov.16b	v26, v10
	bsl.16b	v26, v27, v5
	mov	b5, v20[4]
	mov.b	v5[4], v20[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	mov.16b	v1, v5
	bsl.16b	v1, v27, v17
	str	q1, [sp, #1488]                 ; 16-byte Folded Spill
Lloh314:
	adrp	x2, lCPI0_20@PAGE
Lloh315:
	ldr	q27, [x2, lCPI0_20@PAGEOFF]
	mov.16b	v25, v21
	bsl.16b	v25, v27, v7
Lloh316:
	adrp	x2, lCPI0_21@PAGE
Lloh317:
	ldr	q31, [x2, lCPI0_21@PAGEOFF]
	mov.16b	v6, v30
	bsl.16b	v6, v31, v4
Lloh318:
	adrp	x2, lCPI0_22@PAGE
Lloh319:
	ldr	q8, [x2, lCPI0_22@PAGEOFF]
	bit.16b	v3, v8, v10
Lloh320:
	adrp	x2, lCPI0_23@PAGE
	mov.16b	v17, v0
	mov.16b	v2, v9
Lloh321:
	ldr	q9, [x2, lCPI0_23@PAGEOFF]
	bit.16b	v16, v9, v5
	str	q16, [sp, #18656]
	str	q3, [sp, #18672]
	str	q6, [sp, #18624]
	str	q25, [sp, #18640]
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	str	q0, [sp, #18592]
	str	q26, [sp, #18608]
	ldr	q0, [sp, #1504]                 ; 16-byte Folded Reload
	str	q0, [sp, #18560]
	str	q15, [sp, #18576]
	str	q8, [sp, #12080]
	str	q9, [sp, #12064]
	mov.16b	v9, v2
	ldr	q23, [sp, #1392]                ; 16-byte Folded Reload
	ldr	q24, [sp, #1376]                ; 16-byte Folded Reload
	ldr	q25, [sp, #1168]                ; 16-byte Folded Reload
	ldr	q12, [sp, #1536]                ; 16-byte Folded Reload
	ldr	q11, [sp, #1568]                ; 16-byte Folded Reload
	mov.16b	v0, v17
	ldr	q28, [sp, #1408]                ; 16-byte Folded Reload
	ldr	d2, [sp, #696]                  ; 8-byte Folded Reload
	str	q27, [sp, #12048]
	str	q31, [sp, #12032]
	lsl	w2, w1, #3
	and	x1, x2, #0x38
	add	x3, sp, #2, lsl #12             ; =8192
	add	x3, x3, #3840
	ldr	x4, [x3, x1]
	and	x2, x2, #0xf8
	add	x3, sp, #14, lsl #12            ; =57344
	add	x3, x3, #1384
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4, #32]
	ldp	q7, q16, [x4]
	mov	x5, #-2                         ; =0xfffffffffffffffe
	dup.2d	v17, x5
	bit.16b	v16, v17, v21
	bit.16b	v7, v17, v30
	bit.16b	v4, v17, v10
	bit.16b	v3, v17, v5
	stp	q3, q4, [x4, #32]
	stp	q7, q16, [x4]
Lloh322:
	adrp	x4, lCPI0_24@PAGE
Lloh323:
	ldr	q3, [x4, lCPI0_24@PAGEOFF]
Lloh324:
	adrp	x4, lCPI0_25@PAGE
Lloh325:
	ldr	q4, [x4, lCPI0_25@PAGEOFF]
	str	q3, [sp, #12144]
	str	q4, [sp, #12128]
Lloh326:
	adrp	x4, lCPI0_26@PAGE
Lloh327:
	ldr	q3, [x4, lCPI0_26@PAGEOFF]
Lloh328:
	adrp	x4, lCPI0_27@PAGE
Lloh329:
	ldr	q4, [x4, lCPI0_27@PAGEOFF]
	str	q3, [sp, #12112]
	str	q4, [sp, #12096]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #3904
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	orr.16b	v16, v5, v16
	orr.16b	v4, v21, v4
	orr.16b	v3, v30, v3
	orr.16b	v7, v10, v7
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh330:
	adrp	x4, lCPI0_28@PAGE
Lloh331:
	ldr	q3, [x4, lCPI0_28@PAGEOFF]
Lloh332:
	adrp	x4, lCPI0_29@PAGE
Lloh333:
	ldr	q4, [x4, lCPI0_29@PAGEOFF]
	str	q3, [sp, #12208]
	str	q4, [sp, #12192]
Lloh334:
	adrp	x4, lCPI0_30@PAGE
Lloh335:
	ldr	q3, [x4, lCPI0_30@PAGEOFF]
Lloh336:
	adrp	x4, lCPI0_31@PAGE
Lloh337:
	ldr	q4, [x4, lCPI0_31@PAGEOFF]
	str	q3, [sp, #12176]
	str	q4, [sp, #12160]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #3968
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	bic.16b	v16, v16, v5
	bic.16b	v4, v4, v21
	bic.16b	v3, v3, v30
	bic.16b	v7, v7, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh338:
	adrp	x4, lCPI0_32@PAGE
Lloh339:
	ldr	q3, [x4, lCPI0_32@PAGEOFF]
Lloh340:
	adrp	x4, lCPI0_33@PAGE
Lloh341:
	ldr	q4, [x4, lCPI0_33@PAGEOFF]
	str	q3, [sp, #12272]
	str	q4, [sp, #12256]
Lloh342:
	adrp	x4, lCPI0_34@PAGE
Lloh343:
	ldr	q3, [x4, lCPI0_34@PAGEOFF]
Lloh344:
	adrp	x4, lCPI0_35@PAGE
Lloh345:
	ldr	q4, [x4, lCPI0_35@PAGEOFF]
	str	q3, [sp, #12240]
	str	q4, [sp, #12224]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #4032
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	bic.16b	v16, v16, v5
	sub.2d	v16, v16, v5
	bic.16b	v4, v4, v21
	sub.2d	v4, v4, v21
	bic.16b	v3, v3, v30
	sub.2d	v3, v3, v30
	bic.16b	v7, v7, v10
	sub.2d	v7, v7, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh346:
	adrp	x4, lCPI0_36@PAGE
Lloh347:
	ldr	q3, [x4, lCPI0_36@PAGEOFF]
Lloh348:
	adrp	x4, lCPI0_37@PAGE
Lloh349:
	ldr	q4, [x4, lCPI0_37@PAGEOFF]
	str	q3, [sp, #12336]
	str	q4, [sp, #12320]
Lloh350:
	adrp	x4, lCPI0_38@PAGE
Lloh351:
	ldr	q3, [x4, lCPI0_38@PAGEOFF]
Lloh352:
	adrp	x4, lCPI0_39@PAGE
Lloh353:
	ldr	q4, [x4, lCPI0_39@PAGEOFF]
	str	q3, [sp, #12304]
	str	q4, [sp, #12288]
	add	x4, sp, #3, lsl #12             ; =12288
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #2                          ; =0x2
	dup.2d	v17, x5
	bit.16b	v16, v17, v5
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh354:
	adrp	x4, lCPI0_40@PAGE
Lloh355:
	ldr	q3, [x4, lCPI0_40@PAGEOFF]
Lloh356:
	adrp	x4, lCPI0_41@PAGE
Lloh357:
	ldr	q4, [x4, lCPI0_41@PAGEOFF]
	str	q3, [sp, #12400]
	str	q4, [sp, #12384]
Lloh358:
	adrp	x4, lCPI0_42@PAGE
Lloh359:
	ldr	q3, [x4, lCPI0_42@PAGEOFF]
Lloh360:
	adrp	x4, lCPI0_43@PAGE
Lloh361:
	ldr	q4, [x4, lCPI0_43@PAGEOFF]
	str	q3, [sp, #12368]
	str	q4, [sp, #12352]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #64
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #3                          ; =0x3
	dup.2d	v17, x5
	bit.16b	v16, v17, v5
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh362:
	adrp	x4, lCPI0_44@PAGE
Lloh363:
	ldr	q3, [x4, lCPI0_44@PAGEOFF]
Lloh364:
	adrp	x4, lCPI0_45@PAGE
Lloh365:
	ldr	q4, [x4, lCPI0_45@PAGEOFF]
	str	q3, [sp, #12464]
	str	q4, [sp, #12448]
Lloh366:
	adrp	x4, lCPI0_46@PAGE
Lloh367:
	ldr	q3, [x4, lCPI0_46@PAGEOFF]
Lloh368:
	adrp	x4, lCPI0_47@PAGE
Lloh369:
	ldr	q4, [x4, lCPI0_47@PAGEOFF]
	str	q3, [sp, #12432]
	str	q4, [sp, #12416]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #128
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #4                          ; =0x4
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v5
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v10
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh370:
	adrp	x4, lCPI0_48@PAGE
Lloh371:
	ldr	q3, [x4, lCPI0_48@PAGEOFF]
Lloh372:
	adrp	x4, lCPI0_49@PAGE
Lloh373:
	ldr	q4, [x4, lCPI0_49@PAGEOFF]
	str	q3, [sp, #12528]
	str	q4, [sp, #12512]
Lloh374:
	adrp	x4, lCPI0_50@PAGE
Lloh375:
	ldr	q3, [x4, lCPI0_50@PAGEOFF]
Lloh376:
	adrp	x4, lCPI0_51@PAGE
Lloh377:
	ldr	q4, [x4, lCPI0_51@PAGEOFF]
	str	q3, [sp, #12496]
	str	q4, [sp, #12480]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #192
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #5                          ; =0x5
	dup.2d	v17, x5
	bit.16b	v16, v17, v5
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh378:
	adrp	x4, lCPI0_52@PAGE
Lloh379:
	ldr	q3, [x4, lCPI0_52@PAGEOFF]
Lloh380:
	adrp	x4, lCPI0_53@PAGE
Lloh381:
	ldr	q4, [x4, lCPI0_53@PAGEOFF]
	str	q3, [sp, #12592]
	str	q4, [sp, #12576]
Lloh382:
	adrp	x4, lCPI0_54@PAGE
Lloh383:
	ldr	q3, [x4, lCPI0_54@PAGEOFF]
Lloh384:
	adrp	x4, lCPI0_55@PAGE
Lloh385:
	ldr	q4, [x4, lCPI0_55@PAGEOFF]
	str	q3, [sp, #12560]
	str	q4, [sp, #12544]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #256
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #6                          ; =0x6
	dup.2d	v17, x5
	bit.16b	v16, v17, v5
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh386:
	adrp	x4, lCPI0_56@PAGE
Lloh387:
	ldr	q3, [x4, lCPI0_56@PAGEOFF]
Lloh388:
	adrp	x4, lCPI0_57@PAGE
Lloh389:
	ldr	q4, [x4, lCPI0_57@PAGEOFF]
	str	q3, [sp, #12656]
	str	q4, [sp, #12640]
Lloh390:
	adrp	x4, lCPI0_58@PAGE
Lloh391:
	ldr	q3, [x4, lCPI0_58@PAGEOFF]
Lloh392:
	adrp	x4, lCPI0_59@PAGE
Lloh393:
	ldr	q4, [x4, lCPI0_59@PAGEOFF]
	str	q3, [sp, #12624]
	str	q4, [sp, #12608]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #320
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #7                          ; =0x7
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v5
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v10
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh394:
	adrp	x4, lCPI0_60@PAGE
Lloh395:
	ldr	q3, [x4, lCPI0_60@PAGEOFF]
Lloh396:
	adrp	x4, lCPI0_61@PAGE
Lloh397:
	ldr	q4, [x4, lCPI0_61@PAGEOFF]
	str	q3, [sp, #12720]
	str	q4, [sp, #12704]
Lloh398:
	adrp	x4, lCPI0_62@PAGE
Lloh399:
	ldr	q3, [x4, lCPI0_62@PAGEOFF]
Lloh400:
	adrp	x4, lCPI0_63@PAGE
Lloh401:
	ldr	q4, [x4, lCPI0_63@PAGEOFF]
	str	q3, [sp, #12688]
	str	q4, [sp, #12672]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #384
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #8                          ; =0x8
	dup.2d	v17, x5
	bit.16b	v16, v17, v5
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh402:
	adrp	x4, lCPI0_64@PAGE
Lloh403:
	ldr	q3, [x4, lCPI0_64@PAGEOFF]
Lloh404:
	adrp	x4, lCPI0_65@PAGE
Lloh405:
	ldr	q4, [x4, lCPI0_65@PAGEOFF]
	str	q3, [sp, #12784]
	str	q4, [sp, #12768]
Lloh406:
	adrp	x4, lCPI0_66@PAGE
Lloh407:
	ldr	q3, [x4, lCPI0_66@PAGEOFF]
Lloh408:
	adrp	x4, lCPI0_67@PAGE
Lloh409:
	ldr	q4, [x4, lCPI0_67@PAGEOFF]
	str	q3, [sp, #12752]
	str	q4, [sp, #12736]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #448
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #9                          ; =0x9
	dup.2d	v17, x5
	bit.16b	v16, v17, v5
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh410:
	adrp	x4, lCPI0_68@PAGE
Lloh411:
	ldr	q3, [x4, lCPI0_68@PAGEOFF]
Lloh412:
	adrp	x4, lCPI0_69@PAGE
Lloh413:
	ldr	q4, [x4, lCPI0_69@PAGEOFF]
	str	q3, [sp, #12848]
	str	q4, [sp, #12832]
Lloh414:
	adrp	x4, lCPI0_70@PAGE
Lloh415:
	ldr	q3, [x4, lCPI0_70@PAGEOFF]
Lloh416:
	adrp	x4, lCPI0_71@PAGE
Lloh417:
	ldr	q4, [x4, lCPI0_71@PAGEOFF]
	str	q3, [sp, #12816]
	str	q4, [sp, #12800]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #512
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #10                         ; =0xa
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v5
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v10
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh418:
	adrp	x4, lCPI0_72@PAGE
Lloh419:
	ldr	q3, [x4, lCPI0_72@PAGEOFF]
Lloh420:
	adrp	x4, lCPI0_73@PAGE
Lloh421:
	ldr	q4, [x4, lCPI0_73@PAGEOFF]
	str	q3, [sp, #12912]
	str	q4, [sp, #12896]
Lloh422:
	adrp	x4, lCPI0_74@PAGE
Lloh423:
	ldr	q3, [x4, lCPI0_74@PAGEOFF]
Lloh424:
	adrp	x4, lCPI0_75@PAGE
Lloh425:
	ldr	q4, [x4, lCPI0_75@PAGEOFF]
	str	q3, [sp, #12880]
	str	q4, [sp, #12864]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #576
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #11                         ; =0xb
	dup.2d	v17, x5
	bit.16b	v16, v17, v5
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh426:
	adrp	x4, lCPI0_76@PAGE
Lloh427:
	ldr	q3, [x4, lCPI0_76@PAGEOFF]
Lloh428:
	adrp	x4, lCPI0_77@PAGE
Lloh429:
	ldr	q4, [x4, lCPI0_77@PAGEOFF]
	str	q3, [sp, #12976]
	str	q4, [sp, #12960]
Lloh430:
	adrp	x4, lCPI0_78@PAGE
Lloh431:
	ldr	q3, [x4, lCPI0_78@PAGEOFF]
Lloh432:
	adrp	x4, lCPI0_79@PAGE
Lloh433:
	ldr	q4, [x4, lCPI0_79@PAGEOFF]
	str	q3, [sp, #12944]
	str	q4, [sp, #12928]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #640
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #12                         ; =0xc
	dup.2d	v17, x5
	bit.16b	v16, v17, v5
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh434:
	adrp	x4, lCPI0_80@PAGE
Lloh435:
	ldr	q3, [x4, lCPI0_80@PAGEOFF]
Lloh436:
	adrp	x4, lCPI0_81@PAGE
Lloh437:
	ldr	q4, [x4, lCPI0_81@PAGEOFF]
	str	q3, [sp, #13040]
	str	q4, [sp, #13024]
Lloh438:
	adrp	x4, lCPI0_82@PAGE
Lloh439:
	ldr	q3, [x4, lCPI0_82@PAGEOFF]
Lloh440:
	adrp	x4, lCPI0_83@PAGE
Lloh441:
	ldr	q4, [x4, lCPI0_83@PAGEOFF]
	str	q3, [sp, #13008]
	str	q4, [sp, #12992]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #704
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #13                         ; =0xd
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v5
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v10
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh442:
	adrp	x4, lCPI0_84@PAGE
Lloh443:
	ldr	q3, [x4, lCPI0_84@PAGEOFF]
Lloh444:
	adrp	x4, lCPI0_85@PAGE
Lloh445:
	ldr	q4, [x4, lCPI0_85@PAGEOFF]
	str	q3, [sp, #13104]
	str	q4, [sp, #13088]
Lloh446:
	adrp	x4, lCPI0_86@PAGE
Lloh447:
	ldr	q3, [x4, lCPI0_86@PAGEOFF]
Lloh448:
	adrp	x4, lCPI0_87@PAGE
Lloh449:
	ldr	q4, [x4, lCPI0_87@PAGEOFF]
	str	q3, [sp, #13072]
	str	q4, [sp, #13056]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #768
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #14                         ; =0xe
	dup.2d	v17, x5
	bit.16b	v16, v17, v5
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh450:
	adrp	x4, lCPI0_88@PAGE
Lloh451:
	ldr	q3, [x4, lCPI0_88@PAGEOFF]
Lloh452:
	adrp	x4, lCPI0_89@PAGE
Lloh453:
	ldr	q4, [x4, lCPI0_89@PAGEOFF]
	str	q3, [sp, #13168]
	str	q4, [sp, #13152]
Lloh454:
	adrp	x4, lCPI0_90@PAGE
Lloh455:
	ldr	q3, [x4, lCPI0_90@PAGEOFF]
Lloh456:
	adrp	x4, lCPI0_91@PAGE
Lloh457:
	ldr	q4, [x4, lCPI0_91@PAGEOFF]
	str	q3, [sp, #13136]
	str	q4, [sp, #13120]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #832
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #15                         ; =0xf
	dup.2d	v17, x5
	bit.16b	v16, v17, v5
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh458:
	adrp	x4, lCPI0_92@PAGE
Lloh459:
	ldr	q3, [x4, lCPI0_92@PAGEOFF]
Lloh460:
	adrp	x4, lCPI0_93@PAGE
Lloh461:
	ldr	q4, [x4, lCPI0_93@PAGEOFF]
	str	q3, [sp, #13232]
	str	q4, [sp, #13216]
Lloh462:
	adrp	x4, lCPI0_94@PAGE
Lloh463:
	ldr	q3, [x4, lCPI0_94@PAGEOFF]
Lloh464:
	adrp	x4, lCPI0_95@PAGE
Lloh465:
	ldr	q4, [x4, lCPI0_95@PAGEOFF]
	str	q3, [sp, #13200]
	str	q4, [sp, #13184]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #896
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #16                         ; =0x10
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v5
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v10
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh466:
	adrp	x4, lCPI0_96@PAGE
Lloh467:
	ldr	q3, [x4, lCPI0_96@PAGEOFF]
Lloh468:
	adrp	x4, lCPI0_97@PAGE
Lloh469:
	ldr	q4, [x4, lCPI0_97@PAGEOFF]
	str	q3, [sp, #13296]
	str	q4, [sp, #13280]
Lloh470:
	adrp	x4, lCPI0_98@PAGE
Lloh471:
	ldr	q3, [x4, lCPI0_98@PAGEOFF]
Lloh472:
	adrp	x4, lCPI0_99@PAGE
Lloh473:
	ldr	q4, [x4, lCPI0_99@PAGEOFF]
	str	q3, [sp, #13264]
	str	q4, [sp, #13248]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #960
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #17                         ; =0x11
	dup.2d	v17, x5
	bit.16b	v16, v17, v5
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh474:
	adrp	x4, lCPI0_100@PAGE
Lloh475:
	ldr	q3, [x4, lCPI0_100@PAGEOFF]
Lloh476:
	adrp	x4, lCPI0_101@PAGE
Lloh477:
	ldr	q4, [x4, lCPI0_101@PAGEOFF]
	str	q3, [sp, #13360]
	str	q4, [sp, #13344]
Lloh478:
	adrp	x4, lCPI0_102@PAGE
Lloh479:
	ldr	q3, [x4, lCPI0_102@PAGEOFF]
Lloh480:
	adrp	x4, lCPI0_103@PAGE
Lloh481:
	ldr	q4, [x4, lCPI0_103@PAGEOFF]
	str	q3, [sp, #13328]
	str	q4, [sp, #13312]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #1024
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #18                         ; =0x12
	dup.2d	v17, x5
	bit.16b	v16, v17, v5
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh482:
	adrp	x4, lCPI0_104@PAGE
Lloh483:
	ldr	q3, [x4, lCPI0_104@PAGEOFF]
Lloh484:
	adrp	x4, lCPI0_105@PAGE
Lloh485:
	ldr	q4, [x4, lCPI0_105@PAGEOFF]
	str	q3, [sp, #13424]
	str	q4, [sp, #13408]
Lloh486:
	adrp	x4, lCPI0_106@PAGE
Lloh487:
	ldr	q3, [x4, lCPI0_106@PAGEOFF]
Lloh488:
	adrp	x4, lCPI0_107@PAGE
Lloh489:
	ldr	q4, [x4, lCPI0_107@PAGEOFF]
	str	q3, [sp, #13392]
	str	q4, [sp, #13376]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #1088
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #19                         ; =0x13
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v5
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v10
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh490:
	adrp	x4, lCPI0_108@PAGE
Lloh491:
	ldr	q3, [x4, lCPI0_108@PAGEOFF]
Lloh492:
	adrp	x4, lCPI0_109@PAGE
Lloh493:
	ldr	q4, [x4, lCPI0_109@PAGEOFF]
	str	q3, [sp, #13488]
	str	q4, [sp, #13472]
Lloh494:
	adrp	x4, lCPI0_110@PAGE
Lloh495:
	ldr	q3, [x4, lCPI0_110@PAGEOFF]
Lloh496:
	adrp	x4, lCPI0_111@PAGE
Lloh497:
	ldr	q4, [x4, lCPI0_111@PAGEOFF]
	str	q3, [sp, #13456]
	str	q4, [sp, #13440]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #1152
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #20                         ; =0x14
	dup.2d	v17, x5
	bit.16b	v16, v17, v5
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh498:
	adrp	x4, lCPI0_112@PAGE
Lloh499:
	ldr	q3, [x4, lCPI0_112@PAGEOFF]
Lloh500:
	adrp	x4, lCPI0_113@PAGE
Lloh501:
	ldr	q4, [x4, lCPI0_113@PAGEOFF]
	str	q3, [sp, #13552]
	str	q4, [sp, #13536]
Lloh502:
	adrp	x4, lCPI0_114@PAGE
Lloh503:
	ldr	q3, [x4, lCPI0_114@PAGEOFF]
Lloh504:
	adrp	x4, lCPI0_115@PAGE
Lloh505:
	ldr	q4, [x4, lCPI0_115@PAGEOFF]
	str	q3, [sp, #13520]
	str	q4, [sp, #13504]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #1216
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #21                         ; =0x15
	dup.2d	v17, x5
	bit.16b	v16, v17, v5
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh506:
	adrp	x4, lCPI0_116@PAGE
Lloh507:
	ldr	q3, [x4, lCPI0_116@PAGEOFF]
Lloh508:
	adrp	x4, lCPI0_117@PAGE
Lloh509:
	ldr	q4, [x4, lCPI0_117@PAGEOFF]
	str	q3, [sp, #13616]
	str	q4, [sp, #13600]
Lloh510:
	adrp	x4, lCPI0_118@PAGE
Lloh511:
	ldr	q3, [x4, lCPI0_118@PAGEOFF]
Lloh512:
	adrp	x4, lCPI0_119@PAGE
Lloh513:
	ldr	q4, [x4, lCPI0_119@PAGEOFF]
	str	q3, [sp, #13584]
	str	q4, [sp, #13568]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #1280
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #22                         ; =0x16
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v5
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v10
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh514:
	adrp	x4, lCPI0_120@PAGE
Lloh515:
	ldr	q3, [x4, lCPI0_120@PAGEOFF]
Lloh516:
	adrp	x4, lCPI0_121@PAGE
Lloh517:
	ldr	q4, [x4, lCPI0_121@PAGEOFF]
	str	q3, [sp, #13680]
	str	q4, [sp, #13664]
Lloh518:
	adrp	x4, lCPI0_122@PAGE
Lloh519:
	ldr	q3, [x4, lCPI0_122@PAGEOFF]
Lloh520:
	adrp	x4, lCPI0_123@PAGE
Lloh521:
	ldr	q4, [x4, lCPI0_123@PAGEOFF]
	str	q3, [sp, #13648]
	str	q4, [sp, #13632]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #1344
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #23                         ; =0x17
	dup.2d	v17, x5
	bit.16b	v16, v17, v5
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh522:
	adrp	x4, lCPI0_124@PAGE
Lloh523:
	ldr	q3, [x4, lCPI0_124@PAGEOFF]
Lloh524:
	adrp	x4, lCPI0_125@PAGE
Lloh525:
	ldr	q4, [x4, lCPI0_125@PAGEOFF]
	str	q3, [sp, #13744]
	str	q4, [sp, #13728]
Lloh526:
	adrp	x4, lCPI0_126@PAGE
Lloh527:
	ldr	q3, [x4, lCPI0_126@PAGEOFF]
Lloh528:
	adrp	x4, lCPI0_127@PAGE
Lloh529:
	ldr	q4, [x4, lCPI0_127@PAGEOFF]
	str	q3, [sp, #13712]
	str	q4, [sp, #13696]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #1408
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #24                         ; =0x18
	dup.2d	v17, x5
	bit.16b	v16, v17, v5
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh530:
	adrp	x4, lCPI0_128@PAGE
Lloh531:
	ldr	q3, [x4, lCPI0_128@PAGEOFF]
Lloh532:
	adrp	x4, lCPI0_129@PAGE
Lloh533:
	ldr	q4, [x4, lCPI0_129@PAGEOFF]
	str	q3, [sp, #13808]
	str	q4, [sp, #13792]
Lloh534:
	adrp	x4, lCPI0_130@PAGE
Lloh535:
	ldr	q3, [x4, lCPI0_130@PAGEOFF]
Lloh536:
	adrp	x4, lCPI0_131@PAGE
Lloh537:
	ldr	q4, [x4, lCPI0_131@PAGEOFF]
	str	q3, [sp, #13776]
	str	q4, [sp, #13760]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #1472
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #25                         ; =0x19
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v5
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v10
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh538:
	adrp	x4, lCPI0_132@PAGE
Lloh539:
	ldr	q3, [x4, lCPI0_132@PAGEOFF]
Lloh540:
	adrp	x4, lCPI0_133@PAGE
Lloh541:
	ldr	q4, [x4, lCPI0_133@PAGEOFF]
	str	q3, [sp, #13872]
	str	q4, [sp, #13856]
Lloh542:
	adrp	x4, lCPI0_134@PAGE
Lloh543:
	ldr	q3, [x4, lCPI0_134@PAGEOFF]
Lloh544:
	adrp	x4, lCPI0_135@PAGE
Lloh545:
	ldr	q4, [x4, lCPI0_135@PAGEOFF]
	str	q3, [sp, #13840]
	str	q4, [sp, #13824]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #1536
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #26                         ; =0x1a
	dup.2d	v17, x5
	bit.16b	v16, v17, v5
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh546:
	adrp	x4, lCPI0_136@PAGE
Lloh547:
	ldr	q3, [x4, lCPI0_136@PAGEOFF]
Lloh548:
	adrp	x4, lCPI0_137@PAGE
Lloh549:
	ldr	q4, [x4, lCPI0_137@PAGEOFF]
	str	q3, [sp, #13936]
	str	q4, [sp, #13920]
Lloh550:
	adrp	x4, lCPI0_138@PAGE
Lloh551:
	ldr	q3, [x4, lCPI0_138@PAGEOFF]
Lloh552:
	adrp	x4, lCPI0_139@PAGE
Lloh553:
	ldr	q4, [x4, lCPI0_139@PAGEOFF]
	str	q3, [sp, #13904]
	str	q4, [sp, #13888]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #1600
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #27                         ; =0x1b
	dup.2d	v17, x5
	bit.16b	v16, v17, v5
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh554:
	adrp	x4, lCPI0_140@PAGE
Lloh555:
	ldr	q3, [x4, lCPI0_140@PAGEOFF]
Lloh556:
	adrp	x4, lCPI0_141@PAGE
Lloh557:
	ldr	q4, [x4, lCPI0_141@PAGEOFF]
	str	q3, [sp, #14000]
	str	q4, [sp, #13984]
Lloh558:
	adrp	x4, lCPI0_142@PAGE
Lloh559:
	ldr	q3, [x4, lCPI0_142@PAGEOFF]
Lloh560:
	adrp	x4, lCPI0_143@PAGE
Lloh561:
	ldr	q4, [x4, lCPI0_143@PAGEOFF]
	str	q3, [sp, #13968]
	str	q4, [sp, #13952]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #1664
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #28                         ; =0x1c
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v5
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v10
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh562:
	adrp	x4, lCPI0_144@PAGE
Lloh563:
	ldr	q3, [x4, lCPI0_144@PAGEOFF]
Lloh564:
	adrp	x4, lCPI0_145@PAGE
Lloh565:
	ldr	q4, [x4, lCPI0_145@PAGEOFF]
	str	q3, [sp, #14064]
	str	q4, [sp, #14048]
Lloh566:
	adrp	x4, lCPI0_146@PAGE
Lloh567:
	ldr	q3, [x4, lCPI0_146@PAGEOFF]
Lloh568:
	adrp	x4, lCPI0_147@PAGE
Lloh569:
	ldr	q4, [x4, lCPI0_147@PAGEOFF]
	str	q3, [sp, #14032]
	str	q4, [sp, #14016]
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #1728
	ldr	x1, [x4, x1]
	sub	x1, x1, x2
	add	x1, x3, x1
	ldp	q3, q4, [x1]
	ldp	q16, q7, [x1, #32]
	mov	w2, #29                         ; =0x1d
	dup.2d	v17, x2
	bit.16b	v16, v17, v5
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x1]
	stp	q16, q7, [x1, #32]
	ldr	q3, [sp, #18528]
	ldr	q4, [sp, #18544]
	ldr	q7, [sp, #18496]
	ldr	q16, [sp, #18512]
	ldr	q17, [sp, #18464]
	ldr	q18, [sp, #18480]
	ldr	q19, [sp, #18432]
	ldr	q26, [sp, #18448]
	ldr	q27, [sp, #272]                 ; 16-byte Folded Reload
	bit.16b	v26, v27, v21
	bit.16b	v19, v27, v30
	bit.16b	v18, v27, v10
	bit.16b	v17, v27, v5
Lloh570:
	adrp	x1, lCPI0_17@PAGE
Lloh571:
	ldr	q27, [x1, lCPI0_17@PAGEOFF]
	bit.16b	v16, v27, v21
Lloh572:
	adrp	x1, lCPI0_16@PAGE
Lloh573:
	ldr	q27, [x1, lCPI0_16@PAGEOFF]
	bit.16b	v7, v27, v30
Lloh574:
	adrp	x1, lCPI0_19@PAGE
Lloh575:
	ldr	q27, [x1, lCPI0_19@PAGEOFF]
	bit.16b	v4, v27, v10
Lloh576:
	adrp	x1, lCPI0_18@PAGE
Lloh577:
	ldr	q27, [x1, lCPI0_18@PAGEOFF]
	bit.16b	v3, v27, v5
	str	q3, [sp, #18528]
	str	q4, [sp, #18544]
	str	q7, [sp, #18496]
	str	q16, [sp, #18512]
	str	q17, [sp, #18464]
	str	q18, [sp, #18480]
	str	q19, [sp, #18432]
	str	q26, [sp, #18448]
	ldp	q4, q1, [sp, #944]              ; 32-byte Folded Reload
	bic.16b	v3, v4, v10
	bic.16b	v1, v1, v5
	stp	q3, q1, [sp, #944]              ; 32-byte Folded Spill
	ldp	q4, q1, [sp, #976]              ; 32-byte Folded Reload
	bic.16b	v3, v4, v21
	bic.16b	v1, v1, v30
	stp	q3, q1, [sp, #976]              ; 32-byte Folded Spill
	ldr	q31, [sp, #1456]                ; 16-byte Folded Reload
LBB0_378:                               ; %schedule.16
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	mov	w1, #128                        ; =0x80
	dup.2d	v5, x1
	ldp	q6, q1, [sp, #976]              ; 32-byte Folded Reload
	cmgt.2d	v3, v5, v6
	cmgt.2d	v4, v5, v1
	uzp1.4s	v3, v4, v3
	ldp	q17, q7, [sp, #944]             ; 32-byte Folded Reload
	cmgt.2d	v4, v5, v7
	cmgt.2d	v16, v5, v17
	uzp1.4s	v4, v4, v16
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v21, v20, v3
	shl.8b	v3, v21, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w1, s4
	umaxv.8b	b3, v3
	fmov	w3, s3
	tbz	w3, #0, LBB0_384
; %bb.379:                              ; %schedule.16
                                        ;   in Loop: Header=BB0_8 Depth=3
	cmge.2d	v3, v6, v5
	cmge.2d	v4, v1, v5
	uzp1.4s	v3, v4, v3
	cmge.2d	v4, v7, v5
	cmge.2d	v5, v17, v5
	uzp1.4s	v4, v4, v5
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v10, v20, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_384
; %bb.380:                              ; %varying.divergent404
                                        ;   in Loop: Header=BB0_8 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	str	q24, [sp, #2816]
	str	q12, [sp, #2832]
	and	x1, x1, #0x7
	add	x3, sp, #2816
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #6, #0, ne
	cset	w1, ne
	cmp	w2, #255
	b.ne	LBB0_382
; %bb.381:                              ; %varying.divergent404
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #0, LBB0_382
	b	LBB0_1086
LBB0_382:                               ; %convergence.overflow.resume407
                                        ;   in Loop: Header=BB0_8 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #18, lsl #12            ; =73728
	add	x2, x2, #1520
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s5, w4
	ubfx	w4, w5, #1, #1
	mov.b	v5[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v5[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v5[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v5[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v5[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v5[6], w4
	add	x4, sp, #18, lsl #12            ; =73728
	add	x4, x4, #1512
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v4, w5
	bit.8b	v5, v20, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x2, w3, uxtw]
	bic.8b	v3, v3, v4
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_1086
; %bb.383:                              ; %ready.overflow.resume409
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q23, [sp, #2784]
	str	q11, [sp, #2800]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #2784
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q23, [sp, #2752]
	str	q11, [sp, #2768]
	add	x5, sp, #2752
	str	w4, [x5, x2]
	ldr	q11, [sp, #2768]
	ldr	q23, [sp, #2752]
	str	q24, [sp, #2720]
	str	q12, [sp, #2736]
	add	x4, sp, #2720
	ldr	w4, [x4, x2]
	mov	w5, #6                          ; =0x6
	csel	w4, w5, w4, ne
	str	q24, [sp, #2688]
	str	q12, [sp, #2704]
	add	x5, sp, #2688
	str	w4, [x5, x2]
	mov	w2, #20                         ; =0x14
	mov	w4, #17                         ; =0x11
	ldr	q12, [sp, #2704]
	ldr	q24, [sp, #2688]
	b	LBB0_6
LBB0_384:                               ; %varying.coherent405
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w1, #0xff
	b.eq	LBB0_446
; %bb.385:                              ; %varying.coherent.true410
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
	tst	w2, #0xff
	b.eq	LBB0_1063
LBB0_386:                               ; %schedule.17
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v8, v31
	str	q13, [sp, #1456]                ; 16-byte Folded Spill
	str	q29, [sp, #1472]                ; 16-byte Folded Spill
	str	q0, [sp, #1488]                 ; 16-byte Folded Spill
	mov.16b	v1, v22
	mov.16b	v4, v9
	mov.16b	v9, v24
	mov.16b	v24, v12
	mov.16b	v29, v23
	mov.16b	v23, v11
	str	q4, [sp, #1504]                 ; 16-byte Folded Spill
	mov.16b	v22, v25
	str	q1, [sp, #1232]                 ; 16-byte Folded Spill
	str	q14, [sp, #1440]                ; 16-byte Folded Spill
	ldr	q7, [sp, #928]                  ; 16-byte Folded Reload
	mov	b3, v20[0]
	mov.b	v3[4], v20[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldp	q1, q0, [sp, #976]              ; 32-byte Folded Reload
	and.16b	v16, v3, v0
	mov	b4, v20[2]
	mov.b	v4[4], v20[3]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	and.16b	v17, v4, v1
	mov	b5, v20[4]
	mov.b	v5[4], v20[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v27, v5, #0
	ldp	q1, q0, [sp, #944]              ; 32-byte Folded Reload
	and.16b	v18, v27, v0
	mov	b5, v20[6]
	mov.b	v5[4], v20[7]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v30, v5, #0
	and.16b	v19, v30, v1
	shl.8b	v5, v20, #7
	cmlt.8b	v21, v5, #0
	and.8b	v5, v21, v2
	addv.8b	b5, v5
	fmov	w2, s5
	mov	w3, #32                         ; =0x20
	dup.2d	v31, x3
	and.16b	v26, v3, v31
	mvn.16b	v3, v3
	sub.2d	v26, v26, v3
	and.16b	v3, v4, v31
	mvn.16b	v4, v4
	sub.2d	v11, v3, v4
	and.16b	v3, v27, v31
	and.16b	v4, v30, v31
	mvn.16b	v30, v30
	sub.2d	v4, v4, v30
	mov.d	x3, v4[1]
	mov.d	x4, v19[1]
	sdiv	x4, x4, x3
	mvn.16b	v27, v27
	sub.2d	v3, v3, v27
	fmov	x5, d4
	fmov	x6, d19
	sdiv	x6, x6, x5
	mul	x5, x6, x5
	fmov	d30, x6
	mov.d	v30[1], x4
	mov.d	x6, v3[1]
	mov.d	x7, v18[1]
	sdiv	x7, x7, x6
	fmov	x19, d3
	fmov	x20, d18
	sdiv	x20, x20, x19
	mul	x19, x20, x19
	fmov	d10, x20
	mov.d	v10[1], x7
	mov.d	x20, v11[1]
	mov.d	x21, v17[1]
	sdiv	x21, x21, x20
	fmov	x22, d11
	fmov	x23, d17
	sdiv	x23, x23, x22
	mul	x22, x23, x22
	fmov	d11, x23
	mov.d	v11[1], x21
	mov.d	x23, v26[1]
	mov.d	x24, v16[1]
	fmov	x25, d26
	fmov	x26, d16
	sdiv	x26, x26, x25
	mul	x25, x26, x25
	fmov	d12, x26
	sdiv	x24, x24, x23
	mov.d	v12[1], x24
	mul	x3, x4, x3
	fmov	d3, x5
	mov.d	v3[1], x3
	mul	x3, x7, x6
	fmov	d4, x19
	mov.d	v4[1], x3
	mul	x3, x21, x20
	fmov	d26, x22
	mov.d	v26[1], x3
	mul	x3, x24, x23
	fmov	d27, x25
	mov.d	v27[1], x3
	sub.2d	v16, v16, v27
	sub.2d	v17, v17, v26
	sub.2d	v4, v18, v4
	sub.2d	v3, v19, v3
	ldr	q27, [sp, #18560]
	ldr	q26, [sp, #18576]
	ldr	q19, [sp, #18592]
	ldr	q18, [sp, #18608]
	ldr	q31, [sp, #18672]
	ldr	q13, [sp, #18656]
	ldr	q14, [sp, #18640]
	shl.2d	v3, v3, #6
	shl.2d	v4, v4, #6
	shl.2d	v17, v17, #6
	shl.2d	v16, v16, #6
	ldr	q15, [sp, #18624]
	add.2d	v18, v18, v31
	add.2d	v18, v18, v3
	add.2d	v3, v19, v13
	add.2d	v19, v3, v4
	add.2d	v3, v26, v14
	add.2d	v26, v3, v17
	add.2d	v3, v27, v15
	add.2d	v27, v3, v16
	movi.2d	v13, #0000000000000000
	movi.2d	v14, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	str	q7, [sp, #928]                  ; 16-byte Folded Spill
	tbz	w2, #0, LBB0_394
; %bb.387:                              ; %cond.load4483
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d27
	ldr	d13, [x3]
	tbnz	w2, #1, LBB0_395
LBB0_388:                               ; %else4493
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v31, v8
	tbz	w2, #2, LBB0_396
LBB0_389:                               ; %cond.load4495
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d26
	ld1.d	{ v14 }[0], [x3]
	tbnz	w2, #3, LBB0_397
LBB0_390:                               ; %else4505
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #4, LBB0_398
LBB0_391:                               ; %cond.load4507
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d19
	ld1.d	{ v16 }[0], [x3]
	tbnz	w2, #5, LBB0_399
LBB0_392:                               ; %else4517
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #6, LBB0_400
LBB0_393:                               ; %cond.load4519
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d18
	ld1.d	{ v17 }[0], [x3]
	tbnz	w2, #7, LBB0_401
	b	LBB0_402
LBB0_394:                               ; %else4487
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #1, LBB0_388
LBB0_395:                               ; %cond.load4489
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v27[1]
	ld1.d	{ v13 }[1], [x3]
	mov.16b	v31, v8
	tbnz	w2, #2, LBB0_389
LBB0_396:                               ; %else4499
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #3, LBB0_390
LBB0_397:                               ; %cond.load4501
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v26[1]
	ld1.d	{ v14 }[1], [x3]
	tbnz	w2, #4, LBB0_391
LBB0_398:                               ; %else4511
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #5, LBB0_392
LBB0_399:                               ; %cond.load4513
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v19[1]
	ld1.d	{ v16 }[1], [x3]
	tbnz	w2, #6, LBB0_393
LBB0_400:                               ; %else4523
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #7, LBB0_402
LBB0_401:                               ; %cond.load4525
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v18[1]
	ld1.d	{ v17 }[1], [x2]
LBB0_402:                               ; %else4529
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w2, #32                         ; =0x20
	dup.2d	v3, x2
	cmhi.2d	v4, v3, v14
	cmhi.2d	v18, v3, v13
	uzp1.4s	v4, v18, v4
	cmhi.2d	v18, v3, v16
	cmhi.2d	v3, v3, v17
	uzp1.4s	v3, v18, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	ldrb	w2, [x9, #1536]
	and	w3, w2, #0x1
	fmov	s4, w3
	ubfx	w3, w2, #1, #1
	mov.b	v4[1], w3
	ubfx	w3, w2, #2, #1
	mov.b	v4[2], w3
	ubfx	w3, w2, #3, #1
	mov.b	v4[3], w3
	ubfx	w3, w2, #4, #1
	mov.b	v4[4], w3
	ubfx	w3, w2, #5, #1
	mov.b	v4[5], w3
	ubfx	w3, w2, #6, #1
	mov.b	v4[6], w3
	lsr	w2, w2, #7
	mov.b	v4[7], w2
	bif.8b	v3, v4, v21
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x9, #1536]
	shl.2d	v3, v11, #5
	shl.2d	v4, v12, #5
	shl.2d	v18, v30, #5
	shl.2d	v19, v10, #5
	add.2d	v16, v16, v19
	add.2d	v17, v17, v18
	add.2d	v18, v13, v4
	add.2d	v19, v14, v3
	ldr	q3, [sp, #18336]
	ldr	q4, [sp, #18352]
	ldr	q21, [sp, #18304]
	ldr	q26, [sp, #18320]
	mov	b27, v20[2]
	mov.b	v27[4], v20[3]
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	mov	b30, v20[0]
	mov.b	v30[4], v20[1]
	bit.16b	v26, v19, v27
	ushll.2d	v27, v30, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	bit.16b	v21, v18, v27
	mov	b27, v20[6]
	mov.b	v27[4], v20[7]
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	bit.16b	v4, v17, v27
	mov	b27, v20[4]
	mov.b	v27[4], v20[5]
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	bit.16b	v3, v16, v27
	str	q3, [sp, #18336]
	str	q4, [sp, #18352]
	str	q21, [sp, #18304]
	str	q26, [sp, #18320]
	mov	w2, #128                        ; =0x80
	dup.2d	v26, x2
	cmhi.2d	v3, v26, v18
	cmhi.2d	v4, v26, v19
	uzp1.4s	v3, v3, v4
	cmhi.2d	v4, v26, v16
	cmhi.2d	v21, v26, v17
	uzp1.4s	v4, v4, v21
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v21, v20, v3
	shl.8b	v3, v21, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w2, s4
	umaxv.8b	b3, v3
	fmov	w3, s3
	tbz	w3, #0, LBB0_408
; %bb.403:                              ; %else4529
                                        ;   in Loop: Header=BB0_8 Depth=3
	cmhs.2d	v3, v18, v26
	cmhs.2d	v4, v19, v26
	uzp1.4s	v3, v3, v4
	cmhs.2d	v4, v16, v26
	cmhs.2d	v16, v17, v26
	uzp1.4s	v4, v4, v16
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v10, v20, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_408
; %bb.404:                              ; %varying.divergent415
                                        ;   in Loop: Header=BB0_8 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	str	q9, [sp, #2976]
	str	q24, [sp, #2992]
	and	x1, x1, #0x7
	add	x3, sp, #2976
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #7, #0, ne
	cset	w1, ne
	cmp	w2, #255
	mov.16b	v25, v22
	b.ne	LBB0_406
; %bb.405:                              ; %varying.divergent415
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #0, LBB0_406
	b	LBB0_1086
LBB0_406:                               ; %convergence.overflow.resume418
                                        ;   in Loop: Header=BB0_8 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #18, lsl #12            ; =73728
	add	x2, x2, #1520
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s5, w4
	ubfx	w4, w5, #1, #1
	mov.b	v5[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v5[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v5[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v5[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v5[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v5[6], w4
	add	x4, sp, #18, lsl #12            ; =73728
	add	x4, x4, #1512
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v4, w5
	bit.8b	v5, v20, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x2, w3, uxtw]
	bic.8b	v3, v3, v4
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_1086
; %bb.407:                              ; %ready.overflow.resume420
                                        ;   in Loop: Header=BB0_8 Depth=3
	zip2.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldp	q5, q1, [sp, #448]              ; 32-byte Folded Reload
	and.16b	v4, v3, v5
	zip1.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v1, v3, v1
	stp	q4, q1, [sp, #448]              ; 32-byte Folded Spill
	str	q29, [sp, #2944]
	str	q23, [sp, #2960]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #2944
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q29, [sp, #2912]
	str	q23, [sp, #2928]
	add	x5, sp, #2912
	str	w4, [x5, x2]
	ldr	q11, [sp, #2928]
	ldr	q23, [sp, #2912]
	str	q9, [sp, #2880]
	str	q24, [sp, #2896]
	add	x4, sp, #2880
	ldr	w4, [x4, x2]
	mov	w5, #7                          ; =0x7
	csel	w4, w5, w4, ne
	str	q9, [sp, #2848]
	str	q24, [sp, #2864]
	add	x5, sp, #2848
	str	w4, [x5, x2]
	mov	w2, #19                         ; =0x13
	mov	w4, #18                         ; =0x12
	ldr	q12, [sp, #2864]
	ldr	q24, [sp, #2848]
	b	LBB0_456
LBB0_408:                               ; %varying.coherent416
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	mov.16b	v25, v22
	mov.16b	v12, v24
	b.eq	LBB0_455
; %bb.409:                              ; %varying.coherent.true421
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v24, v9
	tbz	w1, #0, LBB0_410
	b	LBB0_1059
LBB0_410:                               ; %schedule.18.thread
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q3, [sp, #18688]
	ldr	q4, [sp, #18704]
	ldr	q7, [sp, #18720]
	ldr	q16, [sp, #18736]
	ldr	q17, [sp, #18800]
	ldr	q18, [sp, #18784]
	ldr	q19, [sp, #18768]
	ldr	q21, [sp, #18752]
	ldr	q26, [sp, #18304]
	ldr	q27, [sp, #18320]
	ldr	q30, [sp, #18336]
	ldr	q31, [sp, #18352]
	shl.2d	v31, v31, #5
	shl.2d	v30, v30, #5
	shl.2d	v27, v27, #5
	shl.2d	v26, v26, #5
	add.2d	v16, v16, v17
	add.2d	v17, v16, v31
	add.2d	v7, v7, v18
	add.2d	v18, v7, v30
	add.2d	v4, v4, v19
	add.2d	v19, v4, v27
	add.2d	v3, v3, v21
	add.2d	v21, v3, v26
	fmov	w1, s5
	movi.2d	v5, #0000000000000000
	movi.2d	v16, #0000000000000000
	ldr	q6, [sp, #1200]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #1184]                 ; 16-byte Folded Reload
	mov.16b	v11, v23
	ldr	q3, [sp, #1488]                 ; 16-byte Folded Reload
	ldr	q13, [sp, #1456]                ; 16-byte Folded Reload
	tbz	w1, #0, LBB0_412
; %bb.411:                              ; %cond.load5694
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d21
	ldr	s5, [x2]
LBB0_412:                               ; %else5698
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q7, [sp, #1216]                 ; 16-byte Folded Reload
	ldr	q4, [sp, #1360]                 ; 16-byte Folded Reload
	ldr	q9, [sp, #1504]                 ; 16-byte Folded Reload
	mov.16b	v23, v29
	ldr	q29, [sp, #1472]                ; 16-byte Folded Reload
	str	q4, [sp, #1360]                 ; 16-byte Folded Spill
	str	q7, [sp, #1216]                 ; 16-byte Folded Spill
	str	q0, [sp, #1184]                 ; 16-byte Folded Spill
	str	q6, [sp, #1200]                 ; 16-byte Folded Spill
	tbz	w1, #1, LBB0_414
; %bb.413:                              ; %cond.load5700
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v21[1]
	ld1.s	{ v5 }[1], [x2]
LBB0_414:                               ; %else5704
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q22, [sp, #1232]                ; 16-byte Folded Reload
	ldr	q0, [sp, #1040]                 ; 16-byte Folded Reload
	mov.16b	v31, v8
	str	q0, [sp, #1040]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #1056]                 ; 16-byte Folded Reload
	ldr	q14, [sp, #1440]                ; 16-byte Folded Reload
	tbz	w1, #2, LBB0_420
; %bb.415:                              ; %cond.load5706
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d19
	ld1.s	{ v5 }[2], [x2]
	mov.16b	v0, v3
	tbnz	w1, #3, LBB0_421
LBB0_416:                               ; %else5716
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #4, LBB0_422
LBB0_417:                               ; %cond.load5718
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d18
	ld1.s	{ v16 }[0], [x2]
	tbnz	w1, #5, LBB0_423
LBB0_418:                               ; %else5728
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #6, LBB0_424
LBB0_419:                               ; %cond.load5730
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d17
	ld1.s	{ v16 }[2], [x2]
	str	q1, [sp, #1056]                 ; 16-byte Folded Spill
	tbnz	w1, #7, LBB0_425
	b	LBB0_426
LBB0_420:                               ; %else5710
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v0, v3
	tbz	w1, #3, LBB0_416
LBB0_421:                               ; %cond.load5712
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v19[1]
	ld1.s	{ v5 }[3], [x2]
	tbnz	w1, #4, LBB0_417
LBB0_422:                               ; %else5722
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #5, LBB0_418
LBB0_423:                               ; %cond.load5724
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v18[1]
	ld1.s	{ v16 }[1], [x2]
	tbnz	w1, #6, LBB0_419
LBB0_424:                               ; %else5734
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q1, [sp, #1056]                 ; 16-byte Folded Spill
	tbz	w1, #7, LBB0_426
LBB0_425:                               ; %cond.load5736
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x1, v17[1]
	ld1.s	{ v16 }[3], [x1]
LBB0_426:                               ; %else5740
                                        ;   in Loop: Header=BB0_8 Depth=3
	zip2.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q1, [sp, #448]                  ; 16-byte Folded Reload
	bit.16b	v1, v16, v3
	str	q1, [sp, #448]                  ; 16-byte Folded Spill
	zip1.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q1, [sp, #464]                  ; 16-byte Folded Reload
	bit.16b	v1, v5, v3
	str	q1, [sp, #464]                  ; 16-byte Folded Spill
	mov.16b	v6, v31
	cbnz	w0, LBB0_159
LBB0_427:                               ; %schedule.19.convergence.cascade.exit426_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_428:                               ; %convergence.cascade.exit426
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1046
; %bb.429:                              ; %convergence.target.19.ready
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q1, [sp, #704]                  ; 16-byte Folded Reload
	dup.4s	v3, v1[0]
	ldrb	w1, [x9, #1536]
	ubfx	w2, w1, #3, #1
	ubfx	w3, w1, #2, #1
	ubfx	w4, w1, #1, #1
	and	w5, w1, #0x1
	lsr	w6, w1, #7
	ubfx	w7, w1, #6, #1
	ubfx	w19, w1, #5, #1
	ubfx	w1, w1, #4, #1
	fmov	s4, w1
	mov.h	v4[1], w19
	mov.h	v4[2], w7
	mov.h	v4[3], w6
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	fmov	s7, w5
	mov.h	v7[1], w4
	mov.h	v7[2], w3
	mov.h	v7[3], w2
	ldr	q1, [sp, #448]                  ; 16-byte Folded Reload
	mov.16b	v5, v4
	bsl.16b	v5, v1, v3
	ushll.4s	v4, v7, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q1, [sp, #464]                  ; 16-byte Folded Reload
	mov.16b	v17, v4
	bsl.16b	v17, v1, v3
	ldr	q3, [sp, #18480]
	ldr	q4, [sp, #18464]
	ldr	q7, [sp, #18448]
	ldr	q16, [sp, #18432]
	ldr	q18, [sp, #18496]
	ldr	q19, [sp, #18512]
	ldr	q21, [sp, #18528]
	ldr	q26, [sp, #18544]
	ldr	q1, [sp, #992]                  ; 16-byte Folded Reload
	shl.2d	v27, v1, #5
	ldr	q1, [sp, #976]                  ; 16-byte Folded Reload
	shl.2d	v30, v1, #5
	ldr	q1, [sp, #960]                  ; 16-byte Folded Reload
	shl.2d	v31, v1, #5
	ldr	q1, [sp, #944]                  ; 16-byte Folded Reload
	shl.2d	v8, v1, #5
	add.2d	v26, v26, v8
	add.2d	v31, v21, v31
	add.2d	v19, v19, v30
	add.2d	v18, v18, v27
	add.2d	v21, v16, v18
	add.2d	v19, v7, v19
	add.2d	v18, v4, v31
	add.2d	v16, v3, v26
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w1, s3
	mov.16b	v31, v6
	tbz	w1, #0, LBB0_437
; %bb.430:                              ; %cond.store5743
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d21
	str	s17, [x2]
	tbnz	w1, #1, LBB0_438
LBB0_431:                               ; %else5750
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #2, LBB0_439
LBB0_432:                               ; %cond.store5751
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d19
	st1.s	{ v17 }[2], [x2]
	tbnz	w1, #3, LBB0_440
LBB0_433:                               ; %else5758
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #4, LBB0_441
LBB0_434:                               ; %cond.store5759
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d18
	str	s5, [x2]
	tbnz	w1, #5, LBB0_442
LBB0_435:                               ; %else5766
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #6, LBB0_443
LBB0_436:                               ; %cond.store5767
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d16
	st1.s	{ v5 }[2], [x2]
	tbnz	w1, #7, LBB0_444
	b	LBB0_445
LBB0_437:                               ; %else5746
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #1, LBB0_431
LBB0_438:                               ; %cond.store5747
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v21[1]
	st1.s	{ v17 }[1], [x2]
	tbnz	w1, #2, LBB0_432
LBB0_439:                               ; %else5754
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #3, LBB0_433
LBB0_440:                               ; %cond.store5755
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v19[1]
	st1.s	{ v17 }[3], [x2]
	tbnz	w1, #4, LBB0_434
LBB0_441:                               ; %else5762
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #5, LBB0_435
LBB0_442:                               ; %cond.store5763
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v18[1]
	st1.s	{ v5 }[1], [x2]
	tbnz	w1, #6, LBB0_436
LBB0_443:                               ; %else5770
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #7, LBB0_445
LBB0_444:                               ; %cond.store5771
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x1, v16[1]
	st1.s	{ v5 }[3], [x1]
LBB0_445:                               ; %else5774
                                        ;   in Loop: Header=BB0_8 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v20, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v4, v3, #0
	ushll2.4s	v3, v3, #0
	ldp	q6, q1, [sp, #944]              ; 32-byte Folded Reload
	uaddw2.2d	v5, v6, v3
	uaddw.2d	v1, v1, v3
	stp	q5, q1, [sp, #944]              ; 32-byte Folded Spill
	ldp	q6, q1, [sp, #976]              ; 32-byte Folded Reload
	uaddw2.2d	v5, v6, v4
	uaddw.2d	v1, v1, v4
	stp	q5, q1, [sp, #976]              ; 32-byte Folded Spill
	b	LBB0_378
LBB0_446:                               ; %varying.coherent.false411
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1063
LBB0_447:                               ; %schedule.20
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v6, v31
	cbz	w0, LBB0_452
; %bb.448:                              ; %convergence.cascade450.preheader
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
LBB0_449:                               ; %convergence.cascade450
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_3 Depth=2
                                        ;       Parent Loop BB0_8 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w2, s4
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	str	q24, [sp, #12000]
	str	q12, [sp, #12016]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #3808
	ldr	w6, [x6, x2]
	cmp	w6, #6
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #1520
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s5, w19
	ubfx	w19, w20, #1, #1
	mov.b	v5[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v5[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v5[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v5[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v5[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v5[6], w19
	add	x19, sp, #18, lsl #12           ; =73728
	add	x19, x19, #1512
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s3, w21
	ubfx	w21, w20, #1, #1
	mov.b	v3[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v3[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v3[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v3[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v3[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v3[6], w21
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	orr.8b	v4, v20, v3
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	and.8b	v7, v1, v5
	eor.8b	v7, v7, v4
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v4, v7
	dup.8b	v17, w7
	bit.8b	v3, v16, v17
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x19, w3, sxtw]
	bic.8b	v3, v5, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v4, v5, v4
	str	q23, [sp, #11968]
	str	q11, [sp, #11984]
	add	x3, sp, #2, lsl #12             ; =8192
	add	x3, x3, #3776
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v20, v4, v3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_453
; %bb.450:                              ; %convergence.cascade450
                                        ;   in Loop: Header=BB0_449 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_453
; %bb.451:                              ; %convergence.cascade450
                                        ;   in Loop: Header=BB0_449 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_449
	b	LBB0_453
LBB0_452:                               ; %schedule.20.convergence.cascade.exit451_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_453:                               ; %convergence.cascade.exit451
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1046
; %bb.454:                              ; %convergence.target.20.ready
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q18, [sp, #18272]
	ldr	q16, [sp, #18288]
	ldr	q5, [sp, #18240]
	ldr	q3, [sp, #18256]
	ldr	q17, [sp, #18208]
	ldr	q4, [sp, #18224]
	ldr	q7, [sp, #18176]
	ldr	q21, [sp, #18192]
	mov	b19, v20[2]
	mov.b	v19[4], v20[3]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	ldr	q8, [sp, #256]                  ; 16-byte Folded Reload
	bit.16b	v21, v8, v19
	mov	b26, v20[0]
	mov.b	v26[4], v20[1]
	ushll.2d	v26, v26, #0
	shl.2d	v26, v26, #63
	cmlt.2d	v26, v26, #0
	mov	b27, v20[6]
	mov.b	v27[4], v20[7]
	bit.16b	v7, v8, v26
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	bit.16b	v4, v8, v27
	mov	b30, v20[4]
	mov.b	v30[4], v20[5]
	ushll.2d	v30, v30, #0
	shl.2d	v30, v30, #63
	cmlt.2d	v30, v30, #0
Lloh578:
	adrp	x1, lCPI0_17@PAGE
Lloh579:
	ldr	q31, [x1, lCPI0_17@PAGEOFF]
	bit.16b	v3, v31, v19
Lloh580:
	adrp	x1, lCPI0_18@PAGE
Lloh581:
	ldr	q31, [x1, lCPI0_18@PAGEOFF]
	bit.16b	v18, v31, v30
Lloh582:
	adrp	x1, lCPI0_16@PAGE
Lloh583:
	ldr	q31, [x1, lCPI0_16@PAGEOFF]
	str	q18, [sp, #18272]
Lloh584:
	adrp	x1, lCPI0_19@PAGE
Lloh585:
	ldr	q18, [x1, lCPI0_19@PAGEOFF]
	bit.16b	v17, v8, v30
	bit.16b	v16, v18, v27
	str	q16, [sp, #18288]
	bit.16b	v5, v31, v26
	str	q5, [sp, #18240]
	str	q3, [sp, #18256]
	str	q17, [sp, #18208]
	str	q4, [sp, #18224]
	str	q7, [sp, #18176]
	str	q21, [sp, #18192]
	ldr	q1, [sp, #1360]                 ; 16-byte Folded Reload
	bic.16b	v1, v1, v27
	str	q1, [sp, #1360]                 ; 16-byte Folded Spill
	bic.16b	v31, v6, v30
	ldr	q1, [sp, #1088]                 ; 16-byte Folded Reload
	bic.16b	v1, v1, v19
	str	q1, [sp, #1088]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #1072]                 ; 16-byte Folded Reload
	bic.16b	v1, v1, v26
	str	q1, [sp, #1072]                 ; 16-byte Folded Spill
	b	LBB0_457
LBB0_455:                               ; %varying.coherent.false422
                                        ;   in Loop: Header=BB0_8 Depth=3
	zip2.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldp	q5, q1, [sp, #448]              ; 32-byte Folded Reload
	and.16b	v4, v3, v5
	zip1.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v1, v3, v1
	stp	q4, q1, [sp, #448]              ; 32-byte Folded Spill
	ldr	q22, [sp, #1232]                ; 16-byte Folded Reload
	ldr	q14, [sp, #1440]                ; 16-byte Folded Reload
	ldr	q4, [sp, #1504]                 ; 16-byte Folded Reload
	mov.16b	v11, v23
	mov.16b	v23, v29
	mov.16b	v24, v9
	mov.16b	v9, v4
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	ldr	q29, [sp, #1472]                ; 16-byte Folded Reload
	ldr	q13, [sp, #1456]                ; 16-byte Folded Reload
	tbz	w1, #0, LBB0_158
	b	LBB0_1063
LBB0_456:                               ; %scheduler.dispatch.route.backedge
                                        ;   in Loop: Header=BB0_8 Depth=3
                                        ; kill: def $w3 killed $w3 killed $x3 def $x3
	ldr	q22, [sp, #1232]                ; 16-byte Folded Reload
	ldr	q14, [sp, #1440]                ; 16-byte Folded Reload
	ldr	q9, [sp, #1504]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	ldr	q29, [sp, #1472]                ; 16-byte Folded Reload
	ldr	q13, [sp, #1456]                ; 16-byte Folded Reload
	b	LBB0_7
LBB0_457:                               ; %schedule.21
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	mov	w1, #128                        ; =0x80
	dup.2d	v5, x1
	ldr	q1, [sp, #1088]                 ; 16-byte Folded Reload
	cmgt.2d	v3, v5, v1
	ldr	q6, [sp, #1072]                 ; 16-byte Folded Reload
	cmgt.2d	v4, v5, v6
	uzp1.4s	v3, v4, v3
	cmgt.2d	v4, v5, v31
	ldr	q7, [sp, #1360]                 ; 16-byte Folded Reload
	cmgt.2d	v16, v5, v7
	uzp1.4s	v4, v4, v16
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v21, v20, v3
	shl.8b	v3, v21, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w1, s4
	umaxv.8b	b3, v3
	fmov	w3, s3
	tbz	w3, #0, LBB0_463
; %bb.458:                              ; %schedule.21
                                        ;   in Loop: Header=BB0_8 Depth=3
	cmge.2d	v3, v1, v5
	cmge.2d	v4, v6, v5
	uzp1.4s	v3, v4, v3
	cmge.2d	v4, v31, v5
	cmge.2d	v5, v7, v5
	uzp1.4s	v4, v4, v5
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v10, v20, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_463
; %bb.459:                              ; %varying.divergent468
                                        ;   in Loop: Header=BB0_8 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	str	q24, [sp, #3200]
	str	q12, [sp, #3216]
	and	x1, x1, #0x7
	add	x3, sp, #3200
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #8, #0, ne
	cset	w1, ne
	cmp	w2, #255
	b.ne	LBB0_461
; %bb.460:                              ; %varying.divergent468
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #0, LBB0_461
	b	LBB0_1086
LBB0_461:                               ; %convergence.overflow.resume471
                                        ;   in Loop: Header=BB0_8 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #18, lsl #12            ; =73728
	add	x2, x2, #1520
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s5, w4
	ubfx	w4, w5, #1, #1
	mov.b	v5[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v5[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v5[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v5[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v5[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v5[6], w4
	add	x4, sp, #18, lsl #12            ; =73728
	add	x4, x4, #1512
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v4, w5
	bit.8b	v5, v20, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x2, w3, uxtw]
	bic.8b	v3, v3, v4
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_1086
; %bb.462:                              ; %ready.overflow.resume473
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q23, [sp, #3168]
	str	q11, [sp, #3184]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #3168
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q23, [sp, #3136]
	str	q11, [sp, #3152]
	add	x5, sp, #3136
	str	w4, [x5, x2]
	ldr	q11, [sp, #3152]
	ldr	q23, [sp, #3136]
	str	q24, [sp, #3104]
	str	q12, [sp, #3120]
	add	x4, sp, #3104
	ldr	w4, [x4, x2]
	mov	w5, #8                          ; =0x8
	csel	w4, w5, w4, ne
	str	q24, [sp, #3072]
	str	q12, [sp, #3088]
	add	x5, sp, #3072
	str	w4, [x5, x2]
	mov	w2, #23                         ; =0x17
	mov	w4, #22                         ; =0x16
	ldr	q12, [sp, #3088]
	ldr	q24, [sp, #3072]
	b	LBB0_6
LBB0_463:                               ; %varying.coherent469
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w1, #0xff
	b.eq	LBB0_514
; %bb.464:                              ; %varying.coherent.true474
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
	tst	w2, #0xff
	b.eq	LBB0_1063
LBB0_465:                               ; %schedule.22
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v6, v22
	str	q13, [sp, #1456]                ; 16-byte Folded Spill
	str	q29, [sp, #1472]                ; 16-byte Folded Spill
	str	q0, [sp, #1488]                 ; 16-byte Folded Spill
	str	q24, [sp, #1376]                ; 16-byte Folded Spill
	str	q12, [sp, #1536]                ; 16-byte Folded Spill
	str	q23, [sp, #1392]                ; 16-byte Folded Spill
	str	q11, [sp, #1568]                ; 16-byte Folded Spill
	mov.16b	v8, v25
	str	q9, [sp, #1504]                 ; 16-byte Folded Spill
	str	q14, [sp, #1440]                ; 16-byte Folded Spill
	ldr	q0, [sp, #1360]                 ; 16-byte Folded Reload
	mov	b3, v20[0]
	mov.b	v3[4], v20[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q1, [sp, #1072]                 ; 16-byte Folded Reload
	and.16b	v16, v3, v1
	mov	b4, v20[2]
	mov.b	v4[4], v20[3]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	ldr	q1, [sp, #1088]                 ; 16-byte Folded Reload
	and.16b	v17, v4, v1
	mov	b5, v20[4]
	mov.b	v5[4], v20[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v27, v5, #0
	mov.16b	v7, v31
	and.16b	v18, v27, v31
	mov	b5, v20[6]
	mov.b	v5[4], v20[7]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v30, v5, #0
	and.16b	v19, v30, v0
	shl.8b	v5, v20, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	mov	w2, #32                         ; =0x20
	dup.2d	v31, x2
	and.16b	v21, v3, v31
	mvn.16b	v3, v3
	sub.2d	v21, v21, v3
	and.16b	v3, v4, v31
	mvn.16b	v4, v4
	sub.2d	v26, v3, v4
	and.16b	v3, v27, v31
	mvn.16b	v4, v27
	and.16b	v27, v30, v31
	mvn.16b	v30, v30
	sub.2d	v27, v27, v30
	mov.d	x2, v27[1]
	mov.d	x3, v19[1]
	sdiv	x3, x3, x2
	sub.2d	v3, v3, v4
	fmov	x4, d27
	fmov	x5, d19
	sdiv	x5, x5, x4
	mul	x4, x5, x4
	fmov	d4, x5
	mov.d	v4[1], x3
	mov.d	x5, v3[1]
	mov.d	x6, v18[1]
	sdiv	x6, x6, x5
	fmov	x7, d3
	fmov	x19, d18
	sdiv	x19, x19, x7
	mul	x7, x19, x7
	fmov	d3, x19
	mov.d	v3[1], x6
	mov.d	x19, v26[1]
	mov.d	x20, v17[1]
	sdiv	x20, x20, x19
	fmov	x21, d26
	fmov	x22, d17
	sdiv	x22, x22, x21
	mul	x21, x22, x21
	fmov	d26, x22
	mov.d	v26[1], x20
	mov.d	x22, v21[1]
	mov.d	x23, v16[1]
	fmov	x24, d21
	fmov	x25, d16
	sdiv	x25, x25, x24
	mul	x24, x25, x24
	fmov	d21, x25
	sdiv	x23, x23, x22
	mov.d	v21[1], x23
	mul	x22, x23, x22
	fmov	d27, x24
	mov.d	v27[1], x22
	mul	x19, x20, x19
	fmov	d30, x21
	mov.d	v30[1], x19
	mul	x5, x6, x5
	fmov	d31, x7
	mov.d	v31[1], x5
	mul	x2, x3, x2
	fmov	d10, x4
	mov.d	v10[1], x2
	addv.8b	b5, v5
	sub.2d	v19, v19, v10
	sub.2d	v18, v18, v31
	fmov	w2, s5
	sub.2d	v17, v17, v30
	sub.2d	v16, v16, v27
	ldr	q27, [sp, #18688]
	ldr	q30, [sp, #18704]
	ldr	q31, [sp, #18720]
	ldr	q11, [sp, #18736]
	ldr	q12, [sp, #18800]
	ldr	q13, [sp, #18784]
	ldr	q14, [sp, #18768]
	shl.2d	v21, v21, #10
	shl.2d	v26, v26, #10
	shl.2d	v3, v3, #10
	shl.2d	v4, v4, #10
	shl.2d	v10, v16, #5
	shl.2d	v15, v17, #5
	shl.2d	v17, v18, #5
	shl.2d	v16, v19, #5
	add.2d	v16, v4, v16
	add.2d	v17, v3, v17
	ldr	q3, [sp, #18752]
	add.2d	v18, v26, v15
	add.2d	v10, v21, v10
	add.2d	v4, v11, v12
	add.2d	v19, v4, v16
	add.2d	v4, v31, v13
	add.2d	v11, v4, v17
	add.2d	v4, v30, v14
	add.2d	v26, v4, v18
	add.2d	v3, v27, v3
	add.2d	v27, v3, v10
	movi.2d	v21, #0000000000000000
	movi.2d	v30, #0000000000000000
	tbz	w2, #0, LBB0_469
; %bb.466:                              ; %cond.load4581
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d27
	ldr	s21, [x3]
	tbnz	w2, #1, LBB0_470
LBB0_467:                               ; %else4591
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v25, v8
	tbz	w2, #2, LBB0_471
LBB0_468:                               ; %cond.load4593
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d26
	ld1.s	{ v21 }[2], [x3]
	ldr	q23, [sp, #1392]                ; 16-byte Folded Reload
	ldr	q29, [sp, #1472]                ; 16-byte Folded Reload
	tbnz	w2, #3, LBB0_472
	b	LBB0_473
LBB0_469:                               ; %else4585
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #1, LBB0_467
LBB0_470:                               ; %cond.load4587
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v27[1]
	ld1.s	{ v21 }[1], [x3]
	mov.16b	v25, v8
	tbnz	w2, #2, LBB0_468
LBB0_471:                               ; %else4597
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q23, [sp, #1392]                ; 16-byte Folded Reload
	ldr	q29, [sp, #1472]                ; 16-byte Folded Reload
	tbz	w2, #3, LBB0_473
LBB0_472:                               ; %cond.load4599
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v26[1]
	ld1.s	{ v21 }[3], [x3]
LBB0_473:                               ; %else4603
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q9, [sp, #1504]                 ; 16-byte Folded Reload
	ldr	q24, [sp, #1376]                ; 16-byte Folded Reload
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	ldr	q13, [sp, #1456]                ; 16-byte Folded Reload
	mov.16b	v22, v6
	ldr	q14, [sp, #1440]                ; 16-byte Folded Reload
	tbz	w2, #4, LBB0_477
; %bb.474:                              ; %cond.load4605
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d11
	ld1.s	{ v30 }[0], [x3]
	tbnz	w2, #5, LBB0_478
LBB0_475:                               ; %else4615
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #6, LBB0_479
LBB0_476:                               ; %cond.load4617
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d19
	ld1.s	{ v30 }[2], [x3]
	tbnz	w2, #7, LBB0_480
	b	LBB0_481
LBB0_477:                               ; %else4609
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #5, LBB0_475
LBB0_478:                               ; %cond.load4611
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v11[1]
	ld1.s	{ v30 }[1], [x3]
	tbnz	w2, #6, LBB0_476
LBB0_479:                               ; %else4621
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #7, LBB0_481
LBB0_480:                               ; %cond.load4623
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v19[1]
	ld1.s	{ v30 }[3], [x2]
LBB0_481:                               ; %else4627
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q3, [sp, #18480]
	ldr	q4, [sp, #18464]
	ldr	q19, [sp, #18448]
	ldr	q26, [sp, #18432]
	ldr	q27, [sp, #18496]
	ldr	q31, [sp, #18512]
	ldr	q11, [sp, #18528]
	ldr	q12, [sp, #18544]
	add.2d	v26, v26, v27
	add.2d	v27, v26, v10
	add.2d	v19, v19, v31
	add.2d	v26, v19, v18
	add.2d	v4, v4, v11
	add.2d	v19, v4, v17
	add.2d	v3, v3, v12
	add.2d	v18, v3, v16
	fmov	w2, s5
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbz	w2, #0, LBB0_489
; %bb.482:                              ; %cond.load4630
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d27
	ldr	s16, [x3]
	tbnz	w2, #1, LBB0_490
LBB0_483:                               ; %else4640
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #2, LBB0_491
LBB0_484:                               ; %cond.load4642
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d26
	ld1.s	{ v16 }[2], [x3]
	tbnz	w2, #3, LBB0_492
LBB0_485:                               ; %else4652
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #4, LBB0_493
LBB0_486:                               ; %cond.load4654
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d19
	ld1.s	{ v17 }[0], [x3]
	tbnz	w2, #5, LBB0_494
LBB0_487:                               ; %else4664
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #6, LBB0_495
LBB0_488:                               ; %cond.load4666
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d18
	ld1.s	{ v17 }[2], [x3]
	tbnz	w2, #7, LBB0_496
	b	LBB0_497
LBB0_489:                               ; %else4634
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #1, LBB0_483
LBB0_490:                               ; %cond.load4636
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v27[1]
	ld1.s	{ v16 }[1], [x3]
	tbnz	w2, #2, LBB0_484
LBB0_491:                               ; %else4646
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #3, LBB0_485
LBB0_492:                               ; %cond.load4648
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v26[1]
	ld1.s	{ v16 }[3], [x3]
	tbnz	w2, #4, LBB0_486
LBB0_493:                               ; %else4658
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #5, LBB0_487
LBB0_494:                               ; %cond.load4660
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v19[1]
	ld1.s	{ v17 }[1], [x3]
	tbnz	w2, #6, LBB0_488
LBB0_495:                               ; %else4670
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #7, LBB0_497
LBB0_496:                               ; %cond.load4672
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v18[1]
	ld1.s	{ v17 }[3], [x2]
LBB0_497:                               ; %else4676
                                        ;   in Loop: Header=BB0_8 Depth=3
	fadd.4s	v18, v21, v16
	fadd.4s	v16, v30, v17
	ldr	q3, [sp, #18224]
	ldr	q4, [sp, #18208]
	ldr	q17, [sp, #18192]
	ldr	q19, [sp, #18176]
	ldr	q21, [sp, #18240]
	ldr	q26, [sp, #18256]
	ldr	q27, [sp, #18272]
	ldr	q30, [sp, #18288]
	ldr	q1, [sp, #1072]                 ; 16-byte Folded Reload
	shl.2d	v31, v1, #5
	ldr	q1, [sp, #1088]                 ; 16-byte Folded Reload
	shl.2d	v10, v1, #5
	shl.2d	v11, v7, #5
	ldr	q1, [sp, #1360]                 ; 16-byte Folded Reload
	shl.2d	v12, v1, #5
	add.2d	v30, v30, v12
	add.2d	v27, v27, v11
	add.2d	v10, v26, v10
	add.2d	v21, v21, v31
	add.2d	v26, v19, v21
	add.2d	v21, v17, v10
	add.2d	v19, v4, v27
	add.2d	v17, v3, v30
	fmov	w2, s5
	tbz	w2, #0, LBB0_505
; %bb.498:                              ; %cond.store4679
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d26
	str	s18, [x3]
	ldr	q11, [sp, #1568]                ; 16-byte Folded Reload
	ldr	q12, [sp, #1536]                ; 16-byte Folded Reload
	tbnz	w2, #1, LBB0_506
LBB0_499:                               ; %else4686
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v31, v7
	tbz	w2, #2, LBB0_507
LBB0_500:                               ; %cond.store4687
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d21
	st1.s	{ v18 }[2], [x3]
	tbnz	w2, #3, LBB0_508
LBB0_501:                               ; %else4694
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #4, LBB0_509
LBB0_502:                               ; %cond.store4695
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d19
	str	s16, [x3]
	tbnz	w2, #5, LBB0_510
LBB0_503:                               ; %else4702
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #6, LBB0_511
LBB0_504:                               ; %cond.store4703
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d17
	st1.s	{ v16 }[2], [x3]
	tbnz	w2, #7, LBB0_512
	b	LBB0_513
LBB0_505:                               ; %else4682
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q11, [sp, #1568]                ; 16-byte Folded Reload
	ldr	q12, [sp, #1536]                ; 16-byte Folded Reload
	tbz	w2, #1, LBB0_499
LBB0_506:                               ; %cond.store4683
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v26[1]
	st1.s	{ v18 }[1], [x3]
	mov.16b	v31, v7
	tbnz	w2, #2, LBB0_500
LBB0_507:                               ; %else4690
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #3, LBB0_501
LBB0_508:                               ; %cond.store4691
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v21[1]
	st1.s	{ v18 }[3], [x3]
	tbnz	w2, #4, LBB0_502
LBB0_509:                               ; %else4698
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #5, LBB0_503
LBB0_510:                               ; %cond.store4699
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v19[1]
	st1.s	{ v16 }[1], [x3]
	tbnz	w2, #6, LBB0_504
LBB0_511:                               ; %else4706
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #7, LBB0_513
LBB0_512:                               ; %cond.store4707
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v17[1]
	st1.s	{ v16 }[3], [x2]
LBB0_513:                               ; %else4710
                                        ;   in Loop: Header=BB0_8 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v20, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v4, v3, #0
	ushll2.4s	v3, v3, #0
	ldr	q1, [sp, #1360]                 ; 16-byte Folded Reload
	uaddw2.2d	v1, v1, v3
	str	q1, [sp, #1360]                 ; 16-byte Folded Spill
	uaddw.2d	v31, v31, v3
	ldr	q1, [sp, #1088]                 ; 16-byte Folded Reload
	uaddw2.2d	v1, v1, v4
	str	q1, [sp, #1088]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #1072]                 ; 16-byte Folded Reload
	uaddw.2d	v1, v1, v4
	str	q1, [sp, #1072]                 ; 16-byte Folded Spill
	tbz	w1, #0, LBB0_457
	b	LBB0_1063
LBB0_514:                               ; %varying.coherent.false475
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1063
LBB0_515:                               ; %schedule.23
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q31, [sp, #1456]                ; 16-byte Folded Spill
	ldr	q6, [sp, #1552]                 ; 16-byte Folded Reload
	str	q28, [sp, #1408]                ; 16-byte Folded Spill
	str	q25, [sp, #1168]                ; 16-byte Folded Spill
	str	q11, [sp, #1568]                ; 16-byte Folded Spill
	str	q23, [sp, #1392]                ; 16-byte Folded Spill
	str	q12, [sp, #1536]                ; 16-byte Folded Spill
	str	q24, [sp, #1376]                ; 16-byte Folded Spill
	cbz	w0, LBB0_520
; %bb.516:                              ; %convergence.cascade483.preheader
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
LBB0_517:                               ; %convergence.cascade483
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_3 Depth=2
                                        ;       Parent Loop BB0_8 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w2, s4
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	str	q24, [sp, #11936]
	str	q12, [sp, #11952]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #3744
	ldr	w6, [x6, x2]
	cmp	w6, #8
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #1520
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s5, w19
	ubfx	w19, w20, #1, #1
	mov.b	v5[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v5[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v5[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v5[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v5[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v5[6], w19
	add	x19, sp, #18, lsl #12           ; =73728
	add	x19, x19, #1512
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s3, w21
	ubfx	w21, w20, #1, #1
	mov.b	v3[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v3[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v3[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v3[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v3[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v3[6], w21
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	orr.8b	v4, v20, v3
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	and.8b	v7, v1, v5
	eor.8b	v7, v7, v4
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v4, v7
	dup.8b	v17, w7
	bit.8b	v3, v16, v17
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x19, w3, sxtw]
	bic.8b	v3, v5, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v4, v5, v4
	str	q23, [sp, #11904]
	str	q11, [sp, #11920]
	add	x3, sp, #2, lsl #12             ; =8192
	add	x3, x3, #3712
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v20, v4, v3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_521
; %bb.518:                              ; %convergence.cascade483
                                        ;   in Loop: Header=BB0_517 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_521
; %bb.519:                              ; %convergence.cascade483
                                        ;   in Loop: Header=BB0_517 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_517
	b	LBB0_521
LBB0_520:                               ; %schedule.23.convergence.cascade.exit484_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_521:                               ; %convergence.cascade.exit484
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1047
; %bb.522:                              ; %convergence.target.23.ready
                                        ;   in Loop: Header=BB0_8 Depth=3
	rbit	w1, w2
	clz	w1, w1
	ldr	q16, [sp, #18144]
	ldr	q3, [sp, #18160]
	ldr	q4, [sp, #18112]
	ldr	q7, [sp, #18128]
	ldr	q17, [sp, #18080]
	ldr	q5, [sp, #18096]
	ldr	q18, [sp, #18048]
	ldr	q19, [sp, #18064]
	mov	b21, v20[2]
	mov.b	v21[4], v20[3]
	ushll.2d	v21, v21, #0
	shl.2d	v21, v21, #63
	cmlt.2d	v21, v21, #0
	ldr	q31, [sp, #240]                 ; 16-byte Folded Reload
	mov.16b	v27, v21
	bsl.16b	v27, v31, v19
	mov	b26, v20[0]
	mov.b	v26[4], v20[1]
	ushll.2d	v26, v26, #0
	shl.2d	v26, v26, #63
	cmlt.2d	v30, v26, #0
	mov.16b	v1, v30
	bsl.16b	v1, v31, v18
	str	q1, [sp, #1504]                 ; 16-byte Folded Spill
	mov	b26, v20[6]
	mov.b	v26[4], v20[7]
	ushll.2d	v26, v26, #0
	shl.2d	v26, v26, #63
	cmlt.2d	v10, v26, #0
	mov	b26, v20[4]
	mov.b	v26[4], v20[5]
	mov.16b	v1, v10
	bsl.16b	v1, v31, v5
	str	q1, [sp, #1488]                 ; 16-byte Folded Spill
	ushll.2d	v5, v26, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v15, v5, #0
	mov.16b	v1, v15
	bsl.16b	v1, v31, v17
	str	q1, [sp, #1472]                 ; 16-byte Folded Spill
Lloh586:
	adrp	x2, lCPI0_20@PAGE
Lloh587:
	ldr	q26, [x2, lCPI0_20@PAGEOFF]
	mov.16b	v5, v6
	mov.16b	v25, v21
	bsl.16b	v25, v26, v7
Lloh588:
	adrp	x2, lCPI0_21@PAGE
Lloh589:
	ldr	q31, [x2, lCPI0_21@PAGEOFF]
	mov.16b	v6, v30
	bsl.16b	v6, v31, v4
Lloh590:
	adrp	x2, lCPI0_22@PAGE
Lloh591:
	ldr	q8, [x2, lCPI0_22@PAGEOFF]
	bit.16b	v3, v8, v10
Lloh592:
	adrp	x2, lCPI0_23@PAGE
	mov.16b	v17, v0
	mov.16b	v2, v9
Lloh593:
	ldr	q9, [x2, lCPI0_23@PAGEOFF]
	bit.16b	v16, v9, v15
	str	q16, [sp, #18144]
	str	q3, [sp, #18160]
	str	q6, [sp, #18112]
	str	q25, [sp, #18128]
	ldr	q0, [sp, #1472]                 ; 16-byte Folded Reload
	str	q0, [sp, #18080]
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	str	q0, [sp, #18096]
	ldr	q0, [sp, #1504]                 ; 16-byte Folded Reload
	str	q0, [sp, #18048]
	str	q27, [sp, #18064]
	str	q8, [sp, #9904]
	str	q9, [sp, #9888]
	mov.16b	v9, v2
	mov.16b	v6, v5
	ldr	q23, [sp, #1392]                ; 16-byte Folded Reload
	ldr	q24, [sp, #1376]                ; 16-byte Folded Reload
	ldr	q25, [sp, #1168]                ; 16-byte Folded Reload
	ldr	q5, [sp, #1200]                 ; 16-byte Folded Reload
	ldr	q12, [sp, #1536]                ; 16-byte Folded Reload
	ldr	q11, [sp, #1568]                ; 16-byte Folded Reload
	mov.16b	v0, v17
	ldr	q28, [sp, #1408]                ; 16-byte Folded Reload
	ldr	d2, [sp, #696]                  ; 8-byte Folded Reload
	str	q26, [sp, #9872]
	str	q31, [sp, #9856]
	lsl	w2, w1, #3
	and	x1, x2, #0x38
	add	x3, sp, #2, lsl #12             ; =8192
	add	x3, x3, #1664
	ldr	x4, [x3, x1]
	and	x2, x2, #0xf8
	add	x3, sp, #11, lsl #12            ; =45056
	add	x3, x3, #3432
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4, #32]
	ldp	q7, q16, [x4]
	mov	x5, #-4                         ; =0xfffffffffffffffc
	dup.2d	v17, x5
	bit.16b	v16, v17, v21
	bit.16b	v7, v17, v30
	bit.16b	v4, v17, v10
	bit.16b	v3, v17, v15
	stp	q3, q4, [x4, #32]
	stp	q7, q16, [x4]
Lloh594:
	adrp	x4, lCPI0_24@PAGE
Lloh595:
	ldr	q3, [x4, lCPI0_24@PAGEOFF]
Lloh596:
	adrp	x4, lCPI0_25@PAGE
Lloh597:
	ldr	q4, [x4, lCPI0_25@PAGEOFF]
	str	q3, [sp, #9968]
	str	q4, [sp, #9952]
Lloh598:
	adrp	x4, lCPI0_26@PAGE
Lloh599:
	ldr	q3, [x4, lCPI0_26@PAGEOFF]
Lloh600:
	adrp	x4, lCPI0_27@PAGE
Lloh601:
	ldr	q4, [x4, lCPI0_27@PAGEOFF]
	str	q3, [sp, #9936]
	str	q4, [sp, #9920]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #1728
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	x5, #-3                         ; =0xfffffffffffffffd
	dup.2d	v17, x5
	bit.16b	v16, v17, v15
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh602:
	adrp	x4, lCPI0_28@PAGE
Lloh603:
	ldr	q3, [x4, lCPI0_28@PAGEOFF]
Lloh604:
	adrp	x4, lCPI0_29@PAGE
Lloh605:
	ldr	q4, [x4, lCPI0_29@PAGEOFF]
	str	q3, [sp, #10032]
	str	q4, [sp, #10016]
Lloh606:
	adrp	x4, lCPI0_30@PAGE
Lloh607:
	ldr	q3, [x4, lCPI0_30@PAGEOFF]
Lloh608:
	adrp	x4, lCPI0_31@PAGE
Lloh609:
	ldr	q4, [x4, lCPI0_31@PAGEOFF]
	str	q3, [sp, #10000]
	str	q4, [sp, #9984]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #1792
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	x5, #-2                         ; =0xfffffffffffffffe
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v15
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v10
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh610:
	adrp	x4, lCPI0_32@PAGE
Lloh611:
	ldr	q3, [x4, lCPI0_32@PAGEOFF]
Lloh612:
	adrp	x4, lCPI0_33@PAGE
Lloh613:
	ldr	q4, [x4, lCPI0_33@PAGEOFF]
	str	q3, [sp, #10096]
	str	q4, [sp, #10080]
Lloh614:
	adrp	x4, lCPI0_34@PAGE
Lloh615:
	ldr	q3, [x4, lCPI0_34@PAGEOFF]
Lloh616:
	adrp	x4, lCPI0_35@PAGE
Lloh617:
	ldr	q4, [x4, lCPI0_35@PAGEOFF]
	str	q3, [sp, #10064]
	str	q4, [sp, #10048]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #1856
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	orr.16b	v16, v15, v16
	orr.16b	v4, v21, v4
	orr.16b	v3, v30, v3
	orr.16b	v7, v10, v7
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh618:
	adrp	x4, lCPI0_36@PAGE
Lloh619:
	ldr	q3, [x4, lCPI0_36@PAGEOFF]
Lloh620:
	adrp	x4, lCPI0_37@PAGE
Lloh621:
	ldr	q4, [x4, lCPI0_37@PAGEOFF]
	str	q3, [sp, #10160]
	str	q4, [sp, #10144]
Lloh622:
	adrp	x4, lCPI0_38@PAGE
Lloh623:
	ldr	q3, [x4, lCPI0_38@PAGEOFF]
Lloh624:
	adrp	x4, lCPI0_39@PAGE
Lloh625:
	ldr	q4, [x4, lCPI0_39@PAGEOFF]
	str	q3, [sp, #10128]
	str	q4, [sp, #10112]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #1920
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	bic.16b	v16, v16, v15
	bic.16b	v4, v4, v21
	bic.16b	v3, v3, v30
	bic.16b	v7, v7, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh626:
	adrp	x4, lCPI0_40@PAGE
Lloh627:
	ldr	q3, [x4, lCPI0_40@PAGEOFF]
Lloh628:
	adrp	x4, lCPI0_41@PAGE
Lloh629:
	ldr	q4, [x4, lCPI0_41@PAGEOFF]
	str	q3, [sp, #10224]
	str	q4, [sp, #10208]
Lloh630:
	adrp	x4, lCPI0_42@PAGE
Lloh631:
	ldr	q3, [x4, lCPI0_42@PAGEOFF]
Lloh632:
	adrp	x4, lCPI0_43@PAGE
Lloh633:
	ldr	q4, [x4, lCPI0_43@PAGEOFF]
	str	q3, [sp, #10192]
	str	q4, [sp, #10176]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #1984
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	bic.16b	v16, v16, v15
	sub.2d	v16, v16, v15
	bic.16b	v4, v4, v21
	sub.2d	v4, v4, v21
	bic.16b	v3, v3, v30
	sub.2d	v3, v3, v30
	bic.16b	v7, v7, v10
	sub.2d	v7, v7, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh634:
	adrp	x4, lCPI0_44@PAGE
Lloh635:
	ldr	q3, [x4, lCPI0_44@PAGEOFF]
Lloh636:
	adrp	x4, lCPI0_45@PAGE
Lloh637:
	ldr	q4, [x4, lCPI0_45@PAGEOFF]
	str	q3, [sp, #10288]
	str	q4, [sp, #10272]
Lloh638:
	adrp	x4, lCPI0_46@PAGE
Lloh639:
	ldr	q3, [x4, lCPI0_46@PAGEOFF]
Lloh640:
	adrp	x4, lCPI0_47@PAGE
Lloh641:
	ldr	q4, [x4, lCPI0_47@PAGEOFF]
	str	q3, [sp, #10256]
	str	q4, [sp, #10240]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #2048
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #2                          ; =0x2
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v15
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v10
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh642:
	adrp	x4, lCPI0_48@PAGE
Lloh643:
	ldr	q3, [x4, lCPI0_48@PAGEOFF]
Lloh644:
	adrp	x4, lCPI0_49@PAGE
Lloh645:
	ldr	q4, [x4, lCPI0_49@PAGEOFF]
	str	q3, [sp, #10352]
	str	q4, [sp, #10336]
Lloh646:
	adrp	x4, lCPI0_50@PAGE
Lloh647:
	ldr	q3, [x4, lCPI0_50@PAGEOFF]
Lloh648:
	adrp	x4, lCPI0_51@PAGE
Lloh649:
	ldr	q4, [x4, lCPI0_51@PAGEOFF]
	str	q3, [sp, #10320]
	str	q4, [sp, #10304]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #2112
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #3                          ; =0x3
	dup.2d	v17, x5
	bit.16b	v16, v17, v15
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh650:
	adrp	x4, lCPI0_52@PAGE
Lloh651:
	ldr	q3, [x4, lCPI0_52@PAGEOFF]
Lloh652:
	adrp	x4, lCPI0_53@PAGE
Lloh653:
	ldr	q4, [x4, lCPI0_53@PAGEOFF]
	str	q3, [sp, #10416]
	str	q4, [sp, #10400]
Lloh654:
	adrp	x4, lCPI0_54@PAGE
Lloh655:
	ldr	q3, [x4, lCPI0_54@PAGEOFF]
Lloh656:
	adrp	x4, lCPI0_55@PAGE
Lloh657:
	ldr	q4, [x4, lCPI0_55@PAGEOFF]
	str	q3, [sp, #10384]
	str	q4, [sp, #10368]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #2176
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #4                          ; =0x4
	dup.2d	v17, x5
	bit.16b	v16, v17, v15
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh658:
	adrp	x4, lCPI0_56@PAGE
Lloh659:
	ldr	q3, [x4, lCPI0_56@PAGEOFF]
Lloh660:
	adrp	x4, lCPI0_57@PAGE
Lloh661:
	ldr	q4, [x4, lCPI0_57@PAGEOFF]
	str	q3, [sp, #10480]
	str	q4, [sp, #10464]
Lloh662:
	adrp	x4, lCPI0_58@PAGE
Lloh663:
	ldr	q3, [x4, lCPI0_58@PAGEOFF]
Lloh664:
	adrp	x4, lCPI0_59@PAGE
Lloh665:
	ldr	q4, [x4, lCPI0_59@PAGEOFF]
	str	q3, [sp, #10448]
	str	q4, [sp, #10432]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #2240
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #5                          ; =0x5
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v15
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v10
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh666:
	adrp	x4, lCPI0_60@PAGE
Lloh667:
	ldr	q3, [x4, lCPI0_60@PAGEOFF]
Lloh668:
	adrp	x4, lCPI0_61@PAGE
Lloh669:
	ldr	q4, [x4, lCPI0_61@PAGEOFF]
	str	q3, [sp, #10544]
	str	q4, [sp, #10528]
Lloh670:
	adrp	x4, lCPI0_62@PAGE
Lloh671:
	ldr	q3, [x4, lCPI0_62@PAGEOFF]
Lloh672:
	adrp	x4, lCPI0_63@PAGE
Lloh673:
	ldr	q4, [x4, lCPI0_63@PAGEOFF]
	str	q3, [sp, #10512]
	str	q4, [sp, #10496]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #2304
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #6                          ; =0x6
	dup.2d	v17, x5
	bit.16b	v16, v17, v15
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh674:
	adrp	x4, lCPI0_64@PAGE
Lloh675:
	ldr	q3, [x4, lCPI0_64@PAGEOFF]
Lloh676:
	adrp	x4, lCPI0_65@PAGE
Lloh677:
	ldr	q4, [x4, lCPI0_65@PAGEOFF]
	str	q3, [sp, #10608]
	str	q4, [sp, #10592]
Lloh678:
	adrp	x4, lCPI0_66@PAGE
Lloh679:
	ldr	q3, [x4, lCPI0_66@PAGEOFF]
Lloh680:
	adrp	x4, lCPI0_67@PAGE
Lloh681:
	ldr	q4, [x4, lCPI0_67@PAGEOFF]
	str	q3, [sp, #10576]
	str	q4, [sp, #10560]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #2368
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #7                          ; =0x7
	dup.2d	v17, x5
	bit.16b	v16, v17, v15
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh682:
	adrp	x4, lCPI0_68@PAGE
Lloh683:
	ldr	q3, [x4, lCPI0_68@PAGEOFF]
Lloh684:
	adrp	x4, lCPI0_69@PAGE
Lloh685:
	ldr	q4, [x4, lCPI0_69@PAGEOFF]
	str	q3, [sp, #10672]
	str	q4, [sp, #10656]
Lloh686:
	adrp	x4, lCPI0_70@PAGE
Lloh687:
	ldr	q3, [x4, lCPI0_70@PAGEOFF]
Lloh688:
	adrp	x4, lCPI0_71@PAGE
Lloh689:
	ldr	q4, [x4, lCPI0_71@PAGEOFF]
	str	q3, [sp, #10640]
	str	q4, [sp, #10624]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #2432
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #8                          ; =0x8
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v15
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v10
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh690:
	adrp	x4, lCPI0_72@PAGE
Lloh691:
	ldr	q3, [x4, lCPI0_72@PAGEOFF]
Lloh692:
	adrp	x4, lCPI0_73@PAGE
Lloh693:
	ldr	q4, [x4, lCPI0_73@PAGEOFF]
	str	q3, [sp, #10736]
	str	q4, [sp, #10720]
Lloh694:
	adrp	x4, lCPI0_74@PAGE
Lloh695:
	ldr	q3, [x4, lCPI0_74@PAGEOFF]
Lloh696:
	adrp	x4, lCPI0_75@PAGE
Lloh697:
	ldr	q4, [x4, lCPI0_75@PAGEOFF]
	str	q3, [sp, #10704]
	str	q4, [sp, #10688]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #2496
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #9                          ; =0x9
	dup.2d	v17, x5
	bit.16b	v16, v17, v15
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh698:
	adrp	x4, lCPI0_76@PAGE
Lloh699:
	ldr	q3, [x4, lCPI0_76@PAGEOFF]
Lloh700:
	adrp	x4, lCPI0_77@PAGE
Lloh701:
	ldr	q4, [x4, lCPI0_77@PAGEOFF]
	str	q3, [sp, #10800]
	str	q4, [sp, #10784]
Lloh702:
	adrp	x4, lCPI0_78@PAGE
Lloh703:
	ldr	q3, [x4, lCPI0_78@PAGEOFF]
Lloh704:
	adrp	x4, lCPI0_79@PAGE
Lloh705:
	ldr	q4, [x4, lCPI0_79@PAGEOFF]
	str	q3, [sp, #10768]
	str	q4, [sp, #10752]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #2560
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #10                         ; =0xa
	dup.2d	v17, x5
	bit.16b	v16, v17, v15
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh706:
	adrp	x4, lCPI0_80@PAGE
Lloh707:
	ldr	q3, [x4, lCPI0_80@PAGEOFF]
Lloh708:
	adrp	x4, lCPI0_81@PAGE
Lloh709:
	ldr	q4, [x4, lCPI0_81@PAGEOFF]
	str	q3, [sp, #10864]
	str	q4, [sp, #10848]
Lloh710:
	adrp	x4, lCPI0_82@PAGE
Lloh711:
	ldr	q3, [x4, lCPI0_82@PAGEOFF]
Lloh712:
	adrp	x4, lCPI0_83@PAGE
Lloh713:
	ldr	q4, [x4, lCPI0_83@PAGEOFF]
	str	q3, [sp, #10832]
	str	q4, [sp, #10816]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #2624
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #11                         ; =0xb
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v15
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v10
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh714:
	adrp	x4, lCPI0_84@PAGE
Lloh715:
	ldr	q3, [x4, lCPI0_84@PAGEOFF]
Lloh716:
	adrp	x4, lCPI0_85@PAGE
Lloh717:
	ldr	q4, [x4, lCPI0_85@PAGEOFF]
	str	q3, [sp, #10928]
	str	q4, [sp, #10912]
Lloh718:
	adrp	x4, lCPI0_86@PAGE
Lloh719:
	ldr	q3, [x4, lCPI0_86@PAGEOFF]
Lloh720:
	adrp	x4, lCPI0_87@PAGE
Lloh721:
	ldr	q4, [x4, lCPI0_87@PAGEOFF]
	str	q3, [sp, #10896]
	str	q4, [sp, #10880]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #2688
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #12                         ; =0xc
	dup.2d	v17, x5
	bit.16b	v16, v17, v15
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh722:
	adrp	x4, lCPI0_88@PAGE
Lloh723:
	ldr	q3, [x4, lCPI0_88@PAGEOFF]
Lloh724:
	adrp	x4, lCPI0_89@PAGE
Lloh725:
	ldr	q4, [x4, lCPI0_89@PAGEOFF]
	str	q3, [sp, #10992]
	str	q4, [sp, #10976]
Lloh726:
	adrp	x4, lCPI0_90@PAGE
Lloh727:
	ldr	q3, [x4, lCPI0_90@PAGEOFF]
Lloh728:
	adrp	x4, lCPI0_91@PAGE
Lloh729:
	ldr	q4, [x4, lCPI0_91@PAGEOFF]
	str	q3, [sp, #10960]
	str	q4, [sp, #10944]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #2752
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #13                         ; =0xd
	dup.2d	v17, x5
	bit.16b	v16, v17, v15
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh730:
	adrp	x4, lCPI0_92@PAGE
Lloh731:
	ldr	q3, [x4, lCPI0_92@PAGEOFF]
Lloh732:
	adrp	x4, lCPI0_93@PAGE
Lloh733:
	ldr	q4, [x4, lCPI0_93@PAGEOFF]
	str	q3, [sp, #11056]
	str	q4, [sp, #11040]
Lloh734:
	adrp	x4, lCPI0_94@PAGE
Lloh735:
	ldr	q3, [x4, lCPI0_94@PAGEOFF]
Lloh736:
	adrp	x4, lCPI0_95@PAGE
Lloh737:
	ldr	q4, [x4, lCPI0_95@PAGEOFF]
	str	q3, [sp, #11024]
	str	q4, [sp, #11008]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #2816
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #14                         ; =0xe
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v15
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v10
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh738:
	adrp	x4, lCPI0_96@PAGE
Lloh739:
	ldr	q3, [x4, lCPI0_96@PAGEOFF]
Lloh740:
	adrp	x4, lCPI0_97@PAGE
Lloh741:
	ldr	q4, [x4, lCPI0_97@PAGEOFF]
	str	q3, [sp, #11120]
	str	q4, [sp, #11104]
Lloh742:
	adrp	x4, lCPI0_98@PAGE
Lloh743:
	ldr	q3, [x4, lCPI0_98@PAGEOFF]
Lloh744:
	adrp	x4, lCPI0_99@PAGE
Lloh745:
	ldr	q4, [x4, lCPI0_99@PAGEOFF]
	str	q3, [sp, #11088]
	str	q4, [sp, #11072]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #2880
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #15                         ; =0xf
	dup.2d	v17, x5
	bit.16b	v16, v17, v15
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh746:
	adrp	x4, lCPI0_100@PAGE
Lloh747:
	ldr	q3, [x4, lCPI0_100@PAGEOFF]
Lloh748:
	adrp	x4, lCPI0_101@PAGE
Lloh749:
	ldr	q4, [x4, lCPI0_101@PAGEOFF]
	str	q3, [sp, #11184]
	str	q4, [sp, #11168]
Lloh750:
	adrp	x4, lCPI0_102@PAGE
Lloh751:
	ldr	q3, [x4, lCPI0_102@PAGEOFF]
Lloh752:
	adrp	x4, lCPI0_103@PAGE
Lloh753:
	ldr	q4, [x4, lCPI0_103@PAGEOFF]
	str	q3, [sp, #11152]
	str	q4, [sp, #11136]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #2944
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #16                         ; =0x10
	dup.2d	v17, x5
	bit.16b	v16, v17, v15
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh754:
	adrp	x4, lCPI0_104@PAGE
Lloh755:
	ldr	q3, [x4, lCPI0_104@PAGEOFF]
Lloh756:
	adrp	x4, lCPI0_105@PAGE
Lloh757:
	ldr	q4, [x4, lCPI0_105@PAGEOFF]
	str	q3, [sp, #11248]
	str	q4, [sp, #11232]
Lloh758:
	adrp	x4, lCPI0_106@PAGE
Lloh759:
	ldr	q3, [x4, lCPI0_106@PAGEOFF]
Lloh760:
	adrp	x4, lCPI0_107@PAGE
Lloh761:
	ldr	q4, [x4, lCPI0_107@PAGEOFF]
	str	q3, [sp, #11216]
	str	q4, [sp, #11200]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #3008
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #17                         ; =0x11
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v15
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v10
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh762:
	adrp	x4, lCPI0_108@PAGE
Lloh763:
	ldr	q3, [x4, lCPI0_108@PAGEOFF]
Lloh764:
	adrp	x4, lCPI0_109@PAGE
Lloh765:
	ldr	q4, [x4, lCPI0_109@PAGEOFF]
	str	q3, [sp, #11312]
	str	q4, [sp, #11296]
Lloh766:
	adrp	x4, lCPI0_110@PAGE
Lloh767:
	ldr	q3, [x4, lCPI0_110@PAGEOFF]
Lloh768:
	adrp	x4, lCPI0_111@PAGE
Lloh769:
	ldr	q4, [x4, lCPI0_111@PAGEOFF]
	str	q3, [sp, #11280]
	str	q4, [sp, #11264]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #3072
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #18                         ; =0x12
	dup.2d	v17, x5
	bit.16b	v16, v17, v15
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh770:
	adrp	x4, lCPI0_112@PAGE
Lloh771:
	ldr	q3, [x4, lCPI0_112@PAGEOFF]
Lloh772:
	adrp	x4, lCPI0_113@PAGE
Lloh773:
	ldr	q4, [x4, lCPI0_113@PAGEOFF]
	str	q3, [sp, #11376]
	str	q4, [sp, #11360]
Lloh774:
	adrp	x4, lCPI0_114@PAGE
Lloh775:
	ldr	q3, [x4, lCPI0_114@PAGEOFF]
Lloh776:
	adrp	x4, lCPI0_115@PAGE
Lloh777:
	ldr	q4, [x4, lCPI0_115@PAGEOFF]
	str	q3, [sp, #11344]
	str	q4, [sp, #11328]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #3136
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #19                         ; =0x13
	dup.2d	v17, x5
	bit.16b	v16, v17, v15
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh778:
	adrp	x4, lCPI0_116@PAGE
Lloh779:
	ldr	q3, [x4, lCPI0_116@PAGEOFF]
Lloh780:
	adrp	x4, lCPI0_117@PAGE
Lloh781:
	ldr	q4, [x4, lCPI0_117@PAGEOFF]
	str	q3, [sp, #11440]
	str	q4, [sp, #11424]
Lloh782:
	adrp	x4, lCPI0_118@PAGE
Lloh783:
	ldr	q3, [x4, lCPI0_118@PAGEOFF]
Lloh784:
	adrp	x4, lCPI0_119@PAGE
Lloh785:
	ldr	q4, [x4, lCPI0_119@PAGEOFF]
	str	q3, [sp, #11408]
	str	q4, [sp, #11392]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #3200
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #20                         ; =0x14
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v15
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v10
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh786:
	adrp	x4, lCPI0_120@PAGE
Lloh787:
	ldr	q3, [x4, lCPI0_120@PAGEOFF]
Lloh788:
	adrp	x4, lCPI0_121@PAGE
Lloh789:
	ldr	q4, [x4, lCPI0_121@PAGEOFF]
	str	q3, [sp, #11504]
	str	q4, [sp, #11488]
Lloh790:
	adrp	x4, lCPI0_122@PAGE
Lloh791:
	ldr	q3, [x4, lCPI0_122@PAGEOFF]
Lloh792:
	adrp	x4, lCPI0_123@PAGE
Lloh793:
	ldr	q4, [x4, lCPI0_123@PAGEOFF]
	str	q3, [sp, #11472]
	str	q4, [sp, #11456]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #3264
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #21                         ; =0x15
	dup.2d	v17, x5
	bit.16b	v16, v17, v15
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh794:
	adrp	x4, lCPI0_124@PAGE
Lloh795:
	ldr	q3, [x4, lCPI0_124@PAGEOFF]
Lloh796:
	adrp	x4, lCPI0_125@PAGE
Lloh797:
	ldr	q4, [x4, lCPI0_125@PAGEOFF]
	str	q3, [sp, #11568]
	str	q4, [sp, #11552]
Lloh798:
	adrp	x4, lCPI0_126@PAGE
Lloh799:
	ldr	q3, [x4, lCPI0_126@PAGEOFF]
Lloh800:
	adrp	x4, lCPI0_127@PAGE
Lloh801:
	ldr	q4, [x4, lCPI0_127@PAGEOFF]
	str	q3, [sp, #11536]
	str	q4, [sp, #11520]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #3328
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #22                         ; =0x16
	dup.2d	v17, x5
	bit.16b	v16, v17, v15
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh802:
	adrp	x4, lCPI0_128@PAGE
Lloh803:
	ldr	q3, [x4, lCPI0_128@PAGEOFF]
Lloh804:
	adrp	x4, lCPI0_129@PAGE
Lloh805:
	ldr	q4, [x4, lCPI0_129@PAGEOFF]
	str	q3, [sp, #11632]
	str	q4, [sp, #11616]
Lloh806:
	adrp	x4, lCPI0_130@PAGE
Lloh807:
	ldr	q3, [x4, lCPI0_130@PAGEOFF]
Lloh808:
	adrp	x4, lCPI0_131@PAGE
Lloh809:
	ldr	q4, [x4, lCPI0_131@PAGEOFF]
	str	q3, [sp, #11600]
	str	q4, [sp, #11584]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #3392
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #23                         ; =0x17
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v15
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v10
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh810:
	adrp	x4, lCPI0_132@PAGE
Lloh811:
	ldr	q3, [x4, lCPI0_132@PAGEOFF]
Lloh812:
	adrp	x4, lCPI0_133@PAGE
Lloh813:
	ldr	q4, [x4, lCPI0_133@PAGEOFF]
	str	q3, [sp, #11696]
	str	q4, [sp, #11680]
Lloh814:
	adrp	x4, lCPI0_134@PAGE
Lloh815:
	ldr	q3, [x4, lCPI0_134@PAGEOFF]
Lloh816:
	adrp	x4, lCPI0_135@PAGE
Lloh817:
	ldr	q4, [x4, lCPI0_135@PAGEOFF]
	str	q3, [sp, #11664]
	str	q4, [sp, #11648]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #3456
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #24                         ; =0x18
	dup.2d	v17, x5
	bit.16b	v16, v17, v15
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh818:
	adrp	x4, lCPI0_136@PAGE
Lloh819:
	ldr	q3, [x4, lCPI0_136@PAGEOFF]
Lloh820:
	adrp	x4, lCPI0_137@PAGE
Lloh821:
	ldr	q4, [x4, lCPI0_137@PAGEOFF]
	str	q3, [sp, #11760]
	str	q4, [sp, #11744]
Lloh822:
	adrp	x4, lCPI0_138@PAGE
Lloh823:
	ldr	q3, [x4, lCPI0_138@PAGEOFF]
Lloh824:
	adrp	x4, lCPI0_139@PAGE
Lloh825:
	ldr	q4, [x4, lCPI0_139@PAGEOFF]
	str	q3, [sp, #11728]
	str	q4, [sp, #11712]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #3520
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #25                         ; =0x19
	dup.2d	v17, x5
	bit.16b	v16, v17, v15
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh826:
	adrp	x4, lCPI0_140@PAGE
Lloh827:
	ldr	q3, [x4, lCPI0_140@PAGEOFF]
Lloh828:
	adrp	x4, lCPI0_141@PAGE
Lloh829:
	ldr	q4, [x4, lCPI0_141@PAGEOFF]
	str	q3, [sp, #11824]
	str	q4, [sp, #11808]
Lloh830:
	adrp	x4, lCPI0_142@PAGE
Lloh831:
	ldr	q3, [x4, lCPI0_142@PAGEOFF]
Lloh832:
	adrp	x4, lCPI0_143@PAGE
Lloh833:
	ldr	q4, [x4, lCPI0_143@PAGEOFF]
	str	q3, [sp, #11792]
	str	q4, [sp, #11776]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #3584
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #26                         ; =0x1a
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v15
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v10
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh834:
	adrp	x4, lCPI0_144@PAGE
Lloh835:
	ldr	q3, [x4, lCPI0_144@PAGEOFF]
Lloh836:
	adrp	x4, lCPI0_145@PAGE
Lloh837:
	ldr	q4, [x4, lCPI0_145@PAGEOFF]
	str	q3, [sp, #11888]
	str	q4, [sp, #11872]
Lloh838:
	adrp	x4, lCPI0_146@PAGE
Lloh839:
	ldr	q3, [x4, lCPI0_146@PAGEOFF]
Lloh840:
	adrp	x4, lCPI0_147@PAGE
Lloh841:
	ldr	q4, [x4, lCPI0_147@PAGEOFF]
	str	q3, [sp, #11856]
	str	q4, [sp, #11840]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #3648
	ldr	x1, [x4, x1]
	sub	x1, x1, x2
	add	x1, x3, x1
	ldp	q3, q4, [x1]
	ldp	q16, q7, [x1, #32]
	mov	w2, #27                         ; =0x1b
	dup.2d	v17, x2
	bit.16b	v16, v17, v15
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v10
	stp	q3, q4, [x1]
	stp	q16, q7, [x1, #32]
	ldr	q3, [sp, #18016]
	ldr	q4, [sp, #18032]
	ldr	q7, [sp, #17984]
	ldr	q16, [sp, #18000]
	ldr	q17, [sp, #17952]
	ldr	q18, [sp, #17968]
	ldr	q19, [sp, #17920]
	ldr	q26, [sp, #17936]
	ldr	q27, [sp, #224]                 ; 16-byte Folded Reload
	bit.16b	v26, v27, v21
	bit.16b	v19, v27, v30
	bit.16b	v18, v27, v10
	bit.16b	v17, v27, v15
Lloh842:
	adrp	x1, lCPI0_17@PAGE
Lloh843:
	ldr	q27, [x1, lCPI0_17@PAGEOFF]
	bit.16b	v16, v27, v21
Lloh844:
	adrp	x1, lCPI0_16@PAGE
Lloh845:
	ldr	q27, [x1, lCPI0_16@PAGEOFF]
	bit.16b	v7, v27, v30
Lloh846:
	adrp	x1, lCPI0_19@PAGE
Lloh847:
	ldr	q27, [x1, lCPI0_19@PAGEOFF]
	bit.16b	v4, v27, v10
Lloh848:
	adrp	x1, lCPI0_18@PAGE
Lloh849:
	ldr	q27, [x1, lCPI0_18@PAGEOFF]
	bit.16b	v3, v27, v15
	str	q3, [sp, #18016]
	str	q4, [sp, #18032]
	str	q7, [sp, #17984]
	str	q16, [sp, #18000]
	str	q17, [sp, #17952]
	str	q18, [sp, #17968]
	str	q19, [sp, #17920]
	str	q26, [sp, #17936]
	bic.16b	v6, v6, v10
	str	q6, [sp, #1552]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #1216]                 ; 16-byte Folded Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #1216]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #1008]                 ; 16-byte Folded Reload
	bic.16b	v1, v1, v21
	str	q1, [sp, #1008]                 ; 16-byte Folded Spill
	bic.16b	v5, v5, v30
	str	q5, [sp, #1200]                 ; 16-byte Folded Spill
	ldr	q31, [sp, #1456]                ; 16-byte Folded Reload
LBB0_523:                               ; %schedule.24
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	mov	w1, #128                        ; =0x80
	dup.2d	v5, x1
	ldr	q1, [sp, #1008]                 ; 16-byte Folded Reload
	cmgt.2d	v3, v5, v1
	ldr	q6, [sp, #1200]                 ; 16-byte Folded Reload
	cmgt.2d	v4, v5, v6
	uzp1.4s	v3, v4, v3
	ldr	q7, [sp, #1216]                 ; 16-byte Folded Reload
	cmgt.2d	v4, v5, v7
	ldr	q17, [sp, #1552]                ; 16-byte Folded Reload
	cmgt.2d	v16, v5, v17
	uzp1.4s	v4, v4, v16
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v21, v20, v3
	shl.8b	v3, v21, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w1, s4
	umaxv.8b	b3, v3
	fmov	w3, s3
	tbz	w3, #0, LBB0_529
; %bb.524:                              ; %schedule.24
                                        ;   in Loop: Header=BB0_8 Depth=3
	cmge.2d	v3, v1, v5
	cmge.2d	v4, v6, v5
	uzp1.4s	v3, v4, v3
	cmge.2d	v4, v7, v5
	cmge.2d	v5, v17, v5
	uzp1.4s	v4, v4, v5
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v10, v20, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_529
; %bb.525:                              ; %varying.divergent565
                                        ;   in Loop: Header=BB0_8 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	str	q24, [sp, #3360]
	str	q12, [sp, #3376]
	and	x1, x1, #0x7
	add	x3, sp, #3360
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #9, #0, ne
	cset	w1, ne
	cmp	w2, #255
	b.ne	LBB0_527
; %bb.526:                              ; %varying.divergent565
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #0, LBB0_527
	b	LBB0_1086
LBB0_527:                               ; %convergence.overflow.resume568
                                        ;   in Loop: Header=BB0_8 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #18, lsl #12            ; =73728
	add	x2, x2, #1520
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s5, w4
	ubfx	w4, w5, #1, #1
	mov.b	v5[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v5[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v5[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v5[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v5[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v5[6], w4
	add	x4, sp, #18, lsl #12            ; =73728
	add	x4, x4, #1512
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v4, w5
	bit.8b	v5, v20, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x2, w3, uxtw]
	bic.8b	v3, v3, v4
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_1086
; %bb.528:                              ; %ready.overflow.resume570
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q23, [sp, #3328]
	str	q11, [sp, #3344]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #3328
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q23, [sp, #3296]
	str	q11, [sp, #3312]
	add	x5, sp, #3296
	str	w4, [x5, x2]
	ldr	q11, [sp, #3312]
	ldr	q23, [sp, #3296]
	str	q24, [sp, #3264]
	str	q12, [sp, #3280]
	add	x4, sp, #3264
	ldr	w4, [x4, x2]
	mov	w5, #9                          ; =0x9
	csel	w4, w5, w4, ne
	str	q24, [sp, #3232]
	str	q12, [sp, #3248]
	add	x5, sp, #3232
	str	w4, [x5, x2]
	mov	w2, #28                         ; =0x1c
	mov	w4, #25                         ; =0x19
	ldr	q12, [sp, #3248]
	ldr	q24, [sp, #3232]
	b	LBB0_6
LBB0_529:                               ; %varying.coherent566
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w1, #0xff
	b.eq	LBB0_572
; %bb.530:                              ; %varying.coherent.true571
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
	tst	w2, #0xff
	b.eq	LBB0_1063
LBB0_531:                               ; %schedule.25
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v3, v22
	mov.16b	v22, v31
	str	q13, [sp, #1456]                ; 16-byte Folded Spill
	str	q29, [sp, #1472]                ; 16-byte Folded Spill
	str	q0, [sp, #1488]                 ; 16-byte Folded Spill
	mov.16b	v8, v24
	mov.16b	v29, v12
	mov.16b	v24, v23
	mov.16b	v23, v11
	str	q9, [sp, #1504]                 ; 16-byte Folded Spill
	mov.16b	v1, v25
	str	q3, [sp, #1232]                 ; 16-byte Folded Spill
	str	q14, [sp, #1440]                ; 16-byte Folded Spill
	mov	b3, v20[0]
	mov.b	v3[4], v20[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q6, [sp, #1216]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #1200]                 ; 16-byte Folded Reload
	and.16b	v16, v3, v0
	mov	b4, v20[2]
	mov.b	v4[4], v20[3]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	ldr	q0, [sp, #1008]                 ; 16-byte Folded Reload
	and.16b	v17, v4, v0
	mov	b5, v20[4]
	mov.b	v5[4], v20[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v27, v5, #0
	ldr	q19, [sp, #1552]                ; 16-byte Folded Reload
	and.16b	v18, v27, v6
	mov	b5, v20[6]
	mov.b	v5[4], v20[7]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v30, v5, #0
	mov.16b	v6, v19
	and.16b	v19, v30, v19
	shl.8b	v5, v20, #7
	cmlt.8b	v21, v5, #0
	and.8b	v5, v21, v2
	addv.8b	b5, v5
	fmov	w2, s5
	mov	w3, #32                         ; =0x20
	dup.2d	v31, x3
	and.16b	v26, v3, v31
	mvn.16b	v3, v3
	sub.2d	v26, v26, v3
	and.16b	v3, v4, v31
	mvn.16b	v4, v4
	sub.2d	v11, v3, v4
	and.16b	v3, v27, v31
	and.16b	v4, v30, v31
	mvn.16b	v30, v30
	sub.2d	v4, v4, v30
	mov.d	x3, v4[1]
	mov.d	x4, v19[1]
	sdiv	x4, x4, x3
	mvn.16b	v27, v27
	sub.2d	v3, v3, v27
	fmov	x5, d4
	fmov	x6, d19
	sdiv	x6, x6, x5
	mul	x5, x6, x5
	fmov	d30, x6
	mov.d	v30[1], x4
	mov.d	x6, v3[1]
	mov.d	x7, v18[1]
	sdiv	x7, x7, x6
	fmov	x19, d3
	fmov	x20, d18
	sdiv	x20, x20, x19
	mul	x19, x20, x19
	fmov	d10, x20
	mov.d	v10[1], x7
	mov.d	x20, v11[1]
	mov.d	x21, v17[1]
	sdiv	x21, x21, x20
	fmov	x22, d11
	fmov	x23, d17
	sdiv	x23, x23, x22
	mul	x22, x23, x22
	fmov	d11, x23
	mov.d	v11[1], x21
	mov.d	x23, v26[1]
	mov.d	x24, v16[1]
	fmov	x25, d26
	fmov	x26, d16
	sdiv	x26, x26, x25
	mul	x25, x26, x25
	fmov	d12, x26
	sdiv	x24, x24, x23
	mov.d	v12[1], x24
	mul	x3, x4, x3
	fmov	d3, x5
	mov.d	v3[1], x3
	mul	x3, x7, x6
	fmov	d4, x19
	mov.d	v4[1], x3
	mul	x3, x21, x20
	fmov	d26, x22
	mov.d	v26[1], x3
	mul	x3, x24, x23
	fmov	d27, x25
	mov.d	v27[1], x3
	sub.2d	v16, v16, v27
	sub.2d	v17, v17, v26
	sub.2d	v4, v18, v4
	sub.2d	v3, v19, v3
	ldr	q27, [sp, #18048]
	ldr	q26, [sp, #18064]
	ldr	q19, [sp, #18080]
	ldr	q18, [sp, #18096]
	ldr	q31, [sp, #18160]
	ldr	q13, [sp, #18144]
	ldr	q14, [sp, #18128]
	shl.2d	v3, v3, #6
	shl.2d	v4, v4, #6
	shl.2d	v17, v17, #6
	shl.2d	v16, v16, #6
	ldr	q15, [sp, #18112]
	add.2d	v18, v18, v31
	add.2d	v18, v18, v3
	add.2d	v3, v19, v13
	add.2d	v19, v3, v4
	add.2d	v3, v26, v14
	add.2d	v26, v3, v17
	add.2d	v3, v27, v15
	add.2d	v27, v3, v16
	movi.2d	v13, #0000000000000000
	movi.2d	v14, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbz	w2, #0, LBB0_539
; %bb.532:                              ; %cond.load4712
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d27
	ldr	d13, [x3]
	tbnz	w2, #1, LBB0_540
LBB0_533:                               ; %else4722
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v31, v22
	tbz	w2, #2, LBB0_541
LBB0_534:                               ; %cond.load4724
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d26
	ld1.d	{ v14 }[0], [x3]
	tbnz	w2, #3, LBB0_542
LBB0_535:                               ; %else4734
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #4, LBB0_543
LBB0_536:                               ; %cond.load4736
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d19
	ld1.d	{ v16 }[0], [x3]
	tbnz	w2, #5, LBB0_544
LBB0_537:                               ; %else4746
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #6, LBB0_545
LBB0_538:                               ; %cond.load4748
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d18
	ld1.d	{ v17 }[0], [x3]
	tbnz	w2, #7, LBB0_546
	b	LBB0_547
LBB0_539:                               ; %else4716
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #1, LBB0_533
LBB0_540:                               ; %cond.load4718
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v27[1]
	ld1.d	{ v13 }[1], [x3]
	mov.16b	v31, v22
	tbnz	w2, #2, LBB0_534
LBB0_541:                               ; %else4728
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #3, LBB0_535
LBB0_542:                               ; %cond.load4730
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v26[1]
	ld1.d	{ v14 }[1], [x3]
	tbnz	w2, #4, LBB0_536
LBB0_543:                               ; %else4740
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #5, LBB0_537
LBB0_544:                               ; %cond.load4742
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v19[1]
	ld1.d	{ v16 }[1], [x3]
	tbnz	w2, #6, LBB0_538
LBB0_545:                               ; %else4752
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #7, LBB0_547
LBB0_546:                               ; %cond.load4754
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v18[1]
	ld1.d	{ v17 }[1], [x2]
LBB0_547:                               ; %else4758
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w2, #32                         ; =0x20
	dup.2d	v3, x2
	cmhi.2d	v4, v3, v14
	cmhi.2d	v18, v3, v13
	uzp1.4s	v4, v18, v4
	cmhi.2d	v18, v3, v16
	cmhi.2d	v3, v3, v17
	uzp1.4s	v3, v18, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	ldrb	w2, [x9, #1024]
	and	w3, w2, #0x1
	fmov	s4, w3
	ubfx	w3, w2, #1, #1
	mov.b	v4[1], w3
	ubfx	w3, w2, #2, #1
	mov.b	v4[2], w3
	ubfx	w3, w2, #3, #1
	mov.b	v4[3], w3
	ubfx	w3, w2, #4, #1
	mov.b	v4[4], w3
	ubfx	w3, w2, #5, #1
	mov.b	v4[5], w3
	ubfx	w3, w2, #6, #1
	mov.b	v4[6], w3
	lsr	w2, w2, #7
	mov.b	v4[7], w2
	bif.8b	v3, v4, v21
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x9, #1024]
	shl.2d	v3, v11, #5
	shl.2d	v4, v12, #5
	shl.2d	v18, v30, #5
	shl.2d	v19, v10, #5
	add.2d	v16, v16, v19
	add.2d	v17, v17, v18
	add.2d	v18, v13, v4
	add.2d	v19, v14, v3
	ldr	q3, [sp, #17824]
	ldr	q4, [sp, #17840]
	ldr	q21, [sp, #17792]
	ldr	q26, [sp, #17808]
	mov	b27, v20[2]
	mov.b	v27[4], v20[3]
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	mov	b30, v20[0]
	mov.b	v30[4], v20[1]
	bit.16b	v26, v19, v27
	ushll.2d	v27, v30, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	bit.16b	v21, v18, v27
	mov	b27, v20[6]
	mov.b	v27[4], v20[7]
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	bit.16b	v4, v17, v27
	mov	b27, v20[4]
	mov.b	v27[4], v20[5]
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	bit.16b	v3, v16, v27
	str	q3, [sp, #17824]
	str	q4, [sp, #17840]
	str	q21, [sp, #17792]
	str	q26, [sp, #17808]
	mov	w2, #128                        ; =0x80
	dup.2d	v26, x2
	cmhi.2d	v3, v26, v18
	cmhi.2d	v4, v26, v19
	uzp1.4s	v3, v3, v4
	cmhi.2d	v4, v26, v16
	cmhi.2d	v21, v26, v17
	uzp1.4s	v4, v4, v21
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v21, v20, v3
	shl.8b	v3, v21, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w2, s4
	umaxv.8b	b3, v3
	fmov	w3, s3
	tbz	w3, #0, LBB0_553
; %bb.548:                              ; %else4758
                                        ;   in Loop: Header=BB0_8 Depth=3
	cmhs.2d	v3, v18, v26
	cmhs.2d	v4, v19, v26
	uzp1.4s	v3, v3, v4
	cmhs.2d	v4, v16, v26
	cmhs.2d	v16, v17, v26
	uzp1.4s	v4, v4, v16
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v10, v20, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_553
; %bb.549:                              ; %varying.divergent576
                                        ;   in Loop: Header=BB0_8 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	str	q8, [sp, #3520]
	str	q29, [sp, #3536]
	and	x1, x1, #0x7
	add	x3, sp, #3520
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #10, #0, ne
	cset	w1, ne
	cmp	w2, #255
	mov.16b	v25, v1
	b.ne	LBB0_551
; %bb.550:                              ; %varying.divergent576
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #0, LBB0_551
	b	LBB0_1086
LBB0_551:                               ; %convergence.overflow.resume579
                                        ;   in Loop: Header=BB0_8 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #18, lsl #12            ; =73728
	add	x2, x2, #1520
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s5, w4
	ubfx	w4, w5, #1, #1
	mov.b	v5[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v5[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v5[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v5[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v5[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v5[6], w4
	add	x4, sp, #18, lsl #12            ; =73728
	add	x4, x4, #1512
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v4, w5
	bit.8b	v5, v20, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x2, w3, uxtw]
	bic.8b	v3, v3, v4
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_1086
; %bb.552:                              ; %ready.overflow.resume581
                                        ;   in Loop: Header=BB0_8 Depth=3
	zip2.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldp	q5, q4, [sp, #480]              ; 32-byte Folded Reload
	and.16b	v1, v3, v5
	zip1.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v4, v3, v4
	stp	q1, q4, [sp, #480]              ; 32-byte Folded Spill
	str	q24, [sp, #3488]
	str	q23, [sp, #3504]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #3488
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q24, [sp, #3456]
	str	q23, [sp, #3472]
	add	x5, sp, #3456
	str	w4, [x5, x2]
	ldr	q11, [sp, #3472]
	ldr	q23, [sp, #3456]
	str	q8, [sp, #3424]
	str	q29, [sp, #3440]
	add	x4, sp, #3424
	ldr	w4, [x4, x2]
	mov	w5, #10                         ; =0xa
	csel	w4, w5, w4, ne
	str	q8, [sp, #3392]
	str	q29, [sp, #3408]
	add	x5, sp, #3392
	str	w4, [x5, x2]
	mov	w2, #27                         ; =0x1b
	mov	w4, #26                         ; =0x1a
	ldr	q12, [sp, #3408]
	ldr	q24, [sp, #3392]
	b	LBB0_456
LBB0_553:                               ; %varying.coherent577
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	mov.16b	v25, v1
	mov.16b	v12, v29
	b.eq	LBB0_581
; %bb.554:                              ; %varying.coherent.true582
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q29, [sp, #1472]                ; 16-byte Folded Reload
	tbnz	w1, #0, LBB0_1058
; %bb.555:                              ; %schedule.26.thread
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q3, [sp, #18176]
	ldr	q4, [sp, #18192]
	ldr	q7, [sp, #18208]
	ldr	q16, [sp, #18224]
	ldr	q17, [sp, #18288]
	ldr	q18, [sp, #18272]
	ldr	q19, [sp, #18256]
	ldr	q21, [sp, #18240]
	ldr	q26, [sp, #17792]
	ldr	q27, [sp, #17808]
	ldr	q30, [sp, #17824]
	ldr	q31, [sp, #17840]
	shl.2d	v31, v31, #5
	shl.2d	v30, v30, #5
	shl.2d	v27, v27, #5
	shl.2d	v26, v26, #5
	add.2d	v16, v16, v17
	add.2d	v17, v16, v31
	add.2d	v7, v7, v18
	add.2d	v18, v7, v30
	add.2d	v4, v4, v19
	add.2d	v19, v4, v27
	add.2d	v3, v3, v21
	add.2d	v21, v3, v26
	fmov	w1, s5
	movi.2d	v5, #0000000000000000
	movi.2d	v16, #0000000000000000
	mov.16b	v11, v23
	tbz	w1, #0, LBB0_557
; %bb.556:                              ; %cond.load5776
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d21
	ldr	s5, [x2]
LBB0_557:                               ; %else5780
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q0, [sp, #1360]                 ; 16-byte Folded Reload
	ldr	q9, [sp, #1504]                 ; 16-byte Folded Reload
	mov.16b	v23, v24
	str	q0, [sp, #1360]                 ; 16-byte Folded Spill
	tbz	w1, #1, LBB0_559
; %bb.558:                              ; %cond.load5782
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v21[1]
	ld1.s	{ v5 }[1], [x2]
LBB0_559:                               ; %else5786
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q4, [sp, #1232]                 ; 16-byte Folded Reload
	mov.16b	v24, v8
	mov.16b	v31, v22
	ldr	q14, [sp, #1440]                ; 16-byte Folded Reload
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	ldr	q13, [sp, #1456]                ; 16-byte Folded Reload
	tbz	w1, #2, LBB0_565
; %bb.560:                              ; %cond.load5788
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d19
	ld1.s	{ v5 }[2], [x2]
	mov.16b	v22, v4
	tbnz	w1, #3, LBB0_566
LBB0_561:                               ; %else5798
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #4, LBB0_567
LBB0_562:                               ; %cond.load5800
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d18
	ld1.s	{ v16 }[0], [x2]
	tbnz	w1, #5, LBB0_568
LBB0_563:                               ; %else5810
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #6, LBB0_569
LBB0_564:                               ; %cond.load5812
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d17
	ld1.s	{ v16 }[2], [x2]
	str	q6, [sp, #1552]                 ; 16-byte Folded Spill
	tbnz	w1, #7, LBB0_570
	b	LBB0_571
LBB0_565:                               ; %else5792
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v22, v4
	tbz	w1, #3, LBB0_561
LBB0_566:                               ; %cond.load5794
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v19[1]
	ld1.s	{ v5 }[3], [x2]
	tbnz	w1, #4, LBB0_562
LBB0_567:                               ; %else5804
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #5, LBB0_563
LBB0_568:                               ; %cond.load5806
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v18[1]
	ld1.s	{ v16 }[1], [x2]
	tbnz	w1, #6, LBB0_564
LBB0_569:                               ; %else5816
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q6, [sp, #1552]                 ; 16-byte Folded Spill
	tbz	w1, #7, LBB0_571
LBB0_570:                               ; %cond.load5818
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x1, v17[1]
	ld1.s	{ v16 }[3], [x1]
LBB0_571:                               ; %else5822
                                        ;   in Loop: Header=BB0_8 Depth=3
	zip2.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q4, [sp, #480]                  ; 16-byte Folded Reload
	bit.16b	v4, v16, v3
	str	q4, [sp, #480]                  ; 16-byte Folded Spill
	zip1.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q4, [sp, #496]                  ; 16-byte Folded Reload
	bit.16b	v4, v5, v3
	str	q4, [sp, #496]                  ; 16-byte Folded Spill
	b	LBB0_582
LBB0_572:                               ; %varying.coherent.false572
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1063
LBB0_573:                               ; %schedule.28
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v6, v31
	cbz	w0, LBB0_578
; %bb.574:                              ; %convergence.cascade611.preheader
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
LBB0_575:                               ; %convergence.cascade611
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_3 Depth=2
                                        ;       Parent Loop BB0_8 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w2, s4
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	str	q24, [sp, #9824]
	str	q12, [sp, #9840]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #1632
	ldr	w6, [x6, x2]
	cmp	w6, #9
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #1520
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s5, w19
	ubfx	w19, w20, #1, #1
	mov.b	v5[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v5[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v5[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v5[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v5[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v5[6], w19
	add	x19, sp, #18, lsl #12           ; =73728
	add	x19, x19, #1512
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s3, w21
	ubfx	w21, w20, #1, #1
	mov.b	v3[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v3[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v3[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v3[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v3[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v3[6], w21
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	orr.8b	v4, v20, v3
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	and.8b	v7, v1, v5
	eor.8b	v7, v7, v4
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v4, v7
	dup.8b	v17, w7
	bit.8b	v3, v16, v17
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x19, w3, sxtw]
	bic.8b	v3, v5, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v4, v5, v4
	str	q23, [sp, #9792]
	str	q11, [sp, #9808]
	add	x3, sp, #2, lsl #12             ; =8192
	add	x3, x3, #1600
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v20, v4, v3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_579
; %bb.576:                              ; %convergence.cascade611
                                        ;   in Loop: Header=BB0_575 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_579
; %bb.577:                              ; %convergence.cascade611
                                        ;   in Loop: Header=BB0_575 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_575
	b	LBB0_579
LBB0_578:                               ; %schedule.28.convergence.cascade.exit612_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_579:                               ; %convergence.cascade.exit612
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1046
; %bb.580:                              ; %convergence.target.28.ready
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q18, [sp, #17760]
	ldr	q16, [sp, #17776]
	ldr	q5, [sp, #17728]
	ldr	q3, [sp, #17744]
	ldr	q17, [sp, #17696]
	ldr	q4, [sp, #17712]
	ldr	q7, [sp, #17664]
	ldr	q21, [sp, #17680]
	mov	b19, v20[2]
	mov.b	v19[4], v20[3]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	ldr	q8, [sp, #208]                  ; 16-byte Folded Reload
	bit.16b	v21, v8, v19
	mov	b26, v20[0]
	mov.b	v26[4], v20[1]
	ushll.2d	v26, v26, #0
	shl.2d	v26, v26, #63
	cmlt.2d	v26, v26, #0
	mov	b27, v20[6]
	mov.b	v27[4], v20[7]
	bit.16b	v7, v8, v26
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	bit.16b	v4, v8, v27
	mov	b30, v20[4]
	mov.b	v30[4], v20[5]
	ushll.2d	v30, v30, #0
	shl.2d	v30, v30, #63
	cmlt.2d	v30, v30, #0
Lloh850:
	adrp	x1, lCPI0_17@PAGE
Lloh851:
	ldr	q31, [x1, lCPI0_17@PAGEOFF]
	bit.16b	v3, v31, v19
Lloh852:
	adrp	x1, lCPI0_18@PAGE
Lloh853:
	ldr	q31, [x1, lCPI0_18@PAGEOFF]
	bit.16b	v18, v31, v30
Lloh854:
	adrp	x1, lCPI0_16@PAGE
Lloh855:
	ldr	q31, [x1, lCPI0_16@PAGEOFF]
	str	q18, [sp, #17760]
Lloh856:
	adrp	x1, lCPI0_19@PAGE
Lloh857:
	ldr	q18, [x1, lCPI0_19@PAGEOFF]
	bit.16b	v17, v8, v30
	bit.16b	v16, v18, v27
	str	q16, [sp, #17776]
	bit.16b	v5, v31, v26
	str	q5, [sp, #17728]
	str	q3, [sp, #17744]
	str	q17, [sp, #17696]
	str	q4, [sp, #17712]
	str	q7, [sp, #17664]
	str	q21, [sp, #17680]
	bic.16b	v28, v28, v27
	ldr	q1, [sp, #1312]                 ; 16-byte Folded Reload
	bic.16b	v1, v1, v30
	str	q1, [sp, #1312]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #720]                  ; 16-byte Folded Reload
	bic.16b	v1, v1, v19
	str	q1, [sp, #720]                  ; 16-byte Folded Spill
	ldr	q3, [sp, #1152]                 ; 16-byte Folded Reload
	bic.16b	v3, v3, v26
	str	q3, [sp, #1152]                 ; 16-byte Folded Spill
	mov.16b	v31, v6
	b	LBB0_606
LBB0_581:                               ; %varying.coherent.false583
                                        ;   in Loop: Header=BB0_8 Depth=3
	zip2.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldp	q5, q4, [sp, #480]              ; 32-byte Folded Reload
	and.16b	v1, v3, v5
	zip1.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v4, v3, v4
	stp	q1, q4, [sp, #480]              ; 32-byte Folded Spill
	ldr	q22, [sp, #1232]                ; 16-byte Folded Reload
	ldr	q14, [sp, #1440]                ; 16-byte Folded Reload
	ldr	q9, [sp, #1504]                 ; 16-byte Folded Reload
	mov.16b	v11, v23
	mov.16b	v23, v24
	mov.16b	v24, v8
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	ldr	q29, [sp, #1472]                ; 16-byte Folded Reload
	ldr	q13, [sp, #1456]                ; 16-byte Folded Reload
	tbnz	w1, #0, LBB0_1063
LBB0_582:                               ; %schedule.27
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q28, [sp, #1408]                ; 16-byte Folded Spill
	mov.16b	v28, v9
	mov.16b	v9, v14
	mov.16b	v15, v22
	mov.16b	v22, v0
	mov.16b	v14, v29
	mov.16b	v29, v25
	ldr	q8, [sp, #1552]                 ; 16-byte Folded Reload
	mov.16b	v25, v31
	cbz	w0, LBB0_587
; %bb.583:                              ; %convergence.cascade586.preheader
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
LBB0_584:                               ; %convergence.cascade586
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_3 Depth=2
                                        ;       Parent Loop BB0_8 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w2, s4
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	str	q24, [sp, #3584]
	str	q12, [sp, #3600]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #3584
	ldr	w6, [x6, x2]
	cmp	w6, #10
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #1520
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s5, w19
	ubfx	w19, w20, #1, #1
	mov.b	v5[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v5[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v5[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v5[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v5[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v5[6], w19
	add	x19, sp, #18, lsl #12           ; =73728
	add	x19, x19, #1512
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s3, w21
	ubfx	w21, w20, #1, #1
	mov.b	v3[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v3[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v3[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v3[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v3[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v3[6], w21
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	orr.8b	v4, v20, v3
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	and.8b	v7, v1, v5
	eor.8b	v7, v7, v4
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v4, v7
	dup.8b	v17, w7
	bit.8b	v3, v16, v17
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x19, w3, sxtw]
	bic.8b	v3, v5, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v4, v5, v4
	str	q23, [sp, #3552]
	str	q11, [sp, #3568]
	add	x3, sp, #3552
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v20, v4, v3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_588
; %bb.585:                              ; %convergence.cascade586
                                        ;   in Loop: Header=BB0_584 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_588
; %bb.586:                              ; %convergence.cascade586
                                        ;   in Loop: Header=BB0_584 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_584
	b	LBB0_588
LBB0_587:                               ; %schedule.27.convergence.cascade.exit587_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_588:                               ; %convergence.cascade.exit587
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1048
; %bb.589:                              ; %convergence.target.27.ready
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q1, [sp, #704]                  ; 16-byte Folded Reload
	dup.4s	v3, v1[0]
	ldrb	w1, [x9, #1024]
	ubfx	w2, w1, #3, #1
	ubfx	w3, w1, #2, #1
	ubfx	w4, w1, #1, #1
	and	w5, w1, #0x1
	lsr	w6, w1, #7
	ubfx	w7, w1, #6, #1
	ubfx	w19, w1, #5, #1
	ubfx	w1, w1, #4, #1
	fmov	s4, w1
	mov.h	v4[1], w19
	mov.h	v4[2], w7
	mov.h	v4[3], w6
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	fmov	s7, w5
	mov.h	v7[1], w4
	mov.h	v7[2], w3
	mov.h	v7[3], w2
	ldp	q5, q6, [sp, #480]              ; 32-byte Folded Reload
	bif.16b	v5, v3, v4
	ushll.4s	v4, v7, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	mov.16b	v17, v4
	bsl.16b	v17, v6, v3
	ldr	q3, [sp, #17968]
	ldr	q4, [sp, #17952]
	ldr	q7, [sp, #17936]
	ldr	q16, [sp, #17920]
	ldr	q18, [sp, #17984]
	ldr	q19, [sp, #18000]
	ldr	q21, [sp, #18016]
	ldr	q26, [sp, #18032]
	ldr	q1, [sp, #1200]                 ; 16-byte Folded Reload
	shl.2d	v27, v1, #5
	ldr	q1, [sp, #1008]                 ; 16-byte Folded Reload
	shl.2d	v30, v1, #5
	ldr	q1, [sp, #1216]                 ; 16-byte Folded Reload
	shl.2d	v31, v1, #5
	shl.2d	v8, v8, #5
	add.2d	v26, v26, v8
	add.2d	v31, v21, v31
	add.2d	v19, v19, v30
	add.2d	v18, v18, v27
	add.2d	v21, v16, v18
	add.2d	v19, v7, v19
	add.2d	v18, v4, v31
	add.2d	v16, v3, v26
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w1, s3
	mov.16b	v31, v25
	tbz	w1, #0, LBB0_597
; %bb.590:                              ; %cond.store5825
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d21
	str	s17, [x2]
	tbnz	w1, #1, LBB0_598
LBB0_591:                               ; %else5832
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #2, LBB0_599
LBB0_592:                               ; %cond.store5833
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d19
	st1.s	{ v17 }[2], [x2]
	mov.16b	v25, v29
	tbnz	w1, #3, LBB0_600
LBB0_593:                               ; %else5840
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v29, v14
	tbz	w1, #4, LBB0_601
LBB0_594:                               ; %cond.store5841
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d18
	str	s5, [x2]
	tbnz	w1, #5, LBB0_602
LBB0_595:                               ; %else5848
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #6, LBB0_603
LBB0_596:                               ; %cond.store5849
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d16
	st1.s	{ v5 }[2], [x2]
	mov.16b	v0, v22
	tbnz	w1, #7, LBB0_604
	b	LBB0_605
LBB0_597:                               ; %else5828
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #1, LBB0_591
LBB0_598:                               ; %cond.store5829
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v21[1]
	st1.s	{ v17 }[1], [x2]
	tbnz	w1, #2, LBB0_592
LBB0_599:                               ; %else5836
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v25, v29
	tbz	w1, #3, LBB0_593
LBB0_600:                               ; %cond.store5837
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v19[1]
	st1.s	{ v17 }[3], [x2]
	mov.16b	v29, v14
	tbnz	w1, #4, LBB0_594
LBB0_601:                               ; %else5844
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #5, LBB0_595
LBB0_602:                               ; %cond.store5845
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v18[1]
	st1.s	{ v5 }[1], [x2]
	tbnz	w1, #6, LBB0_596
LBB0_603:                               ; %else5852
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v0, v22
	tbz	w1, #7, LBB0_605
LBB0_604:                               ; %cond.store5853
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x1, v16[1]
	st1.s	{ v5 }[3], [x1]
LBB0_605:                               ; %else5856
                                        ;   in Loop: Header=BB0_8 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v20, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v4, v3, #0
	ushll2.4s	v3, v3, #0
	ldr	q1, [sp, #1552]                 ; 16-byte Folded Reload
	uaddw2.2d	v1, v1, v3
	str	q1, [sp, #1552]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #1216]                 ; 16-byte Folded Reload
	uaddw.2d	v1, v1, v3
	str	q1, [sp, #1216]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #1008]                 ; 16-byte Folded Reload
	uaddw2.2d	v1, v1, v4
	str	q1, [sp, #1008]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #1200]                 ; 16-byte Folded Reload
	uaddw.2d	v1, v1, v4
	str	q1, [sp, #1200]                 ; 16-byte Folded Spill
	mov.16b	v14, v9
	mov.16b	v9, v28
	ldr	q28, [sp, #1408]                ; 16-byte Folded Reload
	mov.16b	v22, v15
	b	LBB0_523
LBB0_606:                               ; %schedule.29
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	mov	w1, #128                        ; =0x80
	dup.2d	v5, x1
	ldr	q1, [sp, #720]                  ; 16-byte Folded Reload
	cmgt.2d	v3, v5, v1
	ldr	q4, [sp, #1152]                 ; 16-byte Folded Reload
	cmgt.2d	v4, v5, v4
	uzp1.4s	v3, v4, v3
	ldr	q4, [sp, #1312]                 ; 16-byte Folded Reload
	cmgt.2d	v4, v5, v4
	cmgt.2d	v16, v5, v28
	uzp1.4s	v4, v4, v16
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v21, v20, v3
	shl.8b	v3, v21, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w1, s4
	umaxv.8b	b3, v3
	fmov	w3, s3
	tbz	w3, #0, LBB0_612
; %bb.607:                              ; %schedule.29
                                        ;   in Loop: Header=BB0_8 Depth=3
	cmge.2d	v3, v1, v5
	ldr	q4, [sp, #1152]                 ; 16-byte Folded Reload
	cmge.2d	v4, v4, v5
	uzp1.4s	v3, v4, v3
	ldr	q1, [sp, #1312]                 ; 16-byte Folded Reload
	cmge.2d	v4, v1, v5
	cmge.2d	v5, v28, v5
	uzp1.4s	v4, v4, v5
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v10, v20, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_612
; %bb.608:                              ; %varying.divergent629
                                        ;   in Loop: Header=BB0_8 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	str	q24, [sp, #3744]
	str	q12, [sp, #3760]
	and	x1, x1, #0x7
	add	x3, sp, #3744
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #11, #0, ne
	cset	w1, ne
	cmp	w2, #255
	b.ne	LBB0_610
; %bb.609:                              ; %varying.divergent629
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #0, LBB0_610
	b	LBB0_1086
LBB0_610:                               ; %convergence.overflow.resume632
                                        ;   in Loop: Header=BB0_8 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #18, lsl #12            ; =73728
	add	x2, x2, #1520
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s5, w4
	ubfx	w4, w5, #1, #1
	mov.b	v5[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v5[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v5[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v5[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v5[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v5[6], w4
	add	x4, sp, #18, lsl #12            ; =73728
	add	x4, x4, #1512
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v4, w5
	bit.8b	v5, v20, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x2, w3, uxtw]
	bic.8b	v3, v3, v4
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_1086
; %bb.611:                              ; %ready.overflow.resume634
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q23, [sp, #3712]
	str	q11, [sp, #3728]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #3712
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q23, [sp, #3680]
	str	q11, [sp, #3696]
	add	x5, sp, #3680
	str	w4, [x5, x2]
	ldr	q11, [sp, #3696]
	ldr	q23, [sp, #3680]
	str	q24, [sp, #3648]
	str	q12, [sp, #3664]
	add	x4, sp, #3648
	ldr	w4, [x4, x2]
	mov	w5, #11                         ; =0xb
	csel	w4, w5, w4, ne
	str	q24, [sp, #3616]
	str	q12, [sp, #3632]
	add	x5, sp, #3616
	str	w4, [x5, x2]
	mov	w2, #31                         ; =0x1f
	mov	w4, #30                         ; =0x1e
	ldr	q12, [sp, #3632]
	ldr	q24, [sp, #3616]
	b	LBB0_6
LBB0_612:                               ; %varying.coherent630
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w1, #0xff
	b.eq	LBB0_663
; %bb.613:                              ; %varying.coherent.true635
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
	tst	w2, #0xff
	b.eq	LBB0_1063
LBB0_614:                               ; %schedule.30
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v7, v22
	mov.16b	v22, v31
	str	q13, [sp, #1456]                ; 16-byte Folded Spill
	str	q29, [sp, #1472]                ; 16-byte Folded Spill
	str	q0, [sp, #1488]                 ; 16-byte Folded Spill
	str	q24, [sp, #1376]                ; 16-byte Folded Spill
	str	q12, [sp, #1536]                ; 16-byte Folded Spill
	str	q23, [sp, #1392]                ; 16-byte Folded Spill
	str	q11, [sp, #1568]                ; 16-byte Folded Spill
	mov.16b	v8, v25
	str	q9, [sp, #1504]                 ; 16-byte Folded Spill
	str	q14, [sp, #1440]                ; 16-byte Folded Spill
	mov	b3, v20[0]
	mov.b	v3[4], v20[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q4, [sp, #1152]                 ; 16-byte Folded Reload
	and.16b	v16, v3, v4
	mov	b4, v20[2]
	mov.b	v4[4], v20[3]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	ldr	q5, [sp, #720]                  ; 16-byte Folded Reload
	mov.16b	v6, v5
	and.16b	v17, v4, v5
	mov	b5, v20[4]
	mov.b	v5[4], v20[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v27, v5, #0
	ldr	q0, [sp, #1312]                 ; 16-byte Folded Reload
	and.16b	v18, v27, v0
	mov	b5, v20[6]
	mov.b	v5[4], v20[7]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v30, v5, #0
	and.16b	v19, v30, v28
	shl.8b	v5, v20, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	mov	w2, #32                         ; =0x20
	dup.2d	v31, x2
	and.16b	v21, v3, v31
	mvn.16b	v3, v3
	sub.2d	v21, v21, v3
	and.16b	v3, v4, v31
	mvn.16b	v4, v4
	sub.2d	v26, v3, v4
	and.16b	v3, v27, v31
	mvn.16b	v4, v27
	and.16b	v27, v30, v31
	mvn.16b	v30, v30
	sub.2d	v27, v27, v30
	mov.d	x2, v27[1]
	mov.d	x3, v19[1]
	sdiv	x3, x3, x2
	sub.2d	v3, v3, v4
	fmov	x4, d27
	fmov	x5, d19
	sdiv	x5, x5, x4
	mul	x4, x5, x4
	fmov	d4, x5
	mov.d	v4[1], x3
	mov.d	x5, v3[1]
	mov.d	x6, v18[1]
	sdiv	x6, x6, x5
	fmov	x7, d3
	fmov	x19, d18
	sdiv	x19, x19, x7
	mul	x7, x19, x7
	fmov	d3, x19
	mov.d	v3[1], x6
	mov.d	x19, v26[1]
	mov.d	x20, v17[1]
	sdiv	x20, x20, x19
	fmov	x21, d26
	fmov	x22, d17
	sdiv	x22, x22, x21
	mul	x21, x22, x21
	fmov	d26, x22
	mov.d	v26[1], x20
	mov.d	x22, v21[1]
	mov.d	x23, v16[1]
	fmov	x24, d21
	fmov	x25, d16
	sdiv	x25, x25, x24
	mul	x24, x25, x24
	fmov	d21, x25
	sdiv	x23, x23, x22
	mov.d	v21[1], x23
	mul	x22, x23, x22
	fmov	d27, x24
	mov.d	v27[1], x22
	mul	x19, x20, x19
	fmov	d30, x21
	mov.d	v30[1], x19
	mul	x5, x6, x5
	fmov	d31, x7
	mov.d	v31[1], x5
	mul	x2, x3, x2
	fmov	d10, x4
	mov.d	v10[1], x2
	addv.8b	b5, v5
	sub.2d	v19, v19, v10
	sub.2d	v18, v18, v31
	fmov	w2, s5
	sub.2d	v17, v17, v30
	sub.2d	v16, v16, v27
	ldr	q27, [sp, #18176]
	ldr	q30, [sp, #18192]
	ldr	q31, [sp, #18208]
	ldr	q11, [sp, #18224]
	ldr	q12, [sp, #18288]
	ldr	q13, [sp, #18272]
	ldr	q14, [sp, #18256]
	shl.2d	v21, v21, #10
	shl.2d	v26, v26, #10
	shl.2d	v3, v3, #10
	shl.2d	v4, v4, #10
	shl.2d	v10, v16, #5
	shl.2d	v15, v17, #5
	shl.2d	v17, v18, #5
	shl.2d	v16, v19, #5
	add.2d	v16, v4, v16
	add.2d	v17, v3, v17
	ldr	q3, [sp, #18240]
	add.2d	v18, v26, v15
	add.2d	v10, v21, v10
	add.2d	v4, v11, v12
	add.2d	v19, v4, v16
	add.2d	v4, v31, v13
	add.2d	v11, v4, v17
	add.2d	v4, v30, v14
	add.2d	v26, v4, v18
	add.2d	v3, v27, v3
	add.2d	v27, v3, v10
	movi.2d	v21, #0000000000000000
	movi.2d	v30, #0000000000000000
	tbz	w2, #0, LBB0_618
; %bb.615:                              ; %cond.load4810
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d27
	ldr	s21, [x3]
	tbnz	w2, #1, LBB0_619
LBB0_616:                               ; %else4820
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v25, v8
	tbz	w2, #2, LBB0_620
LBB0_617:                               ; %cond.load4822
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d26
	ld1.s	{ v21 }[2], [x3]
	ldr	q23, [sp, #1392]                ; 16-byte Folded Reload
	ldr	q29, [sp, #1472]                ; 16-byte Folded Reload
	tbnz	w2, #3, LBB0_621
	b	LBB0_622
LBB0_618:                               ; %else4814
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #1, LBB0_616
LBB0_619:                               ; %cond.load4816
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v27[1]
	ld1.s	{ v21 }[1], [x3]
	mov.16b	v25, v8
	tbnz	w2, #2, LBB0_617
LBB0_620:                               ; %else4826
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q23, [sp, #1392]                ; 16-byte Folded Reload
	ldr	q29, [sp, #1472]                ; 16-byte Folded Reload
	tbz	w2, #3, LBB0_622
LBB0_621:                               ; %cond.load4828
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v26[1]
	ld1.s	{ v21 }[3], [x3]
LBB0_622:                               ; %else4832
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q9, [sp, #1504]                 ; 16-byte Folded Reload
	ldr	q24, [sp, #1376]                ; 16-byte Folded Reload
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	ldr	q13, [sp, #1456]                ; 16-byte Folded Reload
	mov.16b	v1, v6
	ldr	q14, [sp, #1440]                ; 16-byte Folded Reload
	tbz	w2, #4, LBB0_626
; %bb.623:                              ; %cond.load4834
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d11
	ld1.s	{ v30 }[0], [x3]
	tbnz	w2, #5, LBB0_627
LBB0_624:                               ; %else4844
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #6, LBB0_628
LBB0_625:                               ; %cond.load4846
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d19
	ld1.s	{ v30 }[2], [x3]
	tbnz	w2, #7, LBB0_629
	b	LBB0_630
LBB0_626:                               ; %else4838
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #5, LBB0_624
LBB0_627:                               ; %cond.load4840
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v11[1]
	ld1.s	{ v30 }[1], [x3]
	tbnz	w2, #6, LBB0_625
LBB0_628:                               ; %else4850
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #7, LBB0_630
LBB0_629:                               ; %cond.load4852
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v19[1]
	ld1.s	{ v30 }[3], [x2]
LBB0_630:                               ; %else4856
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q3, [sp, #17968]
	ldr	q4, [sp, #17952]
	ldr	q19, [sp, #17936]
	ldr	q26, [sp, #17920]
	ldr	q27, [sp, #17984]
	ldr	q31, [sp, #18000]
	ldr	q11, [sp, #18016]
	ldr	q12, [sp, #18032]
	add.2d	v26, v26, v27
	add.2d	v27, v26, v10
	add.2d	v19, v19, v31
	add.2d	v26, v19, v18
	add.2d	v4, v4, v11
	add.2d	v19, v4, v17
	add.2d	v3, v3, v12
	add.2d	v18, v3, v16
	fmov	w2, s5
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbz	w2, #0, LBB0_638
; %bb.631:                              ; %cond.load4859
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d27
	ldr	s16, [x3]
	tbnz	w2, #1, LBB0_639
LBB0_632:                               ; %else4869
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #2, LBB0_640
LBB0_633:                               ; %cond.load4871
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d26
	ld1.s	{ v16 }[2], [x3]
	tbnz	w2, #3, LBB0_641
LBB0_634:                               ; %else4881
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #4, LBB0_642
LBB0_635:                               ; %cond.load4883
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d19
	ld1.s	{ v17 }[0], [x3]
	tbnz	w2, #5, LBB0_643
LBB0_636:                               ; %else4893
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #6, LBB0_644
LBB0_637:                               ; %cond.load4895
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d18
	ld1.s	{ v17 }[2], [x3]
	tbnz	w2, #7, LBB0_645
	b	LBB0_646
LBB0_638:                               ; %else4863
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #1, LBB0_632
LBB0_639:                               ; %cond.load4865
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v27[1]
	ld1.s	{ v16 }[1], [x3]
	tbnz	w2, #2, LBB0_633
LBB0_640:                               ; %else4875
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #3, LBB0_634
LBB0_641:                               ; %cond.load4877
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v26[1]
	ld1.s	{ v16 }[3], [x3]
	tbnz	w2, #4, LBB0_635
LBB0_642:                               ; %else4887
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #5, LBB0_636
LBB0_643:                               ; %cond.load4889
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v19[1]
	ld1.s	{ v17 }[1], [x3]
	tbnz	w2, #6, LBB0_637
LBB0_644:                               ; %else4899
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #7, LBB0_646
LBB0_645:                               ; %cond.load4901
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v18[1]
	ld1.s	{ v17 }[3], [x2]
LBB0_646:                               ; %else4905
                                        ;   in Loop: Header=BB0_8 Depth=3
	fadd.4s	v18, v21, v16
	fadd.4s	v16, v30, v17
	ldr	q3, [sp, #17712]
	ldr	q4, [sp, #17696]
	ldr	q17, [sp, #17680]
	ldr	q19, [sp, #17664]
	ldr	q21, [sp, #17728]
	ldr	q26, [sp, #17744]
	ldr	q27, [sp, #17760]
	ldr	q30, [sp, #17776]
	ldr	q6, [sp, #1152]                 ; 16-byte Folded Reload
	shl.2d	v31, v6, #5
	shl.2d	v10, v1, #5
	ldr	q6, [sp, #1312]                 ; 16-byte Folded Reload
	shl.2d	v11, v6, #5
	shl.2d	v12, v28, #5
	add.2d	v30, v30, v12
	add.2d	v27, v27, v11
	add.2d	v10, v26, v10
	add.2d	v21, v21, v31
	add.2d	v26, v19, v21
	add.2d	v21, v17, v10
	add.2d	v19, v4, v27
	add.2d	v17, v3, v30
	fmov	w2, s5
	tbz	w2, #0, LBB0_654
; %bb.647:                              ; %cond.store4908
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d26
	str	s18, [x3]
	ldr	q11, [sp, #1568]                ; 16-byte Folded Reload
	ldr	q12, [sp, #1536]                ; 16-byte Folded Reload
	mov.16b	v31, v22
	tbnz	w2, #1, LBB0_655
LBB0_648:                               ; %else4915
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v22, v7
	tbz	w2, #2, LBB0_656
LBB0_649:                               ; %cond.store4916
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d21
	st1.s	{ v18 }[2], [x3]
	tbnz	w2, #3, LBB0_657
LBB0_650:                               ; %else4923
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #4, LBB0_658
LBB0_651:                               ; %cond.store4924
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d19
	str	s16, [x3]
	tbnz	w2, #5, LBB0_659
LBB0_652:                               ; %else4931
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #6, LBB0_660
LBB0_653:                               ; %cond.store4932
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d17
	st1.s	{ v16 }[2], [x3]
	tbnz	w2, #7, LBB0_661
	b	LBB0_662
LBB0_654:                               ; %else4911
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q11, [sp, #1568]                ; 16-byte Folded Reload
	ldr	q12, [sp, #1536]                ; 16-byte Folded Reload
	mov.16b	v31, v22
	tbz	w2, #1, LBB0_648
LBB0_655:                               ; %cond.store4912
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v26[1]
	st1.s	{ v18 }[1], [x3]
	mov.16b	v22, v7
	tbnz	w2, #2, LBB0_649
LBB0_656:                               ; %else4919
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #3, LBB0_650
LBB0_657:                               ; %cond.store4920
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v21[1]
	st1.s	{ v18 }[3], [x3]
	tbnz	w2, #4, LBB0_651
LBB0_658:                               ; %else4927
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #5, LBB0_652
LBB0_659:                               ; %cond.store4928
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v19[1]
	st1.s	{ v16 }[1], [x3]
	tbnz	w2, #6, LBB0_653
LBB0_660:                               ; %else4935
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #7, LBB0_662
LBB0_661:                               ; %cond.store4936
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v17[1]
	st1.s	{ v16 }[3], [x2]
LBB0_662:                               ; %else4939
                                        ;   in Loop: Header=BB0_8 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v20, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v4, v3, #0
	ushll2.4s	v3, v3, #0
	uaddw2.2d	v28, v28, v3
	ldr	q5, [sp, #1312]                 ; 16-byte Folded Reload
	uaddw.2d	v5, v5, v3
	str	q5, [sp, #1312]                 ; 16-byte Folded Spill
	uaddw2.2d	v1, v1, v4
	str	q1, [sp, #720]                  ; 16-byte Folded Spill
	ldr	q3, [sp, #1152]                 ; 16-byte Folded Reload
	uaddw.2d	v3, v3, v4
	str	q3, [sp, #1152]                 ; 16-byte Folded Spill
	tbz	w1, #0, LBB0_606
	b	LBB0_1063
LBB0_663:                               ; %varying.coherent.false636
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1063
LBB0_664:                               ; %schedule.31
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q31, [sp, #1456]                ; 16-byte Folded Spill
	ldr	q6, [sp, #1552]                 ; 16-byte Folded Reload
	str	q28, [sp, #1408]                ; 16-byte Folded Spill
	str	q25, [sp, #1168]                ; 16-byte Folded Spill
	str	q11, [sp, #1568]                ; 16-byte Folded Spill
	str	q12, [sp, #1536]                ; 16-byte Folded Spill
	str	q24, [sp, #1376]                ; 16-byte Folded Spill
	str	q6, [sp, #1552]                 ; 16-byte Folded Spill
	cbz	w0, LBB0_669
; %bb.665:                              ; %convergence.cascade644.preheader
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
LBB0_666:                               ; %convergence.cascade644
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_3 Depth=2
                                        ;       Parent Loop BB0_8 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w2, s4
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	str	q24, [sp, #9760]
	str	q12, [sp, #9776]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #1568
	ldr	w6, [x6, x2]
	cmp	w6, #11
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #1520
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s5, w19
	ubfx	w19, w20, #1, #1
	mov.b	v5[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v5[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v5[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v5[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v5[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v5[6], w19
	add	x19, sp, #18, lsl #12           ; =73728
	add	x19, x19, #1512
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s3, w21
	ubfx	w21, w20, #1, #1
	mov.b	v3[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v3[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v3[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v3[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v3[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v3[6], w21
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	orr.8b	v4, v20, v3
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	and.8b	v7, v1, v5
	eor.8b	v7, v7, v4
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v4, v7
	dup.8b	v17, w7
	bit.8b	v3, v16, v17
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x19, w3, sxtw]
	bic.8b	v3, v5, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v4, v5, v4
	str	q23, [sp, #9728]
	str	q11, [sp, #9744]
	add	x3, sp, #2, lsl #12             ; =8192
	add	x3, x3, #1536
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v20, v4, v3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_670
; %bb.667:                              ; %convergence.cascade644
                                        ;   in Loop: Header=BB0_666 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_670
; %bb.668:                              ; %convergence.cascade644
                                        ;   in Loop: Header=BB0_666 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_666
	b	LBB0_670
LBB0_669:                               ; %schedule.31.convergence.cascade.exit645_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_670:                               ; %convergence.cascade.exit645
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1047
; %bb.671:                              ; %convergence.target.31.ready
                                        ;   in Loop: Header=BB0_8 Depth=3
	rbit	w1, w2
	clz	w1, w1
	ldr	q16, [sp, #17632]
	ldr	q3, [sp, #17648]
	ldr	q4, [sp, #17600]
	ldr	q7, [sp, #17616]
	ldr	q17, [sp, #17568]
	ldr	q5, [sp, #17584]
	ldr	q18, [sp, #17536]
	ldr	q19, [sp, #17552]
	mov	b21, v20[2]
	mov.b	v21[4], v20[3]
	ushll.2d	v21, v21, #0
	shl.2d	v21, v21, #63
	cmlt.2d	v30, v21, #0
	mov	b26, v20[0]
	mov.b	v26[4], v20[1]
	ldr	q27, [sp, #192]                 ; 16-byte Folded Reload
	mov.16b	v1, v30
	bsl.16b	v1, v27, v19
	str	q1, [sp, #1504]                 ; 16-byte Folded Spill
	ushll.2d	v26, v26, #0
	shl.2d	v26, v26, #63
	cmlt.2d	v15, v26, #0
	mov.16b	v1, v15
	bsl.16b	v1, v27, v18
	str	q1, [sp, #1488]                 ; 16-byte Folded Spill
	mov	b26, v20[6]
	mov.b	v26[4], v20[7]
	ushll.2d	v26, v26, #0
	shl.2d	v26, v26, #63
	mov.16b	v21, v14
	cmlt.2d	v14, v26, #0
	mov.16b	v26, v14
	bsl.16b	v26, v27, v5
	mov	b5, v20[4]
	mov.b	v5[4], v20[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	mov.16b	v19, v22
	cmlt.2d	v22, v5, #0
	mov.16b	v1, v22
	bsl.16b	v1, v27, v17
	str	q1, [sp, #1472]                 ; 16-byte Folded Spill
Lloh858:
	adrp	x2, lCPI0_20@PAGE
Lloh859:
	ldr	q27, [x2, lCPI0_20@PAGEOFF]
	mov.16b	v25, v30
	bsl.16b	v25, v27, v7
Lloh860:
	adrp	x2, lCPI0_21@PAGE
Lloh861:
	ldr	q31, [x2, lCPI0_21@PAGEOFF]
	mov.16b	v6, v15
	bsl.16b	v6, v31, v4
Lloh862:
	adrp	x2, lCPI0_22@PAGE
Lloh863:
	ldr	q8, [x2, lCPI0_22@PAGEOFF]
	bit.16b	v3, v8, v14
Lloh864:
	adrp	x2, lCPI0_23@PAGE
	mov.16b	v17, v0
	mov.16b	v2, v9
Lloh865:
	ldr	q9, [x2, lCPI0_23@PAGEOFF]
	bit.16b	v16, v9, v22
	str	q16, [sp, #17632]
	str	q3, [sp, #17648]
	str	q6, [sp, #17600]
	str	q25, [sp, #17616]
	ldr	q0, [sp, #1472]                 ; 16-byte Folded Reload
	str	q0, [sp, #17568]
	str	q26, [sp, #17584]
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	str	q0, [sp, #17536]
	ldr	q0, [sp, #1504]                 ; 16-byte Folded Reload
	str	q0, [sp, #17552]
	str	q8, [sp, #7728]
	str	q9, [sp, #7712]
	mov.16b	v9, v2
	mov.16b	v5, v21
	ldr	q24, [sp, #1376]                ; 16-byte Folded Reload
	mov.16b	v8, v19
	ldr	q21, [sp, #1168]                ; 16-byte Folded Reload
	ldr	q12, [sp, #1536]                ; 16-byte Folded Reload
	ldr	q11, [sp, #1568]                ; 16-byte Folded Reload
	mov.16b	v0, v17
	ldr	q6, [sp, #1136]                 ; 16-byte Folded Reload
	ldr	q25, [sp, #1120]                ; 16-byte Folded Reload
	ldr	q28, [sp, #1104]                ; 16-byte Folded Reload
	ldr	d2, [sp, #696]                  ; 8-byte Folded Reload
	str	q27, [sp, #7696]
	str	q31, [sp, #7680]
	lsl	w2, w1, #3
	and	x1, x2, #0x38
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #3584
	ldr	x4, [x3, x1]
	and	x2, x2, #0xf8
	add	x3, sp, #9, lsl #12             ; =36864
	add	x3, x3, #1384
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4, #32]
	ldp	q7, q16, [x4]
	mov	x5, #-8                         ; =0xfffffffffffffff8
	dup.2d	v17, x5
	bit.16b	v16, v17, v30
	bit.16b	v7, v17, v15
	bit.16b	v4, v17, v14
	bit.16b	v3, v17, v22
	stp	q3, q4, [x4, #32]
	stp	q7, q16, [x4]
Lloh866:
	adrp	x4, lCPI0_24@PAGE
Lloh867:
	ldr	q3, [x4, lCPI0_24@PAGEOFF]
Lloh868:
	adrp	x4, lCPI0_25@PAGE
Lloh869:
	ldr	q4, [x4, lCPI0_25@PAGEOFF]
	str	q3, [sp, #7792]
	str	q4, [sp, #7776]
Lloh870:
	adrp	x4, lCPI0_26@PAGE
Lloh871:
	ldr	q3, [x4, lCPI0_26@PAGEOFF]
Lloh872:
	adrp	x4, lCPI0_27@PAGE
Lloh873:
	ldr	q4, [x4, lCPI0_27@PAGEOFF]
	str	q3, [sp, #7760]
	str	q4, [sp, #7744]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #3648
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	x5, #-7                         ; =0xfffffffffffffff9
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v22
	bit.16b	v4, v7, v30
	bit.16b	v3, v7, v15
	bif.16b	v7, v16, v14
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh874:
	adrp	x4, lCPI0_28@PAGE
Lloh875:
	ldr	q3, [x4, lCPI0_28@PAGEOFF]
Lloh876:
	adrp	x4, lCPI0_29@PAGE
Lloh877:
	ldr	q4, [x4, lCPI0_29@PAGEOFF]
	str	q3, [sp, #7856]
	str	q4, [sp, #7840]
Lloh878:
	adrp	x4, lCPI0_30@PAGE
Lloh879:
	ldr	q3, [x4, lCPI0_30@PAGEOFF]
Lloh880:
	adrp	x4, lCPI0_31@PAGE
Lloh881:
	ldr	q4, [x4, lCPI0_31@PAGEOFF]
	str	q3, [sp, #7824]
	str	q4, [sp, #7808]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #3712
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	x5, #-6                         ; =0xfffffffffffffffa
	dup.2d	v17, x5
	bit.16b	v16, v17, v22
	bit.16b	v4, v17, v30
	bit.16b	v3, v17, v15
	bit.16b	v7, v17, v14
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh882:
	adrp	x4, lCPI0_32@PAGE
Lloh883:
	ldr	q3, [x4, lCPI0_32@PAGEOFF]
Lloh884:
	adrp	x4, lCPI0_33@PAGE
Lloh885:
	ldr	q4, [x4, lCPI0_33@PAGEOFF]
	str	q3, [sp, #7920]
	str	q4, [sp, #7904]
Lloh886:
	adrp	x4, lCPI0_34@PAGE
Lloh887:
	ldr	q3, [x4, lCPI0_34@PAGEOFF]
Lloh888:
	adrp	x4, lCPI0_35@PAGE
Lloh889:
	ldr	q4, [x4, lCPI0_35@PAGEOFF]
	str	q3, [sp, #7888]
	str	q4, [sp, #7872]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #3776
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	x5, #-5                         ; =0xfffffffffffffffb
	dup.2d	v17, x5
	bit.16b	v16, v17, v22
	bit.16b	v4, v17, v30
	bit.16b	v3, v17, v15
	bit.16b	v7, v17, v14
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh890:
	adrp	x4, lCPI0_36@PAGE
Lloh891:
	ldr	q3, [x4, lCPI0_36@PAGEOFF]
Lloh892:
	adrp	x4, lCPI0_37@PAGE
Lloh893:
	ldr	q4, [x4, lCPI0_37@PAGEOFF]
	str	q3, [sp, #7984]
	str	q4, [sp, #7968]
Lloh894:
	adrp	x4, lCPI0_38@PAGE
Lloh895:
	ldr	q3, [x4, lCPI0_38@PAGEOFF]
Lloh896:
	adrp	x4, lCPI0_39@PAGE
Lloh897:
	ldr	q4, [x4, lCPI0_39@PAGEOFF]
	str	q3, [sp, #7952]
	str	q4, [sp, #7936]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #3840
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	x5, #-4                         ; =0xfffffffffffffffc
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v22
	bit.16b	v4, v7, v30
	bit.16b	v3, v7, v15
	bif.16b	v7, v16, v14
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh898:
	adrp	x4, lCPI0_40@PAGE
Lloh899:
	ldr	q3, [x4, lCPI0_40@PAGEOFF]
Lloh900:
	adrp	x4, lCPI0_41@PAGE
Lloh901:
	ldr	q4, [x4, lCPI0_41@PAGEOFF]
	str	q3, [sp, #8048]
	str	q4, [sp, #8032]
Lloh902:
	adrp	x4, lCPI0_42@PAGE
Lloh903:
	ldr	q3, [x4, lCPI0_42@PAGEOFF]
Lloh904:
	adrp	x4, lCPI0_43@PAGE
Lloh905:
	ldr	q4, [x4, lCPI0_43@PAGEOFF]
	str	q3, [sp, #8016]
	str	q4, [sp, #8000]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #3904
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	x5, #-3                         ; =0xfffffffffffffffd
	dup.2d	v17, x5
	bit.16b	v16, v17, v22
	bit.16b	v4, v17, v30
	bit.16b	v3, v17, v15
	bit.16b	v7, v17, v14
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh906:
	adrp	x4, lCPI0_44@PAGE
Lloh907:
	ldr	q3, [x4, lCPI0_44@PAGEOFF]
Lloh908:
	adrp	x4, lCPI0_45@PAGE
Lloh909:
	ldr	q4, [x4, lCPI0_45@PAGEOFF]
	str	q3, [sp, #8112]
	str	q4, [sp, #8096]
Lloh910:
	adrp	x4, lCPI0_46@PAGE
Lloh911:
	ldr	q3, [x4, lCPI0_46@PAGEOFF]
Lloh912:
	adrp	x4, lCPI0_47@PAGE
Lloh913:
	ldr	q4, [x4, lCPI0_47@PAGEOFF]
	str	q3, [sp, #8080]
	str	q4, [sp, #8064]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #3968
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	x5, #-2                         ; =0xfffffffffffffffe
	dup.2d	v17, x5
	bit.16b	v16, v17, v22
	bit.16b	v4, v17, v30
	bit.16b	v3, v17, v15
	bit.16b	v7, v17, v14
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh914:
	adrp	x4, lCPI0_48@PAGE
Lloh915:
	ldr	q3, [x4, lCPI0_48@PAGEOFF]
Lloh916:
	adrp	x4, lCPI0_49@PAGE
Lloh917:
	ldr	q4, [x4, lCPI0_49@PAGEOFF]
	str	q3, [sp, #8176]
	str	q4, [sp, #8160]
Lloh918:
	adrp	x4, lCPI0_50@PAGE
Lloh919:
	ldr	q3, [x4, lCPI0_50@PAGEOFF]
Lloh920:
	adrp	x4, lCPI0_51@PAGE
Lloh921:
	ldr	q4, [x4, lCPI0_51@PAGEOFF]
	str	q3, [sp, #8144]
	str	q4, [sp, #8128]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #4032
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	orr.16b	v16, v22, v16
	orr.16b	v4, v30, v4
	orr.16b	v3, v15, v3
	orr.16b	v7, v14, v7
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh922:
	adrp	x4, lCPI0_52@PAGE
Lloh923:
	ldr	q3, [x4, lCPI0_52@PAGEOFF]
Lloh924:
	adrp	x4, lCPI0_53@PAGE
Lloh925:
	ldr	q4, [x4, lCPI0_53@PAGEOFF]
	str	q3, [sp, #8240]
	str	q4, [sp, #8224]
Lloh926:
	adrp	x4, lCPI0_54@PAGE
Lloh927:
	ldr	q3, [x4, lCPI0_54@PAGEOFF]
Lloh928:
	adrp	x4, lCPI0_55@PAGE
Lloh929:
	ldr	q4, [x4, lCPI0_55@PAGEOFF]
	str	q3, [sp, #8208]
	str	q4, [sp, #8192]
	add	x4, sp, #2, lsl #12             ; =8192
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	bic.16b	v16, v16, v22
	bic.16b	v4, v4, v30
	bic.16b	v3, v3, v15
	bic.16b	v7, v7, v14
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh930:
	adrp	x4, lCPI0_56@PAGE
Lloh931:
	ldr	q3, [x4, lCPI0_56@PAGEOFF]
Lloh932:
	adrp	x4, lCPI0_57@PAGE
Lloh933:
	ldr	q4, [x4, lCPI0_57@PAGEOFF]
	str	q3, [sp, #8304]
	str	q4, [sp, #8288]
Lloh934:
	adrp	x4, lCPI0_58@PAGE
Lloh935:
	ldr	q3, [x4, lCPI0_58@PAGEOFF]
Lloh936:
	adrp	x4, lCPI0_59@PAGE
Lloh937:
	ldr	q4, [x4, lCPI0_59@PAGEOFF]
	str	q3, [sp, #8272]
	str	q4, [sp, #8256]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #64
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	bic.16b	v16, v16, v22
	sub.2d	v16, v16, v22
	bic.16b	v4, v4, v30
	sub.2d	v4, v4, v30
	bic.16b	v3, v3, v15
	sub.2d	v3, v3, v15
	bic.16b	v7, v7, v14
	sub.2d	v7, v7, v14
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh938:
	adrp	x4, lCPI0_60@PAGE
Lloh939:
	ldr	q3, [x4, lCPI0_60@PAGEOFF]
Lloh940:
	adrp	x4, lCPI0_61@PAGE
Lloh941:
	ldr	q4, [x4, lCPI0_61@PAGEOFF]
	str	q3, [sp, #8368]
	str	q4, [sp, #8352]
Lloh942:
	adrp	x4, lCPI0_62@PAGE
Lloh943:
	ldr	q3, [x4, lCPI0_62@PAGEOFF]
Lloh944:
	adrp	x4, lCPI0_63@PAGE
Lloh945:
	ldr	q4, [x4, lCPI0_63@PAGEOFF]
	str	q3, [sp, #8336]
	str	q4, [sp, #8320]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #128
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #2                          ; =0x2
	dup.2d	v17, x5
	bit.16b	v16, v17, v22
	bit.16b	v4, v17, v30
	bit.16b	v3, v17, v15
	bit.16b	v7, v17, v14
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh946:
	adrp	x4, lCPI0_64@PAGE
Lloh947:
	ldr	q3, [x4, lCPI0_64@PAGEOFF]
Lloh948:
	adrp	x4, lCPI0_65@PAGE
Lloh949:
	ldr	q4, [x4, lCPI0_65@PAGEOFF]
	str	q3, [sp, #8432]
	str	q4, [sp, #8416]
Lloh950:
	adrp	x4, lCPI0_66@PAGE
Lloh951:
	ldr	q3, [x4, lCPI0_66@PAGEOFF]
Lloh952:
	adrp	x4, lCPI0_67@PAGE
Lloh953:
	ldr	q4, [x4, lCPI0_67@PAGEOFF]
	str	q3, [sp, #8400]
	str	q4, [sp, #8384]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #192
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #3                          ; =0x3
	dup.2d	v17, x5
	bit.16b	v16, v17, v22
	bit.16b	v4, v17, v30
	bit.16b	v3, v17, v15
	bit.16b	v7, v17, v14
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh954:
	adrp	x4, lCPI0_68@PAGE
Lloh955:
	ldr	q3, [x4, lCPI0_68@PAGEOFF]
Lloh956:
	adrp	x4, lCPI0_69@PAGE
Lloh957:
	ldr	q4, [x4, lCPI0_69@PAGEOFF]
	str	q3, [sp, #8496]
	str	q4, [sp, #8480]
Lloh958:
	adrp	x4, lCPI0_70@PAGE
Lloh959:
	ldr	q3, [x4, lCPI0_70@PAGEOFF]
Lloh960:
	adrp	x4, lCPI0_71@PAGE
Lloh961:
	ldr	q4, [x4, lCPI0_71@PAGEOFF]
	str	q3, [sp, #8464]
	str	q4, [sp, #8448]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #256
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #4                          ; =0x4
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v22
	bit.16b	v4, v7, v30
	bit.16b	v3, v7, v15
	bif.16b	v7, v16, v14
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh962:
	adrp	x4, lCPI0_72@PAGE
Lloh963:
	ldr	q3, [x4, lCPI0_72@PAGEOFF]
Lloh964:
	adrp	x4, lCPI0_73@PAGE
Lloh965:
	ldr	q4, [x4, lCPI0_73@PAGEOFF]
	str	q3, [sp, #8560]
	str	q4, [sp, #8544]
Lloh966:
	adrp	x4, lCPI0_74@PAGE
Lloh967:
	ldr	q3, [x4, lCPI0_74@PAGEOFF]
Lloh968:
	adrp	x4, lCPI0_75@PAGE
Lloh969:
	ldr	q4, [x4, lCPI0_75@PAGEOFF]
	str	q3, [sp, #8528]
	str	q4, [sp, #8512]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #320
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #5                          ; =0x5
	dup.2d	v17, x5
	bit.16b	v16, v17, v22
	bit.16b	v4, v17, v30
	bit.16b	v3, v17, v15
	bit.16b	v7, v17, v14
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh970:
	adrp	x4, lCPI0_76@PAGE
Lloh971:
	ldr	q3, [x4, lCPI0_76@PAGEOFF]
Lloh972:
	adrp	x4, lCPI0_77@PAGE
Lloh973:
	ldr	q4, [x4, lCPI0_77@PAGEOFF]
	str	q3, [sp, #8624]
	str	q4, [sp, #8608]
Lloh974:
	adrp	x4, lCPI0_78@PAGE
Lloh975:
	ldr	q3, [x4, lCPI0_78@PAGEOFF]
Lloh976:
	adrp	x4, lCPI0_79@PAGE
Lloh977:
	ldr	q4, [x4, lCPI0_79@PAGEOFF]
	str	q3, [sp, #8592]
	str	q4, [sp, #8576]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #384
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #6                          ; =0x6
	dup.2d	v17, x5
	bit.16b	v16, v17, v22
	bit.16b	v4, v17, v30
	bit.16b	v3, v17, v15
	bit.16b	v7, v17, v14
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh978:
	adrp	x4, lCPI0_80@PAGE
Lloh979:
	ldr	q3, [x4, lCPI0_80@PAGEOFF]
Lloh980:
	adrp	x4, lCPI0_81@PAGE
Lloh981:
	ldr	q4, [x4, lCPI0_81@PAGEOFF]
	str	q3, [sp, #8688]
	str	q4, [sp, #8672]
Lloh982:
	adrp	x4, lCPI0_82@PAGE
Lloh983:
	ldr	q3, [x4, lCPI0_82@PAGEOFF]
Lloh984:
	adrp	x4, lCPI0_83@PAGE
Lloh985:
	ldr	q4, [x4, lCPI0_83@PAGEOFF]
	str	q3, [sp, #8656]
	str	q4, [sp, #8640]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #448
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #7                          ; =0x7
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v22
	bit.16b	v4, v7, v30
	bit.16b	v3, v7, v15
	bif.16b	v7, v16, v14
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh986:
	adrp	x4, lCPI0_84@PAGE
Lloh987:
	ldr	q3, [x4, lCPI0_84@PAGEOFF]
Lloh988:
	adrp	x4, lCPI0_85@PAGE
Lloh989:
	ldr	q4, [x4, lCPI0_85@PAGEOFF]
	str	q3, [sp, #8752]
	str	q4, [sp, #8736]
Lloh990:
	adrp	x4, lCPI0_86@PAGE
Lloh991:
	ldr	q3, [x4, lCPI0_86@PAGEOFF]
Lloh992:
	adrp	x4, lCPI0_87@PAGE
Lloh993:
	ldr	q4, [x4, lCPI0_87@PAGEOFF]
	str	q3, [sp, #8720]
	str	q4, [sp, #8704]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #512
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #8                          ; =0x8
	dup.2d	v17, x5
	bit.16b	v16, v17, v22
	bit.16b	v4, v17, v30
	bit.16b	v3, v17, v15
	bit.16b	v7, v17, v14
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh994:
	adrp	x4, lCPI0_88@PAGE
Lloh995:
	ldr	q3, [x4, lCPI0_88@PAGEOFF]
Lloh996:
	adrp	x4, lCPI0_89@PAGE
Lloh997:
	ldr	q4, [x4, lCPI0_89@PAGEOFF]
	str	q3, [sp, #8816]
	str	q4, [sp, #8800]
Lloh998:
	adrp	x4, lCPI0_90@PAGE
Lloh999:
	ldr	q3, [x4, lCPI0_90@PAGEOFF]
Lloh1000:
	adrp	x4, lCPI0_91@PAGE
Lloh1001:
	ldr	q4, [x4, lCPI0_91@PAGEOFF]
	str	q3, [sp, #8784]
	str	q4, [sp, #8768]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #576
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #9                          ; =0x9
	dup.2d	v17, x5
	bit.16b	v16, v17, v22
	bit.16b	v4, v17, v30
	bit.16b	v3, v17, v15
	bit.16b	v7, v17, v14
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1002:
	adrp	x4, lCPI0_92@PAGE
Lloh1003:
	ldr	q3, [x4, lCPI0_92@PAGEOFF]
Lloh1004:
	adrp	x4, lCPI0_93@PAGE
Lloh1005:
	ldr	q4, [x4, lCPI0_93@PAGEOFF]
	str	q3, [sp, #8880]
	str	q4, [sp, #8864]
Lloh1006:
	adrp	x4, lCPI0_94@PAGE
Lloh1007:
	ldr	q3, [x4, lCPI0_94@PAGEOFF]
Lloh1008:
	adrp	x4, lCPI0_95@PAGE
Lloh1009:
	ldr	q4, [x4, lCPI0_95@PAGEOFF]
	str	q3, [sp, #8848]
	str	q4, [sp, #8832]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #640
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #10                         ; =0xa
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v22
	bit.16b	v4, v7, v30
	bit.16b	v3, v7, v15
	bif.16b	v7, v16, v14
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh1010:
	adrp	x4, lCPI0_96@PAGE
Lloh1011:
	ldr	q3, [x4, lCPI0_96@PAGEOFF]
Lloh1012:
	adrp	x4, lCPI0_97@PAGE
Lloh1013:
	ldr	q4, [x4, lCPI0_97@PAGEOFF]
	str	q3, [sp, #8944]
	str	q4, [sp, #8928]
Lloh1014:
	adrp	x4, lCPI0_98@PAGE
Lloh1015:
	ldr	q3, [x4, lCPI0_98@PAGEOFF]
Lloh1016:
	adrp	x4, lCPI0_99@PAGE
Lloh1017:
	ldr	q4, [x4, lCPI0_99@PAGEOFF]
	str	q3, [sp, #8912]
	str	q4, [sp, #8896]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #704
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #11                         ; =0xb
	dup.2d	v17, x5
	bit.16b	v16, v17, v22
	bit.16b	v4, v17, v30
	bit.16b	v3, v17, v15
	bit.16b	v7, v17, v14
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1018:
	adrp	x4, lCPI0_100@PAGE
Lloh1019:
	ldr	q3, [x4, lCPI0_100@PAGEOFF]
Lloh1020:
	adrp	x4, lCPI0_101@PAGE
Lloh1021:
	ldr	q4, [x4, lCPI0_101@PAGEOFF]
	str	q3, [sp, #9008]
	str	q4, [sp, #8992]
Lloh1022:
	adrp	x4, lCPI0_102@PAGE
Lloh1023:
	ldr	q3, [x4, lCPI0_102@PAGEOFF]
Lloh1024:
	adrp	x4, lCPI0_103@PAGE
Lloh1025:
	ldr	q4, [x4, lCPI0_103@PAGEOFF]
	str	q3, [sp, #8976]
	str	q4, [sp, #8960]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #768
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #12                         ; =0xc
	dup.2d	v17, x5
	bit.16b	v16, v17, v22
	bit.16b	v4, v17, v30
	bit.16b	v3, v17, v15
	bit.16b	v7, v17, v14
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1026:
	adrp	x4, lCPI0_104@PAGE
Lloh1027:
	ldr	q3, [x4, lCPI0_104@PAGEOFF]
Lloh1028:
	adrp	x4, lCPI0_105@PAGE
Lloh1029:
	ldr	q4, [x4, lCPI0_105@PAGEOFF]
	str	q3, [sp, #9072]
	str	q4, [sp, #9056]
Lloh1030:
	adrp	x4, lCPI0_106@PAGE
Lloh1031:
	ldr	q3, [x4, lCPI0_106@PAGEOFF]
Lloh1032:
	adrp	x4, lCPI0_107@PAGE
Lloh1033:
	ldr	q4, [x4, lCPI0_107@PAGEOFF]
	str	q3, [sp, #9040]
	str	q4, [sp, #9024]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #832
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #13                         ; =0xd
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v22
	bit.16b	v4, v7, v30
	bit.16b	v3, v7, v15
	bif.16b	v7, v16, v14
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh1034:
	adrp	x4, lCPI0_108@PAGE
Lloh1035:
	ldr	q3, [x4, lCPI0_108@PAGEOFF]
Lloh1036:
	adrp	x4, lCPI0_109@PAGE
Lloh1037:
	ldr	q4, [x4, lCPI0_109@PAGEOFF]
	str	q3, [sp, #9136]
	str	q4, [sp, #9120]
Lloh1038:
	adrp	x4, lCPI0_110@PAGE
Lloh1039:
	ldr	q3, [x4, lCPI0_110@PAGEOFF]
Lloh1040:
	adrp	x4, lCPI0_111@PAGE
Lloh1041:
	ldr	q4, [x4, lCPI0_111@PAGEOFF]
	str	q3, [sp, #9104]
	str	q4, [sp, #9088]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #896
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #14                         ; =0xe
	dup.2d	v17, x5
	bit.16b	v16, v17, v22
	bit.16b	v4, v17, v30
	bit.16b	v3, v17, v15
	bit.16b	v7, v17, v14
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1042:
	adrp	x4, lCPI0_112@PAGE
Lloh1043:
	ldr	q3, [x4, lCPI0_112@PAGEOFF]
Lloh1044:
	adrp	x4, lCPI0_113@PAGE
Lloh1045:
	ldr	q4, [x4, lCPI0_113@PAGEOFF]
	str	q3, [sp, #9200]
	str	q4, [sp, #9184]
Lloh1046:
	adrp	x4, lCPI0_114@PAGE
Lloh1047:
	ldr	q3, [x4, lCPI0_114@PAGEOFF]
Lloh1048:
	adrp	x4, lCPI0_115@PAGE
Lloh1049:
	ldr	q4, [x4, lCPI0_115@PAGEOFF]
	str	q3, [sp, #9168]
	str	q4, [sp, #9152]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #960
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #15                         ; =0xf
	dup.2d	v17, x5
	bit.16b	v16, v17, v22
	bit.16b	v4, v17, v30
	bit.16b	v3, v17, v15
	bit.16b	v7, v17, v14
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1050:
	adrp	x4, lCPI0_116@PAGE
Lloh1051:
	ldr	q3, [x4, lCPI0_116@PAGEOFF]
Lloh1052:
	adrp	x4, lCPI0_117@PAGE
Lloh1053:
	ldr	q4, [x4, lCPI0_117@PAGEOFF]
	str	q3, [sp, #9264]
	str	q4, [sp, #9248]
Lloh1054:
	adrp	x4, lCPI0_118@PAGE
Lloh1055:
	ldr	q3, [x4, lCPI0_118@PAGEOFF]
Lloh1056:
	adrp	x4, lCPI0_119@PAGE
Lloh1057:
	ldr	q4, [x4, lCPI0_119@PAGEOFF]
	str	q3, [sp, #9232]
	str	q4, [sp, #9216]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #1024
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #16                         ; =0x10
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v22
	bit.16b	v4, v7, v30
	bit.16b	v3, v7, v15
	bif.16b	v7, v16, v14
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh1058:
	adrp	x4, lCPI0_120@PAGE
Lloh1059:
	ldr	q3, [x4, lCPI0_120@PAGEOFF]
Lloh1060:
	adrp	x4, lCPI0_121@PAGE
Lloh1061:
	ldr	q4, [x4, lCPI0_121@PAGEOFF]
	str	q3, [sp, #9328]
	str	q4, [sp, #9312]
Lloh1062:
	adrp	x4, lCPI0_122@PAGE
Lloh1063:
	ldr	q3, [x4, lCPI0_122@PAGEOFF]
Lloh1064:
	adrp	x4, lCPI0_123@PAGE
Lloh1065:
	ldr	q4, [x4, lCPI0_123@PAGEOFF]
	str	q3, [sp, #9296]
	str	q4, [sp, #9280]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #1088
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #17                         ; =0x11
	dup.2d	v17, x5
	bit.16b	v16, v17, v22
	bit.16b	v4, v17, v30
	bit.16b	v3, v17, v15
	bit.16b	v7, v17, v14
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1066:
	adrp	x4, lCPI0_124@PAGE
Lloh1067:
	ldr	q3, [x4, lCPI0_124@PAGEOFF]
Lloh1068:
	adrp	x4, lCPI0_125@PAGE
Lloh1069:
	ldr	q4, [x4, lCPI0_125@PAGEOFF]
	str	q3, [sp, #9392]
	str	q4, [sp, #9376]
Lloh1070:
	adrp	x4, lCPI0_126@PAGE
Lloh1071:
	ldr	q3, [x4, lCPI0_126@PAGEOFF]
Lloh1072:
	adrp	x4, lCPI0_127@PAGE
Lloh1073:
	ldr	q4, [x4, lCPI0_127@PAGEOFF]
	str	q3, [sp, #9360]
	str	q4, [sp, #9344]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #1152
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #18                         ; =0x12
	dup.2d	v17, x5
	bit.16b	v16, v17, v22
	bit.16b	v4, v17, v30
	bit.16b	v3, v17, v15
	bit.16b	v7, v17, v14
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1074:
	adrp	x4, lCPI0_128@PAGE
Lloh1075:
	ldr	q3, [x4, lCPI0_128@PAGEOFF]
Lloh1076:
	adrp	x4, lCPI0_129@PAGE
Lloh1077:
	ldr	q4, [x4, lCPI0_129@PAGEOFF]
	str	q3, [sp, #9456]
	str	q4, [sp, #9440]
Lloh1078:
	adrp	x4, lCPI0_130@PAGE
Lloh1079:
	ldr	q3, [x4, lCPI0_130@PAGEOFF]
Lloh1080:
	adrp	x4, lCPI0_131@PAGE
Lloh1081:
	ldr	q4, [x4, lCPI0_131@PAGEOFF]
	str	q3, [sp, #9424]
	str	q4, [sp, #9408]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #1216
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #19                         ; =0x13
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v22
	bit.16b	v4, v7, v30
	bit.16b	v3, v7, v15
	bif.16b	v7, v16, v14
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh1082:
	adrp	x4, lCPI0_132@PAGE
Lloh1083:
	ldr	q3, [x4, lCPI0_132@PAGEOFF]
Lloh1084:
	adrp	x4, lCPI0_133@PAGE
Lloh1085:
	ldr	q4, [x4, lCPI0_133@PAGEOFF]
	str	q3, [sp, #9520]
	str	q4, [sp, #9504]
Lloh1086:
	adrp	x4, lCPI0_134@PAGE
Lloh1087:
	ldr	q3, [x4, lCPI0_134@PAGEOFF]
Lloh1088:
	adrp	x4, lCPI0_135@PAGE
Lloh1089:
	ldr	q4, [x4, lCPI0_135@PAGEOFF]
	str	q3, [sp, #9488]
	str	q4, [sp, #9472]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #1280
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #20                         ; =0x14
	dup.2d	v17, x5
	bit.16b	v16, v17, v22
	bit.16b	v4, v17, v30
	bit.16b	v3, v17, v15
	bit.16b	v7, v17, v14
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1090:
	adrp	x4, lCPI0_136@PAGE
Lloh1091:
	ldr	q3, [x4, lCPI0_136@PAGEOFF]
Lloh1092:
	adrp	x4, lCPI0_137@PAGE
Lloh1093:
	ldr	q4, [x4, lCPI0_137@PAGEOFF]
	str	q3, [sp, #9584]
	str	q4, [sp, #9568]
Lloh1094:
	adrp	x4, lCPI0_138@PAGE
Lloh1095:
	ldr	q3, [x4, lCPI0_138@PAGEOFF]
Lloh1096:
	adrp	x4, lCPI0_139@PAGE
Lloh1097:
	ldr	q4, [x4, lCPI0_139@PAGEOFF]
	str	q3, [sp, #9552]
	str	q4, [sp, #9536]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #1344
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #21                         ; =0x15
	dup.2d	v17, x5
	bit.16b	v16, v17, v22
	bit.16b	v4, v17, v30
	bit.16b	v3, v17, v15
	bit.16b	v7, v17, v14
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1098:
	adrp	x4, lCPI0_140@PAGE
Lloh1099:
	ldr	q3, [x4, lCPI0_140@PAGEOFF]
Lloh1100:
	adrp	x4, lCPI0_141@PAGE
Lloh1101:
	ldr	q4, [x4, lCPI0_141@PAGEOFF]
	str	q3, [sp, #9648]
	str	q4, [sp, #9632]
Lloh1102:
	adrp	x4, lCPI0_142@PAGE
Lloh1103:
	ldr	q3, [x4, lCPI0_142@PAGEOFF]
Lloh1104:
	adrp	x4, lCPI0_143@PAGE
Lloh1105:
	ldr	q4, [x4, lCPI0_143@PAGEOFF]
	str	q3, [sp, #9616]
	str	q4, [sp, #9600]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #1408
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #22                         ; =0x16
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v22
	bit.16b	v4, v7, v30
	bit.16b	v3, v7, v15
	bif.16b	v7, v16, v14
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh1106:
	adrp	x4, lCPI0_144@PAGE
Lloh1107:
	ldr	q3, [x4, lCPI0_144@PAGEOFF]
Lloh1108:
	adrp	x4, lCPI0_145@PAGE
Lloh1109:
	ldr	q4, [x4, lCPI0_145@PAGEOFF]
	str	q3, [sp, #9712]
	str	q4, [sp, #9696]
Lloh1110:
	adrp	x4, lCPI0_146@PAGE
Lloh1111:
	ldr	q3, [x4, lCPI0_146@PAGEOFF]
Lloh1112:
	adrp	x4, lCPI0_147@PAGE
Lloh1113:
	ldr	q4, [x4, lCPI0_147@PAGEOFF]
	str	q3, [sp, #9680]
	str	q4, [sp, #9664]
	add	x4, sp, #2, lsl #12             ; =8192
	add	x4, x4, #1472
	ldr	x1, [x4, x1]
	sub	x1, x1, x2
	add	x1, x3, x1
	ldp	q3, q4, [x1]
	ldp	q16, q7, [x1, #32]
	mov	w2, #23                         ; =0x17
	dup.2d	v17, x2
	bit.16b	v16, v17, v22
	bit.16b	v4, v17, v30
	bit.16b	v3, v17, v15
	bit.16b	v7, v17, v14
	stp	q3, q4, [x1]
	stp	q16, q7, [x1, #32]
	ldr	q3, [sp, #17504]
	ldr	q4, [sp, #17520]
	ldr	q7, [sp, #17472]
	ldr	q16, [sp, #17488]
	ldr	q17, [sp, #17440]
	ldr	q18, [sp, #17456]
	ldr	q19, [sp, #17408]
	ldr	q26, [sp, #17424]
	ldr	q27, [sp, #176]                 ; 16-byte Folded Reload
	bit.16b	v26, v27, v30
	bit.16b	v19, v27, v15
	bit.16b	v18, v27, v14
	bit.16b	v17, v27, v22
Lloh1114:
	adrp	x1, lCPI0_17@PAGE
Lloh1115:
	ldr	q27, [x1, lCPI0_17@PAGEOFF]
	bit.16b	v16, v27, v30
Lloh1116:
	adrp	x1, lCPI0_16@PAGE
Lloh1117:
	ldr	q27, [x1, lCPI0_16@PAGEOFF]
	bit.16b	v7, v27, v15
Lloh1118:
	adrp	x1, lCPI0_19@PAGE
Lloh1119:
	ldr	q27, [x1, lCPI0_19@PAGEOFF]
	bit.16b	v4, v27, v14
Lloh1120:
	adrp	x1, lCPI0_18@PAGE
Lloh1121:
	ldr	q27, [x1, lCPI0_18@PAGEOFF]
	bit.16b	v3, v27, v22
	str	q3, [sp, #17504]
	str	q4, [sp, #17520]
	str	q7, [sp, #17472]
	str	q16, [sp, #17488]
	str	q17, [sp, #17440]
	str	q18, [sp, #17456]
	str	q19, [sp, #17408]
	str	q26, [sp, #17424]
	bic.16b	v28, v28, v14
	mov.16b	v14, v5
	str	q28, [sp, #1104]                ; 16-byte Folded Spill
	bic.16b	v25, v25, v22
	mov.16b	v22, v8
	str	q25, [sp, #1120]                ; 16-byte Folded Spill
	mov.16b	v25, v21
	ldr	q28, [sp, #1408]                ; 16-byte Folded Reload
	bic.16b	v6, v6, v30
	str	q6, [sp, #1136]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #768]                  ; 16-byte Folded Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #768]                  ; 16-byte Folded Spill
	ldr	q31, [sp, #1456]                ; 16-byte Folded Reload
LBB0_672:                               ; %schedule.32
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	mov	w1, #128                        ; =0x80
	dup.2d	v5, x1
	ldr	q3, [sp, #1136]                 ; 16-byte Folded Reload
	cmgt.2d	v3, v5, v3
	ldr	q1, [sp, #768]                  ; 16-byte Folded Reload
	cmgt.2d	v4, v5, v1
	uzp1.4s	v3, v4, v3
	ldr	q4, [sp, #1120]                 ; 16-byte Folded Reload
	cmgt.2d	v4, v5, v4
	ldr	q6, [sp, #1104]                 ; 16-byte Folded Reload
	cmgt.2d	v16, v5, v6
	uzp1.4s	v4, v4, v16
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v21, v20, v3
	shl.8b	v3, v21, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w1, s4
	umaxv.8b	b3, v3
	fmov	w3, s3
	tbz	w3, #0, LBB0_678
; %bb.673:                              ; %schedule.32
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q3, [sp, #1136]                 ; 16-byte Folded Reload
	cmge.2d	v3, v3, v5
	cmge.2d	v4, v1, v5
	uzp1.4s	v3, v4, v3
	ldr	q4, [sp, #1120]                 ; 16-byte Folded Reload
	cmge.2d	v4, v4, v5
	ldr	q6, [sp, #1104]                 ; 16-byte Folded Reload
	cmge.2d	v5, v6, v5
	uzp1.4s	v4, v4, v5
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v10, v20, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_678
; %bb.674:                              ; %varying.divergent726
                                        ;   in Loop: Header=BB0_8 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	str	q24, [sp, #3904]
	str	q12, [sp, #3920]
	and	x1, x1, #0x7
	add	x3, sp, #3904
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #12, #0, ne
	cset	w1, ne
	cmp	w2, #255
	b.ne	LBB0_676
; %bb.675:                              ; %varying.divergent726
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbnz	w1, #0, LBB0_1086
LBB0_676:                               ; %convergence.overflow.resume729
                                        ;   in Loop: Header=BB0_8 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #18, lsl #12            ; =73728
	add	x2, x2, #1520
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s5, w4
	ubfx	w4, w5, #1, #1
	mov.b	v5[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v5[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v5[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v5[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v5[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v5[6], w4
	add	x4, sp, #18, lsl #12            ; =73728
	add	x4, x4, #1512
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v4, w5
	bit.8b	v5, v20, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x2, w3, uxtw]
	bic.8b	v3, v3, v4
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_1086
; %bb.677:                              ; %ready.overflow.resume731
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q23, [sp, #3872]
	str	q11, [sp, #3888]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #3872
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q23, [sp, #3840]
	str	q11, [sp, #3856]
	add	x5, sp, #3840
	str	w4, [x5, x2]
	ldr	q11, [sp, #3856]
	ldr	q23, [sp, #3840]
	str	q24, [sp, #3808]
	str	q12, [sp, #3824]
	add	x4, sp, #3808
	ldr	w4, [x4, x2]
	mov	w5, #12                         ; =0xc
	csel	w4, w5, w4, ne
	str	q24, [sp, #3776]
	str	q12, [sp, #3792]
	add	x5, sp, #3776
	str	w4, [x5, x2]
	mov	w2, #36                         ; =0x24
	mov	w4, #33                         ; =0x21
	ldr	q12, [sp, #3792]
	ldr	q24, [sp, #3776]
	b	LBB0_6
LBB0_678:                               ; %varying.coherent727
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w1, #0xff
	b.eq	LBB0_746
; %bb.679:                              ; %varying.coherent.true732
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
	tst	w2, #0xff
	b.eq	LBB0_1063
LBB0_680:                               ; %schedule.33
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v6, v31
	str	q13, [sp, #1456]                ; 16-byte Folded Spill
	str	q29, [sp, #1472]                ; 16-byte Folded Spill
	str	q0, [sp, #1488]                 ; 16-byte Folded Spill
	mov.16b	v29, v24
	mov.16b	v1, v12
	mov.16b	v24, v23
	mov.16b	v3, v22
	mov.16b	v22, v11
	mov.16b	v23, v25
	str	q9, [sp, #1504]                 ; 16-byte Folded Spill
	str	q3, [sp, #1232]                 ; 16-byte Folded Spill
	str	q14, [sp, #1440]                ; 16-byte Folded Spill
	mov	b3, v20[0]
	mov.b	v3[4], v20[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q0, [sp, #768]                  ; 16-byte Folded Reload
	and.16b	v16, v3, v0
	mov	b4, v20[2]
	mov.b	v4[4], v20[3]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	ldr	q0, [sp, #1136]                 ; 16-byte Folded Reload
	and.16b	v17, v4, v0
	mov	b5, v20[4]
	mov.b	v5[4], v20[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v27, v5, #0
	ldr	q0, [sp, #1120]                 ; 16-byte Folded Reload
	and.16b	v18, v27, v0
	mov	b5, v20[6]
	mov.b	v5[4], v20[7]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v30, v5, #0
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	and.16b	v19, v30, v0
	shl.8b	v5, v20, #7
	cmlt.8b	v21, v5, #0
	and.8b	v5, v21, v2
	addv.8b	b5, v5
	fmov	w2, s5
	mov	w3, #32                         ; =0x20
	dup.2d	v31, x3
	and.16b	v26, v3, v31
	mvn.16b	v3, v3
	sub.2d	v26, v26, v3
	and.16b	v3, v4, v31
	mvn.16b	v4, v4
	sub.2d	v11, v3, v4
	and.16b	v3, v27, v31
	and.16b	v4, v30, v31
	mvn.16b	v30, v30
	sub.2d	v4, v4, v30
	mov.d	x3, v4[1]
	mov.d	x4, v19[1]
	sdiv	x4, x4, x3
	mvn.16b	v27, v27
	sub.2d	v3, v3, v27
	fmov	x5, d4
	fmov	x6, d19
	sdiv	x6, x6, x5
	mul	x5, x6, x5
	fmov	d30, x6
	mov.d	v30[1], x4
	mov.d	x6, v3[1]
	mov.d	x7, v18[1]
	sdiv	x7, x7, x6
	fmov	x19, d3
	fmov	x20, d18
	sdiv	x20, x20, x19
	mul	x19, x20, x19
	fmov	d10, x20
	mov.d	v10[1], x7
	mov.d	x20, v11[1]
	mov.d	x21, v17[1]
	sdiv	x21, x21, x20
	fmov	x22, d11
	fmov	x23, d17
	sdiv	x23, x23, x22
	mul	x22, x23, x22
	fmov	d11, x23
	mov.d	v11[1], x21
	mov.d	x23, v26[1]
	mov.d	x24, v16[1]
	fmov	x25, d26
	fmov	x26, d16
	sdiv	x26, x26, x25
	mul	x25, x26, x25
	fmov	d12, x26
	sdiv	x24, x24, x23
	mov.d	v12[1], x24
	mul	x3, x4, x3
	fmov	d3, x5
	mov.d	v3[1], x3
	mul	x3, x7, x6
	fmov	d4, x19
	mov.d	v4[1], x3
	mul	x3, x21, x20
	fmov	d26, x22
	mov.d	v26[1], x3
	mul	x3, x24, x23
	fmov	d27, x25
	mov.d	v27[1], x3
	sub.2d	v16, v16, v27
	sub.2d	v17, v17, v26
	sub.2d	v4, v18, v4
	sub.2d	v3, v19, v3
	ldr	q27, [sp, #17536]
	ldr	q26, [sp, #17552]
	ldr	q19, [sp, #17568]
	ldr	q18, [sp, #17584]
	ldr	q31, [sp, #17648]
	ldr	q13, [sp, #17632]
	ldr	q14, [sp, #17616]
	shl.2d	v3, v3, #6
	shl.2d	v4, v4, #6
	shl.2d	v17, v17, #6
	shl.2d	v16, v16, #6
	ldr	q15, [sp, #17600]
	add.2d	v18, v18, v31
	add.2d	v18, v18, v3
	add.2d	v3, v19, v13
	add.2d	v19, v3, v4
	add.2d	v3, v26, v14
	add.2d	v26, v3, v17
	add.2d	v3, v27, v15
	add.2d	v27, v3, v16
	movi.2d	v13, #0000000000000000
	movi.2d	v14, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbz	w2, #0, LBB0_688
; %bb.681:                              ; %cond.load4941
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d27
	ldr	d13, [x3]
	tbnz	w2, #1, LBB0_689
LBB0_682:                               ; %else4951
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v31, v6
	tbz	w2, #2, LBB0_690
LBB0_683:                               ; %cond.load4953
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d26
	ld1.d	{ v14 }[0], [x3]
	tbnz	w2, #3, LBB0_691
LBB0_684:                               ; %else4963
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #4, LBB0_692
LBB0_685:                               ; %cond.load4965
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d19
	ld1.d	{ v16 }[0], [x3]
	tbnz	w2, #5, LBB0_693
LBB0_686:                               ; %else4975
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #6, LBB0_694
LBB0_687:                               ; %cond.load4977
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d18
	ld1.d	{ v17 }[0], [x3]
	tbnz	w2, #7, LBB0_695
	b	LBB0_696
LBB0_688:                               ; %else4945
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #1, LBB0_682
LBB0_689:                               ; %cond.load4947
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v27[1]
	ld1.d	{ v13 }[1], [x3]
	mov.16b	v31, v6
	tbnz	w2, #2, LBB0_683
LBB0_690:                               ; %else4957
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #3, LBB0_684
LBB0_691:                               ; %cond.load4959
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v26[1]
	ld1.d	{ v14 }[1], [x3]
	tbnz	w2, #4, LBB0_685
LBB0_692:                               ; %else4969
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #5, LBB0_686
LBB0_693:                               ; %cond.load4971
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v19[1]
	ld1.d	{ v16 }[1], [x3]
	tbnz	w2, #6, LBB0_687
LBB0_694:                               ; %else4981
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #7, LBB0_696
LBB0_695:                               ; %cond.load4983
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v18[1]
	ld1.d	{ v17 }[1], [x2]
LBB0_696:                               ; %else4987
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w2, #32                         ; =0x20
	dup.2d	v3, x2
	cmhi.2d	v4, v3, v14
	cmhi.2d	v18, v3, v13
	uzp1.4s	v4, v18, v4
	cmhi.2d	v18, v3, v16
	cmhi.2d	v3, v3, v17
	uzp1.4s	v3, v18, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	ldrb	w2, [x9, #512]
	and	w3, w2, #0x1
	fmov	s4, w3
	ubfx	w3, w2, #1, #1
	mov.b	v4[1], w3
	ubfx	w3, w2, #2, #1
	mov.b	v4[2], w3
	ubfx	w3, w2, #3, #1
	mov.b	v4[3], w3
	ubfx	w3, w2, #4, #1
	mov.b	v4[4], w3
	ubfx	w3, w2, #5, #1
	mov.b	v4[5], w3
	ubfx	w3, w2, #6, #1
	mov.b	v4[6], w3
	lsr	w2, w2, #7
	mov.b	v4[7], w2
	bif.8b	v3, v4, v21
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x9, #512]
	shl.2d	v3, v11, #5
	shl.2d	v4, v12, #5
	shl.2d	v18, v30, #5
	shl.2d	v19, v10, #5
	add.2d	v16, v16, v19
	add.2d	v17, v17, v18
	add.2d	v18, v13, v4
	add.2d	v19, v14, v3
	ldr	q3, [sp, #17312]
	ldr	q4, [sp, #17328]
	ldr	q21, [sp, #17280]
	ldr	q26, [sp, #17296]
	mov	b27, v20[2]
	mov.b	v27[4], v20[3]
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	mov	b30, v20[0]
	mov.b	v30[4], v20[1]
	bit.16b	v26, v19, v27
	ushll.2d	v27, v30, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	bit.16b	v21, v18, v27
	mov	b27, v20[6]
	mov.b	v27[4], v20[7]
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	bit.16b	v4, v17, v27
	mov	b27, v20[4]
	mov.b	v27[4], v20[5]
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	bit.16b	v3, v16, v27
	str	q3, [sp, #17312]
	str	q4, [sp, #17328]
	str	q21, [sp, #17280]
	str	q26, [sp, #17296]
	mov	w2, #128                        ; =0x80
	dup.2d	v26, x2
	cmhi.2d	v3, v26, v18
	cmhi.2d	v4, v26, v19
	uzp1.4s	v3, v3, v4
	cmhi.2d	v4, v26, v16
	cmhi.2d	v21, v26, v17
	uzp1.4s	v4, v4, v21
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v21, v20, v3
	shl.8b	v3, v21, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w2, s4
	umaxv.8b	b3, v3
	fmov	w3, s3
	tbz	w3, #0, LBB0_702
; %bb.697:                              ; %else4987
                                        ;   in Loop: Header=BB0_8 Depth=3
	cmhs.2d	v3, v18, v26
	cmhs.2d	v4, v19, v26
	uzp1.4s	v3, v3, v4
	cmhs.2d	v4, v16, v26
	cmhs.2d	v16, v17, v26
	uzp1.4s	v4, v4, v16
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v10, v20, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_702
; %bb.698:                              ; %varying.divergent737
                                        ;   in Loop: Header=BB0_8 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	str	q29, [sp, #4064]
	str	q1, [sp, #4080]
	and	x1, x1, #0x7
	add	x3, sp, #4064
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #13, #0, ne
	cset	w1, ne
	cmp	w2, #255
	mov.16b	v25, v23
	b.ne	LBB0_700
; %bb.699:                              ; %varying.divergent737
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbnz	w1, #0, LBB0_1086
LBB0_700:                               ; %convergence.overflow.resume740
                                        ;   in Loop: Header=BB0_8 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #18, lsl #12            ; =73728
	add	x2, x2, #1520
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s5, w4
	ubfx	w4, w5, #1, #1
	mov.b	v5[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v5[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v5[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v5[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v5[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v5[6], w4
	add	x4, sp, #18, lsl #12            ; =73728
	add	x4, x4, #1512
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v4, w5
	bit.8b	v5, v20, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x2, w3, uxtw]
	bic.8b	v3, v3, v4
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_1086
; %bb.701:                              ; %ready.overflow.resume742
                                        ;   in Loop: Header=BB0_8 Depth=3
	zip2.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldp	q6, q4, [sp, #512]              ; 32-byte Folded Reload
	and.16b	v5, v3, v6
	zip1.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v4, v3, v4
	stp	q5, q4, [sp, #512]              ; 32-byte Folded Spill
	str	q24, [sp, #4032]
	str	q22, [sp, #4048]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #4032
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q24, [sp, #4000]
	str	q22, [sp, #4016]
	add	x5, sp, #4000
	str	w4, [x5, x2]
	ldr	q11, [sp, #4016]
	ldr	q23, [sp, #4000]
	str	q29, [sp, #3968]
	str	q1, [sp, #3984]
	add	x4, sp, #3968
	ldr	w4, [x4, x2]
	mov	w5, #13                         ; =0xd
	csel	w4, w5, w4, ne
	str	q29, [sp, #3936]
	str	q1, [sp, #3952]
	add	x5, sp, #3936
	str	w4, [x5, x2]
	mov	w2, #35                         ; =0x23
	mov	w4, #34                         ; =0x22
	ldr	q12, [sp, #3952]
	ldr	q24, [sp, #3936]
	b	LBB0_456
LBB0_702:                               ; %varying.coherent738
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	mov.16b	v25, v23
	mov.16b	v12, v1
	b.eq	LBB0_721
; %bb.703:                              ; %varying.coherent.true743
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v23, v24
	tbnz	w1, #0, LBB0_1057
; %bb.704:                              ; %schedule.34.thread
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q3, [sp, #17664]
	ldr	q4, [sp, #17680]
	ldr	q7, [sp, #17696]
	ldr	q16, [sp, #17712]
	ldr	q17, [sp, #17776]
	ldr	q18, [sp, #17760]
	ldr	q19, [sp, #17744]
	ldr	q21, [sp, #17728]
	ldr	q26, [sp, #17280]
	ldr	q27, [sp, #17296]
	ldr	q30, [sp, #17312]
	ldr	q31, [sp, #17328]
	shl.2d	v31, v31, #5
	shl.2d	v30, v30, #5
	shl.2d	v27, v27, #5
	shl.2d	v26, v26, #5
	add.2d	v16, v16, v17
	add.2d	v17, v16, v31
	add.2d	v7, v7, v18
	add.2d	v18, v7, v30
	add.2d	v4, v4, v19
	add.2d	v19, v4, v27
	add.2d	v3, v3, v21
	add.2d	v21, v3, v26
	fmov	w1, s5
	movi.2d	v5, #0000000000000000
	movi.2d	v16, #0000000000000000
	mov.16b	v11, v22
	mov.16b	v24, v29
	tbz	w1, #0, LBB0_706
; %bb.705:                              ; %cond.load5858
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d21
	ldr	s5, [x2]
LBB0_706:                               ; %else5862
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q3, [sp, #1216]                 ; 16-byte Folded Reload
	ldr	q1, [sp, #1360]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	ldr	q29, [sp, #1472]                ; 16-byte Folded Reload
	ldr	q13, [sp, #1456]                ; 16-byte Folded Reload
	str	q1, [sp, #1360]                 ; 16-byte Folded Spill
	str	q3, [sp, #1216]                 ; 16-byte Folded Spill
	tbz	w1, #1, LBB0_715
; %bb.707:                              ; %cond.load5864
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v21[1]
	ld1.s	{ v5 }[1], [x2]
	ldr	q22, [sp, #1232]                ; 16-byte Folded Reload
	mov.16b	v31, v6
	ldr	q3, [sp, #1072]                 ; 16-byte Folded Reload
	ldr	q14, [sp, #1440]                ; 16-byte Folded Reload
	ldr	q9, [sp, #1504]                 ; 16-byte Folded Reload
	tbnz	w1, #2, LBB0_716
LBB0_708:                               ; %else5874
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q1, [sp, #1088]                 ; 16-byte Folded Reload
	tbz	w1, #3, LBB0_717
LBB0_709:                               ; %cond.load5876
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v19[1]
	ld1.s	{ v5 }[3], [x2]
	tbnz	w1, #4, LBB0_718
LBB0_710:                               ; %else5886
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #5, LBB0_719
LBB0_711:                               ; %cond.load5888
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v18[1]
	ld1.s	{ v16 }[1], [x2]
	tbnz	w1, #6, LBB0_720
LBB0_712:                               ; %else5898
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q1, [sp, #1088]                 ; 16-byte Folded Spill
	str	q3, [sp, #1072]                 ; 16-byte Folded Spill
	tbz	w1, #7, LBB0_714
LBB0_713:                               ; %cond.load5900
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x1, v17[1]
	ld1.s	{ v16 }[3], [x1]
LBB0_714:                               ; %else5904
                                        ;   in Loop: Header=BB0_8 Depth=3
	zip2.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q4, [sp, #512]                  ; 16-byte Folded Reload
	bit.16b	v4, v16, v3
	str	q4, [sp, #512]                  ; 16-byte Folded Spill
	zip1.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q4, [sp, #528]                  ; 16-byte Folded Reload
	bit.16b	v4, v5, v3
	str	q4, [sp, #528]                  ; 16-byte Folded Spill
	b	LBB0_722
LBB0_715:                               ; %else5868
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q22, [sp, #1232]                ; 16-byte Folded Reload
	mov.16b	v31, v6
	ldr	q3, [sp, #1072]                 ; 16-byte Folded Reload
	ldr	q14, [sp, #1440]                ; 16-byte Folded Reload
	ldr	q9, [sp, #1504]                 ; 16-byte Folded Reload
	tbz	w1, #2, LBB0_708
LBB0_716:                               ; %cond.load5870
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d19
	ld1.s	{ v5 }[2], [x2]
	ldr	q1, [sp, #1088]                 ; 16-byte Folded Reload
	tbnz	w1, #3, LBB0_709
LBB0_717:                               ; %else5880
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #4, LBB0_710
LBB0_718:                               ; %cond.load5882
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d18
	ld1.s	{ v16 }[0], [x2]
	tbnz	w1, #5, LBB0_711
LBB0_719:                               ; %else5892
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #6, LBB0_712
LBB0_720:                               ; %cond.load5894
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d17
	ld1.s	{ v16 }[2], [x2]
	str	q1, [sp, #1088]                 ; 16-byte Folded Spill
	str	q3, [sp, #1072]                 ; 16-byte Folded Spill
	tbnz	w1, #7, LBB0_713
	b	LBB0_714
LBB0_721:                               ; %varying.coherent.false744
                                        ;   in Loop: Header=BB0_8 Depth=3
	zip2.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldp	q5, q4, [sp, #512]              ; 32-byte Folded Reload
	and.16b	v1, v3, v5
	zip1.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v4, v3, v4
	stp	q1, q4, [sp, #512]              ; 32-byte Folded Spill
	ldr	q1, [sp, #1232]                 ; 16-byte Folded Reload
	ldr	q14, [sp, #1440]                ; 16-byte Folded Reload
	ldr	q9, [sp, #1504]                 ; 16-byte Folded Reload
	mov.16b	v11, v22
	mov.16b	v22, v1
	mov.16b	v23, v24
	mov.16b	v24, v29
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	ldr	q29, [sp, #1472]                ; 16-byte Folded Reload
	ldr	q13, [sp, #1456]                ; 16-byte Folded Reload
	tbnz	w1, #0, LBB0_1063
LBB0_722:                               ; %schedule.35
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q28, [sp, #1408]                ; 16-byte Folded Spill
	mov.16b	v28, v9
	mov.16b	v9, v14
	mov.16b	v1, v22
	mov.16b	v22, v0
	mov.16b	v15, v1
	mov.16b	v14, v29
	mov.16b	v29, v25
	mov.16b	v25, v31
	cbz	w0, LBB0_727
; %bb.723:                              ; %convergence.cascade747.preheader
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
LBB0_724:                               ; %convergence.cascade747
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_3 Depth=2
                                        ;       Parent Loop BB0_8 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w2, s4
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	str	q24, [sp, #4128]
	str	q12, [sp, #4144]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #1, lsl #12             ; =4096
	add	x6, x6, #32
	ldr	w6, [x6, x2]
	cmp	w6, #13
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #1520
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s5, w19
	ubfx	w19, w20, #1, #1
	mov.b	v5[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v5[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v5[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v5[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v5[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v5[6], w19
	add	x19, sp, #18, lsl #12           ; =73728
	add	x19, x19, #1512
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s3, w21
	ubfx	w21, w20, #1, #1
	mov.b	v3[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v3[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v3[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v3[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v3[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v3[6], w21
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	orr.8b	v4, v20, v3
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	and.8b	v7, v1, v5
	eor.8b	v7, v7, v4
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v4, v7
	dup.8b	v17, w7
	bit.8b	v3, v16, v17
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x19, w3, sxtw]
	bic.8b	v3, v5, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v4, v5, v4
	str	q23, [sp, #4096]
	str	q11, [sp, #4112]
	add	x3, sp, #1, lsl #12             ; =4096
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v20, v4, v3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_728
; %bb.725:                              ; %convergence.cascade747
                                        ;   in Loop: Header=BB0_724 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_728
; %bb.726:                              ; %convergence.cascade747
                                        ;   in Loop: Header=BB0_724 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_724
	b	LBB0_728
LBB0_727:                               ; %schedule.35.convergence.cascade.exit748_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_728:                               ; %convergence.cascade.exit748
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1048
; %bb.729:                              ; %convergence.target.35.ready
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q1, [sp, #704]                  ; 16-byte Folded Reload
	dup.4s	v3, v1[0]
	ldrb	w1, [x9, #512]
	ubfx	w2, w1, #3, #1
	ubfx	w3, w1, #2, #1
	ubfx	w4, w1, #1, #1
	and	w5, w1, #0x1
	lsr	w6, w1, #7
	ubfx	w7, w1, #6, #1
	ubfx	w19, w1, #5, #1
	ubfx	w1, w1, #4, #1
	fmov	s4, w1
	mov.h	v4[1], w19
	mov.h	v4[2], w7
	mov.h	v4[3], w6
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	fmov	s7, w5
	mov.h	v7[1], w4
	mov.h	v7[2], w3
	mov.h	v7[3], w2
	ldr	q5, [sp, #512]                  ; 16-byte Folded Reload
	bif.16b	v5, v3, v4
	ushll.4s	v4, v7, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q7, [sp, #528]                  ; 16-byte Folded Reload
	mov.16b	v17, v4
	bsl.16b	v17, v7, v3
	ldr	q3, [sp, #17456]
	ldr	q4, [sp, #17440]
	ldr	q7, [sp, #17424]
	ldr	q16, [sp, #17408]
	ldr	q18, [sp, #17472]
	ldr	q19, [sp, #17488]
	ldr	q21, [sp, #17504]
	ldr	q26, [sp, #17520]
	ldr	q1, [sp, #768]                  ; 16-byte Folded Reload
	shl.2d	v27, v1, #5
	ldr	q6, [sp, #1136]                 ; 16-byte Folded Reload
	shl.2d	v30, v6, #5
	ldr	q6, [sp, #1120]                 ; 16-byte Folded Reload
	shl.2d	v31, v6, #5
	ldr	q6, [sp, #1104]                 ; 16-byte Folded Reload
	shl.2d	v8, v6, #5
	add.2d	v26, v26, v8
	add.2d	v31, v21, v31
	add.2d	v19, v19, v30
	add.2d	v18, v18, v27
	add.2d	v21, v16, v18
	add.2d	v19, v7, v19
	add.2d	v18, v4, v31
	add.2d	v16, v3, v26
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w1, s3
	mov.16b	v31, v25
	tbz	w1, #0, LBB0_737
; %bb.730:                              ; %cond.store5907
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d21
	str	s17, [x2]
	tbnz	w1, #1, LBB0_738
LBB0_731:                               ; %else5914
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #2, LBB0_739
LBB0_732:                               ; %cond.store5915
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d19
	st1.s	{ v17 }[2], [x2]
	mov.16b	v25, v29
	tbnz	w1, #3, LBB0_740
LBB0_733:                               ; %else5922
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v29, v14
	tbz	w1, #4, LBB0_741
LBB0_734:                               ; %cond.store5923
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d18
	str	s5, [x2]
	mov.16b	v6, v15
	tbnz	w1, #5, LBB0_742
LBB0_735:                               ; %else5930
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #6, LBB0_743
LBB0_736:                               ; %cond.store5931
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d16
	st1.s	{ v5 }[2], [x2]
	mov.16b	v0, v22
	tbnz	w1, #7, LBB0_744
	b	LBB0_745
LBB0_737:                               ; %else5910
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #1, LBB0_731
LBB0_738:                               ; %cond.store5911
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v21[1]
	st1.s	{ v17 }[1], [x2]
	tbnz	w1, #2, LBB0_732
LBB0_739:                               ; %else5918
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v25, v29
	tbz	w1, #3, LBB0_733
LBB0_740:                               ; %cond.store5919
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v19[1]
	st1.s	{ v17 }[3], [x2]
	mov.16b	v29, v14
	tbnz	w1, #4, LBB0_734
LBB0_741:                               ; %else5926
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v6, v15
	tbz	w1, #5, LBB0_735
LBB0_742:                               ; %cond.store5927
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v18[1]
	st1.s	{ v5 }[1], [x2]
	tbnz	w1, #6, LBB0_736
LBB0_743:                               ; %else5934
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v0, v22
	tbz	w1, #7, LBB0_745
LBB0_744:                               ; %cond.store5935
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x1, v16[1]
	st1.s	{ v5 }[3], [x1]
LBB0_745:                               ; %else5938
                                        ;   in Loop: Header=BB0_8 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v20, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v4, v3, #0
	ushll2.4s	v3, v3, #0
	ldr	q5, [sp, #1104]                 ; 16-byte Folded Reload
	uaddw2.2d	v5, v5, v3
	str	q5, [sp, #1104]                 ; 16-byte Folded Spill
	ldr	q5, [sp, #1120]                 ; 16-byte Folded Reload
	uaddw.2d	v5, v5, v3
	str	q5, [sp, #1120]                 ; 16-byte Folded Spill
	ldr	q3, [sp, #1136]                 ; 16-byte Folded Reload
	uaddw2.2d	v3, v3, v4
	str	q3, [sp, #1136]                 ; 16-byte Folded Spill
	uaddw.2d	v1, v1, v4
	str	q1, [sp, #768]                  ; 16-byte Folded Spill
	mov.16b	v14, v9
	mov.16b	v9, v28
	ldr	q28, [sp, #1408]                ; 16-byte Folded Reload
	mov.16b	v22, v6
	b	LBB0_672
LBB0_746:                               ; %varying.coherent.false733
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1063
LBB0_747:                               ; %schedule.36
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v6, v31
	cbz	w0, LBB0_752
; %bb.748:                              ; %convergence.cascade772.preheader
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
LBB0_749:                               ; %convergence.cascade772
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_3 Depth=2
                                        ;       Parent Loop BB0_8 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w2, s4
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	str	q24, [sp, #7648]
	str	q12, [sp, #7664]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #1, lsl #12             ; =4096
	add	x6, x6, #3552
	ldr	w6, [x6, x2]
	cmp	w6, #12
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #1520
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s5, w19
	ubfx	w19, w20, #1, #1
	mov.b	v5[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v5[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v5[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v5[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v5[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v5[6], w19
	add	x19, sp, #18, lsl #12           ; =73728
	add	x19, x19, #1512
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s3, w21
	ubfx	w21, w20, #1, #1
	mov.b	v3[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v3[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v3[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v3[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v3[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v3[6], w21
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	orr.8b	v4, v20, v3
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	and.8b	v7, v1, v5
	eor.8b	v7, v7, v4
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v4, v7
	dup.8b	v17, w7
	bit.8b	v3, v16, v17
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x19, w3, sxtw]
	bic.8b	v3, v5, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v4, v5, v4
	str	q23, [sp, #7616]
	str	q11, [sp, #7632]
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #3520
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v20, v4, v3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_753
; %bb.750:                              ; %convergence.cascade772
                                        ;   in Loop: Header=BB0_749 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_753
; %bb.751:                              ; %convergence.cascade772
                                        ;   in Loop: Header=BB0_749 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_749
	b	LBB0_753
LBB0_752:                               ; %schedule.36.convergence.cascade.exit773_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_753:                               ; %convergence.cascade.exit773
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1046
; %bb.754:                              ; %convergence.target.36.ready
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q18, [sp, #17248]
	ldr	q16, [sp, #17264]
	ldr	q5, [sp, #17216]
	ldr	q3, [sp, #17232]
	ldr	q17, [sp, #17184]
	ldr	q4, [sp, #17200]
	ldr	q7, [sp, #17152]
	ldr	q21, [sp, #17168]
	mov	b19, v20[2]
	mov.b	v19[4], v20[3]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	ldr	q8, [sp, #160]                  ; 16-byte Folded Reload
	bit.16b	v21, v8, v19
	mov	b26, v20[0]
	mov.b	v26[4], v20[1]
	ushll.2d	v26, v26, #0
	shl.2d	v26, v26, #63
	cmlt.2d	v26, v26, #0
	mov	b27, v20[6]
	mov.b	v27[4], v20[7]
	bit.16b	v7, v8, v26
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	bit.16b	v4, v8, v27
	mov	b30, v20[4]
	mov.b	v30[4], v20[5]
	ushll.2d	v30, v30, #0
	shl.2d	v30, v30, #63
	cmlt.2d	v30, v30, #0
Lloh1122:
	adrp	x1, lCPI0_17@PAGE
Lloh1123:
	ldr	q31, [x1, lCPI0_17@PAGEOFF]
	bit.16b	v3, v31, v19
Lloh1124:
	adrp	x1, lCPI0_18@PAGE
Lloh1125:
	ldr	q31, [x1, lCPI0_18@PAGEOFF]
	bit.16b	v18, v31, v30
Lloh1126:
	adrp	x1, lCPI0_16@PAGE
Lloh1127:
	ldr	q31, [x1, lCPI0_16@PAGEOFF]
	str	q18, [sp, #17248]
Lloh1128:
	adrp	x1, lCPI0_19@PAGE
Lloh1129:
	ldr	q18, [x1, lCPI0_19@PAGEOFF]
	bit.16b	v17, v8, v30
	bit.16b	v16, v18, v27
	str	q16, [sp, #17264]
	bit.16b	v5, v31, v26
	str	q5, [sp, #17216]
	str	q3, [sp, #17232]
	str	q17, [sp, #17184]
	str	q4, [sp, #17200]
	str	q7, [sp, #17152]
	str	q21, [sp, #17168]
	ldr	q1, [sp, #1280]                 ; 16-byte Folded Reload
	bic.16b	v1, v1, v27
	str	q1, [sp, #1280]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #1520]                 ; 16-byte Folded Reload
	bic.16b	v1, v1, v30
	str	q1, [sp, #1520]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #1328]                 ; 16-byte Folded Reload
	bic.16b	v1, v1, v19
	str	q1, [sp, #1328]                 ; 16-byte Folded Spill
	bic.16b	v29, v29, v26
	mov.16b	v31, v6
LBB0_755:                               ; %schedule.37
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	mov	w1, #128                        ; =0x80
	dup.2d	v5, x1
	ldr	q6, [sp, #1328]                 ; 16-byte Folded Reload
	cmgt.2d	v3, v5, v6
	cmgt.2d	v4, v5, v29
	uzp1.4s	v3, v4, v3
	ldr	q7, [sp, #1520]                 ; 16-byte Folded Reload
	cmgt.2d	v4, v5, v7
	ldr	q1, [sp, #1280]                 ; 16-byte Folded Reload
	cmgt.2d	v16, v5, v1
	uzp1.4s	v4, v4, v16
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v21, v20, v3
	shl.8b	v3, v21, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w1, s4
	umaxv.8b	b3, v3
	fmov	w3, s3
	tbz	w3, #0, LBB0_761
; %bb.756:                              ; %schedule.37
                                        ;   in Loop: Header=BB0_8 Depth=3
	cmge.2d	v3, v6, v5
	cmge.2d	v4, v29, v5
	uzp1.4s	v3, v4, v3
	cmge.2d	v4, v7, v5
	cmge.2d	v5, v1, v5
	uzp1.4s	v4, v4, v5
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v10, v20, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_761
; %bb.757:                              ; %varying.divergent790
                                        ;   in Loop: Header=BB0_8 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	str	q24, [sp, #4288]
	str	q12, [sp, #4304]
	and	x1, x1, #0x7
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #192
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #14, #0, ne
	cset	w1, ne
	cmp	w2, #255
	b.ne	LBB0_759
; %bb.758:                              ; %varying.divergent790
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbnz	w1, #0, LBB0_1086
LBB0_759:                               ; %convergence.overflow.resume793
                                        ;   in Loop: Header=BB0_8 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #18, lsl #12            ; =73728
	add	x2, x2, #1520
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s5, w4
	ubfx	w4, w5, #1, #1
	mov.b	v5[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v5[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v5[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v5[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v5[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v5[6], w4
	add	x4, sp, #18, lsl #12            ; =73728
	add	x4, x4, #1512
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v4, w5
	bit.8b	v5, v20, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x2, w3, uxtw]
	bic.8b	v3, v3, v4
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_1086
; %bb.760:                              ; %ready.overflow.resume795
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q23, [sp, #4256]
	str	q11, [sp, #4272]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #160
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q23, [sp, #4224]
	str	q11, [sp, #4240]
	add	x5, sp, #1, lsl #12             ; =4096
	add	x5, x5, #128
	str	w4, [x5, x2]
	ldr	q11, [sp, #4240]
	ldr	q23, [sp, #4224]
	str	q24, [sp, #4192]
	str	q12, [sp, #4208]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #96
	ldr	w4, [x4, x2]
	mov	w5, #14                         ; =0xe
	csel	w4, w5, w4, ne
	str	q24, [sp, #4160]
	str	q12, [sp, #4176]
	add	x5, sp, #1, lsl #12             ; =4096
	add	x5, x5, #64
	str	w4, [x5, x2]
	mov	w2, #39                         ; =0x27
	mov	w4, #38                         ; =0x26
	ldr	q12, [sp, #4176]
	ldr	q24, [sp, #4160]
	b	LBB0_6
LBB0_761:                               ; %varying.coherent791
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w1, #0xff
	b.eq	LBB0_812
; %bb.762:                              ; %varying.coherent.true796
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
	tst	w2, #0xff
	b.eq	LBB0_1063
LBB0_763:                               ; %schedule.38
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v7, v31
	mov.16b	v6, v22
	str	q13, [sp, #1456]                ; 16-byte Folded Spill
	str	q0, [sp, #1488]                 ; 16-byte Folded Spill
	str	q24, [sp, #1376]                ; 16-byte Folded Spill
	str	q12, [sp, #1536]                ; 16-byte Folded Spill
	str	q23, [sp, #1392]                ; 16-byte Folded Spill
	str	q11, [sp, #1568]                ; 16-byte Folded Spill
	mov.16b	v8, v25
	str	q9, [sp, #1504]                 ; 16-byte Folded Spill
	str	q14, [sp, #1440]                ; 16-byte Folded Spill
	ldr	q0, [sp, #1328]                 ; 16-byte Folded Reload
	mov	b3, v20[0]
	mov.b	v3[4], v20[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q1, [sp, #1520]                 ; 16-byte Folded Reload
	mov.16b	v9, v29
	and.16b	v16, v3, v29
	mov	b4, v20[2]
	mov.b	v4[4], v20[3]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	and.16b	v17, v4, v0
	mov	b5, v20[4]
	mov.b	v5[4], v20[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v27, v5, #0
	and.16b	v18, v27, v1
	mov	b5, v20[6]
	mov.b	v5[4], v20[7]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v30, v5, #0
	ldr	q5, [sp, #1280]                 ; 16-byte Folded Reload
	and.16b	v19, v30, v5
	shl.8b	v5, v20, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	mov	w2, #32                         ; =0x20
	dup.2d	v31, x2
	and.16b	v21, v3, v31
	mvn.16b	v3, v3
	sub.2d	v21, v21, v3
	and.16b	v3, v4, v31
	mvn.16b	v4, v4
	sub.2d	v26, v3, v4
	and.16b	v3, v27, v31
	mvn.16b	v4, v27
	and.16b	v27, v30, v31
	mvn.16b	v30, v30
	sub.2d	v27, v27, v30
	mov.d	x2, v27[1]
	mov.d	x3, v19[1]
	sdiv	x3, x3, x2
	sub.2d	v3, v3, v4
	fmov	x4, d27
	fmov	x5, d19
	sdiv	x5, x5, x4
	mul	x4, x5, x4
	fmov	d4, x5
	mov.d	v4[1], x3
	mov.d	x5, v3[1]
	mov.d	x6, v18[1]
	sdiv	x6, x6, x5
	fmov	x7, d3
	fmov	x19, d18
	sdiv	x19, x19, x7
	mul	x7, x19, x7
	fmov	d3, x19
	mov.d	v3[1], x6
	mov.d	x19, v26[1]
	mov.d	x20, v17[1]
	sdiv	x20, x20, x19
	fmov	x21, d26
	fmov	x22, d17
	sdiv	x22, x22, x21
	mul	x21, x22, x21
	fmov	d26, x22
	mov.d	v26[1], x20
	mov.d	x22, v21[1]
	mov.d	x23, v16[1]
	fmov	x24, d21
	fmov	x25, d16
	sdiv	x25, x25, x24
	mul	x24, x25, x24
	fmov	d21, x25
	sdiv	x23, x23, x22
	mov.d	v21[1], x23
	mul	x22, x23, x22
	fmov	d27, x24
	mov.d	v27[1], x22
	mul	x19, x20, x19
	fmov	d30, x21
	mov.d	v30[1], x19
	mul	x5, x6, x5
	fmov	d31, x7
	mov.d	v31[1], x5
	mul	x2, x3, x2
	fmov	d10, x4
	mov.d	v10[1], x2
	addv.8b	b5, v5
	sub.2d	v19, v19, v10
	sub.2d	v18, v18, v31
	fmov	w2, s5
	sub.2d	v17, v17, v30
	sub.2d	v16, v16, v27
	ldr	q27, [sp, #17664]
	ldr	q30, [sp, #17680]
	ldr	q31, [sp, #17696]
	ldr	q11, [sp, #17712]
	ldr	q12, [sp, #17776]
	ldr	q13, [sp, #17760]
	ldr	q14, [sp, #17744]
	shl.2d	v21, v21, #10
	shl.2d	v26, v26, #10
	shl.2d	v3, v3, #10
	shl.2d	v4, v4, #10
	shl.2d	v10, v16, #5
	shl.2d	v15, v17, #5
	shl.2d	v17, v18, #5
	shl.2d	v16, v19, #5
	add.2d	v16, v4, v16
	add.2d	v17, v3, v17
	ldr	q3, [sp, #17728]
	add.2d	v18, v26, v15
	add.2d	v10, v21, v10
	add.2d	v4, v11, v12
	add.2d	v19, v4, v16
	add.2d	v4, v31, v13
	add.2d	v11, v4, v17
	add.2d	v4, v30, v14
	add.2d	v26, v4, v18
	add.2d	v3, v27, v3
	add.2d	v27, v3, v10
	movi.2d	v21, #0000000000000000
	movi.2d	v30, #0000000000000000
	tbz	w2, #0, LBB0_767
; %bb.764:                              ; %cond.load5039
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d27
	ldr	s21, [x3]
	tbnz	w2, #1, LBB0_768
LBB0_765:                               ; %else5049
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v25, v8
	tbz	w2, #2, LBB0_769
LBB0_766:                               ; %cond.load5051
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d26
	ld1.s	{ v21 }[2], [x3]
	ldr	q1, [sp, #1424]                 ; 16-byte Folded Reload
	ldr	q23, [sp, #1392]                ; 16-byte Folded Reload
	mov.16b	v29, v9
	tbnz	w2, #3, LBB0_770
	b	LBB0_771
LBB0_767:                               ; %else5043
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #1, LBB0_765
LBB0_768:                               ; %cond.load5045
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v27[1]
	ld1.s	{ v21 }[1], [x3]
	mov.16b	v25, v8
	tbnz	w2, #2, LBB0_766
LBB0_769:                               ; %else5055
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q1, [sp, #1424]                 ; 16-byte Folded Reload
	ldr	q23, [sp, #1392]                ; 16-byte Folded Reload
	mov.16b	v29, v9
	tbz	w2, #3, LBB0_771
LBB0_770:                               ; %cond.load5057
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v26[1]
	ld1.s	{ v21 }[3], [x3]
LBB0_771:                               ; %else5061
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q9, [sp, #1504]                 ; 16-byte Folded Reload
	ldr	q24, [sp, #1376]                ; 16-byte Folded Reload
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	ldr	q13, [sp, #1456]                ; 16-byte Folded Reload
	mov.16b	v22, v6
	ldr	q14, [sp, #1440]                ; 16-byte Folded Reload
	tbz	w2, #4, LBB0_775
; %bb.772:                              ; %cond.load5063
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d11
	ld1.s	{ v30 }[0], [x3]
	tbnz	w2, #5, LBB0_776
LBB0_773:                               ; %else5073
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #6, LBB0_777
LBB0_774:                               ; %cond.load5075
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d19
	ld1.s	{ v30 }[2], [x3]
	str	q1, [sp, #1424]                 ; 16-byte Folded Spill
	tbnz	w2, #7, LBB0_778
	b	LBB0_779
LBB0_775:                               ; %else5067
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #5, LBB0_773
LBB0_776:                               ; %cond.load5069
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v11[1]
	ld1.s	{ v30 }[1], [x3]
	tbnz	w2, #6, LBB0_774
LBB0_777:                               ; %else5079
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q1, [sp, #1424]                 ; 16-byte Folded Spill
	tbz	w2, #7, LBB0_779
LBB0_778:                               ; %cond.load5081
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v19[1]
	ld1.s	{ v30 }[3], [x2]
LBB0_779:                               ; %else5085
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q3, [sp, #17456]
	ldr	q4, [sp, #17440]
	ldr	q19, [sp, #17424]
	ldr	q26, [sp, #17408]
	ldr	q27, [sp, #17472]
	ldr	q31, [sp, #17488]
	ldr	q11, [sp, #17504]
	ldr	q12, [sp, #17520]
	add.2d	v26, v26, v27
	add.2d	v27, v26, v10
	add.2d	v19, v19, v31
	add.2d	v26, v19, v18
	add.2d	v4, v4, v11
	add.2d	v19, v4, v17
	add.2d	v3, v3, v12
	add.2d	v18, v3, v16
	fmov	w2, s5
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbz	w2, #0, LBB0_787
; %bb.780:                              ; %cond.load5088
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d27
	ldr	s16, [x3]
	tbnz	w2, #1, LBB0_788
LBB0_781:                               ; %else5098
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #2, LBB0_789
LBB0_782:                               ; %cond.load5100
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d26
	ld1.s	{ v16 }[2], [x3]
	tbnz	w2, #3, LBB0_790
LBB0_783:                               ; %else5110
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #4, LBB0_791
LBB0_784:                               ; %cond.load5112
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d19
	ld1.s	{ v17 }[0], [x3]
	tbnz	w2, #5, LBB0_792
LBB0_785:                               ; %else5122
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #6, LBB0_793
LBB0_786:                               ; %cond.load5124
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d18
	ld1.s	{ v17 }[2], [x3]
	tbnz	w2, #7, LBB0_794
	b	LBB0_795
LBB0_787:                               ; %else5092
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #1, LBB0_781
LBB0_788:                               ; %cond.load5094
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v27[1]
	ld1.s	{ v16 }[1], [x3]
	tbnz	w2, #2, LBB0_782
LBB0_789:                               ; %else5104
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #3, LBB0_783
LBB0_790:                               ; %cond.load5106
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v26[1]
	ld1.s	{ v16 }[3], [x3]
	tbnz	w2, #4, LBB0_784
LBB0_791:                               ; %else5116
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #5, LBB0_785
LBB0_792:                               ; %cond.load5118
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v19[1]
	ld1.s	{ v17 }[1], [x3]
	tbnz	w2, #6, LBB0_786
LBB0_793:                               ; %else5128
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #7, LBB0_795
LBB0_794:                               ; %cond.load5130
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v18[1]
	ld1.s	{ v17 }[3], [x2]
LBB0_795:                               ; %else5134
                                        ;   in Loop: Header=BB0_8 Depth=3
	fadd.4s	v18, v21, v16
	fadd.4s	v16, v30, v17
	ldr	q3, [sp, #17200]
	ldr	q4, [sp, #17184]
	ldr	q17, [sp, #17168]
	ldr	q19, [sp, #17152]
	ldr	q21, [sp, #17216]
	ldr	q26, [sp, #17232]
	ldr	q27, [sp, #17248]
	ldr	q30, [sp, #17264]
	shl.2d	v31, v29, #5
	ldr	q1, [sp, #1328]                 ; 16-byte Folded Reload
	shl.2d	v10, v1, #5
	ldr	q1, [sp, #1520]                 ; 16-byte Folded Reload
	shl.2d	v11, v1, #5
	ldr	q1, [sp, #1280]                 ; 16-byte Folded Reload
	shl.2d	v12, v1, #5
	add.2d	v30, v30, v12
	add.2d	v27, v27, v11
	add.2d	v10, v26, v10
	add.2d	v21, v21, v31
	add.2d	v26, v19, v21
	add.2d	v21, v17, v10
	add.2d	v19, v4, v27
	add.2d	v17, v3, v30
	fmov	w2, s5
	tbz	w2, #0, LBB0_803
; %bb.796:                              ; %cond.store5137
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d26
	str	s18, [x3]
	ldr	q11, [sp, #1568]                ; 16-byte Folded Reload
	ldr	q12, [sp, #1536]                ; 16-byte Folded Reload
	mov.16b	v31, v7
	tbnz	w2, #1, LBB0_804
LBB0_797:                               ; %else5144
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #2, LBB0_805
LBB0_798:                               ; %cond.store5145
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d21
	st1.s	{ v18 }[2], [x3]
	tbnz	w2, #3, LBB0_806
LBB0_799:                               ; %else5152
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #4, LBB0_807
LBB0_800:                               ; %cond.store5153
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d19
	str	s16, [x3]
	tbnz	w2, #5, LBB0_808
LBB0_801:                               ; %else5160
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #6, LBB0_809
LBB0_802:                               ; %cond.store5161
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d17
	st1.s	{ v16 }[2], [x3]
	tbnz	w2, #7, LBB0_810
	b	LBB0_811
LBB0_803:                               ; %else5140
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q11, [sp, #1568]                ; 16-byte Folded Reload
	ldr	q12, [sp, #1536]                ; 16-byte Folded Reload
	mov.16b	v31, v7
	tbz	w2, #1, LBB0_797
LBB0_804:                               ; %cond.store5141
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v26[1]
	st1.s	{ v18 }[1], [x3]
	tbnz	w2, #2, LBB0_798
LBB0_805:                               ; %else5148
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #3, LBB0_799
LBB0_806:                               ; %cond.store5149
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v21[1]
	st1.s	{ v18 }[3], [x3]
	tbnz	w2, #4, LBB0_800
LBB0_807:                               ; %else5156
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #5, LBB0_801
LBB0_808:                               ; %cond.store5157
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v19[1]
	st1.s	{ v16 }[1], [x3]
	tbnz	w2, #6, LBB0_802
LBB0_809:                               ; %else5164
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #7, LBB0_811
LBB0_810:                               ; %cond.store5165
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v17[1]
	st1.s	{ v16 }[3], [x2]
LBB0_811:                               ; %else5168
                                        ;   in Loop: Header=BB0_8 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v20, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v4, v3, #0
	ushll2.4s	v3, v3, #0
	ldr	q1, [sp, #1280]                 ; 16-byte Folded Reload
	uaddw2.2d	v1, v1, v3
	str	q1, [sp, #1280]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #1520]                 ; 16-byte Folded Reload
	uaddw.2d	v1, v1, v3
	str	q1, [sp, #1520]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #1328]                 ; 16-byte Folded Reload
	uaddw2.2d	v1, v1, v4
	str	q1, [sp, #1328]                 ; 16-byte Folded Spill
	uaddw.2d	v29, v29, v4
	tbz	w1, #0, LBB0_755
	b	LBB0_1063
LBB0_812:                               ; %varying.coherent.false797
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1063
LBB0_813:                               ; %schedule.39
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q31, [sp, #1456]                ; 16-byte Folded Spill
	ldr	q6, [sp, #1552]                 ; 16-byte Folded Reload
	str	q28, [sp, #1408]                ; 16-byte Folded Spill
	str	q25, [sp, #1168]                ; 16-byte Folded Spill
	str	q11, [sp, #1568]                ; 16-byte Folded Spill
	str	q23, [sp, #1392]                ; 16-byte Folded Spill
	str	q12, [sp, #1536]                ; 16-byte Folded Spill
	str	q24, [sp, #1376]                ; 16-byte Folded Spill
	str	q6, [sp, #1552]                 ; 16-byte Folded Spill
	cbz	w0, LBB0_818
; %bb.814:                              ; %convergence.cascade805.preheader
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
LBB0_815:                               ; %convergence.cascade805
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_3 Depth=2
                                        ;       Parent Loop BB0_8 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w2, s4
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	str	q24, [sp, #7584]
	str	q12, [sp, #7600]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #1, lsl #12             ; =4096
	add	x6, x6, #3488
	ldr	w6, [x6, x2]
	cmp	w6, #14
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #1520
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s5, w19
	ubfx	w19, w20, #1, #1
	mov.b	v5[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v5[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v5[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v5[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v5[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v5[6], w19
	add	x19, sp, #18, lsl #12           ; =73728
	add	x19, x19, #1512
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s3, w21
	ubfx	w21, w20, #1, #1
	mov.b	v3[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v3[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v3[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v3[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v3[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v3[6], w21
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	orr.8b	v4, v20, v3
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	and.8b	v7, v1, v5
	eor.8b	v7, v7, v4
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v4, v7
	dup.8b	v17, w7
	bit.8b	v3, v16, v17
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x19, w3, sxtw]
	bic.8b	v3, v5, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v4, v5, v4
	str	q23, [sp, #7552]
	str	q11, [sp, #7568]
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #3456
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v20, v4, v3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_819
; %bb.816:                              ; %convergence.cascade805
                                        ;   in Loop: Header=BB0_815 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_819
; %bb.817:                              ; %convergence.cascade805
                                        ;   in Loop: Header=BB0_815 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_815
	b	LBB0_819
LBB0_818:                               ; %schedule.39.convergence.cascade.exit806_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_819:                               ; %convergence.cascade.exit806
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1047
; %bb.820:                              ; %convergence.target.39.ready
                                        ;   in Loop: Header=BB0_8 Depth=3
	rbit	w1, w2
	clz	w1, w1
	ldr	q16, [sp, #17120]
	ldr	q3, [sp, #17136]
	ldr	q4, [sp, #17088]
	ldr	q7, [sp, #17104]
	ldr	q17, [sp, #17056]
	ldr	q18, [sp, #17072]
	ldr	q5, [sp, #17024]
	ldr	q19, [sp, #17040]
	mov	b21, v20[2]
	mov.b	v21[4], v20[3]
	ushll.2d	v21, v21, #0
	shl.2d	v21, v21, #63
	cmlt.2d	v21, v21, #0
	ldr	q31, [sp, #144]                 ; 16-byte Folded Reload
	mov.16b	v15, v21
	bsl.16b	v15, v31, v19
	mov	b26, v20[0]
	mov.b	v26[4], v20[1]
	ushll.2d	v26, v26, #0
	shl.2d	v26, v26, #63
	cmlt.2d	v30, v26, #0
	mov.16b	v26, v30
	bsl.16b	v26, v31, v5
	mov	b5, v20[6]
	mov.b	v5[4], v20[7]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	mov	b27, v20[4]
	mov.b	v27[4], v20[5]
	mov.16b	v1, v5
	bsl.16b	v1, v31, v18
	str	q1, [sp, #1504]                 ; 16-byte Folded Spill
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v10, v27, #0
	mov.16b	v1, v10
	bsl.16b	v1, v31, v17
	str	q1, [sp, #1488]                 ; 16-byte Folded Spill
Lloh1130:
	adrp	x2, lCPI0_20@PAGE
Lloh1131:
	ldr	q27, [x2, lCPI0_20@PAGEOFF]
	mov.16b	v25, v21
	bsl.16b	v25, v27, v7
Lloh1132:
	adrp	x2, lCPI0_21@PAGE
Lloh1133:
	ldr	q31, [x2, lCPI0_21@PAGEOFF]
	mov.16b	v6, v30
	bsl.16b	v6, v31, v4
Lloh1134:
	adrp	x2, lCPI0_22@PAGE
Lloh1135:
	ldr	q8, [x2, lCPI0_22@PAGEOFF]
	bit.16b	v3, v8, v5
Lloh1136:
	adrp	x2, lCPI0_23@PAGE
	mov.16b	v17, v0
	mov.16b	v2, v9
Lloh1137:
	ldr	q9, [x2, lCPI0_23@PAGEOFF]
	bit.16b	v16, v9, v10
	str	q16, [sp, #17120]
	str	q3, [sp, #17136]
	str	q6, [sp, #17088]
	str	q25, [sp, #17104]
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	str	q0, [sp, #17056]
	ldr	q0, [sp, #1504]                 ; 16-byte Folded Reload
	str	q0, [sp, #17072]
	str	q26, [sp, #17024]
	str	q15, [sp, #17040]
	str	q8, [sp, #5552]
	str	q9, [sp, #5536]
	mov.16b	v9, v2
	ldr	q23, [sp, #1392]                ; 16-byte Folded Reload
	ldr	q24, [sp, #1376]                ; 16-byte Folded Reload
	ldr	q25, [sp, #1168]                ; 16-byte Folded Reload
	ldr	q12, [sp, #1536]                ; 16-byte Folded Reload
	ldr	q1, [sp, #1264]                 ; 16-byte Folded Reload
	ldr	q11, [sp, #1568]                ; 16-byte Folded Reload
	mov.16b	v0, v17
	ldr	q28, [sp, #1408]                ; 16-byte Folded Reload
	ldr	d2, [sp, #696]                  ; 8-byte Folded Reload
	str	q27, [sp, #5520]
	str	q31, [sp, #5504]
	lsl	w2, w1, #3
	and	x1, x2, #0x38
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #1408
	ldr	x4, [x3, x1]
	and	x2, x2, #0xf8
	add	x3, sp, #6, lsl #12             ; =24576
	add	x3, x3, #3432
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4, #32]
	ldp	q7, q16, [x4]
	mov	x5, #-16                        ; =0xfffffffffffffff0
	dup.2d	v17, x5
	bit.16b	v16, v17, v21
	bit.16b	v7, v17, v30
	bit.16b	v4, v17, v5
	bit.16b	v3, v17, v10
	stp	q3, q4, [x4, #32]
	stp	q7, q16, [x4]
Lloh1138:
	adrp	x4, lCPI0_24@PAGE
Lloh1139:
	ldr	q3, [x4, lCPI0_24@PAGEOFF]
Lloh1140:
	adrp	x4, lCPI0_25@PAGE
Lloh1141:
	ldr	q4, [x4, lCPI0_25@PAGEOFF]
	str	q3, [sp, #5616]
	str	q4, [sp, #5600]
Lloh1142:
	adrp	x4, lCPI0_26@PAGE
Lloh1143:
	ldr	q3, [x4, lCPI0_26@PAGEOFF]
Lloh1144:
	adrp	x4, lCPI0_27@PAGE
Lloh1145:
	ldr	q4, [x4, lCPI0_27@PAGEOFF]
	str	q3, [sp, #5584]
	str	q4, [sp, #5568]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #1472
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	x5, #-15                        ; =0xfffffffffffffff1
	dup.2d	v17, x5
	bit.16b	v16, v17, v10
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v5
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1146:
	adrp	x4, lCPI0_28@PAGE
Lloh1147:
	ldr	q3, [x4, lCPI0_28@PAGEOFF]
Lloh1148:
	adrp	x4, lCPI0_29@PAGE
Lloh1149:
	ldr	q4, [x4, lCPI0_29@PAGEOFF]
	str	q3, [sp, #5680]
	str	q4, [sp, #5664]
Lloh1150:
	adrp	x4, lCPI0_30@PAGE
Lloh1151:
	ldr	q3, [x4, lCPI0_30@PAGEOFF]
Lloh1152:
	adrp	x4, lCPI0_31@PAGE
Lloh1153:
	ldr	q4, [x4, lCPI0_31@PAGEOFF]
	str	q3, [sp, #5648]
	str	q4, [sp, #5632]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #1536
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	x5, #-14                        ; =0xfffffffffffffff2
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v10
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v5
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh1154:
	adrp	x4, lCPI0_32@PAGE
Lloh1155:
	ldr	q3, [x4, lCPI0_32@PAGEOFF]
Lloh1156:
	adrp	x4, lCPI0_33@PAGE
Lloh1157:
	ldr	q4, [x4, lCPI0_33@PAGEOFF]
	str	q3, [sp, #5744]
	str	q4, [sp, #5728]
Lloh1158:
	adrp	x4, lCPI0_34@PAGE
Lloh1159:
	ldr	q3, [x4, lCPI0_34@PAGEOFF]
Lloh1160:
	adrp	x4, lCPI0_35@PAGE
Lloh1161:
	ldr	q4, [x4, lCPI0_35@PAGEOFF]
	str	q3, [sp, #5712]
	str	q4, [sp, #5696]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #1600
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	x5, #-13                        ; =0xfffffffffffffff3
	dup.2d	v17, x5
	bit.16b	v16, v17, v10
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v5
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1162:
	adrp	x4, lCPI0_36@PAGE
Lloh1163:
	ldr	q3, [x4, lCPI0_36@PAGEOFF]
Lloh1164:
	adrp	x4, lCPI0_37@PAGE
Lloh1165:
	ldr	q4, [x4, lCPI0_37@PAGEOFF]
	str	q3, [sp, #5808]
	str	q4, [sp, #5792]
Lloh1166:
	adrp	x4, lCPI0_38@PAGE
Lloh1167:
	ldr	q3, [x4, lCPI0_38@PAGEOFF]
Lloh1168:
	adrp	x4, lCPI0_39@PAGE
Lloh1169:
	ldr	q4, [x4, lCPI0_39@PAGEOFF]
	str	q3, [sp, #5776]
	str	q4, [sp, #5760]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #1664
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	x5, #-12                        ; =0xfffffffffffffff4
	dup.2d	v17, x5
	bit.16b	v16, v17, v10
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v5
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1170:
	adrp	x4, lCPI0_40@PAGE
Lloh1171:
	ldr	q3, [x4, lCPI0_40@PAGEOFF]
Lloh1172:
	adrp	x4, lCPI0_41@PAGE
Lloh1173:
	ldr	q4, [x4, lCPI0_41@PAGEOFF]
	str	q3, [sp, #5872]
	str	q4, [sp, #5856]
Lloh1174:
	adrp	x4, lCPI0_42@PAGE
Lloh1175:
	ldr	q3, [x4, lCPI0_42@PAGEOFF]
Lloh1176:
	adrp	x4, lCPI0_43@PAGE
Lloh1177:
	ldr	q4, [x4, lCPI0_43@PAGEOFF]
	str	q3, [sp, #5840]
	str	q4, [sp, #5824]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #1728
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	x5, #-11                        ; =0xfffffffffffffff5
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v10
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v5
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh1178:
	adrp	x4, lCPI0_44@PAGE
Lloh1179:
	ldr	q3, [x4, lCPI0_44@PAGEOFF]
Lloh1180:
	adrp	x4, lCPI0_45@PAGE
Lloh1181:
	ldr	q4, [x4, lCPI0_45@PAGEOFF]
	str	q3, [sp, #5936]
	str	q4, [sp, #5920]
Lloh1182:
	adrp	x4, lCPI0_46@PAGE
Lloh1183:
	ldr	q3, [x4, lCPI0_46@PAGEOFF]
Lloh1184:
	adrp	x4, lCPI0_47@PAGE
Lloh1185:
	ldr	q4, [x4, lCPI0_47@PAGEOFF]
	str	q3, [sp, #5904]
	str	q4, [sp, #5888]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #1792
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	x5, #-10                        ; =0xfffffffffffffff6
	dup.2d	v17, x5
	bit.16b	v16, v17, v10
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v5
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1186:
	adrp	x4, lCPI0_48@PAGE
Lloh1187:
	ldr	q3, [x4, lCPI0_48@PAGEOFF]
Lloh1188:
	adrp	x4, lCPI0_49@PAGE
Lloh1189:
	ldr	q4, [x4, lCPI0_49@PAGEOFF]
	str	q3, [sp, #6000]
	str	q4, [sp, #5984]
Lloh1190:
	adrp	x4, lCPI0_50@PAGE
Lloh1191:
	ldr	q3, [x4, lCPI0_50@PAGEOFF]
Lloh1192:
	adrp	x4, lCPI0_51@PAGE
Lloh1193:
	ldr	q4, [x4, lCPI0_51@PAGEOFF]
	str	q3, [sp, #5968]
	str	q4, [sp, #5952]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #1856
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	x5, #-9                         ; =0xfffffffffffffff7
	dup.2d	v17, x5
	bit.16b	v16, v17, v10
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v5
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1194:
	adrp	x4, lCPI0_52@PAGE
Lloh1195:
	ldr	q3, [x4, lCPI0_52@PAGEOFF]
Lloh1196:
	adrp	x4, lCPI0_53@PAGE
Lloh1197:
	ldr	q4, [x4, lCPI0_53@PAGEOFF]
	str	q3, [sp, #6064]
	str	q4, [sp, #6048]
Lloh1198:
	adrp	x4, lCPI0_54@PAGE
Lloh1199:
	ldr	q3, [x4, lCPI0_54@PAGEOFF]
Lloh1200:
	adrp	x4, lCPI0_55@PAGE
Lloh1201:
	ldr	q4, [x4, lCPI0_55@PAGEOFF]
	str	q3, [sp, #6032]
	str	q4, [sp, #6016]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #1920
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	x5, #-8                         ; =0xfffffffffffffff8
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v10
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v5
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh1202:
	adrp	x4, lCPI0_56@PAGE
Lloh1203:
	ldr	q3, [x4, lCPI0_56@PAGEOFF]
Lloh1204:
	adrp	x4, lCPI0_57@PAGE
Lloh1205:
	ldr	q4, [x4, lCPI0_57@PAGEOFF]
	str	q3, [sp, #6128]
	str	q4, [sp, #6112]
Lloh1206:
	adrp	x4, lCPI0_58@PAGE
Lloh1207:
	ldr	q3, [x4, lCPI0_58@PAGEOFF]
Lloh1208:
	adrp	x4, lCPI0_59@PAGE
Lloh1209:
	ldr	q4, [x4, lCPI0_59@PAGEOFF]
	str	q3, [sp, #6096]
	str	q4, [sp, #6080]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #1984
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	x5, #-7                         ; =0xfffffffffffffff9
	dup.2d	v17, x5
	bit.16b	v16, v17, v10
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v5
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1210:
	adrp	x4, lCPI0_60@PAGE
Lloh1211:
	ldr	q3, [x4, lCPI0_60@PAGEOFF]
Lloh1212:
	adrp	x4, lCPI0_61@PAGE
Lloh1213:
	ldr	q4, [x4, lCPI0_61@PAGEOFF]
	str	q3, [sp, #6192]
	str	q4, [sp, #6176]
Lloh1214:
	adrp	x4, lCPI0_62@PAGE
Lloh1215:
	ldr	q3, [x4, lCPI0_62@PAGEOFF]
Lloh1216:
	adrp	x4, lCPI0_63@PAGE
Lloh1217:
	ldr	q4, [x4, lCPI0_63@PAGEOFF]
	str	q3, [sp, #6160]
	str	q4, [sp, #6144]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #2048
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	x5, #-6                         ; =0xfffffffffffffffa
	dup.2d	v17, x5
	bit.16b	v16, v17, v10
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v5
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1218:
	adrp	x4, lCPI0_64@PAGE
Lloh1219:
	ldr	q3, [x4, lCPI0_64@PAGEOFF]
Lloh1220:
	adrp	x4, lCPI0_65@PAGE
Lloh1221:
	ldr	q4, [x4, lCPI0_65@PAGEOFF]
	str	q3, [sp, #6256]
	str	q4, [sp, #6240]
Lloh1222:
	adrp	x4, lCPI0_66@PAGE
Lloh1223:
	ldr	q3, [x4, lCPI0_66@PAGEOFF]
Lloh1224:
	adrp	x4, lCPI0_67@PAGE
Lloh1225:
	ldr	q4, [x4, lCPI0_67@PAGEOFF]
	str	q3, [sp, #6224]
	str	q4, [sp, #6208]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #2112
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	x5, #-5                         ; =0xfffffffffffffffb
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v10
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v5
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh1226:
	adrp	x4, lCPI0_68@PAGE
Lloh1227:
	ldr	q3, [x4, lCPI0_68@PAGEOFF]
Lloh1228:
	adrp	x4, lCPI0_69@PAGE
Lloh1229:
	ldr	q4, [x4, lCPI0_69@PAGEOFF]
	str	q3, [sp, #6320]
	str	q4, [sp, #6304]
Lloh1230:
	adrp	x4, lCPI0_70@PAGE
Lloh1231:
	ldr	q3, [x4, lCPI0_70@PAGEOFF]
Lloh1232:
	adrp	x4, lCPI0_71@PAGE
Lloh1233:
	ldr	q4, [x4, lCPI0_71@PAGEOFF]
	str	q3, [sp, #6288]
	str	q4, [sp, #6272]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #2176
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	x5, #-4                         ; =0xfffffffffffffffc
	dup.2d	v17, x5
	bit.16b	v16, v17, v10
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v5
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1234:
	adrp	x4, lCPI0_72@PAGE
Lloh1235:
	ldr	q3, [x4, lCPI0_72@PAGEOFF]
Lloh1236:
	adrp	x4, lCPI0_73@PAGE
Lloh1237:
	ldr	q4, [x4, lCPI0_73@PAGEOFF]
	str	q3, [sp, #6384]
	str	q4, [sp, #6368]
Lloh1238:
	adrp	x4, lCPI0_74@PAGE
Lloh1239:
	ldr	q3, [x4, lCPI0_74@PAGEOFF]
Lloh1240:
	adrp	x4, lCPI0_75@PAGE
Lloh1241:
	ldr	q4, [x4, lCPI0_75@PAGEOFF]
	str	q3, [sp, #6352]
	str	q4, [sp, #6336]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #2240
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	x5, #-3                         ; =0xfffffffffffffffd
	dup.2d	v17, x5
	bit.16b	v16, v17, v10
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v5
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1242:
	adrp	x4, lCPI0_76@PAGE
Lloh1243:
	ldr	q3, [x4, lCPI0_76@PAGEOFF]
Lloh1244:
	adrp	x4, lCPI0_77@PAGE
Lloh1245:
	ldr	q4, [x4, lCPI0_77@PAGEOFF]
	str	q3, [sp, #6448]
	str	q4, [sp, #6432]
Lloh1246:
	adrp	x4, lCPI0_78@PAGE
Lloh1247:
	ldr	q3, [x4, lCPI0_78@PAGEOFF]
Lloh1248:
	adrp	x4, lCPI0_79@PAGE
Lloh1249:
	ldr	q4, [x4, lCPI0_79@PAGEOFF]
	str	q3, [sp, #6416]
	str	q4, [sp, #6400]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #2304
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	x5, #-2                         ; =0xfffffffffffffffe
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v10
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v5
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh1250:
	adrp	x4, lCPI0_80@PAGE
Lloh1251:
	ldr	q3, [x4, lCPI0_80@PAGEOFF]
Lloh1252:
	adrp	x4, lCPI0_81@PAGE
Lloh1253:
	ldr	q4, [x4, lCPI0_81@PAGEOFF]
	str	q3, [sp, #6512]
	str	q4, [sp, #6496]
Lloh1254:
	adrp	x4, lCPI0_82@PAGE
Lloh1255:
	ldr	q3, [x4, lCPI0_82@PAGEOFF]
Lloh1256:
	adrp	x4, lCPI0_83@PAGE
Lloh1257:
	ldr	q4, [x4, lCPI0_83@PAGEOFF]
	str	q3, [sp, #6480]
	str	q4, [sp, #6464]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #2368
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	orr.16b	v16, v10, v16
	orr.16b	v4, v21, v4
	orr.16b	v3, v30, v3
	orr.16b	v7, v5, v7
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1258:
	adrp	x4, lCPI0_84@PAGE
Lloh1259:
	ldr	q3, [x4, lCPI0_84@PAGEOFF]
Lloh1260:
	adrp	x4, lCPI0_85@PAGE
Lloh1261:
	ldr	q4, [x4, lCPI0_85@PAGEOFF]
	str	q3, [sp, #6576]
	str	q4, [sp, #6560]
Lloh1262:
	adrp	x4, lCPI0_86@PAGE
Lloh1263:
	ldr	q3, [x4, lCPI0_86@PAGEOFF]
Lloh1264:
	adrp	x4, lCPI0_87@PAGE
Lloh1265:
	ldr	q4, [x4, lCPI0_87@PAGEOFF]
	str	q3, [sp, #6544]
	str	q4, [sp, #6528]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #2432
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	bic.16b	v16, v16, v10
	bic.16b	v4, v4, v21
	bic.16b	v3, v3, v30
	bic.16b	v7, v7, v5
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1266:
	adrp	x4, lCPI0_88@PAGE
Lloh1267:
	ldr	q3, [x4, lCPI0_88@PAGEOFF]
Lloh1268:
	adrp	x4, lCPI0_89@PAGE
Lloh1269:
	ldr	q4, [x4, lCPI0_89@PAGEOFF]
	str	q3, [sp, #6640]
	str	q4, [sp, #6624]
Lloh1270:
	adrp	x4, lCPI0_90@PAGE
Lloh1271:
	ldr	q3, [x4, lCPI0_90@PAGEOFF]
Lloh1272:
	adrp	x4, lCPI0_91@PAGE
Lloh1273:
	ldr	q4, [x4, lCPI0_91@PAGEOFF]
	str	q3, [sp, #6608]
	str	q4, [sp, #6592]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #2496
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	bic.16b	v16, v16, v10
	sub.2d	v16, v16, v10
	bic.16b	v4, v4, v21
	sub.2d	v4, v4, v21
	bic.16b	v3, v3, v30
	sub.2d	v3, v3, v30
	bic.16b	v7, v7, v5
	sub.2d	v7, v7, v5
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1274:
	adrp	x4, lCPI0_92@PAGE
Lloh1275:
	ldr	q3, [x4, lCPI0_92@PAGEOFF]
Lloh1276:
	adrp	x4, lCPI0_93@PAGE
Lloh1277:
	ldr	q4, [x4, lCPI0_93@PAGEOFF]
	str	q3, [sp, #6704]
	str	q4, [sp, #6688]
Lloh1278:
	adrp	x4, lCPI0_94@PAGE
Lloh1279:
	ldr	q3, [x4, lCPI0_94@PAGEOFF]
Lloh1280:
	adrp	x4, lCPI0_95@PAGE
Lloh1281:
	ldr	q4, [x4, lCPI0_95@PAGEOFF]
	str	q3, [sp, #6672]
	str	q4, [sp, #6656]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #2560
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #2                          ; =0x2
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v10
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v5
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh1282:
	adrp	x4, lCPI0_96@PAGE
Lloh1283:
	ldr	q3, [x4, lCPI0_96@PAGEOFF]
Lloh1284:
	adrp	x4, lCPI0_97@PAGE
Lloh1285:
	ldr	q4, [x4, lCPI0_97@PAGEOFF]
	str	q3, [sp, #6768]
	str	q4, [sp, #6752]
Lloh1286:
	adrp	x4, lCPI0_98@PAGE
Lloh1287:
	ldr	q3, [x4, lCPI0_98@PAGEOFF]
Lloh1288:
	adrp	x4, lCPI0_99@PAGE
Lloh1289:
	ldr	q4, [x4, lCPI0_99@PAGEOFF]
	str	q3, [sp, #6736]
	str	q4, [sp, #6720]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #2624
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #3                          ; =0x3
	dup.2d	v17, x5
	bit.16b	v16, v17, v10
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v5
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1290:
	adrp	x4, lCPI0_100@PAGE
Lloh1291:
	ldr	q3, [x4, lCPI0_100@PAGEOFF]
Lloh1292:
	adrp	x4, lCPI0_101@PAGE
Lloh1293:
	ldr	q4, [x4, lCPI0_101@PAGEOFF]
	str	q3, [sp, #6832]
	str	q4, [sp, #6816]
Lloh1294:
	adrp	x4, lCPI0_102@PAGE
Lloh1295:
	ldr	q3, [x4, lCPI0_102@PAGEOFF]
Lloh1296:
	adrp	x4, lCPI0_103@PAGE
Lloh1297:
	ldr	q4, [x4, lCPI0_103@PAGEOFF]
	str	q3, [sp, #6800]
	str	q4, [sp, #6784]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #2688
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #4                          ; =0x4
	dup.2d	v17, x5
	bit.16b	v16, v17, v10
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v5
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1298:
	adrp	x4, lCPI0_104@PAGE
Lloh1299:
	ldr	q3, [x4, lCPI0_104@PAGEOFF]
Lloh1300:
	adrp	x4, lCPI0_105@PAGE
Lloh1301:
	ldr	q4, [x4, lCPI0_105@PAGEOFF]
	str	q3, [sp, #6896]
	str	q4, [sp, #6880]
Lloh1302:
	adrp	x4, lCPI0_106@PAGE
Lloh1303:
	ldr	q3, [x4, lCPI0_106@PAGEOFF]
Lloh1304:
	adrp	x4, lCPI0_107@PAGE
Lloh1305:
	ldr	q4, [x4, lCPI0_107@PAGEOFF]
	str	q3, [sp, #6864]
	str	q4, [sp, #6848]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #2752
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #5                          ; =0x5
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v10
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v5
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh1306:
	adrp	x4, lCPI0_108@PAGE
Lloh1307:
	ldr	q3, [x4, lCPI0_108@PAGEOFF]
Lloh1308:
	adrp	x4, lCPI0_109@PAGE
Lloh1309:
	ldr	q4, [x4, lCPI0_109@PAGEOFF]
	str	q3, [sp, #6960]
	str	q4, [sp, #6944]
Lloh1310:
	adrp	x4, lCPI0_110@PAGE
Lloh1311:
	ldr	q3, [x4, lCPI0_110@PAGEOFF]
Lloh1312:
	adrp	x4, lCPI0_111@PAGE
Lloh1313:
	ldr	q4, [x4, lCPI0_111@PAGEOFF]
	str	q3, [sp, #6928]
	str	q4, [sp, #6912]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #2816
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #6                          ; =0x6
	dup.2d	v17, x5
	bit.16b	v16, v17, v10
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v5
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1314:
	adrp	x4, lCPI0_112@PAGE
Lloh1315:
	ldr	q3, [x4, lCPI0_112@PAGEOFF]
Lloh1316:
	adrp	x4, lCPI0_113@PAGE
Lloh1317:
	ldr	q4, [x4, lCPI0_113@PAGEOFF]
	str	q3, [sp, #7024]
	str	q4, [sp, #7008]
Lloh1318:
	adrp	x4, lCPI0_114@PAGE
Lloh1319:
	ldr	q3, [x4, lCPI0_114@PAGEOFF]
Lloh1320:
	adrp	x4, lCPI0_115@PAGE
Lloh1321:
	ldr	q4, [x4, lCPI0_115@PAGEOFF]
	str	q3, [sp, #6992]
	str	q4, [sp, #6976]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #2880
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #7                          ; =0x7
	dup.2d	v17, x5
	bit.16b	v16, v17, v10
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v5
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1322:
	adrp	x4, lCPI0_116@PAGE
Lloh1323:
	ldr	q3, [x4, lCPI0_116@PAGEOFF]
Lloh1324:
	adrp	x4, lCPI0_117@PAGE
Lloh1325:
	ldr	q4, [x4, lCPI0_117@PAGEOFF]
	str	q3, [sp, #7088]
	str	q4, [sp, #7072]
Lloh1326:
	adrp	x4, lCPI0_118@PAGE
Lloh1327:
	ldr	q3, [x4, lCPI0_118@PAGEOFF]
Lloh1328:
	adrp	x4, lCPI0_119@PAGE
Lloh1329:
	ldr	q4, [x4, lCPI0_119@PAGEOFF]
	str	q3, [sp, #7056]
	str	q4, [sp, #7040]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #2944
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #8                          ; =0x8
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v10
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v5
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh1330:
	adrp	x4, lCPI0_120@PAGE
Lloh1331:
	ldr	q3, [x4, lCPI0_120@PAGEOFF]
Lloh1332:
	adrp	x4, lCPI0_121@PAGE
Lloh1333:
	ldr	q4, [x4, lCPI0_121@PAGEOFF]
	str	q3, [sp, #7152]
	str	q4, [sp, #7136]
Lloh1334:
	adrp	x4, lCPI0_122@PAGE
Lloh1335:
	ldr	q3, [x4, lCPI0_122@PAGEOFF]
Lloh1336:
	adrp	x4, lCPI0_123@PAGE
Lloh1337:
	ldr	q4, [x4, lCPI0_123@PAGEOFF]
	str	q3, [sp, #7120]
	str	q4, [sp, #7104]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #3008
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #9                          ; =0x9
	dup.2d	v17, x5
	bit.16b	v16, v17, v10
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v5
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1338:
	adrp	x4, lCPI0_124@PAGE
Lloh1339:
	ldr	q3, [x4, lCPI0_124@PAGEOFF]
Lloh1340:
	adrp	x4, lCPI0_125@PAGE
Lloh1341:
	ldr	q4, [x4, lCPI0_125@PAGEOFF]
	str	q3, [sp, #7216]
	str	q4, [sp, #7200]
Lloh1342:
	adrp	x4, lCPI0_126@PAGE
Lloh1343:
	ldr	q3, [x4, lCPI0_126@PAGEOFF]
Lloh1344:
	adrp	x4, lCPI0_127@PAGE
Lloh1345:
	ldr	q4, [x4, lCPI0_127@PAGEOFF]
	str	q3, [sp, #7184]
	str	q4, [sp, #7168]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #3072
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #10                         ; =0xa
	dup.2d	v17, x5
	bit.16b	v16, v17, v10
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v5
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1346:
	adrp	x4, lCPI0_128@PAGE
Lloh1347:
	ldr	q3, [x4, lCPI0_128@PAGEOFF]
Lloh1348:
	adrp	x4, lCPI0_129@PAGE
Lloh1349:
	ldr	q4, [x4, lCPI0_129@PAGEOFF]
	str	q3, [sp, #7280]
	str	q4, [sp, #7264]
Lloh1350:
	adrp	x4, lCPI0_130@PAGE
Lloh1351:
	ldr	q3, [x4, lCPI0_130@PAGEOFF]
Lloh1352:
	adrp	x4, lCPI0_131@PAGE
Lloh1353:
	ldr	q4, [x4, lCPI0_131@PAGEOFF]
	str	q3, [sp, #7248]
	str	q4, [sp, #7232]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #3136
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #11                         ; =0xb
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v10
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v5
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh1354:
	adrp	x4, lCPI0_132@PAGE
Lloh1355:
	ldr	q3, [x4, lCPI0_132@PAGEOFF]
Lloh1356:
	adrp	x4, lCPI0_133@PAGE
Lloh1357:
	ldr	q4, [x4, lCPI0_133@PAGEOFF]
	str	q3, [sp, #7344]
	str	q4, [sp, #7328]
Lloh1358:
	adrp	x4, lCPI0_134@PAGE
Lloh1359:
	ldr	q3, [x4, lCPI0_134@PAGEOFF]
Lloh1360:
	adrp	x4, lCPI0_135@PAGE
Lloh1361:
	ldr	q4, [x4, lCPI0_135@PAGEOFF]
	str	q3, [sp, #7312]
	str	q4, [sp, #7296]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #3200
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #12                         ; =0xc
	dup.2d	v17, x5
	bit.16b	v16, v17, v10
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v5
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1362:
	adrp	x4, lCPI0_136@PAGE
Lloh1363:
	ldr	q3, [x4, lCPI0_136@PAGEOFF]
Lloh1364:
	adrp	x4, lCPI0_137@PAGE
Lloh1365:
	ldr	q4, [x4, lCPI0_137@PAGEOFF]
	str	q3, [sp, #7408]
	str	q4, [sp, #7392]
Lloh1366:
	adrp	x4, lCPI0_138@PAGE
Lloh1367:
	ldr	q3, [x4, lCPI0_138@PAGEOFF]
Lloh1368:
	adrp	x4, lCPI0_139@PAGE
Lloh1369:
	ldr	q4, [x4, lCPI0_139@PAGEOFF]
	str	q3, [sp, #7376]
	str	q4, [sp, #7360]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #3264
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	ldp	q16, q7, [x4, #32]
	mov	w5, #13                         ; =0xd
	dup.2d	v17, x5
	bit.16b	v16, v17, v10
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v5
	stp	q3, q4, [x4]
	stp	q16, q7, [x4, #32]
Lloh1370:
	adrp	x4, lCPI0_140@PAGE
Lloh1371:
	ldr	q3, [x4, lCPI0_140@PAGEOFF]
Lloh1372:
	adrp	x4, lCPI0_141@PAGE
Lloh1373:
	ldr	q4, [x4, lCPI0_141@PAGEOFF]
	str	q3, [sp, #7472]
	str	q4, [sp, #7456]
Lloh1374:
	adrp	x4, lCPI0_142@PAGE
Lloh1375:
	ldr	q3, [x4, lCPI0_142@PAGEOFF]
Lloh1376:
	adrp	x4, lCPI0_143@PAGE
Lloh1377:
	ldr	q4, [x4, lCPI0_143@PAGEOFF]
	str	q3, [sp, #7440]
	str	q4, [sp, #7424]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #3328
	ldr	x4, [x4, x1]
	sub	x4, x4, x2
	add	x4, x3, x4
	ldp	q3, q4, [x4]
	mov	w5, #14                         ; =0xe
	dup.2d	v7, x5
	ldp	q17, q16, [x4, #32]
	bit.16b	v17, v7, v10
	bit.16b	v4, v7, v21
	bit.16b	v3, v7, v30
	bif.16b	v7, v16, v5
	stp	q3, q4, [x4]
	stp	q17, q7, [x4, #32]
Lloh1378:
	adrp	x4, lCPI0_144@PAGE
Lloh1379:
	ldr	q3, [x4, lCPI0_144@PAGEOFF]
Lloh1380:
	adrp	x4, lCPI0_145@PAGE
Lloh1381:
	ldr	q4, [x4, lCPI0_145@PAGEOFF]
	str	q3, [sp, #7536]
	str	q4, [sp, #7520]
Lloh1382:
	adrp	x4, lCPI0_146@PAGE
Lloh1383:
	ldr	q3, [x4, lCPI0_146@PAGEOFF]
Lloh1384:
	adrp	x4, lCPI0_147@PAGE
Lloh1385:
	ldr	q4, [x4, lCPI0_147@PAGEOFF]
	str	q3, [sp, #7504]
	str	q4, [sp, #7488]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #3392
	ldr	x1, [x4, x1]
	sub	x1, x1, x2
	add	x1, x3, x1
	ldp	q3, q4, [x1]
	ldp	q16, q7, [x1, #32]
	mov	w2, #15                         ; =0xf
	dup.2d	v17, x2
	bit.16b	v16, v17, v10
	bit.16b	v4, v17, v21
	bit.16b	v3, v17, v30
	bit.16b	v7, v17, v5
	stp	q3, q4, [x1]
	stp	q16, q7, [x1, #32]
	ldr	q3, [sp, #16992]
	ldr	q4, [sp, #17008]
	ldr	q7, [sp, #16960]
	ldr	q16, [sp, #16976]
	ldr	q17, [sp, #16928]
	ldr	q18, [sp, #16944]
	ldr	q19, [sp, #16896]
	ldr	q26, [sp, #16912]
	ldr	q27, [sp, #128]                 ; 16-byte Folded Reload
	bit.16b	v26, v27, v21
	bit.16b	v19, v27, v30
	bit.16b	v18, v27, v5
	bit.16b	v17, v27, v10
Lloh1386:
	adrp	x1, lCPI0_17@PAGE
Lloh1387:
	ldr	q27, [x1, lCPI0_17@PAGEOFF]
	bit.16b	v16, v27, v21
Lloh1388:
	adrp	x1, lCPI0_16@PAGE
Lloh1389:
	ldr	q27, [x1, lCPI0_16@PAGEOFF]
	bit.16b	v7, v27, v30
Lloh1390:
	adrp	x1, lCPI0_19@PAGE
Lloh1391:
	ldr	q27, [x1, lCPI0_19@PAGEOFF]
	bit.16b	v4, v27, v5
Lloh1392:
	adrp	x1, lCPI0_18@PAGE
Lloh1393:
	ldr	q27, [x1, lCPI0_18@PAGEOFF]
	bit.16b	v3, v27, v10
	str	q3, [sp, #16992]
	str	q4, [sp, #17008]
	str	q7, [sp, #16960]
	str	q16, [sp, #16976]
	str	q17, [sp, #16928]
	str	q18, [sp, #16944]
	str	q19, [sp, #16896]
	str	q26, [sp, #16912]
	bic.16b	v13, v13, v5
	ldr	q3, [sp, #928]                  ; 16-byte Folded Reload
	bic.16b	v3, v3, v10
	str	q3, [sp, #928]                  ; 16-byte Folded Spill
	ldr	q3, [sp, #1024]                 ; 16-byte Folded Reload
	bic.16b	v3, v3, v21
	str	q3, [sp, #1024]                 ; 16-byte Folded Spill
	bic.16b	v1, v1, v30
	str	q1, [sp, #1264]                 ; 16-byte Folded Spill
	ldr	q31, [sp, #1456]                ; 16-byte Folded Reload
LBB0_821:                               ; %schedule.40
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	mov	w1, #128                        ; =0x80
	dup.2d	v5, x1
	ldr	q7, [sp, #1024]                 ; 16-byte Folded Reload
	cmgt.2d	v3, v5, v7
	ldr	q1, [sp, #1264]                 ; 16-byte Folded Reload
	cmgt.2d	v4, v5, v1
	uzp1.4s	v3, v4, v3
	ldr	q6, [sp, #928]                  ; 16-byte Folded Reload
	cmgt.2d	v4, v5, v6
	cmgt.2d	v16, v5, v13
	uzp1.4s	v4, v4, v16
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v21, v20, v3
	shl.8b	v3, v21, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w1, s4
	umaxv.8b	b3, v3
	fmov	w3, s3
	tbz	w3, #0, LBB0_827
; %bb.822:                              ; %schedule.40
                                        ;   in Loop: Header=BB0_8 Depth=3
	cmge.2d	v3, v7, v5
	cmge.2d	v4, v1, v5
	uzp1.4s	v3, v4, v3
	cmge.2d	v4, v6, v5
	cmge.2d	v5, v13, v5
	uzp1.4s	v4, v4, v5
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v10, v20, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_827
; %bb.823:                              ; %varying.divergent887
                                        ;   in Loop: Header=BB0_8 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	str	q24, [sp, #4448]
	str	q12, [sp, #4464]
	and	x1, x1, #0x7
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #352
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #15, #0, ne
	cset	w1, ne
	cmp	w2, #255
	b.ne	LBB0_825
; %bb.824:                              ; %varying.divergent887
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbnz	w1, #0, LBB0_1086
LBB0_825:                               ; %convergence.overflow.resume890
                                        ;   in Loop: Header=BB0_8 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #18, lsl #12            ; =73728
	add	x2, x2, #1520
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s5, w4
	ubfx	w4, w5, #1, #1
	mov.b	v5[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v5[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v5[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v5[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v5[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v5[6], w4
	add	x4, sp, #18, lsl #12            ; =73728
	add	x4, x4, #1512
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v4, w5
	bit.8b	v5, v20, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x2, w3, uxtw]
	bic.8b	v3, v3, v4
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_1086
; %bb.826:                              ; %ready.overflow.resume892
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q23, [sp, #4416]
	str	q11, [sp, #4432]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #320
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q23, [sp, #4384]
	str	q11, [sp, #4400]
	add	x5, sp, #1, lsl #12             ; =4096
	add	x5, x5, #288
	str	w4, [x5, x2]
	ldr	q11, [sp, #4400]
	ldr	q23, [sp, #4384]
	str	q24, [sp, #4352]
	str	q12, [sp, #4368]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #256
	ldr	w4, [x4, x2]
	mov	w5, #15                         ; =0xf
	csel	w4, w5, w4, ne
	str	q24, [sp, #4320]
	str	q12, [sp, #4336]
	add	x5, sp, #1, lsl #12             ; =4096
	add	x5, x5, #224
	str	w4, [x5, x2]
	mov	w2, #44                         ; =0x2c
	mov	w4, #41                         ; =0x29
	ldr	q12, [sp, #4336]
	ldr	q24, [sp, #4320]
	b	LBB0_6
LBB0_827:                               ; %varying.coherent888
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w1, #0xff
	b.eq	LBB0_889
; %bb.828:                              ; %varying.coherent.true893
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
	tst	w2, #0xff
	b.eq	LBB0_1063
LBB0_829:                               ; %schedule.41
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v8, v31
	str	q29, [sp, #1472]                ; 16-byte Folded Spill
	str	q0, [sp, #1488]                 ; 16-byte Folded Spill
	mov.16b	v3, v22
	mov.16b	v22, v12
	str	q9, [sp, #1504]                 ; 16-byte Folded Spill
	mov.16b	v1, v11
	mov.16b	v6, v25
	str	q3, [sp, #1232]                 ; 16-byte Folded Spill
	str	q14, [sp, #1440]                ; 16-byte Folded Spill
	mov	b3, v20[0]
	mov.b	v3[4], v20[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q4, [sp, #1264]                 ; 16-byte Folded Reload
	and.16b	v16, v3, v4
	mov	b4, v20[2]
	mov.b	v4[4], v20[3]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	ldr	q5, [sp, #1024]                 ; 16-byte Folded Reload
	and.16b	v17, v4, v5
	mov	b5, v20[4]
	mov.b	v5[4], v20[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v27, v5, #0
	ldr	q5, [sp, #928]                  ; 16-byte Folded Reload
	and.16b	v18, v27, v5
	mov	b5, v20[6]
	mov.b	v5[4], v20[7]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v30, v5, #0
	mov.16b	v9, v13
	and.16b	v19, v30, v13
	shl.8b	v5, v20, #7
	cmlt.8b	v21, v5, #0
	and.8b	v5, v21, v2
	addv.8b	b5, v5
	fmov	w2, s5
	mov	w3, #32                         ; =0x20
	dup.2d	v31, x3
	and.16b	v26, v3, v31
	mvn.16b	v3, v3
	sub.2d	v26, v26, v3
	and.16b	v3, v4, v31
	mvn.16b	v4, v4
	sub.2d	v11, v3, v4
	and.16b	v3, v27, v31
	and.16b	v4, v30, v31
	mvn.16b	v30, v30
	sub.2d	v4, v4, v30
	mov.d	x3, v4[1]
	mov.d	x4, v19[1]
	sdiv	x4, x4, x3
	mvn.16b	v27, v27
	sub.2d	v3, v3, v27
	fmov	x5, d4
	fmov	x6, d19
	sdiv	x6, x6, x5
	mul	x5, x6, x5
	fmov	d30, x6
	mov.d	v30[1], x4
	mov.d	x6, v3[1]
	mov.d	x7, v18[1]
	sdiv	x7, x7, x6
	fmov	x19, d3
	fmov	x20, d18
	sdiv	x20, x20, x19
	mul	x19, x20, x19
	fmov	d10, x20
	mov.d	v10[1], x7
	mov.d	x20, v11[1]
	mov.d	x21, v17[1]
	sdiv	x21, x21, x20
	fmov	x22, d11
	fmov	x23, d17
	sdiv	x23, x23, x22
	mul	x22, x23, x22
	fmov	d11, x23
	mov.d	v11[1], x21
	mov.d	x23, v26[1]
	mov.d	x24, v16[1]
	fmov	x25, d26
	fmov	x26, d16
	sdiv	x26, x26, x25
	mul	x25, x26, x25
	fmov	d12, x26
	sdiv	x24, x24, x23
	mov.d	v12[1], x24
	mul	x3, x4, x3
	fmov	d3, x5
	mov.d	v3[1], x3
	mul	x3, x7, x6
	fmov	d4, x19
	mov.d	v4[1], x3
	mul	x3, x21, x20
	fmov	d26, x22
	mov.d	v26[1], x3
	mul	x3, x24, x23
	fmov	d27, x25
	mov.d	v27[1], x3
	sub.2d	v16, v16, v27
	sub.2d	v17, v17, v26
	sub.2d	v4, v18, v4
	sub.2d	v3, v19, v3
	ldr	q27, [sp, #17024]
	ldr	q26, [sp, #17040]
	ldr	q19, [sp, #17056]
	ldr	q18, [sp, #17072]
	ldr	q31, [sp, #17136]
	ldr	q13, [sp, #17120]
	ldr	q14, [sp, #17104]
	shl.2d	v3, v3, #6
	shl.2d	v4, v4, #6
	shl.2d	v17, v17, #6
	shl.2d	v16, v16, #6
	ldr	q15, [sp, #17088]
	add.2d	v18, v18, v31
	add.2d	v18, v18, v3
	add.2d	v3, v19, v13
	add.2d	v19, v3, v4
	add.2d	v3, v26, v14
	add.2d	v26, v3, v17
	add.2d	v3, v27, v15
	add.2d	v27, v3, v16
	movi.2d	v13, #0000000000000000
	movi.2d	v14, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbz	w2, #0, LBB0_837
; %bb.830:                              ; %cond.load5170
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d27
	ldr	d13, [x3]
	tbnz	w2, #1, LBB0_838
LBB0_831:                               ; %else5180
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v31, v8
	tbz	w2, #2, LBB0_839
LBB0_832:                               ; %cond.load5182
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d26
	ld1.d	{ v14 }[0], [x3]
	tbnz	w2, #3, LBB0_840
LBB0_833:                               ; %else5192
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #4, LBB0_841
LBB0_834:                               ; %cond.load5194
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d19
	ld1.d	{ v16 }[0], [x3]
	tbnz	w2, #5, LBB0_842
LBB0_835:                               ; %else5204
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #6, LBB0_843
LBB0_836:                               ; %cond.load5206
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d18
	ld1.d	{ v17 }[0], [x3]
	tbnz	w2, #7, LBB0_844
	b	LBB0_845
LBB0_837:                               ; %else5174
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #1, LBB0_831
LBB0_838:                               ; %cond.load5176
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v27[1]
	ld1.d	{ v13 }[1], [x3]
	mov.16b	v31, v8
	tbnz	w2, #2, LBB0_832
LBB0_839:                               ; %else5186
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #3, LBB0_833
LBB0_840:                               ; %cond.load5188
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v26[1]
	ld1.d	{ v14 }[1], [x3]
	tbnz	w2, #4, LBB0_834
LBB0_841:                               ; %else5198
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #5, LBB0_835
LBB0_842:                               ; %cond.load5200
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v19[1]
	ld1.d	{ v16 }[1], [x3]
	tbnz	w2, #6, LBB0_836
LBB0_843:                               ; %else5210
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #7, LBB0_845
LBB0_844:                               ; %cond.load5212
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v18[1]
	ld1.d	{ v17 }[1], [x2]
LBB0_845:                               ; %else5216
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w2, #32                         ; =0x20
	dup.2d	v3, x2
	cmhi.2d	v4, v3, v14
	cmhi.2d	v18, v3, v13
	uzp1.4s	v4, v18, v4
	cmhi.2d	v18, v3, v16
	cmhi.2d	v3, v3, v17
	uzp1.4s	v3, v18, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	ldrb	w2, [x9]
	and	w3, w2, #0x1
	fmov	s4, w3
	ubfx	w3, w2, #1, #1
	mov.b	v4[1], w3
	ubfx	w3, w2, #2, #1
	mov.b	v4[2], w3
	ubfx	w3, w2, #3, #1
	mov.b	v4[3], w3
	ubfx	w3, w2, #4, #1
	mov.b	v4[4], w3
	ubfx	w3, w2, #5, #1
	mov.b	v4[5], w3
	ubfx	w3, w2, #6, #1
	mov.b	v4[6], w3
	lsr	w2, w2, #7
	mov.b	v4[7], w2
	bif.8b	v3, v4, v21
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x9]
	shl.2d	v3, v11, #5
	shl.2d	v4, v12, #5
	shl.2d	v18, v30, #5
	shl.2d	v19, v10, #5
	add.2d	v16, v16, v19
	add.2d	v17, v17, v18
	add.2d	v18, v13, v4
	add.2d	v19, v14, v3
	ldr	q3, [sp, #16800]
	ldr	q4, [sp, #16816]
	ldr	q21, [sp, #16768]
	ldr	q26, [sp, #16784]
	mov	b27, v20[2]
	mov.b	v27[4], v20[3]
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	mov	b30, v20[0]
	mov.b	v30[4], v20[1]
	bit.16b	v26, v19, v27
	ushll.2d	v27, v30, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	bit.16b	v21, v18, v27
	mov	b27, v20[6]
	mov.b	v27[4], v20[7]
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	bit.16b	v4, v17, v27
	mov	b27, v20[4]
	mov.b	v27[4], v20[5]
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	bit.16b	v3, v16, v27
	str	q3, [sp, #16800]
	str	q4, [sp, #16816]
	str	q21, [sp, #16768]
	str	q26, [sp, #16784]
	mov	w2, #128                        ; =0x80
	dup.2d	v26, x2
	cmhi.2d	v3, v26, v18
	cmhi.2d	v4, v26, v19
	uzp1.4s	v3, v3, v4
	cmhi.2d	v4, v26, v16
	cmhi.2d	v21, v26, v17
	uzp1.4s	v4, v4, v21
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v21, v20, v3
	shl.8b	v3, v21, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w2, s4
	umaxv.8b	b3, v3
	fmov	w3, s3
	tbz	w3, #0, LBB0_851
; %bb.846:                              ; %else5216
                                        ;   in Loop: Header=BB0_8 Depth=3
	cmhs.2d	v3, v18, v26
	cmhs.2d	v4, v19, v26
	uzp1.4s	v3, v3, v4
	cmhs.2d	v4, v16, v26
	cmhs.2d	v16, v17, v26
	uzp1.4s	v4, v4, v16
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v10, v20, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_851
; %bb.847:                              ; %varying.divergent898
                                        ;   in Loop: Header=BB0_8 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	str	q24, [sp, #4608]
	str	q22, [sp, #4624]
	and	x1, x1, #0x7
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #512
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #16, #0, ne
	cset	w1, ne
	cmp	w2, #255
	mov.16b	v25, v6
	b.ne	LBB0_849
; %bb.848:                              ; %varying.divergent898
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbnz	w1, #0, LBB0_1086
LBB0_849:                               ; %convergence.overflow.resume901
                                        ;   in Loop: Header=BB0_8 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #18, lsl #12            ; =73728
	add	x2, x2, #1520
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s5, w4
	ubfx	w4, w5, #1, #1
	mov.b	v5[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v5[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v5[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v5[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v5[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v5[6], w4
	add	x4, sp, #18, lsl #12            ; =73728
	add	x4, x4, #1512
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v4, w5
	bit.8b	v5, v20, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x2, w3, uxtw]
	bic.8b	v3, v3, v4
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_1086
; %bb.850:                              ; %ready.overflow.resume903
                                        ;   in Loop: Header=BB0_8 Depth=3
	zip2.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldp	q6, q4, [sp, #544]              ; 32-byte Folded Reload
	and.16b	v5, v3, v6
	zip1.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v4, v3, v4
	stp	q5, q4, [sp, #544]              ; 32-byte Folded Spill
	str	q23, [sp, #4576]
	str	q1, [sp, #4592]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #480
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q23, [sp, #4544]
	str	q1, [sp, #4560]
	add	x5, sp, #1, lsl #12             ; =4096
	add	x5, x5, #448
	str	w4, [x5, x2]
	ldr	q11, [sp, #4560]
	ldr	q23, [sp, #4544]
	str	q24, [sp, #4512]
	str	q22, [sp, #4528]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #416
	ldr	w4, [x4, x2]
	mov	w5, #16                         ; =0x10
	csel	w4, w5, w4, ne
	str	q24, [sp, #4480]
	str	q22, [sp, #4496]
	add	x5, sp, #1, lsl #12             ; =4096
	add	x5, x5, #384
	str	w4, [x5, x2]
	mov	w2, #43                         ; =0x2b
	mov	w4, #42                         ; =0x2a
	ldr	q12, [sp, #4496]
	ldr	q24, [sp, #4480]
                                        ; kill: def $w3 killed $w3 killed $x3 def $x3
	ldr	q22, [sp, #1232]                ; 16-byte Folded Reload
	ldr	q14, [sp, #1440]                ; 16-byte Folded Reload
	ldr	q4, [sp, #1504]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	ldr	q29, [sp, #1472]                ; 16-byte Folded Reload
	mov.16b	v13, v9
	mov.16b	v9, v4
	b	LBB0_7
LBB0_851:                               ; %varying.coherent899
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	mov.16b	v25, v6
	mov.16b	v12, v22
	b.eq	LBB0_898
; %bb.852:                              ; %varying.coherent.true904
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbnz	w1, #0, LBB0_1062
; %bb.853:                              ; %schedule.42.thread
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q3, [sp, #17152]
	ldr	q4, [sp, #17168]
	ldr	q7, [sp, #17184]
	ldr	q16, [sp, #17200]
	ldr	q17, [sp, #17264]
	ldr	q18, [sp, #17248]
	ldr	q19, [sp, #17232]
	ldr	q21, [sp, #17216]
	ldr	q26, [sp, #16768]
	ldr	q27, [sp, #16784]
	ldr	q30, [sp, #16800]
	ldr	q31, [sp, #16816]
	shl.2d	v31, v31, #5
	shl.2d	v30, v30, #5
	shl.2d	v27, v27, #5
	shl.2d	v26, v26, #5
	add.2d	v16, v16, v17
	add.2d	v17, v16, v31
	add.2d	v7, v7, v18
	add.2d	v18, v7, v30
	add.2d	v4, v4, v19
	add.2d	v19, v4, v27
	add.2d	v3, v3, v21
	add.2d	v21, v3, v26
	fmov	w1, s5
	movi.2d	v5, #0000000000000000
	movi.2d	v16, #0000000000000000
	ldr	q4, [sp, #1200]                 ; 16-byte Folded Reload
	ldr	q3, [sp, #1184]                 ; 16-byte Folded Reload
	mov.16b	v11, v1
	mov.16b	v13, v9
	tbz	w1, #0, LBB0_855
; %bb.854:                              ; %cond.load5940
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d21
	ldr	s5, [x2]
LBB0_855:                               ; %else5944
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q6, [sp, #1216]                 ; 16-byte Folded Reload
	ldr	q1, [sp, #1360]                 ; 16-byte Folded Reload
	ldr	q9, [sp, #1504]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	ldr	q29, [sp, #1472]                ; 16-byte Folded Reload
	str	q1, [sp, #1360]                 ; 16-byte Folded Spill
	str	q6, [sp, #1216]                 ; 16-byte Folded Spill
	str	q3, [sp, #1184]                 ; 16-byte Folded Spill
	str	q4, [sp, #1200]                 ; 16-byte Folded Spill
	tbz	w1, #1, LBB0_883
; %bb.856:                              ; %cond.load5946
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v21[1]
	ld1.s	{ v5 }[1], [x2]
	ldr	q1, [sp, #1552]                 ; 16-byte Folded Reload
	ldr	q22, [sp, #1232]                ; 16-byte Folded Reload
	mov.16b	v31, v8
	ldr	q14, [sp, #1440]                ; 16-byte Folded Reload
	tbnz	w1, #2, LBB0_884
LBB0_857:                               ; %else5956
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #3, LBB0_885
LBB0_858:                               ; %cond.load5958
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v19[1]
	ld1.s	{ v5 }[3], [x2]
	tbnz	w1, #4, LBB0_886
LBB0_859:                               ; %else5968
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #5, LBB0_887
LBB0_860:                               ; %cond.load5970
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v18[1]
	ld1.s	{ v16 }[1], [x2]
	tbnz	w1, #6, LBB0_888
LBB0_861:                               ; %else5980
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q1, [sp, #1552]                 ; 16-byte Folded Spill
	tbz	w1, #7, LBB0_863
LBB0_862:                               ; %cond.load5982
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x1, v17[1]
	ld1.s	{ v16 }[3], [x1]
LBB0_863:                               ; %else5986
                                        ;   in Loop: Header=BB0_8 Depth=3
	zip2.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q4, [sp, #544]                  ; 16-byte Folded Reload
	bit.16b	v4, v16, v3
	str	q4, [sp, #544]                  ; 16-byte Folded Spill
	zip1.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q4, [sp, #560]                  ; 16-byte Folded Reload
	bit.16b	v4, v5, v3
	str	q4, [sp, #560]                  ; 16-byte Folded Spill
	mov.16b	v6, v31
	cbnz	w0, LBB0_154
LBB0_864:                               ; %schedule.43.convergence.cascade.exit909_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v10, v29
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_865:                               ; %convergence.cascade.exit909
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1050
; %bb.866:                              ; %convergence.target.43.ready
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q1, [sp, #704]                  ; 16-byte Folded Reload
	dup.4s	v3, v1[0]
	ldrb	w1, [x9]
	ubfx	w2, w1, #3, #1
	ubfx	w3, w1, #2, #1
	ubfx	w4, w1, #1, #1
	and	w5, w1, #0x1
	lsr	w6, w1, #7
	ubfx	w7, w1, #6, #1
	ubfx	w19, w1, #5, #1
	ubfx	w1, w1, #4, #1
	fmov	s4, w1
	mov.h	v4[1], w19
	mov.h	v4[2], w7
	mov.h	v4[3], w6
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	fmov	s7, w5
	mov.h	v7[1], w4
	mov.h	v7[2], w3
	mov.h	v7[3], w2
	ldr	q5, [sp, #544]                  ; 16-byte Folded Reload
	bif.16b	v5, v3, v4
	ushll.4s	v4, v7, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q7, [sp, #560]                  ; 16-byte Folded Reload
	mov.16b	v17, v4
	bsl.16b	v17, v7, v3
	ldr	q3, [sp, #16944]
	ldr	q4, [sp, #16928]
	ldr	q7, [sp, #16912]
	ldr	q16, [sp, #16896]
	ldr	q18, [sp, #16960]
	ldr	q19, [sp, #16976]
	ldr	q21, [sp, #16992]
	ldr	q26, [sp, #17008]
	ldr	q1, [sp, #1264]                 ; 16-byte Folded Reload
	shl.2d	v27, v1, #5
	ldr	q30, [sp, #1024]                ; 16-byte Folded Reload
	shl.2d	v30, v30, #5
	ldr	q1, [sp, #928]                  ; 16-byte Folded Reload
	shl.2d	v31, v1, #5
	mov.16b	v29, v13
	shl.2d	v8, v13, #5
	add.2d	v26, v26, v8
	add.2d	v31, v21, v31
	add.2d	v19, v19, v30
	add.2d	v18, v18, v27
	add.2d	v21, v16, v18
	add.2d	v19, v7, v19
	add.2d	v18, v4, v31
	add.2d	v16, v3, v26
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w1, s3
	mov.16b	v31, v6
	tbz	w1, #0, LBB0_874
; %bb.867:                              ; %cond.store5989
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d21
	str	s17, [x2]
	tbnz	w1, #1, LBB0_875
LBB0_868:                               ; %else5996
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v13, v29
	tbz	w1, #2, LBB0_876
LBB0_869:                               ; %cond.store5997
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d19
	st1.s	{ v17 }[2], [x2]
	mov.16b	v29, v10
	tbnz	w1, #3, LBB0_877
LBB0_870:                               ; %else6004
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #4, LBB0_878
LBB0_871:                               ; %cond.store6005
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d18
	str	s5, [x2]
	tbnz	w1, #5, LBB0_879
LBB0_872:                               ; %else6012
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #6, LBB0_880
LBB0_873:                               ; %cond.store6013
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d16
	st1.s	{ v5 }[2], [x2]
	tbnz	w1, #7, LBB0_881
	b	LBB0_882
LBB0_874:                               ; %else5992
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #1, LBB0_868
LBB0_875:                               ; %cond.store5993
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v21[1]
	st1.s	{ v17 }[1], [x2]
	mov.16b	v13, v29
	tbnz	w1, #2, LBB0_869
LBB0_876:                               ; %else6000
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v29, v10
	tbz	w1, #3, LBB0_870
LBB0_877:                               ; %cond.store6001
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v19[1]
	st1.s	{ v17 }[3], [x2]
	tbnz	w1, #4, LBB0_871
LBB0_878:                               ; %else6008
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #5, LBB0_872
LBB0_879:                               ; %cond.store6009
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v18[1]
	st1.s	{ v5 }[1], [x2]
	tbnz	w1, #6, LBB0_873
LBB0_880:                               ; %else6016
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #7, LBB0_882
LBB0_881:                               ; %cond.store6017
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x1, v16[1]
	st1.s	{ v5 }[3], [x1]
LBB0_882:                               ; %else6020
                                        ;   in Loop: Header=BB0_8 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v20, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v4, v3, #0
	ushll2.4s	v3, v3, #0
	uaddw2.2d	v13, v13, v3
	uaddw.2d	v1, v1, v3
	str	q1, [sp, #928]                  ; 16-byte Folded Spill
	ldr	q3, [sp, #1024]                 ; 16-byte Folded Reload
	uaddw2.2d	v3, v3, v4
	str	q3, [sp, #1024]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #1264]                 ; 16-byte Folded Reload
	uaddw.2d	v1, v1, v4
	str	q1, [sp, #1264]                 ; 16-byte Folded Spill
	b	LBB0_821
LBB0_883:                               ; %else5950
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q1, [sp, #1552]                 ; 16-byte Folded Reload
	ldr	q22, [sp, #1232]                ; 16-byte Folded Reload
	mov.16b	v31, v8
	ldr	q14, [sp, #1440]                ; 16-byte Folded Reload
	tbz	w1, #2, LBB0_857
LBB0_884:                               ; %cond.load5952
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d19
	ld1.s	{ v5 }[2], [x2]
	tbnz	w1, #3, LBB0_858
LBB0_885:                               ; %else5962
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #4, LBB0_859
LBB0_886:                               ; %cond.load5964
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d18
	ld1.s	{ v16 }[0], [x2]
	tbnz	w1, #5, LBB0_860
LBB0_887:                               ; %else5974
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #6, LBB0_861
LBB0_888:                               ; %cond.load5976
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d17
	ld1.s	{ v16 }[2], [x2]
	str	q1, [sp, #1552]                 ; 16-byte Folded Spill
	tbnz	w1, #7, LBB0_862
	b	LBB0_863
LBB0_889:                               ; %varying.coherent.false894
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1063
LBB0_890:                               ; %schedule.44
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v6, v31
	cbz	w0, LBB0_895
; %bb.891:                              ; %convergence.cascade933.preheader
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
LBB0_892:                               ; %convergence.cascade933
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_3 Depth=2
                                        ;       Parent Loop BB0_8 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w2, s4
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	str	q24, [sp, #5472]
	str	q12, [sp, #5488]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #1, lsl #12             ; =4096
	add	x6, x6, #1376
	ldr	w6, [x6, x2]
	cmp	w6, #15
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #1520
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s5, w19
	ubfx	w19, w20, #1, #1
	mov.b	v5[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v5[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v5[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v5[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v5[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v5[6], w19
	add	x19, sp, #18, lsl #12           ; =73728
	add	x19, x19, #1512
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s3, w21
	ubfx	w21, w20, #1, #1
	mov.b	v3[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v3[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v3[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v3[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v3[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v3[6], w21
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	orr.8b	v4, v20, v3
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	and.8b	v7, v1, v5
	eor.8b	v7, v7, v4
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v4, v7
	dup.8b	v17, w7
	bit.8b	v3, v16, v17
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x19, w3, sxtw]
	bic.8b	v3, v5, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v4, v5, v4
	str	q23, [sp, #5440]
	str	q11, [sp, #5456]
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #1344
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v20, v4, v3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_896
; %bb.893:                              ; %convergence.cascade933
                                        ;   in Loop: Header=BB0_892 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_896
; %bb.894:                              ; %convergence.cascade933
                                        ;   in Loop: Header=BB0_892 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_892
	b	LBB0_896
LBB0_895:                               ; %schedule.44.convergence.cascade.exit934_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_896:                               ; %convergence.cascade.exit934
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1046
; %bb.897:                              ; %convergence.target.44.ready
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	b3, v20[6]
	mov.b	v3[4], v20[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q16, [sp, #112]                 ; 16-byte Folded Reload
	ldp	q4, q5, [sp, #352]              ; 32-byte Folded Reload
	bit.16b	v4, v16, v3
	str	q4, [sp, #352]                  ; 16-byte Folded Spill
	mov	b4, v20[4]
	mov.b	v4[4], v20[5]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	bit.16b	v5, v16, v4
	str	q5, [sp, #368]                  ; 16-byte Folded Spill
	mov	b5, v20[2]
	mov.b	v5[4], v20[3]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	ldp	q7, q17, [sp, #384]             ; 32-byte Folded Reload
	bit.16b	v7, v16, v5
	str	q7, [sp, #384]                  ; 16-byte Folded Spill
	mov	b7, v20[0]
	mov.b	v7[4], v20[1]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	bit.16b	v17, v16, v7
	str	q17, [sp, #400]                 ; 16-byte Folded Spill
Lloh1394:
	adrp	x1, lCPI0_19@PAGE
Lloh1395:
	ldr	q16, [x1, lCPI0_19@PAGEOFF]
	ldr	q17, [sp, #592]                 ; 16-byte Folded Reload
	bit.16b	v17, v16, v3
	str	q17, [sp, #592]                 ; 16-byte Folded Spill
Lloh1396:
	adrp	x1, lCPI0_18@PAGE
Lloh1397:
	ldr	q16, [x1, lCPI0_18@PAGEOFF]
	ldr	q17, [sp, #608]                 ; 16-byte Folded Reload
	bit.16b	v17, v16, v4
	str	q17, [sp, #608]                 ; 16-byte Folded Spill
Lloh1398:
	adrp	x1, lCPI0_17@PAGE
Lloh1399:
	ldr	q16, [x1, lCPI0_17@PAGEOFF]
	ldr	q17, [sp, #624]                 ; 16-byte Folded Reload
	bit.16b	v17, v16, v5
	str	q17, [sp, #624]                 ; 16-byte Folded Spill
Lloh1400:
	adrp	x1, lCPI0_16@PAGE
Lloh1401:
	ldr	q16, [x1, lCPI0_16@PAGEOFF]
	ldr	q17, [sp, #640]                 ; 16-byte Folded Reload
	bit.16b	v17, v16, v7
	str	q17, [sp, #640]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #864]                  ; 16-byte Folded Reload
	bic.16b	v1, v1, v3
	str	q1, [sp, #864]                  ; 16-byte Folded Spill
	ldr	q1, [sp, #848]                  ; 16-byte Folded Reload
	bic.16b	v1, v1, v4
	str	q1, [sp, #848]                  ; 16-byte Folded Spill
	ldr	q1, [sp, #1344]                 ; 16-byte Folded Reload
	bic.16b	v1, v1, v5
	str	q1, [sp, #1344]                 ; 16-byte Folded Spill
	bic.16b	v0, v0, v7
	mov.16b	v31, v6
	b	LBB0_899
LBB0_898:                               ; %varying.coherent.false905
                                        ;   in Loop: Header=BB0_8 Depth=3
	zip2.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldp	q6, q4, [sp, #544]              ; 32-byte Folded Reload
	and.16b	v5, v3, v6
	zip1.8b	v3, v20, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v4, v3, v4
	stp	q5, q4, [sp, #544]              ; 32-byte Folded Spill
	ldr	q22, [sp, #1232]                ; 16-byte Folded Reload
	ldr	q14, [sp, #1440]                ; 16-byte Folded Reload
	ldr	q5, [sp, #1504]                 ; 16-byte Folded Reload
	mov.16b	v11, v1
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	ldr	q29, [sp, #1472]                ; 16-byte Folded Reload
	mov.16b	v13, v9
	mov.16b	v9, v5
	tbnz	w1, #0, LBB0_1063
	b	LBB0_153
LBB0_899:                               ; %schedule.45
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	mov	w1, #128                        ; =0x80
	dup.2d	v5, x1
	ldr	q1, [sp, #1344]                 ; 16-byte Folded Reload
	cmgt.2d	v3, v5, v1
	cmgt.2d	v4, v5, v0
	uzp1.4s	v3, v4, v3
	ldp	q6, q7, [sp, #848]              ; 32-byte Folded Reload
	cmgt.2d	v4, v5, v6
	cmgt.2d	v16, v5, v7
	uzp1.4s	v4, v4, v16
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v21, v20, v3
	shl.8b	v3, v21, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w1, s4
	umaxv.8b	b3, v3
	fmov	w3, s3
	tbz	w3, #0, LBB0_905
; %bb.900:                              ; %schedule.45
                                        ;   in Loop: Header=BB0_8 Depth=3
	cmge.2d	v3, v1, v5
	cmge.2d	v4, v0, v5
	uzp1.4s	v3, v4, v3
	cmge.2d	v4, v6, v5
	cmge.2d	v5, v7, v5
	uzp1.4s	v4, v4, v5
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v10, v20, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_905
; %bb.901:                              ; %varying.divergent951
                                        ;   in Loop: Header=BB0_8 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	str	q24, [sp, #4832]
	str	q12, [sp, #4848]
	and	x1, x1, #0x7
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #736
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #17, #0, ne
	cset	w1, ne
	cmp	w2, #255
	b.ne	LBB0_903
; %bb.902:                              ; %varying.divergent951
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbnz	w1, #0, LBB0_1086
LBB0_903:                               ; %convergence.overflow.resume954
                                        ;   in Loop: Header=BB0_8 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #18, lsl #12            ; =73728
	add	x2, x2, #1520
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s5, w4
	ubfx	w4, w5, #1, #1
	mov.b	v5[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v5[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v5[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v5[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v5[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v5[6], w4
	add	x4, sp, #18, lsl #12            ; =73728
	add	x4, x4, #1512
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v4, w5
	bit.8b	v5, v20, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x2, w3, uxtw]
	bic.8b	v3, v3, v4
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_1086
; %bb.904:                              ; %ready.overflow.resume956
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q23, [sp, #4800]
	str	q11, [sp, #4816]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #704
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q23, [sp, #4768]
	str	q11, [sp, #4784]
	add	x5, sp, #1, lsl #12             ; =4096
	add	x5, x5, #672
	str	w4, [x5, x2]
	ldr	q11, [sp, #4784]
	ldr	q23, [sp, #4768]
	str	q24, [sp, #4736]
	str	q12, [sp, #4752]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #640
	ldr	w4, [x4, x2]
	mov	w5, #17                         ; =0x11
	csel	w4, w5, w4, ne
	str	q24, [sp, #4704]
	str	q12, [sp, #4720]
	add	x5, sp, #1, lsl #12             ; =4096
	add	x5, x5, #608
	str	w4, [x5, x2]
	mov	w2, #47                         ; =0x2f
	mov	w4, #46                         ; =0x2e
	ldr	q12, [sp, #4720]
	ldr	q24, [sp, #4704]
	b	LBB0_6
LBB0_905:                               ; %varying.coherent952
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w1, #0xff
	b.eq	LBB0_972
; %bb.906:                              ; %varying.coherent.true957
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
	tst	w2, #0xff
	b.eq	LBB0_1063
LBB0_907:                               ; %schedule.46
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q31, [sp, #1456]                ; 16-byte Folded Spill
	str	q12, [sp, #1536]                ; 16-byte Folded Spill
	str	q23, [sp, #1392]                ; 16-byte Folded Spill
	str	q11, [sp, #1568]                ; 16-byte Folded Spill
	str	q25, [sp, #1168]                ; 16-byte Folded Spill
	str	q9, [sp, #1504]                 ; 16-byte Folded Spill
	str	q14, [sp, #1440]                ; 16-byte Folded Spill
	mov.16b	v4, v0
	mov.16b	v0, v28
	mov.16b	v28, v22
	str	q0, [sp, #1408]                 ; 16-byte Folded Spill
	mov.16b	v23, v29
	ldr	q29, [sp, #1552]                ; 16-byte Folded Reload
	mov.16b	v22, v13
	mov	b3, v20[0]
	mov.b	v3[4], v20[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v16, v3, #0
	str	q4, [sp, #1488]                 ; 16-byte Folded Spill
	and.16b	v17, v16, v4
	mov	b3, v20[2]
	mov.b	v3[4], v20[3]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v5, v3, #0
	mov	b3, v20[4]
	mov.b	v3[4], v20[5]
	ldr	q4, [sp, #1344]                 ; 16-byte Folded Reload
	and.16b	v21, v5, v4
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v18, v3, #0
	ldr	q3, [sp, #848]                  ; 16-byte Folded Reload
	and.16b	v30, v18, v3
	mov	b3, v20[6]
	mov.b	v3[4], v20[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v12, v3, #0
	ldr	q3, [sp, #864]                  ; 16-byte Folded Reload
	and.16b	v19, v12, v3
	shl.8b	v10, v20, #7
	mov	w2, #32                         ; =0x20
	dup.2d	v3, x2
	and.16b	v4, v16, v3
	mvn.16b	v26, v16
	sub.2d	v26, v4, v26
	and.16b	v4, v5, v3
	mvn.16b	v27, v5
	sub.2d	v4, v4, v27
	and.16b	v27, v18, v3
	mvn.16b	v31, v18
	sub.2d	v27, v27, v31
	and.16b	v3, v12, v3
	mvn.16b	v31, v12
	sub.2d	v3, v3, v31
	mov.d	x2, v3[1]
	mov.d	x3, v19[1]
	sdiv	x21, x3, x2
	fmov	x3, d3
	fmov	x4, d19
	sdiv	x4, x4, x3
	mul	x22, x4, x3
	fmov	d3, x4
	mov.d	v3[1], x21
	mov.d	x4, v27[1]
	mov.d	x5, v30[1]
	sdiv	x23, x5, x4
	fmov	x6, d27
	fmov	x5, d30
	sdiv	x5, x5, x6
	mul	x24, x5, x6
	fmov	d27, x5
	mov.d	v27[1], x23
	mov.d	x5, v4[1]
	mov.d	x7, v21[1]
	sdiv	x25, x7, x5
	fmov	x19, d4
	fmov	x7, d21
	sdiv	x7, x7, x19
	mul	x26, x7, x19
	fmov	d4, x7
	mov.d	v4[1], x25
	mov.d	x7, v26[1]
	mov.d	x20, v17[1]
	sdiv	x27, x20, x7
	fmov	x20, d26
	fmov	x28, d17
	sdiv	x28, x28, x20
	mul	x30, x28, x20
	fmov	d26, x28
	mov.d	v26[1], x27
	mul	x21, x21, x2
	fmov	d31, x22
	mov.d	v31[1], x21
	mul	x21, x23, x4
	fmov	d11, x24
	mov.d	v11[1], x21
	cmlt.8b	v13, v10, #0
	mul	x21, x25, x5
	fmov	d10, x26
	mov.d	v10[1], x21
	mul	x21, x27, x7
	fmov	d14, x30
	mov.d	v14[1], x21
	sub.2d	v17, v17, v14
	sub.2d	v14, v21, v10
	sub.2d	v15, v30, v11
	sub.2d	v19, v19, v31
	shl.2d	v11, v26, #5
	shl.2d	v10, v4, #5
	shl.2d	v30, v27, #5
	shl.2d	v21, v3, #5
	add.2d	v3, v21, v19
	add.2d	v4, v30, v15
	add.2d	v19, v10, v14
	add.2d	v17, v11, v17
	and.16b	v16, v16, v17
	and.16b	v17, v18, v4
	and.16b	v18, v12, v3
	mov.d	x21, v18[1]
	sdiv	x21, x21, x2
	fmov	x22, d18
	sdiv	x22, x22, x3
	mul	x3, x22, x3
	fmov	d3, x22
	mov.d	v3[1], x21
	mov.d	x22, v17[1]
	sdiv	x22, x22, x4
	fmov	x23, d17
	sdiv	x23, x23, x6
	mul	x6, x23, x6
	fmov	d4, x23
	mov.d	v4[1], x22
	and.16b	v19, v5, v19
	mov.d	x23, v19[1]
	sdiv	x23, x23, x5
	fmov	x24, d19
	sdiv	x24, x24, x19
	mul	x19, x24, x19
	fmov	d26, x24
	mov.d	v26[1], x23
	mov.d	x24, v16[1]
	and.8b	v5, v13, v2
	fmov	x25, d16
	sdiv	x25, x25, x20
	mul	x20, x25, x20
	fmov	d27, x25
	sdiv	x24, x24, x7
	mov.d	v27[1], x24
	mul	x7, x24, x7
	fmov	d31, x20
	mov.d	v31[1], x7
	mul	x5, x23, x5
	fmov	d12, x19
	mov.d	v12[1], x5
	mul	x4, x22, x4
	fmov	d13, x6
	mov.d	v13[1], x4
	mul	x2, x21, x2
	fmov	d14, x3
	mov.d	v14[1], x2
	addv.8b	b5, v5
	sub.2d	v18, v18, v14
	sub.2d	v17, v17, v13
	fmov	w2, s5
	sub.2d	v19, v19, v12
	sub.2d	v16, v16, v31
	ldr	q31, [sp, #17152]
	ldr	q12, [sp, #17168]
	ldr	q13, [sp, #17184]
	ldr	q15, [sp, #17200]
	ldr	q8, [sp, #17264]
	ldr	q9, [sp, #17248]
	ldr	q7, [sp, #17232]
	shl.2d	v27, v27, #10
	shl.2d	v26, v26, #10
	shl.2d	v4, v4, #10
	shl.2d	v3, v3, #10
	shl.2d	v14, v16, #5
	shl.2d	v19, v19, #5
	shl.2d	v17, v17, #5
	shl.2d	v16, v18, #5
	add.2d	v16, v3, v16
	add.2d	v17, v4, v17
	ldr	q3, [sp, #17216]
	add.2d	v18, v26, v19
	add.2d	v14, v27, v14
	add.2d	v4, v15, v8
	add.2d	v19, v4, v16
	add.2d	v4, v13, v9
	add.2d	v26, v4, v17
	add.2d	v4, v12, v7
	add.2d	v27, v4, v18
	add.2d	v3, v31, v3
	add.2d	v31, v3, v14
	movi.2d	v12, #0000000000000000
	movi.2d	v13, #0000000000000000
	str	q23, [sp, #1472]                ; 16-byte Folded Spill
	str	q28, [sp, #1232]                ; 16-byte Folded Spill
	str	q29, [sp, #1552]                ; 16-byte Folded Spill
	tbz	w2, #0, LBB0_925
; %bb.908:                              ; %cond.load5268
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d31
	ldr	s12, [x3]
	tbnz	w2, #1, LBB0_926
LBB0_909:                               ; %else5278
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v4, v22
	tbz	w2, #2, LBB0_911
LBB0_910:                               ; %cond.load5280
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d27
	ld1.s	{ v12 }[2], [x3]
LBB0_911:                               ; %else5284
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q1, [sp, #1520]                 ; 16-byte Folded Reload
	ldr	q15, [sp, #1296]                ; 16-byte Folded Reload
	ldr	q0, [sp, #1248]                 ; 16-byte Folded Reload
	ldr	q22, [sp, #1424]                ; 16-byte Folded Reload
	ldr	q23, [sp, #1392]                ; 16-byte Folded Reload
	str	q1, [sp, #1520]                 ; 16-byte Folded Spill
	tbz	w2, #3, LBB0_927
; %bb.912:                              ; %cond.load5286
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v27[1]
	ld1.s	{ v12 }[3], [x3]
	tbnz	w2, #4, LBB0_928
LBB0_913:                               ; %else5296
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #5, LBB0_929
LBB0_914:                               ; %cond.load5298
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v26[1]
	ld1.s	{ v13 }[1], [x3]
	tbnz	w2, #6, LBB0_930
LBB0_915:                               ; %else5308
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q15, [sp, #1296]                ; 16-byte Folded Spill
	str	q0, [sp, #1248]                 ; 16-byte Folded Spill
	mov.16b	v0, v4
	tbz	w2, #7, LBB0_917
LBB0_916:                               ; %cond.load5310
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v19[1]
	ld1.s	{ v13 }[3], [x2]
LBB0_917:                               ; %else5314
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v15, v22
	ldr	q3, [sp, #16944]
	ldr	q4, [sp, #16928]
	ldr	q7, [sp, #16912]
	ldr	q19, [sp, #16896]
	ldr	q26, [sp, #16960]
	ldr	q31, [sp, #16976]
	ldr	q8, [sp, #16992]
	ldr	q9, [sp, #17008]
	add.2d	v19, v19, v26
	add.2d	v27, v19, v14
	add.2d	v7, v7, v31
	add.2d	v26, v7, v18
	add.2d	v4, v4, v8
	add.2d	v19, v4, v17
	add.2d	v3, v3, v9
	add.2d	v18, v3, v16
	fmov	w2, s5
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbz	w2, #0, LBB0_931
; %bb.918:                              ; %cond.load5317
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d27
	ldr	s16, [x3]
	ldr	q22, [sp, #1488]                ; 16-byte Folded Reload
	ldr	q29, [sp, #1440]                ; 16-byte Folded Reload
	ldr	q9, [sp, #1504]                 ; 16-byte Folded Reload
	ldr	q14, [sp, #1168]                ; 16-byte Folded Reload
	tbnz	w2, #1, LBB0_932
LBB0_919:                               ; %else5327
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q3, [sp, #1344]                 ; 16-byte Folded Reload
	ldp	q6, q25, [sp, #848]             ; 32-byte Folded Reload
	ldr	q1, [sp, #1264]                 ; 16-byte Folded Reload
	tbz	w2, #2, LBB0_933
LBB0_920:                               ; %cond.load5329
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d26
	ld1.s	{ v16 }[2], [x3]
	tbnz	w2, #3, LBB0_934
LBB0_921:                               ; %else5339
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #4, LBB0_935
LBB0_922:                               ; %cond.load5341
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d19
	ld1.s	{ v17 }[0], [x3]
	tbnz	w2, #5, LBB0_936
LBB0_923:                               ; %else5351
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #6, LBB0_937
LBB0_924:                               ; %cond.load5353
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d18
	ld1.s	{ v17 }[2], [x3]
	str	q3, [sp, #1344]                 ; 16-byte Folded Spill
	tbnz	w2, #7, LBB0_938
	b	LBB0_939
LBB0_925:                               ; %else5272
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #1, LBB0_909
LBB0_926:                               ; %cond.load5274
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v31[1]
	ld1.s	{ v12 }[1], [x3]
	mov.16b	v4, v22
	tbnz	w2, #2, LBB0_910
	b	LBB0_911
LBB0_927:                               ; %else5290
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #4, LBB0_913
LBB0_928:                               ; %cond.load5292
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d26
	ld1.s	{ v13 }[0], [x3]
	tbnz	w2, #5, LBB0_914
LBB0_929:                               ; %else5302
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #6, LBB0_915
LBB0_930:                               ; %cond.load5304
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d19
	ld1.s	{ v13 }[2], [x3]
	str	q15, [sp, #1296]                ; 16-byte Folded Spill
	str	q0, [sp, #1248]                 ; 16-byte Folded Spill
	mov.16b	v0, v4
	tbnz	w2, #7, LBB0_916
	b	LBB0_917
LBB0_931:                               ; %else5321
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q22, [sp, #1488]                ; 16-byte Folded Reload
	ldr	q29, [sp, #1440]                ; 16-byte Folded Reload
	ldr	q9, [sp, #1504]                 ; 16-byte Folded Reload
	ldr	q14, [sp, #1168]                ; 16-byte Folded Reload
	tbz	w2, #1, LBB0_919
LBB0_932:                               ; %cond.load5323
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v27[1]
	ld1.s	{ v16 }[1], [x3]
	ldr	q3, [sp, #1344]                 ; 16-byte Folded Reload
	ldp	q6, q25, [sp, #848]             ; 32-byte Folded Reload
	ldr	q1, [sp, #1264]                 ; 16-byte Folded Reload
	tbnz	w2, #2, LBB0_920
LBB0_933:                               ; %else5333
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #3, LBB0_921
LBB0_934:                               ; %cond.load5335
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v26[1]
	ld1.s	{ v16 }[3], [x3]
	tbnz	w2, #4, LBB0_922
LBB0_935:                               ; %else5345
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #5, LBB0_923
LBB0_936:                               ; %cond.load5347
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v19[1]
	ld1.s	{ v17 }[1], [x3]
	tbnz	w2, #6, LBB0_924
LBB0_937:                               ; %else5357
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q3, [sp, #1344]                 ; 16-byte Folded Spill
	tbz	w2, #7, LBB0_939
LBB0_938:                               ; %cond.load5359
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v18[1]
	ld1.s	{ v17 }[3], [x2]
LBB0_939:                               ; %else5363
                                        ;   in Loop: Header=BB0_8 Depth=3
	fadd.4s	v16, v12, v16
	fadd.4s	v17, v13, v17
	ldr	q3, [sp, #19504]
	ldr	q4, [sp, #19488]
	ldr	q7, [sp, #19472]
	ldr	q18, [sp, #19456]
	ldr	q19, [sp, #19520]
	ldr	q26, [sp, #19536]
	ldr	q31, [sp, #19552]
	ldr	q8, [sp, #19568]
	add.2d	v18, v18, v19
	add.2d	v27, v18, v11
	add.2d	v7, v7, v26
	add.2d	v10, v7, v10
	add.2d	v4, v4, v31
	add.2d	v26, v4, v30
	add.2d	v3, v3, v8
	add.2d	v21, v3, v21
	fmov	w2, s5
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	tbz	w2, #0, LBB0_947
; %bb.940:                              ; %cond.load5366
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d27
	ldr	s18, [x3]
	str	q1, [sp, #1264]                 ; 16-byte Folded Spill
	ldr	q30, [sp, #1312]                ; 16-byte Folded Reload
	ldr	q11, [sp, #1568]                ; 16-byte Folded Reload
	ldr	q12, [sp, #1536]                ; 16-byte Folded Reload
	ldr	q31, [sp, #1456]                ; 16-byte Folded Reload
	tbnz	w2, #1, LBB0_948
LBB0_941:                               ; %else5376
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q27, [sp, #1408]                ; 16-byte Folded Reload
	mov.16b	v13, v0
	tbz	w2, #2, LBB0_949
LBB0_942:                               ; %cond.load5378
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d10
	ld1.s	{ v18 }[2], [x3]
	tbnz	w2, #3, LBB0_950
LBB0_943:                               ; %else5388
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #4, LBB0_951
LBB0_944:                               ; %cond.load5390
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d26
	ld1.s	{ v19 }[0], [x3]
	tbnz	w2, #5, LBB0_952
LBB0_945:                               ; %else5400
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #6, LBB0_953
LBB0_946:                               ; %cond.load5402
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d21
	ld1.s	{ v19 }[2], [x3]
	tbnz	w2, #7, LBB0_954
	b	LBB0_955
LBB0_947:                               ; %else5370
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q1, [sp, #1264]                 ; 16-byte Folded Spill
	ldr	q30, [sp, #1312]                ; 16-byte Folded Reload
	ldr	q11, [sp, #1568]                ; 16-byte Folded Reload
	ldr	q12, [sp, #1536]                ; 16-byte Folded Reload
	ldr	q31, [sp, #1456]                ; 16-byte Folded Reload
	tbz	w2, #1, LBB0_941
LBB0_948:                               ; %cond.load5372
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v27[1]
	ld1.s	{ v18 }[1], [x3]
	ldr	q27, [sp, #1408]                ; 16-byte Folded Reload
	mov.16b	v13, v0
	tbnz	w2, #2, LBB0_942
LBB0_949:                               ; %else5382
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #3, LBB0_943
LBB0_950:                               ; %cond.load5384
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v10[1]
	ld1.s	{ v18 }[3], [x3]
	tbnz	w2, #4, LBB0_944
LBB0_951:                               ; %else5394
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #5, LBB0_945
LBB0_952:                               ; %cond.load5396
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v26[1]
	ld1.s	{ v19 }[1], [x3]
	tbnz	w2, #6, LBB0_946
LBB0_953:                               ; %else5406
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #7, LBB0_955
LBB0_954:                               ; %cond.load5408
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v21[1]
	ld1.s	{ v19 }[3], [x2]
LBB0_955:                               ; %else5412
                                        ;   in Loop: Header=BB0_8 Depth=3
	fadd.4s	v18, v16, v18
	fadd.4s	v16, v17, v19
	shl.2d	v3, v22, #5
	ldr	q1, [sp, #1344]                 ; 16-byte Folded Reload
	shl.2d	v4, v1, #5
	shl.2d	v7, v6, #5
	shl.2d	v26, v25, #5
	ldr	q17, [sp, #400]                 ; 16-byte Folded Reload
	ldr	q19, [sp, #640]                 ; 16-byte Folded Reload
	add.2d	v17, v17, v19
	add.2d	v21, v17, v3
	ldr	q3, [sp, #384]                  ; 16-byte Folded Reload
	ldr	q17, [sp, #624]                 ; 16-byte Folded Reload
	add.2d	v3, v3, v17
	add.2d	v19, v3, v4
	ldr	q3, [sp, #368]                  ; 16-byte Folded Reload
	ldp	q4, q0, [sp, #592]              ; 32-byte Folded Reload
	add.2d	v3, v3, v0
	add.2d	v17, v3, v7
	ldr	q3, [sp, #352]                  ; 16-byte Folded Reload
	add.2d	v3, v3, v4
	fmov	w2, s5
	add.2d	v5, v3, v26
	tbz	w2, #0, LBB0_963
; %bb.956:                              ; %cond.store5415
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d21
	str	s18, [x3]
	tbnz	w2, #1, LBB0_964
LBB0_957:                               ; %else5422
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #2, LBB0_965
LBB0_958:                               ; %cond.store5423
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d19
	st1.s	{ v18 }[2], [x3]
	tbnz	w2, #3, LBB0_966
LBB0_959:                               ; %else5430
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #4, LBB0_967
LBB0_960:                               ; %cond.store5431
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d17
	str	s16, [x3]
	tbnz	w2, #5, LBB0_968
LBB0_961:                               ; %else5438
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #6, LBB0_969
LBB0_962:                               ; %cond.store5439
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d5
	st1.s	{ v16 }[2], [x3]
	tbnz	w2, #7, LBB0_970
	b	LBB0_971
LBB0_963:                               ; %else5418
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #1, LBB0_957
LBB0_964:                               ; %cond.store5419
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v21[1]
	st1.s	{ v18 }[1], [x3]
	tbnz	w2, #2, LBB0_958
LBB0_965:                               ; %else5426
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #3, LBB0_959
LBB0_966:                               ; %cond.store5427
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v19[1]
	st1.s	{ v18 }[3], [x3]
	tbnz	w2, #4, LBB0_960
LBB0_967:                               ; %else5434
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #5, LBB0_961
LBB0_968:                               ; %cond.store5435
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v17[1]
	st1.s	{ v16 }[1], [x3]
	tbnz	w2, #6, LBB0_962
LBB0_969:                               ; %else5442
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #7, LBB0_971
LBB0_970:                               ; %cond.store5443
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v5[1]
	st1.s	{ v16 }[3], [x2]
LBB0_971:                               ; %else5446
                                        ;   in Loop: Header=BB0_8 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v20, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v4, v3, #0
	ushll2.4s	v3, v3, #0
	uaddw2.2d	v25, v25, v3
	uaddw.2d	v6, v6, v3
	stp	q6, q25, [sp, #848]             ; 32-byte Folded Spill
	ldr	q1, [sp, #1344]                 ; 16-byte Folded Reload
	uaddw2.2d	v1, v1, v4
	str	q1, [sp, #1344]                 ; 16-byte Folded Spill
	uaddw.2d	v0, v22, v4
	mov.16b	v25, v14
	ldr	q22, [sp, #1232]                ; 16-byte Folded Reload
	mov.16b	v14, v29
	ldr	q29, [sp, #1472]                ; 16-byte Folded Reload
	mov.16b	v28, v27
	str	q15, [sp, #1424]                ; 16-byte Folded Spill
	str	q30, [sp, #1312]                ; 16-byte Folded Spill
	tbz	w1, #0, LBB0_899
	b	LBB0_1063
LBB0_972:                               ; %varying.coherent.false958
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1063
LBB0_973:                               ; %schedule.47
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v6, v31
	cbz	w0, LBB0_978
; %bb.974:                              ; %convergence.cascade967.preheader
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
LBB0_975:                               ; %convergence.cascade967
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_3 Depth=2
                                        ;       Parent Loop BB0_8 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w2, s4
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	str	q24, [sp, #5408]
	str	q12, [sp, #5424]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #1, lsl #12             ; =4096
	add	x6, x6, #1312
	ldr	w6, [x6, x2]
	cmp	w6, #17
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #1520
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s5, w19
	ubfx	w19, w20, #1, #1
	mov.b	v5[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v5[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v5[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v5[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v5[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v5[6], w19
	add	x19, sp, #18, lsl #12           ; =73728
	add	x19, x19, #1512
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s3, w21
	ubfx	w21, w20, #1, #1
	mov.b	v3[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v3[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v3[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v3[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v3[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v3[6], w21
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	orr.8b	v4, v20, v3
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	and.8b	v7, v1, v5
	eor.8b	v7, v7, v4
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v4, v7
	dup.8b	v17, w7
	bit.8b	v3, v16, v17
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x19, w3, sxtw]
	bic.8b	v3, v5, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v4, v5, v4
	str	q23, [sp, #5376]
	str	q11, [sp, #5392]
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #1280
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v20, v4, v3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_979
; %bb.976:                              ; %convergence.cascade967
                                        ;   in Loop: Header=BB0_975 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_979
; %bb.977:                              ; %convergence.cascade967
                                        ;   in Loop: Header=BB0_975 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_975
	b	LBB0_979
LBB0_978:                               ; %schedule.47.convergence.cascade.exit968_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_979:                               ; %convergence.cascade.exit968
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1046
; %bb.980:                              ; %convergence.target.47.ready
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	b3, v20[6]
	mov.b	v3[4], v20[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmge.2d	v3, v3, #0
	ldp	q4, q5, [sp, #816]              ; 32-byte Folded Reload
	and.16b	v1, v3, v4
	mov	b3, v20[4]
	mov.b	v3[4], v20[5]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmge.2d	v3, v3, #0
	mov	b4, v20[2]
	mov.b	v4[4], v20[3]
	and.16b	v5, v3, v5
	stp	q1, q5, [sp, #816]              ; 32-byte Folded Spill
	ushll.2d	v3, v4, #0
	shl.2d	v3, v3, #63
	cmge.2d	v3, v3, #0
	ldp	q4, q5, [sp, #784]              ; 32-byte Folded Reload
	and.16b	v1, v3, v5
	mov	b3, v20[0]
	mov.b	v3[4], v20[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmge.2d	v3, v3, #0
	and.16b	v4, v3, v4
	stp	q4, q1, [sp, #784]              ; 32-byte Folded Spill
LBB0_981:                               ; %schedule.48
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v31, v6
LBB0_982:                               ; %schedule.48
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	mov	w1, #128                        ; =0x80
	dup.2d	v5, x1
	ldp	q19, q16, [sp, #784]            ; 32-byte Folded Reload
	cmgt.2d	v3, v5, v16
	cmgt.2d	v4, v5, v19
	uzp1.4s	v3, v4, v3
	ldp	q18, q17, [sp, #816]            ; 32-byte Folded Reload
	cmgt.2d	v4, v5, v17
	cmgt.2d	v7, v5, v18
	uzp1.4s	v4, v4, v7
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v21, v20, v3
	shl.8b	v3, v21, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w1, s4
	umaxv.8b	b3, v3
	fmov	w3, s3
	tbz	w3, #0, LBB0_988
; %bb.983:                              ; %schedule.48
                                        ;   in Loop: Header=BB0_8 Depth=3
	cmge.2d	v3, v16, v5
	cmge.2d	v4, v19, v5
	uzp1.4s	v3, v4, v3
	cmge.2d	v4, v17, v5
	cmge.2d	v5, v18, v5
	uzp1.4s	v4, v4, v5
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v10, v20, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_988
; %bb.984:                              ; %varying.divergent985
                                        ;   in Loop: Header=BB0_8 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	str	q24, [sp, #4992]
	str	q12, [sp, #5008]
	and	x1, x1, #0x7
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #896
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #18, #0, ne
	cset	w1, ne
	cmp	w2, #255
	b.ne	LBB0_986
; %bb.985:                              ; %varying.divergent985
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbnz	w1, #0, LBB0_1086
LBB0_986:                               ; %convergence.overflow.resume988
                                        ;   in Loop: Header=BB0_8 Depth=3
	mvn	w2, w16
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w16
	csel	w3, wzr, w2, eq
	add	x2, sp, #18, lsl #12            ; =73728
	add	x2, x2, #1520
	ldrb	w5, [x2, w3, uxtw]
	and	w4, w5, #0x1
	fmov	s5, w4
	ubfx	w4, w5, #1, #1
	mov.b	v5[1], w4
	ubfx	w4, w5, #2, #1
	mov.b	v5[2], w4
	ubfx	w4, w5, #3, #1
	mov.b	v5[3], w4
	ubfx	w4, w5, #4, #1
	mov.b	v5[4], w4
	ubfx	w4, w5, #5, #1
	mov.b	v5[5], w4
	ubfx	w4, w5, #6, #1
	mov.b	v5[6], w4
	add	x4, sp, #18, lsl #12            ; =73728
	add	x4, x4, #1512
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	ldrb	w5, [x4, w3, uxtw]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	cmp	w1, #0
	csetm	w5, ne
	dup.8b	v4, w5
	bit.8b	v5, v20, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x2, w3, uxtw]
	bic.8b	v3, v3, v4
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x4, w3, uxtw]
	cmp	x17, #8
	b.hs	LBB0_1086
; %bb.987:                              ; %ready.overflow.resume990
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q23, [sp, #4960]
	str	q11, [sp, #4976]
	ubfiz	x2, x3, #2, #3
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #864
	ldr	w4, [x4, x2]
	cmp	w1, #0
	csel	w4, w0, w4, ne
	csinc	w0, w0, w3, eq
	str	q23, [sp, #4928]
	str	q11, [sp, #4944]
	add	x5, sp, #1, lsl #12             ; =4096
	add	x5, x5, #832
	str	w4, [x5, x2]
	ldr	q11, [sp, #4944]
	ldr	q23, [sp, #4928]
	str	q24, [sp, #4896]
	str	q12, [sp, #4912]
	add	x4, sp, #1, lsl #12             ; =4096
	add	x4, x4, #800
	ldr	w4, [x4, x2]
	mov	w5, #18                         ; =0x12
	csel	w4, w5, w4, ne
	str	q24, [sp, #4864]
	str	q12, [sp, #4880]
	add	x5, sp, #1, lsl #12             ; =4096
	add	x5, x5, #768
	str	w4, [x5, x2]
	mov	w2, #52                         ; =0x34
	mov	w4, #49                         ; =0x31
	ldr	q12, [sp, #4880]
	ldr	q24, [sp, #4864]
	b	LBB0_6
LBB0_988:                               ; %varying.coherent986
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w1, #0xff
	b.eq	LBB0_1028
; %bb.989:                              ; %varying.coherent.true991
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
	tst	w2, #0xff
	b.eq	LBB0_1063
LBB0_990:                               ; %schedule.49
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v6, v31
	str	q24, [sp, #1376]                ; 16-byte Folded Spill
	str	q12, [sp, #1536]                ; 16-byte Folded Spill
	str	q23, [sp, #1392]                ; 16-byte Folded Spill
	str	q11, [sp, #1568]                ; 16-byte Folded Spill
	str	q25, [sp, #1168]                ; 16-byte Folded Spill
	str	q9, [sp, #1504]                 ; 16-byte Folded Spill
	str	q28, [sp, #1408]                ; 16-byte Folded Spill
	mov.16b	v28, v14
	str	q22, [sp, #1232]                ; 16-byte Folded Spill
	ldr	q23, [sp, #1520]                ; 16-byte Folded Reload
	str	q29, [sp, #1472]                ; 16-byte Folded Spill
	str	q13, [sp, #1456]                ; 16-byte Folded Spill
	mov.16b	v22, v0
	mov	b3, v20[0]
	mov.b	v3[4], v20[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v21, v3, #0
	ldp	q0, q13, [sp, #784]             ; 32-byte Folded Reload
	and.16b	v18, v21, v0
	mov	b3, v20[2]
	mov.b	v3[4], v20[3]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v30, v3, #0
	and.16b	v10, v30, v13
	mov	b3, v20[4]
	mov.b	v3[4], v20[5]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v16, v3, #0
	ldp	q15, q14, [sp, #816]            ; 32-byte Folded Reload
	and.16b	v11, v16, v14
	mov	b3, v20[6]
	mov.b	v3[4], v20[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v17, v3, #0
	and.16b	v19, v17, v15
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v5, v3, v2
	mov	w2, #32                         ; =0x20
	dup.2d	v3, x2
	and.16b	v4, v21, v3
	mvn.16b	v7, v21
	sub.2d	v12, v4, v7
	and.16b	v4, v30, v3
	mvn.16b	v7, v30
	sub.2d	v26, v4, v7
	and.16b	v4, v16, v3
	and.16b	v3, v17, v3
	mvn.16b	v7, v17
	sub.2d	v3, v3, v7
	mov.d	x2, v3[1]
	mov.d	x3, v19[1]
	mvn.16b	v7, v16
	sdiv	x3, x3, x2
	sub.2d	v4, v4, v7
	fmov	x4, d3
	fmov	x5, d19
	sdiv	x5, x5, x4
	mul	x4, x5, x4
	fmov	d3, x5
	mov.d	v3[1], x3
	mov.d	x5, v4[1]
	mov.d	x6, v11[1]
	sdiv	x6, x6, x5
	fmov	x7, d4
	fmov	x19, d11
	sdiv	x19, x19, x7
	mul	x7, x19, x7
	fmov	d4, x19
	mov.d	v4[1], x6
	mov.d	x19, v26[1]
	mov.d	x20, v10[1]
	sdiv	x20, x20, x19
	fmov	x21, d26
	fmov	x22, d10
	sdiv	x22, x22, x21
	mul	x21, x22, x21
	fmov	d7, x22
	mov.d	v7[1], x20
	mov.d	x22, v12[1]
	mov.d	x23, v18[1]
	fmov	x24, d12
	fmov	x25, d18
	sdiv	x25, x25, x24
	mul	x24, x25, x24
	fmov	d26, x25
	sdiv	x23, x23, x22
	mov.d	v26[1], x23
	mul	x19, x20, x19
	fmov	d27, x21
	mov.d	v27[1], x19
	mul	x19, x23, x22
	fmov	d31, x24
	mov.d	v31[1], x19
	addv.8b	b5, v5
	mul	x2, x3, x2
	fmov	d8, x4
	mov.d	v8[1], x2
	mul	x2, x6, x5
	fmov	d9, x7
	mov.d	v9[1], x2
	sub.2d	v9, v11, v9
	sub.2d	v19, v19, v8
	sub.2d	v18, v18, v31
	sub.2d	v27, v10, v27
	ldr	q31, [sp, #19760]
	ldr	q8, [sp, #19744]
	ldr	q10, [sp, #19728]
	ldr	q11, [sp, #19712]
	add.2d	v26, v11, v26
	add.2d	v7, v10, v7
	add.2d	v4, v8, v4
	add.2d	v3, v31, v3
	mov	w2, #17                         ; =0x11
	dup.2d	v31, x2
	cmhi.2d	v8, v31, v3
	cmhi.2d	v10, v31, v4
	uzp1.4s	v8, v10, v8
	cmhi.2d	v10, v31, v7
	cmhi.2d	v31, v31, v26
	uzp1.4s	v31, v31, v10
	uzp1.8h	v31, v31, v8
	ldr	q8, [sp, #19424]
	ldr	q10, [sp, #19440]
	ldr	q11, [sp, #19392]
	ldr	q12, [sp, #19408]
	add.2d	v27, v12, v27
	add.2d	v18, v11, v18
	add.2d	v19, v10, v19
	mov.d	x2, v7[1]
	fmov	x3, d7
	add	x3, x3, x3, lsl #6
	fmov	d7, x3
	add	x2, x2, x2, lsl #6
	mov.d	v7[1], x2
	mov.d	x2, v26[1]
	fmov	x3, d26
	add	x3, x3, x3, lsl #6
	fmov	d26, x3
	add	x2, x2, x2, lsl #6
	mov.d	v26[1], x2
	add.2d	v8, v8, v9
	mov.d	x2, v3[1]
	fmov	x3, d3
	add	x3, x3, x3, lsl #6
	fmov	d3, x3
	add	x2, x2, x2, lsl #6
	mov.d	v3[1], x2
	mov.d	x2, v4[1]
	fmov	x3, d4
	add	x3, x3, x3, lsl #6
	fmov	d4, x3
	add	x2, x2, x2, lsl #6
	mov.d	v4[1], x2
	mov	w2, #65                         ; =0x41
	dup.2d	v9, x2
	add.2d	v4, v4, v8
	add.2d	v3, v3, v19
	add.2d	v26, v26, v18
	add.2d	v7, v7, v27
	cmhi.2d	v19, v9, v19
	cmhi.2d	v8, v9, v8
	uzp1.4s	v19, v8, v19
	cmhi.2d	v27, v9, v27
	cmhi.2d	v18, v9, v18
	uzp1.4s	v18, v18, v27
	uzp1.8h	v18, v18, v19
	and.16b	v18, v31, v18
	xtn.8b	v10, v18
	ldr	q18, [sp, #16736]
	ldr	q19, [sp, #16752]
	ldr	q27, [sp, #16704]
	ldr	q31, [sp, #16720]
	bif.16b	v7, v31, v30
	bsl.16b	v21, v26, v27
	bif.16b	v3, v19, v17
	bif.16b	v4, v18, v16
	shl.2d	v16, v0, #5
	shl.2d	v17, v13, #5
	fmov	w2, s5
	str	q4, [sp, #16736]
	str	q3, [sp, #16752]
	str	q21, [sp, #16704]
	str	q7, [sp, #16720]
	shl.2d	v3, v14, #5
	shl.2d	v4, v15, #5
	ldp	q0, q1, [sp, #384]              ; 32-byte Folded Reload
	ldr	q7, [sp, #640]                  ; 16-byte Folded Reload
	add.2d	v7, v1, v7
	add.2d	v26, v7, v16
	ldr	q7, [sp, #624]                  ; 16-byte Folded Reload
	add.2d	v7, v0, v7
	add.2d	v21, v7, v17
	ldp	q0, q1, [sp, #352]              ; 32-byte Folded Reload
	ldr	q7, [sp, #608]                  ; 16-byte Folded Reload
	add.2d	v7, v1, v7
	add.2d	v19, v7, v3
	ldr	q3, [sp, #592]                  ; 16-byte Folded Reload
	add.2d	v3, v0, v3
	add.2d	v18, v3, v4
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	str	q23, [sp, #1520]                ; 16-byte Folded Spill
	tbz	w2, #0, LBB0_992
; %bb.991:                              ; %cond.load5448
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d26
	ldr	s16, [x3]
LBB0_992:                               ; %else5452
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #1, LBB0_994
; %bb.993:                              ; %cond.load5454
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v26[1]
	ld1.s	{ v16 }[1], [x3]
LBB0_994:                               ; %else5458
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v0, v22
	mov.16b	v14, v28
	ldr	q9, [sp, #1504]                 ; 16-byte Folded Reload
	ldr	q25, [sp, #1168]                ; 16-byte Folded Reload
	ldr	q11, [sp, #1568]                ; 16-byte Folded Reload
	ldr	q12, [sp, #1536]                ; 16-byte Folded Reload
	mov.16b	v31, v6
	ldr	q3, [sp, #1344]                 ; 16-byte Folded Reload
	ldr	q13, [sp, #1456]                ; 16-byte Folded Reload
	ldr	q29, [sp, #1472]                ; 16-byte Folded Reload
	ldr	q1, [sp, #1280]                 ; 16-byte Folded Reload
	ldr	q28, [sp, #1408]                ; 16-byte Folded Reload
	ldr	q6, [sp, #1552]                 ; 16-byte Folded Reload
	ldr	q22, [sp, #1232]                ; 16-byte Folded Reload
	ldr	q23, [sp, #1392]                ; 16-byte Folded Reload
	ldr	q24, [sp, #1376]                ; 16-byte Folded Reload
	tbz	w2, #2, LBB0_1000
; %bb.995:                              ; %cond.load5460
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d21
	ld1.s	{ v16 }[2], [x3]
	tbnz	w2, #3, LBB0_1001
LBB0_996:                               ; %else5470
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #4, LBB0_1002
LBB0_997:                               ; %cond.load5472
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d19
	ld1.s	{ v17 }[0], [x3]
	tbnz	w2, #5, LBB0_1003
LBB0_998:                               ; %else5482
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #6, LBB0_1004
LBB0_999:                               ; %cond.load5484
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x3, d18
	ld1.s	{ v17 }[2], [x3]
	str	q3, [sp, #1344]                 ; 16-byte Folded Spill
	str	q1, [sp, #1280]                 ; 16-byte Folded Spill
	tbnz	w2, #7, LBB0_1005
	b	LBB0_1006
LBB0_1000:                              ; %else5464
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #3, LBB0_996
LBB0_1001:                              ; %cond.load5466
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v21[1]
	ld1.s	{ v16 }[3], [x3]
	tbnz	w2, #4, LBB0_997
LBB0_1002:                              ; %else5476
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w2, #5, LBB0_998
LBB0_1003:                              ; %cond.load5478
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x3, v19[1]
	ld1.s	{ v17 }[1], [x3]
	tbnz	w2, #6, LBB0_999
LBB0_1004:                              ; %else5488
                                        ;   in Loop: Header=BB0_8 Depth=3
	str	q3, [sp, #1344]                 ; 16-byte Folded Spill
	str	q1, [sp, #1280]                 ; 16-byte Folded Spill
	tbz	w2, #7, LBB0_1006
LBB0_1005:                              ; %cond.load5490
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v18[1]
	ld1.s	{ v17 }[3], [x2]
LBB0_1006:                              ; %else5494
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q3, [sp, #16688]
	ldr	q4, [sp, #16672]
	zip1.8b	v7, v20, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	bit.16b	v4, v16, v7
	zip2.8b	v7, v20, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	bit.16b	v3, v17, v7
	str	q3, [sp, #16688]
	str	q4, [sp, #16672]
	and.8b	v21, v20, v10
	shl.8b	v3, v21, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w2, s4
	umaxv.8b	b3, v3
	fmov	w3, s3
	str	q6, [sp, #1552]                 ; 16-byte Folded Spill
	tbz	w3, #0, LBB0_1010
; %bb.1007:                             ; %else5494
                                        ;   in Loop: Header=BB0_8 Depth=3
	bic.8b	v10, v20, v10
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	tst	w3, #0xff
	b.eq	LBB0_1010
; %bb.1008:                             ; %varying.divergent999
                                        ;   in Loop: Header=BB0_8 Depth=3
	subs	w1, w0, #1
	csel	w1, wzr, w1, lo
	and	w2, w16, #0xff
	lsr	w3, w2, w1
	tst	w3, #0x1
	str	q24, [sp, #5152]
	str	q12, [sp, #5168]
	and	x1, x1, #0x7
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #1056
	ldr	w1, [x3, x1, lsl #2]
	ccmp	w0, #0, #4, ne
	ccmp	w1, #19, #0, ne
	cset	w1, ne
	cmp	w2, #255
	b.ne	LBB0_4
; %bb.1009:                             ; %varying.divergent999
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbnz	w1, #0, LBB0_1086
	b	LBB0_4
LBB0_1010:                              ; %varying.coherent1000
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1037
; %bb.1011:                             ; %varying.coherent.true1005
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbnz	w1, #0, LBB0_1063
; %bb.1012:                             ; %schedule.50.thread
                                        ;   in Loop: Header=BB0_8 Depth=3
	ldr	q3, [sp, #16752]
	ldr	q4, [sp, #16736]
	ldr	q7, [sp, #16720]
	ldr	q17, [sp, #16704]
	ldr	q16, [sp, #16688]
	ldr	q19, [sp, #16672]
	shl.2d	v26, v17, #2
	shl.2d	v7, v7, #2
	shl.2d	v4, v4, #2
	dup.2d	v27, x11
	shl.2d	v3, v3, #2
	add.2d	v17, v27, v3
	add.2d	v18, v27, v4
	add.2d	v21, v27, v7
	add.2d	v26, v27, v26
	fmov	w1, s5
	tbz	w1, #0, LBB0_1020
; %bb.1013:                             ; %cond.store6022
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d26
	str	s19, [x2]
	tbnz	w1, #1, LBB0_1021
LBB0_1014:                              ; %else6029
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #2, LBB0_1022
LBB0_1015:                              ; %cond.store6030
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d21
	st1.s	{ v19 }[2], [x2]
	tbnz	w1, #3, LBB0_1023
LBB0_1016:                              ; %else6037
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #4, LBB0_1024
LBB0_1017:                              ; %cond.store6038
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d18
	str	s16, [x2]
	tbnz	w1, #5, LBB0_1025
LBB0_1018:                              ; %else6045
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #6, LBB0_1026
LBB0_1019:                              ; %cond.store6046
                                        ;   in Loop: Header=BB0_8 Depth=3
	fmov	x2, d17
	st1.s	{ v16 }[2], [x2]
	tbz	w1, #7, LBB0_1038
	b	LBB0_1027
LBB0_1020:                              ; %else6025
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #1, LBB0_1014
LBB0_1021:                              ; %cond.store6026
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v26[1]
	st1.s	{ v19 }[1], [x2]
	tbnz	w1, #2, LBB0_1015
LBB0_1022:                              ; %else6033
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #3, LBB0_1016
LBB0_1023:                              ; %cond.store6034
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v21[1]
	st1.s	{ v19 }[3], [x2]
	tbnz	w1, #4, LBB0_1017
LBB0_1024:                              ; %else6041
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #5, LBB0_1018
LBB0_1025:                              ; %cond.store6042
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x2, v18[1]
	st1.s	{ v16 }[1], [x2]
	tbnz	w1, #6, LBB0_1019
LBB0_1026:                              ; %else6049
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbz	w1, #7, LBB0_1038
LBB0_1027:                              ; %cond.store6050
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.d	x1, v17[1]
	st1.s	{ v16 }[3], [x1]
	b	LBB0_1038
LBB0_1028:                              ; %varying.coherent.false992
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1063
LBB0_1029:                              ; %schedule.52
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v8, v22
	mov.16b	v10, v9
	mov.16b	v9, v14
	mov.16b	v6, v31
	ldr	q22, [sp, #576]                 ; 16-byte Folded Reload
	cbz	w0, LBB0_1034
; %bb.1030:                             ; %convergence.cascade1027.preheader
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
LBB0_1031:                              ; %convergence.cascade1027
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_3 Depth=2
                                        ;       Parent Loop BB0_8 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w2, s4
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	str	q24, [sp, #5344]
	str	q12, [sp, #5360]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #1, lsl #12             ; =4096
	add	x6, x6, #1248
	ldr	w6, [x6, x2]
	cmp	w6, #18
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #1520
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s5, w19
	ubfx	w19, w20, #1, #1
	mov.b	v5[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v5[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v5[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v5[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v5[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v5[6], w19
	add	x19, sp, #18, lsl #12           ; =73728
	add	x19, x19, #1512
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s3, w21
	ubfx	w21, w20, #1, #1
	mov.b	v3[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v3[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v3[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v3[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v3[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v3[6], w21
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	orr.8b	v4, v20, v3
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	and.8b	v7, v1, v5
	eor.8b	v7, v7, v4
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v4, v7
	dup.8b	v17, w7
	bit.8b	v3, v16, v17
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x19, w3, sxtw]
	bic.8b	v3, v5, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v4, v5, v4
	str	q23, [sp, #5312]
	str	q11, [sp, #5328]
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #1216
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v20, v4, v3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_1035
; %bb.1032:                             ; %convergence.cascade1027
                                        ;   in Loop: Header=BB0_1031 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_1035
; %bb.1033:                             ; %convergence.cascade1027
                                        ;   in Loop: Header=BB0_1031 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_1031
	b	LBB0_1035
LBB0_1034:                              ; %schedule.52.convergence.cascade.exit1028_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_1035:                              ; %convergence.cascade.exit1028
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1049
; %bb.1036:                             ; %convergence.target.52.ready
                                        ;   in Loop: Header=BB0_8 Depth=3
	rbit	w1, w2
	clz	w1, w1
	ldp	q3, q1, [sp, #624]              ; 32-byte Folded Reload
	str	q1, [sp, #5248]
	str	q3, [sp, #5264]
	ldp	q3, q1, [sp, #592]              ; 32-byte Folded Reload
	str	q1, [sp, #5280]
	str	q3, [sp, #5296]
	and	x2, x1, #0x7
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #1152
	ldr	x2, [x3, x2, lsl #3]
	lsl	w1, w1, #2
	add	x3, sp, #4, lsl #12             ; =16384
	add	x3, x3, #3432
	sub	x1, x2, x1
	add	x1, x1, x3
	ldp	q4, q3, [x1, #992]
	ldr	q5, [x1, #2032]
	ldr	q7, [x1, #2016]
	ldr	q16, [x1, #3056]
	ldr	q17, [x1, #3040]
	ldr	q18, [x1, #4080]
	ldr	q19, [x1, #4064]
	movi.8b	v21, #1
	and.8b	v21, v20, v21
	ushll.8h	v21, v21, #0
	ushll.4s	v26, v21, #0
	ushll2.4s	v21, v21, #0
	uaddw2.2d	v25, v25, v21
	uaddw.2d	v22, v22, v21
	str	q22, [sp, #576]                 ; 16-byte Folded Spill
	ldr	q1, [sp, #736]                  ; 16-byte Folded Reload
	uaddw2.2d	v1, v1, v26
	str	q1, [sp, #736]                  ; 16-byte Folded Spill
	ldr	q1, [sp, #752]                  ; 16-byte Folded Reload
	uaddw.2d	v1, v1, v26
	str	q1, [sp, #752]                  ; 16-byte Folded Spill
	ldr	q21, [sp, #19696]
	ldr	q26, [sp, #19680]
	zip1.8b	v27, v20, v0
	ushll.4s	v27, v27, #0
	shl.4s	v27, v27, #31
	cmlt.4s	v27, v27, #0
	bif.16b	v4, v26, v27
	zip2.8b	v26, v20, v0
	ushll.4s	v26, v26, #0
	shl.4s	v26, v26, #31
	cmlt.4s	v26, v26, #0
	bif.16b	v3, v21, v26
	str	q3, [sp, #19696]
	str	q4, [sp, #19680]
	ldr	q3, [sp, #19664]
	ldr	q4, [sp, #19648]
	bit.16b	v4, v7, v27
	bit.16b	v3, v5, v26
	str	q3, [sp, #19664]
	str	q4, [sp, #19648]
	ldr	q3, [sp, #19632]
	ldr	q4, [sp, #19616]
	bit.16b	v4, v17, v27
	bit.16b	v3, v16, v26
	str	q3, [sp, #19632]
	str	q4, [sp, #19616]
	ldr	q3, [sp, #19600]
	ldr	q4, [sp, #19584]
	bit.16b	v4, v19, v27
	bit.16b	v3, v18, v26
	str	q3, [sp, #19600]
	str	q4, [sp, #19584]
	mov.16b	v31, v6
	mov.16b	v14, v9
	mov.16b	v9, v10
	mov.16b	v22, v8
	b	LBB0_163
LBB0_1037:                              ; %varying.coherent.false1006
                                        ;   in Loop: Header=BB0_8 Depth=3
	tbnz	w1, #0, LBB0_1063
LBB0_1038:                              ; %schedule.51
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov.16b	v6, v31
	cbz	w0, LBB0_1043
; %bb.1039:                             ; %convergence.cascade1009.preheader
                                        ;   in Loop: Header=BB0_8 Depth=3
	mov	w1, #0                          ; =0x0
LBB0_1040:                              ; %convergence.cascade1009
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_3 Depth=2
                                        ;       Parent Loop BB0_8 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w2, s4
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	str	q24, [sp, #5216]
	str	q12, [sp, #5232]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #1, lsl #12             ; =4096
	add	x6, x6, #1120
	ldr	w6, [x6, x2]
	cmp	w6, #19
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #1520
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s5, w19
	ubfx	w19, w20, #1, #1
	mov.b	v5[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v5[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v5[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v5[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v5[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v5[6], w19
	add	x19, sp, #18, lsl #12           ; =73728
	add	x19, x19, #1512
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s3, w21
	ubfx	w21, w20, #1, #1
	mov.b	v3[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v3[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v3[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v3[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v3[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v3[6], w21
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	orr.8b	v4, v20, v3
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	and.8b	v7, v1, v5
	eor.8b	v7, v7, v4
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v4, v7
	dup.8b	v17, w7
	bit.8b	v3, v16, v17
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x19, w3, sxtw]
	bic.8b	v3, v5, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v4, v5, v4
	str	q23, [sp, #5184]
	str	q11, [sp, #5200]
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #1088
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v20, v4, v3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_1044
; %bb.1041:                             ; %convergence.cascade1009
                                        ;   in Loop: Header=BB0_1040 Depth=4
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_1044
; %bb.1042:                             ; %convergence.cascade1009
                                        ;   in Loop: Header=BB0_1040 Depth=4
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_1040
	b	LBB0_1044
LBB0_1043:                              ; %schedule.51.convergence.cascade.exit1010_crit_edge
                                        ;   in Loop: Header=BB0_8 Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_1044:                              ; %convergence.cascade.exit1010
                                        ;   in Loop: Header=BB0_8 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_1046
; %bb.1045:                             ; %convergence.target.51.ready
                                        ;   in Loop: Header=BB0_8 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v20, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v4, v3, #0
	ushll2.4s	v3, v3, #0
	ldp	q7, q5, [sp, #816]              ; 32-byte Folded Reload
	uaddw2.2d	v1, v7, v3
	uaddw.2d	v5, v5, v3
	stp	q1, q5, [sp, #816]              ; 32-byte Folded Spill
	ldp	q3, q5, [sp, #784]              ; 32-byte Folded Reload
	uaddw2.2d	v1, v5, v4
	uaddw.2d	v3, v3, v4
	stp	q3, q1, [sp, #784]              ; 32-byte Folded Spill
	b	LBB0_981
LBB0_1046:                              ;   in Loop: Header=BB0_3 Depth=2
	mov.16b	v31, v6
	b	LBB0_1063
LBB0_1047:                              ;   in Loop: Header=BB0_3 Depth=2
	ldr	q31, [sp, #1456]                ; 16-byte Folded Reload
	b	LBB0_1063
LBB0_1048:                              ;   in Loop: Header=BB0_3 Depth=2
	mov.16b	v31, v25
	mov.16b	v25, v29
	mov.16b	v29, v14
	mov.16b	v0, v22
	mov.16b	v22, v15
	mov.16b	v14, v9
	mov.16b	v9, v28
	ldr	q28, [sp, #1408]                ; 16-byte Folded Reload
	b	LBB0_1063
LBB0_1049:                              ;   in Loop: Header=BB0_3 Depth=2
	mov.16b	v31, v6
	mov.16b	v14, v9
	mov.16b	v9, v10
	mov.16b	v22, v8
	b	LBB0_1063
LBB0_1050:                              ;   in Loop: Header=BB0_3 Depth=2
	mov.16b	v31, v6
	mov.16b	v29, v10
	b	LBB0_1063
LBB0_1051:                              ; %varying.coherent.false
                                        ;   in Loop: Header=BB0_3 Depth=2
	tst	w1, #0xff
	b.eq	LBB0_1064
; %bb.1052:                             ; %schedule.53
                                        ;   in Loop: Header=BB0_3 Depth=2
	mov.16b	v21, v1
	cbz	w0, LBB0_1066
LBB0_1053:                              ; %convergence.cascade1056.preheader
                                        ;   in Loop: Header=BB0_3 Depth=2
	mov	w1, #0                          ; =0x0
LBB0_1054:                              ; %convergence.cascade1056
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_3 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w2, s4
	umaxv.8b	b3, v3
	fmov	w5, s3
	sub	w3, w0, #1
	tst	w2, #0xff
	csel	w3, w3, wzr, ne
	mov	w2, #1                          ; =0x1
	lsl	w4, w2, w3
	and	w2, w4, w16
	tst	w2, #0xff
	cset	w7, ne
	str	q24, [sp, #16624]
	str	q12, [sp, #16640]
	ubfiz	x2, x3, #2, #3
	add	x6, sp, #4, lsl #12             ; =16384
	add	x6, x6, #240
	ldr	w6, [x6, x2]
	cmp	w6, #0
	cset	w6, eq
	and	w7, w7, w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #1520
	ldrb	w20, [x5, w3, sxtw]
	and	w19, w20, #0x1
	fmov	s5, w19
	ubfx	w19, w20, #1, #1
	mov.b	v5[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v5[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v5[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v5[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v5[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v5[6], w19
	add	x19, sp, #18, lsl #12           ; =73728
	add	x19, x19, #1512
	lsr	w20, w20, #7
	mov.b	v5[7], w20
	ldrb	w20, [x19, w3, sxtw]
	and	w21, w20, #0x1
	fmov	s3, w21
	ubfx	w21, w20, #1, #1
	mov.b	v3[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v3[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v3[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v3[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v3[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v3[6], w21
	lsr	w20, w20, #7
	mov.b	v3[7], w20
	orr.8b	v4, v20, v3
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	and.8b	v7, v1, v5
	eor.8b	v7, v7, v4
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b7, v7
	fmov	w20, s7
	ands	w6, w7, w6
	csetm	w7, ne
	bics	w20, w6, w20
	csetm	w21, ne
	dup.8b	v7, w21
	bic.8b	v16, v4, v7
	dup.8b	v17, w7
	bit.8b	v3, v16, v17
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x19, w3, sxtw]
	bic.8b	v3, v5, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w3, sxtw]
	mov	w3, #-1                         ; =0xffffffff
	csinv	w3, w3, w4, eq
	and	w16, w3, w16
	dup.8b	v3, w6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v5, w20
	and.8b	v4, v5, v4
	str	q23, [sp, #16592]
	str	q11, [sp, #16608]
	add	x3, sp, #4, lsl #12             ; =16384
	add	x3, x3, #208
	ldr	w2, [x3, x2]
	csel	w0, w2, w0, ne
	bit.8b	v20, v4, v3
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	cmp	w6, #1
	b.ne	LBB0_1067
; %bb.1055:                             ; %convergence.cascade1056
                                        ;   in Loop: Header=BB0_1054 Depth=3
	cmp	w0, #0
	ccmp	w1, #6, #2, ne
	b.hi	LBB0_1067
; %bb.1056:                             ; %convergence.cascade1056
                                        ;   in Loop: Header=BB0_1054 Depth=3
	add	w1, w1, #1
	tst	w2, #0xff
	b.ne	LBB0_1054
	b	LBB0_1067
LBB0_1057:                              ;   in Loop: Header=BB0_3 Depth=2
	ldr	q1, [sp, #1232]                 ; 16-byte Folded Reload
	ldr	q14, [sp, #1440]                ; 16-byte Folded Reload
	ldr	q9, [sp, #1504]                 ; 16-byte Folded Reload
	mov.16b	v11, v22
	mov.16b	v22, v1
	mov.16b	v24, v29
	b	LBB0_1060
LBB0_1058:                              ;   in Loop: Header=BB0_3 Depth=2
	ldr	q22, [sp, #1232]                ; 16-byte Folded Reload
	ldr	q14, [sp, #1440]                ; 16-byte Folded Reload
	ldr	q9, [sp, #1504]                 ; 16-byte Folded Reload
	mov.16b	v11, v23
	mov.16b	v23, v24
	mov.16b	v24, v8
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	ldr	q13, [sp, #1456]                ; 16-byte Folded Reload
	b	LBB0_1063
LBB0_1059:                              ;   in Loop: Header=BB0_3 Depth=2
	ldr	q22, [sp, #1232]                ; 16-byte Folded Reload
	ldr	q14, [sp, #1440]                ; 16-byte Folded Reload
	ldr	q9, [sp, #1504]                 ; 16-byte Folded Reload
	mov.16b	v11, v23
	mov.16b	v23, v29
LBB0_1060:                              ; %scheduler.loop.backedge.loopexit
                                        ;   in Loop: Header=BB0_3 Depth=2
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	ldr	q29, [sp, #1472]                ; 16-byte Folded Reload
	ldr	q13, [sp, #1456]                ; 16-byte Folded Reload
	b	LBB0_1063
LBB0_1061:                              ;   in Loop: Header=BB0_3 Depth=2
	ldr	q22, [sp, #1232]                ; 16-byte Folded Reload
	ldr	q9, [sp, #1504]                 ; 16-byte Folded Reload
	mov.16b	v11, v29
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	ldr	q29, [sp, #1472]                ; 16-byte Folded Reload
	ldr	q13, [sp, #1456]                ; 16-byte Folded Reload
	ldr	q14, [sp, #1440]                ; 16-byte Folded Reload
	b	LBB0_1063
LBB0_1062:                              ;   in Loop: Header=BB0_3 Depth=2
	ldr	q22, [sp, #1232]                ; 16-byte Folded Reload
	ldr	q14, [sp, #1440]                ; 16-byte Folded Reload
	ldr	q4, [sp, #1504]                 ; 16-byte Folded Reload
	mov.16b	v11, v1
	ldr	q0, [sp, #1488]                 ; 16-byte Folded Reload
	ldr	q29, [sp, #1472]                ; 16-byte Folded Reload
	mov.16b	v13, v9
	mov.16b	v9, v4
LBB0_1063:                              ; %scheduler.loop.backedge.loopexit
                                        ;   in Loop: Header=BB0_3 Depth=2
	mov.16b	v6, v22
	mov.16b	v8, v25
	mov.16b	v30, v14
	ldr	q27, [sp, #1520]                ; 16-byte Folded Reload
	ldr	q26, [sp, #1552]                ; 16-byte Folded Reload
	ldr	q25, [sp, #1328]                ; 16-byte Folded Reload
	ldp	q22, q1, [sp, #736]             ; 32-byte Folded Reload
LBB0_1064:                              ; %scheduler.loop.backedge
                                        ;   in Loop: Header=BB0_3 Depth=2
	cbnz	x17, LBB0_3
	b	LBB0_1084
LBB0_1065:                              ; %schedule.53.loopexit
                                        ;   in Loop: Header=BB0_3 Depth=2
	mov.16b	v6, v22
	mov.16b	v8, v25
	mov.16b	v30, v14
	ldr	q27, [sp, #1520]                ; 16-byte Folded Reload
	ldr	q26, [sp, #1552]                ; 16-byte Folded Reload
	ldr	q25, [sp, #1328]                ; 16-byte Folded Reload
	ldp	q22, q1, [sp, #736]             ; 32-byte Folded Reload
	mov.16b	v21, v1
	cbnz	w0, LBB0_1053
LBB0_1066:                              ; %schedule.53.convergence.cascade.exit1057_crit_edge
                                        ;   in Loop: Header=BB0_3 Depth=2
	shl.8b	v3, v20, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
LBB0_1067:                              ; %convergence.cascade.exit1057
                                        ;   in Loop: Header=BB0_3 Depth=2
	tst	w2, #0xff
	b.ne	LBB0_1069
; %bb.1068:                             ;   in Loop: Header=BB0_3 Depth=2
	mov.16b	v1, v21
	cbnz	x17, LBB0_3
	b	LBB0_1084
LBB0_1069:                              ; %convergence.target.53.ready
                                        ;   in Loop: Header=BB0_2 Depth=1
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	bic.8b	v1, v1, v20
	str	d1, [sp, #1592]                 ; 8-byte Folded Spill
	tst	w16, #0xff
	b.eq	LBB0_1082
; %bb.1070:                             ; %return.frame.cleanup
                                        ;   in Loop: Header=BB0_2 Depth=1
	ldrb	w0, [x8, #8]
	and	w1, w0, #0x1
	fmov	s3, w1
	ubfx	w1, w0, #1, #1
	mov.b	v3[1], w1
	ubfx	w1, w0, #2, #1
	mov.b	v3[2], w1
	ubfx	w1, w0, #3, #1
	mov.b	v3[3], w1
	ubfx	w1, w0, #4, #1
	mov.b	v3[4], w1
	ubfx	w1, w0, #5, #1
	mov.b	v3[5], w1
	ubfx	w1, w0, #6, #1
	mov.b	v3[6], w1
	lsr	w0, w0, #7
	mov.b	v3[7], w0
	ldrb	w0, [x8]
	and	w1, w0, #0x1
	fmov	s4, w1
	ubfx	w1, w0, #1, #1
	mov.b	v4[1], w1
	ubfx	w1, w0, #2, #1
	mov.b	v4[2], w1
	ubfx	w1, w0, #3, #1
	mov.b	v4[3], w1
	ubfx	w1, w0, #4, #1
	mov.b	v4[4], w1
	ubfx	w1, w0, #5, #1
	mov.b	v4[5], w1
	ubfx	w1, w0, #6, #1
	mov.b	v4[6], w1
	lsr	w0, w0, #7
	mov.b	v4[7], w0
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	and.8b	v3, v1, v3
	eor.8b	v5, v4, v3
	shl.8b	v5, v5, #7
	cmlt.8b	v16, v5, #0
	umaxv.8b	b5, v16
	fmov	w0, s5
	eor	w0, w0, #0x1
	and	w1, w16, w0
	dup.8b	v5, w1
	and.8b	v5, v5, v4
	shl.8b	v7, v5, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b17, v7
	fmov	w0, s17
	tst	w1, #0x1
	csetm	w1, ne
	dup.8b	v7, w1
	bic.8b	v3, v3, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8, #8]
	bic.8b	v3, v4, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x8]
	cmp	x17, #8
	ldp	q19, q18, [sp, #816]            ; 32-byte Folded Reload
	ldr	q20, [sp, #1024]                ; 16-byte Folded Reload
	b.lo	LBB0_1072
; %bb.1071:                             ; %return.frame.cleanup
                                        ;   in Loop: Header=BB0_2 Depth=1
	tst	w0, #0xff
	b.ne	LBB0_1086
LBB0_1072:                              ; %ready.overflow.resume1078
                                        ;   in Loop: Header=BB0_2 Depth=1
	fmov	s3, wzr
	and.8b	v4, v16, v2
	addv.8b	b4, v4
	fmov	w1, s4
	cmeq.8b	v3, v17, v3
	mvn.8b	v3, v3
	umov.b	w2, v3[0]
	sbfx	w3, w2, #0, #1
	fmov	s16, w3
	sbfx	w3, w2, #1, #1
	mov.b	v16[1], w3
	sbfx	w3, w2, #2, #1
	mov.b	v16[2], w3
	sbfx	w3, w2, #3, #1
	mov.b	v16[3], w3
	sbfx	w3, w2, #4, #1
	mov.b	v16[4], w3
	sbfx	w3, w2, #5, #1
	mov.b	v16[5], w3
	sbfx	w3, w2, #6, #1
	mov.b	v16[6], w3
	sbfx	w2, w2, #7, #1
	mov.b	v16[7], w2
	and	w2, w16, #0xfffffffe
	tst	w1, #0xff
	csel	w1, w2, w16, eq
	sxtw	x16, w17
	tst	w0, #0xff
	csel	x2, x16, xzr, ne
	add	x16, sp, #18, lsl #12           ; =73728
	add	x16, x16, #1592
	ldrb	w0, [x16, x2]
	and	w3, w0, #0x1
	fmov	s3, w3
	ubfx	w3, w0, #1, #1
	mov.b	v3[1], w3
	ubfx	w3, w0, #2, #1
	mov.b	v3[2], w3
	ubfx	w3, w0, #3, #1
	mov.b	v3[3], w3
	ubfx	w3, w0, #4, #1
	mov.b	v3[4], w3
	ubfx	w3, w0, #5, #1
	mov.b	v3[5], w3
	ubfx	w3, w0, #6, #1
	mov.b	v3[6], w3
	lsr	w0, w0, #7
	mov.b	v3[7], w0
	bit.8b	v3, v5, v16
	fmov	w3, s24
Lloh1402:
	adrp	x0, l_convergence.targets@PAGE
Lloh1403:
	add	x0, x0, l_convergence.targets@PAGEOFF
	add	x4, x0, w3, sxtw #2
	fmov	w5, s23
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x16, x2]
	lsl	x6, x2, #2
	add	x3, sp, #18, lsl #12            ; =73728
	add	x3, x3, #1560
	add	x2, x3, x6
	csel	x4, x4, x2, ne
	ldr	w4, [x4]
	str	w4, [x2]
	add	x2, sp, #18, lsl #12            ; =73728
	add	x2, x2, #1528
	ldr	w4, [x2, x6]
	csel	w4, w5, w4, ne
	str	w4, [x2, x6]
	cinc	w17, w17, ne
	and	w4, w1, #0x2
	ldrb	w5, [x8, #9]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	ldrb	w5, [x8, #1]
	and	w6, w5, #0x1
	fmov	s4, w6
	ubfx	w6, w5, #1, #1
	mov.b	v4[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v4[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v4[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v4[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v4[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v4[6], w6
	lsr	w5, w5, #7
	mov.b	v4[7], w5
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	and.8b	v3, v1, v3
	eor.8b	v5, v4, v3
	shl.8b	v5, v5, #7
	cmlt.8b	v16, v5, #0
	umaxv.8b	b5, v16
	fmov	w5, s5
	eor	w5, w5, #0x1
	ands	w4, w5, w4, lsr #1
	dup.8b	v5, w4
	and.8b	v5, v5, v4
	shl.8b	v7, v5, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b17, v7
	fmov	w4, s17
	csetm	w5, ne
	dup.8b	v7, w5
	bic.8b	v3, v3, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	stur	b3, [x8, #9]
	bic.8b	v3, v4, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	stur	b3, [x8, #1]
	cmp	w17, #8
	and	w5, w4, #0xff
	ccmp	w5, #0, #4, hs
	b.ne	LBB0_1086
; %bb.1073:                             ; %ready.overflow.resume1084
                                        ;   in Loop: Header=BB0_2 Depth=1
	fmov	s3, wzr
	and.8b	v4, v16, v2
	cmeq.8b	v3, v17, v3
	mvn.8b	v3, v3
	umov.b	w5, v3[0]
	addv.8b	b3, v4
	sbfx	w6, w5, #0, #1
	fmov	s16, w6
	sbfx	w6, w5, #1, #1
	mov.b	v16[1], w6
	sbfx	w6, w5, #2, #1
	mov.b	v16[2], w6
	sbfx	w6, w5, #3, #1
	mov.b	v16[3], w6
	sbfx	w6, w5, #4, #1
	mov.b	v16[4], w6
	sbfx	w6, w5, #5, #1
	mov.b	v16[5], w6
	sbfx	w6, w5, #6, #1
	mov.b	v16[6], w6
	sbfx	w5, w5, #7, #1
	mov.b	v16[7], w5
	fmov	w5, s3
	and	w6, w1, #0xfffffffd
	tst	w5, #0xff
	csel	w1, w6, w1, eq
	sxtw	x5, w17
	tst	w4, #0xff
	csel	x4, x5, xzr, ne
	ldrb	w5, [x16, x4]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	bit.8b	v3, v5, v16
	mov.s	w5, v24[1]
	add	x5, x0, w5, sxtw #2
	mov.s	w6, v23[1]
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x16, x4]
	lsl	x16, x4, #2
	add	x3, x3, x16
	csel	x4, x5, x3, ne
	ldr	w4, [x4]
	str	w4, [x3]
	ldr	w3, [x2, x16]
	csel	w3, w6, w3, ne
	str	w3, [x2, x16]
	cinc	w3, w17, ne
	and	w16, w1, #0x4
	ldrb	w17, [x8, #10]
	and	w2, w17, #0x1
	fmov	s3, w2
	ubfx	w2, w17, #1, #1
	mov.b	v3[1], w2
	ubfx	w2, w17, #2, #1
	mov.b	v3[2], w2
	ubfx	w2, w17, #3, #1
	mov.b	v3[3], w2
	ubfx	w2, w17, #4, #1
	mov.b	v3[4], w2
	ubfx	w2, w17, #5, #1
	mov.b	v3[5], w2
	ubfx	w2, w17, #6, #1
	mov.b	v3[6], w2
	lsr	w17, w17, #7
	mov.b	v3[7], w17
	ldrb	w17, [x8, #2]
	and	w2, w17, #0x1
	fmov	s4, w2
	ubfx	w2, w17, #1, #1
	mov.b	v4[1], w2
	ubfx	w2, w17, #2, #1
	mov.b	v4[2], w2
	ubfx	w2, w17, #3, #1
	mov.b	v4[3], w2
	ubfx	w2, w17, #4, #1
	mov.b	v4[4], w2
	ubfx	w2, w17, #5, #1
	mov.b	v4[5], w2
	ubfx	w2, w17, #6, #1
	mov.b	v4[6], w2
	lsr	w17, w17, #7
	mov.b	v4[7], w17
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	and.8b	v3, v1, v3
	eor.8b	v5, v4, v3
	shl.8b	v5, v5, #7
	cmlt.8b	v16, v5, #0
	umaxv.8b	b5, v16
	fmov	w17, s5
	eor	w17, w17, #0x1
	ands	w16, w17, w16, lsr #2
	dup.8b	v5, w16
	and.8b	v5, v5, v4
	shl.8b	v7, v5, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b17, v7
	fmov	w16, s17
	csetm	w17, ne
	dup.8b	v7, w17
	bic.8b	v3, v3, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	stur	b3, [x8, #10]
	bic.8b	v3, v4, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	stur	b3, [x8, #2]
	cmp	w3, #8
	and	w17, w16, #0xff
	ccmp	w17, #0, #4, hs
	b.ne	LBB0_1086
; %bb.1074:                             ; %ready.overflow.resume1090
                                        ;   in Loop: Header=BB0_2 Depth=1
	fmov	s3, wzr
	and.8b	v4, v16, v2
	addv.8b	b4, v4
	fmov	w17, s4
	cmeq.8b	v3, v17, v3
	mvn.8b	v3, v3
	umov.b	w2, v3[0]
	sbfx	w4, w2, #0, #1
	fmov	s16, w4
	sbfx	w4, w2, #1, #1
	mov.b	v16[1], w4
	sbfx	w4, w2, #2, #1
	mov.b	v16[2], w4
	sbfx	w4, w2, #3, #1
	mov.b	v16[3], w4
	sbfx	w4, w2, #4, #1
	mov.b	v16[4], w4
	sbfx	w4, w2, #5, #1
	mov.b	v16[5], w4
	sbfx	w4, w2, #6, #1
	mov.b	v16[6], w4
	sbfx	w2, w2, #7, #1
	mov.b	v16[7], w2
	and	w2, w1, #0xfffffffb
	tst	w17, #0xff
	csel	w17, w2, w1, eq
	sxtw	x1, w3
	tst	w16, #0xff
	csel	x1, x1, xzr, ne
	add	x16, sp, #18, lsl #12           ; =73728
	add	x16, x16, #1592
	ldrb	w2, [x16, x1]
	and	w4, w2, #0x1
	fmov	s3, w4
	ubfx	w4, w2, #1, #1
	mov.b	v3[1], w4
	ubfx	w4, w2, #2, #1
	mov.b	v3[2], w4
	ubfx	w4, w2, #3, #1
	mov.b	v3[3], w4
	ubfx	w4, w2, #4, #1
	mov.b	v3[4], w4
	ubfx	w4, w2, #5, #1
	mov.b	v3[5], w4
	ubfx	w4, w2, #6, #1
	mov.b	v3[6], w4
	lsr	w2, w2, #7
	mov.b	v3[7], w2
	bit.8b	v3, v5, v16
	mov.s	w2, v24[2]
	add	x4, x0, w2, sxtw #2
	mov.s	w5, v23[2]
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x16, x1]
	lsl	x6, x1, #2
	add	x2, sp, #18, lsl #12            ; =73728
	add	x2, x2, #1560
	add	x1, x2, x6
	csel	x4, x4, x1, ne
	ldr	w4, [x4]
	str	w4, [x1]
	add	x1, sp, #18, lsl #12            ; =73728
	add	x1, x1, #1528
	ldr	w4, [x1, x6]
	csel	w4, w5, w4, ne
	str	w4, [x1, x6]
	cinc	w3, w3, ne
	and	w4, w17, #0x8
	ldrb	w5, [x8, #11]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	ldrb	w5, [x8, #3]
	and	w6, w5, #0x1
	fmov	s4, w6
	ubfx	w6, w5, #1, #1
	mov.b	v4[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v4[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v4[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v4[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v4[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v4[6], w6
	lsr	w5, w5, #7
	mov.b	v4[7], w5
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	and.8b	v3, v1, v3
	eor.8b	v5, v4, v3
	shl.8b	v5, v5, #7
	cmlt.8b	v16, v5, #0
	umaxv.8b	b5, v16
	fmov	w5, s5
	eor	w5, w5, #0x1
	ands	w4, w5, w4, lsr #3
	dup.8b	v5, w4
	and.8b	v5, v5, v4
	shl.8b	v7, v5, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b17, v7
	fmov	w5, s17
	csetm	w4, ne
	dup.8b	v7, w4
	bic.8b	v3, v3, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	stur	b3, [x8, #11]
	bic.8b	v3, v4, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	stur	b3, [x8, #3]
	cmp	w3, #8
	and	w4, w5, #0xff
	ccmp	w4, #0, #4, hs
	b.ne	LBB0_1086
; %bb.1075:                             ; %ready.overflow.resume1096
                                        ;   in Loop: Header=BB0_2 Depth=1
	fmov	s3, wzr
	and.8b	v4, v16, v2
	cmeq.8b	v3, v17, v3
	mvn.8b	v3, v3
	umov.b	w4, v3[0]
	addv.8b	b3, v4
	sbfx	w6, w4, #0, #1
	fmov	s16, w6
	sbfx	w6, w4, #1, #1
	mov.b	v16[1], w6
	sbfx	w6, w4, #2, #1
	mov.b	v16[2], w6
	sbfx	w6, w4, #3, #1
	mov.b	v16[3], w6
	sbfx	w6, w4, #4, #1
	mov.b	v16[4], w6
	sbfx	w6, w4, #5, #1
	mov.b	v16[5], w6
	sbfx	w6, w4, #6, #1
	mov.b	v16[6], w6
	sbfx	w4, w4, #7, #1
	mov.b	v16[7], w4
	fmov	w4, s3
	and	w6, w17, #0xfffffff7
	tst	w4, #0xff
	csel	w4, w6, w17, eq
	sxtw	x17, w3
	tst	w5, #0xff
	csel	x17, x17, xzr, ne
	ldrb	w5, [x16, x17]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	bit.8b	v3, v5, v16
	mov.s	w5, v24[3]
	add	x5, x0, w5, sxtw #2
	mov.s	w6, v23[3]
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x16, x17]
	lsl	x16, x17, #2
	add	x17, x2, x16
	csel	x2, x5, x17, ne
	ldr	w2, [x2]
	str	w2, [x17]
	ldr	w17, [x1, x16]
	csel	w17, w6, w17, ne
	str	w17, [x1, x16]
	cinc	w17, w3, ne
	and	w16, w4, #0x10
	ldrb	w1, [x8, #12]
	and	w2, w1, #0x1
	fmov	s3, w2
	ubfx	w2, w1, #1, #1
	mov.b	v3[1], w2
	ubfx	w2, w1, #2, #1
	mov.b	v3[2], w2
	ubfx	w2, w1, #3, #1
	mov.b	v3[3], w2
	ubfx	w2, w1, #4, #1
	mov.b	v3[4], w2
	ubfx	w2, w1, #5, #1
	mov.b	v3[5], w2
	ubfx	w2, w1, #6, #1
	mov.b	v3[6], w2
	lsr	w1, w1, #7
	mov.b	v3[7], w1
	ldrb	w1, [x8, #4]
	and	w2, w1, #0x1
	fmov	s4, w2
	ubfx	w2, w1, #1, #1
	mov.b	v4[1], w2
	ubfx	w2, w1, #2, #1
	mov.b	v4[2], w2
	ubfx	w2, w1, #3, #1
	mov.b	v4[3], w2
	ubfx	w2, w1, #4, #1
	mov.b	v4[4], w2
	ubfx	w2, w1, #5, #1
	mov.b	v4[5], w2
	ubfx	w2, w1, #6, #1
	mov.b	v4[6], w2
	lsr	w1, w1, #7
	mov.b	v4[7], w1
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	and.8b	v3, v1, v3
	eor.8b	v5, v4, v3
	shl.8b	v5, v5, #7
	cmlt.8b	v16, v5, #0
	umaxv.8b	b5, v16
	fmov	w1, s5
	eor	w1, w1, #0x1
	ands	w16, w1, w16, lsr #4
	dup.8b	v5, w16
	and.8b	v5, v5, v4
	shl.8b	v7, v5, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b17, v7
	fmov	w16, s17
	csetm	w1, ne
	dup.8b	v7, w1
	bic.8b	v3, v3, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	stur	b3, [x8, #12]
	bic.8b	v3, v4, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	stur	b3, [x8, #4]
	cmp	w17, #8
	and	w1, w16, #0xff
	ccmp	w1, #0, #4, hs
	b.ne	LBB0_1086
; %bb.1076:                             ; %ready.overflow.resume1102
                                        ;   in Loop: Header=BB0_2 Depth=1
	fmov	s3, wzr
	and.8b	v4, v16, v2
	addv.8b	b4, v4
	cmeq.8b	v3, v17, v3
	mvn.8b	v3, v3
	umov.b	w1, v3[0]
	fmov	w2, s4
	sbfx	w3, w1, #0, #1
	fmov	s16, w3
	sbfx	w3, w1, #1, #1
	mov.b	v16[1], w3
	sbfx	w3, w1, #2, #1
	mov.b	v16[2], w3
	sbfx	w3, w1, #3, #1
	mov.b	v16[3], w3
	sbfx	w3, w1, #4, #1
	mov.b	v16[4], w3
	sbfx	w3, w1, #5, #1
	mov.b	v16[5], w3
	sbfx	w3, w1, #6, #1
	mov.b	v16[6], w3
	sbfx	w1, w1, #7, #1
	mov.b	v16[7], w1
	and	w1, w4, #0xffffffef
	tst	w2, #0xff
	csel	w2, w1, w4, eq
	sxtw	x1, w17
	tst	w16, #0xff
	csel	x1, x1, xzr, ne
	add	x16, sp, #18, lsl #12           ; =73728
	add	x16, x16, #1592
	ldrb	w3, [x16, x1]
	and	w4, w3, #0x1
	fmov	s3, w4
	ubfx	w4, w3, #1, #1
	mov.b	v3[1], w4
	ubfx	w4, w3, #2, #1
	mov.b	v3[2], w4
	ubfx	w4, w3, #3, #1
	mov.b	v3[3], w4
	ubfx	w4, w3, #4, #1
	mov.b	v3[4], w4
	ubfx	w4, w3, #5, #1
	mov.b	v3[5], w4
	ubfx	w4, w3, #6, #1
	mov.b	v3[6], w4
	lsr	w3, w3, #7
	mov.b	v3[7], w3
	bit.8b	v3, v5, v16
	fmov	w3, s12
	add	x4, x0, w3, sxtw #2
	fmov	w5, s11
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x16, x1]
	lsl	x6, x1, #2
	add	x3, sp, #18, lsl #12            ; =73728
	add	x3, x3, #1560
	add	x1, x3, x6
	csel	x4, x4, x1, ne
	ldr	w4, [x4]
	str	w4, [x1]
	add	x1, sp, #18, lsl #12            ; =73728
	add	x1, x1, #1528
	ldr	w4, [x1, x6]
	csel	w4, w5, w4, ne
	str	w4, [x1, x6]
	cinc	w4, w17, ne
	and	w17, w2, #0x20
	ldrb	w5, [x8, #13]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	ldrb	w5, [x8, #5]
	and	w6, w5, #0x1
	fmov	s4, w6
	ubfx	w6, w5, #1, #1
	mov.b	v4[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v4[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v4[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v4[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v4[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v4[6], w6
	lsr	w5, w5, #7
	mov.b	v4[7], w5
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	and.8b	v3, v1, v3
	eor.8b	v5, v4, v3
	shl.8b	v5, v5, #7
	cmlt.8b	v16, v5, #0
	umaxv.8b	b5, v16
	fmov	w5, s5
	eor	w5, w5, #0x1
	ands	w17, w5, w17, lsr #5
	dup.8b	v5, w17
	and.8b	v5, v5, v4
	shl.8b	v7, v5, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b17, v7
	fmov	w5, s17
	csetm	w17, ne
	dup.8b	v7, w17
	bic.8b	v3, v3, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	stur	b3, [x8, #13]
	bic.8b	v3, v4, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	stur	b3, [x8, #5]
	cmp	w4, #8
	and	w17, w5, #0xff
	ccmp	w17, #0, #4, hs
	b.ne	LBB0_1086
; %bb.1077:                             ; %ready.overflow.resume1108
                                        ;   in Loop: Header=BB0_2 Depth=1
	fmov	s3, wzr
	and.8b	v4, v16, v2
	addv.8b	b4, v4
	fmov	w17, s4
	cmeq.8b	v3, v17, v3
	mvn.8b	v3, v3
	umov.b	w6, v3[0]
	sbfx	w7, w6, #0, #1
	fmov	s16, w7
	sbfx	w7, w6, #1, #1
	mov.b	v16[1], w7
	sbfx	w7, w6, #2, #1
	mov.b	v16[2], w7
	sbfx	w7, w6, #3, #1
	mov.b	v16[3], w7
	sbfx	w7, w6, #4, #1
	mov.b	v16[4], w7
	sbfx	w7, w6, #5, #1
	mov.b	v16[5], w7
	sbfx	w7, w6, #6, #1
	mov.b	v16[6], w7
	sbfx	w6, w6, #7, #1
	mov.b	v16[7], w6
	and	w6, w2, #0xffffffdf
	tst	w17, #0xff
	csel	w17, w6, w2, eq
	sxtw	x2, w4
	tst	w5, #0xff
	csel	x2, x2, xzr, ne
	ldrb	w5, [x16, x2]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	mov.s	w5, v12[1]
	bit.8b	v3, v5, v16
	add	x5, x0, w5, sxtw #2
	mov.s	w6, v11[1]
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x16, x2]
	lsl	x16, x2, #2
	add	x2, x3, x16
	csel	x3, x5, x2, ne
	ldr	w3, [x3]
	str	w3, [x2]
	ldr	w2, [x1, x16]
	csel	w2, w6, w2, ne
	str	w2, [x1, x16]
	cinc	w16, w4, ne
	ldrb	w1, [x8, #14]
	and	w2, w1, #0x1
	fmov	s5, w2
	ubfx	w2, w1, #1, #1
	mov.b	v5[1], w2
	ubfx	w2, w1, #2, #1
	mov.b	v5[2], w2
	ubfx	w2, w1, #3, #1
	mov.b	v5[3], w2
	ubfx	w2, w1, #4, #1
	mov.b	v5[4], w2
	ubfx	w2, w1, #5, #1
	mov.b	v5[5], w2
	ubfx	w2, w1, #6, #1
	mov.b	v5[6], w2
	lsr	w1, w1, #7
	mov.b	v5[7], w1
	ldrb	w1, [x8, #6]
	and	w2, w1, #0x1
	fmov	s3, w2
	ubfx	w2, w1, #1, #1
	mov.b	v3[1], w2
	ubfx	w2, w1, #2, #1
	mov.b	v3[2], w2
	ubfx	w2, w1, #3, #1
	mov.b	v3[3], w2
	ubfx	w2, w1, #4, #1
	mov.b	v3[4], w2
	ubfx	w2, w1, #5, #1
	mov.b	v3[5], w2
	ubfx	w2, w1, #6, #1
	mov.b	v3[6], w2
	and	w2, w17, #0x40
	lsr	w1, w1, #7
	mov.b	v3[7], w1
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	and.8b	v4, v1, v5
	eor.8b	v5, v3, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v16, v5, #0
	umaxv.8b	b5, v16
	fmov	w1, s5
	eor	w1, w1, #0x1
	ands	w1, w1, w2, lsr #6
	dup.8b	v5, w1
	and.8b	v5, v5, v3
	shl.8b	v7, v5, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b17, v7
	fmov	w1, s17
	csetm	w2, ne
	dup.8b	v7, w2
	bic.8b	v4, v4, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	stur	b4, [x8, #14]
	bic.8b	v3, v3, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	stur	b3, [x8, #6]
	cmp	w16, #8
	b.lo	LBB0_1079
; %bb.1078:                             ; %ready.overflow.resume1108
                                        ;   in Loop: Header=BB0_2 Depth=1
	tst	w1, #0xff
	b.ne	LBB0_1086
LBB0_1079:                              ; %ready.overflow.resume1114
                                        ;   in Loop: Header=BB0_2 Depth=1
	fmov	s3, wzr
	and.8b	v4, v16, v2
	addv.8b	b4, v4
	fmov	w2, s4
	cmeq.8b	v3, v17, v3
	mvn.8b	v3, v3
	umov.b	w3, v3[0]
	sbfx	w4, w3, #0, #1
	fmov	s16, w4
	sbfx	w4, w3, #1, #1
	mov.b	v16[1], w4
	sbfx	w4, w3, #2, #1
	mov.b	v16[2], w4
	sbfx	w4, w3, #3, #1
	mov.b	v16[3], w4
	sbfx	w4, w3, #4, #1
	mov.b	v16[4], w4
	sbfx	w4, w3, #5, #1
	mov.b	v16[5], w4
	sbfx	w4, w3, #6, #1
	mov.b	v16[6], w4
	sbfx	w3, w3, #7, #1
	mov.b	v16[7], w3
	and	w3, w17, #0xffffffbf
	tst	w2, #0xff
	csel	w3, w3, w17, eq
	sxtw	x17, w16
	tst	w1, #0xff
	csel	x1, x17, xzr, ne
	add	x17, sp, #18, lsl #12           ; =73728
	add	x17, x17, #1592
	ldrb	w2, [x17, x1]
	and	w4, w2, #0x1
	fmov	s3, w4
	ubfx	w4, w2, #1, #1
	mov.b	v3[1], w4
	ubfx	w4, w2, #2, #1
	mov.b	v3[2], w4
	ubfx	w4, w2, #3, #1
	mov.b	v3[3], w4
	ubfx	w4, w2, #4, #1
	mov.b	v3[4], w4
	ubfx	w4, w2, #5, #1
	mov.b	v3[5], w4
	ubfx	w4, w2, #6, #1
	mov.b	v3[6], w4
	lsr	w2, w2, #7
	mov.b	v3[7], w2
	bit.8b	v3, v5, v16
	mov.s	w2, v12[2]
	add	x4, x0, w2, sxtw #2
	mov.s	w5, v11[2]
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x17, x1]
	lsl	x6, x1, #2
	add	x2, sp, #18, lsl #12            ; =73728
	add	x2, x2, #1560
	add	x1, sp, #18, lsl #12            ; =73728
	add	x1, x1, #1528
	ldr	w7, [x1, x6]
	csel	w5, w5, w7, ne
	add	x7, x2, x6
	csel	x4, x4, x7, ne
	ldr	w19, [x4]
	str	w5, [x1, x6]
	sxtb	w4, w3
	str	w19, [x7]
	cinc	w3, w16, ne
	cmp	w4, #0
	ldrb	w16, [x8, #15]
	and	w5, w16, #0x1
	fmov	s5, w5
	ubfx	w5, w16, #1, #1
	mov.b	v5[1], w5
	ubfx	w5, w16, #2, #1
	mov.b	v5[2], w5
	ubfx	w5, w16, #3, #1
	mov.b	v5[3], w5
	ubfx	w5, w16, #4, #1
	mov.b	v5[4], w5
	ubfx	w5, w16, #5, #1
	mov.b	v5[5], w5
	ubfx	w5, w16, #6, #1
	mov.b	v5[6], w5
	lsr	w16, w16, #7
	mov.b	v5[7], w16
	ldrb	w16, [x8, #7]
	and	w5, w16, #0x1
	fmov	s3, w5
	ubfx	w5, w16, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w16, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w16, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w16, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w16, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w16, #6, #1
	mov.b	v3[6], w5
	cset	w5, lt
	lsr	w16, w16, #7
	mov.b	v3[7], w16
	ldr	d1, [sp, #1592]                 ; 8-byte Folded Reload
	and.8b	v4, v1, v5
	eor.8b	v5, v3, v4
	shl.8b	v5, v5, #7
	cmlt.8b	v16, v5, #0
	umaxv.8b	b5, v16
	fmov	w16, s5
	eor	w16, w16, #0x1
	ands	w16, w5, w16
	dup.8b	v5, w16
	and.8b	v5, v5, v3
	shl.8b	v7, v5, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v2
	addv.8b	b17, v7
	fmov	w5, s17
	csetm	w16, ne
	dup.8b	v7, w16
	bic.8b	v4, v4, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	stur	b4, [x8, #15]
	bic.8b	v3, v3, v7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	stur	b3, [x8, #7]
	cmp	w3, #8
	b.lo	LBB0_1081
; %bb.1080:                             ; %ready.overflow.resume1114
                                        ;   in Loop: Header=BB0_2 Depth=1
	tst	w5, #0xff
	b.ne	LBB0_1086
LBB0_1081:                              ; %ready.overflow.resume1120
                                        ;   in Loop: Header=BB0_2 Depth=1
	fmov	s3, wzr
	cmeq.8b	v3, v17, v3
	and.8b	v4, v16, v2
	addv.8b	b4, v4
	mvn.8b	v3, v3
	umov.b	w16, v3[0]
	sbfx	w6, w16, #0, #1
	fmov	s16, w6
	sbfx	w6, w16, #1, #1
	mov.b	v16[1], w6
	sbfx	w6, w16, #2, #1
	mov.b	v16[2], w6
	sbfx	w6, w16, #3, #1
	mov.b	v16[3], w6
	sbfx	w6, w16, #4, #1
	mov.b	v16[4], w6
	sbfx	w6, w16, #5, #1
	mov.b	v16[5], w6
	sbfx	w6, w16, #6, #1
	mov.b	v16[6], w6
	fmov	w6, s4
	sbfx	w16, w16, #7, #1
	mov.b	v16[7], w16
	and	w16, w4, #0x7f
	tst	w6, #0xff
	csel	w16, w16, w4, eq
	sxtw	x4, w3
	tst	w5, #0xff
	csel	x4, x4, xzr, ne
	ldrb	w5, [x17, x4]
	and	w6, w5, #0x1
	fmov	s3, w6
	ubfx	w6, w5, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v3[6], w6
	lsr	w5, w5, #7
	mov.b	v3[7], w5
	bit.8b	v3, v5, v16
	mov.s	w5, v12[3]
	mov.s	w6, v11[3]
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x17, x4]
	add	x17, x0, w5, sxtw #2
	lsl	x0, x4, #2
	add	x2, x2, x0
	csel	x17, x17, x2, ne
	ldr	w17, [x17]
	str	w17, [x2]
	ldr	w17, [x1, x0]
	csel	w17, w6, w17, ne
	str	w17, [x1, x0]
	cinc	w17, w3, ne
	b	LBB0_1083
LBB0_1082:                              ;   in Loop: Header=BB0_2 Depth=1
	mov	w16, #0                         ; =0x0
	ldp	q19, q18, [sp, #816]            ; 32-byte Folded Reload
	ldr	q20, [sp, #1024]                ; 16-byte Folded Reload
LBB0_1083:                              ; %return.frame.cleanup.done
                                        ;   in Loop: Header=BB0_2 Depth=1
	mov.16b	v1, v21
	cbnz	w17, LBB0_2
LBB0_1084:                              ; %scheduler.done
	ldr	d0, [sp, #1592]                 ; 8-byte Folded Reload
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	umaxv.8b	b0, v0
	fmov	w8, s0
	tbnz	w8, #0, LBB0_1086
; %bb.1085:                             ; %scheduler.exit
	sub	sp, x29, #144
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
LBB0_1086:                              ; %scheduler.stalled
	brk	#0x1
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpLdr	Lloh40, Lloh41
	.loh AdrpAdrp	Lloh38, Lloh40
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpAdrp	Lloh36, Lloh38
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpAdrp	Lloh34, Lloh36
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpLdr	Lloh32, Lloh33
	.loh AdrpAdrp	Lloh30, Lloh32
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdrp	Lloh28, Lloh30
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpLdr	Lloh304, Lloh305
	.loh AdrpAdrp	Lloh302, Lloh304
	.loh AdrpLdr	Lloh302, Lloh303
	.loh AdrpAdrp	Lloh300, Lloh302
	.loh AdrpLdr	Lloh300, Lloh301
	.loh AdrpAdrp	Lloh298, Lloh300
	.loh AdrpLdr	Lloh298, Lloh299
	.loh AdrpLdr	Lloh296, Lloh297
	.loh AdrpAdrp	Lloh294, Lloh296
	.loh AdrpLdr	Lloh294, Lloh295
	.loh AdrpAdrp	Lloh292, Lloh294
	.loh AdrpLdr	Lloh292, Lloh293
	.loh AdrpAdrp	Lloh290, Lloh292
	.loh AdrpLdr	Lloh290, Lloh291
	.loh AdrpLdr	Lloh288, Lloh289
	.loh AdrpAdrp	Lloh286, Lloh288
	.loh AdrpLdr	Lloh286, Lloh287
	.loh AdrpAdrp	Lloh284, Lloh286
	.loh AdrpLdr	Lloh284, Lloh285
	.loh AdrpAdrp	Lloh282, Lloh284
	.loh AdrpLdr	Lloh282, Lloh283
	.loh AdrpLdr	Lloh280, Lloh281
	.loh AdrpAdrp	Lloh278, Lloh280
	.loh AdrpLdr	Lloh278, Lloh279
	.loh AdrpAdrp	Lloh276, Lloh278
	.loh AdrpLdr	Lloh276, Lloh277
	.loh AdrpAdrp	Lloh274, Lloh276
	.loh AdrpLdr	Lloh274, Lloh275
	.loh AdrpLdr	Lloh272, Lloh273
	.loh AdrpAdrp	Lloh270, Lloh272
	.loh AdrpLdr	Lloh270, Lloh271
	.loh AdrpAdrp	Lloh268, Lloh270
	.loh AdrpLdr	Lloh268, Lloh269
	.loh AdrpAdrp	Lloh266, Lloh268
	.loh AdrpLdr	Lloh266, Lloh267
	.loh AdrpLdr	Lloh264, Lloh265
	.loh AdrpAdrp	Lloh262, Lloh264
	.loh AdrpLdr	Lloh262, Lloh263
	.loh AdrpAdrp	Lloh260, Lloh262
	.loh AdrpLdr	Lloh260, Lloh261
	.loh AdrpAdrp	Lloh258, Lloh260
	.loh AdrpLdr	Lloh258, Lloh259
	.loh AdrpLdr	Lloh256, Lloh257
	.loh AdrpAdrp	Lloh254, Lloh256
	.loh AdrpLdr	Lloh254, Lloh255
	.loh AdrpAdrp	Lloh252, Lloh254
	.loh AdrpLdr	Lloh252, Lloh253
	.loh AdrpAdrp	Lloh250, Lloh252
	.loh AdrpLdr	Lloh250, Lloh251
	.loh AdrpLdr	Lloh248, Lloh249
	.loh AdrpAdrp	Lloh246, Lloh248
	.loh AdrpLdr	Lloh246, Lloh247
	.loh AdrpAdrp	Lloh244, Lloh246
	.loh AdrpLdr	Lloh244, Lloh245
	.loh AdrpAdrp	Lloh242, Lloh244
	.loh AdrpLdr	Lloh242, Lloh243
	.loh AdrpLdr	Lloh240, Lloh241
	.loh AdrpAdrp	Lloh238, Lloh240
	.loh AdrpLdr	Lloh238, Lloh239
	.loh AdrpAdrp	Lloh236, Lloh238
	.loh AdrpLdr	Lloh236, Lloh237
	.loh AdrpAdrp	Lloh234, Lloh236
	.loh AdrpLdr	Lloh234, Lloh235
	.loh AdrpLdr	Lloh232, Lloh233
	.loh AdrpAdrp	Lloh230, Lloh232
	.loh AdrpLdr	Lloh230, Lloh231
	.loh AdrpAdrp	Lloh228, Lloh230
	.loh AdrpLdr	Lloh228, Lloh229
	.loh AdrpAdrp	Lloh226, Lloh228
	.loh AdrpLdr	Lloh226, Lloh227
	.loh AdrpLdr	Lloh224, Lloh225
	.loh AdrpAdrp	Lloh222, Lloh224
	.loh AdrpLdr	Lloh222, Lloh223
	.loh AdrpAdrp	Lloh220, Lloh222
	.loh AdrpLdr	Lloh220, Lloh221
	.loh AdrpAdrp	Lloh218, Lloh220
	.loh AdrpLdr	Lloh218, Lloh219
	.loh AdrpLdr	Lloh216, Lloh217
	.loh AdrpAdrp	Lloh214, Lloh216
	.loh AdrpLdr	Lloh214, Lloh215
	.loh AdrpAdrp	Lloh212, Lloh214
	.loh AdrpLdr	Lloh212, Lloh213
	.loh AdrpAdrp	Lloh210, Lloh212
	.loh AdrpLdr	Lloh210, Lloh211
	.loh AdrpLdr	Lloh208, Lloh209
	.loh AdrpAdrp	Lloh206, Lloh208
	.loh AdrpLdr	Lloh206, Lloh207
	.loh AdrpAdrp	Lloh204, Lloh206
	.loh AdrpLdr	Lloh204, Lloh205
	.loh AdrpAdrp	Lloh202, Lloh204
	.loh AdrpLdr	Lloh202, Lloh203
	.loh AdrpLdr	Lloh200, Lloh201
	.loh AdrpAdrp	Lloh198, Lloh200
	.loh AdrpLdr	Lloh198, Lloh199
	.loh AdrpAdrp	Lloh196, Lloh198
	.loh AdrpLdr	Lloh196, Lloh197
	.loh AdrpAdrp	Lloh194, Lloh196
	.loh AdrpLdr	Lloh194, Lloh195
	.loh AdrpLdr	Lloh192, Lloh193
	.loh AdrpAdrp	Lloh190, Lloh192
	.loh AdrpLdr	Lloh190, Lloh191
	.loh AdrpAdrp	Lloh188, Lloh190
	.loh AdrpLdr	Lloh188, Lloh189
	.loh AdrpAdrp	Lloh186, Lloh188
	.loh AdrpLdr	Lloh186, Lloh187
	.loh AdrpLdr	Lloh184, Lloh185
	.loh AdrpAdrp	Lloh182, Lloh184
	.loh AdrpLdr	Lloh182, Lloh183
	.loh AdrpAdrp	Lloh180, Lloh182
	.loh AdrpLdr	Lloh180, Lloh181
	.loh AdrpAdrp	Lloh178, Lloh180
	.loh AdrpLdr	Lloh178, Lloh179
	.loh AdrpLdr	Lloh176, Lloh177
	.loh AdrpAdrp	Lloh174, Lloh176
	.loh AdrpLdr	Lloh174, Lloh175
	.loh AdrpAdrp	Lloh172, Lloh174
	.loh AdrpLdr	Lloh172, Lloh173
	.loh AdrpAdrp	Lloh170, Lloh172
	.loh AdrpLdr	Lloh170, Lloh171
	.loh AdrpLdr	Lloh168, Lloh169
	.loh AdrpAdrp	Lloh166, Lloh168
	.loh AdrpLdr	Lloh166, Lloh167
	.loh AdrpAdrp	Lloh164, Lloh166
	.loh AdrpLdr	Lloh164, Lloh165
	.loh AdrpAdrp	Lloh162, Lloh164
	.loh AdrpLdr	Lloh162, Lloh163
	.loh AdrpLdr	Lloh160, Lloh161
	.loh AdrpAdrp	Lloh158, Lloh160
	.loh AdrpLdr	Lloh158, Lloh159
	.loh AdrpAdrp	Lloh156, Lloh158
	.loh AdrpLdr	Lloh156, Lloh157
	.loh AdrpAdrp	Lloh154, Lloh156
	.loh AdrpLdr	Lloh154, Lloh155
	.loh AdrpLdr	Lloh152, Lloh153
	.loh AdrpAdrp	Lloh150, Lloh152
	.loh AdrpLdr	Lloh150, Lloh151
	.loh AdrpAdrp	Lloh148, Lloh150
	.loh AdrpLdr	Lloh148, Lloh149
	.loh AdrpAdrp	Lloh146, Lloh148
	.loh AdrpLdr	Lloh146, Lloh147
	.loh AdrpLdr	Lloh144, Lloh145
	.loh AdrpAdrp	Lloh142, Lloh144
	.loh AdrpLdr	Lloh142, Lloh143
	.loh AdrpAdrp	Lloh140, Lloh142
	.loh AdrpLdr	Lloh140, Lloh141
	.loh AdrpAdrp	Lloh138, Lloh140
	.loh AdrpLdr	Lloh138, Lloh139
	.loh AdrpLdr	Lloh136, Lloh137
	.loh AdrpAdrp	Lloh134, Lloh136
	.loh AdrpLdr	Lloh134, Lloh135
	.loh AdrpAdrp	Lloh132, Lloh134
	.loh AdrpLdr	Lloh132, Lloh133
	.loh AdrpAdrp	Lloh130, Lloh132
	.loh AdrpLdr	Lloh130, Lloh131
	.loh AdrpLdr	Lloh128, Lloh129
	.loh AdrpAdrp	Lloh126, Lloh128
	.loh AdrpLdr	Lloh126, Lloh127
	.loh AdrpAdrp	Lloh124, Lloh126
	.loh AdrpLdr	Lloh124, Lloh125
	.loh AdrpAdrp	Lloh122, Lloh124
	.loh AdrpLdr	Lloh122, Lloh123
	.loh AdrpLdr	Lloh120, Lloh121
	.loh AdrpAdrp	Lloh118, Lloh120
	.loh AdrpLdr	Lloh118, Lloh119
	.loh AdrpAdrp	Lloh116, Lloh118
	.loh AdrpLdr	Lloh116, Lloh117
	.loh AdrpAdrp	Lloh114, Lloh116
	.loh AdrpLdr	Lloh114, Lloh115
	.loh AdrpLdr	Lloh112, Lloh113
	.loh AdrpAdrp	Lloh110, Lloh112
	.loh AdrpLdr	Lloh110, Lloh111
	.loh AdrpAdrp	Lloh108, Lloh110
	.loh AdrpLdr	Lloh108, Lloh109
	.loh AdrpAdrp	Lloh106, Lloh108
	.loh AdrpLdr	Lloh106, Lloh107
	.loh AdrpLdr	Lloh104, Lloh105
	.loh AdrpAdrp	Lloh102, Lloh104
	.loh AdrpLdr	Lloh102, Lloh103
	.loh AdrpAdrp	Lloh100, Lloh102
	.loh AdrpLdr	Lloh100, Lloh101
	.loh AdrpAdrp	Lloh98, Lloh100
	.loh AdrpLdr	Lloh98, Lloh99
	.loh AdrpLdr	Lloh96, Lloh97
	.loh AdrpAdrp	Lloh94, Lloh96
	.loh AdrpLdr	Lloh94, Lloh95
	.loh AdrpAdrp	Lloh92, Lloh94
	.loh AdrpLdr	Lloh92, Lloh93
	.loh AdrpAdrp	Lloh90, Lloh92
	.loh AdrpLdr	Lloh90, Lloh91
	.loh AdrpLdr	Lloh88, Lloh89
	.loh AdrpAdrp	Lloh86, Lloh88
	.loh AdrpLdr	Lloh86, Lloh87
	.loh AdrpAdrp	Lloh84, Lloh86
	.loh AdrpLdr	Lloh84, Lloh85
	.loh AdrpAdrp	Lloh82, Lloh84
	.loh AdrpLdr	Lloh82, Lloh83
	.loh AdrpLdr	Lloh80, Lloh81
	.loh AdrpAdrp	Lloh78, Lloh80
	.loh AdrpLdr	Lloh78, Lloh79
	.loh AdrpAdrp	Lloh76, Lloh78
	.loh AdrpLdr	Lloh76, Lloh77
	.loh AdrpAdrp	Lloh74, Lloh76
	.loh AdrpLdr	Lloh74, Lloh75
	.loh AdrpLdr	Lloh72, Lloh73
	.loh AdrpAdrp	Lloh70, Lloh72
	.loh AdrpLdr	Lloh70, Lloh71
	.loh AdrpAdrp	Lloh68, Lloh70
	.loh AdrpLdr	Lloh68, Lloh69
	.loh AdrpAdrp	Lloh66, Lloh68
	.loh AdrpLdr	Lloh66, Lloh67
	.loh AdrpLdr	Lloh64, Lloh65
	.loh AdrpAdrp	Lloh62, Lloh64
	.loh AdrpLdr	Lloh62, Lloh63
	.loh AdrpAdrp	Lloh60, Lloh62
	.loh AdrpLdr	Lloh60, Lloh61
	.loh AdrpAdrp	Lloh58, Lloh60
	.loh AdrpLdr	Lloh58, Lloh59
	.loh AdrpLdr	Lloh56, Lloh57
	.loh AdrpAdrp	Lloh54, Lloh56
	.loh AdrpLdr	Lloh54, Lloh55
	.loh AdrpAdrp	Lloh52, Lloh54
	.loh AdrpLdr	Lloh52, Lloh53
	.loh AdrpAdrp	Lloh50, Lloh52
	.loh AdrpLdr	Lloh50, Lloh51
	.loh AdrpLdr	Lloh48, Lloh49
	.loh AdrpAdrp	Lloh46, Lloh48
	.loh AdrpLdr	Lloh46, Lloh47
	.loh AdrpAdrp	Lloh44, Lloh46
	.loh AdrpLdr	Lloh44, Lloh45
	.loh AdrpAdrp	Lloh42, Lloh44
	.loh AdrpLdr	Lloh42, Lloh43
	.loh AdrpLdr	Lloh312, Lloh313
	.loh AdrpAdrp	Lloh310, Lloh312
	.loh AdrpLdr	Lloh310, Lloh311
	.loh AdrpAdrp	Lloh308, Lloh310
	.loh AdrpLdr	Lloh308, Lloh309
	.loh AdrpAdrp	Lloh306, Lloh308
	.loh AdrpLdr	Lloh306, Lloh307
	.loh AdrpLdr	Lloh576, Lloh577
	.loh AdrpAdrp	Lloh574, Lloh576
	.loh AdrpLdr	Lloh574, Lloh575
	.loh AdrpAdrp	Lloh572, Lloh574
	.loh AdrpLdr	Lloh572, Lloh573
	.loh AdrpAdrp	Lloh570, Lloh572
	.loh AdrpLdr	Lloh570, Lloh571
	.loh AdrpLdr	Lloh568, Lloh569
	.loh AdrpAdrp	Lloh566, Lloh568
	.loh AdrpLdr	Lloh566, Lloh567
	.loh AdrpAdrp	Lloh564, Lloh566
	.loh AdrpLdr	Lloh564, Lloh565
	.loh AdrpAdrp	Lloh562, Lloh564
	.loh AdrpLdr	Lloh562, Lloh563
	.loh AdrpLdr	Lloh560, Lloh561
	.loh AdrpAdrp	Lloh558, Lloh560
	.loh AdrpLdr	Lloh558, Lloh559
	.loh AdrpAdrp	Lloh556, Lloh558
	.loh AdrpLdr	Lloh556, Lloh557
	.loh AdrpAdrp	Lloh554, Lloh556
	.loh AdrpLdr	Lloh554, Lloh555
	.loh AdrpLdr	Lloh552, Lloh553
	.loh AdrpAdrp	Lloh550, Lloh552
	.loh AdrpLdr	Lloh550, Lloh551
	.loh AdrpAdrp	Lloh548, Lloh550
	.loh AdrpLdr	Lloh548, Lloh549
	.loh AdrpAdrp	Lloh546, Lloh548
	.loh AdrpLdr	Lloh546, Lloh547
	.loh AdrpLdr	Lloh544, Lloh545
	.loh AdrpAdrp	Lloh542, Lloh544
	.loh AdrpLdr	Lloh542, Lloh543
	.loh AdrpAdrp	Lloh540, Lloh542
	.loh AdrpLdr	Lloh540, Lloh541
	.loh AdrpAdrp	Lloh538, Lloh540
	.loh AdrpLdr	Lloh538, Lloh539
	.loh AdrpLdr	Lloh536, Lloh537
	.loh AdrpAdrp	Lloh534, Lloh536
	.loh AdrpLdr	Lloh534, Lloh535
	.loh AdrpAdrp	Lloh532, Lloh534
	.loh AdrpLdr	Lloh532, Lloh533
	.loh AdrpAdrp	Lloh530, Lloh532
	.loh AdrpLdr	Lloh530, Lloh531
	.loh AdrpLdr	Lloh528, Lloh529
	.loh AdrpAdrp	Lloh526, Lloh528
	.loh AdrpLdr	Lloh526, Lloh527
	.loh AdrpAdrp	Lloh524, Lloh526
	.loh AdrpLdr	Lloh524, Lloh525
	.loh AdrpAdrp	Lloh522, Lloh524
	.loh AdrpLdr	Lloh522, Lloh523
	.loh AdrpLdr	Lloh520, Lloh521
	.loh AdrpAdrp	Lloh518, Lloh520
	.loh AdrpLdr	Lloh518, Lloh519
	.loh AdrpAdrp	Lloh516, Lloh518
	.loh AdrpLdr	Lloh516, Lloh517
	.loh AdrpAdrp	Lloh514, Lloh516
	.loh AdrpLdr	Lloh514, Lloh515
	.loh AdrpLdr	Lloh512, Lloh513
	.loh AdrpAdrp	Lloh510, Lloh512
	.loh AdrpLdr	Lloh510, Lloh511
	.loh AdrpAdrp	Lloh508, Lloh510
	.loh AdrpLdr	Lloh508, Lloh509
	.loh AdrpAdrp	Lloh506, Lloh508
	.loh AdrpLdr	Lloh506, Lloh507
	.loh AdrpLdr	Lloh504, Lloh505
	.loh AdrpAdrp	Lloh502, Lloh504
	.loh AdrpLdr	Lloh502, Lloh503
	.loh AdrpAdrp	Lloh500, Lloh502
	.loh AdrpLdr	Lloh500, Lloh501
	.loh AdrpAdrp	Lloh498, Lloh500
	.loh AdrpLdr	Lloh498, Lloh499
	.loh AdrpLdr	Lloh496, Lloh497
	.loh AdrpAdrp	Lloh494, Lloh496
	.loh AdrpLdr	Lloh494, Lloh495
	.loh AdrpAdrp	Lloh492, Lloh494
	.loh AdrpLdr	Lloh492, Lloh493
	.loh AdrpAdrp	Lloh490, Lloh492
	.loh AdrpLdr	Lloh490, Lloh491
	.loh AdrpLdr	Lloh488, Lloh489
	.loh AdrpAdrp	Lloh486, Lloh488
	.loh AdrpLdr	Lloh486, Lloh487
	.loh AdrpAdrp	Lloh484, Lloh486
	.loh AdrpLdr	Lloh484, Lloh485
	.loh AdrpAdrp	Lloh482, Lloh484
	.loh AdrpLdr	Lloh482, Lloh483
	.loh AdrpLdr	Lloh480, Lloh481
	.loh AdrpAdrp	Lloh478, Lloh480
	.loh AdrpLdr	Lloh478, Lloh479
	.loh AdrpAdrp	Lloh476, Lloh478
	.loh AdrpLdr	Lloh476, Lloh477
	.loh AdrpAdrp	Lloh474, Lloh476
	.loh AdrpLdr	Lloh474, Lloh475
	.loh AdrpLdr	Lloh472, Lloh473
	.loh AdrpAdrp	Lloh470, Lloh472
	.loh AdrpLdr	Lloh470, Lloh471
	.loh AdrpAdrp	Lloh468, Lloh470
	.loh AdrpLdr	Lloh468, Lloh469
	.loh AdrpAdrp	Lloh466, Lloh468
	.loh AdrpLdr	Lloh466, Lloh467
	.loh AdrpLdr	Lloh464, Lloh465
	.loh AdrpAdrp	Lloh462, Lloh464
	.loh AdrpLdr	Lloh462, Lloh463
	.loh AdrpAdrp	Lloh460, Lloh462
	.loh AdrpLdr	Lloh460, Lloh461
	.loh AdrpAdrp	Lloh458, Lloh460
	.loh AdrpLdr	Lloh458, Lloh459
	.loh AdrpLdr	Lloh456, Lloh457
	.loh AdrpAdrp	Lloh454, Lloh456
	.loh AdrpLdr	Lloh454, Lloh455
	.loh AdrpAdrp	Lloh452, Lloh454
	.loh AdrpLdr	Lloh452, Lloh453
	.loh AdrpAdrp	Lloh450, Lloh452
	.loh AdrpLdr	Lloh450, Lloh451
	.loh AdrpLdr	Lloh448, Lloh449
	.loh AdrpAdrp	Lloh446, Lloh448
	.loh AdrpLdr	Lloh446, Lloh447
	.loh AdrpAdrp	Lloh444, Lloh446
	.loh AdrpLdr	Lloh444, Lloh445
	.loh AdrpAdrp	Lloh442, Lloh444
	.loh AdrpLdr	Lloh442, Lloh443
	.loh AdrpLdr	Lloh440, Lloh441
	.loh AdrpAdrp	Lloh438, Lloh440
	.loh AdrpLdr	Lloh438, Lloh439
	.loh AdrpAdrp	Lloh436, Lloh438
	.loh AdrpLdr	Lloh436, Lloh437
	.loh AdrpAdrp	Lloh434, Lloh436
	.loh AdrpLdr	Lloh434, Lloh435
	.loh AdrpLdr	Lloh432, Lloh433
	.loh AdrpAdrp	Lloh430, Lloh432
	.loh AdrpLdr	Lloh430, Lloh431
	.loh AdrpAdrp	Lloh428, Lloh430
	.loh AdrpLdr	Lloh428, Lloh429
	.loh AdrpAdrp	Lloh426, Lloh428
	.loh AdrpLdr	Lloh426, Lloh427
	.loh AdrpLdr	Lloh424, Lloh425
	.loh AdrpAdrp	Lloh422, Lloh424
	.loh AdrpLdr	Lloh422, Lloh423
	.loh AdrpAdrp	Lloh420, Lloh422
	.loh AdrpLdr	Lloh420, Lloh421
	.loh AdrpAdrp	Lloh418, Lloh420
	.loh AdrpLdr	Lloh418, Lloh419
	.loh AdrpLdr	Lloh416, Lloh417
	.loh AdrpAdrp	Lloh414, Lloh416
	.loh AdrpLdr	Lloh414, Lloh415
	.loh AdrpAdrp	Lloh412, Lloh414
	.loh AdrpLdr	Lloh412, Lloh413
	.loh AdrpAdrp	Lloh410, Lloh412
	.loh AdrpLdr	Lloh410, Lloh411
	.loh AdrpLdr	Lloh408, Lloh409
	.loh AdrpAdrp	Lloh406, Lloh408
	.loh AdrpLdr	Lloh406, Lloh407
	.loh AdrpAdrp	Lloh404, Lloh406
	.loh AdrpLdr	Lloh404, Lloh405
	.loh AdrpAdrp	Lloh402, Lloh404
	.loh AdrpLdr	Lloh402, Lloh403
	.loh AdrpLdr	Lloh400, Lloh401
	.loh AdrpAdrp	Lloh398, Lloh400
	.loh AdrpLdr	Lloh398, Lloh399
	.loh AdrpAdrp	Lloh396, Lloh398
	.loh AdrpLdr	Lloh396, Lloh397
	.loh AdrpAdrp	Lloh394, Lloh396
	.loh AdrpLdr	Lloh394, Lloh395
	.loh AdrpLdr	Lloh392, Lloh393
	.loh AdrpAdrp	Lloh390, Lloh392
	.loh AdrpLdr	Lloh390, Lloh391
	.loh AdrpAdrp	Lloh388, Lloh390
	.loh AdrpLdr	Lloh388, Lloh389
	.loh AdrpAdrp	Lloh386, Lloh388
	.loh AdrpLdr	Lloh386, Lloh387
	.loh AdrpLdr	Lloh384, Lloh385
	.loh AdrpAdrp	Lloh382, Lloh384
	.loh AdrpLdr	Lloh382, Lloh383
	.loh AdrpAdrp	Lloh380, Lloh382
	.loh AdrpLdr	Lloh380, Lloh381
	.loh AdrpAdrp	Lloh378, Lloh380
	.loh AdrpLdr	Lloh378, Lloh379
	.loh AdrpLdr	Lloh376, Lloh377
	.loh AdrpAdrp	Lloh374, Lloh376
	.loh AdrpLdr	Lloh374, Lloh375
	.loh AdrpAdrp	Lloh372, Lloh374
	.loh AdrpLdr	Lloh372, Lloh373
	.loh AdrpAdrp	Lloh370, Lloh372
	.loh AdrpLdr	Lloh370, Lloh371
	.loh AdrpLdr	Lloh368, Lloh369
	.loh AdrpAdrp	Lloh366, Lloh368
	.loh AdrpLdr	Lloh366, Lloh367
	.loh AdrpAdrp	Lloh364, Lloh366
	.loh AdrpLdr	Lloh364, Lloh365
	.loh AdrpAdrp	Lloh362, Lloh364
	.loh AdrpLdr	Lloh362, Lloh363
	.loh AdrpLdr	Lloh360, Lloh361
	.loh AdrpAdrp	Lloh358, Lloh360
	.loh AdrpLdr	Lloh358, Lloh359
	.loh AdrpAdrp	Lloh356, Lloh358
	.loh AdrpLdr	Lloh356, Lloh357
	.loh AdrpAdrp	Lloh354, Lloh356
	.loh AdrpLdr	Lloh354, Lloh355
	.loh AdrpLdr	Lloh352, Lloh353
	.loh AdrpAdrp	Lloh350, Lloh352
	.loh AdrpLdr	Lloh350, Lloh351
	.loh AdrpAdrp	Lloh348, Lloh350
	.loh AdrpLdr	Lloh348, Lloh349
	.loh AdrpAdrp	Lloh346, Lloh348
	.loh AdrpLdr	Lloh346, Lloh347
	.loh AdrpLdr	Lloh344, Lloh345
	.loh AdrpAdrp	Lloh342, Lloh344
	.loh AdrpLdr	Lloh342, Lloh343
	.loh AdrpAdrp	Lloh340, Lloh342
	.loh AdrpLdr	Lloh340, Lloh341
	.loh AdrpAdrp	Lloh338, Lloh340
	.loh AdrpLdr	Lloh338, Lloh339
	.loh AdrpLdr	Lloh336, Lloh337
	.loh AdrpAdrp	Lloh334, Lloh336
	.loh AdrpLdr	Lloh334, Lloh335
	.loh AdrpAdrp	Lloh332, Lloh334
	.loh AdrpLdr	Lloh332, Lloh333
	.loh AdrpAdrp	Lloh330, Lloh332
	.loh AdrpLdr	Lloh330, Lloh331
	.loh AdrpLdr	Lloh328, Lloh329
	.loh AdrpAdrp	Lloh326, Lloh328
	.loh AdrpLdr	Lloh326, Lloh327
	.loh AdrpAdrp	Lloh324, Lloh326
	.loh AdrpLdr	Lloh324, Lloh325
	.loh AdrpAdrp	Lloh322, Lloh324
	.loh AdrpLdr	Lloh322, Lloh323
	.loh AdrpLdr	Lloh320, Lloh321
	.loh AdrpAdrp	Lloh318, Lloh320
	.loh AdrpLdr	Lloh318, Lloh319
	.loh AdrpAdrp	Lloh316, Lloh318
	.loh AdrpLdr	Lloh316, Lloh317
	.loh AdrpAdrp	Lloh314, Lloh316
	.loh AdrpLdr	Lloh314, Lloh315
	.loh AdrpLdr	Lloh584, Lloh585
	.loh AdrpAdrp	Lloh582, Lloh584
	.loh AdrpLdr	Lloh582, Lloh583
	.loh AdrpAdrp	Lloh580, Lloh582
	.loh AdrpLdr	Lloh580, Lloh581
	.loh AdrpAdrp	Lloh578, Lloh580
	.loh AdrpLdr	Lloh578, Lloh579
	.loh AdrpLdr	Lloh848, Lloh849
	.loh AdrpAdrp	Lloh846, Lloh848
	.loh AdrpLdr	Lloh846, Lloh847
	.loh AdrpAdrp	Lloh844, Lloh846
	.loh AdrpLdr	Lloh844, Lloh845
	.loh AdrpAdrp	Lloh842, Lloh844
	.loh AdrpLdr	Lloh842, Lloh843
	.loh AdrpLdr	Lloh840, Lloh841
	.loh AdrpAdrp	Lloh838, Lloh840
	.loh AdrpLdr	Lloh838, Lloh839
	.loh AdrpAdrp	Lloh836, Lloh838
	.loh AdrpLdr	Lloh836, Lloh837
	.loh AdrpAdrp	Lloh834, Lloh836
	.loh AdrpLdr	Lloh834, Lloh835
	.loh AdrpLdr	Lloh832, Lloh833
	.loh AdrpAdrp	Lloh830, Lloh832
	.loh AdrpLdr	Lloh830, Lloh831
	.loh AdrpAdrp	Lloh828, Lloh830
	.loh AdrpLdr	Lloh828, Lloh829
	.loh AdrpAdrp	Lloh826, Lloh828
	.loh AdrpLdr	Lloh826, Lloh827
	.loh AdrpLdr	Lloh824, Lloh825
	.loh AdrpAdrp	Lloh822, Lloh824
	.loh AdrpLdr	Lloh822, Lloh823
	.loh AdrpAdrp	Lloh820, Lloh822
	.loh AdrpLdr	Lloh820, Lloh821
	.loh AdrpAdrp	Lloh818, Lloh820
	.loh AdrpLdr	Lloh818, Lloh819
	.loh AdrpLdr	Lloh816, Lloh817
	.loh AdrpAdrp	Lloh814, Lloh816
	.loh AdrpLdr	Lloh814, Lloh815
	.loh AdrpAdrp	Lloh812, Lloh814
	.loh AdrpLdr	Lloh812, Lloh813
	.loh AdrpAdrp	Lloh810, Lloh812
	.loh AdrpLdr	Lloh810, Lloh811
	.loh AdrpLdr	Lloh808, Lloh809
	.loh AdrpAdrp	Lloh806, Lloh808
	.loh AdrpLdr	Lloh806, Lloh807
	.loh AdrpAdrp	Lloh804, Lloh806
	.loh AdrpLdr	Lloh804, Lloh805
	.loh AdrpAdrp	Lloh802, Lloh804
	.loh AdrpLdr	Lloh802, Lloh803
	.loh AdrpLdr	Lloh800, Lloh801
	.loh AdrpAdrp	Lloh798, Lloh800
	.loh AdrpLdr	Lloh798, Lloh799
	.loh AdrpAdrp	Lloh796, Lloh798
	.loh AdrpLdr	Lloh796, Lloh797
	.loh AdrpAdrp	Lloh794, Lloh796
	.loh AdrpLdr	Lloh794, Lloh795
	.loh AdrpLdr	Lloh792, Lloh793
	.loh AdrpAdrp	Lloh790, Lloh792
	.loh AdrpLdr	Lloh790, Lloh791
	.loh AdrpAdrp	Lloh788, Lloh790
	.loh AdrpLdr	Lloh788, Lloh789
	.loh AdrpAdrp	Lloh786, Lloh788
	.loh AdrpLdr	Lloh786, Lloh787
	.loh AdrpLdr	Lloh784, Lloh785
	.loh AdrpAdrp	Lloh782, Lloh784
	.loh AdrpLdr	Lloh782, Lloh783
	.loh AdrpAdrp	Lloh780, Lloh782
	.loh AdrpLdr	Lloh780, Lloh781
	.loh AdrpAdrp	Lloh778, Lloh780
	.loh AdrpLdr	Lloh778, Lloh779
	.loh AdrpLdr	Lloh776, Lloh777
	.loh AdrpAdrp	Lloh774, Lloh776
	.loh AdrpLdr	Lloh774, Lloh775
	.loh AdrpAdrp	Lloh772, Lloh774
	.loh AdrpLdr	Lloh772, Lloh773
	.loh AdrpAdrp	Lloh770, Lloh772
	.loh AdrpLdr	Lloh770, Lloh771
	.loh AdrpLdr	Lloh768, Lloh769
	.loh AdrpAdrp	Lloh766, Lloh768
	.loh AdrpLdr	Lloh766, Lloh767
	.loh AdrpAdrp	Lloh764, Lloh766
	.loh AdrpLdr	Lloh764, Lloh765
	.loh AdrpAdrp	Lloh762, Lloh764
	.loh AdrpLdr	Lloh762, Lloh763
	.loh AdrpLdr	Lloh760, Lloh761
	.loh AdrpAdrp	Lloh758, Lloh760
	.loh AdrpLdr	Lloh758, Lloh759
	.loh AdrpAdrp	Lloh756, Lloh758
	.loh AdrpLdr	Lloh756, Lloh757
	.loh AdrpAdrp	Lloh754, Lloh756
	.loh AdrpLdr	Lloh754, Lloh755
	.loh AdrpLdr	Lloh752, Lloh753
	.loh AdrpAdrp	Lloh750, Lloh752
	.loh AdrpLdr	Lloh750, Lloh751
	.loh AdrpAdrp	Lloh748, Lloh750
	.loh AdrpLdr	Lloh748, Lloh749
	.loh AdrpAdrp	Lloh746, Lloh748
	.loh AdrpLdr	Lloh746, Lloh747
	.loh AdrpLdr	Lloh744, Lloh745
	.loh AdrpAdrp	Lloh742, Lloh744
	.loh AdrpLdr	Lloh742, Lloh743
	.loh AdrpAdrp	Lloh740, Lloh742
	.loh AdrpLdr	Lloh740, Lloh741
	.loh AdrpAdrp	Lloh738, Lloh740
	.loh AdrpLdr	Lloh738, Lloh739
	.loh AdrpLdr	Lloh736, Lloh737
	.loh AdrpAdrp	Lloh734, Lloh736
	.loh AdrpLdr	Lloh734, Lloh735
	.loh AdrpAdrp	Lloh732, Lloh734
	.loh AdrpLdr	Lloh732, Lloh733
	.loh AdrpAdrp	Lloh730, Lloh732
	.loh AdrpLdr	Lloh730, Lloh731
	.loh AdrpLdr	Lloh728, Lloh729
	.loh AdrpAdrp	Lloh726, Lloh728
	.loh AdrpLdr	Lloh726, Lloh727
	.loh AdrpAdrp	Lloh724, Lloh726
	.loh AdrpLdr	Lloh724, Lloh725
	.loh AdrpAdrp	Lloh722, Lloh724
	.loh AdrpLdr	Lloh722, Lloh723
	.loh AdrpLdr	Lloh720, Lloh721
	.loh AdrpAdrp	Lloh718, Lloh720
	.loh AdrpLdr	Lloh718, Lloh719
	.loh AdrpAdrp	Lloh716, Lloh718
	.loh AdrpLdr	Lloh716, Lloh717
	.loh AdrpAdrp	Lloh714, Lloh716
	.loh AdrpLdr	Lloh714, Lloh715
	.loh AdrpLdr	Lloh712, Lloh713
	.loh AdrpAdrp	Lloh710, Lloh712
	.loh AdrpLdr	Lloh710, Lloh711
	.loh AdrpAdrp	Lloh708, Lloh710
	.loh AdrpLdr	Lloh708, Lloh709
	.loh AdrpAdrp	Lloh706, Lloh708
	.loh AdrpLdr	Lloh706, Lloh707
	.loh AdrpLdr	Lloh704, Lloh705
	.loh AdrpAdrp	Lloh702, Lloh704
	.loh AdrpLdr	Lloh702, Lloh703
	.loh AdrpAdrp	Lloh700, Lloh702
	.loh AdrpLdr	Lloh700, Lloh701
	.loh AdrpAdrp	Lloh698, Lloh700
	.loh AdrpLdr	Lloh698, Lloh699
	.loh AdrpLdr	Lloh696, Lloh697
	.loh AdrpAdrp	Lloh694, Lloh696
	.loh AdrpLdr	Lloh694, Lloh695
	.loh AdrpAdrp	Lloh692, Lloh694
	.loh AdrpLdr	Lloh692, Lloh693
	.loh AdrpAdrp	Lloh690, Lloh692
	.loh AdrpLdr	Lloh690, Lloh691
	.loh AdrpLdr	Lloh688, Lloh689
	.loh AdrpAdrp	Lloh686, Lloh688
	.loh AdrpLdr	Lloh686, Lloh687
	.loh AdrpAdrp	Lloh684, Lloh686
	.loh AdrpLdr	Lloh684, Lloh685
	.loh AdrpAdrp	Lloh682, Lloh684
	.loh AdrpLdr	Lloh682, Lloh683
	.loh AdrpLdr	Lloh680, Lloh681
	.loh AdrpAdrp	Lloh678, Lloh680
	.loh AdrpLdr	Lloh678, Lloh679
	.loh AdrpAdrp	Lloh676, Lloh678
	.loh AdrpLdr	Lloh676, Lloh677
	.loh AdrpAdrp	Lloh674, Lloh676
	.loh AdrpLdr	Lloh674, Lloh675
	.loh AdrpLdr	Lloh672, Lloh673
	.loh AdrpAdrp	Lloh670, Lloh672
	.loh AdrpLdr	Lloh670, Lloh671
	.loh AdrpAdrp	Lloh668, Lloh670
	.loh AdrpLdr	Lloh668, Lloh669
	.loh AdrpAdrp	Lloh666, Lloh668
	.loh AdrpLdr	Lloh666, Lloh667
	.loh AdrpLdr	Lloh664, Lloh665
	.loh AdrpAdrp	Lloh662, Lloh664
	.loh AdrpLdr	Lloh662, Lloh663
	.loh AdrpAdrp	Lloh660, Lloh662
	.loh AdrpLdr	Lloh660, Lloh661
	.loh AdrpAdrp	Lloh658, Lloh660
	.loh AdrpLdr	Lloh658, Lloh659
	.loh AdrpLdr	Lloh656, Lloh657
	.loh AdrpAdrp	Lloh654, Lloh656
	.loh AdrpLdr	Lloh654, Lloh655
	.loh AdrpAdrp	Lloh652, Lloh654
	.loh AdrpLdr	Lloh652, Lloh653
	.loh AdrpAdrp	Lloh650, Lloh652
	.loh AdrpLdr	Lloh650, Lloh651
	.loh AdrpLdr	Lloh648, Lloh649
	.loh AdrpAdrp	Lloh646, Lloh648
	.loh AdrpLdr	Lloh646, Lloh647
	.loh AdrpAdrp	Lloh644, Lloh646
	.loh AdrpLdr	Lloh644, Lloh645
	.loh AdrpAdrp	Lloh642, Lloh644
	.loh AdrpLdr	Lloh642, Lloh643
	.loh AdrpLdr	Lloh640, Lloh641
	.loh AdrpAdrp	Lloh638, Lloh640
	.loh AdrpLdr	Lloh638, Lloh639
	.loh AdrpAdrp	Lloh636, Lloh638
	.loh AdrpLdr	Lloh636, Lloh637
	.loh AdrpAdrp	Lloh634, Lloh636
	.loh AdrpLdr	Lloh634, Lloh635
	.loh AdrpLdr	Lloh632, Lloh633
	.loh AdrpAdrp	Lloh630, Lloh632
	.loh AdrpLdr	Lloh630, Lloh631
	.loh AdrpAdrp	Lloh628, Lloh630
	.loh AdrpLdr	Lloh628, Lloh629
	.loh AdrpAdrp	Lloh626, Lloh628
	.loh AdrpLdr	Lloh626, Lloh627
	.loh AdrpLdr	Lloh624, Lloh625
	.loh AdrpAdrp	Lloh622, Lloh624
	.loh AdrpLdr	Lloh622, Lloh623
	.loh AdrpAdrp	Lloh620, Lloh622
	.loh AdrpLdr	Lloh620, Lloh621
	.loh AdrpAdrp	Lloh618, Lloh620
	.loh AdrpLdr	Lloh618, Lloh619
	.loh AdrpLdr	Lloh616, Lloh617
	.loh AdrpAdrp	Lloh614, Lloh616
	.loh AdrpLdr	Lloh614, Lloh615
	.loh AdrpAdrp	Lloh612, Lloh614
	.loh AdrpLdr	Lloh612, Lloh613
	.loh AdrpAdrp	Lloh610, Lloh612
	.loh AdrpLdr	Lloh610, Lloh611
	.loh AdrpLdr	Lloh608, Lloh609
	.loh AdrpAdrp	Lloh606, Lloh608
	.loh AdrpLdr	Lloh606, Lloh607
	.loh AdrpAdrp	Lloh604, Lloh606
	.loh AdrpLdr	Lloh604, Lloh605
	.loh AdrpAdrp	Lloh602, Lloh604
	.loh AdrpLdr	Lloh602, Lloh603
	.loh AdrpLdr	Lloh600, Lloh601
	.loh AdrpAdrp	Lloh598, Lloh600
	.loh AdrpLdr	Lloh598, Lloh599
	.loh AdrpAdrp	Lloh596, Lloh598
	.loh AdrpLdr	Lloh596, Lloh597
	.loh AdrpAdrp	Lloh594, Lloh596
	.loh AdrpLdr	Lloh594, Lloh595
	.loh AdrpLdr	Lloh592, Lloh593
	.loh AdrpAdrp	Lloh590, Lloh592
	.loh AdrpLdr	Lloh590, Lloh591
	.loh AdrpAdrp	Lloh588, Lloh590
	.loh AdrpLdr	Lloh588, Lloh589
	.loh AdrpAdrp	Lloh586, Lloh588
	.loh AdrpLdr	Lloh586, Lloh587
	.loh AdrpLdr	Lloh856, Lloh857
	.loh AdrpAdrp	Lloh854, Lloh856
	.loh AdrpLdr	Lloh854, Lloh855
	.loh AdrpAdrp	Lloh852, Lloh854
	.loh AdrpLdr	Lloh852, Lloh853
	.loh AdrpAdrp	Lloh850, Lloh852
	.loh AdrpLdr	Lloh850, Lloh851
	.loh AdrpLdr	Lloh1120, Lloh1121
	.loh AdrpAdrp	Lloh1118, Lloh1120
	.loh AdrpLdr	Lloh1118, Lloh1119
	.loh AdrpAdrp	Lloh1116, Lloh1118
	.loh AdrpLdr	Lloh1116, Lloh1117
	.loh AdrpAdrp	Lloh1114, Lloh1116
	.loh AdrpLdr	Lloh1114, Lloh1115
	.loh AdrpLdr	Lloh1112, Lloh1113
	.loh AdrpAdrp	Lloh1110, Lloh1112
	.loh AdrpLdr	Lloh1110, Lloh1111
	.loh AdrpAdrp	Lloh1108, Lloh1110
	.loh AdrpLdr	Lloh1108, Lloh1109
	.loh AdrpAdrp	Lloh1106, Lloh1108
	.loh AdrpLdr	Lloh1106, Lloh1107
	.loh AdrpLdr	Lloh1104, Lloh1105
	.loh AdrpAdrp	Lloh1102, Lloh1104
	.loh AdrpLdr	Lloh1102, Lloh1103
	.loh AdrpAdrp	Lloh1100, Lloh1102
	.loh AdrpLdr	Lloh1100, Lloh1101
	.loh AdrpAdrp	Lloh1098, Lloh1100
	.loh AdrpLdr	Lloh1098, Lloh1099
	.loh AdrpLdr	Lloh1096, Lloh1097
	.loh AdrpAdrp	Lloh1094, Lloh1096
	.loh AdrpLdr	Lloh1094, Lloh1095
	.loh AdrpAdrp	Lloh1092, Lloh1094
	.loh AdrpLdr	Lloh1092, Lloh1093
	.loh AdrpAdrp	Lloh1090, Lloh1092
	.loh AdrpLdr	Lloh1090, Lloh1091
	.loh AdrpLdr	Lloh1088, Lloh1089
	.loh AdrpAdrp	Lloh1086, Lloh1088
	.loh AdrpLdr	Lloh1086, Lloh1087
	.loh AdrpAdrp	Lloh1084, Lloh1086
	.loh AdrpLdr	Lloh1084, Lloh1085
	.loh AdrpAdrp	Lloh1082, Lloh1084
	.loh AdrpLdr	Lloh1082, Lloh1083
	.loh AdrpLdr	Lloh1080, Lloh1081
	.loh AdrpAdrp	Lloh1078, Lloh1080
	.loh AdrpLdr	Lloh1078, Lloh1079
	.loh AdrpAdrp	Lloh1076, Lloh1078
	.loh AdrpLdr	Lloh1076, Lloh1077
	.loh AdrpAdrp	Lloh1074, Lloh1076
	.loh AdrpLdr	Lloh1074, Lloh1075
	.loh AdrpLdr	Lloh1072, Lloh1073
	.loh AdrpAdrp	Lloh1070, Lloh1072
	.loh AdrpLdr	Lloh1070, Lloh1071
	.loh AdrpAdrp	Lloh1068, Lloh1070
	.loh AdrpLdr	Lloh1068, Lloh1069
	.loh AdrpAdrp	Lloh1066, Lloh1068
	.loh AdrpLdr	Lloh1066, Lloh1067
	.loh AdrpLdr	Lloh1064, Lloh1065
	.loh AdrpAdrp	Lloh1062, Lloh1064
	.loh AdrpLdr	Lloh1062, Lloh1063
	.loh AdrpAdrp	Lloh1060, Lloh1062
	.loh AdrpLdr	Lloh1060, Lloh1061
	.loh AdrpAdrp	Lloh1058, Lloh1060
	.loh AdrpLdr	Lloh1058, Lloh1059
	.loh AdrpLdr	Lloh1056, Lloh1057
	.loh AdrpAdrp	Lloh1054, Lloh1056
	.loh AdrpLdr	Lloh1054, Lloh1055
	.loh AdrpAdrp	Lloh1052, Lloh1054
	.loh AdrpLdr	Lloh1052, Lloh1053
	.loh AdrpAdrp	Lloh1050, Lloh1052
	.loh AdrpLdr	Lloh1050, Lloh1051
	.loh AdrpLdr	Lloh1048, Lloh1049
	.loh AdrpAdrp	Lloh1046, Lloh1048
	.loh AdrpLdr	Lloh1046, Lloh1047
	.loh AdrpAdrp	Lloh1044, Lloh1046
	.loh AdrpLdr	Lloh1044, Lloh1045
	.loh AdrpAdrp	Lloh1042, Lloh1044
	.loh AdrpLdr	Lloh1042, Lloh1043
	.loh AdrpLdr	Lloh1040, Lloh1041
	.loh AdrpAdrp	Lloh1038, Lloh1040
	.loh AdrpLdr	Lloh1038, Lloh1039
	.loh AdrpAdrp	Lloh1036, Lloh1038
	.loh AdrpLdr	Lloh1036, Lloh1037
	.loh AdrpAdrp	Lloh1034, Lloh1036
	.loh AdrpLdr	Lloh1034, Lloh1035
	.loh AdrpLdr	Lloh1032, Lloh1033
	.loh AdrpAdrp	Lloh1030, Lloh1032
	.loh AdrpLdr	Lloh1030, Lloh1031
	.loh AdrpAdrp	Lloh1028, Lloh1030
	.loh AdrpLdr	Lloh1028, Lloh1029
	.loh AdrpAdrp	Lloh1026, Lloh1028
	.loh AdrpLdr	Lloh1026, Lloh1027
	.loh AdrpLdr	Lloh1024, Lloh1025
	.loh AdrpAdrp	Lloh1022, Lloh1024
	.loh AdrpLdr	Lloh1022, Lloh1023
	.loh AdrpAdrp	Lloh1020, Lloh1022
	.loh AdrpLdr	Lloh1020, Lloh1021
	.loh AdrpAdrp	Lloh1018, Lloh1020
	.loh AdrpLdr	Lloh1018, Lloh1019
	.loh AdrpLdr	Lloh1016, Lloh1017
	.loh AdrpAdrp	Lloh1014, Lloh1016
	.loh AdrpLdr	Lloh1014, Lloh1015
	.loh AdrpAdrp	Lloh1012, Lloh1014
	.loh AdrpLdr	Lloh1012, Lloh1013
	.loh AdrpAdrp	Lloh1010, Lloh1012
	.loh AdrpLdr	Lloh1010, Lloh1011
	.loh AdrpLdr	Lloh1008, Lloh1009
	.loh AdrpAdrp	Lloh1006, Lloh1008
	.loh AdrpLdr	Lloh1006, Lloh1007
	.loh AdrpAdrp	Lloh1004, Lloh1006
	.loh AdrpLdr	Lloh1004, Lloh1005
	.loh AdrpAdrp	Lloh1002, Lloh1004
	.loh AdrpLdr	Lloh1002, Lloh1003
	.loh AdrpLdr	Lloh1000, Lloh1001
	.loh AdrpAdrp	Lloh998, Lloh1000
	.loh AdrpLdr	Lloh998, Lloh999
	.loh AdrpAdrp	Lloh996, Lloh998
	.loh AdrpLdr	Lloh996, Lloh997
	.loh AdrpAdrp	Lloh994, Lloh996
	.loh AdrpLdr	Lloh994, Lloh995
	.loh AdrpLdr	Lloh992, Lloh993
	.loh AdrpAdrp	Lloh990, Lloh992
	.loh AdrpLdr	Lloh990, Lloh991
	.loh AdrpAdrp	Lloh988, Lloh990
	.loh AdrpLdr	Lloh988, Lloh989
	.loh AdrpAdrp	Lloh986, Lloh988
	.loh AdrpLdr	Lloh986, Lloh987
	.loh AdrpLdr	Lloh984, Lloh985
	.loh AdrpAdrp	Lloh982, Lloh984
	.loh AdrpLdr	Lloh982, Lloh983
	.loh AdrpAdrp	Lloh980, Lloh982
	.loh AdrpLdr	Lloh980, Lloh981
	.loh AdrpAdrp	Lloh978, Lloh980
	.loh AdrpLdr	Lloh978, Lloh979
	.loh AdrpLdr	Lloh976, Lloh977
	.loh AdrpAdrp	Lloh974, Lloh976
	.loh AdrpLdr	Lloh974, Lloh975
	.loh AdrpAdrp	Lloh972, Lloh974
	.loh AdrpLdr	Lloh972, Lloh973
	.loh AdrpAdrp	Lloh970, Lloh972
	.loh AdrpLdr	Lloh970, Lloh971
	.loh AdrpLdr	Lloh968, Lloh969
	.loh AdrpAdrp	Lloh966, Lloh968
	.loh AdrpLdr	Lloh966, Lloh967
	.loh AdrpAdrp	Lloh964, Lloh966
	.loh AdrpLdr	Lloh964, Lloh965
	.loh AdrpAdrp	Lloh962, Lloh964
	.loh AdrpLdr	Lloh962, Lloh963
	.loh AdrpLdr	Lloh960, Lloh961
	.loh AdrpAdrp	Lloh958, Lloh960
	.loh AdrpLdr	Lloh958, Lloh959
	.loh AdrpAdrp	Lloh956, Lloh958
	.loh AdrpLdr	Lloh956, Lloh957
	.loh AdrpAdrp	Lloh954, Lloh956
	.loh AdrpLdr	Lloh954, Lloh955
	.loh AdrpLdr	Lloh952, Lloh953
	.loh AdrpAdrp	Lloh950, Lloh952
	.loh AdrpLdr	Lloh950, Lloh951
	.loh AdrpAdrp	Lloh948, Lloh950
	.loh AdrpLdr	Lloh948, Lloh949
	.loh AdrpAdrp	Lloh946, Lloh948
	.loh AdrpLdr	Lloh946, Lloh947
	.loh AdrpLdr	Lloh944, Lloh945
	.loh AdrpAdrp	Lloh942, Lloh944
	.loh AdrpLdr	Lloh942, Lloh943
	.loh AdrpAdrp	Lloh940, Lloh942
	.loh AdrpLdr	Lloh940, Lloh941
	.loh AdrpAdrp	Lloh938, Lloh940
	.loh AdrpLdr	Lloh938, Lloh939
	.loh AdrpLdr	Lloh936, Lloh937
	.loh AdrpAdrp	Lloh934, Lloh936
	.loh AdrpLdr	Lloh934, Lloh935
	.loh AdrpAdrp	Lloh932, Lloh934
	.loh AdrpLdr	Lloh932, Lloh933
	.loh AdrpAdrp	Lloh930, Lloh932
	.loh AdrpLdr	Lloh930, Lloh931
	.loh AdrpLdr	Lloh928, Lloh929
	.loh AdrpAdrp	Lloh926, Lloh928
	.loh AdrpLdr	Lloh926, Lloh927
	.loh AdrpAdrp	Lloh924, Lloh926
	.loh AdrpLdr	Lloh924, Lloh925
	.loh AdrpAdrp	Lloh922, Lloh924
	.loh AdrpLdr	Lloh922, Lloh923
	.loh AdrpLdr	Lloh920, Lloh921
	.loh AdrpAdrp	Lloh918, Lloh920
	.loh AdrpLdr	Lloh918, Lloh919
	.loh AdrpAdrp	Lloh916, Lloh918
	.loh AdrpLdr	Lloh916, Lloh917
	.loh AdrpAdrp	Lloh914, Lloh916
	.loh AdrpLdr	Lloh914, Lloh915
	.loh AdrpLdr	Lloh912, Lloh913
	.loh AdrpAdrp	Lloh910, Lloh912
	.loh AdrpLdr	Lloh910, Lloh911
	.loh AdrpAdrp	Lloh908, Lloh910
	.loh AdrpLdr	Lloh908, Lloh909
	.loh AdrpAdrp	Lloh906, Lloh908
	.loh AdrpLdr	Lloh906, Lloh907
	.loh AdrpLdr	Lloh904, Lloh905
	.loh AdrpAdrp	Lloh902, Lloh904
	.loh AdrpLdr	Lloh902, Lloh903
	.loh AdrpAdrp	Lloh900, Lloh902
	.loh AdrpLdr	Lloh900, Lloh901
	.loh AdrpAdrp	Lloh898, Lloh900
	.loh AdrpLdr	Lloh898, Lloh899
	.loh AdrpLdr	Lloh896, Lloh897
	.loh AdrpAdrp	Lloh894, Lloh896
	.loh AdrpLdr	Lloh894, Lloh895
	.loh AdrpAdrp	Lloh892, Lloh894
	.loh AdrpLdr	Lloh892, Lloh893
	.loh AdrpAdrp	Lloh890, Lloh892
	.loh AdrpLdr	Lloh890, Lloh891
	.loh AdrpLdr	Lloh888, Lloh889
	.loh AdrpAdrp	Lloh886, Lloh888
	.loh AdrpLdr	Lloh886, Lloh887
	.loh AdrpAdrp	Lloh884, Lloh886
	.loh AdrpLdr	Lloh884, Lloh885
	.loh AdrpAdrp	Lloh882, Lloh884
	.loh AdrpLdr	Lloh882, Lloh883
	.loh AdrpLdr	Lloh880, Lloh881
	.loh AdrpAdrp	Lloh878, Lloh880
	.loh AdrpLdr	Lloh878, Lloh879
	.loh AdrpAdrp	Lloh876, Lloh878
	.loh AdrpLdr	Lloh876, Lloh877
	.loh AdrpAdrp	Lloh874, Lloh876
	.loh AdrpLdr	Lloh874, Lloh875
	.loh AdrpLdr	Lloh872, Lloh873
	.loh AdrpAdrp	Lloh870, Lloh872
	.loh AdrpLdr	Lloh870, Lloh871
	.loh AdrpAdrp	Lloh868, Lloh870
	.loh AdrpLdr	Lloh868, Lloh869
	.loh AdrpAdrp	Lloh866, Lloh868
	.loh AdrpLdr	Lloh866, Lloh867
	.loh AdrpLdr	Lloh864, Lloh865
	.loh AdrpAdrp	Lloh862, Lloh864
	.loh AdrpLdr	Lloh862, Lloh863
	.loh AdrpAdrp	Lloh860, Lloh862
	.loh AdrpLdr	Lloh860, Lloh861
	.loh AdrpAdrp	Lloh858, Lloh860
	.loh AdrpLdr	Lloh858, Lloh859
	.loh AdrpLdr	Lloh1128, Lloh1129
	.loh AdrpAdrp	Lloh1126, Lloh1128
	.loh AdrpLdr	Lloh1126, Lloh1127
	.loh AdrpAdrp	Lloh1124, Lloh1126
	.loh AdrpLdr	Lloh1124, Lloh1125
	.loh AdrpAdrp	Lloh1122, Lloh1124
	.loh AdrpLdr	Lloh1122, Lloh1123
	.loh AdrpLdr	Lloh1392, Lloh1393
	.loh AdrpAdrp	Lloh1390, Lloh1392
	.loh AdrpLdr	Lloh1390, Lloh1391
	.loh AdrpAdrp	Lloh1388, Lloh1390
	.loh AdrpLdr	Lloh1388, Lloh1389
	.loh AdrpAdrp	Lloh1386, Lloh1388
	.loh AdrpLdr	Lloh1386, Lloh1387
	.loh AdrpLdr	Lloh1384, Lloh1385
	.loh AdrpAdrp	Lloh1382, Lloh1384
	.loh AdrpLdr	Lloh1382, Lloh1383
	.loh AdrpAdrp	Lloh1380, Lloh1382
	.loh AdrpLdr	Lloh1380, Lloh1381
	.loh AdrpAdrp	Lloh1378, Lloh1380
	.loh AdrpLdr	Lloh1378, Lloh1379
	.loh AdrpLdr	Lloh1376, Lloh1377
	.loh AdrpAdrp	Lloh1374, Lloh1376
	.loh AdrpLdr	Lloh1374, Lloh1375
	.loh AdrpAdrp	Lloh1372, Lloh1374
	.loh AdrpLdr	Lloh1372, Lloh1373
	.loh AdrpAdrp	Lloh1370, Lloh1372
	.loh AdrpLdr	Lloh1370, Lloh1371
	.loh AdrpLdr	Lloh1368, Lloh1369
	.loh AdrpAdrp	Lloh1366, Lloh1368
	.loh AdrpLdr	Lloh1366, Lloh1367
	.loh AdrpAdrp	Lloh1364, Lloh1366
	.loh AdrpLdr	Lloh1364, Lloh1365
	.loh AdrpAdrp	Lloh1362, Lloh1364
	.loh AdrpLdr	Lloh1362, Lloh1363
	.loh AdrpLdr	Lloh1360, Lloh1361
	.loh AdrpAdrp	Lloh1358, Lloh1360
	.loh AdrpLdr	Lloh1358, Lloh1359
	.loh AdrpAdrp	Lloh1356, Lloh1358
	.loh AdrpLdr	Lloh1356, Lloh1357
	.loh AdrpAdrp	Lloh1354, Lloh1356
	.loh AdrpLdr	Lloh1354, Lloh1355
	.loh AdrpLdr	Lloh1352, Lloh1353
	.loh AdrpAdrp	Lloh1350, Lloh1352
	.loh AdrpLdr	Lloh1350, Lloh1351
	.loh AdrpAdrp	Lloh1348, Lloh1350
	.loh AdrpLdr	Lloh1348, Lloh1349
	.loh AdrpAdrp	Lloh1346, Lloh1348
	.loh AdrpLdr	Lloh1346, Lloh1347
	.loh AdrpLdr	Lloh1344, Lloh1345
	.loh AdrpAdrp	Lloh1342, Lloh1344
	.loh AdrpLdr	Lloh1342, Lloh1343
	.loh AdrpAdrp	Lloh1340, Lloh1342
	.loh AdrpLdr	Lloh1340, Lloh1341
	.loh AdrpAdrp	Lloh1338, Lloh1340
	.loh AdrpLdr	Lloh1338, Lloh1339
	.loh AdrpLdr	Lloh1336, Lloh1337
	.loh AdrpAdrp	Lloh1334, Lloh1336
	.loh AdrpLdr	Lloh1334, Lloh1335
	.loh AdrpAdrp	Lloh1332, Lloh1334
	.loh AdrpLdr	Lloh1332, Lloh1333
	.loh AdrpAdrp	Lloh1330, Lloh1332
	.loh AdrpLdr	Lloh1330, Lloh1331
	.loh AdrpLdr	Lloh1328, Lloh1329
	.loh AdrpAdrp	Lloh1326, Lloh1328
	.loh AdrpLdr	Lloh1326, Lloh1327
	.loh AdrpAdrp	Lloh1324, Lloh1326
	.loh AdrpLdr	Lloh1324, Lloh1325
	.loh AdrpAdrp	Lloh1322, Lloh1324
	.loh AdrpLdr	Lloh1322, Lloh1323
	.loh AdrpLdr	Lloh1320, Lloh1321
	.loh AdrpAdrp	Lloh1318, Lloh1320
	.loh AdrpLdr	Lloh1318, Lloh1319
	.loh AdrpAdrp	Lloh1316, Lloh1318
	.loh AdrpLdr	Lloh1316, Lloh1317
	.loh AdrpAdrp	Lloh1314, Lloh1316
	.loh AdrpLdr	Lloh1314, Lloh1315
	.loh AdrpLdr	Lloh1312, Lloh1313
	.loh AdrpAdrp	Lloh1310, Lloh1312
	.loh AdrpLdr	Lloh1310, Lloh1311
	.loh AdrpAdrp	Lloh1308, Lloh1310
	.loh AdrpLdr	Lloh1308, Lloh1309
	.loh AdrpAdrp	Lloh1306, Lloh1308
	.loh AdrpLdr	Lloh1306, Lloh1307
	.loh AdrpLdr	Lloh1304, Lloh1305
	.loh AdrpAdrp	Lloh1302, Lloh1304
	.loh AdrpLdr	Lloh1302, Lloh1303
	.loh AdrpAdrp	Lloh1300, Lloh1302
	.loh AdrpLdr	Lloh1300, Lloh1301
	.loh AdrpAdrp	Lloh1298, Lloh1300
	.loh AdrpLdr	Lloh1298, Lloh1299
	.loh AdrpLdr	Lloh1296, Lloh1297
	.loh AdrpAdrp	Lloh1294, Lloh1296
	.loh AdrpLdr	Lloh1294, Lloh1295
	.loh AdrpAdrp	Lloh1292, Lloh1294
	.loh AdrpLdr	Lloh1292, Lloh1293
	.loh AdrpAdrp	Lloh1290, Lloh1292
	.loh AdrpLdr	Lloh1290, Lloh1291
	.loh AdrpLdr	Lloh1288, Lloh1289
	.loh AdrpAdrp	Lloh1286, Lloh1288
	.loh AdrpLdr	Lloh1286, Lloh1287
	.loh AdrpAdrp	Lloh1284, Lloh1286
	.loh AdrpLdr	Lloh1284, Lloh1285
	.loh AdrpAdrp	Lloh1282, Lloh1284
	.loh AdrpLdr	Lloh1282, Lloh1283
	.loh AdrpLdr	Lloh1280, Lloh1281
	.loh AdrpAdrp	Lloh1278, Lloh1280
	.loh AdrpLdr	Lloh1278, Lloh1279
	.loh AdrpAdrp	Lloh1276, Lloh1278
	.loh AdrpLdr	Lloh1276, Lloh1277
	.loh AdrpAdrp	Lloh1274, Lloh1276
	.loh AdrpLdr	Lloh1274, Lloh1275
	.loh AdrpLdr	Lloh1272, Lloh1273
	.loh AdrpAdrp	Lloh1270, Lloh1272
	.loh AdrpLdr	Lloh1270, Lloh1271
	.loh AdrpAdrp	Lloh1268, Lloh1270
	.loh AdrpLdr	Lloh1268, Lloh1269
	.loh AdrpAdrp	Lloh1266, Lloh1268
	.loh AdrpLdr	Lloh1266, Lloh1267
	.loh AdrpLdr	Lloh1264, Lloh1265
	.loh AdrpAdrp	Lloh1262, Lloh1264
	.loh AdrpLdr	Lloh1262, Lloh1263
	.loh AdrpAdrp	Lloh1260, Lloh1262
	.loh AdrpLdr	Lloh1260, Lloh1261
	.loh AdrpAdrp	Lloh1258, Lloh1260
	.loh AdrpLdr	Lloh1258, Lloh1259
	.loh AdrpLdr	Lloh1256, Lloh1257
	.loh AdrpAdrp	Lloh1254, Lloh1256
	.loh AdrpLdr	Lloh1254, Lloh1255
	.loh AdrpAdrp	Lloh1252, Lloh1254
	.loh AdrpLdr	Lloh1252, Lloh1253
	.loh AdrpAdrp	Lloh1250, Lloh1252
	.loh AdrpLdr	Lloh1250, Lloh1251
	.loh AdrpLdr	Lloh1248, Lloh1249
	.loh AdrpAdrp	Lloh1246, Lloh1248
	.loh AdrpLdr	Lloh1246, Lloh1247
	.loh AdrpAdrp	Lloh1244, Lloh1246
	.loh AdrpLdr	Lloh1244, Lloh1245
	.loh AdrpAdrp	Lloh1242, Lloh1244
	.loh AdrpLdr	Lloh1242, Lloh1243
	.loh AdrpLdr	Lloh1240, Lloh1241
	.loh AdrpAdrp	Lloh1238, Lloh1240
	.loh AdrpLdr	Lloh1238, Lloh1239
	.loh AdrpAdrp	Lloh1236, Lloh1238
	.loh AdrpLdr	Lloh1236, Lloh1237
	.loh AdrpAdrp	Lloh1234, Lloh1236
	.loh AdrpLdr	Lloh1234, Lloh1235
	.loh AdrpLdr	Lloh1232, Lloh1233
	.loh AdrpAdrp	Lloh1230, Lloh1232
	.loh AdrpLdr	Lloh1230, Lloh1231
	.loh AdrpAdrp	Lloh1228, Lloh1230
	.loh AdrpLdr	Lloh1228, Lloh1229
	.loh AdrpAdrp	Lloh1226, Lloh1228
	.loh AdrpLdr	Lloh1226, Lloh1227
	.loh AdrpLdr	Lloh1224, Lloh1225
	.loh AdrpAdrp	Lloh1222, Lloh1224
	.loh AdrpLdr	Lloh1222, Lloh1223
	.loh AdrpAdrp	Lloh1220, Lloh1222
	.loh AdrpLdr	Lloh1220, Lloh1221
	.loh AdrpAdrp	Lloh1218, Lloh1220
	.loh AdrpLdr	Lloh1218, Lloh1219
	.loh AdrpLdr	Lloh1216, Lloh1217
	.loh AdrpAdrp	Lloh1214, Lloh1216
	.loh AdrpLdr	Lloh1214, Lloh1215
	.loh AdrpAdrp	Lloh1212, Lloh1214
	.loh AdrpLdr	Lloh1212, Lloh1213
	.loh AdrpAdrp	Lloh1210, Lloh1212
	.loh AdrpLdr	Lloh1210, Lloh1211
	.loh AdrpLdr	Lloh1208, Lloh1209
	.loh AdrpAdrp	Lloh1206, Lloh1208
	.loh AdrpLdr	Lloh1206, Lloh1207
	.loh AdrpAdrp	Lloh1204, Lloh1206
	.loh AdrpLdr	Lloh1204, Lloh1205
	.loh AdrpAdrp	Lloh1202, Lloh1204
	.loh AdrpLdr	Lloh1202, Lloh1203
	.loh AdrpLdr	Lloh1200, Lloh1201
	.loh AdrpAdrp	Lloh1198, Lloh1200
	.loh AdrpLdr	Lloh1198, Lloh1199
	.loh AdrpAdrp	Lloh1196, Lloh1198
	.loh AdrpLdr	Lloh1196, Lloh1197
	.loh AdrpAdrp	Lloh1194, Lloh1196
	.loh AdrpLdr	Lloh1194, Lloh1195
	.loh AdrpLdr	Lloh1192, Lloh1193
	.loh AdrpAdrp	Lloh1190, Lloh1192
	.loh AdrpLdr	Lloh1190, Lloh1191
	.loh AdrpAdrp	Lloh1188, Lloh1190
	.loh AdrpLdr	Lloh1188, Lloh1189
	.loh AdrpAdrp	Lloh1186, Lloh1188
	.loh AdrpLdr	Lloh1186, Lloh1187
	.loh AdrpLdr	Lloh1184, Lloh1185
	.loh AdrpAdrp	Lloh1182, Lloh1184
	.loh AdrpLdr	Lloh1182, Lloh1183
	.loh AdrpAdrp	Lloh1180, Lloh1182
	.loh AdrpLdr	Lloh1180, Lloh1181
	.loh AdrpAdrp	Lloh1178, Lloh1180
	.loh AdrpLdr	Lloh1178, Lloh1179
	.loh AdrpLdr	Lloh1176, Lloh1177
	.loh AdrpAdrp	Lloh1174, Lloh1176
	.loh AdrpLdr	Lloh1174, Lloh1175
	.loh AdrpAdrp	Lloh1172, Lloh1174
	.loh AdrpLdr	Lloh1172, Lloh1173
	.loh AdrpAdrp	Lloh1170, Lloh1172
	.loh AdrpLdr	Lloh1170, Lloh1171
	.loh AdrpLdr	Lloh1168, Lloh1169
	.loh AdrpAdrp	Lloh1166, Lloh1168
	.loh AdrpLdr	Lloh1166, Lloh1167
	.loh AdrpAdrp	Lloh1164, Lloh1166
	.loh AdrpLdr	Lloh1164, Lloh1165
	.loh AdrpAdrp	Lloh1162, Lloh1164
	.loh AdrpLdr	Lloh1162, Lloh1163
	.loh AdrpLdr	Lloh1160, Lloh1161
	.loh AdrpAdrp	Lloh1158, Lloh1160
	.loh AdrpLdr	Lloh1158, Lloh1159
	.loh AdrpAdrp	Lloh1156, Lloh1158
	.loh AdrpLdr	Lloh1156, Lloh1157
	.loh AdrpAdrp	Lloh1154, Lloh1156
	.loh AdrpLdr	Lloh1154, Lloh1155
	.loh AdrpLdr	Lloh1152, Lloh1153
	.loh AdrpAdrp	Lloh1150, Lloh1152
	.loh AdrpLdr	Lloh1150, Lloh1151
	.loh AdrpAdrp	Lloh1148, Lloh1150
	.loh AdrpLdr	Lloh1148, Lloh1149
	.loh AdrpAdrp	Lloh1146, Lloh1148
	.loh AdrpLdr	Lloh1146, Lloh1147
	.loh AdrpLdr	Lloh1144, Lloh1145
	.loh AdrpAdrp	Lloh1142, Lloh1144
	.loh AdrpLdr	Lloh1142, Lloh1143
	.loh AdrpAdrp	Lloh1140, Lloh1142
	.loh AdrpLdr	Lloh1140, Lloh1141
	.loh AdrpAdrp	Lloh1138, Lloh1140
	.loh AdrpLdr	Lloh1138, Lloh1139
	.loh AdrpLdr	Lloh1136, Lloh1137
	.loh AdrpAdrp	Lloh1134, Lloh1136
	.loh AdrpLdr	Lloh1134, Lloh1135
	.loh AdrpAdrp	Lloh1132, Lloh1134
	.loh AdrpLdr	Lloh1132, Lloh1133
	.loh AdrpAdrp	Lloh1130, Lloh1132
	.loh AdrpLdr	Lloh1130, Lloh1131
	.loh AdrpLdr	Lloh1400, Lloh1401
	.loh AdrpAdrp	Lloh1398, Lloh1400
	.loh AdrpLdr	Lloh1398, Lloh1399
	.loh AdrpAdrp	Lloh1396, Lloh1398
	.loh AdrpLdr	Lloh1396, Lloh1397
	.loh AdrpAdrp	Lloh1394, Lloh1396
	.loh AdrpLdr	Lloh1394, Lloh1395
	.loh AdrpAdd	Lloh1402, Lloh1403
	.section	__TEXT,__const
	.p2align	1, 0x0
LJTI0_0:
	.short	(LBB0_10-LBB0_10)>>2
	.short	(LBB0_163-LBB0_10)>>2
	.short	(LBB0_67-LBB0_10)>>2
	.short	(LBB0_172-LBB0_10)>>2
	.short	(LBB0_65-LBB0_10)>>2
	.short	(LBB0_47-LBB0_10)>>2
	.short	(LBB0_148-LBB0_10)>>2
	.short	(LBB0_225-LBB0_10)>>2
	.short	(LBB0_234-LBB0_10)>>2
	.short	(LBB0_64-LBB0_10)>>2
	.short	(LBB0_29-LBB0_10)>>2
	.short	(LBB0_143-LBB0_10)>>2
	.short	(LBB0_304-LBB0_10)>>2
	.short	(LBB0_312-LBB0_10)>>2
	.short	(LBB0_107-LBB0_10)>>2
	.short	(LBB0_370-LBB0_10)>>2
	.short	(LBB0_378-LBB0_10)>>2
	.short	(LBB0_105-LBB0_10)>>2
	.short	(LBB0_86-LBB0_10)>>2
	.short	(LBB0_158-LBB0_10)>>2
	.short	(LBB0_447-LBB0_10)>>2
	.short	(LBB0_457-LBB0_10)>>2
	.short	(LBB0_103-LBB0_10)>>2
	.short	(LBB0_515-LBB0_10)>>2
	.short	(LBB0_523-LBB0_10)>>2
	.short	(LBB0_106-LBB0_10)>>2
	.short	(LBB0_12-LBB0_10)>>2
	.short	(LBB0_582-LBB0_10)>>2
	.short	(LBB0_573-LBB0_10)>>2
	.short	(LBB0_606-LBB0_10)>>2
	.short	(LBB0_66-LBB0_10)>>2
	.short	(LBB0_664-LBB0_10)>>2
	.short	(LBB0_672-LBB0_10)>>2
	.short	(LBB0_104-LBB0_10)>>2
	.short	(LBB0_125-LBB0_10)>>2
	.short	(LBB0_722-LBB0_10)>>2
	.short	(LBB0_747-LBB0_10)>>2
	.short	(LBB0_755-LBB0_10)>>2
	.short	(LBB0_46-LBB0_10)>>2
	.short	(LBB0_813-LBB0_10)>>2
	.short	(LBB0_821-LBB0_10)>>2
	.short	(LBB0_68-LBB0_10)>>2
	.short	(LBB0_69-LBB0_10)>>2
	.short	(LBB0_153-LBB0_10)>>2
	.short	(LBB0_890-LBB0_10)>>2
	.short	(LBB0_899-LBB0_10)>>2
	.short	(LBB0_11-LBB0_10)>>2
	.short	(LBB0_973-LBB0_10)>>2
	.short	(LBB0_982-LBB0_10)>>2
	.short	(LBB0_142-LBB0_10)>>2
	.short	(LBB0_108-LBB0_10)>>2
	.short	(LBB0_1038-LBB0_10)>>2
	.short	(LBB0_1029-LBB0_10)>>2
	.short	(LBB0_1065-LBB0_10)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_tile_inclusive_scan.packet_batch ; -- Begin function tile_inclusive_scan.packet_batch
	.p2align	2
_tile_inclusive_scan.packet_batch:      ; @tile_inclusive_scan.packet_batch
; %bb.0:                                ; %packet.batch.prologue
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	mov	x21, x3
	mov	x19, x2
	mov	x20, x0
	ldr	w23, [x2, #36]
	ldr	w8, [x2]
	ldr	w9, [x2, #12]
	lsl	x8, x8, #5
	cmp	x8, x9
	csel	x10, x8, xzr, ls
	add	x10, x10, x23
	subs	x11, x9, x10
	mov	w12, #32                        ; =0x20
	sub	x13, x12, x23
	cmp	x11, x13
	csel	x11, x11, x13, lo
	cmp	x9, x10
	ccmp	x23, x12, #2, hi
	ccmp	x8, x9, #2, lo
	csel	x8, x11, xzr, ls
	cmp	w3, #4
	b.ne	LBB1_3
; %bb.1:                                ; %packet.batch.prologue
	cmp	x8, #32
	b.lo	LBB1_3
; %bb.2:                                ; %packet.batch.full
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	add	w8, w23, #8
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	add	w8, w23, #16
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	add	w8, w23, #24
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	b	_tile_inclusive_scan
LBB1_3:                                 ; %packet.batch.partial
	ubfiz	x9, x21, #3, #32
	cmp	x8, x9
	csel	x8, x8, x9, lo
	lsr	x24, x8, #3
	and	w22, w8, #0x7
	cmp	x8, #8
	b.lo	LBB1_6
; %bb.4:                                ; %packet.batch.partial.full.loop.preheader
	mov	x25, x24
	mov	x26, x23
LBB1_5:                                 ; %packet.batch.partial.full.loop
                                        ; =>This Inner Loop Header: Depth=1
	str	w26, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	add	w26, w26, #8
	subs	w25, w25, #1
	b.ne	LBB1_5
LBB1_6:                                 ; %packet.batch.tail.check
	cbz	w22, LBB1_8
; %bb.7:                                ; %packet.batch.tail.call
	add	w8, w23, w24, lsl #3
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	x2, x22
	bl	_tile_inclusive_scan
LBB1_8:                                 ; %packet.batch.partial.finish
	lsl	w8, w21, #3
	sub	w8, w8, #8
	cmp	w21, #0
	csel	w8, wzr, w8, eq
	add	w8, w23, w8
	str	w8, [x19, #36]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.section	__TEXT,__const
	.p2align	2, 0x0                          ; @convergence.targets
l_convergence.targets:
	.long	53                              ; 0x35
	.long	7                               ; 0x7
	.long	6                               ; 0x6
	.long	12                              ; 0xc
	.long	11                              ; 0xb
	.long	15                              ; 0xf
	.long	20                              ; 0x14
	.long	19                              ; 0x13
	.long	23                              ; 0x17
	.long	28                              ; 0x1c
	.long	27                              ; 0x1b
	.long	31                              ; 0x1f
	.long	36                              ; 0x24
	.long	35                              ; 0x23
	.long	39                              ; 0x27
	.long	44                              ; 0x2c
	.long	43                              ; 0x2b
	.long	47                              ; 0x2f
	.long	52                              ; 0x34
	.long	51                              ; 0x33

.subsections_via_symbols

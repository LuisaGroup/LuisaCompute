	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function tile_transpose
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_4:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_5:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_6:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_7:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_3:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_tile_transpose:                        ; @tile_transpose
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	sub	x9, sp, #2, lsl #12             ; =8192
	sub	x9, x9, #1824
	and	sp, x9, #0xffffffffffffffc0
	fmov	s1, wzr
	add	x8, sp, #2, lsl #12             ; =8192
	add	x8, x8, #1704
	str	wzr, [sp, #9980]
	stur	wzr, [x8, #81]
	stur	xzr, [x8, #52]
	stur	xzr, [x8, #68]
	stur	xzr, [x8, #60]
	str	wzr, [sp, #9972]
	stur	xzr, [x8, #20]
	stur	xzr, [x8, #36]
	stur	xzr, [x8, #28]
	str	wzr, [sp, #9940]
	str	xzr, [sp, #9904]
	str	xzr, [sp, #9896]
	movi.2d	v31, #0000000000000000
	str	q31, [sp, #1648]
	str	q31, [sp, #1632]
	str	q31, [sp, #1616]
	str	q31, [sp, #1600]
	str	q31, [sp, #1584]
	str	q31, [sp, #1536]
	str	q31, [sp, #1552]
	str	q31, [sp, #1568]
	str	q31, [sp, #1520]
	str	q31, [sp, #1472]
	str	q31, [sp, #1488]
	str	q31, [sp, #1440]
	str	q31, [sp, #1456]
	str	q31, [sp, #1408]
	str	q31, [sp, #1424]
	str	q31, [sp, #1504]
	str	q31, [sp, #1392]
	str	q31, [sp, #1344]
	str	q31, [sp, #1360]
	str	q31, [sp, #1376]
	str	q31, [sp, #1328]
	str	q31, [sp, #1280]
	str	q31, [sp, #1296]
	str	q31, [sp, #1312]
	str	q31, [sp, #1264]
	str	q31, [sp, #1248]
	ldr	x10, [x0]
	ldr	x9, [x0, #16]
	stp	x10, x9, [sp, #176]             ; 16-byte Folded Spill
	ldr	w9, [x1]
	ldr	w11, [x1, #36]
	dup.4s	v3, w2
Lloh0:
	adrp	x10, lCPI0_0@PAGE
Lloh1:
	ldr	q2, [x10, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x10, lCPI0_1@PAGE
Lloh3:
	ldr	q4, [x10, lCPI0_1@PAGEOFF]
	cmhi.4s	v5, v3, v4
	cmhi.4s	v3, v3, v2
	uzp1.8h	v3, v3, v5
Lloh4:
	adrp	x10, lCPI0_2@PAGE
Lloh5:
	ldr	q5, [x10, lCPI0_2@PAGEOFF]
	and.16b	v5, v3, v5
	addv.8h	h5, v5
	fmov	w10, s5
	and	w10, w10, #0xff
	fmov	s5, w10
	cmeq.8b	v1, v5, v1
	umov.b	w10, v1[0]
	and	w12, w10, #0x1
	fmov	s5, w12
	ubfx	w12, w10, #1, #1
	mov.b	v5[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v5[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v5[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v5[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v5[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v5[6], w12
	xtn.8b	v1, v3
	ubfx	w10, w10, #7, #1
	mov.b	v5[7], w10
	movi.8b	v6, #1
	eor.8b	v5, v5, v6
	and.8b	v5, v5, v1
	umaxv.8h	h3, v3
	fmov	w10, s3
	shl.8b	v3, v5, #7
	cmlt.8b	v5, v3, #0
Lloh6:
	adrp	x12, lCPI0_3@PAGE
Lloh7:
	ldr	d3, [x12, lCPI0_3@PAGEOFF]
	and.8b	v5, v5, v3
	addv.8b	b5, v5
	str	b5, [x8, #80]
	str	wzr, [sp, #9944]
	str	wzr, [sp, #9912]
	tbz	w10, #0, LBB0_197
; %bb.1:                                ; %scheduler.dispatch.lr.ph
	stp	xzr, xzr, [sp, #96]             ; 16-byte Folded Spill
	stp	xzr, xzr, [sp, #80]             ; 16-byte Folded Spill
	stp	xzr, xzr, [sp, #64]             ; 16-byte Folded Spill
	stp	xzr, xzr, [sp, #48]             ; 16-byte Folded Spill
	mov	w27, #0                         ; =0x0
	add	x10, sp, #1704
	dup.2d	v0, x10
	add	w9, w11, w9, lsl #6
	dup.4s	v5, w9
	add.4s	v4, v5, v4
	stp	q4, q0, [sp, #128]              ; 32-byte Folded Spill
	add.4s	v2, v5, v2
	str	q2, [sp, #112]                  ; 16-byte Folded Spill
	mov	w11, #1                         ; =0x1
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #1784
	add	x7, sp, #2, lsl #12             ; =8192
	add	x7, x7, #1752
	add	x14, sp, #2, lsl #12            ; =8192
	add	x14, x14, #1720
Lloh8:
	adrp	x19, LJTI0_0@PAGE
Lloh9:
	add	x19, x19, LJTI0_0@PAGEOFF
	mov	w22, #256                       ; =0x100
	add	x20, sp, #2, lsl #12            ; =8192
	add	x20, x20, #1712
	add	x1, sp, #672
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v0, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v14, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v12, #0000000000000000
	movi.2d	v11, #0000000000000000
	movi.2d	v10, #0000000000000000
	movi.2d	v9, #0000000000000000
	mov	w3, #-1                         ; =0xffffffff
	add	x5, sp, #640
	add	x2, sp, #1200
	add	x4, sp, #1168
	add	x16, sp, #1056
	add	x0, sp, #1024
	mov	w30, #1                         ; =0x1
	b	LBB0_5
LBB0_2:                                 ; %ready.overflow.resume84
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b5, [x6, w30, uxtw]
	orr	w27, w23, w27
	mov	w10, #9                         ; =0x9
LBB0_3:                                 ; %scheduler.loop.backedge
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	w10, [x7, w30, uxtw #2]
	add	w28, w30, #1
	str	w9, [x14, w30, uxtw #2]
LBB0_4:                                 ; %scheduler.loop.backedge
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	x30, x28
	cbz	w28, LBB0_197
LBB0_5:                                 ; %scheduler.dispatch
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_81 Depth 2
                                        ;     Child Loop BB0_161 Depth 2
                                        ;     Child Loop BB0_191 Depth 2
                                        ;     Child Loop BB0_75 Depth 2
	sub	w28, w30, #1
	ldr	w10, [x7, w28, sxtw #2]
	cmp	w10, #10
	b.hi	LBB0_199
; %bb.6:                                ; %scheduler.dispatch
                                        ;   in Loop: Header=BB0_5 Depth=1
	sxtw	x21, w28
	ldrb	w9, [x6, x21]
	and	w17, w9, #0x1
	fmov	s13, w17
	ubfx	w17, w9, #1, #1
	mov.b	v13[1], w17
	ubfx	w17, w9, #2, #1
	mov.b	v13[2], w17
	ubfx	w17, w9, #3, #1
	mov.b	v13[3], w17
	ubfx	w17, w9, #4, #1
	mov.b	v13[4], w17
	ubfx	w17, w9, #5, #1
	mov.b	v13[5], w17
	ubfx	w17, w9, #6, #1
	mov.b	v13[6], w17
	lsr	w9, w9, #7
	mov.b	v13[7], w9
	ldr	w17, [x14, w28, sxtw #2]
	adr	x9, LBB0_7
	ldrh	w23, [x19, x10, lsl #1]
	add	x9, x9, x23, lsl #2
	br	x9
LBB0_7:                                 ; %schedule.0
                                        ;   in Loop: Header=BB0_5 Depth=1
	zip1.8b	v2, v13, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #112]                  ; 16-byte Folded Reload
	and.16b	v5, v2, v4
	zip2.8b	v4, v13, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v6, v4, #0
	ldr	q4, [sp, #128]                  ; 16-byte Folded Reload
	and.16b	v4, v6, v4
	movi.4s	v16, #9
	and.16b	v7, v6, v16
	mvn.16b	v6, v6
	sub.4s	v6, v7, v6
	mov.s	w9, v6[1]
	and.16b	v7, v2, v16
	mov.s	w10, v4[1]
	udiv	w9, w10, w9
	fmov	w10, s6
	fmov	w23, s4
	udiv	w10, w23, w10
	fmov	s17, w10
	mov.s	v17[1], w9
	mov.s	w23, v6[2]
	mvn.16b	v2, v2
	mov.s	w24, v4[2]
	udiv	w23, w24, w23
	mov.s	v17[2], w23
	sub.4s	v7, v7, v2
	mov.s	w24, v6[3]
	mov.s	w25, v4[3]
	udiv	w24, w25, w24
	mov.s	v17[3], w24
	mov.s	w25, v7[1]
	mov.s	w26, v5[1]
	fmov	w4, s7
	fmov	w2, s5
	udiv	w2, w2, w4
	fmov	s16, w2
	udiv	w4, w26, w25
	mov.s	v16[1], w4
	mov.s	w25, v7[2]
	mov.s	w26, v5[2]
	udiv	w25, w26, w25
	mov.s	v16[2], w25
	mov.s	w26, v7[3]
	mov.s	w15, v5[3]
	udiv	w15, w15, w26
	mov.s	v16[3], w15
	fmov	s2, w10
	mov.s	v2[1], w9
	fmov	s18, w25
	mov.s	v18[1], w15
	fmov	s19, w2
	mov.s	v19[1], w4
	fmov	s21, w23
	mov.s	v21[1], w24
	mls.4s	v4, v17, v6
	ushll.2d	v21, v21, #4
	ushll.2d	v19, v19, #4
	ushll.2d	v2, v2, #4
	ldr	q22, [sp, #1648]
	mov.16b	v29, v23
	ldr	q23, [sp, #1600]
	ldr	q17, [sp, #1616]
	mov.16b	v8, v14
	ldr	q14, [sp, #1632]
	mov	b6, v13[4]
	mov.b	v6[4], v13[5]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	bit.16b	v14, v2, v6
	mov	b2, v13[2]
	mov.b	v2[4], v13[3]
	ushll.2d	v18, v18, #4
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v2, v2, #0
	mov.16b	v15, v2
	bsl.16b	v15, v18, v17
	mov	b17, v13[0]
	mov.b	v17[4], v13[1]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	bif.16b	v19, v23, v17
	mov	b18, v13[6]
	mov.b	v18[4], v13[7]
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	bif.16b	v21, v22, v18
	str	q21, [sp, #1648]
	str	q19, [sp, #1600]
	str	q15, [sp, #1616]
	str	q14, [sp, #1632]
	mls.4s	v5, v16, v7
	shl.4s	v5, v5, #4
	ldr	q7, [sp, #1584]
	ldr	q16, [sp, #1552]
	ldr	q19, [sp, #1568]
	ldr	q21, [sp, #1536]
	shl.4s	v4, v4, #4
	ushll2.2d	v22, v4, #0
	ushll2.2d	v23, v5, #0
	ushll.2d	v4, v4, #0
	bif.16b	v4, v19, v6
	bit.16b	v16, v23, v2
	bit.16b	v7, v22, v18
	str	q7, [sp, #1584]
	str	q16, [sp, #1552]
	str	q4, [sp, #1568]
	ushll.2d	v4, v5, #0
	bif.16b	v4, v21, v17
	str	q4, [sp, #1536]
	ldr	q4, [sp, #1472]
	ldr	q5, [sp, #1488]
	ldr	q7, [sp, #1520]
	ldr	q16, [sp, #1504]
	shl.8b	v19, v13, #7
	ldr	q21, [sp, #1408]
	ldr	q22, [sp, #1424]
	cmlt.8b	v19, v19, #0
	umaxv.8b	b19, v19
	fmov	w9, s19
	ldr	q19, [sp, #1456]
	ldr	q23, [sp, #1440]
Lloh10:
	adrp	x10, lCPI0_6@PAGE
Lloh11:
	ldr	q14, [x10, lCPI0_6@PAGEOFF]
	bit.16b	v5, v14, v2
Lloh12:
	adrp	x10, lCPI0_7@PAGE
Lloh13:
	ldr	q14, [x10, lCPI0_7@PAGEOFF]
	bit.16b	v4, v14, v17
Lloh14:
	adrp	x10, lCPI0_4@PAGE
Lloh15:
	ldr	q14, [x10, lCPI0_4@PAGEOFF]
	str	q4, [sp, #1472]
Lloh16:
	adrp	x10, lCPI0_5@PAGE
Lloh17:
	ldr	q4, [x10, lCPI0_5@PAGEOFF]
	str	q5, [sp, #1488]
	ldr	q20, [sp, #144]                 ; 16-byte Folded Reload
	mov.16b	v5, v6
	bsl.16b	v5, v20, v23
	bit.16b	v19, v20, v18
	bit.16b	v22, v20, v2
	bit.16b	v16, v14, v6
	bif.16b	v4, v7, v18
	str	q4, [sp, #1520]
	str	q16, [sp, #1504]
	mov.16b	v4, v17
	bsl.16b	v4, v20, v21
	str	q4, [sp, #1408]
	str	q22, [sp, #1424]
	str	q19, [sp, #1456]
	str	q5, [sp, #1440]
	bic.16b	v28, v28, v18
	bic.16b	v27, v27, v6
	bic.16b	v14, v8, v2
	bic.16b	v23, v29, v17
	add	x2, sp, #1200
	add	x4, sp, #1168
	tbnz	w9, #0, LBB0_44
	b	LBB0_4
LBB0_8:                                 ; %scheduler.dispatch.schedule.7_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v2, v13, #7
	cmlt.8b	v2, v2, #0
	umaxv.8b	b2, v2
	fmov	w9, s2
	eor	w23, w9, #0x1
	b	LBB0_126
LBB0_9:                                 ; %scheduler.dispatch.schedule.2_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v2, v13, #7
	cmlt.8b	v2, v2, #0
	umaxv.8b	b2, v2
	fmov	w9, s2
	eor	w23, w9, #0x1
	b	LBB0_54
LBB0_10:                                ; %schedule.8
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v2, v13, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w9, s2
	ldr	q4, [sp, #1328]
	ldr	q6, [sp, #1312]
	ldr	q16, [sp, #1296]
	ldr	q5, [sp, #1280]
	ldr	q2, [sp, #1264]
	ldr	q7, [sp, #1248]
	shl.2d	v17, v5, #2
	ldr	x10, [sp, #184]                 ; 8-byte Folded Reload
	dup.2d	v5, x10
	add.2d	v17, v5, v17
	tbnz	w9, #0, LBB0_29
; %bb.11:                               ; %else120
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #1, LBB0_30
LBB0_12:                                ; %else123
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.2d	v16, v16, #2
	add.2d	v16, v5, v16
	tbnz	w9, #2, LBB0_31
LBB0_13:                                ; %else126
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #3, LBB0_32
LBB0_14:                                ; %else129
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.2d	v6, v6, #2
	add.2d	v6, v5, v6
	tbnz	w9, #4, LBB0_33
LBB0_15:                                ; %else132
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #5, LBB0_34
LBB0_16:                                ; %else135
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.2d	v4, v4, #2
	add.2d	v4, v5, v4
	tbnz	w9, #6, LBB0_35
LBB0_17:                                ; %else138
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #7, LBB0_36
LBB0_18:                                ; %else141
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w9, #0xff
	b.ne	LBB0_189
	b	LBB0_4
LBB0_19:                                ; %schedule.3
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v2, v13, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w23, s2
	ldr	q6, [sp, #1392]
	ldr	q7, [sp, #1376]
	ldr	q16, [sp, #1360]
	ldr	q2, [sp, #1344]
	shl.2d	v4, v2, #2
	ldr	x9, [sp, #176]                  ; 8-byte Folded Reload
	dup.2d	v2, x9
	add.2d	v17, v2, v4
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbnz	w23, #0, LBB0_37
; %bb.20:                               ; %else
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w23, #1, LBB0_38
LBB0_21:                                ; %else49
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.2d	v16, v16, #2
	add.2d	v16, v2, v16
	tbnz	w23, #2, LBB0_39
LBB0_22:                                ; %else52
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w23, #3, LBB0_40
LBB0_23:                                ; %else55
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.2d	v7, v7, #2
	add.2d	v7, v2, v7
	tbnz	w23, #4, LBB0_41
LBB0_24:                                ; %else58
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w23, #5, LBB0_42
LBB0_25:                                ; %else61
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.2d	v6, v6, #2
	add.2d	v2, v2, v6
	tbnz	w23, #6, LBB0_43
LBB0_26:                                ; %else64
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w23, #7, LBB0_28
LBB0_27:                                ; %cond.load66
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x9, v2[1]
	ld1.s	{ v5 }[3], [x9]
LBB0_28:                                ; %else67
                                        ;   in Loop: Header=BB0_5 Depth=1
	zip2.8b	v2, v13, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	bit.16b	v30, v5, v2
	zip1.8b	v2, v13, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	bit.16b	v0, v4, v2
	tst	w23, #0xff
	b.ne	LBB0_73
	b	LBB0_4
LBB0_29:                                ; %cond.store
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d17
	str	s7, [x10]
	tbz	w9, #1, LBB0_12
LBB0_30:                                ; %cond.store121
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v17[1]
	st1.s	{ v7 }[1], [x10]
	shl.2d	v16, v16, #2
	add.2d	v16, v5, v16
	tbz	w9, #2, LBB0_13
LBB0_31:                                ; %cond.store124
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d16
	st1.s	{ v7 }[2], [x10]
	tbz	w9, #3, LBB0_14
LBB0_32:                                ; %cond.store127
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v16[1]
	st1.s	{ v7 }[3], [x10]
	shl.2d	v6, v6, #2
	add.2d	v6, v5, v6
	tbz	w9, #4, LBB0_15
LBB0_33:                                ; %cond.store130
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d6
	str	s2, [x10]
	tbz	w9, #5, LBB0_16
LBB0_34:                                ; %cond.store133
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v6[1]
	st1.s	{ v2 }[1], [x10]
	shl.2d	v4, v4, #2
	add.2d	v4, v5, v4
	tbz	w9, #6, LBB0_17
LBB0_35:                                ; %cond.store136
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d4
	st1.s	{ v2 }[2], [x10]
	tbz	w9, #7, LBB0_18
LBB0_36:                                ; %cond.store139
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v4[1]
	st1.s	{ v2 }[3], [x10]
	tst	w9, #0xff
	b.ne	LBB0_189
	b	LBB0_4
LBB0_37:                                ; %cond.load
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x9, d17
	ldr	s4, [x9]
	tbz	w23, #1, LBB0_21
LBB0_38:                                ; %cond.load48
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x9, v17[1]
	ld1.s	{ v4 }[1], [x9]
	shl.2d	v16, v16, #2
	add.2d	v16, v2, v16
	tbz	w23, #2, LBB0_22
LBB0_39:                                ; %cond.load51
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x9, d16
	ld1.s	{ v4 }[2], [x9]
	tbz	w23, #3, LBB0_23
LBB0_40:                                ; %cond.load54
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x9, v16[1]
	ld1.s	{ v4 }[3], [x9]
	shl.2d	v7, v7, #2
	add.2d	v7, v2, v7
	tbz	w23, #4, LBB0_24
LBB0_41:                                ; %cond.load57
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x9, d7
	ld1.s	{ v5 }[0], [x9]
	tbz	w23, #5, LBB0_25
LBB0_42:                                ; %cond.load60
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x9, v7[1]
	ld1.s	{ v5 }[1], [x9]
	shl.2d	v6, v6, #2
	add.2d	v2, v2, v6
	tbz	w23, #6, LBB0_26
LBB0_43:                                ; %cond.load63
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x9, d2
	ld1.s	{ v5 }[2], [x9]
	tbnz	w23, #7, LBB0_27
	b	LBB0_28
LBB0_44:                                ; %schedule.1
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v2, v13, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w9, s2
	dup.2d	v2, x22
	cmgt.2d	v4, v2, v14
	cmgt.2d	v5, v2, v23
	uzp1.4s	v4, v5, v4
	cmgt.2d	v5, v2, v27
	cmgt.2d	v6, v2, v28
	uzp1.4s	v5, v5, v6
	uzp1.8h	v4, v4, v5
	xtn.8b	v4, v4
	and.8b	v4, v13, v4
	shl.8b	v4, v4, #7
	cmlt.8b	v5, v4, #0
	and.8b	v4, v5, v3
	addv.8b	b4, v4
	fmov	w10, s4
	umaxv.8b	b5, v5
	fmov	w15, s5
	tbz	w15, #0, LBB0_51
; %bb.45:                               ; %schedule.1
                                        ;   in Loop: Header=BB0_5 Depth=1
	cmge.2d	v5, v14, v2
	cmge.2d	v6, v23, v2
	uzp1.4s	v5, v6, v5
	cmge.2d	v6, v27, v2
	cmge.2d	v2, v28, v2
	uzp1.4s	v2, v6, v2
	uzp1.8h	v2, v5, v2
	xtn.8b	v2, v2
	and.8b	v2, v13, v2
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b5, v2
	fmov	w15, s5
	tst	w15, #0xff
	b.eq	LBB0_51
; %bb.46:                               ; %varying.divergent
                                        ;   in Loop: Header=BB0_5 Depth=1
	subs	w9, w17, #1
	csel	w9, wzr, w9, lo
	and	w12, w27, #0xff
	lsr	w10, w12, w9
	tst	w10, #0x1
	stp	q10, q9, [sp, #448]
	and	x9, x9, #0x7
	add	x10, sp, #448
	ldr	w9, [x10, x9, lsl #2]
	ccmp	w17, #0, #4, ne
	ccmp	w9, #0, #0, ne
	cset	w10, ne
	cmp	w12, #255
	b.ne	LBB0_48
; %bb.47:                               ; %varying.divergent
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #0, LBB0_199
LBB0_48:                                ; %convergence.overflow.resume
                                        ;   in Loop: Header=BB0_5 Depth=1
	mvn	w9, w27
	rbit	w9, w9
	clz	w9, w9
	mov	w12, #255                       ; =0xff
	bics	wzr, w12, w27
	csel	w9, wzr, w9, eq
	ubfiz	x12, x9, #2, #3
	lsl	w13, w11, w9
	stp	q10, q9, [sp, #416]
	add	x15, sp, #416
	ldr	w15, [x15, x12]
	cmp	w10, #0
	csel	w23, w13, wzr, ne
	csel	w10, wzr, w15, ne
	stp	q10, q9, [sp, #384]
	add	x13, sp, #384
	str	w10, [x13, x12]
	ldp	q10, q9, [sp, #384]
	stp	q12, q11, [sp, #352]
	add	x10, sp, #352
	ldr	w10, [x10, x12]
	csel	w10, w17, w10, ne
	stp	q12, q11, [sp, #320]
	add	x13, sp, #320
	str	w10, [x13, x12]
	ldrb	w10, [x20, x9]
	and	w12, w10, #0x1
	fmov	s2, w12
	ubfx	w12, w10, #1, #1
	mov.b	v2[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v2[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v2[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v2[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v2[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v2[6], w12
	ldp	q12, q11, [sp, #320]
	lsr	w10, w10, #7
	mov.b	v2[7], w10
	ldrb	w10, [x8, x9]
	and	w12, w10, #0x1
	fmov	s6, w12
	ubfx	w12, w10, #1, #1
	mov.b	v6[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v6[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v6[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v6[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v6[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v6[6], w12
	lsr	w10, w10, #7
	mov.b	v6[7], w10
	csetm	w10, ne
	dup.8b	v7, w10
	bit.8b	v2, v13, v7
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x20, x9]
	bic.8b	v2, v6, v7
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x8, x9]
	csinc	w9, w17, w9, eq
	cmp	w28, #8
	b.hs	LBB0_199
; %bb.49:                               ; %ready.overflow.resume18
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b4, [x6, x21]
	mov	w10, #2                         ; =0x2
	str	w10, [x7, x21, lsl #2]
	str	w9, [x14, x21, lsl #2]
	cmp	w30, #8
	b.hs	LBB0_199
; %bb.50:                               ; %ready.overflow.resume20
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b5, [x6, w30, uxtw]
	orr	w27, w23, w27
	mov	w10, #5                         ; =0x5
	b	LBB0_3
LBB0_51:                                ; %varying.coherent
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w10, #0xff
	b.eq	LBB0_78
; %bb.52:                               ; %varying.coherent.true
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w9, #0xff
	b.eq	LBB0_4
; %bb.53:                               ;   in Loop: Header=BB0_5 Depth=1
	mov	w23, #0                         ; =0x0
LBB0_54:                                ; %schedule.2
                                        ;   in Loop: Header=BB0_5 Depth=1
	stp	q24, q31, [sp, #288]            ; 32-byte Folded Spill
	mov.16b	v8, v30
	mov.16b	v24, v25
	mov.16b	v25, v26
	mov.16b	v26, v0
	mov	b2, v13[0]
	mov.b	v2[4], v13[1]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v4, v2, #0
	mov.16b	v29, v23
	and.16b	v7, v4, v23
	mov	b2, v13[2]
	mov.b	v2[4], v13[3]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v5, v2, #0
	mov	b2, v13[4]
	mov.b	v2[4], v13[5]
	mov.16b	v31, v14
	and.16b	v16, v5, v14
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v6, v2, #0
	mov.16b	v0, v27
	and.16b	v17, v6, v27
	mov	b2, v13[6]
	mov.b	v2[4], v13[7]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v14, v2, #0
	mov.16b	v30, v28
	and.16b	v18, v14, v28
	mov	w9, #16                         ; =0x10
	dup.2d	v21, x9
	and.16b	v2, v4, v21
	mvn.16b	v19, v4
	sub.2d	v2, v2, v19
	and.16b	v19, v5, v21
	mvn.16b	v22, v5
	sub.2d	v19, v19, v22
	and.16b	v22, v6, v21
	mvn.16b	v23, v6
	sub.2d	v22, v22, v23
	and.16b	v21, v14, v21
	mvn.16b	v23, v14
	sub.2d	v21, v21, v23
	mov.d	x9, v21[1]
	mov.d	x10, v18[1]
	sdiv	x24, x10, x9
	fmov	x10, d21
	fmov	x15, d18
	sdiv	x15, x15, x10
	mul	x10, x15, x10
	fmov	d21, x15
	mov.d	v21[1], x24
	mov.d	x15, v22[1]
	mov.d	x2, v17[1]
	sdiv	x2, x2, x15
	fmov	x4, d22
	fmov	x25, d17
	sdiv	x25, x25, x4
	mul	x4, x25, x4
	fmov	d22, x25
	mov.d	v22[1], x2
	mov.d	x25, v19[1]
	mov.d	x26, v16[1]
	sdiv	x26, x26, x25
	fmov	x13, d19
	fmov	x6, d16
	sdiv	x6, x6, x13
	mul	x13, x6, x13
	fmov	d19, x6
	mov.d	v19[1], x26
	mov.d	x6, v2[1]
	mov.d	x7, v7[1]
	fmov	x19, d2
	fmov	x22, d7
	sdiv	x22, x22, x19
	mul	x19, x22, x19
	fmov	d23, x22
	sdiv	x7, x7, x6
	mov.d	v23[1], x7
	mul	x22, x26, x25
	fmov	d15, x13
	mov.d	v15[1], x22
	mul	x13, x7, x6
	add	x7, sp, #2, lsl #12             ; =8192
	add	x7, x7, #1752
	fmov	d20, x19
	mov.d	v20[1], x13
	mul	x9, x24, x9
	fmov	d27, x10
	mov.d	v27[1], x9
	mul	x9, x2, x15
	fmov	d2, x4
	mov.d	v2[1], x9
	sub.2d	v2, v17, v2
	sub.2d	v17, v18, v27
	sub.2d	v7, v7, v20
	sub.2d	v16, v16, v15
	ldr	q18, [sp, #1648]
	ldr	q20, [sp, #1632]
	ldr	q27, [sp, #1616]
	ldr	q15, [sp, #1600]
	add.2d	v23, v15, v23
	add.2d	v19, v27, v19
	add.2d	v20, v20, v22
	add.2d	v18, v18, v21
	mov	w9, #65                         ; =0x41
	dup.2d	v21, x9
	cmhi.2d	v22, v21, v18
	cmhi.2d	v27, v21, v20
	uzp1.4s	v22, v27, v22
	cmhi.2d	v27, v21, v19
	cmhi.2d	v21, v21, v23
	uzp1.4s	v21, v21, v27
	uzp1.8h	v21, v21, v22
	ldr	q22, [sp, #1568]
	ldr	q27, [sp, #1584]
	ldr	q15, [sp, #1536]
	ldr	q28, [sp, #1552]
	add.2d	v16, v28, v16
	add.2d	v7, v15, v7
	add.2d	v17, v27, v17
	mov.d	x9, v19[1]
	fmov	x10, d19
	add	x10, x10, x10, lsl #7
	fmov	d19, x10
	add	x9, x9, x9, lsl #7
	mov.d	v19[1], x9
	mov.d	x9, v23[1]
	fmov	x10, d23
	add	x10, x10, x10, lsl #7
	fmov	d23, x10
	add	x9, x9, x9, lsl #7
	mov.d	v23[1], x9
	mov.d	x9, v18[1]
	fmov	x10, d18
	add	x10, x10, x10, lsl #7
	fmov	d18, x10
	add	x9, x9, x9, lsl #7
	mov.d	v18[1], x9
	mov.d	x9, v20[1]
	fmov	x10, d20
	add	x10, x10, x10, lsl #7
	fmov	d20, x10
	add	x9, x9, x9, lsl #7
	mov.d	v20[1], x9
	add.2d	v2, v22, v2
	mov	w9, #129                        ; =0x81
	dup.2d	v22, x9
	add.2d	v20, v20, v2
	add.2d	v18, v18, v17
	add.2d	v23, v23, v7
	add.2d	v19, v19, v16
	cmhi.2d	v17, v22, v17
	cmhi.2d	v2, v22, v2
	uzp1.4s	v2, v2, v17
	cmhi.2d	v16, v22, v16
	cmhi.2d	v7, v22, v7
	uzp1.4s	v7, v7, v16
	uzp1.8h	v2, v7, v2
	and.16b	v2, v21, v2
	xtn.8b	v2, v2
	ldr	q7, [sp, #1376]
	ldr	q16, [sp, #1392]
	ldr	q17, [sp, #1344]
	ldr	q21, [sp, #1360]
	bsl.16b	v5, v19, v21
	bsl.16b	v4, v23, v17
	bit.16b	v16, v18, v14
	bsl.16b	v6, v20, v7
	str	q6, [sp, #1376]
	str	q16, [sp, #1392]
	str	q4, [sp, #1344]
	str	q5, [sp, #1360]
	and.8b	v4, v13, v2
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v5, v4, v3
	addv.8b	b6, v5
	fmov	w9, s6
	umaxv.8b	b4, v4
	fmov	w10, s4
	tbz	w10, #0, LBB0_61
; %bb.55:                               ; %schedule.2
                                        ;   in Loop: Header=BB0_5 Depth=1
	bic.8b	v5, v13, v2
	shl.8b	v2, v5, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b4, v2
	fmov	w10, s4
	tst	w10, #0xff
	b.eq	LBB0_61
; %bb.56:                               ; %varying.divergent24
                                        ;   in Loop: Header=BB0_5 Depth=1
	subs	w9, w17, #1
	csel	w9, wzr, w9, lo
	and	w12, w27, #0xff
	lsr	w10, w12, w9
	tst	w10, #0x1
	stp	q10, q9, [sp, #608]
	and	x9, x9, #0x7
	add	x10, sp, #608
	ldr	w9, [x10, x9, lsl #2]
	ccmp	w17, #0, #4, ne
	ccmp	w9, #1, #0, ne
	cset	w10, ne
	cmp	w12, #255
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #1784
	b.ne	LBB0_58
; %bb.57:                               ; %varying.divergent24
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #0, LBB0_199
LBB0_58:                                ; %convergence.overflow.resume27
                                        ;   in Loop: Header=BB0_5 Depth=1
	mvn	w9, w27
	rbit	w9, w9
	clz	w9, w9
	mov	w12, #255                       ; =0xff
	bics	wzr, w12, w27
	csel	w9, wzr, w9, eq
	ubfiz	x12, x9, #2, #3
	lsl	w13, w11, w9
	stp	q10, q9, [sp, #576]
	add	x15, sp, #576
	ldr	w15, [x15, x12]
	cmp	w10, #0
	csel	w23, w13, wzr, ne
	csinc	w10, w15, wzr, eq
	stp	q10, q9, [sp, #544]
	add	x13, sp, #544
	str	w10, [x13, x12]
	ldp	q10, q9, [sp, #544]
	stp	q12, q11, [sp, #512]
	add	x10, sp, #512
	ldr	w10, [x10, x12]
	csel	w10, w17, w10, ne
	stp	q12, q11, [sp, #480]
	add	x13, sp, #480
	str	w10, [x13, x12]
	ldrb	w10, [x20, x9]
	and	w12, w10, #0x1
	fmov	s2, w12
	ubfx	w12, w10, #1, #1
	mov.b	v2[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v2[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v2[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v2[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v2[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v2[6], w12
	ldp	q12, q11, [sp, #480]
	lsr	w10, w10, #7
	mov.b	v2[7], w10
	ldrb	w10, [x8, x9]
	and	w12, w10, #0x1
	fmov	s7, w12
	ubfx	w12, w10, #1, #1
	mov.b	v7[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v7[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v7[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v7[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v7[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v7[6], w12
	lsr	w10, w10, #7
	mov.b	v7[7], w10
	csetm	w10, ne
	dup.8b	v16, w10
	bit.8b	v2, v13, v16
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x20, x9]
	bic.8b	v2, v7, v16
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x8, x9]
	csinc	w9, w17, w9, eq
	cmp	w28, #8
Lloh18:
	adrp	x19, LJTI0_0@PAGE
Lloh19:
	add	x19, x19, LJTI0_0@PAGEOFF
	mov	w22, #256                       ; =0x100
	add	x2, sp, #1200
	add	x4, sp, #1168
	b.hs	LBB0_199
; %bb.59:                               ; %ready.overflow.resume29
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b6, [x6, x21]
	mov	w10, #3                         ; =0x3
	str	w10, [x7, x21, lsl #2]
	str	w9, [x14, x21, lsl #2]
	cmp	w30, #8
	b.hs	LBB0_199
; %bb.60:                               ; %ready.overflow.resume31
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v27, v0
	mov.16b	v28, v30
	mov.16b	v23, v29
	mov.16b	v14, v31
	orr	w27, w23, w27
	zip2.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmge.4s	v2, v2, #0
	and.16b	v30, v2, v8
	zip1.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmge.4s	v2, v2, #0
	str	b4, [x6, w30, uxtw]
	and.16b	v0, v2, v26
	mov	w10, #4                         ; =0x4
	str	w10, [x7, w30, uxtw #2]
	str	w9, [x14, w30, uxtw #2]
	add	w28, w30, #1
	mov.16b	v26, v25
	mov.16b	v25, v24
	ldp	q24, q31, [sp, #288]            ; 32-byte Folded Reload
	b	LBB0_4
LBB0_61:                                ; %varying.coherent25
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w9, #0xff
	add	x2, sp, #1200
	add	x4, sp, #1168
	b.eq	LBB0_87
; %bb.62:                               ; %varying.coherent.true32
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #1784
Lloh20:
	adrp	x19, LJTI0_0@PAGE
Lloh21:
	add	x19, x19, LJTI0_0@PAGEOFF
	mov	w22, #256                       ; =0x100
	mov.16b	v27, v0
	mov.16b	v28, v30
	mov.16b	v23, v29
	mov.16b	v14, v31
	tbnz	w23, #0, LBB0_88
; %bb.63:                               ; %schedule.3.thread
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q2, [sp, #1392]
	ldr	q4, [sp, #1376]
	ldr	q5, [sp, #1360]
	ldr	q6, [sp, #1344]
	shl.2d	v6, v6, #2
	shl.2d	v7, v5, #2
	shl.2d	v4, v4, #2
	ldr	x9, [sp, #176]                  ; 8-byte Folded Reload
	dup.2d	v16, x9
	shl.2d	v2, v2, #2
	add.2d	v5, v16, v2
	add.2d	v2, v16, v4
	add.2d	v7, v16, v7
	add.2d	v16, v16, v6
	shl.8b	v4, v13, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v3
	addv.8b	b4, v4
	fmov	w9, s4
	movi.2d	v4, #0000000000000000
	movi.2d	v6, #0000000000000000
	mov.16b	v0, v26
	mov.16b	v30, v8
	tbnz	w9, #0, LBB0_109
; %bb.64:                               ; %else147
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v26, v25
	tbnz	w9, #1, LBB0_110
LBB0_65:                                ; %else153
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v25, v24
	ldr	q24, [sp, #288]                 ; 16-byte Folded Reload
	tbnz	w9, #2, LBB0_111
LBB0_66:                                ; %else159
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q31, [sp, #304]                 ; 16-byte Folded Reload
	tbnz	w9, #3, LBB0_112
LBB0_67:                                ; %else165
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #4, LBB0_113
LBB0_68:                                ; %else171
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #5, LBB0_114
LBB0_69:                                ; %else177
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #6, LBB0_115
LBB0_70:                                ; %else183
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w9, #7, LBB0_72
LBB0_71:                                ; %cond.load185
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x9, v5[1]
	ld1.s	{ v6 }[3], [x9]
LBB0_72:                                ; %else189
                                        ;   in Loop: Header=BB0_5 Depth=1
	zip2.8b	v2, v13, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	bit.16b	v30, v6, v2
	zip1.8b	v2, v13, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	bit.16b	v0, v4, v2
LBB0_73:                                ; %schedule.4
                                        ;   in Loop: Header=BB0_5 Depth=1
	cbz	w17, LBB0_90
LBB0_74:                                ; %convergence.cascade.preheader
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	w23, #0                         ; =0x0
LBB0_75:                                ; %convergence.cascade
                                        ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v2, v13, #7
	cmlt.8b	v2, v2, #0
	and.8b	v4, v2, v3
	addv.8b	b4, v4
	fmov	w9, s4
	umaxv.8b	b2, v2
	fmov	w12, s2
	sub	w10, w17, #1
	tst	w9, #0xff
	csel	w25, w10, wzr, ne
	lsl	w9, w11, w25
	and	w10, w9, w27
	tst	w10, #0xff
	cset	w13, ne
	stp	q10, q9, [sp, #672]
	ubfiz	x24, x25, #2, #3
	ldr	w10, [x1, x24]
	cmp	w10, #1
	cset	w10, eq
	and	w26, w13, w12
	ldrb	w12, [x20, w25, sxtw]
	and	w13, w12, #0x1
	fmov	s2, w13
	ubfx	w13, w12, #1, #1
	mov.b	v2[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v2[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v2[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v2[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v2[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v2[6], w13
	lsr	w12, w12, #7
	mov.b	v2[7], w12
	ldrb	w12, [x8, w25, sxtw]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	orr.8b	v5, v13, v4
	and.8b	v6, v1, v2
	eor.8b	v6, v6, v5
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	umaxv.8b	b6, v6
	fmov	w12, s6
	ands	w10, w26, w10
	csetm	w13, ne
	bics	w12, w10, w12
	csetm	w15, ne
	dup.8b	v6, w15
	dup.8b	v7, w13
	bic.8b	v16, v5, v6
	bit.8b	v4, v16, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v3
	addv.8b	b4, v4
	str	b4, [x8, w25, sxtw]
	bic.8b	v2, v2, v6
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x20, w25, sxtw]
	csinv	w9, w3, w9, eq
	dup.8b	v2, w10
	and	w27, w9, w27
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	dup.8b	v4, w12
	and.8b	v4, v4, v5
	stp	q12, q11, [sp, #640]
	ldr	w9, [x5, x24]
	csel	w17, w9, w17, ne
	bit.8b	v13, v4, v2
	shl.8b	v2, v13, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w9, s2
	cmp	w10, #1
	b.ne	LBB0_91
; %bb.76:                               ; %convergence.cascade
                                        ;   in Loop: Header=BB0_75 Depth=2
	cmp	w17, #0
	ccmp	w23, #6, #2, ne
	b.hi	LBB0_91
; %bb.77:                               ; %convergence.cascade
                                        ;   in Loop: Header=BB0_75 Depth=2
	add	w23, w23, #1
	tst	w9, #0xff
	b.ne	LBB0_75
	b	LBB0_91
LBB0_78:                                ; %varying.coherent.false
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w9, #0xff
	b.eq	LBB0_4
LBB0_79:                                ; %schedule.5
                                        ;   in Loop: Header=BB0_5 Depth=1
	cbz	w17, LBB0_84
; %bb.80:                               ; %convergence.cascade44.preheader
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	w23, #0                         ; =0x0
LBB0_81:                                ; %convergence.cascade44
                                        ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v2, v13, #7
	cmlt.8b	v2, v2, #0
	and.8b	v4, v2, v3
	addv.8b	b4, v4
	fmov	w9, s4
	umaxv.8b	b2, v2
	fmov	w12, s2
	sub	w10, w17, #1
	tst	w9, #0xff
	csel	w25, w10, wzr, ne
	lsl	w9, w11, w25
	and	w10, w9, w27
	tst	w10, #0xff
	cset	w13, ne
	str	q10, [sp, #1200]
	str	q9, [sp, #1216]
	ubfiz	x24, x25, #2, #3
	ldr	w10, [x2, x24]
	cmp	w10, #0
	cset	w10, eq
	and	w26, w13, w12
	ldrb	w12, [x20, w25, sxtw]
	and	w13, w12, #0x1
	fmov	s2, w13
	ubfx	w13, w12, #1, #1
	mov.b	v2[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v2[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v2[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v2[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v2[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v2[6], w13
	lsr	w12, w12, #7
	mov.b	v2[7], w12
	ldrb	w12, [x8, w25, sxtw]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	orr.8b	v5, v13, v4
	and.8b	v6, v1, v2
	eor.8b	v6, v6, v5
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	umaxv.8b	b6, v6
	fmov	w12, s6
	ands	w10, w26, w10
	csetm	w13, ne
	bics	w12, w10, w12
	csetm	w15, ne
	dup.8b	v6, w15
	dup.8b	v7, w13
	bic.8b	v16, v5, v6
	bit.8b	v4, v16, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v3
	addv.8b	b4, v4
	str	b4, [x8, w25, sxtw]
	bic.8b	v2, v2, v6
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x20, w25, sxtw]
	csinv	w9, w3, w9, eq
	dup.8b	v2, w10
	and	w27, w9, w27
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	dup.8b	v4, w12
	and.8b	v4, v4, v5
	str	q12, [sp, #1168]
	str	q11, [sp, #1184]
	ldr	w9, [x4, x24]
	csel	w17, w9, w17, ne
	bit.8b	v13, v4, v2
	shl.8b	v2, v13, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w9, s2
	cmp	w10, #1
	b.ne	LBB0_85
; %bb.82:                               ; %convergence.cascade44
                                        ;   in Loop: Header=BB0_81 Depth=2
	cmp	w17, #0
	ccmp	w23, #6, #2, ne
	b.hi	LBB0_85
; %bb.83:                               ; %convergence.cascade44
                                        ;   in Loop: Header=BB0_81 Depth=2
	add	w23, w23, #1
	tst	w9, #0xff
	b.ne	LBB0_81
	b	LBB0_85
LBB0_84:                                ; %schedule.5.convergence.cascade.exit45_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v2, v13, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w9, s2
LBB0_85:                                ; %convergence.cascade.exit45
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w9, #0xff
	b.eq	LBB0_4
; %bb.86:                               ; %convergence.target.5.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	b2, v13[6]
	mov.b	v2[4], v13[7]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmge.2d	v2, v2, #0
	and.16b	v26, v2, v26
	mov	b2, v13[4]
	mov.b	v2[4], v13[5]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmge.2d	v2, v2, #0
	mov	b4, v13[2]
	mov.b	v4[4], v13[3]
	and.16b	v25, v2, v25
	ushll.2d	v2, v4, #0
	shl.2d	v2, v2, #63
	cmge.2d	v2, v2, #0
	and.16b	v24, v2, v24
	mov	b2, v13[0]
	mov.b	v2[4], v13[1]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmge.2d	v2, v2, #0
	and.16b	v31, v2, v31
	b	LBB0_116
LBB0_87:                                ; %varying.coherent.false33
                                        ;   in Loop: Header=BB0_5 Depth=1
	zip2.8b	v2, v13, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmge.4s	v2, v2, #0
	and.16b	v8, v2, v8
	zip1.8b	v2, v13, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmge.4s	v2, v2, #0
	and.16b	v26, v2, v26
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #1784
Lloh22:
	adrp	x19, LJTI0_0@PAGE
Lloh23:
	add	x19, x19, LJTI0_0@PAGEOFF
	mov	w22, #256                       ; =0x100
	mov.16b	v27, v0
	mov.16b	v28, v30
	mov.16b	v23, v29
	mov.16b	v14, v31
	tbz	w23, #0, LBB0_89
LBB0_88:                                ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v0, v26
	mov.16b	v26, v25
	mov.16b	v25, v24
	ldp	q24, q31, [sp, #288]            ; 32-byte Folded Reload
	mov.16b	v30, v8
	b	LBB0_4
LBB0_89:                                ;   in Loop: Header=BB0_5 Depth=1
	mov.16b	v0, v26
	mov.16b	v26, v25
	mov.16b	v25, v24
	ldp	q24, q31, [sp, #288]            ; 32-byte Folded Reload
	mov.16b	v30, v8
	cbnz	w17, LBB0_74
LBB0_90:                                ; %schedule.4.convergence.cascade.exit_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v2, v13, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w9, s2
LBB0_91:                                ; %convergence.cascade.exit
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w9, #0xff
	b.eq	LBB0_4
; %bb.92:                               ; %convergence.target.4.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q2, [sp, #1456]
	ldr	q4, [sp, #1440]
	ldr	q5, [sp, #1424]
	ldr	q6, [sp, #1408]
	ldr	q7, [sp, #1472]
	ldr	q16, [sp, #1488]
	ldr	q17, [sp, #1504]
	ldr	q18, [sp, #1520]
	shl.2d	v19, v23, #5
	shl.2d	v20, v14, #5
	shl.2d	v21, v27, #5
	shl.2d	v22, v28, #5
	add.2d	v18, v18, v22
	add.2d	v17, v17, v21
	add.2d	v16, v16, v20
	add.2d	v7, v7, v19
	add.2d	v6, v6, v7
	add.2d	v5, v5, v16
	add.2d	v4, v4, v17
	add.2d	v2, v2, v18
	shl.8b	v7, v13, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v3
	addv.8b	b7, v7
	fmov	w9, s7
	tbnz	w9, #0, LBB0_102
; %bb.93:                               ; %else195
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #1, LBB0_103
LBB0_94:                                ; %else199
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #2, LBB0_104
LBB0_95:                                ; %else203
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #3, LBB0_105
LBB0_96:                                ; %else207
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #4, LBB0_106
LBB0_97:                                ; %else211
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #5, LBB0_107
LBB0_98:                                ; %else215
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #6, LBB0_108
LBB0_99:                                ; %else219
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w9, #7, LBB0_101
LBB0_100:                               ; %cond.store220
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x9, v2[1]
	st1.s	{ v30 }[3], [x9]
LBB0_101:                               ; %else223
                                        ;   in Loop: Header=BB0_5 Depth=1
	movi.8b	v2, #1
	and.8b	v2, v13, v2
	ushll.8h	v2, v2, #0
	ushll.4s	v4, v2, #0
	ushll2.4s	v2, v2, #0
	uaddw2.2d	v28, v28, v2
	uaddw.2d	v27, v27, v2
	uaddw2.2d	v14, v14, v4
	uaddw.2d	v23, v23, v4
	b	LBB0_44
LBB0_102:                               ; %cond.store192
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d6
	str	s0, [x10]
	tbz	w9, #1, LBB0_94
LBB0_103:                               ; %cond.store196
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v6[1]
	st1.s	{ v0 }[1], [x10]
	tbz	w9, #2, LBB0_95
LBB0_104:                               ; %cond.store200
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d5
	st1.s	{ v0 }[2], [x10]
	tbz	w9, #3, LBB0_96
LBB0_105:                               ; %cond.store204
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v5[1]
	st1.s	{ v0 }[3], [x10]
	tbz	w9, #4, LBB0_97
LBB0_106:                               ; %cond.store208
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d4
	str	s30, [x10]
	tbz	w9, #5, LBB0_98
LBB0_107:                               ; %cond.store212
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v4[1]
	st1.s	{ v30 }[1], [x10]
	tbz	w9, #6, LBB0_99
LBB0_108:                               ; %cond.store216
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d2
	st1.s	{ v30 }[2], [x10]
	tbnz	w9, #7, LBB0_100
	b	LBB0_101
LBB0_109:                               ; %cond.load143
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d16
	ldr	s4, [x10]
	mov.16b	v26, v25
	tbz	w9, #1, LBB0_65
LBB0_110:                               ; %cond.load149
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v16[1]
	ld1.s	{ v4 }[1], [x10]
	mov.16b	v25, v24
	ldr	q24, [sp, #288]                 ; 16-byte Folded Reload
	tbz	w9, #2, LBB0_66
LBB0_111:                               ; %cond.load155
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d7
	ld1.s	{ v4 }[2], [x10]
	ldr	q31, [sp, #304]                 ; 16-byte Folded Reload
	tbz	w9, #3, LBB0_67
LBB0_112:                               ; %cond.load161
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v7[1]
	ld1.s	{ v4 }[3], [x10]
	tbz	w9, #4, LBB0_68
LBB0_113:                               ; %cond.load167
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d2
	ld1.s	{ v6 }[0], [x10]
	tbz	w9, #5, LBB0_69
LBB0_114:                               ; %cond.load173
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v2[1]
	ld1.s	{ v6 }[1], [x10]
	tbz	w9, #6, LBB0_70
LBB0_115:                               ; %cond.load179
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d5
	ld1.s	{ v6 }[2], [x10]
	tbnz	w9, #7, LBB0_71
	b	LBB0_72
LBB0_116:                               ; %schedule.6
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v2, v13, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w9, s2
	dup.2d	v2, x22
	cmgt.2d	v4, v2, v24
	cmgt.2d	v5, v2, v31
	uzp1.4s	v4, v5, v4
	cmgt.2d	v5, v2, v25
	cmgt.2d	v6, v2, v26
	uzp1.4s	v5, v5, v6
	uzp1.8h	v4, v4, v5
	xtn.8b	v4, v4
	and.8b	v4, v13, v4
	shl.8b	v4, v4, #7
	cmlt.8b	v5, v4, #0
	and.8b	v4, v5, v3
	addv.8b	b4, v4
	fmov	w10, s4
	umaxv.8b	b5, v5
	fmov	w13, s5
	tbz	w13, #0, LBB0_123
; %bb.117:                              ; %schedule.6
                                        ;   in Loop: Header=BB0_5 Depth=1
	cmge.2d	v5, v24, v2
	cmge.2d	v6, v31, v2
	uzp1.4s	v5, v6, v5
	cmge.2d	v6, v25, v2
	cmge.2d	v2, v26, v2
	uzp1.4s	v2, v6, v2
	uzp1.8h	v2, v5, v2
	xtn.8b	v2, v2
	and.8b	v2, v13, v2
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b5, v2
	fmov	w13, s5
	tst	w13, #0xff
	b.eq	LBB0_123
; %bb.118:                              ; %varying.divergent62
                                        ;   in Loop: Header=BB0_5 Depth=1
	subs	w9, w17, #1
	csel	w9, wzr, w9, lo
	and	w12, w27, #0xff
	lsr	w10, w12, w9
	tst	w10, #0x1
	stp	q10, q9, [sp, #832]
	and	x9, x9, #0x7
	add	x10, sp, #832
	ldr	w9, [x10, x9, lsl #2]
	ccmp	w17, #0, #4, ne
	ccmp	w9, #2, #0, ne
	cset	w10, ne
	cmp	w12, #255
	b.ne	LBB0_120
; %bb.119:                              ; %varying.divergent62
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #0, LBB0_199
LBB0_120:                               ; %convergence.overflow.resume65
                                        ;   in Loop: Header=BB0_5 Depth=1
	mvn	w9, w27
	rbit	w9, w9
	clz	w9, w9
	mov	w12, #255                       ; =0xff
	bics	wzr, w12, w27
	csel	w9, wzr, w9, eq
	ubfiz	x12, x9, #2, #3
	lsl	w13, w11, w9
	stp	q10, q9, [sp, #800]
	add	x15, sp, #800
	ldr	w15, [x15, x12]
	cmp	w10, #0
	csel	w23, w13, wzr, ne
	mov	w10, #2                         ; =0x2
	csel	w10, w10, w15, ne
	stp	q10, q9, [sp, #768]
	add	x13, sp, #768
	str	w10, [x13, x12]
	ldp	q10, q9, [sp, #768]
	stp	q12, q11, [sp, #736]
	add	x10, sp, #736
	ldr	w10, [x10, x12]
	csel	w10, w17, w10, ne
	stp	q12, q11, [sp, #704]
	add	x13, sp, #704
	str	w10, [x13, x12]
	ldrb	w10, [x20, x9]
	and	w12, w10, #0x1
	fmov	s2, w12
	ubfx	w12, w10, #1, #1
	mov.b	v2[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v2[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v2[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v2[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v2[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v2[6], w12
	ldp	q12, q11, [sp, #704]
	lsr	w10, w10, #7
	mov.b	v2[7], w10
	ldrb	w10, [x8, x9]
	and	w12, w10, #0x1
	fmov	s6, w12
	ubfx	w12, w10, #1, #1
	mov.b	v6[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v6[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v6[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v6[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v6[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v6[6], w12
	lsr	w10, w10, #7
	mov.b	v6[7], w10
	csetm	w10, ne
	dup.8b	v7, w10
	bit.8b	v2, v13, v7
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x20, x9]
	bic.8b	v2, v6, v7
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x8, x9]
	csinc	w9, w17, w9, eq
	cmp	w28, #8
	b.hs	LBB0_199
; %bb.121:                              ; %ready.overflow.resume67
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b4, [x6, x21]
	mov	w10, #7                         ; =0x7
	str	w10, [x7, x21, lsl #2]
	str	w9, [x14, x21, lsl #2]
	cmp	w30, #8
	b.hs	LBB0_199
; %bb.122:                              ; %ready.overflow.resume69
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b5, [x6, w30, uxtw]
	orr	w27, w23, w27
	mov	w10, #10                        ; =0xa
	b	LBB0_3
LBB0_123:                               ; %varying.coherent63
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w10, #0xff
	b.eq	LBB0_158
; %bb.124:                              ; %varying.coherent.true70
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w9, #0xff
	b.eq	LBB0_4
; %bb.125:                              ;   in Loop: Header=BB0_5 Depth=1
	mov	w23, #0                         ; =0x0
LBB0_126:                               ; %schedule.7
                                        ;   in Loop: Header=BB0_5 Depth=1
	stp	q28, q27, [sp, #192]            ; 32-byte Folded Spill
	stp	q14, q23, [sp, #224]            ; 32-byte Folded Spill
	stp	q30, q0, [sp, #256]             ; 32-byte Folded Spill
	mov	b2, v13[0]
	mov.b	v2[4], v13[1]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v15, v2, #0
	stp	q24, q31, [sp, #288]            ; 32-byte Folded Spill
	and.16b	v7, v15, v31
	mov	b2, v13[2]
	mov.b	v2[4], v13[3]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v4, v2, #0
	and.16b	v18, v4, v24
	mov	b2, v13[4]
	mov.b	v2[4], v13[5]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v5, v2, #0
	mov.16b	v14, v25
	and.16b	v23, v5, v25
	mov	b2, v13[6]
	mov.b	v2[4], v13[7]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v6, v2, #0
	mov.16b	v0, v26
	and.16b	v22, v6, v26
	shl.8b	v2, v13, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	d2, [sp, #168]                  ; 8-byte Folded Spill
	fmov	w24, s2
	mov	w9, #16                         ; =0x10
	dup.2d	v16, x9
	and.16b	v2, v15, v16
	mvn.16b	v17, v15
	sub.2d	v2, v2, v17
	and.16b	v17, v4, v16
	mvn.16b	v19, v4
	sub.2d	v19, v17, v19
	and.16b	v17, v5, v16
	and.16b	v16, v6, v16
	mvn.16b	v20, v6
	sub.2d	v16, v16, v20
	mov.d	x9, v16[1]
	mov.d	x10, v22[1]
	sdiv	x25, x10, x9
	mvn.16b	v20, v5
	sub.2d	v17, v17, v20
	fmov	x10, d16
	fmov	x13, d22
	sdiv	x13, x13, x10
	mul	x10, x13, x10
	fmov	d16, x13
	mov.d	v16[1], x25
	mov.d	x13, v17[1]
	mov.d	x15, v23[1]
	sdiv	x15, x15, x13
	fmov	x2, d17
	fmov	x4, d23
	sdiv	x4, x4, x2
	mul	x2, x4, x2
	fmov	d17, x4
	mov.d	v17[1], x15
	mov.d	x4, v19[1]
	mov.d	x6, v18[1]
	sdiv	x6, x6, x4
	fmov	x7, d19
	fmov	x19, d18
	sdiv	x19, x19, x7
	mul	x7, x19, x7
	fmov	d19, x19
	mov.d	v19[1], x6
	mov.d	x19, v2[1]
	mov.d	x22, v7[1]
	fmov	x26, d2
	fmov	x12, d7
	sdiv	x12, x12, x26
	mul	x26, x12, x26
	fmov	d21, x12
	sdiv	x12, x22, x19
	mov.d	v21[1], x12
	mul	x12, x12, x19
	fmov	d2, x26
	mov.d	v2[1], x12
	mul	x12, x6, x4
	fmov	d20, x7
	mov.d	v20[1], x12
	mul	x12, x15, x13
	fmov	d27, x2
	mov.d	v27[1], x12
	mul	x9, x25, x9
	fmov	d28, x10
	mov.d	v28[1], x9
	sub.2d	v22, v22, v28
	sub.2d	v23, v23, v27
	sub.2d	v18, v18, v20
	sub.2d	v2, v7, v2
	ldr	q7, [sp, #1584]
	ldr	q20, [sp, #1568]
	ldr	q27, [sp, #1552]
	ldr	q28, [sp, #1536]
	add.2d	v28, v28, v21
	add.2d	v27, v27, v19
	add.2d	v20, v20, v17
	add.2d	v7, v7, v16
	mov	w9, #129                        ; =0x81
	dup.2d	v24, x9
	cmhi.2d	v25, v24, v7
	cmhi.2d	v26, v24, v20
	uzp1.4s	v25, v26, v25
	cmhi.2d	v26, v24, v27
	cmhi.2d	v24, v24, v28
	uzp1.4s	v24, v24, v26
	uzp1.8h	v24, v24, v25
	ldr	q25, [sp, #1648]
	ldr	q26, [sp, #1632]
	ldr	q29, [sp, #1616]
	ldr	q30, [sp, #1600]
	add.2d	v30, v30, v2
	add.2d	v29, v29, v18
	add.2d	v26, v26, v23
	mov.d	x9, v28[1]
	fmov	x10, d28
	add	x10, x10, x10, lsl #6
	fmov	d28, x10
	add	x9, x9, x9, lsl #6
	mov.d	v28[1], x9
	mov.d	x9, v27[1]
	fmov	x10, d27
	add	x10, x10, x10, lsl #6
	fmov	d27, x10
	add	x9, x9, x9, lsl #6
	mov.d	v27[1], x9
	mov.d	x9, v20[1]
	fmov	x10, d20
	add	x10, x10, x10, lsl #6
	fmov	d20, x10
	add	x9, x9, x9, lsl #6
	mov.d	v20[1], x9
	add.2d	v25, v25, v22
	mov.d	x9, v7[1]
	fmov	x10, d7
	add	x10, x10, x10, lsl #6
	fmov	d7, x10
	add	x9, x9, x9, lsl #6
	mov.d	v7[1], x9
	mov	w9, #65                         ; =0x41
	dup.2d	v31, x9
	add.2d	v8, v7, v25
	add.2d	v20, v20, v26
	add.2d	v27, v27, v29
	add.2d	v28, v28, v30
	cmhi.2d	v7, v31, v25
	cmhi.2d	v25, v31, v26
	uzp1.4s	v7, v25, v7
	cmhi.2d	v25, v31, v29
	cmhi.2d	v26, v31, v30
	uzp1.4s	v25, v26, v25
	uzp1.8h	v7, v25, v7
	and.16b	v7, v24, v7
	xtn.8b	v7, v7
	ldr	q24, [sp, #1328]
	ldr	q25, [sp, #1312]
	ldr	q26, [sp, #1296]
	ldr	q29, [sp, #1280]
	bif.16b	v28, v29, v15
	bsl.16b	v4, v27, v26
	bsl.16b	v5, v20, v25
	bsl.16b	v6, v8, v24
	str	q6, [sp, #1328]
	str	q5, [sp, #1312]
	str	q4, [sp, #1296]
	str	q28, [sp, #1280]
	ldr	q4, [sp, #1408]
	ldr	q5, [sp, #1424]
	ldr	q20, [sp, #1440]
	ldr	q6, [sp, #1456]
	ldr	q24, [sp, #1520]
	ldr	q25, [sp, #1504]
	ldr	q26, [sp, #1488]
	ldr	q27, [sp, #1472]
	shl.2d	v28, v2, #9
	shl.2d	v18, v18, #9
	shl.2d	v2, v23, #9
	shl.2d	v22, v22, #9
	shl.2d	v21, v21, #5
	shl.2d	v19, v19, #5
	shl.2d	v17, v17, #5
	shl.2d	v16, v16, #5
	add.2d	v21, v21, v27
	add.2d	v19, v19, v26
	add.2d	v17, v17, v25
	add.2d	v16, v16, v24
	add.2d	v6, v6, v16
	add.2d	v6, v6, v22
	add.2d	v16, v20, v17
	add.2d	v2, v16, v2
	add.2d	v5, v5, v19
	add.2d	v16, v5, v18
	add.2d	v4, v4, v21
	add.2d	v17, v4, v28
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbz	w24, #0, LBB0_128
; %bb.127:                              ; %cond.load70
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x9, d17
	ldr	s4, [x9]
LBB0_128:                               ; %else74
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w24, #1, LBB0_130
; %bb.129:                              ; %cond.load76
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x9, v17[1]
	ld1.s	{ v4 }[1], [x9]
LBB0_130:                               ; %else80
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #1784
	add	x7, sp, #2, lsl #12             ; =8192
	add	x7, x7, #1752
Lloh24:
	adrp	x19, LJTI0_0@PAGE
Lloh25:
	add	x19, x19, LJTI0_0@PAGEOFF
	mov	w22, #256                       ; =0x100
	ldp	q24, q31, [sp, #288]            ; 32-byte Folded Reload
	mov.16b	v25, v14
	mov.16b	v26, v0
	ldp	q30, q0, [sp, #256]             ; 32-byte Folded Reload
	ldp	q14, q23, [sp, #224]            ; 32-byte Folded Reload
	ldp	q28, q27, [sp, #192]            ; 32-byte Folded Reload
	add	x2, sp, #1200
	add	x4, sp, #1168
	tbnz	w24, #2, LBB0_153
; %bb.131:                              ; %else86
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w24, #3, LBB0_154
LBB0_132:                               ; %else92
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w24, #4, LBB0_155
LBB0_133:                               ; %else98
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w24, #5, LBB0_156
LBB0_134:                               ; %else104
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w24, #6, LBB0_157
LBB0_135:                               ; %else110
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w24, #7, LBB0_137
LBB0_136:                               ; %cond.load112
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x9, v6[1]
	ld1.s	{ v5 }[3], [x9]
LBB0_137:                               ; %else116
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q2, [sp, #1264]
	ldr	q6, [sp, #1248]
	zip1.8b	v16, v13, v0
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	bif.16b	v4, v6, v16
	zip2.8b	v6, v13, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	bit.16b	v2, v5, v6
	str	q2, [sp, #1264]
	str	q4, [sp, #1248]
	and.8b	v2, v13, v7
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v4, v2, v3
	addv.8b	b4, v4
	fmov	w9, s4
	umaxv.8b	b2, v2
	fmov	w10, s2
	tbz	w10, #0, LBB0_143
; %bb.138:                              ; %else116
                                        ;   in Loop: Header=BB0_5 Depth=1
	bic.8b	v2, v13, v7
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b5, v2
	fmov	w10, s5
	tst	w10, #0xff
	b.eq	LBB0_143
; %bb.139:                              ; %varying.divergent77
                                        ;   in Loop: Header=BB0_5 Depth=1
	subs	w9, w17, #1
	csel	w9, wzr, w9, lo
	and	w12, w27, #0xff
	lsr	w10, w12, w9
	tst	w10, #0x1
	stp	q10, q9, [sp, #992]
	and	x9, x9, #0x7
	add	x10, sp, #992
	ldr	w9, [x10, x9, lsl #2]
	ccmp	w17, #0, #4, ne
	ccmp	w9, #3, #0, ne
	cset	w10, ne
	cmp	w12, #255
	b.ne	LBB0_141
; %bb.140:                              ; %varying.divergent77
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w10, #0, LBB0_199
LBB0_141:                               ; %convergence.overflow.resume80
                                        ;   in Loop: Header=BB0_5 Depth=1
	mvn	w9, w27
	rbit	w9, w9
	clz	w9, w9
	mov	w12, #255                       ; =0xff
	bics	wzr, w12, w27
	csel	w9, wzr, w9, eq
	ubfiz	x12, x9, #2, #3
	lsl	w13, w11, w9
	stp	q10, q9, [sp, #960]
	add	x15, sp, #960
	ldr	w15, [x15, x12]
	cmp	w10, #0
	csel	w23, w13, wzr, ne
	mov	w10, #3                         ; =0x3
	csel	w10, w10, w15, ne
	stp	q10, q9, [sp, #928]
	add	x13, sp, #928
	str	w10, [x13, x12]
	ldp	q10, q9, [sp, #928]
	stp	q12, q11, [sp, #896]
	add	x10, sp, #896
	ldr	w10, [x10, x12]
	csel	w10, w17, w10, ne
	stp	q12, q11, [sp, #864]
	add	x13, sp, #864
	str	w10, [x13, x12]
	ldrb	w10, [x20, x9]
	and	w12, w10, #0x1
	fmov	s2, w12
	ubfx	w12, w10, #1, #1
	mov.b	v2[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v2[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v2[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v2[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v2[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v2[6], w12
	ldp	q12, q11, [sp, #864]
	lsr	w10, w10, #7
	mov.b	v2[7], w10
	ldrb	w10, [x8, x9]
	and	w12, w10, #0x1
	fmov	s6, w12
	ubfx	w12, w10, #1, #1
	mov.b	v6[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v6[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v6[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v6[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v6[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v6[6], w12
	lsr	w10, w10, #7
	mov.b	v6[7], w10
	csetm	w10, ne
	dup.8b	v7, w10
	bit.8b	v2, v13, v7
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x20, x9]
	bic.8b	v2, v6, v7
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x8, x9]
	csinc	w9, w17, w9, eq
	cmp	w28, #8
	b.hs	LBB0_199
; %bb.142:                              ; %ready.overflow.resume82
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	b4, [x6, x21]
	mov	w10, #8                         ; =0x8
	str	w10, [x7, x21, lsl #2]
	str	w9, [x14, x21, lsl #2]
	cmp	w30, #8
	b.lo	LBB0_2
	b	LBB0_199
LBB0_143:                               ; %varying.coherent78
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w9, #0xff
	b.eq	LBB0_179
; %bb.144:                              ; %varying.coherent.true85
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w23, #0, LBB0_4
; %bb.145:                              ; %schedule.8.thread
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q4, [sp, #1328]
	ldr	q5, [sp, #1312]
	ldr	q7, [sp, #1296]
	ldr	q16, [sp, #1280]
	ldr	q2, [sp, #1264]
	ldr	q6, [sp, #1248]
	shl.2d	v16, v16, #2
	shl.2d	v7, v7, #2
	shl.2d	v5, v5, #2
	ldr	x9, [sp, #184]                  ; 8-byte Folded Reload
	dup.2d	v17, x9
	shl.2d	v4, v4, #2
	add.2d	v4, v17, v4
	add.2d	v5, v17, v5
	add.2d	v7, v17, v7
	add.2d	v16, v17, v16
	ldr	d17, [sp, #168]                 ; 8-byte Folded Reload
	fmov	w9, s17
	tbnz	w9, #0, LBB0_181
; %bb.146:                              ; %else228
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #1, LBB0_182
LBB0_147:                               ; %else232
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #2, LBB0_183
LBB0_148:                               ; %else236
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #3, LBB0_184
LBB0_149:                               ; %else240
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #4, LBB0_185
LBB0_150:                               ; %else244
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #5, LBB0_186
LBB0_151:                               ; %else248
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #6, LBB0_187
LBB0_152:                               ; %else252
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w9, #7, LBB0_188
	b	LBB0_189
LBB0_153:                               ; %cond.load82
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x9, d16
	ld1.s	{ v4 }[2], [x9]
	tbz	w24, #3, LBB0_132
LBB0_154:                               ; %cond.load88
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x9, v16[1]
	ld1.s	{ v4 }[3], [x9]
	tbz	w24, #4, LBB0_133
LBB0_155:                               ; %cond.load94
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x9, d2
	ld1.s	{ v5 }[0], [x9]
	tbz	w24, #5, LBB0_134
LBB0_156:                               ; %cond.load100
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x9, v2[1]
	ld1.s	{ v5 }[1], [x9]
	tbz	w24, #6, LBB0_135
LBB0_157:                               ; %cond.load106
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x9, d6
	ld1.s	{ v5 }[2], [x9]
	tbnz	w24, #7, LBB0_136
	b	LBB0_137
LBB0_158:                               ; %varying.coherent.false71
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w9, #0xff
	b.eq	LBB0_4
LBB0_159:                               ; %schedule.10
                                        ;   in Loop: Header=BB0_5 Depth=1
	cbz	w17, LBB0_164
; %bb.160:                              ; %convergence.cascade107.preheader
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	w23, #0                         ; =0x0
LBB0_161:                               ; %convergence.cascade107
                                        ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v2, v13, #7
	cmlt.8b	v2, v2, #0
	and.8b	v4, v2, v3
	addv.8b	b4, v4
	fmov	w9, s4
	umaxv.8b	b2, v2
	fmov	w12, s2
	sub	w10, w17, #1
	tst	w9, #0xff
	csel	w25, w10, wzr, ne
	lsl	w9, w11, w25
	and	w10, w9, w27
	tst	w10, #0xff
	cset	w13, ne
	str	q10, [sp, #1136]
	str	q9, [sp, #1152]
	ubfiz	x24, x25, #2, #3
	add	x10, sp, #1136
	ldr	w10, [x10, x24]
	cmp	w10, #2
	cset	w10, eq
	and	w26, w13, w12
	ldrb	w12, [x20, w25, sxtw]
	and	w13, w12, #0x1
	fmov	s2, w13
	ubfx	w13, w12, #1, #1
	mov.b	v2[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v2[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v2[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v2[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v2[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v2[6], w13
	lsr	w12, w12, #7
	mov.b	v2[7], w12
	ldrb	w12, [x8, w25, sxtw]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	orr.8b	v5, v13, v4
	and.8b	v6, v1, v2
	eor.8b	v6, v6, v5
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	umaxv.8b	b6, v6
	fmov	w12, s6
	ands	w10, w26, w10
	csetm	w13, ne
	bics	w12, w10, w12
	csetm	w15, ne
	dup.8b	v6, w15
	dup.8b	v7, w13
	bic.8b	v16, v5, v6
	bit.8b	v4, v16, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v3
	addv.8b	b4, v4
	str	b4, [x8, w25, sxtw]
	bic.8b	v2, v2, v6
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x20, w25, sxtw]
	csinv	w9, w3, w9, eq
	dup.8b	v2, w10
	and	w27, w9, w27
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	dup.8b	v4, w12
	and.8b	v4, v4, v5
	str	q12, [sp, #1104]
	str	q11, [sp, #1120]
	add	x9, sp, #1104
	ldr	w9, [x9, x24]
	csel	w17, w9, w17, ne
	bit.8b	v13, v4, v2
	shl.8b	v2, v13, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w9, s2
	cmp	w10, #1
	b.ne	LBB0_165
; %bb.162:                              ; %convergence.cascade107
                                        ;   in Loop: Header=BB0_161 Depth=2
	cmp	w17, #0
	ccmp	w23, #6, #2, ne
	b.hi	LBB0_165
; %bb.163:                              ; %convergence.cascade107
                                        ;   in Loop: Header=BB0_161 Depth=2
	add	w23, w23, #1
	tst	w9, #0xff
	b.ne	LBB0_161
	b	LBB0_165
LBB0_164:                               ; %schedule.10.convergence.cascade.exit108_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v2, v13, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w9, s2
LBB0_165:                               ; %convergence.cascade.exit108
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w9, #0xff
	b.eq	LBB0_4
; %bb.166:                              ; %convergence.target.10.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	bic.8b	v1, v1, v13
	tst	w27, #0xff
	b.eq	LBB0_180
; %bb.167:                              ; %return.frame.cleanup
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldrb	w9, [x8, #8]
	and	w10, w9, #0x1
	fmov	s2, w10
	ubfx	w10, w9, #1, #1
	mov.b	v2[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v2[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v2[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v2[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v2[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v2[6], w10
	lsr	w9, w9, #7
	mov.b	v2[7], w9
	ldrb	w9, [x8]
	and	w10, w9, #0x1
	fmov	s6, w10
	ubfx	w10, w9, #1, #1
	mov.b	v6[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v6[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v6[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v6[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v6[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v6[6], w10
	lsr	w9, w9, #7
	mov.b	v6[7], w9
	and.8b	v7, v1, v2
	eor.8b	v2, v6, v7
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	umaxv.8b	b4, v2
	fmov	w9, s4
	eor	w9, w9, #0x1
	and	w10, w27, w9
	dup.8b	v4, w10
	and.8b	v4, v4, v6
	shl.8b	v5, v4, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v3
	addv.8b	b5, v5
	fmov	w9, s5
	tst	w10, #0x1
	csetm	w10, ne
	dup.8b	v16, w10
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v3
	addv.8b	b7, v7
	str	b7, [x8, #8]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v3
	addv.8b	b6, v6
	str	b6, [x8]
	cmp	w28, #8
	b.lo	LBB0_169
; %bb.168:                              ; %return.frame.cleanup
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w9, #0xff
	b.ne	LBB0_199
LBB0_169:                               ; %ready.overflow.resume129
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w10, s2
	ldr	d2, [sp, #104]                  ; 8-byte Folded Reload
	cmeq.8b	v2, v5, v2
	mvn.8b	v2, v2
	umov.b	w12, v2[0]
	sbfx	w13, w12, #0, #1
	fmov	s2, w13
	sbfx	w13, w12, #1, #1
	mov.b	v2[1], w13
	sbfx	w13, w12, #2, #1
	mov.b	v2[2], w13
	sbfx	w13, w12, #3, #1
	mov.b	v2[3], w13
	sbfx	w13, w12, #4, #1
	mov.b	v2[4], w13
	sbfx	w13, w12, #5, #1
	mov.b	v2[5], w13
	sbfx	w13, w12, #6, #1
	mov.b	v2[6], w13
	sbfx	w12, w12, #7, #1
	mov.b	v2[7], w12
	and	w12, w27, #0xfffffffe
	tst	w10, #0xff
	csel	w17, w12, w27, eq
	tst	w9, #0xff
	csel	x9, x21, xzr, ne
	ldrb	w10, [x6, x9]
	and	w12, w10, #0x1
	fmov	s5, w12
	ubfx	w12, w10, #1, #1
	mov.b	v5[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v5[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v5[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v5[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v5[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v5[6], w12
	lsr	w10, w10, #7
	mov.b	v5[7], w10
	bsl.8b	v2, v4, v5
	fmov	w10, s10
Lloh26:
	adrp	x15, l_convergence.targets@PAGE
Lloh27:
	add	x15, x15, l_convergence.targets@PAGEOFF
	add	x10, x15, w10, sxtw #2
	fmov	w12, s12
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x6, x9]
	lsl	x9, x9, #2
	add	x13, x7, x9
	csel	x10, x10, x13, ne
	ldr	w10, [x10]
	str	w10, [x13]
	ldr	w10, [x14, x9]
	csel	w10, w12, w10, ne
	str	w10, [x14, x9]
	csel	w21, w30, w28, ne
	and	w9, w17, #0x2
	ldrb	w10, [x8, #9]
	and	w12, w10, #0x1
	fmov	s2, w12
	ubfx	w12, w10, #1, #1
	mov.b	v2[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v2[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v2[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v2[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v2[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v2[6], w12
	lsr	w10, w10, #7
	mov.b	v2[7], w10
	ldrb	w10, [x8, #1]
	and	w12, w10, #0x1
	fmov	s6, w12
	ubfx	w12, w10, #1, #1
	mov.b	v6[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v6[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v6[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v6[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v6[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v6[6], w12
	lsr	w10, w10, #7
	mov.b	v6[7], w10
	and.8b	v7, v1, v2
	eor.8b	v2, v6, v7
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	umaxv.8b	b4, v2
	fmov	w10, s4
	eor	w10, w10, #0x1
	ands	w9, w10, w9, lsr #1
	dup.8b	v4, w9
	and.8b	v4, v4, v6
	shl.8b	v5, v4, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v3
	addv.8b	b5, v5
	fmov	w9, s5
	csetm	w10, ne
	dup.8b	v16, w10
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v3
	addv.8b	b7, v7
	stur	b7, [x8, #9]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v3
	addv.8b	b6, v6
	stur	b6, [x8, #1]
	cmp	w21, #8
	and	w10, w9, #0xff
	ccmp	w10, #0, #4, hs
	b.ne	LBB0_199
; %bb.170:                              ; %ready.overflow.resume135
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v2, v2, v3
	ldr	d6, [sp, #96]                   ; 8-byte Folded Reload
	cmeq.8b	v5, v5, v6
	mvn.8b	v5, v5
	umov.b	w10, v5[0]
	addv.8b	b5, v2
	sbfx	w12, w10, #0, #1
	fmov	s2, w12
	sbfx	w12, w10, #1, #1
	mov.b	v2[1], w12
	sbfx	w12, w10, #2, #1
	mov.b	v2[2], w12
	sbfx	w12, w10, #3, #1
	mov.b	v2[3], w12
	sbfx	w12, w10, #4, #1
	mov.b	v2[4], w12
	sbfx	w12, w10, #5, #1
	mov.b	v2[5], w12
	sbfx	w12, w10, #6, #1
	mov.b	v2[6], w12
	sbfx	w10, w10, #7, #1
	mov.b	v2[7], w10
	fmov	w10, s5
	and	w12, w17, #0xfffffffd
	tst	w10, #0xff
	csel	w17, w12, w17, eq
	sxtw	x10, w21
	tst	w9, #0xff
	csel	x9, x10, xzr, ne
	ldrb	w10, [x6, x9]
	and	w12, w10, #0x1
	fmov	s5, w12
	ubfx	w12, w10, #1, #1
	mov.b	v5[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v5[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v5[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v5[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v5[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v5[6], w12
	lsr	w10, w10, #7
	mov.b	v5[7], w10
	bsl.8b	v2, v4, v5
	mov.s	w10, v10[1]
	add	x10, x15, w10, sxtw #2
	mov.s	w12, v12[1]
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x6, x9]
	lsl	x9, x9, #2
	add	x13, x7, x9
	csel	x10, x10, x13, ne
	ldr	w10, [x10]
	str	w10, [x13]
	ldr	w10, [x14, x9]
	csel	w10, w12, w10, ne
	str	w10, [x14, x9]
	cinc	w21, w21, ne
	and	w9, w17, #0x4
	ldrb	w10, [x8, #10]
	and	w12, w10, #0x1
	fmov	s2, w12
	ubfx	w12, w10, #1, #1
	mov.b	v2[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v2[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v2[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v2[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v2[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v2[6], w12
	lsr	w10, w10, #7
	mov.b	v2[7], w10
	ldrb	w10, [x8, #2]
	and	w12, w10, #0x1
	fmov	s6, w12
	ubfx	w12, w10, #1, #1
	mov.b	v6[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v6[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v6[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v6[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v6[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v6[6], w12
	lsr	w10, w10, #7
	mov.b	v6[7], w10
	and.8b	v7, v1, v2
	eor.8b	v2, v6, v7
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	umaxv.8b	b4, v2
	fmov	w10, s4
	eor	w10, w10, #0x1
	ands	w9, w10, w9, lsr #2
	dup.8b	v4, w9
	and.8b	v4, v4, v6
	shl.8b	v5, v4, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v3
	addv.8b	b5, v5
	fmov	w9, s5
	csetm	w10, ne
	dup.8b	v16, w10
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v3
	addv.8b	b7, v7
	stur	b7, [x8, #10]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v3
	addv.8b	b6, v6
	stur	b6, [x8, #2]
	cmp	w21, #8
	and	w10, w9, #0xff
	ccmp	w10, #0, #4, hs
	b.ne	LBB0_199
; %bb.171:                              ; %ready.overflow.resume141
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v2, v2, v3
	ldr	d6, [sp, #88]                   ; 8-byte Folded Reload
	cmeq.8b	v5, v5, v6
	mvn.8b	v5, v5
	umov.b	w10, v5[0]
	addv.8b	b5, v2
	sbfx	w12, w10, #0, #1
	fmov	s2, w12
	sbfx	w12, w10, #1, #1
	mov.b	v2[1], w12
	sbfx	w12, w10, #2, #1
	mov.b	v2[2], w12
	sbfx	w12, w10, #3, #1
	mov.b	v2[3], w12
	sbfx	w12, w10, #4, #1
	mov.b	v2[4], w12
	sbfx	w12, w10, #5, #1
	mov.b	v2[5], w12
	sbfx	w12, w10, #6, #1
	mov.b	v2[6], w12
	sbfx	w10, w10, #7, #1
	mov.b	v2[7], w10
	fmov	w10, s5
	and	w12, w17, #0xfffffffb
	tst	w10, #0xff
	csel	w17, w12, w17, eq
	sxtw	x10, w21
	tst	w9, #0xff
	csel	x9, x10, xzr, ne
	ldrb	w10, [x6, x9]
	and	w12, w10, #0x1
	fmov	s5, w12
	ubfx	w12, w10, #1, #1
	mov.b	v5[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v5[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v5[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v5[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v5[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v5[6], w12
	lsr	w10, w10, #7
	mov.b	v5[7], w10
	bsl.8b	v2, v4, v5
	mov.s	w10, v10[2]
	add	x10, x15, w10, sxtw #2
	mov.s	w12, v12[2]
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x6, x9]
	lsl	x9, x9, #2
	add	x13, x7, x9
	csel	x10, x10, x13, ne
	ldr	w10, [x10]
	str	w10, [x13]
	ldr	w10, [x14, x9]
	csel	w10, w12, w10, ne
	str	w10, [x14, x9]
	cinc	w21, w21, ne
	and	w9, w17, #0x8
	ldrb	w10, [x8, #11]
	and	w12, w10, #0x1
	fmov	s2, w12
	ubfx	w12, w10, #1, #1
	mov.b	v2[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v2[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v2[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v2[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v2[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v2[6], w12
	lsr	w10, w10, #7
	mov.b	v2[7], w10
	ldrb	w10, [x8, #3]
	and	w12, w10, #0x1
	fmov	s6, w12
	ubfx	w12, w10, #1, #1
	mov.b	v6[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v6[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v6[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v6[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v6[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v6[6], w12
	lsr	w10, w10, #7
	mov.b	v6[7], w10
	and.8b	v7, v1, v2
	eor.8b	v2, v6, v7
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	umaxv.8b	b4, v2
	fmov	w10, s4
	eor	w10, w10, #0x1
	ands	w9, w10, w9, lsr #3
	dup.8b	v4, w9
	and.8b	v4, v4, v6
	shl.8b	v5, v4, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v3
	addv.8b	b5, v5
	fmov	w9, s5
	csetm	w10, ne
	dup.8b	v16, w10
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v3
	addv.8b	b7, v7
	stur	b7, [x8, #11]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v3
	addv.8b	b6, v6
	stur	b6, [x8, #3]
	cmp	w21, #8
	and	w10, w9, #0xff
	ccmp	w10, #0, #4, hs
	b.ne	LBB0_199
; %bb.172:                              ; %ready.overflow.resume147
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v2, v2, v3
	ldr	d6, [sp, #80]                   ; 8-byte Folded Reload
	cmeq.8b	v5, v5, v6
	mvn.8b	v5, v5
	umov.b	w10, v5[0]
	addv.8b	b5, v2
	sbfx	w12, w10, #0, #1
	fmov	s2, w12
	sbfx	w12, w10, #1, #1
	mov.b	v2[1], w12
	sbfx	w12, w10, #2, #1
	mov.b	v2[2], w12
	sbfx	w12, w10, #3, #1
	mov.b	v2[3], w12
	sbfx	w12, w10, #4, #1
	mov.b	v2[4], w12
	sbfx	w12, w10, #5, #1
	mov.b	v2[5], w12
	sbfx	w12, w10, #6, #1
	mov.b	v2[6], w12
	sbfx	w10, w10, #7, #1
	mov.b	v2[7], w10
	fmov	w10, s5
	and	w12, w17, #0xfffffff7
	tst	w10, #0xff
	csel	w17, w12, w17, eq
	sxtw	x10, w21
	tst	w9, #0xff
	csel	x9, x10, xzr, ne
	ldrb	w10, [x6, x9]
	and	w12, w10, #0x1
	fmov	s5, w12
	ubfx	w12, w10, #1, #1
	mov.b	v5[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v5[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v5[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v5[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v5[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v5[6], w12
	lsr	w10, w10, #7
	mov.b	v5[7], w10
	bsl.8b	v2, v4, v5
	mov.s	w10, v10[3]
	add	x10, x15, w10, sxtw #2
	mov.s	w12, v12[3]
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x6, x9]
	lsl	x9, x9, #2
	add	x13, x7, x9
	csel	x10, x10, x13, ne
	ldr	w10, [x10]
	str	w10, [x13]
	ldr	w10, [x14, x9]
	csel	w10, w12, w10, ne
	str	w10, [x14, x9]
	cinc	w23, w21, ne
	and	w9, w17, #0x10
	ldrb	w10, [x8, #12]
	and	w12, w10, #0x1
	fmov	s2, w12
	ubfx	w12, w10, #1, #1
	mov.b	v2[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v2[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v2[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v2[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v2[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v2[6], w12
	lsr	w10, w10, #7
	mov.b	v2[7], w10
	ldrb	w10, [x8, #4]
	and	w12, w10, #0x1
	fmov	s6, w12
	ubfx	w12, w10, #1, #1
	mov.b	v6[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v6[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v6[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v6[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v6[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v6[6], w12
	lsr	w10, w10, #7
	mov.b	v6[7], w10
	and.8b	v7, v1, v2
	eor.8b	v2, v6, v7
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	umaxv.8b	b4, v2
	fmov	w10, s4
	eor	w10, w10, #0x1
	ands	w9, w10, w9, lsr #4
	dup.8b	v4, w9
	and.8b	v4, v4, v6
	shl.8b	v5, v4, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v3
	addv.8b	b5, v5
	fmov	w9, s5
	csetm	w10, ne
	dup.8b	v16, w10
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v3
	addv.8b	b7, v7
	stur	b7, [x8, #12]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v3
	addv.8b	b6, v6
	stur	b6, [x8, #4]
	cmp	w23, #8
	and	w10, w9, #0xff
	ccmp	w10, #0, #4, hs
	b.ne	LBB0_199
; %bb.173:                              ; %ready.overflow.resume153
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w10, s2
	ldr	d2, [sp, #72]                   ; 8-byte Folded Reload
	cmeq.8b	v2, v5, v2
	mvn.8b	v2, v2
	umov.b	w12, v2[0]
	sbfx	w13, w12, #0, #1
	fmov	s2, w13
	sbfx	w13, w12, #1, #1
	mov.b	v2[1], w13
	sbfx	w13, w12, #2, #1
	mov.b	v2[2], w13
	sbfx	w13, w12, #3, #1
	mov.b	v2[3], w13
	sbfx	w13, w12, #4, #1
	mov.b	v2[4], w13
	sbfx	w13, w12, #5, #1
	mov.b	v2[5], w13
	sbfx	w13, w12, #6, #1
	mov.b	v2[6], w13
	sbfx	w12, w12, #7, #1
	mov.b	v2[7], w12
	and	w12, w17, #0xffffffef
	tst	w10, #0xff
	csel	w21, w12, w17, eq
	sxtw	x10, w23
	tst	w9, #0xff
	csel	x9, x10, xzr, ne
	ldrb	w10, [x6, x9]
	and	w12, w10, #0x1
	fmov	s5, w12
	ubfx	w12, w10, #1, #1
	mov.b	v5[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v5[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v5[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v5[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v5[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v5[6], w12
	lsr	w10, w10, #7
	mov.b	v5[7], w10
	bsl.8b	v2, v4, v5
	fmov	w10, s9
	add	x10, x15, w10, sxtw #2
	fmov	w12, s11
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x6, x9]
	lsl	x9, x9, #2
	add	x13, x7, x9
	csel	x10, x10, x13, ne
	ldr	w10, [x10]
	str	w10, [x13]
	ldr	w10, [x14, x9]
	csel	w10, w12, w10, ne
	str	w10, [x14, x9]
	cinc	w17, w23, ne
	and	w9, w21, #0x20
	ldrb	w10, [x8, #13]
	and	w12, w10, #0x1
	fmov	s2, w12
	ubfx	w12, w10, #1, #1
	mov.b	v2[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v2[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v2[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v2[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v2[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v2[6], w12
	lsr	w10, w10, #7
	mov.b	v2[7], w10
	ldrb	w10, [x8, #5]
	and	w12, w10, #0x1
	fmov	s6, w12
	ubfx	w12, w10, #1, #1
	mov.b	v6[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v6[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v6[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v6[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v6[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v6[6], w12
	lsr	w10, w10, #7
	mov.b	v6[7], w10
	and.8b	v7, v1, v2
	eor.8b	v2, v6, v7
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	umaxv.8b	b4, v2
	fmov	w10, s4
	eor	w10, w10, #0x1
	ands	w9, w10, w9, lsr #5
	dup.8b	v4, w9
	and.8b	v4, v4, v6
	shl.8b	v5, v4, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v3
	addv.8b	b5, v5
	fmov	w9, s5
	csetm	w10, ne
	dup.8b	v16, w10
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v3
	addv.8b	b7, v7
	stur	b7, [x8, #13]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v3
	addv.8b	b6, v6
	stur	b6, [x8, #5]
	cmp	w17, #8
	and	w10, w9, #0xff
	ccmp	w10, #0, #4, hs
	b.ne	LBB0_199
; %bb.174:                              ; %ready.overflow.resume159
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w10, s2
	ldr	d2, [sp, #64]                   ; 8-byte Folded Reload
	cmeq.8b	v2, v5, v2
	mvn.8b	v2, v2
	umov.b	w12, v2[0]
	sbfx	w13, w12, #0, #1
	fmov	s2, w13
	sbfx	w13, w12, #1, #1
	mov.b	v2[1], w13
	sbfx	w13, w12, #2, #1
	mov.b	v2[2], w13
	sbfx	w13, w12, #3, #1
	mov.b	v2[3], w13
	sbfx	w13, w12, #4, #1
	mov.b	v2[4], w13
	sbfx	w13, w12, #5, #1
	mov.b	v2[5], w13
	sbfx	w13, w12, #6, #1
	mov.b	v2[6], w13
	sbfx	w12, w12, #7, #1
	mov.b	v2[7], w12
	and	w12, w21, #0xffffffdf
	tst	w10, #0xff
	csel	w21, w12, w21, eq
	sxtw	x10, w17
	tst	w9, #0xff
	csel	x9, x10, xzr, ne
	ldrb	w10, [x6, x9]
	and	w12, w10, #0x1
	fmov	s5, w12
	ubfx	w12, w10, #1, #1
	mov.b	v5[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v5[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v5[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v5[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v5[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v5[6], w12
	lsr	w10, w10, #7
	mov.b	v5[7], w10
	mov.s	w10, v9[1]
	bsl.8b	v2, v4, v5
	add	x10, x15, w10, sxtw #2
	mov.s	w12, v11[1]
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x6, x9]
	lsl	x9, x9, #2
	add	x13, x7, x9
	csel	x10, x10, x13, ne
	ldr	w10, [x10]
	str	w10, [x13]
	ldr	w10, [x14, x9]
	csel	w10, w12, w10, ne
	str	w10, [x14, x9]
	cinc	w17, w17, ne
	ldrb	w9, [x8, #14]
	and	w10, w9, #0x1
	fmov	s2, w10
	ubfx	w10, w9, #1, #1
	mov.b	v2[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v2[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v2[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v2[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v2[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v2[6], w10
	lsr	w9, w9, #7
	mov.b	v2[7], w9
	ldrb	w9, [x8, #6]
	and	w10, w9, #0x1
	fmov	s6, w10
	ubfx	w10, w9, #1, #1
	mov.b	v6[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v6[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v6[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v6[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v6[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v6[6], w10
	and	w10, w21, #0x40
	lsr	w9, w9, #7
	mov.b	v6[7], w9
	and.8b	v7, v1, v2
	eor.8b	v2, v6, v7
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	umaxv.8b	b4, v2
	fmov	w9, s4
	eor	w9, w9, #0x1
	ands	w9, w9, w10, lsr #6
	dup.8b	v4, w9
	and.8b	v4, v4, v6
	shl.8b	v5, v4, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v3
	addv.8b	b5, v5
	fmov	w9, s5
	csetm	w10, ne
	dup.8b	v16, w10
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v3
	addv.8b	b7, v7
	stur	b7, [x8, #14]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v3
	addv.8b	b6, v6
	stur	b6, [x8, #6]
	cmp	w17, #8
	b.lo	LBB0_176
; %bb.175:                              ; %ready.overflow.resume159
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w9, #0xff
	b.ne	LBB0_199
LBB0_176:                               ; %ready.overflow.resume165
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v2, v2, v3
	ldr	d6, [sp, #56]                   ; 8-byte Folded Reload
	cmeq.8b	v5, v5, v6
	mvn.8b	v5, v5
	umov.b	w10, v5[0]
	addv.8b	b5, v2
	sbfx	w12, w10, #0, #1
	fmov	s2, w12
	sbfx	w12, w10, #1, #1
	mov.b	v2[1], w12
	sbfx	w12, w10, #2, #1
	mov.b	v2[2], w12
	sbfx	w12, w10, #3, #1
	mov.b	v2[3], w12
	sbfx	w12, w10, #4, #1
	mov.b	v2[4], w12
	sbfx	w12, w10, #5, #1
	mov.b	v2[5], w12
	sbfx	w12, w10, #6, #1
	mov.b	v2[6], w12
	sbfx	w10, w10, #7, #1
	mov.b	v2[7], w10
	fmov	w10, s5
	and	w12, w21, #0xffffffbf
	tst	w10, #0xff
	csel	w10, w12, w21, eq
	sxtw	x12, w17
	tst	w9, #0xff
	csel	x9, x12, xzr, ne
	ldrb	w12, [x6, x9]
	and	w13, w12, #0x1
	fmov	s5, w13
	ubfx	w13, w12, #1, #1
	mov.b	v5[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v5[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v5[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v5[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v5[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v5[6], w13
	lsr	w12, w12, #7
	mov.b	v5[7], w12
	bsl.8b	v2, v4, v5
	mov.s	w12, v9[2]
	add	x12, x15, w12, sxtw #2
	mov.s	w13, v11[2]
	sxtb	w21, w10
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x6, x9]
	lsl	x9, x9, #2
	ldr	w10, [x14, x9]
	csel	w10, w13, w10, ne
	add	x13, x7, x9
	csel	x12, x12, x13, ne
	ldr	w12, [x12]
	str	w10, [x14, x9]
	str	w12, [x13]
	cinc	w17, w17, ne
	cmp	w21, #0
	ldrb	w9, [x8, #15]
	and	w10, w9, #0x1
	fmov	s2, w10
	ubfx	w10, w9, #1, #1
	mov.b	v2[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v2[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v2[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v2[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v2[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v2[6], w10
	lsr	w9, w9, #7
	mov.b	v2[7], w9
	ldrb	w9, [x8, #7]
	and	w10, w9, #0x1
	fmov	s6, w10
	ubfx	w10, w9, #1, #1
	mov.b	v6[1], w10
	ubfx	w10, w9, #2, #1
	mov.b	v6[2], w10
	ubfx	w10, w9, #3, #1
	mov.b	v6[3], w10
	ubfx	w10, w9, #4, #1
	mov.b	v6[4], w10
	ubfx	w10, w9, #5, #1
	mov.b	v6[5], w10
	ubfx	w10, w9, #6, #1
	mov.b	v6[6], w10
	cset	w10, lt
	lsr	w9, w9, #7
	mov.b	v6[7], w9
	and.8b	v7, v1, v2
	eor.8b	v2, v6, v7
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	umaxv.8b	b4, v2
	fmov	w9, s4
	eor	w9, w9, #0x1
	ands	w9, w10, w9
	dup.8b	v4, w9
	and.8b	v4, v4, v6
	shl.8b	v5, v4, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v3
	addv.8b	b5, v5
	fmov	w9, s5
	csetm	w10, ne
	dup.8b	v16, w10
	bic.8b	v7, v7, v16
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	and.8b	v7, v7, v3
	addv.8b	b7, v7
	stur	b7, [x8, #15]
	bic.8b	v6, v6, v16
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	and.8b	v6, v6, v3
	addv.8b	b6, v6
	stur	b6, [x8, #7]
	cmp	w17, #8
	b.lo	LBB0_178
; %bb.177:                              ; %ready.overflow.resume165
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w9, #0xff
	b.ne	LBB0_199
LBB0_178:                               ; %ready.overflow.resume171
                                        ;   in Loop: Header=BB0_5 Depth=1
	and.8b	v2, v2, v3
	addv.8b	b6, v2
	ldr	d2, [sp, #48]                   ; 8-byte Folded Reload
	cmeq.8b	v2, v5, v2
	mvn.8b	v2, v2
	umov.b	w10, v2[0]
	sbfx	w12, w10, #0, #1
	fmov	s2, w12
	sbfx	w12, w10, #1, #1
	mov.b	v2[1], w12
	sbfx	w12, w10, #2, #1
	mov.b	v2[2], w12
	sbfx	w12, w10, #3, #1
	mov.b	v2[3], w12
	sbfx	w12, w10, #4, #1
	mov.b	v2[4], w12
	sbfx	w12, w10, #5, #1
	mov.b	v2[5], w12
	sbfx	w12, w10, #6, #1
	mov.b	v2[6], w12
	fmov	w12, s6
	sbfx	w10, w10, #7, #1
	mov.b	v2[7], w10
	and	w10, w21, #0x7f
	tst	w12, #0xff
	csel	w27, w10, w21, eq
	sxtw	x10, w17
	tst	w9, #0xff
	csel	x9, x10, xzr, ne
	ldrb	w10, [x6, x9]
	and	w12, w10, #0x1
	fmov	s5, w12
	ubfx	w12, w10, #1, #1
	mov.b	v5[1], w12
	ubfx	w12, w10, #2, #1
	mov.b	v5[2], w12
	ubfx	w12, w10, #3, #1
	mov.b	v5[3], w12
	ubfx	w12, w10, #4, #1
	mov.b	v5[4], w12
	ubfx	w12, w10, #5, #1
	mov.b	v5[5], w12
	ubfx	w12, w10, #6, #1
	mov.b	v5[6], w12
	lsr	w10, w10, #7
	mov.b	v5[7], w10
	bsl.8b	v2, v4, v5
	mov.s	w10, v9[3]
	mov.s	w12, v11[3]
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x6, x9]
Lloh28:
	adrp	x13, l_convergence.targets@PAGE
Lloh29:
	add	x13, x13, l_convergence.targets@PAGEOFF
	add	x10, x13, w10, sxtw #2
	lsl	x9, x9, #2
	add	x13, x7, x9
	csel	x10, x10, x13, ne
	ldr	w10, [x10]
	str	w10, [x13]
	ldr	w10, [x14, x9]
	csel	w10, w12, w10, ne
	str	w10, [x14, x9]
	cinc	w28, w17, ne
	b	LBB0_4
LBB0_179:                               ; %varying.coherent.false86
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w23, #0, LBB0_4
	b	LBB0_189
LBB0_180:                               ;   in Loop: Header=BB0_5 Depth=1
	mov	w27, #0                         ; =0x0
	b	LBB0_4
LBB0_181:                               ; %cond.store225
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d16
	str	s6, [x10]
	tbz	w9, #1, LBB0_147
LBB0_182:                               ; %cond.store229
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v16[1]
	st1.s	{ v6 }[1], [x10]
	tbz	w9, #2, LBB0_148
LBB0_183:                               ; %cond.store233
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d7
	st1.s	{ v6 }[2], [x10]
	tbz	w9, #3, LBB0_149
LBB0_184:                               ; %cond.store237
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v7[1]
	st1.s	{ v6 }[3], [x10]
	tbz	w9, #4, LBB0_150
LBB0_185:                               ; %cond.store241
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d5
	str	s2, [x10]
	tbz	w9, #5, LBB0_151
LBB0_186:                               ; %cond.store245
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x10, v5[1]
	st1.s	{ v2 }[1], [x10]
	tbz	w9, #6, LBB0_152
LBB0_187:                               ; %cond.store249
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x10, d4
	st1.s	{ v2 }[2], [x10]
	tbz	w9, #7, LBB0_189
LBB0_188:                               ; %cond.store253
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x9, v4[1]
	st1.s	{ v2 }[3], [x9]
LBB0_189:                               ; %schedule.9
                                        ;   in Loop: Header=BB0_5 Depth=1
	cbz	w17, LBB0_194
; %bb.190:                              ; %convergence.cascade89.preheader
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	w23, #0                         ; =0x0
LBB0_191:                               ; %convergence.cascade89
                                        ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v2, v13, #7
	cmlt.8b	v2, v2, #0
	and.8b	v4, v2, v3
	addv.8b	b4, v4
	fmov	w9, s4
	umaxv.8b	b2, v2
	fmov	w12, s2
	sub	w10, w17, #1
	tst	w9, #0xff
	csel	w25, w10, wzr, ne
	lsl	w9, w11, w25
	and	w10, w9, w27
	tst	w10, #0xff
	cset	w13, ne
	str	q10, [sp, #1056]
	str	q9, [sp, #1072]
	ubfiz	x24, x25, #2, #3
	ldr	w10, [x16, x24]
	cmp	w10, #3
	cset	w10, eq
	and	w26, w13, w12
	ldrb	w12, [x20, w25, sxtw]
	and	w13, w12, #0x1
	fmov	s2, w13
	ubfx	w13, w12, #1, #1
	mov.b	v2[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v2[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v2[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v2[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v2[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v2[6], w13
	lsr	w12, w12, #7
	mov.b	v2[7], w12
	ldrb	w12, [x8, w25, sxtw]
	and	w13, w12, #0x1
	fmov	s4, w13
	ubfx	w13, w12, #1, #1
	mov.b	v4[1], w13
	ubfx	w13, w12, #2, #1
	mov.b	v4[2], w13
	ubfx	w13, w12, #3, #1
	mov.b	v4[3], w13
	ubfx	w13, w12, #4, #1
	mov.b	v4[4], w13
	ubfx	w13, w12, #5, #1
	mov.b	v4[5], w13
	ubfx	w13, w12, #6, #1
	mov.b	v4[6], w13
	lsr	w12, w12, #7
	mov.b	v4[7], w12
	orr.8b	v5, v13, v4
	and.8b	v6, v1, v2
	eor.8b	v6, v6, v5
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	umaxv.8b	b6, v6
	fmov	w12, s6
	ands	w10, w26, w10
	csetm	w13, ne
	bics	w12, w10, w12
	csetm	w15, ne
	dup.8b	v6, w15
	dup.8b	v7, w13
	bic.8b	v16, v5, v6
	bit.8b	v4, v16, v7
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v3
	addv.8b	b4, v4
	str	b4, [x8, w25, sxtw]
	bic.8b	v2, v2, v6
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	str	b2, [x20, w25, sxtw]
	csinv	w9, w3, w9, eq
	dup.8b	v2, w10
	and	w27, w9, w27
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	dup.8b	v4, w12
	and.8b	v4, v4, v5
	str	q12, [sp, #1024]
	str	q11, [sp, #1040]
	ldr	w9, [x0, x24]
	csel	w17, w9, w17, ne
	bit.8b	v13, v4, v2
	shl.8b	v2, v13, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w9, s2
	cmp	w10, #1
	b.ne	LBB0_195
; %bb.192:                              ; %convergence.cascade89
                                        ;   in Loop: Header=BB0_191 Depth=2
	cmp	w17, #0
	ccmp	w23, #6, #2, ne
	b.hi	LBB0_195
; %bb.193:                              ; %convergence.cascade89
                                        ;   in Loop: Header=BB0_191 Depth=2
	add	w23, w23, #1
	tst	w9, #0xff
	b.ne	LBB0_191
	b	LBB0_195
LBB0_194:                               ; %schedule.9.convergence.cascade.exit90_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v2, v13, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w9, s2
LBB0_195:                               ; %convergence.cascade.exit90
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w9, #0xff
	b.eq	LBB0_4
; %bb.196:                              ; %convergence.target.9.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	movi.8b	v2, #1
	and.8b	v2, v13, v2
	ushll.8h	v2, v2, #0
	ushll.4s	v4, v2, #0
	ushll2.4s	v2, v2, #0
	uaddw2.2d	v26, v26, v2
	uaddw.2d	v25, v25, v2
	uaddw2.2d	v24, v24, v4
	uaddw.2d	v31, v31, v4
	b	LBB0_116
LBB0_197:                               ; %scheduler.done
	shl.8b	v0, v1, #7
	cmlt.8b	v0, v0, #0
	umaxv.8b	b0, v0
	fmov	w8, s0
	tbnz	w8, #0, LBB0_199
; %bb.198:                              ; %scheduler.exit
	sub	sp, x29, #144
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
LBB0_199:                               ; %scheduler.stalled
	brk	#0x1
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdd	Lloh18, Lloh19
	.loh AdrpAdd	Lloh20, Lloh21
	.loh AdrpAdd	Lloh22, Lloh23
	.loh AdrpAdd	Lloh24, Lloh25
	.loh AdrpAdd	Lloh26, Lloh27
	.loh AdrpAdd	Lloh28, Lloh29
	.section	__TEXT,__const
	.p2align	1, 0x0
LJTI0_0:
	.short	(LBB0_7-LBB0_7)>>2
	.short	(LBB0_44-LBB0_7)>>2
	.short	(LBB0_9-LBB0_7)>>2
	.short	(LBB0_19-LBB0_7)>>2
	.short	(LBB0_73-LBB0_7)>>2
	.short	(LBB0_79-LBB0_7)>>2
	.short	(LBB0_116-LBB0_7)>>2
	.short	(LBB0_8-LBB0_7)>>2
	.short	(LBB0_10-LBB0_7)>>2
	.short	(LBB0_189-LBB0_7)>>2
	.short	(LBB0_159-LBB0_7)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_tile_transpose.packet_batch    ; -- Begin function tile_transpose.packet_batch
	.p2align	2
_tile_transpose.packet_batch:           ; @tile_transpose.packet_batch
; %bb.0:                                ; %packet.batch.prologue
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	mov	x21, x3
	mov	x19, x2
	mov	x20, x0
	ldr	w23, [x2, #36]
	ldr	w8, [x2]
	ldr	w9, [x2, #12]
	lsl	x8, x8, #6
	cmp	x8, x9
	csel	x10, x8, xzr, ls
	add	x10, x10, x23
	subs	x11, x9, x10
	mov	w12, #64                        ; =0x40
	sub	x13, x12, x23
	cmp	x11, x13
	csel	x11, x11, x13, lo
	cmp	x9, x10
	ccmp	x23, x12, #2, hi
	ccmp	x8, x9, #2, lo
	csel	x8, x11, xzr, ls
	cmp	w3, #8
	b.ne	LBB1_3
; %bb.1:                                ; %packet.batch.prologue
	cmp	x8, #64
	b.lo	LBB1_3
; %bb.2:                                ; %packet.batch.full
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_transpose
	add	w8, w23, #8
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_transpose
	add	w8, w23, #16
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_transpose
	add	w8, w23, #24
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_transpose
	add	w8, w23, #32
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_transpose
	add	w8, w23, #40
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_transpose
	add	w8, w23, #48
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_transpose
	add	w8, w23, #56
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	b	_tile_transpose
LBB1_3:                                 ; %packet.batch.partial
	ubfiz	x9, x21, #3, #32
	cmp	x8, x9
	csel	x8, x8, x9, lo
	lsr	x24, x8, #3
	and	w22, w8, #0x7
	cmp	x8, #8
	b.lo	LBB1_6
; %bb.4:                                ; %packet.batch.partial.full.loop.preheader
	mov	x25, x24
	mov	x26, x23
LBB1_5:                                 ; %packet.batch.partial.full.loop
                                        ; =>This Inner Loop Header: Depth=1
	str	w26, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_transpose
	add	w26, w26, #8
	subs	w25, w25, #1
	b.ne	LBB1_5
LBB1_6:                                 ; %packet.batch.tail.check
	cbz	w22, LBB1_8
; %bb.7:                                ; %packet.batch.tail.call
	add	w8, w23, w24, lsl #3
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	x2, x22
	bl	_tile_transpose
LBB1_8:                                 ; %packet.batch.partial.finish
	lsl	w8, w21, #3
	sub	w8, w8, #8
	cmp	w21, #0
	csel	w8, wzr, w8, eq
	add	w8, w23, w8
	str	w8, [x19, #36]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	2, 0x0                          ; @convergence.targets
l_convergence.targets:
	.long	5                               ; 0x5
	.long	4                               ; 0x4
	.long	10                              ; 0xa
	.long	9                               ; 0x9

.subsections_via_symbols

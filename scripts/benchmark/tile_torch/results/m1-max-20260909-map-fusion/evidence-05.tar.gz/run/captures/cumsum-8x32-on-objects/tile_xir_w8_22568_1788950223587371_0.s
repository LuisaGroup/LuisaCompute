	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function tile_inclusive_scan
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_tile_inclusive_scan:                   ; @tile_inclusive_scan
; %bb.0:                                ; %prologue
	stp	x28, x27, [sp, #-16]!           ; 16-byte Folded Spill
	sub	sp, sp, #6, lsl #12             ; =24576
	sub	sp, sp, #144
	dup.4s	v1, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q2, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q3, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v0, v1, v3
	cmhi.4s	v1, v1, v2
	uzp1.8h	v6, v1, v0
	umaxv.8h	h4, v6
	fmov	w8, s4
	tbz	w8, #0, LBB0_57
; %bb.1:                                ; %direct.activate
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	ldr	w8, [x1]
	ldr	w11, [x1, #36]
	add	w8, w11, w8, lsl #5
	dup.4s	v4, w8
	add	x11, sp, #6, lsl #12            ; =24576
	ldr	x12, [x0]
	ldr	x8, [x0, #16]
	sshll.2d	v5, v1, #0
	sshll.2d	v7, v0, #0
	sshll2.2d	v16, v1, #0
	sshll2.2d	v17, v0, #0
	add.4s	v3, v4, v3
	add.4s	v2, v4, v2
	and.16b	v2, v1, v2
	and.16b	v3, v0, v3
	ushll.2d	v18, v2, #2
	ushll.2d	v4, v3, #2
	ushll2.2d	v19, v2, #2
	ushll2.2d	v2, v3, #2
	and.16b	v2, v17, v2
	and.16b	v3, v16, v19
	and.16b	v4, v7, v4
	and.16b	v5, v5, v18
	movi.2d	v7, #0000000000000000
	stp	q7, q7, [x11, #16]!
	stp	q7, q7, [x11, #32]
	stp	q7, q7, [x11, #64]
	stp	q7, q7, [x11, #96]
Lloh4:
	adrp	x11, lCPI0_2@PAGE
Lloh5:
	ldr	q7, [x11, lCPI0_2@PAGEOFF]
	and.16b	v6, v6, v7
	addv.8h	h6, v6
	fmov	w11, s6
	dup.2d	v7, x12
	add	x12, sp, #5, lsl #12            ; =20480
	add	x12, x12, #16
	b	LBB0_3
LBB0_2:                                 ; %else33
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x13, x12, x10, lsl #5
	ldp	q18, q19, [x13]
	bif.16b	v17, v19, v0
	bif.16b	v16, v18, v1
	stp	q16, q17, [x13]
	add	x10, x10, #1
	add	x9, x9, #4
	cmp	x9, #512
	b.eq	LBB0_19
LBB0_3:                                 ; %direct.true80
                                        ; =>This Inner Loop Header: Depth=1
	lsr	x13, x10, #5
	dup.2d	v18, x13
	add.2d	v16, v18, v5
	shl.2d	v16, v16, #7
	and	x13, x9, #0x7c
	dup.2d	v19, x13
	orr.16b	v16, v16, v19
	add.2d	v20, v7, v16
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbnz	w11, #0, LBB0_11
; %bb.4:                                ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w13, w11, #0xff
	tbnz	w13, #1, LBB0_12
LBB0_5:                                 ; %else15
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v20, v18, v3
	shl.2d	v20, v20, #7
	orr.16b	v20, v20, v19
	add.2d	v20, v7, v20
	tbnz	w13, #2, LBB0_13
LBB0_6:                                 ; %else18
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w13, #3, LBB0_14
LBB0_7:                                 ; %else21
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v20, v18, v4
	shl.2d	v20, v20, #7
	orr.16b	v20, v20, v19
	add.2d	v20, v7, v20
	tbnz	w13, #4, LBB0_15
LBB0_8:                                 ; %else24
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w13, #5, LBB0_16
LBB0_9:                                 ; %else27
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v18, v18, v2
	shl.2d	v18, v18, #7
	orr.16b	v18, v18, v19
	add.2d	v18, v7, v18
	tbnz	w13, #6, LBB0_17
LBB0_10:                                ; %else30
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w13, #7, LBB0_2
	b	LBB0_18
LBB0_11:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x13, d20
	ldr	s16, [x13]
	and	w13, w11, #0xff
	tbz	w13, #1, LBB0_5
LBB0_12:                                ; %cond.load14
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x14, v20[1]
	ld1.s	{ v16 }[1], [x14]
	add.2d	v20, v18, v3
	shl.2d	v20, v20, #7
	orr.16b	v20, v20, v19
	add.2d	v20, v7, v20
	tbz	w13, #2, LBB0_6
LBB0_13:                                ; %cond.load17
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x14, d20
	ld1.s	{ v16 }[2], [x14]
	tbz	w13, #3, LBB0_7
LBB0_14:                                ; %cond.load20
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x14, v20[1]
	ld1.s	{ v16 }[3], [x14]
	add.2d	v20, v18, v4
	shl.2d	v20, v20, #7
	orr.16b	v20, v20, v19
	add.2d	v20, v7, v20
	tbz	w13, #4, LBB0_8
LBB0_15:                                ; %cond.load23
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x14, d20
	ld1.s	{ v17 }[0], [x14]
	tbz	w13, #5, LBB0_9
LBB0_16:                                ; %cond.load26
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x14, v20[1]
	ld1.s	{ v17 }[1], [x14]
	add.2d	v18, v18, v2
	shl.2d	v18, v18, #7
	orr.16b	v18, v18, v19
	add.2d	v18, v7, v18
	tbz	w13, #6, LBB0_10
LBB0_17:                                ; %cond.load29
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x14, d18
	ld1.s	{ v17 }[2], [x14]
	tbz	w13, #7, LBB0_2
LBB0_18:                                ; %cond.load32
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x13, v18[1]
	ld1.s	{ v17 }[3], [x13]
	b	LBB0_2
LBB0_19:                                ; %direct.true96.preheader
	mov	x9, #0                          ; =0x0
	movi.2d	v7, #0000000000000000
	add	x10, sp, #5, lsl #12            ; =20480
	add	x10, x10, #16
	add	x11, sp, #4, lsl #12            ; =16384
	add	x11, x11, #16
	movi.2d	v16, #0000000000000000
	b	LBB0_21
LBB0_20:                                ; %direct.schedule.9
                                        ;   in Loop: Header=BB0_21 Depth=1
	add	x12, x10, x9, lsl #5
	ldp	q20, q19, [x12]
	tst	x9, #0x1f
	cset	w12, ne
	bit.16b	v7, v18, v1
	bit.16b	v16, v17, v0
	dup.4h	v17, w12
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	and.16b	v18, v17, v16
	and.16b	v17, v17, v7
	fadd.4s	v17, v20, v17
	fadd.4s	v18, v19, v18
	add	x12, x11, x9, lsl #5
	ldp	q19, q20, [x12]
	bif.16b	v18, v20, v0
	bif.16b	v17, v19, v1
	stp	q17, q18, [x12]
	add	x9, x9, #1
	cmp	x9, #128
	b.eq	LBB0_23
LBB0_21:                                ; %direct.true96
                                        ; =>This Inner Loop Header: Depth=1
	and	x12, x9, #0x7f
	sub	x12, x12, #1
	movi.2d	v18, #0000000000000000
	movi.2d	v17, #0000000000000000
	cmp	x12, #127
	b.hi	LBB0_20
; %bb.22:                               ; %direct.true106
                                        ;   in Loop: Header=BB0_21 Depth=1
	add	x12, x10, x12, lsl #5
	ldp	q18, q17, [x12]
	b	LBB0_20
LBB0_23:                                ; %direct.true130.preheader
	mov	x9, #0                          ; =0x0
	movi.2d	v7, #0000000000000000
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #16
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #16
	movi.2d	v16, #0000000000000000
	b	LBB0_25
LBB0_24:                                ; %direct.schedule.14
                                        ;   in Loop: Header=BB0_25 Depth=1
	add	x12, x10, x9, lsl #5
	ldp	q20, q19, [x12]
	and	x12, x9, #0x1f
	cmp	x12, #1
	cset	w12, hi
	bit.16b	v7, v18, v1
	bit.16b	v16, v17, v0
	dup.4h	v17, w12
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	and.16b	v18, v17, v16
	and.16b	v17, v17, v7
	fadd.4s	v17, v20, v17
	fadd.4s	v18, v19, v18
	add	x12, x11, x9, lsl #5
	ldp	q19, q20, [x12]
	bif.16b	v18, v20, v0
	bif.16b	v17, v19, v1
	stp	q17, q18, [x12]
	add	x9, x9, #1
	cmp	x9, #128
	b.eq	LBB0_27
LBB0_25:                                ; %direct.true130
                                        ; =>This Inner Loop Header: Depth=1
	and	x12, x9, #0x7f
	sub	x12, x12, #2
	movi.2d	v18, #0000000000000000
	movi.2d	v17, #0000000000000000
	cmp	x12, #127
	b.hi	LBB0_24
; %bb.26:                               ; %direct.true141
                                        ;   in Loop: Header=BB0_25 Depth=1
	add	x12, x10, x12, lsl #5
	ldp	q18, q17, [x12]
	b	LBB0_24
LBB0_27:                                ; %direct.true165.preheader
	mov	x9, #0                          ; =0x0
	movi.2d	v7, #0000000000000000
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #16
	add	x11, sp, #2, lsl #12            ; =8192
	add	x11, x11, #16
	movi.2d	v16, #0000000000000000
	b	LBB0_29
LBB0_28:                                ; %direct.schedule.19
                                        ;   in Loop: Header=BB0_29 Depth=1
	add	x12, x10, x9, lsl #5
	ldp	q20, q19, [x12]
	and	x12, x9, #0x1f
	cmp	x12, #3
	cset	w12, hi
	bit.16b	v7, v18, v1
	bit.16b	v16, v17, v0
	dup.4h	v17, w12
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	and.16b	v18, v17, v16
	and.16b	v17, v17, v7
	fadd.4s	v17, v20, v17
	fadd.4s	v18, v19, v18
	add	x12, x11, x9, lsl #5
	ldp	q19, q20, [x12]
	bif.16b	v18, v20, v0
	bif.16b	v17, v19, v1
	stp	q17, q18, [x12]
	add	x9, x9, #1
	cmp	x9, #128
	b.eq	LBB0_31
LBB0_29:                                ; %direct.true165
                                        ; =>This Inner Loop Header: Depth=1
	and	x12, x9, #0x7f
	sub	x12, x12, #4
	movi.2d	v18, #0000000000000000
	movi.2d	v17, #0000000000000000
	cmp	x12, #127
	b.hi	LBB0_28
; %bb.30:                               ; %direct.true176
                                        ;   in Loop: Header=BB0_29 Depth=1
	add	x12, x10, x12, lsl #5
	ldp	q18, q17, [x12]
	b	LBB0_28
LBB0_31:                                ; %direct.true200.preheader
	mov	x9, #0                          ; =0x0
	movi.2d	v7, #0000000000000000
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #16
	add	x11, sp, #1, lsl #12            ; =4096
	add	x11, x11, #16
	movi.2d	v16, #0000000000000000
	b	LBB0_33
LBB0_32:                                ; %direct.schedule.24
                                        ;   in Loop: Header=BB0_33 Depth=1
	add	x12, x10, x9, lsl #5
	ldp	q20, q19, [x12]
	and	x12, x9, #0x1f
	cmp	x12, #7
	cset	w12, hi
	bit.16b	v7, v18, v1
	bit.16b	v16, v17, v0
	dup.4h	v17, w12
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	and.16b	v18, v17, v16
	and.16b	v17, v17, v7
	fadd.4s	v17, v20, v17
	fadd.4s	v18, v19, v18
	add	x12, x11, x9, lsl #5
	ldp	q19, q20, [x12]
	bif.16b	v18, v20, v0
	bif.16b	v17, v19, v1
	stp	q17, q18, [x12]
	add	x9, x9, #1
	cmp	x9, #128
	b.eq	LBB0_35
LBB0_33:                                ; %direct.true200
                                        ; =>This Inner Loop Header: Depth=1
	and	x12, x9, #0x7f
	sub	x12, x12, #8
	movi.2d	v18, #0000000000000000
	movi.2d	v17, #0000000000000000
	cmp	x12, #127
	b.hi	LBB0_32
; %bb.34:                               ; %direct.true211
                                        ;   in Loop: Header=BB0_33 Depth=1
	add	x12, x10, x12, lsl #5
	ldp	q18, q17, [x12]
	b	LBB0_32
LBB0_35:                                ; %direct.true235.preheader
	mov	x9, #0                          ; =0x0
	movi.2d	v7, #0000000000000000
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #16
	add	x11, sp, #6, lsl #12            ; =24576
	add	x11, x11, #16
	add	x12, sp, #16
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	b	LBB0_37
LBB0_36:                                ; %direct.schedule.29
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x14, x10, x9, lsl #5
	ldp	q21, q22, [x14]
	bit.16b	v18, v22, v0
	bit.16b	v17, v21, v1
	and	x14, x9, #0x1f
	cmp	x14, #15
	cset	w14, hi
	bit.16b	v16, v20, v0
	bit.16b	v7, v19, v1
	dup.4h	v19, w14
	ushll.4s	v19, v19, #0
	shl.4s	v19, v19, #31
	cmlt.4s	v19, v19, #0
	and.16b	v20, v19, v7
	and.16b	v19, v19, v16
	fadd.4s	v19, v18, v19
	fadd.4s	v20, v17, v20
	add	x13, x11, x13
	ldp	q22, q21, [x13]
	fadd.4s	v20, v22, v20
	fadd.4s	v19, v21, v19
	add	x13, x12, x9, lsl #5
	ldp	q21, q22, [x13]
	bif.16b	v19, v22, v0
	bif.16b	v20, v21, v1
	stp	q20, q19, [x13]
	add	x9, x9, #1
	cmp	x9, #128
	b.eq	LBB0_39
LBB0_37:                                ; %direct.true235
                                        ; =>This Inner Loop Header: Depth=1
	and	x13, x9, #0x60
	mov	x14, x13
	bfxil	x14, x9, #0, #5
	sub	x14, x14, #16
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	cmp	x14, #127
	b.hi	LBB0_36
; %bb.38:                               ; %direct.true246
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x14, x10, x14, lsl #5
	ldp	q19, q20, [x14]
	b	LBB0_36
LBB0_39:                                ; %direct.true276.preheader
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	fmov	w11, s6
	add	x12, sp, #16
	dup.2d	v6, x8
	b	LBB0_41
LBB0_40:                                ; %else58
                                        ;   in Loop: Header=BB0_41 Depth=1
	add	x10, x10, #1
	add	x9, x9, #4
	cmp	x9, #512
	b.eq	LBB0_57
LBB0_41:                                ; %direct.true276
                                        ; =>This Inner Loop Header: Depth=1
	lsr	x8, x10, #5
	dup.2d	v7, x8
	add.2d	v16, v7, v5
	add	x13, x12, x10, lsl #5
	ldr	q17, [x13]
	and.16b	v17, v1, v17
	shl.2d	v18, v16, #7
	and	x8, x9, #0x7c
	dup.2d	v16, x8
	orr.16b	v18, v18, v16
	add.2d	v18, v6, v18
	tbnz	w11, #0, LBB0_50
; %bb.42:                               ; %else37
                                        ;   in Loop: Header=BB0_41 Depth=1
	and	w8, w11, #0xff
	tbnz	w8, #1, LBB0_51
LBB0_43:                                ; %else40
                                        ;   in Loop: Header=BB0_41 Depth=1
	add.2d	v18, v7, v3
	shl.2d	v18, v18, #7
	orr.16b	v18, v18, v16
	add.2d	v18, v6, v18
	tbnz	w8, #2, LBB0_52
LBB0_44:                                ; %else43
                                        ;   in Loop: Header=BB0_41 Depth=1
	tbz	w8, #3, LBB0_46
LBB0_45:                                ; %cond.store44
                                        ;   in Loop: Header=BB0_41 Depth=1
	mov.d	x14, v18[1]
	st1.s	{ v17 }[3], [x14]
LBB0_46:                                ; %else46
                                        ;   in Loop: Header=BB0_41 Depth=1
	add.2d	v18, v7, v4
	ldr	q17, [x13, #16]
	and.16b	v17, v0, v17
	shl.2d	v18, v18, #7
	orr.16b	v18, v18, v16
	add.2d	v18, v6, v18
	tbnz	w8, #4, LBB0_53
; %bb.47:                               ; %else49
                                        ;   in Loop: Header=BB0_41 Depth=1
	tbnz	w8, #5, LBB0_54
LBB0_48:                                ; %else52
                                        ;   in Loop: Header=BB0_41 Depth=1
	add.2d	v7, v7, v2
	shl.2d	v7, v7, #7
	orr.16b	v7, v7, v16
	add.2d	v7, v6, v7
	tbnz	w8, #6, LBB0_55
LBB0_49:                                ; %else55
                                        ;   in Loop: Header=BB0_41 Depth=1
	tbz	w8, #7, LBB0_40
	b	LBB0_56
LBB0_50:                                ; %cond.store
                                        ;   in Loop: Header=BB0_41 Depth=1
	fmov	x8, d18
	str	s17, [x8]
	and	w8, w11, #0xff
	tbz	w8, #1, LBB0_43
LBB0_51:                                ; %cond.store38
                                        ;   in Loop: Header=BB0_41 Depth=1
	mov.d	x14, v18[1]
	st1.s	{ v17 }[1], [x14]
	add.2d	v18, v7, v3
	shl.2d	v18, v18, #7
	orr.16b	v18, v18, v16
	add.2d	v18, v6, v18
	tbz	w8, #2, LBB0_44
LBB0_52:                                ; %cond.store41
                                        ;   in Loop: Header=BB0_41 Depth=1
	fmov	x14, d18
	st1.s	{ v17 }[2], [x14]
	tbnz	w8, #3, LBB0_45
	b	LBB0_46
LBB0_53:                                ; %cond.store47
                                        ;   in Loop: Header=BB0_41 Depth=1
	fmov	x13, d18
	str	s17, [x13]
	tbz	w8, #5, LBB0_48
LBB0_54:                                ; %cond.store50
                                        ;   in Loop: Header=BB0_41 Depth=1
	mov.d	x13, v18[1]
	st1.s	{ v17 }[1], [x13]
	add.2d	v7, v7, v2
	shl.2d	v7, v7, #7
	orr.16b	v7, v7, v16
	add.2d	v7, v6, v7
	tbz	w8, #6, LBB0_49
LBB0_55:                                ; %cond.store53
                                        ;   in Loop: Header=BB0_41 Depth=1
	fmov	x13, d7
	st1.s	{ v17 }[2], [x13]
	tbz	w8, #7, LBB0_40
LBB0_56:                                ; %cond.store56
                                        ;   in Loop: Header=BB0_41 Depth=1
	mov.d	x8, v7[1]
	st1.s	{ v17 }[3], [x8]
	b	LBB0_40
LBB0_57:                                ; %common.ret
	add	sp, sp, #6, lsl #12             ; =24576
	add	sp, sp, #144
	ldp	x28, x27, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
                                        ; -- End function
	.globl	_tile_inclusive_scan.packet_batch.blocks ; -- Begin function tile_inclusive_scan.packet_batch.blocks
	.p2align	2
_tile_inclusive_scan.packet_batch.blocks: ; @tile_inclusive_scan.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_13
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w24, w25, [x2]
	ldp	w27, w26, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Folded Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
LBB1_3:                                 ; %tile_inclusive_scan.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w24, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w24, wzr, w24, eq
	cinc	w9, w25, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w25, wzr, w9, ne
	add	w27, w27, w8
	subs	w19, w19, #1
	b.eq	LBB1_12
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x24, #5, #32
	cmp	x8, x26
	csel	x9, x8, xzr, ls
	subs	x10, x26, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x26, x9
	stp	w24, w25, [x20]
	str	w27, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x26, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cmp	x22, #8
	b.lo	LBB1_9
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	cmp	x28, #1
	b.eq	LBB1_9
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	cmp	x28, #2
	b.eq	LBB1_9
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
LBB1_9:                                 ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_11
; %bb.10:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_tile_inclusive_scan
LBB1_11:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Folded Reload
	b	LBB1_3
LBB1_12:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_13:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

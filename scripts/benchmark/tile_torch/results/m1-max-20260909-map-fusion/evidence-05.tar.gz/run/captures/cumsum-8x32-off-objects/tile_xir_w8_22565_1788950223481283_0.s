	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function tile_inclusive_scan
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_4:
	.quad	120                             ; 0x78
	.quad	124                             ; 0x7c
lCPI0_5:
	.quad	112                             ; 0x70
	.quad	116                             ; 0x74
lCPI0_6:
	.quad	104                             ; 0x68
	.quad	108                             ; 0x6c
lCPI0_7:
	.quad	96                              ; 0x60
	.quad	100                             ; 0x64
lCPI0_8:
	.quad	88                              ; 0x58
	.quad	92                              ; 0x5c
lCPI0_9:
	.quad	80                              ; 0x50
	.quad	84                              ; 0x54
lCPI0_10:
	.quad	72                              ; 0x48
	.quad	76                              ; 0x4c
lCPI0_11:
	.quad	64                              ; 0x40
	.quad	68                              ; 0x44
lCPI0_12:
	.quad	56                              ; 0x38
	.quad	60                              ; 0x3c
lCPI0_13:
	.quad	48                              ; 0x30
	.quad	52                              ; 0x34
lCPI0_14:
	.quad	40                              ; 0x28
	.quad	44                              ; 0x2c
lCPI0_15:
	.quad	32                              ; 0x20
	.quad	36                              ; 0x24
lCPI0_16:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_17:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_18:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_19:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_20:
	.quad	16                              ; 0x10
	.quad	24                              ; 0x18
lCPI0_21:
	.quad	0                               ; 0x0
	.quad	8                               ; 0x8
lCPI0_22:
	.quad	48                              ; 0x30
	.quad	56                              ; 0x38
lCPI0_23:
	.quad	32                              ; 0x20
	.quad	40                              ; 0x28
lCPI0_24:
	.quad	112                             ; 0x70
	.quad	120                             ; 0x78
lCPI0_25:
	.quad	96                              ; 0x60
	.quad	104                             ; 0x68
lCPI0_26:
	.quad	80                              ; 0x50
	.quad	88                              ; 0x58
lCPI0_27:
	.quad	64                              ; 0x40
	.quad	72                              ; 0x48
lCPI0_28:
	.quad	176                             ; 0xb0
	.quad	184                             ; 0xb8
lCPI0_29:
	.quad	160                             ; 0xa0
	.quad	168                             ; 0xa8
lCPI0_30:
	.quad	144                             ; 0x90
	.quad	152                             ; 0x98
lCPI0_31:
	.quad	128                             ; 0x80
	.quad	136                             ; 0x88
lCPI0_32:
	.quad	240                             ; 0xf0
	.quad	248                             ; 0xf8
lCPI0_33:
	.quad	224                             ; 0xe0
	.quad	232                             ; 0xe8
lCPI0_34:
	.quad	208                             ; 0xd0
	.quad	216                             ; 0xd8
lCPI0_35:
	.quad	192                             ; 0xc0
	.quad	200                             ; 0xc8
lCPI0_36:
	.quad	304                             ; 0x130
	.quad	312                             ; 0x138
lCPI0_37:
	.quad	288                             ; 0x120
	.quad	296                             ; 0x128
lCPI0_38:
	.quad	272                             ; 0x110
	.quad	280                             ; 0x118
lCPI0_39:
	.quad	256                             ; 0x100
	.quad	264                             ; 0x108
lCPI0_40:
	.quad	368                             ; 0x170
	.quad	376                             ; 0x178
lCPI0_41:
	.quad	352                             ; 0x160
	.quad	360                             ; 0x168
lCPI0_42:
	.quad	336                             ; 0x150
	.quad	344                             ; 0x158
lCPI0_43:
	.quad	320                             ; 0x140
	.quad	328                             ; 0x148
lCPI0_44:
	.quad	432                             ; 0x1b0
	.quad	440                             ; 0x1b8
lCPI0_45:
	.quad	416                             ; 0x1a0
	.quad	424                             ; 0x1a8
lCPI0_46:
	.quad	400                             ; 0x190
	.quad	408                             ; 0x198
lCPI0_47:
	.quad	384                             ; 0x180
	.quad	392                             ; 0x188
lCPI0_48:
	.quad	496                             ; 0x1f0
	.quad	504                             ; 0x1f8
lCPI0_49:
	.quad	480                             ; 0x1e0
	.quad	488                             ; 0x1e8
lCPI0_50:
	.quad	464                             ; 0x1d0
	.quad	472                             ; 0x1d8
lCPI0_51:
	.quad	448                             ; 0x1c0
	.quad	456                             ; 0x1c8
lCPI0_52:
	.quad	560                             ; 0x230
	.quad	568                             ; 0x238
lCPI0_53:
	.quad	544                             ; 0x220
	.quad	552                             ; 0x228
lCPI0_54:
	.quad	528                             ; 0x210
	.quad	536                             ; 0x218
lCPI0_55:
	.quad	512                             ; 0x200
	.quad	520                             ; 0x208
lCPI0_56:
	.quad	624                             ; 0x270
	.quad	632                             ; 0x278
lCPI0_57:
	.quad	608                             ; 0x260
	.quad	616                             ; 0x268
lCPI0_58:
	.quad	592                             ; 0x250
	.quad	600                             ; 0x258
lCPI0_59:
	.quad	576                             ; 0x240
	.quad	584                             ; 0x248
lCPI0_60:
	.quad	688                             ; 0x2b0
	.quad	696                             ; 0x2b8
lCPI0_61:
	.quad	672                             ; 0x2a0
	.quad	680                             ; 0x2a8
lCPI0_62:
	.quad	656                             ; 0x290
	.quad	664                             ; 0x298
lCPI0_63:
	.quad	640                             ; 0x280
	.quad	648                             ; 0x288
lCPI0_64:
	.quad	752                             ; 0x2f0
	.quad	760                             ; 0x2f8
lCPI0_65:
	.quad	736                             ; 0x2e0
	.quad	744                             ; 0x2e8
lCPI0_66:
	.quad	720                             ; 0x2d0
	.quad	728                             ; 0x2d8
lCPI0_67:
	.quad	704                             ; 0x2c0
	.quad	712                             ; 0x2c8
lCPI0_68:
	.quad	816                             ; 0x330
	.quad	824                             ; 0x338
lCPI0_69:
	.quad	800                             ; 0x320
	.quad	808                             ; 0x328
lCPI0_70:
	.quad	784                             ; 0x310
	.quad	792                             ; 0x318
lCPI0_71:
	.quad	768                             ; 0x300
	.quad	776                             ; 0x308
lCPI0_72:
	.quad	880                             ; 0x370
	.quad	888                             ; 0x378
lCPI0_73:
	.quad	864                             ; 0x360
	.quad	872                             ; 0x368
lCPI0_74:
	.quad	848                             ; 0x350
	.quad	856                             ; 0x358
lCPI0_75:
	.quad	832                             ; 0x340
	.quad	840                             ; 0x348
lCPI0_76:
	.quad	944                             ; 0x3b0
	.quad	952                             ; 0x3b8
lCPI0_77:
	.quad	928                             ; 0x3a0
	.quad	936                             ; 0x3a8
lCPI0_78:
	.quad	912                             ; 0x390
	.quad	920                             ; 0x398
lCPI0_79:
	.quad	896                             ; 0x380
	.quad	904                             ; 0x388
lCPI0_80:
	.quad	1008                            ; 0x3f0
	.quad	1016                            ; 0x3f8
lCPI0_81:
	.quad	992                             ; 0x3e0
	.quad	1000                            ; 0x3e8
lCPI0_82:
	.quad	976                             ; 0x3d0
	.quad	984                             ; 0x3d8
lCPI0_83:
	.quad	960                             ; 0x3c0
	.quad	968                             ; 0x3c8
lCPI0_84:
	.quad	1072                            ; 0x430
	.quad	1080                            ; 0x438
lCPI0_85:
	.quad	1056                            ; 0x420
	.quad	1064                            ; 0x428
lCPI0_86:
	.quad	1040                            ; 0x410
	.quad	1048                            ; 0x418
lCPI0_87:
	.quad	1024                            ; 0x400
	.quad	1032                            ; 0x408
lCPI0_88:
	.quad	1136                            ; 0x470
	.quad	1144                            ; 0x478
lCPI0_89:
	.quad	1120                            ; 0x460
	.quad	1128                            ; 0x468
lCPI0_90:
	.quad	1104                            ; 0x450
	.quad	1112                            ; 0x458
lCPI0_91:
	.quad	1088                            ; 0x440
	.quad	1096                            ; 0x448
lCPI0_92:
	.quad	1200                            ; 0x4b0
	.quad	1208                            ; 0x4b8
lCPI0_93:
	.quad	1184                            ; 0x4a0
	.quad	1192                            ; 0x4a8
lCPI0_94:
	.quad	1168                            ; 0x490
	.quad	1176                            ; 0x498
lCPI0_95:
	.quad	1152                            ; 0x480
	.quad	1160                            ; 0x488
lCPI0_96:
	.quad	1264                            ; 0x4f0
	.quad	1272                            ; 0x4f8
lCPI0_97:
	.quad	1248                            ; 0x4e0
	.quad	1256                            ; 0x4e8
lCPI0_98:
	.quad	1232                            ; 0x4d0
	.quad	1240                            ; 0x4d8
lCPI0_99:
	.quad	1216                            ; 0x4c0
	.quad	1224                            ; 0x4c8
lCPI0_100:
	.quad	1328                            ; 0x530
	.quad	1336                            ; 0x538
lCPI0_101:
	.quad	1312                            ; 0x520
	.quad	1320                            ; 0x528
lCPI0_102:
	.quad	1296                            ; 0x510
	.quad	1304                            ; 0x518
lCPI0_103:
	.quad	1280                            ; 0x500
	.quad	1288                            ; 0x508
lCPI0_104:
	.quad	1392                            ; 0x570
	.quad	1400                            ; 0x578
lCPI0_105:
	.quad	1376                            ; 0x560
	.quad	1384                            ; 0x568
lCPI0_106:
	.quad	1360                            ; 0x550
	.quad	1368                            ; 0x558
lCPI0_107:
	.quad	1344                            ; 0x540
	.quad	1352                            ; 0x548
lCPI0_108:
	.quad	1456                            ; 0x5b0
	.quad	1464                            ; 0x5b8
lCPI0_109:
	.quad	1440                            ; 0x5a0
	.quad	1448                            ; 0x5a8
lCPI0_110:
	.quad	1424                            ; 0x590
	.quad	1432                            ; 0x598
lCPI0_111:
	.quad	1408                            ; 0x580
	.quad	1416                            ; 0x588
lCPI0_112:
	.quad	1520                            ; 0x5f0
	.quad	1528                            ; 0x5f8
lCPI0_113:
	.quad	1504                            ; 0x5e0
	.quad	1512                            ; 0x5e8
lCPI0_114:
	.quad	1488                            ; 0x5d0
	.quad	1496                            ; 0x5d8
lCPI0_115:
	.quad	1472                            ; 0x5c0
	.quad	1480                            ; 0x5c8
lCPI0_116:
	.quad	1584                            ; 0x630
	.quad	1592                            ; 0x638
lCPI0_117:
	.quad	1568                            ; 0x620
	.quad	1576                            ; 0x628
lCPI0_118:
	.quad	1552                            ; 0x610
	.quad	1560                            ; 0x618
lCPI0_119:
	.quad	1536                            ; 0x600
	.quad	1544                            ; 0x608
lCPI0_120:
	.quad	1648                            ; 0x670
	.quad	1656                            ; 0x678
lCPI0_121:
	.quad	1632                            ; 0x660
	.quad	1640                            ; 0x668
lCPI0_122:
	.quad	1616                            ; 0x650
	.quad	1624                            ; 0x658
lCPI0_123:
	.quad	1600                            ; 0x640
	.quad	1608                            ; 0x648
lCPI0_124:
	.quad	1712                            ; 0x6b0
	.quad	1720                            ; 0x6b8
lCPI0_125:
	.quad	1696                            ; 0x6a0
	.quad	1704                            ; 0x6a8
lCPI0_126:
	.quad	1680                            ; 0x690
	.quad	1688                            ; 0x698
lCPI0_127:
	.quad	1664                            ; 0x680
	.quad	1672                            ; 0x688
lCPI0_128:
	.quad	1776                            ; 0x6f0
	.quad	1784                            ; 0x6f8
lCPI0_129:
	.quad	1760                            ; 0x6e0
	.quad	1768                            ; 0x6e8
lCPI0_130:
	.quad	1744                            ; 0x6d0
	.quad	1752                            ; 0x6d8
lCPI0_131:
	.quad	1728                            ; 0x6c0
	.quad	1736                            ; 0x6c8
lCPI0_132:
	.quad	1840                            ; 0x730
	.quad	1848                            ; 0x738
lCPI0_133:
	.quad	1824                            ; 0x720
	.quad	1832                            ; 0x728
lCPI0_134:
	.quad	1808                            ; 0x710
	.quad	1816                            ; 0x718
lCPI0_135:
	.quad	1792                            ; 0x700
	.quad	1800                            ; 0x708
lCPI0_136:
	.quad	1904                            ; 0x770
	.quad	1912                            ; 0x778
lCPI0_137:
	.quad	1888                            ; 0x760
	.quad	1896                            ; 0x768
lCPI0_138:
	.quad	1872                            ; 0x750
	.quad	1880                            ; 0x758
lCPI0_139:
	.quad	1856                            ; 0x740
	.quad	1864                            ; 0x748
lCPI0_140:
	.quad	1968                            ; 0x7b0
	.quad	1976                            ; 0x7b8
lCPI0_141:
	.quad	1952                            ; 0x7a0
	.quad	1960                            ; 0x7a8
lCPI0_142:
	.quad	1936                            ; 0x790
	.quad	1944                            ; 0x798
lCPI0_143:
	.quad	1920                            ; 0x780
	.quad	1928                            ; 0x788
lCPI0_144:
	.quad	2032                            ; 0x7f0
	.quad	2040                            ; 0x7f8
lCPI0_145:
	.quad	2016                            ; 0x7e0
	.quad	2024                            ; 0x7e8
lCPI0_146:
	.quad	2000                            ; 0x7d0
	.quad	2008                            ; 0x7d8
lCPI0_147:
	.quad	1984                            ; 0x7c0
	.quad	1992                            ; 0x7c8
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_3:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_tile_inclusive_scan:                   ; @tile_inclusive_scan
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	add	x29, sp, #144
	sub	x9, sp, #18, lsl #12            ; =73728
	sub	x9, x9, #864
	and	sp, x9, #0xffffffffffffffc0
	fmov	s2, wzr
	add	x8, sp, #18, lsl #12            ; =73728
	add	x8, x8, #744
	str	wzr, [x8, #84]
	stur	wzr, [x8, #81]
	stur	xzr, [x8, #52]
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #3967
	stur	xzr, [x8, #68]
	stur	xzr, [x8, #60]
	str	wzr, [x8, #76]
	stur	xzr, [x8, #20]
	stur	xzr, [x8, #36]
	stur	xzr, [x8, #28]
	str	wzr, [x8, #44]
	stp	xzr, xzr, [x8]
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #18992]
	str	q0, [sp, #18976]
	str	q0, [sp, #18960]
	str	q0, [sp, #18944]
	str	q0, [sp, #18928]
	str	q0, [sp, #18912]
	str	q0, [sp, #18896]
	str	q0, [sp, #18880]
	str	q0, [sp, #18864]
	str	q0, [sp, #18848]
	str	q0, [sp, #18832]
	str	q0, [sp, #18816]
	str	q0, [sp, #18800]
	str	q0, [sp, #18784]
	str	q0, [sp, #18768]
	str	q0, [sp, #18752]
	str	q0, [sp, #18736]
	str	q0, [sp, #18720]
	str	q0, [sp, #18704]
	str	q0, [sp, #18688]
	str	q0, [sp, #18608]
	str	q0, [sp, #18560]
	str	q0, [sp, #18576]
	str	q0, [sp, #18656]
	str	q0, [sp, #18672]
	str	q0, [sp, #18624]
	str	q0, [sp, #18640]
	str	q0, [sp, #18592]
	str	q0, [sp, #18480]
	str	q0, [sp, #18432]
	str	q0, [sp, #18448]
	str	q0, [sp, #18528]
	str	q0, [sp, #18544]
	str	q0, [sp, #18496]
	str	q0, [sp, #18512]
	str	q0, [sp, #18464]
	str	q0, [sp, #18352]
	str	q0, [sp, #18304]
	str	q0, [sp, #18320]
	str	q0, [sp, #18400]
	str	q0, [sp, #18416]
	str	q0, [sp, #18368]
	str	q0, [sp, #18384]
	str	q0, [sp, #18336]
	strb	wzr, [x9, #2048]
	str	q0, [sp, #18224]
	str	q0, [sp, #18208]
	str	q0, [sp, #18192]
	str	q0, [sp, #18176]
	str	q0, [sp, #18160]
	str	q0, [sp, #18112]
	str	q0, [sp, #18128]
	str	q0, [sp, #18080]
	str	q0, [sp, #18096]
	str	q0, [sp, #18048]
	str	q0, [sp, #18064]
	str	q0, [sp, #18144]
	str	q0, [sp, #17968]
	str	q0, [sp, #17920]
	str	q0, [sp, #17936]
	str	q0, [sp, #18016]
	str	q0, [sp, #18032]
	str	q0, [sp, #17984]
	str	q0, [sp, #18000]
	str	q0, [sp, #17952]
	str	q0, [sp, #17840]
	str	q0, [sp, #17792]
	str	q0, [sp, #17808]
	str	q0, [sp, #17888]
	str	q0, [sp, #17904]
	str	q0, [sp, #17856]
	str	q0, [sp, #17872]
	str	q0, [sp, #17824]
	strb	wzr, [x9, #1536]
	str	q0, [sp, #17712]
	str	q0, [sp, #17696]
	str	q0, [sp, #17680]
	str	q0, [sp, #17664]
	str	q0, [sp, #17648]
	str	q0, [sp, #17600]
	str	q0, [sp, #17616]
	str	q0, [sp, #17568]
	str	q0, [sp, #17584]
	str	q0, [sp, #17536]
	str	q0, [sp, #17552]
	str	q0, [sp, #17632]
	str	q0, [sp, #17456]
	str	q0, [sp, #17408]
	str	q0, [sp, #17424]
	str	q0, [sp, #17504]
	str	q0, [sp, #17520]
	str	q0, [sp, #17472]
	str	q0, [sp, #17488]
	str	q0, [sp, #17440]
	str	q0, [sp, #17328]
	str	q0, [sp, #17280]
	str	q0, [sp, #17296]
	str	q0, [sp, #17376]
	str	q0, [sp, #17392]
	str	q0, [sp, #17344]
	str	q0, [sp, #17360]
	str	q0, [sp, #17312]
	strb	wzr, [x9, #1024]
	str	q0, [sp, #17200]
	str	q0, [sp, #17184]
	str	q0, [sp, #17168]
	str	q0, [sp, #17152]
	str	q0, [sp, #17136]
	str	q0, [sp, #17088]
	str	q0, [sp, #17104]
	str	q0, [sp, #17056]
	str	q0, [sp, #17072]
	str	q0, [sp, #17024]
	str	q0, [sp, #17040]
	str	q0, [sp, #17120]
	str	q0, [sp, #16944]
	str	q0, [sp, #16896]
	str	q0, [sp, #16912]
	str	q0, [sp, #16992]
	str	q0, [sp, #17008]
	str	q0, [sp, #16960]
	str	q0, [sp, #16976]
	str	q0, [sp, #16928]
	str	q0, [sp, #16816]
	str	q0, [sp, #16768]
	str	q0, [sp, #16784]
	str	q0, [sp, #16864]
	str	q0, [sp, #16880]
	str	q0, [sp, #16832]
	str	q0, [sp, #16848]
	str	q0, [sp, #16800]
	strb	wzr, [x9, #512]
	str	q0, [sp, #16688]
	str	q0, [sp, #16672]
	str	q0, [sp, #16656]
	str	q0, [sp, #16640]
	str	q0, [sp, #16624]
	str	q0, [sp, #16576]
	str	q0, [sp, #16592]
	str	q0, [sp, #16544]
	str	q0, [sp, #16560]
	str	q0, [sp, #16512]
	str	q0, [sp, #16528]
	str	q0, [sp, #16608]
	str	q0, [sp, #16432]
	str	q0, [sp, #16384]
	str	q0, [sp, #16400]
	str	q0, [sp, #16480]
	str	q0, [sp, #16496]
	str	q0, [sp, #16448]
	str	q0, [sp, #16464]
	str	q0, [sp, #16416]
	str	q0, [sp, #16304]
	str	q0, [sp, #16256]
	str	q0, [sp, #16272]
	str	q0, [sp, #16352]
	str	q0, [sp, #16368]
	str	q0, [sp, #16320]
	str	q0, [sp, #16336]
	str	q0, [sp, #16288]
	strb	wzr, [x9]
	str	q0, [sp, #16176]
	str	q0, [sp, #16160]
	str	q0, [sp, #16144]
	dup.4s	v1, w2
Lloh0:
	adrp	x10, lCPI0_0@PAGE
Lloh1:
	ldr	q3, [x10, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x10, lCPI0_1@PAGE
Lloh3:
	ldr	q4, [x10, lCPI0_1@PAGEOFF]
	cmhi.4s	v5, v1, v4
	cmhi.4s	v1, v1, v3
	uzp1.8h	v5, v1, v5
	xtn.8b	v1, v5
Lloh4:
	adrp	x10, lCPI0_2@PAGE
Lloh5:
	ldr	q6, [x10, lCPI0_2@PAGEOFF]
	and.16b	v6, v5, v6
	str	q0, [sp, #16128]
	ldr	x10, [x0]
	str	x10, [sp, #136]                 ; 8-byte Folded Spill
	ldr	x11, [x0, #16]
	ldr	w12, [x1]
	addv.8h	h6, v6
	fmov	w13, s6
	and	w13, w13, #0xff
	fmov	s6, w13
	cmeq.8b	v2, v6, v2
	umov.b	w13, v2[0]
	and	w14, w13, #0x1
	fmov	s2, w14
	ubfx	w14, w13, #1, #1
	mov.b	v2[1], w14
	ubfx	w14, w13, #2, #1
	mov.b	v2[2], w14
	ubfx	w14, w13, #3, #1
	mov.b	v2[3], w14
	ubfx	w14, w13, #4, #1
	mov.b	v2[4], w14
	ubfx	w14, w13, #5, #1
	mov.b	v2[5], w14
	ubfx	w14, w13, #6, #1
	ubfx	w15, w13, #7, #1
	ldr	w13, [x1, #36]
	movi.8b	v6, #1
	mov.b	v2[6], w14
	mov.b	v2[7], w15
	eor.8b	v2, v2, v6
	and.8b	v2, v2, v1
	umaxv.8h	h5, v5
	fmov	w14, s5
	shl.8b	v2, v2, #7
	cmlt.8b	v5, v2, #0
Lloh6:
	adrp	x15, lCPI0_3@PAGE
Lloh7:
	ldr	d2, [x15, lCPI0_3@PAGEOFF]
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x8, #80]
	str	wzr, [x8, #48]
	str	wzr, [x8, #16]
	tbnz	w14, #0, LBB0_1
	b	LBB0_1004
LBB0_1:                                 ; %scheduler.dispatch.lr.ph.lr.ph
	str	q0, [sp, #848]                  ; 16-byte Folded Spill
	mov	x16, #0                         ; =0x0
	mov	w17, #0                         ; =0x0
	add	x14, sp, #18, lsl #12           ; =73728
	add	x14, x14, #616
	dup.2d	v0, x14
	add	x14, sp, #17, lsl #12           ; =69632
	add	x14, x14, #616
	dup.2d	v5, x14
	stp	q5, q0, [sp, #144]              ; 32-byte Folded Spill
	add	x14, sp, #16, lsl #12           ; =65536
	add	x14, x14, #2664
	dup.2d	v0, x14
	add	x14, sp, #15, lsl #12           ; =61440
	add	x14, x14, #2664
	dup.2d	v5, x14
	stp	q5, q0, [sp, #384]              ; 32-byte Folded Spill
	add	x14, sp, #14, lsl #12           ; =57344
	add	x14, x14, #2664
	dup.2d	v0, x14
	add	x14, sp, #14, lsl #12           ; =57344
	add	x14, x14, #616
	dup.2d	v5, x14
	stp	q5, q0, [sp, #352]              ; 32-byte Folded Spill
	add	x14, sp, #13, lsl #12           ; =53248
	add	x14, x14, #616
	dup.2d	v0, x14
	add	x14, sp, #12, lsl #12           ; =49152
	add	x14, x14, #616
	dup.2d	v5, x14
	stp	q5, q0, [sp, #320]              ; 32-byte Folded Spill
	add	x14, sp, #11, lsl #12           ; =45056
	add	x14, x14, #2664
	dup.2d	v0, x14
	add	x14, sp, #10, lsl #12           ; =40960
	add	x14, x14, #2664
	dup.2d	v5, x14
	stp	q5, q0, [sp, #288]              ; 32-byte Folded Spill
	add	x14, sp, #9, lsl #12            ; =36864
	add	x14, x14, #2664
	dup.2d	v0, x14
	add	x14, sp, #9, lsl #12            ; =36864
	add	x14, x14, #616
	dup.2d	v5, x14
	stp	q5, q0, [sp, #256]              ; 32-byte Folded Spill
	add	x14, sp, #8, lsl #12            ; =32768
	add	x14, x14, #616
	dup.2d	v0, x14
	add	x14, sp, #7, lsl #12            ; =28672
	add	x14, x14, #616
	dup.2d	v5, x14
	stp	q5, q0, [sp, #224]              ; 32-byte Folded Spill
	add	x14, sp, #6, lsl #12            ; =24576
	add	x14, x14, #2664
	dup.2d	v0, x14
	add	x14, sp, #5, lsl #12            ; =20480
	add	x14, x14, #2664
	dup.2d	v5, x14
	stp	q5, q0, [sp, #192]              ; 32-byte Folded Spill
	add	x14, sp, #4, lsl #12            ; =16384
	add	x14, x14, #2664
	dup.2d	v5, x14
	str	q5, [sp, #176]                  ; 16-byte Folded Spill
	add	w12, w13, w12, lsl #5
	dup.4s	v5, w12
	add.4s	v4, v5, v4
	add.4s	v3, v5, v3
	ushll2.2d	v0, v4, #2
	ushll2.2d	v5, v3, #2
	stp	q5, q0, [sp, #96]               ; 32-byte Folded Spill
	ushll.2d	v4, v4, #2
	ushll.2d	v3, v3, #2
	stp	q3, q4, [sp, #64]               ; 32-byte Folded Spill
	movi	d0, #0000000000000000
	str	q0, [sp, #768]                  ; 16-byte Folded Spill
	movi.2d	v15, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #1472]                 ; 16-byte Folded Spill
	str	q0, [sp, #1456]                 ; 16-byte Folded Spill
	stp	q0, q0, [sp, #448]              ; 32-byte Folded Spill
	stp	q0, q0, [sp, #416]              ; 32-byte Folded Spill
	mov	w0, #1                          ; =0x1
	add	x12, sp, #18, lsl #12           ; =73728
	add	x12, x12, #824
	add	x13, sp, #18, lsl #12           ; =73728
	add	x13, x13, #792
	add	x14, sp, #18, lsl #12           ; =73728
	add	x14, x14, #760
Lloh8:
	adrp	x15, LJTI0_0@PAGE
Lloh9:
	add	x15, x15, LJTI0_0@PAGEOFF
	stp	q0, q0, [sp, #736]              ; 32-byte Folded Spill
	stp	q0, q0, [sp, #704]              ; 32-byte Folded Spill
	stp	q0, q0, [sp, #608]              ; 32-byte Folded Spill
	str	q0, [sp, #1200]                 ; 16-byte Folded Spill
	str	q0, [sp, #1184]                 ; 16-byte Folded Spill
	str	q0, [sp, #1168]                 ; 16-byte Folded Spill
	movi.2d	v3, #0000000000000000
	str	q3, [sp, #1440]                 ; 16-byte Folded Spill
	str	q3, [sp, #1424]                 ; 16-byte Folded Spill
	stp	q3, q3, [sp, #944]              ; 32-byte Folded Spill
	str	q3, [sp, #1408]                 ; 16-byte Folded Spill
	stp	q3, q3, [sp, #576]              ; 32-byte Folded Spill
	str	q3, [sp, #1152]                 ; 16-byte Folded Spill
	str	q3, [sp, #1136]                 ; 16-byte Folded Spill
	stp	q3, q3, [sp, #896]              ; 32-byte Folded Spill
	str	q3, [sp, #1120]                 ; 16-byte Folded Spill
	str	q3, [sp, #1392]                 ; 16-byte Folded Spill
	str	q3, [sp, #1376]                 ; 16-byte Folded Spill
	str	q3, [sp, #1360]                 ; 16-byte Folded Spill
	stp	q3, q3, [sp, #544]              ; 32-byte Folded Spill
	str	q3, [sp, #1104]                 ; 16-byte Folded Spill
	str	q3, [sp, #1088]                 ; 16-byte Folded Spill
	str	q3, [sp, #1072]                 ; 16-byte Folded Spill
	str	q3, [sp, #1344]                 ; 16-byte Folded Spill
	str	q3, [sp, #1328]                 ; 16-byte Folded Spill
	str	q3, [sp, #928]                  ; 16-byte Folded Spill
	str	q3, [sp, #1312]                 ; 16-byte Folded Spill
	stp	q3, q3, [sp, #512]              ; 32-byte Folded Spill
	stp	q3, q3, [sp, #816]              ; 32-byte Folded Spill
	str	q3, [sp, #1056]                 ; 16-byte Folded Spill
	str	q3, [sp, #1040]                 ; 16-byte Folded Spill
	movi.2d	v23, #0000000000000000
	str	q3, [sp, #1296]                 ; 16-byte Folded Spill
	str	q3, [sp, #1280]                 ; 16-byte Folded Spill
	movi.2d	v24, #0000000000000000
	stp	q3, q3, [sp, #480]              ; 32-byte Folded Spill
	movi.2d	v4, #0000000000000000
	str	q4, [sp, #1024]                 ; 16-byte Folded Spill
	movi.2d	v25, #0000000000000000
	stp	q3, q4, [sp, #784]              ; 32-byte Folded Spill
	movi.2d	v5, #0000000000000000
	stp	q5, q5, [sp, #976]              ; 32-byte Folded Spill
	stp	q5, q5, [sp, #640]              ; 32-byte Folded Spill
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v9, #0000000000000000
	movi.2d	v8, #0000000000000000
LBB0_2:                                 ; %scheduler.dispatch.lr.ph
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_6 Depth 2
                                        ;       Child Loop BB0_7 Depth 3
                                        ;         Child Loop BB0_185 Depth 4
                                        ;         Child Loop BB0_257 Depth 4
                                        ;         Child Loop BB0_330 Depth 4
                                        ;         Child Loop BB0_401 Depth 4
                                        ;         Child Loop BB0_475 Depth 4
                                        ;         Child Loop BB0_547 Depth 4
                                        ;         Child Loop BB0_620 Depth 4
                                        ;         Child Loop BB0_691 Depth 4
                                        ;         Child Loop BB0_765 Depth 4
                                        ;         Child Loop BB0_837 Depth 4
                                        ;         Child Loop BB0_926 Depth 4
                                        ;         Child Loop BB0_978 Depth 4
                                        ;         Child Loop BB0_93 Depth 4
                                        ;         Child Loop BB0_69 Depth 4
                                        ;         Child Loop BB0_21 Depth 4
                                        ;         Child Loop BB0_38 Depth 4
                                        ;         Child Loop BB0_53 Depth 4
                                        ;       Child Loop BB0_987 Depth 3
	stp	q27, q26, [sp, #672]            ; 32-byte Folded Spill
	str	q4, [sp, #1008]                 ; 16-byte Folded Spill
	str	q25, [sp, #1216]                ; 16-byte Folded Spill
	str	q3, [sp, #1232]                 ; 16-byte Folded Spill
	str	q24, [sp, #1488]                ; 16-byte Folded Spill
	str	q23, [sp, #1248]                ; 16-byte Folded Spill
	str	q0, [sp, #1264]                 ; 16-byte Folded Spill
	stp	q20, q19, [sp, #864]            ; 32-byte Folded Spill
	mov.16b	v20, v22
	b	LBB0_6
LBB0_3:                                 ; %schedule.49.convergence.cascade.exit1011_crit_edge
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
LBB0_4:                                 ; %convergence.cascade.exit1011
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w3, #0xff
	b.ne	LBB0_990
LBB0_5:                                 ; %scheduler.loop.backedge
                                        ;   in Loop: Header=BB0_6 Depth=2
	cbz	x0, LBB0_1004
LBB0_6:                                 ; %scheduler.dispatch
                                        ;   Parent Loop BB0_2 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_7 Depth 3
                                        ;         Child Loop BB0_185 Depth 4
                                        ;         Child Loop BB0_257 Depth 4
                                        ;         Child Loop BB0_330 Depth 4
                                        ;         Child Loop BB0_401 Depth 4
                                        ;         Child Loop BB0_475 Depth 4
                                        ;         Child Loop BB0_547 Depth 4
                                        ;         Child Loop BB0_620 Depth 4
                                        ;         Child Loop BB0_691 Depth 4
                                        ;         Child Loop BB0_765 Depth 4
                                        ;         Child Loop BB0_837 Depth 4
                                        ;         Child Loop BB0_926 Depth 4
                                        ;         Child Loop BB0_978 Depth 4
                                        ;         Child Loop BB0_93 Depth 4
                                        ;         Child Loop BB0_69 Depth 4
                                        ;         Child Loop BB0_21 Depth 4
                                        ;         Child Loop BB0_38 Depth 4
                                        ;         Child Loop BB0_53 Depth 4
                                        ;       Child Loop BB0_987 Depth 3
	sub	w0, w0, #1
	ldrb	w1, [x12, w0, sxtw]
	and	w2, w1, #0x1
	fmov	s10, w2
	ubfx	w2, w1, #1, #1
	mov.b	v10[1], w2
	ubfx	w2, w1, #2, #1
	mov.b	v10[2], w2
	ubfx	w2, w1, #3, #1
	mov.b	v10[3], w2
	ubfx	w2, w1, #4, #1
	mov.b	v10[4], w2
	ubfx	w2, w1, #5, #1
	mov.b	v10[5], w2
	ubfx	w2, w1, #6, #1
	mov.b	v10[6], w2
	lsr	w1, w1, #7
	mov.b	v10[7], w1
	ldr	w3, [x13, w0, sxtw #2]
	ldr	w1, [x14, w0, sxtw #2]
	cmp	w3, #49
	b.hi	LBB0_1006
LBB0_7:                                 ; %scheduler.dispatch.route
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB0_185 Depth 4
                                        ;         Child Loop BB0_257 Depth 4
                                        ;         Child Loop BB0_330 Depth 4
                                        ;         Child Loop BB0_401 Depth 4
                                        ;         Child Loop BB0_475 Depth 4
                                        ;         Child Loop BB0_547 Depth 4
                                        ;         Child Loop BB0_620 Depth 4
                                        ;         Child Loop BB0_691 Depth 4
                                        ;         Child Loop BB0_765 Depth 4
                                        ;         Child Loop BB0_837 Depth 4
                                        ;         Child Loop BB0_926 Depth 4
                                        ;         Child Loop BB0_978 Depth 4
                                        ;         Child Loop BB0_93 Depth 4
                                        ;         Child Loop BB0_69 Depth 4
                                        ;         Child Loop BB0_21 Depth 4
                                        ;         Child Loop BB0_38 Depth 4
                                        ;         Child Loop BB0_53 Depth 4
	mov	w3, w3
	adr	x2, LBB0_8
	ldrh	w4, [x15, x3, lsl #1]
	add	x2, x2, x4, lsl #2
	br	x2
LBB0_8:                                 ; %schedule.0
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w2, s3
	ldr	q3, [sp, #18992]
	ldr	q4, [sp, #18944]
	ldr	q16, [sp, #18960]
	ldr	q17, [sp, #18976]
	mov	b18, v10[4]
	mov.b	v18[4], v10[5]
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	mov	b19, v10[2]
	mov.b	v19[4], v10[3]
	ldp	q0, q5, [sp, #80]               ; 32-byte Folded Reload
	bit.16b	v17, v0, v18
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	bit.16b	v16, v5, v19
	mov	b26, v10[0]
	mov.b	v26[4], v10[1]
	ushll.2d	v26, v26, #0
	shl.2d	v26, v26, #63
	cmlt.2d	v26, v26, #0
	ldr	q5, [sp, #64]                   ; 16-byte Folded Reload
	bit.16b	v4, v5, v26
	mov	b27, v10[6]
	mov.b	v27[4], v10[7]
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	ldr	q5, [sp, #112]                  ; 16-byte Folded Reload
	bit.16b	v3, v5, v27
	zip2.8b	v30, v10, v0
	ushll.4s	v30, v30, #0
	shl.4s	v30, v30, #31
	zip1.8b	v31, v10, v0
	ushll.4s	v31, v31, #0
	shl.4s	v31, v31, #31
	str	q3, [sp, #18992]
	str	q4, [sp, #18944]
	str	q16, [sp, #18960]
	str	q17, [sp, #18976]
	ldp	q4, q0, [sp, #672]              ; 32-byte Folded Reload
	bic.16b	v3, v4, v27
	bic.16b	v0, v0, v18
	stp	q3, q0, [sp, #672]              ; 32-byte Folded Spill
	ldp	q4, q0, [sp, #640]              ; 32-byte Folded Reload
	bic.16b	v3, v4, v19
	bic.16b	v0, v0, v26
	stp	q3, q0, [sp, #640]              ; 32-byte Folded Spill
	ldr	q3, [sp, #18928]
	ldr	q4, [sp, #18912]
	cmge.4s	v16, v31, #0
	and.16b	v4, v16, v4
	cmge.4s	v17, v30, #0
	and.16b	v3, v17, v3
	str	q3, [sp, #18928]
	str	q4, [sp, #18912]
	ldr	q3, [sp, #18896]
	ldr	q4, [sp, #18880]
	and.16b	v4, v16, v4
	and.16b	v3, v17, v3
	str	q3, [sp, #18896]
	str	q4, [sp, #18880]
	ldr	q3, [sp, #18864]
	ldr	q4, [sp, #18848]
	and.16b	v4, v16, v4
	and.16b	v3, v17, v3
	str	q3, [sp, #18864]
	str	q4, [sp, #18848]
	ldr	q3, [sp, #18832]
	ldr	q4, [sp, #18816]
	and.16b	v4, v16, v4
	and.16b	v3, v17, v3
	str	q3, [sp, #18832]
	str	q4, [sp, #18816]
	movi	d0, #0000000000000000
	str	q0, [sp, #768]                  ; 16-byte Folded Spill
	tbnz	w2, #0, LBB0_132
	b	LBB0_5
LBB0_9:                                 ; %schedule.24
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	ldr	q5, [sp, #17536]
	ldr	q31, [sp, #17552]
	ldr	q4, [sp, #17568]
	ldr	q3, [sp, #17584]
	ldr	q18, [sp, #17648]
	ldr	q26, [sp, #17632]
	ldr	q11, [sp, #17616]
	ldr	q16, [sp, #17600]
	ldr	q17, [sp, #17152]
	ldr	q12, [sp, #17168]
	ldr	q27, [sp, #17184]
	ldr	q19, [sp, #17200]
	shl.2d	v17, v17, #5
	add.2d	v5, v5, v16
	add.2d	v30, v5, v17
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbnz	w2, #0, LBB0_97
; %bb.10:                               ; %else4426
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #1, LBB0_98
LBB0_11:                                ; %else4432
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.2d	v5, v12, #5
	add.2d	v24, v31, v11
	add.2d	v30, v24, v5
	tbnz	w2, #2, LBB0_99
LBB0_12:                                ; %else4438
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #3, LBB0_100
LBB0_13:                                ; %else4444
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.2d	v5, v27, #5
	add.2d	v4, v4, v26
	add.2d	v4, v4, v5
	tbnz	w2, #4, LBB0_101
LBB0_14:                                ; %else4450
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #5, LBB0_102
LBB0_15:                                ; %else4456
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.2d	v4, v19, #5
	add.2d	v3, v3, v18
	add.2d	v3, v3, v4
	tbnz	w2, #6, LBB0_103
LBB0_16:                                ; %else4462
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w2, #7, LBB0_18
LBB0_17:                                ; %cond.load4464
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v3[1]
	ld1.s	{ v17 }[3], [x3]
LBB0_18:                                ; %else4468
                                        ;   in Loop: Header=BB0_7 Depth=3
	zip2.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q0, [sp, #544]                  ; 16-byte Folded Reload
	bit.16b	v0, v17, v3
	str	q0, [sp, #544]                  ; 16-byte Folded Spill
	zip1.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q0, [sp, #560]                  ; 16-byte Folded Reload
	bit.16b	v0, v16, v3
	str	q0, [sp, #560]                  ; 16-byte Folded Spill
	tst	w2, #0xff
	b.eq	LBB0_5
LBB0_19:                                ; %schedule.25
                                        ;   in Loop: Header=BB0_7 Depth=3
	cbz	w1, LBB0_517
LBB0_20:                                ; %convergence.cascade559.preheader
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
LBB0_21:                                ; %convergence.cascade559
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_7 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w10, s4
	umaxv.8b	b3, v3
	fmov	w6, s3
	sub	w3, w1, #1
	tst	w10, #0xff
	csel	w4, w3, wzr, ne
	mov	w10, #1                         ; =0x1
	lsl	w5, w10, w4
	and	w10, w5, w17
	tst	w10, #0xff
	cset	w10, ne
	str	q9, [sp, #3264]
	str	q8, [sp, #3280]
	ubfiz	x3, x4, #2, #3
	add	x7, sp, #3264
	ldr	w7, [x7, x3]
	cmp	w7, #9
	cset	w7, eq
	and	w19, w10, w6
	add	x6, sp, #18, lsl #12            ; =73728
	add	x6, x6, #752
	ldrb	w10, [x6, w4, sxtw]
	and	w20, w10, #0x1
	fmov	s3, w20
	ubfx	w20, w10, #1, #1
	mov.b	v3[1], w20
	ubfx	w20, w10, #2, #1
	mov.b	v3[2], w20
	ubfx	w20, w10, #3, #1
	mov.b	v3[3], w20
	ubfx	w20, w10, #4, #1
	mov.b	v3[4], w20
	ubfx	w20, w10, #5, #1
	mov.b	v3[5], w20
	ubfx	w20, w10, #6, #1
	mov.b	v3[6], w20
	add	x20, sp, #18, lsl #12           ; =73728
	add	x20, x20, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x20, w4, sxtw]
	and	w21, w10, #0x1
	fmov	s4, w21
	ubfx	w21, w10, #1, #1
	mov.b	v4[1], w21
	ubfx	w21, w10, #2, #1
	mov.b	v4[2], w21
	ubfx	w21, w10, #3, #1
	mov.b	v4[3], w21
	ubfx	w21, w10, #4, #1
	mov.b	v4[4], w21
	ubfx	w21, w10, #5, #1
	mov.b	v4[5], w21
	ubfx	w21, w10, #6, #1
	mov.b	v4[6], w21
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	orr.8b	v5, v10, v4
	and.8b	v16, v1, v3
	eor.8b	v16, v16, v5
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	umaxv.8b	b16, v16
	fmov	w10, s16
	ands	w7, w19, w7
	csetm	w19, ne
	bics	w10, w7, w10
	csetm	w21, ne
	dup.8b	v16, w21
	bic.8b	v17, v5, v16
	dup.8b	v18, w19
	bit.8b	v4, v17, v18
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x20, w4, sxtw]
	bic.8b	v3, v3, v16
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x6, w4, sxtw]
	mov	w4, #-1                         ; =0xffffffff
	csinv	w4, w4, w5, eq
	and	w17, w4, w17
	dup.8b	v3, w7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v4, w10
	and.8b	v4, v4, v5
	str	q7, [sp, #3232]
	str	q6, [sp, #3248]
	add	x10, sp, #3232
	ldr	w10, [x10, x3]
	csel	w1, w10, w1, ne
	bit.8b	v10, v4, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	cmp	w7, #1
	b.ne	LBB0_518
; %bb.22:                               ; %convergence.cascade559
                                        ;   in Loop: Header=BB0_21 Depth=4
	cmp	w1, #0
	ccmp	w2, #6, #2, ne
	b.hi	LBB0_518
; %bb.23:                               ; %convergence.cascade559
                                        ;   in Loop: Header=BB0_21 Depth=4
	add	w2, w2, #1
	tst	w3, #0xff
	b.ne	LBB0_21
	b	LBB0_518
LBB0_24:                                ; %scheduler.dispatch.route.schedule.12_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w2, s3
	eor	w2, w2, #0x1
	b	LBB0_278
LBB0_25:                                ; %scheduler.dispatch.route.schedule.31_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w2, s3
	eor	w2, w2, #0x1
	b	LBB0_635
LBB0_26:                                ; %schedule.16
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	ldr	q5, [sp, #18048]
	ldr	q31, [sp, #18064]
	ldr	q4, [sp, #18080]
	ldr	q3, [sp, #18096]
	ldr	q18, [sp, #18160]
	ldr	q26, [sp, #18144]
	ldr	q11, [sp, #18128]
	ldr	q16, [sp, #18112]
	ldr	q17, [sp, #17664]
	ldr	q12, [sp, #17680]
	ldr	q27, [sp, #17696]
	ldr	q19, [sp, #17712]
	shl.2d	v17, v17, #5
	add.2d	v5, v5, v16
	add.2d	v30, v5, v17
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbnz	w2, #0, LBB0_104
; %bb.27:                               ; %else4197
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #1, LBB0_105
LBB0_28:                                ; %else4203
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.2d	v5, v12, #5
	add.2d	v24, v31, v11
	add.2d	v30, v24, v5
	tbnz	w2, #2, LBB0_106
LBB0_29:                                ; %else4209
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #3, LBB0_107
LBB0_30:                                ; %else4215
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.2d	v5, v27, #5
	add.2d	v4, v4, v26
	add.2d	v4, v4, v5
	tbnz	w2, #4, LBB0_108
LBB0_31:                                ; %else4221
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #5, LBB0_109
LBB0_32:                                ; %else4227
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.2d	v4, v19, #5
	add.2d	v3, v3, v18
	add.2d	v3, v3, v4
	tbnz	w2, #6, LBB0_110
LBB0_33:                                ; %else4233
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w2, #7, LBB0_35
LBB0_34:                                ; %cond.load4235
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v3[1]
	ld1.s	{ v17 }[3], [x3]
LBB0_35:                                ; %else4239
                                        ;   in Loop: Header=BB0_7 Depth=3
	zip2.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q0, [sp, #512]                  ; 16-byte Folded Reload
	bit.16b	v0, v17, v3
	str	q0, [sp, #512]                  ; 16-byte Folded Spill
	zip1.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q0, [sp, #528]                  ; 16-byte Folded Reload
	bit.16b	v0, v16, v3
	str	q0, [sp, #528]                  ; 16-byte Folded Spill
	tst	w2, #0xff
	b.eq	LBB0_5
LBB0_36:                                ; %schedule.17
                                        ;   in Loop: Header=BB0_7 Depth=3
	cbz	w1, LBB0_372
LBB0_37:                                ; %convergence.cascade395.preheader
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
LBB0_38:                                ; %convergence.cascade395
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_7 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w10, s4
	umaxv.8b	b3, v3
	fmov	w6, s3
	sub	w3, w1, #1
	tst	w10, #0xff
	csel	w4, w3, wzr, ne
	mov	w10, #1                         ; =0x1
	lsl	w5, w10, w4
	and	w10, w5, w17
	tst	w10, #0xff
	cset	w10, ne
	str	q9, [sp, #2720]
	str	q8, [sp, #2736]
	ubfiz	x3, x4, #2, #3
	add	x7, sp, #2720
	ldr	w7, [x7, x3]
	cmp	w7, #6
	cset	w7, eq
	and	w19, w10, w6
	add	x6, sp, #18, lsl #12            ; =73728
	add	x6, x6, #752
	ldrb	w10, [x6, w4, sxtw]
	and	w20, w10, #0x1
	fmov	s3, w20
	ubfx	w20, w10, #1, #1
	mov.b	v3[1], w20
	ubfx	w20, w10, #2, #1
	mov.b	v3[2], w20
	ubfx	w20, w10, #3, #1
	mov.b	v3[3], w20
	ubfx	w20, w10, #4, #1
	mov.b	v3[4], w20
	ubfx	w20, w10, #5, #1
	mov.b	v3[5], w20
	ubfx	w20, w10, #6, #1
	mov.b	v3[6], w20
	add	x20, sp, #18, lsl #12           ; =73728
	add	x20, x20, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x20, w4, sxtw]
	and	w21, w10, #0x1
	fmov	s4, w21
	ubfx	w21, w10, #1, #1
	mov.b	v4[1], w21
	ubfx	w21, w10, #2, #1
	mov.b	v4[2], w21
	ubfx	w21, w10, #3, #1
	mov.b	v4[3], w21
	ubfx	w21, w10, #4, #1
	mov.b	v4[4], w21
	ubfx	w21, w10, #5, #1
	mov.b	v4[5], w21
	ubfx	w21, w10, #6, #1
	mov.b	v4[6], w21
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	orr.8b	v5, v10, v4
	and.8b	v16, v1, v3
	eor.8b	v16, v16, v5
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	umaxv.8b	b16, v16
	fmov	w10, s16
	ands	w7, w19, w7
	csetm	w19, ne
	bics	w10, w7, w10
	csetm	w21, ne
	dup.8b	v16, w21
	bic.8b	v17, v5, v16
	dup.8b	v18, w19
	bit.8b	v4, v17, v18
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x20, w4, sxtw]
	bic.8b	v3, v3, v16
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x6, w4, sxtw]
	mov	w4, #-1                         ; =0xffffffff
	csinv	w4, w4, w5, eq
	and	w17, w4, w17
	dup.8b	v3, w7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v4, w10
	and.8b	v4, v4, v5
	str	q7, [sp, #2688]
	str	q6, [sp, #2704]
	add	x10, sp, #2688
	ldr	w10, [x10, x3]
	csel	w1, w10, w1, ne
	bit.8b	v10, v4, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	cmp	w7, #1
	b.ne	LBB0_373
; %bb.39:                               ; %convergence.cascade395
                                        ;   in Loop: Header=BB0_38 Depth=4
	cmp	w1, #0
	ccmp	w2, #6, #2, ne
	b.hi	LBB0_373
; %bb.40:                               ; %convergence.cascade395
                                        ;   in Loop: Header=BB0_38 Depth=4
	add	w2, w2, #1
	tst	w3, #0xff
	b.ne	LBB0_38
	b	LBB0_373
LBB0_41:                                ; %schedule.8
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	ldr	q5, [sp, #18560]
	ldr	q31, [sp, #18576]
	ldr	q4, [sp, #18592]
	ldr	q3, [sp, #18608]
	ldr	q18, [sp, #18672]
	ldr	q26, [sp, #18656]
	ldr	q11, [sp, #18640]
	ldr	q16, [sp, #18624]
	ldr	q17, [sp, #18176]
	ldr	q12, [sp, #18192]
	ldr	q27, [sp, #18208]
	ldr	q19, [sp, #18224]
	shl.2d	v17, v17, #5
	add.2d	v5, v5, v16
	add.2d	v30, v5, v17
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbnz	w2, #0, LBB0_111
; %bb.42:                               ; %else3968
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #1, LBB0_112
LBB0_43:                                ; %else3974
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.2d	v5, v12, #5
	add.2d	v24, v31, v11
	add.2d	v30, v24, v5
	tbnz	w2, #2, LBB0_113
LBB0_44:                                ; %else3980
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #3, LBB0_114
LBB0_45:                                ; %else3986
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.2d	v5, v27, #5
	add.2d	v4, v4, v26
	add.2d	v4, v4, v5
	tbnz	w2, #4, LBB0_115
LBB0_46:                                ; %else3992
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #5, LBB0_116
LBB0_47:                                ; %else3998
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.2d	v4, v19, #5
	add.2d	v3, v3, v18
	add.2d	v3, v3, v4
	tbnz	w2, #6, LBB0_117
LBB0_48:                                ; %else4004
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w2, #7, LBB0_50
LBB0_49:                                ; %cond.load4006
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v3[1]
	ld1.s	{ v17 }[3], [x3]
LBB0_50:                                ; %else4010
                                        ;   in Loop: Header=BB0_7 Depth=3
	zip2.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q0, [sp, #480]                  ; 16-byte Folded Reload
	bit.16b	v0, v17, v3
	str	q0, [sp, #480]                  ; 16-byte Folded Spill
	zip1.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q0, [sp, #496]                  ; 16-byte Folded Reload
	bit.16b	v0, v16, v3
	str	q0, [sp, #496]                  ; 16-byte Folded Spill
	tst	w2, #0xff
	b.eq	LBB0_5
LBB0_51:                                ; %schedule.9
                                        ;   in Loop: Header=BB0_7 Depth=3
	cbz	w1, LBB0_227
LBB0_52:                                ; %convergence.cascade231.preheader
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
LBB0_53:                                ; %convergence.cascade231
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_7 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w10, s4
	umaxv.8b	b3, v3
	fmov	w6, s3
	sub	w3, w1, #1
	tst	w10, #0xff
	csel	w4, w3, wzr, ne
	mov	w10, #1                         ; =0x1
	lsl	w5, w10, w4
	and	w10, w5, w17
	tst	w10, #0xff
	cset	w10, ne
	str	q9, [sp, #2176]
	str	q8, [sp, #2192]
	ubfiz	x3, x4, #2, #3
	add	x7, sp, #2176
	ldr	w7, [x7, x3]
	cmp	w7, #3
	cset	w7, eq
	and	w19, w10, w6
	add	x6, sp, #18, lsl #12            ; =73728
	add	x6, x6, #752
	ldrb	w10, [x6, w4, sxtw]
	and	w20, w10, #0x1
	fmov	s3, w20
	ubfx	w20, w10, #1, #1
	mov.b	v3[1], w20
	ubfx	w20, w10, #2, #1
	mov.b	v3[2], w20
	ubfx	w20, w10, #3, #1
	mov.b	v3[3], w20
	ubfx	w20, w10, #4, #1
	mov.b	v3[4], w20
	ubfx	w20, w10, #5, #1
	mov.b	v3[5], w20
	ubfx	w20, w10, #6, #1
	mov.b	v3[6], w20
	add	x20, sp, #18, lsl #12           ; =73728
	add	x20, x20, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x20, w4, sxtw]
	and	w21, w10, #0x1
	fmov	s4, w21
	ubfx	w21, w10, #1, #1
	mov.b	v4[1], w21
	ubfx	w21, w10, #2, #1
	mov.b	v4[2], w21
	ubfx	w21, w10, #3, #1
	mov.b	v4[3], w21
	ubfx	w21, w10, #4, #1
	mov.b	v4[4], w21
	ubfx	w21, w10, #5, #1
	mov.b	v4[5], w21
	ubfx	w21, w10, #6, #1
	mov.b	v4[6], w21
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	orr.8b	v5, v10, v4
	and.8b	v16, v1, v3
	eor.8b	v16, v16, v5
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	umaxv.8b	b16, v16
	fmov	w10, s16
	ands	w7, w19, w7
	csetm	w19, ne
	bics	w10, w7, w10
	csetm	w21, ne
	dup.8b	v16, w21
	bic.8b	v17, v5, v16
	dup.8b	v18, w19
	bit.8b	v4, v17, v18
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x20, w4, sxtw]
	bic.8b	v3, v3, v16
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x6, w4, sxtw]
	mov	w4, #-1                         ; =0xffffffff
	csinv	w4, w4, w5, eq
	and	w17, w4, w17
	dup.8b	v3, w7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v4, w10
	and.8b	v4, v4, v5
	str	q7, [sp, #2144]
	str	q6, [sp, #2160]
	add	x10, sp, #2144
	ldr	w10, [x10, x3]
	csel	w1, w10, w1, ne
	bit.8b	v10, v4, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	cmp	w7, #1
	b.ne	LBB0_228
; %bb.54:                               ; %convergence.cascade231
                                        ;   in Loop: Header=BB0_53 Depth=4
	cmp	w1, #0
	ccmp	w2, #6, #2, ne
	b.hi	LBB0_228
; %bb.55:                               ; %convergence.cascade231
                                        ;   in Loop: Header=BB0_53 Depth=4
	add	w2, w2, #1
	tst	w3, #0xff
	b.ne	LBB0_53
	b	LBB0_228
LBB0_56:                                ; %scheduler.dispatch.route.schedule.47_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w2, s3
	eor	w2, w2, #0x1
	b	LBB0_942
LBB0_57:                                ; %schedule.32
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	ldr	q5, [sp, #17024]
	ldr	q31, [sp, #17040]
	ldr	q4, [sp, #17056]
	ldr	q3, [sp, #17072]
	ldr	q18, [sp, #17136]
	ldr	q26, [sp, #17120]
	ldr	q11, [sp, #17104]
	ldr	q16, [sp, #17088]
	ldr	q17, [sp, #16640]
	ldr	q12, [sp, #16656]
	ldr	q27, [sp, #16672]
	ldr	q19, [sp, #16688]
	shl.2d	v17, v17, #5
	add.2d	v5, v5, v16
	add.2d	v30, v5, v17
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbnz	w2, #0, LBB0_118
; %bb.58:                               ; %else4655
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #1, LBB0_119
LBB0_59:                                ; %else4661
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.2d	v5, v12, #5
	add.2d	v24, v31, v11
	add.2d	v30, v24, v5
	tbnz	w2, #2, LBB0_120
LBB0_60:                                ; %else4667
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #3, LBB0_121
LBB0_61:                                ; %else4673
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.2d	v5, v27, #5
	add.2d	v4, v4, v26
	add.2d	v4, v4, v5
	tbnz	w2, #4, LBB0_122
LBB0_62:                                ; %else4679
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #5, LBB0_123
LBB0_63:                                ; %else4685
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.2d	v4, v19, #5
	add.2d	v3, v3, v18
	add.2d	v3, v3, v4
	tbnz	w2, #6, LBB0_124
LBB0_64:                                ; %else4691
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w2, #7, LBB0_66
LBB0_65:                                ; %cond.load4693
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v3[1]
	ld1.s	{ v17 }[3], [x3]
LBB0_66:                                ; %else4697
                                        ;   in Loop: Header=BB0_7 Depth=3
	zip2.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q0, [sp, #576]                  ; 16-byte Folded Reload
	bit.16b	v0, v17, v3
	str	q0, [sp, #576]                  ; 16-byte Folded Spill
	zip1.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q0, [sp, #592]                  ; 16-byte Folded Reload
	bit.16b	v0, v16, v3
	str	q0, [sp, #592]                  ; 16-byte Folded Spill
	tst	w2, #0xff
	b.eq	LBB0_5
LBB0_67:                                ; %schedule.33
                                        ;   in Loop: Header=BB0_7 Depth=3
	cbz	w1, LBB0_662
LBB0_68:                                ; %convergence.cascade723.preheader
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
LBB0_69:                                ; %convergence.cascade723
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_7 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w10, s4
	umaxv.8b	b3, v3
	fmov	w6, s3
	sub	w3, w1, #1
	tst	w10, #0xff
	csel	w4, w3, wzr, ne
	mov	w10, #1                         ; =0x1
	lsl	w5, w10, w4
	and	w10, w5, w17
	tst	w10, #0xff
	cset	w10, ne
	str	q9, [sp, #3808]
	str	q8, [sp, #3824]
	ubfiz	x3, x4, #2, #3
	add	x7, sp, #3808
	ldr	w7, [x7, x3]
	cmp	w7, #12
	cset	w7, eq
	and	w19, w10, w6
	add	x6, sp, #18, lsl #12            ; =73728
	add	x6, x6, #752
	ldrb	w10, [x6, w4, sxtw]
	and	w20, w10, #0x1
	fmov	s3, w20
	ubfx	w20, w10, #1, #1
	mov.b	v3[1], w20
	ubfx	w20, w10, #2, #1
	mov.b	v3[2], w20
	ubfx	w20, w10, #3, #1
	mov.b	v3[3], w20
	ubfx	w20, w10, #4, #1
	mov.b	v3[4], w20
	ubfx	w20, w10, #5, #1
	mov.b	v3[5], w20
	ubfx	w20, w10, #6, #1
	mov.b	v3[6], w20
	add	x20, sp, #18, lsl #12           ; =73728
	add	x20, x20, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x20, w4, sxtw]
	and	w21, w10, #0x1
	fmov	s4, w21
	ubfx	w21, w10, #1, #1
	mov.b	v4[1], w21
	ubfx	w21, w10, #2, #1
	mov.b	v4[2], w21
	ubfx	w21, w10, #3, #1
	mov.b	v4[3], w21
	ubfx	w21, w10, #4, #1
	mov.b	v4[4], w21
	ubfx	w21, w10, #5, #1
	mov.b	v4[5], w21
	ubfx	w21, w10, #6, #1
	mov.b	v4[6], w21
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	orr.8b	v5, v10, v4
	and.8b	v16, v1, v3
	eor.8b	v16, v16, v5
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	umaxv.8b	b16, v16
	fmov	w10, s16
	ands	w7, w19, w7
	csetm	w19, ne
	bics	w10, w7, w10
	csetm	w21, ne
	dup.8b	v16, w21
	bic.8b	v17, v5, v16
	dup.8b	v18, w19
	bit.8b	v4, v17, v18
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x20, w4, sxtw]
	bic.8b	v3, v3, v16
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x6, w4, sxtw]
	mov	w4, #-1                         ; =0xffffffff
	csinv	w4, w4, w5, eq
	and	w17, w4, w17
	dup.8b	v3, w7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v4, w10
	and.8b	v4, v4, v5
	str	q7, [sp, #3776]
	str	q6, [sp, #3792]
	add	x10, sp, #3776
	ldr	w10, [x10, x3]
	csel	w1, w10, w1, ne
	bit.8b	v10, v4, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	cmp	w7, #1
	b.ne	LBB0_663
; %bb.70:                               ; %convergence.cascade723
                                        ;   in Loop: Header=BB0_69 Depth=4
	cmp	w1, #0
	ccmp	w2, #6, #2, ne
	b.hi	LBB0_663
; %bb.71:                               ; %convergence.cascade723
                                        ;   in Loop: Header=BB0_69 Depth=4
	add	w2, w2, #1
	tst	w3, #0xff
	b.ne	LBB0_69
	b	LBB0_663
LBB0_72:                                ; %scheduler.dispatch.route.schedule.4_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w2, s3
	eor	w2, w2, #0x1
	b	LBB0_149
LBB0_73:                                ; %scheduler.dispatch.route.schedule.15_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w2, s3
	eor	w2, w2, #0x1
	b	LBB0_345
LBB0_74:                                ; %scheduler.dispatch.route.schedule.23_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w2, s3
	eor	w2, w2, #0x1
	b	LBB0_490
LBB0_75:                                ; %scheduler.dispatch.route.schedule.39_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w2, s3
	eor	w2, w2, #0x1
	b	LBB0_780
LBB0_76:                                ; %scheduler.dispatch.route.schedule.2_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	b	LBB0_140
LBB0_77:                                ; %scheduler.dispatch.route.schedule.20_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w2, s3
	eor	w2, w2, #0x1
	b	LBB0_423
LBB0_78:                                ; %scheduler.dispatch.route.schedule.36_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w2, s3
	eor	w2, w2, #0x1
	b	LBB0_713
LBB0_79:                                ; %scheduler.dispatch.route.schedule.44_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w2, s3
	eor	w2, w2, #0x1
	b	LBB0_858
LBB0_80:                                ; %scheduler.dispatch.route.schedule.7_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w2, s3
	eor	w2, w2, #0x1
	b	LBB0_200
LBB0_81:                                ; %schedule.40
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	ldr	q5, [sp, #16512]
	ldr	q31, [sp, #16528]
	ldr	q4, [sp, #16544]
	ldr	q3, [sp, #16560]
	ldr	q18, [sp, #16624]
	ldr	q26, [sp, #16608]
	ldr	q11, [sp, #16592]
	ldr	q16, [sp, #16576]
	ldr	q17, [sp, #16128]
	ldr	q12, [sp, #16144]
	ldr	q27, [sp, #16160]
	ldr	q19, [sp, #16176]
	shl.2d	v17, v17, #5
	add.2d	v5, v5, v16
	add.2d	v30, v5, v17
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbnz	w2, #0, LBB0_125
; %bb.82:                               ; %else4884
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #1, LBB0_126
LBB0_83:                                ; %else4890
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.2d	v5, v12, #5
	add.2d	v24, v31, v11
	add.2d	v30, v24, v5
	tbnz	w2, #2, LBB0_127
LBB0_84:                                ; %else4896
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #3, LBB0_128
LBB0_85:                                ; %else4902
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.2d	v5, v27, #5
	add.2d	v4, v4, v26
	add.2d	v4, v4, v5
	tbnz	w2, #4, LBB0_129
LBB0_86:                                ; %else4908
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #5, LBB0_130
LBB0_87:                                ; %else4914
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.2d	v4, v19, #5
	add.2d	v3, v3, v18
	add.2d	v3, v3, v4
	tbnz	w2, #6, LBB0_131
LBB0_88:                                ; %else4920
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w2, #7, LBB0_90
LBB0_89:                                ; %cond.load4922
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v3[1]
	ld1.s	{ v17 }[3], [x3]
LBB0_90:                                ; %else4926
                                        ;   in Loop: Header=BB0_7 Depth=3
	zip2.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q0, [sp, #608]                  ; 16-byte Folded Reload
	bit.16b	v0, v17, v3
	str	q0, [sp, #608]                  ; 16-byte Folded Spill
	zip1.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q0, [sp, #624]                  ; 16-byte Folded Reload
	bit.16b	v0, v16, v3
	str	q0, [sp, #624]                  ; 16-byte Folded Spill
	tst	w2, #0xff
	b.eq	LBB0_5
LBB0_91:                                ; %schedule.41
                                        ;   in Loop: Header=BB0_7 Depth=3
	cbz	w1, LBB0_807
LBB0_92:                                ; %convergence.cascade887.preheader
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
LBB0_93:                                ; %convergence.cascade887
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_7 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w10, s4
	umaxv.8b	b3, v3
	fmov	w6, s3
	sub	w3, w1, #1
	tst	w10, #0xff
	csel	w4, w3, wzr, ne
	mov	w10, #1                         ; =0x1
	lsl	w5, w10, w4
	and	w10, w5, w17
	tst	w10, #0xff
	cset	w10, ne
	str	q9, [sp, #4352]
	str	q8, [sp, #4368]
	ubfiz	x3, x4, #2, #3
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #256
	ldr	w7, [x7, x3]
	cmp	w7, #15
	cset	w7, eq
	and	w19, w10, w6
	add	x6, sp, #18, lsl #12            ; =73728
	add	x6, x6, #752
	ldrb	w10, [x6, w4, sxtw]
	and	w20, w10, #0x1
	fmov	s3, w20
	ubfx	w20, w10, #1, #1
	mov.b	v3[1], w20
	ubfx	w20, w10, #2, #1
	mov.b	v3[2], w20
	ubfx	w20, w10, #3, #1
	mov.b	v3[3], w20
	ubfx	w20, w10, #4, #1
	mov.b	v3[4], w20
	ubfx	w20, w10, #5, #1
	mov.b	v3[5], w20
	ubfx	w20, w10, #6, #1
	mov.b	v3[6], w20
	add	x20, sp, #18, lsl #12           ; =73728
	add	x20, x20, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x20, w4, sxtw]
	and	w21, w10, #0x1
	fmov	s4, w21
	ubfx	w21, w10, #1, #1
	mov.b	v4[1], w21
	ubfx	w21, w10, #2, #1
	mov.b	v4[2], w21
	ubfx	w21, w10, #3, #1
	mov.b	v4[3], w21
	ubfx	w21, w10, #4, #1
	mov.b	v4[4], w21
	ubfx	w21, w10, #5, #1
	mov.b	v4[5], w21
	ubfx	w21, w10, #6, #1
	mov.b	v4[6], w21
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	orr.8b	v5, v10, v4
	and.8b	v16, v1, v3
	eor.8b	v16, v16, v5
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	umaxv.8b	b16, v16
	fmov	w10, s16
	ands	w7, w19, w7
	csetm	w19, ne
	bics	w10, w7, w10
	csetm	w21, ne
	dup.8b	v16, w21
	bic.8b	v17, v5, v16
	dup.8b	v18, w19
	bit.8b	v4, v17, v18
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x20, w4, sxtw]
	bic.8b	v3, v3, v16
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x6, w4, sxtw]
	mov	w4, #-1                         ; =0xffffffff
	csinv	w4, w4, w5, eq
	and	w17, w4, w17
	dup.8b	v3, w7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v4, w10
	and.8b	v4, v4, v5
	str	q7, [sp, #4320]
	str	q6, [sp, #4336]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #224
	ldr	w10, [x10, x3]
	csel	w1, w10, w1, ne
	bit.8b	v10, v4, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	cmp	w7, #1
	b.ne	LBB0_808
; %bb.94:                               ; %convergence.cascade887
                                        ;   in Loop: Header=BB0_93 Depth=4
	cmp	w1, #0
	ccmp	w2, #6, #2, ne
	b.hi	LBB0_808
; %bb.95:                               ; %convergence.cascade887
                                        ;   in Loop: Header=BB0_93 Depth=4
	add	w2, w2, #1
	tst	w3, #0xff
	b.ne	LBB0_93
	b	LBB0_808
LBB0_96:                                ; %scheduler.dispatch.route.schedule.28_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w2, s3
	eor	w2, w2, #0x1
	b	LBB0_568
LBB0_97:                                ; %cond.load4422
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x3, d30
	ldr	s16, [x3]
	tbz	w2, #1, LBB0_11
LBB0_98:                                ; %cond.load4428
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v30[1]
	ld1.s	{ v16 }[1], [x3]
	shl.2d	v5, v12, #5
	add.2d	v24, v31, v11
	add.2d	v30, v24, v5
	tbz	w2, #2, LBB0_12
LBB0_99:                                ; %cond.load4434
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x3, d30
	ld1.s	{ v16 }[2], [x3]
	tbz	w2, #3, LBB0_13
LBB0_100:                               ; %cond.load4440
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v30[1]
	ld1.s	{ v16 }[3], [x3]
	shl.2d	v5, v27, #5
	add.2d	v4, v4, v26
	add.2d	v4, v4, v5
	tbz	w2, #4, LBB0_14
LBB0_101:                               ; %cond.load4446
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x3, d4
	ld1.s	{ v17 }[0], [x3]
	tbz	w2, #5, LBB0_15
LBB0_102:                               ; %cond.load4452
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v4[1]
	ld1.s	{ v17 }[1], [x3]
	shl.2d	v4, v19, #5
	add.2d	v3, v3, v18
	add.2d	v3, v3, v4
	tbz	w2, #6, LBB0_16
LBB0_103:                               ; %cond.load4458
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x3, d3
	ld1.s	{ v17 }[2], [x3]
	tbnz	w2, #7, LBB0_17
	b	LBB0_18
LBB0_104:                               ; %cond.load4193
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x3, d30
	ldr	s16, [x3]
	tbz	w2, #1, LBB0_28
LBB0_105:                               ; %cond.load4199
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v30[1]
	ld1.s	{ v16 }[1], [x3]
	shl.2d	v5, v12, #5
	add.2d	v24, v31, v11
	add.2d	v30, v24, v5
	tbz	w2, #2, LBB0_29
LBB0_106:                               ; %cond.load4205
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x3, d30
	ld1.s	{ v16 }[2], [x3]
	tbz	w2, #3, LBB0_30
LBB0_107:                               ; %cond.load4211
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v30[1]
	ld1.s	{ v16 }[3], [x3]
	shl.2d	v5, v27, #5
	add.2d	v4, v4, v26
	add.2d	v4, v4, v5
	tbz	w2, #4, LBB0_31
LBB0_108:                               ; %cond.load4217
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x3, d4
	ld1.s	{ v17 }[0], [x3]
	tbz	w2, #5, LBB0_32
LBB0_109:                               ; %cond.load4223
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v4[1]
	ld1.s	{ v17 }[1], [x3]
	shl.2d	v4, v19, #5
	add.2d	v3, v3, v18
	add.2d	v3, v3, v4
	tbz	w2, #6, LBB0_33
LBB0_110:                               ; %cond.load4229
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x3, d3
	ld1.s	{ v17 }[2], [x3]
	tbnz	w2, #7, LBB0_34
	b	LBB0_35
LBB0_111:                               ; %cond.load3964
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x3, d30
	ldr	s16, [x3]
	tbz	w2, #1, LBB0_43
LBB0_112:                               ; %cond.load3970
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v30[1]
	ld1.s	{ v16 }[1], [x3]
	shl.2d	v5, v12, #5
	add.2d	v24, v31, v11
	add.2d	v30, v24, v5
	tbz	w2, #2, LBB0_44
LBB0_113:                               ; %cond.load3976
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x3, d30
	ld1.s	{ v16 }[2], [x3]
	tbz	w2, #3, LBB0_45
LBB0_114:                               ; %cond.load3982
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v30[1]
	ld1.s	{ v16 }[3], [x3]
	shl.2d	v5, v27, #5
	add.2d	v4, v4, v26
	add.2d	v4, v4, v5
	tbz	w2, #4, LBB0_46
LBB0_115:                               ; %cond.load3988
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x3, d4
	ld1.s	{ v17 }[0], [x3]
	tbz	w2, #5, LBB0_47
LBB0_116:                               ; %cond.load3994
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v4[1]
	ld1.s	{ v17 }[1], [x3]
	shl.2d	v4, v19, #5
	add.2d	v3, v3, v18
	add.2d	v3, v3, v4
	tbz	w2, #6, LBB0_48
LBB0_117:                               ; %cond.load4000
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x3, d3
	ld1.s	{ v17 }[2], [x3]
	tbnz	w2, #7, LBB0_49
	b	LBB0_50
LBB0_118:                               ; %cond.load4651
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x3, d30
	ldr	s16, [x3]
	tbz	w2, #1, LBB0_59
LBB0_119:                               ; %cond.load4657
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v30[1]
	ld1.s	{ v16 }[1], [x3]
	shl.2d	v5, v12, #5
	add.2d	v24, v31, v11
	add.2d	v30, v24, v5
	tbz	w2, #2, LBB0_60
LBB0_120:                               ; %cond.load4663
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x3, d30
	ld1.s	{ v16 }[2], [x3]
	tbz	w2, #3, LBB0_61
LBB0_121:                               ; %cond.load4669
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v30[1]
	ld1.s	{ v16 }[3], [x3]
	shl.2d	v5, v27, #5
	add.2d	v4, v4, v26
	add.2d	v4, v4, v5
	tbz	w2, #4, LBB0_62
LBB0_122:                               ; %cond.load4675
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x3, d4
	ld1.s	{ v17 }[0], [x3]
	tbz	w2, #5, LBB0_63
LBB0_123:                               ; %cond.load4681
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v4[1]
	ld1.s	{ v17 }[1], [x3]
	shl.2d	v4, v19, #5
	add.2d	v3, v3, v18
	add.2d	v3, v3, v4
	tbz	w2, #6, LBB0_64
LBB0_124:                               ; %cond.load4687
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x3, d3
	ld1.s	{ v17 }[2], [x3]
	tbnz	w2, #7, LBB0_65
	b	LBB0_66
LBB0_125:                               ; %cond.load4880
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x3, d30
	ldr	s16, [x3]
	tbz	w2, #1, LBB0_83
LBB0_126:                               ; %cond.load4886
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v30[1]
	ld1.s	{ v16 }[1], [x3]
	shl.2d	v5, v12, #5
	add.2d	v24, v31, v11
	add.2d	v30, v24, v5
	tbz	w2, #2, LBB0_84
LBB0_127:                               ; %cond.load4892
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x3, d30
	ld1.s	{ v16 }[2], [x3]
	tbz	w2, #3, LBB0_85
LBB0_128:                               ; %cond.load4898
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v30[1]
	ld1.s	{ v16 }[3], [x3]
	shl.2d	v5, v27, #5
	add.2d	v4, v4, v26
	add.2d	v4, v4, v5
	tbz	w2, #4, LBB0_86
LBB0_129:                               ; %cond.load4904
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x3, d4
	ld1.s	{ v17 }[0], [x3]
	tbz	w2, #5, LBB0_87
LBB0_130:                               ; %cond.load4910
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v4[1]
	ld1.s	{ v17 }[1], [x3]
	shl.2d	v4, v19, #5
	add.2d	v3, v3, v18
	add.2d	v3, v3, v4
	tbz	w2, #6, LBB0_88
LBB0_131:                               ; %cond.load4916
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x3, d3
	ld1.s	{ v17 }[2], [x3]
	tbnz	w2, #7, LBB0_89
	b	LBB0_90
LBB0_132:                               ; %schedule.1
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w2, s3
	ldp	q5, q0, [sp, #640]              ; 32-byte Folded Reload
	cmle.2d	v3, v0, #0
	cmle.2d	v4, v5, #0
	uzp1.4s	v3, v3, v4
	ldp	q18, q17, [sp, #672]            ; 32-byte Folded Reload
	cmle.2d	v4, v17, #0
	cmle.2d	v16, v18, #0
	uzp1.4s	v4, v4, v16
	uzp1.8h	v3, v3, v4
	xtn.8b	v3, v3
	and.8b	v11, v10, v3
	shl.8b	v3, v11, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w3, s4
	umaxv.8b	b3, v3
	fmov	w4, s3
	tbz	w4, #0, LBB0_138
; %bb.133:                              ; %schedule.1
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w4, #1                          ; =0x1
	dup.2d	v3, x4
	cmge.2d	v4, v5, v3
	cmge.2d	v16, v0, v3
	uzp1.4s	v4, v16, v4
	cmge.2d	v16, v17, v3
	cmge.2d	v3, v18, v3
	uzp1.4s	v3, v16, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v12, v10, v3
	shl.8b	v3, v12, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w4, s3
	tst	w4, #0xff
	b.eq	LBB0_138
; %bb.134:                              ; %varying.divergent
                                        ;   in Loop: Header=BB0_7 Depth=3
	subs	w10, w1, #1
	csel	w10, wzr, w10, lo
	and	w3, w17, #0xff
	lsr	w2, w3, w10
	tst	w2, #0x1
	str	q9, [sp, #1632]
	str	q8, [sp, #1648]
	and	x10, x10, #0x7
	add	x2, sp, #1632
	ldr	w10, [x2, x10, lsl #2]
	ccmp	w1, #0, #4, ne
	ccmp	w10, #0, #0, ne
	cset	w2, ne
	cmp	w3, #255
	b.ne	LBB0_136
; %bb.135:                              ; %varying.divergent
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w2, #0, LBB0_136
	b	LBB0_1006
LBB0_136:                               ; %convergence.overflow.resume
                                        ;   in Loop: Header=BB0_7 Depth=3
	mvn	w10, w17
	rbit	w10, w10
	clz	w10, w10
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w17
	csel	w4, wzr, w10, eq
	add	x3, sp, #18, lsl #12            ; =73728
	add	x3, x3, #752
	ldrb	w10, [x3, w4, uxtw]
	and	w5, w10, #0x1
	fmov	s3, w5
	ubfx	w5, w10, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w10, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w10, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w10, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w10, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w10, #6, #1
	mov.b	v3[6], w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x5, w4, uxtw]
	and	w6, w10, #0x1
	fmov	s4, w6
	ubfx	w6, w10, #1, #1
	mov.b	v4[1], w6
	ubfx	w6, w10, #2, #1
	mov.b	v4[2], w6
	ubfx	w6, w10, #3, #1
	mov.b	v4[3], w6
	ubfx	w6, w10, #4, #1
	mov.b	v4[4], w6
	ubfx	w6, w10, #5, #1
	mov.b	v4[5], w6
	ubfx	w6, w10, #6, #1
	mov.b	v4[6], w6
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	cmp	w2, #0
	csetm	w10, ne
	dup.8b	v5, w10
	bit.8b	v3, v10, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x3, w4, uxtw]
	bic.8b	v3, v4, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w4, uxtw]
	cmp	x0, #8
	b.hs	LBB0_1006
; %bb.137:                              ; %ready.overflow.resume109
                                        ;   in Loop: Header=BB0_7 Depth=3
	str	q7, [sp, #1600]
	str	q6, [sp, #1616]
	ubfiz	x10, x4, #2, #3
	add	x3, sp, #1600
	ldr	w3, [x3, x10]
	cmp	w2, #0
	csel	w3, w1, w3, ne
	str	q7, [sp, #1568]
	str	q6, [sp, #1584]
	add	x5, sp, #1568
	str	w3, [x5, x10]
	ldr	q6, [sp, #1584]
	ldr	q7, [sp, #1568]
	str	q9, [sp, #1536]
	str	q8, [sp, #1552]
	add	x3, sp, #1536
	ldr	w3, [x3, x10]
	csel	w3, wzr, w3, ne
	str	q9, [sp, #1504]
	str	q8, [sp, #1520]
	add	x5, sp, #1504
	str	w3, [x5, x10]
	csinc	w1, w1, w4, eq
	mov	w3, #49                         ; =0x31
	mov	w5, #2                          ; =0x2
	ldr	q8, [sp, #1520]
	ldr	q9, [sp, #1504]
	b	LBB0_939
LBB0_138:                               ; %varying.coherent
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_984
; %bb.139:                              ; %varying.coherent.true
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_5
LBB0_140:                               ; %schedule.2
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	x16, #0                         ; =0x0
	rbit	w3, w2
	clz	w3, w3
	tst	w2, #0xff
	csel	w3, wzr, w3, eq
	ubfiz	x4, x3, #3, #3
Lloh10:
	adrp	x5, lCPI0_4@PAGE
Lloh11:
	ldr	q3, [x5, lCPI0_4@PAGEOFF]
Lloh12:
	adrp	x5, lCPI0_5@PAGE
Lloh13:
	ldr	q4, [x5, lCPI0_5@PAGEOFF]
	str	q3, [sp, #16016]
	str	q4, [sp, #16000]
Lloh14:
	adrp	x5, lCPI0_6@PAGE
Lloh15:
	ldr	q3, [x5, lCPI0_6@PAGEOFF]
Lloh16:
	adrp	x5, lCPI0_7@PAGE
Lloh17:
	ldr	q4, [x5, lCPI0_7@PAGEOFF]
	str	q3, [sp, #15984]
	str	q4, [sp, #15968]
	add	x5, sp, #3, lsl #12             ; =12288
	add	x5, x5, #3680
	ldr	x5, [x5, x4]
Lloh18:
	adrp	x6, lCPI0_8@PAGE
Lloh19:
	ldr	q3, [x6, lCPI0_8@PAGEOFF]
Lloh20:
	adrp	x6, lCPI0_9@PAGE
Lloh21:
	ldr	q4, [x6, lCPI0_9@PAGEOFF]
	str	q3, [sp, #15952]
	str	q4, [sp, #15936]
Lloh22:
	adrp	x6, lCPI0_10@PAGE
Lloh23:
	ldr	q3, [x6, lCPI0_10@PAGEOFF]
Lloh24:
	adrp	x6, lCPI0_11@PAGE
Lloh25:
	ldr	q4, [x6, lCPI0_11@PAGEOFF]
	str	q3, [sp, #15920]
	str	q4, [sp, #15904]
	add	x6, sp, #3, lsl #12             ; =12288
	add	x6, x6, #3616
	ldr	x6, [x6, x4]
Lloh26:
	adrp	x7, lCPI0_12@PAGE
Lloh27:
	ldr	q3, [x7, lCPI0_12@PAGEOFF]
Lloh28:
	adrp	x7, lCPI0_13@PAGE
Lloh29:
	ldr	q4, [x7, lCPI0_13@PAGEOFF]
	str	q3, [sp, #15888]
	str	q4, [sp, #15872]
Lloh30:
	adrp	x7, lCPI0_14@PAGE
Lloh31:
	ldr	q3, [x7, lCPI0_14@PAGEOFF]
Lloh32:
	adrp	x7, lCPI0_15@PAGE
Lloh33:
	ldr	q4, [x7, lCPI0_15@PAGEOFF]
	str	q3, [sp, #15856]
	str	q4, [sp, #15840]
	add	x7, sp, #3, lsl #12             ; =12288
	add	x7, x7, #3552
	ldr	x7, [x7, x4]
Lloh34:
	adrp	x19, lCPI0_16@PAGE
Lloh35:
	ldr	q16, [x19, lCPI0_16@PAGEOFF]
Lloh36:
	adrp	x19, lCPI0_17@PAGE
Lloh37:
	ldr	q18, [x19, lCPI0_17@PAGEOFF]
Lloh38:
	adrp	x19, lCPI0_18@PAGE
Lloh39:
	ldr	q17, [x19, lCPI0_18@PAGEOFF]
Lloh40:
	adrp	x19, lCPI0_19@PAGE
Lloh41:
	ldr	q19, [x19, lCPI0_19@PAGEOFF]
	str	q19, [sp, #15824]
	str	q17, [sp, #15808]
	str	q18, [sp, #15792]
	str	q16, [sp, #15776]
	add	x19, sp, #3, lsl #12            ; =12288
	add	x19, x19, #3488
	ldr	x19, [x19, x4]
	lsl	w20, w3, #2
	sub	x3, x5, x20
	tst	w2, #0xff
	csel	x3, xzr, x3, eq
	sub	x4, x6, x20
	tst	w2, #0xff
	csel	x4, xzr, x4, eq
	sub	x5, x7, x20
	tst	w2, #0xff
	csel	x5, xzr, x5, eq
	sub	x6, x19, x20
	ands	w2, w2, #0xff
	ldr	q4, [sp, #18800]
	ldr	q30, [sp, #18752]
	ldr	q11, [sp, #18768]
	ldr	q12, [sp, #18784]
	ldr	q13, [sp, #18720]
	ldr	q31, [sp, #18736]
	ldr	q27, [sp, #18688]
	ldr	q26, [sp, #18704]
	mov	b3, v10[2]
	mov.b	v3[4], v10[3]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q22, [sp, #160]                 ; 16-byte Folded Reload
	mov.16b	v14, v3
	bsl.16b	v14, v22, v26
	mov	b26, v10[0]
	mov.b	v26[4], v10[1]
	ushll.2d	v26, v26, #0
	shl.2d	v26, v26, #63
	cmlt.2d	v26, v26, #0
	mov.16b	v0, v21
	mov.16b	v21, v20
	mov.16b	v20, v15
	mov.16b	v15, v26
	bsl.16b	v15, v22, v27
	mov	b27, v10[6]
	mov.b	v27[4], v10[7]
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	mov.16b	v5, v27
	bsl.16b	v5, v22, v31
	mov	b31, v10[4]
	mov.b	v31[4], v10[5]
	ushll.2d	v31, v31, #0
	shl.2d	v31, v31, #63
	cmlt.2d	v31, v31, #0
	bit.16b	v13, v22, v31
	bit.16b	v12, v17, v31
	bit.16b	v11, v18, v3
	bit.16b	v30, v16, v26
	bit.16b	v4, v19, v27
	zip2.8b	v24, v10, v0
	ushll.4s	v24, v24, #0
	shl.4s	v24, v24, #31
	cmlt.4s	v24, v24, #0
	zip1.8b	v25, v10, v0
	ushll.4s	v25, v25, #0
	shl.4s	v25, v25, #31
	cmlt.4s	v25, v25, #0
	str	q4, [sp, #18800]
	str	q30, [sp, #18752]
	str	q11, [sp, #18768]
	str	q13, [sp, #18720]
	str	q5, [sp, #18736]
	str	q15, [sp, #18688]
	mov.16b	v15, v20
	mov.16b	v20, v21
	mov.16b	v21, v0
	str	q14, [sp, #18704]
	str	q12, [sp, #18784]
	ldr	q4, [sp, #18928]
	ldr	q5, [sp, #18912]
	csel	x6, xzr, x6, eq
	add	x7, sp, #18, lsl #12            ; =73728
	add	x7, x7, #616
	add	x6, x7, x6
	ldp	q11, q30, [x6]
	bif.16b	v5, v11, v25
	bif.16b	v4, v30, v24
	stp	q5, q4, [x6]
	ldr	q4, [sp, #18896]
	ldr	q5, [sp, #18880]
	add	x5, x7, x5
	ldp	q11, q30, [x5]
	bif.16b	v5, v11, v25
	bif.16b	v4, v30, v24
	stp	q5, q4, [x5]
	ldr	q4, [sp, #18864]
	ldr	q5, [sp, #18848]
	add	x4, x7, x4
	ldp	q11, q30, [x4]
	bif.16b	v5, v11, v25
	bif.16b	v4, v30, v24
	stp	q5, q4, [x4]
	ldr	q4, [sp, #18816]
	ldr	q5, [sp, #18832]
	add	x3, x7, x3
	ldp	q30, q11, [x3]
	bif.16b	v5, v11, v24
	bif.16b	v4, v30, v25
	stp	q4, q5, [x3]
	ldr	q4, [sp, #18656]
	ldr	q5, [sp, #18672]
	ldr	q24, [sp, #18624]
	ldr	q25, [sp, #18640]
	ldr	q30, [sp, #18592]
	ldr	q11, [sp, #18608]
	ldr	q12, [sp, #18560]
	ldr	q13, [sp, #18576]
	ldr	q22, [sp, #144]                 ; 16-byte Folded Reload
	bit.16b	v13, v22, v3
	bit.16b	v12, v22, v26
	bit.16b	v11, v22, v27
	bit.16b	v30, v22, v31
	bif.16b	v18, v25, v3
	bif.16b	v16, v24, v26
	bit.16b	v5, v19, v27
	bit.16b	v4, v17, v31
	str	q4, [sp, #18656]
	str	q5, [sp, #18672]
	str	q16, [sp, #18624]
	str	q18, [sp, #18640]
	str	q30, [sp, #18592]
	str	q11, [sp, #18608]
	str	q12, [sp, #18560]
	str	q13, [sp, #18576]
	ldp	q5, q0, [sp, #976]              ; 32-byte Folded Reload
	bic.16b	v4, v5, v27
	bic.16b	v0, v0, v31
	stp	q4, q0, [sp, #976]              ; 32-byte Folded Spill
	ldr	q0, [sp, #1008]                 ; 16-byte Folded Reload
	bic.16b	v0, v0, v3
	str	q0, [sp, #1008]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #800]                  ; 16-byte Folded Reload
	bic.16b	v0, v0, v26
	str	q0, [sp, #800]                  ; 16-byte Folded Spill
	cbz	w2, LBB0_5
LBB0_141:                               ; %schedule.3
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	mov	w2, #128                        ; =0x80
	dup.2d	v3, x2
	ldp	q18, q17, [sp, #992]            ; 32-byte Folded Reload
	cmgt.2d	v4, v3, v17
	ldr	q0, [sp, #800]                  ; 16-byte Folded Reload
	cmgt.2d	v5, v3, v0
	uzp1.4s	v4, v5, v4
	cmgt.2d	v5, v3, v18
	ldr	q19, [sp, #976]                 ; 16-byte Folded Reload
	cmgt.2d	v16, v3, v19
	uzp1.4s	v5, v5, v16
	uzp1.8h	v4, v4, v5
	xtn.8b	v4, v4
	and.8b	v11, v10, v4
	shl.8b	v4, v11, #7
	cmlt.8b	v4, v4, #0
	and.8b	v5, v4, v2
	addv.8b	b5, v5
	fmov	w2, s5
	umaxv.8b	b4, v4
	fmov	w4, s4
	tbz	w4, #0, LBB0_147
; %bb.142:                              ; %schedule.3
                                        ;   in Loop: Header=BB0_7 Depth=3
	cmge.2d	v4, v17, v3
	cmge.2d	v5, v0, v3
	uzp1.4s	v4, v5, v4
	cmge.2d	v5, v18, v3
	cmge.2d	v3, v19, v3
	uzp1.4s	v3, v5, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v12, v10, v3
	shl.8b	v3, v12, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w4, s3
	tst	w4, #0xff
	b.eq	LBB0_147
; %bb.143:                              ; %varying.divergent121
                                        ;   in Loop: Header=BB0_7 Depth=3
	subs	w10, w1, #1
	csel	w10, wzr, w10, lo
	and	w3, w17, #0xff
	lsr	w2, w3, w10
	tst	w2, #0x1
	str	q9, [sp, #1792]
	str	q8, [sp, #1808]
	and	x10, x10, #0x7
	add	x2, sp, #1792
	ldr	w10, [x2, x10, lsl #2]
	ccmp	w1, #0, #4, ne
	ccmp	w10, #1, #0, ne
	cset	w2, ne
	cmp	w3, #255
	b.ne	LBB0_145
; %bb.144:                              ; %varying.divergent121
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w2, #0, LBB0_145
	b	LBB0_1006
LBB0_145:                               ; %convergence.overflow.resume124
                                        ;   in Loop: Header=BB0_7 Depth=3
	mvn	w10, w17
	rbit	w10, w10
	clz	w10, w10
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w17
	csel	w4, wzr, w10, eq
	add	x3, sp, #18, lsl #12            ; =73728
	add	x3, x3, #752
	ldrb	w10, [x3, w4, uxtw]
	and	w5, w10, #0x1
	fmov	s3, w5
	ubfx	w5, w10, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w10, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w10, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w10, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w10, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w10, #6, #1
	mov.b	v3[6], w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x5, w4, uxtw]
	and	w6, w10, #0x1
	fmov	s4, w6
	ubfx	w6, w10, #1, #1
	mov.b	v4[1], w6
	ubfx	w6, w10, #2, #1
	mov.b	v4[2], w6
	ubfx	w6, w10, #3, #1
	mov.b	v4[3], w6
	ubfx	w6, w10, #4, #1
	mov.b	v4[4], w6
	ubfx	w6, w10, #5, #1
	mov.b	v4[5], w6
	ubfx	w6, w10, #6, #1
	mov.b	v4[6], w6
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	cmp	w2, #0
	csetm	w10, ne
	dup.8b	v5, w10
	bit.8b	v3, v10, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x3, w4, uxtw]
	bic.8b	v3, v4, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w4, uxtw]
	cmp	x0, #8
	b.hs	LBB0_1006
; %bb.146:                              ; %ready.overflow.resume126
                                        ;   in Loop: Header=BB0_7 Depth=3
	str	q7, [sp, #1760]
	str	q6, [sp, #1776]
	ubfiz	x10, x4, #2, #3
	add	x3, sp, #1760
	ldr	w3, [x3, x10]
	cmp	w2, #0
	csel	w3, w1, w3, ne
	csinc	w1, w1, w4, eq
	str	q7, [sp, #1728]
	str	q6, [sp, #1744]
	add	x5, sp, #1728
	str	w3, [x5, x10]
	ldr	q6, [sp, #1744]
	ldr	q7, [sp, #1728]
	str	q9, [sp, #1696]
	str	q8, [sp, #1712]
	add	x3, sp, #1696
	ldr	w3, [x3, x10]
	csinc	w3, w3, wzr, eq
	str	q9, [sp, #1664]
	str	q8, [sp, #1680]
	add	x5, sp, #1664
	str	w3, [x5, x10]
	mov	w3, #5                          ; =0x5
	mov	w5, #4                          ; =0x4
	ldr	q8, [sp, #1680]
	ldr	q9, [sp, #1664]
	b	LBB0_938
LBB0_147:                               ; %varying.coherent122
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_182
; %bb.148:                              ; %varying.coherent.true127
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
	tst	w3, #0xff
	b.eq	LBB0_5
LBB0_149:                               ; %schedule.4
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	b3, v10[0]
	mov.b	v3[4], v10[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v4, v3, #0
	ldr	q0, [sp, #800]                  ; 16-byte Folded Reload
	and.16b	v17, v4, v0
	mov	b3, v10[2]
	mov.b	v3[4], v10[3]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v5, v3, #0
	ldr	q3, [sp, #1008]                 ; 16-byte Folded Reload
	and.16b	v18, v5, v3
	mov	b3, v10[4]
	mov.b	v3[4], v10[5]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v24, v3, #0
	ldr	q3, [sp, #992]                  ; 16-byte Folded Reload
	and.16b	v19, v24, v3
	mov	b3, v10[6]
	mov.b	v3[4], v10[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v25, v3, #0
	ldr	q3, [sp, #976]                  ; 16-byte Folded Reload
	and.16b	v3, v25, v3
	shl.8b	v16, v10, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v2
	addv.8b	b16, v16
	fmov	w3, s16
	mov	w4, #32                         ; =0x20
	dup.2d	v27, x4
	and.16b	v26, v4, v27
	mvn.16b	v4, v4
	sub.2d	v26, v26, v4
	and.16b	v4, v5, v27
	mvn.16b	v5, v5
	sub.2d	v4, v4, v5
	and.16b	v5, v24, v27
	and.16b	v27, v25, v27
	mvn.16b	v25, v25
	sub.2d	v25, v27, v25
	mov.d	x4, v25[1]
	mov.d	x5, v3[1]
	sdiv	x5, x5, x4
	mvn.16b	v24, v24
	sub.2d	v5, v5, v24
	fmov	x6, d25
	fmov	x7, d3
	sdiv	x7, x7, x6
	mul	x6, x7, x6
	fmov	d24, x7
	mov.d	v24[1], x5
	mov.d	x7, v5[1]
	mov.d	x19, v19[1]
	sdiv	x19, x19, x7
	fmov	x20, d5
	fmov	x21, d19
	sdiv	x21, x21, x20
	mul	x20, x21, x20
	fmov	d5, x21
	mov.d	v5[1], x19
	mov.d	x21, v4[1]
	mov.d	x22, v18[1]
	sdiv	x22, x22, x21
	fmov	x23, d4
	fmov	x24, d18
	sdiv	x24, x24, x23
	mul	x23, x24, x23
	fmov	d4, x24
	mov.d	v4[1], x22
	mov.d	x24, v26[1]
	mov.d	x25, v17[1]
	fmov	x26, d26
	fmov	x27, d17
	sdiv	x27, x27, x26
	mul	x26, x27, x26
	fmov	d25, x27
	sdiv	x25, x25, x24
	mov.d	v25[1], x25
	mul	x24, x25, x24
	fmov	d26, x26
	mov.d	v26[1], x24
	mul	x21, x22, x21
	fmov	d27, x23
	mov.d	v27[1], x21
	mul	x7, x19, x7
	fmov	d30, x20
	mov.d	v30[1], x7
	mul	x4, x5, x4
	fmov	d31, x6
	mov.d	v31[1], x4
	sub.2d	v3, v3, v31
	sub.2d	v19, v19, v30
	sub.2d	v18, v18, v27
	sub.2d	v17, v17, v26
	ldr	q26, [sp, #18992]
	ldr	q27, [sp, #18976]
	ldr	q30, [sp, #18960]
	ldr	q31, [sp, #18944]
	add.2d	v25, v31, v25
	add.2d	v4, v30, v4
	add.2d	v5, v27, v5
	add.2d	v24, v26, v24
	dup.2d	v26, x16
	add.2d	v17, v17, v26
	add.2d	v18, v18, v26
	add.2d	v19, v19, v26
	add.2d	v3, v3, v26
	shl.2d	v24, v24, #7
	shl.2d	v5, v5, #7
	shl.2d	v4, v4, #7
	shl.2d	v25, v25, #7
	shl.2d	v3, v3, #2
	shl.2d	v19, v19, #2
	shl.2d	v18, v18, #2
	shl.2d	v17, v17, #2
	ldr	x10, [sp, #136]                 ; 8-byte Folded Reload
	dup.2d	v26, x10
	add.2d	v24, v26, v24
	add.2d	v3, v24, v3
	add.2d	v5, v26, v5
	add.2d	v19, v5, v19
	add.2d	v4, v26, v4
	add.2d	v4, v4, v18
	add.2d	v5, v26, v25
	add.2d	v26, v5, v17
	movi.2d	v18, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbnz	w3, #0, LBB0_168
; %bb.150:                              ; %else
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #1, LBB0_169
LBB0_151:                               ; %else3870
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #2, LBB0_170
LBB0_152:                               ; %else3873
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #3, LBB0_171
LBB0_153:                               ; %else3876
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #4, LBB0_172
LBB0_154:                               ; %else3879
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #5, LBB0_173
LBB0_155:                               ; %else3882
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #6, LBB0_174
LBB0_156:                               ; %else3885
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w3, #7, LBB0_158
LBB0_157:                               ; %cond.load3887
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v3[1]
	ld1.s	{ v17 }[3], [x3]
LBB0_158:                               ; %else3888
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q3, [sp, #18608]
	ldr	q4, [sp, #18592]
	ldr	q5, [sp, #18576]
	ldr	q19, [sp, #18560]
	ldr	q24, [sp, #18624]
	ldr	q25, [sp, #18640]
	ldr	q26, [sp, #18656]
	ldr	q27, [sp, #18672]
	shl.2d	v30, v0, #5
	ldp	q22, q23, [sp, #992]            ; 32-byte Folded Reload
	shl.2d	v31, v23, #5
	shl.2d	v11, v22, #5
	ldr	q22, [sp, #976]                 ; 16-byte Folded Reload
	shl.2d	v12, v22, #5
	add.2d	v27, v27, v12
	add.2d	v11, v26, v11
	add.2d	v25, v25, v31
	add.2d	v24, v24, v30
	add.2d	v26, v19, v24
	add.2d	v19, v5, v25
	add.2d	v4, v4, v11
	add.2d	v3, v3, v27
	fmov	w3, s16
	tbnz	w3, #0, LBB0_175
; %bb.159:                              ; %else3892
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #1, LBB0_176
LBB0_160:                               ; %else3895
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldp	q16, q5, [sp, #976]             ; 32-byte Folded Reload
	tbnz	w3, #2, LBB0_177
LBB0_161:                               ; %else3898
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #3, LBB0_178
LBB0_162:                               ; %else3901
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #4, LBB0_179
LBB0_163:                               ; %else3904
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #5, LBB0_180
LBB0_164:                               ; %else3907
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #6, LBB0_181
LBB0_165:                               ; %else3910
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w3, #7, LBB0_167
LBB0_166:                               ; %cond.store3911
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v3[1]
	st1.s	{ v17 }[3], [x3]
LBB0_167:                               ; %else3913
                                        ;   in Loop: Header=BB0_7 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v10, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v4, v3, #0
	ushll2.4s	v3, v3, #0
	uaddw2.2d	v16, v16, v3
	uaddw.2d	v5, v5, v3
	stp	q16, q5, [sp, #976]             ; 32-byte Folded Spill
	ldr	q3, [sp, #1008]                 ; 16-byte Folded Reload
	uaddw2.2d	v3, v3, v4
	str	q3, [sp, #1008]                 ; 16-byte Folded Spill
	uaddw.2d	v0, v0, v4
	str	q0, [sp, #800]                  ; 16-byte Folded Spill
	tbz	w2, #0, LBB0_141
	b	LBB0_5
LBB0_168:                               ; %cond.load
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d26
	ldr	s18, [x4]
	tbz	w3, #1, LBB0_151
LBB0_169:                               ; %cond.load3869
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v26[1]
	ld1.s	{ v18 }[1], [x4]
	tbz	w3, #2, LBB0_152
LBB0_170:                               ; %cond.load3872
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d4
	ld1.s	{ v18 }[2], [x4]
	tbz	w3, #3, LBB0_153
LBB0_171:                               ; %cond.load3875
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v4[1]
	ld1.s	{ v18 }[3], [x4]
	tbz	w3, #4, LBB0_154
LBB0_172:                               ; %cond.load3878
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d19
	ld1.s	{ v17 }[0], [x4]
	tbz	w3, #5, LBB0_155
LBB0_173:                               ; %cond.load3881
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v19[1]
	ld1.s	{ v17 }[1], [x4]
	tbz	w3, #6, LBB0_156
LBB0_174:                               ; %cond.load3884
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d3
	ld1.s	{ v17 }[2], [x4]
	tbnz	w3, #7, LBB0_157
	b	LBB0_158
LBB0_175:                               ; %cond.store
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d26
	str	s18, [x4]
	tbz	w3, #1, LBB0_160
LBB0_176:                               ; %cond.store3893
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v26[1]
	st1.s	{ v18 }[1], [x4]
	ldp	q16, q5, [sp, #976]             ; 32-byte Folded Reload
	tbz	w3, #2, LBB0_161
LBB0_177:                               ; %cond.store3896
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d19
	st1.s	{ v18 }[2], [x4]
	tbz	w3, #3, LBB0_162
LBB0_178:                               ; %cond.store3899
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v19[1]
	st1.s	{ v18 }[3], [x4]
	tbz	w3, #4, LBB0_163
LBB0_179:                               ; %cond.store3902
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d4
	str	s17, [x4]
	tbz	w3, #5, LBB0_164
LBB0_180:                               ; %cond.store3905
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v4[1]
	st1.s	{ v17 }[1], [x4]
	tbz	w3, #6, LBB0_165
LBB0_181:                               ; %cond.store3908
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d3
	st1.s	{ v17 }[2], [x4]
	tbnz	w3, #7, LBB0_166
	b	LBB0_167
LBB0_182:                               ; %varying.coherent.false128
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
LBB0_183:                               ; %schedule.5
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q0, [sp, #816]                  ; 16-byte Folded Reload
	cbz	w1, LBB0_188
; %bb.184:                              ; %convergence.cascade.preheader
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
LBB0_185:                               ; %convergence.cascade
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_7 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w10, s4
	umaxv.8b	b3, v3
	fmov	w6, s3
	sub	w3, w1, #1
	tst	w10, #0xff
	csel	w4, w3, wzr, ne
	mov	w10, #1                         ; =0x1
	lsl	w5, w10, w4
	and	w10, w5, w17
	tst	w10, #0xff
	cset	w10, ne
	str	q9, [sp, #15744]
	str	q8, [sp, #15760]
	ubfiz	x3, x4, #2, #3
	add	x7, sp, #3, lsl #12             ; =12288
	add	x7, x7, #3456
	ldr	w7, [x7, x3]
	cmp	w7, #1
	cset	w7, eq
	and	w19, w10, w6
	add	x6, sp, #18, lsl #12            ; =73728
	add	x6, x6, #752
	ldrb	w10, [x6, w4, sxtw]
	and	w20, w10, #0x1
	fmov	s3, w20
	ubfx	w20, w10, #1, #1
	mov.b	v3[1], w20
	ubfx	w20, w10, #2, #1
	mov.b	v3[2], w20
	ubfx	w20, w10, #3, #1
	mov.b	v3[3], w20
	ubfx	w20, w10, #4, #1
	mov.b	v3[4], w20
	ubfx	w20, w10, #5, #1
	mov.b	v3[5], w20
	ubfx	w20, w10, #6, #1
	mov.b	v3[6], w20
	add	x20, sp, #18, lsl #12           ; =73728
	add	x20, x20, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x20, w4, sxtw]
	and	w21, w10, #0x1
	fmov	s4, w21
	ubfx	w21, w10, #1, #1
	mov.b	v4[1], w21
	ubfx	w21, w10, #2, #1
	mov.b	v4[2], w21
	ubfx	w21, w10, #3, #1
	mov.b	v4[3], w21
	ubfx	w21, w10, #4, #1
	mov.b	v4[4], w21
	ubfx	w21, w10, #5, #1
	mov.b	v4[5], w21
	ubfx	w21, w10, #6, #1
	mov.b	v4[6], w21
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	orr.8b	v5, v10, v4
	and.8b	v16, v1, v3
	eor.8b	v16, v16, v5
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	umaxv.8b	b16, v16
	fmov	w10, s16
	ands	w7, w19, w7
	csetm	w19, ne
	bics	w10, w7, w10
	csetm	w21, ne
	dup.8b	v16, w21
	bic.8b	v17, v5, v16
	dup.8b	v18, w19
	bit.8b	v4, v17, v18
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x20, w4, sxtw]
	bic.8b	v3, v3, v16
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x6, w4, sxtw]
	mov	w4, #-1                         ; =0xffffffff
	csinv	w4, w4, w5, eq
	and	w17, w4, w17
	dup.8b	v3, w7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v4, w10
	and.8b	v4, v4, v5
	str	q7, [sp, #15712]
	str	q6, [sp, #15728]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #3424
	ldr	w10, [x10, x3]
	csel	w1, w10, w1, ne
	bit.8b	v10, v4, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	cmp	w7, #1
	b.ne	LBB0_189
; %bb.186:                              ; %convergence.cascade
                                        ;   in Loop: Header=BB0_185 Depth=4
	cmp	w1, #0
	ccmp	w2, #6, #2, ne
	b.hi	LBB0_189
; %bb.187:                              ; %convergence.cascade
                                        ;   in Loop: Header=BB0_185 Depth=4
	add	w2, w2, #1
	tst	w3, #0xff
	b.ne	LBB0_185
	b	LBB0_189
LBB0_188:                               ; %schedule.5.convergence.cascade.exit_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
LBB0_189:                               ; %convergence.cascade.exit
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
; %bb.190:                              ; %convergence.target.5.ready
                                        ;   in Loop: Header=BB0_7 Depth=3
	rbit	w10, w3
	clz	w2, w10
	ldr	q3, [sp, #18528]
	ldr	q4, [sp, #18544]
	ldr	q5, [sp, #18496]
	ldr	q16, [sp, #18512]
	ldr	q17, [sp, #18464]
	ldr	q18, [sp, #18480]
	ldr	q19, [sp, #18432]
	ldr	q22, [sp, #18448]
	mov	b23, v10[2]
	mov.b	v23[4], v10[3]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v11, v23, #0
	ldr	q24, [sp, #400]                 ; 16-byte Folded Reload
	bit.16b	v22, v24, v11
	mov	b23, v10[0]
	mov.b	v23[4], v10[1]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v12, v23, #0
	mov	b23, v10[6]
	mov.b	v23[4], v10[7]
	bit.16b	v19, v24, v12
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v13, v23, #0
	bit.16b	v18, v24, v13
	mov	b23, v10[4]
	mov.b	v23[4], v10[5]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v14, v23, #0
	bit.16b	v17, v24, v14
Lloh42:
	adrp	x10, lCPI0_20@PAGE
Lloh43:
	ldr	q23, [x10, lCPI0_20@PAGEOFF]
	bit.16b	v16, v23, v11
Lloh44:
	adrp	x10, lCPI0_21@PAGE
Lloh45:
	ldr	q24, [x10, lCPI0_21@PAGEOFF]
	bit.16b	v5, v24, v12
Lloh46:
	adrp	x10, lCPI0_22@PAGE
Lloh47:
	ldr	q25, [x10, lCPI0_22@PAGEOFF]
	bit.16b	v4, v25, v13
Lloh48:
	adrp	x10, lCPI0_23@PAGE
Lloh49:
	ldr	q26, [x10, lCPI0_23@PAGEOFF]
	bit.16b	v3, v26, v14
	str	q3, [sp, #18528]
	str	q4, [sp, #18544]
	str	q5, [sp, #18496]
	str	q16, [sp, #18512]
	str	q17, [sp, #18464]
	str	q18, [sp, #18480]
	str	q19, [sp, #18432]
	str	q22, [sp, #18448]
	str	q25, [sp, #13712]
	str	q26, [sp, #13696]
	str	q23, [sp, #13680]
	str	q24, [sp, #13664]
	lsl	w10, w2, #3
	and	x2, x10, #0x38
	add	x3, sp, #3, lsl #12             ; =12288
	add	x3, x3, #1376
	ldr	x5, [x3, x2]
	and	x3, x10, #0xf8
	add	x4, sp, #16, lsl #12            ; =65536
	add	x4, x4, #2664
	sub	x10, x5, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10, #32]
	ldp	q5, q16, [x10]
	orr.16b	v16, v11, v16
	orr.16b	v5, v12, v5
	orr.16b	v4, v13, v4
	orr.16b	v3, v14, v3
	stp	q3, q4, [x10, #32]
	stp	q5, q16, [x10]
Lloh50:
	adrp	x10, lCPI0_24@PAGE
Lloh51:
	ldr	q3, [x10, lCPI0_24@PAGEOFF]
Lloh52:
	adrp	x10, lCPI0_25@PAGE
Lloh53:
	ldr	q4, [x10, lCPI0_25@PAGEOFF]
	str	q3, [sp, #13776]
	str	q4, [sp, #13760]
Lloh54:
	adrp	x10, lCPI0_26@PAGE
Lloh55:
	ldr	q3, [x10, lCPI0_26@PAGEOFF]
Lloh56:
	adrp	x10, lCPI0_27@PAGE
Lloh57:
	ldr	q4, [x10, lCPI0_27@PAGEOFF]
	str	q3, [sp, #13744]
	str	q4, [sp, #13728]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #1440
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	bic.16b	v16, v16, v14
	bic.16b	v4, v4, v11
	bic.16b	v3, v3, v12
	bic.16b	v5, v5, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh58:
	adrp	x10, lCPI0_28@PAGE
Lloh59:
	ldr	q3, [x10, lCPI0_28@PAGEOFF]
Lloh60:
	adrp	x10, lCPI0_29@PAGE
Lloh61:
	ldr	q4, [x10, lCPI0_29@PAGEOFF]
	str	q3, [sp, #13840]
	str	q4, [sp, #13824]
Lloh62:
	adrp	x10, lCPI0_30@PAGE
Lloh63:
	ldr	q3, [x10, lCPI0_30@PAGEOFF]
Lloh64:
	adrp	x10, lCPI0_31@PAGE
Lloh65:
	ldr	q4, [x10, lCPI0_31@PAGEOFF]
	str	q3, [sp, #13808]
	str	q4, [sp, #13792]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #1504
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	bic.16b	v16, v16, v14
	sub.2d	v16, v16, v14
	bic.16b	v4, v4, v11
	sub.2d	v4, v4, v11
	bic.16b	v3, v3, v12
	sub.2d	v3, v3, v12
	bic.16b	v5, v5, v13
	sub.2d	v5, v5, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh66:
	adrp	x10, lCPI0_32@PAGE
Lloh67:
	ldr	q3, [x10, lCPI0_32@PAGEOFF]
Lloh68:
	adrp	x10, lCPI0_33@PAGE
Lloh69:
	ldr	q4, [x10, lCPI0_33@PAGEOFF]
	str	q3, [sp, #13904]
	str	q4, [sp, #13888]
Lloh70:
	adrp	x10, lCPI0_34@PAGE
Lloh71:
	ldr	q3, [x10, lCPI0_34@PAGEOFF]
Lloh72:
	adrp	x10, lCPI0_35@PAGE
Lloh73:
	ldr	q4, [x10, lCPI0_35@PAGEOFF]
	str	q3, [sp, #13872]
	str	q4, [sp, #13856]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #1568
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #2                          ; =0x2
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh74:
	adrp	x10, lCPI0_36@PAGE
Lloh75:
	ldr	q3, [x10, lCPI0_36@PAGEOFF]
Lloh76:
	adrp	x10, lCPI0_37@PAGE
Lloh77:
	ldr	q4, [x10, lCPI0_37@PAGEOFF]
	str	q3, [sp, #13968]
	str	q4, [sp, #13952]
Lloh78:
	adrp	x10, lCPI0_38@PAGE
Lloh79:
	ldr	q3, [x10, lCPI0_38@PAGEOFF]
Lloh80:
	adrp	x10, lCPI0_39@PAGE
Lloh81:
	ldr	q4, [x10, lCPI0_39@PAGEOFF]
	str	q3, [sp, #13936]
	str	q4, [sp, #13920]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #1632
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #3                          ; =0x3
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh82:
	adrp	x10, lCPI0_40@PAGE
Lloh83:
	ldr	q3, [x10, lCPI0_40@PAGEOFF]
Lloh84:
	adrp	x10, lCPI0_41@PAGE
Lloh85:
	ldr	q4, [x10, lCPI0_41@PAGEOFF]
	str	q3, [sp, #14032]
	str	q4, [sp, #14016]
Lloh86:
	adrp	x10, lCPI0_42@PAGE
Lloh87:
	ldr	q3, [x10, lCPI0_42@PAGEOFF]
Lloh88:
	adrp	x10, lCPI0_43@PAGE
Lloh89:
	ldr	q4, [x10, lCPI0_43@PAGEOFF]
	str	q3, [sp, #14000]
	str	q4, [sp, #13984]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #1696
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #4                          ; =0x4
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh90:
	adrp	x10, lCPI0_44@PAGE
Lloh91:
	ldr	q3, [x10, lCPI0_44@PAGEOFF]
Lloh92:
	adrp	x10, lCPI0_45@PAGE
Lloh93:
	ldr	q4, [x10, lCPI0_45@PAGEOFF]
	str	q3, [sp, #14096]
	str	q4, [sp, #14080]
Lloh94:
	adrp	x10, lCPI0_46@PAGE
Lloh95:
	ldr	q3, [x10, lCPI0_46@PAGEOFF]
Lloh96:
	adrp	x10, lCPI0_47@PAGE
Lloh97:
	ldr	q4, [x10, lCPI0_47@PAGEOFF]
	str	q3, [sp, #14064]
	str	q4, [sp, #14048]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #1760
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #5                          ; =0x5
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh98:
	adrp	x10, lCPI0_48@PAGE
Lloh99:
	ldr	q3, [x10, lCPI0_48@PAGEOFF]
Lloh100:
	adrp	x10, lCPI0_49@PAGE
Lloh101:
	ldr	q4, [x10, lCPI0_49@PAGEOFF]
	str	q3, [sp, #14160]
	str	q4, [sp, #14144]
Lloh102:
	adrp	x10, lCPI0_50@PAGE
Lloh103:
	ldr	q3, [x10, lCPI0_50@PAGEOFF]
Lloh104:
	adrp	x10, lCPI0_51@PAGE
Lloh105:
	ldr	q4, [x10, lCPI0_51@PAGEOFF]
	str	q3, [sp, #14128]
	str	q4, [sp, #14112]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #1824
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #6                          ; =0x6
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh106:
	adrp	x10, lCPI0_52@PAGE
Lloh107:
	ldr	q3, [x10, lCPI0_52@PAGEOFF]
Lloh108:
	adrp	x10, lCPI0_53@PAGE
Lloh109:
	ldr	q4, [x10, lCPI0_53@PAGEOFF]
	str	q3, [sp, #14224]
	str	q4, [sp, #14208]
Lloh110:
	adrp	x10, lCPI0_54@PAGE
Lloh111:
	ldr	q3, [x10, lCPI0_54@PAGEOFF]
Lloh112:
	adrp	x10, lCPI0_55@PAGE
Lloh113:
	ldr	q4, [x10, lCPI0_55@PAGEOFF]
	str	q3, [sp, #14192]
	str	q4, [sp, #14176]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #1888
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #7                          ; =0x7
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh114:
	adrp	x10, lCPI0_56@PAGE
Lloh115:
	ldr	q3, [x10, lCPI0_56@PAGEOFF]
Lloh116:
	adrp	x10, lCPI0_57@PAGE
Lloh117:
	ldr	q4, [x10, lCPI0_57@PAGEOFF]
	str	q3, [sp, #14288]
	str	q4, [sp, #14272]
Lloh118:
	adrp	x10, lCPI0_58@PAGE
Lloh119:
	ldr	q3, [x10, lCPI0_58@PAGEOFF]
Lloh120:
	adrp	x10, lCPI0_59@PAGE
Lloh121:
	ldr	q4, [x10, lCPI0_59@PAGEOFF]
	str	q3, [sp, #14256]
	str	q4, [sp, #14240]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #1952
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #8                          ; =0x8
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh122:
	adrp	x10, lCPI0_60@PAGE
Lloh123:
	ldr	q3, [x10, lCPI0_60@PAGEOFF]
Lloh124:
	adrp	x10, lCPI0_61@PAGE
Lloh125:
	ldr	q4, [x10, lCPI0_61@PAGEOFF]
	str	q3, [sp, #14352]
	str	q4, [sp, #14336]
Lloh126:
	adrp	x10, lCPI0_62@PAGE
Lloh127:
	ldr	q3, [x10, lCPI0_62@PAGEOFF]
Lloh128:
	adrp	x10, lCPI0_63@PAGE
Lloh129:
	ldr	q4, [x10, lCPI0_63@PAGEOFF]
	str	q3, [sp, #14320]
	str	q4, [sp, #14304]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2016
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #9                          ; =0x9
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh130:
	adrp	x10, lCPI0_64@PAGE
Lloh131:
	ldr	q3, [x10, lCPI0_64@PAGEOFF]
Lloh132:
	adrp	x10, lCPI0_65@PAGE
Lloh133:
	ldr	q4, [x10, lCPI0_65@PAGEOFF]
	str	q3, [sp, #14416]
	str	q4, [sp, #14400]
Lloh134:
	adrp	x10, lCPI0_66@PAGE
Lloh135:
	ldr	q3, [x10, lCPI0_66@PAGEOFF]
Lloh136:
	adrp	x10, lCPI0_67@PAGE
Lloh137:
	ldr	q4, [x10, lCPI0_67@PAGEOFF]
	str	q3, [sp, #14384]
	str	q4, [sp, #14368]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2080
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #10                         ; =0xa
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh138:
	adrp	x10, lCPI0_68@PAGE
Lloh139:
	ldr	q3, [x10, lCPI0_68@PAGEOFF]
Lloh140:
	adrp	x10, lCPI0_69@PAGE
Lloh141:
	ldr	q4, [x10, lCPI0_69@PAGEOFF]
	str	q3, [sp, #14480]
	str	q4, [sp, #14464]
Lloh142:
	adrp	x10, lCPI0_70@PAGE
Lloh143:
	ldr	q3, [x10, lCPI0_70@PAGEOFF]
Lloh144:
	adrp	x10, lCPI0_71@PAGE
Lloh145:
	ldr	q4, [x10, lCPI0_71@PAGEOFF]
	str	q3, [sp, #14448]
	str	q4, [sp, #14432]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2144
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #11                         ; =0xb
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh146:
	adrp	x10, lCPI0_72@PAGE
Lloh147:
	ldr	q3, [x10, lCPI0_72@PAGEOFF]
Lloh148:
	adrp	x10, lCPI0_73@PAGE
Lloh149:
	ldr	q4, [x10, lCPI0_73@PAGEOFF]
	str	q3, [sp, #14544]
	str	q4, [sp, #14528]
Lloh150:
	adrp	x10, lCPI0_74@PAGE
Lloh151:
	ldr	q3, [x10, lCPI0_74@PAGEOFF]
Lloh152:
	adrp	x10, lCPI0_75@PAGE
Lloh153:
	ldr	q4, [x10, lCPI0_75@PAGEOFF]
	str	q3, [sp, #14512]
	str	q4, [sp, #14496]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2208
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #12                         ; =0xc
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh154:
	adrp	x10, lCPI0_76@PAGE
Lloh155:
	ldr	q3, [x10, lCPI0_76@PAGEOFF]
Lloh156:
	adrp	x10, lCPI0_77@PAGE
Lloh157:
	ldr	q4, [x10, lCPI0_77@PAGEOFF]
	str	q3, [sp, #14608]
	str	q4, [sp, #14592]
Lloh158:
	adrp	x10, lCPI0_78@PAGE
Lloh159:
	ldr	q3, [x10, lCPI0_78@PAGEOFF]
Lloh160:
	adrp	x10, lCPI0_79@PAGE
Lloh161:
	ldr	q4, [x10, lCPI0_79@PAGEOFF]
	str	q3, [sp, #14576]
	str	q4, [sp, #14560]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2272
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #13                         ; =0xd
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh162:
	adrp	x10, lCPI0_80@PAGE
Lloh163:
	ldr	q3, [x10, lCPI0_80@PAGEOFF]
Lloh164:
	adrp	x10, lCPI0_81@PAGE
Lloh165:
	ldr	q4, [x10, lCPI0_81@PAGEOFF]
	str	q3, [sp, #14672]
	str	q4, [sp, #14656]
Lloh166:
	adrp	x10, lCPI0_82@PAGE
Lloh167:
	ldr	q3, [x10, lCPI0_82@PAGEOFF]
Lloh168:
	adrp	x10, lCPI0_83@PAGE
Lloh169:
	ldr	q4, [x10, lCPI0_83@PAGEOFF]
	str	q3, [sp, #14640]
	str	q4, [sp, #14624]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2336
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #14                         ; =0xe
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh170:
	adrp	x10, lCPI0_84@PAGE
Lloh171:
	ldr	q3, [x10, lCPI0_84@PAGEOFF]
Lloh172:
	adrp	x10, lCPI0_85@PAGE
Lloh173:
	ldr	q4, [x10, lCPI0_85@PAGEOFF]
	str	q3, [sp, #14736]
	str	q4, [sp, #14720]
Lloh174:
	adrp	x10, lCPI0_86@PAGE
Lloh175:
	ldr	q3, [x10, lCPI0_86@PAGEOFF]
Lloh176:
	adrp	x10, lCPI0_87@PAGE
Lloh177:
	ldr	q4, [x10, lCPI0_87@PAGEOFF]
	str	q3, [sp, #14704]
	str	q4, [sp, #14688]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2400
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #15                         ; =0xf
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh178:
	adrp	x10, lCPI0_88@PAGE
Lloh179:
	ldr	q3, [x10, lCPI0_88@PAGEOFF]
Lloh180:
	adrp	x10, lCPI0_89@PAGE
Lloh181:
	ldr	q4, [x10, lCPI0_89@PAGEOFF]
	str	q3, [sp, #14800]
	str	q4, [sp, #14784]
Lloh182:
	adrp	x10, lCPI0_90@PAGE
Lloh183:
	ldr	q3, [x10, lCPI0_90@PAGEOFF]
Lloh184:
	adrp	x10, lCPI0_91@PAGE
Lloh185:
	ldr	q4, [x10, lCPI0_91@PAGEOFF]
	str	q3, [sp, #14768]
	str	q4, [sp, #14752]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2464
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #16                         ; =0x10
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh186:
	adrp	x10, lCPI0_92@PAGE
Lloh187:
	ldr	q3, [x10, lCPI0_92@PAGEOFF]
Lloh188:
	adrp	x10, lCPI0_93@PAGE
Lloh189:
	ldr	q4, [x10, lCPI0_93@PAGEOFF]
	str	q3, [sp, #14864]
	str	q4, [sp, #14848]
Lloh190:
	adrp	x10, lCPI0_94@PAGE
Lloh191:
	ldr	q3, [x10, lCPI0_94@PAGEOFF]
Lloh192:
	adrp	x10, lCPI0_95@PAGE
Lloh193:
	ldr	q4, [x10, lCPI0_95@PAGEOFF]
	str	q3, [sp, #14832]
	str	q4, [sp, #14816]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2528
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #17                         ; =0x11
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh194:
	adrp	x10, lCPI0_96@PAGE
Lloh195:
	ldr	q3, [x10, lCPI0_96@PAGEOFF]
Lloh196:
	adrp	x10, lCPI0_97@PAGE
Lloh197:
	ldr	q4, [x10, lCPI0_97@PAGEOFF]
	str	q3, [sp, #14928]
	str	q4, [sp, #14912]
Lloh198:
	adrp	x10, lCPI0_98@PAGE
Lloh199:
	ldr	q3, [x10, lCPI0_98@PAGEOFF]
Lloh200:
	adrp	x10, lCPI0_99@PAGE
Lloh201:
	ldr	q4, [x10, lCPI0_99@PAGEOFF]
	str	q3, [sp, #14896]
	str	q4, [sp, #14880]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2592
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #18                         ; =0x12
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh202:
	adrp	x10, lCPI0_100@PAGE
Lloh203:
	ldr	q3, [x10, lCPI0_100@PAGEOFF]
Lloh204:
	adrp	x10, lCPI0_101@PAGE
Lloh205:
	ldr	q4, [x10, lCPI0_101@PAGEOFF]
	str	q3, [sp, #14992]
	str	q4, [sp, #14976]
Lloh206:
	adrp	x10, lCPI0_102@PAGE
Lloh207:
	ldr	q3, [x10, lCPI0_102@PAGEOFF]
Lloh208:
	adrp	x10, lCPI0_103@PAGE
Lloh209:
	ldr	q4, [x10, lCPI0_103@PAGEOFF]
	str	q3, [sp, #14960]
	str	q4, [sp, #14944]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2656
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #19                         ; =0x13
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh210:
	adrp	x10, lCPI0_104@PAGE
Lloh211:
	ldr	q3, [x10, lCPI0_104@PAGEOFF]
Lloh212:
	adrp	x10, lCPI0_105@PAGE
Lloh213:
	ldr	q4, [x10, lCPI0_105@PAGEOFF]
	str	q3, [sp, #15056]
	str	q4, [sp, #15040]
Lloh214:
	adrp	x10, lCPI0_106@PAGE
Lloh215:
	ldr	q3, [x10, lCPI0_106@PAGEOFF]
Lloh216:
	adrp	x10, lCPI0_107@PAGE
Lloh217:
	ldr	q4, [x10, lCPI0_107@PAGEOFF]
	str	q3, [sp, #15024]
	str	q4, [sp, #15008]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2720
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #20                         ; =0x14
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh218:
	adrp	x10, lCPI0_108@PAGE
Lloh219:
	ldr	q3, [x10, lCPI0_108@PAGEOFF]
Lloh220:
	adrp	x10, lCPI0_109@PAGE
Lloh221:
	ldr	q4, [x10, lCPI0_109@PAGEOFF]
	str	q3, [sp, #15120]
	str	q4, [sp, #15104]
Lloh222:
	adrp	x10, lCPI0_110@PAGE
Lloh223:
	ldr	q3, [x10, lCPI0_110@PAGEOFF]
Lloh224:
	adrp	x10, lCPI0_111@PAGE
Lloh225:
	ldr	q4, [x10, lCPI0_111@PAGEOFF]
	str	q3, [sp, #15088]
	str	q4, [sp, #15072]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2784
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #21                         ; =0x15
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh226:
	adrp	x10, lCPI0_112@PAGE
Lloh227:
	ldr	q3, [x10, lCPI0_112@PAGEOFF]
Lloh228:
	adrp	x10, lCPI0_113@PAGE
Lloh229:
	ldr	q4, [x10, lCPI0_113@PAGEOFF]
	str	q3, [sp, #15184]
	str	q4, [sp, #15168]
Lloh230:
	adrp	x10, lCPI0_114@PAGE
Lloh231:
	ldr	q3, [x10, lCPI0_114@PAGEOFF]
Lloh232:
	adrp	x10, lCPI0_115@PAGE
Lloh233:
	ldr	q4, [x10, lCPI0_115@PAGEOFF]
	str	q3, [sp, #15152]
	str	q4, [sp, #15136]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2848
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #22                         ; =0x16
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh234:
	adrp	x10, lCPI0_116@PAGE
Lloh235:
	ldr	q3, [x10, lCPI0_116@PAGEOFF]
Lloh236:
	adrp	x10, lCPI0_117@PAGE
Lloh237:
	ldr	q4, [x10, lCPI0_117@PAGEOFF]
	str	q3, [sp, #15248]
	str	q4, [sp, #15232]
Lloh238:
	adrp	x10, lCPI0_118@PAGE
Lloh239:
	ldr	q3, [x10, lCPI0_118@PAGEOFF]
Lloh240:
	adrp	x10, lCPI0_119@PAGE
Lloh241:
	ldr	q4, [x10, lCPI0_119@PAGEOFF]
	str	q3, [sp, #15216]
	str	q4, [sp, #15200]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2912
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #23                         ; =0x17
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh242:
	adrp	x10, lCPI0_120@PAGE
Lloh243:
	ldr	q3, [x10, lCPI0_120@PAGEOFF]
Lloh244:
	adrp	x10, lCPI0_121@PAGE
Lloh245:
	ldr	q4, [x10, lCPI0_121@PAGEOFF]
	str	q3, [sp, #15312]
	str	q4, [sp, #15296]
Lloh246:
	adrp	x10, lCPI0_122@PAGE
Lloh247:
	ldr	q3, [x10, lCPI0_122@PAGEOFF]
Lloh248:
	adrp	x10, lCPI0_123@PAGE
Lloh249:
	ldr	q4, [x10, lCPI0_123@PAGEOFF]
	str	q3, [sp, #15280]
	str	q4, [sp, #15264]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2976
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #24                         ; =0x18
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh250:
	adrp	x10, lCPI0_124@PAGE
Lloh251:
	ldr	q3, [x10, lCPI0_124@PAGEOFF]
Lloh252:
	adrp	x10, lCPI0_125@PAGE
Lloh253:
	ldr	q4, [x10, lCPI0_125@PAGEOFF]
	str	q3, [sp, #15376]
	str	q4, [sp, #15360]
Lloh254:
	adrp	x10, lCPI0_126@PAGE
Lloh255:
	ldr	q3, [x10, lCPI0_126@PAGEOFF]
Lloh256:
	adrp	x10, lCPI0_127@PAGE
Lloh257:
	ldr	q4, [x10, lCPI0_127@PAGEOFF]
	str	q3, [sp, #15344]
	str	q4, [sp, #15328]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #3040
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #25                         ; =0x19
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh258:
	adrp	x10, lCPI0_128@PAGE
Lloh259:
	ldr	q3, [x10, lCPI0_128@PAGEOFF]
Lloh260:
	adrp	x10, lCPI0_129@PAGE
Lloh261:
	ldr	q4, [x10, lCPI0_129@PAGEOFF]
	str	q3, [sp, #15440]
	str	q4, [sp, #15424]
Lloh262:
	adrp	x10, lCPI0_130@PAGE
Lloh263:
	ldr	q3, [x10, lCPI0_130@PAGEOFF]
Lloh264:
	adrp	x10, lCPI0_131@PAGE
Lloh265:
	ldr	q4, [x10, lCPI0_131@PAGEOFF]
	str	q3, [sp, #15408]
	str	q4, [sp, #15392]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #3104
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #26                         ; =0x1a
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh266:
	adrp	x10, lCPI0_132@PAGE
Lloh267:
	ldr	q3, [x10, lCPI0_132@PAGEOFF]
Lloh268:
	adrp	x10, lCPI0_133@PAGE
Lloh269:
	ldr	q4, [x10, lCPI0_133@PAGEOFF]
	str	q3, [sp, #15504]
	str	q4, [sp, #15488]
Lloh270:
	adrp	x10, lCPI0_134@PAGE
Lloh271:
	ldr	q3, [x10, lCPI0_134@PAGEOFF]
Lloh272:
	adrp	x10, lCPI0_135@PAGE
Lloh273:
	ldr	q4, [x10, lCPI0_135@PAGEOFF]
	str	q3, [sp, #15472]
	str	q4, [sp, #15456]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #3168
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #27                         ; =0x1b
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh274:
	adrp	x10, lCPI0_136@PAGE
Lloh275:
	ldr	q3, [x10, lCPI0_136@PAGEOFF]
Lloh276:
	adrp	x10, lCPI0_137@PAGE
Lloh277:
	ldr	q4, [x10, lCPI0_137@PAGEOFF]
	str	q3, [sp, #15568]
	str	q4, [sp, #15552]
Lloh278:
	adrp	x10, lCPI0_138@PAGE
Lloh279:
	ldr	q3, [x10, lCPI0_138@PAGEOFF]
Lloh280:
	adrp	x10, lCPI0_139@PAGE
Lloh281:
	ldr	q4, [x10, lCPI0_139@PAGEOFF]
	str	q3, [sp, #15536]
	str	q4, [sp, #15520]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #3232
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #28                         ; =0x1c
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh282:
	adrp	x10, lCPI0_140@PAGE
Lloh283:
	ldr	q3, [x10, lCPI0_140@PAGEOFF]
Lloh284:
	adrp	x10, lCPI0_141@PAGE
Lloh285:
	ldr	q4, [x10, lCPI0_141@PAGEOFF]
	str	q3, [sp, #15632]
	str	q4, [sp, #15616]
Lloh286:
	adrp	x10, lCPI0_142@PAGE
Lloh287:
	ldr	q3, [x10, lCPI0_142@PAGEOFF]
Lloh288:
	adrp	x10, lCPI0_143@PAGE
Lloh289:
	ldr	q4, [x10, lCPI0_143@PAGEOFF]
	str	q3, [sp, #15600]
	str	q4, [sp, #15584]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #3296
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #29                         ; =0x1d
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh290:
	adrp	x10, lCPI0_144@PAGE
Lloh291:
	ldr	q3, [x10, lCPI0_144@PAGEOFF]
Lloh292:
	adrp	x10, lCPI0_145@PAGE
Lloh293:
	ldr	q4, [x10, lCPI0_145@PAGEOFF]
	str	q3, [sp, #15696]
	str	q4, [sp, #15680]
Lloh294:
	adrp	x10, lCPI0_146@PAGE
Lloh295:
	ldr	q3, [x10, lCPI0_146@PAGEOFF]
Lloh296:
	adrp	x10, lCPI0_147@PAGE
Lloh297:
	ldr	q4, [x10, lCPI0_147@PAGEOFF]
	str	q3, [sp, #15664]
	str	q4, [sp, #15648]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #3360
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w2, #30                         ; =0x1e
	dup.2d	v17, x2
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
	ldr	q3, [sp, #18400]
	ldr	q4, [sp, #18416]
	ldr	q5, [sp, #18368]
	ldr	q16, [sp, #18384]
	ldr	q17, [sp, #18336]
	ldr	q18, [sp, #18352]
	ldr	q19, [sp, #18304]
	ldr	q22, [sp, #18320]
	ldr	q23, [sp, #384]                 ; 16-byte Folded Reload
	bit.16b	v22, v23, v11
	bit.16b	v19, v23, v12
	bit.16b	v18, v23, v13
	bit.16b	v17, v23, v14
Lloh298:
	adrp	x10, lCPI0_17@PAGE
Lloh299:
	ldr	q23, [x10, lCPI0_17@PAGEOFF]
	bit.16b	v16, v23, v11
Lloh300:
	adrp	x10, lCPI0_16@PAGE
Lloh301:
	ldr	q23, [x10, lCPI0_16@PAGEOFF]
	bit.16b	v5, v23, v12
Lloh302:
	adrp	x10, lCPI0_19@PAGE
Lloh303:
	ldr	q23, [x10, lCPI0_19@PAGEOFF]
	bit.16b	v4, v23, v13
Lloh304:
	adrp	x10, lCPI0_18@PAGE
Lloh305:
	ldr	q23, [x10, lCPI0_18@PAGEOFF]
	bit.16b	v3, v23, v14
	str	q3, [sp, #18400]
	str	q4, [sp, #18416]
	str	q5, [sp, #18368]
	str	q16, [sp, #18384]
	str	q17, [sp, #18336]
	str	q18, [sp, #18352]
	str	q19, [sp, #18304]
	str	q22, [sp, #18320]
	ldr	q3, [sp, #1216]                 ; 16-byte Folded Reload
	bic.16b	v3, v3, v13
	str	q3, [sp, #1216]                 ; 16-byte Folded Spill
	ldr	q3, [sp, #1024]                 ; 16-byte Folded Reload
	bic.16b	v3, v3, v14
	str	q3, [sp, #1024]                 ; 16-byte Folded Spill
	ldr	q3, [sp, #1232]                 ; 16-byte Folded Reload
	bic.16b	v3, v3, v11
	str	q3, [sp, #1232]                 ; 16-byte Folded Spill
	bic.16b	v0, v0, v12
LBB0_191:                               ; %schedule.6
                                        ;   in Loop: Header=BB0_7 Depth=3
	str	q0, [sp, #816]                  ; 16-byte Folded Spill
LBB0_192:                               ; %schedule.6
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	mov	w2, #128                        ; =0x80
	dup.2d	v3, x2
	ldr	q17, [sp, #1232]                ; 16-byte Folded Reload
	cmgt.2d	v4, v3, v17
	ldr	q0, [sp, #816]                  ; 16-byte Folded Reload
	cmgt.2d	v5, v3, v0
	uzp1.4s	v4, v5, v4
	ldr	q18, [sp, #1024]                ; 16-byte Folded Reload
	cmgt.2d	v5, v3, v18
	ldr	q19, [sp, #1216]                ; 16-byte Folded Reload
	cmgt.2d	v16, v3, v19
	uzp1.4s	v5, v5, v16
	uzp1.8h	v4, v4, v5
	xtn.8b	v4, v4
	and.8b	v11, v10, v4
	shl.8b	v4, v11, #7
	cmlt.8b	v4, v4, #0
	and.8b	v5, v4, v2
	addv.8b	b5, v5
	fmov	w2, s5
	umaxv.8b	b4, v4
	fmov	w4, s4
	tbz	w4, #0, LBB0_198
; %bb.193:                              ; %schedule.6
                                        ;   in Loop: Header=BB0_7 Depth=3
	cmge.2d	v4, v17, v3
	cmge.2d	v5, v0, v3
	uzp1.4s	v4, v5, v4
	cmge.2d	v5, v18, v3
	cmge.2d	v3, v19, v3
	uzp1.4s	v3, v5, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v12, v10, v3
	shl.8b	v3, v12, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w4, s3
	tst	w4, #0xff
	b.eq	LBB0_198
; %bb.194:                              ; %varying.divergent207
                                        ;   in Loop: Header=BB0_7 Depth=3
	subs	w10, w1, #1
	csel	w10, wzr, w10, lo
	and	w3, w17, #0xff
	lsr	w2, w3, w10
	tst	w2, #0x1
	str	q9, [sp, #1952]
	str	q8, [sp, #1968]
	and	x10, x10, #0x7
	add	x2, sp, #1952
	ldr	w10, [x2, x10, lsl #2]
	ccmp	w1, #0, #4, ne
	ccmp	w10, #2, #0, ne
	cset	w2, ne
	cmp	w3, #255
	b.ne	LBB0_196
; %bb.195:                              ; %varying.divergent207
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w2, #0, LBB0_196
	b	LBB0_1006
LBB0_196:                               ; %convergence.overflow.resume210
                                        ;   in Loop: Header=BB0_7 Depth=3
	mvn	w10, w17
	rbit	w10, w10
	clz	w10, w10
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w17
	csel	w4, wzr, w10, eq
	add	x3, sp, #18, lsl #12            ; =73728
	add	x3, x3, #752
	ldrb	w10, [x3, w4, uxtw]
	and	w5, w10, #0x1
	fmov	s3, w5
	ubfx	w5, w10, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w10, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w10, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w10, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w10, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w10, #6, #1
	mov.b	v3[6], w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x5, w4, uxtw]
	and	w6, w10, #0x1
	fmov	s4, w6
	ubfx	w6, w10, #1, #1
	mov.b	v4[1], w6
	ubfx	w6, w10, #2, #1
	mov.b	v4[2], w6
	ubfx	w6, w10, #3, #1
	mov.b	v4[3], w6
	ubfx	w6, w10, #4, #1
	mov.b	v4[4], w6
	ubfx	w6, w10, #5, #1
	mov.b	v4[5], w6
	ubfx	w6, w10, #6, #1
	mov.b	v4[6], w6
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	cmp	w2, #0
	csetm	w10, ne
	dup.8b	v5, w10
	bit.8b	v3, v10, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x3, w4, uxtw]
	bic.8b	v3, v4, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w4, uxtw]
	cmp	x0, #8
	b.hs	LBB0_1006
; %bb.197:                              ; %ready.overflow.resume212
                                        ;   in Loop: Header=BB0_7 Depth=3
	str	q7, [sp, #1920]
	str	q6, [sp, #1936]
	ubfiz	x10, x4, #2, #3
	add	x3, sp, #1920
	ldr	w3, [x3, x10]
	cmp	w2, #0
	csel	w3, w1, w3, ne
	csinc	w1, w1, w4, eq
	str	q7, [sp, #1888]
	str	q6, [sp, #1904]
	add	x5, sp, #1888
	str	w3, [x5, x10]
	ldr	q6, [sp, #1904]
	ldr	q7, [sp, #1888]
	str	q9, [sp, #1856]
	str	q8, [sp, #1872]
	add	x3, sp, #1856
	ldr	w3, [x3, x10]
	mov	w5, #2                          ; =0x2
	csel	w3, w5, w3, ne
	str	q9, [sp, #1824]
	str	q8, [sp, #1840]
	add	x5, sp, #1824
	str	w3, [x5, x10]
	mov	w3, #10                         ; =0xa
	mov	w5, #7                          ; =0x7
	ldr	q8, [sp, #1840]
	ldr	q9, [sp, #1824]
	b	LBB0_938
LBB0_198:                               ; %varying.coherent208
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_254
; %bb.199:                              ; %varying.coherent.true213
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
	tst	w3, #0xff
	b.eq	LBB0_5
LBB0_200:                               ; %schedule.7
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.16b	v0, v21
	mov.16b	v21, v20
	mov.16b	v20, v15
	mov	b3, v10[0]
	mov.b	v3[4], v10[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v4, v3, #0
	ldr	q3, [sp, #816]                  ; 16-byte Folded Reload
	and.16b	v18, v4, v3
	mov	b3, v10[2]
	mov.b	v3[4], v10[3]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v5, v3, #0
	ldr	q3, [sp, #1232]                 ; 16-byte Folded Reload
	and.16b	v19, v5, v3
	mov	b3, v10[4]
	mov.b	v3[4], v10[5]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v24, v3, #0
	ldr	q3, [sp, #1024]                 ; 16-byte Folded Reload
	and.16b	v26, v24, v3
	mov	b3, v10[6]
	mov.b	v3[4], v10[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v25, v3, #0
	ldr	q3, [sp, #1216]                 ; 16-byte Folded Reload
	and.16b	v3, v25, v3
	shl.8b	v16, v10, #7
	cmlt.8b	v16, v16, #0
	and.8b	v17, v16, v2
	addv.8b	b13, v17
	fmov	w3, s13
	mov	w4, #32                         ; =0x20
	dup.2d	v27, x4
	and.16b	v17, v4, v27
	mvn.16b	v4, v4
	sub.2d	v17, v17, v4
	and.16b	v4, v5, v27
	mvn.16b	v5, v5
	sub.2d	v4, v4, v5
	and.16b	v5, v24, v27
	and.16b	v27, v25, v27
	mvn.16b	v25, v25
	sub.2d	v25, v27, v25
	mov.d	x4, v25[1]
	mov.d	x5, v3[1]
	sdiv	x5, x5, x4
	mvn.16b	v24, v24
	sub.2d	v5, v5, v24
	fmov	x6, d25
	fmov	x7, d3
	sdiv	x7, x7, x6
	mul	x6, x7, x6
	fmov	d11, x7
	mov.d	v11[1], x5
	mov.d	x7, v5[1]
	mov.d	x19, v26[1]
	sdiv	x19, x19, x7
	fmov	x20, d5
	fmov	x21, d26
	sdiv	x21, x21, x20
	mul	x20, x21, x20
	fmov	d12, x21
	mov.d	v12[1], x19
	mov.d	x21, v4[1]
	mov.d	x22, v19[1]
	sdiv	x22, x22, x21
	fmov	x23, d4
	fmov	x24, d19
	sdiv	x24, x24, x23
	mul	x23, x24, x23
	fmov	d14, x24
	mov.d	v14[1], x22
	mov.d	x24, v17[1]
	mov.d	x25, v18[1]
	fmov	x26, d17
	fmov	x27, d18
	sdiv	x27, x27, x26
	mul	x26, x27, x26
	fmov	d17, x27
	sdiv	x25, x25, x24
	mov.d	v17[1], x25
	mul	x24, x25, x24
	fmov	d4, x26
	mov.d	v4[1], x24
	mul	x21, x22, x21
	fmov	d5, x23
	mov.d	v5[1], x21
	mul	x7, x19, x7
	fmov	d24, x20
	mov.d	v24[1], x7
	mul	x4, x5, x4
	fmov	d25, x6
	mov.d	v25[1], x4
	sub.2d	v3, v3, v25
	sub.2d	v24, v26, v24
	sub.2d	v5, v19, v5
	sub.2d	v4, v18, v4
	dup.2d	v18, x16
	add.2d	v4, v4, v18
	add.2d	v5, v5, v18
	add.2d	v19, v24, v18
	add.2d	v3, v3, v18
	ldr	q18, [sp, #18432]
	ldr	q24, [sp, #18448]
	ldr	q25, [sp, #18464]
	ldr	q26, [sp, #18480]
	ldr	q27, [sp, #18544]
	ldr	q30, [sp, #18528]
	ldr	q15, [sp, #18512]
	shl.2d	v3, v3, #6
	shl.2d	v19, v19, #6
	shl.2d	v5, v5, #6
	shl.2d	v28, v4, #6
	ldr	q29, [sp, #18496]
	add.2d	v4, v26, v27
	add.2d	v31, v4, v3
	add.2d	v3, v25, v30
	add.2d	v3, v3, v19
	add.2d	v4, v24, v15
	add.2d	v4, v4, v5
	add.2d	v5, v18, v29
	add.2d	v15, v5, v28
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	tbnz	w3, #0, LBB0_239
; %bb.201:                              ; %else3919
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #1, LBB0_240
LBB0_202:                               ; %else3925
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.16b	v15, v20
	mov.16b	v20, v21
	tbnz	w3, #2, LBB0_241
LBB0_203:                               ; %else3931
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.16b	v21, v0
	tbnz	w3, #3, LBB0_242
LBB0_204:                               ; %else3937
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #4, LBB0_243
LBB0_205:                               ; %else3943
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #5, LBB0_244
LBB0_206:                               ; %else3949
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #6, LBB0_245
LBB0_207:                               ; %else3955
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w3, #7, LBB0_209
LBB0_208:                               ; %cond.load3957
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v31[1]
	ld1.d	{ v27 }[1], [x3]
LBB0_209:                               ; %else3961
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w3, #32                         ; =0x20
	dup.2d	v3, x3
	cmhi.2d	v4, v3, v19
	cmhi.2d	v5, v3, v18
	uzp1.4s	v4, v5, v4
	cmhi.2d	v5, v3, v26
	cmhi.2d	v3, v3, v27
	uzp1.4s	v3, v5, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	ldrb	w3, [x9, #2048]
	and	w4, w3, #0x1
	fmov	s4, w4
	ubfx	w4, w3, #1, #1
	mov.b	v4[1], w4
	ubfx	w4, w3, #2, #1
	mov.b	v4[2], w4
	ubfx	w4, w3, #3, #1
	mov.b	v4[3], w4
	ubfx	w4, w3, #4, #1
	mov.b	v4[4], w4
	ubfx	w4, w3, #5, #1
	mov.b	v4[5], w4
	ubfx	w4, w3, #6, #1
	mov.b	v4[6], w4
	lsr	w3, w3, #7
	mov.b	v4[7], w3
	bif.8b	v3, v4, v16
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x9, #2048]
	shl.2d	v5, v14, #5
	shl.2d	v4, v17, #5
	shl.2d	v16, v11, #5
	shl.2d	v3, v12, #5
	add.2d	v3, v26, v3
	add.2d	v16, v27, v16
	add.2d	v4, v18, v4
	add.2d	v17, v19, v5
	ldr	q5, [sp, #18208]
	ldr	q18, [sp, #18224]
	ldr	q19, [sp, #18176]
	ldr	q24, [sp, #18192]
	mov	b25, v10[2]
	mov.b	v25[4], v10[3]
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	mov	b26, v10[0]
	mov.b	v26[4], v10[1]
	bit.16b	v24, v17, v25
	ushll.2d	v25, v26, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	bit.16b	v19, v4, v25
	mov	b25, v10[6]
	mov.b	v25[4], v10[7]
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	bit.16b	v18, v16, v25
	mov	b25, v10[4]
	mov.b	v25[4], v10[5]
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	bit.16b	v5, v3, v25
	str	q5, [sp, #18208]
	str	q18, [sp, #18224]
	str	q19, [sp, #18176]
	str	q24, [sp, #18192]
	mov	w3, #128                        ; =0x80
	dup.2d	v18, x3
	cmhi.2d	v5, v18, v4
	cmhi.2d	v19, v18, v17
	uzp1.4s	v5, v5, v19
	cmhi.2d	v19, v18, v3
	cmhi.2d	v24, v18, v16
	uzp1.4s	v19, v19, v24
	uzp1.8h	v5, v5, v19
	xtn.8b	v5, v5
	and.8b	v11, v10, v5
	shl.8b	v5, v11, #7
	cmlt.8b	v5, v5, #0
	and.8b	v19, v5, v2
	addv.8b	b19, v19
	fmov	w3, s19
	umaxv.8b	b5, v5
	fmov	w4, s5
	tbz	w4, #0, LBB0_215
; %bb.210:                              ; %else3961
                                        ;   in Loop: Header=BB0_7 Depth=3
	cmhs.2d	v4, v4, v18
	cmhs.2d	v5, v17, v18
	uzp1.4s	v4, v4, v5
	cmhs.2d	v3, v3, v18
	cmhs.2d	v5, v16, v18
	uzp1.4s	v3, v3, v5
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v12, v10, v3
	shl.8b	v3, v12, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w4, s3
	tst	w4, #0xff
	b.eq	LBB0_215
; %bb.211:                              ; %varying.divergent221
                                        ;   in Loop: Header=BB0_7 Depth=3
	subs	w10, w1, #1
	csel	w10, wzr, w10, lo
	and	w3, w17, #0xff
	lsr	w2, w3, w10
	tst	w2, #0x1
	str	q9, [sp, #2112]
	str	q8, [sp, #2128]
	and	x10, x10, #0x7
	add	x2, sp, #2112
	ldr	w10, [x2, x10, lsl #2]
	ccmp	w1, #0, #4, ne
	ccmp	w10, #3, #0, ne
	cset	w2, ne
	cmp	w3, #255
	b.ne	LBB0_213
; %bb.212:                              ; %varying.divergent221
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w2, #0, LBB0_213
	b	LBB0_1006
LBB0_213:                               ; %convergence.overflow.resume224
                                        ;   in Loop: Header=BB0_7 Depth=3
	mvn	w10, w17
	rbit	w10, w10
	clz	w10, w10
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w17
	csel	w4, wzr, w10, eq
	add	x3, sp, #18, lsl #12            ; =73728
	add	x3, x3, #752
	ldrb	w10, [x3, w4, uxtw]
	and	w5, w10, #0x1
	fmov	s3, w5
	ubfx	w5, w10, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w10, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w10, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w10, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w10, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w10, #6, #1
	mov.b	v3[6], w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x5, w4, uxtw]
	and	w6, w10, #0x1
	fmov	s4, w6
	ubfx	w6, w10, #1, #1
	mov.b	v4[1], w6
	ubfx	w6, w10, #2, #1
	mov.b	v4[2], w6
	ubfx	w6, w10, #3, #1
	mov.b	v4[3], w6
	ubfx	w6, w10, #4, #1
	mov.b	v4[4], w6
	ubfx	w6, w10, #5, #1
	mov.b	v4[5], w6
	ubfx	w6, w10, #6, #1
	mov.b	v4[6], w6
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	cmp	w2, #0
	csetm	w10, ne
	dup.8b	v5, w10
	bit.8b	v3, v10, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x3, w4, uxtw]
	bic.8b	v3, v4, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w4, uxtw]
	cmp	x0, #8
	b.hs	LBB0_1006
; %bb.214:                              ; %ready.overflow.resume226
                                        ;   in Loop: Header=BB0_7 Depth=3
	zip2.8b	v3, v12, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldp	q5, q0, [sp, #480]              ; 32-byte Folded Reload
	and.16b	v4, v3, v5
	zip1.8b	v3, v12, v5
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v0, v3, v0
	stp	q4, q0, [sp, #480]              ; 32-byte Folded Spill
	str	q7, [sp, #2080]
	str	q6, [sp, #2096]
	ubfiz	x10, x4, #2, #3
	add	x3, sp, #2080
	ldr	w3, [x3, x10]
	cmp	w2, #0
	csel	w3, w1, w3, ne
	csinc	w1, w1, w4, eq
	str	q7, [sp, #2048]
	str	q6, [sp, #2064]
	add	x5, sp, #2048
	str	w3, [x5, x10]
	ldr	q6, [sp, #2064]
	ldr	q7, [sp, #2048]
	str	q9, [sp, #2016]
	str	q8, [sp, #2032]
	add	x3, sp, #2016
	ldr	w3, [x3, x10]
	mov	w5, #3                          ; =0x3
	csel	w3, w5, w3, ne
	str	q9, [sp, #1984]
	str	q8, [sp, #2000]
	add	x5, sp, #1984
	str	w3, [x5, x10]
	mov	w3, #9                          ; =0x9
	mov	w5, #8                          ; =0x8
	ldr	q8, [sp, #2000]
	ldr	q9, [sp, #1984]
	b	LBB0_938
LBB0_215:                               ; %varying.coherent222
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_253
; %bb.216:                              ; %varying.coherent.true227
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #0, LBB0_5
; %bb.217:                              ; %schedule.8.thread
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q3, [sp, #18560]
	ldr	q4, [sp, #18576]
	ldr	q5, [sp, #18592]
	ldr	q16, [sp, #18608]
	ldr	q17, [sp, #18672]
	ldr	q18, [sp, #18656]
	ldr	q19, [sp, #18640]
	ldr	q22, [sp, #18624]
	ldr	q23, [sp, #18176]
	ldr	q24, [sp, #18192]
	ldr	q25, [sp, #18208]
	ldr	q26, [sp, #18224]
	shl.2d	v26, v26, #5
	shl.2d	v25, v25, #5
	shl.2d	v24, v24, #5
	shl.2d	v23, v23, #5
	add.2d	v16, v16, v17
	add.2d	v17, v16, v26
	add.2d	v5, v5, v18
	add.2d	v18, v5, v25
	add.2d	v4, v4, v19
	add.2d	v4, v4, v24
	add.2d	v3, v3, v22
	add.2d	v19, v3, v23
	fmov	w2, s13
	movi.2d	v16, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w2, #0, LBB0_263
; %bb.218:                              ; %else5195
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #1, LBB0_264
LBB0_219:                               ; %else5201
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #2, LBB0_265
LBB0_220:                               ; %else5207
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #3, LBB0_266
LBB0_221:                               ; %else5213
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #4, LBB0_267
LBB0_222:                               ; %else5219
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #5, LBB0_268
LBB0_223:                               ; %else5225
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #6, LBB0_269
LBB0_224:                               ; %else5231
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w2, #7, LBB0_226
LBB0_225:                               ; %cond.load5233
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v17[1]
	ld1.s	{ v3 }[3], [x10]
LBB0_226:                               ; %else5237
                                        ;   in Loop: Header=BB0_7 Depth=3
	zip2.8b	v4, v10, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q0, [sp, #480]                  ; 16-byte Folded Reload
	bit.16b	v0, v3, v4
	str	q0, [sp, #480]                  ; 16-byte Folded Spill
	zip1.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q0, [sp, #496]                  ; 16-byte Folded Reload
	bit.16b	v0, v16, v3
	str	q0, [sp, #496]                  ; 16-byte Folded Spill
	cbnz	w1, LBB0_52
LBB0_227:                               ; %schedule.9.convergence.cascade.exit232_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
LBB0_228:                               ; %convergence.cascade.exit232
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
; %bb.229:                              ; %convergence.target.9.ready
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q0, [sp, #768]                  ; 16-byte Folded Reload
	dup.4s	v4, v0[0]
	ldrb	w10, [x9, #2048]
	ubfx	w2, w10, #3, #1
	ubfx	w3, w10, #2, #1
	ubfx	w4, w10, #1, #1
	and	w5, w10, #0x1
	lsr	w6, w10, #7
	ubfx	w7, w10, #6, #1
	ubfx	w19, w10, #5, #1
	ubfx	w10, w10, #4, #1
	fmov	s3, w10
	mov.h	v3[1], w19
	mov.h	v3[2], w7
	mov.h	v3[3], w6
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	fmov	s5, w5
	mov.h	v5[1], w4
	mov.h	v5[2], w3
	mov.h	v5[3], w2
	ldr	q0, [sp, #480]                  ; 16-byte Folded Reload
	bsl.16b	v3, v0, v4
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q0, [sp, #496]                  ; 16-byte Folded Reload
	mov.16b	v16, v5
	bsl.16b	v16, v0, v4
	ldr	q4, [sp, #18352]
	ldr	q5, [sp, #18336]
	ldr	q17, [sp, #18320]
	ldr	q18, [sp, #18304]
	ldr	q19, [sp, #18368]
	ldr	q22, [sp, #18384]
	ldr	q23, [sp, #18400]
	ldr	q24, [sp, #18416]
	ldr	q0, [sp, #816]                  ; 16-byte Folded Reload
	shl.2d	v25, v0, #5
	ldr	q26, [sp, #1232]                ; 16-byte Folded Reload
	shl.2d	v26, v26, #5
	ldr	q27, [sp, #1024]                ; 16-byte Folded Reload
	shl.2d	v27, v27, #5
	ldr	q28, [sp, #1216]                ; 16-byte Folded Reload
	shl.2d	v28, v28, #5
	add.2d	v24, v24, v28
	add.2d	v23, v23, v27
	add.2d	v22, v22, v26
	add.2d	v19, v19, v25
	add.2d	v19, v18, v19
	add.2d	v18, v17, v22
	add.2d	v17, v5, v23
	add.2d	v4, v4, v24
	shl.8b	v5, v10, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	fmov	w2, s5
	tbnz	w2, #0, LBB0_246
; %bb.230:                              ; %else5243
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #1, LBB0_247
LBB0_231:                               ; %else5247
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #2, LBB0_248
LBB0_232:                               ; %else5251
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #3, LBB0_249
LBB0_233:                               ; %else5255
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #4, LBB0_250
LBB0_234:                               ; %else5259
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q16, [sp, #1024]                ; 16-byte Folded Reload
	tbnz	w2, #5, LBB0_251
LBB0_235:                               ; %else5263
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #6, LBB0_252
LBB0_236:                               ; %else5267
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q5, [sp, #1232]                 ; 16-byte Folded Reload
	tbz	w2, #7, LBB0_238
LBB0_237:                               ; %cond.store5268
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v4[1]
	st1.s	{ v3 }[3], [x10]
LBB0_238:                               ; %else5271
                                        ;   in Loop: Header=BB0_7 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v10, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v4, v3, #0
	ushll2.4s	v3, v3, #0
	ldr	q17, [sp, #1216]                ; 16-byte Folded Reload
	uaddw2.2d	v17, v17, v3
	str	q17, [sp, #1216]                ; 16-byte Folded Spill
	uaddw.2d	v16, v16, v3
	str	q16, [sp, #1024]                ; 16-byte Folded Spill
	uaddw2.2d	v5, v5, v4
	str	q5, [sp, #1232]                 ; 16-byte Folded Spill
	uaddw.2d	v0, v0, v4
	b	LBB0_191
LBB0_239:                               ; %cond.load3915
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d15
	ldr	d18, [x4]
	tbz	w3, #1, LBB0_202
LBB0_240:                               ; %cond.load3921
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v15[1]
	ld1.d	{ v18 }[1], [x4]
	mov.16b	v15, v20
	mov.16b	v20, v21
	tbz	w3, #2, LBB0_203
LBB0_241:                               ; %cond.load3927
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d4
	ld1.d	{ v19 }[0], [x4]
	mov.16b	v21, v0
	tbz	w3, #3, LBB0_204
LBB0_242:                               ; %cond.load3933
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v4[1]
	ld1.d	{ v19 }[1], [x4]
	tbz	w3, #4, LBB0_205
LBB0_243:                               ; %cond.load3939
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d3
	ld1.d	{ v26 }[0], [x4]
	tbz	w3, #5, LBB0_206
LBB0_244:                               ; %cond.load3945
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v3[1]
	ld1.d	{ v26 }[1], [x4]
	tbz	w3, #6, LBB0_207
LBB0_245:                               ; %cond.load3951
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d31
	ld1.d	{ v27 }[0], [x4]
	tbnz	w3, #7, LBB0_208
	b	LBB0_209
LBB0_246:                               ; %cond.store5240
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d19
	str	s16, [x10]
	tbz	w2, #1, LBB0_231
LBB0_247:                               ; %cond.store5244
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v19[1]
	st1.s	{ v16 }[1], [x10]
	tbz	w2, #2, LBB0_232
LBB0_248:                               ; %cond.store5248
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d18
	st1.s	{ v16 }[2], [x10]
	tbz	w2, #3, LBB0_233
LBB0_249:                               ; %cond.store5252
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v18[1]
	st1.s	{ v16 }[3], [x10]
	tbz	w2, #4, LBB0_234
LBB0_250:                               ; %cond.store5256
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d17
	str	s3, [x10]
	ldr	q16, [sp, #1024]                ; 16-byte Folded Reload
	tbz	w2, #5, LBB0_235
LBB0_251:                               ; %cond.store5260
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v17[1]
	st1.s	{ v3 }[1], [x10]
	tbz	w2, #6, LBB0_236
LBB0_252:                               ; %cond.store5264
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d4
	st1.s	{ v3 }[2], [x10]
	ldr	q5, [sp, #1232]                 ; 16-byte Folded Reload
	tbnz	w2, #7, LBB0_237
	b	LBB0_238
LBB0_253:                               ; %varying.coherent.false228
                                        ;   in Loop: Header=BB0_7 Depth=3
	zip2.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldp	q5, q0, [sp, #480]              ; 32-byte Folded Reload
	and.16b	v4, v3, v5
	zip1.8b	v3, v10, v5
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v0, v3, v0
	stp	q4, q0, [sp, #480]              ; 32-byte Folded Spill
	tbz	w2, #0, LBB0_51
	b	LBB0_5
LBB0_254:                               ; %varying.coherent.false214
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
LBB0_255:                               ; %schedule.10
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q0, [sp, #784]                  ; 16-byte Folded Reload
	cbz	w1, LBB0_260
; %bb.256:                              ; %convergence.cascade256.preheader
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
LBB0_257:                               ; %convergence.cascade256
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_7 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w10, s4
	umaxv.8b	b3, v3
	fmov	w6, s3
	sub	w3, w1, #1
	tst	w10, #0xff
	csel	w4, w3, wzr, ne
	mov	w10, #1                         ; =0x1
	lsl	w5, w10, w4
	and	w10, w5, w17
	tst	w10, #0xff
	cset	w10, ne
	str	q9, [sp, #13632]
	str	q8, [sp, #13648]
	ubfiz	x3, x4, #2, #3
	add	x7, sp, #3, lsl #12             ; =12288
	add	x7, x7, #1344
	ldr	w7, [x7, x3]
	cmp	w7, #2
	cset	w7, eq
	and	w19, w10, w6
	add	x6, sp, #18, lsl #12            ; =73728
	add	x6, x6, #752
	ldrb	w10, [x6, w4, sxtw]
	and	w20, w10, #0x1
	fmov	s3, w20
	ubfx	w20, w10, #1, #1
	mov.b	v3[1], w20
	ubfx	w20, w10, #2, #1
	mov.b	v3[2], w20
	ubfx	w20, w10, #3, #1
	mov.b	v3[3], w20
	ubfx	w20, w10, #4, #1
	mov.b	v3[4], w20
	ubfx	w20, w10, #5, #1
	mov.b	v3[5], w20
	ubfx	w20, w10, #6, #1
	mov.b	v3[6], w20
	add	x20, sp, #18, lsl #12           ; =73728
	add	x20, x20, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x20, w4, sxtw]
	and	w21, w10, #0x1
	fmov	s4, w21
	ubfx	w21, w10, #1, #1
	mov.b	v4[1], w21
	ubfx	w21, w10, #2, #1
	mov.b	v4[2], w21
	ubfx	w21, w10, #3, #1
	mov.b	v4[3], w21
	ubfx	w21, w10, #4, #1
	mov.b	v4[4], w21
	ubfx	w21, w10, #5, #1
	mov.b	v4[5], w21
	ubfx	w21, w10, #6, #1
	mov.b	v4[6], w21
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	orr.8b	v5, v10, v4
	and.8b	v16, v1, v3
	eor.8b	v16, v16, v5
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	umaxv.8b	b16, v16
	fmov	w10, s16
	ands	w7, w19, w7
	csetm	w19, ne
	bics	w10, w7, w10
	csetm	w21, ne
	dup.8b	v16, w21
	bic.8b	v17, v5, v16
	dup.8b	v18, w19
	bit.8b	v4, v17, v18
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x20, w4, sxtw]
	bic.8b	v3, v3, v16
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x6, w4, sxtw]
	mov	w4, #-1                         ; =0xffffffff
	csinv	w4, w4, w5, eq
	and	w17, w4, w17
	dup.8b	v3, w7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v4, w10
	and.8b	v4, v4, v5
	str	q7, [sp, #13600]
	str	q6, [sp, #13616]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #1312
	ldr	w10, [x10, x3]
	csel	w1, w10, w1, ne
	bit.8b	v10, v4, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	cmp	w7, #1
	b.ne	LBB0_261
; %bb.258:                              ; %convergence.cascade256
                                        ;   in Loop: Header=BB0_257 Depth=4
	cmp	w1, #0
	ccmp	w2, #6, #2, ne
	b.hi	LBB0_261
; %bb.259:                              ; %convergence.cascade256
                                        ;   in Loop: Header=BB0_257 Depth=4
	add	w2, w2, #1
	tst	w3, #0xff
	b.ne	LBB0_257
	b	LBB0_261
LBB0_260:                               ; %schedule.10.convergence.cascade.exit257_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
LBB0_261:                               ; %convergence.cascade.exit257
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
; %bb.262:                              ; %convergence.target.10.ready
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q17, [sp, #18144]
	ldr	q4, [sp, #18160]
	ldr	q3, [sp, #18112]
	ldr	q5, [sp, #18128]
	ldr	q16, [sp, #18080]
	ldr	q19, [sp, #18096]
	ldr	q22, [sp, #18048]
	ldr	q23, [sp, #18064]
	mov	b18, v10[2]
	mov.b	v18[4], v10[3]
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	ldr	q28, [sp, #368]                 ; 16-byte Folded Reload
	bit.16b	v23, v28, v18
	mov	b24, v10[0]
	mov.b	v24[4], v10[1]
	ushll.2d	v24, v24, #0
	shl.2d	v24, v24, #63
	cmlt.2d	v24, v24, #0
	mov	b25, v10[6]
	mov.b	v25[4], v10[7]
	bit.16b	v22, v28, v24
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	bit.16b	v19, v28, v25
	mov	b26, v10[4]
	mov.b	v26[4], v10[5]
	ushll.2d	v26, v26, #0
	shl.2d	v26, v26, #63
	cmlt.2d	v26, v26, #0
Lloh306:
	adrp	x10, lCPI0_17@PAGE
Lloh307:
	ldr	q27, [x10, lCPI0_17@PAGEOFF]
	bit.16b	v5, v27, v18
Lloh308:
	adrp	x10, lCPI0_18@PAGE
Lloh309:
	ldr	q27, [x10, lCPI0_18@PAGEOFF]
	bit.16b	v17, v27, v26
Lloh310:
	adrp	x10, lCPI0_16@PAGE
Lloh311:
	ldr	q27, [x10, lCPI0_16@PAGEOFF]
	str	q17, [sp, #18144]
Lloh312:
	adrp	x10, lCPI0_19@PAGE
Lloh313:
	ldr	q17, [x10, lCPI0_19@PAGEOFF]
	bit.16b	v16, v28, v26
	bit.16b	v4, v17, v25
	str	q4, [sp, #18160]
	bit.16b	v3, v27, v24
	str	q3, [sp, #18112]
	str	q5, [sp, #18128]
	str	q16, [sp, #18080]
	str	q19, [sp, #18096]
	str	q22, [sp, #18048]
	str	q23, [sp, #18064]
	ldr	q3, [sp, #1488]                 ; 16-byte Folded Reload
	bic.16b	v3, v3, v25
	str	q3, [sp, #1488]                 ; 16-byte Folded Spill
	ldr	q3, [sp, #1280]                 ; 16-byte Folded Reload
	bic.16b	v3, v3, v26
	str	q3, [sp, #1280]                 ; 16-byte Folded Spill
	ldr	q3, [sp, #1296]                 ; 16-byte Folded Reload
	bic.16b	v3, v3, v18
	str	q3, [sp, #1296]                 ; 16-byte Folded Spill
	bic.16b	v0, v0, v24
	str	q0, [sp, #784]                  ; 16-byte Folded Spill
	b	LBB0_270
LBB0_263:                               ; %cond.load5191
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d19
	ldr	s16, [x10]
	tbz	w2, #1, LBB0_219
LBB0_264:                               ; %cond.load5197
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v19[1]
	ld1.s	{ v16 }[1], [x10]
	tbz	w2, #2, LBB0_220
LBB0_265:                               ; %cond.load5203
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d4
	ld1.s	{ v16 }[2], [x10]
	tbz	w2, #3, LBB0_221
LBB0_266:                               ; %cond.load5209
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v4[1]
	ld1.s	{ v16 }[3], [x10]
	tbz	w2, #4, LBB0_222
LBB0_267:                               ; %cond.load5215
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d18
	ld1.s	{ v3 }[0], [x10]
	tbz	w2, #5, LBB0_223
LBB0_268:                               ; %cond.load5221
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v18[1]
	ld1.s	{ v3 }[1], [x10]
	tbz	w2, #6, LBB0_224
LBB0_269:                               ; %cond.load5227
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d17
	ld1.s	{ v3 }[2], [x10]
	tbnz	w2, #7, LBB0_225
	b	LBB0_226
LBB0_270:                               ; %schedule.11
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	mov	w2, #128                        ; =0x80
	dup.2d	v3, x2
	ldr	q17, [sp, #1296]                ; 16-byte Folded Reload
	cmgt.2d	v4, v3, v17
	ldr	q0, [sp, #784]                  ; 16-byte Folded Reload
	cmgt.2d	v5, v3, v0
	uzp1.4s	v4, v5, v4
	ldr	q18, [sp, #1280]                ; 16-byte Folded Reload
	cmgt.2d	v5, v3, v18
	ldr	q19, [sp, #1488]                ; 16-byte Folded Reload
	cmgt.2d	v16, v3, v19
	uzp1.4s	v5, v5, v16
	uzp1.8h	v4, v4, v5
	xtn.8b	v4, v4
	and.8b	v11, v10, v4
	shl.8b	v4, v11, #7
	cmlt.8b	v4, v4, #0
	and.8b	v5, v4, v2
	addv.8b	b5, v5
	fmov	w2, s5
	umaxv.8b	b4, v4
	fmov	w4, s4
	tbz	w4, #0, LBB0_276
; %bb.271:                              ; %schedule.11
                                        ;   in Loop: Header=BB0_7 Depth=3
	cmge.2d	v4, v17, v3
	cmge.2d	v5, v0, v3
	uzp1.4s	v4, v5, v4
	cmge.2d	v5, v18, v3
	cmge.2d	v3, v19, v3
	uzp1.4s	v3, v5, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v12, v10, v3
	shl.8b	v3, v12, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w4, s3
	tst	w4, #0xff
	b.eq	LBB0_276
; %bb.272:                              ; %varying.divergent274
                                        ;   in Loop: Header=BB0_7 Depth=3
	subs	w10, w1, #1
	csel	w10, wzr, w10, lo
	and	w3, w17, #0xff
	lsr	w2, w3, w10
	tst	w2, #0x1
	str	q9, [sp, #2336]
	str	q8, [sp, #2352]
	and	x10, x10, #0x7
	add	x2, sp, #2336
	ldr	w10, [x2, x10, lsl #2]
	ccmp	w1, #0, #4, ne
	ccmp	w10, #4, #0, ne
	cset	w2, ne
	cmp	w3, #255
	b.ne	LBB0_274
; %bb.273:                              ; %varying.divergent274
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w2, #0, LBB0_274
	b	LBB0_1006
LBB0_274:                               ; %convergence.overflow.resume277
                                        ;   in Loop: Header=BB0_7 Depth=3
	mvn	w10, w17
	rbit	w10, w10
	clz	w10, w10
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w17
	csel	w4, wzr, w10, eq
	add	x3, sp, #18, lsl #12            ; =73728
	add	x3, x3, #752
	ldrb	w10, [x3, w4, uxtw]
	and	w5, w10, #0x1
	fmov	s3, w5
	ubfx	w5, w10, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w10, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w10, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w10, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w10, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w10, #6, #1
	mov.b	v3[6], w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x5, w4, uxtw]
	and	w6, w10, #0x1
	fmov	s4, w6
	ubfx	w6, w10, #1, #1
	mov.b	v4[1], w6
	ubfx	w6, w10, #2, #1
	mov.b	v4[2], w6
	ubfx	w6, w10, #3, #1
	mov.b	v4[3], w6
	ubfx	w6, w10, #4, #1
	mov.b	v4[4], w6
	ubfx	w6, w10, #5, #1
	mov.b	v4[5], w6
	ubfx	w6, w10, #6, #1
	mov.b	v4[6], w6
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	cmp	w2, #0
	csetm	w10, ne
	dup.8b	v5, w10
	bit.8b	v3, v10, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x3, w4, uxtw]
	bic.8b	v3, v4, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w4, uxtw]
	cmp	x0, #8
	b.hs	LBB0_1006
; %bb.275:                              ; %ready.overflow.resume279
                                        ;   in Loop: Header=BB0_7 Depth=3
	str	q7, [sp, #2304]
	str	q6, [sp, #2320]
	ubfiz	x10, x4, #2, #3
	add	x3, sp, #2304
	ldr	w3, [x3, x10]
	cmp	w2, #0
	csel	w3, w1, w3, ne
	csinc	w1, w1, w4, eq
	str	q7, [sp, #2272]
	str	q6, [sp, #2288]
	add	x5, sp, #2272
	str	w3, [x5, x10]
	ldr	q6, [sp, #2288]
	ldr	q7, [sp, #2272]
	str	q9, [sp, #2240]
	str	q8, [sp, #2256]
	add	x3, sp, #2240
	ldr	w3, [x3, x10]
	mov	w5, #4                          ; =0x4
	csel	w3, w5, w3, ne
	str	q9, [sp, #2208]
	str	q8, [sp, #2224]
	add	x5, sp, #2208
	str	w3, [x5, x10]
	mov	w3, #13                         ; =0xd
	mov	w5, #12                         ; =0xc
	ldr	q8, [sp, #2224]
	ldr	q9, [sp, #2208]
	b	LBB0_938
LBB0_276:                               ; %varying.coherent275
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_327
; %bb.277:                              ; %varying.coherent.true280
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
	tst	w3, #0xff
	b.eq	LBB0_5
LBB0_278:                               ; %schedule.12
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	b3, v10[0]
	mov.b	v3[4], v10[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v4, v3, #0
	ldr	q0, [sp, #784]                  ; 16-byte Folded Reload
	and.16b	v17, v4, v0
	mov	b3, v10[2]
	mov.b	v3[4], v10[3]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v5, v3, #0
	ldr	q3, [sp, #1296]                 ; 16-byte Folded Reload
	and.16b	v18, v5, v3
	mov	b3, v10[4]
	mov.b	v3[4], v10[5]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v24, v3, #0
	ldr	q3, [sp, #1280]                 ; 16-byte Folded Reload
	and.16b	v19, v24, v3
	mov	b3, v10[6]
	mov.b	v3[4], v10[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v25, v3, #0
	ldr	q3, [sp, #1488]                 ; 16-byte Folded Reload
	and.16b	v3, v25, v3
	shl.8b	v16, v10, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v2
	mov	w3, #32                         ; =0x20
	dup.2d	v27, x3
	and.16b	v26, v4, v27
	mvn.16b	v4, v4
	sub.2d	v26, v26, v4
	and.16b	v4, v5, v27
	mvn.16b	v5, v5
	sub.2d	v4, v4, v5
	and.16b	v5, v24, v27
	mvn.16b	v24, v24
	and.16b	v27, v25, v27
	mvn.16b	v25, v25
	sub.2d	v25, v27, v25
	mov.d	x3, v25[1]
	mov.d	x4, v3[1]
	sdiv	x4, x4, x3
	sub.2d	v5, v5, v24
	fmov	x5, d25
	fmov	x6, d3
	sdiv	x6, x6, x5
	mul	x5, x6, x5
	fmov	d24, x6
	mov.d	v24[1], x4
	mov.d	x6, v5[1]
	mov.d	x7, v19[1]
	sdiv	x7, x7, x6
	fmov	x19, d5
	fmov	x20, d19
	sdiv	x20, x20, x19
	mul	x19, x20, x19
	fmov	d5, x20
	mov.d	v5[1], x7
	mov.d	x20, v4[1]
	mov.d	x21, v18[1]
	sdiv	x21, x21, x20
	fmov	x22, d4
	fmov	x23, d18
	sdiv	x23, x23, x22
	mul	x22, x23, x22
	fmov	d4, x23
	mov.d	v4[1], x21
	mov.d	x23, v26[1]
	mov.d	x24, v17[1]
	fmov	x25, d26
	fmov	x26, d17
	sdiv	x26, x26, x25
	mul	x25, x26, x25
	fmov	d25, x26
	sdiv	x24, x24, x23
	mov.d	v25[1], x24
	mul	x23, x24, x23
	fmov	d26, x25
	mov.d	v26[1], x23
	mul	x20, x21, x20
	fmov	d27, x22
	mov.d	v27[1], x20
	mul	x6, x7, x6
	fmov	d28, x19
	mov.d	v28[1], x6
	mul	x3, x4, x3
	fmov	d29, x5
	mov.d	v29[1], x3
	addv.8b	b16, v16
	sub.2d	v3, v3, v29
	sub.2d	v19, v19, v28
	fmov	w3, s16
	sub.2d	v18, v18, v27
	sub.2d	v17, v17, v26
	ldr	q28, [sp, #18560]
	ldr	q29, [sp, #18576]
	ldr	q30, [sp, #18592]
	ldr	q31, [sp, #18608]
	ldr	q11, [sp, #18672]
	ldr	q12, [sp, #18656]
	ldr	q13, [sp, #18640]
	shl.2d	v25, v25, #10
	shl.2d	v4, v4, #10
	shl.2d	v5, v5, #10
	shl.2d	v24, v24, #10
	shl.2d	v17, v17, #5
	shl.2d	v26, v18, #5
	shl.2d	v19, v19, #5
	shl.2d	v3, v3, #5
	add.2d	v18, v24, v3
	add.2d	v19, v5, v19
	ldr	q5, [sp, #18624]
	add.2d	v26, v4, v26
	add.2d	v27, v25, v17
	add.2d	v3, v31, v11
	add.2d	v3, v3, v18
	add.2d	v4, v30, v12
	add.2d	v31, v4, v19
	add.2d	v4, v29, v13
	add.2d	v4, v4, v26
	add.2d	v5, v28, v5
	add.2d	v30, v5, v27
	movi.2d	v17, #0000000000000000
	movi.2d	v11, #0000000000000000
	tbnz	w3, #0, LBB0_306
; %bb.279:                              ; %else4017
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #1, LBB0_307
LBB0_280:                               ; %else4023
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #2, LBB0_308
LBB0_281:                               ; %else4029
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #3, LBB0_309
LBB0_282:                               ; %else4035
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #4, LBB0_310
LBB0_283:                               ; %else4041
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #5, LBB0_311
LBB0_284:                               ; %else4047
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #6, LBB0_312
LBB0_285:                               ; %else4053
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w3, #7, LBB0_287
LBB0_286:                               ; %cond.load4055
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v3[1]
	ld1.s	{ v11 }[3], [x3]
LBB0_287:                               ; %else4059
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q3, [sp, #18352]
	ldr	q5, [sp, #18336]
	ldr	q4, [sp, #18320]
	ldr	q24, [sp, #18304]
	ldr	q25, [sp, #18368]
	ldr	q28, [sp, #18384]
	ldr	q29, [sp, #18400]
	ldr	q30, [sp, #18416]
	add.2d	v24, v24, v25
	add.2d	v27, v24, v27
	add.2d	v4, v4, v28
	add.2d	v4, v4, v26
	add.2d	v5, v5, v29
	add.2d	v26, v5, v19
	add.2d	v3, v3, v30
	add.2d	v19, v3, v18
	fmov	w3, s16
	movi.2d	v3, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w3, #0, LBB0_313
; %bb.288:                              ; %else4066
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #1, LBB0_314
LBB0_289:                               ; %else4072
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #2, LBB0_315
LBB0_290:                               ; %else4078
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #3, LBB0_316
LBB0_291:                               ; %else4084
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #4, LBB0_317
LBB0_292:                               ; %else4090
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #5, LBB0_318
LBB0_293:                               ; %else4096
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #6, LBB0_319
LBB0_294:                               ; %else4102
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w3, #7, LBB0_296
LBB0_295:                               ; %cond.load4104
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v19[1]
	ld1.s	{ v18 }[3], [x3]
LBB0_296:                               ; %else4108
                                        ;   in Loop: Header=BB0_7 Depth=3
	fadd.4s	v17, v17, v3
	fadd.4s	v3, v11, v18
	ldr	q4, [sp, #18096]
	ldr	q5, [sp, #18080]
	ldr	q18, [sp, #18064]
	ldr	q19, [sp, #18048]
	ldr	q24, [sp, #18112]
	ldr	q25, [sp, #18128]
	ldr	q26, [sp, #18144]
	ldr	q27, [sp, #18160]
	shl.2d	v28, v0, #5
	ldr	q22, [sp, #1296]                ; 16-byte Folded Reload
	shl.2d	v29, v22, #5
	ldr	q22, [sp, #1280]                ; 16-byte Folded Reload
	shl.2d	v30, v22, #5
	ldr	q22, [sp, #1488]                ; 16-byte Folded Reload
	shl.2d	v31, v22, #5
	add.2d	v27, v27, v31
	add.2d	v30, v26, v30
	add.2d	v25, v25, v29
	add.2d	v24, v24, v28
	add.2d	v26, v19, v24
	add.2d	v19, v18, v25
	add.2d	v18, v5, v30
	add.2d	v4, v4, v27
	fmov	w3, s16
	tbnz	w3, #0, LBB0_320
; %bb.297:                              ; %else4114
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #1, LBB0_321
LBB0_298:                               ; %else4118
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q5, [sp, #1296]                 ; 16-byte Folded Reload
	ldr	q16, [sp, #1280]                ; 16-byte Folded Reload
	tbnz	w3, #2, LBB0_322
LBB0_299:                               ; %else4122
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #3, LBB0_323
LBB0_300:                               ; %else4126
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #4, LBB0_324
LBB0_301:                               ; %else4130
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #5, LBB0_325
LBB0_302:                               ; %else4134
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #6, LBB0_326
LBB0_303:                               ; %else4138
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w3, #7, LBB0_305
LBB0_304:                               ; %cond.store4139
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v4[1]
	st1.s	{ v3 }[3], [x3]
LBB0_305:                               ; %else4142
                                        ;   in Loop: Header=BB0_7 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v10, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v4, v3, #0
	ushll2.4s	v3, v3, #0
	ldr	q17, [sp, #1488]                ; 16-byte Folded Reload
	uaddw2.2d	v17, v17, v3
	str	q17, [sp, #1488]                ; 16-byte Folded Spill
	uaddw.2d	v16, v16, v3
	str	q16, [sp, #1280]                ; 16-byte Folded Spill
	uaddw2.2d	v5, v5, v4
	str	q5, [sp, #1296]                 ; 16-byte Folded Spill
	uaddw.2d	v0, v0, v4
	str	q0, [sp, #784]                  ; 16-byte Folded Spill
	tbz	w2, #0, LBB0_270
	b	LBB0_5
LBB0_306:                               ; %cond.load4013
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d30
	ldr	s17, [x4]
	tbz	w3, #1, LBB0_280
LBB0_307:                               ; %cond.load4019
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v30[1]
	ld1.s	{ v17 }[1], [x4]
	tbz	w3, #2, LBB0_281
LBB0_308:                               ; %cond.load4025
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d4
	ld1.s	{ v17 }[2], [x4]
	tbz	w3, #3, LBB0_282
LBB0_309:                               ; %cond.load4031
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v4[1]
	ld1.s	{ v17 }[3], [x4]
	tbz	w3, #4, LBB0_283
LBB0_310:                               ; %cond.load4037
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d31
	ld1.s	{ v11 }[0], [x4]
	tbz	w3, #5, LBB0_284
LBB0_311:                               ; %cond.load4043
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v31[1]
	ld1.s	{ v11 }[1], [x4]
	tbz	w3, #6, LBB0_285
LBB0_312:                               ; %cond.load4049
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d3
	ld1.s	{ v11 }[2], [x4]
	tbnz	w3, #7, LBB0_286
	b	LBB0_287
LBB0_313:                               ; %cond.load4062
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d27
	ldr	s3, [x4]
	tbz	w3, #1, LBB0_289
LBB0_314:                               ; %cond.load4068
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v27[1]
	ld1.s	{ v3 }[1], [x4]
	tbz	w3, #2, LBB0_290
LBB0_315:                               ; %cond.load4074
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d4
	ld1.s	{ v3 }[2], [x4]
	tbz	w3, #3, LBB0_291
LBB0_316:                               ; %cond.load4080
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v4[1]
	ld1.s	{ v3 }[3], [x4]
	tbz	w3, #4, LBB0_292
LBB0_317:                               ; %cond.load4086
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d26
	ld1.s	{ v18 }[0], [x4]
	tbz	w3, #5, LBB0_293
LBB0_318:                               ; %cond.load4092
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v26[1]
	ld1.s	{ v18 }[1], [x4]
	tbz	w3, #6, LBB0_294
LBB0_319:                               ; %cond.load4098
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d19
	ld1.s	{ v18 }[2], [x4]
	tbnz	w3, #7, LBB0_295
	b	LBB0_296
LBB0_320:                               ; %cond.store4111
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d26
	str	s17, [x4]
	tbz	w3, #1, LBB0_298
LBB0_321:                               ; %cond.store4115
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v26[1]
	st1.s	{ v17 }[1], [x4]
	ldr	q5, [sp, #1296]                 ; 16-byte Folded Reload
	ldr	q16, [sp, #1280]                ; 16-byte Folded Reload
	tbz	w3, #2, LBB0_299
LBB0_322:                               ; %cond.store4119
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d19
	st1.s	{ v17 }[2], [x4]
	tbz	w3, #3, LBB0_300
LBB0_323:                               ; %cond.store4123
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v19[1]
	st1.s	{ v17 }[3], [x4]
	tbz	w3, #4, LBB0_301
LBB0_324:                               ; %cond.store4127
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d18
	str	s3, [x4]
	tbz	w3, #5, LBB0_302
LBB0_325:                               ; %cond.store4131
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v18[1]
	st1.s	{ v3 }[1], [x4]
	tbz	w3, #6, LBB0_303
LBB0_326:                               ; %cond.store4135
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d4
	st1.s	{ v3 }[2], [x4]
	tbnz	w3, #7, LBB0_304
	b	LBB0_305
LBB0_327:                               ; %varying.coherent.false281
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
LBB0_328:                               ; %schedule.13
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q0, [sp, #832]                  ; 16-byte Folded Reload
	cbz	w1, LBB0_333
; %bb.329:                              ; %convergence.cascade289.preheader
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
LBB0_330:                               ; %convergence.cascade289
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_7 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w10, s4
	umaxv.8b	b3, v3
	fmov	w6, s3
	sub	w3, w1, #1
	tst	w10, #0xff
	csel	w4, w3, wzr, ne
	mov	w10, #1                         ; =0x1
	lsl	w5, w10, w4
	and	w10, w5, w17
	tst	w10, #0xff
	cset	w10, ne
	str	q9, [sp, #13568]
	str	q8, [sp, #13584]
	ubfiz	x3, x4, #2, #3
	add	x7, sp, #3, lsl #12             ; =12288
	add	x7, x7, #1280
	ldr	w7, [x7, x3]
	cmp	w7, #4
	cset	w7, eq
	and	w19, w10, w6
	add	x6, sp, #18, lsl #12            ; =73728
	add	x6, x6, #752
	ldrb	w10, [x6, w4, sxtw]
	and	w20, w10, #0x1
	fmov	s3, w20
	ubfx	w20, w10, #1, #1
	mov.b	v3[1], w20
	ubfx	w20, w10, #2, #1
	mov.b	v3[2], w20
	ubfx	w20, w10, #3, #1
	mov.b	v3[3], w20
	ubfx	w20, w10, #4, #1
	mov.b	v3[4], w20
	ubfx	w20, w10, #5, #1
	mov.b	v3[5], w20
	ubfx	w20, w10, #6, #1
	mov.b	v3[6], w20
	add	x20, sp, #18, lsl #12           ; =73728
	add	x20, x20, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x20, w4, sxtw]
	and	w21, w10, #0x1
	fmov	s4, w21
	ubfx	w21, w10, #1, #1
	mov.b	v4[1], w21
	ubfx	w21, w10, #2, #1
	mov.b	v4[2], w21
	ubfx	w21, w10, #3, #1
	mov.b	v4[3], w21
	ubfx	w21, w10, #4, #1
	mov.b	v4[4], w21
	ubfx	w21, w10, #5, #1
	mov.b	v4[5], w21
	ubfx	w21, w10, #6, #1
	mov.b	v4[6], w21
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	orr.8b	v5, v10, v4
	and.8b	v16, v1, v3
	eor.8b	v16, v16, v5
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	umaxv.8b	b16, v16
	fmov	w10, s16
	ands	w7, w19, w7
	csetm	w19, ne
	bics	w10, w7, w10
	csetm	w21, ne
	dup.8b	v16, w21
	bic.8b	v17, v5, v16
	dup.8b	v18, w19
	bit.8b	v4, v17, v18
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x20, w4, sxtw]
	bic.8b	v3, v3, v16
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x6, w4, sxtw]
	mov	w4, #-1                         ; =0xffffffff
	csinv	w4, w4, w5, eq
	and	w17, w4, w17
	dup.8b	v3, w7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v4, w10
	and.8b	v4, v4, v5
	str	q7, [sp, #13536]
	str	q6, [sp, #13552]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #1248
	ldr	w10, [x10, x3]
	csel	w1, w10, w1, ne
	bit.8b	v10, v4, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	cmp	w7, #1
	b.ne	LBB0_334
; %bb.331:                              ; %convergence.cascade289
                                        ;   in Loop: Header=BB0_330 Depth=4
	cmp	w1, #0
	ccmp	w2, #6, #2, ne
	b.hi	LBB0_334
; %bb.332:                              ; %convergence.cascade289
                                        ;   in Loop: Header=BB0_330 Depth=4
	add	w2, w2, #1
	tst	w3, #0xff
	b.ne	LBB0_330
	b	LBB0_334
LBB0_333:                               ; %schedule.13.convergence.cascade.exit290_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
LBB0_334:                               ; %convergence.cascade.exit290
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
; %bb.335:                              ; %convergence.target.13.ready
                                        ;   in Loop: Header=BB0_7 Depth=3
	rbit	w10, w3
	clz	w2, w10
	ldr	q3, [sp, #18016]
	ldr	q4, [sp, #18032]
	ldr	q5, [sp, #17984]
	ldr	q16, [sp, #18000]
	ldr	q17, [sp, #17952]
	ldr	q18, [sp, #17968]
	ldr	q19, [sp, #17920]
	ldr	q22, [sp, #17936]
	mov	b23, v10[2]
	mov.b	v23[4], v10[3]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v11, v23, #0
	mov	b23, v10[0]
	mov.b	v23[4], v10[1]
	ldr	q24, [sp, #352]                 ; 16-byte Folded Reload
	bit.16b	v22, v24, v11
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v12, v23, #0
	bit.16b	v19, v24, v12
	mov	b23, v10[6]
	mov.b	v23[4], v10[7]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v13, v23, #0
	bit.16b	v18, v24, v13
	mov	b23, v10[4]
	mov.b	v23[4], v10[5]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v14, v23, #0
	bit.16b	v17, v24, v14
Lloh314:
	adrp	x10, lCPI0_20@PAGE
Lloh315:
	ldr	q23, [x10, lCPI0_20@PAGEOFF]
	bit.16b	v16, v23, v11
Lloh316:
	adrp	x10, lCPI0_21@PAGE
Lloh317:
	ldr	q24, [x10, lCPI0_21@PAGEOFF]
	bit.16b	v5, v24, v12
Lloh318:
	adrp	x10, lCPI0_22@PAGE
Lloh319:
	ldr	q25, [x10, lCPI0_22@PAGEOFF]
	bit.16b	v4, v25, v13
Lloh320:
	adrp	x10, lCPI0_23@PAGE
Lloh321:
	ldr	q26, [x10, lCPI0_23@PAGEOFF]
	bit.16b	v3, v26, v14
	str	q3, [sp, #18016]
	str	q4, [sp, #18032]
	str	q5, [sp, #17984]
	str	q16, [sp, #18000]
	str	q17, [sp, #17952]
	str	q18, [sp, #17968]
	str	q19, [sp, #17920]
	str	q22, [sp, #17936]
	str	q25, [sp, #11536]
	str	q26, [sp, #11520]
	str	q23, [sp, #11504]
	str	q24, [sp, #11488]
	lsl	w10, w2, #3
	and	x2, x10, #0x38
	add	x3, sp, #2, lsl #12             ; =8192
	add	x3, x3, #3296
	ldr	x5, [x3, x2]
	and	x3, x10, #0xf8
	add	x4, sp, #14, lsl #12            ; =57344
	add	x4, x4, #616
	sub	x10, x5, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10, #32]
	ldp	q5, q16, [x10]
	mov	x5, #-2                         ; =0xfffffffffffffffe
	dup.2d	v17, x5
	bit.16b	v16, v17, v11
	bit.16b	v5, v17, v12
	bit.16b	v4, v17, v13
	bit.16b	v3, v17, v14
	stp	q3, q4, [x10, #32]
	stp	q5, q16, [x10]
Lloh322:
	adrp	x10, lCPI0_24@PAGE
Lloh323:
	ldr	q3, [x10, lCPI0_24@PAGEOFF]
Lloh324:
	adrp	x10, lCPI0_25@PAGE
Lloh325:
	ldr	q4, [x10, lCPI0_25@PAGEOFF]
	str	q3, [sp, #11600]
	str	q4, [sp, #11584]
Lloh326:
	adrp	x10, lCPI0_26@PAGE
Lloh327:
	ldr	q3, [x10, lCPI0_26@PAGEOFF]
Lloh328:
	adrp	x10, lCPI0_27@PAGE
Lloh329:
	ldr	q4, [x10, lCPI0_27@PAGEOFF]
	str	q3, [sp, #11568]
	str	q4, [sp, #11552]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #3360
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	orr.16b	v16, v14, v16
	orr.16b	v4, v11, v4
	orr.16b	v3, v12, v3
	orr.16b	v5, v13, v5
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh330:
	adrp	x10, lCPI0_28@PAGE
Lloh331:
	ldr	q3, [x10, lCPI0_28@PAGEOFF]
Lloh332:
	adrp	x10, lCPI0_29@PAGE
Lloh333:
	ldr	q4, [x10, lCPI0_29@PAGEOFF]
	str	q3, [sp, #11664]
	str	q4, [sp, #11648]
Lloh334:
	adrp	x10, lCPI0_30@PAGE
Lloh335:
	ldr	q3, [x10, lCPI0_30@PAGEOFF]
Lloh336:
	adrp	x10, lCPI0_31@PAGE
Lloh337:
	ldr	q4, [x10, lCPI0_31@PAGEOFF]
	str	q3, [sp, #11632]
	str	q4, [sp, #11616]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #3424
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	bic.16b	v16, v16, v14
	bic.16b	v4, v4, v11
	bic.16b	v3, v3, v12
	bic.16b	v5, v5, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh338:
	adrp	x10, lCPI0_32@PAGE
Lloh339:
	ldr	q3, [x10, lCPI0_32@PAGEOFF]
Lloh340:
	adrp	x10, lCPI0_33@PAGE
Lloh341:
	ldr	q4, [x10, lCPI0_33@PAGEOFF]
	str	q3, [sp, #11728]
	str	q4, [sp, #11712]
Lloh342:
	adrp	x10, lCPI0_34@PAGE
Lloh343:
	ldr	q3, [x10, lCPI0_34@PAGEOFF]
Lloh344:
	adrp	x10, lCPI0_35@PAGE
Lloh345:
	ldr	q4, [x10, lCPI0_35@PAGEOFF]
	str	q3, [sp, #11696]
	str	q4, [sp, #11680]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #3488
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	bic.16b	v16, v16, v14
	sub.2d	v16, v16, v14
	bic.16b	v4, v4, v11
	sub.2d	v4, v4, v11
	bic.16b	v3, v3, v12
	sub.2d	v3, v3, v12
	bic.16b	v5, v5, v13
	sub.2d	v5, v5, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh346:
	adrp	x10, lCPI0_36@PAGE
Lloh347:
	ldr	q3, [x10, lCPI0_36@PAGEOFF]
Lloh348:
	adrp	x10, lCPI0_37@PAGE
Lloh349:
	ldr	q4, [x10, lCPI0_37@PAGEOFF]
	str	q3, [sp, #11792]
	str	q4, [sp, #11776]
Lloh350:
	adrp	x10, lCPI0_38@PAGE
Lloh351:
	ldr	q3, [x10, lCPI0_38@PAGEOFF]
Lloh352:
	adrp	x10, lCPI0_39@PAGE
Lloh353:
	ldr	q4, [x10, lCPI0_39@PAGEOFF]
	str	q3, [sp, #11760]
	str	q4, [sp, #11744]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #3552
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #2                          ; =0x2
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh354:
	adrp	x10, lCPI0_40@PAGE
Lloh355:
	ldr	q3, [x10, lCPI0_40@PAGEOFF]
Lloh356:
	adrp	x10, lCPI0_41@PAGE
Lloh357:
	ldr	q4, [x10, lCPI0_41@PAGEOFF]
	str	q3, [sp, #11856]
	str	q4, [sp, #11840]
Lloh358:
	adrp	x10, lCPI0_42@PAGE
Lloh359:
	ldr	q3, [x10, lCPI0_42@PAGEOFF]
Lloh360:
	adrp	x10, lCPI0_43@PAGE
Lloh361:
	ldr	q4, [x10, lCPI0_43@PAGEOFF]
	str	q3, [sp, #11824]
	str	q4, [sp, #11808]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #3616
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #3                          ; =0x3
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh362:
	adrp	x10, lCPI0_44@PAGE
Lloh363:
	ldr	q3, [x10, lCPI0_44@PAGEOFF]
Lloh364:
	adrp	x10, lCPI0_45@PAGE
Lloh365:
	ldr	q4, [x10, lCPI0_45@PAGEOFF]
	str	q3, [sp, #11920]
	str	q4, [sp, #11904]
Lloh366:
	adrp	x10, lCPI0_46@PAGE
Lloh367:
	ldr	q3, [x10, lCPI0_46@PAGEOFF]
Lloh368:
	adrp	x10, lCPI0_47@PAGE
Lloh369:
	ldr	q4, [x10, lCPI0_47@PAGEOFF]
	str	q3, [sp, #11888]
	str	q4, [sp, #11872]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #3680
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #4                          ; =0x4
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh370:
	adrp	x10, lCPI0_48@PAGE
Lloh371:
	ldr	q3, [x10, lCPI0_48@PAGEOFF]
Lloh372:
	adrp	x10, lCPI0_49@PAGE
Lloh373:
	ldr	q4, [x10, lCPI0_49@PAGEOFF]
	str	q3, [sp, #11984]
	str	q4, [sp, #11968]
Lloh374:
	adrp	x10, lCPI0_50@PAGE
Lloh375:
	ldr	q3, [x10, lCPI0_50@PAGEOFF]
Lloh376:
	adrp	x10, lCPI0_51@PAGE
Lloh377:
	ldr	q4, [x10, lCPI0_51@PAGEOFF]
	str	q3, [sp, #11952]
	str	q4, [sp, #11936]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #3744
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #5                          ; =0x5
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh378:
	adrp	x10, lCPI0_52@PAGE
Lloh379:
	ldr	q3, [x10, lCPI0_52@PAGEOFF]
Lloh380:
	adrp	x10, lCPI0_53@PAGE
Lloh381:
	ldr	q4, [x10, lCPI0_53@PAGEOFF]
	str	q3, [sp, #12048]
	str	q4, [sp, #12032]
Lloh382:
	adrp	x10, lCPI0_54@PAGE
Lloh383:
	ldr	q3, [x10, lCPI0_54@PAGEOFF]
Lloh384:
	adrp	x10, lCPI0_55@PAGE
Lloh385:
	ldr	q4, [x10, lCPI0_55@PAGEOFF]
	str	q3, [sp, #12016]
	str	q4, [sp, #12000]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #3808
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #6                          ; =0x6
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh386:
	adrp	x10, lCPI0_56@PAGE
Lloh387:
	ldr	q3, [x10, lCPI0_56@PAGEOFF]
Lloh388:
	adrp	x10, lCPI0_57@PAGE
Lloh389:
	ldr	q4, [x10, lCPI0_57@PAGEOFF]
	str	q3, [sp, #12112]
	str	q4, [sp, #12096]
Lloh390:
	adrp	x10, lCPI0_58@PAGE
Lloh391:
	ldr	q3, [x10, lCPI0_58@PAGEOFF]
Lloh392:
	adrp	x10, lCPI0_59@PAGE
Lloh393:
	ldr	q4, [x10, lCPI0_59@PAGEOFF]
	str	q3, [sp, #12080]
	str	q4, [sp, #12064]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #3872
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #7                          ; =0x7
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh394:
	adrp	x10, lCPI0_60@PAGE
Lloh395:
	ldr	q3, [x10, lCPI0_60@PAGEOFF]
Lloh396:
	adrp	x10, lCPI0_61@PAGE
Lloh397:
	ldr	q4, [x10, lCPI0_61@PAGEOFF]
	str	q3, [sp, #12176]
	str	q4, [sp, #12160]
Lloh398:
	adrp	x10, lCPI0_62@PAGE
Lloh399:
	ldr	q3, [x10, lCPI0_62@PAGEOFF]
Lloh400:
	adrp	x10, lCPI0_63@PAGE
Lloh401:
	ldr	q4, [x10, lCPI0_63@PAGEOFF]
	str	q3, [sp, #12144]
	str	q4, [sp, #12128]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #3936
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #8                          ; =0x8
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh402:
	adrp	x10, lCPI0_64@PAGE
Lloh403:
	ldr	q3, [x10, lCPI0_64@PAGEOFF]
Lloh404:
	adrp	x10, lCPI0_65@PAGE
Lloh405:
	ldr	q4, [x10, lCPI0_65@PAGEOFF]
	str	q3, [sp, #12240]
	str	q4, [sp, #12224]
Lloh406:
	adrp	x10, lCPI0_66@PAGE
Lloh407:
	ldr	q3, [x10, lCPI0_66@PAGEOFF]
Lloh408:
	adrp	x10, lCPI0_67@PAGE
Lloh409:
	ldr	q4, [x10, lCPI0_67@PAGEOFF]
	str	q3, [sp, #12208]
	str	q4, [sp, #12192]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #4000
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #9                          ; =0x9
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh410:
	adrp	x10, lCPI0_68@PAGE
Lloh411:
	ldr	q3, [x10, lCPI0_68@PAGEOFF]
Lloh412:
	adrp	x10, lCPI0_69@PAGE
Lloh413:
	ldr	q4, [x10, lCPI0_69@PAGEOFF]
	str	q3, [sp, #12304]
	str	q4, [sp, #12288]
Lloh414:
	adrp	x10, lCPI0_70@PAGE
Lloh415:
	ldr	q3, [x10, lCPI0_70@PAGEOFF]
Lloh416:
	adrp	x10, lCPI0_71@PAGE
Lloh417:
	ldr	q4, [x10, lCPI0_71@PAGEOFF]
	str	q3, [sp, #12272]
	str	q4, [sp, #12256]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #4064
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #10                         ; =0xa
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh418:
	adrp	x10, lCPI0_72@PAGE
Lloh419:
	ldr	q3, [x10, lCPI0_72@PAGEOFF]
Lloh420:
	adrp	x10, lCPI0_73@PAGE
Lloh421:
	ldr	q4, [x10, lCPI0_73@PAGEOFF]
	str	q3, [sp, #12368]
	str	q4, [sp, #12352]
Lloh422:
	adrp	x10, lCPI0_74@PAGE
Lloh423:
	ldr	q3, [x10, lCPI0_74@PAGEOFF]
Lloh424:
	adrp	x10, lCPI0_75@PAGE
Lloh425:
	ldr	q4, [x10, lCPI0_75@PAGEOFF]
	str	q3, [sp, #12336]
	str	q4, [sp, #12320]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #32
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #11                         ; =0xb
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh426:
	adrp	x10, lCPI0_76@PAGE
Lloh427:
	ldr	q3, [x10, lCPI0_76@PAGEOFF]
Lloh428:
	adrp	x10, lCPI0_77@PAGE
Lloh429:
	ldr	q4, [x10, lCPI0_77@PAGEOFF]
	str	q3, [sp, #12432]
	str	q4, [sp, #12416]
Lloh430:
	adrp	x10, lCPI0_78@PAGE
Lloh431:
	ldr	q3, [x10, lCPI0_78@PAGEOFF]
Lloh432:
	adrp	x10, lCPI0_79@PAGE
Lloh433:
	ldr	q4, [x10, lCPI0_79@PAGEOFF]
	str	q3, [sp, #12400]
	str	q4, [sp, #12384]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #96
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #12                         ; =0xc
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh434:
	adrp	x10, lCPI0_80@PAGE
Lloh435:
	ldr	q3, [x10, lCPI0_80@PAGEOFF]
Lloh436:
	adrp	x10, lCPI0_81@PAGE
Lloh437:
	ldr	q4, [x10, lCPI0_81@PAGEOFF]
	str	q3, [sp, #12496]
	str	q4, [sp, #12480]
Lloh438:
	adrp	x10, lCPI0_82@PAGE
Lloh439:
	ldr	q3, [x10, lCPI0_82@PAGEOFF]
Lloh440:
	adrp	x10, lCPI0_83@PAGE
Lloh441:
	ldr	q4, [x10, lCPI0_83@PAGEOFF]
	str	q3, [sp, #12464]
	str	q4, [sp, #12448]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #160
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #13                         ; =0xd
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh442:
	adrp	x10, lCPI0_84@PAGE
Lloh443:
	ldr	q3, [x10, lCPI0_84@PAGEOFF]
Lloh444:
	adrp	x10, lCPI0_85@PAGE
Lloh445:
	ldr	q4, [x10, lCPI0_85@PAGEOFF]
	str	q3, [sp, #12560]
	str	q4, [sp, #12544]
Lloh446:
	adrp	x10, lCPI0_86@PAGE
Lloh447:
	ldr	q3, [x10, lCPI0_86@PAGEOFF]
Lloh448:
	adrp	x10, lCPI0_87@PAGE
Lloh449:
	ldr	q4, [x10, lCPI0_87@PAGEOFF]
	str	q3, [sp, #12528]
	str	q4, [sp, #12512]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #224
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #14                         ; =0xe
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh450:
	adrp	x10, lCPI0_88@PAGE
Lloh451:
	ldr	q3, [x10, lCPI0_88@PAGEOFF]
Lloh452:
	adrp	x10, lCPI0_89@PAGE
Lloh453:
	ldr	q4, [x10, lCPI0_89@PAGEOFF]
	str	q3, [sp, #12624]
	str	q4, [sp, #12608]
Lloh454:
	adrp	x10, lCPI0_90@PAGE
Lloh455:
	ldr	q3, [x10, lCPI0_90@PAGEOFF]
Lloh456:
	adrp	x10, lCPI0_91@PAGE
Lloh457:
	ldr	q4, [x10, lCPI0_91@PAGEOFF]
	str	q3, [sp, #12592]
	str	q4, [sp, #12576]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #288
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #15                         ; =0xf
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh458:
	adrp	x10, lCPI0_92@PAGE
Lloh459:
	ldr	q3, [x10, lCPI0_92@PAGEOFF]
Lloh460:
	adrp	x10, lCPI0_93@PAGE
Lloh461:
	ldr	q4, [x10, lCPI0_93@PAGEOFF]
	str	q3, [sp, #12688]
	str	q4, [sp, #12672]
Lloh462:
	adrp	x10, lCPI0_94@PAGE
Lloh463:
	ldr	q3, [x10, lCPI0_94@PAGEOFF]
Lloh464:
	adrp	x10, lCPI0_95@PAGE
Lloh465:
	ldr	q4, [x10, lCPI0_95@PAGEOFF]
	str	q3, [sp, #12656]
	str	q4, [sp, #12640]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #352
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #16                         ; =0x10
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh466:
	adrp	x10, lCPI0_96@PAGE
Lloh467:
	ldr	q3, [x10, lCPI0_96@PAGEOFF]
Lloh468:
	adrp	x10, lCPI0_97@PAGE
Lloh469:
	ldr	q4, [x10, lCPI0_97@PAGEOFF]
	str	q3, [sp, #12752]
	str	q4, [sp, #12736]
Lloh470:
	adrp	x10, lCPI0_98@PAGE
Lloh471:
	ldr	q3, [x10, lCPI0_98@PAGEOFF]
Lloh472:
	adrp	x10, lCPI0_99@PAGE
Lloh473:
	ldr	q4, [x10, lCPI0_99@PAGEOFF]
	str	q3, [sp, #12720]
	str	q4, [sp, #12704]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #416
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #17                         ; =0x11
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh474:
	adrp	x10, lCPI0_100@PAGE
Lloh475:
	ldr	q3, [x10, lCPI0_100@PAGEOFF]
Lloh476:
	adrp	x10, lCPI0_101@PAGE
Lloh477:
	ldr	q4, [x10, lCPI0_101@PAGEOFF]
	str	q3, [sp, #12816]
	str	q4, [sp, #12800]
Lloh478:
	adrp	x10, lCPI0_102@PAGE
Lloh479:
	ldr	q3, [x10, lCPI0_102@PAGEOFF]
Lloh480:
	adrp	x10, lCPI0_103@PAGE
Lloh481:
	ldr	q4, [x10, lCPI0_103@PAGEOFF]
	str	q3, [sp, #12784]
	str	q4, [sp, #12768]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #480
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #18                         ; =0x12
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh482:
	adrp	x10, lCPI0_104@PAGE
Lloh483:
	ldr	q3, [x10, lCPI0_104@PAGEOFF]
Lloh484:
	adrp	x10, lCPI0_105@PAGE
Lloh485:
	ldr	q4, [x10, lCPI0_105@PAGEOFF]
	str	q3, [sp, #12880]
	str	q4, [sp, #12864]
Lloh486:
	adrp	x10, lCPI0_106@PAGE
Lloh487:
	ldr	q3, [x10, lCPI0_106@PAGEOFF]
Lloh488:
	adrp	x10, lCPI0_107@PAGE
Lloh489:
	ldr	q4, [x10, lCPI0_107@PAGEOFF]
	str	q3, [sp, #12848]
	str	q4, [sp, #12832]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #544
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #19                         ; =0x13
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh490:
	adrp	x10, lCPI0_108@PAGE
Lloh491:
	ldr	q3, [x10, lCPI0_108@PAGEOFF]
Lloh492:
	adrp	x10, lCPI0_109@PAGE
Lloh493:
	ldr	q4, [x10, lCPI0_109@PAGEOFF]
	str	q3, [sp, #12944]
	str	q4, [sp, #12928]
Lloh494:
	adrp	x10, lCPI0_110@PAGE
Lloh495:
	ldr	q3, [x10, lCPI0_110@PAGEOFF]
Lloh496:
	adrp	x10, lCPI0_111@PAGE
Lloh497:
	ldr	q4, [x10, lCPI0_111@PAGEOFF]
	str	q3, [sp, #12912]
	str	q4, [sp, #12896]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #608
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #20                         ; =0x14
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh498:
	adrp	x10, lCPI0_112@PAGE
Lloh499:
	ldr	q3, [x10, lCPI0_112@PAGEOFF]
Lloh500:
	adrp	x10, lCPI0_113@PAGE
Lloh501:
	ldr	q4, [x10, lCPI0_113@PAGEOFF]
	str	q3, [sp, #13008]
	str	q4, [sp, #12992]
Lloh502:
	adrp	x10, lCPI0_114@PAGE
Lloh503:
	ldr	q3, [x10, lCPI0_114@PAGEOFF]
Lloh504:
	adrp	x10, lCPI0_115@PAGE
Lloh505:
	ldr	q4, [x10, lCPI0_115@PAGEOFF]
	str	q3, [sp, #12976]
	str	q4, [sp, #12960]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #672
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #21                         ; =0x15
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh506:
	adrp	x10, lCPI0_116@PAGE
Lloh507:
	ldr	q3, [x10, lCPI0_116@PAGEOFF]
Lloh508:
	adrp	x10, lCPI0_117@PAGE
Lloh509:
	ldr	q4, [x10, lCPI0_117@PAGEOFF]
	str	q3, [sp, #13072]
	str	q4, [sp, #13056]
Lloh510:
	adrp	x10, lCPI0_118@PAGE
Lloh511:
	ldr	q3, [x10, lCPI0_118@PAGEOFF]
Lloh512:
	adrp	x10, lCPI0_119@PAGE
Lloh513:
	ldr	q4, [x10, lCPI0_119@PAGEOFF]
	str	q3, [sp, #13040]
	str	q4, [sp, #13024]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #736
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #22                         ; =0x16
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh514:
	adrp	x10, lCPI0_120@PAGE
Lloh515:
	ldr	q3, [x10, lCPI0_120@PAGEOFF]
Lloh516:
	adrp	x10, lCPI0_121@PAGE
Lloh517:
	ldr	q4, [x10, lCPI0_121@PAGEOFF]
	str	q3, [sp, #13136]
	str	q4, [sp, #13120]
Lloh518:
	adrp	x10, lCPI0_122@PAGE
Lloh519:
	ldr	q3, [x10, lCPI0_122@PAGEOFF]
Lloh520:
	adrp	x10, lCPI0_123@PAGE
Lloh521:
	ldr	q4, [x10, lCPI0_123@PAGEOFF]
	str	q3, [sp, #13104]
	str	q4, [sp, #13088]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #800
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #23                         ; =0x17
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh522:
	adrp	x10, lCPI0_124@PAGE
Lloh523:
	ldr	q3, [x10, lCPI0_124@PAGEOFF]
Lloh524:
	adrp	x10, lCPI0_125@PAGE
Lloh525:
	ldr	q4, [x10, lCPI0_125@PAGEOFF]
	str	q3, [sp, #13200]
	str	q4, [sp, #13184]
Lloh526:
	adrp	x10, lCPI0_126@PAGE
Lloh527:
	ldr	q3, [x10, lCPI0_126@PAGEOFF]
Lloh528:
	adrp	x10, lCPI0_127@PAGE
Lloh529:
	ldr	q4, [x10, lCPI0_127@PAGEOFF]
	str	q3, [sp, #13168]
	str	q4, [sp, #13152]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #864
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #24                         ; =0x18
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh530:
	adrp	x10, lCPI0_128@PAGE
Lloh531:
	ldr	q3, [x10, lCPI0_128@PAGEOFF]
Lloh532:
	adrp	x10, lCPI0_129@PAGE
Lloh533:
	ldr	q4, [x10, lCPI0_129@PAGEOFF]
	str	q3, [sp, #13264]
	str	q4, [sp, #13248]
Lloh534:
	adrp	x10, lCPI0_130@PAGE
Lloh535:
	ldr	q3, [x10, lCPI0_130@PAGEOFF]
Lloh536:
	adrp	x10, lCPI0_131@PAGE
Lloh537:
	ldr	q4, [x10, lCPI0_131@PAGEOFF]
	str	q3, [sp, #13232]
	str	q4, [sp, #13216]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #928
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #25                         ; =0x19
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh538:
	adrp	x10, lCPI0_132@PAGE
Lloh539:
	ldr	q3, [x10, lCPI0_132@PAGEOFF]
Lloh540:
	adrp	x10, lCPI0_133@PAGE
Lloh541:
	ldr	q4, [x10, lCPI0_133@PAGEOFF]
	str	q3, [sp, #13328]
	str	q4, [sp, #13312]
Lloh542:
	adrp	x10, lCPI0_134@PAGE
Lloh543:
	ldr	q3, [x10, lCPI0_134@PAGEOFF]
Lloh544:
	adrp	x10, lCPI0_135@PAGE
Lloh545:
	ldr	q4, [x10, lCPI0_135@PAGEOFF]
	str	q3, [sp, #13296]
	str	q4, [sp, #13280]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #992
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #26                         ; =0x1a
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh546:
	adrp	x10, lCPI0_136@PAGE
Lloh547:
	ldr	q3, [x10, lCPI0_136@PAGEOFF]
Lloh548:
	adrp	x10, lCPI0_137@PAGE
Lloh549:
	ldr	q4, [x10, lCPI0_137@PAGEOFF]
	str	q3, [sp, #13392]
	str	q4, [sp, #13376]
Lloh550:
	adrp	x10, lCPI0_138@PAGE
Lloh551:
	ldr	q3, [x10, lCPI0_138@PAGEOFF]
Lloh552:
	adrp	x10, lCPI0_139@PAGE
Lloh553:
	ldr	q4, [x10, lCPI0_139@PAGEOFF]
	str	q3, [sp, #13360]
	str	q4, [sp, #13344]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #1056
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #27                         ; =0x1b
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh554:
	adrp	x10, lCPI0_140@PAGE
Lloh555:
	ldr	q3, [x10, lCPI0_140@PAGEOFF]
Lloh556:
	adrp	x10, lCPI0_141@PAGE
Lloh557:
	ldr	q4, [x10, lCPI0_141@PAGEOFF]
	str	q3, [sp, #13456]
	str	q4, [sp, #13440]
Lloh558:
	adrp	x10, lCPI0_142@PAGE
Lloh559:
	ldr	q3, [x10, lCPI0_142@PAGEOFF]
Lloh560:
	adrp	x10, lCPI0_143@PAGE
Lloh561:
	ldr	q4, [x10, lCPI0_143@PAGEOFF]
	str	q3, [sp, #13424]
	str	q4, [sp, #13408]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #1120
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #28                         ; =0x1c
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh562:
	adrp	x10, lCPI0_144@PAGE
Lloh563:
	ldr	q3, [x10, lCPI0_144@PAGEOFF]
Lloh564:
	adrp	x10, lCPI0_145@PAGE
Lloh565:
	ldr	q4, [x10, lCPI0_145@PAGEOFF]
	str	q3, [sp, #13520]
	str	q4, [sp, #13504]
Lloh566:
	adrp	x10, lCPI0_146@PAGE
Lloh567:
	ldr	q3, [x10, lCPI0_146@PAGEOFF]
Lloh568:
	adrp	x10, lCPI0_147@PAGE
Lloh569:
	ldr	q4, [x10, lCPI0_147@PAGEOFF]
	str	q3, [sp, #13488]
	str	q4, [sp, #13472]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #1184
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w2, #29                         ; =0x1d
	dup.2d	v17, x2
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
	ldr	q3, [sp, #17888]
	ldr	q4, [sp, #17904]
	ldr	q5, [sp, #17856]
	ldr	q16, [sp, #17872]
	ldr	q17, [sp, #17824]
	ldr	q18, [sp, #17840]
	ldr	q19, [sp, #17792]
	ldr	q22, [sp, #17808]
	ldr	q23, [sp, #336]                 ; 16-byte Folded Reload
	bit.16b	v22, v23, v11
	bit.16b	v19, v23, v12
	bit.16b	v18, v23, v13
	bit.16b	v17, v23, v14
Lloh570:
	adrp	x10, lCPI0_17@PAGE
Lloh571:
	ldr	q23, [x10, lCPI0_17@PAGEOFF]
	bit.16b	v16, v23, v11
Lloh572:
	adrp	x10, lCPI0_16@PAGE
Lloh573:
	ldr	q23, [x10, lCPI0_16@PAGEOFF]
	bit.16b	v5, v23, v12
Lloh574:
	adrp	x10, lCPI0_19@PAGE
Lloh575:
	ldr	q23, [x10, lCPI0_19@PAGEOFF]
	bit.16b	v4, v23, v13
Lloh576:
	adrp	x10, lCPI0_18@PAGE
Lloh577:
	ldr	q23, [x10, lCPI0_18@PAGEOFF]
	bit.16b	v3, v23, v14
	str	q3, [sp, #17888]
	str	q4, [sp, #17904]
	str	q5, [sp, #17856]
	str	q16, [sp, #17872]
	str	q17, [sp, #17824]
	str	q18, [sp, #17840]
	str	q19, [sp, #17792]
	str	q22, [sp, #17808]
	ldr	q3, [sp, #1248]                 ; 16-byte Folded Reload
	bic.16b	v3, v3, v13
	str	q3, [sp, #1248]                 ; 16-byte Folded Spill
	ldr	q3, [sp, #1040]                 ; 16-byte Folded Reload
	bic.16b	v3, v3, v14
	str	q3, [sp, #1040]                 ; 16-byte Folded Spill
	ldr	q3, [sp, #1056]                 ; 16-byte Folded Reload
	bic.16b	v3, v3, v11
	str	q3, [sp, #1056]                 ; 16-byte Folded Spill
	bic.16b	v0, v0, v12
LBB0_336:                               ; %schedule.14
                                        ;   in Loop: Header=BB0_7 Depth=3
	str	q0, [sp, #832]                  ; 16-byte Folded Spill
LBB0_337:                               ; %schedule.14
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	mov	w2, #128                        ; =0x80
	dup.2d	v3, x2
	ldr	q17, [sp, #1056]                ; 16-byte Folded Reload
	cmgt.2d	v4, v3, v17
	ldr	q0, [sp, #832]                  ; 16-byte Folded Reload
	cmgt.2d	v5, v3, v0
	uzp1.4s	v4, v5, v4
	ldr	q18, [sp, #1040]                ; 16-byte Folded Reload
	cmgt.2d	v5, v3, v18
	ldr	q19, [sp, #1248]                ; 16-byte Folded Reload
	cmgt.2d	v16, v3, v19
	uzp1.4s	v5, v5, v16
	uzp1.8h	v4, v4, v5
	xtn.8b	v4, v4
	and.8b	v11, v10, v4
	shl.8b	v4, v11, #7
	cmlt.8b	v4, v4, #0
	and.8b	v5, v4, v2
	addv.8b	b5, v5
	fmov	w2, s5
	umaxv.8b	b4, v4
	fmov	w4, s4
	tbz	w4, #0, LBB0_343
; %bb.338:                              ; %schedule.14
                                        ;   in Loop: Header=BB0_7 Depth=3
	cmge.2d	v4, v17, v3
	cmge.2d	v5, v0, v3
	uzp1.4s	v4, v5, v4
	cmge.2d	v5, v18, v3
	cmge.2d	v3, v19, v3
	uzp1.4s	v3, v5, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v12, v10, v3
	shl.8b	v3, v12, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w4, s3
	tst	w4, #0xff
	b.eq	LBB0_343
; %bb.339:                              ; %varying.divergent371
                                        ;   in Loop: Header=BB0_7 Depth=3
	subs	w10, w1, #1
	csel	w10, wzr, w10, lo
	and	w3, w17, #0xff
	lsr	w2, w3, w10
	tst	w2, #0x1
	str	q9, [sp, #2496]
	str	q8, [sp, #2512]
	and	x10, x10, #0x7
	add	x2, sp, #2496
	ldr	w10, [x2, x10, lsl #2]
	ccmp	w1, #0, #4, ne
	ccmp	w10, #5, #0, ne
	cset	w2, ne
	cmp	w3, #255
	b.ne	LBB0_341
; %bb.340:                              ; %varying.divergent371
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w2, #0, LBB0_341
	b	LBB0_1006
LBB0_341:                               ; %convergence.overflow.resume374
                                        ;   in Loop: Header=BB0_7 Depth=3
	mvn	w10, w17
	rbit	w10, w10
	clz	w10, w10
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w17
	csel	w4, wzr, w10, eq
	add	x3, sp, #18, lsl #12            ; =73728
	add	x3, x3, #752
	ldrb	w10, [x3, w4, uxtw]
	and	w5, w10, #0x1
	fmov	s3, w5
	ubfx	w5, w10, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w10, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w10, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w10, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w10, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w10, #6, #1
	mov.b	v3[6], w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x5, w4, uxtw]
	and	w6, w10, #0x1
	fmov	s4, w6
	ubfx	w6, w10, #1, #1
	mov.b	v4[1], w6
	ubfx	w6, w10, #2, #1
	mov.b	v4[2], w6
	ubfx	w6, w10, #3, #1
	mov.b	v4[3], w6
	ubfx	w6, w10, #4, #1
	mov.b	v4[4], w6
	ubfx	w6, w10, #5, #1
	mov.b	v4[5], w6
	ubfx	w6, w10, #6, #1
	mov.b	v4[6], w6
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	cmp	w2, #0
	csetm	w10, ne
	dup.8b	v5, w10
	bit.8b	v3, v10, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x3, w4, uxtw]
	bic.8b	v3, v4, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w4, uxtw]
	cmp	x0, #8
	b.hs	LBB0_1006
; %bb.342:                              ; %ready.overflow.resume376
                                        ;   in Loop: Header=BB0_7 Depth=3
	str	q7, [sp, #2464]
	str	q6, [sp, #2480]
	ubfiz	x10, x4, #2, #3
	add	x3, sp, #2464
	ldr	w3, [x3, x10]
	cmp	w2, #0
	csel	w3, w1, w3, ne
	csinc	w1, w1, w4, eq
	str	q7, [sp, #2432]
	str	q6, [sp, #2448]
	add	x5, sp, #2432
	str	w3, [x5, x10]
	ldr	q6, [sp, #2448]
	ldr	q7, [sp, #2432]
	str	q9, [sp, #2400]
	str	q8, [sp, #2416]
	add	x3, sp, #2400
	ldr	w3, [x3, x10]
	mov	w5, #5                          ; =0x5
	csel	w3, w5, w3, ne
	str	q9, [sp, #2368]
	str	q8, [sp, #2384]
	add	x5, sp, #2368
	str	w3, [x5, x10]
	mov	w3, #18                         ; =0x12
	mov	w5, #15                         ; =0xf
	ldr	q8, [sp, #2384]
	ldr	q9, [sp, #2368]
	b	LBB0_938
LBB0_343:                               ; %varying.coherent372
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_398
; %bb.344:                              ; %varying.coherent.true377
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
	tst	w3, #0xff
	b.eq	LBB0_5
LBB0_345:                               ; %schedule.15
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.16b	v0, v21
	mov.16b	v21, v20
	mov.16b	v20, v15
	mov	b3, v10[0]
	mov.b	v3[4], v10[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v4, v3, #0
	ldr	q3, [sp, #832]                  ; 16-byte Folded Reload
	and.16b	v18, v4, v3
	mov	b3, v10[2]
	mov.b	v3[4], v10[3]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v5, v3, #0
	ldr	q3, [sp, #1056]                 ; 16-byte Folded Reload
	and.16b	v19, v5, v3
	mov	b3, v10[4]
	mov.b	v3[4], v10[5]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v24, v3, #0
	ldr	q3, [sp, #1040]                 ; 16-byte Folded Reload
	and.16b	v26, v24, v3
	mov	b3, v10[6]
	mov.b	v3[4], v10[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v25, v3, #0
	ldr	q3, [sp, #1248]                 ; 16-byte Folded Reload
	and.16b	v3, v25, v3
	shl.8b	v16, v10, #7
	cmlt.8b	v16, v16, #0
	and.8b	v17, v16, v2
	addv.8b	b13, v17
	fmov	w3, s13
	mov	w4, #32                         ; =0x20
	dup.2d	v27, x4
	and.16b	v17, v4, v27
	mvn.16b	v4, v4
	sub.2d	v17, v17, v4
	and.16b	v4, v5, v27
	mvn.16b	v5, v5
	sub.2d	v4, v4, v5
	and.16b	v5, v24, v27
	and.16b	v27, v25, v27
	mvn.16b	v25, v25
	sub.2d	v25, v27, v25
	mov.d	x4, v25[1]
	mov.d	x5, v3[1]
	sdiv	x5, x5, x4
	mvn.16b	v24, v24
	sub.2d	v5, v5, v24
	fmov	x6, d25
	fmov	x7, d3
	sdiv	x7, x7, x6
	mul	x6, x7, x6
	fmov	d11, x7
	mov.d	v11[1], x5
	mov.d	x7, v5[1]
	mov.d	x19, v26[1]
	sdiv	x19, x19, x7
	fmov	x20, d5
	fmov	x21, d26
	sdiv	x21, x21, x20
	mul	x20, x21, x20
	fmov	d12, x21
	mov.d	v12[1], x19
	mov.d	x21, v4[1]
	mov.d	x22, v19[1]
	sdiv	x22, x22, x21
	fmov	x23, d4
	fmov	x24, d19
	sdiv	x24, x24, x23
	mul	x23, x24, x23
	fmov	d14, x24
	mov.d	v14[1], x22
	mov.d	x24, v17[1]
	mov.d	x25, v18[1]
	fmov	x26, d17
	fmov	x27, d18
	sdiv	x27, x27, x26
	mul	x26, x27, x26
	fmov	d17, x27
	sdiv	x25, x25, x24
	mov.d	v17[1], x25
	mul	x24, x25, x24
	fmov	d4, x26
	mov.d	v4[1], x24
	mul	x21, x22, x21
	fmov	d5, x23
	mov.d	v5[1], x21
	mul	x7, x19, x7
	fmov	d24, x20
	mov.d	v24[1], x7
	mul	x4, x5, x4
	fmov	d25, x6
	mov.d	v25[1], x4
	sub.2d	v3, v3, v25
	sub.2d	v24, v26, v24
	sub.2d	v5, v19, v5
	sub.2d	v4, v18, v4
	dup.2d	v18, x16
	add.2d	v4, v4, v18
	add.2d	v5, v5, v18
	add.2d	v19, v24, v18
	add.2d	v3, v3, v18
	ldr	q18, [sp, #17920]
	ldr	q24, [sp, #17936]
	ldr	q25, [sp, #17952]
	ldr	q26, [sp, #17968]
	ldr	q27, [sp, #18032]
	ldr	q28, [sp, #18016]
	ldr	q29, [sp, #18000]
	shl.2d	v3, v3, #6
	shl.2d	v19, v19, #6
	shl.2d	v5, v5, #6
	shl.2d	v30, v4, #6
	ldr	q15, [sp, #17984]
	add.2d	v4, v26, v27
	add.2d	v31, v4, v3
	add.2d	v3, v25, v28
	add.2d	v3, v3, v19
	add.2d	v4, v24, v29
	add.2d	v4, v4, v5
	add.2d	v5, v18, v15
	add.2d	v15, v5, v30
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	tbnz	w3, #0, LBB0_384
; %bb.346:                              ; %else4148
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #1, LBB0_385
LBB0_347:                               ; %else4154
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.16b	v15, v20
	mov.16b	v20, v21
	tbnz	w3, #2, LBB0_386
LBB0_348:                               ; %else4160
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.16b	v21, v0
	tbnz	w3, #3, LBB0_387
LBB0_349:                               ; %else4166
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #4, LBB0_388
LBB0_350:                               ; %else4172
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #5, LBB0_389
LBB0_351:                               ; %else4178
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #6, LBB0_390
LBB0_352:                               ; %else4184
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w3, #7, LBB0_354
LBB0_353:                               ; %cond.load4186
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v31[1]
	ld1.d	{ v27 }[1], [x3]
LBB0_354:                               ; %else4190
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w3, #32                         ; =0x20
	dup.2d	v3, x3
	cmhi.2d	v4, v3, v19
	cmhi.2d	v5, v3, v18
	uzp1.4s	v4, v5, v4
	cmhi.2d	v5, v3, v26
	cmhi.2d	v3, v3, v27
	uzp1.4s	v3, v5, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	ldrb	w3, [x9, #1536]
	and	w4, w3, #0x1
	fmov	s4, w4
	ubfx	w4, w3, #1, #1
	mov.b	v4[1], w4
	ubfx	w4, w3, #2, #1
	mov.b	v4[2], w4
	ubfx	w4, w3, #3, #1
	mov.b	v4[3], w4
	ubfx	w4, w3, #4, #1
	mov.b	v4[4], w4
	ubfx	w4, w3, #5, #1
	mov.b	v4[5], w4
	ubfx	w4, w3, #6, #1
	mov.b	v4[6], w4
	lsr	w3, w3, #7
	mov.b	v4[7], w3
	bif.8b	v3, v4, v16
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x9, #1536]
	shl.2d	v5, v14, #5
	shl.2d	v4, v17, #5
	shl.2d	v16, v11, #5
	shl.2d	v3, v12, #5
	add.2d	v3, v26, v3
	add.2d	v16, v27, v16
	add.2d	v4, v18, v4
	add.2d	v17, v19, v5
	ldr	q5, [sp, #17696]
	ldr	q18, [sp, #17712]
	ldr	q19, [sp, #17664]
	ldr	q24, [sp, #17680]
	mov	b25, v10[2]
	mov.b	v25[4], v10[3]
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	mov	b26, v10[0]
	mov.b	v26[4], v10[1]
	bit.16b	v24, v17, v25
	ushll.2d	v25, v26, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	bit.16b	v19, v4, v25
	mov	b25, v10[6]
	mov.b	v25[4], v10[7]
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	bit.16b	v18, v16, v25
	mov	b25, v10[4]
	mov.b	v25[4], v10[5]
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	bit.16b	v5, v3, v25
	str	q5, [sp, #17696]
	str	q18, [sp, #17712]
	str	q19, [sp, #17664]
	str	q24, [sp, #17680]
	mov	w3, #128                        ; =0x80
	dup.2d	v18, x3
	cmhi.2d	v5, v18, v4
	cmhi.2d	v19, v18, v17
	uzp1.4s	v5, v5, v19
	cmhi.2d	v19, v18, v3
	cmhi.2d	v24, v18, v16
	uzp1.4s	v19, v19, v24
	uzp1.8h	v5, v5, v19
	xtn.8b	v5, v5
	and.8b	v11, v10, v5
	shl.8b	v5, v11, #7
	cmlt.8b	v5, v5, #0
	and.8b	v19, v5, v2
	addv.8b	b19, v19
	fmov	w3, s19
	umaxv.8b	b5, v5
	fmov	w4, s5
	tbz	w4, #0, LBB0_360
; %bb.355:                              ; %else4190
                                        ;   in Loop: Header=BB0_7 Depth=3
	cmhs.2d	v4, v4, v18
	cmhs.2d	v5, v17, v18
	uzp1.4s	v4, v4, v5
	cmhs.2d	v3, v3, v18
	cmhs.2d	v5, v16, v18
	uzp1.4s	v3, v3, v5
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v12, v10, v3
	shl.8b	v3, v12, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w4, s3
	tst	w4, #0xff
	b.eq	LBB0_360
; %bb.356:                              ; %varying.divergent385
                                        ;   in Loop: Header=BB0_7 Depth=3
	subs	w10, w1, #1
	csel	w10, wzr, w10, lo
	and	w3, w17, #0xff
	lsr	w2, w3, w10
	tst	w2, #0x1
	str	q9, [sp, #2656]
	str	q8, [sp, #2672]
	and	x10, x10, #0x7
	add	x2, sp, #2656
	ldr	w10, [x2, x10, lsl #2]
	ccmp	w1, #0, #4, ne
	ccmp	w10, #6, #0, ne
	cset	w2, ne
	cmp	w3, #255
	b.ne	LBB0_358
; %bb.357:                              ; %varying.divergent385
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w2, #0, LBB0_358
	b	LBB0_1006
LBB0_358:                               ; %convergence.overflow.resume388
                                        ;   in Loop: Header=BB0_7 Depth=3
	mvn	w10, w17
	rbit	w10, w10
	clz	w10, w10
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w17
	csel	w4, wzr, w10, eq
	add	x3, sp, #18, lsl #12            ; =73728
	add	x3, x3, #752
	ldrb	w10, [x3, w4, uxtw]
	and	w5, w10, #0x1
	fmov	s3, w5
	ubfx	w5, w10, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w10, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w10, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w10, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w10, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w10, #6, #1
	mov.b	v3[6], w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x5, w4, uxtw]
	and	w6, w10, #0x1
	fmov	s4, w6
	ubfx	w6, w10, #1, #1
	mov.b	v4[1], w6
	ubfx	w6, w10, #2, #1
	mov.b	v4[2], w6
	ubfx	w6, w10, #3, #1
	mov.b	v4[3], w6
	ubfx	w6, w10, #4, #1
	mov.b	v4[4], w6
	ubfx	w6, w10, #5, #1
	mov.b	v4[5], w6
	ubfx	w6, w10, #6, #1
	mov.b	v4[6], w6
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	cmp	w2, #0
	csetm	w10, ne
	dup.8b	v5, w10
	bit.8b	v3, v10, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x3, w4, uxtw]
	bic.8b	v3, v4, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w4, uxtw]
	cmp	x0, #8
	b.hs	LBB0_1006
; %bb.359:                              ; %ready.overflow.resume390
                                        ;   in Loop: Header=BB0_7 Depth=3
	zip2.8b	v3, v12, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldp	q5, q0, [sp, #512]              ; 32-byte Folded Reload
	and.16b	v4, v3, v5
	zip1.8b	v3, v12, v5
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v0, v3, v0
	stp	q4, q0, [sp, #512]              ; 32-byte Folded Spill
	str	q7, [sp, #2624]
	str	q6, [sp, #2640]
	ubfiz	x10, x4, #2, #3
	add	x3, sp, #2624
	ldr	w3, [x3, x10]
	cmp	w2, #0
	csel	w3, w1, w3, ne
	csinc	w1, w1, w4, eq
	str	q7, [sp, #2592]
	str	q6, [sp, #2608]
	add	x5, sp, #2592
	str	w3, [x5, x10]
	ldr	q6, [sp, #2608]
	ldr	q7, [sp, #2592]
	str	q9, [sp, #2560]
	str	q8, [sp, #2576]
	add	x3, sp, #2560
	ldr	w3, [x3, x10]
	mov	w5, #6                          ; =0x6
	csel	w3, w5, w3, ne
	str	q9, [sp, #2528]
	str	q8, [sp, #2544]
	add	x5, sp, #2528
	str	w3, [x5, x10]
	mov	w3, #17                         ; =0x11
	mov	w5, #16                         ; =0x10
	ldr	q8, [sp, #2544]
	ldr	q9, [sp, #2528]
	b	LBB0_938
LBB0_360:                               ; %varying.coherent386
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_407
; %bb.361:                              ; %varying.coherent.true391
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #0, LBB0_5
; %bb.362:                              ; %schedule.16.thread
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q3, [sp, #18048]
	ldr	q4, [sp, #18064]
	ldr	q5, [sp, #18080]
	ldr	q16, [sp, #18096]
	ldr	q17, [sp, #18160]
	ldr	q18, [sp, #18144]
	ldr	q19, [sp, #18128]
	ldr	q22, [sp, #18112]
	ldr	q23, [sp, #17664]
	ldr	q24, [sp, #17680]
	ldr	q25, [sp, #17696]
	ldr	q26, [sp, #17712]
	shl.2d	v26, v26, #5
	shl.2d	v25, v25, #5
	shl.2d	v24, v24, #5
	shl.2d	v23, v23, #5
	add.2d	v16, v16, v17
	add.2d	v17, v16, v26
	add.2d	v5, v5, v18
	add.2d	v18, v5, v25
	add.2d	v4, v4, v19
	add.2d	v4, v4, v24
	add.2d	v3, v3, v22
	add.2d	v19, v3, v23
	fmov	w2, s13
	movi.2d	v16, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w2, #0, LBB0_408
; %bb.363:                              ; %else5277
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #1, LBB0_409
LBB0_364:                               ; %else5283
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #2, LBB0_410
LBB0_365:                               ; %else5289
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #3, LBB0_411
LBB0_366:                               ; %else5295
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #4, LBB0_412
LBB0_367:                               ; %else5301
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #5, LBB0_413
LBB0_368:                               ; %else5307
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #6, LBB0_414
LBB0_369:                               ; %else5313
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w2, #7, LBB0_371
LBB0_370:                               ; %cond.load5315
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v17[1]
	ld1.s	{ v3 }[3], [x10]
LBB0_371:                               ; %else5319
                                        ;   in Loop: Header=BB0_7 Depth=3
	zip2.8b	v4, v10, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q0, [sp, #512]                  ; 16-byte Folded Reload
	bit.16b	v0, v3, v4
	str	q0, [sp, #512]                  ; 16-byte Folded Spill
	zip1.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q0, [sp, #528]                  ; 16-byte Folded Reload
	bit.16b	v0, v16, v3
	str	q0, [sp, #528]                  ; 16-byte Folded Spill
	cbnz	w1, LBB0_37
LBB0_372:                               ; %schedule.17.convergence.cascade.exit396_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
LBB0_373:                               ; %convergence.cascade.exit396
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
; %bb.374:                              ; %convergence.target.17.ready
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q0, [sp, #768]                  ; 16-byte Folded Reload
	dup.4s	v4, v0[0]
	ldrb	w10, [x9, #1536]
	ubfx	w2, w10, #3, #1
	ubfx	w3, w10, #2, #1
	ubfx	w4, w10, #1, #1
	and	w5, w10, #0x1
	lsr	w6, w10, #7
	ubfx	w7, w10, #6, #1
	ubfx	w19, w10, #5, #1
	ubfx	w10, w10, #4, #1
	fmov	s3, w10
	mov.h	v3[1], w19
	mov.h	v3[2], w7
	mov.h	v3[3], w6
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	fmov	s5, w5
	mov.h	v5[1], w4
	mov.h	v5[2], w3
	mov.h	v5[3], w2
	ldr	q0, [sp, #512]                  ; 16-byte Folded Reload
	bsl.16b	v3, v0, v4
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q0, [sp, #528]                  ; 16-byte Folded Reload
	mov.16b	v16, v5
	bsl.16b	v16, v0, v4
	ldr	q4, [sp, #17840]
	ldr	q5, [sp, #17824]
	ldr	q17, [sp, #17808]
	ldr	q18, [sp, #17792]
	ldr	q19, [sp, #17856]
	ldr	q22, [sp, #17872]
	ldr	q23, [sp, #17888]
	ldr	q24, [sp, #17904]
	ldr	q0, [sp, #832]                  ; 16-byte Folded Reload
	shl.2d	v25, v0, #5
	ldr	q26, [sp, #1056]                ; 16-byte Folded Reload
	shl.2d	v26, v26, #5
	ldr	q27, [sp, #1040]                ; 16-byte Folded Reload
	shl.2d	v27, v27, #5
	ldr	q28, [sp, #1248]                ; 16-byte Folded Reload
	shl.2d	v28, v28, #5
	add.2d	v24, v24, v28
	add.2d	v23, v23, v27
	add.2d	v22, v22, v26
	add.2d	v19, v19, v25
	add.2d	v19, v18, v19
	add.2d	v18, v17, v22
	add.2d	v17, v5, v23
	add.2d	v4, v4, v24
	shl.8b	v5, v10, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	fmov	w2, s5
	tbnz	w2, #0, LBB0_391
; %bb.375:                              ; %else5325
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #1, LBB0_392
LBB0_376:                               ; %else5329
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q5, [sp, #1056]                 ; 16-byte Folded Reload
	tbnz	w2, #2, LBB0_393
LBB0_377:                               ; %else5333
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #3, LBB0_394
LBB0_378:                               ; %else5337
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #4, LBB0_395
LBB0_379:                               ; %else5341
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q16, [sp, #1040]                ; 16-byte Folded Reload
	tbnz	w2, #5, LBB0_396
LBB0_380:                               ; %else5345
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #6, LBB0_397
LBB0_381:                               ; %else5349
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w2, #7, LBB0_383
LBB0_382:                               ; %cond.store5350
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v4[1]
	st1.s	{ v3 }[3], [x10]
LBB0_383:                               ; %else5353
                                        ;   in Loop: Header=BB0_7 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v10, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v4, v3, #0
	ushll2.4s	v3, v3, #0
	ldr	q17, [sp, #1248]                ; 16-byte Folded Reload
	uaddw2.2d	v17, v17, v3
	str	q17, [sp, #1248]                ; 16-byte Folded Spill
	uaddw.2d	v16, v16, v3
	str	q16, [sp, #1040]                ; 16-byte Folded Spill
	uaddw2.2d	v5, v5, v4
	str	q5, [sp, #1056]                 ; 16-byte Folded Spill
	uaddw.2d	v0, v0, v4
	b	LBB0_336
LBB0_384:                               ; %cond.load4144
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d15
	ldr	d18, [x4]
	tbz	w3, #1, LBB0_347
LBB0_385:                               ; %cond.load4150
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v15[1]
	ld1.d	{ v18 }[1], [x4]
	mov.16b	v15, v20
	mov.16b	v20, v21
	tbz	w3, #2, LBB0_348
LBB0_386:                               ; %cond.load4156
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d4
	ld1.d	{ v19 }[0], [x4]
	mov.16b	v21, v0
	tbz	w3, #3, LBB0_349
LBB0_387:                               ; %cond.load4162
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v4[1]
	ld1.d	{ v19 }[1], [x4]
	tbz	w3, #4, LBB0_350
LBB0_388:                               ; %cond.load4168
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d3
	ld1.d	{ v26 }[0], [x4]
	tbz	w3, #5, LBB0_351
LBB0_389:                               ; %cond.load4174
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v3[1]
	ld1.d	{ v26 }[1], [x4]
	tbz	w3, #6, LBB0_352
LBB0_390:                               ; %cond.load4180
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d31
	ld1.d	{ v27 }[0], [x4]
	tbnz	w3, #7, LBB0_353
	b	LBB0_354
LBB0_391:                               ; %cond.store5322
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d19
	str	s16, [x10]
	tbz	w2, #1, LBB0_376
LBB0_392:                               ; %cond.store5326
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v19[1]
	st1.s	{ v16 }[1], [x10]
	ldr	q5, [sp, #1056]                 ; 16-byte Folded Reload
	tbz	w2, #2, LBB0_377
LBB0_393:                               ; %cond.store5330
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d18
	st1.s	{ v16 }[2], [x10]
	tbz	w2, #3, LBB0_378
LBB0_394:                               ; %cond.store5334
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v18[1]
	st1.s	{ v16 }[3], [x10]
	tbz	w2, #4, LBB0_379
LBB0_395:                               ; %cond.store5338
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d17
	str	s3, [x10]
	ldr	q16, [sp, #1040]                ; 16-byte Folded Reload
	tbz	w2, #5, LBB0_380
LBB0_396:                               ; %cond.store5342
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v17[1]
	st1.s	{ v3 }[1], [x10]
	tbz	w2, #6, LBB0_381
LBB0_397:                               ; %cond.store5346
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d4
	st1.s	{ v3 }[2], [x10]
	tbnz	w2, #7, LBB0_382
	b	LBB0_383
LBB0_398:                               ; %varying.coherent.false378
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
LBB0_399:                               ; %schedule.18
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q0, [sp, #928]                  ; 16-byte Folded Reload
	cbz	w1, LBB0_404
; %bb.400:                              ; %convergence.cascade420.preheader
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
LBB0_401:                               ; %convergence.cascade420
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_7 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w10, s4
	umaxv.8b	b3, v3
	fmov	w6, s3
	sub	w3, w1, #1
	tst	w10, #0xff
	csel	w4, w3, wzr, ne
	mov	w10, #1                         ; =0x1
	lsl	w5, w10, w4
	and	w10, w5, w17
	tst	w10, #0xff
	cset	w10, ne
	str	q9, [sp, #11456]
	str	q8, [sp, #11472]
	ubfiz	x3, x4, #2, #3
	add	x7, sp, #2, lsl #12             ; =8192
	add	x7, x7, #3264
	ldr	w7, [x7, x3]
	cmp	w7, #5
	cset	w7, eq
	and	w19, w10, w6
	add	x6, sp, #18, lsl #12            ; =73728
	add	x6, x6, #752
	ldrb	w10, [x6, w4, sxtw]
	and	w20, w10, #0x1
	fmov	s3, w20
	ubfx	w20, w10, #1, #1
	mov.b	v3[1], w20
	ubfx	w20, w10, #2, #1
	mov.b	v3[2], w20
	ubfx	w20, w10, #3, #1
	mov.b	v3[3], w20
	ubfx	w20, w10, #4, #1
	mov.b	v3[4], w20
	ubfx	w20, w10, #5, #1
	mov.b	v3[5], w20
	ubfx	w20, w10, #6, #1
	mov.b	v3[6], w20
	add	x20, sp, #18, lsl #12           ; =73728
	add	x20, x20, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x20, w4, sxtw]
	and	w21, w10, #0x1
	fmov	s4, w21
	ubfx	w21, w10, #1, #1
	mov.b	v4[1], w21
	ubfx	w21, w10, #2, #1
	mov.b	v4[2], w21
	ubfx	w21, w10, #3, #1
	mov.b	v4[3], w21
	ubfx	w21, w10, #4, #1
	mov.b	v4[4], w21
	ubfx	w21, w10, #5, #1
	mov.b	v4[5], w21
	ubfx	w21, w10, #6, #1
	mov.b	v4[6], w21
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	orr.8b	v5, v10, v4
	and.8b	v16, v1, v3
	eor.8b	v16, v16, v5
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	umaxv.8b	b16, v16
	fmov	w10, s16
	ands	w7, w19, w7
	csetm	w19, ne
	bics	w10, w7, w10
	csetm	w21, ne
	dup.8b	v16, w21
	bic.8b	v17, v5, v16
	dup.8b	v18, w19
	bit.8b	v4, v17, v18
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x20, w4, sxtw]
	bic.8b	v3, v3, v16
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x6, w4, sxtw]
	mov	w4, #-1                         ; =0xffffffff
	csinv	w4, w4, w5, eq
	and	w17, w4, w17
	dup.8b	v3, w7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v4, w10
	and.8b	v4, v4, v5
	str	q7, [sp, #11424]
	str	q6, [sp, #11440]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #3232
	ldr	w10, [x10, x3]
	csel	w1, w10, w1, ne
	bit.8b	v10, v4, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	cmp	w7, #1
	b.ne	LBB0_405
; %bb.402:                              ; %convergence.cascade420
                                        ;   in Loop: Header=BB0_401 Depth=4
	cmp	w1, #0
	ccmp	w2, #6, #2, ne
	b.hi	LBB0_405
; %bb.403:                              ; %convergence.cascade420
                                        ;   in Loop: Header=BB0_401 Depth=4
	add	w2, w2, #1
	tst	w3, #0xff
	b.ne	LBB0_401
	b	LBB0_405
LBB0_404:                               ; %schedule.18.convergence.cascade.exit421_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
LBB0_405:                               ; %convergence.cascade.exit421
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
; %bb.406:                              ; %convergence.target.18.ready
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q17, [sp, #17632]
	ldr	q4, [sp, #17648]
	ldr	q3, [sp, #17600]
	ldr	q5, [sp, #17616]
	ldr	q16, [sp, #17568]
	ldr	q19, [sp, #17584]
	ldr	q22, [sp, #17536]
	ldr	q23, [sp, #17552]
	mov	b18, v10[2]
	mov.b	v18[4], v10[3]
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	ldr	q28, [sp, #320]                 ; 16-byte Folded Reload
	bit.16b	v23, v28, v18
	mov	b24, v10[0]
	mov.b	v24[4], v10[1]
	ushll.2d	v24, v24, #0
	shl.2d	v24, v24, #63
	cmlt.2d	v24, v24, #0
	mov	b25, v10[6]
	mov.b	v25[4], v10[7]
	bit.16b	v22, v28, v24
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	bit.16b	v19, v28, v25
	mov	b26, v10[4]
	mov.b	v26[4], v10[5]
	ushll.2d	v26, v26, #0
	shl.2d	v26, v26, #63
	cmlt.2d	v26, v26, #0
Lloh578:
	adrp	x10, lCPI0_17@PAGE
Lloh579:
	ldr	q27, [x10, lCPI0_17@PAGEOFF]
	bit.16b	v5, v27, v18
Lloh580:
	adrp	x10, lCPI0_18@PAGE
Lloh581:
	ldr	q27, [x10, lCPI0_18@PAGEOFF]
	bit.16b	v17, v27, v26
Lloh582:
	adrp	x10, lCPI0_16@PAGE
Lloh583:
	ldr	q27, [x10, lCPI0_16@PAGEOFF]
	str	q17, [sp, #17632]
Lloh584:
	adrp	x10, lCPI0_19@PAGE
Lloh585:
	ldr	q17, [x10, lCPI0_19@PAGEOFF]
	bit.16b	v16, v28, v26
	bit.16b	v4, v17, v25
	str	q4, [sp, #17648]
	bit.16b	v3, v27, v24
	str	q3, [sp, #17600]
	str	q5, [sp, #17616]
	str	q16, [sp, #17568]
	str	q19, [sp, #17584]
	str	q22, [sp, #17536]
	str	q23, [sp, #17552]
	ldr	q3, [sp, #1312]                 ; 16-byte Folded Reload
	bic.16b	v3, v3, v25
	str	q3, [sp, #1312]                 ; 16-byte Folded Spill
	bic.16b	v0, v0, v26
	str	q0, [sp, #928]                  ; 16-byte Folded Spill
	ldr	q0, [sp, #1328]                 ; 16-byte Folded Reload
	bic.16b	v0, v0, v18
	str	q0, [sp, #1328]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #1344]                 ; 16-byte Folded Reload
	bic.16b	v0, v0, v24
	str	q0, [sp, #1344]                 ; 16-byte Folded Spill
	b	LBB0_415
LBB0_407:                               ; %varying.coherent.false392
                                        ;   in Loop: Header=BB0_7 Depth=3
	zip2.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldp	q5, q0, [sp, #512]              ; 32-byte Folded Reload
	and.16b	v4, v3, v5
	zip1.8b	v3, v10, v5
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v0, v3, v0
	stp	q4, q0, [sp, #512]              ; 32-byte Folded Spill
	tbz	w2, #0, LBB0_36
	b	LBB0_5
LBB0_408:                               ; %cond.load5273
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d19
	ldr	s16, [x10]
	tbz	w2, #1, LBB0_364
LBB0_409:                               ; %cond.load5279
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v19[1]
	ld1.s	{ v16 }[1], [x10]
	tbz	w2, #2, LBB0_365
LBB0_410:                               ; %cond.load5285
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d4
	ld1.s	{ v16 }[2], [x10]
	tbz	w2, #3, LBB0_366
LBB0_411:                               ; %cond.load5291
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v4[1]
	ld1.s	{ v16 }[3], [x10]
	tbz	w2, #4, LBB0_367
LBB0_412:                               ; %cond.load5297
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d18
	ld1.s	{ v3 }[0], [x10]
	tbz	w2, #5, LBB0_368
LBB0_413:                               ; %cond.load5303
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v18[1]
	ld1.s	{ v3 }[1], [x10]
	tbz	w2, #6, LBB0_369
LBB0_414:                               ; %cond.load5309
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d17
	ld1.s	{ v3 }[2], [x10]
	tbnz	w2, #7, LBB0_370
	b	LBB0_371
LBB0_415:                               ; %schedule.19
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	mov	w2, #128                        ; =0x80
	dup.2d	v3, x2
	ldr	q17, [sp, #1328]                ; 16-byte Folded Reload
	cmgt.2d	v4, v3, v17
	ldr	q0, [sp, #1344]                 ; 16-byte Folded Reload
	cmgt.2d	v5, v3, v0
	uzp1.4s	v4, v5, v4
	ldr	q18, [sp, #928]                 ; 16-byte Folded Reload
	cmgt.2d	v5, v3, v18
	ldr	q19, [sp, #1312]                ; 16-byte Folded Reload
	cmgt.2d	v16, v3, v19
	uzp1.4s	v5, v5, v16
	uzp1.8h	v4, v4, v5
	xtn.8b	v4, v4
	and.8b	v11, v10, v4
	shl.8b	v4, v11, #7
	cmlt.8b	v4, v4, #0
	and.8b	v5, v4, v2
	addv.8b	b5, v5
	fmov	w2, s5
	umaxv.8b	b4, v4
	fmov	w4, s4
	tbz	w4, #0, LBB0_421
; %bb.416:                              ; %schedule.19
                                        ;   in Loop: Header=BB0_7 Depth=3
	cmge.2d	v4, v17, v3
	cmge.2d	v5, v0, v3
	uzp1.4s	v4, v5, v4
	cmge.2d	v5, v18, v3
	cmge.2d	v3, v19, v3
	uzp1.4s	v3, v5, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v12, v10, v3
	shl.8b	v3, v12, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w4, s3
	tst	w4, #0xff
	b.eq	LBB0_421
; %bb.417:                              ; %varying.divergent438
                                        ;   in Loop: Header=BB0_7 Depth=3
	subs	w10, w1, #1
	csel	w10, wzr, w10, lo
	and	w3, w17, #0xff
	lsr	w2, w3, w10
	tst	w2, #0x1
	str	q9, [sp, #2880]
	str	q8, [sp, #2896]
	and	x10, x10, #0x7
	add	x2, sp, #2880
	ldr	w10, [x2, x10, lsl #2]
	ccmp	w1, #0, #4, ne
	ccmp	w10, #7, #0, ne
	cset	w2, ne
	cmp	w3, #255
	b.ne	LBB0_419
; %bb.418:                              ; %varying.divergent438
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w2, #0, LBB0_419
	b	LBB0_1006
LBB0_419:                               ; %convergence.overflow.resume441
                                        ;   in Loop: Header=BB0_7 Depth=3
	mvn	w10, w17
	rbit	w10, w10
	clz	w10, w10
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w17
	csel	w4, wzr, w10, eq
	add	x3, sp, #18, lsl #12            ; =73728
	add	x3, x3, #752
	ldrb	w10, [x3, w4, uxtw]
	and	w5, w10, #0x1
	fmov	s3, w5
	ubfx	w5, w10, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w10, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w10, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w10, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w10, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w10, #6, #1
	mov.b	v3[6], w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x5, w4, uxtw]
	and	w6, w10, #0x1
	fmov	s4, w6
	ubfx	w6, w10, #1, #1
	mov.b	v4[1], w6
	ubfx	w6, w10, #2, #1
	mov.b	v4[2], w6
	ubfx	w6, w10, #3, #1
	mov.b	v4[3], w6
	ubfx	w6, w10, #4, #1
	mov.b	v4[4], w6
	ubfx	w6, w10, #5, #1
	mov.b	v4[5], w6
	ubfx	w6, w10, #6, #1
	mov.b	v4[6], w6
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	cmp	w2, #0
	csetm	w10, ne
	dup.8b	v5, w10
	bit.8b	v3, v10, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x3, w4, uxtw]
	bic.8b	v3, v4, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w4, uxtw]
	cmp	x0, #8
	b.hs	LBB0_1006
; %bb.420:                              ; %ready.overflow.resume443
                                        ;   in Loop: Header=BB0_7 Depth=3
	str	q7, [sp, #2848]
	str	q6, [sp, #2864]
	ubfiz	x10, x4, #2, #3
	add	x3, sp, #2848
	ldr	w3, [x3, x10]
	cmp	w2, #0
	csel	w3, w1, w3, ne
	csinc	w1, w1, w4, eq
	str	q7, [sp, #2816]
	str	q6, [sp, #2832]
	add	x5, sp, #2816
	str	w3, [x5, x10]
	ldr	q6, [sp, #2832]
	ldr	q7, [sp, #2816]
	str	q9, [sp, #2784]
	str	q8, [sp, #2800]
	add	x3, sp, #2784
	ldr	w3, [x3, x10]
	mov	w5, #7                          ; =0x7
	csel	w3, w5, w3, ne
	str	q9, [sp, #2752]
	str	q8, [sp, #2768]
	add	x5, sp, #2752
	str	w3, [x5, x10]
	mov	w3, #21                         ; =0x15
	mov	w5, #20                         ; =0x14
	ldr	q8, [sp, #2768]
	ldr	q9, [sp, #2752]
	b	LBB0_938
LBB0_421:                               ; %varying.coherent439
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_472
; %bb.422:                              ; %varying.coherent.true444
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
	tst	w3, #0xff
	b.eq	LBB0_5
LBB0_423:                               ; %schedule.20
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	b3, v10[0]
	mov.b	v3[4], v10[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v4, v3, #0
	ldr	q0, [sp, #1344]                 ; 16-byte Folded Reload
	and.16b	v17, v4, v0
	mov	b3, v10[2]
	mov.b	v3[4], v10[3]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v5, v3, #0
	ldr	q0, [sp, #1328]                 ; 16-byte Folded Reload
	and.16b	v18, v5, v0
	mov	b3, v10[4]
	mov.b	v3[4], v10[5]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v24, v3, #0
	ldr	q0, [sp, #928]                  ; 16-byte Folded Reload
	and.16b	v19, v24, v0
	mov	b3, v10[6]
	mov.b	v3[4], v10[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v25, v3, #0
	ldr	q0, [sp, #1312]                 ; 16-byte Folded Reload
	and.16b	v3, v25, v0
	shl.8b	v16, v10, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v2
	mov	w3, #32                         ; =0x20
	dup.2d	v27, x3
	and.16b	v26, v4, v27
	mvn.16b	v4, v4
	sub.2d	v26, v26, v4
	and.16b	v4, v5, v27
	mvn.16b	v5, v5
	sub.2d	v4, v4, v5
	and.16b	v5, v24, v27
	mvn.16b	v24, v24
	and.16b	v27, v25, v27
	mvn.16b	v25, v25
	sub.2d	v25, v27, v25
	mov.d	x3, v25[1]
	mov.d	x4, v3[1]
	sdiv	x4, x4, x3
	sub.2d	v5, v5, v24
	fmov	x5, d25
	fmov	x6, d3
	sdiv	x6, x6, x5
	mul	x5, x6, x5
	fmov	d24, x6
	mov.d	v24[1], x4
	mov.d	x6, v5[1]
	mov.d	x7, v19[1]
	sdiv	x7, x7, x6
	fmov	x19, d5
	fmov	x20, d19
	sdiv	x20, x20, x19
	mul	x19, x20, x19
	fmov	d5, x20
	mov.d	v5[1], x7
	mov.d	x20, v4[1]
	mov.d	x21, v18[1]
	sdiv	x21, x21, x20
	fmov	x22, d4
	fmov	x23, d18
	sdiv	x23, x23, x22
	mul	x22, x23, x22
	fmov	d4, x23
	mov.d	v4[1], x21
	mov.d	x23, v26[1]
	mov.d	x24, v17[1]
	fmov	x25, d26
	fmov	x26, d17
	sdiv	x26, x26, x25
	mul	x25, x26, x25
	fmov	d25, x26
	sdiv	x24, x24, x23
	mov.d	v25[1], x24
	mul	x23, x24, x23
	fmov	d26, x25
	mov.d	v26[1], x23
	mul	x20, x21, x20
	fmov	d27, x22
	mov.d	v27[1], x20
	mul	x6, x7, x6
	fmov	d28, x19
	mov.d	v28[1], x6
	mul	x3, x4, x3
	fmov	d29, x5
	mov.d	v29[1], x3
	addv.8b	b16, v16
	sub.2d	v3, v3, v29
	sub.2d	v19, v19, v28
	fmov	w3, s16
	sub.2d	v18, v18, v27
	sub.2d	v17, v17, v26
	ldr	q28, [sp, #18048]
	ldr	q29, [sp, #18064]
	ldr	q30, [sp, #18080]
	ldr	q31, [sp, #18096]
	ldr	q11, [sp, #18160]
	ldr	q12, [sp, #18144]
	ldr	q13, [sp, #18128]
	shl.2d	v25, v25, #10
	shl.2d	v4, v4, #10
	shl.2d	v5, v5, #10
	shl.2d	v24, v24, #10
	shl.2d	v17, v17, #5
	shl.2d	v26, v18, #5
	shl.2d	v19, v19, #5
	shl.2d	v3, v3, #5
	add.2d	v18, v24, v3
	add.2d	v19, v5, v19
	ldr	q5, [sp, #18112]
	add.2d	v26, v4, v26
	add.2d	v27, v25, v17
	add.2d	v3, v31, v11
	add.2d	v3, v3, v18
	add.2d	v4, v30, v12
	add.2d	v31, v4, v19
	add.2d	v4, v29, v13
	add.2d	v4, v4, v26
	add.2d	v5, v28, v5
	add.2d	v30, v5, v27
	movi.2d	v17, #0000000000000000
	movi.2d	v11, #0000000000000000
	tbnz	w3, #0, LBB0_451
; %bb.424:                              ; %else4246
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #1, LBB0_452
LBB0_425:                               ; %else4252
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #2, LBB0_453
LBB0_426:                               ; %else4258
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #3, LBB0_454
LBB0_427:                               ; %else4264
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #4, LBB0_455
LBB0_428:                               ; %else4270
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #5, LBB0_456
LBB0_429:                               ; %else4276
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #6, LBB0_457
LBB0_430:                               ; %else4282
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w3, #7, LBB0_432
LBB0_431:                               ; %cond.load4284
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v3[1]
	ld1.s	{ v11 }[3], [x3]
LBB0_432:                               ; %else4288
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q3, [sp, #17840]
	ldr	q5, [sp, #17824]
	ldr	q4, [sp, #17808]
	ldr	q24, [sp, #17792]
	ldr	q25, [sp, #17856]
	ldr	q28, [sp, #17872]
	ldr	q29, [sp, #17888]
	ldr	q30, [sp, #17904]
	add.2d	v24, v24, v25
	add.2d	v27, v24, v27
	add.2d	v4, v4, v28
	add.2d	v4, v4, v26
	add.2d	v5, v5, v29
	add.2d	v26, v5, v19
	add.2d	v3, v3, v30
	add.2d	v19, v3, v18
	fmov	w3, s16
	movi.2d	v3, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w3, #0, LBB0_458
; %bb.433:                              ; %else4295
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #1, LBB0_459
LBB0_434:                               ; %else4301
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #2, LBB0_460
LBB0_435:                               ; %else4307
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #3, LBB0_461
LBB0_436:                               ; %else4313
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #4, LBB0_462
LBB0_437:                               ; %else4319
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #5, LBB0_463
LBB0_438:                               ; %else4325
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #6, LBB0_464
LBB0_439:                               ; %else4331
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w3, #7, LBB0_441
LBB0_440:                               ; %cond.load4333
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v19[1]
	ld1.s	{ v18 }[3], [x3]
LBB0_441:                               ; %else4337
                                        ;   in Loop: Header=BB0_7 Depth=3
	fadd.4s	v17, v17, v3
	fadd.4s	v3, v11, v18
	ldr	q4, [sp, #17584]
	ldr	q5, [sp, #17568]
	ldr	q18, [sp, #17552]
	ldr	q19, [sp, #17536]
	ldr	q24, [sp, #17600]
	ldr	q25, [sp, #17616]
	ldr	q26, [sp, #17632]
	ldr	q27, [sp, #17648]
	ldr	q0, [sp, #1344]                 ; 16-byte Folded Reload
	shl.2d	v28, v0, #5
	ldr	q0, [sp, #1328]                 ; 16-byte Folded Reload
	shl.2d	v29, v0, #5
	ldr	q0, [sp, #928]                  ; 16-byte Folded Reload
	shl.2d	v30, v0, #5
	ldr	q0, [sp, #1312]                 ; 16-byte Folded Reload
	shl.2d	v31, v0, #5
	add.2d	v27, v27, v31
	add.2d	v30, v26, v30
	add.2d	v25, v25, v29
	add.2d	v24, v24, v28
	add.2d	v26, v19, v24
	add.2d	v19, v18, v25
	add.2d	v18, v5, v30
	add.2d	v4, v4, v27
	fmov	w3, s16
	tbnz	w3, #0, LBB0_465
; %bb.442:                              ; %else4343
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #1, LBB0_466
LBB0_443:                               ; %else4347
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q0, [sp, #1344]                 ; 16-byte Folded Reload
	ldr	q5, [sp, #1328]                 ; 16-byte Folded Reload
	ldr	q16, [sp, #1312]                ; 16-byte Folded Reload
	tbnz	w3, #2, LBB0_467
LBB0_444:                               ; %else4351
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #3, LBB0_468
LBB0_445:                               ; %else4355
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #4, LBB0_469
LBB0_446:                               ; %else4359
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #5, LBB0_470
LBB0_447:                               ; %else4363
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #6, LBB0_471
LBB0_448:                               ; %else4367
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w3, #7, LBB0_450
LBB0_449:                               ; %cond.store4368
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v4[1]
	st1.s	{ v3 }[3], [x3]
LBB0_450:                               ; %else4371
                                        ;   in Loop: Header=BB0_7 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v10, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v4, v3, #0
	ushll2.4s	v3, v3, #0
	uaddw2.2d	v16, v16, v3
	str	q16, [sp, #1312]                ; 16-byte Folded Spill
	ldr	q16, [sp, #928]                 ; 16-byte Folded Reload
	uaddw.2d	v16, v16, v3
	str	q16, [sp, #928]                 ; 16-byte Folded Spill
	uaddw2.2d	v5, v5, v4
	str	q5, [sp, #1328]                 ; 16-byte Folded Spill
	uaddw.2d	v0, v0, v4
	str	q0, [sp, #1344]                 ; 16-byte Folded Spill
	tbz	w2, #0, LBB0_415
	b	LBB0_5
LBB0_451:                               ; %cond.load4242
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d30
	ldr	s17, [x4]
	tbz	w3, #1, LBB0_425
LBB0_452:                               ; %cond.load4248
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v30[1]
	ld1.s	{ v17 }[1], [x4]
	tbz	w3, #2, LBB0_426
LBB0_453:                               ; %cond.load4254
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d4
	ld1.s	{ v17 }[2], [x4]
	tbz	w3, #3, LBB0_427
LBB0_454:                               ; %cond.load4260
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v4[1]
	ld1.s	{ v17 }[3], [x4]
	tbz	w3, #4, LBB0_428
LBB0_455:                               ; %cond.load4266
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d31
	ld1.s	{ v11 }[0], [x4]
	tbz	w3, #5, LBB0_429
LBB0_456:                               ; %cond.load4272
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v31[1]
	ld1.s	{ v11 }[1], [x4]
	tbz	w3, #6, LBB0_430
LBB0_457:                               ; %cond.load4278
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d3
	ld1.s	{ v11 }[2], [x4]
	tbnz	w3, #7, LBB0_431
	b	LBB0_432
LBB0_458:                               ; %cond.load4291
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d27
	ldr	s3, [x4]
	tbz	w3, #1, LBB0_434
LBB0_459:                               ; %cond.load4297
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v27[1]
	ld1.s	{ v3 }[1], [x4]
	tbz	w3, #2, LBB0_435
LBB0_460:                               ; %cond.load4303
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d4
	ld1.s	{ v3 }[2], [x4]
	tbz	w3, #3, LBB0_436
LBB0_461:                               ; %cond.load4309
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v4[1]
	ld1.s	{ v3 }[3], [x4]
	tbz	w3, #4, LBB0_437
LBB0_462:                               ; %cond.load4315
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d26
	ld1.s	{ v18 }[0], [x4]
	tbz	w3, #5, LBB0_438
LBB0_463:                               ; %cond.load4321
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v26[1]
	ld1.s	{ v18 }[1], [x4]
	tbz	w3, #6, LBB0_439
LBB0_464:                               ; %cond.load4327
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d19
	ld1.s	{ v18 }[2], [x4]
	tbnz	w3, #7, LBB0_440
	b	LBB0_441
LBB0_465:                               ; %cond.store4340
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d26
	str	s17, [x4]
	tbz	w3, #1, LBB0_443
LBB0_466:                               ; %cond.store4344
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v26[1]
	st1.s	{ v17 }[1], [x4]
	ldr	q0, [sp, #1344]                 ; 16-byte Folded Reload
	ldr	q5, [sp, #1328]                 ; 16-byte Folded Reload
	ldr	q16, [sp, #1312]                ; 16-byte Folded Reload
	tbz	w3, #2, LBB0_444
LBB0_467:                               ; %cond.store4348
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d19
	st1.s	{ v17 }[2], [x4]
	tbz	w3, #3, LBB0_445
LBB0_468:                               ; %cond.store4352
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v19[1]
	st1.s	{ v17 }[3], [x4]
	tbz	w3, #4, LBB0_446
LBB0_469:                               ; %cond.store4356
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d18
	str	s3, [x4]
	tbz	w3, #5, LBB0_447
LBB0_470:                               ; %cond.store4360
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v18[1]
	st1.s	{ v3 }[1], [x4]
	tbz	w3, #6, LBB0_448
LBB0_471:                               ; %cond.store4364
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d4
	st1.s	{ v3 }[2], [x4]
	tbnz	w3, #7, LBB0_449
	b	LBB0_450
LBB0_472:                               ; %varying.coherent.false445
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
LBB0_473:                               ; %schedule.21
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q0, [sp, #896]                  ; 16-byte Folded Reload
	cbz	w1, LBB0_478
; %bb.474:                              ; %convergence.cascade453.preheader
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
LBB0_475:                               ; %convergence.cascade453
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_7 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w10, s4
	umaxv.8b	b3, v3
	fmov	w6, s3
	sub	w3, w1, #1
	tst	w10, #0xff
	csel	w4, w3, wzr, ne
	mov	w10, #1                         ; =0x1
	lsl	w5, w10, w4
	and	w10, w5, w17
	tst	w10, #0xff
	cset	w10, ne
	str	q9, [sp, #11392]
	str	q8, [sp, #11408]
	ubfiz	x3, x4, #2, #3
	add	x7, sp, #2, lsl #12             ; =8192
	add	x7, x7, #3200
	ldr	w7, [x7, x3]
	cmp	w7, #7
	cset	w7, eq
	and	w19, w10, w6
	add	x6, sp, #18, lsl #12            ; =73728
	add	x6, x6, #752
	ldrb	w10, [x6, w4, sxtw]
	and	w20, w10, #0x1
	fmov	s3, w20
	ubfx	w20, w10, #1, #1
	mov.b	v3[1], w20
	ubfx	w20, w10, #2, #1
	mov.b	v3[2], w20
	ubfx	w20, w10, #3, #1
	mov.b	v3[3], w20
	ubfx	w20, w10, #4, #1
	mov.b	v3[4], w20
	ubfx	w20, w10, #5, #1
	mov.b	v3[5], w20
	ubfx	w20, w10, #6, #1
	mov.b	v3[6], w20
	add	x20, sp, #18, lsl #12           ; =73728
	add	x20, x20, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x20, w4, sxtw]
	and	w21, w10, #0x1
	fmov	s4, w21
	ubfx	w21, w10, #1, #1
	mov.b	v4[1], w21
	ubfx	w21, w10, #2, #1
	mov.b	v4[2], w21
	ubfx	w21, w10, #3, #1
	mov.b	v4[3], w21
	ubfx	w21, w10, #4, #1
	mov.b	v4[4], w21
	ubfx	w21, w10, #5, #1
	mov.b	v4[5], w21
	ubfx	w21, w10, #6, #1
	mov.b	v4[6], w21
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	orr.8b	v5, v10, v4
	and.8b	v16, v1, v3
	eor.8b	v16, v16, v5
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	umaxv.8b	b16, v16
	fmov	w10, s16
	ands	w7, w19, w7
	csetm	w19, ne
	bics	w10, w7, w10
	csetm	w21, ne
	dup.8b	v16, w21
	bic.8b	v17, v5, v16
	dup.8b	v18, w19
	bit.8b	v4, v17, v18
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x20, w4, sxtw]
	bic.8b	v3, v3, v16
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x6, w4, sxtw]
	mov	w4, #-1                         ; =0xffffffff
	csinv	w4, w4, w5, eq
	and	w17, w4, w17
	dup.8b	v3, w7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v4, w10
	and.8b	v4, v4, v5
	str	q7, [sp, #11360]
	str	q6, [sp, #11376]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #3168
	ldr	w10, [x10, x3]
	csel	w1, w10, w1, ne
	bit.8b	v10, v4, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	cmp	w7, #1
	b.ne	LBB0_479
; %bb.476:                              ; %convergence.cascade453
                                        ;   in Loop: Header=BB0_475 Depth=4
	cmp	w1, #0
	ccmp	w2, #6, #2, ne
	b.hi	LBB0_479
; %bb.477:                              ; %convergence.cascade453
                                        ;   in Loop: Header=BB0_475 Depth=4
	add	w2, w2, #1
	tst	w3, #0xff
	b.ne	LBB0_475
	b	LBB0_479
LBB0_478:                               ; %schedule.21.convergence.cascade.exit454_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
LBB0_479:                               ; %convergence.cascade.exit454
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
; %bb.480:                              ; %convergence.target.21.ready
                                        ;   in Loop: Header=BB0_7 Depth=3
	rbit	w10, w3
	clz	w2, w10
	ldr	q3, [sp, #17504]
	ldr	q4, [sp, #17520]
	ldr	q5, [sp, #17472]
	ldr	q16, [sp, #17488]
	ldr	q17, [sp, #17440]
	ldr	q18, [sp, #17456]
	ldr	q19, [sp, #17408]
	ldr	q22, [sp, #17424]
	mov	b23, v10[2]
	mov.b	v23[4], v10[3]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v11, v23, #0
	ldr	q24, [sp, #304]                 ; 16-byte Folded Reload
	bit.16b	v22, v24, v11
	mov	b23, v10[0]
	mov.b	v23[4], v10[1]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v12, v23, #0
	bit.16b	v19, v24, v12
	mov	b23, v10[6]
	mov.b	v23[4], v10[7]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v13, v23, #0
	mov	b23, v10[4]
	mov.b	v23[4], v10[5]
	bit.16b	v18, v24, v13
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v14, v23, #0
	bit.16b	v17, v24, v14
Lloh586:
	adrp	x10, lCPI0_20@PAGE
Lloh587:
	ldr	q23, [x10, lCPI0_20@PAGEOFF]
	bit.16b	v16, v23, v11
Lloh588:
	adrp	x10, lCPI0_21@PAGE
Lloh589:
	ldr	q24, [x10, lCPI0_21@PAGEOFF]
	bit.16b	v5, v24, v12
Lloh590:
	adrp	x10, lCPI0_22@PAGE
Lloh591:
	ldr	q25, [x10, lCPI0_22@PAGEOFF]
	bit.16b	v4, v25, v13
Lloh592:
	adrp	x10, lCPI0_23@PAGE
Lloh593:
	ldr	q26, [x10, lCPI0_23@PAGEOFF]
	bit.16b	v3, v26, v14
	str	q3, [sp, #17504]
	str	q4, [sp, #17520]
	str	q5, [sp, #17472]
	str	q16, [sp, #17488]
	str	q17, [sp, #17440]
	str	q18, [sp, #17456]
	str	q19, [sp, #17408]
	str	q22, [sp, #17424]
	str	q25, [sp, #9360]
	str	q26, [sp, #9344]
	str	q23, [sp, #9328]
	str	q24, [sp, #9312]
	lsl	w10, w2, #3
	and	x2, x10, #0x38
	add	x3, sp, #2, lsl #12             ; =8192
	add	x3, x3, #1120
	ldr	x5, [x3, x2]
	and	x3, x10, #0xf8
	add	x4, sp, #11, lsl #12            ; =45056
	add	x4, x4, #2664
	sub	x10, x5, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10, #32]
	ldp	q5, q16, [x10]
	mov	x5, #-4                         ; =0xfffffffffffffffc
	dup.2d	v17, x5
	bit.16b	v16, v17, v11
	bit.16b	v5, v17, v12
	bit.16b	v4, v17, v13
	bit.16b	v3, v17, v14
	stp	q3, q4, [x10, #32]
	stp	q5, q16, [x10]
Lloh594:
	adrp	x10, lCPI0_24@PAGE
Lloh595:
	ldr	q3, [x10, lCPI0_24@PAGEOFF]
Lloh596:
	adrp	x10, lCPI0_25@PAGE
Lloh597:
	ldr	q4, [x10, lCPI0_25@PAGEOFF]
	str	q3, [sp, #9424]
	str	q4, [sp, #9408]
Lloh598:
	adrp	x10, lCPI0_26@PAGE
Lloh599:
	ldr	q3, [x10, lCPI0_26@PAGEOFF]
Lloh600:
	adrp	x10, lCPI0_27@PAGE
Lloh601:
	ldr	q4, [x10, lCPI0_27@PAGEOFF]
	str	q3, [sp, #9392]
	str	q4, [sp, #9376]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #1184
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	x5, #-3                         ; =0xfffffffffffffffd
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh602:
	adrp	x10, lCPI0_28@PAGE
Lloh603:
	ldr	q3, [x10, lCPI0_28@PAGEOFF]
Lloh604:
	adrp	x10, lCPI0_29@PAGE
Lloh605:
	ldr	q4, [x10, lCPI0_29@PAGEOFF]
	str	q3, [sp, #9488]
	str	q4, [sp, #9472]
Lloh606:
	adrp	x10, lCPI0_30@PAGE
Lloh607:
	ldr	q3, [x10, lCPI0_30@PAGEOFF]
Lloh608:
	adrp	x10, lCPI0_31@PAGE
Lloh609:
	ldr	q4, [x10, lCPI0_31@PAGEOFF]
	str	q3, [sp, #9456]
	str	q4, [sp, #9440]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #1248
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	x5, #-2                         ; =0xfffffffffffffffe
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh610:
	adrp	x10, lCPI0_32@PAGE
Lloh611:
	ldr	q3, [x10, lCPI0_32@PAGEOFF]
Lloh612:
	adrp	x10, lCPI0_33@PAGE
Lloh613:
	ldr	q4, [x10, lCPI0_33@PAGEOFF]
	str	q3, [sp, #9552]
	str	q4, [sp, #9536]
Lloh614:
	adrp	x10, lCPI0_34@PAGE
Lloh615:
	ldr	q3, [x10, lCPI0_34@PAGEOFF]
Lloh616:
	adrp	x10, lCPI0_35@PAGE
Lloh617:
	ldr	q4, [x10, lCPI0_35@PAGEOFF]
	str	q3, [sp, #9520]
	str	q4, [sp, #9504]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #1312
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	orr.16b	v16, v14, v16
	orr.16b	v4, v11, v4
	orr.16b	v3, v12, v3
	orr.16b	v5, v13, v5
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh618:
	adrp	x10, lCPI0_36@PAGE
Lloh619:
	ldr	q3, [x10, lCPI0_36@PAGEOFF]
Lloh620:
	adrp	x10, lCPI0_37@PAGE
Lloh621:
	ldr	q4, [x10, lCPI0_37@PAGEOFF]
	str	q3, [sp, #9616]
	str	q4, [sp, #9600]
Lloh622:
	adrp	x10, lCPI0_38@PAGE
Lloh623:
	ldr	q3, [x10, lCPI0_38@PAGEOFF]
Lloh624:
	adrp	x10, lCPI0_39@PAGE
Lloh625:
	ldr	q4, [x10, lCPI0_39@PAGEOFF]
	str	q3, [sp, #9584]
	str	q4, [sp, #9568]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #1376
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	bic.16b	v16, v16, v14
	bic.16b	v4, v4, v11
	bic.16b	v3, v3, v12
	bic.16b	v5, v5, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh626:
	adrp	x10, lCPI0_40@PAGE
Lloh627:
	ldr	q3, [x10, lCPI0_40@PAGEOFF]
Lloh628:
	adrp	x10, lCPI0_41@PAGE
Lloh629:
	ldr	q4, [x10, lCPI0_41@PAGEOFF]
	str	q3, [sp, #9680]
	str	q4, [sp, #9664]
Lloh630:
	adrp	x10, lCPI0_42@PAGE
Lloh631:
	ldr	q3, [x10, lCPI0_42@PAGEOFF]
Lloh632:
	adrp	x10, lCPI0_43@PAGE
Lloh633:
	ldr	q4, [x10, lCPI0_43@PAGEOFF]
	str	q3, [sp, #9648]
	str	q4, [sp, #9632]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #1440
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	bic.16b	v16, v16, v14
	sub.2d	v16, v16, v14
	bic.16b	v4, v4, v11
	sub.2d	v4, v4, v11
	bic.16b	v3, v3, v12
	sub.2d	v3, v3, v12
	bic.16b	v5, v5, v13
	sub.2d	v5, v5, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh634:
	adrp	x10, lCPI0_44@PAGE
Lloh635:
	ldr	q3, [x10, lCPI0_44@PAGEOFF]
Lloh636:
	adrp	x10, lCPI0_45@PAGE
Lloh637:
	ldr	q4, [x10, lCPI0_45@PAGEOFF]
	str	q3, [sp, #9744]
	str	q4, [sp, #9728]
Lloh638:
	adrp	x10, lCPI0_46@PAGE
Lloh639:
	ldr	q3, [x10, lCPI0_46@PAGEOFF]
Lloh640:
	adrp	x10, lCPI0_47@PAGE
Lloh641:
	ldr	q4, [x10, lCPI0_47@PAGEOFF]
	str	q3, [sp, #9712]
	str	q4, [sp, #9696]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #1504
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #2                          ; =0x2
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh642:
	adrp	x10, lCPI0_48@PAGE
Lloh643:
	ldr	q3, [x10, lCPI0_48@PAGEOFF]
Lloh644:
	adrp	x10, lCPI0_49@PAGE
Lloh645:
	ldr	q4, [x10, lCPI0_49@PAGEOFF]
	str	q3, [sp, #9808]
	str	q4, [sp, #9792]
Lloh646:
	adrp	x10, lCPI0_50@PAGE
Lloh647:
	ldr	q3, [x10, lCPI0_50@PAGEOFF]
Lloh648:
	adrp	x10, lCPI0_51@PAGE
Lloh649:
	ldr	q4, [x10, lCPI0_51@PAGEOFF]
	str	q3, [sp, #9776]
	str	q4, [sp, #9760]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #1568
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #3                          ; =0x3
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh650:
	adrp	x10, lCPI0_52@PAGE
Lloh651:
	ldr	q3, [x10, lCPI0_52@PAGEOFF]
Lloh652:
	adrp	x10, lCPI0_53@PAGE
Lloh653:
	ldr	q4, [x10, lCPI0_53@PAGEOFF]
	str	q3, [sp, #9872]
	str	q4, [sp, #9856]
Lloh654:
	adrp	x10, lCPI0_54@PAGE
Lloh655:
	ldr	q3, [x10, lCPI0_54@PAGEOFF]
Lloh656:
	adrp	x10, lCPI0_55@PAGE
Lloh657:
	ldr	q4, [x10, lCPI0_55@PAGEOFF]
	str	q3, [sp, #9840]
	str	q4, [sp, #9824]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #1632
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #4                          ; =0x4
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh658:
	adrp	x10, lCPI0_56@PAGE
Lloh659:
	ldr	q3, [x10, lCPI0_56@PAGEOFF]
Lloh660:
	adrp	x10, lCPI0_57@PAGE
Lloh661:
	ldr	q4, [x10, lCPI0_57@PAGEOFF]
	str	q3, [sp, #9936]
	str	q4, [sp, #9920]
Lloh662:
	adrp	x10, lCPI0_58@PAGE
Lloh663:
	ldr	q3, [x10, lCPI0_58@PAGEOFF]
Lloh664:
	adrp	x10, lCPI0_59@PAGE
Lloh665:
	ldr	q4, [x10, lCPI0_59@PAGEOFF]
	str	q3, [sp, #9904]
	str	q4, [sp, #9888]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #1696
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #5                          ; =0x5
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh666:
	adrp	x10, lCPI0_60@PAGE
Lloh667:
	ldr	q3, [x10, lCPI0_60@PAGEOFF]
Lloh668:
	adrp	x10, lCPI0_61@PAGE
Lloh669:
	ldr	q4, [x10, lCPI0_61@PAGEOFF]
	str	q3, [sp, #10000]
	str	q4, [sp, #9984]
Lloh670:
	adrp	x10, lCPI0_62@PAGE
Lloh671:
	ldr	q3, [x10, lCPI0_62@PAGEOFF]
Lloh672:
	adrp	x10, lCPI0_63@PAGE
Lloh673:
	ldr	q4, [x10, lCPI0_63@PAGEOFF]
	str	q3, [sp, #9968]
	str	q4, [sp, #9952]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #1760
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #6                          ; =0x6
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh674:
	adrp	x10, lCPI0_64@PAGE
Lloh675:
	ldr	q3, [x10, lCPI0_64@PAGEOFF]
Lloh676:
	adrp	x10, lCPI0_65@PAGE
Lloh677:
	ldr	q4, [x10, lCPI0_65@PAGEOFF]
	str	q3, [sp, #10064]
	str	q4, [sp, #10048]
Lloh678:
	adrp	x10, lCPI0_66@PAGE
Lloh679:
	ldr	q3, [x10, lCPI0_66@PAGEOFF]
Lloh680:
	adrp	x10, lCPI0_67@PAGE
Lloh681:
	ldr	q4, [x10, lCPI0_67@PAGEOFF]
	str	q3, [sp, #10032]
	str	q4, [sp, #10016]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #1824
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #7                          ; =0x7
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh682:
	adrp	x10, lCPI0_68@PAGE
Lloh683:
	ldr	q3, [x10, lCPI0_68@PAGEOFF]
Lloh684:
	adrp	x10, lCPI0_69@PAGE
Lloh685:
	ldr	q4, [x10, lCPI0_69@PAGEOFF]
	str	q3, [sp, #10128]
	str	q4, [sp, #10112]
Lloh686:
	adrp	x10, lCPI0_70@PAGE
Lloh687:
	ldr	q3, [x10, lCPI0_70@PAGEOFF]
Lloh688:
	adrp	x10, lCPI0_71@PAGE
Lloh689:
	ldr	q4, [x10, lCPI0_71@PAGEOFF]
	str	q3, [sp, #10096]
	str	q4, [sp, #10080]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #1888
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #8                          ; =0x8
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh690:
	adrp	x10, lCPI0_72@PAGE
Lloh691:
	ldr	q3, [x10, lCPI0_72@PAGEOFF]
Lloh692:
	adrp	x10, lCPI0_73@PAGE
Lloh693:
	ldr	q4, [x10, lCPI0_73@PAGEOFF]
	str	q3, [sp, #10192]
	str	q4, [sp, #10176]
Lloh694:
	adrp	x10, lCPI0_74@PAGE
Lloh695:
	ldr	q3, [x10, lCPI0_74@PAGEOFF]
Lloh696:
	adrp	x10, lCPI0_75@PAGE
Lloh697:
	ldr	q4, [x10, lCPI0_75@PAGEOFF]
	str	q3, [sp, #10160]
	str	q4, [sp, #10144]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #1952
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #9                          ; =0x9
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh698:
	adrp	x10, lCPI0_76@PAGE
Lloh699:
	ldr	q3, [x10, lCPI0_76@PAGEOFF]
Lloh700:
	adrp	x10, lCPI0_77@PAGE
Lloh701:
	ldr	q4, [x10, lCPI0_77@PAGEOFF]
	str	q3, [sp, #10256]
	str	q4, [sp, #10240]
Lloh702:
	adrp	x10, lCPI0_78@PAGE
Lloh703:
	ldr	q3, [x10, lCPI0_78@PAGEOFF]
Lloh704:
	adrp	x10, lCPI0_79@PAGE
Lloh705:
	ldr	q4, [x10, lCPI0_79@PAGEOFF]
	str	q3, [sp, #10224]
	str	q4, [sp, #10208]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #2016
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #10                         ; =0xa
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh706:
	adrp	x10, lCPI0_80@PAGE
Lloh707:
	ldr	q3, [x10, lCPI0_80@PAGEOFF]
Lloh708:
	adrp	x10, lCPI0_81@PAGE
Lloh709:
	ldr	q4, [x10, lCPI0_81@PAGEOFF]
	str	q3, [sp, #10320]
	str	q4, [sp, #10304]
Lloh710:
	adrp	x10, lCPI0_82@PAGE
Lloh711:
	ldr	q3, [x10, lCPI0_82@PAGEOFF]
Lloh712:
	adrp	x10, lCPI0_83@PAGE
Lloh713:
	ldr	q4, [x10, lCPI0_83@PAGEOFF]
	str	q3, [sp, #10288]
	str	q4, [sp, #10272]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #2080
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #11                         ; =0xb
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh714:
	adrp	x10, lCPI0_84@PAGE
Lloh715:
	ldr	q3, [x10, lCPI0_84@PAGEOFF]
Lloh716:
	adrp	x10, lCPI0_85@PAGE
Lloh717:
	ldr	q4, [x10, lCPI0_85@PAGEOFF]
	str	q3, [sp, #10384]
	str	q4, [sp, #10368]
Lloh718:
	adrp	x10, lCPI0_86@PAGE
Lloh719:
	ldr	q3, [x10, lCPI0_86@PAGEOFF]
Lloh720:
	adrp	x10, lCPI0_87@PAGE
Lloh721:
	ldr	q4, [x10, lCPI0_87@PAGEOFF]
	str	q3, [sp, #10352]
	str	q4, [sp, #10336]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #2144
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #12                         ; =0xc
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh722:
	adrp	x10, lCPI0_88@PAGE
Lloh723:
	ldr	q3, [x10, lCPI0_88@PAGEOFF]
Lloh724:
	adrp	x10, lCPI0_89@PAGE
Lloh725:
	ldr	q4, [x10, lCPI0_89@PAGEOFF]
	str	q3, [sp, #10448]
	str	q4, [sp, #10432]
Lloh726:
	adrp	x10, lCPI0_90@PAGE
Lloh727:
	ldr	q3, [x10, lCPI0_90@PAGEOFF]
Lloh728:
	adrp	x10, lCPI0_91@PAGE
Lloh729:
	ldr	q4, [x10, lCPI0_91@PAGEOFF]
	str	q3, [sp, #10416]
	str	q4, [sp, #10400]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #2208
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #13                         ; =0xd
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh730:
	adrp	x10, lCPI0_92@PAGE
Lloh731:
	ldr	q3, [x10, lCPI0_92@PAGEOFF]
Lloh732:
	adrp	x10, lCPI0_93@PAGE
Lloh733:
	ldr	q4, [x10, lCPI0_93@PAGEOFF]
	str	q3, [sp, #10512]
	str	q4, [sp, #10496]
Lloh734:
	adrp	x10, lCPI0_94@PAGE
Lloh735:
	ldr	q3, [x10, lCPI0_94@PAGEOFF]
Lloh736:
	adrp	x10, lCPI0_95@PAGE
Lloh737:
	ldr	q4, [x10, lCPI0_95@PAGEOFF]
	str	q3, [sp, #10480]
	str	q4, [sp, #10464]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #2272
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #14                         ; =0xe
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh738:
	adrp	x10, lCPI0_96@PAGE
Lloh739:
	ldr	q3, [x10, lCPI0_96@PAGEOFF]
Lloh740:
	adrp	x10, lCPI0_97@PAGE
Lloh741:
	ldr	q4, [x10, lCPI0_97@PAGEOFF]
	str	q3, [sp, #10576]
	str	q4, [sp, #10560]
Lloh742:
	adrp	x10, lCPI0_98@PAGE
Lloh743:
	ldr	q3, [x10, lCPI0_98@PAGEOFF]
Lloh744:
	adrp	x10, lCPI0_99@PAGE
Lloh745:
	ldr	q4, [x10, lCPI0_99@PAGEOFF]
	str	q3, [sp, #10544]
	str	q4, [sp, #10528]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #2336
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #15                         ; =0xf
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh746:
	adrp	x10, lCPI0_100@PAGE
Lloh747:
	ldr	q3, [x10, lCPI0_100@PAGEOFF]
Lloh748:
	adrp	x10, lCPI0_101@PAGE
Lloh749:
	ldr	q4, [x10, lCPI0_101@PAGEOFF]
	str	q3, [sp, #10640]
	str	q4, [sp, #10624]
Lloh750:
	adrp	x10, lCPI0_102@PAGE
Lloh751:
	ldr	q3, [x10, lCPI0_102@PAGEOFF]
Lloh752:
	adrp	x10, lCPI0_103@PAGE
Lloh753:
	ldr	q4, [x10, lCPI0_103@PAGEOFF]
	str	q3, [sp, #10608]
	str	q4, [sp, #10592]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #2400
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #16                         ; =0x10
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh754:
	adrp	x10, lCPI0_104@PAGE
Lloh755:
	ldr	q3, [x10, lCPI0_104@PAGEOFF]
Lloh756:
	adrp	x10, lCPI0_105@PAGE
Lloh757:
	ldr	q4, [x10, lCPI0_105@PAGEOFF]
	str	q3, [sp, #10704]
	str	q4, [sp, #10688]
Lloh758:
	adrp	x10, lCPI0_106@PAGE
Lloh759:
	ldr	q3, [x10, lCPI0_106@PAGEOFF]
Lloh760:
	adrp	x10, lCPI0_107@PAGE
Lloh761:
	ldr	q4, [x10, lCPI0_107@PAGEOFF]
	str	q3, [sp, #10672]
	str	q4, [sp, #10656]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #2464
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #17                         ; =0x11
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh762:
	adrp	x10, lCPI0_108@PAGE
Lloh763:
	ldr	q3, [x10, lCPI0_108@PAGEOFF]
Lloh764:
	adrp	x10, lCPI0_109@PAGE
Lloh765:
	ldr	q4, [x10, lCPI0_109@PAGEOFF]
	str	q3, [sp, #10768]
	str	q4, [sp, #10752]
Lloh766:
	adrp	x10, lCPI0_110@PAGE
Lloh767:
	ldr	q3, [x10, lCPI0_110@PAGEOFF]
Lloh768:
	adrp	x10, lCPI0_111@PAGE
Lloh769:
	ldr	q4, [x10, lCPI0_111@PAGEOFF]
	str	q3, [sp, #10736]
	str	q4, [sp, #10720]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #2528
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #18                         ; =0x12
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh770:
	adrp	x10, lCPI0_112@PAGE
Lloh771:
	ldr	q3, [x10, lCPI0_112@PAGEOFF]
Lloh772:
	adrp	x10, lCPI0_113@PAGE
Lloh773:
	ldr	q4, [x10, lCPI0_113@PAGEOFF]
	str	q3, [sp, #10832]
	str	q4, [sp, #10816]
Lloh774:
	adrp	x10, lCPI0_114@PAGE
Lloh775:
	ldr	q3, [x10, lCPI0_114@PAGEOFF]
Lloh776:
	adrp	x10, lCPI0_115@PAGE
Lloh777:
	ldr	q4, [x10, lCPI0_115@PAGEOFF]
	str	q3, [sp, #10800]
	str	q4, [sp, #10784]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #2592
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #19                         ; =0x13
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh778:
	adrp	x10, lCPI0_116@PAGE
Lloh779:
	ldr	q3, [x10, lCPI0_116@PAGEOFF]
Lloh780:
	adrp	x10, lCPI0_117@PAGE
Lloh781:
	ldr	q4, [x10, lCPI0_117@PAGEOFF]
	str	q3, [sp, #10896]
	str	q4, [sp, #10880]
Lloh782:
	adrp	x10, lCPI0_118@PAGE
Lloh783:
	ldr	q3, [x10, lCPI0_118@PAGEOFF]
Lloh784:
	adrp	x10, lCPI0_119@PAGE
Lloh785:
	ldr	q4, [x10, lCPI0_119@PAGEOFF]
	str	q3, [sp, #10864]
	str	q4, [sp, #10848]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #2656
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #20                         ; =0x14
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh786:
	adrp	x10, lCPI0_120@PAGE
Lloh787:
	ldr	q3, [x10, lCPI0_120@PAGEOFF]
Lloh788:
	adrp	x10, lCPI0_121@PAGE
Lloh789:
	ldr	q4, [x10, lCPI0_121@PAGEOFF]
	str	q3, [sp, #10960]
	str	q4, [sp, #10944]
Lloh790:
	adrp	x10, lCPI0_122@PAGE
Lloh791:
	ldr	q3, [x10, lCPI0_122@PAGEOFF]
Lloh792:
	adrp	x10, lCPI0_123@PAGE
Lloh793:
	ldr	q4, [x10, lCPI0_123@PAGEOFF]
	str	q3, [sp, #10928]
	str	q4, [sp, #10912]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #2720
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #21                         ; =0x15
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh794:
	adrp	x10, lCPI0_124@PAGE
Lloh795:
	ldr	q3, [x10, lCPI0_124@PAGEOFF]
Lloh796:
	adrp	x10, lCPI0_125@PAGE
Lloh797:
	ldr	q4, [x10, lCPI0_125@PAGEOFF]
	str	q3, [sp, #11024]
	str	q4, [sp, #11008]
Lloh798:
	adrp	x10, lCPI0_126@PAGE
Lloh799:
	ldr	q3, [x10, lCPI0_126@PAGEOFF]
Lloh800:
	adrp	x10, lCPI0_127@PAGE
Lloh801:
	ldr	q4, [x10, lCPI0_127@PAGEOFF]
	str	q3, [sp, #10992]
	str	q4, [sp, #10976]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #2784
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #22                         ; =0x16
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh802:
	adrp	x10, lCPI0_128@PAGE
Lloh803:
	ldr	q3, [x10, lCPI0_128@PAGEOFF]
Lloh804:
	adrp	x10, lCPI0_129@PAGE
Lloh805:
	ldr	q4, [x10, lCPI0_129@PAGEOFF]
	str	q3, [sp, #11088]
	str	q4, [sp, #11072]
Lloh806:
	adrp	x10, lCPI0_130@PAGE
Lloh807:
	ldr	q3, [x10, lCPI0_130@PAGEOFF]
Lloh808:
	adrp	x10, lCPI0_131@PAGE
Lloh809:
	ldr	q4, [x10, lCPI0_131@PAGEOFF]
	str	q3, [sp, #11056]
	str	q4, [sp, #11040]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #2848
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #23                         ; =0x17
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh810:
	adrp	x10, lCPI0_132@PAGE
Lloh811:
	ldr	q3, [x10, lCPI0_132@PAGEOFF]
Lloh812:
	adrp	x10, lCPI0_133@PAGE
Lloh813:
	ldr	q4, [x10, lCPI0_133@PAGEOFF]
	str	q3, [sp, #11152]
	str	q4, [sp, #11136]
Lloh814:
	adrp	x10, lCPI0_134@PAGE
Lloh815:
	ldr	q3, [x10, lCPI0_134@PAGEOFF]
Lloh816:
	adrp	x10, lCPI0_135@PAGE
Lloh817:
	ldr	q4, [x10, lCPI0_135@PAGEOFF]
	str	q3, [sp, #11120]
	str	q4, [sp, #11104]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #2912
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #24                         ; =0x18
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh818:
	adrp	x10, lCPI0_136@PAGE
Lloh819:
	ldr	q3, [x10, lCPI0_136@PAGEOFF]
Lloh820:
	adrp	x10, lCPI0_137@PAGE
Lloh821:
	ldr	q4, [x10, lCPI0_137@PAGEOFF]
	str	q3, [sp, #11216]
	str	q4, [sp, #11200]
Lloh822:
	adrp	x10, lCPI0_138@PAGE
Lloh823:
	ldr	q3, [x10, lCPI0_138@PAGEOFF]
Lloh824:
	adrp	x10, lCPI0_139@PAGE
Lloh825:
	ldr	q4, [x10, lCPI0_139@PAGEOFF]
	str	q3, [sp, #11184]
	str	q4, [sp, #11168]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #2976
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #25                         ; =0x19
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh826:
	adrp	x10, lCPI0_140@PAGE
Lloh827:
	ldr	q3, [x10, lCPI0_140@PAGEOFF]
Lloh828:
	adrp	x10, lCPI0_141@PAGE
Lloh829:
	ldr	q4, [x10, lCPI0_141@PAGEOFF]
	str	q3, [sp, #11280]
	str	q4, [sp, #11264]
Lloh830:
	adrp	x10, lCPI0_142@PAGE
Lloh831:
	ldr	q3, [x10, lCPI0_142@PAGEOFF]
Lloh832:
	adrp	x10, lCPI0_143@PAGE
Lloh833:
	ldr	q4, [x10, lCPI0_143@PAGEOFF]
	str	q3, [sp, #11248]
	str	q4, [sp, #11232]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #3040
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #26                         ; =0x1a
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh834:
	adrp	x10, lCPI0_144@PAGE
Lloh835:
	ldr	q3, [x10, lCPI0_144@PAGEOFF]
Lloh836:
	adrp	x10, lCPI0_145@PAGE
Lloh837:
	ldr	q4, [x10, lCPI0_145@PAGEOFF]
	str	q3, [sp, #11344]
	str	q4, [sp, #11328]
Lloh838:
	adrp	x10, lCPI0_146@PAGE
Lloh839:
	ldr	q3, [x10, lCPI0_146@PAGEOFF]
Lloh840:
	adrp	x10, lCPI0_147@PAGE
Lloh841:
	ldr	q4, [x10, lCPI0_147@PAGEOFF]
	str	q3, [sp, #11312]
	str	q4, [sp, #11296]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #3104
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w2, #27                         ; =0x1b
	dup.2d	v17, x2
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
	ldr	q3, [sp, #17376]
	ldr	q4, [sp, #17392]
	ldr	q5, [sp, #17344]
	ldr	q16, [sp, #17360]
	ldr	q17, [sp, #17312]
	ldr	q18, [sp, #17328]
	ldr	q19, [sp, #17280]
	ldr	q22, [sp, #17296]
	ldr	q23, [sp, #288]                 ; 16-byte Folded Reload
	bit.16b	v22, v23, v11
	bit.16b	v19, v23, v12
	bit.16b	v18, v23, v13
	bit.16b	v17, v23, v14
Lloh842:
	adrp	x10, lCPI0_17@PAGE
Lloh843:
	ldr	q23, [x10, lCPI0_17@PAGEOFF]
	bit.16b	v16, v23, v11
Lloh844:
	adrp	x10, lCPI0_16@PAGE
Lloh845:
	ldr	q23, [x10, lCPI0_16@PAGEOFF]
	bit.16b	v5, v23, v12
Lloh846:
	adrp	x10, lCPI0_19@PAGE
Lloh847:
	ldr	q23, [x10, lCPI0_19@PAGEOFF]
	bit.16b	v4, v23, v13
Lloh848:
	adrp	x10, lCPI0_18@PAGE
Lloh849:
	ldr	q23, [x10, lCPI0_18@PAGEOFF]
	bit.16b	v3, v23, v14
	str	q3, [sp, #17376]
	str	q4, [sp, #17392]
	str	q5, [sp, #17344]
	str	q16, [sp, #17360]
	str	q17, [sp, #17312]
	str	q18, [sp, #17328]
	str	q19, [sp, #17280]
	str	q22, [sp, #17296]
	ldr	q3, [sp, #1072]                 ; 16-byte Folded Reload
	bic.16b	v3, v3, v13
	str	q3, [sp, #1072]                 ; 16-byte Folded Spill
	bic.16b	v0, v0, v14
	str	q0, [sp, #896]                  ; 16-byte Folded Spill
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	bic.16b	v0, v0, v11
	str	q0, [sp, #1088]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	bic.16b	v0, v0, v12
LBB0_481:                               ; %schedule.22
                                        ;   in Loop: Header=BB0_7 Depth=3
	str	q0, [sp, #1104]                 ; 16-byte Folded Spill
LBB0_482:                               ; %schedule.22
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	mov	w2, #128                        ; =0x80
	dup.2d	v3, x2
	ldr	q17, [sp, #1088]                ; 16-byte Folded Reload
	cmgt.2d	v4, v3, v17
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	cmgt.2d	v5, v3, v0
	uzp1.4s	v4, v5, v4
	ldr	q18, [sp, #896]                 ; 16-byte Folded Reload
	cmgt.2d	v5, v3, v18
	ldr	q19, [sp, #1072]                ; 16-byte Folded Reload
	cmgt.2d	v16, v3, v19
	uzp1.4s	v5, v5, v16
	uzp1.8h	v4, v4, v5
	xtn.8b	v4, v4
	and.8b	v11, v10, v4
	shl.8b	v4, v11, #7
	cmlt.8b	v4, v4, #0
	and.8b	v5, v4, v2
	addv.8b	b5, v5
	fmov	w2, s5
	umaxv.8b	b4, v4
	fmov	w4, s4
	tbz	w4, #0, LBB0_488
; %bb.483:                              ; %schedule.22
                                        ;   in Loop: Header=BB0_7 Depth=3
	cmge.2d	v4, v17, v3
	cmge.2d	v5, v0, v3
	uzp1.4s	v4, v5, v4
	cmge.2d	v5, v18, v3
	cmge.2d	v3, v19, v3
	uzp1.4s	v3, v5, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v12, v10, v3
	shl.8b	v3, v12, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w4, s3
	tst	w4, #0xff
	b.eq	LBB0_488
; %bb.484:                              ; %varying.divergent535
                                        ;   in Loop: Header=BB0_7 Depth=3
	subs	w10, w1, #1
	csel	w10, wzr, w10, lo
	and	w3, w17, #0xff
	lsr	w2, w3, w10
	tst	w2, #0x1
	str	q9, [sp, #3040]
	str	q8, [sp, #3056]
	and	x10, x10, #0x7
	add	x2, sp, #3040
	ldr	w10, [x2, x10, lsl #2]
	ccmp	w1, #0, #4, ne
	ccmp	w10, #8, #0, ne
	cset	w2, ne
	cmp	w3, #255
	b.ne	LBB0_486
; %bb.485:                              ; %varying.divergent535
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w2, #0, LBB0_486
	b	LBB0_1006
LBB0_486:                               ; %convergence.overflow.resume538
                                        ;   in Loop: Header=BB0_7 Depth=3
	mvn	w10, w17
	rbit	w10, w10
	clz	w10, w10
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w17
	csel	w4, wzr, w10, eq
	add	x3, sp, #18, lsl #12            ; =73728
	add	x3, x3, #752
	ldrb	w10, [x3, w4, uxtw]
	and	w5, w10, #0x1
	fmov	s3, w5
	ubfx	w5, w10, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w10, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w10, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w10, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w10, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w10, #6, #1
	mov.b	v3[6], w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x5, w4, uxtw]
	and	w6, w10, #0x1
	fmov	s4, w6
	ubfx	w6, w10, #1, #1
	mov.b	v4[1], w6
	ubfx	w6, w10, #2, #1
	mov.b	v4[2], w6
	ubfx	w6, w10, #3, #1
	mov.b	v4[3], w6
	ubfx	w6, w10, #4, #1
	mov.b	v4[4], w6
	ubfx	w6, w10, #5, #1
	mov.b	v4[5], w6
	ubfx	w6, w10, #6, #1
	mov.b	v4[6], w6
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	cmp	w2, #0
	csetm	w10, ne
	dup.8b	v5, w10
	bit.8b	v3, v10, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x3, w4, uxtw]
	bic.8b	v3, v4, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w4, uxtw]
	cmp	x0, #8
	b.hs	LBB0_1006
; %bb.487:                              ; %ready.overflow.resume540
                                        ;   in Loop: Header=BB0_7 Depth=3
	str	q7, [sp, #3008]
	str	q6, [sp, #3024]
	ubfiz	x10, x4, #2, #3
	add	x3, sp, #3008
	ldr	w3, [x3, x10]
	cmp	w2, #0
	csel	w3, w1, w3, ne
	csinc	w1, w1, w4, eq
	str	q7, [sp, #2976]
	str	q6, [sp, #2992]
	add	x5, sp, #2976
	str	w3, [x5, x10]
	ldr	q6, [sp, #2992]
	ldr	q7, [sp, #2976]
	str	q9, [sp, #2944]
	str	q8, [sp, #2960]
	add	x3, sp, #2944
	ldr	w3, [x3, x10]
	mov	w5, #8                          ; =0x8
	csel	w3, w5, w3, ne
	str	q9, [sp, #2912]
	str	q8, [sp, #2928]
	add	x5, sp, #2912
	str	w3, [x5, x10]
	mov	w3, #26                         ; =0x1a
	mov	w5, #23                         ; =0x17
	ldr	q8, [sp, #2928]
	ldr	q9, [sp, #2912]
	b	LBB0_938
LBB0_488:                               ; %varying.coherent536
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_544
; %bb.489:                              ; %varying.coherent.true541
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
	tst	w3, #0xff
	b.eq	LBB0_5
LBB0_490:                               ; %schedule.23
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.16b	v0, v21
	mov.16b	v21, v20
	mov.16b	v20, v15
	mov	b3, v10[0]
	mov.b	v3[4], v10[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v4, v3, #0
	ldr	q3, [sp, #1104]                 ; 16-byte Folded Reload
	and.16b	v18, v4, v3
	mov	b3, v10[2]
	mov.b	v3[4], v10[3]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v5, v3, #0
	ldr	q3, [sp, #1088]                 ; 16-byte Folded Reload
	and.16b	v19, v5, v3
	mov	b3, v10[4]
	mov.b	v3[4], v10[5]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v24, v3, #0
	ldr	q3, [sp, #896]                  ; 16-byte Folded Reload
	and.16b	v26, v24, v3
	mov	b3, v10[6]
	mov.b	v3[4], v10[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v25, v3, #0
	ldr	q3, [sp, #1072]                 ; 16-byte Folded Reload
	and.16b	v3, v25, v3
	shl.8b	v16, v10, #7
	cmlt.8b	v16, v16, #0
	and.8b	v17, v16, v2
	addv.8b	b13, v17
	fmov	w3, s13
	mov	w4, #32                         ; =0x20
	dup.2d	v27, x4
	and.16b	v17, v4, v27
	mvn.16b	v4, v4
	sub.2d	v17, v17, v4
	and.16b	v4, v5, v27
	mvn.16b	v5, v5
	sub.2d	v4, v4, v5
	and.16b	v5, v24, v27
	and.16b	v27, v25, v27
	mvn.16b	v25, v25
	sub.2d	v25, v27, v25
	mov.d	x4, v25[1]
	mov.d	x5, v3[1]
	sdiv	x5, x5, x4
	mvn.16b	v24, v24
	sub.2d	v5, v5, v24
	fmov	x6, d25
	fmov	x7, d3
	sdiv	x7, x7, x6
	mul	x6, x7, x6
	fmov	d11, x7
	mov.d	v11[1], x5
	mov.d	x7, v5[1]
	mov.d	x19, v26[1]
	sdiv	x19, x19, x7
	fmov	x20, d5
	fmov	x21, d26
	sdiv	x21, x21, x20
	mul	x20, x21, x20
	fmov	d12, x21
	mov.d	v12[1], x19
	mov.d	x21, v4[1]
	mov.d	x22, v19[1]
	sdiv	x22, x22, x21
	fmov	x23, d4
	fmov	x24, d19
	sdiv	x24, x24, x23
	mul	x23, x24, x23
	fmov	d14, x24
	mov.d	v14[1], x22
	mov.d	x24, v17[1]
	mov.d	x25, v18[1]
	fmov	x26, d17
	fmov	x27, d18
	sdiv	x27, x27, x26
	mul	x26, x27, x26
	fmov	d17, x27
	sdiv	x25, x25, x24
	mov.d	v17[1], x25
	mul	x24, x25, x24
	fmov	d4, x26
	mov.d	v4[1], x24
	mul	x21, x22, x21
	fmov	d5, x23
	mov.d	v5[1], x21
	mul	x7, x19, x7
	fmov	d24, x20
	mov.d	v24[1], x7
	mul	x4, x5, x4
	fmov	d25, x6
	mov.d	v25[1], x4
	sub.2d	v3, v3, v25
	sub.2d	v24, v26, v24
	sub.2d	v5, v19, v5
	sub.2d	v4, v18, v4
	dup.2d	v18, x16
	add.2d	v4, v4, v18
	add.2d	v5, v5, v18
	add.2d	v19, v24, v18
	add.2d	v3, v3, v18
	ldr	q18, [sp, #17408]
	ldr	q24, [sp, #17424]
	ldr	q25, [sp, #17440]
	ldr	q26, [sp, #17456]
	ldr	q27, [sp, #17520]
	ldr	q28, [sp, #17504]
	ldr	q29, [sp, #17488]
	shl.2d	v3, v3, #6
	shl.2d	v19, v19, #6
	shl.2d	v5, v5, #6
	shl.2d	v30, v4, #6
	ldr	q15, [sp, #17472]
	add.2d	v4, v26, v27
	add.2d	v31, v4, v3
	add.2d	v3, v25, v28
	add.2d	v3, v3, v19
	add.2d	v4, v24, v29
	add.2d	v4, v4, v5
	add.2d	v5, v18, v15
	add.2d	v15, v5, v30
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	tbnz	w3, #0, LBB0_529
; %bb.491:                              ; %else4377
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #1, LBB0_530
LBB0_492:                               ; %else4383
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.16b	v15, v20
	mov.16b	v20, v21
	tbnz	w3, #2, LBB0_531
LBB0_493:                               ; %else4389
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.16b	v21, v0
	tbnz	w3, #3, LBB0_532
LBB0_494:                               ; %else4395
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #4, LBB0_533
LBB0_495:                               ; %else4401
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #5, LBB0_534
LBB0_496:                               ; %else4407
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #6, LBB0_535
LBB0_497:                               ; %else4413
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w3, #7, LBB0_499
LBB0_498:                               ; %cond.load4415
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v31[1]
	ld1.d	{ v27 }[1], [x3]
LBB0_499:                               ; %else4419
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w3, #32                         ; =0x20
	dup.2d	v3, x3
	cmhi.2d	v4, v3, v19
	cmhi.2d	v5, v3, v18
	uzp1.4s	v4, v5, v4
	cmhi.2d	v5, v3, v26
	cmhi.2d	v3, v3, v27
	uzp1.4s	v3, v5, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	ldrb	w3, [x9, #1024]
	and	w4, w3, #0x1
	fmov	s4, w4
	ubfx	w4, w3, #1, #1
	mov.b	v4[1], w4
	ubfx	w4, w3, #2, #1
	mov.b	v4[2], w4
	ubfx	w4, w3, #3, #1
	mov.b	v4[3], w4
	ubfx	w4, w3, #4, #1
	mov.b	v4[4], w4
	ubfx	w4, w3, #5, #1
	mov.b	v4[5], w4
	ubfx	w4, w3, #6, #1
	mov.b	v4[6], w4
	lsr	w3, w3, #7
	mov.b	v4[7], w3
	bif.8b	v3, v4, v16
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x9, #1024]
	shl.2d	v5, v14, #5
	shl.2d	v4, v17, #5
	shl.2d	v16, v11, #5
	shl.2d	v3, v12, #5
	add.2d	v3, v26, v3
	add.2d	v16, v27, v16
	add.2d	v4, v18, v4
	add.2d	v17, v19, v5
	ldr	q5, [sp, #17184]
	ldr	q18, [sp, #17200]
	ldr	q19, [sp, #17152]
	ldr	q24, [sp, #17168]
	mov	b25, v10[2]
	mov.b	v25[4], v10[3]
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	mov	b26, v10[0]
	mov.b	v26[4], v10[1]
	bit.16b	v24, v17, v25
	ushll.2d	v25, v26, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	bit.16b	v19, v4, v25
	mov	b25, v10[6]
	mov.b	v25[4], v10[7]
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	bit.16b	v18, v16, v25
	mov	b25, v10[4]
	mov.b	v25[4], v10[5]
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	bit.16b	v5, v3, v25
	str	q5, [sp, #17184]
	str	q18, [sp, #17200]
	str	q19, [sp, #17152]
	str	q24, [sp, #17168]
	mov	w3, #128                        ; =0x80
	dup.2d	v18, x3
	cmhi.2d	v5, v18, v4
	cmhi.2d	v19, v18, v17
	uzp1.4s	v5, v5, v19
	cmhi.2d	v19, v18, v3
	cmhi.2d	v24, v18, v16
	uzp1.4s	v19, v19, v24
	uzp1.8h	v5, v5, v19
	xtn.8b	v5, v5
	and.8b	v11, v10, v5
	shl.8b	v5, v11, #7
	cmlt.8b	v5, v5, #0
	and.8b	v19, v5, v2
	addv.8b	b19, v19
	fmov	w3, s19
	umaxv.8b	b5, v5
	fmov	w4, s5
	tbz	w4, #0, LBB0_505
; %bb.500:                              ; %else4419
                                        ;   in Loop: Header=BB0_7 Depth=3
	cmhs.2d	v4, v4, v18
	cmhs.2d	v5, v17, v18
	uzp1.4s	v4, v4, v5
	cmhs.2d	v3, v3, v18
	cmhs.2d	v5, v16, v18
	uzp1.4s	v3, v3, v5
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v12, v10, v3
	shl.8b	v3, v12, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w4, s3
	tst	w4, #0xff
	b.eq	LBB0_505
; %bb.501:                              ; %varying.divergent549
                                        ;   in Loop: Header=BB0_7 Depth=3
	subs	w10, w1, #1
	csel	w10, wzr, w10, lo
	and	w3, w17, #0xff
	lsr	w2, w3, w10
	tst	w2, #0x1
	str	q9, [sp, #3200]
	str	q8, [sp, #3216]
	and	x10, x10, #0x7
	add	x2, sp, #3200
	ldr	w10, [x2, x10, lsl #2]
	ccmp	w1, #0, #4, ne
	ccmp	w10, #9, #0, ne
	cset	w2, ne
	cmp	w3, #255
	b.ne	LBB0_503
; %bb.502:                              ; %varying.divergent549
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #0, LBB0_1006
LBB0_503:                               ; %convergence.overflow.resume552
                                        ;   in Loop: Header=BB0_7 Depth=3
	mvn	w10, w17
	rbit	w10, w10
	clz	w10, w10
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w17
	csel	w4, wzr, w10, eq
	add	x3, sp, #18, lsl #12            ; =73728
	add	x3, x3, #752
	ldrb	w10, [x3, w4, uxtw]
	and	w5, w10, #0x1
	fmov	s3, w5
	ubfx	w5, w10, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w10, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w10, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w10, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w10, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w10, #6, #1
	mov.b	v3[6], w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x5, w4, uxtw]
	and	w6, w10, #0x1
	fmov	s4, w6
	ubfx	w6, w10, #1, #1
	mov.b	v4[1], w6
	ubfx	w6, w10, #2, #1
	mov.b	v4[2], w6
	ubfx	w6, w10, #3, #1
	mov.b	v4[3], w6
	ubfx	w6, w10, #4, #1
	mov.b	v4[4], w6
	ubfx	w6, w10, #5, #1
	mov.b	v4[5], w6
	ubfx	w6, w10, #6, #1
	mov.b	v4[6], w6
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	cmp	w2, #0
	csetm	w10, ne
	dup.8b	v5, w10
	bit.8b	v3, v10, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x3, w4, uxtw]
	bic.8b	v3, v4, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w4, uxtw]
	cmp	x0, #8
	b.hs	LBB0_1006
; %bb.504:                              ; %ready.overflow.resume554
                                        ;   in Loop: Header=BB0_7 Depth=3
	zip2.8b	v3, v12, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldp	q5, q0, [sp, #544]              ; 32-byte Folded Reload
	and.16b	v4, v3, v5
	zip1.8b	v3, v12, v5
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v0, v3, v0
	stp	q4, q0, [sp, #544]              ; 32-byte Folded Spill
	str	q7, [sp, #3168]
	str	q6, [sp, #3184]
	ubfiz	x10, x4, #2, #3
	add	x3, sp, #3168
	ldr	w3, [x3, x10]
	cmp	w2, #0
	csel	w3, w1, w3, ne
	csinc	w1, w1, w4, eq
	str	q7, [sp, #3136]
	str	q6, [sp, #3152]
	add	x5, sp, #3136
	str	w3, [x5, x10]
	ldr	q6, [sp, #3152]
	ldr	q7, [sp, #3136]
	str	q9, [sp, #3104]
	str	q8, [sp, #3120]
	add	x3, sp, #3104
	ldr	w3, [x3, x10]
	mov	w5, #9                          ; =0x9
	csel	w3, w5, w3, ne
	str	q9, [sp, #3072]
	str	q8, [sp, #3088]
	add	x5, sp, #3072
	str	w3, [x5, x10]
	mov	w3, #25                         ; =0x19
	mov	w5, #24                         ; =0x18
	ldr	q8, [sp, #3088]
	ldr	q9, [sp, #3072]
	b	LBB0_938
LBB0_505:                               ; %varying.coherent550
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_543
; %bb.506:                              ; %varying.coherent.true555
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w2, #0, LBB0_507
	b	LBB0_5
LBB0_507:                               ; %schedule.24.thread
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q3, [sp, #17536]
	ldr	q4, [sp, #17552]
	ldr	q5, [sp, #17568]
	ldr	q16, [sp, #17584]
	ldr	q17, [sp, #17648]
	ldr	q18, [sp, #17632]
	ldr	q19, [sp, #17616]
	ldr	q22, [sp, #17600]
	ldr	q23, [sp, #17152]
	ldr	q24, [sp, #17168]
	ldr	q25, [sp, #17184]
	ldr	q26, [sp, #17200]
	shl.2d	v26, v26, #5
	shl.2d	v25, v25, #5
	shl.2d	v24, v24, #5
	shl.2d	v23, v23, #5
	add.2d	v16, v16, v17
	add.2d	v17, v16, v26
	add.2d	v5, v5, v18
	add.2d	v18, v5, v25
	add.2d	v4, v4, v19
	add.2d	v4, v4, v24
	add.2d	v3, v3, v22
	add.2d	v19, v3, v23
	fmov	w2, s13
	movi.2d	v16, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w2, #0, LBB0_553
; %bb.508:                              ; %else5359
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #1, LBB0_554
LBB0_509:                               ; %else5365
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #2, LBB0_555
LBB0_510:                               ; %else5371
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #3, LBB0_556
LBB0_511:                               ; %else5377
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #4, LBB0_557
LBB0_512:                               ; %else5383
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #5, LBB0_558
LBB0_513:                               ; %else5389
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #6, LBB0_559
LBB0_514:                               ; %else5395
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w2, #7, LBB0_516
LBB0_515:                               ; %cond.load5397
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v17[1]
	ld1.s	{ v3 }[3], [x10]
LBB0_516:                               ; %else5401
                                        ;   in Loop: Header=BB0_7 Depth=3
	zip2.8b	v4, v10, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q0, [sp, #544]                  ; 16-byte Folded Reload
	bit.16b	v0, v3, v4
	str	q0, [sp, #544]                  ; 16-byte Folded Spill
	zip1.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q0, [sp, #560]                  ; 16-byte Folded Reload
	bit.16b	v0, v16, v3
	str	q0, [sp, #560]                  ; 16-byte Folded Spill
	cbnz	w1, LBB0_20
LBB0_517:                               ; %schedule.25.convergence.cascade.exit560_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
LBB0_518:                               ; %convergence.cascade.exit560
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
; %bb.519:                              ; %convergence.target.25.ready
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q0, [sp, #768]                  ; 16-byte Folded Reload
	dup.4s	v4, v0[0]
	ldrb	w10, [x9, #1024]
	ubfx	w2, w10, #3, #1
	ubfx	w3, w10, #2, #1
	ubfx	w4, w10, #1, #1
	and	w5, w10, #0x1
	lsr	w6, w10, #7
	ubfx	w7, w10, #6, #1
	ubfx	w19, w10, #5, #1
	ubfx	w10, w10, #4, #1
	fmov	s3, w10
	mov.h	v3[1], w19
	mov.h	v3[2], w7
	mov.h	v3[3], w6
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	fmov	s5, w5
	mov.h	v5[1], w4
	mov.h	v5[2], w3
	mov.h	v5[3], w2
	ldr	q0, [sp, #544]                  ; 16-byte Folded Reload
	bsl.16b	v3, v0, v4
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q0, [sp, #560]                  ; 16-byte Folded Reload
	mov.16b	v16, v5
	bsl.16b	v16, v0, v4
	ldr	q4, [sp, #17328]
	ldr	q5, [sp, #17312]
	ldr	q17, [sp, #17296]
	ldr	q18, [sp, #17280]
	ldr	q19, [sp, #17344]
	ldr	q22, [sp, #17360]
	ldr	q23, [sp, #17376]
	ldr	q24, [sp, #17392]
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	shl.2d	v25, v0, #5
	ldr	q0, [sp, #1088]                 ; 16-byte Folded Reload
	shl.2d	v26, v0, #5
	ldr	q0, [sp, #896]                  ; 16-byte Folded Reload
	shl.2d	v27, v0, #5
	ldr	q0, [sp, #1072]                 ; 16-byte Folded Reload
	shl.2d	v28, v0, #5
	add.2d	v24, v24, v28
	add.2d	v23, v23, v27
	add.2d	v22, v22, v26
	add.2d	v19, v19, v25
	add.2d	v19, v18, v19
	add.2d	v18, v17, v22
	add.2d	v17, v5, v23
	add.2d	v4, v4, v24
	shl.8b	v5, v10, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	fmov	w2, s5
	tbnz	w2, #0, LBB0_536
; %bb.520:                              ; %else5407
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #1, LBB0_537
LBB0_521:                               ; %else5411
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	ldr	q5, [sp, #1088]                 ; 16-byte Folded Reload
	tbnz	w2, #2, LBB0_538
LBB0_522:                               ; %else5415
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #3, LBB0_539
LBB0_523:                               ; %else5419
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #4, LBB0_540
LBB0_524:                               ; %else5423
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #5, LBB0_541
LBB0_525:                               ; %else5427
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #6, LBB0_542
LBB0_526:                               ; %else5431
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w2, #7, LBB0_528
LBB0_527:                               ; %cond.store5432
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v4[1]
	st1.s	{ v3 }[3], [x10]
LBB0_528:                               ; %else5435
                                        ;   in Loop: Header=BB0_7 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v10, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v4, v3, #0
	ushll2.4s	v3, v3, #0
	ldr	q16, [sp, #1072]                ; 16-byte Folded Reload
	uaddw2.2d	v16, v16, v3
	str	q16, [sp, #1072]                ; 16-byte Folded Spill
	ldr	q16, [sp, #896]                 ; 16-byte Folded Reload
	uaddw.2d	v16, v16, v3
	str	q16, [sp, #896]                 ; 16-byte Folded Spill
	uaddw2.2d	v5, v5, v4
	str	q5, [sp, #1088]                 ; 16-byte Folded Spill
	uaddw.2d	v0, v0, v4
	b	LBB0_481
LBB0_529:                               ; %cond.load4373
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d15
	ldr	d18, [x4]
	tbz	w3, #1, LBB0_492
LBB0_530:                               ; %cond.load4379
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v15[1]
	ld1.d	{ v18 }[1], [x4]
	mov.16b	v15, v20
	mov.16b	v20, v21
	tbz	w3, #2, LBB0_493
LBB0_531:                               ; %cond.load4385
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d4
	ld1.d	{ v19 }[0], [x4]
	mov.16b	v21, v0
	tbz	w3, #3, LBB0_494
LBB0_532:                               ; %cond.load4391
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v4[1]
	ld1.d	{ v19 }[1], [x4]
	tbz	w3, #4, LBB0_495
LBB0_533:                               ; %cond.load4397
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d3
	ld1.d	{ v26 }[0], [x4]
	tbz	w3, #5, LBB0_496
LBB0_534:                               ; %cond.load4403
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v3[1]
	ld1.d	{ v26 }[1], [x4]
	tbz	w3, #6, LBB0_497
LBB0_535:                               ; %cond.load4409
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d31
	ld1.d	{ v27 }[0], [x4]
	tbnz	w3, #7, LBB0_498
	b	LBB0_499
LBB0_536:                               ; %cond.store5404
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d19
	str	s16, [x10]
	tbz	w2, #1, LBB0_521
LBB0_537:                               ; %cond.store5408
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v19[1]
	st1.s	{ v16 }[1], [x10]
	ldr	q0, [sp, #1104]                 ; 16-byte Folded Reload
	ldr	q5, [sp, #1088]                 ; 16-byte Folded Reload
	tbz	w2, #2, LBB0_522
LBB0_538:                               ; %cond.store5412
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d18
	st1.s	{ v16 }[2], [x10]
	tbz	w2, #3, LBB0_523
LBB0_539:                               ; %cond.store5416
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v18[1]
	st1.s	{ v16 }[3], [x10]
	tbz	w2, #4, LBB0_524
LBB0_540:                               ; %cond.store5420
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d17
	str	s3, [x10]
	tbz	w2, #5, LBB0_525
LBB0_541:                               ; %cond.store5424
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v17[1]
	st1.s	{ v3 }[1], [x10]
	tbz	w2, #6, LBB0_526
LBB0_542:                               ; %cond.store5428
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d4
	st1.s	{ v3 }[2], [x10]
	tbnz	w2, #7, LBB0_527
	b	LBB0_528
LBB0_543:                               ; %varying.coherent.false556
                                        ;   in Loop: Header=BB0_7 Depth=3
	zip2.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldp	q5, q0, [sp, #544]              ; 32-byte Folded Reload
	and.16b	v4, v3, v5
	zip1.8b	v3, v10, v5
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v0, v3, v0
	stp	q4, q0, [sp, #544]              ; 32-byte Folded Spill
	tbnz	w2, #0, LBB0_1007
	b	LBB0_19
LBB0_1007:                              ; %varying.coherent.false556
                                        ;   in Loop: Header=BB0_6 Depth=2
	b	LBB0_5
LBB0_544:                               ; %varying.coherent.false542
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
LBB0_545:                               ; %schedule.26
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q0, [sp, #944]                  ; 16-byte Folded Reload
	cbz	w1, LBB0_550
; %bb.546:                              ; %convergence.cascade584.preheader
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
LBB0_547:                               ; %convergence.cascade584
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_7 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w10, s4
	umaxv.8b	b3, v3
	fmov	w6, s3
	sub	w3, w1, #1
	tst	w10, #0xff
	csel	w4, w3, wzr, ne
	mov	w10, #1                         ; =0x1
	lsl	w5, w10, w4
	and	w10, w5, w17
	tst	w10, #0xff
	cset	w10, ne
	str	q9, [sp, #9280]
	str	q8, [sp, #9296]
	ubfiz	x3, x4, #2, #3
	add	x7, sp, #2, lsl #12             ; =8192
	add	x7, x7, #1088
	ldr	w7, [x7, x3]
	cmp	w7, #8
	cset	w7, eq
	and	w19, w10, w6
	add	x6, sp, #18, lsl #12            ; =73728
	add	x6, x6, #752
	ldrb	w10, [x6, w4, sxtw]
	and	w20, w10, #0x1
	fmov	s3, w20
	ubfx	w20, w10, #1, #1
	mov.b	v3[1], w20
	ubfx	w20, w10, #2, #1
	mov.b	v3[2], w20
	ubfx	w20, w10, #3, #1
	mov.b	v3[3], w20
	ubfx	w20, w10, #4, #1
	mov.b	v3[4], w20
	ubfx	w20, w10, #5, #1
	mov.b	v3[5], w20
	ubfx	w20, w10, #6, #1
	mov.b	v3[6], w20
	add	x20, sp, #18, lsl #12           ; =73728
	add	x20, x20, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x20, w4, sxtw]
	and	w21, w10, #0x1
	fmov	s4, w21
	ubfx	w21, w10, #1, #1
	mov.b	v4[1], w21
	ubfx	w21, w10, #2, #1
	mov.b	v4[2], w21
	ubfx	w21, w10, #3, #1
	mov.b	v4[3], w21
	ubfx	w21, w10, #4, #1
	mov.b	v4[4], w21
	ubfx	w21, w10, #5, #1
	mov.b	v4[5], w21
	ubfx	w21, w10, #6, #1
	mov.b	v4[6], w21
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	orr.8b	v5, v10, v4
	and.8b	v16, v1, v3
	eor.8b	v16, v16, v5
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	umaxv.8b	b16, v16
	fmov	w10, s16
	ands	w7, w19, w7
	csetm	w19, ne
	bics	w10, w7, w10
	csetm	w21, ne
	dup.8b	v16, w21
	bic.8b	v17, v5, v16
	dup.8b	v18, w19
	bit.8b	v4, v17, v18
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x20, w4, sxtw]
	bic.8b	v3, v3, v16
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x6, w4, sxtw]
	mov	w4, #-1                         ; =0xffffffff
	csinv	w4, w4, w5, eq
	and	w17, w4, w17
	dup.8b	v3, w7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v4, w10
	and.8b	v4, v4, v5
	str	q7, [sp, #9248]
	str	q6, [sp, #9264]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #1056
	ldr	w10, [x10, x3]
	csel	w1, w10, w1, ne
	bit.8b	v10, v4, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	cmp	w7, #1
	b.ne	LBB0_551
; %bb.548:                              ; %convergence.cascade584
                                        ;   in Loop: Header=BB0_547 Depth=4
	cmp	w1, #0
	ccmp	w2, #6, #2, ne
	b.hi	LBB0_551
; %bb.549:                              ; %convergence.cascade584
                                        ;   in Loop: Header=BB0_547 Depth=4
	add	w2, w2, #1
	tst	w3, #0xff
	b.ne	LBB0_547
	b	LBB0_551
LBB0_550:                               ; %schedule.26.convergence.cascade.exit585_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
LBB0_551:                               ; %convergence.cascade.exit585
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
; %bb.552:                              ; %convergence.target.26.ready
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q17, [sp, #17120]
	ldr	q4, [sp, #17136]
	ldr	q3, [sp, #17088]
	ldr	q5, [sp, #17104]
	ldr	q16, [sp, #17056]
	ldr	q19, [sp, #17072]
	ldr	q22, [sp, #17024]
	ldr	q23, [sp, #17040]
	mov	b18, v10[2]
	mov.b	v18[4], v10[3]
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	ldr	q28, [sp, #272]                 ; 16-byte Folded Reload
	bit.16b	v23, v28, v18
	mov	b24, v10[0]
	mov.b	v24[4], v10[1]
	ushll.2d	v24, v24, #0
	shl.2d	v24, v24, #63
	cmlt.2d	v24, v24, #0
	mov	b25, v10[6]
	mov.b	v25[4], v10[7]
	bit.16b	v22, v28, v24
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	bit.16b	v19, v28, v25
	mov	b26, v10[4]
	mov.b	v26[4], v10[5]
	ushll.2d	v26, v26, #0
	shl.2d	v26, v26, #63
	cmlt.2d	v26, v26, #0
Lloh850:
	adrp	x10, lCPI0_17@PAGE
Lloh851:
	ldr	q27, [x10, lCPI0_17@PAGEOFF]
	bit.16b	v5, v27, v18
Lloh852:
	adrp	x10, lCPI0_18@PAGE
Lloh853:
	ldr	q27, [x10, lCPI0_18@PAGEOFF]
	bit.16b	v17, v27, v26
Lloh854:
	adrp	x10, lCPI0_16@PAGE
Lloh855:
	ldr	q27, [x10, lCPI0_16@PAGEOFF]
	str	q17, [sp, #17120]
Lloh856:
	adrp	x10, lCPI0_19@PAGE
Lloh857:
	ldr	q17, [x10, lCPI0_19@PAGEOFF]
	bit.16b	v16, v28, v26
	bit.16b	v4, v17, v25
	str	q4, [sp, #17136]
	bit.16b	v3, v27, v24
	str	q3, [sp, #17088]
	str	q5, [sp, #17104]
	str	q16, [sp, #17056]
	str	q19, [sp, #17072]
	str	q22, [sp, #17024]
	str	q23, [sp, #17040]
	ldr	q3, [sp, #1360]                 ; 16-byte Folded Reload
	bic.16b	v3, v3, v25
	str	q3, [sp, #1360]                 ; 16-byte Folded Spill
	bic.16b	v0, v0, v26
	str	q0, [sp, #944]                  ; 16-byte Folded Spill
	ldr	q0, [sp, #1376]                 ; 16-byte Folded Reload
	bic.16b	v0, v0, v18
	str	q0, [sp, #1376]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #1392]                 ; 16-byte Folded Reload
	bic.16b	v0, v0, v24
	str	q0, [sp, #1392]                 ; 16-byte Folded Spill
	b	LBB0_560
LBB0_553:                               ; %cond.load5355
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d19
	ldr	s16, [x10]
	tbz	w2, #1, LBB0_509
LBB0_554:                               ; %cond.load5361
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v19[1]
	ld1.s	{ v16 }[1], [x10]
	tbz	w2, #2, LBB0_510
LBB0_555:                               ; %cond.load5367
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d4
	ld1.s	{ v16 }[2], [x10]
	tbz	w2, #3, LBB0_511
LBB0_556:                               ; %cond.load5373
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v4[1]
	ld1.s	{ v16 }[3], [x10]
	tbz	w2, #4, LBB0_512
LBB0_557:                               ; %cond.load5379
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d18
	ld1.s	{ v3 }[0], [x10]
	tbz	w2, #5, LBB0_513
LBB0_558:                               ; %cond.load5385
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v18[1]
	ld1.s	{ v3 }[1], [x10]
	tbz	w2, #6, LBB0_514
LBB0_559:                               ; %cond.load5391
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d17
	ld1.s	{ v3 }[2], [x10]
	tbnz	w2, #7, LBB0_515
	b	LBB0_516
LBB0_560:                               ; %schedule.27
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	mov	w2, #128                        ; =0x80
	dup.2d	v3, x2
	ldr	q17, [sp, #1376]                ; 16-byte Folded Reload
	cmgt.2d	v4, v3, v17
	ldr	q0, [sp, #1392]                 ; 16-byte Folded Reload
	cmgt.2d	v5, v3, v0
	uzp1.4s	v4, v5, v4
	ldr	q18, [sp, #944]                 ; 16-byte Folded Reload
	cmgt.2d	v5, v3, v18
	ldr	q19, [sp, #1360]                ; 16-byte Folded Reload
	cmgt.2d	v16, v3, v19
	uzp1.4s	v5, v5, v16
	uzp1.8h	v4, v4, v5
	xtn.8b	v4, v4
	and.8b	v11, v10, v4
	shl.8b	v4, v11, #7
	cmlt.8b	v4, v4, #0
	and.8b	v5, v4, v2
	addv.8b	b5, v5
	fmov	w2, s5
	umaxv.8b	b4, v4
	fmov	w4, s4
	tbz	w4, #0, LBB0_566
; %bb.561:                              ; %schedule.27
                                        ;   in Loop: Header=BB0_7 Depth=3
	cmge.2d	v4, v17, v3
	cmge.2d	v5, v0, v3
	uzp1.4s	v4, v5, v4
	cmge.2d	v5, v18, v3
	cmge.2d	v3, v19, v3
	uzp1.4s	v3, v5, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v12, v10, v3
	shl.8b	v3, v12, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w4, s3
	tst	w4, #0xff
	b.eq	LBB0_566
; %bb.562:                              ; %varying.divergent602
                                        ;   in Loop: Header=BB0_7 Depth=3
	subs	w10, w1, #1
	csel	w10, wzr, w10, lo
	and	w3, w17, #0xff
	lsr	w2, w3, w10
	tst	w2, #0x1
	str	q9, [sp, #3424]
	str	q8, [sp, #3440]
	and	x10, x10, #0x7
	add	x2, sp, #3424
	ldr	w10, [x2, x10, lsl #2]
	ccmp	w1, #0, #4, ne
	ccmp	w10, #10, #0, ne
	cset	w2, ne
	cmp	w3, #255
	b.ne	LBB0_564
; %bb.563:                              ; %varying.divergent602
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #0, LBB0_1006
LBB0_564:                               ; %convergence.overflow.resume605
                                        ;   in Loop: Header=BB0_7 Depth=3
	mvn	w10, w17
	rbit	w10, w10
	clz	w10, w10
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w17
	csel	w4, wzr, w10, eq
	add	x3, sp, #18, lsl #12            ; =73728
	add	x3, x3, #752
	ldrb	w10, [x3, w4, uxtw]
	and	w5, w10, #0x1
	fmov	s3, w5
	ubfx	w5, w10, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w10, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w10, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w10, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w10, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w10, #6, #1
	mov.b	v3[6], w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x5, w4, uxtw]
	and	w6, w10, #0x1
	fmov	s4, w6
	ubfx	w6, w10, #1, #1
	mov.b	v4[1], w6
	ubfx	w6, w10, #2, #1
	mov.b	v4[2], w6
	ubfx	w6, w10, #3, #1
	mov.b	v4[3], w6
	ubfx	w6, w10, #4, #1
	mov.b	v4[4], w6
	ubfx	w6, w10, #5, #1
	mov.b	v4[5], w6
	ubfx	w6, w10, #6, #1
	mov.b	v4[6], w6
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	cmp	w2, #0
	csetm	w10, ne
	dup.8b	v5, w10
	bit.8b	v3, v10, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x3, w4, uxtw]
	bic.8b	v3, v4, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w4, uxtw]
	cmp	x0, #8
	b.hs	LBB0_1006
; %bb.565:                              ; %ready.overflow.resume607
                                        ;   in Loop: Header=BB0_7 Depth=3
	str	q7, [sp, #3392]
	str	q6, [sp, #3408]
	ubfiz	x10, x4, #2, #3
	add	x3, sp, #3392
	ldr	w3, [x3, x10]
	cmp	w2, #0
	csel	w3, w1, w3, ne
	csinc	w1, w1, w4, eq
	str	q7, [sp, #3360]
	str	q6, [sp, #3376]
	add	x5, sp, #3360
	str	w3, [x5, x10]
	ldr	q6, [sp, #3376]
	ldr	q7, [sp, #3360]
	str	q9, [sp, #3328]
	str	q8, [sp, #3344]
	add	x3, sp, #3328
	ldr	w3, [x3, x10]
	mov	w5, #10                         ; =0xa
	csel	w3, w5, w3, ne
	str	q9, [sp, #3296]
	str	q8, [sp, #3312]
	add	x5, sp, #3296
	str	w3, [x5, x10]
	mov	w3, #29                         ; =0x1d
	mov	w5, #28                         ; =0x1c
	ldr	q8, [sp, #3312]
	ldr	q9, [sp, #3296]
	b	LBB0_938
LBB0_566:                               ; %varying.coherent603
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_617
; %bb.567:                              ; %varying.coherent.true608
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
	tst	w3, #0xff
	b.eq	LBB0_5
LBB0_568:                               ; %schedule.28
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	b3, v10[0]
	mov.b	v3[4], v10[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v4, v3, #0
	ldr	q0, [sp, #1392]                 ; 16-byte Folded Reload
	and.16b	v17, v4, v0
	mov	b3, v10[2]
	mov.b	v3[4], v10[3]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v5, v3, #0
	ldr	q0, [sp, #1376]                 ; 16-byte Folded Reload
	and.16b	v18, v5, v0
	mov	b3, v10[4]
	mov.b	v3[4], v10[5]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v24, v3, #0
	ldr	q0, [sp, #944]                  ; 16-byte Folded Reload
	and.16b	v19, v24, v0
	mov	b3, v10[6]
	mov.b	v3[4], v10[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v25, v3, #0
	ldr	q0, [sp, #1360]                 ; 16-byte Folded Reload
	and.16b	v3, v25, v0
	shl.8b	v16, v10, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v2
	mov	w3, #32                         ; =0x20
	dup.2d	v27, x3
	and.16b	v26, v4, v27
	mvn.16b	v4, v4
	sub.2d	v26, v26, v4
	and.16b	v4, v5, v27
	mvn.16b	v5, v5
	sub.2d	v4, v4, v5
	and.16b	v5, v24, v27
	mvn.16b	v24, v24
	and.16b	v27, v25, v27
	mvn.16b	v25, v25
	sub.2d	v25, v27, v25
	mov.d	x3, v25[1]
	mov.d	x4, v3[1]
	sdiv	x4, x4, x3
	sub.2d	v5, v5, v24
	fmov	x5, d25
	fmov	x6, d3
	sdiv	x6, x6, x5
	mul	x5, x6, x5
	fmov	d24, x6
	mov.d	v24[1], x4
	mov.d	x6, v5[1]
	mov.d	x7, v19[1]
	sdiv	x7, x7, x6
	fmov	x19, d5
	fmov	x20, d19
	sdiv	x20, x20, x19
	mul	x19, x20, x19
	fmov	d5, x20
	mov.d	v5[1], x7
	mov.d	x20, v4[1]
	mov.d	x21, v18[1]
	sdiv	x21, x21, x20
	fmov	x22, d4
	fmov	x23, d18
	sdiv	x23, x23, x22
	mul	x22, x23, x22
	fmov	d4, x23
	mov.d	v4[1], x21
	mov.d	x23, v26[1]
	mov.d	x24, v17[1]
	fmov	x25, d26
	fmov	x26, d17
	sdiv	x26, x26, x25
	mul	x25, x26, x25
	fmov	d25, x26
	sdiv	x24, x24, x23
	mov.d	v25[1], x24
	mul	x23, x24, x23
	fmov	d26, x25
	mov.d	v26[1], x23
	mul	x20, x21, x20
	fmov	d27, x22
	mov.d	v27[1], x20
	mul	x6, x7, x6
	fmov	d28, x19
	mov.d	v28[1], x6
	mul	x3, x4, x3
	fmov	d29, x5
	mov.d	v29[1], x3
	addv.8b	b16, v16
	sub.2d	v3, v3, v29
	sub.2d	v19, v19, v28
	fmov	w3, s16
	sub.2d	v18, v18, v27
	sub.2d	v17, v17, v26
	ldr	q28, [sp, #17536]
	ldr	q29, [sp, #17552]
	ldr	q30, [sp, #17568]
	ldr	q31, [sp, #17584]
	ldr	q11, [sp, #17648]
	ldr	q12, [sp, #17632]
	ldr	q13, [sp, #17616]
	shl.2d	v25, v25, #10
	shl.2d	v4, v4, #10
	shl.2d	v5, v5, #10
	shl.2d	v24, v24, #10
	shl.2d	v17, v17, #5
	shl.2d	v26, v18, #5
	shl.2d	v19, v19, #5
	shl.2d	v3, v3, #5
	add.2d	v18, v24, v3
	add.2d	v19, v5, v19
	ldr	q5, [sp, #17600]
	add.2d	v26, v4, v26
	add.2d	v27, v25, v17
	add.2d	v3, v31, v11
	add.2d	v3, v3, v18
	add.2d	v4, v30, v12
	add.2d	v31, v4, v19
	add.2d	v4, v29, v13
	add.2d	v4, v4, v26
	add.2d	v5, v28, v5
	add.2d	v30, v5, v27
	movi.2d	v17, #0000000000000000
	movi.2d	v11, #0000000000000000
	tbnz	w3, #0, LBB0_596
; %bb.569:                              ; %else4475
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #1, LBB0_597
LBB0_570:                               ; %else4481
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #2, LBB0_598
LBB0_571:                               ; %else4487
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #3, LBB0_599
LBB0_572:                               ; %else4493
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #4, LBB0_600
LBB0_573:                               ; %else4499
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #5, LBB0_601
LBB0_574:                               ; %else4505
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #6, LBB0_602
LBB0_575:                               ; %else4511
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w3, #7, LBB0_577
LBB0_576:                               ; %cond.load4513
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v3[1]
	ld1.s	{ v11 }[3], [x3]
LBB0_577:                               ; %else4517
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q3, [sp, #17328]
	ldr	q5, [sp, #17312]
	ldr	q4, [sp, #17296]
	ldr	q24, [sp, #17280]
	ldr	q25, [sp, #17344]
	ldr	q28, [sp, #17360]
	ldr	q29, [sp, #17376]
	ldr	q30, [sp, #17392]
	add.2d	v24, v24, v25
	add.2d	v27, v24, v27
	add.2d	v4, v4, v28
	add.2d	v4, v4, v26
	add.2d	v5, v5, v29
	add.2d	v26, v5, v19
	add.2d	v3, v3, v30
	add.2d	v19, v3, v18
	fmov	w3, s16
	movi.2d	v3, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w3, #0, LBB0_603
; %bb.578:                              ; %else4524
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #1, LBB0_604
LBB0_579:                               ; %else4530
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #2, LBB0_605
LBB0_580:                               ; %else4536
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #3, LBB0_606
LBB0_581:                               ; %else4542
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #4, LBB0_607
LBB0_582:                               ; %else4548
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #5, LBB0_608
LBB0_583:                               ; %else4554
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #6, LBB0_609
LBB0_584:                               ; %else4560
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w3, #7, LBB0_586
LBB0_585:                               ; %cond.load4562
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v19[1]
	ld1.s	{ v18 }[3], [x3]
LBB0_586:                               ; %else4566
                                        ;   in Loop: Header=BB0_7 Depth=3
	fadd.4s	v17, v17, v3
	fadd.4s	v3, v11, v18
	ldr	q4, [sp, #17072]
	ldr	q5, [sp, #17056]
	ldr	q18, [sp, #17040]
	ldr	q19, [sp, #17024]
	ldr	q24, [sp, #17088]
	ldr	q25, [sp, #17104]
	ldr	q26, [sp, #17120]
	ldr	q27, [sp, #17136]
	ldr	q0, [sp, #1392]                 ; 16-byte Folded Reload
	shl.2d	v28, v0, #5
	ldr	q0, [sp, #1376]                 ; 16-byte Folded Reload
	shl.2d	v29, v0, #5
	ldr	q0, [sp, #944]                  ; 16-byte Folded Reload
	shl.2d	v30, v0, #5
	ldr	q0, [sp, #1360]                 ; 16-byte Folded Reload
	shl.2d	v31, v0, #5
	add.2d	v27, v27, v31
	add.2d	v30, v26, v30
	add.2d	v25, v25, v29
	add.2d	v24, v24, v28
	add.2d	v26, v19, v24
	add.2d	v19, v18, v25
	add.2d	v18, v5, v30
	add.2d	v4, v4, v27
	fmov	w3, s16
	tbnz	w3, #0, LBB0_610
; %bb.587:                              ; %else4572
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #1, LBB0_611
LBB0_588:                               ; %else4576
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q0, [sp, #1392]                 ; 16-byte Folded Reload
	ldr	q5, [sp, #1376]                 ; 16-byte Folded Reload
	ldr	q16, [sp, #1360]                ; 16-byte Folded Reload
	tbnz	w3, #2, LBB0_612
LBB0_589:                               ; %else4580
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #3, LBB0_613
LBB0_590:                               ; %else4584
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #4, LBB0_614
LBB0_591:                               ; %else4588
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #5, LBB0_615
LBB0_592:                               ; %else4592
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #6, LBB0_616
LBB0_593:                               ; %else4596
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w3, #7, LBB0_595
LBB0_594:                               ; %cond.store4597
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v4[1]
	st1.s	{ v3 }[3], [x3]
LBB0_595:                               ; %else4600
                                        ;   in Loop: Header=BB0_7 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v10, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v4, v3, #0
	ushll2.4s	v3, v3, #0
	uaddw2.2d	v16, v16, v3
	str	q16, [sp, #1360]                ; 16-byte Folded Spill
	ldr	q16, [sp, #944]                 ; 16-byte Folded Reload
	uaddw.2d	v16, v16, v3
	str	q16, [sp, #944]                 ; 16-byte Folded Spill
	uaddw2.2d	v5, v5, v4
	str	q5, [sp, #1376]                 ; 16-byte Folded Spill
	uaddw.2d	v0, v0, v4
	str	q0, [sp, #1392]                 ; 16-byte Folded Spill
	tbz	w2, #0, LBB0_560
	b	LBB0_5
LBB0_596:                               ; %cond.load4471
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d30
	ldr	s17, [x4]
	tbz	w3, #1, LBB0_570
LBB0_597:                               ; %cond.load4477
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v30[1]
	ld1.s	{ v17 }[1], [x4]
	tbz	w3, #2, LBB0_571
LBB0_598:                               ; %cond.load4483
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d4
	ld1.s	{ v17 }[2], [x4]
	tbz	w3, #3, LBB0_572
LBB0_599:                               ; %cond.load4489
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v4[1]
	ld1.s	{ v17 }[3], [x4]
	tbz	w3, #4, LBB0_573
LBB0_600:                               ; %cond.load4495
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d31
	ld1.s	{ v11 }[0], [x4]
	tbz	w3, #5, LBB0_574
LBB0_601:                               ; %cond.load4501
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v31[1]
	ld1.s	{ v11 }[1], [x4]
	tbz	w3, #6, LBB0_575
LBB0_602:                               ; %cond.load4507
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d3
	ld1.s	{ v11 }[2], [x4]
	tbnz	w3, #7, LBB0_576
	b	LBB0_577
LBB0_603:                               ; %cond.load4520
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d27
	ldr	s3, [x4]
	tbz	w3, #1, LBB0_579
LBB0_604:                               ; %cond.load4526
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v27[1]
	ld1.s	{ v3 }[1], [x4]
	tbz	w3, #2, LBB0_580
LBB0_605:                               ; %cond.load4532
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d4
	ld1.s	{ v3 }[2], [x4]
	tbz	w3, #3, LBB0_581
LBB0_606:                               ; %cond.load4538
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v4[1]
	ld1.s	{ v3 }[3], [x4]
	tbz	w3, #4, LBB0_582
LBB0_607:                               ; %cond.load4544
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d26
	ld1.s	{ v18 }[0], [x4]
	tbz	w3, #5, LBB0_583
LBB0_608:                               ; %cond.load4550
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v26[1]
	ld1.s	{ v18 }[1], [x4]
	tbz	w3, #6, LBB0_584
LBB0_609:                               ; %cond.load4556
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d19
	ld1.s	{ v18 }[2], [x4]
	tbnz	w3, #7, LBB0_585
	b	LBB0_586
LBB0_610:                               ; %cond.store4569
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d26
	str	s17, [x4]
	tbz	w3, #1, LBB0_588
LBB0_611:                               ; %cond.store4573
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v26[1]
	st1.s	{ v17 }[1], [x4]
	ldr	q0, [sp, #1392]                 ; 16-byte Folded Reload
	ldr	q5, [sp, #1376]                 ; 16-byte Folded Reload
	ldr	q16, [sp, #1360]                ; 16-byte Folded Reload
	tbz	w3, #2, LBB0_589
LBB0_612:                               ; %cond.store4577
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d19
	st1.s	{ v17 }[2], [x4]
	tbz	w3, #3, LBB0_590
LBB0_613:                               ; %cond.store4581
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v19[1]
	st1.s	{ v17 }[3], [x4]
	tbz	w3, #4, LBB0_591
LBB0_614:                               ; %cond.store4585
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d18
	str	s3, [x4]
	tbz	w3, #5, LBB0_592
LBB0_615:                               ; %cond.store4589
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v18[1]
	st1.s	{ v3 }[1], [x4]
	tbz	w3, #6, LBB0_593
LBB0_616:                               ; %cond.store4593
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d4
	st1.s	{ v3 }[2], [x4]
	tbnz	w3, #7, LBB0_594
	b	LBB0_595
LBB0_617:                               ; %varying.coherent.false609
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
LBB0_618:                               ; %schedule.29
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q0, [sp, #912]                  ; 16-byte Folded Reload
	cbz	w1, LBB0_623
; %bb.619:                              ; %convergence.cascade617.preheader
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
LBB0_620:                               ; %convergence.cascade617
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_7 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w10, s4
	umaxv.8b	b3, v3
	fmov	w6, s3
	sub	w3, w1, #1
	tst	w10, #0xff
	csel	w4, w3, wzr, ne
	mov	w10, #1                         ; =0x1
	lsl	w5, w10, w4
	and	w10, w5, w17
	tst	w10, #0xff
	cset	w10, ne
	str	q9, [sp, #9216]
	str	q8, [sp, #9232]
	ubfiz	x3, x4, #2, #3
	add	x7, sp, #2, lsl #12             ; =8192
	add	x7, x7, #1024
	ldr	w7, [x7, x3]
	cmp	w7, #10
	cset	w7, eq
	and	w19, w10, w6
	add	x6, sp, #18, lsl #12            ; =73728
	add	x6, x6, #752
	ldrb	w10, [x6, w4, sxtw]
	and	w20, w10, #0x1
	fmov	s3, w20
	ubfx	w20, w10, #1, #1
	mov.b	v3[1], w20
	ubfx	w20, w10, #2, #1
	mov.b	v3[2], w20
	ubfx	w20, w10, #3, #1
	mov.b	v3[3], w20
	ubfx	w20, w10, #4, #1
	mov.b	v3[4], w20
	ubfx	w20, w10, #5, #1
	mov.b	v3[5], w20
	ubfx	w20, w10, #6, #1
	mov.b	v3[6], w20
	add	x20, sp, #18, lsl #12           ; =73728
	add	x20, x20, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x20, w4, sxtw]
	and	w21, w10, #0x1
	fmov	s4, w21
	ubfx	w21, w10, #1, #1
	mov.b	v4[1], w21
	ubfx	w21, w10, #2, #1
	mov.b	v4[2], w21
	ubfx	w21, w10, #3, #1
	mov.b	v4[3], w21
	ubfx	w21, w10, #4, #1
	mov.b	v4[4], w21
	ubfx	w21, w10, #5, #1
	mov.b	v4[5], w21
	ubfx	w21, w10, #6, #1
	mov.b	v4[6], w21
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	orr.8b	v5, v10, v4
	and.8b	v16, v1, v3
	eor.8b	v16, v16, v5
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	umaxv.8b	b16, v16
	fmov	w10, s16
	ands	w7, w19, w7
	csetm	w19, ne
	bics	w10, w7, w10
	csetm	w21, ne
	dup.8b	v16, w21
	bic.8b	v17, v5, v16
	dup.8b	v18, w19
	bit.8b	v4, v17, v18
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x20, w4, sxtw]
	bic.8b	v3, v3, v16
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x6, w4, sxtw]
	mov	w4, #-1                         ; =0xffffffff
	csinv	w4, w4, w5, eq
	and	w17, w4, w17
	dup.8b	v3, w7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v4, w10
	and.8b	v4, v4, v5
	str	q7, [sp, #9184]
	str	q6, [sp, #9200]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #992
	ldr	w10, [x10, x3]
	csel	w1, w10, w1, ne
	bit.8b	v10, v4, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	cmp	w7, #1
	b.ne	LBB0_624
; %bb.621:                              ; %convergence.cascade617
                                        ;   in Loop: Header=BB0_620 Depth=4
	cmp	w1, #0
	ccmp	w2, #6, #2, ne
	b.hi	LBB0_624
; %bb.622:                              ; %convergence.cascade617
                                        ;   in Loop: Header=BB0_620 Depth=4
	add	w2, w2, #1
	tst	w3, #0xff
	b.ne	LBB0_620
	b	LBB0_624
LBB0_623:                               ; %schedule.29.convergence.cascade.exit618_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
LBB0_624:                               ; %convergence.cascade.exit618
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
; %bb.625:                              ; %convergence.target.29.ready
                                        ;   in Loop: Header=BB0_7 Depth=3
	rbit	w10, w3
	clz	w2, w10
	ldr	q3, [sp, #16992]
	ldr	q4, [sp, #17008]
	ldr	q5, [sp, #16960]
	ldr	q16, [sp, #16976]
	ldr	q17, [sp, #16928]
	ldr	q18, [sp, #16944]
	ldr	q19, [sp, #16896]
	ldr	q22, [sp, #16912]
	mov	b23, v10[2]
	mov.b	v23[4], v10[3]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v11, v23, #0
	mov	b23, v10[0]
	mov.b	v23[4], v10[1]
	ldr	q24, [sp, #256]                 ; 16-byte Folded Reload
	bit.16b	v22, v24, v11
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v12, v23, #0
	bit.16b	v19, v24, v12
	mov	b23, v10[6]
	mov.b	v23[4], v10[7]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v13, v23, #0
	bit.16b	v18, v24, v13
	mov	b23, v10[4]
	mov.b	v23[4], v10[5]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v14, v23, #0
	bit.16b	v17, v24, v14
Lloh858:
	adrp	x10, lCPI0_20@PAGE
Lloh859:
	ldr	q23, [x10, lCPI0_20@PAGEOFF]
	bit.16b	v16, v23, v11
Lloh860:
	adrp	x10, lCPI0_21@PAGE
Lloh861:
	ldr	q24, [x10, lCPI0_21@PAGEOFF]
	bit.16b	v5, v24, v12
Lloh862:
	adrp	x10, lCPI0_22@PAGE
Lloh863:
	ldr	q25, [x10, lCPI0_22@PAGEOFF]
	bit.16b	v4, v25, v13
Lloh864:
	adrp	x10, lCPI0_23@PAGE
Lloh865:
	ldr	q26, [x10, lCPI0_23@PAGEOFF]
	bit.16b	v3, v26, v14
	str	q3, [sp, #16992]
	str	q4, [sp, #17008]
	str	q5, [sp, #16960]
	str	q16, [sp, #16976]
	str	q17, [sp, #16928]
	str	q18, [sp, #16944]
	str	q19, [sp, #16896]
	str	q22, [sp, #16912]
	str	q25, [sp, #7184]
	str	q26, [sp, #7168]
	str	q23, [sp, #7152]
	str	q24, [sp, #7136]
	lsl	w10, w2, #3
	and	x2, x10, #0x38
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #3040
	ldr	x5, [x3, x2]
	and	x3, x10, #0xf8
	add	x4, sp, #9, lsl #12             ; =36864
	add	x4, x4, #616
	sub	x10, x5, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10, #32]
	ldp	q5, q16, [x10]
	mov	x5, #-8                         ; =0xfffffffffffffff8
	dup.2d	v17, x5
	bit.16b	v16, v17, v11
	bit.16b	v5, v17, v12
	bit.16b	v4, v17, v13
	bit.16b	v3, v17, v14
	stp	q3, q4, [x10, #32]
	stp	q5, q16, [x10]
Lloh866:
	adrp	x10, lCPI0_24@PAGE
Lloh867:
	ldr	q3, [x10, lCPI0_24@PAGEOFF]
Lloh868:
	adrp	x10, lCPI0_25@PAGE
Lloh869:
	ldr	q4, [x10, lCPI0_25@PAGEOFF]
	str	q3, [sp, #7248]
	str	q4, [sp, #7232]
Lloh870:
	adrp	x10, lCPI0_26@PAGE
Lloh871:
	ldr	q3, [x10, lCPI0_26@PAGEOFF]
Lloh872:
	adrp	x10, lCPI0_27@PAGE
Lloh873:
	ldr	q4, [x10, lCPI0_27@PAGEOFF]
	str	q3, [sp, #7216]
	str	q4, [sp, #7200]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #3104
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	x5, #-7                         ; =0xfffffffffffffff9
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh874:
	adrp	x10, lCPI0_28@PAGE
Lloh875:
	ldr	q3, [x10, lCPI0_28@PAGEOFF]
Lloh876:
	adrp	x10, lCPI0_29@PAGE
Lloh877:
	ldr	q4, [x10, lCPI0_29@PAGEOFF]
	str	q3, [sp, #7312]
	str	q4, [sp, #7296]
Lloh878:
	adrp	x10, lCPI0_30@PAGE
Lloh879:
	ldr	q3, [x10, lCPI0_30@PAGEOFF]
Lloh880:
	adrp	x10, lCPI0_31@PAGE
Lloh881:
	ldr	q4, [x10, lCPI0_31@PAGEOFF]
	str	q3, [sp, #7280]
	str	q4, [sp, #7264]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #3168
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	x5, #-6                         ; =0xfffffffffffffffa
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh882:
	adrp	x10, lCPI0_32@PAGE
Lloh883:
	ldr	q3, [x10, lCPI0_32@PAGEOFF]
Lloh884:
	adrp	x10, lCPI0_33@PAGE
Lloh885:
	ldr	q4, [x10, lCPI0_33@PAGEOFF]
	str	q3, [sp, #7376]
	str	q4, [sp, #7360]
Lloh886:
	adrp	x10, lCPI0_34@PAGE
Lloh887:
	ldr	q3, [x10, lCPI0_34@PAGEOFF]
Lloh888:
	adrp	x10, lCPI0_35@PAGE
Lloh889:
	ldr	q4, [x10, lCPI0_35@PAGEOFF]
	str	q3, [sp, #7344]
	str	q4, [sp, #7328]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #3232
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	x5, #-5                         ; =0xfffffffffffffffb
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh890:
	adrp	x10, lCPI0_36@PAGE
Lloh891:
	ldr	q3, [x10, lCPI0_36@PAGEOFF]
Lloh892:
	adrp	x10, lCPI0_37@PAGE
Lloh893:
	ldr	q4, [x10, lCPI0_37@PAGEOFF]
	str	q3, [sp, #7440]
	str	q4, [sp, #7424]
Lloh894:
	adrp	x10, lCPI0_38@PAGE
Lloh895:
	ldr	q3, [x10, lCPI0_38@PAGEOFF]
Lloh896:
	adrp	x10, lCPI0_39@PAGE
Lloh897:
	ldr	q4, [x10, lCPI0_39@PAGEOFF]
	str	q3, [sp, #7408]
	str	q4, [sp, #7392]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #3296
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	x5, #-4                         ; =0xfffffffffffffffc
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh898:
	adrp	x10, lCPI0_40@PAGE
Lloh899:
	ldr	q3, [x10, lCPI0_40@PAGEOFF]
Lloh900:
	adrp	x10, lCPI0_41@PAGE
Lloh901:
	ldr	q4, [x10, lCPI0_41@PAGEOFF]
	str	q3, [sp, #7504]
	str	q4, [sp, #7488]
Lloh902:
	adrp	x10, lCPI0_42@PAGE
Lloh903:
	ldr	q3, [x10, lCPI0_42@PAGEOFF]
Lloh904:
	adrp	x10, lCPI0_43@PAGE
Lloh905:
	ldr	q4, [x10, lCPI0_43@PAGEOFF]
	str	q3, [sp, #7472]
	str	q4, [sp, #7456]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #3360
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	x5, #-3                         ; =0xfffffffffffffffd
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh906:
	adrp	x10, lCPI0_44@PAGE
Lloh907:
	ldr	q3, [x10, lCPI0_44@PAGEOFF]
Lloh908:
	adrp	x10, lCPI0_45@PAGE
Lloh909:
	ldr	q4, [x10, lCPI0_45@PAGEOFF]
	str	q3, [sp, #7568]
	str	q4, [sp, #7552]
Lloh910:
	adrp	x10, lCPI0_46@PAGE
Lloh911:
	ldr	q3, [x10, lCPI0_46@PAGEOFF]
Lloh912:
	adrp	x10, lCPI0_47@PAGE
Lloh913:
	ldr	q4, [x10, lCPI0_47@PAGEOFF]
	str	q3, [sp, #7536]
	str	q4, [sp, #7520]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #3424
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	x5, #-2                         ; =0xfffffffffffffffe
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh914:
	adrp	x10, lCPI0_48@PAGE
Lloh915:
	ldr	q3, [x10, lCPI0_48@PAGEOFF]
Lloh916:
	adrp	x10, lCPI0_49@PAGE
Lloh917:
	ldr	q4, [x10, lCPI0_49@PAGEOFF]
	str	q3, [sp, #7632]
	str	q4, [sp, #7616]
Lloh918:
	adrp	x10, lCPI0_50@PAGE
Lloh919:
	ldr	q3, [x10, lCPI0_50@PAGEOFF]
Lloh920:
	adrp	x10, lCPI0_51@PAGE
Lloh921:
	ldr	q4, [x10, lCPI0_51@PAGEOFF]
	str	q3, [sp, #7600]
	str	q4, [sp, #7584]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #3488
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	orr.16b	v16, v14, v16
	orr.16b	v4, v11, v4
	orr.16b	v3, v12, v3
	orr.16b	v5, v13, v5
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh922:
	adrp	x10, lCPI0_52@PAGE
Lloh923:
	ldr	q3, [x10, lCPI0_52@PAGEOFF]
Lloh924:
	adrp	x10, lCPI0_53@PAGE
Lloh925:
	ldr	q4, [x10, lCPI0_53@PAGEOFF]
	str	q3, [sp, #7696]
	str	q4, [sp, #7680]
Lloh926:
	adrp	x10, lCPI0_54@PAGE
Lloh927:
	ldr	q3, [x10, lCPI0_54@PAGEOFF]
Lloh928:
	adrp	x10, lCPI0_55@PAGE
Lloh929:
	ldr	q4, [x10, lCPI0_55@PAGEOFF]
	str	q3, [sp, #7664]
	str	q4, [sp, #7648]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #3552
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	bic.16b	v16, v16, v14
	bic.16b	v4, v4, v11
	bic.16b	v3, v3, v12
	bic.16b	v5, v5, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh930:
	adrp	x10, lCPI0_56@PAGE
Lloh931:
	ldr	q3, [x10, lCPI0_56@PAGEOFF]
Lloh932:
	adrp	x10, lCPI0_57@PAGE
Lloh933:
	ldr	q4, [x10, lCPI0_57@PAGEOFF]
	str	q3, [sp, #7760]
	str	q4, [sp, #7744]
Lloh934:
	adrp	x10, lCPI0_58@PAGE
Lloh935:
	ldr	q3, [x10, lCPI0_58@PAGEOFF]
Lloh936:
	adrp	x10, lCPI0_59@PAGE
Lloh937:
	ldr	q4, [x10, lCPI0_59@PAGEOFF]
	str	q3, [sp, #7728]
	str	q4, [sp, #7712]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #3616
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	bic.16b	v16, v16, v14
	sub.2d	v16, v16, v14
	bic.16b	v4, v4, v11
	sub.2d	v4, v4, v11
	bic.16b	v3, v3, v12
	sub.2d	v3, v3, v12
	bic.16b	v5, v5, v13
	sub.2d	v5, v5, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh938:
	adrp	x10, lCPI0_60@PAGE
Lloh939:
	ldr	q3, [x10, lCPI0_60@PAGEOFF]
Lloh940:
	adrp	x10, lCPI0_61@PAGE
Lloh941:
	ldr	q4, [x10, lCPI0_61@PAGEOFF]
	str	q3, [sp, #7824]
	str	q4, [sp, #7808]
Lloh942:
	adrp	x10, lCPI0_62@PAGE
Lloh943:
	ldr	q3, [x10, lCPI0_62@PAGEOFF]
Lloh944:
	adrp	x10, lCPI0_63@PAGE
Lloh945:
	ldr	q4, [x10, lCPI0_63@PAGEOFF]
	str	q3, [sp, #7792]
	str	q4, [sp, #7776]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #3680
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #2                          ; =0x2
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh946:
	adrp	x10, lCPI0_64@PAGE
Lloh947:
	ldr	q3, [x10, lCPI0_64@PAGEOFF]
Lloh948:
	adrp	x10, lCPI0_65@PAGE
Lloh949:
	ldr	q4, [x10, lCPI0_65@PAGEOFF]
	str	q3, [sp, #7888]
	str	q4, [sp, #7872]
Lloh950:
	adrp	x10, lCPI0_66@PAGE
Lloh951:
	ldr	q3, [x10, lCPI0_66@PAGEOFF]
Lloh952:
	adrp	x10, lCPI0_67@PAGE
Lloh953:
	ldr	q4, [x10, lCPI0_67@PAGEOFF]
	str	q3, [sp, #7856]
	str	q4, [sp, #7840]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #3744
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #3                          ; =0x3
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh954:
	adrp	x10, lCPI0_68@PAGE
Lloh955:
	ldr	q3, [x10, lCPI0_68@PAGEOFF]
Lloh956:
	adrp	x10, lCPI0_69@PAGE
Lloh957:
	ldr	q4, [x10, lCPI0_69@PAGEOFF]
	str	q3, [sp, #7952]
	str	q4, [sp, #7936]
Lloh958:
	adrp	x10, lCPI0_70@PAGE
Lloh959:
	ldr	q3, [x10, lCPI0_70@PAGEOFF]
Lloh960:
	adrp	x10, lCPI0_71@PAGE
Lloh961:
	ldr	q4, [x10, lCPI0_71@PAGEOFF]
	str	q3, [sp, #7920]
	str	q4, [sp, #7904]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #3808
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #4                          ; =0x4
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh962:
	adrp	x10, lCPI0_72@PAGE
Lloh963:
	ldr	q3, [x10, lCPI0_72@PAGEOFF]
Lloh964:
	adrp	x10, lCPI0_73@PAGE
Lloh965:
	ldr	q4, [x10, lCPI0_73@PAGEOFF]
	str	q3, [sp, #8016]
	str	q4, [sp, #8000]
Lloh966:
	adrp	x10, lCPI0_74@PAGE
Lloh967:
	ldr	q3, [x10, lCPI0_74@PAGEOFF]
Lloh968:
	adrp	x10, lCPI0_75@PAGE
Lloh969:
	ldr	q4, [x10, lCPI0_75@PAGEOFF]
	str	q3, [sp, #7984]
	str	q4, [sp, #7968]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #3872
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #5                          ; =0x5
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh970:
	adrp	x10, lCPI0_76@PAGE
Lloh971:
	ldr	q3, [x10, lCPI0_76@PAGEOFF]
Lloh972:
	adrp	x10, lCPI0_77@PAGE
Lloh973:
	ldr	q4, [x10, lCPI0_77@PAGEOFF]
	str	q3, [sp, #8080]
	str	q4, [sp, #8064]
Lloh974:
	adrp	x10, lCPI0_78@PAGE
Lloh975:
	ldr	q3, [x10, lCPI0_78@PAGEOFF]
Lloh976:
	adrp	x10, lCPI0_79@PAGE
Lloh977:
	ldr	q4, [x10, lCPI0_79@PAGEOFF]
	str	q3, [sp, #8048]
	str	q4, [sp, #8032]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #3936
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #6                          ; =0x6
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh978:
	adrp	x10, lCPI0_80@PAGE
Lloh979:
	ldr	q3, [x10, lCPI0_80@PAGEOFF]
Lloh980:
	adrp	x10, lCPI0_81@PAGE
Lloh981:
	ldr	q4, [x10, lCPI0_81@PAGEOFF]
	str	q3, [sp, #8144]
	str	q4, [sp, #8128]
Lloh982:
	adrp	x10, lCPI0_82@PAGE
Lloh983:
	ldr	q3, [x10, lCPI0_82@PAGEOFF]
Lloh984:
	adrp	x10, lCPI0_83@PAGE
Lloh985:
	ldr	q4, [x10, lCPI0_83@PAGEOFF]
	str	q3, [sp, #8112]
	str	q4, [sp, #8096]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #4000
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #7                          ; =0x7
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh986:
	adrp	x10, lCPI0_84@PAGE
Lloh987:
	ldr	q3, [x10, lCPI0_84@PAGEOFF]
Lloh988:
	adrp	x10, lCPI0_85@PAGE
Lloh989:
	ldr	q4, [x10, lCPI0_85@PAGEOFF]
	str	q3, [sp, #8208]
	str	q4, [sp, #8192]
Lloh990:
	adrp	x10, lCPI0_86@PAGE
Lloh991:
	ldr	q3, [x10, lCPI0_86@PAGEOFF]
Lloh992:
	adrp	x10, lCPI0_87@PAGE
Lloh993:
	ldr	q4, [x10, lCPI0_87@PAGEOFF]
	str	q3, [sp, #8176]
	str	q4, [sp, #8160]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #4064
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #8                          ; =0x8
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh994:
	adrp	x10, lCPI0_88@PAGE
Lloh995:
	ldr	q3, [x10, lCPI0_88@PAGEOFF]
Lloh996:
	adrp	x10, lCPI0_89@PAGE
Lloh997:
	ldr	q4, [x10, lCPI0_89@PAGEOFF]
	str	q3, [sp, #8272]
	str	q4, [sp, #8256]
Lloh998:
	adrp	x10, lCPI0_90@PAGE
Lloh999:
	ldr	q3, [x10, lCPI0_90@PAGEOFF]
Lloh1000:
	adrp	x10, lCPI0_91@PAGE
Lloh1001:
	ldr	q4, [x10, lCPI0_91@PAGEOFF]
	str	q3, [sp, #8240]
	str	q4, [sp, #8224]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #32
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #9                          ; =0x9
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1002:
	adrp	x10, lCPI0_92@PAGE
Lloh1003:
	ldr	q3, [x10, lCPI0_92@PAGEOFF]
Lloh1004:
	adrp	x10, lCPI0_93@PAGE
Lloh1005:
	ldr	q4, [x10, lCPI0_93@PAGEOFF]
	str	q3, [sp, #8336]
	str	q4, [sp, #8320]
Lloh1006:
	adrp	x10, lCPI0_94@PAGE
Lloh1007:
	ldr	q3, [x10, lCPI0_94@PAGEOFF]
Lloh1008:
	adrp	x10, lCPI0_95@PAGE
Lloh1009:
	ldr	q4, [x10, lCPI0_95@PAGEOFF]
	str	q3, [sp, #8304]
	str	q4, [sp, #8288]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #96
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #10                         ; =0xa
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh1010:
	adrp	x10, lCPI0_96@PAGE
Lloh1011:
	ldr	q3, [x10, lCPI0_96@PAGEOFF]
Lloh1012:
	adrp	x10, lCPI0_97@PAGE
Lloh1013:
	ldr	q4, [x10, lCPI0_97@PAGEOFF]
	str	q3, [sp, #8400]
	str	q4, [sp, #8384]
Lloh1014:
	adrp	x10, lCPI0_98@PAGE
Lloh1015:
	ldr	q3, [x10, lCPI0_98@PAGEOFF]
Lloh1016:
	adrp	x10, lCPI0_99@PAGE
Lloh1017:
	ldr	q4, [x10, lCPI0_99@PAGEOFF]
	str	q3, [sp, #8368]
	str	q4, [sp, #8352]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #160
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #11                         ; =0xb
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1018:
	adrp	x10, lCPI0_100@PAGE
Lloh1019:
	ldr	q3, [x10, lCPI0_100@PAGEOFF]
Lloh1020:
	adrp	x10, lCPI0_101@PAGE
Lloh1021:
	ldr	q4, [x10, lCPI0_101@PAGEOFF]
	str	q3, [sp, #8464]
	str	q4, [sp, #8448]
Lloh1022:
	adrp	x10, lCPI0_102@PAGE
Lloh1023:
	ldr	q3, [x10, lCPI0_102@PAGEOFF]
Lloh1024:
	adrp	x10, lCPI0_103@PAGE
Lloh1025:
	ldr	q4, [x10, lCPI0_103@PAGEOFF]
	str	q3, [sp, #8432]
	str	q4, [sp, #8416]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #224
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #12                         ; =0xc
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1026:
	adrp	x10, lCPI0_104@PAGE
Lloh1027:
	ldr	q3, [x10, lCPI0_104@PAGEOFF]
Lloh1028:
	adrp	x10, lCPI0_105@PAGE
Lloh1029:
	ldr	q4, [x10, lCPI0_105@PAGEOFF]
	str	q3, [sp, #8528]
	str	q4, [sp, #8512]
Lloh1030:
	adrp	x10, lCPI0_106@PAGE
Lloh1031:
	ldr	q3, [x10, lCPI0_106@PAGEOFF]
Lloh1032:
	adrp	x10, lCPI0_107@PAGE
Lloh1033:
	ldr	q4, [x10, lCPI0_107@PAGEOFF]
	str	q3, [sp, #8496]
	str	q4, [sp, #8480]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #288
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #13                         ; =0xd
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh1034:
	adrp	x10, lCPI0_108@PAGE
Lloh1035:
	ldr	q3, [x10, lCPI0_108@PAGEOFF]
Lloh1036:
	adrp	x10, lCPI0_109@PAGE
Lloh1037:
	ldr	q4, [x10, lCPI0_109@PAGEOFF]
	str	q3, [sp, #8592]
	str	q4, [sp, #8576]
Lloh1038:
	adrp	x10, lCPI0_110@PAGE
Lloh1039:
	ldr	q3, [x10, lCPI0_110@PAGEOFF]
Lloh1040:
	adrp	x10, lCPI0_111@PAGE
Lloh1041:
	ldr	q4, [x10, lCPI0_111@PAGEOFF]
	str	q3, [sp, #8560]
	str	q4, [sp, #8544]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #352
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #14                         ; =0xe
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1042:
	adrp	x10, lCPI0_112@PAGE
Lloh1043:
	ldr	q3, [x10, lCPI0_112@PAGEOFF]
Lloh1044:
	adrp	x10, lCPI0_113@PAGE
Lloh1045:
	ldr	q4, [x10, lCPI0_113@PAGEOFF]
	str	q3, [sp, #8656]
	str	q4, [sp, #8640]
Lloh1046:
	adrp	x10, lCPI0_114@PAGE
Lloh1047:
	ldr	q3, [x10, lCPI0_114@PAGEOFF]
Lloh1048:
	adrp	x10, lCPI0_115@PAGE
Lloh1049:
	ldr	q4, [x10, lCPI0_115@PAGEOFF]
	str	q3, [sp, #8624]
	str	q4, [sp, #8608]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #416
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #15                         ; =0xf
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1050:
	adrp	x10, lCPI0_116@PAGE
Lloh1051:
	ldr	q3, [x10, lCPI0_116@PAGEOFF]
Lloh1052:
	adrp	x10, lCPI0_117@PAGE
Lloh1053:
	ldr	q4, [x10, lCPI0_117@PAGEOFF]
	str	q3, [sp, #8720]
	str	q4, [sp, #8704]
Lloh1054:
	adrp	x10, lCPI0_118@PAGE
Lloh1055:
	ldr	q3, [x10, lCPI0_118@PAGEOFF]
Lloh1056:
	adrp	x10, lCPI0_119@PAGE
Lloh1057:
	ldr	q4, [x10, lCPI0_119@PAGEOFF]
	str	q3, [sp, #8688]
	str	q4, [sp, #8672]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #480
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #16                         ; =0x10
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh1058:
	adrp	x10, lCPI0_120@PAGE
Lloh1059:
	ldr	q3, [x10, lCPI0_120@PAGEOFF]
Lloh1060:
	adrp	x10, lCPI0_121@PAGE
Lloh1061:
	ldr	q4, [x10, lCPI0_121@PAGEOFF]
	str	q3, [sp, #8784]
	str	q4, [sp, #8768]
Lloh1062:
	adrp	x10, lCPI0_122@PAGE
Lloh1063:
	ldr	q3, [x10, lCPI0_122@PAGEOFF]
Lloh1064:
	adrp	x10, lCPI0_123@PAGE
Lloh1065:
	ldr	q4, [x10, lCPI0_123@PAGEOFF]
	str	q3, [sp, #8752]
	str	q4, [sp, #8736]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #544
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #17                         ; =0x11
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1066:
	adrp	x10, lCPI0_124@PAGE
Lloh1067:
	ldr	q3, [x10, lCPI0_124@PAGEOFF]
Lloh1068:
	adrp	x10, lCPI0_125@PAGE
Lloh1069:
	ldr	q4, [x10, lCPI0_125@PAGEOFF]
	str	q3, [sp, #8848]
	str	q4, [sp, #8832]
Lloh1070:
	adrp	x10, lCPI0_126@PAGE
Lloh1071:
	ldr	q3, [x10, lCPI0_126@PAGEOFF]
Lloh1072:
	adrp	x10, lCPI0_127@PAGE
Lloh1073:
	ldr	q4, [x10, lCPI0_127@PAGEOFF]
	str	q3, [sp, #8816]
	str	q4, [sp, #8800]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #608
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #18                         ; =0x12
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1074:
	adrp	x10, lCPI0_128@PAGE
Lloh1075:
	ldr	q3, [x10, lCPI0_128@PAGEOFF]
Lloh1076:
	adrp	x10, lCPI0_129@PAGE
Lloh1077:
	ldr	q4, [x10, lCPI0_129@PAGEOFF]
	str	q3, [sp, #8912]
	str	q4, [sp, #8896]
Lloh1078:
	adrp	x10, lCPI0_130@PAGE
Lloh1079:
	ldr	q3, [x10, lCPI0_130@PAGEOFF]
Lloh1080:
	adrp	x10, lCPI0_131@PAGE
Lloh1081:
	ldr	q4, [x10, lCPI0_131@PAGEOFF]
	str	q3, [sp, #8880]
	str	q4, [sp, #8864]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #672
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #19                         ; =0x13
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh1082:
	adrp	x10, lCPI0_132@PAGE
Lloh1083:
	ldr	q3, [x10, lCPI0_132@PAGEOFF]
Lloh1084:
	adrp	x10, lCPI0_133@PAGE
Lloh1085:
	ldr	q4, [x10, lCPI0_133@PAGEOFF]
	str	q3, [sp, #8976]
	str	q4, [sp, #8960]
Lloh1086:
	adrp	x10, lCPI0_134@PAGE
Lloh1087:
	ldr	q3, [x10, lCPI0_134@PAGEOFF]
Lloh1088:
	adrp	x10, lCPI0_135@PAGE
Lloh1089:
	ldr	q4, [x10, lCPI0_135@PAGEOFF]
	str	q3, [sp, #8944]
	str	q4, [sp, #8928]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #736
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #20                         ; =0x14
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1090:
	adrp	x10, lCPI0_136@PAGE
Lloh1091:
	ldr	q3, [x10, lCPI0_136@PAGEOFF]
Lloh1092:
	adrp	x10, lCPI0_137@PAGE
Lloh1093:
	ldr	q4, [x10, lCPI0_137@PAGEOFF]
	str	q3, [sp, #9040]
	str	q4, [sp, #9024]
Lloh1094:
	adrp	x10, lCPI0_138@PAGE
Lloh1095:
	ldr	q3, [x10, lCPI0_138@PAGEOFF]
Lloh1096:
	adrp	x10, lCPI0_139@PAGE
Lloh1097:
	ldr	q4, [x10, lCPI0_139@PAGEOFF]
	str	q3, [sp, #9008]
	str	q4, [sp, #8992]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #800
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #21                         ; =0x15
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1098:
	adrp	x10, lCPI0_140@PAGE
Lloh1099:
	ldr	q3, [x10, lCPI0_140@PAGEOFF]
Lloh1100:
	adrp	x10, lCPI0_141@PAGE
Lloh1101:
	ldr	q4, [x10, lCPI0_141@PAGEOFF]
	str	q3, [sp, #9104]
	str	q4, [sp, #9088]
Lloh1102:
	adrp	x10, lCPI0_142@PAGE
Lloh1103:
	ldr	q3, [x10, lCPI0_142@PAGEOFF]
Lloh1104:
	adrp	x10, lCPI0_143@PAGE
Lloh1105:
	ldr	q4, [x10, lCPI0_143@PAGEOFF]
	str	q3, [sp, #9072]
	str	q4, [sp, #9056]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #864
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #22                         ; =0x16
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh1106:
	adrp	x10, lCPI0_144@PAGE
Lloh1107:
	ldr	q3, [x10, lCPI0_144@PAGEOFF]
Lloh1108:
	adrp	x10, lCPI0_145@PAGE
Lloh1109:
	ldr	q4, [x10, lCPI0_145@PAGEOFF]
	str	q3, [sp, #9168]
	str	q4, [sp, #9152]
Lloh1110:
	adrp	x10, lCPI0_146@PAGE
Lloh1111:
	ldr	q3, [x10, lCPI0_146@PAGEOFF]
Lloh1112:
	adrp	x10, lCPI0_147@PAGE
Lloh1113:
	ldr	q4, [x10, lCPI0_147@PAGEOFF]
	str	q3, [sp, #9136]
	str	q4, [sp, #9120]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #928
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w2, #23                         ; =0x17
	dup.2d	v17, x2
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
	ldr	q3, [sp, #16864]
	ldr	q4, [sp, #16880]
	ldr	q5, [sp, #16832]
	ldr	q16, [sp, #16848]
	ldr	q17, [sp, #16800]
	ldr	q18, [sp, #16816]
	ldr	q19, [sp, #16768]
	ldr	q22, [sp, #16784]
	ldr	q23, [sp, #240]                 ; 16-byte Folded Reload
	bit.16b	v22, v23, v11
	bit.16b	v19, v23, v12
	bit.16b	v18, v23, v13
	bit.16b	v17, v23, v14
Lloh1114:
	adrp	x10, lCPI0_17@PAGE
Lloh1115:
	ldr	q23, [x10, lCPI0_17@PAGEOFF]
	bit.16b	v16, v23, v11
Lloh1116:
	adrp	x10, lCPI0_16@PAGE
Lloh1117:
	ldr	q23, [x10, lCPI0_16@PAGEOFF]
	bit.16b	v5, v23, v12
Lloh1118:
	adrp	x10, lCPI0_19@PAGE
Lloh1119:
	ldr	q23, [x10, lCPI0_19@PAGEOFF]
	bit.16b	v4, v23, v13
Lloh1120:
	adrp	x10, lCPI0_18@PAGE
Lloh1121:
	ldr	q23, [x10, lCPI0_18@PAGEOFF]
	bit.16b	v3, v23, v14
	str	q3, [sp, #16864]
	str	q4, [sp, #16880]
	str	q5, [sp, #16832]
	str	q16, [sp, #16848]
	str	q17, [sp, #16800]
	str	q18, [sp, #16816]
	str	q19, [sp, #16768]
	str	q22, [sp, #16784]
	ldr	q3, [sp, #1120]                 ; 16-byte Folded Reload
	bic.16b	v3, v3, v13
	str	q3, [sp, #1120]                 ; 16-byte Folded Spill
	bic.16b	v0, v0, v14
	str	q0, [sp, #912]                  ; 16-byte Folded Spill
	ldr	q0, [sp, #1136]                 ; 16-byte Folded Reload
	bic.16b	v0, v0, v11
	str	q0, [sp, #1136]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #1152]                 ; 16-byte Folded Reload
	bic.16b	v0, v0, v12
LBB0_626:                               ; %schedule.30
                                        ;   in Loop: Header=BB0_7 Depth=3
	str	q0, [sp, #1152]                 ; 16-byte Folded Spill
LBB0_627:                               ; %schedule.30
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	mov	w2, #128                        ; =0x80
	dup.2d	v3, x2
	ldr	q17, [sp, #1136]                ; 16-byte Folded Reload
	cmgt.2d	v4, v3, v17
	ldr	q0, [sp, #1152]                 ; 16-byte Folded Reload
	cmgt.2d	v5, v3, v0
	uzp1.4s	v4, v5, v4
	ldr	q18, [sp, #912]                 ; 16-byte Folded Reload
	cmgt.2d	v5, v3, v18
	ldr	q19, [sp, #1120]                ; 16-byte Folded Reload
	cmgt.2d	v16, v3, v19
	uzp1.4s	v5, v5, v16
	uzp1.8h	v4, v4, v5
	xtn.8b	v4, v4
	and.8b	v11, v10, v4
	shl.8b	v4, v11, #7
	cmlt.8b	v4, v4, #0
	and.8b	v5, v4, v2
	addv.8b	b5, v5
	fmov	w2, s5
	umaxv.8b	b4, v4
	fmov	w4, s4
	tbz	w4, #0, LBB0_633
; %bb.628:                              ; %schedule.30
                                        ;   in Loop: Header=BB0_7 Depth=3
	cmge.2d	v4, v17, v3
	cmge.2d	v5, v0, v3
	uzp1.4s	v4, v5, v4
	cmge.2d	v5, v18, v3
	cmge.2d	v3, v19, v3
	uzp1.4s	v3, v5, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v12, v10, v3
	shl.8b	v3, v12, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w4, s3
	tst	w4, #0xff
	b.eq	LBB0_633
; %bb.629:                              ; %varying.divergent699
                                        ;   in Loop: Header=BB0_7 Depth=3
	subs	w10, w1, #1
	csel	w10, wzr, w10, lo
	and	w3, w17, #0xff
	lsr	w2, w3, w10
	tst	w2, #0x1
	str	q9, [sp, #3584]
	str	q8, [sp, #3600]
	and	x10, x10, #0x7
	add	x2, sp, #3584
	ldr	w10, [x2, x10, lsl #2]
	ccmp	w1, #0, #4, ne
	ccmp	w10, #11, #0, ne
	cset	w2, ne
	cmp	w3, #255
	b.ne	LBB0_631
; %bb.630:                              ; %varying.divergent699
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #0, LBB0_1006
LBB0_631:                               ; %convergence.overflow.resume702
                                        ;   in Loop: Header=BB0_7 Depth=3
	mvn	w10, w17
	rbit	w10, w10
	clz	w10, w10
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w17
	csel	w4, wzr, w10, eq
	add	x3, sp, #18, lsl #12            ; =73728
	add	x3, x3, #752
	ldrb	w10, [x3, w4, uxtw]
	and	w5, w10, #0x1
	fmov	s3, w5
	ubfx	w5, w10, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w10, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w10, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w10, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w10, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w10, #6, #1
	mov.b	v3[6], w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x5, w4, uxtw]
	and	w6, w10, #0x1
	fmov	s4, w6
	ubfx	w6, w10, #1, #1
	mov.b	v4[1], w6
	ubfx	w6, w10, #2, #1
	mov.b	v4[2], w6
	ubfx	w6, w10, #3, #1
	mov.b	v4[3], w6
	ubfx	w6, w10, #4, #1
	mov.b	v4[4], w6
	ubfx	w6, w10, #5, #1
	mov.b	v4[5], w6
	ubfx	w6, w10, #6, #1
	mov.b	v4[6], w6
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	cmp	w2, #0
	csetm	w10, ne
	dup.8b	v5, w10
	bit.8b	v3, v10, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x3, w4, uxtw]
	bic.8b	v3, v4, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w4, uxtw]
	cmp	x0, #8
	b.hs	LBB0_1006
; %bb.632:                              ; %ready.overflow.resume704
                                        ;   in Loop: Header=BB0_7 Depth=3
	str	q7, [sp, #3552]
	str	q6, [sp, #3568]
	ubfiz	x10, x4, #2, #3
	add	x3, sp, #3552
	ldr	w3, [x3, x10]
	cmp	w2, #0
	csel	w3, w1, w3, ne
	csinc	w1, w1, w4, eq
	str	q7, [sp, #3520]
	str	q6, [sp, #3536]
	add	x5, sp, #3520
	str	w3, [x5, x10]
	ldr	q6, [sp, #3536]
	ldr	q7, [sp, #3520]
	str	q9, [sp, #3488]
	str	q8, [sp, #3504]
	add	x3, sp, #3488
	ldr	w3, [x3, x10]
	mov	w5, #11                         ; =0xb
	csel	w3, w5, w3, ne
	str	q9, [sp, #3456]
	str	q8, [sp, #3472]
	add	x5, sp, #3456
	str	w3, [x5, x10]
	mov	w3, #34                         ; =0x22
	mov	w5, #31                         ; =0x1f
	ldr	q8, [sp, #3472]
	ldr	q9, [sp, #3456]
	b	LBB0_938
LBB0_633:                               ; %varying.coherent700
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_688
; %bb.634:                              ; %varying.coherent.true705
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
	tst	w3, #0xff
	b.eq	LBB0_5
LBB0_635:                               ; %schedule.31
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.16b	v0, v21
	mov.16b	v21, v20
	mov.16b	v20, v15
	mov	b3, v10[0]
	mov.b	v3[4], v10[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v4, v3, #0
	ldr	q3, [sp, #1152]                 ; 16-byte Folded Reload
	and.16b	v18, v4, v3
	mov	b3, v10[2]
	mov.b	v3[4], v10[3]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v5, v3, #0
	ldr	q3, [sp, #1136]                 ; 16-byte Folded Reload
	and.16b	v19, v5, v3
	mov	b3, v10[4]
	mov.b	v3[4], v10[5]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v24, v3, #0
	ldr	q3, [sp, #912]                  ; 16-byte Folded Reload
	and.16b	v26, v24, v3
	mov	b3, v10[6]
	mov.b	v3[4], v10[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v25, v3, #0
	ldr	q3, [sp, #1120]                 ; 16-byte Folded Reload
	and.16b	v3, v25, v3
	shl.8b	v16, v10, #7
	cmlt.8b	v16, v16, #0
	and.8b	v17, v16, v2
	addv.8b	b13, v17
	fmov	w3, s13
	mov	w4, #32                         ; =0x20
	dup.2d	v27, x4
	and.16b	v17, v4, v27
	mvn.16b	v4, v4
	sub.2d	v17, v17, v4
	and.16b	v4, v5, v27
	mvn.16b	v5, v5
	sub.2d	v4, v4, v5
	and.16b	v5, v24, v27
	and.16b	v27, v25, v27
	mvn.16b	v25, v25
	sub.2d	v25, v27, v25
	mov.d	x4, v25[1]
	mov.d	x5, v3[1]
	sdiv	x5, x5, x4
	mvn.16b	v24, v24
	sub.2d	v5, v5, v24
	fmov	x6, d25
	fmov	x7, d3
	sdiv	x7, x7, x6
	mul	x6, x7, x6
	fmov	d11, x7
	mov.d	v11[1], x5
	mov.d	x7, v5[1]
	mov.d	x19, v26[1]
	sdiv	x19, x19, x7
	fmov	x20, d5
	fmov	x21, d26
	sdiv	x21, x21, x20
	mul	x20, x21, x20
	fmov	d12, x21
	mov.d	v12[1], x19
	mov.d	x21, v4[1]
	mov.d	x22, v19[1]
	sdiv	x22, x22, x21
	fmov	x23, d4
	fmov	x24, d19
	sdiv	x24, x24, x23
	mul	x23, x24, x23
	fmov	d14, x24
	mov.d	v14[1], x22
	mov.d	x24, v17[1]
	mov.d	x25, v18[1]
	fmov	x26, d17
	fmov	x27, d18
	sdiv	x27, x27, x26
	mul	x26, x27, x26
	fmov	d17, x27
	sdiv	x25, x25, x24
	mov.d	v17[1], x25
	mul	x24, x25, x24
	fmov	d4, x26
	mov.d	v4[1], x24
	mul	x21, x22, x21
	fmov	d5, x23
	mov.d	v5[1], x21
	mul	x7, x19, x7
	fmov	d24, x20
	mov.d	v24[1], x7
	mul	x4, x5, x4
	fmov	d25, x6
	mov.d	v25[1], x4
	sub.2d	v3, v3, v25
	sub.2d	v24, v26, v24
	sub.2d	v5, v19, v5
	sub.2d	v4, v18, v4
	dup.2d	v18, x16
	add.2d	v4, v4, v18
	add.2d	v5, v5, v18
	add.2d	v19, v24, v18
	add.2d	v3, v3, v18
	ldr	q18, [sp, #16896]
	ldr	q24, [sp, #16912]
	ldr	q25, [sp, #16928]
	ldr	q26, [sp, #16944]
	ldr	q27, [sp, #17008]
	ldr	q28, [sp, #16992]
	ldr	q29, [sp, #16976]
	shl.2d	v3, v3, #6
	shl.2d	v19, v19, #6
	shl.2d	v5, v5, #6
	shl.2d	v30, v4, #6
	ldr	q15, [sp, #16960]
	add.2d	v4, v26, v27
	add.2d	v31, v4, v3
	add.2d	v3, v25, v28
	add.2d	v3, v3, v19
	add.2d	v4, v24, v29
	add.2d	v4, v4, v5
	add.2d	v5, v18, v15
	add.2d	v15, v5, v30
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	tbnz	w3, #0, LBB0_674
; %bb.636:                              ; %else4606
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #1, LBB0_675
LBB0_637:                               ; %else4612
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.16b	v15, v20
	mov.16b	v20, v21
	tbnz	w3, #2, LBB0_676
LBB0_638:                               ; %else4618
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.16b	v21, v0
	tbnz	w3, #3, LBB0_677
LBB0_639:                               ; %else4624
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #4, LBB0_678
LBB0_640:                               ; %else4630
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #5, LBB0_679
LBB0_641:                               ; %else4636
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #6, LBB0_680
LBB0_642:                               ; %else4642
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w3, #7, LBB0_644
LBB0_643:                               ; %cond.load4644
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v31[1]
	ld1.d	{ v27 }[1], [x3]
LBB0_644:                               ; %else4648
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w3, #32                         ; =0x20
	dup.2d	v3, x3
	cmhi.2d	v4, v3, v19
	cmhi.2d	v5, v3, v18
	uzp1.4s	v4, v5, v4
	cmhi.2d	v5, v3, v26
	cmhi.2d	v3, v3, v27
	uzp1.4s	v3, v5, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	ldrb	w3, [x9, #512]
	and	w4, w3, #0x1
	fmov	s4, w4
	ubfx	w4, w3, #1, #1
	mov.b	v4[1], w4
	ubfx	w4, w3, #2, #1
	mov.b	v4[2], w4
	ubfx	w4, w3, #3, #1
	mov.b	v4[3], w4
	ubfx	w4, w3, #4, #1
	mov.b	v4[4], w4
	ubfx	w4, w3, #5, #1
	mov.b	v4[5], w4
	ubfx	w4, w3, #6, #1
	mov.b	v4[6], w4
	lsr	w3, w3, #7
	mov.b	v4[7], w3
	bif.8b	v3, v4, v16
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x9, #512]
	shl.2d	v5, v14, #5
	shl.2d	v4, v17, #5
	shl.2d	v16, v11, #5
	shl.2d	v3, v12, #5
	add.2d	v3, v26, v3
	add.2d	v16, v27, v16
	add.2d	v4, v18, v4
	add.2d	v17, v19, v5
	ldr	q5, [sp, #16672]
	ldr	q18, [sp, #16688]
	ldr	q19, [sp, #16640]
	ldr	q24, [sp, #16656]
	mov	b25, v10[2]
	mov.b	v25[4], v10[3]
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	mov	b26, v10[0]
	mov.b	v26[4], v10[1]
	bit.16b	v24, v17, v25
	ushll.2d	v25, v26, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	bit.16b	v19, v4, v25
	mov	b25, v10[6]
	mov.b	v25[4], v10[7]
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	bit.16b	v18, v16, v25
	mov	b25, v10[4]
	mov.b	v25[4], v10[5]
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	bit.16b	v5, v3, v25
	str	q5, [sp, #16672]
	str	q18, [sp, #16688]
	str	q19, [sp, #16640]
	str	q24, [sp, #16656]
	mov	w3, #128                        ; =0x80
	dup.2d	v18, x3
	cmhi.2d	v5, v18, v4
	cmhi.2d	v19, v18, v17
	uzp1.4s	v5, v5, v19
	cmhi.2d	v19, v18, v3
	cmhi.2d	v24, v18, v16
	uzp1.4s	v19, v19, v24
	uzp1.8h	v5, v5, v19
	xtn.8b	v5, v5
	and.8b	v11, v10, v5
	shl.8b	v5, v11, #7
	cmlt.8b	v5, v5, #0
	and.8b	v19, v5, v2
	addv.8b	b19, v19
	fmov	w3, s19
	umaxv.8b	b5, v5
	fmov	w4, s5
	tbz	w4, #0, LBB0_650
; %bb.645:                              ; %else4648
                                        ;   in Loop: Header=BB0_7 Depth=3
	cmhs.2d	v4, v4, v18
	cmhs.2d	v5, v17, v18
	uzp1.4s	v4, v4, v5
	cmhs.2d	v3, v3, v18
	cmhs.2d	v5, v16, v18
	uzp1.4s	v3, v3, v5
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v12, v10, v3
	shl.8b	v3, v12, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w4, s3
	tst	w4, #0xff
	b.eq	LBB0_650
; %bb.646:                              ; %varying.divergent713
                                        ;   in Loop: Header=BB0_7 Depth=3
	subs	w10, w1, #1
	csel	w10, wzr, w10, lo
	and	w3, w17, #0xff
	lsr	w2, w3, w10
	tst	w2, #0x1
	str	q9, [sp, #3744]
	str	q8, [sp, #3760]
	and	x10, x10, #0x7
	add	x2, sp, #3744
	ldr	w10, [x2, x10, lsl #2]
	ccmp	w1, #0, #4, ne
	ccmp	w10, #12, #0, ne
	cset	w2, ne
	cmp	w3, #255
	b.ne	LBB0_648
; %bb.647:                              ; %varying.divergent713
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #0, LBB0_1006
LBB0_648:                               ; %convergence.overflow.resume716
                                        ;   in Loop: Header=BB0_7 Depth=3
	mvn	w10, w17
	rbit	w10, w10
	clz	w10, w10
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w17
	csel	w4, wzr, w10, eq
	add	x3, sp, #18, lsl #12            ; =73728
	add	x3, x3, #752
	ldrb	w10, [x3, w4, uxtw]
	and	w5, w10, #0x1
	fmov	s3, w5
	ubfx	w5, w10, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w10, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w10, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w10, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w10, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w10, #6, #1
	mov.b	v3[6], w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x5, w4, uxtw]
	and	w6, w10, #0x1
	fmov	s4, w6
	ubfx	w6, w10, #1, #1
	mov.b	v4[1], w6
	ubfx	w6, w10, #2, #1
	mov.b	v4[2], w6
	ubfx	w6, w10, #3, #1
	mov.b	v4[3], w6
	ubfx	w6, w10, #4, #1
	mov.b	v4[4], w6
	ubfx	w6, w10, #5, #1
	mov.b	v4[5], w6
	ubfx	w6, w10, #6, #1
	mov.b	v4[6], w6
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	cmp	w2, #0
	csetm	w10, ne
	dup.8b	v5, w10
	bit.8b	v3, v10, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x3, w4, uxtw]
	bic.8b	v3, v4, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w4, uxtw]
	cmp	x0, #8
	b.hs	LBB0_1006
; %bb.649:                              ; %ready.overflow.resume718
                                        ;   in Loop: Header=BB0_7 Depth=3
	zip2.8b	v3, v12, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldp	q5, q0, [sp, #576]              ; 32-byte Folded Reload
	and.16b	v4, v3, v5
	zip1.8b	v3, v12, v5
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v0, v3, v0
	stp	q4, q0, [sp, #576]              ; 32-byte Folded Spill
	str	q7, [sp, #3712]
	str	q6, [sp, #3728]
	ubfiz	x10, x4, #2, #3
	add	x3, sp, #3712
	ldr	w3, [x3, x10]
	cmp	w2, #0
	csel	w3, w1, w3, ne
	csinc	w1, w1, w4, eq
	str	q7, [sp, #3680]
	str	q6, [sp, #3696]
	add	x5, sp, #3680
	str	w3, [x5, x10]
	ldr	q6, [sp, #3696]
	ldr	q7, [sp, #3680]
	str	q9, [sp, #3648]
	str	q8, [sp, #3664]
	add	x3, sp, #3648
	ldr	w3, [x3, x10]
	mov	w5, #12                         ; =0xc
	csel	w3, w5, w3, ne
	str	q9, [sp, #3616]
	str	q8, [sp, #3632]
	add	x5, sp, #3616
	str	w3, [x5, x10]
	mov	w3, #33                         ; =0x21
	mov	w5, #32                         ; =0x20
	ldr	q8, [sp, #3632]
	ldr	q9, [sp, #3616]
	b	LBB0_938
LBB0_650:                               ; %varying.coherent714
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_697
; %bb.651:                              ; %varying.coherent.true719
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w2, #0, LBB0_652
	b	LBB0_5
LBB0_652:                               ; %schedule.32.thread
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q3, [sp, #17024]
	ldr	q4, [sp, #17040]
	ldr	q5, [sp, #17056]
	ldr	q16, [sp, #17072]
	ldr	q17, [sp, #17136]
	ldr	q18, [sp, #17120]
	ldr	q19, [sp, #17104]
	ldr	q22, [sp, #17088]
	ldr	q23, [sp, #16640]
	ldr	q24, [sp, #16656]
	ldr	q25, [sp, #16672]
	ldr	q26, [sp, #16688]
	shl.2d	v26, v26, #5
	shl.2d	v25, v25, #5
	shl.2d	v24, v24, #5
	shl.2d	v23, v23, #5
	add.2d	v16, v16, v17
	add.2d	v17, v16, v26
	add.2d	v5, v5, v18
	add.2d	v18, v5, v25
	add.2d	v4, v4, v19
	add.2d	v4, v4, v24
	add.2d	v3, v3, v22
	add.2d	v19, v3, v23
	fmov	w2, s13
	movi.2d	v16, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w2, #0, LBB0_698
; %bb.653:                              ; %else5441
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #1, LBB0_699
LBB0_654:                               ; %else5447
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #2, LBB0_700
LBB0_655:                               ; %else5453
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #3, LBB0_701
LBB0_656:                               ; %else5459
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #4, LBB0_702
LBB0_657:                               ; %else5465
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #5, LBB0_703
LBB0_658:                               ; %else5471
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #6, LBB0_704
LBB0_659:                               ; %else5477
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w2, #7, LBB0_661
LBB0_660:                               ; %cond.load5479
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v17[1]
	ld1.s	{ v3 }[3], [x10]
LBB0_661:                               ; %else5483
                                        ;   in Loop: Header=BB0_7 Depth=3
	zip2.8b	v4, v10, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q0, [sp, #576]                  ; 16-byte Folded Reload
	bit.16b	v0, v3, v4
	str	q0, [sp, #576]                  ; 16-byte Folded Spill
	zip1.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q0, [sp, #592]                  ; 16-byte Folded Reload
	bit.16b	v0, v16, v3
	str	q0, [sp, #592]                  ; 16-byte Folded Spill
	cbnz	w1, LBB0_68
LBB0_662:                               ; %schedule.33.convergence.cascade.exit724_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
LBB0_663:                               ; %convergence.cascade.exit724
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
; %bb.664:                              ; %convergence.target.33.ready
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q0, [sp, #768]                  ; 16-byte Folded Reload
	dup.4s	v4, v0[0]
	ldrb	w10, [x9, #512]
	ubfx	w2, w10, #3, #1
	ubfx	w3, w10, #2, #1
	ubfx	w4, w10, #1, #1
	and	w5, w10, #0x1
	lsr	w6, w10, #7
	ubfx	w7, w10, #6, #1
	ubfx	w19, w10, #5, #1
	ubfx	w10, w10, #4, #1
	fmov	s3, w10
	mov.h	v3[1], w19
	mov.h	v3[2], w7
	mov.h	v3[3], w6
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	fmov	s5, w5
	mov.h	v5[1], w4
	mov.h	v5[2], w3
	mov.h	v5[3], w2
	ldr	q0, [sp, #576]                  ; 16-byte Folded Reload
	bsl.16b	v3, v0, v4
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q0, [sp, #592]                  ; 16-byte Folded Reload
	mov.16b	v16, v5
	bsl.16b	v16, v0, v4
	ldr	q4, [sp, #16816]
	ldr	q5, [sp, #16800]
	ldr	q17, [sp, #16784]
	ldr	q18, [sp, #16768]
	ldr	q19, [sp, #16832]
	ldr	q22, [sp, #16848]
	ldr	q23, [sp, #16864]
	ldr	q24, [sp, #16880]
	ldr	q0, [sp, #1152]                 ; 16-byte Folded Reload
	shl.2d	v25, v0, #5
	ldr	q0, [sp, #1136]                 ; 16-byte Folded Reload
	shl.2d	v26, v0, #5
	ldr	q0, [sp, #912]                  ; 16-byte Folded Reload
	shl.2d	v27, v0, #5
	ldr	q0, [sp, #1120]                 ; 16-byte Folded Reload
	shl.2d	v28, v0, #5
	add.2d	v24, v24, v28
	add.2d	v23, v23, v27
	add.2d	v22, v22, v26
	add.2d	v19, v19, v25
	add.2d	v19, v18, v19
	add.2d	v18, v17, v22
	add.2d	v17, v5, v23
	add.2d	v4, v4, v24
	shl.8b	v5, v10, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	fmov	w2, s5
	tbnz	w2, #0, LBB0_681
; %bb.665:                              ; %else5489
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #1, LBB0_682
LBB0_666:                               ; %else5493
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q0, [sp, #1152]                 ; 16-byte Folded Reload
	ldr	q5, [sp, #1136]                 ; 16-byte Folded Reload
	tbnz	w2, #2, LBB0_683
LBB0_667:                               ; %else5497
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #3, LBB0_684
LBB0_668:                               ; %else5501
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #4, LBB0_685
LBB0_669:                               ; %else5505
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #5, LBB0_686
LBB0_670:                               ; %else5509
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #6, LBB0_687
LBB0_671:                               ; %else5513
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w2, #7, LBB0_673
LBB0_672:                               ; %cond.store5514
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v4[1]
	st1.s	{ v3 }[3], [x10]
LBB0_673:                               ; %else5517
                                        ;   in Loop: Header=BB0_7 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v10, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v4, v3, #0
	ushll2.4s	v3, v3, #0
	ldr	q16, [sp, #1120]                ; 16-byte Folded Reload
	uaddw2.2d	v16, v16, v3
	str	q16, [sp, #1120]                ; 16-byte Folded Spill
	ldr	q16, [sp, #912]                 ; 16-byte Folded Reload
	uaddw.2d	v16, v16, v3
	str	q16, [sp, #912]                 ; 16-byte Folded Spill
	uaddw2.2d	v5, v5, v4
	str	q5, [sp, #1136]                 ; 16-byte Folded Spill
	uaddw.2d	v0, v0, v4
	b	LBB0_626
LBB0_674:                               ; %cond.load4602
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d15
	ldr	d18, [x4]
	tbz	w3, #1, LBB0_637
LBB0_675:                               ; %cond.load4608
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v15[1]
	ld1.d	{ v18 }[1], [x4]
	mov.16b	v15, v20
	mov.16b	v20, v21
	tbz	w3, #2, LBB0_638
LBB0_676:                               ; %cond.load4614
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d4
	ld1.d	{ v19 }[0], [x4]
	mov.16b	v21, v0
	tbz	w3, #3, LBB0_639
LBB0_677:                               ; %cond.load4620
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v4[1]
	ld1.d	{ v19 }[1], [x4]
	tbz	w3, #4, LBB0_640
LBB0_678:                               ; %cond.load4626
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d3
	ld1.d	{ v26 }[0], [x4]
	tbz	w3, #5, LBB0_641
LBB0_679:                               ; %cond.load4632
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v3[1]
	ld1.d	{ v26 }[1], [x4]
	tbz	w3, #6, LBB0_642
LBB0_680:                               ; %cond.load4638
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d31
	ld1.d	{ v27 }[0], [x4]
	tbnz	w3, #7, LBB0_643
	b	LBB0_644
LBB0_681:                               ; %cond.store5486
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d19
	str	s16, [x10]
	tbz	w2, #1, LBB0_666
LBB0_682:                               ; %cond.store5490
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v19[1]
	st1.s	{ v16 }[1], [x10]
	ldr	q0, [sp, #1152]                 ; 16-byte Folded Reload
	ldr	q5, [sp, #1136]                 ; 16-byte Folded Reload
	tbz	w2, #2, LBB0_667
LBB0_683:                               ; %cond.store5494
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d18
	st1.s	{ v16 }[2], [x10]
	tbz	w2, #3, LBB0_668
LBB0_684:                               ; %cond.store5498
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v18[1]
	st1.s	{ v16 }[3], [x10]
	tbz	w2, #4, LBB0_669
LBB0_685:                               ; %cond.store5502
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d17
	str	s3, [x10]
	tbz	w2, #5, LBB0_670
LBB0_686:                               ; %cond.store5506
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v17[1]
	st1.s	{ v3 }[1], [x10]
	tbz	w2, #6, LBB0_671
LBB0_687:                               ; %cond.store5510
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d4
	st1.s	{ v3 }[2], [x10]
	tbnz	w2, #7, LBB0_672
	b	LBB0_673
LBB0_688:                               ; %varying.coherent.false706
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
LBB0_689:                               ; %schedule.34
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q0, [sp, #960]                  ; 16-byte Folded Reload
	cbz	w1, LBB0_694
; %bb.690:                              ; %convergence.cascade748.preheader
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
LBB0_691:                               ; %convergence.cascade748
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_7 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w10, s4
	umaxv.8b	b3, v3
	fmov	w6, s3
	sub	w3, w1, #1
	tst	w10, #0xff
	csel	w4, w3, wzr, ne
	mov	w10, #1                         ; =0x1
	lsl	w5, w10, w4
	and	w10, w5, w17
	tst	w10, #0xff
	cset	w10, ne
	str	q9, [sp, #7104]
	str	q8, [sp, #7120]
	ubfiz	x3, x4, #2, #3
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #3008
	ldr	w7, [x7, x3]
	cmp	w7, #11
	cset	w7, eq
	and	w19, w10, w6
	add	x6, sp, #18, lsl #12            ; =73728
	add	x6, x6, #752
	ldrb	w10, [x6, w4, sxtw]
	and	w20, w10, #0x1
	fmov	s3, w20
	ubfx	w20, w10, #1, #1
	mov.b	v3[1], w20
	ubfx	w20, w10, #2, #1
	mov.b	v3[2], w20
	ubfx	w20, w10, #3, #1
	mov.b	v3[3], w20
	ubfx	w20, w10, #4, #1
	mov.b	v3[4], w20
	ubfx	w20, w10, #5, #1
	mov.b	v3[5], w20
	ubfx	w20, w10, #6, #1
	mov.b	v3[6], w20
	add	x20, sp, #18, lsl #12           ; =73728
	add	x20, x20, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x20, w4, sxtw]
	and	w21, w10, #0x1
	fmov	s4, w21
	ubfx	w21, w10, #1, #1
	mov.b	v4[1], w21
	ubfx	w21, w10, #2, #1
	mov.b	v4[2], w21
	ubfx	w21, w10, #3, #1
	mov.b	v4[3], w21
	ubfx	w21, w10, #4, #1
	mov.b	v4[4], w21
	ubfx	w21, w10, #5, #1
	mov.b	v4[5], w21
	ubfx	w21, w10, #6, #1
	mov.b	v4[6], w21
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	orr.8b	v5, v10, v4
	and.8b	v16, v1, v3
	eor.8b	v16, v16, v5
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	umaxv.8b	b16, v16
	fmov	w10, s16
	ands	w7, w19, w7
	csetm	w19, ne
	bics	w10, w7, w10
	csetm	w21, ne
	dup.8b	v16, w21
	bic.8b	v17, v5, v16
	dup.8b	v18, w19
	bit.8b	v4, v17, v18
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x20, w4, sxtw]
	bic.8b	v3, v3, v16
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x6, w4, sxtw]
	mov	w4, #-1                         ; =0xffffffff
	csinv	w4, w4, w5, eq
	and	w17, w4, w17
	dup.8b	v3, w7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v4, w10
	and.8b	v4, v4, v5
	str	q7, [sp, #7072]
	str	q6, [sp, #7088]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #2976
	ldr	w10, [x10, x3]
	csel	w1, w10, w1, ne
	bit.8b	v10, v4, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	cmp	w7, #1
	b.ne	LBB0_695
; %bb.692:                              ; %convergence.cascade748
                                        ;   in Loop: Header=BB0_691 Depth=4
	cmp	w1, #0
	ccmp	w2, #6, #2, ne
	b.hi	LBB0_695
; %bb.693:                              ; %convergence.cascade748
                                        ;   in Loop: Header=BB0_691 Depth=4
	add	w2, w2, #1
	tst	w3, #0xff
	b.ne	LBB0_691
	b	LBB0_695
LBB0_694:                               ; %schedule.34.convergence.cascade.exit749_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
LBB0_695:                               ; %convergence.cascade.exit749
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
; %bb.696:                              ; %convergence.target.34.ready
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q17, [sp, #16608]
	ldr	q4, [sp, #16624]
	ldr	q3, [sp, #16576]
	ldr	q5, [sp, #16592]
	ldr	q16, [sp, #16544]
	ldr	q19, [sp, #16560]
	ldr	q22, [sp, #16512]
	ldr	q23, [sp, #16528]
	mov	b18, v10[2]
	mov.b	v18[4], v10[3]
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	ldr	q28, [sp, #224]                 ; 16-byte Folded Reload
	bit.16b	v23, v28, v18
	mov	b24, v10[0]
	mov.b	v24[4], v10[1]
	ushll.2d	v24, v24, #0
	shl.2d	v24, v24, #63
	cmlt.2d	v24, v24, #0
	mov	b25, v10[6]
	mov.b	v25[4], v10[7]
	bit.16b	v22, v28, v24
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	bit.16b	v19, v28, v25
	mov	b26, v10[4]
	mov.b	v26[4], v10[5]
	ushll.2d	v26, v26, #0
	shl.2d	v26, v26, #63
	cmlt.2d	v26, v26, #0
Lloh1122:
	adrp	x10, lCPI0_17@PAGE
Lloh1123:
	ldr	q27, [x10, lCPI0_17@PAGEOFF]
	bit.16b	v5, v27, v18
Lloh1124:
	adrp	x10, lCPI0_18@PAGE
Lloh1125:
	ldr	q27, [x10, lCPI0_18@PAGEOFF]
	bit.16b	v17, v27, v26
Lloh1126:
	adrp	x10, lCPI0_16@PAGE
Lloh1127:
	ldr	q27, [x10, lCPI0_16@PAGEOFF]
	str	q17, [sp, #16608]
Lloh1128:
	adrp	x10, lCPI0_19@PAGE
Lloh1129:
	ldr	q17, [x10, lCPI0_19@PAGEOFF]
	bit.16b	v16, v28, v26
	bit.16b	v4, v17, v25
	str	q4, [sp, #16624]
	bit.16b	v3, v27, v24
	str	q3, [sp, #16576]
	str	q5, [sp, #16592]
	str	q16, [sp, #16544]
	str	q19, [sp, #16560]
	str	q22, [sp, #16512]
	str	q23, [sp, #16528]
	ldr	q3, [sp, #1408]                 ; 16-byte Folded Reload
	bic.16b	v3, v3, v25
	str	q3, [sp, #1408]                 ; 16-byte Folded Spill
	bic.16b	v0, v0, v26
	str	q0, [sp, #960]                  ; 16-byte Folded Spill
	ldr	q0, [sp, #1424]                 ; 16-byte Folded Reload
	bic.16b	v0, v0, v18
	str	q0, [sp, #1424]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #1440]                 ; 16-byte Folded Reload
	bic.16b	v0, v0, v24
	str	q0, [sp, #1440]                 ; 16-byte Folded Spill
	b	LBB0_705
LBB0_697:                               ; %varying.coherent.false720
                                        ;   in Loop: Header=BB0_7 Depth=3
	zip2.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldp	q5, q0, [sp, #576]              ; 32-byte Folded Reload
	and.16b	v4, v3, v5
	zip1.8b	v3, v10, v5
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v0, v3, v0
	stp	q4, q0, [sp, #576]              ; 32-byte Folded Spill
	tbnz	w2, #0, LBB0_1008
	b	LBB0_67
LBB0_1008:                              ; %varying.coherent.false720
                                        ;   in Loop: Header=BB0_6 Depth=2
	b	LBB0_5
LBB0_698:                               ; %cond.load5437
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d19
	ldr	s16, [x10]
	tbz	w2, #1, LBB0_654
LBB0_699:                               ; %cond.load5443
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v19[1]
	ld1.s	{ v16 }[1], [x10]
	tbz	w2, #2, LBB0_655
LBB0_700:                               ; %cond.load5449
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d4
	ld1.s	{ v16 }[2], [x10]
	tbz	w2, #3, LBB0_656
LBB0_701:                               ; %cond.load5455
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v4[1]
	ld1.s	{ v16 }[3], [x10]
	tbz	w2, #4, LBB0_657
LBB0_702:                               ; %cond.load5461
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d18
	ld1.s	{ v3 }[0], [x10]
	tbz	w2, #5, LBB0_658
LBB0_703:                               ; %cond.load5467
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v18[1]
	ld1.s	{ v3 }[1], [x10]
	tbz	w2, #6, LBB0_659
LBB0_704:                               ; %cond.load5473
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d17
	ld1.s	{ v3 }[2], [x10]
	tbnz	w2, #7, LBB0_660
	b	LBB0_661
LBB0_705:                               ; %schedule.35
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	mov	w2, #128                        ; =0x80
	dup.2d	v3, x2
	ldr	q17, [sp, #1424]                ; 16-byte Folded Reload
	cmgt.2d	v4, v3, v17
	ldr	q0, [sp, #1440]                 ; 16-byte Folded Reload
	cmgt.2d	v5, v3, v0
	uzp1.4s	v4, v5, v4
	ldr	q18, [sp, #960]                 ; 16-byte Folded Reload
	cmgt.2d	v5, v3, v18
	ldr	q19, [sp, #1408]                ; 16-byte Folded Reload
	cmgt.2d	v16, v3, v19
	uzp1.4s	v5, v5, v16
	uzp1.8h	v4, v4, v5
	xtn.8b	v4, v4
	and.8b	v11, v10, v4
	shl.8b	v4, v11, #7
	cmlt.8b	v4, v4, #0
	and.8b	v5, v4, v2
	addv.8b	b5, v5
	fmov	w2, s5
	umaxv.8b	b4, v4
	fmov	w4, s4
	tbz	w4, #0, LBB0_711
; %bb.706:                              ; %schedule.35
                                        ;   in Loop: Header=BB0_7 Depth=3
	cmge.2d	v4, v17, v3
	cmge.2d	v5, v0, v3
	uzp1.4s	v4, v5, v4
	cmge.2d	v5, v18, v3
	cmge.2d	v3, v19, v3
	uzp1.4s	v3, v5, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v12, v10, v3
	shl.8b	v3, v12, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w4, s3
	tst	w4, #0xff
	b.eq	LBB0_711
; %bb.707:                              ; %varying.divergent766
                                        ;   in Loop: Header=BB0_7 Depth=3
	subs	w10, w1, #1
	csel	w10, wzr, w10, lo
	and	w3, w17, #0xff
	lsr	w2, w3, w10
	tst	w2, #0x1
	str	q9, [sp, #3968]
	str	q8, [sp, #3984]
	and	x10, x10, #0x7
	add	x2, sp, #3968
	ldr	w10, [x2, x10, lsl #2]
	ccmp	w1, #0, #4, ne
	ccmp	w10, #13, #0, ne
	cset	w2, ne
	cmp	w3, #255
	b.ne	LBB0_709
; %bb.708:                              ; %varying.divergent766
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #0, LBB0_1006
LBB0_709:                               ; %convergence.overflow.resume769
                                        ;   in Loop: Header=BB0_7 Depth=3
	mvn	w10, w17
	rbit	w10, w10
	clz	w10, w10
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w17
	csel	w4, wzr, w10, eq
	add	x3, sp, #18, lsl #12            ; =73728
	add	x3, x3, #752
	ldrb	w10, [x3, w4, uxtw]
	and	w5, w10, #0x1
	fmov	s3, w5
	ubfx	w5, w10, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w10, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w10, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w10, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w10, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w10, #6, #1
	mov.b	v3[6], w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x5, w4, uxtw]
	and	w6, w10, #0x1
	fmov	s4, w6
	ubfx	w6, w10, #1, #1
	mov.b	v4[1], w6
	ubfx	w6, w10, #2, #1
	mov.b	v4[2], w6
	ubfx	w6, w10, #3, #1
	mov.b	v4[3], w6
	ubfx	w6, w10, #4, #1
	mov.b	v4[4], w6
	ubfx	w6, w10, #5, #1
	mov.b	v4[5], w6
	ubfx	w6, w10, #6, #1
	mov.b	v4[6], w6
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	cmp	w2, #0
	csetm	w10, ne
	dup.8b	v5, w10
	bit.8b	v3, v10, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x3, w4, uxtw]
	bic.8b	v3, v4, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w4, uxtw]
	cmp	x0, #8
	b.hs	LBB0_1006
; %bb.710:                              ; %ready.overflow.resume771
                                        ;   in Loop: Header=BB0_7 Depth=3
	str	q7, [sp, #3936]
	str	q6, [sp, #3952]
	ubfiz	x10, x4, #2, #3
	add	x3, sp, #3936
	ldr	w3, [x3, x10]
	cmp	w2, #0
	csel	w3, w1, w3, ne
	csinc	w1, w1, w4, eq
	str	q7, [sp, #3904]
	str	q6, [sp, #3920]
	add	x5, sp, #3904
	str	w3, [x5, x10]
	ldr	q6, [sp, #3920]
	ldr	q7, [sp, #3904]
	str	q9, [sp, #3872]
	str	q8, [sp, #3888]
	add	x3, sp, #3872
	ldr	w3, [x3, x10]
	mov	w5, #13                         ; =0xd
	csel	w3, w5, w3, ne
	str	q9, [sp, #3840]
	str	q8, [sp, #3856]
	add	x5, sp, #3840
	str	w3, [x5, x10]
	mov	w3, #37                         ; =0x25
	mov	w5, #36                         ; =0x24
	ldr	q8, [sp, #3856]
	ldr	q9, [sp, #3840]
	b	LBB0_938
LBB0_711:                               ; %varying.coherent767
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_762
; %bb.712:                              ; %varying.coherent.true772
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
	tst	w3, #0xff
	b.eq	LBB0_5
LBB0_713:                               ; %schedule.36
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	b3, v10[0]
	mov.b	v3[4], v10[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v4, v3, #0
	ldr	q0, [sp, #1440]                 ; 16-byte Folded Reload
	and.16b	v17, v4, v0
	mov	b3, v10[2]
	mov.b	v3[4], v10[3]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v5, v3, #0
	ldr	q0, [sp, #1424]                 ; 16-byte Folded Reload
	and.16b	v18, v5, v0
	mov	b3, v10[4]
	mov.b	v3[4], v10[5]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v24, v3, #0
	ldr	q0, [sp, #960]                  ; 16-byte Folded Reload
	and.16b	v19, v24, v0
	mov	b3, v10[6]
	mov.b	v3[4], v10[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v25, v3, #0
	ldr	q0, [sp, #1408]                 ; 16-byte Folded Reload
	and.16b	v3, v25, v0
	shl.8b	v16, v10, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v2
	mov	w3, #32                         ; =0x20
	dup.2d	v27, x3
	and.16b	v26, v4, v27
	mvn.16b	v4, v4
	sub.2d	v26, v26, v4
	and.16b	v4, v5, v27
	mvn.16b	v5, v5
	sub.2d	v4, v4, v5
	and.16b	v5, v24, v27
	mvn.16b	v24, v24
	and.16b	v27, v25, v27
	mvn.16b	v25, v25
	sub.2d	v25, v27, v25
	mov.d	x3, v25[1]
	mov.d	x4, v3[1]
	sdiv	x4, x4, x3
	sub.2d	v5, v5, v24
	fmov	x5, d25
	fmov	x6, d3
	sdiv	x6, x6, x5
	mul	x5, x6, x5
	fmov	d24, x6
	mov.d	v24[1], x4
	mov.d	x6, v5[1]
	mov.d	x7, v19[1]
	sdiv	x7, x7, x6
	fmov	x19, d5
	fmov	x20, d19
	sdiv	x20, x20, x19
	mul	x19, x20, x19
	fmov	d5, x20
	mov.d	v5[1], x7
	mov.d	x20, v4[1]
	mov.d	x21, v18[1]
	sdiv	x21, x21, x20
	fmov	x22, d4
	fmov	x23, d18
	sdiv	x23, x23, x22
	mul	x22, x23, x22
	fmov	d4, x23
	mov.d	v4[1], x21
	mov.d	x23, v26[1]
	mov.d	x24, v17[1]
	fmov	x25, d26
	fmov	x26, d17
	sdiv	x26, x26, x25
	mul	x25, x26, x25
	fmov	d25, x26
	sdiv	x24, x24, x23
	mov.d	v25[1], x24
	mul	x23, x24, x23
	fmov	d26, x25
	mov.d	v26[1], x23
	mul	x20, x21, x20
	fmov	d27, x22
	mov.d	v27[1], x20
	mul	x6, x7, x6
	fmov	d28, x19
	mov.d	v28[1], x6
	mul	x3, x4, x3
	fmov	d29, x5
	mov.d	v29[1], x3
	addv.8b	b16, v16
	sub.2d	v3, v3, v29
	sub.2d	v19, v19, v28
	fmov	w3, s16
	sub.2d	v18, v18, v27
	sub.2d	v17, v17, v26
	ldr	q28, [sp, #17024]
	ldr	q29, [sp, #17040]
	ldr	q30, [sp, #17056]
	ldr	q31, [sp, #17072]
	ldr	q11, [sp, #17136]
	ldr	q12, [sp, #17120]
	ldr	q13, [sp, #17104]
	shl.2d	v25, v25, #10
	shl.2d	v4, v4, #10
	shl.2d	v5, v5, #10
	shl.2d	v24, v24, #10
	shl.2d	v17, v17, #5
	shl.2d	v26, v18, #5
	shl.2d	v19, v19, #5
	shl.2d	v3, v3, #5
	add.2d	v18, v24, v3
	add.2d	v19, v5, v19
	ldr	q5, [sp, #17088]
	add.2d	v26, v4, v26
	add.2d	v27, v25, v17
	add.2d	v3, v31, v11
	add.2d	v3, v3, v18
	add.2d	v4, v30, v12
	add.2d	v31, v4, v19
	add.2d	v4, v29, v13
	add.2d	v4, v4, v26
	add.2d	v5, v28, v5
	add.2d	v30, v5, v27
	movi.2d	v17, #0000000000000000
	movi.2d	v11, #0000000000000000
	tbnz	w3, #0, LBB0_741
; %bb.714:                              ; %else4704
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #1, LBB0_742
LBB0_715:                               ; %else4710
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #2, LBB0_743
LBB0_716:                               ; %else4716
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #3, LBB0_744
LBB0_717:                               ; %else4722
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #4, LBB0_745
LBB0_718:                               ; %else4728
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #5, LBB0_746
LBB0_719:                               ; %else4734
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #6, LBB0_747
LBB0_720:                               ; %else4740
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w3, #7, LBB0_722
LBB0_721:                               ; %cond.load4742
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v3[1]
	ld1.s	{ v11 }[3], [x3]
LBB0_722:                               ; %else4746
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q3, [sp, #16816]
	ldr	q5, [sp, #16800]
	ldr	q4, [sp, #16784]
	ldr	q24, [sp, #16768]
	ldr	q25, [sp, #16832]
	ldr	q28, [sp, #16848]
	ldr	q29, [sp, #16864]
	ldr	q30, [sp, #16880]
	add.2d	v24, v24, v25
	add.2d	v27, v24, v27
	add.2d	v4, v4, v28
	add.2d	v4, v4, v26
	add.2d	v5, v5, v29
	add.2d	v26, v5, v19
	add.2d	v3, v3, v30
	add.2d	v19, v3, v18
	fmov	w3, s16
	movi.2d	v3, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w3, #0, LBB0_748
; %bb.723:                              ; %else4753
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #1, LBB0_749
LBB0_724:                               ; %else4759
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #2, LBB0_750
LBB0_725:                               ; %else4765
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #3, LBB0_751
LBB0_726:                               ; %else4771
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #4, LBB0_752
LBB0_727:                               ; %else4777
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #5, LBB0_753
LBB0_728:                               ; %else4783
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #6, LBB0_754
LBB0_729:                               ; %else4789
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w3, #7, LBB0_731
LBB0_730:                               ; %cond.load4791
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v19[1]
	ld1.s	{ v18 }[3], [x3]
LBB0_731:                               ; %else4795
                                        ;   in Loop: Header=BB0_7 Depth=3
	fadd.4s	v17, v17, v3
	fadd.4s	v3, v11, v18
	ldr	q4, [sp, #16560]
	ldr	q5, [sp, #16544]
	ldr	q18, [sp, #16528]
	ldr	q19, [sp, #16512]
	ldr	q24, [sp, #16576]
	ldr	q25, [sp, #16592]
	ldr	q26, [sp, #16608]
	ldr	q27, [sp, #16624]
	ldr	q0, [sp, #1440]                 ; 16-byte Folded Reload
	shl.2d	v28, v0, #5
	ldr	q0, [sp, #1424]                 ; 16-byte Folded Reload
	shl.2d	v29, v0, #5
	ldr	q0, [sp, #960]                  ; 16-byte Folded Reload
	shl.2d	v30, v0, #5
	ldr	q0, [sp, #1408]                 ; 16-byte Folded Reload
	shl.2d	v31, v0, #5
	add.2d	v27, v27, v31
	add.2d	v30, v26, v30
	add.2d	v25, v25, v29
	add.2d	v24, v24, v28
	add.2d	v26, v19, v24
	add.2d	v19, v18, v25
	add.2d	v18, v5, v30
	add.2d	v4, v4, v27
	fmov	w3, s16
	tbnz	w3, #0, LBB0_755
; %bb.732:                              ; %else4801
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #1, LBB0_756
LBB0_733:                               ; %else4805
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q0, [sp, #1440]                 ; 16-byte Folded Reload
	ldr	q5, [sp, #1424]                 ; 16-byte Folded Reload
	ldr	q16, [sp, #1408]                ; 16-byte Folded Reload
	tbnz	w3, #2, LBB0_757
LBB0_734:                               ; %else4809
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #3, LBB0_758
LBB0_735:                               ; %else4813
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #4, LBB0_759
LBB0_736:                               ; %else4817
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #5, LBB0_760
LBB0_737:                               ; %else4821
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #6, LBB0_761
LBB0_738:                               ; %else4825
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w3, #7, LBB0_740
LBB0_739:                               ; %cond.store4826
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v4[1]
	st1.s	{ v3 }[3], [x3]
LBB0_740:                               ; %else4829
                                        ;   in Loop: Header=BB0_7 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v10, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v4, v3, #0
	ushll2.4s	v3, v3, #0
	uaddw2.2d	v16, v16, v3
	str	q16, [sp, #1408]                ; 16-byte Folded Spill
	ldr	q16, [sp, #960]                 ; 16-byte Folded Reload
	uaddw.2d	v16, v16, v3
	str	q16, [sp, #960]                 ; 16-byte Folded Spill
	uaddw2.2d	v5, v5, v4
	str	q5, [sp, #1424]                 ; 16-byte Folded Spill
	uaddw.2d	v0, v0, v4
	str	q0, [sp, #1440]                 ; 16-byte Folded Spill
	tbz	w2, #0, LBB0_705
	b	LBB0_5
LBB0_741:                               ; %cond.load4700
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d30
	ldr	s17, [x4]
	tbz	w3, #1, LBB0_715
LBB0_742:                               ; %cond.load4706
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v30[1]
	ld1.s	{ v17 }[1], [x4]
	tbz	w3, #2, LBB0_716
LBB0_743:                               ; %cond.load4712
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d4
	ld1.s	{ v17 }[2], [x4]
	tbz	w3, #3, LBB0_717
LBB0_744:                               ; %cond.load4718
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v4[1]
	ld1.s	{ v17 }[3], [x4]
	tbz	w3, #4, LBB0_718
LBB0_745:                               ; %cond.load4724
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d31
	ld1.s	{ v11 }[0], [x4]
	tbz	w3, #5, LBB0_719
LBB0_746:                               ; %cond.load4730
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v31[1]
	ld1.s	{ v11 }[1], [x4]
	tbz	w3, #6, LBB0_720
LBB0_747:                               ; %cond.load4736
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d3
	ld1.s	{ v11 }[2], [x4]
	tbnz	w3, #7, LBB0_721
	b	LBB0_722
LBB0_748:                               ; %cond.load4749
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d27
	ldr	s3, [x4]
	tbz	w3, #1, LBB0_724
LBB0_749:                               ; %cond.load4755
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v27[1]
	ld1.s	{ v3 }[1], [x4]
	tbz	w3, #2, LBB0_725
LBB0_750:                               ; %cond.load4761
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d4
	ld1.s	{ v3 }[2], [x4]
	tbz	w3, #3, LBB0_726
LBB0_751:                               ; %cond.load4767
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v4[1]
	ld1.s	{ v3 }[3], [x4]
	tbz	w3, #4, LBB0_727
LBB0_752:                               ; %cond.load4773
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d26
	ld1.s	{ v18 }[0], [x4]
	tbz	w3, #5, LBB0_728
LBB0_753:                               ; %cond.load4779
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v26[1]
	ld1.s	{ v18 }[1], [x4]
	tbz	w3, #6, LBB0_729
LBB0_754:                               ; %cond.load4785
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d19
	ld1.s	{ v18 }[2], [x4]
	tbnz	w3, #7, LBB0_730
	b	LBB0_731
LBB0_755:                               ; %cond.store4798
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d26
	str	s17, [x4]
	tbz	w3, #1, LBB0_733
LBB0_756:                               ; %cond.store4802
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v26[1]
	st1.s	{ v17 }[1], [x4]
	ldr	q0, [sp, #1440]                 ; 16-byte Folded Reload
	ldr	q5, [sp, #1424]                 ; 16-byte Folded Reload
	ldr	q16, [sp, #1408]                ; 16-byte Folded Reload
	tbz	w3, #2, LBB0_734
LBB0_757:                               ; %cond.store4806
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d19
	st1.s	{ v17 }[2], [x4]
	tbz	w3, #3, LBB0_735
LBB0_758:                               ; %cond.store4810
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v19[1]
	st1.s	{ v17 }[3], [x4]
	tbz	w3, #4, LBB0_736
LBB0_759:                               ; %cond.store4814
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d18
	str	s3, [x4]
	tbz	w3, #5, LBB0_737
LBB0_760:                               ; %cond.store4818
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v18[1]
	st1.s	{ v3 }[1], [x4]
	tbz	w3, #6, LBB0_738
LBB0_761:                               ; %cond.store4822
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d4
	st1.s	{ v3 }[2], [x4]
	tbnz	w3, #7, LBB0_739
	b	LBB0_740
LBB0_762:                               ; %varying.coherent.false773
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
LBB0_763:                               ; %schedule.37
                                        ;   in Loop: Header=BB0_7 Depth=3
	cbz	w1, LBB0_768
; %bb.764:                              ; %convergence.cascade781.preheader
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
LBB0_765:                               ; %convergence.cascade781
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_7 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w10, s4
	umaxv.8b	b3, v3
	fmov	w6, s3
	sub	w3, w1, #1
	tst	w10, #0xff
	csel	w4, w3, wzr, ne
	mov	w10, #1                         ; =0x1
	lsl	w5, w10, w4
	and	w10, w5, w17
	tst	w10, #0xff
	cset	w10, ne
	str	q9, [sp, #7040]
	str	q8, [sp, #7056]
	ubfiz	x3, x4, #2, #3
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #2944
	ldr	w7, [x7, x3]
	cmp	w7, #13
	cset	w7, eq
	and	w19, w10, w6
	add	x6, sp, #18, lsl #12            ; =73728
	add	x6, x6, #752
	ldrb	w10, [x6, w4, sxtw]
	and	w20, w10, #0x1
	fmov	s3, w20
	ubfx	w20, w10, #1, #1
	mov.b	v3[1], w20
	ubfx	w20, w10, #2, #1
	mov.b	v3[2], w20
	ubfx	w20, w10, #3, #1
	mov.b	v3[3], w20
	ubfx	w20, w10, #4, #1
	mov.b	v3[4], w20
	ubfx	w20, w10, #5, #1
	mov.b	v3[5], w20
	ubfx	w20, w10, #6, #1
	mov.b	v3[6], w20
	add	x20, sp, #18, lsl #12           ; =73728
	add	x20, x20, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x20, w4, sxtw]
	and	w21, w10, #0x1
	fmov	s4, w21
	ubfx	w21, w10, #1, #1
	mov.b	v4[1], w21
	ubfx	w21, w10, #2, #1
	mov.b	v4[2], w21
	ubfx	w21, w10, #3, #1
	mov.b	v4[3], w21
	ubfx	w21, w10, #4, #1
	mov.b	v4[4], w21
	ubfx	w21, w10, #5, #1
	mov.b	v4[5], w21
	ubfx	w21, w10, #6, #1
	mov.b	v4[6], w21
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	orr.8b	v5, v10, v4
	and.8b	v16, v1, v3
	eor.8b	v16, v16, v5
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	umaxv.8b	b16, v16
	fmov	w10, s16
	ands	w7, w19, w7
	csetm	w19, ne
	bics	w10, w7, w10
	csetm	w21, ne
	dup.8b	v16, w21
	bic.8b	v17, v5, v16
	dup.8b	v18, w19
	bit.8b	v4, v17, v18
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x20, w4, sxtw]
	bic.8b	v3, v3, v16
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x6, w4, sxtw]
	mov	w4, #-1                         ; =0xffffffff
	csinv	w4, w4, w5, eq
	and	w17, w4, w17
	dup.8b	v3, w7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v4, w10
	and.8b	v4, v4, v5
	str	q7, [sp, #7008]
	str	q6, [sp, #7024]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #2912
	ldr	w10, [x10, x3]
	csel	w1, w10, w1, ne
	bit.8b	v10, v4, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	cmp	w7, #1
	b.ne	LBB0_769
; %bb.766:                              ; %convergence.cascade781
                                        ;   in Loop: Header=BB0_765 Depth=4
	cmp	w1, #0
	ccmp	w2, #6, #2, ne
	b.hi	LBB0_769
; %bb.767:                              ; %convergence.cascade781
                                        ;   in Loop: Header=BB0_765 Depth=4
	add	w2, w2, #1
	tst	w3, #0xff
	b.ne	LBB0_765
	b	LBB0_769
LBB0_768:                               ; %schedule.37.convergence.cascade.exit782_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
LBB0_769:                               ; %convergence.cascade.exit782
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
; %bb.770:                              ; %convergence.target.37.ready
                                        ;   in Loop: Header=BB0_7 Depth=3
	rbit	w10, w3
	clz	w2, w10
	ldr	q3, [sp, #16480]
	ldr	q4, [sp, #16496]
	ldr	q5, [sp, #16448]
	ldr	q16, [sp, #16464]
	ldr	q17, [sp, #16416]
	ldr	q18, [sp, #16432]
	ldr	q19, [sp, #16384]
	ldr	q22, [sp, #16400]
	mov	b23, v10[2]
	mov.b	v23[4], v10[3]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v11, v23, #0
	ldr	q24, [sp, #208]                 ; 16-byte Folded Reload
	bit.16b	v22, v24, v11
	mov	b23, v10[0]
	mov.b	v23[4], v10[1]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v12, v23, #0
	bit.16b	v19, v24, v12
	mov	b23, v10[6]
	mov.b	v23[4], v10[7]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v13, v23, #0
	mov	b23, v10[4]
	mov.b	v23[4], v10[5]
	bit.16b	v18, v24, v13
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v14, v23, #0
	bit.16b	v17, v24, v14
Lloh1130:
	adrp	x10, lCPI0_20@PAGE
Lloh1131:
	ldr	q23, [x10, lCPI0_20@PAGEOFF]
	bit.16b	v16, v23, v11
Lloh1132:
	adrp	x10, lCPI0_21@PAGE
Lloh1133:
	ldr	q24, [x10, lCPI0_21@PAGEOFF]
	bit.16b	v5, v24, v12
Lloh1134:
	adrp	x10, lCPI0_22@PAGE
Lloh1135:
	ldr	q25, [x10, lCPI0_22@PAGEOFF]
	bit.16b	v4, v25, v13
Lloh1136:
	adrp	x10, lCPI0_23@PAGE
Lloh1137:
	ldr	q26, [x10, lCPI0_23@PAGEOFF]
	bit.16b	v3, v26, v14
	str	q3, [sp, #16480]
	str	q4, [sp, #16496]
	str	q5, [sp, #16448]
	str	q16, [sp, #16464]
	str	q17, [sp, #16416]
	str	q18, [sp, #16432]
	str	q19, [sp, #16384]
	str	q22, [sp, #16400]
	str	q25, [sp, #5008]
	str	q26, [sp, #4992]
	str	q23, [sp, #4976]
	str	q24, [sp, #4960]
	lsl	w10, w2, #3
	and	x2, x10, #0x38
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #864
	ldr	x5, [x3, x2]
	and	x3, x10, #0xf8
	add	x4, sp, #6, lsl #12             ; =24576
	add	x4, x4, #2664
	sub	x10, x5, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10, #32]
	ldp	q5, q16, [x10]
	mov	x5, #-16                        ; =0xfffffffffffffff0
	dup.2d	v17, x5
	bit.16b	v16, v17, v11
	bit.16b	v5, v17, v12
	bit.16b	v4, v17, v13
	bit.16b	v3, v17, v14
	stp	q3, q4, [x10, #32]
	stp	q5, q16, [x10]
Lloh1138:
	adrp	x10, lCPI0_24@PAGE
Lloh1139:
	ldr	q3, [x10, lCPI0_24@PAGEOFF]
Lloh1140:
	adrp	x10, lCPI0_25@PAGE
Lloh1141:
	ldr	q4, [x10, lCPI0_25@PAGEOFF]
	str	q3, [sp, #5072]
	str	q4, [sp, #5056]
Lloh1142:
	adrp	x10, lCPI0_26@PAGE
Lloh1143:
	ldr	q3, [x10, lCPI0_26@PAGEOFF]
Lloh1144:
	adrp	x10, lCPI0_27@PAGE
Lloh1145:
	ldr	q4, [x10, lCPI0_27@PAGEOFF]
	str	q3, [sp, #5040]
	str	q4, [sp, #5024]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #928
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	x5, #-15                        ; =0xfffffffffffffff1
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1146:
	adrp	x10, lCPI0_28@PAGE
Lloh1147:
	ldr	q3, [x10, lCPI0_28@PAGEOFF]
Lloh1148:
	adrp	x10, lCPI0_29@PAGE
Lloh1149:
	ldr	q4, [x10, lCPI0_29@PAGEOFF]
	str	q3, [sp, #5136]
	str	q4, [sp, #5120]
Lloh1150:
	adrp	x10, lCPI0_30@PAGE
Lloh1151:
	ldr	q3, [x10, lCPI0_30@PAGEOFF]
Lloh1152:
	adrp	x10, lCPI0_31@PAGE
Lloh1153:
	ldr	q4, [x10, lCPI0_31@PAGEOFF]
	str	q3, [sp, #5104]
	str	q4, [sp, #5088]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #992
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	x5, #-14                        ; =0xfffffffffffffff2
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh1154:
	adrp	x10, lCPI0_32@PAGE
Lloh1155:
	ldr	q3, [x10, lCPI0_32@PAGEOFF]
Lloh1156:
	adrp	x10, lCPI0_33@PAGE
Lloh1157:
	ldr	q4, [x10, lCPI0_33@PAGEOFF]
	str	q3, [sp, #5200]
	str	q4, [sp, #5184]
Lloh1158:
	adrp	x10, lCPI0_34@PAGE
Lloh1159:
	ldr	q3, [x10, lCPI0_34@PAGEOFF]
Lloh1160:
	adrp	x10, lCPI0_35@PAGE
Lloh1161:
	ldr	q4, [x10, lCPI0_35@PAGEOFF]
	str	q3, [sp, #5168]
	str	q4, [sp, #5152]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #1056
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	x5, #-13                        ; =0xfffffffffffffff3
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1162:
	adrp	x10, lCPI0_36@PAGE
Lloh1163:
	ldr	q3, [x10, lCPI0_36@PAGEOFF]
Lloh1164:
	adrp	x10, lCPI0_37@PAGE
Lloh1165:
	ldr	q4, [x10, lCPI0_37@PAGEOFF]
	str	q3, [sp, #5264]
	str	q4, [sp, #5248]
Lloh1166:
	adrp	x10, lCPI0_38@PAGE
Lloh1167:
	ldr	q3, [x10, lCPI0_38@PAGEOFF]
Lloh1168:
	adrp	x10, lCPI0_39@PAGE
Lloh1169:
	ldr	q4, [x10, lCPI0_39@PAGEOFF]
	str	q3, [sp, #5232]
	str	q4, [sp, #5216]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #1120
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	x5, #-12                        ; =0xfffffffffffffff4
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1170:
	adrp	x10, lCPI0_40@PAGE
Lloh1171:
	ldr	q3, [x10, lCPI0_40@PAGEOFF]
Lloh1172:
	adrp	x10, lCPI0_41@PAGE
Lloh1173:
	ldr	q4, [x10, lCPI0_41@PAGEOFF]
	str	q3, [sp, #5328]
	str	q4, [sp, #5312]
Lloh1174:
	adrp	x10, lCPI0_42@PAGE
Lloh1175:
	ldr	q3, [x10, lCPI0_42@PAGEOFF]
Lloh1176:
	adrp	x10, lCPI0_43@PAGE
Lloh1177:
	ldr	q4, [x10, lCPI0_43@PAGEOFF]
	str	q3, [sp, #5296]
	str	q4, [sp, #5280]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #1184
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	x5, #-11                        ; =0xfffffffffffffff5
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh1178:
	adrp	x10, lCPI0_44@PAGE
Lloh1179:
	ldr	q3, [x10, lCPI0_44@PAGEOFF]
Lloh1180:
	adrp	x10, lCPI0_45@PAGE
Lloh1181:
	ldr	q4, [x10, lCPI0_45@PAGEOFF]
	str	q3, [sp, #5392]
	str	q4, [sp, #5376]
Lloh1182:
	adrp	x10, lCPI0_46@PAGE
Lloh1183:
	ldr	q3, [x10, lCPI0_46@PAGEOFF]
Lloh1184:
	adrp	x10, lCPI0_47@PAGE
Lloh1185:
	ldr	q4, [x10, lCPI0_47@PAGEOFF]
	str	q3, [sp, #5360]
	str	q4, [sp, #5344]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #1248
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	x5, #-10                        ; =0xfffffffffffffff6
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1186:
	adrp	x10, lCPI0_48@PAGE
Lloh1187:
	ldr	q3, [x10, lCPI0_48@PAGEOFF]
Lloh1188:
	adrp	x10, lCPI0_49@PAGE
Lloh1189:
	ldr	q4, [x10, lCPI0_49@PAGEOFF]
	str	q3, [sp, #5456]
	str	q4, [sp, #5440]
Lloh1190:
	adrp	x10, lCPI0_50@PAGE
Lloh1191:
	ldr	q3, [x10, lCPI0_50@PAGEOFF]
Lloh1192:
	adrp	x10, lCPI0_51@PAGE
Lloh1193:
	ldr	q4, [x10, lCPI0_51@PAGEOFF]
	str	q3, [sp, #5424]
	str	q4, [sp, #5408]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #1312
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	x5, #-9                         ; =0xfffffffffffffff7
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1194:
	adrp	x10, lCPI0_52@PAGE
Lloh1195:
	ldr	q3, [x10, lCPI0_52@PAGEOFF]
Lloh1196:
	adrp	x10, lCPI0_53@PAGE
Lloh1197:
	ldr	q4, [x10, lCPI0_53@PAGEOFF]
	str	q3, [sp, #5520]
	str	q4, [sp, #5504]
Lloh1198:
	adrp	x10, lCPI0_54@PAGE
Lloh1199:
	ldr	q3, [x10, lCPI0_54@PAGEOFF]
Lloh1200:
	adrp	x10, lCPI0_55@PAGE
Lloh1201:
	ldr	q4, [x10, lCPI0_55@PAGEOFF]
	str	q3, [sp, #5488]
	str	q4, [sp, #5472]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #1376
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	x5, #-8                         ; =0xfffffffffffffff8
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh1202:
	adrp	x10, lCPI0_56@PAGE
Lloh1203:
	ldr	q3, [x10, lCPI0_56@PAGEOFF]
Lloh1204:
	adrp	x10, lCPI0_57@PAGE
Lloh1205:
	ldr	q4, [x10, lCPI0_57@PAGEOFF]
	str	q3, [sp, #5584]
	str	q4, [sp, #5568]
Lloh1206:
	adrp	x10, lCPI0_58@PAGE
Lloh1207:
	ldr	q3, [x10, lCPI0_58@PAGEOFF]
Lloh1208:
	adrp	x10, lCPI0_59@PAGE
Lloh1209:
	ldr	q4, [x10, lCPI0_59@PAGEOFF]
	str	q3, [sp, #5552]
	str	q4, [sp, #5536]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #1440
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	x5, #-7                         ; =0xfffffffffffffff9
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1210:
	adrp	x10, lCPI0_60@PAGE
Lloh1211:
	ldr	q3, [x10, lCPI0_60@PAGEOFF]
Lloh1212:
	adrp	x10, lCPI0_61@PAGE
Lloh1213:
	ldr	q4, [x10, lCPI0_61@PAGEOFF]
	str	q3, [sp, #5648]
	str	q4, [sp, #5632]
Lloh1214:
	adrp	x10, lCPI0_62@PAGE
Lloh1215:
	ldr	q3, [x10, lCPI0_62@PAGEOFF]
Lloh1216:
	adrp	x10, lCPI0_63@PAGE
Lloh1217:
	ldr	q4, [x10, lCPI0_63@PAGEOFF]
	str	q3, [sp, #5616]
	str	q4, [sp, #5600]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #1504
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	x5, #-6                         ; =0xfffffffffffffffa
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1218:
	adrp	x10, lCPI0_64@PAGE
Lloh1219:
	ldr	q3, [x10, lCPI0_64@PAGEOFF]
Lloh1220:
	adrp	x10, lCPI0_65@PAGE
Lloh1221:
	ldr	q4, [x10, lCPI0_65@PAGEOFF]
	str	q3, [sp, #5712]
	str	q4, [sp, #5696]
Lloh1222:
	adrp	x10, lCPI0_66@PAGE
Lloh1223:
	ldr	q3, [x10, lCPI0_66@PAGEOFF]
Lloh1224:
	adrp	x10, lCPI0_67@PAGE
Lloh1225:
	ldr	q4, [x10, lCPI0_67@PAGEOFF]
	str	q3, [sp, #5680]
	str	q4, [sp, #5664]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #1568
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	x5, #-5                         ; =0xfffffffffffffffb
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh1226:
	adrp	x10, lCPI0_68@PAGE
Lloh1227:
	ldr	q3, [x10, lCPI0_68@PAGEOFF]
Lloh1228:
	adrp	x10, lCPI0_69@PAGE
Lloh1229:
	ldr	q4, [x10, lCPI0_69@PAGEOFF]
	str	q3, [sp, #5776]
	str	q4, [sp, #5760]
Lloh1230:
	adrp	x10, lCPI0_70@PAGE
Lloh1231:
	ldr	q3, [x10, lCPI0_70@PAGEOFF]
Lloh1232:
	adrp	x10, lCPI0_71@PAGE
Lloh1233:
	ldr	q4, [x10, lCPI0_71@PAGEOFF]
	str	q3, [sp, #5744]
	str	q4, [sp, #5728]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #1632
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	x5, #-4                         ; =0xfffffffffffffffc
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1234:
	adrp	x10, lCPI0_72@PAGE
Lloh1235:
	ldr	q3, [x10, lCPI0_72@PAGEOFF]
Lloh1236:
	adrp	x10, lCPI0_73@PAGE
Lloh1237:
	ldr	q4, [x10, lCPI0_73@PAGEOFF]
	str	q3, [sp, #5840]
	str	q4, [sp, #5824]
Lloh1238:
	adrp	x10, lCPI0_74@PAGE
Lloh1239:
	ldr	q3, [x10, lCPI0_74@PAGEOFF]
Lloh1240:
	adrp	x10, lCPI0_75@PAGE
Lloh1241:
	ldr	q4, [x10, lCPI0_75@PAGEOFF]
	str	q3, [sp, #5808]
	str	q4, [sp, #5792]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #1696
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	x5, #-3                         ; =0xfffffffffffffffd
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1242:
	adrp	x10, lCPI0_76@PAGE
Lloh1243:
	ldr	q3, [x10, lCPI0_76@PAGEOFF]
Lloh1244:
	adrp	x10, lCPI0_77@PAGE
Lloh1245:
	ldr	q4, [x10, lCPI0_77@PAGEOFF]
	str	q3, [sp, #5904]
	str	q4, [sp, #5888]
Lloh1246:
	adrp	x10, lCPI0_78@PAGE
Lloh1247:
	ldr	q3, [x10, lCPI0_78@PAGEOFF]
Lloh1248:
	adrp	x10, lCPI0_79@PAGE
Lloh1249:
	ldr	q4, [x10, lCPI0_79@PAGEOFF]
	str	q3, [sp, #5872]
	str	q4, [sp, #5856]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #1760
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	x5, #-2                         ; =0xfffffffffffffffe
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh1250:
	adrp	x10, lCPI0_80@PAGE
Lloh1251:
	ldr	q3, [x10, lCPI0_80@PAGEOFF]
Lloh1252:
	adrp	x10, lCPI0_81@PAGE
Lloh1253:
	ldr	q4, [x10, lCPI0_81@PAGEOFF]
	str	q3, [sp, #5968]
	str	q4, [sp, #5952]
Lloh1254:
	adrp	x10, lCPI0_82@PAGE
Lloh1255:
	ldr	q3, [x10, lCPI0_82@PAGEOFF]
Lloh1256:
	adrp	x10, lCPI0_83@PAGE
Lloh1257:
	ldr	q4, [x10, lCPI0_83@PAGEOFF]
	str	q3, [sp, #5936]
	str	q4, [sp, #5920]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #1824
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	orr.16b	v16, v14, v16
	orr.16b	v4, v11, v4
	orr.16b	v3, v12, v3
	orr.16b	v5, v13, v5
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1258:
	adrp	x10, lCPI0_84@PAGE
Lloh1259:
	ldr	q3, [x10, lCPI0_84@PAGEOFF]
Lloh1260:
	adrp	x10, lCPI0_85@PAGE
Lloh1261:
	ldr	q4, [x10, lCPI0_85@PAGEOFF]
	str	q3, [sp, #6032]
	str	q4, [sp, #6016]
Lloh1262:
	adrp	x10, lCPI0_86@PAGE
Lloh1263:
	ldr	q3, [x10, lCPI0_86@PAGEOFF]
Lloh1264:
	adrp	x10, lCPI0_87@PAGE
Lloh1265:
	ldr	q4, [x10, lCPI0_87@PAGEOFF]
	str	q3, [sp, #6000]
	str	q4, [sp, #5984]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #1888
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	bic.16b	v16, v16, v14
	bic.16b	v4, v4, v11
	bic.16b	v3, v3, v12
	bic.16b	v5, v5, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1266:
	adrp	x10, lCPI0_88@PAGE
Lloh1267:
	ldr	q3, [x10, lCPI0_88@PAGEOFF]
Lloh1268:
	adrp	x10, lCPI0_89@PAGE
Lloh1269:
	ldr	q4, [x10, lCPI0_89@PAGEOFF]
	str	q3, [sp, #6096]
	str	q4, [sp, #6080]
Lloh1270:
	adrp	x10, lCPI0_90@PAGE
Lloh1271:
	ldr	q3, [x10, lCPI0_90@PAGEOFF]
Lloh1272:
	adrp	x10, lCPI0_91@PAGE
Lloh1273:
	ldr	q4, [x10, lCPI0_91@PAGEOFF]
	str	q3, [sp, #6064]
	str	q4, [sp, #6048]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #1952
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	bic.16b	v16, v16, v14
	sub.2d	v16, v16, v14
	bic.16b	v4, v4, v11
	sub.2d	v4, v4, v11
	bic.16b	v3, v3, v12
	sub.2d	v3, v3, v12
	bic.16b	v5, v5, v13
	sub.2d	v5, v5, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1274:
	adrp	x10, lCPI0_92@PAGE
Lloh1275:
	ldr	q3, [x10, lCPI0_92@PAGEOFF]
Lloh1276:
	adrp	x10, lCPI0_93@PAGE
Lloh1277:
	ldr	q4, [x10, lCPI0_93@PAGEOFF]
	str	q3, [sp, #6160]
	str	q4, [sp, #6144]
Lloh1278:
	adrp	x10, lCPI0_94@PAGE
Lloh1279:
	ldr	q3, [x10, lCPI0_94@PAGEOFF]
Lloh1280:
	adrp	x10, lCPI0_95@PAGE
Lloh1281:
	ldr	q4, [x10, lCPI0_95@PAGEOFF]
	str	q3, [sp, #6128]
	str	q4, [sp, #6112]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #2016
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #2                          ; =0x2
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh1282:
	adrp	x10, lCPI0_96@PAGE
Lloh1283:
	ldr	q3, [x10, lCPI0_96@PAGEOFF]
Lloh1284:
	adrp	x10, lCPI0_97@PAGE
Lloh1285:
	ldr	q4, [x10, lCPI0_97@PAGEOFF]
	str	q3, [sp, #6224]
	str	q4, [sp, #6208]
Lloh1286:
	adrp	x10, lCPI0_98@PAGE
Lloh1287:
	ldr	q3, [x10, lCPI0_98@PAGEOFF]
Lloh1288:
	adrp	x10, lCPI0_99@PAGE
Lloh1289:
	ldr	q4, [x10, lCPI0_99@PAGEOFF]
	str	q3, [sp, #6192]
	str	q4, [sp, #6176]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #2080
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #3                          ; =0x3
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1290:
	adrp	x10, lCPI0_100@PAGE
Lloh1291:
	ldr	q3, [x10, lCPI0_100@PAGEOFF]
Lloh1292:
	adrp	x10, lCPI0_101@PAGE
Lloh1293:
	ldr	q4, [x10, lCPI0_101@PAGEOFF]
	str	q3, [sp, #6288]
	str	q4, [sp, #6272]
Lloh1294:
	adrp	x10, lCPI0_102@PAGE
Lloh1295:
	ldr	q3, [x10, lCPI0_102@PAGEOFF]
Lloh1296:
	adrp	x10, lCPI0_103@PAGE
Lloh1297:
	ldr	q4, [x10, lCPI0_103@PAGEOFF]
	str	q3, [sp, #6256]
	str	q4, [sp, #6240]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #2144
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #4                          ; =0x4
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1298:
	adrp	x10, lCPI0_104@PAGE
Lloh1299:
	ldr	q3, [x10, lCPI0_104@PAGEOFF]
Lloh1300:
	adrp	x10, lCPI0_105@PAGE
Lloh1301:
	ldr	q4, [x10, lCPI0_105@PAGEOFF]
	str	q3, [sp, #6352]
	str	q4, [sp, #6336]
Lloh1302:
	adrp	x10, lCPI0_106@PAGE
Lloh1303:
	ldr	q3, [x10, lCPI0_106@PAGEOFF]
Lloh1304:
	adrp	x10, lCPI0_107@PAGE
Lloh1305:
	ldr	q4, [x10, lCPI0_107@PAGEOFF]
	str	q3, [sp, #6320]
	str	q4, [sp, #6304]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #2208
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #5                          ; =0x5
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh1306:
	adrp	x10, lCPI0_108@PAGE
Lloh1307:
	ldr	q3, [x10, lCPI0_108@PAGEOFF]
Lloh1308:
	adrp	x10, lCPI0_109@PAGE
Lloh1309:
	ldr	q4, [x10, lCPI0_109@PAGEOFF]
	str	q3, [sp, #6416]
	str	q4, [sp, #6400]
Lloh1310:
	adrp	x10, lCPI0_110@PAGE
Lloh1311:
	ldr	q3, [x10, lCPI0_110@PAGEOFF]
Lloh1312:
	adrp	x10, lCPI0_111@PAGE
Lloh1313:
	ldr	q4, [x10, lCPI0_111@PAGEOFF]
	str	q3, [sp, #6384]
	str	q4, [sp, #6368]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #2272
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #6                          ; =0x6
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1314:
	adrp	x10, lCPI0_112@PAGE
Lloh1315:
	ldr	q3, [x10, lCPI0_112@PAGEOFF]
Lloh1316:
	adrp	x10, lCPI0_113@PAGE
Lloh1317:
	ldr	q4, [x10, lCPI0_113@PAGEOFF]
	str	q3, [sp, #6480]
	str	q4, [sp, #6464]
Lloh1318:
	adrp	x10, lCPI0_114@PAGE
Lloh1319:
	ldr	q3, [x10, lCPI0_114@PAGEOFF]
Lloh1320:
	adrp	x10, lCPI0_115@PAGE
Lloh1321:
	ldr	q4, [x10, lCPI0_115@PAGEOFF]
	str	q3, [sp, #6448]
	str	q4, [sp, #6432]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #2336
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #7                          ; =0x7
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1322:
	adrp	x10, lCPI0_116@PAGE
Lloh1323:
	ldr	q3, [x10, lCPI0_116@PAGEOFF]
Lloh1324:
	adrp	x10, lCPI0_117@PAGE
Lloh1325:
	ldr	q4, [x10, lCPI0_117@PAGEOFF]
	str	q3, [sp, #6544]
	str	q4, [sp, #6528]
Lloh1326:
	adrp	x10, lCPI0_118@PAGE
Lloh1327:
	ldr	q3, [x10, lCPI0_118@PAGEOFF]
Lloh1328:
	adrp	x10, lCPI0_119@PAGE
Lloh1329:
	ldr	q4, [x10, lCPI0_119@PAGEOFF]
	str	q3, [sp, #6512]
	str	q4, [sp, #6496]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #2400
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #8                          ; =0x8
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh1330:
	adrp	x10, lCPI0_120@PAGE
Lloh1331:
	ldr	q3, [x10, lCPI0_120@PAGEOFF]
Lloh1332:
	adrp	x10, lCPI0_121@PAGE
Lloh1333:
	ldr	q4, [x10, lCPI0_121@PAGEOFF]
	str	q3, [sp, #6608]
	str	q4, [sp, #6592]
Lloh1334:
	adrp	x10, lCPI0_122@PAGE
Lloh1335:
	ldr	q3, [x10, lCPI0_122@PAGEOFF]
Lloh1336:
	adrp	x10, lCPI0_123@PAGE
Lloh1337:
	ldr	q4, [x10, lCPI0_123@PAGEOFF]
	str	q3, [sp, #6576]
	str	q4, [sp, #6560]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #2464
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #9                          ; =0x9
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1338:
	adrp	x10, lCPI0_124@PAGE
Lloh1339:
	ldr	q3, [x10, lCPI0_124@PAGEOFF]
Lloh1340:
	adrp	x10, lCPI0_125@PAGE
Lloh1341:
	ldr	q4, [x10, lCPI0_125@PAGEOFF]
	str	q3, [sp, #6672]
	str	q4, [sp, #6656]
Lloh1342:
	adrp	x10, lCPI0_126@PAGE
Lloh1343:
	ldr	q3, [x10, lCPI0_126@PAGEOFF]
Lloh1344:
	adrp	x10, lCPI0_127@PAGE
Lloh1345:
	ldr	q4, [x10, lCPI0_127@PAGEOFF]
	str	q3, [sp, #6640]
	str	q4, [sp, #6624]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #2528
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #10                         ; =0xa
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1346:
	adrp	x10, lCPI0_128@PAGE
Lloh1347:
	ldr	q3, [x10, lCPI0_128@PAGEOFF]
Lloh1348:
	adrp	x10, lCPI0_129@PAGE
Lloh1349:
	ldr	q4, [x10, lCPI0_129@PAGEOFF]
	str	q3, [sp, #6736]
	str	q4, [sp, #6720]
Lloh1350:
	adrp	x10, lCPI0_130@PAGE
Lloh1351:
	ldr	q3, [x10, lCPI0_130@PAGEOFF]
Lloh1352:
	adrp	x10, lCPI0_131@PAGE
Lloh1353:
	ldr	q4, [x10, lCPI0_131@PAGEOFF]
	str	q3, [sp, #6704]
	str	q4, [sp, #6688]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #2592
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #11                         ; =0xb
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh1354:
	adrp	x10, lCPI0_132@PAGE
Lloh1355:
	ldr	q3, [x10, lCPI0_132@PAGEOFF]
Lloh1356:
	adrp	x10, lCPI0_133@PAGE
Lloh1357:
	ldr	q4, [x10, lCPI0_133@PAGEOFF]
	str	q3, [sp, #6800]
	str	q4, [sp, #6784]
Lloh1358:
	adrp	x10, lCPI0_134@PAGE
Lloh1359:
	ldr	q3, [x10, lCPI0_134@PAGEOFF]
Lloh1360:
	adrp	x10, lCPI0_135@PAGE
Lloh1361:
	ldr	q4, [x10, lCPI0_135@PAGEOFF]
	str	q3, [sp, #6768]
	str	q4, [sp, #6752]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #2656
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #12                         ; =0xc
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1362:
	adrp	x10, lCPI0_136@PAGE
Lloh1363:
	ldr	q3, [x10, lCPI0_136@PAGEOFF]
Lloh1364:
	adrp	x10, lCPI0_137@PAGE
Lloh1365:
	ldr	q4, [x10, lCPI0_137@PAGEOFF]
	str	q3, [sp, #6864]
	str	q4, [sp, #6848]
Lloh1366:
	adrp	x10, lCPI0_138@PAGE
Lloh1367:
	ldr	q3, [x10, lCPI0_138@PAGEOFF]
Lloh1368:
	adrp	x10, lCPI0_139@PAGE
Lloh1369:
	ldr	q4, [x10, lCPI0_139@PAGEOFF]
	str	q3, [sp, #6832]
	str	q4, [sp, #6816]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #2720
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w5, #13                         ; =0xd
	dup.2d	v17, x5
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
Lloh1370:
	adrp	x10, lCPI0_140@PAGE
Lloh1371:
	ldr	q3, [x10, lCPI0_140@PAGEOFF]
Lloh1372:
	adrp	x10, lCPI0_141@PAGE
Lloh1373:
	ldr	q4, [x10, lCPI0_141@PAGEOFF]
	str	q3, [sp, #6928]
	str	q4, [sp, #6912]
Lloh1374:
	adrp	x10, lCPI0_142@PAGE
Lloh1375:
	ldr	q3, [x10, lCPI0_142@PAGEOFF]
Lloh1376:
	adrp	x10, lCPI0_143@PAGE
Lloh1377:
	ldr	q4, [x10, lCPI0_143@PAGEOFF]
	str	q3, [sp, #6896]
	str	q4, [sp, #6880]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #2784
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	mov	w5, #14                         ; =0xe
	dup.2d	v5, x5
	ldp	q17, q16, [x10, #32]
	bit.16b	v17, v5, v14
	bit.16b	v4, v5, v11
	bit.16b	v3, v5, v12
	bif.16b	v5, v16, v13
	stp	q3, q4, [x10]
	stp	q17, q5, [x10, #32]
Lloh1378:
	adrp	x10, lCPI0_144@PAGE
Lloh1379:
	ldr	q3, [x10, lCPI0_144@PAGEOFF]
Lloh1380:
	adrp	x10, lCPI0_145@PAGE
Lloh1381:
	ldr	q4, [x10, lCPI0_145@PAGEOFF]
	str	q3, [sp, #6992]
	str	q4, [sp, #6976]
Lloh1382:
	adrp	x10, lCPI0_146@PAGE
Lloh1383:
	ldr	q3, [x10, lCPI0_146@PAGEOFF]
Lloh1384:
	adrp	x10, lCPI0_147@PAGE
Lloh1385:
	ldr	q4, [x10, lCPI0_147@PAGEOFF]
	str	q3, [sp, #6960]
	str	q4, [sp, #6944]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #2848
	ldr	x10, [x10, x2]
	sub	x10, x10, x3
	add	x10, x4, x10
	ldp	q3, q4, [x10]
	ldp	q16, q5, [x10, #32]
	mov	w2, #15                         ; =0xf
	dup.2d	v17, x2
	bit.16b	v16, v17, v14
	bit.16b	v4, v17, v11
	bit.16b	v3, v17, v12
	bit.16b	v5, v17, v13
	stp	q3, q4, [x10]
	stp	q16, q5, [x10, #32]
	ldr	q3, [sp, #16352]
	ldr	q4, [sp, #16368]
	ldr	q5, [sp, #16320]
	ldr	q16, [sp, #16336]
	ldr	q17, [sp, #16288]
	ldr	q18, [sp, #16304]
	ldr	q19, [sp, #16256]
	ldr	q22, [sp, #16272]
	ldr	q23, [sp, #192]                 ; 16-byte Folded Reload
	bit.16b	v22, v23, v11
	bit.16b	v19, v23, v12
	bit.16b	v18, v23, v13
	bit.16b	v17, v23, v14
Lloh1386:
	adrp	x10, lCPI0_17@PAGE
Lloh1387:
	ldr	q23, [x10, lCPI0_17@PAGEOFF]
	bit.16b	v16, v23, v11
Lloh1388:
	adrp	x10, lCPI0_16@PAGE
Lloh1389:
	ldr	q23, [x10, lCPI0_16@PAGEOFF]
	bit.16b	v5, v23, v12
Lloh1390:
	adrp	x10, lCPI0_19@PAGE
Lloh1391:
	ldr	q23, [x10, lCPI0_19@PAGEOFF]
	bit.16b	v4, v23, v13
Lloh1392:
	adrp	x10, lCPI0_18@PAGE
Lloh1393:
	ldr	q23, [x10, lCPI0_18@PAGEOFF]
	bit.16b	v3, v23, v14
	str	q3, [sp, #16352]
	str	q4, [sp, #16368]
	str	q5, [sp, #16320]
	str	q16, [sp, #16336]
	str	q17, [sp, #16288]
	str	q18, [sp, #16304]
	str	q19, [sp, #16256]
	str	q22, [sp, #16272]
	ldr	q0, [sp, #1264]                 ; 16-byte Folded Reload
	bic.16b	v0, v0, v13
	str	q0, [sp, #1264]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #1168]                 ; 16-byte Folded Reload
	bic.16b	v0, v0, v14
	str	q0, [sp, #1168]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #1184]                 ; 16-byte Folded Reload
	bic.16b	v0, v0, v11
	str	q0, [sp, #1184]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #1200]                 ; 16-byte Folded Reload
	bic.16b	v0, v0, v12
LBB0_771:                               ; %schedule.38
                                        ;   in Loop: Header=BB0_7 Depth=3
	str	q0, [sp, #1200]                 ; 16-byte Folded Spill
LBB0_772:                               ; %schedule.38
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	mov	w2, #128                        ; =0x80
	dup.2d	v3, x2
	ldr	q17, [sp, #1184]                ; 16-byte Folded Reload
	cmgt.2d	v4, v3, v17
	ldr	q0, [sp, #1200]                 ; 16-byte Folded Reload
	cmgt.2d	v5, v3, v0
	uzp1.4s	v4, v5, v4
	ldr	q18, [sp, #1168]                ; 16-byte Folded Reload
	cmgt.2d	v5, v3, v18
	ldr	q19, [sp, #1264]                ; 16-byte Folded Reload
	cmgt.2d	v16, v3, v19
	uzp1.4s	v5, v5, v16
	uzp1.8h	v4, v4, v5
	xtn.8b	v4, v4
	and.8b	v11, v10, v4
	shl.8b	v4, v11, #7
	cmlt.8b	v4, v4, #0
	and.8b	v5, v4, v2
	addv.8b	b5, v5
	fmov	w2, s5
	umaxv.8b	b4, v4
	fmov	w4, s4
	tbz	w4, #0, LBB0_778
; %bb.773:                              ; %schedule.38
                                        ;   in Loop: Header=BB0_7 Depth=3
	cmge.2d	v4, v17, v3
	cmge.2d	v5, v0, v3
	uzp1.4s	v4, v5, v4
	cmge.2d	v5, v18, v3
	cmge.2d	v3, v19, v3
	uzp1.4s	v3, v5, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v12, v10, v3
	shl.8b	v3, v12, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w4, s3
	tst	w4, #0xff
	b.eq	LBB0_778
; %bb.774:                              ; %varying.divergent863
                                        ;   in Loop: Header=BB0_7 Depth=3
	subs	w10, w1, #1
	csel	w10, wzr, w10, lo
	and	w3, w17, #0xff
	lsr	w2, w3, w10
	tst	w2, #0x1
	str	q9, [sp, #4128]
	str	q8, [sp, #4144]
	and	x10, x10, #0x7
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #32
	ldr	w10, [x2, x10, lsl #2]
	ccmp	w1, #0, #4, ne
	ccmp	w10, #14, #0, ne
	cset	w2, ne
	cmp	w3, #255
	b.ne	LBB0_776
; %bb.775:                              ; %varying.divergent863
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #0, LBB0_1006
LBB0_776:                               ; %convergence.overflow.resume866
                                        ;   in Loop: Header=BB0_7 Depth=3
	mvn	w10, w17
	rbit	w10, w10
	clz	w10, w10
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w17
	csel	w4, wzr, w10, eq
	add	x3, sp, #18, lsl #12            ; =73728
	add	x3, x3, #752
	ldrb	w10, [x3, w4, uxtw]
	and	w5, w10, #0x1
	fmov	s3, w5
	ubfx	w5, w10, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w10, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w10, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w10, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w10, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w10, #6, #1
	mov.b	v3[6], w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x5, w4, uxtw]
	and	w6, w10, #0x1
	fmov	s4, w6
	ubfx	w6, w10, #1, #1
	mov.b	v4[1], w6
	ubfx	w6, w10, #2, #1
	mov.b	v4[2], w6
	ubfx	w6, w10, #3, #1
	mov.b	v4[3], w6
	ubfx	w6, w10, #4, #1
	mov.b	v4[4], w6
	ubfx	w6, w10, #5, #1
	mov.b	v4[5], w6
	ubfx	w6, w10, #6, #1
	mov.b	v4[6], w6
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	cmp	w2, #0
	csetm	w10, ne
	dup.8b	v5, w10
	bit.8b	v3, v10, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x3, w4, uxtw]
	bic.8b	v3, v4, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w4, uxtw]
	cmp	x0, #8
	b.hs	LBB0_1006
; %bb.777:                              ; %ready.overflow.resume868
                                        ;   in Loop: Header=BB0_7 Depth=3
	str	q7, [sp, #4096]
	str	q6, [sp, #4112]
	ubfiz	x10, x4, #2, #3
	add	x3, sp, #1, lsl #12             ; =4096
	ldr	w3, [x3, x10]
	cmp	w2, #0
	csel	w3, w1, w3, ne
	csinc	w1, w1, w4, eq
	str	q7, [sp, #4064]
	str	q6, [sp, #4080]
	add	x5, sp, #4064
	str	w3, [x5, x10]
	ldr	q6, [sp, #4080]
	ldr	q7, [sp, #4064]
	str	q9, [sp, #4032]
	str	q8, [sp, #4048]
	add	x3, sp, #4032
	ldr	w3, [x3, x10]
	mov	w5, #14                         ; =0xe
	csel	w3, w5, w3, ne
	str	q9, [sp, #4000]
	str	q8, [sp, #4016]
	add	x5, sp, #4000
	str	w3, [x5, x10]
	mov	w3, #42                         ; =0x2a
	mov	w5, #39                         ; =0x27
	ldr	q8, [sp, #4016]
	ldr	q9, [sp, #4000]
	b	LBB0_938
LBB0_778:                               ; %varying.coherent864
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_834
; %bb.779:                              ; %varying.coherent.true869
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
	tst	w3, #0xff
	b.eq	LBB0_5
LBB0_780:                               ; %schedule.39
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.16b	v0, v21
	mov.16b	v21, v20
	mov.16b	v20, v15
	mov	b3, v10[0]
	mov.b	v3[4], v10[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v4, v3, #0
	ldr	q3, [sp, #1200]                 ; 16-byte Folded Reload
	and.16b	v18, v4, v3
	mov	b3, v10[2]
	mov.b	v3[4], v10[3]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v5, v3, #0
	ldr	q3, [sp, #1184]                 ; 16-byte Folded Reload
	and.16b	v19, v5, v3
	mov	b3, v10[4]
	mov.b	v3[4], v10[5]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v24, v3, #0
	ldr	q3, [sp, #1168]                 ; 16-byte Folded Reload
	and.16b	v26, v24, v3
	mov	b3, v10[6]
	mov.b	v3[4], v10[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v25, v3, #0
	ldr	q3, [sp, #1264]                 ; 16-byte Folded Reload
	and.16b	v3, v25, v3
	shl.8b	v16, v10, #7
	cmlt.8b	v16, v16, #0
	and.8b	v17, v16, v2
	addv.8b	b13, v17
	fmov	w3, s13
	mov	w4, #32                         ; =0x20
	dup.2d	v27, x4
	and.16b	v17, v4, v27
	mvn.16b	v4, v4
	sub.2d	v17, v17, v4
	and.16b	v4, v5, v27
	mvn.16b	v5, v5
	sub.2d	v4, v4, v5
	and.16b	v5, v24, v27
	and.16b	v27, v25, v27
	mvn.16b	v25, v25
	sub.2d	v25, v27, v25
	mov.d	x4, v25[1]
	mov.d	x5, v3[1]
	sdiv	x5, x5, x4
	mvn.16b	v24, v24
	sub.2d	v5, v5, v24
	fmov	x6, d25
	fmov	x7, d3
	sdiv	x7, x7, x6
	mul	x6, x7, x6
	fmov	d11, x7
	mov.d	v11[1], x5
	mov.d	x7, v5[1]
	mov.d	x19, v26[1]
	sdiv	x19, x19, x7
	fmov	x20, d5
	fmov	x21, d26
	sdiv	x21, x21, x20
	mul	x20, x21, x20
	fmov	d12, x21
	mov.d	v12[1], x19
	mov.d	x21, v4[1]
	mov.d	x22, v19[1]
	sdiv	x22, x22, x21
	fmov	x23, d4
	fmov	x24, d19
	sdiv	x24, x24, x23
	mul	x23, x24, x23
	fmov	d14, x24
	mov.d	v14[1], x22
	mov.d	x24, v17[1]
	mov.d	x25, v18[1]
	fmov	x26, d17
	fmov	x27, d18
	sdiv	x27, x27, x26
	mul	x26, x27, x26
	fmov	d17, x27
	sdiv	x25, x25, x24
	mov.d	v17[1], x25
	mul	x24, x25, x24
	fmov	d4, x26
	mov.d	v4[1], x24
	mul	x21, x22, x21
	fmov	d5, x23
	mov.d	v5[1], x21
	mul	x7, x19, x7
	fmov	d24, x20
	mov.d	v24[1], x7
	mul	x4, x5, x4
	fmov	d25, x6
	mov.d	v25[1], x4
	sub.2d	v3, v3, v25
	sub.2d	v24, v26, v24
	sub.2d	v5, v19, v5
	sub.2d	v4, v18, v4
	dup.2d	v18, x16
	add.2d	v4, v4, v18
	add.2d	v5, v5, v18
	add.2d	v19, v24, v18
	add.2d	v3, v3, v18
	ldr	q18, [sp, #16384]
	ldr	q24, [sp, #16400]
	ldr	q25, [sp, #16416]
	ldr	q26, [sp, #16432]
	ldr	q27, [sp, #16496]
	ldr	q28, [sp, #16480]
	ldr	q29, [sp, #16464]
	shl.2d	v3, v3, #6
	shl.2d	v19, v19, #6
	shl.2d	v5, v5, #6
	shl.2d	v30, v4, #6
	ldr	q15, [sp, #16448]
	add.2d	v4, v26, v27
	add.2d	v31, v4, v3
	add.2d	v3, v25, v28
	add.2d	v3, v3, v19
	add.2d	v4, v24, v29
	add.2d	v4, v4, v5
	add.2d	v5, v18, v15
	add.2d	v15, v5, v30
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	tbnz	w3, #0, LBB0_819
; %bb.781:                              ; %else4835
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #1, LBB0_820
LBB0_782:                               ; %else4841
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.16b	v15, v20
	mov.16b	v20, v21
	tbnz	w3, #2, LBB0_821
LBB0_783:                               ; %else4847
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.16b	v21, v0
	tbnz	w3, #3, LBB0_822
LBB0_784:                               ; %else4853
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #4, LBB0_823
LBB0_785:                               ; %else4859
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #5, LBB0_824
LBB0_786:                               ; %else4865
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #6, LBB0_825
LBB0_787:                               ; %else4871
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w3, #7, LBB0_789
LBB0_788:                               ; %cond.load4873
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x3, v31[1]
	ld1.d	{ v27 }[1], [x3]
LBB0_789:                               ; %else4877
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w3, #32                         ; =0x20
	dup.2d	v3, x3
	cmhi.2d	v4, v3, v19
	cmhi.2d	v5, v3, v18
	uzp1.4s	v4, v5, v4
	cmhi.2d	v5, v3, v26
	cmhi.2d	v3, v3, v27
	uzp1.4s	v3, v5, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	ldrb	w3, [x9]
	and	w4, w3, #0x1
	fmov	s4, w4
	ubfx	w4, w3, #1, #1
	mov.b	v4[1], w4
	ubfx	w4, w3, #2, #1
	mov.b	v4[2], w4
	ubfx	w4, w3, #3, #1
	mov.b	v4[3], w4
	ubfx	w4, w3, #4, #1
	mov.b	v4[4], w4
	ubfx	w4, w3, #5, #1
	mov.b	v4[5], w4
	ubfx	w4, w3, #6, #1
	mov.b	v4[6], w4
	lsr	w3, w3, #7
	mov.b	v4[7], w3
	bif.8b	v3, v4, v16
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x9]
	shl.2d	v5, v14, #5
	shl.2d	v4, v17, #5
	shl.2d	v16, v11, #5
	shl.2d	v3, v12, #5
	add.2d	v3, v26, v3
	add.2d	v16, v27, v16
	add.2d	v4, v18, v4
	add.2d	v17, v19, v5
	ldr	q5, [sp, #16160]
	ldr	q18, [sp, #16176]
	ldr	q19, [sp, #16128]
	ldr	q24, [sp, #16144]
	mov	b25, v10[2]
	mov.b	v25[4], v10[3]
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	mov	b26, v10[0]
	mov.b	v26[4], v10[1]
	bit.16b	v24, v17, v25
	ushll.2d	v25, v26, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	bit.16b	v19, v4, v25
	mov	b25, v10[6]
	mov.b	v25[4], v10[7]
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	bit.16b	v18, v16, v25
	mov	b25, v10[4]
	mov.b	v25[4], v10[5]
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	bit.16b	v5, v3, v25
	str	q5, [sp, #16160]
	str	q18, [sp, #16176]
	str	q19, [sp, #16128]
	str	q24, [sp, #16144]
	mov	w3, #128                        ; =0x80
	dup.2d	v18, x3
	cmhi.2d	v5, v18, v4
	cmhi.2d	v19, v18, v17
	uzp1.4s	v5, v5, v19
	cmhi.2d	v19, v18, v3
	cmhi.2d	v24, v18, v16
	uzp1.4s	v19, v19, v24
	uzp1.8h	v5, v5, v19
	xtn.8b	v5, v5
	and.8b	v11, v10, v5
	shl.8b	v5, v11, #7
	cmlt.8b	v5, v5, #0
	and.8b	v19, v5, v2
	addv.8b	b19, v19
	fmov	w3, s19
	umaxv.8b	b5, v5
	fmov	w4, s5
	tbz	w4, #0, LBB0_795
; %bb.790:                              ; %else4877
                                        ;   in Loop: Header=BB0_7 Depth=3
	cmhs.2d	v4, v4, v18
	cmhs.2d	v5, v17, v18
	uzp1.4s	v4, v4, v5
	cmhs.2d	v3, v3, v18
	cmhs.2d	v5, v16, v18
	uzp1.4s	v3, v3, v5
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v12, v10, v3
	shl.8b	v3, v12, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w4, s3
	tst	w4, #0xff
	b.eq	LBB0_795
; %bb.791:                              ; %varying.divergent877
                                        ;   in Loop: Header=BB0_7 Depth=3
	subs	w10, w1, #1
	csel	w10, wzr, w10, lo
	and	w3, w17, #0xff
	lsr	w2, w3, w10
	tst	w2, #0x1
	str	q9, [sp, #4288]
	str	q8, [sp, #4304]
	and	x10, x10, #0x7
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #192
	ldr	w10, [x2, x10, lsl #2]
	ccmp	w1, #0, #4, ne
	ccmp	w10, #15, #0, ne
	cset	w2, ne
	cmp	w3, #255
	b.ne	LBB0_793
; %bb.792:                              ; %varying.divergent877
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #0, LBB0_1006
LBB0_793:                               ; %convergence.overflow.resume880
                                        ;   in Loop: Header=BB0_7 Depth=3
	mvn	w10, w17
	rbit	w10, w10
	clz	w10, w10
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w17
	csel	w4, wzr, w10, eq
	add	x3, sp, #18, lsl #12            ; =73728
	add	x3, x3, #752
	ldrb	w10, [x3, w4, uxtw]
	and	w5, w10, #0x1
	fmov	s3, w5
	ubfx	w5, w10, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w10, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w10, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w10, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w10, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w10, #6, #1
	mov.b	v3[6], w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x5, w4, uxtw]
	and	w6, w10, #0x1
	fmov	s4, w6
	ubfx	w6, w10, #1, #1
	mov.b	v4[1], w6
	ubfx	w6, w10, #2, #1
	mov.b	v4[2], w6
	ubfx	w6, w10, #3, #1
	mov.b	v4[3], w6
	ubfx	w6, w10, #4, #1
	mov.b	v4[4], w6
	ubfx	w6, w10, #5, #1
	mov.b	v4[5], w6
	ubfx	w6, w10, #6, #1
	mov.b	v4[6], w6
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	cmp	w2, #0
	csetm	w10, ne
	dup.8b	v5, w10
	bit.8b	v3, v10, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x3, w4, uxtw]
	bic.8b	v3, v4, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w4, uxtw]
	cmp	x0, #8
	b.hs	LBB0_1006
; %bb.794:                              ; %ready.overflow.resume882
                                        ;   in Loop: Header=BB0_7 Depth=3
	zip2.8b	v3, v12, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldp	q5, q0, [sp, #608]              ; 32-byte Folded Reload
	and.16b	v4, v3, v5
	zip1.8b	v3, v12, v5
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v0, v3, v0
	stp	q4, q0, [sp, #608]              ; 32-byte Folded Spill
	str	q7, [sp, #4256]
	str	q6, [sp, #4272]
	ubfiz	x10, x4, #2, #3
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #160
	ldr	w3, [x3, x10]
	cmp	w2, #0
	csel	w3, w1, w3, ne
	csinc	w1, w1, w4, eq
	str	q7, [sp, #4224]
	str	q6, [sp, #4240]
	add	x5, sp, #1, lsl #12             ; =4096
	add	x5, x5, #128
	str	w3, [x5, x10]
	ldr	q6, [sp, #4240]
	ldr	q7, [sp, #4224]
	str	q9, [sp, #4192]
	str	q8, [sp, #4208]
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #96
	ldr	w3, [x3, x10]
	mov	w5, #15                         ; =0xf
	csel	w3, w5, w3, ne
	str	q9, [sp, #4160]
	str	q8, [sp, #4176]
	add	x5, sp, #1, lsl #12             ; =4096
	add	x5, x5, #64
	str	w3, [x5, x10]
	mov	w3, #41                         ; =0x29
	mov	w5, #40                         ; =0x28
	ldr	q8, [sp, #4176]
	ldr	q9, [sp, #4160]
	b	LBB0_938
LBB0_795:                               ; %varying.coherent878
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_833
; %bb.796:                              ; %varying.coherent.true883
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w2, #0, LBB0_797
	b	LBB0_5
LBB0_797:                               ; %schedule.40.thread
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q3, [sp, #16512]
	ldr	q4, [sp, #16528]
	ldr	q5, [sp, #16544]
	ldr	q16, [sp, #16560]
	ldr	q17, [sp, #16624]
	ldr	q18, [sp, #16608]
	ldr	q19, [sp, #16592]
	ldr	q22, [sp, #16576]
	ldr	q23, [sp, #16128]
	ldr	q24, [sp, #16144]
	ldr	q25, [sp, #16160]
	ldr	q26, [sp, #16176]
	shl.2d	v26, v26, #5
	shl.2d	v25, v25, #5
	shl.2d	v24, v24, #5
	shl.2d	v23, v23, #5
	add.2d	v16, v16, v17
	add.2d	v17, v16, v26
	add.2d	v5, v5, v18
	add.2d	v18, v5, v25
	add.2d	v4, v4, v19
	add.2d	v4, v4, v24
	add.2d	v3, v3, v22
	add.2d	v19, v3, v23
	fmov	w2, s13
	movi.2d	v16, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w2, #0, LBB0_843
; %bb.798:                              ; %else5523
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #1, LBB0_844
LBB0_799:                               ; %else5529
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #2, LBB0_845
LBB0_800:                               ; %else5535
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #3, LBB0_846
LBB0_801:                               ; %else5541
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #4, LBB0_847
LBB0_802:                               ; %else5547
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #5, LBB0_848
LBB0_803:                               ; %else5553
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #6, LBB0_849
LBB0_804:                               ; %else5559
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w2, #7, LBB0_806
LBB0_805:                               ; %cond.load5561
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v17[1]
	ld1.s	{ v3 }[3], [x10]
LBB0_806:                               ; %else5565
                                        ;   in Loop: Header=BB0_7 Depth=3
	zip2.8b	v4, v10, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q0, [sp, #608]                  ; 16-byte Folded Reload
	bit.16b	v0, v3, v4
	str	q0, [sp, #608]                  ; 16-byte Folded Spill
	zip1.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q0, [sp, #624]                  ; 16-byte Folded Reload
	bit.16b	v0, v16, v3
	str	q0, [sp, #624]                  ; 16-byte Folded Spill
	cbnz	w1, LBB0_92
LBB0_807:                               ; %schedule.41.convergence.cascade.exit888_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
LBB0_808:                               ; %convergence.cascade.exit888
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
; %bb.809:                              ; %convergence.target.41.ready
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q0, [sp, #768]                  ; 16-byte Folded Reload
	dup.4s	v4, v0[0]
	ldrb	w10, [x9]
	ubfx	w2, w10, #3, #1
	ubfx	w3, w10, #2, #1
	ubfx	w4, w10, #1, #1
	and	w5, w10, #0x1
	lsr	w6, w10, #7
	ubfx	w7, w10, #6, #1
	ubfx	w19, w10, #5, #1
	ubfx	w10, w10, #4, #1
	fmov	s3, w10
	mov.h	v3[1], w19
	mov.h	v3[2], w7
	mov.h	v3[3], w6
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	fmov	s5, w5
	mov.h	v5[1], w4
	mov.h	v5[2], w3
	mov.h	v5[3], w2
	ldr	q0, [sp, #608]                  ; 16-byte Folded Reload
	bsl.16b	v3, v0, v4
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q0, [sp, #624]                  ; 16-byte Folded Reload
	mov.16b	v16, v5
	bsl.16b	v16, v0, v4
	ldr	q4, [sp, #16304]
	ldr	q5, [sp, #16288]
	ldr	q17, [sp, #16272]
	ldr	q18, [sp, #16256]
	ldr	q19, [sp, #16320]
	ldr	q22, [sp, #16336]
	ldr	q23, [sp, #16352]
	ldr	q24, [sp, #16368]
	ldr	q0, [sp, #1200]                 ; 16-byte Folded Reload
	shl.2d	v25, v0, #5
	ldr	q0, [sp, #1184]                 ; 16-byte Folded Reload
	shl.2d	v26, v0, #5
	ldr	q0, [sp, #1168]                 ; 16-byte Folded Reload
	shl.2d	v27, v0, #5
	ldr	q0, [sp, #1264]                 ; 16-byte Folded Reload
	shl.2d	v28, v0, #5
	add.2d	v24, v24, v28
	add.2d	v23, v23, v27
	add.2d	v22, v22, v26
	add.2d	v19, v19, v25
	add.2d	v19, v18, v19
	add.2d	v18, v17, v22
	add.2d	v17, v5, v23
	add.2d	v4, v4, v24
	shl.8b	v5, v10, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	fmov	w2, s5
	tbnz	w2, #0, LBB0_826
; %bb.810:                              ; %else5571
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #1, LBB0_827
LBB0_811:                               ; %else5575
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q0, [sp, #1200]                 ; 16-byte Folded Reload
	ldr	q5, [sp, #1184]                 ; 16-byte Folded Reload
	tbnz	w2, #2, LBB0_828
LBB0_812:                               ; %else5579
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #3, LBB0_829
LBB0_813:                               ; %else5583
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #4, LBB0_830
LBB0_814:                               ; %else5587
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q16, [sp, #1168]                ; 16-byte Folded Reload
	tbnz	w2, #5, LBB0_831
LBB0_815:                               ; %else5591
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #6, LBB0_832
LBB0_816:                               ; %else5595
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w2, #7, LBB0_818
LBB0_817:                               ; %cond.store5596
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v4[1]
	st1.s	{ v3 }[3], [x10]
LBB0_818:                               ; %else5599
                                        ;   in Loop: Header=BB0_7 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v10, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v4, v3, #0
	ushll2.4s	v3, v3, #0
	ldr	q17, [sp, #1264]                ; 16-byte Folded Reload
	uaddw2.2d	v17, v17, v3
	str	q17, [sp, #1264]                ; 16-byte Folded Spill
	uaddw.2d	v16, v16, v3
	str	q16, [sp, #1168]                ; 16-byte Folded Spill
	uaddw2.2d	v5, v5, v4
	str	q5, [sp, #1184]                 ; 16-byte Folded Spill
	uaddw.2d	v0, v0, v4
	b	LBB0_771
LBB0_819:                               ; %cond.load4831
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d15
	ldr	d18, [x4]
	tbz	w3, #1, LBB0_782
LBB0_820:                               ; %cond.load4837
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v15[1]
	ld1.d	{ v18 }[1], [x4]
	mov.16b	v15, v20
	mov.16b	v20, v21
	tbz	w3, #2, LBB0_783
LBB0_821:                               ; %cond.load4843
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d4
	ld1.d	{ v19 }[0], [x4]
	mov.16b	v21, v0
	tbz	w3, #3, LBB0_784
LBB0_822:                               ; %cond.load4849
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v4[1]
	ld1.d	{ v19 }[1], [x4]
	tbz	w3, #4, LBB0_785
LBB0_823:                               ; %cond.load4855
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d3
	ld1.d	{ v26 }[0], [x4]
	tbz	w3, #5, LBB0_786
LBB0_824:                               ; %cond.load4861
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x4, v3[1]
	ld1.d	{ v26 }[1], [x4]
	tbz	w3, #6, LBB0_787
LBB0_825:                               ; %cond.load4867
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x4, d31
	ld1.d	{ v27 }[0], [x4]
	tbnz	w3, #7, LBB0_788
	b	LBB0_789
LBB0_826:                               ; %cond.store5568
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d19
	str	s16, [x10]
	tbz	w2, #1, LBB0_811
LBB0_827:                               ; %cond.store5572
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v19[1]
	st1.s	{ v16 }[1], [x10]
	ldr	q0, [sp, #1200]                 ; 16-byte Folded Reload
	ldr	q5, [sp, #1184]                 ; 16-byte Folded Reload
	tbz	w2, #2, LBB0_812
LBB0_828:                               ; %cond.store5576
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d18
	st1.s	{ v16 }[2], [x10]
	tbz	w2, #3, LBB0_813
LBB0_829:                               ; %cond.store5580
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v18[1]
	st1.s	{ v16 }[3], [x10]
	tbz	w2, #4, LBB0_814
LBB0_830:                               ; %cond.store5584
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d17
	str	s3, [x10]
	ldr	q16, [sp, #1168]                ; 16-byte Folded Reload
	tbz	w2, #5, LBB0_815
LBB0_831:                               ; %cond.store5588
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v17[1]
	st1.s	{ v3 }[1], [x10]
	tbz	w2, #6, LBB0_816
LBB0_832:                               ; %cond.store5592
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d4
	st1.s	{ v3 }[2], [x10]
	tbnz	w2, #7, LBB0_817
	b	LBB0_818
LBB0_833:                               ; %varying.coherent.false884
                                        ;   in Loop: Header=BB0_7 Depth=3
	zip2.8b	v3, v10, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	ldp	q5, q0, [sp, #608]              ; 32-byte Folded Reload
	and.16b	v4, v3, v5
	zip1.8b	v3, v10, v5
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v0, v3, v0
	stp	q4, q0, [sp, #608]              ; 32-byte Folded Spill
	tbnz	w2, #0, LBB0_1009
	b	LBB0_91
LBB0_1009:                              ; %varying.coherent.false884
                                        ;   in Loop: Header=BB0_6 Depth=2
	b	LBB0_5
LBB0_834:                               ; %varying.coherent.false870
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
LBB0_835:                               ; %schedule.42
                                        ;   in Loop: Header=BB0_7 Depth=3
	cbz	w1, LBB0_840
; %bb.836:                              ; %convergence.cascade912.preheader
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
LBB0_837:                               ; %convergence.cascade912
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_7 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w10, s4
	umaxv.8b	b3, v3
	fmov	w6, s3
	sub	w3, w1, #1
	tst	w10, #0xff
	csel	w4, w3, wzr, ne
	mov	w10, #1                         ; =0x1
	lsl	w5, w10, w4
	and	w10, w5, w17
	tst	w10, #0xff
	cset	w10, ne
	str	q9, [sp, #4928]
	str	q8, [sp, #4944]
	ubfiz	x3, x4, #2, #3
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #832
	ldr	w7, [x7, x3]
	cmp	w7, #14
	cset	w7, eq
	and	w19, w10, w6
	add	x6, sp, #18, lsl #12            ; =73728
	add	x6, x6, #752
	ldrb	w10, [x6, w4, sxtw]
	and	w20, w10, #0x1
	fmov	s3, w20
	ubfx	w20, w10, #1, #1
	mov.b	v3[1], w20
	ubfx	w20, w10, #2, #1
	mov.b	v3[2], w20
	ubfx	w20, w10, #3, #1
	mov.b	v3[3], w20
	ubfx	w20, w10, #4, #1
	mov.b	v3[4], w20
	ubfx	w20, w10, #5, #1
	mov.b	v3[5], w20
	ubfx	w20, w10, #6, #1
	mov.b	v3[6], w20
	add	x20, sp, #18, lsl #12           ; =73728
	add	x20, x20, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x20, w4, sxtw]
	and	w21, w10, #0x1
	fmov	s4, w21
	ubfx	w21, w10, #1, #1
	mov.b	v4[1], w21
	ubfx	w21, w10, #2, #1
	mov.b	v4[2], w21
	ubfx	w21, w10, #3, #1
	mov.b	v4[3], w21
	ubfx	w21, w10, #4, #1
	mov.b	v4[4], w21
	ubfx	w21, w10, #5, #1
	mov.b	v4[5], w21
	ubfx	w21, w10, #6, #1
	mov.b	v4[6], w21
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	orr.8b	v5, v10, v4
	and.8b	v16, v1, v3
	eor.8b	v16, v16, v5
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	umaxv.8b	b16, v16
	fmov	w10, s16
	ands	w7, w19, w7
	csetm	w19, ne
	bics	w10, w7, w10
	csetm	w21, ne
	dup.8b	v16, w21
	bic.8b	v17, v5, v16
	dup.8b	v18, w19
	bit.8b	v4, v17, v18
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x20, w4, sxtw]
	bic.8b	v3, v3, v16
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x6, w4, sxtw]
	mov	w4, #-1                         ; =0xffffffff
	csinv	w4, w4, w5, eq
	and	w17, w4, w17
	dup.8b	v3, w7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v4, w10
	and.8b	v4, v4, v5
	str	q7, [sp, #4896]
	str	q6, [sp, #4912]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #800
	ldr	w10, [x10, x3]
	csel	w1, w10, w1, ne
	bit.8b	v10, v4, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	cmp	w7, #1
	b.ne	LBB0_841
; %bb.838:                              ; %convergence.cascade912
                                        ;   in Loop: Header=BB0_837 Depth=4
	cmp	w1, #0
	ccmp	w2, #6, #2, ne
	b.hi	LBB0_841
; %bb.839:                              ; %convergence.cascade912
                                        ;   in Loop: Header=BB0_837 Depth=4
	add	w2, w2, #1
	tst	w3, #0xff
	b.ne	LBB0_837
	b	LBB0_841
LBB0_840:                               ; %schedule.42.convergence.cascade.exit913_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
LBB0_841:                               ; %convergence.cascade.exit913
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
; %bb.842:                              ; %convergence.target.42.ready
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	b3, v10[6]
	mov.b	v3[4], v10[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q17, [sp, #176]                 ; 16-byte Folded Reload
	ldr	q0, [sp, #416]                  ; 16-byte Folded Reload
	bit.16b	v0, v17, v3
	str	q0, [sp, #416]                  ; 16-byte Folded Spill
	mov	b4, v10[4]
	mov.b	v4[4], v10[5]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	ldr	q0, [sp, #432]                  ; 16-byte Folded Reload
	bit.16b	v0, v17, v4
	str	q0, [sp, #432]                  ; 16-byte Folded Spill
	mov	b5, v10[2]
	mov.b	v5[4], v10[3]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	ldr	q0, [sp, #448]                  ; 16-byte Folded Reload
	bit.16b	v0, v17, v5
	str	q0, [sp, #448]                  ; 16-byte Folded Spill
	mov	b16, v10[0]
	mov.b	v16[4], v10[1]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	ldr	q0, [sp, #464]                  ; 16-byte Folded Reload
	bit.16b	v0, v17, v16
	str	q0, [sp, #464]                  ; 16-byte Folded Spill
Lloh1394:
	adrp	x10, lCPI0_19@PAGE
Lloh1395:
	ldr	q17, [x10, lCPI0_19@PAGEOFF]
	ldr	q0, [sp, #704]                  ; 16-byte Folded Reload
	bit.16b	v0, v17, v3
	str	q0, [sp, #704]                  ; 16-byte Folded Spill
Lloh1396:
	adrp	x10, lCPI0_18@PAGE
Lloh1397:
	ldr	q17, [x10, lCPI0_18@PAGEOFF]
	ldr	q0, [sp, #720]                  ; 16-byte Folded Reload
	bit.16b	v0, v17, v4
	str	q0, [sp, #720]                  ; 16-byte Folded Spill
Lloh1398:
	adrp	x10, lCPI0_17@PAGE
Lloh1399:
	ldr	q17, [x10, lCPI0_17@PAGEOFF]
	ldr	q0, [sp, #736]                  ; 16-byte Folded Reload
	bit.16b	v0, v17, v5
	str	q0, [sp, #736]                  ; 16-byte Folded Spill
Lloh1400:
	adrp	x10, lCPI0_16@PAGE
Lloh1401:
	ldr	q17, [x10, lCPI0_16@PAGEOFF]
	ldr	q0, [sp, #752]                  ; 16-byte Folded Reload
	bit.16b	v0, v17, v16
	str	q0, [sp, #752]                  ; 16-byte Folded Spill
	ldr	q0, [sp, #1456]                 ; 16-byte Folded Reload
	bic.16b	v0, v0, v3
	str	q0, [sp, #1456]                 ; 16-byte Folded Spill
	ldr	q0, [sp, #1472]                 ; 16-byte Folded Reload
	bic.16b	v0, v0, v4
	str	q0, [sp, #1472]                 ; 16-byte Folded Spill
	bic.16b	v21, v21, v5
	bic.16b	v20, v20, v16
	b	LBB0_850
LBB0_843:                               ; %cond.load5519
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d19
	ldr	s16, [x10]
	tbz	w2, #1, LBB0_799
LBB0_844:                               ; %cond.load5525
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v19[1]
	ld1.s	{ v16 }[1], [x10]
	tbz	w2, #2, LBB0_800
LBB0_845:                               ; %cond.load5531
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d4
	ld1.s	{ v16 }[2], [x10]
	tbz	w2, #3, LBB0_801
LBB0_846:                               ; %cond.load5537
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v4[1]
	ld1.s	{ v16 }[3], [x10]
	tbz	w2, #4, LBB0_802
LBB0_847:                               ; %cond.load5543
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d18
	ld1.s	{ v3 }[0], [x10]
	tbz	w2, #5, LBB0_803
LBB0_848:                               ; %cond.load5549
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v18[1]
	ld1.s	{ v3 }[1], [x10]
	tbz	w2, #6, LBB0_804
LBB0_849:                               ; %cond.load5555
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d17
	ld1.s	{ v3 }[2], [x10]
	tbnz	w2, #7, LBB0_805
	b	LBB0_806
LBB0_850:                               ; %schedule.43
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	mov	w2, #128                        ; =0x80
	dup.2d	v3, x2
	cmgt.2d	v4, v3, v21
	cmgt.2d	v5, v3, v20
	uzp1.4s	v4, v5, v4
	ldr	q0, [sp, #1472]                 ; 16-byte Folded Reload
	cmgt.2d	v5, v3, v0
	ldr	q17, [sp, #1456]                ; 16-byte Folded Reload
	cmgt.2d	v16, v3, v17
	uzp1.4s	v5, v5, v16
	uzp1.8h	v4, v4, v5
	xtn.8b	v4, v4
	and.8b	v11, v10, v4
	shl.8b	v4, v11, #7
	cmlt.8b	v4, v4, #0
	and.8b	v5, v4, v2
	addv.8b	b5, v5
	fmov	w2, s5
	umaxv.8b	b4, v4
	fmov	w4, s4
	tbz	w4, #0, LBB0_856
; %bb.851:                              ; %schedule.43
                                        ;   in Loop: Header=BB0_7 Depth=3
	cmge.2d	v4, v21, v3
	cmge.2d	v5, v20, v3
	uzp1.4s	v4, v5, v4
	cmge.2d	v5, v0, v3
	cmge.2d	v3, v17, v3
	uzp1.4s	v3, v5, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v12, v10, v3
	shl.8b	v3, v12, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w4, s3
	tst	w4, #0xff
	b.eq	LBB0_856
; %bb.852:                              ; %varying.divergent930
                                        ;   in Loop: Header=BB0_7 Depth=3
	subs	w10, w1, #1
	csel	w10, wzr, w10, lo
	and	w3, w17, #0xff
	lsr	w2, w3, w10
	tst	w2, #0x1
	str	q9, [sp, #4512]
	str	q8, [sp, #4528]
	and	x10, x10, #0x7
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #416
	ldr	w10, [x2, x10, lsl #2]
	ccmp	w1, #0, #4, ne
	ccmp	w10, #16, #0, ne
	cset	w2, ne
	cmp	w3, #255
	b.ne	LBB0_854
; %bb.853:                              ; %varying.divergent930
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #0, LBB0_1006
LBB0_854:                               ; %convergence.overflow.resume933
                                        ;   in Loop: Header=BB0_7 Depth=3
	mvn	w10, w17
	rbit	w10, w10
	clz	w10, w10
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w17
	csel	w4, wzr, w10, eq
	add	x3, sp, #18, lsl #12            ; =73728
	add	x3, x3, #752
	ldrb	w10, [x3, w4, uxtw]
	and	w5, w10, #0x1
	fmov	s3, w5
	ubfx	w5, w10, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w10, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w10, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w10, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w10, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w10, #6, #1
	mov.b	v3[6], w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x5, w4, uxtw]
	and	w6, w10, #0x1
	fmov	s4, w6
	ubfx	w6, w10, #1, #1
	mov.b	v4[1], w6
	ubfx	w6, w10, #2, #1
	mov.b	v4[2], w6
	ubfx	w6, w10, #3, #1
	mov.b	v4[3], w6
	ubfx	w6, w10, #4, #1
	mov.b	v4[4], w6
	ubfx	w6, w10, #5, #1
	mov.b	v4[5], w6
	ubfx	w6, w10, #6, #1
	mov.b	v4[6], w6
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	cmp	w2, #0
	csetm	w10, ne
	dup.8b	v5, w10
	bit.8b	v3, v10, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x3, w4, uxtw]
	bic.8b	v3, v4, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w4, uxtw]
	cmp	x0, #8
	b.hs	LBB0_1006
; %bb.855:                              ; %ready.overflow.resume935
                                        ;   in Loop: Header=BB0_7 Depth=3
	str	q7, [sp, #4480]
	str	q6, [sp, #4496]
	ubfiz	x10, x4, #2, #3
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #384
	ldr	w3, [x3, x10]
	cmp	w2, #0
	csel	w3, w1, w3, ne
	csinc	w1, w1, w4, eq
	str	q7, [sp, #4448]
	str	q6, [sp, #4464]
	add	x5, sp, #1, lsl #12             ; =4096
	add	x5, x5, #352
	str	w3, [x5, x10]
	ldr	q6, [sp, #4464]
	ldr	q7, [sp, #4448]
	str	q9, [sp, #4416]
	str	q8, [sp, #4432]
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #320
	ldr	w3, [x3, x10]
	mov	w5, #16                         ; =0x10
	csel	w3, w5, w3, ne
	str	q9, [sp, #4384]
	str	q8, [sp, #4400]
	add	x5, sp, #1, lsl #12             ; =4096
	add	x5, x5, #288
	str	w3, [x5, x10]
	mov	w3, #45                         ; =0x2d
	mov	w5, #44                         ; =0x2c
	ldr	q8, [sp, #4400]
	ldr	q9, [sp, #4384]
	b	LBB0_938
LBB0_856:                               ; %varying.coherent931
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_923
; %bb.857:                              ; %varying.coherent.true936
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
	tst	w3, #0xff
	b.eq	LBB0_5
LBB0_858:                               ; %schedule.44
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.16b	v5, v21
	mov.16b	v21, v15
	mov	b3, v10[0]
	mov.b	v3[4], v10[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v18, v3, #0
	and.16b	v16, v18, v20
	mov	b3, v10[2]
	mov.b	v3[4], v10[3]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v17, v3, #0
	mov	b3, v10[4]
	mov.b	v3[4], v10[5]
	mov.16b	v0, v5
	and.16b	v26, v17, v5
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v19, v3, #0
	ldr	q3, [sp, #1472]                 ; 16-byte Folded Reload
	and.16b	v31, v19, v3
	mov	b3, v10[6]
	mov.b	v3[4], v10[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v27, v3, #0
	ldr	q3, [sp, #1456]                 ; 16-byte Folded Reload
	and.16b	v3, v27, v3
	shl.8b	v11, v10, #7
	mov	w3, #32                         ; =0x20
	dup.2d	v5, x3
	and.16b	v4, v18, v5
	mvn.16b	v24, v18
	sub.2d	v4, v4, v24
	and.16b	v24, v17, v5
	mvn.16b	v25, v17
	sub.2d	v24, v24, v25
	and.16b	v25, v19, v5
	mvn.16b	v28, v19
	sub.2d	v25, v25, v28
	and.16b	v5, v27, v5
	mvn.16b	v28, v27
	sub.2d	v5, v5, v28
	mov.d	x3, v5[1]
	mov.d	x4, v3[1]
	sdiv	x22, x4, x3
	fmov	x4, d5
	fmov	x5, d3
	sdiv	x5, x5, x4
	mul	x23, x5, x4
	fmov	d5, x5
	mov.d	v5[1], x22
	mov.d	x5, v25[1]
	mov.d	x6, v31[1]
	sdiv	x24, x6, x5
	fmov	x7, d25
	fmov	x6, d31
	sdiv	x6, x6, x7
	mul	x25, x6, x7
	fmov	d25, x6
	mov.d	v25[1], x24
	mov.d	x6, v24[1]
	mov.d	x19, v26[1]
	sdiv	x26, x19, x6
	fmov	x20, d24
	fmov	x19, d26
	sdiv	x19, x19, x20
	mul	x27, x19, x20
	fmov	d24, x19
	mov.d	v24[1], x26
	mov.d	x19, v4[1]
	mov.d	x21, v16[1]
	sdiv	x28, x21, x19
	fmov	x21, d4
	fmov	x30, d16
	sdiv	x30, x30, x21
	mul	x10, x30, x21
	fmov	d4, x30
	mov.d	v4[1], x28
	mul	x22, x22, x3
	fmov	d28, x23
	mov.d	v28[1], x22
	mul	x22, x24, x5
	fmov	d29, x25
	mov.d	v29[1], x22
	cmlt.8b	v11, v11, #0
	mul	x22, x26, x6
	fmov	d30, x27
	mov.d	v30[1], x22
	mul	x22, x28, x19
	fmov	d12, x10
	mov.d	v12[1], x22
	sub.2d	v15, v16, v12
	sub.2d	v26, v26, v30
	sub.2d	v29, v31, v29
	sub.2d	v3, v3, v28
	shl.2d	v16, v4, #5
	shl.2d	v14, v24, #5
	shl.2d	v13, v25, #5
	shl.2d	v12, v5, #5
	add.2d	v4, v12, v3
	add.2d	v5, v13, v29
	add.2d	v24, v14, v26
	add.2d	v3, v16, v15
	and.16b	v3, v18, v3
	and.16b	v18, v19, v5
	and.16b	v19, v27, v4
	mov.d	x10, v19[1]
	sdiv	x22, x10, x3
	fmov	x10, d19
	sdiv	x10, x10, x4
	mul	x4, x10, x4
	fmov	d4, x10
	mov.d	v4[1], x22
	mov.d	x10, v18[1]
	sdiv	x10, x10, x5
	fmov	x23, d18
	sdiv	x23, x23, x7
	mul	x7, x23, x7
	fmov	d5, x23
	mov.d	v5[1], x10
	and.16b	v17, v17, v24
	mov.d	x23, v17[1]
	sdiv	x23, x23, x6
	fmov	x24, d17
	sdiv	x24, x24, x20
	mul	x20, x24, x20
	fmov	d24, x24
	mov.d	v24[1], x23
	mov.d	x24, v3[1]
	and.8b	v25, v11, v2
	fmov	x25, d3
	sdiv	x25, x25, x21
	mul	x21, x25, x21
	fmov	d26, x25
	sdiv	x24, x24, x19
	mov.d	v26[1], x24
	mul	x19, x24, x19
	fmov	d27, x21
	mov.d	v27[1], x19
	mul	x6, x23, x6
	fmov	d28, x20
	mov.d	v28[1], x6
	mul	x10, x10, x5
	fmov	d29, x7
	mov.d	v29[1], x10
	mul	x10, x22, x3
	fmov	d30, x4
	mov.d	v30[1], x10
	addv.8b	b11, v25
	sub.2d	v19, v19, v30
	sub.2d	v18, v18, v29
	fmov	w3, s11
	sub.2d	v17, v17, v28
	sub.2d	v3, v3, v27
	ldr	q25, [sp, #16512]
	ldr	q28, [sp, #16528]
	ldr	q29, [sp, #16544]
	ldr	q30, [sp, #16560]
	ldr	q15, [sp, #16624]
	ldr	q22, [sp, #16608]
	ldr	q23, [sp, #16592]
	shl.2d	v31, v26, #10
	shl.2d	v24, v24, #10
	shl.2d	v5, v5, #10
	shl.2d	v4, v4, #10
	shl.2d	v3, v3, #5
	shl.2d	v17, v17, #5
	shl.2d	v18, v18, #5
	shl.2d	v19, v19, #5
	add.2d	v19, v4, v19
	add.2d	v26, v5, v18
	ldr	q5, [sp, #16576]
	add.2d	v27, v24, v17
	add.2d	v31, v31, v3
	add.2d	v3, v30, v15
	add.2d	v3, v3, v19
	add.2d	v4, v29, v22
	add.2d	v4, v4, v26
	add.2d	v17, v28, v23
	add.2d	v15, v17, v27
	add.2d	v5, v25, v5
	add.2d	v30, v5, v31
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w3, #0, LBB0_895
; %bb.859:                              ; %else4933
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #1, LBB0_896
LBB0_860:                               ; %else4939
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #2, LBB0_897
LBB0_861:                               ; %else4945
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #3, LBB0_898
LBB0_862:                               ; %else4951
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.16b	v15, v21
	mov.16b	v21, v0
	tbnz	w3, #4, LBB0_899
LBB0_863:                               ; %else4957
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #5, LBB0_900
LBB0_864:                               ; %else4963
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #6, LBB0_901
LBB0_865:                               ; %else4969
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w3, #7, LBB0_867
LBB0_866:                               ; %cond.load4971
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v18 }[3], [x10]
LBB0_867:                               ; %else4975
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q3, [sp, #16304]
	ldr	q4, [sp, #16288]
	ldr	q5, [sp, #16272]
	ldr	q22, [sp, #16256]
	ldr	q23, [sp, #16320]
	ldr	q24, [sp, #16336]
	ldr	q25, [sp, #16352]
	ldr	q28, [sp, #16368]
	add.2d	v22, v22, v23
	add.2d	v31, v22, v31
	add.2d	v5, v5, v24
	add.2d	v27, v5, v27
	add.2d	v4, v4, v25
	add.2d	v4, v4, v26
	add.2d	v3, v3, v28
	add.2d	v26, v3, v19
	fmov	w3, s11
	movi.2d	v3, #0000000000000000
	movi.2d	v19, #0000000000000000
	tbnz	w3, #0, LBB0_902
; %bb.868:                              ; %else4982
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #1, LBB0_903
LBB0_869:                               ; %else4988
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #2, LBB0_904
LBB0_870:                               ; %else4994
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #3, LBB0_905
LBB0_871:                               ; %else5000
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #4, LBB0_906
LBB0_872:                               ; %else5006
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #5, LBB0_907
LBB0_873:                               ; %else5012
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #6, LBB0_908
LBB0_874:                               ; %else5018
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w3, #7, LBB0_876
LBB0_875:                               ; %cond.load5020
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v26[1]
	ld1.s	{ v19 }[3], [x10]
LBB0_876:                               ; %else5024
                                        ;   in Loop: Header=BB0_7 Depth=3
	fadd.4s	v17, v17, v3
	fadd.4s	v18, v18, v19
	ldr	q3, [sp, #18736]
	ldr	q4, [sp, #18720]
	ldr	q5, [sp, #18704]
	ldr	q19, [sp, #18688]
	ldr	q22, [sp, #18752]
	ldr	q23, [sp, #18768]
	ldr	q24, [sp, #18784]
	ldr	q25, [sp, #18800]
	add.2d	v19, v19, v22
	add.2d	v27, v19, v16
	add.2d	v5, v5, v23
	add.2d	v26, v5, v14
	add.2d	v4, v4, v24
	add.2d	v4, v4, v13
	add.2d	v3, v3, v25
	add.2d	v19, v3, v12
	fmov	w3, s11
	movi.2d	v3, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbnz	w3, #0, LBB0_909
; %bb.877:                              ; %else5031
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #1, LBB0_910
LBB0_878:                               ; %else5037
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #2, LBB0_911
LBB0_879:                               ; %else5043
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #3, LBB0_912
LBB0_880:                               ; %else5049
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #4, LBB0_913
LBB0_881:                               ; %else5055
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #5, LBB0_914
LBB0_882:                               ; %else5061
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #6, LBB0_915
LBB0_883:                               ; %else5067
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w3, #7, LBB0_885
LBB0_884:                               ; %cond.load5069
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v19[1]
	ld1.s	{ v16 }[3], [x10]
LBB0_885:                               ; %else5073
                                        ;   in Loop: Header=BB0_7 Depth=3
	fadd.4s	v17, v17, v3
	fadd.4s	v3, v18, v16
	shl.2d	v4, v20, #5
	shl.2d	v5, v21, #5
	ldr	q0, [sp, #1472]                 ; 16-byte Folded Reload
	shl.2d	v16, v0, #5
	ldr	q0, [sp, #1456]                 ; 16-byte Folded Reload
	shl.2d	v22, v0, #5
	ldr	q0, [sp, #464]                  ; 16-byte Folded Reload
	ldr	q18, [sp, #752]                 ; 16-byte Folded Reload
	add.2d	v18, v0, v18
	add.2d	v19, v18, v4
	ldr	q0, [sp, #448]                  ; 16-byte Folded Reload
	ldr	q4, [sp, #736]                  ; 16-byte Folded Reload
	add.2d	v4, v0, v4
	add.2d	v18, v4, v5
	ldp	q0, q5, [sp, #416]              ; 32-byte Folded Reload
	ldr	q4, [sp, #720]                  ; 16-byte Folded Reload
	add.2d	v4, v5, v4
	add.2d	v16, v4, v16
	ldr	q4, [sp, #704]                  ; 16-byte Folded Reload
	add.2d	v4, v0, v4
	fmov	w3, s11
	add.2d	v4, v4, v22
	tbnz	w3, #0, LBB0_916
; %bb.886:                              ; %else5079
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #1, LBB0_917
LBB0_887:                               ; %else5083
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #2, LBB0_918
LBB0_888:                               ; %else5087
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #3, LBB0_919
LBB0_889:                               ; %else5091
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #4, LBB0_920
LBB0_890:                               ; %else5095
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #5, LBB0_921
LBB0_891:                               ; %else5099
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #6, LBB0_922
LBB0_892:                               ; %else5103
                                        ;   in Loop: Header=BB0_7 Depth=3
	ldr	q0, [sp, #1472]                 ; 16-byte Folded Reload
	ldr	q5, [sp, #1456]                 ; 16-byte Folded Reload
	tbz	w3, #7, LBB0_894
LBB0_893:                               ; %cond.store5104
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v4[1]
	st1.s	{ v3 }[3], [x10]
LBB0_894:                               ; %else5107
                                        ;   in Loop: Header=BB0_7 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v10, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v4, v3, #0
	ushll2.4s	v3, v3, #0
	uaddw2.2d	v5, v5, v3
	str	q5, [sp, #1456]                 ; 16-byte Folded Spill
	uaddw.2d	v0, v0, v3
	str	q0, [sp, #1472]                 ; 16-byte Folded Spill
	uaddw2.2d	v21, v21, v4
	uaddw.2d	v20, v20, v4
	tbz	w2, #0, LBB0_850
	b	LBB0_5
LBB0_895:                               ; %cond.load4929
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d30
	ldr	s17, [x10]
	tbz	w3, #1, LBB0_860
LBB0_896:                               ; %cond.load4935
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v30[1]
	ld1.s	{ v17 }[1], [x10]
	tbz	w3, #2, LBB0_861
LBB0_897:                               ; %cond.load4941
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d15
	ld1.s	{ v17 }[2], [x10]
	tbz	w3, #3, LBB0_862
LBB0_898:                               ; %cond.load4947
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v15[1]
	ld1.s	{ v17 }[3], [x10]
	mov.16b	v15, v21
	mov.16b	v21, v0
	tbz	w3, #4, LBB0_863
LBB0_899:                               ; %cond.load4953
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d4
	ld1.s	{ v18 }[0], [x10]
	tbz	w3, #5, LBB0_864
LBB0_900:                               ; %cond.load4959
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v4[1]
	ld1.s	{ v18 }[1], [x10]
	tbz	w3, #6, LBB0_865
LBB0_901:                               ; %cond.load4965
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d3
	ld1.s	{ v18 }[2], [x10]
	tbnz	w3, #7, LBB0_866
	b	LBB0_867
LBB0_902:                               ; %cond.load4978
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d31
	ldr	s3, [x10]
	tbz	w3, #1, LBB0_869
LBB0_903:                               ; %cond.load4984
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v31[1]
	ld1.s	{ v3 }[1], [x10]
	tbz	w3, #2, LBB0_870
LBB0_904:                               ; %cond.load4990
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d27
	ld1.s	{ v3 }[2], [x10]
	tbz	w3, #3, LBB0_871
LBB0_905:                               ; %cond.load4996
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v27[1]
	ld1.s	{ v3 }[3], [x10]
	tbz	w3, #4, LBB0_872
LBB0_906:                               ; %cond.load5002
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d4
	ld1.s	{ v19 }[0], [x10]
	tbz	w3, #5, LBB0_873
LBB0_907:                               ; %cond.load5008
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v4[1]
	ld1.s	{ v19 }[1], [x10]
	tbz	w3, #6, LBB0_874
LBB0_908:                               ; %cond.load5014
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d26
	ld1.s	{ v19 }[2], [x10]
	tbnz	w3, #7, LBB0_875
	b	LBB0_876
LBB0_909:                               ; %cond.load5027
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d27
	ldr	s3, [x10]
	tbz	w3, #1, LBB0_878
LBB0_910:                               ; %cond.load5033
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v27[1]
	ld1.s	{ v3 }[1], [x10]
	tbz	w3, #2, LBB0_879
LBB0_911:                               ; %cond.load5039
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d26
	ld1.s	{ v3 }[2], [x10]
	tbz	w3, #3, LBB0_880
LBB0_912:                               ; %cond.load5045
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v26[1]
	ld1.s	{ v3 }[3], [x10]
	tbz	w3, #4, LBB0_881
LBB0_913:                               ; %cond.load5051
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d4
	ld1.s	{ v16 }[0], [x10]
	tbz	w3, #5, LBB0_882
LBB0_914:                               ; %cond.load5057
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v4[1]
	ld1.s	{ v16 }[1], [x10]
	tbz	w3, #6, LBB0_883
LBB0_915:                               ; %cond.load5063
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d19
	ld1.s	{ v16 }[2], [x10]
	tbnz	w3, #7, LBB0_884
	b	LBB0_885
LBB0_916:                               ; %cond.store5076
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d19
	str	s17, [x10]
	tbz	w3, #1, LBB0_887
LBB0_917:                               ; %cond.store5080
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v19[1]
	st1.s	{ v17 }[1], [x10]
	tbz	w3, #2, LBB0_888
LBB0_918:                               ; %cond.store5084
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d18
	st1.s	{ v17 }[2], [x10]
	tbz	w3, #3, LBB0_889
LBB0_919:                               ; %cond.store5088
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v18[1]
	st1.s	{ v17 }[3], [x10]
	tbz	w3, #4, LBB0_890
LBB0_920:                               ; %cond.store5092
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d16
	str	s3, [x10]
	tbz	w3, #5, LBB0_891
LBB0_921:                               ; %cond.store5096
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v16[1]
	st1.s	{ v3 }[1], [x10]
	tbz	w3, #6, LBB0_892
LBB0_922:                               ; %cond.store5100
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d4
	st1.s	{ v3 }[2], [x10]
	ldr	q0, [sp, #1472]                 ; 16-byte Folded Reload
	ldr	q5, [sp, #1456]                 ; 16-byte Folded Reload
	tbnz	w3, #7, LBB0_893
	b	LBB0_894
LBB0_923:                               ; %varying.coherent.false937
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
LBB0_924:                               ; %schedule.45
                                        ;   in Loop: Header=BB0_7 Depth=3
	cbz	w1, LBB0_929
; %bb.925:                              ; %convergence.cascade946.preheader
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
LBB0_926:                               ; %convergence.cascade946
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_7 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w10, s4
	umaxv.8b	b3, v3
	fmov	w6, s3
	sub	w3, w1, #1
	tst	w10, #0xff
	csel	w4, w3, wzr, ne
	mov	w10, #1                         ; =0x1
	lsl	w5, w10, w4
	and	w10, w5, w17
	tst	w10, #0xff
	cset	w10, ne
	str	q9, [sp, #4864]
	str	q8, [sp, #4880]
	ubfiz	x3, x4, #2, #3
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #768
	ldr	w7, [x7, x3]
	cmp	w7, #16
	cset	w7, eq
	and	w19, w10, w6
	add	x6, sp, #18, lsl #12            ; =73728
	add	x6, x6, #752
	ldrb	w10, [x6, w4, sxtw]
	and	w20, w10, #0x1
	fmov	s3, w20
	ubfx	w20, w10, #1, #1
	mov.b	v3[1], w20
	ubfx	w20, w10, #2, #1
	mov.b	v3[2], w20
	ubfx	w20, w10, #3, #1
	mov.b	v3[3], w20
	ubfx	w20, w10, #4, #1
	mov.b	v3[4], w20
	ubfx	w20, w10, #5, #1
	mov.b	v3[5], w20
	ubfx	w20, w10, #6, #1
	mov.b	v3[6], w20
	add	x20, sp, #18, lsl #12           ; =73728
	add	x20, x20, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x20, w4, sxtw]
	and	w21, w10, #0x1
	fmov	s4, w21
	ubfx	w21, w10, #1, #1
	mov.b	v4[1], w21
	ubfx	w21, w10, #2, #1
	mov.b	v4[2], w21
	ubfx	w21, w10, #3, #1
	mov.b	v4[3], w21
	ubfx	w21, w10, #4, #1
	mov.b	v4[4], w21
	ubfx	w21, w10, #5, #1
	mov.b	v4[5], w21
	ubfx	w21, w10, #6, #1
	mov.b	v4[6], w21
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	orr.8b	v5, v10, v4
	and.8b	v16, v1, v3
	eor.8b	v16, v16, v5
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	umaxv.8b	b16, v16
	fmov	w10, s16
	ands	w7, w19, w7
	csetm	w19, ne
	bics	w10, w7, w10
	csetm	w21, ne
	dup.8b	v16, w21
	bic.8b	v17, v5, v16
	dup.8b	v18, w19
	bit.8b	v4, v17, v18
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x20, w4, sxtw]
	bic.8b	v3, v3, v16
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x6, w4, sxtw]
	mov	w4, #-1                         ; =0xffffffff
	csinv	w4, w4, w5, eq
	and	w17, w4, w17
	dup.8b	v3, w7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v4, w10
	and.8b	v4, v4, v5
	str	q7, [sp, #4832]
	str	q6, [sp, #4848]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #736
	ldr	w10, [x10, x3]
	csel	w1, w10, w1, ne
	bit.8b	v10, v4, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	cmp	w7, #1
	b.ne	LBB0_930
; %bb.927:                              ; %convergence.cascade946
                                        ;   in Loop: Header=BB0_926 Depth=4
	cmp	w1, #0
	ccmp	w2, #6, #2, ne
	b.hi	LBB0_930
; %bb.928:                              ; %convergence.cascade946
                                        ;   in Loop: Header=BB0_926 Depth=4
	add	w2, w2, #1
	tst	w3, #0xff
	b.ne	LBB0_926
	b	LBB0_930
LBB0_929:                               ; %schedule.45.convergence.cascade.exit947_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
LBB0_930:                               ; %convergence.cascade.exit947
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
; %bb.931:                              ; %convergence.target.45.ready
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	b3, v10[6]
	mov.b	v3[4], v10[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmge.2d	v3, v3, #0
	ldp	q4, q5, [sp, #864]              ; 32-byte Folded Reload
	and.16b	v0, v3, v4
	mov	b3, v10[4]
	mov.b	v3[4], v10[5]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmge.2d	v3, v3, #0
	mov	b4, v10[2]
	mov.b	v4[4], v10[3]
	and.16b	v5, v3, v5
	stp	q0, q5, [sp, #864]              ; 32-byte Folded Spill
	ushll.2d	v3, v4, #0
	shl.2d	v3, v3, #63
	cmge.2d	v3, v3, #0
	and.16b	v15, v3, v15
	mov	b3, v10[0]
	mov.b	v3[4], v10[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmge.2d	v3, v3, #0
	ldr	q0, [sp, #848]                  ; 16-byte Folded Reload
	and.16b	v0, v3, v0
	str	q0, [sp, #848]                  ; 16-byte Folded Spill
LBB0_932:                               ; %schedule.46
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	mov	w10, #128                       ; =0x80
	dup.2d	v3, x10
	cmgt.2d	v4, v3, v15
	ldp	q0, q18, [sp, #848]             ; 32-byte Folded Reload
	cmgt.2d	v5, v3, v0
	uzp1.4s	v4, v5, v4
	ldr	q17, [sp, #880]                 ; 16-byte Folded Reload
	cmgt.2d	v5, v3, v17
	cmgt.2d	v16, v3, v18
	uzp1.4s	v5, v5, v16
	uzp1.8h	v4, v4, v5
	xtn.8b	v4, v4
	and.8b	v11, v10, v4
	shl.8b	v4, v11, #7
	cmlt.8b	v4, v4, #0
	and.8b	v5, v4, v2
	addv.8b	b5, v5
	fmov	w2, s5
	umaxv.8b	b4, v4
	fmov	w10, s4
	tbz	w10, #0, LBB0_940
; %bb.933:                              ; %schedule.46
                                        ;   in Loop: Header=BB0_7 Depth=3
	cmge.2d	v4, v15, v3
	cmge.2d	v5, v0, v3
	uzp1.4s	v4, v5, v4
	cmge.2d	v5, v17, v3
	cmge.2d	v3, v18, v3
	uzp1.4s	v3, v5, v3
	uzp1.8h	v3, v4, v3
	xtn.8b	v3, v3
	and.8b	v12, v10, v3
	shl.8b	v3, v12, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w10, s3
	tst	w10, #0xff
	b.eq	LBB0_940
; %bb.934:                              ; %varying.divergent964
                                        ;   in Loop: Header=BB0_7 Depth=3
	subs	w10, w1, #1
	csel	w10, wzr, w10, lo
	and	w3, w17, #0xff
	lsr	w2, w3, w10
	tst	w2, #0x1
	str	q9, [sp, #4672]
	str	q8, [sp, #4688]
	and	x10, x10, #0x7
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #576
	ldr	w10, [x2, x10, lsl #2]
	ccmp	w1, #0, #4, ne
	ccmp	w10, #17, #0, ne
	cset	w2, ne
	cmp	w3, #255
	b.ne	LBB0_936
; %bb.935:                              ; %varying.divergent964
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w2, #0, LBB0_1006
LBB0_936:                               ; %convergence.overflow.resume967
                                        ;   in Loop: Header=BB0_7 Depth=3
	mvn	w10, w17
	rbit	w10, w10
	clz	w10, w10
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w17
	csel	w4, wzr, w10, eq
	add	x3, sp, #18, lsl #12            ; =73728
	add	x3, x3, #752
	ldrb	w10, [x3, w4, uxtw]
	and	w5, w10, #0x1
	fmov	s3, w5
	ubfx	w5, w10, #1, #1
	mov.b	v3[1], w5
	ubfx	w5, w10, #2, #1
	mov.b	v3[2], w5
	ubfx	w5, w10, #3, #1
	mov.b	v3[3], w5
	ubfx	w5, w10, #4, #1
	mov.b	v3[4], w5
	ubfx	w5, w10, #5, #1
	mov.b	v3[5], w5
	ubfx	w5, w10, #6, #1
	mov.b	v3[6], w5
	add	x5, sp, #18, lsl #12            ; =73728
	add	x5, x5, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x5, w4, uxtw]
	and	w6, w10, #0x1
	fmov	s4, w6
	ubfx	w6, w10, #1, #1
	mov.b	v4[1], w6
	ubfx	w6, w10, #2, #1
	mov.b	v4[2], w6
	ubfx	w6, w10, #3, #1
	mov.b	v4[3], w6
	ubfx	w6, w10, #4, #1
	mov.b	v4[4], w6
	ubfx	w6, w10, #5, #1
	mov.b	v4[5], w6
	ubfx	w6, w10, #6, #1
	mov.b	v4[6], w6
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	cmp	w2, #0
	csetm	w10, ne
	dup.8b	v5, w10
	bit.8b	v3, v10, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x3, w4, uxtw]
	bic.8b	v3, v4, v5
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x5, w4, uxtw]
	cmp	x0, #8
	b.hs	LBB0_1006
; %bb.937:                              ; %ready.overflow.resume969
                                        ;   in Loop: Header=BB0_7 Depth=3
	str	q7, [sp, #4640]
	str	q6, [sp, #4656]
	ubfiz	x10, x4, #2, #3
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #544
	ldr	w3, [x3, x10]
	cmp	w2, #0
	csel	w3, w1, w3, ne
	csinc	w1, w1, w4, eq
	str	q7, [sp, #4608]
	str	q6, [sp, #4624]
	add	x5, sp, #1, lsl #12             ; =4096
	add	x5, x5, #512
	str	w3, [x5, x10]
	ldr	q6, [sp, #4624]
	ldr	q7, [sp, #4608]
	str	q9, [sp, #4576]
	str	q8, [sp, #4592]
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #480
	ldr	w3, [x3, x10]
	mov	w5, #17                         ; =0x11
	csel	w3, w5, w3, ne
	str	q9, [sp, #4544]
	str	q8, [sp, #4560]
	add	x5, sp, #1, lsl #12             ; =4096
	add	x5, x5, #448
	str	w3, [x5, x10]
	mov	w3, #48                         ; =0x30
	mov	w5, #47                         ; =0x2f
	ldr	q8, [sp, #4560]
	ldr	q9, [sp, #4544]
LBB0_938:                               ; %scheduler.dispatch.route.backedge
                                        ;   in Loop: Header=BB0_7 Depth=3
                                        ; kill: def $w4 killed $w4 killed $x4 def $x4
LBB0_939:                               ; %scheduler.dispatch.route.backedge
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w10, #1                         ; =0x1
	lsl	w10, w10, w4
	cmp	w2, #0
	csel	w10, w10, wzr, ne
	add	x2, sp, #18, lsl #12            ; =73728
	add	x2, x2, #824
	shl.8b	v3, v11, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x2, x0]
	add	x2, sp, #18, lsl #12            ; =73728
	add	x2, x2, #792
	str	w5, [x2, x0, lsl #2]
	orr	w17, w10, w17
	add	x10, sp, #18, lsl #12           ; =73728
	add	x10, x10, #760
	str	w1, [x10, x0, lsl #2]
	add	x0, x0, #1
	fmov	d10, d12
	cmp	w3, #49
	b.ls	LBB0_7
	b	LBB0_1006
LBB0_940:                               ; %varying.coherent965
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w2, #0xff
	b.eq	LBB0_975
; %bb.941:                              ; %varying.coherent.true970
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
	tst	w3, #0xff
	b.eq	LBB0_5
LBB0_942:                               ; %schedule.47
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.16b	v0, v21
	mov.16b	v21, v20
	mov	b3, v10[6]
	mov.b	v3[4], v10[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v4, v3, #0
	ldp	q30, q29, [sp, #864]            ; 32-byte Folded Reload
	and.16b	v16, v4, v30
	mov	b3, v10[4]
	mov.b	v3[4], v10[5]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v5, v3, #0
	and.16b	v18, v5, v29
	mov	b3, v10[2]
	mov.b	v3[4], v10[3]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v22, v3, #0
	and.16b	v19, v22, v15
	mov	b3, v10[0]
	mov.b	v3[4], v10[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v23, v3, #0
	ldr	q20, [sp, #848]                 ; 16-byte Folded Reload
	and.16b	v3, v23, v20
	shl.8b	v17, v10, #7
	cmlt.8b	v17, v17, #0
	and.8b	v17, v17, v2
	mov	w10, #32                        ; =0x20
	dup.2d	v24, x10
	and.16b	v25, v4, v24
	mvn.16b	v4, v4
	sub.2d	v26, v25, v4
	and.16b	v4, v5, v24
	mvn.16b	v5, v5
	sub.2d	v4, v4, v5
	and.16b	v5, v22, v24
	and.16b	v24, v23, v24
	mvn.16b	v23, v23
	sub.2d	v23, v24, v23
	mov.d	x3, v23[1]
	mov.d	x10, v3[1]
	mvn.16b	v22, v22
	sdiv	x4, x10, x3
	sub.2d	v5, v5, v22
	fmov	x10, d23
	fmov	x5, d3
	sdiv	x5, x5, x10
	mul	x10, x5, x10
	fmov	d22, x5
	mov.d	v22[1], x4
	mov.d	x5, v5[1]
	mov.d	x6, v19[1]
	sdiv	x6, x6, x5
	fmov	x7, d5
	fmov	x19, d19
	sdiv	x19, x19, x7
	mul	x7, x19, x7
	fmov	d5, x19
	mov.d	v5[1], x6
	mov.d	x19, v4[1]
	mov.d	x20, v18[1]
	sdiv	x20, x20, x19
	fmov	x21, d4
	fmov	x22, d18
	sdiv	x22, x22, x21
	mul	x21, x22, x21
	fmov	d4, x22
	mov.d	v4[1], x20
	mov.d	x22, v26[1]
	mov.d	x23, v16[1]
	fmov	x24, d26
	fmov	x25, d16
	sdiv	x25, x25, x24
	mul	x24, x25, x24
	fmov	d23, x25
	sdiv	x23, x23, x22
	mov.d	v23[1], x23
	mul	x22, x23, x22
	fmov	d24, x24
	mov.d	v24[1], x22
	mul	x19, x20, x19
	fmov	d25, x21
	mov.d	v25[1], x19
	addv.8b	b17, v17
	mul	x5, x6, x5
	fmov	d26, x7
	mov.d	v26[1], x5
	mul	x3, x4, x3
	fmov	d27, x10
	mov.d	v27[1], x3
	sub.2d	v3, v3, v27
	sub.2d	v28, v19, v26
	sub.2d	v18, v18, v25
	sub.2d	v16, v16, v24
	ldr	q24, [sp, #18944]
	ldr	q25, [sp, #18960]
	ldr	q26, [sp, #18976]
	ldr	q19, [sp, #18992]
	add.2d	v19, v19, v23
	add.2d	v27, v26, v4
	add.2d	v11, v25, v5
	add.2d	v13, v24, v22
	dup.2d	v4, x16
	add.2d	v26, v16, v4
	add.2d	v31, v18, v4
	add.2d	v12, v28, v4
	add.2d	v14, v3, v4
	shl.2d	v3, v20, #5
	mov.16b	v20, v15
	shl.2d	v4, v15, #5
	fmov	w3, s17
	shl.2d	v5, v29, #5
	shl.2d	v16, v30, #5
	ldr	q18, [sp, #464]                 ; 16-byte Folded Reload
	ldr	q22, [sp, #752]                 ; 16-byte Folded Reload
	add.2d	v18, v18, v22
	add.2d	v30, v18, v3
	ldr	q3, [sp, #448]                  ; 16-byte Folded Reload
	ldr	q18, [sp, #736]                 ; 16-byte Folded Reload
	add.2d	v3, v3, v18
	add.2d	v15, v3, v4
	ldr	q3, [sp, #432]                  ; 16-byte Folded Reload
	ldr	q4, [sp, #720]                  ; 16-byte Folded Reload
	add.2d	v3, v3, v4
	add.2d	v4, v3, v5
	ldr	q3, [sp, #416]                  ; 16-byte Folded Reload
	ldr	q5, [sp, #704]                  ; 16-byte Folded Reload
	add.2d	v3, v3, v5
	add.2d	v3, v3, v16
	movi.2d	v18, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbnz	w3, #0, LBB0_961
; %bb.943:                              ; %else5113
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #1, LBB0_962
LBB0_944:                               ; %else5119
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #2, LBB0_963
LBB0_945:                               ; %else5125
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #3, LBB0_964
LBB0_946:                               ; %else5131
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.16b	v15, v20
	mov.16b	v20, v21
	tbnz	w3, #4, LBB0_965
LBB0_947:                               ; %else5137
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.16b	v21, v0
	tbnz	w3, #5, LBB0_966
LBB0_948:                               ; %else5143
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #6, LBB0_967
LBB0_949:                               ; %else5149
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w3, #7, LBB0_951
LBB0_950:                               ; %cond.load5151
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v16 }[3], [x10]
LBB0_951:                               ; %else5155
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.2d	v3, v13, #7
	shl.2d	v4, v11, #7
	shl.2d	v5, v27, #7
	shl.2d	v22, v19, #7
	shl.2d	v19, v14, #2
	shl.2d	v23, v12, #2
	shl.2d	v24, v31, #2
	shl.2d	v25, v26, #2
	dup.2d	v27, x11
	add.2d	v3, v27, v3
	add.2d	v26, v3, v19
	add.2d	v3, v27, v4
	add.2d	v19, v3, v23
	add.2d	v3, v27, v5
	add.2d	v4, v3, v24
	add.2d	v3, v27, v22
	add.2d	v3, v3, v25
	fmov	w3, s17
	tbnz	w3, #0, LBB0_968
; %bb.952:                              ; %else5161
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #1, LBB0_969
LBB0_953:                               ; %else5165
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #2, LBB0_970
LBB0_954:                               ; %else5169
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #3, LBB0_971
LBB0_955:                               ; %else5173
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #4, LBB0_972
LBB0_956:                               ; %else5177
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #5, LBB0_973
LBB0_957:                               ; %else5181
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbnz	w3, #6, LBB0_974
LBB0_958:                               ; %else5185
                                        ;   in Loop: Header=BB0_7 Depth=3
	tbz	w3, #7, LBB0_960
LBB0_959:                               ; %cond.store5186
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v3[1]
	st1.s	{ v16 }[3], [x10]
LBB0_960:                               ; %else5189
                                        ;   in Loop: Header=BB0_7 Depth=3
	movi.8b	v3, #1
	and.8b	v3, v10, v3
	ushll.8h	v3, v3, #0
	ushll.4s	v4, v3, #0
	ushll2.4s	v3, v3, #0
	ldp	q0, q5, [sp, #848]              ; 32-byte Folded Reload
	uaddw2.2d	v5, v5, v3
	str	q5, [sp, #864]                  ; 16-byte Folded Spill
	ldr	q5, [sp, #880]                  ; 16-byte Folded Reload
	uaddw.2d	v5, v5, v3
	str	q5, [sp, #880]                  ; 16-byte Folded Spill
	uaddw2.2d	v15, v15, v4
	uaddw.2d	v0, v0, v4
	str	q0, [sp, #848]                  ; 16-byte Folded Spill
	tbz	w2, #0, LBB0_932
	b	LBB0_5
LBB0_961:                               ; %cond.load5109
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d30
	ldr	s18, [x10]
	tbz	w3, #1, LBB0_944
LBB0_962:                               ; %cond.load5115
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v30[1]
	ld1.s	{ v18 }[1], [x10]
	tbz	w3, #2, LBB0_945
LBB0_963:                               ; %cond.load5121
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d15
	ld1.s	{ v18 }[2], [x10]
	tbz	w3, #3, LBB0_946
LBB0_964:                               ; %cond.load5127
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v15[1]
	ld1.s	{ v18 }[3], [x10]
	mov.16b	v15, v20
	mov.16b	v20, v21
	tbz	w3, #4, LBB0_947
LBB0_965:                               ; %cond.load5133
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d4
	ld1.s	{ v16 }[0], [x10]
	mov.16b	v21, v0
	tbz	w3, #5, LBB0_948
LBB0_966:                               ; %cond.load5139
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v4[1]
	ld1.s	{ v16 }[1], [x10]
	tbz	w3, #6, LBB0_949
LBB0_967:                               ; %cond.load5145
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d3
	ld1.s	{ v16 }[2], [x10]
	tbnz	w3, #7, LBB0_950
	b	LBB0_951
LBB0_968:                               ; %cond.store5158
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d26
	str	s18, [x10]
	tbz	w3, #1, LBB0_953
LBB0_969:                               ; %cond.store5162
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v26[1]
	st1.s	{ v18 }[1], [x10]
	tbz	w3, #2, LBB0_954
LBB0_970:                               ; %cond.store5166
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d19
	st1.s	{ v18 }[2], [x10]
	tbz	w3, #3, LBB0_955
LBB0_971:                               ; %cond.store5170
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v19[1]
	st1.s	{ v18 }[3], [x10]
	tbz	w3, #4, LBB0_956
LBB0_972:                               ; %cond.store5174
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d4
	str	s16, [x10]
	tbz	w3, #5, LBB0_957
LBB0_973:                               ; %cond.store5178
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov.d	x10, v4[1]
	st1.s	{ v16 }[1], [x10]
	tbz	w3, #6, LBB0_958
LBB0_974:                               ; %cond.store5182
                                        ;   in Loop: Header=BB0_7 Depth=3
	fmov	x10, d3
	st1.s	{ v16 }[2], [x10]
	tbnz	w3, #7, LBB0_959
	b	LBB0_960
LBB0_975:                               ; %varying.coherent.false971
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
LBB0_976:                               ; %schedule.48
                                        ;   in Loop: Header=BB0_7 Depth=3
	cbz	w1, LBB0_981
; %bb.977:                              ; %convergence.cascade981.preheader
                                        ;   in Loop: Header=BB0_7 Depth=3
	mov	w2, #0                          ; =0x0
LBB0_978:                               ; %convergence.cascade981
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ;       Parent Loop BB0_7 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w10, s4
	umaxv.8b	b3, v3
	fmov	w6, s3
	sub	w3, w1, #1
	tst	w10, #0xff
	csel	w4, w3, wzr, ne
	mov	w10, #1                         ; =0x1
	lsl	w5, w10, w4
	and	w10, w5, w17
	tst	w10, #0xff
	cset	w10, ne
	str	q9, [sp, #4800]
	str	q8, [sp, #4816]
	ubfiz	x3, x4, #2, #3
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #704
	ldr	w7, [x7, x3]
	cmp	w7, #17
	cset	w7, eq
	and	w19, w10, w6
	add	x6, sp, #18, lsl #12            ; =73728
	add	x6, x6, #752
	ldrb	w10, [x6, w4, sxtw]
	and	w20, w10, #0x1
	fmov	s3, w20
	ubfx	w20, w10, #1, #1
	mov.b	v3[1], w20
	ubfx	w20, w10, #2, #1
	mov.b	v3[2], w20
	ubfx	w20, w10, #3, #1
	mov.b	v3[3], w20
	ubfx	w20, w10, #4, #1
	mov.b	v3[4], w20
	ubfx	w20, w10, #5, #1
	mov.b	v3[5], w20
	ubfx	w20, w10, #6, #1
	mov.b	v3[6], w20
	add	x20, sp, #18, lsl #12           ; =73728
	add	x20, x20, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x20, w4, sxtw]
	and	w21, w10, #0x1
	fmov	s4, w21
	ubfx	w21, w10, #1, #1
	mov.b	v4[1], w21
	ubfx	w21, w10, #2, #1
	mov.b	v4[2], w21
	ubfx	w21, w10, #3, #1
	mov.b	v4[3], w21
	ubfx	w21, w10, #4, #1
	mov.b	v4[4], w21
	ubfx	w21, w10, #5, #1
	mov.b	v4[5], w21
	ubfx	w21, w10, #6, #1
	mov.b	v4[6], w21
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	orr.8b	v5, v10, v4
	and.8b	v16, v1, v3
	eor.8b	v16, v16, v5
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	umaxv.8b	b16, v16
	fmov	w10, s16
	ands	w7, w19, w7
	csetm	w19, ne
	bics	w10, w7, w10
	csetm	w21, ne
	dup.8b	v16, w21
	bic.8b	v17, v5, v16
	dup.8b	v18, w19
	bit.8b	v4, v17, v18
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x20, w4, sxtw]
	bic.8b	v3, v3, v16
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x6, w4, sxtw]
	mov	w4, #-1                         ; =0xffffffff
	csinv	w4, w4, w5, eq
	and	w17, w4, w17
	dup.8b	v3, w7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v4, w10
	and.8b	v4, v4, v5
	str	q7, [sp, #4768]
	str	q6, [sp, #4784]
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #672
	ldr	w10, [x10, x3]
	csel	w1, w10, w1, ne
	bit.8b	v10, v4, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	cmp	w7, #1
	b.ne	LBB0_982
; %bb.979:                              ; %convergence.cascade981
                                        ;   in Loop: Header=BB0_978 Depth=4
	cmp	w1, #0
	ccmp	w2, #6, #2, ne
	b.hi	LBB0_982
; %bb.980:                              ; %convergence.cascade981
                                        ;   in Loop: Header=BB0_978 Depth=4
	add	w2, w2, #1
	tst	w3, #0xff
	b.ne	LBB0_978
	b	LBB0_982
LBB0_981:                               ; %schedule.48.convergence.cascade.exit982_crit_edge
                                        ;   in Loop: Header=BB0_7 Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
LBB0_982:                               ; %convergence.cascade.exit982
                                        ;   in Loop: Header=BB0_7 Depth=3
	tst	w3, #0xff
	b.eq	LBB0_5
; %bb.983:                              ; %convergence.target.48.ready
                                        ;   in Loop: Header=BB0_7 Depth=3
	rbit	w10, w3
	clz	w10, w10
	ldp	q0, q3, [sp, #736]              ; 32-byte Folded Reload
	str	q3, [sp, #4704]
	str	q0, [sp, #4720]
	ldp	q0, q3, [sp, #704]              ; 32-byte Folded Reload
	str	q3, [sp, #4736]
	str	q0, [sp, #4752]
	and	x2, x10, #0x7
	add	x3, sp, #1, lsl #12             ; =4096
	add	x3, x3, #608
	ldr	x2, [x3, x2, lsl #3]
	lsl	w10, w10, #2
	add	x3, sp, #4, lsl #12             ; =16384
	add	x3, x3, #2664
	sub	x10, x2, x10
	add	x10, x10, x3
	ldp	q4, q3, [x10, #992]
	ldr	q5, [x10, #2032]
	ldr	q16, [x10, #2016]
	ldr	q17, [x10, #3056]
	ldr	q18, [x10, #3040]
	ldr	q19, [x10, #4080]
	ldr	q22, [x10, #4064]
	movi.8b	v23, #1
	and.8b	v23, v10, v23
	ushll.8h	v23, v23, #0
	ushll.4s	v24, v23, #0
	ushll2.4s	v23, v23, #0
	ldr	q0, [sp, #672]                  ; 16-byte Folded Reload
	uaddw2.2d	v0, v0, v23
	str	q0, [sp, #672]                  ; 16-byte Folded Spill
	ldr	q0, [sp, #688]                  ; 16-byte Folded Reload
	uaddw.2d	v0, v0, v23
	str	q0, [sp, #688]                  ; 16-byte Folded Spill
	ldr	q0, [sp, #640]                  ; 16-byte Folded Reload
	uaddw2.2d	v0, v0, v24
	str	q0, [sp, #640]                  ; 16-byte Folded Spill
	ldr	q0, [sp, #656]                  ; 16-byte Folded Reload
	uaddw.2d	v0, v0, v24
	str	q0, [sp, #656]                  ; 16-byte Folded Spill
	ldr	q23, [sp, #18928]
	ldr	q24, [sp, #18912]
	zip1.8b	v25, v10, v0
	ushll.4s	v25, v25, #0
	shl.4s	v25, v25, #31
	cmlt.4s	v25, v25, #0
	bif.16b	v4, v24, v25
	zip2.8b	v24, v10, v0
	ushll.4s	v24, v24, #0
	shl.4s	v24, v24, #31
	cmlt.4s	v24, v24, #0
	bif.16b	v3, v23, v24
	str	q3, [sp, #18928]
	str	q4, [sp, #18912]
	ldr	q3, [sp, #18896]
	ldr	q4, [sp, #18880]
	bit.16b	v4, v16, v25
	bit.16b	v3, v5, v24
	str	q3, [sp, #18896]
	str	q4, [sp, #18880]
	ldr	q3, [sp, #18864]
	ldr	q4, [sp, #18848]
	bit.16b	v4, v18, v25
	bit.16b	v3, v17, v24
	str	q3, [sp, #18864]
	str	q4, [sp, #18848]
	ldr	q3, [sp, #18832]
	ldr	q4, [sp, #18816]
	bit.16b	v4, v22, v25
	bit.16b	v3, v19, v24
	str	q3, [sp, #18832]
	str	q4, [sp, #18816]
	b	LBB0_132
LBB0_984:                               ; %varying.coherent.false
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w2, #0xff
	b.eq	LBB0_5
LBB0_985:                               ; %schedule.49
                                        ;   in Loop: Header=BB0_6 Depth=2
	cbz	w1, LBB0_3
; %bb.986:                              ; %convergence.cascade1010.preheader
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w2, #0                          ; =0x0
LBB0_987:                               ; %convergence.cascade1010
                                        ;   Parent Loop BB0_2 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v4, v3, v2
	addv.8b	b4, v4
	fmov	w10, s4
	umaxv.8b	b3, v3
	fmov	w6, s3
	sub	w3, w1, #1
	tst	w10, #0xff
	csel	w4, w3, wzr, ne
	mov	w10, #1                         ; =0x1
	lsl	w5, w10, w4
	and	w10, w5, w17
	tst	w10, #0xff
	cset	w10, ne
	str	q9, [sp, #16080]
	str	q8, [sp, #16096]
	ubfiz	x3, x4, #2, #3
	add	x7, sp, #3, lsl #12             ; =12288
	add	x7, x7, #3792
	ldr	w7, [x7, x3]
	cmp	w7, #0
	cset	w7, eq
	and	w19, w10, w6
	add	x6, sp, #18, lsl #12            ; =73728
	add	x6, x6, #752
	ldrb	w10, [x6, w4, sxtw]
	and	w20, w10, #0x1
	fmov	s3, w20
	ubfx	w20, w10, #1, #1
	mov.b	v3[1], w20
	ubfx	w20, w10, #2, #1
	mov.b	v3[2], w20
	ubfx	w20, w10, #3, #1
	mov.b	v3[3], w20
	ubfx	w20, w10, #4, #1
	mov.b	v3[4], w20
	ubfx	w20, w10, #5, #1
	mov.b	v3[5], w20
	ubfx	w20, w10, #6, #1
	mov.b	v3[6], w20
	add	x20, sp, #18, lsl #12           ; =73728
	add	x20, x20, #744
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x20, w4, sxtw]
	and	w21, w10, #0x1
	fmov	s4, w21
	ubfx	w21, w10, #1, #1
	mov.b	v4[1], w21
	ubfx	w21, w10, #2, #1
	mov.b	v4[2], w21
	ubfx	w21, w10, #3, #1
	mov.b	v4[3], w21
	ubfx	w21, w10, #4, #1
	mov.b	v4[4], w21
	ubfx	w21, w10, #5, #1
	mov.b	v4[5], w21
	ubfx	w21, w10, #6, #1
	mov.b	v4[6], w21
	lsr	w10, w10, #7
	mov.b	v4[7], w10
	orr.8b	v5, v10, v4
	and.8b	v16, v1, v3
	eor.8b	v16, v16, v5
	shl.8b	v16, v16, #7
	cmlt.8b	v16, v16, #0
	umaxv.8b	b16, v16
	fmov	w10, s16
	ands	w7, w19, w7
	csetm	w19, ne
	bics	w10, w7, w10
	csetm	w21, ne
	dup.8b	v16, w21
	bic.8b	v17, v5, v16
	dup.8b	v18, w19
	bit.8b	v4, v17, v18
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	str	b4, [x20, w4, sxtw]
	bic.8b	v3, v3, v16
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x6, w4, sxtw]
	mov	w4, #-1                         ; =0xffffffff
	csinv	w4, w4, w5, eq
	and	w17, w4, w17
	dup.8b	v3, w7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	dup.8b	v4, w10
	and.8b	v4, v4, v5
	str	q7, [sp, #16048]
	str	q6, [sp, #16064]
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #3760
	ldr	w10, [x10, x3]
	csel	w1, w10, w1, ne
	bit.8b	v10, v4, v3
	shl.8b	v3, v10, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w3, s3
	cmp	w7, #1
	b.ne	LBB0_4
; %bb.988:                              ; %convergence.cascade1010
                                        ;   in Loop: Header=BB0_987 Depth=3
	cmp	w1, #0
	ccmp	w2, #6, #2, ne
	b.hi	LBB0_4
; %bb.989:                              ; %convergence.cascade1010
                                        ;   in Loop: Header=BB0_987 Depth=3
	add	w2, w2, #1
	tst	w3, #0xff
	b.ne	LBB0_987
	b	LBB0_4
LBB0_990:                               ; %convergence.target.49.ready
                                        ;   in Loop: Header=BB0_2 Depth=1
	mov.16b	v22, v20
	bic.8b	v1, v1, v10
	tst	w17, #0xff
	b.eq	LBB0_1003
; %bb.991:                              ; %return.frame.cleanup
                                        ;   in Loop: Header=BB0_2 Depth=1
	ldrb	w10, [x8, #8]
	and	w1, w10, #0x1
	fmov	s3, w1
	ubfx	w1, w10, #1, #1
	mov.b	v3[1], w1
	ubfx	w1, w10, #2, #1
	mov.b	v3[2], w1
	ubfx	w1, w10, #3, #1
	mov.b	v3[3], w1
	ubfx	w1, w10, #4, #1
	mov.b	v3[4], w1
	ubfx	w1, w10, #5, #1
	mov.b	v3[5], w1
	ubfx	w1, w10, #6, #1
	mov.b	v3[6], w1
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x8]
	and	w1, w10, #0x1
	fmov	s5, w1
	ubfx	w1, w10, #1, #1
	mov.b	v5[1], w1
	ubfx	w1, w10, #2, #1
	mov.b	v5[2], w1
	ubfx	w1, w10, #3, #1
	mov.b	v5[3], w1
	ubfx	w1, w10, #4, #1
	mov.b	v5[4], w1
	ubfx	w1, w10, #5, #1
	mov.b	v5[5], w1
	ubfx	w1, w10, #6, #1
	mov.b	v5[6], w1
	lsr	w10, w10, #7
	mov.b	v5[7], w10
	and.8b	v17, v1, v3
	eor.8b	v3, v5, v17
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b4, v3
	fmov	w10, s4
	eor	w10, w10, #0x1
	and	w10, w17, w10
	dup.8b	v4, w10
	and.8b	v16, v4, v5
	shl.8b	v4, v16, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w1, s4
	tst	w10, #0x1
	csetm	w10, ne
	dup.8b	v18, w10
	bic.8b	v17, v17, v18
	shl.8b	v17, v17, #7
	cmlt.8b	v17, v17, #0
	and.8b	v17, v17, v2
	addv.8b	b17, v17
	str	b17, [x8, #8]
	bic.8b	v5, v5, v18
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	str	b5, [x8]
	cmp	x0, #8
	ldp	q20, q19, [sp, #864]            ; 32-byte Folded Reload
	ldr	q0, [sp, #1264]                 ; 16-byte Folded Reload
	ldr	q23, [sp, #1248]                ; 16-byte Folded Reload
	ldr	q24, [sp, #1488]                ; 16-byte Folded Reload
	ldr	q25, [sp, #1216]                ; 16-byte Folded Reload
	ldp	q27, q26, [sp, #672]            ; 32-byte Folded Reload
	b.lo	LBB0_993
; %bb.992:                              ; %return.frame.cleanup
                                        ;   in Loop: Header=BB0_2 Depth=1
	tst	w1, #0xff
	b.ne	LBB0_1006
LBB0_993:                               ; %ready.overflow.resume1032
                                        ;   in Loop: Header=BB0_2 Depth=1
	fmov	s5, wzr
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w10, s3
	cmeq.8b	v3, v4, v5
	mvn.8b	v3, v3
	umov.b	w2, v3[0]
	sbfx	w3, w2, #0, #1
	fmov	s3, w3
	sbfx	w3, w2, #1, #1
	mov.b	v3[1], w3
	sbfx	w3, w2, #2, #1
	mov.b	v3[2], w3
	sbfx	w3, w2, #3, #1
	mov.b	v3[3], w3
	sbfx	w3, w2, #4, #1
	mov.b	v3[4], w3
	sbfx	w3, w2, #5, #1
	mov.b	v3[5], w3
	sbfx	w3, w2, #6, #1
	mov.b	v3[6], w3
	sbfx	w2, w2, #7, #1
	mov.b	v3[7], w2
	and	w2, w17, #0xfffffffe
	tst	w10, #0xff
	csel	w2, w2, w17, eq
	sxtw	x10, w0
	tst	w1, #0xff
	csel	x10, x10, xzr, ne
	add	x17, sp, #18, lsl #12           ; =73728
	add	x17, x17, #824
	ldrb	w1, [x17, x10]
	and	w3, w1, #0x1
	fmov	s4, w3
	ubfx	w3, w1, #1, #1
	mov.b	v4[1], w3
	ubfx	w3, w1, #2, #1
	mov.b	v4[2], w3
	ubfx	w3, w1, #3, #1
	mov.b	v4[3], w3
	ubfx	w3, w1, #4, #1
	mov.b	v4[4], w3
	ubfx	w3, w1, #5, #1
	mov.b	v4[5], w3
	ubfx	w3, w1, #6, #1
	mov.b	v4[6], w3
	lsr	w1, w1, #7
	mov.b	v4[7], w1
	bsl.8b	v3, v16, v4
	fmov	w3, s9
Lloh1402:
	adrp	x1, l_convergence.targets@PAGE
Lloh1403:
	add	x1, x1, l_convergence.targets@PAGEOFF
	add	x3, x1, w3, sxtw #2
	fmov	w5, s7
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x17, x10]
	lsl	x10, x10, #2
	add	x4, sp, #18, lsl #12            ; =73728
	add	x4, x4, #792
	add	x6, x4, x10
	csel	x3, x3, x6, ne
	ldr	w3, [x3]
	str	w3, [x6]
	add	x3, sp, #18, lsl #12            ; =73728
	add	x3, x3, #760
	ldr	w6, [x3, x10]
	csel	w5, w5, w6, ne
	str	w5, [x3, x10]
	cinc	w0, w0, ne
	and	w5, w2, #0x2
	ldrb	w10, [x8, #9]
	and	w6, w10, #0x1
	fmov	s3, w6
	ubfx	w6, w10, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w10, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w10, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w10, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w10, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w10, #6, #1
	mov.b	v3[6], w6
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x8, #1]
	and	w6, w10, #0x1
	fmov	s5, w6
	ubfx	w6, w10, #1, #1
	mov.b	v5[1], w6
	ubfx	w6, w10, #2, #1
	mov.b	v5[2], w6
	ubfx	w6, w10, #3, #1
	mov.b	v5[3], w6
	ubfx	w6, w10, #4, #1
	mov.b	v5[4], w6
	ubfx	w6, w10, #5, #1
	mov.b	v5[5], w6
	ubfx	w6, w10, #6, #1
	mov.b	v5[6], w6
	lsr	w10, w10, #7
	mov.b	v5[7], w10
	and.8b	v17, v1, v3
	eor.8b	v3, v5, v17
	shl.8b	v3, v3, #7
	cmlt.8b	v4, v3, #0
	umaxv.8b	b3, v4
	fmov	w10, s3
	eor	w10, w10, #0x1
	ands	w10, w10, w5, lsr #1
	dup.8b	v3, w10
	and.8b	v3, v3, v5
	shl.8b	v16, v3, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v2
	addv.8b	b16, v16
	fmov	w5, s16
	csetm	w10, ne
	dup.8b	v18, w10
	bic.8b	v17, v17, v18
	shl.8b	v17, v17, #7
	cmlt.8b	v17, v17, #0
	and.8b	v17, v17, v2
	addv.8b	b17, v17
	stur	b17, [x8, #9]
	bic.8b	v5, v5, v18
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	stur	b5, [x8, #1]
	cmp	w0, #8
	and	w10, w5, #0xff
	ccmp	w10, #0, #4, hs
	b.ne	LBB0_1006
; %bb.994:                              ; %ready.overflow.resume1038
                                        ;   in Loop: Header=BB0_2 Depth=1
	fmov	s5, wzr
	and.8b	v4, v4, v2
	cmeq.8b	v5, v16, v5
	mvn.8b	v5, v5
	umov.b	w10, v5[0]
	addv.8b	b5, v4
	sbfx	w6, w10, #0, #1
	fmov	s4, w6
	sbfx	w6, w10, #1, #1
	mov.b	v4[1], w6
	sbfx	w6, w10, #2, #1
	mov.b	v4[2], w6
	sbfx	w6, w10, #3, #1
	mov.b	v4[3], w6
	sbfx	w6, w10, #4, #1
	mov.b	v4[4], w6
	sbfx	w6, w10, #5, #1
	mov.b	v4[5], w6
	sbfx	w6, w10, #6, #1
	mov.b	v4[6], w6
	sbfx	w10, w10, #7, #1
	mov.b	v4[7], w10
	fmov	w10, s5
	and	w6, w2, #0xfffffffd
	tst	w10, #0xff
	csel	w2, w6, w2, eq
	sxtw	x10, w0
	tst	w5, #0xff
	csel	x10, x10, xzr, ne
	ldrb	w5, [x17, x10]
	and	w6, w5, #0x1
	fmov	s5, w6
	ubfx	w6, w5, #1, #1
	mov.b	v5[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v5[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v5[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v5[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v5[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v5[6], w6
	lsr	w5, w5, #7
	mov.b	v5[7], w5
	bif.8b	v3, v5, v4
	mov.s	w5, v9[1]
	add	x5, x1, w5, sxtw #2
	mov.s	w6, v7[1]
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x17, x10]
	lsl	x10, x10, #2
	add	x17, x4, x10
	csel	x4, x5, x17, ne
	ldr	w4, [x4]
	str	w4, [x17]
	ldr	w17, [x3, x10]
	csel	w17, w6, w17, ne
	str	w17, [x3, x10]
	cinc	w4, w0, ne
	and	w17, w2, #0x4
	ldrb	w10, [x8, #10]
	and	w0, w10, #0x1
	fmov	s3, w0
	ubfx	w0, w10, #1, #1
	mov.b	v3[1], w0
	ubfx	w0, w10, #2, #1
	mov.b	v3[2], w0
	ubfx	w0, w10, #3, #1
	mov.b	v3[3], w0
	ubfx	w0, w10, #4, #1
	mov.b	v3[4], w0
	ubfx	w0, w10, #5, #1
	mov.b	v3[5], w0
	ubfx	w0, w10, #6, #1
	mov.b	v3[6], w0
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x8, #2]
	and	w0, w10, #0x1
	fmov	s5, w0
	ubfx	w0, w10, #1, #1
	mov.b	v5[1], w0
	ubfx	w0, w10, #2, #1
	mov.b	v5[2], w0
	ubfx	w0, w10, #3, #1
	mov.b	v5[3], w0
	ubfx	w0, w10, #4, #1
	mov.b	v5[4], w0
	ubfx	w0, w10, #5, #1
	mov.b	v5[5], w0
	ubfx	w0, w10, #6, #1
	mov.b	v5[6], w0
	lsr	w10, w10, #7
	mov.b	v5[7], w10
	and.8b	v17, v1, v3
	eor.8b	v3, v5, v17
	shl.8b	v3, v3, #7
	cmlt.8b	v4, v3, #0
	umaxv.8b	b3, v4
	fmov	w10, s3
	eor	w10, w10, #0x1
	ands	w10, w10, w17, lsr #2
	dup.8b	v3, w10
	and.8b	v3, v3, v5
	shl.8b	v16, v3, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v2
	addv.8b	b16, v16
	fmov	w17, s16
	csetm	w10, ne
	dup.8b	v18, w10
	bic.8b	v17, v17, v18
	shl.8b	v17, v17, #7
	cmlt.8b	v17, v17, #0
	and.8b	v17, v17, v2
	addv.8b	b17, v17
	stur	b17, [x8, #10]
	bic.8b	v5, v5, v18
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	stur	b5, [x8, #2]
	cmp	w4, #8
	and	w10, w17, #0xff
	ccmp	w10, #0, #4, hs
	b.ne	LBB0_1006
; %bb.995:                              ; %ready.overflow.resume1044
                                        ;   in Loop: Header=BB0_2 Depth=1
	fmov	s5, wzr
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w10, s4
	cmeq.8b	v4, v16, v5
	mvn.8b	v4, v4
	umov.b	w0, v4[0]
	sbfx	w3, w0, #0, #1
	fmov	s4, w3
	sbfx	w3, w0, #1, #1
	mov.b	v4[1], w3
	sbfx	w3, w0, #2, #1
	mov.b	v4[2], w3
	sbfx	w3, w0, #3, #1
	mov.b	v4[3], w3
	sbfx	w3, w0, #4, #1
	mov.b	v4[4], w3
	sbfx	w3, w0, #5, #1
	mov.b	v4[5], w3
	sbfx	w3, w0, #6, #1
	mov.b	v4[6], w3
	sbfx	w0, w0, #7, #1
	mov.b	v4[7], w0
	and	w0, w2, #0xfffffffb
	tst	w10, #0xff
	csel	w0, w0, w2, eq
	sxtw	x10, w4
	tst	w17, #0xff
	csel	x10, x10, xzr, ne
	add	x17, sp, #18, lsl #12           ; =73728
	add	x17, x17, #824
	ldrb	w2, [x17, x10]
	and	w3, w2, #0x1
	fmov	s5, w3
	ubfx	w3, w2, #1, #1
	mov.b	v5[1], w3
	ubfx	w3, w2, #2, #1
	mov.b	v5[2], w3
	ubfx	w3, w2, #3, #1
	mov.b	v5[3], w3
	ubfx	w3, w2, #4, #1
	mov.b	v5[4], w3
	ubfx	w3, w2, #5, #1
	mov.b	v5[5], w3
	ubfx	w3, w2, #6, #1
	mov.b	v5[6], w3
	lsr	w2, w2, #7
	mov.b	v5[7], w2
	bif.8b	v3, v5, v4
	mov.s	w2, v9[2]
	add	x2, x1, w2, sxtw #2
	mov.s	w5, v7[2]
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x17, x10]
	lsl	x10, x10, #2
	add	x3, sp, #18, lsl #12            ; =73728
	add	x3, x3, #792
	add	x6, x3, x10
	csel	x2, x2, x6, ne
	ldr	w2, [x2]
	str	w2, [x6]
	add	x2, sp, #18, lsl #12            ; =73728
	add	x2, x2, #760
	ldr	w6, [x2, x10]
	csel	w5, w5, w6, ne
	str	w5, [x2, x10]
	cinc	w4, w4, ne
	and	w5, w0, #0x8
	ldrb	w10, [x8, #11]
	and	w6, w10, #0x1
	fmov	s3, w6
	ubfx	w6, w10, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w10, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w10, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w10, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w10, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w10, #6, #1
	mov.b	v3[6], w6
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x8, #3]
	and	w6, w10, #0x1
	fmov	s5, w6
	ubfx	w6, w10, #1, #1
	mov.b	v5[1], w6
	ubfx	w6, w10, #2, #1
	mov.b	v5[2], w6
	ubfx	w6, w10, #3, #1
	mov.b	v5[3], w6
	ubfx	w6, w10, #4, #1
	mov.b	v5[4], w6
	ubfx	w6, w10, #5, #1
	mov.b	v5[5], w6
	ubfx	w6, w10, #6, #1
	mov.b	v5[6], w6
	lsr	w10, w10, #7
	mov.b	v5[7], w10
	and.8b	v17, v1, v3
	eor.8b	v3, v5, v17
	shl.8b	v3, v3, #7
	cmlt.8b	v4, v3, #0
	umaxv.8b	b3, v4
	fmov	w10, s3
	eor	w10, w10, #0x1
	ands	w10, w10, w5, lsr #3
	dup.8b	v3, w10
	and.8b	v3, v3, v5
	shl.8b	v16, v3, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v2
	addv.8b	b16, v16
	fmov	w6, s16
	csetm	w10, ne
	dup.8b	v18, w10
	bic.8b	v17, v17, v18
	shl.8b	v17, v17, #7
	cmlt.8b	v17, v17, #0
	and.8b	v17, v17, v2
	addv.8b	b17, v17
	stur	b17, [x8, #11]
	bic.8b	v5, v5, v18
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	stur	b5, [x8, #3]
	cmp	w4, #8
	and	w10, w6, #0xff
	ccmp	w10, #0, #4, hs
	b.ne	LBB0_1006
; %bb.996:                              ; %ready.overflow.resume1050
                                        ;   in Loop: Header=BB0_2 Depth=1
	fmov	s5, wzr
	and.8b	v4, v4, v2
	cmeq.8b	v5, v16, v5
	mvn.8b	v5, v5
	umov.b	w10, v5[0]
	addv.8b	b5, v4
	sbfx	w5, w10, #0, #1
	fmov	s4, w5
	sbfx	w5, w10, #1, #1
	mov.b	v4[1], w5
	sbfx	w5, w10, #2, #1
	mov.b	v4[2], w5
	sbfx	w5, w10, #3, #1
	mov.b	v4[3], w5
	sbfx	w5, w10, #4, #1
	mov.b	v4[4], w5
	sbfx	w5, w10, #5, #1
	mov.b	v4[5], w5
	sbfx	w5, w10, #6, #1
	mov.b	v4[6], w5
	sbfx	w10, w10, #7, #1
	mov.b	v4[7], w10
	fmov	w10, s5
	and	w5, w0, #0xfffffff7
	tst	w10, #0xff
	csel	w5, w5, w0, eq
	sxtw	x10, w4
	tst	w6, #0xff
	csel	x10, x10, xzr, ne
	ldrb	w0, [x17, x10]
	and	w6, w0, #0x1
	fmov	s5, w6
	ubfx	w6, w0, #1, #1
	mov.b	v5[1], w6
	ubfx	w6, w0, #2, #1
	mov.b	v5[2], w6
	ubfx	w6, w0, #3, #1
	mov.b	v5[3], w6
	ubfx	w6, w0, #4, #1
	mov.b	v5[4], w6
	ubfx	w6, w0, #5, #1
	mov.b	v5[5], w6
	ubfx	w6, w0, #6, #1
	mov.b	v5[6], w6
	lsr	w0, w0, #7
	mov.b	v5[7], w0
	bif.8b	v3, v5, v4
	mov.s	w0, v9[3]
	add	x0, x1, w0, sxtw #2
	mov.s	w6, v7[3]
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x17, x10]
	lsl	x10, x10, #2
	add	x17, x3, x10
	csel	x0, x0, x17, ne
	ldr	w0, [x0]
	str	w0, [x17]
	ldr	w17, [x2, x10]
	csel	w17, w6, w17, ne
	str	w17, [x2, x10]
	cinc	w0, w4, ne
	and	w17, w5, #0x10
	ldrb	w10, [x8, #12]
	and	w2, w10, #0x1
	fmov	s3, w2
	ubfx	w2, w10, #1, #1
	mov.b	v3[1], w2
	ubfx	w2, w10, #2, #1
	mov.b	v3[2], w2
	ubfx	w2, w10, #3, #1
	mov.b	v3[3], w2
	ubfx	w2, w10, #4, #1
	mov.b	v3[4], w2
	ubfx	w2, w10, #5, #1
	mov.b	v3[5], w2
	ubfx	w2, w10, #6, #1
	mov.b	v3[6], w2
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x8, #4]
	and	w2, w10, #0x1
	fmov	s5, w2
	ubfx	w2, w10, #1, #1
	mov.b	v5[1], w2
	ubfx	w2, w10, #2, #1
	mov.b	v5[2], w2
	ubfx	w2, w10, #3, #1
	mov.b	v5[3], w2
	ubfx	w2, w10, #4, #1
	mov.b	v5[4], w2
	ubfx	w2, w10, #5, #1
	mov.b	v5[5], w2
	ubfx	w2, w10, #6, #1
	mov.b	v5[6], w2
	lsr	w10, w10, #7
	mov.b	v5[7], w10
	and.8b	v17, v1, v3
	eor.8b	v3, v5, v17
	shl.8b	v3, v3, #7
	cmlt.8b	v4, v3, #0
	umaxv.8b	b3, v4
	fmov	w10, s3
	eor	w10, w10, #0x1
	ands	w10, w10, w17, lsr #4
	dup.8b	v3, w10
	and.8b	v3, v3, v5
	shl.8b	v16, v3, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v2
	addv.8b	b16, v16
	fmov	w17, s16
	csetm	w10, ne
	dup.8b	v18, w10
	bic.8b	v17, v17, v18
	shl.8b	v17, v17, #7
	cmlt.8b	v17, v17, #0
	and.8b	v17, v17, v2
	addv.8b	b17, v17
	stur	b17, [x8, #12]
	bic.8b	v5, v5, v18
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	stur	b5, [x8, #4]
	cmp	w0, #8
	and	w10, w17, #0xff
	ccmp	w10, #0, #4, hs
	b.ne	LBB0_1006
; %bb.997:                              ; %ready.overflow.resume1056
                                        ;   in Loop: Header=BB0_2 Depth=1
	fmov	s5, wzr
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	cmeq.8b	v5, v16, v5
	mvn.8b	v5, v5
	umov.b	w10, v5[0]
	fmov	w2, s4
	sbfx	w3, w10, #0, #1
	fmov	s4, w3
	sbfx	w3, w10, #1, #1
	mov.b	v4[1], w3
	sbfx	w3, w10, #2, #1
	mov.b	v4[2], w3
	sbfx	w3, w10, #3, #1
	mov.b	v4[3], w3
	sbfx	w3, w10, #4, #1
	mov.b	v4[4], w3
	sbfx	w3, w10, #5, #1
	mov.b	v4[5], w3
	sbfx	w3, w10, #6, #1
	mov.b	v4[6], w3
	sbfx	w10, w10, #7, #1
	mov.b	v4[7], w10
	and	w10, w5, #0xffffffef
	tst	w2, #0xff
	csel	w3, w10, w5, eq
	sxtw	x10, w0
	tst	w17, #0xff
	csel	x10, x10, xzr, ne
	add	x17, sp, #18, lsl #12           ; =73728
	add	x17, x17, #824
	ldrb	w2, [x17, x10]
	and	w4, w2, #0x1
	fmov	s5, w4
	ubfx	w4, w2, #1, #1
	mov.b	v5[1], w4
	ubfx	w4, w2, #2, #1
	mov.b	v5[2], w4
	ubfx	w4, w2, #3, #1
	mov.b	v5[3], w4
	ubfx	w4, w2, #4, #1
	mov.b	v5[4], w4
	ubfx	w4, w2, #5, #1
	mov.b	v5[5], w4
	ubfx	w4, w2, #6, #1
	mov.b	v5[6], w4
	lsr	w2, w2, #7
	mov.b	v5[7], w2
	bif.8b	v3, v5, v4
	fmov	w2, s8
	add	x2, x1, w2, sxtw #2
	fmov	w5, s6
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x17, x10]
	lsl	x10, x10, #2
	add	x4, sp, #18, lsl #12            ; =73728
	add	x4, x4, #792
	add	x6, x4, x10
	csel	x2, x2, x6, ne
	ldr	w2, [x2]
	str	w2, [x6]
	add	x2, sp, #18, lsl #12            ; =73728
	add	x2, x2, #760
	ldr	w6, [x2, x10]
	csel	w5, w5, w6, ne
	str	w5, [x2, x10]
	cinc	w5, w0, ne
	and	w0, w3, #0x20
	ldrb	w10, [x8, #13]
	and	w6, w10, #0x1
	fmov	s3, w6
	ubfx	w6, w10, #1, #1
	mov.b	v3[1], w6
	ubfx	w6, w10, #2, #1
	mov.b	v3[2], w6
	ubfx	w6, w10, #3, #1
	mov.b	v3[3], w6
	ubfx	w6, w10, #4, #1
	mov.b	v3[4], w6
	ubfx	w6, w10, #5, #1
	mov.b	v3[5], w6
	ubfx	w6, w10, #6, #1
	mov.b	v3[6], w6
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x8, #5]
	and	w6, w10, #0x1
	fmov	s5, w6
	ubfx	w6, w10, #1, #1
	mov.b	v5[1], w6
	ubfx	w6, w10, #2, #1
	mov.b	v5[2], w6
	ubfx	w6, w10, #3, #1
	mov.b	v5[3], w6
	ubfx	w6, w10, #4, #1
	mov.b	v5[4], w6
	ubfx	w6, w10, #5, #1
	mov.b	v5[5], w6
	ubfx	w6, w10, #6, #1
	mov.b	v5[6], w6
	lsr	w10, w10, #7
	mov.b	v5[7], w10
	and.8b	v17, v1, v3
	eor.8b	v3, v5, v17
	shl.8b	v3, v3, #7
	cmlt.8b	v4, v3, #0
	umaxv.8b	b3, v4
	fmov	w10, s3
	eor	w10, w10, #0x1
	ands	w10, w10, w0, lsr #5
	dup.8b	v3, w10
	and.8b	v3, v3, v5
	shl.8b	v16, v3, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v2
	addv.8b	b16, v16
	fmov	w6, s16
	csetm	w10, ne
	dup.8b	v18, w10
	bic.8b	v17, v17, v18
	shl.8b	v17, v17, #7
	cmlt.8b	v17, v17, #0
	and.8b	v17, v17, v2
	addv.8b	b17, v17
	stur	b17, [x8, #13]
	bic.8b	v5, v5, v18
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	stur	b5, [x8, #5]
	cmp	w5, #8
	and	w10, w6, #0xff
	ccmp	w10, #0, #4, hs
	b.ne	LBB0_1006
; %bb.998:                              ; %ready.overflow.resume1062
                                        ;   in Loop: Header=BB0_2 Depth=1
	fmov	s5, wzr
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w10, s4
	cmeq.8b	v4, v16, v5
	mvn.8b	v4, v4
	umov.b	w0, v4[0]
	sbfx	w7, w0, #0, #1
	fmov	s4, w7
	sbfx	w7, w0, #1, #1
	mov.b	v4[1], w7
	sbfx	w7, w0, #2, #1
	mov.b	v4[2], w7
	sbfx	w7, w0, #3, #1
	mov.b	v4[3], w7
	sbfx	w7, w0, #4, #1
	mov.b	v4[4], w7
	sbfx	w7, w0, #5, #1
	mov.b	v4[5], w7
	sbfx	w7, w0, #6, #1
	mov.b	v4[6], w7
	sbfx	w0, w0, #7, #1
	mov.b	v4[7], w0
	and	w0, w3, #0xffffffdf
	tst	w10, #0xff
	csel	w0, w0, w3, eq
	sxtw	x10, w5
	tst	w6, #0xff
	csel	x10, x10, xzr, ne
	ldrb	w3, [x17, x10]
	and	w6, w3, #0x1
	fmov	s5, w6
	ubfx	w6, w3, #1, #1
	mov.b	v5[1], w6
	ubfx	w6, w3, #2, #1
	mov.b	v5[2], w6
	ubfx	w6, w3, #3, #1
	mov.b	v5[3], w6
	ubfx	w6, w3, #4, #1
	mov.b	v5[4], w6
	ubfx	w6, w3, #5, #1
	mov.b	v5[5], w6
	ubfx	w6, w3, #6, #1
	mov.b	v5[6], w6
	lsr	w3, w3, #7
	mov.b	v5[7], w3
	mov.s	w3, v8[1]
	bif.8b	v3, v5, v4
	add	x3, x1, w3, sxtw #2
	mov.s	w6, v6[1]
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x17, x10]
	lsl	x10, x10, #2
	add	x17, x4, x10
	csel	x3, x3, x17, ne
	ldr	w3, [x3]
	str	w3, [x17]
	ldr	w17, [x2, x10]
	csel	w17, w6, w17, ne
	str	w17, [x2, x10]
	cinc	w17, w5, ne
	ldrb	w10, [x8, #14]
	and	w2, w10, #0x1
	fmov	s3, w2
	ubfx	w2, w10, #1, #1
	mov.b	v3[1], w2
	ubfx	w2, w10, #2, #1
	mov.b	v3[2], w2
	ubfx	w2, w10, #3, #1
	mov.b	v3[3], w2
	ubfx	w2, w10, #4, #1
	mov.b	v3[4], w2
	ubfx	w2, w10, #5, #1
	mov.b	v3[5], w2
	ubfx	w2, w10, #6, #1
	mov.b	v3[6], w2
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x8, #6]
	and	w2, w10, #0x1
	fmov	s5, w2
	ubfx	w2, w10, #1, #1
	mov.b	v5[1], w2
	ubfx	w2, w10, #2, #1
	mov.b	v5[2], w2
	ubfx	w2, w10, #3, #1
	mov.b	v5[3], w2
	ubfx	w2, w10, #4, #1
	mov.b	v5[4], w2
	ubfx	w2, w10, #5, #1
	mov.b	v5[5], w2
	ubfx	w2, w10, #6, #1
	mov.b	v5[6], w2
	and	w2, w0, #0x40
	lsr	w10, w10, #7
	mov.b	v5[7], w10
	and.8b	v17, v1, v3
	eor.8b	v3, v5, v17
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b4, v3
	fmov	w10, s4
	eor	w10, w10, #0x1
	ands	w10, w10, w2, lsr #6
	dup.8b	v4, w10
	and.8b	v16, v4, v5
	shl.8b	v4, v16, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w2, s4
	csetm	w10, ne
	dup.8b	v18, w10
	bic.8b	v17, v17, v18
	shl.8b	v17, v17, #7
	cmlt.8b	v17, v17, #0
	and.8b	v17, v17, v2
	addv.8b	b17, v17
	stur	b17, [x8, #14]
	bic.8b	v5, v5, v18
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	stur	b5, [x8, #6]
	cmp	w17, #8
	b.lo	LBB0_1000
; %bb.999:                              ; %ready.overflow.resume1062
                                        ;   in Loop: Header=BB0_2 Depth=1
	tst	w2, #0xff
	b.ne	LBB0_1006
LBB0_1000:                              ; %ready.overflow.resume1068
                                        ;   in Loop: Header=BB0_2 Depth=1
	fmov	s5, wzr
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w10, s3
	cmeq.8b	v3, v4, v5
	mvn.8b	v3, v3
	umov.b	w3, v3[0]
	sbfx	w4, w3, #0, #1
	fmov	s3, w4
	sbfx	w4, w3, #1, #1
	mov.b	v3[1], w4
	sbfx	w4, w3, #2, #1
	mov.b	v3[2], w4
	sbfx	w4, w3, #3, #1
	mov.b	v3[3], w4
	sbfx	w4, w3, #4, #1
	mov.b	v3[4], w4
	sbfx	w4, w3, #5, #1
	mov.b	v3[5], w4
	sbfx	w4, w3, #6, #1
	mov.b	v3[6], w4
	sbfx	w3, w3, #7, #1
	mov.b	v3[7], w3
	and	w3, w0, #0xffffffbf
	tst	w10, #0xff
	csel	w4, w3, w0, eq
	sxtw	x10, w17
	tst	w2, #0xff
	csel	x10, x10, xzr, ne
	add	x0, sp, #18, lsl #12            ; =73728
	add	x0, x0, #824
	ldrb	w2, [x0, x10]
	and	w3, w2, #0x1
	fmov	s4, w3
	ubfx	w3, w2, #1, #1
	mov.b	v4[1], w3
	ubfx	w3, w2, #2, #1
	mov.b	v4[2], w3
	ubfx	w3, w2, #3, #1
	mov.b	v4[3], w3
	ubfx	w3, w2, #4, #1
	mov.b	v4[4], w3
	ubfx	w3, w2, #5, #1
	mov.b	v4[5], w3
	ubfx	w3, w2, #6, #1
	mov.b	v4[6], w3
	lsr	w2, w2, #7
	mov.b	v4[7], w2
	bsl.8b	v3, v16, v4
	mov.s	w2, v8[2]
	add	x5, x1, w2, sxtw #2
	mov.s	w6, v6[2]
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x0, x10]
	lsl	x10, x10, #2
	add	x3, sp, #18, lsl #12            ; =73728
	add	x3, x3, #792
	add	x2, sp, #18, lsl #12            ; =73728
	add	x2, x2, #760
	ldr	w7, [x2, x10]
	csel	w6, w6, w7, ne
	add	x7, x3, x10
	csel	x5, x5, x7, ne
	ldr	w19, [x5]
	str	w6, [x2, x10]
	sxtb	w5, w4
	str	w19, [x7]
	cinc	w4, w17, ne
	cmp	w5, #0
	ldrb	w10, [x8, #15]
	and	w17, w10, #0x1
	fmov	s3, w17
	ubfx	w17, w10, #1, #1
	mov.b	v3[1], w17
	ubfx	w17, w10, #2, #1
	mov.b	v3[2], w17
	ubfx	w17, w10, #3, #1
	mov.b	v3[3], w17
	ubfx	w17, w10, #4, #1
	mov.b	v3[4], w17
	ubfx	w17, w10, #5, #1
	mov.b	v3[5], w17
	ubfx	w17, w10, #6, #1
	mov.b	v3[6], w17
	lsr	w10, w10, #7
	mov.b	v3[7], w10
	ldrb	w10, [x8, #7]
	and	w17, w10, #0x1
	fmov	s5, w17
	ubfx	w17, w10, #1, #1
	mov.b	v5[1], w17
	ubfx	w17, w10, #2, #1
	mov.b	v5[2], w17
	ubfx	w17, w10, #3, #1
	mov.b	v5[3], w17
	ubfx	w17, w10, #4, #1
	mov.b	v5[4], w17
	ubfx	w17, w10, #5, #1
	mov.b	v5[5], w17
	ubfx	w17, w10, #6, #1
	mov.b	v5[6], w17
	cset	w17, lt
	lsr	w10, w10, #7
	mov.b	v5[7], w10
	and.8b	v17, v1, v3
	eor.8b	v3, v5, v17
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b4, v3
	fmov	w10, s4
	eor	w10, w10, #0x1
	ands	w10, w17, w10
	dup.8b	v4, w10
	and.8b	v16, v4, v5
	shl.8b	v4, v16, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v2
	addv.8b	b4, v4
	fmov	w6, s4
	csetm	w10, ne
	dup.8b	v18, w10
	bic.8b	v17, v17, v18
	shl.8b	v17, v17, #7
	cmlt.8b	v17, v17, #0
	and.8b	v17, v17, v2
	addv.8b	b17, v17
	stur	b17, [x8, #15]
	bic.8b	v5, v5, v18
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v2
	addv.8b	b5, v5
	stur	b5, [x8, #7]
	cmp	w4, #8
	b.lo	LBB0_1002
; %bb.1001:                             ; %ready.overflow.resume1068
                                        ;   in Loop: Header=BB0_2 Depth=1
	tst	w6, #0xff
	b.ne	LBB0_1006
LBB0_1002:                              ; %ready.overflow.resume1074
                                        ;   in Loop: Header=BB0_2 Depth=1
	fmov	s5, wzr
	cmeq.8b	v4, v4, v5
	and.8b	v3, v3, v2
	addv.8b	b5, v3
	mvn.8b	v3, v4
	umov.b	w10, v3[0]
	sbfx	w17, w10, #0, #1
	fmov	s3, w17
	sbfx	w17, w10, #1, #1
	mov.b	v3[1], w17
	sbfx	w17, w10, #2, #1
	mov.b	v3[2], w17
	sbfx	w17, w10, #3, #1
	mov.b	v3[3], w17
	sbfx	w17, w10, #4, #1
	mov.b	v3[4], w17
	sbfx	w17, w10, #5, #1
	mov.b	v3[5], w17
	sbfx	w17, w10, #6, #1
	mov.b	v3[6], w17
	fmov	w17, s5
	sbfx	w10, w10, #7, #1
	mov.b	v3[7], w10
	and	w10, w5, #0x7f
	tst	w17, #0xff
	csel	w17, w10, w5, eq
	sxtw	x10, w4
	tst	w6, #0xff
	csel	x10, x10, xzr, ne
	ldrb	w5, [x0, x10]
	and	w6, w5, #0x1
	fmov	s4, w6
	ubfx	w6, w5, #1, #1
	mov.b	v4[1], w6
	ubfx	w6, w5, #2, #1
	mov.b	v4[2], w6
	ubfx	w6, w5, #3, #1
	mov.b	v4[3], w6
	ubfx	w6, w5, #4, #1
	mov.b	v4[4], w6
	ubfx	w6, w5, #5, #1
	mov.b	v4[5], w6
	ubfx	w6, w5, #6, #1
	mov.b	v4[6], w6
	lsr	w5, w5, #7
	mov.b	v4[7], w5
	bsl.8b	v3, v16, v4
	mov.s	w5, v8[3]
	mov.s	w6, v6[3]
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	str	b3, [x0, x10]
	add	x0, x1, w5, sxtw #2
	lsl	x10, x10, #2
	add	x1, x3, x10
	csel	x0, x0, x1, ne
	ldr	w0, [x0]
	str	w0, [x1]
	ldr	w0, [x2, x10]
	csel	w0, w6, w0, ne
	str	w0, [x2, x10]
	cinc	w0, w4, ne
	ldr	q3, [sp, #1232]                 ; 16-byte Folded Reload
	ldr	q4, [sp, #1008]                 ; 16-byte Folded Reload
	cbnz	w0, LBB0_2
	b	LBB0_1004
LBB0_1003:                              ;   in Loop: Header=BB0_2 Depth=1
	mov	w17, #0                         ; =0x0
	ldp	q20, q19, [sp, #864]            ; 32-byte Folded Reload
	ldr	q0, [sp, #1264]                 ; 16-byte Folded Reload
	ldr	q23, [sp, #1248]                ; 16-byte Folded Reload
	ldr	q24, [sp, #1488]                ; 16-byte Folded Reload
	ldr	q3, [sp, #1232]                 ; 16-byte Folded Reload
	ldr	q25, [sp, #1216]                ; 16-byte Folded Reload
	ldr	q4, [sp, #1008]                 ; 16-byte Folded Reload
	ldp	q27, q26, [sp, #672]            ; 32-byte Folded Reload
	cbnz	w0, LBB0_2
LBB0_1004:                              ; %scheduler.done
	shl.8b	v0, v1, #7
	cmlt.8b	v0, v0, #0
	umaxv.8b	b0, v0
	fmov	w8, s0
	tbnz	w8, #0, LBB0_1006
; %bb.1005:                             ; %scheduler.exit
	sub	sp, x29, #144
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
LBB0_1006:                              ; %scheduler.stalled
	brk	#0x1
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpLdr	Lloh40, Lloh41
	.loh AdrpAdrp	Lloh38, Lloh40
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpAdrp	Lloh36, Lloh38
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpAdrp	Lloh34, Lloh36
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpLdr	Lloh32, Lloh33
	.loh AdrpAdrp	Lloh30, Lloh32
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdrp	Lloh28, Lloh30
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpLdr	Lloh304, Lloh305
	.loh AdrpAdrp	Lloh302, Lloh304
	.loh AdrpLdr	Lloh302, Lloh303
	.loh AdrpAdrp	Lloh300, Lloh302
	.loh AdrpLdr	Lloh300, Lloh301
	.loh AdrpAdrp	Lloh298, Lloh300
	.loh AdrpLdr	Lloh298, Lloh299
	.loh AdrpLdr	Lloh296, Lloh297
	.loh AdrpAdrp	Lloh294, Lloh296
	.loh AdrpLdr	Lloh294, Lloh295
	.loh AdrpAdrp	Lloh292, Lloh294
	.loh AdrpLdr	Lloh292, Lloh293
	.loh AdrpAdrp	Lloh290, Lloh292
	.loh AdrpLdr	Lloh290, Lloh291
	.loh AdrpLdr	Lloh288, Lloh289
	.loh AdrpAdrp	Lloh286, Lloh288
	.loh AdrpLdr	Lloh286, Lloh287
	.loh AdrpAdrp	Lloh284, Lloh286
	.loh AdrpLdr	Lloh284, Lloh285
	.loh AdrpAdrp	Lloh282, Lloh284
	.loh AdrpLdr	Lloh282, Lloh283
	.loh AdrpLdr	Lloh280, Lloh281
	.loh AdrpAdrp	Lloh278, Lloh280
	.loh AdrpLdr	Lloh278, Lloh279
	.loh AdrpAdrp	Lloh276, Lloh278
	.loh AdrpLdr	Lloh276, Lloh277
	.loh AdrpAdrp	Lloh274, Lloh276
	.loh AdrpLdr	Lloh274, Lloh275
	.loh AdrpLdr	Lloh272, Lloh273
	.loh AdrpAdrp	Lloh270, Lloh272
	.loh AdrpLdr	Lloh270, Lloh271
	.loh AdrpAdrp	Lloh268, Lloh270
	.loh AdrpLdr	Lloh268, Lloh269
	.loh AdrpAdrp	Lloh266, Lloh268
	.loh AdrpLdr	Lloh266, Lloh267
	.loh AdrpLdr	Lloh264, Lloh265
	.loh AdrpAdrp	Lloh262, Lloh264
	.loh AdrpLdr	Lloh262, Lloh263
	.loh AdrpAdrp	Lloh260, Lloh262
	.loh AdrpLdr	Lloh260, Lloh261
	.loh AdrpAdrp	Lloh258, Lloh260
	.loh AdrpLdr	Lloh258, Lloh259
	.loh AdrpLdr	Lloh256, Lloh257
	.loh AdrpAdrp	Lloh254, Lloh256
	.loh AdrpLdr	Lloh254, Lloh255
	.loh AdrpAdrp	Lloh252, Lloh254
	.loh AdrpLdr	Lloh252, Lloh253
	.loh AdrpAdrp	Lloh250, Lloh252
	.loh AdrpLdr	Lloh250, Lloh251
	.loh AdrpLdr	Lloh248, Lloh249
	.loh AdrpAdrp	Lloh246, Lloh248
	.loh AdrpLdr	Lloh246, Lloh247
	.loh AdrpAdrp	Lloh244, Lloh246
	.loh AdrpLdr	Lloh244, Lloh245
	.loh AdrpAdrp	Lloh242, Lloh244
	.loh AdrpLdr	Lloh242, Lloh243
	.loh AdrpLdr	Lloh240, Lloh241
	.loh AdrpAdrp	Lloh238, Lloh240
	.loh AdrpLdr	Lloh238, Lloh239
	.loh AdrpAdrp	Lloh236, Lloh238
	.loh AdrpLdr	Lloh236, Lloh237
	.loh AdrpAdrp	Lloh234, Lloh236
	.loh AdrpLdr	Lloh234, Lloh235
	.loh AdrpLdr	Lloh232, Lloh233
	.loh AdrpAdrp	Lloh230, Lloh232
	.loh AdrpLdr	Lloh230, Lloh231
	.loh AdrpAdrp	Lloh228, Lloh230
	.loh AdrpLdr	Lloh228, Lloh229
	.loh AdrpAdrp	Lloh226, Lloh228
	.loh AdrpLdr	Lloh226, Lloh227
	.loh AdrpLdr	Lloh224, Lloh225
	.loh AdrpAdrp	Lloh222, Lloh224
	.loh AdrpLdr	Lloh222, Lloh223
	.loh AdrpAdrp	Lloh220, Lloh222
	.loh AdrpLdr	Lloh220, Lloh221
	.loh AdrpAdrp	Lloh218, Lloh220
	.loh AdrpLdr	Lloh218, Lloh219
	.loh AdrpLdr	Lloh216, Lloh217
	.loh AdrpAdrp	Lloh214, Lloh216
	.loh AdrpLdr	Lloh214, Lloh215
	.loh AdrpAdrp	Lloh212, Lloh214
	.loh AdrpLdr	Lloh212, Lloh213
	.loh AdrpAdrp	Lloh210, Lloh212
	.loh AdrpLdr	Lloh210, Lloh211
	.loh AdrpLdr	Lloh208, Lloh209
	.loh AdrpAdrp	Lloh206, Lloh208
	.loh AdrpLdr	Lloh206, Lloh207
	.loh AdrpAdrp	Lloh204, Lloh206
	.loh AdrpLdr	Lloh204, Lloh205
	.loh AdrpAdrp	Lloh202, Lloh204
	.loh AdrpLdr	Lloh202, Lloh203
	.loh AdrpLdr	Lloh200, Lloh201
	.loh AdrpAdrp	Lloh198, Lloh200
	.loh AdrpLdr	Lloh198, Lloh199
	.loh AdrpAdrp	Lloh196, Lloh198
	.loh AdrpLdr	Lloh196, Lloh197
	.loh AdrpAdrp	Lloh194, Lloh196
	.loh AdrpLdr	Lloh194, Lloh195
	.loh AdrpLdr	Lloh192, Lloh193
	.loh AdrpAdrp	Lloh190, Lloh192
	.loh AdrpLdr	Lloh190, Lloh191
	.loh AdrpAdrp	Lloh188, Lloh190
	.loh AdrpLdr	Lloh188, Lloh189
	.loh AdrpAdrp	Lloh186, Lloh188
	.loh AdrpLdr	Lloh186, Lloh187
	.loh AdrpLdr	Lloh184, Lloh185
	.loh AdrpAdrp	Lloh182, Lloh184
	.loh AdrpLdr	Lloh182, Lloh183
	.loh AdrpAdrp	Lloh180, Lloh182
	.loh AdrpLdr	Lloh180, Lloh181
	.loh AdrpAdrp	Lloh178, Lloh180
	.loh AdrpLdr	Lloh178, Lloh179
	.loh AdrpLdr	Lloh176, Lloh177
	.loh AdrpAdrp	Lloh174, Lloh176
	.loh AdrpLdr	Lloh174, Lloh175
	.loh AdrpAdrp	Lloh172, Lloh174
	.loh AdrpLdr	Lloh172, Lloh173
	.loh AdrpAdrp	Lloh170, Lloh172
	.loh AdrpLdr	Lloh170, Lloh171
	.loh AdrpLdr	Lloh168, Lloh169
	.loh AdrpAdrp	Lloh166, Lloh168
	.loh AdrpLdr	Lloh166, Lloh167
	.loh AdrpAdrp	Lloh164, Lloh166
	.loh AdrpLdr	Lloh164, Lloh165
	.loh AdrpAdrp	Lloh162, Lloh164
	.loh AdrpLdr	Lloh162, Lloh163
	.loh AdrpLdr	Lloh160, Lloh161
	.loh AdrpAdrp	Lloh158, Lloh160
	.loh AdrpLdr	Lloh158, Lloh159
	.loh AdrpAdrp	Lloh156, Lloh158
	.loh AdrpLdr	Lloh156, Lloh157
	.loh AdrpAdrp	Lloh154, Lloh156
	.loh AdrpLdr	Lloh154, Lloh155
	.loh AdrpLdr	Lloh152, Lloh153
	.loh AdrpAdrp	Lloh150, Lloh152
	.loh AdrpLdr	Lloh150, Lloh151
	.loh AdrpAdrp	Lloh148, Lloh150
	.loh AdrpLdr	Lloh148, Lloh149
	.loh AdrpAdrp	Lloh146, Lloh148
	.loh AdrpLdr	Lloh146, Lloh147
	.loh AdrpLdr	Lloh144, Lloh145
	.loh AdrpAdrp	Lloh142, Lloh144
	.loh AdrpLdr	Lloh142, Lloh143
	.loh AdrpAdrp	Lloh140, Lloh142
	.loh AdrpLdr	Lloh140, Lloh141
	.loh AdrpAdrp	Lloh138, Lloh140
	.loh AdrpLdr	Lloh138, Lloh139
	.loh AdrpLdr	Lloh136, Lloh137
	.loh AdrpAdrp	Lloh134, Lloh136
	.loh AdrpLdr	Lloh134, Lloh135
	.loh AdrpAdrp	Lloh132, Lloh134
	.loh AdrpLdr	Lloh132, Lloh133
	.loh AdrpAdrp	Lloh130, Lloh132
	.loh AdrpLdr	Lloh130, Lloh131
	.loh AdrpLdr	Lloh128, Lloh129
	.loh AdrpAdrp	Lloh126, Lloh128
	.loh AdrpLdr	Lloh126, Lloh127
	.loh AdrpAdrp	Lloh124, Lloh126
	.loh AdrpLdr	Lloh124, Lloh125
	.loh AdrpAdrp	Lloh122, Lloh124
	.loh AdrpLdr	Lloh122, Lloh123
	.loh AdrpLdr	Lloh120, Lloh121
	.loh AdrpAdrp	Lloh118, Lloh120
	.loh AdrpLdr	Lloh118, Lloh119
	.loh AdrpAdrp	Lloh116, Lloh118
	.loh AdrpLdr	Lloh116, Lloh117
	.loh AdrpAdrp	Lloh114, Lloh116
	.loh AdrpLdr	Lloh114, Lloh115
	.loh AdrpLdr	Lloh112, Lloh113
	.loh AdrpAdrp	Lloh110, Lloh112
	.loh AdrpLdr	Lloh110, Lloh111
	.loh AdrpAdrp	Lloh108, Lloh110
	.loh AdrpLdr	Lloh108, Lloh109
	.loh AdrpAdrp	Lloh106, Lloh108
	.loh AdrpLdr	Lloh106, Lloh107
	.loh AdrpLdr	Lloh104, Lloh105
	.loh AdrpAdrp	Lloh102, Lloh104
	.loh AdrpLdr	Lloh102, Lloh103
	.loh AdrpAdrp	Lloh100, Lloh102
	.loh AdrpLdr	Lloh100, Lloh101
	.loh AdrpAdrp	Lloh98, Lloh100
	.loh AdrpLdr	Lloh98, Lloh99
	.loh AdrpLdr	Lloh96, Lloh97
	.loh AdrpAdrp	Lloh94, Lloh96
	.loh AdrpLdr	Lloh94, Lloh95
	.loh AdrpAdrp	Lloh92, Lloh94
	.loh AdrpLdr	Lloh92, Lloh93
	.loh AdrpAdrp	Lloh90, Lloh92
	.loh AdrpLdr	Lloh90, Lloh91
	.loh AdrpLdr	Lloh88, Lloh89
	.loh AdrpAdrp	Lloh86, Lloh88
	.loh AdrpLdr	Lloh86, Lloh87
	.loh AdrpAdrp	Lloh84, Lloh86
	.loh AdrpLdr	Lloh84, Lloh85
	.loh AdrpAdrp	Lloh82, Lloh84
	.loh AdrpLdr	Lloh82, Lloh83
	.loh AdrpLdr	Lloh80, Lloh81
	.loh AdrpAdrp	Lloh78, Lloh80
	.loh AdrpLdr	Lloh78, Lloh79
	.loh AdrpAdrp	Lloh76, Lloh78
	.loh AdrpLdr	Lloh76, Lloh77
	.loh AdrpAdrp	Lloh74, Lloh76
	.loh AdrpLdr	Lloh74, Lloh75
	.loh AdrpLdr	Lloh72, Lloh73
	.loh AdrpAdrp	Lloh70, Lloh72
	.loh AdrpLdr	Lloh70, Lloh71
	.loh AdrpAdrp	Lloh68, Lloh70
	.loh AdrpLdr	Lloh68, Lloh69
	.loh AdrpAdrp	Lloh66, Lloh68
	.loh AdrpLdr	Lloh66, Lloh67
	.loh AdrpLdr	Lloh64, Lloh65
	.loh AdrpAdrp	Lloh62, Lloh64
	.loh AdrpLdr	Lloh62, Lloh63
	.loh AdrpAdrp	Lloh60, Lloh62
	.loh AdrpLdr	Lloh60, Lloh61
	.loh AdrpAdrp	Lloh58, Lloh60
	.loh AdrpLdr	Lloh58, Lloh59
	.loh AdrpLdr	Lloh56, Lloh57
	.loh AdrpAdrp	Lloh54, Lloh56
	.loh AdrpLdr	Lloh54, Lloh55
	.loh AdrpAdrp	Lloh52, Lloh54
	.loh AdrpLdr	Lloh52, Lloh53
	.loh AdrpAdrp	Lloh50, Lloh52
	.loh AdrpLdr	Lloh50, Lloh51
	.loh AdrpLdr	Lloh48, Lloh49
	.loh AdrpAdrp	Lloh46, Lloh48
	.loh AdrpLdr	Lloh46, Lloh47
	.loh AdrpAdrp	Lloh44, Lloh46
	.loh AdrpLdr	Lloh44, Lloh45
	.loh AdrpAdrp	Lloh42, Lloh44
	.loh AdrpLdr	Lloh42, Lloh43
	.loh AdrpLdr	Lloh312, Lloh313
	.loh AdrpAdrp	Lloh310, Lloh312
	.loh AdrpLdr	Lloh310, Lloh311
	.loh AdrpAdrp	Lloh308, Lloh310
	.loh AdrpLdr	Lloh308, Lloh309
	.loh AdrpAdrp	Lloh306, Lloh308
	.loh AdrpLdr	Lloh306, Lloh307
	.loh AdrpLdr	Lloh576, Lloh577
	.loh AdrpAdrp	Lloh574, Lloh576
	.loh AdrpLdr	Lloh574, Lloh575
	.loh AdrpAdrp	Lloh572, Lloh574
	.loh AdrpLdr	Lloh572, Lloh573
	.loh AdrpAdrp	Lloh570, Lloh572
	.loh AdrpLdr	Lloh570, Lloh571
	.loh AdrpLdr	Lloh568, Lloh569
	.loh AdrpAdrp	Lloh566, Lloh568
	.loh AdrpLdr	Lloh566, Lloh567
	.loh AdrpAdrp	Lloh564, Lloh566
	.loh AdrpLdr	Lloh564, Lloh565
	.loh AdrpAdrp	Lloh562, Lloh564
	.loh AdrpLdr	Lloh562, Lloh563
	.loh AdrpLdr	Lloh560, Lloh561
	.loh AdrpAdrp	Lloh558, Lloh560
	.loh AdrpLdr	Lloh558, Lloh559
	.loh AdrpAdrp	Lloh556, Lloh558
	.loh AdrpLdr	Lloh556, Lloh557
	.loh AdrpAdrp	Lloh554, Lloh556
	.loh AdrpLdr	Lloh554, Lloh555
	.loh AdrpLdr	Lloh552, Lloh553
	.loh AdrpAdrp	Lloh550, Lloh552
	.loh AdrpLdr	Lloh550, Lloh551
	.loh AdrpAdrp	Lloh548, Lloh550
	.loh AdrpLdr	Lloh548, Lloh549
	.loh AdrpAdrp	Lloh546, Lloh548
	.loh AdrpLdr	Lloh546, Lloh547
	.loh AdrpLdr	Lloh544, Lloh545
	.loh AdrpAdrp	Lloh542, Lloh544
	.loh AdrpLdr	Lloh542, Lloh543
	.loh AdrpAdrp	Lloh540, Lloh542
	.loh AdrpLdr	Lloh540, Lloh541
	.loh AdrpAdrp	Lloh538, Lloh540
	.loh AdrpLdr	Lloh538, Lloh539
	.loh AdrpLdr	Lloh536, Lloh537
	.loh AdrpAdrp	Lloh534, Lloh536
	.loh AdrpLdr	Lloh534, Lloh535
	.loh AdrpAdrp	Lloh532, Lloh534
	.loh AdrpLdr	Lloh532, Lloh533
	.loh AdrpAdrp	Lloh530, Lloh532
	.loh AdrpLdr	Lloh530, Lloh531
	.loh AdrpLdr	Lloh528, Lloh529
	.loh AdrpAdrp	Lloh526, Lloh528
	.loh AdrpLdr	Lloh526, Lloh527
	.loh AdrpAdrp	Lloh524, Lloh526
	.loh AdrpLdr	Lloh524, Lloh525
	.loh AdrpAdrp	Lloh522, Lloh524
	.loh AdrpLdr	Lloh522, Lloh523
	.loh AdrpLdr	Lloh520, Lloh521
	.loh AdrpAdrp	Lloh518, Lloh520
	.loh AdrpLdr	Lloh518, Lloh519
	.loh AdrpAdrp	Lloh516, Lloh518
	.loh AdrpLdr	Lloh516, Lloh517
	.loh AdrpAdrp	Lloh514, Lloh516
	.loh AdrpLdr	Lloh514, Lloh515
	.loh AdrpLdr	Lloh512, Lloh513
	.loh AdrpAdrp	Lloh510, Lloh512
	.loh AdrpLdr	Lloh510, Lloh511
	.loh AdrpAdrp	Lloh508, Lloh510
	.loh AdrpLdr	Lloh508, Lloh509
	.loh AdrpAdrp	Lloh506, Lloh508
	.loh AdrpLdr	Lloh506, Lloh507
	.loh AdrpLdr	Lloh504, Lloh505
	.loh AdrpAdrp	Lloh502, Lloh504
	.loh AdrpLdr	Lloh502, Lloh503
	.loh AdrpAdrp	Lloh500, Lloh502
	.loh AdrpLdr	Lloh500, Lloh501
	.loh AdrpAdrp	Lloh498, Lloh500
	.loh AdrpLdr	Lloh498, Lloh499
	.loh AdrpLdr	Lloh496, Lloh497
	.loh AdrpAdrp	Lloh494, Lloh496
	.loh AdrpLdr	Lloh494, Lloh495
	.loh AdrpAdrp	Lloh492, Lloh494
	.loh AdrpLdr	Lloh492, Lloh493
	.loh AdrpAdrp	Lloh490, Lloh492
	.loh AdrpLdr	Lloh490, Lloh491
	.loh AdrpLdr	Lloh488, Lloh489
	.loh AdrpAdrp	Lloh486, Lloh488
	.loh AdrpLdr	Lloh486, Lloh487
	.loh AdrpAdrp	Lloh484, Lloh486
	.loh AdrpLdr	Lloh484, Lloh485
	.loh AdrpAdrp	Lloh482, Lloh484
	.loh AdrpLdr	Lloh482, Lloh483
	.loh AdrpLdr	Lloh480, Lloh481
	.loh AdrpAdrp	Lloh478, Lloh480
	.loh AdrpLdr	Lloh478, Lloh479
	.loh AdrpAdrp	Lloh476, Lloh478
	.loh AdrpLdr	Lloh476, Lloh477
	.loh AdrpAdrp	Lloh474, Lloh476
	.loh AdrpLdr	Lloh474, Lloh475
	.loh AdrpLdr	Lloh472, Lloh473
	.loh AdrpAdrp	Lloh470, Lloh472
	.loh AdrpLdr	Lloh470, Lloh471
	.loh AdrpAdrp	Lloh468, Lloh470
	.loh AdrpLdr	Lloh468, Lloh469
	.loh AdrpAdrp	Lloh466, Lloh468
	.loh AdrpLdr	Lloh466, Lloh467
	.loh AdrpLdr	Lloh464, Lloh465
	.loh AdrpAdrp	Lloh462, Lloh464
	.loh AdrpLdr	Lloh462, Lloh463
	.loh AdrpAdrp	Lloh460, Lloh462
	.loh AdrpLdr	Lloh460, Lloh461
	.loh AdrpAdrp	Lloh458, Lloh460
	.loh AdrpLdr	Lloh458, Lloh459
	.loh AdrpLdr	Lloh456, Lloh457
	.loh AdrpAdrp	Lloh454, Lloh456
	.loh AdrpLdr	Lloh454, Lloh455
	.loh AdrpAdrp	Lloh452, Lloh454
	.loh AdrpLdr	Lloh452, Lloh453
	.loh AdrpAdrp	Lloh450, Lloh452
	.loh AdrpLdr	Lloh450, Lloh451
	.loh AdrpLdr	Lloh448, Lloh449
	.loh AdrpAdrp	Lloh446, Lloh448
	.loh AdrpLdr	Lloh446, Lloh447
	.loh AdrpAdrp	Lloh444, Lloh446
	.loh AdrpLdr	Lloh444, Lloh445
	.loh AdrpAdrp	Lloh442, Lloh444
	.loh AdrpLdr	Lloh442, Lloh443
	.loh AdrpLdr	Lloh440, Lloh441
	.loh AdrpAdrp	Lloh438, Lloh440
	.loh AdrpLdr	Lloh438, Lloh439
	.loh AdrpAdrp	Lloh436, Lloh438
	.loh AdrpLdr	Lloh436, Lloh437
	.loh AdrpAdrp	Lloh434, Lloh436
	.loh AdrpLdr	Lloh434, Lloh435
	.loh AdrpLdr	Lloh432, Lloh433
	.loh AdrpAdrp	Lloh430, Lloh432
	.loh AdrpLdr	Lloh430, Lloh431
	.loh AdrpAdrp	Lloh428, Lloh430
	.loh AdrpLdr	Lloh428, Lloh429
	.loh AdrpAdrp	Lloh426, Lloh428
	.loh AdrpLdr	Lloh426, Lloh427
	.loh AdrpLdr	Lloh424, Lloh425
	.loh AdrpAdrp	Lloh422, Lloh424
	.loh AdrpLdr	Lloh422, Lloh423
	.loh AdrpAdrp	Lloh420, Lloh422
	.loh AdrpLdr	Lloh420, Lloh421
	.loh AdrpAdrp	Lloh418, Lloh420
	.loh AdrpLdr	Lloh418, Lloh419
	.loh AdrpLdr	Lloh416, Lloh417
	.loh AdrpAdrp	Lloh414, Lloh416
	.loh AdrpLdr	Lloh414, Lloh415
	.loh AdrpAdrp	Lloh412, Lloh414
	.loh AdrpLdr	Lloh412, Lloh413
	.loh AdrpAdrp	Lloh410, Lloh412
	.loh AdrpLdr	Lloh410, Lloh411
	.loh AdrpLdr	Lloh408, Lloh409
	.loh AdrpAdrp	Lloh406, Lloh408
	.loh AdrpLdr	Lloh406, Lloh407
	.loh AdrpAdrp	Lloh404, Lloh406
	.loh AdrpLdr	Lloh404, Lloh405
	.loh AdrpAdrp	Lloh402, Lloh404
	.loh AdrpLdr	Lloh402, Lloh403
	.loh AdrpLdr	Lloh400, Lloh401
	.loh AdrpAdrp	Lloh398, Lloh400
	.loh AdrpLdr	Lloh398, Lloh399
	.loh AdrpAdrp	Lloh396, Lloh398
	.loh AdrpLdr	Lloh396, Lloh397
	.loh AdrpAdrp	Lloh394, Lloh396
	.loh AdrpLdr	Lloh394, Lloh395
	.loh AdrpLdr	Lloh392, Lloh393
	.loh AdrpAdrp	Lloh390, Lloh392
	.loh AdrpLdr	Lloh390, Lloh391
	.loh AdrpAdrp	Lloh388, Lloh390
	.loh AdrpLdr	Lloh388, Lloh389
	.loh AdrpAdrp	Lloh386, Lloh388
	.loh AdrpLdr	Lloh386, Lloh387
	.loh AdrpLdr	Lloh384, Lloh385
	.loh AdrpAdrp	Lloh382, Lloh384
	.loh AdrpLdr	Lloh382, Lloh383
	.loh AdrpAdrp	Lloh380, Lloh382
	.loh AdrpLdr	Lloh380, Lloh381
	.loh AdrpAdrp	Lloh378, Lloh380
	.loh AdrpLdr	Lloh378, Lloh379
	.loh AdrpLdr	Lloh376, Lloh377
	.loh AdrpAdrp	Lloh374, Lloh376
	.loh AdrpLdr	Lloh374, Lloh375
	.loh AdrpAdrp	Lloh372, Lloh374
	.loh AdrpLdr	Lloh372, Lloh373
	.loh AdrpAdrp	Lloh370, Lloh372
	.loh AdrpLdr	Lloh370, Lloh371
	.loh AdrpLdr	Lloh368, Lloh369
	.loh AdrpAdrp	Lloh366, Lloh368
	.loh AdrpLdr	Lloh366, Lloh367
	.loh AdrpAdrp	Lloh364, Lloh366
	.loh AdrpLdr	Lloh364, Lloh365
	.loh AdrpAdrp	Lloh362, Lloh364
	.loh AdrpLdr	Lloh362, Lloh363
	.loh AdrpLdr	Lloh360, Lloh361
	.loh AdrpAdrp	Lloh358, Lloh360
	.loh AdrpLdr	Lloh358, Lloh359
	.loh AdrpAdrp	Lloh356, Lloh358
	.loh AdrpLdr	Lloh356, Lloh357
	.loh AdrpAdrp	Lloh354, Lloh356
	.loh AdrpLdr	Lloh354, Lloh355
	.loh AdrpLdr	Lloh352, Lloh353
	.loh AdrpAdrp	Lloh350, Lloh352
	.loh AdrpLdr	Lloh350, Lloh351
	.loh AdrpAdrp	Lloh348, Lloh350
	.loh AdrpLdr	Lloh348, Lloh349
	.loh AdrpAdrp	Lloh346, Lloh348
	.loh AdrpLdr	Lloh346, Lloh347
	.loh AdrpLdr	Lloh344, Lloh345
	.loh AdrpAdrp	Lloh342, Lloh344
	.loh AdrpLdr	Lloh342, Lloh343
	.loh AdrpAdrp	Lloh340, Lloh342
	.loh AdrpLdr	Lloh340, Lloh341
	.loh AdrpAdrp	Lloh338, Lloh340
	.loh AdrpLdr	Lloh338, Lloh339
	.loh AdrpLdr	Lloh336, Lloh337
	.loh AdrpAdrp	Lloh334, Lloh336
	.loh AdrpLdr	Lloh334, Lloh335
	.loh AdrpAdrp	Lloh332, Lloh334
	.loh AdrpLdr	Lloh332, Lloh333
	.loh AdrpAdrp	Lloh330, Lloh332
	.loh AdrpLdr	Lloh330, Lloh331
	.loh AdrpLdr	Lloh328, Lloh329
	.loh AdrpAdrp	Lloh326, Lloh328
	.loh AdrpLdr	Lloh326, Lloh327
	.loh AdrpAdrp	Lloh324, Lloh326
	.loh AdrpLdr	Lloh324, Lloh325
	.loh AdrpAdrp	Lloh322, Lloh324
	.loh AdrpLdr	Lloh322, Lloh323
	.loh AdrpLdr	Lloh320, Lloh321
	.loh AdrpAdrp	Lloh318, Lloh320
	.loh AdrpLdr	Lloh318, Lloh319
	.loh AdrpAdrp	Lloh316, Lloh318
	.loh AdrpLdr	Lloh316, Lloh317
	.loh AdrpAdrp	Lloh314, Lloh316
	.loh AdrpLdr	Lloh314, Lloh315
	.loh AdrpLdr	Lloh584, Lloh585
	.loh AdrpAdrp	Lloh582, Lloh584
	.loh AdrpLdr	Lloh582, Lloh583
	.loh AdrpAdrp	Lloh580, Lloh582
	.loh AdrpLdr	Lloh580, Lloh581
	.loh AdrpAdrp	Lloh578, Lloh580
	.loh AdrpLdr	Lloh578, Lloh579
	.loh AdrpLdr	Lloh848, Lloh849
	.loh AdrpAdrp	Lloh846, Lloh848
	.loh AdrpLdr	Lloh846, Lloh847
	.loh AdrpAdrp	Lloh844, Lloh846
	.loh AdrpLdr	Lloh844, Lloh845
	.loh AdrpAdrp	Lloh842, Lloh844
	.loh AdrpLdr	Lloh842, Lloh843
	.loh AdrpLdr	Lloh840, Lloh841
	.loh AdrpAdrp	Lloh838, Lloh840
	.loh AdrpLdr	Lloh838, Lloh839
	.loh AdrpAdrp	Lloh836, Lloh838
	.loh AdrpLdr	Lloh836, Lloh837
	.loh AdrpAdrp	Lloh834, Lloh836
	.loh AdrpLdr	Lloh834, Lloh835
	.loh AdrpLdr	Lloh832, Lloh833
	.loh AdrpAdrp	Lloh830, Lloh832
	.loh AdrpLdr	Lloh830, Lloh831
	.loh AdrpAdrp	Lloh828, Lloh830
	.loh AdrpLdr	Lloh828, Lloh829
	.loh AdrpAdrp	Lloh826, Lloh828
	.loh AdrpLdr	Lloh826, Lloh827
	.loh AdrpLdr	Lloh824, Lloh825
	.loh AdrpAdrp	Lloh822, Lloh824
	.loh AdrpLdr	Lloh822, Lloh823
	.loh AdrpAdrp	Lloh820, Lloh822
	.loh AdrpLdr	Lloh820, Lloh821
	.loh AdrpAdrp	Lloh818, Lloh820
	.loh AdrpLdr	Lloh818, Lloh819
	.loh AdrpLdr	Lloh816, Lloh817
	.loh AdrpAdrp	Lloh814, Lloh816
	.loh AdrpLdr	Lloh814, Lloh815
	.loh AdrpAdrp	Lloh812, Lloh814
	.loh AdrpLdr	Lloh812, Lloh813
	.loh AdrpAdrp	Lloh810, Lloh812
	.loh AdrpLdr	Lloh810, Lloh811
	.loh AdrpLdr	Lloh808, Lloh809
	.loh AdrpAdrp	Lloh806, Lloh808
	.loh AdrpLdr	Lloh806, Lloh807
	.loh AdrpAdrp	Lloh804, Lloh806
	.loh AdrpLdr	Lloh804, Lloh805
	.loh AdrpAdrp	Lloh802, Lloh804
	.loh AdrpLdr	Lloh802, Lloh803
	.loh AdrpLdr	Lloh800, Lloh801
	.loh AdrpAdrp	Lloh798, Lloh800
	.loh AdrpLdr	Lloh798, Lloh799
	.loh AdrpAdrp	Lloh796, Lloh798
	.loh AdrpLdr	Lloh796, Lloh797
	.loh AdrpAdrp	Lloh794, Lloh796
	.loh AdrpLdr	Lloh794, Lloh795
	.loh AdrpLdr	Lloh792, Lloh793
	.loh AdrpAdrp	Lloh790, Lloh792
	.loh AdrpLdr	Lloh790, Lloh791
	.loh AdrpAdrp	Lloh788, Lloh790
	.loh AdrpLdr	Lloh788, Lloh789
	.loh AdrpAdrp	Lloh786, Lloh788
	.loh AdrpLdr	Lloh786, Lloh787
	.loh AdrpLdr	Lloh784, Lloh785
	.loh AdrpAdrp	Lloh782, Lloh784
	.loh AdrpLdr	Lloh782, Lloh783
	.loh AdrpAdrp	Lloh780, Lloh782
	.loh AdrpLdr	Lloh780, Lloh781
	.loh AdrpAdrp	Lloh778, Lloh780
	.loh AdrpLdr	Lloh778, Lloh779
	.loh AdrpLdr	Lloh776, Lloh777
	.loh AdrpAdrp	Lloh774, Lloh776
	.loh AdrpLdr	Lloh774, Lloh775
	.loh AdrpAdrp	Lloh772, Lloh774
	.loh AdrpLdr	Lloh772, Lloh773
	.loh AdrpAdrp	Lloh770, Lloh772
	.loh AdrpLdr	Lloh770, Lloh771
	.loh AdrpLdr	Lloh768, Lloh769
	.loh AdrpAdrp	Lloh766, Lloh768
	.loh AdrpLdr	Lloh766, Lloh767
	.loh AdrpAdrp	Lloh764, Lloh766
	.loh AdrpLdr	Lloh764, Lloh765
	.loh AdrpAdrp	Lloh762, Lloh764
	.loh AdrpLdr	Lloh762, Lloh763
	.loh AdrpLdr	Lloh760, Lloh761
	.loh AdrpAdrp	Lloh758, Lloh760
	.loh AdrpLdr	Lloh758, Lloh759
	.loh AdrpAdrp	Lloh756, Lloh758
	.loh AdrpLdr	Lloh756, Lloh757
	.loh AdrpAdrp	Lloh754, Lloh756
	.loh AdrpLdr	Lloh754, Lloh755
	.loh AdrpLdr	Lloh752, Lloh753
	.loh AdrpAdrp	Lloh750, Lloh752
	.loh AdrpLdr	Lloh750, Lloh751
	.loh AdrpAdrp	Lloh748, Lloh750
	.loh AdrpLdr	Lloh748, Lloh749
	.loh AdrpAdrp	Lloh746, Lloh748
	.loh AdrpLdr	Lloh746, Lloh747
	.loh AdrpLdr	Lloh744, Lloh745
	.loh AdrpAdrp	Lloh742, Lloh744
	.loh AdrpLdr	Lloh742, Lloh743
	.loh AdrpAdrp	Lloh740, Lloh742
	.loh AdrpLdr	Lloh740, Lloh741
	.loh AdrpAdrp	Lloh738, Lloh740
	.loh AdrpLdr	Lloh738, Lloh739
	.loh AdrpLdr	Lloh736, Lloh737
	.loh AdrpAdrp	Lloh734, Lloh736
	.loh AdrpLdr	Lloh734, Lloh735
	.loh AdrpAdrp	Lloh732, Lloh734
	.loh AdrpLdr	Lloh732, Lloh733
	.loh AdrpAdrp	Lloh730, Lloh732
	.loh AdrpLdr	Lloh730, Lloh731
	.loh AdrpLdr	Lloh728, Lloh729
	.loh AdrpAdrp	Lloh726, Lloh728
	.loh AdrpLdr	Lloh726, Lloh727
	.loh AdrpAdrp	Lloh724, Lloh726
	.loh AdrpLdr	Lloh724, Lloh725
	.loh AdrpAdrp	Lloh722, Lloh724
	.loh AdrpLdr	Lloh722, Lloh723
	.loh AdrpLdr	Lloh720, Lloh721
	.loh AdrpAdrp	Lloh718, Lloh720
	.loh AdrpLdr	Lloh718, Lloh719
	.loh AdrpAdrp	Lloh716, Lloh718
	.loh AdrpLdr	Lloh716, Lloh717
	.loh AdrpAdrp	Lloh714, Lloh716
	.loh AdrpLdr	Lloh714, Lloh715
	.loh AdrpLdr	Lloh712, Lloh713
	.loh AdrpAdrp	Lloh710, Lloh712
	.loh AdrpLdr	Lloh710, Lloh711
	.loh AdrpAdrp	Lloh708, Lloh710
	.loh AdrpLdr	Lloh708, Lloh709
	.loh AdrpAdrp	Lloh706, Lloh708
	.loh AdrpLdr	Lloh706, Lloh707
	.loh AdrpLdr	Lloh704, Lloh705
	.loh AdrpAdrp	Lloh702, Lloh704
	.loh AdrpLdr	Lloh702, Lloh703
	.loh AdrpAdrp	Lloh700, Lloh702
	.loh AdrpLdr	Lloh700, Lloh701
	.loh AdrpAdrp	Lloh698, Lloh700
	.loh AdrpLdr	Lloh698, Lloh699
	.loh AdrpLdr	Lloh696, Lloh697
	.loh AdrpAdrp	Lloh694, Lloh696
	.loh AdrpLdr	Lloh694, Lloh695
	.loh AdrpAdrp	Lloh692, Lloh694
	.loh AdrpLdr	Lloh692, Lloh693
	.loh AdrpAdrp	Lloh690, Lloh692
	.loh AdrpLdr	Lloh690, Lloh691
	.loh AdrpLdr	Lloh688, Lloh689
	.loh AdrpAdrp	Lloh686, Lloh688
	.loh AdrpLdr	Lloh686, Lloh687
	.loh AdrpAdrp	Lloh684, Lloh686
	.loh AdrpLdr	Lloh684, Lloh685
	.loh AdrpAdrp	Lloh682, Lloh684
	.loh AdrpLdr	Lloh682, Lloh683
	.loh AdrpLdr	Lloh680, Lloh681
	.loh AdrpAdrp	Lloh678, Lloh680
	.loh AdrpLdr	Lloh678, Lloh679
	.loh AdrpAdrp	Lloh676, Lloh678
	.loh AdrpLdr	Lloh676, Lloh677
	.loh AdrpAdrp	Lloh674, Lloh676
	.loh AdrpLdr	Lloh674, Lloh675
	.loh AdrpLdr	Lloh672, Lloh673
	.loh AdrpAdrp	Lloh670, Lloh672
	.loh AdrpLdr	Lloh670, Lloh671
	.loh AdrpAdrp	Lloh668, Lloh670
	.loh AdrpLdr	Lloh668, Lloh669
	.loh AdrpAdrp	Lloh666, Lloh668
	.loh AdrpLdr	Lloh666, Lloh667
	.loh AdrpLdr	Lloh664, Lloh665
	.loh AdrpAdrp	Lloh662, Lloh664
	.loh AdrpLdr	Lloh662, Lloh663
	.loh AdrpAdrp	Lloh660, Lloh662
	.loh AdrpLdr	Lloh660, Lloh661
	.loh AdrpAdrp	Lloh658, Lloh660
	.loh AdrpLdr	Lloh658, Lloh659
	.loh AdrpLdr	Lloh656, Lloh657
	.loh AdrpAdrp	Lloh654, Lloh656
	.loh AdrpLdr	Lloh654, Lloh655
	.loh AdrpAdrp	Lloh652, Lloh654
	.loh AdrpLdr	Lloh652, Lloh653
	.loh AdrpAdrp	Lloh650, Lloh652
	.loh AdrpLdr	Lloh650, Lloh651
	.loh AdrpLdr	Lloh648, Lloh649
	.loh AdrpAdrp	Lloh646, Lloh648
	.loh AdrpLdr	Lloh646, Lloh647
	.loh AdrpAdrp	Lloh644, Lloh646
	.loh AdrpLdr	Lloh644, Lloh645
	.loh AdrpAdrp	Lloh642, Lloh644
	.loh AdrpLdr	Lloh642, Lloh643
	.loh AdrpLdr	Lloh640, Lloh641
	.loh AdrpAdrp	Lloh638, Lloh640
	.loh AdrpLdr	Lloh638, Lloh639
	.loh AdrpAdrp	Lloh636, Lloh638
	.loh AdrpLdr	Lloh636, Lloh637
	.loh AdrpAdrp	Lloh634, Lloh636
	.loh AdrpLdr	Lloh634, Lloh635
	.loh AdrpLdr	Lloh632, Lloh633
	.loh AdrpAdrp	Lloh630, Lloh632
	.loh AdrpLdr	Lloh630, Lloh631
	.loh AdrpAdrp	Lloh628, Lloh630
	.loh AdrpLdr	Lloh628, Lloh629
	.loh AdrpAdrp	Lloh626, Lloh628
	.loh AdrpLdr	Lloh626, Lloh627
	.loh AdrpLdr	Lloh624, Lloh625
	.loh AdrpAdrp	Lloh622, Lloh624
	.loh AdrpLdr	Lloh622, Lloh623
	.loh AdrpAdrp	Lloh620, Lloh622
	.loh AdrpLdr	Lloh620, Lloh621
	.loh AdrpAdrp	Lloh618, Lloh620
	.loh AdrpLdr	Lloh618, Lloh619
	.loh AdrpLdr	Lloh616, Lloh617
	.loh AdrpAdrp	Lloh614, Lloh616
	.loh AdrpLdr	Lloh614, Lloh615
	.loh AdrpAdrp	Lloh612, Lloh614
	.loh AdrpLdr	Lloh612, Lloh613
	.loh AdrpAdrp	Lloh610, Lloh612
	.loh AdrpLdr	Lloh610, Lloh611
	.loh AdrpLdr	Lloh608, Lloh609
	.loh AdrpAdrp	Lloh606, Lloh608
	.loh AdrpLdr	Lloh606, Lloh607
	.loh AdrpAdrp	Lloh604, Lloh606
	.loh AdrpLdr	Lloh604, Lloh605
	.loh AdrpAdrp	Lloh602, Lloh604
	.loh AdrpLdr	Lloh602, Lloh603
	.loh AdrpLdr	Lloh600, Lloh601
	.loh AdrpAdrp	Lloh598, Lloh600
	.loh AdrpLdr	Lloh598, Lloh599
	.loh AdrpAdrp	Lloh596, Lloh598
	.loh AdrpLdr	Lloh596, Lloh597
	.loh AdrpAdrp	Lloh594, Lloh596
	.loh AdrpLdr	Lloh594, Lloh595
	.loh AdrpLdr	Lloh592, Lloh593
	.loh AdrpAdrp	Lloh590, Lloh592
	.loh AdrpLdr	Lloh590, Lloh591
	.loh AdrpAdrp	Lloh588, Lloh590
	.loh AdrpLdr	Lloh588, Lloh589
	.loh AdrpAdrp	Lloh586, Lloh588
	.loh AdrpLdr	Lloh586, Lloh587
	.loh AdrpLdr	Lloh856, Lloh857
	.loh AdrpAdrp	Lloh854, Lloh856
	.loh AdrpLdr	Lloh854, Lloh855
	.loh AdrpAdrp	Lloh852, Lloh854
	.loh AdrpLdr	Lloh852, Lloh853
	.loh AdrpAdrp	Lloh850, Lloh852
	.loh AdrpLdr	Lloh850, Lloh851
	.loh AdrpLdr	Lloh1120, Lloh1121
	.loh AdrpAdrp	Lloh1118, Lloh1120
	.loh AdrpLdr	Lloh1118, Lloh1119
	.loh AdrpAdrp	Lloh1116, Lloh1118
	.loh AdrpLdr	Lloh1116, Lloh1117
	.loh AdrpAdrp	Lloh1114, Lloh1116
	.loh AdrpLdr	Lloh1114, Lloh1115
	.loh AdrpLdr	Lloh1112, Lloh1113
	.loh AdrpAdrp	Lloh1110, Lloh1112
	.loh AdrpLdr	Lloh1110, Lloh1111
	.loh AdrpAdrp	Lloh1108, Lloh1110
	.loh AdrpLdr	Lloh1108, Lloh1109
	.loh AdrpAdrp	Lloh1106, Lloh1108
	.loh AdrpLdr	Lloh1106, Lloh1107
	.loh AdrpLdr	Lloh1104, Lloh1105
	.loh AdrpAdrp	Lloh1102, Lloh1104
	.loh AdrpLdr	Lloh1102, Lloh1103
	.loh AdrpAdrp	Lloh1100, Lloh1102
	.loh AdrpLdr	Lloh1100, Lloh1101
	.loh AdrpAdrp	Lloh1098, Lloh1100
	.loh AdrpLdr	Lloh1098, Lloh1099
	.loh AdrpLdr	Lloh1096, Lloh1097
	.loh AdrpAdrp	Lloh1094, Lloh1096
	.loh AdrpLdr	Lloh1094, Lloh1095
	.loh AdrpAdrp	Lloh1092, Lloh1094
	.loh AdrpLdr	Lloh1092, Lloh1093
	.loh AdrpAdrp	Lloh1090, Lloh1092
	.loh AdrpLdr	Lloh1090, Lloh1091
	.loh AdrpLdr	Lloh1088, Lloh1089
	.loh AdrpAdrp	Lloh1086, Lloh1088
	.loh AdrpLdr	Lloh1086, Lloh1087
	.loh AdrpAdrp	Lloh1084, Lloh1086
	.loh AdrpLdr	Lloh1084, Lloh1085
	.loh AdrpAdrp	Lloh1082, Lloh1084
	.loh AdrpLdr	Lloh1082, Lloh1083
	.loh AdrpLdr	Lloh1080, Lloh1081
	.loh AdrpAdrp	Lloh1078, Lloh1080
	.loh AdrpLdr	Lloh1078, Lloh1079
	.loh AdrpAdrp	Lloh1076, Lloh1078
	.loh AdrpLdr	Lloh1076, Lloh1077
	.loh AdrpAdrp	Lloh1074, Lloh1076
	.loh AdrpLdr	Lloh1074, Lloh1075
	.loh AdrpLdr	Lloh1072, Lloh1073
	.loh AdrpAdrp	Lloh1070, Lloh1072
	.loh AdrpLdr	Lloh1070, Lloh1071
	.loh AdrpAdrp	Lloh1068, Lloh1070
	.loh AdrpLdr	Lloh1068, Lloh1069
	.loh AdrpAdrp	Lloh1066, Lloh1068
	.loh AdrpLdr	Lloh1066, Lloh1067
	.loh AdrpLdr	Lloh1064, Lloh1065
	.loh AdrpAdrp	Lloh1062, Lloh1064
	.loh AdrpLdr	Lloh1062, Lloh1063
	.loh AdrpAdrp	Lloh1060, Lloh1062
	.loh AdrpLdr	Lloh1060, Lloh1061
	.loh AdrpAdrp	Lloh1058, Lloh1060
	.loh AdrpLdr	Lloh1058, Lloh1059
	.loh AdrpLdr	Lloh1056, Lloh1057
	.loh AdrpAdrp	Lloh1054, Lloh1056
	.loh AdrpLdr	Lloh1054, Lloh1055
	.loh AdrpAdrp	Lloh1052, Lloh1054
	.loh AdrpLdr	Lloh1052, Lloh1053
	.loh AdrpAdrp	Lloh1050, Lloh1052
	.loh AdrpLdr	Lloh1050, Lloh1051
	.loh AdrpLdr	Lloh1048, Lloh1049
	.loh AdrpAdrp	Lloh1046, Lloh1048
	.loh AdrpLdr	Lloh1046, Lloh1047
	.loh AdrpAdrp	Lloh1044, Lloh1046
	.loh AdrpLdr	Lloh1044, Lloh1045
	.loh AdrpAdrp	Lloh1042, Lloh1044
	.loh AdrpLdr	Lloh1042, Lloh1043
	.loh AdrpLdr	Lloh1040, Lloh1041
	.loh AdrpAdrp	Lloh1038, Lloh1040
	.loh AdrpLdr	Lloh1038, Lloh1039
	.loh AdrpAdrp	Lloh1036, Lloh1038
	.loh AdrpLdr	Lloh1036, Lloh1037
	.loh AdrpAdrp	Lloh1034, Lloh1036
	.loh AdrpLdr	Lloh1034, Lloh1035
	.loh AdrpLdr	Lloh1032, Lloh1033
	.loh AdrpAdrp	Lloh1030, Lloh1032
	.loh AdrpLdr	Lloh1030, Lloh1031
	.loh AdrpAdrp	Lloh1028, Lloh1030
	.loh AdrpLdr	Lloh1028, Lloh1029
	.loh AdrpAdrp	Lloh1026, Lloh1028
	.loh AdrpLdr	Lloh1026, Lloh1027
	.loh AdrpLdr	Lloh1024, Lloh1025
	.loh AdrpAdrp	Lloh1022, Lloh1024
	.loh AdrpLdr	Lloh1022, Lloh1023
	.loh AdrpAdrp	Lloh1020, Lloh1022
	.loh AdrpLdr	Lloh1020, Lloh1021
	.loh AdrpAdrp	Lloh1018, Lloh1020
	.loh AdrpLdr	Lloh1018, Lloh1019
	.loh AdrpLdr	Lloh1016, Lloh1017
	.loh AdrpAdrp	Lloh1014, Lloh1016
	.loh AdrpLdr	Lloh1014, Lloh1015
	.loh AdrpAdrp	Lloh1012, Lloh1014
	.loh AdrpLdr	Lloh1012, Lloh1013
	.loh AdrpAdrp	Lloh1010, Lloh1012
	.loh AdrpLdr	Lloh1010, Lloh1011
	.loh AdrpLdr	Lloh1008, Lloh1009
	.loh AdrpAdrp	Lloh1006, Lloh1008
	.loh AdrpLdr	Lloh1006, Lloh1007
	.loh AdrpAdrp	Lloh1004, Lloh1006
	.loh AdrpLdr	Lloh1004, Lloh1005
	.loh AdrpAdrp	Lloh1002, Lloh1004
	.loh AdrpLdr	Lloh1002, Lloh1003
	.loh AdrpLdr	Lloh1000, Lloh1001
	.loh AdrpAdrp	Lloh998, Lloh1000
	.loh AdrpLdr	Lloh998, Lloh999
	.loh AdrpAdrp	Lloh996, Lloh998
	.loh AdrpLdr	Lloh996, Lloh997
	.loh AdrpAdrp	Lloh994, Lloh996
	.loh AdrpLdr	Lloh994, Lloh995
	.loh AdrpLdr	Lloh992, Lloh993
	.loh AdrpAdrp	Lloh990, Lloh992
	.loh AdrpLdr	Lloh990, Lloh991
	.loh AdrpAdrp	Lloh988, Lloh990
	.loh AdrpLdr	Lloh988, Lloh989
	.loh AdrpAdrp	Lloh986, Lloh988
	.loh AdrpLdr	Lloh986, Lloh987
	.loh AdrpLdr	Lloh984, Lloh985
	.loh AdrpAdrp	Lloh982, Lloh984
	.loh AdrpLdr	Lloh982, Lloh983
	.loh AdrpAdrp	Lloh980, Lloh982
	.loh AdrpLdr	Lloh980, Lloh981
	.loh AdrpAdrp	Lloh978, Lloh980
	.loh AdrpLdr	Lloh978, Lloh979
	.loh AdrpLdr	Lloh976, Lloh977
	.loh AdrpAdrp	Lloh974, Lloh976
	.loh AdrpLdr	Lloh974, Lloh975
	.loh AdrpAdrp	Lloh972, Lloh974
	.loh AdrpLdr	Lloh972, Lloh973
	.loh AdrpAdrp	Lloh970, Lloh972
	.loh AdrpLdr	Lloh970, Lloh971
	.loh AdrpLdr	Lloh968, Lloh969
	.loh AdrpAdrp	Lloh966, Lloh968
	.loh AdrpLdr	Lloh966, Lloh967
	.loh AdrpAdrp	Lloh964, Lloh966
	.loh AdrpLdr	Lloh964, Lloh965
	.loh AdrpAdrp	Lloh962, Lloh964
	.loh AdrpLdr	Lloh962, Lloh963
	.loh AdrpLdr	Lloh960, Lloh961
	.loh AdrpAdrp	Lloh958, Lloh960
	.loh AdrpLdr	Lloh958, Lloh959
	.loh AdrpAdrp	Lloh956, Lloh958
	.loh AdrpLdr	Lloh956, Lloh957
	.loh AdrpAdrp	Lloh954, Lloh956
	.loh AdrpLdr	Lloh954, Lloh955
	.loh AdrpLdr	Lloh952, Lloh953
	.loh AdrpAdrp	Lloh950, Lloh952
	.loh AdrpLdr	Lloh950, Lloh951
	.loh AdrpAdrp	Lloh948, Lloh950
	.loh AdrpLdr	Lloh948, Lloh949
	.loh AdrpAdrp	Lloh946, Lloh948
	.loh AdrpLdr	Lloh946, Lloh947
	.loh AdrpLdr	Lloh944, Lloh945
	.loh AdrpAdrp	Lloh942, Lloh944
	.loh AdrpLdr	Lloh942, Lloh943
	.loh AdrpAdrp	Lloh940, Lloh942
	.loh AdrpLdr	Lloh940, Lloh941
	.loh AdrpAdrp	Lloh938, Lloh940
	.loh AdrpLdr	Lloh938, Lloh939
	.loh AdrpLdr	Lloh936, Lloh937
	.loh AdrpAdrp	Lloh934, Lloh936
	.loh AdrpLdr	Lloh934, Lloh935
	.loh AdrpAdrp	Lloh932, Lloh934
	.loh AdrpLdr	Lloh932, Lloh933
	.loh AdrpAdrp	Lloh930, Lloh932
	.loh AdrpLdr	Lloh930, Lloh931
	.loh AdrpLdr	Lloh928, Lloh929
	.loh AdrpAdrp	Lloh926, Lloh928
	.loh AdrpLdr	Lloh926, Lloh927
	.loh AdrpAdrp	Lloh924, Lloh926
	.loh AdrpLdr	Lloh924, Lloh925
	.loh AdrpAdrp	Lloh922, Lloh924
	.loh AdrpLdr	Lloh922, Lloh923
	.loh AdrpLdr	Lloh920, Lloh921
	.loh AdrpAdrp	Lloh918, Lloh920
	.loh AdrpLdr	Lloh918, Lloh919
	.loh AdrpAdrp	Lloh916, Lloh918
	.loh AdrpLdr	Lloh916, Lloh917
	.loh AdrpAdrp	Lloh914, Lloh916
	.loh AdrpLdr	Lloh914, Lloh915
	.loh AdrpLdr	Lloh912, Lloh913
	.loh AdrpAdrp	Lloh910, Lloh912
	.loh AdrpLdr	Lloh910, Lloh911
	.loh AdrpAdrp	Lloh908, Lloh910
	.loh AdrpLdr	Lloh908, Lloh909
	.loh AdrpAdrp	Lloh906, Lloh908
	.loh AdrpLdr	Lloh906, Lloh907
	.loh AdrpLdr	Lloh904, Lloh905
	.loh AdrpAdrp	Lloh902, Lloh904
	.loh AdrpLdr	Lloh902, Lloh903
	.loh AdrpAdrp	Lloh900, Lloh902
	.loh AdrpLdr	Lloh900, Lloh901
	.loh AdrpAdrp	Lloh898, Lloh900
	.loh AdrpLdr	Lloh898, Lloh899
	.loh AdrpLdr	Lloh896, Lloh897
	.loh AdrpAdrp	Lloh894, Lloh896
	.loh AdrpLdr	Lloh894, Lloh895
	.loh AdrpAdrp	Lloh892, Lloh894
	.loh AdrpLdr	Lloh892, Lloh893
	.loh AdrpAdrp	Lloh890, Lloh892
	.loh AdrpLdr	Lloh890, Lloh891
	.loh AdrpLdr	Lloh888, Lloh889
	.loh AdrpAdrp	Lloh886, Lloh888
	.loh AdrpLdr	Lloh886, Lloh887
	.loh AdrpAdrp	Lloh884, Lloh886
	.loh AdrpLdr	Lloh884, Lloh885
	.loh AdrpAdrp	Lloh882, Lloh884
	.loh AdrpLdr	Lloh882, Lloh883
	.loh AdrpLdr	Lloh880, Lloh881
	.loh AdrpAdrp	Lloh878, Lloh880
	.loh AdrpLdr	Lloh878, Lloh879
	.loh AdrpAdrp	Lloh876, Lloh878
	.loh AdrpLdr	Lloh876, Lloh877
	.loh AdrpAdrp	Lloh874, Lloh876
	.loh AdrpLdr	Lloh874, Lloh875
	.loh AdrpLdr	Lloh872, Lloh873
	.loh AdrpAdrp	Lloh870, Lloh872
	.loh AdrpLdr	Lloh870, Lloh871
	.loh AdrpAdrp	Lloh868, Lloh870
	.loh AdrpLdr	Lloh868, Lloh869
	.loh AdrpAdrp	Lloh866, Lloh868
	.loh AdrpLdr	Lloh866, Lloh867
	.loh AdrpLdr	Lloh864, Lloh865
	.loh AdrpAdrp	Lloh862, Lloh864
	.loh AdrpLdr	Lloh862, Lloh863
	.loh AdrpAdrp	Lloh860, Lloh862
	.loh AdrpLdr	Lloh860, Lloh861
	.loh AdrpAdrp	Lloh858, Lloh860
	.loh AdrpLdr	Lloh858, Lloh859
	.loh AdrpLdr	Lloh1128, Lloh1129
	.loh AdrpAdrp	Lloh1126, Lloh1128
	.loh AdrpLdr	Lloh1126, Lloh1127
	.loh AdrpAdrp	Lloh1124, Lloh1126
	.loh AdrpLdr	Lloh1124, Lloh1125
	.loh AdrpAdrp	Lloh1122, Lloh1124
	.loh AdrpLdr	Lloh1122, Lloh1123
	.loh AdrpLdr	Lloh1392, Lloh1393
	.loh AdrpAdrp	Lloh1390, Lloh1392
	.loh AdrpLdr	Lloh1390, Lloh1391
	.loh AdrpAdrp	Lloh1388, Lloh1390
	.loh AdrpLdr	Lloh1388, Lloh1389
	.loh AdrpAdrp	Lloh1386, Lloh1388
	.loh AdrpLdr	Lloh1386, Lloh1387
	.loh AdrpLdr	Lloh1384, Lloh1385
	.loh AdrpAdrp	Lloh1382, Lloh1384
	.loh AdrpLdr	Lloh1382, Lloh1383
	.loh AdrpAdrp	Lloh1380, Lloh1382
	.loh AdrpLdr	Lloh1380, Lloh1381
	.loh AdrpAdrp	Lloh1378, Lloh1380
	.loh AdrpLdr	Lloh1378, Lloh1379
	.loh AdrpLdr	Lloh1376, Lloh1377
	.loh AdrpAdrp	Lloh1374, Lloh1376
	.loh AdrpLdr	Lloh1374, Lloh1375
	.loh AdrpAdrp	Lloh1372, Lloh1374
	.loh AdrpLdr	Lloh1372, Lloh1373
	.loh AdrpAdrp	Lloh1370, Lloh1372
	.loh AdrpLdr	Lloh1370, Lloh1371
	.loh AdrpLdr	Lloh1368, Lloh1369
	.loh AdrpAdrp	Lloh1366, Lloh1368
	.loh AdrpLdr	Lloh1366, Lloh1367
	.loh AdrpAdrp	Lloh1364, Lloh1366
	.loh AdrpLdr	Lloh1364, Lloh1365
	.loh AdrpAdrp	Lloh1362, Lloh1364
	.loh AdrpLdr	Lloh1362, Lloh1363
	.loh AdrpLdr	Lloh1360, Lloh1361
	.loh AdrpAdrp	Lloh1358, Lloh1360
	.loh AdrpLdr	Lloh1358, Lloh1359
	.loh AdrpAdrp	Lloh1356, Lloh1358
	.loh AdrpLdr	Lloh1356, Lloh1357
	.loh AdrpAdrp	Lloh1354, Lloh1356
	.loh AdrpLdr	Lloh1354, Lloh1355
	.loh AdrpLdr	Lloh1352, Lloh1353
	.loh AdrpAdrp	Lloh1350, Lloh1352
	.loh AdrpLdr	Lloh1350, Lloh1351
	.loh AdrpAdrp	Lloh1348, Lloh1350
	.loh AdrpLdr	Lloh1348, Lloh1349
	.loh AdrpAdrp	Lloh1346, Lloh1348
	.loh AdrpLdr	Lloh1346, Lloh1347
	.loh AdrpLdr	Lloh1344, Lloh1345
	.loh AdrpAdrp	Lloh1342, Lloh1344
	.loh AdrpLdr	Lloh1342, Lloh1343
	.loh AdrpAdrp	Lloh1340, Lloh1342
	.loh AdrpLdr	Lloh1340, Lloh1341
	.loh AdrpAdrp	Lloh1338, Lloh1340
	.loh AdrpLdr	Lloh1338, Lloh1339
	.loh AdrpLdr	Lloh1336, Lloh1337
	.loh AdrpAdrp	Lloh1334, Lloh1336
	.loh AdrpLdr	Lloh1334, Lloh1335
	.loh AdrpAdrp	Lloh1332, Lloh1334
	.loh AdrpLdr	Lloh1332, Lloh1333
	.loh AdrpAdrp	Lloh1330, Lloh1332
	.loh AdrpLdr	Lloh1330, Lloh1331
	.loh AdrpLdr	Lloh1328, Lloh1329
	.loh AdrpAdrp	Lloh1326, Lloh1328
	.loh AdrpLdr	Lloh1326, Lloh1327
	.loh AdrpAdrp	Lloh1324, Lloh1326
	.loh AdrpLdr	Lloh1324, Lloh1325
	.loh AdrpAdrp	Lloh1322, Lloh1324
	.loh AdrpLdr	Lloh1322, Lloh1323
	.loh AdrpLdr	Lloh1320, Lloh1321
	.loh AdrpAdrp	Lloh1318, Lloh1320
	.loh AdrpLdr	Lloh1318, Lloh1319
	.loh AdrpAdrp	Lloh1316, Lloh1318
	.loh AdrpLdr	Lloh1316, Lloh1317
	.loh AdrpAdrp	Lloh1314, Lloh1316
	.loh AdrpLdr	Lloh1314, Lloh1315
	.loh AdrpLdr	Lloh1312, Lloh1313
	.loh AdrpAdrp	Lloh1310, Lloh1312
	.loh AdrpLdr	Lloh1310, Lloh1311
	.loh AdrpAdrp	Lloh1308, Lloh1310
	.loh AdrpLdr	Lloh1308, Lloh1309
	.loh AdrpAdrp	Lloh1306, Lloh1308
	.loh AdrpLdr	Lloh1306, Lloh1307
	.loh AdrpLdr	Lloh1304, Lloh1305
	.loh AdrpAdrp	Lloh1302, Lloh1304
	.loh AdrpLdr	Lloh1302, Lloh1303
	.loh AdrpAdrp	Lloh1300, Lloh1302
	.loh AdrpLdr	Lloh1300, Lloh1301
	.loh AdrpAdrp	Lloh1298, Lloh1300
	.loh AdrpLdr	Lloh1298, Lloh1299
	.loh AdrpLdr	Lloh1296, Lloh1297
	.loh AdrpAdrp	Lloh1294, Lloh1296
	.loh AdrpLdr	Lloh1294, Lloh1295
	.loh AdrpAdrp	Lloh1292, Lloh1294
	.loh AdrpLdr	Lloh1292, Lloh1293
	.loh AdrpAdrp	Lloh1290, Lloh1292
	.loh AdrpLdr	Lloh1290, Lloh1291
	.loh AdrpLdr	Lloh1288, Lloh1289
	.loh AdrpAdrp	Lloh1286, Lloh1288
	.loh AdrpLdr	Lloh1286, Lloh1287
	.loh AdrpAdrp	Lloh1284, Lloh1286
	.loh AdrpLdr	Lloh1284, Lloh1285
	.loh AdrpAdrp	Lloh1282, Lloh1284
	.loh AdrpLdr	Lloh1282, Lloh1283
	.loh AdrpLdr	Lloh1280, Lloh1281
	.loh AdrpAdrp	Lloh1278, Lloh1280
	.loh AdrpLdr	Lloh1278, Lloh1279
	.loh AdrpAdrp	Lloh1276, Lloh1278
	.loh AdrpLdr	Lloh1276, Lloh1277
	.loh AdrpAdrp	Lloh1274, Lloh1276
	.loh AdrpLdr	Lloh1274, Lloh1275
	.loh AdrpLdr	Lloh1272, Lloh1273
	.loh AdrpAdrp	Lloh1270, Lloh1272
	.loh AdrpLdr	Lloh1270, Lloh1271
	.loh AdrpAdrp	Lloh1268, Lloh1270
	.loh AdrpLdr	Lloh1268, Lloh1269
	.loh AdrpAdrp	Lloh1266, Lloh1268
	.loh AdrpLdr	Lloh1266, Lloh1267
	.loh AdrpLdr	Lloh1264, Lloh1265
	.loh AdrpAdrp	Lloh1262, Lloh1264
	.loh AdrpLdr	Lloh1262, Lloh1263
	.loh AdrpAdrp	Lloh1260, Lloh1262
	.loh AdrpLdr	Lloh1260, Lloh1261
	.loh AdrpAdrp	Lloh1258, Lloh1260
	.loh AdrpLdr	Lloh1258, Lloh1259
	.loh AdrpLdr	Lloh1256, Lloh1257
	.loh AdrpAdrp	Lloh1254, Lloh1256
	.loh AdrpLdr	Lloh1254, Lloh1255
	.loh AdrpAdrp	Lloh1252, Lloh1254
	.loh AdrpLdr	Lloh1252, Lloh1253
	.loh AdrpAdrp	Lloh1250, Lloh1252
	.loh AdrpLdr	Lloh1250, Lloh1251
	.loh AdrpLdr	Lloh1248, Lloh1249
	.loh AdrpAdrp	Lloh1246, Lloh1248
	.loh AdrpLdr	Lloh1246, Lloh1247
	.loh AdrpAdrp	Lloh1244, Lloh1246
	.loh AdrpLdr	Lloh1244, Lloh1245
	.loh AdrpAdrp	Lloh1242, Lloh1244
	.loh AdrpLdr	Lloh1242, Lloh1243
	.loh AdrpLdr	Lloh1240, Lloh1241
	.loh AdrpAdrp	Lloh1238, Lloh1240
	.loh AdrpLdr	Lloh1238, Lloh1239
	.loh AdrpAdrp	Lloh1236, Lloh1238
	.loh AdrpLdr	Lloh1236, Lloh1237
	.loh AdrpAdrp	Lloh1234, Lloh1236
	.loh AdrpLdr	Lloh1234, Lloh1235
	.loh AdrpLdr	Lloh1232, Lloh1233
	.loh AdrpAdrp	Lloh1230, Lloh1232
	.loh AdrpLdr	Lloh1230, Lloh1231
	.loh AdrpAdrp	Lloh1228, Lloh1230
	.loh AdrpLdr	Lloh1228, Lloh1229
	.loh AdrpAdrp	Lloh1226, Lloh1228
	.loh AdrpLdr	Lloh1226, Lloh1227
	.loh AdrpLdr	Lloh1224, Lloh1225
	.loh AdrpAdrp	Lloh1222, Lloh1224
	.loh AdrpLdr	Lloh1222, Lloh1223
	.loh AdrpAdrp	Lloh1220, Lloh1222
	.loh AdrpLdr	Lloh1220, Lloh1221
	.loh AdrpAdrp	Lloh1218, Lloh1220
	.loh AdrpLdr	Lloh1218, Lloh1219
	.loh AdrpLdr	Lloh1216, Lloh1217
	.loh AdrpAdrp	Lloh1214, Lloh1216
	.loh AdrpLdr	Lloh1214, Lloh1215
	.loh AdrpAdrp	Lloh1212, Lloh1214
	.loh AdrpLdr	Lloh1212, Lloh1213
	.loh AdrpAdrp	Lloh1210, Lloh1212
	.loh AdrpLdr	Lloh1210, Lloh1211
	.loh AdrpLdr	Lloh1208, Lloh1209
	.loh AdrpAdrp	Lloh1206, Lloh1208
	.loh AdrpLdr	Lloh1206, Lloh1207
	.loh AdrpAdrp	Lloh1204, Lloh1206
	.loh AdrpLdr	Lloh1204, Lloh1205
	.loh AdrpAdrp	Lloh1202, Lloh1204
	.loh AdrpLdr	Lloh1202, Lloh1203
	.loh AdrpLdr	Lloh1200, Lloh1201
	.loh AdrpAdrp	Lloh1198, Lloh1200
	.loh AdrpLdr	Lloh1198, Lloh1199
	.loh AdrpAdrp	Lloh1196, Lloh1198
	.loh AdrpLdr	Lloh1196, Lloh1197
	.loh AdrpAdrp	Lloh1194, Lloh1196
	.loh AdrpLdr	Lloh1194, Lloh1195
	.loh AdrpLdr	Lloh1192, Lloh1193
	.loh AdrpAdrp	Lloh1190, Lloh1192
	.loh AdrpLdr	Lloh1190, Lloh1191
	.loh AdrpAdrp	Lloh1188, Lloh1190
	.loh AdrpLdr	Lloh1188, Lloh1189
	.loh AdrpAdrp	Lloh1186, Lloh1188
	.loh AdrpLdr	Lloh1186, Lloh1187
	.loh AdrpLdr	Lloh1184, Lloh1185
	.loh AdrpAdrp	Lloh1182, Lloh1184
	.loh AdrpLdr	Lloh1182, Lloh1183
	.loh AdrpAdrp	Lloh1180, Lloh1182
	.loh AdrpLdr	Lloh1180, Lloh1181
	.loh AdrpAdrp	Lloh1178, Lloh1180
	.loh AdrpLdr	Lloh1178, Lloh1179
	.loh AdrpLdr	Lloh1176, Lloh1177
	.loh AdrpAdrp	Lloh1174, Lloh1176
	.loh AdrpLdr	Lloh1174, Lloh1175
	.loh AdrpAdrp	Lloh1172, Lloh1174
	.loh AdrpLdr	Lloh1172, Lloh1173
	.loh AdrpAdrp	Lloh1170, Lloh1172
	.loh AdrpLdr	Lloh1170, Lloh1171
	.loh AdrpLdr	Lloh1168, Lloh1169
	.loh AdrpAdrp	Lloh1166, Lloh1168
	.loh AdrpLdr	Lloh1166, Lloh1167
	.loh AdrpAdrp	Lloh1164, Lloh1166
	.loh AdrpLdr	Lloh1164, Lloh1165
	.loh AdrpAdrp	Lloh1162, Lloh1164
	.loh AdrpLdr	Lloh1162, Lloh1163
	.loh AdrpLdr	Lloh1160, Lloh1161
	.loh AdrpAdrp	Lloh1158, Lloh1160
	.loh AdrpLdr	Lloh1158, Lloh1159
	.loh AdrpAdrp	Lloh1156, Lloh1158
	.loh AdrpLdr	Lloh1156, Lloh1157
	.loh AdrpAdrp	Lloh1154, Lloh1156
	.loh AdrpLdr	Lloh1154, Lloh1155
	.loh AdrpLdr	Lloh1152, Lloh1153
	.loh AdrpAdrp	Lloh1150, Lloh1152
	.loh AdrpLdr	Lloh1150, Lloh1151
	.loh AdrpAdrp	Lloh1148, Lloh1150
	.loh AdrpLdr	Lloh1148, Lloh1149
	.loh AdrpAdrp	Lloh1146, Lloh1148
	.loh AdrpLdr	Lloh1146, Lloh1147
	.loh AdrpLdr	Lloh1144, Lloh1145
	.loh AdrpAdrp	Lloh1142, Lloh1144
	.loh AdrpLdr	Lloh1142, Lloh1143
	.loh AdrpAdrp	Lloh1140, Lloh1142
	.loh AdrpLdr	Lloh1140, Lloh1141
	.loh AdrpAdrp	Lloh1138, Lloh1140
	.loh AdrpLdr	Lloh1138, Lloh1139
	.loh AdrpLdr	Lloh1136, Lloh1137
	.loh AdrpAdrp	Lloh1134, Lloh1136
	.loh AdrpLdr	Lloh1134, Lloh1135
	.loh AdrpAdrp	Lloh1132, Lloh1134
	.loh AdrpLdr	Lloh1132, Lloh1133
	.loh AdrpAdrp	Lloh1130, Lloh1132
	.loh AdrpLdr	Lloh1130, Lloh1131
	.loh AdrpLdr	Lloh1400, Lloh1401
	.loh AdrpAdrp	Lloh1398, Lloh1400
	.loh AdrpLdr	Lloh1398, Lloh1399
	.loh AdrpAdrp	Lloh1396, Lloh1398
	.loh AdrpLdr	Lloh1396, Lloh1397
	.loh AdrpAdrp	Lloh1394, Lloh1396
	.loh AdrpLdr	Lloh1394, Lloh1395
	.loh AdrpAdd	Lloh1402, Lloh1403
	.section	__TEXT,__const
	.p2align	1, 0x0
LJTI0_0:
	.short	(LBB0_8-LBB0_8)>>2
	.short	(LBB0_132-LBB0_8)>>2
	.short	(LBB0_76-LBB0_8)>>2
	.short	(LBB0_141-LBB0_8)>>2
	.short	(LBB0_72-LBB0_8)>>2
	.short	(LBB0_183-LBB0_8)>>2
	.short	(LBB0_192-LBB0_8)>>2
	.short	(LBB0_80-LBB0_8)>>2
	.short	(LBB0_41-LBB0_8)>>2
	.short	(LBB0_51-LBB0_8)>>2
	.short	(LBB0_255-LBB0_8)>>2
	.short	(LBB0_270-LBB0_8)>>2
	.short	(LBB0_24-LBB0_8)>>2
	.short	(LBB0_328-LBB0_8)>>2
	.short	(LBB0_337-LBB0_8)>>2
	.short	(LBB0_73-LBB0_8)>>2
	.short	(LBB0_26-LBB0_8)>>2
	.short	(LBB0_36-LBB0_8)>>2
	.short	(LBB0_399-LBB0_8)>>2
	.short	(LBB0_415-LBB0_8)>>2
	.short	(LBB0_77-LBB0_8)>>2
	.short	(LBB0_473-LBB0_8)>>2
	.short	(LBB0_482-LBB0_8)>>2
	.short	(LBB0_74-LBB0_8)>>2
	.short	(LBB0_9-LBB0_8)>>2
	.short	(LBB0_19-LBB0_8)>>2
	.short	(LBB0_545-LBB0_8)>>2
	.short	(LBB0_560-LBB0_8)>>2
	.short	(LBB0_96-LBB0_8)>>2
	.short	(LBB0_618-LBB0_8)>>2
	.short	(LBB0_627-LBB0_8)>>2
	.short	(LBB0_25-LBB0_8)>>2
	.short	(LBB0_57-LBB0_8)>>2
	.short	(LBB0_67-LBB0_8)>>2
	.short	(LBB0_689-LBB0_8)>>2
	.short	(LBB0_705-LBB0_8)>>2
	.short	(LBB0_78-LBB0_8)>>2
	.short	(LBB0_763-LBB0_8)>>2
	.short	(LBB0_772-LBB0_8)>>2
	.short	(LBB0_75-LBB0_8)>>2
	.short	(LBB0_81-LBB0_8)>>2
	.short	(LBB0_91-LBB0_8)>>2
	.short	(LBB0_835-LBB0_8)>>2
	.short	(LBB0_850-LBB0_8)>>2
	.short	(LBB0_79-LBB0_8)>>2
	.short	(LBB0_924-LBB0_8)>>2
	.short	(LBB0_932-LBB0_8)>>2
	.short	(LBB0_56-LBB0_8)>>2
	.short	(LBB0_976-LBB0_8)>>2
	.short	(LBB0_985-LBB0_8)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_tile_inclusive_scan.packet_batch ; -- Begin function tile_inclusive_scan.packet_batch
	.p2align	2
_tile_inclusive_scan.packet_batch:      ; @tile_inclusive_scan.packet_batch
; %bb.0:                                ; %packet.batch.prologue
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	mov	x21, x3
	mov	x19, x2
	mov	x20, x0
	ldr	w23, [x2, #36]
	ldr	w8, [x2]
	ldr	w9, [x2, #12]
	lsl	x8, x8, #5
	cmp	x8, x9
	csel	x10, x8, xzr, ls
	add	x10, x10, x23
	subs	x11, x9, x10
	mov	w12, #32                        ; =0x20
	sub	x13, x12, x23
	cmp	x11, x13
	csel	x11, x11, x13, lo
	cmp	x9, x10
	ccmp	x23, x12, #2, hi
	ccmp	x8, x9, #2, lo
	csel	x8, x11, xzr, ls
	cmp	w3, #4
	b.ne	LBB1_3
; %bb.1:                                ; %packet.batch.prologue
	cmp	x8, #32
	b.lo	LBB1_3
; %bb.2:                                ; %packet.batch.full
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	add	w8, w23, #8
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	add	w8, w23, #16
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	add	w8, w23, #24
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	b	_tile_inclusive_scan
LBB1_3:                                 ; %packet.batch.partial
	ubfiz	x9, x21, #3, #32
	cmp	x8, x9
	csel	x8, x8, x9, lo
	lsr	x24, x8, #3
	and	w22, w8, #0x7
	cmp	x8, #8
	b.lo	LBB1_6
; %bb.4:                                ; %packet.batch.partial.full.loop.preheader
	mov	x25, x24
	mov	x26, x23
LBB1_5:                                 ; %packet.batch.partial.full.loop
                                        ; =>This Inner Loop Header: Depth=1
	str	w26, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_tile_inclusive_scan
	add	w26, w26, #8
	subs	w25, w25, #1
	b.ne	LBB1_5
LBB1_6:                                 ; %packet.batch.tail.check
	cbz	w22, LBB1_8
; %bb.7:                                ; %packet.batch.tail.call
	add	w8, w23, w24, lsl #3
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	x2, x22
	bl	_tile_inclusive_scan
LBB1_8:                                 ; %packet.batch.partial.finish
	lsl	w8, w21, #3
	sub	w8, w8, #8
	cmp	w21, #0
	csel	w8, wzr, w8, eq
	add	w8, w23, w8
	str	w8, [x19, #36]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.section	__TEXT,__const
	.p2align	2, 0x0                          ; @convergence.targets
l_convergence.targets:
	.long	49                              ; 0x31
	.long	5                               ; 0x5
	.long	10                              ; 0xa
	.long	9                               ; 0x9
	.long	13                              ; 0xd
	.long	18                              ; 0x12
	.long	17                              ; 0x11
	.long	21                              ; 0x15
	.long	26                              ; 0x1a
	.long	25                              ; 0x19
	.long	29                              ; 0x1d
	.long	34                              ; 0x22
	.long	33                              ; 0x21
	.long	37                              ; 0x25
	.long	42                              ; 0x2a
	.long	41                              ; 0x29
	.long	45                              ; 0x2d
	.long	48                              ; 0x30

.subsections_via_symbols

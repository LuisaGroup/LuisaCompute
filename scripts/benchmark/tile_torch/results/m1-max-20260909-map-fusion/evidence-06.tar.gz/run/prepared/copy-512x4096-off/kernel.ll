; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @tile_pointwise(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [8192 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill1 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill1, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.slot2 = alloca i64, align 8
  store i64 0, ptr %.slot2, align 4
  %2 = getelementptr i8, ptr %argument_buffer, i64 0
  %3 = load ptr, ptr %2, align 16
  %4 = getelementptr i8, ptr %2, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = insertvalue { ptr, i64 } poison, ptr %3, 0
  %7 = insertvalue { ptr, i64 } %6, i64 %5, 1
  %8 = getelementptr i8, ptr %argument_buffer, i64 16
  %9 = load ptr, ptr %8, align 16
  %10 = getelementptr i8, ptr %8, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = insertvalue { ptr, i64 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %11, 1
  %14 = getelementptr i8, ptr %argument_buffer, i64 32
  %15 = load ptr, ptr %14, align 16
  %16 = getelementptr i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = insertvalue { ptr, i64 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i64 } %18, i64 %17, 1
  %20 = load i32, ptr %launch_config, align 4
  %21 = getelementptr i8, ptr %launch_config, i64 12
  %22 = load i32, ptr %21, align 4
  %23 = getelementptr i8, ptr %launch_config, i64 4
  %24 = load i32, ptr %23, align 4
  %25 = getelementptr i8, ptr %launch_config, i64 16
  %26 = load i32, ptr %25, align 4
  %27 = getelementptr i8, ptr %launch_config, i64 8
  %28 = load i32, ptr %27, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 20
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 36
  %32 = load i32, ptr %31, align 4
  %.splatinsert3 = insertelement <8 x i32> poison, i32 %32, i64 0
  %.splat4 = shufflevector <8 x i32> %.splatinsert3, <8 x i32> poison, <8 x i32> zeroinitializer
  %33 = add <8 x i32> %.splat4, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %34 = mul i32 %20, 1024
  %.splatinsert5 = insertelement <8 x i32> poison, i32 %34, i64 0
  %.splat6 = shufflevector <8 x i32> %.splatinsert5, <8 x i32> poison, <8 x i32> zeroinitializer
  %35 = add <8 x i32> %.splat6, %33
  %36 = mul i32 %24, 1
  %.splatinsert7 = insertelement <8 x i32> poison, i32 %36, i64 0
  %.splat8 = shufflevector <8 x i32> %.splatinsert7, <8 x i32> poison, <8 x i32> zeroinitializer
  %37 = add <8 x i32> %.splat8, zeroinitializer
  %38 = mul i32 %28, 1
  %.splatinsert9 = insertelement <8 x i32> poison, i32 %38, i64 0
  %.splat10 = shufflevector <8 x i32> %.splatinsert9, <8 x i32> poison, <8 x i32> zeroinitializer
  %39 = add <8 x i32> %.splat10, zeroinitializer
  %40 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %35, 0
  %41 = insertvalue [3 x <8 x i32>] %40, <8 x i32> %37, 1
  %42 = insertvalue [3 x <8 x i32>] %41, <8 x i32> %39, 2
  %.splatinsert11 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat12 = shufflevector <8 x i32> %.splatinsert11, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat12
  %44 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %43)
  br i1 %44, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %45 = extractvalue [3 x <8 x i32>] %42, 0
  %46 = zext <8 x i32> %45 to <8 x i64>
  %47 = select <8 x i1> %43, <8 x i64> %46, <8 x i64> zeroinitializer
  %48 = select <8 x i1> %43, <8 x i64> splat (i64 256), <8 x i64> splat (i64 1)
  %49 = sdiv <8 x i64> %47, %48
  %50 = select <8 x i1> %43, <8 x i64> %46, <8 x i64> zeroinitializer
  %51 = select <8 x i1> %43, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %52 = sdiv <8 x i64> %50, %51
  %53 = select <8 x i1> %43, <8 x i64> %52, <8 x i64> zeroinitializer
  %54 = select <8 x i1> %43, <8 x i64> splat (i64 256), <8 x i64> splat (i64 1)
  %55 = srem <8 x i64> %53, %54
  %56 = mul <8 x i64> %49, splat (i64 16)
  %57 = load <8 x i64>, ptr %.spill, align 64
  %58 = select <8 x i1> %43, <8 x i64> %56, <8 x i64> %57
  store <8 x i64> %58, ptr %.spill, align 64
  %59 = mul <8 x i64> %55, splat (i64 16)
  %60 = load <8 x i64>, ptr %.spill1, align 64
  %61 = select <8 x i1> %43, <8 x i64> %59, <8 x i64> %60
  store <8 x i64> %61, ptr %.spill1, align 64
  %62 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %63 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %64 = extractvalue { <8 x ptr>, <8 x i64> } %62, 0
  %65 = select <8 x i1> %43, <8 x ptr> %63, <8 x ptr> %64
  %66 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %62, 1
  %68 = select <8 x i1> %43, <8 x i64> %66, <8 x i64> %67
  %69 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %65, 0
  %70 = insertvalue { <8 x ptr>, <8 x i64> } %69, <8 x i64> %68, 1
  store { <8 x ptr>, <8 x i64> } %70, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %71 = icmp slt i64 %.state, 256
  br i1 %71, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state13 = load i64, ptr %.slot, align 4
  %72 = srem i64 %.state13, 16
  %.state14 = load i64, ptr %.slot, align 4
  %73 = sdiv i64 %.state14, 16
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %.splatinsert15 = insertelement <8 x i64> poison, i64 %73, i64 0
  %.splat16 = shufflevector <8 x i64> %.splatinsert15, <8 x i64> poison, <8 x i32> zeroinitializer
  %74 = add <8 x i64> %.spill.load, %.splat16
  %75 = add <8 x i64> zeroinitializer, %74
  %.spill.load17 = load <8 x i64>, ptr %.spill1, align 64
  %.splatinsert18 = insertelement <8 x i64> poison, i64 %72, i64 0
  %.splat19 = shufflevector <8 x i64> %.splatinsert18, <8 x i64> poison, <8 x i32> zeroinitializer
  %76 = add <8 x i64> %.spill.load17, %.splat19
  %77 = mul <8 x i64> %75, splat (i64 4096)
  %78 = add <8 x i64> %77, %76
  %79 = extractvalue { ptr, i64 } %7, 0
  %80 = mul <8 x i64> %78, splat (i64 4)
  %81 = getelementptr i8, ptr %79, <8 x i64> %80
  %82 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %81, i32 1, <8 x i1> %43, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %83 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %84 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state20 = load i64, ptr %.slot, align 4
  %.splatinsert21 = insertelement <8 x i64> poison, i64 %.state20, i64 0
  %.splat22 = shufflevector <8 x i64> %.splatinsert21, <8 x i64> poison, <8 x i32> zeroinitializer
  %85 = mul <8 x i64> %.splat22, splat (i64 32)
  %86 = add <8 x i64> %84, %85
  %87 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %83, 0
  %88 = insertvalue { <8 x ptr>, <8 x i64> } %87, <8 x i64> %86, 1
  %89 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %88, 1
  %91 = extractelement <8 x ptr> %89, i32 0
  %92 = extractelement <8 x i64> %90, i32 0
  %93 = sub i64 %92, 0
  %94 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %43)
  %95 = select i1 %94, i64 %93, i64 0
  %private.contiguous.address = getelementptr i8, ptr %91, i64 %95
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %96 = select <8 x i1> %43, <8 x float> %82, <8 x float> %private.contiguous.preserve
  store <8 x float> %96, ptr %private.contiguous.address, align 4
  %.state23 = load i64, ptr %.slot, align 4
  %97 = add i64 %.state23, 1
  store i64 %97, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store i64 0, ptr %.slot2, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state24 = load i64, ptr %.slot2, align 4
  %98 = icmp slt i64 %.state24, 256
  br i1 %98, label %direct.true25, label %direct.false26

direct.schedule.5:                                ; preds = %direct.true25
  %.state27 = load i64, ptr %.slot2, align 4
  %99 = srem i64 %.state27, 16
  %.state28 = load i64, ptr %.slot2, align 4
  %100 = sdiv i64 %.state28, 16
  %.spill.load29 = load <8 x i64>, ptr %.spill, align 64
  %.splatinsert30 = insertelement <8 x i64> poison, i64 %100, i64 0
  %.splat31 = shufflevector <8 x i64> %.splatinsert30, <8 x i64> poison, <8 x i32> zeroinitializer
  %101 = add <8 x i64> %.spill.load29, %.splat31
  %102 = add <8 x i64> zeroinitializer, %101
  %.spill.load32 = load <8 x i64>, ptr %.spill1, align 64
  %.splatinsert33 = insertelement <8 x i64> poison, i64 %99, i64 0
  %.splat34 = shufflevector <8 x i64> %.splatinsert33, <8 x i64> poison, <8 x i32> zeroinitializer
  %103 = add <8 x i64> %.spill.load32, %.splat34
  %104 = mul <8 x i64> %102, splat (i64 4096)
  %105 = add <8 x i64> %104, %103
  %tile_snapshot.spill.load35 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %106 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load35, 0
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load35, 1
  %.state36 = load i64, ptr %.slot2, align 4
  %.splatinsert37 = insertelement <8 x i64> poison, i64 %.state36, i64 0
  %.splat38 = shufflevector <8 x i64> %.splatinsert37, <8 x i64> poison, <8 x i32> zeroinitializer
  %108 = mul <8 x i64> %.splat38, splat (i64 32)
  %109 = add <8 x i64> %107, %108
  %110 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %106, 0
  %111 = insertvalue { <8 x ptr>, <8 x i64> } %110, <8 x i64> %109, 1
  %112 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %113 = extractvalue { <8 x ptr>, <8 x i64> } %111, 1
  %114 = extractelement <8 x ptr> %112, i32 0
  %115 = extractelement <8 x i64> %113, i32 0
  %116 = sub i64 %115, 0
  %117 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %43)
  %118 = select i1 %117, i64 %116, i64 0
  %private.contiguous.address39 = getelementptr i8, ptr %114, i64 %118
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address39, align 4
  %119 = select <8 x i1> %43, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %120 = extractvalue { ptr, i64 } %19, 0
  %121 = mul <8 x i64> %105, splat (i64 4)
  %122 = getelementptr i8, ptr %120, <8 x i64> %121
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %119, <8 x ptr> %122, i32 1, <8 x i1> %43)
  %.state40 = load i64, ptr %.slot2, align 4
  %123 = add i64 %.state40, 1
  store i64 %123, ptr %.slot2, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false26
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true25:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false26:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #2

define internal void @tile_pointwise.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 1024
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 1024
  %3 = sub i64 1024, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 128
  %8 = icmp uge i64 %packet.range.remaining, 1024
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  br label %packet.batch.full.loop

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full.loop
  ret void

packet.batch.full.loop:                           ; preds = %packet.batch.full.loop, %packet.batch.full
  %packet.index = phi i32 [ 0, %packet.batch.full ], [ %packet.index.next, %packet.batch.full.loop ]
  %packet.thread.offset = mul i32 %packet.index, 8
  %packet.thread.index = add i32 %base.thread.index, %packet.thread.offset
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @tile_pointwise(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.index.next = add i32 %packet.index, 1
  %packet.batch.has.more = icmp ult i32 %packet.index.next, %packet_count
  br i1 %packet.batch.has.more, label %packet.batch.full.loop, label %packet.batch.exit

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @tile_pointwise(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @tile_pointwise(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @tile_pointwise.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @tile_pointwise.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 128)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }

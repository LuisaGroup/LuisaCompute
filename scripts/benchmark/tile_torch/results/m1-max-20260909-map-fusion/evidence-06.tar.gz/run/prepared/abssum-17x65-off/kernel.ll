; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

@convergence.targets = private unnamed_addr constant [9 x i32] [i32 5, i32 4, i32 8, i32 11, i32 14, i32 17, i32 19, i32 21, i32 23], align 4

define internal void @tile_row_reduce(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %live.mask = alloca <8 x i1>, align 1
  %runnable.mask = alloca <8 x i1>, align 1
  %ready.count = alloca i32, align 4
  %ready.mask = alloca [8 x <8 x i1>], align 1
  %ready.target = alloca [8 x i32], align 4
  %ready.token = alloca [8 x i32], align 4
  %current.mask = alloca <8 x i1>, align 1
  %current.token = alloca i32, align 4
  %frame.active = alloca i8, align 1
  %frame.static.id = alloca <8 x i32>, align 32
  %frame.parent.token = alloca <8 x i32>, align 32
  %frame.expected = alloca [8 x <8 x i1>], align 1
  %frame.arrived = alloca [8 x <8 x i1>], align 1
  store <8 x i1> zeroinitializer, ptr %live.mask, align 1
  store <8 x i1> zeroinitializer, ptr %runnable.mask, align 1
  store i32 0, ptr %ready.count, align 4
  store [8 x <8 x i1>] zeroinitializer, ptr %ready.mask, align 1
  store [8 x i32] zeroinitializer, ptr %ready.target, align 4
  store [8 x i32] zeroinitializer, ptr %ready.token, align 4
  store <8 x i1> zeroinitializer, ptr %current.mask, align 1
  store i32 0, ptr %current.token, align 4
  store i8 0, ptr %frame.active, align 1
  store <8 x i32> zeroinitializer, ptr %frame.static.id, align 32
  store <8 x i32> zeroinitializer, ptr %frame.parent.token, align 32
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.expected, align 1
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.arrived, align 1
  %tile_snapshot.local = alloca [8320 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot, align 64
  %.spill1 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill1, align 64
  %.slot2 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot2, align 32
  %.spill3 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill3, align 4
  %.spill4 = alloca i64, align 8
  store i64 0, ptr %.spill4, align 4
  %.spill5 = alloca i64, align 8
  store i64 0, ptr %.spill5, align 4
  %.spill6 = alloca i64, align 8
  store i64 0, ptr %.spill6, align 4
  %.spill7 = alloca i64, align 8
  store i64 0, ptr %.spill7, align 4
  %.spill8 = alloca i64, align 8
  store i64 0, ptr %.spill8, align 4
  %.spill9 = alloca i64, align 8
  store i64 0, ptr %.spill9, align 4
  %.slot10 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot10, align 64
  %.slot11 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot11, align 32
  %.slot12 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot12, align 32
  %.slot13 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot13, align 32
  %.slot14 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot14, align 32
  %.spill15 = alloca i64, align 8
  store i64 0, ptr %.spill15, align 4
  %.spill16 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill16, align 32
  %.spill17 = alloca i64, align 8
  store i64 0, ptr %.spill17, align 4
  %.slot18 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot18, align 64
  %.slot19 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot19, align 32
  %.slot20 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot20, align 32
  %.slot21 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot21, align 32
  %.slot22 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot22, align 32
  %.spill23 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill23, align 32
  %.spill24 = alloca i64, align 8
  store i64 0, ptr %.spill24, align 4
  %.slot25 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot25, align 64
  %.slot26 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot26, align 32
  %.slot27 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot27, align 32
  %.slot28 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot28, align 32
  %.slot29 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot29, align 32
  %.spill30 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill30, align 32
  %.spill31 = alloca i64, align 8
  store i64 0, ptr %.spill31, align 4
  %.slot32 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot32, align 64
  %.slot33 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot33, align 32
  %.slot34 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot34, align 32
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.slot36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot36, align 32
  %.spill37 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill37, align 32
  %.spill38 = alloca i64, align 8
  store i64 0, ptr %.spill38, align 4
  %.spill39 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill39, align 64
  %.spill40 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill40, align 64
  %.spill41 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill41, align 64
  %2 = getelementptr i8, ptr %argument_buffer, i64 0
  %3 = load ptr, ptr %2, align 16
  %4 = getelementptr i8, ptr %2, i64 8
  %5 = load i64, ptr %4, align 8
  %6 = insertvalue { ptr, i64 } poison, ptr %3, 0
  %7 = insertvalue { ptr, i64 } %6, i64 %5, 1
  %8 = getelementptr i8, ptr %argument_buffer, i64 16
  %9 = load ptr, ptr %8, align 16
  %10 = getelementptr i8, ptr %8, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = insertvalue { ptr, i64 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %11, 1
  %14 = load i32, ptr %launch_config, align 4
  %15 = getelementptr i8, ptr %launch_config, i64 12
  %16 = load i32, ptr %15, align 4
  %17 = getelementptr i8, ptr %launch_config, i64 4
  %18 = load i32, ptr %17, align 4
  %19 = getelementptr i8, ptr %launch_config, i64 16
  %20 = load i32, ptr %19, align 4
  %21 = getelementptr i8, ptr %launch_config, i64 8
  %22 = load i32, ptr %21, align 4
  %23 = getelementptr i8, ptr %launch_config, i64 20
  %24 = load i32, ptr %23, align 4
  %25 = getelementptr i8, ptr %launch_config, i64 36
  %26 = load i32, ptr %25, align 4
  %.splatinsert42 = insertelement <8 x i32> poison, i32 %26, i64 0
  %.splat43 = shufflevector <8 x i32> %.splatinsert42, <8 x i32> poison, <8 x i32> zeroinitializer
  %27 = add <8 x i32> %.splat43, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %28 = mul i32 %14, 32
  %.splatinsert44 = insertelement <8 x i32> poison, i32 %28, i64 0
  %.splat45 = shufflevector <8 x i32> %.splatinsert44, <8 x i32> poison, <8 x i32> zeroinitializer
  %29 = add <8 x i32> %.splat45, %27
  %30 = mul i32 %18, 1
  %.splatinsert46 = insertelement <8 x i32> poison, i32 %30, i64 0
  %.splat47 = shufflevector <8 x i32> %.splatinsert46, <8 x i32> poison, <8 x i32> zeroinitializer
  %31 = add <8 x i32> %.splat47, zeroinitializer
  %32 = mul i32 %22, 1
  %.splatinsert48 = insertelement <8 x i32> poison, i32 %32, i64 0
  %.splat49 = shufflevector <8 x i32> %.splatinsert48, <8 x i32> poison, <8 x i32> zeroinitializer
  %33 = add <8 x i32> %.splat49, zeroinitializer
  %34 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %29, 0
  %35 = insertvalue [3 x <8 x i32>] %34, <8 x i32> %31, 1
  %36 = insertvalue [3 x <8 x i32>] %35, <8 x i32> %33, 2
  %.splatinsert50 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat51 = shufflevector <8 x i32> %.splatinsert50, <8 x i32> poison, <8 x i32> zeroinitializer
  %37 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat51
  store <8 x i1> %37, ptr %live.mask, align 1
  %38 = load i32, ptr %current.token, align 4
  %39 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %37)
  %40 = load i32, ptr %ready.count, align 4
  %41 = icmp uge i32 %40, 8
  %42 = and i1 %39, %41
  br i1 %42, label %ready.overflow.trap, label %ready.overflow.resume

ready.overflow.trap:                              ; preds = %prologue
  call void @llvm.trap()
  unreachable

ready.overflow.resume:                            ; preds = %prologue
  %43 = select i1 %39, i32 %40, i32 0
  %44 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %43
  %45 = load <8 x i1>, ptr %44, align 1
  %46 = select i1 %39, <8 x i1> %37, <8 x i1> %45
  store <8 x i1> %46, ptr %44, align 1
  %47 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %43
  %48 = load i32, ptr %47, align 4
  %49 = select i1 %39, i32 0, i32 %48
  store i32 %49, ptr %47, align 4
  %50 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %43
  %51 = load i32, ptr %50, align 4
  %52 = select i1 %39, i32 %38, i32 %51
  store i32 %52, ptr %50, align 4
  %53 = add i32 %40, 1
  %54 = select i1 %39, i32 %53, i32 %40
  store i32 %54, ptr %ready.count, align 4
  %55 = load <8 x i1>, ptr %runnable.mask, align 1
  %56 = or <8 x i1> %55, %37
  store <8 x i1> %56, ptr %runnable.mask, align 1
  br label %scheduler.loop

scheduler.loop:                                   ; preds = %return.frame.cleanup.done, %convergence.cascade.exit575, %schedule.22, %varying.coherent.false571, %varying.coherent.true570, %convergence.cascade.exit544, %schedule.20, %varying.coherent.false540, %varying.coherent.true539, %convergence.cascade.exit513, %schedule.18, %varying.coherent.false509, %varying.coherent.true508, %convergence.cascade.exit468, %schedule.16, %varying.coherent.false429, %varying.coherent.true428, %convergence.target.14.ready, %convergence.cascade.exit361, %schedule.13, %varying.coherent.false322, %varying.coherent.true321, %convergence.target.11.ready, %convergence.cascade.exit254, %schedule.10, %varying.coherent.false215, %varying.coherent.true214, %convergence.target.8.ready, %convergence.cascade.exit148, %schedule.7, %varying.coherent.false109, %varying.coherent.true108, %convergence.target.5.ready, %convergence.cascade.exit75, %convergence.target.4.ready, %convergence.cascade.exit, %schedule.3, %varying.coherent.false63, %varying.coherent.true62, %varying.coherent.false, %varying.coherent.true, %schedule.0, %ready.overflow.resume
  %57 = load i32, ptr %ready.count, align 4
  %58 = icmp ne i32 %57, 0
  br i1 %58, label %scheduler.dispatch, label %scheduler.done

scheduler.dispatch:                               ; preds = %scheduler.loop
  %59 = sub i32 %57, 1
  store i32 %59, ptr %ready.count, align 4
  %60 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %59
  %61 = load <8 x i1>, ptr %60, align 1
  store <8 x i1> %61, ptr %current.mask, align 1
  %62 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %59
  %63 = load i32, ptr %62, align 4
  %64 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %59
  %65 = load i32, ptr %64, align 4
  store i32 %65, ptr %current.token, align 4
  %66 = load <8 x i1>, ptr %runnable.mask, align 1
  %67 = xor <8 x i1> %61, splat (i1 true)
  %68 = and <8 x i1> %66, %67
  store <8 x i1> %68, ptr %runnable.mask, align 1
  br label %scheduler.dispatch.route

scheduler.dispatch.route:                         ; preds = %ready.overflow.resume569, %ready.overflow.resume538, %ready.overflow.resume507, %ready.overflow.resume427, %ready.overflow.resume320, %ready.overflow.resume213, %ready.overflow.resume107, %ready.overflow.resume61, %ready.overflow.resume53, %scheduler.dispatch
  %scheduler.dispatch.pc = phi i32 [ %63, %scheduler.dispatch ], [ 5, %ready.overflow.resume53 ], [ 4, %ready.overflow.resume61 ], [ 8, %ready.overflow.resume107 ], [ 11, %ready.overflow.resume213 ], [ 14, %ready.overflow.resume320 ], [ 17, %ready.overflow.resume427 ], [ 19, %ready.overflow.resume507 ], [ 21, %ready.overflow.resume538 ], [ 23, %ready.overflow.resume569 ]
  switch i32 %scheduler.dispatch.pc, label %scheduler.invalid [
    i32 0, label %schedule.0
    i32 1, label %schedule.1
    i32 2, label %schedule.2
    i32 3, label %schedule.3
    i32 4, label %schedule.4
    i32 5, label %schedule.5
    i32 6, label %schedule.6
    i32 7, label %schedule.7
    i32 8, label %schedule.8
    i32 9, label %schedule.9
    i32 10, label %schedule.10
    i32 11, label %schedule.11
    i32 12, label %schedule.12
    i32 13, label %schedule.13
    i32 14, label %schedule.14
    i32 15, label %schedule.15
    i32 16, label %schedule.16
    i32 17, label %schedule.17
    i32 18, label %schedule.18
    i32 19, label %schedule.19
    i32 20, label %schedule.20
    i32 21, label %schedule.21
    i32 22, label %schedule.22
    i32 23, label %schedule.23
  ]

scheduler.done:                                   ; preds = %scheduler.loop
  %69 = load <8 x i1>, ptr %live.mask, align 1
  %70 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %69)
  br i1 %70, label %scheduler.stalled, label %scheduler.exit

scheduler.exit:                                   ; preds = %scheduler.done
  ret void

scheduler.stalled:                                ; preds = %scheduler.done
  call void @llvm.trap()
  unreachable

scheduler.invalid:                                ; preds = %scheduler.dispatch.route
  call void @llvm.trap()
  unreachable

schedule.0:                                       ; preds = %scheduler.dispatch.route
  %71 = load <8 x i1>, ptr %current.mask, align 1
  %72 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %73 = bitcast <8 x i1> %71 to i8
  %74 = call i8 @llvm.cttz.i8(i8 %73, i1 false)
  %75 = zext i8 %74 to i32
  %76 = select i1 %72, i32 %75, i32 0
  %77 = extractvalue [3 x <8 x i32>] %36, 0
  %78 = zext <8 x i32> %77 to <8 x i64>
  %79 = select <8 x i1> %71, <8 x i64> %78, <8 x i64> zeroinitializer
  %80 = select <8 x i1> %71, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %81 = sdiv <8 x i64> %79, %80
  %82 = mul <8 x i64> %81, splat (i64 4)
  %83 = load <8 x i64>, ptr %.spill, align 64
  %84 = select <8 x i1> %71, <8 x i64> %82, <8 x i64> %83
  store <8 x i64> %84, ptr %.spill, align 64
  %85 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %86 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %85, 0
  %88 = select <8 x i1> %71, <8 x ptr> %86, <8 x ptr> %87
  %89 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %85, 1
  %91 = select <8 x i1> %71, <8 x i64> %89, <8 x i64> %90
  %92 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %88, 0
  %93 = insertvalue { <8 x ptr>, <8 x i64> } %92, <8 x i64> %91, 1
  store { <8 x ptr>, <8 x i64> } %93, ptr %tile_snapshot.spill, align 64
  %94 = load <8 x i64>, ptr %.slot, align 64
  %95 = select <8 x i1> %71, <8 x i64> zeroinitializer, <8 x i64> %94
  store <8 x i64> %95, ptr %.slot, align 64
  store <8 x i1> %71, ptr %current.mask, align 1
  %96 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  br i1 %96, label %schedule.1, label %scheduler.loop

schedule.1:                                       ; preds = %convergence.target.4.ready, %schedule.0, %scheduler.dispatch.route
  %97 = load <8 x i1>, ptr %current.mask, align 1
  %98 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %97)
  %99 = bitcast <8 x i1> %97 to i8
  %100 = call i8 @llvm.cttz.i8(i8 %99, i1 false)
  %101 = zext i8 %100 to i32
  %102 = select i1 %98, i32 %101, i32 0
  %.state = load <8 x i64>, ptr %.slot, align 64
  %103 = icmp slt <8 x i64> %.state, splat (i64 260)
  %104 = and <8 x i1> %97, %103
  %105 = xor <8 x i1> %103, splat (i1 true)
  %106 = and <8 x i1> %97, %105
  %107 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %104)
  %108 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %106)
  %109 = and i1 %107, %108
  br i1 %109, label %varying.divergent, label %varying.coherent

schedule.2:                                       ; preds = %varying.coherent.true, %scheduler.dispatch.route
  %110 = load <8 x i1>, ptr %current.mask, align 1
  %111 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %110)
  %112 = bitcast <8 x i1> %110 to i8
  %113 = call i8 @llvm.cttz.i8(i8 %112, i1 false)
  %114 = zext i8 %113 to i32
  %115 = select i1 %111, i32 %114, i32 0
  %.state54 = load <8 x i64>, ptr %.slot, align 64
  %116 = select <8 x i1> %110, <8 x i64> %.state54, <8 x i64> zeroinitializer
  %117 = select <8 x i1> %110, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %118 = srem <8 x i64> %116, %117
  %.state55 = load <8 x i64>, ptr %.slot, align 64
  %119 = select <8 x i1> %110, <8 x i64> %.state55, <8 x i64> zeroinitializer
  %120 = select <8 x i1> %110, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %121 = sdiv <8 x i64> %119, %120
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %122 = add <8 x i64> %.spill.load, %121
  %123 = add <8 x i64> zeroinitializer, %122
  %124 = icmp sge <8 x i64> %122, zeroinitializer
  %125 = and <8 x i1> splat (i1 true), %124
  %126 = icmp slt <8 x i64> %122, splat (i64 17)
  %127 = and <8 x i1> %125, %126
  %128 = add <8 x i64> zeroinitializer, %118
  %129 = mul <8 x i64> %123, splat (i64 65)
  %130 = add <8 x i64> %129, %128
  %131 = load <8 x i64>, ptr %.spill1, align 64
  %132 = select <8 x i1> %110, <8 x i64> %130, <8 x i64> %131
  store <8 x i64> %132, ptr %.spill1, align 64
  %133 = and <8 x i1> %110, %127
  %134 = xor <8 x i1> %127, splat (i1 true)
  %135 = and <8 x i1> %110, %134
  %136 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %133)
  %137 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %135)
  %138 = and i1 %136, %137
  br i1 %138, label %varying.divergent56, label %varying.coherent57

schedule.3:                                       ; preds = %varying.coherent.true62, %scheduler.dispatch.route
  %139 = load <8 x i1>, ptr %current.mask, align 1
  %140 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %139)
  %141 = bitcast <8 x i1> %139 to i8
  %142 = call i8 @llvm.cttz.i8(i8 %141, i1 false)
  %143 = zext i8 %142 to i32
  %144 = select i1 %140, i32 %143, i32 0
  %.spill.load64 = load <8 x i64>, ptr %.spill1, align 64
  %145 = extractvalue { ptr, i64 } %7, 0
  %146 = mul <8 x i64> %.spill.load64, splat (i64 4)
  %147 = getelementptr i8, ptr %145, <8 x i64> %146
  %148 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %147, i32 1, <8 x i1> %139, <8 x float> zeroinitializer)
  %149 = load <8 x float>, ptr %.slot2, align 32
  %150 = select <8 x i1> %139, <8 x float> %148, <8 x float> %149
  store <8 x float> %150, ptr %.slot2, align 32
  store <8 x i1> %139, ptr %current.mask, align 1
  %151 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %139)
  br i1 %151, label %schedule.4, label %scheduler.loop

schedule.4:                                       ; preds = %schedule.3, %varying.coherent.false63, %scheduler.dispatch.route
  %152 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token = load i32, ptr %current.token, align 4
  %convergence.token.present = icmp ne i32 %convergence.current.token, 0
  br i1 %convergence.token.present, label %convergence.cascade, label %convergence.cascade.exit

schedule.5:                                       ; preds = %varying.coherent.false, %scheduler.dispatch.route
  %153 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token76 = load i32, ptr %current.token, align 4
  %convergence.token.present77 = icmp ne i32 %convergence.current.token76, 0
  br i1 %convergence.token.present77, label %convergence.cascade74, label %convergence.cascade.exit75

schedule.6:                                       ; preds = %schedule.7, %convergence.target.5.ready, %scheduler.dispatch.route
  %154 = load <8 x i1>, ptr %current.mask, align 1
  %155 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %154)
  %156 = bitcast <8 x i1> %154 to i8
  %157 = call i8 @llvm.cttz.i8(i8 %156, i1 false)
  %158 = zext i8 %157 to i32
  %159 = select i1 %155, i32 %158, i32 0
  %.state101 = load <8 x i64>, ptr %.slot10, align 64
  %160 = icmp slt <8 x i64> %.state101, splat (i64 64)
  %161 = and <8 x i1> %154, %160
  %162 = xor <8 x i1> %160, splat (i1 true)
  %163 = and <8 x i1> %154, %162
  %164 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %161)
  %165 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %163)
  %166 = and i1 %164, %165
  br i1 %166, label %varying.divergent102, label %varying.coherent103

schedule.7:                                       ; preds = %varying.coherent.true108, %scheduler.dispatch.route
  %167 = load <8 x i1>, ptr %current.mask, align 1
  %168 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %167)
  %169 = bitcast <8 x i1> %167 to i8
  %170 = call i8 @llvm.cttz.i8(i8 %169, i1 false)
  %171 = zext i8 %170 to i32
  %172 = select i1 %168, i32 %171, i32 0
  %.state110 = load <8 x i64>, ptr %.slot10, align 64
  %173 = add <8 x i64> %.state110, zeroinitializer
  %174 = select <8 x i1> %167, <8 x i64> %173, <8 x i64> zeroinitializer
  %175 = select <8 x i1> %167, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %176 = sdiv <8 x i64> %174, %175
  %.spill.load111 = load i64, ptr %.spill6, align 4
  %.splatinsert112 = insertelement <8 x i64> poison, i64 %.spill.load111, i64 0
  %.splat113 = shufflevector <8 x i64> %.splatinsert112, <8 x i64> poison, <8 x i32> zeroinitializer
  %177 = add <8 x i64> %.splat113, %176
  %178 = select <8 x i1> %167, <8 x i64> %177, <8 x i64> zeroinitializer
  %179 = select <8 x i1> %167, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %180 = srem <8 x i64> %178, %179
  %181 = select <8 x i1> %167, <8 x i64> %177, <8 x i64> zeroinitializer
  %182 = select <8 x i1> %167, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %183 = sdiv <8 x i64> %181, %182
  %.spill.load114 = load i64, ptr %.spill5, align 4
  %.splatinsert115 = insertelement <8 x i64> poison, i64 %.spill.load114, i64 0
  %.splat116 = shufflevector <8 x i64> %.splatinsert115, <8 x i64> poison, <8 x i32> zeroinitializer
  %184 = add <8 x i64> %.splat116, %183
  %185 = mul <8 x i64> %184, splat (i64 65)
  %186 = add <8 x i64> %185, %180
  %tile_snapshot.spill.load117 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load117, 0
  %188 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load117, 1
  %189 = mul <8 x i64> %186, splat (i64 32)
  %190 = add <8 x i64> %188, %189
  %191 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %187, 0
  %192 = insertvalue { <8 x ptr>, <8 x i64> } %191, <8 x i64> %190, 1
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %192, 0
  %194 = extractvalue { <8 x ptr>, <8 x i64> } %192, 1
  %195 = getelementptr i8, <8 x ptr> %193, <8 x i64> %194
  %196 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %195, i32 1, <8 x i1> %167, <8 x float> zeroinitializer)
  %197 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %196)
  %.state118 = load <8 x float>, ptr %.slot11, align 32
  %198 = fadd <8 x float> %.state118, %197
  %.state119 = load <8 x i64>, ptr %.slot10, align 64
  %199 = add <8 x i64> %.state119, splat (i64 1)
  %200 = select <8 x i1> %167, <8 x i64> %199, <8 x i64> zeroinitializer
  %201 = select <8 x i1> %167, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %202 = sdiv <8 x i64> %200, %201
  %.spill.load120 = load i64, ptr %.spill6, align 4
  %.splatinsert121 = insertelement <8 x i64> poison, i64 %.spill.load120, i64 0
  %.splat122 = shufflevector <8 x i64> %.splatinsert121, <8 x i64> poison, <8 x i32> zeroinitializer
  %203 = add <8 x i64> %.splat122, %202
  %204 = select <8 x i1> %167, <8 x i64> %203, <8 x i64> zeroinitializer
  %205 = select <8 x i1> %167, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %206 = srem <8 x i64> %204, %205
  %207 = select <8 x i1> %167, <8 x i64> %203, <8 x i64> zeroinitializer
  %208 = select <8 x i1> %167, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %209 = sdiv <8 x i64> %207, %208
  %.spill.load123 = load i64, ptr %.spill5, align 4
  %.splatinsert124 = insertelement <8 x i64> poison, i64 %.spill.load123, i64 0
  %.splat125 = shufflevector <8 x i64> %.splatinsert124, <8 x i64> poison, <8 x i32> zeroinitializer
  %210 = add <8 x i64> %.splat125, %209
  %211 = mul <8 x i64> %210, splat (i64 65)
  %212 = add <8 x i64> %211, %206
  %tile_snapshot.spill.load126 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %213 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load126, 0
  %214 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load126, 1
  %215 = mul <8 x i64> %212, splat (i64 32)
  %216 = add <8 x i64> %214, %215
  %217 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %213, 0
  %218 = insertvalue { <8 x ptr>, <8 x i64> } %217, <8 x i64> %216, 1
  %219 = extractvalue { <8 x ptr>, <8 x i64> } %218, 0
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %218, 1
  %221 = getelementptr i8, <8 x ptr> %219, <8 x i64> %220
  %222 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %221, i32 1, <8 x i1> %167, <8 x float> zeroinitializer)
  %223 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %222)
  %.state127 = load <8 x float>, ptr %.slot12, align 32
  %224 = fadd <8 x float> %.state127, %223
  %.state128 = load <8 x i64>, ptr %.slot10, align 64
  %225 = add <8 x i64> %.state128, splat (i64 2)
  %226 = select <8 x i1> %167, <8 x i64> %225, <8 x i64> zeroinitializer
  %227 = select <8 x i1> %167, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %228 = sdiv <8 x i64> %226, %227
  %.spill.load129 = load i64, ptr %.spill6, align 4
  %.splatinsert130 = insertelement <8 x i64> poison, i64 %.spill.load129, i64 0
  %.splat131 = shufflevector <8 x i64> %.splatinsert130, <8 x i64> poison, <8 x i32> zeroinitializer
  %229 = add <8 x i64> %.splat131, %228
  %230 = select <8 x i1> %167, <8 x i64> %229, <8 x i64> zeroinitializer
  %231 = select <8 x i1> %167, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %232 = srem <8 x i64> %230, %231
  %233 = select <8 x i1> %167, <8 x i64> %229, <8 x i64> zeroinitializer
  %234 = select <8 x i1> %167, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %235 = sdiv <8 x i64> %233, %234
  %.spill.load132 = load i64, ptr %.spill5, align 4
  %.splatinsert133 = insertelement <8 x i64> poison, i64 %.spill.load132, i64 0
  %.splat134 = shufflevector <8 x i64> %.splatinsert133, <8 x i64> poison, <8 x i32> zeroinitializer
  %236 = add <8 x i64> %.splat134, %235
  %237 = mul <8 x i64> %236, splat (i64 65)
  %238 = add <8 x i64> %237, %232
  %tile_snapshot.spill.load135 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %239 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load135, 0
  %240 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load135, 1
  %241 = mul <8 x i64> %238, splat (i64 32)
  %242 = add <8 x i64> %240, %241
  %243 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %239, 0
  %244 = insertvalue { <8 x ptr>, <8 x i64> } %243, <8 x i64> %242, 1
  %245 = extractvalue { <8 x ptr>, <8 x i64> } %244, 0
  %246 = extractvalue { <8 x ptr>, <8 x i64> } %244, 1
  %247 = getelementptr i8, <8 x ptr> %245, <8 x i64> %246
  %248 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %247, i32 1, <8 x i1> %167, <8 x float> zeroinitializer)
  %249 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %248)
  %.state136 = load <8 x float>, ptr %.slot13, align 32
  %250 = fadd <8 x float> %.state136, %249
  %.state137 = load <8 x i64>, ptr %.slot10, align 64
  %251 = add <8 x i64> %.state137, splat (i64 3)
  %252 = select <8 x i1> %167, <8 x i64> %251, <8 x i64> zeroinitializer
  %253 = select <8 x i1> %167, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %254 = sdiv <8 x i64> %252, %253
  %.spill.load138 = load i64, ptr %.spill6, align 4
  %.splatinsert139 = insertelement <8 x i64> poison, i64 %.spill.load138, i64 0
  %.splat140 = shufflevector <8 x i64> %.splatinsert139, <8 x i64> poison, <8 x i32> zeroinitializer
  %255 = add <8 x i64> %.splat140, %254
  %256 = select <8 x i1> %167, <8 x i64> %255, <8 x i64> zeroinitializer
  %257 = select <8 x i1> %167, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %258 = srem <8 x i64> %256, %257
  %259 = select <8 x i1> %167, <8 x i64> %255, <8 x i64> zeroinitializer
  %260 = select <8 x i1> %167, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %261 = sdiv <8 x i64> %259, %260
  %.spill.load141 = load i64, ptr %.spill5, align 4
  %.splatinsert142 = insertelement <8 x i64> poison, i64 %.spill.load141, i64 0
  %.splat143 = shufflevector <8 x i64> %.splatinsert142, <8 x i64> poison, <8 x i32> zeroinitializer
  %262 = add <8 x i64> %.splat143, %261
  %263 = mul <8 x i64> %262, splat (i64 65)
  %264 = add <8 x i64> %263, %258
  %tile_snapshot.spill.load144 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %265 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load144, 0
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load144, 1
  %267 = mul <8 x i64> %264, splat (i64 32)
  %268 = add <8 x i64> %266, %267
  %269 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %265, 0
  %270 = insertvalue { <8 x ptr>, <8 x i64> } %269, <8 x i64> %268, 1
  %271 = extractvalue { <8 x ptr>, <8 x i64> } %270, 0
  %272 = extractvalue { <8 x ptr>, <8 x i64> } %270, 1
  %273 = getelementptr i8, <8 x ptr> %271, <8 x i64> %272
  %274 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %273, i32 1, <8 x i1> %167, <8 x float> zeroinitializer)
  %275 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %274)
  %.state145 = load <8 x float>, ptr %.slot14, align 32
  %276 = fadd <8 x float> %.state145, %275
  %.state146 = load <8 x i64>, ptr %.slot10, align 64
  %277 = add <8 x i64> %.state146, splat (i64 4)
  %278 = load <8 x i64>, ptr %.slot10, align 64
  %279 = select <8 x i1> %167, <8 x i64> %277, <8 x i64> %278
  store <8 x i64> %279, ptr %.slot10, align 64
  %280 = load <8 x float>, ptr %.slot11, align 32
  %281 = select <8 x i1> %167, <8 x float> %198, <8 x float> %280
  store <8 x float> %281, ptr %.slot11, align 32
  %282 = load <8 x float>, ptr %.slot12, align 32
  %283 = select <8 x i1> %167, <8 x float> %224, <8 x float> %282
  store <8 x float> %283, ptr %.slot12, align 32
  %284 = load <8 x float>, ptr %.slot13, align 32
  %285 = select <8 x i1> %167, <8 x float> %250, <8 x float> %284
  store <8 x float> %285, ptr %.slot13, align 32
  %286 = load <8 x float>, ptr %.slot14, align 32
  %287 = select <8 x i1> %167, <8 x float> %276, <8 x float> %286
  store <8 x float> %287, ptr %.slot14, align 32
  store <8 x i1> %167, ptr %current.mask, align 1
  %288 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %167)
  br i1 %288, label %schedule.6, label %scheduler.loop

schedule.8:                                       ; preds = %varying.coherent.false109, %scheduler.dispatch.route
  %289 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token149 = load i32, ptr %current.token, align 4
  %convergence.token.present150 = icmp ne i32 %convergence.current.token149, 0
  br i1 %convergence.token.present150, label %convergence.cascade147, label %convergence.cascade.exit148

schedule.9:                                       ; preds = %schedule.10, %convergence.target.8.ready, %scheduler.dispatch.route
  %290 = load <8 x i1>, ptr %current.mask, align 1
  %291 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %290)
  %292 = bitcast <8 x i1> %290 to i8
  %293 = call i8 @llvm.cttz.i8(i8 %292, i1 false)
  %294 = zext i8 %293 to i32
  %295 = select i1 %291, i32 %294, i32 0
  %.state207 = load <8 x i64>, ptr %.slot18, align 64
  %296 = icmp slt <8 x i64> %.state207, splat (i64 64)
  %297 = and <8 x i1> %290, %296
  %298 = xor <8 x i1> %296, splat (i1 true)
  %299 = and <8 x i1> %290, %298
  %300 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %297)
  %301 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %299)
  %302 = and i1 %300, %301
  br i1 %302, label %varying.divergent208, label %varying.coherent209

schedule.10:                                      ; preds = %varying.coherent.true214, %scheduler.dispatch.route
  %303 = load <8 x i1>, ptr %current.mask, align 1
  %304 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %303)
  %305 = bitcast <8 x i1> %303 to i8
  %306 = call i8 @llvm.cttz.i8(i8 %305, i1 false)
  %307 = zext i8 %306 to i32
  %308 = select i1 %304, i32 %307, i32 0
  %.state216 = load <8 x i64>, ptr %.slot18, align 64
  %309 = add <8 x i64> %.state216, zeroinitializer
  %310 = select <8 x i1> %303, <8 x i64> %309, <8 x i64> zeroinitializer
  %311 = select <8 x i1> %303, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %312 = sdiv <8 x i64> %310, %311
  %.spill.load217 = load i64, ptr %.spill17, align 4
  %.splatinsert218 = insertelement <8 x i64> poison, i64 %.spill.load217, i64 0
  %.splat219 = shufflevector <8 x i64> %.splatinsert218, <8 x i64> poison, <8 x i32> zeroinitializer
  %313 = add <8 x i64> %.splat219, %312
  %314 = select <8 x i1> %303, <8 x i64> %313, <8 x i64> zeroinitializer
  %315 = select <8 x i1> %303, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %316 = srem <8 x i64> %314, %315
  %317 = select <8 x i1> %303, <8 x i64> %313, <8 x i64> zeroinitializer
  %318 = select <8 x i1> %303, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %319 = sdiv <8 x i64> %317, %318
  %.spill.load220 = load i64, ptr %.spill5, align 4
  %.splatinsert221 = insertelement <8 x i64> poison, i64 %.spill.load220, i64 0
  %.splat222 = shufflevector <8 x i64> %.splatinsert221, <8 x i64> poison, <8 x i32> zeroinitializer
  %320 = add <8 x i64> %.splat222, %319
  %321 = mul <8 x i64> %320, splat (i64 65)
  %322 = add <8 x i64> %321, %316
  %tile_snapshot.spill.load223 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load223, 0
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load223, 1
  %325 = mul <8 x i64> %322, splat (i64 32)
  %326 = add <8 x i64> %324, %325
  %327 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %323, 0
  %328 = insertvalue { <8 x ptr>, <8 x i64> } %327, <8 x i64> %326, 1
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %328, 0
  %330 = extractvalue { <8 x ptr>, <8 x i64> } %328, 1
  %331 = getelementptr i8, <8 x ptr> %329, <8 x i64> %330
  %332 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %331, i32 1, <8 x i1> %303, <8 x float> zeroinitializer)
  %333 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %332)
  %.state224 = load <8 x float>, ptr %.slot19, align 32
  %334 = fadd <8 x float> %.state224, %333
  %.state225 = load <8 x i64>, ptr %.slot18, align 64
  %335 = add <8 x i64> %.state225, splat (i64 1)
  %336 = select <8 x i1> %303, <8 x i64> %335, <8 x i64> zeroinitializer
  %337 = select <8 x i1> %303, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %338 = sdiv <8 x i64> %336, %337
  %.spill.load226 = load i64, ptr %.spill17, align 4
  %.splatinsert227 = insertelement <8 x i64> poison, i64 %.spill.load226, i64 0
  %.splat228 = shufflevector <8 x i64> %.splatinsert227, <8 x i64> poison, <8 x i32> zeroinitializer
  %339 = add <8 x i64> %.splat228, %338
  %340 = select <8 x i1> %303, <8 x i64> %339, <8 x i64> zeroinitializer
  %341 = select <8 x i1> %303, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %342 = srem <8 x i64> %340, %341
  %343 = select <8 x i1> %303, <8 x i64> %339, <8 x i64> zeroinitializer
  %344 = select <8 x i1> %303, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %345 = sdiv <8 x i64> %343, %344
  %.spill.load229 = load i64, ptr %.spill5, align 4
  %.splatinsert230 = insertelement <8 x i64> poison, i64 %.spill.load229, i64 0
  %.splat231 = shufflevector <8 x i64> %.splatinsert230, <8 x i64> poison, <8 x i32> zeroinitializer
  %346 = add <8 x i64> %.splat231, %345
  %347 = mul <8 x i64> %346, splat (i64 65)
  %348 = add <8 x i64> %347, %342
  %tile_snapshot.spill.load232 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %349 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load232, 0
  %350 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load232, 1
  %351 = mul <8 x i64> %348, splat (i64 32)
  %352 = add <8 x i64> %350, %351
  %353 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %349, 0
  %354 = insertvalue { <8 x ptr>, <8 x i64> } %353, <8 x i64> %352, 1
  %355 = extractvalue { <8 x ptr>, <8 x i64> } %354, 0
  %356 = extractvalue { <8 x ptr>, <8 x i64> } %354, 1
  %357 = getelementptr i8, <8 x ptr> %355, <8 x i64> %356
  %358 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %357, i32 1, <8 x i1> %303, <8 x float> zeroinitializer)
  %359 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %358)
  %.state233 = load <8 x float>, ptr %.slot20, align 32
  %360 = fadd <8 x float> %.state233, %359
  %.state234 = load <8 x i64>, ptr %.slot18, align 64
  %361 = add <8 x i64> %.state234, splat (i64 2)
  %362 = select <8 x i1> %303, <8 x i64> %361, <8 x i64> zeroinitializer
  %363 = select <8 x i1> %303, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %364 = sdiv <8 x i64> %362, %363
  %.spill.load235 = load i64, ptr %.spill17, align 4
  %.splatinsert236 = insertelement <8 x i64> poison, i64 %.spill.load235, i64 0
  %.splat237 = shufflevector <8 x i64> %.splatinsert236, <8 x i64> poison, <8 x i32> zeroinitializer
  %365 = add <8 x i64> %.splat237, %364
  %366 = select <8 x i1> %303, <8 x i64> %365, <8 x i64> zeroinitializer
  %367 = select <8 x i1> %303, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %368 = srem <8 x i64> %366, %367
  %369 = select <8 x i1> %303, <8 x i64> %365, <8 x i64> zeroinitializer
  %370 = select <8 x i1> %303, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %371 = sdiv <8 x i64> %369, %370
  %.spill.load238 = load i64, ptr %.spill5, align 4
  %.splatinsert239 = insertelement <8 x i64> poison, i64 %.spill.load238, i64 0
  %.splat240 = shufflevector <8 x i64> %.splatinsert239, <8 x i64> poison, <8 x i32> zeroinitializer
  %372 = add <8 x i64> %.splat240, %371
  %373 = mul <8 x i64> %372, splat (i64 65)
  %374 = add <8 x i64> %373, %368
  %tile_snapshot.spill.load241 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %375 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load241, 0
  %376 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load241, 1
  %377 = mul <8 x i64> %374, splat (i64 32)
  %378 = add <8 x i64> %376, %377
  %379 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %375, 0
  %380 = insertvalue { <8 x ptr>, <8 x i64> } %379, <8 x i64> %378, 1
  %381 = extractvalue { <8 x ptr>, <8 x i64> } %380, 0
  %382 = extractvalue { <8 x ptr>, <8 x i64> } %380, 1
  %383 = getelementptr i8, <8 x ptr> %381, <8 x i64> %382
  %384 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %383, i32 1, <8 x i1> %303, <8 x float> zeroinitializer)
  %385 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %384)
  %.state242 = load <8 x float>, ptr %.slot21, align 32
  %386 = fadd <8 x float> %.state242, %385
  %.state243 = load <8 x i64>, ptr %.slot18, align 64
  %387 = add <8 x i64> %.state243, splat (i64 3)
  %388 = select <8 x i1> %303, <8 x i64> %387, <8 x i64> zeroinitializer
  %389 = select <8 x i1> %303, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %390 = sdiv <8 x i64> %388, %389
  %.spill.load244 = load i64, ptr %.spill17, align 4
  %.splatinsert245 = insertelement <8 x i64> poison, i64 %.spill.load244, i64 0
  %.splat246 = shufflevector <8 x i64> %.splatinsert245, <8 x i64> poison, <8 x i32> zeroinitializer
  %391 = add <8 x i64> %.splat246, %390
  %392 = select <8 x i1> %303, <8 x i64> %391, <8 x i64> zeroinitializer
  %393 = select <8 x i1> %303, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %394 = srem <8 x i64> %392, %393
  %395 = select <8 x i1> %303, <8 x i64> %391, <8 x i64> zeroinitializer
  %396 = select <8 x i1> %303, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %397 = sdiv <8 x i64> %395, %396
  %.spill.load247 = load i64, ptr %.spill5, align 4
  %.splatinsert248 = insertelement <8 x i64> poison, i64 %.spill.load247, i64 0
  %.splat249 = shufflevector <8 x i64> %.splatinsert248, <8 x i64> poison, <8 x i32> zeroinitializer
  %398 = add <8 x i64> %.splat249, %397
  %399 = mul <8 x i64> %398, splat (i64 65)
  %400 = add <8 x i64> %399, %394
  %tile_snapshot.spill.load250 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %401 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load250, 0
  %402 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load250, 1
  %403 = mul <8 x i64> %400, splat (i64 32)
  %404 = add <8 x i64> %402, %403
  %405 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %401, 0
  %406 = insertvalue { <8 x ptr>, <8 x i64> } %405, <8 x i64> %404, 1
  %407 = extractvalue { <8 x ptr>, <8 x i64> } %406, 0
  %408 = extractvalue { <8 x ptr>, <8 x i64> } %406, 1
  %409 = getelementptr i8, <8 x ptr> %407, <8 x i64> %408
  %410 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %409, i32 1, <8 x i1> %303, <8 x float> zeroinitializer)
  %411 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %410)
  %.state251 = load <8 x float>, ptr %.slot22, align 32
  %412 = fadd <8 x float> %.state251, %411
  %.state252 = load <8 x i64>, ptr %.slot18, align 64
  %413 = add <8 x i64> %.state252, splat (i64 4)
  %414 = load <8 x i64>, ptr %.slot18, align 64
  %415 = select <8 x i1> %303, <8 x i64> %413, <8 x i64> %414
  store <8 x i64> %415, ptr %.slot18, align 64
  %416 = load <8 x float>, ptr %.slot19, align 32
  %417 = select <8 x i1> %303, <8 x float> %334, <8 x float> %416
  store <8 x float> %417, ptr %.slot19, align 32
  %418 = load <8 x float>, ptr %.slot20, align 32
  %419 = select <8 x i1> %303, <8 x float> %360, <8 x float> %418
  store <8 x float> %419, ptr %.slot20, align 32
  %420 = load <8 x float>, ptr %.slot21, align 32
  %421 = select <8 x i1> %303, <8 x float> %386, <8 x float> %420
  store <8 x float> %421, ptr %.slot21, align 32
  %422 = load <8 x float>, ptr %.slot22, align 32
  %423 = select <8 x i1> %303, <8 x float> %412, <8 x float> %422
  store <8 x float> %423, ptr %.slot22, align 32
  store <8 x i1> %303, ptr %current.mask, align 1
  %424 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %303)
  br i1 %424, label %schedule.9, label %scheduler.loop

schedule.11:                                      ; preds = %varying.coherent.false215, %scheduler.dispatch.route
  %425 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token255 = load i32, ptr %current.token, align 4
  %convergence.token.present256 = icmp ne i32 %convergence.current.token255, 0
  br i1 %convergence.token.present256, label %convergence.cascade253, label %convergence.cascade.exit254

schedule.12:                                      ; preds = %schedule.13, %convergence.target.11.ready, %scheduler.dispatch.route
  %426 = load <8 x i1>, ptr %current.mask, align 1
  %427 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %426)
  %428 = bitcast <8 x i1> %426 to i8
  %429 = call i8 @llvm.cttz.i8(i8 %428, i1 false)
  %430 = zext i8 %429 to i32
  %431 = select i1 %427, i32 %430, i32 0
  %.state314 = load <8 x i64>, ptr %.slot25, align 64
  %432 = icmp slt <8 x i64> %.state314, splat (i64 64)
  %433 = and <8 x i1> %426, %432
  %434 = xor <8 x i1> %432, splat (i1 true)
  %435 = and <8 x i1> %426, %434
  %436 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %433)
  %437 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %435)
  %438 = and i1 %436, %437
  br i1 %438, label %varying.divergent315, label %varying.coherent316

schedule.13:                                      ; preds = %varying.coherent.true321, %scheduler.dispatch.route
  %439 = load <8 x i1>, ptr %current.mask, align 1
  %440 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %439)
  %441 = bitcast <8 x i1> %439 to i8
  %442 = call i8 @llvm.cttz.i8(i8 %441, i1 false)
  %443 = zext i8 %442 to i32
  %444 = select i1 %440, i32 %443, i32 0
  %.state323 = load <8 x i64>, ptr %.slot25, align 64
  %445 = add <8 x i64> %.state323, zeroinitializer
  %446 = select <8 x i1> %439, <8 x i64> %445, <8 x i64> zeroinitializer
  %447 = select <8 x i1> %439, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %448 = sdiv <8 x i64> %446, %447
  %.spill.load324 = load i64, ptr %.spill24, align 4
  %.splatinsert325 = insertelement <8 x i64> poison, i64 %.spill.load324, i64 0
  %.splat326 = shufflevector <8 x i64> %.splatinsert325, <8 x i64> poison, <8 x i32> zeroinitializer
  %449 = add <8 x i64> %.splat326, %448
  %450 = select <8 x i1> %439, <8 x i64> %449, <8 x i64> zeroinitializer
  %451 = select <8 x i1> %439, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %452 = srem <8 x i64> %450, %451
  %453 = select <8 x i1> %439, <8 x i64> %449, <8 x i64> zeroinitializer
  %454 = select <8 x i1> %439, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %455 = sdiv <8 x i64> %453, %454
  %.spill.load327 = load i64, ptr %.spill5, align 4
  %.splatinsert328 = insertelement <8 x i64> poison, i64 %.spill.load327, i64 0
  %.splat329 = shufflevector <8 x i64> %.splatinsert328, <8 x i64> poison, <8 x i32> zeroinitializer
  %456 = add <8 x i64> %.splat329, %455
  %457 = mul <8 x i64> %456, splat (i64 65)
  %458 = add <8 x i64> %457, %452
  %tile_snapshot.spill.load330 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %459 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load330, 0
  %460 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load330, 1
  %461 = mul <8 x i64> %458, splat (i64 32)
  %462 = add <8 x i64> %460, %461
  %463 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %459, 0
  %464 = insertvalue { <8 x ptr>, <8 x i64> } %463, <8 x i64> %462, 1
  %465 = extractvalue { <8 x ptr>, <8 x i64> } %464, 0
  %466 = extractvalue { <8 x ptr>, <8 x i64> } %464, 1
  %467 = getelementptr i8, <8 x ptr> %465, <8 x i64> %466
  %468 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %467, i32 1, <8 x i1> %439, <8 x float> zeroinitializer)
  %469 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %468)
  %.state331 = load <8 x float>, ptr %.slot26, align 32
  %470 = fadd <8 x float> %.state331, %469
  %.state332 = load <8 x i64>, ptr %.slot25, align 64
  %471 = add <8 x i64> %.state332, splat (i64 1)
  %472 = select <8 x i1> %439, <8 x i64> %471, <8 x i64> zeroinitializer
  %473 = select <8 x i1> %439, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %474 = sdiv <8 x i64> %472, %473
  %.spill.load333 = load i64, ptr %.spill24, align 4
  %.splatinsert334 = insertelement <8 x i64> poison, i64 %.spill.load333, i64 0
  %.splat335 = shufflevector <8 x i64> %.splatinsert334, <8 x i64> poison, <8 x i32> zeroinitializer
  %475 = add <8 x i64> %.splat335, %474
  %476 = select <8 x i1> %439, <8 x i64> %475, <8 x i64> zeroinitializer
  %477 = select <8 x i1> %439, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %478 = srem <8 x i64> %476, %477
  %479 = select <8 x i1> %439, <8 x i64> %475, <8 x i64> zeroinitializer
  %480 = select <8 x i1> %439, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %481 = sdiv <8 x i64> %479, %480
  %.spill.load336 = load i64, ptr %.spill5, align 4
  %.splatinsert337 = insertelement <8 x i64> poison, i64 %.spill.load336, i64 0
  %.splat338 = shufflevector <8 x i64> %.splatinsert337, <8 x i64> poison, <8 x i32> zeroinitializer
  %482 = add <8 x i64> %.splat338, %481
  %483 = mul <8 x i64> %482, splat (i64 65)
  %484 = add <8 x i64> %483, %478
  %tile_snapshot.spill.load339 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %485 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load339, 0
  %486 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load339, 1
  %487 = mul <8 x i64> %484, splat (i64 32)
  %488 = add <8 x i64> %486, %487
  %489 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %485, 0
  %490 = insertvalue { <8 x ptr>, <8 x i64> } %489, <8 x i64> %488, 1
  %491 = extractvalue { <8 x ptr>, <8 x i64> } %490, 0
  %492 = extractvalue { <8 x ptr>, <8 x i64> } %490, 1
  %493 = getelementptr i8, <8 x ptr> %491, <8 x i64> %492
  %494 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %493, i32 1, <8 x i1> %439, <8 x float> zeroinitializer)
  %495 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %494)
  %.state340 = load <8 x float>, ptr %.slot27, align 32
  %496 = fadd <8 x float> %.state340, %495
  %.state341 = load <8 x i64>, ptr %.slot25, align 64
  %497 = add <8 x i64> %.state341, splat (i64 2)
  %498 = select <8 x i1> %439, <8 x i64> %497, <8 x i64> zeroinitializer
  %499 = select <8 x i1> %439, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %500 = sdiv <8 x i64> %498, %499
  %.spill.load342 = load i64, ptr %.spill24, align 4
  %.splatinsert343 = insertelement <8 x i64> poison, i64 %.spill.load342, i64 0
  %.splat344 = shufflevector <8 x i64> %.splatinsert343, <8 x i64> poison, <8 x i32> zeroinitializer
  %501 = add <8 x i64> %.splat344, %500
  %502 = select <8 x i1> %439, <8 x i64> %501, <8 x i64> zeroinitializer
  %503 = select <8 x i1> %439, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %504 = srem <8 x i64> %502, %503
  %505 = select <8 x i1> %439, <8 x i64> %501, <8 x i64> zeroinitializer
  %506 = select <8 x i1> %439, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %507 = sdiv <8 x i64> %505, %506
  %.spill.load345 = load i64, ptr %.spill5, align 4
  %.splatinsert346 = insertelement <8 x i64> poison, i64 %.spill.load345, i64 0
  %.splat347 = shufflevector <8 x i64> %.splatinsert346, <8 x i64> poison, <8 x i32> zeroinitializer
  %508 = add <8 x i64> %.splat347, %507
  %509 = mul <8 x i64> %508, splat (i64 65)
  %510 = add <8 x i64> %509, %504
  %tile_snapshot.spill.load348 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %511 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load348, 0
  %512 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load348, 1
  %513 = mul <8 x i64> %510, splat (i64 32)
  %514 = add <8 x i64> %512, %513
  %515 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %511, 0
  %516 = insertvalue { <8 x ptr>, <8 x i64> } %515, <8 x i64> %514, 1
  %517 = extractvalue { <8 x ptr>, <8 x i64> } %516, 0
  %518 = extractvalue { <8 x ptr>, <8 x i64> } %516, 1
  %519 = getelementptr i8, <8 x ptr> %517, <8 x i64> %518
  %520 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %519, i32 1, <8 x i1> %439, <8 x float> zeroinitializer)
  %521 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %520)
  %.state349 = load <8 x float>, ptr %.slot28, align 32
  %522 = fadd <8 x float> %.state349, %521
  %.state350 = load <8 x i64>, ptr %.slot25, align 64
  %523 = add <8 x i64> %.state350, splat (i64 3)
  %524 = select <8 x i1> %439, <8 x i64> %523, <8 x i64> zeroinitializer
  %525 = select <8 x i1> %439, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %526 = sdiv <8 x i64> %524, %525
  %.spill.load351 = load i64, ptr %.spill24, align 4
  %.splatinsert352 = insertelement <8 x i64> poison, i64 %.spill.load351, i64 0
  %.splat353 = shufflevector <8 x i64> %.splatinsert352, <8 x i64> poison, <8 x i32> zeroinitializer
  %527 = add <8 x i64> %.splat353, %526
  %528 = select <8 x i1> %439, <8 x i64> %527, <8 x i64> zeroinitializer
  %529 = select <8 x i1> %439, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %530 = srem <8 x i64> %528, %529
  %531 = select <8 x i1> %439, <8 x i64> %527, <8 x i64> zeroinitializer
  %532 = select <8 x i1> %439, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %533 = sdiv <8 x i64> %531, %532
  %.spill.load354 = load i64, ptr %.spill5, align 4
  %.splatinsert355 = insertelement <8 x i64> poison, i64 %.spill.load354, i64 0
  %.splat356 = shufflevector <8 x i64> %.splatinsert355, <8 x i64> poison, <8 x i32> zeroinitializer
  %534 = add <8 x i64> %.splat356, %533
  %535 = mul <8 x i64> %534, splat (i64 65)
  %536 = add <8 x i64> %535, %530
  %tile_snapshot.spill.load357 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %537 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load357, 0
  %538 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load357, 1
  %539 = mul <8 x i64> %536, splat (i64 32)
  %540 = add <8 x i64> %538, %539
  %541 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %537, 0
  %542 = insertvalue { <8 x ptr>, <8 x i64> } %541, <8 x i64> %540, 1
  %543 = extractvalue { <8 x ptr>, <8 x i64> } %542, 0
  %544 = extractvalue { <8 x ptr>, <8 x i64> } %542, 1
  %545 = getelementptr i8, <8 x ptr> %543, <8 x i64> %544
  %546 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %545, i32 1, <8 x i1> %439, <8 x float> zeroinitializer)
  %547 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %546)
  %.state358 = load <8 x float>, ptr %.slot29, align 32
  %548 = fadd <8 x float> %.state358, %547
  %.state359 = load <8 x i64>, ptr %.slot25, align 64
  %549 = add <8 x i64> %.state359, splat (i64 4)
  %550 = load <8 x i64>, ptr %.slot25, align 64
  %551 = select <8 x i1> %439, <8 x i64> %549, <8 x i64> %550
  store <8 x i64> %551, ptr %.slot25, align 64
  %552 = load <8 x float>, ptr %.slot26, align 32
  %553 = select <8 x i1> %439, <8 x float> %470, <8 x float> %552
  store <8 x float> %553, ptr %.slot26, align 32
  %554 = load <8 x float>, ptr %.slot27, align 32
  %555 = select <8 x i1> %439, <8 x float> %496, <8 x float> %554
  store <8 x float> %555, ptr %.slot27, align 32
  %556 = load <8 x float>, ptr %.slot28, align 32
  %557 = select <8 x i1> %439, <8 x float> %522, <8 x float> %556
  store <8 x float> %557, ptr %.slot28, align 32
  %558 = load <8 x float>, ptr %.slot29, align 32
  %559 = select <8 x i1> %439, <8 x float> %548, <8 x float> %558
  store <8 x float> %559, ptr %.slot29, align 32
  store <8 x i1> %439, ptr %current.mask, align 1
  %560 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %439)
  br i1 %560, label %schedule.12, label %scheduler.loop

schedule.14:                                      ; preds = %varying.coherent.false322, %scheduler.dispatch.route
  %561 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token362 = load i32, ptr %current.token, align 4
  %convergence.token.present363 = icmp ne i32 %convergence.current.token362, 0
  br i1 %convergence.token.present363, label %convergence.cascade360, label %convergence.cascade.exit361

schedule.15:                                      ; preds = %schedule.16, %convergence.target.14.ready, %scheduler.dispatch.route
  %562 = load <8 x i1>, ptr %current.mask, align 1
  %563 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %562)
  %564 = bitcast <8 x i1> %562 to i8
  %565 = call i8 @llvm.cttz.i8(i8 %564, i1 false)
  %566 = zext i8 %565 to i32
  %567 = select i1 %563, i32 %566, i32 0
  %.state421 = load <8 x i64>, ptr %.slot32, align 64
  %568 = icmp slt <8 x i64> %.state421, splat (i64 64)
  %569 = and <8 x i1> %562, %568
  %570 = xor <8 x i1> %568, splat (i1 true)
  %571 = and <8 x i1> %562, %570
  %572 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %569)
  %573 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %571)
  %574 = and i1 %572, %573
  br i1 %574, label %varying.divergent422, label %varying.coherent423

schedule.16:                                      ; preds = %varying.coherent.true428, %scheduler.dispatch.route
  %575 = load <8 x i1>, ptr %current.mask, align 1
  %576 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %575)
  %577 = bitcast <8 x i1> %575 to i8
  %578 = call i8 @llvm.cttz.i8(i8 %577, i1 false)
  %579 = zext i8 %578 to i32
  %580 = select i1 %576, i32 %579, i32 0
  %.state430 = load <8 x i64>, ptr %.slot32, align 64
  %581 = add <8 x i64> %.state430, zeroinitializer
  %582 = select <8 x i1> %575, <8 x i64> %581, <8 x i64> zeroinitializer
  %583 = select <8 x i1> %575, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %584 = sdiv <8 x i64> %582, %583
  %.spill.load431 = load i64, ptr %.spill31, align 4
  %.splatinsert432 = insertelement <8 x i64> poison, i64 %.spill.load431, i64 0
  %.splat433 = shufflevector <8 x i64> %.splatinsert432, <8 x i64> poison, <8 x i32> zeroinitializer
  %585 = add <8 x i64> %.splat433, %584
  %586 = select <8 x i1> %575, <8 x i64> %585, <8 x i64> zeroinitializer
  %587 = select <8 x i1> %575, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %588 = srem <8 x i64> %586, %587
  %589 = select <8 x i1> %575, <8 x i64> %585, <8 x i64> zeroinitializer
  %590 = select <8 x i1> %575, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %591 = sdiv <8 x i64> %589, %590
  %.spill.load434 = load i64, ptr %.spill5, align 4
  %.splatinsert435 = insertelement <8 x i64> poison, i64 %.spill.load434, i64 0
  %.splat436 = shufflevector <8 x i64> %.splatinsert435, <8 x i64> poison, <8 x i32> zeroinitializer
  %592 = add <8 x i64> %.splat436, %591
  %593 = mul <8 x i64> %592, splat (i64 65)
  %594 = add <8 x i64> %593, %588
  %tile_snapshot.spill.load437 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %595 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load437, 0
  %596 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load437, 1
  %597 = mul <8 x i64> %594, splat (i64 32)
  %598 = add <8 x i64> %596, %597
  %599 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %595, 0
  %600 = insertvalue { <8 x ptr>, <8 x i64> } %599, <8 x i64> %598, 1
  %601 = extractvalue { <8 x ptr>, <8 x i64> } %600, 0
  %602 = extractvalue { <8 x ptr>, <8 x i64> } %600, 1
  %603 = getelementptr i8, <8 x ptr> %601, <8 x i64> %602
  %604 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %603, i32 1, <8 x i1> %575, <8 x float> zeroinitializer)
  %605 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %604)
  %.state438 = load <8 x float>, ptr %.slot33, align 32
  %606 = fadd <8 x float> %.state438, %605
  %.state439 = load <8 x i64>, ptr %.slot32, align 64
  %607 = add <8 x i64> %.state439, splat (i64 1)
  %608 = select <8 x i1> %575, <8 x i64> %607, <8 x i64> zeroinitializer
  %609 = select <8 x i1> %575, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %610 = sdiv <8 x i64> %608, %609
  %.spill.load440 = load i64, ptr %.spill31, align 4
  %.splatinsert441 = insertelement <8 x i64> poison, i64 %.spill.load440, i64 0
  %.splat442 = shufflevector <8 x i64> %.splatinsert441, <8 x i64> poison, <8 x i32> zeroinitializer
  %611 = add <8 x i64> %.splat442, %610
  %612 = select <8 x i1> %575, <8 x i64> %611, <8 x i64> zeroinitializer
  %613 = select <8 x i1> %575, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %614 = srem <8 x i64> %612, %613
  %615 = select <8 x i1> %575, <8 x i64> %611, <8 x i64> zeroinitializer
  %616 = select <8 x i1> %575, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %617 = sdiv <8 x i64> %615, %616
  %.spill.load443 = load i64, ptr %.spill5, align 4
  %.splatinsert444 = insertelement <8 x i64> poison, i64 %.spill.load443, i64 0
  %.splat445 = shufflevector <8 x i64> %.splatinsert444, <8 x i64> poison, <8 x i32> zeroinitializer
  %618 = add <8 x i64> %.splat445, %617
  %619 = mul <8 x i64> %618, splat (i64 65)
  %620 = add <8 x i64> %619, %614
  %tile_snapshot.spill.load446 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %621 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load446, 0
  %622 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load446, 1
  %623 = mul <8 x i64> %620, splat (i64 32)
  %624 = add <8 x i64> %622, %623
  %625 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %621, 0
  %626 = insertvalue { <8 x ptr>, <8 x i64> } %625, <8 x i64> %624, 1
  %627 = extractvalue { <8 x ptr>, <8 x i64> } %626, 0
  %628 = extractvalue { <8 x ptr>, <8 x i64> } %626, 1
  %629 = getelementptr i8, <8 x ptr> %627, <8 x i64> %628
  %630 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %629, i32 1, <8 x i1> %575, <8 x float> zeroinitializer)
  %631 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %630)
  %.state447 = load <8 x float>, ptr %.slot34, align 32
  %632 = fadd <8 x float> %.state447, %631
  %.state448 = load <8 x i64>, ptr %.slot32, align 64
  %633 = add <8 x i64> %.state448, splat (i64 2)
  %634 = select <8 x i1> %575, <8 x i64> %633, <8 x i64> zeroinitializer
  %635 = select <8 x i1> %575, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %636 = sdiv <8 x i64> %634, %635
  %.spill.load449 = load i64, ptr %.spill31, align 4
  %.splatinsert450 = insertelement <8 x i64> poison, i64 %.spill.load449, i64 0
  %.splat451 = shufflevector <8 x i64> %.splatinsert450, <8 x i64> poison, <8 x i32> zeroinitializer
  %637 = add <8 x i64> %.splat451, %636
  %638 = select <8 x i1> %575, <8 x i64> %637, <8 x i64> zeroinitializer
  %639 = select <8 x i1> %575, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %640 = srem <8 x i64> %638, %639
  %641 = select <8 x i1> %575, <8 x i64> %637, <8 x i64> zeroinitializer
  %642 = select <8 x i1> %575, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %643 = sdiv <8 x i64> %641, %642
  %.spill.load452 = load i64, ptr %.spill5, align 4
  %.splatinsert453 = insertelement <8 x i64> poison, i64 %.spill.load452, i64 0
  %.splat454 = shufflevector <8 x i64> %.splatinsert453, <8 x i64> poison, <8 x i32> zeroinitializer
  %644 = add <8 x i64> %.splat454, %643
  %645 = mul <8 x i64> %644, splat (i64 65)
  %646 = add <8 x i64> %645, %640
  %tile_snapshot.spill.load455 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %647 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 0
  %648 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 1
  %649 = mul <8 x i64> %646, splat (i64 32)
  %650 = add <8 x i64> %648, %649
  %651 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %647, 0
  %652 = insertvalue { <8 x ptr>, <8 x i64> } %651, <8 x i64> %650, 1
  %653 = extractvalue { <8 x ptr>, <8 x i64> } %652, 0
  %654 = extractvalue { <8 x ptr>, <8 x i64> } %652, 1
  %655 = getelementptr i8, <8 x ptr> %653, <8 x i64> %654
  %656 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %655, i32 1, <8 x i1> %575, <8 x float> zeroinitializer)
  %657 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %656)
  %.state456 = load <8 x float>, ptr %.slot35, align 32
  %658 = fadd <8 x float> %.state456, %657
  %.state457 = load <8 x i64>, ptr %.slot32, align 64
  %659 = add <8 x i64> %.state457, splat (i64 3)
  %660 = select <8 x i1> %575, <8 x i64> %659, <8 x i64> zeroinitializer
  %661 = select <8 x i1> %575, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %662 = sdiv <8 x i64> %660, %661
  %.spill.load458 = load i64, ptr %.spill31, align 4
  %.splatinsert459 = insertelement <8 x i64> poison, i64 %.spill.load458, i64 0
  %.splat460 = shufflevector <8 x i64> %.splatinsert459, <8 x i64> poison, <8 x i32> zeroinitializer
  %663 = add <8 x i64> %.splat460, %662
  %664 = select <8 x i1> %575, <8 x i64> %663, <8 x i64> zeroinitializer
  %665 = select <8 x i1> %575, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %666 = srem <8 x i64> %664, %665
  %667 = select <8 x i1> %575, <8 x i64> %663, <8 x i64> zeroinitializer
  %668 = select <8 x i1> %575, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %669 = sdiv <8 x i64> %667, %668
  %.spill.load461 = load i64, ptr %.spill5, align 4
  %.splatinsert462 = insertelement <8 x i64> poison, i64 %.spill.load461, i64 0
  %.splat463 = shufflevector <8 x i64> %.splatinsert462, <8 x i64> poison, <8 x i32> zeroinitializer
  %670 = add <8 x i64> %.splat463, %669
  %671 = mul <8 x i64> %670, splat (i64 65)
  %672 = add <8 x i64> %671, %666
  %tile_snapshot.spill.load464 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %673 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load464, 0
  %674 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load464, 1
  %675 = mul <8 x i64> %672, splat (i64 32)
  %676 = add <8 x i64> %674, %675
  %677 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %673, 0
  %678 = insertvalue { <8 x ptr>, <8 x i64> } %677, <8 x i64> %676, 1
  %679 = extractvalue { <8 x ptr>, <8 x i64> } %678, 0
  %680 = extractvalue { <8 x ptr>, <8 x i64> } %678, 1
  %681 = getelementptr i8, <8 x ptr> %679, <8 x i64> %680
  %682 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %681, i32 1, <8 x i1> %575, <8 x float> zeroinitializer)
  %683 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %682)
  %.state465 = load <8 x float>, ptr %.slot36, align 32
  %684 = fadd <8 x float> %.state465, %683
  %.state466 = load <8 x i64>, ptr %.slot32, align 64
  %685 = add <8 x i64> %.state466, splat (i64 4)
  %686 = load <8 x i64>, ptr %.slot32, align 64
  %687 = select <8 x i1> %575, <8 x i64> %685, <8 x i64> %686
  store <8 x i64> %687, ptr %.slot32, align 64
  %688 = load <8 x float>, ptr %.slot33, align 32
  %689 = select <8 x i1> %575, <8 x float> %606, <8 x float> %688
  store <8 x float> %689, ptr %.slot33, align 32
  %690 = load <8 x float>, ptr %.slot34, align 32
  %691 = select <8 x i1> %575, <8 x float> %632, <8 x float> %690
  store <8 x float> %691, ptr %.slot34, align 32
  %692 = load <8 x float>, ptr %.slot35, align 32
  %693 = select <8 x i1> %575, <8 x float> %658, <8 x float> %692
  store <8 x float> %693, ptr %.slot35, align 32
  %694 = load <8 x float>, ptr %.slot36, align 32
  %695 = select <8 x i1> %575, <8 x float> %684, <8 x float> %694
  store <8 x float> %695, ptr %.slot36, align 32
  store <8 x i1> %575, ptr %current.mask, align 1
  %696 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %575)
  br i1 %696, label %schedule.15, label %scheduler.loop

schedule.17:                                      ; preds = %varying.coherent.false429, %scheduler.dispatch.route
  %697 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token469 = load i32, ptr %current.token, align 4
  %convergence.token.present470 = icmp ne i32 %convergence.current.token469, 0
  br i1 %convergence.token.present470, label %convergence.cascade467, label %convergence.cascade.exit468

schedule.18:                                      ; preds = %varying.coherent.true508, %scheduler.dispatch.route
  %698 = load <8 x i1>, ptr %current.mask, align 1
  %699 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %698)
  %700 = bitcast <8 x i1> %698 to i8
  %701 = call i8 @llvm.cttz.i8(i8 %700, i1 false)
  %702 = zext i8 %701 to i32
  %703 = select i1 %699, i32 %702, i32 0
  %.spill.load510 = load <8 x i64>, ptr %.spill39, align 64
  %.spill.load511 = load <8 x float>, ptr %.spill23, align 32
  %704 = extractvalue { ptr, i64 } %13, 0
  %705 = mul <8 x i64> %.spill.load510, splat (i64 4)
  %706 = getelementptr i8, ptr %704, <8 x i64> %705
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.spill.load511, <8 x ptr> %706, i32 1, <8 x i1> %698)
  store <8 x i1> %698, ptr %current.mask, align 1
  %707 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %698)
  br i1 %707, label %schedule.19, label %scheduler.loop

schedule.19:                                      ; preds = %schedule.18, %varying.coherent.false509, %scheduler.dispatch.route
  %708 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token514 = load i32, ptr %current.token, align 4
  %convergence.token.present515 = icmp ne i32 %convergence.current.token514, 0
  br i1 %convergence.token.present515, label %convergence.cascade512, label %convergence.cascade.exit513

schedule.20:                                      ; preds = %varying.coherent.true539, %scheduler.dispatch.route
  %709 = load <8 x i1>, ptr %current.mask, align 1
  %710 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %709)
  %711 = bitcast <8 x i1> %709 to i8
  %712 = call i8 @llvm.cttz.i8(i8 %711, i1 false)
  %713 = zext i8 %712 to i32
  %714 = select i1 %710, i32 %713, i32 0
  %.spill.load541 = load <8 x i64>, ptr %.spill40, align 64
  %.spill.load542 = load <8 x float>, ptr %.spill30, align 32
  %715 = extractvalue { ptr, i64 } %13, 0
  %716 = mul <8 x i64> %.spill.load541, splat (i64 4)
  %717 = getelementptr i8, ptr %715, <8 x i64> %716
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.spill.load542, <8 x ptr> %717, i32 1, <8 x i1> %709)
  store <8 x i1> %709, ptr %current.mask, align 1
  %718 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %709)
  br i1 %718, label %schedule.21, label %scheduler.loop

schedule.21:                                      ; preds = %schedule.20, %varying.coherent.false540, %scheduler.dispatch.route
  %719 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token545 = load i32, ptr %current.token, align 4
  %convergence.token.present546 = icmp ne i32 %convergence.current.token545, 0
  br i1 %convergence.token.present546, label %convergence.cascade543, label %convergence.cascade.exit544

schedule.22:                                      ; preds = %varying.coherent.true570, %scheduler.dispatch.route
  %720 = load <8 x i1>, ptr %current.mask, align 1
  %721 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %720)
  %722 = bitcast <8 x i1> %720 to i8
  %723 = call i8 @llvm.cttz.i8(i8 %722, i1 false)
  %724 = zext i8 %723 to i32
  %725 = select i1 %721, i32 %724, i32 0
  %.spill.load572 = load <8 x i64>, ptr %.spill41, align 64
  %.spill.load573 = load <8 x float>, ptr %.spill37, align 32
  %726 = extractvalue { ptr, i64 } %13, 0
  %727 = mul <8 x i64> %.spill.load572, splat (i64 4)
  %728 = getelementptr i8, ptr %726, <8 x i64> %727
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.spill.load573, <8 x ptr> %728, i32 1, <8 x i1> %720)
  store <8 x i1> %720, ptr %current.mask, align 1
  %729 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %720)
  br i1 %729, label %schedule.23, label %scheduler.loop

schedule.23:                                      ; preds = %schedule.22, %varying.coherent.false571, %scheduler.dispatch.route
  %730 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token576 = load i32, ptr %current.token, align 4
  %convergence.token.present577 = icmp ne i32 %convergence.current.token576, 0
  br i1 %convergence.token.present577, label %convergence.cascade574, label %convergence.cascade.exit575

varying.divergent:                                ; preds = %schedule.1
  %731 = load i32, ptr %current.token, align 4
  %732 = icmp ne i32 %731, 0
  %733 = sub i32 %731, 1
  %734 = select i1 %732, i32 %733, i32 0
  %735 = load i8, ptr %frame.active, align 1
  %736 = trunc i32 %734 to i8
  %737 = shl i8 1, %736
  %738 = and i8 %735, %737
  %739 = icmp ne i8 %738, 0
  %740 = load <8 x i32>, ptr %frame.static.id, align 32
  %741 = extractelement <8 x i32> %740, i32 %734
  %742 = icmp eq i32 %741, 0
  %743 = and i1 %739, %742
  %744 = and i1 %732, %743
  %745 = xor i1 %744, true
  %746 = and i1 true, %745
  %747 = xor i8 %735, -1
  %748 = icmp ne i8 %747, 0
  %749 = xor i1 %748, true
  %750 = and i1 %746, %749
  br i1 %750, label %convergence.overflow.trap, label %convergence.overflow.resume

varying.coherent:                                 ; preds = %schedule.1
  br i1 %107, label %varying.coherent.true, label %varying.coherent.false

convergence.overflow.trap:                        ; preds = %varying.divergent
  call void @llvm.trap()
  unreachable

convergence.overflow.resume:                      ; preds = %varying.divergent
  %751 = call i8 @llvm.cttz.i8(i8 %747, i1 false)
  %752 = zext i8 %751 to i32
  %753 = select i1 %748, i32 %752, i32 0
  %754 = trunc i32 %753 to i8
  %755 = shl i8 1, %754
  %756 = or i8 %735, %755
  %757 = select i1 %746, i8 %756, i8 %735
  store i8 %757, ptr %frame.active, align 1
  %758 = load <8 x i32>, ptr %frame.static.id, align 32
  %759 = extractelement <8 x i32> %758, i32 %753
  %760 = select i1 %746, i32 0, i32 %759
  %761 = load <8 x i32>, ptr %frame.static.id, align 32
  %762 = insertelement <8 x i32> %761, i32 %760, i32 %753
  store <8 x i32> %762, ptr %frame.static.id, align 32
  %763 = load <8 x i32>, ptr %frame.parent.token, align 32
  %764 = extractelement <8 x i32> %763, i32 %753
  %765 = select i1 %746, i32 %731, i32 %764
  %766 = load <8 x i32>, ptr %frame.parent.token, align 32
  %767 = insertelement <8 x i32> %766, i32 %765, i32 %753
  store <8 x i32> %767, ptr %frame.parent.token, align 32
  %768 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %753
  %769 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %753
  %770 = load <8 x i1>, ptr %768, align 1
  %771 = load <8 x i1>, ptr %769, align 1
  %772 = select i1 %746, <8 x i1> %97, <8 x i1> %770
  store <8 x i1> %772, ptr %768, align 1
  %773 = select i1 %746, <8 x i1> zeroinitializer, <8 x i1> %771
  store <8 x i1> %773, ptr %769, align 1
  %774 = add i32 %753, 1
  %775 = select i1 %744, i32 %731, i32 %774
  %776 = select i1 true, i32 %775, i32 %731
  store i32 %776, ptr %current.token, align 4
  %777 = load i32, ptr %current.token, align 4
  %778 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %104)
  %779 = load i32, ptr %ready.count, align 4
  %780 = icmp uge i32 %779, 8
  %781 = and i1 %778, %780
  br i1 %781, label %ready.overflow.trap52, label %ready.overflow.resume53

ready.overflow.trap52:                            ; preds = %convergence.overflow.resume
  call void @llvm.trap()
  unreachable

ready.overflow.resume53:                          ; preds = %convergence.overflow.resume
  %782 = select i1 %778, i32 %779, i32 0
  %783 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %782
  %784 = load <8 x i1>, ptr %783, align 1
  %785 = select i1 %778, <8 x i1> %104, <8 x i1> %784
  store <8 x i1> %785, ptr %783, align 1
  %786 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %782
  %787 = load i32, ptr %786, align 4
  %788 = select i1 %778, i32 2, i32 %787
  store i32 %788, ptr %786, align 4
  %789 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %782
  %790 = load i32, ptr %789, align 4
  %791 = select i1 %778, i32 %777, i32 %790
  store i32 %791, ptr %789, align 4
  %792 = add i32 %779, 1
  %793 = select i1 %778, i32 %792, i32 %779
  store i32 %793, ptr %ready.count, align 4
  %794 = load <8 x i1>, ptr %runnable.mask, align 1
  %795 = or <8 x i1> %794, %104
  store <8 x i1> %795, ptr %runnable.mask, align 1
  store <8 x i1> %106, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true:                            ; preds = %varying.coherent
  store <8 x i1> %97, ptr %current.mask, align 1
  %796 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %97)
  br i1 %796, label %schedule.2, label %scheduler.loop

varying.coherent.false:                           ; preds = %varying.coherent
  store <8 x i1> %97, ptr %current.mask, align 1
  %797 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %97)
  br i1 %797, label %schedule.5, label %scheduler.loop

varying.divergent56:                              ; preds = %schedule.2
  %798 = load i32, ptr %current.token, align 4
  %799 = icmp ne i32 %798, 0
  %800 = sub i32 %798, 1
  %801 = select i1 %799, i32 %800, i32 0
  %802 = load i8, ptr %frame.active, align 1
  %803 = trunc i32 %801 to i8
  %804 = shl i8 1, %803
  %805 = and i8 %802, %804
  %806 = icmp ne i8 %805, 0
  %807 = load <8 x i32>, ptr %frame.static.id, align 32
  %808 = extractelement <8 x i32> %807, i32 %801
  %809 = icmp eq i32 %808, 1
  %810 = and i1 %806, %809
  %811 = and i1 %799, %810
  %812 = xor i1 %811, true
  %813 = and i1 true, %812
  %814 = xor i8 %802, -1
  %815 = icmp ne i8 %814, 0
  %816 = xor i1 %815, true
  %817 = and i1 %813, %816
  br i1 %817, label %convergence.overflow.trap58, label %convergence.overflow.resume59

varying.coherent57:                               ; preds = %schedule.2
  br i1 %136, label %varying.coherent.true62, label %varying.coherent.false63

convergence.overflow.trap58:                      ; preds = %varying.divergent56
  call void @llvm.trap()
  unreachable

convergence.overflow.resume59:                    ; preds = %varying.divergent56
  %818 = call i8 @llvm.cttz.i8(i8 %814, i1 false)
  %819 = zext i8 %818 to i32
  %820 = select i1 %815, i32 %819, i32 0
  %821 = trunc i32 %820 to i8
  %822 = shl i8 1, %821
  %823 = or i8 %802, %822
  %824 = select i1 %813, i8 %823, i8 %802
  store i8 %824, ptr %frame.active, align 1
  %825 = load <8 x i32>, ptr %frame.static.id, align 32
  %826 = extractelement <8 x i32> %825, i32 %820
  %827 = select i1 %813, i32 1, i32 %826
  %828 = load <8 x i32>, ptr %frame.static.id, align 32
  %829 = insertelement <8 x i32> %828, i32 %827, i32 %820
  store <8 x i32> %829, ptr %frame.static.id, align 32
  %830 = load <8 x i32>, ptr %frame.parent.token, align 32
  %831 = extractelement <8 x i32> %830, i32 %820
  %832 = select i1 %813, i32 %798, i32 %831
  %833 = load <8 x i32>, ptr %frame.parent.token, align 32
  %834 = insertelement <8 x i32> %833, i32 %832, i32 %820
  store <8 x i32> %834, ptr %frame.parent.token, align 32
  %835 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %820
  %836 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %820
  %837 = load <8 x i1>, ptr %835, align 1
  %838 = load <8 x i1>, ptr %836, align 1
  %839 = select i1 %813, <8 x i1> %110, <8 x i1> %837
  store <8 x i1> %839, ptr %835, align 1
  %840 = select i1 %813, <8 x i1> zeroinitializer, <8 x i1> %838
  store <8 x i1> %840, ptr %836, align 1
  %841 = add i32 %820, 1
  %842 = select i1 %811, i32 %798, i32 %841
  %843 = select i1 true, i32 %842, i32 %798
  store i32 %843, ptr %current.token, align 4
  %844 = load <8 x float>, ptr %.slot2, align 32
  %845 = select <8 x i1> %135, <8 x float> zeroinitializer, <8 x float> %844
  store <8 x float> %845, ptr %.slot2, align 32
  %846 = load i32, ptr %current.token, align 4
  %847 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %133)
  %848 = load i32, ptr %ready.count, align 4
  %849 = icmp uge i32 %848, 8
  %850 = and i1 %847, %849
  br i1 %850, label %ready.overflow.trap60, label %ready.overflow.resume61

ready.overflow.trap60:                            ; preds = %convergence.overflow.resume59
  call void @llvm.trap()
  unreachable

ready.overflow.resume61:                          ; preds = %convergence.overflow.resume59
  %851 = select i1 %847, i32 %848, i32 0
  %852 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %851
  %853 = load <8 x i1>, ptr %852, align 1
  %854 = select i1 %847, <8 x i1> %133, <8 x i1> %853
  store <8 x i1> %854, ptr %852, align 1
  %855 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %851
  %856 = load i32, ptr %855, align 4
  %857 = select i1 %847, i32 3, i32 %856
  store i32 %857, ptr %855, align 4
  %858 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %851
  %859 = load i32, ptr %858, align 4
  %860 = select i1 %847, i32 %846, i32 %859
  store i32 %860, ptr %858, align 4
  %861 = add i32 %848, 1
  %862 = select i1 %847, i32 %861, i32 %848
  store i32 %862, ptr %ready.count, align 4
  %863 = load <8 x i1>, ptr %runnable.mask, align 1
  %864 = or <8 x i1> %863, %133
  store <8 x i1> %864, ptr %runnable.mask, align 1
  store <8 x i1> %135, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true62:                          ; preds = %varying.coherent57
  store <8 x i1> %110, ptr %current.mask, align 1
  %865 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %110)
  br i1 %865, label %schedule.3, label %scheduler.loop

varying.coherent.false63:                         ; preds = %varying.coherent57
  %866 = load <8 x float>, ptr %.slot2, align 32
  %867 = select <8 x i1> %110, <8 x float> zeroinitializer, <8 x float> %866
  store <8 x float> %867, ptr %.slot2, align 32
  store <8 x i1> %110, ptr %current.mask, align 1
  %868 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %110)
  br i1 %868, label %schedule.4, label %scheduler.loop

convergence.cascade:                              ; preds = %convergence.cascade, %schedule.4
  %convergence.cascade.flow = phi <8 x i1> [ %152, %schedule.4 ], [ %911, %convergence.cascade ]
  %convergence.cascade.depth = phi i32 [ 0, %schedule.4 ], [ %912, %convergence.cascade ]
  %869 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow)
  %870 = load i32, ptr %current.token, align 4
  %871 = icmp ne i32 %870, 0
  %872 = and i1 %869, %871
  %873 = sub i32 %870, 1
  %874 = select i1 %872, i32 %873, i32 0
  %875 = load i8, ptr %frame.active, align 1
  %876 = trunc i32 %874 to i8
  %877 = shl i8 1, %876
  %878 = and i8 %875, %877
  %879 = icmp ne i8 %878, 0
  %880 = load <8 x i32>, ptr %frame.static.id, align 32
  %881 = extractelement <8 x i32> %880, i32 %874
  %convergence.target.pointer = getelementptr inbounds [9 x i32], ptr @convergence.targets, i32 0, i32 %881
  %convergence.dynamic.target = load i32, ptr %convergence.target.pointer, align 4
  %882 = icmp eq i32 %convergence.dynamic.target, 4
  %883 = and i1 %879, %882
  %884 = and i1 %872, %883
  %885 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %874
  %886 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %874
  %887 = load <8 x i1>, ptr %885, align 1
  %888 = load <8 x i1>, ptr %886, align 1
  %889 = or <8 x i1> %888, %convergence.cascade.flow
  %890 = load <8 x i1>, ptr %live.mask, align 1
  %891 = and <8 x i1> %887, %890
  %892 = icmp eq <8 x i1> %889, %891
  %893 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %892)
  %894 = and i1 %884, %893
  %895 = select i1 %894, <8 x i1> zeroinitializer, <8 x i1> %889
  %896 = select i1 %884, <8 x i1> %895, <8 x i1> %888
  store <8 x i1> %896, ptr %886, align 1
  %897 = select i1 %894, <8 x i1> zeroinitializer, <8 x i1> %887
  store <8 x i1> %897, ptr %885, align 1
  %898 = trunc i32 %874 to i8
  %899 = shl i8 1, %898
  %900 = xor i8 %899, -1
  %901 = and i8 %875, %900
  %902 = select i1 %894, i8 %901, i8 %875
  store i8 %902, ptr %frame.active, align 1
  %.splatinsert65 = insertelement <8 x i1> poison, i1 %884, i64 0
  %.splat66 = shufflevector <8 x i1> %.splatinsert65, <8 x i1> poison, <8 x i32> zeroinitializer
  %903 = and <8 x i1> %convergence.cascade.flow, %.splat66
  %904 = load <8 x i1>, ptr %runnable.mask, align 1
  %905 = xor <8 x i1> %903, splat (i1 true)
  %906 = and <8 x i1> %904, %905
  store <8 x i1> %906, ptr %runnable.mask, align 1
  %.splatinsert67 = insertelement <8 x i1> poison, i1 %894, i64 0
  %.splat68 = shufflevector <8 x i1> %.splatinsert67, <8 x i1> poison, <8 x i32> zeroinitializer
  %907 = select <8 x i1> %.splat68, <8 x i1> %889, <8 x i1> zeroinitializer
  %908 = load <8 x i32>, ptr %frame.parent.token, align 32
  %909 = extractelement <8 x i32> %908, i32 %874
  %910 = select i1 %894, i32 %909, i32 %870
  store i32 %910, ptr %current.token, align 4
  %.splatinsert69 = insertelement <8 x i1> poison, i1 %884, i64 0
  %.splat70 = shufflevector <8 x i1> %.splatinsert69, <8 x i1> poison, <8 x i32> zeroinitializer
  %911 = select <8 x i1> %.splat70, <8 x i1> %907, <8 x i1> %convergence.cascade.flow
  %912 = add i32 %convergence.cascade.depth, 1
  %913 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %911)
  %914 = icmp ult i32 %912, 8
  %915 = and i1 %913, %914
  %916 = and i1 %884, %915
  %convergence.parent.token = load i32, ptr %current.token, align 4
  %convergence.parent.present = icmp ne i32 %convergence.parent.token, 0
  %917 = and i1 %916, %convergence.parent.present
  br i1 %917, label %convergence.cascade, label %convergence.cascade.exit

convergence.cascade.exit:                         ; preds = %convergence.cascade, %schedule.4
  %convergence.cascade.result = phi <8 x i1> [ %152, %schedule.4 ], [ %911, %convergence.cascade ]
  %918 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %918, label %convergence.target.4.ready, label %scheduler.loop

convergence.target.4.ready:                       ; preds = %convergence.cascade.exit
  %919 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %920 = bitcast <8 x i1> %convergence.cascade.result to i8
  %921 = call i8 @llvm.cttz.i8(i8 %920, i1 false)
  %922 = zext i8 %921 to i32
  %923 = select i1 %919, i32 %922, i32 0
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %924 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %925 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state71 = load <8 x i64>, ptr %.slot, align 64
  %926 = mul <8 x i64> %.state71, splat (i64 32)
  %927 = add <8 x i64> %925, %926
  %928 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %924, 0
  %929 = insertvalue { <8 x ptr>, <8 x i64> } %928, <8 x i64> %927, 1
  %.state72 = load <8 x float>, ptr %.slot2, align 32
  %930 = extractvalue { <8 x ptr>, <8 x i64> } %929, 0
  %931 = extractvalue { <8 x ptr>, <8 x i64> } %929, 1
  %932 = getelementptr i8, <8 x ptr> %930, <8 x i64> %931
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state72, <8 x ptr> %932, i32 1, <8 x i1> %convergence.cascade.result)
  %.state73 = load <8 x i64>, ptr %.slot, align 64
  %933 = add <8 x i64> %.state73, splat (i64 1)
  %934 = load <8 x i64>, ptr %.slot, align 64
  %935 = select <8 x i1> %convergence.cascade.result, <8 x i64> %933, <8 x i64> %934
  store <8 x i64> %935, ptr %.slot, align 64
  store <8 x i1> %convergence.cascade.result, ptr %current.mask, align 1
  %936 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %936, label %schedule.1, label %scheduler.loop

convergence.cascade74:                            ; preds = %convergence.cascade74, %schedule.5
  %convergence.cascade.flow78 = phi <8 x i1> [ %153, %schedule.5 ], [ %979, %convergence.cascade74 ]
  %convergence.cascade.depth79 = phi i32 [ 0, %schedule.5 ], [ %980, %convergence.cascade74 ]
  %937 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow78)
  %938 = load i32, ptr %current.token, align 4
  %939 = icmp ne i32 %938, 0
  %940 = and i1 %937, %939
  %941 = sub i32 %938, 1
  %942 = select i1 %940, i32 %941, i32 0
  %943 = load i8, ptr %frame.active, align 1
  %944 = trunc i32 %942 to i8
  %945 = shl i8 1, %944
  %946 = and i8 %943, %945
  %947 = icmp ne i8 %946, 0
  %948 = load <8 x i32>, ptr %frame.static.id, align 32
  %949 = extractelement <8 x i32> %948, i32 %942
  %convergence.target.pointer80 = getelementptr inbounds [9 x i32], ptr @convergence.targets, i32 0, i32 %949
  %convergence.dynamic.target81 = load i32, ptr %convergence.target.pointer80, align 4
  %950 = icmp eq i32 %convergence.dynamic.target81, 5
  %951 = and i1 %947, %950
  %952 = and i1 %940, %951
  %953 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %942
  %954 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %942
  %955 = load <8 x i1>, ptr %953, align 1
  %956 = load <8 x i1>, ptr %954, align 1
  %957 = or <8 x i1> %956, %convergence.cascade.flow78
  %958 = load <8 x i1>, ptr %live.mask, align 1
  %959 = and <8 x i1> %955, %958
  %960 = icmp eq <8 x i1> %957, %959
  %961 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %960)
  %962 = and i1 %952, %961
  %963 = select i1 %962, <8 x i1> zeroinitializer, <8 x i1> %957
  %964 = select i1 %952, <8 x i1> %963, <8 x i1> %956
  store <8 x i1> %964, ptr %954, align 1
  %965 = select i1 %962, <8 x i1> zeroinitializer, <8 x i1> %955
  store <8 x i1> %965, ptr %953, align 1
  %966 = trunc i32 %942 to i8
  %967 = shl i8 1, %966
  %968 = xor i8 %967, -1
  %969 = and i8 %943, %968
  %970 = select i1 %962, i8 %969, i8 %943
  store i8 %970, ptr %frame.active, align 1
  %.splatinsert82 = insertelement <8 x i1> poison, i1 %952, i64 0
  %.splat83 = shufflevector <8 x i1> %.splatinsert82, <8 x i1> poison, <8 x i32> zeroinitializer
  %971 = and <8 x i1> %convergence.cascade.flow78, %.splat83
  %972 = load <8 x i1>, ptr %runnable.mask, align 1
  %973 = xor <8 x i1> %971, splat (i1 true)
  %974 = and <8 x i1> %972, %973
  store <8 x i1> %974, ptr %runnable.mask, align 1
  %.splatinsert84 = insertelement <8 x i1> poison, i1 %962, i64 0
  %.splat85 = shufflevector <8 x i1> %.splatinsert84, <8 x i1> poison, <8 x i32> zeroinitializer
  %975 = select <8 x i1> %.splat85, <8 x i1> %957, <8 x i1> zeroinitializer
  %976 = load <8 x i32>, ptr %frame.parent.token, align 32
  %977 = extractelement <8 x i32> %976, i32 %942
  %978 = select i1 %962, i32 %977, i32 %938
  store i32 %978, ptr %current.token, align 4
  %.splatinsert86 = insertelement <8 x i1> poison, i1 %952, i64 0
  %.splat87 = shufflevector <8 x i1> %.splatinsert86, <8 x i1> poison, <8 x i32> zeroinitializer
  %979 = select <8 x i1> %.splat87, <8 x i1> %975, <8 x i1> %convergence.cascade.flow78
  %980 = add i32 %convergence.cascade.depth79, 1
  %981 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %979)
  %982 = icmp ult i32 %980, 8
  %983 = and i1 %981, %982
  %984 = and i1 %952, %983
  %convergence.parent.token88 = load i32, ptr %current.token, align 4
  %convergence.parent.present89 = icmp ne i32 %convergence.parent.token88, 0
  %985 = and i1 %984, %convergence.parent.present89
  br i1 %985, label %convergence.cascade74, label %convergence.cascade.exit75

convergence.cascade.exit75:                       ; preds = %convergence.cascade74, %schedule.5
  %convergence.cascade.result90 = phi <8 x i1> [ %153, %schedule.5 ], [ %979, %convergence.cascade74 ]
  %986 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result90)
  br i1 %986, label %convergence.target.5.ready, label %scheduler.loop

convergence.target.5.ready:                       ; preds = %convergence.cascade.exit75
  %987 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result90)
  %988 = bitcast <8 x i1> %convergence.cascade.result90 to i8
  %989 = call i8 @llvm.cttz.i8(i8 %988, i1 false)
  %990 = zext i8 %989 to i32
  %991 = select i1 %987, i32 %990, i32 0
  store float 0.000000e+00, ptr %.spill3, align 4
  store i64 0, ptr %.spill4, align 4
  store i64 0, ptr %.spill5, align 4
  store i64 0, ptr %.spill6, align 4
  %tile_snapshot.spill.load91 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %992 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load91, 0
  %993 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load91, 1
  %994 = add <8 x i64> %993, zeroinitializer
  %995 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %992, 0
  %996 = insertvalue { <8 x ptr>, <8 x i64> } %995, <8 x i64> %994, 1
  %997 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %998 = extractvalue { <8 x ptr>, <8 x i64> } %996, 1
  %999 = extractelement <8 x ptr> %997, i32 0
  %1000 = extractelement <8 x i64> %998, i32 %991
  %1001 = zext i32 %991 to i64
  %1002 = mul i64 %1001, 4
  %1003 = sub i64 %1000, %1002
  %1004 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result90)
  %1005 = select i1 %1004, i64 %1003, i64 0
  %private.contiguous.address = getelementptr i8, ptr %999, i64 %1005
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address, align 4
  %1006 = select <8 x i1> %convergence.cascade.result90, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %1007 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %1006)
  store i64 1, ptr %.spill7, align 4
  %tile_snapshot.spill.load92 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1008 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load92, 0
  %1009 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load92, 1
  %1010 = add <8 x i64> %1009, splat (i64 32)
  %1011 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1008, 0
  %1012 = insertvalue { <8 x ptr>, <8 x i64> } %1011, <8 x i64> %1010, 1
  %1013 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1014 = extractvalue { <8 x ptr>, <8 x i64> } %1012, 1
  %1015 = extractelement <8 x ptr> %1013, i32 0
  %1016 = extractelement <8 x i64> %1014, i32 %991
  %1017 = zext i32 %991 to i64
  %1018 = mul i64 %1017, 4
  %1019 = sub i64 %1016, %1018
  %1020 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result90)
  %1021 = select i1 %1020, i64 %1019, i64 0
  %private.contiguous.address93 = getelementptr i8, ptr %1015, i64 %1021
  %private.contiguous.load94 = load <8 x float>, ptr %private.contiguous.address93, align 4
  %1022 = select <8 x i1> %convergence.cascade.result90, <8 x float> %private.contiguous.load94, <8 x float> zeroinitializer
  %1023 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %1022)
  store i64 2, ptr %.spill8, align 4
  %tile_snapshot.spill.load95 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1024 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load95, 0
  %1025 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load95, 1
  %1026 = add <8 x i64> %1025, splat (i64 64)
  %1027 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1024, 0
  %1028 = insertvalue { <8 x ptr>, <8 x i64> } %1027, <8 x i64> %1026, 1
  %1029 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1030 = extractvalue { <8 x ptr>, <8 x i64> } %1028, 1
  %1031 = extractelement <8 x ptr> %1029, i32 0
  %1032 = extractelement <8 x i64> %1030, i32 %991
  %1033 = zext i32 %991 to i64
  %1034 = mul i64 %1033, 4
  %1035 = sub i64 %1032, %1034
  %1036 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result90)
  %1037 = select i1 %1036, i64 %1035, i64 0
  %private.contiguous.address96 = getelementptr i8, ptr %1031, i64 %1037
  %private.contiguous.load97 = load <8 x float>, ptr %private.contiguous.address96, align 4
  %1038 = select <8 x i1> %convergence.cascade.result90, <8 x float> %private.contiguous.load97, <8 x float> zeroinitializer
  %1039 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %1038)
  store i64 3, ptr %.spill9, align 4
  %tile_snapshot.spill.load98 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1040 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load98, 0
  %1041 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load98, 1
  %1042 = add <8 x i64> %1041, splat (i64 96)
  %1043 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1040, 0
  %1044 = insertvalue { <8 x ptr>, <8 x i64> } %1043, <8 x i64> %1042, 1
  %1045 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1046 = extractvalue { <8 x ptr>, <8 x i64> } %1044, 1
  %1047 = extractelement <8 x ptr> %1045, i32 0
  %1048 = extractelement <8 x i64> %1046, i32 %991
  %1049 = zext i32 %991 to i64
  %1050 = mul i64 %1049, 4
  %1051 = sub i64 %1048, %1050
  %1052 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result90)
  %1053 = select i1 %1052, i64 %1051, i64 0
  %private.contiguous.address99 = getelementptr i8, ptr %1047, i64 %1053
  %private.contiguous.load100 = load <8 x float>, ptr %private.contiguous.address99, align 4
  %1054 = select <8 x i1> %convergence.cascade.result90, <8 x float> %private.contiguous.load100, <8 x float> zeroinitializer
  %1055 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %1054)
  %1056 = load <8 x i64>, ptr %.slot10, align 64
  %1057 = select <8 x i1> %convergence.cascade.result90, <8 x i64> splat (i64 4), <8 x i64> %1056
  store <8 x i64> %1057, ptr %.slot10, align 64
  %1058 = load <8 x float>, ptr %.slot11, align 32
  %1059 = select <8 x i1> %convergence.cascade.result90, <8 x float> %1007, <8 x float> %1058
  store <8 x float> %1059, ptr %.slot11, align 32
  %1060 = load <8 x float>, ptr %.slot12, align 32
  %1061 = select <8 x i1> %convergence.cascade.result90, <8 x float> %1023, <8 x float> %1060
  store <8 x float> %1061, ptr %.slot12, align 32
  %1062 = load <8 x float>, ptr %.slot13, align 32
  %1063 = select <8 x i1> %convergence.cascade.result90, <8 x float> %1039, <8 x float> %1062
  store <8 x float> %1063, ptr %.slot13, align 32
  %1064 = load <8 x float>, ptr %.slot14, align 32
  %1065 = select <8 x i1> %convergence.cascade.result90, <8 x float> %1055, <8 x float> %1064
  store <8 x float> %1065, ptr %.slot14, align 32
  store <8 x i1> %convergence.cascade.result90, ptr %current.mask, align 1
  %1066 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result90)
  br i1 %1066, label %schedule.6, label %scheduler.loop

varying.divergent102:                             ; preds = %schedule.6
  %1067 = load i32, ptr %current.token, align 4
  %1068 = icmp ne i32 %1067, 0
  %1069 = sub i32 %1067, 1
  %1070 = select i1 %1068, i32 %1069, i32 0
  %1071 = load i8, ptr %frame.active, align 1
  %1072 = trunc i32 %1070 to i8
  %1073 = shl i8 1, %1072
  %1074 = and i8 %1071, %1073
  %1075 = icmp ne i8 %1074, 0
  %1076 = load <8 x i32>, ptr %frame.static.id, align 32
  %1077 = extractelement <8 x i32> %1076, i32 %1070
  %1078 = icmp eq i32 %1077, 2
  %1079 = and i1 %1075, %1078
  %1080 = and i1 %1068, %1079
  %1081 = xor i1 %1080, true
  %1082 = and i1 true, %1081
  %1083 = xor i8 %1071, -1
  %1084 = icmp ne i8 %1083, 0
  %1085 = xor i1 %1084, true
  %1086 = and i1 %1082, %1085
  br i1 %1086, label %convergence.overflow.trap104, label %convergence.overflow.resume105

varying.coherent103:                              ; preds = %schedule.6
  br i1 %164, label %varying.coherent.true108, label %varying.coherent.false109

convergence.overflow.trap104:                     ; preds = %varying.divergent102
  call void @llvm.trap()
  unreachable

convergence.overflow.resume105:                   ; preds = %varying.divergent102
  %1087 = call i8 @llvm.cttz.i8(i8 %1083, i1 false)
  %1088 = zext i8 %1087 to i32
  %1089 = select i1 %1084, i32 %1088, i32 0
  %1090 = trunc i32 %1089 to i8
  %1091 = shl i8 1, %1090
  %1092 = or i8 %1071, %1091
  %1093 = select i1 %1082, i8 %1092, i8 %1071
  store i8 %1093, ptr %frame.active, align 1
  %1094 = load <8 x i32>, ptr %frame.static.id, align 32
  %1095 = extractelement <8 x i32> %1094, i32 %1089
  %1096 = select i1 %1082, i32 2, i32 %1095
  %1097 = load <8 x i32>, ptr %frame.static.id, align 32
  %1098 = insertelement <8 x i32> %1097, i32 %1096, i32 %1089
  store <8 x i32> %1098, ptr %frame.static.id, align 32
  %1099 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1100 = extractelement <8 x i32> %1099, i32 %1089
  %1101 = select i1 %1082, i32 %1067, i32 %1100
  %1102 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1103 = insertelement <8 x i32> %1102, i32 %1101, i32 %1089
  store <8 x i32> %1103, ptr %frame.parent.token, align 32
  %1104 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1089
  %1105 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1089
  %1106 = load <8 x i1>, ptr %1104, align 1
  %1107 = load <8 x i1>, ptr %1105, align 1
  %1108 = select i1 %1082, <8 x i1> %154, <8 x i1> %1106
  store <8 x i1> %1108, ptr %1104, align 1
  %1109 = select i1 %1082, <8 x i1> zeroinitializer, <8 x i1> %1107
  store <8 x i1> %1109, ptr %1105, align 1
  %1110 = add i32 %1089, 1
  %1111 = select i1 %1080, i32 %1067, i32 %1110
  %1112 = select i1 true, i32 %1111, i32 %1067
  store i32 %1112, ptr %current.token, align 4
  %1113 = load i32, ptr %current.token, align 4
  %1114 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %161)
  %1115 = load i32, ptr %ready.count, align 4
  %1116 = icmp uge i32 %1115, 8
  %1117 = and i1 %1114, %1116
  br i1 %1117, label %ready.overflow.trap106, label %ready.overflow.resume107

ready.overflow.trap106:                           ; preds = %convergence.overflow.resume105
  call void @llvm.trap()
  unreachable

ready.overflow.resume107:                         ; preds = %convergence.overflow.resume105
  %1118 = select i1 %1114, i32 %1115, i32 0
  %1119 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1118
  %1120 = load <8 x i1>, ptr %1119, align 1
  %1121 = select i1 %1114, <8 x i1> %161, <8 x i1> %1120
  store <8 x i1> %1121, ptr %1119, align 1
  %1122 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1118
  %1123 = load i32, ptr %1122, align 4
  %1124 = select i1 %1114, i32 7, i32 %1123
  store i32 %1124, ptr %1122, align 4
  %1125 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1118
  %1126 = load i32, ptr %1125, align 4
  %1127 = select i1 %1114, i32 %1113, i32 %1126
  store i32 %1127, ptr %1125, align 4
  %1128 = add i32 %1115, 1
  %1129 = select i1 %1114, i32 %1128, i32 %1115
  store i32 %1129, ptr %ready.count, align 4
  %1130 = load <8 x i1>, ptr %runnable.mask, align 1
  %1131 = or <8 x i1> %1130, %161
  store <8 x i1> %1131, ptr %runnable.mask, align 1
  store <8 x i1> %163, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true108:                         ; preds = %varying.coherent103
  store <8 x i1> %154, ptr %current.mask, align 1
  %1132 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %154)
  br i1 %1132, label %schedule.7, label %scheduler.loop

varying.coherent.false109:                        ; preds = %varying.coherent103
  store <8 x i1> %154, ptr %current.mask, align 1
  %1133 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %154)
  br i1 %1133, label %schedule.8, label %scheduler.loop

convergence.cascade147:                           ; preds = %convergence.cascade147, %schedule.8
  %convergence.cascade.flow151 = phi <8 x i1> [ %289, %schedule.8 ], [ %1176, %convergence.cascade147 ]
  %convergence.cascade.depth152 = phi i32 [ 0, %schedule.8 ], [ %1177, %convergence.cascade147 ]
  %1134 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow151)
  %1135 = load i32, ptr %current.token, align 4
  %1136 = icmp ne i32 %1135, 0
  %1137 = and i1 %1134, %1136
  %1138 = sub i32 %1135, 1
  %1139 = select i1 %1137, i32 %1138, i32 0
  %1140 = load i8, ptr %frame.active, align 1
  %1141 = trunc i32 %1139 to i8
  %1142 = shl i8 1, %1141
  %1143 = and i8 %1140, %1142
  %1144 = icmp ne i8 %1143, 0
  %1145 = load <8 x i32>, ptr %frame.static.id, align 32
  %1146 = extractelement <8 x i32> %1145, i32 %1139
  %convergence.target.pointer153 = getelementptr inbounds [9 x i32], ptr @convergence.targets, i32 0, i32 %1146
  %convergence.dynamic.target154 = load i32, ptr %convergence.target.pointer153, align 4
  %1147 = icmp eq i32 %convergence.dynamic.target154, 8
  %1148 = and i1 %1144, %1147
  %1149 = and i1 %1137, %1148
  %1150 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1139
  %1151 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1139
  %1152 = load <8 x i1>, ptr %1150, align 1
  %1153 = load <8 x i1>, ptr %1151, align 1
  %1154 = or <8 x i1> %1153, %convergence.cascade.flow151
  %1155 = load <8 x i1>, ptr %live.mask, align 1
  %1156 = and <8 x i1> %1152, %1155
  %1157 = icmp eq <8 x i1> %1154, %1156
  %1158 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1157)
  %1159 = and i1 %1149, %1158
  %1160 = select i1 %1159, <8 x i1> zeroinitializer, <8 x i1> %1154
  %1161 = select i1 %1149, <8 x i1> %1160, <8 x i1> %1153
  store <8 x i1> %1161, ptr %1151, align 1
  %1162 = select i1 %1159, <8 x i1> zeroinitializer, <8 x i1> %1152
  store <8 x i1> %1162, ptr %1150, align 1
  %1163 = trunc i32 %1139 to i8
  %1164 = shl i8 1, %1163
  %1165 = xor i8 %1164, -1
  %1166 = and i8 %1140, %1165
  %1167 = select i1 %1159, i8 %1166, i8 %1140
  store i8 %1167, ptr %frame.active, align 1
  %.splatinsert155 = insertelement <8 x i1> poison, i1 %1149, i64 0
  %.splat156 = shufflevector <8 x i1> %.splatinsert155, <8 x i1> poison, <8 x i32> zeroinitializer
  %1168 = and <8 x i1> %convergence.cascade.flow151, %.splat156
  %1169 = load <8 x i1>, ptr %runnable.mask, align 1
  %1170 = xor <8 x i1> %1168, splat (i1 true)
  %1171 = and <8 x i1> %1169, %1170
  store <8 x i1> %1171, ptr %runnable.mask, align 1
  %.splatinsert157 = insertelement <8 x i1> poison, i1 %1159, i64 0
  %.splat158 = shufflevector <8 x i1> %.splatinsert157, <8 x i1> poison, <8 x i32> zeroinitializer
  %1172 = select <8 x i1> %.splat158, <8 x i1> %1154, <8 x i1> zeroinitializer
  %1173 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1174 = extractelement <8 x i32> %1173, i32 %1139
  %1175 = select i1 %1159, i32 %1174, i32 %1135
  store i32 %1175, ptr %current.token, align 4
  %.splatinsert159 = insertelement <8 x i1> poison, i1 %1149, i64 0
  %.splat160 = shufflevector <8 x i1> %.splatinsert159, <8 x i1> poison, <8 x i32> zeroinitializer
  %1176 = select <8 x i1> %.splat160, <8 x i1> %1172, <8 x i1> %convergence.cascade.flow151
  %1177 = add i32 %convergence.cascade.depth152, 1
  %1178 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1176)
  %1179 = icmp ult i32 %1177, 8
  %1180 = and i1 %1178, %1179
  %1181 = and i1 %1149, %1180
  %convergence.parent.token161 = load i32, ptr %current.token, align 4
  %convergence.parent.present162 = icmp ne i32 %convergence.parent.token161, 0
  %1182 = and i1 %1181, %convergence.parent.present162
  br i1 %1182, label %convergence.cascade147, label %convergence.cascade.exit148

convergence.cascade.exit148:                      ; preds = %convergence.cascade147, %schedule.8
  %convergence.cascade.result163 = phi <8 x i1> [ %289, %schedule.8 ], [ %1176, %convergence.cascade147 ]
  %1183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result163)
  br i1 %1183, label %convergence.target.8.ready, label %scheduler.loop

convergence.target.8.ready:                       ; preds = %convergence.cascade.exit148
  %1184 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result163)
  %1185 = bitcast <8 x i1> %convergence.cascade.result163 to i8
  %1186 = call i8 @llvm.cttz.i8(i8 %1185, i1 false)
  %1187 = zext i8 %1186 to i32
  %1188 = select i1 %1184, i32 %1187, i32 0
  store i64 64, ptr %.spill15, align 4
  %.spill.load164 = load i64, ptr %.spill6, align 4
  %1189 = add i64 %.spill.load164, 64
  %1190 = srem i64 %1189, 65
  %1191 = sdiv i64 %1189, 65
  %.spill.load165 = load i64, ptr %.spill5, align 4
  %1192 = add i64 %.spill.load165, %1191
  %1193 = mul i64 %1192, 65
  %1194 = add i64 %1193, %1190
  %tile_snapshot.spill.load166 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1195 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load166, 0
  %1196 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load166, 1
  %.splatinsert167 = insertelement <8 x i64> poison, i64 %1194, i64 0
  %.splat168 = shufflevector <8 x i64> %.splatinsert167, <8 x i64> poison, <8 x i32> zeroinitializer
  %1197 = mul <8 x i64> %.splat168, splat (i64 32)
  %1198 = add <8 x i64> %1196, %1197
  %1199 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1195, 0
  %1200 = insertvalue { <8 x ptr>, <8 x i64> } %1199, <8 x i64> %1198, 1
  %1201 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1202 = extractvalue { <8 x ptr>, <8 x i64> } %1200, 1
  %1203 = extractelement <8 x ptr> %1201, i32 0
  %1204 = extractelement <8 x i64> %1202, i32 %1188
  %1205 = zext i32 %1188 to i64
  %1206 = mul i64 %1205, 4
  %1207 = sub i64 %1204, %1206
  %1208 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result163)
  %1209 = select i1 %1208, i64 %1207, i64 0
  %private.contiguous.address169 = getelementptr i8, ptr %1203, i64 %1209
  %private.contiguous.load170 = load <8 x float>, ptr %private.contiguous.address169, align 4
  %1210 = select <8 x i1> %convergence.cascade.result163, <8 x float> %private.contiguous.load170, <8 x float> zeroinitializer
  %1211 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %1210)
  %.state171 = load <8 x float>, ptr %.slot11, align 32
  %1212 = fadd <8 x float> %.state171, %1211
  %.spill.load172 = load float, ptr %.spill3, align 4
  %.splatinsert173 = insertelement <8 x float> poison, float %.spill.load172, i64 0
  %.splat174 = shufflevector <8 x float> %.splatinsert173, <8 x float> poison, <8 x i32> zeroinitializer
  %1213 = fadd <8 x float> %.splat174, %1212
  %.state175 = load <8 x float>, ptr %.slot12, align 32
  %1214 = fadd <8 x float> %1213, %.state175
  %.state176 = load <8 x float>, ptr %.slot13, align 32
  %1215 = fadd <8 x float> %1214, %.state176
  %.state177 = load <8 x float>, ptr %.slot14, align 32
  %1216 = fadd <8 x float> %1215, %.state177
  %1217 = load <8 x float>, ptr %.spill16, align 32
  %1218 = select <8 x i1> %convergence.cascade.result163, <8 x float> %1216, <8 x float> %1217
  store <8 x float> %1218, ptr %.spill16, align 32
  %.spill.load178 = load i64, ptr %.spill5, align 4
  %1219 = add i64 %.spill.load178, 1
  %1220 = mul i64 %1219, 65
  store i64 %1220, ptr %.spill17, align 4
  %.spill.load179 = load i64, ptr %.spill4, align 4
  %1221 = add i64 %1220, %.spill.load179
  %1222 = srem i64 %1221, 65
  %1223 = sdiv i64 %1221, 65
  %.spill.load180 = load i64, ptr %.spill5, align 4
  %1224 = add i64 %.spill.load180, %1223
  %1225 = mul i64 %1224, 65
  %1226 = add i64 %1225, %1222
  %tile_snapshot.spill.load181 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1227 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load181, 0
  %1228 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load181, 1
  %.splatinsert182 = insertelement <8 x i64> poison, i64 %1226, i64 0
  %.splat183 = shufflevector <8 x i64> %.splatinsert182, <8 x i64> poison, <8 x i32> zeroinitializer
  %1229 = mul <8 x i64> %.splat183, splat (i64 32)
  %1230 = add <8 x i64> %1228, %1229
  %1231 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1227, 0
  %1232 = insertvalue { <8 x ptr>, <8 x i64> } %1231, <8 x i64> %1230, 1
  %1233 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1234 = extractvalue { <8 x ptr>, <8 x i64> } %1232, 1
  %1235 = extractelement <8 x ptr> %1233, i32 0
  %1236 = extractelement <8 x i64> %1234, i32 %1188
  %1237 = zext i32 %1188 to i64
  %1238 = mul i64 %1237, 4
  %1239 = sub i64 %1236, %1238
  %1240 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result163)
  %1241 = select i1 %1240, i64 %1239, i64 0
  %private.contiguous.address184 = getelementptr i8, ptr %1235, i64 %1241
  %private.contiguous.load185 = load <8 x float>, ptr %private.contiguous.address184, align 4
  %1242 = select <8 x i1> %convergence.cascade.result163, <8 x float> %private.contiguous.load185, <8 x float> zeroinitializer
  %1243 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %1242)
  %.spill.load186 = load i64, ptr %.spill7, align 4
  %1244 = add i64 %1220, %.spill.load186
  %1245 = srem i64 %1244, 65
  %1246 = sdiv i64 %1244, 65
  %.spill.load187 = load i64, ptr %.spill5, align 4
  %1247 = add i64 %.spill.load187, %1246
  %1248 = mul i64 %1247, 65
  %1249 = add i64 %1248, %1245
  %tile_snapshot.spill.load188 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1250 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 0
  %1251 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 1
  %.splatinsert189 = insertelement <8 x i64> poison, i64 %1249, i64 0
  %.splat190 = shufflevector <8 x i64> %.splatinsert189, <8 x i64> poison, <8 x i32> zeroinitializer
  %1252 = mul <8 x i64> %.splat190, splat (i64 32)
  %1253 = add <8 x i64> %1251, %1252
  %1254 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1250, 0
  %1255 = insertvalue { <8 x ptr>, <8 x i64> } %1254, <8 x i64> %1253, 1
  %1256 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1257 = extractvalue { <8 x ptr>, <8 x i64> } %1255, 1
  %1258 = extractelement <8 x ptr> %1256, i32 0
  %1259 = extractelement <8 x i64> %1257, i32 %1188
  %1260 = zext i32 %1188 to i64
  %1261 = mul i64 %1260, 4
  %1262 = sub i64 %1259, %1261
  %1263 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result163)
  %1264 = select i1 %1263, i64 %1262, i64 0
  %private.contiguous.address191 = getelementptr i8, ptr %1258, i64 %1264
  %private.contiguous.load192 = load <8 x float>, ptr %private.contiguous.address191, align 4
  %1265 = select <8 x i1> %convergence.cascade.result163, <8 x float> %private.contiguous.load192, <8 x float> zeroinitializer
  %1266 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %1265)
  %.spill.load193 = load i64, ptr %.spill8, align 4
  %1267 = add i64 %1220, %.spill.load193
  %1268 = srem i64 %1267, 65
  %1269 = sdiv i64 %1267, 65
  %.spill.load194 = load i64, ptr %.spill5, align 4
  %1270 = add i64 %.spill.load194, %1269
  %1271 = mul i64 %1270, 65
  %1272 = add i64 %1271, %1268
  %tile_snapshot.spill.load195 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1273 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load195, 0
  %1274 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load195, 1
  %.splatinsert196 = insertelement <8 x i64> poison, i64 %1272, i64 0
  %.splat197 = shufflevector <8 x i64> %.splatinsert196, <8 x i64> poison, <8 x i32> zeroinitializer
  %1275 = mul <8 x i64> %.splat197, splat (i64 32)
  %1276 = add <8 x i64> %1274, %1275
  %1277 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1273, 0
  %1278 = insertvalue { <8 x ptr>, <8 x i64> } %1277, <8 x i64> %1276, 1
  %1279 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1280 = extractvalue { <8 x ptr>, <8 x i64> } %1278, 1
  %1281 = extractelement <8 x ptr> %1279, i32 0
  %1282 = extractelement <8 x i64> %1280, i32 %1188
  %1283 = zext i32 %1188 to i64
  %1284 = mul i64 %1283, 4
  %1285 = sub i64 %1282, %1284
  %1286 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result163)
  %1287 = select i1 %1286, i64 %1285, i64 0
  %private.contiguous.address198 = getelementptr i8, ptr %1281, i64 %1287
  %private.contiguous.load199 = load <8 x float>, ptr %private.contiguous.address198, align 4
  %1288 = select <8 x i1> %convergence.cascade.result163, <8 x float> %private.contiguous.load199, <8 x float> zeroinitializer
  %1289 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %1288)
  %.spill.load200 = load i64, ptr %.spill9, align 4
  %1290 = add i64 %1220, %.spill.load200
  %1291 = srem i64 %1290, 65
  %1292 = sdiv i64 %1290, 65
  %.spill.load201 = load i64, ptr %.spill5, align 4
  %1293 = add i64 %.spill.load201, %1292
  %1294 = mul i64 %1293, 65
  %1295 = add i64 %1294, %1291
  %tile_snapshot.spill.load202 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1296 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load202, 0
  %1297 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load202, 1
  %.splatinsert203 = insertelement <8 x i64> poison, i64 %1295, i64 0
  %.splat204 = shufflevector <8 x i64> %.splatinsert203, <8 x i64> poison, <8 x i32> zeroinitializer
  %1298 = mul <8 x i64> %.splat204, splat (i64 32)
  %1299 = add <8 x i64> %1297, %1298
  %1300 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1296, 0
  %1301 = insertvalue { <8 x ptr>, <8 x i64> } %1300, <8 x i64> %1299, 1
  %1302 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1303 = extractvalue { <8 x ptr>, <8 x i64> } %1301, 1
  %1304 = extractelement <8 x ptr> %1302, i32 0
  %1305 = extractelement <8 x i64> %1303, i32 %1188
  %1306 = zext i32 %1188 to i64
  %1307 = mul i64 %1306, 4
  %1308 = sub i64 %1305, %1307
  %1309 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result163)
  %1310 = select i1 %1309, i64 %1308, i64 0
  %private.contiguous.address205 = getelementptr i8, ptr %1304, i64 %1310
  %private.contiguous.load206 = load <8 x float>, ptr %private.contiguous.address205, align 4
  %1311 = select <8 x i1> %convergence.cascade.result163, <8 x float> %private.contiguous.load206, <8 x float> zeroinitializer
  %1312 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %1311)
  %1313 = load <8 x i64>, ptr %.slot18, align 64
  %1314 = select <8 x i1> %convergence.cascade.result163, <8 x i64> splat (i64 4), <8 x i64> %1313
  store <8 x i64> %1314, ptr %.slot18, align 64
  %1315 = load <8 x float>, ptr %.slot19, align 32
  %1316 = select <8 x i1> %convergence.cascade.result163, <8 x float> %1243, <8 x float> %1315
  store <8 x float> %1316, ptr %.slot19, align 32
  %1317 = load <8 x float>, ptr %.slot20, align 32
  %1318 = select <8 x i1> %convergence.cascade.result163, <8 x float> %1266, <8 x float> %1317
  store <8 x float> %1318, ptr %.slot20, align 32
  %1319 = load <8 x float>, ptr %.slot21, align 32
  %1320 = select <8 x i1> %convergence.cascade.result163, <8 x float> %1289, <8 x float> %1319
  store <8 x float> %1320, ptr %.slot21, align 32
  %1321 = load <8 x float>, ptr %.slot22, align 32
  %1322 = select <8 x i1> %convergence.cascade.result163, <8 x float> %1312, <8 x float> %1321
  store <8 x float> %1322, ptr %.slot22, align 32
  store <8 x i1> %convergence.cascade.result163, ptr %current.mask, align 1
  %1323 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result163)
  br i1 %1323, label %schedule.9, label %scheduler.loop

varying.divergent208:                             ; preds = %schedule.9
  %1324 = load i32, ptr %current.token, align 4
  %1325 = icmp ne i32 %1324, 0
  %1326 = sub i32 %1324, 1
  %1327 = select i1 %1325, i32 %1326, i32 0
  %1328 = load i8, ptr %frame.active, align 1
  %1329 = trunc i32 %1327 to i8
  %1330 = shl i8 1, %1329
  %1331 = and i8 %1328, %1330
  %1332 = icmp ne i8 %1331, 0
  %1333 = load <8 x i32>, ptr %frame.static.id, align 32
  %1334 = extractelement <8 x i32> %1333, i32 %1327
  %1335 = icmp eq i32 %1334, 3
  %1336 = and i1 %1332, %1335
  %1337 = and i1 %1325, %1336
  %1338 = xor i1 %1337, true
  %1339 = and i1 true, %1338
  %1340 = xor i8 %1328, -1
  %1341 = icmp ne i8 %1340, 0
  %1342 = xor i1 %1341, true
  %1343 = and i1 %1339, %1342
  br i1 %1343, label %convergence.overflow.trap210, label %convergence.overflow.resume211

varying.coherent209:                              ; preds = %schedule.9
  br i1 %300, label %varying.coherent.true214, label %varying.coherent.false215

convergence.overflow.trap210:                     ; preds = %varying.divergent208
  call void @llvm.trap()
  unreachable

convergence.overflow.resume211:                   ; preds = %varying.divergent208
  %1344 = call i8 @llvm.cttz.i8(i8 %1340, i1 false)
  %1345 = zext i8 %1344 to i32
  %1346 = select i1 %1341, i32 %1345, i32 0
  %1347 = trunc i32 %1346 to i8
  %1348 = shl i8 1, %1347
  %1349 = or i8 %1328, %1348
  %1350 = select i1 %1339, i8 %1349, i8 %1328
  store i8 %1350, ptr %frame.active, align 1
  %1351 = load <8 x i32>, ptr %frame.static.id, align 32
  %1352 = extractelement <8 x i32> %1351, i32 %1346
  %1353 = select i1 %1339, i32 3, i32 %1352
  %1354 = load <8 x i32>, ptr %frame.static.id, align 32
  %1355 = insertelement <8 x i32> %1354, i32 %1353, i32 %1346
  store <8 x i32> %1355, ptr %frame.static.id, align 32
  %1356 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1357 = extractelement <8 x i32> %1356, i32 %1346
  %1358 = select i1 %1339, i32 %1324, i32 %1357
  %1359 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1360 = insertelement <8 x i32> %1359, i32 %1358, i32 %1346
  store <8 x i32> %1360, ptr %frame.parent.token, align 32
  %1361 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1346
  %1362 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1346
  %1363 = load <8 x i1>, ptr %1361, align 1
  %1364 = load <8 x i1>, ptr %1362, align 1
  %1365 = select i1 %1339, <8 x i1> %290, <8 x i1> %1363
  store <8 x i1> %1365, ptr %1361, align 1
  %1366 = select i1 %1339, <8 x i1> zeroinitializer, <8 x i1> %1364
  store <8 x i1> %1366, ptr %1362, align 1
  %1367 = add i32 %1346, 1
  %1368 = select i1 %1337, i32 %1324, i32 %1367
  %1369 = select i1 true, i32 %1368, i32 %1324
  store i32 %1369, ptr %current.token, align 4
  %1370 = load i32, ptr %current.token, align 4
  %1371 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %297)
  %1372 = load i32, ptr %ready.count, align 4
  %1373 = icmp uge i32 %1372, 8
  %1374 = and i1 %1371, %1373
  br i1 %1374, label %ready.overflow.trap212, label %ready.overflow.resume213

ready.overflow.trap212:                           ; preds = %convergence.overflow.resume211
  call void @llvm.trap()
  unreachable

ready.overflow.resume213:                         ; preds = %convergence.overflow.resume211
  %1375 = select i1 %1371, i32 %1372, i32 0
  %1376 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1375
  %1377 = load <8 x i1>, ptr %1376, align 1
  %1378 = select i1 %1371, <8 x i1> %297, <8 x i1> %1377
  store <8 x i1> %1378, ptr %1376, align 1
  %1379 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1375
  %1380 = load i32, ptr %1379, align 4
  %1381 = select i1 %1371, i32 10, i32 %1380
  store i32 %1381, ptr %1379, align 4
  %1382 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1375
  %1383 = load i32, ptr %1382, align 4
  %1384 = select i1 %1371, i32 %1370, i32 %1383
  store i32 %1384, ptr %1382, align 4
  %1385 = add i32 %1372, 1
  %1386 = select i1 %1371, i32 %1385, i32 %1372
  store i32 %1386, ptr %ready.count, align 4
  %1387 = load <8 x i1>, ptr %runnable.mask, align 1
  %1388 = or <8 x i1> %1387, %297
  store <8 x i1> %1388, ptr %runnable.mask, align 1
  store <8 x i1> %299, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true214:                         ; preds = %varying.coherent209
  store <8 x i1> %290, ptr %current.mask, align 1
  %1389 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %290)
  br i1 %1389, label %schedule.10, label %scheduler.loop

varying.coherent.false215:                        ; preds = %varying.coherent209
  store <8 x i1> %290, ptr %current.mask, align 1
  %1390 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %290)
  br i1 %1390, label %schedule.11, label %scheduler.loop

convergence.cascade253:                           ; preds = %convergence.cascade253, %schedule.11
  %convergence.cascade.flow257 = phi <8 x i1> [ %425, %schedule.11 ], [ %1433, %convergence.cascade253 ]
  %convergence.cascade.depth258 = phi i32 [ 0, %schedule.11 ], [ %1434, %convergence.cascade253 ]
  %1391 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow257)
  %1392 = load i32, ptr %current.token, align 4
  %1393 = icmp ne i32 %1392, 0
  %1394 = and i1 %1391, %1393
  %1395 = sub i32 %1392, 1
  %1396 = select i1 %1394, i32 %1395, i32 0
  %1397 = load i8, ptr %frame.active, align 1
  %1398 = trunc i32 %1396 to i8
  %1399 = shl i8 1, %1398
  %1400 = and i8 %1397, %1399
  %1401 = icmp ne i8 %1400, 0
  %1402 = load <8 x i32>, ptr %frame.static.id, align 32
  %1403 = extractelement <8 x i32> %1402, i32 %1396
  %convergence.target.pointer259 = getelementptr inbounds [9 x i32], ptr @convergence.targets, i32 0, i32 %1403
  %convergence.dynamic.target260 = load i32, ptr %convergence.target.pointer259, align 4
  %1404 = icmp eq i32 %convergence.dynamic.target260, 11
  %1405 = and i1 %1401, %1404
  %1406 = and i1 %1394, %1405
  %1407 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1396
  %1408 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1396
  %1409 = load <8 x i1>, ptr %1407, align 1
  %1410 = load <8 x i1>, ptr %1408, align 1
  %1411 = or <8 x i1> %1410, %convergence.cascade.flow257
  %1412 = load <8 x i1>, ptr %live.mask, align 1
  %1413 = and <8 x i1> %1409, %1412
  %1414 = icmp eq <8 x i1> %1411, %1413
  %1415 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1414)
  %1416 = and i1 %1406, %1415
  %1417 = select i1 %1416, <8 x i1> zeroinitializer, <8 x i1> %1411
  %1418 = select i1 %1406, <8 x i1> %1417, <8 x i1> %1410
  store <8 x i1> %1418, ptr %1408, align 1
  %1419 = select i1 %1416, <8 x i1> zeroinitializer, <8 x i1> %1409
  store <8 x i1> %1419, ptr %1407, align 1
  %1420 = trunc i32 %1396 to i8
  %1421 = shl i8 1, %1420
  %1422 = xor i8 %1421, -1
  %1423 = and i8 %1397, %1422
  %1424 = select i1 %1416, i8 %1423, i8 %1397
  store i8 %1424, ptr %frame.active, align 1
  %.splatinsert261 = insertelement <8 x i1> poison, i1 %1406, i64 0
  %.splat262 = shufflevector <8 x i1> %.splatinsert261, <8 x i1> poison, <8 x i32> zeroinitializer
  %1425 = and <8 x i1> %convergence.cascade.flow257, %.splat262
  %1426 = load <8 x i1>, ptr %runnable.mask, align 1
  %1427 = xor <8 x i1> %1425, splat (i1 true)
  %1428 = and <8 x i1> %1426, %1427
  store <8 x i1> %1428, ptr %runnable.mask, align 1
  %.splatinsert263 = insertelement <8 x i1> poison, i1 %1416, i64 0
  %.splat264 = shufflevector <8 x i1> %.splatinsert263, <8 x i1> poison, <8 x i32> zeroinitializer
  %1429 = select <8 x i1> %.splat264, <8 x i1> %1411, <8 x i1> zeroinitializer
  %1430 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1431 = extractelement <8 x i32> %1430, i32 %1396
  %1432 = select i1 %1416, i32 %1431, i32 %1392
  store i32 %1432, ptr %current.token, align 4
  %.splatinsert265 = insertelement <8 x i1> poison, i1 %1406, i64 0
  %.splat266 = shufflevector <8 x i1> %.splatinsert265, <8 x i1> poison, <8 x i32> zeroinitializer
  %1433 = select <8 x i1> %.splat266, <8 x i1> %1429, <8 x i1> %convergence.cascade.flow257
  %1434 = add i32 %convergence.cascade.depth258, 1
  %1435 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1433)
  %1436 = icmp ult i32 %1434, 8
  %1437 = and i1 %1435, %1436
  %1438 = and i1 %1406, %1437
  %convergence.parent.token267 = load i32, ptr %current.token, align 4
  %convergence.parent.present268 = icmp ne i32 %convergence.parent.token267, 0
  %1439 = and i1 %1438, %convergence.parent.present268
  br i1 %1439, label %convergence.cascade253, label %convergence.cascade.exit254

convergence.cascade.exit254:                      ; preds = %convergence.cascade253, %schedule.11
  %convergence.cascade.result269 = phi <8 x i1> [ %425, %schedule.11 ], [ %1433, %convergence.cascade253 ]
  %1440 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result269)
  br i1 %1440, label %convergence.target.11.ready, label %scheduler.loop

convergence.target.11.ready:                      ; preds = %convergence.cascade.exit254
  %1441 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result269)
  %1442 = bitcast <8 x i1> %convergence.cascade.result269 to i8
  %1443 = call i8 @llvm.cttz.i8(i8 %1442, i1 false)
  %1444 = zext i8 %1443 to i32
  %1445 = select i1 %1441, i32 %1444, i32 0
  %.spill.load270 = load i64, ptr %.spill17, align 4
  %.spill.load271 = load i64, ptr %.spill15, align 4
  %1446 = add i64 %.spill.load270, %.spill.load271
  %1447 = srem i64 %1446, 65
  %1448 = sdiv i64 %1446, 65
  %.spill.load272 = load i64, ptr %.spill5, align 4
  %1449 = add i64 %.spill.load272, %1448
  %1450 = mul i64 %1449, 65
  %1451 = add i64 %1450, %1447
  %tile_snapshot.spill.load273 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1452 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load273, 0
  %1453 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load273, 1
  %.splatinsert274 = insertelement <8 x i64> poison, i64 %1451, i64 0
  %.splat275 = shufflevector <8 x i64> %.splatinsert274, <8 x i64> poison, <8 x i32> zeroinitializer
  %1454 = mul <8 x i64> %.splat275, splat (i64 32)
  %1455 = add <8 x i64> %1453, %1454
  %1456 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1452, 0
  %1457 = insertvalue { <8 x ptr>, <8 x i64> } %1456, <8 x i64> %1455, 1
  %1458 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1459 = extractvalue { <8 x ptr>, <8 x i64> } %1457, 1
  %1460 = extractelement <8 x ptr> %1458, i32 0
  %1461 = extractelement <8 x i64> %1459, i32 %1445
  %1462 = zext i32 %1445 to i64
  %1463 = mul i64 %1462, 4
  %1464 = sub i64 %1461, %1463
  %1465 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result269)
  %1466 = select i1 %1465, i64 %1464, i64 0
  %private.contiguous.address276 = getelementptr i8, ptr %1460, i64 %1466
  %private.contiguous.load277 = load <8 x float>, ptr %private.contiguous.address276, align 4
  %1467 = select <8 x i1> %convergence.cascade.result269, <8 x float> %private.contiguous.load277, <8 x float> zeroinitializer
  %1468 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %1467)
  %.state278 = load <8 x float>, ptr %.slot19, align 32
  %1469 = fadd <8 x float> %.state278, %1468
  %.spill.load279 = load float, ptr %.spill3, align 4
  %.splatinsert280 = insertelement <8 x float> poison, float %.spill.load279, i64 0
  %.splat281 = shufflevector <8 x float> %.splatinsert280, <8 x float> poison, <8 x i32> zeroinitializer
  %1470 = fadd <8 x float> %.splat281, %1469
  %.state282 = load <8 x float>, ptr %.slot20, align 32
  %1471 = fadd <8 x float> %1470, %.state282
  %.state283 = load <8 x float>, ptr %.slot21, align 32
  %1472 = fadd <8 x float> %1471, %.state283
  %.state284 = load <8 x float>, ptr %.slot22, align 32
  %1473 = fadd <8 x float> %1472, %.state284
  %1474 = load <8 x float>, ptr %.spill23, align 32
  %1475 = select <8 x i1> %convergence.cascade.result269, <8 x float> %1473, <8 x float> %1474
  store <8 x float> %1475, ptr %.spill23, align 32
  %.spill.load285 = load i64, ptr %.spill5, align 4
  %1476 = add i64 %.spill.load285, 2
  %1477 = mul i64 %1476, 65
  store i64 %1477, ptr %.spill24, align 4
  %.spill.load286 = load i64, ptr %.spill4, align 4
  %1478 = add i64 %1477, %.spill.load286
  %1479 = srem i64 %1478, 65
  %1480 = sdiv i64 %1478, 65
  %.spill.load287 = load i64, ptr %.spill5, align 4
  %1481 = add i64 %.spill.load287, %1480
  %1482 = mul i64 %1481, 65
  %1483 = add i64 %1482, %1479
  %tile_snapshot.spill.load288 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1484 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load288, 0
  %1485 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load288, 1
  %.splatinsert289 = insertelement <8 x i64> poison, i64 %1483, i64 0
  %.splat290 = shufflevector <8 x i64> %.splatinsert289, <8 x i64> poison, <8 x i32> zeroinitializer
  %1486 = mul <8 x i64> %.splat290, splat (i64 32)
  %1487 = add <8 x i64> %1485, %1486
  %1488 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1484, 0
  %1489 = insertvalue { <8 x ptr>, <8 x i64> } %1488, <8 x i64> %1487, 1
  %1490 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1491 = extractvalue { <8 x ptr>, <8 x i64> } %1489, 1
  %1492 = extractelement <8 x ptr> %1490, i32 0
  %1493 = extractelement <8 x i64> %1491, i32 %1445
  %1494 = zext i32 %1445 to i64
  %1495 = mul i64 %1494, 4
  %1496 = sub i64 %1493, %1495
  %1497 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result269)
  %1498 = select i1 %1497, i64 %1496, i64 0
  %private.contiguous.address291 = getelementptr i8, ptr %1492, i64 %1498
  %private.contiguous.load292 = load <8 x float>, ptr %private.contiguous.address291, align 4
  %1499 = select <8 x i1> %convergence.cascade.result269, <8 x float> %private.contiguous.load292, <8 x float> zeroinitializer
  %1500 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %1499)
  %.spill.load293 = load i64, ptr %.spill7, align 4
  %1501 = add i64 %1477, %.spill.load293
  %1502 = srem i64 %1501, 65
  %1503 = sdiv i64 %1501, 65
  %.spill.load294 = load i64, ptr %.spill5, align 4
  %1504 = add i64 %.spill.load294, %1503
  %1505 = mul i64 %1504, 65
  %1506 = add i64 %1505, %1502
  %tile_snapshot.spill.load295 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1507 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load295, 0
  %1508 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load295, 1
  %.splatinsert296 = insertelement <8 x i64> poison, i64 %1506, i64 0
  %.splat297 = shufflevector <8 x i64> %.splatinsert296, <8 x i64> poison, <8 x i32> zeroinitializer
  %1509 = mul <8 x i64> %.splat297, splat (i64 32)
  %1510 = add <8 x i64> %1508, %1509
  %1511 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1507, 0
  %1512 = insertvalue { <8 x ptr>, <8 x i64> } %1511, <8 x i64> %1510, 1
  %1513 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1514 = extractvalue { <8 x ptr>, <8 x i64> } %1512, 1
  %1515 = extractelement <8 x ptr> %1513, i32 0
  %1516 = extractelement <8 x i64> %1514, i32 %1445
  %1517 = zext i32 %1445 to i64
  %1518 = mul i64 %1517, 4
  %1519 = sub i64 %1516, %1518
  %1520 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result269)
  %1521 = select i1 %1520, i64 %1519, i64 0
  %private.contiguous.address298 = getelementptr i8, ptr %1515, i64 %1521
  %private.contiguous.load299 = load <8 x float>, ptr %private.contiguous.address298, align 4
  %1522 = select <8 x i1> %convergence.cascade.result269, <8 x float> %private.contiguous.load299, <8 x float> zeroinitializer
  %1523 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %1522)
  %.spill.load300 = load i64, ptr %.spill8, align 4
  %1524 = add i64 %1477, %.spill.load300
  %1525 = srem i64 %1524, 65
  %1526 = sdiv i64 %1524, 65
  %.spill.load301 = load i64, ptr %.spill5, align 4
  %1527 = add i64 %.spill.load301, %1526
  %1528 = mul i64 %1527, 65
  %1529 = add i64 %1528, %1525
  %tile_snapshot.spill.load302 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1530 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load302, 0
  %1531 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load302, 1
  %.splatinsert303 = insertelement <8 x i64> poison, i64 %1529, i64 0
  %.splat304 = shufflevector <8 x i64> %.splatinsert303, <8 x i64> poison, <8 x i32> zeroinitializer
  %1532 = mul <8 x i64> %.splat304, splat (i64 32)
  %1533 = add <8 x i64> %1531, %1532
  %1534 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1530, 0
  %1535 = insertvalue { <8 x ptr>, <8 x i64> } %1534, <8 x i64> %1533, 1
  %1536 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1537 = extractvalue { <8 x ptr>, <8 x i64> } %1535, 1
  %1538 = extractelement <8 x ptr> %1536, i32 0
  %1539 = extractelement <8 x i64> %1537, i32 %1445
  %1540 = zext i32 %1445 to i64
  %1541 = mul i64 %1540, 4
  %1542 = sub i64 %1539, %1541
  %1543 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result269)
  %1544 = select i1 %1543, i64 %1542, i64 0
  %private.contiguous.address305 = getelementptr i8, ptr %1538, i64 %1544
  %private.contiguous.load306 = load <8 x float>, ptr %private.contiguous.address305, align 4
  %1545 = select <8 x i1> %convergence.cascade.result269, <8 x float> %private.contiguous.load306, <8 x float> zeroinitializer
  %1546 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %1545)
  %.spill.load307 = load i64, ptr %.spill9, align 4
  %1547 = add i64 %1477, %.spill.load307
  %1548 = srem i64 %1547, 65
  %1549 = sdiv i64 %1547, 65
  %.spill.load308 = load i64, ptr %.spill5, align 4
  %1550 = add i64 %.spill.load308, %1549
  %1551 = mul i64 %1550, 65
  %1552 = add i64 %1551, %1548
  %tile_snapshot.spill.load309 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1553 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load309, 0
  %1554 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load309, 1
  %.splatinsert310 = insertelement <8 x i64> poison, i64 %1552, i64 0
  %.splat311 = shufflevector <8 x i64> %.splatinsert310, <8 x i64> poison, <8 x i32> zeroinitializer
  %1555 = mul <8 x i64> %.splat311, splat (i64 32)
  %1556 = add <8 x i64> %1554, %1555
  %1557 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1553, 0
  %1558 = insertvalue { <8 x ptr>, <8 x i64> } %1557, <8 x i64> %1556, 1
  %1559 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1560 = extractvalue { <8 x ptr>, <8 x i64> } %1558, 1
  %1561 = extractelement <8 x ptr> %1559, i32 0
  %1562 = extractelement <8 x i64> %1560, i32 %1445
  %1563 = zext i32 %1445 to i64
  %1564 = mul i64 %1563, 4
  %1565 = sub i64 %1562, %1564
  %1566 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result269)
  %1567 = select i1 %1566, i64 %1565, i64 0
  %private.contiguous.address312 = getelementptr i8, ptr %1561, i64 %1567
  %private.contiguous.load313 = load <8 x float>, ptr %private.contiguous.address312, align 4
  %1568 = select <8 x i1> %convergence.cascade.result269, <8 x float> %private.contiguous.load313, <8 x float> zeroinitializer
  %1569 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %1568)
  %1570 = load <8 x i64>, ptr %.slot25, align 64
  %1571 = select <8 x i1> %convergence.cascade.result269, <8 x i64> splat (i64 4), <8 x i64> %1570
  store <8 x i64> %1571, ptr %.slot25, align 64
  %1572 = load <8 x float>, ptr %.slot26, align 32
  %1573 = select <8 x i1> %convergence.cascade.result269, <8 x float> %1500, <8 x float> %1572
  store <8 x float> %1573, ptr %.slot26, align 32
  %1574 = load <8 x float>, ptr %.slot27, align 32
  %1575 = select <8 x i1> %convergence.cascade.result269, <8 x float> %1523, <8 x float> %1574
  store <8 x float> %1575, ptr %.slot27, align 32
  %1576 = load <8 x float>, ptr %.slot28, align 32
  %1577 = select <8 x i1> %convergence.cascade.result269, <8 x float> %1546, <8 x float> %1576
  store <8 x float> %1577, ptr %.slot28, align 32
  %1578 = load <8 x float>, ptr %.slot29, align 32
  %1579 = select <8 x i1> %convergence.cascade.result269, <8 x float> %1569, <8 x float> %1578
  store <8 x float> %1579, ptr %.slot29, align 32
  store <8 x i1> %convergence.cascade.result269, ptr %current.mask, align 1
  %1580 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result269)
  br i1 %1580, label %schedule.12, label %scheduler.loop

varying.divergent315:                             ; preds = %schedule.12
  %1581 = load i32, ptr %current.token, align 4
  %1582 = icmp ne i32 %1581, 0
  %1583 = sub i32 %1581, 1
  %1584 = select i1 %1582, i32 %1583, i32 0
  %1585 = load i8, ptr %frame.active, align 1
  %1586 = trunc i32 %1584 to i8
  %1587 = shl i8 1, %1586
  %1588 = and i8 %1585, %1587
  %1589 = icmp ne i8 %1588, 0
  %1590 = load <8 x i32>, ptr %frame.static.id, align 32
  %1591 = extractelement <8 x i32> %1590, i32 %1584
  %1592 = icmp eq i32 %1591, 4
  %1593 = and i1 %1589, %1592
  %1594 = and i1 %1582, %1593
  %1595 = xor i1 %1594, true
  %1596 = and i1 true, %1595
  %1597 = xor i8 %1585, -1
  %1598 = icmp ne i8 %1597, 0
  %1599 = xor i1 %1598, true
  %1600 = and i1 %1596, %1599
  br i1 %1600, label %convergence.overflow.trap317, label %convergence.overflow.resume318

varying.coherent316:                              ; preds = %schedule.12
  br i1 %436, label %varying.coherent.true321, label %varying.coherent.false322

convergence.overflow.trap317:                     ; preds = %varying.divergent315
  call void @llvm.trap()
  unreachable

convergence.overflow.resume318:                   ; preds = %varying.divergent315
  %1601 = call i8 @llvm.cttz.i8(i8 %1597, i1 false)
  %1602 = zext i8 %1601 to i32
  %1603 = select i1 %1598, i32 %1602, i32 0
  %1604 = trunc i32 %1603 to i8
  %1605 = shl i8 1, %1604
  %1606 = or i8 %1585, %1605
  %1607 = select i1 %1596, i8 %1606, i8 %1585
  store i8 %1607, ptr %frame.active, align 1
  %1608 = load <8 x i32>, ptr %frame.static.id, align 32
  %1609 = extractelement <8 x i32> %1608, i32 %1603
  %1610 = select i1 %1596, i32 4, i32 %1609
  %1611 = load <8 x i32>, ptr %frame.static.id, align 32
  %1612 = insertelement <8 x i32> %1611, i32 %1610, i32 %1603
  store <8 x i32> %1612, ptr %frame.static.id, align 32
  %1613 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1614 = extractelement <8 x i32> %1613, i32 %1603
  %1615 = select i1 %1596, i32 %1581, i32 %1614
  %1616 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1617 = insertelement <8 x i32> %1616, i32 %1615, i32 %1603
  store <8 x i32> %1617, ptr %frame.parent.token, align 32
  %1618 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1603
  %1619 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1603
  %1620 = load <8 x i1>, ptr %1618, align 1
  %1621 = load <8 x i1>, ptr %1619, align 1
  %1622 = select i1 %1596, <8 x i1> %426, <8 x i1> %1620
  store <8 x i1> %1622, ptr %1618, align 1
  %1623 = select i1 %1596, <8 x i1> zeroinitializer, <8 x i1> %1621
  store <8 x i1> %1623, ptr %1619, align 1
  %1624 = add i32 %1603, 1
  %1625 = select i1 %1594, i32 %1581, i32 %1624
  %1626 = select i1 true, i32 %1625, i32 %1581
  store i32 %1626, ptr %current.token, align 4
  %1627 = load i32, ptr %current.token, align 4
  %1628 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %433)
  %1629 = load i32, ptr %ready.count, align 4
  %1630 = icmp uge i32 %1629, 8
  %1631 = and i1 %1628, %1630
  br i1 %1631, label %ready.overflow.trap319, label %ready.overflow.resume320

ready.overflow.trap319:                           ; preds = %convergence.overflow.resume318
  call void @llvm.trap()
  unreachable

ready.overflow.resume320:                         ; preds = %convergence.overflow.resume318
  %1632 = select i1 %1628, i32 %1629, i32 0
  %1633 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1632
  %1634 = load <8 x i1>, ptr %1633, align 1
  %1635 = select i1 %1628, <8 x i1> %433, <8 x i1> %1634
  store <8 x i1> %1635, ptr %1633, align 1
  %1636 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1632
  %1637 = load i32, ptr %1636, align 4
  %1638 = select i1 %1628, i32 13, i32 %1637
  store i32 %1638, ptr %1636, align 4
  %1639 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1632
  %1640 = load i32, ptr %1639, align 4
  %1641 = select i1 %1628, i32 %1627, i32 %1640
  store i32 %1641, ptr %1639, align 4
  %1642 = add i32 %1629, 1
  %1643 = select i1 %1628, i32 %1642, i32 %1629
  store i32 %1643, ptr %ready.count, align 4
  %1644 = load <8 x i1>, ptr %runnable.mask, align 1
  %1645 = or <8 x i1> %1644, %433
  store <8 x i1> %1645, ptr %runnable.mask, align 1
  store <8 x i1> %435, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true321:                         ; preds = %varying.coherent316
  store <8 x i1> %426, ptr %current.mask, align 1
  %1646 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %426)
  br i1 %1646, label %schedule.13, label %scheduler.loop

varying.coherent.false322:                        ; preds = %varying.coherent316
  store <8 x i1> %426, ptr %current.mask, align 1
  %1647 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %426)
  br i1 %1647, label %schedule.14, label %scheduler.loop

convergence.cascade360:                           ; preds = %convergence.cascade360, %schedule.14
  %convergence.cascade.flow364 = phi <8 x i1> [ %561, %schedule.14 ], [ %1690, %convergence.cascade360 ]
  %convergence.cascade.depth365 = phi i32 [ 0, %schedule.14 ], [ %1691, %convergence.cascade360 ]
  %1648 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow364)
  %1649 = load i32, ptr %current.token, align 4
  %1650 = icmp ne i32 %1649, 0
  %1651 = and i1 %1648, %1650
  %1652 = sub i32 %1649, 1
  %1653 = select i1 %1651, i32 %1652, i32 0
  %1654 = load i8, ptr %frame.active, align 1
  %1655 = trunc i32 %1653 to i8
  %1656 = shl i8 1, %1655
  %1657 = and i8 %1654, %1656
  %1658 = icmp ne i8 %1657, 0
  %1659 = load <8 x i32>, ptr %frame.static.id, align 32
  %1660 = extractelement <8 x i32> %1659, i32 %1653
  %convergence.target.pointer366 = getelementptr inbounds [9 x i32], ptr @convergence.targets, i32 0, i32 %1660
  %convergence.dynamic.target367 = load i32, ptr %convergence.target.pointer366, align 4
  %1661 = icmp eq i32 %convergence.dynamic.target367, 14
  %1662 = and i1 %1658, %1661
  %1663 = and i1 %1651, %1662
  %1664 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1653
  %1665 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1653
  %1666 = load <8 x i1>, ptr %1664, align 1
  %1667 = load <8 x i1>, ptr %1665, align 1
  %1668 = or <8 x i1> %1667, %convergence.cascade.flow364
  %1669 = load <8 x i1>, ptr %live.mask, align 1
  %1670 = and <8 x i1> %1666, %1669
  %1671 = icmp eq <8 x i1> %1668, %1670
  %1672 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1671)
  %1673 = and i1 %1663, %1672
  %1674 = select i1 %1673, <8 x i1> zeroinitializer, <8 x i1> %1668
  %1675 = select i1 %1663, <8 x i1> %1674, <8 x i1> %1667
  store <8 x i1> %1675, ptr %1665, align 1
  %1676 = select i1 %1673, <8 x i1> zeroinitializer, <8 x i1> %1666
  store <8 x i1> %1676, ptr %1664, align 1
  %1677 = trunc i32 %1653 to i8
  %1678 = shl i8 1, %1677
  %1679 = xor i8 %1678, -1
  %1680 = and i8 %1654, %1679
  %1681 = select i1 %1673, i8 %1680, i8 %1654
  store i8 %1681, ptr %frame.active, align 1
  %.splatinsert368 = insertelement <8 x i1> poison, i1 %1663, i64 0
  %.splat369 = shufflevector <8 x i1> %.splatinsert368, <8 x i1> poison, <8 x i32> zeroinitializer
  %1682 = and <8 x i1> %convergence.cascade.flow364, %.splat369
  %1683 = load <8 x i1>, ptr %runnable.mask, align 1
  %1684 = xor <8 x i1> %1682, splat (i1 true)
  %1685 = and <8 x i1> %1683, %1684
  store <8 x i1> %1685, ptr %runnable.mask, align 1
  %.splatinsert370 = insertelement <8 x i1> poison, i1 %1673, i64 0
  %.splat371 = shufflevector <8 x i1> %.splatinsert370, <8 x i1> poison, <8 x i32> zeroinitializer
  %1686 = select <8 x i1> %.splat371, <8 x i1> %1668, <8 x i1> zeroinitializer
  %1687 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1688 = extractelement <8 x i32> %1687, i32 %1653
  %1689 = select i1 %1673, i32 %1688, i32 %1649
  store i32 %1689, ptr %current.token, align 4
  %.splatinsert372 = insertelement <8 x i1> poison, i1 %1663, i64 0
  %.splat373 = shufflevector <8 x i1> %.splatinsert372, <8 x i1> poison, <8 x i32> zeroinitializer
  %1690 = select <8 x i1> %.splat373, <8 x i1> %1686, <8 x i1> %convergence.cascade.flow364
  %1691 = add i32 %convergence.cascade.depth365, 1
  %1692 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1690)
  %1693 = icmp ult i32 %1691, 8
  %1694 = and i1 %1692, %1693
  %1695 = and i1 %1663, %1694
  %convergence.parent.token374 = load i32, ptr %current.token, align 4
  %convergence.parent.present375 = icmp ne i32 %convergence.parent.token374, 0
  %1696 = and i1 %1695, %convergence.parent.present375
  br i1 %1696, label %convergence.cascade360, label %convergence.cascade.exit361

convergence.cascade.exit361:                      ; preds = %convergence.cascade360, %schedule.14
  %convergence.cascade.result376 = phi <8 x i1> [ %561, %schedule.14 ], [ %1690, %convergence.cascade360 ]
  %1697 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result376)
  br i1 %1697, label %convergence.target.14.ready, label %scheduler.loop

convergence.target.14.ready:                      ; preds = %convergence.cascade.exit361
  %1698 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result376)
  %1699 = bitcast <8 x i1> %convergence.cascade.result376 to i8
  %1700 = call i8 @llvm.cttz.i8(i8 %1699, i1 false)
  %1701 = zext i8 %1700 to i32
  %1702 = select i1 %1698, i32 %1701, i32 0
  %.spill.load377 = load i64, ptr %.spill24, align 4
  %.spill.load378 = load i64, ptr %.spill15, align 4
  %1703 = add i64 %.spill.load377, %.spill.load378
  %1704 = srem i64 %1703, 65
  %1705 = sdiv i64 %1703, 65
  %.spill.load379 = load i64, ptr %.spill5, align 4
  %1706 = add i64 %.spill.load379, %1705
  %1707 = mul i64 %1706, 65
  %1708 = add i64 %1707, %1704
  %tile_snapshot.spill.load380 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1709 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load380, 0
  %1710 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load380, 1
  %.splatinsert381 = insertelement <8 x i64> poison, i64 %1708, i64 0
  %.splat382 = shufflevector <8 x i64> %.splatinsert381, <8 x i64> poison, <8 x i32> zeroinitializer
  %1711 = mul <8 x i64> %.splat382, splat (i64 32)
  %1712 = add <8 x i64> %1710, %1711
  %1713 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1709, 0
  %1714 = insertvalue { <8 x ptr>, <8 x i64> } %1713, <8 x i64> %1712, 1
  %1715 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1716 = extractvalue { <8 x ptr>, <8 x i64> } %1714, 1
  %1717 = extractelement <8 x ptr> %1715, i32 0
  %1718 = extractelement <8 x i64> %1716, i32 %1702
  %1719 = zext i32 %1702 to i64
  %1720 = mul i64 %1719, 4
  %1721 = sub i64 %1718, %1720
  %1722 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result376)
  %1723 = select i1 %1722, i64 %1721, i64 0
  %private.contiguous.address383 = getelementptr i8, ptr %1717, i64 %1723
  %private.contiguous.load384 = load <8 x float>, ptr %private.contiguous.address383, align 4
  %1724 = select <8 x i1> %convergence.cascade.result376, <8 x float> %private.contiguous.load384, <8 x float> zeroinitializer
  %1725 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %1724)
  %.state385 = load <8 x float>, ptr %.slot26, align 32
  %1726 = fadd <8 x float> %.state385, %1725
  %.spill.load386 = load float, ptr %.spill3, align 4
  %.splatinsert387 = insertelement <8 x float> poison, float %.spill.load386, i64 0
  %.splat388 = shufflevector <8 x float> %.splatinsert387, <8 x float> poison, <8 x i32> zeroinitializer
  %1727 = fadd <8 x float> %.splat388, %1726
  %.state389 = load <8 x float>, ptr %.slot27, align 32
  %1728 = fadd <8 x float> %1727, %.state389
  %.state390 = load <8 x float>, ptr %.slot28, align 32
  %1729 = fadd <8 x float> %1728, %.state390
  %.state391 = load <8 x float>, ptr %.slot29, align 32
  %1730 = fadd <8 x float> %1729, %.state391
  %1731 = load <8 x float>, ptr %.spill30, align 32
  %1732 = select <8 x i1> %convergence.cascade.result376, <8 x float> %1730, <8 x float> %1731
  store <8 x float> %1732, ptr %.spill30, align 32
  %.spill.load392 = load i64, ptr %.spill5, align 4
  %1733 = add i64 %.spill.load392, 3
  %1734 = mul i64 %1733, 65
  store i64 %1734, ptr %.spill31, align 4
  %.spill.load393 = load i64, ptr %.spill4, align 4
  %1735 = add i64 %1734, %.spill.load393
  %1736 = srem i64 %1735, 65
  %1737 = sdiv i64 %1735, 65
  %.spill.load394 = load i64, ptr %.spill5, align 4
  %1738 = add i64 %.spill.load394, %1737
  %1739 = mul i64 %1738, 65
  %1740 = add i64 %1739, %1736
  %tile_snapshot.spill.load395 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1741 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load395, 0
  %1742 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load395, 1
  %.splatinsert396 = insertelement <8 x i64> poison, i64 %1740, i64 0
  %.splat397 = shufflevector <8 x i64> %.splatinsert396, <8 x i64> poison, <8 x i32> zeroinitializer
  %1743 = mul <8 x i64> %.splat397, splat (i64 32)
  %1744 = add <8 x i64> %1742, %1743
  %1745 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1741, 0
  %1746 = insertvalue { <8 x ptr>, <8 x i64> } %1745, <8 x i64> %1744, 1
  %1747 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1748 = extractvalue { <8 x ptr>, <8 x i64> } %1746, 1
  %1749 = extractelement <8 x ptr> %1747, i32 0
  %1750 = extractelement <8 x i64> %1748, i32 %1702
  %1751 = zext i32 %1702 to i64
  %1752 = mul i64 %1751, 4
  %1753 = sub i64 %1750, %1752
  %1754 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result376)
  %1755 = select i1 %1754, i64 %1753, i64 0
  %private.contiguous.address398 = getelementptr i8, ptr %1749, i64 %1755
  %private.contiguous.load399 = load <8 x float>, ptr %private.contiguous.address398, align 4
  %1756 = select <8 x i1> %convergence.cascade.result376, <8 x float> %private.contiguous.load399, <8 x float> zeroinitializer
  %1757 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %1756)
  %.spill.load400 = load i64, ptr %.spill7, align 4
  %1758 = add i64 %1734, %.spill.load400
  %1759 = srem i64 %1758, 65
  %1760 = sdiv i64 %1758, 65
  %.spill.load401 = load i64, ptr %.spill5, align 4
  %1761 = add i64 %.spill.load401, %1760
  %1762 = mul i64 %1761, 65
  %1763 = add i64 %1762, %1759
  %tile_snapshot.spill.load402 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1764 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load402, 0
  %1765 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load402, 1
  %.splatinsert403 = insertelement <8 x i64> poison, i64 %1763, i64 0
  %.splat404 = shufflevector <8 x i64> %.splatinsert403, <8 x i64> poison, <8 x i32> zeroinitializer
  %1766 = mul <8 x i64> %.splat404, splat (i64 32)
  %1767 = add <8 x i64> %1765, %1766
  %1768 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1764, 0
  %1769 = insertvalue { <8 x ptr>, <8 x i64> } %1768, <8 x i64> %1767, 1
  %1770 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1771 = extractvalue { <8 x ptr>, <8 x i64> } %1769, 1
  %1772 = extractelement <8 x ptr> %1770, i32 0
  %1773 = extractelement <8 x i64> %1771, i32 %1702
  %1774 = zext i32 %1702 to i64
  %1775 = mul i64 %1774, 4
  %1776 = sub i64 %1773, %1775
  %1777 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result376)
  %1778 = select i1 %1777, i64 %1776, i64 0
  %private.contiguous.address405 = getelementptr i8, ptr %1772, i64 %1778
  %private.contiguous.load406 = load <8 x float>, ptr %private.contiguous.address405, align 4
  %1779 = select <8 x i1> %convergence.cascade.result376, <8 x float> %private.contiguous.load406, <8 x float> zeroinitializer
  %1780 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %1779)
  %.spill.load407 = load i64, ptr %.spill8, align 4
  %1781 = add i64 %1734, %.spill.load407
  %1782 = srem i64 %1781, 65
  %1783 = sdiv i64 %1781, 65
  %.spill.load408 = load i64, ptr %.spill5, align 4
  %1784 = add i64 %.spill.load408, %1783
  %1785 = mul i64 %1784, 65
  %1786 = add i64 %1785, %1782
  %tile_snapshot.spill.load409 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1787 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 0
  %1788 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 1
  %.splatinsert410 = insertelement <8 x i64> poison, i64 %1786, i64 0
  %.splat411 = shufflevector <8 x i64> %.splatinsert410, <8 x i64> poison, <8 x i32> zeroinitializer
  %1789 = mul <8 x i64> %.splat411, splat (i64 32)
  %1790 = add <8 x i64> %1788, %1789
  %1791 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1787, 0
  %1792 = insertvalue { <8 x ptr>, <8 x i64> } %1791, <8 x i64> %1790, 1
  %1793 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1794 = extractvalue { <8 x ptr>, <8 x i64> } %1792, 1
  %1795 = extractelement <8 x ptr> %1793, i32 0
  %1796 = extractelement <8 x i64> %1794, i32 %1702
  %1797 = zext i32 %1702 to i64
  %1798 = mul i64 %1797, 4
  %1799 = sub i64 %1796, %1798
  %1800 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result376)
  %1801 = select i1 %1800, i64 %1799, i64 0
  %private.contiguous.address412 = getelementptr i8, ptr %1795, i64 %1801
  %private.contiguous.load413 = load <8 x float>, ptr %private.contiguous.address412, align 4
  %1802 = select <8 x i1> %convergence.cascade.result376, <8 x float> %private.contiguous.load413, <8 x float> zeroinitializer
  %1803 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %1802)
  %.spill.load414 = load i64, ptr %.spill9, align 4
  %1804 = add i64 %1734, %.spill.load414
  %1805 = srem i64 %1804, 65
  %1806 = sdiv i64 %1804, 65
  %.spill.load415 = load i64, ptr %.spill5, align 4
  %1807 = add i64 %.spill.load415, %1806
  %1808 = mul i64 %1807, 65
  %1809 = add i64 %1808, %1805
  %tile_snapshot.spill.load416 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1810 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load416, 0
  %1811 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load416, 1
  %.splatinsert417 = insertelement <8 x i64> poison, i64 %1809, i64 0
  %.splat418 = shufflevector <8 x i64> %.splatinsert417, <8 x i64> poison, <8 x i32> zeroinitializer
  %1812 = mul <8 x i64> %.splat418, splat (i64 32)
  %1813 = add <8 x i64> %1811, %1812
  %1814 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1810, 0
  %1815 = insertvalue { <8 x ptr>, <8 x i64> } %1814, <8 x i64> %1813, 1
  %1816 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1817 = extractvalue { <8 x ptr>, <8 x i64> } %1815, 1
  %1818 = extractelement <8 x ptr> %1816, i32 0
  %1819 = extractelement <8 x i64> %1817, i32 %1702
  %1820 = zext i32 %1702 to i64
  %1821 = mul i64 %1820, 4
  %1822 = sub i64 %1819, %1821
  %1823 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result376)
  %1824 = select i1 %1823, i64 %1822, i64 0
  %private.contiguous.address419 = getelementptr i8, ptr %1818, i64 %1824
  %private.contiguous.load420 = load <8 x float>, ptr %private.contiguous.address419, align 4
  %1825 = select <8 x i1> %convergence.cascade.result376, <8 x float> %private.contiguous.load420, <8 x float> zeroinitializer
  %1826 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %1825)
  %1827 = load <8 x i64>, ptr %.slot32, align 64
  %1828 = select <8 x i1> %convergence.cascade.result376, <8 x i64> splat (i64 4), <8 x i64> %1827
  store <8 x i64> %1828, ptr %.slot32, align 64
  %1829 = load <8 x float>, ptr %.slot33, align 32
  %1830 = select <8 x i1> %convergence.cascade.result376, <8 x float> %1757, <8 x float> %1829
  store <8 x float> %1830, ptr %.slot33, align 32
  %1831 = load <8 x float>, ptr %.slot34, align 32
  %1832 = select <8 x i1> %convergence.cascade.result376, <8 x float> %1780, <8 x float> %1831
  store <8 x float> %1832, ptr %.slot34, align 32
  %1833 = load <8 x float>, ptr %.slot35, align 32
  %1834 = select <8 x i1> %convergence.cascade.result376, <8 x float> %1803, <8 x float> %1833
  store <8 x float> %1834, ptr %.slot35, align 32
  %1835 = load <8 x float>, ptr %.slot36, align 32
  %1836 = select <8 x i1> %convergence.cascade.result376, <8 x float> %1826, <8 x float> %1835
  store <8 x float> %1836, ptr %.slot36, align 32
  store <8 x i1> %convergence.cascade.result376, ptr %current.mask, align 1
  %1837 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result376)
  br i1 %1837, label %schedule.15, label %scheduler.loop

varying.divergent422:                             ; preds = %schedule.15
  %1838 = load i32, ptr %current.token, align 4
  %1839 = icmp ne i32 %1838, 0
  %1840 = sub i32 %1838, 1
  %1841 = select i1 %1839, i32 %1840, i32 0
  %1842 = load i8, ptr %frame.active, align 1
  %1843 = trunc i32 %1841 to i8
  %1844 = shl i8 1, %1843
  %1845 = and i8 %1842, %1844
  %1846 = icmp ne i8 %1845, 0
  %1847 = load <8 x i32>, ptr %frame.static.id, align 32
  %1848 = extractelement <8 x i32> %1847, i32 %1841
  %1849 = icmp eq i32 %1848, 5
  %1850 = and i1 %1846, %1849
  %1851 = and i1 %1839, %1850
  %1852 = xor i1 %1851, true
  %1853 = and i1 true, %1852
  %1854 = xor i8 %1842, -1
  %1855 = icmp ne i8 %1854, 0
  %1856 = xor i1 %1855, true
  %1857 = and i1 %1853, %1856
  br i1 %1857, label %convergence.overflow.trap424, label %convergence.overflow.resume425

varying.coherent423:                              ; preds = %schedule.15
  br i1 %572, label %varying.coherent.true428, label %varying.coherent.false429

convergence.overflow.trap424:                     ; preds = %varying.divergent422
  call void @llvm.trap()
  unreachable

convergence.overflow.resume425:                   ; preds = %varying.divergent422
  %1858 = call i8 @llvm.cttz.i8(i8 %1854, i1 false)
  %1859 = zext i8 %1858 to i32
  %1860 = select i1 %1855, i32 %1859, i32 0
  %1861 = trunc i32 %1860 to i8
  %1862 = shl i8 1, %1861
  %1863 = or i8 %1842, %1862
  %1864 = select i1 %1853, i8 %1863, i8 %1842
  store i8 %1864, ptr %frame.active, align 1
  %1865 = load <8 x i32>, ptr %frame.static.id, align 32
  %1866 = extractelement <8 x i32> %1865, i32 %1860
  %1867 = select i1 %1853, i32 5, i32 %1866
  %1868 = load <8 x i32>, ptr %frame.static.id, align 32
  %1869 = insertelement <8 x i32> %1868, i32 %1867, i32 %1860
  store <8 x i32> %1869, ptr %frame.static.id, align 32
  %1870 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1871 = extractelement <8 x i32> %1870, i32 %1860
  %1872 = select i1 %1853, i32 %1838, i32 %1871
  %1873 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1874 = insertelement <8 x i32> %1873, i32 %1872, i32 %1860
  store <8 x i32> %1874, ptr %frame.parent.token, align 32
  %1875 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1860
  %1876 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1860
  %1877 = load <8 x i1>, ptr %1875, align 1
  %1878 = load <8 x i1>, ptr %1876, align 1
  %1879 = select i1 %1853, <8 x i1> %562, <8 x i1> %1877
  store <8 x i1> %1879, ptr %1875, align 1
  %1880 = select i1 %1853, <8 x i1> zeroinitializer, <8 x i1> %1878
  store <8 x i1> %1880, ptr %1876, align 1
  %1881 = add i32 %1860, 1
  %1882 = select i1 %1851, i32 %1838, i32 %1881
  %1883 = select i1 true, i32 %1882, i32 %1838
  store i32 %1883, ptr %current.token, align 4
  %1884 = load i32, ptr %current.token, align 4
  %1885 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %569)
  %1886 = load i32, ptr %ready.count, align 4
  %1887 = icmp uge i32 %1886, 8
  %1888 = and i1 %1885, %1887
  br i1 %1888, label %ready.overflow.trap426, label %ready.overflow.resume427

ready.overflow.trap426:                           ; preds = %convergence.overflow.resume425
  call void @llvm.trap()
  unreachable

ready.overflow.resume427:                         ; preds = %convergence.overflow.resume425
  %1889 = select i1 %1885, i32 %1886, i32 0
  %1890 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1889
  %1891 = load <8 x i1>, ptr %1890, align 1
  %1892 = select i1 %1885, <8 x i1> %569, <8 x i1> %1891
  store <8 x i1> %1892, ptr %1890, align 1
  %1893 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1889
  %1894 = load i32, ptr %1893, align 4
  %1895 = select i1 %1885, i32 16, i32 %1894
  store i32 %1895, ptr %1893, align 4
  %1896 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1889
  %1897 = load i32, ptr %1896, align 4
  %1898 = select i1 %1885, i32 %1884, i32 %1897
  store i32 %1898, ptr %1896, align 4
  %1899 = add i32 %1886, 1
  %1900 = select i1 %1885, i32 %1899, i32 %1886
  store i32 %1900, ptr %ready.count, align 4
  %1901 = load <8 x i1>, ptr %runnable.mask, align 1
  %1902 = or <8 x i1> %1901, %569
  store <8 x i1> %1902, ptr %runnable.mask, align 1
  store <8 x i1> %571, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true428:                         ; preds = %varying.coherent423
  store <8 x i1> %562, ptr %current.mask, align 1
  %1903 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %562)
  br i1 %1903, label %schedule.16, label %scheduler.loop

varying.coherent.false429:                        ; preds = %varying.coherent423
  store <8 x i1> %562, ptr %current.mask, align 1
  %1904 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %562)
  br i1 %1904, label %schedule.17, label %scheduler.loop

convergence.cascade467:                           ; preds = %convergence.cascade467, %schedule.17
  %convergence.cascade.flow471 = phi <8 x i1> [ %697, %schedule.17 ], [ %1947, %convergence.cascade467 ]
  %convergence.cascade.depth472 = phi i32 [ 0, %schedule.17 ], [ %1948, %convergence.cascade467 ]
  %1905 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow471)
  %1906 = load i32, ptr %current.token, align 4
  %1907 = icmp ne i32 %1906, 0
  %1908 = and i1 %1905, %1907
  %1909 = sub i32 %1906, 1
  %1910 = select i1 %1908, i32 %1909, i32 0
  %1911 = load i8, ptr %frame.active, align 1
  %1912 = trunc i32 %1910 to i8
  %1913 = shl i8 1, %1912
  %1914 = and i8 %1911, %1913
  %1915 = icmp ne i8 %1914, 0
  %1916 = load <8 x i32>, ptr %frame.static.id, align 32
  %1917 = extractelement <8 x i32> %1916, i32 %1910
  %convergence.target.pointer473 = getelementptr inbounds [9 x i32], ptr @convergence.targets, i32 0, i32 %1917
  %convergence.dynamic.target474 = load i32, ptr %convergence.target.pointer473, align 4
  %1918 = icmp eq i32 %convergence.dynamic.target474, 17
  %1919 = and i1 %1915, %1918
  %1920 = and i1 %1908, %1919
  %1921 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1910
  %1922 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1910
  %1923 = load <8 x i1>, ptr %1921, align 1
  %1924 = load <8 x i1>, ptr %1922, align 1
  %1925 = or <8 x i1> %1924, %convergence.cascade.flow471
  %1926 = load <8 x i1>, ptr %live.mask, align 1
  %1927 = and <8 x i1> %1923, %1926
  %1928 = icmp eq <8 x i1> %1925, %1927
  %1929 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1928)
  %1930 = and i1 %1920, %1929
  %1931 = select i1 %1930, <8 x i1> zeroinitializer, <8 x i1> %1925
  %1932 = select i1 %1920, <8 x i1> %1931, <8 x i1> %1924
  store <8 x i1> %1932, ptr %1922, align 1
  %1933 = select i1 %1930, <8 x i1> zeroinitializer, <8 x i1> %1923
  store <8 x i1> %1933, ptr %1921, align 1
  %1934 = trunc i32 %1910 to i8
  %1935 = shl i8 1, %1934
  %1936 = xor i8 %1935, -1
  %1937 = and i8 %1911, %1936
  %1938 = select i1 %1930, i8 %1937, i8 %1911
  store i8 %1938, ptr %frame.active, align 1
  %.splatinsert475 = insertelement <8 x i1> poison, i1 %1920, i64 0
  %.splat476 = shufflevector <8 x i1> %.splatinsert475, <8 x i1> poison, <8 x i32> zeroinitializer
  %1939 = and <8 x i1> %convergence.cascade.flow471, %.splat476
  %1940 = load <8 x i1>, ptr %runnable.mask, align 1
  %1941 = xor <8 x i1> %1939, splat (i1 true)
  %1942 = and <8 x i1> %1940, %1941
  store <8 x i1> %1942, ptr %runnable.mask, align 1
  %.splatinsert477 = insertelement <8 x i1> poison, i1 %1930, i64 0
  %.splat478 = shufflevector <8 x i1> %.splatinsert477, <8 x i1> poison, <8 x i32> zeroinitializer
  %1943 = select <8 x i1> %.splat478, <8 x i1> %1925, <8 x i1> zeroinitializer
  %1944 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1945 = extractelement <8 x i32> %1944, i32 %1910
  %1946 = select i1 %1930, i32 %1945, i32 %1906
  store i32 %1946, ptr %current.token, align 4
  %.splatinsert479 = insertelement <8 x i1> poison, i1 %1920, i64 0
  %.splat480 = shufflevector <8 x i1> %.splatinsert479, <8 x i1> poison, <8 x i32> zeroinitializer
  %1947 = select <8 x i1> %.splat480, <8 x i1> %1943, <8 x i1> %convergence.cascade.flow471
  %1948 = add i32 %convergence.cascade.depth472, 1
  %1949 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1947)
  %1950 = icmp ult i32 %1948, 8
  %1951 = and i1 %1949, %1950
  %1952 = and i1 %1920, %1951
  %convergence.parent.token481 = load i32, ptr %current.token, align 4
  %convergence.parent.present482 = icmp ne i32 %convergence.parent.token481, 0
  %1953 = and i1 %1952, %convergence.parent.present482
  br i1 %1953, label %convergence.cascade467, label %convergence.cascade.exit468

convergence.cascade.exit468:                      ; preds = %convergence.cascade467, %schedule.17
  %convergence.cascade.result483 = phi <8 x i1> [ %697, %schedule.17 ], [ %1947, %convergence.cascade467 ]
  %1954 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result483)
  br i1 %1954, label %convergence.target.17.ready, label %scheduler.loop

convergence.target.17.ready:                      ; preds = %convergence.cascade.exit468
  %1955 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result483)
  %1956 = bitcast <8 x i1> %convergence.cascade.result483 to i8
  %1957 = call i8 @llvm.cttz.i8(i8 %1956, i1 false)
  %1958 = zext i8 %1957 to i32
  %1959 = select i1 %1955, i32 %1958, i32 0
  %.spill.load484 = load i64, ptr %.spill31, align 4
  %.spill.load485 = load i64, ptr %.spill15, align 4
  %1960 = add i64 %.spill.load484, %.spill.load485
  %1961 = srem i64 %1960, 65
  %1962 = sdiv i64 %1960, 65
  %.spill.load486 = load i64, ptr %.spill5, align 4
  %1963 = add i64 %.spill.load486, %1962
  %1964 = mul i64 %1963, 65
  %1965 = add i64 %1964, %1961
  %tile_snapshot.spill.load487 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1966 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load487, 0
  %1967 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load487, 1
  %.splatinsert488 = insertelement <8 x i64> poison, i64 %1965, i64 0
  %.splat489 = shufflevector <8 x i64> %.splatinsert488, <8 x i64> poison, <8 x i32> zeroinitializer
  %1968 = mul <8 x i64> %.splat489, splat (i64 32)
  %1969 = add <8 x i64> %1967, %1968
  %1970 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1966, 0
  %1971 = insertvalue { <8 x ptr>, <8 x i64> } %1970, <8 x i64> %1969, 1
  %1972 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1973 = extractvalue { <8 x ptr>, <8 x i64> } %1971, 1
  %1974 = extractelement <8 x ptr> %1972, i32 0
  %1975 = extractelement <8 x i64> %1973, i32 %1959
  %1976 = zext i32 %1959 to i64
  %1977 = mul i64 %1976, 4
  %1978 = sub i64 %1975, %1977
  %1979 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result483)
  %1980 = select i1 %1979, i64 %1978, i64 0
  %private.contiguous.address490 = getelementptr i8, ptr %1974, i64 %1980
  %private.contiguous.load491 = load <8 x float>, ptr %private.contiguous.address490, align 4
  %1981 = select <8 x i1> %convergence.cascade.result483, <8 x float> %private.contiguous.load491, <8 x float> zeroinitializer
  %1982 = call <8 x float> @llvm.fabs.v8f32(<8 x float> %1981)
  %.state492 = load <8 x float>, ptr %.slot33, align 32
  %1983 = fadd <8 x float> %.state492, %1982
  %.spill.load493 = load float, ptr %.spill3, align 4
  %.splatinsert494 = insertelement <8 x float> poison, float %.spill.load493, i64 0
  %.splat495 = shufflevector <8 x float> %.splatinsert494, <8 x float> poison, <8 x i32> zeroinitializer
  %1984 = fadd <8 x float> %.splat495, %1983
  %.state496 = load <8 x float>, ptr %.slot34, align 32
  %1985 = fadd <8 x float> %1984, %.state496
  %.state497 = load <8 x float>, ptr %.slot35, align 32
  %1986 = fadd <8 x float> %1985, %.state497
  %.state498 = load <8 x float>, ptr %.slot36, align 32
  %1987 = fadd <8 x float> %1986, %.state498
  %1988 = load <8 x float>, ptr %.spill37, align 32
  %1989 = select <8 x i1> %convergence.cascade.result483, <8 x float> %1987, <8 x float> %1988
  store <8 x float> %1989, ptr %.spill37, align 32
  %.spill.load499 = load <8 x i64>, ptr %.spill, align 64
  %1990 = add <8 x i64> %.spill.load499, zeroinitializer
  store i64 0, ptr %.spill38, align 4
  %1991 = add <8 x i64> zeroinitializer, %1990
  %.spill.load500 = load <8 x float>, ptr %.spill16, align 32
  %1992 = extractvalue { ptr, i64 } %13, 0
  %1993 = mul <8 x i64> %1991, splat (i64 4)
  %1994 = getelementptr i8, ptr %1992, <8 x i64> %1993
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.spill.load500, <8 x ptr> %1994, i32 1, <8 x i1> %convergence.cascade.result483)
  %.spill.load501 = load <8 x i64>, ptr %.spill, align 64
  %1995 = add <8 x i64> %.spill.load501, splat (i64 1)
  %1996 = add <8 x i64> zeroinitializer, %1995
  %1997 = icmp sge <8 x i64> %1995, zeroinitializer
  %1998 = and <8 x i1> splat (i1 true), %1997
  %1999 = icmp slt <8 x i64> %1995, splat (i64 17)
  %2000 = and <8 x i1> %1998, %1999
  %2001 = load <8 x i64>, ptr %.spill39, align 64
  %2002 = select <8 x i1> %convergence.cascade.result483, <8 x i64> %1996, <8 x i64> %2001
  store <8 x i64> %2002, ptr %.spill39, align 64
  %2003 = and <8 x i1> %convergence.cascade.result483, %2000
  %2004 = xor <8 x i1> %2000, splat (i1 true)
  %2005 = and <8 x i1> %convergence.cascade.result483, %2004
  %2006 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2003)
  %2007 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2005)
  %2008 = and i1 %2006, %2007
  br i1 %2008, label %varying.divergent502, label %varying.coherent503

varying.divergent502:                             ; preds = %convergence.target.17.ready
  %2009 = load i32, ptr %current.token, align 4
  %2010 = icmp ne i32 %2009, 0
  %2011 = sub i32 %2009, 1
  %2012 = select i1 %2010, i32 %2011, i32 0
  %2013 = load i8, ptr %frame.active, align 1
  %2014 = trunc i32 %2012 to i8
  %2015 = shl i8 1, %2014
  %2016 = and i8 %2013, %2015
  %2017 = icmp ne i8 %2016, 0
  %2018 = load <8 x i32>, ptr %frame.static.id, align 32
  %2019 = extractelement <8 x i32> %2018, i32 %2012
  %2020 = icmp eq i32 %2019, 6
  %2021 = and i1 %2017, %2020
  %2022 = and i1 %2010, %2021
  %2023 = xor i1 %2022, true
  %2024 = and i1 true, %2023
  %2025 = xor i8 %2013, -1
  %2026 = icmp ne i8 %2025, 0
  %2027 = xor i1 %2026, true
  %2028 = and i1 %2024, %2027
  br i1 %2028, label %convergence.overflow.trap504, label %convergence.overflow.resume505

varying.coherent503:                              ; preds = %convergence.target.17.ready
  br i1 %2006, label %varying.coherent.true508, label %varying.coherent.false509

convergence.overflow.trap504:                     ; preds = %varying.divergent502
  call void @llvm.trap()
  unreachable

convergence.overflow.resume505:                   ; preds = %varying.divergent502
  %2029 = call i8 @llvm.cttz.i8(i8 %2025, i1 false)
  %2030 = zext i8 %2029 to i32
  %2031 = select i1 %2026, i32 %2030, i32 0
  %2032 = trunc i32 %2031 to i8
  %2033 = shl i8 1, %2032
  %2034 = or i8 %2013, %2033
  %2035 = select i1 %2024, i8 %2034, i8 %2013
  store i8 %2035, ptr %frame.active, align 1
  %2036 = load <8 x i32>, ptr %frame.static.id, align 32
  %2037 = extractelement <8 x i32> %2036, i32 %2031
  %2038 = select i1 %2024, i32 6, i32 %2037
  %2039 = load <8 x i32>, ptr %frame.static.id, align 32
  %2040 = insertelement <8 x i32> %2039, i32 %2038, i32 %2031
  store <8 x i32> %2040, ptr %frame.static.id, align 32
  %2041 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2042 = extractelement <8 x i32> %2041, i32 %2031
  %2043 = select i1 %2024, i32 %2009, i32 %2042
  %2044 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2045 = insertelement <8 x i32> %2044, i32 %2043, i32 %2031
  store <8 x i32> %2045, ptr %frame.parent.token, align 32
  %2046 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2031
  %2047 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2031
  %2048 = load <8 x i1>, ptr %2046, align 1
  %2049 = load <8 x i1>, ptr %2047, align 1
  %2050 = select i1 %2024, <8 x i1> %convergence.cascade.result483, <8 x i1> %2048
  store <8 x i1> %2050, ptr %2046, align 1
  %2051 = select i1 %2024, <8 x i1> zeroinitializer, <8 x i1> %2049
  store <8 x i1> %2051, ptr %2047, align 1
  %2052 = add i32 %2031, 1
  %2053 = select i1 %2022, i32 %2009, i32 %2052
  %2054 = select i1 true, i32 %2053, i32 %2009
  store i32 %2054, ptr %current.token, align 4
  %2055 = load i32, ptr %current.token, align 4
  %2056 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2003)
  %2057 = load i32, ptr %ready.count, align 4
  %2058 = icmp uge i32 %2057, 8
  %2059 = and i1 %2056, %2058
  br i1 %2059, label %ready.overflow.trap506, label %ready.overflow.resume507

ready.overflow.trap506:                           ; preds = %convergence.overflow.resume505
  call void @llvm.trap()
  unreachable

ready.overflow.resume507:                         ; preds = %convergence.overflow.resume505
  %2060 = select i1 %2056, i32 %2057, i32 0
  %2061 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2060
  %2062 = load <8 x i1>, ptr %2061, align 1
  %2063 = select i1 %2056, <8 x i1> %2003, <8 x i1> %2062
  store <8 x i1> %2063, ptr %2061, align 1
  %2064 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2060
  %2065 = load i32, ptr %2064, align 4
  %2066 = select i1 %2056, i32 18, i32 %2065
  store i32 %2066, ptr %2064, align 4
  %2067 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2060
  %2068 = load i32, ptr %2067, align 4
  %2069 = select i1 %2056, i32 %2055, i32 %2068
  store i32 %2069, ptr %2067, align 4
  %2070 = add i32 %2057, 1
  %2071 = select i1 %2056, i32 %2070, i32 %2057
  store i32 %2071, ptr %ready.count, align 4
  %2072 = load <8 x i1>, ptr %runnable.mask, align 1
  %2073 = or <8 x i1> %2072, %2003
  store <8 x i1> %2073, ptr %runnable.mask, align 1
  store <8 x i1> %2005, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true508:                         ; preds = %varying.coherent503
  store <8 x i1> %convergence.cascade.result483, ptr %current.mask, align 1
  %2074 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result483)
  br i1 %2074, label %schedule.18, label %scheduler.loop

varying.coherent.false509:                        ; preds = %varying.coherent503
  store <8 x i1> %convergence.cascade.result483, ptr %current.mask, align 1
  %2075 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result483)
  br i1 %2075, label %schedule.19, label %scheduler.loop

convergence.cascade512:                           ; preds = %convergence.cascade512, %schedule.19
  %convergence.cascade.flow516 = phi <8 x i1> [ %708, %schedule.19 ], [ %2118, %convergence.cascade512 ]
  %convergence.cascade.depth517 = phi i32 [ 0, %schedule.19 ], [ %2119, %convergence.cascade512 ]
  %2076 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow516)
  %2077 = load i32, ptr %current.token, align 4
  %2078 = icmp ne i32 %2077, 0
  %2079 = and i1 %2076, %2078
  %2080 = sub i32 %2077, 1
  %2081 = select i1 %2079, i32 %2080, i32 0
  %2082 = load i8, ptr %frame.active, align 1
  %2083 = trunc i32 %2081 to i8
  %2084 = shl i8 1, %2083
  %2085 = and i8 %2082, %2084
  %2086 = icmp ne i8 %2085, 0
  %2087 = load <8 x i32>, ptr %frame.static.id, align 32
  %2088 = extractelement <8 x i32> %2087, i32 %2081
  %convergence.target.pointer518 = getelementptr inbounds [9 x i32], ptr @convergence.targets, i32 0, i32 %2088
  %convergence.dynamic.target519 = load i32, ptr %convergence.target.pointer518, align 4
  %2089 = icmp eq i32 %convergence.dynamic.target519, 19
  %2090 = and i1 %2086, %2089
  %2091 = and i1 %2079, %2090
  %2092 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2081
  %2093 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2081
  %2094 = load <8 x i1>, ptr %2092, align 1
  %2095 = load <8 x i1>, ptr %2093, align 1
  %2096 = or <8 x i1> %2095, %convergence.cascade.flow516
  %2097 = load <8 x i1>, ptr %live.mask, align 1
  %2098 = and <8 x i1> %2094, %2097
  %2099 = icmp eq <8 x i1> %2096, %2098
  %2100 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2099)
  %2101 = and i1 %2091, %2100
  %2102 = select i1 %2101, <8 x i1> zeroinitializer, <8 x i1> %2096
  %2103 = select i1 %2091, <8 x i1> %2102, <8 x i1> %2095
  store <8 x i1> %2103, ptr %2093, align 1
  %2104 = select i1 %2101, <8 x i1> zeroinitializer, <8 x i1> %2094
  store <8 x i1> %2104, ptr %2092, align 1
  %2105 = trunc i32 %2081 to i8
  %2106 = shl i8 1, %2105
  %2107 = xor i8 %2106, -1
  %2108 = and i8 %2082, %2107
  %2109 = select i1 %2101, i8 %2108, i8 %2082
  store i8 %2109, ptr %frame.active, align 1
  %.splatinsert520 = insertelement <8 x i1> poison, i1 %2091, i64 0
  %.splat521 = shufflevector <8 x i1> %.splatinsert520, <8 x i1> poison, <8 x i32> zeroinitializer
  %2110 = and <8 x i1> %convergence.cascade.flow516, %.splat521
  %2111 = load <8 x i1>, ptr %runnable.mask, align 1
  %2112 = xor <8 x i1> %2110, splat (i1 true)
  %2113 = and <8 x i1> %2111, %2112
  store <8 x i1> %2113, ptr %runnable.mask, align 1
  %.splatinsert522 = insertelement <8 x i1> poison, i1 %2101, i64 0
  %.splat523 = shufflevector <8 x i1> %.splatinsert522, <8 x i1> poison, <8 x i32> zeroinitializer
  %2114 = select <8 x i1> %.splat523, <8 x i1> %2096, <8 x i1> zeroinitializer
  %2115 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2116 = extractelement <8 x i32> %2115, i32 %2081
  %2117 = select i1 %2101, i32 %2116, i32 %2077
  store i32 %2117, ptr %current.token, align 4
  %.splatinsert524 = insertelement <8 x i1> poison, i1 %2091, i64 0
  %.splat525 = shufflevector <8 x i1> %.splatinsert524, <8 x i1> poison, <8 x i32> zeroinitializer
  %2118 = select <8 x i1> %.splat525, <8 x i1> %2114, <8 x i1> %convergence.cascade.flow516
  %2119 = add i32 %convergence.cascade.depth517, 1
  %2120 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2118)
  %2121 = icmp ult i32 %2119, 8
  %2122 = and i1 %2120, %2121
  %2123 = and i1 %2091, %2122
  %convergence.parent.token526 = load i32, ptr %current.token, align 4
  %convergence.parent.present527 = icmp ne i32 %convergence.parent.token526, 0
  %2124 = and i1 %2123, %convergence.parent.present527
  br i1 %2124, label %convergence.cascade512, label %convergence.cascade.exit513

convergence.cascade.exit513:                      ; preds = %convergence.cascade512, %schedule.19
  %convergence.cascade.result528 = phi <8 x i1> [ %708, %schedule.19 ], [ %2118, %convergence.cascade512 ]
  %2125 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result528)
  br i1 %2125, label %convergence.target.19.ready, label %scheduler.loop

convergence.target.19.ready:                      ; preds = %convergence.cascade.exit513
  %2126 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result528)
  %2127 = bitcast <8 x i1> %convergence.cascade.result528 to i8
  %2128 = call i8 @llvm.cttz.i8(i8 %2127, i1 false)
  %2129 = zext i8 %2128 to i32
  %2130 = select i1 %2126, i32 %2129, i32 0
  %.spill.load529 = load <8 x i64>, ptr %.spill, align 64
  %2131 = add <8 x i64> %.spill.load529, splat (i64 2)
  %.spill.load530 = load i64, ptr %.spill38, align 4
  %.splatinsert531 = insertelement <8 x i64> poison, i64 %.spill.load530, i64 0
  %.splat532 = shufflevector <8 x i64> %.splatinsert531, <8 x i64> poison, <8 x i32> zeroinitializer
  %2132 = add <8 x i64> %.splat532, %2131
  %2133 = icmp sge <8 x i64> %2131, zeroinitializer
  %2134 = and <8 x i1> splat (i1 true), %2133
  %2135 = icmp slt <8 x i64> %2131, splat (i64 17)
  %2136 = and <8 x i1> %2134, %2135
  %2137 = load <8 x i64>, ptr %.spill40, align 64
  %2138 = select <8 x i1> %convergence.cascade.result528, <8 x i64> %2132, <8 x i64> %2137
  store <8 x i64> %2138, ptr %.spill40, align 64
  %2139 = and <8 x i1> %convergence.cascade.result528, %2136
  %2140 = xor <8 x i1> %2136, splat (i1 true)
  %2141 = and <8 x i1> %convergence.cascade.result528, %2140
  %2142 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2139)
  %2143 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2141)
  %2144 = and i1 %2142, %2143
  br i1 %2144, label %varying.divergent533, label %varying.coherent534

varying.divergent533:                             ; preds = %convergence.target.19.ready
  %2145 = load i32, ptr %current.token, align 4
  %2146 = icmp ne i32 %2145, 0
  %2147 = sub i32 %2145, 1
  %2148 = select i1 %2146, i32 %2147, i32 0
  %2149 = load i8, ptr %frame.active, align 1
  %2150 = trunc i32 %2148 to i8
  %2151 = shl i8 1, %2150
  %2152 = and i8 %2149, %2151
  %2153 = icmp ne i8 %2152, 0
  %2154 = load <8 x i32>, ptr %frame.static.id, align 32
  %2155 = extractelement <8 x i32> %2154, i32 %2148
  %2156 = icmp eq i32 %2155, 7
  %2157 = and i1 %2153, %2156
  %2158 = and i1 %2146, %2157
  %2159 = xor i1 %2158, true
  %2160 = and i1 true, %2159
  %2161 = xor i8 %2149, -1
  %2162 = icmp ne i8 %2161, 0
  %2163 = xor i1 %2162, true
  %2164 = and i1 %2160, %2163
  br i1 %2164, label %convergence.overflow.trap535, label %convergence.overflow.resume536

varying.coherent534:                              ; preds = %convergence.target.19.ready
  br i1 %2142, label %varying.coherent.true539, label %varying.coherent.false540

convergence.overflow.trap535:                     ; preds = %varying.divergent533
  call void @llvm.trap()
  unreachable

convergence.overflow.resume536:                   ; preds = %varying.divergent533
  %2165 = call i8 @llvm.cttz.i8(i8 %2161, i1 false)
  %2166 = zext i8 %2165 to i32
  %2167 = select i1 %2162, i32 %2166, i32 0
  %2168 = trunc i32 %2167 to i8
  %2169 = shl i8 1, %2168
  %2170 = or i8 %2149, %2169
  %2171 = select i1 %2160, i8 %2170, i8 %2149
  store i8 %2171, ptr %frame.active, align 1
  %2172 = load <8 x i32>, ptr %frame.static.id, align 32
  %2173 = extractelement <8 x i32> %2172, i32 %2167
  %2174 = select i1 %2160, i32 7, i32 %2173
  %2175 = load <8 x i32>, ptr %frame.static.id, align 32
  %2176 = insertelement <8 x i32> %2175, i32 %2174, i32 %2167
  store <8 x i32> %2176, ptr %frame.static.id, align 32
  %2177 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2178 = extractelement <8 x i32> %2177, i32 %2167
  %2179 = select i1 %2160, i32 %2145, i32 %2178
  %2180 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2181 = insertelement <8 x i32> %2180, i32 %2179, i32 %2167
  store <8 x i32> %2181, ptr %frame.parent.token, align 32
  %2182 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2167
  %2183 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2167
  %2184 = load <8 x i1>, ptr %2182, align 1
  %2185 = load <8 x i1>, ptr %2183, align 1
  %2186 = select i1 %2160, <8 x i1> %convergence.cascade.result528, <8 x i1> %2184
  store <8 x i1> %2186, ptr %2182, align 1
  %2187 = select i1 %2160, <8 x i1> zeroinitializer, <8 x i1> %2185
  store <8 x i1> %2187, ptr %2183, align 1
  %2188 = add i32 %2167, 1
  %2189 = select i1 %2158, i32 %2145, i32 %2188
  %2190 = select i1 true, i32 %2189, i32 %2145
  store i32 %2190, ptr %current.token, align 4
  %2191 = load i32, ptr %current.token, align 4
  %2192 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2139)
  %2193 = load i32, ptr %ready.count, align 4
  %2194 = icmp uge i32 %2193, 8
  %2195 = and i1 %2192, %2194
  br i1 %2195, label %ready.overflow.trap537, label %ready.overflow.resume538

ready.overflow.trap537:                           ; preds = %convergence.overflow.resume536
  call void @llvm.trap()
  unreachable

ready.overflow.resume538:                         ; preds = %convergence.overflow.resume536
  %2196 = select i1 %2192, i32 %2193, i32 0
  %2197 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2196
  %2198 = load <8 x i1>, ptr %2197, align 1
  %2199 = select i1 %2192, <8 x i1> %2139, <8 x i1> %2198
  store <8 x i1> %2199, ptr %2197, align 1
  %2200 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2196
  %2201 = load i32, ptr %2200, align 4
  %2202 = select i1 %2192, i32 20, i32 %2201
  store i32 %2202, ptr %2200, align 4
  %2203 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2196
  %2204 = load i32, ptr %2203, align 4
  %2205 = select i1 %2192, i32 %2191, i32 %2204
  store i32 %2205, ptr %2203, align 4
  %2206 = add i32 %2193, 1
  %2207 = select i1 %2192, i32 %2206, i32 %2193
  store i32 %2207, ptr %ready.count, align 4
  %2208 = load <8 x i1>, ptr %runnable.mask, align 1
  %2209 = or <8 x i1> %2208, %2139
  store <8 x i1> %2209, ptr %runnable.mask, align 1
  store <8 x i1> %2141, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true539:                         ; preds = %varying.coherent534
  store <8 x i1> %convergence.cascade.result528, ptr %current.mask, align 1
  %2210 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result528)
  br i1 %2210, label %schedule.20, label %scheduler.loop

varying.coherent.false540:                        ; preds = %varying.coherent534
  store <8 x i1> %convergence.cascade.result528, ptr %current.mask, align 1
  %2211 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result528)
  br i1 %2211, label %schedule.21, label %scheduler.loop

convergence.cascade543:                           ; preds = %convergence.cascade543, %schedule.21
  %convergence.cascade.flow547 = phi <8 x i1> [ %719, %schedule.21 ], [ %2254, %convergence.cascade543 ]
  %convergence.cascade.depth548 = phi i32 [ 0, %schedule.21 ], [ %2255, %convergence.cascade543 ]
  %2212 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow547)
  %2213 = load i32, ptr %current.token, align 4
  %2214 = icmp ne i32 %2213, 0
  %2215 = and i1 %2212, %2214
  %2216 = sub i32 %2213, 1
  %2217 = select i1 %2215, i32 %2216, i32 0
  %2218 = load i8, ptr %frame.active, align 1
  %2219 = trunc i32 %2217 to i8
  %2220 = shl i8 1, %2219
  %2221 = and i8 %2218, %2220
  %2222 = icmp ne i8 %2221, 0
  %2223 = load <8 x i32>, ptr %frame.static.id, align 32
  %2224 = extractelement <8 x i32> %2223, i32 %2217
  %convergence.target.pointer549 = getelementptr inbounds [9 x i32], ptr @convergence.targets, i32 0, i32 %2224
  %convergence.dynamic.target550 = load i32, ptr %convergence.target.pointer549, align 4
  %2225 = icmp eq i32 %convergence.dynamic.target550, 21
  %2226 = and i1 %2222, %2225
  %2227 = and i1 %2215, %2226
  %2228 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2217
  %2229 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2217
  %2230 = load <8 x i1>, ptr %2228, align 1
  %2231 = load <8 x i1>, ptr %2229, align 1
  %2232 = or <8 x i1> %2231, %convergence.cascade.flow547
  %2233 = load <8 x i1>, ptr %live.mask, align 1
  %2234 = and <8 x i1> %2230, %2233
  %2235 = icmp eq <8 x i1> %2232, %2234
  %2236 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2235)
  %2237 = and i1 %2227, %2236
  %2238 = select i1 %2237, <8 x i1> zeroinitializer, <8 x i1> %2232
  %2239 = select i1 %2227, <8 x i1> %2238, <8 x i1> %2231
  store <8 x i1> %2239, ptr %2229, align 1
  %2240 = select i1 %2237, <8 x i1> zeroinitializer, <8 x i1> %2230
  store <8 x i1> %2240, ptr %2228, align 1
  %2241 = trunc i32 %2217 to i8
  %2242 = shl i8 1, %2241
  %2243 = xor i8 %2242, -1
  %2244 = and i8 %2218, %2243
  %2245 = select i1 %2237, i8 %2244, i8 %2218
  store i8 %2245, ptr %frame.active, align 1
  %.splatinsert551 = insertelement <8 x i1> poison, i1 %2227, i64 0
  %.splat552 = shufflevector <8 x i1> %.splatinsert551, <8 x i1> poison, <8 x i32> zeroinitializer
  %2246 = and <8 x i1> %convergence.cascade.flow547, %.splat552
  %2247 = load <8 x i1>, ptr %runnable.mask, align 1
  %2248 = xor <8 x i1> %2246, splat (i1 true)
  %2249 = and <8 x i1> %2247, %2248
  store <8 x i1> %2249, ptr %runnable.mask, align 1
  %.splatinsert553 = insertelement <8 x i1> poison, i1 %2237, i64 0
  %.splat554 = shufflevector <8 x i1> %.splatinsert553, <8 x i1> poison, <8 x i32> zeroinitializer
  %2250 = select <8 x i1> %.splat554, <8 x i1> %2232, <8 x i1> zeroinitializer
  %2251 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2252 = extractelement <8 x i32> %2251, i32 %2217
  %2253 = select i1 %2237, i32 %2252, i32 %2213
  store i32 %2253, ptr %current.token, align 4
  %.splatinsert555 = insertelement <8 x i1> poison, i1 %2227, i64 0
  %.splat556 = shufflevector <8 x i1> %.splatinsert555, <8 x i1> poison, <8 x i32> zeroinitializer
  %2254 = select <8 x i1> %.splat556, <8 x i1> %2250, <8 x i1> %convergence.cascade.flow547
  %2255 = add i32 %convergence.cascade.depth548, 1
  %2256 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2254)
  %2257 = icmp ult i32 %2255, 8
  %2258 = and i1 %2256, %2257
  %2259 = and i1 %2227, %2258
  %convergence.parent.token557 = load i32, ptr %current.token, align 4
  %convergence.parent.present558 = icmp ne i32 %convergence.parent.token557, 0
  %2260 = and i1 %2259, %convergence.parent.present558
  br i1 %2260, label %convergence.cascade543, label %convergence.cascade.exit544

convergence.cascade.exit544:                      ; preds = %convergence.cascade543, %schedule.21
  %convergence.cascade.result559 = phi <8 x i1> [ %719, %schedule.21 ], [ %2254, %convergence.cascade543 ]
  %2261 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result559)
  br i1 %2261, label %convergence.target.21.ready, label %scheduler.loop

convergence.target.21.ready:                      ; preds = %convergence.cascade.exit544
  %2262 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result559)
  %2263 = bitcast <8 x i1> %convergence.cascade.result559 to i8
  %2264 = call i8 @llvm.cttz.i8(i8 %2263, i1 false)
  %2265 = zext i8 %2264 to i32
  %2266 = select i1 %2262, i32 %2265, i32 0
  %.spill.load560 = load <8 x i64>, ptr %.spill, align 64
  %2267 = add <8 x i64> %.spill.load560, splat (i64 3)
  %.spill.load561 = load i64, ptr %.spill38, align 4
  %.splatinsert562 = insertelement <8 x i64> poison, i64 %.spill.load561, i64 0
  %.splat563 = shufflevector <8 x i64> %.splatinsert562, <8 x i64> poison, <8 x i32> zeroinitializer
  %2268 = add <8 x i64> %.splat563, %2267
  %2269 = icmp sge <8 x i64> %2267, zeroinitializer
  %2270 = and <8 x i1> splat (i1 true), %2269
  %2271 = icmp slt <8 x i64> %2267, splat (i64 17)
  %2272 = and <8 x i1> %2270, %2271
  %2273 = load <8 x i64>, ptr %.spill41, align 64
  %2274 = select <8 x i1> %convergence.cascade.result559, <8 x i64> %2268, <8 x i64> %2273
  store <8 x i64> %2274, ptr %.spill41, align 64
  %2275 = and <8 x i1> %convergence.cascade.result559, %2272
  %2276 = xor <8 x i1> %2272, splat (i1 true)
  %2277 = and <8 x i1> %convergence.cascade.result559, %2276
  %2278 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2275)
  %2279 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2277)
  %2280 = and i1 %2278, %2279
  br i1 %2280, label %varying.divergent564, label %varying.coherent565

varying.divergent564:                             ; preds = %convergence.target.21.ready
  %2281 = load i32, ptr %current.token, align 4
  %2282 = icmp ne i32 %2281, 0
  %2283 = sub i32 %2281, 1
  %2284 = select i1 %2282, i32 %2283, i32 0
  %2285 = load i8, ptr %frame.active, align 1
  %2286 = trunc i32 %2284 to i8
  %2287 = shl i8 1, %2286
  %2288 = and i8 %2285, %2287
  %2289 = icmp ne i8 %2288, 0
  %2290 = load <8 x i32>, ptr %frame.static.id, align 32
  %2291 = extractelement <8 x i32> %2290, i32 %2284
  %2292 = icmp eq i32 %2291, 8
  %2293 = and i1 %2289, %2292
  %2294 = and i1 %2282, %2293
  %2295 = xor i1 %2294, true
  %2296 = and i1 true, %2295
  %2297 = xor i8 %2285, -1
  %2298 = icmp ne i8 %2297, 0
  %2299 = xor i1 %2298, true
  %2300 = and i1 %2296, %2299
  br i1 %2300, label %convergence.overflow.trap566, label %convergence.overflow.resume567

varying.coherent565:                              ; preds = %convergence.target.21.ready
  br i1 %2278, label %varying.coherent.true570, label %varying.coherent.false571

convergence.overflow.trap566:                     ; preds = %varying.divergent564
  call void @llvm.trap()
  unreachable

convergence.overflow.resume567:                   ; preds = %varying.divergent564
  %2301 = call i8 @llvm.cttz.i8(i8 %2297, i1 false)
  %2302 = zext i8 %2301 to i32
  %2303 = select i1 %2298, i32 %2302, i32 0
  %2304 = trunc i32 %2303 to i8
  %2305 = shl i8 1, %2304
  %2306 = or i8 %2285, %2305
  %2307 = select i1 %2296, i8 %2306, i8 %2285
  store i8 %2307, ptr %frame.active, align 1
  %2308 = load <8 x i32>, ptr %frame.static.id, align 32
  %2309 = extractelement <8 x i32> %2308, i32 %2303
  %2310 = select i1 %2296, i32 8, i32 %2309
  %2311 = load <8 x i32>, ptr %frame.static.id, align 32
  %2312 = insertelement <8 x i32> %2311, i32 %2310, i32 %2303
  store <8 x i32> %2312, ptr %frame.static.id, align 32
  %2313 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2314 = extractelement <8 x i32> %2313, i32 %2303
  %2315 = select i1 %2296, i32 %2281, i32 %2314
  %2316 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2317 = insertelement <8 x i32> %2316, i32 %2315, i32 %2303
  store <8 x i32> %2317, ptr %frame.parent.token, align 32
  %2318 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2303
  %2319 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2303
  %2320 = load <8 x i1>, ptr %2318, align 1
  %2321 = load <8 x i1>, ptr %2319, align 1
  %2322 = select i1 %2296, <8 x i1> %convergence.cascade.result559, <8 x i1> %2320
  store <8 x i1> %2322, ptr %2318, align 1
  %2323 = select i1 %2296, <8 x i1> zeroinitializer, <8 x i1> %2321
  store <8 x i1> %2323, ptr %2319, align 1
  %2324 = add i32 %2303, 1
  %2325 = select i1 %2294, i32 %2281, i32 %2324
  %2326 = select i1 true, i32 %2325, i32 %2281
  store i32 %2326, ptr %current.token, align 4
  %2327 = load i32, ptr %current.token, align 4
  %2328 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2275)
  %2329 = load i32, ptr %ready.count, align 4
  %2330 = icmp uge i32 %2329, 8
  %2331 = and i1 %2328, %2330
  br i1 %2331, label %ready.overflow.trap568, label %ready.overflow.resume569

ready.overflow.trap568:                           ; preds = %convergence.overflow.resume567
  call void @llvm.trap()
  unreachable

ready.overflow.resume569:                         ; preds = %convergence.overflow.resume567
  %2332 = select i1 %2328, i32 %2329, i32 0
  %2333 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2332
  %2334 = load <8 x i1>, ptr %2333, align 1
  %2335 = select i1 %2328, <8 x i1> %2275, <8 x i1> %2334
  store <8 x i1> %2335, ptr %2333, align 1
  %2336 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2332
  %2337 = load i32, ptr %2336, align 4
  %2338 = select i1 %2328, i32 22, i32 %2337
  store i32 %2338, ptr %2336, align 4
  %2339 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2332
  %2340 = load i32, ptr %2339, align 4
  %2341 = select i1 %2328, i32 %2327, i32 %2340
  store i32 %2341, ptr %2339, align 4
  %2342 = add i32 %2329, 1
  %2343 = select i1 %2328, i32 %2342, i32 %2329
  store i32 %2343, ptr %ready.count, align 4
  %2344 = load <8 x i1>, ptr %runnable.mask, align 1
  %2345 = or <8 x i1> %2344, %2275
  store <8 x i1> %2345, ptr %runnable.mask, align 1
  store <8 x i1> %2277, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true570:                         ; preds = %varying.coherent565
  store <8 x i1> %convergence.cascade.result559, ptr %current.mask, align 1
  %2346 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result559)
  br i1 %2346, label %schedule.22, label %scheduler.loop

varying.coherent.false571:                        ; preds = %varying.coherent565
  store <8 x i1> %convergence.cascade.result559, ptr %current.mask, align 1
  %2347 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result559)
  br i1 %2347, label %schedule.23, label %scheduler.loop

convergence.cascade574:                           ; preds = %convergence.cascade574, %schedule.23
  %convergence.cascade.flow578 = phi <8 x i1> [ %730, %schedule.23 ], [ %2390, %convergence.cascade574 ]
  %convergence.cascade.depth579 = phi i32 [ 0, %schedule.23 ], [ %2391, %convergence.cascade574 ]
  %2348 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow578)
  %2349 = load i32, ptr %current.token, align 4
  %2350 = icmp ne i32 %2349, 0
  %2351 = and i1 %2348, %2350
  %2352 = sub i32 %2349, 1
  %2353 = select i1 %2351, i32 %2352, i32 0
  %2354 = load i8, ptr %frame.active, align 1
  %2355 = trunc i32 %2353 to i8
  %2356 = shl i8 1, %2355
  %2357 = and i8 %2354, %2356
  %2358 = icmp ne i8 %2357, 0
  %2359 = load <8 x i32>, ptr %frame.static.id, align 32
  %2360 = extractelement <8 x i32> %2359, i32 %2353
  %convergence.target.pointer580 = getelementptr inbounds [9 x i32], ptr @convergence.targets, i32 0, i32 %2360
  %convergence.dynamic.target581 = load i32, ptr %convergence.target.pointer580, align 4
  %2361 = icmp eq i32 %convergence.dynamic.target581, 23
  %2362 = and i1 %2358, %2361
  %2363 = and i1 %2351, %2362
  %2364 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2353
  %2365 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2353
  %2366 = load <8 x i1>, ptr %2364, align 1
  %2367 = load <8 x i1>, ptr %2365, align 1
  %2368 = or <8 x i1> %2367, %convergence.cascade.flow578
  %2369 = load <8 x i1>, ptr %live.mask, align 1
  %2370 = and <8 x i1> %2366, %2369
  %2371 = icmp eq <8 x i1> %2368, %2370
  %2372 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2371)
  %2373 = and i1 %2363, %2372
  %2374 = select i1 %2373, <8 x i1> zeroinitializer, <8 x i1> %2368
  %2375 = select i1 %2363, <8 x i1> %2374, <8 x i1> %2367
  store <8 x i1> %2375, ptr %2365, align 1
  %2376 = select i1 %2373, <8 x i1> zeroinitializer, <8 x i1> %2366
  store <8 x i1> %2376, ptr %2364, align 1
  %2377 = trunc i32 %2353 to i8
  %2378 = shl i8 1, %2377
  %2379 = xor i8 %2378, -1
  %2380 = and i8 %2354, %2379
  %2381 = select i1 %2373, i8 %2380, i8 %2354
  store i8 %2381, ptr %frame.active, align 1
  %.splatinsert582 = insertelement <8 x i1> poison, i1 %2363, i64 0
  %.splat583 = shufflevector <8 x i1> %.splatinsert582, <8 x i1> poison, <8 x i32> zeroinitializer
  %2382 = and <8 x i1> %convergence.cascade.flow578, %.splat583
  %2383 = load <8 x i1>, ptr %runnable.mask, align 1
  %2384 = xor <8 x i1> %2382, splat (i1 true)
  %2385 = and <8 x i1> %2383, %2384
  store <8 x i1> %2385, ptr %runnable.mask, align 1
  %.splatinsert584 = insertelement <8 x i1> poison, i1 %2373, i64 0
  %.splat585 = shufflevector <8 x i1> %.splatinsert584, <8 x i1> poison, <8 x i32> zeroinitializer
  %2386 = select <8 x i1> %.splat585, <8 x i1> %2368, <8 x i1> zeroinitializer
  %2387 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2388 = extractelement <8 x i32> %2387, i32 %2353
  %2389 = select i1 %2373, i32 %2388, i32 %2349
  store i32 %2389, ptr %current.token, align 4
  %.splatinsert586 = insertelement <8 x i1> poison, i1 %2363, i64 0
  %.splat587 = shufflevector <8 x i1> %.splatinsert586, <8 x i1> poison, <8 x i32> zeroinitializer
  %2390 = select <8 x i1> %.splat587, <8 x i1> %2386, <8 x i1> %convergence.cascade.flow578
  %2391 = add i32 %convergence.cascade.depth579, 1
  %2392 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2390)
  %2393 = icmp ult i32 %2391, 8
  %2394 = and i1 %2392, %2393
  %2395 = and i1 %2363, %2394
  %convergence.parent.token588 = load i32, ptr %current.token, align 4
  %convergence.parent.present589 = icmp ne i32 %convergence.parent.token588, 0
  %2396 = and i1 %2395, %convergence.parent.present589
  br i1 %2396, label %convergence.cascade574, label %convergence.cascade.exit575

convergence.cascade.exit575:                      ; preds = %convergence.cascade574, %schedule.23
  %convergence.cascade.result590 = phi <8 x i1> [ %730, %schedule.23 ], [ %2390, %convergence.cascade574 ]
  %2397 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result590)
  br i1 %2397, label %convergence.target.23.ready, label %scheduler.loop

convergence.target.23.ready:                      ; preds = %convergence.cascade.exit575
  %2398 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result590)
  %2399 = bitcast <8 x i1> %convergence.cascade.result590 to i8
  %2400 = call i8 @llvm.cttz.i8(i8 %2399, i1 false)
  %2401 = zext i8 %2400 to i32
  %2402 = select i1 %2398, i32 %2401, i32 0
  %2403 = load <8 x i1>, ptr %live.mask, align 1
  %2404 = xor <8 x i1> %convergence.cascade.result590, splat (i1 true)
  %2405 = and <8 x i1> %2403, %2404
  store <8 x i1> %2405, ptr %live.mask, align 1
  %2406 = load <8 x i1>, ptr %runnable.mask, align 1
  %2407 = xor <8 x i1> %convergence.cascade.result590, splat (i1 true)
  %2408 = and <8 x i1> %2406, %2407
  store <8 x i1> %2408, ptr %runnable.mask, align 1
  %return.active.frames = load i8, ptr %frame.active, align 1
  %return.frames.present = icmp ne i8 %return.active.frames, 0
  br i1 %return.frames.present, label %return.frame.cleanup, label %return.frame.cleanup.done

return.frame.cleanup:                             ; preds = %convergence.target.23.ready
  %2409 = load i8, ptr %frame.active, align 1
  %2410 = and i8 %2409, 1
  %2411 = icmp ne i8 %2410, 0
  %2412 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 0
  %2413 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 0
  %2414 = load <8 x i1>, ptr %2412, align 1
  %2415 = load <8 x i1>, ptr %2413, align 1
  %2416 = and <8 x i1> %2414, %2405
  %2417 = icmp eq <8 x i1> %2415, %2416
  %2418 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2417)
  %2419 = and i1 %2411, %2418
  %.splatinsert591 = insertelement <8 x i1> poison, i1 %2419, i64 0
  %.splat592 = shufflevector <8 x i1> %.splatinsert591, <8 x i1> poison, <8 x i32> zeroinitializer
  %2420 = select <8 x i1> %.splat592, <8 x i1> %2415, <8 x i1> zeroinitializer
  %2421 = select i1 %2419, <8 x i1> zeroinitializer, <8 x i1> %2416
  store <8 x i1> %2421, ptr %2412, align 1
  %2422 = select i1 %2419, <8 x i1> zeroinitializer, <8 x i1> %2415
  store <8 x i1> %2422, ptr %2413, align 1
  %2423 = and i8 %2409, -2
  %2424 = select i1 %2419, i8 %2423, i8 %2409
  store i8 %2424, ptr %frame.active, align 1
  %2425 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2426 = extractelement <8 x i32> %2425, i32 0
  %2427 = load <8 x i32>, ptr %frame.static.id, align 32
  %2428 = extractelement <8 x i32> %2427, i32 0
  %convergence.target.pointer593 = getelementptr inbounds [9 x i32], ptr @convergence.targets, i32 0, i32 %2428
  %convergence.dynamic.target594 = load i32, ptr %convergence.target.pointer593, align 4
  %2429 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2420)
  %2430 = load i32, ptr %ready.count, align 4
  %2431 = icmp uge i32 %2430, 8
  %2432 = and i1 %2429, %2431
  br i1 %2432, label %ready.overflow.trap595, label %ready.overflow.resume596

return.frame.cleanup.done:                        ; preds = %ready.overflow.resume638, %convergence.target.23.ready
  br label %scheduler.loop

ready.overflow.trap595:                           ; preds = %return.frame.cleanup
  call void @llvm.trap()
  unreachable

ready.overflow.resume596:                         ; preds = %return.frame.cleanup
  %2433 = select i1 %2429, i32 %2430, i32 0
  %2434 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2433
  %2435 = load <8 x i1>, ptr %2434, align 1
  %2436 = select i1 %2429, <8 x i1> %2420, <8 x i1> %2435
  store <8 x i1> %2436, ptr %2434, align 1
  %2437 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2433
  %2438 = load i32, ptr %2437, align 4
  %2439 = select i1 %2429, i32 %convergence.dynamic.target594, i32 %2438
  store i32 %2439, ptr %2437, align 4
  %2440 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2433
  %2441 = load i32, ptr %2440, align 4
  %2442 = select i1 %2429, i32 %2426, i32 %2441
  store i32 %2442, ptr %2440, align 4
  %2443 = add i32 %2430, 1
  %2444 = select i1 %2429, i32 %2443, i32 %2430
  store i32 %2444, ptr %ready.count, align 4
  %2445 = load <8 x i1>, ptr %runnable.mask, align 1
  %2446 = or <8 x i1> %2445, %2420
  store <8 x i1> %2446, ptr %runnable.mask, align 1
  %2447 = load i8, ptr %frame.active, align 1
  %2448 = and i8 %2447, 2
  %2449 = icmp ne i8 %2448, 0
  %2450 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 1
  %2451 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 1
  %2452 = load <8 x i1>, ptr %2450, align 1
  %2453 = load <8 x i1>, ptr %2451, align 1
  %2454 = and <8 x i1> %2452, %2405
  %2455 = icmp eq <8 x i1> %2453, %2454
  %2456 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2455)
  %2457 = and i1 %2449, %2456
  %.splatinsert597 = insertelement <8 x i1> poison, i1 %2457, i64 0
  %.splat598 = shufflevector <8 x i1> %.splatinsert597, <8 x i1> poison, <8 x i32> zeroinitializer
  %2458 = select <8 x i1> %.splat598, <8 x i1> %2453, <8 x i1> zeroinitializer
  %2459 = select i1 %2457, <8 x i1> zeroinitializer, <8 x i1> %2454
  store <8 x i1> %2459, ptr %2450, align 1
  %2460 = select i1 %2457, <8 x i1> zeroinitializer, <8 x i1> %2453
  store <8 x i1> %2460, ptr %2451, align 1
  %2461 = and i8 %2447, -3
  %2462 = select i1 %2457, i8 %2461, i8 %2447
  store i8 %2462, ptr %frame.active, align 1
  %2463 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2464 = extractelement <8 x i32> %2463, i32 1
  %2465 = load <8 x i32>, ptr %frame.static.id, align 32
  %2466 = extractelement <8 x i32> %2465, i32 1
  %convergence.target.pointer599 = getelementptr inbounds [9 x i32], ptr @convergence.targets, i32 0, i32 %2466
  %convergence.dynamic.target600 = load i32, ptr %convergence.target.pointer599, align 4
  %2467 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2458)
  %2468 = load i32, ptr %ready.count, align 4
  %2469 = icmp uge i32 %2468, 8
  %2470 = and i1 %2467, %2469
  br i1 %2470, label %ready.overflow.trap601, label %ready.overflow.resume602

ready.overflow.trap601:                           ; preds = %ready.overflow.resume596
  call void @llvm.trap()
  unreachable

ready.overflow.resume602:                         ; preds = %ready.overflow.resume596
  %2471 = select i1 %2467, i32 %2468, i32 0
  %2472 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2471
  %2473 = load <8 x i1>, ptr %2472, align 1
  %2474 = select i1 %2467, <8 x i1> %2458, <8 x i1> %2473
  store <8 x i1> %2474, ptr %2472, align 1
  %2475 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2471
  %2476 = load i32, ptr %2475, align 4
  %2477 = select i1 %2467, i32 %convergence.dynamic.target600, i32 %2476
  store i32 %2477, ptr %2475, align 4
  %2478 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2471
  %2479 = load i32, ptr %2478, align 4
  %2480 = select i1 %2467, i32 %2464, i32 %2479
  store i32 %2480, ptr %2478, align 4
  %2481 = add i32 %2468, 1
  %2482 = select i1 %2467, i32 %2481, i32 %2468
  store i32 %2482, ptr %ready.count, align 4
  %2483 = load <8 x i1>, ptr %runnable.mask, align 1
  %2484 = or <8 x i1> %2483, %2458
  store <8 x i1> %2484, ptr %runnable.mask, align 1
  %2485 = load i8, ptr %frame.active, align 1
  %2486 = and i8 %2485, 4
  %2487 = icmp ne i8 %2486, 0
  %2488 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 2
  %2489 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 2
  %2490 = load <8 x i1>, ptr %2488, align 1
  %2491 = load <8 x i1>, ptr %2489, align 1
  %2492 = and <8 x i1> %2490, %2405
  %2493 = icmp eq <8 x i1> %2491, %2492
  %2494 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2493)
  %2495 = and i1 %2487, %2494
  %.splatinsert603 = insertelement <8 x i1> poison, i1 %2495, i64 0
  %.splat604 = shufflevector <8 x i1> %.splatinsert603, <8 x i1> poison, <8 x i32> zeroinitializer
  %2496 = select <8 x i1> %.splat604, <8 x i1> %2491, <8 x i1> zeroinitializer
  %2497 = select i1 %2495, <8 x i1> zeroinitializer, <8 x i1> %2492
  store <8 x i1> %2497, ptr %2488, align 1
  %2498 = select i1 %2495, <8 x i1> zeroinitializer, <8 x i1> %2491
  store <8 x i1> %2498, ptr %2489, align 1
  %2499 = and i8 %2485, -5
  %2500 = select i1 %2495, i8 %2499, i8 %2485
  store i8 %2500, ptr %frame.active, align 1
  %2501 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2502 = extractelement <8 x i32> %2501, i32 2
  %2503 = load <8 x i32>, ptr %frame.static.id, align 32
  %2504 = extractelement <8 x i32> %2503, i32 2
  %convergence.target.pointer605 = getelementptr inbounds [9 x i32], ptr @convergence.targets, i32 0, i32 %2504
  %convergence.dynamic.target606 = load i32, ptr %convergence.target.pointer605, align 4
  %2505 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2496)
  %2506 = load i32, ptr %ready.count, align 4
  %2507 = icmp uge i32 %2506, 8
  %2508 = and i1 %2505, %2507
  br i1 %2508, label %ready.overflow.trap607, label %ready.overflow.resume608

ready.overflow.trap607:                           ; preds = %ready.overflow.resume602
  call void @llvm.trap()
  unreachable

ready.overflow.resume608:                         ; preds = %ready.overflow.resume602
  %2509 = select i1 %2505, i32 %2506, i32 0
  %2510 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2509
  %2511 = load <8 x i1>, ptr %2510, align 1
  %2512 = select i1 %2505, <8 x i1> %2496, <8 x i1> %2511
  store <8 x i1> %2512, ptr %2510, align 1
  %2513 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2509
  %2514 = load i32, ptr %2513, align 4
  %2515 = select i1 %2505, i32 %convergence.dynamic.target606, i32 %2514
  store i32 %2515, ptr %2513, align 4
  %2516 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2509
  %2517 = load i32, ptr %2516, align 4
  %2518 = select i1 %2505, i32 %2502, i32 %2517
  store i32 %2518, ptr %2516, align 4
  %2519 = add i32 %2506, 1
  %2520 = select i1 %2505, i32 %2519, i32 %2506
  store i32 %2520, ptr %ready.count, align 4
  %2521 = load <8 x i1>, ptr %runnable.mask, align 1
  %2522 = or <8 x i1> %2521, %2496
  store <8 x i1> %2522, ptr %runnable.mask, align 1
  %2523 = load i8, ptr %frame.active, align 1
  %2524 = and i8 %2523, 8
  %2525 = icmp ne i8 %2524, 0
  %2526 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 3
  %2527 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 3
  %2528 = load <8 x i1>, ptr %2526, align 1
  %2529 = load <8 x i1>, ptr %2527, align 1
  %2530 = and <8 x i1> %2528, %2405
  %2531 = icmp eq <8 x i1> %2529, %2530
  %2532 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2531)
  %2533 = and i1 %2525, %2532
  %.splatinsert609 = insertelement <8 x i1> poison, i1 %2533, i64 0
  %.splat610 = shufflevector <8 x i1> %.splatinsert609, <8 x i1> poison, <8 x i32> zeroinitializer
  %2534 = select <8 x i1> %.splat610, <8 x i1> %2529, <8 x i1> zeroinitializer
  %2535 = select i1 %2533, <8 x i1> zeroinitializer, <8 x i1> %2530
  store <8 x i1> %2535, ptr %2526, align 1
  %2536 = select i1 %2533, <8 x i1> zeroinitializer, <8 x i1> %2529
  store <8 x i1> %2536, ptr %2527, align 1
  %2537 = and i8 %2523, -9
  %2538 = select i1 %2533, i8 %2537, i8 %2523
  store i8 %2538, ptr %frame.active, align 1
  %2539 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2540 = extractelement <8 x i32> %2539, i32 3
  %2541 = load <8 x i32>, ptr %frame.static.id, align 32
  %2542 = extractelement <8 x i32> %2541, i32 3
  %convergence.target.pointer611 = getelementptr inbounds [9 x i32], ptr @convergence.targets, i32 0, i32 %2542
  %convergence.dynamic.target612 = load i32, ptr %convergence.target.pointer611, align 4
  %2543 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2534)
  %2544 = load i32, ptr %ready.count, align 4
  %2545 = icmp uge i32 %2544, 8
  %2546 = and i1 %2543, %2545
  br i1 %2546, label %ready.overflow.trap613, label %ready.overflow.resume614

ready.overflow.trap613:                           ; preds = %ready.overflow.resume608
  call void @llvm.trap()
  unreachable

ready.overflow.resume614:                         ; preds = %ready.overflow.resume608
  %2547 = select i1 %2543, i32 %2544, i32 0
  %2548 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2547
  %2549 = load <8 x i1>, ptr %2548, align 1
  %2550 = select i1 %2543, <8 x i1> %2534, <8 x i1> %2549
  store <8 x i1> %2550, ptr %2548, align 1
  %2551 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2547
  %2552 = load i32, ptr %2551, align 4
  %2553 = select i1 %2543, i32 %convergence.dynamic.target612, i32 %2552
  store i32 %2553, ptr %2551, align 4
  %2554 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2547
  %2555 = load i32, ptr %2554, align 4
  %2556 = select i1 %2543, i32 %2540, i32 %2555
  store i32 %2556, ptr %2554, align 4
  %2557 = add i32 %2544, 1
  %2558 = select i1 %2543, i32 %2557, i32 %2544
  store i32 %2558, ptr %ready.count, align 4
  %2559 = load <8 x i1>, ptr %runnable.mask, align 1
  %2560 = or <8 x i1> %2559, %2534
  store <8 x i1> %2560, ptr %runnable.mask, align 1
  %2561 = load i8, ptr %frame.active, align 1
  %2562 = and i8 %2561, 16
  %2563 = icmp ne i8 %2562, 0
  %2564 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 4
  %2565 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 4
  %2566 = load <8 x i1>, ptr %2564, align 1
  %2567 = load <8 x i1>, ptr %2565, align 1
  %2568 = and <8 x i1> %2566, %2405
  %2569 = icmp eq <8 x i1> %2567, %2568
  %2570 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2569)
  %2571 = and i1 %2563, %2570
  %.splatinsert615 = insertelement <8 x i1> poison, i1 %2571, i64 0
  %.splat616 = shufflevector <8 x i1> %.splatinsert615, <8 x i1> poison, <8 x i32> zeroinitializer
  %2572 = select <8 x i1> %.splat616, <8 x i1> %2567, <8 x i1> zeroinitializer
  %2573 = select i1 %2571, <8 x i1> zeroinitializer, <8 x i1> %2568
  store <8 x i1> %2573, ptr %2564, align 1
  %2574 = select i1 %2571, <8 x i1> zeroinitializer, <8 x i1> %2567
  store <8 x i1> %2574, ptr %2565, align 1
  %2575 = and i8 %2561, -17
  %2576 = select i1 %2571, i8 %2575, i8 %2561
  store i8 %2576, ptr %frame.active, align 1
  %2577 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2578 = extractelement <8 x i32> %2577, i32 4
  %2579 = load <8 x i32>, ptr %frame.static.id, align 32
  %2580 = extractelement <8 x i32> %2579, i32 4
  %convergence.target.pointer617 = getelementptr inbounds [9 x i32], ptr @convergence.targets, i32 0, i32 %2580
  %convergence.dynamic.target618 = load i32, ptr %convergence.target.pointer617, align 4
  %2581 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2572)
  %2582 = load i32, ptr %ready.count, align 4
  %2583 = icmp uge i32 %2582, 8
  %2584 = and i1 %2581, %2583
  br i1 %2584, label %ready.overflow.trap619, label %ready.overflow.resume620

ready.overflow.trap619:                           ; preds = %ready.overflow.resume614
  call void @llvm.trap()
  unreachable

ready.overflow.resume620:                         ; preds = %ready.overflow.resume614
  %2585 = select i1 %2581, i32 %2582, i32 0
  %2586 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2585
  %2587 = load <8 x i1>, ptr %2586, align 1
  %2588 = select i1 %2581, <8 x i1> %2572, <8 x i1> %2587
  store <8 x i1> %2588, ptr %2586, align 1
  %2589 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2585
  %2590 = load i32, ptr %2589, align 4
  %2591 = select i1 %2581, i32 %convergence.dynamic.target618, i32 %2590
  store i32 %2591, ptr %2589, align 4
  %2592 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2585
  %2593 = load i32, ptr %2592, align 4
  %2594 = select i1 %2581, i32 %2578, i32 %2593
  store i32 %2594, ptr %2592, align 4
  %2595 = add i32 %2582, 1
  %2596 = select i1 %2581, i32 %2595, i32 %2582
  store i32 %2596, ptr %ready.count, align 4
  %2597 = load <8 x i1>, ptr %runnable.mask, align 1
  %2598 = or <8 x i1> %2597, %2572
  store <8 x i1> %2598, ptr %runnable.mask, align 1
  %2599 = load i8, ptr %frame.active, align 1
  %2600 = and i8 %2599, 32
  %2601 = icmp ne i8 %2600, 0
  %2602 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 5
  %2603 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 5
  %2604 = load <8 x i1>, ptr %2602, align 1
  %2605 = load <8 x i1>, ptr %2603, align 1
  %2606 = and <8 x i1> %2604, %2405
  %2607 = icmp eq <8 x i1> %2605, %2606
  %2608 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2607)
  %2609 = and i1 %2601, %2608
  %.splatinsert621 = insertelement <8 x i1> poison, i1 %2609, i64 0
  %.splat622 = shufflevector <8 x i1> %.splatinsert621, <8 x i1> poison, <8 x i32> zeroinitializer
  %2610 = select <8 x i1> %.splat622, <8 x i1> %2605, <8 x i1> zeroinitializer
  %2611 = select i1 %2609, <8 x i1> zeroinitializer, <8 x i1> %2606
  store <8 x i1> %2611, ptr %2602, align 1
  %2612 = select i1 %2609, <8 x i1> zeroinitializer, <8 x i1> %2605
  store <8 x i1> %2612, ptr %2603, align 1
  %2613 = and i8 %2599, -33
  %2614 = select i1 %2609, i8 %2613, i8 %2599
  store i8 %2614, ptr %frame.active, align 1
  %2615 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2616 = extractelement <8 x i32> %2615, i32 5
  %2617 = load <8 x i32>, ptr %frame.static.id, align 32
  %2618 = extractelement <8 x i32> %2617, i32 5
  %convergence.target.pointer623 = getelementptr inbounds [9 x i32], ptr @convergence.targets, i32 0, i32 %2618
  %convergence.dynamic.target624 = load i32, ptr %convergence.target.pointer623, align 4
  %2619 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2610)
  %2620 = load i32, ptr %ready.count, align 4
  %2621 = icmp uge i32 %2620, 8
  %2622 = and i1 %2619, %2621
  br i1 %2622, label %ready.overflow.trap625, label %ready.overflow.resume626

ready.overflow.trap625:                           ; preds = %ready.overflow.resume620
  call void @llvm.trap()
  unreachable

ready.overflow.resume626:                         ; preds = %ready.overflow.resume620
  %2623 = select i1 %2619, i32 %2620, i32 0
  %2624 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2623
  %2625 = load <8 x i1>, ptr %2624, align 1
  %2626 = select i1 %2619, <8 x i1> %2610, <8 x i1> %2625
  store <8 x i1> %2626, ptr %2624, align 1
  %2627 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2623
  %2628 = load i32, ptr %2627, align 4
  %2629 = select i1 %2619, i32 %convergence.dynamic.target624, i32 %2628
  store i32 %2629, ptr %2627, align 4
  %2630 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2623
  %2631 = load i32, ptr %2630, align 4
  %2632 = select i1 %2619, i32 %2616, i32 %2631
  store i32 %2632, ptr %2630, align 4
  %2633 = add i32 %2620, 1
  %2634 = select i1 %2619, i32 %2633, i32 %2620
  store i32 %2634, ptr %ready.count, align 4
  %2635 = load <8 x i1>, ptr %runnable.mask, align 1
  %2636 = or <8 x i1> %2635, %2610
  store <8 x i1> %2636, ptr %runnable.mask, align 1
  %2637 = load i8, ptr %frame.active, align 1
  %2638 = and i8 %2637, 64
  %2639 = icmp ne i8 %2638, 0
  %2640 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 6
  %2641 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 6
  %2642 = load <8 x i1>, ptr %2640, align 1
  %2643 = load <8 x i1>, ptr %2641, align 1
  %2644 = and <8 x i1> %2642, %2405
  %2645 = icmp eq <8 x i1> %2643, %2644
  %2646 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2645)
  %2647 = and i1 %2639, %2646
  %.splatinsert627 = insertelement <8 x i1> poison, i1 %2647, i64 0
  %.splat628 = shufflevector <8 x i1> %.splatinsert627, <8 x i1> poison, <8 x i32> zeroinitializer
  %2648 = select <8 x i1> %.splat628, <8 x i1> %2643, <8 x i1> zeroinitializer
  %2649 = select i1 %2647, <8 x i1> zeroinitializer, <8 x i1> %2644
  store <8 x i1> %2649, ptr %2640, align 1
  %2650 = select i1 %2647, <8 x i1> zeroinitializer, <8 x i1> %2643
  store <8 x i1> %2650, ptr %2641, align 1
  %2651 = and i8 %2637, -65
  %2652 = select i1 %2647, i8 %2651, i8 %2637
  store i8 %2652, ptr %frame.active, align 1
  %2653 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2654 = extractelement <8 x i32> %2653, i32 6
  %2655 = load <8 x i32>, ptr %frame.static.id, align 32
  %2656 = extractelement <8 x i32> %2655, i32 6
  %convergence.target.pointer629 = getelementptr inbounds [9 x i32], ptr @convergence.targets, i32 0, i32 %2656
  %convergence.dynamic.target630 = load i32, ptr %convergence.target.pointer629, align 4
  %2657 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2648)
  %2658 = load i32, ptr %ready.count, align 4
  %2659 = icmp uge i32 %2658, 8
  %2660 = and i1 %2657, %2659
  br i1 %2660, label %ready.overflow.trap631, label %ready.overflow.resume632

ready.overflow.trap631:                           ; preds = %ready.overflow.resume626
  call void @llvm.trap()
  unreachable

ready.overflow.resume632:                         ; preds = %ready.overflow.resume626
  %2661 = select i1 %2657, i32 %2658, i32 0
  %2662 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2661
  %2663 = load <8 x i1>, ptr %2662, align 1
  %2664 = select i1 %2657, <8 x i1> %2648, <8 x i1> %2663
  store <8 x i1> %2664, ptr %2662, align 1
  %2665 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2661
  %2666 = load i32, ptr %2665, align 4
  %2667 = select i1 %2657, i32 %convergence.dynamic.target630, i32 %2666
  store i32 %2667, ptr %2665, align 4
  %2668 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2661
  %2669 = load i32, ptr %2668, align 4
  %2670 = select i1 %2657, i32 %2654, i32 %2669
  store i32 %2670, ptr %2668, align 4
  %2671 = add i32 %2658, 1
  %2672 = select i1 %2657, i32 %2671, i32 %2658
  store i32 %2672, ptr %ready.count, align 4
  %2673 = load <8 x i1>, ptr %runnable.mask, align 1
  %2674 = or <8 x i1> %2673, %2648
  store <8 x i1> %2674, ptr %runnable.mask, align 1
  %2675 = load i8, ptr %frame.active, align 1
  %2676 = and i8 %2675, -128
  %2677 = icmp ne i8 %2676, 0
  %2678 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 7
  %2679 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 7
  %2680 = load <8 x i1>, ptr %2678, align 1
  %2681 = load <8 x i1>, ptr %2679, align 1
  %2682 = and <8 x i1> %2680, %2405
  %2683 = icmp eq <8 x i1> %2681, %2682
  %2684 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2683)
  %2685 = and i1 %2677, %2684
  %.splatinsert633 = insertelement <8 x i1> poison, i1 %2685, i64 0
  %.splat634 = shufflevector <8 x i1> %.splatinsert633, <8 x i1> poison, <8 x i32> zeroinitializer
  %2686 = select <8 x i1> %.splat634, <8 x i1> %2681, <8 x i1> zeroinitializer
  %2687 = select i1 %2685, <8 x i1> zeroinitializer, <8 x i1> %2682
  store <8 x i1> %2687, ptr %2678, align 1
  %2688 = select i1 %2685, <8 x i1> zeroinitializer, <8 x i1> %2681
  store <8 x i1> %2688, ptr %2679, align 1
  %2689 = and i8 %2675, 127
  %2690 = select i1 %2685, i8 %2689, i8 %2675
  store i8 %2690, ptr %frame.active, align 1
  %2691 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2692 = extractelement <8 x i32> %2691, i32 7
  %2693 = load <8 x i32>, ptr %frame.static.id, align 32
  %2694 = extractelement <8 x i32> %2693, i32 7
  %convergence.target.pointer635 = getelementptr inbounds [9 x i32], ptr @convergence.targets, i32 0, i32 %2694
  %convergence.dynamic.target636 = load i32, ptr %convergence.target.pointer635, align 4
  %2695 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2686)
  %2696 = load i32, ptr %ready.count, align 4
  %2697 = icmp uge i32 %2696, 8
  %2698 = and i1 %2695, %2697
  br i1 %2698, label %ready.overflow.trap637, label %ready.overflow.resume638

ready.overflow.trap637:                           ; preds = %ready.overflow.resume632
  call void @llvm.trap()
  unreachable

ready.overflow.resume638:                         ; preds = %ready.overflow.resume632
  %2699 = select i1 %2695, i32 %2696, i32 0
  %2700 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2699
  %2701 = load <8 x i1>, ptr %2700, align 1
  %2702 = select i1 %2695, <8 x i1> %2686, <8 x i1> %2701
  store <8 x i1> %2702, ptr %2700, align 1
  %2703 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2699
  %2704 = load i32, ptr %2703, align 4
  %2705 = select i1 %2695, i32 %convergence.dynamic.target636, i32 %2704
  store i32 %2705, ptr %2703, align 4
  %2706 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2699
  %2707 = load i32, ptr %2706, align 4
  %2708 = select i1 %2695, i32 %2692, i32 %2707
  store i32 %2708, ptr %2706, align 4
  %2709 = add i32 %2696, 1
  %2710 = select i1 %2695, i32 %2709, i32 %2696
  store i32 %2710, ptr %ready.count, align 4
  %2711 = load <8 x i1>, ptr %runnable.mask, align 1
  %2712 = or <8 x i1> %2711, %2686
  store <8 x i1> %2712, ptr %runnable.mask, align 1
  br label %return.frame.cleanup.done
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.and.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.fabs.v8f32(<8 x float>) #0

define dso_local void @tile_row_reduce.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @tile_row_reduce(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @tile_row_reduce(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @tile_row_reduce(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @tile_row_reduce(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @tile_row_reduce(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @tile_row_reduce(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(write) }

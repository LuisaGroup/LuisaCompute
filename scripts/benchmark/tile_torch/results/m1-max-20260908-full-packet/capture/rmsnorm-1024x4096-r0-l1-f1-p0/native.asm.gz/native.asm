/tmp/luisa-full-packet.UEezjO/capture/rmsnorm-1024x4096-r0-l1-f1-p0/object/tile_xir_w8_63773_1788856228964933_0.o:
(__TEXT,__text) section
_llm_rows:
       0:	sub	sp, sp, #0x30
       4:	stp	d11, d10, [sp, #0x10]
       8:	stp	d9, d8, [sp, #0x20]
       c:	dup.4s	v1, w2
      10:	adrp	x8, lCPI0_0@PAGE
      14:	ldr	q3, [x8, lCPI0_0@PAGEOFF]
      18:	adrp	x8, lCPI0_1@PAGE
      1c:	ldr	q4, [x8, lCPI0_1@PAGEOFF]
      20:	cmhi.4s	v0, v1, v4
      24:	cmhi.4s	v1, v1, v3
      28:	uzp1.8h	v2, v1, v0
      2c:	umaxv.8h	h5, v2
      30:	fmov	w8, s5
      34:	tbz	w8, #0x0, 0x8a8
      38:	ldr	x8, [x0]
      3c:	adrp	x9, lCPI0_2@PAGE
      40:	ldr	q5, [x9, lCPI0_2@PAGEOFF]
      44:	and.16b	v2, v2, v5
      48:	addv.8h	h2, v2
      4c:	fmov	w10, s2
      50:	and	w9, w10, #0xff
      54:	ldr	w11, [x1]
      58:	ldr	w12, [x1, #0x24]
      5c:	add	w11, w12, w11, lsl #10
      60:	dup.4s	v5, w11
      64:	add.4s	v7, v5, v4
      68:	add.4s	v3, v5, v3
      6c:	and.16b	v4, v1, v3
      70:	ushll.2d	v19, v4, #0xe
      74:	dup.2d	v3, x8
      78:	add.2d	v17, v3, v19
      7c:	movi.2d	v5, #0000000000000000
      80:	movi.2d	v6, #0000000000000000
      84:	tbnz	w10, #0x0, 0x8b8
      88:	and.16b	v7, v0, v7
      8c:	ushll2.2d	v16, v4, #0xe
      90:	tbnz	w9, #0x1, 0x8cc
      94:	add.2d	v17, v3, v16
      98:	tbnz	w9, #0x2, 0x8dc
      9c:	ushll.2d	v18, v7, #0xe
      a0:	tbnz	w9, #0x3, 0x8ec
      a4:	add.2d	v20, v3, v18
      a8:	tbnz	w9, #0x4, 0x8fc
      ac:	ushll2.2d	v17, v7, #0xe
      b0:	tbnz	w9, #0x5, 0x90c
      b4:	ldr	x8, [x1, #0x88]
      b8:	add.2d	v20, v3, v17
      bc:	tbnz	w9, #0x6, 0x920
      c0:	tbz	w9, #0x7, 0xcc
      c4:	mov.d	x9, v20[1]
      c8:	ld1.s	{ v6 }[3], [x9]
      cc:	ldr	x10, [x0, #0x10]
      d0:	ldr	x9, [x0, #0x30]
      d4:	fmov	w12, s2
      d8:	and	w11, w12, #0xff
      dc:	ldp	q20, q21, [x8]
      e0:	bit.16b	v21, v6, v0
      e4:	bit.16b	v20, v5, v1
      e8:	stp	q20, q21, [x8]
      ec:	mov	w13, #0x4
      f0:	dup.2d	v20, x13
      f4:	add.2d	v22, v3, v20
      f8:	add.2d	v23, v22, v19
      fc:	movi.2d	v20, #0000000000000000
     100:	movi.2d	v21, #0000000000000000
     104:	tbnz	w12, #0x0, 0x930
     108:	tbnz	w11, #0x1, 0x93c
     10c:	add.2d	v23, v22, v16
     110:	tbnz	w11, #0x2, 0x94c
     114:	tbnz	w11, #0x3, 0x958
     118:	add.2d	v23, v22, v18
     11c:	tbnz	w11, #0x4, 0x968
     120:	tbnz	w11, #0x5, 0x974
     124:	add.2d	v22, v22, v17
     128:	tbnz	w11, #0x6, 0x984
     12c:	tbz	w11, #0x7, 0x138
     130:	mov.d	x11, v22[1]
     134:	ld1.s	{ v21 }[3], [x11]
     138:	fmov	w12, s2
     13c:	and	w11, w12, #0xff
     140:	ldp	q22, q23, [x8, #0x20]
     144:	bit.16b	v23, v21, v0
     148:	bit.16b	v22, v20, v1
     14c:	stp	q22, q23, [x8, #0x20]
     150:	mov	w13, #0x8
     154:	dup.2d	v22, x13
     158:	add.2d	v24, v3, v22
     15c:	add.2d	v25, v24, v19
     160:	movi.2d	v22, #0000000000000000
     164:	movi.2d	v23, #0000000000000000
     168:	tbnz	w12, #0x0, 0x994
     16c:	tbnz	w11, #0x1, 0x9a0
     170:	add.2d	v25, v24, v16
     174:	tbnz	w11, #0x2, 0x9b0
     178:	tbnz	w11, #0x3, 0x9bc
     17c:	add.2d	v25, v24, v18
     180:	tbnz	w11, #0x4, 0x9cc
     184:	tbnz	w11, #0x5, 0x9d8
     188:	add.2d	v24, v24, v17
     18c:	tbnz	w11, #0x6, 0x9e8
     190:	tbz	w11, #0x7, 0x19c
     194:	mov.d	x11, v24[1]
     198:	ld1.s	{ v23 }[3], [x11]
     19c:	fmov	w12, s2
     1a0:	and	w11, w12, #0xff
     1a4:	ldp	q24, q25, [x8, #0x40]
     1a8:	bit.16b	v25, v23, v0
     1ac:	bit.16b	v24, v22, v1
     1b0:	stp	q24, q25, [x8, #0x40]
     1b4:	mov	w13, #0xc
     1b8:	dup.2d	v24, x13
     1bc:	add.2d	v25, v3, v24
     1c0:	add.2d	v26, v25, v19
     1c4:	movi.2d	v19, #0000000000000000
     1c8:	movi.2d	v24, #0000000000000000
     1cc:	tbnz	w12, #0x0, 0x9f8
     1d0:	tbnz	w11, #0x1, 0xa04
     1d4:	add.2d	v16, v25, v16
     1d8:	tbnz	w11, #0x2, 0xa14
     1dc:	tbnz	w11, #0x3, 0xa20
     1e0:	add.2d	v16, v25, v18
     1e4:	tbnz	w11, #0x4, 0xa30
     1e8:	tbnz	w11, #0x5, 0xa3c
     1ec:	add.2d	v28, v25, v17
     1f0:	tbz	w11, #0x6, 0x1fc
     1f4:	fmov	x12, d28
     1f8:	ld1.s	{ v24 }[2], [x12]
     1fc:	sshll.2d	v27, v1, #0x0
     200:	sshll.2d	v29, v0, #0x0
     204:	sshll2.2d	v30, v1, #0x0
     208:	sshll2.2d	v8, v0, #0x0
     20c:	ushll.2d	v31, v4, #0xc
     210:	ushll.2d	v9, v7, #0xc
     214:	ushll2.2d	v10, v4, #0xc
     218:	ushll2.2d	v4, v7, #0xc
     21c:	fmul.4s	v16, v5, v5
     220:	fmul.4s	v18, v6, v6
     224:	fmul.4s	v17, v20, v20
     228:	fmul.4s	v21, v21, v21
     22c:	fmul.4s	v25, v22, v22
     230:	fmul.4s	v26, v23, v23
     234:	tbz	w11, #0x7, 0x240
     238:	mov.d	x11, v28[1]
     23c:	ld1.s	{ v24 }[3], [x11]
     240:	add	x11, x8, #0x20, lsl #12
     244:	and.16b	v4, v8, v4
     248:	and.16b	v5, v30, v10
     24c:	and.16b	v6, v29, v9
     250:	and.16b	v7, v27, v31
     254:	ldp	q20, q22, [x8, #0x60]
     258:	bit.16b	v22, v24, v0
     25c:	bit.16b	v20, v19, v1
     260:	stp	q20, q22, [x8, #0x60]
     264:	fmul.4s	v19, v19, v19
     268:	fmul.4s	v24, v24, v24
     26c:	and.16b	v20, v0, v18
     270:	and.16b	v22, v1, v16
     274:	and.16b	v21, v0, v21
     278:	and.16b	v23, v1, v17
     27c:	and.16b	v18, v0, v26
     280:	and.16b	v17, v1, v25
     284:	and.16b	v16, v0, v24
     288:	and.16b	v19, v1, v19
     28c:	add	x12, x8, #0xe0
     290:	mov	w13, #0x7
     294:	fmov	w14, s2
     298:	b	0x31c
     29c:	fmul.4s	v25, v25, v25
     2a0:	fmul.4s	v24, v24, v24
     2a4:	fadd.4s	v24, v22, v24
     2a8:	fadd.4s	v25, v20, v25
     2ac:	fmul.4s	v27, v27, v27
     2b0:	fmul.4s	v26, v26, v26
     2b4:	fadd.4s	v26, v23, v26
     2b8:	fadd.4s	v27, v21, v27
     2bc:	fmul.4s	v29, v29, v29
     2c0:	fmul.4s	v28, v28, v28
     2c4:	fadd.4s	v28, v17, v28
     2c8:	fadd.4s	v29, v18, v29
     2cc:	ldp	q8, q9, [x12]
     2d0:	bit.16b	v9, v31, v0
     2d4:	bit.16b	v8, v30, v1
     2d8:	stp	q8, q9, [x12], #0x80
     2dc:	fmul.4s	v30, v30, v30
     2e0:	fmul.4s	v31, v31, v31
     2e4:	fadd.4s	v31, v16, v31
     2e8:	fadd.4s	v30, v19, v30
     2ec:	bit.16b	v20, v25, v0
     2f0:	bit.16b	v22, v24, v1
     2f4:	bit.16b	v21, v27, v0
     2f8:	bit.16b	v23, v26, v1
     2fc:	bit.16b	v18, v29, v0
     300:	add	x13, x13, #0x4
     304:	bit.16b	v17, v28, v1
     308:	bit.16b	v19, v30, v1
     30c:	sub	x15, x15, #0x3
     310:	bit.16b	v16, v31, v0
     314:	cmp	x15, #0xffc
     318:	b.hs	0x70c
     31c:	sub	x15, x13, #0x3
     320:	dup.2d	v26, x15
     324:	add.2d	v24, v26, v7
     328:	shl.2d	v24, v24, #0x2
     32c:	add.2d	v27, v3, v24
     330:	movi.2d	v24, #0000000000000000
     334:	movi.2d	v25, #0000000000000000
     338:	tbnz	w14, #0x0, 0x504
     33c:	and	w16, w14, #0xff
     340:	tbnz	w16, #0x1, 0x514
     344:	add.2d	v27, v26, v5
     348:	shl.2d	v27, v27, #0x2
     34c:	add.2d	v27, v3, v27
     350:	tbnz	w16, #0x2, 0x52c
     354:	tbnz	w16, #0x3, 0x538
     358:	add.2d	v27, v26, v6
     35c:	shl.2d	v27, v27, #0x2
     360:	add.2d	v27, v3, v27
     364:	tbnz	w16, #0x4, 0x550
     368:	tbnz	w16, #0x5, 0x55c
     36c:	add.2d	v26, v26, v4
     370:	shl.2d	v26, v26, #0x2
     374:	add.2d	v26, v3, v26
     378:	tbnz	w16, #0x6, 0x574
     37c:	tbz	w16, #0x7, 0x388
     380:	mov.d	x16, v26[1]
     384:	ld1.s	{ v25 }[3], [x16]
     388:	fmov	w16, s2
     38c:	ldp	q26, q27, [x12, #-0x60]
     390:	bit.16b	v27, v25, v0
     394:	bit.16b	v26, v24, v1
     398:	add	x15, x15, #0x1
     39c:	dup.2d	v28, x15
     3a0:	stp	q26, q27, [x12, #-0x60]
     3a4:	add.2d	v26, v28, v7
     3a8:	shl.2d	v26, v26, #0x2
     3ac:	add.2d	v29, v3, v26
     3b0:	movi.2d	v26, #0000000000000000
     3b4:	movi.2d	v27, #0000000000000000
     3b8:	tbnz	w16, #0x0, 0x584
     3bc:	and	w16, w16, #0xff
     3c0:	tbnz	w16, #0x1, 0x594
     3c4:	add.2d	v29, v28, v5
     3c8:	shl.2d	v29, v29, #0x2
     3cc:	add.2d	v29, v3, v29
     3d0:	tbnz	w16, #0x2, 0x5ac
     3d4:	tbnz	w16, #0x3, 0x5b8
     3d8:	add.2d	v29, v28, v6
     3dc:	shl.2d	v29, v29, #0x2
     3e0:	add.2d	v29, v3, v29
     3e4:	tbnz	w16, #0x4, 0x5d0
     3e8:	tbnz	w16, #0x5, 0x5dc
     3ec:	add.2d	v28, v28, v4
     3f0:	shl.2d	v28, v28, #0x2
     3f4:	add.2d	v28, v3, v28
     3f8:	tbnz	w16, #0x6, 0x5f4
     3fc:	tbz	w16, #0x7, 0x408
     400:	mov.d	x16, v28[1]
     404:	ld1.s	{ v27 }[3], [x16]
     408:	fmov	w16, s2
     40c:	ldp	q28, q29, [x12, #-0x40]
     410:	bit.16b	v29, v27, v0
     414:	bit.16b	v28, v26, v1
     418:	add	x15, x15, #0x1
     41c:	dup.2d	v30, x15
     420:	stp	q28, q29, [x12, #-0x40]
     424:	add.2d	v28, v30, v7
     428:	shl.2d	v28, v28, #0x2
     42c:	add.2d	v31, v3, v28
     430:	movi.2d	v28, #0000000000000000
     434:	movi.2d	v29, #0000000000000000
     438:	tbnz	w16, #0x0, 0x604
     43c:	and	w16, w16, #0xff
     440:	tbnz	w16, #0x1, 0x614
     444:	add.2d	v31, v30, v5
     448:	shl.2d	v31, v31, #0x2
     44c:	add.2d	v31, v3, v31
     450:	tbnz	w16, #0x2, 0x62c
     454:	tbnz	w16, #0x3, 0x638
     458:	add.2d	v31, v30, v6
     45c:	shl.2d	v31, v31, #0x2
     460:	add.2d	v31, v3, v31
     464:	tbnz	w16, #0x4, 0x650
     468:	tbnz	w16, #0x5, 0x65c
     46c:	add.2d	v30, v30, v4
     470:	shl.2d	v30, v30, #0x2
     474:	add.2d	v30, v3, v30
     478:	tbnz	w16, #0x6, 0x674
     47c:	tbz	w16, #0x7, 0x488
     480:	mov.d	x16, v30[1]
     484:	ld1.s	{ v29 }[3], [x16]
     488:	fmov	w16, s2
     48c:	ldp	q30, q31, [x12, #-0x20]
     490:	bit.16b	v31, v29, v0
     494:	bit.16b	v30, v28, v1
     498:	add	x15, x15, #0x1
     49c:	dup.2d	v8, x15
     4a0:	stp	q30, q31, [x12, #-0x20]
     4a4:	add.2d	v30, v8, v7
     4a8:	shl.2d	v30, v30, #0x2
     4ac:	add.2d	v9, v3, v30
     4b0:	movi.2d	v30, #0000000000000000
     4b4:	movi.2d	v31, #0000000000000000
     4b8:	tbnz	w16, #0x0, 0x684
     4bc:	and	w16, w16, #0xff
     4c0:	tbnz	w16, #0x1, 0x694
     4c4:	add.2d	v9, v8, v5
     4c8:	shl.2d	v9, v9, #0x2
     4cc:	add.2d	v9, v3, v9
     4d0:	tbnz	w16, #0x2, 0x6ac
     4d4:	tbnz	w16, #0x3, 0x6b8
     4d8:	add.2d	v9, v8, v6
     4dc:	shl.2d	v9, v9, #0x2
     4e0:	add.2d	v9, v3, v9
     4e4:	tbnz	w16, #0x4, 0x6d0
     4e8:	tbnz	w16, #0x5, 0x6dc
     4ec:	add.2d	v8, v8, v4
     4f0:	shl.2d	v8, v8, #0x2
     4f4:	add.2d	v8, v3, v8
     4f8:	tbnz	w16, #0x6, 0x6f4
     4fc:	tbz	w16, #0x7, 0x29c
     500:	b	0x700
     504:	fmov	x16, d27
     508:	ldr	s24, [x16]
     50c:	and	w16, w14, #0xff
     510:	tbz	w16, #0x1, 0x344
     514:	mov.d	x17, v27[1]
     518:	ld1.s	{ v24 }[1], [x17]
     51c:	add.2d	v27, v26, v5
     520:	shl.2d	v27, v27, #0x2
     524:	add.2d	v27, v3, v27
     528:	tbz	w16, #0x2, 0x354
     52c:	fmov	x17, d27
     530:	ld1.s	{ v24 }[2], [x17]
     534:	tbz	w16, #0x3, 0x358
     538:	mov.d	x17, v27[1]
     53c:	ld1.s	{ v24 }[3], [x17]
     540:	add.2d	v27, v26, v6
     544:	shl.2d	v27, v27, #0x2
     548:	add.2d	v27, v3, v27
     54c:	tbz	w16, #0x4, 0x368
     550:	fmov	x17, d27
     554:	ld1.s	{ v25 }[0], [x17]
     558:	tbz	w16, #0x5, 0x36c
     55c:	mov.d	x17, v27[1]
     560:	ld1.s	{ v25 }[1], [x17]
     564:	add.2d	v26, v26, v4
     568:	shl.2d	v26, v26, #0x2
     56c:	add.2d	v26, v3, v26
     570:	tbz	w16, #0x6, 0x37c
     574:	fmov	x17, d26
     578:	ld1.s	{ v25 }[2], [x17]
     57c:	tbnz	w16, #0x7, 0x380
     580:	b	0x388
     584:	fmov	x17, d29
     588:	ldr	s26, [x17]
     58c:	and	w16, w16, #0xff
     590:	tbz	w16, #0x1, 0x3c4
     594:	mov.d	x17, v29[1]
     598:	ld1.s	{ v26 }[1], [x17]
     59c:	add.2d	v29, v28, v5
     5a0:	shl.2d	v29, v29, #0x2
     5a4:	add.2d	v29, v3, v29
     5a8:	tbz	w16, #0x2, 0x3d4
     5ac:	fmov	x17, d29
     5b0:	ld1.s	{ v26 }[2], [x17]
     5b4:	tbz	w16, #0x3, 0x3d8
     5b8:	mov.d	x17, v29[1]
     5bc:	ld1.s	{ v26 }[3], [x17]
     5c0:	add.2d	v29, v28, v6
     5c4:	shl.2d	v29, v29, #0x2
     5c8:	add.2d	v29, v3, v29
     5cc:	tbz	w16, #0x4, 0x3e8
     5d0:	fmov	x17, d29
     5d4:	ld1.s	{ v27 }[0], [x17]
     5d8:	tbz	w16, #0x5, 0x3ec
     5dc:	mov.d	x17, v29[1]
     5e0:	ld1.s	{ v27 }[1], [x17]
     5e4:	add.2d	v28, v28, v4
     5e8:	shl.2d	v28, v28, #0x2
     5ec:	add.2d	v28, v3, v28
     5f0:	tbz	w16, #0x6, 0x3fc
     5f4:	fmov	x17, d28
     5f8:	ld1.s	{ v27 }[2], [x17]
     5fc:	tbnz	w16, #0x7, 0x400
     600:	b	0x408
     604:	fmov	x17, d31
     608:	ldr	s28, [x17]
     60c:	and	w16, w16, #0xff
     610:	tbz	w16, #0x1, 0x444
     614:	mov.d	x17, v31[1]
     618:	ld1.s	{ v28 }[1], [x17]
     61c:	add.2d	v31, v30, v5
     620:	shl.2d	v31, v31, #0x2
     624:	add.2d	v31, v3, v31
     628:	tbz	w16, #0x2, 0x454
     62c:	fmov	x17, d31
     630:	ld1.s	{ v28 }[2], [x17]
     634:	tbz	w16, #0x3, 0x458
     638:	mov.d	x17, v31[1]
     63c:	ld1.s	{ v28 }[3], [x17]
     640:	add.2d	v31, v30, v6
     644:	shl.2d	v31, v31, #0x2
     648:	add.2d	v31, v3, v31
     64c:	tbz	w16, #0x4, 0x468
     650:	fmov	x17, d31
     654:	ld1.s	{ v29 }[0], [x17]
     658:	tbz	w16, #0x5, 0x46c
     65c:	mov.d	x17, v31[1]
     660:	ld1.s	{ v29 }[1], [x17]
     664:	add.2d	v30, v30, v4
     668:	shl.2d	v30, v30, #0x2
     66c:	add.2d	v30, v3, v30
     670:	tbz	w16, #0x6, 0x47c
     674:	fmov	x17, d30
     678:	ld1.s	{ v29 }[2], [x17]
     67c:	tbnz	w16, #0x7, 0x480
     680:	b	0x488
     684:	fmov	x17, d9
     688:	ldr	s30, [x17]
     68c:	and	w16, w16, #0xff
     690:	tbz	w16, #0x1, 0x4c4
     694:	mov.d	x17, v9[1]
     698:	ld1.s	{ v30 }[1], [x17]
     69c:	add.2d	v9, v8, v5
     6a0:	shl.2d	v9, v9, #0x2
     6a4:	add.2d	v9, v3, v9
     6a8:	tbz	w16, #0x2, 0x4d4
     6ac:	fmov	x17, d9
     6b0:	ld1.s	{ v30 }[2], [x17]
     6b4:	tbz	w16, #0x3, 0x4d8
     6b8:	mov.d	x17, v9[1]
     6bc:	ld1.s	{ v30 }[3], [x17]
     6c0:	add.2d	v9, v8, v6
     6c4:	shl.2d	v9, v9, #0x2
     6c8:	add.2d	v9, v3, v9
     6cc:	tbz	w16, #0x4, 0x4e8
     6d0:	fmov	x17, d9
     6d4:	ld1.s	{ v31 }[0], [x17]
     6d8:	tbz	w16, #0x5, 0x4ec
     6dc:	mov.d	x17, v9[1]
     6e0:	ld1.s	{ v31 }[1], [x17]
     6e4:	add.2d	v8, v8, v4
     6e8:	shl.2d	v8, v8, #0x2
     6ec:	add.2d	v8, v3, v8
     6f0:	tbz	w16, #0x6, 0x4fc
     6f4:	fmov	x17, d8
     6f8:	ld1.s	{ v31 }[2], [x17]
     6fc:	tbz	w16, #0x7, 0x29c
     700:	mov.d	x16, v8[1]
     704:	ld1.s	{ v31 }[3], [x16]
     708:	b	0x29c
     70c:	mov	x12, #0x0
     710:	add	x13, x10, x12, lsl #2
     714:	ld1r.4s	{ v3 }, [x13]
     718:	add	x13, x11, x12, lsl #5
     71c:	ldp	q24, q25, [x13]
     720:	bit.16b	v25, v3, v0
     724:	bif.16b	v3, v24, v1
     728:	stp	q3, q25, [x13]
     72c:	add	x12, x12, #0x1
     730:	cmp	x12, #0x1, lsl #12
     734:	b.ne	0x710
     738:	mov	x10, #0x0
     73c:	fadd.4s	v3, v22, v23
     740:	fadd.4s	v20, v20, v21
     744:	mov	w11, #0x39800000
     748:	dup.4s	v21, w11
     74c:	mov	w11, #0xc5ac
     750:	movk	w11, #0x3727, lsl #16
     754:	dup.4s	v22, w11
     758:	fadd.4s	v18, v20, v18
     75c:	fadd.4s	v3, v3, v17
     760:	fadd.4s	v3, v3, v19
     764:	fadd.4s	v16, v18, v16
     768:	fmul.4s	v16, v16, v21
     76c:	fmul.4s	v3, v3, v21
     770:	fadd.4s	v3, v3, v22
     774:	fadd.4s	v16, v16, v22
     778:	fsqrt.4s	v16, v16
     77c:	fsqrt.4s	v3, v3
     780:	and.16b	v3, v1, v3
     784:	and.16b	v16, v0, v16
     788:	dup.2d	v17, x9
     78c:	fmov	w9, s2
     790:	b	0x7a0
     794:	add	x10, x10, #0x1
     798:	cmp	x10, #0x1, lsl #12
     79c:	b.eq	0x8a8
     7a0:	dup.2d	v2, x10
     7a4:	add.2d	v21, v2, v7
     7a8:	add	x11, x8, x10, lsl #5
     7ac:	ldp	q19, q18, [x11]
     7b0:	and.16b	v19, v1, v19
     7b4:	fdiv.4s	v20, v19, v3
     7b8:	add	x11, x11, #0x20, lsl #12
     7bc:	ldp	q22, q19, [x11]
     7c0:	and.16b	v22, v1, v22
     7c4:	fmul.4s	v20, v20, v22
     7c8:	shl.2d	v21, v21, #0x2
     7cc:	add.2d	v21, v17, v21
     7d0:	tbnz	w9, #0x0, 0x834
     7d4:	and	w11, w9, #0xff
     7d8:	tbnz	w11, #0x1, 0x844
     7dc:	add.2d	v21, v2, v5
     7e0:	shl.2d	v21, v21, #0x2
     7e4:	add.2d	v21, v17, v21
     7e8:	tbnz	w11, #0x2, 0x85c
     7ec:	tbz	w11, #0x3, 0x7f8
     7f0:	mov.d	x12, v21[1]
     7f4:	st1.s	{ v20 }[3], [x12]
     7f8:	add.2d	v20, v2, v6
     7fc:	and.16b	v18, v0, v18
     800:	fdiv.4s	v18, v18, v16
     804:	and.16b	v19, v0, v19
     808:	fmul.4s	v18, v18, v19
     80c:	shl.2d	v19, v20, #0x2
     810:	add.2d	v19, v17, v19
     814:	tbnz	w11, #0x4, 0x86c
     818:	tbnz	w11, #0x5, 0x878
     81c:	add.2d	v2, v2, v4
     820:	shl.2d	v2, v2, #0x2
     824:	add.2d	v2, v17, v2
     828:	tbnz	w11, #0x6, 0x890
     82c:	tbz	w11, #0x7, 0x794
     830:	b	0x89c
     834:	fmov	x11, d21
     838:	str	s20, [x11]
     83c:	and	w11, w9, #0xff
     840:	tbz	w11, #0x1, 0x7dc
     844:	mov.d	x12, v21[1]
     848:	st1.s	{ v20 }[1], [x12]
     84c:	add.2d	v21, v2, v5
     850:	shl.2d	v21, v21, #0x2
     854:	add.2d	v21, v17, v21
     858:	tbz	w11, #0x2, 0x7ec
     85c:	fmov	x12, d21
     860:	st1.s	{ v20 }[2], [x12]
     864:	tbnz	w11, #0x3, 0x7f0
     868:	b	0x7f8
     86c:	fmov	x12, d19
     870:	str	s18, [x12]
     874:	tbz	w11, #0x5, 0x81c
     878:	mov.d	x12, v19[1]
     87c:	st1.s	{ v18 }[1], [x12]
     880:	add.2d	v2, v2, v4
     884:	shl.2d	v2, v2, #0x2
     888:	add.2d	v2, v17, v2
     88c:	tbz	w11, #0x6, 0x82c
     890:	fmov	x12, d2
     894:	st1.s	{ v18 }[2], [x12]
     898:	tbz	w11, #0x7, 0x794
     89c:	mov.d	x11, v2[1]
     8a0:	st1.s	{ v18 }[3], [x11]
     8a4:	b	0x794
     8a8:	ldp	d9, d8, [sp, #0x20]
     8ac:	ldp	d11, d10, [sp, #0x10]
     8b0:	add	sp, sp, #0x30
     8b4:	ret
     8b8:	fmov	x8, d17
     8bc:	ldr	s5, [x8]
     8c0:	and.16b	v7, v0, v7
     8c4:	ushll2.2d	v16, v4, #0xe
     8c8:	tbz	w9, #0x1, 0x94
     8cc:	mov.d	x8, v17[1]
     8d0:	ld1.s	{ v5 }[1], [x8]
     8d4:	add.2d	v17, v3, v16
     8d8:	tbz	w9, #0x2, 0x9c
     8dc:	fmov	x8, d17
     8e0:	ld1.s	{ v5 }[2], [x8]
     8e4:	ushll.2d	v18, v7, #0xe
     8e8:	tbz	w9, #0x3, 0xa4
     8ec:	mov.d	x8, v17[1]
     8f0:	ld1.s	{ v5 }[3], [x8]
     8f4:	add.2d	v20, v3, v18
     8f8:	tbz	w9, #0x4, 0xac
     8fc:	fmov	x8, d20
     900:	ld1.s	{ v6 }[0], [x8]
     904:	ushll2.2d	v17, v7, #0xe
     908:	tbz	w9, #0x5, 0xb4
     90c:	mov.d	x8, v20[1]
     910:	ld1.s	{ v6 }[1], [x8]
     914:	ldr	x8, [x1, #0x88]
     918:	add.2d	v20, v3, v17
     91c:	tbz	w9, #0x6, 0xc0
     920:	fmov	x10, d20
     924:	ld1.s	{ v6 }[2], [x10]
     928:	tbnz	w9, #0x7, 0xc4
     92c:	b	0xcc
     930:	fmov	x12, d23
     934:	ldr	s20, [x12]
     938:	tbz	w11, #0x1, 0x10c
     93c:	mov.d	x12, v23[1]
     940:	ld1.s	{ v20 }[1], [x12]
     944:	add.2d	v23, v22, v16
     948:	tbz	w11, #0x2, 0x114
     94c:	fmov	x12, d23
     950:	ld1.s	{ v20 }[2], [x12]
     954:	tbz	w11, #0x3, 0x118
     958:	mov.d	x12, v23[1]
     95c:	ld1.s	{ v20 }[3], [x12]
     960:	add.2d	v23, v22, v18
     964:	tbz	w11, #0x4, 0x120
     968:	fmov	x12, d23
     96c:	ld1.s	{ v21 }[0], [x12]
     970:	tbz	w11, #0x5, 0x124
     974:	mov.d	x12, v23[1]
     978:	ld1.s	{ v21 }[1], [x12]
     97c:	add.2d	v22, v22, v17
     980:	tbz	w11, #0x6, 0x12c
     984:	fmov	x12, d22
     988:	ld1.s	{ v21 }[2], [x12]
     98c:	tbnz	w11, #0x7, 0x130
     990:	b	0x138
     994:	fmov	x12, d25
     998:	ldr	s22, [x12]
     99c:	tbz	w11, #0x1, 0x170
     9a0:	mov.d	x12, v25[1]
     9a4:	ld1.s	{ v22 }[1], [x12]
     9a8:	add.2d	v25, v24, v16
     9ac:	tbz	w11, #0x2, 0x178
     9b0:	fmov	x12, d25
     9b4:	ld1.s	{ v22 }[2], [x12]
     9b8:	tbz	w11, #0x3, 0x17c
     9bc:	mov.d	x12, v25[1]
     9c0:	ld1.s	{ v22 }[3], [x12]
     9c4:	add.2d	v25, v24, v18
     9c8:	tbz	w11, #0x4, 0x184
     9cc:	fmov	x12, d25
     9d0:	ld1.s	{ v23 }[0], [x12]
     9d4:	tbz	w11, #0x5, 0x188
     9d8:	mov.d	x12, v25[1]
     9dc:	ld1.s	{ v23 }[1], [x12]
     9e0:	add.2d	v24, v24, v17
     9e4:	tbz	w11, #0x6, 0x190
     9e8:	fmov	x12, d24
     9ec:	ld1.s	{ v23 }[2], [x12]
     9f0:	tbnz	w11, #0x7, 0x194
     9f4:	b	0x19c
     9f8:	fmov	x12, d26
     9fc:	ldr	s19, [x12]
     a00:	tbz	w11, #0x1, 0x1d4
     a04:	mov.d	x12, v26[1]
     a08:	ld1.s	{ v19 }[1], [x12]
     a0c:	add.2d	v16, v25, v16
     a10:	tbz	w11, #0x2, 0x1dc
     a14:	fmov	x12, d16
     a18:	ld1.s	{ v19 }[2], [x12]
     a1c:	tbz	w11, #0x3, 0x1e0
     a20:	mov.d	x12, v16[1]
     a24:	ld1.s	{ v19 }[3], [x12]
     a28:	add.2d	v16, v25, v18
     a2c:	tbz	w11, #0x4, 0x1e8
     a30:	fmov	x12, d16
     a34:	ld1.s	{ v24 }[0], [x12]
     a38:	tbz	w11, #0x5, 0x1ec
     a3c:	mov.d	x12, v16[1]
     a40:	ld1.s	{ v24 }[1], [x12]
     a44:	add.2d	v28, v25, v17
     a48:	tbnz	w11, #0x6, 0x1f4
     a4c:	b	0x1fc
_llm_rows.packet_batch.blocks:
     a50:	cbz	w3, 0xba8
     a54:	sub	sp, sp, #0x70
     a58:	stp	x28, x27, [sp, #0x10]
     a5c:	stp	x26, x25, [sp, #0x20]
     a60:	stp	x24, x23, [sp, #0x30]
     a64:	stp	x22, x21, [sp, #0x40]
     a68:	stp	x20, x19, [sp, #0x50]
     a6c:	stp	x29, x30, [sp, #0x60]
     a70:	mov	x19, x3
     a74:	mov	x20, x2
     a78:	mov	x21, x0
     a7c:	mov	w22, #0x0
     a80:	ldp	w24, w8, [x2, #0x2c]
     a84:	stp	w3, w8, [sp, #0x8]
     a88:	ldp	w25, w26, [x2]
     a8c:	ldp	w28, w27, [x2, #0x8]
     a90:	str	w24, [sp, #0x4]
     a94:	b	0xadc
     a98:	mov	w8, #0x3f8
     a9c:	str	w8, [x20, #0x24]
     aa0:	ldp	w24, w19, [sp, #0x4]
     aa4:	add	w8, w25, #0x1
     aa8:	cmp	w8, w24
     aac:	cset	w8, eq
     ab0:	csinc	w25, wzr, w25, eq
     ab4:	cinc	w9, w26, eq
     ab8:	ldr	w10, [sp, #0xc]
     abc:	cmp	w9, w10
     ac0:	cset	w10, eq
     ac4:	ands	w8, w8, w10
     ac8:	csel	w26, wzr, w9, ne
     acc:	add	w28, w28, w8
     ad0:	add	w22, w22, #0x1
     ad4:	cmp	w22, w19
     ad8:	b.eq	0xb8c
     adc:	ubfiz	x8, x25, #10, #32
     ae0:	cmp	x8, x27
     ae4:	csel	x9, x8, xzr, ls
     ae8:	subs	x10, x27, x9
     aec:	cmp	x10, #0x400
     af0:	mov	w11, #0x400
     af4:	csel	x10, x10, x11, lo
     af8:	cmp	x27, x9
     afc:	stp	w25, w26, [x20]
     b00:	str	w28, [x20, #0x8]
     b04:	ccmp	x8, x27, #0x2, hi
     b08:	csel	x23, x10, xzr, ls
     b0c:	cmp	x23, #0x400
     b10:	b.lo	0xb3c
     b14:	mov	w23, #0x0
     b18:	str	w23, [x20, #0x24]
     b1c:	mov	x0, x21
     b20:	mov	x1, x20
     b24:	mov	w2, #0x8
     b28:	bl	_llm_rows
     b2c:	add	w23, w23, #0x8
     b30:	cmp	w23, #0x400
     b34:	b.ne	0xb18
     b38:	b	0xaa4
     b3c:	lsr	x8, x23, #3
     b40:	lsl	w24, w8, #3
     b44:	cmp	x23, #0x8
     b48:	b.lo	0xb70
     b4c:	mov	w19, #0x0
     b50:	str	w19, [x20, #0x24]
     b54:	mov	x0, x21
     b58:	mov	x1, x20
     b5c:	mov	w2, #0x8
     b60:	bl	_llm_rows
     b64:	add	w19, w19, #0x8
     b68:	cmp	w24, w19
     b6c:	b.ne	0xb50
     b70:	and	w2, w23, #0x7
     b74:	cbz	w2, 0xa98
     b78:	str	w24, [x20, #0x24]
     b7c:	mov	x0, x21
     b80:	mov	x1, x20
     b84:	bl	_llm_rows
     b88:	b	0xa98
     b8c:	ldp	x29, x30, [sp, #0x60]
     b90:	ldp	x20, x19, [sp, #0x50]
     b94:	ldp	x22, x21, [sp, #0x40]
     b98:	ldp	x24, x23, [sp, #0x30]
     b9c:	ldp	x26, x25, [sp, #0x20]
     ba0:	ldp	x28, x27, [sp, #0x10]
     ba4:	add	sp, sp, #0x70
     ba8:	ret

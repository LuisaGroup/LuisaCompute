; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [16384 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [16384 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.spill4 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill4, align 4
  %.spill5 = alloca i64, align 8
  store i64 0, ptr %.spill5, align 4
  %.spill6 = alloca i64, align 8
  store i64 0, ptr %.spill6, align 4
  %.spill7 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill7, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.slot8 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot8, align 32
  %.slot9 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot9, align 32
  %.slot10 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot10, align 32
  %.slot11 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot11, align 32
  %.spill12 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill12, align 4
  %tile_snapshot.spill13 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill13, align 64
  %.slot14 = alloca i64, align 8
  store i64 0, ptr %.slot14, align 4
  %.spill15 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill15, align 4
  %.slot16 = alloca i64, align 8
  store i64 0, ptr %.slot16, align 4
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert17 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat18 = shufflevector <8 x i32> %.splatinsert17, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat18, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 1024
  %.splatinsert19 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat20 = shufflevector <8 x i32> %.splatinsert19, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat20, %41
  %44 = mul i32 %32, 1
  %.splatinsert21 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat22 = shufflevector <8 x i32> %.splatinsert21, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat22, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert23 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat24 = shufflevector <8 x i32> %.splatinsert23, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat24, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert25 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat26 = shufflevector <8 x i32> %.splatinsert25, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat26
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %65 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %66 = extractvalue { <8 x ptr>, <8 x i64> } %64, 0
  %67 = select <8 x i1> %51, <8 x ptr> %65, <8 x ptr> %66
  %68 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %69 = extractvalue { <8 x ptr>, <8 x i64> } %64, 1
  %70 = select <8 x i1> %51, <8 x i64> %68, <8 x i64> %69
  %71 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %67, 0
  %72 = insertvalue { <8 x ptr>, <8 x i64> } %71, <8 x i64> %70, 1
  store { <8 x ptr>, <8 x i64> } %72, ptr %tile_snapshot.spill, align 64
  store float 0.000000e+00, ptr %.spill4, align 4
  %73 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> zeroinitializer
  %74 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %75 = sdiv <8 x i64> %73, %74
  store i64 0, ptr %.spill5, align 4
  store i64 0, ptr %.spill6, align 4
  %76 = add <8 x i64> zeroinitializer, %75
  %77 = add <8 x i64> %63, zeroinitializer
  %78 = add <8 x i64> zeroinitializer, %77
  %79 = add <8 x i64> zeroinitializer, %76
  %80 = mul <8 x i64> %78, splat (i64 4096)
  %81 = load <8 x i64>, ptr %.spill7, align 64
  %82 = select <8 x i1> %51, <8 x i64> %80, <8 x i64> %81
  store <8 x i64> %82, ptr %.spill7, align 64
  %83 = add <8 x i64> %80, %79
  %84 = extractvalue { ptr, i64 } %9, 0
  %85 = mul <8 x i64> %83, splat (i64 4)
  %86 = getelementptr i8, ptr %84, <8 x i64> %85
  %87 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %86, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %89 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %90 = add <8 x i64> %89, zeroinitializer
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %88, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = extractelement <8 x ptr> %93, i32 0
  %96 = extractelement <8 x i64> %94, i32 0
  %97 = sub i64 %96, 0
  %98 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %99 = select i1 %98, i64 %97, i64 0
  %private.contiguous.address = getelementptr i8, ptr %95, i64 %99
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %100 = select <8 x i1> %51, <8 x float> %87, <8 x float> %private.contiguous.preserve
  store <8 x float> %100, ptr %private.contiguous.address, align 4
  %101 = fmul <8 x float> %87, %87
  %102 = select <8 x i1> %51, <8 x i64> <i64 8, i64 9, i64 10, i64 11, i64 12, i64 13, i64 14, i64 15>, <8 x i64> zeroinitializer
  %103 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %104 = sdiv <8 x i64> %102, %103
  %105 = add <8 x i64> zeroinitializer, %104
  %106 = add <8 x i64> zeroinitializer, %105
  %107 = add <8 x i64> %80, %106
  %108 = extractvalue { ptr, i64 } %9, 0
  %109 = mul <8 x i64> %107, splat (i64 4)
  %110 = getelementptr i8, ptr %108, <8 x i64> %109
  %111 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %110, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %112 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %113 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %114 = add <8 x i64> %113, splat (i64 32)
  %115 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %112, 0
  %116 = insertvalue { <8 x ptr>, <8 x i64> } %115, <8 x i64> %114, 1
  %117 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %118 = extractvalue { <8 x ptr>, <8 x i64> } %116, 1
  %119 = extractelement <8 x ptr> %117, i32 0
  %120 = extractelement <8 x i64> %118, i32 0
  %121 = sub i64 %120, 0
  %122 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %123 = select i1 %122, i64 %121, i64 0
  %private.contiguous.address27 = getelementptr i8, ptr %119, i64 %123
  %private.contiguous.preserve28 = load <8 x float>, ptr %private.contiguous.address27, align 4
  %124 = select <8 x i1> %51, <8 x float> %111, <8 x float> %private.contiguous.preserve28
  store <8 x float> %124, ptr %private.contiguous.address27, align 4
  %125 = fmul <8 x float> %111, %111
  %126 = select <8 x i1> %51, <8 x i64> <i64 16, i64 17, i64 18, i64 19, i64 20, i64 21, i64 22, i64 23>, <8 x i64> zeroinitializer
  %127 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %128 = sdiv <8 x i64> %126, %127
  %129 = add <8 x i64> zeroinitializer, %128
  %130 = add <8 x i64> zeroinitializer, %129
  %131 = add <8 x i64> %80, %130
  %132 = extractvalue { ptr, i64 } %9, 0
  %133 = mul <8 x i64> %131, splat (i64 4)
  %134 = getelementptr i8, ptr %132, <8 x i64> %133
  %135 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %134, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %136 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %138 = add <8 x i64> %137, splat (i64 64)
  %139 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %136, 0
  %140 = insertvalue { <8 x ptr>, <8 x i64> } %139, <8 x i64> %138, 1
  %141 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %140, 1
  %143 = extractelement <8 x ptr> %141, i32 0
  %144 = extractelement <8 x i64> %142, i32 0
  %145 = sub i64 %144, 0
  %146 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %147 = select i1 %146, i64 %145, i64 0
  %private.contiguous.address29 = getelementptr i8, ptr %143, i64 %147
  %private.contiguous.preserve30 = load <8 x float>, ptr %private.contiguous.address29, align 4
  %148 = select <8 x i1> %51, <8 x float> %135, <8 x float> %private.contiguous.preserve30
  store <8 x float> %148, ptr %private.contiguous.address29, align 4
  %149 = fmul <8 x float> %135, %135
  %150 = select <8 x i1> %51, <8 x i64> <i64 24, i64 25, i64 26, i64 27, i64 28, i64 29, i64 30, i64 31>, <8 x i64> zeroinitializer
  %151 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %152 = sdiv <8 x i64> %150, %151
  %153 = add <8 x i64> zeroinitializer, %152
  %154 = add <8 x i64> zeroinitializer, %153
  %155 = add <8 x i64> %80, %154
  %156 = extractvalue { ptr, i64 } %9, 0
  %157 = mul <8 x i64> %155, splat (i64 4)
  %158 = getelementptr i8, ptr %156, <8 x i64> %157
  %159 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %158, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %160 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %162 = add <8 x i64> %161, splat (i64 96)
  %163 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %160, 0
  %164 = insertvalue { <8 x ptr>, <8 x i64> } %163, <8 x i64> %162, 1
  %165 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %164, 1
  %167 = extractelement <8 x ptr> %165, i32 0
  %168 = extractelement <8 x i64> %166, i32 0
  %169 = sub i64 %168, 0
  %170 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %171 = select i1 %170, i64 %169, i64 0
  %private.contiguous.address31 = getelementptr i8, ptr %167, i64 %171
  %private.contiguous.preserve32 = load <8 x float>, ptr %private.contiguous.address31, align 4
  %172 = select <8 x i1> %51, <8 x float> %159, <8 x float> %private.contiguous.preserve32
  store <8 x float> %172, ptr %private.contiguous.address31, align 4
  %173 = fmul <8 x float> %159, %159
  store i64 4, ptr %.slot, align 4
  %174 = load <8 x float>, ptr %.slot8, align 32
  %175 = select <8 x i1> %51, <8 x float> %101, <8 x float> %174
  store <8 x float> %175, ptr %.slot8, align 32
  %176 = load <8 x float>, ptr %.slot9, align 32
  %177 = select <8 x i1> %51, <8 x float> %125, <8 x float> %176
  store <8 x float> %177, ptr %.slot9, align 32
  %178 = load <8 x float>, ptr %.slot10, align 32
  %179 = select <8 x i1> %51, <8 x float> %149, <8 x float> %178
  store <8 x float> %179, ptr %.slot10, align 32
  %180 = load <8 x float>, ptr %.slot11, align 32
  %181 = select <8 x i1> %51, <8 x float> %173, <8 x float> %180
  store <8 x float> %181, ptr %.slot11, align 32
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %182 = icmp slt i64 %.state, 512
  br i1 %182, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state33 = load i64, ptr %.slot, align 4
  %183 = add i64 %.state33, 0
  %184 = mul i64 %183, 8
  %.splatinsert34 = insertelement <8 x i64> poison, i64 %184, i64 0
  %.splat35 = shufflevector <8 x i64> %.splatinsert34, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %185 = add <8 x i64> %.splat35, %.spill.load
  %186 = select <8 x i1> %51, <8 x i64> %185, <8 x i64> zeroinitializer
  %187 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %188 = sdiv <8 x i64> %186, %187
  %.spill.load36 = load i64, ptr %.spill6, align 4
  %.splatinsert37 = insertelement <8 x i64> poison, i64 %.spill.load36, i64 0
  %.splat38 = shufflevector <8 x i64> %.splatinsert37, <8 x i64> poison, <8 x i32> zeroinitializer
  %189 = add <8 x i64> %.splat38, %188
  %190 = add <8 x i64> zeroinitializer, %189
  %.spill.load39 = load <8 x i64>, ptr %.spill7, align 64
  %191 = add <8 x i64> %.spill.load39, %190
  %192 = extractvalue { ptr, i64 } %9, 0
  %193 = mul <8 x i64> %191, splat (i64 4)
  %194 = getelementptr i8, ptr %192, <8 x i64> %193
  %195 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %194, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %196 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %197 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.splatinsert40 = insertelement <8 x i64> poison, i64 %183, i64 0
  %.splat41 = shufflevector <8 x i64> %.splatinsert40, <8 x i64> poison, <8 x i32> zeroinitializer
  %198 = mul <8 x i64> %.splat41, splat (i64 32)
  %199 = add <8 x i64> %197, %198
  %200 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %196, 0
  %201 = insertvalue { <8 x ptr>, <8 x i64> } %200, <8 x i64> %199, 1
  %202 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %203 = extractvalue { <8 x ptr>, <8 x i64> } %201, 1
  %204 = extractelement <8 x ptr> %202, i32 0
  %205 = extractelement <8 x i64> %203, i32 0
  %206 = sub i64 %205, 0
  %207 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %208 = select i1 %207, i64 %206, i64 0
  %private.contiguous.address42 = getelementptr i8, ptr %204, i64 %208
  %private.contiguous.preserve43 = load <8 x float>, ptr %private.contiguous.address42, align 4
  %209 = select <8 x i1> %51, <8 x float> %195, <8 x float> %private.contiguous.preserve43
  store <8 x float> %209, ptr %private.contiguous.address42, align 4
  %210 = fmul <8 x float> %195, %195
  %.state44 = load <8 x float>, ptr %.slot8, align 32
  %211 = fadd <8 x float> %.state44, %210
  %.state45 = load i64, ptr %.slot, align 4
  %212 = add i64 %.state45, 1
  %213 = mul i64 %212, 8
  %.splatinsert46 = insertelement <8 x i64> poison, i64 %213, i64 0
  %.splat47 = shufflevector <8 x i64> %.splatinsert46, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load48 = load <8 x i64>, ptr %.spill, align 64
  %214 = add <8 x i64> %.splat47, %.spill.load48
  %215 = select <8 x i1> %51, <8 x i64> %214, <8 x i64> zeroinitializer
  %216 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %217 = sdiv <8 x i64> %215, %216
  %.spill.load49 = load i64, ptr %.spill6, align 4
  %.splatinsert50 = insertelement <8 x i64> poison, i64 %.spill.load49, i64 0
  %.splat51 = shufflevector <8 x i64> %.splatinsert50, <8 x i64> poison, <8 x i32> zeroinitializer
  %218 = add <8 x i64> %.splat51, %217
  %219 = add <8 x i64> zeroinitializer, %218
  %.spill.load52 = load <8 x i64>, ptr %.spill7, align 64
  %220 = add <8 x i64> %.spill.load52, %219
  %221 = extractvalue { ptr, i64 } %9, 0
  %222 = mul <8 x i64> %220, splat (i64 4)
  %223 = getelementptr i8, ptr %221, <8 x i64> %222
  %224 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %223, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load53 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %225 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 0
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 1
  %.splatinsert54 = insertelement <8 x i64> poison, i64 %212, i64 0
  %.splat55 = shufflevector <8 x i64> %.splatinsert54, <8 x i64> poison, <8 x i32> zeroinitializer
  %227 = mul <8 x i64> %.splat55, splat (i64 32)
  %228 = add <8 x i64> %226, %227
  %229 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %225, 0
  %230 = insertvalue { <8 x ptr>, <8 x i64> } %229, <8 x i64> %228, 1
  %231 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %232 = extractvalue { <8 x ptr>, <8 x i64> } %230, 1
  %233 = extractelement <8 x ptr> %231, i32 0
  %234 = extractelement <8 x i64> %232, i32 0
  %235 = sub i64 %234, 0
  %236 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %237 = select i1 %236, i64 %235, i64 0
  %private.contiguous.address56 = getelementptr i8, ptr %233, i64 %237
  %private.contiguous.preserve57 = load <8 x float>, ptr %private.contiguous.address56, align 4
  %238 = select <8 x i1> %51, <8 x float> %224, <8 x float> %private.contiguous.preserve57
  store <8 x float> %238, ptr %private.contiguous.address56, align 4
  %239 = fmul <8 x float> %224, %224
  %.state58 = load <8 x float>, ptr %.slot9, align 32
  %240 = fadd <8 x float> %.state58, %239
  %.state59 = load i64, ptr %.slot, align 4
  %241 = add i64 %.state59, 2
  %242 = mul i64 %241, 8
  %.splatinsert60 = insertelement <8 x i64> poison, i64 %242, i64 0
  %.splat61 = shufflevector <8 x i64> %.splatinsert60, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load62 = load <8 x i64>, ptr %.spill, align 64
  %243 = add <8 x i64> %.splat61, %.spill.load62
  %244 = select <8 x i1> %51, <8 x i64> %243, <8 x i64> zeroinitializer
  %245 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %246 = sdiv <8 x i64> %244, %245
  %.spill.load63 = load i64, ptr %.spill6, align 4
  %.splatinsert64 = insertelement <8 x i64> poison, i64 %.spill.load63, i64 0
  %.splat65 = shufflevector <8 x i64> %.splatinsert64, <8 x i64> poison, <8 x i32> zeroinitializer
  %247 = add <8 x i64> %.splat65, %246
  %248 = add <8 x i64> zeroinitializer, %247
  %.spill.load66 = load <8 x i64>, ptr %.spill7, align 64
  %249 = add <8 x i64> %.spill.load66, %248
  %250 = extractvalue { ptr, i64 } %9, 0
  %251 = mul <8 x i64> %249, splat (i64 4)
  %252 = getelementptr i8, ptr %250, <8 x i64> %251
  %253 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %252, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load67 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load67, 0
  %255 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load67, 1
  %.splatinsert68 = insertelement <8 x i64> poison, i64 %241, i64 0
  %.splat69 = shufflevector <8 x i64> %.splatinsert68, <8 x i64> poison, <8 x i32> zeroinitializer
  %256 = mul <8 x i64> %.splat69, splat (i64 32)
  %257 = add <8 x i64> %255, %256
  %258 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %254, 0
  %259 = insertvalue { <8 x ptr>, <8 x i64> } %258, <8 x i64> %257, 1
  %260 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %259, 1
  %262 = extractelement <8 x ptr> %260, i32 0
  %263 = extractelement <8 x i64> %261, i32 0
  %264 = sub i64 %263, 0
  %265 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %266 = select i1 %265, i64 %264, i64 0
  %private.contiguous.address70 = getelementptr i8, ptr %262, i64 %266
  %private.contiguous.preserve71 = load <8 x float>, ptr %private.contiguous.address70, align 4
  %267 = select <8 x i1> %51, <8 x float> %253, <8 x float> %private.contiguous.preserve71
  store <8 x float> %267, ptr %private.contiguous.address70, align 4
  %268 = fmul <8 x float> %253, %253
  %.state72 = load <8 x float>, ptr %.slot10, align 32
  %269 = fadd <8 x float> %.state72, %268
  %.state73 = load i64, ptr %.slot, align 4
  %270 = add i64 %.state73, 3
  %271 = mul i64 %270, 8
  %.splatinsert74 = insertelement <8 x i64> poison, i64 %271, i64 0
  %.splat75 = shufflevector <8 x i64> %.splatinsert74, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load76 = load <8 x i64>, ptr %.spill, align 64
  %272 = add <8 x i64> %.splat75, %.spill.load76
  %273 = select <8 x i1> %51, <8 x i64> %272, <8 x i64> zeroinitializer
  %274 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %275 = sdiv <8 x i64> %273, %274
  %.spill.load77 = load i64, ptr %.spill6, align 4
  %.splatinsert78 = insertelement <8 x i64> poison, i64 %.spill.load77, i64 0
  %.splat79 = shufflevector <8 x i64> %.splatinsert78, <8 x i64> poison, <8 x i32> zeroinitializer
  %276 = add <8 x i64> %.splat79, %275
  %277 = add <8 x i64> zeroinitializer, %276
  %.spill.load80 = load <8 x i64>, ptr %.spill7, align 64
  %278 = add <8 x i64> %.spill.load80, %277
  %279 = extractvalue { ptr, i64 } %9, 0
  %280 = mul <8 x i64> %278, splat (i64 4)
  %281 = getelementptr i8, ptr %279, <8 x i64> %280
  %282 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %281, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load81 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %283 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load81, 0
  %284 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load81, 1
  %.splatinsert82 = insertelement <8 x i64> poison, i64 %270, i64 0
  %.splat83 = shufflevector <8 x i64> %.splatinsert82, <8 x i64> poison, <8 x i32> zeroinitializer
  %285 = mul <8 x i64> %.splat83, splat (i64 32)
  %286 = add <8 x i64> %284, %285
  %287 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %283, 0
  %288 = insertvalue { <8 x ptr>, <8 x i64> } %287, <8 x i64> %286, 1
  %289 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %290 = extractvalue { <8 x ptr>, <8 x i64> } %288, 1
  %291 = extractelement <8 x ptr> %289, i32 0
  %292 = extractelement <8 x i64> %290, i32 0
  %293 = sub i64 %292, 0
  %294 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %295 = select i1 %294, i64 %293, i64 0
  %private.contiguous.address84 = getelementptr i8, ptr %291, i64 %295
  %private.contiguous.preserve85 = load <8 x float>, ptr %private.contiguous.address84, align 4
  %296 = select <8 x i1> %51, <8 x float> %282, <8 x float> %private.contiguous.preserve85
  store <8 x float> %296, ptr %private.contiguous.address84, align 4
  %297 = fmul <8 x float> %282, %282
  %.state86 = load <8 x float>, ptr %.slot11, align 32
  %298 = fadd <8 x float> %.state86, %297
  %.state87 = load i64, ptr %.slot, align 4
  %299 = add i64 %.state87, 4
  store i64 %299, ptr %.slot, align 4
  %300 = load <8 x float>, ptr %.slot8, align 32
  %301 = select <8 x i1> %51, <8 x float> %211, <8 x float> %300
  store <8 x float> %301, ptr %.slot8, align 32
  %302 = load <8 x float>, ptr %.slot9, align 32
  %303 = select <8 x i1> %51, <8 x float> %240, <8 x float> %302
  store <8 x float> %303, ptr %.slot9, align 32
  %304 = load <8 x float>, ptr %.slot10, align 32
  %305 = select <8 x i1> %51, <8 x float> %269, <8 x float> %304
  store <8 x float> %305, ptr %.slot10, align 32
  %306 = load <8 x float>, ptr %.slot11, align 32
  %307 = select <8 x i1> %51, <8 x float> %298, <8 x float> %306
  store <8 x float> %307, ptr %.slot11, align 32
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %.state88 = load <8 x float>, ptr %.slot8, align 32
  %.state89 = load <8 x float>, ptr %.slot9, align 32
  %308 = fadd <8 x float> %.state88, %.state89
  %.state90 = load <8 x float>, ptr %.slot10, align 32
  %309 = fadd <8 x float> %308, %.state90
  %.state91 = load <8 x float>, ptr %.slot11, align 32
  %310 = fadd <8 x float> %309, %.state91
  %.spill.load92 = load <8 x i64>, ptr %.spill, align 64
  %311 = trunc <8 x i64> %.spill.load92 to <8 x i32>
  %312 = xor <8 x i32> %311, splat (i32 1)
  %313 = extractelement <8 x i32> %312, i64 0
  %314 = icmp ult i32 %313, 8
  %315 = select i1 %314, i32 %313, i32 0
  %316 = extractelement <8 x i1> %51, i32 %315
  %317 = extractelement <8 x i1> %51, i64 0
  %318 = and i1 %314, %316
  %319 = and i1 %317, %318
  %320 = extractelement <8 x float> %310, i32 %315
  %321 = select i1 %319, float %320, float 0.000000e+00
  %322 = insertelement <8 x float> poison, float %321, i64 0
  %323 = xor i1 %319, true
  %324 = and i1 %317, %323
  %325 = insertelement <8 x i1> poison, i1 %324, i64 0
  %326 = extractelement <8 x i32> %312, i64 1
  %327 = icmp ult i32 %326, 8
  %328 = select i1 %327, i32 %326, i32 0
  %329 = extractelement <8 x i1> %51, i32 %328
  %330 = extractelement <8 x i1> %51, i64 1
  %331 = and i1 %327, %329
  %332 = and i1 %330, %331
  %333 = extractelement <8 x float> %310, i32 %328
  %334 = select i1 %332, float %333, float 0.000000e+00
  %335 = insertelement <8 x float> %322, float %334, i64 1
  %336 = xor i1 %332, true
  %337 = and i1 %330, %336
  %338 = insertelement <8 x i1> %325, i1 %337, i64 1
  %339 = extractelement <8 x i32> %312, i64 2
  %340 = icmp ult i32 %339, 8
  %341 = select i1 %340, i32 %339, i32 0
  %342 = extractelement <8 x i1> %51, i32 %341
  %343 = extractelement <8 x i1> %51, i64 2
  %344 = and i1 %340, %342
  %345 = and i1 %343, %344
  %346 = extractelement <8 x float> %310, i32 %341
  %347 = select i1 %345, float %346, float 0.000000e+00
  %348 = insertelement <8 x float> %335, float %347, i64 2
  %349 = xor i1 %345, true
  %350 = and i1 %343, %349
  %351 = insertelement <8 x i1> %338, i1 %350, i64 2
  %352 = extractelement <8 x i32> %312, i64 3
  %353 = icmp ult i32 %352, 8
  %354 = select i1 %353, i32 %352, i32 0
  %355 = extractelement <8 x i1> %51, i32 %354
  %356 = extractelement <8 x i1> %51, i64 3
  %357 = and i1 %353, %355
  %358 = and i1 %356, %357
  %359 = extractelement <8 x float> %310, i32 %354
  %360 = select i1 %358, float %359, float 0.000000e+00
  %361 = insertelement <8 x float> %348, float %360, i64 3
  %362 = xor i1 %358, true
  %363 = and i1 %356, %362
  %364 = insertelement <8 x i1> %351, i1 %363, i64 3
  %365 = extractelement <8 x i32> %312, i64 4
  %366 = icmp ult i32 %365, 8
  %367 = select i1 %366, i32 %365, i32 0
  %368 = extractelement <8 x i1> %51, i32 %367
  %369 = extractelement <8 x i1> %51, i64 4
  %370 = and i1 %366, %368
  %371 = and i1 %369, %370
  %372 = extractelement <8 x float> %310, i32 %367
  %373 = select i1 %371, float %372, float 0.000000e+00
  %374 = insertelement <8 x float> %361, float %373, i64 4
  %375 = xor i1 %371, true
  %376 = and i1 %369, %375
  %377 = insertelement <8 x i1> %364, i1 %376, i64 4
  %378 = extractelement <8 x i32> %312, i64 5
  %379 = icmp ult i32 %378, 8
  %380 = select i1 %379, i32 %378, i32 0
  %381 = extractelement <8 x i1> %51, i32 %380
  %382 = extractelement <8 x i1> %51, i64 5
  %383 = and i1 %379, %381
  %384 = and i1 %382, %383
  %385 = extractelement <8 x float> %310, i32 %380
  %386 = select i1 %384, float %385, float 0.000000e+00
  %387 = insertelement <8 x float> %374, float %386, i64 5
  %388 = xor i1 %384, true
  %389 = and i1 %382, %388
  %390 = insertelement <8 x i1> %377, i1 %389, i64 5
  %391 = extractelement <8 x i32> %312, i64 6
  %392 = icmp ult i32 %391, 8
  %393 = select i1 %392, i32 %391, i32 0
  %394 = extractelement <8 x i1> %51, i32 %393
  %395 = extractelement <8 x i1> %51, i64 6
  %396 = and i1 %392, %394
  %397 = and i1 %395, %396
  %398 = extractelement <8 x float> %310, i32 %393
  %399 = select i1 %397, float %398, float 0.000000e+00
  %400 = insertelement <8 x float> %387, float %399, i64 6
  %401 = xor i1 %397, true
  %402 = and i1 %395, %401
  %403 = insertelement <8 x i1> %390, i1 %402, i64 6
  %404 = extractelement <8 x i32> %312, i64 7
  %405 = icmp ult i32 %404, 8
  %406 = select i1 %405, i32 %404, i32 0
  %407 = extractelement <8 x i1> %51, i32 %406
  %408 = extractelement <8 x i1> %51, i64 7
  %409 = and i1 %405, %407
  %410 = and i1 %408, %409
  %411 = extractelement <8 x float> %310, i32 %406
  %412 = select i1 %410, float %411, float 0.000000e+00
  %413 = insertelement <8 x float> %400, float %412, i64 7
  %414 = xor i1 %410, true
  %415 = and i1 %408, %414
  %416 = insertelement <8 x i1> %403, i1 %415, i64 7
  %417 = fadd <8 x float> %310, %413
  %418 = xor <8 x i32> %311, splat (i32 2)
  %419 = extractelement <8 x i32> %418, i64 0
  %420 = icmp ult i32 %419, 8
  %421 = select i1 %420, i32 %419, i32 0
  %422 = extractelement <8 x i1> %51, i32 %421
  %423 = extractelement <8 x i1> %51, i64 0
  %424 = and i1 %420, %422
  %425 = and i1 %423, %424
  %426 = extractelement <8 x float> %417, i32 %421
  %427 = select i1 %425, float %426, float 0.000000e+00
  %428 = insertelement <8 x float> poison, float %427, i64 0
  %429 = xor i1 %425, true
  %430 = and i1 %423, %429
  %431 = insertelement <8 x i1> poison, i1 %430, i64 0
  %432 = extractelement <8 x i32> %418, i64 1
  %433 = icmp ult i32 %432, 8
  %434 = select i1 %433, i32 %432, i32 0
  %435 = extractelement <8 x i1> %51, i32 %434
  %436 = extractelement <8 x i1> %51, i64 1
  %437 = and i1 %433, %435
  %438 = and i1 %436, %437
  %439 = extractelement <8 x float> %417, i32 %434
  %440 = select i1 %438, float %439, float 0.000000e+00
  %441 = insertelement <8 x float> %428, float %440, i64 1
  %442 = xor i1 %438, true
  %443 = and i1 %436, %442
  %444 = insertelement <8 x i1> %431, i1 %443, i64 1
  %445 = extractelement <8 x i32> %418, i64 2
  %446 = icmp ult i32 %445, 8
  %447 = select i1 %446, i32 %445, i32 0
  %448 = extractelement <8 x i1> %51, i32 %447
  %449 = extractelement <8 x i1> %51, i64 2
  %450 = and i1 %446, %448
  %451 = and i1 %449, %450
  %452 = extractelement <8 x float> %417, i32 %447
  %453 = select i1 %451, float %452, float 0.000000e+00
  %454 = insertelement <8 x float> %441, float %453, i64 2
  %455 = xor i1 %451, true
  %456 = and i1 %449, %455
  %457 = insertelement <8 x i1> %444, i1 %456, i64 2
  %458 = extractelement <8 x i32> %418, i64 3
  %459 = icmp ult i32 %458, 8
  %460 = select i1 %459, i32 %458, i32 0
  %461 = extractelement <8 x i1> %51, i32 %460
  %462 = extractelement <8 x i1> %51, i64 3
  %463 = and i1 %459, %461
  %464 = and i1 %462, %463
  %465 = extractelement <8 x float> %417, i32 %460
  %466 = select i1 %464, float %465, float 0.000000e+00
  %467 = insertelement <8 x float> %454, float %466, i64 3
  %468 = xor i1 %464, true
  %469 = and i1 %462, %468
  %470 = insertelement <8 x i1> %457, i1 %469, i64 3
  %471 = extractelement <8 x i32> %418, i64 4
  %472 = icmp ult i32 %471, 8
  %473 = select i1 %472, i32 %471, i32 0
  %474 = extractelement <8 x i1> %51, i32 %473
  %475 = extractelement <8 x i1> %51, i64 4
  %476 = and i1 %472, %474
  %477 = and i1 %475, %476
  %478 = extractelement <8 x float> %417, i32 %473
  %479 = select i1 %477, float %478, float 0.000000e+00
  %480 = insertelement <8 x float> %467, float %479, i64 4
  %481 = xor i1 %477, true
  %482 = and i1 %475, %481
  %483 = insertelement <8 x i1> %470, i1 %482, i64 4
  %484 = extractelement <8 x i32> %418, i64 5
  %485 = icmp ult i32 %484, 8
  %486 = select i1 %485, i32 %484, i32 0
  %487 = extractelement <8 x i1> %51, i32 %486
  %488 = extractelement <8 x i1> %51, i64 5
  %489 = and i1 %485, %487
  %490 = and i1 %488, %489
  %491 = extractelement <8 x float> %417, i32 %486
  %492 = select i1 %490, float %491, float 0.000000e+00
  %493 = insertelement <8 x float> %480, float %492, i64 5
  %494 = xor i1 %490, true
  %495 = and i1 %488, %494
  %496 = insertelement <8 x i1> %483, i1 %495, i64 5
  %497 = extractelement <8 x i32> %418, i64 6
  %498 = icmp ult i32 %497, 8
  %499 = select i1 %498, i32 %497, i32 0
  %500 = extractelement <8 x i1> %51, i32 %499
  %501 = extractelement <8 x i1> %51, i64 6
  %502 = and i1 %498, %500
  %503 = and i1 %501, %502
  %504 = extractelement <8 x float> %417, i32 %499
  %505 = select i1 %503, float %504, float 0.000000e+00
  %506 = insertelement <8 x float> %493, float %505, i64 6
  %507 = xor i1 %503, true
  %508 = and i1 %501, %507
  %509 = insertelement <8 x i1> %496, i1 %508, i64 6
  %510 = extractelement <8 x i32> %418, i64 7
  %511 = icmp ult i32 %510, 8
  %512 = select i1 %511, i32 %510, i32 0
  %513 = extractelement <8 x i1> %51, i32 %512
  %514 = extractelement <8 x i1> %51, i64 7
  %515 = and i1 %511, %513
  %516 = and i1 %514, %515
  %517 = extractelement <8 x float> %417, i32 %512
  %518 = select i1 %516, float %517, float 0.000000e+00
  %519 = insertelement <8 x float> %506, float %518, i64 7
  %520 = xor i1 %516, true
  %521 = and i1 %514, %520
  %522 = insertelement <8 x i1> %509, i1 %521, i64 7
  %523 = fadd <8 x float> %417, %519
  %524 = xor <8 x i32> %311, splat (i32 4)
  %525 = extractelement <8 x i32> %524, i64 0
  %526 = icmp ult i32 %525, 8
  %527 = select i1 %526, i32 %525, i32 0
  %528 = extractelement <8 x i1> %51, i32 %527
  %529 = extractelement <8 x i1> %51, i64 0
  %530 = and i1 %526, %528
  %531 = and i1 %529, %530
  %532 = extractelement <8 x float> %523, i32 %527
  %533 = select i1 %531, float %532, float 0.000000e+00
  %534 = insertelement <8 x float> poison, float %533, i64 0
  %535 = xor i1 %531, true
  %536 = and i1 %529, %535
  %537 = insertelement <8 x i1> poison, i1 %536, i64 0
  %538 = extractelement <8 x i32> %524, i64 1
  %539 = icmp ult i32 %538, 8
  %540 = select i1 %539, i32 %538, i32 0
  %541 = extractelement <8 x i1> %51, i32 %540
  %542 = extractelement <8 x i1> %51, i64 1
  %543 = and i1 %539, %541
  %544 = and i1 %542, %543
  %545 = extractelement <8 x float> %523, i32 %540
  %546 = select i1 %544, float %545, float 0.000000e+00
  %547 = insertelement <8 x float> %534, float %546, i64 1
  %548 = xor i1 %544, true
  %549 = and i1 %542, %548
  %550 = insertelement <8 x i1> %537, i1 %549, i64 1
  %551 = extractelement <8 x i32> %524, i64 2
  %552 = icmp ult i32 %551, 8
  %553 = select i1 %552, i32 %551, i32 0
  %554 = extractelement <8 x i1> %51, i32 %553
  %555 = extractelement <8 x i1> %51, i64 2
  %556 = and i1 %552, %554
  %557 = and i1 %555, %556
  %558 = extractelement <8 x float> %523, i32 %553
  %559 = select i1 %557, float %558, float 0.000000e+00
  %560 = insertelement <8 x float> %547, float %559, i64 2
  %561 = xor i1 %557, true
  %562 = and i1 %555, %561
  %563 = insertelement <8 x i1> %550, i1 %562, i64 2
  %564 = extractelement <8 x i32> %524, i64 3
  %565 = icmp ult i32 %564, 8
  %566 = select i1 %565, i32 %564, i32 0
  %567 = extractelement <8 x i1> %51, i32 %566
  %568 = extractelement <8 x i1> %51, i64 3
  %569 = and i1 %565, %567
  %570 = and i1 %568, %569
  %571 = extractelement <8 x float> %523, i32 %566
  %572 = select i1 %570, float %571, float 0.000000e+00
  %573 = insertelement <8 x float> %560, float %572, i64 3
  %574 = xor i1 %570, true
  %575 = and i1 %568, %574
  %576 = insertelement <8 x i1> %563, i1 %575, i64 3
  %577 = extractelement <8 x i32> %524, i64 4
  %578 = icmp ult i32 %577, 8
  %579 = select i1 %578, i32 %577, i32 0
  %580 = extractelement <8 x i1> %51, i32 %579
  %581 = extractelement <8 x i1> %51, i64 4
  %582 = and i1 %578, %580
  %583 = and i1 %581, %582
  %584 = extractelement <8 x float> %523, i32 %579
  %585 = select i1 %583, float %584, float 0.000000e+00
  %586 = insertelement <8 x float> %573, float %585, i64 4
  %587 = xor i1 %583, true
  %588 = and i1 %581, %587
  %589 = insertelement <8 x i1> %576, i1 %588, i64 4
  %590 = extractelement <8 x i32> %524, i64 5
  %591 = icmp ult i32 %590, 8
  %592 = select i1 %591, i32 %590, i32 0
  %593 = extractelement <8 x i1> %51, i32 %592
  %594 = extractelement <8 x i1> %51, i64 5
  %595 = and i1 %591, %593
  %596 = and i1 %594, %595
  %597 = extractelement <8 x float> %523, i32 %592
  %598 = select i1 %596, float %597, float 0.000000e+00
  %599 = insertelement <8 x float> %586, float %598, i64 5
  %600 = xor i1 %596, true
  %601 = and i1 %594, %600
  %602 = insertelement <8 x i1> %589, i1 %601, i64 5
  %603 = extractelement <8 x i32> %524, i64 6
  %604 = icmp ult i32 %603, 8
  %605 = select i1 %604, i32 %603, i32 0
  %606 = extractelement <8 x i1> %51, i32 %605
  %607 = extractelement <8 x i1> %51, i64 6
  %608 = and i1 %604, %606
  %609 = and i1 %607, %608
  %610 = extractelement <8 x float> %523, i32 %605
  %611 = select i1 %609, float %610, float 0.000000e+00
  %612 = insertelement <8 x float> %599, float %611, i64 6
  %613 = xor i1 %609, true
  %614 = and i1 %607, %613
  %615 = insertelement <8 x i1> %602, i1 %614, i64 6
  %616 = extractelement <8 x i32> %524, i64 7
  %617 = icmp ult i32 %616, 8
  %618 = select i1 %617, i32 %616, i32 0
  %619 = extractelement <8 x i1> %51, i32 %618
  %620 = extractelement <8 x i1> %51, i64 7
  %621 = and i1 %617, %619
  %622 = and i1 %620, %621
  %623 = extractelement <8 x float> %523, i32 %618
  %624 = select i1 %622, float %623, float 0.000000e+00
  %625 = insertelement <8 x float> %612, float %624, i64 7
  %626 = xor i1 %622, true
  %627 = and i1 %620, %626
  %628 = insertelement <8 x i1> %615, i1 %627, i64 7
  %629 = fadd <8 x float> %523, %625
  %630 = extractelement <8 x i1> %51, i32 0
  %631 = extractelement <8 x i1> %51, i64 0
  %632 = and i1 true, %630
  %633 = and i1 %631, %632
  %634 = extractelement <8 x float> %629, i32 0
  %635 = select i1 %633, float %634, float 0.000000e+00
  %636 = insertelement <8 x float> poison, float %635, i64 0
  %637 = xor i1 %633, true
  %638 = and i1 %631, %637
  %639 = insertelement <8 x i1> poison, i1 %638, i64 0
  %640 = extractelement <8 x i1> %51, i32 0
  %641 = extractelement <8 x i1> %51, i64 1
  %642 = and i1 true, %640
  %643 = and i1 %641, %642
  %644 = extractelement <8 x float> %629, i32 0
  %645 = select i1 %643, float %644, float 0.000000e+00
  %646 = insertelement <8 x float> %636, float %645, i64 1
  %647 = xor i1 %643, true
  %648 = and i1 %641, %647
  %649 = insertelement <8 x i1> %639, i1 %648, i64 1
  %650 = extractelement <8 x i1> %51, i32 0
  %651 = extractelement <8 x i1> %51, i64 2
  %652 = and i1 true, %650
  %653 = and i1 %651, %652
  %654 = extractelement <8 x float> %629, i32 0
  %655 = select i1 %653, float %654, float 0.000000e+00
  %656 = insertelement <8 x float> %646, float %655, i64 2
  %657 = xor i1 %653, true
  %658 = and i1 %651, %657
  %659 = insertelement <8 x i1> %649, i1 %658, i64 2
  %660 = extractelement <8 x i1> %51, i32 0
  %661 = extractelement <8 x i1> %51, i64 3
  %662 = and i1 true, %660
  %663 = and i1 %661, %662
  %664 = extractelement <8 x float> %629, i32 0
  %665 = select i1 %663, float %664, float 0.000000e+00
  %666 = insertelement <8 x float> %656, float %665, i64 3
  %667 = xor i1 %663, true
  %668 = and i1 %661, %667
  %669 = insertelement <8 x i1> %659, i1 %668, i64 3
  %670 = extractelement <8 x i1> %51, i32 0
  %671 = extractelement <8 x i1> %51, i64 4
  %672 = and i1 true, %670
  %673 = and i1 %671, %672
  %674 = extractelement <8 x float> %629, i32 0
  %675 = select i1 %673, float %674, float 0.000000e+00
  %676 = insertelement <8 x float> %666, float %675, i64 4
  %677 = xor i1 %673, true
  %678 = and i1 %671, %677
  %679 = insertelement <8 x i1> %669, i1 %678, i64 4
  %680 = extractelement <8 x i1> %51, i32 0
  %681 = extractelement <8 x i1> %51, i64 5
  %682 = and i1 true, %680
  %683 = and i1 %681, %682
  %684 = extractelement <8 x float> %629, i32 0
  %685 = select i1 %683, float %684, float 0.000000e+00
  %686 = insertelement <8 x float> %676, float %685, i64 5
  %687 = xor i1 %683, true
  %688 = and i1 %681, %687
  %689 = insertelement <8 x i1> %679, i1 %688, i64 5
  %690 = extractelement <8 x i1> %51, i32 0
  %691 = extractelement <8 x i1> %51, i64 6
  %692 = and i1 true, %690
  %693 = and i1 %691, %692
  %694 = extractelement <8 x float> %629, i32 0
  %695 = select i1 %693, float %694, float 0.000000e+00
  %696 = insertelement <8 x float> %686, float %695, i64 6
  %697 = xor i1 %693, true
  %698 = and i1 %691, %697
  %699 = insertelement <8 x i1> %689, i1 %698, i64 6
  %700 = extractelement <8 x i1> %51, i32 0
  %701 = extractelement <8 x i1> %51, i64 7
  %702 = and i1 true, %700
  %703 = and i1 %701, %702
  %704 = extractelement <8 x float> %629, i32 0
  %705 = select i1 %703, float %704, float 0.000000e+00
  %706 = insertelement <8 x float> %696, float %705, i64 7
  %707 = xor i1 %703, true
  %708 = and i1 %701, %707
  %709 = insertelement <8 x i1> %699, i1 %708, i64 7
  %710 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %711 = bitcast <8 x i1> %51 to i8
  %712 = call i8 @llvm.cttz.i8(i8 %711, i1 false)
  %713 = zext i8 %712 to i32
  %714 = select i1 %710, i32 %713, i32 0
  %715 = extractelement <8 x float> %706, i32 %714
  %.spill.load93 = load float, ptr %.spill4, align 4
  %716 = fadd float %.spill.load93, %715
  %717 = fdiv float %716, 4.096000e+03
  store float %717, ptr %.spill12, align 4
  %718 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %719 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %720 = extractvalue { <8 x ptr>, <8 x i64> } %718, 0
  %721 = select <8 x i1> %51, <8 x ptr> %719, <8 x ptr> %720
  %722 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %723 = extractvalue { <8 x ptr>, <8 x i64> } %718, 1
  %724 = select <8 x i1> %51, <8 x i64> %722, <8 x i64> %723
  %725 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %721, 0
  %726 = insertvalue { <8 x ptr>, <8 x i64> } %725, <8 x i64> %724, 1
  store { <8 x ptr>, <8 x i64> } %726, ptr %tile_snapshot.spill13, align 64
  store i64 0, ptr %.slot14, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state94 = load i64, ptr %.slot14, align 4
  %727 = icmp slt i64 %.state94, 512
  br i1 %727, label %direct.true95, label %direct.false96

direct.schedule.5:                                ; preds = %direct.true95
  %.state97 = load i64, ptr %.slot14, align 4
  %728 = mul i64 %.state97, 8
  %.splatinsert98 = insertelement <8 x i64> poison, i64 %728, i64 0
  %.splat99 = shufflevector <8 x i64> %.splatinsert98, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load100 = load <8 x i64>, ptr %.spill, align 64
  %729 = add <8 x i64> %.splat99, %.spill.load100
  %.spill.load101 = load i64, ptr %.spill5, align 4
  %730 = add i64 %.spill.load101, 0
  %731 = add <8 x i64> zeroinitializer, %729
  %732 = mul i64 %730, 4096
  %.splatinsert102 = insertelement <8 x i64> poison, i64 %732, i64 0
  %.splat103 = shufflevector <8 x i64> %.splatinsert102, <8 x i64> poison, <8 x i32> zeroinitializer
  %733 = add <8 x i64> %.splat103, %731
  %734 = extractvalue { ptr, i64 } %15, 0
  %735 = extractelement <8 x i64> %733, i32 0
  %736 = sub i64 %735, 0
  %737 = mul i64 %736, 4
  %buffer.contiguous.address = getelementptr i8, ptr %734, i64 %737
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load104 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %738 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load104, 0
  %739 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load104, 1
  %.state105 = load i64, ptr %.slot14, align 4
  %.splatinsert106 = insertelement <8 x i64> poison, i64 %.state105, i64 0
  %.splat107 = shufflevector <8 x i64> %.splatinsert106, <8 x i64> poison, <8 x i32> zeroinitializer
  %740 = mul <8 x i64> %.splat107, splat (i64 32)
  %741 = add <8 x i64> %739, %740
  %742 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %738, 0
  %743 = insertvalue { <8 x ptr>, <8 x i64> } %742, <8 x i64> %741, 1
  %744 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %745 = extractvalue { <8 x ptr>, <8 x i64> } %743, 1
  %746 = extractelement <8 x ptr> %744, i32 0
  %747 = extractelement <8 x i64> %745, i32 0
  %748 = sub i64 %747, 0
  %749 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %750 = select i1 %749, i64 %748, i64 0
  %private.contiguous.address108 = getelementptr i8, ptr %746, i64 %750
  %private.contiguous.preserve109 = load <8 x float>, ptr %private.contiguous.address108, align 4
  %751 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve109
  store <8 x float> %751, ptr %private.contiguous.address108, align 4
  %.state110 = load i64, ptr %.slot14, align 4
  %752 = add i64 %.state110, 1
  store i64 %752, ptr %.slot14, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false96
  %.spill.load111 = load float, ptr %.spill12, align 4
  %753 = fadd float %.spill.load111, 0x3EE4F8B580000000
  %754 = call float @llvm.sqrt.f32(float %753)
  store float %754, ptr %.spill15, align 4
  store i64 0, ptr %.slot16, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state112 = load i64, ptr %.slot16, align 4
  %755 = icmp slt i64 %.state112, 512
  br i1 %755, label %direct.true113, label %direct.false114

direct.schedule.8:                                ; preds = %direct.true113
  %.state115 = load i64, ptr %.slot16, align 4
  %756 = mul i64 %.state115, 8
  %.splatinsert116 = insertelement <8 x i64> poison, i64 %756, i64 0
  %.splat117 = shufflevector <8 x i64> %.splatinsert116, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load118 = load <8 x i64>, ptr %.spill, align 64
  %757 = add <8 x i64> %.splat117, %.spill.load118
  %758 = add <8 x i64> zeroinitializer, %757
  %.spill.load119 = load <8 x i64>, ptr %.spill7, align 64
  %759 = add <8 x i64> %.spill.load119, %758
  %tile_snapshot.spill.load120 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %760 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load120, 0
  %761 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load120, 1
  %.state121 = load i64, ptr %.slot16, align 4
  %.splatinsert122 = insertelement <8 x i64> poison, i64 %.state121, i64 0
  %.splat123 = shufflevector <8 x i64> %.splatinsert122, <8 x i64> poison, <8 x i32> zeroinitializer
  %762 = mul <8 x i64> %.splat123, splat (i64 32)
  %763 = add <8 x i64> %761, %762
  %764 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %760, 0
  %765 = insertvalue { <8 x ptr>, <8 x i64> } %764, <8 x i64> %763, 1
  %766 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %767 = extractvalue { <8 x ptr>, <8 x i64> } %765, 1
  %768 = extractelement <8 x ptr> %766, i32 0
  %769 = extractelement <8 x i64> %767, i32 0
  %770 = sub i64 %769, 0
  %771 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %772 = select i1 %771, i64 %770, i64 0
  %private.contiguous.address124 = getelementptr i8, ptr %768, i64 %772
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address124, align 4
  %773 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %.spill.load125 = load float, ptr %.spill15, align 4
  %.splatinsert126 = insertelement <8 x float> poison, float %.spill.load125, i64 0
  %.splat127 = shufflevector <8 x float> %.splatinsert126, <8 x float> poison, <8 x i32> zeroinitializer
  %774 = fdiv <8 x float> %773, %.splat127
  %tile_snapshot.spill.load128 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %775 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load128, 0
  %776 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load128, 1
  %.state129 = load i64, ptr %.slot16, align 4
  %.splatinsert130 = insertelement <8 x i64> poison, i64 %.state129, i64 0
  %.splat131 = shufflevector <8 x i64> %.splatinsert130, <8 x i64> poison, <8 x i32> zeroinitializer
  %777 = mul <8 x i64> %.splat131, splat (i64 32)
  %778 = add <8 x i64> %776, %777
  %779 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %775, 0
  %780 = insertvalue { <8 x ptr>, <8 x i64> } %779, <8 x i64> %778, 1
  %781 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %782 = extractvalue { <8 x ptr>, <8 x i64> } %780, 1
  %783 = extractelement <8 x ptr> %781, i32 0
  %784 = extractelement <8 x i64> %782, i32 0
  %785 = sub i64 %784, 0
  %786 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %787 = select i1 %786, i64 %785, i64 0
  %private.contiguous.address132 = getelementptr i8, ptr %783, i64 %787
  %private.contiguous.load133 = load <8 x float>, ptr %private.contiguous.address132, align 4
  %788 = select <8 x i1> %51, <8 x float> %private.contiguous.load133, <8 x float> zeroinitializer
  %789 = fmul <8 x float> %774, %788
  %790 = extractvalue { ptr, i64 } %27, 0
  %791 = extractelement <8 x i64> %759, i32 0
  %792 = sub i64 %791, 0
  %793 = mul i64 %792, 4
  %buffer.contiguous.address134 = getelementptr i8, ptr %790, i64 %793
  call void @llvm.masked.store.v8f32.p0(<8 x float> %789, ptr %buffer.contiguous.address134, i32 1, <8 x i1> %51)
  %.state135 = load i64, ptr %.slot16, align 4
  %794 = add i64 %.state135, 1
  store i64 %794, ptr %.slot16, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false114
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true95:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false96:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true113:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false114:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.9
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), i32 immarg, <8 x i1>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.sqrt.f32(float) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), i32 immarg, <8 x i1>) #3

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %tile_snapshot.local = alloca [16384 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [16384 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.spill4 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill4, align 4
  %.spill5 = alloca i64, align 8
  store i64 0, ptr %.spill5, align 4
  %.spill6 = alloca i64, align 8
  store i64 0, ptr %.spill6, align 4
  %.spill7 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill7, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.slot8 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot8, align 32
  %.slot9 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot9, align 32
  %.slot10 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot10, align 32
  %.slot11 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot11, align 32
  %.spill12 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill12, align 4
  %tile_snapshot.spill13 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill13, align 64
  %.slot14 = alloca i64, align 8
  store i64 0, ptr %.slot14, align 4
  %.spill15 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill15, align 4
  %.slot16 = alloca i64, align 8
  store i64 0, ptr %.slot16, align 4
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert17 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat18 = shufflevector <8 x i32> %.splatinsert17, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat18, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 1024
  %.splatinsert19 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat20 = shufflevector <8 x i32> %.splatinsert19, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat20, %41
  %44 = mul i32 %32, 1
  %.splatinsert21 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat22 = shufflevector <8 x i32> %.splatinsert21, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat22, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert23 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat24 = shufflevector <8 x i32> %.splatinsert23, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat24, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert25 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat26 = shufflevector <8 x i32> %.splatinsert25, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat26
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %65 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %66 = extractvalue { <8 x ptr>, <8 x i64> } %64, 0
  %67 = select <8 x i1> %51, <8 x ptr> %65, <8 x ptr> %66
  %68 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %69 = extractvalue { <8 x ptr>, <8 x i64> } %64, 1
  %70 = select <8 x i1> %51, <8 x i64> %68, <8 x i64> %69
  %71 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %67, 0
  %72 = insertvalue { <8 x ptr>, <8 x i64> } %71, <8 x i64> %70, 1
  store { <8 x ptr>, <8 x i64> } %72, ptr %tile_snapshot.spill, align 64
  store float 0.000000e+00, ptr %.spill4, align 4
  %73 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> zeroinitializer
  %74 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %75 = sdiv <8 x i64> %73, %74
  store i64 0, ptr %.spill5, align 4
  store i64 0, ptr %.spill6, align 4
  %76 = add <8 x i64> zeroinitializer, %75
  %77 = add <8 x i64> %63, zeroinitializer
  %78 = add <8 x i64> zeroinitializer, %77
  %79 = add <8 x i64> zeroinitializer, %76
  %80 = mul <8 x i64> %78, splat (i64 4096)
  %81 = load <8 x i64>, ptr %.spill7, align 64
  %82 = select <8 x i1> %51, <8 x i64> %80, <8 x i64> %81
  store <8 x i64> %82, ptr %.spill7, align 64
  %83 = add <8 x i64> %80, %79
  %84 = extractvalue { ptr, i64 } %9, 0
  %85 = mul <8 x i64> %83, splat (i64 4)
  %86 = getelementptr i8, ptr %84, <8 x i64> %85
  %87 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %86, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %89 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %90 = add <8 x i64> %89, zeroinitializer
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %88, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = extractelement <8 x ptr> %93, i32 0
  %96 = extractelement <8 x i64> %94, i32 0
  %97 = sub i64 %96, 0
  %98 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %99 = select i1 %98, i64 %97, i64 0
  %private.contiguous.address = getelementptr i8, ptr %95, i64 %99
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %100 = select <8 x i1> %51, <8 x float> %87, <8 x float> %private.contiguous.preserve
  store <8 x float> %100, ptr %private.contiguous.address, align 4
  %101 = fmul <8 x float> %87, %87
  %102 = select <8 x i1> %51, <8 x i64> <i64 8, i64 9, i64 10, i64 11, i64 12, i64 13, i64 14, i64 15>, <8 x i64> zeroinitializer
  %103 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %104 = sdiv <8 x i64> %102, %103
  %105 = add <8 x i64> zeroinitializer, %104
  %106 = add <8 x i64> zeroinitializer, %105
  %107 = add <8 x i64> %80, %106
  %108 = extractvalue { ptr, i64 } %9, 0
  %109 = mul <8 x i64> %107, splat (i64 4)
  %110 = getelementptr i8, ptr %108, <8 x i64> %109
  %111 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %110, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %112 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %113 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %114 = add <8 x i64> %113, splat (i64 32)
  %115 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %112, 0
  %116 = insertvalue { <8 x ptr>, <8 x i64> } %115, <8 x i64> %114, 1
  %117 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %118 = extractvalue { <8 x ptr>, <8 x i64> } %116, 1
  %119 = extractelement <8 x ptr> %117, i32 0
  %120 = extractelement <8 x i64> %118, i32 0
  %121 = sub i64 %120, 0
  %122 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %123 = select i1 %122, i64 %121, i64 0
  %private.contiguous.address27 = getelementptr i8, ptr %119, i64 %123
  %private.contiguous.preserve28 = load <8 x float>, ptr %private.contiguous.address27, align 4
  %124 = select <8 x i1> %51, <8 x float> %111, <8 x float> %private.contiguous.preserve28
  store <8 x float> %124, ptr %private.contiguous.address27, align 4
  %125 = fmul <8 x float> %111, %111
  %126 = select <8 x i1> %51, <8 x i64> <i64 16, i64 17, i64 18, i64 19, i64 20, i64 21, i64 22, i64 23>, <8 x i64> zeroinitializer
  %127 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %128 = sdiv <8 x i64> %126, %127
  %129 = add <8 x i64> zeroinitializer, %128
  %130 = add <8 x i64> zeroinitializer, %129
  %131 = add <8 x i64> %80, %130
  %132 = extractvalue { ptr, i64 } %9, 0
  %133 = mul <8 x i64> %131, splat (i64 4)
  %134 = getelementptr i8, ptr %132, <8 x i64> %133
  %135 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %134, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %136 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %138 = add <8 x i64> %137, splat (i64 64)
  %139 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %136, 0
  %140 = insertvalue { <8 x ptr>, <8 x i64> } %139, <8 x i64> %138, 1
  %141 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %140, 1
  %143 = extractelement <8 x ptr> %141, i32 0
  %144 = extractelement <8 x i64> %142, i32 0
  %145 = sub i64 %144, 0
  %146 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %147 = select i1 %146, i64 %145, i64 0
  %private.contiguous.address29 = getelementptr i8, ptr %143, i64 %147
  %private.contiguous.preserve30 = load <8 x float>, ptr %private.contiguous.address29, align 4
  %148 = select <8 x i1> %51, <8 x float> %135, <8 x float> %private.contiguous.preserve30
  store <8 x float> %148, ptr %private.contiguous.address29, align 4
  %149 = fmul <8 x float> %135, %135
  %150 = select <8 x i1> %51, <8 x i64> <i64 24, i64 25, i64 26, i64 27, i64 28, i64 29, i64 30, i64 31>, <8 x i64> zeroinitializer
  %151 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %152 = sdiv <8 x i64> %150, %151
  %153 = add <8 x i64> zeroinitializer, %152
  %154 = add <8 x i64> zeroinitializer, %153
  %155 = add <8 x i64> %80, %154
  %156 = extractvalue { ptr, i64 } %9, 0
  %157 = mul <8 x i64> %155, splat (i64 4)
  %158 = getelementptr i8, ptr %156, <8 x i64> %157
  %159 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %158, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %160 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %162 = add <8 x i64> %161, splat (i64 96)
  %163 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %160, 0
  %164 = insertvalue { <8 x ptr>, <8 x i64> } %163, <8 x i64> %162, 1
  %165 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %164, 1
  %167 = extractelement <8 x ptr> %165, i32 0
  %168 = extractelement <8 x i64> %166, i32 0
  %169 = sub i64 %168, 0
  %170 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %171 = select i1 %170, i64 %169, i64 0
  %private.contiguous.address31 = getelementptr i8, ptr %167, i64 %171
  %private.contiguous.preserve32 = load <8 x float>, ptr %private.contiguous.address31, align 4
  %172 = select <8 x i1> %51, <8 x float> %159, <8 x float> %private.contiguous.preserve32
  store <8 x float> %172, ptr %private.contiguous.address31, align 4
  %173 = fmul <8 x float> %159, %159
  store i64 4, ptr %.slot, align 4
  %174 = load <8 x float>, ptr %.slot8, align 32
  %175 = select <8 x i1> %51, <8 x float> %101, <8 x float> %174
  store <8 x float> %175, ptr %.slot8, align 32
  %176 = load <8 x float>, ptr %.slot9, align 32
  %177 = select <8 x i1> %51, <8 x float> %125, <8 x float> %176
  store <8 x float> %177, ptr %.slot9, align 32
  %178 = load <8 x float>, ptr %.slot10, align 32
  %179 = select <8 x i1> %51, <8 x float> %149, <8 x float> %178
  store <8 x float> %179, ptr %.slot10, align 32
  %180 = load <8 x float>, ptr %.slot11, align 32
  %181 = select <8 x i1> %51, <8 x float> %173, <8 x float> %180
  store <8 x float> %181, ptr %.slot11, align 32
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %182 = icmp slt i64 %.state, 512
  br i1 %182, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state33 = load i64, ptr %.slot, align 4
  %183 = add i64 %.state33, 0
  %184 = mul i64 %183, 8
  %.splatinsert34 = insertelement <8 x i64> poison, i64 %184, i64 0
  %.splat35 = shufflevector <8 x i64> %.splatinsert34, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %185 = add <8 x i64> %.splat35, %.spill.load
  %186 = select <8 x i1> %51, <8 x i64> %185, <8 x i64> zeroinitializer
  %187 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %188 = sdiv <8 x i64> %186, %187
  %.spill.load36 = load i64, ptr %.spill6, align 4
  %.splatinsert37 = insertelement <8 x i64> poison, i64 %.spill.load36, i64 0
  %.splat38 = shufflevector <8 x i64> %.splatinsert37, <8 x i64> poison, <8 x i32> zeroinitializer
  %189 = add <8 x i64> %.splat38, %188
  %190 = add <8 x i64> zeroinitializer, %189
  %.spill.load39 = load <8 x i64>, ptr %.spill7, align 64
  %191 = add <8 x i64> %.spill.load39, %190
  %192 = extractvalue { ptr, i64 } %9, 0
  %193 = mul <8 x i64> %191, splat (i64 4)
  %194 = getelementptr i8, ptr %192, <8 x i64> %193
  %195 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %194, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %196 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %197 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.splatinsert40 = insertelement <8 x i64> poison, i64 %183, i64 0
  %.splat41 = shufflevector <8 x i64> %.splatinsert40, <8 x i64> poison, <8 x i32> zeroinitializer
  %198 = mul <8 x i64> %.splat41, splat (i64 32)
  %199 = add <8 x i64> %197, %198
  %200 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %196, 0
  %201 = insertvalue { <8 x ptr>, <8 x i64> } %200, <8 x i64> %199, 1
  %202 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %203 = extractvalue { <8 x ptr>, <8 x i64> } %201, 1
  %204 = extractelement <8 x ptr> %202, i32 0
  %205 = extractelement <8 x i64> %203, i32 0
  %206 = sub i64 %205, 0
  %207 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %208 = select i1 %207, i64 %206, i64 0
  %private.contiguous.address42 = getelementptr i8, ptr %204, i64 %208
  %private.contiguous.preserve43 = load <8 x float>, ptr %private.contiguous.address42, align 4
  %209 = select <8 x i1> %51, <8 x float> %195, <8 x float> %private.contiguous.preserve43
  store <8 x float> %209, ptr %private.contiguous.address42, align 4
  %210 = fmul <8 x float> %195, %195
  %.state44 = load <8 x float>, ptr %.slot8, align 32
  %211 = fadd <8 x float> %.state44, %210
  %.state45 = load i64, ptr %.slot, align 4
  %212 = add i64 %.state45, 1
  %213 = mul i64 %212, 8
  %.splatinsert46 = insertelement <8 x i64> poison, i64 %213, i64 0
  %.splat47 = shufflevector <8 x i64> %.splatinsert46, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load48 = load <8 x i64>, ptr %.spill, align 64
  %214 = add <8 x i64> %.splat47, %.spill.load48
  %215 = select <8 x i1> %51, <8 x i64> %214, <8 x i64> zeroinitializer
  %216 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %217 = sdiv <8 x i64> %215, %216
  %.spill.load49 = load i64, ptr %.spill6, align 4
  %.splatinsert50 = insertelement <8 x i64> poison, i64 %.spill.load49, i64 0
  %.splat51 = shufflevector <8 x i64> %.splatinsert50, <8 x i64> poison, <8 x i32> zeroinitializer
  %218 = add <8 x i64> %.splat51, %217
  %219 = add <8 x i64> zeroinitializer, %218
  %.spill.load52 = load <8 x i64>, ptr %.spill7, align 64
  %220 = add <8 x i64> %.spill.load52, %219
  %221 = extractvalue { ptr, i64 } %9, 0
  %222 = mul <8 x i64> %220, splat (i64 4)
  %223 = getelementptr i8, ptr %221, <8 x i64> %222
  %224 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %223, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load53 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %225 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 0
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 1
  %.splatinsert54 = insertelement <8 x i64> poison, i64 %212, i64 0
  %.splat55 = shufflevector <8 x i64> %.splatinsert54, <8 x i64> poison, <8 x i32> zeroinitializer
  %227 = mul <8 x i64> %.splat55, splat (i64 32)
  %228 = add <8 x i64> %226, %227
  %229 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %225, 0
  %230 = insertvalue { <8 x ptr>, <8 x i64> } %229, <8 x i64> %228, 1
  %231 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %232 = extractvalue { <8 x ptr>, <8 x i64> } %230, 1
  %233 = extractelement <8 x ptr> %231, i32 0
  %234 = extractelement <8 x i64> %232, i32 0
  %235 = sub i64 %234, 0
  %236 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %237 = select i1 %236, i64 %235, i64 0
  %private.contiguous.address56 = getelementptr i8, ptr %233, i64 %237
  %private.contiguous.preserve57 = load <8 x float>, ptr %private.contiguous.address56, align 4
  %238 = select <8 x i1> %51, <8 x float> %224, <8 x float> %private.contiguous.preserve57
  store <8 x float> %238, ptr %private.contiguous.address56, align 4
  %239 = fmul <8 x float> %224, %224
  %.state58 = load <8 x float>, ptr %.slot9, align 32
  %240 = fadd <8 x float> %.state58, %239
  %.state59 = load i64, ptr %.slot, align 4
  %241 = add i64 %.state59, 2
  %242 = mul i64 %241, 8
  %.splatinsert60 = insertelement <8 x i64> poison, i64 %242, i64 0
  %.splat61 = shufflevector <8 x i64> %.splatinsert60, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load62 = load <8 x i64>, ptr %.spill, align 64
  %243 = add <8 x i64> %.splat61, %.spill.load62
  %244 = select <8 x i1> %51, <8 x i64> %243, <8 x i64> zeroinitializer
  %245 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %246 = sdiv <8 x i64> %244, %245
  %.spill.load63 = load i64, ptr %.spill6, align 4
  %.splatinsert64 = insertelement <8 x i64> poison, i64 %.spill.load63, i64 0
  %.splat65 = shufflevector <8 x i64> %.splatinsert64, <8 x i64> poison, <8 x i32> zeroinitializer
  %247 = add <8 x i64> %.splat65, %246
  %248 = add <8 x i64> zeroinitializer, %247
  %.spill.load66 = load <8 x i64>, ptr %.spill7, align 64
  %249 = add <8 x i64> %.spill.load66, %248
  %250 = extractvalue { ptr, i64 } %9, 0
  %251 = mul <8 x i64> %249, splat (i64 4)
  %252 = getelementptr i8, ptr %250, <8 x i64> %251
  %253 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %252, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load67 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load67, 0
  %255 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load67, 1
  %.splatinsert68 = insertelement <8 x i64> poison, i64 %241, i64 0
  %.splat69 = shufflevector <8 x i64> %.splatinsert68, <8 x i64> poison, <8 x i32> zeroinitializer
  %256 = mul <8 x i64> %.splat69, splat (i64 32)
  %257 = add <8 x i64> %255, %256
  %258 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %254, 0
  %259 = insertvalue { <8 x ptr>, <8 x i64> } %258, <8 x i64> %257, 1
  %260 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %259, 1
  %262 = extractelement <8 x ptr> %260, i32 0
  %263 = extractelement <8 x i64> %261, i32 0
  %264 = sub i64 %263, 0
  %265 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %266 = select i1 %265, i64 %264, i64 0
  %private.contiguous.address70 = getelementptr i8, ptr %262, i64 %266
  %private.contiguous.preserve71 = load <8 x float>, ptr %private.contiguous.address70, align 4
  %267 = select <8 x i1> %51, <8 x float> %253, <8 x float> %private.contiguous.preserve71
  store <8 x float> %267, ptr %private.contiguous.address70, align 4
  %268 = fmul <8 x float> %253, %253
  %.state72 = load <8 x float>, ptr %.slot10, align 32
  %269 = fadd <8 x float> %.state72, %268
  %.state73 = load i64, ptr %.slot, align 4
  %270 = add i64 %.state73, 3
  %271 = mul i64 %270, 8
  %.splatinsert74 = insertelement <8 x i64> poison, i64 %271, i64 0
  %.splat75 = shufflevector <8 x i64> %.splatinsert74, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load76 = load <8 x i64>, ptr %.spill, align 64
  %272 = add <8 x i64> %.splat75, %.spill.load76
  %273 = select <8 x i1> %51, <8 x i64> %272, <8 x i64> zeroinitializer
  %274 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %275 = sdiv <8 x i64> %273, %274
  %.spill.load77 = load i64, ptr %.spill6, align 4
  %.splatinsert78 = insertelement <8 x i64> poison, i64 %.spill.load77, i64 0
  %.splat79 = shufflevector <8 x i64> %.splatinsert78, <8 x i64> poison, <8 x i32> zeroinitializer
  %276 = add <8 x i64> %.splat79, %275
  %277 = add <8 x i64> zeroinitializer, %276
  %.spill.load80 = load <8 x i64>, ptr %.spill7, align 64
  %278 = add <8 x i64> %.spill.load80, %277
  %279 = extractvalue { ptr, i64 } %9, 0
  %280 = mul <8 x i64> %278, splat (i64 4)
  %281 = getelementptr i8, ptr %279, <8 x i64> %280
  %282 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %281, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load81 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %283 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load81, 0
  %284 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load81, 1
  %.splatinsert82 = insertelement <8 x i64> poison, i64 %270, i64 0
  %.splat83 = shufflevector <8 x i64> %.splatinsert82, <8 x i64> poison, <8 x i32> zeroinitializer
  %285 = mul <8 x i64> %.splat83, splat (i64 32)
  %286 = add <8 x i64> %284, %285
  %287 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %283, 0
  %288 = insertvalue { <8 x ptr>, <8 x i64> } %287, <8 x i64> %286, 1
  %289 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %290 = extractvalue { <8 x ptr>, <8 x i64> } %288, 1
  %291 = extractelement <8 x ptr> %289, i32 0
  %292 = extractelement <8 x i64> %290, i32 0
  %293 = sub i64 %292, 0
  %294 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %295 = select i1 %294, i64 %293, i64 0
  %private.contiguous.address84 = getelementptr i8, ptr %291, i64 %295
  %private.contiguous.preserve85 = load <8 x float>, ptr %private.contiguous.address84, align 4
  %296 = select <8 x i1> %51, <8 x float> %282, <8 x float> %private.contiguous.preserve85
  store <8 x float> %296, ptr %private.contiguous.address84, align 4
  %297 = fmul <8 x float> %282, %282
  %.state86 = load <8 x float>, ptr %.slot11, align 32
  %298 = fadd <8 x float> %.state86, %297
  %.state87 = load i64, ptr %.slot, align 4
  %299 = add i64 %.state87, 4
  store i64 %299, ptr %.slot, align 4
  %300 = load <8 x float>, ptr %.slot8, align 32
  %301 = select <8 x i1> %51, <8 x float> %211, <8 x float> %300
  store <8 x float> %301, ptr %.slot8, align 32
  %302 = load <8 x float>, ptr %.slot9, align 32
  %303 = select <8 x i1> %51, <8 x float> %240, <8 x float> %302
  store <8 x float> %303, ptr %.slot9, align 32
  %304 = load <8 x float>, ptr %.slot10, align 32
  %305 = select <8 x i1> %51, <8 x float> %269, <8 x float> %304
  store <8 x float> %305, ptr %.slot10, align 32
  %306 = load <8 x float>, ptr %.slot11, align 32
  %307 = select <8 x i1> %51, <8 x float> %298, <8 x float> %306
  store <8 x float> %307, ptr %.slot11, align 32
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %.state88 = load <8 x float>, ptr %.slot8, align 32
  %.state89 = load <8 x float>, ptr %.slot9, align 32
  %308 = fadd <8 x float> %.state88, %.state89
  %.state90 = load <8 x float>, ptr %.slot10, align 32
  %309 = fadd <8 x float> %308, %.state90
  %.state91 = load <8 x float>, ptr %.slot11, align 32
  %310 = fadd <8 x float> %309, %.state91
  %.spill.load92 = load <8 x i64>, ptr %.spill, align 64
  %311 = trunc <8 x i64> %.spill.load92 to <8 x i32>
  %312 = xor <8 x i32> %311, splat (i32 1)
  %313 = extractelement <8 x i32> %312, i64 0
  %314 = icmp ult i32 %313, 8
  %315 = select i1 %314, i32 %313, i32 0
  %316 = extractelement <8 x i1> %51, i32 %315
  %317 = extractelement <8 x i1> %51, i64 0
  %318 = and i1 %314, %316
  %319 = and i1 %317, %318
  %320 = extractelement <8 x float> %310, i32 %315
  %321 = select i1 %319, float %320, float 0.000000e+00
  %322 = insertelement <8 x float> poison, float %321, i64 0
  %323 = xor i1 %319, true
  %324 = and i1 %317, %323
  %325 = insertelement <8 x i1> poison, i1 %324, i64 0
  %326 = extractelement <8 x i32> %312, i64 1
  %327 = icmp ult i32 %326, 8
  %328 = select i1 %327, i32 %326, i32 0
  %329 = extractelement <8 x i1> %51, i32 %328
  %330 = extractelement <8 x i1> %51, i64 1
  %331 = and i1 %327, %329
  %332 = and i1 %330, %331
  %333 = extractelement <8 x float> %310, i32 %328
  %334 = select i1 %332, float %333, float 0.000000e+00
  %335 = insertelement <8 x float> %322, float %334, i64 1
  %336 = xor i1 %332, true
  %337 = and i1 %330, %336
  %338 = insertelement <8 x i1> %325, i1 %337, i64 1
  %339 = extractelement <8 x i32> %312, i64 2
  %340 = icmp ult i32 %339, 8
  %341 = select i1 %340, i32 %339, i32 0
  %342 = extractelement <8 x i1> %51, i32 %341
  %343 = extractelement <8 x i1> %51, i64 2
  %344 = and i1 %340, %342
  %345 = and i1 %343, %344
  %346 = extractelement <8 x float> %310, i32 %341
  %347 = select i1 %345, float %346, float 0.000000e+00
  %348 = insertelement <8 x float> %335, float %347, i64 2
  %349 = xor i1 %345, true
  %350 = and i1 %343, %349
  %351 = insertelement <8 x i1> %338, i1 %350, i64 2
  %352 = extractelement <8 x i32> %312, i64 3
  %353 = icmp ult i32 %352, 8
  %354 = select i1 %353, i32 %352, i32 0
  %355 = extractelement <8 x i1> %51, i32 %354
  %356 = extractelement <8 x i1> %51, i64 3
  %357 = and i1 %353, %355
  %358 = and i1 %356, %357
  %359 = extractelement <8 x float> %310, i32 %354
  %360 = select i1 %358, float %359, float 0.000000e+00
  %361 = insertelement <8 x float> %348, float %360, i64 3
  %362 = xor i1 %358, true
  %363 = and i1 %356, %362
  %364 = insertelement <8 x i1> %351, i1 %363, i64 3
  %365 = extractelement <8 x i32> %312, i64 4
  %366 = icmp ult i32 %365, 8
  %367 = select i1 %366, i32 %365, i32 0
  %368 = extractelement <8 x i1> %51, i32 %367
  %369 = extractelement <8 x i1> %51, i64 4
  %370 = and i1 %366, %368
  %371 = and i1 %369, %370
  %372 = extractelement <8 x float> %310, i32 %367
  %373 = select i1 %371, float %372, float 0.000000e+00
  %374 = insertelement <8 x float> %361, float %373, i64 4
  %375 = xor i1 %371, true
  %376 = and i1 %369, %375
  %377 = insertelement <8 x i1> %364, i1 %376, i64 4
  %378 = extractelement <8 x i32> %312, i64 5
  %379 = icmp ult i32 %378, 8
  %380 = select i1 %379, i32 %378, i32 0
  %381 = extractelement <8 x i1> %51, i32 %380
  %382 = extractelement <8 x i1> %51, i64 5
  %383 = and i1 %379, %381
  %384 = and i1 %382, %383
  %385 = extractelement <8 x float> %310, i32 %380
  %386 = select i1 %384, float %385, float 0.000000e+00
  %387 = insertelement <8 x float> %374, float %386, i64 5
  %388 = xor i1 %384, true
  %389 = and i1 %382, %388
  %390 = insertelement <8 x i1> %377, i1 %389, i64 5
  %391 = extractelement <8 x i32> %312, i64 6
  %392 = icmp ult i32 %391, 8
  %393 = select i1 %392, i32 %391, i32 0
  %394 = extractelement <8 x i1> %51, i32 %393
  %395 = extractelement <8 x i1> %51, i64 6
  %396 = and i1 %392, %394
  %397 = and i1 %395, %396
  %398 = extractelement <8 x float> %310, i32 %393
  %399 = select i1 %397, float %398, float 0.000000e+00
  %400 = insertelement <8 x float> %387, float %399, i64 6
  %401 = xor i1 %397, true
  %402 = and i1 %395, %401
  %403 = insertelement <8 x i1> %390, i1 %402, i64 6
  %404 = extractelement <8 x i32> %312, i64 7
  %405 = icmp ult i32 %404, 8
  %406 = select i1 %405, i32 %404, i32 0
  %407 = extractelement <8 x i1> %51, i32 %406
  %408 = extractelement <8 x i1> %51, i64 7
  %409 = and i1 %405, %407
  %410 = and i1 %408, %409
  %411 = extractelement <8 x float> %310, i32 %406
  %412 = select i1 %410, float %411, float 0.000000e+00
  %413 = insertelement <8 x float> %400, float %412, i64 7
  %414 = xor i1 %410, true
  %415 = and i1 %408, %414
  %416 = insertelement <8 x i1> %403, i1 %415, i64 7
  %417 = fadd <8 x float> %310, %413
  %418 = xor <8 x i32> %311, splat (i32 2)
  %419 = extractelement <8 x i32> %418, i64 0
  %420 = icmp ult i32 %419, 8
  %421 = select i1 %420, i32 %419, i32 0
  %422 = extractelement <8 x i1> %51, i32 %421
  %423 = extractelement <8 x i1> %51, i64 0
  %424 = and i1 %420, %422
  %425 = and i1 %423, %424
  %426 = extractelement <8 x float> %417, i32 %421
  %427 = select i1 %425, float %426, float 0.000000e+00
  %428 = insertelement <8 x float> poison, float %427, i64 0
  %429 = xor i1 %425, true
  %430 = and i1 %423, %429
  %431 = insertelement <8 x i1> poison, i1 %430, i64 0
  %432 = extractelement <8 x i32> %418, i64 1
  %433 = icmp ult i32 %432, 8
  %434 = select i1 %433, i32 %432, i32 0
  %435 = extractelement <8 x i1> %51, i32 %434
  %436 = extractelement <8 x i1> %51, i64 1
  %437 = and i1 %433, %435
  %438 = and i1 %436, %437
  %439 = extractelement <8 x float> %417, i32 %434
  %440 = select i1 %438, float %439, float 0.000000e+00
  %441 = insertelement <8 x float> %428, float %440, i64 1
  %442 = xor i1 %438, true
  %443 = and i1 %436, %442
  %444 = insertelement <8 x i1> %431, i1 %443, i64 1
  %445 = extractelement <8 x i32> %418, i64 2
  %446 = icmp ult i32 %445, 8
  %447 = select i1 %446, i32 %445, i32 0
  %448 = extractelement <8 x i1> %51, i32 %447
  %449 = extractelement <8 x i1> %51, i64 2
  %450 = and i1 %446, %448
  %451 = and i1 %449, %450
  %452 = extractelement <8 x float> %417, i32 %447
  %453 = select i1 %451, float %452, float 0.000000e+00
  %454 = insertelement <8 x float> %441, float %453, i64 2
  %455 = xor i1 %451, true
  %456 = and i1 %449, %455
  %457 = insertelement <8 x i1> %444, i1 %456, i64 2
  %458 = extractelement <8 x i32> %418, i64 3
  %459 = icmp ult i32 %458, 8
  %460 = select i1 %459, i32 %458, i32 0
  %461 = extractelement <8 x i1> %51, i32 %460
  %462 = extractelement <8 x i1> %51, i64 3
  %463 = and i1 %459, %461
  %464 = and i1 %462, %463
  %465 = extractelement <8 x float> %417, i32 %460
  %466 = select i1 %464, float %465, float 0.000000e+00
  %467 = insertelement <8 x float> %454, float %466, i64 3
  %468 = xor i1 %464, true
  %469 = and i1 %462, %468
  %470 = insertelement <8 x i1> %457, i1 %469, i64 3
  %471 = extractelement <8 x i32> %418, i64 4
  %472 = icmp ult i32 %471, 8
  %473 = select i1 %472, i32 %471, i32 0
  %474 = extractelement <8 x i1> %51, i32 %473
  %475 = extractelement <8 x i1> %51, i64 4
  %476 = and i1 %472, %474
  %477 = and i1 %475, %476
  %478 = extractelement <8 x float> %417, i32 %473
  %479 = select i1 %477, float %478, float 0.000000e+00
  %480 = insertelement <8 x float> %467, float %479, i64 4
  %481 = xor i1 %477, true
  %482 = and i1 %475, %481
  %483 = insertelement <8 x i1> %470, i1 %482, i64 4
  %484 = extractelement <8 x i32> %418, i64 5
  %485 = icmp ult i32 %484, 8
  %486 = select i1 %485, i32 %484, i32 0
  %487 = extractelement <8 x i1> %51, i32 %486
  %488 = extractelement <8 x i1> %51, i64 5
  %489 = and i1 %485, %487
  %490 = and i1 %488, %489
  %491 = extractelement <8 x float> %417, i32 %486
  %492 = select i1 %490, float %491, float 0.000000e+00
  %493 = insertelement <8 x float> %480, float %492, i64 5
  %494 = xor i1 %490, true
  %495 = and i1 %488, %494
  %496 = insertelement <8 x i1> %483, i1 %495, i64 5
  %497 = extractelement <8 x i32> %418, i64 6
  %498 = icmp ult i32 %497, 8
  %499 = select i1 %498, i32 %497, i32 0
  %500 = extractelement <8 x i1> %51, i32 %499
  %501 = extractelement <8 x i1> %51, i64 6
  %502 = and i1 %498, %500
  %503 = and i1 %501, %502
  %504 = extractelement <8 x float> %417, i32 %499
  %505 = select i1 %503, float %504, float 0.000000e+00
  %506 = insertelement <8 x float> %493, float %505, i64 6
  %507 = xor i1 %503, true
  %508 = and i1 %501, %507
  %509 = insertelement <8 x i1> %496, i1 %508, i64 6
  %510 = extractelement <8 x i32> %418, i64 7
  %511 = icmp ult i32 %510, 8
  %512 = select i1 %511, i32 %510, i32 0
  %513 = extractelement <8 x i1> %51, i32 %512
  %514 = extractelement <8 x i1> %51, i64 7
  %515 = and i1 %511, %513
  %516 = and i1 %514, %515
  %517 = extractelement <8 x float> %417, i32 %512
  %518 = select i1 %516, float %517, float 0.000000e+00
  %519 = insertelement <8 x float> %506, float %518, i64 7
  %520 = xor i1 %516, true
  %521 = and i1 %514, %520
  %522 = insertelement <8 x i1> %509, i1 %521, i64 7
  %523 = fadd <8 x float> %417, %519
  %524 = xor <8 x i32> %311, splat (i32 4)
  %525 = extractelement <8 x i32> %524, i64 0
  %526 = icmp ult i32 %525, 8
  %527 = select i1 %526, i32 %525, i32 0
  %528 = extractelement <8 x i1> %51, i32 %527
  %529 = extractelement <8 x i1> %51, i64 0
  %530 = and i1 %526, %528
  %531 = and i1 %529, %530
  %532 = extractelement <8 x float> %523, i32 %527
  %533 = select i1 %531, float %532, float 0.000000e+00
  %534 = insertelement <8 x float> poison, float %533, i64 0
  %535 = xor i1 %531, true
  %536 = and i1 %529, %535
  %537 = insertelement <8 x i1> poison, i1 %536, i64 0
  %538 = extractelement <8 x i32> %524, i64 1
  %539 = icmp ult i32 %538, 8
  %540 = select i1 %539, i32 %538, i32 0
  %541 = extractelement <8 x i1> %51, i32 %540
  %542 = extractelement <8 x i1> %51, i64 1
  %543 = and i1 %539, %541
  %544 = and i1 %542, %543
  %545 = extractelement <8 x float> %523, i32 %540
  %546 = select i1 %544, float %545, float 0.000000e+00
  %547 = insertelement <8 x float> %534, float %546, i64 1
  %548 = xor i1 %544, true
  %549 = and i1 %542, %548
  %550 = insertelement <8 x i1> %537, i1 %549, i64 1
  %551 = extractelement <8 x i32> %524, i64 2
  %552 = icmp ult i32 %551, 8
  %553 = select i1 %552, i32 %551, i32 0
  %554 = extractelement <8 x i1> %51, i32 %553
  %555 = extractelement <8 x i1> %51, i64 2
  %556 = and i1 %552, %554
  %557 = and i1 %555, %556
  %558 = extractelement <8 x float> %523, i32 %553
  %559 = select i1 %557, float %558, float 0.000000e+00
  %560 = insertelement <8 x float> %547, float %559, i64 2
  %561 = xor i1 %557, true
  %562 = and i1 %555, %561
  %563 = insertelement <8 x i1> %550, i1 %562, i64 2
  %564 = extractelement <8 x i32> %524, i64 3
  %565 = icmp ult i32 %564, 8
  %566 = select i1 %565, i32 %564, i32 0
  %567 = extractelement <8 x i1> %51, i32 %566
  %568 = extractelement <8 x i1> %51, i64 3
  %569 = and i1 %565, %567
  %570 = and i1 %568, %569
  %571 = extractelement <8 x float> %523, i32 %566
  %572 = select i1 %570, float %571, float 0.000000e+00
  %573 = insertelement <8 x float> %560, float %572, i64 3
  %574 = xor i1 %570, true
  %575 = and i1 %568, %574
  %576 = insertelement <8 x i1> %563, i1 %575, i64 3
  %577 = extractelement <8 x i32> %524, i64 4
  %578 = icmp ult i32 %577, 8
  %579 = select i1 %578, i32 %577, i32 0
  %580 = extractelement <8 x i1> %51, i32 %579
  %581 = extractelement <8 x i1> %51, i64 4
  %582 = and i1 %578, %580
  %583 = and i1 %581, %582
  %584 = extractelement <8 x float> %523, i32 %579
  %585 = select i1 %583, float %584, float 0.000000e+00
  %586 = insertelement <8 x float> %573, float %585, i64 4
  %587 = xor i1 %583, true
  %588 = and i1 %581, %587
  %589 = insertelement <8 x i1> %576, i1 %588, i64 4
  %590 = extractelement <8 x i32> %524, i64 5
  %591 = icmp ult i32 %590, 8
  %592 = select i1 %591, i32 %590, i32 0
  %593 = extractelement <8 x i1> %51, i32 %592
  %594 = extractelement <8 x i1> %51, i64 5
  %595 = and i1 %591, %593
  %596 = and i1 %594, %595
  %597 = extractelement <8 x float> %523, i32 %592
  %598 = select i1 %596, float %597, float 0.000000e+00
  %599 = insertelement <8 x float> %586, float %598, i64 5
  %600 = xor i1 %596, true
  %601 = and i1 %594, %600
  %602 = insertelement <8 x i1> %589, i1 %601, i64 5
  %603 = extractelement <8 x i32> %524, i64 6
  %604 = icmp ult i32 %603, 8
  %605 = select i1 %604, i32 %603, i32 0
  %606 = extractelement <8 x i1> %51, i32 %605
  %607 = extractelement <8 x i1> %51, i64 6
  %608 = and i1 %604, %606
  %609 = and i1 %607, %608
  %610 = extractelement <8 x float> %523, i32 %605
  %611 = select i1 %609, float %610, float 0.000000e+00
  %612 = insertelement <8 x float> %599, float %611, i64 6
  %613 = xor i1 %609, true
  %614 = and i1 %607, %613
  %615 = insertelement <8 x i1> %602, i1 %614, i64 6
  %616 = extractelement <8 x i32> %524, i64 7
  %617 = icmp ult i32 %616, 8
  %618 = select i1 %617, i32 %616, i32 0
  %619 = extractelement <8 x i1> %51, i32 %618
  %620 = extractelement <8 x i1> %51, i64 7
  %621 = and i1 %617, %619
  %622 = and i1 %620, %621
  %623 = extractelement <8 x float> %523, i32 %618
  %624 = select i1 %622, float %623, float 0.000000e+00
  %625 = insertelement <8 x float> %612, float %624, i64 7
  %626 = xor i1 %622, true
  %627 = and i1 %620, %626
  %628 = insertelement <8 x i1> %615, i1 %627, i64 7
  %629 = fadd <8 x float> %523, %625
  %630 = extractelement <8 x i1> %51, i32 0
  %631 = extractelement <8 x i1> %51, i64 0
  %632 = and i1 true, %630
  %633 = and i1 %631, %632
  %634 = extractelement <8 x float> %629, i32 0
  %635 = select i1 %633, float %634, float 0.000000e+00
  %636 = insertelement <8 x float> poison, float %635, i64 0
  %637 = xor i1 %633, true
  %638 = and i1 %631, %637
  %639 = insertelement <8 x i1> poison, i1 %638, i64 0
  %640 = extractelement <8 x i1> %51, i32 0
  %641 = extractelement <8 x i1> %51, i64 1
  %642 = and i1 true, %640
  %643 = and i1 %641, %642
  %644 = extractelement <8 x float> %629, i32 0
  %645 = select i1 %643, float %644, float 0.000000e+00
  %646 = insertelement <8 x float> %636, float %645, i64 1
  %647 = xor i1 %643, true
  %648 = and i1 %641, %647
  %649 = insertelement <8 x i1> %639, i1 %648, i64 1
  %650 = extractelement <8 x i1> %51, i32 0
  %651 = extractelement <8 x i1> %51, i64 2
  %652 = and i1 true, %650
  %653 = and i1 %651, %652
  %654 = extractelement <8 x float> %629, i32 0
  %655 = select i1 %653, float %654, float 0.000000e+00
  %656 = insertelement <8 x float> %646, float %655, i64 2
  %657 = xor i1 %653, true
  %658 = and i1 %651, %657
  %659 = insertelement <8 x i1> %649, i1 %658, i64 2
  %660 = extractelement <8 x i1> %51, i32 0
  %661 = extractelement <8 x i1> %51, i64 3
  %662 = and i1 true, %660
  %663 = and i1 %661, %662
  %664 = extractelement <8 x float> %629, i32 0
  %665 = select i1 %663, float %664, float 0.000000e+00
  %666 = insertelement <8 x float> %656, float %665, i64 3
  %667 = xor i1 %663, true
  %668 = and i1 %661, %667
  %669 = insertelement <8 x i1> %659, i1 %668, i64 3
  %670 = extractelement <8 x i1> %51, i32 0
  %671 = extractelement <8 x i1> %51, i64 4
  %672 = and i1 true, %670
  %673 = and i1 %671, %672
  %674 = extractelement <8 x float> %629, i32 0
  %675 = select i1 %673, float %674, float 0.000000e+00
  %676 = insertelement <8 x float> %666, float %675, i64 4
  %677 = xor i1 %673, true
  %678 = and i1 %671, %677
  %679 = insertelement <8 x i1> %669, i1 %678, i64 4
  %680 = extractelement <8 x i1> %51, i32 0
  %681 = extractelement <8 x i1> %51, i64 5
  %682 = and i1 true, %680
  %683 = and i1 %681, %682
  %684 = extractelement <8 x float> %629, i32 0
  %685 = select i1 %683, float %684, float 0.000000e+00
  %686 = insertelement <8 x float> %676, float %685, i64 5
  %687 = xor i1 %683, true
  %688 = and i1 %681, %687
  %689 = insertelement <8 x i1> %679, i1 %688, i64 5
  %690 = extractelement <8 x i1> %51, i32 0
  %691 = extractelement <8 x i1> %51, i64 6
  %692 = and i1 true, %690
  %693 = and i1 %691, %692
  %694 = extractelement <8 x float> %629, i32 0
  %695 = select i1 %693, float %694, float 0.000000e+00
  %696 = insertelement <8 x float> %686, float %695, i64 6
  %697 = xor i1 %693, true
  %698 = and i1 %691, %697
  %699 = insertelement <8 x i1> %689, i1 %698, i64 6
  %700 = extractelement <8 x i1> %51, i32 0
  %701 = extractelement <8 x i1> %51, i64 7
  %702 = and i1 true, %700
  %703 = and i1 %701, %702
  %704 = extractelement <8 x float> %629, i32 0
  %705 = select i1 %703, float %704, float 0.000000e+00
  %706 = insertelement <8 x float> %696, float %705, i64 7
  %707 = xor i1 %703, true
  %708 = and i1 %701, %707
  %709 = insertelement <8 x i1> %699, i1 %708, i64 7
  %710 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %711 = bitcast <8 x i1> %51 to i8
  %712 = call i8 @llvm.cttz.i8(i8 %711, i1 false)
  %713 = zext i8 %712 to i32
  %714 = select i1 %710, i32 %713, i32 0
  %715 = extractelement <8 x float> %706, i32 %714
  %.spill.load93 = load float, ptr %.spill4, align 4
  %716 = fadd float %.spill.load93, %715
  %717 = fdiv float %716, 4.096000e+03
  store float %717, ptr %.spill12, align 4
  %718 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %719 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %720 = extractvalue { <8 x ptr>, <8 x i64> } %718, 0
  %721 = select <8 x i1> %51, <8 x ptr> %719, <8 x ptr> %720
  %722 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %723 = extractvalue { <8 x ptr>, <8 x i64> } %718, 1
  %724 = select <8 x i1> %51, <8 x i64> %722, <8 x i64> %723
  %725 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %721, 0
  %726 = insertvalue { <8 x ptr>, <8 x i64> } %725, <8 x i64> %724, 1
  store { <8 x ptr>, <8 x i64> } %726, ptr %tile_snapshot.spill13, align 64
  store i64 0, ptr %.slot14, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state94 = load i64, ptr %.slot14, align 4
  %727 = icmp slt i64 %.state94, 512
  br i1 %727, label %direct.true95, label %direct.false96

direct.schedule.5:                                ; preds = %direct.true95
  %.state97 = load i64, ptr %.slot14, align 4
  %728 = mul i64 %.state97, 8
  %.splatinsert98 = insertelement <8 x i64> poison, i64 %728, i64 0
  %.splat99 = shufflevector <8 x i64> %.splatinsert98, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load100 = load <8 x i64>, ptr %.spill, align 64
  %729 = add <8 x i64> %.splat99, %.spill.load100
  %.spill.load101 = load i64, ptr %.spill5, align 4
  %730 = add i64 %.spill.load101, 0
  %731 = add <8 x i64> zeroinitializer, %729
  %732 = mul i64 %730, 4096
  %.splatinsert102 = insertelement <8 x i64> poison, i64 %732, i64 0
  %.splat103 = shufflevector <8 x i64> %.splatinsert102, <8 x i64> poison, <8 x i32> zeroinitializer
  %733 = add <8 x i64> %.splat103, %731
  %734 = extractvalue { ptr, i64 } %15, 0
  %735 = extractelement <8 x i64> %733, i32 0
  %736 = sub i64 %735, 0
  %737 = mul i64 %736, 4
  %buffer.contiguous.address = getelementptr i8, ptr %734, i64 %737
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load104 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %738 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load104, 0
  %739 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load104, 1
  %.state105 = load i64, ptr %.slot14, align 4
  %.splatinsert106 = insertelement <8 x i64> poison, i64 %.state105, i64 0
  %.splat107 = shufflevector <8 x i64> %.splatinsert106, <8 x i64> poison, <8 x i32> zeroinitializer
  %740 = mul <8 x i64> %.splat107, splat (i64 32)
  %741 = add <8 x i64> %739, %740
  %742 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %738, 0
  %743 = insertvalue { <8 x ptr>, <8 x i64> } %742, <8 x i64> %741, 1
  %744 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %745 = extractvalue { <8 x ptr>, <8 x i64> } %743, 1
  %746 = extractelement <8 x ptr> %744, i32 0
  %747 = extractelement <8 x i64> %745, i32 0
  %748 = sub i64 %747, 0
  %749 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %750 = select i1 %749, i64 %748, i64 0
  %private.contiguous.address108 = getelementptr i8, ptr %746, i64 %750
  %private.contiguous.preserve109 = load <8 x float>, ptr %private.contiguous.address108, align 4
  %751 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve109
  store <8 x float> %751, ptr %private.contiguous.address108, align 4
  %.state110 = load i64, ptr %.slot14, align 4
  %752 = add i64 %.state110, 1
  store i64 %752, ptr %.slot14, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false96
  %.spill.load111 = load float, ptr %.spill12, align 4
  %753 = fadd float %.spill.load111, 0x3EE4F8B580000000
  %754 = call float @llvm.sqrt.f32(float %753)
  store float %754, ptr %.spill15, align 4
  store i64 0, ptr %.slot16, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state112 = load i64, ptr %.slot16, align 4
  %755 = icmp slt i64 %.state112, 512
  br i1 %755, label %direct.true113, label %direct.false114

direct.schedule.8:                                ; preds = %direct.true113
  %.state115 = load i64, ptr %.slot16, align 4
  %756 = mul i64 %.state115, 8
  %.splatinsert116 = insertelement <8 x i64> poison, i64 %756, i64 0
  %.splat117 = shufflevector <8 x i64> %.splatinsert116, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load118 = load <8 x i64>, ptr %.spill, align 64
  %757 = add <8 x i64> %.splat117, %.spill.load118
  %758 = add <8 x i64> zeroinitializer, %757
  %.spill.load119 = load <8 x i64>, ptr %.spill7, align 64
  %759 = add <8 x i64> %.spill.load119, %758
  %tile_snapshot.spill.load120 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %760 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load120, 0
  %761 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load120, 1
  %.state121 = load i64, ptr %.slot16, align 4
  %.splatinsert122 = insertelement <8 x i64> poison, i64 %.state121, i64 0
  %.splat123 = shufflevector <8 x i64> %.splatinsert122, <8 x i64> poison, <8 x i32> zeroinitializer
  %762 = mul <8 x i64> %.splat123, splat (i64 32)
  %763 = add <8 x i64> %761, %762
  %764 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %760, 0
  %765 = insertvalue { <8 x ptr>, <8 x i64> } %764, <8 x i64> %763, 1
  %766 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %767 = extractvalue { <8 x ptr>, <8 x i64> } %765, 1
  %768 = extractelement <8 x ptr> %766, i32 0
  %769 = extractelement <8 x i64> %767, i32 0
  %770 = sub i64 %769, 0
  %771 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %772 = select i1 %771, i64 %770, i64 0
  %private.contiguous.address124 = getelementptr i8, ptr %768, i64 %772
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address124, align 4
  %773 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %.spill.load125 = load float, ptr %.spill15, align 4
  %.splatinsert126 = insertelement <8 x float> poison, float %.spill.load125, i64 0
  %.splat127 = shufflevector <8 x float> %.splatinsert126, <8 x float> poison, <8 x i32> zeroinitializer
  %774 = fdiv <8 x float> %773, %.splat127
  %tile_snapshot.spill.load128 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %775 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load128, 0
  %776 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load128, 1
  %.state129 = load i64, ptr %.slot16, align 4
  %.splatinsert130 = insertelement <8 x i64> poison, i64 %.state129, i64 0
  %.splat131 = shufflevector <8 x i64> %.splatinsert130, <8 x i64> poison, <8 x i32> zeroinitializer
  %777 = mul <8 x i64> %.splat131, splat (i64 32)
  %778 = add <8 x i64> %776, %777
  %779 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %775, 0
  %780 = insertvalue { <8 x ptr>, <8 x i64> } %779, <8 x i64> %778, 1
  %781 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %782 = extractvalue { <8 x ptr>, <8 x i64> } %780, 1
  %783 = extractelement <8 x ptr> %781, i32 0
  %784 = extractelement <8 x i64> %782, i32 0
  %785 = sub i64 %784, 0
  %786 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %787 = select i1 %786, i64 %785, i64 0
  %private.contiguous.address132 = getelementptr i8, ptr %783, i64 %787
  %private.contiguous.load133 = load <8 x float>, ptr %private.contiguous.address132, align 4
  %788 = select <8 x i1> %51, <8 x float> %private.contiguous.load133, <8 x float> zeroinitializer
  %789 = fmul <8 x float> %774, %788
  %790 = extractvalue { ptr, i64 } %27, 0
  %791 = extractelement <8 x i64> %759, i32 0
  %792 = sub i64 %791, 0
  %793 = mul i64 %792, 4
  %buffer.contiguous.address134 = getelementptr i8, ptr %790, i64 %793
  call void @llvm.masked.store.v8f32.p0(<8 x float> %789, ptr %buffer.contiguous.address134, i32 1, <8 x i1> %51)
  %.state135 = load i64, ptr %.slot16, align 4
  %794 = add i64 %.state135, 1
  store i64 %794, ptr %.slot16, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false114
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true95:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false96:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true113:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false114:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.9
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 1024
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 1024
  %3 = sub i64 1024, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 128
  %8 = icmp uge i64 %packet.range.remaining, 1024
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  br label %packet.batch.full.loop

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full.loop
  ret void

packet.batch.full.loop:                           ; preds = %packet.batch.full.loop, %packet.batch.full
  %packet.index = phi i32 [ 0, %packet.batch.full ], [ %packet.index.next, %packet.batch.full.loop ]
  %packet.thread.offset = mul i32 %packet.index, 8
  %packet.thread.index = add i32 %base.thread.index, %packet.thread.offset
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.index.next = add i32 %packet.index, 1
  %packet.batch.has.more = icmp ult i32 %packet.index.next, %packet_count
  br i1 %packet.batch.has.more, label %packet.batch.full.loop, label %packet.batch.exit

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 128)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

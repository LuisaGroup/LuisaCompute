/tmp/luisa-full-packet.UEezjO/capture/rmsnorm-1024x4096-r0-l8-f1-p1/object/tile_xir_w8_63780_1788856231522913_0.o:
(__TEXT,__text) section
_llm_rows.packet_batch.blocks:
       0:	stp	d15, d14, [sp, #-0xa0]!
       4:	stp	d13, d12, [sp, #0x10]
       8:	stp	d11, d10, [sp, #0x20]
       c:	stp	d9, d8, [sp, #0x30]
      10:	stp	x28, x27, [sp, #0x40]
      14:	stp	x26, x25, [sp, #0x50]
      18:	stp	x24, x23, [sp, #0x60]
      1c:	stp	x22, x21, [sp, #0x70]
      20:	stp	x20, x19, [sp, #0x80]
      24:	stp	x29, x30, [sp, #0x90]
      28:	sub	sp, sp, #0x8, lsl #12
      2c:	sub	sp, sp, #0x3b0
      30:	str	x0, [sp, #0x38]
      34:	cbz	w3, 0x19a0
      38:	mov	x25, x3
      3c:	mov	w26, #0x0
      40:	add	x24, sp, #0x2c0
      44:	ldp	w9, w8, [x2, #0x2c]
      48:	stp	w8, w9, [sp, #0x30]
      4c:	ldp	w8, w9, [x2]
      50:	add	x27, sp, #0x4, lsl #12
      54:	add	x27, x27, #0x3b0
      58:	add	x28, x27, #0xe0
      5c:	add	x19, sp, #0x3b0
      60:	movi	d8, #0000000000000000
      64:	adrp	x10, lCPI0_0@PAGE
      68:	ldr	q0, [x10, lCPI0_0@PAGEOFF]
      6c:	str	q0, [sp, #0x150]
      70:	adrp	x10, lCPI0_1@PAGE
      74:	ldr	q0, [x10, lCPI0_1@PAGEOFF]
      78:	str	q0, [sp, #0x140]
      7c:	adrp	x10, lCPI0_2@PAGE
      80:	ldr	q0, [x10, lCPI0_2@PAGEOFF]
      84:	str	q0, [sp, #0x130]
      88:	adrp	x10, lCPI0_3@PAGE
      8c:	ldr	q0, [x10, lCPI0_3@PAGEOFF]
      90:	str	q0, [sp, #0x120]
      94:	adrp	x10, lCPI0_4@PAGE
      98:	ldr	q0, [x10, lCPI0_4@PAGEOFF]
      9c:	str	q0, [sp, #0x110]
      a0:	adrp	x10, lCPI0_5@PAGE
      a4:	ldr	q0, [x10, lCPI0_5@PAGEOFF]
      a8:	str	q0, [sp, #0x100]
      ac:	adrp	x10, lCPI0_6@PAGE
      b0:	ldr	q0, [x10, lCPI0_6@PAGEOFF]
      b4:	str	q0, [sp, #0xf0]
      b8:	adrp	x10, lCPI0_7@PAGE
      bc:	ldr	q0, [x10, lCPI0_7@PAGEOFF]
      c0:	str	q0, [sp, #0xe0]
      c4:	adrp	x10, lCPI0_8@PAGE
      c8:	ldr	q0, [x10, lCPI0_8@PAGEOFF]
      cc:	str	q0, [sp, #0xd0]
      d0:	adrp	x10, lCPI0_9@PAGE
      d4:	ldr	q0, [x10, lCPI0_9@PAGEOFF]
      d8:	str	q0, [sp, #0xc0]
      dc:	adrp	x10, lCPI0_10@PAGE
      e0:	ldr	q0, [x10, lCPI0_10@PAGEOFF]
      e4:	str	q0, [sp, #0xb0]
      e8:	adrp	x10, lCPI0_11@PAGE
      ec:	ldr	q0, [x10, lCPI0_11@PAGEOFF]
      f0:	str	q0, [sp, #0xa0]
      f4:	adrp	x10, lCPI0_12@PAGE
      f8:	ldr	q0, [x10, lCPI0_12@PAGEOFF]
      fc:	str	q0, [sp, #0x90]
     100:	adrp	x10, lCPI0_13@PAGE
     104:	ldr	q0, [x10, lCPI0_13@PAGEOFF]
     108:	str	q0, [sp, #0x80]
     10c:	adrp	x10, lCPI0_14@PAGE
     110:	ldr	q0, [x10, lCPI0_14@PAGEOFF]
     114:	str	q0, [sp, #0x70]
     118:	adrp	x10, lCPI0_15@PAGE
     11c:	ldr	q0, [x10, lCPI0_15@PAGEOFF]
     120:	str	q0, [sp, #0x60]
     124:	adrp	x10, lCPI0_16@PAGE
     128:	ldr	q0, [x10, lCPI0_16@PAGEOFF]
     12c:	str	q0, [sp, #0x220]
     130:	adrp	x10, lCPI0_17@PAGE
     134:	ldr	q0, [x10, lCPI0_17@PAGEOFF]
     138:	str	q0, [sp, #0x210]
     13c:	adrp	x10, lCPI0_18@PAGE
     140:	ldr	q0, [x10, lCPI0_18@PAGEOFF]
     144:	str	q0, [sp, #0x200]
     148:	adrp	x10, lCPI0_19@PAGE
     14c:	ldr	q0, [x10, lCPI0_19@PAGEOFF]
     150:	str	q0, [sp, #0x1f0]
     154:	ldp	w10, w11, [x2, #0x8]
     158:	str	x2, [sp, #0x10]
     15c:	str	x11, [sp, #0x28]
     160:	str	w3, [sp, #0x1c]
     164:	b	0x1a8
     168:	ldr	x14, [sp, #0x48]
     16c:	add	w8, w14, #0x1
     170:	ldp	w11, w9, [sp, #0x30]
     174:	cmp	w8, w9
     178:	cset	w9, eq
     17c:	csinc	w8, wzr, w14, eq
     180:	ldp	w13, w12, [sp, #0x40]
     184:	cinc	w10, w13, eq
     188:	cmp	w10, w11
     18c:	cset	w11, eq
     190:	ands	w11, w9, w11
     194:	csel	w9, wzr, w10, ne
     198:	add	w10, w12, w11
     19c:	add	w26, w26, #0x1
     1a0:	cmp	w26, w25
     1a4:	b.eq	0x198c
     1a8:	stp	w9, w10, [sp, #0x40]
     1ac:	mov	x13, x8
     1b0:	ubfiz	x8, x8, #10, #32
     1b4:	ldr	x12, [sp, #0x28]
     1b8:	cmp	x8, x12
     1bc:	csel	x9, x8, xzr, ls
     1c0:	subs	x10, x12, x9
     1c4:	cmp	x10, #0x400
     1c8:	mov	w11, #0x400
     1cc:	csel	x10, x10, x11, lo
     1d0:	cmp	x12, x9
     1d4:	ccmp	x8, x12, #0x2, hi
     1d8:	csel	x8, x10, xzr, ls
     1dc:	cmp	x8, #0x400
     1e0:	str	x13, [sp, #0x48]
     1e4:	b.lo	0x718
     1e8:	mov	w20, #0x0
     1ec:	ldr	x9, [sp, #0x38]
     1f0:	ldr	x8, [x9]
     1f4:	ldr	x22, [x9, #0x10]
     1f8:	ldr	x21, [x9, #0x30]
     1fc:	lsl	w23, w13, #7
     200:	dup.2d	v19, x8
     204:	str	q19, [sp, #0x50]
     208:	mov	x8, #0x0
     20c:	add	w9, w20, w23
     210:	and	w9, w9, #0x1fffffff
     214:	dup.2s	v1, w9
     218:	ushll.2d	v0, v1, #0xe
     21c:	add.2d	v0, v19, v0
     220:	ldp	q3, q2, [sp, #0x140]
     224:	add.2d	v2, v0, v2
     228:	mov.d	x9, v2[1]
     22c:	add.2d	v3, v0, v3
     230:	mov.d	x10, v3[1]
     234:	ldp	q5, q4, [sp, #0x120]
     238:	add.2d	v4, v0, v4
     23c:	mov.d	x11, v4[1]
     240:	add.2d	v5, v0, v5
     244:	mov.d	x12, v5[1]
     248:	fmov	x13, d2
     24c:	ldr	s2, [x13]
     250:	ld1.s	{ v2 }[1], [x9]
     254:	fmov	x9, d3
     258:	ld1.s	{ v2 }[2], [x9]
     25c:	ld1.s	{ v2 }[3], [x10]
     260:	fmov	x9, d4
     264:	ldr	s3, [x9]
     268:	ld1.s	{ v3 }[1], [x11]
     26c:	fmov	x9, d5
     270:	ld1.s	{ v3 }[2], [x9]
     274:	ushll.2d	v7, v1, #0xc
     278:	ld1.s	{ v3 }[3], [x12]
     27c:	str	q3, [x24, #0x4100]
     280:	str	q2, [x24, #0x40f0]
     284:	fmul.4s	v20, v3, v3
     288:	fmul.4s	v21, v2, v2
     28c:	ldp	q1, q2, [sp, #0xe0]
     290:	add.2d	v1, v0, v1
     294:	add.2d	v2, v0, v2
     298:	ldp	q4, q3, [sp, #0x100]
     29c:	add.2d	v3, v0, v3
     2a0:	mov.d	x9, v3[1]
     2a4:	add.2d	v4, v0, v4
     2a8:	mov.d	x10, v4[1]
     2ac:	fmov	x11, d3
     2b0:	fmov	x12, d4
     2b4:	mov.d	x13, v2[1]
     2b8:	fmov	x14, d2
     2bc:	mov.d	x15, v1[1]
     2c0:	ldr	s2, [x11]
     2c4:	ld1.s	{ v2 }[1], [x9]
     2c8:	fmov	x9, d1
     2cc:	ld1.s	{ v2 }[2], [x12]
     2d0:	ld1.s	{ v2 }[3], [x10]
     2d4:	ldr	s1, [x14]
     2d8:	ld1.s	{ v1 }[1], [x13]
     2dc:	ld1.s	{ v1 }[2], [x9]
     2e0:	ld1.s	{ v1 }[3], [x15]
     2e4:	str	q1, [x24, #0x4120]
     2e8:	str	q2, [x24, #0x4110]
     2ec:	fmul.4s	v22, v1, v1
     2f0:	fmul.4s	v23, v2, v2
     2f4:	ldp	q1, q2, [sp, #0xa0]
     2f8:	add.2d	v1, v0, v1
     2fc:	add.2d	v2, v0, v2
     300:	ldp	q3, q4, [sp, #0xc0]
     304:	add.2d	v3, v0, v3
     308:	add.2d	v4, v0, v4
     30c:	mov.d	x9, v4[1]
     310:	mov.d	x10, v3[1]
     314:	fmov	x11, d4
     318:	mov.d	x12, v2[1]
     31c:	fmov	x13, d2
     320:	mov.d	x14, v1[1]
     324:	fmov	x15, d1
     328:	ldr	s1, [x13]
     32c:	ld1.s	{ v1 }[1], [x12]
     330:	ld1.s	{ v1 }[2], [x15]
     334:	fmov	x12, d3
     338:	ld1.s	{ v1 }[3], [x14]
     33c:	ldr	s2, [x11]
     340:	ld1.s	{ v2 }[1], [x9]
     344:	ld1.s	{ v2 }[2], [x12]
     348:	ld1.s	{ v2 }[3], [x10]
     34c:	fmul.4s	v25, v1, v1
     350:	fmul.4s	v24, v2, v2
     354:	ldp	q3, q4, [sp, #0x60]
     358:	add.2d	v3, v0, v3
     35c:	add.2d	v4, v0, v4
     360:	ldp	q5, q6, [sp, #0x80]
     364:	add.2d	v5, v0, v5
     368:	add.2d	v0, v0, v6
     36c:	mov.d	x9, v0[1]
     370:	fmov	x10, d0
     374:	mov.d	x11, v5[1]
     378:	fmov	x12, d5
     37c:	mov.d	x13, v4[1]
     380:	fmov	x14, d4
     384:	mov.d	x15, v3[1]
     388:	ldr	s0, [x10]
     38c:	ld1.s	{ v0 }[1], [x9]
     390:	fmov	x9, d3
     394:	ld1.s	{ v0 }[2], [x12]
     398:	ld1.s	{ v0 }[3], [x11]
     39c:	ldr	s3, [x14]
     3a0:	ld1.s	{ v3 }[1], [x13]
     3a4:	ld1.s	{ v3 }[2], [x9]
     3a8:	ld1.s	{ v3 }[3], [x15]
     3ac:	str	q2, [x24, #0x4130]
     3b0:	str	q1, [x24, #0x4140]
     3b4:	str	q3, [x24, #0x4160]
     3b8:	str	q0, [x24, #0x4150]
     3bc:	fmul.4s	v26, v3, v3
     3c0:	fmul.4s	v27, v0, v0
     3c4:	ldp	q1, q0, [sp, #0x210]
     3c8:	orr.16b	v0, v7, v0
     3cc:	orr.16b	v1, v7, v1
     3d0:	ldp	q3, q2, [sp, #0x1f0]
     3d4:	orr.16b	v2, v7, v2
     3d8:	str	q7, [sp, #0x1e0]
     3dc:	orr.16b	v3, v7, v3
     3e0:	mov	x9, x28
     3e4:	mov	w10, #0x38
     3e8:	sub	x11, x10, #0x18
     3ec:	dup.2d	v4, x11
     3f0:	add.2d	v5, v4, v0
     3f4:	add.2d	v6, v4, v1
     3f8:	add.2d	v7, v4, v2
     3fc:	add.2d	v4, v4, v3
     400:	shl.2d	v4, v4, #0x2
     404:	shl.2d	v7, v7, #0x2
     408:	shl.2d	v6, v6, #0x2
     40c:	shl.2d	v5, v5, #0x2
     410:	add.2d	v5, v19, v5
     414:	add.2d	v6, v19, v6
     418:	add.2d	v7, v19, v7
     41c:	add.2d	v4, v19, v4
     420:	mov.d	x0, v4[1]
     424:	fmov	x14, d4
     428:	mov.d	x11, v7[1]
     42c:	fmov	x15, d7
     430:	mov.d	x16, v6[1]
     434:	sub	x12, x10, #0x10
     438:	dup.2d	v4, x12
     43c:	add.2d	v7, v4, v0
     440:	add.2d	v16, v4, v1
     444:	fmov	x17, d6
     448:	add.2d	v6, v4, v2
     44c:	add.2d	v4, v4, v3
     450:	shl.2d	v4, v4, #0x2
     454:	shl.2d	v6, v6, #0x2
     458:	mov.d	x12, v5[1]
     45c:	shl.2d	v16, v16, #0x2
     460:	shl.2d	v7, v7, #0x2
     464:	add.2d	v7, v19, v7
     468:	add.2d	v16, v19, v16
     46c:	add.2d	v6, v19, v6
     470:	fmov	x2, d5
     474:	add.2d	v5, v19, v4
     478:	mov.d	x1, v5[1]
     47c:	mov.d	x13, v6[1]
     480:	ldr	s4, [x14]
     484:	fmov	x3, d5
     488:	fmov	x4, d6
     48c:	mov.d	x5, v16[1]
     490:	fmov	x6, d16
     494:	ldr	s5, [x17]
     498:	mov.d	x14, v7[1]
     49c:	fmov	x17, d7
     4a0:	ldr	s6, [x3]
     4a4:	sub	x3, x10, #0x8
     4a8:	ldr	s7, [x6]
     4ac:	dup.2d	v16, x3
     4b0:	add.2d	v17, v16, v0
     4b4:	add.2d	v18, v16, v3
     4b8:	ld1.s	{ v4 }[1], [x0]
     4bc:	shl.2d	v18, v18, #0x2
     4c0:	add.2d	v18, v19, v18
     4c4:	mov.d	x0, v18[1]
     4c8:	ld1.s	{ v5 }[1], [x16]
     4cc:	fmov	x16, d18
     4d0:	add.2d	v18, v16, v1
     4d4:	add.2d	v16, v16, v2
     4d8:	shl.2d	v16, v16, #0x2
     4dc:	ld1.s	{ v6 }[1], [x1]
     4e0:	shl.2d	v18, v18, #0x2
     4e4:	shl.2d	v17, v17, #0x2
     4e8:	add.2d	v17, v19, v17
     4ec:	add.2d	v18, v19, v18
     4f0:	ld1.s	{ v7 }[1], [x5]
     4f4:	add.2d	v16, v19, v16
     4f8:	mov.d	x1, v16[1]
     4fc:	fmov	x3, d16
     500:	ld1.s	{ v4 }[2], [x15]
     504:	mov.d	x5, v18[1]
     508:	mov.d	x15, v17[1]
     50c:	ld1.s	{ v5 }[2], [x2]
     510:	fmov	x2, d18
     514:	ldr	s16, [x2]
     518:	ld1.s	{ v16 }[1], [x5]
     51c:	ld1.s	{ v6 }[2], [x4]
     520:	fmov	x2, d17
     524:	dup.2d	v17, x10
     528:	add.2d	v18, v17, v3
     52c:	ld1.s	{ v7 }[2], [x17]
     530:	shl.2d	v18, v18, #0x2
     534:	add.2d	v18, v19, v18
     538:	mov.d	x17, v18[1]
     53c:	ld1.s	{ v16 }[2], [x2]
     540:	fmov	x2, d18
     544:	add.2d	v18, v17, v2
     548:	shl.2d	v18, v18, #0x2
     54c:	add.2d	v18, v19, v18
     550:	ld1.s	{ v4 }[3], [x11]
     554:	mov.d	x11, v18[1]
     558:	fmov	x4, d18
     55c:	add.2d	v18, v17, v1
     560:	ld1.s	{ v5 }[3], [x12]
     564:	shl.2d	v18, v18, #0x2
     568:	add.2d	v18, v19, v18
     56c:	mov.d	x12, v18[1]
     570:	ld1.s	{ v6 }[3], [x13]
     574:	fmov	x13, d18
     578:	add.2d	v17, v17, v0
     57c:	shl.2d	v17, v17, #0x2
     580:	add.2d	v17, v19, v17
     584:	ld1.s	{ v7 }[3], [x14]
     588:	mov.d	x14, v17[1]
     58c:	fmov	x5, d17
     590:	ldr	s17, [x16]
     594:	ld1.s	{ v16 }[3], [x15]
     598:	ld1.s	{ v17 }[1], [x0]
     59c:	ld1.s	{ v17 }[2], [x3]
     5a0:	ld1.s	{ v17 }[3], [x1]
     5a4:	stp	q4, q5, [x9, #-0x60]
     5a8:	fmul.4s	v4, v4, v4
     5ac:	fmul.4s	v5, v5, v5
     5b0:	stp	q6, q7, [x9, #-0x40]
     5b4:	fmul.4s	v6, v6, v6
     5b8:	fmul.4s	v7, v7, v7
     5bc:	stp	q17, q16, [x9, #-0x20]
     5c0:	fmul.4s	v17, v17, v17
     5c4:	fadd.4s	v20, v20, v5
     5c8:	ldr	s5, [x2]
     5cc:	ld1.s	{ v5 }[1], [x17]
     5d0:	ld1.s	{ v5 }[2], [x4]
     5d4:	fadd.4s	v21, v21, v4
     5d8:	ld1.s	{ v5 }[3], [x11]
     5dc:	ldr	s4, [x13]
     5e0:	ld1.s	{ v4 }[1], [x12]
     5e4:	fadd.4s	v22, v22, v7
     5e8:	fmul.4s	v7, v16, v16
     5ec:	ld1.s	{ v4 }[2], [x5]
     5f0:	ld1.s	{ v4 }[3], [x14]
     5f4:	fadd.4s	v23, v23, v6
     5f8:	fadd.4s	v25, v25, v7
     5fc:	stp	q5, q4, [x9], #0x80
     600:	fmul.4s	v5, v5, v5
     604:	fmul.4s	v4, v4, v4
     608:	fadd.4s	v24, v24, v17
     60c:	fadd.4s	v26, v26, v4
     610:	fadd.4s	v27, v27, v5
     614:	add	x8, x8, #0x4
     618:	add	x10, x10, #0x20
     61c:	cmp	x8, #0x1fc
     620:	b.lo	0x3e8
     624:	add	x0, sp, #0x3b0
     628:	mov	x1, x22
     62c:	mov	w2, #0x4000
     630:	stp	q22, q20, [sp, #0x190]
     634:	stp	q23, q21, [sp, #0x160]
     638:	stp	q24, q26, [sp, #0x1c0]
     63c:	str	q25, [sp, #0x180]
     640:	str	q27, [sp, #0x1b0]
     644:	bl	_memcpy
     648:	mov	x8, #0x0
     64c:	ldp	q1, q0, [sp, #0x160]
     650:	fadd.4s	v0, v0, v1
     654:	ldp	q2, q1, [sp, #0x190]
     658:	fadd.4s	v1, v1, v2
     65c:	ldr	q2, [sp, #0x180]
     660:	fadd.4s	v1, v1, v2
     664:	ldp	q2, q3, [sp, #0x1b0]
     668:	fadd.4s	v0, v0, v3
     66c:	fadd.4s	v0, v0, v2
     670:	ldr	q2, [sp, #0x1d0]
     674:	fadd.4s	v1, v1, v2
     678:	rev64.4s	v2, v1
     67c:	rev64.4s	v3, v0
     680:	fadd.4s	v0, v0, v3
     684:	fadd.4s	v1, v1, v2
     688:	dup.4s	v2, v1[2]
     68c:	dup.4s	v3, v0[2]
     690:	fadd.4s	v0, v0, v3
     694:	fadd.4s	v1, v1, v2
     698:	fadd.4s	v0, v0, v1
     69c:	fadd	s0, s0, s8
     6a0:	mov	w9, #0x39800000
     6a4:	fmov	s1, w9
     6a8:	fmul	s0, s0, s1
     6ac:	mov	w9, #0xc5ac
     6b0:	movk	w9, #0x3727, lsl #16
     6b4:	fmov	s1, w9
     6b8:	fadd	s0, s0, s1
     6bc:	fsqrt	s0, s0
     6c0:	dup.4s	v0, v0[0]
     6c4:	ldr	q1, [sp, #0x1e0]
     6c8:	fmov	x9, d1
     6cc:	add	x9, x21, x9, lsl #2
     6d0:	add	x10, x27, x8
     6d4:	ldp	q1, q2, [x10]
     6d8:	fdiv.4s	v2, v2, v0
     6dc:	fdiv.4s	v1, v1, v0
     6e0:	add	x10, x19, x8
     6e4:	ldp	q4, q3, [x10]
     6e8:	fmul.4s	v1, v1, v4
     6ec:	fmul.4s	v2, v2, v3
     6f0:	add	x10, x9, x8
     6f4:	stp	q1, q2, [x10]
     6f8:	add	x8, x8, #0x20
     6fc:	cmp	x8, #0x4, lsl #12
     700:	b.ne	0x6d0
     704:	add	w20, w20, #0x1
     708:	cmp	w20, #0x80
     70c:	ldr	q19, [sp, #0x50]
     710:	b.ne	0x208
     714:	b	0x168
     718:	str	w26, [sp, #0x50]
     71c:	lsr	x20, x8, #3
     720:	str	x8, [sp, #0x20]
     724:	cmp	x8, #0x8
     728:	b.lo	0xc54
     72c:	mov	w23, #0x0
     730:	ldr	x8, [sp, #0x38]
     734:	ldr	x25, [x8]
     738:	ldr	x22, [x8, #0x10]
     73c:	ldr	x9, [sp, #0x48]
     740:	lsl	w26, w9, #7
     744:	ldr	x21, [x8, #0x30]
     748:	mov	x8, #0x0
     74c:	add	w9, w23, w26
     750:	and	w9, w9, #0x1fffffff
     754:	dup.2s	v2, w9
     758:	dup.2d	v0, x25
     75c:	ushll.2d	v1, v2, #0xe
     760:	add.2d	v1, v0, v1
     764:	ldp	q4, q3, [sp, #0x140]
     768:	add.2d	v3, v1, v3
     76c:	mov.d	x9, v3[1]
     770:	add.2d	v4, v1, v4
     774:	mov.d	x10, v4[1]
     778:	ldp	q6, q5, [sp, #0x120]
     77c:	add.2d	v5, v1, v5
     780:	mov.d	x11, v5[1]
     784:	add.2d	v6, v1, v6
     788:	mov.d	x12, v6[1]
     78c:	fmov	x13, d3
     790:	ldr	s3, [x13]
     794:	ld1.s	{ v3 }[1], [x9]
     798:	fmov	x9, d4
     79c:	ld1.s	{ v3 }[2], [x9]
     7a0:	ld1.s	{ v3 }[3], [x10]
     7a4:	fmov	x9, d5
     7a8:	ldr	s4, [x9]
     7ac:	ushll.2d	v16, v2, #0xc
     7b0:	ld1.s	{ v4 }[1], [x11]
     7b4:	fmov	x9, d6
     7b8:	ld1.s	{ v4 }[2], [x9]
     7bc:	ld1.s	{ v4 }[3], [x12]
     7c0:	str	q4, [x24, #0x4100]
     7c4:	str	q3, [x24, #0x40f0]
     7c8:	fmul.4s	v20, v4, v4
     7cc:	fmul.4s	v21, v3, v3
     7d0:	ldp	q2, q3, [sp, #0xe0]
     7d4:	add.2d	v2, v1, v2
     7d8:	add.2d	v3, v1, v3
     7dc:	ldp	q4, q5, [sp, #0x100]
     7e0:	add.2d	v4, v1, v4
     7e4:	add.2d	v5, v1, v5
     7e8:	mov.d	x9, v5[1]
     7ec:	fmov	x10, d5
     7f0:	mov.d	x11, v4[1]
     7f4:	fmov	x12, d4
     7f8:	mov.d	x13, v3[1]
     7fc:	fmov	x14, d3
     800:	mov.d	x15, v2[1]
     804:	ldr	s3, [x10]
     808:	ld1.s	{ v3 }[1], [x9]
     80c:	fmov	x9, d2
     810:	ld1.s	{ v3 }[2], [x12]
     814:	ld1.s	{ v3 }[3], [x11]
     818:	ldr	s2, [x14]
     81c:	ld1.s	{ v2 }[1], [x13]
     820:	ld1.s	{ v2 }[2], [x9]
     824:	ld1.s	{ v2 }[3], [x15]
     828:	str	q2, [x24, #0x4120]
     82c:	str	q3, [x24, #0x4110]
     830:	fmul.4s	v22, v2, v2
     834:	fmul.4s	v23, v3, v3
     838:	ldp	q2, q3, [sp, #0xa0]
     83c:	add.2d	v2, v1, v2
     840:	add.2d	v3, v1, v3
     844:	ldp	q4, q5, [sp, #0xc0]
     848:	add.2d	v4, v1, v4
     84c:	add.2d	v5, v1, v5
     850:	mov.d	x9, v5[1]
     854:	mov.d	x10, v4[1]
     858:	fmov	x11, d5
     85c:	mov.d	x12, v3[1]
     860:	fmov	x13, d3
     864:	mov.d	x14, v2[1]
     868:	fmov	x15, d2
     86c:	ldr	s2, [x13]
     870:	ld1.s	{ v2 }[1], [x12]
     874:	ld1.s	{ v2 }[2], [x15]
     878:	fmov	x12, d4
     87c:	ld1.s	{ v2 }[3], [x14]
     880:	ldr	s3, [x11]
     884:	ld1.s	{ v3 }[1], [x9]
     888:	ld1.s	{ v3 }[2], [x12]
     88c:	ld1.s	{ v3 }[3], [x10]
     890:	fmul.4s	v25, v2, v2
     894:	fmul.4s	v24, v3, v3
     898:	ldp	q4, q5, [sp, #0x60]
     89c:	add.2d	v4, v1, v4
     8a0:	add.2d	v5, v1, v5
     8a4:	ldp	q6, q7, [sp, #0x80]
     8a8:	add.2d	v6, v1, v6
     8ac:	add.2d	v1, v1, v7
     8b0:	mov.d	x9, v1[1]
     8b4:	fmov	x10, d1
     8b8:	mov.d	x11, v6[1]
     8bc:	fmov	x12, d6
     8c0:	mov.d	x13, v5[1]
     8c4:	fmov	x14, d5
     8c8:	mov.d	x15, v4[1]
     8cc:	ldr	s1, [x10]
     8d0:	ld1.s	{ v1 }[1], [x9]
     8d4:	fmov	x9, d4
     8d8:	ld1.s	{ v1 }[2], [x12]
     8dc:	ld1.s	{ v1 }[3], [x11]
     8e0:	ldr	s4, [x14]
     8e4:	ld1.s	{ v4 }[1], [x13]
     8e8:	ld1.s	{ v4 }[2], [x9]
     8ec:	ld1.s	{ v4 }[3], [x15]
     8f0:	str	q3, [x24, #0x4130]
     8f4:	str	q2, [x24, #0x4140]
     8f8:	str	q4, [x24, #0x4160]
     8fc:	str	q1, [x24, #0x4150]
     900:	fmul.4s	v26, v4, v4
     904:	fmul.4s	v27, v1, v1
     908:	ldp	q2, q1, [sp, #0x210]
     90c:	orr.16b	v1, v16, v1
     910:	orr.16b	v2, v16, v2
     914:	ldp	q4, q3, [sp, #0x1f0]
     918:	orr.16b	v3, v16, v3
     91c:	str	q16, [sp, #0x1e0]
     920:	orr.16b	v4, v16, v4
     924:	mov	x9, x28
     928:	mov	w10, #0x38
     92c:	sub	x11, x10, #0x18
     930:	dup.2d	v5, x11
     934:	add.2d	v6, v5, v1
     938:	add.2d	v7, v5, v2
     93c:	add.2d	v16, v5, v3
     940:	add.2d	v5, v5, v4
     944:	shl.2d	v5, v5, #0x2
     948:	shl.2d	v16, v16, #0x2
     94c:	shl.2d	v7, v7, #0x2
     950:	shl.2d	v6, v6, #0x2
     954:	add.2d	v6, v0, v6
     958:	add.2d	v7, v0, v7
     95c:	add.2d	v16, v0, v16
     960:	add.2d	v5, v0, v5
     964:	mov.d	x0, v5[1]
     968:	fmov	x14, d5
     96c:	mov.d	x11, v16[1]
     970:	fmov	x15, d16
     974:	mov.d	x16, v7[1]
     978:	sub	x12, x10, #0x10
     97c:	dup.2d	v5, x12
     980:	add.2d	v16, v5, v1
     984:	add.2d	v17, v5, v2
     988:	fmov	x17, d7
     98c:	add.2d	v7, v5, v3
     990:	add.2d	v5, v5, v4
     994:	shl.2d	v5, v5, #0x2
     998:	shl.2d	v7, v7, #0x2
     99c:	mov.d	x12, v6[1]
     9a0:	shl.2d	v17, v17, #0x2
     9a4:	shl.2d	v16, v16, #0x2
     9a8:	add.2d	v16, v0, v16
     9ac:	add.2d	v17, v0, v17
     9b0:	add.2d	v7, v0, v7
     9b4:	fmov	x2, d6
     9b8:	add.2d	v6, v0, v5
     9bc:	mov.d	x1, v6[1]
     9c0:	mov.d	x13, v7[1]
     9c4:	ldr	s5, [x14]
     9c8:	fmov	x3, d6
     9cc:	fmov	x4, d7
     9d0:	mov.d	x5, v17[1]
     9d4:	fmov	x6, d17
     9d8:	ldr	s6, [x17]
     9dc:	mov.d	x14, v16[1]
     9e0:	fmov	x17, d16
     9e4:	ldr	s7, [x3]
     9e8:	sub	x3, x10, #0x8
     9ec:	ldr	s16, [x6]
     9f0:	dup.2d	v17, x3
     9f4:	add.2d	v18, v17, v1
     9f8:	add.2d	v19, v17, v4
     9fc:	ld1.s	{ v5 }[1], [x0]
     a00:	shl.2d	v19, v19, #0x2
     a04:	add.2d	v19, v0, v19
     a08:	mov.d	x0, v19[1]
     a0c:	ld1.s	{ v6 }[1], [x16]
     a10:	fmov	x16, d19
     a14:	add.2d	v19, v17, v2
     a18:	add.2d	v17, v17, v3
     a1c:	shl.2d	v17, v17, #0x2
     a20:	ld1.s	{ v7 }[1], [x1]
     a24:	shl.2d	v19, v19, #0x2
     a28:	shl.2d	v18, v18, #0x2
     a2c:	add.2d	v18, v0, v18
     a30:	add.2d	v19, v0, v19
     a34:	ld1.s	{ v16 }[1], [x5]
     a38:	add.2d	v17, v0, v17
     a3c:	mov.d	x1, v17[1]
     a40:	fmov	x3, d17
     a44:	ld1.s	{ v5 }[2], [x15]
     a48:	mov.d	x5, v19[1]
     a4c:	mov.d	x15, v18[1]
     a50:	ld1.s	{ v6 }[2], [x2]
     a54:	fmov	x2, d19
     a58:	ldr	s17, [x2]
     a5c:	ld1.s	{ v17 }[1], [x5]
     a60:	ld1.s	{ v7 }[2], [x4]
     a64:	fmov	x2, d18
     a68:	dup.2d	v18, x10
     a6c:	add.2d	v19, v18, v4
     a70:	ld1.s	{ v16 }[2], [x17]
     a74:	shl.2d	v19, v19, #0x2
     a78:	add.2d	v19, v0, v19
     a7c:	mov.d	x17, v19[1]
     a80:	ld1.s	{ v17 }[2], [x2]
     a84:	fmov	x2, d19
     a88:	add.2d	v19, v18, v3
     a8c:	shl.2d	v19, v19, #0x2
     a90:	add.2d	v19, v0, v19
     a94:	ld1.s	{ v5 }[3], [x11]
     a98:	mov.d	x11, v19[1]
     a9c:	fmov	x4, d19
     aa0:	add.2d	v19, v18, v2
     aa4:	ld1.s	{ v6 }[3], [x12]
     aa8:	shl.2d	v19, v19, #0x2
     aac:	add.2d	v19, v0, v19
     ab0:	mov.d	x12, v19[1]
     ab4:	ld1.s	{ v7 }[3], [x13]
     ab8:	fmov	x13, d19
     abc:	add.2d	v18, v18, v1
     ac0:	shl.2d	v18, v18, #0x2
     ac4:	add.2d	v18, v0, v18
     ac8:	ld1.s	{ v16 }[3], [x14]
     acc:	mov.d	x14, v18[1]
     ad0:	fmov	x5, d18
     ad4:	ldr	s18, [x16]
     ad8:	ld1.s	{ v17 }[3], [x15]
     adc:	ld1.s	{ v18 }[1], [x0]
     ae0:	ld1.s	{ v18 }[2], [x3]
     ae4:	ld1.s	{ v18 }[3], [x1]
     ae8:	stp	q5, q6, [x9, #-0x60]
     aec:	fmul.4s	v5, v5, v5
     af0:	fmul.4s	v6, v6, v6
     af4:	stp	q7, q16, [x9, #-0x40]
     af8:	fmul.4s	v7, v7, v7
     afc:	fmul.4s	v16, v16, v16
     b00:	stp	q18, q17, [x9, #-0x20]
     b04:	fmul.4s	v18, v18, v18
     b08:	fadd.4s	v20, v20, v6
     b0c:	ldr	s6, [x2]
     b10:	ld1.s	{ v6 }[1], [x17]
     b14:	ld1.s	{ v6 }[2], [x4]
     b18:	fadd.4s	v21, v21, v5
     b1c:	ld1.s	{ v6 }[3], [x11]
     b20:	ldr	s5, [x13]
     b24:	ld1.s	{ v5 }[1], [x12]
     b28:	fadd.4s	v22, v22, v16
     b2c:	fmul.4s	v16, v17, v17
     b30:	ld1.s	{ v5 }[2], [x5]
     b34:	ld1.s	{ v5 }[3], [x14]
     b38:	fadd.4s	v23, v23, v7
     b3c:	fadd.4s	v25, v25, v16
     b40:	stp	q6, q5, [x9], #0x80
     b44:	fmul.4s	v6, v6, v6
     b48:	fmul.4s	v5, v5, v5
     b4c:	fadd.4s	v24, v24, v18
     b50:	fadd.4s	v26, v26, v5
     b54:	fadd.4s	v27, v27, v6
     b58:	add	x8, x8, #0x4
     b5c:	add	x10, x10, #0x20
     b60:	cmp	x8, #0x1fc
     b64:	b.lo	0x92c
     b68:	add	x0, sp, #0x3b0
     b6c:	mov	x1, x22
     b70:	mov	w2, #0x4000
     b74:	stp	q22, q20, [sp, #0x190]
     b78:	stp	q23, q21, [sp, #0x160]
     b7c:	stp	q24, q26, [sp, #0x1c0]
     b80:	str	q25, [sp, #0x180]
     b84:	str	q27, [sp, #0x1b0]
     b88:	bl	_memcpy
     b8c:	mov	x8, #0x0
     b90:	ldp	q1, q0, [sp, #0x160]
     b94:	fadd.4s	v0, v0, v1
     b98:	ldp	q2, q1, [sp, #0x190]
     b9c:	fadd.4s	v1, v1, v2
     ba0:	ldr	q2, [sp, #0x180]
     ba4:	fadd.4s	v1, v1, v2
     ba8:	ldp	q2, q3, [sp, #0x1b0]
     bac:	fadd.4s	v0, v0, v3
     bb0:	fadd.4s	v0, v0, v2
     bb4:	ldr	q2, [sp, #0x1d0]
     bb8:	fadd.4s	v1, v1, v2
     bbc:	rev64.4s	v2, v1
     bc0:	rev64.4s	v3, v0
     bc4:	fadd.4s	v0, v0, v3
     bc8:	fadd.4s	v1, v1, v2
     bcc:	dup.4s	v2, v1[2]
     bd0:	dup.4s	v3, v0[2]
     bd4:	fadd.4s	v0, v0, v3
     bd8:	fadd.4s	v1, v1, v2
     bdc:	fadd.4s	v0, v0, v1
     be0:	fadd	s0, s0, s8
     be4:	mov	w9, #0x39800000
     be8:	fmov	s1, w9
     bec:	fmul	s0, s0, s1
     bf0:	mov	w9, #0xc5ac
     bf4:	movk	w9, #0x3727, lsl #16
     bf8:	fmov	s1, w9
     bfc:	fadd	s0, s0, s1
     c00:	fsqrt	s0, s0
     c04:	dup.4s	v0, v0[0]
     c08:	ldr	q1, [sp, #0x1e0]
     c0c:	fmov	x9, d1
     c10:	add	x9, x21, x9, lsl #2
     c14:	add	x10, x27, x8
     c18:	ldp	q1, q2, [x10]
     c1c:	fdiv.4s	v2, v2, v0
     c20:	fdiv.4s	v1, v1, v0
     c24:	add	x10, x19, x8
     c28:	ldp	q4, q3, [x10]
     c2c:	fmul.4s	v1, v1, v4
     c30:	fmul.4s	v2, v2, v3
     c34:	add	x10, x9, x8
     c38:	stp	q1, q2, [x10]
     c3c:	add	x8, x8, #0x20
     c40:	cmp	x8, #0x4, lsl #12
     c44:	b.ne	0xc14
     c48:	add	w23, w23, #0x1
     c4c:	cmp	w23, w20
     c50:	b.ne	0x748
     c54:	ldr	x8, [sp, #0x20]
     c58:	and	w8, w8, #0x7
     c5c:	ldr	w25, [sp, #0x1c]
     c60:	ldr	w26, [sp, #0x50]
     c64:	cbz	w8, 0x168
     c68:	dup.4s	v1, w8
     c6c:	adrp	x8, lCPI0_21@PAGE
     c70:	ldr	q2, [x8, lCPI0_21@PAGEOFF]
     c74:	adrp	x8, lCPI0_22@PAGE
     c78:	ldr	q0, [x8, lCPI0_22@PAGEOFF]
     c7c:	cmhi.4s	v0, v1, v0
     c80:	cmhi.4s	v1, v1, v2
     c84:	uzp1.8h	v3, v1, v0
     c88:	umaxv.8h	h2, v3
     c8c:	fmov	w8, s2
     c90:	ldr	x10, [sp, #0x48]
     c94:	tbz	w8, #0x0, 0x168
     c98:	ldr	x8, [sp, #0x38]
     c9c:	ldr	x9, [x8]
     ca0:	adrp	x8, lCPI0_20@PAGE
     ca4:	ldr	q2, [x8, lCPI0_20@PAGEOFF]
     ca8:	and.16b	v2, v3, v2
     cac:	addv.8h	h2, v2
     cb0:	fmov	w8, s2
     cb4:	sshll.2d	v19, v1, #0x0
     cb8:	ldr	q4, [sp, #0x1f0]
     cbc:	and.16b	v5, v19, v4
     cc0:	ubfiz	w10, w10, #7, #22
     cc4:	orr	w10, w10, w20
     cc8:	dup.4s	v4, w10
     ccc:	and.16b	v6, v1, v4
     cd0:	ushll.2d	v20, v6, #0xc
     cd4:	str	q5, [sp, #0x1e0]
     cd8:	orr.16b	v5, v20, v5
     cdc:	shl.2d	v5, v5, #0x2
     ce0:	dup.2d	v16, x9
     ce4:	add.2d	v5, v16, v5
     ce8:	movi.2d	v21, #0000000000000000
     cec:	movi.2d	v22, #0000000000000000
     cf0:	tbz	w8, #0x0, 0xcfc
     cf4:	fmov	x9, d5
     cf8:	ldr	s21, [x9]
     cfc:	and	w8, w8, #0xff
     d00:	tbz	w8, #0x1, 0xd0c
     d04:	mov.d	x9, v5[1]
     d08:	ld1.s	{ v21 }[1], [x9]
     d0c:	sshll2.2d	v17, v1, #0x0
     d10:	ldr	q5, [sp, #0x200]
     d14:	and.16b	v5, v17, v5
     d18:	ushll2.2d	v23, v6, #0xc
     d1c:	str	q5, [sp, #0x1d0]
     d20:	orr.16b	v5, v23, v5
     d24:	shl.2d	v5, v5, #0x2
     d28:	add.2d	v5, v16, v5
     d2c:	tbz	w8, #0x2, 0xd38
     d30:	fmov	x9, d5
     d34:	ld1.s	{ v21 }[2], [x9]
     d38:	tbz	w8, #0x3, 0xd44
     d3c:	mov.d	x9, v5[1]
     d40:	ld1.s	{ v21 }[3], [x9]
     d44:	sshll.2d	v24, v0, #0x0
     d48:	ldr	q5, [sp, #0x210]
     d4c:	and.16b	v5, v24, v5
     d50:	and.16b	v4, v0, v4
     d54:	ushll.2d	v25, v4, #0xc
     d58:	str	q5, [sp, #0x1c0]
     d5c:	orr.16b	v5, v25, v5
     d60:	shl.2d	v5, v5, #0x2
     d64:	add.2d	v5, v16, v5
     d68:	tbz	w8, #0x4, 0xd74
     d6c:	fmov	x9, d5
     d70:	ld1.s	{ v22 }[0], [x9]
     d74:	tbz	w8, #0x5, 0xd80
     d78:	mov.d	x9, v5[1]
     d7c:	ld1.s	{ v22 }[1], [x9]
     d80:	sshll2.2d	v18, v0, #0x0
     d84:	ldr	q5, [sp, #0x220]
     d88:	and.16b	v7, v18, v5
     d8c:	ushll2.2d	v26, v4, #0xc
     d90:	orr.16b	v4, v26, v7
     d94:	shl.2d	v4, v4, #0x2
     d98:	add.2d	v4, v16, v4
     d9c:	tbz	w8, #0x6, 0xda8
     da0:	fmov	x9, d4
     da4:	ld1.s	{ v22 }[2], [x9]
     da8:	tbz	w8, #0x7, 0xdb4
     dac:	mov.d	x8, v4[1]
     db0:	ld1.s	{ v22 }[3], [x8]
     db4:	ldr	x8, [sp, #0x38]
     db8:	ldr	x9, [x8, #0x10]
     dbc:	ldr	x8, [x8, #0x30]
     dc0:	fmov	w10, s2
     dc4:	sshll.2d	v4, v1, #0x0
     dc8:	str	q21, [x24, #0x40f0]
     dcc:	str	q22, [x24, #0x4100]
     dd0:	adrp	x11, lCPI0_23@PAGE
     dd4:	ldr	q5, [x11, lCPI0_23@PAGEOFF]
     dd8:	and.16b	v4, v4, v5
     ddc:	orr.16b	v4, v20, v4
     de0:	shl.2d	v4, v4, #0x2
     de4:	add.2d	v4, v16, v4
     de8:	movi.2d	v27, #0000000000000000
     dec:	movi.2d	v31, #0000000000000000
     df0:	tbz	w10, #0x0, 0xdfc
     df4:	fmov	x11, d4
     df8:	ldr	s27, [x11]
     dfc:	and	w10, w10, #0xff
     e00:	tbz	w10, #0x1, 0xe0c
     e04:	mov.d	x11, v4[1]
     e08:	ld1.s	{ v27 }[1], [x11]
     e0c:	adrp	x11, lCPI0_25@PAGE
     e10:	ldr	q4, [x11, lCPI0_25@PAGEOFF]
     e14:	and.16b	v4, v17, v4
     e18:	orr.16b	v4, v23, v4
     e1c:	shl.2d	v4, v4, #0x2
     e20:	add.2d	v4, v16, v4
     e24:	tbz	w10, #0x2, 0xe30
     e28:	fmov	x11, d4
     e2c:	ld1.s	{ v27 }[2], [x11]
     e30:	tbz	w10, #0x3, 0xe3c
     e34:	mov.d	x11, v4[1]
     e38:	ld1.s	{ v27 }[3], [x11]
     e3c:	sshll.2d	v4, v0, #0x0
     e40:	adrp	x11, lCPI0_24@PAGE
     e44:	ldr	q5, [x11, lCPI0_24@PAGEOFF]
     e48:	and.16b	v4, v4, v5
     e4c:	orr.16b	v4, v25, v4
     e50:	shl.2d	v4, v4, #0x2
     e54:	add.2d	v4, v16, v4
     e58:	tbz	w10, #0x4, 0xe64
     e5c:	fmov	x11, d4
     e60:	ld1.s	{ v31 }[0], [x11]
     e64:	tbz	w10, #0x5, 0xe70
     e68:	mov.d	x11, v4[1]
     e6c:	ld1.s	{ v31 }[1], [x11]
     e70:	adrp	x11, lCPI0_26@PAGE
     e74:	ldr	q4, [x11, lCPI0_26@PAGEOFF]
     e78:	and.16b	v4, v18, v4
     e7c:	orr.16b	v4, v26, v4
     e80:	shl.2d	v4, v4, #0x2
     e84:	add.2d	v4, v16, v4
     e88:	tbz	w10, #0x6, 0xe94
     e8c:	fmov	x11, d4
     e90:	ld1.s	{ v31 }[2], [x11]
     e94:	tbz	w10, #0x7, 0xea0
     e98:	mov.d	x10, v4[1]
     e9c:	ld1.s	{ v31 }[3], [x10]
     ea0:	fmov	w10, s2
     ea4:	sshll.2d	v4, v1, #0x0
     ea8:	str	q27, [x24, #0x4110]
     eac:	str	q31, [x24, #0x4120]
     eb0:	adrp	x11, lCPI0_27@PAGE
     eb4:	ldr	q5, [x11, lCPI0_27@PAGEOFF]
     eb8:	and.16b	v4, v4, v5
     ebc:	orr.16b	v4, v20, v4
     ec0:	shl.2d	v4, v4, #0x2
     ec4:	add.2d	v4, v16, v4
     ec8:	movi.2d	v9, #0000000000000000
     ecc:	movi.2d	v10, #0000000000000000
     ed0:	tbz	w10, #0x0, 0xedc
     ed4:	fmov	x11, d4
     ed8:	ldr	s9, [x11]
     edc:	and	w10, w10, #0xff
     ee0:	tbz	w10, #0x1, 0xeec
     ee4:	mov.d	x11, v4[1]
     ee8:	ld1.s	{ v9 }[1], [x11]
     eec:	adrp	x11, lCPI0_29@PAGE
     ef0:	ldr	q4, [x11, lCPI0_29@PAGEOFF]
     ef4:	and.16b	v4, v17, v4
     ef8:	orr.16b	v4, v23, v4
     efc:	shl.2d	v4, v4, #0x2
     f00:	add.2d	v4, v16, v4
     f04:	tbz	w10, #0x2, 0xf10
     f08:	fmov	x11, d4
     f0c:	ld1.s	{ v9 }[2], [x11]
     f10:	tbz	w10, #0x3, 0xf1c
     f14:	mov.d	x11, v4[1]
     f18:	ld1.s	{ v9 }[3], [x11]
     f1c:	sshll.2d	v4, v0, #0x0
     f20:	adrp	x11, lCPI0_28@PAGE
     f24:	ldr	q5, [x11, lCPI0_28@PAGEOFF]
     f28:	and.16b	v4, v4, v5
     f2c:	orr.16b	v4, v25, v4
     f30:	shl.2d	v4, v4, #0x2
     f34:	add.2d	v4, v16, v4
     f38:	tbz	w10, #0x4, 0xf44
     f3c:	fmov	x11, d4
     f40:	ld1.s	{ v10 }[0], [x11]
     f44:	tbz	w10, #0x5, 0xf50
     f48:	mov.d	x11, v4[1]
     f4c:	ld1.s	{ v10 }[1], [x11]
     f50:	adrp	x11, lCPI0_30@PAGE
     f54:	ldr	q4, [x11, lCPI0_30@PAGEOFF]
     f58:	and.16b	v4, v18, v4
     f5c:	orr.16b	v4, v26, v4
     f60:	shl.2d	v4, v4, #0x2
     f64:	add.2d	v4, v16, v4
     f68:	tbz	w10, #0x6, 0xf74
     f6c:	fmov	x11, d4
     f70:	ld1.s	{ v10 }[2], [x11]
     f74:	tbz	w10, #0x7, 0xf80
     f78:	mov.d	x10, v4[1]
     f7c:	ld1.s	{ v10 }[3], [x10]
     f80:	fmov	w10, s2
     f84:	sshll.2d	v4, v1, #0x0
     f88:	str	q9, [x24, #0x4130]
     f8c:	str	q10, [x24, #0x4140]
     f90:	adrp	x11, lCPI0_31@PAGE
     f94:	ldr	q5, [x11, lCPI0_31@PAGEOFF]
     f98:	and.16b	v4, v4, v5
     f9c:	orr.16b	v4, v20, v4
     fa0:	shl.2d	v4, v4, #0x2
     fa4:	add.2d	v4, v16, v4
     fa8:	movi.2d	v11, #0000000000000000
     fac:	movi.2d	v12, #0000000000000000
     fb0:	tbz	w10, #0x0, 0xfbc
     fb4:	fmov	x11, d4
     fb8:	ldr	s11, [x11]
     fbc:	and	w10, w10, #0xff
     fc0:	tbz	w10, #0x1, 0xfcc
     fc4:	mov.d	x11, v4[1]
     fc8:	ld1.s	{ v11 }[1], [x11]
     fcc:	adrp	x11, lCPI0_33@PAGE
     fd0:	ldr	q4, [x11, lCPI0_33@PAGEOFF]
     fd4:	and.16b	v4, v17, v4
     fd8:	orr.16b	v4, v23, v4
     fdc:	shl.2d	v4, v4, #0x2
     fe0:	add.2d	v4, v16, v4
     fe4:	tbz	w10, #0x2, 0xff0
     fe8:	fmov	x11, d4
     fec:	ld1.s	{ v11 }[2], [x11]
     ff0:	tbz	w10, #0x3, 0xffc
     ff4:	mov.d	x11, v4[1]
     ff8:	ld1.s	{ v11 }[3], [x11]
     ffc:	sshll.2d	v4, v0, #0x0
    1000:	adrp	x11, lCPI0_32@PAGE
    1004:	ldr	q5, [x11, lCPI0_32@PAGEOFF]
    1008:	and.16b	v4, v4, v5
    100c:	orr.16b	v4, v25, v4
    1010:	shl.2d	v4, v4, #0x2
    1014:	add.2d	v4, v16, v4
    1018:	tbz	w10, #0x4, 0x1024
    101c:	fmov	x11, d4
    1020:	ld1.s	{ v12 }[0], [x11]
    1024:	tbz	w10, #0x5, 0x1030
    1028:	mov.d	x11, v4[1]
    102c:	ld1.s	{ v12 }[1], [x11]
    1030:	adrp	x11, lCPI0_34@PAGE
    1034:	ldr	q4, [x11, lCPI0_34@PAGEOFF]
    1038:	and.16b	v4, v18, v4
    103c:	orr.16b	v4, v26, v4
    1040:	shl.2d	v4, v4, #0x2
    1044:	add.2d	v4, v16, v4
    1048:	tbz	w10, #0x6, 0x1054
    104c:	fmov	x11, d4
    1050:	ld1.s	{ v12 }[2], [x11]
    1054:	tbz	w10, #0x7, 0x1060
    1058:	mov.d	x10, v4[1]
    105c:	ld1.s	{ v12 }[3], [x10]
    1060:	mov	x11, #0x0
    1064:	and.16b	v28, v18, v26
    1068:	and.16b	v29, v17, v23
    106c:	fmov	w10, s2
    1070:	and.16b	v30, v24, v25
    1074:	and	w10, w10, #0xff
    1078:	and.16b	v19, v19, v20
    107c:	fmul.4s	v4, v21, v21
    1080:	fmul.4s	v5, v22, v22
    1084:	fmul.4s	v22, v27, v27
    1088:	fmul.4s	v23, v31, v31
    108c:	fmul.4s	v26, v9, v9
    1090:	fmul.4s	v27, v10, v10
    1094:	str	q11, [x24, #0x4150]
    1098:	str	q12, [x24, #0x4160]
    109c:	fmul.4s	v31, v11, v11
    10a0:	fmul.4s	v9, v12, v12
    10a4:	and.16b	v21, v0, v5
    10a8:	and.16b	v20, v1, v4
    10ac:	and.16b	v25, v0, v23
    10b0:	and.16b	v24, v1, v22
    10b4:	and.16b	v22, v0, v27
    10b8:	and.16b	v26, v1, v26
    10bc:	and.16b	v23, v0, v9
    10c0:	mov	x12, x28
    10c4:	mov	w13, #0x20
    10c8:	and.16b	v27, v1, v31
    10cc:	b	0x1150
    10d0:	fmul.4s	v4, v9, v9
    10d4:	fmul.4s	v5, v31, v31
    10d8:	fadd.4s	v5, v20, v5
    10dc:	fadd.4s	v4, v21, v4
    10e0:	fmul.4s	v6, v11, v11
    10e4:	fmul.4s	v31, v10, v10
    10e8:	fadd.4s	v31, v24, v31
    10ec:	fadd.4s	v6, v25, v6
    10f0:	fmul.4s	v9, v13, v13
    10f4:	fmul.4s	v10, v12, v12
    10f8:	fadd.4s	v10, v26, v10
    10fc:	fadd.4s	v9, v22, v9
    1100:	ldp	q11, q12, [x12]
    1104:	bit.16b	v12, v15, v0
    1108:	bit.16b	v11, v14, v1
    110c:	stp	q11, q12, [x12], #0x80
    1110:	fmul.4s	v11, v14, v14
    1114:	fmul.4s	v12, v15, v15
    1118:	fadd.4s	v12, v23, v12
    111c:	fadd.4s	v11, v27, v11
    1120:	bit.16b	v21, v4, v0
    1124:	bit.16b	v20, v5, v1
    1128:	bit.16b	v25, v6, v0
    112c:	bit.16b	v24, v31, v1
    1130:	bit.16b	v22, v9, v0
    1134:	add	x11, x11, #0x4
    1138:	bit.16b	v26, v10, v1
    113c:	add	x13, x13, #0x20
    1140:	bit.16b	v27, v11, v1
    1144:	bit.16b	v23, v12, v0
    1148:	cmp	x11, #0x1fc
    114c:	b.hs	0x1500
    1150:	fmov	w14, s2
    1154:	sshll.2d	v4, v1, #0x0
    1158:	dup.2d	v10, x13
    115c:	ldr	q5, [sp, #0x1f0]
    1160:	orr.16b	v5, v10, v5
    1164:	and.16b	v4, v4, v5
    1168:	add.2d	v4, v4, v19
    116c:	shl.2d	v4, v4, #0x2
    1170:	add.2d	v4, v16, v4
    1174:	movi.2d	v31, #0000000000000000
    1178:	movi.2d	v9, #0000000000000000
    117c:	tbz	w14, #0x0, 0x1188
    1180:	fmov	x15, d4
    1184:	ldr	s31, [x15]
    1188:	and	w14, w14, #0xff
    118c:	tbz	w14, #0x1, 0x1198
    1190:	mov.d	x15, v4[1]
    1194:	ld1.s	{ v31 }[1], [x15]
    1198:	ldr	q4, [sp, #0x200]
    119c:	orr.16b	v4, v10, v4
    11a0:	and.16b	v4, v17, v4
    11a4:	add.2d	v4, v4, v29
    11a8:	shl.2d	v4, v4, #0x2
    11ac:	add.2d	v4, v16, v4
    11b0:	tbz	w14, #0x2, 0x11bc
    11b4:	fmov	x15, d4
    11b8:	ld1.s	{ v31 }[2], [x15]
    11bc:	tbz	w14, #0x3, 0x11c8
    11c0:	mov.d	x15, v4[1]
    11c4:	ld1.s	{ v31 }[3], [x15]
    11c8:	sshll.2d	v4, v0, #0x0
    11cc:	ldr	q5, [sp, #0x210]
    11d0:	orr.16b	v5, v10, v5
    11d4:	and.16b	v4, v4, v5
    11d8:	add.2d	v4, v4, v30
    11dc:	shl.2d	v4, v4, #0x2
    11e0:	add.2d	v4, v16, v4
    11e4:	tbz	w14, #0x4, 0x11f0
    11e8:	fmov	x15, d4
    11ec:	ld1.s	{ v9 }[0], [x15]
    11f0:	tbz	w14, #0x5, 0x11fc
    11f4:	mov.d	x15, v4[1]
    11f8:	ld1.s	{ v9 }[1], [x15]
    11fc:	ldr	q4, [sp, #0x220]
    1200:	orr.16b	v4, v10, v4
    1204:	and.16b	v4, v18, v4
    1208:	add.2d	v4, v4, v28
    120c:	shl.2d	v4, v4, #0x2
    1210:	add.2d	v4, v16, v4
    1214:	tbz	w14, #0x6, 0x1220
    1218:	fmov	x15, d4
    121c:	ld1.s	{ v9 }[2], [x15]
    1220:	tbz	w14, #0x7, 0x122c
    1224:	mov.d	x14, v4[1]
    1228:	ld1.s	{ v9 }[3], [x14]
    122c:	fmov	w14, s2
    1230:	sshll.2d	v4, v1, #0x0
    1234:	ldp	q5, q10, [x12, #-0x60]
    1238:	bit.16b	v10, v9, v0
    123c:	bit.16b	v5, v31, v1
    1240:	stp	q5, q10, [x12, #-0x60]
    1244:	add	x15, x13, #0x8
    1248:	dup.2d	v12, x15
    124c:	ldr	q5, [sp, #0x1f0]
    1250:	orr.16b	v5, v12, v5
    1254:	and.16b	v4, v4, v5
    1258:	add.2d	v4, v4, v19
    125c:	shl.2d	v4, v4, #0x2
    1260:	add.2d	v4, v16, v4
    1264:	movi.2d	v10, #0000000000000000
    1268:	movi.2d	v11, #0000000000000000
    126c:	tbz	w14, #0x0, 0x1278
    1270:	fmov	x15, d4
    1274:	ldr	s10, [x15]
    1278:	and	w14, w14, #0xff
    127c:	tbz	w14, #0x1, 0x1288
    1280:	mov.d	x15, v4[1]
    1284:	ld1.s	{ v10 }[1], [x15]
    1288:	ldr	q4, [sp, #0x200]
    128c:	orr.16b	v4, v12, v4
    1290:	and.16b	v4, v17, v4
    1294:	add.2d	v4, v4, v29
    1298:	shl.2d	v4, v4, #0x2
    129c:	add.2d	v4, v16, v4
    12a0:	tbz	w14, #0x2, 0x12ac
    12a4:	fmov	x15, d4
    12a8:	ld1.s	{ v10 }[2], [x15]
    12ac:	tbz	w14, #0x3, 0x12b8
    12b0:	mov.d	x15, v4[1]
    12b4:	ld1.s	{ v10 }[3], [x15]
    12b8:	sshll.2d	v4, v0, #0x0
    12bc:	ldr	q5, [sp, #0x210]
    12c0:	orr.16b	v5, v12, v5
    12c4:	and.16b	v4, v4, v5
    12c8:	add.2d	v4, v4, v30
    12cc:	shl.2d	v4, v4, #0x2
    12d0:	add.2d	v4, v16, v4
    12d4:	tbz	w14, #0x4, 0x12e0
    12d8:	fmov	x15, d4
    12dc:	ld1.s	{ v11 }[0], [x15]
    12e0:	tbz	w14, #0x5, 0x12ec
    12e4:	mov.d	x15, v4[1]
    12e8:	ld1.s	{ v11 }[1], [x15]
    12ec:	ldr	q4, [sp, #0x220]
    12f0:	orr.16b	v4, v12, v4
    12f4:	and.16b	v4, v18, v4
    12f8:	add.2d	v4, v4, v28
    12fc:	shl.2d	v4, v4, #0x2
    1300:	add.2d	v4, v16, v4
    1304:	tbz	w14, #0x6, 0x1310
    1308:	fmov	x15, d4
    130c:	ld1.s	{ v11 }[2], [x15]
    1310:	tbz	w14, #0x7, 0x131c
    1314:	mov.d	x14, v4[1]
    1318:	ld1.s	{ v11 }[3], [x14]
    131c:	fmov	w14, s2
    1320:	sshll.2d	v4, v1, #0x0
    1324:	ldp	q5, q12, [x12, #-0x40]
    1328:	bit.16b	v12, v11, v0
    132c:	bit.16b	v5, v10, v1
    1330:	stp	q5, q12, [x12, #-0x40]
    1334:	add	x15, x13, #0x10
    1338:	dup.2d	v14, x15
    133c:	ldr	q5, [sp, #0x1f0]
    1340:	orr.16b	v5, v14, v5
    1344:	and.16b	v4, v4, v5
    1348:	add.2d	v4, v4, v19
    134c:	shl.2d	v4, v4, #0x2
    1350:	add.2d	v4, v16, v4
    1354:	movi.2d	v12, #0000000000000000
    1358:	movi.2d	v13, #0000000000000000
    135c:	tbz	w14, #0x0, 0x1368
    1360:	fmov	x15, d4
    1364:	ldr	s12, [x15]
    1368:	and	w14, w14, #0xff
    136c:	tbz	w14, #0x1, 0x1378
    1370:	mov.d	x15, v4[1]
    1374:	ld1.s	{ v12 }[1], [x15]
    1378:	ldr	q4, [sp, #0x200]
    137c:	orr.16b	v4, v14, v4
    1380:	and.16b	v4, v17, v4
    1384:	add.2d	v4, v4, v29
    1388:	shl.2d	v4, v4, #0x2
    138c:	add.2d	v4, v16, v4
    1390:	tbz	w14, #0x2, 0x139c
    1394:	fmov	x15, d4
    1398:	ld1.s	{ v12 }[2], [x15]
    139c:	tbz	w14, #0x3, 0x13a8
    13a0:	mov.d	x15, v4[1]
    13a4:	ld1.s	{ v12 }[3], [x15]
    13a8:	sshll.2d	v4, v0, #0x0
    13ac:	ldr	q5, [sp, #0x210]
    13b0:	orr.16b	v5, v14, v5
    13b4:	and.16b	v4, v4, v5
    13b8:	add.2d	v4, v4, v30
    13bc:	shl.2d	v4, v4, #0x2
    13c0:	add.2d	v4, v16, v4
    13c4:	tbz	w14, #0x4, 0x13d0
    13c8:	fmov	x15, d4
    13cc:	ld1.s	{ v13 }[0], [x15]
    13d0:	tbz	w14, #0x5, 0x13dc
    13d4:	mov.d	x15, v4[1]
    13d8:	ld1.s	{ v13 }[1], [x15]
    13dc:	ldr	q4, [sp, #0x220]
    13e0:	orr.16b	v4, v14, v4
    13e4:	and.16b	v4, v18, v4
    13e8:	add.2d	v4, v4, v28
    13ec:	shl.2d	v4, v4, #0x2
    13f0:	add.2d	v4, v16, v4
    13f4:	tbz	w14, #0x6, 0x1400
    13f8:	fmov	x15, d4
    13fc:	ld1.s	{ v13 }[2], [x15]
    1400:	tbz	w14, #0x7, 0x140c
    1404:	mov.d	x14, v4[1]
    1408:	ld1.s	{ v13 }[3], [x14]
    140c:	fmov	w14, s2
    1410:	sshll.2d	v5, v1, #0x0
    1414:	ldp	q4, q14, [x12, #-0x20]
    1418:	bit.16b	v14, v13, v0
    141c:	bit.16b	v4, v12, v1
    1420:	stp	q4, q14, [x12, #-0x20]
    1424:	add	x15, x13, #0x18
    1428:	dup.2d	v4, x15
    142c:	ldr	q6, [sp, #0x1f0]
    1430:	orr.16b	v14, v4, v6
    1434:	and.16b	v5, v5, v14
    1438:	add.2d	v5, v5, v19
    143c:	shl.2d	v5, v5, #0x2
    1440:	add.2d	v5, v16, v5
    1444:	movi.2d	v14, #0000000000000000
    1448:	movi.2d	v15, #0000000000000000
    144c:	tbz	w14, #0x0, 0x1458
    1450:	fmov	x15, d5
    1454:	ldr	s14, [x15]
    1458:	and	w14, w14, #0xff
    145c:	tbz	w14, #0x1, 0x1468
    1460:	mov.d	x15, v5[1]
    1464:	ld1.s	{ v14 }[1], [x15]
    1468:	ldr	q5, [sp, #0x200]
    146c:	orr.16b	v5, v4, v5
    1470:	and.16b	v5, v17, v5
    1474:	add.2d	v5, v5, v29
    1478:	shl.2d	v5, v5, #0x2
    147c:	add.2d	v5, v16, v5
    1480:	tbz	w14, #0x2, 0x148c
    1484:	fmov	x15, d5
    1488:	ld1.s	{ v14 }[2], [x15]
    148c:	tbz	w14, #0x3, 0x1498
    1490:	mov.d	x15, v5[1]
    1494:	ld1.s	{ v14 }[3], [x15]
    1498:	sshll.2d	v5, v0, #0x0
    149c:	ldr	q6, [sp, #0x210]
    14a0:	orr.16b	v6, v4, v6
    14a4:	and.16b	v5, v5, v6
    14a8:	add.2d	v5, v5, v30
    14ac:	shl.2d	v5, v5, #0x2
    14b0:	add.2d	v5, v16, v5
    14b4:	tbz	w14, #0x4, 0x14c0
    14b8:	fmov	x15, d5
    14bc:	ld1.s	{ v15 }[0], [x15]
    14c0:	tbz	w14, #0x5, 0x14cc
    14c4:	mov.d	x15, v5[1]
    14c8:	ld1.s	{ v15 }[1], [x15]
    14cc:	ldr	q5, [sp, #0x220]
    14d0:	orr.16b	v4, v4, v5
    14d4:	and.16b	v4, v18, v4
    14d8:	add.2d	v4, v4, v28
    14dc:	shl.2d	v4, v4, #0x2
    14e0:	add.2d	v4, v16, v4
    14e4:	tbz	w14, #0x6, 0x14f0
    14e8:	fmov	x15, d4
    14ec:	ld1.s	{ v15 }[2], [x15]
    14f0:	tbz	w14, #0x7, 0x10d0
    14f4:	mov.d	x14, v4[1]
    14f8:	ld1.s	{ v15 }[3], [x14]
    14fc:	b	0x10d0
    1500:	mov	x11, #0x0
    1504:	b	0x1528
    1508:	add	x12, x19, x11
    150c:	ldp	q4, q5, [x12]
    1510:	bit.16b	v5, v17, v0
    1514:	bit.16b	v4, v16, v1
    1518:	stp	q4, q5, [x12]
    151c:	add	x11, x11, #0x20
    1520:	cmp	x11, #0x4, lsl #12
    1524:	b.eq	0x15c0
    1528:	fmov	w13, s2
    152c:	add	x12, x9, x11
    1530:	movi.2d	v16, #0000000000000000
    1534:	movi.2d	v17, #0000000000000000
    1538:	tbnz	w13, #0x0, 0x1560
    153c:	and	w13, w13, #0xff
    1540:	tbnz	w13, #0x1, 0x156c
    1544:	tbnz	w13, #0x2, 0x1578
    1548:	tbnz	w13, #0x3, 0x1584
    154c:	tbnz	w13, #0x4, 0x1590
    1550:	tbnz	w13, #0x5, 0x159c
    1554:	tbnz	w13, #0x6, 0x15a8
    1558:	tbz	w13, #0x7, 0x1508
    155c:	b	0x15b4
    1560:	ldr	s16, [x12]
    1564:	and	w13, w13, #0xff
    1568:	tbz	w13, #0x1, 0x1544
    156c:	add	x14, x12, #0x4
    1570:	ld1.s	{ v16 }[1], [x14]
    1574:	tbz	w13, #0x2, 0x1548
    1578:	add	x14, x12, #0x8
    157c:	ld1.s	{ v16 }[2], [x14]
    1580:	tbz	w13, #0x3, 0x154c
    1584:	add	x14, x12, #0xc
    1588:	ld1.s	{ v16 }[3], [x14]
    158c:	tbz	w13, #0x4, 0x1550
    1590:	add	x14, x12, #0x10
    1594:	ld1.s	{ v17 }[0], [x14]
    1598:	tbz	w13, #0x5, 0x1554
    159c:	add	x14, x12, #0x14
    15a0:	ld1.s	{ v17 }[1], [x14]
    15a4:	tbz	w13, #0x6, 0x1558
    15a8:	add	x14, x12, #0x18
    15ac:	ld1.s	{ v17 }[2], [x14]
    15b0:	tbz	w13, #0x7, 0x1508
    15b4:	add	x12, x12, #0x1c
    15b8:	ld1.s	{ v17 }[3], [x12]
    15bc:	b	0x1508
    15c0:	mov	x9, #0x0
    15c4:	xtn.8b	v18, v3
    15c8:	fadd.4s	v3, v21, v25
    15cc:	fadd.4s	v4, v20, v24
    15d0:	fadd.4s	v4, v4, v26
    15d4:	fadd.4s	v3, v3, v22
    15d8:	fadd.4s	v16, v3, v23
    15dc:	fadd.4s	v17, v4, v27
    15e0:	ldp	q4, q3, [sp, #0x1d0]
    15e4:	uzp1.4s	v4, v3, v4
    15e8:	ldr	q3, [sp, #0x1c0]
    15ec:	uzp1.4s	v3, v3, v7
    15f0:	movi.4s	v6, #0x1
    15f4:	eor.16b	v5, v4, v6
    15f8:	mov.s	w12, v5[1]
    15fc:	mov.s	w14, v5[2]
    1600:	mov.s	w15, v5[3]
    1604:	fmov	w11, s5
    1608:	add	x13, sp, #0x238
    160c:	bfxil	x13, x11, #0, #3
    1610:	str	d18, [sp, #0x238]
    1614:	ldrb	w16, [x13]
    1618:	and	x13, x11, #0x7
    161c:	umov.b	w11, v18[0]
    1620:	stp	q17, q16, [x24, #0x40]
    1624:	add	x17, sp, #0x300
    1628:	ldr	s5, [x17, x13, lsl #2]
    162c:	eor.16b	v20, v3, v6
    1630:	ands	w13, w11, #0x1
    1634:	tst	w13, w16
    1638:	fcsel	s5, s5, s8, ne
    163c:	add	x16, sp, #0x238
    1640:	bfxil	x16, x12, #0, #3
    1644:	ldrb	w16, [x16]
    1648:	and	x17, x12, #0x7
    164c:	umov.b	w12, v18[1]
    1650:	stp	q17, q16, [x24, #0x20]
    1654:	add	x0, sp, #0x2e0
    1658:	ldr	s6, [x0, x17, lsl #2]
    165c:	ands	w17, w12, #0x1
    1660:	tst	w17, w16
    1664:	fcsel	s6, s6, s8, ne
    1668:	add	x16, sp, #0x238
    166c:	bfxil	x16, x14, #0, #3
    1670:	ldrb	w16, [x16]
    1674:	and	x17, x14, #0x7
    1678:	umov.b	w14, v18[2]
    167c:	stp	q17, q16, [x24]
    1680:	ldr	s7, [x24, x17, lsl #2]
    1684:	ands	w17, w14, #0x1
    1688:	tst	w17, w16
    168c:	fcsel	s7, s7, s8, ne
    1690:	add	x16, sp, #0x238
    1694:	bfxil	x16, x15, #0, #3
    1698:	ldrb	w16, [x16]
    169c:	and	x17, x15, #0x7
    16a0:	umov.b	w15, v18[3]
    16a4:	stp	q17, q16, [sp, #0x2a0]
    16a8:	add	x0, sp, #0x2a0
    16ac:	ldr	s21, [x0, x17, lsl #2]
    16b0:	ands	w17, w15, #0x1
    16b4:	tst	w17, w16
    16b8:	mov.s	w17, v20[1]
    16bc:	mov.s	w0, v20[2]
    16c0:	mov.s	w1, v20[3]
    16c4:	fcsel	s21, s21, s8, ne
    16c8:	fmov	w16, s20
    16cc:	and	x2, x16, #0x7
    16d0:	add	x3, sp, #0x238
    16d4:	bfxil	x3, x16, #0, #3
    16d8:	ldrb	w3, [x3]
    16dc:	umov.b	w16, v18[4]
    16e0:	stp	q17, q16, [x24, #0xc0]
    16e4:	add	x4, sp, #0x380
    16e8:	ldr	s20, [x4, x2, lsl #2]
    16ec:	and	w2, w16, w3
    16f0:	tst	w2, #0x1
    16f4:	add	x2, sp, #0x238
    16f8:	bfxil	x2, x17, #0, #3
    16fc:	ldrb	w2, [x2]
    1700:	and	x3, x17, #0x7
    1704:	umov.b	w17, v18[5]
    1708:	stp	q17, q16, [x24, #0xa0]
    170c:	add	x4, sp, #0x360
    1710:	ldr	s22, [x4, x3, lsl #2]
    1714:	fcsel	s20, s20, s8, ne
    1718:	ands	w3, w17, #0x1
    171c:	tst	w3, w2
    1720:	fcsel	s22, s22, s8, ne
    1724:	add	x2, sp, #0x238
    1728:	bfxil	x2, x0, #0, #3
    172c:	ldrb	w2, [x2]
    1730:	and	x3, x0, #0x7
    1734:	umov.b	w0, v18[6]
    1738:	stp	q17, q16, [x24, #0x80]
    173c:	add	x4, sp, #0x340
    1740:	ldr	s23, [x4, x3, lsl #2]
    1744:	ands	w3, w0, #0x1
    1748:	tst	w3, w2
    174c:	fcsel	s23, s23, s8, ne
    1750:	add	x2, sp, #0x238
    1754:	bfxil	x2, x1, #0, #3
    1758:	ldrb	w2, [x2]
    175c:	and	x3, x1, #0x7
    1760:	umov.b	w1, v18[7]
    1764:	stp	q17, q16, [x24, #0x60]
    1768:	add	x4, sp, #0x320
    176c:	ldr	s18, [x4, x3, lsl #2]
    1770:	ands	w3, w1, #0x1
    1774:	tst	w3, w2
    1778:	fcsel	s18, s18, s8, ne
    177c:	mov.s	v5[1], v6[0]
    1780:	mov.s	v5[2], v7[0]
    1784:	mov.s	v5[3], v21[0]
    1788:	mov.s	v20[1], v22[0]
    178c:	mov.s	v20[2], v23[0]
    1790:	mov.s	v20[3], v18[0]
    1794:	fadd.4s	v6, v16, v20
    1798:	fadd.4s	v5, v17, v5
    179c:	movi.4s	v7, #0x2
    17a0:	eor.16b	v4, v4, v7
    17a4:	fmov	w2, s4
    17a8:	add	x3, sp, #0x238
    17ac:	bfxil	x3, x2, #0, #3
    17b0:	ldrb	w3, [x3]
    17b4:	and	x2, x2, #0x7
    17b8:	stp	q5, q6, [sp, #0x280]
    17bc:	add	x4, sp, #0x280
    17c0:	ldr	s4, [x4, x2, lsl #2]
    17c4:	eor.16b	v3, v3, v7
    17c8:	tst	w13, w3
    17cc:	fcsel	s4, s4, s8, ne
    17d0:	fmov	w2, s3
    17d4:	add	x3, sp, #0x238
    17d8:	bfxil	x3, x2, #0, #3
    17dc:	and	x2, x2, #0x7
    17e0:	ldrb	w3, [x3]
    17e4:	stp	q5, q6, [sp, #0x260]
    17e8:	add	x4, sp, #0x260
    17ec:	ldr	s3, [x4, x2, lsl #2]
    17f0:	and	w2, w16, w3
    17f4:	tst	w2, #0x1
    17f8:	fcsel	s3, s3, s8, ne
    17fc:	fadd.4s	v3, v6, v3
    1800:	tst	w13, w16
    1804:	fcsel	s3, s3, s8, ne
    1808:	ands	w11, w11, #0x1
    180c:	fadd.4s	v4, v5, v4
    1810:	fadd	s3, s4, s3
    1814:	fcsel	s4, s3, s8, ne
    1818:	tst	w12, #0x1
    181c:	fcsel	s5, s4, s8, ne
    1820:	tst	w14, #0x1
    1824:	fcsel	s6, s4, s8, ne
    1828:	tst	w15, #0x1
    182c:	fcsel	s7, s4, s8, ne
    1830:	tst	w11, w16
    1834:	fcsel	s3, s3, s8, ne
    1838:	tst	w17, #0x1
    183c:	fcsel	s16, s4, s8, ne
    1840:	tst	w0, #0x1
    1844:	fcsel	s17, s4, s8, ne
    1848:	tst	w1, #0x1
    184c:	fcsel	s18, s4, s8, ne
    1850:	mov.s	v4[1], v5[0]
    1854:	mov.s	v4[2], v6[0]
    1858:	mov.s	v4[3], v7[0]
    185c:	mov.s	v3[1], v16[0]
    1860:	mov.s	v3[2], v17[0]
    1864:	mov.s	v3[3], v18[0]
    1868:	rbit	w10, w10
    186c:	clz	w10, w10
    1870:	stp	q4, q3, [sp, #0x240]
    1874:	and	x10, x10, #0x7
    1878:	add	x11, sp, #0x240
    187c:	ldr	s3, [x11, x10, lsl #2]
    1880:	fadd	s3, s3, s8
    1884:	mov	w10, #0x39800000
    1888:	fmov	s4, w10
    188c:	fmul	s3, s3, s4
    1890:	mov	w10, #0xc5ac
    1894:	movk	w10, #0x3727, lsl #16
    1898:	fmov	s4, w10
    189c:	fadd	s3, s3, s4
    18a0:	fsqrt	s3, s3
    18a4:	dup.4s	v3, v3[0]
    18a8:	fmov	x10, d19
    18ac:	add	x8, x8, x10, lsl #2
    18b0:	b	0x18c0
    18b4:	add	x9, x9, #0x20
    18b8:	cmp	x9, #0x4, lsl #12
    18bc:	b.eq	0x168
    18c0:	fmov	w11, s2
    18c4:	add	x10, x27, x9
    18c8:	ldp	q5, q4, [x10]
    18cc:	and.16b	v5, v1, v5
    18d0:	fdiv.4s	v6, v5, v3
    18d4:	add	x10, x19, x9
    18d8:	ldp	q7, q5, [x10]
    18dc:	and.16b	v7, v1, v7
    18e0:	fmul.4s	v6, v6, v7
    18e4:	add	x10, x8, x9
    18e8:	tbnz	w11, #0x0, 0x1920
    18ec:	and	w11, w11, #0xff
    18f0:	tbnz	w11, #0x1, 0x192c
    18f4:	tbnz	w11, #0x2, 0x1938
    18f8:	tbnz	w11, #0x3, 0x1944
    18fc:	and.16b	v4, v0, v4
    1900:	fdiv.4s	v4, v4, v3
    1904:	and.16b	v5, v0, v5
    1908:	fmul.4s	v4, v4, v5
    190c:	tbnz	w11, #0x4, 0x1960
    1910:	tbnz	w11, #0x5, 0x1968
    1914:	tbnz	w11, #0x6, 0x1974
    1918:	tbz	w11, #0x7, 0x18b4
    191c:	b	0x1980
    1920:	str	s6, [x10]
    1924:	and	w11, w11, #0xff
    1928:	tbz	w11, #0x1, 0x18f4
    192c:	add	x12, x10, #0x4
    1930:	st1.s	{ v6 }[1], [x12]
    1934:	tbz	w11, #0x2, 0x18f8
    1938:	add	x12, x10, #0x8
    193c:	st1.s	{ v6 }[2], [x12]
    1940:	tbz	w11, #0x3, 0x18fc
    1944:	add	x12, x10, #0xc
    1948:	st1.s	{ v6 }[3], [x12]
    194c:	and.16b	v4, v0, v4
    1950:	fdiv.4s	v4, v4, v3
    1954:	and.16b	v5, v0, v5
    1958:	fmul.4s	v4, v4, v5
    195c:	tbz	w11, #0x4, 0x1910
    1960:	str	s4, [x10, #0x10]
    1964:	tbz	w11, #0x5, 0x1914
    1968:	add	x12, x10, #0x14
    196c:	st1.s	{ v4 }[1], [x12]
    1970:	tbz	w11, #0x6, 0x1918
    1974:	add	x12, x10, #0x18
    1978:	st1.s	{ v4 }[2], [x12]
    197c:	tbz	w11, #0x7, 0x18b4
    1980:	add	x10, x10, #0x1c
    1984:	st1.s	{ v4 }[3], [x10]
    1988:	b	0x18b4
    198c:	ldr	x9, [sp, #0x10]
    1990:	stp	w14, w13, [x9]
    1994:	str	w12, [x9, #0x8]
    1998:	mov	w8, #0x3f8
    199c:	str	w8, [x9, #0x24]
    19a0:	add	sp, sp, #0x8, lsl #12
    19a4:	add	sp, sp, #0x3b0
    19a8:	ldp	x29, x30, [sp, #0x90]
    19ac:	ldp	x20, x19, [sp, #0x80]
    19b0:	ldp	x22, x21, [sp, #0x70]
    19b4:	ldp	x24, x23, [sp, #0x60]
    19b8:	ldp	x26, x25, [sp, #0x50]
    19bc:	ldp	x28, x27, [sp, #0x40]
    19c0:	ldp	d9, d8, [sp, #0x30]
    19c4:	ldp	d11, d10, [sp, #0x20]
    19c8:	ldp	d13, d12, [sp, #0x10]
    19cc:	ldp	d15, d14, [sp], #0xa0
    19d0:	ret

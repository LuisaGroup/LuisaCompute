/tmp/luisa-full-packet.UEezjO/capture/rmsnorm-1024x4096-r0-l8-f1-p0/object/tile_xir_w8_63777_1788856230960163_0.o:
(__TEXT,__text) section
_llm_rows:
       0:	stp	d15, d14, [sp, #-0x50]!
       4:	stp	d13, d12, [sp, #0x10]
       8:	stp	d11, d10, [sp, #0x20]
       c:	stp	d9, d8, [sp, #0x30]
      10:	stp	x28, x27, [sp, #0x40]
      14:	sub	sp, sp, #0x8, lsl #12
      18:	sub	sp, sp, #0x200
      1c:	dup.4s	v1, w2
      20:	adrp	x8, lCPI0_1@PAGE
      24:	ldr	q2, [x8, lCPI0_1@PAGEOFF]
      28:	adrp	x8, lCPI0_2@PAGE
      2c:	ldr	q0, [x8, lCPI0_2@PAGEOFF]
      30:	cmhi.4s	v0, v1, v0
      34:	cmhi.4s	v1, v1, v2
      38:	uzp1.8h	v3, v1, v0
      3c:	umaxv.8h	h2, v3
      40:	fmov	w8, s2
      44:	tbz	w8, #0x0, 0xda4
      48:	ldr	x9, [x0]
      4c:	adrp	x8, lCPI0_0@PAGE
      50:	ldr	q2, [x8, lCPI0_0@PAGEOFF]
      54:	str	q3, [sp, #0x40]
      58:	and.16b	v2, v3, v2
      5c:	addv.8h	h12, v2
      60:	fmov	w10, s12
      64:	and	w8, w10, #0xff
      68:	sshll2.2d	v16, v1, #0x0
      6c:	sshll.2d	v23, v0, #0x0
      70:	sshll.2d	v24, v1, #0x0
      74:	ldr	w11, [x1]
      78:	ldr	w12, [x1, #0x24]
      7c:	add	w11, w12, w11, lsl #10
      80:	adrp	x12, lCPI0_3@PAGE
      84:	ldr	q2, [x12, lCPI0_3@PAGEOFF]
      88:	str	q2, [sp, #0x70]
      8c:	and.16b	v2, v24, v2
      90:	adrp	x12, lCPI0_4@PAGE
      94:	ldr	q18, [x12, lCPI0_4@PAGEOFF]
      98:	adrp	x12, lCPI0_5@PAGE
      9c:	ldr	q19, [x12, lCPI0_5@PAGEOFF]
      a0:	and.16b	v5, v16, v19
      a4:	lsr	w11, w11, #3
      a8:	dup.4s	v3, w11
      ac:	and.16b	v4, v1, v3
      b0:	and.16b	v3, v0, v3
      b4:	ushll.2d	v25, v4, #0xc
      b8:	ushll2.2d	v26, v4, #0xc
      bc:	stp	q5, q2, [sp, #0x20]
      c0:	orr.16b	v4, v26, v5
      c4:	orr.16b	v5, v25, v2
      c8:	shl.2d	v5, v5, #0x2
      cc:	dup.2d	v20, x9
      d0:	add.2d	v5, v20, v5
      d4:	movi.2d	v28, #0000000000000000
      d8:	movi.2d	v29, #0000000000000000
      dc:	tbnz	w10, #0x0, 0xdc4
      e0:	adrp	x9, lCPI0_6@PAGE
      e4:	and.16b	v2, v23, v18
      e8:	ushll.2d	v27, v3, #0xc
      ec:	shl.2d	v4, v4, #0x2
      f0:	tbnz	w8, #0x1, 0xde0
      f4:	sshll2.2d	v21, v0, #0x0
      f8:	ldr	q22, [x9, lCPI0_6@PAGEOFF]
      fc:	orr.16b	v5, v27, v2
     100:	add.2d	v4, v20, v4
     104:	tbnz	w8, #0x2, 0xdfc
     108:	and.16b	v6, v21, v22
     10c:	ushll2.2d	v30, v3, #0xc
     110:	shl.2d	v3, v5, #0x2
     114:	tbnz	w8, #0x3, 0xe14
     118:	orr.16b	v4, v30, v6
     11c:	add.2d	v3, v20, v3
     120:	tbnz	w8, #0x4, 0xe28
     124:	shl.2d	v4, v4, #0x2
     128:	tbnz	w8, #0x5, 0xe38
     12c:	add.2d	v3, v20, v4
     130:	tbnz	w8, #0x6, 0xe48
     134:	add	x9, sp, #0x110
     138:	stp	q6, q2, [sp]
     13c:	tbz	w8, #0x7, 0x148
     140:	mov.d	x8, v3[1]
     144:	ld1.s	{ v29 }[3], [x8]
     148:	ldr	x10, [x0, #0x10]
     14c:	ldr	x8, [x0, #0x30]
     150:	fmov	w12, s12
     154:	and	w11, w12, #0xff
     158:	sshll.2d	v3, v0, #0x0
     15c:	sshll.2d	v4, v1, #0x0
     160:	str	q28, [x9, #0x40f0]
     164:	str	q29, [x9, #0x4100]
     168:	adrp	x13, lCPI0_7@PAGE
     16c:	ldr	q5, [x13, lCPI0_7@PAGEOFF]
     170:	and.16b	v4, v4, v5
     174:	adrp	x13, lCPI0_8@PAGE
     178:	ldr	q5, [x13, lCPI0_8@PAGEOFF]
     17c:	adrp	x13, lCPI0_9@PAGE
     180:	ldr	q6, [x13, lCPI0_9@PAGEOFF]
     184:	and.16b	v6, v16, v6
     188:	orr.16b	v7, v26, v6
     18c:	orr.16b	v4, v25, v4
     190:	shl.2d	v4, v4, #0x2
     194:	add.2d	v6, v20, v4
     198:	movi.2d	v4, #0000000000000000
     19c:	movi.2d	v31, #0000000000000000
     1a0:	ldr	q2, [sp, #0x70]
     1a4:	tbnz	w12, #0x0, 0xe60
     1a8:	adrp	x12, lCPI0_10@PAGE
     1ac:	and.16b	v3, v3, v5
     1b0:	shl.2d	v7, v7, #0x2
     1b4:	tbnz	w11, #0x1, 0xe78
     1b8:	ldr	q5, [x12, lCPI0_10@PAGEOFF]
     1bc:	orr.16b	v6, v27, v3
     1c0:	add.2d	v3, v20, v7
     1c4:	tbnz	w11, #0x2, 0xe90
     1c8:	and.16b	v5, v21, v5
     1cc:	shl.2d	v6, v6, #0x2
     1d0:	tbnz	w11, #0x3, 0xea4
     1d4:	orr.16b	v5, v30, v5
     1d8:	add.2d	v3, v20, v6
     1dc:	tbnz	w11, #0x4, 0xeb8
     1e0:	shl.2d	v5, v5, #0x2
     1e4:	tbnz	w11, #0x5, 0xec8
     1e8:	add.2d	v3, v20, v5
     1ec:	tbnz	w11, #0x6, 0xed8
     1f0:	tbz	w11, #0x7, 0x1fc
     1f4:	mov.d	x11, v3[1]
     1f8:	ld1.s	{ v31 }[3], [x11]
     1fc:	fmov	w12, s12
     200:	and	w11, w12, #0xff
     204:	sshll.2d	v3, v0, #0x0
     208:	sshll.2d	v5, v1, #0x0
     20c:	str	q4, [x9, #0x4110]
     210:	str	q31, [x9, #0x4120]
     214:	adrp	x13, lCPI0_11@PAGE
     218:	ldr	q6, [x13, lCPI0_11@PAGEOFF]
     21c:	and.16b	v5, v5, v6
     220:	adrp	x13, lCPI0_12@PAGE
     224:	ldr	q7, [x13, lCPI0_12@PAGEOFF]
     228:	adrp	x13, lCPI0_13@PAGE
     22c:	ldr	q6, [x13, lCPI0_13@PAGEOFF]
     230:	and.16b	v6, v16, v6
     234:	orr.16b	v9, v26, v6
     238:	orr.16b	v5, v25, v5
     23c:	shl.2d	v5, v5, #0x2
     240:	add.2d	v8, v20, v5
     244:	movi.2d	v5, #0000000000000000
     248:	movi.2d	v6, #0000000000000000
     24c:	tbnz	w12, #0x0, 0xee8
     250:	adrp	x12, lCPI0_14@PAGE
     254:	and.16b	v3, v3, v7
     258:	shl.2d	v9, v9, #0x2
     25c:	tbnz	w11, #0x1, 0xf00
     260:	ldr	q7, [x12, lCPI0_14@PAGEOFF]
     264:	orr.16b	v8, v27, v3
     268:	add.2d	v3, v20, v9
     26c:	tbnz	w11, #0x2, 0xf18
     270:	and.16b	v7, v21, v7
     274:	shl.2d	v8, v8, #0x2
     278:	tbnz	w11, #0x3, 0xf2c
     27c:	orr.16b	v7, v30, v7
     280:	add.2d	v3, v20, v8
     284:	tbnz	w11, #0x4, 0xf40
     288:	shl.2d	v7, v7, #0x2
     28c:	tbnz	w11, #0x5, 0xf50
     290:	add.2d	v3, v20, v7
     294:	tbnz	w11, #0x6, 0xf60
     298:	tbz	w11, #0x7, 0x2a4
     29c:	mov.d	x11, v3[1]
     2a0:	ld1.s	{ v6 }[3], [x11]
     2a4:	fmov	w12, s12
     2a8:	and	w11, w12, #0xff
     2ac:	sshll.2d	v8, v0, #0x0
     2b0:	sshll.2d	v3, v1, #0x0
     2b4:	str	q5, [x9, #0x4130]
     2b8:	str	q6, [x9, #0x4140]
     2bc:	adrp	x13, lCPI0_15@PAGE
     2c0:	ldr	q7, [x13, lCPI0_15@PAGEOFF]
     2c4:	and.16b	v3, v3, v7
     2c8:	adrp	x13, lCPI0_16@PAGE
     2cc:	ldr	q9, [x13, lCPI0_16@PAGEOFF]
     2d0:	adrp	x13, lCPI0_17@PAGE
     2d4:	ldr	q7, [x13, lCPI0_17@PAGEOFF]
     2d8:	and.16b	v7, v16, v7
     2dc:	orr.16b	v11, v26, v7
     2e0:	orr.16b	v3, v25, v3
     2e4:	shl.2d	v3, v3, #0x2
     2e8:	add.2d	v10, v20, v3
     2ec:	movi.2d	v3, #0000000000000000
     2f0:	movi.2d	v7, #0000000000000000
     2f4:	tbnz	w12, #0x0, 0xf70
     2f8:	adrp	x12, lCPI0_18@PAGE
     2fc:	and.16b	v8, v8, v9
     300:	shl.2d	v11, v11, #0x2
     304:	tbnz	w11, #0x1, 0xf88
     308:	ldr	q9, [x12, lCPI0_18@PAGEOFF]
     30c:	orr.16b	v10, v27, v8
     310:	add.2d	v8, v20, v11
     314:	tbnz	w11, #0x2, 0xfa0
     318:	and.16b	v9, v21, v9
     31c:	shl.2d	v10, v10, #0x2
     320:	tbnz	w11, #0x3, 0xfb4
     324:	orr.16b	v9, v30, v9
     328:	add.2d	v8, v20, v10
     32c:	tbnz	w11, #0x4, 0xfc8
     330:	shl.2d	v9, v9, #0x2
     334:	tbnz	w11, #0x5, 0xfd8
     338:	add.2d	v8, v20, v9
     33c:	tbz	w11, #0x6, 0x348
     340:	fmov	x12, d8
     344:	ld1.s	{ v7 }[2], [x12]
     348:	fmov	w13, s12
     34c:	fmul.4s	v28, v28, v28
     350:	fmul.4s	v29, v29, v29
     354:	fmul.4s	v4, v4, v4
     358:	fmul.4s	v31, v31, v31
     35c:	fmul.4s	v5, v5, v5
     360:	fmul.4s	v6, v6, v6
     364:	tbz	w11, #0x7, 0x370
     368:	mov.d	x11, v8[1]
     36c:	ld1.s	{ v7 }[3], [x11]
     370:	mov	x12, #0x0
     374:	and.16b	v8, v21, v30
     378:	and.16b	v9, v16, v26
     37c:	and	w11, w13, #0xff
     380:	and.16b	v10, v23, v27
     384:	and.16b	v23, v24, v25
     388:	str	q3, [x9, #0x4150]
     38c:	str	q7, [x9, #0x4160]
     390:	fmul.4s	v3, v3, v3
     394:	fmul.4s	v7, v7, v7
     398:	and.16b	v25, v0, v29
     39c:	and.16b	v24, v1, v28
     3a0:	and.16b	v29, v0, v31
     3a4:	and.16b	v28, v1, v4
     3a8:	and.16b	v26, v0, v6
     3ac:	and.16b	v30, v1, v5
     3b0:	and.16b	v27, v0, v7
     3b4:	add	x13, sp, #0x4, lsl #12
     3b8:	add	x13, x13, #0x200
     3bc:	and.16b	v31, v1, v3
     3c0:	add	x13, x13, #0xe0
     3c4:	mov	w14, #0x20
     3c8:	fmov	w15, s12
     3cc:	sshll.2d	v4, v0, #0x0
     3d0:	sshll.2d	v3, v1, #0x0
     3d4:	stp	q3, q4, [sp, #0x50]
     3d8:	b	0x464
     3dc:	fmul.4s	v2, v14, v14
     3e0:	fmul.4s	v11, v13, v13
     3e4:	fadd.4s	v11, v24, v11
     3e8:	fadd.4s	v2, v25, v2
     3ec:	fmul.4s	v4, v4, v4
     3f0:	fmul.4s	v12, v15, v15
     3f4:	fadd.4s	v12, v28, v12
     3f8:	fadd.4s	v4, v29, v4
     3fc:	fmul.4s	v6, v6, v6
     400:	fmul.4s	v5, v5, v5
     404:	fadd.4s	v5, v30, v5
     408:	fadd.4s	v6, v26, v6
     40c:	ldp	q13, q14, [x13]
     410:	bit.16b	v14, v3, v0
     414:	bit.16b	v13, v7, v1
     418:	stp	q13, q14, [x13], #0x80
     41c:	fmul.4s	v7, v7, v7
     420:	fmul.4s	v3, v3, v3
     424:	fadd.4s	v3, v27, v3
     428:	fadd.4s	v7, v31, v7
     42c:	bit.16b	v25, v2, v0
     430:	bit.16b	v24, v11, v1
     434:	bit.16b	v29, v4, v0
     438:	bit.16b	v28, v12, v1
     43c:	bit.16b	v26, v6, v0
     440:	add	x12, x12, #0x4
     444:	bit.16b	v30, v5, v1
     448:	add	x14, x14, #0x20
     44c:	bit.16b	v31, v7, v1
     450:	bit.16b	v27, v3, v0
     454:	cmp	x12, #0x1fc
     458:	mov.16b	v12, v17
     45c:	ldr	q2, [sp, #0x70]
     460:	b.hs	0x904
     464:	dup.2d	v3, x14
     468:	orr.16b	v4, v3, v2
     46c:	ldr	q5, [sp, #0x50]
     470:	and.16b	v4, v5, v4
     474:	add.2d	v4, v4, v23
     478:	shl.2d	v4, v4, #0x2
     47c:	add.2d	v4, v20, v4
     480:	movi.2d	v13, #0000000000000000
     484:	movi.2d	v14, #0000000000000000
     488:	tbnz	w15, #0x0, 0x70c
     48c:	and	w16, w15, #0xff
     490:	tbnz	w16, #0x1, 0x71c
     494:	orr.16b	v4, v3, v19
     498:	and.16b	v4, v16, v4
     49c:	add.2d	v4, v4, v9
     4a0:	shl.2d	v4, v4, #0x2
     4a4:	add.2d	v4, v20, v4
     4a8:	tbnz	w16, #0x2, 0x73c
     4ac:	tbz	w16, #0x3, 0x4b8
     4b0:	mov.d	x17, v4[1]
     4b4:	ld1.s	{ v13 }[3], [x17]
     4b8:	orr.16b	v4, v3, v18
     4bc:	ldr	q5, [sp, #0x60]
     4c0:	and.16b	v4, v5, v4
     4c4:	add.2d	v4, v4, v10
     4c8:	shl.2d	v4, v4, #0x2
     4cc:	add.2d	v4, v20, v4
     4d0:	tbnz	w16, #0x4, 0x74c
     4d4:	tbnz	w16, #0x5, 0x758
     4d8:	orr.16b	v3, v3, v22
     4dc:	and.16b	v3, v21, v3
     4e0:	add.2d	v3, v3, v8
     4e4:	shl.2d	v3, v3, #0x2
     4e8:	add.2d	v3, v20, v3
     4ec:	tbnz	w16, #0x6, 0x778
     4f0:	tbz	w16, #0x7, 0x4fc
     4f4:	mov.d	x16, v3[1]
     4f8:	ld1.s	{ v14 }[3], [x16]
     4fc:	fmov	w16, s12
     500:	sshll.2d	v4, v1, #0x0
     504:	ldp	q3, q5, [x13, #-0x60]
     508:	bit.16b	v5, v14, v0
     50c:	bit.16b	v3, v13, v1
     510:	stp	q3, q5, [x13, #-0x60]
     514:	add	x17, x14, #0x8
     518:	dup.2d	v3, x17
     51c:	orr.16b	v5, v3, v2
     520:	and.16b	v4, v4, v5
     524:	add.2d	v4, v4, v23
     528:	shl.2d	v4, v4, #0x2
     52c:	add.2d	v5, v20, v4
     530:	movi.2d	v15, #0000000000000000
     534:	movi.2d	v4, #0000000000000000
     538:	tbnz	w16, #0x0, 0x788
     53c:	and	w16, w16, #0xff
     540:	tbnz	w16, #0x1, 0x798
     544:	orr.16b	v5, v3, v19
     548:	and.16b	v5, v16, v5
     54c:	add.2d	v5, v5, v9
     550:	shl.2d	v5, v5, #0x2
     554:	add.2d	v5, v20, v5
     558:	tbnz	w16, #0x2, 0x7b8
     55c:	tbz	w16, #0x3, 0x568
     560:	mov.d	x17, v5[1]
     564:	ld1.s	{ v15 }[3], [x17]
     568:	sshll.2d	v5, v0, #0x0
     56c:	orr.16b	v6, v3, v18
     570:	and.16b	v5, v5, v6
     574:	add.2d	v5, v5, v10
     578:	shl.2d	v5, v5, #0x2
     57c:	add.2d	v5, v20, v5
     580:	tbnz	w16, #0x4, 0x7c8
     584:	tbnz	w16, #0x5, 0x7d4
     588:	orr.16b	v3, v3, v22
     58c:	and.16b	v3, v21, v3
     590:	add.2d	v3, v3, v8
     594:	shl.2d	v3, v3, #0x2
     598:	add.2d	v3, v20, v3
     59c:	tbnz	w16, #0x6, 0x7f4
     5a0:	tbz	w16, #0x7, 0x5ac
     5a4:	mov.d	x16, v3[1]
     5a8:	ld1.s	{ v4 }[3], [x16]
     5ac:	fmov	w16, s12
     5b0:	sshll.2d	v5, v1, #0x0
     5b4:	ldp	q3, q6, [x13, #-0x40]
     5b8:	bit.16b	v6, v4, v0
     5bc:	bit.16b	v3, v15, v1
     5c0:	stp	q3, q6, [x13, #-0x40]
     5c4:	add	x17, x14, #0x10
     5c8:	dup.2d	v3, x17
     5cc:	orr.16b	v6, v3, v2
     5d0:	and.16b	v5, v5, v6
     5d4:	add.2d	v5, v5, v23
     5d8:	shl.2d	v5, v5, #0x2
     5dc:	add.2d	v7, v20, v5
     5e0:	movi.2d	v5, #0000000000000000
     5e4:	movi.2d	v6, #0000000000000000
     5e8:	tbnz	w16, #0x0, 0x804
     5ec:	and	w16, w16, #0xff
     5f0:	tbnz	w16, #0x1, 0x814
     5f4:	orr.16b	v7, v3, v19
     5f8:	and.16b	v7, v16, v7
     5fc:	add.2d	v7, v7, v9
     600:	shl.2d	v7, v7, #0x2
     604:	add.2d	v7, v20, v7
     608:	tbnz	w16, #0x2, 0x834
     60c:	tbz	w16, #0x3, 0x618
     610:	mov.d	x17, v7[1]
     614:	ld1.s	{ v5 }[3], [x17]
     618:	sshll.2d	v7, v0, #0x0
     61c:	orr.16b	v11, v3, v18
     620:	and.16b	v7, v7, v11
     624:	add.2d	v7, v7, v10
     628:	shl.2d	v7, v7, #0x2
     62c:	add.2d	v7, v20, v7
     630:	tbnz	w16, #0x4, 0x844
     634:	tbnz	w16, #0x5, 0x850
     638:	orr.16b	v3, v3, v22
     63c:	and.16b	v3, v21, v3
     640:	add.2d	v3, v3, v8
     644:	shl.2d	v3, v3, #0x2
     648:	add.2d	v3, v20, v3
     64c:	tbnz	w16, #0x6, 0x870
     650:	tbz	w16, #0x7, 0x65c
     654:	mov.d	x16, v3[1]
     658:	ld1.s	{ v6 }[3], [x16]
     65c:	mov.16b	v17, v12
     660:	fmov	w16, s12
     664:	sshll.2d	v3, v1, #0x0
     668:	ldp	q7, q11, [x13, #-0x20]
     66c:	bit.16b	v11, v6, v0
     670:	bit.16b	v7, v5, v1
     674:	stp	q7, q11, [x13, #-0x20]
     678:	add	x17, x14, #0x18
     67c:	dup.2d	v11, x17
     680:	orr.16b	v7, v11, v2
     684:	and.16b	v3, v3, v7
     688:	add.2d	v3, v3, v23
     68c:	shl.2d	v3, v3, #0x2
     690:	add.2d	v12, v20, v3
     694:	movi.2d	v7, #0000000000000000
     698:	movi.2d	v3, #0000000000000000
     69c:	tbnz	w16, #0x0, 0x880
     6a0:	and	w16, w16, #0xff
     6a4:	tbnz	w16, #0x1, 0x890
     6a8:	orr.16b	v12, v11, v19
     6ac:	and.16b	v12, v16, v12
     6b0:	add.2d	v12, v12, v9
     6b4:	shl.2d	v12, v12, #0x2
     6b8:	add.2d	v12, v20, v12
     6bc:	tbnz	w16, #0x2, 0x8b0
     6c0:	tbz	w16, #0x3, 0x6cc
     6c4:	mov.d	x17, v12[1]
     6c8:	ld1.s	{ v7 }[3], [x17]
     6cc:	sshll.2d	v12, v0, #0x0
     6d0:	orr.16b	v2, v11, v18
     6d4:	and.16b	v2, v12, v2
     6d8:	add.2d	v2, v2, v10
     6dc:	shl.2d	v2, v2, #0x2
     6e0:	add.2d	v12, v20, v2
     6e4:	tbnz	w16, #0x4, 0x8c0
     6e8:	tbnz	w16, #0x5, 0x8cc
     6ec:	orr.16b	v2, v11, v22
     6f0:	and.16b	v2, v21, v2
     6f4:	add.2d	v2, v2, v8
     6f8:	shl.2d	v2, v2, #0x2
     6fc:	add.2d	v11, v20, v2
     700:	tbnz	w16, #0x6, 0x8ec
     704:	tbz	w16, #0x7, 0x3dc
     708:	b	0x8f8
     70c:	fmov	x16, d4
     710:	ldr	s13, [x16]
     714:	and	w16, w15, #0xff
     718:	tbz	w16, #0x1, 0x494
     71c:	mov.d	x17, v4[1]
     720:	ld1.s	{ v13 }[1], [x17]
     724:	orr.16b	v4, v3, v19
     728:	and.16b	v4, v16, v4
     72c:	add.2d	v4, v4, v9
     730:	shl.2d	v4, v4, #0x2
     734:	add.2d	v4, v20, v4
     738:	tbz	w16, #0x2, 0x4ac
     73c:	fmov	x17, d4
     740:	ld1.s	{ v13 }[2], [x17]
     744:	tbnz	w16, #0x3, 0x4b0
     748:	b	0x4b8
     74c:	fmov	x17, d4
     750:	ld1.s	{ v14 }[0], [x17]
     754:	tbz	w16, #0x5, 0x4d8
     758:	mov.d	x17, v4[1]
     75c:	ld1.s	{ v14 }[1], [x17]
     760:	orr.16b	v3, v3, v22
     764:	and.16b	v3, v21, v3
     768:	add.2d	v3, v3, v8
     76c:	shl.2d	v3, v3, #0x2
     770:	add.2d	v3, v20, v3
     774:	tbz	w16, #0x6, 0x4f0
     778:	fmov	x17, d3
     77c:	ld1.s	{ v14 }[2], [x17]
     780:	tbnz	w16, #0x7, 0x4f4
     784:	b	0x4fc
     788:	fmov	x17, d5
     78c:	ldr	s15, [x17]
     790:	and	w16, w16, #0xff
     794:	tbz	w16, #0x1, 0x544
     798:	mov.d	x17, v5[1]
     79c:	ld1.s	{ v15 }[1], [x17]
     7a0:	orr.16b	v5, v3, v19
     7a4:	and.16b	v5, v16, v5
     7a8:	add.2d	v5, v5, v9
     7ac:	shl.2d	v5, v5, #0x2
     7b0:	add.2d	v5, v20, v5
     7b4:	tbz	w16, #0x2, 0x55c
     7b8:	fmov	x17, d5
     7bc:	ld1.s	{ v15 }[2], [x17]
     7c0:	tbnz	w16, #0x3, 0x560
     7c4:	b	0x568
     7c8:	fmov	x17, d5
     7cc:	ld1.s	{ v4 }[0], [x17]
     7d0:	tbz	w16, #0x5, 0x588
     7d4:	mov.d	x17, v5[1]
     7d8:	ld1.s	{ v4 }[1], [x17]
     7dc:	orr.16b	v3, v3, v22
     7e0:	and.16b	v3, v21, v3
     7e4:	add.2d	v3, v3, v8
     7e8:	shl.2d	v3, v3, #0x2
     7ec:	add.2d	v3, v20, v3
     7f0:	tbz	w16, #0x6, 0x5a0
     7f4:	fmov	x17, d3
     7f8:	ld1.s	{ v4 }[2], [x17]
     7fc:	tbnz	w16, #0x7, 0x5a4
     800:	b	0x5ac
     804:	fmov	x17, d7
     808:	ldr	s5, [x17]
     80c:	and	w16, w16, #0xff
     810:	tbz	w16, #0x1, 0x5f4
     814:	mov.d	x17, v7[1]
     818:	ld1.s	{ v5 }[1], [x17]
     81c:	orr.16b	v7, v3, v19
     820:	and.16b	v7, v16, v7
     824:	add.2d	v7, v7, v9
     828:	shl.2d	v7, v7, #0x2
     82c:	add.2d	v7, v20, v7
     830:	tbz	w16, #0x2, 0x60c
     834:	fmov	x17, d7
     838:	ld1.s	{ v5 }[2], [x17]
     83c:	tbnz	w16, #0x3, 0x610
     840:	b	0x618
     844:	fmov	x17, d7
     848:	ld1.s	{ v6 }[0], [x17]
     84c:	tbz	w16, #0x5, 0x638
     850:	mov.d	x17, v7[1]
     854:	ld1.s	{ v6 }[1], [x17]
     858:	orr.16b	v3, v3, v22
     85c:	and.16b	v3, v21, v3
     860:	add.2d	v3, v3, v8
     864:	shl.2d	v3, v3, #0x2
     868:	add.2d	v3, v20, v3
     86c:	tbz	w16, #0x6, 0x650
     870:	fmov	x17, d3
     874:	ld1.s	{ v6 }[2], [x17]
     878:	tbnz	w16, #0x7, 0x654
     87c:	b	0x65c
     880:	fmov	x17, d12
     884:	ldr	s7, [x17]
     888:	and	w16, w16, #0xff
     88c:	tbz	w16, #0x1, 0x6a8
     890:	mov.d	x17, v12[1]
     894:	ld1.s	{ v7 }[1], [x17]
     898:	orr.16b	v12, v11, v19
     89c:	and.16b	v12, v16, v12
     8a0:	add.2d	v12, v12, v9
     8a4:	shl.2d	v12, v12, #0x2
     8a8:	add.2d	v12, v20, v12
     8ac:	tbz	w16, #0x2, 0x6c0
     8b0:	fmov	x17, d12
     8b4:	ld1.s	{ v7 }[2], [x17]
     8b8:	tbnz	w16, #0x3, 0x6c4
     8bc:	b	0x6cc
     8c0:	fmov	x17, d12
     8c4:	ld1.s	{ v3 }[0], [x17]
     8c8:	tbz	w16, #0x5, 0x6ec
     8cc:	mov.d	x17, v12[1]
     8d0:	ld1.s	{ v3 }[1], [x17]
     8d4:	orr.16b	v2, v11, v22
     8d8:	and.16b	v2, v21, v2
     8dc:	add.2d	v2, v2, v8
     8e0:	shl.2d	v2, v2, #0x2
     8e4:	add.2d	v11, v20, v2
     8e8:	tbz	w16, #0x6, 0x704
     8ec:	fmov	x17, d11
     8f0:	ld1.s	{ v3 }[2], [x17]
     8f4:	tbz	w16, #0x7, 0x3dc
     8f8:	mov.d	x16, v11[1]
     8fc:	ld1.s	{ v3 }[3], [x16]
     900:	b	0x3dc
     904:	mov	x12, #0x0
     908:	fmov	w13, s12
     90c:	add	x14, sp, #0x200
     910:	b	0x934
     914:	add	x15, x14, x12
     918:	ldp	q2, q5, [x15]
     91c:	bif.16b	v4, v5, v0
     920:	bit.16b	v2, v3, v1
     924:	stp	q2, q4, [x15]
     928:	add	x12, x12, #0x20
     92c:	cmp	x12, #0x4, lsl #12
     930:	b.eq	0x9c8
     934:	add	x15, x10, x12
     938:	movi.2d	v3, #0000000000000000
     93c:	movi.2d	v4, #0000000000000000
     940:	tbnz	w13, #0x0, 0x968
     944:	and	w16, w13, #0xff
     948:	tbnz	w16, #0x1, 0x974
     94c:	tbnz	w16, #0x2, 0x980
     950:	tbnz	w16, #0x3, 0x98c
     954:	tbnz	w16, #0x4, 0x998
     958:	tbnz	w16, #0x5, 0x9a4
     95c:	tbnz	w16, #0x6, 0x9b0
     960:	tbz	w16, #0x7, 0x914
     964:	b	0x9bc
     968:	ldr	s3, [x15]
     96c:	and	w16, w13, #0xff
     970:	tbz	w16, #0x1, 0x94c
     974:	add	x17, x15, #0x4
     978:	ld1.s	{ v3 }[1], [x17]
     97c:	tbz	w16, #0x2, 0x950
     980:	add	x17, x15, #0x8
     984:	ld1.s	{ v3 }[2], [x17]
     988:	tbz	w16, #0x3, 0x954
     98c:	add	x17, x15, #0xc
     990:	ld1.s	{ v3 }[3], [x17]
     994:	tbz	w16, #0x4, 0x958
     998:	add	x17, x15, #0x10
     99c:	ld1.s	{ v4 }[0], [x17]
     9a0:	tbz	w16, #0x5, 0x95c
     9a4:	add	x17, x15, #0x14
     9a8:	ld1.s	{ v4 }[1], [x17]
     9ac:	tbz	w16, #0x6, 0x960
     9b0:	add	x17, x15, #0x18
     9b4:	ld1.s	{ v4 }[2], [x17]
     9b8:	tbz	w16, #0x7, 0x914
     9bc:	add	x15, x15, #0x1c
     9c0:	ld1.s	{ v4 }[3], [x15]
     9c4:	b	0x914
     9c8:	mov	x10, #0x0
     9cc:	ldr	q2, [sp, #0x40]
     9d0:	xtn.8b	v17, v2
     9d4:	fadd.4s	v2, v25, v29
     9d8:	fadd.4s	v3, v24, v28
     9dc:	fadd.4s	v3, v3, v30
     9e0:	fadd.4s	v2, v2, v26
     9e4:	fadd.4s	v6, v2, v27
     9e8:	fadd.4s	v16, v3, v31
     9ec:	ldp	q3, q2, [sp, #0x20]
     9f0:	uzp1.4s	v5, v2, v3
     9f4:	ldp	q3, q2, [sp]
     9f8:	uzp1.4s	v4, v2, v3
     9fc:	movi.4s	v2, #0x1
     a00:	eor.16b	v18, v4, v2
     a04:	eor.16b	v2, v5, v2
     a08:	mov.s	w15, v2[1]
     a0c:	mov.s	w16, v2[2]
     a10:	mov.s	w17, v2[3]
     a14:	fmov	w12, s2
     a18:	add	x13, sp, #0x88
     a1c:	bfxil	x13, x12, #0, #3
     a20:	str	d17, [sp, #0x88]
     a24:	ldrb	w13, [x13]
     a28:	and	x14, x12, #0x7
     a2c:	umov.b	w12, v17[0]
     a30:	stp	q16, q6, [x9, #0x40]
     a34:	add	x0, sp, #0x150
     a38:	ldr	s2, [x0, x14, lsl #2]
     a3c:	ands	w14, w12, #0x1
     a40:	tst	w14, w13
     a44:	movi	d3, #0000000000000000
     a48:	fcsel	s7, s2, s3, ne
     a4c:	add	x13, sp, #0x88
     a50:	bfxil	x13, x15, #0, #3
     a54:	ldrb	w0, [x13]
     a58:	umov.b	w13, v17[1]
     a5c:	and	x15, x15, #0x7
     a60:	stp	q16, q6, [x9, #0x20]
     a64:	add	x1, sp, #0x130
     a68:	ldr	s2, [x1, x15, lsl #2]
     a6c:	ands	w15, w13, #0x1
     a70:	tst	w15, w0
     a74:	fcsel	s19, s2, s3, ne
     a78:	add	x15, sp, #0x88
     a7c:	bfxil	x15, x16, #0, #3
     a80:	ldrb	w0, [x15]
     a84:	and	x16, x16, #0x7
     a88:	umov.b	w15, v17[2]
     a8c:	stp	q16, q6, [x9]
     a90:	add	x1, sp, #0x110
     a94:	ldr	s2, [x1, x16, lsl #2]
     a98:	ands	w16, w15, #0x1
     a9c:	tst	w16, w0
     aa0:	fcsel	s20, s2, s3, ne
     aa4:	add	x16, sp, #0x88
     aa8:	bfxil	x16, x17, #0, #3
     aac:	ldrb	w0, [x16]
     ab0:	and	x17, x17, #0x7
     ab4:	umov.b	w16, v17[3]
     ab8:	stp	q16, q6, [sp, #0xf0]
     abc:	add	x1, sp, #0xf0
     ac0:	ldr	s2, [x1, x17, lsl #2]
     ac4:	ands	w17, w16, #0x1
     ac8:	tst	w17, w0
     acc:	mov.s	w0, v18[1]
     ad0:	mov.s	w1, v18[2]
     ad4:	mov.s	w3, v18[3]
     ad8:	fmov	w17, s18
     adc:	and	x2, x17, #0x7
     ae0:	add	x4, sp, #0x88
     ae4:	bfxil	x4, x17, #0, #3
     ae8:	ldrb	w4, [x4]
     aec:	stp	q16, q6, [x9, #0xc0]
     af0:	add	x17, sp, #0x1d0
     af4:	ldr	s18, [x17, x2, lsl #2]
     af8:	umov.b	w17, v17[4]
     afc:	fcsel	s2, s2, s3, ne
     b00:	and	w2, w17, w4
     b04:	tst	w2, #0x1
     b08:	add	x2, sp, #0x88
     b0c:	bfxil	x2, x0, #0, #3
     b10:	ldrb	w2, [x2]
     b14:	and	x0, x0, #0x7
     b18:	stp	q16, q6, [x9, #0xa0]
     b1c:	add	x4, sp, #0x1b0
     b20:	ldr	s21, [x4, x0, lsl #2]
     b24:	fcsel	s18, s18, s3, ne
     b28:	umov.b	w0, v17[5]
     b2c:	ands	w4, w0, #0x1
     b30:	tst	w4, w2
     b34:	fcsel	s21, s21, s3, ne
     b38:	add	x2, sp, #0x88
     b3c:	bfxil	x2, x1, #0, #3
     b40:	ldrb	w2, [x2]
     b44:	and	x1, x1, #0x7
     b48:	stp	q16, q6, [x9, #0x80]
     b4c:	add	x4, sp, #0x190
     b50:	ldr	s22, [x4, x1, lsl #2]
     b54:	umov.b	w1, v17[6]
     b58:	ands	w4, w1, #0x1
     b5c:	tst	w4, w2
     b60:	add	x2, sp, #0x88
     b64:	bfxil	x2, x3, #0, #3
     b68:	ldrb	w4, [x2]
     b6c:	umov.b	w2, v17[7]
     b70:	and	x3, x3, #0x7
     b74:	stp	q16, q6, [x9, #0x60]
     b78:	add	x9, sp, #0x170
     b7c:	ldr	s17, [x9, x3, lsl #2]
     b80:	fcsel	s22, s22, s3, ne
     b84:	ands	w9, w2, #0x1
     b88:	tst	w9, w4
     b8c:	fcsel	s17, s17, s3, ne
     b90:	mov.s	v7[1], v19[0]
     b94:	mov.s	v7[2], v20[0]
     b98:	mov.s	v7[3], v2[0]
     b9c:	mov.s	v18[1], v21[0]
     ba0:	mov.s	v18[2], v22[0]
     ba4:	mov.s	v18[3], v17[0]
     ba8:	fadd.4s	v2, v6, v18
     bac:	fadd.4s	v6, v16, v7
     bb0:	movi.4s	v7, #0x2
     bb4:	eor.16b	v5, v5, v7
     bb8:	fmov	w9, s5
     bbc:	add	x3, sp, #0x88
     bc0:	bfxil	x3, x9, #0, #3
     bc4:	ldrb	w3, [x3]
     bc8:	and	x9, x9, #0x7
     bcc:	stp	q6, q2, [sp, #0xd0]
     bd0:	add	x4, sp, #0xd0
     bd4:	ldr	s5, [x4, x9, lsl #2]
     bd8:	add	x9, sp, #0x88
     bdc:	eor.16b	v4, v4, v7
     be0:	tst	w14, w3
     be4:	fcsel	s5, s5, s3, ne
     be8:	fmov	w3, s4
     bec:	and	x4, x3, #0x7
     bf0:	bfxil	x9, x3, #0, #3
     bf4:	ldrb	w9, [x9]
     bf8:	and	w9, w17, w9
     bfc:	stp	q6, q2, [sp, #0xb0]
     c00:	add	x3, sp, #0xb0
     c04:	ldr	s4, [x3, x4, lsl #2]
     c08:	tst	w9, #0x1
     c0c:	fcsel	s4, s4, s3, ne
     c10:	fadd.4s	v2, v2, v4
     c14:	tst	w14, w17
     c18:	fcsel	s2, s2, s3, ne
     c1c:	ands	w9, w12, #0x1
     c20:	fadd.4s	v4, v6, v5
     c24:	fadd	s2, s4, s2
     c28:	fcsel	s4, s2, s3, ne
     c2c:	tst	w13, #0x1
     c30:	fcsel	s5, s4, s3, ne
     c34:	tst	w15, #0x1
     c38:	fcsel	s6, s4, s3, ne
     c3c:	tst	w16, #0x1
     c40:	fcsel	s7, s4, s3, ne
     c44:	tst	w9, w17
     c48:	fcsel	s2, s2, s3, ne
     c4c:	tst	w0, #0x1
     c50:	fcsel	s16, s4, s3, ne
     c54:	tst	w1, #0x1
     c58:	fcsel	s17, s4, s3, ne
     c5c:	tst	w2, #0x1
     c60:	fcsel	s18, s4, s3, ne
     c64:	mov.s	v4[1], v5[0]
     c68:	mov.s	v4[2], v6[0]
     c6c:	mov.s	v4[3], v7[0]
     c70:	mov.s	v2[1], v16[0]
     c74:	mov.s	v2[2], v17[0]
     c78:	mov.s	v2[3], v18[0]
     c7c:	rbit	w9, w11
     c80:	clz	w9, w9
     c84:	stp	q4, q2, [sp, #0x90]
     c88:	and	x9, x9, #0x7
     c8c:	add	x11, sp, #0x90
     c90:	ldr	s2, [x11, x9, lsl #2]
     c94:	fadd	s2, s2, s3
     c98:	mov	w9, #0x39800000
     c9c:	fmov	s3, w9
     ca0:	fmul	s2, s2, s3
     ca4:	mov	w9, #0xc5ac
     ca8:	movk	w9, #0x3727, lsl #16
     cac:	fmov	s3, w9
     cb0:	fadd	s2, s2, s3
     cb4:	fsqrt	s2, s2
     cb8:	dup.4s	v3, v2[0]
     cbc:	fmov	x9, d23
     cc0:	add	x8, x8, x9, lsl #2
     cc4:	add	x9, sp, #0x4, lsl #12
     cc8:	add	x9, x9, #0x200
     ccc:	add	x11, sp, #0x200
     cd0:	b	0xce0
     cd4:	add	x10, x10, #0x20
     cd8:	cmp	x10, #0x4, lsl #12
     cdc:	b.eq	0xda4
     ce0:	fmov	w13, s12
     ce4:	add	x14, x9, x10
     ce8:	ldr	q2, [x14]
     cec:	and.16b	v2, v1, v2
     cf0:	fdiv.4s	v2, v2, v3
     cf4:	add	x15, x11, x10
     cf8:	ldr	q4, [x15]
     cfc:	and.16b	v4, v1, v4
     d00:	fmul.4s	v4, v2, v4
     d04:	add	x12, x8, x10
     d08:	tbnz	w13, #0x0, 0xd50
     d0c:	and	w13, w13, #0xff
     d10:	tbnz	w13, #0x1, 0xd5c
     d14:	tbnz	w13, #0x2, 0xd68
     d18:	tbz	w13, #0x3, 0xd24
     d1c:	add	x16, x12, #0xc
     d20:	st1.s	{ v4 }[3], [x16]
     d24:	ldr	q2, [x14, #0x10]
     d28:	and.16b	v2, v0, v2
     d2c:	fdiv.4s	v2, v2, v3
     d30:	ldr	q4, [x15, #0x10]
     d34:	and.16b	v4, v0, v4
     d38:	fmul.4s	v4, v2, v4
     d3c:	tbnz	w13, #0x4, 0xd78
     d40:	tbnz	w13, #0x5, 0xd80
     d44:	tbnz	w13, #0x6, 0xd8c
     d48:	tbz	w13, #0x7, 0xcd4
     d4c:	b	0xd98
     d50:	str	s4, [x12]
     d54:	and	w13, w13, #0xff
     d58:	tbz	w13, #0x1, 0xd14
     d5c:	add	x16, x12, #0x4
     d60:	st1.s	{ v4 }[1], [x16]
     d64:	tbz	w13, #0x2, 0xd18
     d68:	add	x16, x12, #0x8
     d6c:	st1.s	{ v4 }[2], [x16]
     d70:	tbnz	w13, #0x3, 0xd1c
     d74:	b	0xd24
     d78:	str	s4, [x12, #0x10]
     d7c:	tbz	w13, #0x5, 0xd44
     d80:	add	x14, x12, #0x14
     d84:	st1.s	{ v4 }[1], [x14]
     d88:	tbz	w13, #0x6, 0xd48
     d8c:	add	x14, x12, #0x18
     d90:	st1.s	{ v4 }[2], [x14]
     d94:	tbz	w13, #0x7, 0xcd4
     d98:	add	x12, x12, #0x1c
     d9c:	st1.s	{ v4 }[3], [x12]
     da0:	b	0xcd4
     da4:	add	sp, sp, #0x8, lsl #12
     da8:	add	sp, sp, #0x200
     dac:	ldp	x28, x27, [sp, #0x40]
     db0:	ldp	d9, d8, [sp, #0x30]
     db4:	ldp	d11, d10, [sp, #0x20]
     db8:	ldp	d13, d12, [sp, #0x10]
     dbc:	ldp	d15, d14, [sp], #0x50
     dc0:	ret
     dc4:	fmov	x9, d5
     dc8:	ldr	s28, [x9]
     dcc:	adrp	x9, lCPI0_6@PAGE
     dd0:	and.16b	v2, v23, v18
     dd4:	ushll.2d	v27, v3, #0xc
     dd8:	shl.2d	v4, v4, #0x2
     ddc:	tbz	w8, #0x1, 0xf4
     de0:	mov.d	x10, v5[1]
     de4:	ld1.s	{ v28 }[1], [x10]
     de8:	sshll2.2d	v21, v0, #0x0
     dec:	ldr	q22, [x9, lCPI0_6@PAGEOFF]
     df0:	orr.16b	v5, v27, v2
     df4:	add.2d	v4, v20, v4
     df8:	tbz	w8, #0x2, 0x108
     dfc:	fmov	x9, d4
     e00:	ld1.s	{ v28 }[2], [x9]
     e04:	and.16b	v6, v21, v22
     e08:	ushll2.2d	v30, v3, #0xc
     e0c:	shl.2d	v3, v5, #0x2
     e10:	tbz	w8, #0x3, 0x118
     e14:	mov.d	x9, v4[1]
     e18:	ld1.s	{ v28 }[3], [x9]
     e1c:	orr.16b	v4, v30, v6
     e20:	add.2d	v3, v20, v3
     e24:	tbz	w8, #0x4, 0x124
     e28:	fmov	x9, d3
     e2c:	ld1.s	{ v29 }[0], [x9]
     e30:	shl.2d	v4, v4, #0x2
     e34:	tbz	w8, #0x5, 0x12c
     e38:	mov.d	x9, v3[1]
     e3c:	ld1.s	{ v29 }[1], [x9]
     e40:	add.2d	v3, v20, v4
     e44:	tbz	w8, #0x6, 0x134
     e48:	fmov	x9, d3
     e4c:	ld1.s	{ v29 }[2], [x9]
     e50:	add	x9, sp, #0x110
     e54:	stp	q6, q2, [sp]
     e58:	tbnz	w8, #0x7, 0x140
     e5c:	b	0x148
     e60:	fmov	x12, d6
     e64:	ldr	s4, [x12]
     e68:	adrp	x12, lCPI0_10@PAGE
     e6c:	and.16b	v3, v3, v5
     e70:	shl.2d	v7, v7, #0x2
     e74:	tbz	w11, #0x1, 0x1b8
     e78:	mov.d	x13, v6[1]
     e7c:	ld1.s	{ v4 }[1], [x13]
     e80:	ldr	q5, [x12, lCPI0_10@PAGEOFF]
     e84:	orr.16b	v6, v27, v3
     e88:	add.2d	v3, v20, v7
     e8c:	tbz	w11, #0x2, 0x1c8
     e90:	fmov	x12, d3
     e94:	ld1.s	{ v4 }[2], [x12]
     e98:	and.16b	v5, v21, v5
     e9c:	shl.2d	v6, v6, #0x2
     ea0:	tbz	w11, #0x3, 0x1d4
     ea4:	mov.d	x12, v3[1]
     ea8:	ld1.s	{ v4 }[3], [x12]
     eac:	orr.16b	v5, v30, v5
     eb0:	add.2d	v3, v20, v6
     eb4:	tbz	w11, #0x4, 0x1e0
     eb8:	fmov	x12, d3
     ebc:	ld1.s	{ v31 }[0], [x12]
     ec0:	shl.2d	v5, v5, #0x2
     ec4:	tbz	w11, #0x5, 0x1e8
     ec8:	mov.d	x12, v3[1]
     ecc:	ld1.s	{ v31 }[1], [x12]
     ed0:	add.2d	v3, v20, v5
     ed4:	tbz	w11, #0x6, 0x1f0
     ed8:	fmov	x12, d3
     edc:	ld1.s	{ v31 }[2], [x12]
     ee0:	tbnz	w11, #0x7, 0x1f4
     ee4:	b	0x1fc
     ee8:	fmov	x12, d8
     eec:	ldr	s5, [x12]
     ef0:	adrp	x12, lCPI0_14@PAGE
     ef4:	and.16b	v3, v3, v7
     ef8:	shl.2d	v9, v9, #0x2
     efc:	tbz	w11, #0x1, 0x260
     f00:	mov.d	x13, v8[1]
     f04:	ld1.s	{ v5 }[1], [x13]
     f08:	ldr	q7, [x12, lCPI0_14@PAGEOFF]
     f0c:	orr.16b	v8, v27, v3
     f10:	add.2d	v3, v20, v9
     f14:	tbz	w11, #0x2, 0x270
     f18:	fmov	x12, d3
     f1c:	ld1.s	{ v5 }[2], [x12]
     f20:	and.16b	v7, v21, v7
     f24:	shl.2d	v8, v8, #0x2
     f28:	tbz	w11, #0x3, 0x27c
     f2c:	mov.d	x12, v3[1]
     f30:	ld1.s	{ v5 }[3], [x12]
     f34:	orr.16b	v7, v30, v7
     f38:	add.2d	v3, v20, v8
     f3c:	tbz	w11, #0x4, 0x288
     f40:	fmov	x12, d3
     f44:	ld1.s	{ v6 }[0], [x12]
     f48:	shl.2d	v7, v7, #0x2
     f4c:	tbz	w11, #0x5, 0x290
     f50:	mov.d	x12, v3[1]
     f54:	ld1.s	{ v6 }[1], [x12]
     f58:	add.2d	v3, v20, v7
     f5c:	tbz	w11, #0x6, 0x298
     f60:	fmov	x12, d3
     f64:	ld1.s	{ v6 }[2], [x12]
     f68:	tbnz	w11, #0x7, 0x29c
     f6c:	b	0x2a4
     f70:	fmov	x12, d10
     f74:	ldr	s3, [x12]
     f78:	adrp	x12, lCPI0_18@PAGE
     f7c:	and.16b	v8, v8, v9
     f80:	shl.2d	v11, v11, #0x2
     f84:	tbz	w11, #0x1, 0x308
     f88:	mov.d	x13, v10[1]
     f8c:	ld1.s	{ v3 }[1], [x13]
     f90:	ldr	q9, [x12, lCPI0_18@PAGEOFF]
     f94:	orr.16b	v10, v27, v8
     f98:	add.2d	v8, v20, v11
     f9c:	tbz	w11, #0x2, 0x318
     fa0:	fmov	x12, d8
     fa4:	ld1.s	{ v3 }[2], [x12]
     fa8:	and.16b	v9, v21, v9
     fac:	shl.2d	v10, v10, #0x2
     fb0:	tbz	w11, #0x3, 0x324
     fb4:	mov.d	x12, v8[1]
     fb8:	ld1.s	{ v3 }[3], [x12]
     fbc:	orr.16b	v9, v30, v9
     fc0:	add.2d	v8, v20, v10
     fc4:	tbz	w11, #0x4, 0x330
     fc8:	fmov	x12, d8
     fcc:	ld1.s	{ v7 }[0], [x12]
     fd0:	shl.2d	v9, v9, #0x2
     fd4:	tbz	w11, #0x5, 0x338
     fd8:	mov.d	x12, v8[1]
     fdc:	ld1.s	{ v7 }[1], [x12]
     fe0:	add.2d	v8, v20, v9
     fe4:	tbnz	w11, #0x6, 0x340
     fe8:	b	0x348
_llm_rows.packet_batch.blocks:
     fec:	cbz	w3, 0x1144
     ff0:	sub	sp, sp, #0x70
     ff4:	stp	x28, x27, [sp, #0x10]
     ff8:	stp	x26, x25, [sp, #0x20]
     ffc:	stp	x24, x23, [sp, #0x30]
    1000:	stp	x22, x21, [sp, #0x40]
    1004:	stp	x20, x19, [sp, #0x50]
    1008:	stp	x29, x30, [sp, #0x60]
    100c:	mov	x19, x3
    1010:	mov	x20, x2
    1014:	mov	x21, x0
    1018:	mov	w22, #0x0
    101c:	ldp	w24, w8, [x2, #0x2c]
    1020:	stp	w3, w8, [sp, #0x8]
    1024:	ldp	w25, w26, [x2]
    1028:	ldp	w28, w27, [x2, #0x8]
    102c:	str	w24, [sp, #0x4]
    1030:	b	0x1078
    1034:	mov	w8, #0x3f8
    1038:	str	w8, [x20, #0x24]
    103c:	ldp	w24, w19, [sp, #0x4]
    1040:	add	w8, w25, #0x1
    1044:	cmp	w8, w24
    1048:	cset	w8, eq
    104c:	csinc	w25, wzr, w25, eq
    1050:	cinc	w9, w26, eq
    1054:	ldr	w10, [sp, #0xc]
    1058:	cmp	w9, w10
    105c:	cset	w10, eq
    1060:	ands	w8, w8, w10
    1064:	csel	w26, wzr, w9, ne
    1068:	add	w28, w28, w8
    106c:	add	w22, w22, #0x1
    1070:	cmp	w22, w19
    1074:	b.eq	0x1128
    1078:	ubfiz	x8, x25, #10, #32
    107c:	cmp	x8, x27
    1080:	csel	x9, x8, xzr, ls
    1084:	subs	x10, x27, x9
    1088:	cmp	x10, #0x400
    108c:	mov	w11, #0x400
    1090:	csel	x10, x10, x11, lo
    1094:	cmp	x27, x9
    1098:	stp	w25, w26, [x20]
    109c:	str	w28, [x20, #0x8]
    10a0:	ccmp	x8, x27, #0x2, hi
    10a4:	csel	x23, x10, xzr, ls
    10a8:	cmp	x23, #0x400
    10ac:	b.lo	0x10d8
    10b0:	mov	w23, #0x0
    10b4:	str	w23, [x20, #0x24]
    10b8:	mov	x0, x21
    10bc:	mov	x1, x20
    10c0:	mov	w2, #0x8
    10c4:	bl	_llm_rows
    10c8:	add	w23, w23, #0x8
    10cc:	cmp	w23, #0x400
    10d0:	b.ne	0x10b4
    10d4:	b	0x1040
    10d8:	lsr	x8, x23, #3
    10dc:	lsl	w24, w8, #3
    10e0:	cmp	x23, #0x8
    10e4:	b.lo	0x110c
    10e8:	mov	w19, #0x0
    10ec:	str	w19, [x20, #0x24]
    10f0:	mov	x0, x21
    10f4:	mov	x1, x20
    10f8:	mov	w2, #0x8
    10fc:	bl	_llm_rows
    1100:	add	w19, w19, #0x8
    1104:	cmp	w24, w19
    1108:	b.ne	0x10ec
    110c:	and	w2, w23, #0x7
    1110:	cbz	w2, 0x1034
    1114:	str	w24, [x20, #0x24]
    1118:	mov	x0, x21
    111c:	mov	x1, x20
    1120:	bl	_llm_rows
    1124:	b	0x1034
    1128:	ldp	x29, x30, [sp, #0x60]
    112c:	ldp	x20, x19, [sp, #0x50]
    1130:	ldp	x22, x21, [sp, #0x40]
    1134:	ldp	x24, x23, [sp, #0x30]
    1138:	ldp	x26, x25, [sp, #0x20]
    113c:	ldp	x28, x27, [sp, #0x10]
    1140:	add	sp, sp, #0x70
    1144:	ret

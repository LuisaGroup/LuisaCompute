/tmp/luisa-full-packet.UEezjO/capture/rmsnorm-64x256-r0-l8-f1-p1/object/tile_xir_w8_63770_1788856227625083_0.o:
(__TEXT,__text) section
_llm_rows.packet_batch.blocks:
       0:	stp	d15, d14, [sp, #-0xa0]!
       4:	stp	d13, d12, [sp, #0x10]
       8:	stp	d11, d10, [sp, #0x20]
       c:	stp	d9, d8, [sp, #0x30]
      10:	stp	x28, x27, [sp, #0x40]
      14:	stp	x26, x25, [sp, #0x50]
      18:	stp	x24, x23, [sp, #0x60]
      1c:	stp	x22, x21, [sp, #0x70]
      20:	stp	x20, x19, [sp, #0x80]
      24:	stp	x29, x30, [sp, #0x90]
      28:	sub	sp, sp, #0xbb0
      2c:	str	x0, [sp, #0x38]
      30:	cbz	w3, 0x1998
      34:	mov	x25, x3
      38:	mov	w26, #0x0
      3c:	add	x24, sp, #0x2c0
      40:	ldp	w9, w8, [x2, #0x2c]
      44:	stp	w8, w9, [sp, #0x30]
      48:	ldp	w8, w9, [x2]
      4c:	add	x27, sp, #0x7b0
      50:	add	x28, x27, #0xe0
      54:	add	x19, sp, #0x3b0
      58:	movi	d8, #0000000000000000
      5c:	adrp	x10, lCPI0_0@PAGE
      60:	ldr	q0, [x10, lCPI0_0@PAGEOFF]
      64:	str	q0, [sp, #0x150]
      68:	adrp	x10, lCPI0_1@PAGE
      6c:	ldr	q0, [x10, lCPI0_1@PAGEOFF]
      70:	str	q0, [sp, #0x140]
      74:	adrp	x10, lCPI0_2@PAGE
      78:	ldr	q0, [x10, lCPI0_2@PAGEOFF]
      7c:	str	q0, [sp, #0x130]
      80:	adrp	x10, lCPI0_3@PAGE
      84:	ldr	q0, [x10, lCPI0_3@PAGEOFF]
      88:	str	q0, [sp, #0x120]
      8c:	adrp	x10, lCPI0_4@PAGE
      90:	ldr	q0, [x10, lCPI0_4@PAGEOFF]
      94:	str	q0, [sp, #0x110]
      98:	adrp	x10, lCPI0_5@PAGE
      9c:	ldr	q0, [x10, lCPI0_5@PAGEOFF]
      a0:	str	q0, [sp, #0x100]
      a4:	adrp	x10, lCPI0_6@PAGE
      a8:	ldr	q0, [x10, lCPI0_6@PAGEOFF]
      ac:	str	q0, [sp, #0xf0]
      b0:	adrp	x10, lCPI0_7@PAGE
      b4:	ldr	q0, [x10, lCPI0_7@PAGEOFF]
      b8:	str	q0, [sp, #0xe0]
      bc:	adrp	x10, lCPI0_8@PAGE
      c0:	ldr	q0, [x10, lCPI0_8@PAGEOFF]
      c4:	str	q0, [sp, #0xd0]
      c8:	adrp	x10, lCPI0_9@PAGE
      cc:	ldr	q0, [x10, lCPI0_9@PAGEOFF]
      d0:	str	q0, [sp, #0xc0]
      d4:	adrp	x10, lCPI0_10@PAGE
      d8:	ldr	q0, [x10, lCPI0_10@PAGEOFF]
      dc:	str	q0, [sp, #0xb0]
      e0:	adrp	x10, lCPI0_11@PAGE
      e4:	ldr	q0, [x10, lCPI0_11@PAGEOFF]
      e8:	str	q0, [sp, #0xa0]
      ec:	adrp	x10, lCPI0_12@PAGE
      f0:	ldr	q0, [x10, lCPI0_12@PAGEOFF]
      f4:	str	q0, [sp, #0x90]
      f8:	adrp	x10, lCPI0_13@PAGE
      fc:	ldr	q0, [x10, lCPI0_13@PAGEOFF]
     100:	str	q0, [sp, #0x80]
     104:	adrp	x10, lCPI0_14@PAGE
     108:	ldr	q0, [x10, lCPI0_14@PAGEOFF]
     10c:	str	q0, [sp, #0x70]
     110:	adrp	x10, lCPI0_15@PAGE
     114:	ldr	q0, [x10, lCPI0_15@PAGEOFF]
     118:	str	q0, [sp, #0x60]
     11c:	adrp	x10, lCPI0_16@PAGE
     120:	ldr	q0, [x10, lCPI0_16@PAGEOFF]
     124:	str	q0, [sp, #0x220]
     128:	adrp	x10, lCPI0_17@PAGE
     12c:	ldr	q0, [x10, lCPI0_17@PAGEOFF]
     130:	str	q0, [sp, #0x210]
     134:	adrp	x10, lCPI0_18@PAGE
     138:	ldr	q0, [x10, lCPI0_18@PAGEOFF]
     13c:	str	q0, [sp, #0x200]
     140:	adrp	x10, lCPI0_19@PAGE
     144:	ldr	q0, [x10, lCPI0_19@PAGEOFF]
     148:	str	q0, [sp, #0x1f0]
     14c:	ldp	w10, w11, [x2, #0x8]
     150:	str	x2, [sp, #0x10]
     154:	str	x11, [sp, #0x28]
     158:	str	w3, [sp, #0x1c]
     15c:	b	0x1a0
     160:	ldr	x14, [sp, #0x48]
     164:	add	w8, w14, #0x1
     168:	ldp	w11, w9, [sp, #0x30]
     16c:	cmp	w8, w9
     170:	cset	w9, eq
     174:	csinc	w8, wzr, w14, eq
     178:	ldp	w13, w12, [sp, #0x40]
     17c:	cinc	w10, w13, eq
     180:	cmp	w10, w11
     184:	cset	w11, eq
     188:	ands	w11, w9, w11
     18c:	csel	w9, wzr, w10, ne
     190:	add	w10, w12, w11
     194:	add	w26, w26, #0x1
     198:	cmp	w26, w25
     19c:	b.eq	0x1984
     1a0:	stp	w9, w10, [sp, #0x40]
     1a4:	mov	x13, x8
     1a8:	ubfiz	x8, x8, #9, #32
     1ac:	ldr	x12, [sp, #0x28]
     1b0:	cmp	x8, x12
     1b4:	csel	x9, x8, xzr, ls
     1b8:	subs	x10, x12, x9
     1bc:	cmp	x10, #0x200
     1c0:	mov	w11, #0x200
     1c4:	csel	x10, x10, x11, lo
     1c8:	cmp	x12, x9
     1cc:	ccmp	x8, x12, #0x2, hi
     1d0:	csel	x8, x10, xzr, ls
     1d4:	cmp	x8, #0x200
     1d8:	str	x13, [sp, #0x48]
     1dc:	b.lo	0x710
     1e0:	mov	w20, #0x0
     1e4:	ldr	x9, [sp, #0x38]
     1e8:	ldr	x8, [x9]
     1ec:	ldr	x22, [x9, #0x10]
     1f0:	ldr	x21, [x9, #0x30]
     1f4:	lsl	w23, w13, #6
     1f8:	dup.2d	v19, x8
     1fc:	str	q19, [sp, #0x50]
     200:	mov	x8, #0x0
     204:	add	w9, w20, w23
     208:	and	w9, w9, #0x1fffffff
     20c:	dup.2s	v1, w9
     210:	ushll.2d	v0, v1, #0xa
     214:	add.2d	v0, v19, v0
     218:	ldp	q3, q2, [sp, #0x140]
     21c:	add.2d	v2, v0, v2
     220:	mov.d	x9, v2[1]
     224:	add.2d	v3, v0, v3
     228:	mov.d	x10, v3[1]
     22c:	ldp	q5, q4, [sp, #0x120]
     230:	add.2d	v4, v0, v4
     234:	mov.d	x11, v4[1]
     238:	add.2d	v5, v0, v5
     23c:	mov.d	x12, v5[1]
     240:	fmov	x13, d2
     244:	ldr	s2, [x13]
     248:	ld1.s	{ v2 }[1], [x9]
     24c:	fmov	x9, d3
     250:	ld1.s	{ v2 }[2], [x9]
     254:	ld1.s	{ v2 }[3], [x10]
     258:	fmov	x9, d4
     25c:	ldr	s3, [x9]
     260:	ld1.s	{ v3 }[1], [x11]
     264:	fmov	x9, d5
     268:	ld1.s	{ v3 }[2], [x9]
     26c:	ushll.2d	v7, v1, #0x8
     270:	ld1.s	{ v3 }[3], [x12]
     274:	str	q3, [x24, #0x500]
     278:	str	q2, [x24, #0x4f0]
     27c:	fmul.4s	v20, v3, v3
     280:	fmul.4s	v21, v2, v2
     284:	ldp	q1, q2, [sp, #0xe0]
     288:	add.2d	v1, v0, v1
     28c:	add.2d	v2, v0, v2
     290:	ldp	q4, q3, [sp, #0x100]
     294:	add.2d	v3, v0, v3
     298:	mov.d	x9, v3[1]
     29c:	add.2d	v4, v0, v4
     2a0:	mov.d	x10, v4[1]
     2a4:	fmov	x11, d3
     2a8:	fmov	x12, d4
     2ac:	mov.d	x13, v2[1]
     2b0:	fmov	x14, d2
     2b4:	mov.d	x15, v1[1]
     2b8:	ldr	s2, [x11]
     2bc:	ld1.s	{ v2 }[1], [x9]
     2c0:	fmov	x9, d1
     2c4:	ld1.s	{ v2 }[2], [x12]
     2c8:	ld1.s	{ v2 }[3], [x10]
     2cc:	ldr	s1, [x14]
     2d0:	ld1.s	{ v1 }[1], [x13]
     2d4:	ld1.s	{ v1 }[2], [x9]
     2d8:	ld1.s	{ v1 }[3], [x15]
     2dc:	str	q1, [x24, #0x520]
     2e0:	str	q2, [x24, #0x510]
     2e4:	fmul.4s	v22, v1, v1
     2e8:	fmul.4s	v23, v2, v2
     2ec:	ldp	q1, q2, [sp, #0xa0]
     2f0:	add.2d	v1, v0, v1
     2f4:	add.2d	v2, v0, v2
     2f8:	ldp	q3, q4, [sp, #0xc0]
     2fc:	add.2d	v3, v0, v3
     300:	add.2d	v4, v0, v4
     304:	mov.d	x9, v4[1]
     308:	mov.d	x10, v3[1]
     30c:	fmov	x11, d4
     310:	mov.d	x12, v2[1]
     314:	fmov	x13, d2
     318:	mov.d	x14, v1[1]
     31c:	fmov	x15, d1
     320:	ldr	s1, [x13]
     324:	ld1.s	{ v1 }[1], [x12]
     328:	ld1.s	{ v1 }[2], [x15]
     32c:	fmov	x12, d3
     330:	ld1.s	{ v1 }[3], [x14]
     334:	ldr	s2, [x11]
     338:	ld1.s	{ v2 }[1], [x9]
     33c:	ld1.s	{ v2 }[2], [x12]
     340:	ld1.s	{ v2 }[3], [x10]
     344:	fmul.4s	v25, v1, v1
     348:	fmul.4s	v24, v2, v2
     34c:	ldp	q3, q4, [sp, #0x60]
     350:	add.2d	v3, v0, v3
     354:	add.2d	v4, v0, v4
     358:	ldp	q5, q6, [sp, #0x80]
     35c:	add.2d	v5, v0, v5
     360:	add.2d	v0, v0, v6
     364:	mov.d	x9, v0[1]
     368:	fmov	x10, d0
     36c:	mov.d	x11, v5[1]
     370:	fmov	x12, d5
     374:	mov.d	x13, v4[1]
     378:	fmov	x14, d4
     37c:	mov.d	x15, v3[1]
     380:	ldr	s0, [x10]
     384:	ld1.s	{ v0 }[1], [x9]
     388:	fmov	x9, d3
     38c:	ld1.s	{ v0 }[2], [x12]
     390:	ld1.s	{ v0 }[3], [x11]
     394:	ldr	s3, [x14]
     398:	ld1.s	{ v3 }[1], [x13]
     39c:	ld1.s	{ v3 }[2], [x9]
     3a0:	ld1.s	{ v3 }[3], [x15]
     3a4:	str	q2, [x24, #0x530]
     3a8:	str	q1, [x24, #0x540]
     3ac:	str	q3, [x24, #0x560]
     3b0:	str	q0, [x24, #0x550]
     3b4:	fmul.4s	v26, v3, v3
     3b8:	fmul.4s	v27, v0, v0
     3bc:	ldp	q1, q0, [sp, #0x210]
     3c0:	orr.16b	v0, v7, v0
     3c4:	orr.16b	v1, v7, v1
     3c8:	ldp	q3, q2, [sp, #0x1f0]
     3cc:	orr.16b	v2, v7, v2
     3d0:	str	q7, [sp, #0x1e0]
     3d4:	orr.16b	v3, v7, v3
     3d8:	mov	x9, x28
     3dc:	mov	w10, #0x38
     3e0:	sub	x11, x10, #0x18
     3e4:	dup.2d	v4, x11
     3e8:	add.2d	v5, v4, v0
     3ec:	add.2d	v6, v4, v1
     3f0:	add.2d	v7, v4, v2
     3f4:	add.2d	v4, v4, v3
     3f8:	shl.2d	v4, v4, #0x2
     3fc:	shl.2d	v7, v7, #0x2
     400:	shl.2d	v6, v6, #0x2
     404:	shl.2d	v5, v5, #0x2
     408:	add.2d	v5, v19, v5
     40c:	add.2d	v6, v19, v6
     410:	add.2d	v7, v19, v7
     414:	add.2d	v4, v19, v4
     418:	mov.d	x0, v4[1]
     41c:	fmov	x14, d4
     420:	mov.d	x11, v7[1]
     424:	fmov	x15, d7
     428:	mov.d	x16, v6[1]
     42c:	sub	x12, x10, #0x10
     430:	dup.2d	v4, x12
     434:	add.2d	v7, v4, v0
     438:	add.2d	v16, v4, v1
     43c:	fmov	x17, d6
     440:	add.2d	v6, v4, v2
     444:	add.2d	v4, v4, v3
     448:	shl.2d	v4, v4, #0x2
     44c:	shl.2d	v6, v6, #0x2
     450:	mov.d	x12, v5[1]
     454:	shl.2d	v16, v16, #0x2
     458:	shl.2d	v7, v7, #0x2
     45c:	add.2d	v7, v19, v7
     460:	add.2d	v16, v19, v16
     464:	add.2d	v6, v19, v6
     468:	fmov	x2, d5
     46c:	add.2d	v5, v19, v4
     470:	mov.d	x1, v5[1]
     474:	mov.d	x13, v6[1]
     478:	ldr	s4, [x14]
     47c:	fmov	x3, d5
     480:	fmov	x4, d6
     484:	mov.d	x5, v16[1]
     488:	fmov	x6, d16
     48c:	ldr	s5, [x17]
     490:	mov.d	x14, v7[1]
     494:	fmov	x17, d7
     498:	ldr	s6, [x3]
     49c:	sub	x3, x10, #0x8
     4a0:	ldr	s7, [x6]
     4a4:	dup.2d	v16, x3
     4a8:	add.2d	v17, v16, v0
     4ac:	add.2d	v18, v16, v3
     4b0:	ld1.s	{ v4 }[1], [x0]
     4b4:	shl.2d	v18, v18, #0x2
     4b8:	add.2d	v18, v19, v18
     4bc:	mov.d	x0, v18[1]
     4c0:	ld1.s	{ v5 }[1], [x16]
     4c4:	fmov	x16, d18
     4c8:	add.2d	v18, v16, v1
     4cc:	add.2d	v16, v16, v2
     4d0:	shl.2d	v16, v16, #0x2
     4d4:	ld1.s	{ v6 }[1], [x1]
     4d8:	shl.2d	v18, v18, #0x2
     4dc:	shl.2d	v17, v17, #0x2
     4e0:	add.2d	v17, v19, v17
     4e4:	add.2d	v18, v19, v18
     4e8:	ld1.s	{ v7 }[1], [x5]
     4ec:	add.2d	v16, v19, v16
     4f0:	mov.d	x1, v16[1]
     4f4:	fmov	x3, d16
     4f8:	ld1.s	{ v4 }[2], [x15]
     4fc:	mov.d	x5, v18[1]
     500:	mov.d	x15, v17[1]
     504:	ld1.s	{ v5 }[2], [x2]
     508:	fmov	x2, d18
     50c:	ldr	s16, [x2]
     510:	ld1.s	{ v16 }[1], [x5]
     514:	ld1.s	{ v6 }[2], [x4]
     518:	fmov	x2, d17
     51c:	dup.2d	v17, x10
     520:	add.2d	v18, v17, v3
     524:	ld1.s	{ v7 }[2], [x17]
     528:	shl.2d	v18, v18, #0x2
     52c:	add.2d	v18, v19, v18
     530:	mov.d	x17, v18[1]
     534:	ld1.s	{ v16 }[2], [x2]
     538:	fmov	x2, d18
     53c:	add.2d	v18, v17, v2
     540:	shl.2d	v18, v18, #0x2
     544:	add.2d	v18, v19, v18
     548:	ld1.s	{ v4 }[3], [x11]
     54c:	mov.d	x11, v18[1]
     550:	fmov	x4, d18
     554:	add.2d	v18, v17, v1
     558:	ld1.s	{ v5 }[3], [x12]
     55c:	shl.2d	v18, v18, #0x2
     560:	add.2d	v18, v19, v18
     564:	mov.d	x12, v18[1]
     568:	ld1.s	{ v6 }[3], [x13]
     56c:	fmov	x13, d18
     570:	add.2d	v17, v17, v0
     574:	shl.2d	v17, v17, #0x2
     578:	add.2d	v17, v19, v17
     57c:	ld1.s	{ v7 }[3], [x14]
     580:	mov.d	x14, v17[1]
     584:	fmov	x5, d17
     588:	ldr	s17, [x16]
     58c:	ld1.s	{ v16 }[3], [x15]
     590:	ld1.s	{ v17 }[1], [x0]
     594:	ld1.s	{ v17 }[2], [x3]
     598:	ld1.s	{ v17 }[3], [x1]
     59c:	stp	q4, q5, [x9, #-0x60]
     5a0:	fmul.4s	v4, v4, v4
     5a4:	fmul.4s	v5, v5, v5
     5a8:	stp	q6, q7, [x9, #-0x40]
     5ac:	fmul.4s	v6, v6, v6
     5b0:	fmul.4s	v7, v7, v7
     5b4:	stp	q17, q16, [x9, #-0x20]
     5b8:	fmul.4s	v17, v17, v17
     5bc:	fadd.4s	v20, v20, v5
     5c0:	ldr	s5, [x2]
     5c4:	ld1.s	{ v5 }[1], [x17]
     5c8:	ld1.s	{ v5 }[2], [x4]
     5cc:	fadd.4s	v21, v21, v4
     5d0:	ld1.s	{ v5 }[3], [x11]
     5d4:	ldr	s4, [x13]
     5d8:	ld1.s	{ v4 }[1], [x12]
     5dc:	fadd.4s	v22, v22, v7
     5e0:	fmul.4s	v7, v16, v16
     5e4:	ld1.s	{ v4 }[2], [x5]
     5e8:	ld1.s	{ v4 }[3], [x14]
     5ec:	fadd.4s	v23, v23, v6
     5f0:	fadd.4s	v25, v25, v7
     5f4:	stp	q5, q4, [x9], #0x80
     5f8:	fmul.4s	v5, v5, v5
     5fc:	fmul.4s	v4, v4, v4
     600:	fadd.4s	v24, v24, v17
     604:	fadd.4s	v26, v26, v4
     608:	fadd.4s	v27, v27, v5
     60c:	add	x8, x8, #0x4
     610:	add	x10, x10, #0x20
     614:	cmp	x8, #0x1c
     618:	b.lo	0x3e0
     61c:	add	x0, sp, #0x3b0
     620:	mov	x1, x22
     624:	mov	w2, #0x400
     628:	stp	q22, q20, [sp, #0x190]
     62c:	stp	q23, q21, [sp, #0x160]
     630:	stp	q24, q26, [sp, #0x1c0]
     634:	str	q25, [sp, #0x180]
     638:	str	q27, [sp, #0x1b0]
     63c:	bl	_memcpy
     640:	mov	x8, #0x0
     644:	ldp	q1, q0, [sp, #0x160]
     648:	fadd.4s	v0, v0, v1
     64c:	ldp	q2, q1, [sp, #0x190]
     650:	fadd.4s	v1, v1, v2
     654:	ldr	q2, [sp, #0x180]
     658:	fadd.4s	v1, v1, v2
     65c:	ldp	q2, q3, [sp, #0x1b0]
     660:	fadd.4s	v0, v0, v3
     664:	fadd.4s	v0, v0, v2
     668:	ldr	q2, [sp, #0x1d0]
     66c:	fadd.4s	v1, v1, v2
     670:	rev64.4s	v2, v1
     674:	rev64.4s	v3, v0
     678:	fadd.4s	v0, v0, v3
     67c:	fadd.4s	v1, v1, v2
     680:	dup.4s	v2, v1[2]
     684:	dup.4s	v3, v0[2]
     688:	fadd.4s	v0, v0, v3
     68c:	fadd.4s	v1, v1, v2
     690:	fadd.4s	v0, v0, v1
     694:	fadd	s0, s0, s8
     698:	mov	w9, #0x3b800000
     69c:	fmov	s1, w9
     6a0:	fmul	s0, s0, s1
     6a4:	mov	w9, #0xc5ac
     6a8:	movk	w9, #0x3727, lsl #16
     6ac:	fmov	s1, w9
     6b0:	fadd	s0, s0, s1
     6b4:	fsqrt	s0, s0
     6b8:	dup.4s	v0, v0[0]
     6bc:	ldr	q1, [sp, #0x1e0]
     6c0:	fmov	x9, d1
     6c4:	add	x9, x21, x9, lsl #2
     6c8:	add	x10, x27, x8
     6cc:	ldp	q1, q2, [x10]
     6d0:	fdiv.4s	v2, v2, v0
     6d4:	fdiv.4s	v1, v1, v0
     6d8:	add	x10, x19, x8
     6dc:	ldp	q4, q3, [x10]
     6e0:	fmul.4s	v1, v1, v4
     6e4:	fmul.4s	v2, v2, v3
     6e8:	add	x10, x9, x8
     6ec:	stp	q1, q2, [x10]
     6f0:	add	x8, x8, #0x20
     6f4:	cmp	x8, #0x400
     6f8:	b.ne	0x6c8
     6fc:	add	w20, w20, #0x1
     700:	cmp	w20, #0x40
     704:	ldr	q19, [sp, #0x50]
     708:	b.ne	0x200
     70c:	b	0x160
     710:	str	w26, [sp, #0x50]
     714:	lsr	x20, x8, #3
     718:	str	x8, [sp, #0x20]
     71c:	cmp	x8, #0x8
     720:	b.lo	0xc4c
     724:	mov	w23, #0x0
     728:	ldr	x8, [sp, #0x38]
     72c:	ldr	x25, [x8]
     730:	ldr	x22, [x8, #0x10]
     734:	ldr	x9, [sp, #0x48]
     738:	lsl	w26, w9, #6
     73c:	ldr	x21, [x8, #0x30]
     740:	mov	x8, #0x0
     744:	add	w9, w23, w26
     748:	and	w9, w9, #0x1fffffff
     74c:	dup.2s	v2, w9
     750:	dup.2d	v0, x25
     754:	ushll.2d	v1, v2, #0xa
     758:	add.2d	v1, v0, v1
     75c:	ldp	q4, q3, [sp, #0x140]
     760:	add.2d	v3, v1, v3
     764:	mov.d	x9, v3[1]
     768:	add.2d	v4, v1, v4
     76c:	mov.d	x10, v4[1]
     770:	ldp	q6, q5, [sp, #0x120]
     774:	add.2d	v5, v1, v5
     778:	mov.d	x11, v5[1]
     77c:	add.2d	v6, v1, v6
     780:	mov.d	x12, v6[1]
     784:	fmov	x13, d3
     788:	ldr	s3, [x13]
     78c:	ld1.s	{ v3 }[1], [x9]
     790:	fmov	x9, d4
     794:	ld1.s	{ v3 }[2], [x9]
     798:	ld1.s	{ v3 }[3], [x10]
     79c:	fmov	x9, d5
     7a0:	ldr	s4, [x9]
     7a4:	ushll.2d	v16, v2, #0x8
     7a8:	ld1.s	{ v4 }[1], [x11]
     7ac:	fmov	x9, d6
     7b0:	ld1.s	{ v4 }[2], [x9]
     7b4:	ld1.s	{ v4 }[3], [x12]
     7b8:	str	q4, [x24, #0x500]
     7bc:	str	q3, [x24, #0x4f0]
     7c0:	fmul.4s	v20, v4, v4
     7c4:	fmul.4s	v21, v3, v3
     7c8:	ldp	q2, q3, [sp, #0xe0]
     7cc:	add.2d	v2, v1, v2
     7d0:	add.2d	v3, v1, v3
     7d4:	ldp	q4, q5, [sp, #0x100]
     7d8:	add.2d	v4, v1, v4
     7dc:	add.2d	v5, v1, v5
     7e0:	mov.d	x9, v5[1]
     7e4:	fmov	x10, d5
     7e8:	mov.d	x11, v4[1]
     7ec:	fmov	x12, d4
     7f0:	mov.d	x13, v3[1]
     7f4:	fmov	x14, d3
     7f8:	mov.d	x15, v2[1]
     7fc:	ldr	s3, [x10]
     800:	ld1.s	{ v3 }[1], [x9]
     804:	fmov	x9, d2
     808:	ld1.s	{ v3 }[2], [x12]
     80c:	ld1.s	{ v3 }[3], [x11]
     810:	ldr	s2, [x14]
     814:	ld1.s	{ v2 }[1], [x13]
     818:	ld1.s	{ v2 }[2], [x9]
     81c:	ld1.s	{ v2 }[3], [x15]
     820:	str	q2, [x24, #0x520]
     824:	str	q3, [x24, #0x510]
     828:	fmul.4s	v22, v2, v2
     82c:	fmul.4s	v23, v3, v3
     830:	ldp	q2, q3, [sp, #0xa0]
     834:	add.2d	v2, v1, v2
     838:	add.2d	v3, v1, v3
     83c:	ldp	q4, q5, [sp, #0xc0]
     840:	add.2d	v4, v1, v4
     844:	add.2d	v5, v1, v5
     848:	mov.d	x9, v5[1]
     84c:	mov.d	x10, v4[1]
     850:	fmov	x11, d5
     854:	mov.d	x12, v3[1]
     858:	fmov	x13, d3
     85c:	mov.d	x14, v2[1]
     860:	fmov	x15, d2
     864:	ldr	s2, [x13]
     868:	ld1.s	{ v2 }[1], [x12]
     86c:	ld1.s	{ v2 }[2], [x15]
     870:	fmov	x12, d4
     874:	ld1.s	{ v2 }[3], [x14]
     878:	ldr	s3, [x11]
     87c:	ld1.s	{ v3 }[1], [x9]
     880:	ld1.s	{ v3 }[2], [x12]
     884:	ld1.s	{ v3 }[3], [x10]
     888:	fmul.4s	v25, v2, v2
     88c:	fmul.4s	v24, v3, v3
     890:	ldp	q4, q5, [sp, #0x60]
     894:	add.2d	v4, v1, v4
     898:	add.2d	v5, v1, v5
     89c:	ldp	q6, q7, [sp, #0x80]
     8a0:	add.2d	v6, v1, v6
     8a4:	add.2d	v1, v1, v7
     8a8:	mov.d	x9, v1[1]
     8ac:	fmov	x10, d1
     8b0:	mov.d	x11, v6[1]
     8b4:	fmov	x12, d6
     8b8:	mov.d	x13, v5[1]
     8bc:	fmov	x14, d5
     8c0:	mov.d	x15, v4[1]
     8c4:	ldr	s1, [x10]
     8c8:	ld1.s	{ v1 }[1], [x9]
     8cc:	fmov	x9, d4
     8d0:	ld1.s	{ v1 }[2], [x12]
     8d4:	ld1.s	{ v1 }[3], [x11]
     8d8:	ldr	s4, [x14]
     8dc:	ld1.s	{ v4 }[1], [x13]
     8e0:	ld1.s	{ v4 }[2], [x9]
     8e4:	ld1.s	{ v4 }[3], [x15]
     8e8:	str	q3, [x24, #0x530]
     8ec:	str	q2, [x24, #0x540]
     8f0:	str	q4, [x24, #0x560]
     8f4:	str	q1, [x24, #0x550]
     8f8:	fmul.4s	v26, v4, v4
     8fc:	fmul.4s	v27, v1, v1
     900:	ldp	q2, q1, [sp, #0x210]
     904:	orr.16b	v1, v16, v1
     908:	orr.16b	v2, v16, v2
     90c:	ldp	q4, q3, [sp, #0x1f0]
     910:	orr.16b	v3, v16, v3
     914:	str	q16, [sp, #0x1e0]
     918:	orr.16b	v4, v16, v4
     91c:	mov	x9, x28
     920:	mov	w10, #0x38
     924:	sub	x11, x10, #0x18
     928:	dup.2d	v5, x11
     92c:	add.2d	v6, v5, v1
     930:	add.2d	v7, v5, v2
     934:	add.2d	v16, v5, v3
     938:	add.2d	v5, v5, v4
     93c:	shl.2d	v5, v5, #0x2
     940:	shl.2d	v16, v16, #0x2
     944:	shl.2d	v7, v7, #0x2
     948:	shl.2d	v6, v6, #0x2
     94c:	add.2d	v6, v0, v6
     950:	add.2d	v7, v0, v7
     954:	add.2d	v16, v0, v16
     958:	add.2d	v5, v0, v5
     95c:	mov.d	x0, v5[1]
     960:	fmov	x14, d5
     964:	mov.d	x11, v16[1]
     968:	fmov	x15, d16
     96c:	mov.d	x16, v7[1]
     970:	sub	x12, x10, #0x10
     974:	dup.2d	v5, x12
     978:	add.2d	v16, v5, v1
     97c:	add.2d	v17, v5, v2
     980:	fmov	x17, d7
     984:	add.2d	v7, v5, v3
     988:	add.2d	v5, v5, v4
     98c:	shl.2d	v5, v5, #0x2
     990:	shl.2d	v7, v7, #0x2
     994:	mov.d	x12, v6[1]
     998:	shl.2d	v17, v17, #0x2
     99c:	shl.2d	v16, v16, #0x2
     9a0:	add.2d	v16, v0, v16
     9a4:	add.2d	v17, v0, v17
     9a8:	add.2d	v7, v0, v7
     9ac:	fmov	x2, d6
     9b0:	add.2d	v6, v0, v5
     9b4:	mov.d	x1, v6[1]
     9b8:	mov.d	x13, v7[1]
     9bc:	ldr	s5, [x14]
     9c0:	fmov	x3, d6
     9c4:	fmov	x4, d7
     9c8:	mov.d	x5, v17[1]
     9cc:	fmov	x6, d17
     9d0:	ldr	s6, [x17]
     9d4:	mov.d	x14, v16[1]
     9d8:	fmov	x17, d16
     9dc:	ldr	s7, [x3]
     9e0:	sub	x3, x10, #0x8
     9e4:	ldr	s16, [x6]
     9e8:	dup.2d	v17, x3
     9ec:	add.2d	v18, v17, v1
     9f0:	add.2d	v19, v17, v4
     9f4:	ld1.s	{ v5 }[1], [x0]
     9f8:	shl.2d	v19, v19, #0x2
     9fc:	add.2d	v19, v0, v19
     a00:	mov.d	x0, v19[1]
     a04:	ld1.s	{ v6 }[1], [x16]
     a08:	fmov	x16, d19
     a0c:	add.2d	v19, v17, v2
     a10:	add.2d	v17, v17, v3
     a14:	shl.2d	v17, v17, #0x2
     a18:	ld1.s	{ v7 }[1], [x1]
     a1c:	shl.2d	v19, v19, #0x2
     a20:	shl.2d	v18, v18, #0x2
     a24:	add.2d	v18, v0, v18
     a28:	add.2d	v19, v0, v19
     a2c:	ld1.s	{ v16 }[1], [x5]
     a30:	add.2d	v17, v0, v17
     a34:	mov.d	x1, v17[1]
     a38:	fmov	x3, d17
     a3c:	ld1.s	{ v5 }[2], [x15]
     a40:	mov.d	x5, v19[1]
     a44:	mov.d	x15, v18[1]
     a48:	ld1.s	{ v6 }[2], [x2]
     a4c:	fmov	x2, d19
     a50:	ldr	s17, [x2]
     a54:	ld1.s	{ v17 }[1], [x5]
     a58:	ld1.s	{ v7 }[2], [x4]
     a5c:	fmov	x2, d18
     a60:	dup.2d	v18, x10
     a64:	add.2d	v19, v18, v4
     a68:	ld1.s	{ v16 }[2], [x17]
     a6c:	shl.2d	v19, v19, #0x2
     a70:	add.2d	v19, v0, v19
     a74:	mov.d	x17, v19[1]
     a78:	ld1.s	{ v17 }[2], [x2]
     a7c:	fmov	x2, d19
     a80:	add.2d	v19, v18, v3
     a84:	shl.2d	v19, v19, #0x2
     a88:	add.2d	v19, v0, v19
     a8c:	ld1.s	{ v5 }[3], [x11]
     a90:	mov.d	x11, v19[1]
     a94:	fmov	x4, d19
     a98:	add.2d	v19, v18, v2
     a9c:	ld1.s	{ v6 }[3], [x12]
     aa0:	shl.2d	v19, v19, #0x2
     aa4:	add.2d	v19, v0, v19
     aa8:	mov.d	x12, v19[1]
     aac:	ld1.s	{ v7 }[3], [x13]
     ab0:	fmov	x13, d19
     ab4:	add.2d	v18, v18, v1
     ab8:	shl.2d	v18, v18, #0x2
     abc:	add.2d	v18, v0, v18
     ac0:	ld1.s	{ v16 }[3], [x14]
     ac4:	mov.d	x14, v18[1]
     ac8:	fmov	x5, d18
     acc:	ldr	s18, [x16]
     ad0:	ld1.s	{ v17 }[3], [x15]
     ad4:	ld1.s	{ v18 }[1], [x0]
     ad8:	ld1.s	{ v18 }[2], [x3]
     adc:	ld1.s	{ v18 }[3], [x1]
     ae0:	stp	q5, q6, [x9, #-0x60]
     ae4:	fmul.4s	v5, v5, v5
     ae8:	fmul.4s	v6, v6, v6
     aec:	stp	q7, q16, [x9, #-0x40]
     af0:	fmul.4s	v7, v7, v7
     af4:	fmul.4s	v16, v16, v16
     af8:	stp	q18, q17, [x9, #-0x20]
     afc:	fmul.4s	v18, v18, v18
     b00:	fadd.4s	v20, v20, v6
     b04:	ldr	s6, [x2]
     b08:	ld1.s	{ v6 }[1], [x17]
     b0c:	ld1.s	{ v6 }[2], [x4]
     b10:	fadd.4s	v21, v21, v5
     b14:	ld1.s	{ v6 }[3], [x11]
     b18:	ldr	s5, [x13]
     b1c:	ld1.s	{ v5 }[1], [x12]
     b20:	fadd.4s	v22, v22, v16
     b24:	fmul.4s	v16, v17, v17
     b28:	ld1.s	{ v5 }[2], [x5]
     b2c:	ld1.s	{ v5 }[3], [x14]
     b30:	fadd.4s	v23, v23, v7
     b34:	fadd.4s	v25, v25, v16
     b38:	stp	q6, q5, [x9], #0x80
     b3c:	fmul.4s	v6, v6, v6
     b40:	fmul.4s	v5, v5, v5
     b44:	fadd.4s	v24, v24, v18
     b48:	fadd.4s	v26, v26, v5
     b4c:	fadd.4s	v27, v27, v6
     b50:	add	x8, x8, #0x4
     b54:	add	x10, x10, #0x20
     b58:	cmp	x8, #0x1c
     b5c:	b.lo	0x924
     b60:	add	x0, sp, #0x3b0
     b64:	mov	x1, x22
     b68:	mov	w2, #0x400
     b6c:	stp	q22, q20, [sp, #0x190]
     b70:	stp	q23, q21, [sp, #0x160]
     b74:	stp	q24, q26, [sp, #0x1c0]
     b78:	str	q25, [sp, #0x180]
     b7c:	str	q27, [sp, #0x1b0]
     b80:	bl	_memcpy
     b84:	mov	x8, #0x0
     b88:	ldp	q1, q0, [sp, #0x160]
     b8c:	fadd.4s	v0, v0, v1
     b90:	ldp	q2, q1, [sp, #0x190]
     b94:	fadd.4s	v1, v1, v2
     b98:	ldr	q2, [sp, #0x180]
     b9c:	fadd.4s	v1, v1, v2
     ba0:	ldp	q2, q3, [sp, #0x1b0]
     ba4:	fadd.4s	v0, v0, v3
     ba8:	fadd.4s	v0, v0, v2
     bac:	ldr	q2, [sp, #0x1d0]
     bb0:	fadd.4s	v1, v1, v2
     bb4:	rev64.4s	v2, v1
     bb8:	rev64.4s	v3, v0
     bbc:	fadd.4s	v0, v0, v3
     bc0:	fadd.4s	v1, v1, v2
     bc4:	dup.4s	v2, v1[2]
     bc8:	dup.4s	v3, v0[2]
     bcc:	fadd.4s	v0, v0, v3
     bd0:	fadd.4s	v1, v1, v2
     bd4:	fadd.4s	v0, v0, v1
     bd8:	fadd	s0, s0, s8
     bdc:	mov	w9, #0x3b800000
     be0:	fmov	s1, w9
     be4:	fmul	s0, s0, s1
     be8:	mov	w9, #0xc5ac
     bec:	movk	w9, #0x3727, lsl #16
     bf0:	fmov	s1, w9
     bf4:	fadd	s0, s0, s1
     bf8:	fsqrt	s0, s0
     bfc:	dup.4s	v0, v0[0]
     c00:	ldr	q1, [sp, #0x1e0]
     c04:	fmov	x9, d1
     c08:	add	x9, x21, x9, lsl #2
     c0c:	add	x10, x27, x8
     c10:	ldp	q1, q2, [x10]
     c14:	fdiv.4s	v2, v2, v0
     c18:	fdiv.4s	v1, v1, v0
     c1c:	add	x10, x19, x8
     c20:	ldp	q4, q3, [x10]
     c24:	fmul.4s	v1, v1, v4
     c28:	fmul.4s	v2, v2, v3
     c2c:	add	x10, x9, x8
     c30:	stp	q1, q2, [x10]
     c34:	add	x8, x8, #0x20
     c38:	cmp	x8, #0x400
     c3c:	b.ne	0xc0c
     c40:	add	w23, w23, #0x1
     c44:	cmp	w23, w20
     c48:	b.ne	0x740
     c4c:	ldr	x8, [sp, #0x20]
     c50:	and	w8, w8, #0x7
     c54:	ldr	w25, [sp, #0x1c]
     c58:	ldr	w26, [sp, #0x50]
     c5c:	cbz	w8, 0x160
     c60:	dup.4s	v1, w8
     c64:	adrp	x8, lCPI0_21@PAGE
     c68:	ldr	q2, [x8, lCPI0_21@PAGEOFF]
     c6c:	adrp	x8, lCPI0_22@PAGE
     c70:	ldr	q0, [x8, lCPI0_22@PAGEOFF]
     c74:	cmhi.4s	v0, v1, v0
     c78:	cmhi.4s	v1, v1, v2
     c7c:	uzp1.8h	v3, v1, v0
     c80:	umaxv.8h	h2, v3
     c84:	fmov	w8, s2
     c88:	ldr	x10, [sp, #0x48]
     c8c:	tbz	w8, #0x0, 0x160
     c90:	ldr	x8, [sp, #0x38]
     c94:	ldr	x9, [x8]
     c98:	adrp	x8, lCPI0_20@PAGE
     c9c:	ldr	q2, [x8, lCPI0_20@PAGEOFF]
     ca0:	and.16b	v2, v3, v2
     ca4:	addv.8h	h2, v2
     ca8:	fmov	w8, s2
     cac:	sshll.2d	v19, v1, #0x0
     cb0:	ldr	q4, [sp, #0x1f0]
     cb4:	and.16b	v5, v19, v4
     cb8:	ubfiz	w10, w10, #6, #23
     cbc:	orr	w10, w10, w20
     cc0:	dup.4s	v4, w10
     cc4:	and.16b	v6, v1, v4
     cc8:	ushll.2d	v20, v6, #0x8
     ccc:	str	q5, [sp, #0x1e0]
     cd0:	orr.16b	v5, v20, v5
     cd4:	shl.2d	v5, v5, #0x2
     cd8:	dup.2d	v16, x9
     cdc:	add.2d	v5, v16, v5
     ce0:	movi.2d	v21, #0000000000000000
     ce4:	movi.2d	v22, #0000000000000000
     ce8:	tbz	w8, #0x0, 0xcf4
     cec:	fmov	x9, d5
     cf0:	ldr	s21, [x9]
     cf4:	and	w8, w8, #0xff
     cf8:	tbz	w8, #0x1, 0xd04
     cfc:	mov.d	x9, v5[1]
     d00:	ld1.s	{ v21 }[1], [x9]
     d04:	sshll2.2d	v17, v1, #0x0
     d08:	ldr	q5, [sp, #0x200]
     d0c:	and.16b	v5, v17, v5
     d10:	ushll2.2d	v23, v6, #0x8
     d14:	str	q5, [sp, #0x1d0]
     d18:	orr.16b	v5, v23, v5
     d1c:	shl.2d	v5, v5, #0x2
     d20:	add.2d	v5, v16, v5
     d24:	tbz	w8, #0x2, 0xd30
     d28:	fmov	x9, d5
     d2c:	ld1.s	{ v21 }[2], [x9]
     d30:	tbz	w8, #0x3, 0xd3c
     d34:	mov.d	x9, v5[1]
     d38:	ld1.s	{ v21 }[3], [x9]
     d3c:	sshll.2d	v24, v0, #0x0
     d40:	ldr	q5, [sp, #0x210]
     d44:	and.16b	v5, v24, v5
     d48:	and.16b	v4, v0, v4
     d4c:	ushll.2d	v25, v4, #0x8
     d50:	str	q5, [sp, #0x1c0]
     d54:	orr.16b	v5, v25, v5
     d58:	shl.2d	v5, v5, #0x2
     d5c:	add.2d	v5, v16, v5
     d60:	tbz	w8, #0x4, 0xd6c
     d64:	fmov	x9, d5
     d68:	ld1.s	{ v22 }[0], [x9]
     d6c:	tbz	w8, #0x5, 0xd78
     d70:	mov.d	x9, v5[1]
     d74:	ld1.s	{ v22 }[1], [x9]
     d78:	sshll2.2d	v18, v0, #0x0
     d7c:	ldr	q5, [sp, #0x220]
     d80:	and.16b	v7, v18, v5
     d84:	ushll2.2d	v26, v4, #0x8
     d88:	orr.16b	v4, v26, v7
     d8c:	shl.2d	v4, v4, #0x2
     d90:	add.2d	v4, v16, v4
     d94:	tbz	w8, #0x6, 0xda0
     d98:	fmov	x9, d4
     d9c:	ld1.s	{ v22 }[2], [x9]
     da0:	tbz	w8, #0x7, 0xdac
     da4:	mov.d	x8, v4[1]
     da8:	ld1.s	{ v22 }[3], [x8]
     dac:	ldr	x8, [sp, #0x38]
     db0:	ldr	x9, [x8, #0x10]
     db4:	ldr	x8, [x8, #0x30]
     db8:	fmov	w10, s2
     dbc:	sshll.2d	v4, v1, #0x0
     dc0:	str	q21, [x24, #0x4f0]
     dc4:	str	q22, [x24, #0x500]
     dc8:	adrp	x11, lCPI0_23@PAGE
     dcc:	ldr	q5, [x11, lCPI0_23@PAGEOFF]
     dd0:	and.16b	v4, v4, v5
     dd4:	orr.16b	v4, v20, v4
     dd8:	shl.2d	v4, v4, #0x2
     ddc:	add.2d	v4, v16, v4
     de0:	movi.2d	v27, #0000000000000000
     de4:	movi.2d	v31, #0000000000000000
     de8:	tbz	w10, #0x0, 0xdf4
     dec:	fmov	x11, d4
     df0:	ldr	s27, [x11]
     df4:	and	w10, w10, #0xff
     df8:	tbz	w10, #0x1, 0xe04
     dfc:	mov.d	x11, v4[1]
     e00:	ld1.s	{ v27 }[1], [x11]
     e04:	adrp	x11, lCPI0_25@PAGE
     e08:	ldr	q4, [x11, lCPI0_25@PAGEOFF]
     e0c:	and.16b	v4, v17, v4
     e10:	orr.16b	v4, v23, v4
     e14:	shl.2d	v4, v4, #0x2
     e18:	add.2d	v4, v16, v4
     e1c:	tbz	w10, #0x2, 0xe28
     e20:	fmov	x11, d4
     e24:	ld1.s	{ v27 }[2], [x11]
     e28:	tbz	w10, #0x3, 0xe34
     e2c:	mov.d	x11, v4[1]
     e30:	ld1.s	{ v27 }[3], [x11]
     e34:	sshll.2d	v4, v0, #0x0
     e38:	adrp	x11, lCPI0_24@PAGE
     e3c:	ldr	q5, [x11, lCPI0_24@PAGEOFF]
     e40:	and.16b	v4, v4, v5
     e44:	orr.16b	v4, v25, v4
     e48:	shl.2d	v4, v4, #0x2
     e4c:	add.2d	v4, v16, v4
     e50:	tbz	w10, #0x4, 0xe5c
     e54:	fmov	x11, d4
     e58:	ld1.s	{ v31 }[0], [x11]
     e5c:	tbz	w10, #0x5, 0xe68
     e60:	mov.d	x11, v4[1]
     e64:	ld1.s	{ v31 }[1], [x11]
     e68:	adrp	x11, lCPI0_26@PAGE
     e6c:	ldr	q4, [x11, lCPI0_26@PAGEOFF]
     e70:	and.16b	v4, v18, v4
     e74:	orr.16b	v4, v26, v4
     e78:	shl.2d	v4, v4, #0x2
     e7c:	add.2d	v4, v16, v4
     e80:	tbz	w10, #0x6, 0xe8c
     e84:	fmov	x11, d4
     e88:	ld1.s	{ v31 }[2], [x11]
     e8c:	tbz	w10, #0x7, 0xe98
     e90:	mov.d	x10, v4[1]
     e94:	ld1.s	{ v31 }[3], [x10]
     e98:	fmov	w10, s2
     e9c:	sshll.2d	v4, v1, #0x0
     ea0:	str	q27, [x24, #0x510]
     ea4:	str	q31, [x24, #0x520]
     ea8:	adrp	x11, lCPI0_27@PAGE
     eac:	ldr	q5, [x11, lCPI0_27@PAGEOFF]
     eb0:	and.16b	v4, v4, v5
     eb4:	orr.16b	v4, v20, v4
     eb8:	shl.2d	v4, v4, #0x2
     ebc:	add.2d	v4, v16, v4
     ec0:	movi.2d	v9, #0000000000000000
     ec4:	movi.2d	v10, #0000000000000000
     ec8:	tbz	w10, #0x0, 0xed4
     ecc:	fmov	x11, d4
     ed0:	ldr	s9, [x11]
     ed4:	and	w10, w10, #0xff
     ed8:	tbz	w10, #0x1, 0xee4
     edc:	mov.d	x11, v4[1]
     ee0:	ld1.s	{ v9 }[1], [x11]
     ee4:	adrp	x11, lCPI0_29@PAGE
     ee8:	ldr	q4, [x11, lCPI0_29@PAGEOFF]
     eec:	and.16b	v4, v17, v4
     ef0:	orr.16b	v4, v23, v4
     ef4:	shl.2d	v4, v4, #0x2
     ef8:	add.2d	v4, v16, v4
     efc:	tbz	w10, #0x2, 0xf08
     f00:	fmov	x11, d4
     f04:	ld1.s	{ v9 }[2], [x11]
     f08:	tbz	w10, #0x3, 0xf14
     f0c:	mov.d	x11, v4[1]
     f10:	ld1.s	{ v9 }[3], [x11]
     f14:	sshll.2d	v4, v0, #0x0
     f18:	adrp	x11, lCPI0_28@PAGE
     f1c:	ldr	q5, [x11, lCPI0_28@PAGEOFF]
     f20:	and.16b	v4, v4, v5
     f24:	orr.16b	v4, v25, v4
     f28:	shl.2d	v4, v4, #0x2
     f2c:	add.2d	v4, v16, v4
     f30:	tbz	w10, #0x4, 0xf3c
     f34:	fmov	x11, d4
     f38:	ld1.s	{ v10 }[0], [x11]
     f3c:	tbz	w10, #0x5, 0xf48
     f40:	mov.d	x11, v4[1]
     f44:	ld1.s	{ v10 }[1], [x11]
     f48:	adrp	x11, lCPI0_30@PAGE
     f4c:	ldr	q4, [x11, lCPI0_30@PAGEOFF]
     f50:	and.16b	v4, v18, v4
     f54:	orr.16b	v4, v26, v4
     f58:	shl.2d	v4, v4, #0x2
     f5c:	add.2d	v4, v16, v4
     f60:	tbz	w10, #0x6, 0xf6c
     f64:	fmov	x11, d4
     f68:	ld1.s	{ v10 }[2], [x11]
     f6c:	tbz	w10, #0x7, 0xf78
     f70:	mov.d	x10, v4[1]
     f74:	ld1.s	{ v10 }[3], [x10]
     f78:	fmov	w10, s2
     f7c:	sshll.2d	v4, v1, #0x0
     f80:	str	q9, [x24, #0x530]
     f84:	str	q10, [x24, #0x540]
     f88:	adrp	x11, lCPI0_31@PAGE
     f8c:	ldr	q5, [x11, lCPI0_31@PAGEOFF]
     f90:	and.16b	v4, v4, v5
     f94:	orr.16b	v4, v20, v4
     f98:	shl.2d	v4, v4, #0x2
     f9c:	add.2d	v4, v16, v4
     fa0:	movi.2d	v11, #0000000000000000
     fa4:	movi.2d	v12, #0000000000000000
     fa8:	tbz	w10, #0x0, 0xfb4
     fac:	fmov	x11, d4
     fb0:	ldr	s11, [x11]
     fb4:	and	w10, w10, #0xff
     fb8:	tbz	w10, #0x1, 0xfc4
     fbc:	mov.d	x11, v4[1]
     fc0:	ld1.s	{ v11 }[1], [x11]
     fc4:	adrp	x11, lCPI0_33@PAGE
     fc8:	ldr	q4, [x11, lCPI0_33@PAGEOFF]
     fcc:	and.16b	v4, v17, v4
     fd0:	orr.16b	v4, v23, v4
     fd4:	shl.2d	v4, v4, #0x2
     fd8:	add.2d	v4, v16, v4
     fdc:	tbz	w10, #0x2, 0xfe8
     fe0:	fmov	x11, d4
     fe4:	ld1.s	{ v11 }[2], [x11]
     fe8:	tbz	w10, #0x3, 0xff4
     fec:	mov.d	x11, v4[1]
     ff0:	ld1.s	{ v11 }[3], [x11]
     ff4:	sshll.2d	v4, v0, #0x0
     ff8:	adrp	x11, lCPI0_32@PAGE
     ffc:	ldr	q5, [x11, lCPI0_32@PAGEOFF]
    1000:	and.16b	v4, v4, v5
    1004:	orr.16b	v4, v25, v4
    1008:	shl.2d	v4, v4, #0x2
    100c:	add.2d	v4, v16, v4
    1010:	tbz	w10, #0x4, 0x101c
    1014:	fmov	x11, d4
    1018:	ld1.s	{ v12 }[0], [x11]
    101c:	tbz	w10, #0x5, 0x1028
    1020:	mov.d	x11, v4[1]
    1024:	ld1.s	{ v12 }[1], [x11]
    1028:	adrp	x11, lCPI0_34@PAGE
    102c:	ldr	q4, [x11, lCPI0_34@PAGEOFF]
    1030:	and.16b	v4, v18, v4
    1034:	orr.16b	v4, v26, v4
    1038:	shl.2d	v4, v4, #0x2
    103c:	add.2d	v4, v16, v4
    1040:	tbz	w10, #0x6, 0x104c
    1044:	fmov	x11, d4
    1048:	ld1.s	{ v12 }[2], [x11]
    104c:	tbz	w10, #0x7, 0x1058
    1050:	mov.d	x10, v4[1]
    1054:	ld1.s	{ v12 }[3], [x10]
    1058:	mov	x11, #0x0
    105c:	and.16b	v28, v18, v26
    1060:	and.16b	v29, v17, v23
    1064:	fmov	w10, s2
    1068:	and.16b	v30, v24, v25
    106c:	and	w10, w10, #0xff
    1070:	and.16b	v19, v19, v20
    1074:	fmul.4s	v4, v21, v21
    1078:	fmul.4s	v5, v22, v22
    107c:	fmul.4s	v22, v27, v27
    1080:	fmul.4s	v23, v31, v31
    1084:	fmul.4s	v26, v9, v9
    1088:	fmul.4s	v27, v10, v10
    108c:	str	q11, [x24, #0x550]
    1090:	str	q12, [x24, #0x560]
    1094:	fmul.4s	v31, v11, v11
    1098:	fmul.4s	v9, v12, v12
    109c:	and.16b	v21, v0, v5
    10a0:	and.16b	v20, v1, v4
    10a4:	and.16b	v25, v0, v23
    10a8:	and.16b	v24, v1, v22
    10ac:	and.16b	v22, v0, v27
    10b0:	and.16b	v26, v1, v26
    10b4:	and.16b	v23, v0, v9
    10b8:	mov	x12, x28
    10bc:	mov	w13, #0x20
    10c0:	and.16b	v27, v1, v31
    10c4:	b	0x1148
    10c8:	fmul.4s	v4, v9, v9
    10cc:	fmul.4s	v5, v31, v31
    10d0:	fadd.4s	v5, v20, v5
    10d4:	fadd.4s	v4, v21, v4
    10d8:	fmul.4s	v6, v11, v11
    10dc:	fmul.4s	v31, v10, v10
    10e0:	fadd.4s	v31, v24, v31
    10e4:	fadd.4s	v6, v25, v6
    10e8:	fmul.4s	v9, v13, v13
    10ec:	fmul.4s	v10, v12, v12
    10f0:	fadd.4s	v10, v26, v10
    10f4:	fadd.4s	v9, v22, v9
    10f8:	ldp	q11, q12, [x12]
    10fc:	bit.16b	v12, v15, v0
    1100:	bit.16b	v11, v14, v1
    1104:	stp	q11, q12, [x12], #0x80
    1108:	fmul.4s	v11, v14, v14
    110c:	fmul.4s	v12, v15, v15
    1110:	fadd.4s	v12, v23, v12
    1114:	fadd.4s	v11, v27, v11
    1118:	bit.16b	v21, v4, v0
    111c:	bit.16b	v20, v5, v1
    1120:	bit.16b	v25, v6, v0
    1124:	bit.16b	v24, v31, v1
    1128:	bit.16b	v22, v9, v0
    112c:	add	x11, x11, #0x4
    1130:	bit.16b	v26, v10, v1
    1134:	add	x13, x13, #0x20
    1138:	bit.16b	v27, v11, v1
    113c:	bit.16b	v23, v12, v0
    1140:	cmp	x11, #0x1c
    1144:	b.hs	0x14f8
    1148:	fmov	w14, s2
    114c:	sshll.2d	v4, v1, #0x0
    1150:	dup.2d	v10, x13
    1154:	ldr	q5, [sp, #0x1f0]
    1158:	orr.16b	v5, v10, v5
    115c:	and.16b	v4, v4, v5
    1160:	add.2d	v4, v4, v19
    1164:	shl.2d	v4, v4, #0x2
    1168:	add.2d	v4, v16, v4
    116c:	movi.2d	v31, #0000000000000000
    1170:	movi.2d	v9, #0000000000000000
    1174:	tbz	w14, #0x0, 0x1180
    1178:	fmov	x15, d4
    117c:	ldr	s31, [x15]
    1180:	and	w14, w14, #0xff
    1184:	tbz	w14, #0x1, 0x1190
    1188:	mov.d	x15, v4[1]
    118c:	ld1.s	{ v31 }[1], [x15]
    1190:	ldr	q4, [sp, #0x200]
    1194:	orr.16b	v4, v10, v4
    1198:	and.16b	v4, v17, v4
    119c:	add.2d	v4, v4, v29
    11a0:	shl.2d	v4, v4, #0x2
    11a4:	add.2d	v4, v16, v4
    11a8:	tbz	w14, #0x2, 0x11b4
    11ac:	fmov	x15, d4
    11b0:	ld1.s	{ v31 }[2], [x15]
    11b4:	tbz	w14, #0x3, 0x11c0
    11b8:	mov.d	x15, v4[1]
    11bc:	ld1.s	{ v31 }[3], [x15]
    11c0:	sshll.2d	v4, v0, #0x0
    11c4:	ldr	q5, [sp, #0x210]
    11c8:	orr.16b	v5, v10, v5
    11cc:	and.16b	v4, v4, v5
    11d0:	add.2d	v4, v4, v30
    11d4:	shl.2d	v4, v4, #0x2
    11d8:	add.2d	v4, v16, v4
    11dc:	tbz	w14, #0x4, 0x11e8
    11e0:	fmov	x15, d4
    11e4:	ld1.s	{ v9 }[0], [x15]
    11e8:	tbz	w14, #0x5, 0x11f4
    11ec:	mov.d	x15, v4[1]
    11f0:	ld1.s	{ v9 }[1], [x15]
    11f4:	ldr	q4, [sp, #0x220]
    11f8:	orr.16b	v4, v10, v4
    11fc:	and.16b	v4, v18, v4
    1200:	add.2d	v4, v4, v28
    1204:	shl.2d	v4, v4, #0x2
    1208:	add.2d	v4, v16, v4
    120c:	tbz	w14, #0x6, 0x1218
    1210:	fmov	x15, d4
    1214:	ld1.s	{ v9 }[2], [x15]
    1218:	tbz	w14, #0x7, 0x1224
    121c:	mov.d	x14, v4[1]
    1220:	ld1.s	{ v9 }[3], [x14]
    1224:	fmov	w14, s2
    1228:	sshll.2d	v4, v1, #0x0
    122c:	ldp	q5, q10, [x12, #-0x60]
    1230:	bit.16b	v10, v9, v0
    1234:	bit.16b	v5, v31, v1
    1238:	stp	q5, q10, [x12, #-0x60]
    123c:	add	x15, x13, #0x8
    1240:	dup.2d	v12, x15
    1244:	ldr	q5, [sp, #0x1f0]
    1248:	orr.16b	v5, v12, v5
    124c:	and.16b	v4, v4, v5
    1250:	add.2d	v4, v4, v19
    1254:	shl.2d	v4, v4, #0x2
    1258:	add.2d	v4, v16, v4
    125c:	movi.2d	v10, #0000000000000000
    1260:	movi.2d	v11, #0000000000000000
    1264:	tbz	w14, #0x0, 0x1270
    1268:	fmov	x15, d4
    126c:	ldr	s10, [x15]
    1270:	and	w14, w14, #0xff
    1274:	tbz	w14, #0x1, 0x1280
    1278:	mov.d	x15, v4[1]
    127c:	ld1.s	{ v10 }[1], [x15]
    1280:	ldr	q4, [sp, #0x200]
    1284:	orr.16b	v4, v12, v4
    1288:	and.16b	v4, v17, v4
    128c:	add.2d	v4, v4, v29
    1290:	shl.2d	v4, v4, #0x2
    1294:	add.2d	v4, v16, v4
    1298:	tbz	w14, #0x2, 0x12a4
    129c:	fmov	x15, d4
    12a0:	ld1.s	{ v10 }[2], [x15]
    12a4:	tbz	w14, #0x3, 0x12b0
    12a8:	mov.d	x15, v4[1]
    12ac:	ld1.s	{ v10 }[3], [x15]
    12b0:	sshll.2d	v4, v0, #0x0
    12b4:	ldr	q5, [sp, #0x210]
    12b8:	orr.16b	v5, v12, v5
    12bc:	and.16b	v4, v4, v5
    12c0:	add.2d	v4, v4, v30
    12c4:	shl.2d	v4, v4, #0x2
    12c8:	add.2d	v4, v16, v4
    12cc:	tbz	w14, #0x4, 0x12d8
    12d0:	fmov	x15, d4
    12d4:	ld1.s	{ v11 }[0], [x15]
    12d8:	tbz	w14, #0x5, 0x12e4
    12dc:	mov.d	x15, v4[1]
    12e0:	ld1.s	{ v11 }[1], [x15]
    12e4:	ldr	q4, [sp, #0x220]
    12e8:	orr.16b	v4, v12, v4
    12ec:	and.16b	v4, v18, v4
    12f0:	add.2d	v4, v4, v28
    12f4:	shl.2d	v4, v4, #0x2
    12f8:	add.2d	v4, v16, v4
    12fc:	tbz	w14, #0x6, 0x1308
    1300:	fmov	x15, d4
    1304:	ld1.s	{ v11 }[2], [x15]
    1308:	tbz	w14, #0x7, 0x1314
    130c:	mov.d	x14, v4[1]
    1310:	ld1.s	{ v11 }[3], [x14]
    1314:	fmov	w14, s2
    1318:	sshll.2d	v4, v1, #0x0
    131c:	ldp	q5, q12, [x12, #-0x40]
    1320:	bit.16b	v12, v11, v0
    1324:	bit.16b	v5, v10, v1
    1328:	stp	q5, q12, [x12, #-0x40]
    132c:	add	x15, x13, #0x10
    1330:	dup.2d	v14, x15
    1334:	ldr	q5, [sp, #0x1f0]
    1338:	orr.16b	v5, v14, v5
    133c:	and.16b	v4, v4, v5
    1340:	add.2d	v4, v4, v19
    1344:	shl.2d	v4, v4, #0x2
    1348:	add.2d	v4, v16, v4
    134c:	movi.2d	v12, #0000000000000000
    1350:	movi.2d	v13, #0000000000000000
    1354:	tbz	w14, #0x0, 0x1360
    1358:	fmov	x15, d4
    135c:	ldr	s12, [x15]
    1360:	and	w14, w14, #0xff
    1364:	tbz	w14, #0x1, 0x1370
    1368:	mov.d	x15, v4[1]
    136c:	ld1.s	{ v12 }[1], [x15]
    1370:	ldr	q4, [sp, #0x200]
    1374:	orr.16b	v4, v14, v4
    1378:	and.16b	v4, v17, v4
    137c:	add.2d	v4, v4, v29
    1380:	shl.2d	v4, v4, #0x2
    1384:	add.2d	v4, v16, v4
    1388:	tbz	w14, #0x2, 0x1394
    138c:	fmov	x15, d4
    1390:	ld1.s	{ v12 }[2], [x15]
    1394:	tbz	w14, #0x3, 0x13a0
    1398:	mov.d	x15, v4[1]
    139c:	ld1.s	{ v12 }[3], [x15]
    13a0:	sshll.2d	v4, v0, #0x0
    13a4:	ldr	q5, [sp, #0x210]
    13a8:	orr.16b	v5, v14, v5
    13ac:	and.16b	v4, v4, v5
    13b0:	add.2d	v4, v4, v30
    13b4:	shl.2d	v4, v4, #0x2
    13b8:	add.2d	v4, v16, v4
    13bc:	tbz	w14, #0x4, 0x13c8
    13c0:	fmov	x15, d4
    13c4:	ld1.s	{ v13 }[0], [x15]
    13c8:	tbz	w14, #0x5, 0x13d4
    13cc:	mov.d	x15, v4[1]
    13d0:	ld1.s	{ v13 }[1], [x15]
    13d4:	ldr	q4, [sp, #0x220]
    13d8:	orr.16b	v4, v14, v4
    13dc:	and.16b	v4, v18, v4
    13e0:	add.2d	v4, v4, v28
    13e4:	shl.2d	v4, v4, #0x2
    13e8:	add.2d	v4, v16, v4
    13ec:	tbz	w14, #0x6, 0x13f8
    13f0:	fmov	x15, d4
    13f4:	ld1.s	{ v13 }[2], [x15]
    13f8:	tbz	w14, #0x7, 0x1404
    13fc:	mov.d	x14, v4[1]
    1400:	ld1.s	{ v13 }[3], [x14]
    1404:	fmov	w14, s2
    1408:	sshll.2d	v5, v1, #0x0
    140c:	ldp	q4, q14, [x12, #-0x20]
    1410:	bit.16b	v14, v13, v0
    1414:	bit.16b	v4, v12, v1
    1418:	stp	q4, q14, [x12, #-0x20]
    141c:	add	x15, x13, #0x18
    1420:	dup.2d	v4, x15
    1424:	ldr	q6, [sp, #0x1f0]
    1428:	orr.16b	v14, v4, v6
    142c:	and.16b	v5, v5, v14
    1430:	add.2d	v5, v5, v19
    1434:	shl.2d	v5, v5, #0x2
    1438:	add.2d	v5, v16, v5
    143c:	movi.2d	v14, #0000000000000000
    1440:	movi.2d	v15, #0000000000000000
    1444:	tbz	w14, #0x0, 0x1450
    1448:	fmov	x15, d5
    144c:	ldr	s14, [x15]
    1450:	and	w14, w14, #0xff
    1454:	tbz	w14, #0x1, 0x1460
    1458:	mov.d	x15, v5[1]
    145c:	ld1.s	{ v14 }[1], [x15]
    1460:	ldr	q5, [sp, #0x200]
    1464:	orr.16b	v5, v4, v5
    1468:	and.16b	v5, v17, v5
    146c:	add.2d	v5, v5, v29
    1470:	shl.2d	v5, v5, #0x2
    1474:	add.2d	v5, v16, v5
    1478:	tbz	w14, #0x2, 0x1484
    147c:	fmov	x15, d5
    1480:	ld1.s	{ v14 }[2], [x15]
    1484:	tbz	w14, #0x3, 0x1490
    1488:	mov.d	x15, v5[1]
    148c:	ld1.s	{ v14 }[3], [x15]
    1490:	sshll.2d	v5, v0, #0x0
    1494:	ldr	q6, [sp, #0x210]
    1498:	orr.16b	v6, v4, v6
    149c:	and.16b	v5, v5, v6
    14a0:	add.2d	v5, v5, v30
    14a4:	shl.2d	v5, v5, #0x2
    14a8:	add.2d	v5, v16, v5
    14ac:	tbz	w14, #0x4, 0x14b8
    14b0:	fmov	x15, d5
    14b4:	ld1.s	{ v15 }[0], [x15]
    14b8:	tbz	w14, #0x5, 0x14c4
    14bc:	mov.d	x15, v5[1]
    14c0:	ld1.s	{ v15 }[1], [x15]
    14c4:	ldr	q5, [sp, #0x220]
    14c8:	orr.16b	v4, v4, v5
    14cc:	and.16b	v4, v18, v4
    14d0:	add.2d	v4, v4, v28
    14d4:	shl.2d	v4, v4, #0x2
    14d8:	add.2d	v4, v16, v4
    14dc:	tbz	w14, #0x6, 0x14e8
    14e0:	fmov	x15, d4
    14e4:	ld1.s	{ v15 }[2], [x15]
    14e8:	tbz	w14, #0x7, 0x10c8
    14ec:	mov.d	x14, v4[1]
    14f0:	ld1.s	{ v15 }[3], [x14]
    14f4:	b	0x10c8
    14f8:	mov	x11, #0x0
    14fc:	b	0x1520
    1500:	add	x12, x19, x11
    1504:	ldp	q4, q5, [x12]
    1508:	bit.16b	v5, v17, v0
    150c:	bit.16b	v4, v16, v1
    1510:	stp	q4, q5, [x12]
    1514:	add	x11, x11, #0x20
    1518:	cmp	x11, #0x400
    151c:	b.eq	0x15b8
    1520:	fmov	w13, s2
    1524:	add	x12, x9, x11
    1528:	movi.2d	v16, #0000000000000000
    152c:	movi.2d	v17, #0000000000000000
    1530:	tbnz	w13, #0x0, 0x1558
    1534:	and	w13, w13, #0xff
    1538:	tbnz	w13, #0x1, 0x1564
    153c:	tbnz	w13, #0x2, 0x1570
    1540:	tbnz	w13, #0x3, 0x157c
    1544:	tbnz	w13, #0x4, 0x1588
    1548:	tbnz	w13, #0x5, 0x1594
    154c:	tbnz	w13, #0x6, 0x15a0
    1550:	tbz	w13, #0x7, 0x1500
    1554:	b	0x15ac
    1558:	ldr	s16, [x12]
    155c:	and	w13, w13, #0xff
    1560:	tbz	w13, #0x1, 0x153c
    1564:	add	x14, x12, #0x4
    1568:	ld1.s	{ v16 }[1], [x14]
    156c:	tbz	w13, #0x2, 0x1540
    1570:	add	x14, x12, #0x8
    1574:	ld1.s	{ v16 }[2], [x14]
    1578:	tbz	w13, #0x3, 0x1544
    157c:	add	x14, x12, #0xc
    1580:	ld1.s	{ v16 }[3], [x14]
    1584:	tbz	w13, #0x4, 0x1548
    1588:	add	x14, x12, #0x10
    158c:	ld1.s	{ v17 }[0], [x14]
    1590:	tbz	w13, #0x5, 0x154c
    1594:	add	x14, x12, #0x14
    1598:	ld1.s	{ v17 }[1], [x14]
    159c:	tbz	w13, #0x6, 0x1550
    15a0:	add	x14, x12, #0x18
    15a4:	ld1.s	{ v17 }[2], [x14]
    15a8:	tbz	w13, #0x7, 0x1500
    15ac:	add	x12, x12, #0x1c
    15b0:	ld1.s	{ v17 }[3], [x12]
    15b4:	b	0x1500
    15b8:	mov	x9, #0x0
    15bc:	xtn.8b	v18, v3
    15c0:	fadd.4s	v3, v21, v25
    15c4:	fadd.4s	v4, v20, v24
    15c8:	fadd.4s	v4, v4, v26
    15cc:	fadd.4s	v3, v3, v22
    15d0:	fadd.4s	v16, v3, v23
    15d4:	fadd.4s	v17, v4, v27
    15d8:	ldp	q4, q3, [sp, #0x1d0]
    15dc:	uzp1.4s	v4, v3, v4
    15e0:	ldr	q3, [sp, #0x1c0]
    15e4:	uzp1.4s	v3, v3, v7
    15e8:	movi.4s	v6, #0x1
    15ec:	eor.16b	v5, v4, v6
    15f0:	mov.s	w12, v5[1]
    15f4:	mov.s	w14, v5[2]
    15f8:	mov.s	w15, v5[3]
    15fc:	fmov	w11, s5
    1600:	add	x13, sp, #0x238
    1604:	bfxil	x13, x11, #0, #3
    1608:	str	d18, [sp, #0x238]
    160c:	ldrb	w16, [x13]
    1610:	and	x13, x11, #0x7
    1614:	umov.b	w11, v18[0]
    1618:	stp	q17, q16, [x24, #0x40]
    161c:	add	x17, sp, #0x300
    1620:	ldr	s5, [x17, x13, lsl #2]
    1624:	eor.16b	v20, v3, v6
    1628:	ands	w13, w11, #0x1
    162c:	tst	w13, w16
    1630:	fcsel	s5, s5, s8, ne
    1634:	add	x16, sp, #0x238
    1638:	bfxil	x16, x12, #0, #3
    163c:	ldrb	w16, [x16]
    1640:	and	x17, x12, #0x7
    1644:	umov.b	w12, v18[1]
    1648:	stp	q17, q16, [x24, #0x20]
    164c:	add	x0, sp, #0x2e0
    1650:	ldr	s6, [x0, x17, lsl #2]
    1654:	ands	w17, w12, #0x1
    1658:	tst	w17, w16
    165c:	fcsel	s6, s6, s8, ne
    1660:	add	x16, sp, #0x238
    1664:	bfxil	x16, x14, #0, #3
    1668:	ldrb	w16, [x16]
    166c:	and	x17, x14, #0x7
    1670:	umov.b	w14, v18[2]
    1674:	stp	q17, q16, [x24]
    1678:	ldr	s7, [x24, x17, lsl #2]
    167c:	ands	w17, w14, #0x1
    1680:	tst	w17, w16
    1684:	fcsel	s7, s7, s8, ne
    1688:	add	x16, sp, #0x238
    168c:	bfxil	x16, x15, #0, #3
    1690:	ldrb	w16, [x16]
    1694:	and	x17, x15, #0x7
    1698:	umov.b	w15, v18[3]
    169c:	stp	q17, q16, [sp, #0x2a0]
    16a0:	add	x0, sp, #0x2a0
    16a4:	ldr	s21, [x0, x17, lsl #2]
    16a8:	ands	w17, w15, #0x1
    16ac:	tst	w17, w16
    16b0:	mov.s	w17, v20[1]
    16b4:	mov.s	w0, v20[2]
    16b8:	mov.s	w1, v20[3]
    16bc:	fcsel	s21, s21, s8, ne
    16c0:	fmov	w16, s20
    16c4:	and	x2, x16, #0x7
    16c8:	add	x3, sp, #0x238
    16cc:	bfxil	x3, x16, #0, #3
    16d0:	ldrb	w3, [x3]
    16d4:	umov.b	w16, v18[4]
    16d8:	stp	q17, q16, [x24, #0xc0]
    16dc:	add	x4, sp, #0x380
    16e0:	ldr	s20, [x4, x2, lsl #2]
    16e4:	and	w2, w16, w3
    16e8:	tst	w2, #0x1
    16ec:	add	x2, sp, #0x238
    16f0:	bfxil	x2, x17, #0, #3
    16f4:	ldrb	w2, [x2]
    16f8:	and	x3, x17, #0x7
    16fc:	umov.b	w17, v18[5]
    1700:	stp	q17, q16, [x24, #0xa0]
    1704:	add	x4, sp, #0x360
    1708:	ldr	s22, [x4, x3, lsl #2]
    170c:	fcsel	s20, s20, s8, ne
    1710:	ands	w3, w17, #0x1
    1714:	tst	w3, w2
    1718:	fcsel	s22, s22, s8, ne
    171c:	add	x2, sp, #0x238
    1720:	bfxil	x2, x0, #0, #3
    1724:	ldrb	w2, [x2]
    1728:	and	x3, x0, #0x7
    172c:	umov.b	w0, v18[6]
    1730:	stp	q17, q16, [x24, #0x80]
    1734:	add	x4, sp, #0x340
    1738:	ldr	s23, [x4, x3, lsl #2]
    173c:	ands	w3, w0, #0x1
    1740:	tst	w3, w2
    1744:	fcsel	s23, s23, s8, ne
    1748:	add	x2, sp, #0x238
    174c:	bfxil	x2, x1, #0, #3
    1750:	ldrb	w2, [x2]
    1754:	and	x3, x1, #0x7
    1758:	umov.b	w1, v18[7]
    175c:	stp	q17, q16, [x24, #0x60]
    1760:	add	x4, sp, #0x320
    1764:	ldr	s18, [x4, x3, lsl #2]
    1768:	ands	w3, w1, #0x1
    176c:	tst	w3, w2
    1770:	fcsel	s18, s18, s8, ne
    1774:	mov.s	v5[1], v6[0]
    1778:	mov.s	v5[2], v7[0]
    177c:	mov.s	v5[3], v21[0]
    1780:	mov.s	v20[1], v22[0]
    1784:	mov.s	v20[2], v23[0]
    1788:	mov.s	v20[3], v18[0]
    178c:	fadd.4s	v6, v16, v20
    1790:	fadd.4s	v5, v17, v5
    1794:	movi.4s	v7, #0x2
    1798:	eor.16b	v4, v4, v7
    179c:	fmov	w2, s4
    17a0:	add	x3, sp, #0x238
    17a4:	bfxil	x3, x2, #0, #3
    17a8:	ldrb	w3, [x3]
    17ac:	and	x2, x2, #0x7
    17b0:	stp	q5, q6, [sp, #0x280]
    17b4:	add	x4, sp, #0x280
    17b8:	ldr	s4, [x4, x2, lsl #2]
    17bc:	eor.16b	v3, v3, v7
    17c0:	tst	w13, w3
    17c4:	fcsel	s4, s4, s8, ne
    17c8:	fmov	w2, s3
    17cc:	add	x3, sp, #0x238
    17d0:	bfxil	x3, x2, #0, #3
    17d4:	and	x2, x2, #0x7
    17d8:	ldrb	w3, [x3]
    17dc:	stp	q5, q6, [sp, #0x260]
    17e0:	add	x4, sp, #0x260
    17e4:	ldr	s3, [x4, x2, lsl #2]
    17e8:	and	w2, w16, w3
    17ec:	tst	w2, #0x1
    17f0:	fcsel	s3, s3, s8, ne
    17f4:	fadd.4s	v3, v6, v3
    17f8:	tst	w13, w16
    17fc:	fcsel	s3, s3, s8, ne
    1800:	ands	w11, w11, #0x1
    1804:	fadd.4s	v4, v5, v4
    1808:	fadd	s3, s4, s3
    180c:	fcsel	s4, s3, s8, ne
    1810:	tst	w12, #0x1
    1814:	fcsel	s5, s4, s8, ne
    1818:	tst	w14, #0x1
    181c:	fcsel	s6, s4, s8, ne
    1820:	tst	w15, #0x1
    1824:	fcsel	s7, s4, s8, ne
    1828:	tst	w11, w16
    182c:	fcsel	s3, s3, s8, ne
    1830:	tst	w17, #0x1
    1834:	fcsel	s16, s4, s8, ne
    1838:	tst	w0, #0x1
    183c:	fcsel	s17, s4, s8, ne
    1840:	tst	w1, #0x1
    1844:	fcsel	s18, s4, s8, ne
    1848:	mov.s	v4[1], v5[0]
    184c:	mov.s	v4[2], v6[0]
    1850:	mov.s	v4[3], v7[0]
    1854:	mov.s	v3[1], v16[0]
    1858:	mov.s	v3[2], v17[0]
    185c:	mov.s	v3[3], v18[0]
    1860:	rbit	w10, w10
    1864:	clz	w10, w10
    1868:	stp	q4, q3, [sp, #0x240]
    186c:	and	x10, x10, #0x7
    1870:	add	x11, sp, #0x240
    1874:	ldr	s3, [x11, x10, lsl #2]
    1878:	fadd	s3, s3, s8
    187c:	mov	w10, #0x3b800000
    1880:	fmov	s4, w10
    1884:	fmul	s3, s3, s4
    1888:	mov	w10, #0xc5ac
    188c:	movk	w10, #0x3727, lsl #16
    1890:	fmov	s4, w10
    1894:	fadd	s3, s3, s4
    1898:	fsqrt	s3, s3
    189c:	dup.4s	v3, v3[0]
    18a0:	fmov	x10, d19
    18a4:	add	x8, x8, x10, lsl #2
    18a8:	b	0x18b8
    18ac:	add	x9, x9, #0x20
    18b0:	cmp	x9, #0x400
    18b4:	b.eq	0x160
    18b8:	fmov	w11, s2
    18bc:	add	x10, x27, x9
    18c0:	ldp	q5, q4, [x10]
    18c4:	and.16b	v5, v1, v5
    18c8:	fdiv.4s	v6, v5, v3
    18cc:	add	x10, x19, x9
    18d0:	ldp	q7, q5, [x10]
    18d4:	and.16b	v7, v1, v7
    18d8:	fmul.4s	v6, v6, v7
    18dc:	add	x10, x8, x9
    18e0:	tbnz	w11, #0x0, 0x1918
    18e4:	and	w11, w11, #0xff
    18e8:	tbnz	w11, #0x1, 0x1924
    18ec:	tbnz	w11, #0x2, 0x1930
    18f0:	tbnz	w11, #0x3, 0x193c
    18f4:	and.16b	v4, v0, v4
    18f8:	fdiv.4s	v4, v4, v3
    18fc:	and.16b	v5, v0, v5
    1900:	fmul.4s	v4, v4, v5
    1904:	tbnz	w11, #0x4, 0x1958
    1908:	tbnz	w11, #0x5, 0x1960
    190c:	tbnz	w11, #0x6, 0x196c
    1910:	tbz	w11, #0x7, 0x18ac
    1914:	b	0x1978
    1918:	str	s6, [x10]
    191c:	and	w11, w11, #0xff
    1920:	tbz	w11, #0x1, 0x18ec
    1924:	add	x12, x10, #0x4
    1928:	st1.s	{ v6 }[1], [x12]
    192c:	tbz	w11, #0x2, 0x18f0
    1930:	add	x12, x10, #0x8
    1934:	st1.s	{ v6 }[2], [x12]
    1938:	tbz	w11, #0x3, 0x18f4
    193c:	add	x12, x10, #0xc
    1940:	st1.s	{ v6 }[3], [x12]
    1944:	and.16b	v4, v0, v4
    1948:	fdiv.4s	v4, v4, v3
    194c:	and.16b	v5, v0, v5
    1950:	fmul.4s	v4, v4, v5
    1954:	tbz	w11, #0x4, 0x1908
    1958:	str	s4, [x10, #0x10]
    195c:	tbz	w11, #0x5, 0x190c
    1960:	add	x12, x10, #0x14
    1964:	st1.s	{ v4 }[1], [x12]
    1968:	tbz	w11, #0x6, 0x1910
    196c:	add	x12, x10, #0x18
    1970:	st1.s	{ v4 }[2], [x12]
    1974:	tbz	w11, #0x7, 0x18ac
    1978:	add	x10, x10, #0x1c
    197c:	st1.s	{ v4 }[3], [x10]
    1980:	b	0x18ac
    1984:	ldr	x9, [sp, #0x10]
    1988:	stp	w14, w13, [x9]
    198c:	str	w12, [x9, #0x8]
    1990:	mov	w8, #0x1f8
    1994:	str	w8, [x9, #0x24]
    1998:	add	sp, sp, #0xbb0
    199c:	ldp	x29, x30, [sp, #0x90]
    19a0:	ldp	x20, x19, [sp, #0x80]
    19a4:	ldp	x22, x21, [sp, #0x70]
    19a8:	ldp	x24, x23, [sp, #0x60]
    19ac:	ldp	x26, x25, [sp, #0x50]
    19b0:	ldp	x28, x27, [sp, #0x40]
    19b4:	ldp	d9, d8, [sp, #0x30]
    19b8:	ldp	d11, d10, [sp, #0x20]
    19bc:	ldp	d13, d12, [sp, #0x10]
    19c0:	ldp	d15, d14, [sp], #0xa0
    19c4:	ret

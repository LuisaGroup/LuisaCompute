/tmp/luisa-full-packet.UEezjO/capture/rmsnorm-64x256-r0-l8-f0-p1/object/tile_xir_w8_63768_1788856226926704_0.o:
(__TEXT,__text) section
_llm_rows.full_packet:
       0:	stp	x24, x23, [sp, #-0x40]!
       4:	stp	x22, x21, [sp, #0x10]
       8:	stp	x20, x19, [sp, #0x20]
       c:	stp	x29, x30, [sp, #0x30]
      10:	sub	sp, sp, #0xc00
      14:	ldr	x8, [x0]
      18:	ldr	x19, [x0, #0x10]
      1c:	ldr	x21, [x0, #0x30]
      20:	ldr	w9, [x1]
      24:	ldr	w10, [x1, #0x24]
      28:	add	w9, w10, w9, lsl #9
      2c:	lsr	w9, w9, #3
      30:	ubfiz	x22, x9, #10, #32
      34:	add	x20, sp, #0x800
      38:	add	x0, sp, #0x800
      3c:	add	x1, x8, x22
      40:	mov	w2, #0x400
      44:	bl	_memcpy
      48:	ldr	q0, [sp, #0x800]
      4c:	ldr	q1, [sp, #0x810]
      50:	fmul.4s	v2, v1, v1
      54:	fmul.4s	v0, v0, v0
      58:	str	q0, [sp, #0xa0]
      5c:	ldr	q0, [sp, #0x820]
      60:	ldr	q1, [sp, #0x830]
      64:	fmul.4s	v1, v1, v1
      68:	str	q1, [sp, #0x120]
      6c:	fmul.4s	v0, v0, v0
      70:	str	q0, [sp, #0xc0]
      74:	ldr	q0, [sp, #0x850]
      78:	ldr	q1, [sp, #0x840]
      7c:	fmul.4s	v3, v1, v1
      80:	fmul.4s	v0, v0, v0
      84:	str	q0, [sp, #0xe0]
      88:	ldr	q0, [sp, #0x860]
      8c:	ldr	q1, [sp, #0x870]
      90:	fmul.4s	v1, v1, v1
      94:	stp	q3, q1, [sp, #0x140]
      98:	fmul.4s	v0, v0, v0
      9c:	stp	q0, q2, [sp, #0xf0]
      a0:	ldr	q1, [sp, #0x880]
      a4:	ldr	q0, [sp, #0x890]
      a8:	stp	q1, q0, [sp]
      ac:	ldr	q1, [sp, #0x8a0]
      b0:	ldr	q0, [sp, #0x8b0]
      b4:	stp	q1, q0, [sp, #0x20]
      b8:	ldr	q1, [sp, #0x8d0]
      bc:	ldr	q0, [sp, #0x8c0]
      c0:	stp	q1, q0, [sp, #0x40]
      c4:	ldr	q1, [sp, #0x8e0]
      c8:	ldr	q0, [sp, #0x8f0]
      cc:	stp	q1, q0, [sp, #0x60]
      d0:	ldr	q1, [sp, #0x910]
      d4:	ldr	q0, [sp, #0x900]
      d8:	stp	q1, q0, [sp, #0x80]
      dc:	ldr	q0, [sp, #0x930]
      e0:	str	q0, [sp, #0xb0]
      e4:	ldr	q0, [sp, #0x920]
      e8:	str	q0, [sp, #0xd0]
      ec:	ldr	q0, [sp, #0x940]
      f0:	str	q0, [sp, #0x110]
      f4:	ldr	q0, [sp, #0x950]
      f8:	str	q0, [sp, #0x130]
      fc:	ldr	q1, [sp, #0x970]
     100:	ldr	q0, [sp, #0x960]
     104:	stp	q1, q0, [sp, #0x160]
     108:	ldr	q1, [sp, #0x980]
     10c:	ldr	q0, [sp, #0x990]
     110:	stp	q1, q0, [sp, #0x180]
     114:	ldr	q1, [sp, #0x9a0]
     118:	ldr	q0, [sp, #0x9b0]
     11c:	stp	q1, q0, [sp, #0x1a0]
     120:	ldr	q1, [sp, #0x9d0]
     124:	ldr	q0, [sp, #0x9c0]
     128:	stp	q1, q0, [sp, #0x1c0]
     12c:	ldr	q1, [sp, #0x9e0]
     130:	ldr	q0, [sp, #0x9f0]
     134:	stp	q1, q0, [sp, #0x1e0]
     138:	ldr	q1, [sp, #0xa10]
     13c:	ldr	q0, [sp, #0xa00]
     140:	stp	q1, q0, [sp, #0x200]
     144:	ldr	q1, [sp, #0xa30]
     148:	ldr	q0, [sp, #0xa20]
     14c:	stp	q1, q0, [sp, #0x220]
     150:	ldr	q1, [sp, #0xa40]
     154:	ldr	q0, [sp, #0xa50]
     158:	stp	q1, q0, [sp, #0x240]
     15c:	ldr	q1, [sp, #0xa70]
     160:	ldr	q0, [sp, #0xa60]
     164:	stp	q1, q0, [sp, #0x260]
     168:	ldr	q1, [sp, #0xa80]
     16c:	ldr	q0, [sp, #0xa90]
     170:	stp	q1, q0, [sp, #0x280]
     174:	ldr	q1, [sp, #0xaa0]
     178:	ldr	q0, [sp, #0xab0]
     17c:	stp	q1, q0, [sp, #0x2a0]
     180:	ldr	q1, [sp, #0xad0]
     184:	ldr	q0, [sp, #0xac0]
     188:	stp	q1, q0, [sp, #0x2c0]
     18c:	ldr	q1, [sp, #0xae0]
     190:	ldr	q0, [sp, #0xaf0]
     194:	stp	q1, q0, [sp, #0x2e0]
     198:	ldr	q1, [sp, #0xb10]
     19c:	ldr	q0, [sp, #0xb00]
     1a0:	stp	q1, q0, [sp, #0x300]
     1a4:	ldr	q1, [sp, #0xb30]
     1a8:	ldr	q0, [sp, #0xb20]
     1ac:	stp	q1, q0, [sp, #0x320]
     1b0:	ldr	q1, [sp, #0xb40]
     1b4:	ldr	q0, [sp, #0xb50]
     1b8:	stp	q1, q0, [sp, #0x340]
     1bc:	ldr	q1, [sp, #0xb70]
     1c0:	ldr	q0, [sp, #0xb60]
     1c4:	stp	q1, q0, [sp, #0x360]
     1c8:	ldr	q1, [sp, #0xb80]
     1cc:	ldr	q0, [sp, #0xb90]
     1d0:	stp	q1, q0, [sp, #0x380]
     1d4:	ldr	q1, [sp, #0xba0]
     1d8:	ldr	q0, [sp, #0xbb0]
     1dc:	stp	q1, q0, [sp, #0x3a0]
     1e0:	ldr	q1, [sp, #0xbd0]
     1e4:	ldr	q0, [sp, #0xbc0]
     1e8:	stp	q1, q0, [sp, #0x3c0]
     1ec:	ldr	q1, [sp, #0xbe0]
     1f0:	ldr	q0, [sp, #0xbf0]
     1f4:	stp	q1, q0, [sp, #0x3e0]
     1f8:	add	x23, sp, #0x400
     1fc:	add	x0, sp, #0x400
     200:	mov	x1, x19
     204:	mov	w2, #0x400
     208:	bl	_memcpy
     20c:	mov	x8, #0x0
     210:	ldr	q0, [sp]
     214:	fmul.4s	v0, v0, v0
     218:	ldr	q1, [sp, #0xa0]
     21c:	fadd.4s	v0, v1, v0
     220:	ldr	q1, [sp, #0x10]
     224:	fmul.4s	v1, v1, v1
     228:	ldp	q7, q2, [sp, #0xf0]
     22c:	fadd.4s	v1, v2, v1
     230:	ldr	q2, [sp, #0x20]
     234:	fmul.4s	v2, v2, v2
     238:	ldr	q3, [sp, #0xc0]
     23c:	fadd.4s	v2, v3, v2
     240:	ldr	q3, [sp, #0x30]
     244:	fmul.4s	v3, v3, v3
     248:	ldr	q4, [sp, #0x120]
     24c:	fadd.4s	v3, v4, v3
     250:	ldr	q4, [sp, #0x40]
     254:	fmul.4s	v4, v4, v4
     258:	ldr	q5, [sp, #0xe0]
     25c:	fadd.4s	v4, v5, v4
     260:	ldr	q5, [sp, #0x50]
     264:	fmul.4s	v5, v5, v5
     268:	ldp	q6, q16, [sp, #0x140]
     26c:	fadd.4s	v5, v6, v5
     270:	ldr	q6, [sp, #0x60]
     274:	fmul.4s	v6, v6, v6
     278:	fadd.4s	v6, v7, v6
     27c:	ldr	q7, [sp, #0x70]
     280:	fmul.4s	v7, v7, v7
     284:	fadd.4s	v7, v16, v7
     288:	ldr	q16, [sp, #0x80]
     28c:	fmul.4s	v16, v16, v16
     290:	fadd.4s	v1, v1, v16
     294:	ldr	q16, [sp, #0x90]
     298:	fmul.4s	v16, v16, v16
     29c:	fadd.4s	v0, v0, v16
     2a0:	ldr	q16, [sp, #0xb0]
     2a4:	fmul.4s	v16, v16, v16
     2a8:	fadd.4s	v3, v3, v16
     2ac:	ldr	q16, [sp, #0xd0]
     2b0:	fmul.4s	v16, v16, v16
     2b4:	fadd.4s	v2, v2, v16
     2b8:	ldr	q16, [sp, #0x110]
     2bc:	fmul.4s	v16, v16, v16
     2c0:	fadd.4s	v5, v5, v16
     2c4:	ldr	q16, [sp, #0x130]
     2c8:	fmul.4s	v16, v16, v16
     2cc:	fadd.4s	v4, v4, v16
     2d0:	ldr	q16, [sp, #0x160]
     2d4:	fmul.4s	v16, v16, v16
     2d8:	fadd.4s	v7, v7, v16
     2dc:	ldr	q16, [sp, #0x170]
     2e0:	fmul.4s	v16, v16, v16
     2e4:	fadd.4s	v6, v6, v16
     2e8:	ldr	q16, [sp, #0x180]
     2ec:	fmul.4s	v16, v16, v16
     2f0:	fadd.4s	v0, v0, v16
     2f4:	ldr	q16, [sp, #0x190]
     2f8:	fmul.4s	v16, v16, v16
     2fc:	fadd.4s	v1, v1, v16
     300:	ldr	q16, [sp, #0x1a0]
     304:	fmul.4s	v16, v16, v16
     308:	fadd.4s	v2, v2, v16
     30c:	ldr	q16, [sp, #0x1b0]
     310:	fmul.4s	v16, v16, v16
     314:	fadd.4s	v3, v3, v16
     318:	ldr	q16, [sp, #0x1c0]
     31c:	fmul.4s	v16, v16, v16
     320:	fadd.4s	v4, v4, v16
     324:	ldr	q16, [sp, #0x1d0]
     328:	fmul.4s	v16, v16, v16
     32c:	fadd.4s	v5, v5, v16
     330:	ldr	q16, [sp, #0x1e0]
     334:	fmul.4s	v16, v16, v16
     338:	fadd.4s	v6, v6, v16
     33c:	ldr	q16, [sp, #0x1f0]
     340:	fmul.4s	v16, v16, v16
     344:	fadd.4s	v7, v7, v16
     348:	ldr	q16, [sp, #0x200]
     34c:	fmul.4s	v16, v16, v16
     350:	fadd.4s	v1, v1, v16
     354:	ldr	q16, [sp, #0x210]
     358:	fmul.4s	v16, v16, v16
     35c:	fadd.4s	v0, v0, v16
     360:	ldr	q16, [sp, #0x220]
     364:	fmul.4s	v16, v16, v16
     368:	fadd.4s	v3, v3, v16
     36c:	ldr	q16, [sp, #0x230]
     370:	fmul.4s	v16, v16, v16
     374:	fadd.4s	v2, v2, v16
     378:	ldr	q16, [sp, #0x240]
     37c:	fmul.4s	v16, v16, v16
     380:	fadd.4s	v5, v5, v16
     384:	ldr	q16, [sp, #0x250]
     388:	fmul.4s	v16, v16, v16
     38c:	fadd.4s	v4, v4, v16
     390:	ldr	q16, [sp, #0x260]
     394:	fmul.4s	v16, v16, v16
     398:	fadd.4s	v7, v7, v16
     39c:	ldr	q16, [sp, #0x270]
     3a0:	fmul.4s	v16, v16, v16
     3a4:	fadd.4s	v6, v6, v16
     3a8:	ldr	q16, [sp, #0x280]
     3ac:	fmul.4s	v16, v16, v16
     3b0:	fadd.4s	v0, v0, v16
     3b4:	ldr	q16, [sp, #0x290]
     3b8:	fmul.4s	v16, v16, v16
     3bc:	fadd.4s	v1, v1, v16
     3c0:	ldr	q16, [sp, #0x2a0]
     3c4:	fmul.4s	v16, v16, v16
     3c8:	fadd.4s	v2, v2, v16
     3cc:	ldr	q16, [sp, #0x2b0]
     3d0:	fmul.4s	v16, v16, v16
     3d4:	fadd.4s	v3, v3, v16
     3d8:	ldr	q16, [sp, #0x2c0]
     3dc:	fmul.4s	v16, v16, v16
     3e0:	fadd.4s	v4, v4, v16
     3e4:	ldr	q16, [sp, #0x2d0]
     3e8:	fmul.4s	v16, v16, v16
     3ec:	fadd.4s	v5, v5, v16
     3f0:	ldr	q16, [sp, #0x2e0]
     3f4:	fmul.4s	v16, v16, v16
     3f8:	fadd.4s	v6, v6, v16
     3fc:	ldr	q16, [sp, #0x2f0]
     400:	fmul.4s	v16, v16, v16
     404:	fadd.4s	v7, v7, v16
     408:	ldr	q16, [sp, #0x300]
     40c:	fmul.4s	v16, v16, v16
     410:	fadd.4s	v1, v1, v16
     414:	ldr	q16, [sp, #0x310]
     418:	fmul.4s	v16, v16, v16
     41c:	fadd.4s	v0, v0, v16
     420:	ldr	q16, [sp, #0x320]
     424:	fmul.4s	v16, v16, v16
     428:	fadd.4s	v3, v3, v16
     42c:	ldr	q16, [sp, #0x330]
     430:	fmul.4s	v16, v16, v16
     434:	fadd.4s	v2, v2, v16
     438:	ldr	q16, [sp, #0x340]
     43c:	fmul.4s	v16, v16, v16
     440:	fadd.4s	v5, v5, v16
     444:	ldr	q16, [sp, #0x350]
     448:	fmul.4s	v16, v16, v16
     44c:	fadd.4s	v4, v4, v16
     450:	ldr	q16, [sp, #0x360]
     454:	fmul.4s	v16, v16, v16
     458:	fadd.4s	v7, v7, v16
     45c:	ldr	q16, [sp, #0x370]
     460:	fmul.4s	v16, v16, v16
     464:	fadd.4s	v6, v6, v16
     468:	ldr	q16, [sp, #0x380]
     46c:	fmul.4s	v16, v16, v16
     470:	fadd.4s	v0, v0, v16
     474:	ldr	q16, [sp, #0x390]
     478:	fmul.4s	v16, v16, v16
     47c:	fadd.4s	v1, v1, v16
     480:	ldr	q16, [sp, #0x3a0]
     484:	fmul.4s	v16, v16, v16
     488:	fadd.4s	v2, v2, v16
     48c:	ldr	q16, [sp, #0x3b0]
     490:	fmul.4s	v16, v16, v16
     494:	fadd.4s	v3, v3, v16
     498:	ldr	q16, [sp, #0x3c0]
     49c:	fmul.4s	v16, v16, v16
     4a0:	fadd.4s	v4, v4, v16
     4a4:	ldr	q16, [sp, #0x3d0]
     4a8:	fmul.4s	v16, v16, v16
     4ac:	fadd.4s	v5, v5, v16
     4b0:	ldr	q16, [sp, #0x3e0]
     4b4:	fmul.4s	v16, v16, v16
     4b8:	fadd.4s	v6, v6, v16
     4bc:	ldr	q16, [sp, #0x3f0]
     4c0:	fmul.4s	v16, v16, v16
     4c4:	fadd.4s	v7, v7, v16
     4c8:	fadd.4s	v1, v1, v3
     4cc:	fadd.4s	v0, v0, v2
     4d0:	fadd.4s	v0, v0, v5
     4d4:	fadd.4s	v1, v1, v4
     4d8:	fadd.4s	v1, v1, v7
     4dc:	fadd.4s	v0, v0, v6
     4e0:	rev64.4s	v2, v0
     4e4:	rev64.4s	v3, v1
     4e8:	fadd.4s	v1, v1, v3
     4ec:	dup.4s	v3, v1[2]
     4f0:	fadd.4s	v0, v0, v2
     4f4:	fadd.4s	v1, v1, v3
     4f8:	dup.4s	v2, v0[2]
     4fc:	fadd.4s	v0, v0, v2
     500:	fadd.4s	v0, v0, v1
     504:	movi	d1, #0000000000000000
     508:	fadd	s0, s0, s1
     50c:	mov	w9, #0x3b800000
     510:	fmov	s1, w9
     514:	fmul	s0, s0, s1
     518:	mov	w9, #0xc5ac
     51c:	movk	w9, #0x3727, lsl #16
     520:	fmov	s1, w9
     524:	fadd	s0, s0, s1
     528:	fsqrt	s0, s0
     52c:	dup.4s	v0, v0[0]
     530:	add	x9, x21, x22
     534:	add	x10, x20, x8
     538:	ldp	q1, q2, [x10]
     53c:	fdiv.4s	v2, v2, v0
     540:	fdiv.4s	v1, v1, v0
     544:	add	x10, x23, x8
     548:	ldp	q4, q3, [x10]
     54c:	fmul.4s	v1, v1, v4
     550:	fmul.4s	v2, v2, v3
     554:	add	x10, x9, x8
     558:	stp	q1, q2, [x10]
     55c:	add	x8, x8, #0x20
     560:	cmp	x8, #0x400
     564:	b.ne	0x534
     568:	add	sp, sp, #0xc00
     56c:	ldp	x29, x30, [sp, #0x30]
     570:	ldp	x20, x19, [sp, #0x20]
     574:	ldp	x22, x21, [sp, #0x10]
     578:	ldp	x24, x23, [sp], #0x40
     57c:	ret
_llm_rows.packet_batch.blocks:
     580:	cbz	w3, 0xda4
     584:	stp	d9, d8, [sp, #-0x70]!
     588:	stp	x28, x27, [sp, #0x10]
     58c:	stp	x26, x25, [sp, #0x20]
     590:	stp	x24, x23, [sp, #0x30]
     594:	stp	x22, x21, [sp, #0x40]
     598:	stp	x20, x19, [sp, #0x50]
     59c:	stp	x29, x30, [sp, #0x60]
     5a0:	sub	sp, sp, #0x9e0
     5a4:	mov	x28, x3
     5a8:	mov	x20, x2
     5ac:	mov	x21, x0
     5b0:	mov	w22, #0x0
     5b4:	ldp	w27, w24, [x2, #0x2c]
     5b8:	ldp	w26, w25, [x2]
     5bc:	add	x8, sp, #0x5e0
     5c0:	add	x8, x8, #0xe0
     5c4:	str	x8, [sp, #0x20]
     5c8:	mov	w23, #0x200
     5cc:	movi	d8, #0000000000000000
     5d0:	ldp	w11, w8, [x2, #0x8]
     5d4:	str	x8, [sp, #0x58]
     5d8:	adrp	x8, lCPI1_0@PAGE
     5dc:	ldr	q0, [x8, lCPI1_0@PAGEOFF]
     5e0:	str	q0, [sp, #0x10]
     5e4:	adrp	x8, lCPI1_1@PAGE
     5e8:	ldr	q0, [x8, lCPI1_1@PAGEOFF]
     5ec:	str	q0, [sp, #0x40]
     5f0:	adrp	x8, lCPI1_2@PAGE
     5f4:	ldr	q0, [x8, lCPI1_2@PAGEOFF]
     5f8:	str	q0, [sp, #0x30]
     5fc:	str	w3, [sp, #0x2c]
     600:	b	0x648
     604:	mov	w8, #0x1f8
     608:	str	w8, [x20, #0x24]
     60c:	ldr	w28, [sp, #0x2c]
     610:	add	w8, w26, #0x1
     614:	cmp	w8, w27
     618:	cset	w8, eq
     61c:	csinc	w26, wzr, w26, eq
     620:	cinc	w9, w25, eq
     624:	cmp	w9, w24
     628:	cset	w10, eq
     62c:	ands	w8, w8, w10
     630:	csel	w25, wzr, w9, ne
     634:	ldr	w11, [sp, #0x60]
     638:	add	w11, w11, w8
     63c:	add	w22, w22, #0x1
     640:	cmp	w22, w28
     644:	b.eq	0xd84
     648:	ubfiz	x8, x26, #9, #32
     64c:	ldr	x12, [sp, #0x58]
     650:	cmp	x8, x12
     654:	csel	x9, x8, xzr, ls
     658:	subs	x10, x12, x9
     65c:	cmp	x10, #0x200
     660:	csel	x10, x10, x23, lo
     664:	cmp	x12, x9
     668:	stp	w26, w25, [x20]
     66c:	str	w11, [sp, #0x60]
     670:	str	w11, [x20, #0x8]
     674:	ccmp	x8, x12, #0x2, hi
     678:	csel	x19, x10, xzr, ls
     67c:	cmp	x19, #0x200
     680:	b.lo	0x6a8
     684:	mov	w19, #0x0
     688:	str	w19, [x20, #0x24]
     68c:	mov	x0, x21
     690:	mov	x1, x20
     694:	bl	_llm_rows.full_packet
     698:	add	w19, w19, #0x8
     69c:	cmp	w19, #0x200
     6a0:	b.ne	0x688
     6a4:	b	0x610
     6a8:	mov	x23, x26
     6ac:	mov	x26, x25
     6b0:	mov	x25, x22
     6b4:	mov	x22, x24
     6b8:	mov	x24, x27
     6bc:	lsr	x8, x19, #3
     6c0:	str	x8, [sp, #0x50]
     6c4:	cmp	x19, #0x8
     6c8:	b.lo	0x6f4
     6cc:	mov	w27, #0x0
     6d0:	ldr	x8, [sp, #0x50]
     6d4:	lsl	w28, w8, #3
     6d8:	str	w27, [x20, #0x24]
     6dc:	mov	x0, x21
     6e0:	mov	x1, x20
     6e4:	bl	_llm_rows.full_packet
     6e8:	add	w27, w27, #0x8
     6ec:	cmp	w28, w27
     6f0:	b.ne	0x6d8
     6f4:	and	w8, w19, #0x7
     6f8:	mov	x27, x24
     6fc:	mov	x24, x22
     700:	mov	x22, x25
     704:	mov	x25, x26
     708:	mov	x26, x23
     70c:	mov	w23, #0x200
     710:	cbz	w8, 0x604
     714:	dup.4s	v1, w8
     718:	ldp	q0, q2, [sp, #0x30]
     71c:	cmhi.4s	v0, v1, v0
     720:	cmhi.4s	v1, v1, v2
     724:	uzp1.8h	v3, v1, v0
     728:	umaxv.8h	h2, v3
     72c:	fmov	w8, s2
     730:	add	x5, sp, #0x5e0
     734:	add	x6, sp, #0x1e0
     738:	tbz	w8, #0x0, 0x604
     73c:	mov	x12, #0x0
     740:	ldr	x11, [x21, #0x10]
     744:	ldr	x8, [x21, #0x30]
     748:	ldr	q2, [sp, #0x10]
     74c:	and.16b	v2, v3, v2
     750:	addv.8h	h2, v2
     754:	fmov	w9, s2
     758:	and	w10, w9, #0xff
     75c:	ldr	x13, [x21]
     760:	ubfiz	w9, w26, #6, #23
     764:	ldr	x14, [sp, #0x50]
     768:	orr	w9, w9, w14
     76c:	fmov	s4, w9
     770:	and.16b	v4, v1, v4
     774:	fmov	w9, s4
     778:	ubfiz	x9, x9, #10, #32
     77c:	add	x13, x13, x9
     780:	fmov	w14, s2
     784:	b	0x7a8
     788:	add	x15, x5, x12
     78c:	ldp	q6, q7, [x15]
     790:	bif.16b	v5, v7, v0
     794:	bif.16b	v4, v6, v1
     798:	stp	q4, q5, [x15]
     79c:	add	x12, x12, #0x20
     7a0:	cmp	x12, #0x400
     7a4:	b.eq	0x83c
     7a8:	add	x15, x13, x12
     7ac:	movi.2d	v4, #0000000000000000
     7b0:	movi.2d	v5, #0000000000000000
     7b4:	tbnz	w14, #0x0, 0x7dc
     7b8:	and	w16, w14, #0xff
     7bc:	tbnz	w16, #0x1, 0x7e8
     7c0:	tbnz	w16, #0x2, 0x7f4
     7c4:	tbnz	w16, #0x3, 0x800
     7c8:	tbnz	w16, #0x4, 0x80c
     7cc:	tbnz	w16, #0x5, 0x818
     7d0:	tbnz	w16, #0x6, 0x824
     7d4:	tbz	w16, #0x7, 0x788
     7d8:	b	0x830
     7dc:	ldr	s4, [x15]
     7e0:	and	w16, w14, #0xff
     7e4:	tbz	w16, #0x1, 0x7c0
     7e8:	add	x17, x15, #0x4
     7ec:	ld1.s	{ v4 }[1], [x17]
     7f0:	tbz	w16, #0x2, 0x7c4
     7f4:	add	x17, x15, #0x8
     7f8:	ld1.s	{ v4 }[2], [x17]
     7fc:	tbz	w16, #0x3, 0x7c8
     800:	add	x17, x15, #0xc
     804:	ld1.s	{ v4 }[3], [x17]
     808:	tbz	w16, #0x4, 0x7cc
     80c:	add	x17, x15, #0x10
     810:	ld1.s	{ v5 }[0], [x17]
     814:	tbz	w16, #0x5, 0x7d0
     818:	add	x17, x15, #0x14
     81c:	ld1.s	{ v5 }[1], [x17]
     820:	tbz	w16, #0x6, 0x7d4
     824:	add	x17, x15, #0x18
     828:	ld1.s	{ v5 }[2], [x17]
     82c:	tbz	w16, #0x7, 0x788
     830:	add	x15, x15, #0x1c
     834:	ld1.s	{ v5 }[3], [x15]
     838:	b	0x788
     83c:	add	x12, sp, #0xf0
     840:	ldr	q4, [x12, #0x500]
     844:	ldr	q5, [x12, #0x4f0]
     848:	fmul.4s	v6, v5, v5
     84c:	fmul.4s	v4, v4, v4
     850:	ldr	q5, [x12, #0x520]
     854:	ldr	q7, [x12, #0x510]
     858:	fmul.4s	v7, v7, v7
     85c:	fmul.4s	v16, v5, v5
     860:	ldr	q5, [x12, #0x540]
     864:	ldr	q17, [x12, #0x530]
     868:	fmul.4s	v19, v17, v17
     86c:	fmul.4s	v20, v5, v5
     870:	ldr	q5, [x12, #0x560]
     874:	ldr	q17, [x12, #0x550]
     878:	fmul.4s	v21, v17, v17
     87c:	fmul.4s	v22, v5, v5
     880:	and.16b	v5, v0, v4
     884:	and.16b	v4, v1, v6
     888:	and.16b	v18, v0, v16
     88c:	and.16b	v17, v1, v7
     890:	and.16b	v6, v0, v20
     894:	and.16b	v19, v1, v19
     898:	and.16b	v16, v0, v22
     89c:	and.16b	v7, v1, v21
     8a0:	ldr	x12, [sp, #0x20]
     8a4:	mov	w13, #0x4
     8a8:	ldp	q21, q20, [x12, #-0x60]
     8ac:	and.16b	v21, v1, v21
     8b0:	and.16b	v20, v0, v20
     8b4:	fmul.4s	v20, v20, v20
     8b8:	fmul.4s	v21, v21, v21
     8bc:	fadd.4s	v21, v4, v21
     8c0:	fadd.4s	v20, v5, v20
     8c4:	ldp	q23, q22, [x12, #-0x40]
     8c8:	and.16b	v23, v1, v23
     8cc:	and.16b	v22, v0, v22
     8d0:	fmul.4s	v22, v22, v22
     8d4:	fmul.4s	v23, v23, v23
     8d8:	fadd.4s	v23, v17, v23
     8dc:	fadd.4s	v22, v18, v22
     8e0:	ldp	q25, q24, [x12, #-0x20]
     8e4:	and.16b	v25, v1, v25
     8e8:	and.16b	v24, v0, v24
     8ec:	fmul.4s	v24, v24, v24
     8f0:	fmul.4s	v25, v25, v25
     8f4:	fadd.4s	v25, v19, v25
     8f8:	fadd.4s	v24, v6, v24
     8fc:	ldp	q27, q26, [x12], #0x80
     900:	and.16b	v27, v1, v27
     904:	and.16b	v26, v0, v26
     908:	fmul.4s	v26, v26, v26
     90c:	fmul.4s	v27, v27, v27
     910:	fadd.4s	v27, v7, v27
     914:	fadd.4s	v26, v16, v26
     918:	bit.16b	v5, v20, v0
     91c:	bit.16b	v4, v21, v1
     920:	bit.16b	v18, v22, v0
     924:	bit.16b	v17, v23, v1
     928:	bit.16b	v6, v24, v0
     92c:	bit.16b	v19, v25, v1
     930:	bit.16b	v16, v26, v0
     934:	bit.16b	v7, v27, v1
     938:	cmp	x13, #0x1c
     93c:	add	x13, x13, #0x4
     940:	b.lo	0x8a8
     944:	mov	x12, #0x0
     948:	b	0x96c
     94c:	add	x13, x6, x12
     950:	ldp	q22, q23, [x13]
     954:	bif.16b	v21, v23, v0
     958:	bif.16b	v20, v22, v1
     95c:	stp	q20, q21, [x13]
     960:	add	x12, x12, #0x20
     964:	cmp	x12, #0x400
     968:	b.eq	0xa04
     96c:	fmov	w14, s2
     970:	add	x13, x11, x12
     974:	movi.2d	v20, #0000000000000000
     978:	movi.2d	v21, #0000000000000000
     97c:	tbnz	w14, #0x0, 0x9a4
     980:	and	w14, w14, #0xff
     984:	tbnz	w14, #0x1, 0x9b0
     988:	tbnz	w14, #0x2, 0x9bc
     98c:	tbnz	w14, #0x3, 0x9c8
     990:	tbnz	w14, #0x4, 0x9d4
     994:	tbnz	w14, #0x5, 0x9e0
     998:	tbnz	w14, #0x6, 0x9ec
     99c:	tbz	w14, #0x7, 0x94c
     9a0:	b	0x9f8
     9a4:	ldr	s20, [x13]
     9a8:	and	w14, w14, #0xff
     9ac:	tbz	w14, #0x1, 0x988
     9b0:	add	x15, x13, #0x4
     9b4:	ld1.s	{ v20 }[1], [x15]
     9b8:	tbz	w14, #0x2, 0x98c
     9bc:	add	x15, x13, #0x8
     9c0:	ld1.s	{ v20 }[2], [x15]
     9c4:	tbz	w14, #0x3, 0x990
     9c8:	add	x15, x13, #0xc
     9cc:	ld1.s	{ v20 }[3], [x15]
     9d0:	tbz	w14, #0x4, 0x994
     9d4:	add	x15, x13, #0x10
     9d8:	ld1.s	{ v21 }[0], [x15]
     9dc:	tbz	w14, #0x5, 0x998
     9e0:	add	x15, x13, #0x14
     9e4:	ld1.s	{ v21 }[1], [x15]
     9e8:	tbz	w14, #0x6, 0x99c
     9ec:	add	x15, x13, #0x18
     9f0:	ld1.s	{ v21 }[2], [x15]
     9f4:	tbz	w14, #0x7, 0x94c
     9f8:	add	x13, x13, #0x1c
     9fc:	ld1.s	{ v21 }[3], [x13]
     a00:	b	0x94c
     a04:	mov	x11, #0x0
     a08:	xtn.8b	v20, v3
     a0c:	fadd.4s	v3, v5, v18
     a10:	fadd.4s	v4, v4, v17
     a14:	fadd.4s	v4, v4, v19
     a18:	fadd.4s	v3, v3, v6
     a1c:	fadd.4s	v3, v3, v16
     a20:	fadd.4s	v4, v4, v7
     a24:	ldp	q5, q7, [sp, #0x30]
     a28:	and.16b	v6, v1, v7
     a2c:	and.16b	v5, v0, v5
     a30:	movi.4s	v16, #0x1
     a34:	eor.16b	v7, v5, v16
     a38:	eor.16b	v18, v6, v16
     a3c:	umov.b	w13, v20[0]
     a40:	add	x4, sp, #0xf0
     a44:	str	q4, [x4, #0xc0]
     a48:	ldr	s6, [x4, #0xc4]
     a4c:	umov.b	w12, v20[1]
     a50:	ands	w14, w13, #0x1
     a54:	tst	w14, w12
     a58:	mov.s	w15, v18[1]
     a5c:	fcsel	s6, s6, s8, ne
     a60:	add	x16, sp, #0x68
     a64:	bfxil	x16, x15, #0, #3
     a68:	str	d20, [sp, #0x68]
     a6c:	ldrb	w16, [x16]
     a70:	add	x17, sp, #0x190
     a74:	orr	x15, x17, x15, lsl #2
     a78:	stp	q4, q3, [x4, #0xa0]
     a7c:	ldr	s16, [x15]
     a80:	ands	w15, w12, #0x1
     a84:	tst	w15, w16
     a88:	fcsel	s16, s16, s8, ne
     a8c:	mov.s	w15, v18[2]
     a90:	add	x16, sp, #0x68
     a94:	bfxil	x16, x15, #0, #3
     a98:	ldrb	w16, [x16]
     a9c:	add	x17, sp, #0x170
     aa0:	orr	x17, x17, x15, lsl #2
     aa4:	umov.b	w15, v20[2]
     aa8:	stp	q4, q3, [x4, #0x80]
     aac:	ldr	s17, [x17]
     ab0:	ands	w17, w15, #0x1
     ab4:	tst	w17, w16
     ab8:	fcsel	s17, s17, s8, ne
     abc:	mov.s	w16, v18[3]
     ac0:	add	x17, sp, #0x68
     ac4:	bfxil	x17, x16, #0, #3
     ac8:	ldrb	w17, [x17]
     acc:	add	x0, sp, #0x150
     ad0:	orr	x0, x0, x16, lsl #2
     ad4:	umov.b	w16, v20[3]
     ad8:	stp	q4, q3, [x4, #0x60]
     adc:	ldr	s18, [x0]
     ae0:	ands	w0, w16, #0x1
     ae4:	tst	w0, w17
     ae8:	fcsel	s18, s18, s8, ne
     aec:	fmov	w0, s7
     af0:	add	x17, sp, #0x68
     af4:	bfxil	x17, x0, #0, #3
     af8:	ldrb	w1, [x17]
     afc:	umov.b	w17, v20[4]
     b00:	and	w1, w17, w1
     b04:	stp	q4, q3, [x4, #0x40]
     b08:	add	x2, sp, #0x130
     b0c:	ldr	s19, [x2, w0, uxtw #2]
     b10:	tst	w1, #0x1
     b14:	mov.s	w1, v7[1]
     b18:	fcsel	s19, s19, s8, ne
     b1c:	add	x0, sp, #0x68
     b20:	bfxil	x0, x1, #0, #3
     b24:	ldrb	w2, [x0]
     b28:	umov.b	w0, v20[5]
     b2c:	stp	q4, q3, [x4, #0x20]
     b30:	add	x3, sp, #0x110
     b34:	ldr	s21, [x3, w1, uxtw #2]
     b38:	ands	w1, w0, #0x1
     b3c:	tst	w1, w2
     b40:	fcsel	s21, s21, s8, ne
     b44:	mov.s	w2, v7[2]
     b48:	add	x1, sp, #0x68
     b4c:	bfxil	x1, x2, #0, #3
     b50:	ldrb	w3, [x1]
     b54:	umov.b	w1, v20[6]
     b58:	stp	q4, q3, [x4]
     b5c:	ldr	s22, [x4, w2, uxtw #2]
     b60:	ands	w2, w1, #0x1
     b64:	tst	w2, w3
     b68:	fcsel	s22, s22, s8, ne
     b6c:	mov.s	w3, v7[3]
     b70:	add	x2, sp, #0x68
     b74:	bfxil	x2, x3, #0, #3
     b78:	ldrb	w4, [x2]
     b7c:	umov.b	w2, v20[7]
     b80:	stp	q4, q3, [sp, #0xd0]
     b84:	add	x7, sp, #0xd0
     b88:	ldr	s7, [x7, w3, uxtw #2]
     b8c:	ands	w3, w2, #0x1
     b90:	tst	w3, w4
     b94:	mov.s	v6[1], v16[0]
     b98:	mov.s	v6[2], v17[0]
     b9c:	mov.s	v6[3], v18[0]
     ba0:	mov.s	v19[1], v21[0]
     ba4:	fcsel	s7, s7, s8, ne
     ba8:	mov.s	v19[2], v22[0]
     bac:	mov.s	v19[3], v7[0]
     bb0:	fadd.4s	v3, v3, v19
     bb4:	fadd.4s	v4, v4, v6
     bb8:	movi.4s	v6, #0x2
     bbc:	eor.16b	v5, v5, v6
     bc0:	str	q4, [sp, #0xb0]
     bc4:	ldr	s6, [sp, #0xb8]
     bc8:	fmov	w3, s5
     bcc:	add	x4, sp, #0x68
     bd0:	bfxil	x4, x3, #0, #3
     bd4:	ldrb	w4, [x4]
     bd8:	stp	q4, q3, [sp, #0x90]
     bdc:	add	x7, sp, #0x90
     be0:	ldr	s5, [x7, w3, uxtw #2]
     be4:	tst	w14, w15
     be8:	fcsel	s6, s6, s8, ne
     bec:	and	w3, w17, w4
     bf0:	tst	w3, #0x1
     bf4:	fcsel	s5, s5, s8, ne
     bf8:	fadd.4s	v3, v3, v5
     bfc:	tst	w14, w17
     c00:	fcsel	s3, s3, s8, ne
     c04:	ands	w13, w13, #0x1
     c08:	fadd.4s	v4, v4, v6
     c0c:	fadd	s3, s4, s3
     c10:	fcsel	s4, s3, s8, ne
     c14:	tst	w12, #0x1
     c18:	fcsel	s5, s4, s8, ne
     c1c:	tst	w15, #0x1
     c20:	fcsel	s6, s4, s8, ne
     c24:	tst	w16, #0x1
     c28:	fcsel	s7, s4, s8, ne
     c2c:	tst	w13, w17
     c30:	fcsel	s3, s3, s8, ne
     c34:	tst	w0, #0x1
     c38:	fcsel	s16, s4, s8, ne
     c3c:	tst	w1, #0x1
     c40:	fcsel	s17, s4, s8, ne
     c44:	tst	w2, #0x1
     c48:	fcsel	s18, s4, s8, ne
     c4c:	mov.s	v4[1], v5[0]
     c50:	mov.s	v4[2], v6[0]
     c54:	mov.s	v4[3], v7[0]
     c58:	mov.s	v3[1], v16[0]
     c5c:	mov.s	v3[2], v17[0]
     c60:	mov.s	v3[3], v18[0]
     c64:	rbit	w10, w10
     c68:	clz	w10, w10
     c6c:	stp	q4, q3, [sp, #0x70]
     c70:	and	x10, x10, #0x7
     c74:	add	x12, sp, #0x70
     c78:	ldr	s3, [x12, x10, lsl #2]
     c7c:	fadd	s3, s3, s8
     c80:	mov	w10, #0x3b800000
     c84:	fmov	s4, w10
     c88:	fmul	s3, s3, s4
     c8c:	mov	w10, #0xc5ac
     c90:	movk	w10, #0x3727, lsl #16
     c94:	fmov	s4, w10
     c98:	fadd	s3, s3, s4
     c9c:	fsqrt	s3, s3
     ca0:	dup.4s	v3, v3[0]
     ca4:	add	x8, x8, x9
     ca8:	b	0xcb8
     cac:	add	x11, x11, #0x20
     cb0:	cmp	x11, #0x400
     cb4:	b.eq	0x604
     cb8:	fmov	w10, s2
     cbc:	add	x9, x5, x11
     cc0:	ldp	q5, q4, [x9]
     cc4:	and.16b	v5, v1, v5
     cc8:	fdiv.4s	v6, v5, v3
     ccc:	add	x9, x6, x11
     cd0:	ldp	q7, q5, [x9]
     cd4:	and.16b	v7, v1, v7
     cd8:	fmul.4s	v6, v6, v7
     cdc:	add	x9, x8, x11
     ce0:	tbnz	w10, #0x0, 0xd18
     ce4:	and	w10, w10, #0xff
     ce8:	tbnz	w10, #0x1, 0xd24
     cec:	tbnz	w10, #0x2, 0xd30
     cf0:	tbnz	w10, #0x3, 0xd3c
     cf4:	and.16b	v4, v0, v4
     cf8:	fdiv.4s	v4, v4, v3
     cfc:	and.16b	v5, v0, v5
     d00:	fmul.4s	v4, v4, v5
     d04:	tbnz	w10, #0x4, 0xd58
     d08:	tbnz	w10, #0x5, 0xd60
     d0c:	tbnz	w10, #0x6, 0xd6c
     d10:	tbz	w10, #0x7, 0xcac
     d14:	b	0xd78
     d18:	str	s6, [x9]
     d1c:	and	w10, w10, #0xff
     d20:	tbz	w10, #0x1, 0xcec
     d24:	add	x12, x9, #0x4
     d28:	st1.s	{ v6 }[1], [x12]
     d2c:	tbz	w10, #0x2, 0xcf0
     d30:	add	x12, x9, #0x8
     d34:	st1.s	{ v6 }[2], [x12]
     d38:	tbz	w10, #0x3, 0xcf4
     d3c:	add	x12, x9, #0xc
     d40:	st1.s	{ v6 }[3], [x12]
     d44:	and.16b	v4, v0, v4
     d48:	fdiv.4s	v4, v4, v3
     d4c:	and.16b	v5, v0, v5
     d50:	fmul.4s	v4, v4, v5
     d54:	tbz	w10, #0x4, 0xd08
     d58:	str	s4, [x9, #0x10]
     d5c:	tbz	w10, #0x5, 0xd0c
     d60:	add	x12, x9, #0x14
     d64:	st1.s	{ v4 }[1], [x12]
     d68:	tbz	w10, #0x6, 0xd10
     d6c:	add	x12, x9, #0x18
     d70:	st1.s	{ v4 }[2], [x12]
     d74:	tbz	w10, #0x7, 0xcac
     d78:	add	x9, x9, #0x1c
     d7c:	st1.s	{ v4 }[3], [x9]
     d80:	b	0xcac
     d84:	add	sp, sp, #0x9e0
     d88:	ldp	x29, x30, [sp, #0x60]
     d8c:	ldp	x20, x19, [sp, #0x50]
     d90:	ldp	x22, x21, [sp, #0x40]
     d94:	ldp	x24, x23, [sp, #0x30]
     d98:	ldp	x26, x25, [sp, #0x20]
     d9c:	ldp	x28, x27, [sp, #0x10]
     da0:	ldp	d9, d8, [sp], #0x70
     da4:	ret

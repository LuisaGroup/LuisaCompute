/tmp/luisa-full-packet.UEezjO/capture/rmsnorm-64x256-r0-l1-f1-p0/object/tile_xir_w8_63765_1788856225870555_0.o:
(__TEXT,__text) section
_llm_rows:
       0:	stp	d9, d8, [sp, #-0x20]!
       4:	stp	x28, x27, [sp, #0x10]
       8:	sub	sp, sp, #0x4, lsl #12
       c:	sub	sp, sp, #0x10
      10:	dup.4s	v1, w2
      14:	adrp	x8, lCPI0_0@PAGE
      18:	ldr	q3, [x8, lCPI0_0@PAGEOFF]
      1c:	adrp	x8, lCPI0_1@PAGE
      20:	ldr	q4, [x8, lCPI0_1@PAGEOFF]
      24:	cmhi.4s	v0, v1, v4
      28:	cmhi.4s	v1, v1, v3
      2c:	uzp1.8h	v2, v1, v0
      30:	umaxv.8h	h5, v2
      34:	fmov	w8, s5
      38:	tbz	w8, #0x0, 0x8a0
      3c:	ldr	x9, [x0]
      40:	adrp	x8, lCPI0_2@PAGE
      44:	ldr	q5, [x8, lCPI0_2@PAGEOFF]
      48:	and.16b	v2, v2, v5
      4c:	addv.8h	h2, v2
      50:	fmov	w10, s2
      54:	and	w8, w10, #0xff
      58:	ldr	w11, [x1]
      5c:	ldr	w12, [x1, #0x24]
      60:	add	w11, w12, w11, lsl #6
      64:	dup.4s	v5, w11
      68:	add.4s	v7, v5, v4
      6c:	add.4s	v3, v5, v3
      70:	and.16b	v4, v1, v3
      74:	ushll.2d	v19, v4, #0xa
      78:	dup.2d	v3, x9
      7c:	add.2d	v17, v3, v19
      80:	movi.2d	v5, #0000000000000000
      84:	movi.2d	v6, #0000000000000000
      88:	tbnz	w10, #0x0, 0x8b4
      8c:	and.16b	v7, v0, v7
      90:	ushll2.2d	v16, v4, #0xa
      94:	tbnz	w8, #0x1, 0x8c8
      98:	add.2d	v17, v3, v16
      9c:	tbnz	w8, #0x2, 0x8d8
      a0:	ushll.2d	v18, v7, #0xa
      a4:	tbnz	w8, #0x3, 0x8e8
      a8:	add.2d	v20, v3, v18
      ac:	tbnz	w8, #0x4, 0x8f8
      b0:	ushll2.2d	v17, v7, #0xa
      b4:	tbnz	w8, #0x5, 0x908
      b8:	add.2d	v20, v3, v17
      bc:	tbnz	w8, #0x6, 0x918
      c0:	add	x10, sp, #0x2, lsl #12
      c4:	add	x10, x10, #0x10
      c8:	tbz	w8, #0x7, 0xd4
      cc:	mov.d	x8, v20[1]
      d0:	ld1.s	{ v6 }[3], [x8]
      d4:	ldr	x9, [x0, #0x10]
      d8:	ldr	x8, [x0, #0x30]
      dc:	fmov	w12, s2
      e0:	and	w11, w12, #0xff
      e4:	stp	q5, q6, [x10]
      e8:	mov	w13, #0x4
      ec:	dup.2d	v20, x13
      f0:	add.2d	v22, v3, v20
      f4:	add.2d	v23, v22, v19
      f8:	movi.2d	v20, #0000000000000000
      fc:	movi.2d	v21, #0000000000000000
     100:	tbnz	w12, #0x0, 0x930
     104:	tbnz	w11, #0x1, 0x93c
     108:	add.2d	v23, v22, v16
     10c:	tbnz	w11, #0x2, 0x94c
     110:	tbnz	w11, #0x3, 0x958
     114:	add.2d	v23, v22, v18
     118:	tbnz	w11, #0x4, 0x968
     11c:	tbnz	w11, #0x5, 0x974
     120:	add.2d	v22, v22, v17
     124:	tbnz	w11, #0x6, 0x984
     128:	tbz	w11, #0x7, 0x134
     12c:	mov.d	x11, v22[1]
     130:	ld1.s	{ v21 }[3], [x11]
     134:	fmov	w12, s2
     138:	and	w11, w12, #0xff
     13c:	stp	q20, q21, [x10, #0x20]
     140:	mov	w13, #0x8
     144:	dup.2d	v22, x13
     148:	add.2d	v24, v3, v22
     14c:	add.2d	v25, v24, v19
     150:	movi.2d	v22, #0000000000000000
     154:	movi.2d	v23, #0000000000000000
     158:	tbnz	w12, #0x0, 0x994
     15c:	tbnz	w11, #0x1, 0x9a0
     160:	add.2d	v25, v24, v16
     164:	tbnz	w11, #0x2, 0x9b0
     168:	tbnz	w11, #0x3, 0x9bc
     16c:	add.2d	v25, v24, v18
     170:	tbnz	w11, #0x4, 0x9cc
     174:	tbnz	w11, #0x5, 0x9d8
     178:	add.2d	v24, v24, v17
     17c:	tbnz	w11, #0x6, 0x9e8
     180:	tbz	w11, #0x7, 0x18c
     184:	mov.d	x11, v24[1]
     188:	ld1.s	{ v23 }[3], [x11]
     18c:	fmov	w12, s2
     190:	and	w11, w12, #0xff
     194:	stp	q22, q23, [x10, #0x40]
     198:	mov	w13, #0xc
     19c:	dup.2d	v24, x13
     1a0:	add.2d	v25, v3, v24
     1a4:	add.2d	v26, v25, v19
     1a8:	movi.2d	v19, #0000000000000000
     1ac:	movi.2d	v24, #0000000000000000
     1b0:	tbnz	w12, #0x0, 0x9f8
     1b4:	tbnz	w11, #0x1, 0xa04
     1b8:	add.2d	v16, v25, v16
     1bc:	tbnz	w11, #0x2, 0xa14
     1c0:	tbnz	w11, #0x3, 0xa20
     1c4:	add.2d	v16, v25, v18
     1c8:	tbnz	w11, #0x4, 0xa30
     1cc:	tbnz	w11, #0x5, 0xa3c
     1d0:	add.2d	v16, v25, v17
     1d4:	tbz	w11, #0x6, 0x1e0
     1d8:	fmov	x12, d16
     1dc:	ld1.s	{ v24 }[2], [x12]
     1e0:	sshll.2d	v17, v1, #0x0
     1e4:	sshll.2d	v25, v0, #0x0
     1e8:	sshll2.2d	v28, v1, #0x0
     1ec:	sshll2.2d	v30, v0, #0x0
     1f0:	ushll.2d	v29, v4, #0x8
     1f4:	ushll.2d	v31, v7, #0x8
     1f8:	ushll2.2d	v8, v4, #0x8
     1fc:	ushll2.2d	v4, v7, #0x8
     200:	fmul.4s	v18, v5, v5
     204:	fmul.4s	v26, v6, v6
     208:	fmul.4s	v20, v20, v20
     20c:	fmul.4s	v27, v21, v21
     210:	fmul.4s	v21, v22, v22
     214:	fmul.4s	v22, v23, v23
     218:	tbz	w11, #0x7, 0x224
     21c:	mov.d	x11, v16[1]
     220:	ld1.s	{ v24 }[3], [x11]
     224:	and.16b	v4, v30, v4
     228:	and.16b	v5, v28, v8
     22c:	and.16b	v6, v25, v31
     230:	and.16b	v7, v17, v29
     234:	stp	q19, q24, [x10, #0x60]
     238:	fmul.4s	v23, v19, v19
     23c:	fmul.4s	v24, v24, v24
     240:	and.16b	v16, v0, v26
     244:	and.16b	v18, v1, v18
     248:	and.16b	v17, v0, v27
     24c:	and.16b	v20, v1, v20
     250:	and.16b	v19, v0, v22
     254:	add	x10, sp, #0x2, lsl #12
     258:	add	x10, x10, #0x10
     25c:	and.16b	v22, v1, v21
     260:	add	x10, x10, #0xe0
     264:	and.16b	v21, v0, v24
     268:	mov	w11, #0x7
     26c:	fmov	w12, s2
     270:	and.16b	v23, v1, v23
     274:	b	0x2f8
     278:	fmul.4s	v25, v25, v25
     27c:	fmul.4s	v24, v24, v24
     280:	fadd.4s	v24, v18, v24
     284:	fadd.4s	v25, v16, v25
     288:	fmul.4s	v27, v27, v27
     28c:	fmul.4s	v26, v26, v26
     290:	fadd.4s	v26, v20, v26
     294:	fadd.4s	v27, v17, v27
     298:	fmul.4s	v29, v29, v29
     29c:	fmul.4s	v28, v28, v28
     2a0:	fadd.4s	v28, v22, v28
     2a4:	fadd.4s	v29, v19, v29
     2a8:	ldp	q8, q9, [x10]
     2ac:	bit.16b	v9, v31, v0
     2b0:	bit.16b	v8, v30, v1
     2b4:	stp	q8, q9, [x10], #0x80
     2b8:	fmul.4s	v30, v30, v30
     2bc:	fmul.4s	v31, v31, v31
     2c0:	fadd.4s	v31, v21, v31
     2c4:	fadd.4s	v30, v23, v30
     2c8:	bit.16b	v16, v25, v0
     2cc:	bit.16b	v18, v24, v1
     2d0:	bit.16b	v17, v27, v0
     2d4:	bit.16b	v20, v26, v1
     2d8:	bit.16b	v19, v29, v0
     2dc:	add	x11, x11, #0x4
     2e0:	bit.16b	v22, v28, v1
     2e4:	bit.16b	v23, v30, v1
     2e8:	sub	x13, x13, #0x3
     2ec:	bit.16b	v21, v31, v0
     2f0:	cmp	x13, #0xfc
     2f4:	b.hs	0x6e8
     2f8:	sub	x13, x11, #0x3
     2fc:	dup.2d	v26, x13
     300:	add.2d	v24, v26, v7
     304:	shl.2d	v24, v24, #0x2
     308:	add.2d	v27, v3, v24
     30c:	movi.2d	v24, #0000000000000000
     310:	movi.2d	v25, #0000000000000000
     314:	tbnz	w12, #0x0, 0x4e0
     318:	and	w14, w12, #0xff
     31c:	tbnz	w14, #0x1, 0x4f0
     320:	add.2d	v27, v26, v5
     324:	shl.2d	v27, v27, #0x2
     328:	add.2d	v27, v3, v27
     32c:	tbnz	w14, #0x2, 0x508
     330:	tbnz	w14, #0x3, 0x514
     334:	add.2d	v27, v26, v6
     338:	shl.2d	v27, v27, #0x2
     33c:	add.2d	v27, v3, v27
     340:	tbnz	w14, #0x4, 0x52c
     344:	tbnz	w14, #0x5, 0x538
     348:	add.2d	v26, v26, v4
     34c:	shl.2d	v26, v26, #0x2
     350:	add.2d	v26, v3, v26
     354:	tbnz	w14, #0x6, 0x550
     358:	tbz	w14, #0x7, 0x364
     35c:	mov.d	x14, v26[1]
     360:	ld1.s	{ v25 }[3], [x14]
     364:	fmov	w14, s2
     368:	ldp	q26, q27, [x10, #-0x60]
     36c:	bit.16b	v27, v25, v0
     370:	bit.16b	v26, v24, v1
     374:	add	x13, x13, #0x1
     378:	dup.2d	v28, x13
     37c:	stp	q26, q27, [x10, #-0x60]
     380:	add.2d	v26, v28, v7
     384:	shl.2d	v26, v26, #0x2
     388:	add.2d	v29, v3, v26
     38c:	movi.2d	v26, #0000000000000000
     390:	movi.2d	v27, #0000000000000000
     394:	tbnz	w14, #0x0, 0x560
     398:	and	w14, w14, #0xff
     39c:	tbnz	w14, #0x1, 0x570
     3a0:	add.2d	v29, v28, v5
     3a4:	shl.2d	v29, v29, #0x2
     3a8:	add.2d	v29, v3, v29
     3ac:	tbnz	w14, #0x2, 0x588
     3b0:	tbnz	w14, #0x3, 0x594
     3b4:	add.2d	v29, v28, v6
     3b8:	shl.2d	v29, v29, #0x2
     3bc:	add.2d	v29, v3, v29
     3c0:	tbnz	w14, #0x4, 0x5ac
     3c4:	tbnz	w14, #0x5, 0x5b8
     3c8:	add.2d	v28, v28, v4
     3cc:	shl.2d	v28, v28, #0x2
     3d0:	add.2d	v28, v3, v28
     3d4:	tbnz	w14, #0x6, 0x5d0
     3d8:	tbz	w14, #0x7, 0x3e4
     3dc:	mov.d	x14, v28[1]
     3e0:	ld1.s	{ v27 }[3], [x14]
     3e4:	fmov	w14, s2
     3e8:	ldp	q28, q29, [x10, #-0x40]
     3ec:	bit.16b	v29, v27, v0
     3f0:	bit.16b	v28, v26, v1
     3f4:	add	x13, x13, #0x1
     3f8:	dup.2d	v30, x13
     3fc:	stp	q28, q29, [x10, #-0x40]
     400:	add.2d	v28, v30, v7
     404:	shl.2d	v28, v28, #0x2
     408:	add.2d	v31, v3, v28
     40c:	movi.2d	v28, #0000000000000000
     410:	movi.2d	v29, #0000000000000000
     414:	tbnz	w14, #0x0, 0x5e0
     418:	and	w14, w14, #0xff
     41c:	tbnz	w14, #0x1, 0x5f0
     420:	add.2d	v31, v30, v5
     424:	shl.2d	v31, v31, #0x2
     428:	add.2d	v31, v3, v31
     42c:	tbnz	w14, #0x2, 0x608
     430:	tbnz	w14, #0x3, 0x614
     434:	add.2d	v31, v30, v6
     438:	shl.2d	v31, v31, #0x2
     43c:	add.2d	v31, v3, v31
     440:	tbnz	w14, #0x4, 0x62c
     444:	tbnz	w14, #0x5, 0x638
     448:	add.2d	v30, v30, v4
     44c:	shl.2d	v30, v30, #0x2
     450:	add.2d	v30, v3, v30
     454:	tbnz	w14, #0x6, 0x650
     458:	tbz	w14, #0x7, 0x464
     45c:	mov.d	x14, v30[1]
     460:	ld1.s	{ v29 }[3], [x14]
     464:	fmov	w14, s2
     468:	ldp	q30, q31, [x10, #-0x20]
     46c:	bit.16b	v31, v29, v0
     470:	bit.16b	v30, v28, v1
     474:	add	x13, x13, #0x1
     478:	dup.2d	v8, x13
     47c:	stp	q30, q31, [x10, #-0x20]
     480:	add.2d	v30, v8, v7
     484:	shl.2d	v30, v30, #0x2
     488:	add.2d	v9, v3, v30
     48c:	movi.2d	v30, #0000000000000000
     490:	movi.2d	v31, #0000000000000000
     494:	tbnz	w14, #0x0, 0x660
     498:	and	w14, w14, #0xff
     49c:	tbnz	w14, #0x1, 0x670
     4a0:	add.2d	v9, v8, v5
     4a4:	shl.2d	v9, v9, #0x2
     4a8:	add.2d	v9, v3, v9
     4ac:	tbnz	w14, #0x2, 0x688
     4b0:	tbnz	w14, #0x3, 0x694
     4b4:	add.2d	v9, v8, v6
     4b8:	shl.2d	v9, v9, #0x2
     4bc:	add.2d	v9, v3, v9
     4c0:	tbnz	w14, #0x4, 0x6ac
     4c4:	tbnz	w14, #0x5, 0x6b8
     4c8:	add.2d	v8, v8, v4
     4cc:	shl.2d	v8, v8, #0x2
     4d0:	add.2d	v8, v3, v8
     4d4:	tbnz	w14, #0x6, 0x6d0
     4d8:	tbz	w14, #0x7, 0x278
     4dc:	b	0x6dc
     4e0:	fmov	x14, d27
     4e4:	ldr	s24, [x14]
     4e8:	and	w14, w12, #0xff
     4ec:	tbz	w14, #0x1, 0x320
     4f0:	mov.d	x15, v27[1]
     4f4:	ld1.s	{ v24 }[1], [x15]
     4f8:	add.2d	v27, v26, v5
     4fc:	shl.2d	v27, v27, #0x2
     500:	add.2d	v27, v3, v27
     504:	tbz	w14, #0x2, 0x330
     508:	fmov	x15, d27
     50c:	ld1.s	{ v24 }[2], [x15]
     510:	tbz	w14, #0x3, 0x334
     514:	mov.d	x15, v27[1]
     518:	ld1.s	{ v24 }[3], [x15]
     51c:	add.2d	v27, v26, v6
     520:	shl.2d	v27, v27, #0x2
     524:	add.2d	v27, v3, v27
     528:	tbz	w14, #0x4, 0x344
     52c:	fmov	x15, d27
     530:	ld1.s	{ v25 }[0], [x15]
     534:	tbz	w14, #0x5, 0x348
     538:	mov.d	x15, v27[1]
     53c:	ld1.s	{ v25 }[1], [x15]
     540:	add.2d	v26, v26, v4
     544:	shl.2d	v26, v26, #0x2
     548:	add.2d	v26, v3, v26
     54c:	tbz	w14, #0x6, 0x358
     550:	fmov	x15, d26
     554:	ld1.s	{ v25 }[2], [x15]
     558:	tbnz	w14, #0x7, 0x35c
     55c:	b	0x364
     560:	fmov	x15, d29
     564:	ldr	s26, [x15]
     568:	and	w14, w14, #0xff
     56c:	tbz	w14, #0x1, 0x3a0
     570:	mov.d	x15, v29[1]
     574:	ld1.s	{ v26 }[1], [x15]
     578:	add.2d	v29, v28, v5
     57c:	shl.2d	v29, v29, #0x2
     580:	add.2d	v29, v3, v29
     584:	tbz	w14, #0x2, 0x3b0
     588:	fmov	x15, d29
     58c:	ld1.s	{ v26 }[2], [x15]
     590:	tbz	w14, #0x3, 0x3b4
     594:	mov.d	x15, v29[1]
     598:	ld1.s	{ v26 }[3], [x15]
     59c:	add.2d	v29, v28, v6
     5a0:	shl.2d	v29, v29, #0x2
     5a4:	add.2d	v29, v3, v29
     5a8:	tbz	w14, #0x4, 0x3c4
     5ac:	fmov	x15, d29
     5b0:	ld1.s	{ v27 }[0], [x15]
     5b4:	tbz	w14, #0x5, 0x3c8
     5b8:	mov.d	x15, v29[1]
     5bc:	ld1.s	{ v27 }[1], [x15]
     5c0:	add.2d	v28, v28, v4
     5c4:	shl.2d	v28, v28, #0x2
     5c8:	add.2d	v28, v3, v28
     5cc:	tbz	w14, #0x6, 0x3d8
     5d0:	fmov	x15, d28
     5d4:	ld1.s	{ v27 }[2], [x15]
     5d8:	tbnz	w14, #0x7, 0x3dc
     5dc:	b	0x3e4
     5e0:	fmov	x15, d31
     5e4:	ldr	s28, [x15]
     5e8:	and	w14, w14, #0xff
     5ec:	tbz	w14, #0x1, 0x420
     5f0:	mov.d	x15, v31[1]
     5f4:	ld1.s	{ v28 }[1], [x15]
     5f8:	add.2d	v31, v30, v5
     5fc:	shl.2d	v31, v31, #0x2
     600:	add.2d	v31, v3, v31
     604:	tbz	w14, #0x2, 0x430
     608:	fmov	x15, d31
     60c:	ld1.s	{ v28 }[2], [x15]
     610:	tbz	w14, #0x3, 0x434
     614:	mov.d	x15, v31[1]
     618:	ld1.s	{ v28 }[3], [x15]
     61c:	add.2d	v31, v30, v6
     620:	shl.2d	v31, v31, #0x2
     624:	add.2d	v31, v3, v31
     628:	tbz	w14, #0x4, 0x444
     62c:	fmov	x15, d31
     630:	ld1.s	{ v29 }[0], [x15]
     634:	tbz	w14, #0x5, 0x448
     638:	mov.d	x15, v31[1]
     63c:	ld1.s	{ v29 }[1], [x15]
     640:	add.2d	v30, v30, v4
     644:	shl.2d	v30, v30, #0x2
     648:	add.2d	v30, v3, v30
     64c:	tbz	w14, #0x6, 0x458
     650:	fmov	x15, d30
     654:	ld1.s	{ v29 }[2], [x15]
     658:	tbnz	w14, #0x7, 0x45c
     65c:	b	0x464
     660:	fmov	x15, d9
     664:	ldr	s30, [x15]
     668:	and	w14, w14, #0xff
     66c:	tbz	w14, #0x1, 0x4a0
     670:	mov.d	x15, v9[1]
     674:	ld1.s	{ v30 }[1], [x15]
     678:	add.2d	v9, v8, v5
     67c:	shl.2d	v9, v9, #0x2
     680:	add.2d	v9, v3, v9
     684:	tbz	w14, #0x2, 0x4b0
     688:	fmov	x15, d9
     68c:	ld1.s	{ v30 }[2], [x15]
     690:	tbz	w14, #0x3, 0x4b4
     694:	mov.d	x15, v9[1]
     698:	ld1.s	{ v30 }[3], [x15]
     69c:	add.2d	v9, v8, v6
     6a0:	shl.2d	v9, v9, #0x2
     6a4:	add.2d	v9, v3, v9
     6a8:	tbz	w14, #0x4, 0x4c4
     6ac:	fmov	x15, d9
     6b0:	ld1.s	{ v31 }[0], [x15]
     6b4:	tbz	w14, #0x5, 0x4c8
     6b8:	mov.d	x15, v9[1]
     6bc:	ld1.s	{ v31 }[1], [x15]
     6c0:	add.2d	v8, v8, v4
     6c4:	shl.2d	v8, v8, #0x2
     6c8:	add.2d	v8, v3, v8
     6cc:	tbz	w14, #0x6, 0x4d8
     6d0:	fmov	x15, d8
     6d4:	ld1.s	{ v31 }[2], [x15]
     6d8:	tbz	w14, #0x7, 0x278
     6dc:	mov.d	x14, v8[1]
     6e0:	ld1.s	{ v31 }[3], [x14]
     6e4:	b	0x278
     6e8:	mov	x10, #0x0
     6ec:	add	x11, sp, #0x10
     6f0:	add	x12, x9, x10, lsl #2
     6f4:	ld1r.4s	{ v3 }, [x12]
     6f8:	add	x12, x11, x10, lsl #5
     6fc:	ldp	q24, q25, [x12]
     700:	bit.16b	v25, v3, v0
     704:	bif.16b	v3, v24, v1
     708:	stp	q3, q25, [x12]
     70c:	add	x10, x10, #0x1
     710:	cmp	x10, #0x100
     714:	b.ne	0x6f0
     718:	mov	x9, #0x0
     71c:	fadd.4s	v3, v18, v20
     720:	fadd.4s	v16, v16, v17
     724:	fadd.4s	v16, v16, v19
     728:	fadd.4s	v3, v3, v22
     72c:	fadd.4s	v3, v3, v23
     730:	fadd.4s	v16, v16, v21
     734:	mov	w10, #0x3b800000
     738:	dup.4s	v17, w10
     73c:	fmul.4s	v16, v16, v17
     740:	mov	w10, #0xc5ac
     744:	movk	w10, #0x3727, lsl #16
     748:	dup.4s	v18, w10
     74c:	fmul.4s	v3, v3, v17
     750:	fadd.4s	v3, v3, v18
     754:	fadd.4s	v16, v16, v18
     758:	fsqrt.4s	v16, v16
     75c:	fsqrt.4s	v3, v3
     760:	and.16b	v3, v1, v3
     764:	and.16b	v16, v0, v16
     768:	fmov	w10, s2
     76c:	add	x11, sp, #0x2, lsl #12
     770:	add	x11, x11, #0x10
     774:	dup.2d	v2, x8
     778:	add	x8, sp, #0x10
     77c:	b	0x78c
     780:	add	x9, x9, #0x1
     784:	cmp	x9, #0x100
     788:	b.eq	0x8a0
     78c:	dup.2d	v17, x9
     790:	add.2d	v19, v17, v7
     794:	lsl	x12, x9, #5
     798:	add	x13, x11, x12
     79c:	ldr	q18, [x13]
     7a0:	and.16b	v18, v1, v18
     7a4:	fdiv.4s	v18, v18, v3
     7a8:	add	x14, x8, x12
     7ac:	ldr	q20, [x14]
     7b0:	and.16b	v20, v1, v20
     7b4:	fmul.4s	v18, v18, v20
     7b8:	shl.2d	v19, v19, #0x2
     7bc:	add.2d	v19, v2, v19
     7c0:	tbnz	w10, #0x0, 0x82c
     7c4:	and	w12, w10, #0xff
     7c8:	tbnz	w12, #0x1, 0x83c
     7cc:	add.2d	v19, v17, v5
     7d0:	shl.2d	v19, v19, #0x2
     7d4:	add.2d	v19, v2, v19
     7d8:	tbnz	w12, #0x2, 0x854
     7dc:	tbz	w12, #0x3, 0x7e8
     7e0:	mov.d	x15, v19[1]
     7e4:	st1.s	{ v18 }[3], [x15]
     7e8:	add.2d	v19, v17, v6
     7ec:	ldr	q18, [x13, #0x10]
     7f0:	and.16b	v18, v0, v18
     7f4:	fdiv.4s	v18, v18, v16
     7f8:	ldr	q20, [x14, #0x10]
     7fc:	and.16b	v20, v0, v20
     800:	fmul.4s	v18, v18, v20
     804:	shl.2d	v19, v19, #0x2
     808:	add.2d	v19, v2, v19
     80c:	tbnz	w12, #0x4, 0x864
     810:	tbnz	w12, #0x5, 0x870
     814:	add.2d	v17, v17, v4
     818:	shl.2d	v17, v17, #0x2
     81c:	add.2d	v17, v2, v17
     820:	tbnz	w12, #0x6, 0x888
     824:	tbz	w12, #0x7, 0x780
     828:	b	0x894
     82c:	fmov	x12, d19
     830:	str	s18, [x12]
     834:	and	w12, w10, #0xff
     838:	tbz	w12, #0x1, 0x7cc
     83c:	mov.d	x15, v19[1]
     840:	st1.s	{ v18 }[1], [x15]
     844:	add.2d	v19, v17, v5
     848:	shl.2d	v19, v19, #0x2
     84c:	add.2d	v19, v2, v19
     850:	tbz	w12, #0x2, 0x7dc
     854:	fmov	x15, d19
     858:	st1.s	{ v18 }[2], [x15]
     85c:	tbnz	w12, #0x3, 0x7e0
     860:	b	0x7e8
     864:	fmov	x13, d19
     868:	str	s18, [x13]
     86c:	tbz	w12, #0x5, 0x814
     870:	mov.d	x13, v19[1]
     874:	st1.s	{ v18 }[1], [x13]
     878:	add.2d	v17, v17, v4
     87c:	shl.2d	v17, v17, #0x2
     880:	add.2d	v17, v2, v17
     884:	tbz	w12, #0x6, 0x824
     888:	fmov	x13, d17
     88c:	st1.s	{ v18 }[2], [x13]
     890:	tbz	w12, #0x7, 0x780
     894:	mov.d	x12, v17[1]
     898:	st1.s	{ v18 }[3], [x12]
     89c:	b	0x780
     8a0:	add	sp, sp, #0x4, lsl #12
     8a4:	add	sp, sp, #0x10
     8a8:	ldp	x28, x27, [sp, #0x10]
     8ac:	ldp	d9, d8, [sp], #0x20
     8b0:	ret
     8b4:	fmov	x9, d17
     8b8:	ldr	s5, [x9]
     8bc:	and.16b	v7, v0, v7
     8c0:	ushll2.2d	v16, v4, #0xa
     8c4:	tbz	w8, #0x1, 0x98
     8c8:	mov.d	x9, v17[1]
     8cc:	ld1.s	{ v5 }[1], [x9]
     8d0:	add.2d	v17, v3, v16
     8d4:	tbz	w8, #0x2, 0xa0
     8d8:	fmov	x9, d17
     8dc:	ld1.s	{ v5 }[2], [x9]
     8e0:	ushll.2d	v18, v7, #0xa
     8e4:	tbz	w8, #0x3, 0xa8
     8e8:	mov.d	x9, v17[1]
     8ec:	ld1.s	{ v5 }[3], [x9]
     8f0:	add.2d	v20, v3, v18
     8f4:	tbz	w8, #0x4, 0xb0
     8f8:	fmov	x9, d20
     8fc:	ld1.s	{ v6 }[0], [x9]
     900:	ushll2.2d	v17, v7, #0xa
     904:	tbz	w8, #0x5, 0xb8
     908:	mov.d	x9, v20[1]
     90c:	ld1.s	{ v6 }[1], [x9]
     910:	add.2d	v20, v3, v17
     914:	tbz	w8, #0x6, 0xc0
     918:	fmov	x9, d20
     91c:	ld1.s	{ v6 }[2], [x9]
     920:	add	x10, sp, #0x2, lsl #12
     924:	add	x10, x10, #0x10
     928:	tbnz	w8, #0x7, 0xcc
     92c:	b	0xd4
     930:	fmov	x12, d23
     934:	ldr	s20, [x12]
     938:	tbz	w11, #0x1, 0x108
     93c:	mov.d	x12, v23[1]
     940:	ld1.s	{ v20 }[1], [x12]
     944:	add.2d	v23, v22, v16
     948:	tbz	w11, #0x2, 0x110
     94c:	fmov	x12, d23
     950:	ld1.s	{ v20 }[2], [x12]
     954:	tbz	w11, #0x3, 0x114
     958:	mov.d	x12, v23[1]
     95c:	ld1.s	{ v20 }[3], [x12]
     960:	add.2d	v23, v22, v18
     964:	tbz	w11, #0x4, 0x11c
     968:	fmov	x12, d23
     96c:	ld1.s	{ v21 }[0], [x12]
     970:	tbz	w11, #0x5, 0x120
     974:	mov.d	x12, v23[1]
     978:	ld1.s	{ v21 }[1], [x12]
     97c:	add.2d	v22, v22, v17
     980:	tbz	w11, #0x6, 0x128
     984:	fmov	x12, d22
     988:	ld1.s	{ v21 }[2], [x12]
     98c:	tbnz	w11, #0x7, 0x12c
     990:	b	0x134
     994:	fmov	x12, d25
     998:	ldr	s22, [x12]
     99c:	tbz	w11, #0x1, 0x160
     9a0:	mov.d	x12, v25[1]
     9a4:	ld1.s	{ v22 }[1], [x12]
     9a8:	add.2d	v25, v24, v16
     9ac:	tbz	w11, #0x2, 0x168
     9b0:	fmov	x12, d25
     9b4:	ld1.s	{ v22 }[2], [x12]
     9b8:	tbz	w11, #0x3, 0x16c
     9bc:	mov.d	x12, v25[1]
     9c0:	ld1.s	{ v22 }[3], [x12]
     9c4:	add.2d	v25, v24, v18
     9c8:	tbz	w11, #0x4, 0x174
     9cc:	fmov	x12, d25
     9d0:	ld1.s	{ v23 }[0], [x12]
     9d4:	tbz	w11, #0x5, 0x178
     9d8:	mov.d	x12, v25[1]
     9dc:	ld1.s	{ v23 }[1], [x12]
     9e0:	add.2d	v24, v24, v17
     9e4:	tbz	w11, #0x6, 0x180
     9e8:	fmov	x12, d24
     9ec:	ld1.s	{ v23 }[2], [x12]
     9f0:	tbnz	w11, #0x7, 0x184
     9f4:	b	0x18c
     9f8:	fmov	x12, d26
     9fc:	ldr	s19, [x12]
     a00:	tbz	w11, #0x1, 0x1b8
     a04:	mov.d	x12, v26[1]
     a08:	ld1.s	{ v19 }[1], [x12]
     a0c:	add.2d	v16, v25, v16
     a10:	tbz	w11, #0x2, 0x1c0
     a14:	fmov	x12, d16
     a18:	ld1.s	{ v19 }[2], [x12]
     a1c:	tbz	w11, #0x3, 0x1c4
     a20:	mov.d	x12, v16[1]
     a24:	ld1.s	{ v19 }[3], [x12]
     a28:	add.2d	v16, v25, v18
     a2c:	tbz	w11, #0x4, 0x1cc
     a30:	fmov	x12, d16
     a34:	ld1.s	{ v24 }[0], [x12]
     a38:	tbz	w11, #0x5, 0x1d0
     a3c:	mov.d	x12, v16[1]
     a40:	ld1.s	{ v24 }[1], [x12]
     a44:	add.2d	v16, v25, v17
     a48:	tbnz	w11, #0x6, 0x1d8
     a4c:	b	0x1e0
_llm_rows.packet_batch.blocks:
     a50:	cbz	w3, 0xce4
     a54:	sub	sp, sp, #0x70
     a58:	stp	x28, x27, [sp, #0x10]
     a5c:	stp	x26, x25, [sp, #0x20]
     a60:	stp	x24, x23, [sp, #0x30]
     a64:	stp	x22, x21, [sp, #0x40]
     a68:	stp	x20, x19, [sp, #0x50]
     a6c:	stp	x29, x30, [sp, #0x60]
     a70:	mov	x19, x3
     a74:	mov	x20, x2
     a78:	mov	x21, x0
     a7c:	ldp	w26, w23, [x2, #0x2c]
     a80:	ldp	w27, w28, [x2]
     a84:	ldp	w25, w24, [x2, #0x8]
     a88:	str	w23, [sp, #0xc]
     a8c:	b	0xb78
     a90:	mov	x0, x21
     a94:	mov	x1, x20
     a98:	mov	w2, #0x8
     a9c:	bl	_llm_rows
     aa0:	mov	w8, #0x8
     aa4:	str	w8, [x20, #0x24]
     aa8:	mov	x0, x21
     aac:	mov	x1, x20
     ab0:	mov	w2, #0x8
     ab4:	bl	_llm_rows
     ab8:	mov	w8, #0x10
     abc:	str	w8, [x20, #0x24]
     ac0:	mov	x0, x21
     ac4:	mov	x1, x20
     ac8:	mov	w2, #0x8
     acc:	bl	_llm_rows
     ad0:	mov	w8, #0x18
     ad4:	str	w8, [x20, #0x24]
     ad8:	mov	x0, x21
     adc:	mov	x1, x20
     ae0:	mov	w2, #0x8
     ae4:	bl	_llm_rows
     ae8:	mov	w8, #0x20
     aec:	str	w8, [x20, #0x24]
     af0:	mov	x0, x21
     af4:	mov	x1, x20
     af8:	mov	w2, #0x8
     afc:	bl	_llm_rows
     b00:	mov	w8, #0x28
     b04:	str	w8, [x20, #0x24]
     b08:	mov	x0, x21
     b0c:	mov	x1, x20
     b10:	mov	w2, #0x8
     b14:	bl	_llm_rows
     b18:	mov	w8, #0x30
     b1c:	str	w8, [x20, #0x24]
     b20:	mov	x0, x21
     b24:	mov	x1, x20
     b28:	mov	w2, #0x8
     b2c:	bl	_llm_rows
     b30:	mov	w8, #0x38
     b34:	str	w8, [x20, #0x24]
     b38:	mov	x0, x21
     b3c:	mov	x1, x20
     b40:	mov	w2, #0x8
     b44:	bl	_llm_rows
     b48:	add	w8, w27, #0x1
     b4c:	cmp	w8, w26
     b50:	cset	w8, eq
     b54:	csinc	w27, wzr, w27, eq
     b58:	cinc	w9, w28, eq
     b5c:	cmp	w9, w23
     b60:	cset	w10, eq
     b64:	ands	w8, w8, w10
     b68:	csel	w28, wzr, w9, ne
     b6c:	add	w25, w25, w8
     b70:	subs	w19, w19, #0x1
     b74:	b.eq	0xcc8
     b78:	ubfiz	x8, x27, #6, #32
     b7c:	cmp	x8, x24
     b80:	csel	x9, x8, xzr, ls
     b84:	subs	x10, x24, x9
     b88:	cmp	x10, #0x40
     b8c:	mov	w11, #0x40
     b90:	csel	x10, x10, x11, lo
     b94:	cmp	x24, x9
     b98:	stp	w27, w28, [x20]
     b9c:	str	w25, [x20, #0x8]
     ba0:	str	wzr, [x20, #0x24]
     ba4:	ccmp	x8, x24, #0x2, hi
     ba8:	csel	x22, x10, xzr, ls
     bac:	cmp	x22, #0x40
     bb0:	b.hs	0xa90
     bb4:	mov	x23, x26
     bb8:	lsr	x26, x22, #3
     bbc:	cmp	x22, #0x8
     bc0:	b.lo	0xc98
     bc4:	str	wzr, [x20, #0x24]
     bc8:	mov	x0, x21
     bcc:	mov	x1, x20
     bd0:	mov	w2, #0x8
     bd4:	bl	_llm_rows
     bd8:	cmp	x26, #0x1
     bdc:	b.eq	0xc98
     be0:	mov	w8, #0x8
     be4:	str	w8, [x20, #0x24]
     be8:	mov	x0, x21
     bec:	mov	x1, x20
     bf0:	mov	w2, #0x8
     bf4:	bl	_llm_rows
     bf8:	cmp	x26, #0x2
     bfc:	b.eq	0xc98
     c00:	mov	w8, #0x10
     c04:	str	w8, [x20, #0x24]
     c08:	mov	x0, x21
     c0c:	mov	x1, x20
     c10:	mov	w2, #0x8
     c14:	bl	_llm_rows
     c18:	cmp	x26, #0x3
     c1c:	b.eq	0xc98
     c20:	mov	w8, #0x18
     c24:	str	w8, [x20, #0x24]
     c28:	mov	x0, x21
     c2c:	mov	x1, x20
     c30:	mov	w2, #0x8
     c34:	bl	_llm_rows
     c38:	cmp	x26, #0x4
     c3c:	b.eq	0xc98
     c40:	mov	w8, #0x20
     c44:	str	w8, [x20, #0x24]
     c48:	mov	x0, x21
     c4c:	mov	x1, x20
     c50:	mov	w2, #0x8
     c54:	bl	_llm_rows
     c58:	cmp	x26, #0x5
     c5c:	b.eq	0xc98
     c60:	mov	w8, #0x28
     c64:	str	w8, [x20, #0x24]
     c68:	mov	x0, x21
     c6c:	mov	x1, x20
     c70:	mov	w2, #0x8
     c74:	bl	_llm_rows
     c78:	cmp	x26, #0x6
     c7c:	b.eq	0xc98
     c80:	mov	w8, #0x30
     c84:	str	w8, [x20, #0x24]
     c88:	mov	x0, x21
     c8c:	mov	x1, x20
     c90:	mov	w2, #0x8
     c94:	bl	_llm_rows
     c98:	and	w2, w22, #0x7
     c9c:	cbz	w2, 0xcb4
     ca0:	lsl	w8, w26, #3
     ca4:	str	w8, [x20, #0x24]
     ca8:	mov	x0, x21
     cac:	mov	x1, x20
     cb0:	bl	_llm_rows
     cb4:	mov	w8, #0x38
     cb8:	str	w8, [x20, #0x24]
     cbc:	mov	x26, x23
     cc0:	ldr	w23, [sp, #0xc]
     cc4:	b	0xb48
     cc8:	ldp	x29, x30, [sp, #0x60]
     ccc:	ldp	x20, x19, [sp, #0x50]
     cd0:	ldp	x22, x21, [sp, #0x40]
     cd4:	ldp	x24, x23, [sp, #0x30]
     cd8:	ldp	x26, x25, [sp, #0x20]
     cdc:	ldp	x28, x27, [sp, #0x10]
     ce0:	add	sp, sp, #0x70
     ce4:	ret

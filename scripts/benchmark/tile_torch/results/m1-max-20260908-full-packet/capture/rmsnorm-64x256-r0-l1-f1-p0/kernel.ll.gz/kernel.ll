; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [8192 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [8192 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.spill = alloca float, align 4
  store float 0.000000e+00, ptr %.spill, align 4
  %.spill4 = alloca i64, align 8
  store i64 0, ptr %.spill4, align 4
  %.spill5 = alloca i64, align 8
  store i64 0, ptr %.spill5, align 4
  %.spill6 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill6, align 64
  %.spill7 = alloca i64, align 8
  store i64 0, ptr %.spill7, align 4
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.slot8 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot8, align 32
  %.slot9 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot9, align 32
  %.slot10 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot10, align 32
  %.slot11 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot11, align 32
  %.spill12 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill12, align 32
  %tile_snapshot.spill13 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill13, align 64
  %.slot14 = alloca i64, align 8
  store i64 0, ptr %.slot14, align 4
  %.spill15 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill15, align 32
  %.slot16 = alloca i64, align 8
  store i64 0, ptr %.slot16, align 4
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert17 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat18 = shufflevector <8 x i32> %.splatinsert17, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat18, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 64
  %.splatinsert19 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat20 = shufflevector <8 x i32> %.splatinsert19, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat20, %41
  %44 = mul i32 %32, 1
  %.splatinsert21 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat22 = shufflevector <8 x i32> %.splatinsert21, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat22, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert23 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat24 = shufflevector <8 x i32> %.splatinsert23, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat24, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert25 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat26 = shufflevector <8 x i32> %.splatinsert25, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat26
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = zext <8 x i32> %53 to <8 x i64>
  %55 = select <8 x i1> %51, <8 x i64> %54, <8 x i64> zeroinitializer
  %56 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %57 = sdiv <8 x i64> %55, %56
  %58 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %59 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %60 = extractvalue { <8 x ptr>, <8 x i64> } %58, 0
  %61 = select <8 x i1> %51, <8 x ptr> %59, <8 x ptr> %60
  %62 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %63 = extractvalue { <8 x ptr>, <8 x i64> } %58, 1
  %64 = select <8 x i1> %51, <8 x i64> %62, <8 x i64> %63
  %65 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %61, 0
  %66 = insertvalue { <8 x ptr>, <8 x i64> } %65, <8 x i64> %64, 1
  store { <8 x ptr>, <8 x i64> } %66, ptr %tile_snapshot.spill, align 64
  store float 0.000000e+00, ptr %.spill, align 4
  store i64 0, ptr %.spill4, align 4
  store i64 0, ptr %.spill5, align 4
  %67 = add <8 x i64> %57, zeroinitializer
  %68 = add <8 x i64> zeroinitializer, %67
  %69 = mul <8 x i64> %68, splat (i64 256)
  %70 = load <8 x i64>, ptr %.spill6, align 64
  %71 = select <8 x i1> %51, <8 x i64> %69, <8 x i64> %70
  store <8 x i64> %71, ptr %.spill6, align 64
  %72 = add <8 x i64> %69, zeroinitializer
  %73 = extractvalue { ptr, i64 } %9, 0
  %74 = mul <8 x i64> %72, splat (i64 4)
  %75 = getelementptr i8, ptr %73, <8 x i64> %74
  %76 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %75, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %77 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %78 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %79 = add <8 x i64> %78, zeroinitializer
  %80 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %77, 0
  %81 = insertvalue { <8 x ptr>, <8 x i64> } %80, <8 x i64> %79, 1
  %82 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %83 = extractvalue { <8 x ptr>, <8 x i64> } %81, 1
  %84 = extractelement <8 x ptr> %82, i32 0
  %85 = extractelement <8 x i64> %83, i32 0
  %86 = sub i64 %85, 0
  %87 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %88 = select i1 %87, i64 %86, i64 0
  %private.contiguous.address = getelementptr i8, ptr %84, i64 %88
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %89 = select <8 x i1> %51, <8 x float> %76, <8 x float> %private.contiguous.preserve
  store <8 x float> %89, ptr %private.contiguous.address, align 4
  store i64 0, ptr %.spill7, align 4
  %90 = fmul <8 x float> %76, %76
  %91 = add <8 x i64> %69, splat (i64 1)
  %92 = extractvalue { ptr, i64 } %9, 0
  %93 = mul <8 x i64> %91, splat (i64 4)
  %94 = getelementptr i8, ptr %92, <8 x i64> %93
  %95 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %94, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %96 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %97 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %98 = add <8 x i64> %97, splat (i64 32)
  %99 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %96, 0
  %100 = insertvalue { <8 x ptr>, <8 x i64> } %99, <8 x i64> %98, 1
  %101 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %102 = extractvalue { <8 x ptr>, <8 x i64> } %100, 1
  %103 = extractelement <8 x ptr> %101, i32 0
  %104 = extractelement <8 x i64> %102, i32 0
  %105 = sub i64 %104, 0
  %106 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %107 = select i1 %106, i64 %105, i64 0
  %private.contiguous.address27 = getelementptr i8, ptr %103, i64 %107
  %private.contiguous.preserve28 = load <8 x float>, ptr %private.contiguous.address27, align 4
  %108 = select <8 x i1> %51, <8 x float> %95, <8 x float> %private.contiguous.preserve28
  store <8 x float> %108, ptr %private.contiguous.address27, align 4
  %109 = fmul <8 x float> %95, %95
  %110 = add <8 x i64> %69, splat (i64 2)
  %111 = extractvalue { ptr, i64 } %9, 0
  %112 = mul <8 x i64> %110, splat (i64 4)
  %113 = getelementptr i8, ptr %111, <8 x i64> %112
  %114 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %113, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %117 = add <8 x i64> %116, splat (i64 64)
  %118 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %115, 0
  %119 = insertvalue { <8 x ptr>, <8 x i64> } %118, <8 x i64> %117, 1
  %120 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %121 = extractvalue { <8 x ptr>, <8 x i64> } %119, 1
  %122 = extractelement <8 x ptr> %120, i32 0
  %123 = extractelement <8 x i64> %121, i32 0
  %124 = sub i64 %123, 0
  %125 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %126 = select i1 %125, i64 %124, i64 0
  %private.contiguous.address29 = getelementptr i8, ptr %122, i64 %126
  %private.contiguous.preserve30 = load <8 x float>, ptr %private.contiguous.address29, align 4
  %127 = select <8 x i1> %51, <8 x float> %114, <8 x float> %private.contiguous.preserve30
  store <8 x float> %127, ptr %private.contiguous.address29, align 4
  %128 = fmul <8 x float> %114, %114
  %129 = add <8 x i64> %69, splat (i64 3)
  %130 = extractvalue { ptr, i64 } %9, 0
  %131 = mul <8 x i64> %129, splat (i64 4)
  %132 = getelementptr i8, ptr %130, <8 x i64> %131
  %133 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %132, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %135 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %136 = add <8 x i64> %135, splat (i64 96)
  %137 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %134, 0
  %138 = insertvalue { <8 x ptr>, <8 x i64> } %137, <8 x i64> %136, 1
  %139 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %140 = extractvalue { <8 x ptr>, <8 x i64> } %138, 1
  %141 = extractelement <8 x ptr> %139, i32 0
  %142 = extractelement <8 x i64> %140, i32 0
  %143 = sub i64 %142, 0
  %144 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %145 = select i1 %144, i64 %143, i64 0
  %private.contiguous.address31 = getelementptr i8, ptr %141, i64 %145
  %private.contiguous.preserve32 = load <8 x float>, ptr %private.contiguous.address31, align 4
  %146 = select <8 x i1> %51, <8 x float> %133, <8 x float> %private.contiguous.preserve32
  store <8 x float> %146, ptr %private.contiguous.address31, align 4
  %147 = fmul <8 x float> %133, %133
  store i64 4, ptr %.slot, align 4
  %148 = load <8 x float>, ptr %.slot8, align 32
  %149 = select <8 x i1> %51, <8 x float> %90, <8 x float> %148
  store <8 x float> %149, ptr %.slot8, align 32
  %150 = load <8 x float>, ptr %.slot9, align 32
  %151 = select <8 x i1> %51, <8 x float> %109, <8 x float> %150
  store <8 x float> %151, ptr %.slot9, align 32
  %152 = load <8 x float>, ptr %.slot10, align 32
  %153 = select <8 x i1> %51, <8 x float> %128, <8 x float> %152
  store <8 x float> %153, ptr %.slot10, align 32
  %154 = load <8 x float>, ptr %.slot11, align 32
  %155 = select <8 x i1> %51, <8 x float> %147, <8 x float> %154
  store <8 x float> %155, ptr %.slot11, align 32
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %156 = icmp slt i64 %.state, 256
  br i1 %156, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state33 = load i64, ptr %.slot, align 4
  %157 = add i64 %.state33, 0
  %158 = sdiv i64 %157, 1
  %.spill.load = load i64, ptr %.spill5, align 4
  %159 = add i64 %.spill.load, %158
  %160 = add i64 0, %159
  %.spill.load34 = load <8 x i64>, ptr %.spill6, align 64
  %.splatinsert35 = insertelement <8 x i64> poison, i64 %160, i64 0
  %.splat36 = shufflevector <8 x i64> %.splatinsert35, <8 x i64> poison, <8 x i32> zeroinitializer
  %161 = add <8 x i64> %.spill.load34, %.splat36
  %162 = extractvalue { ptr, i64 } %9, 0
  %163 = mul <8 x i64> %161, splat (i64 4)
  %164 = getelementptr i8, ptr %162, <8 x i64> %163
  %165 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %164, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.splatinsert37 = insertelement <8 x i64> poison, i64 %159, i64 0
  %.splat38 = shufflevector <8 x i64> %.splatinsert37, <8 x i64> poison, <8 x i32> zeroinitializer
  %168 = mul <8 x i64> %.splat38, splat (i64 32)
  %169 = add <8 x i64> %167, %168
  %170 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %166, 0
  %171 = insertvalue { <8 x ptr>, <8 x i64> } %170, <8 x i64> %169, 1
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %171, 1
  %174 = extractelement <8 x ptr> %172, i32 0
  %175 = extractelement <8 x i64> %173, i32 0
  %176 = sub i64 %175, 0
  %177 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %178 = select i1 %177, i64 %176, i64 0
  %private.contiguous.address39 = getelementptr i8, ptr %174, i64 %178
  %private.contiguous.preserve40 = load <8 x float>, ptr %private.contiguous.address39, align 4
  %179 = select <8 x i1> %51, <8 x float> %165, <8 x float> %private.contiguous.preserve40
  store <8 x float> %179, ptr %private.contiguous.address39, align 4
  %180 = fmul <8 x float> %165, %165
  %.state41 = load <8 x float>, ptr %.slot8, align 32
  %181 = fadd <8 x float> %.state41, %180
  %.state42 = load i64, ptr %.slot, align 4
  %182 = add i64 %.state42, 1
  %183 = sdiv i64 %182, 1
  %.spill.load43 = load i64, ptr %.spill5, align 4
  %184 = add i64 %.spill.load43, %183
  %185 = add i64 0, %184
  %.spill.load44 = load <8 x i64>, ptr %.spill6, align 64
  %.splatinsert45 = insertelement <8 x i64> poison, i64 %185, i64 0
  %.splat46 = shufflevector <8 x i64> %.splatinsert45, <8 x i64> poison, <8 x i32> zeroinitializer
  %186 = add <8 x i64> %.spill.load44, %.splat46
  %187 = extractvalue { ptr, i64 } %9, 0
  %188 = mul <8 x i64> %186, splat (i64 4)
  %189 = getelementptr i8, ptr %187, <8 x i64> %188
  %190 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %189, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load47 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %191 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load47, 0
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load47, 1
  %.splatinsert48 = insertelement <8 x i64> poison, i64 %184, i64 0
  %.splat49 = shufflevector <8 x i64> %.splatinsert48, <8 x i64> poison, <8 x i32> zeroinitializer
  %193 = mul <8 x i64> %.splat49, splat (i64 32)
  %194 = add <8 x i64> %192, %193
  %195 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %191, 0
  %196 = insertvalue { <8 x ptr>, <8 x i64> } %195, <8 x i64> %194, 1
  %197 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %198 = extractvalue { <8 x ptr>, <8 x i64> } %196, 1
  %199 = extractelement <8 x ptr> %197, i32 0
  %200 = extractelement <8 x i64> %198, i32 0
  %201 = sub i64 %200, 0
  %202 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %203 = select i1 %202, i64 %201, i64 0
  %private.contiguous.address50 = getelementptr i8, ptr %199, i64 %203
  %private.contiguous.preserve51 = load <8 x float>, ptr %private.contiguous.address50, align 4
  %204 = select <8 x i1> %51, <8 x float> %190, <8 x float> %private.contiguous.preserve51
  store <8 x float> %204, ptr %private.contiguous.address50, align 4
  %205 = fmul <8 x float> %190, %190
  %.state52 = load <8 x float>, ptr %.slot9, align 32
  %206 = fadd <8 x float> %.state52, %205
  %.state53 = load i64, ptr %.slot, align 4
  %207 = add i64 %.state53, 2
  %208 = sdiv i64 %207, 1
  %.spill.load54 = load i64, ptr %.spill5, align 4
  %209 = add i64 %.spill.load54, %208
  %210 = add i64 0, %209
  %.spill.load55 = load <8 x i64>, ptr %.spill6, align 64
  %.splatinsert56 = insertelement <8 x i64> poison, i64 %210, i64 0
  %.splat57 = shufflevector <8 x i64> %.splatinsert56, <8 x i64> poison, <8 x i32> zeroinitializer
  %211 = add <8 x i64> %.spill.load55, %.splat57
  %212 = extractvalue { ptr, i64 } %9, 0
  %213 = mul <8 x i64> %211, splat (i64 4)
  %214 = getelementptr i8, ptr %212, <8 x i64> %213
  %215 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %214, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load58 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load58, 0
  %217 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load58, 1
  %.splatinsert59 = insertelement <8 x i64> poison, i64 %209, i64 0
  %.splat60 = shufflevector <8 x i64> %.splatinsert59, <8 x i64> poison, <8 x i32> zeroinitializer
  %218 = mul <8 x i64> %.splat60, splat (i64 32)
  %219 = add <8 x i64> %217, %218
  %220 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %216, 0
  %221 = insertvalue { <8 x ptr>, <8 x i64> } %220, <8 x i64> %219, 1
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %221, 1
  %224 = extractelement <8 x ptr> %222, i32 0
  %225 = extractelement <8 x i64> %223, i32 0
  %226 = sub i64 %225, 0
  %227 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %228 = select i1 %227, i64 %226, i64 0
  %private.contiguous.address61 = getelementptr i8, ptr %224, i64 %228
  %private.contiguous.preserve62 = load <8 x float>, ptr %private.contiguous.address61, align 4
  %229 = select <8 x i1> %51, <8 x float> %215, <8 x float> %private.contiguous.preserve62
  store <8 x float> %229, ptr %private.contiguous.address61, align 4
  %230 = fmul <8 x float> %215, %215
  %.state63 = load <8 x float>, ptr %.slot10, align 32
  %231 = fadd <8 x float> %.state63, %230
  %.state64 = load i64, ptr %.slot, align 4
  %232 = add i64 %.state64, 3
  %233 = sdiv i64 %232, 1
  %.spill.load65 = load i64, ptr %.spill5, align 4
  %234 = add i64 %.spill.load65, %233
  %235 = add i64 0, %234
  %.spill.load66 = load <8 x i64>, ptr %.spill6, align 64
  %.splatinsert67 = insertelement <8 x i64> poison, i64 %235, i64 0
  %.splat68 = shufflevector <8 x i64> %.splatinsert67, <8 x i64> poison, <8 x i32> zeroinitializer
  %236 = add <8 x i64> %.spill.load66, %.splat68
  %237 = extractvalue { ptr, i64 } %9, 0
  %238 = mul <8 x i64> %236, splat (i64 4)
  %239 = getelementptr i8, ptr %237, <8 x i64> %238
  %240 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %239, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load69 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load69, 0
  %242 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load69, 1
  %.splatinsert70 = insertelement <8 x i64> poison, i64 %234, i64 0
  %.splat71 = shufflevector <8 x i64> %.splatinsert70, <8 x i64> poison, <8 x i32> zeroinitializer
  %243 = mul <8 x i64> %.splat71, splat (i64 32)
  %244 = add <8 x i64> %242, %243
  %245 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %241, 0
  %246 = insertvalue { <8 x ptr>, <8 x i64> } %245, <8 x i64> %244, 1
  %247 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %246, 1
  %249 = extractelement <8 x ptr> %247, i32 0
  %250 = extractelement <8 x i64> %248, i32 0
  %251 = sub i64 %250, 0
  %252 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %253 = select i1 %252, i64 %251, i64 0
  %private.contiguous.address72 = getelementptr i8, ptr %249, i64 %253
  %private.contiguous.preserve73 = load <8 x float>, ptr %private.contiguous.address72, align 4
  %254 = select <8 x i1> %51, <8 x float> %240, <8 x float> %private.contiguous.preserve73
  store <8 x float> %254, ptr %private.contiguous.address72, align 4
  %255 = fmul <8 x float> %240, %240
  %.state74 = load <8 x float>, ptr %.slot11, align 32
  %256 = fadd <8 x float> %.state74, %255
  %.state75 = load i64, ptr %.slot, align 4
  %257 = add i64 %.state75, 4
  store i64 %257, ptr %.slot, align 4
  %258 = load <8 x float>, ptr %.slot8, align 32
  %259 = select <8 x i1> %51, <8 x float> %181, <8 x float> %258
  store <8 x float> %259, ptr %.slot8, align 32
  %260 = load <8 x float>, ptr %.slot9, align 32
  %261 = select <8 x i1> %51, <8 x float> %206, <8 x float> %260
  store <8 x float> %261, ptr %.slot9, align 32
  %262 = load <8 x float>, ptr %.slot10, align 32
  %263 = select <8 x i1> %51, <8 x float> %231, <8 x float> %262
  store <8 x float> %263, ptr %.slot10, align 32
  %264 = load <8 x float>, ptr %.slot11, align 32
  %265 = select <8 x i1> %51, <8 x float> %256, <8 x float> %264
  store <8 x float> %265, ptr %.slot11, align 32
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %.spill.load76 = load float, ptr %.spill, align 4
  %.splatinsert77 = insertelement <8 x float> poison, float %.spill.load76, i64 0
  %.splat78 = shufflevector <8 x float> %.splatinsert77, <8 x float> poison, <8 x i32> zeroinitializer
  %.state79 = load <8 x float>, ptr %.slot8, align 32
  %266 = fadd <8 x float> %.splat78, %.state79
  %.state80 = load <8 x float>, ptr %.slot9, align 32
  %267 = fadd <8 x float> %266, %.state80
  %.state81 = load <8 x float>, ptr %.slot10, align 32
  %268 = fadd <8 x float> %267, %.state81
  %.state82 = load <8 x float>, ptr %.slot11, align 32
  %269 = fadd <8 x float> %268, %.state82
  %270 = fdiv <8 x float> %269, splat (float 2.560000e+02)
  %271 = load <8 x float>, ptr %.spill12, align 32
  %272 = select <8 x i1> %51, <8 x float> %270, <8 x float> %271
  store <8 x float> %272, ptr %.spill12, align 32
  %273 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %274 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %275 = extractvalue { <8 x ptr>, <8 x i64> } %273, 0
  %276 = select <8 x i1> %51, <8 x ptr> %274, <8 x ptr> %275
  %277 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %278 = extractvalue { <8 x ptr>, <8 x i64> } %273, 1
  %279 = select <8 x i1> %51, <8 x i64> %277, <8 x i64> %278
  %280 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %276, 0
  %281 = insertvalue { <8 x ptr>, <8 x i64> } %280, <8 x i64> %279, 1
  store { <8 x ptr>, <8 x i64> } %281, ptr %tile_snapshot.spill13, align 64
  store i64 0, ptr %.slot14, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state83 = load i64, ptr %.slot14, align 4
  %282 = icmp slt i64 %.state83, 256
  br i1 %282, label %direct.true84, label %direct.false85

direct.schedule.5:                                ; preds = %direct.true84
  %.spill.load86 = load i64, ptr %.spill4, align 4
  %283 = add i64 %.spill.load86, 0
  %.state87 = load i64, ptr %.slot14, align 4
  %284 = add i64 0, %.state87
  %285 = mul i64 %283, 256
  %286 = add i64 %285, %284
  %287 = extractvalue { ptr, i64 } %15, 0
  %288 = mul i64 %286, 4
  %289 = getelementptr i8, ptr %287, i64 %288
  %290 = load float, ptr %289, align 4
  %.splatinsert88 = insertelement <8 x float> poison, float %290, i64 0
  %.splat89 = shufflevector <8 x float> %.splatinsert88, <8 x float> poison, <8 x i32> zeroinitializer
  %tile_snapshot.spill.load90 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %291 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load90, 0
  %292 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load90, 1
  %.state91 = load i64, ptr %.slot14, align 4
  %.splatinsert92 = insertelement <8 x i64> poison, i64 %.state91, i64 0
  %.splat93 = shufflevector <8 x i64> %.splatinsert92, <8 x i64> poison, <8 x i32> zeroinitializer
  %293 = mul <8 x i64> %.splat93, splat (i64 32)
  %294 = add <8 x i64> %292, %293
  %295 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %291, 0
  %296 = insertvalue { <8 x ptr>, <8 x i64> } %295, <8 x i64> %294, 1
  %297 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %298 = extractvalue { <8 x ptr>, <8 x i64> } %296, 1
  %299 = extractelement <8 x ptr> %297, i32 0
  %300 = extractelement <8 x i64> %298, i32 0
  %301 = sub i64 %300, 0
  %302 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %303 = select i1 %302, i64 %301, i64 0
  %private.contiguous.address94 = getelementptr i8, ptr %299, i64 %303
  %private.contiguous.preserve95 = load <8 x float>, ptr %private.contiguous.address94, align 4
  %304 = select <8 x i1> %51, <8 x float> %.splat89, <8 x float> %private.contiguous.preserve95
  store <8 x float> %304, ptr %private.contiguous.address94, align 4
  %.state96 = load i64, ptr %.slot14, align 4
  %305 = add i64 %.state96, 1
  store i64 %305, ptr %.slot14, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false85
  %.spill.load97 = load <8 x float>, ptr %.spill12, align 32
  %306 = fadd <8 x float> %.spill.load97, splat (float 0x3EE4F8B580000000)
  %307 = call <8 x float> @llvm.sqrt.v8f32(<8 x float> %306)
  %308 = load <8 x float>, ptr %.spill15, align 32
  %309 = select <8 x i1> %51, <8 x float> %307, <8 x float> %308
  store <8 x float> %309, ptr %.spill15, align 32
  store i64 0, ptr %.slot16, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state98 = load i64, ptr %.slot16, align 4
  %310 = icmp slt i64 %.state98, 256
  br i1 %310, label %direct.true99, label %direct.false100

direct.schedule.8:                                ; preds = %direct.true99
  %.state101 = load i64, ptr %.slot16, align 4
  %311 = add i64 0, %.state101
  %.spill.load102 = load <8 x i64>, ptr %.spill6, align 64
  %.splatinsert103 = insertelement <8 x i64> poison, i64 %311, i64 0
  %.splat104 = shufflevector <8 x i64> %.splatinsert103, <8 x i64> poison, <8 x i32> zeroinitializer
  %312 = add <8 x i64> %.spill.load102, %.splat104
  %.spill.load105 = load i64, ptr %.spill7, align 4
  %.state106 = load i64, ptr %.slot16, align 4
  %313 = add i64 %.spill.load105, %.state106
  %.spill.load107 = load i64, ptr %.spill7, align 4
  %314 = add i64 %.spill.load107, %313
  %tile_snapshot.spill.load108 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load108, 0
  %316 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load108, 1
  %.splatinsert109 = insertelement <8 x i64> poison, i64 %314, i64 0
  %.splat110 = shufflevector <8 x i64> %.splatinsert109, <8 x i64> poison, <8 x i32> zeroinitializer
  %317 = mul <8 x i64> %.splat110, splat (i64 32)
  %318 = add <8 x i64> %316, %317
  %319 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %315, 0
  %320 = insertvalue { <8 x ptr>, <8 x i64> } %319, <8 x i64> %318, 1
  %321 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %320, 1
  %323 = extractelement <8 x ptr> %321, i32 0
  %324 = extractelement <8 x i64> %322, i32 0
  %325 = sub i64 %324, 0
  %326 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %327 = select i1 %326, i64 %325, i64 0
  %private.contiguous.address111 = getelementptr i8, ptr %323, i64 %327
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address111, align 4
  %328 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %.spill.load112 = load <8 x float>, ptr %.spill15, align 32
  %329 = fdiv <8 x float> %328, %.spill.load112
  %tile_snapshot.spill.load113 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %330 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load113, 0
  %331 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load113, 1
  %.splatinsert114 = insertelement <8 x i64> poison, i64 %313, i64 0
  %.splat115 = shufflevector <8 x i64> %.splatinsert114, <8 x i64> poison, <8 x i32> zeroinitializer
  %332 = mul <8 x i64> %.splat115, splat (i64 32)
  %333 = add <8 x i64> %331, %332
  %334 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %330, 0
  %335 = insertvalue { <8 x ptr>, <8 x i64> } %334, <8 x i64> %333, 1
  %336 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %337 = extractvalue { <8 x ptr>, <8 x i64> } %335, 1
  %338 = extractelement <8 x ptr> %336, i32 0
  %339 = extractelement <8 x i64> %337, i32 0
  %340 = sub i64 %339, 0
  %341 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %342 = select i1 %341, i64 %340, i64 0
  %private.contiguous.address116 = getelementptr i8, ptr %338, i64 %342
  %private.contiguous.load117 = load <8 x float>, ptr %private.contiguous.address116, align 4
  %343 = select <8 x i1> %51, <8 x float> %private.contiguous.load117, <8 x float> zeroinitializer
  %344 = fmul <8 x float> %329, %343
  %345 = extractvalue { ptr, i64 } %27, 0
  %346 = mul <8 x i64> %312, splat (i64 4)
  %347 = getelementptr i8, ptr %345, <8 x i64> %346
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %344, <8 x ptr> %347, i32 1, <8 x i1> %51)
  %.state118 = load i64, ptr %.slot16, align 4
  %348 = add i64 %.state118, 1
  store i64 %348, ptr %.slot16, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false100
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true84:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false85:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true99:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false100:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.9
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.sqrt.v8f32(<8 x float>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #2

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 64
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 64
  %3 = sub i64 64, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 8
  %8 = icmp uge i64 %packet.range.remaining, 64
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index3 = add i32 %base.thread.index, 32
  store i32 %packet.thread.index3, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index4 = add i32 %base.thread.index, 40
  store i32 %packet.thread.index4, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index5 = add i32 %base.thread.index, 48
  store i32 %packet.thread.index5, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index6 = add i32 %base.thread.index, 56
  store i32 %packet.thread.index6, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }

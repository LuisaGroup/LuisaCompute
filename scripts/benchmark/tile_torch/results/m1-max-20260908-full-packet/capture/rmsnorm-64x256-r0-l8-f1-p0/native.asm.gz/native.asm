/tmp/luisa-full-packet.UEezjO/capture/rmsnorm-64x256-r0-l8-f1-p0/object/tile_xir_w8_63769_1788856227241410_0.o:
(__TEXT,__text) section
_llm_rows:
       0:	stp	d15, d14, [sp, #-0x50]!
       4:	stp	d13, d12, [sp, #0x10]
       8:	stp	d11, d10, [sp, #0x20]
       c:	stp	d9, d8, [sp, #0x30]
      10:	stp	x28, x27, [sp, #0x40]
      14:	sub	sp, sp, #0xa00
      18:	dup.4s	v1, w2
      1c:	adrp	x8, lCPI0_1@PAGE
      20:	ldr	q2, [x8, lCPI0_1@PAGEOFF]
      24:	adrp	x8, lCPI0_2@PAGE
      28:	ldr	q0, [x8, lCPI0_2@PAGEOFF]
      2c:	cmhi.4s	v0, v1, v0
      30:	cmhi.4s	v1, v1, v2
      34:	uzp1.8h	v3, v1, v0
      38:	umaxv.8h	h2, v3
      3c:	fmov	w8, s2
      40:	tbz	w8, #0x0, 0xd98
      44:	ldr	x9, [x0]
      48:	adrp	x8, lCPI0_0@PAGE
      4c:	ldr	q2, [x8, lCPI0_0@PAGEOFF]
      50:	str	q3, [sp, #0x40]
      54:	and.16b	v2, v3, v2
      58:	addv.8h	h12, v2
      5c:	fmov	w10, s12
      60:	and	w8, w10, #0xff
      64:	sshll2.2d	v16, v1, #0x0
      68:	sshll.2d	v23, v0, #0x0
      6c:	sshll.2d	v24, v1, #0x0
      70:	ldr	w11, [x1]
      74:	ldr	w12, [x1, #0x24]
      78:	add	w11, w12, w11, lsl #9
      7c:	adrp	x12, lCPI0_3@PAGE
      80:	ldr	q2, [x12, lCPI0_3@PAGEOFF]
      84:	str	q2, [sp, #0x70]
      88:	and.16b	v2, v24, v2
      8c:	adrp	x12, lCPI0_4@PAGE
      90:	ldr	q18, [x12, lCPI0_4@PAGEOFF]
      94:	adrp	x12, lCPI0_5@PAGE
      98:	ldr	q19, [x12, lCPI0_5@PAGEOFF]
      9c:	and.16b	v5, v16, v19
      a0:	lsr	w11, w11, #3
      a4:	dup.4s	v3, w11
      a8:	and.16b	v4, v1, v3
      ac:	and.16b	v3, v0, v3
      b0:	ushll.2d	v25, v4, #0x8
      b4:	ushll2.2d	v26, v4, #0x8
      b8:	stp	q5, q2, [sp, #0x20]
      bc:	orr.16b	v4, v26, v5
      c0:	orr.16b	v5, v25, v2
      c4:	shl.2d	v5, v5, #0x2
      c8:	dup.2d	v20, x9
      cc:	add.2d	v5, v20, v5
      d0:	movi.2d	v28, #0000000000000000
      d4:	movi.2d	v29, #0000000000000000
      d8:	tbnz	w10, #0x0, 0xdb4
      dc:	adrp	x9, lCPI0_6@PAGE
      e0:	and.16b	v2, v23, v18
      e4:	ushll.2d	v27, v3, #0x8
      e8:	shl.2d	v4, v4, #0x2
      ec:	tbnz	w8, #0x1, 0xdd0
      f0:	sshll2.2d	v21, v0, #0x0
      f4:	ldr	q22, [x9, lCPI0_6@PAGEOFF]
      f8:	orr.16b	v5, v27, v2
      fc:	add.2d	v4, v20, v4
     100:	tbnz	w8, #0x2, 0xdec
     104:	and.16b	v6, v21, v22
     108:	ushll2.2d	v30, v3, #0x8
     10c:	shl.2d	v3, v5, #0x2
     110:	tbnz	w8, #0x3, 0xe04
     114:	orr.16b	v4, v30, v6
     118:	add.2d	v3, v20, v3
     11c:	tbnz	w8, #0x4, 0xe18
     120:	shl.2d	v4, v4, #0x2
     124:	tbnz	w8, #0x5, 0xe28
     128:	add.2d	v3, v20, v4
     12c:	tbnz	w8, #0x6, 0xe38
     130:	add	x9, sp, #0x110
     134:	stp	q6, q2, [sp]
     138:	tbz	w8, #0x7, 0x144
     13c:	mov.d	x8, v3[1]
     140:	ld1.s	{ v29 }[3], [x8]
     144:	ldr	x10, [x0, #0x10]
     148:	ldr	x8, [x0, #0x30]
     14c:	fmov	w12, s12
     150:	and	w11, w12, #0xff
     154:	sshll.2d	v3, v0, #0x0
     158:	sshll.2d	v4, v1, #0x0
     15c:	str	q28, [x9, #0x4f0]
     160:	str	q29, [x9, #0x500]
     164:	adrp	x13, lCPI0_7@PAGE
     168:	ldr	q5, [x13, lCPI0_7@PAGEOFF]
     16c:	and.16b	v4, v4, v5
     170:	adrp	x13, lCPI0_8@PAGE
     174:	ldr	q5, [x13, lCPI0_8@PAGEOFF]
     178:	adrp	x13, lCPI0_9@PAGE
     17c:	ldr	q6, [x13, lCPI0_9@PAGEOFF]
     180:	and.16b	v6, v16, v6
     184:	orr.16b	v7, v26, v6
     188:	orr.16b	v4, v25, v4
     18c:	shl.2d	v4, v4, #0x2
     190:	add.2d	v6, v20, v4
     194:	movi.2d	v4, #0000000000000000
     198:	movi.2d	v31, #0000000000000000
     19c:	ldr	q2, [sp, #0x70]
     1a0:	tbnz	w12, #0x0, 0xe50
     1a4:	adrp	x12, lCPI0_10@PAGE
     1a8:	and.16b	v3, v3, v5
     1ac:	shl.2d	v7, v7, #0x2
     1b0:	tbnz	w11, #0x1, 0xe68
     1b4:	ldr	q5, [x12, lCPI0_10@PAGEOFF]
     1b8:	orr.16b	v6, v27, v3
     1bc:	add.2d	v3, v20, v7
     1c0:	tbnz	w11, #0x2, 0xe80
     1c4:	and.16b	v5, v21, v5
     1c8:	shl.2d	v6, v6, #0x2
     1cc:	tbnz	w11, #0x3, 0xe94
     1d0:	orr.16b	v5, v30, v5
     1d4:	add.2d	v3, v20, v6
     1d8:	tbnz	w11, #0x4, 0xea8
     1dc:	shl.2d	v5, v5, #0x2
     1e0:	tbnz	w11, #0x5, 0xeb8
     1e4:	add.2d	v3, v20, v5
     1e8:	tbnz	w11, #0x6, 0xec8
     1ec:	tbz	w11, #0x7, 0x1f8
     1f0:	mov.d	x11, v3[1]
     1f4:	ld1.s	{ v31 }[3], [x11]
     1f8:	fmov	w12, s12
     1fc:	and	w11, w12, #0xff
     200:	sshll.2d	v3, v0, #0x0
     204:	sshll.2d	v5, v1, #0x0
     208:	str	q4, [x9, #0x510]
     20c:	str	q31, [x9, #0x520]
     210:	adrp	x13, lCPI0_11@PAGE
     214:	ldr	q6, [x13, lCPI0_11@PAGEOFF]
     218:	and.16b	v5, v5, v6
     21c:	adrp	x13, lCPI0_12@PAGE
     220:	ldr	q7, [x13, lCPI0_12@PAGEOFF]
     224:	adrp	x13, lCPI0_13@PAGE
     228:	ldr	q6, [x13, lCPI0_13@PAGEOFF]
     22c:	and.16b	v6, v16, v6
     230:	orr.16b	v9, v26, v6
     234:	orr.16b	v5, v25, v5
     238:	shl.2d	v5, v5, #0x2
     23c:	add.2d	v8, v20, v5
     240:	movi.2d	v5, #0000000000000000
     244:	movi.2d	v6, #0000000000000000
     248:	tbnz	w12, #0x0, 0xed8
     24c:	adrp	x12, lCPI0_14@PAGE
     250:	and.16b	v3, v3, v7
     254:	shl.2d	v9, v9, #0x2
     258:	tbnz	w11, #0x1, 0xef0
     25c:	ldr	q7, [x12, lCPI0_14@PAGEOFF]
     260:	orr.16b	v8, v27, v3
     264:	add.2d	v3, v20, v9
     268:	tbnz	w11, #0x2, 0xf08
     26c:	and.16b	v7, v21, v7
     270:	shl.2d	v8, v8, #0x2
     274:	tbnz	w11, #0x3, 0xf1c
     278:	orr.16b	v7, v30, v7
     27c:	add.2d	v3, v20, v8
     280:	tbnz	w11, #0x4, 0xf30
     284:	shl.2d	v7, v7, #0x2
     288:	tbnz	w11, #0x5, 0xf40
     28c:	add.2d	v3, v20, v7
     290:	tbnz	w11, #0x6, 0xf50
     294:	tbz	w11, #0x7, 0x2a0
     298:	mov.d	x11, v3[1]
     29c:	ld1.s	{ v6 }[3], [x11]
     2a0:	fmov	w12, s12
     2a4:	and	w11, w12, #0xff
     2a8:	sshll.2d	v8, v0, #0x0
     2ac:	sshll.2d	v3, v1, #0x0
     2b0:	str	q5, [x9, #0x530]
     2b4:	str	q6, [x9, #0x540]
     2b8:	adrp	x13, lCPI0_15@PAGE
     2bc:	ldr	q7, [x13, lCPI0_15@PAGEOFF]
     2c0:	and.16b	v3, v3, v7
     2c4:	adrp	x13, lCPI0_16@PAGE
     2c8:	ldr	q9, [x13, lCPI0_16@PAGEOFF]
     2cc:	adrp	x13, lCPI0_17@PAGE
     2d0:	ldr	q7, [x13, lCPI0_17@PAGEOFF]
     2d4:	and.16b	v7, v16, v7
     2d8:	orr.16b	v11, v26, v7
     2dc:	orr.16b	v3, v25, v3
     2e0:	shl.2d	v3, v3, #0x2
     2e4:	add.2d	v10, v20, v3
     2e8:	movi.2d	v3, #0000000000000000
     2ec:	movi.2d	v7, #0000000000000000
     2f0:	tbnz	w12, #0x0, 0xf60
     2f4:	adrp	x12, lCPI0_18@PAGE
     2f8:	and.16b	v8, v8, v9
     2fc:	shl.2d	v11, v11, #0x2
     300:	tbnz	w11, #0x1, 0xf78
     304:	ldr	q9, [x12, lCPI0_18@PAGEOFF]
     308:	orr.16b	v10, v27, v8
     30c:	add.2d	v8, v20, v11
     310:	tbnz	w11, #0x2, 0xf90
     314:	and.16b	v9, v21, v9
     318:	shl.2d	v10, v10, #0x2
     31c:	tbnz	w11, #0x3, 0xfa4
     320:	orr.16b	v9, v30, v9
     324:	add.2d	v8, v20, v10
     328:	tbnz	w11, #0x4, 0xfb8
     32c:	shl.2d	v9, v9, #0x2
     330:	tbnz	w11, #0x5, 0xfc8
     334:	add.2d	v8, v20, v9
     338:	tbz	w11, #0x6, 0x344
     33c:	fmov	x12, d8
     340:	ld1.s	{ v7 }[2], [x12]
     344:	fmov	w13, s12
     348:	fmul.4s	v28, v28, v28
     34c:	fmul.4s	v29, v29, v29
     350:	fmul.4s	v4, v4, v4
     354:	fmul.4s	v31, v31, v31
     358:	fmul.4s	v5, v5, v5
     35c:	fmul.4s	v6, v6, v6
     360:	tbz	w11, #0x7, 0x36c
     364:	mov.d	x11, v8[1]
     368:	ld1.s	{ v7 }[3], [x11]
     36c:	mov	x12, #0x0
     370:	and.16b	v8, v21, v30
     374:	and.16b	v9, v16, v26
     378:	and	w11, w13, #0xff
     37c:	and.16b	v10, v23, v27
     380:	and.16b	v23, v24, v25
     384:	str	q3, [x9, #0x550]
     388:	str	q7, [x9, #0x560]
     38c:	fmul.4s	v3, v3, v3
     390:	fmul.4s	v7, v7, v7
     394:	and.16b	v25, v0, v29
     398:	and.16b	v24, v1, v28
     39c:	and.16b	v29, v0, v31
     3a0:	and.16b	v28, v1, v4
     3a4:	and.16b	v26, v0, v6
     3a8:	and.16b	v30, v1, v5
     3ac:	and.16b	v27, v0, v7
     3b0:	add	x13, sp, #0x600
     3b4:	and.16b	v31, v1, v3
     3b8:	add	x13, x13, #0xe0
     3bc:	mov	w14, #0x20
     3c0:	fmov	w15, s12
     3c4:	sshll.2d	v4, v0, #0x0
     3c8:	sshll.2d	v3, v1, #0x0
     3cc:	stp	q3, q4, [sp, #0x50]
     3d0:	b	0x45c
     3d4:	fmul.4s	v2, v14, v14
     3d8:	fmul.4s	v11, v13, v13
     3dc:	fadd.4s	v11, v24, v11
     3e0:	fadd.4s	v2, v25, v2
     3e4:	fmul.4s	v4, v4, v4
     3e8:	fmul.4s	v12, v15, v15
     3ec:	fadd.4s	v12, v28, v12
     3f0:	fadd.4s	v4, v29, v4
     3f4:	fmul.4s	v6, v6, v6
     3f8:	fmul.4s	v5, v5, v5
     3fc:	fadd.4s	v5, v30, v5
     400:	fadd.4s	v6, v26, v6
     404:	ldp	q13, q14, [x13]
     408:	bit.16b	v14, v3, v0
     40c:	bit.16b	v13, v7, v1
     410:	stp	q13, q14, [x13], #0x80
     414:	fmul.4s	v7, v7, v7
     418:	fmul.4s	v3, v3, v3
     41c:	fadd.4s	v3, v27, v3
     420:	fadd.4s	v7, v31, v7
     424:	bit.16b	v25, v2, v0
     428:	bit.16b	v24, v11, v1
     42c:	bit.16b	v29, v4, v0
     430:	bit.16b	v28, v12, v1
     434:	bit.16b	v26, v6, v0
     438:	add	x12, x12, #0x4
     43c:	bit.16b	v30, v5, v1
     440:	add	x14, x14, #0x20
     444:	bit.16b	v31, v7, v1
     448:	bit.16b	v27, v3, v0
     44c:	cmp	x12, #0x1c
     450:	mov.16b	v12, v17
     454:	ldr	q2, [sp, #0x70]
     458:	b.hs	0x8fc
     45c:	dup.2d	v3, x14
     460:	orr.16b	v4, v3, v2
     464:	ldr	q5, [sp, #0x50]
     468:	and.16b	v4, v5, v4
     46c:	add.2d	v4, v4, v23
     470:	shl.2d	v4, v4, #0x2
     474:	add.2d	v4, v20, v4
     478:	movi.2d	v13, #0000000000000000
     47c:	movi.2d	v14, #0000000000000000
     480:	tbnz	w15, #0x0, 0x704
     484:	and	w16, w15, #0xff
     488:	tbnz	w16, #0x1, 0x714
     48c:	orr.16b	v4, v3, v19
     490:	and.16b	v4, v16, v4
     494:	add.2d	v4, v4, v9
     498:	shl.2d	v4, v4, #0x2
     49c:	add.2d	v4, v20, v4
     4a0:	tbnz	w16, #0x2, 0x734
     4a4:	tbz	w16, #0x3, 0x4b0
     4a8:	mov.d	x17, v4[1]
     4ac:	ld1.s	{ v13 }[3], [x17]
     4b0:	orr.16b	v4, v3, v18
     4b4:	ldr	q5, [sp, #0x60]
     4b8:	and.16b	v4, v5, v4
     4bc:	add.2d	v4, v4, v10
     4c0:	shl.2d	v4, v4, #0x2
     4c4:	add.2d	v4, v20, v4
     4c8:	tbnz	w16, #0x4, 0x744
     4cc:	tbnz	w16, #0x5, 0x750
     4d0:	orr.16b	v3, v3, v22
     4d4:	and.16b	v3, v21, v3
     4d8:	add.2d	v3, v3, v8
     4dc:	shl.2d	v3, v3, #0x2
     4e0:	add.2d	v3, v20, v3
     4e4:	tbnz	w16, #0x6, 0x770
     4e8:	tbz	w16, #0x7, 0x4f4
     4ec:	mov.d	x16, v3[1]
     4f0:	ld1.s	{ v14 }[3], [x16]
     4f4:	fmov	w16, s12
     4f8:	sshll.2d	v4, v1, #0x0
     4fc:	ldp	q3, q5, [x13, #-0x60]
     500:	bit.16b	v5, v14, v0
     504:	bit.16b	v3, v13, v1
     508:	stp	q3, q5, [x13, #-0x60]
     50c:	add	x17, x14, #0x8
     510:	dup.2d	v3, x17
     514:	orr.16b	v5, v3, v2
     518:	and.16b	v4, v4, v5
     51c:	add.2d	v4, v4, v23
     520:	shl.2d	v4, v4, #0x2
     524:	add.2d	v5, v20, v4
     528:	movi.2d	v15, #0000000000000000
     52c:	movi.2d	v4, #0000000000000000
     530:	tbnz	w16, #0x0, 0x780
     534:	and	w16, w16, #0xff
     538:	tbnz	w16, #0x1, 0x790
     53c:	orr.16b	v5, v3, v19
     540:	and.16b	v5, v16, v5
     544:	add.2d	v5, v5, v9
     548:	shl.2d	v5, v5, #0x2
     54c:	add.2d	v5, v20, v5
     550:	tbnz	w16, #0x2, 0x7b0
     554:	tbz	w16, #0x3, 0x560
     558:	mov.d	x17, v5[1]
     55c:	ld1.s	{ v15 }[3], [x17]
     560:	sshll.2d	v5, v0, #0x0
     564:	orr.16b	v6, v3, v18
     568:	and.16b	v5, v5, v6
     56c:	add.2d	v5, v5, v10
     570:	shl.2d	v5, v5, #0x2
     574:	add.2d	v5, v20, v5
     578:	tbnz	w16, #0x4, 0x7c0
     57c:	tbnz	w16, #0x5, 0x7cc
     580:	orr.16b	v3, v3, v22
     584:	and.16b	v3, v21, v3
     588:	add.2d	v3, v3, v8
     58c:	shl.2d	v3, v3, #0x2
     590:	add.2d	v3, v20, v3
     594:	tbnz	w16, #0x6, 0x7ec
     598:	tbz	w16, #0x7, 0x5a4
     59c:	mov.d	x16, v3[1]
     5a0:	ld1.s	{ v4 }[3], [x16]
     5a4:	fmov	w16, s12
     5a8:	sshll.2d	v5, v1, #0x0
     5ac:	ldp	q3, q6, [x13, #-0x40]
     5b0:	bit.16b	v6, v4, v0
     5b4:	bit.16b	v3, v15, v1
     5b8:	stp	q3, q6, [x13, #-0x40]
     5bc:	add	x17, x14, #0x10
     5c0:	dup.2d	v3, x17
     5c4:	orr.16b	v6, v3, v2
     5c8:	and.16b	v5, v5, v6
     5cc:	add.2d	v5, v5, v23
     5d0:	shl.2d	v5, v5, #0x2
     5d4:	add.2d	v7, v20, v5
     5d8:	movi.2d	v5, #0000000000000000
     5dc:	movi.2d	v6, #0000000000000000
     5e0:	tbnz	w16, #0x0, 0x7fc
     5e4:	and	w16, w16, #0xff
     5e8:	tbnz	w16, #0x1, 0x80c
     5ec:	orr.16b	v7, v3, v19
     5f0:	and.16b	v7, v16, v7
     5f4:	add.2d	v7, v7, v9
     5f8:	shl.2d	v7, v7, #0x2
     5fc:	add.2d	v7, v20, v7
     600:	tbnz	w16, #0x2, 0x82c
     604:	tbz	w16, #0x3, 0x610
     608:	mov.d	x17, v7[1]
     60c:	ld1.s	{ v5 }[3], [x17]
     610:	sshll.2d	v7, v0, #0x0
     614:	orr.16b	v11, v3, v18
     618:	and.16b	v7, v7, v11
     61c:	add.2d	v7, v7, v10
     620:	shl.2d	v7, v7, #0x2
     624:	add.2d	v7, v20, v7
     628:	tbnz	w16, #0x4, 0x83c
     62c:	tbnz	w16, #0x5, 0x848
     630:	orr.16b	v3, v3, v22
     634:	and.16b	v3, v21, v3
     638:	add.2d	v3, v3, v8
     63c:	shl.2d	v3, v3, #0x2
     640:	add.2d	v3, v20, v3
     644:	tbnz	w16, #0x6, 0x868
     648:	tbz	w16, #0x7, 0x654
     64c:	mov.d	x16, v3[1]
     650:	ld1.s	{ v6 }[3], [x16]
     654:	mov.16b	v17, v12
     658:	fmov	w16, s12
     65c:	sshll.2d	v3, v1, #0x0
     660:	ldp	q7, q11, [x13, #-0x20]
     664:	bit.16b	v11, v6, v0
     668:	bit.16b	v7, v5, v1
     66c:	stp	q7, q11, [x13, #-0x20]
     670:	add	x17, x14, #0x18
     674:	dup.2d	v11, x17
     678:	orr.16b	v7, v11, v2
     67c:	and.16b	v3, v3, v7
     680:	add.2d	v3, v3, v23
     684:	shl.2d	v3, v3, #0x2
     688:	add.2d	v12, v20, v3
     68c:	movi.2d	v7, #0000000000000000
     690:	movi.2d	v3, #0000000000000000
     694:	tbnz	w16, #0x0, 0x878
     698:	and	w16, w16, #0xff
     69c:	tbnz	w16, #0x1, 0x888
     6a0:	orr.16b	v12, v11, v19
     6a4:	and.16b	v12, v16, v12
     6a8:	add.2d	v12, v12, v9
     6ac:	shl.2d	v12, v12, #0x2
     6b0:	add.2d	v12, v20, v12
     6b4:	tbnz	w16, #0x2, 0x8a8
     6b8:	tbz	w16, #0x3, 0x6c4
     6bc:	mov.d	x17, v12[1]
     6c0:	ld1.s	{ v7 }[3], [x17]
     6c4:	sshll.2d	v12, v0, #0x0
     6c8:	orr.16b	v2, v11, v18
     6cc:	and.16b	v2, v12, v2
     6d0:	add.2d	v2, v2, v10
     6d4:	shl.2d	v2, v2, #0x2
     6d8:	add.2d	v12, v20, v2
     6dc:	tbnz	w16, #0x4, 0x8b8
     6e0:	tbnz	w16, #0x5, 0x8c4
     6e4:	orr.16b	v2, v11, v22
     6e8:	and.16b	v2, v21, v2
     6ec:	add.2d	v2, v2, v8
     6f0:	shl.2d	v2, v2, #0x2
     6f4:	add.2d	v11, v20, v2
     6f8:	tbnz	w16, #0x6, 0x8e4
     6fc:	tbz	w16, #0x7, 0x3d4
     700:	b	0x8f0
     704:	fmov	x16, d4
     708:	ldr	s13, [x16]
     70c:	and	w16, w15, #0xff
     710:	tbz	w16, #0x1, 0x48c
     714:	mov.d	x17, v4[1]
     718:	ld1.s	{ v13 }[1], [x17]
     71c:	orr.16b	v4, v3, v19
     720:	and.16b	v4, v16, v4
     724:	add.2d	v4, v4, v9
     728:	shl.2d	v4, v4, #0x2
     72c:	add.2d	v4, v20, v4
     730:	tbz	w16, #0x2, 0x4a4
     734:	fmov	x17, d4
     738:	ld1.s	{ v13 }[2], [x17]
     73c:	tbnz	w16, #0x3, 0x4a8
     740:	b	0x4b0
     744:	fmov	x17, d4
     748:	ld1.s	{ v14 }[0], [x17]
     74c:	tbz	w16, #0x5, 0x4d0
     750:	mov.d	x17, v4[1]
     754:	ld1.s	{ v14 }[1], [x17]
     758:	orr.16b	v3, v3, v22
     75c:	and.16b	v3, v21, v3
     760:	add.2d	v3, v3, v8
     764:	shl.2d	v3, v3, #0x2
     768:	add.2d	v3, v20, v3
     76c:	tbz	w16, #0x6, 0x4e8
     770:	fmov	x17, d3
     774:	ld1.s	{ v14 }[2], [x17]
     778:	tbnz	w16, #0x7, 0x4ec
     77c:	b	0x4f4
     780:	fmov	x17, d5
     784:	ldr	s15, [x17]
     788:	and	w16, w16, #0xff
     78c:	tbz	w16, #0x1, 0x53c
     790:	mov.d	x17, v5[1]
     794:	ld1.s	{ v15 }[1], [x17]
     798:	orr.16b	v5, v3, v19
     79c:	and.16b	v5, v16, v5
     7a0:	add.2d	v5, v5, v9
     7a4:	shl.2d	v5, v5, #0x2
     7a8:	add.2d	v5, v20, v5
     7ac:	tbz	w16, #0x2, 0x554
     7b0:	fmov	x17, d5
     7b4:	ld1.s	{ v15 }[2], [x17]
     7b8:	tbnz	w16, #0x3, 0x558
     7bc:	b	0x560
     7c0:	fmov	x17, d5
     7c4:	ld1.s	{ v4 }[0], [x17]
     7c8:	tbz	w16, #0x5, 0x580
     7cc:	mov.d	x17, v5[1]
     7d0:	ld1.s	{ v4 }[1], [x17]
     7d4:	orr.16b	v3, v3, v22
     7d8:	and.16b	v3, v21, v3
     7dc:	add.2d	v3, v3, v8
     7e0:	shl.2d	v3, v3, #0x2
     7e4:	add.2d	v3, v20, v3
     7e8:	tbz	w16, #0x6, 0x598
     7ec:	fmov	x17, d3
     7f0:	ld1.s	{ v4 }[2], [x17]
     7f4:	tbnz	w16, #0x7, 0x59c
     7f8:	b	0x5a4
     7fc:	fmov	x17, d7
     800:	ldr	s5, [x17]
     804:	and	w16, w16, #0xff
     808:	tbz	w16, #0x1, 0x5ec
     80c:	mov.d	x17, v7[1]
     810:	ld1.s	{ v5 }[1], [x17]
     814:	orr.16b	v7, v3, v19
     818:	and.16b	v7, v16, v7
     81c:	add.2d	v7, v7, v9
     820:	shl.2d	v7, v7, #0x2
     824:	add.2d	v7, v20, v7
     828:	tbz	w16, #0x2, 0x604
     82c:	fmov	x17, d7
     830:	ld1.s	{ v5 }[2], [x17]
     834:	tbnz	w16, #0x3, 0x608
     838:	b	0x610
     83c:	fmov	x17, d7
     840:	ld1.s	{ v6 }[0], [x17]
     844:	tbz	w16, #0x5, 0x630
     848:	mov.d	x17, v7[1]
     84c:	ld1.s	{ v6 }[1], [x17]
     850:	orr.16b	v3, v3, v22
     854:	and.16b	v3, v21, v3
     858:	add.2d	v3, v3, v8
     85c:	shl.2d	v3, v3, #0x2
     860:	add.2d	v3, v20, v3
     864:	tbz	w16, #0x6, 0x648
     868:	fmov	x17, d3
     86c:	ld1.s	{ v6 }[2], [x17]
     870:	tbnz	w16, #0x7, 0x64c
     874:	b	0x654
     878:	fmov	x17, d12
     87c:	ldr	s7, [x17]
     880:	and	w16, w16, #0xff
     884:	tbz	w16, #0x1, 0x6a0
     888:	mov.d	x17, v12[1]
     88c:	ld1.s	{ v7 }[1], [x17]
     890:	orr.16b	v12, v11, v19
     894:	and.16b	v12, v16, v12
     898:	add.2d	v12, v12, v9
     89c:	shl.2d	v12, v12, #0x2
     8a0:	add.2d	v12, v20, v12
     8a4:	tbz	w16, #0x2, 0x6b8
     8a8:	fmov	x17, d12
     8ac:	ld1.s	{ v7 }[2], [x17]
     8b0:	tbnz	w16, #0x3, 0x6bc
     8b4:	b	0x6c4
     8b8:	fmov	x17, d12
     8bc:	ld1.s	{ v3 }[0], [x17]
     8c0:	tbz	w16, #0x5, 0x6e4
     8c4:	mov.d	x17, v12[1]
     8c8:	ld1.s	{ v3 }[1], [x17]
     8cc:	orr.16b	v2, v11, v22
     8d0:	and.16b	v2, v21, v2
     8d4:	add.2d	v2, v2, v8
     8d8:	shl.2d	v2, v2, #0x2
     8dc:	add.2d	v11, v20, v2
     8e0:	tbz	w16, #0x6, 0x6fc
     8e4:	fmov	x17, d11
     8e8:	ld1.s	{ v3 }[2], [x17]
     8ec:	tbz	w16, #0x7, 0x3d4
     8f0:	mov.d	x16, v11[1]
     8f4:	ld1.s	{ v3 }[3], [x16]
     8f8:	b	0x3d4
     8fc:	mov	x12, #0x0
     900:	fmov	w13, s12
     904:	add	x14, sp, #0x200
     908:	b	0x92c
     90c:	add	x15, x14, x12
     910:	ldp	q2, q5, [x15]
     914:	bif.16b	v4, v5, v0
     918:	bit.16b	v2, v3, v1
     91c:	stp	q2, q4, [x15]
     920:	add	x12, x12, #0x20
     924:	cmp	x12, #0x400
     928:	b.eq	0x9c0
     92c:	add	x15, x10, x12
     930:	movi.2d	v3, #0000000000000000
     934:	movi.2d	v4, #0000000000000000
     938:	tbnz	w13, #0x0, 0x960
     93c:	and	w16, w13, #0xff
     940:	tbnz	w16, #0x1, 0x96c
     944:	tbnz	w16, #0x2, 0x978
     948:	tbnz	w16, #0x3, 0x984
     94c:	tbnz	w16, #0x4, 0x990
     950:	tbnz	w16, #0x5, 0x99c
     954:	tbnz	w16, #0x6, 0x9a8
     958:	tbz	w16, #0x7, 0x90c
     95c:	b	0x9b4
     960:	ldr	s3, [x15]
     964:	and	w16, w13, #0xff
     968:	tbz	w16, #0x1, 0x944
     96c:	add	x17, x15, #0x4
     970:	ld1.s	{ v3 }[1], [x17]
     974:	tbz	w16, #0x2, 0x948
     978:	add	x17, x15, #0x8
     97c:	ld1.s	{ v3 }[2], [x17]
     980:	tbz	w16, #0x3, 0x94c
     984:	add	x17, x15, #0xc
     988:	ld1.s	{ v3 }[3], [x17]
     98c:	tbz	w16, #0x4, 0x950
     990:	add	x17, x15, #0x10
     994:	ld1.s	{ v4 }[0], [x17]
     998:	tbz	w16, #0x5, 0x954
     99c:	add	x17, x15, #0x14
     9a0:	ld1.s	{ v4 }[1], [x17]
     9a4:	tbz	w16, #0x6, 0x958
     9a8:	add	x17, x15, #0x18
     9ac:	ld1.s	{ v4 }[2], [x17]
     9b0:	tbz	w16, #0x7, 0x90c
     9b4:	add	x15, x15, #0x1c
     9b8:	ld1.s	{ v4 }[3], [x15]
     9bc:	b	0x90c
     9c0:	mov	x10, #0x0
     9c4:	ldr	q2, [sp, #0x40]
     9c8:	xtn.8b	v17, v2
     9cc:	fadd.4s	v2, v25, v29
     9d0:	fadd.4s	v3, v24, v28
     9d4:	fadd.4s	v3, v3, v30
     9d8:	fadd.4s	v2, v2, v26
     9dc:	fadd.4s	v6, v2, v27
     9e0:	fadd.4s	v16, v3, v31
     9e4:	ldp	q3, q2, [sp, #0x20]
     9e8:	uzp1.4s	v5, v2, v3
     9ec:	ldp	q3, q2, [sp]
     9f0:	uzp1.4s	v4, v2, v3
     9f4:	movi.4s	v2, #0x1
     9f8:	eor.16b	v18, v4, v2
     9fc:	eor.16b	v2, v5, v2
     a00:	mov.s	w15, v2[1]
     a04:	mov.s	w16, v2[2]
     a08:	mov.s	w17, v2[3]
     a0c:	fmov	w12, s2
     a10:	add	x13, sp, #0x88
     a14:	bfxil	x13, x12, #0, #3
     a18:	str	d17, [sp, #0x88]
     a1c:	ldrb	w13, [x13]
     a20:	and	x14, x12, #0x7
     a24:	umov.b	w12, v17[0]
     a28:	stp	q16, q6, [x9, #0x40]
     a2c:	add	x0, sp, #0x150
     a30:	ldr	s2, [x0, x14, lsl #2]
     a34:	ands	w14, w12, #0x1
     a38:	tst	w14, w13
     a3c:	movi	d3, #0000000000000000
     a40:	fcsel	s7, s2, s3, ne
     a44:	add	x13, sp, #0x88
     a48:	bfxil	x13, x15, #0, #3
     a4c:	ldrb	w0, [x13]
     a50:	umov.b	w13, v17[1]
     a54:	and	x15, x15, #0x7
     a58:	stp	q16, q6, [x9, #0x20]
     a5c:	add	x1, sp, #0x130
     a60:	ldr	s2, [x1, x15, lsl #2]
     a64:	ands	w15, w13, #0x1
     a68:	tst	w15, w0
     a6c:	fcsel	s19, s2, s3, ne
     a70:	add	x15, sp, #0x88
     a74:	bfxil	x15, x16, #0, #3
     a78:	ldrb	w0, [x15]
     a7c:	and	x16, x16, #0x7
     a80:	umov.b	w15, v17[2]
     a84:	stp	q16, q6, [x9]
     a88:	add	x1, sp, #0x110
     a8c:	ldr	s2, [x1, x16, lsl #2]
     a90:	ands	w16, w15, #0x1
     a94:	tst	w16, w0
     a98:	fcsel	s20, s2, s3, ne
     a9c:	add	x16, sp, #0x88
     aa0:	bfxil	x16, x17, #0, #3
     aa4:	ldrb	w0, [x16]
     aa8:	and	x17, x17, #0x7
     aac:	umov.b	w16, v17[3]
     ab0:	stp	q16, q6, [sp, #0xf0]
     ab4:	add	x1, sp, #0xf0
     ab8:	ldr	s2, [x1, x17, lsl #2]
     abc:	ands	w17, w16, #0x1
     ac0:	tst	w17, w0
     ac4:	mov.s	w0, v18[1]
     ac8:	mov.s	w1, v18[2]
     acc:	mov.s	w3, v18[3]
     ad0:	fmov	w17, s18
     ad4:	and	x2, x17, #0x7
     ad8:	add	x4, sp, #0x88
     adc:	bfxil	x4, x17, #0, #3
     ae0:	ldrb	w4, [x4]
     ae4:	stp	q16, q6, [x9, #0xc0]
     ae8:	add	x17, sp, #0x1d0
     aec:	ldr	s18, [x17, x2, lsl #2]
     af0:	umov.b	w17, v17[4]
     af4:	fcsel	s2, s2, s3, ne
     af8:	and	w2, w17, w4
     afc:	tst	w2, #0x1
     b00:	add	x2, sp, #0x88
     b04:	bfxil	x2, x0, #0, #3
     b08:	ldrb	w2, [x2]
     b0c:	and	x0, x0, #0x7
     b10:	stp	q16, q6, [x9, #0xa0]
     b14:	add	x4, sp, #0x1b0
     b18:	ldr	s21, [x4, x0, lsl #2]
     b1c:	fcsel	s18, s18, s3, ne
     b20:	umov.b	w0, v17[5]
     b24:	ands	w4, w0, #0x1
     b28:	tst	w4, w2
     b2c:	fcsel	s21, s21, s3, ne
     b30:	add	x2, sp, #0x88
     b34:	bfxil	x2, x1, #0, #3
     b38:	ldrb	w2, [x2]
     b3c:	and	x1, x1, #0x7
     b40:	stp	q16, q6, [x9, #0x80]
     b44:	add	x4, sp, #0x190
     b48:	ldr	s22, [x4, x1, lsl #2]
     b4c:	umov.b	w1, v17[6]
     b50:	ands	w4, w1, #0x1
     b54:	tst	w4, w2
     b58:	add	x2, sp, #0x88
     b5c:	bfxil	x2, x3, #0, #3
     b60:	ldrb	w4, [x2]
     b64:	umov.b	w2, v17[7]
     b68:	and	x3, x3, #0x7
     b6c:	stp	q16, q6, [x9, #0x60]
     b70:	add	x9, sp, #0x170
     b74:	ldr	s17, [x9, x3, lsl #2]
     b78:	fcsel	s22, s22, s3, ne
     b7c:	ands	w9, w2, #0x1
     b80:	tst	w9, w4
     b84:	fcsel	s17, s17, s3, ne
     b88:	mov.s	v7[1], v19[0]
     b8c:	mov.s	v7[2], v20[0]
     b90:	mov.s	v7[3], v2[0]
     b94:	mov.s	v18[1], v21[0]
     b98:	mov.s	v18[2], v22[0]
     b9c:	mov.s	v18[3], v17[0]
     ba0:	fadd.4s	v2, v6, v18
     ba4:	fadd.4s	v6, v16, v7
     ba8:	movi.4s	v7, #0x2
     bac:	eor.16b	v5, v5, v7
     bb0:	fmov	w9, s5
     bb4:	add	x3, sp, #0x88
     bb8:	bfxil	x3, x9, #0, #3
     bbc:	ldrb	w3, [x3]
     bc0:	and	x9, x9, #0x7
     bc4:	stp	q6, q2, [sp, #0xd0]
     bc8:	add	x4, sp, #0xd0
     bcc:	ldr	s5, [x4, x9, lsl #2]
     bd0:	add	x9, sp, #0x88
     bd4:	eor.16b	v4, v4, v7
     bd8:	tst	w14, w3
     bdc:	fcsel	s5, s5, s3, ne
     be0:	fmov	w3, s4
     be4:	and	x4, x3, #0x7
     be8:	bfxil	x9, x3, #0, #3
     bec:	ldrb	w9, [x9]
     bf0:	and	w9, w17, w9
     bf4:	stp	q6, q2, [sp, #0xb0]
     bf8:	add	x3, sp, #0xb0
     bfc:	ldr	s4, [x3, x4, lsl #2]
     c00:	tst	w9, #0x1
     c04:	fcsel	s4, s4, s3, ne
     c08:	fadd.4s	v2, v2, v4
     c0c:	tst	w14, w17
     c10:	fcsel	s2, s2, s3, ne
     c14:	ands	w9, w12, #0x1
     c18:	fadd.4s	v4, v6, v5
     c1c:	fadd	s2, s4, s2
     c20:	fcsel	s4, s2, s3, ne
     c24:	tst	w13, #0x1
     c28:	fcsel	s5, s4, s3, ne
     c2c:	tst	w15, #0x1
     c30:	fcsel	s6, s4, s3, ne
     c34:	tst	w16, #0x1
     c38:	fcsel	s7, s4, s3, ne
     c3c:	tst	w9, w17
     c40:	fcsel	s2, s2, s3, ne
     c44:	tst	w0, #0x1
     c48:	fcsel	s16, s4, s3, ne
     c4c:	tst	w1, #0x1
     c50:	fcsel	s17, s4, s3, ne
     c54:	tst	w2, #0x1
     c58:	fcsel	s18, s4, s3, ne
     c5c:	mov.s	v4[1], v5[0]
     c60:	mov.s	v4[2], v6[0]
     c64:	mov.s	v4[3], v7[0]
     c68:	mov.s	v2[1], v16[0]
     c6c:	mov.s	v2[2], v17[0]
     c70:	mov.s	v2[3], v18[0]
     c74:	rbit	w9, w11
     c78:	clz	w9, w9
     c7c:	stp	q4, q2, [sp, #0x90]
     c80:	and	x9, x9, #0x7
     c84:	add	x11, sp, #0x90
     c88:	ldr	s2, [x11, x9, lsl #2]
     c8c:	fadd	s2, s2, s3
     c90:	mov	w9, #0x3b800000
     c94:	fmov	s3, w9
     c98:	fmul	s2, s2, s3
     c9c:	mov	w9, #0xc5ac
     ca0:	movk	w9, #0x3727, lsl #16
     ca4:	fmov	s3, w9
     ca8:	fadd	s2, s2, s3
     cac:	fsqrt	s2, s2
     cb0:	dup.4s	v3, v2[0]
     cb4:	fmov	x9, d23
     cb8:	add	x8, x8, x9, lsl #2
     cbc:	add	x9, sp, #0x600
     cc0:	add	x11, sp, #0x200
     cc4:	b	0xcd4
     cc8:	add	x10, x10, #0x20
     ccc:	cmp	x10, #0x400
     cd0:	b.eq	0xd98
     cd4:	fmov	w13, s12
     cd8:	add	x14, x9, x10
     cdc:	ldr	q2, [x14]
     ce0:	and.16b	v2, v1, v2
     ce4:	fdiv.4s	v2, v2, v3
     ce8:	add	x15, x11, x10
     cec:	ldr	q4, [x15]
     cf0:	and.16b	v4, v1, v4
     cf4:	fmul.4s	v4, v2, v4
     cf8:	add	x12, x8, x10
     cfc:	tbnz	w13, #0x0, 0xd44
     d00:	and	w13, w13, #0xff
     d04:	tbnz	w13, #0x1, 0xd50
     d08:	tbnz	w13, #0x2, 0xd5c
     d0c:	tbz	w13, #0x3, 0xd18
     d10:	add	x16, x12, #0xc
     d14:	st1.s	{ v4 }[3], [x16]
     d18:	ldr	q2, [x14, #0x10]
     d1c:	and.16b	v2, v0, v2
     d20:	fdiv.4s	v2, v2, v3
     d24:	ldr	q4, [x15, #0x10]
     d28:	and.16b	v4, v0, v4
     d2c:	fmul.4s	v4, v2, v4
     d30:	tbnz	w13, #0x4, 0xd6c
     d34:	tbnz	w13, #0x5, 0xd74
     d38:	tbnz	w13, #0x6, 0xd80
     d3c:	tbz	w13, #0x7, 0xcc8
     d40:	b	0xd8c
     d44:	str	s4, [x12]
     d48:	and	w13, w13, #0xff
     d4c:	tbz	w13, #0x1, 0xd08
     d50:	add	x16, x12, #0x4
     d54:	st1.s	{ v4 }[1], [x16]
     d58:	tbz	w13, #0x2, 0xd0c
     d5c:	add	x16, x12, #0x8
     d60:	st1.s	{ v4 }[2], [x16]
     d64:	tbnz	w13, #0x3, 0xd10
     d68:	b	0xd18
     d6c:	str	s4, [x12, #0x10]
     d70:	tbz	w13, #0x5, 0xd38
     d74:	add	x14, x12, #0x14
     d78:	st1.s	{ v4 }[1], [x14]
     d7c:	tbz	w13, #0x6, 0xd3c
     d80:	add	x14, x12, #0x18
     d84:	st1.s	{ v4 }[2], [x14]
     d88:	tbz	w13, #0x7, 0xcc8
     d8c:	add	x12, x12, #0x1c
     d90:	st1.s	{ v4 }[3], [x12]
     d94:	b	0xcc8
     d98:	add	sp, sp, #0xa00
     d9c:	ldp	x28, x27, [sp, #0x40]
     da0:	ldp	d9, d8, [sp, #0x30]
     da4:	ldp	d11, d10, [sp, #0x20]
     da8:	ldp	d13, d12, [sp, #0x10]
     dac:	ldp	d15, d14, [sp], #0x50
     db0:	ret
     db4:	fmov	x9, d5
     db8:	ldr	s28, [x9]
     dbc:	adrp	x9, lCPI0_6@PAGE
     dc0:	and.16b	v2, v23, v18
     dc4:	ushll.2d	v27, v3, #0x8
     dc8:	shl.2d	v4, v4, #0x2
     dcc:	tbz	w8, #0x1, 0xf0
     dd0:	mov.d	x10, v5[1]
     dd4:	ld1.s	{ v28 }[1], [x10]
     dd8:	sshll2.2d	v21, v0, #0x0
     ddc:	ldr	q22, [x9, lCPI0_6@PAGEOFF]
     de0:	orr.16b	v5, v27, v2
     de4:	add.2d	v4, v20, v4
     de8:	tbz	w8, #0x2, 0x104
     dec:	fmov	x9, d4
     df0:	ld1.s	{ v28 }[2], [x9]
     df4:	and.16b	v6, v21, v22
     df8:	ushll2.2d	v30, v3, #0x8
     dfc:	shl.2d	v3, v5, #0x2
     e00:	tbz	w8, #0x3, 0x114
     e04:	mov.d	x9, v4[1]
     e08:	ld1.s	{ v28 }[3], [x9]
     e0c:	orr.16b	v4, v30, v6
     e10:	add.2d	v3, v20, v3
     e14:	tbz	w8, #0x4, 0x120
     e18:	fmov	x9, d3
     e1c:	ld1.s	{ v29 }[0], [x9]
     e20:	shl.2d	v4, v4, #0x2
     e24:	tbz	w8, #0x5, 0x128
     e28:	mov.d	x9, v3[1]
     e2c:	ld1.s	{ v29 }[1], [x9]
     e30:	add.2d	v3, v20, v4
     e34:	tbz	w8, #0x6, 0x130
     e38:	fmov	x9, d3
     e3c:	ld1.s	{ v29 }[2], [x9]
     e40:	add	x9, sp, #0x110
     e44:	stp	q6, q2, [sp]
     e48:	tbnz	w8, #0x7, 0x13c
     e4c:	b	0x144
     e50:	fmov	x12, d6
     e54:	ldr	s4, [x12]
     e58:	adrp	x12, lCPI0_10@PAGE
     e5c:	and.16b	v3, v3, v5
     e60:	shl.2d	v7, v7, #0x2
     e64:	tbz	w11, #0x1, 0x1b4
     e68:	mov.d	x13, v6[1]
     e6c:	ld1.s	{ v4 }[1], [x13]
     e70:	ldr	q5, [x12, lCPI0_10@PAGEOFF]
     e74:	orr.16b	v6, v27, v3
     e78:	add.2d	v3, v20, v7
     e7c:	tbz	w11, #0x2, 0x1c4
     e80:	fmov	x12, d3
     e84:	ld1.s	{ v4 }[2], [x12]
     e88:	and.16b	v5, v21, v5
     e8c:	shl.2d	v6, v6, #0x2
     e90:	tbz	w11, #0x3, 0x1d0
     e94:	mov.d	x12, v3[1]
     e98:	ld1.s	{ v4 }[3], [x12]
     e9c:	orr.16b	v5, v30, v5
     ea0:	add.2d	v3, v20, v6
     ea4:	tbz	w11, #0x4, 0x1dc
     ea8:	fmov	x12, d3
     eac:	ld1.s	{ v31 }[0], [x12]
     eb0:	shl.2d	v5, v5, #0x2
     eb4:	tbz	w11, #0x5, 0x1e4
     eb8:	mov.d	x12, v3[1]
     ebc:	ld1.s	{ v31 }[1], [x12]
     ec0:	add.2d	v3, v20, v5
     ec4:	tbz	w11, #0x6, 0x1ec
     ec8:	fmov	x12, d3
     ecc:	ld1.s	{ v31 }[2], [x12]
     ed0:	tbnz	w11, #0x7, 0x1f0
     ed4:	b	0x1f8
     ed8:	fmov	x12, d8
     edc:	ldr	s5, [x12]
     ee0:	adrp	x12, lCPI0_14@PAGE
     ee4:	and.16b	v3, v3, v7
     ee8:	shl.2d	v9, v9, #0x2
     eec:	tbz	w11, #0x1, 0x25c
     ef0:	mov.d	x13, v8[1]
     ef4:	ld1.s	{ v5 }[1], [x13]
     ef8:	ldr	q7, [x12, lCPI0_14@PAGEOFF]
     efc:	orr.16b	v8, v27, v3
     f00:	add.2d	v3, v20, v9
     f04:	tbz	w11, #0x2, 0x26c
     f08:	fmov	x12, d3
     f0c:	ld1.s	{ v5 }[2], [x12]
     f10:	and.16b	v7, v21, v7
     f14:	shl.2d	v8, v8, #0x2
     f18:	tbz	w11, #0x3, 0x278
     f1c:	mov.d	x12, v3[1]
     f20:	ld1.s	{ v5 }[3], [x12]
     f24:	orr.16b	v7, v30, v7
     f28:	add.2d	v3, v20, v8
     f2c:	tbz	w11, #0x4, 0x284
     f30:	fmov	x12, d3
     f34:	ld1.s	{ v6 }[0], [x12]
     f38:	shl.2d	v7, v7, #0x2
     f3c:	tbz	w11, #0x5, 0x28c
     f40:	mov.d	x12, v3[1]
     f44:	ld1.s	{ v6 }[1], [x12]
     f48:	add.2d	v3, v20, v7
     f4c:	tbz	w11, #0x6, 0x294
     f50:	fmov	x12, d3
     f54:	ld1.s	{ v6 }[2], [x12]
     f58:	tbnz	w11, #0x7, 0x298
     f5c:	b	0x2a0
     f60:	fmov	x12, d10
     f64:	ldr	s3, [x12]
     f68:	adrp	x12, lCPI0_18@PAGE
     f6c:	and.16b	v8, v8, v9
     f70:	shl.2d	v11, v11, #0x2
     f74:	tbz	w11, #0x1, 0x304
     f78:	mov.d	x13, v10[1]
     f7c:	ld1.s	{ v3 }[1], [x13]
     f80:	ldr	q9, [x12, lCPI0_18@PAGEOFF]
     f84:	orr.16b	v10, v27, v8
     f88:	add.2d	v8, v20, v11
     f8c:	tbz	w11, #0x2, 0x314
     f90:	fmov	x12, d8
     f94:	ld1.s	{ v3 }[2], [x12]
     f98:	and.16b	v9, v21, v9
     f9c:	shl.2d	v10, v10, #0x2
     fa0:	tbz	w11, #0x3, 0x320
     fa4:	mov.d	x12, v8[1]
     fa8:	ld1.s	{ v3 }[3], [x12]
     fac:	orr.16b	v9, v30, v9
     fb0:	add.2d	v8, v20, v10
     fb4:	tbz	w11, #0x4, 0x32c
     fb8:	fmov	x12, d8
     fbc:	ld1.s	{ v7 }[0], [x12]
     fc0:	shl.2d	v9, v9, #0x2
     fc4:	tbz	w11, #0x5, 0x334
     fc8:	mov.d	x12, v8[1]
     fcc:	ld1.s	{ v7 }[1], [x12]
     fd0:	add.2d	v8, v20, v9
     fd4:	tbnz	w11, #0x6, 0x33c
     fd8:	b	0x344
_llm_rows.packet_batch.blocks:
     fdc:	cbz	w3, 0x1134
     fe0:	sub	sp, sp, #0x70
     fe4:	stp	x28, x27, [sp, #0x10]
     fe8:	stp	x26, x25, [sp, #0x20]
     fec:	stp	x24, x23, [sp, #0x30]
     ff0:	stp	x22, x21, [sp, #0x40]
     ff4:	stp	x20, x19, [sp, #0x50]
     ff8:	stp	x29, x30, [sp, #0x60]
     ffc:	mov	x19, x3
    1000:	mov	x20, x2
    1004:	mov	x21, x0
    1008:	mov	w22, #0x0
    100c:	ldp	w24, w8, [x2, #0x2c]
    1010:	stp	w3, w8, [sp, #0x8]
    1014:	ldp	w25, w26, [x2]
    1018:	ldp	w28, w27, [x2, #0x8]
    101c:	str	w24, [sp, #0x4]
    1020:	b	0x1068
    1024:	mov	w8, #0x1f8
    1028:	str	w8, [x20, #0x24]
    102c:	ldp	w24, w19, [sp, #0x4]
    1030:	add	w8, w25, #0x1
    1034:	cmp	w8, w24
    1038:	cset	w8, eq
    103c:	csinc	w25, wzr, w25, eq
    1040:	cinc	w9, w26, eq
    1044:	ldr	w10, [sp, #0xc]
    1048:	cmp	w9, w10
    104c:	cset	w10, eq
    1050:	ands	w8, w8, w10
    1054:	csel	w26, wzr, w9, ne
    1058:	add	w28, w28, w8
    105c:	add	w22, w22, #0x1
    1060:	cmp	w22, w19
    1064:	b.eq	0x1118
    1068:	ubfiz	x8, x25, #9, #32
    106c:	cmp	x8, x27
    1070:	csel	x9, x8, xzr, ls
    1074:	subs	x10, x27, x9
    1078:	cmp	x10, #0x200
    107c:	mov	w11, #0x200
    1080:	csel	x10, x10, x11, lo
    1084:	cmp	x27, x9
    1088:	stp	w25, w26, [x20]
    108c:	str	w28, [x20, #0x8]
    1090:	ccmp	x8, x27, #0x2, hi
    1094:	csel	x23, x10, xzr, ls
    1098:	cmp	x23, #0x200
    109c:	b.lo	0x10c8
    10a0:	mov	w23, #0x0
    10a4:	str	w23, [x20, #0x24]
    10a8:	mov	x0, x21
    10ac:	mov	x1, x20
    10b0:	mov	w2, #0x8
    10b4:	bl	_llm_rows
    10b8:	add	w23, w23, #0x8
    10bc:	cmp	w23, #0x200
    10c0:	b.ne	0x10a4
    10c4:	b	0x1030
    10c8:	lsr	x8, x23, #3
    10cc:	lsl	w24, w8, #3
    10d0:	cmp	x23, #0x8
    10d4:	b.lo	0x10fc
    10d8:	mov	w19, #0x0
    10dc:	str	w19, [x20, #0x24]
    10e0:	mov	x0, x21
    10e4:	mov	x1, x20
    10e8:	mov	w2, #0x8
    10ec:	bl	_llm_rows
    10f0:	add	w19, w19, #0x8
    10f4:	cmp	w24, w19
    10f8:	b.ne	0x10dc
    10fc:	and	w2, w23, #0x7
    1100:	cbz	w2, 0x1024
    1104:	str	w24, [x20, #0x24]
    1108:	mov	x0, x21
    110c:	mov	x1, x20
    1110:	bl	_llm_rows
    1114:	b	0x1024
    1118:	ldp	x29, x30, [sp, #0x60]
    111c:	ldp	x20, x19, [sp, #0x50]
    1120:	ldp	x22, x21, [sp, #0x40]
    1124:	ldp	x24, x23, [sp, #0x30]
    1128:	ldp	x26, x25, [sp, #0x20]
    112c:	ldp	x28, x27, [sp, #0x10]
    1130:	add	sp, sp, #0x70
    1134:	ret

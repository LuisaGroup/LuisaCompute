/tmp/luisa-full-packet.UEezjO/capture/rmsnorm-64x256-r0-l1-f1-p1/object/tile_xir_w8_63766_1788856226313353_0.o:
(__TEXT,__text) section
_llm_rows.packet_batch.blocks:
       0:	stp	d15, d14, [sp, #-0xa0]!
       4:	stp	d13, d12, [sp, #0x10]
       8:	stp	d11, d10, [sp, #0x20]
       c:	stp	d9, d8, [sp, #0x30]
      10:	stp	x28, x27, [sp, #0x40]
      14:	stp	x26, x25, [sp, #0x50]
      18:	stp	x24, x23, [sp, #0x60]
      1c:	stp	x22, x21, [sp, #0x70]
      20:	stp	x20, x19, [sp, #0x80]
      24:	stp	x29, x30, [sp, #0x90]
      28:	sub	sp, sp, #0x4, lsl #12
      2c:	sub	sp, sp, #0x50
      30:	str	x0, [sp, #0x38]
      34:	str	w3, [sp, #0x34]
      38:	cbz	w3, 0x3780
      3c:	mov	w8, #0x0
      40:	add	x9, sp, #0x2, lsl #12
      44:	add	x9, x9, #0x50
      48:	ldp	w11, w10, [x2, #0x2c]
      4c:	stp	w10, w11, [sp, #0x2c]
      50:	ldp	w12, w13, [x2]
      54:	add	x10, x9, #0xe0
      58:	str	x10, [sp, #0x8]
      5c:	mov	w16, #0x8
      60:	ldp	w17, w0, [x2, #0x8]
      64:	mov	w4, #0x4
      68:	adrp	x14, lCPI0_0@PAGE
      6c:	ldr	q0, [x14, lCPI0_0@PAGEOFF]
      70:	mov	w5, #0xc
      74:	add	x6, sp, #0x50
      78:	dup.2d	v1, x16
      7c:	str	q1, [sp, #0x10]
      80:	dup.2d	v2, x4
      84:	adrp	x14, lCPI0_1@PAGE
      88:	ldr	q3, [x14, lCPI0_1@PAGEOFF]
      8c:	dup.2d	v4, x5
      90:	b	0xdc
      94:	mov	w10, #0x38
      98:	str	w10, [x2, #0x24]
      9c:	add	w10, w12, #0x1
      a0:	ldr	w11, [sp, #0x30]
      a4:	cmp	w10, w11
      a8:	cset	w10, eq
      ac:	csinc	w12, wzr, w12, eq
      b0:	cinc	w11, w13, eq
      b4:	ldr	w13, [sp, #0x2c]
      b8:	cmp	w11, w13
      bc:	cset	w13, eq
      c0:	ands	w10, w10, w13
      c4:	csel	w13, wzr, w11, ne
      c8:	add	w17, w17, w10
      cc:	add	w8, w8, #0x1
      d0:	ldr	w10, [sp, #0x34]
      d4:	cmp	w8, w10
      d8:	b.eq	0x3780
      dc:	ubfiz	x14, x12, #6, #32
      e0:	cmp	x14, x0
      e4:	csel	x15, x14, xzr, ls
      e8:	subs	x7, x0, x15
      ec:	cmp	x7, #0x40
      f0:	mov	w10, #0x40
      f4:	csel	x7, x7, x10, lo
      f8:	cmp	x0, x15
      fc:	stp	w12, w13, [x2]
     100:	str	w17, [x2, #0x8]
     104:	ccmp	x14, x0, #0x2, hi
     108:	csel	x25, x7, xzr, ls
     10c:	mov	w10, #0x3b800000
     110:	dup.4s	v6, w10
     114:	mov	w10, #0xc5ac
     118:	movk	w10, #0x3727, lsl #16
     11c:	dup.4s	v5, w10
     120:	cmp	x25, #0x40
     124:	b.lo	0x2878
     128:	mov	x14, #0x0
     12c:	ldr	x10, [sp, #0x38]
     130:	ldr	x15, [x10]
     134:	ldr	x24, [x10, #0x10]
     138:	ldr	x23, [x10, #0x30]
     13c:	lsl	w25, w12, #6
     140:	dup.4s	v1, w25
     144:	orr.16b	v16, v1, v0
     148:	orr.16b	v20, v1, v3
     14c:	ushll.2d	v1, v20, #0xa
     150:	ushll2.2d	v19, v20, #0xa
     154:	ushll.2d	v18, v16, #0xa
     158:	ushll2.2d	v17, v16, #0xa
     15c:	dup.2d	v7, x15
     160:	add.2d	v17, v7, v17
     164:	add.2d	v18, v7, v18
     168:	add.2d	v19, v7, v19
     16c:	add.2d	v21, v7, v1
     170:	mov.d	x15, v21[1]
     174:	add.2d	v22, v21, v2
     178:	ldr	q26, [sp, #0x10]
     17c:	add.2d	v24, v21, v26
     180:	add.2d	v27, v21, v4
     184:	fmov	x7, d21
     188:	mov.d	x19, v19[1]
     18c:	add.2d	v1, v19, v2
     190:	add.2d	v25, v19, v26
     194:	add.2d	v28, v19, v4
     198:	fmov	x20, d19
     19c:	mov.d	x26, v18[1]
     1a0:	add.2d	v23, v18, v2
     1a4:	add.2d	v30, v18, v26
     1a8:	add.2d	v29, v18, v4
     1ac:	fmov	x27, d18
     1b0:	mov.d	x28, v17[1]
     1b4:	ldr	s31, [x7]
     1b8:	add.2d	v8, v17, v2
     1bc:	add.2d	v9, v17, v26
     1c0:	add.2d	v26, v17, v4
     1c4:	fmov	x7, d17
     1c8:	ushll2.2d	v17, v16, #0x8
     1cc:	ld1.s	{ v31 }[1], [x15]
     1d0:	ld1.s	{ v31 }[2], [x20]
     1d4:	ld1.s	{ v31 }[3], [x19]
     1d8:	mov.d	x15, v22[1]
     1dc:	fmov	x19, d22
     1e0:	ldr	s21, [x27]
     1e4:	mov.d	x20, v1[1]
     1e8:	fmov	x27, d1
     1ec:	ushll2.2d	v18, v20, #0x8
     1f0:	ushll.2d	v19, v16, #0x8
     1f4:	ushll.2d	v20, v20, #0x8
     1f8:	ld1.s	{ v21 }[1], [x26]
     1fc:	ld1.s	{ v21 }[2], [x7]
     200:	ld1.s	{ v21 }[3], [x28]
     204:	stp	q31, q21, [x9]
     208:	fmul.4s	v21, v21, v21
     20c:	fmul.4s	v16, v31, v31
     210:	mov.d	x7, v23[1]
     214:	fmov	x26, d23
     218:	mov.d	x28, v8[1]
     21c:	ldr	s1, [x19]
     220:	ld1.s	{ v1 }[1], [x15]
     224:	ld1.s	{ v1 }[2], [x27]
     228:	ld1.s	{ v1 }[3], [x20]
     22c:	fmov	x15, d8
     230:	ldr	s22, [x26]
     234:	ld1.s	{ v22 }[1], [x7]
     238:	ld1.s	{ v22 }[2], [x15]
     23c:	ld1.s	{ v22 }[3], [x28]
     240:	stp	q1, q22, [x9, #0x20]
     244:	fmul.4s	v23, v22, v22
     248:	fmul.4s	v22, v1, v1
     24c:	mov.d	x15, v24[1]
     250:	mov.d	x7, v25[1]
     254:	mov.d	x19, v30[1]
     258:	fmov	x20, d24
     25c:	fmov	x26, d30
     260:	mov.d	x27, v9[1]
     264:	fmov	x28, d9
     268:	ldr	s1, [x26]
     26c:	ld1.s	{ v1 }[1], [x19]
     270:	ld1.s	{ v1 }[2], [x28]
     274:	ld1.s	{ v1 }[3], [x27]
     278:	fmov	x19, d25
     27c:	ldr	s25, [x20]
     280:	ld1.s	{ v25 }[1], [x15]
     284:	ld1.s	{ v25 }[2], [x19]
     288:	ld1.s	{ v25 }[3], [x7]
     28c:	stp	q25, q1, [x9, #0x40]
     290:	fmul.4s	v24, v1, v1
     294:	fmul.4s	v25, v25, v25
     298:	mov.d	x15, v27[1]
     29c:	fmov	x7, d27
     2a0:	mov.d	x19, v28[1]
     2a4:	fmov	x20, d28
     2a8:	mov.d	x26, v29[1]
     2ac:	fmov	x27, d29
     2b0:	mov.d	x28, v26[1]
     2b4:	ldr	s1, [x7]
     2b8:	ld1.s	{ v1 }[1], [x15]
     2bc:	ld1.s	{ v1 }[2], [x20]
     2c0:	ld1.s	{ v1 }[3], [x19]
     2c4:	fmov	x15, d26
     2c8:	ldr	s26, [x27]
     2cc:	ld1.s	{ v26 }[1], [x26]
     2d0:	ld1.s	{ v26 }[2], [x15]
     2d4:	ld1.s	{ v26 }[3], [x28]
     2d8:	stp	q1, q26, [x9, #0x60]
     2dc:	fmul.4s	v27, v26, v26
     2e0:	fmul.4s	v26, v1, v1
     2e4:	add	x20, x9, x14, lsl #5
     2e8:	add	x15, x14, #0x5
     2ec:	add	x7, x14, #0x6
     2f0:	add	x19, x14, #0x7
     2f4:	add	x14, x14, #0x4
     2f8:	dup.2d	v1, x14
     2fc:	add.2d	v28, v1, v17
     300:	add.2d	v29, v1, v19
     304:	add.2d	v30, v1, v20
     308:	add.2d	v1, v1, v18
     30c:	shl.2d	v30, v30, #0x2
     310:	shl.2d	v1, v1, #0x2
     314:	shl.2d	v29, v29, #0x2
     318:	shl.2d	v28, v28, #0x2
     31c:	add.2d	v28, v7, v28
     320:	add.2d	v29, v7, v29
     324:	add.2d	v1, v7, v1
     328:	add.2d	v30, v7, v30
     32c:	mov.d	x26, v30[1]
     330:	mov.d	x27, v1[1]
     334:	fmov	x28, d30
     338:	fmov	x30, d1
     33c:	mov.d	x21, v29[1]
     340:	fmov	x22, d29
     344:	ldr	s1, [x28]
     348:	mov.d	x28, v28[1]
     34c:	ld1.s	{ v1 }[1], [x26]
     350:	ld1.s	{ v1 }[2], [x30]
     354:	fmov	x26, d28
     358:	ldr	s28, [x22]
     35c:	ld1.s	{ v28 }[1], [x21]
     360:	ld1.s	{ v1 }[3], [x27]
     364:	ld1.s	{ v28 }[2], [x26]
     368:	dup.2d	v29, x15
     36c:	ld1.s	{ v28 }[3], [x28]
     370:	add.2d	v30, v29, v17
     374:	add.2d	v31, v29, v20
     378:	shl.2d	v31, v31, #0x2
     37c:	add.2d	v31, v7, v31
     380:	stp	q1, q28, [x20, #0x80]
     384:	mov.d	x15, v31[1]
     388:	fmov	x21, d31
     38c:	add.2d	v31, v29, v19
     390:	add.2d	v29, v29, v18
     394:	fmul.4s	v1, v1, v1
     398:	shl.2d	v29, v29, #0x2
     39c:	shl.2d	v31, v31, #0x2
     3a0:	shl.2d	v30, v30, #0x2
     3a4:	add.2d	v30, v7, v30
     3a8:	add.2d	v31, v7, v31
     3ac:	fmul.4s	v28, v28, v28
     3b0:	add.2d	v29, v7, v29
     3b4:	mov.d	x22, v29[1]
     3b8:	mov.d	x26, v31[1]
     3bc:	fadd.4s	v21, v21, v28
     3c0:	fmov	x27, d29
     3c4:	fmov	x28, d31
     3c8:	mov.d	x30, v30[1]
     3cc:	ldr	s28, [x21]
     3d0:	fadd.4s	v16, v16, v1
     3d4:	fmov	x21, d30
     3d8:	ld1.s	{ v28 }[1], [x15]
     3dc:	ldr	s1, [x28]
     3e0:	ld1.s	{ v28 }[2], [x27]
     3e4:	ld1.s	{ v1 }[1], [x26]
     3e8:	ld1.s	{ v1 }[2], [x21]
     3ec:	ld1.s	{ v28 }[3], [x22]
     3f0:	dup.2d	v29, x7
     3f4:	add.2d	v30, v29, v17
     3f8:	add.2d	v31, v29, v20
     3fc:	ld1.s	{ v1 }[3], [x30]
     400:	shl.2d	v31, v31, #0x2
     404:	add.2d	v31, v7, v31
     408:	mov.d	x15, v31[1]
     40c:	stp	q28, q1, [x20, #0xa0]
     410:	fmov	x7, d31
     414:	add.2d	v31, v29, v19
     418:	add.2d	v29, v29, v18
     41c:	shl.2d	v29, v29, #0x2
     420:	shl.2d	v31, v31, #0x2
     424:	fmul.4s	v28, v28, v28
     428:	shl.2d	v30, v30, #0x2
     42c:	add.2d	v30, v7, v30
     430:	add.2d	v29, v7, v29
     434:	mov.d	x21, v29[1]
     438:	fmul.4s	v1, v1, v1
     43c:	add.2d	v31, v7, v31
     440:	fmov	x22, d29
     444:	mov.d	x26, v31[1]
     448:	fmov	x27, d31
     44c:	fadd.4s	v23, v23, v1
     450:	mov.d	x28, v30[1]
     454:	ldr	s1, [x27]
     458:	ld1.s	{ v1 }[1], [x26]
     45c:	fadd.4s	v22, v22, v28
     460:	fmov	x26, d30
     464:	ld1.s	{ v1 }[2], [x26]
     468:	ldr	s28, [x7]
     46c:	ld1.s	{ v1 }[3], [x28]
     470:	ld1.s	{ v28 }[1], [x15]
     474:	ld1.s	{ v28 }[2], [x22]
     478:	ld1.s	{ v28 }[3], [x21]
     47c:	dup.2d	v29, x19
     480:	add.2d	v30, v29, v17
     484:	add.2d	v31, v29, v20
     488:	stp	q28, q1, [x20, #0xc0]
     48c:	shl.2d	v31, v31, #0x2
     490:	add.2d	v31, v7, v31
     494:	mov.d	x15, v31[1]
     498:	fmov	x7, d31
     49c:	fmul.4s	v28, v28, v28
     4a0:	add.2d	v31, v29, v19
     4a4:	add.2d	v29, v29, v18
     4a8:	shl.2d	v29, v29, #0x2
     4ac:	shl.2d	v31, v31, #0x2
     4b0:	shl.2d	v30, v30, #0x2
     4b4:	fmul.4s	v1, v1, v1
     4b8:	add.2d	v30, v7, v30
     4bc:	add.2d	v31, v7, v31
     4c0:	add.2d	v29, v7, v29
     4c4:	mov.d	x19, v29[1]
     4c8:	fadd.4s	v24, v24, v1
     4cc:	fmov	x21, d29
     4d0:	mov.d	x22, v31[1]
     4d4:	mov.d	x26, v30[1]
     4d8:	fadd.4s	v25, v25, v28
     4dc:	fmov	x27, d31
     4e0:	ldr	s1, [x7]
     4e4:	ld1.s	{ v1 }[1], [x15]
     4e8:	ld1.s	{ v1 }[2], [x21]
     4ec:	fmov	x15, d30
     4f0:	ldr	s28, [x27]
     4f4:	ld1.s	{ v28 }[1], [x22]
     4f8:	ld1.s	{ v1 }[3], [x19]
     4fc:	ld1.s	{ v28 }[2], [x15]
     500:	ld1.s	{ v28 }[3], [x26]
     504:	stp	q1, q28, [x20, #0xe0]
     508:	fmul.4s	v1, v1, v1
     50c:	fmul.4s	v28, v28, v28
     510:	fadd.4s	v27, v27, v28
     514:	fadd.4s	v26, v26, v1
     518:	cmp	x14, #0xfc
     51c:	b.lo	0x2e4
     520:	mov	x14, #0x0
     524:	add	x15, x24, x14, lsl #2
     528:	ld1r.4s	{ v1 }, [x15]
     52c:	add	x15, x6, x14, lsl #5
     530:	stp	q1, q1, [x15]
     534:	add	x14, x14, #0x1
     538:	cmp	x14, #0x100
     53c:	b.ne	0x524
     540:	mov	x14, #0x0
     544:	fadd.4s	v1, v21, v23
     548:	fadd.4s	v16, v16, v22
     54c:	fadd.4s	v16, v16, v25
     550:	fadd.4s	v1, v1, v24
     554:	fadd.4s	v1, v1, v27
     558:	fadd.4s	v16, v16, v26
     55c:	fmul.4s	v16, v16, v6
     560:	fmul.4s	v1, v1, v6
     564:	fadd.4s	v1, v1, v5
     568:	fadd.4s	v16, v16, v5
     56c:	fsqrt.4s	v21, v16
     570:	fsqrt.4s	v22, v1
     574:	dup.2d	v1, x14
     578:	add.2d	v16, v1, v17
     57c:	add.2d	v23, v1, v19
     580:	add.2d	v24, v1, v18
     584:	add.2d	v1, v1, v20
     588:	lsl	x15, x14, #5
     58c:	add	x7, x9, x15
     590:	ldp	q26, q25, [x7]
     594:	fdiv.4s	v26, v26, v21
     598:	fdiv.4s	v25, v25, v22
     59c:	add	x15, x6, x15
     5a0:	ldp	q27, q28, [x15]
     5a4:	fmul.4s	v25, v25, v28
     5a8:	fmul.4s	v26, v26, v27
     5ac:	shl.2d	v1, v1, #0x2
     5b0:	shl.2d	v24, v24, #0x2
     5b4:	shl.2d	v23, v23, #0x2
     5b8:	shl.2d	v27, v16, #0x2
     5bc:	dup.2d	v16, x23
     5c0:	add.2d	v27, v16, v27
     5c4:	add.2d	v1, v16, v1
     5c8:	mov.d	x15, v1[1]
     5cc:	fmov	x7, d1
     5d0:	str	s26, [x7]
     5d4:	st1.s	{ v26 }[1], [x15]
     5d8:	add.2d	v1, v16, v24
     5dc:	mov.d	x15, v1[1]
     5e0:	fmov	x7, d1
     5e4:	st1.s	{ v26 }[2], [x7]
     5e8:	add.2d	v1, v16, v23
     5ec:	st1.s	{ v26 }[3], [x15]
     5f0:	mov.d	x15, v1[1]
     5f4:	fmov	x7, d1
     5f8:	str	s25, [x7]
     5fc:	st1.s	{ v25 }[1], [x15]
     600:	mov.d	x15, v27[1]
     604:	fmov	x7, d27
     608:	st1.s	{ v25 }[2], [x7]
     60c:	st1.s	{ v25 }[3], [x15]
     610:	add	x14, x14, #0x1
     614:	cmp	x14, #0x100
     618:	b.ne	0x574
     61c:	mov	x14, #0x0
     620:	str	w16, [x2, #0x24]
     624:	orr	w15, w25, #0x8
     628:	dup.4s	v1, w15
     62c:	orr.16b	v19, v1, v0
     630:	orr.16b	v20, v1, v3
     634:	dup.2d	v17, x16
     638:	ushll.2d	v1, v20, #0xa
     63c:	ushll2.2d	v22, v20, #0xa
     640:	ushll.2d	v21, v19, #0xa
     644:	ushll2.2d	v18, v19, #0xa
     648:	add.2d	v18, v7, v18
     64c:	add.2d	v21, v7, v21
     650:	add.2d	v22, v7, v22
     654:	add.2d	v23, v7, v1
     658:	mov.d	x15, v23[1]
     65c:	dup.2d	v26, x4
     660:	add.2d	v24, v23, v26
     664:	add.2d	v25, v23, v17
     668:	dup.2d	v1, x5
     66c:	add.2d	v28, v23, v1
     670:	fmov	x7, d23
     674:	mov.d	x19, v22[1]
     678:	add.2d	v23, v22, v26
     67c:	add.2d	v31, v22, v17
     680:	add.2d	v29, v22, v1
     684:	fmov	x20, d22
     688:	mov.d	x21, v21[1]
     68c:	add.2d	v8, v21, v26
     690:	add.2d	v9, v21, v17
     694:	add.2d	v30, v21, v1
     698:	fmov	x22, d21
     69c:	mov.d	x23, v18[1]
     6a0:	ldr	s21, [x7]
     6a4:	add.2d	v26, v18, v26
     6a8:	add.2d	v10, v18, v17
     6ac:	add.2d	v27, v18, v1
     6b0:	fmov	x7, d18
     6b4:	ushll2.2d	v17, v19, #0x8
     6b8:	ld1.s	{ v21 }[1], [x15]
     6bc:	ld1.s	{ v21 }[2], [x20]
     6c0:	ld1.s	{ v21 }[3], [x19]
     6c4:	mov.d	x15, v24[1]
     6c8:	fmov	x19, d24
     6cc:	ldr	s1, [x22]
     6d0:	mov.d	x20, v23[1]
     6d4:	fmov	x22, d23
     6d8:	ushll2.2d	v18, v20, #0x8
     6dc:	ushll.2d	v19, v19, #0x8
     6e0:	ushll.2d	v20, v20, #0x8
     6e4:	ld1.s	{ v1 }[1], [x21]
     6e8:	ld1.s	{ v1 }[2], [x7]
     6ec:	ld1.s	{ v1 }[3], [x23]
     6f0:	stp	q21, q1, [x9]
     6f4:	fmul.4s	v22, v1, v1
     6f8:	fmul.4s	v21, v21, v21
     6fc:	mov.d	x7, v8[1]
     700:	fmov	x21, d8
     704:	mov.d	x23, v26[1]
     708:	ldr	s1, [x19]
     70c:	ld1.s	{ v1 }[1], [x15]
     710:	ld1.s	{ v1 }[2], [x22]
     714:	ld1.s	{ v1 }[3], [x20]
     718:	fmov	x15, d26
     71c:	ldr	s23, [x21]
     720:	ld1.s	{ v23 }[1], [x7]
     724:	ld1.s	{ v23 }[2], [x15]
     728:	ld1.s	{ v23 }[3], [x23]
     72c:	stp	q1, q23, [x9, #0x20]
     730:	fmul.4s	v24, v23, v23
     734:	fmul.4s	v23, v1, v1
     738:	mov.d	x15, v25[1]
     73c:	mov.d	x7, v31[1]
     740:	mov.d	x19, v9[1]
     744:	fmov	x20, d25
     748:	fmov	x21, d9
     74c:	mov.d	x22, v10[1]
     750:	fmov	x23, d10
     754:	ldr	s1, [x21]
     758:	ld1.s	{ v1 }[1], [x19]
     75c:	ld1.s	{ v1 }[2], [x23]
     760:	ld1.s	{ v1 }[3], [x22]
     764:	fmov	x19, d31
     768:	ldr	s26, [x20]
     76c:	ld1.s	{ v26 }[1], [x15]
     770:	ld1.s	{ v26 }[2], [x19]
     774:	ld1.s	{ v26 }[3], [x7]
     778:	stp	q26, q1, [x9, #0x40]
     77c:	fmul.4s	v25, v1, v1
     780:	fmul.4s	v26, v26, v26
     784:	mov.d	x15, v28[1]
     788:	fmov	x7, d28
     78c:	mov.d	x19, v29[1]
     790:	fmov	x20, d29
     794:	mov.d	x21, v30[1]
     798:	fmov	x22, d30
     79c:	mov.d	x23, v27[1]
     7a0:	ldr	s1, [x7]
     7a4:	ld1.s	{ v1 }[1], [x15]
     7a8:	ld1.s	{ v1 }[2], [x20]
     7ac:	ld1.s	{ v1 }[3], [x19]
     7b0:	fmov	x15, d27
     7b4:	ldr	s27, [x22]
     7b8:	ld1.s	{ v27 }[1], [x21]
     7bc:	ld1.s	{ v27 }[2], [x15]
     7c0:	ld1.s	{ v27 }[3], [x23]
     7c4:	stp	q1, q27, [x9, #0x60]
     7c8:	fmul.4s	v28, v27, v27
     7cc:	fmul.4s	v27, v1, v1
     7d0:	add	x20, x9, x14, lsl #5
     7d4:	add	x15, x14, #0x5
     7d8:	add	x7, x14, #0x6
     7dc:	add	x19, x14, #0x7
     7e0:	add	x14, x14, #0x4
     7e4:	dup.2d	v1, x14
     7e8:	add.2d	v29, v1, v17
     7ec:	add.2d	v30, v1, v19
     7f0:	add.2d	v31, v1, v20
     7f4:	add.2d	v1, v1, v18
     7f8:	shl.2d	v31, v31, #0x2
     7fc:	shl.2d	v1, v1, #0x2
     800:	shl.2d	v30, v30, #0x2
     804:	shl.2d	v29, v29, #0x2
     808:	add.2d	v29, v7, v29
     80c:	add.2d	v30, v7, v30
     810:	add.2d	v1, v7, v1
     814:	add.2d	v31, v7, v31
     818:	mov.d	x21, v31[1]
     81c:	mov.d	x22, v1[1]
     820:	fmov	x23, d31
     824:	fmov	x26, d1
     828:	mov.d	x27, v30[1]
     82c:	fmov	x28, d30
     830:	ldr	s1, [x23]
     834:	mov.d	x23, v29[1]
     838:	ld1.s	{ v1 }[1], [x21]
     83c:	ld1.s	{ v1 }[2], [x26]
     840:	fmov	x21, d29
     844:	ldr	s29, [x28]
     848:	ld1.s	{ v29 }[1], [x27]
     84c:	ld1.s	{ v1 }[3], [x22]
     850:	ld1.s	{ v29 }[2], [x21]
     854:	dup.2d	v30, x15
     858:	ld1.s	{ v29 }[3], [x23]
     85c:	add.2d	v31, v30, v17
     860:	add.2d	v8, v30, v20
     864:	shl.2d	v8, v8, #0x2
     868:	add.2d	v8, v7, v8
     86c:	stp	q1, q29, [x20, #0x80]
     870:	mov.d	x15, v8[1]
     874:	fmov	x21, d8
     878:	add.2d	v8, v30, v19
     87c:	add.2d	v30, v30, v18
     880:	fmul.4s	v1, v1, v1
     884:	shl.2d	v30, v30, #0x2
     888:	shl.2d	v8, v8, #0x2
     88c:	shl.2d	v31, v31, #0x2
     890:	add.2d	v31, v7, v31
     894:	add.2d	v8, v7, v8
     898:	fmul.4s	v29, v29, v29
     89c:	add.2d	v30, v7, v30
     8a0:	mov.d	x22, v30[1]
     8a4:	mov.d	x23, v8[1]
     8a8:	fadd.4s	v22, v22, v29
     8ac:	fmov	x26, d30
     8b0:	fmov	x27, d8
     8b4:	mov.d	x28, v31[1]
     8b8:	ldr	s29, [x21]
     8bc:	fadd.4s	v21, v21, v1
     8c0:	fmov	x21, d31
     8c4:	ld1.s	{ v29 }[1], [x15]
     8c8:	ldr	s1, [x27]
     8cc:	ld1.s	{ v29 }[2], [x26]
     8d0:	ld1.s	{ v1 }[1], [x23]
     8d4:	ld1.s	{ v1 }[2], [x21]
     8d8:	ld1.s	{ v29 }[3], [x22]
     8dc:	dup.2d	v30, x7
     8e0:	add.2d	v31, v30, v17
     8e4:	add.2d	v8, v30, v20
     8e8:	ld1.s	{ v1 }[3], [x28]
     8ec:	shl.2d	v8, v8, #0x2
     8f0:	add.2d	v8, v7, v8
     8f4:	mov.d	x15, v8[1]
     8f8:	stp	q29, q1, [x20, #0xa0]
     8fc:	fmov	x7, d8
     900:	add.2d	v8, v30, v19
     904:	add.2d	v30, v30, v18
     908:	shl.2d	v30, v30, #0x2
     90c:	shl.2d	v8, v8, #0x2
     910:	fmul.4s	v29, v29, v29
     914:	shl.2d	v31, v31, #0x2
     918:	add.2d	v31, v7, v31
     91c:	add.2d	v30, v7, v30
     920:	mov.d	x21, v30[1]
     924:	fmul.4s	v1, v1, v1
     928:	add.2d	v8, v7, v8
     92c:	fmov	x22, d30
     930:	mov.d	x23, v8[1]
     934:	fmov	x26, d8
     938:	fadd.4s	v24, v24, v1
     93c:	mov.d	x27, v31[1]
     940:	ldr	s1, [x26]
     944:	ld1.s	{ v1 }[1], [x23]
     948:	fadd.4s	v23, v23, v29
     94c:	fmov	x23, d31
     950:	ld1.s	{ v1 }[2], [x23]
     954:	ldr	s29, [x7]
     958:	ld1.s	{ v1 }[3], [x27]
     95c:	ld1.s	{ v29 }[1], [x15]
     960:	ld1.s	{ v29 }[2], [x22]
     964:	ld1.s	{ v29 }[3], [x21]
     968:	dup.2d	v30, x19
     96c:	add.2d	v31, v30, v17
     970:	add.2d	v8, v30, v20
     974:	stp	q29, q1, [x20, #0xc0]
     978:	shl.2d	v8, v8, #0x2
     97c:	add.2d	v8, v7, v8
     980:	mov.d	x15, v8[1]
     984:	fmov	x7, d8
     988:	fmul.4s	v29, v29, v29
     98c:	add.2d	v8, v30, v19
     990:	add.2d	v30, v30, v18
     994:	shl.2d	v30, v30, #0x2
     998:	shl.2d	v8, v8, #0x2
     99c:	shl.2d	v31, v31, #0x2
     9a0:	fmul.4s	v1, v1, v1
     9a4:	add.2d	v31, v7, v31
     9a8:	add.2d	v8, v7, v8
     9ac:	add.2d	v30, v7, v30
     9b0:	mov.d	x19, v30[1]
     9b4:	fadd.4s	v25, v25, v1
     9b8:	fmov	x21, d30
     9bc:	mov.d	x22, v8[1]
     9c0:	mov.d	x23, v31[1]
     9c4:	fadd.4s	v26, v26, v29
     9c8:	fmov	x26, d8
     9cc:	ldr	s1, [x7]
     9d0:	ld1.s	{ v1 }[1], [x15]
     9d4:	ld1.s	{ v1 }[2], [x21]
     9d8:	fmov	x15, d31
     9dc:	ldr	s29, [x26]
     9e0:	ld1.s	{ v29 }[1], [x22]
     9e4:	ld1.s	{ v1 }[3], [x19]
     9e8:	ld1.s	{ v29 }[2], [x15]
     9ec:	ld1.s	{ v29 }[3], [x23]
     9f0:	stp	q1, q29, [x20, #0xe0]
     9f4:	fmul.4s	v1, v1, v1
     9f8:	fmul.4s	v29, v29, v29
     9fc:	fadd.4s	v28, v28, v29
     a00:	fadd.4s	v27, v27, v1
     a04:	cmp	x14, #0xfc
     a08:	b.lo	0x7d0
     a0c:	mov	x14, #0x0
     a10:	add	x15, x24, x14, lsl #2
     a14:	ld1r.4s	{ v1 }, [x15]
     a18:	add	x15, x6, x14, lsl #5
     a1c:	stp	q1, q1, [x15]
     a20:	add	x14, x14, #0x1
     a24:	cmp	x14, #0x100
     a28:	b.ne	0xa10
     a2c:	mov	x14, #0x0
     a30:	fadd.4s	v1, v22, v24
     a34:	fadd.4s	v21, v21, v23
     a38:	fadd.4s	v21, v21, v26
     a3c:	fadd.4s	v1, v1, v25
     a40:	fadd.4s	v1, v1, v28
     a44:	fadd.4s	v21, v21, v27
     a48:	fmul.4s	v21, v21, v6
     a4c:	fmul.4s	v1, v1, v6
     a50:	fadd.4s	v1, v1, v5
     a54:	fadd.4s	v21, v21, v5
     a58:	fsqrt.4s	v21, v21
     a5c:	fsqrt.4s	v22, v1
     a60:	dup.2d	v1, x14
     a64:	add.2d	v23, v1, v17
     a68:	add.2d	v24, v1, v19
     a6c:	add.2d	v25, v1, v18
     a70:	add.2d	v1, v1, v20
     a74:	lsl	x15, x14, #5
     a78:	add	x7, x9, x15
     a7c:	ldp	q27, q26, [x7]
     a80:	fdiv.4s	v27, v27, v21
     a84:	fdiv.4s	v26, v26, v22
     a88:	add	x15, x6, x15
     a8c:	ldp	q28, q29, [x15]
     a90:	fmul.4s	v26, v26, v29
     a94:	fmul.4s	v27, v27, v28
     a98:	shl.2d	v1, v1, #0x2
     a9c:	shl.2d	v25, v25, #0x2
     aa0:	shl.2d	v24, v24, #0x2
     aa4:	shl.2d	v23, v23, #0x2
     aa8:	add.2d	v23, v16, v23
     aac:	add.2d	v1, v16, v1
     ab0:	mov.d	x15, v1[1]
     ab4:	fmov	x7, d1
     ab8:	str	s27, [x7]
     abc:	st1.s	{ v27 }[1], [x15]
     ac0:	add.2d	v1, v16, v25
     ac4:	mov.d	x15, v1[1]
     ac8:	fmov	x7, d1
     acc:	st1.s	{ v27 }[2], [x7]
     ad0:	add.2d	v1, v16, v24
     ad4:	st1.s	{ v27 }[3], [x15]
     ad8:	mov.d	x15, v1[1]
     adc:	fmov	x7, d1
     ae0:	str	s26, [x7]
     ae4:	st1.s	{ v26 }[1], [x15]
     ae8:	mov.d	x15, v23[1]
     aec:	fmov	x7, d23
     af0:	st1.s	{ v26 }[2], [x7]
     af4:	st1.s	{ v26 }[3], [x15]
     af8:	add	x14, x14, #0x1
     afc:	cmp	x14, #0x100
     b00:	b.ne	0xa60
     b04:	mov	x14, #0x0
     b08:	orr	w15, w25, #0x10
     b0c:	dup.4s	v1, w15
     b10:	orr.16b	v19, v1, v0
     b14:	orr.16b	v20, v1, v3
     b18:	dup.2d	v17, x16
     b1c:	ushll.2d	v1, v20, #0xa
     b20:	ushll2.2d	v22, v20, #0xa
     b24:	ushll.2d	v21, v19, #0xa
     b28:	ushll2.2d	v18, v19, #0xa
     b2c:	add.2d	v18, v7, v18
     b30:	add.2d	v21, v7, v21
     b34:	add.2d	v22, v7, v22
     b38:	add.2d	v23, v7, v1
     b3c:	mov.d	x15, v23[1]
     b40:	dup.2d	v26, x4
     b44:	add.2d	v24, v23, v26
     b48:	add.2d	v25, v23, v17
     b4c:	dup.2d	v1, x5
     b50:	add.2d	v28, v23, v1
     b54:	fmov	x7, d23
     b58:	mov.d	x19, v22[1]
     b5c:	add.2d	v23, v22, v26
     b60:	add.2d	v31, v22, v17
     b64:	add.2d	v29, v22, v1
     b68:	fmov	x20, d22
     b6c:	mov.d	x21, v21[1]
     b70:	add.2d	v8, v21, v26
     b74:	add.2d	v9, v21, v17
     b78:	add.2d	v30, v21, v1
     b7c:	fmov	x22, d21
     b80:	mov.d	x23, v18[1]
     b84:	ldr	s21, [x7]
     b88:	add.2d	v26, v18, v26
     b8c:	add.2d	v10, v18, v17
     b90:	add.2d	v27, v18, v1
     b94:	fmov	x7, d18
     b98:	ushll2.2d	v17, v19, #0x8
     b9c:	ld1.s	{ v21 }[1], [x15]
     ba0:	ld1.s	{ v21 }[2], [x20]
     ba4:	ld1.s	{ v21 }[3], [x19]
     ba8:	mov.d	x15, v24[1]
     bac:	fmov	x19, d24
     bb0:	ldr	s1, [x22]
     bb4:	mov.d	x20, v23[1]
     bb8:	fmov	x22, d23
     bbc:	ushll2.2d	v18, v20, #0x8
     bc0:	ushll.2d	v19, v19, #0x8
     bc4:	ushll.2d	v20, v20, #0x8
     bc8:	ld1.s	{ v1 }[1], [x21]
     bcc:	ld1.s	{ v1 }[2], [x7]
     bd0:	ld1.s	{ v1 }[3], [x23]
     bd4:	stp	q21, q1, [x9]
     bd8:	fmul.4s	v22, v1, v1
     bdc:	fmul.4s	v21, v21, v21
     be0:	mov.d	x7, v8[1]
     be4:	fmov	x21, d8
     be8:	mov.d	x23, v26[1]
     bec:	ldr	s1, [x19]
     bf0:	ld1.s	{ v1 }[1], [x15]
     bf4:	ld1.s	{ v1 }[2], [x22]
     bf8:	ld1.s	{ v1 }[3], [x20]
     bfc:	fmov	x15, d26
     c00:	ldr	s23, [x21]
     c04:	ld1.s	{ v23 }[1], [x7]
     c08:	ld1.s	{ v23 }[2], [x15]
     c0c:	ld1.s	{ v23 }[3], [x23]
     c10:	stp	q1, q23, [x9, #0x20]
     c14:	fmul.4s	v24, v23, v23
     c18:	fmul.4s	v23, v1, v1
     c1c:	mov.d	x15, v25[1]
     c20:	mov.d	x7, v31[1]
     c24:	mov.d	x19, v9[1]
     c28:	fmov	x20, d25
     c2c:	fmov	x21, d9
     c30:	mov.d	x22, v10[1]
     c34:	fmov	x23, d10
     c38:	ldr	s1, [x21]
     c3c:	ld1.s	{ v1 }[1], [x19]
     c40:	ld1.s	{ v1 }[2], [x23]
     c44:	ld1.s	{ v1 }[3], [x22]
     c48:	fmov	x19, d31
     c4c:	ldr	s26, [x20]
     c50:	ld1.s	{ v26 }[1], [x15]
     c54:	ld1.s	{ v26 }[2], [x19]
     c58:	ld1.s	{ v26 }[3], [x7]
     c5c:	stp	q26, q1, [x9, #0x40]
     c60:	fmul.4s	v25, v1, v1
     c64:	fmul.4s	v26, v26, v26
     c68:	mov.d	x15, v28[1]
     c6c:	fmov	x7, d28
     c70:	mov.d	x19, v29[1]
     c74:	fmov	x20, d29
     c78:	mov.d	x21, v30[1]
     c7c:	fmov	x22, d30
     c80:	mov.d	x23, v27[1]
     c84:	ldr	s1, [x7]
     c88:	ld1.s	{ v1 }[1], [x15]
     c8c:	ld1.s	{ v1 }[2], [x20]
     c90:	ld1.s	{ v1 }[3], [x19]
     c94:	fmov	x15, d27
     c98:	ldr	s27, [x22]
     c9c:	ld1.s	{ v27 }[1], [x21]
     ca0:	ld1.s	{ v27 }[2], [x15]
     ca4:	ld1.s	{ v27 }[3], [x23]
     ca8:	stp	q1, q27, [x9, #0x60]
     cac:	fmul.4s	v28, v27, v27
     cb0:	fmul.4s	v27, v1, v1
     cb4:	add	x20, x9, x14, lsl #5
     cb8:	add	x15, x14, #0x5
     cbc:	add	x7, x14, #0x6
     cc0:	add	x19, x14, #0x7
     cc4:	add	x14, x14, #0x4
     cc8:	dup.2d	v1, x14
     ccc:	add.2d	v29, v1, v17
     cd0:	add.2d	v30, v1, v19
     cd4:	add.2d	v31, v1, v20
     cd8:	add.2d	v1, v1, v18
     cdc:	shl.2d	v31, v31, #0x2
     ce0:	shl.2d	v1, v1, #0x2
     ce4:	shl.2d	v30, v30, #0x2
     ce8:	shl.2d	v29, v29, #0x2
     cec:	add.2d	v29, v7, v29
     cf0:	add.2d	v30, v7, v30
     cf4:	add.2d	v1, v7, v1
     cf8:	add.2d	v31, v7, v31
     cfc:	mov.d	x21, v31[1]
     d00:	mov.d	x22, v1[1]
     d04:	fmov	x23, d31
     d08:	fmov	x26, d1
     d0c:	mov.d	x27, v30[1]
     d10:	fmov	x28, d30
     d14:	ldr	s1, [x23]
     d18:	mov.d	x23, v29[1]
     d1c:	ld1.s	{ v1 }[1], [x21]
     d20:	ld1.s	{ v1 }[2], [x26]
     d24:	fmov	x21, d29
     d28:	ldr	s29, [x28]
     d2c:	ld1.s	{ v29 }[1], [x27]
     d30:	ld1.s	{ v1 }[3], [x22]
     d34:	ld1.s	{ v29 }[2], [x21]
     d38:	dup.2d	v30, x15
     d3c:	ld1.s	{ v29 }[3], [x23]
     d40:	add.2d	v31, v30, v17
     d44:	add.2d	v8, v30, v20
     d48:	shl.2d	v8, v8, #0x2
     d4c:	add.2d	v8, v7, v8
     d50:	stp	q1, q29, [x20, #0x80]
     d54:	mov.d	x15, v8[1]
     d58:	fmov	x21, d8
     d5c:	add.2d	v8, v30, v19
     d60:	add.2d	v30, v30, v18
     d64:	fmul.4s	v1, v1, v1
     d68:	shl.2d	v30, v30, #0x2
     d6c:	shl.2d	v8, v8, #0x2
     d70:	shl.2d	v31, v31, #0x2
     d74:	add.2d	v31, v7, v31
     d78:	add.2d	v8, v7, v8
     d7c:	fmul.4s	v29, v29, v29
     d80:	add.2d	v30, v7, v30
     d84:	mov.d	x22, v30[1]
     d88:	mov.d	x23, v8[1]
     d8c:	fadd.4s	v22, v22, v29
     d90:	fmov	x26, d30
     d94:	fmov	x27, d8
     d98:	mov.d	x28, v31[1]
     d9c:	ldr	s29, [x21]
     da0:	fadd.4s	v21, v21, v1
     da4:	fmov	x21, d31
     da8:	ld1.s	{ v29 }[1], [x15]
     dac:	ldr	s1, [x27]
     db0:	ld1.s	{ v29 }[2], [x26]
     db4:	ld1.s	{ v1 }[1], [x23]
     db8:	ld1.s	{ v1 }[2], [x21]
     dbc:	ld1.s	{ v29 }[3], [x22]
     dc0:	dup.2d	v30, x7
     dc4:	add.2d	v31, v30, v17
     dc8:	add.2d	v8, v30, v20
     dcc:	ld1.s	{ v1 }[3], [x28]
     dd0:	shl.2d	v8, v8, #0x2
     dd4:	add.2d	v8, v7, v8
     dd8:	mov.d	x15, v8[1]
     ddc:	stp	q29, q1, [x20, #0xa0]
     de0:	fmov	x7, d8
     de4:	add.2d	v8, v30, v19
     de8:	add.2d	v30, v30, v18
     dec:	shl.2d	v30, v30, #0x2
     df0:	shl.2d	v8, v8, #0x2
     df4:	fmul.4s	v29, v29, v29
     df8:	shl.2d	v31, v31, #0x2
     dfc:	add.2d	v31, v7, v31
     e00:	add.2d	v30, v7, v30
     e04:	mov.d	x21, v30[1]
     e08:	fmul.4s	v1, v1, v1
     e0c:	add.2d	v8, v7, v8
     e10:	fmov	x22, d30
     e14:	mov.d	x23, v8[1]
     e18:	fmov	x26, d8
     e1c:	fadd.4s	v24, v24, v1
     e20:	mov.d	x27, v31[1]
     e24:	ldr	s1, [x26]
     e28:	ld1.s	{ v1 }[1], [x23]
     e2c:	fadd.4s	v23, v23, v29
     e30:	fmov	x23, d31
     e34:	ld1.s	{ v1 }[2], [x23]
     e38:	ldr	s29, [x7]
     e3c:	ld1.s	{ v1 }[3], [x27]
     e40:	ld1.s	{ v29 }[1], [x15]
     e44:	ld1.s	{ v29 }[2], [x22]
     e48:	ld1.s	{ v29 }[3], [x21]
     e4c:	dup.2d	v30, x19
     e50:	add.2d	v31, v30, v17
     e54:	add.2d	v8, v30, v20
     e58:	stp	q29, q1, [x20, #0xc0]
     e5c:	shl.2d	v8, v8, #0x2
     e60:	add.2d	v8, v7, v8
     e64:	mov.d	x15, v8[1]
     e68:	fmov	x7, d8
     e6c:	fmul.4s	v29, v29, v29
     e70:	add.2d	v8, v30, v19
     e74:	add.2d	v30, v30, v18
     e78:	shl.2d	v30, v30, #0x2
     e7c:	shl.2d	v8, v8, #0x2
     e80:	shl.2d	v31, v31, #0x2
     e84:	fmul.4s	v1, v1, v1
     e88:	add.2d	v31, v7, v31
     e8c:	add.2d	v8, v7, v8
     e90:	add.2d	v30, v7, v30
     e94:	mov.d	x19, v30[1]
     e98:	fadd.4s	v25, v25, v1
     e9c:	fmov	x21, d30
     ea0:	mov.d	x22, v8[1]
     ea4:	mov.d	x23, v31[1]
     ea8:	fadd.4s	v26, v26, v29
     eac:	fmov	x26, d8
     eb0:	ldr	s1, [x7]
     eb4:	ld1.s	{ v1 }[1], [x15]
     eb8:	ld1.s	{ v1 }[2], [x21]
     ebc:	fmov	x15, d31
     ec0:	ldr	s29, [x26]
     ec4:	ld1.s	{ v29 }[1], [x22]
     ec8:	ld1.s	{ v1 }[3], [x19]
     ecc:	ld1.s	{ v29 }[2], [x15]
     ed0:	ld1.s	{ v29 }[3], [x23]
     ed4:	stp	q1, q29, [x20, #0xe0]
     ed8:	fmul.4s	v1, v1, v1
     edc:	fmul.4s	v29, v29, v29
     ee0:	fadd.4s	v28, v28, v29
     ee4:	fadd.4s	v27, v27, v1
     ee8:	cmp	x14, #0xfc
     eec:	b.lo	0xcb4
     ef0:	mov	x14, #0x0
     ef4:	add	x15, x24, x14, lsl #2
     ef8:	ld1r.4s	{ v1 }, [x15]
     efc:	add	x15, x6, x14, lsl #5
     f00:	stp	q1, q1, [x15]
     f04:	add	x14, x14, #0x1
     f08:	cmp	x14, #0x100
     f0c:	b.ne	0xef4
     f10:	mov	x14, #0x0
     f14:	fadd.4s	v1, v22, v24
     f18:	fadd.4s	v21, v21, v23
     f1c:	fadd.4s	v21, v21, v26
     f20:	fadd.4s	v1, v1, v25
     f24:	fadd.4s	v1, v1, v28
     f28:	fadd.4s	v21, v21, v27
     f2c:	fmul.4s	v21, v21, v6
     f30:	fmul.4s	v1, v1, v6
     f34:	fadd.4s	v1, v1, v5
     f38:	fadd.4s	v21, v21, v5
     f3c:	fsqrt.4s	v21, v21
     f40:	fsqrt.4s	v22, v1
     f44:	dup.2d	v1, x14
     f48:	add.2d	v23, v1, v17
     f4c:	add.2d	v24, v1, v19
     f50:	add.2d	v25, v1, v18
     f54:	add.2d	v1, v1, v20
     f58:	lsl	x15, x14, #5
     f5c:	add	x7, x9, x15
     f60:	ldp	q27, q26, [x7]
     f64:	fdiv.4s	v27, v27, v21
     f68:	fdiv.4s	v26, v26, v22
     f6c:	add	x15, x6, x15
     f70:	ldp	q28, q29, [x15]
     f74:	fmul.4s	v26, v26, v29
     f78:	fmul.4s	v27, v27, v28
     f7c:	shl.2d	v1, v1, #0x2
     f80:	shl.2d	v25, v25, #0x2
     f84:	shl.2d	v24, v24, #0x2
     f88:	shl.2d	v23, v23, #0x2
     f8c:	add.2d	v23, v16, v23
     f90:	add.2d	v1, v16, v1
     f94:	mov.d	x15, v1[1]
     f98:	fmov	x7, d1
     f9c:	str	s27, [x7]
     fa0:	st1.s	{ v27 }[1], [x15]
     fa4:	add.2d	v1, v16, v25
     fa8:	mov.d	x15, v1[1]
     fac:	fmov	x7, d1
     fb0:	st1.s	{ v27 }[2], [x7]
     fb4:	add.2d	v1, v16, v24
     fb8:	st1.s	{ v27 }[3], [x15]
     fbc:	mov.d	x15, v1[1]
     fc0:	fmov	x7, d1
     fc4:	str	s26, [x7]
     fc8:	st1.s	{ v26 }[1], [x15]
     fcc:	mov.d	x15, v23[1]
     fd0:	fmov	x7, d23
     fd4:	st1.s	{ v26 }[2], [x7]
     fd8:	st1.s	{ v26 }[3], [x15]
     fdc:	add	x14, x14, #0x1
     fe0:	cmp	x14, #0x100
     fe4:	b.ne	0xf44
     fe8:	mov	x14, #0x0
     fec:	mov	w10, #0x18
     ff0:	str	w10, [x2, #0x24]
     ff4:	orr	w15, w25, #0x18
     ff8:	dup.4s	v1, w15
     ffc:	orr.16b	v19, v1, v0
    1000:	orr.16b	v20, v1, v3
    1004:	dup.2d	v17, x16
    1008:	ushll.2d	v1, v20, #0xa
    100c:	ushll2.2d	v22, v20, #0xa
    1010:	ushll.2d	v21, v19, #0xa
    1014:	ushll2.2d	v18, v19, #0xa
    1018:	add.2d	v18, v7, v18
    101c:	add.2d	v21, v7, v21
    1020:	add.2d	v22, v7, v22
    1024:	add.2d	v23, v7, v1
    1028:	mov.d	x15, v23[1]
    102c:	dup.2d	v26, x4
    1030:	add.2d	v24, v23, v26
    1034:	add.2d	v25, v23, v17
    1038:	dup.2d	v1, x5
    103c:	add.2d	v28, v23, v1
    1040:	fmov	x7, d23
    1044:	mov.d	x19, v22[1]
    1048:	add.2d	v23, v22, v26
    104c:	add.2d	v31, v22, v17
    1050:	add.2d	v29, v22, v1
    1054:	fmov	x20, d22
    1058:	mov.d	x21, v21[1]
    105c:	add.2d	v8, v21, v26
    1060:	add.2d	v9, v21, v17
    1064:	add.2d	v30, v21, v1
    1068:	fmov	x22, d21
    106c:	mov.d	x23, v18[1]
    1070:	ldr	s21, [x7]
    1074:	add.2d	v26, v18, v26
    1078:	add.2d	v10, v18, v17
    107c:	add.2d	v27, v18, v1
    1080:	fmov	x7, d18
    1084:	ushll2.2d	v17, v19, #0x8
    1088:	ld1.s	{ v21 }[1], [x15]
    108c:	ld1.s	{ v21 }[2], [x20]
    1090:	ld1.s	{ v21 }[3], [x19]
    1094:	mov.d	x15, v24[1]
    1098:	fmov	x19, d24
    109c:	ldr	s1, [x22]
    10a0:	mov.d	x20, v23[1]
    10a4:	fmov	x22, d23
    10a8:	ushll2.2d	v18, v20, #0x8
    10ac:	ushll.2d	v19, v19, #0x8
    10b0:	ushll.2d	v20, v20, #0x8
    10b4:	ld1.s	{ v1 }[1], [x21]
    10b8:	ld1.s	{ v1 }[2], [x7]
    10bc:	ld1.s	{ v1 }[3], [x23]
    10c0:	stp	q21, q1, [x9]
    10c4:	fmul.4s	v22, v1, v1
    10c8:	fmul.4s	v21, v21, v21
    10cc:	mov.d	x7, v8[1]
    10d0:	fmov	x21, d8
    10d4:	mov.d	x23, v26[1]
    10d8:	ldr	s1, [x19]
    10dc:	ld1.s	{ v1 }[1], [x15]
    10e0:	ld1.s	{ v1 }[2], [x22]
    10e4:	ld1.s	{ v1 }[3], [x20]
    10e8:	fmov	x15, d26
    10ec:	ldr	s23, [x21]
    10f0:	ld1.s	{ v23 }[1], [x7]
    10f4:	ld1.s	{ v23 }[2], [x15]
    10f8:	ld1.s	{ v23 }[3], [x23]
    10fc:	stp	q1, q23, [x9, #0x20]
    1100:	fmul.4s	v24, v23, v23
    1104:	fmul.4s	v23, v1, v1
    1108:	mov.d	x15, v25[1]
    110c:	mov.d	x7, v31[1]
    1110:	mov.d	x19, v9[1]
    1114:	fmov	x20, d25
    1118:	fmov	x21, d9
    111c:	mov.d	x22, v10[1]
    1120:	fmov	x23, d10
    1124:	ldr	s1, [x21]
    1128:	ld1.s	{ v1 }[1], [x19]
    112c:	ld1.s	{ v1 }[2], [x23]
    1130:	ld1.s	{ v1 }[3], [x22]
    1134:	fmov	x19, d31
    1138:	ldr	s26, [x20]
    113c:	ld1.s	{ v26 }[1], [x15]
    1140:	ld1.s	{ v26 }[2], [x19]
    1144:	ld1.s	{ v26 }[3], [x7]
    1148:	stp	q26, q1, [x9, #0x40]
    114c:	fmul.4s	v25, v1, v1
    1150:	fmul.4s	v26, v26, v26
    1154:	mov.d	x15, v28[1]
    1158:	fmov	x7, d28
    115c:	mov.d	x19, v29[1]
    1160:	fmov	x20, d29
    1164:	mov.d	x21, v30[1]
    1168:	fmov	x22, d30
    116c:	mov.d	x23, v27[1]
    1170:	ldr	s1, [x7]
    1174:	ld1.s	{ v1 }[1], [x15]
    1178:	ld1.s	{ v1 }[2], [x20]
    117c:	ld1.s	{ v1 }[3], [x19]
    1180:	fmov	x15, d27
    1184:	ldr	s27, [x22]
    1188:	ld1.s	{ v27 }[1], [x21]
    118c:	ld1.s	{ v27 }[2], [x15]
    1190:	ld1.s	{ v27 }[3], [x23]
    1194:	stp	q1, q27, [x9, #0x60]
    1198:	fmul.4s	v28, v27, v27
    119c:	fmul.4s	v27, v1, v1
    11a0:	add	x20, x9, x14, lsl #5
    11a4:	add	x15, x14, #0x5
    11a8:	add	x7, x14, #0x6
    11ac:	add	x19, x14, #0x7
    11b0:	add	x14, x14, #0x4
    11b4:	dup.2d	v1, x14
    11b8:	add.2d	v29, v1, v17
    11bc:	add.2d	v30, v1, v19
    11c0:	add.2d	v31, v1, v20
    11c4:	add.2d	v1, v1, v18
    11c8:	shl.2d	v31, v31, #0x2
    11cc:	shl.2d	v1, v1, #0x2
    11d0:	shl.2d	v30, v30, #0x2
    11d4:	shl.2d	v29, v29, #0x2
    11d8:	add.2d	v29, v7, v29
    11dc:	add.2d	v30, v7, v30
    11e0:	add.2d	v1, v7, v1
    11e4:	add.2d	v31, v7, v31
    11e8:	mov.d	x21, v31[1]
    11ec:	mov.d	x22, v1[1]
    11f0:	fmov	x23, d31
    11f4:	fmov	x26, d1
    11f8:	mov.d	x27, v30[1]
    11fc:	fmov	x28, d30
    1200:	ldr	s1, [x23]
    1204:	mov.d	x23, v29[1]
    1208:	ld1.s	{ v1 }[1], [x21]
    120c:	ld1.s	{ v1 }[2], [x26]
    1210:	fmov	x21, d29
    1214:	ldr	s29, [x28]
    1218:	ld1.s	{ v29 }[1], [x27]
    121c:	ld1.s	{ v1 }[3], [x22]
    1220:	ld1.s	{ v29 }[2], [x21]
    1224:	dup.2d	v30, x15
    1228:	ld1.s	{ v29 }[3], [x23]
    122c:	add.2d	v31, v30, v17
    1230:	add.2d	v8, v30, v20
    1234:	shl.2d	v8, v8, #0x2
    1238:	add.2d	v8, v7, v8
    123c:	stp	q1, q29, [x20, #0x80]
    1240:	mov.d	x15, v8[1]
    1244:	fmov	x21, d8
    1248:	add.2d	v8, v30, v19
    124c:	add.2d	v30, v30, v18
    1250:	fmul.4s	v1, v1, v1
    1254:	shl.2d	v30, v30, #0x2
    1258:	shl.2d	v8, v8, #0x2
    125c:	shl.2d	v31, v31, #0x2
    1260:	add.2d	v31, v7, v31
    1264:	add.2d	v8, v7, v8
    1268:	fmul.4s	v29, v29, v29
    126c:	add.2d	v30, v7, v30
    1270:	mov.d	x22, v30[1]
    1274:	mov.d	x23, v8[1]
    1278:	fadd.4s	v22, v22, v29
    127c:	fmov	x26, d30
    1280:	fmov	x27, d8
    1284:	mov.d	x28, v31[1]
    1288:	ldr	s29, [x21]
    128c:	fadd.4s	v21, v21, v1
    1290:	fmov	x21, d31
    1294:	ld1.s	{ v29 }[1], [x15]
    1298:	ldr	s1, [x27]
    129c:	ld1.s	{ v29 }[2], [x26]
    12a0:	ld1.s	{ v1 }[1], [x23]
    12a4:	ld1.s	{ v1 }[2], [x21]
    12a8:	ld1.s	{ v29 }[3], [x22]
    12ac:	dup.2d	v30, x7
    12b0:	add.2d	v31, v30, v17
    12b4:	add.2d	v8, v30, v20
    12b8:	ld1.s	{ v1 }[3], [x28]
    12bc:	shl.2d	v8, v8, #0x2
    12c0:	add.2d	v8, v7, v8
    12c4:	mov.d	x15, v8[1]
    12c8:	stp	q29, q1, [x20, #0xa0]
    12cc:	fmov	x7, d8
    12d0:	add.2d	v8, v30, v19
    12d4:	add.2d	v30, v30, v18
    12d8:	shl.2d	v30, v30, #0x2
    12dc:	shl.2d	v8, v8, #0x2
    12e0:	fmul.4s	v29, v29, v29
    12e4:	shl.2d	v31, v31, #0x2
    12e8:	add.2d	v31, v7, v31
    12ec:	add.2d	v30, v7, v30
    12f0:	mov.d	x21, v30[1]
    12f4:	fmul.4s	v1, v1, v1
    12f8:	add.2d	v8, v7, v8
    12fc:	fmov	x22, d30
    1300:	mov.d	x23, v8[1]
    1304:	fmov	x26, d8
    1308:	fadd.4s	v24, v24, v1
    130c:	mov.d	x27, v31[1]
    1310:	ldr	s1, [x26]
    1314:	ld1.s	{ v1 }[1], [x23]
    1318:	fadd.4s	v23, v23, v29
    131c:	fmov	x23, d31
    1320:	ld1.s	{ v1 }[2], [x23]
    1324:	ldr	s29, [x7]
    1328:	ld1.s	{ v1 }[3], [x27]
    132c:	ld1.s	{ v29 }[1], [x15]
    1330:	ld1.s	{ v29 }[2], [x22]
    1334:	ld1.s	{ v29 }[3], [x21]
    1338:	dup.2d	v30, x19
    133c:	add.2d	v31, v30, v17
    1340:	add.2d	v8, v30, v20
    1344:	stp	q29, q1, [x20, #0xc0]
    1348:	shl.2d	v8, v8, #0x2
    134c:	add.2d	v8, v7, v8
    1350:	mov.d	x15, v8[1]
    1354:	fmov	x7, d8
    1358:	fmul.4s	v29, v29, v29
    135c:	add.2d	v8, v30, v19
    1360:	add.2d	v30, v30, v18
    1364:	shl.2d	v30, v30, #0x2
    1368:	shl.2d	v8, v8, #0x2
    136c:	shl.2d	v31, v31, #0x2
    1370:	fmul.4s	v1, v1, v1
    1374:	add.2d	v31, v7, v31
    1378:	add.2d	v8, v7, v8
    137c:	add.2d	v30, v7, v30
    1380:	mov.d	x19, v30[1]
    1384:	fadd.4s	v25, v25, v1
    1388:	fmov	x21, d30
    138c:	mov.d	x22, v8[1]
    1390:	mov.d	x23, v31[1]
    1394:	fadd.4s	v26, v26, v29
    1398:	fmov	x26, d8
    139c:	ldr	s1, [x7]
    13a0:	ld1.s	{ v1 }[1], [x15]
    13a4:	ld1.s	{ v1 }[2], [x21]
    13a8:	fmov	x15, d31
    13ac:	ldr	s29, [x26]
    13b0:	ld1.s	{ v29 }[1], [x22]
    13b4:	ld1.s	{ v1 }[3], [x19]
    13b8:	ld1.s	{ v29 }[2], [x15]
    13bc:	ld1.s	{ v29 }[3], [x23]
    13c0:	stp	q1, q29, [x20, #0xe0]
    13c4:	fmul.4s	v1, v1, v1
    13c8:	fmul.4s	v29, v29, v29
    13cc:	fadd.4s	v28, v28, v29
    13d0:	fadd.4s	v27, v27, v1
    13d4:	cmp	x14, #0xfc
    13d8:	b.lo	0x11a0
    13dc:	mov	x14, #0x0
    13e0:	add	x15, x24, x14, lsl #2
    13e4:	ld1r.4s	{ v1 }, [x15]
    13e8:	add	x15, x6, x14, lsl #5
    13ec:	stp	q1, q1, [x15]
    13f0:	add	x14, x14, #0x1
    13f4:	cmp	x14, #0x100
    13f8:	b.ne	0x13e0
    13fc:	mov	x14, #0x0
    1400:	fadd.4s	v1, v22, v24
    1404:	fadd.4s	v21, v21, v23
    1408:	fadd.4s	v21, v21, v26
    140c:	fadd.4s	v1, v1, v25
    1410:	fadd.4s	v1, v1, v28
    1414:	fadd.4s	v21, v21, v27
    1418:	fmul.4s	v21, v21, v6
    141c:	fmul.4s	v1, v1, v6
    1420:	fadd.4s	v1, v1, v5
    1424:	fadd.4s	v21, v21, v5
    1428:	fsqrt.4s	v21, v21
    142c:	fsqrt.4s	v22, v1
    1430:	dup.2d	v1, x14
    1434:	add.2d	v23, v1, v17
    1438:	add.2d	v24, v1, v19
    143c:	add.2d	v25, v1, v18
    1440:	add.2d	v1, v1, v20
    1444:	lsl	x15, x14, #5
    1448:	add	x7, x9, x15
    144c:	ldp	q27, q26, [x7]
    1450:	fdiv.4s	v27, v27, v21
    1454:	fdiv.4s	v26, v26, v22
    1458:	add	x15, x6, x15
    145c:	ldp	q28, q29, [x15]
    1460:	fmul.4s	v26, v26, v29
    1464:	fmul.4s	v27, v27, v28
    1468:	shl.2d	v1, v1, #0x2
    146c:	shl.2d	v25, v25, #0x2
    1470:	shl.2d	v24, v24, #0x2
    1474:	shl.2d	v23, v23, #0x2
    1478:	add.2d	v23, v16, v23
    147c:	add.2d	v1, v16, v1
    1480:	mov.d	x15, v1[1]
    1484:	fmov	x7, d1
    1488:	str	s27, [x7]
    148c:	st1.s	{ v27 }[1], [x15]
    1490:	add.2d	v1, v16, v25
    1494:	mov.d	x15, v1[1]
    1498:	fmov	x7, d1
    149c:	st1.s	{ v27 }[2], [x7]
    14a0:	add.2d	v1, v16, v24
    14a4:	st1.s	{ v27 }[3], [x15]
    14a8:	mov.d	x15, v1[1]
    14ac:	fmov	x7, d1
    14b0:	str	s26, [x7]
    14b4:	st1.s	{ v26 }[1], [x15]
    14b8:	mov.d	x15, v23[1]
    14bc:	fmov	x7, d23
    14c0:	st1.s	{ v26 }[2], [x7]
    14c4:	st1.s	{ v26 }[3], [x15]
    14c8:	add	x14, x14, #0x1
    14cc:	cmp	x14, #0x100
    14d0:	b.ne	0x1430
    14d4:	mov	x14, #0x0
    14d8:	orr	w15, w25, #0x20
    14dc:	dup.4s	v1, w15
    14e0:	orr.16b	v19, v1, v0
    14e4:	orr.16b	v20, v1, v3
    14e8:	dup.2d	v17, x16
    14ec:	ushll.2d	v1, v20, #0xa
    14f0:	ushll2.2d	v22, v20, #0xa
    14f4:	ushll.2d	v21, v19, #0xa
    14f8:	ushll2.2d	v18, v19, #0xa
    14fc:	add.2d	v18, v7, v18
    1500:	add.2d	v21, v7, v21
    1504:	add.2d	v22, v7, v22
    1508:	add.2d	v23, v7, v1
    150c:	mov.d	x15, v23[1]
    1510:	dup.2d	v26, x4
    1514:	add.2d	v24, v23, v26
    1518:	add.2d	v25, v23, v17
    151c:	dup.2d	v1, x5
    1520:	add.2d	v28, v23, v1
    1524:	fmov	x7, d23
    1528:	mov.d	x19, v22[1]
    152c:	add.2d	v23, v22, v26
    1530:	add.2d	v31, v22, v17
    1534:	add.2d	v29, v22, v1
    1538:	fmov	x20, d22
    153c:	mov.d	x21, v21[1]
    1540:	add.2d	v8, v21, v26
    1544:	add.2d	v9, v21, v17
    1548:	add.2d	v30, v21, v1
    154c:	fmov	x22, d21
    1550:	mov.d	x23, v18[1]
    1554:	ldr	s21, [x7]
    1558:	add.2d	v26, v18, v26
    155c:	add.2d	v10, v18, v17
    1560:	add.2d	v27, v18, v1
    1564:	fmov	x7, d18
    1568:	ushll2.2d	v17, v19, #0x8
    156c:	ld1.s	{ v21 }[1], [x15]
    1570:	ld1.s	{ v21 }[2], [x20]
    1574:	ld1.s	{ v21 }[3], [x19]
    1578:	mov.d	x15, v24[1]
    157c:	fmov	x19, d24
    1580:	ldr	s1, [x22]
    1584:	mov.d	x20, v23[1]
    1588:	fmov	x22, d23
    158c:	ushll2.2d	v18, v20, #0x8
    1590:	ushll.2d	v19, v19, #0x8
    1594:	ushll.2d	v20, v20, #0x8
    1598:	ld1.s	{ v1 }[1], [x21]
    159c:	ld1.s	{ v1 }[2], [x7]
    15a0:	ld1.s	{ v1 }[3], [x23]
    15a4:	stp	q21, q1, [x9]
    15a8:	fmul.4s	v22, v1, v1
    15ac:	fmul.4s	v21, v21, v21
    15b0:	mov.d	x7, v8[1]
    15b4:	fmov	x21, d8
    15b8:	mov.d	x23, v26[1]
    15bc:	ldr	s1, [x19]
    15c0:	ld1.s	{ v1 }[1], [x15]
    15c4:	ld1.s	{ v1 }[2], [x22]
    15c8:	ld1.s	{ v1 }[3], [x20]
    15cc:	fmov	x15, d26
    15d0:	ldr	s23, [x21]
    15d4:	ld1.s	{ v23 }[1], [x7]
    15d8:	ld1.s	{ v23 }[2], [x15]
    15dc:	ld1.s	{ v23 }[3], [x23]
    15e0:	stp	q1, q23, [x9, #0x20]
    15e4:	fmul.4s	v24, v23, v23
    15e8:	fmul.4s	v23, v1, v1
    15ec:	mov.d	x15, v25[1]
    15f0:	mov.d	x7, v31[1]
    15f4:	mov.d	x19, v9[1]
    15f8:	fmov	x20, d25
    15fc:	fmov	x21, d9
    1600:	mov.d	x22, v10[1]
    1604:	fmov	x23, d10
    1608:	ldr	s1, [x21]
    160c:	ld1.s	{ v1 }[1], [x19]
    1610:	ld1.s	{ v1 }[2], [x23]
    1614:	ld1.s	{ v1 }[3], [x22]
    1618:	fmov	x19, d31
    161c:	ldr	s26, [x20]
    1620:	ld1.s	{ v26 }[1], [x15]
    1624:	ld1.s	{ v26 }[2], [x19]
    1628:	ld1.s	{ v26 }[3], [x7]
    162c:	stp	q26, q1, [x9, #0x40]
    1630:	fmul.4s	v25, v1, v1
    1634:	fmul.4s	v26, v26, v26
    1638:	mov.d	x15, v28[1]
    163c:	fmov	x7, d28
    1640:	mov.d	x19, v29[1]
    1644:	fmov	x20, d29
    1648:	mov.d	x21, v30[1]
    164c:	fmov	x22, d30
    1650:	mov.d	x23, v27[1]
    1654:	ldr	s1, [x7]
    1658:	ld1.s	{ v1 }[1], [x15]
    165c:	ld1.s	{ v1 }[2], [x20]
    1660:	ld1.s	{ v1 }[3], [x19]
    1664:	fmov	x15, d27
    1668:	ldr	s27, [x22]
    166c:	ld1.s	{ v27 }[1], [x21]
    1670:	ld1.s	{ v27 }[2], [x15]
    1674:	ld1.s	{ v27 }[3], [x23]
    1678:	stp	q1, q27, [x9, #0x60]
    167c:	fmul.4s	v28, v27, v27
    1680:	fmul.4s	v27, v1, v1
    1684:	add	x20, x9, x14, lsl #5
    1688:	add	x15, x14, #0x5
    168c:	add	x7, x14, #0x6
    1690:	add	x19, x14, #0x7
    1694:	add	x14, x14, #0x4
    1698:	dup.2d	v1, x14
    169c:	add.2d	v29, v1, v17
    16a0:	add.2d	v30, v1, v19
    16a4:	add.2d	v31, v1, v20
    16a8:	add.2d	v1, v1, v18
    16ac:	shl.2d	v31, v31, #0x2
    16b0:	shl.2d	v1, v1, #0x2
    16b4:	shl.2d	v30, v30, #0x2
    16b8:	shl.2d	v29, v29, #0x2
    16bc:	add.2d	v29, v7, v29
    16c0:	add.2d	v30, v7, v30
    16c4:	add.2d	v1, v7, v1
    16c8:	add.2d	v31, v7, v31
    16cc:	mov.d	x21, v31[1]
    16d0:	mov.d	x22, v1[1]
    16d4:	fmov	x23, d31
    16d8:	fmov	x26, d1
    16dc:	mov.d	x27, v30[1]
    16e0:	fmov	x28, d30
    16e4:	ldr	s1, [x23]
    16e8:	mov.d	x23, v29[1]
    16ec:	ld1.s	{ v1 }[1], [x21]
    16f0:	ld1.s	{ v1 }[2], [x26]
    16f4:	fmov	x21, d29
    16f8:	ldr	s29, [x28]
    16fc:	ld1.s	{ v29 }[1], [x27]
    1700:	ld1.s	{ v1 }[3], [x22]
    1704:	ld1.s	{ v29 }[2], [x21]
    1708:	dup.2d	v30, x15
    170c:	ld1.s	{ v29 }[3], [x23]
    1710:	add.2d	v31, v30, v17
    1714:	add.2d	v8, v30, v20
    1718:	shl.2d	v8, v8, #0x2
    171c:	add.2d	v8, v7, v8
    1720:	stp	q1, q29, [x20, #0x80]
    1724:	mov.d	x15, v8[1]
    1728:	fmov	x21, d8
    172c:	add.2d	v8, v30, v19
    1730:	add.2d	v30, v30, v18
    1734:	fmul.4s	v1, v1, v1
    1738:	shl.2d	v30, v30, #0x2
    173c:	shl.2d	v8, v8, #0x2
    1740:	shl.2d	v31, v31, #0x2
    1744:	add.2d	v31, v7, v31
    1748:	add.2d	v8, v7, v8
    174c:	fmul.4s	v29, v29, v29
    1750:	add.2d	v30, v7, v30
    1754:	mov.d	x22, v30[1]
    1758:	mov.d	x23, v8[1]
    175c:	fadd.4s	v22, v22, v29
    1760:	fmov	x26, d30
    1764:	fmov	x27, d8
    1768:	mov.d	x28, v31[1]
    176c:	ldr	s29, [x21]
    1770:	fadd.4s	v21, v21, v1
    1774:	fmov	x21, d31
    1778:	ld1.s	{ v29 }[1], [x15]
    177c:	ldr	s1, [x27]
    1780:	ld1.s	{ v29 }[2], [x26]
    1784:	ld1.s	{ v1 }[1], [x23]
    1788:	ld1.s	{ v1 }[2], [x21]
    178c:	ld1.s	{ v29 }[3], [x22]
    1790:	dup.2d	v30, x7
    1794:	add.2d	v31, v30, v17
    1798:	add.2d	v8, v30, v20
    179c:	ld1.s	{ v1 }[3], [x28]
    17a0:	shl.2d	v8, v8, #0x2
    17a4:	add.2d	v8, v7, v8
    17a8:	mov.d	x15, v8[1]
    17ac:	stp	q29, q1, [x20, #0xa0]
    17b0:	fmov	x7, d8
    17b4:	add.2d	v8, v30, v19
    17b8:	add.2d	v30, v30, v18
    17bc:	shl.2d	v30, v30, #0x2
    17c0:	shl.2d	v8, v8, #0x2
    17c4:	fmul.4s	v29, v29, v29
    17c8:	shl.2d	v31, v31, #0x2
    17cc:	add.2d	v31, v7, v31
    17d0:	add.2d	v30, v7, v30
    17d4:	mov.d	x21, v30[1]
    17d8:	fmul.4s	v1, v1, v1
    17dc:	add.2d	v8, v7, v8
    17e0:	fmov	x22, d30
    17e4:	mov.d	x23, v8[1]
    17e8:	fmov	x26, d8
    17ec:	fadd.4s	v24, v24, v1
    17f0:	mov.d	x27, v31[1]
    17f4:	ldr	s1, [x26]
    17f8:	ld1.s	{ v1 }[1], [x23]
    17fc:	fadd.4s	v23, v23, v29
    1800:	fmov	x23, d31
    1804:	ld1.s	{ v1 }[2], [x23]
    1808:	ldr	s29, [x7]
    180c:	ld1.s	{ v1 }[3], [x27]
    1810:	ld1.s	{ v29 }[1], [x15]
    1814:	ld1.s	{ v29 }[2], [x22]
    1818:	ld1.s	{ v29 }[3], [x21]
    181c:	dup.2d	v30, x19
    1820:	add.2d	v31, v30, v17
    1824:	add.2d	v8, v30, v20
    1828:	stp	q29, q1, [x20, #0xc0]
    182c:	shl.2d	v8, v8, #0x2
    1830:	add.2d	v8, v7, v8
    1834:	mov.d	x15, v8[1]
    1838:	fmov	x7, d8
    183c:	fmul.4s	v29, v29, v29
    1840:	add.2d	v8, v30, v19
    1844:	add.2d	v30, v30, v18
    1848:	shl.2d	v30, v30, #0x2
    184c:	shl.2d	v8, v8, #0x2
    1850:	shl.2d	v31, v31, #0x2
    1854:	fmul.4s	v1, v1, v1
    1858:	add.2d	v31, v7, v31
    185c:	add.2d	v8, v7, v8
    1860:	add.2d	v30, v7, v30
    1864:	mov.d	x19, v30[1]
    1868:	fadd.4s	v25, v25, v1
    186c:	fmov	x21, d30
    1870:	mov.d	x22, v8[1]
    1874:	mov.d	x23, v31[1]
    1878:	fadd.4s	v26, v26, v29
    187c:	fmov	x26, d8
    1880:	ldr	s1, [x7]
    1884:	ld1.s	{ v1 }[1], [x15]
    1888:	ld1.s	{ v1 }[2], [x21]
    188c:	fmov	x15, d31
    1890:	ldr	s29, [x26]
    1894:	ld1.s	{ v29 }[1], [x22]
    1898:	ld1.s	{ v1 }[3], [x19]
    189c:	ld1.s	{ v29 }[2], [x15]
    18a0:	ld1.s	{ v29 }[3], [x23]
    18a4:	stp	q1, q29, [x20, #0xe0]
    18a8:	fmul.4s	v1, v1, v1
    18ac:	fmul.4s	v29, v29, v29
    18b0:	fadd.4s	v28, v28, v29
    18b4:	fadd.4s	v27, v27, v1
    18b8:	cmp	x14, #0xfc
    18bc:	b.lo	0x1684
    18c0:	mov	x14, #0x0
    18c4:	add	x15, x24, x14, lsl #2
    18c8:	ld1r.4s	{ v1 }, [x15]
    18cc:	add	x15, x6, x14, lsl #5
    18d0:	stp	q1, q1, [x15]
    18d4:	add	x14, x14, #0x1
    18d8:	cmp	x14, #0x100
    18dc:	b.ne	0x18c4
    18e0:	mov	x14, #0x0
    18e4:	fadd.4s	v1, v22, v24
    18e8:	fadd.4s	v21, v21, v23
    18ec:	fadd.4s	v21, v21, v26
    18f0:	fadd.4s	v1, v1, v25
    18f4:	fadd.4s	v1, v1, v28
    18f8:	fadd.4s	v21, v21, v27
    18fc:	fmul.4s	v21, v21, v6
    1900:	fmul.4s	v1, v1, v6
    1904:	fadd.4s	v1, v1, v5
    1908:	fadd.4s	v21, v21, v5
    190c:	fsqrt.4s	v21, v21
    1910:	fsqrt.4s	v22, v1
    1914:	dup.2d	v1, x14
    1918:	add.2d	v23, v1, v17
    191c:	add.2d	v24, v1, v19
    1920:	add.2d	v25, v1, v18
    1924:	add.2d	v1, v1, v20
    1928:	lsl	x15, x14, #5
    192c:	add	x7, x9, x15
    1930:	ldp	q27, q26, [x7]
    1934:	fdiv.4s	v27, v27, v21
    1938:	fdiv.4s	v26, v26, v22
    193c:	add	x15, x6, x15
    1940:	ldp	q28, q29, [x15]
    1944:	fmul.4s	v26, v26, v29
    1948:	fmul.4s	v27, v27, v28
    194c:	shl.2d	v1, v1, #0x2
    1950:	shl.2d	v25, v25, #0x2
    1954:	shl.2d	v24, v24, #0x2
    1958:	shl.2d	v23, v23, #0x2
    195c:	add.2d	v23, v16, v23
    1960:	add.2d	v1, v16, v1
    1964:	mov.d	x15, v1[1]
    1968:	fmov	x7, d1
    196c:	str	s27, [x7]
    1970:	st1.s	{ v27 }[1], [x15]
    1974:	add.2d	v1, v16, v25
    1978:	mov.d	x15, v1[1]
    197c:	fmov	x7, d1
    1980:	st1.s	{ v27 }[2], [x7]
    1984:	add.2d	v1, v16, v24
    1988:	st1.s	{ v27 }[3], [x15]
    198c:	mov.d	x15, v1[1]
    1990:	fmov	x7, d1
    1994:	str	s26, [x7]
    1998:	st1.s	{ v26 }[1], [x15]
    199c:	mov.d	x15, v23[1]
    19a0:	fmov	x7, d23
    19a4:	st1.s	{ v26 }[2], [x7]
    19a8:	st1.s	{ v26 }[3], [x15]
    19ac:	add	x14, x14, #0x1
    19b0:	cmp	x14, #0x100
    19b4:	b.ne	0x1914
    19b8:	mov	x14, #0x0
    19bc:	mov	w10, #0x28
    19c0:	str	w10, [x2, #0x24]
    19c4:	orr	w15, w25, w10
    19c8:	dup.4s	v1, w15
    19cc:	orr.16b	v19, v1, v0
    19d0:	orr.16b	v20, v1, v3
    19d4:	dup.2d	v17, x16
    19d8:	ushll.2d	v1, v20, #0xa
    19dc:	ushll2.2d	v22, v20, #0xa
    19e0:	ushll.2d	v21, v19, #0xa
    19e4:	ushll2.2d	v18, v19, #0xa
    19e8:	add.2d	v18, v7, v18
    19ec:	add.2d	v21, v7, v21
    19f0:	add.2d	v22, v7, v22
    19f4:	add.2d	v23, v7, v1
    19f8:	mov.d	x15, v23[1]
    19fc:	dup.2d	v26, x4
    1a00:	add.2d	v24, v23, v26
    1a04:	add.2d	v25, v23, v17
    1a08:	dup.2d	v1, x5
    1a0c:	add.2d	v28, v23, v1
    1a10:	fmov	x7, d23
    1a14:	mov.d	x19, v22[1]
    1a18:	add.2d	v23, v22, v26
    1a1c:	add.2d	v31, v22, v17
    1a20:	add.2d	v29, v22, v1
    1a24:	fmov	x20, d22
    1a28:	mov.d	x21, v21[1]
    1a2c:	add.2d	v8, v21, v26
    1a30:	add.2d	v9, v21, v17
    1a34:	add.2d	v30, v21, v1
    1a38:	fmov	x22, d21
    1a3c:	mov.d	x23, v18[1]
    1a40:	ldr	s21, [x7]
    1a44:	add.2d	v26, v18, v26
    1a48:	add.2d	v10, v18, v17
    1a4c:	add.2d	v27, v18, v1
    1a50:	fmov	x7, d18
    1a54:	ushll2.2d	v17, v19, #0x8
    1a58:	ld1.s	{ v21 }[1], [x15]
    1a5c:	ld1.s	{ v21 }[2], [x20]
    1a60:	ld1.s	{ v21 }[3], [x19]
    1a64:	mov.d	x15, v24[1]
    1a68:	fmov	x19, d24
    1a6c:	ldr	s1, [x22]
    1a70:	mov.d	x20, v23[1]
    1a74:	fmov	x22, d23
    1a78:	ushll2.2d	v18, v20, #0x8
    1a7c:	ushll.2d	v19, v19, #0x8
    1a80:	ushll.2d	v20, v20, #0x8
    1a84:	ld1.s	{ v1 }[1], [x21]
    1a88:	ld1.s	{ v1 }[2], [x7]
    1a8c:	ld1.s	{ v1 }[3], [x23]
    1a90:	stp	q21, q1, [x9]
    1a94:	fmul.4s	v22, v1, v1
    1a98:	fmul.4s	v21, v21, v21
    1a9c:	mov.d	x7, v8[1]
    1aa0:	fmov	x21, d8
    1aa4:	mov.d	x23, v26[1]
    1aa8:	ldr	s1, [x19]
    1aac:	ld1.s	{ v1 }[1], [x15]
    1ab0:	ld1.s	{ v1 }[2], [x22]
    1ab4:	ld1.s	{ v1 }[3], [x20]
    1ab8:	fmov	x15, d26
    1abc:	ldr	s23, [x21]
    1ac0:	ld1.s	{ v23 }[1], [x7]
    1ac4:	ld1.s	{ v23 }[2], [x15]
    1ac8:	ld1.s	{ v23 }[3], [x23]
    1acc:	stp	q1, q23, [x9, #0x20]
    1ad0:	fmul.4s	v24, v23, v23
    1ad4:	fmul.4s	v23, v1, v1
    1ad8:	mov.d	x15, v25[1]
    1adc:	mov.d	x7, v31[1]
    1ae0:	mov.d	x19, v9[1]
    1ae4:	fmov	x20, d25
    1ae8:	fmov	x21, d9
    1aec:	mov.d	x22, v10[1]
    1af0:	fmov	x23, d10
    1af4:	ldr	s1, [x21]
    1af8:	ld1.s	{ v1 }[1], [x19]
    1afc:	ld1.s	{ v1 }[2], [x23]
    1b00:	ld1.s	{ v1 }[3], [x22]
    1b04:	fmov	x19, d31
    1b08:	ldr	s26, [x20]
    1b0c:	ld1.s	{ v26 }[1], [x15]
    1b10:	ld1.s	{ v26 }[2], [x19]
    1b14:	ld1.s	{ v26 }[3], [x7]
    1b18:	stp	q26, q1, [x9, #0x40]
    1b1c:	fmul.4s	v25, v1, v1
    1b20:	fmul.4s	v26, v26, v26
    1b24:	mov.d	x15, v28[1]
    1b28:	fmov	x7, d28
    1b2c:	mov.d	x19, v29[1]
    1b30:	fmov	x20, d29
    1b34:	mov.d	x21, v30[1]
    1b38:	fmov	x22, d30
    1b3c:	mov.d	x23, v27[1]
    1b40:	ldr	s1, [x7]
    1b44:	ld1.s	{ v1 }[1], [x15]
    1b48:	ld1.s	{ v1 }[2], [x20]
    1b4c:	ld1.s	{ v1 }[3], [x19]
    1b50:	fmov	x15, d27
    1b54:	ldr	s27, [x22]
    1b58:	ld1.s	{ v27 }[1], [x21]
    1b5c:	ld1.s	{ v27 }[2], [x15]
    1b60:	ld1.s	{ v27 }[3], [x23]
    1b64:	stp	q1, q27, [x9, #0x60]
    1b68:	fmul.4s	v28, v27, v27
    1b6c:	fmul.4s	v27, v1, v1
    1b70:	add	x20, x9, x14, lsl #5
    1b74:	add	x15, x14, #0x5
    1b78:	add	x7, x14, #0x6
    1b7c:	add	x19, x14, #0x7
    1b80:	add	x14, x14, #0x4
    1b84:	dup.2d	v1, x14
    1b88:	add.2d	v29, v1, v17
    1b8c:	add.2d	v30, v1, v19
    1b90:	add.2d	v31, v1, v20
    1b94:	add.2d	v1, v1, v18
    1b98:	shl.2d	v31, v31, #0x2
    1b9c:	shl.2d	v1, v1, #0x2
    1ba0:	shl.2d	v30, v30, #0x2
    1ba4:	shl.2d	v29, v29, #0x2
    1ba8:	add.2d	v29, v7, v29
    1bac:	add.2d	v30, v7, v30
    1bb0:	add.2d	v1, v7, v1
    1bb4:	add.2d	v31, v7, v31
    1bb8:	mov.d	x21, v31[1]
    1bbc:	mov.d	x22, v1[1]
    1bc0:	fmov	x23, d31
    1bc4:	fmov	x26, d1
    1bc8:	mov.d	x27, v30[1]
    1bcc:	fmov	x28, d30
    1bd0:	ldr	s1, [x23]
    1bd4:	mov.d	x23, v29[1]
    1bd8:	ld1.s	{ v1 }[1], [x21]
    1bdc:	ld1.s	{ v1 }[2], [x26]
    1be0:	fmov	x21, d29
    1be4:	ldr	s29, [x28]
    1be8:	ld1.s	{ v29 }[1], [x27]
    1bec:	ld1.s	{ v1 }[3], [x22]
    1bf0:	ld1.s	{ v29 }[2], [x21]
    1bf4:	dup.2d	v30, x15
    1bf8:	ld1.s	{ v29 }[3], [x23]
    1bfc:	add.2d	v31, v30, v17
    1c00:	add.2d	v8, v30, v20
    1c04:	shl.2d	v8, v8, #0x2
    1c08:	add.2d	v8, v7, v8
    1c0c:	stp	q1, q29, [x20, #0x80]
    1c10:	mov.d	x15, v8[1]
    1c14:	fmov	x21, d8
    1c18:	add.2d	v8, v30, v19
    1c1c:	add.2d	v30, v30, v18
    1c20:	fmul.4s	v1, v1, v1
    1c24:	shl.2d	v30, v30, #0x2
    1c28:	shl.2d	v8, v8, #0x2
    1c2c:	shl.2d	v31, v31, #0x2
    1c30:	add.2d	v31, v7, v31
    1c34:	add.2d	v8, v7, v8
    1c38:	fmul.4s	v29, v29, v29
    1c3c:	add.2d	v30, v7, v30
    1c40:	mov.d	x22, v30[1]
    1c44:	mov.d	x23, v8[1]
    1c48:	fadd.4s	v22, v22, v29
    1c4c:	fmov	x26, d30
    1c50:	fmov	x27, d8
    1c54:	mov.d	x28, v31[1]
    1c58:	ldr	s29, [x21]
    1c5c:	fadd.4s	v21, v21, v1
    1c60:	fmov	x21, d31
    1c64:	ld1.s	{ v29 }[1], [x15]
    1c68:	ldr	s1, [x27]
    1c6c:	ld1.s	{ v29 }[2], [x26]
    1c70:	ld1.s	{ v1 }[1], [x23]
    1c74:	ld1.s	{ v1 }[2], [x21]
    1c78:	ld1.s	{ v29 }[3], [x22]
    1c7c:	dup.2d	v30, x7
    1c80:	add.2d	v31, v30, v17
    1c84:	add.2d	v8, v30, v20
    1c88:	ld1.s	{ v1 }[3], [x28]
    1c8c:	shl.2d	v8, v8, #0x2
    1c90:	add.2d	v8, v7, v8
    1c94:	mov.d	x15, v8[1]
    1c98:	stp	q29, q1, [x20, #0xa0]
    1c9c:	fmov	x7, d8
    1ca0:	add.2d	v8, v30, v19
    1ca4:	add.2d	v30, v30, v18
    1ca8:	shl.2d	v30, v30, #0x2
    1cac:	shl.2d	v8, v8, #0x2
    1cb0:	fmul.4s	v29, v29, v29
    1cb4:	shl.2d	v31, v31, #0x2
    1cb8:	add.2d	v31, v7, v31
    1cbc:	add.2d	v30, v7, v30
    1cc0:	mov.d	x21, v30[1]
    1cc4:	fmul.4s	v1, v1, v1
    1cc8:	add.2d	v8, v7, v8
    1ccc:	fmov	x22, d30
    1cd0:	mov.d	x23, v8[1]
    1cd4:	fmov	x26, d8
    1cd8:	fadd.4s	v24, v24, v1
    1cdc:	mov.d	x27, v31[1]
    1ce0:	ldr	s1, [x26]
    1ce4:	ld1.s	{ v1 }[1], [x23]
    1ce8:	fadd.4s	v23, v23, v29
    1cec:	fmov	x23, d31
    1cf0:	ld1.s	{ v1 }[2], [x23]
    1cf4:	ldr	s29, [x7]
    1cf8:	ld1.s	{ v1 }[3], [x27]
    1cfc:	ld1.s	{ v29 }[1], [x15]
    1d00:	ld1.s	{ v29 }[2], [x22]
    1d04:	ld1.s	{ v29 }[3], [x21]
    1d08:	dup.2d	v30, x19
    1d0c:	add.2d	v31, v30, v17
    1d10:	add.2d	v8, v30, v20
    1d14:	stp	q29, q1, [x20, #0xc0]
    1d18:	shl.2d	v8, v8, #0x2
    1d1c:	add.2d	v8, v7, v8
    1d20:	mov.d	x15, v8[1]
    1d24:	fmov	x7, d8
    1d28:	fmul.4s	v29, v29, v29
    1d2c:	add.2d	v8, v30, v19
    1d30:	add.2d	v30, v30, v18
    1d34:	shl.2d	v30, v30, #0x2
    1d38:	shl.2d	v8, v8, #0x2
    1d3c:	shl.2d	v31, v31, #0x2
    1d40:	fmul.4s	v1, v1, v1
    1d44:	add.2d	v31, v7, v31
    1d48:	add.2d	v8, v7, v8
    1d4c:	add.2d	v30, v7, v30
    1d50:	mov.d	x19, v30[1]
    1d54:	fadd.4s	v25, v25, v1
    1d58:	fmov	x21, d30
    1d5c:	mov.d	x22, v8[1]
    1d60:	mov.d	x23, v31[1]
    1d64:	fadd.4s	v26, v26, v29
    1d68:	fmov	x26, d8
    1d6c:	ldr	s1, [x7]
    1d70:	ld1.s	{ v1 }[1], [x15]
    1d74:	ld1.s	{ v1 }[2], [x21]
    1d78:	fmov	x15, d31
    1d7c:	ldr	s29, [x26]
    1d80:	ld1.s	{ v29 }[1], [x22]
    1d84:	ld1.s	{ v1 }[3], [x19]
    1d88:	ld1.s	{ v29 }[2], [x15]
    1d8c:	ld1.s	{ v29 }[3], [x23]
    1d90:	stp	q1, q29, [x20, #0xe0]
    1d94:	fmul.4s	v1, v1, v1
    1d98:	fmul.4s	v29, v29, v29
    1d9c:	fadd.4s	v28, v28, v29
    1da0:	fadd.4s	v27, v27, v1
    1da4:	cmp	x14, #0xfc
    1da8:	b.lo	0x1b70
    1dac:	mov	x14, #0x0
    1db0:	add	x15, x24, x14, lsl #2
    1db4:	ld1r.4s	{ v1 }, [x15]
    1db8:	add	x15, x6, x14, lsl #5
    1dbc:	stp	q1, q1, [x15]
    1dc0:	add	x14, x14, #0x1
    1dc4:	cmp	x14, #0x100
    1dc8:	b.ne	0x1db0
    1dcc:	mov	x14, #0x0
    1dd0:	fadd.4s	v1, v22, v24
    1dd4:	fadd.4s	v21, v21, v23
    1dd8:	fadd.4s	v21, v21, v26
    1ddc:	fadd.4s	v1, v1, v25
    1de0:	fadd.4s	v1, v1, v28
    1de4:	fadd.4s	v21, v21, v27
    1de8:	fmul.4s	v21, v21, v6
    1dec:	fmul.4s	v1, v1, v6
    1df0:	fadd.4s	v1, v1, v5
    1df4:	fadd.4s	v21, v21, v5
    1df8:	fsqrt.4s	v21, v21
    1dfc:	fsqrt.4s	v22, v1
    1e00:	dup.2d	v1, x14
    1e04:	add.2d	v23, v1, v17
    1e08:	add.2d	v24, v1, v19
    1e0c:	add.2d	v25, v1, v18
    1e10:	add.2d	v1, v1, v20
    1e14:	lsl	x15, x14, #5
    1e18:	add	x7, x9, x15
    1e1c:	ldp	q27, q26, [x7]
    1e20:	fdiv.4s	v27, v27, v21
    1e24:	fdiv.4s	v26, v26, v22
    1e28:	add	x15, x6, x15
    1e2c:	ldp	q28, q29, [x15]
    1e30:	fmul.4s	v26, v26, v29
    1e34:	fmul.4s	v27, v27, v28
    1e38:	shl.2d	v1, v1, #0x2
    1e3c:	shl.2d	v25, v25, #0x2
    1e40:	shl.2d	v24, v24, #0x2
    1e44:	shl.2d	v23, v23, #0x2
    1e48:	add.2d	v23, v16, v23
    1e4c:	add.2d	v1, v16, v1
    1e50:	mov.d	x15, v1[1]
    1e54:	fmov	x7, d1
    1e58:	str	s27, [x7]
    1e5c:	st1.s	{ v27 }[1], [x15]
    1e60:	add.2d	v1, v16, v25
    1e64:	mov.d	x15, v1[1]
    1e68:	fmov	x7, d1
    1e6c:	st1.s	{ v27 }[2], [x7]
    1e70:	add.2d	v1, v16, v24
    1e74:	st1.s	{ v27 }[3], [x15]
    1e78:	mov.d	x15, v1[1]
    1e7c:	fmov	x7, d1
    1e80:	str	s26, [x7]
    1e84:	st1.s	{ v26 }[1], [x15]
    1e88:	mov.d	x15, v23[1]
    1e8c:	fmov	x7, d23
    1e90:	st1.s	{ v26 }[2], [x7]
    1e94:	st1.s	{ v26 }[3], [x15]
    1e98:	add	x14, x14, #0x1
    1e9c:	cmp	x14, #0x100
    1ea0:	b.ne	0x1e00
    1ea4:	mov	x14, #0x0
    1ea8:	orr	w15, w25, #0x30
    1eac:	dup.4s	v1, w15
    1eb0:	orr.16b	v19, v1, v0
    1eb4:	orr.16b	v20, v1, v3
    1eb8:	dup.2d	v17, x16
    1ebc:	ushll.2d	v1, v20, #0xa
    1ec0:	ushll2.2d	v22, v20, #0xa
    1ec4:	ushll.2d	v21, v19, #0xa
    1ec8:	ushll2.2d	v18, v19, #0xa
    1ecc:	add.2d	v18, v7, v18
    1ed0:	add.2d	v21, v7, v21
    1ed4:	add.2d	v22, v7, v22
    1ed8:	add.2d	v23, v7, v1
    1edc:	mov.d	x15, v23[1]
    1ee0:	dup.2d	v26, x4
    1ee4:	add.2d	v24, v23, v26
    1ee8:	add.2d	v25, v23, v17
    1eec:	dup.2d	v1, x5
    1ef0:	add.2d	v28, v23, v1
    1ef4:	fmov	x7, d23
    1ef8:	mov.d	x19, v22[1]
    1efc:	add.2d	v23, v22, v26
    1f00:	add.2d	v31, v22, v17
    1f04:	add.2d	v29, v22, v1
    1f08:	fmov	x20, d22
    1f0c:	mov.d	x21, v21[1]
    1f10:	add.2d	v8, v21, v26
    1f14:	add.2d	v9, v21, v17
    1f18:	add.2d	v30, v21, v1
    1f1c:	fmov	x22, d21
    1f20:	mov.d	x23, v18[1]
    1f24:	ldr	s21, [x7]
    1f28:	add.2d	v26, v18, v26
    1f2c:	add.2d	v10, v18, v17
    1f30:	add.2d	v27, v18, v1
    1f34:	fmov	x7, d18
    1f38:	ushll2.2d	v17, v19, #0x8
    1f3c:	ld1.s	{ v21 }[1], [x15]
    1f40:	ld1.s	{ v21 }[2], [x20]
    1f44:	ld1.s	{ v21 }[3], [x19]
    1f48:	mov.d	x15, v24[1]
    1f4c:	fmov	x19, d24
    1f50:	ldr	s1, [x22]
    1f54:	mov.d	x20, v23[1]
    1f58:	fmov	x22, d23
    1f5c:	ushll2.2d	v18, v20, #0x8
    1f60:	ushll.2d	v19, v19, #0x8
    1f64:	ushll.2d	v20, v20, #0x8
    1f68:	ld1.s	{ v1 }[1], [x21]
    1f6c:	ld1.s	{ v1 }[2], [x7]
    1f70:	ld1.s	{ v1 }[3], [x23]
    1f74:	stp	q21, q1, [x9]
    1f78:	fmul.4s	v22, v1, v1
    1f7c:	fmul.4s	v21, v21, v21
    1f80:	mov.d	x7, v8[1]
    1f84:	fmov	x21, d8
    1f88:	mov.d	x23, v26[1]
    1f8c:	ldr	s1, [x19]
    1f90:	ld1.s	{ v1 }[1], [x15]
    1f94:	ld1.s	{ v1 }[2], [x22]
    1f98:	ld1.s	{ v1 }[3], [x20]
    1f9c:	fmov	x15, d26
    1fa0:	ldr	s23, [x21]
    1fa4:	ld1.s	{ v23 }[1], [x7]
    1fa8:	ld1.s	{ v23 }[2], [x15]
    1fac:	ld1.s	{ v23 }[3], [x23]
    1fb0:	stp	q1, q23, [x9, #0x20]
    1fb4:	fmul.4s	v24, v23, v23
    1fb8:	fmul.4s	v23, v1, v1
    1fbc:	mov.d	x15, v25[1]
    1fc0:	mov.d	x7, v31[1]
    1fc4:	mov.d	x19, v9[1]
    1fc8:	fmov	x20, d25
    1fcc:	fmov	x21, d9
    1fd0:	mov.d	x22, v10[1]
    1fd4:	fmov	x23, d10
    1fd8:	ldr	s1, [x21]
    1fdc:	ld1.s	{ v1 }[1], [x19]
    1fe0:	ld1.s	{ v1 }[2], [x23]
    1fe4:	ld1.s	{ v1 }[3], [x22]
    1fe8:	fmov	x19, d31
    1fec:	ldr	s26, [x20]
    1ff0:	ld1.s	{ v26 }[1], [x15]
    1ff4:	ld1.s	{ v26 }[2], [x19]
    1ff8:	ld1.s	{ v26 }[3], [x7]
    1ffc:	stp	q26, q1, [x9, #0x40]
    2000:	fmul.4s	v25, v1, v1
    2004:	fmul.4s	v26, v26, v26
    2008:	mov.d	x15, v28[1]
    200c:	fmov	x7, d28
    2010:	mov.d	x19, v29[1]
    2014:	fmov	x20, d29
    2018:	mov.d	x21, v30[1]
    201c:	fmov	x22, d30
    2020:	mov.d	x23, v27[1]
    2024:	ldr	s1, [x7]
    2028:	ld1.s	{ v1 }[1], [x15]
    202c:	ld1.s	{ v1 }[2], [x20]
    2030:	ld1.s	{ v1 }[3], [x19]
    2034:	fmov	x15, d27
    2038:	ldr	s27, [x22]
    203c:	ld1.s	{ v27 }[1], [x21]
    2040:	ld1.s	{ v27 }[2], [x15]
    2044:	ld1.s	{ v27 }[3], [x23]
    2048:	stp	q1, q27, [x9, #0x60]
    204c:	fmul.4s	v28, v27, v27
    2050:	fmul.4s	v27, v1, v1
    2054:	add	x20, x9, x14, lsl #5
    2058:	add	x15, x14, #0x5
    205c:	add	x7, x14, #0x6
    2060:	add	x19, x14, #0x7
    2064:	add	x14, x14, #0x4
    2068:	dup.2d	v1, x14
    206c:	add.2d	v29, v1, v17
    2070:	add.2d	v30, v1, v19
    2074:	add.2d	v31, v1, v20
    2078:	add.2d	v1, v1, v18
    207c:	shl.2d	v31, v31, #0x2
    2080:	shl.2d	v1, v1, #0x2
    2084:	shl.2d	v30, v30, #0x2
    2088:	shl.2d	v29, v29, #0x2
    208c:	add.2d	v29, v7, v29
    2090:	add.2d	v30, v7, v30
    2094:	add.2d	v1, v7, v1
    2098:	add.2d	v31, v7, v31
    209c:	mov.d	x21, v31[1]
    20a0:	mov.d	x22, v1[1]
    20a4:	fmov	x23, d31
    20a8:	fmov	x26, d1
    20ac:	mov.d	x27, v30[1]
    20b0:	fmov	x28, d30
    20b4:	ldr	s1, [x23]
    20b8:	mov.d	x23, v29[1]
    20bc:	ld1.s	{ v1 }[1], [x21]
    20c0:	ld1.s	{ v1 }[2], [x26]
    20c4:	fmov	x21, d29
    20c8:	ldr	s29, [x28]
    20cc:	ld1.s	{ v29 }[1], [x27]
    20d0:	ld1.s	{ v1 }[3], [x22]
    20d4:	ld1.s	{ v29 }[2], [x21]
    20d8:	dup.2d	v30, x15
    20dc:	ld1.s	{ v29 }[3], [x23]
    20e0:	add.2d	v31, v30, v17
    20e4:	add.2d	v8, v30, v20
    20e8:	shl.2d	v8, v8, #0x2
    20ec:	add.2d	v8, v7, v8
    20f0:	stp	q1, q29, [x20, #0x80]
    20f4:	mov.d	x15, v8[1]
    20f8:	fmov	x21, d8
    20fc:	add.2d	v8, v30, v19
    2100:	add.2d	v30, v30, v18
    2104:	fmul.4s	v1, v1, v1
    2108:	shl.2d	v30, v30, #0x2
    210c:	shl.2d	v8, v8, #0x2
    2110:	shl.2d	v31, v31, #0x2
    2114:	add.2d	v31, v7, v31
    2118:	add.2d	v8, v7, v8
    211c:	fmul.4s	v29, v29, v29
    2120:	add.2d	v30, v7, v30
    2124:	mov.d	x22, v30[1]
    2128:	mov.d	x23, v8[1]
    212c:	fadd.4s	v22, v22, v29
    2130:	fmov	x26, d30
    2134:	fmov	x27, d8
    2138:	mov.d	x28, v31[1]
    213c:	ldr	s29, [x21]
    2140:	fadd.4s	v21, v21, v1
    2144:	fmov	x21, d31
    2148:	ld1.s	{ v29 }[1], [x15]
    214c:	ldr	s1, [x27]
    2150:	ld1.s	{ v29 }[2], [x26]
    2154:	ld1.s	{ v1 }[1], [x23]
    2158:	ld1.s	{ v1 }[2], [x21]
    215c:	ld1.s	{ v29 }[3], [x22]
    2160:	dup.2d	v30, x7
    2164:	add.2d	v31, v30, v17
    2168:	add.2d	v8, v30, v20
    216c:	ld1.s	{ v1 }[3], [x28]
    2170:	shl.2d	v8, v8, #0x2
    2174:	add.2d	v8, v7, v8
    2178:	mov.d	x15, v8[1]
    217c:	stp	q29, q1, [x20, #0xa0]
    2180:	fmov	x7, d8
    2184:	add.2d	v8, v30, v19
    2188:	add.2d	v30, v30, v18
    218c:	shl.2d	v30, v30, #0x2
    2190:	shl.2d	v8, v8, #0x2
    2194:	fmul.4s	v29, v29, v29
    2198:	shl.2d	v31, v31, #0x2
    219c:	add.2d	v31, v7, v31
    21a0:	add.2d	v30, v7, v30
    21a4:	mov.d	x21, v30[1]
    21a8:	fmul.4s	v1, v1, v1
    21ac:	add.2d	v8, v7, v8
    21b0:	fmov	x22, d30
    21b4:	mov.d	x23, v8[1]
    21b8:	fmov	x26, d8
    21bc:	fadd.4s	v24, v24, v1
    21c0:	mov.d	x27, v31[1]
    21c4:	ldr	s1, [x26]
    21c8:	ld1.s	{ v1 }[1], [x23]
    21cc:	fadd.4s	v23, v23, v29
    21d0:	fmov	x23, d31
    21d4:	ld1.s	{ v1 }[2], [x23]
    21d8:	ldr	s29, [x7]
    21dc:	ld1.s	{ v1 }[3], [x27]
    21e0:	ld1.s	{ v29 }[1], [x15]
    21e4:	ld1.s	{ v29 }[2], [x22]
    21e8:	ld1.s	{ v29 }[3], [x21]
    21ec:	dup.2d	v30, x19
    21f0:	add.2d	v31, v30, v17
    21f4:	add.2d	v8, v30, v20
    21f8:	stp	q29, q1, [x20, #0xc0]
    21fc:	shl.2d	v8, v8, #0x2
    2200:	add.2d	v8, v7, v8
    2204:	mov.d	x15, v8[1]
    2208:	fmov	x7, d8
    220c:	fmul.4s	v29, v29, v29
    2210:	add.2d	v8, v30, v19
    2214:	add.2d	v30, v30, v18
    2218:	shl.2d	v30, v30, #0x2
    221c:	shl.2d	v8, v8, #0x2
    2220:	shl.2d	v31, v31, #0x2
    2224:	fmul.4s	v1, v1, v1
    2228:	add.2d	v31, v7, v31
    222c:	add.2d	v8, v7, v8
    2230:	add.2d	v30, v7, v30
    2234:	mov.d	x19, v30[1]
    2238:	fadd.4s	v25, v25, v1
    223c:	fmov	x21, d30
    2240:	mov.d	x22, v8[1]
    2244:	mov.d	x23, v31[1]
    2248:	fadd.4s	v26, v26, v29
    224c:	fmov	x26, d8
    2250:	ldr	s1, [x7]
    2254:	ld1.s	{ v1 }[1], [x15]
    2258:	ld1.s	{ v1 }[2], [x21]
    225c:	fmov	x15, d31
    2260:	ldr	s29, [x26]
    2264:	ld1.s	{ v29 }[1], [x22]
    2268:	ld1.s	{ v1 }[3], [x19]
    226c:	ld1.s	{ v29 }[2], [x15]
    2270:	ld1.s	{ v29 }[3], [x23]
    2274:	stp	q1, q29, [x20, #0xe0]
    2278:	fmul.4s	v1, v1, v1
    227c:	fmul.4s	v29, v29, v29
    2280:	fadd.4s	v28, v28, v29
    2284:	fadd.4s	v27, v27, v1
    2288:	cmp	x14, #0xfc
    228c:	b.lo	0x2054
    2290:	mov	x14, #0x0
    2294:	add	x15, x24, x14, lsl #2
    2298:	ld1r.4s	{ v1 }, [x15]
    229c:	add	x15, x6, x14, lsl #5
    22a0:	stp	q1, q1, [x15]
    22a4:	add	x14, x14, #0x1
    22a8:	cmp	x14, #0x100
    22ac:	b.ne	0x2294
    22b0:	mov	x14, #0x0
    22b4:	fadd.4s	v1, v22, v24
    22b8:	fadd.4s	v21, v21, v23
    22bc:	fadd.4s	v21, v21, v26
    22c0:	fadd.4s	v1, v1, v25
    22c4:	fadd.4s	v1, v1, v28
    22c8:	fadd.4s	v21, v21, v27
    22cc:	fmul.4s	v21, v21, v6
    22d0:	fmul.4s	v1, v1, v6
    22d4:	fadd.4s	v1, v1, v5
    22d8:	fadd.4s	v21, v21, v5
    22dc:	fsqrt.4s	v21, v21
    22e0:	fsqrt.4s	v22, v1
    22e4:	dup.2d	v1, x14
    22e8:	add.2d	v23, v1, v17
    22ec:	add.2d	v24, v1, v19
    22f0:	add.2d	v25, v1, v18
    22f4:	add.2d	v1, v1, v20
    22f8:	lsl	x15, x14, #5
    22fc:	add	x7, x9, x15
    2300:	ldp	q27, q26, [x7]
    2304:	fdiv.4s	v27, v27, v21
    2308:	fdiv.4s	v26, v26, v22
    230c:	add	x15, x6, x15
    2310:	ldp	q28, q29, [x15]
    2314:	fmul.4s	v26, v26, v29
    2318:	fmul.4s	v27, v27, v28
    231c:	shl.2d	v1, v1, #0x2
    2320:	shl.2d	v25, v25, #0x2
    2324:	shl.2d	v24, v24, #0x2
    2328:	shl.2d	v23, v23, #0x2
    232c:	add.2d	v23, v16, v23
    2330:	add.2d	v1, v16, v1
    2334:	mov.d	x15, v1[1]
    2338:	fmov	x7, d1
    233c:	str	s27, [x7]
    2340:	st1.s	{ v27 }[1], [x15]
    2344:	add.2d	v1, v16, v25
    2348:	mov.d	x15, v1[1]
    234c:	fmov	x7, d1
    2350:	st1.s	{ v27 }[2], [x7]
    2354:	add.2d	v1, v16, v24
    2358:	st1.s	{ v27 }[3], [x15]
    235c:	mov.d	x15, v1[1]
    2360:	fmov	x7, d1
    2364:	str	s26, [x7]
    2368:	st1.s	{ v26 }[1], [x15]
    236c:	mov.d	x15, v23[1]
    2370:	fmov	x7, d23
    2374:	st1.s	{ v26 }[2], [x7]
    2378:	st1.s	{ v26 }[3], [x15]
    237c:	add	x14, x14, #0x1
    2380:	cmp	x14, #0x100
    2384:	b.ne	0x22e4
    2388:	mov	x14, #0x0
    238c:	mov	w10, #0x38
    2390:	str	w10, [x2, #0x24]
    2394:	orr	w15, w25, #0x38
    2398:	dup.4s	v1, w15
    239c:	orr.16b	v19, v1, v0
    23a0:	orr.16b	v20, v1, v3
    23a4:	dup.2d	v17, x16
    23a8:	ushll.2d	v1, v20, #0xa
    23ac:	ushll2.2d	v22, v20, #0xa
    23b0:	ushll.2d	v21, v19, #0xa
    23b4:	ushll2.2d	v18, v19, #0xa
    23b8:	add.2d	v18, v7, v18
    23bc:	add.2d	v21, v7, v21
    23c0:	add.2d	v22, v7, v22
    23c4:	add.2d	v23, v7, v1
    23c8:	mov.d	x15, v23[1]
    23cc:	dup.2d	v26, x4
    23d0:	add.2d	v24, v23, v26
    23d4:	add.2d	v25, v23, v17
    23d8:	dup.2d	v1, x5
    23dc:	add.2d	v28, v23, v1
    23e0:	fmov	x7, d23
    23e4:	mov.d	x19, v22[1]
    23e8:	add.2d	v23, v22, v26
    23ec:	add.2d	v31, v22, v17
    23f0:	add.2d	v29, v22, v1
    23f4:	fmov	x20, d22
    23f8:	mov.d	x21, v21[1]
    23fc:	add.2d	v8, v21, v26
    2400:	add.2d	v9, v21, v17
    2404:	add.2d	v30, v21, v1
    2408:	fmov	x22, d21
    240c:	mov.d	x23, v18[1]
    2410:	ldr	s21, [x7]
    2414:	add.2d	v26, v18, v26
    2418:	add.2d	v10, v18, v17
    241c:	add.2d	v27, v18, v1
    2420:	fmov	x7, d18
    2424:	ushll2.2d	v17, v19, #0x8
    2428:	ld1.s	{ v21 }[1], [x15]
    242c:	ld1.s	{ v21 }[2], [x20]
    2430:	ld1.s	{ v21 }[3], [x19]
    2434:	mov.d	x15, v24[1]
    2438:	fmov	x19, d24
    243c:	ldr	s1, [x22]
    2440:	mov.d	x20, v23[1]
    2444:	fmov	x22, d23
    2448:	ushll2.2d	v18, v20, #0x8
    244c:	ushll.2d	v19, v19, #0x8
    2450:	ushll.2d	v20, v20, #0x8
    2454:	ld1.s	{ v1 }[1], [x21]
    2458:	ld1.s	{ v1 }[2], [x7]
    245c:	ld1.s	{ v1 }[3], [x23]
    2460:	stp	q21, q1, [x9]
    2464:	fmul.4s	v22, v1, v1
    2468:	fmul.4s	v21, v21, v21
    246c:	mov.d	x7, v8[1]
    2470:	fmov	x21, d8
    2474:	mov.d	x23, v26[1]
    2478:	ldr	s1, [x19]
    247c:	ld1.s	{ v1 }[1], [x15]
    2480:	ld1.s	{ v1 }[2], [x22]
    2484:	ld1.s	{ v1 }[3], [x20]
    2488:	fmov	x15, d26
    248c:	ldr	s23, [x21]
    2490:	ld1.s	{ v23 }[1], [x7]
    2494:	ld1.s	{ v23 }[2], [x15]
    2498:	ld1.s	{ v23 }[3], [x23]
    249c:	stp	q1, q23, [x9, #0x20]
    24a0:	fmul.4s	v24, v23, v23
    24a4:	fmul.4s	v23, v1, v1
    24a8:	mov.d	x15, v25[1]
    24ac:	mov.d	x7, v31[1]
    24b0:	mov.d	x19, v9[1]
    24b4:	fmov	x20, d25
    24b8:	fmov	x21, d9
    24bc:	mov.d	x22, v10[1]
    24c0:	fmov	x23, d10
    24c4:	ldr	s1, [x21]
    24c8:	ld1.s	{ v1 }[1], [x19]
    24cc:	ld1.s	{ v1 }[2], [x23]
    24d0:	ld1.s	{ v1 }[3], [x22]
    24d4:	fmov	x19, d31
    24d8:	ldr	s26, [x20]
    24dc:	ld1.s	{ v26 }[1], [x15]
    24e0:	ld1.s	{ v26 }[2], [x19]
    24e4:	ld1.s	{ v26 }[3], [x7]
    24e8:	stp	q26, q1, [x9, #0x40]
    24ec:	fmul.4s	v25, v1, v1
    24f0:	fmul.4s	v26, v26, v26
    24f4:	mov.d	x15, v28[1]
    24f8:	fmov	x7, d28
    24fc:	mov.d	x19, v29[1]
    2500:	fmov	x20, d29
    2504:	mov.d	x21, v30[1]
    2508:	fmov	x22, d30
    250c:	mov.d	x23, v27[1]
    2510:	ldr	s1, [x7]
    2514:	ld1.s	{ v1 }[1], [x15]
    2518:	ld1.s	{ v1 }[2], [x20]
    251c:	ld1.s	{ v1 }[3], [x19]
    2520:	fmov	x15, d27
    2524:	ldr	s27, [x22]
    2528:	ld1.s	{ v27 }[1], [x21]
    252c:	ld1.s	{ v27 }[2], [x15]
    2530:	ld1.s	{ v27 }[3], [x23]
    2534:	stp	q1, q27, [x9, #0x60]
    2538:	fmul.4s	v28, v27, v27
    253c:	fmul.4s	v27, v1, v1
    2540:	add	x20, x9, x14, lsl #5
    2544:	add	x15, x14, #0x5
    2548:	add	x7, x14, #0x6
    254c:	add	x19, x14, #0x7
    2550:	add	x14, x14, #0x4
    2554:	dup.2d	v1, x14
    2558:	add.2d	v29, v1, v17
    255c:	add.2d	v30, v1, v19
    2560:	add.2d	v31, v1, v20
    2564:	add.2d	v1, v1, v18
    2568:	shl.2d	v31, v31, #0x2
    256c:	shl.2d	v1, v1, #0x2
    2570:	shl.2d	v30, v30, #0x2
    2574:	shl.2d	v29, v29, #0x2
    2578:	add.2d	v29, v7, v29
    257c:	add.2d	v30, v7, v30
    2580:	add.2d	v1, v7, v1
    2584:	add.2d	v31, v7, v31
    2588:	mov.d	x21, v31[1]
    258c:	mov.d	x22, v1[1]
    2590:	fmov	x23, d31
    2594:	fmov	x25, d1
    2598:	mov.d	x26, v30[1]
    259c:	fmov	x27, d30
    25a0:	ldr	s1, [x23]
    25a4:	mov.d	x23, v29[1]
    25a8:	ld1.s	{ v1 }[1], [x21]
    25ac:	ld1.s	{ v1 }[2], [x25]
    25b0:	fmov	x21, d29
    25b4:	ldr	s29, [x27]
    25b8:	ld1.s	{ v29 }[1], [x26]
    25bc:	ld1.s	{ v1 }[3], [x22]
    25c0:	ld1.s	{ v29 }[2], [x21]
    25c4:	dup.2d	v30, x15
    25c8:	ld1.s	{ v29 }[3], [x23]
    25cc:	add.2d	v31, v30, v17
    25d0:	add.2d	v8, v30, v20
    25d4:	shl.2d	v8, v8, #0x2
    25d8:	add.2d	v8, v7, v8
    25dc:	stp	q1, q29, [x20, #0x80]
    25e0:	mov.d	x15, v8[1]
    25e4:	fmov	x21, d8
    25e8:	add.2d	v8, v30, v19
    25ec:	add.2d	v30, v30, v18
    25f0:	fmul.4s	v1, v1, v1
    25f4:	shl.2d	v30, v30, #0x2
    25f8:	shl.2d	v8, v8, #0x2
    25fc:	shl.2d	v31, v31, #0x2
    2600:	add.2d	v31, v7, v31
    2604:	add.2d	v8, v7, v8
    2608:	fmul.4s	v29, v29, v29
    260c:	add.2d	v30, v7, v30
    2610:	mov.d	x22, v30[1]
    2614:	mov.d	x23, v8[1]
    2618:	fadd.4s	v22, v22, v29
    261c:	fmov	x25, d30
    2620:	fmov	x26, d8
    2624:	mov.d	x27, v31[1]
    2628:	ldr	s29, [x21]
    262c:	fadd.4s	v21, v21, v1
    2630:	fmov	x21, d31
    2634:	ld1.s	{ v29 }[1], [x15]
    2638:	ldr	s1, [x26]
    263c:	ld1.s	{ v29 }[2], [x25]
    2640:	ld1.s	{ v1 }[1], [x23]
    2644:	ld1.s	{ v1 }[2], [x21]
    2648:	ld1.s	{ v29 }[3], [x22]
    264c:	dup.2d	v30, x7
    2650:	add.2d	v31, v30, v17
    2654:	add.2d	v8, v30, v20
    2658:	ld1.s	{ v1 }[3], [x27]
    265c:	shl.2d	v8, v8, #0x2
    2660:	add.2d	v8, v7, v8
    2664:	mov.d	x15, v8[1]
    2668:	stp	q29, q1, [x20, #0xa0]
    266c:	fmov	x7, d8
    2670:	add.2d	v8, v30, v19
    2674:	add.2d	v30, v30, v18
    2678:	shl.2d	v30, v30, #0x2
    267c:	shl.2d	v8, v8, #0x2
    2680:	fmul.4s	v29, v29, v29
    2684:	shl.2d	v31, v31, #0x2
    2688:	add.2d	v31, v7, v31
    268c:	add.2d	v30, v7, v30
    2690:	mov.d	x21, v30[1]
    2694:	fmul.4s	v1, v1, v1
    2698:	add.2d	v8, v7, v8
    269c:	fmov	x22, d30
    26a0:	mov.d	x23, v8[1]
    26a4:	fmov	x25, d8
    26a8:	fadd.4s	v24, v24, v1
    26ac:	mov.d	x26, v31[1]
    26b0:	ldr	s1, [x25]
    26b4:	ld1.s	{ v1 }[1], [x23]
    26b8:	fadd.4s	v23, v23, v29
    26bc:	fmov	x23, d31
    26c0:	ld1.s	{ v1 }[2], [x23]
    26c4:	ldr	s29, [x7]
    26c8:	ld1.s	{ v1 }[3], [x26]
    26cc:	ld1.s	{ v29 }[1], [x15]
    26d0:	ld1.s	{ v29 }[2], [x22]
    26d4:	ld1.s	{ v29 }[3], [x21]
    26d8:	dup.2d	v30, x19
    26dc:	add.2d	v31, v30, v17
    26e0:	add.2d	v8, v30, v20
    26e4:	stp	q29, q1, [x20, #0xc0]
    26e8:	shl.2d	v8, v8, #0x2
    26ec:	add.2d	v8, v7, v8
    26f0:	mov.d	x15, v8[1]
    26f4:	fmov	x7, d8
    26f8:	fmul.4s	v29, v29, v29
    26fc:	add.2d	v8, v30, v19
    2700:	add.2d	v30, v30, v18
    2704:	shl.2d	v30, v30, #0x2
    2708:	shl.2d	v8, v8, #0x2
    270c:	shl.2d	v31, v31, #0x2
    2710:	fmul.4s	v1, v1, v1
    2714:	add.2d	v31, v7, v31
    2718:	add.2d	v8, v7, v8
    271c:	add.2d	v30, v7, v30
    2720:	mov.d	x19, v30[1]
    2724:	fadd.4s	v25, v25, v1
    2728:	fmov	x21, d30
    272c:	mov.d	x22, v8[1]
    2730:	mov.d	x23, v31[1]
    2734:	fadd.4s	v26, v26, v29
    2738:	fmov	x25, d8
    273c:	ldr	s1, [x7]
    2740:	ld1.s	{ v1 }[1], [x15]
    2744:	ld1.s	{ v1 }[2], [x21]
    2748:	fmov	x15, d31
    274c:	ldr	s29, [x25]
    2750:	ld1.s	{ v29 }[1], [x22]
    2754:	ld1.s	{ v1 }[3], [x19]
    2758:	ld1.s	{ v29 }[2], [x15]
    275c:	ld1.s	{ v29 }[3], [x23]
    2760:	stp	q1, q29, [x20, #0xe0]
    2764:	fmul.4s	v1, v1, v1
    2768:	fmul.4s	v29, v29, v29
    276c:	fadd.4s	v28, v28, v29
    2770:	fadd.4s	v27, v27, v1
    2774:	cmp	x14, #0xfc
    2778:	b.lo	0x2540
    277c:	mov	x14, #0x0
    2780:	add	x15, x24, x14, lsl #2
    2784:	ld1r.4s	{ v1 }, [x15]
    2788:	add	x15, x6, x14, lsl #5
    278c:	stp	q1, q1, [x15]
    2790:	add	x14, x14, #0x1
    2794:	cmp	x14, #0x100
    2798:	b.ne	0x2780
    279c:	mov	x14, #0x0
    27a0:	fadd.4s	v1, v22, v24
    27a4:	fadd.4s	v7, v21, v23
    27a8:	fadd.4s	v7, v7, v26
    27ac:	fadd.4s	v1, v1, v25
    27b0:	fadd.4s	v1, v1, v28
    27b4:	fadd.4s	v7, v7, v27
    27b8:	fmul.4s	v7, v7, v6
    27bc:	fmul.4s	v1, v1, v6
    27c0:	fadd.4s	v1, v1, v5
    27c4:	fadd.4s	v5, v7, v5
    27c8:	fsqrt.4s	v5, v5
    27cc:	fsqrt.4s	v6, v1
    27d0:	dup.2d	v1, x14
    27d4:	add.2d	v7, v1, v17
    27d8:	add.2d	v21, v1, v19
    27dc:	add.2d	v22, v1, v18
    27e0:	add.2d	v1, v1, v20
    27e4:	lsl	x15, x14, #5
    27e8:	add	x7, x9, x15
    27ec:	ldp	q24, q23, [x7]
    27f0:	fdiv.4s	v24, v24, v5
    27f4:	fdiv.4s	v23, v23, v6
    27f8:	add	x15, x6, x15
    27fc:	ldp	q25, q26, [x15]
    2800:	fmul.4s	v23, v23, v26
    2804:	fmul.4s	v24, v24, v25
    2808:	shl.2d	v1, v1, #0x2
    280c:	shl.2d	v22, v22, #0x2
    2810:	shl.2d	v21, v21, #0x2
    2814:	shl.2d	v7, v7, #0x2
    2818:	add.2d	v7, v16, v7
    281c:	add.2d	v1, v16, v1
    2820:	mov.d	x15, v1[1]
    2824:	fmov	x7, d1
    2828:	str	s24, [x7]
    282c:	st1.s	{ v24 }[1], [x15]
    2830:	add.2d	v1, v16, v22
    2834:	mov.d	x15, v1[1]
    2838:	fmov	x7, d1
    283c:	st1.s	{ v24 }[2], [x7]
    2840:	add.2d	v1, v16, v21
    2844:	st1.s	{ v24 }[3], [x15]
    2848:	mov.d	x15, v1[1]
    284c:	fmov	x7, d1
    2850:	str	s23, [x7]
    2854:	st1.s	{ v23 }[1], [x15]
    2858:	mov.d	x15, v7[1]
    285c:	fmov	x7, d7
    2860:	st1.s	{ v23 }[2], [x7]
    2864:	st1.s	{ v23 }[3], [x15]
    2868:	add	x14, x14, #0x1
    286c:	cmp	x14, #0x100
    2870:	b.ne	0x27d0
    2874:	b	0x9c
    2878:	lsr	x24, x25, #3
    287c:	cmp	x25, #0x8
    2880:	b.lo	0x2d94
    2884:	mov	w26, #0x0
    2888:	ldr	x10, [sp, #0x38]
    288c:	ldr	x27, [x10]
    2890:	ldr	x28, [x10, #0x10]
    2894:	lsl	w30, w12, #6
    2898:	ldr	x23, [x10, #0x30]
    289c:	mov	x14, #0x0
    28a0:	add	w15, w30, w26, lsl #3
    28a4:	dup.4s	v1, w15
    28a8:	orr.16b	v18, v1, v0
    28ac:	orr.16b	v19, v1, v3
    28b0:	dup.2d	v16, x16
    28b4:	ushll.2d	v1, v19, #0xa
    28b8:	ushll2.2d	v21, v19, #0xa
    28bc:	ushll.2d	v20, v18, #0xa
    28c0:	ushll2.2d	v17, v18, #0xa
    28c4:	dup.2d	v7, x27
    28c8:	add.2d	v17, v7, v17
    28cc:	add.2d	v20, v7, v20
    28d0:	add.2d	v21, v7, v21
    28d4:	add.2d	v22, v7, v1
    28d8:	mov.d	x15, v22[1]
    28dc:	dup.2d	v25, x4
    28e0:	add.2d	v23, v22, v25
    28e4:	add.2d	v24, v22, v16
    28e8:	dup.2d	v1, x5
    28ec:	add.2d	v27, v22, v1
    28f0:	fmov	x7, d22
    28f4:	mov.d	x19, v21[1]
    28f8:	add.2d	v22, v21, v25
    28fc:	add.2d	v30, v21, v16
    2900:	add.2d	v28, v21, v1
    2904:	fmov	x20, d21
    2908:	mov.d	x21, v20[1]
    290c:	add.2d	v31, v20, v25
    2910:	add.2d	v8, v20, v16
    2914:	add.2d	v29, v20, v1
    2918:	fmov	x22, d20
    291c:	mov.d	x10, v17[1]
    2920:	ldr	s20, [x7]
    2924:	add.2d	v25, v17, v25
    2928:	add.2d	v9, v17, v16
    292c:	add.2d	v26, v17, v1
    2930:	fmov	x7, d17
    2934:	ushll2.2d	v16, v18, #0x8
    2938:	ld1.s	{ v20 }[1], [x15]
    293c:	ld1.s	{ v20 }[2], [x20]
    2940:	ld1.s	{ v20 }[3], [x19]
    2944:	mov.d	x15, v23[1]
    2948:	fmov	x19, d23
    294c:	ldr	s1, [x22]
    2950:	mov.d	x20, v22[1]
    2954:	fmov	x22, d22
    2958:	ushll2.2d	v17, v19, #0x8
    295c:	ushll.2d	v18, v18, #0x8
    2960:	ushll.2d	v19, v19, #0x8
    2964:	ld1.s	{ v1 }[1], [x21]
    2968:	ld1.s	{ v1 }[2], [x7]
    296c:	ld1.s	{ v1 }[3], [x10]
    2970:	stp	q20, q1, [x9]
    2974:	fmul.4s	v21, v1, v1
    2978:	fmul.4s	v20, v20, v20
    297c:	mov.d	x10, v31[1]
    2980:	fmov	x7, d31
    2984:	mov.d	x21, v25[1]
    2988:	ldr	s1, [x19]
    298c:	ld1.s	{ v1 }[1], [x15]
    2990:	ld1.s	{ v1 }[2], [x22]
    2994:	ld1.s	{ v1 }[3], [x20]
    2998:	fmov	x15, d25
    299c:	ldr	s22, [x7]
    29a0:	ld1.s	{ v22 }[1], [x10]
    29a4:	ld1.s	{ v22 }[2], [x15]
    29a8:	ld1.s	{ v22 }[3], [x21]
    29ac:	stp	q1, q22, [x9, #0x20]
    29b0:	fmul.4s	v23, v22, v22
    29b4:	fmul.4s	v22, v1, v1
    29b8:	mov.d	x10, v24[1]
    29bc:	mov.d	x15, v30[1]
    29c0:	mov.d	x7, v8[1]
    29c4:	fmov	x19, d24
    29c8:	fmov	x20, d8
    29cc:	mov.d	x21, v9[1]
    29d0:	fmov	x22, d9
    29d4:	ldr	s1, [x20]
    29d8:	ld1.s	{ v1 }[1], [x7]
    29dc:	ld1.s	{ v1 }[2], [x22]
    29e0:	ld1.s	{ v1 }[3], [x21]
    29e4:	fmov	x7, d30
    29e8:	ldr	s25, [x19]
    29ec:	ld1.s	{ v25 }[1], [x10]
    29f0:	ld1.s	{ v25 }[2], [x7]
    29f4:	ld1.s	{ v25 }[3], [x15]
    29f8:	stp	q25, q1, [x9, #0x40]
    29fc:	fmul.4s	v24, v1, v1
    2a00:	fmul.4s	v25, v25, v25
    2a04:	mov.d	x10, v27[1]
    2a08:	fmov	x15, d27
    2a0c:	mov.d	x7, v28[1]
    2a10:	fmov	x19, d28
    2a14:	mov.d	x20, v29[1]
    2a18:	fmov	x21, d29
    2a1c:	mov.d	x22, v26[1]
    2a20:	ldr	s1, [x15]
    2a24:	ld1.s	{ v1 }[1], [x10]
    2a28:	ld1.s	{ v1 }[2], [x19]
    2a2c:	ld1.s	{ v1 }[3], [x7]
    2a30:	fmov	x10, d26
    2a34:	ldr	s26, [x21]
    2a38:	ld1.s	{ v26 }[1], [x20]
    2a3c:	ld1.s	{ v26 }[2], [x10]
    2a40:	ld1.s	{ v26 }[3], [x22]
    2a44:	stp	q1, q26, [x9, #0x60]
    2a48:	fmul.4s	v27, v26, v26
    2a4c:	fmul.4s	v26, v1, v1
    2a50:	add	x20, x9, x14, lsl #5
    2a54:	add	x15, x14, #0x5
    2a58:	add	x7, x14, #0x6
    2a5c:	add	x19, x14, #0x7
    2a60:	add	x14, x14, #0x4
    2a64:	dup.2d	v1, x14
    2a68:	add.2d	v28, v1, v16
    2a6c:	add.2d	v29, v1, v18
    2a70:	add.2d	v30, v1, v19
    2a74:	add.2d	v1, v1, v17
    2a78:	shl.2d	v30, v30, #0x2
    2a7c:	shl.2d	v1, v1, #0x2
    2a80:	shl.2d	v29, v29, #0x2
    2a84:	shl.2d	v28, v28, #0x2
    2a88:	add.2d	v28, v7, v28
    2a8c:	add.2d	v29, v7, v29
    2a90:	add.2d	v1, v7, v1
    2a94:	add.2d	v30, v7, v30
    2a98:	mov.d	x10, v30[1]
    2a9c:	mov.d	x21, v1[1]
    2aa0:	fmov	x22, d30
    2aa4:	fmov	x11, d1
    2aa8:	mov.d	x1, v29[1]
    2aac:	fmov	x3, d29
    2ab0:	ldr	s1, [x22]
    2ab4:	mov.d	x22, v28[1]
    2ab8:	ld1.s	{ v1 }[1], [x10]
    2abc:	ld1.s	{ v1 }[2], [x11]
    2ac0:	fmov	x10, d28
    2ac4:	ldr	s28, [x3]
    2ac8:	ld1.s	{ v28 }[1], [x1]
    2acc:	ld1.s	{ v1 }[3], [x21]
    2ad0:	ld1.s	{ v28 }[2], [x10]
    2ad4:	dup.2d	v29, x15
    2ad8:	ld1.s	{ v28 }[3], [x22]
    2adc:	add.2d	v30, v29, v16
    2ae0:	add.2d	v31, v29, v19
    2ae4:	shl.2d	v31, v31, #0x2
    2ae8:	add.2d	v31, v7, v31
    2aec:	stp	q1, q28, [x20, #0x80]
    2af0:	mov.d	x10, v31[1]
    2af4:	fmov	x11, d31
    2af8:	add.2d	v31, v29, v18
    2afc:	add.2d	v29, v29, v17
    2b00:	fmul.4s	v1, v1, v1
    2b04:	shl.2d	v29, v29, #0x2
    2b08:	shl.2d	v31, v31, #0x2
    2b0c:	shl.2d	v30, v30, #0x2
    2b10:	add.2d	v30, v7, v30
    2b14:	add.2d	v31, v7, v31
    2b18:	fmul.4s	v28, v28, v28
    2b1c:	add.2d	v29, v7, v29
    2b20:	mov.d	x15, v29[1]
    2b24:	mov.d	x1, v31[1]
    2b28:	fadd.4s	v21, v21, v28
    2b2c:	fmov	x3, d29
    2b30:	fmov	x21, d31
    2b34:	mov.d	x22, v30[1]
    2b38:	ldr	s28, [x11]
    2b3c:	fadd.4s	v20, v20, v1
    2b40:	fmov	x11, d30
    2b44:	ld1.s	{ v28 }[1], [x10]
    2b48:	ldr	s1, [x21]
    2b4c:	ld1.s	{ v28 }[2], [x3]
    2b50:	ld1.s	{ v1 }[1], [x1]
    2b54:	ld1.s	{ v1 }[2], [x11]
    2b58:	ld1.s	{ v28 }[3], [x15]
    2b5c:	dup.2d	v29, x7
    2b60:	add.2d	v30, v29, v16
    2b64:	add.2d	v31, v29, v19
    2b68:	ld1.s	{ v1 }[3], [x22]
    2b6c:	shl.2d	v31, v31, #0x2
    2b70:	add.2d	v31, v7, v31
    2b74:	mov.d	x10, v31[1]
    2b78:	stp	q28, q1, [x20, #0xa0]
    2b7c:	fmov	x11, d31
    2b80:	add.2d	v31, v29, v18
    2b84:	add.2d	v29, v29, v17
    2b88:	shl.2d	v29, v29, #0x2
    2b8c:	shl.2d	v31, v31, #0x2
    2b90:	fmul.4s	v28, v28, v28
    2b94:	shl.2d	v30, v30, #0x2
    2b98:	add.2d	v30, v7, v30
    2b9c:	add.2d	v29, v7, v29
    2ba0:	mov.d	x15, v29[1]
    2ba4:	fmul.4s	v1, v1, v1
    2ba8:	add.2d	v31, v7, v31
    2bac:	fmov	x1, d29
    2bb0:	mov.d	x3, v31[1]
    2bb4:	fmov	x7, d31
    2bb8:	fadd.4s	v23, v23, v1
    2bbc:	mov.d	x21, v30[1]
    2bc0:	ldr	s1, [x7]
    2bc4:	ld1.s	{ v1 }[1], [x3]
    2bc8:	fadd.4s	v22, v22, v28
    2bcc:	fmov	x3, d30
    2bd0:	ld1.s	{ v1 }[2], [x3]
    2bd4:	ldr	s28, [x11]
    2bd8:	ld1.s	{ v1 }[3], [x21]
    2bdc:	ld1.s	{ v28 }[1], [x10]
    2be0:	ld1.s	{ v28 }[2], [x1]
    2be4:	ld1.s	{ v28 }[3], [x15]
    2be8:	dup.2d	v29, x19
    2bec:	add.2d	v30, v29, v16
    2bf0:	add.2d	v31, v29, v19
    2bf4:	stp	q28, q1, [x20, #0xc0]
    2bf8:	shl.2d	v31, v31, #0x2
    2bfc:	add.2d	v31, v7, v31
    2c00:	mov.d	x10, v31[1]
    2c04:	fmov	x11, d31
    2c08:	fmul.4s	v28, v28, v28
    2c0c:	add.2d	v31, v29, v18
    2c10:	add.2d	v29, v29, v17
    2c14:	shl.2d	v29, v29, #0x2
    2c18:	shl.2d	v31, v31, #0x2
    2c1c:	shl.2d	v30, v30, #0x2
    2c20:	fmul.4s	v1, v1, v1
    2c24:	add.2d	v30, v7, v30
    2c28:	add.2d	v31, v7, v31
    2c2c:	add.2d	v29, v7, v29
    2c30:	mov.d	x15, v29[1]
    2c34:	fadd.4s	v24, v24, v1
    2c38:	fmov	x1, d29
    2c3c:	mov.d	x3, v31[1]
    2c40:	mov.d	x7, v30[1]
    2c44:	fadd.4s	v25, v25, v28
    2c48:	fmov	x19, d31
    2c4c:	ldr	s1, [x11]
    2c50:	ld1.s	{ v1 }[1], [x10]
    2c54:	ld1.s	{ v1 }[2], [x1]
    2c58:	fmov	x10, d30
    2c5c:	ldr	s28, [x19]
    2c60:	ld1.s	{ v28 }[1], [x3]
    2c64:	ld1.s	{ v1 }[3], [x15]
    2c68:	ld1.s	{ v28 }[2], [x10]
    2c6c:	ld1.s	{ v28 }[3], [x7]
    2c70:	stp	q1, q28, [x20, #0xe0]
    2c74:	fmul.4s	v1, v1, v1
    2c78:	fmul.4s	v28, v28, v28
    2c7c:	fadd.4s	v27, v27, v28
    2c80:	fadd.4s	v26, v26, v1
    2c84:	cmp	x14, #0xfc
    2c88:	b.lo	0x2a50
    2c8c:	mov	x14, #0x0
    2c90:	add	x10, x28, x14, lsl #2
    2c94:	ld1r.4s	{ v1 }, [x10]
    2c98:	add	x10, x6, x14, lsl #5
    2c9c:	stp	q1, q1, [x10]
    2ca0:	add	x14, x14, #0x1
    2ca4:	cmp	x14, #0x100
    2ca8:	b.ne	0x2c90
    2cac:	mov	x14, #0x0
    2cb0:	fadd.4s	v1, v21, v23
    2cb4:	fadd.4s	v7, v20, v22
    2cb8:	fadd.4s	v7, v7, v25
    2cbc:	fadd.4s	v1, v1, v24
    2cc0:	fadd.4s	v1, v1, v27
    2cc4:	fadd.4s	v7, v7, v26
    2cc8:	fmul.4s	v7, v7, v6
    2ccc:	fmul.4s	v1, v1, v6
    2cd0:	fadd.4s	v1, v1, v5
    2cd4:	fadd.4s	v7, v7, v5
    2cd8:	fsqrt.4s	v7, v7
    2cdc:	fsqrt.4s	v20, v1
    2ce0:	dup.2d	v1, x14
    2ce4:	add.2d	v21, v1, v16
    2ce8:	add.2d	v22, v1, v18
    2cec:	add.2d	v23, v1, v17
    2cf0:	add.2d	v1, v1, v19
    2cf4:	lsl	x10, x14, #5
    2cf8:	add	x11, x9, x10
    2cfc:	ldp	q25, q24, [x11]
    2d00:	fdiv.4s	v25, v25, v7
    2d04:	fdiv.4s	v24, v24, v20
    2d08:	add	x10, x6, x10
    2d0c:	ldp	q26, q27, [x10]
    2d10:	fmul.4s	v24, v24, v27
    2d14:	fmul.4s	v25, v25, v26
    2d18:	shl.2d	v1, v1, #0x2
    2d1c:	shl.2d	v23, v23, #0x2
    2d20:	shl.2d	v22, v22, #0x2
    2d24:	shl.2d	v21, v21, #0x2
    2d28:	dup.2d	v26, x23
    2d2c:	add.2d	v21, v26, v21
    2d30:	add.2d	v1, v26, v1
    2d34:	mov.d	x10, v1[1]
    2d38:	fmov	x11, d1
    2d3c:	str	s25, [x11]
    2d40:	st1.s	{ v25 }[1], [x10]
    2d44:	add.2d	v1, v26, v23
    2d48:	mov.d	x10, v1[1]
    2d4c:	fmov	x11, d1
    2d50:	st1.s	{ v25 }[2], [x11]
    2d54:	add.2d	v1, v26, v22
    2d58:	st1.s	{ v25 }[3], [x10]
    2d5c:	mov.d	x10, v1[1]
    2d60:	fmov	x11, d1
    2d64:	str	s24, [x11]
    2d68:	st1.s	{ v24 }[1], [x10]
    2d6c:	mov.d	x10, v21[1]
    2d70:	fmov	x11, d21
    2d74:	st1.s	{ v24 }[2], [x11]
    2d78:	st1.s	{ v24 }[3], [x10]
    2d7c:	add	x14, x14, #0x1
    2d80:	cmp	x14, #0x100
    2d84:	b.ne	0x2ce0
    2d88:	add	w26, w26, #0x1
    2d8c:	cmp	w26, w24
    2d90:	b.ne	0x289c
    2d94:	and	w14, w25, #0x7
    2d98:	cbz	w14, 0x94
    2d9c:	dup.4s	v1, w14
    2da0:	cmhi.4s	v7, v1, v0
    2da4:	cmhi.4s	v16, v1, v3
    2da8:	uzp1.8h	v1, v16, v7
    2dac:	umaxv.8h	h17, v1
    2db0:	fmov	w10, s17
    2db4:	tbz	w10, #0x0, 0x94
    2db8:	ldr	x10, [sp, #0x38]
    2dbc:	ldr	x10, [x10]
    2dc0:	adrp	x11, lCPI0_2@PAGE
    2dc4:	ldr	q17, [x11, lCPI0_2@PAGEOFF]
    2dc8:	and.16b	v1, v1, v17
    2dcc:	addv.8h	h17, v1
    2dd0:	fmov	w14, s17
    2dd4:	lsl	w11, w24, #3
    2dd8:	orr	w11, w11, w12, lsl #6
    2ddc:	dup.4s	v20, w11
    2de0:	orr.16b	v1, v20, v3
    2de4:	and.16b	v19, v16, v1
    2de8:	ushll.2d	v21, v19, #0xa
    2dec:	dup.2d	v18, x10
    2df0:	add.2d	v22, v18, v21
    2df4:	movi.2d	v23, #0000000000000000
    2df8:	movi.2d	v24, #0000000000000000
    2dfc:	tbnz	w14, #0x0, 0x35cc
    2e00:	and	w14, w14, #0xff
    2e04:	tbnz	w14, #0x1, 0x35dc
    2e08:	ushll2.2d	v22, v19, #0xa
    2e0c:	add.2d	v1, v18, v22
    2e10:	tbnz	w14, #0x2, 0x35f0
    2e14:	tbnz	w14, #0x3, 0x35fc
    2e18:	orr.16b	v1, v20, v0
    2e1c:	and.16b	v20, v7, v1
    2e20:	ushll.2d	v26, v20, #0xa
    2e24:	add.2d	v1, v18, v26
    2e28:	tbnz	w14, #0x4, 0x3618
    2e2c:	tbnz	w14, #0x5, 0x3624
    2e30:	ushll2.2d	v27, v20, #0xa
    2e34:	add.2d	v1, v18, v27
    2e38:	tbnz	w14, #0x6, 0x3638
    2e3c:	tbz	w14, #0x7, 0x2e48
    2e40:	mov.d	x10, v1[1]
    2e44:	ld1.s	{ v24 }[3], [x10]
    2e48:	ldr	x10, [sp, #0x38]
    2e4c:	ldr	x25, [x10, #0x10]
    2e50:	ldr	x24, [x10, #0x30]
    2e54:	fmov	w14, s17
    2e58:	stp	q23, q24, [x9]
    2e5c:	dup.2d	v1, x4
    2e60:	add.2d	v29, v18, v1
    2e64:	add.2d	v30, v29, v21
    2e68:	movi.2d	v25, #0000000000000000
    2e6c:	movi.2d	v28, #0000000000000000
    2e70:	tbnz	w14, #0x0, 0x3648
    2e74:	and	w14, w14, #0xff
    2e78:	tbnz	w14, #0x1, 0x3658
    2e7c:	add.2d	v1, v29, v22
    2e80:	tbnz	w14, #0x2, 0x3668
    2e84:	tbnz	w14, #0x3, 0x3674
    2e88:	add.2d	v1, v29, v26
    2e8c:	tbnz	w14, #0x4, 0x3684
    2e90:	tbnz	w14, #0x5, 0x3690
    2e94:	add.2d	v1, v29, v27
    2e98:	tbnz	w14, #0x6, 0x36a0
    2e9c:	tbz	w14, #0x7, 0x2ea8
    2ea0:	mov.d	x10, v1[1]
    2ea4:	ld1.s	{ v28 }[3], [x10]
    2ea8:	fmov	w14, s17
    2eac:	stp	q25, q28, [x9, #0x20]
    2eb0:	dup.2d	v1, x16
    2eb4:	add.2d	v31, v18, v1
    2eb8:	add.2d	v8, v31, v21
    2ebc:	movi.2d	v29, #0000000000000000
    2ec0:	movi.2d	v30, #0000000000000000
    2ec4:	tbnz	w14, #0x0, 0x36b0
    2ec8:	and	w14, w14, #0xff
    2ecc:	tbnz	w14, #0x1, 0x36c0
    2ed0:	add.2d	v1, v31, v22
    2ed4:	tbnz	w14, #0x2, 0x36d0
    2ed8:	tbnz	w14, #0x3, 0x36dc
    2edc:	add.2d	v1, v31, v26
    2ee0:	tbnz	w14, #0x4, 0x36ec
    2ee4:	tbnz	w14, #0x5, 0x36f8
    2ee8:	add.2d	v1, v31, v27
    2eec:	tbnz	w14, #0x6, 0x3708
    2ef0:	tbz	w14, #0x7, 0x2efc
    2ef4:	mov.d	x10, v1[1]
    2ef8:	ld1.s	{ v30 }[3], [x10]
    2efc:	fmov	w14, s17
    2f00:	stp	q29, q30, [x9, #0x40]
    2f04:	dup.2d	v1, x5
    2f08:	add.2d	v9, v18, v1
    2f0c:	add.2d	v21, v9, v21
    2f10:	movi.2d	v31, #0000000000000000
    2f14:	movi.2d	v8, #0000000000000000
    2f18:	tbnz	w14, #0x0, 0x3718
    2f1c:	and	w14, w14, #0xff
    2f20:	tbnz	w14, #0x1, 0x3728
    2f24:	add.2d	v1, v9, v22
    2f28:	tbnz	w14, #0x2, 0x3738
    2f2c:	tbnz	w14, #0x3, 0x3744
    2f30:	add.2d	v1, v9, v26
    2f34:	tbnz	w14, #0x4, 0x3754
    2f38:	tbnz	w14, #0x5, 0x3760
    2f3c:	add.2d	v1, v9, v27
    2f40:	tbnz	w14, #0x6, 0x3770
    2f44:	tbz	w14, #0x7, 0x2f50
    2f48:	mov.d	x10, v1[1]
    2f4c:	ld1.s	{ v8 }[3], [x10]
    2f50:	sshll.2d	v1, v16, #0x0
    2f54:	sshll.2d	v21, v7, #0x0
    2f58:	sshll2.2d	v22, v16, #0x0
    2f5c:	sshll2.2d	v26, v7, #0x0
    2f60:	ushll.2d	v27, v19, #0x8
    2f64:	ushll.2d	v9, v20, #0x8
    2f68:	ushll2.2d	v10, v19, #0x8
    2f6c:	ushll2.2d	v19, v20, #0x8
    2f70:	and.16b	v19, v26, v19
    2f74:	and.16b	v20, v22, v10
    2f78:	and.16b	v21, v21, v9
    2f7c:	and.16b	v22, v1, v27
    2f80:	fmul.4s	v1, v23, v23
    2f84:	fmul.4s	v23, v24, v24
    2f88:	fmul.4s	v24, v25, v25
    2f8c:	fmul.4s	v25, v28, v28
    2f90:	fmul.4s	v27, v29, v29
    2f94:	fmul.4s	v28, v30, v30
    2f98:	stp	q31, q8, [x9, #0x60]
    2f9c:	fmul.4s	v30, v31, v31
    2fa0:	fmul.4s	v31, v8, v8
    2fa4:	and.16b	v23, v7, v23
    2fa8:	and.16b	v26, v16, v1
    2fac:	and.16b	v25, v7, v25
    2fb0:	and.16b	v29, v16, v24
    2fb4:	and.16b	v28, v7, v28
    2fb8:	and.16b	v27, v16, v27
    2fbc:	and.16b	v24, v7, v31
    2fc0:	ldr	x23, [sp, #0x8]
    2fc4:	mov	w14, #0x4
    2fc8:	and.16b	v30, v16, v30
    2fcc:	b	0x3050
    2fd0:	fmul.4s	v1, v8, v8
    2fd4:	fmul.4s	v31, v31, v31
    2fd8:	fadd.4s	v31, v26, v31
    2fdc:	fadd.4s	v1, v23, v1
    2fe0:	fmul.4s	v8, v10, v10
    2fe4:	fmul.4s	v9, v9, v9
    2fe8:	fadd.4s	v9, v29, v9
    2fec:	fadd.4s	v8, v25, v8
    2ff0:	fmul.4s	v10, v12, v12
    2ff4:	fmul.4s	v11, v11, v11
    2ff8:	fadd.4s	v11, v27, v11
    2ffc:	fadd.4s	v10, v28, v10
    3000:	ldp	q12, q15, [x23]
    3004:	bit.16b	v15, v14, v7
    3008:	bit.16b	v12, v13, v16
    300c:	stp	q12, q15, [x23], #0x80
    3010:	fmul.4s	v12, v13, v13
    3014:	fmul.4s	v13, v14, v14
    3018:	fadd.4s	v13, v24, v13
    301c:	fadd.4s	v12, v30, v12
    3020:	bit.16b	v23, v1, v7
    3024:	bit.16b	v26, v31, v16
    3028:	bit.16b	v25, v8, v7
    302c:	bit.16b	v29, v9, v16
    3030:	bit.16b	v28, v10, v7
    3034:	bit.16b	v27, v11, v16
    3038:	sub	x10, x14, #0x3
    303c:	bit.16b	v30, v12, v16
    3040:	add	x14, x14, #0x1
    3044:	bit.16b	v24, v13, v7
    3048:	cmp	x10, #0xfc
    304c:	b.hs	0x3440
    3050:	dup.2d	v9, x14
    3054:	fmov	w15, s17
    3058:	add.2d	v1, v9, v22
    305c:	shl.2d	v1, v1, #0x2
    3060:	add.2d	v10, v18, v1
    3064:	movi.2d	v31, #0000000000000000
    3068:	movi.2d	v8, #0000000000000000
    306c:	tbnz	w15, #0x0, 0x3238
    3070:	and	w15, w15, #0xff
    3074:	tbnz	w15, #0x1, 0x3248
    3078:	add.2d	v1, v9, v20
    307c:	shl.2d	v1, v1, #0x2
    3080:	add.2d	v1, v18, v1
    3084:	tbnz	w15, #0x2, 0x3260
    3088:	tbnz	w15, #0x3, 0x326c
    308c:	add.2d	v1, v9, v21
    3090:	shl.2d	v1, v1, #0x2
    3094:	add.2d	v1, v18, v1
    3098:	tbnz	w15, #0x4, 0x3284
    309c:	tbnz	w15, #0x5, 0x3290
    30a0:	add.2d	v1, v9, v19
    30a4:	shl.2d	v1, v1, #0x2
    30a8:	add.2d	v1, v18, v1
    30ac:	tbnz	w15, #0x6, 0x32a8
    30b0:	tbz	w15, #0x7, 0x30bc
    30b4:	mov.d	x10, v1[1]
    30b8:	ld1.s	{ v8 }[3], [x10]
    30bc:	fmov	w15, s17
    30c0:	ldp	q1, q9, [x23, #-0x60]
    30c4:	bit.16b	v9, v8, v7
    30c8:	bit.16b	v1, v31, v16
    30cc:	add	x14, x14, #0x1
    30d0:	dup.2d	v11, x14
    30d4:	stp	q1, q9, [x23, #-0x60]
    30d8:	add.2d	v1, v11, v22
    30dc:	shl.2d	v1, v1, #0x2
    30e0:	add.2d	v12, v18, v1
    30e4:	movi.2d	v9, #0000000000000000
    30e8:	movi.2d	v10, #0000000000000000
    30ec:	tbnz	w15, #0x0, 0x32b8
    30f0:	and	w15, w15, #0xff
    30f4:	tbnz	w15, #0x1, 0x32c8
    30f8:	add.2d	v1, v11, v20
    30fc:	shl.2d	v1, v1, #0x2
    3100:	add.2d	v1, v18, v1
    3104:	tbnz	w15, #0x2, 0x32e0
    3108:	tbnz	w15, #0x3, 0x32ec
    310c:	add.2d	v1, v11, v21
    3110:	shl.2d	v1, v1, #0x2
    3114:	add.2d	v1, v18, v1
    3118:	tbnz	w15, #0x4, 0x3304
    311c:	tbnz	w15, #0x5, 0x3310
    3120:	add.2d	v1, v11, v19
    3124:	shl.2d	v1, v1, #0x2
    3128:	add.2d	v1, v18, v1
    312c:	tbnz	w15, #0x6, 0x3328
    3130:	tbz	w15, #0x7, 0x313c
    3134:	mov.d	x10, v1[1]
    3138:	ld1.s	{ v10 }[3], [x10]
    313c:	fmov	w15, s17
    3140:	ldp	q1, q11, [x23, #-0x40]
    3144:	bit.16b	v11, v10, v7
    3148:	bit.16b	v1, v9, v16
    314c:	add	x14, x14, #0x1
    3150:	dup.2d	v13, x14
    3154:	stp	q1, q11, [x23, #-0x40]
    3158:	add.2d	v1, v13, v22
    315c:	shl.2d	v1, v1, #0x2
    3160:	add.2d	v14, v18, v1
    3164:	movi.2d	v11, #0000000000000000
    3168:	movi.2d	v12, #0000000000000000
    316c:	tbnz	w15, #0x0, 0x3338
    3170:	and	w15, w15, #0xff
    3174:	tbnz	w15, #0x1, 0x3348
    3178:	add.2d	v1, v13, v20
    317c:	shl.2d	v1, v1, #0x2
    3180:	add.2d	v1, v18, v1
    3184:	tbnz	w15, #0x2, 0x3360
    3188:	tbnz	w15, #0x3, 0x336c
    318c:	add.2d	v1, v13, v21
    3190:	shl.2d	v1, v1, #0x2
    3194:	add.2d	v1, v18, v1
    3198:	tbnz	w15, #0x4, 0x3384
    319c:	tbnz	w15, #0x5, 0x3390
    31a0:	add.2d	v1, v13, v19
    31a4:	shl.2d	v1, v1, #0x2
    31a8:	add.2d	v1, v18, v1
    31ac:	tbnz	w15, #0x6, 0x33a8
    31b0:	tbz	w15, #0x7, 0x31bc
    31b4:	mov.d	x10, v1[1]
    31b8:	ld1.s	{ v12 }[3], [x10]
    31bc:	fmov	w15, s17
    31c0:	ldp	q1, q13, [x23, #-0x20]
    31c4:	bit.16b	v13, v12, v7
    31c8:	bit.16b	v1, v11, v16
    31cc:	add	x14, x14, #0x1
    31d0:	dup.2d	v15, x14
    31d4:	stp	q1, q13, [x23, #-0x20]
    31d8:	add.2d	v1, v15, v22
    31dc:	shl.2d	v1, v1, #0x2
    31e0:	add.2d	v1, v18, v1
    31e4:	movi.2d	v13, #0000000000000000
    31e8:	movi.2d	v14, #0000000000000000
    31ec:	tbnz	w15, #0x0, 0x33b8
    31f0:	and	w15, w15, #0xff
    31f4:	tbnz	w15, #0x1, 0x33c8
    31f8:	add.2d	v1, v15, v20
    31fc:	shl.2d	v1, v1, #0x2
    3200:	add.2d	v1, v18, v1
    3204:	tbnz	w15, #0x2, 0x33e0
    3208:	tbnz	w15, #0x3, 0x33ec
    320c:	add.2d	v1, v15, v21
    3210:	shl.2d	v1, v1, #0x2
    3214:	add.2d	v1, v18, v1
    3218:	tbnz	w15, #0x4, 0x3404
    321c:	tbnz	w15, #0x5, 0x3410
    3220:	add.2d	v1, v15, v19
    3224:	shl.2d	v1, v1, #0x2
    3228:	add.2d	v1, v18, v1
    322c:	tbnz	w15, #0x6, 0x3428
    3230:	tbz	w15, #0x7, 0x2fd0
    3234:	b	0x3434
    3238:	fmov	x10, d10
    323c:	ldr	s31, [x10]
    3240:	and	w15, w15, #0xff
    3244:	tbz	w15, #0x1, 0x3078
    3248:	mov.d	x10, v10[1]
    324c:	ld1.s	{ v31 }[1], [x10]
    3250:	add.2d	v1, v9, v20
    3254:	shl.2d	v1, v1, #0x2
    3258:	add.2d	v1, v18, v1
    325c:	tbz	w15, #0x2, 0x3088
    3260:	fmov	x10, d1
    3264:	ld1.s	{ v31 }[2], [x10]
    3268:	tbz	w15, #0x3, 0x308c
    326c:	mov.d	x10, v1[1]
    3270:	ld1.s	{ v31 }[3], [x10]
    3274:	add.2d	v1, v9, v21
    3278:	shl.2d	v1, v1, #0x2
    327c:	add.2d	v1, v18, v1
    3280:	tbz	w15, #0x4, 0x309c
    3284:	fmov	x10, d1
    3288:	ld1.s	{ v8 }[0], [x10]
    328c:	tbz	w15, #0x5, 0x30a0
    3290:	mov.d	x10, v1[1]
    3294:	ld1.s	{ v8 }[1], [x10]
    3298:	add.2d	v1, v9, v19
    329c:	shl.2d	v1, v1, #0x2
    32a0:	add.2d	v1, v18, v1
    32a4:	tbz	w15, #0x6, 0x30b0
    32a8:	fmov	x10, d1
    32ac:	ld1.s	{ v8 }[2], [x10]
    32b0:	tbnz	w15, #0x7, 0x30b4
    32b4:	b	0x30bc
    32b8:	fmov	x10, d12
    32bc:	ldr	s9, [x10]
    32c0:	and	w15, w15, #0xff
    32c4:	tbz	w15, #0x1, 0x30f8
    32c8:	mov.d	x10, v12[1]
    32cc:	ld1.s	{ v9 }[1], [x10]
    32d0:	add.2d	v1, v11, v20
    32d4:	shl.2d	v1, v1, #0x2
    32d8:	add.2d	v1, v18, v1
    32dc:	tbz	w15, #0x2, 0x3108
    32e0:	fmov	x10, d1
    32e4:	ld1.s	{ v9 }[2], [x10]
    32e8:	tbz	w15, #0x3, 0x310c
    32ec:	mov.d	x10, v1[1]
    32f0:	ld1.s	{ v9 }[3], [x10]
    32f4:	add.2d	v1, v11, v21
    32f8:	shl.2d	v1, v1, #0x2
    32fc:	add.2d	v1, v18, v1
    3300:	tbz	w15, #0x4, 0x311c
    3304:	fmov	x10, d1
    3308:	ld1.s	{ v10 }[0], [x10]
    330c:	tbz	w15, #0x5, 0x3120
    3310:	mov.d	x10, v1[1]
    3314:	ld1.s	{ v10 }[1], [x10]
    3318:	add.2d	v1, v11, v19
    331c:	shl.2d	v1, v1, #0x2
    3320:	add.2d	v1, v18, v1
    3324:	tbz	w15, #0x6, 0x3130
    3328:	fmov	x10, d1
    332c:	ld1.s	{ v10 }[2], [x10]
    3330:	tbnz	w15, #0x7, 0x3134
    3334:	b	0x313c
    3338:	fmov	x10, d14
    333c:	ldr	s11, [x10]
    3340:	and	w15, w15, #0xff
    3344:	tbz	w15, #0x1, 0x3178
    3348:	mov.d	x10, v14[1]
    334c:	ld1.s	{ v11 }[1], [x10]
    3350:	add.2d	v1, v13, v20
    3354:	shl.2d	v1, v1, #0x2
    3358:	add.2d	v1, v18, v1
    335c:	tbz	w15, #0x2, 0x3188
    3360:	fmov	x10, d1
    3364:	ld1.s	{ v11 }[2], [x10]
    3368:	tbz	w15, #0x3, 0x318c
    336c:	mov.d	x10, v1[1]
    3370:	ld1.s	{ v11 }[3], [x10]
    3374:	add.2d	v1, v13, v21
    3378:	shl.2d	v1, v1, #0x2
    337c:	add.2d	v1, v18, v1
    3380:	tbz	w15, #0x4, 0x319c
    3384:	fmov	x10, d1
    3388:	ld1.s	{ v12 }[0], [x10]
    338c:	tbz	w15, #0x5, 0x31a0
    3390:	mov.d	x10, v1[1]
    3394:	ld1.s	{ v12 }[1], [x10]
    3398:	add.2d	v1, v13, v19
    339c:	shl.2d	v1, v1, #0x2
    33a0:	add.2d	v1, v18, v1
    33a4:	tbz	w15, #0x6, 0x31b0
    33a8:	fmov	x10, d1
    33ac:	ld1.s	{ v12 }[2], [x10]
    33b0:	tbnz	w15, #0x7, 0x31b4
    33b4:	b	0x31bc
    33b8:	fmov	x10, d1
    33bc:	ldr	s13, [x10]
    33c0:	and	w15, w15, #0xff
    33c4:	tbz	w15, #0x1, 0x31f8
    33c8:	mov.d	x10, v1[1]
    33cc:	ld1.s	{ v13 }[1], [x10]
    33d0:	add.2d	v1, v15, v20
    33d4:	shl.2d	v1, v1, #0x2
    33d8:	add.2d	v1, v18, v1
    33dc:	tbz	w15, #0x2, 0x3208
    33e0:	fmov	x10, d1
    33e4:	ld1.s	{ v13 }[2], [x10]
    33e8:	tbz	w15, #0x3, 0x320c
    33ec:	mov.d	x10, v1[1]
    33f0:	ld1.s	{ v13 }[3], [x10]
    33f4:	add.2d	v1, v15, v21
    33f8:	shl.2d	v1, v1, #0x2
    33fc:	add.2d	v1, v18, v1
    3400:	tbz	w15, #0x4, 0x321c
    3404:	fmov	x10, d1
    3408:	ld1.s	{ v14 }[0], [x10]
    340c:	tbz	w15, #0x5, 0x3220
    3410:	mov.d	x10, v1[1]
    3414:	ld1.s	{ v14 }[1], [x10]
    3418:	add.2d	v1, v15, v19
    341c:	shl.2d	v1, v1, #0x2
    3420:	add.2d	v1, v18, v1
    3424:	tbz	w15, #0x6, 0x3230
    3428:	fmov	x10, d1
    342c:	ld1.s	{ v14 }[2], [x10]
    3430:	tbz	w15, #0x7, 0x2fd0
    3434:	mov.d	x10, v1[1]
    3438:	ld1.s	{ v14 }[3], [x10]
    343c:	b	0x2fd0
    3440:	mov	x14, #0x0
    3444:	add	x10, x25, x14, lsl #2
    3448:	ld1r.4s	{ v1 }, [x10]
    344c:	add	x10, x6, x14, lsl #5
    3450:	ldp	q18, q31, [x10]
    3454:	bit.16b	v31, v1, v7
    3458:	bif.16b	v1, v18, v16
    345c:	stp	q1, q31, [x10]
    3460:	add	x14, x14, #0x1
    3464:	cmp	x14, #0x100
    3468:	b.ne	0x3444
    346c:	mov	x14, #0x0
    3470:	fadd.4s	v1, v26, v29
    3474:	fadd.4s	v18, v23, v25
    3478:	fadd.4s	v18, v18, v28
    347c:	fadd.4s	v1, v1, v27
    3480:	fadd.4s	v1, v1, v30
    3484:	fadd.4s	v18, v18, v24
    3488:	fmul.4s	v18, v18, v6
    348c:	fmul.4s	v1, v1, v6
    3490:	fadd.4s	v1, v1, v5
    3494:	fadd.4s	v5, v18, v5
    3498:	fsqrt.4s	v6, v5
    349c:	fsqrt.4s	v1, v1
    34a0:	and.16b	v5, v16, v1
    34a4:	and.16b	v6, v7, v6
    34a8:	b	0x34b8
    34ac:	add	x14, x14, #0x1
    34b0:	cmp	x14, #0x100
    34b4:	b.eq	0x94
    34b8:	fmov	w15, s17
    34bc:	dup.2d	v18, x14
    34c0:	add.2d	v1, v18, v22
    34c4:	lsl	x10, x14, #5
    34c8:	add	x11, x9, x10
    34cc:	ldp	q23, q24, [x11]
    34d0:	and.16b	v23, v16, v23
    34d4:	fdiv.4s	v23, v23, v5
    34d8:	add	x10, x6, x10
    34dc:	ldp	q26, q25, [x10]
    34e0:	and.16b	v26, v16, v26
    34e4:	fmul.4s	v26, v23, v26
    34e8:	shl.2d	v1, v1, #0x2
    34ec:	dup.2d	v23, x24
    34f0:	add.2d	v1, v23, v1
    34f4:	tbnz	w15, #0x0, 0x3558
    34f8:	and	w15, w15, #0xff
    34fc:	tbnz	w15, #0x1, 0x3568
    3500:	add.2d	v1, v18, v20
    3504:	shl.2d	v1, v1, #0x2
    3508:	add.2d	v1, v23, v1
    350c:	tbnz	w15, #0x2, 0x3580
    3510:	tbz	w15, #0x3, 0x351c
    3514:	mov.d	x10, v1[1]
    3518:	st1.s	{ v26 }[3], [x10]
    351c:	add.2d	v1, v18, v21
    3520:	and.16b	v24, v7, v24
    3524:	fdiv.4s	v24, v24, v6
    3528:	and.16b	v25, v7, v25
    352c:	fmul.4s	v24, v24, v25
    3530:	shl.2d	v1, v1, #0x2
    3534:	add.2d	v1, v23, v1
    3538:	tbnz	w15, #0x4, 0x3590
    353c:	tbnz	w15, #0x5, 0x359c
    3540:	add.2d	v1, v18, v19
    3544:	shl.2d	v1, v1, #0x2
    3548:	add.2d	v1, v23, v1
    354c:	tbnz	w15, #0x6, 0x35b4
    3550:	tbz	w15, #0x7, 0x34ac
    3554:	b	0x35c0
    3558:	fmov	x10, d1
    355c:	str	s26, [x10]
    3560:	and	w15, w15, #0xff
    3564:	tbz	w15, #0x1, 0x3500
    3568:	mov.d	x10, v1[1]
    356c:	st1.s	{ v26 }[1], [x10]
    3570:	add.2d	v1, v18, v20
    3574:	shl.2d	v1, v1, #0x2
    3578:	add.2d	v1, v23, v1
    357c:	tbz	w15, #0x2, 0x3510
    3580:	fmov	x10, d1
    3584:	st1.s	{ v26 }[2], [x10]
    3588:	tbnz	w15, #0x3, 0x3514
    358c:	b	0x351c
    3590:	fmov	x10, d1
    3594:	str	s24, [x10]
    3598:	tbz	w15, #0x5, 0x3540
    359c:	mov.d	x10, v1[1]
    35a0:	st1.s	{ v24 }[1], [x10]
    35a4:	add.2d	v1, v18, v19
    35a8:	shl.2d	v1, v1, #0x2
    35ac:	add.2d	v1, v23, v1
    35b0:	tbz	w15, #0x6, 0x3550
    35b4:	fmov	x10, d1
    35b8:	st1.s	{ v24 }[2], [x10]
    35bc:	tbz	w15, #0x7, 0x34ac
    35c0:	mov.d	x10, v1[1]
    35c4:	st1.s	{ v24 }[3], [x10]
    35c8:	b	0x34ac
    35cc:	fmov	x10, d22
    35d0:	ldr	s23, [x10]
    35d4:	and	w14, w14, #0xff
    35d8:	tbz	w14, #0x1, 0x2e08
    35dc:	mov.d	x10, v22[1]
    35e0:	ld1.s	{ v23 }[1], [x10]
    35e4:	ushll2.2d	v22, v19, #0xa
    35e8:	add.2d	v1, v18, v22
    35ec:	tbz	w14, #0x2, 0x2e14
    35f0:	fmov	x10, d1
    35f4:	ld1.s	{ v23 }[2], [x10]
    35f8:	tbz	w14, #0x3, 0x2e18
    35fc:	mov.d	x10, v1[1]
    3600:	ld1.s	{ v23 }[3], [x10]
    3604:	orr.16b	v1, v20, v0
    3608:	and.16b	v20, v7, v1
    360c:	ushll.2d	v26, v20, #0xa
    3610:	add.2d	v1, v18, v26
    3614:	tbz	w14, #0x4, 0x2e2c
    3618:	fmov	x10, d1
    361c:	ld1.s	{ v24 }[0], [x10]
    3620:	tbz	w14, #0x5, 0x2e30
    3624:	mov.d	x10, v1[1]
    3628:	ld1.s	{ v24 }[1], [x10]
    362c:	ushll2.2d	v27, v20, #0xa
    3630:	add.2d	v1, v18, v27
    3634:	tbz	w14, #0x6, 0x2e3c
    3638:	fmov	x10, d1
    363c:	ld1.s	{ v24 }[2], [x10]
    3640:	tbnz	w14, #0x7, 0x2e40
    3644:	b	0x2e48
    3648:	fmov	x10, d30
    364c:	ldr	s25, [x10]
    3650:	and	w14, w14, #0xff
    3654:	tbz	w14, #0x1, 0x2e7c
    3658:	mov.d	x10, v30[1]
    365c:	ld1.s	{ v25 }[1], [x10]
    3660:	add.2d	v1, v29, v22
    3664:	tbz	w14, #0x2, 0x2e84
    3668:	fmov	x10, d1
    366c:	ld1.s	{ v25 }[2], [x10]
    3670:	tbz	w14, #0x3, 0x2e88
    3674:	mov.d	x10, v1[1]
    3678:	ld1.s	{ v25 }[3], [x10]
    367c:	add.2d	v1, v29, v26
    3680:	tbz	w14, #0x4, 0x2e90
    3684:	fmov	x10, d1
    3688:	ld1.s	{ v28 }[0], [x10]
    368c:	tbz	w14, #0x5, 0x2e94
    3690:	mov.d	x10, v1[1]
    3694:	ld1.s	{ v28 }[1], [x10]
    3698:	add.2d	v1, v29, v27
    369c:	tbz	w14, #0x6, 0x2e9c
    36a0:	fmov	x10, d1
    36a4:	ld1.s	{ v28 }[2], [x10]
    36a8:	tbnz	w14, #0x7, 0x2ea0
    36ac:	b	0x2ea8
    36b0:	fmov	x10, d8
    36b4:	ldr	s29, [x10]
    36b8:	and	w14, w14, #0xff
    36bc:	tbz	w14, #0x1, 0x2ed0
    36c0:	mov.d	x10, v8[1]
    36c4:	ld1.s	{ v29 }[1], [x10]
    36c8:	add.2d	v1, v31, v22
    36cc:	tbz	w14, #0x2, 0x2ed8
    36d0:	fmov	x10, d1
    36d4:	ld1.s	{ v29 }[2], [x10]
    36d8:	tbz	w14, #0x3, 0x2edc
    36dc:	mov.d	x10, v1[1]
    36e0:	ld1.s	{ v29 }[3], [x10]
    36e4:	add.2d	v1, v31, v26
    36e8:	tbz	w14, #0x4, 0x2ee4
    36ec:	fmov	x10, d1
    36f0:	ld1.s	{ v30 }[0], [x10]
    36f4:	tbz	w14, #0x5, 0x2ee8
    36f8:	mov.d	x10, v1[1]
    36fc:	ld1.s	{ v30 }[1], [x10]
    3700:	add.2d	v1, v31, v27
    3704:	tbz	w14, #0x6, 0x2ef0
    3708:	fmov	x10, d1
    370c:	ld1.s	{ v30 }[2], [x10]
    3710:	tbnz	w14, #0x7, 0x2ef4
    3714:	b	0x2efc
    3718:	fmov	x10, d21
    371c:	ldr	s31, [x10]
    3720:	and	w14, w14, #0xff
    3724:	tbz	w14, #0x1, 0x2f24
    3728:	mov.d	x10, v21[1]
    372c:	ld1.s	{ v31 }[1], [x10]
    3730:	add.2d	v1, v9, v22
    3734:	tbz	w14, #0x2, 0x2f2c
    3738:	fmov	x10, d1
    373c:	ld1.s	{ v31 }[2], [x10]
    3740:	tbz	w14, #0x3, 0x2f30
    3744:	mov.d	x10, v1[1]
    3748:	ld1.s	{ v31 }[3], [x10]
    374c:	add.2d	v1, v9, v26
    3750:	tbz	w14, #0x4, 0x2f38
    3754:	fmov	x10, d1
    3758:	ld1.s	{ v8 }[0], [x10]
    375c:	tbz	w14, #0x5, 0x2f3c
    3760:	mov.d	x10, v1[1]
    3764:	ld1.s	{ v8 }[1], [x10]
    3768:	add.2d	v1, v9, v27
    376c:	tbz	w14, #0x6, 0x2f44
    3770:	fmov	x10, d1
    3774:	ld1.s	{ v8 }[2], [x10]
    3778:	tbnz	w14, #0x7, 0x2f48
    377c:	b	0x2f50
    3780:	add	sp, sp, #0x4, lsl #12
    3784:	add	sp, sp, #0x50
    3788:	ldp	x29, x30, [sp, #0x90]
    378c:	ldp	x20, x19, [sp, #0x80]
    3790:	ldp	x22, x21, [sp, #0x70]
    3794:	ldp	x24, x23, [sp, #0x60]
    3798:	ldp	x26, x25, [sp, #0x50]
    379c:	ldp	x28, x27, [sp, #0x40]
    37a0:	ldp	d9, d8, [sp, #0x30]
    37a4:	ldp	d11, d10, [sp, #0x20]
    37a8:	ldp	d13, d12, [sp, #0x10]
    37ac:	ldp	d15, d14, [sp], #0xa0
    37b0:	ret

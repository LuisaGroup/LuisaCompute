/tmp/luisa-full-packet.UEezjO/capture/rmsnorm-64x256-r0-l8-f0-p0/object/tile_xir_w8_63767_1788856226610924_0.o:
(__TEXT,__text) section
_llm_rows:
       0:	stp	x28, x27, [sp, #-0x10]!
       4:	sub	sp, sp, #0x980
       8:	dup.4s	v1, w2
       c:	adrp	x8, lCPI0_1@PAGE
      10:	ldr	q3, [x8, lCPI0_1@PAGEOFF]
      14:	adrp	x8, lCPI0_2@PAGE
      18:	ldr	q4, [x8, lCPI0_2@PAGEOFF]
      1c:	cmhi.4s	v0, v1, v4
      20:	cmhi.4s	v1, v1, v3
      24:	uzp1.8h	v5, v1, v0
      28:	umaxv.8h	h2, v5
      2c:	fmov	w8, s2
      30:	tbz	w8, #0x0, 0x690
      34:	mov	x13, #0x0
      38:	add	x11, sp, #0x90
      3c:	ldr	x12, [x0, #0x10]
      40:	ldr	x8, [x0, #0x30]
      44:	adrp	x9, lCPI0_0@PAGE
      48:	ldr	q2, [x9, lCPI0_0@PAGEOFF]
      4c:	and.16b	v2, v5, v2
      50:	addv.8h	h2, v2
      54:	fmov	w9, s2
      58:	and	w10, w9, #0xff
      5c:	ldr	x14, [x0]
      60:	ldr	w9, [x1]
      64:	ldr	w15, [x1, #0x24]
      68:	add	w9, w15, w9, lsl #9
      6c:	lsr	w9, w9, #3
      70:	fmov	s6, w9
      74:	and.16b	v6, v1, v6
      78:	fmov	w9, s6
      7c:	ubfiz	x9, x9, #10, #32
      80:	add	x14, x14, x9
      84:	fmov	w15, s2
      88:	add	x16, sp, #0x580
      8c:	b	0xb0
      90:	add	x17, x16, x13
      94:	ldp	q16, q17, [x17]
      98:	bif.16b	v7, v17, v0
      9c:	bif.16b	v6, v16, v1
      a0:	stp	q6, q7, [x17]
      a4:	add	x13, x13, #0x20
      a8:	cmp	x13, #0x400
      ac:	b.eq	0x144
      b0:	add	x17, x14, x13
      b4:	movi.2d	v6, #0000000000000000
      b8:	movi.2d	v7, #0000000000000000
      bc:	tbnz	w15, #0x0, 0xe4
      c0:	and	w0, w15, #0xff
      c4:	tbnz	w0, #0x1, 0xf0
      c8:	tbnz	w0, #0x2, 0xfc
      cc:	tbnz	w0, #0x3, 0x108
      d0:	tbnz	w0, #0x4, 0x114
      d4:	tbnz	w0, #0x5, 0x120
      d8:	tbnz	w0, #0x6, 0x12c
      dc:	tbz	w0, #0x7, 0x90
      e0:	b	0x138
      e4:	ldr	s6, [x17]
      e8:	and	w0, w15, #0xff
      ec:	tbz	w0, #0x1, 0xc8
      f0:	add	x1, x17, #0x4
      f4:	ld1.s	{ v6 }[1], [x1]
      f8:	tbz	w0, #0x2, 0xcc
      fc:	add	x1, x17, #0x8
     100:	ld1.s	{ v6 }[2], [x1]
     104:	tbz	w0, #0x3, 0xd0
     108:	add	x1, x17, #0xc
     10c:	ld1.s	{ v6 }[3], [x1]
     110:	tbz	w0, #0x4, 0xd4
     114:	add	x1, x17, #0x10
     118:	ld1.s	{ v7 }[0], [x1]
     11c:	tbz	w0, #0x5, 0xd8
     120:	add	x1, x17, #0x14
     124:	ld1.s	{ v7 }[1], [x1]
     128:	tbz	w0, #0x6, 0xdc
     12c:	add	x1, x17, #0x18
     130:	ld1.s	{ v7 }[2], [x1]
     134:	tbz	w0, #0x7, 0x90
     138:	add	x17, x17, #0x1c
     13c:	ld1.s	{ v7 }[3], [x17]
     140:	b	0x90
     144:	ldr	q6, [x11, #0x500]
     148:	ldr	q7, [x11, #0x4f0]
     14c:	fmul.4s	v16, v7, v7
     150:	fmul.4s	v6, v6, v6
     154:	ldr	q7, [x11, #0x520]
     158:	ldr	q17, [x11, #0x510]
     15c:	fmul.4s	v17, v17, v17
     160:	fmul.4s	v18, v7, v7
     164:	ldr	q7, [x11, #0x540]
     168:	ldr	q19, [x11, #0x530]
     16c:	fmul.4s	v21, v19, v19
     170:	fmul.4s	v22, v7, v7
     174:	ldr	q7, [x11, #0x560]
     178:	ldr	q19, [x11, #0x550]
     17c:	fmul.4s	v23, v19, v19
     180:	fmul.4s	v24, v7, v7
     184:	and.16b	v7, v0, v6
     188:	and.16b	v6, v1, v16
     18c:	and.16b	v20, v0, v18
     190:	and.16b	v19, v1, v17
     194:	and.16b	v16, v0, v22
     198:	and.16b	v21, v1, v21
     19c:	and.16b	v18, v0, v24
     1a0:	and.16b	v17, v1, v23
     1a4:	add	x13, sp, #0x580
     1a8:	add	x13, x13, #0xe0
     1ac:	mov	w14, #0x4
     1b0:	ldp	q23, q22, [x13, #-0x60]
     1b4:	and.16b	v23, v1, v23
     1b8:	and.16b	v22, v0, v22
     1bc:	fmul.4s	v22, v22, v22
     1c0:	fmul.4s	v23, v23, v23
     1c4:	fadd.4s	v23, v6, v23
     1c8:	fadd.4s	v22, v7, v22
     1cc:	ldp	q25, q24, [x13, #-0x40]
     1d0:	and.16b	v25, v1, v25
     1d4:	and.16b	v24, v0, v24
     1d8:	fmul.4s	v24, v24, v24
     1dc:	fmul.4s	v25, v25, v25
     1e0:	fadd.4s	v25, v19, v25
     1e4:	fadd.4s	v24, v20, v24
     1e8:	ldp	q27, q26, [x13, #-0x20]
     1ec:	and.16b	v27, v1, v27
     1f0:	and.16b	v26, v0, v26
     1f4:	fmul.4s	v26, v26, v26
     1f8:	fmul.4s	v27, v27, v27
     1fc:	fadd.4s	v27, v21, v27
     200:	fadd.4s	v26, v16, v26
     204:	ldp	q29, q28, [x13], #0x80
     208:	and.16b	v29, v1, v29
     20c:	and.16b	v28, v0, v28
     210:	fmul.4s	v28, v28, v28
     214:	fmul.4s	v29, v29, v29
     218:	fadd.4s	v29, v17, v29
     21c:	fadd.4s	v28, v18, v28
     220:	bit.16b	v7, v22, v0
     224:	bit.16b	v6, v23, v1
     228:	bit.16b	v20, v24, v0
     22c:	bit.16b	v19, v25, v1
     230:	bit.16b	v16, v26, v0
     234:	bit.16b	v21, v27, v1
     238:	bit.16b	v18, v28, v0
     23c:	bit.16b	v17, v29, v1
     240:	cmp	x14, #0x1c
     244:	add	x14, x14, #0x4
     248:	b.lo	0x1b0
     24c:	mov	x13, #0x0
     250:	fmov	w14, s2
     254:	add	x15, sp, #0x180
     258:	b	0x27c
     25c:	add	x16, x15, x13
     260:	ldp	q24, q25, [x16]
     264:	bif.16b	v23, v25, v0
     268:	bif.16b	v22, v24, v1
     26c:	stp	q22, q23, [x16]
     270:	add	x13, x13, #0x20
     274:	cmp	x13, #0x400
     278:	b.eq	0x310
     27c:	add	x16, x12, x13
     280:	movi.2d	v22, #0000000000000000
     284:	movi.2d	v23, #0000000000000000
     288:	tbnz	w14, #0x0, 0x2b0
     28c:	and	w17, w14, #0xff
     290:	tbnz	w17, #0x1, 0x2bc
     294:	tbnz	w17, #0x2, 0x2c8
     298:	tbnz	w17, #0x3, 0x2d4
     29c:	tbnz	w17, #0x4, 0x2e0
     2a0:	tbnz	w17, #0x5, 0x2ec
     2a4:	tbnz	w17, #0x6, 0x2f8
     2a8:	tbz	w17, #0x7, 0x25c
     2ac:	b	0x304
     2b0:	ldr	s22, [x16]
     2b4:	and	w17, w14, #0xff
     2b8:	tbz	w17, #0x1, 0x294
     2bc:	add	x0, x16, #0x4
     2c0:	ld1.s	{ v22 }[1], [x0]
     2c4:	tbz	w17, #0x2, 0x298
     2c8:	add	x0, x16, #0x8
     2cc:	ld1.s	{ v22 }[2], [x0]
     2d0:	tbz	w17, #0x3, 0x29c
     2d4:	add	x0, x16, #0xc
     2d8:	ld1.s	{ v22 }[3], [x0]
     2dc:	tbz	w17, #0x4, 0x2a0
     2e0:	add	x0, x16, #0x10
     2e4:	ld1.s	{ v23 }[0], [x0]
     2e8:	tbz	w17, #0x5, 0x2a4
     2ec:	add	x0, x16, #0x14
     2f0:	ld1.s	{ v23 }[1], [x0]
     2f4:	tbz	w17, #0x6, 0x2a8
     2f8:	add	x0, x16, #0x18
     2fc:	ld1.s	{ v23 }[2], [x0]
     300:	tbz	w17, #0x7, 0x25c
     304:	add	x16, x16, #0x1c
     308:	ld1.s	{ v23 }[3], [x16]
     30c:	b	0x25c
     310:	mov	x12, #0x0
     314:	xtn.8b	v22, v5
     318:	fadd.4s	v5, v7, v20
     31c:	fadd.4s	v6, v6, v19
     320:	fadd.4s	v6, v6, v21
     324:	fadd.4s	v5, v5, v16
     328:	fadd.4s	v5, v5, v18
     32c:	fadd.4s	v6, v6, v17
     330:	and.16b	v3, v1, v3
     334:	and.16b	v4, v0, v4
     338:	movi.4s	v7, #0x1
     33c:	eor.16b	v16, v4, v7
     340:	eor.16b	v19, v3, v7
     344:	umov.b	w14, v22[0]
     348:	str	q6, [x11, #0xc0]
     34c:	ldr	s7, [x11, #0xc4]
     350:	umov.b	w13, v22[1]
     354:	ands	w15, w14, #0x1
     358:	tst	w15, w13
     35c:	movi	d3, #0000000000000000
     360:	fcsel	s7, s7, s3, ne
     364:	mov.s	w16, v19[1]
     368:	add	x17, sp, #0x8
     36c:	add	x0, sp, #0x8
     370:	bfxil	x0, x16, #0, #3
     374:	str	d22, [sp, #0x8]
     378:	ldrb	w0, [x0]
     37c:	add	x1, sp, #0x130
     380:	orr	x16, x1, x16, lsl #2
     384:	stp	q6, q5, [x11, #0xa0]
     388:	ldr	s17, [x16]
     38c:	ands	w16, w13, #0x1
     390:	tst	w16, w0
     394:	mov.s	w16, v19[2]
     398:	fcsel	s17, s17, s3, ne
     39c:	add	x0, sp, #0x8
     3a0:	bfxil	x0, x16, #0, #3
     3a4:	ldrb	w0, [x0]
     3a8:	add	x1, sp, #0x110
     3ac:	orr	x1, x1, x16, lsl #2
     3b0:	umov.b	w16, v22[2]
     3b4:	stp	q6, q5, [x11, #0x80]
     3b8:	ldr	s18, [x1]
     3bc:	ands	w1, w16, #0x1
     3c0:	tst	w1, w0
     3c4:	fcsel	s18, s18, s3, ne
     3c8:	mov.s	w0, v19[3]
     3cc:	add	x1, sp, #0x8
     3d0:	bfxil	x1, x0, #0, #3
     3d4:	ldrb	w1, [x1]
     3d8:	add	x2, sp, #0xf0
     3dc:	orr	x2, x2, x0, lsl #2
     3e0:	umov.b	w0, v22[3]
     3e4:	stp	q6, q5, [x11, #0x60]
     3e8:	ldr	s19, [x2]
     3ec:	ands	w2, w0, #0x1
     3f0:	tst	w2, w1
     3f4:	fcsel	s19, s19, s3, ne
     3f8:	fmov	w2, s16
     3fc:	add	x1, sp, #0x8
     400:	bfxil	x1, x2, #0, #3
     404:	ldrb	w3, [x1]
     408:	umov.b	w1, v22[4]
     40c:	and	w3, w1, w3
     410:	stp	q6, q5, [x11, #0x40]
     414:	add	x4, sp, #0xd0
     418:	ldr	s20, [x4, w2, uxtw #2]
     41c:	tst	w3, #0x1
     420:	mov.s	w3, v16[1]
     424:	add	x4, sp, #0x8
     428:	bfxil	x4, x3, #0, #3
     42c:	umov.b	w2, v22[5]
     430:	ldrb	w4, [x4]
     434:	stp	q6, q5, [x11, #0x20]
     438:	add	x5, sp, #0xb0
     43c:	ldr	s21, [x5, w3, uxtw #2]
     440:	fcsel	s20, s20, s3, ne
     444:	ands	w3, w2, #0x1
     448:	tst	w3, w4
     44c:	fcsel	s21, s21, s3, ne
     450:	mov.s	w4, v16[2]
     454:	add	x3, sp, #0x8
     458:	bfxil	x3, x4, #0, #3
     45c:	ldrb	w5, [x3]
     460:	umov.b	w3, v22[6]
     464:	stp	q6, q5, [x11]
     468:	add	x11, sp, #0x90
     46c:	ldr	s23, [x11, w4, uxtw #2]
     470:	ands	w11, w3, #0x1
     474:	tst	w11, w5
     478:	mov.s	w11, v16[3]
     47c:	add	x4, sp, #0x8
     480:	bfxil	x4, x11, #0, #3
     484:	ldrb	w4, [x4]
     488:	stp	q6, q5, [sp, #0x70]
     48c:	add	x5, sp, #0x70
     490:	ldr	s16, [x5, w11, uxtw #2]
     494:	umov.b	w11, v22[7]
     498:	fcsel	s22, s23, s3, ne
     49c:	ands	w5, w11, #0x1
     4a0:	tst	w5, w4
     4a4:	fcsel	s16, s16, s3, ne
     4a8:	mov.s	v7[1], v17[0]
     4ac:	mov.s	v7[2], v18[0]
     4b0:	mov.s	v7[3], v19[0]
     4b4:	mov.s	v20[1], v21[0]
     4b8:	mov.s	v20[2], v22[0]
     4bc:	mov.s	v20[3], v16[0]
     4c0:	fadd.4s	v5, v5, v20
     4c4:	fadd.4s	v6, v6, v7
     4c8:	movi.4s	v7, #0x2
     4cc:	eor.16b	v4, v4, v7
     4d0:	str	q6, [sp, #0x50]
     4d4:	ldr	s7, [sp, #0x58]
     4d8:	tst	w15, w16
     4dc:	fcsel	s7, s7, s3, ne
     4e0:	fmov	w4, s4
     4e4:	bfxil	x17, x4, #0, #3
     4e8:	ldrb	w17, [x17]
     4ec:	and	w17, w1, w17
     4f0:	stp	q6, q5, [sp, #0x30]
     4f4:	add	x5, sp, #0x30
     4f8:	ldr	s4, [x5, w4, uxtw #2]
     4fc:	tst	w17, #0x1
     500:	fcsel	s4, s4, s3, ne
     504:	fadd.4s	v4, v5, v4
     508:	tst	w15, w1
     50c:	fcsel	s4, s4, s3, ne
     510:	ands	w14, w14, #0x1
     514:	fadd.4s	v5, v6, v7
     518:	fadd	s4, s5, s4
     51c:	fcsel	s5, s4, s3, ne
     520:	tst	w13, #0x1
     524:	fcsel	s6, s5, s3, ne
     528:	tst	w16, #0x1
     52c:	fcsel	s7, s5, s3, ne
     530:	tst	w0, #0x1
     534:	fcsel	s16, s5, s3, ne
     538:	tst	w14, w1
     53c:	fcsel	s4, s4, s3, ne
     540:	tst	w2, #0x1
     544:	fcsel	s17, s5, s3, ne
     548:	tst	w3, #0x1
     54c:	fcsel	s18, s5, s3, ne
     550:	tst	w11, #0x1
     554:	fcsel	s19, s5, s3, ne
     558:	mov.s	v5[1], v6[0]
     55c:	mov.s	v5[2], v7[0]
     560:	mov.s	v5[3], v16[0]
     564:	mov.s	v4[1], v17[0]
     568:	mov.s	v4[2], v18[0]
     56c:	mov.s	v4[3], v19[0]
     570:	rbit	w10, w10
     574:	clz	w10, w10
     578:	stp	q5, q4, [sp, #0x10]
     57c:	and	x10, x10, #0x7
     580:	add	x11, sp, #0x10
     584:	ldr	s4, [x11, x10, lsl #2]
     588:	fadd	s3, s4, s3
     58c:	mov	w10, #0x3b800000
     590:	fmov	s4, w10
     594:	fmul	s3, s3, s4
     598:	mov	w10, #0xc5ac
     59c:	movk	w10, #0x3727, lsl #16
     5a0:	fmov	s4, w10
     5a4:	fadd	s3, s3, s4
     5a8:	fsqrt	s3, s3
     5ac:	dup.4s	v3, v3[0]
     5b0:	add	x8, x8, x9
     5b4:	add	x9, sp, #0x580
     5b8:	add	x10, sp, #0x180
     5bc:	b	0x5cc
     5c0:	add	x12, x12, #0x20
     5c4:	cmp	x12, #0x400
     5c8:	b.eq	0x690
     5cc:	fmov	w13, s2
     5d0:	add	x14, x9, x12
     5d4:	ldr	q4, [x14]
     5d8:	and.16b	v4, v1, v4
     5dc:	fdiv.4s	v4, v4, v3
     5e0:	add	x15, x10, x12
     5e4:	ldr	q5, [x15]
     5e8:	and.16b	v5, v1, v5
     5ec:	fmul.4s	v4, v4, v5
     5f0:	add	x11, x8, x12
     5f4:	tbnz	w13, #0x0, 0x63c
     5f8:	and	w13, w13, #0xff
     5fc:	tbnz	w13, #0x1, 0x648
     600:	tbnz	w13, #0x2, 0x654
     604:	tbz	w13, #0x3, 0x610
     608:	add	x16, x11, #0xc
     60c:	st1.s	{ v4 }[3], [x16]
     610:	ldr	q4, [x14, #0x10]
     614:	and.16b	v4, v0, v4
     618:	fdiv.4s	v4, v4, v3
     61c:	ldr	q5, [x15, #0x10]
     620:	and.16b	v5, v0, v5
     624:	fmul.4s	v4, v4, v5
     628:	tbnz	w13, #0x4, 0x664
     62c:	tbnz	w13, #0x5, 0x66c
     630:	tbnz	w13, #0x6, 0x678
     634:	tbz	w13, #0x7, 0x5c0
     638:	b	0x684
     63c:	str	s4, [x11]
     640:	and	w13, w13, #0xff
     644:	tbz	w13, #0x1, 0x600
     648:	add	x16, x11, #0x4
     64c:	st1.s	{ v4 }[1], [x16]
     650:	tbz	w13, #0x2, 0x604
     654:	add	x16, x11, #0x8
     658:	st1.s	{ v4 }[2], [x16]
     65c:	tbnz	w13, #0x3, 0x608
     660:	b	0x610
     664:	str	s4, [x11, #0x10]
     668:	tbz	w13, #0x5, 0x630
     66c:	add	x14, x11, #0x14
     670:	st1.s	{ v4 }[1], [x14]
     674:	tbz	w13, #0x6, 0x634
     678:	add	x14, x11, #0x18
     67c:	st1.s	{ v4 }[2], [x14]
     680:	tbz	w13, #0x7, 0x5c0
     684:	add	x11, x11, #0x1c
     688:	st1.s	{ v4 }[3], [x11]
     68c:	b	0x5c0
     690:	add	sp, sp, #0x980
     694:	ldp	x28, x27, [sp], #0x10
     698:	ret
_llm_rows.packet_batch.blocks:
     69c:	cbz	w3, 0x7f4
     6a0:	sub	sp, sp, #0x70
     6a4:	stp	x28, x27, [sp, #0x10]
     6a8:	stp	x26, x25, [sp, #0x20]
     6ac:	stp	x24, x23, [sp, #0x30]
     6b0:	stp	x22, x21, [sp, #0x40]
     6b4:	stp	x20, x19, [sp, #0x50]
     6b8:	stp	x29, x30, [sp, #0x60]
     6bc:	mov	x19, x3
     6c0:	mov	x20, x2
     6c4:	mov	x21, x0
     6c8:	mov	w22, #0x0
     6cc:	ldp	w24, w8, [x2, #0x2c]
     6d0:	stp	w3, w8, [sp, #0x8]
     6d4:	ldp	w25, w26, [x2]
     6d8:	ldp	w28, w27, [x2, #0x8]
     6dc:	str	w24, [sp, #0x4]
     6e0:	b	0x728
     6e4:	mov	w8, #0x1f8
     6e8:	str	w8, [x20, #0x24]
     6ec:	ldp	w24, w19, [sp, #0x4]
     6f0:	add	w8, w25, #0x1
     6f4:	cmp	w8, w24
     6f8:	cset	w8, eq
     6fc:	csinc	w25, wzr, w25, eq
     700:	cinc	w9, w26, eq
     704:	ldr	w10, [sp, #0xc]
     708:	cmp	w9, w10
     70c:	cset	w10, eq
     710:	ands	w8, w8, w10
     714:	csel	w26, wzr, w9, ne
     718:	add	w28, w28, w8
     71c:	add	w22, w22, #0x1
     720:	cmp	w22, w19
     724:	b.eq	0x7d8
     728:	ubfiz	x8, x25, #9, #32
     72c:	cmp	x8, x27
     730:	csel	x9, x8, xzr, ls
     734:	subs	x10, x27, x9
     738:	cmp	x10, #0x200
     73c:	mov	w11, #0x200
     740:	csel	x10, x10, x11, lo
     744:	cmp	x27, x9
     748:	stp	w25, w26, [x20]
     74c:	str	w28, [x20, #0x8]
     750:	ccmp	x8, x27, #0x2, hi
     754:	csel	x23, x10, xzr, ls
     758:	cmp	x23, #0x200
     75c:	b.lo	0x788
     760:	mov	w23, #0x0
     764:	str	w23, [x20, #0x24]
     768:	mov	x0, x21
     76c:	mov	x1, x20
     770:	mov	w2, #0x8
     774:	bl	_llm_rows
     778:	add	w23, w23, #0x8
     77c:	cmp	w23, #0x200
     780:	b.ne	0x764
     784:	b	0x6f0
     788:	lsr	x8, x23, #3
     78c:	lsl	w24, w8, #3
     790:	cmp	x23, #0x8
     794:	b.lo	0x7bc
     798:	mov	w19, #0x0
     79c:	str	w19, [x20, #0x24]
     7a0:	mov	x0, x21
     7a4:	mov	x1, x20
     7a8:	mov	w2, #0x8
     7ac:	bl	_llm_rows
     7b0:	add	w19, w19, #0x8
     7b4:	cmp	w24, w19
     7b8:	b.ne	0x79c
     7bc:	and	w2, w23, #0x7
     7c0:	cbz	w2, 0x6e4
     7c4:	str	w24, [x20, #0x24]
     7c8:	mov	x0, x21
     7cc:	mov	x1, x20
     7d0:	bl	_llm_rows
     7d4:	b	0x6e4
     7d8:	ldp	x29, x30, [sp, #0x60]
     7dc:	ldp	x20, x19, [sp, #0x50]
     7e0:	ldp	x22, x21, [sp, #0x40]
     7e4:	ldp	x24, x23, [sp, #0x30]
     7e8:	ldp	x26, x25, [sp, #0x20]
     7ec:	ldp	x28, x27, [sp, #0x10]
     7f0:	add	sp, sp, #0x70
     7f4:	ret

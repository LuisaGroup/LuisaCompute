/tmp/luisa-full-packet.UEezjO/capture/rmsnorm-1024x4096-r0-l1-f1-p1/object/tile_xir_w8_63774_1788856229507648_0.o:
(__TEXT,__text) section
_llm_rows.packet_batch.blocks:
       0:	sub	sp, sp, #0xc0
       4:	stp	d15, d14, [sp, #0x20]
       8:	stp	d13, d12, [sp, #0x30]
       c:	stp	d11, d10, [sp, #0x40]
      10:	stp	d9, d8, [sp, #0x50]
      14:	stp	x28, x27, [sp, #0x60]
      18:	stp	x26, x25, [sp, #0x70]
      1c:	stp	x24, x23, [sp, #0x80]
      20:	stp	x22, x21, [sp, #0x90]
      24:	stp	x20, x19, [sp, #0xa0]
      28:	stp	x29, x30, [sp, #0xb0]
      2c:	str	w3, [sp, #0x10]
      30:	cbz	w3, 0x1568
      34:	mov	w8, #0x0
      38:	ldp	w10, w9, [x2, #0x2c]
      3c:	stp	w9, w10, [sp, #0x8]
      40:	ldp	w7, w19, [x2]
      44:	ldp	w20, w11, [x2, #0x8]
      48:	str	x2, [sp]
      4c:	adrp	x13, lCPI0_0@PAGE
      50:	ldr	q0, [x13, lCPI0_0@PAGEOFF]
      54:	mov	w13, #0xc
      58:	mov	w14, #0x4
      5c:	dup.2d	v1, x13
      60:	mov	w15, #0x8
      64:	adrp	x16, lCPI0_1@PAGE
      68:	ldr	q2, [x16, lCPI0_1@PAGEOFF]
      6c:	dup.2d	v3, x15
      70:	b	0xb0
      74:	add	w9, w6, #0x1
      78:	ldp	w12, w10, [sp, #0x8]
      7c:	cmp	w9, w10
      80:	cset	w9, eq
      84:	csinc	w7, wzr, w6, eq
      88:	cinc	w10, w5, eq
      8c:	cmp	w10, w12
      90:	cset	w12, eq
      94:	ands	w9, w9, w12
      98:	csel	w19, wzr, w10, ne
      9c:	add	w20, w2, w9
      a0:	add	w8, w8, #0x1
      a4:	ldr	w9, [sp, #0x10]
      a8:	cmp	w8, w9
      ac:	b.eq	0x1554
      b0:	mov	x2, x20
      b4:	mov	x5, x19
      b8:	mov	x6, x7
      bc:	ubfiz	x7, x7, #10, #32
      c0:	cmp	x7, x11
      c4:	csel	x19, x7, xzr, ls
      c8:	subs	x20, x11, x19
      cc:	cmp	x20, #0x400
      d0:	mov	w9, #0x400
      d4:	csel	x20, x20, x9, lo
      d8:	cmp	x11, x19
      dc:	ccmp	x7, x11, #0x2, hi
      e0:	csel	x19, x20, xzr, ls
      e4:	mov	w9, #0x39800000
      e8:	dup.4s	v5, w9
      ec:	mov	w9, #0xc5ac
      f0:	movk	w9, #0x3727, lsl #16
      f4:	dup.4s	v4, w9
      f8:	cmp	x19, #0x400
      fc:	b.lo	0x614
     100:	mov	w7, #0x0
     104:	ldr	x9, [sp]
     108:	ldr	x19, [x9, #0x88]
     10c:	ldr	x25, [x0]
     110:	ldr	x20, [x0, #0x10]
     114:	ldr	x21, [x0, #0x30]
     118:	lsl	w22, w6, #10
     11c:	add	x23, x19, #0x20, lsl #12
     120:	add	x24, x19, #0xe0
     124:	dup.2d	v6, x25
     128:	add	w25, w22, w7, lsl #3
     12c:	dup.4s	v7, w25
     130:	orr.16b	v17, v7, v0
     134:	orr.16b	v18, v7, v2
     138:	ushll2.2d	v7, v17, #0xc
     13c:	ushll.2d	v20, v18, #0xe
     140:	ushll2.2d	v22, v18, #0xe
     144:	ushll.2d	v19, v17, #0xe
     148:	ushll2.2d	v16, v17, #0xe
     14c:	add.2d	v16, v6, v16
     150:	add.2d	v19, v6, v19
     154:	add.2d	v21, v6, v20
     158:	mov.d	x25, v21[1]
     15c:	add.2d	v20, v6, v22
     160:	dup.2d	v24, x14
     164:	add.2d	v22, v21, v24
     168:	add.2d	v23, v21, v3
     16c:	add.2d	v25, v21, v1
     170:	fmov	x26, d21
     174:	mov.d	x27, v20[1]
     178:	add.2d	v21, v20, v24
     17c:	add.2d	v29, v20, v3
     180:	add.2d	v27, v20, v1
     184:	fmov	x28, d20
     188:	mov.d	x30, v19[1]
     18c:	add.2d	v30, v19, v24
     190:	add.2d	v31, v19, v3
     194:	add.2d	v28, v19, v1
     198:	fmov	x1, d19
     19c:	mov.d	x12, v16[1]
     1a0:	add.2d	v24, v16, v24
     1a4:	add.2d	v8, v16, v3
     1a8:	add.2d	v26, v16, v1
     1ac:	fmov	x16, d16
     1b0:	ldr	s19, [x26]
     1b4:	ld1.s	{ v19 }[1], [x25]
     1b8:	mov.d	x25, v22[1]
     1bc:	fmov	x26, d22
     1c0:	ushll2.2d	v16, v18, #0xc
     1c4:	ushll.2d	v17, v17, #0xc
     1c8:	ushll.2d	v18, v18, #0xc
     1cc:	ld1.s	{ v19 }[2], [x28]
     1d0:	ld1.s	{ v19 }[3], [x27]
     1d4:	mov.d	x27, v21[1]
     1d8:	fmov	x28, d21
     1dc:	ldr	s20, [x1]
     1e0:	ld1.s	{ v20 }[1], [x30]
     1e4:	ld1.s	{ v20 }[2], [x16]
     1e8:	ld1.s	{ v20 }[3], [x12]
     1ec:	stp	q19, q20, [x19]
     1f0:	fmul.4s	v20, v20, v20
     1f4:	fmul.4s	v19, v19, v19
     1f8:	mov.d	x12, v30[1]
     1fc:	fmov	x16, d30
     200:	mov.d	x1, v24[1]
     204:	ldr	s21, [x26]
     208:	ld1.s	{ v21 }[1], [x25]
     20c:	fmov	x25, d24
     210:	ld1.s	{ v21 }[2], [x28]
     214:	ld1.s	{ v21 }[3], [x27]
     218:	ldr	s22, [x16]
     21c:	ld1.s	{ v22 }[1], [x12]
     220:	ld1.s	{ v22 }[2], [x25]
     224:	ld1.s	{ v22 }[3], [x1]
     228:	stp	q21, q22, [x19, #0x20]
     22c:	fmul.4s	v22, v22, v22
     230:	fmul.4s	v21, v21, v21
     234:	mov.d	x12, v23[1]
     238:	fmov	x16, d23
     23c:	mov.d	x1, v29[1]
     240:	fmov	x25, d29
     244:	mov.d	x26, v31[1]
     248:	fmov	x27, d31
     24c:	mov.d	x28, v8[1]
     250:	ldr	s24, [x16]
     254:	ld1.s	{ v24 }[1], [x12]
     258:	fmov	x12, d8
     25c:	ld1.s	{ v24 }[2], [x25]
     260:	ld1.s	{ v24 }[3], [x1]
     264:	ldr	s23, [x27]
     268:	ld1.s	{ v23 }[1], [x26]
     26c:	ld1.s	{ v23 }[2], [x12]
     270:	ld1.s	{ v23 }[3], [x28]
     274:	stp	q24, q23, [x19, #0x40]
     278:	fmul.4s	v23, v23, v23
     27c:	fmul.4s	v24, v24, v24
     280:	mov.d	x12, v25[1]
     284:	fmov	x16, d25
     288:	mov.d	x1, v27[1]
     28c:	fmov	x25, d27
     290:	mov.d	x26, v28[1]
     294:	fmov	x27, d28
     298:	mov.d	x28, v26[1]
     29c:	ldr	s25, [x16]
     2a0:	ld1.s	{ v25 }[1], [x12]
     2a4:	fmov	x12, d26
     2a8:	ld1.s	{ v25 }[2], [x25]
     2ac:	ld1.s	{ v25 }[3], [x1]
     2b0:	ldr	s26, [x27]
     2b4:	ld1.s	{ v26 }[1], [x26]
     2b8:	ld1.s	{ v26 }[2], [x12]
     2bc:	ld1.s	{ v26 }[3], [x28]
     2c0:	stp	q25, q26, [x19, #0x60]
     2c4:	fmul.4s	v26, v26, v26
     2c8:	fmul.4s	v25, v25, v25
     2cc:	mov	x25, x24
     2d0:	mov	w26, #0x4
     2d4:	dup.2d	v27, x26
     2d8:	add.2d	v28, v27, v7
     2dc:	add.2d	v29, v27, v17
     2e0:	add.2d	v30, v27, v16
     2e4:	add.2d	v27, v27, v18
     2e8:	shl.2d	v27, v27, #0x2
     2ec:	shl.2d	v30, v30, #0x2
     2f0:	shl.2d	v29, v29, #0x2
     2f4:	shl.2d	v28, v28, #0x2
     2f8:	add.2d	v28, v6, v28
     2fc:	add.2d	v29, v6, v29
     300:	add.2d	v30, v6, v30
     304:	add.2d	v27, v6, v27
     308:	mov.d	x12, v27[1]
     30c:	fmov	x16, d27
     310:	mov.d	x1, v30[1]
     314:	mov.d	x27, v29[1]
     318:	mov.d	x28, v28[1]
     31c:	fmov	x30, d30
     320:	ldr	s27, [x16]
     324:	ld1.s	{ v27 }[1], [x12]
     328:	ld1.s	{ v27 }[2], [x30]
     32c:	fmov	x12, d29
     330:	ldr	s29, [x12]
     334:	ld1.s	{ v29 }[1], [x27]
     338:	ld1.s	{ v27 }[3], [x1]
     33c:	fmov	x12, d28
     340:	ld1.s	{ v29 }[2], [x12]
     344:	add	x12, x26, #0x1
     348:	ld1.s	{ v29 }[3], [x28]
     34c:	dup.2d	v28, x12
     350:	add.2d	v30, v28, v7
     354:	add.2d	v31, v28, v18
     358:	stp	q27, q29, [x25, #-0x60]
     35c:	shl.2d	v31, v31, #0x2
     360:	add.2d	v31, v6, v31
     364:	mov.d	x12, v31[1]
     368:	fmov	x16, d31
     36c:	fmul.4s	v29, v29, v29
     370:	add.2d	v31, v28, v17
     374:	add.2d	v28, v28, v16
     378:	shl.2d	v28, v28, #0x2
     37c:	shl.2d	v31, v31, #0x2
     380:	shl.2d	v30, v30, #0x2
     384:	fmul.4s	v27, v27, v27
     388:	add.2d	v30, v6, v30
     38c:	add.2d	v31, v6, v31
     390:	add.2d	v28, v6, v28
     394:	mov.d	x1, v28[1]
     398:	fadd.4s	v19, v19, v27
     39c:	fmov	x27, d28
     3a0:	mov.d	x28, v31[1]
     3a4:	mov.d	x30, v30[1]
     3a8:	fadd.4s	v20, v20, v29
     3ac:	fmov	x17, d31
     3b0:	ldr	s27, [x16]
     3b4:	ld1.s	{ v27 }[1], [x12]
     3b8:	ld1.s	{ v27 }[2], [x27]
     3bc:	fmov	x12, d30
     3c0:	ldr	s28, [x17]
     3c4:	ld1.s	{ v28 }[1], [x28]
     3c8:	ld1.s	{ v28 }[2], [x12]
     3cc:	add	x12, x26, #0x2
     3d0:	dup.2d	v29, x12
     3d4:	add.2d	v30, v29, v18
     3d8:	ld1.s	{ v27 }[3], [x1]
     3dc:	shl.2d	v30, v30, #0x2
     3e0:	add.2d	v30, v6, v30
     3e4:	mov.d	x12, v30[1]
     3e8:	ld1.s	{ v28 }[3], [x30]
     3ec:	add.2d	v31, v29, v7
     3f0:	fmov	x16, d30
     3f4:	add.2d	v30, v29, v17
     3f8:	add.2d	v29, v29, v16
     3fc:	stp	q27, q28, [x25, #-0x40]
     400:	shl.2d	v29, v29, #0x2
     404:	shl.2d	v30, v30, #0x2
     408:	shl.2d	v31, v31, #0x2
     40c:	add.2d	v31, v6, v31
     410:	add.2d	v30, v6, v30
     414:	fmul.4s	v27, v27, v27
     418:	add.2d	v29, v6, v29
     41c:	mov.d	x17, v29[1]
     420:	mov.d	x1, v30[1]
     424:	fmul.4s	v28, v28, v28
     428:	fmov	x27, d29
     42c:	fmov	x28, d30
     430:	mov.d	x30, v31[1]
     434:	fmov	x9, d31
     438:	fadd.4s	v22, v22, v28
     43c:	ldr	s28, [x16]
     440:	ld1.s	{ v28 }[1], [x12]
     444:	ldr	s29, [x28]
     448:	ld1.s	{ v28 }[2], [x27]
     44c:	ld1.s	{ v29 }[1], [x1]
     450:	ld1.s	{ v29 }[2], [x9]
     454:	ld1.s	{ v28 }[3], [x17]
     458:	fadd.4s	v21, v21, v27
     45c:	add	x9, x26, #0x3
     460:	dup.2d	v27, x9
     464:	ld1.s	{ v29 }[3], [x30]
     468:	add.2d	v30, v27, v7
     46c:	add.2d	v31, v27, v18
     470:	shl.2d	v31, v31, #0x2
     474:	add.2d	v31, v6, v31
     478:	stp	q28, q29, [x25, #-0x20]
     47c:	mov.d	x9, v31[1]
     480:	fmov	x12, d31
     484:	add.2d	v31, v27, v17
     488:	add.2d	v27, v27, v16
     48c:	fmul.4s	v28, v28, v28
     490:	shl.2d	v27, v27, #0x2
     494:	shl.2d	v31, v31, #0x2
     498:	shl.2d	v30, v30, #0x2
     49c:	add.2d	v30, v6, v30
     4a0:	add.2d	v31, v6, v31
     4a4:	fmul.4s	v29, v29, v29
     4a8:	add.2d	v27, v6, v27
     4ac:	mov.d	x16, v27[1]
     4b0:	mov.d	x17, v31[1]
     4b4:	fadd.4s	v23, v23, v29
     4b8:	fmov	x1, d27
     4bc:	fmov	x27, d31
     4c0:	mov.d	x28, v30[1]
     4c4:	fmov	x30, d30
     4c8:	fadd.4s	v24, v24, v28
     4cc:	ldr	s27, [x12]
     4d0:	ld1.s	{ v27 }[1], [x9]
     4d4:	ldr	s28, [x27]
     4d8:	ld1.s	{ v27 }[2], [x1]
     4dc:	ld1.s	{ v28 }[1], [x17]
     4e0:	ld1.s	{ v28 }[2], [x30]
     4e4:	ld1.s	{ v27 }[3], [x16]
     4e8:	ld1.s	{ v28 }[3], [x28]
     4ec:	fmul.4s	v29, v27, v27
     4f0:	fmul.4s	v30, v28, v28
     4f4:	stp	q27, q28, [x25], #0x80
     4f8:	fadd.4s	v26, v26, v30
     4fc:	fadd.4s	v25, v25, v29
     500:	cmp	x26, #0xffc
     504:	add	x26, x26, #0x4
     508:	b.lo	0x2d4
     50c:	mov	x25, #0x0
     510:	add	x9, x20, x25, lsl #2
     514:	ld1r.4s	{ v27 }, [x9]
     518:	add	x9, x23, x25, lsl #5
     51c:	stp	q27, q27, [x9]
     520:	add	x25, x25, #0x1
     524:	cmp	x25, #0x1, lsl #12
     528:	b.ne	0x510
     52c:	mov	x25, #0x0
     530:	fadd.4s	v20, v20, v22
     534:	fadd.4s	v19, v19, v21
     538:	fadd.4s	v19, v19, v24
     53c:	fadd.4s	v20, v20, v23
     540:	fadd.4s	v20, v20, v26
     544:	fadd.4s	v19, v19, v25
     548:	fmul.4s	v19, v19, v5
     54c:	fmul.4s	v20, v20, v5
     550:	fadd.4s	v20, v20, v4
     554:	fadd.4s	v19, v19, v4
     558:	fsqrt.4s	v19, v19
     55c:	fsqrt.4s	v20, v20
     560:	dup.2d	v21, x25
     564:	add.2d	v22, v21, v7
     568:	add.2d	v23, v21, v17
     56c:	add.2d	v24, v21, v16
     570:	add.2d	v21, v21, v18
     574:	add	x9, x19, x25, lsl #5
     578:	ldp	q26, q25, [x9]
     57c:	fdiv.4s	v26, v26, v19
     580:	fdiv.4s	v25, v25, v20
     584:	add	x9, x9, #0x20, lsl #12
     588:	ldp	q27, q28, [x9]
     58c:	fmul.4s	v25, v25, v28
     590:	fmul.4s	v26, v26, v27
     594:	shl.2d	v21, v21, #0x2
     598:	shl.2d	v24, v24, #0x2
     59c:	shl.2d	v23, v23, #0x2
     5a0:	shl.2d	v22, v22, #0x2
     5a4:	dup.2d	v27, x21
     5a8:	add.2d	v22, v27, v22
     5ac:	add.2d	v21, v27, v21
     5b0:	mov.d	x9, v21[1]
     5b4:	fmov	x12, d21
     5b8:	str	s26, [x12]
     5bc:	st1.s	{ v26 }[1], [x9]
     5c0:	add.2d	v21, v27, v24
     5c4:	mov.d	x9, v21[1]
     5c8:	fmov	x12, d21
     5cc:	st1.s	{ v26 }[2], [x12]
     5d0:	add.2d	v21, v27, v23
     5d4:	st1.s	{ v26 }[3], [x9]
     5d8:	mov.d	x9, v21[1]
     5dc:	fmov	x12, d21
     5e0:	str	s25, [x12]
     5e4:	st1.s	{ v25 }[1], [x9]
     5e8:	mov.d	x9, v22[1]
     5ec:	fmov	x12, d22
     5f0:	st1.s	{ v25 }[2], [x12]
     5f4:	st1.s	{ v25 }[3], [x9]
     5f8:	add	x25, x25, #0x1
     5fc:	cmp	x25, #0x1, lsl #12
     600:	b.ne	0x560
     604:	add	w7, w7, #0x1
     608:	cmp	w7, #0x80
     60c:	b.ne	0x128
     610:	b	0x74
     614:	lsr	x7, x19, #3
     618:	cmp	x19, #0x8
     61c:	b.lo	0xb38
     620:	mov	w20, #0x0
     624:	ldr	x9, [sp]
     628:	ldr	x21, [x9, #0x88]
     62c:	ldr	x22, [x0]
     630:	ldr	x23, [x0, #0x10]
     634:	ldr	x24, [x0, #0x30]
     638:	lsl	w25, w6, #10
     63c:	add	x26, x21, #0x20, lsl #12
     640:	add	x27, x21, #0xe0
     644:	add	w9, w25, w20, lsl #3
     648:	dup.4s	v6, w9
     64c:	orr.16b	v19, v6, v0
     650:	orr.16b	v18, v6, v2
     654:	ushll2.2d	v6, v19, #0xc
     658:	ushll2.2d	v7, v18, #0xc
     65c:	dup.2d	v20, x13
     660:	ushll.2d	v22, v18, #0xe
     664:	ushll2.2d	v21, v18, #0xe
     668:	ushll.2d	v17, v19, #0xe
     66c:	dup.2d	v16, x22
     670:	add.2d	v17, v16, v17
     674:	add.2d	v21, v16, v21
     678:	add.2d	v22, v16, v22
     67c:	mov.d	x28, v22[1]
     680:	dup.2d	v24, x14
     684:	add.2d	v23, v22, v24
     688:	dup.2d	v29, x15
     68c:	add.2d	v25, v22, v29
     690:	add.2d	v26, v22, v20
     694:	fmov	x9, d22
     698:	mov.d	x12, v21[1]
     69c:	add.2d	v22, v21, v24
     6a0:	add.2d	v30, v21, v29
     6a4:	add.2d	v27, v21, v20
     6a8:	fmov	x16, d21
     6ac:	mov.d	x17, v17[1]
     6b0:	add.2d	v21, v17, v24
     6b4:	add.2d	v31, v17, v29
     6b8:	add.2d	v28, v17, v20
     6bc:	fmov	x1, d17
     6c0:	ushll.2d	v17, v19, #0xc
     6c4:	ushll2.2d	v19, v19, #0xe
     6c8:	add.2d	v19, v16, v19
     6cc:	mov.d	x30, v19[1]
     6d0:	add.2d	v24, v19, v24
     6d4:	add.2d	v8, v19, v29
     6d8:	add.2d	v29, v19, v20
     6dc:	fmov	x10, d19
     6e0:	ldr	s19, [x9]
     6e4:	ld1.s	{ v19 }[1], [x28]
     6e8:	ld1.s	{ v19 }[2], [x16]
     6ec:	ld1.s	{ v19 }[3], [x12]
     6f0:	mov.d	x9, v23[1]
     6f4:	fmov	x12, d23
     6f8:	ldr	s20, [x1]
     6fc:	ld1.s	{ v20 }[1], [x17]
     700:	ld1.s	{ v20 }[2], [x10]
     704:	ushll.2d	v18, v18, #0xc
     708:	ld1.s	{ v20 }[3], [x30]
     70c:	stp	q19, q20, [x21]
     710:	fmul.4s	v20, v20, v20
     714:	fmul.4s	v19, v19, v19
     718:	mov.d	x10, v22[1]
     71c:	fmov	x16, d22
     720:	mov.d	x17, v21[1]
     724:	fmov	x1, d21
     728:	mov.d	x28, v24[1]
     72c:	ldr	s21, [x12]
     730:	ld1.s	{ v21 }[1], [x9]
     734:	fmov	x9, d24
     738:	ld1.s	{ v21 }[2], [x16]
     73c:	ld1.s	{ v21 }[3], [x10]
     740:	ldr	s22, [x1]
     744:	ld1.s	{ v22 }[1], [x17]
     748:	ld1.s	{ v22 }[2], [x9]
     74c:	ld1.s	{ v22 }[3], [x28]
     750:	stp	q21, q22, [x21, #0x20]
     754:	fmul.4s	v22, v22, v22
     758:	fmul.4s	v21, v21, v21
     75c:	mov.d	x9, v25[1]
     760:	fmov	x10, d25
     764:	mov.d	x12, v30[1]
     768:	fmov	x16, d30
     76c:	mov.d	x17, v31[1]
     770:	fmov	x1, d31
     774:	mov.d	x28, v8[1]
     778:	ldr	s24, [x10]
     77c:	ld1.s	{ v24 }[1], [x9]
     780:	fmov	x9, d8
     784:	ld1.s	{ v24 }[2], [x16]
     788:	ld1.s	{ v24 }[3], [x12]
     78c:	ldr	s23, [x1]
     790:	ld1.s	{ v23 }[1], [x17]
     794:	ld1.s	{ v23 }[2], [x9]
     798:	ld1.s	{ v23 }[3], [x28]
     79c:	stp	q24, q23, [x21, #0x40]
     7a0:	fmul.4s	v23, v23, v23
     7a4:	fmul.4s	v24, v24, v24
     7a8:	mov.d	x9, v26[1]
     7ac:	fmov	x10, d26
     7b0:	mov.d	x12, v27[1]
     7b4:	fmov	x16, d27
     7b8:	mov.d	x17, v28[1]
     7bc:	fmov	x1, d28
     7c0:	mov.d	x28, v29[1]
     7c4:	ldr	s25, [x10]
     7c8:	ld1.s	{ v25 }[1], [x9]
     7cc:	fmov	x9, d29
     7d0:	ld1.s	{ v25 }[2], [x16]
     7d4:	ld1.s	{ v25 }[3], [x12]
     7d8:	ldr	s26, [x1]
     7dc:	ld1.s	{ v26 }[1], [x17]
     7e0:	ld1.s	{ v26 }[2], [x9]
     7e4:	ld1.s	{ v26 }[3], [x28]
     7e8:	stp	q25, q26, [x21, #0x60]
     7ec:	fmul.4s	v26, v26, v26
     7f0:	fmul.4s	v25, v25, v25
     7f4:	mov	x28, x27
     7f8:	mov	w30, #0x4
     7fc:	dup.2d	v27, x30
     800:	add.2d	v28, v27, v6
     804:	add.2d	v29, v27, v17
     808:	add.2d	v30, v27, v7
     80c:	add.2d	v27, v27, v18
     810:	shl.2d	v27, v27, #0x2
     814:	shl.2d	v30, v30, #0x2
     818:	shl.2d	v29, v29, #0x2
     81c:	shl.2d	v28, v28, #0x2
     820:	add.2d	v28, v16, v28
     824:	add.2d	v29, v16, v29
     828:	add.2d	v30, v16, v30
     82c:	add.2d	v27, v16, v27
     830:	mov.d	x9, v27[1]
     834:	fmov	x10, d27
     838:	mov.d	x12, v30[1]
     83c:	mov.d	x16, v29[1]
     840:	mov.d	x17, v28[1]
     844:	fmov	x1, d30
     848:	ldr	s27, [x10]
     84c:	ld1.s	{ v27 }[1], [x9]
     850:	ld1.s	{ v27 }[2], [x1]
     854:	fmov	x9, d29
     858:	ldr	s29, [x9]
     85c:	ld1.s	{ v29 }[1], [x16]
     860:	ld1.s	{ v27 }[3], [x12]
     864:	fmov	x9, d28
     868:	ld1.s	{ v29 }[2], [x9]
     86c:	add	x9, x30, #0x1
     870:	ld1.s	{ v29 }[3], [x17]
     874:	dup.2d	v28, x9
     878:	add.2d	v30, v28, v6
     87c:	add.2d	v31, v28, v18
     880:	stp	q27, q29, [x28, #-0x60]
     884:	shl.2d	v31, v31, #0x2
     888:	add.2d	v31, v16, v31
     88c:	mov.d	x9, v31[1]
     890:	fmov	x10, d31
     894:	fmul.4s	v29, v29, v29
     898:	add.2d	v31, v28, v17
     89c:	add.2d	v28, v28, v7
     8a0:	shl.2d	v28, v28, #0x2
     8a4:	shl.2d	v31, v31, #0x2
     8a8:	shl.2d	v30, v30, #0x2
     8ac:	fmul.4s	v27, v27, v27
     8b0:	add.2d	v30, v16, v30
     8b4:	add.2d	v31, v16, v31
     8b8:	add.2d	v28, v16, v28
     8bc:	mov.d	x12, v28[1]
     8c0:	fadd.4s	v19, v19, v27
     8c4:	fmov	x16, d28
     8c8:	mov.d	x17, v31[1]
     8cc:	mov.d	x1, v30[1]
     8d0:	fadd.4s	v20, v20, v29
     8d4:	fmov	x4, d31
     8d8:	ldr	s27, [x10]
     8dc:	ld1.s	{ v27 }[1], [x9]
     8e0:	ld1.s	{ v27 }[2], [x16]
     8e4:	fmov	x9, d30
     8e8:	ldr	s28, [x4]
     8ec:	ld1.s	{ v28 }[1], [x17]
     8f0:	ld1.s	{ v28 }[2], [x9]
     8f4:	add	x9, x30, #0x2
     8f8:	dup.2d	v29, x9
     8fc:	add.2d	v30, v29, v18
     900:	ld1.s	{ v27 }[3], [x12]
     904:	shl.2d	v30, v30, #0x2
     908:	add.2d	v30, v16, v30
     90c:	mov.d	x9, v30[1]
     910:	ld1.s	{ v28 }[3], [x1]
     914:	add.2d	v31, v29, v6
     918:	fmov	x10, d30
     91c:	add.2d	v30, v29, v17
     920:	add.2d	v29, v29, v7
     924:	stp	q27, q28, [x28, #-0x40]
     928:	shl.2d	v29, v29, #0x2
     92c:	shl.2d	v30, v30, #0x2
     930:	shl.2d	v31, v31, #0x2
     934:	add.2d	v31, v16, v31
     938:	add.2d	v30, v16, v30
     93c:	fmul.4s	v27, v27, v27
     940:	add.2d	v29, v16, v29
     944:	mov.d	x12, v29[1]
     948:	mov.d	x16, v30[1]
     94c:	fmul.4s	v28, v28, v28
     950:	fmov	x17, d29
     954:	fmov	x1, d30
     958:	mov.d	x4, v31[1]
     95c:	fmov	x3, d31
     960:	fadd.4s	v22, v22, v28
     964:	ldr	s28, [x10]
     968:	ld1.s	{ v28 }[1], [x9]
     96c:	ldr	s29, [x1]
     970:	ld1.s	{ v28 }[2], [x17]
     974:	ld1.s	{ v29 }[1], [x16]
     978:	ld1.s	{ v29 }[2], [x3]
     97c:	ld1.s	{ v28 }[3], [x12]
     980:	fadd.4s	v21, v21, v27
     984:	add	x9, x30, #0x3
     988:	dup.2d	v27, x9
     98c:	ld1.s	{ v29 }[3], [x4]
     990:	add.2d	v30, v27, v6
     994:	add.2d	v31, v27, v18
     998:	shl.2d	v31, v31, #0x2
     99c:	add.2d	v31, v16, v31
     9a0:	stp	q28, q29, [x28, #-0x20]
     9a4:	mov.d	x9, v31[1]
     9a8:	fmov	x10, d31
     9ac:	add.2d	v31, v27, v17
     9b0:	add.2d	v27, v27, v7
     9b4:	fmul.4s	v28, v28, v28
     9b8:	shl.2d	v27, v27, #0x2
     9bc:	shl.2d	v31, v31, #0x2
     9c0:	shl.2d	v30, v30, #0x2
     9c4:	add.2d	v30, v16, v30
     9c8:	add.2d	v31, v16, v31
     9cc:	fmul.4s	v29, v29, v29
     9d0:	add.2d	v27, v16, v27
     9d4:	mov.d	x12, v27[1]
     9d8:	mov.d	x16, v31[1]
     9dc:	fadd.4s	v23, v23, v29
     9e0:	fmov	x17, d27
     9e4:	fmov	x1, d31
     9e8:	mov.d	x3, v30[1]
     9ec:	fmov	x4, d30
     9f0:	fadd.4s	v24, v24, v28
     9f4:	ldr	s27, [x10]
     9f8:	ld1.s	{ v27 }[1], [x9]
     9fc:	ldr	s28, [x1]
     a00:	ld1.s	{ v27 }[2], [x17]
     a04:	ld1.s	{ v28 }[1], [x16]
     a08:	ld1.s	{ v28 }[2], [x4]
     a0c:	ld1.s	{ v27 }[3], [x12]
     a10:	ld1.s	{ v28 }[3], [x3]
     a14:	fmul.4s	v29, v27, v27
     a18:	fmul.4s	v30, v28, v28
     a1c:	stp	q27, q28, [x28], #0x80
     a20:	fadd.4s	v26, v26, v30
     a24:	fadd.4s	v25, v25, v29
     a28:	cmp	x30, #0xffc
     a2c:	add	x30, x30, #0x4
     a30:	b.lo	0x7fc
     a34:	mov	x28, #0x0
     a38:	add	x9, x23, x28, lsl #2
     a3c:	ld1r.4s	{ v16 }, [x9]
     a40:	add	x9, x26, x28, lsl #5
     a44:	stp	q16, q16, [x9]
     a48:	add	x28, x28, #0x1
     a4c:	cmp	x28, #0x1, lsl #12
     a50:	b.ne	0xa38
     a54:	mov	x28, #0x0
     a58:	fadd.4s	v16, v20, v22
     a5c:	fadd.4s	v19, v19, v21
     a60:	fadd.4s	v19, v19, v24
     a64:	fadd.4s	v16, v16, v23
     a68:	fadd.4s	v16, v16, v26
     a6c:	fadd.4s	v19, v19, v25
     a70:	fmul.4s	v19, v19, v5
     a74:	fmul.4s	v16, v16, v5
     a78:	fadd.4s	v20, v16, v4
     a7c:	fadd.4s	v16, v19, v4
     a80:	fsqrt.4s	v16, v16
     a84:	fsqrt.4s	v19, v20
     a88:	dup.2d	v20, x28
     a8c:	add.2d	v21, v20, v6
     a90:	add.2d	v22, v20, v17
     a94:	add.2d	v23, v20, v7
     a98:	add.2d	v20, v20, v18
     a9c:	add	x9, x21, x28, lsl #5
     aa0:	ldp	q25, q24, [x9]
     aa4:	fdiv.4s	v25, v25, v16
     aa8:	fdiv.4s	v24, v24, v19
     aac:	add	x9, x9, #0x20, lsl #12
     ab0:	ldp	q26, q27, [x9]
     ab4:	fmul.4s	v24, v24, v27
     ab8:	fmul.4s	v25, v25, v26
     abc:	shl.2d	v20, v20, #0x2
     ac0:	shl.2d	v23, v23, #0x2
     ac4:	shl.2d	v22, v22, #0x2
     ac8:	shl.2d	v21, v21, #0x2
     acc:	dup.2d	v26, x24
     ad0:	add.2d	v21, v26, v21
     ad4:	add.2d	v20, v26, v20
     ad8:	mov.d	x9, v20[1]
     adc:	fmov	x10, d20
     ae0:	str	s25, [x10]
     ae4:	st1.s	{ v25 }[1], [x9]
     ae8:	add.2d	v20, v26, v23
     aec:	mov.d	x9, v20[1]
     af0:	fmov	x10, d20
     af4:	st1.s	{ v25 }[2], [x10]
     af8:	add.2d	v20, v26, v22
     afc:	st1.s	{ v25 }[3], [x9]
     b00:	mov.d	x9, v20[1]
     b04:	fmov	x10, d20
     b08:	str	s24, [x10]
     b0c:	st1.s	{ v24 }[1], [x9]
     b10:	mov.d	x9, v21[1]
     b14:	fmov	x10, d21
     b18:	st1.s	{ v24 }[2], [x10]
     b1c:	st1.s	{ v24 }[3], [x9]
     b20:	add	x28, x28, #0x1
     b24:	cmp	x28, #0x1, lsl #12
     b28:	b.ne	0xa88
     b2c:	add	w20, w20, #0x1
     b30:	cmp	w20, w7
     b34:	b.ne	0x644
     b38:	and	w19, w19, #0x7
     b3c:	cbz	w19, 0x74
     b40:	dup.4s	v7, w19
     b44:	cmhi.4s	v6, v7, v0
     b48:	cmhi.4s	v7, v7, v2
     b4c:	uzp1.8h	v16, v7, v6
     b50:	umaxv.8h	h17, v16
     b54:	fmov	w9, s17
     b58:	tbz	w9, #0x0, 0x74
     b5c:	ldr	x9, [x0]
     b60:	adrp	x10, lCPI0_2@PAGE
     b64:	ldr	q17, [x10, lCPI0_2@PAGEOFF]
     b68:	and.16b	v16, v16, v17
     b6c:	addv.8h	h16, v16
     b70:	fmov	w19, s16
     b74:	lsl	w10, w7, #3
     b78:	orr	w10, w10, w6, lsl #10
     b7c:	dup.4s	v19, w10
     b80:	orr.16b	v17, v19, v2
     b84:	and.16b	v18, v7, v17
     b88:	ushll.2d	v20, v18, #0xe
     b8c:	dup.2d	v17, x9
     b90:	add.2d	v21, v17, v20
     b94:	movi.2d	v22, #0000000000000000
     b98:	movi.2d	v23, #0000000000000000
     b9c:	tbnz	w19, #0x0, 0x13a0
     ba0:	and	w7, w19, #0xff
     ba4:	tbnz	w7, #0x1, 0x13b0
     ba8:	ushll2.2d	v21, v18, #0xe
     bac:	add.2d	v24, v17, v21
     bb0:	tbnz	w7, #0x2, 0x13c4
     bb4:	tbnz	w7, #0x3, 0x13d0
     bb8:	orr.16b	v19, v19, v0
     bbc:	and.16b	v19, v6, v19
     bc0:	ushll.2d	v24, v19, #0xe
     bc4:	add.2d	v25, v17, v24
     bc8:	tbnz	w7, #0x4, 0x13ec
     bcc:	tbnz	w7, #0x5, 0x13f8
     bd0:	ushll2.2d	v25, v19, #0xe
     bd4:	add.2d	v26, v17, v25
     bd8:	tbnz	w7, #0x6, 0x140c
     bdc:	tbz	w7, #0x7, 0xbe8
     be0:	mov.d	x9, v26[1]
     be4:	ld1.s	{ v23 }[3], [x9]
     be8:	ldr	x9, [sp]
     bec:	ldr	x7, [x9, #0x88]
     bf0:	ldr	x20, [x0, #0x10]
     bf4:	ldr	x19, [x0, #0x30]
     bf8:	fmov	w21, s16
     bfc:	ldp	q26, q27, [x7]
     c00:	bit.16b	v27, v23, v6
     c04:	bit.16b	v26, v22, v7
     c08:	stp	q26, q27, [x7]
     c0c:	dup.2d	v26, x14
     c10:	add.2d	v28, v17, v26
     c14:	add.2d	v29, v28, v20
     c18:	movi.2d	v26, #0000000000000000
     c1c:	movi.2d	v27, #0000000000000000
     c20:	tbnz	w21, #0x0, 0x141c
     c24:	and	w21, w21, #0xff
     c28:	tbnz	w21, #0x1, 0x142c
     c2c:	add.2d	v29, v28, v21
     c30:	tbnz	w21, #0x2, 0x143c
     c34:	tbnz	w21, #0x3, 0x1448
     c38:	add.2d	v29, v28, v24
     c3c:	tbnz	w21, #0x4, 0x1458
     c40:	tbnz	w21, #0x5, 0x1464
     c44:	add.2d	v28, v28, v25
     c48:	tbnz	w21, #0x6, 0x1474
     c4c:	tbz	w21, #0x7, 0xc58
     c50:	mov.d	x9, v28[1]
     c54:	ld1.s	{ v27 }[3], [x9]
     c58:	fmov	w21, s16
     c5c:	ldp	q28, q29, [x7, #0x20]
     c60:	bit.16b	v29, v27, v6
     c64:	bit.16b	v28, v26, v7
     c68:	stp	q28, q29, [x7, #0x20]
     c6c:	dup.2d	v28, x15
     c70:	add.2d	v30, v17, v28
     c74:	add.2d	v31, v30, v20
     c78:	movi.2d	v28, #0000000000000000
     c7c:	movi.2d	v29, #0000000000000000
     c80:	tbnz	w21, #0x0, 0x1484
     c84:	and	w21, w21, #0xff
     c88:	tbnz	w21, #0x1, 0x1494
     c8c:	add.2d	v31, v30, v21
     c90:	tbnz	w21, #0x2, 0x14a4
     c94:	tbnz	w21, #0x3, 0x14b0
     c98:	add.2d	v31, v30, v24
     c9c:	tbnz	w21, #0x4, 0x14c0
     ca0:	tbnz	w21, #0x5, 0x14cc
     ca4:	add.2d	v30, v30, v25
     ca8:	tbnz	w21, #0x6, 0x14dc
     cac:	tbz	w21, #0x7, 0xcb8
     cb0:	mov.d	x9, v30[1]
     cb4:	ld1.s	{ v29 }[3], [x9]
     cb8:	fmov	w21, s16
     cbc:	ldp	q30, q31, [x7, #0x40]
     cc0:	bit.16b	v31, v29, v6
     cc4:	bit.16b	v30, v28, v7
     cc8:	stp	q30, q31, [x7, #0x40]
     ccc:	dup.2d	v30, x13
     cd0:	add.2d	v8, v17, v30
     cd4:	add.2d	v20, v8, v20
     cd8:	movi.2d	v30, #0000000000000000
     cdc:	movi.2d	v31, #0000000000000000
     ce0:	tbnz	w21, #0x0, 0x14ec
     ce4:	and	w21, w21, #0xff
     ce8:	tbnz	w21, #0x1, 0x14fc
     cec:	add.2d	v20, v8, v21
     cf0:	tbnz	w21, #0x2, 0x150c
     cf4:	tbnz	w21, #0x3, 0x1518
     cf8:	add.2d	v20, v8, v24
     cfc:	tbnz	w21, #0x4, 0x1528
     d00:	tbnz	w21, #0x5, 0x1534
     d04:	add.2d	v20, v8, v25
     d08:	tbnz	w21, #0x6, 0x1544
     d0c:	tbz	w21, #0x7, 0xd18
     d10:	mov.d	x9, v20[1]
     d14:	ld1.s	{ v31 }[3], [x9]
     d18:	sshll.2d	v21, v7, #0x0
     d1c:	add	x21, x7, #0x20, lsl #12
     d20:	sshll.2d	v20, v6, #0x0
     d24:	sshll2.2d	v24, v7, #0x0
     d28:	sshll2.2d	v25, v6, #0x0
     d2c:	ushll.2d	v8, v18, #0xc
     d30:	ushll.2d	v9, v19, #0xc
     d34:	ushll2.2d	v10, v18, #0xc
     d38:	ushll2.2d	v18, v19, #0xc
     d3c:	and.16b	v18, v25, v18
     d40:	and.16b	v19, v24, v10
     d44:	and.16b	v20, v20, v9
     d48:	and.16b	v21, v21, v8
     d4c:	fmul.4s	v24, v22, v22
     d50:	fmul.4s	v22, v23, v23
     d54:	fmul.4s	v23, v26, v26
     d58:	fmul.4s	v26, v27, v27
     d5c:	fmul.4s	v8, v28, v28
     d60:	fmul.4s	v27, v29, v29
     d64:	ldp	q25, q28, [x7, #0x60]
     d68:	bit.16b	v28, v31, v6
     d6c:	bit.16b	v25, v30, v7
     d70:	stp	q25, q28, [x7, #0x60]
     d74:	fmul.4s	v29, v30, v30
     d78:	fmul.4s	v30, v31, v31
     d7c:	and.16b	v22, v6, v22
     d80:	and.16b	v25, v7, v24
     d84:	and.16b	v24, v6, v26
     d88:	and.16b	v28, v7, v23
     d8c:	and.16b	v27, v6, v27
     d90:	and.16b	v26, v7, v8
     d94:	and.16b	v23, v6, v30
     d98:	add	x22, x7, #0xe0
     d9c:	mov	w23, #0x4
     da0:	and.16b	v29, v7, v29
     da4:	b	0xe28
     da8:	fmul.4s	v31, v31, v31
     dac:	fmul.4s	v30, v30, v30
     db0:	fadd.4s	v30, v25, v30
     db4:	fadd.4s	v31, v22, v31
     db8:	fmul.4s	v9, v9, v9
     dbc:	fmul.4s	v8, v8, v8
     dc0:	fadd.4s	v8, v28, v8
     dc4:	fadd.4s	v9, v24, v9
     dc8:	fmul.4s	v11, v11, v11
     dcc:	fmul.4s	v10, v10, v10
     dd0:	fadd.4s	v10, v26, v10
     dd4:	fadd.4s	v11, v27, v11
     dd8:	ldp	q14, q15, [x22]
     ddc:	bit.16b	v15, v13, v6
     de0:	bit.16b	v14, v12, v7
     de4:	stp	q14, q15, [x22], #0x80
     de8:	fmul.4s	v12, v12, v12
     dec:	fmul.4s	v13, v13, v13
     df0:	fadd.4s	v13, v23, v13
     df4:	fadd.4s	v12, v29, v12
     df8:	bit.16b	v22, v31, v6
     dfc:	bit.16b	v25, v30, v7
     e00:	bit.16b	v24, v9, v6
     e04:	bit.16b	v28, v8, v7
     e08:	bit.16b	v27, v11, v6
     e0c:	bit.16b	v26, v10, v7
     e10:	sub	x9, x23, #0x3
     e14:	bit.16b	v29, v12, v7
     e18:	add	x23, x23, #0x1
     e1c:	bit.16b	v23, v13, v6
     e20:	cmp	x9, #0xffc
     e24:	b.hs	0x1218
     e28:	dup.2d	v8, x23
     e2c:	fmov	w24, s16
     e30:	add.2d	v30, v8, v21
     e34:	shl.2d	v30, v30, #0x2
     e38:	add.2d	v9, v17, v30
     e3c:	movi.2d	v30, #0000000000000000
     e40:	movi.2d	v31, #0000000000000000
     e44:	tbnz	w24, #0x0, 0x1010
     e48:	and	w24, w24, #0xff
     e4c:	tbnz	w24, #0x1, 0x1020
     e50:	add.2d	v9, v8, v19
     e54:	shl.2d	v9, v9, #0x2
     e58:	add.2d	v9, v17, v9
     e5c:	tbnz	w24, #0x2, 0x1038
     e60:	tbnz	w24, #0x3, 0x1044
     e64:	add.2d	v9, v8, v20
     e68:	shl.2d	v9, v9, #0x2
     e6c:	add.2d	v9, v17, v9
     e70:	tbnz	w24, #0x4, 0x105c
     e74:	tbnz	w24, #0x5, 0x1068
     e78:	add.2d	v8, v8, v18
     e7c:	shl.2d	v8, v8, #0x2
     e80:	add.2d	v8, v17, v8
     e84:	tbnz	w24, #0x6, 0x1080
     e88:	tbz	w24, #0x7, 0xe94
     e8c:	mov.d	x9, v8[1]
     e90:	ld1.s	{ v31 }[3], [x9]
     e94:	fmov	w24, s16
     e98:	ldp	q8, q9, [x22, #-0x60]
     e9c:	bit.16b	v9, v31, v6
     ea0:	bit.16b	v8, v30, v7
     ea4:	add	x23, x23, #0x1
     ea8:	dup.2d	v10, x23
     eac:	stp	q8, q9, [x22, #-0x60]
     eb0:	add.2d	v8, v10, v21
     eb4:	shl.2d	v8, v8, #0x2
     eb8:	add.2d	v11, v17, v8
     ebc:	movi.2d	v8, #0000000000000000
     ec0:	movi.2d	v9, #0000000000000000
     ec4:	tbnz	w24, #0x0, 0x1090
     ec8:	and	w24, w24, #0xff
     ecc:	tbnz	w24, #0x1, 0x10a0
     ed0:	add.2d	v11, v10, v19
     ed4:	shl.2d	v11, v11, #0x2
     ed8:	add.2d	v11, v17, v11
     edc:	tbnz	w24, #0x2, 0x10b8
     ee0:	tbnz	w24, #0x3, 0x10c4
     ee4:	add.2d	v11, v10, v20
     ee8:	shl.2d	v11, v11, #0x2
     eec:	add.2d	v11, v17, v11
     ef0:	tbnz	w24, #0x4, 0x10dc
     ef4:	tbnz	w24, #0x5, 0x10e8
     ef8:	add.2d	v10, v10, v18
     efc:	shl.2d	v10, v10, #0x2
     f00:	add.2d	v10, v17, v10
     f04:	tbnz	w24, #0x6, 0x1100
     f08:	tbz	w24, #0x7, 0xf14
     f0c:	mov.d	x9, v10[1]
     f10:	ld1.s	{ v9 }[3], [x9]
     f14:	fmov	w24, s16
     f18:	ldp	q10, q11, [x22, #-0x40]
     f1c:	bit.16b	v11, v9, v6
     f20:	bit.16b	v10, v8, v7
     f24:	add	x23, x23, #0x1
     f28:	dup.2d	v12, x23
     f2c:	stp	q10, q11, [x22, #-0x40]
     f30:	add.2d	v10, v12, v21
     f34:	shl.2d	v10, v10, #0x2
     f38:	add.2d	v13, v17, v10
     f3c:	movi.2d	v10, #0000000000000000
     f40:	movi.2d	v11, #0000000000000000
     f44:	tbnz	w24, #0x0, 0x1110
     f48:	and	w24, w24, #0xff
     f4c:	tbnz	w24, #0x1, 0x1120
     f50:	add.2d	v13, v12, v19
     f54:	shl.2d	v13, v13, #0x2
     f58:	add.2d	v13, v17, v13
     f5c:	tbnz	w24, #0x2, 0x1138
     f60:	tbnz	w24, #0x3, 0x1144
     f64:	add.2d	v13, v12, v20
     f68:	shl.2d	v13, v13, #0x2
     f6c:	add.2d	v13, v17, v13
     f70:	tbnz	w24, #0x4, 0x115c
     f74:	tbnz	w24, #0x5, 0x1168
     f78:	add.2d	v12, v12, v18
     f7c:	shl.2d	v12, v12, #0x2
     f80:	add.2d	v12, v17, v12
     f84:	tbnz	w24, #0x6, 0x1180
     f88:	tbz	w24, #0x7, 0xf94
     f8c:	mov.d	x9, v12[1]
     f90:	ld1.s	{ v11 }[3], [x9]
     f94:	fmov	w24, s16
     f98:	ldp	q12, q13, [x22, #-0x20]
     f9c:	bit.16b	v13, v11, v6
     fa0:	bit.16b	v12, v10, v7
     fa4:	add	x23, x23, #0x1
     fa8:	dup.2d	v14, x23
     fac:	stp	q12, q13, [x22, #-0x20]
     fb0:	add.2d	v12, v14, v21
     fb4:	shl.2d	v12, v12, #0x2
     fb8:	add.2d	v15, v17, v12
     fbc:	movi.2d	v12, #0000000000000000
     fc0:	movi.2d	v13, #0000000000000000
     fc4:	tbnz	w24, #0x0, 0x1190
     fc8:	and	w24, w24, #0xff
     fcc:	tbnz	w24, #0x1, 0x11a0
     fd0:	add.2d	v15, v14, v19
     fd4:	shl.2d	v15, v15, #0x2
     fd8:	add.2d	v15, v17, v15
     fdc:	tbnz	w24, #0x2, 0x11b8
     fe0:	tbnz	w24, #0x3, 0x11c4
     fe4:	add.2d	v15, v14, v20
     fe8:	shl.2d	v15, v15, #0x2
     fec:	add.2d	v15, v17, v15
     ff0:	tbnz	w24, #0x4, 0x11dc
     ff4:	tbnz	w24, #0x5, 0x11e8
     ff8:	add.2d	v14, v14, v18
     ffc:	shl.2d	v14, v14, #0x2
    1000:	add.2d	v14, v17, v14
    1004:	tbnz	w24, #0x6, 0x1200
    1008:	tbz	w24, #0x7, 0xda8
    100c:	b	0x120c
    1010:	fmov	x9, d9
    1014:	ldr	s30, [x9]
    1018:	and	w24, w24, #0xff
    101c:	tbz	w24, #0x1, 0xe50
    1020:	mov.d	x9, v9[1]
    1024:	ld1.s	{ v30 }[1], [x9]
    1028:	add.2d	v9, v8, v19
    102c:	shl.2d	v9, v9, #0x2
    1030:	add.2d	v9, v17, v9
    1034:	tbz	w24, #0x2, 0xe60
    1038:	fmov	x9, d9
    103c:	ld1.s	{ v30 }[2], [x9]
    1040:	tbz	w24, #0x3, 0xe64
    1044:	mov.d	x9, v9[1]
    1048:	ld1.s	{ v30 }[3], [x9]
    104c:	add.2d	v9, v8, v20
    1050:	shl.2d	v9, v9, #0x2
    1054:	add.2d	v9, v17, v9
    1058:	tbz	w24, #0x4, 0xe74
    105c:	fmov	x9, d9
    1060:	ld1.s	{ v31 }[0], [x9]
    1064:	tbz	w24, #0x5, 0xe78
    1068:	mov.d	x9, v9[1]
    106c:	ld1.s	{ v31 }[1], [x9]
    1070:	add.2d	v8, v8, v18
    1074:	shl.2d	v8, v8, #0x2
    1078:	add.2d	v8, v17, v8
    107c:	tbz	w24, #0x6, 0xe88
    1080:	fmov	x9, d8
    1084:	ld1.s	{ v31 }[2], [x9]
    1088:	tbnz	w24, #0x7, 0xe8c
    108c:	b	0xe94
    1090:	fmov	x9, d11
    1094:	ldr	s8, [x9]
    1098:	and	w24, w24, #0xff
    109c:	tbz	w24, #0x1, 0xed0
    10a0:	mov.d	x9, v11[1]
    10a4:	ld1.s	{ v8 }[1], [x9]
    10a8:	add.2d	v11, v10, v19
    10ac:	shl.2d	v11, v11, #0x2
    10b0:	add.2d	v11, v17, v11
    10b4:	tbz	w24, #0x2, 0xee0
    10b8:	fmov	x9, d11
    10bc:	ld1.s	{ v8 }[2], [x9]
    10c0:	tbz	w24, #0x3, 0xee4
    10c4:	mov.d	x9, v11[1]
    10c8:	ld1.s	{ v8 }[3], [x9]
    10cc:	add.2d	v11, v10, v20
    10d0:	shl.2d	v11, v11, #0x2
    10d4:	add.2d	v11, v17, v11
    10d8:	tbz	w24, #0x4, 0xef4
    10dc:	fmov	x9, d11
    10e0:	ld1.s	{ v9 }[0], [x9]
    10e4:	tbz	w24, #0x5, 0xef8
    10e8:	mov.d	x9, v11[1]
    10ec:	ld1.s	{ v9 }[1], [x9]
    10f0:	add.2d	v10, v10, v18
    10f4:	shl.2d	v10, v10, #0x2
    10f8:	add.2d	v10, v17, v10
    10fc:	tbz	w24, #0x6, 0xf08
    1100:	fmov	x9, d10
    1104:	ld1.s	{ v9 }[2], [x9]
    1108:	tbnz	w24, #0x7, 0xf0c
    110c:	b	0xf14
    1110:	fmov	x9, d13
    1114:	ldr	s10, [x9]
    1118:	and	w24, w24, #0xff
    111c:	tbz	w24, #0x1, 0xf50
    1120:	mov.d	x9, v13[1]
    1124:	ld1.s	{ v10 }[1], [x9]
    1128:	add.2d	v13, v12, v19
    112c:	shl.2d	v13, v13, #0x2
    1130:	add.2d	v13, v17, v13
    1134:	tbz	w24, #0x2, 0xf60
    1138:	fmov	x9, d13
    113c:	ld1.s	{ v10 }[2], [x9]
    1140:	tbz	w24, #0x3, 0xf64
    1144:	mov.d	x9, v13[1]
    1148:	ld1.s	{ v10 }[3], [x9]
    114c:	add.2d	v13, v12, v20
    1150:	shl.2d	v13, v13, #0x2
    1154:	add.2d	v13, v17, v13
    1158:	tbz	w24, #0x4, 0xf74
    115c:	fmov	x9, d13
    1160:	ld1.s	{ v11 }[0], [x9]
    1164:	tbz	w24, #0x5, 0xf78
    1168:	mov.d	x9, v13[1]
    116c:	ld1.s	{ v11 }[1], [x9]
    1170:	add.2d	v12, v12, v18
    1174:	shl.2d	v12, v12, #0x2
    1178:	add.2d	v12, v17, v12
    117c:	tbz	w24, #0x6, 0xf88
    1180:	fmov	x9, d12
    1184:	ld1.s	{ v11 }[2], [x9]
    1188:	tbnz	w24, #0x7, 0xf8c
    118c:	b	0xf94
    1190:	fmov	x9, d15
    1194:	ldr	s12, [x9]
    1198:	and	w24, w24, #0xff
    119c:	tbz	w24, #0x1, 0xfd0
    11a0:	mov.d	x9, v15[1]
    11a4:	ld1.s	{ v12 }[1], [x9]
    11a8:	add.2d	v15, v14, v19
    11ac:	shl.2d	v15, v15, #0x2
    11b0:	add.2d	v15, v17, v15
    11b4:	tbz	w24, #0x2, 0xfe0
    11b8:	fmov	x9, d15
    11bc:	ld1.s	{ v12 }[2], [x9]
    11c0:	tbz	w24, #0x3, 0xfe4
    11c4:	mov.d	x9, v15[1]
    11c8:	ld1.s	{ v12 }[3], [x9]
    11cc:	add.2d	v15, v14, v20
    11d0:	shl.2d	v15, v15, #0x2
    11d4:	add.2d	v15, v17, v15
    11d8:	tbz	w24, #0x4, 0xff4
    11dc:	fmov	x9, d15
    11e0:	ld1.s	{ v13 }[0], [x9]
    11e4:	tbz	w24, #0x5, 0xff8
    11e8:	mov.d	x9, v15[1]
    11ec:	ld1.s	{ v13 }[1], [x9]
    11f0:	add.2d	v14, v14, v18
    11f4:	shl.2d	v14, v14, #0x2
    11f8:	add.2d	v14, v17, v14
    11fc:	tbz	w24, #0x6, 0x1008
    1200:	fmov	x9, d14
    1204:	ld1.s	{ v13 }[2], [x9]
    1208:	tbz	w24, #0x7, 0xda8
    120c:	mov.d	x9, v14[1]
    1210:	ld1.s	{ v13 }[3], [x9]
    1214:	b	0xda8
    1218:	mov	x22, #0x0
    121c:	add	x9, x20, x22, lsl #2
    1220:	ld1r.4s	{ v17 }, [x9]
    1224:	add	x9, x21, x22, lsl #5
    1228:	ldp	q30, q31, [x9]
    122c:	bit.16b	v31, v17, v6
    1230:	bif.16b	v17, v30, v7
    1234:	stp	q17, q31, [x9]
    1238:	add	x22, x22, #0x1
    123c:	cmp	x22, #0x1, lsl #12
    1240:	b.ne	0x121c
    1244:	mov	x20, #0x0
    1248:	fadd.4s	v17, v25, v28
    124c:	fadd.4s	v22, v22, v24
    1250:	fadd.4s	v22, v22, v27
    1254:	fadd.4s	v17, v17, v26
    1258:	fadd.4s	v17, v17, v29
    125c:	fadd.4s	v22, v22, v23
    1260:	fmul.4s	v22, v22, v5
    1264:	fmul.4s	v5, v17, v5
    1268:	fadd.4s	v5, v5, v4
    126c:	fadd.4s	v4, v22, v4
    1270:	fsqrt.4s	v17, v4
    1274:	fsqrt.4s	v4, v5
    1278:	and.16b	v4, v7, v4
    127c:	and.16b	v5, v6, v17
    1280:	b	0x1290
    1284:	add	x20, x20, #0x1
    1288:	cmp	x20, #0x1, lsl #12
    128c:	b.eq	0x74
    1290:	fmov	w21, s16
    1294:	dup.2d	v17, x20
    1298:	add.2d	v22, v17, v21
    129c:	add	x9, x7, x20, lsl #5
    12a0:	ldp	q24, q23, [x9]
    12a4:	and.16b	v24, v7, v24
    12a8:	fdiv.4s	v25, v24, v4
    12ac:	add	x9, x9, #0x20, lsl #12
    12b0:	ldp	q26, q24, [x9]
    12b4:	and.16b	v26, v7, v26
    12b8:	fmul.4s	v25, v25, v26
    12bc:	shl.2d	v26, v22, #0x2
    12c0:	dup.2d	v22, x19
    12c4:	add.2d	v26, v22, v26
    12c8:	tbnz	w21, #0x0, 0x132c
    12cc:	and	w21, w21, #0xff
    12d0:	tbnz	w21, #0x1, 0x133c
    12d4:	add.2d	v26, v17, v19
    12d8:	shl.2d	v26, v26, #0x2
    12dc:	add.2d	v26, v22, v26
    12e0:	tbnz	w21, #0x2, 0x1354
    12e4:	tbz	w21, #0x3, 0x12f0
    12e8:	mov.d	x9, v26[1]
    12ec:	st1.s	{ v25 }[3], [x9]
    12f0:	add.2d	v25, v17, v20
    12f4:	and.16b	v23, v6, v23
    12f8:	fdiv.4s	v23, v23, v5
    12fc:	and.16b	v24, v6, v24
    1300:	fmul.4s	v23, v23, v24
    1304:	shl.2d	v24, v25, #0x2
    1308:	add.2d	v24, v22, v24
    130c:	tbnz	w21, #0x4, 0x1364
    1310:	tbnz	w21, #0x5, 0x1370
    1314:	add.2d	v17, v17, v18
    1318:	shl.2d	v17, v17, #0x2
    131c:	add.2d	v17, v22, v17
    1320:	tbnz	w21, #0x6, 0x1388
    1324:	tbz	w21, #0x7, 0x1284
    1328:	b	0x1394
    132c:	fmov	x9, d26
    1330:	str	s25, [x9]
    1334:	and	w21, w21, #0xff
    1338:	tbz	w21, #0x1, 0x12d4
    133c:	mov.d	x9, v26[1]
    1340:	st1.s	{ v25 }[1], [x9]
    1344:	add.2d	v26, v17, v19
    1348:	shl.2d	v26, v26, #0x2
    134c:	add.2d	v26, v22, v26
    1350:	tbz	w21, #0x2, 0x12e4
    1354:	fmov	x9, d26
    1358:	st1.s	{ v25 }[2], [x9]
    135c:	tbnz	w21, #0x3, 0x12e8
    1360:	b	0x12f0
    1364:	fmov	x9, d24
    1368:	str	s23, [x9]
    136c:	tbz	w21, #0x5, 0x1314
    1370:	mov.d	x9, v24[1]
    1374:	st1.s	{ v23 }[1], [x9]
    1378:	add.2d	v17, v17, v18
    137c:	shl.2d	v17, v17, #0x2
    1380:	add.2d	v17, v22, v17
    1384:	tbz	w21, #0x6, 0x1324
    1388:	fmov	x9, d17
    138c:	st1.s	{ v23 }[2], [x9]
    1390:	tbz	w21, #0x7, 0x1284
    1394:	mov.d	x9, v17[1]
    1398:	st1.s	{ v23 }[3], [x9]
    139c:	b	0x1284
    13a0:	fmov	x9, d21
    13a4:	ldr	s22, [x9]
    13a8:	and	w7, w19, #0xff
    13ac:	tbz	w7, #0x1, 0xba8
    13b0:	mov.d	x9, v21[1]
    13b4:	ld1.s	{ v22 }[1], [x9]
    13b8:	ushll2.2d	v21, v18, #0xe
    13bc:	add.2d	v24, v17, v21
    13c0:	tbz	w7, #0x2, 0xbb4
    13c4:	fmov	x9, d24
    13c8:	ld1.s	{ v22 }[2], [x9]
    13cc:	tbz	w7, #0x3, 0xbb8
    13d0:	mov.d	x9, v24[1]
    13d4:	ld1.s	{ v22 }[3], [x9]
    13d8:	orr.16b	v19, v19, v0
    13dc:	and.16b	v19, v6, v19
    13e0:	ushll.2d	v24, v19, #0xe
    13e4:	add.2d	v25, v17, v24
    13e8:	tbz	w7, #0x4, 0xbcc
    13ec:	fmov	x9, d25
    13f0:	ld1.s	{ v23 }[0], [x9]
    13f4:	tbz	w7, #0x5, 0xbd0
    13f8:	mov.d	x9, v25[1]
    13fc:	ld1.s	{ v23 }[1], [x9]
    1400:	ushll2.2d	v25, v19, #0xe
    1404:	add.2d	v26, v17, v25
    1408:	tbz	w7, #0x6, 0xbdc
    140c:	fmov	x9, d26
    1410:	ld1.s	{ v23 }[2], [x9]
    1414:	tbnz	w7, #0x7, 0xbe0
    1418:	b	0xbe8
    141c:	fmov	x9, d29
    1420:	ldr	s26, [x9]
    1424:	and	w21, w21, #0xff
    1428:	tbz	w21, #0x1, 0xc2c
    142c:	mov.d	x9, v29[1]
    1430:	ld1.s	{ v26 }[1], [x9]
    1434:	add.2d	v29, v28, v21
    1438:	tbz	w21, #0x2, 0xc34
    143c:	fmov	x9, d29
    1440:	ld1.s	{ v26 }[2], [x9]
    1444:	tbz	w21, #0x3, 0xc38
    1448:	mov.d	x9, v29[1]
    144c:	ld1.s	{ v26 }[3], [x9]
    1450:	add.2d	v29, v28, v24
    1454:	tbz	w21, #0x4, 0xc40
    1458:	fmov	x9, d29
    145c:	ld1.s	{ v27 }[0], [x9]
    1460:	tbz	w21, #0x5, 0xc44
    1464:	mov.d	x9, v29[1]
    1468:	ld1.s	{ v27 }[1], [x9]
    146c:	add.2d	v28, v28, v25
    1470:	tbz	w21, #0x6, 0xc4c
    1474:	fmov	x9, d28
    1478:	ld1.s	{ v27 }[2], [x9]
    147c:	tbnz	w21, #0x7, 0xc50
    1480:	b	0xc58
    1484:	fmov	x9, d31
    1488:	ldr	s28, [x9]
    148c:	and	w21, w21, #0xff
    1490:	tbz	w21, #0x1, 0xc8c
    1494:	mov.d	x9, v31[1]
    1498:	ld1.s	{ v28 }[1], [x9]
    149c:	add.2d	v31, v30, v21
    14a0:	tbz	w21, #0x2, 0xc94
    14a4:	fmov	x9, d31
    14a8:	ld1.s	{ v28 }[2], [x9]
    14ac:	tbz	w21, #0x3, 0xc98
    14b0:	mov.d	x9, v31[1]
    14b4:	ld1.s	{ v28 }[3], [x9]
    14b8:	add.2d	v31, v30, v24
    14bc:	tbz	w21, #0x4, 0xca0
    14c0:	fmov	x9, d31
    14c4:	ld1.s	{ v29 }[0], [x9]
    14c8:	tbz	w21, #0x5, 0xca4
    14cc:	mov.d	x9, v31[1]
    14d0:	ld1.s	{ v29 }[1], [x9]
    14d4:	add.2d	v30, v30, v25
    14d8:	tbz	w21, #0x6, 0xcac
    14dc:	fmov	x9, d30
    14e0:	ld1.s	{ v29 }[2], [x9]
    14e4:	tbnz	w21, #0x7, 0xcb0
    14e8:	b	0xcb8
    14ec:	fmov	x9, d20
    14f0:	ldr	s30, [x9]
    14f4:	and	w21, w21, #0xff
    14f8:	tbz	w21, #0x1, 0xcec
    14fc:	mov.d	x9, v20[1]
    1500:	ld1.s	{ v30 }[1], [x9]
    1504:	add.2d	v20, v8, v21
    1508:	tbz	w21, #0x2, 0xcf4
    150c:	fmov	x9, d20
    1510:	ld1.s	{ v30 }[2], [x9]
    1514:	tbz	w21, #0x3, 0xcf8
    1518:	mov.d	x9, v20[1]
    151c:	ld1.s	{ v30 }[3], [x9]
    1520:	add.2d	v20, v8, v24
    1524:	tbz	w21, #0x4, 0xd00
    1528:	fmov	x9, d20
    152c:	ld1.s	{ v31 }[0], [x9]
    1530:	tbz	w21, #0x5, 0xd04
    1534:	mov.d	x9, v20[1]
    1538:	ld1.s	{ v31 }[1], [x9]
    153c:	add.2d	v20, v8, v25
    1540:	tbz	w21, #0x6, 0xd0c
    1544:	fmov	x9, d20
    1548:	ld1.s	{ v31 }[2], [x9]
    154c:	tbnz	w21, #0x7, 0xd10
    1550:	b	0xd18
    1554:	ldr	x9, [sp]
    1558:	stp	w6, w5, [x9]
    155c:	str	w2, [x9, #0x8]
    1560:	mov	w8, #0x3f8
    1564:	str	w8, [x9, #0x24]
    1568:	ldp	x29, x30, [sp, #0xb0]
    156c:	ldp	x20, x19, [sp, #0xa0]
    1570:	ldp	x22, x21, [sp, #0x90]
    1574:	ldp	x24, x23, [sp, #0x80]
    1578:	ldp	x26, x25, [sp, #0x70]
    157c:	ldp	x28, x27, [sp, #0x60]
    1580:	ldp	d9, d8, [sp, #0x50]
    1584:	ldp	d11, d10, [sp, #0x40]
    1588:	ldp	d13, d12, [sp, #0x30]
    158c:	ldp	d15, d14, [sp, #0x20]
    1590:	add	sp, sp, #0xc0
    1594:	ret

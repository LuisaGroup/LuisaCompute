; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 131072
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.spill = alloca float, align 4
  store float 0.000000e+00, ptr %.spill, align 4
  %.spill5 = alloca i64, align 8
  store i64 0, ptr %.spill5, align 4
  %.spill6 = alloca i64, align 8
  store i64 0, ptr %.spill6, align 4
  %.spill7 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill7, align 64
  %.spill8 = alloca i64, align 8
  store i64 0, ptr %.spill8, align 4
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.slot9 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot9, align 32
  %.slot10 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot10, align 32
  %.slot11 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot11, align 32
  %.slot12 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot12, align 32
  %.spill13 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill13, align 32
  %tile_snapshot.spill14 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill14, align 64
  %.slot15 = alloca i64, align 8
  store i64 0, ptr %.slot15, align 4
  %.spill16 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill16, align 32
  %.slot17 = alloca i64, align 8
  store i64 0, ptr %.slot17, align 4
  %6 = getelementptr i8, ptr %argument_buffer, i64 0
  %7 = load ptr, ptr %6, align 16
  %8 = getelementptr i8, ptr %6, i64 8
  %9 = load i64, ptr %8, align 8
  %10 = insertvalue { ptr, i64 } poison, ptr %7, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %9, 1
  %12 = getelementptr i8, ptr %argument_buffer, i64 16
  %13 = load ptr, ptr %12, align 16
  %14 = getelementptr i8, ptr %12, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = insertvalue { ptr, i64 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i64 } %16, i64 %15, 1
  %18 = getelementptr i8, ptr %argument_buffer, i64 32
  %19 = load ptr, ptr %18, align 16
  %20 = getelementptr i8, ptr %18, i64 8
  %21 = load i64, ptr %20, align 8
  %22 = insertvalue { ptr, i64 } poison, ptr %19, 0
  %23 = insertvalue { ptr, i64 } %22, i64 %21, 1
  %24 = getelementptr i8, ptr %argument_buffer, i64 48
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = load i32, ptr %launch_config, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 12
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 4
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 16
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 8
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 20
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 36
  %42 = load i32, ptr %41, align 4
  %.splatinsert18 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat19 = shufflevector <8 x i32> %.splatinsert18, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat19, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %44 = mul i32 %30, 1024
  %.splatinsert20 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat21 = shufflevector <8 x i32> %.splatinsert20, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat21, %43
  %46 = mul i32 %34, 1
  %.splatinsert22 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat23 = shufflevector <8 x i32> %.splatinsert22, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat23, zeroinitializer
  %48 = mul i32 %38, 1
  %.splatinsert24 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat25 = shufflevector <8 x i32> %.splatinsert24, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat25, zeroinitializer
  %50 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %45, 0
  %51 = insertvalue [3 x <8 x i32>] %50, <8 x i32> %47, 1
  %52 = insertvalue [3 x <8 x i32>] %51, <8 x i32> %49, 2
  %.splatinsert26 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat27 = shufflevector <8 x i32> %.splatinsert26, <8 x i32> poison, <8 x i32> zeroinitializer
  %53 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat27
  %54 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  br i1 %54, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %55 = extractvalue [3 x <8 x i32>] %52, 0
  %56 = zext <8 x i32> %55 to <8 x i64>
  %57 = select <8 x i1> %53, <8 x i64> %56, <8 x i64> zeroinitializer
  %58 = select <8 x i1> %53, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %59 = sdiv <8 x i64> %57, %58
  %60 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %61 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %62 = extractvalue { <8 x ptr>, <8 x i64> } %60, 0
  %63 = select <8 x i1> %53, <8 x ptr> %61, <8 x ptr> %62
  %64 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %65 = extractvalue { <8 x ptr>, <8 x i64> } %60, 1
  %66 = select <8 x i1> %53, <8 x i64> %64, <8 x i64> %65
  %67 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %63, 0
  %68 = insertvalue { <8 x ptr>, <8 x i64> } %67, <8 x i64> %66, 1
  store { <8 x ptr>, <8 x i64> } %68, ptr %tile_snapshot.spill, align 64
  store float 0.000000e+00, ptr %.spill, align 4
  store i64 0, ptr %.spill5, align 4
  store i64 0, ptr %.spill6, align 4
  %69 = add <8 x i64> %59, zeroinitializer
  %70 = add <8 x i64> zeroinitializer, %69
  %71 = mul <8 x i64> %70, splat (i64 4096)
  %72 = load <8 x i64>, ptr %.spill7, align 64
  %73 = select <8 x i1> %53, <8 x i64> %71, <8 x i64> %72
  store <8 x i64> %73, ptr %.spill7, align 64
  %74 = add <8 x i64> %71, zeroinitializer
  %75 = extractvalue { ptr, i64 } %11, 0
  %76 = mul <8 x i64> %74, splat (i64 4)
  %77 = getelementptr i8, ptr %75, <8 x i64> %76
  %78 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %77, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %79 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %80 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %81 = add <8 x i64> %80, zeroinitializer
  %82 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %79, 0
  %83 = insertvalue { <8 x ptr>, <8 x i64> } %82, <8 x i64> %81, 1
  %84 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %85 = extractvalue { <8 x ptr>, <8 x i64> } %83, 1
  %86 = extractelement <8 x ptr> %84, i32 0
  %87 = extractelement <8 x i64> %85, i32 0
  %88 = sub i64 %87, 0
  %89 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %90 = select i1 %89, i64 %88, i64 0
  %private.contiguous.address = getelementptr i8, ptr %86, i64 %90
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %91 = select <8 x i1> %53, <8 x float> %78, <8 x float> %private.contiguous.preserve
  store <8 x float> %91, ptr %private.contiguous.address, align 4
  store i64 0, ptr %.spill8, align 4
  %92 = fmul <8 x float> %78, %78
  %93 = add <8 x i64> %71, splat (i64 1)
  %94 = extractvalue { ptr, i64 } %11, 0
  %95 = mul <8 x i64> %93, splat (i64 4)
  %96 = getelementptr i8, ptr %94, <8 x i64> %95
  %97 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %96, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %99 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %100 = add <8 x i64> %99, splat (i64 32)
  %101 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %98, 0
  %102 = insertvalue { <8 x ptr>, <8 x i64> } %101, <8 x i64> %100, 1
  %103 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %104 = extractvalue { <8 x ptr>, <8 x i64> } %102, 1
  %105 = extractelement <8 x ptr> %103, i32 0
  %106 = extractelement <8 x i64> %104, i32 0
  %107 = sub i64 %106, 0
  %108 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %109 = select i1 %108, i64 %107, i64 0
  %private.contiguous.address28 = getelementptr i8, ptr %105, i64 %109
  %private.contiguous.preserve29 = load <8 x float>, ptr %private.contiguous.address28, align 4
  %110 = select <8 x i1> %53, <8 x float> %97, <8 x float> %private.contiguous.preserve29
  store <8 x float> %110, ptr %private.contiguous.address28, align 4
  %111 = fmul <8 x float> %97, %97
  %112 = add <8 x i64> %71, splat (i64 2)
  %113 = extractvalue { ptr, i64 } %11, 0
  %114 = mul <8 x i64> %112, splat (i64 4)
  %115 = getelementptr i8, ptr %113, <8 x i64> %114
  %116 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %115, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %117 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %118 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %119 = add <8 x i64> %118, splat (i64 64)
  %120 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %117, 0
  %121 = insertvalue { <8 x ptr>, <8 x i64> } %120, <8 x i64> %119, 1
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %123 = extractvalue { <8 x ptr>, <8 x i64> } %121, 1
  %124 = extractelement <8 x ptr> %122, i32 0
  %125 = extractelement <8 x i64> %123, i32 0
  %126 = sub i64 %125, 0
  %127 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %128 = select i1 %127, i64 %126, i64 0
  %private.contiguous.address30 = getelementptr i8, ptr %124, i64 %128
  %private.contiguous.preserve31 = load <8 x float>, ptr %private.contiguous.address30, align 4
  %129 = select <8 x i1> %53, <8 x float> %116, <8 x float> %private.contiguous.preserve31
  store <8 x float> %129, ptr %private.contiguous.address30, align 4
  %130 = fmul <8 x float> %116, %116
  %131 = add <8 x i64> %71, splat (i64 3)
  %132 = extractvalue { ptr, i64 } %11, 0
  %133 = mul <8 x i64> %131, splat (i64 4)
  %134 = getelementptr i8, ptr %132, <8 x i64> %133
  %135 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %134, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %136 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %138 = add <8 x i64> %137, splat (i64 96)
  %139 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %136, 0
  %140 = insertvalue { <8 x ptr>, <8 x i64> } %139, <8 x i64> %138, 1
  %141 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %140, 1
  %143 = extractelement <8 x ptr> %141, i32 0
  %144 = extractelement <8 x i64> %142, i32 0
  %145 = sub i64 %144, 0
  %146 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %147 = select i1 %146, i64 %145, i64 0
  %private.contiguous.address32 = getelementptr i8, ptr %143, i64 %147
  %private.contiguous.preserve33 = load <8 x float>, ptr %private.contiguous.address32, align 4
  %148 = select <8 x i1> %53, <8 x float> %135, <8 x float> %private.contiguous.preserve33
  store <8 x float> %148, ptr %private.contiguous.address32, align 4
  %149 = fmul <8 x float> %135, %135
  store i64 4, ptr %.slot, align 4
  %150 = load <8 x float>, ptr %.slot9, align 32
  %151 = select <8 x i1> %53, <8 x float> %92, <8 x float> %150
  store <8 x float> %151, ptr %.slot9, align 32
  %152 = load <8 x float>, ptr %.slot10, align 32
  %153 = select <8 x i1> %53, <8 x float> %111, <8 x float> %152
  store <8 x float> %153, ptr %.slot10, align 32
  %154 = load <8 x float>, ptr %.slot11, align 32
  %155 = select <8 x i1> %53, <8 x float> %130, <8 x float> %154
  store <8 x float> %155, ptr %.slot11, align 32
  %156 = load <8 x float>, ptr %.slot12, align 32
  %157 = select <8 x i1> %53, <8 x float> %149, <8 x float> %156
  store <8 x float> %157, ptr %.slot12, align 32
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %158 = icmp slt i64 %.state, 4096
  br i1 %158, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state34 = load i64, ptr %.slot, align 4
  %159 = add i64 %.state34, 0
  %160 = sdiv i64 %159, 1
  %.spill.load = load i64, ptr %.spill6, align 4
  %161 = add i64 %.spill.load, %160
  %162 = add i64 0, %161
  %.spill.load35 = load <8 x i64>, ptr %.spill7, align 64
  %.splatinsert36 = insertelement <8 x i64> poison, i64 %162, i64 0
  %.splat37 = shufflevector <8 x i64> %.splatinsert36, <8 x i64> poison, <8 x i32> zeroinitializer
  %163 = add <8 x i64> %.spill.load35, %.splat37
  %164 = extractvalue { ptr, i64 } %11, 0
  %165 = mul <8 x i64> %163, splat (i64 4)
  %166 = getelementptr i8, ptr %164, <8 x i64> %165
  %167 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %166, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %168 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.splatinsert38 = insertelement <8 x i64> poison, i64 %161, i64 0
  %.splat39 = shufflevector <8 x i64> %.splatinsert38, <8 x i64> poison, <8 x i32> zeroinitializer
  %170 = mul <8 x i64> %.splat39, splat (i64 32)
  %171 = add <8 x i64> %169, %170
  %172 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %168, 0
  %173 = insertvalue { <8 x ptr>, <8 x i64> } %172, <8 x i64> %171, 1
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %173, 1
  %176 = extractelement <8 x ptr> %174, i32 0
  %177 = extractelement <8 x i64> %175, i32 0
  %178 = sub i64 %177, 0
  %179 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %180 = select i1 %179, i64 %178, i64 0
  %private.contiguous.address40 = getelementptr i8, ptr %176, i64 %180
  %private.contiguous.preserve41 = load <8 x float>, ptr %private.contiguous.address40, align 4
  %181 = select <8 x i1> %53, <8 x float> %167, <8 x float> %private.contiguous.preserve41
  store <8 x float> %181, ptr %private.contiguous.address40, align 4
  %182 = fmul <8 x float> %167, %167
  %.state42 = load <8 x float>, ptr %.slot9, align 32
  %183 = fadd <8 x float> %.state42, %182
  %.state43 = load i64, ptr %.slot, align 4
  %184 = add i64 %.state43, 1
  %185 = sdiv i64 %184, 1
  %.spill.load44 = load i64, ptr %.spill6, align 4
  %186 = add i64 %.spill.load44, %185
  %187 = add i64 0, %186
  %.spill.load45 = load <8 x i64>, ptr %.spill7, align 64
  %.splatinsert46 = insertelement <8 x i64> poison, i64 %187, i64 0
  %.splat47 = shufflevector <8 x i64> %.splatinsert46, <8 x i64> poison, <8 x i32> zeroinitializer
  %188 = add <8 x i64> %.spill.load45, %.splat47
  %189 = extractvalue { ptr, i64 } %11, 0
  %190 = mul <8 x i64> %188, splat (i64 4)
  %191 = getelementptr i8, ptr %189, <8 x i64> %190
  %192 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %191, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load48 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load48, 0
  %194 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load48, 1
  %.splatinsert49 = insertelement <8 x i64> poison, i64 %186, i64 0
  %.splat50 = shufflevector <8 x i64> %.splatinsert49, <8 x i64> poison, <8 x i32> zeroinitializer
  %195 = mul <8 x i64> %.splat50, splat (i64 32)
  %196 = add <8 x i64> %194, %195
  %197 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %193, 0
  %198 = insertvalue { <8 x ptr>, <8 x i64> } %197, <8 x i64> %196, 1
  %199 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %200 = extractvalue { <8 x ptr>, <8 x i64> } %198, 1
  %201 = extractelement <8 x ptr> %199, i32 0
  %202 = extractelement <8 x i64> %200, i32 0
  %203 = sub i64 %202, 0
  %204 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %205 = select i1 %204, i64 %203, i64 0
  %private.contiguous.address51 = getelementptr i8, ptr %201, i64 %205
  %private.contiguous.preserve52 = load <8 x float>, ptr %private.contiguous.address51, align 4
  %206 = select <8 x i1> %53, <8 x float> %192, <8 x float> %private.contiguous.preserve52
  store <8 x float> %206, ptr %private.contiguous.address51, align 4
  %207 = fmul <8 x float> %192, %192
  %.state53 = load <8 x float>, ptr %.slot10, align 32
  %208 = fadd <8 x float> %.state53, %207
  %.state54 = load i64, ptr %.slot, align 4
  %209 = add i64 %.state54, 2
  %210 = sdiv i64 %209, 1
  %.spill.load55 = load i64, ptr %.spill6, align 4
  %211 = add i64 %.spill.load55, %210
  %212 = add i64 0, %211
  %.spill.load56 = load <8 x i64>, ptr %.spill7, align 64
  %.splatinsert57 = insertelement <8 x i64> poison, i64 %212, i64 0
  %.splat58 = shufflevector <8 x i64> %.splatinsert57, <8 x i64> poison, <8 x i32> zeroinitializer
  %213 = add <8 x i64> %.spill.load56, %.splat58
  %214 = extractvalue { ptr, i64 } %11, 0
  %215 = mul <8 x i64> %213, splat (i64 4)
  %216 = getelementptr i8, ptr %214, <8 x i64> %215
  %217 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %216, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load59 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %218 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load59, 0
  %219 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load59, 1
  %.splatinsert60 = insertelement <8 x i64> poison, i64 %211, i64 0
  %.splat61 = shufflevector <8 x i64> %.splatinsert60, <8 x i64> poison, <8 x i32> zeroinitializer
  %220 = mul <8 x i64> %.splat61, splat (i64 32)
  %221 = add <8 x i64> %219, %220
  %222 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %218, 0
  %223 = insertvalue { <8 x ptr>, <8 x i64> } %222, <8 x i64> %221, 1
  %224 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %225 = extractvalue { <8 x ptr>, <8 x i64> } %223, 1
  %226 = extractelement <8 x ptr> %224, i32 0
  %227 = extractelement <8 x i64> %225, i32 0
  %228 = sub i64 %227, 0
  %229 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %230 = select i1 %229, i64 %228, i64 0
  %private.contiguous.address62 = getelementptr i8, ptr %226, i64 %230
  %private.contiguous.preserve63 = load <8 x float>, ptr %private.contiguous.address62, align 4
  %231 = select <8 x i1> %53, <8 x float> %217, <8 x float> %private.contiguous.preserve63
  store <8 x float> %231, ptr %private.contiguous.address62, align 4
  %232 = fmul <8 x float> %217, %217
  %.state64 = load <8 x float>, ptr %.slot11, align 32
  %233 = fadd <8 x float> %.state64, %232
  %.state65 = load i64, ptr %.slot, align 4
  %234 = add i64 %.state65, 3
  %235 = sdiv i64 %234, 1
  %.spill.load66 = load i64, ptr %.spill6, align 4
  %236 = add i64 %.spill.load66, %235
  %237 = add i64 0, %236
  %.spill.load67 = load <8 x i64>, ptr %.spill7, align 64
  %.splatinsert68 = insertelement <8 x i64> poison, i64 %237, i64 0
  %.splat69 = shufflevector <8 x i64> %.splatinsert68, <8 x i64> poison, <8 x i32> zeroinitializer
  %238 = add <8 x i64> %.spill.load67, %.splat69
  %239 = extractvalue { ptr, i64 } %11, 0
  %240 = mul <8 x i64> %238, splat (i64 4)
  %241 = getelementptr i8, ptr %239, <8 x i64> %240
  %242 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %241, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load70 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %243 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load70, 0
  %244 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load70, 1
  %.splatinsert71 = insertelement <8 x i64> poison, i64 %236, i64 0
  %.splat72 = shufflevector <8 x i64> %.splatinsert71, <8 x i64> poison, <8 x i32> zeroinitializer
  %245 = mul <8 x i64> %.splat72, splat (i64 32)
  %246 = add <8 x i64> %244, %245
  %247 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %243, 0
  %248 = insertvalue { <8 x ptr>, <8 x i64> } %247, <8 x i64> %246, 1
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %250 = extractvalue { <8 x ptr>, <8 x i64> } %248, 1
  %251 = extractelement <8 x ptr> %249, i32 0
  %252 = extractelement <8 x i64> %250, i32 0
  %253 = sub i64 %252, 0
  %254 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %255 = select i1 %254, i64 %253, i64 0
  %private.contiguous.address73 = getelementptr i8, ptr %251, i64 %255
  %private.contiguous.preserve74 = load <8 x float>, ptr %private.contiguous.address73, align 4
  %256 = select <8 x i1> %53, <8 x float> %242, <8 x float> %private.contiguous.preserve74
  store <8 x float> %256, ptr %private.contiguous.address73, align 4
  %257 = fmul <8 x float> %242, %242
  %.state75 = load <8 x float>, ptr %.slot12, align 32
  %258 = fadd <8 x float> %.state75, %257
  %.state76 = load i64, ptr %.slot, align 4
  %259 = add i64 %.state76, 4
  store i64 %259, ptr %.slot, align 4
  %260 = load <8 x float>, ptr %.slot9, align 32
  %261 = select <8 x i1> %53, <8 x float> %183, <8 x float> %260
  store <8 x float> %261, ptr %.slot9, align 32
  %262 = load <8 x float>, ptr %.slot10, align 32
  %263 = select <8 x i1> %53, <8 x float> %208, <8 x float> %262
  store <8 x float> %263, ptr %.slot10, align 32
  %264 = load <8 x float>, ptr %.slot11, align 32
  %265 = select <8 x i1> %53, <8 x float> %233, <8 x float> %264
  store <8 x float> %265, ptr %.slot11, align 32
  %266 = load <8 x float>, ptr %.slot12, align 32
  %267 = select <8 x i1> %53, <8 x float> %258, <8 x float> %266
  store <8 x float> %267, ptr %.slot12, align 32
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %.spill.load77 = load float, ptr %.spill, align 4
  %.splatinsert78 = insertelement <8 x float> poison, float %.spill.load77, i64 0
  %.splat79 = shufflevector <8 x float> %.splatinsert78, <8 x float> poison, <8 x i32> zeroinitializer
  %.state80 = load <8 x float>, ptr %.slot9, align 32
  %268 = fadd <8 x float> %.splat79, %.state80
  %.state81 = load <8 x float>, ptr %.slot10, align 32
  %269 = fadd <8 x float> %268, %.state81
  %.state82 = load <8 x float>, ptr %.slot11, align 32
  %270 = fadd <8 x float> %269, %.state82
  %.state83 = load <8 x float>, ptr %.slot12, align 32
  %271 = fadd <8 x float> %270, %.state83
  %272 = fdiv <8 x float> %271, splat (float 4.096000e+03)
  %273 = load <8 x float>, ptr %.spill13, align 32
  %274 = select <8 x i1> %53, <8 x float> %272, <8 x float> %273
  store <8 x float> %274, ptr %.spill13, align 32
  %275 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %276 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %277 = extractvalue { <8 x ptr>, <8 x i64> } %275, 0
  %278 = select <8 x i1> %53, <8 x ptr> %276, <8 x ptr> %277
  %279 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %280 = extractvalue { <8 x ptr>, <8 x i64> } %275, 1
  %281 = select <8 x i1> %53, <8 x i64> %279, <8 x i64> %280
  %282 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %278, 0
  %283 = insertvalue { <8 x ptr>, <8 x i64> } %282, <8 x i64> %281, 1
  store { <8 x ptr>, <8 x i64> } %283, ptr %tile_snapshot.spill14, align 64
  store i64 0, ptr %.slot15, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state84 = load i64, ptr %.slot15, align 4
  %284 = icmp slt i64 %.state84, 4096
  br i1 %284, label %direct.true85, label %direct.false86

direct.schedule.5:                                ; preds = %direct.true85
  %.spill.load87 = load i64, ptr %.spill5, align 4
  %285 = add i64 %.spill.load87, 0
  %.state88 = load i64, ptr %.slot15, align 4
  %286 = add i64 0, %.state88
  %287 = mul i64 %285, 4096
  %288 = add i64 %287, %286
  %289 = extractvalue { ptr, i64 } %17, 0
  %290 = mul i64 %288, 4
  %291 = getelementptr i8, ptr %289, i64 %290
  %292 = load float, ptr %291, align 4
  %.splatinsert89 = insertelement <8 x float> poison, float %292, i64 0
  %.splat90 = shufflevector <8 x float> %.splatinsert89, <8 x float> poison, <8 x i32> zeroinitializer
  %tile_snapshot.spill.load91 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load91, 0
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load91, 1
  %.state92 = load i64, ptr %.slot15, align 4
  %.splatinsert93 = insertelement <8 x i64> poison, i64 %.state92, i64 0
  %.splat94 = shufflevector <8 x i64> %.splatinsert93, <8 x i64> poison, <8 x i32> zeroinitializer
  %295 = mul <8 x i64> %.splat94, splat (i64 32)
  %296 = add <8 x i64> %294, %295
  %297 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %293, 0
  %298 = insertvalue { <8 x ptr>, <8 x i64> } %297, <8 x i64> %296, 1
  %299 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %298, 1
  %301 = extractelement <8 x ptr> %299, i32 0
  %302 = extractelement <8 x i64> %300, i32 0
  %303 = sub i64 %302, 0
  %304 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %305 = select i1 %304, i64 %303, i64 0
  %private.contiguous.address95 = getelementptr i8, ptr %301, i64 %305
  %private.contiguous.preserve96 = load <8 x float>, ptr %private.contiguous.address95, align 4
  %306 = select <8 x i1> %53, <8 x float> %.splat90, <8 x float> %private.contiguous.preserve96
  store <8 x float> %306, ptr %private.contiguous.address95, align 4
  %.state97 = load i64, ptr %.slot15, align 4
  %307 = add i64 %.state97, 1
  store i64 %307, ptr %.slot15, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false86
  %.spill.load98 = load <8 x float>, ptr %.spill13, align 32
  %308 = fadd <8 x float> %.spill.load98, splat (float 0x3EE4F8B580000000)
  %309 = call <8 x float> @llvm.sqrt.v8f32(<8 x float> %308)
  %310 = load <8 x float>, ptr %.spill16, align 32
  %311 = select <8 x i1> %53, <8 x float> %309, <8 x float> %310
  store <8 x float> %311, ptr %.spill16, align 32
  store i64 0, ptr %.slot17, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state99 = load i64, ptr %.slot17, align 4
  %312 = icmp slt i64 %.state99, 4096
  br i1 %312, label %direct.true100, label %direct.false101

direct.schedule.8:                                ; preds = %direct.true100
  %.state102 = load i64, ptr %.slot17, align 4
  %313 = add i64 0, %.state102
  %.spill.load103 = load <8 x i64>, ptr %.spill7, align 64
  %.splatinsert104 = insertelement <8 x i64> poison, i64 %313, i64 0
  %.splat105 = shufflevector <8 x i64> %.splatinsert104, <8 x i64> poison, <8 x i32> zeroinitializer
  %314 = add <8 x i64> %.spill.load103, %.splat105
  %.spill.load106 = load i64, ptr %.spill8, align 4
  %.state107 = load i64, ptr %.slot17, align 4
  %315 = add i64 %.spill.load106, %.state107
  %.spill.load108 = load i64, ptr %.spill8, align 4
  %316 = add i64 %.spill.load108, %315
  %tile_snapshot.spill.load109 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %317 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load109, 0
  %318 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load109, 1
  %.splatinsert110 = insertelement <8 x i64> poison, i64 %316, i64 0
  %.splat111 = shufflevector <8 x i64> %.splatinsert110, <8 x i64> poison, <8 x i32> zeroinitializer
  %319 = mul <8 x i64> %.splat111, splat (i64 32)
  %320 = add <8 x i64> %318, %319
  %321 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %317, 0
  %322 = insertvalue { <8 x ptr>, <8 x i64> } %321, <8 x i64> %320, 1
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %322, 1
  %325 = extractelement <8 x ptr> %323, i32 0
  %326 = extractelement <8 x i64> %324, i32 0
  %327 = sub i64 %326, 0
  %328 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %329 = select i1 %328, i64 %327, i64 0
  %private.contiguous.address112 = getelementptr i8, ptr %325, i64 %329
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address112, align 4
  %330 = select <8 x i1> %53, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %.spill.load113 = load <8 x float>, ptr %.spill16, align 32
  %331 = fdiv <8 x float> %330, %.spill.load113
  %tile_snapshot.spill.load114 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %332 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load114, 0
  %333 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load114, 1
  %.splatinsert115 = insertelement <8 x i64> poison, i64 %315, i64 0
  %.splat116 = shufflevector <8 x i64> %.splatinsert115, <8 x i64> poison, <8 x i32> zeroinitializer
  %334 = mul <8 x i64> %.splat116, splat (i64 32)
  %335 = add <8 x i64> %333, %334
  %336 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %332, 0
  %337 = insertvalue { <8 x ptr>, <8 x i64> } %336, <8 x i64> %335, 1
  %338 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %339 = extractvalue { <8 x ptr>, <8 x i64> } %337, 1
  %340 = extractelement <8 x ptr> %338, i32 0
  %341 = extractelement <8 x i64> %339, i32 0
  %342 = sub i64 %341, 0
  %343 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %344 = select i1 %343, i64 %342, i64 0
  %private.contiguous.address117 = getelementptr i8, ptr %340, i64 %344
  %private.contiguous.load118 = load <8 x float>, ptr %private.contiguous.address117, align 4
  %345 = select <8 x i1> %53, <8 x float> %private.contiguous.load118, <8 x float> zeroinitializer
  %346 = fmul <8 x float> %331, %345
  %347 = extractvalue { ptr, i64 } %29, 0
  %348 = mul <8 x i64> %314, splat (i64 4)
  %349 = getelementptr i8, ptr %347, <8 x i64> %348
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %346, <8 x ptr> %349, i32 1, <8 x i1> %53)
  %.state119 = load i64, ptr %.slot17, align 4
  %350 = add i64 %.state119, 1
  store i64 %350, ptr %.slot17, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false101
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true85:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false86:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true100:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false101:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.9
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.sqrt.v8f32(<8 x float>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #2

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 131072
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.spill = alloca float, align 4
  store float 0.000000e+00, ptr %.spill, align 4
  %.spill5 = alloca i64, align 8
  store i64 0, ptr %.spill5, align 4
  %.spill6 = alloca i64, align 8
  store i64 0, ptr %.spill6, align 4
  %.spill7 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill7, align 64
  %.spill8 = alloca i64, align 8
  store i64 0, ptr %.spill8, align 4
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.slot9 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot9, align 32
  %.slot10 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot10, align 32
  %.slot11 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot11, align 32
  %.slot12 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot12, align 32
  %.spill13 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill13, align 32
  %tile_snapshot.spill14 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill14, align 64
  %.slot15 = alloca i64, align 8
  store i64 0, ptr %.slot15, align 4
  %.spill16 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill16, align 32
  %.slot17 = alloca i64, align 8
  store i64 0, ptr %.slot17, align 4
  %6 = getelementptr i8, ptr %argument_buffer, i64 0
  %7 = load ptr, ptr %6, align 16
  %8 = getelementptr i8, ptr %6, i64 8
  %9 = load i64, ptr %8, align 8
  %10 = insertvalue { ptr, i64 } poison, ptr %7, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %9, 1
  %12 = getelementptr i8, ptr %argument_buffer, i64 16
  %13 = load ptr, ptr %12, align 16
  %14 = getelementptr i8, ptr %12, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = insertvalue { ptr, i64 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i64 } %16, i64 %15, 1
  %18 = getelementptr i8, ptr %argument_buffer, i64 32
  %19 = load ptr, ptr %18, align 16
  %20 = getelementptr i8, ptr %18, i64 8
  %21 = load i64, ptr %20, align 8
  %22 = insertvalue { ptr, i64 } poison, ptr %19, 0
  %23 = insertvalue { ptr, i64 } %22, i64 %21, 1
  %24 = getelementptr i8, ptr %argument_buffer, i64 48
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = load i32, ptr %launch_config, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 12
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 4
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 16
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 8
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 20
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 36
  %42 = load i32, ptr %41, align 4
  %.splatinsert18 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat19 = shufflevector <8 x i32> %.splatinsert18, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat19, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %44 = mul i32 %30, 1024
  %.splatinsert20 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat21 = shufflevector <8 x i32> %.splatinsert20, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat21, %43
  %46 = mul i32 %34, 1
  %.splatinsert22 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat23 = shufflevector <8 x i32> %.splatinsert22, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat23, zeroinitializer
  %48 = mul i32 %38, 1
  %.splatinsert24 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat25 = shufflevector <8 x i32> %.splatinsert24, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat25, zeroinitializer
  %50 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %45, 0
  %51 = insertvalue [3 x <8 x i32>] %50, <8 x i32> %47, 1
  %52 = insertvalue [3 x <8 x i32>] %51, <8 x i32> %49, 2
  %.splatinsert26 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat27 = shufflevector <8 x i32> %.splatinsert26, <8 x i32> poison, <8 x i32> zeroinitializer
  %53 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat27
  %54 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  br i1 %54, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %55 = extractvalue [3 x <8 x i32>] %52, 0
  %56 = zext <8 x i32> %55 to <8 x i64>
  %57 = select <8 x i1> %53, <8 x i64> %56, <8 x i64> zeroinitializer
  %58 = select <8 x i1> %53, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %59 = sdiv <8 x i64> %57, %58
  %60 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %61 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %62 = extractvalue { <8 x ptr>, <8 x i64> } %60, 0
  %63 = select <8 x i1> %53, <8 x ptr> %61, <8 x ptr> %62
  %64 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %65 = extractvalue { <8 x ptr>, <8 x i64> } %60, 1
  %66 = select <8 x i1> %53, <8 x i64> %64, <8 x i64> %65
  %67 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %63, 0
  %68 = insertvalue { <8 x ptr>, <8 x i64> } %67, <8 x i64> %66, 1
  store { <8 x ptr>, <8 x i64> } %68, ptr %tile_snapshot.spill, align 64
  store float 0.000000e+00, ptr %.spill, align 4
  store i64 0, ptr %.spill5, align 4
  store i64 0, ptr %.spill6, align 4
  %69 = add <8 x i64> %59, zeroinitializer
  %70 = add <8 x i64> zeroinitializer, %69
  %71 = mul <8 x i64> %70, splat (i64 4096)
  %72 = load <8 x i64>, ptr %.spill7, align 64
  %73 = select <8 x i1> %53, <8 x i64> %71, <8 x i64> %72
  store <8 x i64> %73, ptr %.spill7, align 64
  %74 = add <8 x i64> %71, zeroinitializer
  %75 = extractvalue { ptr, i64 } %11, 0
  %76 = mul <8 x i64> %74, splat (i64 4)
  %77 = getelementptr i8, ptr %75, <8 x i64> %76
  %78 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %77, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %79 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %80 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %81 = add <8 x i64> %80, zeroinitializer
  %82 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %79, 0
  %83 = insertvalue { <8 x ptr>, <8 x i64> } %82, <8 x i64> %81, 1
  %84 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %85 = extractvalue { <8 x ptr>, <8 x i64> } %83, 1
  %86 = extractelement <8 x ptr> %84, i32 0
  %87 = extractelement <8 x i64> %85, i32 0
  %88 = sub i64 %87, 0
  %89 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %90 = select i1 %89, i64 %88, i64 0
  %private.contiguous.address = getelementptr i8, ptr %86, i64 %90
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %91 = select <8 x i1> %53, <8 x float> %78, <8 x float> %private.contiguous.preserve
  store <8 x float> %91, ptr %private.contiguous.address, align 4
  store i64 0, ptr %.spill8, align 4
  %92 = fmul <8 x float> %78, %78
  %93 = add <8 x i64> %71, splat (i64 1)
  %94 = extractvalue { ptr, i64 } %11, 0
  %95 = mul <8 x i64> %93, splat (i64 4)
  %96 = getelementptr i8, ptr %94, <8 x i64> %95
  %97 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %96, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %99 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %100 = add <8 x i64> %99, splat (i64 32)
  %101 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %98, 0
  %102 = insertvalue { <8 x ptr>, <8 x i64> } %101, <8 x i64> %100, 1
  %103 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %104 = extractvalue { <8 x ptr>, <8 x i64> } %102, 1
  %105 = extractelement <8 x ptr> %103, i32 0
  %106 = extractelement <8 x i64> %104, i32 0
  %107 = sub i64 %106, 0
  %108 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %109 = select i1 %108, i64 %107, i64 0
  %private.contiguous.address28 = getelementptr i8, ptr %105, i64 %109
  %private.contiguous.preserve29 = load <8 x float>, ptr %private.contiguous.address28, align 4
  %110 = select <8 x i1> %53, <8 x float> %97, <8 x float> %private.contiguous.preserve29
  store <8 x float> %110, ptr %private.contiguous.address28, align 4
  %111 = fmul <8 x float> %97, %97
  %112 = add <8 x i64> %71, splat (i64 2)
  %113 = extractvalue { ptr, i64 } %11, 0
  %114 = mul <8 x i64> %112, splat (i64 4)
  %115 = getelementptr i8, ptr %113, <8 x i64> %114
  %116 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %115, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %117 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %118 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %119 = add <8 x i64> %118, splat (i64 64)
  %120 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %117, 0
  %121 = insertvalue { <8 x ptr>, <8 x i64> } %120, <8 x i64> %119, 1
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %123 = extractvalue { <8 x ptr>, <8 x i64> } %121, 1
  %124 = extractelement <8 x ptr> %122, i32 0
  %125 = extractelement <8 x i64> %123, i32 0
  %126 = sub i64 %125, 0
  %127 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %128 = select i1 %127, i64 %126, i64 0
  %private.contiguous.address30 = getelementptr i8, ptr %124, i64 %128
  %private.contiguous.preserve31 = load <8 x float>, ptr %private.contiguous.address30, align 4
  %129 = select <8 x i1> %53, <8 x float> %116, <8 x float> %private.contiguous.preserve31
  store <8 x float> %129, ptr %private.contiguous.address30, align 4
  %130 = fmul <8 x float> %116, %116
  %131 = add <8 x i64> %71, splat (i64 3)
  %132 = extractvalue { ptr, i64 } %11, 0
  %133 = mul <8 x i64> %131, splat (i64 4)
  %134 = getelementptr i8, ptr %132, <8 x i64> %133
  %135 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %134, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %136 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %138 = add <8 x i64> %137, splat (i64 96)
  %139 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %136, 0
  %140 = insertvalue { <8 x ptr>, <8 x i64> } %139, <8 x i64> %138, 1
  %141 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %140, 1
  %143 = extractelement <8 x ptr> %141, i32 0
  %144 = extractelement <8 x i64> %142, i32 0
  %145 = sub i64 %144, 0
  %146 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %147 = select i1 %146, i64 %145, i64 0
  %private.contiguous.address32 = getelementptr i8, ptr %143, i64 %147
  %private.contiguous.preserve33 = load <8 x float>, ptr %private.contiguous.address32, align 4
  %148 = select <8 x i1> %53, <8 x float> %135, <8 x float> %private.contiguous.preserve33
  store <8 x float> %148, ptr %private.contiguous.address32, align 4
  %149 = fmul <8 x float> %135, %135
  store i64 4, ptr %.slot, align 4
  %150 = load <8 x float>, ptr %.slot9, align 32
  %151 = select <8 x i1> %53, <8 x float> %92, <8 x float> %150
  store <8 x float> %151, ptr %.slot9, align 32
  %152 = load <8 x float>, ptr %.slot10, align 32
  %153 = select <8 x i1> %53, <8 x float> %111, <8 x float> %152
  store <8 x float> %153, ptr %.slot10, align 32
  %154 = load <8 x float>, ptr %.slot11, align 32
  %155 = select <8 x i1> %53, <8 x float> %130, <8 x float> %154
  store <8 x float> %155, ptr %.slot11, align 32
  %156 = load <8 x float>, ptr %.slot12, align 32
  %157 = select <8 x i1> %53, <8 x float> %149, <8 x float> %156
  store <8 x float> %157, ptr %.slot12, align 32
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %158 = icmp slt i64 %.state, 4096
  br i1 %158, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state34 = load i64, ptr %.slot, align 4
  %159 = add i64 %.state34, 0
  %160 = sdiv i64 %159, 1
  %.spill.load = load i64, ptr %.spill6, align 4
  %161 = add i64 %.spill.load, %160
  %162 = add i64 0, %161
  %.spill.load35 = load <8 x i64>, ptr %.spill7, align 64
  %.splatinsert36 = insertelement <8 x i64> poison, i64 %162, i64 0
  %.splat37 = shufflevector <8 x i64> %.splatinsert36, <8 x i64> poison, <8 x i32> zeroinitializer
  %163 = add <8 x i64> %.spill.load35, %.splat37
  %164 = extractvalue { ptr, i64 } %11, 0
  %165 = mul <8 x i64> %163, splat (i64 4)
  %166 = getelementptr i8, ptr %164, <8 x i64> %165
  %167 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %166, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %168 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.splatinsert38 = insertelement <8 x i64> poison, i64 %161, i64 0
  %.splat39 = shufflevector <8 x i64> %.splatinsert38, <8 x i64> poison, <8 x i32> zeroinitializer
  %170 = mul <8 x i64> %.splat39, splat (i64 32)
  %171 = add <8 x i64> %169, %170
  %172 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %168, 0
  %173 = insertvalue { <8 x ptr>, <8 x i64> } %172, <8 x i64> %171, 1
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %173, 1
  %176 = extractelement <8 x ptr> %174, i32 0
  %177 = extractelement <8 x i64> %175, i32 0
  %178 = sub i64 %177, 0
  %179 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %180 = select i1 %179, i64 %178, i64 0
  %private.contiguous.address40 = getelementptr i8, ptr %176, i64 %180
  %private.contiguous.preserve41 = load <8 x float>, ptr %private.contiguous.address40, align 4
  %181 = select <8 x i1> %53, <8 x float> %167, <8 x float> %private.contiguous.preserve41
  store <8 x float> %181, ptr %private.contiguous.address40, align 4
  %182 = fmul <8 x float> %167, %167
  %.state42 = load <8 x float>, ptr %.slot9, align 32
  %183 = fadd <8 x float> %.state42, %182
  %.state43 = load i64, ptr %.slot, align 4
  %184 = add i64 %.state43, 1
  %185 = sdiv i64 %184, 1
  %.spill.load44 = load i64, ptr %.spill6, align 4
  %186 = add i64 %.spill.load44, %185
  %187 = add i64 0, %186
  %.spill.load45 = load <8 x i64>, ptr %.spill7, align 64
  %.splatinsert46 = insertelement <8 x i64> poison, i64 %187, i64 0
  %.splat47 = shufflevector <8 x i64> %.splatinsert46, <8 x i64> poison, <8 x i32> zeroinitializer
  %188 = add <8 x i64> %.spill.load45, %.splat47
  %189 = extractvalue { ptr, i64 } %11, 0
  %190 = mul <8 x i64> %188, splat (i64 4)
  %191 = getelementptr i8, ptr %189, <8 x i64> %190
  %192 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %191, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load48 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load48, 0
  %194 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load48, 1
  %.splatinsert49 = insertelement <8 x i64> poison, i64 %186, i64 0
  %.splat50 = shufflevector <8 x i64> %.splatinsert49, <8 x i64> poison, <8 x i32> zeroinitializer
  %195 = mul <8 x i64> %.splat50, splat (i64 32)
  %196 = add <8 x i64> %194, %195
  %197 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %193, 0
  %198 = insertvalue { <8 x ptr>, <8 x i64> } %197, <8 x i64> %196, 1
  %199 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %200 = extractvalue { <8 x ptr>, <8 x i64> } %198, 1
  %201 = extractelement <8 x ptr> %199, i32 0
  %202 = extractelement <8 x i64> %200, i32 0
  %203 = sub i64 %202, 0
  %204 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %205 = select i1 %204, i64 %203, i64 0
  %private.contiguous.address51 = getelementptr i8, ptr %201, i64 %205
  %private.contiguous.preserve52 = load <8 x float>, ptr %private.contiguous.address51, align 4
  %206 = select <8 x i1> %53, <8 x float> %192, <8 x float> %private.contiguous.preserve52
  store <8 x float> %206, ptr %private.contiguous.address51, align 4
  %207 = fmul <8 x float> %192, %192
  %.state53 = load <8 x float>, ptr %.slot10, align 32
  %208 = fadd <8 x float> %.state53, %207
  %.state54 = load i64, ptr %.slot, align 4
  %209 = add i64 %.state54, 2
  %210 = sdiv i64 %209, 1
  %.spill.load55 = load i64, ptr %.spill6, align 4
  %211 = add i64 %.spill.load55, %210
  %212 = add i64 0, %211
  %.spill.load56 = load <8 x i64>, ptr %.spill7, align 64
  %.splatinsert57 = insertelement <8 x i64> poison, i64 %212, i64 0
  %.splat58 = shufflevector <8 x i64> %.splatinsert57, <8 x i64> poison, <8 x i32> zeroinitializer
  %213 = add <8 x i64> %.spill.load56, %.splat58
  %214 = extractvalue { ptr, i64 } %11, 0
  %215 = mul <8 x i64> %213, splat (i64 4)
  %216 = getelementptr i8, ptr %214, <8 x i64> %215
  %217 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %216, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load59 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %218 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load59, 0
  %219 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load59, 1
  %.splatinsert60 = insertelement <8 x i64> poison, i64 %211, i64 0
  %.splat61 = shufflevector <8 x i64> %.splatinsert60, <8 x i64> poison, <8 x i32> zeroinitializer
  %220 = mul <8 x i64> %.splat61, splat (i64 32)
  %221 = add <8 x i64> %219, %220
  %222 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %218, 0
  %223 = insertvalue { <8 x ptr>, <8 x i64> } %222, <8 x i64> %221, 1
  %224 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %225 = extractvalue { <8 x ptr>, <8 x i64> } %223, 1
  %226 = extractelement <8 x ptr> %224, i32 0
  %227 = extractelement <8 x i64> %225, i32 0
  %228 = sub i64 %227, 0
  %229 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %230 = select i1 %229, i64 %228, i64 0
  %private.contiguous.address62 = getelementptr i8, ptr %226, i64 %230
  %private.contiguous.preserve63 = load <8 x float>, ptr %private.contiguous.address62, align 4
  %231 = select <8 x i1> %53, <8 x float> %217, <8 x float> %private.contiguous.preserve63
  store <8 x float> %231, ptr %private.contiguous.address62, align 4
  %232 = fmul <8 x float> %217, %217
  %.state64 = load <8 x float>, ptr %.slot11, align 32
  %233 = fadd <8 x float> %.state64, %232
  %.state65 = load i64, ptr %.slot, align 4
  %234 = add i64 %.state65, 3
  %235 = sdiv i64 %234, 1
  %.spill.load66 = load i64, ptr %.spill6, align 4
  %236 = add i64 %.spill.load66, %235
  %237 = add i64 0, %236
  %.spill.load67 = load <8 x i64>, ptr %.spill7, align 64
  %.splatinsert68 = insertelement <8 x i64> poison, i64 %237, i64 0
  %.splat69 = shufflevector <8 x i64> %.splatinsert68, <8 x i64> poison, <8 x i32> zeroinitializer
  %238 = add <8 x i64> %.spill.load67, %.splat69
  %239 = extractvalue { ptr, i64 } %11, 0
  %240 = mul <8 x i64> %238, splat (i64 4)
  %241 = getelementptr i8, ptr %239, <8 x i64> %240
  %242 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %241, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load70 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %243 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load70, 0
  %244 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load70, 1
  %.splatinsert71 = insertelement <8 x i64> poison, i64 %236, i64 0
  %.splat72 = shufflevector <8 x i64> %.splatinsert71, <8 x i64> poison, <8 x i32> zeroinitializer
  %245 = mul <8 x i64> %.splat72, splat (i64 32)
  %246 = add <8 x i64> %244, %245
  %247 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %243, 0
  %248 = insertvalue { <8 x ptr>, <8 x i64> } %247, <8 x i64> %246, 1
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %250 = extractvalue { <8 x ptr>, <8 x i64> } %248, 1
  %251 = extractelement <8 x ptr> %249, i32 0
  %252 = extractelement <8 x i64> %250, i32 0
  %253 = sub i64 %252, 0
  %254 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %255 = select i1 %254, i64 %253, i64 0
  %private.contiguous.address73 = getelementptr i8, ptr %251, i64 %255
  %private.contiguous.preserve74 = load <8 x float>, ptr %private.contiguous.address73, align 4
  %256 = select <8 x i1> %53, <8 x float> %242, <8 x float> %private.contiguous.preserve74
  store <8 x float> %256, ptr %private.contiguous.address73, align 4
  %257 = fmul <8 x float> %242, %242
  %.state75 = load <8 x float>, ptr %.slot12, align 32
  %258 = fadd <8 x float> %.state75, %257
  %.state76 = load i64, ptr %.slot, align 4
  %259 = add i64 %.state76, 4
  store i64 %259, ptr %.slot, align 4
  %260 = load <8 x float>, ptr %.slot9, align 32
  %261 = select <8 x i1> %53, <8 x float> %183, <8 x float> %260
  store <8 x float> %261, ptr %.slot9, align 32
  %262 = load <8 x float>, ptr %.slot10, align 32
  %263 = select <8 x i1> %53, <8 x float> %208, <8 x float> %262
  store <8 x float> %263, ptr %.slot10, align 32
  %264 = load <8 x float>, ptr %.slot11, align 32
  %265 = select <8 x i1> %53, <8 x float> %233, <8 x float> %264
  store <8 x float> %265, ptr %.slot11, align 32
  %266 = load <8 x float>, ptr %.slot12, align 32
  %267 = select <8 x i1> %53, <8 x float> %258, <8 x float> %266
  store <8 x float> %267, ptr %.slot12, align 32
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %.spill.load77 = load float, ptr %.spill, align 4
  %.splatinsert78 = insertelement <8 x float> poison, float %.spill.load77, i64 0
  %.splat79 = shufflevector <8 x float> %.splatinsert78, <8 x float> poison, <8 x i32> zeroinitializer
  %.state80 = load <8 x float>, ptr %.slot9, align 32
  %268 = fadd <8 x float> %.splat79, %.state80
  %.state81 = load <8 x float>, ptr %.slot10, align 32
  %269 = fadd <8 x float> %268, %.state81
  %.state82 = load <8 x float>, ptr %.slot11, align 32
  %270 = fadd <8 x float> %269, %.state82
  %.state83 = load <8 x float>, ptr %.slot12, align 32
  %271 = fadd <8 x float> %270, %.state83
  %272 = fdiv <8 x float> %271, splat (float 4.096000e+03)
  %273 = load <8 x float>, ptr %.spill13, align 32
  %274 = select <8 x i1> %53, <8 x float> %272, <8 x float> %273
  store <8 x float> %274, ptr %.spill13, align 32
  %275 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %276 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %277 = extractvalue { <8 x ptr>, <8 x i64> } %275, 0
  %278 = select <8 x i1> %53, <8 x ptr> %276, <8 x ptr> %277
  %279 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %280 = extractvalue { <8 x ptr>, <8 x i64> } %275, 1
  %281 = select <8 x i1> %53, <8 x i64> %279, <8 x i64> %280
  %282 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %278, 0
  %283 = insertvalue { <8 x ptr>, <8 x i64> } %282, <8 x i64> %281, 1
  store { <8 x ptr>, <8 x i64> } %283, ptr %tile_snapshot.spill14, align 64
  store i64 0, ptr %.slot15, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state84 = load i64, ptr %.slot15, align 4
  %284 = icmp slt i64 %.state84, 4096
  br i1 %284, label %direct.true85, label %direct.false86

direct.schedule.5:                                ; preds = %direct.true85
  %.spill.load87 = load i64, ptr %.spill5, align 4
  %285 = add i64 %.spill.load87, 0
  %.state88 = load i64, ptr %.slot15, align 4
  %286 = add i64 0, %.state88
  %287 = mul i64 %285, 4096
  %288 = add i64 %287, %286
  %289 = extractvalue { ptr, i64 } %17, 0
  %290 = mul i64 %288, 4
  %291 = getelementptr i8, ptr %289, i64 %290
  %292 = load float, ptr %291, align 4
  %.splatinsert89 = insertelement <8 x float> poison, float %292, i64 0
  %.splat90 = shufflevector <8 x float> %.splatinsert89, <8 x float> poison, <8 x i32> zeroinitializer
  %tile_snapshot.spill.load91 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load91, 0
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load91, 1
  %.state92 = load i64, ptr %.slot15, align 4
  %.splatinsert93 = insertelement <8 x i64> poison, i64 %.state92, i64 0
  %.splat94 = shufflevector <8 x i64> %.splatinsert93, <8 x i64> poison, <8 x i32> zeroinitializer
  %295 = mul <8 x i64> %.splat94, splat (i64 32)
  %296 = add <8 x i64> %294, %295
  %297 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %293, 0
  %298 = insertvalue { <8 x ptr>, <8 x i64> } %297, <8 x i64> %296, 1
  %299 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %298, 1
  %301 = extractelement <8 x ptr> %299, i32 0
  %302 = extractelement <8 x i64> %300, i32 0
  %303 = sub i64 %302, 0
  %304 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %305 = select i1 %304, i64 %303, i64 0
  %private.contiguous.address95 = getelementptr i8, ptr %301, i64 %305
  %private.contiguous.preserve96 = load <8 x float>, ptr %private.contiguous.address95, align 4
  %306 = select <8 x i1> %53, <8 x float> %.splat90, <8 x float> %private.contiguous.preserve96
  store <8 x float> %306, ptr %private.contiguous.address95, align 4
  %.state97 = load i64, ptr %.slot15, align 4
  %307 = add i64 %.state97, 1
  store i64 %307, ptr %.slot15, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false86
  %.spill.load98 = load <8 x float>, ptr %.spill13, align 32
  %308 = fadd <8 x float> %.spill.load98, splat (float 0x3EE4F8B580000000)
  %309 = call <8 x float> @llvm.sqrt.v8f32(<8 x float> %308)
  %310 = load <8 x float>, ptr %.spill16, align 32
  %311 = select <8 x i1> %53, <8 x float> %309, <8 x float> %310
  store <8 x float> %311, ptr %.spill16, align 32
  store i64 0, ptr %.slot17, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state99 = load i64, ptr %.slot17, align 4
  %312 = icmp slt i64 %.state99, 4096
  br i1 %312, label %direct.true100, label %direct.false101

direct.schedule.8:                                ; preds = %direct.true100
  %.state102 = load i64, ptr %.slot17, align 4
  %313 = add i64 0, %.state102
  %.spill.load103 = load <8 x i64>, ptr %.spill7, align 64
  %.splatinsert104 = insertelement <8 x i64> poison, i64 %313, i64 0
  %.splat105 = shufflevector <8 x i64> %.splatinsert104, <8 x i64> poison, <8 x i32> zeroinitializer
  %314 = add <8 x i64> %.spill.load103, %.splat105
  %.spill.load106 = load i64, ptr %.spill8, align 4
  %.state107 = load i64, ptr %.slot17, align 4
  %315 = add i64 %.spill.load106, %.state107
  %.spill.load108 = load i64, ptr %.spill8, align 4
  %316 = add i64 %.spill.load108, %315
  %tile_snapshot.spill.load109 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %317 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load109, 0
  %318 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load109, 1
  %.splatinsert110 = insertelement <8 x i64> poison, i64 %316, i64 0
  %.splat111 = shufflevector <8 x i64> %.splatinsert110, <8 x i64> poison, <8 x i32> zeroinitializer
  %319 = mul <8 x i64> %.splat111, splat (i64 32)
  %320 = add <8 x i64> %318, %319
  %321 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %317, 0
  %322 = insertvalue { <8 x ptr>, <8 x i64> } %321, <8 x i64> %320, 1
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %322, 1
  %325 = extractelement <8 x ptr> %323, i32 0
  %326 = extractelement <8 x i64> %324, i32 0
  %327 = sub i64 %326, 0
  %328 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %329 = select i1 %328, i64 %327, i64 0
  %private.contiguous.address112 = getelementptr i8, ptr %325, i64 %329
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address112, align 4
  %330 = select <8 x i1> %53, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %.spill.load113 = load <8 x float>, ptr %.spill16, align 32
  %331 = fdiv <8 x float> %330, %.spill.load113
  %tile_snapshot.spill.load114 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %332 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load114, 0
  %333 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load114, 1
  %.splatinsert115 = insertelement <8 x i64> poison, i64 %315, i64 0
  %.splat116 = shufflevector <8 x i64> %.splatinsert115, <8 x i64> poison, <8 x i32> zeroinitializer
  %334 = mul <8 x i64> %.splat116, splat (i64 32)
  %335 = add <8 x i64> %333, %334
  %336 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %332, 0
  %337 = insertvalue { <8 x ptr>, <8 x i64> } %336, <8 x i64> %335, 1
  %338 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %339 = extractvalue { <8 x ptr>, <8 x i64> } %337, 1
  %340 = extractelement <8 x ptr> %338, i32 0
  %341 = extractelement <8 x i64> %339, i32 0
  %342 = sub i64 %341, 0
  %343 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %344 = select i1 %343, i64 %342, i64 0
  %private.contiguous.address117 = getelementptr i8, ptr %340, i64 %344
  %private.contiguous.load118 = load <8 x float>, ptr %private.contiguous.address117, align 4
  %345 = select <8 x i1> %53, <8 x float> %private.contiguous.load118, <8 x float> zeroinitializer
  %346 = fmul <8 x float> %331, %345
  %347 = extractvalue { ptr, i64 } %29, 0
  %348 = mul <8 x i64> %314, splat (i64 4)
  %349 = getelementptr i8, ptr %347, <8 x i64> %348
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %346, <8 x ptr> %349, i32 1, <8 x i1> %53)
  %.state119 = load i64, ptr %.slot17, align 4
  %350 = add i64 %.state119, 1
  store i64 %350, ptr %.slot17, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false101
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true85:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false86:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true100:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false101:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.9
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 1024
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 1024
  %3 = sub i64 1024, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 128
  %8 = icmp uge i64 %packet.range.remaining, 1024
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  br label %packet.batch.full.loop

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full.loop
  ret void

packet.batch.full.loop:                           ; preds = %packet.batch.full.loop, %packet.batch.full
  %packet.index = phi i32 [ 0, %packet.batch.full ], [ %packet.index.next, %packet.batch.full.loop ]
  %packet.thread.offset = mul i32 %packet.index, 8
  %packet.thread.index = add i32 %base.thread.index, %packet.thread.offset
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.index.next = add i32 %packet.index, 1
  %packet.batch.has.more = icmp ult i32 %packet.index.next, %packet_count
  br i1 %packet.batch.has.more, label %packet.batch.full.loop, label %packet.batch.exit

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 128)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }

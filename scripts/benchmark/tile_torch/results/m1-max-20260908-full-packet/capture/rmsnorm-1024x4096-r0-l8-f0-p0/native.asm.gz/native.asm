/tmp/luisa-full-packet.UEezjO/capture/rmsnorm-1024x4096-r0-l8-f0-p0/object/tile_xir_w8_63775_1788856229971134_0.o:
(__TEXT,__text) section
_llm_rows:
       0:	stp	x28, x27, [sp, #-0x10]!
       4:	sub	sp, sp, #0x8, lsl #12
       8:	sub	sp, sp, #0x180
       c:	dup.4s	v1, w2
      10:	adrp	x8, lCPI0_1@PAGE
      14:	ldr	q3, [x8, lCPI0_1@PAGEOFF]
      18:	adrp	x8, lCPI0_2@PAGE
      1c:	ldr	q4, [x8, lCPI0_2@PAGEOFF]
      20:	cmhi.4s	v0, v1, v4
      24:	cmhi.4s	v1, v1, v3
      28:	uzp1.8h	v5, v1, v0
      2c:	umaxv.8h	h2, v5
      30:	fmov	w8, s2
      34:	tbz	w8, #0x0, 0x6a0
      38:	mov	x13, #0x0
      3c:	add	x11, sp, #0x90
      40:	ldr	x12, [x0, #0x10]
      44:	ldr	x8, [x0, #0x30]
      48:	adrp	x9, lCPI0_0@PAGE
      4c:	ldr	q2, [x9, lCPI0_0@PAGEOFF]
      50:	and.16b	v2, v5, v2
      54:	addv.8h	h2, v2
      58:	fmov	w9, s2
      5c:	and	w10, w9, #0xff
      60:	ldr	x14, [x0]
      64:	ldr	w9, [x1]
      68:	ldr	w15, [x1, #0x24]
      6c:	add	w9, w15, w9, lsl #10
      70:	lsr	w9, w9, #3
      74:	fmov	s6, w9
      78:	and.16b	v6, v1, v6
      7c:	fmov	w9, s6
      80:	ubfiz	x9, x9, #14, #32
      84:	add	x14, x14, x9
      88:	fmov	w15, s2
      8c:	add	x16, sp, #0x4, lsl #12
      90:	add	x16, x16, #0x180
      94:	b	0xb8
      98:	add	x17, x16, x13
      9c:	ldp	q16, q17, [x17]
      a0:	bif.16b	v7, v17, v0
      a4:	bif.16b	v6, v16, v1
      a8:	stp	q6, q7, [x17]
      ac:	add	x13, x13, #0x20
      b0:	cmp	x13, #0x4, lsl #12
      b4:	b.eq	0x14c
      b8:	add	x17, x14, x13
      bc:	movi.2d	v6, #0000000000000000
      c0:	movi.2d	v7, #0000000000000000
      c4:	tbnz	w15, #0x0, 0xec
      c8:	and	w0, w15, #0xff
      cc:	tbnz	w0, #0x1, 0xf8
      d0:	tbnz	w0, #0x2, 0x104
      d4:	tbnz	w0, #0x3, 0x110
      d8:	tbnz	w0, #0x4, 0x11c
      dc:	tbnz	w0, #0x5, 0x128
      e0:	tbnz	w0, #0x6, 0x134
      e4:	tbz	w0, #0x7, 0x98
      e8:	b	0x140
      ec:	ldr	s6, [x17]
      f0:	and	w0, w15, #0xff
      f4:	tbz	w0, #0x1, 0xd0
      f8:	add	x1, x17, #0x4
      fc:	ld1.s	{ v6 }[1], [x1]
     100:	tbz	w0, #0x2, 0xd4
     104:	add	x1, x17, #0x8
     108:	ld1.s	{ v6 }[2], [x1]
     10c:	tbz	w0, #0x3, 0xd8
     110:	add	x1, x17, #0xc
     114:	ld1.s	{ v6 }[3], [x1]
     118:	tbz	w0, #0x4, 0xdc
     11c:	add	x1, x17, #0x10
     120:	ld1.s	{ v7 }[0], [x1]
     124:	tbz	w0, #0x5, 0xe0
     128:	add	x1, x17, #0x14
     12c:	ld1.s	{ v7 }[1], [x1]
     130:	tbz	w0, #0x6, 0xe4
     134:	add	x1, x17, #0x18
     138:	ld1.s	{ v7 }[2], [x1]
     13c:	tbz	w0, #0x7, 0x98
     140:	add	x17, x17, #0x1c
     144:	ld1.s	{ v7 }[3], [x17]
     148:	b	0x98
     14c:	ldr	q6, [x11, #0x4100]
     150:	ldr	q7, [x11, #0x40f0]
     154:	fmul.4s	v16, v7, v7
     158:	fmul.4s	v6, v6, v6
     15c:	ldr	q7, [x11, #0x4120]
     160:	ldr	q17, [x11, #0x4110]
     164:	fmul.4s	v17, v17, v17
     168:	fmul.4s	v18, v7, v7
     16c:	ldr	q7, [x11, #0x4140]
     170:	ldr	q19, [x11, #0x4130]
     174:	fmul.4s	v21, v19, v19
     178:	fmul.4s	v22, v7, v7
     17c:	ldr	q7, [x11, #0x4160]
     180:	ldr	q19, [x11, #0x4150]
     184:	fmul.4s	v23, v19, v19
     188:	fmul.4s	v24, v7, v7
     18c:	and.16b	v7, v0, v6
     190:	and.16b	v6, v1, v16
     194:	and.16b	v20, v0, v18
     198:	and.16b	v19, v1, v17
     19c:	and.16b	v16, v0, v22
     1a0:	and.16b	v21, v1, v21
     1a4:	and.16b	v18, v0, v24
     1a8:	and.16b	v17, v1, v23
     1ac:	add	x13, sp, #0x4, lsl #12
     1b0:	add	x13, x13, #0x180
     1b4:	add	x13, x13, #0xe0
     1b8:	mov	w14, #0x4
     1bc:	ldp	q23, q22, [x13, #-0x60]
     1c0:	and.16b	v23, v1, v23
     1c4:	and.16b	v22, v0, v22
     1c8:	fmul.4s	v22, v22, v22
     1cc:	fmul.4s	v23, v23, v23
     1d0:	fadd.4s	v23, v6, v23
     1d4:	fadd.4s	v22, v7, v22
     1d8:	ldp	q25, q24, [x13, #-0x40]
     1dc:	and.16b	v25, v1, v25
     1e0:	and.16b	v24, v0, v24
     1e4:	fmul.4s	v24, v24, v24
     1e8:	fmul.4s	v25, v25, v25
     1ec:	fadd.4s	v25, v19, v25
     1f0:	fadd.4s	v24, v20, v24
     1f4:	ldp	q27, q26, [x13, #-0x20]
     1f8:	and.16b	v27, v1, v27
     1fc:	and.16b	v26, v0, v26
     200:	fmul.4s	v26, v26, v26
     204:	fmul.4s	v27, v27, v27
     208:	fadd.4s	v27, v21, v27
     20c:	fadd.4s	v26, v16, v26
     210:	ldp	q29, q28, [x13], #0x80
     214:	and.16b	v29, v1, v29
     218:	and.16b	v28, v0, v28
     21c:	fmul.4s	v28, v28, v28
     220:	fmul.4s	v29, v29, v29
     224:	fadd.4s	v29, v17, v29
     228:	fadd.4s	v28, v18, v28
     22c:	bit.16b	v7, v22, v0
     230:	bit.16b	v6, v23, v1
     234:	bit.16b	v20, v24, v0
     238:	bit.16b	v19, v25, v1
     23c:	bit.16b	v16, v26, v0
     240:	bit.16b	v21, v27, v1
     244:	bit.16b	v18, v28, v0
     248:	bit.16b	v17, v29, v1
     24c:	cmp	x14, #0x1fc
     250:	add	x14, x14, #0x4
     254:	b.lo	0x1bc
     258:	mov	x13, #0x0
     25c:	fmov	w14, s2
     260:	add	x15, sp, #0x180
     264:	b	0x288
     268:	add	x16, x15, x13
     26c:	ldp	q24, q25, [x16]
     270:	bif.16b	v23, v25, v0
     274:	bif.16b	v22, v24, v1
     278:	stp	q22, q23, [x16]
     27c:	add	x13, x13, #0x20
     280:	cmp	x13, #0x4, lsl #12
     284:	b.eq	0x31c
     288:	add	x16, x12, x13
     28c:	movi.2d	v22, #0000000000000000
     290:	movi.2d	v23, #0000000000000000
     294:	tbnz	w14, #0x0, 0x2bc
     298:	and	w17, w14, #0xff
     29c:	tbnz	w17, #0x1, 0x2c8
     2a0:	tbnz	w17, #0x2, 0x2d4
     2a4:	tbnz	w17, #0x3, 0x2e0
     2a8:	tbnz	w17, #0x4, 0x2ec
     2ac:	tbnz	w17, #0x5, 0x2f8
     2b0:	tbnz	w17, #0x6, 0x304
     2b4:	tbz	w17, #0x7, 0x268
     2b8:	b	0x310
     2bc:	ldr	s22, [x16]
     2c0:	and	w17, w14, #0xff
     2c4:	tbz	w17, #0x1, 0x2a0
     2c8:	add	x0, x16, #0x4
     2cc:	ld1.s	{ v22 }[1], [x0]
     2d0:	tbz	w17, #0x2, 0x2a4
     2d4:	add	x0, x16, #0x8
     2d8:	ld1.s	{ v22 }[2], [x0]
     2dc:	tbz	w17, #0x3, 0x2a8
     2e0:	add	x0, x16, #0xc
     2e4:	ld1.s	{ v22 }[3], [x0]
     2e8:	tbz	w17, #0x4, 0x2ac
     2ec:	add	x0, x16, #0x10
     2f0:	ld1.s	{ v23 }[0], [x0]
     2f4:	tbz	w17, #0x5, 0x2b0
     2f8:	add	x0, x16, #0x14
     2fc:	ld1.s	{ v23 }[1], [x0]
     300:	tbz	w17, #0x6, 0x2b4
     304:	add	x0, x16, #0x18
     308:	ld1.s	{ v23 }[2], [x0]
     30c:	tbz	w17, #0x7, 0x268
     310:	add	x16, x16, #0x1c
     314:	ld1.s	{ v23 }[3], [x16]
     318:	b	0x268
     31c:	mov	x12, #0x0
     320:	xtn.8b	v22, v5
     324:	fadd.4s	v5, v7, v20
     328:	fadd.4s	v6, v6, v19
     32c:	fadd.4s	v6, v6, v21
     330:	fadd.4s	v5, v5, v16
     334:	fadd.4s	v5, v5, v18
     338:	fadd.4s	v6, v6, v17
     33c:	and.16b	v3, v1, v3
     340:	and.16b	v4, v0, v4
     344:	movi.4s	v7, #0x1
     348:	eor.16b	v16, v4, v7
     34c:	eor.16b	v19, v3, v7
     350:	umov.b	w14, v22[0]
     354:	str	q6, [x11, #0xc0]
     358:	ldr	s7, [x11, #0xc4]
     35c:	umov.b	w13, v22[1]
     360:	ands	w15, w14, #0x1
     364:	tst	w15, w13
     368:	movi	d3, #0000000000000000
     36c:	fcsel	s7, s7, s3, ne
     370:	mov.s	w16, v19[1]
     374:	add	x17, sp, #0x8
     378:	add	x0, sp, #0x8
     37c:	bfxil	x0, x16, #0, #3
     380:	str	d22, [sp, #0x8]
     384:	ldrb	w0, [x0]
     388:	add	x1, sp, #0x130
     38c:	orr	x16, x1, x16, lsl #2
     390:	stp	q6, q5, [x11, #0xa0]
     394:	ldr	s17, [x16]
     398:	ands	w16, w13, #0x1
     39c:	tst	w16, w0
     3a0:	mov.s	w16, v19[2]
     3a4:	fcsel	s17, s17, s3, ne
     3a8:	add	x0, sp, #0x8
     3ac:	bfxil	x0, x16, #0, #3
     3b0:	ldrb	w0, [x0]
     3b4:	add	x1, sp, #0x110
     3b8:	orr	x1, x1, x16, lsl #2
     3bc:	umov.b	w16, v22[2]
     3c0:	stp	q6, q5, [x11, #0x80]
     3c4:	ldr	s18, [x1]
     3c8:	ands	w1, w16, #0x1
     3cc:	tst	w1, w0
     3d0:	fcsel	s18, s18, s3, ne
     3d4:	mov.s	w0, v19[3]
     3d8:	add	x1, sp, #0x8
     3dc:	bfxil	x1, x0, #0, #3
     3e0:	ldrb	w1, [x1]
     3e4:	add	x2, sp, #0xf0
     3e8:	orr	x2, x2, x0, lsl #2
     3ec:	umov.b	w0, v22[3]
     3f0:	stp	q6, q5, [x11, #0x60]
     3f4:	ldr	s19, [x2]
     3f8:	ands	w2, w0, #0x1
     3fc:	tst	w2, w1
     400:	fcsel	s19, s19, s3, ne
     404:	fmov	w2, s16
     408:	add	x1, sp, #0x8
     40c:	bfxil	x1, x2, #0, #3
     410:	ldrb	w3, [x1]
     414:	umov.b	w1, v22[4]
     418:	and	w3, w1, w3
     41c:	stp	q6, q5, [x11, #0x40]
     420:	add	x4, sp, #0xd0
     424:	ldr	s20, [x4, w2, uxtw #2]
     428:	tst	w3, #0x1
     42c:	mov.s	w3, v16[1]
     430:	add	x4, sp, #0x8
     434:	bfxil	x4, x3, #0, #3
     438:	umov.b	w2, v22[5]
     43c:	ldrb	w4, [x4]
     440:	stp	q6, q5, [x11, #0x20]
     444:	add	x5, sp, #0xb0
     448:	ldr	s21, [x5, w3, uxtw #2]
     44c:	fcsel	s20, s20, s3, ne
     450:	ands	w3, w2, #0x1
     454:	tst	w3, w4
     458:	fcsel	s21, s21, s3, ne
     45c:	mov.s	w4, v16[2]
     460:	add	x3, sp, #0x8
     464:	bfxil	x3, x4, #0, #3
     468:	ldrb	w5, [x3]
     46c:	umov.b	w3, v22[6]
     470:	stp	q6, q5, [x11]
     474:	add	x11, sp, #0x90
     478:	ldr	s23, [x11, w4, uxtw #2]
     47c:	ands	w11, w3, #0x1
     480:	tst	w11, w5
     484:	mov.s	w11, v16[3]
     488:	add	x4, sp, #0x8
     48c:	bfxil	x4, x11, #0, #3
     490:	ldrb	w4, [x4]
     494:	stp	q6, q5, [sp, #0x70]
     498:	add	x5, sp, #0x70
     49c:	ldr	s16, [x5, w11, uxtw #2]
     4a0:	umov.b	w11, v22[7]
     4a4:	fcsel	s22, s23, s3, ne
     4a8:	ands	w5, w11, #0x1
     4ac:	tst	w5, w4
     4b0:	fcsel	s16, s16, s3, ne
     4b4:	mov.s	v7[1], v17[0]
     4b8:	mov.s	v7[2], v18[0]
     4bc:	mov.s	v7[3], v19[0]
     4c0:	mov.s	v20[1], v21[0]
     4c4:	mov.s	v20[2], v22[0]
     4c8:	mov.s	v20[3], v16[0]
     4cc:	fadd.4s	v5, v5, v20
     4d0:	fadd.4s	v6, v6, v7
     4d4:	movi.4s	v7, #0x2
     4d8:	eor.16b	v4, v4, v7
     4dc:	str	q6, [sp, #0x50]
     4e0:	ldr	s7, [sp, #0x58]
     4e4:	tst	w15, w16
     4e8:	fcsel	s7, s7, s3, ne
     4ec:	fmov	w4, s4
     4f0:	bfxil	x17, x4, #0, #3
     4f4:	ldrb	w17, [x17]
     4f8:	and	w17, w1, w17
     4fc:	stp	q6, q5, [sp, #0x30]
     500:	add	x5, sp, #0x30
     504:	ldr	s4, [x5, w4, uxtw #2]
     508:	tst	w17, #0x1
     50c:	fcsel	s4, s4, s3, ne
     510:	fadd.4s	v4, v5, v4
     514:	tst	w15, w1
     518:	fcsel	s4, s4, s3, ne
     51c:	ands	w14, w14, #0x1
     520:	fadd.4s	v5, v6, v7
     524:	fadd	s4, s5, s4
     528:	fcsel	s5, s4, s3, ne
     52c:	tst	w13, #0x1
     530:	fcsel	s6, s5, s3, ne
     534:	tst	w16, #0x1
     538:	fcsel	s7, s5, s3, ne
     53c:	tst	w0, #0x1
     540:	fcsel	s16, s5, s3, ne
     544:	tst	w14, w1
     548:	fcsel	s4, s4, s3, ne
     54c:	tst	w2, #0x1
     550:	fcsel	s17, s5, s3, ne
     554:	tst	w3, #0x1
     558:	fcsel	s18, s5, s3, ne
     55c:	tst	w11, #0x1
     560:	fcsel	s19, s5, s3, ne
     564:	mov.s	v5[1], v6[0]
     568:	mov.s	v5[2], v7[0]
     56c:	mov.s	v5[3], v16[0]
     570:	mov.s	v4[1], v17[0]
     574:	mov.s	v4[2], v18[0]
     578:	mov.s	v4[3], v19[0]
     57c:	rbit	w10, w10
     580:	clz	w10, w10
     584:	stp	q5, q4, [sp, #0x10]
     588:	and	x10, x10, #0x7
     58c:	add	x11, sp, #0x10
     590:	ldr	s4, [x11, x10, lsl #2]
     594:	fadd	s3, s4, s3
     598:	mov	w10, #0x39800000
     59c:	fmov	s4, w10
     5a0:	fmul	s3, s3, s4
     5a4:	mov	w10, #0xc5ac
     5a8:	movk	w10, #0x3727, lsl #16
     5ac:	fmov	s4, w10
     5b0:	fadd	s3, s3, s4
     5b4:	fsqrt	s3, s3
     5b8:	dup.4s	v3, v3[0]
     5bc:	add	x8, x8, x9
     5c0:	add	x9, sp, #0x4, lsl #12
     5c4:	add	x9, x9, #0x180
     5c8:	add	x10, sp, #0x180
     5cc:	b	0x5dc
     5d0:	add	x12, x12, #0x20
     5d4:	cmp	x12, #0x4, lsl #12
     5d8:	b.eq	0x6a0
     5dc:	fmov	w13, s2
     5e0:	add	x14, x9, x12
     5e4:	ldr	q4, [x14]
     5e8:	and.16b	v4, v1, v4
     5ec:	fdiv.4s	v4, v4, v3
     5f0:	add	x15, x10, x12
     5f4:	ldr	q5, [x15]
     5f8:	and.16b	v5, v1, v5
     5fc:	fmul.4s	v4, v4, v5
     600:	add	x11, x8, x12
     604:	tbnz	w13, #0x0, 0x64c
     608:	and	w13, w13, #0xff
     60c:	tbnz	w13, #0x1, 0x658
     610:	tbnz	w13, #0x2, 0x664
     614:	tbz	w13, #0x3, 0x620
     618:	add	x16, x11, #0xc
     61c:	st1.s	{ v4 }[3], [x16]
     620:	ldr	q4, [x14, #0x10]
     624:	and.16b	v4, v0, v4
     628:	fdiv.4s	v4, v4, v3
     62c:	ldr	q5, [x15, #0x10]
     630:	and.16b	v5, v0, v5
     634:	fmul.4s	v4, v4, v5
     638:	tbnz	w13, #0x4, 0x674
     63c:	tbnz	w13, #0x5, 0x67c
     640:	tbnz	w13, #0x6, 0x688
     644:	tbz	w13, #0x7, 0x5d0
     648:	b	0x694
     64c:	str	s4, [x11]
     650:	and	w13, w13, #0xff
     654:	tbz	w13, #0x1, 0x610
     658:	add	x16, x11, #0x4
     65c:	st1.s	{ v4 }[1], [x16]
     660:	tbz	w13, #0x2, 0x614
     664:	add	x16, x11, #0x8
     668:	st1.s	{ v4 }[2], [x16]
     66c:	tbnz	w13, #0x3, 0x618
     670:	b	0x620
     674:	str	s4, [x11, #0x10]
     678:	tbz	w13, #0x5, 0x640
     67c:	add	x14, x11, #0x14
     680:	st1.s	{ v4 }[1], [x14]
     684:	tbz	w13, #0x6, 0x644
     688:	add	x14, x11, #0x18
     68c:	st1.s	{ v4 }[2], [x14]
     690:	tbz	w13, #0x7, 0x5d0
     694:	add	x11, x11, #0x1c
     698:	st1.s	{ v4 }[3], [x11]
     69c:	b	0x5d0
     6a0:	add	sp, sp, #0x8, lsl #12
     6a4:	add	sp, sp, #0x180
     6a8:	ldp	x28, x27, [sp], #0x10
     6ac:	ret
_llm_rows.packet_batch.blocks:
     6b0:	cbz	w3, 0x808
     6b4:	sub	sp, sp, #0x70
     6b8:	stp	x28, x27, [sp, #0x10]
     6bc:	stp	x26, x25, [sp, #0x20]
     6c0:	stp	x24, x23, [sp, #0x30]
     6c4:	stp	x22, x21, [sp, #0x40]
     6c8:	stp	x20, x19, [sp, #0x50]
     6cc:	stp	x29, x30, [sp, #0x60]
     6d0:	mov	x19, x3
     6d4:	mov	x20, x2
     6d8:	mov	x21, x0
     6dc:	mov	w22, #0x0
     6e0:	ldp	w24, w8, [x2, #0x2c]
     6e4:	stp	w3, w8, [sp, #0x8]
     6e8:	ldp	w25, w26, [x2]
     6ec:	ldp	w28, w27, [x2, #0x8]
     6f0:	str	w24, [sp, #0x4]
     6f4:	b	0x73c
     6f8:	mov	w8, #0x3f8
     6fc:	str	w8, [x20, #0x24]
     700:	ldp	w24, w19, [sp, #0x4]
     704:	add	w8, w25, #0x1
     708:	cmp	w8, w24
     70c:	cset	w8, eq
     710:	csinc	w25, wzr, w25, eq
     714:	cinc	w9, w26, eq
     718:	ldr	w10, [sp, #0xc]
     71c:	cmp	w9, w10
     720:	cset	w10, eq
     724:	ands	w8, w8, w10
     728:	csel	w26, wzr, w9, ne
     72c:	add	w28, w28, w8
     730:	add	w22, w22, #0x1
     734:	cmp	w22, w19
     738:	b.eq	0x7ec
     73c:	ubfiz	x8, x25, #10, #32
     740:	cmp	x8, x27
     744:	csel	x9, x8, xzr, ls
     748:	subs	x10, x27, x9
     74c:	cmp	x10, #0x400
     750:	mov	w11, #0x400
     754:	csel	x10, x10, x11, lo
     758:	cmp	x27, x9
     75c:	stp	w25, w26, [x20]
     760:	str	w28, [x20, #0x8]
     764:	ccmp	x8, x27, #0x2, hi
     768:	csel	x23, x10, xzr, ls
     76c:	cmp	x23, #0x400
     770:	b.lo	0x79c
     774:	mov	w23, #0x0
     778:	str	w23, [x20, #0x24]
     77c:	mov	x0, x21
     780:	mov	x1, x20
     784:	mov	w2, #0x8
     788:	bl	_llm_rows
     78c:	add	w23, w23, #0x8
     790:	cmp	w23, #0x400
     794:	b.ne	0x778
     798:	b	0x704
     79c:	lsr	x8, x23, #3
     7a0:	lsl	w24, w8, #3
     7a4:	cmp	x23, #0x8
     7a8:	b.lo	0x7d0
     7ac:	mov	w19, #0x0
     7b0:	str	w19, [x20, #0x24]
     7b4:	mov	x0, x21
     7b8:	mov	x1, x20
     7bc:	mov	w2, #0x8
     7c0:	bl	_llm_rows
     7c4:	add	w19, w19, #0x8
     7c8:	cmp	w24, w19
     7cc:	b.ne	0x7b0
     7d0:	and	w2, w23, #0x7
     7d4:	cbz	w2, 0x6f8
     7d8:	str	w24, [x20, #0x24]
     7dc:	mov	x0, x21
     7e0:	mov	x1, x20
     7e4:	bl	_llm_rows
     7e8:	b	0x6f8
     7ec:	ldp	x29, x30, [sp, #0x60]
     7f0:	ldp	x20, x19, [sp, #0x50]
     7f4:	ldp	x22, x21, [sp, #0x40]
     7f8:	ldp	x24, x23, [sp, #0x30]
     7fc:	ldp	x26, x25, [sp, #0x20]
     800:	ldp	x28, x27, [sp, #0x10]
     804:	add	sp, sp, #0x70
     808:	ret

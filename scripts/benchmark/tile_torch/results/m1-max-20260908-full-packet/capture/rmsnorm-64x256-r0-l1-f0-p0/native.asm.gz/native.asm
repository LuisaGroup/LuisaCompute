/tmp/luisa-full-packet.UEezjO/capture/rmsnorm-64x256-r0-l1-f0-p0/object/tile_xir_w8_63761_1788856225189672_0.o:
(__TEXT,__text) section
_llm_rows.packet_batch.blocks:
       0:	cbz	w3, 0x1878
       4:	stp	d11, d10, [sp, #-0x80]!
       8:	stp	d9, d8, [sp, #0x10]
       c:	stp	x28, x27, [sp, #0x20]
      10:	stp	x26, x25, [sp, #0x30]
      14:	stp	x24, x23, [sp, #0x40]
      18:	stp	x22, x21, [sp, #0x50]
      1c:	stp	x20, x19, [sp, #0x60]
      20:	stp	x29, x30, [sp, #0x70]
      24:	sub	sp, sp, #0x4, lsl #12
      28:	sub	sp, sp, #0x20
      2c:	mov	w8, #0x0
      30:	add	x9, sp, #0x2, lsl #12
      34:	add	x9, x9, #0x20
      38:	ldp	w10, w11, [x2, #0x2c]
      3c:	ldp	w19, w20, [x2]
      40:	add	x12, x9, #0xe0
      44:	str	x12, [sp, #0x10]
      48:	adrp	x14, lCPI0_0@PAGE
      4c:	ldr	q0, [x14, lCPI0_0@PAGEOFF]
      50:	adrp	x14, lCPI0_1@PAGE
      54:	ldr	q1, [x14, lCPI0_1@PAGEOFF]
      58:	add	x14, sp, #0x20
      5c:	mov	w16, #0xc5ac
      60:	movk	w16, #0x3727, lsl #16
      64:	adrp	x1, lCPI0_2@PAGE
      68:	ldp	w21, w4, [x2, #0x8]
      6c:	str	x2, [sp, #0x8]
      70:	b	0xa8
      74:	add	w12, w7, #0x1
      78:	cmp	w12, w10
      7c:	cset	w12, eq
      80:	csinc	w19, wzr, w7, eq
      84:	cinc	w13, w6, eq
      88:	cmp	w13, w11
      8c:	cset	w15, eq
      90:	ands	w12, w12, w15
      94:	csel	w20, wzr, w13, ne
      98:	add	w21, w5, w12
      9c:	add	w8, w8, #0x1
      a0:	cmp	w8, w3
      a4:	b.eq	0x183c
      a8:	mov	x5, x21
      ac:	mov	x6, x20
      b0:	mov	x7, x19
      b4:	ubfiz	x19, x19, #6, #32
      b8:	cmp	x19, x4
      bc:	csel	x20, x19, xzr, ls
      c0:	subs	x21, x4, x20
      c4:	cmp	x21, #0x40
      c8:	mov	w12, #0x40
      cc:	csel	x21, x21, x12, lo
      d0:	cmp	x4, x20
      d4:	ccmp	x19, x4, #0x2, hi
      d8:	csel	x19, x21, xzr, ls
      dc:	mov	w12, #0x3b800000
      e0:	dup.4s	v3, w12
      e4:	dup.4s	v2, w16
      e8:	cmp	x19, #0x40
      ec:	b.lo	0x120c
      f0:	mov	x22, #0x0
      f4:	ldr	x24, [x0]
      f8:	ldr	x19, [x0, #0x10]
      fc:	ldr	x21, [x0, #0x30]
     100:	lsl	w20, w7, #6
     104:	dup.4s	v4, w20
     108:	orr.16b	v5, v4, v0
     10c:	orr.16b	v4, v4, v1
     110:	ushll2.2d	v6, v5, #0xa
     114:	ushll2.2d	v7, v4, #0xa
     118:	ushll.2d	v16, v5, #0xa
     11c:	ushll.2d	v17, v4, #0xa
     120:	add	x23, sp, #0x2, lsl #12
     124:	add	x23, x23, #0x20
     128:	dup.2d	v4, x24
     12c:	dup.2d	v5, x22
     130:	add.2d	v18, v5, v17
     134:	add.2d	v19, v5, v7
     138:	add.2d	v20, v5, v16
     13c:	add.2d	v5, v5, v6
     140:	add.2d	v5, v4, v5
     144:	add.2d	v20, v4, v20
     148:	add.2d	v19, v4, v19
     14c:	add.2d	v18, v4, v18
     150:	mov.d	x24, v18[1]
     154:	fmov	x25, d18
     158:	mov.d	x26, v19[1]
     15c:	fmov	x27, d19
     160:	mov.d	x28, v20[1]
     164:	fmov	x30, d20
     168:	mov.d	x12, v5[1]
     16c:	ldr	s18, [x30]
     170:	ld1.s	{ v18 }[1], [x28]
     174:	fmov	x28, d5
     178:	ld1.s	{ v18 }[2], [x28]
     17c:	ld1.s	{ v18 }[3], [x12]
     180:	ldr	s5, [x25]
     184:	ld1.s	{ v5 }[1], [x24]
     188:	ld1.s	{ v5 }[2], [x27]
     18c:	ld1.s	{ v5 }[3], [x26]
     190:	stp	q5, q18, [x23], #0x20
     194:	add	x22, x22, #0x4
     198:	cmp	x22, #0x400
     19c:	b.ne	0x12c
     1a0:	mov	x22, #0x0
     1a4:	ldp	q5, q18, [x9]
     1a8:	fmul.4s	v18, v18, v18
     1ac:	fmul.4s	v5, v5, v5
     1b0:	ldp	q19, q20, [x9, #0x20]
     1b4:	fmul.4s	v20, v20, v20
     1b8:	fmul.4s	v19, v19, v19
     1bc:	ldp	q22, q21, [x9, #0x40]
     1c0:	fmul.4s	v21, v21, v21
     1c4:	fmul.4s	v22, v22, v22
     1c8:	ldp	q23, q24, [x9, #0x60]
     1cc:	fmul.4s	v24, v24, v24
     1d0:	fmul.4s	v23, v23, v23
     1d4:	add	x12, x9, x22, lsl #5
     1d8:	ldp	q26, q25, [x12, #0x80]
     1dc:	fmul.4s	v26, v26, v26
     1e0:	fmul.4s	v25, v25, v25
     1e4:	fadd.4s	v18, v18, v25
     1e8:	fadd.4s	v5, v5, v26
     1ec:	ldp	q26, q25, [x12, #0xa0]
     1f0:	fmul.4s	v26, v26, v26
     1f4:	fmul.4s	v25, v25, v25
     1f8:	fadd.4s	v20, v20, v25
     1fc:	fadd.4s	v19, v19, v26
     200:	ldp	q26, q25, [x12, #0xc0]
     204:	fmul.4s	v26, v26, v26
     208:	fmul.4s	v25, v25, v25
     20c:	fadd.4s	v21, v21, v25
     210:	fadd.4s	v22, v22, v26
     214:	ldp	q26, q25, [x12, #0xe0]
     218:	fmul.4s	v26, v26, v26
     21c:	fmul.4s	v25, v25, v25
     220:	fadd.4s	v24, v24, v25
     224:	fadd.4s	v23, v23, v26
     228:	add	x22, x22, #0x4
     22c:	cmp	x22, #0xfc
     230:	b.lo	0x1d4
     234:	mov	x22, #0x0
     238:	add	x12, x19, x22, lsl #2
     23c:	ld1r.4s	{ v25 }, [x12]
     240:	add	x12, x14, x22, lsl #5
     244:	stp	q25, q25, [x12]
     248:	add	x22, x22, #0x1
     24c:	cmp	x22, #0x100
     250:	b.ne	0x238
     254:	mov	x22, #0x0
     258:	mov	x23, #0x0
     25c:	fadd.4s	v18, v18, v20
     260:	fadd.4s	v5, v5, v19
     264:	fadd.4s	v5, v5, v22
     268:	fadd.4s	v18, v18, v21
     26c:	fadd.4s	v18, v18, v24
     270:	fadd.4s	v5, v5, v23
     274:	fmul.4s	v5, v5, v3
     278:	fmul.4s	v18, v18, v3
     27c:	fadd.4s	v19, v18, v2
     280:	fadd.4s	v5, v5, v2
     284:	fsqrt.4s	v18, v5
     288:	fsqrt.4s	v19, v19
     28c:	add	x12, x9, x23
     290:	ldp	q20, q5, [x12]
     294:	fdiv.4s	v20, v20, v18
     298:	fdiv.4s	v5, v5, v19
     29c:	add	x12, x14, x23
     2a0:	ldp	q21, q22, [x12]
     2a4:	fmul.4s	v22, v5, v22
     2a8:	fmul.4s	v20, v20, v21
     2ac:	dup.2d	v5, x22
     2b0:	add.2d	v21, v5, v17
     2b4:	add.2d	v23, v5, v7
     2b8:	add.2d	v24, v5, v16
     2bc:	add.2d	v25, v5, v6
     2c0:	dup.2d	v5, x21
     2c4:	add.2d	v23, v5, v23
     2c8:	add.2d	v21, v5, v21
     2cc:	mov.d	x12, v21[1]
     2d0:	fmov	x24, d21
     2d4:	str	s20, [x24]
     2d8:	st1.s	{ v20 }[1], [x12]
     2dc:	mov.d	x12, v23[1]
     2e0:	add.2d	v21, v5, v24
     2e4:	fmov	x24, d23
     2e8:	st1.s	{ v20 }[2], [x24]
     2ec:	st1.s	{ v20 }[3], [x12]
     2f0:	mov.d	x12, v21[1]
     2f4:	fmov	x24, d21
     2f8:	str	s22, [x24]
     2fc:	st1.s	{ v22 }[1], [x12]
     300:	add.2d	v20, v5, v25
     304:	mov.d	x12, v20[1]
     308:	fmov	x24, d20
     30c:	st1.s	{ v22 }[2], [x24]
     310:	st1.s	{ v22 }[3], [x12]
     314:	add	x23, x23, #0x20
     318:	add	x22, x22, #0x4
     31c:	cmp	x23, #0x2, lsl #12
     320:	b.ne	0x28c
     324:	mov	x21, #0x0
     328:	orr	w12, w20, #0x8
     32c:	dup.4s	v6, w12
     330:	orr.16b	v16, v6, v0
     334:	orr.16b	v17, v6, v1
     338:	ushll2.2d	v6, v16, #0xa
     33c:	ushll2.2d	v7, v17, #0xa
     340:	ushll.2d	v16, v16, #0xa
     344:	ushll.2d	v17, v17, #0xa
     348:	add	x22, sp, #0x2, lsl #12
     34c:	add	x22, x22, #0x20
     350:	dup.2d	v18, x21
     354:	add.2d	v19, v18, v17
     358:	add.2d	v20, v18, v7
     35c:	add.2d	v21, v18, v16
     360:	add.2d	v18, v18, v6
     364:	add.2d	v18, v4, v18
     368:	add.2d	v21, v4, v21
     36c:	add.2d	v20, v4, v20
     370:	add.2d	v19, v4, v19
     374:	mov.d	x12, v19[1]
     378:	fmov	x23, d19
     37c:	mov.d	x24, v20[1]
     380:	fmov	x25, d20
     384:	mov.d	x26, v21[1]
     388:	fmov	x27, d21
     38c:	mov.d	x28, v18[1]
     390:	ldr	s19, [x27]
     394:	ld1.s	{ v19 }[1], [x26]
     398:	fmov	x26, d18
     39c:	ld1.s	{ v19 }[2], [x26]
     3a0:	ld1.s	{ v19 }[3], [x28]
     3a4:	ldr	s18, [x23]
     3a8:	ld1.s	{ v18 }[1], [x12]
     3ac:	ld1.s	{ v18 }[2], [x25]
     3b0:	ld1.s	{ v18 }[3], [x24]
     3b4:	stp	q18, q19, [x22], #0x20
     3b8:	add	x21, x21, #0x4
     3bc:	cmp	x21, #0x400
     3c0:	b.ne	0x350
     3c4:	mov	x21, #0x0
     3c8:	ldp	q18, q19, [x9]
     3cc:	fmul.4s	v19, v19, v19
     3d0:	fmul.4s	v18, v18, v18
     3d4:	ldp	q20, q21, [x9, #0x20]
     3d8:	fmul.4s	v21, v21, v21
     3dc:	fmul.4s	v20, v20, v20
     3e0:	ldp	q23, q22, [x9, #0x40]
     3e4:	fmul.4s	v22, v22, v22
     3e8:	fmul.4s	v23, v23, v23
     3ec:	ldp	q24, q25, [x9, #0x60]
     3f0:	fmul.4s	v25, v25, v25
     3f4:	fmul.4s	v24, v24, v24
     3f8:	add	x12, x9, x21, lsl #5
     3fc:	ldp	q27, q26, [x12, #0x80]
     400:	fmul.4s	v27, v27, v27
     404:	fmul.4s	v26, v26, v26
     408:	fadd.4s	v19, v19, v26
     40c:	fadd.4s	v18, v18, v27
     410:	ldp	q27, q26, [x12, #0xa0]
     414:	fmul.4s	v27, v27, v27
     418:	fmul.4s	v26, v26, v26
     41c:	fadd.4s	v21, v21, v26
     420:	fadd.4s	v20, v20, v27
     424:	ldp	q27, q26, [x12, #0xc0]
     428:	fmul.4s	v27, v27, v27
     42c:	fmul.4s	v26, v26, v26
     430:	fadd.4s	v22, v22, v26
     434:	fadd.4s	v23, v23, v27
     438:	ldp	q27, q26, [x12, #0xe0]
     43c:	fmul.4s	v27, v27, v27
     440:	fmul.4s	v26, v26, v26
     444:	fadd.4s	v25, v25, v26
     448:	fadd.4s	v24, v24, v27
     44c:	add	x21, x21, #0x4
     450:	cmp	x21, #0xfc
     454:	b.lo	0x3f8
     458:	mov	x21, #0x0
     45c:	add	x12, x19, x21, lsl #2
     460:	ld1r.4s	{ v26 }, [x12]
     464:	add	x12, x14, x21, lsl #5
     468:	stp	q26, q26, [x12]
     46c:	add	x21, x21, #0x1
     470:	cmp	x21, #0x100
     474:	b.ne	0x45c
     478:	mov	x21, #0x0
     47c:	mov	x22, #0x0
     480:	fadd.4s	v19, v19, v21
     484:	fadd.4s	v18, v18, v20
     488:	fadd.4s	v18, v18, v23
     48c:	fadd.4s	v19, v19, v22
     490:	fadd.4s	v19, v19, v25
     494:	fadd.4s	v18, v18, v24
     498:	fmul.4s	v18, v18, v3
     49c:	fmul.4s	v19, v19, v3
     4a0:	fadd.4s	v19, v19, v2
     4a4:	fadd.4s	v18, v18, v2
     4a8:	fsqrt.4s	v18, v18
     4ac:	fsqrt.4s	v19, v19
     4b0:	add	x12, x9, x22
     4b4:	ldp	q21, q20, [x12]
     4b8:	fdiv.4s	v21, v21, v18
     4bc:	fdiv.4s	v20, v20, v19
     4c0:	add	x12, x14, x22
     4c4:	ldp	q22, q23, [x12]
     4c8:	fmul.4s	v20, v20, v23
     4cc:	fmul.4s	v21, v21, v22
     4d0:	dup.2d	v22, x21
     4d4:	add.2d	v23, v22, v17
     4d8:	add.2d	v24, v22, v7
     4dc:	add.2d	v25, v22, v16
     4e0:	add.2d	v22, v22, v6
     4e4:	add.2d	v24, v5, v24
     4e8:	add.2d	v23, v5, v23
     4ec:	mov.d	x12, v23[1]
     4f0:	fmov	x23, d23
     4f4:	str	s21, [x23]
     4f8:	st1.s	{ v21 }[1], [x12]
     4fc:	mov.d	x12, v24[1]
     500:	add.2d	v23, v5, v25
     504:	fmov	x23, d24
     508:	st1.s	{ v21 }[2], [x23]
     50c:	st1.s	{ v21 }[3], [x12]
     510:	mov.d	x12, v23[1]
     514:	fmov	x23, d23
     518:	str	s20, [x23]
     51c:	st1.s	{ v20 }[1], [x12]
     520:	add.2d	v21, v5, v22
     524:	mov.d	x12, v21[1]
     528:	fmov	x23, d21
     52c:	st1.s	{ v20 }[2], [x23]
     530:	st1.s	{ v20 }[3], [x12]
     534:	add	x22, x22, #0x20
     538:	add	x21, x21, #0x4
     53c:	cmp	x22, #0x2, lsl #12
     540:	b.ne	0x4b0
     544:	mov	x21, #0x0
     548:	orr	w12, w20, #0x10
     54c:	dup.4s	v6, w12
     550:	orr.16b	v16, v6, v0
     554:	orr.16b	v17, v6, v1
     558:	ushll2.2d	v6, v16, #0xa
     55c:	ushll2.2d	v7, v17, #0xa
     560:	ushll.2d	v16, v16, #0xa
     564:	ushll.2d	v17, v17, #0xa
     568:	add	x22, sp, #0x2, lsl #12
     56c:	add	x22, x22, #0x20
     570:	dup.2d	v18, x21
     574:	add.2d	v19, v18, v17
     578:	add.2d	v20, v18, v7
     57c:	add.2d	v21, v18, v16
     580:	add.2d	v18, v18, v6
     584:	add.2d	v18, v4, v18
     588:	add.2d	v21, v4, v21
     58c:	add.2d	v20, v4, v20
     590:	add.2d	v19, v4, v19
     594:	mov.d	x12, v19[1]
     598:	fmov	x23, d19
     59c:	mov.d	x24, v20[1]
     5a0:	fmov	x25, d20
     5a4:	mov.d	x26, v21[1]
     5a8:	fmov	x27, d21
     5ac:	mov.d	x28, v18[1]
     5b0:	ldr	s19, [x27]
     5b4:	ld1.s	{ v19 }[1], [x26]
     5b8:	fmov	x26, d18
     5bc:	ld1.s	{ v19 }[2], [x26]
     5c0:	ld1.s	{ v19 }[3], [x28]
     5c4:	ldr	s18, [x23]
     5c8:	ld1.s	{ v18 }[1], [x12]
     5cc:	ld1.s	{ v18 }[2], [x25]
     5d0:	ld1.s	{ v18 }[3], [x24]
     5d4:	stp	q18, q19, [x22], #0x20
     5d8:	add	x21, x21, #0x4
     5dc:	cmp	x21, #0x400
     5e0:	b.ne	0x570
     5e4:	mov	x21, #0x0
     5e8:	ldp	q18, q19, [x9]
     5ec:	fmul.4s	v19, v19, v19
     5f0:	fmul.4s	v18, v18, v18
     5f4:	ldp	q20, q21, [x9, #0x20]
     5f8:	fmul.4s	v21, v21, v21
     5fc:	fmul.4s	v20, v20, v20
     600:	ldp	q23, q22, [x9, #0x40]
     604:	fmul.4s	v22, v22, v22
     608:	fmul.4s	v23, v23, v23
     60c:	ldp	q24, q25, [x9, #0x60]
     610:	fmul.4s	v25, v25, v25
     614:	fmul.4s	v24, v24, v24
     618:	add	x12, x9, x21, lsl #5
     61c:	ldp	q27, q26, [x12, #0x80]
     620:	fmul.4s	v27, v27, v27
     624:	fmul.4s	v26, v26, v26
     628:	fadd.4s	v19, v19, v26
     62c:	fadd.4s	v18, v18, v27
     630:	ldp	q27, q26, [x12, #0xa0]
     634:	fmul.4s	v27, v27, v27
     638:	fmul.4s	v26, v26, v26
     63c:	fadd.4s	v21, v21, v26
     640:	fadd.4s	v20, v20, v27
     644:	ldp	q27, q26, [x12, #0xc0]
     648:	fmul.4s	v27, v27, v27
     64c:	fmul.4s	v26, v26, v26
     650:	fadd.4s	v22, v22, v26
     654:	fadd.4s	v23, v23, v27
     658:	ldp	q27, q26, [x12, #0xe0]
     65c:	fmul.4s	v27, v27, v27
     660:	fmul.4s	v26, v26, v26
     664:	fadd.4s	v25, v25, v26
     668:	fadd.4s	v24, v24, v27
     66c:	add	x21, x21, #0x4
     670:	cmp	x21, #0xfc
     674:	b.lo	0x618
     678:	mov	x21, #0x0
     67c:	add	x12, x19, x21, lsl #2
     680:	ld1r.4s	{ v26 }, [x12]
     684:	add	x12, x14, x21, lsl #5
     688:	stp	q26, q26, [x12]
     68c:	add	x21, x21, #0x1
     690:	cmp	x21, #0x100
     694:	b.ne	0x67c
     698:	mov	x21, #0x0
     69c:	mov	x22, #0x0
     6a0:	fadd.4s	v19, v19, v21
     6a4:	fadd.4s	v18, v18, v20
     6a8:	fadd.4s	v18, v18, v23
     6ac:	fadd.4s	v19, v19, v22
     6b0:	fadd.4s	v19, v19, v25
     6b4:	fadd.4s	v18, v18, v24
     6b8:	fmul.4s	v18, v18, v3
     6bc:	fmul.4s	v19, v19, v3
     6c0:	fadd.4s	v19, v19, v2
     6c4:	fadd.4s	v18, v18, v2
     6c8:	fsqrt.4s	v18, v18
     6cc:	fsqrt.4s	v19, v19
     6d0:	add	x12, x9, x22
     6d4:	ldp	q21, q20, [x12]
     6d8:	fdiv.4s	v21, v21, v18
     6dc:	fdiv.4s	v20, v20, v19
     6e0:	add	x12, x14, x22
     6e4:	ldp	q22, q23, [x12]
     6e8:	fmul.4s	v20, v20, v23
     6ec:	fmul.4s	v21, v21, v22
     6f0:	dup.2d	v22, x21
     6f4:	add.2d	v23, v22, v17
     6f8:	add.2d	v24, v22, v7
     6fc:	add.2d	v25, v22, v16
     700:	add.2d	v22, v22, v6
     704:	add.2d	v24, v5, v24
     708:	add.2d	v23, v5, v23
     70c:	mov.d	x12, v23[1]
     710:	fmov	x23, d23
     714:	str	s21, [x23]
     718:	st1.s	{ v21 }[1], [x12]
     71c:	mov.d	x12, v24[1]
     720:	add.2d	v23, v5, v25
     724:	fmov	x23, d24
     728:	st1.s	{ v21 }[2], [x23]
     72c:	st1.s	{ v21 }[3], [x12]
     730:	mov.d	x12, v23[1]
     734:	fmov	x23, d23
     738:	str	s20, [x23]
     73c:	st1.s	{ v20 }[1], [x12]
     740:	add.2d	v21, v5, v22
     744:	mov.d	x12, v21[1]
     748:	fmov	x23, d21
     74c:	st1.s	{ v20 }[2], [x23]
     750:	st1.s	{ v20 }[3], [x12]
     754:	add	x22, x22, #0x20
     758:	add	x21, x21, #0x4
     75c:	cmp	x22, #0x2, lsl #12
     760:	b.ne	0x6d0
     764:	mov	x21, #0x0
     768:	orr	w12, w20, #0x18
     76c:	dup.4s	v6, w12
     770:	orr.16b	v16, v6, v0
     774:	orr.16b	v17, v6, v1
     778:	ushll2.2d	v6, v16, #0xa
     77c:	ushll2.2d	v7, v17, #0xa
     780:	ushll.2d	v16, v16, #0xa
     784:	ushll.2d	v17, v17, #0xa
     788:	add	x22, sp, #0x2, lsl #12
     78c:	add	x22, x22, #0x20
     790:	dup.2d	v18, x21
     794:	add.2d	v19, v18, v17
     798:	add.2d	v20, v18, v7
     79c:	add.2d	v21, v18, v16
     7a0:	add.2d	v18, v18, v6
     7a4:	add.2d	v18, v4, v18
     7a8:	add.2d	v21, v4, v21
     7ac:	add.2d	v20, v4, v20
     7b0:	add.2d	v19, v4, v19
     7b4:	mov.d	x12, v19[1]
     7b8:	fmov	x23, d19
     7bc:	mov.d	x24, v20[1]
     7c0:	fmov	x25, d20
     7c4:	mov.d	x26, v21[1]
     7c8:	fmov	x27, d21
     7cc:	mov.d	x28, v18[1]
     7d0:	ldr	s19, [x27]
     7d4:	ld1.s	{ v19 }[1], [x26]
     7d8:	fmov	x26, d18
     7dc:	ld1.s	{ v19 }[2], [x26]
     7e0:	ld1.s	{ v19 }[3], [x28]
     7e4:	ldr	s18, [x23]
     7e8:	ld1.s	{ v18 }[1], [x12]
     7ec:	ld1.s	{ v18 }[2], [x25]
     7f0:	ld1.s	{ v18 }[3], [x24]
     7f4:	stp	q18, q19, [x22], #0x20
     7f8:	add	x21, x21, #0x4
     7fc:	cmp	x21, #0x400
     800:	b.ne	0x790
     804:	mov	x21, #0x0
     808:	ldp	q18, q19, [x9]
     80c:	fmul.4s	v19, v19, v19
     810:	fmul.4s	v18, v18, v18
     814:	ldp	q20, q21, [x9, #0x20]
     818:	fmul.4s	v21, v21, v21
     81c:	fmul.4s	v20, v20, v20
     820:	ldp	q23, q22, [x9, #0x40]
     824:	fmul.4s	v22, v22, v22
     828:	fmul.4s	v23, v23, v23
     82c:	ldp	q24, q25, [x9, #0x60]
     830:	fmul.4s	v25, v25, v25
     834:	fmul.4s	v24, v24, v24
     838:	add	x12, x9, x21, lsl #5
     83c:	ldp	q27, q26, [x12, #0x80]
     840:	fmul.4s	v27, v27, v27
     844:	fmul.4s	v26, v26, v26
     848:	fadd.4s	v19, v19, v26
     84c:	fadd.4s	v18, v18, v27
     850:	ldp	q27, q26, [x12, #0xa0]
     854:	fmul.4s	v27, v27, v27
     858:	fmul.4s	v26, v26, v26
     85c:	fadd.4s	v21, v21, v26
     860:	fadd.4s	v20, v20, v27
     864:	ldp	q27, q26, [x12, #0xc0]
     868:	fmul.4s	v27, v27, v27
     86c:	fmul.4s	v26, v26, v26
     870:	fadd.4s	v22, v22, v26
     874:	fadd.4s	v23, v23, v27
     878:	ldp	q27, q26, [x12, #0xe0]
     87c:	fmul.4s	v27, v27, v27
     880:	fmul.4s	v26, v26, v26
     884:	fadd.4s	v25, v25, v26
     888:	fadd.4s	v24, v24, v27
     88c:	add	x21, x21, #0x4
     890:	cmp	x21, #0xfc
     894:	b.lo	0x838
     898:	mov	x21, #0x0
     89c:	add	x12, x19, x21, lsl #2
     8a0:	ld1r.4s	{ v26 }, [x12]
     8a4:	add	x12, x14, x21, lsl #5
     8a8:	stp	q26, q26, [x12]
     8ac:	add	x21, x21, #0x1
     8b0:	cmp	x21, #0x100
     8b4:	b.ne	0x89c
     8b8:	mov	x21, #0x0
     8bc:	mov	x22, #0x0
     8c0:	fadd.4s	v19, v19, v21
     8c4:	fadd.4s	v18, v18, v20
     8c8:	fadd.4s	v18, v18, v23
     8cc:	fadd.4s	v19, v19, v22
     8d0:	fadd.4s	v19, v19, v25
     8d4:	fadd.4s	v18, v18, v24
     8d8:	fmul.4s	v18, v18, v3
     8dc:	fmul.4s	v19, v19, v3
     8e0:	fadd.4s	v19, v19, v2
     8e4:	fadd.4s	v18, v18, v2
     8e8:	fsqrt.4s	v18, v18
     8ec:	fsqrt.4s	v19, v19
     8f0:	add	x12, x9, x22
     8f4:	ldp	q21, q20, [x12]
     8f8:	fdiv.4s	v21, v21, v18
     8fc:	fdiv.4s	v20, v20, v19
     900:	add	x12, x14, x22
     904:	ldp	q22, q23, [x12]
     908:	fmul.4s	v20, v20, v23
     90c:	fmul.4s	v21, v21, v22
     910:	dup.2d	v22, x21
     914:	add.2d	v23, v22, v17
     918:	add.2d	v24, v22, v7
     91c:	add.2d	v25, v22, v16
     920:	add.2d	v22, v22, v6
     924:	add.2d	v24, v5, v24
     928:	add.2d	v23, v5, v23
     92c:	mov.d	x12, v23[1]
     930:	fmov	x23, d23
     934:	str	s21, [x23]
     938:	st1.s	{ v21 }[1], [x12]
     93c:	mov.d	x12, v24[1]
     940:	add.2d	v23, v5, v25
     944:	fmov	x23, d24
     948:	st1.s	{ v21 }[2], [x23]
     94c:	st1.s	{ v21 }[3], [x12]
     950:	mov.d	x12, v23[1]
     954:	fmov	x23, d23
     958:	str	s20, [x23]
     95c:	st1.s	{ v20 }[1], [x12]
     960:	add.2d	v21, v5, v22
     964:	mov.d	x12, v21[1]
     968:	fmov	x23, d21
     96c:	st1.s	{ v20 }[2], [x23]
     970:	st1.s	{ v20 }[3], [x12]
     974:	add	x22, x22, #0x20
     978:	add	x21, x21, #0x4
     97c:	cmp	x22, #0x2, lsl #12
     980:	b.ne	0x8f0
     984:	mov	x21, #0x0
     988:	orr	w12, w20, #0x20
     98c:	dup.4s	v6, w12
     990:	orr.16b	v16, v6, v0
     994:	orr.16b	v17, v6, v1
     998:	ushll2.2d	v6, v16, #0xa
     99c:	ushll2.2d	v7, v17, #0xa
     9a0:	ushll.2d	v16, v16, #0xa
     9a4:	ushll.2d	v17, v17, #0xa
     9a8:	add	x22, sp, #0x2, lsl #12
     9ac:	add	x22, x22, #0x20
     9b0:	dup.2d	v18, x21
     9b4:	add.2d	v19, v18, v17
     9b8:	add.2d	v20, v18, v7
     9bc:	add.2d	v21, v18, v16
     9c0:	add.2d	v18, v18, v6
     9c4:	add.2d	v18, v4, v18
     9c8:	add.2d	v21, v4, v21
     9cc:	add.2d	v20, v4, v20
     9d0:	add.2d	v19, v4, v19
     9d4:	mov.d	x12, v19[1]
     9d8:	fmov	x23, d19
     9dc:	mov.d	x24, v20[1]
     9e0:	fmov	x25, d20
     9e4:	mov.d	x26, v21[1]
     9e8:	fmov	x27, d21
     9ec:	mov.d	x28, v18[1]
     9f0:	ldr	s19, [x27]
     9f4:	ld1.s	{ v19 }[1], [x26]
     9f8:	fmov	x26, d18
     9fc:	ld1.s	{ v19 }[2], [x26]
     a00:	ld1.s	{ v19 }[3], [x28]
     a04:	ldr	s18, [x23]
     a08:	ld1.s	{ v18 }[1], [x12]
     a0c:	ld1.s	{ v18 }[2], [x25]
     a10:	ld1.s	{ v18 }[3], [x24]
     a14:	stp	q18, q19, [x22], #0x20
     a18:	add	x21, x21, #0x4
     a1c:	cmp	x21, #0x400
     a20:	b.ne	0x9b0
     a24:	mov	x21, #0x0
     a28:	ldp	q18, q19, [x9]
     a2c:	fmul.4s	v19, v19, v19
     a30:	fmul.4s	v18, v18, v18
     a34:	ldp	q20, q21, [x9, #0x20]
     a38:	fmul.4s	v21, v21, v21
     a3c:	fmul.4s	v20, v20, v20
     a40:	ldp	q23, q22, [x9, #0x40]
     a44:	fmul.4s	v22, v22, v22
     a48:	fmul.4s	v23, v23, v23
     a4c:	ldp	q24, q25, [x9, #0x60]
     a50:	fmul.4s	v25, v25, v25
     a54:	fmul.4s	v24, v24, v24
     a58:	add	x12, x9, x21, lsl #5
     a5c:	ldp	q27, q26, [x12, #0x80]
     a60:	fmul.4s	v27, v27, v27
     a64:	fmul.4s	v26, v26, v26
     a68:	fadd.4s	v19, v19, v26
     a6c:	fadd.4s	v18, v18, v27
     a70:	ldp	q27, q26, [x12, #0xa0]
     a74:	fmul.4s	v27, v27, v27
     a78:	fmul.4s	v26, v26, v26
     a7c:	fadd.4s	v21, v21, v26
     a80:	fadd.4s	v20, v20, v27
     a84:	ldp	q27, q26, [x12, #0xc0]
     a88:	fmul.4s	v27, v27, v27
     a8c:	fmul.4s	v26, v26, v26
     a90:	fadd.4s	v22, v22, v26
     a94:	fadd.4s	v23, v23, v27
     a98:	ldp	q27, q26, [x12, #0xe0]
     a9c:	fmul.4s	v27, v27, v27
     aa0:	fmul.4s	v26, v26, v26
     aa4:	fadd.4s	v25, v25, v26
     aa8:	fadd.4s	v24, v24, v27
     aac:	add	x21, x21, #0x4
     ab0:	cmp	x21, #0xfc
     ab4:	b.lo	0xa58
     ab8:	mov	x21, #0x0
     abc:	add	x12, x19, x21, lsl #2
     ac0:	ld1r.4s	{ v26 }, [x12]
     ac4:	add	x12, x14, x21, lsl #5
     ac8:	stp	q26, q26, [x12]
     acc:	add	x21, x21, #0x1
     ad0:	cmp	x21, #0x100
     ad4:	b.ne	0xabc
     ad8:	mov	x21, #0x0
     adc:	mov	x22, #0x0
     ae0:	fadd.4s	v19, v19, v21
     ae4:	fadd.4s	v18, v18, v20
     ae8:	fadd.4s	v18, v18, v23
     aec:	fadd.4s	v19, v19, v22
     af0:	fadd.4s	v19, v19, v25
     af4:	fadd.4s	v18, v18, v24
     af8:	fmul.4s	v18, v18, v3
     afc:	fmul.4s	v19, v19, v3
     b00:	fadd.4s	v19, v19, v2
     b04:	fadd.4s	v18, v18, v2
     b08:	fsqrt.4s	v18, v18
     b0c:	fsqrt.4s	v19, v19
     b10:	add	x12, x9, x22
     b14:	ldp	q21, q20, [x12]
     b18:	fdiv.4s	v21, v21, v18
     b1c:	fdiv.4s	v20, v20, v19
     b20:	add	x12, x14, x22
     b24:	ldp	q22, q23, [x12]
     b28:	fmul.4s	v20, v20, v23
     b2c:	fmul.4s	v21, v21, v22
     b30:	dup.2d	v22, x21
     b34:	add.2d	v23, v22, v17
     b38:	add.2d	v24, v22, v7
     b3c:	add.2d	v25, v22, v16
     b40:	add.2d	v22, v22, v6
     b44:	add.2d	v24, v5, v24
     b48:	add.2d	v23, v5, v23
     b4c:	mov.d	x12, v23[1]
     b50:	fmov	x23, d23
     b54:	str	s21, [x23]
     b58:	st1.s	{ v21 }[1], [x12]
     b5c:	mov.d	x12, v24[1]
     b60:	add.2d	v23, v5, v25
     b64:	fmov	x23, d24
     b68:	st1.s	{ v21 }[2], [x23]
     b6c:	st1.s	{ v21 }[3], [x12]
     b70:	mov.d	x12, v23[1]
     b74:	fmov	x23, d23
     b78:	str	s20, [x23]
     b7c:	st1.s	{ v20 }[1], [x12]
     b80:	add.2d	v21, v5, v22
     b84:	mov.d	x12, v21[1]
     b88:	fmov	x23, d21
     b8c:	st1.s	{ v20 }[2], [x23]
     b90:	st1.s	{ v20 }[3], [x12]
     b94:	add	x22, x22, #0x20
     b98:	add	x21, x21, #0x4
     b9c:	cmp	x22, #0x2, lsl #12
     ba0:	b.ne	0xb10
     ba4:	mov	x21, #0x0
     ba8:	mov	w12, #0x28
     bac:	orr	w12, w20, w12
     bb0:	dup.4s	v6, w12
     bb4:	orr.16b	v16, v6, v0
     bb8:	orr.16b	v17, v6, v1
     bbc:	ushll2.2d	v6, v16, #0xa
     bc0:	ushll2.2d	v7, v17, #0xa
     bc4:	ushll.2d	v16, v16, #0xa
     bc8:	ushll.2d	v17, v17, #0xa
     bcc:	add	x22, sp, #0x2, lsl #12
     bd0:	add	x22, x22, #0x20
     bd4:	dup.2d	v18, x21
     bd8:	add.2d	v19, v18, v17
     bdc:	add.2d	v20, v18, v7
     be0:	add.2d	v21, v18, v16
     be4:	add.2d	v18, v18, v6
     be8:	add.2d	v18, v4, v18
     bec:	add.2d	v21, v4, v21
     bf0:	add.2d	v20, v4, v20
     bf4:	add.2d	v19, v4, v19
     bf8:	mov.d	x12, v19[1]
     bfc:	fmov	x23, d19
     c00:	mov.d	x24, v20[1]
     c04:	fmov	x25, d20
     c08:	mov.d	x26, v21[1]
     c0c:	fmov	x27, d21
     c10:	mov.d	x28, v18[1]
     c14:	ldr	s19, [x27]
     c18:	ld1.s	{ v19 }[1], [x26]
     c1c:	fmov	x26, d18
     c20:	ld1.s	{ v19 }[2], [x26]
     c24:	ld1.s	{ v19 }[3], [x28]
     c28:	ldr	s18, [x23]
     c2c:	ld1.s	{ v18 }[1], [x12]
     c30:	ld1.s	{ v18 }[2], [x25]
     c34:	ld1.s	{ v18 }[3], [x24]
     c38:	stp	q18, q19, [x22], #0x20
     c3c:	add	x21, x21, #0x4
     c40:	cmp	x21, #0x400
     c44:	b.ne	0xbd4
     c48:	mov	x21, #0x0
     c4c:	ldp	q18, q19, [x9]
     c50:	fmul.4s	v19, v19, v19
     c54:	fmul.4s	v18, v18, v18
     c58:	ldp	q20, q21, [x9, #0x20]
     c5c:	fmul.4s	v21, v21, v21
     c60:	fmul.4s	v20, v20, v20
     c64:	ldp	q23, q22, [x9, #0x40]
     c68:	fmul.4s	v22, v22, v22
     c6c:	fmul.4s	v23, v23, v23
     c70:	ldp	q24, q25, [x9, #0x60]
     c74:	fmul.4s	v25, v25, v25
     c78:	fmul.4s	v24, v24, v24
     c7c:	add	x12, x9, x21, lsl #5
     c80:	ldp	q27, q26, [x12, #0x80]
     c84:	fmul.4s	v27, v27, v27
     c88:	fmul.4s	v26, v26, v26
     c8c:	fadd.4s	v19, v19, v26
     c90:	fadd.4s	v18, v18, v27
     c94:	ldp	q27, q26, [x12, #0xa0]
     c98:	fmul.4s	v27, v27, v27
     c9c:	fmul.4s	v26, v26, v26
     ca0:	fadd.4s	v21, v21, v26
     ca4:	fadd.4s	v20, v20, v27
     ca8:	ldp	q27, q26, [x12, #0xc0]
     cac:	fmul.4s	v27, v27, v27
     cb0:	fmul.4s	v26, v26, v26
     cb4:	fadd.4s	v22, v22, v26
     cb8:	fadd.4s	v23, v23, v27
     cbc:	ldp	q27, q26, [x12, #0xe0]
     cc0:	fmul.4s	v27, v27, v27
     cc4:	fmul.4s	v26, v26, v26
     cc8:	fadd.4s	v25, v25, v26
     ccc:	fadd.4s	v24, v24, v27
     cd0:	add	x21, x21, #0x4
     cd4:	cmp	x21, #0xfc
     cd8:	b.lo	0xc7c
     cdc:	mov	x21, #0x0
     ce0:	add	x12, x19, x21, lsl #2
     ce4:	ld1r.4s	{ v26 }, [x12]
     ce8:	add	x12, x14, x21, lsl #5
     cec:	stp	q26, q26, [x12]
     cf0:	add	x21, x21, #0x1
     cf4:	cmp	x21, #0x100
     cf8:	b.ne	0xce0
     cfc:	mov	x21, #0x0
     d00:	mov	x22, #0x0
     d04:	fadd.4s	v19, v19, v21
     d08:	fadd.4s	v18, v18, v20
     d0c:	fadd.4s	v18, v18, v23
     d10:	fadd.4s	v19, v19, v22
     d14:	fadd.4s	v19, v19, v25
     d18:	fadd.4s	v18, v18, v24
     d1c:	fmul.4s	v18, v18, v3
     d20:	fmul.4s	v19, v19, v3
     d24:	fadd.4s	v19, v19, v2
     d28:	fadd.4s	v18, v18, v2
     d2c:	fsqrt.4s	v18, v18
     d30:	fsqrt.4s	v19, v19
     d34:	add	x12, x9, x22
     d38:	ldp	q21, q20, [x12]
     d3c:	fdiv.4s	v21, v21, v18
     d40:	fdiv.4s	v20, v20, v19
     d44:	add	x12, x14, x22
     d48:	ldp	q22, q23, [x12]
     d4c:	fmul.4s	v20, v20, v23
     d50:	fmul.4s	v21, v21, v22
     d54:	dup.2d	v22, x21
     d58:	add.2d	v23, v22, v17
     d5c:	add.2d	v24, v22, v7
     d60:	add.2d	v25, v22, v16
     d64:	add.2d	v22, v22, v6
     d68:	add.2d	v24, v5, v24
     d6c:	add.2d	v23, v5, v23
     d70:	mov.d	x12, v23[1]
     d74:	fmov	x23, d23
     d78:	str	s21, [x23]
     d7c:	st1.s	{ v21 }[1], [x12]
     d80:	mov.d	x12, v24[1]
     d84:	add.2d	v23, v5, v25
     d88:	fmov	x23, d24
     d8c:	st1.s	{ v21 }[2], [x23]
     d90:	st1.s	{ v21 }[3], [x12]
     d94:	mov.d	x12, v23[1]
     d98:	fmov	x23, d23
     d9c:	str	s20, [x23]
     da0:	st1.s	{ v20 }[1], [x12]
     da4:	add.2d	v21, v5, v22
     da8:	mov.d	x12, v21[1]
     dac:	fmov	x23, d21
     db0:	st1.s	{ v20 }[2], [x23]
     db4:	st1.s	{ v20 }[3], [x12]
     db8:	add	x22, x22, #0x20
     dbc:	add	x21, x21, #0x4
     dc0:	cmp	x22, #0x2, lsl #12
     dc4:	b.ne	0xd34
     dc8:	mov	x21, #0x0
     dcc:	orr	w12, w20, #0x30
     dd0:	dup.4s	v6, w12
     dd4:	orr.16b	v16, v6, v0
     dd8:	orr.16b	v17, v6, v1
     ddc:	ushll2.2d	v6, v16, #0xa
     de0:	ushll2.2d	v7, v17, #0xa
     de4:	ushll.2d	v16, v16, #0xa
     de8:	ushll.2d	v17, v17, #0xa
     dec:	add	x22, sp, #0x2, lsl #12
     df0:	add	x22, x22, #0x20
     df4:	dup.2d	v18, x21
     df8:	add.2d	v19, v18, v17
     dfc:	add.2d	v20, v18, v7
     e00:	add.2d	v21, v18, v16
     e04:	add.2d	v18, v18, v6
     e08:	add.2d	v18, v4, v18
     e0c:	add.2d	v21, v4, v21
     e10:	add.2d	v20, v4, v20
     e14:	add.2d	v19, v4, v19
     e18:	mov.d	x12, v19[1]
     e1c:	fmov	x23, d19
     e20:	mov.d	x24, v20[1]
     e24:	fmov	x25, d20
     e28:	mov.d	x26, v21[1]
     e2c:	fmov	x27, d21
     e30:	mov.d	x28, v18[1]
     e34:	ldr	s19, [x27]
     e38:	ld1.s	{ v19 }[1], [x26]
     e3c:	fmov	x26, d18
     e40:	ld1.s	{ v19 }[2], [x26]
     e44:	ld1.s	{ v19 }[3], [x28]
     e48:	ldr	s18, [x23]
     e4c:	ld1.s	{ v18 }[1], [x12]
     e50:	ld1.s	{ v18 }[2], [x25]
     e54:	ld1.s	{ v18 }[3], [x24]
     e58:	stp	q18, q19, [x22], #0x20
     e5c:	add	x21, x21, #0x4
     e60:	cmp	x21, #0x400
     e64:	b.ne	0xdf4
     e68:	mov	x21, #0x0
     e6c:	ldp	q18, q19, [x9]
     e70:	fmul.4s	v19, v19, v19
     e74:	fmul.4s	v18, v18, v18
     e78:	ldp	q20, q21, [x9, #0x20]
     e7c:	fmul.4s	v21, v21, v21
     e80:	fmul.4s	v20, v20, v20
     e84:	ldp	q23, q22, [x9, #0x40]
     e88:	fmul.4s	v22, v22, v22
     e8c:	fmul.4s	v23, v23, v23
     e90:	ldp	q24, q25, [x9, #0x60]
     e94:	fmul.4s	v25, v25, v25
     e98:	fmul.4s	v24, v24, v24
     e9c:	add	x12, x9, x21, lsl #5
     ea0:	ldp	q27, q26, [x12, #0x80]
     ea4:	fmul.4s	v27, v27, v27
     ea8:	fmul.4s	v26, v26, v26
     eac:	fadd.4s	v19, v19, v26
     eb0:	fadd.4s	v18, v18, v27
     eb4:	ldp	q27, q26, [x12, #0xa0]
     eb8:	fmul.4s	v27, v27, v27
     ebc:	fmul.4s	v26, v26, v26
     ec0:	fadd.4s	v21, v21, v26
     ec4:	fadd.4s	v20, v20, v27
     ec8:	ldp	q27, q26, [x12, #0xc0]
     ecc:	fmul.4s	v27, v27, v27
     ed0:	fmul.4s	v26, v26, v26
     ed4:	fadd.4s	v22, v22, v26
     ed8:	fadd.4s	v23, v23, v27
     edc:	ldp	q27, q26, [x12, #0xe0]
     ee0:	fmul.4s	v27, v27, v27
     ee4:	fmul.4s	v26, v26, v26
     ee8:	fadd.4s	v25, v25, v26
     eec:	fadd.4s	v24, v24, v27
     ef0:	add	x21, x21, #0x4
     ef4:	cmp	x21, #0xfc
     ef8:	b.lo	0xe9c
     efc:	mov	x21, #0x0
     f00:	add	x12, x19, x21, lsl #2
     f04:	ld1r.4s	{ v26 }, [x12]
     f08:	add	x12, x14, x21, lsl #5
     f0c:	stp	q26, q26, [x12]
     f10:	add	x21, x21, #0x1
     f14:	cmp	x21, #0x100
     f18:	b.ne	0xf00
     f1c:	mov	x21, #0x0
     f20:	mov	x22, #0x0
     f24:	fadd.4s	v19, v19, v21
     f28:	fadd.4s	v18, v18, v20
     f2c:	fadd.4s	v18, v18, v23
     f30:	fadd.4s	v19, v19, v22
     f34:	fadd.4s	v19, v19, v25
     f38:	fadd.4s	v18, v18, v24
     f3c:	fmul.4s	v18, v18, v3
     f40:	fmul.4s	v19, v19, v3
     f44:	fadd.4s	v19, v19, v2
     f48:	fadd.4s	v18, v18, v2
     f4c:	fsqrt.4s	v18, v18
     f50:	fsqrt.4s	v19, v19
     f54:	add	x12, x9, x22
     f58:	ldp	q21, q20, [x12]
     f5c:	fdiv.4s	v21, v21, v18
     f60:	fdiv.4s	v20, v20, v19
     f64:	add	x12, x14, x22
     f68:	ldp	q22, q23, [x12]
     f6c:	fmul.4s	v20, v20, v23
     f70:	fmul.4s	v21, v21, v22
     f74:	dup.2d	v22, x21
     f78:	add.2d	v23, v22, v17
     f7c:	add.2d	v24, v22, v7
     f80:	add.2d	v25, v22, v16
     f84:	add.2d	v22, v22, v6
     f88:	add.2d	v24, v5, v24
     f8c:	add.2d	v23, v5, v23
     f90:	mov.d	x12, v23[1]
     f94:	fmov	x23, d23
     f98:	str	s21, [x23]
     f9c:	st1.s	{ v21 }[1], [x12]
     fa0:	mov.d	x12, v24[1]
     fa4:	add.2d	v23, v5, v25
     fa8:	fmov	x23, d24
     fac:	st1.s	{ v21 }[2], [x23]
     fb0:	st1.s	{ v21 }[3], [x12]
     fb4:	mov.d	x12, v23[1]
     fb8:	fmov	x23, d23
     fbc:	str	s20, [x23]
     fc0:	st1.s	{ v20 }[1], [x12]
     fc4:	add.2d	v21, v5, v22
     fc8:	mov.d	x12, v21[1]
     fcc:	fmov	x23, d21
     fd0:	st1.s	{ v20 }[2], [x23]
     fd4:	st1.s	{ v20 }[3], [x12]
     fd8:	add	x22, x22, #0x20
     fdc:	add	x21, x21, #0x4
     fe0:	cmp	x22, #0x2, lsl #12
     fe4:	b.ne	0xf54
     fe8:	mov	x21, #0x0
     fec:	orr	w12, w20, #0x38
     ff0:	dup.4s	v6, w12
     ff4:	orr.16b	v16, v6, v0
     ff8:	orr.16b	v17, v6, v1
     ffc:	ushll2.2d	v6, v16, #0xa
    1000:	ushll2.2d	v7, v17, #0xa
    1004:	ushll.2d	v16, v16, #0xa
    1008:	ushll.2d	v17, v17, #0xa
    100c:	add	x20, sp, #0x2, lsl #12
    1010:	add	x20, x20, #0x20
    1014:	dup.2d	v18, x21
    1018:	add.2d	v19, v18, v17
    101c:	add.2d	v20, v18, v7
    1020:	add.2d	v21, v18, v16
    1024:	add.2d	v18, v18, v6
    1028:	add.2d	v18, v4, v18
    102c:	add.2d	v21, v4, v21
    1030:	add.2d	v20, v4, v20
    1034:	add.2d	v19, v4, v19
    1038:	mov.d	x12, v19[1]
    103c:	fmov	x22, d19
    1040:	mov.d	x23, v20[1]
    1044:	fmov	x24, d20
    1048:	mov.d	x25, v21[1]
    104c:	fmov	x26, d21
    1050:	mov.d	x27, v18[1]
    1054:	ldr	s19, [x26]
    1058:	ld1.s	{ v19 }[1], [x25]
    105c:	fmov	x25, d18
    1060:	ld1.s	{ v19 }[2], [x25]
    1064:	ld1.s	{ v19 }[3], [x27]
    1068:	ldr	s18, [x22]
    106c:	ld1.s	{ v18 }[1], [x12]
    1070:	ld1.s	{ v18 }[2], [x24]
    1074:	ld1.s	{ v18 }[3], [x23]
    1078:	stp	q18, q19, [x20], #0x20
    107c:	add	x21, x21, #0x4
    1080:	cmp	x21, #0x400
    1084:	b.ne	0x1014
    1088:	mov	x20, #0x0
    108c:	ldp	q4, q18, [x9]
    1090:	fmul.4s	v18, v18, v18
    1094:	fmul.4s	v4, v4, v4
    1098:	ldp	q19, q20, [x9, #0x20]
    109c:	fmul.4s	v20, v20, v20
    10a0:	fmul.4s	v19, v19, v19
    10a4:	ldp	q22, q21, [x9, #0x40]
    10a8:	fmul.4s	v21, v21, v21
    10ac:	fmul.4s	v22, v22, v22
    10b0:	ldp	q23, q24, [x9, #0x60]
    10b4:	fmul.4s	v24, v24, v24
    10b8:	fmul.4s	v23, v23, v23
    10bc:	add	x12, x9, x20, lsl #5
    10c0:	ldp	q26, q25, [x12, #0x80]
    10c4:	fmul.4s	v26, v26, v26
    10c8:	fmul.4s	v25, v25, v25
    10cc:	fadd.4s	v18, v18, v25
    10d0:	fadd.4s	v4, v4, v26
    10d4:	ldp	q26, q25, [x12, #0xa0]
    10d8:	fmul.4s	v26, v26, v26
    10dc:	fmul.4s	v25, v25, v25
    10e0:	fadd.4s	v20, v20, v25
    10e4:	fadd.4s	v19, v19, v26
    10e8:	ldp	q26, q25, [x12, #0xc0]
    10ec:	fmul.4s	v26, v26, v26
    10f0:	fmul.4s	v25, v25, v25
    10f4:	fadd.4s	v21, v21, v25
    10f8:	fadd.4s	v22, v22, v26
    10fc:	ldp	q26, q25, [x12, #0xe0]
    1100:	fmul.4s	v26, v26, v26
    1104:	fmul.4s	v25, v25, v25
    1108:	fadd.4s	v24, v24, v25
    110c:	fadd.4s	v23, v23, v26
    1110:	add	x20, x20, #0x4
    1114:	cmp	x20, #0xfc
    1118:	b.lo	0x10bc
    111c:	mov	x20, #0x0
    1120:	add	x12, x19, x20, lsl #2
    1124:	ld1r.4s	{ v25 }, [x12]
    1128:	add	x12, x14, x20, lsl #5
    112c:	stp	q25, q25, [x12]
    1130:	add	x20, x20, #0x1
    1134:	cmp	x20, #0x100
    1138:	b.ne	0x1120
    113c:	mov	x19, #0x0
    1140:	mov	x20, #0x0
    1144:	fadd.4s	v18, v18, v20
    1148:	fadd.4s	v4, v4, v19
    114c:	fadd.4s	v4, v4, v22
    1150:	fadd.4s	v18, v18, v21
    1154:	fadd.4s	v18, v18, v24
    1158:	fadd.4s	v4, v4, v23
    115c:	fmul.4s	v4, v4, v3
    1160:	fmul.4s	v3, v18, v3
    1164:	fadd.4s	v3, v3, v2
    1168:	fadd.4s	v2, v4, v2
    116c:	fsqrt.4s	v2, v2
    1170:	fsqrt.4s	v3, v3
    1174:	add	x12, x9, x20
    1178:	ldp	q18, q4, [x12]
    117c:	fdiv.4s	v18, v18, v2
    1180:	fdiv.4s	v4, v4, v3
    1184:	add	x12, x14, x20
    1188:	ldp	q19, q20, [x12]
    118c:	fmul.4s	v4, v4, v20
    1190:	fmul.4s	v18, v18, v19
    1194:	dup.2d	v19, x19
    1198:	add.2d	v20, v19, v17
    119c:	add.2d	v21, v19, v7
    11a0:	add.2d	v22, v19, v16
    11a4:	add.2d	v19, v19, v6
    11a8:	add.2d	v21, v5, v21
    11ac:	add.2d	v20, v5, v20
    11b0:	mov.d	x12, v20[1]
    11b4:	fmov	x21, d20
    11b8:	str	s18, [x21]
    11bc:	st1.s	{ v18 }[1], [x12]
    11c0:	mov.d	x12, v21[1]
    11c4:	add.2d	v20, v5, v22
    11c8:	fmov	x21, d21
    11cc:	st1.s	{ v18 }[2], [x21]
    11d0:	st1.s	{ v18 }[3], [x12]
    11d4:	mov.d	x12, v20[1]
    11d8:	fmov	x21, d20
    11dc:	str	s4, [x21]
    11e0:	st1.s	{ v4 }[1], [x12]
    11e4:	add.2d	v18, v5, v19
    11e8:	mov.d	x12, v18[1]
    11ec:	fmov	x21, d18
    11f0:	st1.s	{ v4 }[2], [x21]
    11f4:	st1.s	{ v4 }[3], [x12]
    11f8:	add	x20, x20, #0x20
    11fc:	add	x19, x19, #0x4
    1200:	cmp	x20, #0x2, lsl #12
    1204:	b.ne	0x1174
    1208:	b	0x74
    120c:	lsr	x21, x19, #3
    1210:	cmp	x19, #0x8
    1214:	b.lo	0x1460
    1218:	mov	w20, #0x0
    121c:	ldr	x22, [x0]
    1220:	ldr	x23, [x0, #0x10]
    1224:	lsl	w24, w7, #6
    1228:	ldr	x25, [x0, #0x30]
    122c:	mov	x26, #0x0
    1230:	add	w12, w24, w20, lsl #3
    1234:	dup.4s	v4, w12
    1238:	orr.16b	v6, v4, v0
    123c:	orr.16b	v7, v4, v1
    1240:	ushll2.2d	v4, v6, #0xa
    1244:	ushll2.2d	v5, v7, #0xa
    1248:	ushll.2d	v6, v6, #0xa
    124c:	ushll.2d	v7, v7, #0xa
    1250:	add	x27, sp, #0x2, lsl #12
    1254:	add	x27, x27, #0x20
    1258:	dup.2d	v16, x26
    125c:	add.2d	v17, v16, v7
    1260:	add.2d	v18, v16, v5
    1264:	add.2d	v19, v16, v6
    1268:	add.2d	v16, v16, v4
    126c:	dup.2d	v20, x22
    1270:	add.2d	v16, v20, v16
    1274:	add.2d	v19, v20, v19
    1278:	add.2d	v18, v20, v18
    127c:	add.2d	v17, v20, v17
    1280:	mov.d	x12, v17[1]
    1284:	fmov	x28, d17
    1288:	mov.d	x30, v18[1]
    128c:	fmov	x17, d18
    1290:	mov.d	x13, v19[1]
    1294:	fmov	x2, d19
    1298:	mov.d	x15, v16[1]
    129c:	ldr	s17, [x2]
    12a0:	ld1.s	{ v17 }[1], [x13]
    12a4:	fmov	x13, d16
    12a8:	ld1.s	{ v17 }[2], [x13]
    12ac:	ld1.s	{ v17 }[3], [x15]
    12b0:	ldr	s16, [x28]
    12b4:	ld1.s	{ v16 }[1], [x12]
    12b8:	ld1.s	{ v16 }[2], [x17]
    12bc:	ld1.s	{ v16 }[3], [x30]
    12c0:	stp	q16, q17, [x27], #0x20
    12c4:	add	x26, x26, #0x4
    12c8:	cmp	x26, #0x400
    12cc:	b.ne	0x1258
    12d0:	mov	x26, #0x0
    12d4:	ldp	q16, q17, [x9]
    12d8:	fmul.4s	v17, v17, v17
    12dc:	fmul.4s	v16, v16, v16
    12e0:	ldp	q18, q19, [x9, #0x20]
    12e4:	fmul.4s	v19, v19, v19
    12e8:	fmul.4s	v18, v18, v18
    12ec:	ldp	q21, q20, [x9, #0x40]
    12f0:	fmul.4s	v20, v20, v20
    12f4:	fmul.4s	v21, v21, v21
    12f8:	ldp	q22, q23, [x9, #0x60]
    12fc:	fmul.4s	v23, v23, v23
    1300:	fmul.4s	v22, v22, v22
    1304:	add	x12, x9, x26, lsl #5
    1308:	ldp	q25, q24, [x12, #0x80]
    130c:	fmul.4s	v25, v25, v25
    1310:	fmul.4s	v24, v24, v24
    1314:	fadd.4s	v17, v17, v24
    1318:	fadd.4s	v16, v16, v25
    131c:	ldp	q25, q24, [x12, #0xa0]
    1320:	fmul.4s	v25, v25, v25
    1324:	fmul.4s	v24, v24, v24
    1328:	fadd.4s	v19, v19, v24
    132c:	fadd.4s	v18, v18, v25
    1330:	ldp	q25, q24, [x12, #0xc0]
    1334:	fmul.4s	v25, v25, v25
    1338:	fmul.4s	v24, v24, v24
    133c:	fadd.4s	v20, v20, v24
    1340:	fadd.4s	v21, v21, v25
    1344:	ldp	q25, q24, [x12, #0xe0]
    1348:	fmul.4s	v25, v25, v25
    134c:	fmul.4s	v24, v24, v24
    1350:	fadd.4s	v23, v23, v24
    1354:	fadd.4s	v22, v22, v25
    1358:	add	x26, x26, #0x4
    135c:	cmp	x26, #0xfc
    1360:	b.lo	0x1304
    1364:	mov	x26, #0x0
    1368:	add	x12, x23, x26, lsl #2
    136c:	ld1r.4s	{ v24 }, [x12]
    1370:	add	x12, x14, x26, lsl #5
    1374:	stp	q24, q24, [x12]
    1378:	add	x26, x26, #0x1
    137c:	cmp	x26, #0x100
    1380:	b.ne	0x1368
    1384:	mov	x26, #0x0
    1388:	mov	x27, #0x0
    138c:	fadd.4s	v17, v17, v19
    1390:	fadd.4s	v16, v16, v18
    1394:	fadd.4s	v16, v16, v21
    1398:	fadd.4s	v17, v17, v20
    139c:	fadd.4s	v17, v17, v23
    13a0:	fadd.4s	v16, v16, v22
    13a4:	fmul.4s	v16, v16, v3
    13a8:	fmul.4s	v17, v17, v3
    13ac:	fadd.4s	v17, v17, v2
    13b0:	fadd.4s	v16, v16, v2
    13b4:	fsqrt.4s	v16, v16
    13b8:	fsqrt.4s	v17, v17
    13bc:	add	x12, x9, x27
    13c0:	ldp	q19, q18, [x12]
    13c4:	fdiv.4s	v19, v19, v16
    13c8:	fdiv.4s	v18, v18, v17
    13cc:	add	x12, x14, x27
    13d0:	ldp	q20, q21, [x12]
    13d4:	fmul.4s	v18, v18, v21
    13d8:	fmul.4s	v19, v19, v20
    13dc:	dup.2d	v20, x26
    13e0:	add.2d	v21, v20, v7
    13e4:	add.2d	v22, v20, v5
    13e8:	add.2d	v23, v20, v6
    13ec:	add.2d	v20, v20, v4
    13f0:	dup.2d	v24, x25
    13f4:	add.2d	v22, v24, v22
    13f8:	add.2d	v21, v24, v21
    13fc:	mov.d	x12, v21[1]
    1400:	fmov	x13, d21
    1404:	str	s19, [x13]
    1408:	st1.s	{ v19 }[1], [x12]
    140c:	mov.d	x12, v22[1]
    1410:	add.2d	v21, v24, v23
    1414:	fmov	x13, d22
    1418:	st1.s	{ v19 }[2], [x13]
    141c:	st1.s	{ v19 }[3], [x12]
    1420:	mov.d	x12, v21[1]
    1424:	fmov	x13, d21
    1428:	str	s18, [x13]
    142c:	st1.s	{ v18 }[1], [x12]
    1430:	add.2d	v19, v24, v20
    1434:	mov.d	x12, v19[1]
    1438:	fmov	x13, d19
    143c:	st1.s	{ v18 }[2], [x13]
    1440:	st1.s	{ v18 }[3], [x12]
    1444:	add	x27, x27, #0x20
    1448:	add	x26, x26, #0x4
    144c:	cmp	x27, #0x2, lsl #12
    1450:	b.ne	0x13bc
    1454:	add	w20, w20, #0x1
    1458:	cmp	w20, w21
    145c:	b.ne	0x122c
    1460:	and	w19, w19, #0x7
    1464:	cbz	w19, 0x74
    1468:	dup.4s	v5, w19
    146c:	cmhi.4s	v4, v5, v0
    1470:	cmhi.4s	v5, v5, v1
    1474:	uzp1.8h	v19, v5, v4
    1478:	umaxv.8h	h6, v19
    147c:	fmov	w12, s6
    1480:	tbz	w12, #0x0, 0x74
    1484:	mov	x22, #0x0
    1488:	ldr	x23, [x0]
    148c:	ldr	x20, [x0, #0x10]
    1490:	ldr	x19, [x0, #0x30]
    1494:	lsl	w12, w21, #3
    1498:	orr	w12, w12, w7, lsl #6
    149c:	dup.4s	v6, w12
    14a0:	orr.16b	v7, v6, v1
    14a4:	orr.16b	v6, v6, v0
    14a8:	and.16b	v16, v4, v6
    14ac:	and.16b	v17, v5, v7
    14b0:	ushll2.2d	v6, v16, #0xa
    14b4:	ushll2.2d	v7, v17, #0xa
    14b8:	ushll.2d	v16, v16, #0xa
    14bc:	ushll.2d	v17, v17, #0xa
    14c0:	add	x21, sp, #0x2, lsl #12
    14c4:	add	x21, x21, #0x20
    14c8:	b	0x14e8
    14cc:	ldp	q22, q23, [x21]
    14d0:	bif.16b	v21, v23, v4
    14d4:	bif.16b	v20, v22, v5
    14d8:	stp	q20, q21, [x21], #0x20
    14dc:	add	x22, x22, #0x4
    14e0:	cmp	x22, #0x400
    14e4:	b.eq	0x15cc
    14e8:	ldr	q18, [x1, lCPI0_2@PAGEOFF]
    14ec:	and.16b	v18, v19, v18
    14f0:	addv.8h	h18, v18
    14f4:	fmov	w24, s18
    14f8:	dup.2d	v22, x22
    14fc:	add.2d	v20, v22, v17
    1500:	dup.2d	v23, x23
    1504:	add.2d	v24, v23, v20
    1508:	movi.2d	v20, #0000000000000000
    150c:	movi.2d	v21, #0000000000000000
    1510:	tbnz	w24, #0x0, 0x1550
    1514:	and	w24, w24, #0xff
    1518:	tbnz	w24, #0x1, 0x1560
    151c:	add.2d	v24, v22, v7
    1520:	add.2d	v24, v23, v24
    1524:	tbnz	w24, #0x2, 0x1574
    1528:	tbnz	w24, #0x3, 0x1580
    152c:	add.2d	v24, v22, v16
    1530:	add.2d	v24, v23, v24
    1534:	tbnz	w24, #0x4, 0x1594
    1538:	tbnz	w24, #0x5, 0x15a0
    153c:	add.2d	v22, v22, v6
    1540:	add.2d	v22, v23, v22
    1544:	tbnz	w24, #0x6, 0x15b4
    1548:	tbz	w24, #0x7, 0x14cc
    154c:	b	0x15c0
    1550:	fmov	x12, d24
    1554:	ldr	s20, [x12]
    1558:	and	w24, w24, #0xff
    155c:	tbz	w24, #0x1, 0x151c
    1560:	mov.d	x12, v24[1]
    1564:	ld1.s	{ v20 }[1], [x12]
    1568:	add.2d	v24, v22, v7
    156c:	add.2d	v24, v23, v24
    1570:	tbz	w24, #0x2, 0x1528
    1574:	fmov	x12, d24
    1578:	ld1.s	{ v20 }[2], [x12]
    157c:	tbz	w24, #0x3, 0x152c
    1580:	mov.d	x12, v24[1]
    1584:	ld1.s	{ v20 }[3], [x12]
    1588:	add.2d	v24, v22, v16
    158c:	add.2d	v24, v23, v24
    1590:	tbz	w24, #0x4, 0x1538
    1594:	fmov	x12, d24
    1598:	ld1.s	{ v21 }[0], [x12]
    159c:	tbz	w24, #0x5, 0x153c
    15a0:	mov.d	x12, v24[1]
    15a4:	ld1.s	{ v21 }[1], [x12]
    15a8:	add.2d	v22, v22, v6
    15ac:	add.2d	v22, v23, v22
    15b0:	tbz	w24, #0x6, 0x1548
    15b4:	fmov	x12, d22
    15b8:	ld1.s	{ v21 }[2], [x12]
    15bc:	tbz	w24, #0x7, 0x14cc
    15c0:	mov.d	x12, v22[1]
    15c4:	ld1.s	{ v21 }[3], [x12]
    15c8:	b	0x14cc
    15cc:	ldp	q20, q19, [x9]
    15d0:	fmul.4s	v20, v20, v20
    15d4:	fmul.4s	v19, v19, v19
    15d8:	ldp	q22, q21, [x9, #0x20]
    15dc:	fmul.4s	v23, v22, v22
    15e0:	fmul.4s	v21, v21, v21
    15e4:	ldp	q24, q22, [x9, #0x40]
    15e8:	fmul.4s	v25, v24, v24
    15ec:	fmul.4s	v24, v22, v22
    15f0:	ldp	q26, q22, [x9, #0x60]
    15f4:	fmul.4s	v27, v26, v26
    15f8:	fmul.4s	v28, v22, v22
    15fc:	and.16b	v19, v4, v19
    1600:	and.16b	v22, v5, v20
    1604:	and.16b	v21, v4, v21
    1608:	and.16b	v26, v5, v23
    160c:	and.16b	v24, v4, v24
    1610:	and.16b	v23, v5, v25
    1614:	and.16b	v20, v4, v28
    1618:	and.16b	v25, v5, v27
    161c:	ldr	x21, [sp, #0x10]
    1620:	mov	w22, #0x4
    1624:	ldp	q28, q27, [x21, #-0x60]
    1628:	and.16b	v28, v5, v28
    162c:	and.16b	v27, v4, v27
    1630:	fmul.4s	v27, v27, v27
    1634:	fmul.4s	v28, v28, v28
    1638:	fadd.4s	v28, v22, v28
    163c:	fadd.4s	v27, v19, v27
    1640:	ldp	q30, q29, [x21, #-0x40]
    1644:	and.16b	v30, v5, v30
    1648:	and.16b	v29, v4, v29
    164c:	fmul.4s	v29, v29, v29
    1650:	fmul.4s	v30, v30, v30
    1654:	fadd.4s	v30, v26, v30
    1658:	fadd.4s	v29, v21, v29
    165c:	ldp	q8, q31, [x21, #-0x20]
    1660:	and.16b	v8, v5, v8
    1664:	and.16b	v31, v4, v31
    1668:	fmul.4s	v31, v31, v31
    166c:	fmul.4s	v8, v8, v8
    1670:	fadd.4s	v8, v23, v8
    1674:	fadd.4s	v31, v24, v31
    1678:	ldp	q10, q9, [x21], #0x80
    167c:	and.16b	v10, v5, v10
    1680:	and.16b	v9, v4, v9
    1684:	fmul.4s	v9, v9, v9
    1688:	fmul.4s	v10, v10, v10
    168c:	fadd.4s	v10, v25, v10
    1690:	fadd.4s	v9, v20, v9
    1694:	bit.16b	v19, v27, v4
    1698:	bit.16b	v22, v28, v5
    169c:	bit.16b	v21, v29, v4
    16a0:	bit.16b	v26, v30, v5
    16a4:	bit.16b	v24, v31, v4
    16a8:	bit.16b	v23, v8, v5
    16ac:	bit.16b	v20, v9, v4
    16b0:	bit.16b	v25, v10, v5
    16b4:	cmp	x22, #0xfc
    16b8:	add	x22, x22, #0x4
    16bc:	b.lo	0x1624
    16c0:	mov	x21, #0x0
    16c4:	add	x12, x20, x21, lsl #2
    16c8:	ld1r.4s	{ v27 }, [x12]
    16cc:	add	x12, x14, x21, lsl #5
    16d0:	ldp	q28, q29, [x12]
    16d4:	bit.16b	v29, v27, v4
    16d8:	bif.16b	v27, v28, v5
    16dc:	stp	q27, q29, [x12]
    16e0:	add	x21, x21, #0x1
    16e4:	cmp	x21, #0x100
    16e8:	b.ne	0x16c4
    16ec:	mov	x20, #0x0
    16f0:	fadd.4s	v22, v22, v26
    16f4:	fadd.4s	v19, v19, v21
    16f8:	fadd.4s	v19, v19, v24
    16fc:	fadd.4s	v21, v22, v23
    1700:	fadd.4s	v21, v21, v25
    1704:	fadd.4s	v19, v19, v20
    1708:	fmul.4s	v19, v19, v3
    170c:	fmul.4s	v3, v21, v3
    1710:	fadd.4s	v3, v3, v2
    1714:	fadd.4s	v2, v19, v2
    1718:	fsqrt.4s	v19, v2
    171c:	fsqrt.4s	v2, v3
    1720:	and.16b	v2, v5, v2
    1724:	and.16b	v3, v4, v19
    1728:	add	x21, sp, #0x20
    172c:	add	x22, sp, #0x2, lsl #12
    1730:	add	x22, x22, #0x20
    1734:	b	0x174c
    1738:	add	x20, x20, #0x4
    173c:	add	x21, x21, #0x20
    1740:	add	x22, x22, #0x20
    1744:	cmp	x20, #0x400
    1748:	b.eq	0x74
    174c:	fmov	w23, s18
    1750:	ldp	q19, q21, [x22]
    1754:	and.16b	v19, v5, v19
    1758:	fdiv.4s	v19, v19, v2
    175c:	ldp	q20, q22, [x21]
    1760:	and.16b	v20, v5, v20
    1764:	fmul.4s	v23, v19, v20
    1768:	dup.2d	v19, x20
    176c:	add.2d	v24, v19, v17
    1770:	dup.2d	v20, x19
    1774:	add.2d	v24, v20, v24
    1778:	tbnz	w23, #0x0, 0x17d0
    177c:	and	w23, w23, #0xff
    1780:	tbnz	w23, #0x1, 0x17e0
    1784:	add.2d	v24, v19, v7
    1788:	add.2d	v24, v20, v24
    178c:	tbnz	w23, #0x2, 0x17f4
    1790:	tbz	w23, #0x3, 0x179c
    1794:	mov.d	x12, v24[1]
    1798:	st1.s	{ v23 }[3], [x12]
    179c:	and.16b	v21, v4, v21
    17a0:	fdiv.4s	v21, v21, v3
    17a4:	and.16b	v22, v4, v22
    17a8:	fmul.4s	v21, v21, v22
    17ac:	add.2d	v22, v19, v16
    17b0:	add.2d	v22, v20, v22
    17b4:	tbnz	w23, #0x4, 0x1804
    17b8:	tbnz	w23, #0x5, 0x1810
    17bc:	add.2d	v19, v19, v6
    17c0:	add.2d	v19, v20, v19
    17c4:	tbnz	w23, #0x6, 0x1824
    17c8:	tbz	w23, #0x7, 0x1738
    17cc:	b	0x1830
    17d0:	fmov	x12, d24
    17d4:	str	s23, [x12]
    17d8:	and	w23, w23, #0xff
    17dc:	tbz	w23, #0x1, 0x1784
    17e0:	mov.d	x12, v24[1]
    17e4:	st1.s	{ v23 }[1], [x12]
    17e8:	add.2d	v24, v19, v7
    17ec:	add.2d	v24, v20, v24
    17f0:	tbz	w23, #0x2, 0x1790
    17f4:	fmov	x12, d24
    17f8:	st1.s	{ v23 }[2], [x12]
    17fc:	tbnz	w23, #0x3, 0x1794
    1800:	b	0x179c
    1804:	fmov	x12, d22
    1808:	str	s21, [x12]
    180c:	tbz	w23, #0x5, 0x17bc
    1810:	mov.d	x12, v22[1]
    1814:	st1.s	{ v21 }[1], [x12]
    1818:	add.2d	v19, v19, v6
    181c:	add.2d	v19, v20, v19
    1820:	tbz	w23, #0x6, 0x17c8
    1824:	fmov	x12, d19
    1828:	st1.s	{ v21 }[2], [x12]
    182c:	tbz	w23, #0x7, 0x1738
    1830:	mov.d	x12, v19[1]
    1834:	st1.s	{ v21 }[3], [x12]
    1838:	b	0x1738
    183c:	ldr	x9, [sp, #0x8]
    1840:	stp	w7, w6, [x9]
    1844:	str	w5, [x9, #0x8]
    1848:	mov	w8, #0x38
    184c:	str	w8, [x9, #0x24]
    1850:	add	sp, sp, #0x4, lsl #12
    1854:	add	sp, sp, #0x20
    1858:	ldp	x29, x30, [sp, #0x70]
    185c:	ldp	x20, x19, [sp, #0x60]
    1860:	ldp	x22, x21, [sp, #0x50]
    1864:	ldp	x24, x23, [sp, #0x40]
    1868:	ldp	x26, x25, [sp, #0x30]
    186c:	ldp	x28, x27, [sp, #0x20]
    1870:	ldp	d9, d8, [sp, #0x10]
    1874:	ldp	d11, d10, [sp], #0x80
    1878:	ret

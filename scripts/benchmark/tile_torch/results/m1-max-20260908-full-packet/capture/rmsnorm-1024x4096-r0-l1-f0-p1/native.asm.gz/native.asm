/tmp/luisa-full-packet.UEezjO/capture/rmsnorm-1024x4096-r0-l1-f0-p1/object/tile_xir_w8_63772_1788856228476177_0.o:
(__TEXT,__text) section
_llm_rows.packet_batch.blocks:
       0:	cbz	w3, 0x98c
       4:	sub	sp, sp, #0x90
       8:	stp	d11, d10, [sp, #0x10]
       c:	stp	d9, d8, [sp, #0x20]
      10:	stp	x28, x27, [sp, #0x30]
      14:	stp	x26, x25, [sp, #0x40]
      18:	stp	x24, x23, [sp, #0x50]
      1c:	stp	x22, x21, [sp, #0x60]
      20:	stp	x20, x19, [sp, #0x70]
      24:	stp	x29, x30, [sp, #0x80]
      28:	mov	w8, #0x0
      2c:	ldp	w9, w10, [x2, #0x2c]
      30:	str	w9, [sp, #0x8]
      34:	ldp	w4, w5, [x2]
      38:	adrp	x12, lCPI0_0@PAGE
      3c:	ldr	q0, [x12, lCPI0_0@PAGEOFF]
      40:	adrp	x12, lCPI0_1@PAGE
      44:	ldr	q1, [x12, lCPI0_1@PAGEOFF]
      48:	adrp	x14, lCPI0_2@PAGE
      4c:	ldp	w6, w15, [x2, #0x8]
      50:	b	0x8c
      54:	add	w9, w1, #0x1
      58:	ldr	w11, [sp, #0x8]
      5c:	cmp	w9, w11
      60:	cset	w9, eq
      64:	csinc	w4, wzr, w1, eq
      68:	cinc	w11, w17, eq
      6c:	cmp	w11, w10
      70:	cset	w12, eq
      74:	ands	w9, w9, w12
      78:	csel	w5, wzr, w11, ne
      7c:	add	w6, w16, w9
      80:	add	w8, w8, #0x1
      84:	cmp	w8, w3
      88:	b.eq	0x958
      8c:	mov	x16, x6
      90:	mov	x17, x5
      94:	mov	x1, x4
      98:	ubfiz	x4, x4, #10, #32
      9c:	cmp	x4, x15
      a0:	csel	x5, x4, xzr, ls
      a4:	subs	x6, x15, x5
      a8:	cmp	x6, #0x400
      ac:	mov	w9, #0x400
      b0:	csel	x6, x6, x9, lo
      b4:	cmp	x15, x5
      b8:	ccmp	x4, x15, #0x2, hi
      bc:	csel	x4, x6, xzr, ls
      c0:	mov	w9, #0x39800000
      c4:	dup.4s	v3, w9
      c8:	mov	w9, #0xc5ac
      cc:	movk	w9, #0x3727, lsl #16
      d0:	dup.4s	v2, w9
      d4:	cmp	x4, #0x400
      d8:	b.lo	0x32c
      dc:	mov	w4, #0x0
      e0:	ldr	x5, [x2, #0x88]
      e4:	ldr	x22, [x0]
      e8:	ldr	x6, [x0, #0x10]
      ec:	ldr	x7, [x0, #0x30]
      f0:	lsl	w19, w1, #10
      f4:	add	x20, x5, #0x20, lsl #12
      f8:	add	x21, x5, #0xe0
      fc:	dup.2d	v4, x22
     100:	mov	x22, #0x0
     104:	add	w23, w19, w4, lsl #3
     108:	dup.4s	v5, w23
     10c:	orr.16b	v7, v5, v0
     110:	orr.16b	v16, v5, v1
     114:	ushll2.2d	v5, v7, #0xe
     118:	ushll2.2d	v6, v16, #0xe
     11c:	ushll.2d	v7, v7, #0xe
     120:	ushll.2d	v16, v16, #0xe
     124:	mov	x23, x5
     128:	dup.2d	v17, x22
     12c:	add.2d	v18, v17, v16
     130:	add.2d	v19, v17, v6
     134:	add.2d	v20, v17, v7
     138:	add.2d	v17, v17, v5
     13c:	add.2d	v17, v4, v17
     140:	add.2d	v20, v4, v20
     144:	add.2d	v19, v4, v19
     148:	add.2d	v18, v4, v18
     14c:	mov.d	x24, v18[1]
     150:	fmov	x25, d18
     154:	mov.d	x26, v19[1]
     158:	fmov	x27, d19
     15c:	mov.d	x28, v20[1]
     160:	fmov	x30, d20
     164:	mov.d	x11, v17[1]
     168:	ldr	s18, [x25]
     16c:	ld1.s	{ v18 }[1], [x24]
     170:	fmov	x24, d17
     174:	ld1.s	{ v18 }[2], [x27]
     178:	ld1.s	{ v18 }[3], [x26]
     17c:	ldr	s17, [x30]
     180:	ld1.s	{ v17 }[1], [x28]
     184:	ld1.s	{ v17 }[2], [x24]
     188:	ld1.s	{ v17 }[3], [x11]
     18c:	stp	q18, q17, [x23], #0x20
     190:	add	x22, x22, #0x4
     194:	cmp	x22, #0x4, lsl #12
     198:	b.ne	0x128
     19c:	ldp	q17, q18, [x5]
     1a0:	fmul.4s	v18, v18, v18
     1a4:	fmul.4s	v17, v17, v17
     1a8:	ldp	q19, q20, [x5, #0x20]
     1ac:	fmul.4s	v20, v20, v20
     1b0:	fmul.4s	v19, v19, v19
     1b4:	ldp	q22, q21, [x5, #0x40]
     1b8:	fmul.4s	v21, v21, v21
     1bc:	fmul.4s	v22, v22, v22
     1c0:	ldp	q23, q24, [x5, #0x60]
     1c4:	fmul.4s	v24, v24, v24
     1c8:	fmul.4s	v23, v23, v23
     1cc:	mov	x22, x21
     1d0:	mov	w23, #0x4
     1d4:	ldp	q26, q25, [x22, #-0x60]
     1d8:	fmul.4s	v26, v26, v26
     1dc:	fmul.4s	v25, v25, v25
     1e0:	fadd.4s	v18, v18, v25
     1e4:	fadd.4s	v17, v17, v26
     1e8:	ldp	q26, q25, [x22, #-0x40]
     1ec:	fmul.4s	v26, v26, v26
     1f0:	fmul.4s	v25, v25, v25
     1f4:	fadd.4s	v20, v20, v25
     1f8:	fadd.4s	v19, v19, v26
     1fc:	ldp	q26, q25, [x22, #-0x20]
     200:	fmul.4s	v26, v26, v26
     204:	fmul.4s	v25, v25, v25
     208:	fadd.4s	v21, v21, v25
     20c:	fadd.4s	v22, v22, v26
     210:	ldp	q26, q25, [x22], #0x80
     214:	fmul.4s	v26, v26, v26
     218:	fmul.4s	v25, v25, v25
     21c:	fadd.4s	v24, v24, v25
     220:	fadd.4s	v23, v23, v26
     224:	cmp	x23, #0xffc
     228:	add	x23, x23, #0x4
     22c:	b.lo	0x1d4
     230:	mov	x22, #0x0
     234:	add	x11, x6, x22, lsl #2
     238:	ld1r.4s	{ v25 }, [x11]
     23c:	add	x11, x20, x22, lsl #5
     240:	stp	q25, q25, [x11]
     244:	add	x22, x22, #0x1
     248:	cmp	x22, #0x1, lsl #12
     24c:	b.ne	0x234
     250:	mov	x22, #0x0
     254:	fadd.4s	v18, v18, v20
     258:	fadd.4s	v17, v17, v19
     25c:	fadd.4s	v17, v17, v22
     260:	fadd.4s	v18, v18, v21
     264:	fadd.4s	v18, v18, v24
     268:	fadd.4s	v17, v17, v23
     26c:	fmul.4s	v17, v17, v3
     270:	fmul.4s	v18, v18, v3
     274:	fadd.4s	v18, v18, v2
     278:	fadd.4s	v17, v17, v2
     27c:	fsqrt.4s	v17, v17
     280:	fsqrt.4s	v18, v18
     284:	mov	x23, x5
     288:	ldp	q20, q19, [x23]
     28c:	fdiv.4s	v20, v20, v17
     290:	fdiv.4s	v19, v19, v18
     294:	add	x11, x23, #0x20, lsl #12
     298:	ldp	q21, q22, [x11]
     29c:	fmul.4s	v19, v19, v22
     2a0:	fmul.4s	v20, v20, v21
     2a4:	dup.2d	v21, x22
     2a8:	add.2d	v22, v21, v16
     2ac:	add.2d	v23, v21, v6
     2b0:	add.2d	v24, v21, v7
     2b4:	add.2d	v21, v21, v5
     2b8:	dup.2d	v25, x7
     2bc:	add.2d	v23, v25, v23
     2c0:	add.2d	v22, v25, v22
     2c4:	mov.d	x11, v22[1]
     2c8:	fmov	x24, d22
     2cc:	str	s20, [x24]
     2d0:	st1.s	{ v20 }[1], [x11]
     2d4:	mov.d	x11, v23[1]
     2d8:	add.2d	v22, v25, v24
     2dc:	fmov	x24, d23
     2e0:	st1.s	{ v20 }[2], [x24]
     2e4:	st1.s	{ v20 }[3], [x11]
     2e8:	mov.d	x11, v22[1]
     2ec:	fmov	x24, d22
     2f0:	str	s19, [x24]
     2f4:	st1.s	{ v19 }[1], [x11]
     2f8:	add.2d	v20, v25, v21
     2fc:	mov.d	x11, v20[1]
     300:	fmov	x24, d20
     304:	st1.s	{ v19 }[2], [x24]
     308:	st1.s	{ v19 }[3], [x11]
     30c:	add	x22, x22, #0x4
     310:	add	x23, x23, #0x20
     314:	cmp	x22, #0x4, lsl #12
     318:	b.ne	0x288
     31c:	add	w4, w4, #0x1
     320:	cmp	w4, #0x80
     324:	b.ne	0x100
     328:	b	0x54
     32c:	lsr	x19, x4, #3
     330:	cmp	x4, #0x8
     334:	b.lo	0x584
     338:	mov	w5, #0x0
     33c:	ldr	x6, [x2, #0x88]
     340:	ldr	x7, [x0]
     344:	ldr	x20, [x0, #0x10]
     348:	ldr	x21, [x0, #0x30]
     34c:	lsl	w22, w1, #10
     350:	add	x23, x6, #0x20, lsl #12
     354:	add	x24, x6, #0xe0
     358:	mov	x25, #0x0
     35c:	add	w11, w22, w5, lsl #3
     360:	dup.4s	v4, w11
     364:	orr.16b	v6, v4, v0
     368:	orr.16b	v7, v4, v1
     36c:	ushll2.2d	v4, v6, #0xe
     370:	ushll2.2d	v5, v7, #0xe
     374:	ushll.2d	v6, v6, #0xe
     378:	ushll.2d	v7, v7, #0xe
     37c:	mov	x26, x6
     380:	dup.2d	v16, x25
     384:	add.2d	v17, v16, v7
     388:	add.2d	v18, v16, v5
     38c:	add.2d	v19, v16, v6
     390:	add.2d	v16, v16, v4
     394:	dup.2d	v20, x7
     398:	add.2d	v16, v20, v16
     39c:	add.2d	v19, v20, v19
     3a0:	add.2d	v18, v20, v18
     3a4:	add.2d	v17, v20, v17
     3a8:	mov.d	x11, v17[1]
     3ac:	fmov	x27, d17
     3b0:	mov.d	x28, v18[1]
     3b4:	fmov	x30, d18
     3b8:	mov.d	x12, v19[1]
     3bc:	fmov	x13, d19
     3c0:	mov.d	x9, v16[1]
     3c4:	ldr	s17, [x27]
     3c8:	ld1.s	{ v17 }[1], [x11]
     3cc:	fmov	x11, d16
     3d0:	ld1.s	{ v17 }[2], [x30]
     3d4:	ld1.s	{ v17 }[3], [x28]
     3d8:	ldr	s16, [x13]
     3dc:	ld1.s	{ v16 }[1], [x12]
     3e0:	ld1.s	{ v16 }[2], [x11]
     3e4:	ld1.s	{ v16 }[3], [x9]
     3e8:	stp	q17, q16, [x26], #0x20
     3ec:	add	x25, x25, #0x4
     3f0:	cmp	x25, #0x4, lsl #12
     3f4:	b.ne	0x380
     3f8:	ldp	q16, q17, [x6]
     3fc:	fmul.4s	v17, v17, v17
     400:	fmul.4s	v16, v16, v16
     404:	ldp	q18, q19, [x6, #0x20]
     408:	fmul.4s	v19, v19, v19
     40c:	fmul.4s	v18, v18, v18
     410:	ldp	q21, q20, [x6, #0x40]
     414:	fmul.4s	v20, v20, v20
     418:	fmul.4s	v21, v21, v21
     41c:	ldp	q22, q23, [x6, #0x60]
     420:	fmul.4s	v23, v23, v23
     424:	fmul.4s	v22, v22, v22
     428:	mov	x25, x24
     42c:	mov	w26, #0x4
     430:	ldp	q25, q24, [x25, #-0x60]
     434:	fmul.4s	v25, v25, v25
     438:	fmul.4s	v24, v24, v24
     43c:	fadd.4s	v17, v17, v24
     440:	fadd.4s	v16, v16, v25
     444:	ldp	q25, q24, [x25, #-0x40]
     448:	fmul.4s	v25, v25, v25
     44c:	fmul.4s	v24, v24, v24
     450:	fadd.4s	v19, v19, v24
     454:	fadd.4s	v18, v18, v25
     458:	ldp	q25, q24, [x25, #-0x20]
     45c:	fmul.4s	v25, v25, v25
     460:	fmul.4s	v24, v24, v24
     464:	fadd.4s	v20, v20, v24
     468:	fadd.4s	v21, v21, v25
     46c:	ldp	q25, q24, [x25], #0x80
     470:	fmul.4s	v25, v25, v25
     474:	fmul.4s	v24, v24, v24
     478:	fadd.4s	v23, v23, v24
     47c:	fadd.4s	v22, v22, v25
     480:	cmp	x26, #0xffc
     484:	add	x26, x26, #0x4
     488:	b.lo	0x430
     48c:	mov	x25, #0x0
     490:	add	x9, x20, x25, lsl #2
     494:	ld1r.4s	{ v24 }, [x9]
     498:	add	x9, x23, x25, lsl #5
     49c:	stp	q24, q24, [x9]
     4a0:	add	x25, x25, #0x1
     4a4:	cmp	x25, #0x1, lsl #12
     4a8:	b.ne	0x490
     4ac:	mov	x25, #0x0
     4b0:	fadd.4s	v17, v17, v19
     4b4:	fadd.4s	v16, v16, v18
     4b8:	fadd.4s	v16, v16, v21
     4bc:	fadd.4s	v17, v17, v20
     4c0:	fadd.4s	v17, v17, v23
     4c4:	fadd.4s	v16, v16, v22
     4c8:	fmul.4s	v16, v16, v3
     4cc:	fmul.4s	v17, v17, v3
     4d0:	fadd.4s	v17, v17, v2
     4d4:	fadd.4s	v16, v16, v2
     4d8:	fsqrt.4s	v16, v16
     4dc:	fsqrt.4s	v17, v17
     4e0:	mov	x26, x6
     4e4:	ldp	q19, q18, [x26]
     4e8:	fdiv.4s	v19, v19, v16
     4ec:	fdiv.4s	v18, v18, v17
     4f0:	add	x9, x26, #0x20, lsl #12
     4f4:	ldp	q20, q21, [x9]
     4f8:	fmul.4s	v18, v18, v21
     4fc:	fmul.4s	v19, v19, v20
     500:	dup.2d	v20, x25
     504:	add.2d	v21, v20, v7
     508:	add.2d	v22, v20, v5
     50c:	add.2d	v23, v20, v6
     510:	add.2d	v20, v20, v4
     514:	dup.2d	v24, x21
     518:	add.2d	v22, v24, v22
     51c:	add.2d	v21, v24, v21
     520:	mov.d	x9, v21[1]
     524:	fmov	x11, d21
     528:	str	s19, [x11]
     52c:	st1.s	{ v19 }[1], [x9]
     530:	mov.d	x9, v22[1]
     534:	add.2d	v21, v24, v23
     538:	fmov	x11, d22
     53c:	st1.s	{ v19 }[2], [x11]
     540:	st1.s	{ v19 }[3], [x9]
     544:	mov.d	x9, v21[1]
     548:	fmov	x11, d21
     54c:	str	s18, [x11]
     550:	st1.s	{ v18 }[1], [x9]
     554:	add.2d	v19, v24, v20
     558:	mov.d	x9, v19[1]
     55c:	fmov	x11, d19
     560:	st1.s	{ v18 }[2], [x11]
     564:	st1.s	{ v18 }[3], [x9]
     568:	add	x25, x25, #0x4
     56c:	add	x26, x26, #0x20
     570:	cmp	x25, #0x4, lsl #12
     574:	b.ne	0x4e4
     578:	add	w5, w5, #0x1
     57c:	cmp	w5, w19
     580:	b.ne	0x358
     584:	and	w4, w4, #0x7
     588:	cbz	w4, 0x54
     58c:	dup.4s	v5, w4
     590:	cmhi.4s	v4, v5, v0
     594:	cmhi.4s	v5, v5, v1
     598:	uzp1.8h	v19, v5, v4
     59c:	umaxv.8h	h6, v19
     5a0:	fmov	w9, s6
     5a4:	tbz	w9, #0x0, 0x54
     5a8:	mov	x20, #0x0
     5ac:	ldr	x4, [x2, #0x88]
     5b0:	add	x6, x4, #0x20, lsl #12
     5b4:	ldr	x21, [x0]
     5b8:	ldr	x7, [x0, #0x10]
     5bc:	ldr	x5, [x0, #0x30]
     5c0:	lsl	w9, w19, #3
     5c4:	orr	w9, w9, w1, lsl #10
     5c8:	dup.4s	v6, w9
     5cc:	orr.16b	v7, v6, v1
     5d0:	orr.16b	v6, v6, v0
     5d4:	and.16b	v16, v4, v6
     5d8:	and.16b	v17, v5, v7
     5dc:	ushll2.2d	v6, v16, #0xe
     5e0:	ushll2.2d	v7, v17, #0xe
     5e4:	ushll.2d	v16, v16, #0xe
     5e8:	ushll.2d	v17, v17, #0xe
     5ec:	mov	x19, x4
     5f0:	b	0x610
     5f4:	ldp	q22, q23, [x19]
     5f8:	bif.16b	v21, v23, v4
     5fc:	bif.16b	v20, v22, v5
     600:	stp	q20, q21, [x19], #0x20
     604:	add	x20, x20, #0x4
     608:	cmp	x20, #0x4, lsl #12
     60c:	b.eq	0x6f4
     610:	ldr	q18, [x14, lCPI0_2@PAGEOFF]
     614:	and.16b	v18, v19, v18
     618:	addv.8h	h18, v18
     61c:	fmov	w22, s18
     620:	dup.2d	v22, x20
     624:	add.2d	v20, v22, v17
     628:	dup.2d	v23, x21
     62c:	add.2d	v24, v23, v20
     630:	movi.2d	v20, #0000000000000000
     634:	movi.2d	v21, #0000000000000000
     638:	tbnz	w22, #0x0, 0x678
     63c:	and	w22, w22, #0xff
     640:	tbnz	w22, #0x1, 0x688
     644:	add.2d	v24, v22, v7
     648:	add.2d	v24, v23, v24
     64c:	tbnz	w22, #0x2, 0x69c
     650:	tbnz	w22, #0x3, 0x6a8
     654:	add.2d	v24, v22, v16
     658:	add.2d	v24, v23, v24
     65c:	tbnz	w22, #0x4, 0x6bc
     660:	tbnz	w22, #0x5, 0x6c8
     664:	add.2d	v22, v22, v6
     668:	add.2d	v22, v23, v22
     66c:	tbnz	w22, #0x6, 0x6dc
     670:	tbz	w22, #0x7, 0x5f4
     674:	b	0x6e8
     678:	fmov	x9, d24
     67c:	ldr	s20, [x9]
     680:	and	w22, w22, #0xff
     684:	tbz	w22, #0x1, 0x644
     688:	mov.d	x9, v24[1]
     68c:	ld1.s	{ v20 }[1], [x9]
     690:	add.2d	v24, v22, v7
     694:	add.2d	v24, v23, v24
     698:	tbz	w22, #0x2, 0x650
     69c:	fmov	x9, d24
     6a0:	ld1.s	{ v20 }[2], [x9]
     6a4:	tbz	w22, #0x3, 0x654
     6a8:	mov.d	x9, v24[1]
     6ac:	ld1.s	{ v20 }[3], [x9]
     6b0:	add.2d	v24, v22, v16
     6b4:	add.2d	v24, v23, v24
     6b8:	tbz	w22, #0x4, 0x660
     6bc:	fmov	x9, d24
     6c0:	ld1.s	{ v21 }[0], [x9]
     6c4:	tbz	w22, #0x5, 0x664
     6c8:	mov.d	x9, v24[1]
     6cc:	ld1.s	{ v21 }[1], [x9]
     6d0:	add.2d	v22, v22, v6
     6d4:	add.2d	v22, v23, v22
     6d8:	tbz	w22, #0x6, 0x670
     6dc:	fmov	x9, d22
     6e0:	ld1.s	{ v21 }[2], [x9]
     6e4:	tbz	w22, #0x7, 0x5f4
     6e8:	mov.d	x9, v22[1]
     6ec:	ld1.s	{ v21 }[3], [x9]
     6f0:	b	0x5f4
     6f4:	ldp	q20, q19, [x4]
     6f8:	fmul.4s	v20, v20, v20
     6fc:	fmul.4s	v19, v19, v19
     700:	ldp	q22, q21, [x4, #0x20]
     704:	fmul.4s	v23, v22, v22
     708:	fmul.4s	v21, v21, v21
     70c:	ldp	q24, q22, [x4, #0x40]
     710:	fmul.4s	v25, v24, v24
     714:	fmul.4s	v24, v22, v22
     718:	ldp	q26, q22, [x4, #0x60]
     71c:	fmul.4s	v27, v26, v26
     720:	fmul.4s	v28, v22, v22
     724:	and.16b	v19, v4, v19
     728:	and.16b	v22, v5, v20
     72c:	and.16b	v21, v4, v21
     730:	and.16b	v26, v5, v23
     734:	and.16b	v24, v4, v24
     738:	and.16b	v23, v5, v25
     73c:	and.16b	v20, v4, v28
     740:	and.16b	v25, v5, v27
     744:	add	x19, x4, #0xe0
     748:	mov	w20, #0x4
     74c:	ldp	q28, q27, [x19, #-0x60]
     750:	and.16b	v28, v5, v28
     754:	and.16b	v27, v4, v27
     758:	fmul.4s	v27, v27, v27
     75c:	fmul.4s	v28, v28, v28
     760:	fadd.4s	v28, v22, v28
     764:	fadd.4s	v27, v19, v27
     768:	ldp	q30, q29, [x19, #-0x40]
     76c:	and.16b	v30, v5, v30
     770:	and.16b	v29, v4, v29
     774:	fmul.4s	v29, v29, v29
     778:	fmul.4s	v30, v30, v30
     77c:	fadd.4s	v30, v26, v30
     780:	fadd.4s	v29, v21, v29
     784:	ldp	q8, q31, [x19, #-0x20]
     788:	and.16b	v8, v5, v8
     78c:	and.16b	v31, v4, v31
     790:	fmul.4s	v31, v31, v31
     794:	fmul.4s	v8, v8, v8
     798:	fadd.4s	v8, v23, v8
     79c:	fadd.4s	v31, v24, v31
     7a0:	ldp	q10, q9, [x19], #0x80
     7a4:	and.16b	v10, v5, v10
     7a8:	and.16b	v9, v4, v9
     7ac:	fmul.4s	v9, v9, v9
     7b0:	fmul.4s	v10, v10, v10
     7b4:	fadd.4s	v10, v25, v10
     7b8:	fadd.4s	v9, v20, v9
     7bc:	bit.16b	v19, v27, v4
     7c0:	bit.16b	v22, v28, v5
     7c4:	bit.16b	v21, v29, v4
     7c8:	bit.16b	v26, v30, v5
     7cc:	bit.16b	v24, v31, v4
     7d0:	bit.16b	v23, v8, v5
     7d4:	bit.16b	v20, v9, v4
     7d8:	bit.16b	v25, v10, v5
     7dc:	cmp	x20, #0xffc
     7e0:	add	x20, x20, #0x4
     7e4:	b.lo	0x74c
     7e8:	mov	x19, #0x0
     7ec:	add	x9, x7, x19, lsl #2
     7f0:	ld1r.4s	{ v27 }, [x9]
     7f4:	add	x9, x6, x19, lsl #5
     7f8:	ldp	q28, q29, [x9]
     7fc:	bit.16b	v29, v27, v4
     800:	bif.16b	v27, v28, v5
     804:	stp	q27, q29, [x9]
     808:	add	x19, x19, #0x1
     80c:	cmp	x19, #0x1, lsl #12
     810:	b.ne	0x7ec
     814:	mov	x6, #0x0
     818:	fadd.4s	v22, v22, v26
     81c:	fadd.4s	v19, v19, v21
     820:	fadd.4s	v19, v19, v24
     824:	fadd.4s	v21, v22, v23
     828:	fadd.4s	v21, v21, v25
     82c:	fadd.4s	v19, v19, v20
     830:	fmul.4s	v19, v19, v3
     834:	fmul.4s	v3, v21, v3
     838:	fadd.4s	v3, v3, v2
     83c:	fadd.4s	v2, v19, v2
     840:	fsqrt.4s	v19, v2
     844:	fsqrt.4s	v2, v3
     848:	and.16b	v2, v5, v2
     84c:	and.16b	v3, v4, v19
     850:	b	0x864
     854:	add	x6, x6, #0x4
     858:	add	x4, x4, #0x20
     85c:	cmp	x6, #0x4, lsl #12
     860:	b.eq	0x54
     864:	fmov	w7, s18
     868:	ldp	q19, q21, [x4]
     86c:	and.16b	v19, v5, v19
     870:	fdiv.4s	v19, v19, v2
     874:	add	x9, x4, #0x20, lsl #12
     878:	ldp	q20, q22, [x9]
     87c:	and.16b	v20, v5, v20
     880:	fmul.4s	v23, v19, v20
     884:	dup.2d	v19, x6
     888:	add.2d	v24, v19, v17
     88c:	dup.2d	v20, x5
     890:	add.2d	v24, v20, v24
     894:	tbnz	w7, #0x0, 0x8ec
     898:	and	w7, w7, #0xff
     89c:	tbnz	w7, #0x1, 0x8fc
     8a0:	add.2d	v24, v19, v7
     8a4:	add.2d	v24, v20, v24
     8a8:	tbnz	w7, #0x2, 0x910
     8ac:	tbz	w7, #0x3, 0x8b8
     8b0:	mov.d	x9, v24[1]
     8b4:	st1.s	{ v23 }[3], [x9]
     8b8:	and.16b	v21, v4, v21
     8bc:	fdiv.4s	v21, v21, v3
     8c0:	and.16b	v22, v4, v22
     8c4:	fmul.4s	v21, v21, v22
     8c8:	add.2d	v22, v19, v16
     8cc:	add.2d	v22, v20, v22
     8d0:	tbnz	w7, #0x4, 0x920
     8d4:	tbnz	w7, #0x5, 0x92c
     8d8:	add.2d	v19, v19, v6
     8dc:	add.2d	v19, v20, v19
     8e0:	tbnz	w7, #0x6, 0x940
     8e4:	tbz	w7, #0x7, 0x854
     8e8:	b	0x94c
     8ec:	fmov	x9, d24
     8f0:	str	s23, [x9]
     8f4:	and	w7, w7, #0xff
     8f8:	tbz	w7, #0x1, 0x8a0
     8fc:	mov.d	x9, v24[1]
     900:	st1.s	{ v23 }[1], [x9]
     904:	add.2d	v24, v19, v7
     908:	add.2d	v24, v20, v24
     90c:	tbz	w7, #0x2, 0x8ac
     910:	fmov	x9, d24
     914:	st1.s	{ v23 }[2], [x9]
     918:	tbnz	w7, #0x3, 0x8b0
     91c:	b	0x8b8
     920:	fmov	x9, d22
     924:	str	s21, [x9]
     928:	tbz	w7, #0x5, 0x8d8
     92c:	mov.d	x9, v22[1]
     930:	st1.s	{ v21 }[1], [x9]
     934:	add.2d	v19, v19, v6
     938:	add.2d	v19, v20, v19
     93c:	tbz	w7, #0x6, 0x8e4
     940:	fmov	x9, d19
     944:	st1.s	{ v21 }[2], [x9]
     948:	tbz	w7, #0x7, 0x854
     94c:	mov.d	x9, v19[1]
     950:	st1.s	{ v21 }[3], [x9]
     954:	b	0x854
     958:	stp	w1, w17, [x2]
     95c:	str	w16, [x2, #0x8]
     960:	mov	w8, #0x3f8
     964:	str	w8, [x2, #0x24]
     968:	ldp	x29, x30, [sp, #0x80]
     96c:	ldp	x20, x19, [sp, #0x70]
     970:	ldp	x22, x21, [sp, #0x60]
     974:	ldp	x24, x23, [sp, #0x50]
     978:	ldp	x26, x25, [sp, #0x40]
     97c:	ldp	x28, x27, [sp, #0x30]
     980:	ldp	d9, d8, [sp, #0x20]
     984:	ldp	d11, d10, [sp, #0x10]
     988:	add	sp, sp, #0x90
     98c:	ret

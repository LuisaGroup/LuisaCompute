/tmp/luisa-full-packet.UEezjO/capture/rmsnorm-1024x4096-r0-l8-f0-p1/object/tile_xir_w8_63776_1788856230476029_0.o:
(__TEXT,__text) section
_llm_rows.packet_batch.blocks:
       0:	stp	d9, d8, [sp, #-0x70]!
       4:	stp	x28, x27, [sp, #0x10]
       8:	stp	x26, x25, [sp, #0x20]
       c:	stp	x24, x23, [sp, #0x30]
      10:	stp	x22, x21, [sp, #0x40]
      14:	stp	x20, x19, [sp, #0x50]
      18:	stp	x29, x30, [sp, #0x60]
      1c:	sub	sp, sp, #0x8, lsl #12
      20:	sub	sp, sp, #0x260
      24:	str	x0, [sp, #0x28]
      28:	cbz	w3, 0xb30
      2c:	mov	x28, x3
      30:	mov	w11, #0x0
      34:	add	x24, sp, #0x170
      38:	add	x25, sp, #0x4, lsl #12
      3c:	add	x25, x25, #0x260
      40:	ldp	w9, w8, [x2, #0x2c]
      44:	stp	w8, w9, [sp, #0x44]
      48:	ldp	w8, w9, [x2]
      4c:	add	x10, x25, #0xe0
      50:	stp	x2, x10, [sp, #0x10]
      54:	add	x19, sp, #0x260
      58:	ldp	w10, w12, [x2, #0x8]
      5c:	str	x12, [sp, #0x38]
      60:	movi	d8, #0000000000000000
      64:	str	w3, [sp, #0x24]
      68:	b	0xb4
      6c:	ldr	x14, [sp, #0x58]
      70:	add	w8, w14, #0x1
      74:	ldp	w9, w13, [sp, #0x48]
      78:	cmp	w8, w9
      7c:	cset	w9, eq
      80:	csinc	w8, wzr, w14, eq
      84:	cinc	w10, w13, eq
      88:	ldr	w11, [sp, #0x44]
      8c:	cmp	w10, w11
      90:	cset	w11, eq
      94:	ands	w11, w9, w11
      98:	csel	w9, wzr, w10, ne
      9c:	ldr	w12, [sp, #0x50]
      a0:	add	w10, w12, w11
      a4:	ldr	w11, [sp, #0x54]
      a8:	add	w11, w11, #0x1
      ac:	cmp	w11, w28
      b0:	b.eq	0xb1c
      b4:	mov	w27, #0x39800000
      b8:	str	w11, [sp, #0x54]
      bc:	mov	x13, x10
      c0:	mov	x14, x9
      c4:	mov	x15, x8
      c8:	ubfiz	x8, x8, #10, #32
      cc:	ldr	x12, [sp, #0x38]
      d0:	cmp	x8, x12
      d4:	csel	x9, x8, xzr, ls
      d8:	subs	x10, x12, x9
      dc:	cmp	x10, #0x400
      e0:	mov	w11, #0x400
      e4:	csel	x10, x10, x11, lo
      e8:	cmp	x12, x9
      ec:	ccmp	x8, x12, #0x2, hi
      f0:	csel	x8, x10, xzr, ls
      f4:	cmp	x8, #0x400
      f8:	stp	w14, w13, [sp, #0x4c]
      fc:	str	x15, [sp, #0x58]
     100:	b.lo	0x2c8
     104:	mov	x20, #0x0
     108:	ldr	x8, [sp, #0x28]
     10c:	ldr	x21, [x8]
     110:	ldr	x22, [x8, #0x10]
     114:	ldr	x8, [x8, #0x30]
     118:	lsl	w23, w15, #7
     11c:	and	x9, x15, #0x3fffff
     120:	add	x26, x8, x9, lsl #21
     124:	add	w8, w20, w23
     128:	ubfiz	x8, x8, #14, #29
     12c:	add	x0, sp, #0x4, lsl #12
     130:	add	x0, x0, #0x260
     134:	add	x1, x21, x8
     138:	mov	w2, #0x4000
     13c:	bl	_memcpy
     140:	mov	x8, #0x0
     144:	ldr	q0, [x24, #0x40f0]
     148:	ldr	q1, [x24, #0x4100]
     14c:	fmul.4s	v2, v1, v1
     150:	fmul.4s	v3, v0, v0
     154:	ldr	q0, [x24, #0x4110]
     158:	ldr	q1, [x24, #0x4120]
     15c:	fmul.4s	v4, v1, v1
     160:	fmul.4s	v5, v0, v0
     164:	ldr	q0, [x24, #0x4130]
     168:	ldr	q1, [x24, #0x4140]
     16c:	fmul.4s	v7, v1, v1
     170:	fmul.4s	v6, v0, v0
     174:	ldr	q0, [x24, #0x4150]
     178:	ldr	q1, [x24, #0x4160]
     17c:	fmul.4s	v16, v1, v1
     180:	fmul.4s	v17, v0, v0
     184:	add	x9, x25, x8, lsl #5
     188:	ldp	q1, q0, [x9, #0x80]
     18c:	fmul.4s	v1, v1, v1
     190:	fmul.4s	v0, v0, v0
     194:	fadd.4s	v2, v2, v0
     198:	fadd.4s	v3, v3, v1
     19c:	ldp	q1, q0, [x9, #0xa0]
     1a0:	fmul.4s	v1, v1, v1
     1a4:	fmul.4s	v0, v0, v0
     1a8:	fadd.4s	v4, v4, v0
     1ac:	fadd.4s	v5, v5, v1
     1b0:	ldp	q1, q0, [x9, #0xc0]
     1b4:	fmul.4s	v1, v1, v1
     1b8:	fmul.4s	v0, v0, v0
     1bc:	fadd.4s	v7, v7, v0
     1c0:	fadd.4s	v6, v6, v1
     1c4:	ldp	q1, q0, [x9, #0xe0]
     1c8:	fmul.4s	v1, v1, v1
     1cc:	fmul.4s	v0, v0, v0
     1d0:	fadd.4s	v16, v16, v0
     1d4:	fadd.4s	v17, v17, v1
     1d8:	add	x8, x8, #0x4
     1dc:	cmp	x8, #0x1fc
     1e0:	b.lo	0x184
     1e4:	add	x0, sp, #0x260
     1e8:	mov	x1, x22
     1ec:	mov	w2, #0x4000
     1f0:	stp	q4, q2, [sp, #0x90]
     1f4:	stp	q5, q3, [sp, #0x60]
     1f8:	stp	q6, q16, [sp, #0xc0]
     1fc:	str	q7, [sp, #0x80]
     200:	str	q17, [sp, #0xb0]
     204:	bl	_memcpy
     208:	mov	x8, #0x0
     20c:	ldp	q1, q0, [sp, #0x60]
     210:	fadd.4s	v0, v0, v1
     214:	ldp	q2, q1, [sp, #0x90]
     218:	fadd.4s	v1, v1, v2
     21c:	ldr	q2, [sp, #0x80]
     220:	fadd.4s	v1, v1, v2
     224:	ldp	q2, q3, [sp, #0xb0]
     228:	fadd.4s	v0, v0, v3
     22c:	fadd.4s	v0, v0, v2
     230:	ldr	q2, [sp, #0xd0]
     234:	fadd.4s	v1, v1, v2
     238:	rev64.4s	v2, v1
     23c:	rev64.4s	v3, v0
     240:	fadd.4s	v0, v0, v3
     244:	fadd.4s	v1, v1, v2
     248:	dup.4s	v2, v1[2]
     24c:	dup.4s	v3, v0[2]
     250:	fadd.4s	v0, v0, v3
     254:	fadd.4s	v1, v1, v2
     258:	fadd.4s	v0, v0, v1
     25c:	fadd	s0, s0, s8
     260:	fmov	s1, w27
     264:	fmul	s0, s0, s1
     268:	mov	w9, #0xc5ac
     26c:	movk	w9, #0x3727, lsl #16
     270:	fmov	s1, w9
     274:	fadd	s0, s0, s1
     278:	fsqrt	s0, s0
     27c:	dup.4s	v0, v0[0]
     280:	add	x9, x25, x8
     284:	ldp	q1, q2, [x9]
     288:	fdiv.4s	v2, v2, v0
     28c:	fdiv.4s	v1, v1, v0
     290:	add	x9, x19, x8
     294:	ldp	q4, q3, [x9]
     298:	fmul.4s	v1, v1, v4
     29c:	fmul.4s	v2, v2, v3
     2a0:	add	x9, x26, x8
     2a4:	stp	q1, q2, [x9]
     2a8:	add	x8, x8, #0x20
     2ac:	cmp	x8, #0x4, lsl #12
     2b0:	b.ne	0x280
     2b4:	add	x20, x20, #0x1
     2b8:	add	x26, x26, #0x4, lsl #12
     2bc:	cmp	x20, #0x80
     2c0:	b.ne	0x124
     2c4:	b	0x6c
     2c8:	lsr	x21, x8, #3
     2cc:	str	x8, [sp, #0x30]
     2d0:	cmp	x8, #0x8
     2d4:	b.lo	0x49c
     2d8:	mov	x20, #0x0
     2dc:	ldr	x8, [sp, #0x28]
     2e0:	ldr	x23, [x8]
     2e4:	ldr	x22, [x8, #0x10]
     2e8:	ldr	x8, [x8, #0x30]
     2ec:	ldr	x9, [sp, #0x58]
     2f0:	lsl	w28, w9, #7
     2f4:	and	x9, x9, #0x3fffff
     2f8:	add	x26, x8, x9, lsl #21
     2fc:	add	w8, w20, w28
     300:	ubfiz	x8, x8, #14, #29
     304:	add	x0, sp, #0x4, lsl #12
     308:	add	x0, x0, #0x260
     30c:	add	x1, x23, x8
     310:	mov	w2, #0x4000
     314:	bl	_memcpy
     318:	mov	x8, #0x0
     31c:	ldr	q0, [x24, #0x40f0]
     320:	ldr	q1, [x24, #0x4100]
     324:	fmul.4s	v2, v1, v1
     328:	fmul.4s	v3, v0, v0
     32c:	ldr	q0, [x24, #0x4110]
     330:	ldr	q1, [x24, #0x4120]
     334:	fmul.4s	v4, v1, v1
     338:	fmul.4s	v5, v0, v0
     33c:	ldr	q0, [x24, #0x4130]
     340:	ldr	q1, [x24, #0x4140]
     344:	fmul.4s	v7, v1, v1
     348:	fmul.4s	v6, v0, v0
     34c:	ldr	q0, [x24, #0x4150]
     350:	ldr	q1, [x24, #0x4160]
     354:	fmul.4s	v16, v1, v1
     358:	fmul.4s	v17, v0, v0
     35c:	add	x9, x25, x8, lsl #5
     360:	ldp	q1, q0, [x9, #0x80]
     364:	fmul.4s	v1, v1, v1
     368:	fmul.4s	v0, v0, v0
     36c:	fadd.4s	v2, v2, v0
     370:	fadd.4s	v3, v3, v1
     374:	ldp	q1, q0, [x9, #0xa0]
     378:	fmul.4s	v1, v1, v1
     37c:	fmul.4s	v0, v0, v0
     380:	fadd.4s	v4, v4, v0
     384:	fadd.4s	v5, v5, v1
     388:	ldp	q1, q0, [x9, #0xc0]
     38c:	fmul.4s	v1, v1, v1
     390:	fmul.4s	v0, v0, v0
     394:	fadd.4s	v7, v7, v0
     398:	fadd.4s	v6, v6, v1
     39c:	ldp	q1, q0, [x9, #0xe0]
     3a0:	fmul.4s	v1, v1, v1
     3a4:	fmul.4s	v0, v0, v0
     3a8:	fadd.4s	v16, v16, v0
     3ac:	fadd.4s	v17, v17, v1
     3b0:	add	x8, x8, #0x4
     3b4:	cmp	x8, #0x1fc
     3b8:	b.lo	0x35c
     3bc:	add	x0, sp, #0x260
     3c0:	mov	x1, x22
     3c4:	mov	w2, #0x4000
     3c8:	stp	q4, q2, [sp, #0x90]
     3cc:	stp	q5, q3, [sp, #0x60]
     3d0:	stp	q6, q16, [sp, #0xc0]
     3d4:	str	q7, [sp, #0x80]
     3d8:	str	q17, [sp, #0xb0]
     3dc:	bl	_memcpy
     3e0:	mov	x8, #0x0
     3e4:	ldp	q1, q0, [sp, #0x60]
     3e8:	fadd.4s	v0, v0, v1
     3ec:	ldp	q2, q1, [sp, #0x90]
     3f0:	fadd.4s	v1, v1, v2
     3f4:	ldr	q2, [sp, #0x80]
     3f8:	fadd.4s	v1, v1, v2
     3fc:	ldp	q2, q3, [sp, #0xb0]
     400:	fadd.4s	v0, v0, v3
     404:	fadd.4s	v0, v0, v2
     408:	ldr	q2, [sp, #0xd0]
     40c:	fadd.4s	v1, v1, v2
     410:	rev64.4s	v2, v1
     414:	rev64.4s	v3, v0
     418:	fadd.4s	v0, v0, v3
     41c:	fadd.4s	v1, v1, v2
     420:	dup.4s	v2, v1[2]
     424:	dup.4s	v3, v0[2]
     428:	fadd.4s	v0, v0, v3
     42c:	fadd.4s	v1, v1, v2
     430:	fadd.4s	v0, v0, v1
     434:	fadd	s0, s0, s8
     438:	fmov	s1, w27
     43c:	fmul	s0, s0, s1
     440:	mov	w9, #0xc5ac
     444:	movk	w9, #0x3727, lsl #16
     448:	fmov	s1, w9
     44c:	fadd	s0, s0, s1
     450:	fsqrt	s0, s0
     454:	dup.4s	v0, v0[0]
     458:	add	x9, x25, x8
     45c:	ldp	q1, q2, [x9]
     460:	fdiv.4s	v2, v2, v0
     464:	fdiv.4s	v1, v1, v0
     468:	add	x9, x19, x8
     46c:	ldp	q4, q3, [x9]
     470:	fmul.4s	v1, v1, v4
     474:	fmul.4s	v2, v2, v3
     478:	add	x9, x26, x8
     47c:	stp	q1, q2, [x9]
     480:	add	x8, x8, #0x20
     484:	cmp	x8, #0x4, lsl #12
     488:	b.ne	0x458
     48c:	add	x20, x20, #0x1
     490:	add	x26, x26, #0x4, lsl #12
     494:	cmp	x20, x21
     498:	b.ne	0x2fc
     49c:	ldr	x8, [sp, #0x30]
     4a0:	and	w8, w8, #0x7
     4a4:	ldr	w28, [sp, #0x24]
     4a8:	mov	w5, #0x39800000
     4ac:	cbz	w8, 0x6c
     4b0:	dup.4s	v1, w8
     4b4:	adrp	x8, lCPI0_1@PAGE
     4b8:	ldr	q3, [x8, lCPI0_1@PAGEOFF]
     4bc:	adrp	x8, lCPI0_2@PAGE
     4c0:	ldr	q4, [x8, lCPI0_2@PAGEOFF]
     4c4:	cmhi.4s	v0, v1, v4
     4c8:	cmhi.4s	v1, v1, v3
     4cc:	uzp1.8h	v5, v1, v0
     4d0:	umaxv.8h	h2, v5
     4d4:	fmov	w8, s2
     4d8:	tbz	w8, #0x0, 0x6c
     4dc:	mov	x12, #0x0
     4e0:	ldr	x13, [sp, #0x28]
     4e4:	ldr	x11, [x13, #0x10]
     4e8:	ldr	x8, [x13, #0x30]
     4ec:	adrp	x9, lCPI0_0@PAGE
     4f0:	ldr	q2, [x9, lCPI0_0@PAGEOFF]
     4f4:	and.16b	v2, v5, v2
     4f8:	addv.8h	h2, v2
     4fc:	fmov	w9, s2
     500:	and	w10, w9, #0xff
     504:	ldr	x9, [sp, #0x58]
     508:	ubfiz	w9, w9, #7, #22
     50c:	orr	w9, w9, w21
     510:	ldr	x13, [x13]
     514:	fmov	s6, w9
     518:	and.16b	v6, v1, v6
     51c:	fmov	w9, s6
     520:	ubfiz	x9, x9, #14, #32
     524:	add	x13, x13, x9
     528:	b	0x54c
     52c:	add	x14, x25, x12
     530:	ldp	q16, q17, [x14]
     534:	bif.16b	v7, v17, v0
     538:	bif.16b	v6, v16, v1
     53c:	stp	q6, q7, [x14]
     540:	add	x12, x12, #0x20
     544:	cmp	x12, #0x4, lsl #12
     548:	b.eq	0x5e4
     54c:	fmov	w15, s2
     550:	add	x14, x13, x12
     554:	movi.2d	v6, #0000000000000000
     558:	movi.2d	v7, #0000000000000000
     55c:	tbnz	w15, #0x0, 0x584
     560:	and	w15, w15, #0xff
     564:	tbnz	w15, #0x1, 0x590
     568:	tbnz	w15, #0x2, 0x59c
     56c:	tbnz	w15, #0x3, 0x5a8
     570:	tbnz	w15, #0x4, 0x5b4
     574:	tbnz	w15, #0x5, 0x5c0
     578:	tbnz	w15, #0x6, 0x5cc
     57c:	tbz	w15, #0x7, 0x52c
     580:	b	0x5d8
     584:	ldr	s6, [x14]
     588:	and	w15, w15, #0xff
     58c:	tbz	w15, #0x1, 0x568
     590:	add	x16, x14, #0x4
     594:	ld1.s	{ v6 }[1], [x16]
     598:	tbz	w15, #0x2, 0x56c
     59c:	add	x16, x14, #0x8
     5a0:	ld1.s	{ v6 }[2], [x16]
     5a4:	tbz	w15, #0x3, 0x570
     5a8:	add	x16, x14, #0xc
     5ac:	ld1.s	{ v6 }[3], [x16]
     5b0:	tbz	w15, #0x4, 0x574
     5b4:	add	x16, x14, #0x10
     5b8:	ld1.s	{ v7 }[0], [x16]
     5bc:	tbz	w15, #0x5, 0x578
     5c0:	add	x16, x14, #0x14
     5c4:	ld1.s	{ v7 }[1], [x16]
     5c8:	tbz	w15, #0x6, 0x57c
     5cc:	add	x16, x14, #0x18
     5d0:	ld1.s	{ v7 }[2], [x16]
     5d4:	tbz	w15, #0x7, 0x52c
     5d8:	add	x14, x14, #0x1c
     5dc:	ld1.s	{ v7 }[3], [x14]
     5e0:	b	0x52c
     5e4:	ldr	q6, [x24, #0x4100]
     5e8:	ldr	q7, [x24, #0x40f0]
     5ec:	fmul.4s	v16, v7, v7
     5f0:	fmul.4s	v6, v6, v6
     5f4:	ldr	q7, [x24, #0x4120]
     5f8:	ldr	q17, [x24, #0x4110]
     5fc:	fmul.4s	v17, v17, v17
     600:	fmul.4s	v18, v7, v7
     604:	ldr	q7, [x24, #0x4140]
     608:	ldr	q19, [x24, #0x4130]
     60c:	fmul.4s	v21, v19, v19
     610:	fmul.4s	v22, v7, v7
     614:	ldr	q7, [x24, #0x4160]
     618:	ldr	q19, [x24, #0x4150]
     61c:	fmul.4s	v23, v19, v19
     620:	fmul.4s	v24, v7, v7
     624:	and.16b	v7, v0, v6
     628:	and.16b	v6, v1, v16
     62c:	and.16b	v20, v0, v18
     630:	and.16b	v19, v1, v17
     634:	and.16b	v16, v0, v22
     638:	and.16b	v21, v1, v21
     63c:	and.16b	v18, v0, v24
     640:	and.16b	v17, v1, v23
     644:	ldr	x12, [sp, #0x18]
     648:	mov	w13, #0x4
     64c:	ldp	q23, q22, [x12, #-0x60]
     650:	and.16b	v23, v1, v23
     654:	and.16b	v22, v0, v22
     658:	fmul.4s	v22, v22, v22
     65c:	fmul.4s	v23, v23, v23
     660:	fadd.4s	v23, v6, v23
     664:	fadd.4s	v22, v7, v22
     668:	ldp	q25, q24, [x12, #-0x40]
     66c:	and.16b	v25, v1, v25
     670:	and.16b	v24, v0, v24
     674:	fmul.4s	v24, v24, v24
     678:	fmul.4s	v25, v25, v25
     67c:	fadd.4s	v25, v19, v25
     680:	fadd.4s	v24, v20, v24
     684:	ldp	q27, q26, [x12, #-0x20]
     688:	and.16b	v27, v1, v27
     68c:	and.16b	v26, v0, v26
     690:	fmul.4s	v26, v26, v26
     694:	fmul.4s	v27, v27, v27
     698:	fadd.4s	v27, v21, v27
     69c:	fadd.4s	v26, v16, v26
     6a0:	ldp	q29, q28, [x12], #0x80
     6a4:	and.16b	v29, v1, v29
     6a8:	and.16b	v28, v0, v28
     6ac:	fmul.4s	v28, v28, v28
     6b0:	fmul.4s	v29, v29, v29
     6b4:	fadd.4s	v29, v17, v29
     6b8:	fadd.4s	v28, v18, v28
     6bc:	bit.16b	v7, v22, v0
     6c0:	bit.16b	v6, v23, v1
     6c4:	bit.16b	v20, v24, v0
     6c8:	bit.16b	v19, v25, v1
     6cc:	bit.16b	v16, v26, v0
     6d0:	bit.16b	v21, v27, v1
     6d4:	bit.16b	v18, v28, v0
     6d8:	bit.16b	v17, v29, v1
     6dc:	cmp	x13, #0x1fc
     6e0:	add	x13, x13, #0x4
     6e4:	b.lo	0x64c
     6e8:	mov	x12, #0x0
     6ec:	b	0x710
     6f0:	add	x13, x19, x12
     6f4:	ldp	q24, q25, [x13]
     6f8:	bif.16b	v23, v25, v0
     6fc:	bif.16b	v22, v24, v1
     700:	stp	q22, q23, [x13]
     704:	add	x12, x12, #0x20
     708:	cmp	x12, #0x4, lsl #12
     70c:	b.eq	0x7a8
     710:	fmov	w14, s2
     714:	add	x13, x11, x12
     718:	movi.2d	v22, #0000000000000000
     71c:	movi.2d	v23, #0000000000000000
     720:	tbnz	w14, #0x0, 0x748
     724:	and	w14, w14, #0xff
     728:	tbnz	w14, #0x1, 0x754
     72c:	tbnz	w14, #0x2, 0x760
     730:	tbnz	w14, #0x3, 0x76c
     734:	tbnz	w14, #0x4, 0x778
     738:	tbnz	w14, #0x5, 0x784
     73c:	tbnz	w14, #0x6, 0x790
     740:	tbz	w14, #0x7, 0x6f0
     744:	b	0x79c
     748:	ldr	s22, [x13]
     74c:	and	w14, w14, #0xff
     750:	tbz	w14, #0x1, 0x72c
     754:	add	x15, x13, #0x4
     758:	ld1.s	{ v22 }[1], [x15]
     75c:	tbz	w14, #0x2, 0x730
     760:	add	x15, x13, #0x8
     764:	ld1.s	{ v22 }[2], [x15]
     768:	tbz	w14, #0x3, 0x734
     76c:	add	x15, x13, #0xc
     770:	ld1.s	{ v22 }[3], [x15]
     774:	tbz	w14, #0x4, 0x738
     778:	add	x15, x13, #0x10
     77c:	ld1.s	{ v23 }[0], [x15]
     780:	tbz	w14, #0x5, 0x73c
     784:	add	x15, x13, #0x14
     788:	ld1.s	{ v23 }[1], [x15]
     78c:	tbz	w14, #0x6, 0x740
     790:	add	x15, x13, #0x18
     794:	ld1.s	{ v23 }[2], [x15]
     798:	tbz	w14, #0x7, 0x6f0
     79c:	add	x13, x13, #0x1c
     7a0:	ld1.s	{ v23 }[3], [x13]
     7a4:	b	0x6f0
     7a8:	mov	x11, #0x0
     7ac:	xtn.8b	v22, v5
     7b0:	fadd.4s	v5, v7, v20
     7b4:	fadd.4s	v6, v6, v19
     7b8:	fadd.4s	v6, v6, v21
     7bc:	fadd.4s	v5, v5, v16
     7c0:	fadd.4s	v5, v5, v18
     7c4:	fadd.4s	v6, v6, v17
     7c8:	and.16b	v16, v1, v3
     7cc:	and.16b	v3, v0, v4
     7d0:	movi.4s	v4, #0x1
     7d4:	eor.16b	v7, v3, v4
     7d8:	eor.16b	v18, v16, v4
     7dc:	umov.b	w13, v22[0]
     7e0:	str	q6, [x24, #0xc0]
     7e4:	ldr	s4, [x24, #0xc4]
     7e8:	umov.b	w12, v22[1]
     7ec:	ands	w14, w13, #0x1
     7f0:	tst	w14, w12
     7f4:	mov.s	w15, v18[1]
     7f8:	fcsel	s4, s4, s8, ne
     7fc:	add	x16, sp, #0xe8
     800:	bfxil	x16, x15, #0, #3
     804:	str	d22, [sp, #0xe8]
     808:	ldrb	w16, [x16]
     80c:	add	x17, sp, #0x210
     810:	orr	x15, x17, x15, lsl #2
     814:	stp	q6, q5, [x24, #0xa0]
     818:	ldr	s16, [x15]
     81c:	ands	w15, w12, #0x1
     820:	tst	w15, w16
     824:	fcsel	s16, s16, s8, ne
     828:	mov.s	w15, v18[2]
     82c:	add	x16, sp, #0xe8
     830:	bfxil	x16, x15, #0, #3
     834:	ldrb	w16, [x16]
     838:	add	x17, sp, #0x1f0
     83c:	orr	x17, x17, x15, lsl #2
     840:	umov.b	w15, v22[2]
     844:	stp	q6, q5, [x24, #0x80]
     848:	ldr	s17, [x17]
     84c:	ands	w17, w15, #0x1
     850:	tst	w17, w16
     854:	fcsel	s17, s17, s8, ne
     858:	mov.s	w16, v18[3]
     85c:	add	x17, sp, #0xe8
     860:	bfxil	x17, x16, #0, #3
     864:	ldrb	w17, [x17]
     868:	add	x0, sp, #0x1d0
     86c:	orr	x0, x0, x16, lsl #2
     870:	umov.b	w16, v22[3]
     874:	stp	q6, q5, [x24, #0x60]
     878:	ldr	s18, [x0]
     87c:	ands	w0, w16, #0x1
     880:	tst	w0, w17
     884:	fcsel	s18, s18, s8, ne
     888:	fmov	w0, s7
     88c:	add	x17, sp, #0xe8
     890:	bfxil	x17, x0, #0, #3
     894:	ldrb	w1, [x17]
     898:	umov.b	w17, v22[4]
     89c:	and	w1, w17, w1
     8a0:	stp	q6, q5, [x24, #0x40]
     8a4:	add	x2, sp, #0x1b0
     8a8:	ldr	s19, [x2, w0, uxtw #2]
     8ac:	tst	w1, #0x1
     8b0:	mov.s	w1, v7[1]
     8b4:	fcsel	s19, s19, s8, ne
     8b8:	add	x0, sp, #0xe8
     8bc:	bfxil	x0, x1, #0, #3
     8c0:	ldrb	w2, [x0]
     8c4:	umov.b	w0, v22[5]
     8c8:	stp	q6, q5, [x24, #0x20]
     8cc:	add	x3, sp, #0x190
     8d0:	ldr	s20, [x3, w1, uxtw #2]
     8d4:	ands	w1, w0, #0x1
     8d8:	tst	w1, w2
     8dc:	fcsel	s20, s20, s8, ne
     8e0:	mov.s	w2, v7[2]
     8e4:	add	x1, sp, #0xe8
     8e8:	bfxil	x1, x2, #0, #3
     8ec:	ldrb	w3, [x1]
     8f0:	umov.b	w1, v22[6]
     8f4:	stp	q6, q5, [x24]
     8f8:	ldr	s21, [x24, w2, uxtw #2]
     8fc:	ands	w2, w1, #0x1
     900:	tst	w2, w3
     904:	fcsel	s21, s21, s8, ne
     908:	mov.s	w3, v7[3]
     90c:	add	x2, sp, #0xe8
     910:	bfxil	x2, x3, #0, #3
     914:	ldrb	w4, [x2]
     918:	umov.b	w2, v22[7]
     91c:	stp	q6, q5, [sp, #0x150]
     920:	add	x6, sp, #0x150
     924:	ldr	s7, [x6, w3, uxtw #2]
     928:	ands	w3, w2, #0x1
     92c:	tst	w3, w4
     930:	mov.s	v4[1], v16[0]
     934:	mov.s	v4[2], v17[0]
     938:	mov.s	v4[3], v18[0]
     93c:	mov.s	v19[1], v20[0]
     940:	fcsel	s7, s7, s8, ne
     944:	mov.s	v19[2], v21[0]
     948:	mov.s	v19[3], v7[0]
     94c:	fadd.4s	v5, v5, v19
     950:	fadd.4s	v4, v6, v4
     954:	movi.4s	v6, #0x2
     958:	eor.16b	v3, v3, v6
     95c:	str	q4, [sp, #0x130]
     960:	ldr	s6, [sp, #0x138]
     964:	fmov	w3, s3
     968:	add	x4, sp, #0xe8
     96c:	bfxil	x4, x3, #0, #3
     970:	ldrb	w4, [x4]
     974:	stp	q4, q5, [sp, #0x110]
     978:	add	x6, sp, #0x110
     97c:	ldr	s3, [x6, w3, uxtw #2]
     980:	tst	w14, w15
     984:	fcsel	s6, s6, s8, ne
     988:	and	w3, w17, w4
     98c:	tst	w3, #0x1
     990:	fcsel	s3, s3, s8, ne
     994:	fadd.4s	v3, v5, v3
     998:	tst	w14, w17
     99c:	fcsel	s3, s3, s8, ne
     9a0:	ands	w13, w13, #0x1
     9a4:	fadd.4s	v4, v4, v6
     9a8:	fadd	s3, s4, s3
     9ac:	fcsel	s4, s3, s8, ne
     9b0:	tst	w12, #0x1
     9b4:	fcsel	s5, s4, s8, ne
     9b8:	tst	w15, #0x1
     9bc:	fcsel	s6, s4, s8, ne
     9c0:	tst	w16, #0x1
     9c4:	fcsel	s7, s4, s8, ne
     9c8:	tst	w13, w17
     9cc:	fcsel	s3, s3, s8, ne
     9d0:	tst	w0, #0x1
     9d4:	fcsel	s16, s4, s8, ne
     9d8:	tst	w1, #0x1
     9dc:	fcsel	s17, s4, s8, ne
     9e0:	tst	w2, #0x1
     9e4:	fcsel	s18, s4, s8, ne
     9e8:	mov.s	v4[1], v5[0]
     9ec:	mov.s	v4[2], v6[0]
     9f0:	mov.s	v4[3], v7[0]
     9f4:	mov.s	v3[1], v16[0]
     9f8:	mov.s	v3[2], v17[0]
     9fc:	mov.s	v3[3], v18[0]
     a00:	rbit	w10, w10
     a04:	clz	w10, w10
     a08:	stp	q4, q3, [sp, #0xf0]
     a0c:	and	x10, x10, #0x7
     a10:	add	x12, sp, #0xf0
     a14:	ldr	s3, [x12, x10, lsl #2]
     a18:	fadd	s3, s3, s8
     a1c:	fmov	s4, w5
     a20:	fmul	s3, s3, s4
     a24:	mov	w10, #0xc5ac
     a28:	movk	w10, #0x3727, lsl #16
     a2c:	fmov	s4, w10
     a30:	fadd	s3, s3, s4
     a34:	fsqrt	s3, s3
     a38:	dup.4s	v3, v3[0]
     a3c:	add	x8, x8, x9
     a40:	b	0xa50
     a44:	add	x11, x11, #0x20
     a48:	cmp	x11, #0x4, lsl #12
     a4c:	b.eq	0x6c
     a50:	fmov	w10, s2
     a54:	add	x9, x25, x11
     a58:	ldp	q5, q4, [x9]
     a5c:	and.16b	v5, v1, v5
     a60:	fdiv.4s	v6, v5, v3
     a64:	add	x9, x19, x11
     a68:	ldp	q7, q5, [x9]
     a6c:	and.16b	v7, v1, v7
     a70:	fmul.4s	v6, v6, v7
     a74:	add	x9, x8, x11
     a78:	tbnz	w10, #0x0, 0xab0
     a7c:	and	w10, w10, #0xff
     a80:	tbnz	w10, #0x1, 0xabc
     a84:	tbnz	w10, #0x2, 0xac8
     a88:	tbnz	w10, #0x3, 0xad4
     a8c:	and.16b	v4, v0, v4
     a90:	fdiv.4s	v4, v4, v3
     a94:	and.16b	v5, v0, v5
     a98:	fmul.4s	v4, v4, v5
     a9c:	tbnz	w10, #0x4, 0xaf0
     aa0:	tbnz	w10, #0x5, 0xaf8
     aa4:	tbnz	w10, #0x6, 0xb04
     aa8:	tbz	w10, #0x7, 0xa44
     aac:	b	0xb10
     ab0:	str	s6, [x9]
     ab4:	and	w10, w10, #0xff
     ab8:	tbz	w10, #0x1, 0xa84
     abc:	add	x12, x9, #0x4
     ac0:	st1.s	{ v6 }[1], [x12]
     ac4:	tbz	w10, #0x2, 0xa88
     ac8:	add	x12, x9, #0x8
     acc:	st1.s	{ v6 }[2], [x12]
     ad0:	tbz	w10, #0x3, 0xa8c
     ad4:	add	x12, x9, #0xc
     ad8:	st1.s	{ v6 }[3], [x12]
     adc:	and.16b	v4, v0, v4
     ae0:	fdiv.4s	v4, v4, v3
     ae4:	and.16b	v5, v0, v5
     ae8:	fmul.4s	v4, v4, v5
     aec:	tbz	w10, #0x4, 0xaa0
     af0:	str	s4, [x9, #0x10]
     af4:	tbz	w10, #0x5, 0xaa4
     af8:	add	x12, x9, #0x14
     afc:	st1.s	{ v4 }[1], [x12]
     b00:	tbz	w10, #0x6, 0xaa8
     b04:	add	x12, x9, #0x18
     b08:	st1.s	{ v4 }[2], [x12]
     b0c:	tbz	w10, #0x7, 0xa44
     b10:	add	x9, x9, #0x1c
     b14:	st1.s	{ v4 }[3], [x9]
     b18:	b	0xa44
     b1c:	ldr	x9, [sp, #0x10]
     b20:	stp	w14, w13, [x9]
     b24:	str	w12, [x9, #0x8]
     b28:	mov	w8, #0x3f8
     b2c:	str	w8, [x9, #0x24]
     b30:	add	sp, sp, #0x8, lsl #12
     b34:	add	sp, sp, #0x260
     b38:	ldp	x29, x30, [sp, #0x60]
     b3c:	ldp	x20, x19, [sp, #0x50]
     b40:	ldp	x22, x21, [sp, #0x40]
     b44:	ldp	x24, x23, [sp, #0x30]
     b48:	ldp	x26, x25, [sp, #0x20]
     b4c:	ldp	x28, x27, [sp, #0x10]
     b50:	ldp	d9, d8, [sp], #0x70
     b54:	ret

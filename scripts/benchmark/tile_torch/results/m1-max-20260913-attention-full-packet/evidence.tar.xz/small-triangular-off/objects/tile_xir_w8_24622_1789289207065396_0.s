	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention
lCPI0_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_4:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_5:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_6:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_7:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_8:
	.quad	56                              ; 0x38
	.quad	60                              ; 0x3c
lCPI0_9:
	.quad	48                              ; 0x30
	.quad	52                              ; 0x34
lCPI0_10:
	.quad	40                              ; 0x28
	.quad	44                              ; 0x2c
lCPI0_11:
	.quad	32                              ; 0x20
	.quad	36                              ; 0x24
lCPI0_12:
	.quad	88                              ; 0x58
	.quad	92                              ; 0x5c
lCPI0_13:
	.quad	80                              ; 0x50
	.quad	84                              ; 0x54
lCPI0_14:
	.quad	72                              ; 0x48
	.quad	76                              ; 0x4c
lCPI0_15:
	.quad	64                              ; 0x40
	.quad	68                              ; 0x44
lCPI0_16:
	.quad	120                             ; 0x78
	.quad	124                             ; 0x7c
lCPI0_17:
	.quad	112                             ; 0x70
	.quad	116                             ; 0x74
lCPI0_18:
	.quad	104                             ; 0x68
	.quad	108                             ; 0x6c
lCPI0_19:
	.quad	96                              ; 0x60
	.quad	100                             ; 0x64
lCPI0_20:
	.quad	152                             ; 0x98
	.quad	156                             ; 0x9c
lCPI0_21:
	.quad	144                             ; 0x90
	.quad	148                             ; 0x94
lCPI0_22:
	.quad	136                             ; 0x88
	.quad	140                             ; 0x8c
lCPI0_23:
	.quad	128                             ; 0x80
	.quad	132                             ; 0x84
lCPI0_24:
	.quad	184                             ; 0xb8
	.quad	188                             ; 0xbc
lCPI0_25:
	.quad	176                             ; 0xb0
	.quad	180                             ; 0xb4
lCPI0_26:
	.quad	168                             ; 0xa8
	.quad	172                             ; 0xac
lCPI0_27:
	.quad	160                             ; 0xa0
	.quad	164                             ; 0xa4
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_3:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention:                         ; @llm_attention
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-144]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x26, x25, [sp, #64]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	add	x29, sp, #128
	sub	x9, sp, #2, lsl #12             ; =8192
	sub	x9, x9, #3696
	and	sp, x9, #0xffffffffffffffc0
	str	xzr, [sp, #11832]
	add	x8, sp, #2, lsl #12             ; =8192
	add	x8, x8, #3552
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #11792]
	str	q0, [sp, #11808]
	add	x9, sp, #2, lsl #12             ; =8192
	add	x9, x9, #570
	str	q0, [sp, #11760]
	str	q0, [sp, #11776]
	str	xzr, [sp, #11752]
	str	xzr, [sp, #11744]
	str	q0, [sp, #11312]
	str	q0, [sp, #11296]
	str	q0, [sp, #11280]
	str	q0, [sp, #11264]
	str	xzr, [sp, #11256]
	str	xzr, [sp, #11248]
	str	q0, [sp, #11184]
	str	q0, [sp, #11168]
	str	q0, [sp, #11152]
	str	q0, [sp, #11136]
	str	q0, [sp, #11120]
	str	q0, [sp, #11072]
	str	q0, [sp, #11088]
	str	q0, [sp, #11104]
	str	q0, [sp, #11056]
	str	q0, [sp, #11040]
	str	q0, [sp, #11024]
	str	q0, [sp, #11008]
	str	q0, [sp, #10992]
	str	q0, [sp, #10976]
	str	xzr, [sp, #10968]
	str	q0, [sp, #10928]
	str	q0, [sp, #10912]
	str	xzr, [sp, #10904]
	str	q0, [sp, #10864]
	str	q0, [sp, #10848]
	str	q0, [sp, #10800]
	str	q0, [sp, #10784]
	str	q0, [sp, #10768]
	str	q0, [sp, #10752]
	str	q0, [sp, #10736]
	str	q0, [sp, #10688]
	str	q0, [sp, #10704]
	str	q0, [sp, #10720]
	str	q0, [sp, #10672]
	str	q0, [sp, #10624]
	str	q0, [sp, #10640]
	str	q0, [sp, #10656]
	str	q0, [sp, #10608]
	str	q0, [sp, #10560]
	str	q0, [sp, #10576]
	str	q0, [sp, #10592]
	str	q0, [sp, #10544]
	str	q0, [sp, #10496]
	str	q0, [sp, #10512]
	str	q0, [sp, #10528]
	str	q0, [sp, #10480]
	str	q0, [sp, #10432]
	str	q0, [sp, #10448]
	str	q0, [sp, #10464]
	str	q0, [sp, #10416]
	str	q0, [sp, #10368]
	str	q0, [sp, #10384]
	str	q0, [sp, #10400]
	str	q0, [sp, #10352]
	str	q0, [sp, #10304]
	str	q0, [sp, #10320]
	str	q0, [sp, #10336]
	str	q0, [sp, #10288]
	str	q0, [sp, #10240]
	str	q0, [sp, #10256]
	str	q0, [sp, #10272]
	str	q0, [sp, #10224]
	str	q0, [sp, #10208]
	str	q0, [sp, #10192]
	str	q0, [sp, #10176]
	str	q0, [sp, #10160]
	str	q0, [sp, #10144]
	str	q0, [sp, #10128]
	str	q0, [sp, #10112]
	str	q0, [sp, #10096]
	str	q0, [sp, #10080]
	str	q0, [sp, #10032]
	str	q0, [sp, #10016]
	str	q0, [sp, #10000]
	str	q0, [sp, #9984]
	str	q0, [sp, #9968]
	str	q0, [sp, #9920]
	str	q0, [sp, #9936]
	str	q0, [sp, #9952]
	str	q0, [sp, #9904]
	str	q0, [sp, #9888]
	str	q0, [sp, #9872]
	str	q0, [sp, #9856]
	str	q0, [sp, #9840]
	str	q0, [sp, #9824]
	str	q0, [sp, #9808]
	str	q0, [sp, #9792]
	str	q0, [sp, #9776]
	str	q0, [sp, #9760]
	str	q0, [sp, #9712]
	str	q0, [sp, #9696]
	str	q0, [sp, #9680]
	str	q0, [sp, #9664]
	str	q0, [sp, #9648]
	str	q0, [sp, #9600]
	str	q0, [sp, #9616]
	str	q0, [sp, #9632]
	strb	wzr, [x9, #837]
	str	q0, [sp, #9520]
	str	q0, [sp, #9504]
	str	q0, [sp, #9488]
	str	q0, [sp, #9472]
	str	q0, [sp, #9456]
	str	q0, [sp, #9408]
	str	q0, [sp, #9424]
	str	q0, [sp, #9440]
	str	q0, [sp, #9392]
	str	q0, [sp, #9344]
	str	q0, [sp, #9360]
	str	q0, [sp, #9376]
	str	q0, [sp, #9328]
	str	q0, [sp, #9280]
	str	q0, [sp, #9296]
	str	q0, [sp, #9312]
	str	q0, [sp, #9264]
	str	q0, [sp, #9216]
	str	q0, [sp, #9232]
	str	q0, [sp, #9248]
	str	q0, [sp, #9200]
	str	q0, [sp, #9184]
	str	q0, [sp, #9168]
	str	q0, [sp, #9152]
	str	q0, [sp, #9136]
	str	q0, [sp, #9120]
	str	q0, [sp, #9104]
	str	q0, [sp, #9088]
	str	q0, [sp, #9072]
	str	q0, [sp, #9056]
	str	q0, [sp, #9040]
	str	q0, [sp, #9024]
	str	q0, [sp, #9008]
	str	q0, [sp, #8992]
	str	q0, [sp, #8976]
	str	q0, [sp, #8960]
	str	q0, [sp, #8944]
	str	q0, [sp, #8896]
	str	q0, [sp, #8912]
	str	q0, [sp, #8928]
	str	q0, [sp, #8880]
	str	q0, [sp, #8832]
	str	q0, [sp, #8848]
	str	q0, [sp, #8864]
	str	q0, [sp, #8816]
	str	q0, [sp, #8768]
	str	q0, [sp, #8784]
	str	q0, [sp, #8800]
	strb	wzr, [x9, #5]
	strb	wzr, [x9, #4]
	strb	wzr, [x9, #3]
	strb	wzr, [x9, #2]
	strb	wzr, [x9, #1]
	strb	wzr, [x9]
	str	q0, [sp, #8720]
	str	q0, [sp, #8704]
	str	q0, [sp, #8688]
	str	q0, [sp, #8672]
	str	q0, [sp, #8656]
	str	q0, [sp, #8640]
	str	q0, [sp, #8624]
	str	q0, [sp, #8608]
	str	q0, [sp, #8592]
	str	q0, [sp, #8576]
	str	q0, [sp, #8560]
	str	q0, [sp, #8544]
	str	q0, [sp, #8496]
	str	q0, [sp, #8480]
	str	q0, [sp, #8464]
	str	q0, [sp, #8448]
	str	q0, [sp, #8432]
	str	q0, [sp, #8416]
	str	q0, [sp, #8400]
	str	q0, [sp, #8384]
	str	q0, [sp, #8368]
	str	q0, [sp, #8352]
	str	q0, [sp, #8336]
	str	q0, [sp, #8320]
	str	q0, [sp, #8304]
	str	q0, [sp, #8288]
	str	q0, [sp, #8272]
	str	q0, [sp, #8256]
	str	q0, [sp, #8240]
	str	q0, [sp, #8224]
	str	q0, [sp, #8208]
	str	q0, [sp, #8192]
	str	q0, [sp, #8176]
	str	q0, [sp, #8160]
	str	q0, [sp, #8144]
	str	q0, [sp, #8128]
	str	q0, [sp, #8112]
	str	q0, [sp, #8096]
	str	q0, [sp, #8080]
	str	q0, [sp, #8064]
	str	q0, [sp, #8048]
	str	q0, [sp, #8032]
	str	q0, [sp, #8016]
	str	q0, [sp, #8000]
	str	q0, [sp, #7984]
	str	q0, [sp, #7968]
	str	q0, [sp, #7952]
	str	q0, [sp, #7936]
	str	q0, [sp, #7920]
	str	q0, [sp, #7904]
	str	q0, [sp, #7888]
	str	q0, [sp, #7872]
	str	q0, [sp, #7856]
	str	q0, [sp, #7840]
	str	q0, [sp, #7824]
	str	q0, [sp, #7808]
	str	q0, [sp, #7792]
	str	q0, [sp, #7776]
	str	q0, [sp, #7728]
	str	q0, [sp, #7712]
	str	q0, [sp, #7696]
	str	q0, [sp, #7680]
	str	q0, [sp, #7664]
	str	q0, [sp, #7616]
	str	q0, [sp, #7632]
	str	q0, [sp, #7648]
	str	q0, [sp, #7600]
	str	q0, [sp, #7552]
	str	q0, [sp, #7568]
	str	q0, [sp, #7584]
	str	q0, [sp, #7520]
	str	q0, [sp, #7536]
	str	q0, [sp, #7488]
	str	q0, [sp, #7504]
	ldr	x10, [x0]
	ldr	x11, [x0, #16]
	ldr	x12, [x0, #32]
	dup.4s	v1, w2
Lloh0:
	adrp	x13, lCPI0_2@PAGE
Lloh1:
	ldr	q0, [x13, lCPI0_2@PAGEOFF]
	cmhi.4s	v3, v1, v0
	ldr	x13, [x0, #48]
	ldr	w14, [x1]
	ldr	w15, [x1, #36]
Lloh2:
	adrp	x16, lCPI0_0@PAGE
Lloh3:
	ldr	q4, [x16, lCPI0_0@PAGEOFF]
Lloh4:
	adrp	x16, lCPI0_1@PAGE
Lloh5:
	ldr	q2, [x16, lCPI0_1@PAGEOFF]
	cmhi.4s	v1, v1, v2
	uzp1.8h	v1, v1, v3
	and.16b	v3, v1, v4
	addv.8h	h3, v3
	fmov	w16, s3
	xtn.8b	v4, v1
	umaxv.8h	h1, v1
	fmov	w17, s1
	ldrb	w0, [x8, #88]
	and	w1, w0, #0x1
	fmov	s1, w1
	ubfx	w1, w0, #1, #1
	mov.b	v1[1], w1
	ubfx	w1, w0, #2, #1
	mov.b	v1[2], w1
	ubfx	w1, w0, #3, #1
	mov.b	v1[3], w1
	ubfx	w1, w0, #4, #1
	mov.b	v1[4], w1
	ubfx	w1, w0, #5, #1
	mov.b	v1[5], w1
	ubfx	w1, w0, #6, #1
	mov.b	v1[6], w1
	lsr	w0, w0, #7
	mov.b	v1[7], w0
	tst	w17, #0x1
	csetm	w0, ne
	dup.8b	v3, w0
	str	d4, [sp, #1960]                 ; 8-byte Spill
	bit.8b	v1, v4, v3
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
Lloh6:
	adrp	x0, lCPI0_3@PAGE
Lloh7:
	ldr	d3, [x0, lCPI0_3@PAGEOFF]
	str	d3, [sp, #1992]                 ; 8-byte Spill
	and.8b	v1, v1, v3
	addv.8b	b1, v1
	str	b1, [x8, #88]
	ldr	w0, [sp, #11792]
	tst	w16, #0xff
	csel	w16, w0, wzr, eq
	str	w16, [sp, #11792]
	ldr	w16, [sp, #11760]
	csel	w16, w16, wzr, eq
	str	w16, [sp, #11760]
	tbnz	w17, #0, LBB0_1
	b	LBB0_1346
LBB0_1:                                 ; %scheduler.dispatch.lr.ph.lr.ph
	mov	x2, #0                          ; =0x0
	mov	x3, #0                          ; =0x0
	mov	w0, #0                          ; =0x0
	add	x16, sp, #2, lsl #12            ; =8192
	add	x16, x16, #3360
	dup.2d	v3, x16
	add	x16, sp, #2, lsl #12            ; =8192
	add	x16, x16, #3168
	dup.2d	v1, x16
	stp	q1, q3, [sp, #64]               ; 32-byte Folded Spill
	add	w14, w15, w14, lsl #5
	dup.4s	v1, w14
	add.4s	v3, v1, v0
	add.4s	v0, v1, v2
	stp	q0, q3, [sp, #32]               ; 32-byte Folded Spill
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #1776]                 ; 16-byte Spill
	str	q0, [sp, #1440]                 ; 16-byte Spill
	str	q0, [sp, #1424]                 ; 16-byte Spill
	str	q0, [sp, #1904]                 ; 16-byte Spill
	movi.2d	v23, #0000000000000000
	mov	w1, #1                          ; =0x1
	str	q0, [sp, #1920]                 ; 16-byte Spill
	add	x14, sp, #2, lsl #12            ; =8192
	add	x14, x14, #3640
	movi.2d	v12, #0000000000000000
	add	x15, sp, #2, lsl #12            ; =8192
	add	x15, x15, #3600
	str	q0, [sp, #1408]                 ; 16-byte Spill
	add	x16, sp, #2, lsl #12            ; =8192
	add	x16, x16, #3568
	str	q0, [sp, #1392]                 ; 16-byte Spill
	str	q0, [sp, #1888]                 ; 16-byte Spill
Lloh8:
	adrp	x17, LJTI0_0@PAGE
Lloh9:
	add	x17, x17, LJTI0_0@PAGEOFF
	movi.2d	v25, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v22, #0000000000000000
	str	q0, [sp, #1376]                 ; 16-byte Spill
	str	q0, [sp, #1360]                 ; 16-byte Spill
	str	q0, [sp, #1872]                 ; 16-byte Spill
	movi.2d	v10, #0000000000000000
	str	q0, [sp, #1856]                 ; 16-byte Spill
	movi.2d	v26, #0000000000000000
	str	q0, [sp, #1344]                 ; 16-byte Spill
	str	q0, [sp, #1328]                 ; 16-byte Spill
	str	q0, [sp, #1840]                 ; 16-byte Spill
	str	q0, [sp, #1824]                 ; 16-byte Spill
	movi.2d	v11, #0000000000000000
	str	q0, [sp, #1808]                 ; 16-byte Spill
	stp	q0, q0, [sp, #976]              ; 32-byte Folded Spill
	stp	q0, q0, [sp, #944]              ; 32-byte Folded Spill
	stp	q0, q0, [sp, #912]              ; 32-byte Folded Spill
	stp	q0, q0, [sp, #880]              ; 32-byte Folded Spill
	stp	q0, q0, [sp, #848]              ; 32-byte Folded Spill
	stp	q0, q0, [sp, #816]              ; 32-byte Folded Spill
	stp	q0, q0, [sp, #784]              ; 32-byte Folded Spill
	stp	q0, q0, [sp, #1008]             ; 32-byte Folded Spill
	str	q0, [sp, #1632]                 ; 16-byte Spill
	str	q0, [sp, #1616]                 ; 16-byte Spill
	str	q0, [sp, #1600]                 ; 16-byte Spill
	str	q0, [sp, #1584]                 ; 16-byte Spill
	str	q0, [sp, #1936]                 ; 16-byte Spill
	str	q0, [sp, #1216]                 ; 16-byte Spill
	str	q0, [sp, #1200]                 ; 16-byte Spill
	str	q0, [sp, #1184]                 ; 16-byte Spill
	str	q0, [sp, #1168]                 ; 16-byte Spill
	str	q0, [sp, #1152]                 ; 16-byte Spill
	str	q0, [sp, #1136]                 ; 16-byte Spill
	str	q0, [sp, #1120]                 ; 16-byte Spill
	str	q0, [sp, #1104]                 ; 16-byte Spill
	str	q0, [sp, #1088]                 ; 16-byte Spill
	str	q0, [sp, #1072]                 ; 16-byte Spill
	str	q0, [sp, #1056]                 ; 16-byte Spill
	str	q0, [sp, #1040]                 ; 16-byte Spill
	str	q0, [sp, #1312]                 ; 16-byte Spill
	str	q0, [sp, #1296]                 ; 16-byte Spill
	str	q0, [sp, #1568]                 ; 16-byte Spill
	str	q0, [sp, #1552]                 ; 16-byte Spill
	str	q0, [sp, #1280]                 ; 16-byte Spill
	str	q0, [sp, #1264]                 ; 16-byte Spill
	str	q0, [sp, #1248]                 ; 16-byte Spill
	str	q0, [sp, #1232]                 ; 16-byte Spill
	str	q0, [sp, #1792]                 ; 16-byte Spill
	movi.2d	v8, #0000000000000000
	str	q0, [sp, #1760]                 ; 16-byte Spill
	stp	q0, q0, [sp, #688]              ; 32-byte Folded Spill
	stp	q0, q0, [sp, #656]              ; 32-byte Folded Spill
	stp	q0, q0, [sp, #624]              ; 32-byte Folded Spill
	stp	q0, q0, [sp, #592]              ; 32-byte Folded Spill
	stp	q0, q0, [sp, #96]               ; 32-byte Folded Spill
	stp	q0, q0, [sp, #752]              ; 32-byte Folded Spill
	stp	q0, q0, [sp, #720]              ; 32-byte Folded Spill
	movi.2d	v31, #0000000000000000
	movi.2d	v9, #0000000000000000
	str	q0, [sp, #1968]                 ; 16-byte Spill
	movi.2d	v24, #0000000000000000
	movi.2d	v27, #0000000000000000
	b	LBB0_5
LBB0_2:                                 ; %schedule.47.convergence.cascade.exit1001_crit_edge
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w6, s0
LBB0_3:                                 ; %convergence.cascade.exit1001
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w6, #0xff
	b.ne	LBB0_1332
LBB0_4:                                 ; %scheduler.loop.backedge
                                        ;   in Loop: Header=BB0_5 Depth=1
	cbz	x1, LBB0_1346
LBB0_5:                                 ; %scheduler.dispatch
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_6 Depth 2
                                        ;       Child Loop BB0_185 Depth 3
                                        ;       Child Loop BB0_310 Depth 3
                                        ;       Child Loop BB0_421 Depth 3
                                        ;       Child Loop BB0_446 Depth 3
                                        ;       Child Loop BB0_471 Depth 3
                                        ;       Child Loop BB0_727 Depth 3
                                        ;       Child Loop BB0_1093 Depth 3
                                        ;       Child Loop BB0_1116 Depth 3
                                        ;       Child Loop BB0_120 Depth 3
                                        ;       Child Loop BB0_721 Depth 3
                                        ;       Child Loop BB0_753 Depth 3
                                        ;       Child Loop BB0_778 Depth 3
                                        ;       Child Loop BB0_803 Depth 3
                                        ;       Child Loop BB0_882 Depth 3
                                        ;       Child Loop BB0_949 Depth 3
                                        ;       Child Loop BB0_975 Depth 3
                                        ;       Child Loop BB0_1181 Depth 3
                                        ;       Child Loop BB0_1215 Depth 3
                                        ;       Child Loop BB0_1249 Depth 3
                                        ;       Child Loop BB0_1285 Depth 3
                                        ;     Child Loop BB0_1328 Depth 2
	sub	w1, w1, #1
	ldrb	w4, [x14, w1, sxtw]
	and	w5, w4, #0x1
	fmov	s15, w5
	ubfx	w5, w4, #1, #1
	mov.b	v15[1], w5
	ubfx	w5, w4, #2, #1
	mov.b	v15[2], w5
	ubfx	w5, w4, #3, #1
	mov.b	v15[3], w5
	ubfx	w5, w4, #4, #1
	mov.b	v15[4], w5
	ubfx	w5, w4, #5, #1
	mov.b	v15[5], w5
	ubfx	w5, w4, #6, #1
	mov.b	v15[6], w5
	lsr	w4, w4, #7
	mov.b	v15[7], w4
	ldr	w6, [x15, w1, sxtw #2]
	ldr	w4, [x16, w1, sxtw #2]
	cmp	w6, #47
	b.hi	LBB0_1348
LBB0_6:                                 ; %scheduler.dispatch.route
                                        ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_185 Depth 3
                                        ;       Child Loop BB0_310 Depth 3
                                        ;       Child Loop BB0_421 Depth 3
                                        ;       Child Loop BB0_446 Depth 3
                                        ;       Child Loop BB0_471 Depth 3
                                        ;       Child Loop BB0_727 Depth 3
                                        ;       Child Loop BB0_1093 Depth 3
                                        ;       Child Loop BB0_1116 Depth 3
                                        ;       Child Loop BB0_120 Depth 3
                                        ;       Child Loop BB0_721 Depth 3
                                        ;       Child Loop BB0_753 Depth 3
                                        ;       Child Loop BB0_778 Depth 3
                                        ;       Child Loop BB0_803 Depth 3
                                        ;       Child Loop BB0_882 Depth 3
                                        ;       Child Loop BB0_949 Depth 3
                                        ;       Child Loop BB0_975 Depth 3
                                        ;       Child Loop BB0_1181 Depth 3
                                        ;       Child Loop BB0_1215 Depth 3
                                        ;       Child Loop BB0_1249 Depth 3
                                        ;       Child Loop BB0_1285 Depth 3
	mov	w6, w6
	adr	x5, LBB0_7
	ldrh	w7, [x17, x6, lsl #1]
	add	x5, x5, x7, lsl #2
	br	x5
LBB0_7:                                 ; %schedule.0
                                        ;   in Loop: Header=BB0_6 Depth=2
	str	q27, [sp, #1680]                ; 16-byte Spill
	mov.16b	v14, v11
	str	q23, [sp, #1744]                ; 16-byte Spill
	ldr	q13, [sp, #1792]                ; 16-byte Reload
	mov.16b	v11, v8
	mov.16b	v8, v12
	str	q24, [sp, #1664]                ; 16-byte Spill
	str	q25, [sp, #1728]                ; 16-byte Spill
	mov.16b	v7, v10
	mov.16b	v10, v31
	str	q26, [sp, #1696]                ; 16-byte Spill
	str	q22, [sp, #1712]                ; 16-byte Spill
	str	q29, [sp, #1648]                ; 16-byte Spill
	shl.8b	v0, v15, #7
	cmlt.8b	v20, v0, #0
	ldr	d0, [sp, #1992]                 ; 8-byte Reload
	and.8b	v6, v20, v0
	zip1.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v1, v0, #0
	ldp	q0, q3, [sp, #32]               ; 32-byte Folded Reload
	and.16b	v2, v1, v0
	zip2.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	and.16b	v4, v0, v3
	movi.4s	v3, #3
	and.16b	v16, v1, v3
	and.16b	v3, v0, v3
	mvn.16b	v0, v0
	sub.4s	v5, v3, v0
	mov.s	w2, v5[1]
	mov.s	w3, v4[1]
	udiv	w2, w3, w2
	fmov	w3, s5
	fmov	w5, s4
	udiv	w3, w5, w3
	fmov	s0, w3
	fmov	s19, w3
	mov.s	v19[1], w2
	mov.s	w3, v5[2]
	mvn.16b	v1, v1
	mov.s	w5, v4[2]
	udiv	w3, w5, w3
	mov.s	v19[2], w3
	sub.4s	v1, v16, v1
	mov.s	w5, v5[3]
	mov.s	w6, v4[3]
	udiv	w6, w6, w5
	mov.s	v19[3], w6
	mov.s	w5, v1[1]
	mov.s	w7, v2[1]
	fmov	w19, s1
	fmov	w20, s2
	udiv	w19, w20, w19
	fmov	s3, w19
	fmov	s16, w19
	udiv	w7, w7, w5
	mov.s	v16[1], w7
	mov.s	w5, v1[2]
	mov.s	w19, v2[2]
	addv.8b	b17, v6
	udiv	w19, w19, w5
	mov.s	v16[2], w19
	mov.s	w20, v1[3]
	fmov	w5, s17
	mov.s	w21, v2[3]
	udiv	w20, w21, w20
	mov.s	v16[3], w20
	mov.s	v0[1], w2
	ushll.2d	v22, v0, #0
	fmov	s6, w3
	mov.s	v6[1], w6
	ushll.2d	v23, v6, #0
	mov.s	v3[1], w7
	fmov	s18, w19
	mov.s	v18[1], w20
	ushll.2d	v25, v3, #0
	ushll.2d	v26, v18, #0
	mls.4s	v4, v19, v5
	mls.4s	v2, v16, v1
	add.4s	v2, v2, v2
	add.4s	v5, v4, v4
	ushll2.2d	v21, v5, #0
	ushll.2d	v19, v2, #0
	ushll2.2d	v12, v2, #0
	ushll.2d	v16, v5, #0
	ldr	q1, [sp, #11296]
	ldr	q4, [sp, #11312]
	ldr	q27, [sp, #11264]
	ldr	q28, [sp, #11280]
	mov	b24, v15[2]
	mov.b	v24[4], v15[3]
	ushll.2d	v24, v24, #0
	shl.2d	v24, v24, #63
	cmlt.2d	v24, v24, #0
	bif.16b	v26, v28, v24
	mov	b28, v15[0]
	mov.b	v28[4], v15[1]
	ushll.2d	v28, v28, #0
	shl.2d	v28, v28, #63
	cmlt.2d	v29, v28, #0
	mov	b28, v15[6]
	mov.b	v28[4], v15[7]
	bif.16b	v25, v27, v29
	ushll.2d	v27, v28, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v30, v27, #0
	bit.16b	v4, v23, v30
	mov	b23, v15[4]
	mov.b	v23[4], v15[5]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v31, v23, #0
	bit.16b	v1, v22, v31
	str	q1, [sp, #11296]
	str	q4, [sp, #11312]
	str	q25, [sp, #11264]
	str	q26, [sp, #11280]
	str	xzr, [sp, #11256]
	str	xzr, [sp, #11248]
	ldr	q1, [sp, #11184]
	ldr	q4, [sp, #11136]
	ldr	q22, [sp, #11152]
	ldr	q23, [sp, #11168]
	bit.16b	v23, v16, v31
	mov.16b	v25, v12
	bit.16b	v22, v12, v24
	bit.16b	v4, v19, v29
	bit.16b	v1, v21, v30
	str	q1, [sp, #11184]
	str	q4, [sp, #11136]
	str	q22, [sp, #11152]
	str	q23, [sp, #11168]
	movi.2s	v1, #5
	umull.2d	v22, v18, v1
	umull.2d	v23, v3, v1
	umull.2d	v28, v6, v1
	umull.2d	v27, v0, v1
	uaddw.2d	v4, v27, v5
	uaddw2.2d	v3, v28, v5
	uaddw.2d	v0, v23, v2
	uaddw2.2d	v5, v22, v2
	ldr	q1, [sp, #11104]
	ldr	q2, [sp, #11120]
	ldr	q6, [sp, #11072]
	ldr	q18, [sp, #11088]
	bit.16b	v18, v5, v24
	bit.16b	v6, v0, v29
	bit.16b	v2, v3, v30
	bit.16b	v1, v4, v31
	str	q1, [sp, #11104]
	str	q2, [sp, #11120]
	str	q6, [sp, #11072]
	mov.d	x2, v0[1]
	fmov	x3, d0
	add	x3, x3, x3, lsl #2
	lsl	x3, x3, #2
	fmov	d24, x3
	add	x2, x2, x2, lsl #2
	lsl	x2, x2, #2
	mov.d	v24[1], x2
	str	q18, [sp, #11088]
	dup.2d	v18, x10
	add.2d	v1, v18, v24
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbz	w5, #0, LBB0_9
; %bb.8:                                ; %cond.load
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x2, d1
	ldr	s0, [x2]
LBB0_9:                                 ; %else
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #1, LBB0_11
; %bb.10:                               ; %cond.load6781
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x2, v1[1]
	ld1.s	{ v0 }[1], [x2]
LBB0_11:                                ; %else6782
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.16b	v31, v10
	mov.16b	v12, v8
	mov.16b	v6, v25
	fmov	x2, d5
	add	x2, x2, x2, lsl #2
	lsl	x2, x2, #2
	mov.d	x3, v5[1]
	fmov	d25, x2
	add	x2, x3, x3, lsl #2
	lsl	x2, x2, #2
	mov.d	v25[1], x2
	add.2d	v1, v18, v25
	mov.16b	v8, v11
	tbz	w5, #2, LBB0_13
; %bb.12:                               ; %cond.load6784
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x2, d1
	ld1.s	{ v0 }[2], [x2]
LBB0_13:                                ; %else6785
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.16b	v10, v7
	mov.16b	v11, v14
	str	q13, [sp, #1792]                ; 16-byte Spill
	tbz	w5, #3, LBB0_15
; %bb.14:                               ; %cond.load6787
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x2, v1[1]
	ld1.s	{ v0 }[3], [x2]
LBB0_15:                                ; %else6788
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x2, d4
	add	x2, x2, x2, lsl #2
	lsl	x2, x2, #2
	mov.d	x3, v4[1]
	fmov	d26, x2
	add	x2, x3, x3, lsl #2
	lsl	x2, x2, #2
	mov.d	v26[1], x2
	add.2d	v1, v18, v26
	tbz	w5, #4, LBB0_17
; %bb.16:                               ; %cond.load6790
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x2, d1
	ld1.s	{ v2 }[0], [x2]
LBB0_17:                                ; %else6791
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #5, LBB0_19
; %bb.18:                               ; %cond.load6793
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x2, v1[1]
	ld1.s	{ v2 }[1], [x2]
LBB0_19:                                ; %else6794
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x2, d3
	add	x2, x2, x2, lsl #2
	lsl	x2, x2, #2
	mov.d	x3, v3[1]
	fmov	d29, x2
	add	x2, x3, x3, lsl #2
	lsl	x2, x2, #2
	mov.d	v29[1], x2
	add.2d	v1, v18, v29
	tbz	w5, #6, LBB0_21
; %bb.20:                               ; %cond.load6796
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x2, d1
	ld1.s	{ v2 }[2], [x2]
LBB0_21:                                ; %else6797
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_23
; %bb.22:                               ; %cond.load6799
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x2, v1[1]
	ld1.s	{ v2 }[3], [x2]
LBB0_23:                                ; %else6800
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #11056]
	ldr	q3, [sp, #11040]
	fmov	w2, s17
	zip1.8b	v4, v15, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bif.16b	v0, v3, v4
	zip2.8b	v3, v15, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v2, v3
	str	q1, [sp, #11056]
	str	q0, [sp, #11040]
	mov	w3, #4                          ; =0x4
	dup.2d	v0, x3
	add.2d	v3, v18, v0
	add.2d	v1, v24, v3
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w2, #0, LBB0_313
; %bb.24:                               ; %else6807
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w2, #1, LBB0_314
LBB0_25:                                ; %else6813
                                        ;   in Loop: Header=BB0_6 Depth=2
	add.2d	v1, v25, v3
	tbnz	w2, #2, LBB0_315
LBB0_26:                                ; %else6819
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w2, #3, LBB0_316
LBB0_27:                                ; %else6825
                                        ;   in Loop: Header=BB0_6 Depth=2
	add.2d	v1, v26, v3
	tbnz	w2, #4, LBB0_317
LBB0_28:                                ; %else6831
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w2, #5, LBB0_318
LBB0_29:                                ; %else6837
                                        ;   in Loop: Header=BB0_6 Depth=2
	add.2d	v1, v29, v3
	tbnz	w2, #6, LBB0_319
LBB0_30:                                ; %else6843
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w2, #7, LBB0_32
LBB0_31:                                ; %cond.load6845
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x2, v1[1]
	ld1.s	{ v2 }[3], [x2]
LBB0_32:                                ; %else6849
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #11024]
	ldr	q3, [sp, #11008]
	fmov	w2, s17
	zip1.8b	v4, v15, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bif.16b	v0, v3, v4
	zip2.8b	v3, v15, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v2, v3
	str	q1, [sp, #11024]
	str	q0, [sp, #11008]
	mov	w3, #8                          ; =0x8
	dup.2d	v0, x3
	add.2d	v3, v18, v0
	add.2d	v1, v24, v3
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w2, #0, LBB0_320
; %bb.33:                               ; %else6856
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w2, #1, LBB0_321
LBB0_34:                                ; %else6862
                                        ;   in Loop: Header=BB0_6 Depth=2
	add.2d	v1, v25, v3
	tbnz	w2, #2, LBB0_322
LBB0_35:                                ; %else6868
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w2, #3, LBB0_323
LBB0_36:                                ; %else6874
                                        ;   in Loop: Header=BB0_6 Depth=2
	add.2d	v1, v26, v3
	tbnz	w2, #4, LBB0_324
LBB0_37:                                ; %else6880
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w2, #5, LBB0_325
LBB0_38:                                ; %else6886
                                        ;   in Loop: Header=BB0_6 Depth=2
	add.2d	v1, v29, v3
	tbnz	w2, #6, LBB0_326
LBB0_39:                                ; %else6892
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w2, #7, LBB0_41
LBB0_40:                                ; %cond.load6894
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x2, v1[1]
	ld1.s	{ v2 }[3], [x2]
LBB0_41:                                ; %else6898
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #10992]
	ldr	q3, [sp, #10976]
	fmov	w2, s17
	zip1.8b	v4, v15, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bif.16b	v0, v3, v4
	zip2.8b	v3, v15, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v2, v3
	str	q1, [sp, #10992]
	str	q0, [sp, #10976]
	mov	w3, #3                          ; =0x3
	str	x3, [sp, #10968]
	mov	w3, #12                         ; =0xc
	dup.2d	v0, x3
	add.2d	v3, v18, v0
	add.2d	v1, v24, v3
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w2, #0, LBB0_327
; %bb.42:                               ; %else6905
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w2, #1, LBB0_328
LBB0_43:                                ; %else6911
                                        ;   in Loop: Header=BB0_6 Depth=2
	add.2d	v1, v25, v3
	tbnz	w2, #2, LBB0_329
LBB0_44:                                ; %else6917
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w2, #3, LBB0_330
LBB0_45:                                ; %else6923
                                        ;   in Loop: Header=BB0_6 Depth=2
	add.2d	v1, v26, v3
	tbnz	w2, #4, LBB0_331
LBB0_46:                                ; %else6929
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w2, #5, LBB0_332
LBB0_47:                                ; %else6935
                                        ;   in Loop: Header=BB0_6 Depth=2
	add.2d	v1, v29, v3
	tbnz	w2, #6, LBB0_333
LBB0_48:                                ; %else6941
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w2, #7, LBB0_50
LBB0_49:                                ; %cond.load6943
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x2, v1[1]
	ld1.s	{ v2 }[3], [x2]
LBB0_50:                                ; %else6947
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #10928]
	ldr	q3, [sp, #10912]
	fmov	w2, s17
	zip1.8b	v4, v15, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bif.16b	v0, v3, v4
	zip2.8b	v3, v15, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v2, v3
	str	q1, [sp, #10928]
	str	q0, [sp, #10912]
	mov	w3, #4                          ; =0x4
	str	x3, [sp, #10904]
	mov	w3, #16                         ; =0x10
	dup.2d	v0, x3
	add.2d	v3, v18, v0
	add.2d	v1, v24, v3
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w2, #0, LBB0_334
; %bb.51:                               ; %else6954
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w2, #1, LBB0_335
LBB0_52:                                ; %else6960
                                        ;   in Loop: Header=BB0_6 Depth=2
	add.2d	v1, v25, v3
	tbnz	w2, #2, LBB0_336
LBB0_53:                                ; %else6966
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w2, #3, LBB0_337
LBB0_54:                                ; %else6972
                                        ;   in Loop: Header=BB0_6 Depth=2
	add.2d	v1, v26, v3
	tbnz	w2, #4, LBB0_338
LBB0_55:                                ; %else6978
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w2, #5, LBB0_339
LBB0_56:                                ; %else6984
                                        ;   in Loop: Header=BB0_6 Depth=2
	add.2d	v1, v29, v3
	tbnz	w2, #6, LBB0_340
LBB0_57:                                ; %else6990
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.16b	v7, v20
	tbz	w2, #7, LBB0_59
LBB0_58:                                ; %cond.load6992
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x2, v1[1]
	ld1.s	{ v2 }[3], [x2]
LBB0_59:                                ; %else6996
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #10864]
	ldr	q3, [sp, #10848]
	zip1.8b	v4, v15, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bif.16b	v0, v3, v4
	zip2.8b	v3, v15, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v2, v3
	str	q1, [sp, #10864]
	str	q0, [sp, #10848]
	mov	w2, #1                          ; =0x1
	dup.2d	v1, x2
	orr.16b	v0, v21, v1
	orr.16b	v2, v19, v1
	orr.16b	v4, v6, v1
	orr.16b	v3, v16, v1
	ldr	q1, [sp, #10800]
	ldr	q19, [sp, #10752]
	ldr	q16, [sp, #10768]
	ldr	q6, [sp, #10784]
	mov	b5, v15[4]
	mov.b	v5[4], v15[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	mov.16b	v20, v5
	bsl.16b	v20, v3, v6
	mov	b6, v15[2]
	mov.b	v6[4], v15[3]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	mov.16b	v21, v6
	bsl.16b	v21, v4, v16
	mov	b16, v15[0]
	mov.b	v16[4], v15[1]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	mov	b24, v15[6]
	mov.b	v24[4], v15[7]
	mov.16b	v25, v16
	bsl.16b	v25, v2, v19
	ushll.2d	v19, v24, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	bit.16b	v1, v0, v19
	str	q1, [sp, #10800]
	str	q25, [sp, #10752]
	str	q21, [sp, #10768]
	str	q20, [sp, #10784]
	add.2d	v1, v0, v28
	add.2d	v21, v2, v23
	add.2d	v22, v4, v22
	add.2d	v23, v3, v27
	ldr	q20, [sp, #10736]
	ldr	q24, [sp, #10688]
	ldr	q25, [sp, #10704]
	ldr	q26, [sp, #10720]
	bit.16b	v26, v23, v5
	bit.16b	v25, v22, v6
	bit.16b	v24, v21, v16
	mov.16b	v27, v19
	bsl.16b	v27, v1, v20
	mov	w2, #5                          ; =0x5
	dup.2d	v20, x2
	mov.d	x2, v21[1]
	fmov	x3, d21
	add	x3, x3, x3, lsl #2
	fmov	d21, x3
	add	x2, x2, x2, lsl #2
	mov.d	v21[1], x2
	mov.d	x2, v22[1]
	fmov	x3, d22
	add	x3, x3, x3, lsl #2
	fmov	d22, x3
	add	x2, x2, x2, lsl #2
	mov.d	v22[1], x2
	mov.d	x2, v23[1]
	fmov	x3, d23
	add	x3, x3, x3, lsl #2
	fmov	d23, x3
	add	x2, x2, x2, lsl #2
	mov.d	v23[1], x2
	mov.d	x2, v1[1]
	fmov	x3, d1
	add	x3, x3, x3, lsl #2
	fmov	d1, x3
	str	q27, [sp, #10736]
	str	q24, [sp, #10688]
	str	q25, [sp, #10704]
	str	q26, [sp, #10720]
	cmhi.2d	v24, v20, v4
	cmhi.2d	v25, v20, v2
	uzp1.4s	v24, v25, v24
	cmhi.2d	v25, v20, v3
	cmhi.2d	v26, v20, v0
	uzp1.4s	v25, v25, v26
	uzp1.8h	v24, v24, v25
	xtn.8b	v24, v24
	bit.8b	v31, v24, v7
	add	x2, x2, x2, lsl #2
	mov.d	v1[1], x2
	ldr	q7, [sp, #720]                  ; 16-byte Reload
	bit.16b	v7, v1, v19
	str	q7, [sp, #720]                  ; 16-byte Spill
	ldr	q7, [sp, #736]                  ; 16-byte Reload
	bit.16b	v7, v23, v5
	str	q7, [sp, #736]                  ; 16-byte Spill
	ldr	q7, [sp, #752]                  ; 16-byte Reload
	bit.16b	v7, v22, v6
	str	q7, [sp, #752]                  ; 16-byte Spill
	ldr	q7, [sp, #768]                  ; 16-byte Reload
	bit.16b	v7, v21, v16
	str	q7, [sp, #768]                  ; 16-byte Spill
	ldr	q7, [sp, #10656]
	ldr	q25, [sp, #10672]
	ldr	q26, [sp, #10624]
	ldr	q27, [sp, #10640]
	bsl.16b	v6, v22, v27
	bsl.16b	v16, v21, v26
	bif.16b	v1, v25, v19
	bsl.16b	v5, v23, v7
	str	q5, [sp, #10656]
	str	q1, [sp, #10672]
	str	q16, [sp, #10624]
	str	q6, [sp, #10640]
	and.8b	v7, v15, v24
	shl.8b	v1, v7, #7
	cmlt.8b	v1, v1, #0
	umaxv.8b	b5, v1
	fmov	w2, s5
	tbz	w2, #0, LBB0_277
; %bb.60:                               ; %else6996
                                        ;   in Loop: Header=BB0_6 Depth=2
	cmhs.2d	v4, v4, v20
	cmhs.2d	v2, v2, v20
	uzp1.4s	v2, v2, v4
	cmhs.2d	v3, v3, v20
	cmhs.2d	v0, v0, v20
	uzp1.4s	v0, v3, v0
	uzp1.8h	v0, v2, v0
	xtn.8b	v0, v0
	and.8b	v16, v15, v0
	shl.8b	v0, v16, #7
	cmlt.8b	v0, v0, #0
	ldr	d2, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v2
	addv.8b	b0, v0
	fmov	w2, s0
	tst	w2, #0xff
	b.eq	LBB0_277
; %bb.61:                               ; %varying.divergent
                                        ;   in Loop: Header=BB0_6 Depth=2
	cmp	w4, #0
	cset	w2, ne
	sub	w2, w4, w2
	and	w3, w0, #0xff
	lsr	w5, w3, w2
	tst	w5, #0x1
	cset	w5, eq
	cmp	w4, #0
	ldr	q3, [sp, #1664]                 ; 16-byte Reload
	str	q3, [sp, #2128]
	ldr	q4, [sp, #1680]                 ; 16-byte Reload
	str	q4, [sp, #2144]
	and	x2, x2, #0x7
	add	x6, sp, #2128
	ldr	w2, [x6, x2, lsl #2]
	csinc	w5, w5, wzr, ne
	cmp	w2, #0
	csinc	w5, w5, wzr, eq
	cmp	w3, #255
	ldr	q29, [sp, #1648]                ; 16-byte Reload
	ldr	q22, [sp, #1712]                ; 16-byte Reload
	ldr	q26, [sp, #1696]                ; 16-byte Reload
	ldr	q23, [sp, #1744]                ; 16-byte Reload
	b.ne	LBB0_63
; %bb.62:                               ; %varying.divergent
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #0, LBB0_63
	b	LBB0_1348
LBB0_63:                                ; %convergence.overflow.resume
                                        ;   in Loop: Header=BB0_6 Depth=2
	mvn	w2, w0
	rbit	w2, w2
	clz	w2, w2
	mov	w3, #255                        ; =0xff
	bics	wzr, w3, w0
	csel	w7, wzr, w2, eq
	add	x2, sp, #2, lsl #12             ; =8192
	add	x2, x2, #3560
	ldrb	w6, [x2, w7, uxtw]
	and	w3, w6, #0x1
	fmov	s0, w3
	ubfx	w3, w6, #1, #1
	mov.b	v0[1], w3
	ubfx	w3, w6, #2, #1
	mov.b	v0[2], w3
	ubfx	w3, w6, #3, #1
	mov.b	v0[3], w3
	ubfx	w3, w6, #4, #1
	mov.b	v0[4], w3
	ubfx	w3, w6, #5, #1
	mov.b	v0[5], w3
	ubfx	w3, w6, #6, #1
	mov.b	v0[6], w3
	add	x3, sp, #2, lsl #12             ; =8192
	add	x3, x3, #3552
	lsr	w6, w6, #7
	mov.b	v0[7], w6
	ldrb	w6, [x3, w7, uxtw]
	and	w19, w6, #0x1
	fmov	s1, w19
	ubfx	w19, w6, #1, #1
	mov.b	v1[1], w19
	ubfx	w19, w6, #2, #1
	mov.b	v1[2], w19
	ubfx	w19, w6, #3, #1
	mov.b	v1[3], w19
	ubfx	w19, w6, #4, #1
	mov.b	v1[4], w19
	ubfx	w19, w6, #5, #1
	mov.b	v1[5], w19
	ubfx	w19, w6, #6, #1
	mov.b	v1[6], w19
	lsr	w6, w6, #7
	mov.b	v1[7], w6
	cmp	w5, #0
	csetm	w6, ne
	dup.8b	v2, w6
	bit.8b	v0, v15, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	ldr	d5, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v5
	addv.8b	b0, v0
	str	b0, [x2, w7, uxtw]
	bic.8b	v0, v1, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v5
	addv.8b	b0, v0
	str	b0, [x3, w7, uxtw]
	cmp	x1, #8
	ldr	q25, [sp, #1728]                ; 16-byte Reload
	b.hs	LBB0_1348
; %bb.64:                               ; %ready.overflow.resume135
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v0, v16, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	ldp	q5, q1, [sp, #96]               ; 32-byte Folded Reload
	and.16b	v2, v0, v5
	zip1.8b	v0, v16, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v1, v0, v1
	stp	q2, q1, [sp, #96]               ; 32-byte Folded Spill
	str	q9, [sp, #2096]
	ldr	q0, [sp, #1968]                 ; 16-byte Reload
	str	q0, [sp, #2112]
	ubfiz	x2, x7, #2, #3
	add	x3, sp, #2096
	ldr	w3, [x3, x2]
	cmp	w5, #0
	csel	w3, w4, w3, ne
	csinc	w4, w4, w7, eq
	str	q9, [sp, #2064]
	str	q0, [sp, #2080]
	add	x6, sp, #2064
	str	w3, [x6, x2]
	ldr	q0, [sp, #2080]
	str	q0, [sp, #1968]                 ; 16-byte Spill
	ldr	q9, [sp, #2064]
	str	q3, [sp, #2032]
	str	q4, [sp, #2048]
	add	x3, sp, #2032
	ldr	w3, [x3, x2]
	csel	w3, wzr, w3, ne
	str	q3, [sp, #2000]
	str	q4, [sp, #2016]
	add	x6, sp, #2000
	str	w3, [x6, x2]
	mov	w2, #2                          ; =0x2
	mov	w19, #1                         ; =0x1
	ldr	q27, [sp, #2016]
	ldr	q24, [sp, #2000]
	mov	w3, #1                          ; =0x1
	mov	w6, #2                          ; =0x2
	b	LBB0_1262
LBB0_65:                                ; %scheduler.dispatch.route.schedule.30_crit_edge
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	umaxv.8b	b0, v0
	fmov	w5, s0
	eor	w5, w5, #0x1
	b	LBB0_1161
LBB0_66:                                ; %schedule.19
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w5, s0
	ldr	q3, [sp, #9328]
	ldr	q5, [sp, #9312]
	ldr	q1, [sp, #9296]
	ldr	q0, [sp, #9280]
	shl.2d	v0, v0, #2
	dup.2d	v4, x11
	add.2d	v6, v4, v0
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w5, #0, LBB0_228
; %bb.67:                               ; %else7885
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_229
LBB0_68:                                ; %else7891
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbnz	w5, #2, LBB0_230
LBB0_69:                                ; %else7897
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_231
LBB0_70:                                ; %else7903
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbnz	w5, #4, LBB0_232
LBB0_71:                                ; %else7909
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_233
LBB0_72:                                ; %else7915
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbnz	w5, #6, LBB0_234
LBB0_73:                                ; %else7921
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_75
LBB0_74:                                ; %cond.load7923
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[3], [x6]
LBB0_75:                                ; %else7927
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q3, [sp, #848]                  ; 16-byte Reload
	bit.16b	v3, v2, v1
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #864]                  ; 16-byte Reload
	bit.16b	v2, v0, v1
	stp	q3, q2, [sp, #848]              ; 32-byte Folded Spill
	tst	w5, #0xff
	b.ne	LBB0_776
	b	LBB0_4
LBB0_76:                                ; %scheduler.dispatch.route.schedule.36_crit_edge
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	umaxv.8b	b0, v0
	fmov	w5, s0
	eor	w5, w5, #0x1
	b	LBB0_1229
LBB0_77:                                ; %schedule.23
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w5, s0
	ldr	q3, [sp, #8944]
	ldr	q5, [sp, #8928]
	ldr	q1, [sp, #8912]
	ldr	q0, [sp, #8896]
	shl.2d	v0, v0, #2
	dup.2d	v4, x12
	add.2d	v6, v4, v0
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w5, #0, LBB0_235
; %bb.78:                               ; %else7983
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_236
LBB0_79:                                ; %else7989
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbnz	w5, #2, LBB0_237
LBB0_80:                                ; %else7995
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_238
LBB0_81:                                ; %else8001
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbnz	w5, #4, LBB0_239
LBB0_82:                                ; %else8007
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_240
LBB0_83:                                ; %else8013
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbnz	w5, #6, LBB0_241
LBB0_84:                                ; %else8019
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_86
LBB0_85:                                ; %cond.load8021
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[3], [x6]
LBB0_86:                                ; %else8025
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q3, [sp, #912]                  ; 16-byte Reload
	bit.16b	v3, v2, v1
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #928]                  ; 16-byte Reload
	bit.16b	v2, v0, v1
	stp	q3, q2, [sp, #912]              ; 32-byte Folded Spill
	tst	w5, #0xff
	b.ne	LBB0_880
	b	LBB0_4
LBB0_87:                                ; %schedule.17
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w5, s0
	ldr	q3, [sp, #9392]
	ldr	q5, [sp, #9376]
	ldr	q1, [sp, #9360]
	ldr	q0, [sp, #9344]
	shl.2d	v0, v0, #2
	dup.2d	v4, x11
	add.2d	v6, v4, v0
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w5, #0, LBB0_242
; %bb.88:                               ; %else7836
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_243
LBB0_89:                                ; %else7842
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbnz	w5, #2, LBB0_244
LBB0_90:                                ; %else7848
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_245
LBB0_91:                                ; %else7854
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbnz	w5, #4, LBB0_246
LBB0_92:                                ; %else7860
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_247
LBB0_93:                                ; %else7866
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbnz	w5, #6, LBB0_248
LBB0_94:                                ; %else7872
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_96
LBB0_95:                                ; %cond.load7874
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[3], [x6]
LBB0_96:                                ; %else7878
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q3, [sp, #816]                  ; 16-byte Reload
	bit.16b	v3, v2, v1
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #832]                  ; 16-byte Reload
	bit.16b	v2, v0, v1
	stp	q3, q2, [sp, #816]              ; 32-byte Folded Spill
	tst	w5, #0xff
	b.ne	LBB0_751
	b	LBB0_4
LBB0_97:                                ; %scheduler.dispatch.route.schedule.39_crit_edge
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	umaxv.8b	b0, v0
	fmov	w5, s0
	eor	w5, w5, #0x1
	b	LBB0_1265
LBB0_98:                                ; %schedule.3
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w5, s0
	ldr	q3, [sp, #10608]
	ldr	q5, [sp, #10592]
	ldr	q1, [sp, #10576]
	ldr	q0, [sp, #10560]
	shl.2d	v0, v0, #2
	dup.2d	v4, x10
	add.2d	v6, v4, v0
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w5, #0, LBB0_249
; %bb.99:                               ; %else7052
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_250
LBB0_100:                               ; %else7058
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbnz	w5, #2, LBB0_251
LBB0_101:                               ; %else7064
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_252
LBB0_102:                               ; %else7070
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbnz	w5, #4, LBB0_253
LBB0_103:                               ; %else7076
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_254
LBB0_104:                               ; %else7082
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbnz	w5, #6, LBB0_255
LBB0_105:                               ; %else7088
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_107
LBB0_106:                               ; %cond.load7090
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[3], [x6]
LBB0_107:                               ; %else7094
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q3, [sp, #592]                  ; 16-byte Reload
	bit.16b	v3, v2, v1
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #608]                  ; 16-byte Reload
	bit.16b	v2, v0, v1
	stp	q3, q2, [sp, #592]              ; 32-byte Folded Spill
	tst	w5, #0xff
	b.ne	LBB0_308
	b	LBB0_4
LBB0_108:                               ; %schedule.13
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w5, s0
	ldr	q3, [sp, #9520]
	ldr	q5, [sp, #9504]
	ldr	q1, [sp, #9488]
	ldr	q0, [sp, #9472]
	shl.2d	v0, v0, #2
	dup.2d	v4, x11
	add.2d	v6, v4, v0
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w5, #0, LBB0_256
; %bb.109:                              ; %else7738
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_257
LBB0_110:                               ; %else7744
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbnz	w5, #2, LBB0_258
LBB0_111:                               ; %else7750
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_259
LBB0_112:                               ; %else7756
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbnz	w5, #4, LBB0_260
LBB0_113:                               ; %else7762
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_261
LBB0_114:                               ; %else7768
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbnz	w5, #6, LBB0_262
LBB0_115:                               ; %else7774
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_117
LBB0_116:                               ; %cond.load7776
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[3], [x6]
LBB0_117:                               ; %else7780
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q3, [sp, #1008]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #1024]                 ; 16-byte Reload
	bit.16b	v2, v0, v1
	stp	q3, q2, [sp, #1008]             ; 32-byte Folded Spill
	tst	w5, #0xff
	b.eq	LBB0_4
LBB0_118:                               ; %schedule.14
                                        ;   in Loop: Header=BB0_6 Depth=2
	cbz	w4, LBB0_630
LBB0_119:                               ; %convergence.cascade321.preheader
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w5, #0                          ; =0x0
LBB0_120:                               ; %convergence.cascade321
                                        ;   Parent Loop BB0_5 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d6, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v0, v6
	addv.8b	b1, v1
	fmov	w6, s1
	umaxv.8b	b0, v0
	fmov	w20, s0
	sub	w7, w4, #1
	tst	w6, #0xff
	csel	w7, w7, wzr, ne
	mov	w6, #1                          ; =0x1
	lsl	w19, w6, w7
	and	w6, w19, w0
	tst	w6, #0xff
	cset	w22, ne
	str	q24, [sp, #6384]
	str	q27, [sp, #6400]
	ubfiz	x6, x7, #2, #3
	add	x21, sp, #1, lsl #12            ; =4096
	add	x21, x21, #2288
	ldr	w21, [x21, x6]
	cmp	w21, #6
	cset	w21, eq
	and	w22, w22, w20
	add	x20, sp, #2, lsl #12            ; =8192
	add	x20, x20, #3560
	ldrb	w24, [x20, w7, sxtw]
	and	w23, w24, #0x1
	fmov	s0, w23
	ubfx	w23, w24, #1, #1
	mov.b	v0[1], w23
	ubfx	w23, w24, #2, #1
	mov.b	v0[2], w23
	ubfx	w23, w24, #3, #1
	mov.b	v0[3], w23
	ubfx	w23, w24, #4, #1
	mov.b	v0[4], w23
	ubfx	w23, w24, #5, #1
	mov.b	v0[5], w23
	ubfx	w23, w24, #6, #1
	mov.b	v0[6], w23
	add	x23, sp, #2, lsl #12            ; =8192
	add	x23, x23, #3552
	lsr	w24, w24, #7
	mov.b	v0[7], w24
	ldrb	w24, [x23, w7, sxtw]
	and	w25, w24, #0x1
	fmov	s1, w25
	ubfx	w25, w24, #1, #1
	mov.b	v1[1], w25
	ubfx	w25, w24, #2, #1
	mov.b	v1[2], w25
	ubfx	w25, w24, #3, #1
	mov.b	v1[3], w25
	ubfx	w25, w24, #4, #1
	mov.b	v1[4], w25
	ubfx	w25, w24, #5, #1
	mov.b	v1[5], w25
	ubfx	w25, w24, #6, #1
	mov.b	v1[6], w25
	lsr	w24, w24, #7
	mov.b	v1[7], w24
	orr.8b	v2, v15, v1
	ldr	d3, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v3, v0
	eor.8b	v3, v3, v2
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w24, s3
	ands	w21, w22, w21
	csetm	w22, ne
	bics	w24, w21, w24
	csetm	w25, ne
	dup.8b	v3, w25
	bic.8b	v4, v2, v3
	dup.8b	v5, w22
	bit.8b	v1, v4, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v6
	addv.8b	b1, v1
	str	b1, [x23, w7, sxtw]
	bic.8b	v0, v0, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	str	b0, [x20, w7, sxtw]
	mov	w7, #-1                         ; =0xffffffff
	csinv	w7, w7, w19, eq
	and	w0, w7, w0
	dup.8b	v0, w21
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	dup.8b	v1, w24
	and.8b	v1, v1, v2
	str	q9, [sp, #6352]
	ldr	q2, [sp, #1968]                 ; 16-byte Reload
	str	q2, [sp, #6368]
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #2256
	ldr	w6, [x7, x6]
	csel	w4, w6, w4, ne
	bit.8b	v15, v1, v0
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	fmov	w6, s0
	cmp	w21, #1
	b.ne	LBB0_631
; %bb.121:                              ; %convergence.cascade321
                                        ;   in Loop: Header=BB0_120 Depth=3
	cmp	w4, #0
	ccmp	w5, #6, #2, ne
	b.hi	LBB0_631
; %bb.122:                              ; %convergence.cascade321
                                        ;   in Loop: Header=BB0_120 Depth=3
	add	w5, w5, #1
	tst	w6, #0xff
	b.ne	LBB0_120
	b	LBB0_631
LBB0_123:                               ; %schedule.21
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w5, s0
	ldr	q3, [sp, #9264]
	ldr	q5, [sp, #9248]
	ldr	q1, [sp, #9232]
	ldr	q0, [sp, #9216]
	shl.2d	v0, v0, #2
	dup.2d	v4, x11
	add.2d	v6, v4, v0
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w5, #0, LBB0_263
; %bb.124:                              ; %else7934
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_264
LBB0_125:                               ; %else7940
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbnz	w5, #2, LBB0_265
LBB0_126:                               ; %else7946
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_266
LBB0_127:                               ; %else7952
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbnz	w5, #4, LBB0_267
LBB0_128:                               ; %else7958
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_268
LBB0_129:                               ; %else7964
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbnz	w5, #6, LBB0_269
LBB0_130:                               ; %else7970
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_132
LBB0_131:                               ; %cond.load7972
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[3], [x6]
LBB0_132:                               ; %else7976
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q3, [sp, #880]                  ; 16-byte Reload
	bit.16b	v3, v2, v1
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #896]                  ; 16-byte Reload
	bit.16b	v2, v0, v1
	stp	q3, q2, [sp, #880]              ; 32-byte Folded Spill
	tst	w5, #0xff
	b.ne	LBB0_801
	b	LBB0_4
LBB0_133:                               ; %schedule.9
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w5, s0
	ldr	q3, [sp, #10416]
	ldr	q5, [sp, #10400]
	ldr	q1, [sp, #10384]
	ldr	q0, [sp, #10368]
	shl.2d	v0, v0, #2
	dup.2d	v4, x10
	add.2d	v6, v4, v0
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w5, #0, LBB0_270
; %bb.134:                              ; %else7199
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_271
LBB0_135:                               ; %else7205
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbnz	w5, #2, LBB0_272
LBB0_136:                               ; %else7211
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_273
LBB0_137:                               ; %else7217
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbnz	w5, #4, LBB0_274
LBB0_138:                               ; %else7223
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_275
LBB0_139:                               ; %else7229
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbnz	w5, #6, LBB0_276
LBB0_140:                               ; %else7235
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_142
LBB0_141:                               ; %cond.load7237
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[3], [x6]
LBB0_142:                               ; %else7241
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q3, [sp, #688]                  ; 16-byte Reload
	bit.16b	v3, v2, v1
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #704]                  ; 16-byte Reload
	bit.16b	v2, v0, v1
	stp	q3, q2, [sp, #688]              ; 32-byte Folded Spill
	tst	w5, #0xff
	b.ne	LBB0_469
	b	LBB0_4
LBB0_143:                               ; %schedule.27
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w5, s0
	ldr	q3, [sp, #8816]
	ldr	q5, [sp, #8800]
	ldr	q1, [sp, #8784]
	ldr	q0, [sp, #8768]
	shl.2d	v0, v0, #2
	dup.2d	v4, x12
	add.2d	v6, v4, v0
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w5, #0, LBB0_341
; %bb.144:                              ; %else8081
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_342
LBB0_145:                               ; %else8087
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbnz	w5, #2, LBB0_343
LBB0_146:                               ; %else8093
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_344
LBB0_147:                               ; %else8099
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbnz	w5, #4, LBB0_345
LBB0_148:                               ; %else8105
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_346
LBB0_149:                               ; %else8111
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbnz	w5, #6, LBB0_347
LBB0_150:                               ; %else8117
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_152
LBB0_151:                               ; %cond.load8119
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[3], [x6]
LBB0_152:                               ; %else8123
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q3, [sp, #976]                  ; 16-byte Reload
	bit.16b	v3, v2, v1
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #992]                  ; 16-byte Reload
	bit.16b	v2, v0, v1
	stp	q3, q2, [sp, #976]              ; 32-byte Folded Spill
	tst	w5, #0xff
	b.ne	LBB0_973
	b	LBB0_4
LBB0_153:                               ; %schedule.44
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w5, s0
	ldr	q1, [sp, #7600]
	ldr	q3, [sp, #7584]
	ldr	q5, [sp, #7568]
	ldr	q2, [sp, #7552]
	ldr	q0, [sp, #7824]
	ldr	q4, [sp, #7808]
	shl.2d	v6, v2, #2
	dup.2d	v2, x13
	add.2d	v6, v2, v6
	tbnz	w5, #0, LBB0_348
; %bb.154:                              ; %else8349
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_349
LBB0_155:                               ; %else8353
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v5, v5, #2
	add.2d	v5, v2, v5
	tbnz	w5, #2, LBB0_350
LBB0_156:                               ; %else8357
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_351
LBB0_157:                               ; %else8361
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v3, v3, #2
	add.2d	v3, v2, v3
	tbnz	w5, #4, LBB0_352
LBB0_158:                               ; %else8365
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_353
LBB0_159:                               ; %else8369
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v1, #2
	add.2d	v1, v2, v1
	tbnz	w5, #6, LBB0_354
LBB0_160:                               ; %else8373
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #7, LBB0_355
LBB0_161:                               ; %else8377
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w5, #0xff
	b.ne	LBB0_1114
	b	LBB0_4
LBB0_162:                               ; %scheduler.dispatch.route.schedule.12_crit_edge
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	umaxv.8b	b0, v0
	fmov	w5, s0
	eor	w5, w5, #0x1
	b	LBB0_522
LBB0_163:                               ; %schedule.25
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w5, s0
	ldr	q3, [sp, #8880]
	ldr	q5, [sp, #8864]
	ldr	q1, [sp, #8848]
	ldr	q0, [sp, #8832]
	shl.2d	v0, v0, #2
	dup.2d	v4, x12
	add.2d	v6, v4, v0
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w5, #0, LBB0_356
; %bb.164:                              ; %else8032
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_357
LBB0_165:                               ; %else8038
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbnz	w5, #2, LBB0_358
LBB0_166:                               ; %else8044
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_359
LBB0_167:                               ; %else8050
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbnz	w5, #4, LBB0_360
LBB0_168:                               ; %else8056
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_361
LBB0_169:                               ; %else8062
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbnz	w5, #6, LBB0_362
LBB0_170:                               ; %else8068
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_172
LBB0_171:                               ; %cond.load8070
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[3], [x6]
LBB0_172:                               ; %else8074
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q3, [sp, #944]                  ; 16-byte Reload
	bit.16b	v3, v2, v1
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #960]                  ; 16-byte Reload
	bit.16b	v2, v0, v1
	stp	q3, q2, [sp, #944]              ; 32-byte Folded Spill
	tst	w5, #0xff
	b.ne	LBB0_947
	b	LBB0_4
LBB0_173:                               ; %schedule.1
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w5, s0
	ldr	q3, [sp, #10672]
	ldr	q5, [sp, #10656]
	ldr	q1, [sp, #10640]
	ldr	q0, [sp, #10624]
	shl.2d	v0, v0, #2
	dup.2d	v4, x10
	add.2d	v6, v4, v0
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w5, #0, LBB0_363
; %bb.174:                              ; %else7003
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_364
LBB0_175:                               ; %else7009
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbnz	w5, #2, LBB0_365
LBB0_176:                               ; %else7015
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_366
LBB0_177:                               ; %else7021
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbnz	w5, #4, LBB0_367
LBB0_178:                               ; %else7027
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_368
LBB0_179:                               ; %else7033
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbnz	w5, #6, LBB0_369
LBB0_180:                               ; %else7039
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_182
LBB0_181:                               ; %cond.load7041
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[3], [x6]
LBB0_182:                               ; %else7045
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q3, [sp, #96]                   ; 16-byte Reload
	bit.16b	v3, v2, v1
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #112]                  ; 16-byte Reload
	bit.16b	v2, v0, v1
	stp	q3, q2, [sp, #96]               ; 32-byte Folded Spill
	tst	w5, #0xff
	b.eq	LBB0_4
LBB0_183:                               ; %schedule.2
                                        ;   in Loop: Header=BB0_6 Depth=2
	cbz	w4, LBB0_289
LBB0_184:                               ; %convergence.cascade.preheader
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w5, #0                          ; =0x0
LBB0_185:                               ; %convergence.cascade
                                        ;   Parent Loop BB0_5 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d6, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v0, v6
	addv.8b	b1, v1
	fmov	w6, s1
	umaxv.8b	b0, v0
	fmov	w20, s0
	sub	w7, w4, #1
	tst	w6, #0xff
	csel	w7, w7, wzr, ne
	mov	w6, #1                          ; =0x1
	lsl	w19, w6, w7
	and	w6, w19, w0
	tst	w6, #0xff
	cset	w22, ne
	str	q24, [sp, #7440]
	str	q27, [sp, #7456]
	ubfiz	x6, x7, #2, #3
	add	x21, sp, #1, lsl #12            ; =4096
	add	x21, x21, #3344
	ldr	w21, [x21, x6]
	cmp	w21, #0
	cset	w21, eq
	and	w22, w22, w20
	add	x20, sp, #2, lsl #12            ; =8192
	add	x20, x20, #3560
	ldrb	w24, [x20, w7, sxtw]
	and	w23, w24, #0x1
	fmov	s0, w23
	ubfx	w23, w24, #1, #1
	mov.b	v0[1], w23
	ubfx	w23, w24, #2, #1
	mov.b	v0[2], w23
	ubfx	w23, w24, #3, #1
	mov.b	v0[3], w23
	ubfx	w23, w24, #4, #1
	mov.b	v0[4], w23
	ubfx	w23, w24, #5, #1
	mov.b	v0[5], w23
	ubfx	w23, w24, #6, #1
	mov.b	v0[6], w23
	add	x23, sp, #2, lsl #12            ; =8192
	add	x23, x23, #3552
	lsr	w24, w24, #7
	mov.b	v0[7], w24
	ldrb	w24, [x23, w7, sxtw]
	and	w25, w24, #0x1
	fmov	s1, w25
	ubfx	w25, w24, #1, #1
	mov.b	v1[1], w25
	ubfx	w25, w24, #2, #1
	mov.b	v1[2], w25
	ubfx	w25, w24, #3, #1
	mov.b	v1[3], w25
	ubfx	w25, w24, #4, #1
	mov.b	v1[4], w25
	ubfx	w25, w24, #5, #1
	mov.b	v1[5], w25
	ubfx	w25, w24, #6, #1
	mov.b	v1[6], w25
	lsr	w24, w24, #7
	mov.b	v1[7], w24
	orr.8b	v2, v15, v1
	ldr	d3, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v3, v0
	eor.8b	v3, v3, v2
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w24, s3
	ands	w21, w22, w21
	csetm	w22, ne
	bics	w24, w21, w24
	csetm	w25, ne
	dup.8b	v3, w25
	bic.8b	v4, v2, v3
	dup.8b	v5, w22
	bit.8b	v1, v4, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v6
	addv.8b	b1, v1
	str	b1, [x23, w7, sxtw]
	bic.8b	v0, v0, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	str	b0, [x20, w7, sxtw]
	mov	w7, #-1                         ; =0xffffffff
	csinv	w7, w7, w19, eq
	and	w0, w7, w0
	dup.8b	v0, w21
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	dup.8b	v1, w24
	and.8b	v1, v1, v2
	str	q9, [sp, #7408]
	ldr	q2, [sp, #1968]                 ; 16-byte Reload
	str	q2, [sp, #7424]
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #3312
	ldr	w6, [x7, x6]
	csel	w4, w6, w4, ne
	bit.8b	v15, v1, v0
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	fmov	w6, s0
	cmp	w21, #1
	b.ne	LBB0_290
; %bb.186:                              ; %convergence.cascade
                                        ;   in Loop: Header=BB0_185 Depth=3
	cmp	w4, #0
	ccmp	w5, #6, #2, ne
	b.hi	LBB0_290
; %bb.187:                              ; %convergence.cascade
                                        ;   in Loop: Header=BB0_185 Depth=3
	add	w5, w5, #1
	tst	w6, #0xff
	b.ne	LBB0_185
	b	LBB0_290
LBB0_188:                               ; %schedule.42
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w5, s0
	ldr	q1, [sp, #7664]
	ldr	q3, [sp, #7648]
	ldr	q5, [sp, #7632]
	ldr	q2, [sp, #7616]
	ldr	q0, [sp, #7856]
	ldr	q4, [sp, #7840]
	shl.2d	v6, v2, #2
	dup.2d	v2, x13
	add.2d	v6, v2, v6
	tbnz	w5, #0, LBB0_370
; %bb.189:                              ; %else8323
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_371
LBB0_190:                               ; %else8326
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v5, v5, #2
	add.2d	v5, v2, v5
	tbnz	w5, #2, LBB0_372
LBB0_191:                               ; %else8329
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_373
LBB0_192:                               ; %else8332
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v3, v3, #2
	add.2d	v3, v2, v3
	tbnz	w5, #4, LBB0_374
LBB0_193:                               ; %else8335
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_375
LBB0_194:                               ; %else8338
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v1, #2
	add.2d	v1, v2, v1
	tbnz	w5, #6, LBB0_376
LBB0_195:                               ; %else8341
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #7, LBB0_377
LBB0_196:                               ; %else8344
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w5, #0xff
	b.ne	LBB0_1091
	b	LBB0_4
LBB0_197:                               ; %schedule.5
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w5, s0
	ldr	q3, [sp, #10544]
	ldr	q5, [sp, #10528]
	ldr	q1, [sp, #10512]
	ldr	q0, [sp, #10496]
	shl.2d	v0, v0, #2
	dup.2d	v4, x10
	add.2d	v6, v4, v0
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w5, #0, LBB0_378
; %bb.198:                              ; %else7101
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_379
LBB0_199:                               ; %else7107
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbnz	w5, #2, LBB0_380
LBB0_200:                               ; %else7113
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_381
LBB0_201:                               ; %else7119
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbnz	w5, #4, LBB0_382
LBB0_202:                               ; %else7125
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_383
LBB0_203:                               ; %else7131
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbnz	w5, #6, LBB0_384
LBB0_204:                               ; %else7137
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_206
LBB0_205:                               ; %cond.load7139
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[3], [x6]
LBB0_206:                               ; %else7143
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q3, [sp, #624]                  ; 16-byte Reload
	bit.16b	v3, v2, v1
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #640]                  ; 16-byte Reload
	bit.16b	v2, v0, v1
	stp	q3, q2, [sp, #624]              ; 32-byte Folded Spill
	tst	w5, #0xff
	b.ne	LBB0_419
	b	LBB0_4
LBB0_207:                               ; %schedule.7
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w5, s0
	ldr	q3, [sp, #10480]
	ldr	q5, [sp, #10464]
	ldr	q1, [sp, #10448]
	ldr	q0, [sp, #10432]
	shl.2d	v0, v0, #2
	dup.2d	v4, x10
	add.2d	v6, v4, v0
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w5, #0, LBB0_385
; %bb.208:                              ; %else7150
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_386
LBB0_209:                               ; %else7156
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbnz	w5, #2, LBB0_387
LBB0_210:                               ; %else7162
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_388
LBB0_211:                               ; %else7168
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbnz	w5, #4, LBB0_389
LBB0_212:                               ; %else7174
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_390
LBB0_213:                               ; %else7180
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbnz	w5, #6, LBB0_391
LBB0_214:                               ; %else7186
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_216
LBB0_215:                               ; %cond.load7188
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[3], [x6]
LBB0_216:                               ; %else7192
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q3, [sp, #656]                  ; 16-byte Reload
	bit.16b	v3, v2, v1
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #672]                  ; 16-byte Reload
	bit.16b	v2, v0, v1
	stp	q3, q2, [sp, #656]              ; 32-byte Folded Spill
	tst	w5, #0xff
	b.ne	LBB0_444
	b	LBB0_4
LBB0_217:                               ; %schedule.15
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w5, s0
	ldr	q3, [sp, #9456]
	ldr	q5, [sp, #9440]
	ldr	q1, [sp, #9424]
	ldr	q0, [sp, #9408]
	shl.2d	v0, v0, #2
	dup.2d	v4, x11
	add.2d	v6, v4, v0
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w5, #0, LBB0_392
; %bb.218:                              ; %else7787
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_393
LBB0_219:                               ; %else7793
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbnz	w5, #2, LBB0_394
LBB0_220:                               ; %else7799
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_395
LBB0_221:                               ; %else7805
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbnz	w5, #4, LBB0_396
LBB0_222:                               ; %else7811
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_397
LBB0_223:                               ; %else7817
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbnz	w5, #6, LBB0_398
LBB0_224:                               ; %else7823
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_226
LBB0_225:                               ; %cond.load7825
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[3], [x6]
LBB0_226:                               ; %else7829
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q3, [sp, #784]                  ; 16-byte Reload
	bit.16b	v3, v2, v1
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #800]                  ; 16-byte Reload
	bit.16b	v2, v0, v1
	stp	q3, q2, [sp, #784]              ; 32-byte Folded Spill
	tst	w5, #0xff
	b.ne	LBB0_719
	b	LBB0_4
LBB0_227:                               ; %scheduler.dispatch.route.schedule.33_crit_edge
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	umaxv.8b	b0, v0
	fmov	w5, s0
	eor	w5, w5, #0x1
	b	LBB0_1195
LBB0_228:                               ; %cond.load7881
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d6
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_68
LBB0_229:                               ; %cond.load7887
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v6[1]
	ld1.s	{ v0 }[1], [x6]
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbz	w5, #2, LBB0_69
LBB0_230:                               ; %cond.load7893
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_70
LBB0_231:                               ; %cond.load7899
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbz	w5, #4, LBB0_71
LBB0_232:                               ; %cond.load7905
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[0], [x6]
	tbz	w5, #5, LBB0_72
LBB0_233:                               ; %cond.load7911
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[1], [x6]
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbz	w5, #6, LBB0_73
LBB0_234:                               ; %cond.load7917
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[2], [x6]
	tbnz	w5, #7, LBB0_74
	b	LBB0_75
LBB0_235:                               ; %cond.load7979
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d6
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_79
LBB0_236:                               ; %cond.load7985
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v6[1]
	ld1.s	{ v0 }[1], [x6]
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbz	w5, #2, LBB0_80
LBB0_237:                               ; %cond.load7991
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_81
LBB0_238:                               ; %cond.load7997
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbz	w5, #4, LBB0_82
LBB0_239:                               ; %cond.load8003
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[0], [x6]
	tbz	w5, #5, LBB0_83
LBB0_240:                               ; %cond.load8009
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[1], [x6]
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbz	w5, #6, LBB0_84
LBB0_241:                               ; %cond.load8015
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[2], [x6]
	tbnz	w5, #7, LBB0_85
	b	LBB0_86
LBB0_242:                               ; %cond.load7832
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d6
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_89
LBB0_243:                               ; %cond.load7838
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v6[1]
	ld1.s	{ v0 }[1], [x6]
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbz	w5, #2, LBB0_90
LBB0_244:                               ; %cond.load7844
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_91
LBB0_245:                               ; %cond.load7850
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbz	w5, #4, LBB0_92
LBB0_246:                               ; %cond.load7856
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[0], [x6]
	tbz	w5, #5, LBB0_93
LBB0_247:                               ; %cond.load7862
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[1], [x6]
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbz	w5, #6, LBB0_94
LBB0_248:                               ; %cond.load7868
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[2], [x6]
	tbnz	w5, #7, LBB0_95
	b	LBB0_96
LBB0_249:                               ; %cond.load7048
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d6
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_100
LBB0_250:                               ; %cond.load7054
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v6[1]
	ld1.s	{ v0 }[1], [x6]
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbz	w5, #2, LBB0_101
LBB0_251:                               ; %cond.load7060
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_102
LBB0_252:                               ; %cond.load7066
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbz	w5, #4, LBB0_103
LBB0_253:                               ; %cond.load7072
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[0], [x6]
	tbz	w5, #5, LBB0_104
LBB0_254:                               ; %cond.load7078
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[1], [x6]
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbz	w5, #6, LBB0_105
LBB0_255:                               ; %cond.load7084
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[2], [x6]
	tbnz	w5, #7, LBB0_106
	b	LBB0_107
LBB0_256:                               ; %cond.load7734
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d6
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_110
LBB0_257:                               ; %cond.load7740
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v6[1]
	ld1.s	{ v0 }[1], [x6]
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbz	w5, #2, LBB0_111
LBB0_258:                               ; %cond.load7746
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_112
LBB0_259:                               ; %cond.load7752
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbz	w5, #4, LBB0_113
LBB0_260:                               ; %cond.load7758
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[0], [x6]
	tbz	w5, #5, LBB0_114
LBB0_261:                               ; %cond.load7764
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[1], [x6]
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbz	w5, #6, LBB0_115
LBB0_262:                               ; %cond.load7770
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[2], [x6]
	tbnz	w5, #7, LBB0_116
	b	LBB0_117
LBB0_263:                               ; %cond.load7930
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d6
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_125
LBB0_264:                               ; %cond.load7936
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v6[1]
	ld1.s	{ v0 }[1], [x6]
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbz	w5, #2, LBB0_126
LBB0_265:                               ; %cond.load7942
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_127
LBB0_266:                               ; %cond.load7948
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbz	w5, #4, LBB0_128
LBB0_267:                               ; %cond.load7954
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[0], [x6]
	tbz	w5, #5, LBB0_129
LBB0_268:                               ; %cond.load7960
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[1], [x6]
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbz	w5, #6, LBB0_130
LBB0_269:                               ; %cond.load7966
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[2], [x6]
	tbnz	w5, #7, LBB0_131
	b	LBB0_132
LBB0_270:                               ; %cond.load7195
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d6
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_135
LBB0_271:                               ; %cond.load7201
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v6[1]
	ld1.s	{ v0 }[1], [x6]
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbz	w5, #2, LBB0_136
LBB0_272:                               ; %cond.load7207
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_137
LBB0_273:                               ; %cond.load7213
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbz	w5, #4, LBB0_138
LBB0_274:                               ; %cond.load7219
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[0], [x6]
	tbz	w5, #5, LBB0_139
LBB0_275:                               ; %cond.load7225
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[1], [x6]
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbz	w5, #6, LBB0_140
LBB0_276:                               ; %cond.load7231
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[2], [x6]
	tbnz	w5, #7, LBB0_141
	b	LBB0_142
LBB0_277:                               ; %varying.coherent
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	d0, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v1, v0
	addv.8b	b0, v0
	fmov	w2, s0
	tst	w2, #0xff
	ldr	q29, [sp, #1648]                ; 16-byte Reload
	ldr	q22, [sp, #1712]                ; 16-byte Reload
	ldr	q26, [sp, #1696]                ; 16-byte Reload
	ldr	q24, [sp, #1664]                ; 16-byte Reload
	ldr	q23, [sp, #1744]                ; 16-byte Reload
	ldr	q27, [sp, #1680]                ; 16-byte Reload
	b.eq	LBB0_506
; %bb.278:                              ; %varying.coherent.true
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w5, #0xff
	ldr	q25, [sp, #1728]                ; 16-byte Reload
	b.eq	LBB0_1331
; %bb.279:                              ; %schedule.1.thread
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q3, [sp, #10672]
	ldr	q4, [sp, #10656]
	ldr	q1, [sp, #10640]
	ldr	q0, [sp, #10624]
	shl.2d	v0, v0, #2
	add.2d	v5, v18, v0
	fmov	w2, s17
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w2, #0, LBB0_507
; %bb.280:                              ; %else8416
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w2, #1, LBB0_508
LBB0_281:                               ; %else8422
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v1, #2
	add.2d	v1, v18, v1
	tbnz	w2, #2, LBB0_509
LBB0_282:                               ; %else8428
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w2, #3, LBB0_510
LBB0_283:                               ; %else8434
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v4, #2
	add.2d	v1, v18, v1
	tbnz	w2, #4, LBB0_511
LBB0_284:                               ; %else8440
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w2, #5, LBB0_512
LBB0_285:                               ; %else8446
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v3, #2
	add.2d	v1, v18, v1
	tbnz	w2, #6, LBB0_513
LBB0_286:                               ; %else8452
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w2, #7, LBB0_288
LBB0_287:                               ; %cond.load8454
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x2, v1[1]
	ld1.s	{ v2 }[3], [x2]
LBB0_288:                               ; %else8458
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q3, [sp, #96]                   ; 16-byte Reload
	bit.16b	v3, v2, v1
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #112]                  ; 16-byte Reload
	bit.16b	v2, v0, v1
	stp	q3, q2, [sp, #96]               ; 32-byte Folded Spill
	mov	w2, #2                          ; =0x2
	mov	w3, #1                          ; =0x1
	cbnz	w4, LBB0_184
LBB0_289:                               ; %schedule.2.convergence.cascade.exit_crit_edge
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w6, s0
LBB0_290:                               ; %convergence.cascade.exit
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w6, #0xff
	b.eq	LBB0_4
; %bb.291:                              ; %convergence.target.2.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	dup.2d	v0, x3
	ldp	q2, q1, [sp, #720]              ; 32-byte Folded Reload
	add.2d	v1, v1, v0
	add.2d	v2, v2, v0
	ldp	q4, q3, [sp, #752]              ; 32-byte Folded Reload
	add.2d	v3, v3, v0
	add.2d	v0, v4, v0
	ldr	q4, [sp, #10592]
	ldr	q5, [sp, #10608]
	ldr	q6, [sp, #10560]
	ldr	q7, [sp, #10576]
	mov	b16, v15[2]
	mov.b	v16[4], v15[3]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	bif.16b	v0, v7, v16
	mov	b7, v15[0]
	mov.b	v7[4], v15[1]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	bif.16b	v3, v6, v7
	mov	b6, v15[6]
	mov.b	v6[4], v15[7]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	bif.16b	v2, v5, v6
	mov	b5, v15[4]
	mov.b	v5[4], v15[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	bif.16b	v1, v4, v5
	str	q1, [sp, #10592]
	str	q2, [sp, #10608]
	str	q3, [sp, #10560]
	str	q0, [sp, #10576]
	and.8b	v7, v31, v15
	shl.8b	v0, v7, #7
	cmlt.8b	v0, v0, #0
	umaxv.8b	b1, v0
	fmov	w5, s1
	tbz	w5, #0, LBB0_297
; %bb.292:                              ; %convergence.target.2.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	bic.8b	v16, v15, v31
	shl.8b	v1, v16, #7
	cmlt.8b	v1, v1, #0
	ldr	d2, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w5, s1
	tst	w5, #0xff
	b.eq	LBB0_297
; %bb.293:                              ; %varying.divergent147
                                        ;   in Loop: Header=BB0_6 Depth=2
	cmp	w4, #0
	cset	w5, ne
	sub	w5, w4, w5
	and	w6, w0, #0xff
	lsr	w7, w6, w5
	tst	w7, #0x1
	cset	w7, eq
	cmp	w4, #0
	str	q24, [sp, #2288]
	str	q27, [sp, #2304]
	and	x5, x5, #0x7
	add	x19, sp, #2288
	ldr	w5, [x19, x5, lsl #2]
	csinc	w7, w7, wzr, ne
	cmp	w5, #1
	csinc	w5, w7, wzr, eq
	cmp	w6, #255
	b.ne	LBB0_295
; %bb.294:                              ; %varying.divergent147
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #0, LBB0_295
	b	LBB0_1348
LBB0_295:                               ; %convergence.overflow.resume150
                                        ;   in Loop: Header=BB0_6 Depth=2
	mvn	w6, w0
	rbit	w6, w6
	clz	w6, w6
	mov	w7, #255                        ; =0xff
	bics	wzr, w7, w0
	csel	w7, wzr, w6, eq
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #3560
	ldrb	w20, [x6, w7, uxtw]
	and	w19, w20, #0x1
	fmov	s0, w19
	ubfx	w19, w20, #1, #1
	mov.b	v0[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v0[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v0[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v0[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v0[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v0[6], w19
	add	x19, sp, #2, lsl #12            ; =8192
	add	x19, x19, #3552
	lsr	w20, w20, #7
	mov.b	v0[7], w20
	ldrb	w20, [x19, w7, uxtw]
	and	w21, w20, #0x1
	fmov	s1, w21
	ubfx	w21, w20, #1, #1
	mov.b	v1[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v1[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v1[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v1[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v1[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v1[6], w21
	lsr	w20, w20, #7
	mov.b	v1[7], w20
	cmp	w5, #0
	csetm	w20, ne
	dup.8b	v2, w20
	bit.8b	v0, v15, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	ldr	d3, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x6, w7, uxtw]
	bic.8b	v0, v1, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x19, w7, uxtw]
	cmp	x1, #8
	b.hs	LBB0_1348
; %bb.296:                              ; %ready.overflow.resume152
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v0, v16, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	ldp	q3, q1, [sp, #592]              ; 32-byte Folded Reload
	and.16b	v2, v0, v3
	zip1.8b	v0, v16, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v1, v0, v1
	stp	q2, q1, [sp, #592]              ; 32-byte Folded Spill
	str	q9, [sp, #2256]
	ldr	q0, [sp, #1968]                 ; 16-byte Reload
	str	q0, [sp, #2272]
	ubfiz	x6, x7, #2, #3
	add	x19, sp, #2256
	ldr	w19, [x19, x6]
	cmp	w5, #0
	csel	w19, w4, w19, ne
	csinc	w4, w4, w7, eq
	str	q9, [sp, #2224]
	str	q0, [sp, #2240]
	add	x20, sp, #2224
	str	w19, [x20, x6]
	ldr	q0, [sp, #2240]
	str	q0, [sp, #1968]                 ; 16-byte Spill
	ldr	q9, [sp, #2224]
	str	q24, [sp, #2192]
	str	q27, [sp, #2208]
	add	x19, sp, #2192
	ldr	w19, [x19, x6]
	csinc	w19, w19, wzr, eq
	str	q24, [sp, #2160]
	str	q27, [sp, #2176]
	add	x20, sp, #2160
	str	w19, [x20, x6]
	mov	w6, #4                          ; =0x4
	mov	w19, #3                         ; =0x3
	ldr	q27, [sp, #2176]
	ldr	q24, [sp, #2160]
	b	LBB0_1261
LBB0_297:                               ; %varying.coherent148
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w5, s0
	tst	w5, #0xff
	b.eq	LBB0_399
; %bb.298:                              ; %schedule.3.thread
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q3, [sp, #10608]
	ldr	q5, [sp, #10592]
	ldr	q1, [sp, #10576]
	ldr	q0, [sp, #10560]
	shl.2d	v0, v0, #2
	dup.2d	v4, x10
	add.2d	v6, v4, v0
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d2, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v2
	addv.8b	b0, v0
	fmov	w5, s0
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w5, #0, LBB0_499
; %bb.299:                              ; %else8465
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_500
LBB0_300:                               ; %else8471
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbnz	w5, #2, LBB0_501
LBB0_301:                               ; %else8477
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_502
LBB0_302:                               ; %else8483
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbnz	w5, #4, LBB0_503
LBB0_303:                               ; %else8489
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_504
LBB0_304:                               ; %else8495
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbnz	w5, #6, LBB0_505
LBB0_305:                               ; %else8501
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_307
LBB0_306:                               ; %cond.load8503
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x5, v1[1]
	ld1.s	{ v2 }[3], [x5]
LBB0_307:                               ; %else8507
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q3, [sp, #592]                  ; 16-byte Reload
	bit.16b	v3, v2, v1
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #608]                  ; 16-byte Reload
	bit.16b	v2, v0, v1
	stp	q3, q2, [sp, #592]              ; 32-byte Folded Spill
LBB0_308:                               ; %schedule.4
                                        ;   in Loop: Header=BB0_6 Depth=2
	cbz	w4, LBB0_400
LBB0_309:                               ; %convergence.cascade156.preheader
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w5, #0                          ; =0x0
LBB0_310:                               ; %convergence.cascade156
                                        ;   Parent Loop BB0_5 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d6, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v0, v6
	addv.8b	b1, v1
	fmov	w6, s1
	umaxv.8b	b0, v0
	fmov	w20, s0
	sub	w7, w4, #1
	tst	w6, #0xff
	csel	w7, w7, wzr, ne
	mov	w6, #1                          ; =0x1
	lsl	w19, w6, w7
	and	w6, w19, w0
	tst	w6, #0xff
	cset	w22, ne
	str	q24, [sp, #7376]
	str	q27, [sp, #7392]
	ubfiz	x6, x7, #2, #3
	add	x21, sp, #1, lsl #12            ; =4096
	add	x21, x21, #3280
	ldr	w21, [x21, x6]
	cmp	w21, #1
	cset	w21, eq
	and	w22, w22, w20
	add	x20, sp, #2, lsl #12            ; =8192
	add	x20, x20, #3560
	ldrb	w24, [x20, w7, sxtw]
	and	w23, w24, #0x1
	fmov	s0, w23
	ubfx	w23, w24, #1, #1
	mov.b	v0[1], w23
	ubfx	w23, w24, #2, #1
	mov.b	v0[2], w23
	ubfx	w23, w24, #3, #1
	mov.b	v0[3], w23
	ubfx	w23, w24, #4, #1
	mov.b	v0[4], w23
	ubfx	w23, w24, #5, #1
	mov.b	v0[5], w23
	ubfx	w23, w24, #6, #1
	mov.b	v0[6], w23
	add	x23, sp, #2, lsl #12            ; =8192
	add	x23, x23, #3552
	lsr	w24, w24, #7
	mov.b	v0[7], w24
	ldrb	w24, [x23, w7, sxtw]
	and	w25, w24, #0x1
	fmov	s1, w25
	ubfx	w25, w24, #1, #1
	mov.b	v1[1], w25
	ubfx	w25, w24, #2, #1
	mov.b	v1[2], w25
	ubfx	w25, w24, #3, #1
	mov.b	v1[3], w25
	ubfx	w25, w24, #4, #1
	mov.b	v1[4], w25
	ubfx	w25, w24, #5, #1
	mov.b	v1[5], w25
	ubfx	w25, w24, #6, #1
	mov.b	v1[6], w25
	lsr	w24, w24, #7
	mov.b	v1[7], w24
	orr.8b	v2, v15, v1
	ldr	d3, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v3, v0
	eor.8b	v3, v3, v2
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w24, s3
	ands	w21, w22, w21
	csetm	w22, ne
	bics	w24, w21, w24
	csetm	w25, ne
	dup.8b	v3, w25
	bic.8b	v4, v2, v3
	dup.8b	v5, w22
	bit.8b	v1, v4, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v6
	addv.8b	b1, v1
	str	b1, [x23, w7, sxtw]
	bic.8b	v0, v0, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	str	b0, [x20, w7, sxtw]
	mov	w7, #-1                         ; =0xffffffff
	csinv	w7, w7, w19, eq
	and	w0, w7, w0
	dup.8b	v0, w21
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	dup.8b	v1, w24
	and.8b	v1, v1, v2
	str	q9, [sp, #7344]
	ldr	q2, [sp, #1968]                 ; 16-byte Reload
	str	q2, [sp, #7360]
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #3248
	ldr	w6, [x7, x6]
	csel	w4, w6, w4, ne
	bit.8b	v15, v1, v0
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	fmov	w6, s0
	cmp	w21, #1
	b.ne	LBB0_401
; %bb.311:                              ; %convergence.cascade156
                                        ;   in Loop: Header=BB0_310 Depth=3
	cmp	w4, #0
	ccmp	w5, #6, #2, ne
	b.hi	LBB0_401
; %bb.312:                              ; %convergence.cascade156
                                        ;   in Loop: Header=BB0_310 Depth=3
	add	w5, w5, #1
	tst	w6, #0xff
	b.ne	LBB0_310
	b	LBB0_401
LBB0_313:                               ; %cond.load6803
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x3, d1
	ldr	s0, [x3]
	tbz	w2, #1, LBB0_25
LBB0_314:                               ; %cond.load6809
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x3, v1[1]
	ld1.s	{ v0 }[1], [x3]
	add.2d	v1, v25, v3
	tbz	w2, #2, LBB0_26
LBB0_315:                               ; %cond.load6815
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x3, d1
	ld1.s	{ v0 }[2], [x3]
	tbz	w2, #3, LBB0_27
LBB0_316:                               ; %cond.load6821
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x3, v1[1]
	ld1.s	{ v0 }[3], [x3]
	add.2d	v1, v26, v3
	tbz	w2, #4, LBB0_28
LBB0_317:                               ; %cond.load6827
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x3, d1
	ld1.s	{ v2 }[0], [x3]
	tbz	w2, #5, LBB0_29
LBB0_318:                               ; %cond.load6833
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x3, v1[1]
	ld1.s	{ v2 }[1], [x3]
	add.2d	v1, v29, v3
	tbz	w2, #6, LBB0_30
LBB0_319:                               ; %cond.load6839
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x3, d1
	ld1.s	{ v2 }[2], [x3]
	tbnz	w2, #7, LBB0_31
	b	LBB0_32
LBB0_320:                               ; %cond.load6852
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x3, d1
	ldr	s0, [x3]
	tbz	w2, #1, LBB0_34
LBB0_321:                               ; %cond.load6858
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x3, v1[1]
	ld1.s	{ v0 }[1], [x3]
	add.2d	v1, v25, v3
	tbz	w2, #2, LBB0_35
LBB0_322:                               ; %cond.load6864
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x3, d1
	ld1.s	{ v0 }[2], [x3]
	tbz	w2, #3, LBB0_36
LBB0_323:                               ; %cond.load6870
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x3, v1[1]
	ld1.s	{ v0 }[3], [x3]
	add.2d	v1, v26, v3
	tbz	w2, #4, LBB0_37
LBB0_324:                               ; %cond.load6876
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x3, d1
	ld1.s	{ v2 }[0], [x3]
	tbz	w2, #5, LBB0_38
LBB0_325:                               ; %cond.load6882
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x3, v1[1]
	ld1.s	{ v2 }[1], [x3]
	add.2d	v1, v29, v3
	tbz	w2, #6, LBB0_39
LBB0_326:                               ; %cond.load6888
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x3, d1
	ld1.s	{ v2 }[2], [x3]
	tbnz	w2, #7, LBB0_40
	b	LBB0_41
LBB0_327:                               ; %cond.load6901
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x3, d1
	ldr	s0, [x3]
	tbz	w2, #1, LBB0_43
LBB0_328:                               ; %cond.load6907
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x3, v1[1]
	ld1.s	{ v0 }[1], [x3]
	add.2d	v1, v25, v3
	tbz	w2, #2, LBB0_44
LBB0_329:                               ; %cond.load6913
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x3, d1
	ld1.s	{ v0 }[2], [x3]
	tbz	w2, #3, LBB0_45
LBB0_330:                               ; %cond.load6919
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x3, v1[1]
	ld1.s	{ v0 }[3], [x3]
	add.2d	v1, v26, v3
	tbz	w2, #4, LBB0_46
LBB0_331:                               ; %cond.load6925
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x3, d1
	ld1.s	{ v2 }[0], [x3]
	tbz	w2, #5, LBB0_47
LBB0_332:                               ; %cond.load6931
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x3, v1[1]
	ld1.s	{ v2 }[1], [x3]
	add.2d	v1, v29, v3
	tbz	w2, #6, LBB0_48
LBB0_333:                               ; %cond.load6937
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x3, d1
	ld1.s	{ v2 }[2], [x3]
	tbnz	w2, #7, LBB0_49
	b	LBB0_50
LBB0_334:                               ; %cond.load6950
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x3, d1
	ldr	s0, [x3]
	tbz	w2, #1, LBB0_52
LBB0_335:                               ; %cond.load6956
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x3, v1[1]
	ld1.s	{ v0 }[1], [x3]
	add.2d	v1, v25, v3
	tbz	w2, #2, LBB0_53
LBB0_336:                               ; %cond.load6962
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x3, d1
	ld1.s	{ v0 }[2], [x3]
	tbz	w2, #3, LBB0_54
LBB0_337:                               ; %cond.load6968
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x3, v1[1]
	ld1.s	{ v0 }[3], [x3]
	add.2d	v1, v26, v3
	tbz	w2, #4, LBB0_55
LBB0_338:                               ; %cond.load6974
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x3, d1
	ld1.s	{ v2 }[0], [x3]
	tbz	w2, #5, LBB0_56
LBB0_339:                               ; %cond.load6980
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x3, v1[1]
	ld1.s	{ v2 }[1], [x3]
	add.2d	v1, v29, v3
	tbz	w2, #6, LBB0_57
LBB0_340:                               ; %cond.load6986
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x3, d1
	ld1.s	{ v2 }[2], [x3]
	mov.16b	v7, v20
	tbnz	w2, #7, LBB0_58
	b	LBB0_59
LBB0_341:                               ; %cond.load8077
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d6
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_145
LBB0_342:                               ; %cond.load8083
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v6[1]
	ld1.s	{ v0 }[1], [x6]
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbz	w5, #2, LBB0_146
LBB0_343:                               ; %cond.load8089
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_147
LBB0_344:                               ; %cond.load8095
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbz	w5, #4, LBB0_148
LBB0_345:                               ; %cond.load8101
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[0], [x6]
	tbz	w5, #5, LBB0_149
LBB0_346:                               ; %cond.load8107
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[1], [x6]
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbz	w5, #6, LBB0_150
LBB0_347:                               ; %cond.load8113
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[2], [x6]
	tbnz	w5, #7, LBB0_151
	b	LBB0_152
LBB0_348:                               ; %cond.store8346
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d6
	str	s4, [x6]
	tbz	w5, #1, LBB0_155
LBB0_349:                               ; %cond.store8350
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v6[1]
	st1.s	{ v4 }[1], [x6]
	shl.2d	v5, v5, #2
	add.2d	v5, v2, v5
	tbz	w5, #2, LBB0_156
LBB0_350:                               ; %cond.store8354
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d5
	st1.s	{ v4 }[2], [x6]
	tbz	w5, #3, LBB0_157
LBB0_351:                               ; %cond.store8358
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v5[1]
	st1.s	{ v4 }[3], [x6]
	shl.2d	v3, v3, #2
	add.2d	v3, v2, v3
	tbz	w5, #4, LBB0_158
LBB0_352:                               ; %cond.store8362
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d3
	str	s0, [x6]
	tbz	w5, #5, LBB0_159
LBB0_353:                               ; %cond.store8366
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v3[1]
	st1.s	{ v0 }[1], [x6]
	shl.2d	v1, v1, #2
	add.2d	v1, v2, v1
	tbz	w5, #6, LBB0_160
LBB0_354:                               ; %cond.store8370
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	st1.s	{ v0 }[2], [x6]
	tbz	w5, #7, LBB0_161
LBB0_355:                               ; %cond.store8374
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	st1.s	{ v0 }[3], [x6]
	tst	w5, #0xff
	b.ne	LBB0_1114
	b	LBB0_4
LBB0_356:                               ; %cond.load8028
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d6
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_165
LBB0_357:                               ; %cond.load8034
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v6[1]
	ld1.s	{ v0 }[1], [x6]
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbz	w5, #2, LBB0_166
LBB0_358:                               ; %cond.load8040
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_167
LBB0_359:                               ; %cond.load8046
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbz	w5, #4, LBB0_168
LBB0_360:                               ; %cond.load8052
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[0], [x6]
	tbz	w5, #5, LBB0_169
LBB0_361:                               ; %cond.load8058
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[1], [x6]
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbz	w5, #6, LBB0_170
LBB0_362:                               ; %cond.load8064
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[2], [x6]
	tbnz	w5, #7, LBB0_171
	b	LBB0_172
LBB0_363:                               ; %cond.load6999
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d6
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_175
LBB0_364:                               ; %cond.load7005
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v6[1]
	ld1.s	{ v0 }[1], [x6]
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbz	w5, #2, LBB0_176
LBB0_365:                               ; %cond.load7011
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_177
LBB0_366:                               ; %cond.load7017
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbz	w5, #4, LBB0_178
LBB0_367:                               ; %cond.load7023
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[0], [x6]
	tbz	w5, #5, LBB0_179
LBB0_368:                               ; %cond.load7029
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[1], [x6]
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbz	w5, #6, LBB0_180
LBB0_369:                               ; %cond.load7035
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[2], [x6]
	tbnz	w5, #7, LBB0_181
	b	LBB0_182
LBB0_370:                               ; %cond.store
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d6
	str	s4, [x6]
	tbz	w5, #1, LBB0_190
LBB0_371:                               ; %cond.store8324
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v6[1]
	st1.s	{ v4 }[1], [x6]
	shl.2d	v5, v5, #2
	add.2d	v5, v2, v5
	tbz	w5, #2, LBB0_191
LBB0_372:                               ; %cond.store8327
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d5
	st1.s	{ v4 }[2], [x6]
	tbz	w5, #3, LBB0_192
LBB0_373:                               ; %cond.store8330
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v5[1]
	st1.s	{ v4 }[3], [x6]
	shl.2d	v3, v3, #2
	add.2d	v3, v2, v3
	tbz	w5, #4, LBB0_193
LBB0_374:                               ; %cond.store8333
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d3
	str	s0, [x6]
	tbz	w5, #5, LBB0_194
LBB0_375:                               ; %cond.store8336
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v3[1]
	st1.s	{ v0 }[1], [x6]
	shl.2d	v1, v1, #2
	add.2d	v1, v2, v1
	tbz	w5, #6, LBB0_195
LBB0_376:                               ; %cond.store8339
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	st1.s	{ v0 }[2], [x6]
	tbz	w5, #7, LBB0_196
LBB0_377:                               ; %cond.store8342
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	st1.s	{ v0 }[3], [x6]
	tst	w5, #0xff
	b.ne	LBB0_1091
	b	LBB0_4
LBB0_378:                               ; %cond.load7097
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d6
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_199
LBB0_379:                               ; %cond.load7103
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v6[1]
	ld1.s	{ v0 }[1], [x6]
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbz	w5, #2, LBB0_200
LBB0_380:                               ; %cond.load7109
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_201
LBB0_381:                               ; %cond.load7115
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbz	w5, #4, LBB0_202
LBB0_382:                               ; %cond.load7121
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[0], [x6]
	tbz	w5, #5, LBB0_203
LBB0_383:                               ; %cond.load7127
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[1], [x6]
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbz	w5, #6, LBB0_204
LBB0_384:                               ; %cond.load7133
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[2], [x6]
	tbnz	w5, #7, LBB0_205
	b	LBB0_206
LBB0_385:                               ; %cond.load7146
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d6
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_209
LBB0_386:                               ; %cond.load7152
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v6[1]
	ld1.s	{ v0 }[1], [x6]
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbz	w5, #2, LBB0_210
LBB0_387:                               ; %cond.load7158
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_211
LBB0_388:                               ; %cond.load7164
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbz	w5, #4, LBB0_212
LBB0_389:                               ; %cond.load7170
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[0], [x6]
	tbz	w5, #5, LBB0_213
LBB0_390:                               ; %cond.load7176
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[1], [x6]
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbz	w5, #6, LBB0_214
LBB0_391:                               ; %cond.load7182
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[2], [x6]
	tbnz	w5, #7, LBB0_215
	b	LBB0_216
LBB0_392:                               ; %cond.load7783
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d6
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_219
LBB0_393:                               ; %cond.load7789
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v6[1]
	ld1.s	{ v0 }[1], [x6]
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbz	w5, #2, LBB0_220
LBB0_394:                               ; %cond.load7795
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_221
LBB0_395:                               ; %cond.load7801
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbz	w5, #4, LBB0_222
LBB0_396:                               ; %cond.load7807
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[0], [x6]
	tbz	w5, #5, LBB0_223
LBB0_397:                               ; %cond.load7813
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[1], [x6]
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbz	w5, #6, LBB0_224
LBB0_398:                               ; %cond.load7819
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[2], [x6]
	tbnz	w5, #7, LBB0_225
	b	LBB0_226
LBB0_399:                               ; %varying.coherent.false154
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	ldp	q3, q1, [sp, #592]              ; 32-byte Folded Reload
	and.16b	v2, v0, v3
	zip1.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v1, v0, v1
	stp	q2, q1, [sp, #592]              ; 32-byte Folded Spill
	cbnz	w4, LBB0_309
LBB0_400:                               ; %schedule.4.convergence.cascade.exit157_crit_edge
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w6, s0
LBB0_401:                               ; %convergence.cascade.exit157
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w6, #0xff
	b.eq	LBB0_4
; %bb.402:                              ; %convergence.target.4.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	dup.2d	v0, x2
	ldp	q2, q1, [sp, #720]              ; 32-byte Folded Reload
	add.2d	v1, v1, v0
	add.2d	v2, v2, v0
	ldp	q4, q3, [sp, #752]              ; 32-byte Folded Reload
	add.2d	v3, v3, v0
	add.2d	v0, v4, v0
	ldr	q4, [sp, #10528]
	ldr	q5, [sp, #10544]
	ldr	q6, [sp, #10496]
	ldr	q7, [sp, #10512]
	mov	b16, v15[2]
	mov.b	v16[4], v15[3]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	bif.16b	v0, v7, v16
	mov	b7, v15[0]
	mov.b	v7[4], v15[1]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	bif.16b	v3, v6, v7
	mov	b6, v15[6]
	mov.b	v6[4], v15[7]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	bif.16b	v2, v5, v6
	mov	b5, v15[4]
	mov.b	v5[4], v15[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	bif.16b	v1, v4, v5
	str	q1, [sp, #10528]
	str	q2, [sp, #10544]
	str	q3, [sp, #10496]
	str	q0, [sp, #10512]
	and.8b	v7, v31, v15
	shl.8b	v0, v7, #7
	cmlt.8b	v0, v0, #0
	umaxv.8b	b1, v0
	fmov	w5, s1
	tbz	w5, #0, LBB0_408
; %bb.403:                              ; %convergence.target.4.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	bic.8b	v16, v15, v31
	shl.8b	v1, v16, #7
	cmlt.8b	v1, v1, #0
	ldr	d2, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w5, s1
	tst	w5, #0xff
	b.eq	LBB0_408
; %bb.404:                              ; %varying.divergent178
                                        ;   in Loop: Header=BB0_6 Depth=2
	cmp	w4, #0
	cset	w5, ne
	sub	w5, w4, w5
	and	w6, w0, #0xff
	lsr	w7, w6, w5
	tst	w7, #0x1
	cset	w7, eq
	cmp	w4, #0
	str	q24, [sp, #2448]
	str	q27, [sp, #2464]
	and	x5, x5, #0x7
	add	x19, sp, #2448
	ldr	w5, [x19, x5, lsl #2]
	csinc	w7, w7, wzr, ne
	cmp	w5, #2
	csinc	w5, w7, wzr, eq
	cmp	w6, #255
	b.ne	LBB0_406
; %bb.405:                              ; %varying.divergent178
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #0, LBB0_406
	b	LBB0_1348
LBB0_406:                               ; %convergence.overflow.resume181
                                        ;   in Loop: Header=BB0_6 Depth=2
	mvn	w6, w0
	rbit	w6, w6
	clz	w6, w6
	mov	w7, #255                        ; =0xff
	bics	wzr, w7, w0
	csel	w7, wzr, w6, eq
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #3560
	ldrb	w20, [x6, w7, uxtw]
	and	w19, w20, #0x1
	fmov	s0, w19
	ubfx	w19, w20, #1, #1
	mov.b	v0[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v0[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v0[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v0[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v0[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v0[6], w19
	add	x19, sp, #2, lsl #12            ; =8192
	add	x19, x19, #3552
	lsr	w20, w20, #7
	mov.b	v0[7], w20
	ldrb	w20, [x19, w7, uxtw]
	and	w21, w20, #0x1
	fmov	s1, w21
	ubfx	w21, w20, #1, #1
	mov.b	v1[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v1[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v1[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v1[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v1[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v1[6], w21
	lsr	w20, w20, #7
	mov.b	v1[7], w20
	cmp	w5, #0
	csetm	w20, ne
	dup.8b	v2, w20
	bit.8b	v0, v15, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	ldr	d3, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x6, w7, uxtw]
	bic.8b	v0, v1, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x19, w7, uxtw]
	cmp	x1, #8
	b.hs	LBB0_1348
; %bb.407:                              ; %ready.overflow.resume183
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v0, v16, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	ldp	q3, q1, [sp, #624]              ; 32-byte Folded Reload
	and.16b	v2, v0, v3
	zip1.8b	v0, v16, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v1, v0, v1
	stp	q2, q1, [sp, #624]              ; 32-byte Folded Spill
	str	q9, [sp, #2416]
	ldr	q0, [sp, #1968]                 ; 16-byte Reload
	str	q0, [sp, #2432]
	ubfiz	x6, x7, #2, #3
	add	x19, sp, #2416
	ldr	w19, [x19, x6]
	cmp	w5, #0
	csel	w19, w4, w19, ne
	csinc	w4, w4, w7, eq
	str	q9, [sp, #2384]
	str	q0, [sp, #2400]
	add	x20, sp, #2384
	str	w19, [x20, x6]
	ldr	q0, [sp, #2400]
	str	q0, [sp, #1968]                 ; 16-byte Spill
	ldr	q9, [sp, #2384]
	str	q24, [sp, #2352]
	str	q27, [sp, #2368]
	add	x19, sp, #2352
	ldr	w19, [x19, x6]
	mov	w20, #2                         ; =0x2
	csel	w19, w20, w19, ne
	str	q24, [sp, #2320]
	str	q27, [sp, #2336]
	add	x20, sp, #2320
	str	w19, [x20, x6]
	mov	w6, #6                          ; =0x6
	mov	w19, #5                         ; =0x5
	ldr	q27, [sp, #2336]
	ldr	q24, [sp, #2320]
	b	LBB0_1261
LBB0_408:                               ; %varying.coherent179
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w5, s0
	tst	w5, #0xff
	b.eq	LBB0_424
; %bb.409:                              ; %schedule.5.thread
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q3, [sp, #10544]
	ldr	q5, [sp, #10528]
	ldr	q1, [sp, #10512]
	ldr	q0, [sp, #10496]
	shl.2d	v0, v0, #2
	dup.2d	v4, x10
	add.2d	v6, v4, v0
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d2, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v2
	addv.8b	b0, v0
	fmov	w5, s0
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w5, #0, LBB0_492
; %bb.410:                              ; %else8514
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_493
LBB0_411:                               ; %else8520
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbnz	w5, #2, LBB0_494
LBB0_412:                               ; %else8526
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_495
LBB0_413:                               ; %else8532
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbnz	w5, #4, LBB0_496
LBB0_414:                               ; %else8538
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_497
LBB0_415:                               ; %else8544
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbnz	w5, #6, LBB0_498
LBB0_416:                               ; %else8550
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_418
LBB0_417:                               ; %cond.load8552
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x5, v1[1]
	ld1.s	{ v2 }[3], [x5]
LBB0_418:                               ; %else8556
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q3, [sp, #624]                  ; 16-byte Reload
	bit.16b	v3, v2, v1
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #640]                  ; 16-byte Reload
	bit.16b	v2, v0, v1
	stp	q3, q2, [sp, #624]              ; 32-byte Folded Spill
LBB0_419:                               ; %schedule.6
                                        ;   in Loop: Header=BB0_6 Depth=2
	cbz	w4, LBB0_425
LBB0_420:                               ; %convergence.cascade187.preheader
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w5, #0                          ; =0x0
LBB0_421:                               ; %convergence.cascade187
                                        ;   Parent Loop BB0_5 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d6, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v0, v6
	addv.8b	b1, v1
	fmov	w6, s1
	umaxv.8b	b0, v0
	fmov	w20, s0
	sub	w7, w4, #1
	tst	w6, #0xff
	csel	w7, w7, wzr, ne
	mov	w6, #1                          ; =0x1
	lsl	w19, w6, w7
	and	w6, w19, w0
	tst	w6, #0xff
	cset	w22, ne
	str	q24, [sp, #7312]
	str	q27, [sp, #7328]
	ubfiz	x6, x7, #2, #3
	add	x21, sp, #1, lsl #12            ; =4096
	add	x21, x21, #3216
	ldr	w21, [x21, x6]
	cmp	w21, #2
	cset	w21, eq
	and	w22, w22, w20
	add	x20, sp, #2, lsl #12            ; =8192
	add	x20, x20, #3560
	ldrb	w24, [x20, w7, sxtw]
	and	w23, w24, #0x1
	fmov	s0, w23
	ubfx	w23, w24, #1, #1
	mov.b	v0[1], w23
	ubfx	w23, w24, #2, #1
	mov.b	v0[2], w23
	ubfx	w23, w24, #3, #1
	mov.b	v0[3], w23
	ubfx	w23, w24, #4, #1
	mov.b	v0[4], w23
	ubfx	w23, w24, #5, #1
	mov.b	v0[5], w23
	ubfx	w23, w24, #6, #1
	mov.b	v0[6], w23
	add	x23, sp, #2, lsl #12            ; =8192
	add	x23, x23, #3552
	lsr	w24, w24, #7
	mov.b	v0[7], w24
	ldrb	w24, [x23, w7, sxtw]
	and	w25, w24, #0x1
	fmov	s1, w25
	ubfx	w25, w24, #1, #1
	mov.b	v1[1], w25
	ubfx	w25, w24, #2, #1
	mov.b	v1[2], w25
	ubfx	w25, w24, #3, #1
	mov.b	v1[3], w25
	ubfx	w25, w24, #4, #1
	mov.b	v1[4], w25
	ubfx	w25, w24, #5, #1
	mov.b	v1[5], w25
	ubfx	w25, w24, #6, #1
	mov.b	v1[6], w25
	lsr	w24, w24, #7
	mov.b	v1[7], w24
	orr.8b	v2, v15, v1
	ldr	d3, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v3, v0
	eor.8b	v3, v3, v2
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w24, s3
	ands	w21, w22, w21
	csetm	w22, ne
	bics	w24, w21, w24
	csetm	w25, ne
	dup.8b	v3, w25
	bic.8b	v4, v2, v3
	dup.8b	v5, w22
	bit.8b	v1, v4, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v6
	addv.8b	b1, v1
	str	b1, [x23, w7, sxtw]
	bic.8b	v0, v0, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	str	b0, [x20, w7, sxtw]
	mov	w7, #-1                         ; =0xffffffff
	csinv	w7, w7, w19, eq
	and	w0, w7, w0
	dup.8b	v0, w21
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	dup.8b	v1, w24
	and.8b	v1, v1, v2
	str	q9, [sp, #7280]
	ldr	q2, [sp, #1968]                 ; 16-byte Reload
	str	q2, [sp, #7296]
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #3184
	ldr	w6, [x7, x6]
	csel	w4, w6, w4, ne
	bit.8b	v15, v1, v0
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	fmov	w6, s0
	cmp	w21, #1
	b.ne	LBB0_426
; %bb.422:                              ; %convergence.cascade187
                                        ;   in Loop: Header=BB0_421 Depth=3
	cmp	w4, #0
	ccmp	w5, #6, #2, ne
	b.hi	LBB0_426
; %bb.423:                              ; %convergence.cascade187
                                        ;   in Loop: Header=BB0_421 Depth=3
	add	w5, w5, #1
	tst	w6, #0xff
	b.ne	LBB0_421
	b	LBB0_426
LBB0_424:                               ; %varying.coherent.false185
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	ldp	q3, q1, [sp, #624]              ; 32-byte Folded Reload
	and.16b	v2, v0, v3
	zip1.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v1, v0, v1
	stp	q2, q1, [sp, #624]              ; 32-byte Folded Spill
	cbnz	w4, LBB0_420
LBB0_425:                               ; %schedule.6.convergence.cascade.exit188_crit_edge
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w6, s0
LBB0_426:                               ; %convergence.cascade.exit188
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w6, #0xff
	b.eq	LBB0_4
; %bb.427:                              ; %convergence.target.6.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	add	x5, sp, #2, lsl #12             ; =8192
	add	x5, x5, #2776
	ld1r.2d	{ v0 }, [x5]
	ldp	q2, q1, [sp, #720]              ; 32-byte Folded Reload
	add.2d	v1, v0, v1
	add.2d	v2, v0, v2
	ldp	q4, q3, [sp, #752]              ; 32-byte Folded Reload
	add.2d	v3, v0, v3
	add.2d	v0, v0, v4
	ldr	q4, [sp, #10464]
	ldr	q5, [sp, #10480]
	ldr	q6, [sp, #10432]
	ldr	q7, [sp, #10448]
	mov	b16, v15[2]
	mov.b	v16[4], v15[3]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	bif.16b	v0, v7, v16
	mov	b7, v15[0]
	mov.b	v7[4], v15[1]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	bif.16b	v3, v6, v7
	mov	b6, v15[6]
	mov.b	v6[4], v15[7]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	bif.16b	v2, v5, v6
	mov	b5, v15[4]
	mov.b	v5[4], v15[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	bif.16b	v1, v4, v5
	str	q1, [sp, #10464]
	str	q2, [sp, #10480]
	str	q3, [sp, #10432]
	str	q0, [sp, #10448]
	and.8b	v7, v31, v15
	shl.8b	v0, v7, #7
	cmlt.8b	v0, v0, #0
	umaxv.8b	b1, v0
	fmov	w5, s1
	tbz	w5, #0, LBB0_433
; %bb.428:                              ; %convergence.target.6.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	bic.8b	v16, v15, v31
	shl.8b	v1, v16, #7
	cmlt.8b	v1, v1, #0
	ldr	d2, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w5, s1
	tst	w5, #0xff
	b.eq	LBB0_433
; %bb.429:                              ; %varying.divergent209
                                        ;   in Loop: Header=BB0_6 Depth=2
	cmp	w4, #0
	cset	w5, ne
	sub	w5, w4, w5
	and	w6, w0, #0xff
	lsr	w7, w6, w5
	tst	w7, #0x1
	cset	w7, eq
	cmp	w4, #0
	str	q24, [sp, #2608]
	str	q27, [sp, #2624]
	and	x5, x5, #0x7
	add	x19, sp, #2608
	ldr	w5, [x19, x5, lsl #2]
	csinc	w7, w7, wzr, ne
	cmp	w5, #3
	csinc	w5, w7, wzr, eq
	cmp	w6, #255
	b.ne	LBB0_431
; %bb.430:                              ; %varying.divergent209
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #0, LBB0_431
	b	LBB0_1348
LBB0_431:                               ; %convergence.overflow.resume212
                                        ;   in Loop: Header=BB0_6 Depth=2
	mvn	w6, w0
	rbit	w6, w6
	clz	w6, w6
	mov	w7, #255                        ; =0xff
	bics	wzr, w7, w0
	csel	w7, wzr, w6, eq
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #3560
	ldrb	w20, [x6, w7, uxtw]
	and	w19, w20, #0x1
	fmov	s0, w19
	ubfx	w19, w20, #1, #1
	mov.b	v0[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v0[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v0[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v0[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v0[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v0[6], w19
	add	x19, sp, #2, lsl #12            ; =8192
	add	x19, x19, #3552
	lsr	w20, w20, #7
	mov.b	v0[7], w20
	ldrb	w20, [x19, w7, uxtw]
	and	w21, w20, #0x1
	fmov	s1, w21
	ubfx	w21, w20, #1, #1
	mov.b	v1[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v1[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v1[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v1[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v1[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v1[6], w21
	lsr	w20, w20, #7
	mov.b	v1[7], w20
	cmp	w5, #0
	csetm	w20, ne
	dup.8b	v2, w20
	bit.8b	v0, v15, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	ldr	d3, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x6, w7, uxtw]
	bic.8b	v0, v1, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x19, w7, uxtw]
	cmp	x1, #8
	b.hs	LBB0_1348
; %bb.432:                              ; %ready.overflow.resume214
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v0, v16, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	ldp	q3, q1, [sp, #656]              ; 32-byte Folded Reload
	and.16b	v2, v0, v3
	zip1.8b	v0, v16, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v1, v0, v1
	stp	q2, q1, [sp, #656]              ; 32-byte Folded Spill
	str	q9, [sp, #2576]
	ldr	q0, [sp, #1968]                 ; 16-byte Reload
	str	q0, [sp, #2592]
	ubfiz	x6, x7, #2, #3
	add	x19, sp, #2576
	ldr	w19, [x19, x6]
	cmp	w5, #0
	csel	w19, w4, w19, ne
	csinc	w4, w4, w7, eq
	str	q9, [sp, #2544]
	str	q0, [sp, #2560]
	add	x20, sp, #2544
	str	w19, [x20, x6]
	ldr	q0, [sp, #2560]
	str	q0, [sp, #1968]                 ; 16-byte Spill
	ldr	q9, [sp, #2544]
	str	q24, [sp, #2512]
	str	q27, [sp, #2528]
	add	x19, sp, #2512
	ldr	w19, [x19, x6]
	mov	w20, #3                         ; =0x3
	csel	w19, w20, w19, ne
	str	q24, [sp, #2480]
	str	q27, [sp, #2496]
	add	x20, sp, #2480
	str	w19, [x20, x6]
	mov	w6, #8                          ; =0x8
	mov	w19, #7                         ; =0x7
	ldr	q27, [sp, #2496]
	ldr	q24, [sp, #2480]
	b	LBB0_1261
LBB0_433:                               ; %varying.coherent210
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w5, s0
	tst	w5, #0xff
	b.eq	LBB0_449
; %bb.434:                              ; %schedule.7.thread
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q3, [sp, #10480]
	ldr	q5, [sp, #10464]
	ldr	q1, [sp, #10448]
	ldr	q0, [sp, #10432]
	shl.2d	v0, v0, #2
	dup.2d	v4, x10
	add.2d	v6, v4, v0
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d2, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v2
	addv.8b	b0, v0
	fmov	w5, s0
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w5, #0, LBB0_485
; %bb.435:                              ; %else8563
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_486
LBB0_436:                               ; %else8569
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbnz	w5, #2, LBB0_487
LBB0_437:                               ; %else8575
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_488
LBB0_438:                               ; %else8581
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbnz	w5, #4, LBB0_489
LBB0_439:                               ; %else8587
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_490
LBB0_440:                               ; %else8593
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbnz	w5, #6, LBB0_491
LBB0_441:                               ; %else8599
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_443
LBB0_442:                               ; %cond.load8601
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x5, v1[1]
	ld1.s	{ v2 }[3], [x5]
LBB0_443:                               ; %else8605
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q3, [sp, #656]                  ; 16-byte Reload
	bit.16b	v3, v2, v1
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #672]                  ; 16-byte Reload
	bit.16b	v2, v0, v1
	stp	q3, q2, [sp, #656]              ; 32-byte Folded Spill
LBB0_444:                               ; %schedule.8
                                        ;   in Loop: Header=BB0_6 Depth=2
	cbz	w4, LBB0_450
LBB0_445:                               ; %convergence.cascade218.preheader
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w5, #0                          ; =0x0
LBB0_446:                               ; %convergence.cascade218
                                        ;   Parent Loop BB0_5 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d6, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v0, v6
	addv.8b	b1, v1
	fmov	w6, s1
	umaxv.8b	b0, v0
	fmov	w20, s0
	sub	w7, w4, #1
	tst	w6, #0xff
	csel	w7, w7, wzr, ne
	mov	w6, #1                          ; =0x1
	lsl	w19, w6, w7
	and	w6, w19, w0
	tst	w6, #0xff
	cset	w22, ne
	str	q24, [sp, #7248]
	str	q27, [sp, #7264]
	ubfiz	x6, x7, #2, #3
	add	x21, sp, #1, lsl #12            ; =4096
	add	x21, x21, #3152
	ldr	w21, [x21, x6]
	cmp	w21, #3
	cset	w21, eq
	and	w22, w22, w20
	add	x20, sp, #2, lsl #12            ; =8192
	add	x20, x20, #3560
	ldrb	w24, [x20, w7, sxtw]
	and	w23, w24, #0x1
	fmov	s0, w23
	ubfx	w23, w24, #1, #1
	mov.b	v0[1], w23
	ubfx	w23, w24, #2, #1
	mov.b	v0[2], w23
	ubfx	w23, w24, #3, #1
	mov.b	v0[3], w23
	ubfx	w23, w24, #4, #1
	mov.b	v0[4], w23
	ubfx	w23, w24, #5, #1
	mov.b	v0[5], w23
	ubfx	w23, w24, #6, #1
	mov.b	v0[6], w23
	add	x23, sp, #2, lsl #12            ; =8192
	add	x23, x23, #3552
	lsr	w24, w24, #7
	mov.b	v0[7], w24
	ldrb	w24, [x23, w7, sxtw]
	and	w25, w24, #0x1
	fmov	s1, w25
	ubfx	w25, w24, #1, #1
	mov.b	v1[1], w25
	ubfx	w25, w24, #2, #1
	mov.b	v1[2], w25
	ubfx	w25, w24, #3, #1
	mov.b	v1[3], w25
	ubfx	w25, w24, #4, #1
	mov.b	v1[4], w25
	ubfx	w25, w24, #5, #1
	mov.b	v1[5], w25
	ubfx	w25, w24, #6, #1
	mov.b	v1[6], w25
	lsr	w24, w24, #7
	mov.b	v1[7], w24
	orr.8b	v2, v15, v1
	ldr	d3, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v3, v0
	eor.8b	v3, v3, v2
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w24, s3
	ands	w21, w22, w21
	csetm	w22, ne
	bics	w24, w21, w24
	csetm	w25, ne
	dup.8b	v3, w25
	bic.8b	v4, v2, v3
	dup.8b	v5, w22
	bit.8b	v1, v4, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v6
	addv.8b	b1, v1
	str	b1, [x23, w7, sxtw]
	bic.8b	v0, v0, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	str	b0, [x20, w7, sxtw]
	mov	w7, #-1                         ; =0xffffffff
	csinv	w7, w7, w19, eq
	and	w0, w7, w0
	dup.8b	v0, w21
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	dup.8b	v1, w24
	and.8b	v1, v1, v2
	str	q9, [sp, #7216]
	ldr	q2, [sp, #1968]                 ; 16-byte Reload
	str	q2, [sp, #7232]
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #3120
	ldr	w6, [x7, x6]
	csel	w4, w6, w4, ne
	bit.8b	v15, v1, v0
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	fmov	w6, s0
	cmp	w21, #1
	b.ne	LBB0_451
; %bb.447:                              ; %convergence.cascade218
                                        ;   in Loop: Header=BB0_446 Depth=3
	cmp	w4, #0
	ccmp	w5, #6, #2, ne
	b.hi	LBB0_451
; %bb.448:                              ; %convergence.cascade218
                                        ;   in Loop: Header=BB0_446 Depth=3
	add	w5, w5, #1
	tst	w6, #0xff
	b.ne	LBB0_446
	b	LBB0_451
LBB0_449:                               ; %varying.coherent.false216
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	ldp	q3, q1, [sp, #656]              ; 32-byte Folded Reload
	and.16b	v2, v0, v3
	zip1.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v1, v0, v1
	stp	q2, q1, [sp, #656]              ; 32-byte Folded Spill
	cbnz	w4, LBB0_445
LBB0_450:                               ; %schedule.8.convergence.cascade.exit219_crit_edge
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w6, s0
LBB0_451:                               ; %convergence.cascade.exit219
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w6, #0xff
	b.eq	LBB0_4
; %bb.452:                              ; %convergence.target.8.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	add	x5, sp, #2, lsl #12             ; =8192
	add	x5, x5, #2712
	ld1r.2d	{ v0 }, [x5]
	ldp	q2, q1, [sp, #720]              ; 32-byte Folded Reload
	add.2d	v1, v0, v1
	add.2d	v2, v0, v2
	ldp	q4, q3, [sp, #752]              ; 32-byte Folded Reload
	add.2d	v3, v0, v3
	add.2d	v0, v0, v4
	ldr	q4, [sp, #10400]
	ldr	q5, [sp, #10416]
	ldr	q6, [sp, #10368]
	ldr	q7, [sp, #10384]
	mov	b16, v15[2]
	mov.b	v16[4], v15[3]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	bif.16b	v0, v7, v16
	mov	b7, v15[0]
	mov.b	v7[4], v15[1]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	bif.16b	v3, v6, v7
	mov	b6, v15[6]
	mov.b	v6[4], v15[7]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	bif.16b	v2, v5, v6
	mov	b5, v15[4]
	mov.b	v5[4], v15[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	bif.16b	v1, v4, v5
	str	q1, [sp, #10400]
	str	q2, [sp, #10416]
	str	q3, [sp, #10368]
	str	q0, [sp, #10384]
	and.8b	v7, v31, v15
	shl.8b	v0, v7, #7
	cmlt.8b	v0, v0, #0
	umaxv.8b	b1, v0
	fmov	w5, s1
	tbz	w5, #0, LBB0_458
; %bb.453:                              ; %convergence.target.8.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	bic.8b	v16, v15, v31
	shl.8b	v1, v16, #7
	cmlt.8b	v1, v1, #0
	ldr	d2, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w5, s1
	tst	w5, #0xff
	b.eq	LBB0_458
; %bb.454:                              ; %varying.divergent240
                                        ;   in Loop: Header=BB0_6 Depth=2
	cmp	w4, #0
	cset	w5, ne
	sub	w5, w4, w5
	and	w6, w0, #0xff
	lsr	w7, w6, w5
	tst	w7, #0x1
	cset	w7, eq
	cmp	w4, #0
	str	q24, [sp, #2768]
	str	q27, [sp, #2784]
	and	x5, x5, #0x7
	add	x19, sp, #2768
	ldr	w5, [x19, x5, lsl #2]
	csinc	w7, w7, wzr, ne
	cmp	w5, #4
	csinc	w5, w7, wzr, eq
	cmp	w6, #255
	b.ne	LBB0_456
; %bb.455:                              ; %varying.divergent240
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #0, LBB0_456
	b	LBB0_1348
LBB0_456:                               ; %convergence.overflow.resume243
                                        ;   in Loop: Header=BB0_6 Depth=2
	mvn	w6, w0
	rbit	w6, w6
	clz	w6, w6
	mov	w7, #255                        ; =0xff
	bics	wzr, w7, w0
	csel	w7, wzr, w6, eq
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #3560
	ldrb	w20, [x6, w7, uxtw]
	and	w19, w20, #0x1
	fmov	s0, w19
	ubfx	w19, w20, #1, #1
	mov.b	v0[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v0[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v0[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v0[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v0[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v0[6], w19
	add	x19, sp, #2, lsl #12            ; =8192
	add	x19, x19, #3552
	lsr	w20, w20, #7
	mov.b	v0[7], w20
	ldrb	w20, [x19, w7, uxtw]
	and	w21, w20, #0x1
	fmov	s1, w21
	ubfx	w21, w20, #1, #1
	mov.b	v1[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v1[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v1[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v1[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v1[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v1[6], w21
	lsr	w20, w20, #7
	mov.b	v1[7], w20
	cmp	w5, #0
	csetm	w20, ne
	dup.8b	v2, w20
	bit.8b	v0, v15, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	ldr	d3, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x6, w7, uxtw]
	bic.8b	v0, v1, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x19, w7, uxtw]
	cmp	x1, #8
	b.hs	LBB0_1348
; %bb.457:                              ; %ready.overflow.resume245
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v0, v16, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	ldp	q3, q1, [sp, #688]              ; 32-byte Folded Reload
	and.16b	v2, v0, v3
	zip1.8b	v0, v16, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v1, v0, v1
	stp	q2, q1, [sp, #688]              ; 32-byte Folded Spill
	str	q9, [sp, #2736]
	ldr	q0, [sp, #1968]                 ; 16-byte Reload
	str	q0, [sp, #2752]
	ubfiz	x6, x7, #2, #3
	add	x19, sp, #2736
	ldr	w19, [x19, x6]
	cmp	w5, #0
	csel	w19, w4, w19, ne
	csinc	w4, w4, w7, eq
	str	q9, [sp, #2704]
	str	q0, [sp, #2720]
	add	x20, sp, #2704
	str	w19, [x20, x6]
	ldr	q0, [sp, #2720]
	str	q0, [sp, #1968]                 ; 16-byte Spill
	ldr	q9, [sp, #2704]
	str	q24, [sp, #2672]
	str	q27, [sp, #2688]
	add	x19, sp, #2672
	ldr	w19, [x19, x6]
	mov	w20, #4                         ; =0x4
	csel	w19, w20, w19, ne
	str	q24, [sp, #2640]
	str	q27, [sp, #2656]
	add	x20, sp, #2640
	str	w19, [x20, x6]
	mov	w6, #10                         ; =0xa
	mov	w19, #9                         ; =0x9
	ldr	q27, [sp, #2656]
	ldr	q24, [sp, #2640]
	b	LBB0_1261
LBB0_458:                               ; %varying.coherent241
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w5, s0
	tst	w5, #0xff
	b.eq	LBB0_474
; %bb.459:                              ; %schedule.9.thread
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q3, [sp, #10416]
	ldr	q5, [sp, #10400]
	ldr	q1, [sp, #10384]
	ldr	q0, [sp, #10368]
	shl.2d	v0, v0, #2
	dup.2d	v4, x10
	add.2d	v6, v4, v0
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d2, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v2
	addv.8b	b0, v0
	fmov	w5, s0
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w5, #0, LBB0_478
; %bb.460:                              ; %else8612
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_479
LBB0_461:                               ; %else8618
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbnz	w5, #2, LBB0_480
LBB0_462:                               ; %else8624
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_481
LBB0_463:                               ; %else8630
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbnz	w5, #4, LBB0_482
LBB0_464:                               ; %else8636
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_483
LBB0_465:                               ; %else8642
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbnz	w5, #6, LBB0_484
LBB0_466:                               ; %else8648
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_468
LBB0_467:                               ; %cond.load8650
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x5, v1[1]
	ld1.s	{ v2 }[3], [x5]
LBB0_468:                               ; %else8654
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q3, [sp, #688]                  ; 16-byte Reload
	bit.16b	v3, v2, v1
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #704]                  ; 16-byte Reload
	bit.16b	v2, v0, v1
	stp	q3, q2, [sp, #688]              ; 32-byte Folded Spill
LBB0_469:                               ; %schedule.10
                                        ;   in Loop: Header=BB0_6 Depth=2
	cbz	w4, LBB0_475
LBB0_470:                               ; %convergence.cascade249.preheader
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w5, #0                          ; =0x0
LBB0_471:                               ; %convergence.cascade249
                                        ;   Parent Loop BB0_5 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d6, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v0, v6
	addv.8b	b1, v1
	fmov	w6, s1
	umaxv.8b	b0, v0
	fmov	w20, s0
	sub	w7, w4, #1
	tst	w6, #0xff
	csel	w7, w7, wzr, ne
	mov	w6, #1                          ; =0x1
	lsl	w19, w6, w7
	and	w6, w19, w0
	tst	w6, #0xff
	cset	w22, ne
	str	q24, [sp, #7184]
	str	q27, [sp, #7200]
	ubfiz	x6, x7, #2, #3
	add	x21, sp, #1, lsl #12            ; =4096
	add	x21, x21, #3088
	ldr	w21, [x21, x6]
	cmp	w21, #4
	cset	w21, eq
	and	w22, w22, w20
	add	x20, sp, #2, lsl #12            ; =8192
	add	x20, x20, #3560
	ldrb	w24, [x20, w7, sxtw]
	and	w23, w24, #0x1
	fmov	s0, w23
	ubfx	w23, w24, #1, #1
	mov.b	v0[1], w23
	ubfx	w23, w24, #2, #1
	mov.b	v0[2], w23
	ubfx	w23, w24, #3, #1
	mov.b	v0[3], w23
	ubfx	w23, w24, #4, #1
	mov.b	v0[4], w23
	ubfx	w23, w24, #5, #1
	mov.b	v0[5], w23
	ubfx	w23, w24, #6, #1
	mov.b	v0[6], w23
	add	x23, sp, #2, lsl #12            ; =8192
	add	x23, x23, #3552
	lsr	w24, w24, #7
	mov.b	v0[7], w24
	ldrb	w24, [x23, w7, sxtw]
	and	w25, w24, #0x1
	fmov	s1, w25
	ubfx	w25, w24, #1, #1
	mov.b	v1[1], w25
	ubfx	w25, w24, #2, #1
	mov.b	v1[2], w25
	ubfx	w25, w24, #3, #1
	mov.b	v1[3], w25
	ubfx	w25, w24, #4, #1
	mov.b	v1[4], w25
	ubfx	w25, w24, #5, #1
	mov.b	v1[5], w25
	ubfx	w25, w24, #6, #1
	mov.b	v1[6], w25
	lsr	w24, w24, #7
	mov.b	v1[7], w24
	orr.8b	v2, v15, v1
	ldr	d3, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v3, v0
	eor.8b	v3, v3, v2
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w24, s3
	ands	w21, w22, w21
	csetm	w22, ne
	bics	w24, w21, w24
	csetm	w25, ne
	dup.8b	v3, w25
	bic.8b	v4, v2, v3
	dup.8b	v5, w22
	bit.8b	v1, v4, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v6
	addv.8b	b1, v1
	str	b1, [x23, w7, sxtw]
	bic.8b	v0, v0, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	str	b0, [x20, w7, sxtw]
	mov	w7, #-1                         ; =0xffffffff
	csinv	w7, w7, w19, eq
	and	w0, w7, w0
	dup.8b	v0, w21
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	dup.8b	v1, w24
	and.8b	v1, v1, v2
	str	q9, [sp, #7152]
	ldr	q2, [sp, #1968]                 ; 16-byte Reload
	str	q2, [sp, #7168]
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #3056
	ldr	w6, [x7, x6]
	csel	w4, w6, w4, ne
	bit.8b	v15, v1, v0
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	fmov	w6, s0
	cmp	w21, #1
	b.ne	LBB0_476
; %bb.472:                              ; %convergence.cascade249
                                        ;   in Loop: Header=BB0_471 Depth=3
	cmp	w4, #0
	ccmp	w5, #6, #2, ne
	b.hi	LBB0_476
; %bb.473:                              ; %convergence.cascade249
                                        ;   in Loop: Header=BB0_471 Depth=3
	add	w5, w5, #1
	tst	w6, #0xff
	b.ne	LBB0_471
	b	LBB0_476
LBB0_474:                               ; %varying.coherent.false247
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	ldp	q3, q1, [sp, #688]              ; 32-byte Folded Reload
	and.16b	v2, v0, v3
	zip1.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v1, v0, v1
	stp	q2, q1, [sp, #688]              ; 32-byte Folded Spill
	cbnz	w4, LBB0_470
LBB0_475:                               ; %schedule.10.convergence.cascade.exit250_crit_edge
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w6, s0
LBB0_476:                               ; %convergence.cascade.exit250
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w6, #0xff
	b.eq	LBB0_4
; %bb.477:                              ; %convergence.target.10.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	b0, v15[6]
	mov.b	v0[4], v15[7]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmge.2d	v0, v0, #0
	ldr	q1, [sp, #1760]                 ; 16-byte Reload
	and.16b	v1, v0, v1
	str	q1, [sp, #1760]                 ; 16-byte Spill
	mov	b0, v15[4]
	mov.b	v0[4], v15[5]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmge.2d	v0, v0, #0
	and.16b	v8, v0, v8
	mov	b0, v15[2]
	mov.b	v0[4], v15[3]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmge.2d	v0, v0, #0
	mov	b1, v15[0]
	mov.b	v1[4], v15[1]
	ldr	q2, [sp, #1792]                 ; 16-byte Reload
	and.16b	v2, v0, v2
	str	q2, [sp, #1792]                 ; 16-byte Spill
	ushll.2d	v0, v1, #0
	shl.2d	v0, v0, #63
	cmge.2d	v0, v0, #0
	ldr	q1, [sp, #1776]                 ; 16-byte Reload
	and.16b	v1, v0, v1
	str	q1, [sp, #1776]                 ; 16-byte Spill
	zip1.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	mov	w5, #62154                      ; =0xf2ca
	movk	w5, #61769, lsl #16
	dup.4s	v2, w5
	ldr	q3, [sp, #1232]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #1232]                 ; 16-byte Spill
	ldr	q3, [sp, #1248]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #1248]                 ; 16-byte Spill
	ldr	q3, [sp, #1264]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #1264]                 ; 16-byte Spill
	ldr	q3, [sp, #1280]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #1280]                 ; 16-byte Spill
	ldr	q2, [sp, #1552]                 ; 16-byte Reload
	bic.16b	v2, v2, v1
	str	q2, [sp, #1552]                 ; 16-byte Spill
	ldr	q2, [sp, #1568]                 ; 16-byte Reload
	bic.16b	v2, v2, v0
	str	q2, [sp, #1568]                 ; 16-byte Spill
	ldr	q2, [sp, #1296]                 ; 16-byte Reload
	bic.16b	v2, v2, v1
	str	q2, [sp, #1296]                 ; 16-byte Spill
	ldr	q2, [sp, #1312]                 ; 16-byte Reload
	bic.16b	v2, v2, v0
	str	q2, [sp, #1312]                 ; 16-byte Spill
	ldr	q2, [sp, #1040]                 ; 16-byte Reload
	bic.16b	v2, v2, v1
	str	q2, [sp, #1040]                 ; 16-byte Spill
	ldr	q2, [sp, #1056]                 ; 16-byte Reload
	bic.16b	v2, v2, v0
	str	q2, [sp, #1056]                 ; 16-byte Spill
	ldr	q2, [sp, #1072]                 ; 16-byte Reload
	bic.16b	v2, v2, v1
	str	q2, [sp, #1072]                 ; 16-byte Spill
	ldr	q2, [sp, #1088]                 ; 16-byte Reload
	bic.16b	v2, v2, v0
	str	q2, [sp, #1088]                 ; 16-byte Spill
	ldr	q2, [sp, #1104]                 ; 16-byte Reload
	bic.16b	v2, v2, v1
	str	q2, [sp, #1104]                 ; 16-byte Spill
	ldr	q2, [sp, #1120]                 ; 16-byte Reload
	bic.16b	v2, v2, v0
	str	q2, [sp, #1120]                 ; 16-byte Spill
	ldr	q2, [sp, #1136]                 ; 16-byte Reload
	bic.16b	v2, v2, v1
	str	q2, [sp, #1136]                 ; 16-byte Spill
	ldr	q2, [sp, #1152]                 ; 16-byte Reload
	bic.16b	v2, v2, v0
	str	q2, [sp, #1152]                 ; 16-byte Spill
	ldr	q2, [sp, #1168]                 ; 16-byte Reload
	bic.16b	v2, v2, v1
	str	q2, [sp, #1168]                 ; 16-byte Spill
	ldr	q2, [sp, #1184]                 ; 16-byte Reload
	bic.16b	v2, v2, v0
	str	q2, [sp, #1184]                 ; 16-byte Spill
	ldr	q2, [sp, #1200]                 ; 16-byte Reload
	bic.16b	v2, v2, v1
	str	q2, [sp, #1200]                 ; 16-byte Spill
	ldr	q1, [sp, #1216]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #1216]                 ; 16-byte Spill
	b	LBB0_514
LBB0_478:                               ; %cond.load8608
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d6
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_461
LBB0_479:                               ; %cond.load8614
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v6[1]
	ld1.s	{ v0 }[1], [x6]
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbz	w5, #2, LBB0_462
LBB0_480:                               ; %cond.load8620
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_463
LBB0_481:                               ; %cond.load8626
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbz	w5, #4, LBB0_464
LBB0_482:                               ; %cond.load8632
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[0], [x6]
	tbz	w5, #5, LBB0_465
LBB0_483:                               ; %cond.load8638
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[1], [x6]
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbz	w5, #6, LBB0_466
LBB0_484:                               ; %cond.load8644
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[2], [x6]
	tbnz	w5, #7, LBB0_467
	b	LBB0_468
LBB0_485:                               ; %cond.load8559
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d6
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_436
LBB0_486:                               ; %cond.load8565
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v6[1]
	ld1.s	{ v0 }[1], [x6]
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbz	w5, #2, LBB0_437
LBB0_487:                               ; %cond.load8571
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_438
LBB0_488:                               ; %cond.load8577
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbz	w5, #4, LBB0_439
LBB0_489:                               ; %cond.load8583
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[0], [x6]
	tbz	w5, #5, LBB0_440
LBB0_490:                               ; %cond.load8589
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[1], [x6]
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbz	w5, #6, LBB0_441
LBB0_491:                               ; %cond.load8595
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[2], [x6]
	tbnz	w5, #7, LBB0_442
	b	LBB0_443
LBB0_492:                               ; %cond.load8510
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d6
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_411
LBB0_493:                               ; %cond.load8516
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v6[1]
	ld1.s	{ v0 }[1], [x6]
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbz	w5, #2, LBB0_412
LBB0_494:                               ; %cond.load8522
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_413
LBB0_495:                               ; %cond.load8528
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbz	w5, #4, LBB0_414
LBB0_496:                               ; %cond.load8534
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[0], [x6]
	tbz	w5, #5, LBB0_415
LBB0_497:                               ; %cond.load8540
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[1], [x6]
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbz	w5, #6, LBB0_416
LBB0_498:                               ; %cond.load8546
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[2], [x6]
	tbnz	w5, #7, LBB0_417
	b	LBB0_418
LBB0_499:                               ; %cond.load8461
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d6
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_300
LBB0_500:                               ; %cond.load8467
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v6[1]
	ld1.s	{ v0 }[1], [x6]
	shl.2d	v1, v1, #2
	add.2d	v1, v4, v1
	tbz	w5, #2, LBB0_301
LBB0_501:                               ; %cond.load8473
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_302
LBB0_502:                               ; %cond.load8479
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	shl.2d	v1, v5, #2
	add.2d	v1, v4, v1
	tbz	w5, #4, LBB0_303
LBB0_503:                               ; %cond.load8485
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[0], [x6]
	tbz	w5, #5, LBB0_304
LBB0_504:                               ; %cond.load8491
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v2 }[1], [x6]
	shl.2d	v1, v3, #2
	add.2d	v1, v4, v1
	tbz	w5, #6, LBB0_305
LBB0_505:                               ; %cond.load8497
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v2 }[2], [x6]
	tbnz	w5, #7, LBB0_306
	b	LBB0_307
LBB0_506:                               ; %varying.coherent.false
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	ldp	q3, q1, [sp, #96]               ; 32-byte Folded Reload
	and.16b	v2, v0, v3
	zip1.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v1, v0, v1
	stp	q2, q1, [sp, #96]               ; 32-byte Folded Spill
	mov	w2, #2                          ; =0x2
	mov	w3, #1                          ; =0x1
	tst	w5, #0xff
	ldr	q25, [sp, #1728]                ; 16-byte Reload
	b.ne	LBB0_183
	b	LBB0_4
LBB0_507:                               ; %cond.load8412
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x3, d5
	ldr	s0, [x3]
	tbz	w2, #1, LBB0_281
LBB0_508:                               ; %cond.load8418
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x3, v5[1]
	ld1.s	{ v0 }[1], [x3]
	shl.2d	v1, v1, #2
	add.2d	v1, v18, v1
	tbz	w2, #2, LBB0_282
LBB0_509:                               ; %cond.load8424
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x3, d1
	ld1.s	{ v0 }[2], [x3]
	tbz	w2, #3, LBB0_283
LBB0_510:                               ; %cond.load8430
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x3, v1[1]
	ld1.s	{ v0 }[3], [x3]
	shl.2d	v1, v4, #2
	add.2d	v1, v18, v1
	tbz	w2, #4, LBB0_284
LBB0_511:                               ; %cond.load8436
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x3, d1
	ld1.s	{ v2 }[0], [x3]
	tbz	w2, #5, LBB0_285
LBB0_512:                               ; %cond.load8442
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x3, v1[1]
	ld1.s	{ v2 }[1], [x3]
	shl.2d	v1, v3, #2
	add.2d	v1, v18, v1
	tbz	w2, #6, LBB0_286
LBB0_513:                               ; %cond.load8448
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x3, d1
	ld1.s	{ v2 }[2], [x3]
	tbnz	w2, #7, LBB0_287
	b	LBB0_288
LBB0_514:                               ; %schedule.11
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d4, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v4
	addv.8b	b0, v0
	fmov	w6, s0
	mov	w5, #2                          ; =0x2
	dup.2d	v0, x5
	ldr	q1, [sp, #1792]                 ; 16-byte Reload
	cmgt.2d	v1, v0, v1
	ldr	q2, [sp, #1776]                 ; 16-byte Reload
	cmgt.2d	v2, v0, v2
	uzp1.4s	v1, v2, v1
	cmgt.2d	v2, v0, v8
	ldr	q3, [sp, #1760]                 ; 16-byte Reload
	cmgt.2d	v3, v0, v3
	uzp1.4s	v2, v2, v3
	uzp1.8h	v1, v1, v2
	xtn.8b	v1, v1
	and.8b	v7, v15, v1
	shl.8b	v1, v7, #7
	cmlt.8b	v1, v1, #0
	and.8b	v2, v1, v4
	addv.8b	b2, v2
	fmov	w5, s2
	umaxv.8b	b1, v1
	fmov	w7, s1
	tbz	w7, #0, LBB0_520
; %bb.515:                              ; %schedule.11
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #1792]                 ; 16-byte Reload
	cmge.2d	v1, v1, v0
	ldr	q2, [sp, #1776]                 ; 16-byte Reload
	cmge.2d	v2, v2, v0
	uzp1.4s	v1, v2, v1
	cmge.2d	v2, v8, v0
	ldr	q3, [sp, #1760]                 ; 16-byte Reload
	cmge.2d	v0, v3, v0
	uzp1.4s	v0, v2, v0
	uzp1.8h	v0, v1, v0
	xtn.8b	v0, v0
	and.8b	v16, v15, v0
	shl.8b	v0, v16, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w7, s0
	tst	w7, #0xff
	b.eq	LBB0_520
; %bb.516:                              ; %varying.divergent266
                                        ;   in Loop: Header=BB0_6 Depth=2
	cmp	w4, #0
	cset	w5, ne
	sub	w5, w4, w5
	and	w6, w0, #0xff
	lsr	w7, w6, w5
	tst	w7, #0x1
	cset	w7, eq
	cmp	w4, #0
	str	q24, [sp, #2928]
	str	q27, [sp, #2944]
	and	x5, x5, #0x7
	add	x19, sp, #2928
	ldr	w5, [x19, x5, lsl #2]
	csinc	w7, w7, wzr, ne
	cmp	w5, #5
	csinc	w5, w7, wzr, eq
	cmp	w6, #255
	b.ne	LBB0_518
; %bb.517:                              ; %varying.divergent266
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #0, LBB0_518
	b	LBB0_1348
LBB0_518:                               ; %convergence.overflow.resume269
                                        ;   in Loop: Header=BB0_6 Depth=2
	mvn	w6, w0
	rbit	w6, w6
	clz	w6, w6
	mov	w7, #255                        ; =0xff
	bics	wzr, w7, w0
	csel	w7, wzr, w6, eq
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #3560
	ldrb	w20, [x6, w7, uxtw]
	and	w19, w20, #0x1
	fmov	s0, w19
	ubfx	w19, w20, #1, #1
	mov.b	v0[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v0[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v0[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v0[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v0[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v0[6], w19
	add	x19, sp, #2, lsl #12            ; =8192
	add	x19, x19, #3552
	lsr	w20, w20, #7
	mov.b	v0[7], w20
	ldrb	w20, [x19, w7, uxtw]
	and	w21, w20, #0x1
	fmov	s1, w21
	ubfx	w21, w20, #1, #1
	mov.b	v1[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v1[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v1[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v1[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v1[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v1[6], w21
	lsr	w20, w20, #7
	mov.b	v1[7], w20
	cmp	w5, #0
	csetm	w20, ne
	dup.8b	v2, w20
	bit.8b	v0, v15, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	ldr	d3, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x6, w7, uxtw]
	bic.8b	v0, v1, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x19, w7, uxtw]
	cmp	x1, #8
	b.hs	LBB0_1348
; %bb.519:                              ; %ready.overflow.resume271
                                        ;   in Loop: Header=BB0_6 Depth=2
	str	q9, [sp, #2896]
	ldr	q0, [sp, #1968]                 ; 16-byte Reload
	str	q0, [sp, #2912]
	ubfiz	x6, x7, #2, #3
	add	x19, sp, #2896
	ldr	w19, [x19, x6]
	cmp	w5, #0
	csel	w19, w4, w19, ne
	csinc	w4, w4, w7, eq
	str	q9, [sp, #2864]
	str	q0, [sp, #2880]
	add	x20, sp, #2864
	str	w19, [x20, x6]
	ldr	q0, [sp, #2880]
	str	q0, [sp, #1968]                 ; 16-byte Spill
	ldr	q9, [sp, #2864]
	str	q24, [sp, #2832]
	str	q27, [sp, #2848]
	add	x19, sp, #2832
	ldr	w19, [x19, x6]
	mov	w20, #5                         ; =0x5
	csel	w19, w20, w19, ne
	str	q24, [sp, #2800]
	str	q27, [sp, #2816]
	add	x20, sp, #2800
	str	w19, [x20, x6]
	mov	w6, #41                         ; =0x29
	mov	w19, #12                        ; =0xc
	ldr	q27, [sp, #2816]
	ldr	q24, [sp, #2800]
	b	LBB0_1261
LBB0_520:                               ; %varying.coherent267
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w5, #0xff
	b.eq	LBB0_724
; %bb.521:                              ; %varying.coherent.true272
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w5, #0                          ; =0x0
	tst	w6, #0xff
	b.eq	LBB0_4
LBB0_522:                               ; %schedule.12
                                        ;   in Loop: Header=BB0_6 Depth=2
	str	q24, [sp, #1664]                ; 16-byte Spill
	str	q27, [sp, #1680]                ; 16-byte Spill
	str	q9, [sp, #1456]                 ; 16-byte Spill
	str	q31, [sp, #1472]                ; 16-byte Spill
	str	q23, [sp, #1744]                ; 16-byte Spill
	ldr	q9, [sp, #1936]                 ; 16-byte Reload
	str	q11, [sp, #1536]                ; 16-byte Spill
	str	q26, [sp, #1696]                ; 16-byte Spill
	str	q10, [sp, #1504]                ; 16-byte Spill
	str	q22, [sp, #1712]                ; 16-byte Spill
	str	q29, [sp, #1648]                ; 16-byte Spill
	str	q25, [sp, #1728]                ; 16-byte Spill
	str	q12, [sp, #1520]                ; 16-byte Spill
	fmov	x6, d8
	add	x6, x6, x6, lsl #1
	fmov	d3, x6
	str	q8, [sp, #1488]                 ; 16-byte Spill
	mov.d	x6, v8[1]
	add	x6, x6, x6, lsl #1
	mov.d	v3[1], x6
	ldr	q0, [sp, #1760]                 ; 16-byte Reload
	fmov	x6, d0
	add	x6, x6, x6, lsl #1
	mov.d	x7, v0[1]
	fmov	d5, x6
	add	x6, x7, x7, lsl #1
	mov.d	v5[1], x6
	ldr	q0, [sp, #1776]                 ; 16-byte Reload
	fmov	x6, d0
	add	x6, x6, x6, lsl #1
	fmov	d18, x6
	mov.d	x6, v0[1]
	add	x6, x6, x6, lsl #1
	mov.d	v18[1], x6
	ldr	q0, [sp, #1792]                 ; 16-byte Reload
	fmov	x6, d0
	add	x6, x6, x6, lsl #1
	fmov	d19, x6
	mov.d	x6, v0[1]
	add	x6, x6, x6, lsl #1
	mov.d	v19[1], x6
	mov	b0, v15[2]
	mov.b	v0[4], v15[3]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v2, v0, #0
	and.16b	v16, v2, v19
	mov	b0, v15[0]
	mov.b	v0[4], v15[1]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	and.16b	v27, v0, v18
	mov	b1, v15[6]
	mov.b	v1[4], v15[7]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v4, v1, #0
	and.16b	v10, v4, v5
	mov	b1, v15[4]
	mov.b	v1[4], v15[5]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v6, v1, #0
	and.16b	v17, v6, v3
	shl.8b	v1, v15, #7
	cmlt.8b	v7, v1, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v7, v1
	ldr	q20, [sp, #11280]
	ldr	q22, [sp, #11264]
	ldr	q23, [sp, #11312]
	ldr	q24, [sp, #11296]
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #3056
	ld1r.2d	{ v25 }, [x6]
	addv.8b	b21, v1
	add.2d	v1, v25, v24
	add.2d	v23, v25, v23
	add.2d	v22, v25, v22
	add.2d	v20, v25, v20
	ldr	q24, [sp, #10352]
	ldr	q25, [sp, #10304]
	ldr	q26, [sp, #10320]
	ldr	q28, [sp, #10336]
	bif.16b	v3, v28, v6
	bif.16b	v19, v26, v2
	bif.16b	v18, v25, v0
	bif.16b	v5, v24, v4
	str	q5, [sp, #10352]
	str	q18, [sp, #10304]
	str	q19, [sp, #10320]
	mov.d	x6, v20[1]
	fmov	x7, d20
	add	x7, x7, x7, lsl #2
	fmov	d28, x7
	add	x6, x6, x6, lsl #2
	mov.d	v28[1], x6
	mov.d	x6, v22[1]
	fmov	x7, d22
	add	x7, x7, x7, lsl #2
	fmov	d11, x7
	add	x6, x6, x6, lsl #2
	mov.d	v11[1], x6
	mov.d	x6, v23[1]
	fmov	x7, d23
	add	x7, x7, x7, lsl #2
	fmov	d18, x7
	add	x6, x6, x6, lsl #2
	mov.d	v18[1], x6
	mov.d	x6, v1[1]
	fmov	x7, d1
	add	x7, x7, x7, lsl #2
	fmov	d19, x7
	add	x6, x6, x6, lsl #2
	mov.d	v19[1], x6
	str	q3, [sp, #10336]
	add.2d	v22, v19, v17
	add.2d	v1, v18, v10
	add.2d	v5, v11, v27
	add.2d	v20, v28, v16
	ldr	q24, [sp, #10272]
	ldr	q3, [sp, #10288]
	ldr	q23, [sp, #10240]
	ldr	q25, [sp, #10256]
	bsl.16b	v2, v20, v25
	bit.16b	v3, v1, v4
	mov.16b	v4, v6
	bsl.16b	v4, v22, v24
	mov.d	x6, v1[1]
	fmov	x7, d1
	add	x7, x7, x7, lsl #2
	lsl	x19, x7, #2
	fmov	d24, x7
	add	x6, x6, x6, lsl #2
	mov.d	v24[1], x6
	mov.d	x7, v22[1]
	fmov	x20, d22
	add	x20, x20, x20, lsl #2
	lsl	x21, x20, #2
	fmov	d25, x20
	add	x7, x7, x7, lsl #2
	mov.d	v25[1], x7
	bsl.16b	v0, v5, v23
	mov.d	x20, v20[1]
	fmov	x22, d20
	add	x22, x22, x22, lsl #2
	lsl	x23, x22, #2
	fmov	d26, x22
	add	x20, x20, x20, lsl #2
	mov.d	v26[1], x20
	mov.d	x22, v5[1]
	str	q4, [sp, #10272]
	fmov	x24, d5
	add	x24, x24, x24, lsl #2
	lsl	x25, x24, #2
	fmov	d29, x24
	add	x22, x22, x22, lsl #2
	mov.d	v29[1], x22
	fmov	d5, x25
	lsl	x22, x22, #2
	mov.d	v5[1], x22
	fmov	d1, x23
	lsl	x20, x20, #2
	mov.d	v1[1], x20
	fmov	d4, x21
	lsl	x7, x7, #2
	mov.d	v4[1], x7
	fmov	d6, x19
	lsl	x6, x6, #2
	mov.d	v6[1], x6
	dup.2d	v22, x11
	fmov	w6, s21
	str	q3, [sp, #10288]
	str	q0, [sp, #10240]
	str	q2, [sp, #10256]
	add.2d	v3, v22, v6
	add.2d	v4, v22, v4
	add.2d	v1, v22, v1
	add.2d	v5, v22, v5
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w6, #0, LBB0_638
; %bb.523:                              ; %else7248
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #1, LBB0_639
LBB0_524:                               ; %else7254
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #2, LBB0_640
LBB0_525:                               ; %else7260
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #3, LBB0_641
LBB0_526:                               ; %else7266
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #4, LBB0_642
LBB0_527:                               ; %else7272
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #5, LBB0_643
LBB0_528:                               ; %else7278
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #6, LBB0_644
LBB0_529:                               ; %else7284
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w6, #7, LBB0_531
LBB0_530:                               ; %cond.load7286
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v3[1]
	ld1.s	{ v2 }[3], [x6]
LBB0_531:                               ; %else7290
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #10224]
	ldr	q3, [sp, #10208]
	fmov	w6, s21
	zip1.8b	v4, v15, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bif.16b	v0, v3, v4
	zip2.8b	v3, v15, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v2, v3
	str	q1, [sp, #10224]
	str	q0, [sp, #10208]
	dup.2d	v20, x3
	add.2d	v0, v26, v20
	add.2d	v1, v29, v20
	add.2d	v2, v25, v20
	add.2d	v3, v24, v20
	shl.2d	v3, v3, #2
	shl.2d	v2, v2, #2
	shl.2d	v4, v1, #2
	shl.2d	v0, v0, #2
	add.2d	v1, v22, v0
	add.2d	v5, v22, v4
	add.2d	v4, v22, v2
	add.2d	v3, v22, v3
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w6, #0, LBB0_645
; %bb.532:                              ; %else7297
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #1, LBB0_646
LBB0_533:                               ; %else7303
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #2, LBB0_647
LBB0_534:                               ; %else7309
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #3, LBB0_648
LBB0_535:                               ; %else7315
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #4, LBB0_649
LBB0_536:                               ; %else7321
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #5, LBB0_650
LBB0_537:                               ; %else7327
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #6, LBB0_651
LBB0_538:                               ; %else7333
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w6, #7, LBB0_540
LBB0_539:                               ; %cond.load7335
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v3[1]
	ld1.s	{ v2 }[3], [x6]
LBB0_540:                               ; %else7339
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #10192]
	ldr	q3, [sp, #10176]
	fmov	w6, s21
	zip1.8b	v4, v15, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bif.16b	v0, v3, v4
	zip2.8b	v3, v15, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v2, v3
	str	q1, [sp, #10192]
	str	q0, [sp, #10176]
	dup.2d	v23, x2
	add.2d	v0, v26, v23
	add.2d	v1, v29, v23
	add.2d	v2, v25, v23
	add.2d	v3, v24, v23
	shl.2d	v3, v3, #2
	shl.2d	v2, v2, #2
	shl.2d	v4, v1, #2
	shl.2d	v0, v0, #2
	add.2d	v1, v22, v0
	add.2d	v5, v22, v4
	add.2d	v4, v22, v2
	add.2d	v3, v22, v3
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w6, #0, LBB0_652
; %bb.541:                              ; %else7346
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #1, LBB0_653
LBB0_542:                               ; %else7352
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #2, LBB0_654
LBB0_543:                               ; %else7358
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #3, LBB0_655
LBB0_544:                               ; %else7364
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #4, LBB0_656
LBB0_545:                               ; %else7370
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #5, LBB0_657
LBB0_546:                               ; %else7376
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #6, LBB0_658
LBB0_547:                               ; %else7382
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w6, #7, LBB0_549
LBB0_548:                               ; %cond.load7384
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v3[1]
	ld1.s	{ v2 }[3], [x6]
LBB0_549:                               ; %else7388
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #10160]
	ldr	q3, [sp, #10144]
	fmov	w6, s21
	zip1.8b	v4, v15, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bif.16b	v0, v3, v4
	zip2.8b	v3, v15, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v2, v3
	str	q1, [sp, #10160]
	str	q0, [sp, #10144]
	add	x7, sp, #2, lsl #12             ; =8192
	add	x7, x7, #2776
	ld1r.2d	{ v0 }, [x7]
	add.2d	v1, v0, v24
	add.2d	v2, v0, v25
	add.2d	v3, v0, v26
	add.2d	v0, v0, v29
	shl.2d	v0, v0, #2
	shl.2d	v5, v3, #2
	shl.2d	v2, v2, #2
	shl.2d	v1, v1, #2
	add.2d	v3, v22, v1
	add.2d	v4, v22, v2
	add.2d	v1, v22, v5
	add.2d	v5, v22, v0
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w6, #0, LBB0_659
; %bb.550:                              ; %else7395
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #1, LBB0_660
LBB0_551:                               ; %else7401
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #2, LBB0_661
LBB0_552:                               ; %else7407
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #3, LBB0_662
LBB0_553:                               ; %else7413
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #4, LBB0_663
LBB0_554:                               ; %else7419
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #5, LBB0_664
LBB0_555:                               ; %else7425
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #6, LBB0_665
LBB0_556:                               ; %else7431
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w6, #7, LBB0_558
LBB0_557:                               ; %cond.load7433
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v3[1]
	ld1.s	{ v2 }[3], [x6]
LBB0_558:                               ; %else7437
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #10128]
	ldr	q3, [sp, #10112]
	fmov	w6, s21
	zip1.8b	v4, v15, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bif.16b	v0, v3, v4
	zip2.8b	v3, v15, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v2, v3
	str	q1, [sp, #10128]
	str	q0, [sp, #10112]
	add	x7, sp, #2, lsl #12             ; =8192
	add	x7, x7, #2712
	ld1r.2d	{ v0 }, [x7]
	add.2d	v1, v0, v24
	add.2d	v2, v0, v25
	add.2d	v3, v0, v26
	add.2d	v0, v0, v29
	shl.2d	v0, v0, #2
	shl.2d	v5, v3, #2
	shl.2d	v2, v2, #2
	shl.2d	v1, v1, #2
	add.2d	v3, v22, v1
	add.2d	v4, v22, v2
	add.2d	v1, v22, v5
	add.2d	v5, v22, v0
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w6, #0, LBB0_666
; %bb.559:                              ; %else7444
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #1, LBB0_667
LBB0_560:                               ; %else7450
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #2, LBB0_668
LBB0_561:                               ; %else7456
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #3, LBB0_669
LBB0_562:                               ; %else7462
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #4, LBB0_670
LBB0_563:                               ; %else7468
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #5, LBB0_671
LBB0_564:                               ; %else7474
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #6, LBB0_672
LBB0_565:                               ; %else7480
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w6, #7, LBB0_567
LBB0_566:                               ; %cond.load7482
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v3[1]
	ld1.s	{ v2 }[3], [x6]
LBB0_567:                               ; %else7486
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #10096]
	ldr	q3, [sp, #10080]
	zip1.8b	v4, v15, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bif.16b	v0, v3, v4
	zip2.8b	v3, v15, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v2, v3
	str	q1, [sp, #10096]
	str	q0, [sp, #10080]
	mov	w6, #1                          ; =0x1
	dup.2d	v0, x6
	add.2d	v1, v10, v0
	add.2d	v3, v27, v0
	add.2d	v4, v16, v0
	add.2d	v2, v17, v0
	ldr	q24, [sp, #10032]
	ldr	q6, [sp, #9984]
	ldr	q5, [sp, #10000]
	ldr	q25, [sp, #10016]
	mov	b0, v15[4]
	mov.b	v0[4], v15[5]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	bit.16b	v25, v2, v0
	mov	b26, v15[2]
	mov.b	v26[4], v15[3]
	ushll.2d	v26, v26, #0
	shl.2d	v26, v26, #63
	cmlt.2d	v8, v26, #0
	mov.16b	v26, v8
	bsl.16b	v26, v4, v5
	mov	b5, v15[0]
	mov.b	v5[4], v15[1]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	mov	b29, v15[6]
	mov.b	v29[4], v15[7]
	mov.16b	v30, v5
	bsl.16b	v30, v3, v6
	ushll.2d	v6, v29, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	bit.16b	v24, v1, v6
	str	q24, [sp, #10032]
	str	q30, [sp, #9984]
	str	q26, [sp, #10000]
	str	q25, [sp, #10016]
	add.2d	v2, v19, v2
	add.2d	v29, v18, v1
	add.2d	v26, v11, v3
	add.2d	v1, v28, v4
	ldr	q4, [sp, #9952]
	ldr	q30, [sp, #9968]
	ldr	q31, [sp, #9920]
	ldr	q3, [sp, #9936]
	bit.16b	v3, v1, v8
	mov.d	x6, v2[1]
	fmov	x7, d2
	add	x7, x7, x7, lsl #2
	lsl	x19, x7, #2
	fmov	d24, x7
	add	x6, x6, x6, lsl #2
	mov.d	v24[1], x6
	mov.d	x7, v1[1]
	fmov	x20, d1
	add	x20, x20, x20, lsl #2
	lsl	x21, x20, #2
	fmov	d25, x20
	add	x7, x7, x7, lsl #2
	mov.d	v25[1], x7
	mov.16b	v1, v5
	bsl.16b	v1, v26, v31
	mov.d	x20, v26[1]
	fmov	x22, d26
	add	x22, x22, x22, lsl #2
	lsl	x23, x22, #2
	fmov	d26, x22
	add	x20, x20, x20, lsl #2
	mov.d	v26[1], x20
	mov.d	x22, v29[1]
	mov.16b	v5, v6
	bsl.16b	v5, v29, v30
	fmov	x24, d29
	add	x24, x24, x24, lsl #2
	lsl	x25, x24, #2
	fmov	d29, x24
	add	x22, x22, x22, lsl #2
	mov.d	v29[1], x22
	fmov	d6, x25
	lsl	x22, x22, #2
	mov.d	v6[1], x22
	fmov	d30, x23
	lsl	x20, x20, #2
	mov.d	v30[1], x20
	fmov	d31, x21
	lsl	x7, x7, #2
	mov.d	v31[1], x7
	fmov	d8, x19
	lsl	x6, x6, #2
	mov.d	v8[1], x6
	bsl.16b	v0, v2, v4
	fmov	w6, s21
	str	q0, [sp, #9952]
	str	q5, [sp, #9968]
	str	q1, [sp, #9920]
	str	q3, [sp, #9936]
	add.2d	v4, v22, v8
	add.2d	v1, v22, v31
	add.2d	v5, v22, v30
	add.2d	v3, v22, v6
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w6, #0, LBB0_673
; %bb.568:                              ; %else7493
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #1, LBB0_674
LBB0_569:                               ; %else7499
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #2, LBB0_675
LBB0_570:                               ; %else7505
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #3, LBB0_676
LBB0_571:                               ; %else7511
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #4, LBB0_677
LBB0_572:                               ; %else7517
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #5, LBB0_678
LBB0_573:                               ; %else7523
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #6, LBB0_679
LBB0_574:                               ; %else7529
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w6, #7, LBB0_576
LBB0_575:                               ; %cond.load7531
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v3[1]
	ld1.s	{ v2 }[3], [x6]
LBB0_576:                               ; %else7535
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #9904]
	ldr	q3, [sp, #9888]
	fmov	w6, s21
	zip1.8b	v4, v15, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bif.16b	v0, v3, v4
	zip2.8b	v3, v15, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v2, v3
	str	q1, [sp, #9904]
	str	q0, [sp, #9888]
	add.2d	v0, v26, v20
	add.2d	v1, v25, v20
	add.2d	v2, v24, v20
	add.2d	v3, v29, v20
	shl.2d	v3, v3, #2
	shl.2d	v2, v2, #2
	shl.2d	v1, v1, #2
	shl.2d	v0, v0, #2
	add.2d	v5, v22, v0
	add.2d	v1, v22, v1
	add.2d	v4, v22, v2
	add.2d	v3, v22, v3
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w6, #0, LBB0_680
; %bb.577:                              ; %else7542
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #1, LBB0_681
LBB0_578:                               ; %else7548
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #2, LBB0_682
LBB0_579:                               ; %else7554
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #3, LBB0_683
LBB0_580:                               ; %else7560
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #4, LBB0_684
LBB0_581:                               ; %else7566
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #5, LBB0_685
LBB0_582:                               ; %else7572
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #6, LBB0_686
LBB0_583:                               ; %else7578
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w6, #7, LBB0_585
LBB0_584:                               ; %cond.load7580
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v3[1]
	ld1.s	{ v2 }[3], [x6]
LBB0_585:                               ; %else7584
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #9872]
	ldr	q3, [sp, #9856]
	fmov	w6, s21
	zip1.8b	v4, v15, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bif.16b	v0, v3, v4
	zip2.8b	v3, v15, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v2, v3
	str	q1, [sp, #9872]
	str	q0, [sp, #9856]
	add.2d	v0, v26, v23
	add.2d	v1, v25, v23
	add.2d	v2, v24, v23
	add.2d	v3, v29, v23
	shl.2d	v3, v3, #2
	shl.2d	v2, v2, #2
	shl.2d	v1, v1, #2
	shl.2d	v0, v0, #2
	add.2d	v5, v22, v0
	add.2d	v1, v22, v1
	add.2d	v4, v22, v2
	add.2d	v3, v22, v3
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w6, #0, LBB0_687
; %bb.586:                              ; %else7591
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #1, LBB0_688
LBB0_587:                               ; %else7597
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #2, LBB0_689
LBB0_588:                               ; %else7603
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #3, LBB0_690
LBB0_589:                               ; %else7609
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #4, LBB0_691
LBB0_590:                               ; %else7615
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #5, LBB0_692
LBB0_591:                               ; %else7621
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #6, LBB0_693
LBB0_592:                               ; %else7627
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w6, #7, LBB0_594
LBB0_593:                               ; %cond.load7629
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v3[1]
	ld1.s	{ v2 }[3], [x6]
LBB0_594:                               ; %else7633
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #9840]
	ldr	q3, [sp, #9824]
	fmov	w6, s21
	zip1.8b	v4, v15, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bif.16b	v0, v3, v4
	zip2.8b	v3, v15, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v2, v3
	str	q1, [sp, #9840]
	str	q0, [sp, #9824]
	add	x7, sp, #2, lsl #12             ; =8192
	add	x7, x7, #2776
	ld1r.2d	{ v0 }, [x7]
	add.2d	v1, v0, v29
	add.2d	v2, v0, v24
	add.2d	v3, v0, v25
	add.2d	v0, v0, v26
	shl.2d	v0, v0, #2
	shl.2d	v5, v3, #2
	shl.2d	v2, v2, #2
	shl.2d	v1, v1, #2
	add.2d	v3, v22, v1
	add.2d	v4, v22, v2
	add.2d	v1, v22, v5
	add.2d	v5, v22, v0
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w6, #0, LBB0_694
; %bb.595:                              ; %else7640
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #1, LBB0_695
LBB0_596:                               ; %else7646
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #2, LBB0_696
LBB0_597:                               ; %else7652
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #3, LBB0_697
LBB0_598:                               ; %else7658
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #4, LBB0_698
LBB0_599:                               ; %else7664
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #5, LBB0_699
LBB0_600:                               ; %else7670
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #6, LBB0_700
LBB0_601:                               ; %else7676
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w6, #7, LBB0_603
LBB0_602:                               ; %cond.load7678
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v3[1]
	ld1.s	{ v2 }[3], [x6]
LBB0_603:                               ; %else7682
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #9808]
	ldr	q3, [sp, #9792]
	fmov	w6, s21
	zip1.8b	v4, v15, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bif.16b	v0, v3, v4
	zip2.8b	v3, v15, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v2, v3
	str	q1, [sp, #9808]
	str	q0, [sp, #9792]
	add	x7, sp, #2, lsl #12             ; =8192
	add	x7, x7, #2712
	ld1r.2d	{ v0 }, [x7]
	add.2d	v1, v0, v29
	add.2d	v2, v0, v24
	add.2d	v3, v0, v25
	add.2d	v0, v0, v26
	shl.2d	v0, v0, #2
	shl.2d	v5, v3, #2
	shl.2d	v2, v2, #2
	shl.2d	v1, v1, #2
	add.2d	v3, v22, v1
	add.2d	v4, v22, v2
	add.2d	v1, v22, v5
	add.2d	v5, v22, v0
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w6, #0, LBB0_701
; %bb.604:                              ; %else7689
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #1, LBB0_702
LBB0_605:                               ; %else7695
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #2, LBB0_703
LBB0_606:                               ; %else7701
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #3, LBB0_704
LBB0_607:                               ; %else7707
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #4, LBB0_705
LBB0_608:                               ; %else7713
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #5, LBB0_706
LBB0_609:                               ; %else7719
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #6, LBB0_707
LBB0_610:                               ; %else7725
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w6, #7, LBB0_612
LBB0_611:                               ; %cond.load7727
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v3[1]
	ld1.s	{ v2 }[3], [x6]
LBB0_612:                               ; %else7731
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #9776]
	ldr	q3, [sp, #9760]
	zip1.8b	v4, v15, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bif.16b	v0, v3, v4
	zip2.8b	v3, v15, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v2, v3
	str	q1, [sp, #9776]
	str	q0, [sp, #9760]
	mov	w6, #2                          ; =0x2
	dup.2d	v0, x6
	add.2d	v5, v10, v0
	add.2d	v20, v27, v0
	add.2d	v23, v16, v0
	add.2d	v16, v17, v0
	ldr	q1, [sp, #9712]
	ldr	q4, [sp, #9664]
	ldr	q3, [sp, #9680]
	ldr	q2, [sp, #9696]
	mov	b0, v15[4]
	mov.b	v0[4], v15[5]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	mov.16b	v6, v0
	bsl.16b	v6, v16, v2
	mov	b2, v15[2]
	mov.b	v2[4], v15[3]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v2, v2, #0
	mov	b17, v15[0]
	mov.b	v17[4], v15[1]
	mov.16b	v24, v2
	bsl.16b	v24, v23, v3
	ushll.2d	v3, v17, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	mov.16b	v17, v3
	bsl.16b	v17, v20, v4
	mov	b4, v15[6]
	mov.b	v4[4], v15[7]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	bit.16b	v1, v5, v4
	str	q1, [sp, #9712]
	str	q17, [sp, #9664]
	str	q24, [sp, #9680]
	str	q6, [sp, #9696]
	add.2d	v17, v18, v5
	add.2d	v25, v11, v20
	add.2d	v24, v28, v23
	add.2d	v18, v19, v16
	ldr	q1, [sp, #9648]
	ldr	q6, [sp, #9600]
	ldr	q19, [sp, #9616]
	ldr	q26, [sp, #9632]
	bit.16b	v26, v18, v0
	bit.16b	v19, v24, v2
	bit.16b	v6, v25, v3
	bit.16b	v1, v17, v4
	str	q1, [sp, #9648]
	str	q6, [sp, #9600]
	str	q19, [sp, #9616]
	str	q26, [sp, #9632]
	mov	w6, #5                          ; =0x5
	dup.2d	v6, x6
	cmgt.2d	v1, v6, v23
	cmgt.2d	v19, v6, v20
	uzp1.4s	v1, v19, v1
	cmgt.2d	v19, v6, v16
	cmgt.2d	v26, v6, v5
	uzp1.4s	v19, v19, v26
	uzp1.8h	v1, v1, v19
	ldrb	w6, [x9, #837]
	and	w7, w6, #0x1
	fmov	s19, w7
	ubfx	w7, w6, #1, #1
	mov.b	v19[1], w7
	ubfx	w7, w6, #2, #1
	mov.b	v19[2], w7
	ubfx	w7, w6, #3, #1
	mov.b	v19[3], w7
	ubfx	w7, w6, #4, #1
	mov.b	v19[4], w7
	ubfx	w7, w6, #5, #1
	mov.b	v19[5], w7
	ubfx	w7, w6, #6, #1
	mov.b	v19[6], w7
	lsr	w6, w6, #7
	mov.b	v19[7], w6
	xtn.8b	v1, v1
	bif.8b	v1, v19, v7
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	ldr	d28, [sp, #1992]                ; 8-byte Reload
	and.8b	v1, v1, v28
	addv.8b	b1, v1
	str	b1, [x9, #837]
	cmhi.2d	v1, v6, v23
	cmhi.2d	v19, v6, v20
	uzp1.4s	v1, v19, v1
	cmhi.2d	v19, v6, v16
	cmhi.2d	v26, v6, v5
	uzp1.4s	v19, v19, v26
	uzp1.8h	v1, v1, v19
	xtn.8b	v1, v1
	bit.8b	v9, v1, v7
	str	q9, [sp, #1936]                 ; 16-byte Spill
	mov.d	x6, v25[1]
	fmov	x7, d25
	add	x7, x7, x7, lsl #2
	fmov	d7, x7
	add	x6, x6, x6, lsl #2
	mov.d	v7[1], x6
	mov.d	x6, v24[1]
	fmov	x7, d24
	add	x7, x7, x7, lsl #2
	fmov	d19, x7
	add	x6, x6, x6, lsl #2
	mov.d	v19[1], x6
	mov.d	x6, v18[1]
	fmov	x7, d18
	add	x7, x7, x7, lsl #2
	fmov	d18, x7
	add	x6, x6, x6, lsl #2
	mov.d	v18[1], x6
	mov.d	x6, v17[1]
	fmov	x7, d17
	add	x7, x7, x7, lsl #2
	fmov	d17, x7
	add	x6, x6, x6, lsl #2
	mov.d	v17[1], x6
	ldr	q24, [sp, #1584]                ; 16-byte Reload
	bit.16b	v24, v17, v4
	str	q24, [sp, #1584]                ; 16-byte Spill
	ldr	q24, [sp, #1600]                ; 16-byte Reload
	bit.16b	v24, v18, v0
	str	q24, [sp, #1600]                ; 16-byte Spill
	ldr	q24, [sp, #1616]                ; 16-byte Reload
	bit.16b	v24, v19, v2
	str	q24, [sp, #1616]                ; 16-byte Spill
	ldr	q24, [sp, #1632]                ; 16-byte Reload
	bit.16b	v24, v7, v3
	str	q24, [sp, #1632]                ; 16-byte Spill
	ldr	q24, [sp, #9504]
	ldr	q25, [sp, #9520]
	ldr	q26, [sp, #9472]
	ldr	q27, [sp, #9488]
	bsl.16b	v2, v19, v27
	bsl.16b	v3, v7, v26
	bsl.16b	v4, v17, v25
	bsl.16b	v0, v18, v24
	str	q0, [sp, #9504]
	str	q4, [sp, #9520]
	str	q3, [sp, #9472]
	str	q2, [sp, #9488]
	and.8b	v7, v15, v1
	shl.8b	v0, v7, #7
	cmlt.8b	v0, v0, #0
	and.8b	v1, v0, v28
	addv.8b	b1, v1
	fmov	w6, s1
	umaxv.8b	b0, v0
	fmov	w7, s0
	tbz	w7, #0, LBB0_618
; %bb.613:                              ; %else7731
                                        ;   in Loop: Header=BB0_6 Depth=2
	cmhs.2d	v0, v23, v6
	cmhs.2d	v1, v20, v6
	uzp1.4s	v0, v1, v0
	cmhs.2d	v1, v16, v6
	cmhs.2d	v2, v5, v6
	uzp1.4s	v1, v1, v2
	uzp1.8h	v0, v0, v1
	xtn.8b	v0, v0
	and.8b	v16, v15, v0
	shl.8b	v0, v16, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w7, s0
	tst	w7, #0xff
	b.eq	LBB0_618
; %bb.614:                              ; %varying.divergent312
                                        ;   in Loop: Header=BB0_6 Depth=2
	cmp	w4, #0
	cset	w5, ne
	sub	w5, w4, w5
	and	w6, w0, #0xff
	lsr	w7, w6, w5
	tst	w7, #0x1
	cset	w7, eq
	cmp	w4, #0
	ldr	q5, [sp, #1664]                 ; 16-byte Reload
	str	q5, [sp, #3088]
	ldr	q4, [sp, #1680]                 ; 16-byte Reload
	str	q4, [sp, #3104]
	and	x5, x5, #0x7
	add	x19, sp, #3088
	ldr	w5, [x19, x5, lsl #2]
	csinc	w7, w7, wzr, ne
	cmp	w5, #6
	csinc	w5, w7, wzr, eq
	cmp	w6, #255
	ldr	q23, [sp, #1744]                ; 16-byte Reload
	ldr	q26, [sp, #1696]                ; 16-byte Reload
	ldr	q11, [sp, #1536]                ; 16-byte Reload
	b.ne	LBB0_616
; %bb.615:                              ; %varying.divergent312
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #0, LBB0_616
	b	LBB0_1348
LBB0_616:                               ; %convergence.overflow.resume315
                                        ;   in Loop: Header=BB0_6 Depth=2
	mvn	w6, w0
	rbit	w6, w6
	clz	w6, w6
	mov	w7, #255                        ; =0xff
	bics	wzr, w7, w0
	csel	w7, wzr, w6, eq
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #3560
	ldrb	w20, [x6, w7, uxtw]
	and	w19, w20, #0x1
	fmov	s0, w19
	ubfx	w19, w20, #1, #1
	mov.b	v0[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v0[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v0[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v0[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v0[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v0[6], w19
	add	x19, sp, #2, lsl #12            ; =8192
	add	x19, x19, #3552
	lsr	w20, w20, #7
	mov.b	v0[7], w20
	ldrb	w20, [x19, w7, uxtw]
	and	w21, w20, #0x1
	fmov	s1, w21
	ubfx	w21, w20, #1, #1
	mov.b	v1[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v1[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v1[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v1[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v1[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v1[6], w21
	lsr	w20, w20, #7
	mov.b	v1[7], w20
	cmp	w5, #0
	csetm	w20, ne
	dup.8b	v2, w20
	bit.8b	v0, v15, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	ldr	d3, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x6, w7, uxtw]
	bic.8b	v0, v1, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x19, w7, uxtw]
	cmp	x1, #8
	ldr	q25, [sp, #1728]                ; 16-byte Reload
	ldr	q22, [sp, #1712]                ; 16-byte Reload
	ldr	q10, [sp, #1504]                ; 16-byte Reload
	ldr	q8, [sp, #1488]                 ; 16-byte Reload
	ldr	q31, [sp, #1472]                ; 16-byte Reload
	ldr	q2, [sp, #1968]                 ; 16-byte Reload
	ldr	q3, [sp, #1456]                 ; 16-byte Reload
	b.hs	LBB0_1348
; %bb.617:                              ; %ready.overflow.resume317
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v0, v16, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	ldr	q1, [sp, #1008]                 ; 16-byte Reload
	and.16b	v6, v0, v1
	zip1.8b	v0, v16, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	ldr	q1, [sp, #1024]                 ; 16-byte Reload
	and.16b	v1, v0, v1
	stp	q6, q1, [sp, #1008]             ; 32-byte Folded Spill
	str	q3, [sp, #3056]
	str	q2, [sp, #3072]
	ubfiz	x6, x7, #2, #3
	add	x19, sp, #3056
	ldr	w19, [x19, x6]
	cmp	w5, #0
	csel	w19, w4, w19, ne
	csinc	w4, w4, w7, eq
	str	q3, [sp, #3024]
	str	q2, [sp, #3040]
	add	x20, sp, #3024
	str	w19, [x20, x6]
	ldr	q0, [sp, #3040]
	str	q0, [sp, #1968]                 ; 16-byte Spill
	ldr	q9, [sp, #3024]
	str	q5, [sp, #2992]
	str	q4, [sp, #3008]
	add	x19, sp, #2992
	ldr	w19, [x19, x6]
	mov	w20, #6                         ; =0x6
	csel	w19, w20, w19, ne
	str	q5, [sp, #2960]
	str	q4, [sp, #2976]
	add	x20, sp, #2960
	str	w19, [x20, x6]
	mov	w6, #14                         ; =0xe
	mov	w19, #13                        ; =0xd
	ldr	q27, [sp, #2976]
	ldr	q24, [sp, #2960]
                                        ; kill: def $w7 killed $w7 killed $x7 def $x7
	ldr	q12, [sp, #1520]                ; 16-byte Reload
	ldr	q29, [sp, #1648]                ; 16-byte Reload
	b	LBB0_1262
LBB0_618:                               ; %varying.coherent313
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w6, #0xff
	ldr	q23, [sp, #1744]                ; 16-byte Reload
	ldr	q26, [sp, #1696]                ; 16-byte Reload
	ldr	q11, [sp, #1536]                ; 16-byte Reload
	ldr	q27, [sp, #1680]                ; 16-byte Reload
	ldr	q24, [sp, #1664]                ; 16-byte Reload
	b.eq	LBB0_730
; %bb.619:                              ; %varying.coherent.true318
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q25, [sp, #1728]                ; 16-byte Reload
	ldr	q29, [sp, #1648]                ; 16-byte Reload
	ldr	q10, [sp, #1504]                ; 16-byte Reload
	ldr	q8, [sp, #1488]                 ; 16-byte Reload
	ldr	q31, [sp, #1472]                ; 16-byte Reload
	tbz	w5, #0, LBB0_620
	b	LBB0_1300
LBB0_620:                               ; %schedule.13.thread
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q0, [sp, #9520]
	ldr	q1, [sp, #9504]
	ldr	q2, [sp, #9488]
	ldr	q3, [sp, #9472]
	shl.2d	v5, v3, #2
	shl.2d	v2, v2, #2
	shl.2d	v1, v1, #2
	shl.2d	v0, v0, #2
	add.2d	v3, v22, v0
	add.2d	v4, v22, v1
	add.2d	v1, v22, v2
	add.2d	v5, v22, v5
	fmov	w5, s21
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	ldr	q12, [sp, #1520]                ; 16-byte Reload
	ldr	q9, [sp, #1456]                 ; 16-byte Reload
	tbnz	w5, #0, LBB0_1009
; %bb.621:                              ; %else8661
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_1010
LBB0_622:                               ; %else8667
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q22, [sp, #1712]                ; 16-byte Reload
	tbnz	w5, #2, LBB0_1011
LBB0_623:                               ; %else8673
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_1012
LBB0_624:                               ; %else8679
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #4, LBB0_1013
LBB0_625:                               ; %else8685
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_1014
LBB0_626:                               ; %else8691
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #6, LBB0_1015
LBB0_627:                               ; %else8697
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_629
LBB0_628:                               ; %cond.load8699
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x5, v3[1]
	ld1.s	{ v2 }[3], [x5]
LBB0_629:                               ; %else8703
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q3, [sp, #1008]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #1024]                 ; 16-byte Reload
	bit.16b	v2, v0, v1
	stp	q3, q2, [sp, #1008]             ; 32-byte Folded Spill
	cbnz	w4, LBB0_119
LBB0_630:                               ; %schedule.14.convergence.cascade.exit322_crit_edge
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w6, s0
LBB0_631:                               ; %convergence.cascade.exit322
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w6, #0xff
	b.eq	LBB0_4
; %bb.632:                              ; %convergence.target.14.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	dup.2d	v0, x3
	ldr	q1, [sp, #1600]                 ; 16-byte Reload
	add.2d	v1, v1, v0
	ldr	q2, [sp, #1584]                 ; 16-byte Reload
	add.2d	v2, v2, v0
	ldr	q3, [sp, #1632]                 ; 16-byte Reload
	add.2d	v3, v3, v0
	ldr	q4, [sp, #1616]                 ; 16-byte Reload
	add.2d	v0, v4, v0
	ldr	q4, [sp, #9440]
	ldr	q5, [sp, #9456]
	ldr	q6, [sp, #9408]
	ldr	q7, [sp, #9424]
	mov	b16, v15[2]
	mov.b	v16[4], v15[3]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	bif.16b	v0, v7, v16
	mov	b7, v15[0]
	mov.b	v7[4], v15[1]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	mov	b16, v15[6]
	mov.b	v16[4], v15[7]
	bif.16b	v3, v6, v7
	ushll.2d	v6, v16, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	bif.16b	v2, v5, v6
	mov	b5, v15[4]
	mov.b	v5[4], v15[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	bif.16b	v1, v4, v5
	str	q1, [sp, #9440]
	str	q2, [sp, #9456]
	str	q3, [sp, #9408]
	str	q0, [sp, #9424]
	ldr	q0, [sp, #1936]                 ; 16-byte Reload
	and.8b	v7, v0, v15
	shl.8b	v0, v7, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v0, v1
	addv.8b	b1, v1
	fmov	w5, s1
	umaxv.8b	b0, v0
	fmov	w6, s0
	tbz	w6, #0, LBB0_708
; %bb.633:                              ; %convergence.target.14.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q0, [sp, #1936]                 ; 16-byte Reload
	bic.8b	v16, v15, v0
	shl.8b	v0, v16, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w6, s0
	tst	w6, #0xff
	b.eq	LBB0_708
; %bb.634:                              ; %varying.divergent343
                                        ;   in Loop: Header=BB0_6 Depth=2
	cmp	w4, #0
	cset	w5, ne
	sub	w5, w4, w5
	and	w6, w0, #0xff
	lsr	w7, w6, w5
	tst	w7, #0x1
	cset	w7, eq
	cmp	w4, #0
	str	q24, [sp, #3248]
	str	q27, [sp, #3264]
	and	x5, x5, #0x7
	add	x19, sp, #3248
	ldr	w5, [x19, x5, lsl #2]
	csinc	w7, w7, wzr, ne
	cmp	w5, #7
	csinc	w5, w7, wzr, eq
	cmp	w6, #255
	b.ne	LBB0_636
; %bb.635:                              ; %varying.divergent343
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #0, LBB0_636
	b	LBB0_1348
LBB0_636:                               ; %convergence.overflow.resume346
                                        ;   in Loop: Header=BB0_6 Depth=2
	mvn	w6, w0
	rbit	w6, w6
	clz	w6, w6
	mov	w7, #255                        ; =0xff
	bics	wzr, w7, w0
	csel	w7, wzr, w6, eq
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #3560
	ldrb	w20, [x6, w7, uxtw]
	and	w19, w20, #0x1
	fmov	s0, w19
	ubfx	w19, w20, #1, #1
	mov.b	v0[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v0[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v0[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v0[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v0[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v0[6], w19
	add	x19, sp, #2, lsl #12            ; =8192
	add	x19, x19, #3552
	lsr	w20, w20, #7
	mov.b	v0[7], w20
	ldrb	w20, [x19, w7, uxtw]
	and	w21, w20, #0x1
	fmov	s1, w21
	ubfx	w21, w20, #1, #1
	mov.b	v1[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v1[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v1[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v1[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v1[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v1[6], w21
	lsr	w20, w20, #7
	mov.b	v1[7], w20
	cmp	w5, #0
	csetm	w20, ne
	dup.8b	v2, w20
	bit.8b	v0, v15, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	ldr	d3, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x6, w7, uxtw]
	bic.8b	v0, v1, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x19, w7, uxtw]
	cmp	x1, #8
	b.hs	LBB0_1348
; %bb.637:                              ; %ready.overflow.resume348
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v0, v16, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	ldp	q3, q1, [sp, #784]              ; 32-byte Folded Reload
	and.16b	v2, v0, v3
	zip1.8b	v0, v16, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v1, v0, v1
	stp	q2, q1, [sp, #784]              ; 32-byte Folded Spill
	str	q9, [sp, #3216]
	ldr	q0, [sp, #1968]                 ; 16-byte Reload
	str	q0, [sp, #3232]
	ubfiz	x6, x7, #2, #3
	add	x19, sp, #3216
	ldr	w19, [x19, x6]
	cmp	w5, #0
	csel	w19, w4, w19, ne
	csinc	w4, w4, w7, eq
	str	q9, [sp, #3184]
	str	q0, [sp, #3200]
	add	x20, sp, #3184
	str	w19, [x20, x6]
	ldr	q0, [sp, #3200]
	str	q0, [sp, #1968]                 ; 16-byte Spill
	ldr	q9, [sp, #3184]
	str	q24, [sp, #3152]
	str	q27, [sp, #3168]
	add	x19, sp, #3152
	ldr	w19, [x19, x6]
	mov	w20, #7                         ; =0x7
	csel	w19, w20, w19, ne
	str	q24, [sp, #3120]
	str	q27, [sp, #3136]
	add	x20, sp, #3120
	str	w19, [x20, x6]
	mov	w6, #16                         ; =0x10
	mov	w19, #15                        ; =0xf
	ldr	q27, [sp, #3136]
	ldr	q24, [sp, #3120]
	b	LBB0_1261
LBB0_638:                               ; %cond.load7244
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d5
	ldr	s0, [x7]
	tbz	w6, #1, LBB0_524
LBB0_639:                               ; %cond.load7250
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v5[1]
	ld1.s	{ v0 }[1], [x7]
	tbz	w6, #2, LBB0_525
LBB0_640:                               ; %cond.load7256
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d1
	ld1.s	{ v0 }[2], [x7]
	tbz	w6, #3, LBB0_526
LBB0_641:                               ; %cond.load7262
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v1[1]
	ld1.s	{ v0 }[3], [x7]
	tbz	w6, #4, LBB0_527
LBB0_642:                               ; %cond.load7268
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d4
	ld1.s	{ v2 }[0], [x7]
	tbz	w6, #5, LBB0_528
LBB0_643:                               ; %cond.load7274
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v4[1]
	ld1.s	{ v2 }[1], [x7]
	tbz	w6, #6, LBB0_529
LBB0_644:                               ; %cond.load7280
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d3
	ld1.s	{ v2 }[2], [x7]
	tbnz	w6, #7, LBB0_530
	b	LBB0_531
LBB0_645:                               ; %cond.load7293
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d5
	ldr	s0, [x7]
	tbz	w6, #1, LBB0_533
LBB0_646:                               ; %cond.load7299
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v5[1]
	ld1.s	{ v0 }[1], [x7]
	tbz	w6, #2, LBB0_534
LBB0_647:                               ; %cond.load7305
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d1
	ld1.s	{ v0 }[2], [x7]
	tbz	w6, #3, LBB0_535
LBB0_648:                               ; %cond.load7311
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v1[1]
	ld1.s	{ v0 }[3], [x7]
	tbz	w6, #4, LBB0_536
LBB0_649:                               ; %cond.load7317
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d4
	ld1.s	{ v2 }[0], [x7]
	tbz	w6, #5, LBB0_537
LBB0_650:                               ; %cond.load7323
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v4[1]
	ld1.s	{ v2 }[1], [x7]
	tbz	w6, #6, LBB0_538
LBB0_651:                               ; %cond.load7329
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d3
	ld1.s	{ v2 }[2], [x7]
	tbnz	w6, #7, LBB0_539
	b	LBB0_540
LBB0_652:                               ; %cond.load7342
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d5
	ldr	s0, [x7]
	tbz	w6, #1, LBB0_542
LBB0_653:                               ; %cond.load7348
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v5[1]
	ld1.s	{ v0 }[1], [x7]
	tbz	w6, #2, LBB0_543
LBB0_654:                               ; %cond.load7354
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d1
	ld1.s	{ v0 }[2], [x7]
	tbz	w6, #3, LBB0_544
LBB0_655:                               ; %cond.load7360
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v1[1]
	ld1.s	{ v0 }[3], [x7]
	tbz	w6, #4, LBB0_545
LBB0_656:                               ; %cond.load7366
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d4
	ld1.s	{ v2 }[0], [x7]
	tbz	w6, #5, LBB0_546
LBB0_657:                               ; %cond.load7372
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v4[1]
	ld1.s	{ v2 }[1], [x7]
	tbz	w6, #6, LBB0_547
LBB0_658:                               ; %cond.load7378
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d3
	ld1.s	{ v2 }[2], [x7]
	tbnz	w6, #7, LBB0_548
	b	LBB0_549
LBB0_659:                               ; %cond.load7391
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d5
	ldr	s0, [x7]
	tbz	w6, #1, LBB0_551
LBB0_660:                               ; %cond.load7397
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v5[1]
	ld1.s	{ v0 }[1], [x7]
	tbz	w6, #2, LBB0_552
LBB0_661:                               ; %cond.load7403
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d1
	ld1.s	{ v0 }[2], [x7]
	tbz	w6, #3, LBB0_553
LBB0_662:                               ; %cond.load7409
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v1[1]
	ld1.s	{ v0 }[3], [x7]
	tbz	w6, #4, LBB0_554
LBB0_663:                               ; %cond.load7415
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d4
	ld1.s	{ v2 }[0], [x7]
	tbz	w6, #5, LBB0_555
LBB0_664:                               ; %cond.load7421
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v4[1]
	ld1.s	{ v2 }[1], [x7]
	tbz	w6, #6, LBB0_556
LBB0_665:                               ; %cond.load7427
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d3
	ld1.s	{ v2 }[2], [x7]
	tbnz	w6, #7, LBB0_557
	b	LBB0_558
LBB0_666:                               ; %cond.load7440
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d5
	ldr	s0, [x7]
	tbz	w6, #1, LBB0_560
LBB0_667:                               ; %cond.load7446
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v5[1]
	ld1.s	{ v0 }[1], [x7]
	tbz	w6, #2, LBB0_561
LBB0_668:                               ; %cond.load7452
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d1
	ld1.s	{ v0 }[2], [x7]
	tbz	w6, #3, LBB0_562
LBB0_669:                               ; %cond.load7458
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v1[1]
	ld1.s	{ v0 }[3], [x7]
	tbz	w6, #4, LBB0_563
LBB0_670:                               ; %cond.load7464
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d4
	ld1.s	{ v2 }[0], [x7]
	tbz	w6, #5, LBB0_564
LBB0_671:                               ; %cond.load7470
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v4[1]
	ld1.s	{ v2 }[1], [x7]
	tbz	w6, #6, LBB0_565
LBB0_672:                               ; %cond.load7476
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d3
	ld1.s	{ v2 }[2], [x7]
	tbnz	w6, #7, LBB0_566
	b	LBB0_567
LBB0_673:                               ; %cond.load7489
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d5
	ldr	s0, [x7]
	tbz	w6, #1, LBB0_569
LBB0_674:                               ; %cond.load7495
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v5[1]
	ld1.s	{ v0 }[1], [x7]
	tbz	w6, #2, LBB0_570
LBB0_675:                               ; %cond.load7501
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d1
	ld1.s	{ v0 }[2], [x7]
	tbz	w6, #3, LBB0_571
LBB0_676:                               ; %cond.load7507
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v1[1]
	ld1.s	{ v0 }[3], [x7]
	tbz	w6, #4, LBB0_572
LBB0_677:                               ; %cond.load7513
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d4
	ld1.s	{ v2 }[0], [x7]
	tbz	w6, #5, LBB0_573
LBB0_678:                               ; %cond.load7519
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v4[1]
	ld1.s	{ v2 }[1], [x7]
	tbz	w6, #6, LBB0_574
LBB0_679:                               ; %cond.load7525
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d3
	ld1.s	{ v2 }[2], [x7]
	tbnz	w6, #7, LBB0_575
	b	LBB0_576
LBB0_680:                               ; %cond.load7538
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d5
	ldr	s0, [x7]
	tbz	w6, #1, LBB0_578
LBB0_681:                               ; %cond.load7544
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v5[1]
	ld1.s	{ v0 }[1], [x7]
	tbz	w6, #2, LBB0_579
LBB0_682:                               ; %cond.load7550
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d1
	ld1.s	{ v0 }[2], [x7]
	tbz	w6, #3, LBB0_580
LBB0_683:                               ; %cond.load7556
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v1[1]
	ld1.s	{ v0 }[3], [x7]
	tbz	w6, #4, LBB0_581
LBB0_684:                               ; %cond.load7562
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d4
	ld1.s	{ v2 }[0], [x7]
	tbz	w6, #5, LBB0_582
LBB0_685:                               ; %cond.load7568
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v4[1]
	ld1.s	{ v2 }[1], [x7]
	tbz	w6, #6, LBB0_583
LBB0_686:                               ; %cond.load7574
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d3
	ld1.s	{ v2 }[2], [x7]
	tbnz	w6, #7, LBB0_584
	b	LBB0_585
LBB0_687:                               ; %cond.load7587
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d5
	ldr	s0, [x7]
	tbz	w6, #1, LBB0_587
LBB0_688:                               ; %cond.load7593
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v5[1]
	ld1.s	{ v0 }[1], [x7]
	tbz	w6, #2, LBB0_588
LBB0_689:                               ; %cond.load7599
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d1
	ld1.s	{ v0 }[2], [x7]
	tbz	w6, #3, LBB0_589
LBB0_690:                               ; %cond.load7605
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v1[1]
	ld1.s	{ v0 }[3], [x7]
	tbz	w6, #4, LBB0_590
LBB0_691:                               ; %cond.load7611
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d4
	ld1.s	{ v2 }[0], [x7]
	tbz	w6, #5, LBB0_591
LBB0_692:                               ; %cond.load7617
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v4[1]
	ld1.s	{ v2 }[1], [x7]
	tbz	w6, #6, LBB0_592
LBB0_693:                               ; %cond.load7623
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d3
	ld1.s	{ v2 }[2], [x7]
	tbnz	w6, #7, LBB0_593
	b	LBB0_594
LBB0_694:                               ; %cond.load7636
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d5
	ldr	s0, [x7]
	tbz	w6, #1, LBB0_596
LBB0_695:                               ; %cond.load7642
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v5[1]
	ld1.s	{ v0 }[1], [x7]
	tbz	w6, #2, LBB0_597
LBB0_696:                               ; %cond.load7648
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d1
	ld1.s	{ v0 }[2], [x7]
	tbz	w6, #3, LBB0_598
LBB0_697:                               ; %cond.load7654
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v1[1]
	ld1.s	{ v0 }[3], [x7]
	tbz	w6, #4, LBB0_599
LBB0_698:                               ; %cond.load7660
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d4
	ld1.s	{ v2 }[0], [x7]
	tbz	w6, #5, LBB0_600
LBB0_699:                               ; %cond.load7666
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v4[1]
	ld1.s	{ v2 }[1], [x7]
	tbz	w6, #6, LBB0_601
LBB0_700:                               ; %cond.load7672
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d3
	ld1.s	{ v2 }[2], [x7]
	tbnz	w6, #7, LBB0_602
	b	LBB0_603
LBB0_701:                               ; %cond.load7685
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d5
	ldr	s0, [x7]
	tbz	w6, #1, LBB0_605
LBB0_702:                               ; %cond.load7691
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v5[1]
	ld1.s	{ v0 }[1], [x7]
	tbz	w6, #2, LBB0_606
LBB0_703:                               ; %cond.load7697
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d1
	ld1.s	{ v0 }[2], [x7]
	tbz	w6, #3, LBB0_607
LBB0_704:                               ; %cond.load7703
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v1[1]
	ld1.s	{ v0 }[3], [x7]
	tbz	w6, #4, LBB0_608
LBB0_705:                               ; %cond.load7709
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d4
	ld1.s	{ v2 }[0], [x7]
	tbz	w6, #5, LBB0_609
LBB0_706:                               ; %cond.load7715
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v4[1]
	ld1.s	{ v2 }[1], [x7]
	tbz	w6, #6, LBB0_610
LBB0_707:                               ; %cond.load7721
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d3
	ld1.s	{ v2 }[2], [x7]
	tbnz	w6, #7, LBB0_611
	b	LBB0_612
LBB0_708:                               ; %varying.coherent344
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w5, #0xff
	b.eq	LBB0_731
; %bb.709:                              ; %schedule.15.thread
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q0, [sp, #9456]
	ldr	q1, [sp, #9440]
	ldr	q2, [sp, #9424]
	ldr	q3, [sp, #9408]
	shl.2d	v3, v3, #2
	shl.2d	v5, v2, #2
	shl.2d	v1, v1, #2
	dup.2d	v6, x11
	shl.2d	v0, v0, #2
	add.2d	v2, v6, v0
	add.2d	v4, v6, v1
	add.2d	v1, v6, v5
	add.2d	v5, v6, v3
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d3, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	fmov	w5, s0
	movi.2d	v0, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w5, #0, LBB0_1030
; %bb.710:                              ; %else8710
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_1031
LBB0_711:                               ; %else8716
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #2, LBB0_1032
LBB0_712:                               ; %else8722
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_1033
LBB0_713:                               ; %else8728
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #4, LBB0_1034
LBB0_714:                               ; %else8734
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_1035
LBB0_715:                               ; %else8740
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #6, LBB0_1036
LBB0_716:                               ; %else8746
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_718
LBB0_717:                               ; %cond.load8748
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x5, v2[1]
	ld1.s	{ v3 }[3], [x5]
LBB0_718:                               ; %else8752
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #784]                  ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #784]                  ; 16-byte Spill
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #800]                  ; 16-byte Reload
	bit.16b	v2, v0, v1
	str	q2, [sp, #800]                  ; 16-byte Spill
LBB0_719:                               ; %schedule.16
                                        ;   in Loop: Header=BB0_6 Depth=2
	cbz	w4, LBB0_732
LBB0_720:                               ; %convergence.cascade352.preheader
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w5, #0                          ; =0x0
LBB0_721:                               ; %convergence.cascade352
                                        ;   Parent Loop BB0_5 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d6, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v0, v6
	addv.8b	b1, v1
	fmov	w6, s1
	umaxv.8b	b0, v0
	fmov	w20, s0
	sub	w7, w4, #1
	tst	w6, #0xff
	csel	w7, w7, wzr, ne
	mov	w6, #1                          ; =0x1
	lsl	w19, w6, w7
	and	w6, w19, w0
	tst	w6, #0xff
	cset	w22, ne
	str	q24, [sp, #6320]
	str	q27, [sp, #6336]
	ubfiz	x6, x7, #2, #3
	add	x21, sp, #1, lsl #12            ; =4096
	add	x21, x21, #2224
	ldr	w21, [x21, x6]
	cmp	w21, #7
	cset	w21, eq
	and	w22, w22, w20
	add	x20, sp, #2, lsl #12            ; =8192
	add	x20, x20, #3560
	ldrb	w24, [x20, w7, sxtw]
	and	w23, w24, #0x1
	fmov	s0, w23
	ubfx	w23, w24, #1, #1
	mov.b	v0[1], w23
	ubfx	w23, w24, #2, #1
	mov.b	v0[2], w23
	ubfx	w23, w24, #3, #1
	mov.b	v0[3], w23
	ubfx	w23, w24, #4, #1
	mov.b	v0[4], w23
	ubfx	w23, w24, #5, #1
	mov.b	v0[5], w23
	ubfx	w23, w24, #6, #1
	mov.b	v0[6], w23
	add	x23, sp, #2, lsl #12            ; =8192
	add	x23, x23, #3552
	lsr	w24, w24, #7
	mov.b	v0[7], w24
	ldrb	w24, [x23, w7, sxtw]
	and	w25, w24, #0x1
	fmov	s1, w25
	ubfx	w25, w24, #1, #1
	mov.b	v1[1], w25
	ubfx	w25, w24, #2, #1
	mov.b	v1[2], w25
	ubfx	w25, w24, #3, #1
	mov.b	v1[3], w25
	ubfx	w25, w24, #4, #1
	mov.b	v1[4], w25
	ubfx	w25, w24, #5, #1
	mov.b	v1[5], w25
	ubfx	w25, w24, #6, #1
	mov.b	v1[6], w25
	lsr	w24, w24, #7
	mov.b	v1[7], w24
	orr.8b	v2, v15, v1
	ldr	d3, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v3, v0
	eor.8b	v3, v3, v2
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w24, s3
	ands	w21, w22, w21
	csetm	w22, ne
	bics	w24, w21, w24
	csetm	w25, ne
	dup.8b	v3, w25
	bic.8b	v4, v2, v3
	dup.8b	v5, w22
	bit.8b	v1, v4, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v6
	addv.8b	b1, v1
	str	b1, [x23, w7, sxtw]
	bic.8b	v0, v0, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	str	b0, [x20, w7, sxtw]
	mov	w7, #-1                         ; =0xffffffff
	csinv	w7, w7, w19, eq
	and	w0, w7, w0
	dup.8b	v0, w21
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	dup.8b	v1, w24
	and.8b	v1, v1, v2
	str	q9, [sp, #6288]
	ldr	q2, [sp, #1968]                 ; 16-byte Reload
	str	q2, [sp, #6304]
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #2192
	ldr	w6, [x7, x6]
	csel	w4, w6, w4, ne
	bit.8b	v15, v1, v0
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	fmov	w6, s0
	cmp	w21, #1
	b.ne	LBB0_733
; %bb.722:                              ; %convergence.cascade352
                                        ;   in Loop: Header=BB0_721 Depth=3
	cmp	w4, #0
	ccmp	w5, #6, #2, ne
	b.hi	LBB0_733
; %bb.723:                              ; %convergence.cascade352
                                        ;   in Loop: Header=BB0_721 Depth=3
	add	w5, w5, #1
	tst	w6, #0xff
	b.ne	LBB0_721
	b	LBB0_733
LBB0_724:                               ; %varying.coherent.false273
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w6, #0xff
	b.eq	LBB0_4
LBB0_725:                               ; %schedule.41
                                        ;   in Loop: Header=BB0_6 Depth=2
	cbz	w4, LBB0_1037
; %bb.726:                              ; %convergence.cascade882.preheader
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w5, #0                          ; =0x0
LBB0_727:                               ; %convergence.cascade882
                                        ;   Parent Loop BB0_5 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d6, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v0, v6
	addv.8b	b1, v1
	fmov	w6, s1
	umaxv.8b	b0, v0
	fmov	w20, s0
	sub	w7, w4, #1
	tst	w6, #0xff
	csel	w7, w7, wzr, ne
	mov	w6, #1                          ; =0x1
	lsl	w19, w6, w7
	and	w6, w19, w0
	tst	w6, #0xff
	cset	w22, ne
	str	q24, [sp, #7120]
	str	q27, [sp, #7136]
	ubfiz	x6, x7, #2, #3
	add	x21, sp, #1, lsl #12            ; =4096
	add	x21, x21, #3024
	ldr	w21, [x21, x6]
	cmp	w21, #5
	cset	w21, eq
	and	w22, w22, w20
	add	x20, sp, #2, lsl #12            ; =8192
	add	x20, x20, #3560
	ldrb	w24, [x20, w7, sxtw]
	and	w23, w24, #0x1
	fmov	s0, w23
	ubfx	w23, w24, #1, #1
	mov.b	v0[1], w23
	ubfx	w23, w24, #2, #1
	mov.b	v0[2], w23
	ubfx	w23, w24, #3, #1
	mov.b	v0[3], w23
	ubfx	w23, w24, #4, #1
	mov.b	v0[4], w23
	ubfx	w23, w24, #5, #1
	mov.b	v0[5], w23
	ubfx	w23, w24, #6, #1
	mov.b	v0[6], w23
	add	x23, sp, #2, lsl #12            ; =8192
	add	x23, x23, #3552
	lsr	w24, w24, #7
	mov.b	v0[7], w24
	ldrb	w24, [x23, w7, sxtw]
	and	w25, w24, #0x1
	fmov	s1, w25
	ubfx	w25, w24, #1, #1
	mov.b	v1[1], w25
	ubfx	w25, w24, #2, #1
	mov.b	v1[2], w25
	ubfx	w25, w24, #3, #1
	mov.b	v1[3], w25
	ubfx	w25, w24, #4, #1
	mov.b	v1[4], w25
	ubfx	w25, w24, #5, #1
	mov.b	v1[5], w25
	ubfx	w25, w24, #6, #1
	mov.b	v1[6], w25
	lsr	w24, w24, #7
	mov.b	v1[7], w24
	orr.8b	v2, v15, v1
	ldr	d3, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v3, v0
	eor.8b	v3, v3, v2
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w24, s3
	ands	w21, w22, w21
	csetm	w22, ne
	bics	w24, w21, w24
	csetm	w25, ne
	dup.8b	v3, w25
	bic.8b	v4, v2, v3
	dup.8b	v5, w22
	bit.8b	v1, v4, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v6
	addv.8b	b1, v1
	str	b1, [x23, w7, sxtw]
	bic.8b	v0, v0, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	str	b0, [x20, w7, sxtw]
	mov	w7, #-1                         ; =0xffffffff
	csinv	w7, w7, w19, eq
	and	w0, w7, w0
	dup.8b	v0, w21
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	dup.8b	v1, w24
	and.8b	v1, v1, v2
	str	q9, [sp, #7088]
	ldr	q2, [sp, #1968]                 ; 16-byte Reload
	str	q2, [sp, #7104]
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #2992
	ldr	w6, [x7, x6]
	csel	w4, w6, w4, ne
	bit.8b	v15, v1, v0
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	fmov	w6, s0
	cmp	w21, #1
	b.ne	LBB0_1038
; %bb.728:                              ; %convergence.cascade882
                                        ;   in Loop: Header=BB0_727 Depth=3
	cmp	w4, #0
	ccmp	w5, #6, #2, ne
	b.hi	LBB0_1038
; %bb.729:                              ; %convergence.cascade882
                                        ;   in Loop: Header=BB0_727 Depth=3
	add	w5, w5, #1
	tst	w6, #0xff
	b.ne	LBB0_727
	b	LBB0_1038
LBB0_730:                               ; %varying.coherent.false319
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	ldp	q3, q1, [sp, #1008]             ; 32-byte Folded Reload
	and.16b	v2, v0, v3
	zip1.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v1, v0, v1
	stp	q2, q1, [sp, #1008]             ; 32-byte Folded Spill
	ldr	q12, [sp, #1520]                ; 16-byte Reload
	ldr	q25, [sp, #1728]                ; 16-byte Reload
	ldr	q29, [sp, #1648]                ; 16-byte Reload
	ldr	q22, [sp, #1712]                ; 16-byte Reload
	ldr	q10, [sp, #1504]                ; 16-byte Reload
	ldr	q8, [sp, #1488]                 ; 16-byte Reload
	ldr	q31, [sp, #1472]                ; 16-byte Reload
	ldr	q9, [sp, #1456]                 ; 16-byte Reload
	tbz	w5, #0, LBB0_118
	b	LBB0_4
LBB0_731:                               ; %varying.coherent.false350
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	ldp	q3, q1, [sp, #784]              ; 32-byte Folded Reload
	and.16b	v2, v0, v3
	zip1.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v1, v0, v1
	stp	q2, q1, [sp, #784]              ; 32-byte Folded Spill
	cbnz	w4, LBB0_720
LBB0_732:                               ; %schedule.16.convergence.cascade.exit353_crit_edge
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w6, s0
LBB0_733:                               ; %convergence.cascade.exit353
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w6, #0xff
	b.eq	LBB0_4
; %bb.734:                              ; %convergence.target.16.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	dup.2d	v0, x2
	ldr	q1, [sp, #1600]                 ; 16-byte Reload
	add.2d	v1, v1, v0
	ldr	q2, [sp, #1584]                 ; 16-byte Reload
	add.2d	v2, v2, v0
	ldr	q3, [sp, #1632]                 ; 16-byte Reload
	add.2d	v3, v3, v0
	ldr	q4, [sp, #1616]                 ; 16-byte Reload
	add.2d	v0, v4, v0
	ldr	q4, [sp, #9376]
	ldr	q5, [sp, #9392]
	ldr	q6, [sp, #9344]
	ldr	q7, [sp, #9360]
	mov	b16, v15[2]
	mov.b	v16[4], v15[3]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	bif.16b	v0, v7, v16
	mov	b7, v15[0]
	mov.b	v7[4], v15[1]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	mov	b16, v15[6]
	mov.b	v16[4], v15[7]
	bif.16b	v3, v6, v7
	ushll.2d	v6, v16, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	bif.16b	v2, v5, v6
	mov	b5, v15[4]
	mov.b	v5[4], v15[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	bif.16b	v1, v4, v5
	str	q1, [sp, #9376]
	str	q2, [sp, #9392]
	str	q3, [sp, #9344]
	str	q0, [sp, #9360]
	ldr	q0, [sp, #1936]                 ; 16-byte Reload
	and.8b	v7, v0, v15
	shl.8b	v0, v7, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v0, v1
	addv.8b	b1, v1
	fmov	w5, s1
	umaxv.8b	b0, v0
	fmov	w6, s0
	tbz	w6, #0, LBB0_740
; %bb.735:                              ; %convergence.target.16.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q0, [sp, #1936]                 ; 16-byte Reload
	bic.8b	v16, v15, v0
	shl.8b	v0, v16, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w6, s0
	tst	w6, #0xff
	b.eq	LBB0_740
; %bb.736:                              ; %varying.divergent374
                                        ;   in Loop: Header=BB0_6 Depth=2
	cmp	w4, #0
	cset	w5, ne
	sub	w5, w4, w5
	and	w6, w0, #0xff
	lsr	w7, w6, w5
	tst	w7, #0x1
	cset	w7, eq
	cmp	w4, #0
	str	q24, [sp, #3408]
	str	q27, [sp, #3424]
	and	x5, x5, #0x7
	add	x19, sp, #3408
	ldr	w5, [x19, x5, lsl #2]
	csinc	w7, w7, wzr, ne
	cmp	w5, #8
	csinc	w5, w7, wzr, eq
	cmp	w6, #255
	b.ne	LBB0_738
; %bb.737:                              ; %varying.divergent374
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #0, LBB0_738
	b	LBB0_1348
LBB0_738:                               ; %convergence.overflow.resume377
                                        ;   in Loop: Header=BB0_6 Depth=2
	mvn	w6, w0
	rbit	w6, w6
	clz	w6, w6
	mov	w7, #255                        ; =0xff
	bics	wzr, w7, w0
	csel	w7, wzr, w6, eq
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #3560
	ldrb	w20, [x6, w7, uxtw]
	and	w19, w20, #0x1
	fmov	s0, w19
	ubfx	w19, w20, #1, #1
	mov.b	v0[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v0[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v0[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v0[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v0[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v0[6], w19
	add	x19, sp, #2, lsl #12            ; =8192
	add	x19, x19, #3552
	lsr	w20, w20, #7
	mov.b	v0[7], w20
	ldrb	w20, [x19, w7, uxtw]
	and	w21, w20, #0x1
	fmov	s1, w21
	ubfx	w21, w20, #1, #1
	mov.b	v1[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v1[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v1[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v1[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v1[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v1[6], w21
	lsr	w20, w20, #7
	mov.b	v1[7], w20
	cmp	w5, #0
	csetm	w20, ne
	dup.8b	v2, w20
	bit.8b	v0, v15, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	ldr	d3, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x6, w7, uxtw]
	bic.8b	v0, v1, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x19, w7, uxtw]
	cmp	x1, #8
	b.hs	LBB0_1348
; %bb.739:                              ; %ready.overflow.resume379
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v0, v16, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	ldp	q3, q1, [sp, #816]              ; 32-byte Folded Reload
	and.16b	v2, v0, v3
	zip1.8b	v0, v16, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v1, v0, v1
	stp	q2, q1, [sp, #816]              ; 32-byte Folded Spill
	str	q9, [sp, #3376]
	ldr	q0, [sp, #1968]                 ; 16-byte Reload
	str	q0, [sp, #3392]
	ubfiz	x6, x7, #2, #3
	add	x19, sp, #3376
	ldr	w19, [x19, x6]
	cmp	w5, #0
	csel	w19, w4, w19, ne
	csinc	w4, w4, w7, eq
	str	q9, [sp, #3344]
	str	q0, [sp, #3360]
	add	x20, sp, #3344
	str	w19, [x20, x6]
	ldr	q0, [sp, #3360]
	str	q0, [sp, #1968]                 ; 16-byte Spill
	ldr	q9, [sp, #3344]
	str	q24, [sp, #3312]
	str	q27, [sp, #3328]
	add	x19, sp, #3312
	ldr	w19, [x19, x6]
	mov	w20, #8                         ; =0x8
	csel	w19, w20, w19, ne
	str	q24, [sp, #3280]
	str	q27, [sp, #3296]
	add	x20, sp, #3280
	str	w19, [x20, x6]
	mov	w6, #18                         ; =0x12
	mov	w19, #17                        ; =0x11
	ldr	q27, [sp, #3296]
	ldr	q24, [sp, #3280]
	b	LBB0_1261
LBB0_740:                               ; %varying.coherent375
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w5, #0xff
	b.eq	LBB0_756
; %bb.741:                              ; %schedule.17.thread
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q0, [sp, #9392]
	ldr	q1, [sp, #9376]
	ldr	q2, [sp, #9360]
	ldr	q3, [sp, #9344]
	shl.2d	v3, v3, #2
	shl.2d	v5, v2, #2
	shl.2d	v1, v1, #2
	dup.2d	v6, x11
	shl.2d	v0, v0, #2
	add.2d	v2, v6, v0
	add.2d	v4, v6, v1
	add.2d	v1, v6, v5
	add.2d	v5, v6, v3
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d3, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	fmov	w5, s0
	movi.2d	v0, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w5, #0, LBB0_1023
; %bb.742:                              ; %else8759
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_1024
LBB0_743:                               ; %else8765
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #2, LBB0_1025
LBB0_744:                               ; %else8771
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_1026
LBB0_745:                               ; %else8777
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #4, LBB0_1027
LBB0_746:                               ; %else8783
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_1028
LBB0_747:                               ; %else8789
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #6, LBB0_1029
LBB0_748:                               ; %else8795
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_750
LBB0_749:                               ; %cond.load8797
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x5, v2[1]
	ld1.s	{ v3 }[3], [x5]
LBB0_750:                               ; %else8801
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #816]                  ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #816]                  ; 16-byte Spill
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #832]                  ; 16-byte Reload
	bit.16b	v2, v0, v1
	str	q2, [sp, #832]                  ; 16-byte Spill
LBB0_751:                               ; %schedule.18
                                        ;   in Loop: Header=BB0_6 Depth=2
	cbz	w4, LBB0_757
LBB0_752:                               ; %convergence.cascade383.preheader
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w5, #0                          ; =0x0
LBB0_753:                               ; %convergence.cascade383
                                        ;   Parent Loop BB0_5 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d6, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v0, v6
	addv.8b	b1, v1
	fmov	w6, s1
	umaxv.8b	b0, v0
	fmov	w20, s0
	sub	w7, w4, #1
	tst	w6, #0xff
	csel	w7, w7, wzr, ne
	mov	w6, #1                          ; =0x1
	lsl	w19, w6, w7
	and	w6, w19, w0
	tst	w6, #0xff
	cset	w22, ne
	str	q24, [sp, #6256]
	str	q27, [sp, #6272]
	ubfiz	x6, x7, #2, #3
	add	x21, sp, #1, lsl #12            ; =4096
	add	x21, x21, #2160
	ldr	w21, [x21, x6]
	cmp	w21, #8
	cset	w21, eq
	and	w22, w22, w20
	add	x20, sp, #2, lsl #12            ; =8192
	add	x20, x20, #3560
	ldrb	w24, [x20, w7, sxtw]
	and	w23, w24, #0x1
	fmov	s0, w23
	ubfx	w23, w24, #1, #1
	mov.b	v0[1], w23
	ubfx	w23, w24, #2, #1
	mov.b	v0[2], w23
	ubfx	w23, w24, #3, #1
	mov.b	v0[3], w23
	ubfx	w23, w24, #4, #1
	mov.b	v0[4], w23
	ubfx	w23, w24, #5, #1
	mov.b	v0[5], w23
	ubfx	w23, w24, #6, #1
	mov.b	v0[6], w23
	add	x23, sp, #2, lsl #12            ; =8192
	add	x23, x23, #3552
	lsr	w24, w24, #7
	mov.b	v0[7], w24
	ldrb	w24, [x23, w7, sxtw]
	and	w25, w24, #0x1
	fmov	s1, w25
	ubfx	w25, w24, #1, #1
	mov.b	v1[1], w25
	ubfx	w25, w24, #2, #1
	mov.b	v1[2], w25
	ubfx	w25, w24, #3, #1
	mov.b	v1[3], w25
	ubfx	w25, w24, #4, #1
	mov.b	v1[4], w25
	ubfx	w25, w24, #5, #1
	mov.b	v1[5], w25
	ubfx	w25, w24, #6, #1
	mov.b	v1[6], w25
	lsr	w24, w24, #7
	mov.b	v1[7], w24
	orr.8b	v2, v15, v1
	ldr	d3, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v3, v0
	eor.8b	v3, v3, v2
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w24, s3
	ands	w21, w22, w21
	csetm	w22, ne
	bics	w24, w21, w24
	csetm	w25, ne
	dup.8b	v3, w25
	bic.8b	v4, v2, v3
	dup.8b	v5, w22
	bit.8b	v1, v4, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v6
	addv.8b	b1, v1
	str	b1, [x23, w7, sxtw]
	bic.8b	v0, v0, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	str	b0, [x20, w7, sxtw]
	mov	w7, #-1                         ; =0xffffffff
	csinv	w7, w7, w19, eq
	and	w0, w7, w0
	dup.8b	v0, w21
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	dup.8b	v1, w24
	and.8b	v1, v1, v2
	str	q9, [sp, #6224]
	ldr	q2, [sp, #1968]                 ; 16-byte Reload
	str	q2, [sp, #6240]
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #2128
	ldr	w6, [x7, x6]
	csel	w4, w6, w4, ne
	bit.8b	v15, v1, v0
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	fmov	w6, s0
	cmp	w21, #1
	b.ne	LBB0_758
; %bb.754:                              ; %convergence.cascade383
                                        ;   in Loop: Header=BB0_753 Depth=3
	cmp	w4, #0
	ccmp	w5, #6, #2, ne
	b.hi	LBB0_758
; %bb.755:                              ; %convergence.cascade383
                                        ;   in Loop: Header=BB0_753 Depth=3
	add	w5, w5, #1
	tst	w6, #0xff
	b.ne	LBB0_753
	b	LBB0_758
LBB0_756:                               ; %varying.coherent.false381
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	ldp	q3, q1, [sp, #816]              ; 32-byte Folded Reload
	and.16b	v2, v0, v3
	zip1.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v1, v0, v1
	stp	q2, q1, [sp, #816]              ; 32-byte Folded Spill
	cbnz	w4, LBB0_752
LBB0_757:                               ; %schedule.18.convergence.cascade.exit384_crit_edge
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w6, s0
LBB0_758:                               ; %convergence.cascade.exit384
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w6, #0xff
	b.eq	LBB0_4
; %bb.759:                              ; %convergence.target.18.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	add	x5, sp, #2, lsl #12             ; =8192
	add	x5, x5, #2776
	ld1r.2d	{ v0 }, [x5]
	ldr	q1, [sp, #1600]                 ; 16-byte Reload
	add.2d	v1, v0, v1
	ldr	q2, [sp, #1584]                 ; 16-byte Reload
	add.2d	v2, v0, v2
	ldr	q3, [sp, #1632]                 ; 16-byte Reload
	add.2d	v3, v0, v3
	ldr	q4, [sp, #1616]                 ; 16-byte Reload
	add.2d	v0, v0, v4
	ldr	q4, [sp, #9312]
	ldr	q5, [sp, #9328]
	ldr	q6, [sp, #9280]
	ldr	q7, [sp, #9296]
	mov	b16, v15[2]
	mov.b	v16[4], v15[3]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	bif.16b	v0, v7, v16
	mov	b7, v15[0]
	mov.b	v7[4], v15[1]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	mov	b16, v15[6]
	mov.b	v16[4], v15[7]
	bif.16b	v3, v6, v7
	ushll.2d	v6, v16, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	bif.16b	v2, v5, v6
	mov	b5, v15[4]
	mov.b	v5[4], v15[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	bif.16b	v1, v4, v5
	str	q1, [sp, #9312]
	str	q2, [sp, #9328]
	str	q3, [sp, #9280]
	str	q0, [sp, #9296]
	ldr	q0, [sp, #1936]                 ; 16-byte Reload
	and.8b	v7, v0, v15
	shl.8b	v0, v7, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v0, v1
	addv.8b	b1, v1
	fmov	w5, s1
	umaxv.8b	b0, v0
	fmov	w6, s0
	tbz	w6, #0, LBB0_765
; %bb.760:                              ; %convergence.target.18.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q0, [sp, #1936]                 ; 16-byte Reload
	bic.8b	v16, v15, v0
	shl.8b	v0, v16, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w6, s0
	tst	w6, #0xff
	b.eq	LBB0_765
; %bb.761:                              ; %varying.divergent405
                                        ;   in Loop: Header=BB0_6 Depth=2
	cmp	w4, #0
	cset	w5, ne
	sub	w5, w4, w5
	and	w6, w0, #0xff
	lsr	w7, w6, w5
	tst	w7, #0x1
	cset	w7, eq
	cmp	w4, #0
	str	q24, [sp, #3568]
	str	q27, [sp, #3584]
	and	x5, x5, #0x7
	add	x19, sp, #3568
	ldr	w5, [x19, x5, lsl #2]
	csinc	w7, w7, wzr, ne
	cmp	w5, #9
	csinc	w5, w7, wzr, eq
	cmp	w6, #255
	b.ne	LBB0_763
; %bb.762:                              ; %varying.divergent405
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #0, LBB0_763
	b	LBB0_1348
LBB0_763:                               ; %convergence.overflow.resume408
                                        ;   in Loop: Header=BB0_6 Depth=2
	mvn	w6, w0
	rbit	w6, w6
	clz	w6, w6
	mov	w7, #255                        ; =0xff
	bics	wzr, w7, w0
	csel	w7, wzr, w6, eq
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #3560
	ldrb	w20, [x6, w7, uxtw]
	and	w19, w20, #0x1
	fmov	s0, w19
	ubfx	w19, w20, #1, #1
	mov.b	v0[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v0[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v0[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v0[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v0[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v0[6], w19
	add	x19, sp, #2, lsl #12            ; =8192
	add	x19, x19, #3552
	lsr	w20, w20, #7
	mov.b	v0[7], w20
	ldrb	w20, [x19, w7, uxtw]
	and	w21, w20, #0x1
	fmov	s1, w21
	ubfx	w21, w20, #1, #1
	mov.b	v1[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v1[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v1[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v1[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v1[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v1[6], w21
	lsr	w20, w20, #7
	mov.b	v1[7], w20
	cmp	w5, #0
	csetm	w20, ne
	dup.8b	v2, w20
	bit.8b	v0, v15, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	ldr	d3, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x6, w7, uxtw]
	bic.8b	v0, v1, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x19, w7, uxtw]
	cmp	x1, #8
	b.hs	LBB0_1348
; %bb.764:                              ; %ready.overflow.resume410
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v0, v16, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	ldp	q3, q1, [sp, #848]              ; 32-byte Folded Reload
	and.16b	v2, v0, v3
	zip1.8b	v0, v16, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v1, v0, v1
	stp	q2, q1, [sp, #848]              ; 32-byte Folded Spill
	str	q9, [sp, #3536]
	ldr	q0, [sp, #1968]                 ; 16-byte Reload
	str	q0, [sp, #3552]
	ubfiz	x6, x7, #2, #3
	add	x19, sp, #3536
	ldr	w19, [x19, x6]
	cmp	w5, #0
	csel	w19, w4, w19, ne
	csinc	w4, w4, w7, eq
	str	q9, [sp, #3504]
	str	q0, [sp, #3520]
	add	x20, sp, #3504
	str	w19, [x20, x6]
	ldr	q0, [sp, #3520]
	str	q0, [sp, #1968]                 ; 16-byte Spill
	ldr	q9, [sp, #3504]
	str	q24, [sp, #3472]
	str	q27, [sp, #3488]
	add	x19, sp, #3472
	ldr	w19, [x19, x6]
	mov	w20, #9                         ; =0x9
	csel	w19, w20, w19, ne
	str	q24, [sp, #3440]
	str	q27, [sp, #3456]
	add	x20, sp, #3440
	str	w19, [x20, x6]
	mov	w6, #20                         ; =0x14
	mov	w19, #19                        ; =0x13
	ldr	q27, [sp, #3456]
	ldr	q24, [sp, #3440]
	b	LBB0_1261
LBB0_765:                               ; %varying.coherent406
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w5, #0xff
	b.eq	LBB0_781
; %bb.766:                              ; %schedule.19.thread
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q0, [sp, #9328]
	ldr	q1, [sp, #9312]
	ldr	q2, [sp, #9296]
	ldr	q3, [sp, #9280]
	shl.2d	v3, v3, #2
	shl.2d	v5, v2, #2
	shl.2d	v1, v1, #2
	dup.2d	v6, x11
	shl.2d	v0, v0, #2
	add.2d	v2, v6, v0
	add.2d	v4, v6, v1
	add.2d	v1, v6, v5
	add.2d	v5, v6, v3
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d3, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	fmov	w5, s0
	movi.2d	v0, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w5, #0, LBB0_1002
; %bb.767:                              ; %else8808
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_1003
LBB0_768:                               ; %else8814
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #2, LBB0_1004
LBB0_769:                               ; %else8820
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_1005
LBB0_770:                               ; %else8826
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #4, LBB0_1006
LBB0_771:                               ; %else8832
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_1007
LBB0_772:                               ; %else8838
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #6, LBB0_1008
LBB0_773:                               ; %else8844
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_775
LBB0_774:                               ; %cond.load8846
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x5, v2[1]
	ld1.s	{ v3 }[3], [x5]
LBB0_775:                               ; %else8850
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #848]                  ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #848]                  ; 16-byte Spill
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #864]                  ; 16-byte Reload
	bit.16b	v2, v0, v1
	str	q2, [sp, #864]                  ; 16-byte Spill
LBB0_776:                               ; %schedule.20
                                        ;   in Loop: Header=BB0_6 Depth=2
	cbz	w4, LBB0_782
LBB0_777:                               ; %convergence.cascade414.preheader
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w5, #0                          ; =0x0
LBB0_778:                               ; %convergence.cascade414
                                        ;   Parent Loop BB0_5 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d6, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v0, v6
	addv.8b	b1, v1
	fmov	w6, s1
	umaxv.8b	b0, v0
	fmov	w20, s0
	sub	w7, w4, #1
	tst	w6, #0xff
	csel	w7, w7, wzr, ne
	mov	w6, #1                          ; =0x1
	lsl	w19, w6, w7
	and	w6, w19, w0
	tst	w6, #0xff
	cset	w22, ne
	str	q24, [sp, #6192]
	str	q27, [sp, #6208]
	ubfiz	x6, x7, #2, #3
	add	x21, sp, #1, lsl #12            ; =4096
	add	x21, x21, #2096
	ldr	w21, [x21, x6]
	cmp	w21, #9
	cset	w21, eq
	and	w22, w22, w20
	add	x20, sp, #2, lsl #12            ; =8192
	add	x20, x20, #3560
	ldrb	w24, [x20, w7, sxtw]
	and	w23, w24, #0x1
	fmov	s0, w23
	ubfx	w23, w24, #1, #1
	mov.b	v0[1], w23
	ubfx	w23, w24, #2, #1
	mov.b	v0[2], w23
	ubfx	w23, w24, #3, #1
	mov.b	v0[3], w23
	ubfx	w23, w24, #4, #1
	mov.b	v0[4], w23
	ubfx	w23, w24, #5, #1
	mov.b	v0[5], w23
	ubfx	w23, w24, #6, #1
	mov.b	v0[6], w23
	add	x23, sp, #2, lsl #12            ; =8192
	add	x23, x23, #3552
	lsr	w24, w24, #7
	mov.b	v0[7], w24
	ldrb	w24, [x23, w7, sxtw]
	and	w25, w24, #0x1
	fmov	s1, w25
	ubfx	w25, w24, #1, #1
	mov.b	v1[1], w25
	ubfx	w25, w24, #2, #1
	mov.b	v1[2], w25
	ubfx	w25, w24, #3, #1
	mov.b	v1[3], w25
	ubfx	w25, w24, #4, #1
	mov.b	v1[4], w25
	ubfx	w25, w24, #5, #1
	mov.b	v1[5], w25
	ubfx	w25, w24, #6, #1
	mov.b	v1[6], w25
	lsr	w24, w24, #7
	mov.b	v1[7], w24
	orr.8b	v2, v15, v1
	ldr	d3, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v3, v0
	eor.8b	v3, v3, v2
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w24, s3
	ands	w21, w22, w21
	csetm	w22, ne
	bics	w24, w21, w24
	csetm	w25, ne
	dup.8b	v3, w25
	bic.8b	v4, v2, v3
	dup.8b	v5, w22
	bit.8b	v1, v4, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v6
	addv.8b	b1, v1
	str	b1, [x23, w7, sxtw]
	bic.8b	v0, v0, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	str	b0, [x20, w7, sxtw]
	mov	w7, #-1                         ; =0xffffffff
	csinv	w7, w7, w19, eq
	and	w0, w7, w0
	dup.8b	v0, w21
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	dup.8b	v1, w24
	and.8b	v1, v1, v2
	str	q9, [sp, #6160]
	ldr	q2, [sp, #1968]                 ; 16-byte Reload
	str	q2, [sp, #6176]
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #2064
	ldr	w6, [x7, x6]
	csel	w4, w6, w4, ne
	bit.8b	v15, v1, v0
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	fmov	w6, s0
	cmp	w21, #1
	b.ne	LBB0_783
; %bb.779:                              ; %convergence.cascade414
                                        ;   in Loop: Header=BB0_778 Depth=3
	cmp	w4, #0
	ccmp	w5, #6, #2, ne
	b.hi	LBB0_783
; %bb.780:                              ; %convergence.cascade414
                                        ;   in Loop: Header=BB0_778 Depth=3
	add	w5, w5, #1
	tst	w6, #0xff
	b.ne	LBB0_778
	b	LBB0_783
LBB0_781:                               ; %varying.coherent.false412
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	ldp	q3, q1, [sp, #848]              ; 32-byte Folded Reload
	and.16b	v2, v0, v3
	zip1.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v1, v0, v1
	stp	q2, q1, [sp, #848]              ; 32-byte Folded Spill
	cbnz	w4, LBB0_777
LBB0_782:                               ; %schedule.20.convergence.cascade.exit415_crit_edge
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w6, s0
LBB0_783:                               ; %convergence.cascade.exit415
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w6, #0xff
	b.eq	LBB0_4
; %bb.784:                              ; %convergence.target.20.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	add	x5, sp, #2, lsl #12             ; =8192
	add	x5, x5, #2712
	ld1r.2d	{ v0 }, [x5]
	ldr	q1, [sp, #1600]                 ; 16-byte Reload
	add.2d	v1, v0, v1
	ldr	q2, [sp, #1584]                 ; 16-byte Reload
	add.2d	v2, v0, v2
	ldr	q3, [sp, #1632]                 ; 16-byte Reload
	add.2d	v3, v0, v3
	ldr	q4, [sp, #1616]                 ; 16-byte Reload
	add.2d	v0, v0, v4
	ldr	q4, [sp, #9248]
	ldr	q5, [sp, #9264]
	ldr	q6, [sp, #9216]
	ldr	q7, [sp, #9232]
	mov	b16, v15[2]
	mov.b	v16[4], v15[3]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	bif.16b	v0, v7, v16
	mov	b7, v15[0]
	mov.b	v7[4], v15[1]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	mov	b16, v15[6]
	mov.b	v16[4], v15[7]
	bif.16b	v3, v6, v7
	ushll.2d	v6, v16, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	bif.16b	v2, v5, v6
	mov	b5, v15[4]
	mov.b	v5[4], v15[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	bif.16b	v1, v4, v5
	str	q1, [sp, #9248]
	str	q2, [sp, #9264]
	str	q3, [sp, #9216]
	str	q0, [sp, #9232]
	ldr	q0, [sp, #1936]                 ; 16-byte Reload
	and.8b	v7, v0, v15
	shl.8b	v0, v7, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v0, v1
	addv.8b	b1, v1
	fmov	w5, s1
	umaxv.8b	b0, v0
	fmov	w6, s0
	tbz	w6, #0, LBB0_790
; %bb.785:                              ; %convergence.target.20.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q0, [sp, #1936]                 ; 16-byte Reload
	bic.8b	v16, v15, v0
	shl.8b	v0, v16, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w6, s0
	tst	w6, #0xff
	b.eq	LBB0_790
; %bb.786:                              ; %varying.divergent436
                                        ;   in Loop: Header=BB0_6 Depth=2
	cmp	w4, #0
	cset	w5, ne
	sub	w5, w4, w5
	and	w6, w0, #0xff
	lsr	w7, w6, w5
	tst	w7, #0x1
	cset	w7, eq
	cmp	w4, #0
	str	q24, [sp, #3728]
	str	q27, [sp, #3744]
	and	x5, x5, #0x7
	add	x19, sp, #3728
	ldr	w5, [x19, x5, lsl #2]
	csinc	w7, w7, wzr, ne
	cmp	w5, #10
	csinc	w5, w7, wzr, eq
	cmp	w6, #255
	b.ne	LBB0_788
; %bb.787:                              ; %varying.divergent436
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #0, LBB0_788
	b	LBB0_1348
LBB0_788:                               ; %convergence.overflow.resume439
                                        ;   in Loop: Header=BB0_6 Depth=2
	mvn	w6, w0
	rbit	w6, w6
	clz	w6, w6
	mov	w7, #255                        ; =0xff
	bics	wzr, w7, w0
	csel	w7, wzr, w6, eq
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #3560
	ldrb	w20, [x6, w7, uxtw]
	and	w19, w20, #0x1
	fmov	s0, w19
	ubfx	w19, w20, #1, #1
	mov.b	v0[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v0[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v0[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v0[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v0[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v0[6], w19
	add	x19, sp, #2, lsl #12            ; =8192
	add	x19, x19, #3552
	lsr	w20, w20, #7
	mov.b	v0[7], w20
	ldrb	w20, [x19, w7, uxtw]
	and	w21, w20, #0x1
	fmov	s1, w21
	ubfx	w21, w20, #1, #1
	mov.b	v1[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v1[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v1[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v1[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v1[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v1[6], w21
	lsr	w20, w20, #7
	mov.b	v1[7], w20
	cmp	w5, #0
	csetm	w20, ne
	dup.8b	v2, w20
	bit.8b	v0, v15, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	ldr	d3, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x6, w7, uxtw]
	bic.8b	v0, v1, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x19, w7, uxtw]
	cmp	x1, #8
	b.hs	LBB0_1348
; %bb.789:                              ; %ready.overflow.resume441
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v0, v16, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	ldp	q3, q1, [sp, #880]              ; 32-byte Folded Reload
	and.16b	v2, v0, v3
	zip1.8b	v0, v16, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v1, v0, v1
	stp	q2, q1, [sp, #880]              ; 32-byte Folded Spill
	str	q9, [sp, #3696]
	ldr	q0, [sp, #1968]                 ; 16-byte Reload
	str	q0, [sp, #3712]
	ubfiz	x6, x7, #2, #3
	add	x19, sp, #3696
	ldr	w19, [x19, x6]
	cmp	w5, #0
	csel	w19, w4, w19, ne
	csinc	w4, w4, w7, eq
	str	q9, [sp, #3664]
	str	q0, [sp, #3680]
	add	x20, sp, #3664
	str	w19, [x20, x6]
	ldr	q0, [sp, #3680]
	str	q0, [sp, #1968]                 ; 16-byte Spill
	ldr	q9, [sp, #3664]
	str	q24, [sp, #3632]
	str	q27, [sp, #3648]
	add	x19, sp, #3632
	ldr	w19, [x19, x6]
	mov	w20, #10                        ; =0xa
	csel	w19, w20, w19, ne
	str	q24, [sp, #3600]
	str	q27, [sp, #3616]
	add	x20, sp, #3600
	str	w19, [x20, x6]
	mov	w6, #22                         ; =0x16
	mov	w19, #21                        ; =0x15
	ldr	q27, [sp, #3616]
	ldr	q24, [sp, #3600]
	b	LBB0_1261
LBB0_790:                               ; %varying.coherent437
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w5, #0xff
	b.eq	LBB0_806
; %bb.791:                              ; %schedule.21.thread
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q0, [sp, #9264]
	ldr	q1, [sp, #9248]
	ldr	q2, [sp, #9232]
	ldr	q3, [sp, #9216]
	shl.2d	v3, v3, #2
	shl.2d	v5, v2, #2
	shl.2d	v1, v1, #2
	dup.2d	v6, x11
	shl.2d	v0, v0, #2
	add.2d	v2, v6, v0
	add.2d	v4, v6, v1
	add.2d	v1, v6, v5
	add.2d	v5, v6, v3
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d3, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	fmov	w5, s0
	movi.2d	v0, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w5, #0, LBB0_981
; %bb.792:                              ; %else8857
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_982
LBB0_793:                               ; %else8863
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #2, LBB0_983
LBB0_794:                               ; %else8869
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_984
LBB0_795:                               ; %else8875
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #4, LBB0_985
LBB0_796:                               ; %else8881
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_986
LBB0_797:                               ; %else8887
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #6, LBB0_987
LBB0_798:                               ; %else8893
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_800
LBB0_799:                               ; %cond.load8895
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x5, v2[1]
	ld1.s	{ v3 }[3], [x5]
LBB0_800:                               ; %else8899
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #880]                  ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #880]                  ; 16-byte Spill
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #896]                  ; 16-byte Reload
	bit.16b	v2, v0, v1
	str	q2, [sp, #896]                  ; 16-byte Spill
LBB0_801:                               ; %schedule.22
                                        ;   in Loop: Header=BB0_6 Depth=2
	cbz	w4, LBB0_807
LBB0_802:                               ; %convergence.cascade445.preheader
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w5, #0                          ; =0x0
LBB0_803:                               ; %convergence.cascade445
                                        ;   Parent Loop BB0_5 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d6, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v0, v6
	addv.8b	b1, v1
	fmov	w6, s1
	umaxv.8b	b0, v0
	fmov	w20, s0
	sub	w7, w4, #1
	tst	w6, #0xff
	csel	w7, w7, wzr, ne
	mov	w6, #1                          ; =0x1
	lsl	w19, w6, w7
	and	w6, w19, w0
	tst	w6, #0xff
	cset	w22, ne
	str	q24, [sp, #6128]
	str	q27, [sp, #6144]
	ubfiz	x6, x7, #2, #3
	add	x21, sp, #1, lsl #12            ; =4096
	add	x21, x21, #2032
	ldr	w21, [x21, x6]
	cmp	w21, #10
	cset	w21, eq
	and	w22, w22, w20
	add	x20, sp, #2, lsl #12            ; =8192
	add	x20, x20, #3560
	ldrb	w24, [x20, w7, sxtw]
	and	w23, w24, #0x1
	fmov	s0, w23
	ubfx	w23, w24, #1, #1
	mov.b	v0[1], w23
	ubfx	w23, w24, #2, #1
	mov.b	v0[2], w23
	ubfx	w23, w24, #3, #1
	mov.b	v0[3], w23
	ubfx	w23, w24, #4, #1
	mov.b	v0[4], w23
	ubfx	w23, w24, #5, #1
	mov.b	v0[5], w23
	ubfx	w23, w24, #6, #1
	mov.b	v0[6], w23
	add	x23, sp, #2, lsl #12            ; =8192
	add	x23, x23, #3552
	lsr	w24, w24, #7
	mov.b	v0[7], w24
	ldrb	w24, [x23, w7, sxtw]
	and	w25, w24, #0x1
	fmov	s1, w25
	ubfx	w25, w24, #1, #1
	mov.b	v1[1], w25
	ubfx	w25, w24, #2, #1
	mov.b	v1[2], w25
	ubfx	w25, w24, #3, #1
	mov.b	v1[3], w25
	ubfx	w25, w24, #4, #1
	mov.b	v1[4], w25
	ubfx	w25, w24, #5, #1
	mov.b	v1[5], w25
	ubfx	w25, w24, #6, #1
	mov.b	v1[6], w25
	lsr	w24, w24, #7
	mov.b	v1[7], w24
	orr.8b	v2, v15, v1
	ldr	d3, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v3, v0
	eor.8b	v3, v3, v2
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w24, s3
	ands	w21, w22, w21
	csetm	w22, ne
	bics	w24, w21, w24
	csetm	w25, ne
	dup.8b	v3, w25
	bic.8b	v4, v2, v3
	dup.8b	v5, w22
	bit.8b	v1, v4, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v6
	addv.8b	b1, v1
	str	b1, [x23, w7, sxtw]
	bic.8b	v0, v0, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	str	b0, [x20, w7, sxtw]
	mov	w7, #-1                         ; =0xffffffff
	csinv	w7, w7, w19, eq
	and	w0, w7, w0
	dup.8b	v0, w21
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	dup.8b	v1, w24
	and.8b	v1, v1, v2
	str	q9, [sp, #6096]
	ldr	q2, [sp, #1968]                 ; 16-byte Reload
	str	q2, [sp, #6112]
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #2000
	ldr	w6, [x7, x6]
	csel	w4, w6, w4, ne
	bit.8b	v15, v1, v0
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	fmov	w6, s0
	cmp	w21, #1
	b.ne	LBB0_808
; %bb.804:                              ; %convergence.cascade445
                                        ;   in Loop: Header=BB0_803 Depth=3
	cmp	w4, #0
	ccmp	w5, #6, #2, ne
	b.hi	LBB0_808
; %bb.805:                              ; %convergence.cascade445
                                        ;   in Loop: Header=BB0_803 Depth=3
	add	w5, w5, #1
	tst	w6, #0xff
	b.ne	LBB0_803
	b	LBB0_808
LBB0_806:                               ; %varying.coherent.false443
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	ldp	q3, q1, [sp, #880]              ; 32-byte Folded Reload
	and.16b	v2, v0, v3
	zip1.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v1, v0, v1
	stp	q2, q1, [sp, #880]              ; 32-byte Folded Spill
	cbnz	w4, LBB0_802
LBB0_807:                               ; %schedule.22.convergence.cascade.exit446_crit_edge
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w6, s0
LBB0_808:                               ; %convergence.cascade.exit446
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w6, #0xff
	b.eq	LBB0_4
; %bb.809:                              ; %convergence.target.22.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q0, [sp, #10240]
	ldr	q1, [sp, #10256]
	ldr	q2, [sp, #10272]
	ldr	q3, [sp, #10288]
	mov.d	x5, v3[1]
	fmov	x6, d3
	add	x6, x6, x6, lsl #1
	lsl	x7, x6, #2
	fmov	d16, x6
	mov.d	x6, v2[1]
	fmov	x19, d2
	add	x19, x19, x19, lsl #1
	lsl	x20, x19, #2
	fmov	d19, x19
	mov.d	x19, v1[1]
	fmov	x21, d1
	add	x21, x21, x21, lsl #1
	lsl	x22, x21, #2
	fmov	d20, x21
	mov.d	x21, v0[1]
	fmov	x23, d0
	add	x23, x23, x23, lsl #1
	lsl	x24, x23, #2
	fmov	d21, x23
	add	x5, x5, x5, lsl #1
	mov.d	v16[1], x5
	add	x6, x6, x6, lsl #1
	mov.d	v19[1], x6
	add	x19, x19, x19, lsl #1
	mov.d	v20[1], x19
	add	x21, x21, x21, lsl #1
	mov.d	v21[1], x21
	fmov	d0, x24
	lsl	x21, x21, #2
	mov.d	v0[1], x21
	fmov	d1, x22
	lsl	x19, x19, #2
	mov.d	v1[1], x19
	fmov	d2, x20
	lsl	x6, x6, #2
	mov.d	v2[1], x6
	fmov	d3, x7
	lsl	x5, x5, #2
	mov.d	v3[1], x5
	dup.2d	v17, x12
	add.2d	v3, v17, v3
	add.2d	v4, v17, v2
	add.2d	v1, v17, v1
	add.2d	v5, v17, v0
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d2, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v2
	addv.8b	b18, v0
	fmov	w5, s18
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w5, #0, LBB0_885
; %bb.810:                              ; %else8906
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_886
LBB0_811:                               ; %else8912
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #2, LBB0_887
LBB0_812:                               ; %else8918
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_888
LBB0_813:                               ; %else8924
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #4, LBB0_889
LBB0_814:                               ; %else8930
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_890
LBB0_815:                               ; %else8936
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #6, LBB0_891
LBB0_816:                               ; %else8942
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_818
LBB0_817:                               ; %cond.load8944
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x5, v3[1]
	ld1.s	{ v2 }[3], [x5]
LBB0_818:                               ; %else8948
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #9200]
	ldr	q3, [sp, #9184]
	fmov	w5, s18
	zip1.8b	v4, v15, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bif.16b	v0, v3, v4
	zip2.8b	v3, v15, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v2, v3
	str	q1, [sp, #9200]
	str	q0, [sp, #9184]
	dup.2d	v5, x3
	add.2d	v0, v20, v5
	add.2d	v1, v21, v5
	add.2d	v2, v19, v5
	add.2d	v3, v16, v5
	shl.2d	v3, v3, #2
	shl.2d	v2, v2, #2
	shl.2d	v4, v1, #2
	shl.2d	v0, v0, #2
	add.2d	v1, v17, v0
	add.2d	v6, v17, v4
	add.2d	v4, v17, v2
	add.2d	v3, v17, v3
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w5, #0, LBB0_892
; %bb.819:                              ; %else8955
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_893
LBB0_820:                               ; %else8961
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #2, LBB0_894
LBB0_821:                               ; %else8967
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_895
LBB0_822:                               ; %else8973
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #4, LBB0_896
LBB0_823:                               ; %else8979
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_897
LBB0_824:                               ; %else8985
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #6, LBB0_898
LBB0_825:                               ; %else8991
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_827
LBB0_826:                               ; %cond.load8993
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x5, v3[1]
	ld1.s	{ v2 }[3], [x5]
LBB0_827:                               ; %else8997
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #9168]
	ldr	q3, [sp, #9152]
	fmov	w5, s18
	zip1.8b	v4, v15, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bif.16b	v0, v3, v4
	zip2.8b	v3, v15, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v2, v3
	str	q1, [sp, #9168]
	str	q0, [sp, #9152]
	dup.2d	v7, x2
	add.2d	v0, v20, v7
	add.2d	v1, v21, v7
	add.2d	v2, v19, v7
	add.2d	v3, v16, v7
	shl.2d	v3, v3, #2
	shl.2d	v2, v2, #2
	shl.2d	v4, v1, #2
	shl.2d	v0, v0, #2
	add.2d	v1, v17, v0
	add.2d	v6, v17, v4
	add.2d	v4, v17, v2
	add.2d	v3, v17, v3
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w5, #0, LBB0_899
; %bb.828:                              ; %else9004
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_900
LBB0_829:                               ; %else9010
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #2, LBB0_901
LBB0_830:                               ; %else9016
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_902
LBB0_831:                               ; %else9022
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #4, LBB0_903
LBB0_832:                               ; %else9028
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_904
LBB0_833:                               ; %else9034
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #6, LBB0_905
LBB0_834:                               ; %else9040
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_836
LBB0_835:                               ; %cond.load9042
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x5, v3[1]
	ld1.s	{ v2 }[3], [x5]
LBB0_836:                               ; %else9046
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #9136]
	ldr	q3, [sp, #9120]
	zip1.8b	v4, v15, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bif.16b	v0, v3, v4
	zip2.8b	v3, v15, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v2, v3
	str	q1, [sp, #9136]
	str	q0, [sp, #9120]
	ldr	q0, [sp, #9920]
	ldr	q1, [sp, #9936]
	ldr	q2, [sp, #9952]
	ldr	q3, [sp, #9968]
	mov.d	x6, v3[1]
	fmov	x5, d3
	add	x5, x5, x5, lsl #1
	fmov	d16, x5
	add	x6, x6, x6, lsl #1
	mov.d	v16[1], x6
	mov.d	x7, v2[1]
	fmov	x19, d2
	add	x19, x19, x19, lsl #1
	lsl	x20, x19, #2
	fmov	d19, x19
	add	x7, x7, x7, lsl #1
	mov.d	v19[1], x7
	mov.d	x19, v1[1]
	fmov	x21, d1
	add	x21, x21, x21, lsl #1
	lsl	x22, x21, #2
	fmov	d20, x21
	add	x19, x19, x19, lsl #1
	mov.d	v20[1], x19
	mov.d	x21, v0[1]
	fmov	x23, d0
	add	x23, x23, x23, lsl #1
	lsl	x24, x23, #2
	fmov	d21, x23
	add	x21, x21, x21, lsl #1
	mov.d	v21[1], x21
	fmov	d0, x24
	lsl	x21, x21, #2
	mov.d	v0[1], x21
	fmov	d1, x22
	lsl	x19, x19, #2
	mov.d	v1[1], x19
	fmov	d2, x20
	lsl	x7, x7, #2
	mov.d	v2[1], x7
	lsl	x5, x5, #2
	fmov	d3, x5
	lsl	x5, x6, #2
	mov.d	v3[1], x5
	fmov	w5, s18
	add.2d	v3, v17, v3
	add.2d	v4, v17, v2
	add.2d	v1, v17, v1
	add.2d	v6, v17, v0
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w5, #0, LBB0_906
; %bb.837:                              ; %else9053
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_907
LBB0_838:                               ; %else9059
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #2, LBB0_908
LBB0_839:                               ; %else9065
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_909
LBB0_840:                               ; %else9071
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #4, LBB0_910
LBB0_841:                               ; %else9077
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_911
LBB0_842:                               ; %else9083
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #6, LBB0_912
LBB0_843:                               ; %else9089
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_845
LBB0_844:                               ; %cond.load9091
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x5, v3[1]
	ld1.s	{ v2 }[3], [x5]
LBB0_845:                               ; %else9095
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #9104]
	ldr	q3, [sp, #9088]
	fmov	w5, s18
	zip1.8b	v4, v15, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bif.16b	v0, v3, v4
	zip2.8b	v3, v15, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v2, v3
	str	q1, [sp, #9104]
	str	q0, [sp, #9088]
	add.2d	v0, v21, v5
	add.2d	v1, v20, v5
	add.2d	v2, v19, v5
	add.2d	v3, v16, v5
	shl.2d	v3, v3, #2
	shl.2d	v2, v2, #2
	shl.2d	v1, v1, #2
	shl.2d	v0, v0, #2
	add.2d	v5, v17, v0
	add.2d	v1, v17, v1
	add.2d	v4, v17, v2
	add.2d	v3, v17, v3
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w5, #0, LBB0_913
; %bb.846:                              ; %else9102
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_914
LBB0_847:                               ; %else9108
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #2, LBB0_915
LBB0_848:                               ; %else9114
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_916
LBB0_849:                               ; %else9120
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #4, LBB0_917
LBB0_850:                               ; %else9126
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_918
LBB0_851:                               ; %else9132
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #6, LBB0_919
LBB0_852:                               ; %else9138
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_854
LBB0_853:                               ; %cond.load9140
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x5, v3[1]
	ld1.s	{ v2 }[3], [x5]
LBB0_854:                               ; %else9144
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #9072]
	ldr	q3, [sp, #9056]
	fmov	w5, s18
	zip1.8b	v4, v15, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bif.16b	v0, v3, v4
	zip2.8b	v3, v15, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v2, v3
	str	q1, [sp, #9072]
	str	q0, [sp, #9056]
	add.2d	v0, v21, v7
	add.2d	v1, v20, v7
	add.2d	v2, v19, v7
	add.2d	v3, v16, v7
	shl.2d	v3, v3, #2
	shl.2d	v2, v2, #2
	shl.2d	v1, v1, #2
	shl.2d	v0, v0, #2
	add.2d	v5, v17, v0
	add.2d	v1, v17, v1
	add.2d	v4, v17, v2
	add.2d	v3, v17, v3
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w5, #0, LBB0_920
; %bb.855:                              ; %else9151
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_921
LBB0_856:                               ; %else9157
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #2, LBB0_922
LBB0_857:                               ; %else9163
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_923
LBB0_858:                               ; %else9169
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #4, LBB0_924
LBB0_859:                               ; %else9175
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_925
LBB0_860:                               ; %else9181
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #6, LBB0_926
LBB0_861:                               ; %else9187
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_863
LBB0_862:                               ; %cond.load9189
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x5, v3[1]
	ld1.s	{ v2 }[3], [x5]
LBB0_863:                               ; %else9193
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #9040]
	ldr	q3, [sp, #9024]
	zip1.8b	v4, v15, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bif.16b	v0, v3, v4
	zip2.8b	v3, v15, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v2, v3
	str	q1, [sp, #9040]
	str	q0, [sp, #9024]
	ldr	q1, [sp, #9632]
	ldr	q3, [sp, #9616]
	ldr	q2, [sp, #9600]
	ldr	q0, [sp, #9648]
	mov.d	x5, v0[1]
	fmov	x6, d0
	add	x6, x6, x6, lsl #1
	fmov	d0, x6
	add	x5, x5, x5, lsl #1
	mov.d	v0[1], x5
	mov.d	x5, v2[1]
	fmov	x6, d2
	add	x6, x6, x6, lsl #1
	fmov	d2, x6
	add	x5, x5, x5, lsl #1
	mov.d	v2[1], x5
	mov.d	x5, v3[1]
	fmov	x6, d3
	add	x6, x6, x6, lsl #1
	fmov	d3, x6
	add	x5, x5, x5, lsl #1
	mov.d	v3[1], x5
	mov.d	x5, v1[1]
	fmov	x6, d1
	add	x6, x6, x6, lsl #1
	fmov	d1, x6
	add	x5, x5, x5, lsl #1
	mov.d	v1[1], x5
	ldr	q4, [sp, #9008]
	ldr	q5, [sp, #8960]
	ldr	q6, [sp, #8976]
	ldr	q7, [sp, #8992]
	mov	b16, v15[4]
	mov.b	v16[4], v15[5]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	bit.16b	v7, v1, v16
	mov	b19, v15[2]
	mov.b	v19[4], v15[3]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	mov	b20, v15[0]
	mov.b	v20[4], v15[1]
	bit.16b	v6, v3, v19
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	bit.16b	v5, v2, v20
	mov	b21, v15[6]
	mov.b	v21[4], v15[7]
	ushll.2d	v21, v21, #0
	shl.2d	v21, v21, #63
	cmlt.2d	v21, v21, #0
	bit.16b	v4, v0, v21
	str	q4, [sp, #9008]
	str	q5, [sp, #8960]
	str	q6, [sp, #8976]
	str	q7, [sp, #8992]
	ldr	q4, [sp, #8928]
	ldr	q5, [sp, #8944]
	ldr	q6, [sp, #8896]
	ldr	q7, [sp, #8912]
	bif.16b	v3, v7, v19
	bif.16b	v2, v6, v20
	bif.16b	v0, v5, v21
	bif.16b	v1, v4, v16
	str	q1, [sp, #8928]
	str	q0, [sp, #8944]
	str	q2, [sp, #8896]
	str	q3, [sp, #8912]
	ldr	q0, [sp, #1936]                 ; 16-byte Reload
	and.8b	v7, v0, v15
	shl.8b	v0, v7, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v0, v1
	addv.8b	b1, v1
	fmov	w5, s1
	umaxv.8b	b0, v0
	fmov	w6, s0
	tbz	w6, #0, LBB0_869
; %bb.864:                              ; %else9193
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q0, [sp, #1936]                 ; 16-byte Reload
	bic.8b	v16, v15, v0
	shl.8b	v0, v16, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w6, s0
	tst	w6, #0xff
	b.eq	LBB0_869
; %bb.865:                              ; %varying.divergent487
                                        ;   in Loop: Header=BB0_6 Depth=2
	cmp	w4, #0
	cset	w5, ne
	sub	w5, w4, w5
	and	w6, w0, #0xff
	lsr	w7, w6, w5
	tst	w7, #0x1
	cset	w7, eq
	cmp	w4, #0
	str	q24, [sp, #3888]
	str	q27, [sp, #3904]
	and	x5, x5, #0x7
	add	x19, sp, #3888
	ldr	w5, [x19, x5, lsl #2]
	csinc	w7, w7, wzr, ne
	cmp	w5, #11
	csinc	w5, w7, wzr, eq
	cmp	w6, #255
	b.ne	LBB0_867
; %bb.866:                              ; %varying.divergent487
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #0, LBB0_1348
LBB0_867:                               ; %convergence.overflow.resume490
                                        ;   in Loop: Header=BB0_6 Depth=2
	mvn	w6, w0
	rbit	w6, w6
	clz	w6, w6
	mov	w7, #255                        ; =0xff
	bics	wzr, w7, w0
	csel	w7, wzr, w6, eq
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #3560
	ldrb	w20, [x6, w7, uxtw]
	and	w19, w20, #0x1
	fmov	s0, w19
	ubfx	w19, w20, #1, #1
	mov.b	v0[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v0[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v0[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v0[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v0[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v0[6], w19
	add	x19, sp, #2, lsl #12            ; =8192
	add	x19, x19, #3552
	lsr	w20, w20, #7
	mov.b	v0[7], w20
	ldrb	w20, [x19, w7, uxtw]
	and	w21, w20, #0x1
	fmov	s1, w21
	ubfx	w21, w20, #1, #1
	mov.b	v1[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v1[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v1[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v1[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v1[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v1[6], w21
	lsr	w20, w20, #7
	mov.b	v1[7], w20
	cmp	w5, #0
	csetm	w20, ne
	dup.8b	v2, w20
	bit.8b	v0, v15, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	ldr	d3, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x6, w7, uxtw]
	bic.8b	v0, v1, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x19, w7, uxtw]
	cmp	x1, #8
	b.hs	LBB0_1348
; %bb.868:                              ; %ready.overflow.resume492
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v0, v16, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	ldp	q3, q1, [sp, #912]              ; 32-byte Folded Reload
	and.16b	v2, v0, v3
	zip1.8b	v0, v16, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v1, v0, v1
	stp	q2, q1, [sp, #912]              ; 32-byte Folded Spill
	str	q9, [sp, #3856]
	ldr	q0, [sp, #1968]                 ; 16-byte Reload
	str	q0, [sp, #3872]
	ubfiz	x6, x7, #2, #3
	add	x19, sp, #3856
	ldr	w19, [x19, x6]
	cmp	w5, #0
	csel	w19, w4, w19, ne
	csinc	w4, w4, w7, eq
	str	q9, [sp, #3824]
	str	q0, [sp, #3840]
	add	x20, sp, #3824
	str	w19, [x20, x6]
	ldr	q0, [sp, #3840]
	str	q0, [sp, #1968]                 ; 16-byte Spill
	ldr	q9, [sp, #3824]
	str	q24, [sp, #3792]
	str	q27, [sp, #3808]
	add	x19, sp, #3792
	ldr	w19, [x19, x6]
	mov	w20, #11                        ; =0xb
	csel	w19, w20, w19, ne
	str	q24, [sp, #3760]
	str	q27, [sp, #3776]
	add	x20, sp, #3760
	str	w19, [x20, x6]
	mov	w6, #24                         ; =0x18
	mov	w19, #23                        ; =0x17
	ldr	q27, [sp, #3776]
	ldr	q24, [sp, #3760]
	b	LBB0_1261
LBB0_869:                               ; %varying.coherent488
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w5, #0xff
	b.eq	LBB0_927
; %bb.870:                              ; %schedule.23.thread
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q0, [sp, #8944]
	ldr	q1, [sp, #8928]
	ldr	q2, [sp, #8912]
	ldr	q3, [sp, #8896]
	shl.2d	v5, v3, #2
	shl.2d	v2, v2, #2
	shl.2d	v1, v1, #2
	shl.2d	v0, v0, #2
	add.2d	v3, v17, v0
	add.2d	v4, v17, v1
	add.2d	v1, v17, v2
	add.2d	v5, v17, v5
	fmov	w5, s18
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w5, #0, LBB0_995
; %bb.871:                              ; %else9200
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_996
LBB0_872:                               ; %else9206
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #2, LBB0_997
LBB0_873:                               ; %else9212
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_998
LBB0_874:                               ; %else9218
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #4, LBB0_999
LBB0_875:                               ; %else9224
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_1000
LBB0_876:                               ; %else9230
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #6, LBB0_1001
LBB0_877:                               ; %else9236
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_879
LBB0_878:                               ; %cond.load9238
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x5, v3[1]
	ld1.s	{ v2 }[3], [x5]
LBB0_879:                               ; %else9242
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q3, [sp, #912]                  ; 16-byte Reload
	bit.16b	v3, v2, v1
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #928]                  ; 16-byte Reload
	bit.16b	v2, v0, v1
	stp	q3, q2, [sp, #912]              ; 32-byte Folded Spill
LBB0_880:                               ; %schedule.24
                                        ;   in Loop: Header=BB0_6 Depth=2
	cbz	w4, LBB0_928
LBB0_881:                               ; %convergence.cascade496.preheader
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w5, #0                          ; =0x0
LBB0_882:                               ; %convergence.cascade496
                                        ;   Parent Loop BB0_5 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d6, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v0, v6
	addv.8b	b1, v1
	fmov	w6, s1
	umaxv.8b	b0, v0
	fmov	w20, s0
	sub	w7, w4, #1
	tst	w6, #0xff
	csel	w7, w7, wzr, ne
	mov	w6, #1                          ; =0x1
	lsl	w19, w6, w7
	and	w6, w19, w0
	tst	w6, #0xff
	cset	w22, ne
	str	q24, [sp, #6064]
	str	q27, [sp, #6080]
	ubfiz	x6, x7, #2, #3
	add	x21, sp, #1, lsl #12            ; =4096
	add	x21, x21, #1968
	ldr	w21, [x21, x6]
	cmp	w21, #11
	cset	w21, eq
	and	w22, w22, w20
	add	x20, sp, #2, lsl #12            ; =8192
	add	x20, x20, #3560
	ldrb	w24, [x20, w7, sxtw]
	and	w23, w24, #0x1
	fmov	s0, w23
	ubfx	w23, w24, #1, #1
	mov.b	v0[1], w23
	ubfx	w23, w24, #2, #1
	mov.b	v0[2], w23
	ubfx	w23, w24, #3, #1
	mov.b	v0[3], w23
	ubfx	w23, w24, #4, #1
	mov.b	v0[4], w23
	ubfx	w23, w24, #5, #1
	mov.b	v0[5], w23
	ubfx	w23, w24, #6, #1
	mov.b	v0[6], w23
	add	x23, sp, #2, lsl #12            ; =8192
	add	x23, x23, #3552
	lsr	w24, w24, #7
	mov.b	v0[7], w24
	ldrb	w24, [x23, w7, sxtw]
	and	w25, w24, #0x1
	fmov	s1, w25
	ubfx	w25, w24, #1, #1
	mov.b	v1[1], w25
	ubfx	w25, w24, #2, #1
	mov.b	v1[2], w25
	ubfx	w25, w24, #3, #1
	mov.b	v1[3], w25
	ubfx	w25, w24, #4, #1
	mov.b	v1[4], w25
	ubfx	w25, w24, #5, #1
	mov.b	v1[5], w25
	ubfx	w25, w24, #6, #1
	mov.b	v1[6], w25
	lsr	w24, w24, #7
	mov.b	v1[7], w24
	orr.8b	v2, v15, v1
	ldr	d3, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v3, v0
	eor.8b	v3, v3, v2
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w24, s3
	ands	w21, w22, w21
	csetm	w22, ne
	bics	w24, w21, w24
	csetm	w25, ne
	dup.8b	v3, w25
	bic.8b	v4, v2, v3
	dup.8b	v5, w22
	bit.8b	v1, v4, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v6
	addv.8b	b1, v1
	str	b1, [x23, w7, sxtw]
	bic.8b	v0, v0, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	str	b0, [x20, w7, sxtw]
	mov	w7, #-1                         ; =0xffffffff
	csinv	w7, w7, w19, eq
	and	w0, w7, w0
	dup.8b	v0, w21
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	dup.8b	v1, w24
	and.8b	v1, v1, v2
	str	q9, [sp, #6032]
	ldr	q2, [sp, #1968]                 ; 16-byte Reload
	str	q2, [sp, #6048]
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #1936
	ldr	w6, [x7, x6]
	csel	w4, w6, w4, ne
	bit.8b	v15, v1, v0
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	fmov	w6, s0
	cmp	w21, #1
	b.ne	LBB0_929
; %bb.883:                              ; %convergence.cascade496
                                        ;   in Loop: Header=BB0_882 Depth=3
	cmp	w4, #0
	ccmp	w5, #6, #2, ne
	b.hi	LBB0_929
; %bb.884:                              ; %convergence.cascade496
                                        ;   in Loop: Header=BB0_882 Depth=3
	add	w5, w5, #1
	tst	w6, #0xff
	b.ne	LBB0_882
	b	LBB0_929
LBB0_885:                               ; %cond.load8902
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d5
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_811
LBB0_886:                               ; %cond.load8908
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v5[1]
	ld1.s	{ v0 }[1], [x6]
	tbz	w5, #2, LBB0_812
LBB0_887:                               ; %cond.load8914
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_813
LBB0_888:                               ; %cond.load8920
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	tbz	w5, #4, LBB0_814
LBB0_889:                               ; %cond.load8926
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d4
	ld1.s	{ v2 }[0], [x6]
	tbz	w5, #5, LBB0_815
LBB0_890:                               ; %cond.load8932
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v4[1]
	ld1.s	{ v2 }[1], [x6]
	tbz	w5, #6, LBB0_816
LBB0_891:                               ; %cond.load8938
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d3
	ld1.s	{ v2 }[2], [x6]
	tbnz	w5, #7, LBB0_817
	b	LBB0_818
LBB0_892:                               ; %cond.load8951
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d6
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_820
LBB0_893:                               ; %cond.load8957
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v6[1]
	ld1.s	{ v0 }[1], [x6]
	tbz	w5, #2, LBB0_821
LBB0_894:                               ; %cond.load8963
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_822
LBB0_895:                               ; %cond.load8969
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	tbz	w5, #4, LBB0_823
LBB0_896:                               ; %cond.load8975
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d4
	ld1.s	{ v2 }[0], [x6]
	tbz	w5, #5, LBB0_824
LBB0_897:                               ; %cond.load8981
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v4[1]
	ld1.s	{ v2 }[1], [x6]
	tbz	w5, #6, LBB0_825
LBB0_898:                               ; %cond.load8987
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d3
	ld1.s	{ v2 }[2], [x6]
	tbnz	w5, #7, LBB0_826
	b	LBB0_827
LBB0_899:                               ; %cond.load9000
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d6
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_829
LBB0_900:                               ; %cond.load9006
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v6[1]
	ld1.s	{ v0 }[1], [x6]
	tbz	w5, #2, LBB0_830
LBB0_901:                               ; %cond.load9012
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_831
LBB0_902:                               ; %cond.load9018
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	tbz	w5, #4, LBB0_832
LBB0_903:                               ; %cond.load9024
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d4
	ld1.s	{ v2 }[0], [x6]
	tbz	w5, #5, LBB0_833
LBB0_904:                               ; %cond.load9030
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v4[1]
	ld1.s	{ v2 }[1], [x6]
	tbz	w5, #6, LBB0_834
LBB0_905:                               ; %cond.load9036
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d3
	ld1.s	{ v2 }[2], [x6]
	tbnz	w5, #7, LBB0_835
	b	LBB0_836
LBB0_906:                               ; %cond.load9049
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d6
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_838
LBB0_907:                               ; %cond.load9055
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v6[1]
	ld1.s	{ v0 }[1], [x6]
	tbz	w5, #2, LBB0_839
LBB0_908:                               ; %cond.load9061
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_840
LBB0_909:                               ; %cond.load9067
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	tbz	w5, #4, LBB0_841
LBB0_910:                               ; %cond.load9073
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d4
	ld1.s	{ v2 }[0], [x6]
	tbz	w5, #5, LBB0_842
LBB0_911:                               ; %cond.load9079
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v4[1]
	ld1.s	{ v2 }[1], [x6]
	tbz	w5, #6, LBB0_843
LBB0_912:                               ; %cond.load9085
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d3
	ld1.s	{ v2 }[2], [x6]
	tbnz	w5, #7, LBB0_844
	b	LBB0_845
LBB0_913:                               ; %cond.load9098
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d5
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_847
LBB0_914:                               ; %cond.load9104
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v5[1]
	ld1.s	{ v0 }[1], [x6]
	tbz	w5, #2, LBB0_848
LBB0_915:                               ; %cond.load9110
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_849
LBB0_916:                               ; %cond.load9116
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	tbz	w5, #4, LBB0_850
LBB0_917:                               ; %cond.load9122
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d4
	ld1.s	{ v2 }[0], [x6]
	tbz	w5, #5, LBB0_851
LBB0_918:                               ; %cond.load9128
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v4[1]
	ld1.s	{ v2 }[1], [x6]
	tbz	w5, #6, LBB0_852
LBB0_919:                               ; %cond.load9134
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d3
	ld1.s	{ v2 }[2], [x6]
	tbnz	w5, #7, LBB0_853
	b	LBB0_854
LBB0_920:                               ; %cond.load9147
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d5
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_856
LBB0_921:                               ; %cond.load9153
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v5[1]
	ld1.s	{ v0 }[1], [x6]
	tbz	w5, #2, LBB0_857
LBB0_922:                               ; %cond.load9159
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_858
LBB0_923:                               ; %cond.load9165
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	tbz	w5, #4, LBB0_859
LBB0_924:                               ; %cond.load9171
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d4
	ld1.s	{ v2 }[0], [x6]
	tbz	w5, #5, LBB0_860
LBB0_925:                               ; %cond.load9177
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v4[1]
	ld1.s	{ v2 }[1], [x6]
	tbz	w5, #6, LBB0_861
LBB0_926:                               ; %cond.load9183
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d3
	ld1.s	{ v2 }[2], [x6]
	tbnz	w5, #7, LBB0_862
	b	LBB0_863
LBB0_927:                               ; %varying.coherent.false494
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	ldp	q3, q1, [sp, #912]              ; 32-byte Folded Reload
	and.16b	v2, v0, v3
	zip1.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v1, v0, v1
	stp	q2, q1, [sp, #912]              ; 32-byte Folded Spill
	cbnz	w4, LBB0_881
LBB0_928:                               ; %schedule.24.convergence.cascade.exit497_crit_edge
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w6, s0
LBB0_929:                               ; %convergence.cascade.exit497
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w6, #0xff
	b.eq	LBB0_4
; %bb.930:                              ; %convergence.target.24.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q0, [sp, #8976]
	ldr	q1, [sp, #8960]
	ldr	q2, [sp, #9008]
	ldr	q3, [sp, #8992]
	dup.2d	v4, x3
	add.2d	v3, v3, v4
	add.2d	v2, v2, v4
	add.2d	v1, v1, v4
	add.2d	v0, v0, v4
	ldr	q4, [sp, #8864]
	ldr	q5, [sp, #8880]
	ldr	q6, [sp, #8832]
	ldr	q7, [sp, #8848]
	mov	b16, v15[2]
	mov.b	v16[4], v15[3]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	bif.16b	v0, v7, v16
	mov	b7, v15[0]
	mov.b	v7[4], v15[1]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	mov	b16, v15[6]
	mov.b	v16[4], v15[7]
	bif.16b	v1, v6, v7
	ushll.2d	v6, v16, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	bif.16b	v2, v5, v6
	mov	b5, v15[4]
	mov.b	v5[4], v15[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	bif.16b	v3, v4, v5
	str	q3, [sp, #8864]
	str	q2, [sp, #8880]
	str	q1, [sp, #8832]
	str	q0, [sp, #8848]
	ldr	q0, [sp, #1936]                 ; 16-byte Reload
	and.8b	v7, v0, v15
	shl.8b	v0, v7, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v0, v1
	addv.8b	b1, v1
	fmov	w5, s1
	umaxv.8b	b0, v0
	fmov	w6, s0
	tbz	w6, #0, LBB0_936
; %bb.931:                              ; %convergence.target.24.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q0, [sp, #1936]                 ; 16-byte Reload
	bic.8b	v16, v15, v0
	shl.8b	v0, v16, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w6, s0
	tst	w6, #0xff
	b.eq	LBB0_936
; %bb.932:                              ; %varying.divergent518
                                        ;   in Loop: Header=BB0_6 Depth=2
	cmp	w4, #0
	cset	w5, ne
	sub	w5, w4, w5
	and	w6, w0, #0xff
	lsr	w7, w6, w5
	tst	w7, #0x1
	cset	w7, eq
	cmp	w4, #0
	str	q24, [sp, #4048]
	str	q27, [sp, #4064]
	and	x5, x5, #0x7
	add	x19, sp, #4048
	ldr	w5, [x19, x5, lsl #2]
	csinc	w7, w7, wzr, ne
	cmp	w5, #12
	csinc	w5, w7, wzr, eq
	cmp	w6, #255
	b.ne	LBB0_934
; %bb.933:                              ; %varying.divergent518
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #0, LBB0_1348
LBB0_934:                               ; %convergence.overflow.resume521
                                        ;   in Loop: Header=BB0_6 Depth=2
	mvn	w6, w0
	rbit	w6, w6
	clz	w6, w6
	mov	w7, #255                        ; =0xff
	bics	wzr, w7, w0
	csel	w7, wzr, w6, eq
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #3560
	ldrb	w20, [x6, w7, uxtw]
	and	w19, w20, #0x1
	fmov	s0, w19
	ubfx	w19, w20, #1, #1
	mov.b	v0[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v0[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v0[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v0[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v0[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v0[6], w19
	add	x19, sp, #2, lsl #12            ; =8192
	add	x19, x19, #3552
	lsr	w20, w20, #7
	mov.b	v0[7], w20
	ldrb	w20, [x19, w7, uxtw]
	and	w21, w20, #0x1
	fmov	s1, w21
	ubfx	w21, w20, #1, #1
	mov.b	v1[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v1[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v1[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v1[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v1[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v1[6], w21
	lsr	w20, w20, #7
	mov.b	v1[7], w20
	cmp	w5, #0
	csetm	w20, ne
	dup.8b	v2, w20
	bit.8b	v0, v15, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	ldr	d3, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x6, w7, uxtw]
	bic.8b	v0, v1, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x19, w7, uxtw]
	cmp	x1, #8
	b.hs	LBB0_1348
; %bb.935:                              ; %ready.overflow.resume523
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v0, v16, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	ldp	q3, q1, [sp, #944]              ; 32-byte Folded Reload
	and.16b	v2, v0, v3
	zip1.8b	v0, v16, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v1, v0, v1
	stp	q2, q1, [sp, #944]              ; 32-byte Folded Spill
	str	q9, [sp, #4016]
	ldr	q0, [sp, #1968]                 ; 16-byte Reload
	str	q0, [sp, #4032]
	ubfiz	x6, x7, #2, #3
	add	x19, sp, #4016
	ldr	w19, [x19, x6]
	cmp	w5, #0
	csel	w19, w4, w19, ne
	csinc	w4, w4, w7, eq
	str	q9, [sp, #3984]
	str	q0, [sp, #4000]
	add	x20, sp, #3984
	str	w19, [x20, x6]
	ldr	q0, [sp, #4000]
	str	q0, [sp, #1968]                 ; 16-byte Spill
	ldr	q9, [sp, #3984]
	str	q24, [sp, #3952]
	str	q27, [sp, #3968]
	add	x19, sp, #3952
	ldr	w19, [x19, x6]
	mov	w20, #12                        ; =0xc
	csel	w19, w20, w19, ne
	str	q24, [sp, #3920]
	str	q27, [sp, #3936]
	add	x20, sp, #3920
	str	w19, [x20, x6]
	mov	w6, #26                         ; =0x1a
	mov	w19, #25                        ; =0x19
	ldr	q27, [sp, #3936]
	ldr	q24, [sp, #3920]
	b	LBB0_1261
LBB0_936:                               ; %varying.coherent519
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w5, #0xff
	b.eq	LBB0_952
; %bb.937:                              ; %schedule.25.thread
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q0, [sp, #8880]
	ldr	q1, [sp, #8864]
	ldr	q2, [sp, #8848]
	ldr	q3, [sp, #8832]
	shl.2d	v3, v3, #2
	shl.2d	v5, v2, #2
	shl.2d	v1, v1, #2
	dup.2d	v6, x12
	shl.2d	v0, v0, #2
	add.2d	v2, v6, v0
	add.2d	v4, v6, v1
	add.2d	v1, v6, v5
	add.2d	v5, v6, v3
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d3, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	fmov	w5, s0
	movi.2d	v0, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w5, #0, LBB0_988
; %bb.938:                              ; %else9249
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_989
LBB0_939:                               ; %else9255
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #2, LBB0_990
LBB0_940:                               ; %else9261
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_991
LBB0_941:                               ; %else9267
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #4, LBB0_992
LBB0_942:                               ; %else9273
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_993
LBB0_943:                               ; %else9279
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #6, LBB0_994
LBB0_944:                               ; %else9285
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_946
LBB0_945:                               ; %cond.load9287
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x5, v2[1]
	ld1.s	{ v3 }[3], [x5]
LBB0_946:                               ; %else9291
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #944]                  ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #944]                  ; 16-byte Spill
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #960]                  ; 16-byte Reload
	bit.16b	v2, v0, v1
	str	q2, [sp, #960]                  ; 16-byte Spill
LBB0_947:                               ; %schedule.26
                                        ;   in Loop: Header=BB0_6 Depth=2
	cbz	w4, LBB0_953
LBB0_948:                               ; %convergence.cascade527.preheader
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w5, #0                          ; =0x0
LBB0_949:                               ; %convergence.cascade527
                                        ;   Parent Loop BB0_5 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d6, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v0, v6
	addv.8b	b1, v1
	fmov	w6, s1
	umaxv.8b	b0, v0
	fmov	w20, s0
	sub	w7, w4, #1
	tst	w6, #0xff
	csel	w7, w7, wzr, ne
	mov	w6, #1                          ; =0x1
	lsl	w19, w6, w7
	and	w6, w19, w0
	tst	w6, #0xff
	cset	w22, ne
	str	q24, [sp, #6000]
	str	q27, [sp, #6016]
	ubfiz	x6, x7, #2, #3
	add	x21, sp, #1, lsl #12            ; =4096
	add	x21, x21, #1904
	ldr	w21, [x21, x6]
	cmp	w21, #12
	cset	w21, eq
	and	w22, w22, w20
	add	x20, sp, #2, lsl #12            ; =8192
	add	x20, x20, #3560
	ldrb	w24, [x20, w7, sxtw]
	and	w23, w24, #0x1
	fmov	s0, w23
	ubfx	w23, w24, #1, #1
	mov.b	v0[1], w23
	ubfx	w23, w24, #2, #1
	mov.b	v0[2], w23
	ubfx	w23, w24, #3, #1
	mov.b	v0[3], w23
	ubfx	w23, w24, #4, #1
	mov.b	v0[4], w23
	ubfx	w23, w24, #5, #1
	mov.b	v0[5], w23
	ubfx	w23, w24, #6, #1
	mov.b	v0[6], w23
	add	x23, sp, #2, lsl #12            ; =8192
	add	x23, x23, #3552
	lsr	w24, w24, #7
	mov.b	v0[7], w24
	ldrb	w24, [x23, w7, sxtw]
	and	w25, w24, #0x1
	fmov	s1, w25
	ubfx	w25, w24, #1, #1
	mov.b	v1[1], w25
	ubfx	w25, w24, #2, #1
	mov.b	v1[2], w25
	ubfx	w25, w24, #3, #1
	mov.b	v1[3], w25
	ubfx	w25, w24, #4, #1
	mov.b	v1[4], w25
	ubfx	w25, w24, #5, #1
	mov.b	v1[5], w25
	ubfx	w25, w24, #6, #1
	mov.b	v1[6], w25
	lsr	w24, w24, #7
	mov.b	v1[7], w24
	orr.8b	v2, v15, v1
	ldr	d3, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v3, v0
	eor.8b	v3, v3, v2
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w24, s3
	ands	w21, w22, w21
	csetm	w22, ne
	bics	w24, w21, w24
	csetm	w25, ne
	dup.8b	v3, w25
	bic.8b	v4, v2, v3
	dup.8b	v5, w22
	bit.8b	v1, v4, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v6
	addv.8b	b1, v1
	str	b1, [x23, w7, sxtw]
	bic.8b	v0, v0, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	str	b0, [x20, w7, sxtw]
	mov	w7, #-1                         ; =0xffffffff
	csinv	w7, w7, w19, eq
	and	w0, w7, w0
	dup.8b	v0, w21
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	dup.8b	v1, w24
	and.8b	v1, v1, v2
	str	q9, [sp, #5968]
	ldr	q2, [sp, #1968]                 ; 16-byte Reload
	str	q2, [sp, #5984]
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #1872
	ldr	w6, [x7, x6]
	csel	w4, w6, w4, ne
	bit.8b	v15, v1, v0
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	fmov	w6, s0
	cmp	w21, #1
	b.ne	LBB0_954
; %bb.950:                              ; %convergence.cascade527
                                        ;   in Loop: Header=BB0_949 Depth=3
	cmp	w4, #0
	ccmp	w5, #6, #2, ne
	b.hi	LBB0_954
; %bb.951:                              ; %convergence.cascade527
                                        ;   in Loop: Header=BB0_949 Depth=3
	add	w5, w5, #1
	tst	w6, #0xff
	b.ne	LBB0_949
	b	LBB0_954
LBB0_952:                               ; %varying.coherent.false525
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	ldp	q3, q1, [sp, #944]              ; 32-byte Folded Reload
	and.16b	v2, v0, v3
	zip1.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v1, v0, v1
	stp	q2, q1, [sp, #944]              ; 32-byte Folded Spill
	cbnz	w4, LBB0_948
LBB0_953:                               ; %schedule.26.convergence.cascade.exit528_crit_edge
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w6, s0
LBB0_954:                               ; %convergence.cascade.exit528
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w6, #0xff
	b.eq	LBB0_4
; %bb.955:                              ; %convergence.target.26.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q0, [sp, #8976]
	ldr	q1, [sp, #8960]
	ldr	q2, [sp, #9008]
	ldr	q3, [sp, #8992]
	dup.2d	v4, x2
	add.2d	v3, v3, v4
	add.2d	v2, v2, v4
	add.2d	v1, v1, v4
	add.2d	v0, v0, v4
	ldr	q4, [sp, #8800]
	ldr	q5, [sp, #8816]
	ldr	q6, [sp, #8768]
	ldr	q7, [sp, #8784]
	mov	b16, v15[2]
	mov.b	v16[4], v15[3]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	bif.16b	v0, v7, v16
	mov	b7, v15[0]
	mov.b	v7[4], v15[1]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	mov	b16, v15[6]
	mov.b	v16[4], v15[7]
	bif.16b	v1, v6, v7
	ushll.2d	v6, v16, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	bif.16b	v2, v5, v6
	mov	b5, v15[4]
	mov.b	v5[4], v15[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	bif.16b	v3, v4, v5
	str	q3, [sp, #8800]
	str	q2, [sp, #8816]
	str	q1, [sp, #8768]
	str	q0, [sp, #8784]
	ldr	q0, [sp, #1936]                 ; 16-byte Reload
	and.8b	v7, v0, v15
	shl.8b	v0, v7, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v0, v1
	addv.8b	b1, v1
	fmov	w5, s1
	umaxv.8b	b0, v0
	fmov	w6, s0
	tbz	w6, #0, LBB0_961
; %bb.956:                              ; %convergence.target.26.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q0, [sp, #1936]                 ; 16-byte Reload
	bic.8b	v16, v15, v0
	shl.8b	v0, v16, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w6, s0
	tst	w6, #0xff
	b.eq	LBB0_961
; %bb.957:                              ; %varying.divergent549
                                        ;   in Loop: Header=BB0_6 Depth=2
	cmp	w4, #0
	cset	w5, ne
	sub	w5, w4, w5
	and	w6, w0, #0xff
	lsr	w7, w6, w5
	tst	w7, #0x1
	cset	w7, eq
	cmp	w4, #0
	str	q24, [sp, #4208]
	str	q27, [sp, #4224]
	and	x5, x5, #0x7
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #112
	ldr	w5, [x19, x5, lsl #2]
	csinc	w7, w7, wzr, ne
	cmp	w5, #13
	csinc	w5, w7, wzr, eq
	cmp	w6, #255
	b.ne	LBB0_959
; %bb.958:                              ; %varying.divergent549
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #0, LBB0_1348
LBB0_959:                               ; %convergence.overflow.resume552
                                        ;   in Loop: Header=BB0_6 Depth=2
	mvn	w6, w0
	rbit	w6, w6
	clz	w6, w6
	mov	w7, #255                        ; =0xff
	bics	wzr, w7, w0
	csel	w7, wzr, w6, eq
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #3560
	ldrb	w20, [x6, w7, uxtw]
	and	w19, w20, #0x1
	fmov	s0, w19
	ubfx	w19, w20, #1, #1
	mov.b	v0[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v0[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v0[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v0[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v0[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v0[6], w19
	add	x19, sp, #2, lsl #12            ; =8192
	add	x19, x19, #3552
	lsr	w20, w20, #7
	mov.b	v0[7], w20
	ldrb	w20, [x19, w7, uxtw]
	and	w21, w20, #0x1
	fmov	s1, w21
	ubfx	w21, w20, #1, #1
	mov.b	v1[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v1[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v1[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v1[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v1[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v1[6], w21
	lsr	w20, w20, #7
	mov.b	v1[7], w20
	cmp	w5, #0
	csetm	w20, ne
	dup.8b	v2, w20
	bit.8b	v0, v15, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	ldr	d3, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x6, w7, uxtw]
	bic.8b	v0, v1, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x19, w7, uxtw]
	cmp	x1, #8
	b.hs	LBB0_1348
; %bb.960:                              ; %ready.overflow.resume554
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v0, v16, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	ldp	q3, q1, [sp, #976]              ; 32-byte Folded Reload
	and.16b	v2, v0, v3
	zip1.8b	v0, v16, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v1, v0, v1
	stp	q2, q1, [sp, #976]              ; 32-byte Folded Spill
	str	q9, [sp, #4176]
	ldr	q0, [sp, #1968]                 ; 16-byte Reload
	str	q0, [sp, #4192]
	ubfiz	x6, x7, #2, #3
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #80
	ldr	w19, [x19, x6]
	cmp	w5, #0
	csel	w19, w4, w19, ne
	csinc	w4, w4, w7, eq
	str	q9, [sp, #4144]
	str	q0, [sp, #4160]
	add	x20, sp, #1, lsl #12            ; =4096
	add	x20, x20, #48
	str	w19, [x20, x6]
	ldr	q0, [sp, #4160]
	str	q0, [sp, #1968]                 ; 16-byte Spill
	ldr	q9, [sp, #4144]
	str	q24, [sp, #4112]
	str	q27, [sp, #4128]
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #16
	ldr	w19, [x19, x6]
	mov	w20, #13                        ; =0xd
	csel	w19, w20, w19, ne
	str	q24, [sp, #4080]
	str	q27, [sp, #4096]
	add	x20, sp, #4080
	str	w19, [x20, x6]
	mov	w6, #28                         ; =0x1c
	mov	w19, #27                        ; =0x1b
	ldr	q27, [sp, #4096]
	ldr	q24, [sp, #4080]
	b	LBB0_1261
LBB0_961:                               ; %varying.coherent550
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w5, #0xff
	b.eq	LBB0_972
; %bb.962:                              ; %schedule.27.thread
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q0, [sp, #8816]
	ldr	q1, [sp, #8800]
	ldr	q2, [sp, #8784]
	ldr	q3, [sp, #8768]
	shl.2d	v3, v3, #2
	shl.2d	v5, v2, #2
	shl.2d	v1, v1, #2
	dup.2d	v6, x12
	shl.2d	v0, v0, #2
	add.2d	v2, v6, v0
	add.2d	v4, v6, v1
	add.2d	v1, v6, v5
	add.2d	v5, v6, v3
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d3, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	fmov	w5, s0
	movi.2d	v0, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w5, #0, LBB0_1016
; %bb.963:                              ; %else9298
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_1017
LBB0_964:                               ; %else9304
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #2, LBB0_1018
LBB0_965:                               ; %else9310
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_1019
LBB0_966:                               ; %else9316
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #4, LBB0_1020
LBB0_967:                               ; %else9322
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_1021
LBB0_968:                               ; %else9328
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #6, LBB0_1022
LBB0_969:                               ; %else9334
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_971
LBB0_970:                               ; %cond.load9336
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x5, v2[1]
	ld1.s	{ v3 }[3], [x5]
LBB0_971:                               ; %else9340
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #976]                  ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #976]                  ; 16-byte Spill
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #992]                  ; 16-byte Reload
	bit.16b	v2, v0, v1
	str	q2, [sp, #992]                  ; 16-byte Spill
	b	LBB0_973
LBB0_972:                               ; %varying.coherent.false556
                                        ;   in Loop: Header=BB0_6 Depth=2
	zip2.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	ldp	q3, q1, [sp, #976]              ; 32-byte Folded Reload
	and.16b	v2, v0, v3
	zip1.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v1, v0, v1
	stp	q2, q1, [sp, #976]              ; 32-byte Folded Spill
LBB0_973:                               ; %schedule.28
                                        ;   in Loop: Header=BB0_6 Depth=2
	str	q23, [sp, #1744]                ; 16-byte Spill
	str	q29, [sp, #1648]                ; 16-byte Spill
	str	q22, [sp, #1712]                ; 16-byte Spill
	str	q26, [sp, #1696]                ; 16-byte Spill
	str	q11, [sp, #1536]                ; 16-byte Spill
	str	q31, [sp, #1472]                ; 16-byte Spill
	str	q9, [sp, #1456]                 ; 16-byte Spill
	str	q27, [sp, #1680]                ; 16-byte Spill
	str	q24, [sp, #1664]                ; 16-byte Spill
	str	q25, [sp, #1728]                ; 16-byte Spill
	str	q8, [sp, #1488]                 ; 16-byte Spill
	str	q10, [sp, #1504]                ; 16-byte Spill
	str	q12, [sp, #1520]                ; 16-byte Spill
	cbz	w4, LBB0_978
; %bb.974:                              ; %convergence.cascade558.preheader
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w6, #0                          ; =0x0
LBB0_975:                               ; %convergence.cascade558
                                        ;   Parent Loop BB0_5 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d6, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v0, v6
	addv.8b	b1, v1
	fmov	w5, s1
	umaxv.8b	b0, v0
	fmov	w20, s0
	sub	w7, w4, #1
	tst	w5, #0xff
	csel	w7, w7, wzr, ne
	mov	w5, #1                          ; =0x1
	lsl	w19, w5, w7
	and	w5, w19, w0
	tst	w5, #0xff
	cset	w22, ne
	str	q24, [sp, #5936]
	str	q27, [sp, #5952]
	ubfiz	x5, x7, #2, #3
	add	x21, sp, #1, lsl #12            ; =4096
	add	x21, x21, #1840
	ldr	w21, [x21, x5]
	cmp	w21, #13
	cset	w21, eq
	and	w22, w22, w20
	add	x20, sp, #2, lsl #12            ; =8192
	add	x20, x20, #3560
	ldrb	w24, [x20, w7, sxtw]
	and	w23, w24, #0x1
	fmov	s0, w23
	ubfx	w23, w24, #1, #1
	mov.b	v0[1], w23
	ubfx	w23, w24, #2, #1
	mov.b	v0[2], w23
	ubfx	w23, w24, #3, #1
	mov.b	v0[3], w23
	ubfx	w23, w24, #4, #1
	mov.b	v0[4], w23
	ubfx	w23, w24, #5, #1
	mov.b	v0[5], w23
	ubfx	w23, w24, #6, #1
	mov.b	v0[6], w23
	add	x23, sp, #2, lsl #12            ; =8192
	add	x23, x23, #3552
	lsr	w24, w24, #7
	mov.b	v0[7], w24
	ldrb	w24, [x23, w7, sxtw]
	and	w25, w24, #0x1
	fmov	s1, w25
	ubfx	w25, w24, #1, #1
	mov.b	v1[1], w25
	ubfx	w25, w24, #2, #1
	mov.b	v1[2], w25
	ubfx	w25, w24, #3, #1
	mov.b	v1[3], w25
	ubfx	w25, w24, #4, #1
	mov.b	v1[4], w25
	ubfx	w25, w24, #5, #1
	mov.b	v1[5], w25
	ubfx	w25, w24, #6, #1
	mov.b	v1[6], w25
	lsr	w24, w24, #7
	mov.b	v1[7], w24
	orr.8b	v2, v15, v1
	ldr	d3, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v3, v0
	eor.8b	v3, v3, v2
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w24, s3
	ands	w21, w22, w21
	csetm	w22, ne
	bics	w24, w21, w24
	csetm	w25, ne
	dup.8b	v3, w25
	bic.8b	v4, v2, v3
	dup.8b	v5, w22
	bit.8b	v1, v4, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v6
	addv.8b	b1, v1
	str	b1, [x23, w7, sxtw]
	bic.8b	v0, v0, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	str	b0, [x20, w7, sxtw]
	mov	w7, #-1                         ; =0xffffffff
	csinv	w7, w7, w19, eq
	and	w0, w7, w0
	dup.8b	v0, w21
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	dup.8b	v1, w24
	and.8b	v1, v1, v2
	str	q9, [sp, #5904]
	ldr	q2, [sp, #1968]                 ; 16-byte Reload
	str	q2, [sp, #5920]
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #1808
	ldr	w5, [x7, x5]
	csel	w4, w5, w4, ne
	bit.8b	v15, v1, v0
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	fmov	w5, s0
	cmp	w21, #1
	b.ne	LBB0_979
; %bb.976:                              ; %convergence.cascade558
                                        ;   in Loop: Header=BB0_975 Depth=3
	cmp	w4, #0
	ccmp	w6, #6, #2, ne
	b.hi	LBB0_979
; %bb.977:                              ; %convergence.cascade558
                                        ;   in Loop: Header=BB0_975 Depth=3
	add	w6, w6, #1
	tst	w5, #0xff
	b.ne	LBB0_975
	b	LBB0_979
LBB0_978:                               ; %schedule.28.convergence.cascade.exit559_crit_edge
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w5, s0
LBB0_979:                               ; %convergence.cascade.exit559
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w5, #0xff
	b.eq	LBB0_4
; %bb.980:                              ; %convergence.target.28.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q0, [sp, #11056]
	ldr	q1, [sp, #11040]
	ldr	q2, [sp, #10224]
	ldr	q3, [sp, #10208]
	fmul.4s	v1, v1, v3
	fmul.4s	v2, v0, v2
	movi.2d	v21, #0000000000000000
	fadd.4s	v2, v2, v21
	fadd.4s	v1, v1, v21
	ldr	q3, [sp, #11008]
	ldr	q4, [sp, #11024]
	ldr	q5, [sp, #10176]
	ldr	q6, [sp, #10192]
	fmul.4s	v4, v4, v6
	fmul.4s	v3, v3, v5
	fadd.4s	v1, v1, v3
	fadd.4s	v2, v2, v4
	ldr	q3, [sp, #10992]
	ldr	q4, [sp, #10976]
	ldr	q5, [sp, #10160]
	ldr	q6, [sp, #10144]
	fmul.4s	v4, v4, v6
	fmul.4s	v3, v3, v5
	fadd.4s	v2, v2, v3
	fadd.4s	v1, v1, v4
	ldr	q3, [sp, #10912]
	ldr	q4, [sp, #10928]
	ldr	q5, [sp, #10112]
	ldr	q6, [sp, #10128]
	fmul.4s	v4, v4, v6
	fmul.4s	v3, v3, v5
	fadd.4s	v1, v1, v3
	fadd.4s	v2, v2, v4
	ldr	q3, [sp, #10864]
	ldr	q4, [sp, #10848]
	ldr	q5, [sp, #10096]
	ldr	q6, [sp, #10080]
	fmul.4s	v4, v4, v6
	fmul.4s	v3, v3, v5
	fadd.4s	v5, v2, v3
	fadd.4s	v0, v1, v4
	stp	q0, q5, [sp, #560]              ; 32-byte Folded Spill
	ldr	q1, [sp, #11056]
	ldr	q4, [sp, #11040]
	ldr	q5, [sp, #9904]
	ldr	q6, [sp, #9888]
	fmul.4s	v4, v4, v6
	fmul.4s	v1, v1, v5
	fadd.4s	v1, v1, v21
	fadd.4s	v4, v4, v21
	ldr	q5, [sp, #11008]
	ldr	q6, [sp, #11024]
	ldr	q7, [sp, #9856]
	ldr	q16, [sp, #9872]
	fmul.4s	v6, v6, v16
	fmul.4s	v5, v5, v7
	fadd.4s	v4, v4, v5
	fadd.4s	v1, v1, v6
	ldr	q5, [sp, #10992]
	ldr	q6, [sp, #10976]
	ldr	q7, [sp, #9840]
	ldr	q16, [sp, #9824]
	fmul.4s	v6, v6, v16
	fmul.4s	v5, v5, v7
	fadd.4s	v1, v1, v5
	fadd.4s	v4, v4, v6
	ldr	q5, [sp, #10912]
	ldr	q6, [sp, #10928]
	ldr	q7, [sp, #9792]
	ldr	q16, [sp, #9808]
	fmul.4s	v6, v6, v16
	fmul.4s	v5, v5, v7
	fadd.4s	v5, v4, v5
	fadd.4s	v1, v1, v6
	ldr	q4, [sp, #10864]
	ldr	q6, [sp, #10848]
	ldr	q7, [sp, #9776]
	ldr	q16, [sp, #9760]
	fmul.4s	v6, v6, v16
	fmul.4s	v4, v4, v7
	fadd.4s	v0, v1, v4
	str	q0, [sp, #544]                  ; 16-byte Spill
	fadd.4s	v5, v5, v6
	ldr	q1, [sp, #11056]
	ldr	q6, [sp, #11040]
	ldp	q13, q12, [sp, #1008]           ; 32-byte Folded Reload
	fmul.4s	v6, v12, v6
	fmul.4s	v1, v13, v1
	fadd.4s	v1, v1, v21
	fadd.4s	v6, v6, v21
	ldr	q7, [sp, #11008]
	ldr	q16, [sp, #11024]
	ldp	q9, q3, [sp, #784]              ; 32-byte Folded Reload
	fmul.4s	v16, v9, v16
	fmul.4s	v7, v3, v7
	fadd.4s	v6, v6, v7
	fadd.4s	v1, v1, v16
	ldr	q7, [sp, #10992]
	ldr	q16, [sp, #10976]
	ldp	q8, q31, [sp, #816]             ; 32-byte Folded Reload
	fmul.4s	v16, v31, v16
	fmul.4s	v7, v8, v7
	fadd.4s	v1, v1, v7
	fadd.4s	v6, v6, v16
	ldr	q7, [sp, #10912]
	ldr	q16, [sp, #10928]
	ldp	q30, q29, [sp, #848]            ; 32-byte Folded Reload
	fmul.4s	v16, v30, v16
	fmul.4s	v7, v29, v7
	fadd.4s	v7, v6, v7
	fadd.4s	v1, v1, v16
	ldr	q6, [sp, #10864]
	ldr	q16, [sp, #10848]
	ldp	q28, q27, [sp, #880]            ; 32-byte Folded Reload
	fmul.4s	v16, v27, v16
	fmul.4s	v6, v28, v6
	fadd.4s	v6, v1, v6
	fadd.4s	v7, v7, v16
	ldr	q1, [sp, #10224]
	ldr	q16, [sp, #10208]
	ldp	q2, q0, [sp, #96]               ; 32-byte Folded Reload
	fmul.4s	v16, v0, v16
	fmul.4s	v1, v2, v1
	fadd.4s	v1, v1, v21
	fadd.4s	v16, v16, v21
	ldr	q17, [sp, #10176]
	ldr	q18, [sp, #10192]
	ldp	q22, q23, [sp, #592]            ; 32-byte Folded Reload
	fmul.4s	v18, v22, v18
	fmul.4s	v17, v23, v17
	fadd.4s	v16, v16, v17
	fadd.4s	v1, v1, v18
	ldr	q17, [sp, #10160]
	ldr	q18, [sp, #10144]
	ldp	q26, q25, [sp, #624]            ; 32-byte Folded Reload
	fmul.4s	v18, v25, v18
	fmul.4s	v17, v26, v17
	fadd.4s	v1, v1, v17
	fadd.4s	v16, v16, v18
	ldr	q17, [sp, #10112]
	ldr	q18, [sp, #10128]
	ldp	q24, q10, [sp, #656]            ; 32-byte Folded Reload
	fmul.4s	v18, v24, v18
	fmul.4s	v17, v10, v17
	fadd.4s	v16, v16, v17
	fadd.4s	v1, v1, v18
	ldr	q17, [sp, #10096]
	ldr	q18, [sp, #10080]
	ldp	q11, q14, [sp, #688]            ; 32-byte Folded Reload
	fmul.4s	v18, v14, v18
	fmul.4s	v17, v11, v17
	fadd.4s	v1, v1, v17
	fadd.4s	v16, v16, v18
	ldr	q17, [sp, #9904]
	ldr	q18, [sp, #9888]
	fmul.4s	v18, v0, v18
	fmul.4s	v17, v2, v17
	fadd.4s	v17, v17, v21
	fadd.4s	v18, v18, v21
	ldr	q19, [sp, #9856]
	ldr	q20, [sp, #9872]
	fmul.4s	v20, v22, v20
	fmul.4s	v19, v23, v19
	fadd.4s	v18, v18, v19
	fadd.4s	v17, v17, v20
	ldr	q19, [sp, #9840]
	ldr	q20, [sp, #9824]
	fmul.4s	v20, v25, v20
	fmul.4s	v19, v26, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v18, v18, v20
	ldr	q19, [sp, #9792]
	ldr	q20, [sp, #9808]
	fmul.4s	v20, v24, v20
	fmul.4s	v19, v10, v19
	fadd.4s	v18, v18, v19
	fadd.4s	v17, v17, v20
	ldr	q19, [sp, #9776]
	ldr	q20, [sp, #9760]
	fmul.4s	v20, v14, v20
	fmul.4s	v19, v11, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v18, v18, v20
	fmul.4s	v19, v0, v12
	fmul.4s	v20, v2, v13
	fadd.4s	v20, v20, v21
	fadd.4s	v0, v19, v21
	fmul.4s	v19, v22, v9
	fmul.4s	v21, v23, v3
	fadd.4s	v0, v0, v21
	fadd.4s	v19, v20, v19
	fmul.4s	v20, v25, v31
	fmul.4s	v21, v26, v8
	fadd.4s	v19, v19, v21
	fadd.4s	v0, v0, v20
	fmul.4s	v20, v24, v30
	fmul.4s	v21, v10, v29
	fadd.4s	v0, v0, v21
	fadd.4s	v19, v19, v20
	fmul.4s	v20, v14, v27
	fmul.4s	v21, v11, v28
	fadd.4s	v19, v19, v21
	fadd.4s	v0, v0, v20
	mov	w6, #63790                      ; =0xf92e
	movk	w6, #16100, lsl #16
	dup.4s	v20, w6
	ldp	q4, q2, [sp, #560]              ; 32-byte Folded Reload
	fmul.4s	v3, v4, v20
	fmul.4s	v2, v2, v20
	stp	q2, q3, [sp, #416]              ; 32-byte Folded Spill
	fmul.4s	v3, v5, v20
	ldr	q2, [sp, #544]                  ; 16-byte Reload
	fmul.4s	v2, v2, v20
	stp	q2, q3, [sp, #448]              ; 32-byte Folded Spill
	fmul.4s	v3, v7, v20
	fmul.4s	v2, v6, v20
	stp	q2, q3, [sp, #480]              ; 32-byte Folded Spill
	fmul.4s	v2, v16, v20
	fmul.4s	v1, v1, v20
	stp	q1, q2, [sp, #512]              ; 32-byte Folded Spill
	fmul.4s	v2, v18, v20
	fmul.4s	v1, v17, v20
	stp	q1, q2, [sp, #544]              ; 32-byte Folded Spill
	fmul.4s	v0, v0, v20
	str	q0, [sp, #400]                  ; 16-byte Spill
	fmul.4s	v0, v19, v20
	str	q0, [sp, #576]                  ; 16-byte Spill
	ldr	q0, [sp, #10304]
	ldr	q1, [sp, #10320]
	ldr	q2, [sp, #10336]
	ldr	q3, [sp, #10352]
	mov	w6, #5                          ; =0x5
	dup.2d	v5, x6
	cmgt.2d	v3, v5, v3
	cmgt.2d	v2, v5, v2
	stp	q3, q2, [sp, #240]              ; 32-byte Folded Spill
	uzp1.4s	v2, v2, v3
	cmgt.2d	v7, v5, v1
	cmgt.2d	v29, v5, v0
	uzp1.4s	v0, v29, v7
	uzp1.8h	v0, v0, v2
	str	q0, [sp, #224]                  ; 16-byte Spill
	ldr	q0, [sp, #9984]
	ldr	q1, [sp, #10000]
	ldr	q2, [sp, #10016]
	ldr	q3, [sp, #10032]
	cmgt.2d	v3, v5, v3
	cmgt.2d	v22, v5, v2
	uzp1.4s	v2, v22, v3
	cmgt.2d	v4, v5, v1
	cmgt.2d	v28, v5, v0
	uzp1.4s	v0, v28, v4
	uzp1.8h	v0, v0, v2
	stp	q0, q3, [sp, #288]              ; 32-byte Folded Spill
	ldr	q13, [sp, #11136]
	ldr	q14, [sp, #11152]
	ldr	q10, [sp, #11168]
	ldr	q11, [sp, #11184]
	ldr	q23, [sp, #10752]
	ldr	q26, [sp, #10768]
	ldr	q0, [sp, #10784]
	ldr	q1, [sp, #10800]
	ldr	q3, [sp, #10304]
	ldr	q2, [sp, #10320]
	ldr	q5, [sp, #10336]
	ldr	q6, [sp, #10352]
	cmge.2d	v27, v11, v6
	cmge.2d	v30, v10, v5
	cmge.2d	v2, v14, v2
	cmge.2d	v3, v13, v3
	uzp1.4s	v5, v30, v27
	uzp1.4s	v6, v3, v2
	uzp1.8h	v5, v6, v5
	str	q5, [sp, #208]                  ; 16-byte Spill
	ldr	q5, [sp, #10304]
	ldr	q6, [sp, #10320]
	ldr	q17, [sp, #10336]
	ldr	q16, [sp, #10352]
	cmge.2d	v16, v1, v16
	cmge.2d	v17, v0, v17
	cmge.2d	v6, v26, v6
	cmge.2d	v5, v23, v5
	uzp1.4s	v19, v17, v16
	uzp1.4s	v20, v5, v6
	uzp1.8h	v31, v20, v19
	ldr	q19, [sp, #9984]
	ldr	q20, [sp, #10000]
	ldr	q21, [sp, #10016]
	ldr	q8, [sp, #10032]
	cmge.2d	v8, v11, v8
	cmge.2d	v21, v10, v21
	cmge.2d	v20, v14, v20
	cmge.2d	v19, v13, v19
	uzp1.4s	v12, v21, v8
	uzp1.4s	v24, v19, v20
	uzp1.8h	v18, v24, v12
	str	q18, [sp, #272]                 ; 16-byte Spill
	ldr	q24, [sp, #9984]
	ldr	q12, [sp, #10000]
	ldr	q9, [sp, #10016]
	ldr	q25, [sp, #10032]
	cmge.2d	v18, v1, v25
	cmge.2d	v25, v0, v9
	stp	q18, q25, [sp, #368]            ; 32-byte Folded Spill
	cmge.2d	v9, v26, v12
	cmge.2d	v12, v23, v24
	stp	q9, q12, [sp, #336]             ; 32-byte Folded Spill
	uzp1.4s	v24, v25, v18
	uzp1.4s	v25, v12, v9
	uzp1.8h	v18, v25, v24
	str	q18, [sp, #320]                 ; 16-byte Spill
	ldr	q24, [sp, #9664]
	ldr	q25, [sp, #9680]
	ldr	q9, [sp, #9696]
	ldr	q12, [sp, #9712]
	cmge.2d	v11, v11, v12
	ldr	d18, [sp, #1992]                ; 8-byte Reload
	cmge.2d	v9, v10, v9
	uzp1.4s	v9, v9, v11
	cmge.2d	v25, v14, v25
	ldr	q12, [sp, #1520]                ; 16-byte Reload
	cmge.2d	v24, v13, v24
	ldr	q14, [sp, #1472]                ; 16-byte Reload
	uzp1.4s	v24, v24, v25
	uzp1.8h	v13, v24, v9
	ldr	q24, [sp, #9664]
	ldr	q25, [sp, #9680]
	ldr	q9, [sp, #9696]
	ldr	q10, [sp, #9712]
	cmge.2d	v1, v1, v10
	cmge.2d	v0, v0, v9
	uzp1.4s	v0, v0, v1
	cmge.2d	v1, v26, v25
	cmge.2d	v23, v23, v24
	uzp1.4s	v1, v23, v1
	uzp1.8h	v23, v1, v0
	and.16b	v0, v7, v2
	and.16b	v1, v29, v3
	uzp1.4s	v26, v1, v0
	ldp	q24, q3, [sp, #240]             ; 32-byte Folded Reload
	and.16b	v0, v24, v27
	and.16b	v1, v3, v30
	uzp1.4s	v27, v1, v0
	ldp	q0, q25, [sp, #208]             ; 32-byte Folded Reload
	and.16b	v0, v25, v0
	xtn.8b	v0, v0
	ldrb	w6, [x9, #5]
	and	w7, w6, #0x1
	ubfx	w19, w6, #1, #1
	fmov	s1, w7
	mov.b	v1[1], w19
	ubfx	w7, w6, #2, #1
	mov.b	v1[2], w7
	ubfx	w7, w6, #3, #1
	mov.b	v1[3], w7
	ubfx	w7, w6, #4, #1
	mov.b	v1[4], w7
	ubfx	w7, w6, #5, #1
	mov.b	v1[5], w7
	ubfx	w7, w6, #6, #1
	mov.b	v1[6], w7
	lsr	w6, w6, #7
	mov.b	v1[7], w6
	shl.8b	v2, v15, #7
	cmlt.8b	v30, v2, #0
	bif.8b	v0, v1, v30
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v18
	addv.8b	b0, v0
	str	b0, [x9, #5]
	and.16b	v0, v25, v31
	and.16b	v1, v7, v6
	and.16b	v2, v29, v5
	uzp1.4s	v9, v2, v1
	and.16b	v1, v24, v16
	and.16b	v2, v3, v17
	uzp1.4s	v17, v2, v1
	xtn.8b	v0, v0
	ldrb	w6, [x9, #4]
	and	w7, w6, #0x1
	ubfx	w19, w6, #1, #1
	fmov	s1, w7
	mov.b	v1[1], w19
	ubfx	w7, w6, #2, #1
	mov.b	v1[2], w7
	ubfx	w7, w6, #3, #1
	mov.b	v1[3], w7
	ubfx	w7, w6, #4, #1
	mov.b	v1[4], w7
	ubfx	w7, w6, #5, #1
	mov.b	v1[5], w7
	ubfx	w7, w6, #6, #1
	mov.b	v1[6], w7
	lsr	w6, w6, #7
	mov.b	v1[7], w6
	bif.8b	v0, v1, v30
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v18
	addv.8b	b0, v0
	str	b0, [x9, #4]
	and.16b	v0, v4, v20
	and.16b	v1, v28, v19
	uzp1.4s	v31, v1, v0
	ldp	q29, q3, [sp, #288]             ; 32-byte Folded Reload
	and.16b	v0, v3, v8
	and.16b	v1, v22, v21
	uzp1.4s	v8, v1, v0
	ldr	q0, [sp, #272]                  ; 16-byte Reload
	and.16b	v0, v29, v0
	xtn.8b	v0, v0
	ldrb	w6, [x9, #3]
	and	w7, w6, #0x1
	ubfx	w19, w6, #1, #1
	fmov	s1, w7
	mov.b	v1[1], w19
	ubfx	w7, w6, #2, #1
	mov.b	v1[2], w7
	ubfx	w7, w6, #3, #1
	mov.b	v1[3], w7
	ubfx	w7, w6, #4, #1
	mov.b	v1[4], w7
	ubfx	w7, w6, #5, #1
	mov.b	v1[5], w7
	ubfx	w7, w6, #6, #1
	mov.b	v1[6], w7
	lsr	w6, w6, #7
	mov.b	v1[7], w6
	bif.8b	v0, v1, v30
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v18
	addv.8b	b0, v0
	str	b0, [x9, #3]
	ldp	q5, q0, [sp, #320]              ; 32-byte Folded Reload
	and.16b	v2, v29, v5
	and.16b	v0, v4, v0
	ldr	q1, [sp, #352]                  ; 16-byte Reload
	and.16b	v1, v28, v1
	uzp1.4s	v1, v1, v0
	xtn.8b	v4, v13
	xtn.8b	v0, v23
	xtn.8b	v5, v2
	ldr	q2, [sp, #368]                  ; 16-byte Reload
	and.16b	v2, v3, v2
	ldr	q3, [sp, #384]                  ; 16-byte Reload
	and.16b	v3, v22, v3
	ldrb	w6, [x9, #2]
	and	w7, w6, #0x1
	fmov	s6, w7
	ubfx	w7, w6, #1, #1
	mov.b	v6[1], w7
	ubfx	w7, w6, #2, #1
	mov.b	v6[2], w7
	ubfx	w7, w6, #3, #1
	mov.b	v6[3], w7
	ubfx	w7, w6, #4, #1
	mov.b	v6[4], w7
	ubfx	w7, w6, #5, #1
	mov.b	v6[5], w7
	ubfx	w7, w6, #6, #1
	mov.b	v6[6], w7
	lsr	w6, w6, #7
	mov.b	v6[7], w6
	bif.8b	v5, v6, v30
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v5, v5, v18
	addv.8b	b5, v5
	str	b5, [x9, #2]
	ldrb	w6, [x9, #837]
	and	w7, w6, #0x1
	fmov	s5, w7
	ubfx	w7, w6, #1, #1
	mov.b	v5[1], w7
	ubfx	w7, w6, #2, #1
	mov.b	v5[2], w7
	ubfx	w7, w6, #3, #1
	mov.b	v5[3], w7
	ubfx	w7, w6, #4, #1
	mov.b	v5[4], w7
	ubfx	w7, w6, #5, #1
	mov.b	v5[5], w7
	ubfx	w7, w6, #6, #1
	mov.b	v5[6], w7
	lsr	w6, w6, #7
	mov.b	v5[7], w6
	and.8b	v5, v4, v5
	ldrb	w6, [x9, #1]
	and	w7, w6, #0x1
	fmov	s4, w7
	ubfx	w7, w6, #1, #1
	mov.b	v4[1], w7
	ubfx	w7, w6, #2, #1
	mov.b	v4[2], w7
	ubfx	w7, w6, #3, #1
	mov.b	v4[3], w7
	ubfx	w7, w6, #4, #1
	mov.b	v4[4], w7
	ubfx	w7, w6, #5, #1
	mov.b	v4[5], w7
	ubfx	w7, w6, #6, #1
	mov.b	v4[6], w7
	lsr	w6, w6, #7
	mov.b	v4[7], w6
	bit.8b	v4, v5, v30
	shl.8b	v4, v4, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v18
	addv.8b	b4, v4
	str	b4, [x9, #1]
	ldrb	w6, [x9, #837]
	and	w7, w6, #0x1
	fmov	s4, w7
	ubfx	w7, w6, #1, #1
	mov.b	v4[1], w7
	ubfx	w7, w6, #2, #1
	mov.b	v4[2], w7
	ubfx	w7, w6, #3, #1
	mov.b	v4[3], w7
	ubfx	w7, w6, #4, #1
	mov.b	v4[4], w7
	ubfx	w7, w6, #5, #1
	mov.b	v4[5], w7
	ubfx	w7, w6, #6, #1
	mov.b	v4[6], w7
	lsr	w6, w6, #7
	mov.b	v4[7], w6
	uzp1.4s	v7, v3, v2
	and.8b	v2, v0, v4
	ldrb	w6, [x9]
	and	w7, w6, #0x1
	fmov	s0, w7
	ubfx	w7, w6, #1, #1
	mov.b	v0[1], w7
	ubfx	w7, w6, #2, #1
	mov.b	v0[2], w7
	ubfx	w7, w6, #3, #1
	mov.b	v0[3], w7
	ubfx	w7, w6, #4, #1
	mov.b	v0[4], w7
	ubfx	w7, w6, #5, #1
	mov.b	v0[5], w7
	ubfx	w7, w6, #6, #1
	mov.b	v0[6], w7
	lsr	w6, w6, #7
	mov.b	v0[7], w6
	bit.8b	v0, v2, v30
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v18
	addv.8b	b0, v0
	str	b0, [x9]
	mov	w6, #62154                      ; =0xf2ca
	movk	w6, #61769, lsl #16
	dup.4s	v18, w6
	ldr	q0, [sp, #416]                  ; 16-byte Reload
	mov.16b	v3, v27
	bsl.16b	v3, v0, v18
	ldr	q0, [sp, #432]                  ; 16-byte Reload
	bsl.16b	v26, v0, v18
	ldr	q0, [sp, #8720]
	ldr	q4, [sp, #8704]
	zip1.8b	v6, v15, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v24, v6, #0
	bit.16b	v4, v26, v24
	zip2.8b	v6, v15, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v25, v6, #0
	bit.16b	v0, v3, v25
	str	q0, [sp, #8720]
	str	q4, [sp, #8704]
	ldp	q4, q0, [sp, #448]              ; 32-byte Folded Reload
	mov.16b	v6, v8
	bsl.16b	v6, v4, v18
	mov.16b	v4, v31
	bsl.16b	v4, v0, v18
	ldr	q0, [sp, #8688]
	ldr	q16, [sp, #8672]
	bit.16b	v16, v4, v24
	bit.16b	v0, v6, v25
	str	q0, [sp, #8688]
	str	q16, [sp, #8672]
	zip2.8b	v0, v5, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	ldp	q19, q16, [sp, #480]            ; 32-byte Folded Reload
	bsl.16b	v0, v19, v18
	zip1.8b	v5, v5, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	mov.16b	v23, v5
	bsl.16b	v23, v16, v18
	ldr	q5, [sp, #8656]
	ldr	q16, [sp, #8640]
	bit.16b	v16, v23, v24
	bit.16b	v5, v0, v25
	str	q5, [sp, #8656]
	str	q16, [sp, #8640]
	ldr	q5, [sp, #512]                  ; 16-byte Reload
	mov.16b	v21, v17
	bsl.16b	v21, v5, v18
	ldr	q5, [sp, #528]                  ; 16-byte Reload
	mov.16b	v20, v9
	bsl.16b	v20, v5, v18
	ldr	q5, [sp, #8624]
	ldr	q16, [sp, #8608]
	bit.16b	v16, v20, v24
	bit.16b	v5, v21, v25
	str	q5, [sp, #8624]
	str	q16, [sp, #8608]
	ldr	q5, [sp, #544]                  ; 16-byte Reload
	mov.16b	v17, v7
	bsl.16b	v17, v5, v18
	ldr	q5, [sp, #560]                  ; 16-byte Reload
	mov.16b	v16, v1
	bsl.16b	v16, v5, v18
	ldr	q1, [sp, #8592]
	ldr	q5, [sp, #8576]
	bit.16b	v5, v16, v24
	bit.16b	v1, v17, v25
	str	q1, [sp, #8592]
	str	q5, [sp, #8576]
	zip2.8b	v1, v2, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q5, [sp, #576]                  ; 16-byte Reload
	mov.16b	v7, v1
	bsl.16b	v7, v5, v18
	zip1.8b	v1, v2, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #400]                  ; 16-byte Reload
	mov.16b	v5, v1
	bsl.16b	v5, v2, v18
	ldr	q1, [sp, #8560]
	ldr	q2, [sp, #8544]
	bit.16b	v2, v5, v24
	bit.16b	v1, v7, v25
	str	q1, [sp, #8560]
	str	q2, [sp, #8544]
	ldr	q9, [sp, #8480]
	ldr	q1, [sp, #8496]
	ldr	q8, [sp, #8448]
	ldr	q31, [sp, #8464]
	ldr	q30, [sp, #8416]
	ldr	q29, [sp, #8432]
	ldr	q28, [sp, #8384]
	ldr	q27, [sp, #8400]
	mov	b2, v15[2]
	mov.b	v2[4], v15[3]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v18, v2, #0
	mov	b2, v15[0]
	mov.b	v2[4], v15[1]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v19, v2, #0
	mov	b2, v15[6]
	mov.b	v2[4], v15[7]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v22, v2, #0
	mov	b2, v15[4]
	mov.b	v2[4], v15[5]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v2, v2, #0
Lloh10:
	adrp	x6, lCPI0_7@PAGE
Lloh11:
	ldr	q10, [x6, lCPI0_7@PAGEOFF]
	bit.16b	v9, v10, v2
	str	q9, [sp, #8480]
Lloh12:
	adrp	x6, lCPI0_6@PAGE
Lloh13:
	ldr	q9, [x6, lCPI0_6@PAGEOFF]
	bit.16b	v1, v9, v22
	str	q1, [sp, #8496]
Lloh14:
	adrp	x6, lCPI0_5@PAGE
Lloh15:
	ldr	q1, [x6, lCPI0_5@PAGEOFF]
	bit.16b	v8, v1, v19
	str	q8, [sp, #8448]
Lloh16:
	adrp	x6, lCPI0_4@PAGE
Lloh17:
	ldr	q8, [x6, lCPI0_4@PAGEOFF]
	bit.16b	v31, v8, v18
	str	q31, [sp, #8464]
	ldr	q31, [sp, #80]                  ; 16-byte Reload
	bit.16b	v30, v31, v2
	str	q30, [sp, #8416]
	bit.16b	v29, v31, v22
	str	q29, [sp, #8432]
	bit.16b	v28, v31, v19
	str	q28, [sp, #8384]
	bit.16b	v27, v31, v18
	str	q27, [sp, #8400]
	ldr	q13, [sp, #1824]                ; 16-byte Reload
	str	q9, [sp, #5568]
	ldr	q9, [sp, #1456]                 ; 16-byte Reload
	str	q10, [sp, #5552]
	ldr	q27, [sp, #1680]                ; 16-byte Reload
	ldr	q11, [sp, #1536]                ; 16-byte Reload
	ldr	q29, [sp, #1744]                ; 16-byte Reload
	str	q8, [sp, #5536]
	ldr	q8, [sp, #1488]                 ; 16-byte Reload
	ldr	q10, [sp, #1504]                ; 16-byte Reload
	rbit	w5, w5
	clz	w6, w5
	str	q1, [sp, #5520]
	ubfiz	x5, x6, #3, #3
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #1424
	ldr	x19, [x7, x5]
	lsl	w6, w6, #2
	add	x7, sp, #2, lsl #12             ; =8192
	add	x7, x7, #3360
	sub	x19, x19, x6
	add	x19, x7, x19
	ldr	q1, [x19]
	bit.16b	v1, v26, v24
	ldr	q26, [x19, #16]
	bif.16b	v3, v26, v25
	ldr	q28, [sp, #1840]                ; 16-byte Reload
	stp	q1, q3, [x19]
Lloh18:
	adrp	x19, lCPI0_8@PAGE
Lloh19:
	ldr	q1, [x19, lCPI0_8@PAGEOFF]
Lloh20:
	adrp	x19, lCPI0_9@PAGE
Lloh21:
	ldr	q3, [x19, lCPI0_9@PAGEOFF]
	str	q1, [sp, #5632]
	str	q3, [sp, #5616]
Lloh22:
	adrp	x19, lCPI0_10@PAGE
Lloh23:
	ldr	q1, [x19, lCPI0_10@PAGEOFF]
Lloh24:
	adrp	x19, lCPI0_11@PAGE
Lloh25:
	ldr	q3, [x19, lCPI0_11@PAGEOFF]
	str	q1, [sp, #5600]
	str	q3, [sp, #5584]
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #1488
	ldr	x19, [x19, x5]
	sub	x19, x19, x6
	add	x19, x7, x19
	ldp	q3, q1, [x19]
	bit.16b	v1, v6, v25
	bit.16b	v3, v4, v24
	stp	q3, q1, [x19]
Lloh26:
	adrp	x19, lCPI0_12@PAGE
Lloh27:
	ldr	q1, [x19, lCPI0_12@PAGEOFF]
Lloh28:
	adrp	x19, lCPI0_13@PAGE
Lloh29:
	ldr	q3, [x19, lCPI0_13@PAGEOFF]
	str	q1, [sp, #5696]
	str	q3, [sp, #5680]
Lloh30:
	adrp	x19, lCPI0_14@PAGE
Lloh31:
	ldr	q1, [x19, lCPI0_14@PAGEOFF]
Lloh32:
	adrp	x19, lCPI0_15@PAGE
Lloh33:
	ldr	q3, [x19, lCPI0_15@PAGEOFF]
	str	q1, [sp, #5664]
	str	q3, [sp, #5648]
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #1552
	ldr	x19, [x19, x5]
	sub	x19, x19, x6
	add	x19, x7, x19
	ldp	q1, q3, [x19]
	bif.16b	v0, v3, v25
	bit.16b	v1, v23, v24
	mov.16b	v23, v29
	ldr	q29, [sp, #1648]                ; 16-byte Reload
	stp	q1, q0, [x19]
Lloh34:
	adrp	x19, lCPI0_16@PAGE
Lloh35:
	ldr	q0, [x19, lCPI0_16@PAGEOFF]
Lloh36:
	adrp	x19, lCPI0_17@PAGE
Lloh37:
	ldr	q1, [x19, lCPI0_17@PAGEOFF]
	str	q0, [sp, #5760]
	str	q1, [sp, #5744]
Lloh38:
	adrp	x19, lCPI0_18@PAGE
Lloh39:
	ldr	q0, [x19, lCPI0_18@PAGEOFF]
Lloh40:
	adrp	x19, lCPI0_19@PAGE
Lloh41:
	ldr	q1, [x19, lCPI0_19@PAGEOFF]
	str	q0, [sp, #5728]
	str	q1, [sp, #5712]
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #1616
	ldr	x19, [x19, x5]
	sub	x19, x19, x6
	add	x19, x7, x19
	ldp	q1, q0, [x19]
	bit.16b	v0, v21, v25
	bit.16b	v1, v20, v24
	stp	q1, q0, [x19]
Lloh42:
	adrp	x19, lCPI0_20@PAGE
Lloh43:
	ldr	q0, [x19, lCPI0_20@PAGEOFF]
Lloh44:
	adrp	x19, lCPI0_21@PAGE
Lloh45:
	ldr	q1, [x19, lCPI0_21@PAGEOFF]
	str	q0, [sp, #5824]
	str	q1, [sp, #5808]
Lloh46:
	adrp	x19, lCPI0_22@PAGE
Lloh47:
	ldr	q0, [x19, lCPI0_22@PAGEOFF]
Lloh48:
	adrp	x19, lCPI0_23@PAGE
Lloh49:
	ldr	q1, [x19, lCPI0_23@PAGEOFF]
	str	q0, [sp, #5792]
	str	q1, [sp, #5776]
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #1680
	ldr	x19, [x19, x5]
	sub	x19, x19, x6
	add	x19, x7, x19
	ldp	q1, q0, [x19]
	bit.16b	v0, v17, v25
	bit.16b	v1, v16, v24
	stp	q1, q0, [x19]
Lloh50:
	adrp	x19, lCPI0_24@PAGE
Lloh51:
	ldr	q0, [x19, lCPI0_24@PAGEOFF]
Lloh52:
	adrp	x19, lCPI0_25@PAGE
Lloh53:
	ldr	q1, [x19, lCPI0_25@PAGEOFF]
	str	q0, [sp, #5888]
	str	q1, [sp, #5872]
Lloh54:
	adrp	x19, lCPI0_26@PAGE
Lloh55:
	ldr	q0, [x19, lCPI0_26@PAGEOFF]
Lloh56:
	adrp	x19, lCPI0_27@PAGE
Lloh57:
	ldr	q1, [x19, lCPI0_27@PAGEOFF]
	str	q0, [sp, #5856]
	str	q1, [sp, #5840]
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #1744
	ldr	x5, [x19, x5]
	sub	x5, x5, x6
	add	x5, x7, x5
	ldp	q1, q0, [x5]
	bit.16b	v0, v7, v25
	bit.16b	v1, v5, v24
	mvni.4s	v3, #127, msl #16
	ldr	q4, [sp, #1328]                 ; 16-byte Reload
	bit.16b	v4, v3, v25
	ldr	q25, [sp, #1728]                ; 16-byte Reload
	str	q4, [sp, #1328]                 ; 16-byte Spill
	ldr	q26, [sp, #1696]                ; 16-byte Reload
	ldr	q4, [sp, #1344]                 ; 16-byte Reload
	bit.16b	v4, v3, v24
	ldr	q24, [sp, #1664]                ; 16-byte Reload
	str	q4, [sp, #1344]                 ; 16-byte Spill
	stp	q1, q0, [x5]
	ldr	q0, [sp, #1808]                 ; 16-byte Reload
	bic.16b	v0, v0, v22
	str	q0, [sp, #1808]                 ; 16-byte Spill
	ldr	q22, [sp, #1712]                ; 16-byte Reload
	bic.16b	v11, v11, v2
	mov.16b	v31, v14
	bic.16b	v13, v13, v18
	str	q13, [sp, #1824]                ; 16-byte Spill
	bic.16b	v28, v28, v19
	str	q28, [sp, #1840]                ; 16-byte Spill
	b	LBB0_1153
LBB0_981:                               ; %cond.load8853
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d5
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_793
LBB0_982:                               ; %cond.load8859
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v5[1]
	ld1.s	{ v0 }[1], [x6]
	tbz	w5, #2, LBB0_794
LBB0_983:                               ; %cond.load8865
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_795
LBB0_984:                               ; %cond.load8871
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	tbz	w5, #4, LBB0_796
LBB0_985:                               ; %cond.load8877
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d4
	ld1.s	{ v3 }[0], [x6]
	tbz	w5, #5, LBB0_797
LBB0_986:                               ; %cond.load8883
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v4[1]
	ld1.s	{ v3 }[1], [x6]
	tbz	w5, #6, LBB0_798
LBB0_987:                               ; %cond.load8889
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d2
	ld1.s	{ v3 }[2], [x6]
	tbnz	w5, #7, LBB0_799
	b	LBB0_800
LBB0_988:                               ; %cond.load9245
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d5
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_939
LBB0_989:                               ; %cond.load9251
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v5[1]
	ld1.s	{ v0 }[1], [x6]
	tbz	w5, #2, LBB0_940
LBB0_990:                               ; %cond.load9257
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_941
LBB0_991:                               ; %cond.load9263
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	tbz	w5, #4, LBB0_942
LBB0_992:                               ; %cond.load9269
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d4
	ld1.s	{ v3 }[0], [x6]
	tbz	w5, #5, LBB0_943
LBB0_993:                               ; %cond.load9275
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v4[1]
	ld1.s	{ v3 }[1], [x6]
	tbz	w5, #6, LBB0_944
LBB0_994:                               ; %cond.load9281
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d2
	ld1.s	{ v3 }[2], [x6]
	tbnz	w5, #7, LBB0_945
	b	LBB0_946
LBB0_995:                               ; %cond.load9196
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d5
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_872
LBB0_996:                               ; %cond.load9202
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v5[1]
	ld1.s	{ v0 }[1], [x6]
	tbz	w5, #2, LBB0_873
LBB0_997:                               ; %cond.load9208
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_874
LBB0_998:                               ; %cond.load9214
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	tbz	w5, #4, LBB0_875
LBB0_999:                               ; %cond.load9220
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d4
	ld1.s	{ v2 }[0], [x6]
	tbz	w5, #5, LBB0_876
LBB0_1000:                              ; %cond.load9226
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v4[1]
	ld1.s	{ v2 }[1], [x6]
	tbz	w5, #6, LBB0_877
LBB0_1001:                              ; %cond.load9232
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d3
	ld1.s	{ v2 }[2], [x6]
	tbnz	w5, #7, LBB0_878
	b	LBB0_879
LBB0_1002:                              ; %cond.load8804
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d5
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_768
LBB0_1003:                              ; %cond.load8810
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v5[1]
	ld1.s	{ v0 }[1], [x6]
	tbz	w5, #2, LBB0_769
LBB0_1004:                              ; %cond.load8816
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_770
LBB0_1005:                              ; %cond.load8822
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	tbz	w5, #4, LBB0_771
LBB0_1006:                              ; %cond.load8828
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d4
	ld1.s	{ v3 }[0], [x6]
	tbz	w5, #5, LBB0_772
LBB0_1007:                              ; %cond.load8834
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v4[1]
	ld1.s	{ v3 }[1], [x6]
	tbz	w5, #6, LBB0_773
LBB0_1008:                              ; %cond.load8840
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d2
	ld1.s	{ v3 }[2], [x6]
	tbnz	w5, #7, LBB0_774
	b	LBB0_775
LBB0_1009:                              ; %cond.load8657
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d5
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_622
LBB0_1010:                              ; %cond.load8663
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v5[1]
	ld1.s	{ v0 }[1], [x6]
	ldr	q22, [sp, #1712]                ; 16-byte Reload
	tbz	w5, #2, LBB0_623
LBB0_1011:                              ; %cond.load8669
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_624
LBB0_1012:                              ; %cond.load8675
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	tbz	w5, #4, LBB0_625
LBB0_1013:                              ; %cond.load8681
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d4
	ld1.s	{ v2 }[0], [x6]
	tbz	w5, #5, LBB0_626
LBB0_1014:                              ; %cond.load8687
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v4[1]
	ld1.s	{ v2 }[1], [x6]
	tbz	w5, #6, LBB0_627
LBB0_1015:                              ; %cond.load8693
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d3
	ld1.s	{ v2 }[2], [x6]
	tbnz	w5, #7, LBB0_628
	b	LBB0_629
LBB0_1016:                              ; %cond.load9294
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d5
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_964
LBB0_1017:                              ; %cond.load9300
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v5[1]
	ld1.s	{ v0 }[1], [x6]
	tbz	w5, #2, LBB0_965
LBB0_1018:                              ; %cond.load9306
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_966
LBB0_1019:                              ; %cond.load9312
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	tbz	w5, #4, LBB0_967
LBB0_1020:                              ; %cond.load9318
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d4
	ld1.s	{ v3 }[0], [x6]
	tbz	w5, #5, LBB0_968
LBB0_1021:                              ; %cond.load9324
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v4[1]
	ld1.s	{ v3 }[1], [x6]
	tbz	w5, #6, LBB0_969
LBB0_1022:                              ; %cond.load9330
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d2
	ld1.s	{ v3 }[2], [x6]
	tbnz	w5, #7, LBB0_970
	b	LBB0_971
LBB0_1023:                              ; %cond.load8755
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d5
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_743
LBB0_1024:                              ; %cond.load8761
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v5[1]
	ld1.s	{ v0 }[1], [x6]
	tbz	w5, #2, LBB0_744
LBB0_1025:                              ; %cond.load8767
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_745
LBB0_1026:                              ; %cond.load8773
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	tbz	w5, #4, LBB0_746
LBB0_1027:                              ; %cond.load8779
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d4
	ld1.s	{ v3 }[0], [x6]
	tbz	w5, #5, LBB0_747
LBB0_1028:                              ; %cond.load8785
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v4[1]
	ld1.s	{ v3 }[1], [x6]
	tbz	w5, #6, LBB0_748
LBB0_1029:                              ; %cond.load8791
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d2
	ld1.s	{ v3 }[2], [x6]
	tbnz	w5, #7, LBB0_749
	b	LBB0_750
LBB0_1030:                              ; %cond.load8706
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d5
	ldr	s0, [x6]
	tbz	w5, #1, LBB0_711
LBB0_1031:                              ; %cond.load8712
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v5[1]
	ld1.s	{ v0 }[1], [x6]
	tbz	w5, #2, LBB0_712
LBB0_1032:                              ; %cond.load8718
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	ld1.s	{ v0 }[2], [x6]
	tbz	w5, #3, LBB0_713
LBB0_1033:                              ; %cond.load8724
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v1[1]
	ld1.s	{ v0 }[3], [x6]
	tbz	w5, #4, LBB0_714
LBB0_1034:                              ; %cond.load8730
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d4
	ld1.s	{ v3 }[0], [x6]
	tbz	w5, #5, LBB0_715
LBB0_1035:                              ; %cond.load8736
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v4[1]
	ld1.s	{ v3 }[1], [x6]
	tbz	w5, #6, LBB0_716
LBB0_1036:                              ; %cond.load8742
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d2
	ld1.s	{ v3 }[2], [x6]
	tbnz	w5, #7, LBB0_717
	b	LBB0_718
LBB0_1037:                              ; %schedule.41.convergence.cascade.exit883_crit_edge
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w6, s0
LBB0_1038:                              ; %convergence.cascade.exit883
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w6, #0xff
	b.eq	LBB0_4
; %bb.1039:                             ; %convergence.target.41.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q0, [sp, #1056]                 ; 16-byte Reload
	ldr	q1, [sp, #1568]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v1
	ldr	q1, [sp, #1136]                 ; 16-byte Reload
	ldr	q16, [sp, #1296]                ; 16-byte Reload
	fdiv.4s	v1, v1, v16
	ldr	q2, [sp, #1152]                 ; 16-byte Reload
	ldr	q7, [sp, #1312]                 ; 16-byte Reload
	fdiv.4s	v2, v2, v7
	ldr	q3, [sp, #7856]
	ldr	q4, [sp, #7840]
	zip1.8b	v5, v15, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	bif.16b	v2, v4, v5
	zip2.8b	v4, v15, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bif.16b	v1, v3, v4
	shl.8b	v3, v15, #7
	cmlt.8b	v3, v3, #0
	ldr	d6, [sp, #1992]                 ; 8-byte Reload
	and.8b	v3, v3, v6
	addv.8b	b17, v3
	fmov	w5, s17
	str	q1, [sp, #7856]
	str	q2, [sp, #7840]
	ldr	q1, [sp, #1168]                 ; 16-byte Reload
	fdiv.4s	v1, v1, v16
	ldr	q2, [sp, #1184]                 ; 16-byte Reload
	fdiv.4s	v2, v2, v7
	ldr	q3, [sp, #7824]
	ldr	q6, [sp, #7808]
	bif.16b	v2, v6, v5
	bif.16b	v1, v3, v4
	str	q1, [sp, #7824]
	str	q2, [sp, #7808]
	ldr	q1, [sp, #1200]                 ; 16-byte Reload
	fdiv.4s	v1, v1, v16
	ldr	q2, [sp, #1216]                 ; 16-byte Reload
	fdiv.4s	v2, v2, v7
	ldr	q3, [sp, #7792]
	ldr	q6, [sp, #7776]
	bif.16b	v2, v6, v5
	bif.16b	v1, v3, v4
	str	q1, [sp, #7792]
	str	q2, [sp, #7776]
	ldr	q4, [sp, #11072]
	ldr	q3, [sp, #11088]
	ldr	q1, [sp, #11104]
	mov.d	x6, v4[1]
	ldr	q2, [sp, #11120]
	fmov	x7, d4
	add	x7, x7, x7, lsl #1
	add	x6, x6, x6, lsl #1
	lsl	x19, x7, #2
	fmov	d4, x19
	lsl	x19, x6, #2
	mov.d	v4[1], x19
	dup.2d	v5, x13
	add.2d	v4, v5, v4
	tbz	w5, #0, LBB0_1041
; %bb.1040:                             ; %cond.store9343
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x19, d4
	str	s0, [x19]
LBB0_1041:                              ; %else9346
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #1, LBB0_1043
; %bb.1042:                             ; %cond.store9347
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x19, v4[1]
	st1.s	{ v0 }[1], [x19]
LBB0_1043:                              ; %else9350
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x19, d3
	add	x19, x19, x19, lsl #1
	mov.d	x20, v3[1]
	add	x20, x20, x20, lsl #1
	lsl	x21, x19, #2
	fmov	d3, x21
	lsl	x21, x20, #2
	mov.d	v3[1], x21
	add.2d	v3, v5, v3
	tbz	w5, #2, LBB0_1045
; %bb.1044:                             ; %cond.store9351
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x21, d3
	st1.s	{ v0 }[2], [x21]
LBB0_1045:                              ; %else9354
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #3, LBB0_1047
; %bb.1046:                             ; %cond.store9355
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x21, v3[1]
	st1.s	{ v0 }[3], [x21]
LBB0_1047:                              ; %else9358
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q0, [sp, #1040]                 ; 16-byte Reload
	ldr	q3, [sp, #1552]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v3
	fmov	x21, d1
	add	x21, x21, x21, lsl #1
	mov.d	x22, v1[1]
	add	x22, x22, x22, lsl #1
	lsl	x23, x21, #2
	fmov	d1, x23
	lsl	x23, x22, #2
	mov.d	v1[1], x23
	add.2d	v1, v5, v1
	tbz	w5, #4, LBB0_1049
; %bb.1048:                             ; %cond.store9359
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x23, d1
	str	s0, [x23]
LBB0_1049:                              ; %else9362
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #5, LBB0_1051
; %bb.1050:                             ; %cond.store9363
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x23, v1[1]
	st1.s	{ v0 }[1], [x23]
LBB0_1051:                              ; %else9366
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x23, d2
	add	x23, x23, x23, lsl #1
	mov.d	x24, v2[1]
	add	x24, x24, x24, lsl #1
	lsl	x25, x23, #2
	fmov	d1, x25
	lsl	x25, x24, #2
	mov.d	v1[1], x25
	add.2d	v1, v5, v1
	tbz	w5, #6, LBB0_1053
; %bb.1052:                             ; %cond.store9367
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x25, d1
	st1.s	{ v0 }[2], [x25]
LBB0_1053:                              ; %else9370
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_1055
; %bb.1054:                             ; %cond.store9371
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x5, v1[1]
	st1.s	{ v0 }[3], [x5]
LBB0_1055:                              ; %else9374
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q0, [sp, #1088]                 ; 16-byte Reload
	ldr	q1, [sp, #1568]                 ; 16-byte Reload
	fdiv.4s	v3, v0, v1
	fmov	d0, x7
	mov.d	v0[1], x6
	dup.2d	v1, x3
	add.2d	v2, v0, v1
	shl.2d	v2, v2, #2
	add.2d	v2, v5, v2
	fmov	w5, s17
	tbnz	w5, #0, LBB0_1127
; %bb.1056:                             ; %else9379
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_1128
LBB0_1057:                              ; %else9383
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	d2, x19
	mov.d	v2[1], x20
	add.2d	v4, v2, v1
	shl.2d	v4, v4, #2
	add.2d	v4, v5, v4
	tbnz	w5, #2, LBB0_1129
LBB0_1058:                              ; %else9387
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #3, LBB0_1060
LBB0_1059:                              ; %cond.store9388
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v4[1]
	st1.s	{ v3 }[3], [x6]
LBB0_1060:                              ; %else9391
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q3, [sp, #1072]                 ; 16-byte Reload
	ldr	q4, [sp, #1552]                 ; 16-byte Reload
	fdiv.4s	v6, v3, v4
	fmov	d3, x21
	mov.d	v3[1], x22
	add.2d	v4, v3, v1
	shl.2d	v4, v4, #2
	add.2d	v4, v5, v4
	tbnz	w5, #4, LBB0_1130
; %bb.1061:                             ; %else9395
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_1131
LBB0_1062:                              ; %else9399
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	d4, x23
	mov.d	v4[1], x24
	add.2d	v1, v4, v1
	shl.2d	v1, v1, #2
	add.2d	v1, v5, v1
	tbnz	w5, #6, LBB0_1132
LBB0_1063:                              ; %else9403
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_1065
LBB0_1064:                              ; %cond.store9404
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x5, v1[1]
	st1.s	{ v6 }[3], [x5]
LBB0_1065:                              ; %else9407
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #1120]                 ; 16-byte Reload
	ldr	q6, [sp, #1568]                 ; 16-byte Reload
	fdiv.4s	v6, v1, v6
	dup.2d	v1, x2
	add.2d	v0, v0, v1
	shl.2d	v0, v0, #2
	add.2d	v0, v5, v0
	fmov	w5, s17
	tbnz	w5, #0, LBB0_1133
; %bb.1066:                             ; %else9412
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_1134
LBB0_1067:                              ; %else9416
                                        ;   in Loop: Header=BB0_6 Depth=2
	add.2d	v0, v2, v1
	shl.2d	v0, v0, #2
	add.2d	v0, v5, v0
	tbnz	w5, #2, LBB0_1135
LBB0_1068:                              ; %else9420
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #3, LBB0_1070
LBB0_1069:                              ; %cond.store9421
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v0[1]
	st1.s	{ v6 }[3], [x6]
LBB0_1070:                              ; %else9424
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q0, [sp, #1104]                 ; 16-byte Reload
	ldr	q2, [sp, #1552]                 ; 16-byte Reload
	fdiv.4s	v0, v0, v2
	add.2d	v2, v3, v1
	shl.2d	v2, v2, #2
	add.2d	v2, v5, v2
	tbnz	w5, #4, LBB0_1136
; %bb.1071:                             ; %else9428
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_1137
LBB0_1072:                              ; %else9432
                                        ;   in Loop: Header=BB0_6 Depth=2
	add.2d	v1, v4, v1
	shl.2d	v1, v1, #2
	add.2d	v1, v5, v1
	tbnz	w5, #6, LBB0_1138
LBB0_1073:                              ; %else9436
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_1075
LBB0_1074:                              ; %cond.store9437
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x5, v1[1]
	st1.s	{ v0 }[3], [x5]
LBB0_1075:                              ; %else9440
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #10720]
	ldr	q3, [sp, #10704]
	ldr	q2, [sp, #10688]
	ldr	q0, [sp, #10736]
	mov.d	x5, v0[1]
	fmov	x6, d0
	add	x6, x6, x6, lsl #1
	fmov	d0, x6
	add	x5, x5, x5, lsl #1
	mov.d	v0[1], x5
	mov.d	x5, v2[1]
	fmov	x6, d2
	add	x6, x6, x6, lsl #1
	fmov	d2, x6
	add	x5, x5, x5, lsl #1
	mov.d	v2[1], x5
	mov.d	x5, v3[1]
	fmov	x6, d3
	add	x6, x6, x6, lsl #1
	fmov	d3, x6
	add	x5, x5, x5, lsl #1
	mov.d	v3[1], x5
	mov.d	x5, v1[1]
	fmov	x6, d1
	add	x6, x6, x6, lsl #1
	fmov	d1, x6
	add	x5, x5, x5, lsl #1
	mov.d	v1[1], x5
	ldr	q4, [sp, #7728]
	ldr	q6, [sp, #7680]
	ldr	q7, [sp, #7696]
	ldr	q16, [sp, #7712]
	mov	b18, v15[4]
	mov.b	v18[4], v15[5]
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	bit.16b	v16, v1, v18
	mov	b19, v15[2]
	mov.b	v19[4], v15[3]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	bit.16b	v7, v3, v19
	mov	b20, v15[0]
	mov.b	v20[4], v15[1]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	bit.16b	v6, v2, v20
	mov	b21, v15[6]
	mov.b	v21[4], v15[7]
	ushll.2d	v21, v21, #0
	shl.2d	v21, v21, #63
	cmlt.2d	v21, v21, #0
	bit.16b	v4, v0, v21
	str	q4, [sp, #7728]
	str	q6, [sp, #7680]
	str	q7, [sp, #7696]
	str	q16, [sp, #7712]
	ldr	q4, [sp, #7648]
	ldr	q6, [sp, #7664]
	ldr	q7, [sp, #7616]
	ldr	q16, [sp, #7632]
	bif.16b	v3, v16, v19
	bif.16b	v2, v7, v20
	bif.16b	v0, v6, v21
	bif.16b	v1, v4, v18
	str	q1, [sp, #7648]
	str	q0, [sp, #7664]
	str	q2, [sp, #7616]
	str	q3, [sp, #7632]
	and.8b	v7, v31, v15
	shl.8b	v0, v7, #7
	cmlt.8b	v0, v0, #0
	umaxv.8b	b1, v0
	fmov	w5, s1
	tbz	w5, #0, LBB0_1081
; %bb.1076:                             ; %else9440
                                        ;   in Loop: Header=BB0_6 Depth=2
	bic.8b	v16, v15, v31
	shl.8b	v1, v16, #7
	cmlt.8b	v1, v1, #0
	ldr	d2, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w5, s1
	tst	w5, #0xff
	b.eq	LBB0_1081
; %bb.1077:                             ; %varying.divergent926
                                        ;   in Loop: Header=BB0_6 Depth=2
	cmp	w4, #0
	cset	w5, ne
	sub	w5, w4, w5
	and	w6, w0, #0xff
	lsr	w7, w6, w5
	tst	w7, #0x1
	cset	w7, eq
	cmp	w4, #0
	str	q24, [sp, #6544]
	str	q27, [sp, #6560]
	and	x5, x5, #0x7
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #2448
	ldr	w5, [x19, x5, lsl #2]
	csinc	w7, w7, wzr, ne
	cmp	w5, #18
	csinc	w5, w7, wzr, eq
	cmp	w6, #255
	b.ne	LBB0_1079
; %bb.1078:                             ; %varying.divergent926
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #0, LBB0_1348
LBB0_1079:                              ; %convergence.overflow.resume929
                                        ;   in Loop: Header=BB0_6 Depth=2
	mvn	w6, w0
	rbit	w6, w6
	clz	w6, w6
	mov	w7, #255                        ; =0xff
	bics	wzr, w7, w0
	csel	w7, wzr, w6, eq
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #3560
	ldrb	w20, [x6, w7, uxtw]
	and	w19, w20, #0x1
	fmov	s0, w19
	ubfx	w19, w20, #1, #1
	mov.b	v0[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v0[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v0[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v0[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v0[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v0[6], w19
	add	x19, sp, #2, lsl #12            ; =8192
	add	x19, x19, #3552
	lsr	w20, w20, #7
	mov.b	v0[7], w20
	ldrb	w20, [x19, w7, uxtw]
	and	w21, w20, #0x1
	fmov	s1, w21
	ubfx	w21, w20, #1, #1
	mov.b	v1[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v1[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v1[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v1[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v1[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v1[6], w21
	lsr	w20, w20, #7
	mov.b	v1[7], w20
	cmp	w5, #0
	csetm	w20, ne
	dup.8b	v2, w20
	bit.8b	v0, v15, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	ldr	d3, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x6, w7, uxtw]
	bic.8b	v0, v1, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x19, w7, uxtw]
	cmp	x1, #8
	b.hs	LBB0_1348
; %bb.1080:                             ; %ready.overflow.resume931
                                        ;   in Loop: Header=BB0_6 Depth=2
	str	q9, [sp, #6512]
	ldr	q0, [sp, #1968]                 ; 16-byte Reload
	str	q0, [sp, #6528]
	ubfiz	x6, x7, #2, #3
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #2416
	ldr	w19, [x19, x6]
	cmp	w5, #0
	csel	w19, w4, w19, ne
	csinc	w4, w4, w7, eq
	str	q9, [sp, #6480]
	str	q0, [sp, #6496]
	add	x20, sp, #1, lsl #12            ; =4096
	add	x20, x20, #2384
	str	w19, [x20, x6]
	ldr	q0, [sp, #6496]
	str	q0, [sp, #1968]                 ; 16-byte Spill
	ldr	q9, [sp, #6480]
	str	q24, [sp, #6448]
	str	q27, [sp, #6464]
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #2352
	ldr	w19, [x19, x6]
	mov	w20, #18                        ; =0x12
	csel	w19, w20, w19, ne
	str	q24, [sp, #6416]
	str	q27, [sp, #6432]
	add	x20, sp, #1, lsl #12            ; =4096
	add	x20, x20, #2320
	str	w19, [x20, x6]
	mov	w6, #43                         ; =0x2b
	mov	w19, #42                        ; =0x2a
	ldr	q27, [sp, #6432]
	ldr	q24, [sp, #6416]
	b	LBB0_1261
LBB0_1081:                              ; %varying.coherent927
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w5, s0
	tst	w5, #0xff
	b.eq	LBB0_1091
; %bb.1082:                             ; %schedule.42.thread
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #7664]
	ldr	q2, [sp, #7648]
	ldr	q4, [sp, #7632]
	ldr	q6, [sp, #7616]
	ldr	q0, [sp, #7856]
	ldr	q3, [sp, #7840]
	shl.2d	v6, v6, #2
	add.2d	v6, v5, v6
	fmov	w5, s17
	tbnz	w5, #0, LBB0_1146
; %bb.1083:                             ; %else9445
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_1147
LBB0_1084:                              ; %else9449
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v4, v4, #2
	add.2d	v4, v5, v4
	tbnz	w5, #2, LBB0_1148
LBB0_1085:                              ; %else9453
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_1149
LBB0_1086:                              ; %else9457
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v2, v2, #2
	add.2d	v2, v5, v2
	tbnz	w5, #4, LBB0_1150
LBB0_1087:                              ; %else9461
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_1151
LBB0_1088:                              ; %else9465
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v1, #2
	add.2d	v1, v5, v1
	tbnz	w5, #6, LBB0_1152
LBB0_1089:                              ; %else9469
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_1091
LBB0_1090:                              ; %cond.store9470
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x5, v1[1]
	st1.s	{ v0 }[3], [x5]
LBB0_1091:                              ; %schedule.43
                                        ;   in Loop: Header=BB0_6 Depth=2
	cbz	w4, LBB0_1096
; %bb.1092:                             ; %convergence.cascade936.preheader
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w5, #0                          ; =0x0
LBB0_1093:                              ; %convergence.cascade936
                                        ;   Parent Loop BB0_5 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d6, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v0, v6
	addv.8b	b1, v1
	fmov	w6, s1
	umaxv.8b	b0, v0
	fmov	w20, s0
	sub	w7, w4, #1
	tst	w6, #0xff
	csel	w7, w7, wzr, ne
	mov	w6, #1                          ; =0x1
	lsl	w19, w6, w7
	and	w6, w19, w0
	tst	w6, #0xff
	cset	w22, ne
	str	q24, [sp, #7056]
	str	q27, [sp, #7072]
	ubfiz	x6, x7, #2, #3
	add	x21, sp, #1, lsl #12            ; =4096
	add	x21, x21, #2960
	ldr	w21, [x21, x6]
	cmp	w21, #18
	cset	w21, eq
	and	w22, w22, w20
	add	x20, sp, #2, lsl #12            ; =8192
	add	x20, x20, #3560
	ldrb	w24, [x20, w7, sxtw]
	and	w23, w24, #0x1
	fmov	s0, w23
	ubfx	w23, w24, #1, #1
	mov.b	v0[1], w23
	ubfx	w23, w24, #2, #1
	mov.b	v0[2], w23
	ubfx	w23, w24, #3, #1
	mov.b	v0[3], w23
	ubfx	w23, w24, #4, #1
	mov.b	v0[4], w23
	ubfx	w23, w24, #5, #1
	mov.b	v0[5], w23
	ubfx	w23, w24, #6, #1
	mov.b	v0[6], w23
	add	x23, sp, #2, lsl #12            ; =8192
	add	x23, x23, #3552
	lsr	w24, w24, #7
	mov.b	v0[7], w24
	ldrb	w24, [x23, w7, sxtw]
	and	w25, w24, #0x1
	fmov	s1, w25
	ubfx	w25, w24, #1, #1
	mov.b	v1[1], w25
	ubfx	w25, w24, #2, #1
	mov.b	v1[2], w25
	ubfx	w25, w24, #3, #1
	mov.b	v1[3], w25
	ubfx	w25, w24, #4, #1
	mov.b	v1[4], w25
	ubfx	w25, w24, #5, #1
	mov.b	v1[5], w25
	ubfx	w25, w24, #6, #1
	mov.b	v1[6], w25
	lsr	w24, w24, #7
	mov.b	v1[7], w24
	orr.8b	v2, v15, v1
	ldr	d3, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v3, v0
	eor.8b	v3, v3, v2
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w24, s3
	ands	w21, w22, w21
	csetm	w22, ne
	bics	w24, w21, w24
	csetm	w25, ne
	dup.8b	v3, w25
	bic.8b	v4, v2, v3
	dup.8b	v5, w22
	bit.8b	v1, v4, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v6
	addv.8b	b1, v1
	str	b1, [x23, w7, sxtw]
	bic.8b	v0, v0, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	str	b0, [x20, w7, sxtw]
	mov	w7, #-1                         ; =0xffffffff
	csinv	w7, w7, w19, eq
	and	w0, w7, w0
	dup.8b	v0, w21
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	dup.8b	v1, w24
	and.8b	v1, v1, v2
	str	q9, [sp, #7024]
	ldr	q2, [sp, #1968]                 ; 16-byte Reload
	str	q2, [sp, #7040]
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #2928
	ldr	w6, [x7, x6]
	csel	w4, w6, w4, ne
	bit.8b	v15, v1, v0
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	fmov	w6, s0
	cmp	w21, #1
	b.ne	LBB0_1097
; %bb.1094:                             ; %convergence.cascade936
                                        ;   in Loop: Header=BB0_1093 Depth=3
	cmp	w4, #0
	ccmp	w5, #6, #2, ne
	b.hi	LBB0_1097
; %bb.1095:                             ; %convergence.cascade936
                                        ;   in Loop: Header=BB0_1093 Depth=3
	add	w5, w5, #1
	tst	w6, #0xff
	b.ne	LBB0_1093
	b	LBB0_1097
LBB0_1096:                              ; %schedule.43.convergence.cascade.exit937_crit_edge
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w6, s0
LBB0_1097:                              ; %convergence.cascade.exit937
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w6, #0xff
	b.eq	LBB0_4
; %bb.1098:                             ; %convergence.target.43.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q0, [sp, #7696]
	ldr	q1, [sp, #7680]
	ldr	q2, [sp, #7728]
	ldr	q3, [sp, #7712]
	dup.2d	v4, x3
	add.2d	v3, v3, v4
	add.2d	v2, v2, v4
	add.2d	v1, v1, v4
	add.2d	v0, v0, v4
	ldr	q4, [sp, #7584]
	ldr	q5, [sp, #7600]
	ldr	q6, [sp, #7552]
	ldr	q7, [sp, #7568]
	mov	b16, v15[2]
	mov.b	v16[4], v15[3]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	bif.16b	v0, v7, v16
	mov	b7, v15[0]
	mov.b	v7[4], v15[1]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	bif.16b	v1, v6, v7
	mov	b6, v15[6]
	mov.b	v6[4], v15[7]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	bif.16b	v2, v5, v6
	mov	b5, v15[4]
	mov.b	v5[4], v15[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	bif.16b	v3, v4, v5
	str	q3, [sp, #7584]
	str	q2, [sp, #7600]
	str	q1, [sp, #7552]
	str	q0, [sp, #7568]
	and.8b	v7, v31, v15
	shl.8b	v0, v7, #7
	cmlt.8b	v0, v0, #0
	umaxv.8b	b1, v0
	fmov	w5, s1
	tbz	w5, #0, LBB0_1104
; %bb.1099:                             ; %convergence.target.43.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	bic.8b	v16, v15, v31
	shl.8b	v1, v16, #7
	cmlt.8b	v1, v1, #0
	ldr	d2, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w5, s1
	tst	w5, #0xff
	b.eq	LBB0_1104
; %bb.1100:                             ; %varying.divergent958
                                        ;   in Loop: Header=BB0_6 Depth=2
	cmp	w4, #0
	cset	w5, ne
	sub	w5, w4, w5
	and	w6, w0, #0xff
	lsr	w7, w6, w5
	tst	w7, #0x1
	cset	w7, eq
	cmp	w4, #0
	str	q24, [sp, #6704]
	str	q27, [sp, #6720]
	and	x5, x5, #0x7
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #2608
	ldr	w5, [x19, x5, lsl #2]
	csinc	w7, w7, wzr, ne
	cmp	w5, #19
	csinc	w5, w7, wzr, eq
	cmp	w6, #255
	b.ne	LBB0_1102
; %bb.1101:                             ; %varying.divergent958
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #0, LBB0_1348
LBB0_1102:                              ; %convergence.overflow.resume961
                                        ;   in Loop: Header=BB0_6 Depth=2
	mvn	w6, w0
	rbit	w6, w6
	clz	w6, w6
	mov	w7, #255                        ; =0xff
	bics	wzr, w7, w0
	csel	w7, wzr, w6, eq
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #3560
	ldrb	w20, [x6, w7, uxtw]
	and	w19, w20, #0x1
	fmov	s0, w19
	ubfx	w19, w20, #1, #1
	mov.b	v0[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v0[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v0[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v0[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v0[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v0[6], w19
	add	x19, sp, #2, lsl #12            ; =8192
	add	x19, x19, #3552
	lsr	w20, w20, #7
	mov.b	v0[7], w20
	ldrb	w20, [x19, w7, uxtw]
	and	w21, w20, #0x1
	fmov	s1, w21
	ubfx	w21, w20, #1, #1
	mov.b	v1[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v1[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v1[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v1[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v1[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v1[6], w21
	lsr	w20, w20, #7
	mov.b	v1[7], w20
	cmp	w5, #0
	csetm	w20, ne
	dup.8b	v2, w20
	bit.8b	v0, v15, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	ldr	d3, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x6, w7, uxtw]
	bic.8b	v0, v1, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x19, w7, uxtw]
	cmp	x1, #8
	b.hs	LBB0_1348
; %bb.1103:                             ; %ready.overflow.resume963
                                        ;   in Loop: Header=BB0_6 Depth=2
	str	q9, [sp, #6672]
	ldr	q0, [sp, #1968]                 ; 16-byte Reload
	str	q0, [sp, #6688]
	ubfiz	x6, x7, #2, #3
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #2576
	ldr	w19, [x19, x6]
	cmp	w5, #0
	csel	w19, w4, w19, ne
	csinc	w4, w4, w7, eq
	str	q9, [sp, #6640]
	str	q0, [sp, #6656]
	add	x20, sp, #1, lsl #12            ; =4096
	add	x20, x20, #2544
	str	w19, [x20, x6]
	ldr	q0, [sp, #6656]
	str	q0, [sp, #1968]                 ; 16-byte Spill
	ldr	q9, [sp, #6640]
	str	q24, [sp, #6608]
	str	q27, [sp, #6624]
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #2512
	ldr	w19, [x19, x6]
	mov	w20, #19                        ; =0x13
	csel	w19, w20, w19, ne
	str	q24, [sp, #6576]
	str	q27, [sp, #6592]
	add	x20, sp, #1, lsl #12            ; =4096
	add	x20, x20, #2480
	str	w19, [x20, x6]
	mov	w6, #45                         ; =0x2d
	mov	w19, #44                        ; =0x2c
	ldr	q27, [sp, #6592]
	ldr	q24, [sp, #6576]
	b	LBB0_1261
LBB0_1104:                              ; %varying.coherent959
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w5, s0
	tst	w5, #0xff
	b.eq	LBB0_1114
; %bb.1105:                             ; %schedule.44.thread
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #7600]
	ldr	q3, [sp, #7584]
	ldr	q5, [sp, #7568]
	ldr	q2, [sp, #7552]
	ldr	q0, [sp, #7824]
	ldr	q4, [sp, #7808]
	shl.2d	v6, v2, #2
	dup.2d	v2, x13
	add.2d	v6, v2, v6
	shl.8b	v7, v15, #7
	cmlt.8b	v7, v7, #0
	ldr	d16, [sp, #1992]                ; 8-byte Reload
	and.8b	v7, v7, v16
	addv.8b	b7, v7
	fmov	w5, s7
	tbnz	w5, #0, LBB0_1139
; %bb.1106:                             ; %else9478
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #1, LBB0_1140
LBB0_1107:                              ; %else9482
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v5, v5, #2
	add.2d	v5, v2, v5
	tbnz	w5, #2, LBB0_1141
LBB0_1108:                              ; %else9486
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #3, LBB0_1142
LBB0_1109:                              ; %else9490
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v3, v3, #2
	add.2d	v3, v2, v3
	tbnz	w5, #4, LBB0_1143
LBB0_1110:                              ; %else9494
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #5, LBB0_1144
LBB0_1111:                              ; %else9498
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.2d	v1, v1, #2
	add.2d	v1, v2, v1
	tbnz	w5, #6, LBB0_1145
LBB0_1112:                              ; %else9502
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w5, #7, LBB0_1114
LBB0_1113:                              ; %cond.store9503
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x5, v1[1]
	st1.s	{ v0 }[3], [x5]
LBB0_1114:                              ; %schedule.45
                                        ;   in Loop: Header=BB0_6 Depth=2
	cbz	w4, LBB0_1119
; %bb.1115:                             ; %convergence.cascade968.preheader
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w5, #0                          ; =0x0
LBB0_1116:                              ; %convergence.cascade968
                                        ;   Parent Loop BB0_5 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d6, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v0, v6
	addv.8b	b1, v1
	fmov	w6, s1
	umaxv.8b	b0, v0
	fmov	w20, s0
	sub	w7, w4, #1
	tst	w6, #0xff
	csel	w7, w7, wzr, ne
	mov	w6, #1                          ; =0x1
	lsl	w19, w6, w7
	and	w6, w19, w0
	tst	w6, #0xff
	cset	w22, ne
	str	q24, [sp, #6992]
	str	q27, [sp, #7008]
	ubfiz	x6, x7, #2, #3
	add	x21, sp, #1, lsl #12            ; =4096
	add	x21, x21, #2896
	ldr	w21, [x21, x6]
	cmp	w21, #19
	cset	w21, eq
	and	w22, w22, w20
	add	x20, sp, #2, lsl #12            ; =8192
	add	x20, x20, #3560
	ldrb	w24, [x20, w7, sxtw]
	and	w23, w24, #0x1
	fmov	s0, w23
	ubfx	w23, w24, #1, #1
	mov.b	v0[1], w23
	ubfx	w23, w24, #2, #1
	mov.b	v0[2], w23
	ubfx	w23, w24, #3, #1
	mov.b	v0[3], w23
	ubfx	w23, w24, #4, #1
	mov.b	v0[4], w23
	ubfx	w23, w24, #5, #1
	mov.b	v0[5], w23
	ubfx	w23, w24, #6, #1
	mov.b	v0[6], w23
	add	x23, sp, #2, lsl #12            ; =8192
	add	x23, x23, #3552
	lsr	w24, w24, #7
	mov.b	v0[7], w24
	ldrb	w24, [x23, w7, sxtw]
	and	w25, w24, #0x1
	fmov	s1, w25
	ubfx	w25, w24, #1, #1
	mov.b	v1[1], w25
	ubfx	w25, w24, #2, #1
	mov.b	v1[2], w25
	ubfx	w25, w24, #3, #1
	mov.b	v1[3], w25
	ubfx	w25, w24, #4, #1
	mov.b	v1[4], w25
	ubfx	w25, w24, #5, #1
	mov.b	v1[5], w25
	ubfx	w25, w24, #6, #1
	mov.b	v1[6], w25
	lsr	w24, w24, #7
	mov.b	v1[7], w24
	orr.8b	v2, v15, v1
	ldr	d3, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v3, v0
	eor.8b	v3, v3, v2
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w24, s3
	ands	w21, w22, w21
	csetm	w22, ne
	bics	w24, w21, w24
	csetm	w25, ne
	dup.8b	v3, w25
	bic.8b	v4, v2, v3
	dup.8b	v5, w22
	bit.8b	v1, v4, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v6
	addv.8b	b1, v1
	str	b1, [x23, w7, sxtw]
	bic.8b	v0, v0, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	str	b0, [x20, w7, sxtw]
	mov	w7, #-1                         ; =0xffffffff
	csinv	w7, w7, w19, eq
	and	w0, w7, w0
	dup.8b	v0, w21
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	dup.8b	v1, w24
	and.8b	v1, v1, v2
	str	q9, [sp, #6960]
	ldr	q2, [sp, #1968]                 ; 16-byte Reload
	str	q2, [sp, #6976]
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #2864
	ldr	w6, [x7, x6]
	csel	w4, w6, w4, ne
	bit.8b	v15, v1, v0
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	fmov	w6, s0
	cmp	w21, #1
	b.ne	LBB0_1120
; %bb.1117:                             ; %convergence.cascade968
                                        ;   in Loop: Header=BB0_1116 Depth=3
	cmp	w4, #0
	ccmp	w5, #6, #2, ne
	b.hi	LBB0_1120
; %bb.1118:                             ; %convergence.cascade968
                                        ;   in Loop: Header=BB0_1116 Depth=3
	add	w5, w5, #1
	tst	w6, #0xff
	b.ne	LBB0_1116
	b	LBB0_1120
LBB0_1119:                              ; %schedule.45.convergence.cascade.exit969_crit_edge
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w6, s0
LBB0_1120:                              ; %convergence.cascade.exit969
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w6, #0xff
	b.eq	LBB0_4
; %bb.1121:                             ; %convergence.target.45.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q0, [sp, #7696]
	ldr	q1, [sp, #7680]
	ldr	q2, [sp, #7728]
	ldr	q3, [sp, #7712]
	dup.2d	v4, x2
	add.2d	v3, v3, v4
	add.2d	v2, v2, v4
	add.2d	v1, v1, v4
	add.2d	v0, v0, v4
	ldr	q4, [sp, #7520]
	ldr	q5, [sp, #7536]
	ldr	q6, [sp, #7488]
	ldr	q7, [sp, #7504]
	mov	b16, v15[2]
	mov.b	v16[4], v15[3]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	bif.16b	v0, v7, v16
	mov	b7, v15[0]
	mov.b	v7[4], v15[1]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	bif.16b	v1, v6, v7
	mov	b6, v15[6]
	mov.b	v6[4], v15[7]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	bif.16b	v2, v5, v6
	mov	b5, v15[4]
	mov.b	v5[4], v15[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	bif.16b	v3, v4, v5
	str	q3, [sp, #7520]
	str	q2, [sp, #7536]
	str	q1, [sp, #7488]
	str	q0, [sp, #7504]
	and.8b	v7, v31, v15
	shl.8b	v0, v7, #7
	cmlt.8b	v0, v0, #0
	umaxv.8b	b1, v0
	fmov	w5, s1
	tbz	w5, #0, LBB0_1291
; %bb.1122:                             ; %convergence.target.45.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	bic.8b	v16, v15, v31
	shl.8b	v1, v16, #7
	cmlt.8b	v1, v1, #0
	ldr	d2, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w5, s1
	tst	w5, #0xff
	b.eq	LBB0_1291
; %bb.1123:                             ; %varying.divergent990
                                        ;   in Loop: Header=BB0_6 Depth=2
	cmp	w4, #0
	cset	w5, ne
	sub	w5, w4, w5
	and	w6, w0, #0xff
	lsr	w7, w6, w5
	tst	w7, #0x1
	cset	w7, eq
	cmp	w4, #0
	str	q24, [sp, #6864]
	str	q27, [sp, #6880]
	and	x5, x5, #0x7
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #2768
	ldr	w5, [x19, x5, lsl #2]
	csinc	w7, w7, wzr, ne
	cmp	w5, #20
	csinc	w5, w7, wzr, eq
	cmp	w6, #255
	b.ne	LBB0_1125
; %bb.1124:                             ; %varying.divergent990
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #0, LBB0_1348
LBB0_1125:                              ; %convergence.overflow.resume993
                                        ;   in Loop: Header=BB0_6 Depth=2
	mvn	w6, w0
	rbit	w6, w6
	clz	w6, w6
	mov	w7, #255                        ; =0xff
	bics	wzr, w7, w0
	csel	w7, wzr, w6, eq
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #3560
	ldrb	w20, [x6, w7, uxtw]
	and	w19, w20, #0x1
	fmov	s0, w19
	ubfx	w19, w20, #1, #1
	mov.b	v0[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v0[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v0[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v0[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v0[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v0[6], w19
	add	x19, sp, #2, lsl #12            ; =8192
	add	x19, x19, #3552
	lsr	w20, w20, #7
	mov.b	v0[7], w20
	ldrb	w20, [x19, w7, uxtw]
	and	w21, w20, #0x1
	fmov	s1, w21
	ubfx	w21, w20, #1, #1
	mov.b	v1[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v1[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v1[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v1[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v1[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v1[6], w21
	lsr	w20, w20, #7
	mov.b	v1[7], w20
	cmp	w5, #0
	csetm	w20, ne
	dup.8b	v2, w20
	bit.8b	v0, v15, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	ldr	d3, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x6, w7, uxtw]
	bic.8b	v0, v1, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x19, w7, uxtw]
	cmp	x1, #8
	b.hs	LBB0_1348
; %bb.1126:                             ; %ready.overflow.resume995
                                        ;   in Loop: Header=BB0_6 Depth=2
	str	q9, [sp, #6832]
	ldr	q0, [sp, #1968]                 ; 16-byte Reload
	str	q0, [sp, #6848]
	ubfiz	x6, x7, #2, #3
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #2736
	ldr	w19, [x19, x6]
	cmp	w5, #0
	csel	w19, w4, w19, ne
	csinc	w4, w4, w7, eq
	str	q9, [sp, #6800]
	str	q0, [sp, #6816]
	add	x20, sp, #1, lsl #12            ; =4096
	add	x20, x20, #2704
	str	w19, [x20, x6]
	ldr	q0, [sp, #6816]
	str	q0, [sp, #1968]                 ; 16-byte Spill
	ldr	q9, [sp, #6800]
	str	q24, [sp, #6768]
	str	q27, [sp, #6784]
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #2672
	ldr	w19, [x19, x6]
	mov	w20, #20                        ; =0x14
	csel	w19, w20, w19, ne
	str	q24, [sp, #6736]
	str	q27, [sp, #6752]
	add	x20, sp, #1, lsl #12            ; =4096
	add	x20, x20, #2640
	str	w19, [x20, x6]
	mov	w6, #47                         ; =0x2f
	mov	w19, #46                        ; =0x2e
	ldr	q27, [sp, #6752]
	ldr	q24, [sp, #6736]
	b	LBB0_1261
LBB0_1127:                              ; %cond.store9376
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d2
	str	s3, [x6]
	tbz	w5, #1, LBB0_1057
LBB0_1128:                              ; %cond.store9380
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v2[1]
	st1.s	{ v3 }[1], [x6]
	fmov	d2, x19
	mov.d	v2[1], x20
	add.2d	v4, v2, v1
	shl.2d	v4, v4, #2
	add.2d	v4, v5, v4
	tbz	w5, #2, LBB0_1058
LBB0_1129:                              ; %cond.store9384
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d4
	st1.s	{ v3 }[2], [x6]
	tbnz	w5, #3, LBB0_1059
	b	LBB0_1060
LBB0_1130:                              ; %cond.store9392
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d4
	str	s6, [x6]
	tbz	w5, #5, LBB0_1062
LBB0_1131:                              ; %cond.store9396
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v4[1]
	st1.s	{ v6 }[1], [x6]
	fmov	d4, x23
	mov.d	v4[1], x24
	add.2d	v1, v4, v1
	shl.2d	v1, v1, #2
	add.2d	v1, v5, v1
	tbz	w5, #6, LBB0_1063
LBB0_1132:                              ; %cond.store9400
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	st1.s	{ v6 }[2], [x6]
	tbnz	w5, #7, LBB0_1064
	b	LBB0_1065
LBB0_1133:                              ; %cond.store9409
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d0
	str	s6, [x6]
	tbz	w5, #1, LBB0_1067
LBB0_1134:                              ; %cond.store9413
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v0[1]
	st1.s	{ v6 }[1], [x6]
	add.2d	v0, v2, v1
	shl.2d	v0, v0, #2
	add.2d	v0, v5, v0
	tbz	w5, #2, LBB0_1068
LBB0_1135:                              ; %cond.store9417
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d0
	st1.s	{ v6 }[2], [x6]
	tbnz	w5, #3, LBB0_1069
	b	LBB0_1070
LBB0_1136:                              ; %cond.store9425
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d2
	str	s0, [x6]
	tbz	w5, #5, LBB0_1072
LBB0_1137:                              ; %cond.store9429
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v2[1]
	st1.s	{ v0 }[1], [x6]
	add.2d	v1, v4, v1
	shl.2d	v1, v1, #2
	add.2d	v1, v5, v1
	tbz	w5, #6, LBB0_1073
LBB0_1138:                              ; %cond.store9433
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	st1.s	{ v0 }[2], [x6]
	tbnz	w5, #7, LBB0_1074
	b	LBB0_1075
LBB0_1139:                              ; %cond.store9475
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d6
	str	s4, [x6]
	tbz	w5, #1, LBB0_1107
LBB0_1140:                              ; %cond.store9479
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v6[1]
	st1.s	{ v4 }[1], [x6]
	shl.2d	v5, v5, #2
	add.2d	v5, v2, v5
	tbz	w5, #2, LBB0_1108
LBB0_1141:                              ; %cond.store9483
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d5
	st1.s	{ v4 }[2], [x6]
	tbz	w5, #3, LBB0_1109
LBB0_1142:                              ; %cond.store9487
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v5[1]
	st1.s	{ v4 }[3], [x6]
	shl.2d	v3, v3, #2
	add.2d	v3, v2, v3
	tbz	w5, #4, LBB0_1110
LBB0_1143:                              ; %cond.store9491
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d3
	str	s0, [x6]
	tbz	w5, #5, LBB0_1111
LBB0_1144:                              ; %cond.store9495
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v3[1]
	st1.s	{ v0 }[1], [x6]
	shl.2d	v1, v1, #2
	add.2d	v1, v2, v1
	tbz	w5, #6, LBB0_1112
LBB0_1145:                              ; %cond.store9499
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	st1.s	{ v0 }[2], [x6]
	tbnz	w5, #7, LBB0_1113
	b	LBB0_1114
LBB0_1146:                              ; %cond.store9442
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d6
	str	s3, [x6]
	tbz	w5, #1, LBB0_1084
LBB0_1147:                              ; %cond.store9446
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v6[1]
	st1.s	{ v3 }[1], [x6]
	shl.2d	v4, v4, #2
	add.2d	v4, v5, v4
	tbz	w5, #2, LBB0_1085
LBB0_1148:                              ; %cond.store9450
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d4
	st1.s	{ v3 }[2], [x6]
	tbz	w5, #3, LBB0_1086
LBB0_1149:                              ; %cond.store9454
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v4[1]
	st1.s	{ v3 }[3], [x6]
	shl.2d	v2, v2, #2
	add.2d	v2, v5, v2
	tbz	w5, #4, LBB0_1087
LBB0_1150:                              ; %cond.store9458
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d2
	str	s0, [x6]
	tbz	w5, #5, LBB0_1088
LBB0_1151:                              ; %cond.store9462
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v2[1]
	st1.s	{ v0 }[1], [x6]
	shl.2d	v1, v1, #2
	add.2d	v1, v5, v1
	tbz	w5, #6, LBB0_1089
LBB0_1152:                              ; %cond.store9466
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x6, d1
	st1.s	{ v0 }[2], [x6]
	tbnz	w5, #7, LBB0_1090
	b	LBB0_1091
LBB0_1153:                              ; %schedule.29
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d4, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v4
	addv.8b	b0, v0
	fmov	w6, s0
	mov	w5, #3                          ; =0x3
	dup.2d	v0, x5
	ldr	q1, [sp, #1824]                 ; 16-byte Reload
	cmgt.2d	v1, v0, v1
	ldr	q2, [sp, #1840]                 ; 16-byte Reload
	cmgt.2d	v2, v0, v2
	uzp1.4s	v1, v2, v1
	cmgt.2d	v2, v0, v11
	ldr	q3, [sp, #1808]                 ; 16-byte Reload
	cmgt.2d	v3, v0, v3
	uzp1.4s	v2, v2, v3
	uzp1.8h	v1, v1, v2
	xtn.8b	v1, v1
	and.8b	v7, v15, v1
	shl.8b	v1, v7, #7
	cmlt.8b	v1, v1, #0
	and.8b	v2, v1, v4
	addv.8b	b2, v2
	fmov	w5, s2
	umaxv.8b	b1, v1
	fmov	w7, s1
	tbz	w7, #0, LBB0_1159
; %bb.1154:                             ; %schedule.29
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #1824]                 ; 16-byte Reload
	cmge.2d	v1, v1, v0
	ldr	q2, [sp, #1840]                 ; 16-byte Reload
	cmge.2d	v2, v2, v0
	uzp1.4s	v1, v2, v1
	cmge.2d	v2, v11, v0
	ldr	q3, [sp, #1808]                 ; 16-byte Reload
	cmge.2d	v0, v3, v0
	uzp1.4s	v0, v2, v0
	uzp1.8h	v0, v1, v0
	xtn.8b	v0, v0
	and.8b	v16, v15, v0
	shl.8b	v0, v16, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w7, s0
	tst	w7, #0xff
	b.eq	LBB0_1159
; %bb.1155:                             ; %varying.divergent658
                                        ;   in Loop: Header=BB0_6 Depth=2
	cmp	w4, #0
	cset	w5, ne
	sub	w5, w4, w5
	and	w6, w0, #0xff
	lsr	w7, w6, w5
	tst	w7, #0x1
	cset	w7, eq
	cmp	w4, #0
	str	q24, [sp, #4368]
	str	q27, [sp, #4384]
	and	x5, x5, #0x7
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #272
	ldr	w5, [x19, x5, lsl #2]
	csinc	w7, w7, wzr, ne
	cmp	w5, #14
	csinc	w5, w7, wzr, eq
	cmp	w6, #255
	b.ne	LBB0_1157
; %bb.1156:                             ; %varying.divergent658
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #0, LBB0_1348
LBB0_1157:                              ; %convergence.overflow.resume661
                                        ;   in Loop: Header=BB0_6 Depth=2
	mvn	w6, w0
	rbit	w6, w6
	clz	w6, w6
	mov	w7, #255                        ; =0xff
	bics	wzr, w7, w0
	csel	w7, wzr, w6, eq
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #3560
	ldrb	w20, [x6, w7, uxtw]
	and	w19, w20, #0x1
	fmov	s0, w19
	ubfx	w19, w20, #1, #1
	mov.b	v0[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v0[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v0[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v0[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v0[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v0[6], w19
	add	x19, sp, #2, lsl #12            ; =8192
	add	x19, x19, #3552
	lsr	w20, w20, #7
	mov.b	v0[7], w20
	ldrb	w20, [x19, w7, uxtw]
	and	w21, w20, #0x1
	fmov	s1, w21
	ubfx	w21, w20, #1, #1
	mov.b	v1[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v1[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v1[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v1[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v1[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v1[6], w21
	lsr	w20, w20, #7
	mov.b	v1[7], w20
	cmp	w5, #0
	csetm	w20, ne
	dup.8b	v2, w20
	bit.8b	v0, v15, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	ldr	d3, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x6, w7, uxtw]
	bic.8b	v0, v1, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x19, w7, uxtw]
	cmp	x1, #8
	b.hs	LBB0_1348
; %bb.1158:                             ; %ready.overflow.resume663
                                        ;   in Loop: Header=BB0_6 Depth=2
	str	q9, [sp, #4336]
	ldr	q0, [sp, #1968]                 ; 16-byte Reload
	str	q0, [sp, #4352]
	ubfiz	x6, x7, #2, #3
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #240
	ldr	w19, [x19, x6]
	cmp	w5, #0
	csel	w19, w4, w19, ne
	csinc	w4, w4, w7, eq
	str	q9, [sp, #4304]
	str	q0, [sp, #4320]
	add	x20, sp, #1, lsl #12            ; =4096
	add	x20, x20, #208
	str	w19, [x20, x6]
	ldr	q0, [sp, #4320]
	str	q0, [sp, #1968]                 ; 16-byte Spill
	ldr	q9, [sp, #4304]
	str	q24, [sp, #4272]
	str	q27, [sp, #4288]
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #176
	ldr	w19, [x19, x6]
	mov	w20, #14                        ; =0xe
	csel	w19, w20, w19, ne
	str	q24, [sp, #4240]
	str	q27, [sp, #4256]
	add	x20, sp, #1, lsl #12            ; =4096
	add	x20, x20, #144
	str	w19, [x20, x6]
	mov	w6, #31                         ; =0x1f
	mov	w19, #30                        ; =0x1e
	ldr	q27, [sp, #4256]
	ldr	q24, [sp, #4240]
	b	LBB0_1261
LBB0_1159:                              ; %varying.coherent659
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w5, #0xff
	b.eq	LBB0_1178
; %bb.1160:                             ; %varying.coherent.true664
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w5, #0                          ; =0x0
	tst	w6, #0xff
	b.eq	LBB0_4
LBB0_1161:                              ; %schedule.30
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	b0, v15[6]
	mov.b	v0[4], v15[7]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	ldr	q1, [sp, #1808]                 ; 16-byte Reload
	and.16b	v0, v0, v1
	mov	b1, v15[4]
	mov.b	v1[4], v15[5]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	mov	b2, v15[2]
	mov.b	v2[4], v15[3]
	and.16b	v1, v1, v11
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v2, v2, #0
	ldr	q3, [sp, #1824]                 ; 16-byte Reload
	and.16b	v2, v2, v3
	mov	b3, v15[0]
	mov.b	v3[4], v15[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q4, [sp, #1840]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	shl.8b	v4, v15, #7
	cmlt.8b	v4, v4, #0
	ldr	d5, [sp, #1992]                 ; 8-byte Reload
	and.8b	v4, v4, v5
	addv.8b	b4, v4
	fmov	w6, s4
	ldr	x7, [sp, #11256]
	add	x7, x7, x7, lsl #1
	lsl	x7, x7, #1
	dup.2d	v4, x7
	add.2d	v3, v4, v3
	add.2d	v2, v4, v2
	add.2d	v1, v4, v1
	add.2d	v0, v4, v0
	ldr	q5, [sp, #8384]
	ldr	q6, [sp, #8400]
	ldr	q4, [sp, #8416]
	ldr	q7, [sp, #8432]
	ldr	q16, [sp, #8496]
	ldr	q17, [sp, #8480]
	ldr	q18, [sp, #8464]
	ldr	q19, [sp, #8448]
	shl.2d	v0, v0, #5
	shl.2d	v1, v1, #5
	shl.2d	v20, v2, #5
	shl.2d	v3, v3, #5
	add.2d	v2, v7, v16
	add.2d	v2, v2, v0
	add.2d	v0, v4, v17
	add.2d	v4, v0, v1
	add.2d	v0, v6, v18
	add.2d	v1, v0, v20
	add.2d	v0, v5, v19
	add.2d	v5, v0, v3
	movi.2d	v0, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w6, #0, LBB0_1171
; %bb.1162:                             ; %else8130
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #1, LBB0_1172
LBB0_1163:                              ; %else8136
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #2, LBB0_1173
LBB0_1164:                              ; %else8142
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #3, LBB0_1174
LBB0_1165:                              ; %else8148
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #4, LBB0_1175
LBB0_1166:                              ; %else8154
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #5, LBB0_1176
LBB0_1167:                              ; %else8160
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #6, LBB0_1177
LBB0_1168:                              ; %else8166
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w6, #7, LBB0_1170
LBB0_1169:                              ; %cond.load8168
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v2[1]
	ld1.s	{ v3 }[3], [x6]
LBB0_1170:                              ; %else8172
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q4, [sp, #1344]                 ; 16-byte Reload
	fmaxnm.4s	v0, v4, v0
	ldr	q5, [sp, #1328]                 ; 16-byte Reload
	fmaxnm.4s	v1, v5, v3
	movi.8b	v2, #1
	and.8b	v2, v15, v2
	ushll.8h	v2, v2, #0
	ushll.4s	v3, v2, #0
	ushll2.4s	v2, v2, #0
	ldr	q6, [sp, #1808]                 ; 16-byte Reload
	uaddw2.2d	v6, v6, v2
	str	q6, [sp, #1808]                 ; 16-byte Spill
	uaddw.2d	v11, v11, v2
	ldr	q2, [sp, #1824]                 ; 16-byte Reload
	uaddw2.2d	v2, v2, v3
	str	q2, [sp, #1824]                 ; 16-byte Spill
	ldr	q2, [sp, #1840]                 ; 16-byte Reload
	uaddw.2d	v2, v2, v3
	str	q2, [sp, #1840]                 ; 16-byte Spill
	zip2.8b	v2, v15, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	bit.16b	v5, v1, v2
	str	q5, [sp, #1328]                 ; 16-byte Spill
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	bit.16b	v4, v0, v1
	str	q4, [sp, #1344]                 ; 16-byte Spill
	tbz	w5, #0, LBB0_1153
	b	LBB0_4
LBB0_1171:                              ; %cond.load8126
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d5
	ldr	s0, [x7]
	tbz	w6, #1, LBB0_1163
LBB0_1172:                              ; %cond.load8132
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v5[1]
	ld1.s	{ v0 }[1], [x7]
	tbz	w6, #2, LBB0_1164
LBB0_1173:                              ; %cond.load8138
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d1
	ld1.s	{ v0 }[2], [x7]
	tbz	w6, #3, LBB0_1165
LBB0_1174:                              ; %cond.load8144
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v1[1]
	ld1.s	{ v0 }[3], [x7]
	tbz	w6, #4, LBB0_1166
LBB0_1175:                              ; %cond.load8150
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d4
	ld1.s	{ v3 }[0], [x7]
	tbz	w6, #5, LBB0_1167
LBB0_1176:                              ; %cond.load8156
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v4[1]
	ld1.s	{ v3 }[1], [x7]
	tbz	w6, #6, LBB0_1168
LBB0_1177:                              ; %cond.load8162
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d2
	ld1.s	{ v3 }[2], [x7]
	tbnz	w6, #7, LBB0_1169
	b	LBB0_1170
LBB0_1178:                              ; %varying.coherent.false665
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w6, #0xff
	b.eq	LBB0_4
LBB0_1179:                              ; %schedule.31
                                        ;   in Loop: Header=BB0_6 Depth=2
	cbz	w4, LBB0_1184
; %bb.1180:                             ; %convergence.cascade672.preheader
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w5, #0                          ; =0x0
LBB0_1181:                              ; %convergence.cascade672
                                        ;   Parent Loop BB0_5 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d6, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v0, v6
	addv.8b	b1, v1
	fmov	w6, s1
	umaxv.8b	b0, v0
	fmov	w20, s0
	sub	w7, w4, #1
	tst	w6, #0xff
	csel	w7, w7, wzr, ne
	mov	w6, #1                          ; =0x1
	lsl	w19, w6, w7
	and	w6, w19, w0
	tst	w6, #0xff
	cset	w22, ne
	str	q24, [sp, #5488]
	str	q27, [sp, #5504]
	ubfiz	x6, x7, #2, #3
	add	x21, sp, #1, lsl #12            ; =4096
	add	x21, x21, #1392
	ldr	w21, [x21, x6]
	cmp	w21, #14
	cset	w21, eq
	and	w22, w22, w20
	add	x20, sp, #2, lsl #12            ; =8192
	add	x20, x20, #3560
	ldrb	w24, [x20, w7, sxtw]
	and	w23, w24, #0x1
	fmov	s0, w23
	ubfx	w23, w24, #1, #1
	mov.b	v0[1], w23
	ubfx	w23, w24, #2, #1
	mov.b	v0[2], w23
	ubfx	w23, w24, #3, #1
	mov.b	v0[3], w23
	ubfx	w23, w24, #4, #1
	mov.b	v0[4], w23
	ubfx	w23, w24, #5, #1
	mov.b	v0[5], w23
	ubfx	w23, w24, #6, #1
	mov.b	v0[6], w23
	add	x23, sp, #2, lsl #12            ; =8192
	add	x23, x23, #3552
	lsr	w24, w24, #7
	mov.b	v0[7], w24
	ldrb	w24, [x23, w7, sxtw]
	and	w25, w24, #0x1
	fmov	s1, w25
	ubfx	w25, w24, #1, #1
	mov.b	v1[1], w25
	ubfx	w25, w24, #2, #1
	mov.b	v1[2], w25
	ubfx	w25, w24, #3, #1
	mov.b	v1[3], w25
	ubfx	w25, w24, #4, #1
	mov.b	v1[4], w25
	ubfx	w25, w24, #5, #1
	mov.b	v1[5], w25
	ubfx	w25, w24, #6, #1
	mov.b	v1[6], w25
	lsr	w24, w24, #7
	mov.b	v1[7], w24
	orr.8b	v2, v15, v1
	ldr	d3, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v3, v0
	eor.8b	v3, v3, v2
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w24, s3
	ands	w21, w22, w21
	csetm	w22, ne
	bics	w24, w21, w24
	csetm	w25, ne
	dup.8b	v3, w25
	bic.8b	v4, v2, v3
	dup.8b	v5, w22
	bit.8b	v1, v4, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v6
	addv.8b	b1, v1
	str	b1, [x23, w7, sxtw]
	bic.8b	v0, v0, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	str	b0, [x20, w7, sxtw]
	mov	w7, #-1                         ; =0xffffffff
	csinv	w7, w7, w19, eq
	and	w0, w7, w0
	dup.8b	v0, w21
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	dup.8b	v1, w24
	and.8b	v1, v1, v2
	str	q9, [sp, #5456]
	ldr	q2, [sp, #1968]                 ; 16-byte Reload
	str	q2, [sp, #5472]
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #1360
	ldr	w6, [x7, x6]
	csel	w4, w6, w4, ne
	bit.8b	v15, v1, v0
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	fmov	w6, s0
	cmp	w21, #1
	b.ne	LBB0_1185
; %bb.1182:                             ; %convergence.cascade672
                                        ;   in Loop: Header=BB0_1181 Depth=3
	cmp	w4, #0
	ccmp	w5, #6, #2, ne
	b.hi	LBB0_1185
; %bb.1183:                             ; %convergence.cascade672
                                        ;   in Loop: Header=BB0_1181 Depth=3
	add	w5, w5, #1
	tst	w6, #0xff
	b.ne	LBB0_1181
	b	LBB0_1185
LBB0_1184:                              ; %schedule.31.convergence.cascade.exit673_crit_edge
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w6, s0
LBB0_1185:                              ; %convergence.cascade.exit673
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w6, #0xff
	b.eq	LBB0_4
; %bb.1186:                             ; %convergence.target.31.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	b0, v15[6]
	mov.b	v0[4], v15[7]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmge.2d	v0, v0, #0
	mov	b1, v15[4]
	mov.b	v1[4], v15[5]
	and.16b	v26, v0, v26
	ushll.2d	v0, v1, #0
	shl.2d	v0, v0, #63
	cmge.2d	v0, v0, #0
	ldr	q1, [sp, #1856]                 ; 16-byte Reload
	and.16b	v1, v0, v1
	str	q1, [sp, #1856]                 ; 16-byte Spill
	mov	b0, v15[2]
	mov.b	v0[4], v15[3]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmge.2d	v0, v0, #0
	and.16b	v10, v0, v10
	mov	b0, v15[0]
	mov.b	v0[4], v15[1]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmge.2d	v0, v0, #0
	ldr	q1, [sp, #1872]                 ; 16-byte Reload
	and.16b	v1, v0, v1
	str	q1, [sp, #1872]                 ; 16-byte Spill
	zip1.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	mvni.4s	v2, #127, msl #16
	ldr	q3, [sp, #1360]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #1360]                 ; 16-byte Spill
	ldr	q1, [sp, #1376]                 ; 16-byte Reload
	bit.16b	v1, v2, v0
	str	q1, [sp, #1376]                 ; 16-byte Spill
LBB0_1187:                              ; %schedule.32
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d4, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v4
	addv.8b	b0, v0
	fmov	w6, s0
	mov	w5, #3                          ; =0x3
	dup.2d	v0, x5
	cmgt.2d	v1, v0, v10
	ldr	q2, [sp, #1872]                 ; 16-byte Reload
	cmgt.2d	v2, v0, v2
	uzp1.4s	v1, v2, v1
	ldr	q2, [sp, #1856]                 ; 16-byte Reload
	cmgt.2d	v2, v0, v2
	cmgt.2d	v3, v0, v26
	uzp1.4s	v2, v2, v3
	uzp1.8h	v1, v1, v2
	xtn.8b	v1, v1
	and.8b	v7, v15, v1
	shl.8b	v1, v7, #7
	cmlt.8b	v1, v1, #0
	and.8b	v2, v1, v4
	addv.8b	b2, v2
	fmov	w5, s2
	umaxv.8b	b1, v1
	fmov	w7, s1
	tbz	w7, #0, LBB0_1193
; %bb.1188:                             ; %schedule.32
                                        ;   in Loop: Header=BB0_6 Depth=2
	cmge.2d	v1, v10, v0
	ldr	q2, [sp, #1872]                 ; 16-byte Reload
	cmge.2d	v2, v2, v0
	uzp1.4s	v1, v2, v1
	ldr	q2, [sp, #1856]                 ; 16-byte Reload
	cmge.2d	v2, v2, v0
	cmge.2d	v0, v26, v0
	uzp1.4s	v0, v2, v0
	uzp1.8h	v0, v1, v0
	xtn.8b	v0, v0
	and.8b	v16, v15, v0
	shl.8b	v0, v16, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w7, s0
	tst	w7, #0xff
	b.eq	LBB0_1193
; %bb.1189:                             ; %varying.divergent690
                                        ;   in Loop: Header=BB0_6 Depth=2
	cmp	w4, #0
	cset	w5, ne
	sub	w5, w4, w5
	and	w6, w0, #0xff
	lsr	w7, w6, w5
	tst	w7, #0x1
	cset	w7, eq
	cmp	w4, #0
	str	q24, [sp, #4528]
	str	q27, [sp, #4544]
	and	x5, x5, #0x7
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #432
	ldr	w5, [x19, x5, lsl #2]
	csinc	w7, w7, wzr, ne
	cmp	w5, #15
	csinc	w5, w7, wzr, eq
	cmp	w6, #255
	b.ne	LBB0_1191
; %bb.1190:                             ; %varying.divergent690
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #0, LBB0_1348
LBB0_1191:                              ; %convergence.overflow.resume693
                                        ;   in Loop: Header=BB0_6 Depth=2
	mvn	w6, w0
	rbit	w6, w6
	clz	w6, w6
	mov	w7, #255                        ; =0xff
	bics	wzr, w7, w0
	csel	w7, wzr, w6, eq
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #3560
	ldrb	w20, [x6, w7, uxtw]
	and	w19, w20, #0x1
	fmov	s0, w19
	ubfx	w19, w20, #1, #1
	mov.b	v0[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v0[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v0[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v0[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v0[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v0[6], w19
	add	x19, sp, #2, lsl #12            ; =8192
	add	x19, x19, #3552
	lsr	w20, w20, #7
	mov.b	v0[7], w20
	ldrb	w20, [x19, w7, uxtw]
	and	w21, w20, #0x1
	fmov	s1, w21
	ubfx	w21, w20, #1, #1
	mov.b	v1[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v1[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v1[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v1[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v1[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v1[6], w21
	lsr	w20, w20, #7
	mov.b	v1[7], w20
	cmp	w5, #0
	csetm	w20, ne
	dup.8b	v2, w20
	bit.8b	v0, v15, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	ldr	d3, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x6, w7, uxtw]
	bic.8b	v0, v1, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x19, w7, uxtw]
	cmp	x1, #8
	b.hs	LBB0_1348
; %bb.1192:                             ; %ready.overflow.resume695
                                        ;   in Loop: Header=BB0_6 Depth=2
	str	q9, [sp, #4496]
	ldr	q0, [sp, #1968]                 ; 16-byte Reload
	str	q0, [sp, #4512]
	ubfiz	x6, x7, #2, #3
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #400
	ldr	w19, [x19, x6]
	cmp	w5, #0
	csel	w19, w4, w19, ne
	csinc	w4, w4, w7, eq
	str	q9, [sp, #4464]
	str	q0, [sp, #4480]
	add	x20, sp, #1, lsl #12            ; =4096
	add	x20, x20, #368
	str	w19, [x20, x6]
	ldr	q0, [sp, #4480]
	str	q0, [sp, #1968]                 ; 16-byte Spill
	ldr	q9, [sp, #4464]
	str	q24, [sp, #4432]
	str	q27, [sp, #4448]
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #336
	ldr	w19, [x19, x6]
	mov	w20, #15                        ; =0xf
	csel	w19, w20, w19, ne
	str	q24, [sp, #4400]
	str	q27, [sp, #4416]
	add	x20, sp, #1, lsl #12            ; =4096
	add	x20, x20, #304
	str	w19, [x20, x6]
	mov	w6, #34                         ; =0x22
	mov	w19, #33                        ; =0x21
	ldr	q27, [sp, #4416]
	ldr	q24, [sp, #4400]
	b	LBB0_1261
LBB0_1193:                              ; %varying.coherent691
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w5, #0xff
	b.eq	LBB0_1212
; %bb.1194:                             ; %varying.coherent.true696
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w5, #0                          ; =0x0
	tst	w6, #0xff
	b.eq	LBB0_4
LBB0_1195:                              ; %schedule.33
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	b0, v15[6]
	mov.b	v0[4], v15[7]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	and.16b	v0, v0, v26
	mov	b1, v15[4]
	mov.b	v1[4], v15[5]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	ldr	q2, [sp, #1856]                 ; 16-byte Reload
	and.16b	v1, v1, v2
	mov	b2, v15[2]
	mov.b	v2[4], v15[3]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v2, v2, #0
	mov	b3, v15[0]
	mov.b	v3[4], v15[1]
	and.16b	v2, v2, v10
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q4, [sp, #1872]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	shl.8b	v4, v15, #7
	cmlt.8b	v4, v4, #0
	ldr	d5, [sp, #1992]                 ; 8-byte Reload
	and.8b	v4, v4, v5
	addv.8b	b4, v4
	fmov	w6, s4
	ldr	x7, [sp, #11256]
	mov	w19, #6                         ; =0x6
	mov	x20, #3                         ; =0x3
	madd	x7, x7, x19, x20
	dup.2d	v4, x7
	add.2d	v3, v4, v3
	add.2d	v2, v4, v2
	add.2d	v1, v4, v1
	add.2d	v0, v4, v0
	ldr	q5, [sp, #8384]
	ldr	q6, [sp, #8400]
	ldr	q4, [sp, #8416]
	ldr	q7, [sp, #8432]
	ldr	q16, [sp, #8496]
	ldr	q17, [sp, #8480]
	ldr	q18, [sp, #8464]
	ldr	q19, [sp, #8448]
	shl.2d	v0, v0, #5
	shl.2d	v1, v1, #5
	shl.2d	v20, v2, #5
	shl.2d	v3, v3, #5
	add.2d	v2, v7, v16
	add.2d	v2, v2, v0
	add.2d	v0, v4, v17
	add.2d	v4, v0, v1
	add.2d	v0, v6, v18
	add.2d	v1, v0, v20
	add.2d	v0, v5, v19
	add.2d	v5, v0, v3
	movi.2d	v0, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w6, #0, LBB0_1205
; %bb.1196:                             ; %else8179
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #1, LBB0_1206
LBB0_1197:                              ; %else8185
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #2, LBB0_1207
LBB0_1198:                              ; %else8191
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #3, LBB0_1208
LBB0_1199:                              ; %else8197
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #4, LBB0_1209
LBB0_1200:                              ; %else8203
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #5, LBB0_1210
LBB0_1201:                              ; %else8209
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #6, LBB0_1211
LBB0_1202:                              ; %else8215
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w6, #7, LBB0_1204
LBB0_1203:                              ; %cond.load8217
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v2[1]
	ld1.s	{ v3 }[3], [x6]
LBB0_1204:                              ; %else8221
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q4, [sp, #1376]                 ; 16-byte Reload
	fmaxnm.4s	v0, v4, v0
	ldr	q5, [sp, #1360]                 ; 16-byte Reload
	fmaxnm.4s	v1, v5, v3
	movi.8b	v2, #1
	and.8b	v2, v15, v2
	ushll.8h	v2, v2, #0
	ushll.4s	v3, v2, #0
	ushll2.4s	v2, v2, #0
	uaddw2.2d	v26, v26, v2
	ldr	q6, [sp, #1856]                 ; 16-byte Reload
	uaddw.2d	v6, v6, v2
	str	q6, [sp, #1856]                 ; 16-byte Spill
	uaddw2.2d	v10, v10, v3
	ldr	q2, [sp, #1872]                 ; 16-byte Reload
	uaddw.2d	v2, v2, v3
	str	q2, [sp, #1872]                 ; 16-byte Spill
	zip2.8b	v2, v15, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	bit.16b	v5, v1, v2
	str	q5, [sp, #1360]                 ; 16-byte Spill
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	bit.16b	v4, v0, v1
	str	q4, [sp, #1376]                 ; 16-byte Spill
	tbz	w5, #0, LBB0_1187
	b	LBB0_4
LBB0_1205:                              ; %cond.load8175
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d5
	ldr	s0, [x7]
	tbz	w6, #1, LBB0_1197
LBB0_1206:                              ; %cond.load8181
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v5[1]
	ld1.s	{ v0 }[1], [x7]
	tbz	w6, #2, LBB0_1198
LBB0_1207:                              ; %cond.load8187
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d1
	ld1.s	{ v0 }[2], [x7]
	tbz	w6, #3, LBB0_1199
LBB0_1208:                              ; %cond.load8193
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v1[1]
	ld1.s	{ v0 }[3], [x7]
	tbz	w6, #4, LBB0_1200
LBB0_1209:                              ; %cond.load8199
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d4
	ld1.s	{ v3 }[0], [x7]
	tbz	w6, #5, LBB0_1201
LBB0_1210:                              ; %cond.load8205
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v4[1]
	ld1.s	{ v3 }[1], [x7]
	tbz	w6, #6, LBB0_1202
LBB0_1211:                              ; %cond.load8211
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d2
	ld1.s	{ v3 }[2], [x7]
	tbnz	w6, #7, LBB0_1203
	b	LBB0_1204
LBB0_1212:                              ; %varying.coherent.false697
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w6, #0xff
	b.eq	LBB0_4
LBB0_1213:                              ; %schedule.34
                                        ;   in Loop: Header=BB0_6 Depth=2
	str	q23, [sp, #1744]                ; 16-byte Spill
	str	q12, [sp, #1520]                ; 16-byte Spill
	str	q25, [sp, #1728]                ; 16-byte Spill
	str	q29, [sp, #1648]                ; 16-byte Spill
	str	q22, [sp, #1712]                ; 16-byte Spill
	str	q10, [sp, #1504]                ; 16-byte Spill
	str	q26, [sp, #1696]                ; 16-byte Spill
	str	q11, [sp, #1536]                ; 16-byte Spill
	str	q8, [sp, #1488]                 ; 16-byte Spill
	str	q31, [sp, #1472]                ; 16-byte Spill
	str	q9, [sp, #1456]                 ; 16-byte Spill
	str	q27, [sp, #1680]                ; 16-byte Spill
	str	q24, [sp, #1664]                ; 16-byte Spill
	cbz	w4, LBB0_1218
; %bb.1214:                             ; %convergence.cascade705.preheader
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w6, #0                          ; =0x0
LBB0_1215:                              ; %convergence.cascade705
                                        ;   Parent Loop BB0_5 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d6, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v0, v6
	addv.8b	b1, v1
	fmov	w5, s1
	umaxv.8b	b0, v0
	fmov	w20, s0
	sub	w7, w4, #1
	tst	w5, #0xff
	csel	w7, w7, wzr, ne
	mov	w5, #1                          ; =0x1
	lsl	w19, w5, w7
	and	w5, w19, w0
	tst	w5, #0xff
	cset	w22, ne
	str	q24, [sp, #5424]
	str	q27, [sp, #5440]
	ubfiz	x5, x7, #2, #3
	add	x21, sp, #1, lsl #12            ; =4096
	add	x21, x21, #1328
	ldr	w21, [x21, x5]
	cmp	w21, #15
	cset	w21, eq
	and	w22, w22, w20
	add	x20, sp, #2, lsl #12            ; =8192
	add	x20, x20, #3560
	ldrb	w24, [x20, w7, sxtw]
	and	w23, w24, #0x1
	fmov	s0, w23
	ubfx	w23, w24, #1, #1
	mov.b	v0[1], w23
	ubfx	w23, w24, #2, #1
	mov.b	v0[2], w23
	ubfx	w23, w24, #3, #1
	mov.b	v0[3], w23
	ubfx	w23, w24, #4, #1
	mov.b	v0[4], w23
	ubfx	w23, w24, #5, #1
	mov.b	v0[5], w23
	ubfx	w23, w24, #6, #1
	mov.b	v0[6], w23
	add	x23, sp, #2, lsl #12            ; =8192
	add	x23, x23, #3552
	lsr	w24, w24, #7
	mov.b	v0[7], w24
	ldrb	w24, [x23, w7, sxtw]
	and	w25, w24, #0x1
	fmov	s1, w25
	ubfx	w25, w24, #1, #1
	mov.b	v1[1], w25
	ubfx	w25, w24, #2, #1
	mov.b	v1[2], w25
	ubfx	w25, w24, #3, #1
	mov.b	v1[3], w25
	ubfx	w25, w24, #4, #1
	mov.b	v1[4], w25
	ubfx	w25, w24, #5, #1
	mov.b	v1[5], w25
	ubfx	w25, w24, #6, #1
	mov.b	v1[6], w25
	lsr	w24, w24, #7
	mov.b	v1[7], w24
	orr.8b	v2, v15, v1
	ldr	d3, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v3, v0
	eor.8b	v3, v3, v2
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w24, s3
	ands	w21, w22, w21
	csetm	w22, ne
	bics	w24, w21, w24
	csetm	w25, ne
	dup.8b	v3, w25
	bic.8b	v4, v2, v3
	dup.8b	v5, w22
	bit.8b	v1, v4, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v6
	addv.8b	b1, v1
	str	b1, [x23, w7, sxtw]
	bic.8b	v0, v0, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	str	b0, [x20, w7, sxtw]
	mov	w7, #-1                         ; =0xffffffff
	csinv	w7, w7, w19, eq
	and	w0, w7, w0
	dup.8b	v0, w21
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	dup.8b	v1, w24
	and.8b	v1, v1, v2
	str	q9, [sp, #5392]
	ldr	q2, [sp, #1968]                 ; 16-byte Reload
	str	q2, [sp, #5408]
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #1296
	ldr	w5, [x7, x5]
	csel	w4, w5, w4, ne
	bit.8b	v15, v1, v0
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	fmov	w5, s0
	cmp	w21, #1
	b.ne	LBB0_1219
; %bb.1216:                             ; %convergence.cascade705
                                        ;   in Loop: Header=BB0_1215 Depth=3
	cmp	w4, #0
	ccmp	w6, #6, #2, ne
	b.hi	LBB0_1219
; %bb.1217:                             ; %convergence.cascade705
                                        ;   in Loop: Header=BB0_1215 Depth=3
	add	w6, w6, #1
	tst	w5, #0xff
	b.ne	LBB0_1215
	b	LBB0_1219
LBB0_1218:                              ; %schedule.34.convergence.cascade.exit706_crit_edge
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w5, s0
LBB0_1219:                              ; %convergence.cascade.exit706
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w5, #0xff
	b.eq	LBB0_4
; %bb.1220:                             ; %convergence.target.34.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q0, [sp, #1328]                 ; 16-byte Reload
	ldr	q6, [sp, #1232]                 ; 16-byte Reload
	fmaxnm.4s	v7, v6, v0
	ldr	q0, [sp, #1344]                 ; 16-byte Reload
	ldr	q3, [sp, #1248]                 ; 16-byte Reload
	fmaxnm.4s	v17, v3, v0
	ldr	q0, [sp, #8368]
	ldr	q1, [sp, #8352]
	zip1.8b	v2, v15, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v14, v2, #0
	bit.16b	v1, v17, v14
	zip2.8b	v2, v15, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v5, v2, #0
	bit.16b	v0, v7, v5
	str	q0, [sp, #8368]
	str	q1, [sp, #8352]
	ldr	q0, [sp, #1360]                 ; 16-byte Reload
	ldr	q4, [sp, #1264]                 ; 16-byte Reload
	fmaxnm.4s	v19, v4, v0
	ldr	q0, [sp, #1376]                 ; 16-byte Reload
	ldr	q2, [sp, #1280]                 ; 16-byte Reload
	fmaxnm.4s	v18, v2, v0
	ldr	q0, [sp, #8336]
	ldr	q1, [sp, #8320]
	bit.16b	v1, v18, v14
	bit.16b	v0, v19, v5
	str	q0, [sp, #8336]
	str	q1, [sp, #8320]
	fsub.4s	v1, v3, v17
	fsub.4s	v3, v6, v7
	fsub.4s	v6, v2, v18
	fsub.4s	v0, v4, v19
	stp	q0, q6, [sp, #528]              ; 32-byte Folded Spill
	and.16b	v3, v5, v3
	and.16b	v4, v14, v1
	mov	w6, #-1026555904                ; =0xc2d00000
	dup.4s	v22, w6
	fcmge.4s	v1, v4, v22
	fcmge.4s	v6, v3, v22
	mov	w6, #1120403456                 ; =0x42c80000
	dup.4s	v27, w6
	fcmge.4s	v20, v27, v4
	fcmge.4s	v21, v27, v3
	and.16b	v6, v6, v21
	and.16b	v1, v1, v20
	and.16b	v1, v1, v4
	and.16b	v24, v6, v3
	mov	w6, #43579                      ; =0xaa3b
	movk	w6, #16312, lsl #16
	dup.4s	v12, w6
	fmul.4s	v6, v24, v12
	fmul.4s	v20, v1, v12
	movi.4s	v2, #75, lsl #24
	mvni.4s	v29, #128, lsl #24
	mov.16b	v21, v29
	bsl.16b	v21, v2, v20
	mov.16b	v25, v29
	bsl.16b	v25, v2, v6
	fadd.4s	v6, v6, v25
	fadd.4s	v20, v20, v21
	fsub.4s	v20, v20, v21
	fsub.4s	v6, v6, v25
	fcvtzs.4s	v6, v6
	fcvtzs.4s	v21, v20
	scvtf.4s	v25, v21
	scvtf.4s	v26, v6
	mov	w6, #29184                      ; =0x7200
	movk	w6, #16177, lsl #16
	dup.4s	v20, w6
	fmul.4s	v29, v26, v20
	fmul.4s	v30, v25, v20
	fsub.4s	v1, v1, v30
	fsub.4s	v24, v24, v29
	mov	w6, #48782                      ; =0xbe8e
	movk	w6, #13759, lsl #16
	dup.4s	v16, w6
	fmul.4s	v29, v25, v16
	fmul.4s	v25, v26, v16
	fsub.4s	v24, v24, v25
	mov	w6, #11226                      ; =0x2bda
	movk	w6, #14672, lsl #16
	dup.4s	v25, w6
	fsub.4s	v1, v1, v29
	fmul.4s	v29, v1, v25
	fmul.4s	v30, v24, v25
	mov	w6, #38601                      ; =0x96c9
	movk	w6, #15030, lsl #16
	dup.4s	v26, w6
	fadd.4s	v30, v30, v26
	fadd.4s	v29, v29, v26
	fmul.4s	v31, v1, v29
	mov	w6, #34982                      ; =0x88a6
	movk	w6, #15368, lsl #16
	dup.4s	v29, w6
	fmul.4s	v30, v24, v30
	fadd.4s	v30, v30, v29
	fadd.4s	v31, v31, v29
	fmul.4s	v31, v1, v31
	fmul.4s	v8, v24, v30
	mov	w6, #43642                      ; =0xaa7a
	movk	w6, #15658, lsl #16
	dup.4s	v30, w6
	fadd.4s	v8, v8, v30
	fadd.4s	v31, v31, v30
	fmul.4s	v9, v1, v31
	fmul.4s	v8, v24, v8
	mov	w6, #43691                      ; =0xaaab
	movk	w6, #15914, lsl #16
	dup.4s	v31, w6
	fadd.4s	v8, v8, v31
	fadd.4s	v9, v9, v31
	fmul.4s	v9, v1, v9
	fmul.4s	v10, v24, v8
	movi.4s	v8, #63, lsl #24
	fadd.4s	v10, v10, v8
	fadd.4s	v9, v9, v8
	fmul.4s	v11, v24, v24
	fmul.4s	v13, v1, v1
	fmul.4s	v9, v13, v9
	fmul.4s	v10, v11, v10
	fadd.4s	v10, v24, v10
	fadd.4s	v1, v1, v9
	fmov.4s	v24, #1.00000000
	fadd.4s	v1, v1, v24
	fadd.4s	v9, v10, v24
	sshr.4s	v10, v21, #1
	sshr.4s	v11, v6, #1
	shl.4s	v13, v11, #23
	shl.4s	v28, v10, #23
	add.4s	v28, v28, v24
	add.4s	v13, v13, v24
	fmul.4s	v9, v9, v13
	fmul.4s	v1, v1, v28
	sub.4s	v6, v6, v11
	sub.4s	v21, v21, v10
	shl.4s	v21, v21, #23
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v24
	add.4s	v21, v21, v24
	fmul.4s	v1, v1, v21
	fmul.4s	v6, v9, v6
	fcmgt.4s	v21, v22, v3
	bic.16b	v6, v6, v21
	fcmgt.4s	v21, v22, v4
	bic.16b	v1, v1, v21
	fcmgt.4s	v21, v3, v27
	fcmgt.4s	v28, v4, v27
	mvni.4s	v9, #127, msl #16
	fneg.4s	v10, v9
	bit.16b	v1, v10, v28
	bit.16b	v6, v10, v21
	fcmeq.4s	v4, v4, v4
	fcmeq.4s	v3, v3, v3
	mvni.4s	v21, #63, msl #16
	fneg.4s	v11, v21
	mov.16b	v0, v3
	bsl.16b	v0, v6, v11
	mov.16b	v2, v4
	bsl.16b	v2, v1, v11
	stp	q2, q0, [sp, #560]              ; 32-byte Folded Spill
	ldr	q1, [sp, #8304]
	ldr	q3, [sp, #8288]
	bit.16b	v3, v2, v14
	bit.16b	v1, v0, v5
	str	q1, [sp, #8304]
	str	q3, [sp, #8288]
	ldp	q1, q0, [sp, #528]              ; 32-byte Folded Reload
	and.16b	v2, v5, v1
	mov.16b	v13, v5
	and.16b	v0, v14, v0
	fcmge.4s	v1, v0, v22
	fcmge.4s	v3, v2, v22
	fcmge.4s	v4, v27, v0
	fcmge.4s	v6, v27, v2
	and.16b	v3, v3, v6
	and.16b	v1, v1, v4
	and.16b	v1, v1, v0
	and.16b	v3, v3, v2
	fmul.4s	v4, v3, v12
	fmul.4s	v6, v1, v12
	movi.4s	v5, #75, lsl #24
	mvni.4s	v23, #128, lsl #24
	mov.16b	v21, v23
	bsl.16b	v21, v5, v6
	mov.16b	v28, v23
	bsl.16b	v28, v5, v4
	fadd.4s	v4, v4, v28
	fadd.4s	v6, v6, v21
	fsub.4s	v6, v6, v21
	fsub.4s	v4, v4, v28
	fcvtzs.4s	v4, v4
	fcvtzs.4s	v6, v6
	scvtf.4s	v21, v6
	fmul.4s	v28, v21, v20
	fsub.4s	v1, v1, v28
	scvtf.4s	v28, v4
	fmul.4s	v9, v28, v20
	fsub.4s	v3, v3, v9
	fmul.4s	v21, v21, v16
	fmul.4s	v28, v28, v16
	fsub.4s	v3, v3, v28
	fsub.4s	v1, v1, v21
	fmul.4s	v21, v1, v25
	fadd.4s	v21, v21, v26
	fmul.4s	v21, v1, v21
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v1, v21
	fadd.4s	v21, v21, v30
	fmul.4s	v21, v1, v21
	fadd.4s	v21, v21, v31
	fmul.4s	v21, v1, v21
	fadd.4s	v21, v21, v8
	fmul.4s	v28, v1, v1
	fmul.4s	v21, v28, v21
	fmul.4s	v28, v3, v25
	fadd.4s	v28, v28, v26
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v29
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v30
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v31
	fmul.4s	v28, v3, v28
	fadd.4s	v28, v28, v8
	fmul.4s	v9, v3, v3
	fmul.4s	v28, v9, v28
	fadd.4s	v3, v3, v28
	fadd.4s	v1, v1, v21
	fadd.4s	v1, v1, v24
	fadd.4s	v3, v3, v24
	sshr.4s	v21, v4, #1
	shl.4s	v28, v21, #23
	add.4s	v28, v28, v24
	fmul.4s	v3, v3, v28
	sshr.4s	v28, v6, #1
	shl.4s	v9, v28, #23
	add.4s	v9, v9, v24
	fmul.4s	v1, v1, v9
	sub.4s	v4, v4, v21
	sub.4s	v6, v6, v28
	shl.4s	v6, v6, #23
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v24
	add.4s	v6, v6, v24
	fmul.4s	v1, v1, v6
	fmul.4s	v3, v3, v4
	fcmgt.4s	v4, v22, v2
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v22, v0
	bic.16b	v1, v1, v4
	fcmgt.4s	v4, v2, v27
	fcmgt.4s	v6, v0, v27
	bit.16b	v1, v10, v6
	bit.16b	v3, v10, v4
	fcmeq.4s	v0, v0, v0
	fcmeq.4s	v2, v2, v2
	bsl.16b	v2, v3, v11
	mov.16b	v3, v0
	bsl.16b	v3, v1, v11
	stp	q3, q2, [sp, #528]              ; 32-byte Folded Spill
	ldr	q0, [sp, #8272]
	ldr	q1, [sp, #8256]
	bit.16b	v1, v3, v14
	bit.16b	v0, v2, v13
	str	q0, [sp, #8272]
	str	q1, [sp, #8256]
	ldr	q0, [sp, #8704]
	ldr	q1, [sp, #8720]
	fsub.4s	v4, v1, v7
	fsub.4s	v3, v0, v17
	ldr	q1, [sp, #8672]
	ldr	q0, [sp, #8688]
	fsub.4s	v0, v0, v7
	fsub.4s	v2, v1, v17
	ldr	q1, [sp, #8640]
	ldr	q6, [sp, #8656]
	fsub.4s	v6, v6, v7
	fsub.4s	v1, v1, v17
	stp	q1, q6, [sp, #352]              ; 32-byte Folded Spill
	ldr	q1, [sp, #8608]
	ldr	q6, [sp, #8624]
	fsub.4s	v6, v6, v19
	str	q6, [sp, #384]                  ; 16-byte Spill
	ldr	q6, [sp, #8576]
	ldr	q17, [sp, #8592]
	fsub.4s	v7, v17, v19
	str	q7, [sp, #416]                  ; 16-byte Spill
	ldr	q28, [sp, #8544]
	ldr	q17, [sp, #8560]
	fsub.4s	v7, v17, v19
	str	q7, [sp, #496]                  ; 16-byte Spill
	fsub.4s	v17, v1, v18
	fsub.4s	v1, v6, v18
	str	q1, [sp, #400]                  ; 16-byte Spill
	fsub.4s	v1, v28, v18
	str	q1, [sp, #464]                  ; 16-byte Spill
	and.16b	v3, v14, v3
	fcmge.4s	v6, v3, v22
	fcmge.4s	v18, v27, v3
	and.16b	v6, v6, v18
	and.16b	v4, v13, v4
	fcmge.4s	v18, v4, v22
	fcmge.4s	v19, v27, v4
	and.16b	v18, v18, v19
	and.16b	v18, v18, v4
	fmul.4s	v19, v18, v12
	mov.16b	v28, v23
	bsl.16b	v28, v5, v19
	fadd.4s	v19, v19, v28
	fsub.4s	v19, v19, v28
	and.16b	v28, v6, v3
	fmul.4s	v6, v28, v12
	mov.16b	v9, v23
	bsl.16b	v9, v5, v6
	fadd.4s	v6, v6, v9
	fsub.4s	v9, v6, v9
	fcvtzs.4s	v6, v19
	scvtf.4s	v19, v6
	fmul.4s	v1, v19, v20
	fsub.4s	v1, v18, v1
	fcvtzs.4s	v18, v9
	scvtf.4s	v9, v18
	fmul.4s	v21, v9, v20
	fsub.4s	v21, v28, v21
	fmul.4s	v28, v9, v16
	fsub.4s	v21, v21, v28
	fmul.4s	v19, v19, v16
	fsub.4s	v1, v1, v19
	fmul.4s	v19, v1, v25
	fadd.4s	v19, v19, v26
	fmul.4s	v19, v1, v19
	fadd.4s	v19, v19, v29
	fmul.4s	v19, v1, v19
	fadd.4s	v19, v19, v30
	fmul.4s	v19, v1, v19
	fadd.4s	v19, v19, v31
	fmul.4s	v19, v1, v19
	fadd.4s	v19, v19, v8
	fmul.4s	v28, v1, v1
	fmul.4s	v19, v28, v19
	fmul.4s	v28, v21, v25
	fadd.4s	v28, v28, v26
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v29
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v30
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v31
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v8
	fmul.4s	v9, v21, v21
	fmul.4s	v28, v9, v28
	fadd.4s	v21, v21, v28
	fadd.4s	v1, v1, v19
	fadd.4s	v19, v21, v24
	sshr.4s	v21, v18, #1
	shl.4s	v28, v21, #23
	add.4s	v28, v28, v24
	fmul.4s	v19, v19, v28
	fadd.4s	v1, v1, v24
	sshr.4s	v28, v6, #1
	shl.4s	v9, v28, #23
	add.4s	v9, v9, v24
	fmul.4s	v1, v1, v9
	sub.4s	v18, v18, v21
	sub.4s	v6, v6, v28
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v24
	fmul.4s	v1, v1, v6
	shl.4s	v6, v18, #23
	add.4s	v6, v6, v24
	fmul.4s	v6, v19, v6
	fcmgt.4s	v18, v22, v3
	bic.16b	v6, v6, v18
	fcmgt.4s	v18, v22, v4
	bic.16b	v1, v1, v18
	fcmgt.4s	v18, v4, v27
	bit.16b	v1, v10, v18
	fcmgt.4s	v18, v3, v27
	bit.16b	v6, v10, v18
	fcmeq.4s	v3, v3, v3
	bsl.16b	v3, v6, v11
	str	q3, [sp, #512]                  ; 16-byte Spill
	fcmeq.4s	v3, v4, v4
	bif.16b	v1, v11, v3
	str	q1, [sp, #480]                  ; 16-byte Spill
	and.16b	v2, v14, v2
	fcmge.4s	v1, v2, v22
	fcmge.4s	v3, v27, v2
	and.16b	v1, v1, v3
	and.16b	v0, v13, v0
	fcmge.4s	v3, v0, v22
	fcmge.4s	v4, v27, v0
	and.16b	v3, v3, v4
	and.16b	v4, v3, v0
	fmul.4s	v3, v4, v12
	mvni.4s	v5, #128, lsl #24
	movi.4s	v7, #75, lsl #24
	mov.16b	v6, v5
	bsl.16b	v6, v7, v3
	fadd.4s	v3, v3, v6
	fsub.4s	v3, v3, v6
	and.16b	v1, v1, v2
	fmul.4s	v6, v1, v12
	mov.16b	v18, v5
	bsl.16b	v18, v7, v6
	fadd.4s	v6, v6, v18
	fsub.4s	v6, v6, v18
	fcvtzs.4s	v3, v3
	scvtf.4s	v18, v3
	fmul.4s	v19, v18, v20
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v6, v6
	scvtf.4s	v19, v6
	fmul.4s	v21, v19, v20
	fsub.4s	v1, v1, v21
	fmul.4s	v19, v19, v16
	fsub.4s	v1, v1, v19
	fmul.4s	v18, v18, v16
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v25
	fadd.4s	v18, v18, v26
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v29
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v30
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v31
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v8
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v1, v25
	fadd.4s	v19, v19, v26
	fmul.4s	v19, v1, v19
	fadd.4s	v19, v19, v29
	fmul.4s	v19, v1, v19
	fadd.4s	v19, v19, v30
	fmul.4s	v19, v1, v19
	fadd.4s	v19, v19, v31
	fmul.4s	v19, v1, v19
	fadd.4s	v19, v19, v8
	fmul.4s	v21, v1, v1
	fmul.4s	v19, v21, v19
	fadd.4s	v1, v1, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v1, v1, v24
	sshr.4s	v18, v6, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v24
	fmul.4s	v1, v1, v19
	fadd.4s	v4, v4, v24
	sshr.4s	v19, v3, #1
	shl.4s	v21, v19, #23
	add.4s	v21, v21, v24
	fmul.4s	v4, v4, v21
	sub.4s	v6, v6, v18
	sub.4s	v3, v3, v19
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v24
	fmul.4s	v3, v4, v3
	shl.4s	v4, v6, #23
	add.4s	v4, v4, v24
	fmul.4s	v1, v1, v4
	fcmgt.4s	v4, v22, v2
	bic.16b	v1, v1, v4
	fcmgt.4s	v4, v22, v0
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v0, v27
	bit.16b	v3, v10, v4
	fcmgt.4s	v4, v2, v27
	bit.16b	v1, v10, v4
	fcmeq.4s	v2, v2, v2
	bif.16b	v1, v11, v2
	fcmeq.4s	v0, v0, v0
	bsl.16b	v0, v3, v11
	stp	q0, q1, [sp, #432]              ; 32-byte Folded Spill
	ldr	q0, [sp, #352]                  ; 16-byte Reload
	and.16b	v0, v14, v0
	fcmge.4s	v1, v0, v22
	fcmge.4s	v2, v27, v0
	and.16b	v1, v1, v2
	ldr	q2, [sp, #368]                  ; 16-byte Reload
	and.16b	v2, v13, v2
	fcmge.4s	v3, v2, v22
	fcmge.4s	v4, v27, v2
	and.16b	v3, v3, v4
	and.16b	v4, v3, v2
	fmul.4s	v3, v4, v12
	movi.4s	v6, #75, lsl #24
	mvni.4s	v7, #128, lsl #24
	mov.16b	v5, v7
	bsl.16b	v5, v6, v3
	fadd.4s	v3, v3, v5
	fsub.4s	v3, v3, v5
	and.16b	v1, v1, v0
	fmul.4s	v5, v1, v12
	bif.16b	v6, v5, v7
	movi.4s	v7, #75, lsl #24
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	fcvtzs.4s	v3, v3
	scvtf.4s	v6, v3
	fmul.4s	v18, v6, v20
	fsub.4s	v4, v4, v18
	fcvtzs.4s	v5, v5
	scvtf.4s	v18, v5
	fmul.4s	v19, v18, v20
	fsub.4s	v1, v1, v19
	fmul.4s	v18, v18, v16
	fsub.4s	v1, v1, v18
	fmul.4s	v6, v6, v16
	fsub.4s	v4, v4, v6
	fmul.4s	v6, v4, v25
	fadd.4s	v6, v6, v26
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v29
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v30
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v31
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v8
	fmul.4s	v18, v4, v4
	fmul.4s	v6, v18, v6
	fmul.4s	v18, v1, v25
	fadd.4s	v18, v18, v26
	fmul.4s	v18, v1, v18
	fadd.4s	v18, v18, v29
	fmul.4s	v18, v1, v18
	fadd.4s	v18, v18, v30
	fmul.4s	v18, v1, v18
	fadd.4s	v18, v18, v31
	fmul.4s	v18, v1, v18
	fadd.4s	v18, v18, v8
	fmul.4s	v19, v1, v1
	fmul.4s	v18, v19, v18
	fadd.4s	v1, v1, v18
	fadd.4s	v4, v4, v6
	fadd.4s	v1, v1, v24
	sshr.4s	v6, v5, #1
	shl.4s	v18, v6, #23
	add.4s	v18, v18, v24
	fmul.4s	v1, v1, v18
	fadd.4s	v4, v4, v24
	sshr.4s	v18, v3, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v24
	fmul.4s	v4, v4, v19
	sub.4s	v5, v5, v6
	sub.4s	v3, v3, v18
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v24
	fmul.4s	v3, v4, v3
	shl.4s	v4, v5, #23
	add.4s	v4, v4, v24
	fmul.4s	v1, v1, v4
	fcmgt.4s	v4, v22, v0
	bic.16b	v1, v1, v4
	fcmgt.4s	v4, v22, v2
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v2, v27
	bit.16b	v3, v10, v4
	fcmgt.4s	v4, v0, v27
	bit.16b	v1, v10, v4
	fcmeq.4s	v0, v0, v0
	bsl.16b	v0, v1, v11
	str	q0, [sp, #368]                  ; 16-byte Spill
	fcmeq.4s	v0, v2, v2
	mov.16b	v18, v0
	bsl.16b	v18, v3, v11
	and.16b	v0, v14, v17
	fcmge.4s	v1, v0, v22
	fcmge.4s	v2, v27, v0
	and.16b	v1, v1, v2
	ldr	q2, [sp, #384]                  ; 16-byte Reload
	and.16b	v2, v13, v2
	fcmge.4s	v3, v2, v22
	fcmge.4s	v5, v27, v2
	and.16b	v3, v3, v5
	and.16b	v5, v3, v2
	fmul.4s	v3, v5, v12
	mvni.4s	v4, #128, lsl #24
	mov.16b	v6, v4
	bsl.16b	v6, v7, v3
	fadd.4s	v3, v3, v6
	fsub.4s	v3, v3, v6
	and.16b	v1, v1, v0
	fmul.4s	v6, v1, v12
	mov.16b	v17, v4
	bsl.16b	v17, v7, v6
	fadd.4s	v6, v6, v17
	fsub.4s	v6, v6, v17
	fcvtzs.4s	v3, v3
	scvtf.4s	v17, v3
	fmul.4s	v19, v17, v20
	fsub.4s	v5, v5, v19
	fcvtzs.4s	v6, v6
	scvtf.4s	v19, v6
	fmul.4s	v21, v19, v20
	fsub.4s	v1, v1, v21
	fmul.4s	v19, v19, v16
	fsub.4s	v1, v1, v19
	fmul.4s	v17, v17, v16
	fsub.4s	v5, v5, v17
	fmul.4s	v17, v5, v25
	fadd.4s	v17, v17, v26
	fmul.4s	v17, v5, v17
	fadd.4s	v17, v17, v29
	fmul.4s	v17, v5, v17
	fadd.4s	v17, v17, v30
	fmul.4s	v17, v5, v17
	fadd.4s	v17, v17, v31
	fmul.4s	v17, v5, v17
	fadd.4s	v17, v17, v8
	fmul.4s	v19, v5, v5
	fmul.4s	v17, v19, v17
	fmul.4s	v19, v1, v25
	fadd.4s	v19, v19, v26
	fmul.4s	v19, v1, v19
	fadd.4s	v19, v19, v29
	fmul.4s	v19, v1, v19
	fadd.4s	v19, v19, v30
	fmul.4s	v19, v1, v19
	fadd.4s	v19, v19, v31
	fmul.4s	v19, v1, v19
	fadd.4s	v19, v19, v8
	fmul.4s	v21, v1, v1
	fmul.4s	v19, v21, v19
	fadd.4s	v1, v1, v19
	fadd.4s	v5, v5, v17
	fadd.4s	v1, v1, v24
	sshr.4s	v17, v6, #1
	shl.4s	v19, v17, #23
	add.4s	v19, v19, v24
	fmul.4s	v1, v1, v19
	fadd.4s	v5, v5, v24
	sshr.4s	v19, v3, #1
	shl.4s	v21, v19, #23
	add.4s	v21, v21, v24
	fmul.4s	v5, v5, v21
	sub.4s	v6, v6, v17
	sub.4s	v3, v3, v19
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v24
	fmul.4s	v3, v5, v3
	shl.4s	v5, v6, #23
	add.4s	v5, v5, v24
	fmul.4s	v1, v1, v5
	fcmgt.4s	v5, v22, v0
	bic.16b	v1, v1, v5
	fcmgt.4s	v5, v22, v2
	bic.16b	v3, v3, v5
	fcmgt.4s	v5, v2, v27
	bit.16b	v3, v10, v5
	fcmgt.4s	v5, v0, v27
	bit.16b	v1, v10, v5
	fcmeq.4s	v0, v0, v0
	mov.16b	v19, v0
	bsl.16b	v19, v1, v11
	fcmeq.4s	v0, v2, v2
	mov.16b	v17, v0
	bsl.16b	v17, v3, v11
	ldr	q0, [sp, #400]                  ; 16-byte Reload
	and.16b	v0, v14, v0
	fcmge.4s	v1, v0, v22
	fcmge.4s	v2, v27, v0
	and.16b	v1, v1, v2
	ldr	q2, [sp, #416]                  ; 16-byte Reload
	and.16b	v2, v13, v2
	fcmge.4s	v3, v2, v22
	fcmge.4s	v5, v27, v2
	and.16b	v3, v3, v5
	and.16b	v5, v3, v2
	fmul.4s	v3, v5, v12
	mov.16b	v6, v4
	bsl.16b	v6, v7, v3
	fadd.4s	v3, v3, v6
	fsub.4s	v3, v3, v6
	and.16b	v1, v1, v0
	fmul.4s	v6, v1, v12
	mov.16b	v21, v4
	bsl.16b	v21, v7, v6
	fadd.4s	v6, v6, v21
	fsub.4s	v6, v6, v21
	fcvtzs.4s	v3, v3
	scvtf.4s	v21, v3
	fmul.4s	v28, v21, v20
	fsub.4s	v5, v5, v28
	fcvtzs.4s	v6, v6
	scvtf.4s	v28, v6
	fmul.4s	v9, v28, v20
	fsub.4s	v1, v1, v9
	fmul.4s	v28, v28, v16
	fsub.4s	v1, v1, v28
	fmul.4s	v21, v21, v16
	fsub.4s	v5, v5, v21
	fmul.4s	v21, v5, v25
	fadd.4s	v21, v21, v26
	fmul.4s	v21, v5, v21
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v5, v21
	fadd.4s	v21, v21, v30
	fmul.4s	v21, v5, v21
	fadd.4s	v21, v21, v31
	fmul.4s	v21, v5, v21
	fadd.4s	v21, v21, v8
	fmul.4s	v28, v5, v5
	fmul.4s	v21, v28, v21
	fmul.4s	v28, v1, v25
	fadd.4s	v28, v28, v26
	fmul.4s	v28, v1, v28
	fadd.4s	v28, v28, v29
	fmul.4s	v28, v1, v28
	fadd.4s	v28, v28, v30
	fmul.4s	v28, v1, v28
	fadd.4s	v28, v28, v31
	fmul.4s	v28, v1, v28
	fadd.4s	v28, v28, v8
	fmul.4s	v9, v1, v1
	fmul.4s	v28, v9, v28
	fadd.4s	v1, v1, v28
	fadd.4s	v5, v5, v21
	fadd.4s	v1, v1, v24
	sshr.4s	v21, v6, #1
	shl.4s	v28, v21, #23
	add.4s	v28, v28, v24
	fmul.4s	v1, v1, v28
	fadd.4s	v5, v5, v24
	sshr.4s	v28, v3, #1
	shl.4s	v9, v28, #23
	add.4s	v9, v9, v24
	fmul.4s	v5, v5, v9
	sub.4s	v6, v6, v21
	sub.4s	v3, v3, v28
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v24
	fmul.4s	v3, v5, v3
	shl.4s	v5, v6, #23
	add.4s	v5, v5, v24
	fmul.4s	v1, v1, v5
	fcmgt.4s	v5, v22, v0
	bic.16b	v1, v1, v5
	fcmgt.4s	v5, v22, v2
	bic.16b	v3, v3, v5
	fcmgt.4s	v5, v2, v27
	bit.16b	v3, v10, v5
	fcmgt.4s	v5, v0, v27
	bit.16b	v1, v10, v5
	fcmeq.4s	v0, v0, v0
	bif.16b	v1, v11, v0
	fcmeq.4s	v0, v2, v2
	mov.16b	v5, v0
	bsl.16b	v5, v3, v11
	ldr	q0, [sp, #464]                  ; 16-byte Reload
	and.16b	v0, v14, v0
	fcmge.4s	v2, v0, v22
	fcmge.4s	v3, v27, v0
	and.16b	v3, v2, v3
	ldr	q2, [sp, #496]                  ; 16-byte Reload
	and.16b	v2, v13, v2
	fcmge.4s	v6, v2, v22
	fcmge.4s	v21, v27, v2
	and.16b	v6, v6, v21
	and.16b	v6, v6, v2
	and.16b	v3, v3, v0
	fmul.4s	v21, v3, v12
	fmul.4s	v23, v6, v12
	mov.16b	v28, v4
	bsl.16b	v28, v7, v23
	mov.16b	v9, v4
	bsl.16b	v9, v7, v21
	fadd.4s	v23, v23, v28
	fsub.4s	v23, v23, v28
	fadd.4s	v21, v21, v9
	fsub.4s	v21, v21, v9
	fcvtzs.4s	v23, v23
	scvtf.4s	v28, v23
	fmul.4s	v9, v28, v20
	fsub.4s	v6, v6, v9
	fcvtzs.4s	v21, v21
	scvtf.4s	v9, v21
	fmul.4s	v20, v9, v20
	fsub.4s	v3, v3, v20
	fmul.4s	v20, v28, v16
	fmul.4s	v28, v9, v16
	ldr	q16, [sp, #1504]                ; 16-byte Reload
	ldr	q12, [sp, #1520]                ; 16-byte Reload
	fsub.4s	v3, v3, v28
	fsub.4s	v6, v6, v20
	fmul.4s	v20, v6, v25
	fmul.4s	v25, v3, v25
	fadd.4s	v25, v25, v26
	fadd.4s	v20, v20, v26
	fmul.4s	v20, v6, v20
	fmul.4s	v25, v3, v25
	fadd.4s	v25, v25, v29
	fadd.4s	v20, v20, v29
	fmul.4s	v20, v6, v20
	fmul.4s	v25, v3, v25
	fadd.4s	v25, v25, v30
	fadd.4s	v20, v20, v30
	fmul.4s	v20, v6, v20
	fmul.4s	v25, v3, v25
	fadd.4s	v25, v25, v31
	fadd.4s	v20, v20, v31
	fmul.4s	v20, v6, v20
	fmul.4s	v25, v3, v25
	fadd.4s	v25, v25, v8
	fadd.4s	v20, v20, v8
	fmul.4s	v26, v3, v3
	fmul.4s	v28, v6, v6
	fmul.4s	v20, v28, v20
	fmul.4s	v25, v26, v25
	fadd.4s	v3, v3, v25
	fadd.4s	v6, v6, v20
	fadd.4s	v6, v6, v24
	fadd.4s	v3, v3, v24
	sshr.4s	v20, v23, #1
	sshr.4s	v25, v21, #1
	shl.4s	v26, v25, #23
	shl.4s	v28, v20, #23
	add.4s	v28, v28, v24
	add.4s	v26, v26, v24
	fmul.4s	v3, v3, v26
	fmul.4s	v6, v6, v28
	sub.4s	v21, v21, v25
	sub.4s	v20, v23, v20
	shl.4s	v20, v20, #23
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v24
	add.4s	v20, v20, v24
	fmul.4s	v6, v6, v20
	fmul.4s	v3, v3, v21
	fcmgt.4s	v20, v22, v0
	bic.16b	v3, v3, v20
	fcmgt.4s	v20, v22, v2
	bic.16b	v6, v6, v20
	fcmgt.4s	v20, v0, v27
	fcmgt.4s	v21, v2, v27
	bit.16b	v6, v10, v21
	bit.16b	v3, v10, v20
	fcmeq.4s	v2, v2, v2
	fcmeq.4s	v0, v0, v0
	mov.16b	v25, v0
	bsl.16b	v25, v3, v11
	mov.16b	v26, v2
	bsl.16b	v26, v6, v11
	ldr	q11, [sp, #1888]                ; 16-byte Reload
	ldrb	w6, [x9, #5]
	ubfx	w7, w6, #3, #1
	ubfx	w19, w6, #2, #1
	ubfx	w20, w6, #1, #1
	and	w21, w6, #0x1
	ubfx	w22, w6, #6, #1
	ubfx	w23, w6, #5, #1
	ubfx	w24, w6, #4, #1
	fmov	s0, w24
	mov.h	v0[1], w23
	mov.h	v0[2], w22
	lsr	w6, w6, #7
	mov.h	v0[3], w6
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	ldr	q2, [sp, #480]                  ; 16-byte Reload
	and.16b	v20, v0, v2
	fmov	s0, w21
	mov.h	v0[1], w20
	mov.h	v0[2], w19
	mov.h	v0[3], w7
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	ldr	q2, [sp, #512]                  ; 16-byte Reload
	and.16b	v21, v0, v2
	ldr	q0, [sp, #8240]
	ldr	q2, [sp, #8224]
	bit.16b	v2, v21, v14
	bit.16b	v0, v20, v13
	str	q0, [sp, #8240]
	str	q2, [sp, #8224]
	ldrb	w6, [x9, #3]
	ubfx	w7, w6, #3, #1
	ubfx	w19, w6, #2, #1
	ubfx	w20, w6, #1, #1
	and	w21, w6, #0x1
	lsr	w22, w6, #7
	ubfx	w23, w6, #6, #1
	ubfx	w24, w6, #5, #1
	ubfx	w6, w6, #4, #1
	fmov	s0, w6
	mov.h	v0[1], w24
	mov.h	v0[2], w23
	mov.h	v0[3], w22
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	fmov	s2, w21
	mov.h	v2[1], w20
	mov.h	v2[2], w19
	ldr	q3, [sp, #432]                  ; 16-byte Reload
	and.16b	v22, v0, v3
	mov.h	v2[3], w7
	ushll.4s	v0, v2, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	ldr	q2, [sp, #448]                  ; 16-byte Reload
	and.16b	v23, v0, v2
	ldr	q0, [sp, #8208]
	ldr	q2, [sp, #8192]
	bit.16b	v2, v23, v14
	bit.16b	v0, v22, v13
	str	q0, [sp, #8208]
	str	q2, [sp, #8192]
	ldrb	w6, [x9, #1]
	ubfx	w7, w6, #3, #1
	ubfx	w19, w6, #2, #1
	ubfx	w20, w6, #1, #1
	and	w21, w6, #0x1
	lsr	w22, w6, #7
	ubfx	w23, w6, #5, #1
	ubfx	w24, w6, #4, #1
	fmov	s0, w24
	mov.h	v0[1], w23
	ubfx	w6, w6, #6, #1
	mov.h	v0[2], w6
	mov.h	v0[3], w22
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	and.16b	v18, v0, v18
	fmov	s0, w21
	mov.h	v0[1], w20
	mov.h	v0[2], w19
	mov.h	v0[3], w7
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	ldr	q2, [sp, #368]                  ; 16-byte Reload
	and.16b	v24, v0, v2
	ldr	q0, [sp, #8176]
	ldr	q2, [sp, #8160]
	bit.16b	v2, v24, v14
	bit.16b	v0, v18, v13
	str	q0, [sp, #8176]
	str	q2, [sp, #8160]
	ldrb	w6, [x9, #4]
	ubfx	w7, w6, #3, #1
	ubfx	w19, w6, #2, #1
	ubfx	w20, w6, #1, #1
	and	w21, w6, #0x1
	lsr	w22, w6, #7
	ubfx	w23, w6, #6, #1
	ubfx	w24, w6, #5, #1
	ubfx	w6, w6, #4, #1
	fmov	s0, w6
	mov.h	v0[1], w24
	mov.h	v0[2], w23
	mov.h	v0[3], w22
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	fmov	s2, w21
	mov.h	v2[1], w20
	and.16b	v17, v0, v17
	mov.h	v2[2], w19
	mov.h	v2[3], w7
	ushll.4s	v0, v2, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	and.16b	v19, v0, v19
	ldr	q0, [sp, #8144]
	ldr	q2, [sp, #8128]
	bit.16b	v2, v19, v14
	bit.16b	v0, v17, v13
	str	q0, [sp, #8144]
	str	q2, [sp, #8128]
	ldrb	w6, [x9, #2]
	ubfx	w7, w6, #3, #1
	ubfx	w19, w6, #2, #1
	ubfx	w20, w6, #1, #1
	lsr	w21, w6, #7
	ubfx	w22, w6, #6, #1
	ubfx	w23, w6, #5, #1
	ubfx	w24, w6, #4, #1
	fmov	s0, w24
	mov.h	v0[1], w23
	mov.h	v0[2], w22
	mov.h	v0[3], w21
	and	w6, w6, #0x1
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	and.16b	v5, v0, v5
	fmov	s0, w6
	mov.h	v0[1], w20
	mov.h	v0[2], w19
	mov.h	v0[3], w7
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	and.16b	v27, v0, v1
	ldr	q0, [sp, #8112]
	ldr	q1, [sp, #8096]
	bit.16b	v1, v27, v14
	bit.16b	v0, v5, v13
	str	q0, [sp, #8112]
	str	q1, [sp, #8096]
	ldrb	w6, [x9]
	ubfx	w7, w6, #3, #1
	ubfx	w19, w6, #2, #1
	ubfx	w20, w6, #1, #1
	and	w21, w6, #0x1
	lsr	w22, w6, #7
	ubfx	w23, w6, #6, #1
	ubfx	w24, w6, #5, #1
	ubfx	w6, w6, #4, #1
	fmov	s0, w6
	mov.h	v0[1], w24
	mov.h	v0[2], w23
	mov.h	v0[3], w22
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	fmov	s1, w21
	mov.h	v1[1], w20
	mov.h	v1[2], w19
	mov.h	v1[3], w7
	and.16b	v26, v0, v26
	ushll.4s	v0, v1, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	and.16b	v25, v0, v25
	ldr	q0, [sp, #8080]
	ldr	q1, [sp, #8064]
	bit.16b	v1, v25, v14
	bit.16b	v0, v26, v13
	str	q0, [sp, #8080]
	str	q1, [sp, #8064]
	ldr	q9, [sp, #8048]
	ldr	q1, [sp, #8032]
	ldr	q8, [sp, #8016]
	ldr	q31, [sp, #8000]
	ldr	q6, [sp, #7984]
	ldr	q4, [sp, #7968]
	ldr	q3, [sp, #7952]
	ldr	q2, [sp, #7936]
	mov	b0, v15[0]
	mov.b	v0[4], v15[1]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v28, v0, #0
	mov	b0, v15[2]
	mov.b	v0[4], v15[3]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v29, v0, #0
	mov	b0, v15[4]
	mov.b	v0[4], v15[5]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v30, v0, #0
	mov	b0, v15[6]
	mov.b	v0[4], v15[7]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
Lloh58:
	adrp	x6, lCPI0_6@PAGE
Lloh59:
	ldr	q10, [x6, lCPI0_6@PAGEOFF]
	bit.16b	v9, v10, v0
	str	q9, [sp, #8048]
Lloh60:
	adrp	x6, lCPI0_7@PAGE
Lloh61:
	ldr	q9, [x6, lCPI0_7@PAGEOFF]
	bit.16b	v1, v9, v30
	str	q1, [sp, #8032]
Lloh62:
	adrp	x6, lCPI0_4@PAGE
Lloh63:
	ldr	q1, [x6, lCPI0_4@PAGEOFF]
	bit.16b	v8, v1, v29
	str	q8, [sp, #8016]
Lloh64:
	adrp	x6, lCPI0_5@PAGE
Lloh65:
	ldr	q8, [x6, lCPI0_5@PAGEOFF]
	bit.16b	v31, v8, v28
	str	q31, [sp, #8000]
	ldr	q31, [sp, #64]                  ; 16-byte Reload
	bit.16b	v6, v31, v0
	str	q6, [sp, #7984]
	bit.16b	v4, v31, v30
	str	q4, [sp, #7968]
	bit.16b	v3, v31, v29
	str	q3, [sp, #7952]
	bit.16b	v2, v31, v28
	str	q2, [sp, #7936]
	str	q10, [sp, #5056]
	mov.16b	v4, v11
	mov.16b	v10, v16
	ldr	q6, [sp, #1680]                 ; 16-byte Reload
	ldr	q11, [sp, #1536]                ; 16-byte Reload
	ldr	q3, [sp, #1744]                 ; 16-byte Reload
	str	q9, [sp, #5040]
	ldr	q9, [sp, #1456]                 ; 16-byte Reload
	str	q1, [sp, #5024]
	rbit	w5, w5
	clz	w6, w5
	str	q8, [sp, #5008]
	ldr	q8, [sp, #1488]                 ; 16-byte Reload
	ubfiz	x5, x6, #3, #3
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #912
	ldr	x19, [x7, x5]
	lsl	w6, w6, #2
	add	x7, sp, #2, lsl #12             ; =8192
	add	x7, x7, #3168
	sub	x19, x19, x6
	add	x19, x7, x19
	ldp	q1, q2, [x19]
	bit.16b	v1, v21, v14
	bit.16b	v2, v20, v13
	stp	q1, q2, [x19]
Lloh66:
	adrp	x19, lCPI0_8@PAGE
Lloh67:
	ldr	q1, [x19, lCPI0_8@PAGEOFF]
Lloh68:
	adrp	x19, lCPI0_9@PAGE
Lloh69:
	ldr	q2, [x19, lCPI0_9@PAGEOFF]
	str	q1, [sp, #5120]
	str	q2, [sp, #5104]
Lloh70:
	adrp	x19, lCPI0_10@PAGE
Lloh71:
	ldr	q1, [x19, lCPI0_10@PAGEOFF]
Lloh72:
	adrp	x19, lCPI0_11@PAGE
Lloh73:
	ldr	q2, [x19, lCPI0_11@PAGEOFF]
	str	q1, [sp, #5088]
	str	q2, [sp, #5072]
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #976
	ldr	x19, [x19, x5]
	sub	x19, x19, x6
	add	x19, x7, x19
	ldp	q2, q1, [x19]
	bit.16b	v1, v22, v13
	ldr	q22, [sp, #1712]                ; 16-byte Reload
	bit.16b	v2, v23, v14
	mov.16b	v23, v3
	ldr	q16, [sp, #1648]                ; 16-byte Reload
	stp	q2, q1, [x19]
Lloh74:
	adrp	x19, lCPI0_12@PAGE
Lloh75:
	ldr	q1, [x19, lCPI0_12@PAGEOFF]
Lloh76:
	adrp	x19, lCPI0_13@PAGE
Lloh77:
	ldr	q2, [x19, lCPI0_13@PAGEOFF]
	str	q1, [sp, #5184]
	str	q2, [sp, #5168]
Lloh78:
	adrp	x19, lCPI0_14@PAGE
Lloh79:
	ldr	q1, [x19, lCPI0_14@PAGEOFF]
Lloh80:
	adrp	x19, lCPI0_15@PAGE
Lloh81:
	ldr	q2, [x19, lCPI0_15@PAGEOFF]
	str	q1, [sp, #5152]
	str	q2, [sp, #5136]
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #1040
	ldr	x19, [x19, x5]
	sub	x19, x19, x6
	add	x19, x7, x19
	ldp	q2, q1, [x19]
	bit.16b	v1, v18, v13
	bit.16b	v2, v24, v14
	ldr	q24, [sp, #1664]                ; 16-byte Reload
	stp	q2, q1, [x19]
Lloh82:
	adrp	x19, lCPI0_16@PAGE
Lloh83:
	ldr	q1, [x19, lCPI0_16@PAGEOFF]
Lloh84:
	adrp	x19, lCPI0_17@PAGE
Lloh85:
	ldr	q2, [x19, lCPI0_17@PAGEOFF]
	str	q1, [sp, #5248]
	str	q2, [sp, #5232]
Lloh86:
	adrp	x19, lCPI0_18@PAGE
Lloh87:
	ldr	q1, [x19, lCPI0_18@PAGEOFF]
Lloh88:
	adrp	x19, lCPI0_19@PAGE
Lloh89:
	ldr	q2, [x19, lCPI0_19@PAGEOFF]
	str	q1, [sp, #5216]
	str	q2, [sp, #5200]
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #1104
	ldr	x19, [x19, x5]
	sub	x19, x19, x6
	add	x19, x7, x19
	ldp	q2, q1, [x19]
	bit.16b	v1, v17, v13
	bit.16b	v2, v19, v14
	stp	q2, q1, [x19]
Lloh90:
	adrp	x19, lCPI0_20@PAGE
Lloh91:
	ldr	q1, [x19, lCPI0_20@PAGEOFF]
Lloh92:
	adrp	x19, lCPI0_21@PAGE
Lloh93:
	ldr	q2, [x19, lCPI0_21@PAGEOFF]
	str	q1, [sp, #5312]
	str	q2, [sp, #5296]
Lloh94:
	adrp	x19, lCPI0_22@PAGE
Lloh95:
	ldr	q1, [x19, lCPI0_22@PAGEOFF]
Lloh96:
	adrp	x19, lCPI0_23@PAGE
Lloh97:
	ldr	q2, [x19, lCPI0_23@PAGEOFF]
	str	q1, [sp, #5280]
	str	q2, [sp, #5264]
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #1168
	ldr	x19, [x19, x5]
	sub	x19, x19, x6
	add	x19, x7, x19
	ldp	q2, q1, [x19]
	bit.16b	v1, v5, v13
	bit.16b	v2, v27, v14
	mov.16b	v27, v6
	stp	q2, q1, [x19]
Lloh98:
	adrp	x19, lCPI0_24@PAGE
Lloh99:
	ldr	q1, [x19, lCPI0_24@PAGEOFF]
Lloh100:
	adrp	x19, lCPI0_25@PAGE
Lloh101:
	ldr	q2, [x19, lCPI0_25@PAGEOFF]
	str	q1, [sp, #5376]
	str	q2, [sp, #5360]
Lloh102:
	adrp	x19, lCPI0_26@PAGE
Lloh103:
	ldr	q1, [x19, lCPI0_26@PAGEOFF]
Lloh104:
	adrp	x19, lCPI0_27@PAGE
Lloh105:
	ldr	q2, [x19, lCPI0_27@PAGEOFF]
	str	q1, [sp, #5344]
	str	q2, [sp, #5328]
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #1232
	ldr	x5, [x19, x5]
	sub	x5, x5, x6
	add	x5, x7, x5
	ldp	q2, q1, [x5]
	bit.16b	v1, v26, v13
	bit.16b	v2, v25, v14
	ldr	q25, [sp, #1728]                ; 16-byte Reload
	ldr	q26, [sp, #1696]                ; 16-byte Reload
	stp	q2, q1, [x5]
	ldr	q1, [sp, #1568]                 ; 16-byte Reload
	ldp	q2, q5, [sp, #560]              ; 32-byte Folded Reload
	fmul.4s	v1, v1, v2
	ldr	q2, [sp, #7920]
	ldr	q3, [sp, #7904]
	bif.16b	v1, v3, v14
	ldr	q3, [sp, #1552]                 ; 16-byte Reload
	fmul.4s	v3, v3, v5
	bit.16b	v2, v3, v13
	str	q2, [sp, #7920]
	str	q1, [sp, #7904]
	ldr	q1, [sp, #1312]                 ; 16-byte Reload
	ldp	q2, q5, [sp, #528]              ; 32-byte Folded Reload
	fmul.4s	v1, v1, v2
	ldr	q2, [sp, #7888]
	ldr	q3, [sp, #7872]
	bif.16b	v1, v3, v14
	ldr	q3, [sp, #1296]                 ; 16-byte Reload
	fmul.4s	v3, v3, v5
	bit.16b	v2, v3, v13
	str	q2, [sp, #7888]
	str	q1, [sp, #7872]
	bic.16b	v22, v22, v0
	bic.16b	v16, v16, v30
	ldr	q31, [sp, #1472]                ; 16-byte Reload
	bic.16b	v25, v25, v29
	mov.16b	v29, v16
	bic.16b	v4, v4, v28
	str	q4, [sp, #1888]                 ; 16-byte Spill
	ldr	q0, [sp, #1392]                 ; 16-byte Reload
	bic.16b	v0, v0, v13
	str	q0, [sp, #1392]                 ; 16-byte Spill
	ldr	q0, [sp, #1408]                 ; 16-byte Reload
	bic.16b	v0, v0, v14
	str	q0, [sp, #1408]                 ; 16-byte Spill
LBB0_1221:                              ; %schedule.35
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d4, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v4
	addv.8b	b0, v0
	fmov	w6, s0
	mov	w5, #3                          ; =0x3
	dup.2d	v0, x5
	cmgt.2d	v1, v0, v25
	ldr	q2, [sp, #1888]                 ; 16-byte Reload
	cmgt.2d	v2, v0, v2
	uzp1.4s	v1, v2, v1
	cmgt.2d	v2, v0, v29
	cmgt.2d	v3, v0, v22
	uzp1.4s	v2, v2, v3
	uzp1.8h	v1, v1, v2
	xtn.8b	v1, v1
	and.8b	v7, v15, v1
	shl.8b	v1, v7, #7
	cmlt.8b	v1, v1, #0
	and.8b	v2, v1, v4
	addv.8b	b2, v2
	fmov	w5, s2
	umaxv.8b	b1, v1
	fmov	w7, s1
	tbz	w7, #0, LBB0_1227
; %bb.1222:                             ; %schedule.35
                                        ;   in Loop: Header=BB0_6 Depth=2
	cmge.2d	v1, v25, v0
	ldr	q2, [sp, #1888]                 ; 16-byte Reload
	cmge.2d	v2, v2, v0
	uzp1.4s	v1, v2, v1
	cmge.2d	v2, v29, v0
	cmge.2d	v0, v22, v0
	uzp1.4s	v0, v2, v0
	uzp1.8h	v0, v1, v0
	xtn.8b	v0, v0
	and.8b	v16, v15, v0
	shl.8b	v0, v16, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w7, s0
	tst	w7, #0xff
	b.eq	LBB0_1227
; %bb.1223:                             ; %varying.divergent762
                                        ;   in Loop: Header=BB0_6 Depth=2
	cmp	w4, #0
	cset	w5, ne
	sub	w5, w4, w5
	and	w6, w0, #0xff
	lsr	w7, w6, w5
	tst	w7, #0x1
	cset	w7, eq
	cmp	w4, #0
	str	q24, [sp, #4688]
	str	q27, [sp, #4704]
	and	x5, x5, #0x7
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #592
	ldr	w5, [x19, x5, lsl #2]
	csinc	w7, w7, wzr, ne
	cmp	w5, #16
	csinc	w5, w7, wzr, eq
	cmp	w6, #255
	b.ne	LBB0_1225
; %bb.1224:                             ; %varying.divergent762
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #0, LBB0_1348
LBB0_1225:                              ; %convergence.overflow.resume765
                                        ;   in Loop: Header=BB0_6 Depth=2
	mvn	w6, w0
	rbit	w6, w6
	clz	w6, w6
	mov	w7, #255                        ; =0xff
	bics	wzr, w7, w0
	csel	w7, wzr, w6, eq
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #3560
	ldrb	w20, [x6, w7, uxtw]
	and	w19, w20, #0x1
	fmov	s0, w19
	ubfx	w19, w20, #1, #1
	mov.b	v0[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v0[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v0[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v0[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v0[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v0[6], w19
	add	x19, sp, #2, lsl #12            ; =8192
	add	x19, x19, #3552
	lsr	w20, w20, #7
	mov.b	v0[7], w20
	ldrb	w20, [x19, w7, uxtw]
	and	w21, w20, #0x1
	fmov	s1, w21
	ubfx	w21, w20, #1, #1
	mov.b	v1[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v1[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v1[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v1[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v1[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v1[6], w21
	lsr	w20, w20, #7
	mov.b	v1[7], w20
	cmp	w5, #0
	csetm	w20, ne
	dup.8b	v2, w20
	bit.8b	v0, v15, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	ldr	d3, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x6, w7, uxtw]
	bic.8b	v0, v1, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x19, w7, uxtw]
	cmp	x1, #8
	b.hs	LBB0_1348
; %bb.1226:                             ; %ready.overflow.resume767
                                        ;   in Loop: Header=BB0_6 Depth=2
	str	q9, [sp, #4656]
	ldr	q0, [sp, #1968]                 ; 16-byte Reload
	str	q0, [sp, #4672]
	ubfiz	x6, x7, #2, #3
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #560
	ldr	w19, [x19, x6]
	cmp	w5, #0
	csel	w19, w4, w19, ne
	csinc	w4, w4, w7, eq
	str	q9, [sp, #4624]
	str	q0, [sp, #4640]
	add	x20, sp, #1, lsl #12            ; =4096
	add	x20, x20, #528
	str	w19, [x20, x6]
	ldr	q0, [sp, #4640]
	str	q0, [sp, #1968]                 ; 16-byte Spill
	ldr	q9, [sp, #4624]
	str	q24, [sp, #4592]
	str	q27, [sp, #4608]
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #496
	ldr	w19, [x19, x6]
	mov	w20, #16                        ; =0x10
	csel	w19, w20, w19, ne
	str	q24, [sp, #4560]
	str	q27, [sp, #4576]
	add	x20, sp, #1, lsl #12            ; =4096
	add	x20, x20, #464
	str	w19, [x20, x6]
	mov	w6, #37                         ; =0x25
	mov	w19, #36                        ; =0x24
	ldr	q27, [sp, #4576]
	ldr	q24, [sp, #4560]
	b	LBB0_1261
LBB0_1227:                              ; %varying.coherent763
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w5, #0xff
	b.eq	LBB0_1246
; %bb.1228:                             ; %varying.coherent.true768
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w5, #0                          ; =0x0
	tst	w6, #0xff
	b.eq	LBB0_4
LBB0_1229:                              ; %schedule.36
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	b0, v15[6]
	mov.b	v0[4], v15[7]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	and.16b	v0, v0, v22
	mov	b1, v15[4]
	mov.b	v1[4], v15[5]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	mov	b2, v15[2]
	mov.b	v2[4], v15[3]
	and.16b	v1, v1, v29
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v2, v2, #0
	and.16b	v2, v2, v25
	mov	b3, v15[0]
	mov.b	v3[4], v15[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q4, [sp, #1888]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	shl.8b	v4, v15, #7
	cmlt.8b	v4, v4, #0
	ldr	d5, [sp, #1992]                 ; 8-byte Reload
	and.8b	v4, v4, v5
	addv.8b	b4, v4
	fmov	w6, s4
	ldr	x7, [sp, #11256]
	add	x7, x7, x7, lsl #1
	lsl	x7, x7, #1
	dup.2d	v4, x7
	add.2d	v3, v4, v3
	add.2d	v2, v4, v2
	add.2d	v1, v4, v1
	add.2d	v0, v4, v0
	ldr	q5, [sp, #7936]
	ldr	q6, [sp, #7952]
	ldr	q4, [sp, #7968]
	ldr	q7, [sp, #7984]
	ldr	q16, [sp, #8048]
	ldr	q17, [sp, #8032]
	ldr	q18, [sp, #8016]
	ldr	q19, [sp, #8000]
	shl.2d	v0, v0, #5
	shl.2d	v1, v1, #5
	shl.2d	v20, v2, #5
	shl.2d	v3, v3, #5
	add.2d	v2, v7, v16
	add.2d	v2, v2, v0
	add.2d	v0, v4, v17
	add.2d	v4, v0, v1
	add.2d	v0, v6, v18
	add.2d	v1, v0, v20
	add.2d	v0, v5, v19
	add.2d	v5, v0, v3
	movi.2d	v0, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w6, #0, LBB0_1239
; %bb.1230:                             ; %else8228
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #1, LBB0_1240
LBB0_1231:                              ; %else8234
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #2, LBB0_1241
LBB0_1232:                              ; %else8240
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #3, LBB0_1242
LBB0_1233:                              ; %else8246
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #4, LBB0_1243
LBB0_1234:                              ; %else8252
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #5, LBB0_1244
LBB0_1235:                              ; %else8258
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #6, LBB0_1245
LBB0_1236:                              ; %else8264
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w6, #7, LBB0_1238
LBB0_1237:                              ; %cond.load8266
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v2[1]
	ld1.s	{ v3 }[3], [x6]
LBB0_1238:                              ; %else8270
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q4, [sp, #1408]                 ; 16-byte Reload
	fadd.4s	v0, v4, v0
	ldr	q5, [sp, #1392]                 ; 16-byte Reload
	fadd.4s	v1, v5, v3
	movi.8b	v2, #1
	and.8b	v2, v15, v2
	ushll.8h	v2, v2, #0
	ushll.4s	v3, v2, #0
	ushll2.4s	v2, v2, #0
	uaddw2.2d	v22, v22, v2
	uaddw.2d	v29, v29, v2
	uaddw2.2d	v25, v25, v3
	ldr	q2, [sp, #1888]                 ; 16-byte Reload
	uaddw.2d	v2, v2, v3
	str	q2, [sp, #1888]                 ; 16-byte Spill
	zip2.8b	v2, v15, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	bit.16b	v5, v1, v2
	str	q5, [sp, #1392]                 ; 16-byte Spill
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	bit.16b	v4, v0, v1
	str	q4, [sp, #1408]                 ; 16-byte Spill
	tbz	w5, #0, LBB0_1221
	b	LBB0_4
LBB0_1239:                              ; %cond.load8224
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d5
	ldr	s0, [x7]
	tbz	w6, #1, LBB0_1231
LBB0_1240:                              ; %cond.load8230
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v5[1]
	ld1.s	{ v0 }[1], [x7]
	tbz	w6, #2, LBB0_1232
LBB0_1241:                              ; %cond.load8236
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d1
	ld1.s	{ v0 }[2], [x7]
	tbz	w6, #3, LBB0_1233
LBB0_1242:                              ; %cond.load8242
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v1[1]
	ld1.s	{ v0 }[3], [x7]
	tbz	w6, #4, LBB0_1234
LBB0_1243:                              ; %cond.load8248
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d4
	ld1.s	{ v3 }[0], [x7]
	tbz	w6, #5, LBB0_1235
LBB0_1244:                              ; %cond.load8254
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v4[1]
	ld1.s	{ v3 }[1], [x7]
	tbz	w6, #6, LBB0_1236
LBB0_1245:                              ; %cond.load8260
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d2
	ld1.s	{ v3 }[2], [x7]
	tbnz	w6, #7, LBB0_1237
	b	LBB0_1238
LBB0_1246:                              ; %varying.coherent.false769
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w6, #0xff
	b.eq	LBB0_4
LBB0_1247:                              ; %schedule.37
                                        ;   in Loop: Header=BB0_6 Depth=2
	cbz	w4, LBB0_1252
; %bb.1248:                             ; %convergence.cascade777.preheader
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w5, #0                          ; =0x0
LBB0_1249:                              ; %convergence.cascade777
                                        ;   Parent Loop BB0_5 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d6, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v0, v6
	addv.8b	b1, v1
	fmov	w6, s1
	umaxv.8b	b0, v0
	fmov	w20, s0
	sub	w7, w4, #1
	tst	w6, #0xff
	csel	w7, w7, wzr, ne
	mov	w6, #1                          ; =0x1
	lsl	w19, w6, w7
	and	w6, w19, w0
	tst	w6, #0xff
	cset	w22, ne
	str	q24, [sp, #4976]
	str	q27, [sp, #4992]
	ubfiz	x6, x7, #2, #3
	add	x21, sp, #1, lsl #12            ; =4096
	add	x21, x21, #880
	ldr	w21, [x21, x6]
	cmp	w21, #16
	cset	w21, eq
	and	w22, w22, w20
	add	x20, sp, #2, lsl #12            ; =8192
	add	x20, x20, #3560
	ldrb	w24, [x20, w7, sxtw]
	and	w23, w24, #0x1
	fmov	s0, w23
	ubfx	w23, w24, #1, #1
	mov.b	v0[1], w23
	ubfx	w23, w24, #2, #1
	mov.b	v0[2], w23
	ubfx	w23, w24, #3, #1
	mov.b	v0[3], w23
	ubfx	w23, w24, #4, #1
	mov.b	v0[4], w23
	ubfx	w23, w24, #5, #1
	mov.b	v0[5], w23
	ubfx	w23, w24, #6, #1
	mov.b	v0[6], w23
	add	x23, sp, #2, lsl #12            ; =8192
	add	x23, x23, #3552
	lsr	w24, w24, #7
	mov.b	v0[7], w24
	ldrb	w24, [x23, w7, sxtw]
	and	w25, w24, #0x1
	fmov	s1, w25
	ubfx	w25, w24, #1, #1
	mov.b	v1[1], w25
	ubfx	w25, w24, #2, #1
	mov.b	v1[2], w25
	ubfx	w25, w24, #3, #1
	mov.b	v1[3], w25
	ubfx	w25, w24, #4, #1
	mov.b	v1[4], w25
	ubfx	w25, w24, #5, #1
	mov.b	v1[5], w25
	ubfx	w25, w24, #6, #1
	mov.b	v1[6], w25
	lsr	w24, w24, #7
	mov.b	v1[7], w24
	orr.8b	v2, v15, v1
	ldr	d3, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v3, v0
	eor.8b	v3, v3, v2
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w24, s3
	ands	w21, w22, w21
	csetm	w22, ne
	bics	w24, w21, w24
	csetm	w25, ne
	dup.8b	v3, w25
	bic.8b	v4, v2, v3
	dup.8b	v5, w22
	bit.8b	v1, v4, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v6
	addv.8b	b1, v1
	str	b1, [x23, w7, sxtw]
	bic.8b	v0, v0, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	str	b0, [x20, w7, sxtw]
	mov	w7, #-1                         ; =0xffffffff
	csinv	w7, w7, w19, eq
	and	w0, w7, w0
	dup.8b	v0, w21
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	dup.8b	v1, w24
	and.8b	v1, v1, v2
	str	q9, [sp, #4944]
	ldr	q2, [sp, #1968]                 ; 16-byte Reload
	str	q2, [sp, #4960]
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #848
	ldr	w6, [x7, x6]
	csel	w4, w6, w4, ne
	bit.8b	v15, v1, v0
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	fmov	w6, s0
	cmp	w21, #1
	b.ne	LBB0_1253
; %bb.1250:                             ; %convergence.cascade777
                                        ;   in Loop: Header=BB0_1249 Depth=3
	cmp	w4, #0
	ccmp	w5, #6, #2, ne
	b.hi	LBB0_1253
; %bb.1251:                             ; %convergence.cascade777
                                        ;   in Loop: Header=BB0_1249 Depth=3
	add	w5, w5, #1
	tst	w6, #0xff
	b.ne	LBB0_1249
	b	LBB0_1253
LBB0_1252:                              ; %schedule.37.convergence.cascade.exit778_crit_edge
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w6, s0
LBB0_1253:                              ; %convergence.cascade.exit778
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w6, #0xff
	b.eq	LBB0_4
; %bb.1254:                             ; %convergence.target.37.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	b0, v15[6]
	mov.b	v0[4], v15[7]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmge.2d	v0, v0, #0
	and.16b	v12, v0, v12
	mov	b0, v15[4]
	mov.b	v0[4], v15[5]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmge.2d	v0, v0, #0
	ldr	q1, [sp, #1920]                 ; 16-byte Reload
	and.16b	v1, v0, v1
	str	q1, [sp, #1920]                 ; 16-byte Spill
	mov	b0, v15[2]
	mov.b	v0[4], v15[3]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmge.2d	v0, v0, #0
	and.16b	v23, v0, v23
	mov	b0, v15[0]
	mov.b	v0[4], v15[1]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmge.2d	v0, v0, #0
	ldr	q1, [sp, #1904]                 ; 16-byte Reload
	and.16b	v1, v0, v1
	str	q1, [sp, #1904]                 ; 16-byte Spill
	zip1.8b	v0, v15, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	ldr	q2, [sp, #1424]                 ; 16-byte Reload
	and.16b	v2, v1, v2
	str	q2, [sp, #1424]                 ; 16-byte Spill
	cmge.4s	v0, v0, #0
	ldr	q1, [sp, #1440]                 ; 16-byte Reload
	and.16b	v1, v0, v1
	str	q1, [sp, #1440]                 ; 16-byte Spill
LBB0_1255:                              ; %schedule.38
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d4, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v4
	addv.8b	b0, v0
	fmov	w6, s0
	mov	w5, #3                          ; =0x3
	dup.2d	v0, x5
	cmgt.2d	v1, v0, v23
	ldr	q2, [sp, #1904]                 ; 16-byte Reload
	cmgt.2d	v2, v0, v2
	uzp1.4s	v1, v2, v1
	ldr	q2, [sp, #1920]                 ; 16-byte Reload
	cmgt.2d	v2, v0, v2
	cmgt.2d	v3, v0, v12
	uzp1.4s	v2, v2, v3
	uzp1.8h	v1, v1, v2
	xtn.8b	v1, v1
	and.8b	v7, v15, v1
	shl.8b	v1, v7, #7
	cmlt.8b	v1, v1, #0
	and.8b	v2, v1, v4
	addv.8b	b2, v2
	fmov	w5, s2
	umaxv.8b	b1, v1
	fmov	w7, s1
	tbz	w7, #0, LBB0_1263
; %bb.1256:                             ; %schedule.38
                                        ;   in Loop: Header=BB0_6 Depth=2
	cmge.2d	v1, v23, v0
	ldr	q2, [sp, #1904]                 ; 16-byte Reload
	cmge.2d	v2, v2, v0
	uzp1.4s	v1, v2, v1
	ldr	q2, [sp, #1920]                 ; 16-byte Reload
	cmge.2d	v2, v2, v0
	cmge.2d	v0, v12, v0
	uzp1.4s	v0, v2, v0
	uzp1.8h	v0, v1, v0
	xtn.8b	v0, v0
	and.8b	v16, v15, v0
	shl.8b	v0, v16, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w7, s0
	tst	w7, #0xff
	b.eq	LBB0_1263
; %bb.1257:                             ; %varying.divergent795
                                        ;   in Loop: Header=BB0_6 Depth=2
	cmp	w4, #0
	cset	w5, ne
	sub	w5, w4, w5
	and	w6, w0, #0xff
	lsr	w7, w6, w5
	tst	w7, #0x1
	cset	w7, eq
	cmp	w4, #0
	str	q24, [sp, #4848]
	str	q27, [sp, #4864]
	and	x5, x5, #0x7
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #752
	ldr	w5, [x19, x5, lsl #2]
	csinc	w7, w7, wzr, ne
	cmp	w5, #17
	csinc	w5, w7, wzr, eq
	cmp	w6, #255
	b.ne	LBB0_1259
; %bb.1258:                             ; %varying.divergent795
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w5, #0, LBB0_1348
LBB0_1259:                              ; %convergence.overflow.resume798
                                        ;   in Loop: Header=BB0_6 Depth=2
	mvn	w6, w0
	rbit	w6, w6
	clz	w6, w6
	mov	w7, #255                        ; =0xff
	bics	wzr, w7, w0
	csel	w7, wzr, w6, eq
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #3560
	ldrb	w20, [x6, w7, uxtw]
	and	w19, w20, #0x1
	fmov	s0, w19
	ubfx	w19, w20, #1, #1
	mov.b	v0[1], w19
	ubfx	w19, w20, #2, #1
	mov.b	v0[2], w19
	ubfx	w19, w20, #3, #1
	mov.b	v0[3], w19
	ubfx	w19, w20, #4, #1
	mov.b	v0[4], w19
	ubfx	w19, w20, #5, #1
	mov.b	v0[5], w19
	ubfx	w19, w20, #6, #1
	mov.b	v0[6], w19
	add	x19, sp, #2, lsl #12            ; =8192
	add	x19, x19, #3552
	lsr	w20, w20, #7
	mov.b	v0[7], w20
	ldrb	w20, [x19, w7, uxtw]
	and	w21, w20, #0x1
	fmov	s1, w21
	ubfx	w21, w20, #1, #1
	mov.b	v1[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v1[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v1[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v1[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v1[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v1[6], w21
	lsr	w20, w20, #7
	mov.b	v1[7], w20
	cmp	w5, #0
	csetm	w20, ne
	dup.8b	v2, w20
	bit.8b	v0, v15, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	ldr	d3, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x6, w7, uxtw]
	bic.8b	v0, v1, v2
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x19, w7, uxtw]
	cmp	x1, #8
	b.hs	LBB0_1348
; %bb.1260:                             ; %ready.overflow.resume800
                                        ;   in Loop: Header=BB0_6 Depth=2
	str	q9, [sp, #4816]
	ldr	q0, [sp, #1968]                 ; 16-byte Reload
	str	q0, [sp, #4832]
	ubfiz	x6, x7, #2, #3
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #720
	ldr	w19, [x19, x6]
	cmp	w5, #0
	csel	w19, w4, w19, ne
	csinc	w4, w4, w7, eq
	str	q9, [sp, #4784]
	str	q0, [sp, #4800]
	add	x20, sp, #1, lsl #12            ; =4096
	add	x20, x20, #688
	str	w19, [x20, x6]
	ldr	q0, [sp, #4800]
	str	q0, [sp, #1968]                 ; 16-byte Spill
	ldr	q9, [sp, #4784]
	str	q24, [sp, #4752]
	str	q27, [sp, #4768]
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #656
	ldr	w19, [x19, x6]
	mov	w20, #17                        ; =0x11
	csel	w19, w20, w19, ne
	str	q24, [sp, #4720]
	str	q27, [sp, #4736]
	add	x20, sp, #1, lsl #12            ; =4096
	add	x20, x20, #624
	str	w19, [x20, x6]
	mov	w6, #40                         ; =0x28
	mov	w19, #39                        ; =0x27
	ldr	q27, [sp, #4736]
	ldr	q24, [sp, #4720]
LBB0_1261:                              ; %scheduler.dispatch.route.backedge
                                        ;   in Loop: Header=BB0_6 Depth=2
                                        ; kill: def $w7 killed $w7 killed $x7 def $x7
LBB0_1262:                              ; %scheduler.dispatch.route.backedge
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w20, #1                         ; =0x1
	lsl	w7, w20, w7
	cmp	w5, #0
	csel	w5, w7, wzr, ne
	add	x7, sp, #2, lsl #12             ; =8192
	add	x7, x7, #3640
	shl.8b	v0, v7, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	str	b0, [x7, x1]
	add	x7, sp, #2, lsl #12             ; =8192
	add	x7, x7, #3600
	str	w19, [x7, x1, lsl #2]
	orr	w0, w5, w0
	add	x5, sp, #2, lsl #12             ; =8192
	add	x5, x5, #3568
	str	w4, [x5, x1, lsl #2]
	add	x1, x1, #1
	mov.16b	v15, v16
	cmp	w6, #47
	b.ls	LBB0_6
	b	LBB0_1348
LBB0_1263:                              ; %varying.coherent796
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w5, #0xff
	b.eq	LBB0_1282
; %bb.1264:                             ; %varying.coherent.true801
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w5, #0                          ; =0x0
	tst	w6, #0xff
	b.eq	LBB0_4
LBB0_1265:                              ; %schedule.39
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	b0, v15[6]
	mov.b	v0[4], v15[7]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	and.16b	v0, v0, v12
	mov	b1, v15[4]
	mov.b	v1[4], v15[5]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	ldr	q2, [sp, #1920]                 ; 16-byte Reload
	and.16b	v1, v1, v2
	mov	b2, v15[2]
	mov.b	v2[4], v15[3]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v2, v2, #0
	mov	b3, v15[0]
	mov.b	v3[4], v15[1]
	and.16b	v2, v2, v23
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q4, [sp, #1904]                 ; 16-byte Reload
	and.16b	v3, v3, v4
	shl.8b	v4, v15, #7
	cmlt.8b	v4, v4, #0
	ldr	d5, [sp, #1992]                 ; 8-byte Reload
	and.8b	v4, v4, v5
	addv.8b	b4, v4
	fmov	w6, s4
	ldr	x7, [sp, #11256]
	mov	w19, #6                         ; =0x6
	mov	x20, #3                         ; =0x3
	madd	x7, x7, x19, x20
	dup.2d	v4, x7
	add.2d	v3, v4, v3
	add.2d	v2, v4, v2
	add.2d	v1, v4, v1
	add.2d	v0, v4, v0
	ldr	q5, [sp, #7936]
	ldr	q6, [sp, #7952]
	ldr	q4, [sp, #7968]
	ldr	q7, [sp, #7984]
	ldr	q16, [sp, #8048]
	ldr	q17, [sp, #8032]
	ldr	q18, [sp, #8016]
	ldr	q19, [sp, #8000]
	shl.2d	v0, v0, #5
	shl.2d	v1, v1, #5
	shl.2d	v20, v2, #5
	shl.2d	v3, v3, #5
	add.2d	v2, v7, v16
	add.2d	v2, v2, v0
	add.2d	v0, v4, v17
	add.2d	v4, v0, v1
	add.2d	v0, v6, v18
	add.2d	v1, v0, v20
	add.2d	v0, v5, v19
	add.2d	v5, v0, v3
	movi.2d	v0, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w6, #0, LBB0_1275
; %bb.1266:                             ; %else8277
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #1, LBB0_1276
LBB0_1267:                              ; %else8283
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #2, LBB0_1277
LBB0_1268:                              ; %else8289
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #3, LBB0_1278
LBB0_1269:                              ; %else8295
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #4, LBB0_1279
LBB0_1270:                              ; %else8301
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #5, LBB0_1280
LBB0_1271:                              ; %else8307
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbnz	w6, #6, LBB0_1281
LBB0_1272:                              ; %else8313
                                        ;   in Loop: Header=BB0_6 Depth=2
	tbz	w6, #7, LBB0_1274
LBB0_1273:                              ; %cond.load8315
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x6, v2[1]
	ld1.s	{ v3 }[3], [x6]
LBB0_1274:                              ; %else8319
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q4, [sp, #1440]                 ; 16-byte Reload
	fadd.4s	v0, v4, v0
	ldr	q5, [sp, #1424]                 ; 16-byte Reload
	fadd.4s	v1, v5, v3
	movi.8b	v2, #1
	and.8b	v2, v15, v2
	ushll.8h	v2, v2, #0
	ushll.4s	v3, v2, #0
	ushll2.4s	v2, v2, #0
	uaddw2.2d	v12, v12, v2
	ldr	q6, [sp, #1920]                 ; 16-byte Reload
	uaddw.2d	v6, v6, v2
	str	q6, [sp, #1920]                 ; 16-byte Spill
	uaddw2.2d	v23, v23, v3
	ldr	q2, [sp, #1904]                 ; 16-byte Reload
	uaddw.2d	v2, v2, v3
	str	q2, [sp, #1904]                 ; 16-byte Spill
	zip2.8b	v2, v15, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	bit.16b	v5, v1, v2
	str	q5, [sp, #1424]                 ; 16-byte Spill
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	bit.16b	v4, v0, v1
	str	q4, [sp, #1440]                 ; 16-byte Spill
	tbz	w5, #0, LBB0_1255
	b	LBB0_4
LBB0_1275:                              ; %cond.load8273
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d5
	ldr	s0, [x7]
	tbz	w6, #1, LBB0_1267
LBB0_1276:                              ; %cond.load8279
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v5[1]
	ld1.s	{ v0 }[1], [x7]
	tbz	w6, #2, LBB0_1268
LBB0_1277:                              ; %cond.load8285
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d1
	ld1.s	{ v0 }[2], [x7]
	tbz	w6, #3, LBB0_1269
LBB0_1278:                              ; %cond.load8291
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v1[1]
	ld1.s	{ v0 }[3], [x7]
	tbz	w6, #4, LBB0_1270
LBB0_1279:                              ; %cond.load8297
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d4
	ld1.s	{ v3 }[0], [x7]
	tbz	w6, #5, LBB0_1271
LBB0_1280:                              ; %cond.load8303
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov.d	x7, v4[1]
	ld1.s	{ v3 }[1], [x7]
	tbz	w6, #6, LBB0_1272
LBB0_1281:                              ; %cond.load8309
                                        ;   in Loop: Header=BB0_6 Depth=2
	fmov	x7, d2
	ld1.s	{ v3 }[2], [x7]
	tbnz	w6, #7, LBB0_1273
	b	LBB0_1274
LBB0_1282:                              ; %varying.coherent.false802
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w6, #0xff
	b.eq	LBB0_4
LBB0_1283:                              ; %schedule.40
                                        ;   in Loop: Header=BB0_6 Depth=2
	str	q12, [sp, #1520]                ; 16-byte Spill
	str	q25, [sp, #1728]                ; 16-byte Spill
	str	q23, [sp, #1744]                ; 16-byte Spill
	str	q10, [sp, #1504]                ; 16-byte Spill
	str	q11, [sp, #1536]                ; 16-byte Spill
	str	q26, [sp, #1696]                ; 16-byte Spill
	str	q22, [sp, #1712]                ; 16-byte Spill
	str	q8, [sp, #1488]                 ; 16-byte Spill
	str	q29, [sp, #1648]                ; 16-byte Spill
	str	q9, [sp, #1456]                 ; 16-byte Spill
	str	q27, [sp, #1680]                ; 16-byte Spill
	str	q24, [sp, #1664]                ; 16-byte Spill
	str	q31, [sp, #1472]                ; 16-byte Spill
	cbz	w4, LBB0_1288
; %bb.1284:                             ; %convergence.cascade810.preheader
                                        ;   in Loop: Header=BB0_6 Depth=2
	mov	w5, #0                          ; =0x0
LBB0_1285:                              ; %convergence.cascade810
                                        ;   Parent Loop BB0_5 Depth=1
                                        ;     Parent Loop BB0_6 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d6, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v0, v6
	addv.8b	b1, v1
	fmov	w6, s1
	umaxv.8b	b0, v0
	fmov	w20, s0
	sub	w7, w4, #1
	tst	w6, #0xff
	csel	w7, w7, wzr, ne
	mov	w6, #1                          ; =0x1
	lsl	w19, w6, w7
	and	w6, w19, w0
	tst	w6, #0xff
	cset	w22, ne
	str	q24, [sp, #4912]
	str	q27, [sp, #4928]
	ubfiz	x6, x7, #2, #3
	add	x21, sp, #1, lsl #12            ; =4096
	add	x21, x21, #816
	ldr	w21, [x21, x6]
	cmp	w21, #17
	cset	w21, eq
	and	w22, w22, w20
	add	x20, sp, #2, lsl #12            ; =8192
	add	x20, x20, #3560
	ldrb	w24, [x20, w7, sxtw]
	and	w23, w24, #0x1
	fmov	s0, w23
	ubfx	w23, w24, #1, #1
	mov.b	v0[1], w23
	ubfx	w23, w24, #2, #1
	mov.b	v0[2], w23
	ubfx	w23, w24, #3, #1
	mov.b	v0[3], w23
	ubfx	w23, w24, #4, #1
	mov.b	v0[4], w23
	ubfx	w23, w24, #5, #1
	mov.b	v0[5], w23
	ubfx	w23, w24, #6, #1
	mov.b	v0[6], w23
	add	x23, sp, #2, lsl #12            ; =8192
	add	x23, x23, #3552
	lsr	w24, w24, #7
	mov.b	v0[7], w24
	ldrb	w24, [x23, w7, sxtw]
	and	w25, w24, #0x1
	fmov	s1, w25
	ubfx	w25, w24, #1, #1
	mov.b	v1[1], w25
	ubfx	w25, w24, #2, #1
	mov.b	v1[2], w25
	ubfx	w25, w24, #3, #1
	mov.b	v1[3], w25
	ubfx	w25, w24, #4, #1
	mov.b	v1[4], w25
	ubfx	w25, w24, #5, #1
	mov.b	v1[5], w25
	ubfx	w25, w24, #6, #1
	mov.b	v1[6], w25
	lsr	w24, w24, #7
	mov.b	v1[7], w24
	orr.8b	v2, v15, v1
	ldr	d3, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v3, v0
	eor.8b	v3, v3, v2
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w24, s3
	ands	w21, w22, w21
	csetm	w22, ne
	bics	w24, w21, w24
	csetm	w25, ne
	dup.8b	v3, w25
	bic.8b	v4, v2, v3
	dup.8b	v5, w22
	bit.8b	v1, v4, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v6
	addv.8b	b1, v1
	str	b1, [x23, w7, sxtw]
	bic.8b	v0, v0, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	str	b0, [x20, w7, sxtw]
	mov	w7, #-1                         ; =0xffffffff
	csinv	w7, w7, w19, eq
	and	w0, w7, w0
	dup.8b	v0, w21
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	dup.8b	v1, w24
	and.8b	v1, v1, v2
	str	q9, [sp, #4880]
	ldr	q2, [sp, #1968]                 ; 16-byte Reload
	str	q2, [sp, #4896]
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #784
	ldr	w6, [x7, x6]
	csel	w4, w6, w4, ne
	bit.8b	v15, v1, v0
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	fmov	w6, s0
	cmp	w21, #1
	b.ne	LBB0_1289
; %bb.1286:                             ; %convergence.cascade810
                                        ;   in Loop: Header=BB0_1285 Depth=3
	cmp	w4, #0
	ccmp	w5, #6, #2, ne
	b.hi	LBB0_1289
; %bb.1287:                             ; %convergence.cascade810
                                        ;   in Loop: Header=BB0_1285 Depth=3
	add	w5, w5, #1
	tst	w6, #0xff
	b.ne	LBB0_1285
	b	LBB0_1289
LBB0_1288:                              ; %schedule.40.convergence.cascade.exit811_crit_edge
                                        ;   in Loop: Header=BB0_6 Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w6, s0
LBB0_1289:                              ; %convergence.cascade.exit811
                                        ;   in Loop: Header=BB0_6 Depth=2
	tst	w6, #0xff
	b.eq	LBB0_4
; %bb.1290:                             ; %convergence.target.40.ready
                                        ;   in Loop: Header=BB0_6 Depth=2
	ldr	q1, [sp, #7920]
	ldr	q2, [sp, #7904]
	ldr	q0, [sp, #7888]
	stp	q0, q1, [sp, #480]              ; 32-byte Folded Spill
	ldr	q0, [sp, #7872]
	stp	q0, q2, [sp, #560]              ; 32-byte Folded Spill
	ldr	q30, [sp, #8288]
	ldr	q0, [sp, #8304]
	ldr	q29, [sp, #1040]                ; 16-byte Reload
	fmul.4s	v1, v29, v0
	ldr	q2, [sp, #8288]
	ldr	q0, [sp, #8304]
	ldr	q28, [sp, #1072]                ; 16-byte Reload
	fmul.4s	v4, v28, v0
	ldr	q13, [sp, #8288]
	ldr	q0, [sp, #8304]
	ldr	q17, [sp, #1104]                ; 16-byte Reload
	fmul.4s	v3, v17, v0
	ldr	q0, [sp, #8256]
	stp	q2, q0, [sp, #512]              ; 32-byte Folded Spill
	ldr	q0, [sp, #8272]
	ldr	q14, [sp, #8256]
	ldr	q2, [sp, #8272]
	ldr	q5, [sp, #8256]
	str	q5, [sp, #544]                  ; 16-byte Spill
	ldr	q27, [sp, #8272]
	ldr	q7, [sp, #8224]
	ldr	q5, [sp, #8240]
	ldr	q6, [sp, #9184]
	stp	q6, q7, [sp, #448]              ; 32-byte Folded Spill
	ldr	q6, [sp, #9200]
	fmul.4s	v5, v5, v6
	fadd.4s	v1, v1, v5
	ldr	q5, [sp, #8208]
	ldr	q7, [sp, #8192]
	ldr	q6, [sp, #9104]
	fmul.4s	v5, v5, v6
	fadd.4s	v1, v1, v5
	ldr	q5, [sp, #9088]
	stp	q5, q7, [sp, #416]              ; 32-byte Folded Spill
	ldr	q7, [sp, #8160]
	ldr	q5, [sp, #8176]
	ldr	q6, [sp, #912]                  ; 16-byte Reload
	fmul.4s	v5, v6, v5
	fadd.4s	v1, v1, v5
	str	q1, [sp, #288]                  ; 16-byte Spill
	ldr	q1, [sp, #8224]
	stp	q1, q7, [sp, #384]              ; 32-byte Folded Spill
	ldr	q1, [sp, #8240]
	ldr	q7, [sp, #9152]
	ldr	q5, [sp, #9168]
	fmul.4s	v1, v1, v5
	fadd.4s	v1, v4, v1
	ldr	q4, [sp, #8208]
	ldr	q5, [sp, #8192]
	stp	q5, q7, [sp, #352]              ; 32-byte Folded Spill
	ldr	q5, [sp, #9072]
	fmul.4s	v4, v4, v5
	fadd.4s	v1, v1, v4
	ldr	q5, [sp, #9056]
	ldr	q4, [sp, #8160]
	stp	q4, q5, [sp, #320]              ; 32-byte Folded Spill
	ldr	q4, [sp, #8176]
	ldr	q7, [sp, #944]                  ; 16-byte Reload
	fmul.4s	v4, v7, v4
	fadd.4s	v26, v1, v4
	ldr	q1, [sp, #8224]
	str	q1, [sp, #304]                  ; 16-byte Spill
	ldr	q4, [sp, #8240]
	ldr	q1, [sp, #9120]
	str	q1, [sp, #272]                  ; 16-byte Spill
	ldr	q5, [sp, #9136]
	fmul.4s	v4, v4, v5
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #8208]
	ldr	q1, [sp, #8192]
	str	q1, [sp, #256]                  ; 16-byte Spill
	ldr	q5, [sp, #9040]
	fmul.4s	v4, v4, v5
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #9024]
	ldr	q1, [sp, #8160]
	stp	q1, q4, [sp, #224]              ; 32-byte Folded Spill
	ldr	q4, [sp, #8176]
	ldr	q1, [sp, #976]                  ; 16-byte Reload
	fmul.4s	v4, v1, v4
	fadd.4s	v20, v3, v4
	ldr	q10, [sp, #8128]
	ldr	q3, [sp, #8144]
	ldr	q4, [sp, #9184]
	str	q4, [sp, #208]                  ; 16-byte Spill
	ldr	q4, [sp, #9200]
	fmul.4s	v3, v3, v4
	ldr	q9, [sp, #1136]                 ; 16-byte Reload
	fmul.4s	v0, v9, v0
	fadd.4s	v0, v0, v3
	ldr	q3, [sp, #8112]
	ldr	q11, [sp, #8096]
	ldr	q4, [sp, #9104]
	fmul.4s	v3, v3, v4
	fadd.4s	v0, v0, v3
	ldr	q25, [sp, #9088]
	ldr	q24, [sp, #8064]
	ldr	q3, [sp, #8080]
	fmul.4s	v3, v6, v3
	fadd.4s	v16, v0, v3
	ldr	q23, [sp, #8128]
	ldr	q0, [sp, #8144]
	ldr	q22, [sp, #9152]
	ldr	q3, [sp, #9168]
	fmul.4s	v0, v0, v3
	ldr	q4, [sp, #1168]                 ; 16-byte Reload
	fmul.4s	v2, v4, v2
	fadd.4s	v0, v2, v0
	ldr	q2, [sp, #8112]
	ldr	q5, [sp, #8096]
	ldr	q3, [sp, #9072]
	fmul.4s	v2, v2, v3
	fadd.4s	v0, v0, v2
	ldr	q18, [sp, #9056]
	ldr	q19, [sp, #8064]
	ldr	q2, [sp, #8080]
	fmul.4s	v2, v7, v2
	fadd.4s	v6, v0, v2
	ldr	q0, [sp, #8128]
	stp	q0, q5, [sp, #176]              ; 32-byte Folded Spill
	ldr	q2, [sp, #8144]
	ldr	q7, [sp, #9120]
	ldr	q3, [sp, #9136]
	fmul.4s	v2, v2, v3
	ldr	q21, [sp, #1200]                ; 16-byte Reload
	fmul.4s	v3, v21, v27
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #8112]
	ldr	q0, [sp, #8096]
	str	q0, [sp, #160]                  ; 16-byte Spill
	ldr	q5, [sp, #9040]
	fmul.4s	v3, v3, v5
	fadd.4s	v2, v2, v3
	ldr	q5, [sp, #9024]
	ldr	q0, [sp, #8064]
	str	q0, [sp, #144]                  ; 16-byte Spill
	ldr	q3, [sp, #8080]
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v2, v3
	zip2.8b	v2, v15, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v0, v2, #0
	ldr	q1, [sp, #8352]
	str	q1, [sp, #128]                  ; 16-byte Spill
	ldr	q2, [sp, #8368]
	ldr	q1, [sp, #1232]                 ; 16-byte Reload
	bit.16b	v1, v2, v0
	str	q1, [sp, #1232]                 ; 16-byte Spill
	ldr	q8, [sp, #8320]
	ldr	q27, [sp, #8336]
	ldr	q12, [sp, #1264]                ; 16-byte Reload
	bit.16b	v12, v27, v0
	str	q12, [sp, #1264]                ; 16-byte Spill
	ldr	q27, [sp, #1392]                ; 16-byte Reload
	ldp	q1, q2, [sp, #480]              ; 32-byte Folded Reload
	fadd.4s	v27, v27, v2
	ldr	q12, [sp, #1552]                ; 16-byte Reload
	bit.16b	v12, v27, v0
	str	q12, [sp, #1552]                ; 16-byte Spill
	ldr	q27, [sp, #1424]                ; 16-byte Reload
	fadd.4s	v27, v27, v1
	ldr	q12, [sp, #1296]                ; 16-byte Reload
	bit.16b	v12, v27, v0
	str	q12, [sp, #1296]                ; 16-byte Spill
	ldr	q1, [sp, #288]                  ; 16-byte Reload
	bit.16b	v29, v1, v0
	str	q29, [sp, #1040]                ; 16-byte Spill
	bit.16b	v28, v26, v0
	str	q28, [sp, #1072]                ; 16-byte Spill
	bit.16b	v17, v20, v0
	str	q17, [sp, #1104]                ; 16-byte Spill
	bit.16b	v9, v16, v0
	str	q9, [sp, #1136]                 ; 16-byte Spill
	bit.16b	v4, v6, v0
	str	q4, [sp, #1168]                 ; 16-byte Spill
	bit.16b	v21, v3, v0
	str	q21, [sp, #1200]                ; 16-byte Spill
	ldp	q1, q0, [sp, #448]              ; 32-byte Folded Reload
	fmul.4s	v0, v0, v1
	ldr	q17, [sp, #1056]                ; 16-byte Reload
	fmul.4s	v1, v17, v30
	fadd.4s	v0, v1, v0
	ldp	q2, q1, [sp, #416]              ; 32-byte Folded Reload
	fmul.4s	v1, v1, v2
	fadd.4s	v0, v0, v1
	ldr	q9, [sp, #928]                  ; 16-byte Reload
	ldr	q1, [sp, #400]                  ; 16-byte Reload
	fmul.4s	v1, v9, v1
	fadd.4s	v30, v0, v1
	ldp	q1, q0, [sp, #368]              ; 32-byte Folded Reload
	fmul.4s	v1, v0, v1
	ldr	q3, [sp, #1088]                 ; 16-byte Reload
	ldr	q0, [sp, #512]                  ; 16-byte Reload
	fmul.4s	v4, v3, v0
	fadd.4s	v1, v4, v1
	ldp	q2, q0, [sp, #336]              ; 32-byte Folded Reload
	fmul.4s	v4, v0, v2
	fadd.4s	v1, v1, v4
	ldr	q27, [sp, #960]                 ; 16-byte Reload
	ldp	q0, q2, [sp, #304]              ; 32-byte Folded Reload
	fmul.4s	v4, v27, v2
	fadd.4s	v28, v1, v4
	ldr	q1, [sp, #272]                  ; 16-byte Reload
	fmul.4s	v4, v0, v1
	ldr	q1, [sp, #1120]                 ; 16-byte Reload
	fmul.4s	v20, v1, v13
	fadd.4s	v4, v20, v4
	ldp	q2, q0, [sp, #240]              ; 32-byte Folded Reload
	fmul.4s	v20, v0, v2
	fadd.4s	v4, v4, v20
	ldr	q6, [sp, #992]                  ; 16-byte Reload
	ldp	q0, q2, [sp, #208]              ; 32-byte Folded Reload
	fmul.4s	v20, v6, v2
	ldr	q13, [sp, #1728]                ; 16-byte Reload
	ldr	q31, [sp, #1520]                ; 16-byte Reload
	fadd.4s	v4, v4, v20
	fmul.4s	v20, v10, v0
	ldr	q12, [sp, #1504]                ; 16-byte Reload
	ldr	q2, [sp, #1744]                 ; 16-byte Reload
	ldr	q0, [sp, #1152]                 ; 16-byte Reload
	ldr	q16, [sp, #528]                 ; 16-byte Reload
	fmul.4s	v26, v0, v16
	fadd.4s	v20, v26, v20
	fmul.4s	v25, v11, v25
	ldr	q11, [sp, #1536]                ; 16-byte Reload
	ldr	q26, [sp, #1776]                ; 16-byte Reload
	fadd.4s	v20, v20, v25
	ldr	q25, [sp, #1696]                ; 16-byte Reload
	fmul.4s	v24, v9, v24
	ldr	q9, [sp, #1456]                 ; 16-byte Reload
	fadd.4s	v20, v20, v24
	fmul.4s	v22, v23, v22
	ldr	q21, [sp, #1184]                ; 16-byte Reload
	fmul.4s	v23, v21, v14
	fadd.4s	v22, v23, v22
	ldr	q29, [sp, #1648]                ; 16-byte Reload
	ldr	q10, [sp, #1488]                ; 16-byte Reload
	ldp	q16, q23, [sp, #176]            ; 32-byte Folded Reload
	fmul.4s	v18, v23, v18
	fadd.4s	v18, v22, v18
	ldr	q14, [sp, #1712]                ; 16-byte Reload
	fmul.4s	v19, v27, v19
	fadd.4s	v18, v18, v19
	fmul.4s	v7, v16, v7
	ldr	q27, [sp, #1680]                ; 16-byte Reload
	ldr	q24, [sp, #1664]                ; 16-byte Reload
	ldr	q22, [sp, #1792]                ; 16-byte Reload
	ldr	q23, [sp, #1472]                ; 16-byte Reload
	ldr	q19, [sp, #1216]                ; 16-byte Reload
	ldr	q16, [sp, #544]                 ; 16-byte Reload
	fmul.4s	v16, v19, v16
	fadd.4s	v7, v16, v7
	ldr	q16, [sp, #160]                 ; 16-byte Reload
	fmul.4s	v5, v16, v5
	mov.16b	v16, v10
	mov.16b	v10, v12
	fadd.4s	v5, v7, v5
	ldr	q7, [sp, #144]                  ; 16-byte Reload
	fmul.4s	v6, v6, v7
	mov.16b	v12, v31
	fadd.4s	v5, v5, v6
	zip1.8b	v6, v15, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	ldr	q7, [sp, #1248]                 ; 16-byte Reload
	ldr	q31, [sp, #128]                 ; 16-byte Reload
	bit.16b	v7, v31, v6
	mov.16b	v31, v23
	mov.16b	v23, v2
	str	q7, [sp, #1248]                 ; 16-byte Spill
	ldr	q7, [sp, #1280]                 ; 16-byte Reload
	bit.16b	v7, v8, v6
	str	q7, [sp, #1280]                 ; 16-byte Spill
	ldr	q2, [sp, #1408]                 ; 16-byte Reload
	ldr	q7, [sp, #576]                  ; 16-byte Reload
	fadd.4s	v2, v2, v7
	ldr	q7, [sp, #1568]                 ; 16-byte Reload
	bit.16b	v7, v2, v6
	str	q7, [sp, #1568]                 ; 16-byte Spill
	ldr	q2, [sp, #1440]                 ; 16-byte Reload
	ldr	q7, [sp, #560]                  ; 16-byte Reload
	fadd.4s	v2, v2, v7
	ldr	q7, [sp, #1312]                 ; 16-byte Reload
	bit.16b	v7, v2, v6
	str	q7, [sp, #1312]                 ; 16-byte Spill
	bit.16b	v17, v30, v6
	str	q17, [sp, #1056]                ; 16-byte Spill
	bit.16b	v3, v28, v6
	str	q3, [sp, #1088]                 ; 16-byte Spill
	bit.16b	v1, v4, v6
	str	q1, [sp, #1120]                 ; 16-byte Spill
	bit.16b	v0, v20, v6
	str	q0, [sp, #1152]                 ; 16-byte Spill
	bit.16b	v21, v18, v6
	str	q21, [sp, #1184]                ; 16-byte Spill
	bit.16b	v19, v5, v6
	str	q19, [sp, #1216]                ; 16-byte Spill
	movi.8b	v0, #1
	and.8b	v0, v15, v0
	ushll.8h	v0, v0, #0
	ushll2.4s	v1, v0, #0
	ldr	q2, [sp, #1760]                 ; 16-byte Reload
	uaddw2.2d	v2, v2, v1
	str	q2, [sp, #1760]                 ; 16-byte Spill
	uaddw.2d	v8, v16, v1
	ushll.4s	v0, v0, #0
	uaddw2.2d	v22, v22, v0
	str	q22, [sp, #1792]                ; 16-byte Spill
	mov.16b	v22, v14
	uaddw.2d	v26, v26, v0
	str	q26, [sp, #1776]                ; 16-byte Spill
	mov.16b	v26, v25
	mov.16b	v25, v13
	b	LBB0_514
LBB0_1291:                              ; %varying.coherent991
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w5, s0
	tst	w5, #0xff
	b.eq	LBB0_1326
; %bb.1292:                             ; %schedule.46.thread
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	q1, [sp, #7536]
	ldr	q3, [sp, #7520]
	ldr	q5, [sp, #7504]
	ldr	q2, [sp, #7488]
	ldr	q0, [sp, #7792]
	ldr	q4, [sp, #7776]
	shl.2d	v6, v2, #2
	dup.2d	v2, x13
	add.2d	v6, v2, v6
	shl.8b	v7, v15, #7
	cmlt.8b	v7, v7, #0
	ldr	d16, [sp, #1992]                ; 8-byte Reload
	and.8b	v7, v7, v16
	addv.8b	b7, v7
	fmov	w5, s7
	tbnz	w5, #0, LBB0_1310
; %bb.1293:                             ; %else9511
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w5, #1, LBB0_1311
LBB0_1294:                              ; %else9515
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.2d	v5, v5, #2
	add.2d	v5, v2, v5
	tbnz	w5, #2, LBB0_1312
LBB0_1295:                              ; %else9519
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w5, #3, LBB0_1313
LBB0_1296:                              ; %else9523
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.2d	v3, v3, #2
	add.2d	v3, v2, v3
	tbnz	w5, #4, LBB0_1314
LBB0_1297:                              ; %else9527
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w5, #5, LBB0_1315
LBB0_1298:                              ; %else9531
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.2d	v1, v1, #2
	add.2d	v1, v2, v1
	tbnz	w5, #6, LBB0_1316
LBB0_1299:                              ; %else9535
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w5, #7, LBB0_1317
	b	LBB0_1326
LBB0_1300:                              ;   in Loop: Header=BB0_5 Depth=1
	ldr	q12, [sp, #1520]                ; 16-byte Reload
	ldr	q22, [sp, #1712]                ; 16-byte Reload
	ldr	q9, [sp, #1456]                 ; 16-byte Reload
	cbnz	x1, LBB0_5
	b	LBB0_1346
LBB0_1301:                              ; %schedule.46
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #1992]                 ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w5, s0
	ldr	q1, [sp, #7536]
	ldr	q3, [sp, #7520]
	ldr	q5, [sp, #7504]
	ldr	q2, [sp, #7488]
	ldr	q0, [sp, #7792]
	ldr	q4, [sp, #7776]
	shl.2d	v6, v2, #2
	dup.2d	v2, x13
	add.2d	v6, v2, v6
	tbnz	w5, #0, LBB0_1318
; %bb.1302:                             ; %else8382
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w5, #1, LBB0_1319
LBB0_1303:                              ; %else8386
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.2d	v5, v5, #2
	add.2d	v5, v2, v5
	tbnz	w5, #2, LBB0_1320
LBB0_1304:                              ; %else8390
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w5, #3, LBB0_1321
LBB0_1305:                              ; %else8394
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.2d	v3, v3, #2
	add.2d	v3, v2, v3
	tbnz	w5, #4, LBB0_1322
LBB0_1306:                              ; %else8398
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w5, #5, LBB0_1323
LBB0_1307:                              ; %else8402
                                        ;   in Loop: Header=BB0_5 Depth=1
	shl.2d	v1, v1, #2
	add.2d	v1, v2, v1
	tbnz	w5, #6, LBB0_1324
LBB0_1308:                              ; %else8406
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbnz	w5, #7, LBB0_1325
LBB0_1309:                              ; %else8410
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w5, #0xff
	b.ne	LBB0_1326
	b	LBB0_4
LBB0_1310:                              ; %cond.store9508
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x6, d6
	str	s4, [x6]
	tbz	w5, #1, LBB0_1294
LBB0_1311:                              ; %cond.store9512
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x6, v6[1]
	st1.s	{ v4 }[1], [x6]
	shl.2d	v5, v5, #2
	add.2d	v5, v2, v5
	tbz	w5, #2, LBB0_1295
LBB0_1312:                              ; %cond.store9516
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x6, d5
	st1.s	{ v4 }[2], [x6]
	tbz	w5, #3, LBB0_1296
LBB0_1313:                              ; %cond.store9520
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x6, v5[1]
	st1.s	{ v4 }[3], [x6]
	shl.2d	v3, v3, #2
	add.2d	v3, v2, v3
	tbz	w5, #4, LBB0_1297
LBB0_1314:                              ; %cond.store9524
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x6, d3
	str	s0, [x6]
	tbz	w5, #5, LBB0_1298
LBB0_1315:                              ; %cond.store9528
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x6, v3[1]
	st1.s	{ v0 }[1], [x6]
	shl.2d	v1, v1, #2
	add.2d	v1, v2, v1
	tbz	w5, #6, LBB0_1299
LBB0_1316:                              ; %cond.store9532
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x6, d1
	st1.s	{ v0 }[2], [x6]
	tbz	w5, #7, LBB0_1326
LBB0_1317:                              ; %cond.store9536
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x5, v1[1]
	st1.s	{ v0 }[3], [x5]
	b	LBB0_1326
LBB0_1318:                              ; %cond.store8379
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x6, d6
	str	s4, [x6]
	tbz	w5, #1, LBB0_1303
LBB0_1319:                              ; %cond.store8383
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x6, v6[1]
	st1.s	{ v4 }[1], [x6]
	shl.2d	v5, v5, #2
	add.2d	v5, v2, v5
	tbz	w5, #2, LBB0_1304
LBB0_1320:                              ; %cond.store8387
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x6, d5
	st1.s	{ v4 }[2], [x6]
	tbz	w5, #3, LBB0_1305
LBB0_1321:                              ; %cond.store8391
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x6, v5[1]
	st1.s	{ v4 }[3], [x6]
	shl.2d	v3, v3, #2
	add.2d	v3, v2, v3
	tbz	w5, #4, LBB0_1306
LBB0_1322:                              ; %cond.store8395
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x6, d3
	str	s0, [x6]
	tbz	w5, #5, LBB0_1307
LBB0_1323:                              ; %cond.store8399
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x6, v3[1]
	st1.s	{ v0 }[1], [x6]
	shl.2d	v1, v1, #2
	add.2d	v1, v2, v1
	tbz	w5, #6, LBB0_1308
LBB0_1324:                              ; %cond.store8403
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	x6, d1
	st1.s	{ v0 }[2], [x6]
	tbz	w5, #7, LBB0_1309
LBB0_1325:                              ; %cond.store8407
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov.d	x6, v1[1]
	st1.s	{ v0 }[3], [x6]
	tst	w5, #0xff
	b.eq	LBB0_4
LBB0_1326:                              ; %schedule.47
                                        ;   in Loop: Header=BB0_5 Depth=1
	cbz	w4, LBB0_2
; %bb.1327:                             ; %convergence.cascade1000.preheader
                                        ;   in Loop: Header=BB0_5 Depth=1
	mov	w5, #0                          ; =0x0
LBB0_1328:                              ; %convergence.cascade1000
                                        ;   Parent Loop BB0_5 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	ldr	d6, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v0, v6
	addv.8b	b1, v1
	fmov	w6, s1
	umaxv.8b	b0, v0
	fmov	w20, s0
	sub	w7, w4, #1
	tst	w6, #0xff
	csel	w7, w7, wzr, ne
	mov	w6, #1                          ; =0x1
	lsl	w19, w6, w7
	and	w6, w19, w0
	tst	w6, #0xff
	cset	w22, ne
	str	q24, [sp, #6928]
	str	q27, [sp, #6944]
	ubfiz	x6, x7, #2, #3
	add	x21, sp, #1, lsl #12            ; =4096
	add	x21, x21, #2832
	ldr	w21, [x21, x6]
	cmp	w21, #20
	cset	w21, eq
	and	w22, w22, w20
	add	x20, sp, #2, lsl #12            ; =8192
	add	x20, x20, #3560
	ldrb	w24, [x20, w7, sxtw]
	and	w23, w24, #0x1
	fmov	s0, w23
	ubfx	w23, w24, #1, #1
	mov.b	v0[1], w23
	ubfx	w23, w24, #2, #1
	mov.b	v0[2], w23
	ubfx	w23, w24, #3, #1
	mov.b	v0[3], w23
	ubfx	w23, w24, #4, #1
	mov.b	v0[4], w23
	ubfx	w23, w24, #5, #1
	mov.b	v0[5], w23
	ubfx	w23, w24, #6, #1
	mov.b	v0[6], w23
	add	x23, sp, #2, lsl #12            ; =8192
	add	x23, x23, #3552
	lsr	w24, w24, #7
	mov.b	v0[7], w24
	ldrb	w24, [x23, w7, sxtw]
	and	w25, w24, #0x1
	fmov	s1, w25
	ubfx	w25, w24, #1, #1
	mov.b	v1[1], w25
	ubfx	w25, w24, #2, #1
	mov.b	v1[2], w25
	ubfx	w25, w24, #3, #1
	mov.b	v1[3], w25
	ubfx	w25, w24, #4, #1
	mov.b	v1[4], w25
	ubfx	w25, w24, #5, #1
	mov.b	v1[5], w25
	ubfx	w25, w24, #6, #1
	mov.b	v1[6], w25
	lsr	w24, w24, #7
	mov.b	v1[7], w24
	orr.8b	v2, v15, v1
	ldr	d3, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v3, v0
	eor.8b	v3, v3, v2
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	umaxv.8b	b3, v3
	fmov	w24, s3
	ands	w21, w22, w21
	csetm	w22, ne
	bics	w24, w21, w24
	csetm	w25, ne
	dup.8b	v3, w25
	bic.8b	v4, v2, v3
	dup.8b	v5, w22
	bit.8b	v1, v4, v5
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v6
	addv.8b	b1, v1
	str	b1, [x23, w7, sxtw]
	bic.8b	v0, v0, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	str	b0, [x20, w7, sxtw]
	mov	w7, #-1                         ; =0xffffffff
	csinv	w7, w7, w19, eq
	and	w0, w7, w0
	dup.8b	v0, w21
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	dup.8b	v1, w24
	and.8b	v1, v1, v2
	str	q9, [sp, #6896]
	ldr	q2, [sp, #1968]                 ; 16-byte Reload
	str	q2, [sp, #6912]
	add	x7, sp, #1, lsl #12             ; =4096
	add	x7, x7, #2800
	ldr	w6, [x7, x6]
	csel	w4, w6, w4, ne
	bit.8b	v15, v1, v0
	shl.8b	v0, v15, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	fmov	w6, s0
	cmp	w21, #1
	b.ne	LBB0_3
; %bb.1329:                             ; %convergence.cascade1000
                                        ;   in Loop: Header=BB0_1328 Depth=2
	cmp	w4, #0
	ccmp	w5, #6, #2, ne
	b.hi	LBB0_3
; %bb.1330:                             ; %convergence.cascade1000
                                        ;   in Loop: Header=BB0_1328 Depth=2
	add	w5, w5, #1
	tst	w6, #0xff
	b.ne	LBB0_1328
	b	LBB0_3
LBB0_1331:                              ;   in Loop: Header=BB0_5 Depth=1
	mov	w2, #2                          ; =0x2
	mov	w3, #1                          ; =0x1
	cbnz	x1, LBB0_5
	b	LBB0_1346
LBB0_1332:                              ; %convergence.target.47.ready
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	d0, [sp, #1960]                 ; 8-byte Reload
	bic.8b	v0, v0, v15
	str	d0, [sp, #1960]                 ; 8-byte Spill
	tst	w0, #0xff
	b.eq	LBB0_1345
; %bb.1333:                             ; %return.frame.cleanup
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldrb	w4, [x8, #8]
	and	w5, w4, #0x1
	fmov	s0, w5
	ubfx	w5, w4, #1, #1
	mov.b	v0[1], w5
	ubfx	w5, w4, #2, #1
	mov.b	v0[2], w5
	ubfx	w5, w4, #3, #1
	mov.b	v0[3], w5
	ubfx	w5, w4, #4, #1
	mov.b	v0[4], w5
	ubfx	w5, w4, #5, #1
	mov.b	v0[5], w5
	ubfx	w5, w4, #6, #1
	mov.b	v0[6], w5
	lsr	w4, w4, #7
	mov.b	v0[7], w4
	ldrb	w4, [x9, #2982]
	and	w5, w4, #0x1
	fmov	s2, w5
	ubfx	w5, w4, #1, #1
	mov.b	v2[1], w5
	ubfx	w5, w4, #2, #1
	mov.b	v2[2], w5
	ubfx	w5, w4, #3, #1
	mov.b	v2[3], w5
	ubfx	w5, w4, #4, #1
	mov.b	v2[4], w5
	ubfx	w5, w4, #5, #1
	mov.b	v2[5], w5
	ubfx	w5, w4, #6, #1
	mov.b	v2[6], w5
	lsr	w4, w4, #7
	mov.b	v2[7], w4
	ldr	d1, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v1, v0
	eor.8b	v0, v2, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v1, v0, #0
	umaxv.8b	b0, v1
	fmov	w4, s0
	eor	w4, w4, #0x1
	and	w5, w0, w4
	dup.8b	v0, w5
	and.8b	v0, v0, v2
	shl.8b	v4, v0, #7
	cmlt.8b	v4, v4, #0
	ldr	d5, [sp, #1992]                 ; 8-byte Reload
	and.8b	v4, v4, v5
	addv.8b	b4, v4
	fmov	w4, s4
	tst	w5, #0x1
	csetm	w5, ne
	dup.8b	v4, w5
	bic.8b	v3, v3, v4
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v5
	addv.8b	b3, v3
	str	b3, [x8, #8]
	bic.8b	v2, v2, v4
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v5
	addv.8b	b2, v2
	str	b2, [x9, #2982]
	cmp	x1, #8
	b.lo	LBB0_1335
; %bb.1334:                             ; %return.frame.cleanup
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w4, #0xff
	b.ne	LBB0_1348
LBB0_1335:                              ; %ready.overflow.resume1022
                                        ;   in Loop: Header=BB0_5 Depth=1
	movi.2d	v2, #0000000000000000
	ldr	d5, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v1, v5
	addv.8b	b1, v1
	fmov	w5, s1
	and	w6, w0, #0xfffffffe
	tst	w5, #0xff
	csel	w5, w6, w0, eq
	ands	w0, w4, #0xff
	fmov	s1, w0
	cmeq.2s	v1, v1, v2
	mvn.8b	v1, v1
	dup.2s	v1, v1[0]
	sxtw	x0, w1
	csel	x6, x0, xzr, ne
	add	x0, sp, #2, lsl #12             ; =8192
	add	x0, x0, #3640
	ldrb	w4, [x0, x6]
	and	w7, w4, #0x1
	fmov	s2, w7
	ubfx	w7, w4, #1, #1
	mov.b	v2[1], w7
	ubfx	w7, w4, #2, #1
	mov.b	v2[2], w7
	ubfx	w7, w4, #3, #1
	mov.b	v2[3], w7
	ubfx	w7, w4, #4, #1
	mov.b	v2[4], w7
	ubfx	w7, w4, #5, #1
	mov.b	v2[5], w7
	ubfx	w7, w4, #6, #1
	mov.b	v2[6], w7
	lsr	w4, w4, #7
	mov.b	v2[7], w4
	bif.8b	v0, v2, v1
	fmov	w7, s24
Lloh106:
	adrp	x4, l_convergence.targets@PAGE
Lloh107:
	add	x4, x4, l_convergence.targets@PAGEOFF
	add	x19, x4, w7, sxtw #2
	fmov	w20, s9
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v5
	addv.8b	b0, v0
	str	b0, [x0, x6]
	lsl	x21, x6, #2
	add	x7, sp, #2, lsl #12             ; =8192
	add	x7, x7, #3600
	add	x6, x7, x21
	csel	x19, x19, x6, ne
	ldr	w19, [x19]
	str	w19, [x6]
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #3568
	ldr	w19, [x6, x21]
	csel	w19, w20, w19, ne
	str	w19, [x6, x21]
	cinc	w19, w1, ne
	and	w1, w5, #0x2
	ldrb	w20, [x8, #9]
	and	w21, w20, #0x1
	fmov	s0, w21
	ubfx	w21, w20, #1, #1
	mov.b	v0[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v0[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v0[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v0[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v0[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v0[6], w21
	lsr	w20, w20, #7
	mov.b	v0[7], w20
	ldrb	w20, [x9, #2983]
	and	w21, w20, #0x1
	fmov	s2, w21
	ubfx	w21, w20, #1, #1
	mov.b	v2[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v2[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v2[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v2[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v2[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v2[6], w21
	lsr	w20, w20, #7
	mov.b	v2[7], w20
	ldr	d1, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v1, v0
	eor.8b	v0, v2, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v1, v0, #0
	umaxv.8b	b0, v1
	fmov	w20, s0
	eor	w20, w20, #0x1
	ands	w1, w20, w1, lsr #1
	dup.8b	v0, w1
	and.8b	v0, v0, v2
	shl.8b	v4, v0, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v5
	addv.8b	b4, v4
	fmov	w20, s4
	csetm	w1, ne
	dup.8b	v4, w1
	bic.8b	v3, v3, v4
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v5
	addv.8b	b3, v3
	stur	b3, [x8, #9]
	bic.8b	v2, v2, v4
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v5
	addv.8b	b2, v2
	stur	b2, [x8, #1]
	cmp	w19, #8
	and	w1, w20, #0xff
	ccmp	w1, #0, #4, hs
	b.ne	LBB0_1348
; %bb.1336:                             ; %ready.overflow.resume1028
                                        ;   in Loop: Header=BB0_5 Depth=1
	movi.2d	v2, #0000000000000000
	ldr	d5, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v1, v5
	addv.8b	b1, v1
	fmov	w1, s1
	and	w21, w5, #0xfffffffd
	tst	w1, #0xff
	csel	w1, w21, w5, eq
	ands	w5, w20, #0xff
	fmov	s1, w5
	cmeq.2s	v1, v1, v2
	mvn.8b	v1, v1
	dup.2s	v1, v1[0]
	sxtw	x5, w19
	csel	x5, x5, xzr, ne
	ldrb	w20, [x0, x5]
	and	w21, w20, #0x1
	fmov	s2, w21
	ubfx	w21, w20, #1, #1
	mov.b	v2[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v2[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v2[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v2[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v2[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v2[6], w21
	lsr	w20, w20, #7
	mov.b	v2[7], w20
	bif.8b	v0, v2, v1
	mov.s	w20, v24[1]
	add	x20, x4, w20, sxtw #2
	mov.s	w21, v9[1]
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v5
	addv.8b	b0, v0
	str	b0, [x0, x5]
	lsl	x0, x5, #2
	add	x5, x7, x0
	csel	x7, x20, x5, ne
	ldr	w7, [x7]
	str	w7, [x5]
	ldr	w5, [x6, x0]
	csel	w5, w21, w5, ne
	str	w5, [x6, x0]
	cinc	w5, w19, ne
	and	w0, w1, #0x4
	ldrb	w6, [x8, #10]
	and	w7, w6, #0x1
	fmov	s0, w7
	ubfx	w7, w6, #1, #1
	mov.b	v0[1], w7
	ubfx	w7, w6, #2, #1
	mov.b	v0[2], w7
	ubfx	w7, w6, #3, #1
	mov.b	v0[3], w7
	ubfx	w7, w6, #4, #1
	mov.b	v0[4], w7
	ubfx	w7, w6, #5, #1
	mov.b	v0[5], w7
	ubfx	w7, w6, #6, #1
	mov.b	v0[6], w7
	lsr	w6, w6, #7
	mov.b	v0[7], w6
	ldrb	w6, [x8, #2]
	and	w7, w6, #0x1
	fmov	s2, w7
	ubfx	w7, w6, #1, #1
	mov.b	v2[1], w7
	ubfx	w7, w6, #2, #1
	mov.b	v2[2], w7
	ubfx	w7, w6, #3, #1
	mov.b	v2[3], w7
	ubfx	w7, w6, #4, #1
	mov.b	v2[4], w7
	ubfx	w7, w6, #5, #1
	mov.b	v2[5], w7
	ubfx	w7, w6, #6, #1
	mov.b	v2[6], w7
	lsr	w6, w6, #7
	mov.b	v2[7], w6
	ldr	d1, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v1, v0
	eor.8b	v0, v2, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v1, v0, #0
	umaxv.8b	b0, v1
	fmov	w6, s0
	eor	w6, w6, #0x1
	ands	w0, w6, w0, lsr #2
	dup.8b	v0, w0
	and.8b	v0, v0, v2
	shl.8b	v4, v0, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v5
	addv.8b	b4, v4
	fmov	w0, s4
	csetm	w6, ne
	dup.8b	v4, w6
	bic.8b	v3, v3, v4
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v5
	addv.8b	b3, v3
	stur	b3, [x8, #10]
	bic.8b	v2, v2, v4
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v5
	addv.8b	b2, v2
	stur	b2, [x8, #2]
	cmp	w5, #8
	and	w6, w0, #0xff
	ccmp	w6, #0, #4, hs
	b.ne	LBB0_1348
; %bb.1337:                             ; %ready.overflow.resume1034
                                        ;   in Loop: Header=BB0_5 Depth=1
	movi.2d	v2, #0000000000000000
	ldr	d5, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v1, v5
	addv.8b	b1, v1
	fmov	w6, s1
	and	w7, w1, #0xfffffffb
	tst	w6, #0xff
	csel	w1, w7, w1, eq
	ands	w0, w0, #0xff
	fmov	s1, w0
	cmeq.2s	v1, v1, v2
	mvn.8b	v1, v1
	dup.2s	v1, v1[0]
	sxtw	x0, w5
	csel	x6, x0, xzr, ne
	add	x0, sp, #2, lsl #12             ; =8192
	add	x0, x0, #3640
	ldrb	w7, [x0, x6]
	and	w19, w7, #0x1
	fmov	s2, w19
	ubfx	w19, w7, #1, #1
	mov.b	v2[1], w19
	ubfx	w19, w7, #2, #1
	mov.b	v2[2], w19
	ubfx	w19, w7, #3, #1
	mov.b	v2[3], w19
	ubfx	w19, w7, #4, #1
	mov.b	v2[4], w19
	ubfx	w19, w7, #5, #1
	mov.b	v2[5], w19
	ubfx	w19, w7, #6, #1
	mov.b	v2[6], w19
	lsr	w7, w7, #7
	mov.b	v2[7], w7
	bif.8b	v0, v2, v1
	mov.s	w7, v24[2]
	add	x19, x4, w7, sxtw #2
	mov.s	w20, v9[2]
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v5
	addv.8b	b0, v0
	str	b0, [x0, x6]
	lsl	x21, x6, #2
	add	x7, sp, #2, lsl #12             ; =8192
	add	x7, x7, #3600
	add	x6, x7, x21
	csel	x19, x19, x6, ne
	ldr	w19, [x19]
	str	w19, [x6]
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #3568
	ldr	w19, [x6, x21]
	csel	w19, w20, w19, ne
	str	w19, [x6, x21]
	cinc	w5, w5, ne
	and	w19, w1, #0x8
	ldrb	w20, [x8, #11]
	and	w21, w20, #0x1
	fmov	s0, w21
	ubfx	w21, w20, #1, #1
	mov.b	v0[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v0[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v0[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v0[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v0[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v0[6], w21
	lsr	w20, w20, #7
	mov.b	v0[7], w20
	ldrb	w20, [x8, #3]
	and	w21, w20, #0x1
	fmov	s2, w21
	ubfx	w21, w20, #1, #1
	mov.b	v2[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v2[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v2[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v2[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v2[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v2[6], w21
	lsr	w20, w20, #7
	mov.b	v2[7], w20
	ldr	d1, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v1, v0
	eor.8b	v0, v2, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v1, v0, #0
	umaxv.8b	b0, v1
	fmov	w20, s0
	eor	w20, w20, #0x1
	ands	w19, w20, w19, lsr #3
	dup.8b	v0, w19
	and.8b	v0, v0, v2
	shl.8b	v4, v0, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v5
	addv.8b	b4, v4
	fmov	w19, s4
	csetm	w20, ne
	dup.8b	v4, w20
	bic.8b	v3, v3, v4
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v5
	addv.8b	b3, v3
	stur	b3, [x8, #11]
	bic.8b	v2, v2, v4
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v5
	addv.8b	b2, v2
	stur	b2, [x8, #3]
	cmp	w5, #8
	and	w20, w19, #0xff
	ccmp	w20, #0, #4, hs
	b.ne	LBB0_1348
; %bb.1338:                             ; %ready.overflow.resume1040
                                        ;   in Loop: Header=BB0_5 Depth=1
	movi.2d	v2, #0000000000000000
	ldr	d5, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v1, v5
	addv.8b	b1, v1
	fmov	w20, s1
	and	w21, w1, #0xfffffff7
	tst	w20, #0xff
	csel	w1, w21, w1, eq
	ands	w19, w19, #0xff
	fmov	s1, w19
	cmeq.2s	v1, v1, v2
	mvn.8b	v1, v1
	dup.2s	v1, v1[0]
	sxtw	x19, w5
	csel	x19, x19, xzr, ne
	ldrb	w20, [x0, x19]
	and	w21, w20, #0x1
	fmov	s2, w21
	ubfx	w21, w20, #1, #1
	mov.b	v2[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v2[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v2[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v2[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v2[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v2[6], w21
	lsr	w20, w20, #7
	mov.b	v2[7], w20
	bif.8b	v0, v2, v1
	mov.s	w20, v24[3]
	add	x20, x4, w20, sxtw #2
	mov.s	w21, v9[3]
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v5
	addv.8b	b0, v0
	str	b0, [x0, x19]
	lsl	x0, x19, #2
	add	x7, x7, x0
	csel	x19, x20, x7, ne
	ldr	w19, [x19]
	str	w19, [x7]
	ldr	w7, [x6, x0]
	csel	w7, w21, w7, ne
	str	w7, [x6, x0]
	cinc	w6, w5, ne
	and	w0, w1, #0x10
	ldrb	w5, [x8, #12]
	and	w7, w5, #0x1
	fmov	s0, w7
	ubfx	w7, w5, #1, #1
	mov.b	v0[1], w7
	ubfx	w7, w5, #2, #1
	mov.b	v0[2], w7
	ubfx	w7, w5, #3, #1
	mov.b	v0[3], w7
	ubfx	w7, w5, #4, #1
	mov.b	v0[4], w7
	ubfx	w7, w5, #5, #1
	mov.b	v0[5], w7
	ubfx	w7, w5, #6, #1
	mov.b	v0[6], w7
	lsr	w5, w5, #7
	mov.b	v0[7], w5
	ldrb	w5, [x8, #4]
	and	w7, w5, #0x1
	fmov	s2, w7
	ubfx	w7, w5, #1, #1
	mov.b	v2[1], w7
	ubfx	w7, w5, #2, #1
	mov.b	v2[2], w7
	ubfx	w7, w5, #3, #1
	mov.b	v2[3], w7
	ubfx	w7, w5, #4, #1
	mov.b	v2[4], w7
	ubfx	w7, w5, #5, #1
	mov.b	v2[5], w7
	ubfx	w7, w5, #6, #1
	mov.b	v2[6], w7
	lsr	w5, w5, #7
	mov.b	v2[7], w5
	ldr	d1, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v1, v0
	eor.8b	v0, v2, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v1, v0, #0
	umaxv.8b	b0, v1
	fmov	w5, s0
	eor	w5, w5, #0x1
	ands	w0, w5, w0, lsr #4
	dup.8b	v0, w0
	and.8b	v0, v0, v2
	shl.8b	v4, v0, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v5
	addv.8b	b4, v4
	fmov	w0, s4
	csetm	w5, ne
	dup.8b	v4, w5
	bic.8b	v3, v3, v4
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v5
	addv.8b	b3, v3
	stur	b3, [x8, #12]
	bic.8b	v2, v2, v4
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v5
	addv.8b	b2, v2
	stur	b2, [x8, #4]
	cmp	w6, #8
	and	w5, w0, #0xff
	ccmp	w5, #0, #4, hs
	b.ne	LBB0_1348
; %bb.1339:                             ; %ready.overflow.resume1046
                                        ;   in Loop: Header=BB0_5 Depth=1
	movi.2d	v2, #0000000000000000
	ldr	d5, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v1, v5
	addv.8b	b1, v1
	fmov	w5, s1
	and	w7, w1, #0xffffffef
	tst	w5, #0xff
	csel	w5, w7, w1, eq
	ands	w0, w0, #0xff
	fmov	s1, w0
	cmeq.2s	v1, v1, v2
	mvn.8b	v1, v1
	dup.2s	v1, v1[0]
	sxtw	x0, w6
	csel	x1, x0, xzr, ne
	add	x0, sp, #2, lsl #12             ; =8192
	add	x0, x0, #3640
	ldrb	w7, [x0, x1]
	and	w19, w7, #0x1
	fmov	s2, w19
	ubfx	w19, w7, #1, #1
	mov.b	v2[1], w19
	ubfx	w19, w7, #2, #1
	mov.b	v2[2], w19
	ubfx	w19, w7, #3, #1
	mov.b	v2[3], w19
	ubfx	w19, w7, #4, #1
	mov.b	v2[4], w19
	ubfx	w19, w7, #5, #1
	mov.b	v2[5], w19
	ubfx	w19, w7, #6, #1
	mov.b	v2[6], w19
	lsr	w7, w7, #7
	mov.b	v2[7], w7
	bif.8b	v0, v2, v1
	fmov	w7, s27
	add	x19, x4, w7, sxtw #2
	ldr	q1, [sp, #1968]                 ; 16-byte Reload
	fmov	w20, s1
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v5
	addv.8b	b0, v0
	str	b0, [x0, x1]
	lsl	x21, x1, #2
	add	x7, sp, #2, lsl #12             ; =8192
	add	x7, x7, #3600
	add	x1, x7, x21
	csel	x19, x19, x1, ne
	ldr	w19, [x19]
	str	w19, [x1]
	add	x1, sp, #2, lsl #12             ; =8192
	add	x1, x1, #3568
	ldr	w19, [x1, x21]
	csel	w19, w20, w19, ne
	str	w19, [x1, x21]
	cinc	w6, w6, ne
	and	w19, w5, #0x20
	ldrb	w20, [x8, #13]
	and	w21, w20, #0x1
	fmov	s0, w21
	ubfx	w21, w20, #1, #1
	mov.b	v0[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v0[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v0[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v0[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v0[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v0[6], w21
	lsr	w20, w20, #7
	mov.b	v0[7], w20
	ldrb	w20, [x8, #5]
	and	w21, w20, #0x1
	fmov	s2, w21
	ubfx	w21, w20, #1, #1
	mov.b	v2[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v2[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v2[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v2[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v2[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v2[6], w21
	lsr	w20, w20, #7
	mov.b	v2[7], w20
	ldr	d1, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v1, v0
	eor.8b	v0, v2, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v1, v0, #0
	umaxv.8b	b0, v1
	fmov	w20, s0
	eor	w20, w20, #0x1
	ands	w19, w20, w19, lsr #5
	dup.8b	v0, w19
	and.8b	v0, v0, v2
	shl.8b	v4, v0, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v5
	addv.8b	b4, v4
	fmov	w19, s4
	csetm	w20, ne
	dup.8b	v4, w20
	bic.8b	v3, v3, v4
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v5
	addv.8b	b3, v3
	stur	b3, [x8, #13]
	bic.8b	v2, v2, v4
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v5
	addv.8b	b2, v2
	stur	b2, [x8, #5]
	cmp	w6, #8
	and	w20, w19, #0xff
	ccmp	w20, #0, #4, hs
	b.ne	LBB0_1348
; %bb.1340:                             ; %ready.overflow.resume1052
                                        ;   in Loop: Header=BB0_5 Depth=1
	movi.2d	v2, #0000000000000000
	ldr	d5, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v1, v5
	addv.8b	b1, v1
	fmov	w20, s1
	and	w21, w5, #0xffffffdf
	tst	w20, #0xff
	csel	w5, w21, w5, eq
	ands	w19, w19, #0xff
	fmov	s1, w19
	cmeq.2s	v1, v1, v2
	mvn.8b	v1, v1
	dup.2s	v1, v1[0]
	sxtw	x19, w6
	csel	x19, x19, xzr, ne
	ldrb	w20, [x0, x19]
	and	w21, w20, #0x1
	fmov	s2, w21
	ubfx	w21, w20, #1, #1
	mov.b	v2[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v2[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v2[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v2[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v2[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v2[6], w21
	lsr	w20, w20, #7
	mov.b	v2[7], w20
	mov.s	w20, v27[1]
	bif.8b	v0, v2, v1
	add	x20, x4, w20, sxtw #2
	ldr	q1, [sp, #1968]                 ; 16-byte Reload
	mov.s	w21, v1[1]
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v5
	addv.8b	b0, v0
	str	b0, [x0, x19]
	lsl	x0, x19, #2
	add	x7, x7, x0
	csel	x19, x20, x7, ne
	ldr	w19, [x19]
	str	w19, [x7]
	ldr	w7, [x1, x0]
	csel	w7, w21, w7, ne
	str	w7, [x1, x0]
	cinc	w0, w6, ne
	ldrb	w1, [x8, #14]
	and	w6, w1, #0x1
	fmov	s0, w6
	ubfx	w6, w1, #1, #1
	mov.b	v0[1], w6
	ubfx	w6, w1, #2, #1
	mov.b	v0[2], w6
	ubfx	w6, w1, #3, #1
	mov.b	v0[3], w6
	ubfx	w6, w1, #4, #1
	mov.b	v0[4], w6
	ubfx	w6, w1, #5, #1
	mov.b	v0[5], w6
	ubfx	w6, w1, #6, #1
	mov.b	v0[6], w6
	lsr	w1, w1, #7
	mov.b	v0[7], w1
	ldrb	w1, [x8, #6]
	and	w6, w1, #0x1
	fmov	s2, w6
	ubfx	w6, w1, #1, #1
	mov.b	v2[1], w6
	ubfx	w6, w1, #2, #1
	mov.b	v2[2], w6
	ubfx	w6, w1, #3, #1
	mov.b	v2[3], w6
	ubfx	w6, w1, #4, #1
	mov.b	v2[4], w6
	ubfx	w6, w1, #5, #1
	mov.b	v2[5], w6
	ubfx	w6, w1, #6, #1
	mov.b	v2[6], w6
	and	w6, w5, #0x40
	lsr	w1, w1, #7
	mov.b	v2[7], w1
	ldr	d1, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v1, v0
	eor.8b	v0, v2, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v1, v0, #0
	umaxv.8b	b0, v1
	fmov	w1, s0
	eor	w1, w1, #0x1
	ands	w1, w1, w6, lsr #6
	dup.8b	v0, w1
	and.8b	v0, v0, v2
	shl.8b	v4, v0, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v5
	addv.8b	b4, v4
	fmov	w1, s4
	csetm	w6, ne
	dup.8b	v4, w6
	bic.8b	v3, v3, v4
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v5
	addv.8b	b3, v3
	stur	b3, [x8, #14]
	bic.8b	v2, v2, v4
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v5
	addv.8b	b2, v2
	stur	b2, [x8, #6]
	cmp	w0, #8
	b.lo	LBB0_1342
; %bb.1341:                             ; %ready.overflow.resume1052
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w1, #0xff
	b.ne	LBB0_1348
LBB0_1342:                              ; %ready.overflow.resume1058
                                        ;   in Loop: Header=BB0_5 Depth=1
	movi.2d	v2, #0000000000000000
	ldr	d5, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v1, v5
	addv.8b	b1, v1
	fmov	w6, s1
	and	w7, w5, #0xffffffbf
	tst	w6, #0xff
	csel	w7, w7, w5, eq
	ands	w1, w1, #0xff
	fmov	s1, w1
	cmeq.2s	v1, v1, v2
	mvn.8b	v1, v1
	dup.2s	v1, v1[0]
	sxtw	x1, w0
	csel	x5, x1, xzr, ne
	add	x1, sp, #2, lsl #12             ; =8192
	add	x1, x1, #3640
	ldrb	w6, [x1, x5]
	and	w19, w6, #0x1
	fmov	s2, w19
	ubfx	w19, w6, #1, #1
	mov.b	v2[1], w19
	ubfx	w19, w6, #2, #1
	mov.b	v2[2], w19
	ubfx	w19, w6, #3, #1
	mov.b	v2[3], w19
	ubfx	w19, w6, #4, #1
	mov.b	v2[4], w19
	ubfx	w19, w6, #5, #1
	mov.b	v2[5], w19
	ubfx	w19, w6, #6, #1
	mov.b	v2[6], w19
	lsr	w6, w6, #7
	mov.b	v2[7], w6
	bif.8b	v0, v2, v1
	mov.s	w6, v27[2]
	add	x19, x4, w6, sxtw #2
	ldr	q1, [sp, #1968]                 ; 16-byte Reload
	mov.s	w20, v1[2]
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v5
	addv.8b	b0, v0
	str	b0, [x1, x5]
	lsl	x21, x5, #2
	add	x6, sp, #2, lsl #12             ; =8192
	add	x6, x6, #3600
	add	x5, sp, #2, lsl #12             ; =8192
	add	x5, x5, #3568
	ldr	w22, [x5, x21]
	csel	w20, w20, w22, ne
	add	x22, x6, x21
	csel	x19, x19, x22, ne
	ldr	w23, [x19]
	str	w20, [x5, x21]
	sxtb	w19, w7
	str	w23, [x22]
	cinc	w7, w0, ne
	cmp	w19, #0
	ldrb	w0, [x8, #15]
	and	w20, w0, #0x1
	fmov	s0, w20
	ubfx	w20, w0, #1, #1
	mov.b	v0[1], w20
	ubfx	w20, w0, #2, #1
	mov.b	v0[2], w20
	ubfx	w20, w0, #3, #1
	mov.b	v0[3], w20
	ubfx	w20, w0, #4, #1
	mov.b	v0[4], w20
	ubfx	w20, w0, #5, #1
	mov.b	v0[5], w20
	ubfx	w20, w0, #6, #1
	mov.b	v0[6], w20
	lsr	w0, w0, #7
	mov.b	v0[7], w0
	ldrb	w0, [x8, #7]
	and	w20, w0, #0x1
	fmov	s2, w20
	ubfx	w20, w0, #1, #1
	mov.b	v2[1], w20
	ubfx	w20, w0, #2, #1
	mov.b	v2[2], w20
	ubfx	w20, w0, #3, #1
	mov.b	v2[3], w20
	ubfx	w20, w0, #4, #1
	mov.b	v2[4], w20
	ubfx	w20, w0, #5, #1
	mov.b	v2[5], w20
	ubfx	w20, w0, #6, #1
	mov.b	v2[6], w20
	cset	w20, mi
	lsr	w0, w0, #7
	mov.b	v2[7], w0
	ldr	d1, [sp, #1960]                 ; 8-byte Reload
	and.8b	v3, v1, v0
	eor.8b	v0, v2, v3
	shl.8b	v0, v0, #7
	cmlt.8b	v1, v0, #0
	umaxv.8b	b0, v1
	fmov	w0, s0
	eor	w0, w0, #0x1
	ands	w0, w20, w0
	dup.8b	v0, w0
	and.8b	v0, v0, v2
	shl.8b	v4, v0, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v5
	addv.8b	b4, v4
	fmov	w20, s4
	csetm	w0, ne
	dup.8b	v4, w0
	bic.8b	v3, v3, v4
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v3, v3, v5
	addv.8b	b3, v3
	stur	b3, [x8, #15]
	bic.8b	v2, v2, v4
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	and.8b	v2, v2, v5
	addv.8b	b2, v2
	stur	b2, [x8, #7]
	cmp	w7, #8
	b.lo	LBB0_1344
; %bb.1343:                             ; %ready.overflow.resume1058
                                        ;   in Loop: Header=BB0_5 Depth=1
	tst	w20, #0xff
	b.ne	LBB0_1348
LBB0_1344:                              ; %ready.overflow.resume1064
                                        ;   in Loop: Header=BB0_5 Depth=1
	movi.2d	v2, #0000000000000000
	ldr	d3, [sp, #1992]                 ; 8-byte Reload
	and.8b	v1, v1, v3
	addv.8b	b1, v1
	fmov	w0, s1
	and	w21, w19, #0x7f
	tst	w0, #0xff
	csel	w0, w21, w19, eq
	ands	w19, w20, #0xff
	fmov	s1, w19
	cmeq.2s	v1, v1, v2
	mvn.8b	v1, v1
	dup.2s	v1, v1[0]
	sxtw	x19, w7
	csel	x19, x19, xzr, ne
	ldrb	w20, [x1, x19]
	and	w21, w20, #0x1
	fmov	s2, w21
	ubfx	w21, w20, #1, #1
	mov.b	v2[1], w21
	ubfx	w21, w20, #2, #1
	mov.b	v2[2], w21
	ubfx	w21, w20, #3, #1
	mov.b	v2[3], w21
	ubfx	w21, w20, #4, #1
	mov.b	v2[4], w21
	ubfx	w21, w20, #5, #1
	mov.b	v2[5], w21
	ubfx	w21, w20, #6, #1
	mov.b	v2[6], w21
	lsr	w20, w20, #7
	mov.b	v2[7], w20
	bif.8b	v0, v2, v1
	mov.s	w20, v27[3]
	ldr	q1, [sp, #1968]                 ; 16-byte Reload
	mov.s	w21, v1[3]
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v3
	addv.8b	b0, v0
	str	b0, [x1, x19]
	add	x1, x4, w20, sxtw #2
	lsl	x4, x19, #2
	add	x6, x6, x4
	csel	x1, x1, x6, ne
	ldr	w1, [x1]
	str	w1, [x6]
	ldr	w1, [x5, x4]
	csel	w1, w21, w1, ne
	str	w1, [x5, x4]
	cinc	w1, w7, ne
	cbnz	w1, LBB0_5
	b	LBB0_1346
LBB0_1345:                              ;   in Loop: Header=BB0_5 Depth=1
	mov	w0, #0                          ; =0x0
	cbnz	w1, LBB0_5
LBB0_1346:                              ; %scheduler.done
	ldr	d0, [sp, #1960]                 ; 8-byte Reload
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	umaxv.8b	b0, v0
	fmov	w8, s0
	tbnz	w8, #0, LBB0_1348
; %bb.1347:                             ; %scheduler.exit
	sub	sp, x29, #128
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #144            ; 16-byte Folded Reload
	ret
LBB0_1348:                              ; %scheduler.stalled
	brk	#0x1
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpLdr	Lloh56, Lloh57
	.loh AdrpAdrp	Lloh54, Lloh56
	.loh AdrpLdr	Lloh54, Lloh55
	.loh AdrpAdrp	Lloh52, Lloh54
	.loh AdrpLdr	Lloh52, Lloh53
	.loh AdrpAdrp	Lloh50, Lloh52
	.loh AdrpLdr	Lloh50, Lloh51
	.loh AdrpLdr	Lloh48, Lloh49
	.loh AdrpAdrp	Lloh46, Lloh48
	.loh AdrpLdr	Lloh46, Lloh47
	.loh AdrpAdrp	Lloh44, Lloh46
	.loh AdrpLdr	Lloh44, Lloh45
	.loh AdrpAdrp	Lloh42, Lloh44
	.loh AdrpLdr	Lloh42, Lloh43
	.loh AdrpLdr	Lloh40, Lloh41
	.loh AdrpAdrp	Lloh38, Lloh40
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpAdrp	Lloh36, Lloh38
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpAdrp	Lloh34, Lloh36
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpLdr	Lloh32, Lloh33
	.loh AdrpAdrp	Lloh30, Lloh32
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdrp	Lloh28, Lloh30
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpLdr	Lloh104, Lloh105
	.loh AdrpAdrp	Lloh102, Lloh104
	.loh AdrpLdr	Lloh102, Lloh103
	.loh AdrpAdrp	Lloh100, Lloh102
	.loh AdrpLdr	Lloh100, Lloh101
	.loh AdrpAdrp	Lloh98, Lloh100
	.loh AdrpLdr	Lloh98, Lloh99
	.loh AdrpLdr	Lloh96, Lloh97
	.loh AdrpAdrp	Lloh94, Lloh96
	.loh AdrpLdr	Lloh94, Lloh95
	.loh AdrpAdrp	Lloh92, Lloh94
	.loh AdrpLdr	Lloh92, Lloh93
	.loh AdrpAdrp	Lloh90, Lloh92
	.loh AdrpLdr	Lloh90, Lloh91
	.loh AdrpLdr	Lloh88, Lloh89
	.loh AdrpAdrp	Lloh86, Lloh88
	.loh AdrpLdr	Lloh86, Lloh87
	.loh AdrpAdrp	Lloh84, Lloh86
	.loh AdrpLdr	Lloh84, Lloh85
	.loh AdrpAdrp	Lloh82, Lloh84
	.loh AdrpLdr	Lloh82, Lloh83
	.loh AdrpLdr	Lloh80, Lloh81
	.loh AdrpAdrp	Lloh78, Lloh80
	.loh AdrpLdr	Lloh78, Lloh79
	.loh AdrpAdrp	Lloh76, Lloh78
	.loh AdrpLdr	Lloh76, Lloh77
	.loh AdrpAdrp	Lloh74, Lloh76
	.loh AdrpLdr	Lloh74, Lloh75
	.loh AdrpLdr	Lloh72, Lloh73
	.loh AdrpAdrp	Lloh70, Lloh72
	.loh AdrpLdr	Lloh70, Lloh71
	.loh AdrpAdrp	Lloh68, Lloh70
	.loh AdrpLdr	Lloh68, Lloh69
	.loh AdrpAdrp	Lloh66, Lloh68
	.loh AdrpLdr	Lloh66, Lloh67
	.loh AdrpLdr	Lloh64, Lloh65
	.loh AdrpAdrp	Lloh62, Lloh64
	.loh AdrpLdr	Lloh62, Lloh63
	.loh AdrpAdrp	Lloh60, Lloh62
	.loh AdrpLdr	Lloh60, Lloh61
	.loh AdrpAdrp	Lloh58, Lloh60
	.loh AdrpLdr	Lloh58, Lloh59
	.loh AdrpAdd	Lloh106, Lloh107
	.section	__TEXT,__const
	.p2align	1, 0x0
LJTI0_0:
	.short	(LBB0_7-LBB0_7)>>2
	.short	(LBB0_173-LBB0_7)>>2
	.short	(LBB0_183-LBB0_7)>>2
	.short	(LBB0_98-LBB0_7)>>2
	.short	(LBB0_308-LBB0_7)>>2
	.short	(LBB0_197-LBB0_7)>>2
	.short	(LBB0_419-LBB0_7)>>2
	.short	(LBB0_207-LBB0_7)>>2
	.short	(LBB0_444-LBB0_7)>>2
	.short	(LBB0_133-LBB0_7)>>2
	.short	(LBB0_469-LBB0_7)>>2
	.short	(LBB0_514-LBB0_7)>>2
	.short	(LBB0_162-LBB0_7)>>2
	.short	(LBB0_108-LBB0_7)>>2
	.short	(LBB0_118-LBB0_7)>>2
	.short	(LBB0_217-LBB0_7)>>2
	.short	(LBB0_719-LBB0_7)>>2
	.short	(LBB0_87-LBB0_7)>>2
	.short	(LBB0_751-LBB0_7)>>2
	.short	(LBB0_66-LBB0_7)>>2
	.short	(LBB0_776-LBB0_7)>>2
	.short	(LBB0_123-LBB0_7)>>2
	.short	(LBB0_801-LBB0_7)>>2
	.short	(LBB0_77-LBB0_7)>>2
	.short	(LBB0_880-LBB0_7)>>2
	.short	(LBB0_163-LBB0_7)>>2
	.short	(LBB0_947-LBB0_7)>>2
	.short	(LBB0_143-LBB0_7)>>2
	.short	(LBB0_973-LBB0_7)>>2
	.short	(LBB0_1153-LBB0_7)>>2
	.short	(LBB0_65-LBB0_7)>>2
	.short	(LBB0_1179-LBB0_7)>>2
	.short	(LBB0_1187-LBB0_7)>>2
	.short	(LBB0_227-LBB0_7)>>2
	.short	(LBB0_1213-LBB0_7)>>2
	.short	(LBB0_1221-LBB0_7)>>2
	.short	(LBB0_76-LBB0_7)>>2
	.short	(LBB0_1247-LBB0_7)>>2
	.short	(LBB0_1255-LBB0_7)>>2
	.short	(LBB0_97-LBB0_7)>>2
	.short	(LBB0_1283-LBB0_7)>>2
	.short	(LBB0_725-LBB0_7)>>2
	.short	(LBB0_188-LBB0_7)>>2
	.short	(LBB0_1091-LBB0_7)>>2
	.short	(LBB0_153-LBB0_7)>>2
	.short	(LBB0_1114-LBB0_7)>>2
	.short	(LBB0_1301-LBB0_7)>>2
	.short	(LBB0_1326-LBB0_7)>>2
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_attention.packet_batch     ; -- Begin function llm_attention.packet_batch
	.p2align	2
_llm_attention.packet_batch:            ; @llm_attention.packet_batch
; %bb.0:                                ; %packet.batch.prologue
	stp	x26, x25, [sp, #-80]!           ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	mov	x21, x3
	mov	x19, x2
	mov	x20, x0
	ldr	w23, [x2, #36]
	ldr	w8, [x2]
	ldr	w9, [x2, #12]
	lsl	x8, x8, #5
	cmp	x8, x9
	csel	x10, x8, xzr, ls
	add	x10, x10, x23
	subs	x11, x9, x10
	mov	w12, #32                        ; =0x20
	sub	x13, x12, x23
	cmp	x11, x13
	csel	x11, x11, x13, lo
	cmp	x9, x10
	ccmp	x23, x12, #2, hi
	ccmp	x8, x9, #2, lo
	csel	x8, x11, xzr, ls
	cmp	w3, #4
	b.ne	LBB1_3
; %bb.1:                                ; %packet.batch.prologue
	cmp	x8, #32
	b.lo	LBB1_3
; %bb.2:                                ; %packet.batch.full
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	add	w8, w23, #8
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	add	w8, w23, #16
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	add	w8, w23, #24
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	b	_llm_attention
LBB1_3:                                 ; %packet.batch.partial
	ubfiz	x9, x21, #3, #32
	cmp	x8, x9
	csel	x8, x8, x9, lo
	lsr	x24, x8, #3
	and	w22, w8, #0x7
	cbz	x24, LBB1_6
; %bb.4:                                ; %packet.batch.partial.full.loop.preheader
	mov	x25, x24
	mov	x26, x23
LBB1_5:                                 ; %packet.batch.partial.full.loop
                                        ; =>This Inner Loop Header: Depth=1
	str	w26, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	add	w26, w26, #8
	subs	w25, w25, #1
	b.ne	LBB1_5
LBB1_6:                                 ; %packet.batch.tail.check
	cbz	w22, LBB1_8
; %bb.7:                                ; %packet.batch.tail.call
	add	w8, w23, w24, lsl #3
	str	w8, [x19, #36]
	mov	x0, x20
	mov	x1, x19
	mov	x2, x22
	bl	_llm_attention
LBB1_8:                                 ; %packet.batch.partial.finish
	lsl	w8, w21, #3
	sub	w8, w8, #8
	cmp	w21, #0
	csel	w8, wzr, w8, eq
	add	w8, w23, w8
	str	w8, [x19, #36]
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp], #80             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.section	__TEXT,__const
	.p2align	2, 0x0                          ; @convergence.targets
l_convergence.targets:
	.long	2                               ; 0x2
	.long	4                               ; 0x4
	.long	6                               ; 0x6
	.long	8                               ; 0x8
	.long	10                              ; 0xa
	.long	41                              ; 0x29
	.long	14                              ; 0xe
	.long	16                              ; 0x10
	.long	18                              ; 0x12
	.long	20                              ; 0x14
	.long	22                              ; 0x16
	.long	24                              ; 0x18
	.long	26                              ; 0x1a
	.long	28                              ; 0x1c
	.long	31                              ; 0x1f
	.long	34                              ; 0x22
	.long	37                              ; 0x25
	.long	40                              ; 0x28
	.long	43                              ; 0x2b
	.long	45                              ; 0x2d
	.long	47                              ; 0x2f

.subsections_via_symbols

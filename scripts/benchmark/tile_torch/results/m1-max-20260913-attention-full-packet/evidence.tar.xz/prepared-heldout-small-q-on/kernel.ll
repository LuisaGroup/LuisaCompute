; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_attention(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 2560
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 5632
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 8704
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 49664
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 98816
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 99328
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 99840
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill29 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill29, align 64
  %.spill30 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill30, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill31 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill31, align 64
  %tile_snapshot.spill32 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill32, align 64
  %.slot33 = alloca i64, align 8
  store i64 0, ptr %.slot33, align 4
  %.slot34 = alloca i64, align 8
  store i64 0, ptr %.slot34, align 4
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.slot36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot36, align 32
  %.spill37 = alloca i64, align 8
  store i64 0, ptr %.spill37, align 4
  %tile_snapshot.spill38 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill38, align 64
  %.slot39 = alloca i64, align 8
  store i64 0, ptr %.slot39, align 4
  %.spill40 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill40, align 64
  %.slot41 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot41, align 32
  %tile_snapshot.spill42 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill42, align 64
  %.slot43 = alloca i64, align 8
  store i64 0, ptr %.slot43, align 4
  %.spill44 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill44, align 64
  %.slot45 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot45, align 32
  %.slot46 = alloca i64, align 8
  store i64 0, ptr %.slot46, align 4
  %.slot47 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot47, align 32
  %.slot48 = alloca i64, align 8
  store i64 0, ptr %.slot48, align 4
  %.slot49 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot49, align 32
  %.slot50 = alloca i64, align 8
  store i64 0, ptr %.slot50, align 4
  %.slot51 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot51, align 32
  %.slot52 = alloca i64, align 8
  store i64 0, ptr %.slot52, align 4
  %.slot53 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot53, align 32
  %.slot54 = alloca i64, align 8
  store i64 0, ptr %.slot54, align 4
  %.slot55 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot55, align 32
  %.slot56 = alloca i64, align 8
  store i64 0, ptr %.slot56, align 4
  %.slot57 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot57, align 32
  %.slot58 = alloca i64, align 8
  store i64 0, ptr %.slot58, align 4
  %.slot59 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot59, align 32
  %.slot60 = alloca i64, align 8
  store i64 0, ptr %.slot60, align 4
  %.slot61 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot61, align 32
  %.slot62 = alloca i64, align 8
  store i64 0, ptr %.slot62, align 4
  %.slot63 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot63, align 32
  %.slot64 = alloca i64, align 8
  store i64 0, ptr %.slot64, align 4
  %.slot65 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot65, align 32
  %.slot66 = alloca i64, align 8
  store i64 0, ptr %.slot66, align 4
  %.slot67 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot67, align 32
  %.slot68 = alloca i64, align 8
  store i64 0, ptr %.slot68, align 4
  %.slot69 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot69, align 32
  %.slot70 = alloca i64, align 8
  store i64 0, ptr %.slot70, align 4
  %.slot71 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot71, align 32
  %.slot72 = alloca i64, align 8
  store i64 0, ptr %.slot72, align 4
  %.slot73 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot73, align 32
  %.slot74 = alloca i64, align 8
  store i64 0, ptr %.slot74, align 4
  %.slot75 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot75, align 32
  %.slot76 = alloca i64, align 8
  store i64 0, ptr %.slot76, align 4
  %.slot77 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot77, align 32
  %.spill78 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill78, align 1
  %.spill79 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill79, align 1
  %.spill80 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill80, align 1
  %.spill81 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill81, align 1
  %.spill82 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill82, align 1
  %.spill83 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill83, align 1
  %.spill84 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill84, align 1
  %.spill85 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill85, align 1
  %.spill86 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill86, align 1
  %.spill87 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill87, align 1
  %.spill88 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill88, align 1
  %.spill89 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill89, align 1
  %.spill90 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill90, align 1
  %.spill91 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill91, align 1
  %.spill92 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill92, align 1
  %.spill93 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill93, align 1
  %.spill94 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill94, align 32
  %.spill95 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill95, align 32
  %.spill96 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill96, align 32
  %.spill97 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill97, align 32
  %.spill98 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill98, align 32
  %.spill99 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill99, align 32
  %.spill100 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill100, align 32
  %.spill101 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill101, align 32
  %.spill102 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill102, align 32
  %.spill103 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill103, align 32
  %.spill104 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill104, align 32
  %.spill105 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill105, align 32
  %.spill106 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill106, align 32
  %.spill107 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill107, align 32
  %.spill108 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill108, align 32
  %.spill109 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill109, align 32
  %tile_snapshot.spill110 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill110, align 64
  %.slot111 = alloca i64, align 8
  store i64 0, ptr %.slot111, align 4
  %.slot112 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot112, align 32
  %.spill113 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill113, align 32
  %.spill114 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill114, align 32
  %.spill115 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill115, align 32
  %.spill116 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill116, align 32
  %.spill117 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill117, align 32
  %.spill118 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill118, align 32
  %.spill119 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill119, align 32
  %.spill120 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill120, align 32
  %.spill121 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill121, align 32
  %.spill122 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill122, align 32
  %.spill123 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill123, align 32
  %.spill124 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill124, align 32
  %.spill125 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill125, align 32
  %.spill126 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill126, align 32
  %.spill127 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill127, align 32
  %.spill128 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill128, align 32
  %.spill129 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill129, align 32
  %.spill130 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill130, align 32
  %tile_snapshot.spill131 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill131, align 64
  %.spill132 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill132, align 32
  %.slot133 = alloca i64, align 8
  store i64 0, ptr %.slot133, align 4
  %.slot134 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot134, align 32
  %.spill135 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill135, align 32
  %tile_snapshot.spill136 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill136, align 64
  %.slot137 = alloca i64, align 8
  store i64 0, ptr %.slot137, align 4
  %.slot138 = alloca i64, align 8
  store i64 0, ptr %.slot138, align 4
  %.slot139 = alloca i64, align 8
  store i64 0, ptr %.slot139, align 4
  %.slot140 = alloca i64, align 8
  store i64 0, ptr %.slot140, align 4
  %24 = getelementptr i8, ptr %argument_buffer, i64 0
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = getelementptr i8, ptr %argument_buffer, i64 16
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %30, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %33, 1
  %36 = getelementptr i8, ptr %argument_buffer, i64 32
  %37 = load ptr, ptr %36, align 16
  %38 = getelementptr i8, ptr %36, i64 8
  %39 = load i64, ptr %38, align 8
  %40 = insertvalue { ptr, i64 } poison, ptr %37, 0
  %41 = insertvalue { ptr, i64 } %40, i64 %39, 1
  %42 = getelementptr i8, ptr %argument_buffer, i64 48
  %43 = load ptr, ptr %42, align 16
  %44 = getelementptr i8, ptr %42, i64 8
  %45 = load i64, ptr %44, align 8
  %46 = insertvalue { ptr, i64 } poison, ptr %43, 0
  %47 = insertvalue { ptr, i64 } %46, i64 %45, 1
  %48 = load i32, ptr %launch_config, align 4
  %49 = getelementptr i8, ptr %launch_config, i64 12
  %50 = load i32, ptr %49, align 4
  %51 = getelementptr i8, ptr %launch_config, i64 4
  %52 = load i32, ptr %51, align 4
  %53 = getelementptr i8, ptr %launch_config, i64 16
  %54 = load i32, ptr %53, align 4
  %55 = getelementptr i8, ptr %launch_config, i64 8
  %56 = load i32, ptr %55, align 4
  %57 = getelementptr i8, ptr %launch_config, i64 20
  %58 = load i32, ptr %57, align 4
  %59 = getelementptr i8, ptr %launch_config, i64 36
  %60 = load i32, ptr %59, align 4
  %.splatinsert141 = insertelement <8 x i32> poison, i32 %60, i64 0
  %.splat142 = shufflevector <8 x i32> %.splatinsert141, <8 x i32> poison, <8 x i32> zeroinitializer
  %61 = add <8 x i32> %.splat142, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %62 = mul i32 %48, 32
  %.splatinsert143 = insertelement <8 x i32> poison, i32 %62, i64 0
  %.splat144 = shufflevector <8 x i32> %.splatinsert143, <8 x i32> poison, <8 x i32> zeroinitializer
  %63 = add <8 x i32> %.splat144, %61
  %64 = mul i32 %52, 1
  %.splatinsert145 = insertelement <8 x i32> poison, i32 %64, i64 0
  %.splat146 = shufflevector <8 x i32> %.splatinsert145, <8 x i32> poison, <8 x i32> zeroinitializer
  %65 = add <8 x i32> %.splat146, zeroinitializer
  %66 = mul i32 %56, 1
  %.splatinsert147 = insertelement <8 x i32> poison, i32 %66, i64 0
  %.splat148 = shufflevector <8 x i32> %.splatinsert147, <8 x i32> poison, <8 x i32> zeroinitializer
  %67 = add <8 x i32> %.splat148, zeroinitializer
  %68 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %63, 0
  %69 = insertvalue [3 x <8 x i32>] %68, <8 x i32> %65, 1
  %70 = insertvalue [3 x <8 x i32>] %69, <8 x i32> %67, 2
  %.splatinsert149 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat150 = shufflevector <8 x i32> %.splatinsert149, <8 x i32> poison, <8 x i32> zeroinitializer
  %71 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat150
  %72 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  br i1 %72, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %73 = extractvalue [3 x <8 x i32>] %70, 0
  %74 = zext <8 x i32> %73 to <8 x i64>
  %75 = select <8 x i1> %71, <8 x i64> %74, <8 x i64> zeroinitializer
  %76 = select <8 x i1> %71, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %77 = sdiv <8 x i64> %75, %76
  %78 = select <8 x i1> %71, <8 x i64> %74, <8 x i64> zeroinitializer
  %79 = select <8 x i1> %71, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %80 = sdiv <8 x i64> %78, %79
  %81 = select <8 x i1> %71, <8 x i64> %80, <8 x i64> zeroinitializer
  %82 = select <8 x i1> %71, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %83 = srem <8 x i64> %81, %82
  %84 = load <8 x i64>, ptr %.spill, align 64
  %85 = select <8 x i1> %71, <8 x i64> %83, <8 x i64> %84
  store <8 x i64> %85, ptr %.spill, align 64
  %86 = mul <8 x i64> %77, splat (i64 1)
  %87 = load <8 x i64>, ptr %.spill29, align 64
  %88 = select <8 x i1> %71, <8 x i64> %86, <8 x i64> %87
  store <8 x i64> %88, ptr %.spill29, align 64
  %89 = select <8 x i1> %71, <8 x i64> %83, <8 x i64> zeroinitializer
  %90 = select <8 x i1> %71, <8 x i64> splat (i64 4), <8 x i64> splat (i64 1)
  %91 = sdiv <8 x i64> %89, %90
  %92 = load <8 x i64>, ptr %.spill30, align 64
  %93 = select <8 x i1> %71, <8 x i64> %91, <8 x i64> %92
  store <8 x i64> %93, ptr %.spill30, align 64
  %94 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %95 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %96 = extractvalue { <8 x ptr>, <8 x i64> } %94, 0
  %97 = select <8 x i1> %71, <8 x ptr> %95, <8 x ptr> %96
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %99 = extractvalue { <8 x ptr>, <8 x i64> } %94, 1
  %100 = select <8 x i1> %71, <8 x i64> %98, <8 x i64> %99
  %101 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %97, 0
  %102 = insertvalue { <8 x ptr>, <8 x i64> } %101, <8 x i64> %100, 1
  store { <8 x ptr>, <8 x i64> } %102, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %103 = icmp slt i64 %.state, 80
  br i1 %103, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %104 = add <8 x i64> %.spill.load, zeroinitializer
  %105 = add <8 x i64> zeroinitializer, %104
  %.spill.load151 = load <8 x i64>, ptr %.spill29, align 64
  %106 = add <8 x i64> %.spill.load151, zeroinitializer
  %107 = mul <8 x i64> %105, splat (i64 3)
  %108 = add <8 x i64> %107, %106
  %.state152 = load i64, ptr %.slot, align 4
  %109 = add i64 0, %.state152
  %110 = mul <8 x i64> %108, splat (i64 80)
  %.splatinsert153 = insertelement <8 x i64> poison, i64 %109, i64 0
  %.splat154 = shufflevector <8 x i64> %.splatinsert153, <8 x i64> poison, <8 x i32> zeroinitializer
  %111 = add <8 x i64> %110, %.splat154
  %112 = extractvalue { ptr, i64 } %29, 0
  %113 = mul <8 x i64> %111, splat (i64 4)
  %114 = getelementptr i8, ptr %112, <8 x i64> %113
  %115 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %114, <8 x i1> %71, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %117 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state155 = load i64, ptr %.slot, align 4
  %.splatinsert156 = insertelement <8 x i64> poison, i64 %.state155, i64 0
  %.splat157 = shufflevector <8 x i64> %.splatinsert156, <8 x i64> poison, <8 x i32> zeroinitializer
  %118 = mul <8 x i64> %.splat157, splat (i64 32)
  %119 = add <8 x i64> %117, %118
  %120 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %116, 0
  %121 = insertvalue { <8 x ptr>, <8 x i64> } %120, <8 x i64> %119, 1
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %123 = extractvalue { <8 x ptr>, <8 x i64> } %121, 1
  %124 = extractelement <8 x ptr> %122, i32 0
  %125 = extractelement <8 x i64> %123, i32 0
  %126 = sub i64 %125, 0
  %127 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %128 = select i1 %127, i64 %126, i64 0
  %private.contiguous.address = getelementptr i8, ptr %124, i64 %128
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %129 = select <8 x i1> %71, <8 x float> %115, <8 x float> %private.contiguous.preserve
  store <8 x float> %129, ptr %private.contiguous.address, align 4
  %.state158 = load i64, ptr %.slot, align 4
  %130 = add i64 %.state158, 1
  store i64 %130, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %131 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %132 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %133 = extractvalue { <8 x ptr>, <8 x i64> } %131, 0
  %134 = select <8 x i1> %71, <8 x ptr> %132, <8 x ptr> %133
  %135 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %136 = extractvalue { <8 x ptr>, <8 x i64> } %131, 1
  %137 = select <8 x i1> %71, <8 x i64> %135, <8 x i64> %136
  %138 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %134, 0
  %139 = insertvalue { <8 x ptr>, <8 x i64> } %138, <8 x i64> %137, 1
  store { <8 x ptr>, <8 x i64> } %139, ptr %tile_snapshot.spill31, align 64
  %140 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %141 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %140, 0
  %143 = select <8 x i1> %71, <8 x ptr> %141, <8 x ptr> %142
  %144 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %145 = extractvalue { <8 x ptr>, <8 x i64> } %140, 1
  %146 = select <8 x i1> %71, <8 x i64> %144, <8 x i64> %145
  %147 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %143, 0
  %148 = insertvalue { <8 x ptr>, <8 x i64> } %147, <8 x i64> %146, 1
  store { <8 x ptr>, <8 x i64> } %148, ptr %tile_snapshot.spill32, align 64
  store i64 0, ptr %.slot33, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state159 = load i64, ptr %.slot33, align 4
  %149 = icmp slt i64 %.state159, 96
  br i1 %149, label %direct.true160, label %direct.false161

direct.schedule.5:                                ; preds = %direct.true160
  %tile_snapshot.spill.load162 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load162, 0
  %151 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load162, 1
  %.state163 = load i64, ptr %.slot33, align 4
  %.splatinsert164 = insertelement <8 x i64> poison, i64 %.state163, i64 0
  %.splat165 = shufflevector <8 x i64> %.splatinsert164, <8 x i64> poison, <8 x i32> zeroinitializer
  %152 = mul <8 x i64> %.splat165, splat (i64 32)
  %153 = add <8 x i64> %151, %152
  %154 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %150, 0
  %155 = insertvalue { <8 x ptr>, <8 x i64> } %154, <8 x i64> %153, 1
  %156 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %157 = extractvalue { <8 x ptr>, <8 x i64> } %155, 1
  %158 = extractelement <8 x ptr> %156, i32 0
  %159 = extractelement <8 x i64> %157, i32 0
  %160 = sub i64 %159, 0
  %161 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %162 = select i1 %161, i64 %160, i64 0
  %private.contiguous.address166 = getelementptr i8, ptr %158, i64 %162
  %private.contiguous.preserve167 = load <8 x float>, ptr %private.contiguous.address166, align 4
  %163 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %private.contiguous.preserve167
  store <8 x float> %163, ptr %private.contiguous.address166, align 4
  %.state168 = load i64, ptr %.slot33, align 4
  %164 = add i64 %.state168, 1
  store i64 %164, ptr %.slot33, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false161
  store i64 0, ptr %.slot34, align 4
  %165 = load <8 x float>, ptr %.slot35, align 32
  %166 = select <8 x i1> %71, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %165
  store <8 x float> %166, ptr %.slot35, align 32
  %167 = load <8 x float>, ptr %.slot36, align 32
  %168 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %167
  store <8 x float> %168, ptr %.slot36, align 32
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.81, %direct.schedule.6
  %.state169 = load i64, ptr %.slot34, align 4
  %169 = icmp slt i64 %.state169, 5
  br i1 %169, label %direct.true170, label %direct.false171

direct.schedule.8:                                ; preds = %direct.true170
  %.state172 = load i64, ptr %.slot34, align 4
  %170 = sdiv i64 %.state172, 1
  %171 = mul i64 %170, 16
  store i64 %171, ptr %.spill37, align 4
  %172 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %172, 0
  %175 = select <8 x i1> %71, <8 x ptr> %173, <8 x ptr> %174
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %177 = extractvalue { <8 x ptr>, <8 x i64> } %172, 1
  %178 = select <8 x i1> %71, <8 x i64> %176, <8 x i64> %177
  %179 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %175, 0
  %180 = insertvalue { <8 x ptr>, <8 x i64> } %179, <8 x i64> %178, 1
  store { <8 x ptr>, <8 x i64> } %180, ptr %tile_snapshot.spill38, align 64
  store i64 0, ptr %.slot39, align 4
  br label %direct.schedule.9

direct.schedule.9:                                ; preds = %direct.schedule.12, %direct.schedule.8
  %.state173 = load i64, ptr %.slot39, align 4
  %181 = icmp slt i64 %.state173, 1280
  br i1 %181, label %direct.true174, label %direct.false175

direct.schedule.10:                               ; preds = %direct.true174
  %.state176 = load i64, ptr %.slot39, align 4
  %182 = srem i64 %.state176, 80
  %.state177 = load i64, ptr %.slot39, align 4
  %183 = sdiv i64 %.state177, 80
  %.spill.load178 = load <8 x i64>, ptr %.spill30, align 64
  %184 = add <8 x i64> %.spill.load178, zeroinitializer
  %185 = add <8 x i64> zeroinitializer, %184
  %.spill.load179 = load i64, ptr %.spill37, align 4
  %186 = add i64 %.spill.load179, %183
  %187 = mul <8 x i64> %185, splat (i64 67)
  %.splatinsert180 = insertelement <8 x i64> poison, i64 %186, i64 0
  %.splat181 = shufflevector <8 x i64> %.splatinsert180, <8 x i64> poison, <8 x i32> zeroinitializer
  %188 = add <8 x i64> %187, %.splat181
  %189 = icmp sge i64 %186, 0
  %190 = and i1 true, %189
  %191 = icmp slt i64 %186, 67
  %192 = and i1 %190, %191
  %193 = add i64 0, %182
  %194 = mul <8 x i64> %188, splat (i64 80)
  %.splatinsert182 = insertelement <8 x i64> poison, i64 %193, i64 0
  %.splat183 = shufflevector <8 x i64> %.splatinsert182, <8 x i64> poison, <8 x i32> zeroinitializer
  %195 = add <8 x i64> %194, %.splat183
  %196 = load <8 x i64>, ptr %.spill40, align 64
  %197 = select <8 x i1> %71, <8 x i64> %195, <8 x i64> %196
  store <8 x i64> %197, ptr %.spill40, align 64
  br i1 %192, label %direct.true184, label %direct.false185

direct.schedule.11:                               ; preds = %direct.true184
  %.spill.load186 = load <8 x i64>, ptr %.spill40, align 64
  %198 = extractvalue { ptr, i64 } %35, 0
  %199 = mul <8 x i64> %.spill.load186, splat (i64 4)
  %200 = getelementptr i8, ptr %198, <8 x i64> %199
  %201 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %200, <8 x i1> %71, <8 x float> zeroinitializer)
  %202 = load <8 x float>, ptr %.slot41, align 32
  %203 = select <8 x i1> %71, <8 x float> %201, <8 x float> %202
  store <8 x float> %203, ptr %.slot41, align 32
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.schedule.11, %direct.false185
  %tile_snapshot.spill.load187 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %204 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load187, 0
  %205 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load187, 1
  %.state188 = load i64, ptr %.slot39, align 4
  %.splatinsert189 = insertelement <8 x i64> poison, i64 %.state188, i64 0
  %.splat190 = shufflevector <8 x i64> %.splatinsert189, <8 x i64> poison, <8 x i32> zeroinitializer
  %206 = mul <8 x i64> %.splat190, splat (i64 32)
  %207 = add <8 x i64> %205, %206
  %208 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %204, 0
  %209 = insertvalue { <8 x ptr>, <8 x i64> } %208, <8 x i64> %207, 1
  %.state191 = load <8 x float>, ptr %.slot41, align 32
  %210 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %211 = extractvalue { <8 x ptr>, <8 x i64> } %209, 1
  %212 = extractelement <8 x ptr> %210, i32 0
  %213 = extractelement <8 x i64> %211, i32 0
  %214 = sub i64 %213, 0
  %215 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %216 = select i1 %215, i64 %214, i64 0
  %private.contiguous.address192 = getelementptr i8, ptr %212, i64 %216
  %private.contiguous.preserve193 = load <8 x float>, ptr %private.contiguous.address192, align 4
  %217 = select <8 x i1> %71, <8 x float> %.state191, <8 x float> %private.contiguous.preserve193
  store <8 x float> %217, ptr %private.contiguous.address192, align 4
  %.state194 = load i64, ptr %.slot39, align 4
  %218 = add i64 %.state194, 1
  store i64 %218, ptr %.slot39, align 4
  br label %direct.schedule.9

direct.schedule.13:                               ; preds = %direct.false175
  %219 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %219, 0
  %222 = select <8 x i1> %71, <8 x ptr> %220, <8 x ptr> %221
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %224 = extractvalue { <8 x ptr>, <8 x i64> } %219, 1
  %225 = select <8 x i1> %71, <8 x i64> %223, <8 x i64> %224
  %226 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %222, 0
  %227 = insertvalue { <8 x ptr>, <8 x i64> } %226, <8 x i64> %225, 1
  store { <8 x ptr>, <8 x i64> } %227, ptr %tile_snapshot.spill42, align 64
  store i64 0, ptr %.slot43, align 4
  br label %direct.schedule.14

direct.schedule.14:                               ; preds = %direct.schedule.17, %direct.schedule.13
  %.state195 = load i64, ptr %.slot43, align 4
  %228 = icmp slt i64 %.state195, 1536
  br i1 %228, label %direct.true196, label %direct.false197

direct.schedule.15:                               ; preds = %direct.true196
  %.state198 = load i64, ptr %.slot43, align 4
  %229 = srem i64 %.state198, 96
  %.state199 = load i64, ptr %.slot43, align 4
  %230 = sdiv i64 %.state199, 96
  %.spill.load200 = load <8 x i64>, ptr %.spill30, align 64
  %231 = add <8 x i64> %.spill.load200, zeroinitializer
  %232 = add <8 x i64> zeroinitializer, %231
  %.spill.load201 = load i64, ptr %.spill37, align 4
  %233 = add i64 %.spill.load201, %230
  %234 = mul <8 x i64> %232, splat (i64 67)
  %.splatinsert202 = insertelement <8 x i64> poison, i64 %233, i64 0
  %.splat203 = shufflevector <8 x i64> %.splatinsert202, <8 x i64> poison, <8 x i32> zeroinitializer
  %235 = add <8 x i64> %234, %.splat203
  %236 = icmp sge i64 %233, 0
  %237 = and i1 true, %236
  %238 = icmp slt i64 %233, 67
  %239 = and i1 %237, %238
  %240 = add i64 0, %229
  %241 = mul <8 x i64> %235, splat (i64 96)
  %.splatinsert204 = insertelement <8 x i64> poison, i64 %240, i64 0
  %.splat205 = shufflevector <8 x i64> %.splatinsert204, <8 x i64> poison, <8 x i32> zeroinitializer
  %242 = add <8 x i64> %241, %.splat205
  %243 = load <8 x i64>, ptr %.spill44, align 64
  %244 = select <8 x i1> %71, <8 x i64> %242, <8 x i64> %243
  store <8 x i64> %244, ptr %.spill44, align 64
  br i1 %239, label %direct.true206, label %direct.false207

direct.schedule.16:                               ; preds = %direct.true206
  %.spill.load208 = load <8 x i64>, ptr %.spill44, align 64
  %245 = extractvalue { ptr, i64 } %41, 0
  %246 = mul <8 x i64> %.spill.load208, splat (i64 4)
  %247 = getelementptr i8, ptr %245, <8 x i64> %246
  %248 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %247, <8 x i1> %71, <8 x float> zeroinitializer)
  %249 = load <8 x float>, ptr %.slot45, align 32
  %250 = select <8 x i1> %71, <8 x float> %248, <8 x float> %249
  store <8 x float> %250, ptr %.slot45, align 32
  br label %direct.schedule.17

direct.schedule.17:                               ; preds = %direct.schedule.16, %direct.false207
  %tile_snapshot.spill.load209 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %251 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load209, 0
  %252 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load209, 1
  %.state210 = load i64, ptr %.slot43, align 4
  %.splatinsert211 = insertelement <8 x i64> poison, i64 %.state210, i64 0
  %.splat212 = shufflevector <8 x i64> %.splatinsert211, <8 x i64> poison, <8 x i32> zeroinitializer
  %253 = mul <8 x i64> %.splat212, splat (i64 32)
  %254 = add <8 x i64> %252, %253
  %255 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %251, 0
  %256 = insertvalue { <8 x ptr>, <8 x i64> } %255, <8 x i64> %254, 1
  %.state213 = load <8 x float>, ptr %.slot45, align 32
  %257 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %258 = extractvalue { <8 x ptr>, <8 x i64> } %256, 1
  %259 = extractelement <8 x ptr> %257, i32 0
  %260 = extractelement <8 x i64> %258, i32 0
  %261 = sub i64 %260, 0
  %262 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %263 = select i1 %262, i64 %261, i64 0
  %private.contiguous.address214 = getelementptr i8, ptr %259, i64 %263
  %private.contiguous.preserve215 = load <8 x float>, ptr %private.contiguous.address214, align 4
  %264 = select <8 x i1> %71, <8 x float> %.state213, <8 x float> %private.contiguous.preserve215
  store <8 x float> %264, ptr %private.contiguous.address214, align 4
  %.state216 = load i64, ptr %.slot43, align 4
  %265 = add i64 %.state216, 1
  store i64 %265, ptr %.slot43, align 4
  br label %direct.schedule.14

direct.schedule.18:                               ; preds = %direct.false197
  store i64 0, ptr %.slot46, align 4
  %266 = load <8 x float>, ptr %.slot47, align 32
  %267 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %266
  store <8 x float> %267, ptr %.slot47, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state217 = load i64, ptr %.slot46, align 4
  %268 = icmp slt i64 %.state217, 80
  br i1 %268, label %direct.true218, label %direct.false219

direct.schedule.20:                               ; preds = %direct.true218
  %.state220 = load i64, ptr %.slot46, align 4
  %269 = add i64 0, %.state220
  %tile_snapshot.spill.load221 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %270 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 0
  %271 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 1
  %.splatinsert222 = insertelement <8 x i64> poison, i64 %269, i64 0
  %.splat223 = shufflevector <8 x i64> %.splatinsert222, <8 x i64> poison, <8 x i32> zeroinitializer
  %272 = mul <8 x i64> %.splat223, splat (i64 32)
  %273 = add <8 x i64> %271, %272
  %274 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %270, 0
  %275 = insertvalue { <8 x ptr>, <8 x i64> } %274, <8 x i64> %273, 1
  %276 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %277 = extractvalue { <8 x ptr>, <8 x i64> } %275, 1
  %278 = extractelement <8 x ptr> %276, i32 0
  %279 = extractelement <8 x i64> %277, i32 0
  %280 = sub i64 %279, 0
  %281 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %282 = select i1 %281, i64 %280, i64 0
  %private.contiguous.address224 = getelementptr i8, ptr %278, i64 %282
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address224, align 4
  %283 = select <8 x i1> %71, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load225 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %284 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load225, 0
  %285 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load225, 1
  %.splatinsert226 = insertelement <8 x i64> poison, i64 %269, i64 0
  %.splat227 = shufflevector <8 x i64> %.splatinsert226, <8 x i64> poison, <8 x i32> zeroinitializer
  %286 = mul <8 x i64> %.splat227, splat (i64 32)
  %287 = add <8 x i64> %285, %286
  %288 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %284, 0
  %289 = insertvalue { <8 x ptr>, <8 x i64> } %288, <8 x i64> %287, 1
  %290 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %291 = extractvalue { <8 x ptr>, <8 x i64> } %289, 1
  %292 = extractelement <8 x ptr> %290, i32 0
  %293 = extractelement <8 x i64> %291, i32 0
  %294 = sub i64 %293, 0
  %295 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %296 = select i1 %295, i64 %294, i64 0
  %private.contiguous.address228 = getelementptr i8, ptr %292, i64 %296
  %private.contiguous.load229 = load <8 x float>, ptr %private.contiguous.address228, align 4
  %297 = select <8 x i1> %71, <8 x float> %private.contiguous.load229, <8 x float> zeroinitializer
  %298 = fmul <8 x float> %283, %297
  %.state230 = load <8 x float>, ptr %.slot47, align 32
  %299 = fadd <8 x float> %.state230, %298
  %.state231 = load i64, ptr %.slot46, align 4
  %300 = add i64 %.state231, 1
  store i64 %300, ptr %.slot46, align 4
  %301 = load <8 x float>, ptr %.slot47, align 32
  %302 = select <8 x i1> %71, <8 x float> %299, <8 x float> %301
  store <8 x float> %302, ptr %.slot47, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false219
  store i64 0, ptr %.slot48, align 4
  %303 = load <8 x float>, ptr %.slot49, align 32
  %304 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %303
  store <8 x float> %304, ptr %.slot49, align 32
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state232 = load i64, ptr %.slot48, align 4
  %305 = icmp slt i64 %.state232, 80
  br i1 %305, label %direct.true233, label %direct.false234

direct.schedule.23:                               ; preds = %direct.true233
  %.state235 = load i64, ptr %.slot48, align 4
  %306 = add i64 0, %.state235
  %tile_snapshot.spill.load236 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %307 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load236, 0
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load236, 1
  %.splatinsert237 = insertelement <8 x i64> poison, i64 %306, i64 0
  %.splat238 = shufflevector <8 x i64> %.splatinsert237, <8 x i64> poison, <8 x i32> zeroinitializer
  %309 = mul <8 x i64> %.splat238, splat (i64 32)
  %310 = add <8 x i64> %308, %309
  %311 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %307, 0
  %312 = insertvalue { <8 x ptr>, <8 x i64> } %311, <8 x i64> %310, 1
  %313 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %312, 1
  %315 = extractelement <8 x ptr> %313, i32 0
  %316 = extractelement <8 x i64> %314, i32 0
  %317 = sub i64 %316, 0
  %318 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %319 = select i1 %318, i64 %317, i64 0
  %private.contiguous.address239 = getelementptr i8, ptr %315, i64 %319
  %private.contiguous.load240 = load <8 x float>, ptr %private.contiguous.address239, align 4
  %320 = select <8 x i1> %71, <8 x float> %private.contiguous.load240, <8 x float> zeroinitializer
  %.state241 = load i64, ptr %.slot48, align 4
  %321 = add i64 80, %.state241
  %tile_snapshot.spill.load242 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load242, 0
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load242, 1
  %.splatinsert243 = insertelement <8 x i64> poison, i64 %321, i64 0
  %.splat244 = shufflevector <8 x i64> %.splatinsert243, <8 x i64> poison, <8 x i32> zeroinitializer
  %324 = mul <8 x i64> %.splat244, splat (i64 32)
  %325 = add <8 x i64> %323, %324
  %326 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %322, 0
  %327 = insertvalue { <8 x ptr>, <8 x i64> } %326, <8 x i64> %325, 1
  %328 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %327, 1
  %330 = extractelement <8 x ptr> %328, i32 0
  %331 = extractelement <8 x i64> %329, i32 0
  %332 = sub i64 %331, 0
  %333 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %334 = select i1 %333, i64 %332, i64 0
  %private.contiguous.address245 = getelementptr i8, ptr %330, i64 %334
  %private.contiguous.load246 = load <8 x float>, ptr %private.contiguous.address245, align 4
  %335 = select <8 x i1> %71, <8 x float> %private.contiguous.load246, <8 x float> zeroinitializer
  %336 = fmul <8 x float> %320, %335
  %.state247 = load <8 x float>, ptr %.slot49, align 32
  %337 = fadd <8 x float> %.state247, %336
  %.state248 = load i64, ptr %.slot48, align 4
  %338 = add i64 %.state248, 1
  store i64 %338, ptr %.slot48, align 4
  %339 = load <8 x float>, ptr %.slot49, align 32
  %340 = select <8 x i1> %71, <8 x float> %337, <8 x float> %339
  store <8 x float> %340, ptr %.slot49, align 32
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false234
  store i64 0, ptr %.slot50, align 4
  %341 = load <8 x float>, ptr %.slot51, align 32
  %342 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %341
  store <8 x float> %342, ptr %.slot51, align 32
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.26, %direct.schedule.24
  %.state249 = load i64, ptr %.slot50, align 4
  %343 = icmp slt i64 %.state249, 80
  br i1 %343, label %direct.true250, label %direct.false251

direct.schedule.26:                               ; preds = %direct.true250
  %.state252 = load i64, ptr %.slot50, align 4
  %344 = add i64 0, %.state252
  %tile_snapshot.spill.load253 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %345 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load253, 0
  %346 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load253, 1
  %.splatinsert254 = insertelement <8 x i64> poison, i64 %344, i64 0
  %.splat255 = shufflevector <8 x i64> %.splatinsert254, <8 x i64> poison, <8 x i32> zeroinitializer
  %347 = mul <8 x i64> %.splat255, splat (i64 32)
  %348 = add <8 x i64> %346, %347
  %349 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %345, 0
  %350 = insertvalue { <8 x ptr>, <8 x i64> } %349, <8 x i64> %348, 1
  %351 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %352 = extractvalue { <8 x ptr>, <8 x i64> } %350, 1
  %353 = extractelement <8 x ptr> %351, i32 0
  %354 = extractelement <8 x i64> %352, i32 0
  %355 = sub i64 %354, 0
  %356 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %357 = select i1 %356, i64 %355, i64 0
  %private.contiguous.address256 = getelementptr i8, ptr %353, i64 %357
  %private.contiguous.load257 = load <8 x float>, ptr %private.contiguous.address256, align 4
  %358 = select <8 x i1> %71, <8 x float> %private.contiguous.load257, <8 x float> zeroinitializer
  %.state258 = load i64, ptr %.slot50, align 4
  %359 = add i64 160, %.state258
  %tile_snapshot.spill.load259 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %360 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load259, 0
  %361 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load259, 1
  %.splatinsert260 = insertelement <8 x i64> poison, i64 %359, i64 0
  %.splat261 = shufflevector <8 x i64> %.splatinsert260, <8 x i64> poison, <8 x i32> zeroinitializer
  %362 = mul <8 x i64> %.splat261, splat (i64 32)
  %363 = add <8 x i64> %361, %362
  %364 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %360, 0
  %365 = insertvalue { <8 x ptr>, <8 x i64> } %364, <8 x i64> %363, 1
  %366 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %367 = extractvalue { <8 x ptr>, <8 x i64> } %365, 1
  %368 = extractelement <8 x ptr> %366, i32 0
  %369 = extractelement <8 x i64> %367, i32 0
  %370 = sub i64 %369, 0
  %371 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %372 = select i1 %371, i64 %370, i64 0
  %private.contiguous.address262 = getelementptr i8, ptr %368, i64 %372
  %private.contiguous.load263 = load <8 x float>, ptr %private.contiguous.address262, align 4
  %373 = select <8 x i1> %71, <8 x float> %private.contiguous.load263, <8 x float> zeroinitializer
  %374 = fmul <8 x float> %358, %373
  %.state264 = load <8 x float>, ptr %.slot51, align 32
  %375 = fadd <8 x float> %.state264, %374
  %.state265 = load i64, ptr %.slot50, align 4
  %376 = add i64 %.state265, 1
  store i64 %376, ptr %.slot50, align 4
  %377 = load <8 x float>, ptr %.slot51, align 32
  %378 = select <8 x i1> %71, <8 x float> %375, <8 x float> %377
  store <8 x float> %378, ptr %.slot51, align 32
  br label %direct.schedule.25

direct.schedule.27:                               ; preds = %direct.false251
  store i64 0, ptr %.slot52, align 4
  %379 = load <8 x float>, ptr %.slot53, align 32
  %380 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %379
  store <8 x float> %380, ptr %.slot53, align 32
  br label %direct.schedule.28

direct.schedule.28:                               ; preds = %direct.schedule.29, %direct.schedule.27
  %.state266 = load i64, ptr %.slot52, align 4
  %381 = icmp slt i64 %.state266, 80
  br i1 %381, label %direct.true267, label %direct.false268

direct.schedule.29:                               ; preds = %direct.true267
  %.state269 = load i64, ptr %.slot52, align 4
  %382 = add i64 0, %.state269
  %tile_snapshot.spill.load270 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %383 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 0
  %384 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 1
  %.splatinsert271 = insertelement <8 x i64> poison, i64 %382, i64 0
  %.splat272 = shufflevector <8 x i64> %.splatinsert271, <8 x i64> poison, <8 x i32> zeroinitializer
  %385 = mul <8 x i64> %.splat272, splat (i64 32)
  %386 = add <8 x i64> %384, %385
  %387 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %383, 0
  %388 = insertvalue { <8 x ptr>, <8 x i64> } %387, <8 x i64> %386, 1
  %389 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %390 = extractvalue { <8 x ptr>, <8 x i64> } %388, 1
  %391 = extractelement <8 x ptr> %389, i32 0
  %392 = extractelement <8 x i64> %390, i32 0
  %393 = sub i64 %392, 0
  %394 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %395 = select i1 %394, i64 %393, i64 0
  %private.contiguous.address273 = getelementptr i8, ptr %391, i64 %395
  %private.contiguous.load274 = load <8 x float>, ptr %private.contiguous.address273, align 4
  %396 = select <8 x i1> %71, <8 x float> %private.contiguous.load274, <8 x float> zeroinitializer
  %.state275 = load i64, ptr %.slot52, align 4
  %397 = add i64 240, %.state275
  %tile_snapshot.spill.load276 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %398 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load276, 0
  %399 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load276, 1
  %.splatinsert277 = insertelement <8 x i64> poison, i64 %397, i64 0
  %.splat278 = shufflevector <8 x i64> %.splatinsert277, <8 x i64> poison, <8 x i32> zeroinitializer
  %400 = mul <8 x i64> %.splat278, splat (i64 32)
  %401 = add <8 x i64> %399, %400
  %402 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %398, 0
  %403 = insertvalue { <8 x ptr>, <8 x i64> } %402, <8 x i64> %401, 1
  %404 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %405 = extractvalue { <8 x ptr>, <8 x i64> } %403, 1
  %406 = extractelement <8 x ptr> %404, i32 0
  %407 = extractelement <8 x i64> %405, i32 0
  %408 = sub i64 %407, 0
  %409 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %410 = select i1 %409, i64 %408, i64 0
  %private.contiguous.address279 = getelementptr i8, ptr %406, i64 %410
  %private.contiguous.load280 = load <8 x float>, ptr %private.contiguous.address279, align 4
  %411 = select <8 x i1> %71, <8 x float> %private.contiguous.load280, <8 x float> zeroinitializer
  %412 = fmul <8 x float> %396, %411
  %.state281 = load <8 x float>, ptr %.slot53, align 32
  %413 = fadd <8 x float> %.state281, %412
  %.state282 = load i64, ptr %.slot52, align 4
  %414 = add i64 %.state282, 1
  store i64 %414, ptr %.slot52, align 4
  %415 = load <8 x float>, ptr %.slot53, align 32
  %416 = select <8 x i1> %71, <8 x float> %413, <8 x float> %415
  store <8 x float> %416, ptr %.slot53, align 32
  br label %direct.schedule.28

direct.schedule.30:                               ; preds = %direct.false268
  store i64 0, ptr %.slot54, align 4
  %417 = load <8 x float>, ptr %.slot55, align 32
  %418 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %417
  store <8 x float> %418, ptr %.slot55, align 32
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.32, %direct.schedule.30
  %.state283 = load i64, ptr %.slot54, align 4
  %419 = icmp slt i64 %.state283, 80
  br i1 %419, label %direct.true284, label %direct.false285

direct.schedule.32:                               ; preds = %direct.true284
  %.state286 = load i64, ptr %.slot54, align 4
  %420 = add i64 0, %.state286
  %tile_snapshot.spill.load287 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %421 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load287, 0
  %422 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load287, 1
  %.splatinsert288 = insertelement <8 x i64> poison, i64 %420, i64 0
  %.splat289 = shufflevector <8 x i64> %.splatinsert288, <8 x i64> poison, <8 x i32> zeroinitializer
  %423 = mul <8 x i64> %.splat289, splat (i64 32)
  %424 = add <8 x i64> %422, %423
  %425 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %421, 0
  %426 = insertvalue { <8 x ptr>, <8 x i64> } %425, <8 x i64> %424, 1
  %427 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %428 = extractvalue { <8 x ptr>, <8 x i64> } %426, 1
  %429 = extractelement <8 x ptr> %427, i32 0
  %430 = extractelement <8 x i64> %428, i32 0
  %431 = sub i64 %430, 0
  %432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %433 = select i1 %432, i64 %431, i64 0
  %private.contiguous.address290 = getelementptr i8, ptr %429, i64 %433
  %private.contiguous.load291 = load <8 x float>, ptr %private.contiguous.address290, align 4
  %434 = select <8 x i1> %71, <8 x float> %private.contiguous.load291, <8 x float> zeroinitializer
  %.state292 = load i64, ptr %.slot54, align 4
  %435 = add i64 320, %.state292
  %tile_snapshot.spill.load293 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %436 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load293, 0
  %437 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load293, 1
  %.splatinsert294 = insertelement <8 x i64> poison, i64 %435, i64 0
  %.splat295 = shufflevector <8 x i64> %.splatinsert294, <8 x i64> poison, <8 x i32> zeroinitializer
  %438 = mul <8 x i64> %.splat295, splat (i64 32)
  %439 = add <8 x i64> %437, %438
  %440 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %436, 0
  %441 = insertvalue { <8 x ptr>, <8 x i64> } %440, <8 x i64> %439, 1
  %442 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %443 = extractvalue { <8 x ptr>, <8 x i64> } %441, 1
  %444 = extractelement <8 x ptr> %442, i32 0
  %445 = extractelement <8 x i64> %443, i32 0
  %446 = sub i64 %445, 0
  %447 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %448 = select i1 %447, i64 %446, i64 0
  %private.contiguous.address296 = getelementptr i8, ptr %444, i64 %448
  %private.contiguous.load297 = load <8 x float>, ptr %private.contiguous.address296, align 4
  %449 = select <8 x i1> %71, <8 x float> %private.contiguous.load297, <8 x float> zeroinitializer
  %450 = fmul <8 x float> %434, %449
  %.state298 = load <8 x float>, ptr %.slot55, align 32
  %451 = fadd <8 x float> %.state298, %450
  %.state299 = load i64, ptr %.slot54, align 4
  %452 = add i64 %.state299, 1
  store i64 %452, ptr %.slot54, align 4
  %453 = load <8 x float>, ptr %.slot55, align 32
  %454 = select <8 x i1> %71, <8 x float> %451, <8 x float> %453
  store <8 x float> %454, ptr %.slot55, align 32
  br label %direct.schedule.31

direct.schedule.33:                               ; preds = %direct.false285
  store i64 0, ptr %.slot56, align 4
  %455 = load <8 x float>, ptr %.slot57, align 32
  %456 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %455
  store <8 x float> %456, ptr %.slot57, align 32
  br label %direct.schedule.34

direct.schedule.34:                               ; preds = %direct.schedule.35, %direct.schedule.33
  %.state300 = load i64, ptr %.slot56, align 4
  %457 = icmp slt i64 %.state300, 80
  br i1 %457, label %direct.true301, label %direct.false302

direct.schedule.35:                               ; preds = %direct.true301
  %.state303 = load i64, ptr %.slot56, align 4
  %458 = add i64 0, %.state303
  %tile_snapshot.spill.load304 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %459 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load304, 0
  %460 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load304, 1
  %.splatinsert305 = insertelement <8 x i64> poison, i64 %458, i64 0
  %.splat306 = shufflevector <8 x i64> %.splatinsert305, <8 x i64> poison, <8 x i32> zeroinitializer
  %461 = mul <8 x i64> %.splat306, splat (i64 32)
  %462 = add <8 x i64> %460, %461
  %463 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %459, 0
  %464 = insertvalue { <8 x ptr>, <8 x i64> } %463, <8 x i64> %462, 1
  %465 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %466 = extractvalue { <8 x ptr>, <8 x i64> } %464, 1
  %467 = extractelement <8 x ptr> %465, i32 0
  %468 = extractelement <8 x i64> %466, i32 0
  %469 = sub i64 %468, 0
  %470 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %471 = select i1 %470, i64 %469, i64 0
  %private.contiguous.address307 = getelementptr i8, ptr %467, i64 %471
  %private.contiguous.load308 = load <8 x float>, ptr %private.contiguous.address307, align 4
  %472 = select <8 x i1> %71, <8 x float> %private.contiguous.load308, <8 x float> zeroinitializer
  %.state309 = load i64, ptr %.slot56, align 4
  %473 = add i64 400, %.state309
  %tile_snapshot.spill.load310 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %474 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load310, 0
  %475 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load310, 1
  %.splatinsert311 = insertelement <8 x i64> poison, i64 %473, i64 0
  %.splat312 = shufflevector <8 x i64> %.splatinsert311, <8 x i64> poison, <8 x i32> zeroinitializer
  %476 = mul <8 x i64> %.splat312, splat (i64 32)
  %477 = add <8 x i64> %475, %476
  %478 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %474, 0
  %479 = insertvalue { <8 x ptr>, <8 x i64> } %478, <8 x i64> %477, 1
  %480 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %481 = extractvalue { <8 x ptr>, <8 x i64> } %479, 1
  %482 = extractelement <8 x ptr> %480, i32 0
  %483 = extractelement <8 x i64> %481, i32 0
  %484 = sub i64 %483, 0
  %485 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %486 = select i1 %485, i64 %484, i64 0
  %private.contiguous.address313 = getelementptr i8, ptr %482, i64 %486
  %private.contiguous.load314 = load <8 x float>, ptr %private.contiguous.address313, align 4
  %487 = select <8 x i1> %71, <8 x float> %private.contiguous.load314, <8 x float> zeroinitializer
  %488 = fmul <8 x float> %472, %487
  %.state315 = load <8 x float>, ptr %.slot57, align 32
  %489 = fadd <8 x float> %.state315, %488
  %.state316 = load i64, ptr %.slot56, align 4
  %490 = add i64 %.state316, 1
  store i64 %490, ptr %.slot56, align 4
  %491 = load <8 x float>, ptr %.slot57, align 32
  %492 = select <8 x i1> %71, <8 x float> %489, <8 x float> %491
  store <8 x float> %492, ptr %.slot57, align 32
  br label %direct.schedule.34

direct.schedule.36:                               ; preds = %direct.false302
  store i64 0, ptr %.slot58, align 4
  %493 = load <8 x float>, ptr %.slot59, align 32
  %494 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %493
  store <8 x float> %494, ptr %.slot59, align 32
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.38, %direct.schedule.36
  %.state317 = load i64, ptr %.slot58, align 4
  %495 = icmp slt i64 %.state317, 80
  br i1 %495, label %direct.true318, label %direct.false319

direct.schedule.38:                               ; preds = %direct.true318
  %.state320 = load i64, ptr %.slot58, align 4
  %496 = add i64 0, %.state320
  %tile_snapshot.spill.load321 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %497 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load321, 0
  %498 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load321, 1
  %.splatinsert322 = insertelement <8 x i64> poison, i64 %496, i64 0
  %.splat323 = shufflevector <8 x i64> %.splatinsert322, <8 x i64> poison, <8 x i32> zeroinitializer
  %499 = mul <8 x i64> %.splat323, splat (i64 32)
  %500 = add <8 x i64> %498, %499
  %501 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %497, 0
  %502 = insertvalue { <8 x ptr>, <8 x i64> } %501, <8 x i64> %500, 1
  %503 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %504 = extractvalue { <8 x ptr>, <8 x i64> } %502, 1
  %505 = extractelement <8 x ptr> %503, i32 0
  %506 = extractelement <8 x i64> %504, i32 0
  %507 = sub i64 %506, 0
  %508 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %509 = select i1 %508, i64 %507, i64 0
  %private.contiguous.address324 = getelementptr i8, ptr %505, i64 %509
  %private.contiguous.load325 = load <8 x float>, ptr %private.contiguous.address324, align 4
  %510 = select <8 x i1> %71, <8 x float> %private.contiguous.load325, <8 x float> zeroinitializer
  %.state326 = load i64, ptr %.slot58, align 4
  %511 = add i64 480, %.state326
  %tile_snapshot.spill.load327 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %512 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load327, 0
  %513 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load327, 1
  %.splatinsert328 = insertelement <8 x i64> poison, i64 %511, i64 0
  %.splat329 = shufflevector <8 x i64> %.splatinsert328, <8 x i64> poison, <8 x i32> zeroinitializer
  %514 = mul <8 x i64> %.splat329, splat (i64 32)
  %515 = add <8 x i64> %513, %514
  %516 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %512, 0
  %517 = insertvalue { <8 x ptr>, <8 x i64> } %516, <8 x i64> %515, 1
  %518 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %519 = extractvalue { <8 x ptr>, <8 x i64> } %517, 1
  %520 = extractelement <8 x ptr> %518, i32 0
  %521 = extractelement <8 x i64> %519, i32 0
  %522 = sub i64 %521, 0
  %523 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %524 = select i1 %523, i64 %522, i64 0
  %private.contiguous.address330 = getelementptr i8, ptr %520, i64 %524
  %private.contiguous.load331 = load <8 x float>, ptr %private.contiguous.address330, align 4
  %525 = select <8 x i1> %71, <8 x float> %private.contiguous.load331, <8 x float> zeroinitializer
  %526 = fmul <8 x float> %510, %525
  %.state332 = load <8 x float>, ptr %.slot59, align 32
  %527 = fadd <8 x float> %.state332, %526
  %.state333 = load i64, ptr %.slot58, align 4
  %528 = add i64 %.state333, 1
  store i64 %528, ptr %.slot58, align 4
  %529 = load <8 x float>, ptr %.slot59, align 32
  %530 = select <8 x i1> %71, <8 x float> %527, <8 x float> %529
  store <8 x float> %530, ptr %.slot59, align 32
  br label %direct.schedule.37

direct.schedule.39:                               ; preds = %direct.false319
  store i64 0, ptr %.slot60, align 4
  %531 = load <8 x float>, ptr %.slot61, align 32
  %532 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %531
  store <8 x float> %532, ptr %.slot61, align 32
  br label %direct.schedule.40

direct.schedule.40:                               ; preds = %direct.schedule.41, %direct.schedule.39
  %.state334 = load i64, ptr %.slot60, align 4
  %533 = icmp slt i64 %.state334, 80
  br i1 %533, label %direct.true335, label %direct.false336

direct.schedule.41:                               ; preds = %direct.true335
  %.state337 = load i64, ptr %.slot60, align 4
  %534 = add i64 0, %.state337
  %tile_snapshot.spill.load338 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %535 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load338, 0
  %536 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load338, 1
  %.splatinsert339 = insertelement <8 x i64> poison, i64 %534, i64 0
  %.splat340 = shufflevector <8 x i64> %.splatinsert339, <8 x i64> poison, <8 x i32> zeroinitializer
  %537 = mul <8 x i64> %.splat340, splat (i64 32)
  %538 = add <8 x i64> %536, %537
  %539 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %535, 0
  %540 = insertvalue { <8 x ptr>, <8 x i64> } %539, <8 x i64> %538, 1
  %541 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %542 = extractvalue { <8 x ptr>, <8 x i64> } %540, 1
  %543 = extractelement <8 x ptr> %541, i32 0
  %544 = extractelement <8 x i64> %542, i32 0
  %545 = sub i64 %544, 0
  %546 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %547 = select i1 %546, i64 %545, i64 0
  %private.contiguous.address341 = getelementptr i8, ptr %543, i64 %547
  %private.contiguous.load342 = load <8 x float>, ptr %private.contiguous.address341, align 4
  %548 = select <8 x i1> %71, <8 x float> %private.contiguous.load342, <8 x float> zeroinitializer
  %.state343 = load i64, ptr %.slot60, align 4
  %549 = add i64 560, %.state343
  %tile_snapshot.spill.load344 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %550 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load344, 0
  %551 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load344, 1
  %.splatinsert345 = insertelement <8 x i64> poison, i64 %549, i64 0
  %.splat346 = shufflevector <8 x i64> %.splatinsert345, <8 x i64> poison, <8 x i32> zeroinitializer
  %552 = mul <8 x i64> %.splat346, splat (i64 32)
  %553 = add <8 x i64> %551, %552
  %554 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %550, 0
  %555 = insertvalue { <8 x ptr>, <8 x i64> } %554, <8 x i64> %553, 1
  %556 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %557 = extractvalue { <8 x ptr>, <8 x i64> } %555, 1
  %558 = extractelement <8 x ptr> %556, i32 0
  %559 = extractelement <8 x i64> %557, i32 0
  %560 = sub i64 %559, 0
  %561 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %562 = select i1 %561, i64 %560, i64 0
  %private.contiguous.address347 = getelementptr i8, ptr %558, i64 %562
  %private.contiguous.load348 = load <8 x float>, ptr %private.contiguous.address347, align 4
  %563 = select <8 x i1> %71, <8 x float> %private.contiguous.load348, <8 x float> zeroinitializer
  %564 = fmul <8 x float> %548, %563
  %.state349 = load <8 x float>, ptr %.slot61, align 32
  %565 = fadd <8 x float> %.state349, %564
  %.state350 = load i64, ptr %.slot60, align 4
  %566 = add i64 %.state350, 1
  store i64 %566, ptr %.slot60, align 4
  %567 = load <8 x float>, ptr %.slot61, align 32
  %568 = select <8 x i1> %71, <8 x float> %565, <8 x float> %567
  store <8 x float> %568, ptr %.slot61, align 32
  br label %direct.schedule.40

direct.schedule.42:                               ; preds = %direct.false336
  store i64 0, ptr %.slot62, align 4
  %569 = load <8 x float>, ptr %.slot63, align 32
  %570 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %569
  store <8 x float> %570, ptr %.slot63, align 32
  br label %direct.schedule.43

direct.schedule.43:                               ; preds = %direct.schedule.44, %direct.schedule.42
  %.state351 = load i64, ptr %.slot62, align 4
  %571 = icmp slt i64 %.state351, 80
  br i1 %571, label %direct.true352, label %direct.false353

direct.schedule.44:                               ; preds = %direct.true352
  %.state354 = load i64, ptr %.slot62, align 4
  %572 = add i64 0, %.state354
  %tile_snapshot.spill.load355 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %573 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load355, 0
  %574 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load355, 1
  %.splatinsert356 = insertelement <8 x i64> poison, i64 %572, i64 0
  %.splat357 = shufflevector <8 x i64> %.splatinsert356, <8 x i64> poison, <8 x i32> zeroinitializer
  %575 = mul <8 x i64> %.splat357, splat (i64 32)
  %576 = add <8 x i64> %574, %575
  %577 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %573, 0
  %578 = insertvalue { <8 x ptr>, <8 x i64> } %577, <8 x i64> %576, 1
  %579 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %580 = extractvalue { <8 x ptr>, <8 x i64> } %578, 1
  %581 = extractelement <8 x ptr> %579, i32 0
  %582 = extractelement <8 x i64> %580, i32 0
  %583 = sub i64 %582, 0
  %584 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %585 = select i1 %584, i64 %583, i64 0
  %private.contiguous.address358 = getelementptr i8, ptr %581, i64 %585
  %private.contiguous.load359 = load <8 x float>, ptr %private.contiguous.address358, align 4
  %586 = select <8 x i1> %71, <8 x float> %private.contiguous.load359, <8 x float> zeroinitializer
  %.state360 = load i64, ptr %.slot62, align 4
  %587 = add i64 640, %.state360
  %tile_snapshot.spill.load361 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %588 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load361, 0
  %589 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load361, 1
  %.splatinsert362 = insertelement <8 x i64> poison, i64 %587, i64 0
  %.splat363 = shufflevector <8 x i64> %.splatinsert362, <8 x i64> poison, <8 x i32> zeroinitializer
  %590 = mul <8 x i64> %.splat363, splat (i64 32)
  %591 = add <8 x i64> %589, %590
  %592 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %588, 0
  %593 = insertvalue { <8 x ptr>, <8 x i64> } %592, <8 x i64> %591, 1
  %594 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %595 = extractvalue { <8 x ptr>, <8 x i64> } %593, 1
  %596 = extractelement <8 x ptr> %594, i32 0
  %597 = extractelement <8 x i64> %595, i32 0
  %598 = sub i64 %597, 0
  %599 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %600 = select i1 %599, i64 %598, i64 0
  %private.contiguous.address364 = getelementptr i8, ptr %596, i64 %600
  %private.contiguous.load365 = load <8 x float>, ptr %private.contiguous.address364, align 4
  %601 = select <8 x i1> %71, <8 x float> %private.contiguous.load365, <8 x float> zeroinitializer
  %602 = fmul <8 x float> %586, %601
  %.state366 = load <8 x float>, ptr %.slot63, align 32
  %603 = fadd <8 x float> %.state366, %602
  %.state367 = load i64, ptr %.slot62, align 4
  %604 = add i64 %.state367, 1
  store i64 %604, ptr %.slot62, align 4
  %605 = load <8 x float>, ptr %.slot63, align 32
  %606 = select <8 x i1> %71, <8 x float> %603, <8 x float> %605
  store <8 x float> %606, ptr %.slot63, align 32
  br label %direct.schedule.43

direct.schedule.45:                               ; preds = %direct.false353
  store i64 0, ptr %.slot64, align 4
  %607 = load <8 x float>, ptr %.slot65, align 32
  %608 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %607
  store <8 x float> %608, ptr %.slot65, align 32
  br label %direct.schedule.46

direct.schedule.46:                               ; preds = %direct.schedule.47, %direct.schedule.45
  %.state368 = load i64, ptr %.slot64, align 4
  %609 = icmp slt i64 %.state368, 80
  br i1 %609, label %direct.true369, label %direct.false370

direct.schedule.47:                               ; preds = %direct.true369
  %.state371 = load i64, ptr %.slot64, align 4
  %610 = add i64 0, %.state371
  %tile_snapshot.spill.load372 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %611 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load372, 0
  %612 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load372, 1
  %.splatinsert373 = insertelement <8 x i64> poison, i64 %610, i64 0
  %.splat374 = shufflevector <8 x i64> %.splatinsert373, <8 x i64> poison, <8 x i32> zeroinitializer
  %613 = mul <8 x i64> %.splat374, splat (i64 32)
  %614 = add <8 x i64> %612, %613
  %615 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %611, 0
  %616 = insertvalue { <8 x ptr>, <8 x i64> } %615, <8 x i64> %614, 1
  %617 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %618 = extractvalue { <8 x ptr>, <8 x i64> } %616, 1
  %619 = extractelement <8 x ptr> %617, i32 0
  %620 = extractelement <8 x i64> %618, i32 0
  %621 = sub i64 %620, 0
  %622 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %623 = select i1 %622, i64 %621, i64 0
  %private.contiguous.address375 = getelementptr i8, ptr %619, i64 %623
  %private.contiguous.load376 = load <8 x float>, ptr %private.contiguous.address375, align 4
  %624 = select <8 x i1> %71, <8 x float> %private.contiguous.load376, <8 x float> zeroinitializer
  %.state377 = load i64, ptr %.slot64, align 4
  %625 = add i64 720, %.state377
  %tile_snapshot.spill.load378 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %626 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load378, 0
  %627 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load378, 1
  %.splatinsert379 = insertelement <8 x i64> poison, i64 %625, i64 0
  %.splat380 = shufflevector <8 x i64> %.splatinsert379, <8 x i64> poison, <8 x i32> zeroinitializer
  %628 = mul <8 x i64> %.splat380, splat (i64 32)
  %629 = add <8 x i64> %627, %628
  %630 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %626, 0
  %631 = insertvalue { <8 x ptr>, <8 x i64> } %630, <8 x i64> %629, 1
  %632 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %633 = extractvalue { <8 x ptr>, <8 x i64> } %631, 1
  %634 = extractelement <8 x ptr> %632, i32 0
  %635 = extractelement <8 x i64> %633, i32 0
  %636 = sub i64 %635, 0
  %637 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %638 = select i1 %637, i64 %636, i64 0
  %private.contiguous.address381 = getelementptr i8, ptr %634, i64 %638
  %private.contiguous.load382 = load <8 x float>, ptr %private.contiguous.address381, align 4
  %639 = select <8 x i1> %71, <8 x float> %private.contiguous.load382, <8 x float> zeroinitializer
  %640 = fmul <8 x float> %624, %639
  %.state383 = load <8 x float>, ptr %.slot65, align 32
  %641 = fadd <8 x float> %.state383, %640
  %.state384 = load i64, ptr %.slot64, align 4
  %642 = add i64 %.state384, 1
  store i64 %642, ptr %.slot64, align 4
  %643 = load <8 x float>, ptr %.slot65, align 32
  %644 = select <8 x i1> %71, <8 x float> %641, <8 x float> %643
  store <8 x float> %644, ptr %.slot65, align 32
  br label %direct.schedule.46

direct.schedule.48:                               ; preds = %direct.false370
  store i64 0, ptr %.slot66, align 4
  %645 = load <8 x float>, ptr %.slot67, align 32
  %646 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %645
  store <8 x float> %646, ptr %.slot67, align 32
  br label %direct.schedule.49

direct.schedule.49:                               ; preds = %direct.schedule.50, %direct.schedule.48
  %.state385 = load i64, ptr %.slot66, align 4
  %647 = icmp slt i64 %.state385, 80
  br i1 %647, label %direct.true386, label %direct.false387

direct.schedule.50:                               ; preds = %direct.true386
  %.state388 = load i64, ptr %.slot66, align 4
  %648 = add i64 0, %.state388
  %tile_snapshot.spill.load389 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %649 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load389, 0
  %650 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load389, 1
  %.splatinsert390 = insertelement <8 x i64> poison, i64 %648, i64 0
  %.splat391 = shufflevector <8 x i64> %.splatinsert390, <8 x i64> poison, <8 x i32> zeroinitializer
  %651 = mul <8 x i64> %.splat391, splat (i64 32)
  %652 = add <8 x i64> %650, %651
  %653 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %649, 0
  %654 = insertvalue { <8 x ptr>, <8 x i64> } %653, <8 x i64> %652, 1
  %655 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %656 = extractvalue { <8 x ptr>, <8 x i64> } %654, 1
  %657 = extractelement <8 x ptr> %655, i32 0
  %658 = extractelement <8 x i64> %656, i32 0
  %659 = sub i64 %658, 0
  %660 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %661 = select i1 %660, i64 %659, i64 0
  %private.contiguous.address392 = getelementptr i8, ptr %657, i64 %661
  %private.contiguous.load393 = load <8 x float>, ptr %private.contiguous.address392, align 4
  %662 = select <8 x i1> %71, <8 x float> %private.contiguous.load393, <8 x float> zeroinitializer
  %.state394 = load i64, ptr %.slot66, align 4
  %663 = add i64 800, %.state394
  %tile_snapshot.spill.load395 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %664 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load395, 0
  %665 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load395, 1
  %.splatinsert396 = insertelement <8 x i64> poison, i64 %663, i64 0
  %.splat397 = shufflevector <8 x i64> %.splatinsert396, <8 x i64> poison, <8 x i32> zeroinitializer
  %666 = mul <8 x i64> %.splat397, splat (i64 32)
  %667 = add <8 x i64> %665, %666
  %668 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %664, 0
  %669 = insertvalue { <8 x ptr>, <8 x i64> } %668, <8 x i64> %667, 1
  %670 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %671 = extractvalue { <8 x ptr>, <8 x i64> } %669, 1
  %672 = extractelement <8 x ptr> %670, i32 0
  %673 = extractelement <8 x i64> %671, i32 0
  %674 = sub i64 %673, 0
  %675 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %676 = select i1 %675, i64 %674, i64 0
  %private.contiguous.address398 = getelementptr i8, ptr %672, i64 %676
  %private.contiguous.load399 = load <8 x float>, ptr %private.contiguous.address398, align 4
  %677 = select <8 x i1> %71, <8 x float> %private.contiguous.load399, <8 x float> zeroinitializer
  %678 = fmul <8 x float> %662, %677
  %.state400 = load <8 x float>, ptr %.slot67, align 32
  %679 = fadd <8 x float> %.state400, %678
  %.state401 = load i64, ptr %.slot66, align 4
  %680 = add i64 %.state401, 1
  store i64 %680, ptr %.slot66, align 4
  %681 = load <8 x float>, ptr %.slot67, align 32
  %682 = select <8 x i1> %71, <8 x float> %679, <8 x float> %681
  store <8 x float> %682, ptr %.slot67, align 32
  br label %direct.schedule.49

direct.schedule.51:                               ; preds = %direct.false387
  store i64 0, ptr %.slot68, align 4
  %683 = load <8 x float>, ptr %.slot69, align 32
  %684 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %683
  store <8 x float> %684, ptr %.slot69, align 32
  br label %direct.schedule.52

direct.schedule.52:                               ; preds = %direct.schedule.53, %direct.schedule.51
  %.state402 = load i64, ptr %.slot68, align 4
  %685 = icmp slt i64 %.state402, 80
  br i1 %685, label %direct.true403, label %direct.false404

direct.schedule.53:                               ; preds = %direct.true403
  %.state405 = load i64, ptr %.slot68, align 4
  %686 = add i64 0, %.state405
  %tile_snapshot.spill.load406 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %687 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load406, 0
  %688 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load406, 1
  %.splatinsert407 = insertelement <8 x i64> poison, i64 %686, i64 0
  %.splat408 = shufflevector <8 x i64> %.splatinsert407, <8 x i64> poison, <8 x i32> zeroinitializer
  %689 = mul <8 x i64> %.splat408, splat (i64 32)
  %690 = add <8 x i64> %688, %689
  %691 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %687, 0
  %692 = insertvalue { <8 x ptr>, <8 x i64> } %691, <8 x i64> %690, 1
  %693 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %694 = extractvalue { <8 x ptr>, <8 x i64> } %692, 1
  %695 = extractelement <8 x ptr> %693, i32 0
  %696 = extractelement <8 x i64> %694, i32 0
  %697 = sub i64 %696, 0
  %698 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %699 = select i1 %698, i64 %697, i64 0
  %private.contiguous.address409 = getelementptr i8, ptr %695, i64 %699
  %private.contiguous.load410 = load <8 x float>, ptr %private.contiguous.address409, align 4
  %700 = select <8 x i1> %71, <8 x float> %private.contiguous.load410, <8 x float> zeroinitializer
  %.state411 = load i64, ptr %.slot68, align 4
  %701 = add i64 880, %.state411
  %tile_snapshot.spill.load412 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %702 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 0
  %703 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 1
  %.splatinsert413 = insertelement <8 x i64> poison, i64 %701, i64 0
  %.splat414 = shufflevector <8 x i64> %.splatinsert413, <8 x i64> poison, <8 x i32> zeroinitializer
  %704 = mul <8 x i64> %.splat414, splat (i64 32)
  %705 = add <8 x i64> %703, %704
  %706 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %702, 0
  %707 = insertvalue { <8 x ptr>, <8 x i64> } %706, <8 x i64> %705, 1
  %708 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %709 = extractvalue { <8 x ptr>, <8 x i64> } %707, 1
  %710 = extractelement <8 x ptr> %708, i32 0
  %711 = extractelement <8 x i64> %709, i32 0
  %712 = sub i64 %711, 0
  %713 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %714 = select i1 %713, i64 %712, i64 0
  %private.contiguous.address415 = getelementptr i8, ptr %710, i64 %714
  %private.contiguous.load416 = load <8 x float>, ptr %private.contiguous.address415, align 4
  %715 = select <8 x i1> %71, <8 x float> %private.contiguous.load416, <8 x float> zeroinitializer
  %716 = fmul <8 x float> %700, %715
  %.state417 = load <8 x float>, ptr %.slot69, align 32
  %717 = fadd <8 x float> %.state417, %716
  %.state418 = load i64, ptr %.slot68, align 4
  %718 = add i64 %.state418, 1
  store i64 %718, ptr %.slot68, align 4
  %719 = load <8 x float>, ptr %.slot69, align 32
  %720 = select <8 x i1> %71, <8 x float> %717, <8 x float> %719
  store <8 x float> %720, ptr %.slot69, align 32
  br label %direct.schedule.52

direct.schedule.54:                               ; preds = %direct.false404
  store i64 0, ptr %.slot70, align 4
  %721 = load <8 x float>, ptr %.slot71, align 32
  %722 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %721
  store <8 x float> %722, ptr %.slot71, align 32
  br label %direct.schedule.55

direct.schedule.55:                               ; preds = %direct.schedule.56, %direct.schedule.54
  %.state419 = load i64, ptr %.slot70, align 4
  %723 = icmp slt i64 %.state419, 80
  br i1 %723, label %direct.true420, label %direct.false421

direct.schedule.56:                               ; preds = %direct.true420
  %.state422 = load i64, ptr %.slot70, align 4
  %724 = add i64 0, %.state422
  %tile_snapshot.spill.load423 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %725 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load423, 0
  %726 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load423, 1
  %.splatinsert424 = insertelement <8 x i64> poison, i64 %724, i64 0
  %.splat425 = shufflevector <8 x i64> %.splatinsert424, <8 x i64> poison, <8 x i32> zeroinitializer
  %727 = mul <8 x i64> %.splat425, splat (i64 32)
  %728 = add <8 x i64> %726, %727
  %729 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %725, 0
  %730 = insertvalue { <8 x ptr>, <8 x i64> } %729, <8 x i64> %728, 1
  %731 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %732 = extractvalue { <8 x ptr>, <8 x i64> } %730, 1
  %733 = extractelement <8 x ptr> %731, i32 0
  %734 = extractelement <8 x i64> %732, i32 0
  %735 = sub i64 %734, 0
  %736 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %737 = select i1 %736, i64 %735, i64 0
  %private.contiguous.address426 = getelementptr i8, ptr %733, i64 %737
  %private.contiguous.load427 = load <8 x float>, ptr %private.contiguous.address426, align 4
  %738 = select <8 x i1> %71, <8 x float> %private.contiguous.load427, <8 x float> zeroinitializer
  %.state428 = load i64, ptr %.slot70, align 4
  %739 = add i64 960, %.state428
  %tile_snapshot.spill.load429 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %740 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load429, 0
  %741 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load429, 1
  %.splatinsert430 = insertelement <8 x i64> poison, i64 %739, i64 0
  %.splat431 = shufflevector <8 x i64> %.splatinsert430, <8 x i64> poison, <8 x i32> zeroinitializer
  %742 = mul <8 x i64> %.splat431, splat (i64 32)
  %743 = add <8 x i64> %741, %742
  %744 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %740, 0
  %745 = insertvalue { <8 x ptr>, <8 x i64> } %744, <8 x i64> %743, 1
  %746 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %747 = extractvalue { <8 x ptr>, <8 x i64> } %745, 1
  %748 = extractelement <8 x ptr> %746, i32 0
  %749 = extractelement <8 x i64> %747, i32 0
  %750 = sub i64 %749, 0
  %751 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %752 = select i1 %751, i64 %750, i64 0
  %private.contiguous.address432 = getelementptr i8, ptr %748, i64 %752
  %private.contiguous.load433 = load <8 x float>, ptr %private.contiguous.address432, align 4
  %753 = select <8 x i1> %71, <8 x float> %private.contiguous.load433, <8 x float> zeroinitializer
  %754 = fmul <8 x float> %738, %753
  %.state434 = load <8 x float>, ptr %.slot71, align 32
  %755 = fadd <8 x float> %.state434, %754
  %.state435 = load i64, ptr %.slot70, align 4
  %756 = add i64 %.state435, 1
  store i64 %756, ptr %.slot70, align 4
  %757 = load <8 x float>, ptr %.slot71, align 32
  %758 = select <8 x i1> %71, <8 x float> %755, <8 x float> %757
  store <8 x float> %758, ptr %.slot71, align 32
  br label %direct.schedule.55

direct.schedule.57:                               ; preds = %direct.false421
  store i64 0, ptr %.slot72, align 4
  %759 = load <8 x float>, ptr %.slot73, align 32
  %760 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %759
  store <8 x float> %760, ptr %.slot73, align 32
  br label %direct.schedule.58

direct.schedule.58:                               ; preds = %direct.schedule.59, %direct.schedule.57
  %.state436 = load i64, ptr %.slot72, align 4
  %761 = icmp slt i64 %.state436, 80
  br i1 %761, label %direct.true437, label %direct.false438

direct.schedule.59:                               ; preds = %direct.true437
  %.state439 = load i64, ptr %.slot72, align 4
  %762 = add i64 0, %.state439
  %tile_snapshot.spill.load440 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %763 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load440, 0
  %764 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load440, 1
  %.splatinsert441 = insertelement <8 x i64> poison, i64 %762, i64 0
  %.splat442 = shufflevector <8 x i64> %.splatinsert441, <8 x i64> poison, <8 x i32> zeroinitializer
  %765 = mul <8 x i64> %.splat442, splat (i64 32)
  %766 = add <8 x i64> %764, %765
  %767 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %763, 0
  %768 = insertvalue { <8 x ptr>, <8 x i64> } %767, <8 x i64> %766, 1
  %769 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %770 = extractvalue { <8 x ptr>, <8 x i64> } %768, 1
  %771 = extractelement <8 x ptr> %769, i32 0
  %772 = extractelement <8 x i64> %770, i32 0
  %773 = sub i64 %772, 0
  %774 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %775 = select i1 %774, i64 %773, i64 0
  %private.contiguous.address443 = getelementptr i8, ptr %771, i64 %775
  %private.contiguous.load444 = load <8 x float>, ptr %private.contiguous.address443, align 4
  %776 = select <8 x i1> %71, <8 x float> %private.contiguous.load444, <8 x float> zeroinitializer
  %.state445 = load i64, ptr %.slot72, align 4
  %777 = add i64 1040, %.state445
  %tile_snapshot.spill.load446 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %778 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load446, 0
  %779 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load446, 1
  %.splatinsert447 = insertelement <8 x i64> poison, i64 %777, i64 0
  %.splat448 = shufflevector <8 x i64> %.splatinsert447, <8 x i64> poison, <8 x i32> zeroinitializer
  %780 = mul <8 x i64> %.splat448, splat (i64 32)
  %781 = add <8 x i64> %779, %780
  %782 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %778, 0
  %783 = insertvalue { <8 x ptr>, <8 x i64> } %782, <8 x i64> %781, 1
  %784 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %785 = extractvalue { <8 x ptr>, <8 x i64> } %783, 1
  %786 = extractelement <8 x ptr> %784, i32 0
  %787 = extractelement <8 x i64> %785, i32 0
  %788 = sub i64 %787, 0
  %789 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %790 = select i1 %789, i64 %788, i64 0
  %private.contiguous.address449 = getelementptr i8, ptr %786, i64 %790
  %private.contiguous.load450 = load <8 x float>, ptr %private.contiguous.address449, align 4
  %791 = select <8 x i1> %71, <8 x float> %private.contiguous.load450, <8 x float> zeroinitializer
  %792 = fmul <8 x float> %776, %791
  %.state451 = load <8 x float>, ptr %.slot73, align 32
  %793 = fadd <8 x float> %.state451, %792
  %.state452 = load i64, ptr %.slot72, align 4
  %794 = add i64 %.state452, 1
  store i64 %794, ptr %.slot72, align 4
  %795 = load <8 x float>, ptr %.slot73, align 32
  %796 = select <8 x i1> %71, <8 x float> %793, <8 x float> %795
  store <8 x float> %796, ptr %.slot73, align 32
  br label %direct.schedule.58

direct.schedule.60:                               ; preds = %direct.false438
  store i64 0, ptr %.slot74, align 4
  %797 = load <8 x float>, ptr %.slot75, align 32
  %798 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %797
  store <8 x float> %798, ptr %.slot75, align 32
  br label %direct.schedule.61

direct.schedule.61:                               ; preds = %direct.schedule.62, %direct.schedule.60
  %.state453 = load i64, ptr %.slot74, align 4
  %799 = icmp slt i64 %.state453, 80
  br i1 %799, label %direct.true454, label %direct.false455

direct.schedule.62:                               ; preds = %direct.true454
  %.state456 = load i64, ptr %.slot74, align 4
  %800 = add i64 0, %.state456
  %tile_snapshot.spill.load457 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %801 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load457, 0
  %802 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load457, 1
  %.splatinsert458 = insertelement <8 x i64> poison, i64 %800, i64 0
  %.splat459 = shufflevector <8 x i64> %.splatinsert458, <8 x i64> poison, <8 x i32> zeroinitializer
  %803 = mul <8 x i64> %.splat459, splat (i64 32)
  %804 = add <8 x i64> %802, %803
  %805 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %801, 0
  %806 = insertvalue { <8 x ptr>, <8 x i64> } %805, <8 x i64> %804, 1
  %807 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %808 = extractvalue { <8 x ptr>, <8 x i64> } %806, 1
  %809 = extractelement <8 x ptr> %807, i32 0
  %810 = extractelement <8 x i64> %808, i32 0
  %811 = sub i64 %810, 0
  %812 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %813 = select i1 %812, i64 %811, i64 0
  %private.contiguous.address460 = getelementptr i8, ptr %809, i64 %813
  %private.contiguous.load461 = load <8 x float>, ptr %private.contiguous.address460, align 4
  %814 = select <8 x i1> %71, <8 x float> %private.contiguous.load461, <8 x float> zeroinitializer
  %.state462 = load i64, ptr %.slot74, align 4
  %815 = add i64 1120, %.state462
  %tile_snapshot.spill.load463 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %816 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load463, 0
  %817 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load463, 1
  %.splatinsert464 = insertelement <8 x i64> poison, i64 %815, i64 0
  %.splat465 = shufflevector <8 x i64> %.splatinsert464, <8 x i64> poison, <8 x i32> zeroinitializer
  %818 = mul <8 x i64> %.splat465, splat (i64 32)
  %819 = add <8 x i64> %817, %818
  %820 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %816, 0
  %821 = insertvalue { <8 x ptr>, <8 x i64> } %820, <8 x i64> %819, 1
  %822 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %823 = extractvalue { <8 x ptr>, <8 x i64> } %821, 1
  %824 = extractelement <8 x ptr> %822, i32 0
  %825 = extractelement <8 x i64> %823, i32 0
  %826 = sub i64 %825, 0
  %827 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %828 = select i1 %827, i64 %826, i64 0
  %private.contiguous.address466 = getelementptr i8, ptr %824, i64 %828
  %private.contiguous.load467 = load <8 x float>, ptr %private.contiguous.address466, align 4
  %829 = select <8 x i1> %71, <8 x float> %private.contiguous.load467, <8 x float> zeroinitializer
  %830 = fmul <8 x float> %814, %829
  %.state468 = load <8 x float>, ptr %.slot75, align 32
  %831 = fadd <8 x float> %.state468, %830
  %.state469 = load i64, ptr %.slot74, align 4
  %832 = add i64 %.state469, 1
  store i64 %832, ptr %.slot74, align 4
  %833 = load <8 x float>, ptr %.slot75, align 32
  %834 = select <8 x i1> %71, <8 x float> %831, <8 x float> %833
  store <8 x float> %834, ptr %.slot75, align 32
  br label %direct.schedule.61

direct.schedule.63:                               ; preds = %direct.false455
  store i64 0, ptr %.slot76, align 4
  %835 = load <8 x float>, ptr %.slot77, align 32
  %836 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %835
  store <8 x float> %836, ptr %.slot77, align 32
  br label %direct.schedule.64

direct.schedule.64:                               ; preds = %direct.schedule.65, %direct.schedule.63
  %.state470 = load i64, ptr %.slot76, align 4
  %837 = icmp slt i64 %.state470, 80
  br i1 %837, label %direct.true471, label %direct.false472

direct.schedule.65:                               ; preds = %direct.true471
  %.state473 = load i64, ptr %.slot76, align 4
  %838 = add i64 0, %.state473
  %tile_snapshot.spill.load474 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %839 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load474, 0
  %840 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load474, 1
  %.splatinsert475 = insertelement <8 x i64> poison, i64 %838, i64 0
  %.splat476 = shufflevector <8 x i64> %.splatinsert475, <8 x i64> poison, <8 x i32> zeroinitializer
  %841 = mul <8 x i64> %.splat476, splat (i64 32)
  %842 = add <8 x i64> %840, %841
  %843 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %839, 0
  %844 = insertvalue { <8 x ptr>, <8 x i64> } %843, <8 x i64> %842, 1
  %845 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %846 = extractvalue { <8 x ptr>, <8 x i64> } %844, 1
  %847 = extractelement <8 x ptr> %845, i32 0
  %848 = extractelement <8 x i64> %846, i32 0
  %849 = sub i64 %848, 0
  %850 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %851 = select i1 %850, i64 %849, i64 0
  %private.contiguous.address477 = getelementptr i8, ptr %847, i64 %851
  %private.contiguous.load478 = load <8 x float>, ptr %private.contiguous.address477, align 4
  %852 = select <8 x i1> %71, <8 x float> %private.contiguous.load478, <8 x float> zeroinitializer
  %.state479 = load i64, ptr %.slot76, align 4
  %853 = add i64 1200, %.state479
  %tile_snapshot.spill.load480 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %854 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load480, 0
  %855 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load480, 1
  %.splatinsert481 = insertelement <8 x i64> poison, i64 %853, i64 0
  %.splat482 = shufflevector <8 x i64> %.splatinsert481, <8 x i64> poison, <8 x i32> zeroinitializer
  %856 = mul <8 x i64> %.splat482, splat (i64 32)
  %857 = add <8 x i64> %855, %856
  %858 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %854, 0
  %859 = insertvalue { <8 x ptr>, <8 x i64> } %858, <8 x i64> %857, 1
  %860 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %861 = extractvalue { <8 x ptr>, <8 x i64> } %859, 1
  %862 = extractelement <8 x ptr> %860, i32 0
  %863 = extractelement <8 x i64> %861, i32 0
  %864 = sub i64 %863, 0
  %865 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %866 = select i1 %865, i64 %864, i64 0
  %private.contiguous.address483 = getelementptr i8, ptr %862, i64 %866
  %private.contiguous.load484 = load <8 x float>, ptr %private.contiguous.address483, align 4
  %867 = select <8 x i1> %71, <8 x float> %private.contiguous.load484, <8 x float> zeroinitializer
  %868 = fmul <8 x float> %852, %867
  %.state485 = load <8 x float>, ptr %.slot77, align 32
  %869 = fadd <8 x float> %.state485, %868
  %.state486 = load i64, ptr %.slot76, align 4
  %870 = add i64 %.state486, 1
  store i64 %870, ptr %.slot76, align 4
  %871 = load <8 x float>, ptr %.slot77, align 32
  %872 = select <8 x i1> %71, <8 x float> %869, <8 x float> %871
  store <8 x float> %872, ptr %.slot77, align 32
  br label %direct.schedule.64

direct.schedule.66:                               ; preds = %direct.false472
  %.state487 = load <8 x float>, ptr %.slot47, align 32
  %873 = fmul <8 x float> %.state487, splat (float 0x3FBC9F25C0000000)
  %.state488 = load <8 x float>, ptr %.slot49, align 32
  %874 = fmul <8 x float> %.state488, splat (float 0x3FBC9F25C0000000)
  %.state489 = load <8 x float>, ptr %.slot51, align 32
  %875 = fmul <8 x float> %.state489, splat (float 0x3FBC9F25C0000000)
  %.state490 = load <8 x float>, ptr %.slot53, align 32
  %876 = fmul <8 x float> %.state490, splat (float 0x3FBC9F25C0000000)
  %.state491 = load <8 x float>, ptr %.slot55, align 32
  %877 = fmul <8 x float> %.state491, splat (float 0x3FBC9F25C0000000)
  %.state492 = load <8 x float>, ptr %.slot57, align 32
  %878 = fmul <8 x float> %.state492, splat (float 0x3FBC9F25C0000000)
  %.state493 = load <8 x float>, ptr %.slot59, align 32
  %879 = fmul <8 x float> %.state493, splat (float 0x3FBC9F25C0000000)
  %.state494 = load <8 x float>, ptr %.slot61, align 32
  %880 = fmul <8 x float> %.state494, splat (float 0x3FBC9F25C0000000)
  %.state495 = load <8 x float>, ptr %.slot63, align 32
  %881 = fmul <8 x float> %.state495, splat (float 0x3FBC9F25C0000000)
  %.state496 = load <8 x float>, ptr %.slot65, align 32
  %882 = fmul <8 x float> %.state496, splat (float 0x3FBC9F25C0000000)
  %.state497 = load <8 x float>, ptr %.slot67, align 32
  %883 = fmul <8 x float> %.state497, splat (float 0x3FBC9F25C0000000)
  %.state498 = load <8 x float>, ptr %.slot69, align 32
  %884 = fmul <8 x float> %.state498, splat (float 0x3FBC9F25C0000000)
  %.state499 = load <8 x float>, ptr %.slot71, align 32
  %885 = fmul <8 x float> %.state499, splat (float 0x3FBC9F25C0000000)
  %.state500 = load <8 x float>, ptr %.slot73, align 32
  %886 = fmul <8 x float> %.state500, splat (float 0x3FBC9F25C0000000)
  %.state501 = load <8 x float>, ptr %.slot75, align 32
  %887 = fmul <8 x float> %.state501, splat (float 0x3FBC9F25C0000000)
  %.state502 = load <8 x float>, ptr %.slot77, align 32
  %888 = fmul <8 x float> %.state502, splat (float 0x3FBC9F25C0000000)
  %.spill.load503 = load i64, ptr %.spill37, align 4
  %889 = add i64 0, %.spill.load503
  %.spill.load504 = load i64, ptr %.spill37, align 4
  %890 = add i64 1, %.spill.load504
  %.spill.load505 = load i64, ptr %.spill37, align 4
  %891 = add i64 2, %.spill.load505
  %.spill.load506 = load i64, ptr %.spill37, align 4
  %892 = add i64 3, %.spill.load506
  %.spill.load507 = load i64, ptr %.spill37, align 4
  %893 = add i64 4, %.spill.load507
  %.spill.load508 = load i64, ptr %.spill37, align 4
  %894 = add i64 5, %.spill.load508
  %.spill.load509 = load i64, ptr %.spill37, align 4
  %895 = add i64 6, %.spill.load509
  %.spill.load510 = load i64, ptr %.spill37, align 4
  %896 = add i64 7, %.spill.load510
  %.spill.load511 = load i64, ptr %.spill37, align 4
  %897 = add i64 8, %.spill.load511
  %.spill.load512 = load i64, ptr %.spill37, align 4
  %898 = add i64 9, %.spill.load512
  %.spill.load513 = load i64, ptr %.spill37, align 4
  %899 = add i64 10, %.spill.load513
  %.spill.load514 = load i64, ptr %.spill37, align 4
  %900 = add i64 11, %.spill.load514
  %.spill.load515 = load i64, ptr %.spill37, align 4
  %901 = add i64 12, %.spill.load515
  %.spill.load516 = load i64, ptr %.spill37, align 4
  %902 = add i64 13, %.spill.load516
  %.spill.load517 = load i64, ptr %.spill37, align 4
  %903 = add i64 14, %.spill.load517
  %.spill.load518 = load i64, ptr %.spill37, align 4
  %904 = add i64 15, %.spill.load518
  %905 = icmp slt i64 %889, 67
  %906 = icmp slt i64 %890, 67
  %907 = icmp slt i64 %891, 67
  %908 = icmp slt i64 %892, 67
  %909 = icmp slt i64 %893, 67
  %910 = icmp slt i64 %894, 67
  %911 = icmp slt i64 %895, 67
  %912 = icmp slt i64 %896, 67
  %913 = icmp slt i64 %897, 67
  %914 = icmp slt i64 %898, 67
  %915 = icmp slt i64 %899, 67
  %916 = icmp slt i64 %900, 67
  %917 = icmp slt i64 %901, 67
  %918 = icmp slt i64 %902, 67
  %919 = icmp slt i64 %903, 67
  %920 = icmp slt i64 %904, 67
  %.spill.load519 = load <8 x i64>, ptr %.spill29, align 64
  %921 = add <8 x i64> zeroinitializer, %.spill.load519
  %922 = add <8 x i64> %921, splat (i64 67)
  %923 = sub <8 x i64> %922, splat (i64 3)
  %.splatinsert520 = insertelement <8 x i64> poison, i64 %889, i64 0
  %.splat521 = shufflevector <8 x i64> %.splatinsert520, <8 x i64> poison, <8 x i32> zeroinitializer
  %924 = icmp sle <8 x i64> %.splat521, %923
  %.splatinsert522 = insertelement <8 x i64> poison, i64 %890, i64 0
  %.splat523 = shufflevector <8 x i64> %.splatinsert522, <8 x i64> poison, <8 x i32> zeroinitializer
  %925 = icmp sle <8 x i64> %.splat523, %923
  %.splatinsert524 = insertelement <8 x i64> poison, i64 %891, i64 0
  %.splat525 = shufflevector <8 x i64> %.splatinsert524, <8 x i64> poison, <8 x i32> zeroinitializer
  %926 = icmp sle <8 x i64> %.splat525, %923
  %.splatinsert526 = insertelement <8 x i64> poison, i64 %892, i64 0
  %.splat527 = shufflevector <8 x i64> %.splatinsert526, <8 x i64> poison, <8 x i32> zeroinitializer
  %927 = icmp sle <8 x i64> %.splat527, %923
  %.splatinsert528 = insertelement <8 x i64> poison, i64 %893, i64 0
  %.splat529 = shufflevector <8 x i64> %.splatinsert528, <8 x i64> poison, <8 x i32> zeroinitializer
  %928 = icmp sle <8 x i64> %.splat529, %923
  %.splatinsert530 = insertelement <8 x i64> poison, i64 %894, i64 0
  %.splat531 = shufflevector <8 x i64> %.splatinsert530, <8 x i64> poison, <8 x i32> zeroinitializer
  %929 = icmp sle <8 x i64> %.splat531, %923
  %.splatinsert532 = insertelement <8 x i64> poison, i64 %895, i64 0
  %.splat533 = shufflevector <8 x i64> %.splatinsert532, <8 x i64> poison, <8 x i32> zeroinitializer
  %930 = icmp sle <8 x i64> %.splat533, %923
  %.splatinsert534 = insertelement <8 x i64> poison, i64 %896, i64 0
  %.splat535 = shufflevector <8 x i64> %.splatinsert534, <8 x i64> poison, <8 x i32> zeroinitializer
  %931 = icmp sle <8 x i64> %.splat535, %923
  %.splatinsert536 = insertelement <8 x i64> poison, i64 %897, i64 0
  %.splat537 = shufflevector <8 x i64> %.splatinsert536, <8 x i64> poison, <8 x i32> zeroinitializer
  %932 = icmp sle <8 x i64> %.splat537, %923
  %.splatinsert538 = insertelement <8 x i64> poison, i64 %898, i64 0
  %.splat539 = shufflevector <8 x i64> %.splatinsert538, <8 x i64> poison, <8 x i32> zeroinitializer
  %933 = icmp sle <8 x i64> %.splat539, %923
  %.splatinsert540 = insertelement <8 x i64> poison, i64 %899, i64 0
  %.splat541 = shufflevector <8 x i64> %.splatinsert540, <8 x i64> poison, <8 x i32> zeroinitializer
  %934 = icmp sle <8 x i64> %.splat541, %923
  %.splatinsert542 = insertelement <8 x i64> poison, i64 %900, i64 0
  %.splat543 = shufflevector <8 x i64> %.splatinsert542, <8 x i64> poison, <8 x i32> zeroinitializer
  %935 = icmp sle <8 x i64> %.splat543, %923
  %.splatinsert544 = insertelement <8 x i64> poison, i64 %901, i64 0
  %.splat545 = shufflevector <8 x i64> %.splatinsert544, <8 x i64> poison, <8 x i32> zeroinitializer
  %936 = icmp sle <8 x i64> %.splat545, %923
  %.splatinsert546 = insertelement <8 x i64> poison, i64 %902, i64 0
  %.splat547 = shufflevector <8 x i64> %.splatinsert546, <8 x i64> poison, <8 x i32> zeroinitializer
  %937 = icmp sle <8 x i64> %.splat547, %923
  %.splatinsert548 = insertelement <8 x i64> poison, i64 %903, i64 0
  %.splat549 = shufflevector <8 x i64> %.splatinsert548, <8 x i64> poison, <8 x i32> zeroinitializer
  %938 = icmp sle <8 x i64> %.splat549, %923
  %.splatinsert550 = insertelement <8 x i64> poison, i64 %904, i64 0
  %.splat551 = shufflevector <8 x i64> %.splatinsert550, <8 x i64> poison, <8 x i32> zeroinitializer
  %939 = icmp sle <8 x i64> %.splat551, %923
  %.splatinsert552 = insertelement <8 x i1> poison, i1 %905, i64 0
  %.splat553 = shufflevector <8 x i1> %.splatinsert552, <8 x i1> poison, <8 x i32> zeroinitializer
  %940 = and <8 x i1> %.splat553, %924
  %941 = load <8 x i1>, ptr %.spill78, align 1
  %942 = select <8 x i1> %71, <8 x i1> %940, <8 x i1> %941
  store <8 x i1> %942, ptr %.spill78, align 1
  %.splatinsert554 = insertelement <8 x i1> poison, i1 %906, i64 0
  %.splat555 = shufflevector <8 x i1> %.splatinsert554, <8 x i1> poison, <8 x i32> zeroinitializer
  %943 = and <8 x i1> %.splat555, %925
  %944 = load <8 x i1>, ptr %.spill79, align 1
  %945 = select <8 x i1> %71, <8 x i1> %943, <8 x i1> %944
  store <8 x i1> %945, ptr %.spill79, align 1
  %.splatinsert556 = insertelement <8 x i1> poison, i1 %907, i64 0
  %.splat557 = shufflevector <8 x i1> %.splatinsert556, <8 x i1> poison, <8 x i32> zeroinitializer
  %946 = and <8 x i1> %.splat557, %926
  %947 = load <8 x i1>, ptr %.spill80, align 1
  %948 = select <8 x i1> %71, <8 x i1> %946, <8 x i1> %947
  store <8 x i1> %948, ptr %.spill80, align 1
  %.splatinsert558 = insertelement <8 x i1> poison, i1 %908, i64 0
  %.splat559 = shufflevector <8 x i1> %.splatinsert558, <8 x i1> poison, <8 x i32> zeroinitializer
  %949 = and <8 x i1> %.splat559, %927
  %950 = load <8 x i1>, ptr %.spill81, align 1
  %951 = select <8 x i1> %71, <8 x i1> %949, <8 x i1> %950
  store <8 x i1> %951, ptr %.spill81, align 1
  %.splatinsert560 = insertelement <8 x i1> poison, i1 %909, i64 0
  %.splat561 = shufflevector <8 x i1> %.splatinsert560, <8 x i1> poison, <8 x i32> zeroinitializer
  %952 = and <8 x i1> %.splat561, %928
  %953 = load <8 x i1>, ptr %.spill82, align 1
  %954 = select <8 x i1> %71, <8 x i1> %952, <8 x i1> %953
  store <8 x i1> %954, ptr %.spill82, align 1
  %.splatinsert562 = insertelement <8 x i1> poison, i1 %910, i64 0
  %.splat563 = shufflevector <8 x i1> %.splatinsert562, <8 x i1> poison, <8 x i32> zeroinitializer
  %955 = and <8 x i1> %.splat563, %929
  %956 = load <8 x i1>, ptr %.spill83, align 1
  %957 = select <8 x i1> %71, <8 x i1> %955, <8 x i1> %956
  store <8 x i1> %957, ptr %.spill83, align 1
  %.splatinsert564 = insertelement <8 x i1> poison, i1 %911, i64 0
  %.splat565 = shufflevector <8 x i1> %.splatinsert564, <8 x i1> poison, <8 x i32> zeroinitializer
  %958 = and <8 x i1> %.splat565, %930
  %959 = load <8 x i1>, ptr %.spill84, align 1
  %960 = select <8 x i1> %71, <8 x i1> %958, <8 x i1> %959
  store <8 x i1> %960, ptr %.spill84, align 1
  %.splatinsert566 = insertelement <8 x i1> poison, i1 %912, i64 0
  %.splat567 = shufflevector <8 x i1> %.splatinsert566, <8 x i1> poison, <8 x i32> zeroinitializer
  %961 = and <8 x i1> %.splat567, %931
  %962 = load <8 x i1>, ptr %.spill85, align 1
  %963 = select <8 x i1> %71, <8 x i1> %961, <8 x i1> %962
  store <8 x i1> %963, ptr %.spill85, align 1
  %.splatinsert568 = insertelement <8 x i1> poison, i1 %913, i64 0
  %.splat569 = shufflevector <8 x i1> %.splatinsert568, <8 x i1> poison, <8 x i32> zeroinitializer
  %964 = and <8 x i1> %.splat569, %932
  %965 = load <8 x i1>, ptr %.spill86, align 1
  %966 = select <8 x i1> %71, <8 x i1> %964, <8 x i1> %965
  store <8 x i1> %966, ptr %.spill86, align 1
  %.splatinsert570 = insertelement <8 x i1> poison, i1 %914, i64 0
  %.splat571 = shufflevector <8 x i1> %.splatinsert570, <8 x i1> poison, <8 x i32> zeroinitializer
  %967 = and <8 x i1> %.splat571, %933
  %968 = load <8 x i1>, ptr %.spill87, align 1
  %969 = select <8 x i1> %71, <8 x i1> %967, <8 x i1> %968
  store <8 x i1> %969, ptr %.spill87, align 1
  %.splatinsert572 = insertelement <8 x i1> poison, i1 %915, i64 0
  %.splat573 = shufflevector <8 x i1> %.splatinsert572, <8 x i1> poison, <8 x i32> zeroinitializer
  %970 = and <8 x i1> %.splat573, %934
  %971 = load <8 x i1>, ptr %.spill88, align 1
  %972 = select <8 x i1> %71, <8 x i1> %970, <8 x i1> %971
  store <8 x i1> %972, ptr %.spill88, align 1
  %.splatinsert574 = insertelement <8 x i1> poison, i1 %916, i64 0
  %.splat575 = shufflevector <8 x i1> %.splatinsert574, <8 x i1> poison, <8 x i32> zeroinitializer
  %973 = and <8 x i1> %.splat575, %935
  %974 = load <8 x i1>, ptr %.spill89, align 1
  %975 = select <8 x i1> %71, <8 x i1> %973, <8 x i1> %974
  store <8 x i1> %975, ptr %.spill89, align 1
  %.splatinsert576 = insertelement <8 x i1> poison, i1 %917, i64 0
  %.splat577 = shufflevector <8 x i1> %.splatinsert576, <8 x i1> poison, <8 x i32> zeroinitializer
  %976 = and <8 x i1> %.splat577, %936
  %977 = load <8 x i1>, ptr %.spill90, align 1
  %978 = select <8 x i1> %71, <8 x i1> %976, <8 x i1> %977
  store <8 x i1> %978, ptr %.spill90, align 1
  %.splatinsert578 = insertelement <8 x i1> poison, i1 %918, i64 0
  %.splat579 = shufflevector <8 x i1> %.splatinsert578, <8 x i1> poison, <8 x i32> zeroinitializer
  %979 = and <8 x i1> %.splat579, %937
  %980 = load <8 x i1>, ptr %.spill91, align 1
  %981 = select <8 x i1> %71, <8 x i1> %979, <8 x i1> %980
  store <8 x i1> %981, ptr %.spill91, align 1
  %.splatinsert580 = insertelement <8 x i1> poison, i1 %919, i64 0
  %.splat581 = shufflevector <8 x i1> %.splatinsert580, <8 x i1> poison, <8 x i32> zeroinitializer
  %982 = and <8 x i1> %.splat581, %938
  %983 = load <8 x i1>, ptr %.spill92, align 1
  %984 = select <8 x i1> %71, <8 x i1> %982, <8 x i1> %983
  store <8 x i1> %984, ptr %.spill92, align 1
  %.splatinsert582 = insertelement <8 x i1> poison, i1 %920, i64 0
  %.splat583 = shufflevector <8 x i1> %.splatinsert582, <8 x i1> poison, <8 x i32> zeroinitializer
  %985 = and <8 x i1> %.splat583, %939
  %986 = load <8 x i1>, ptr %.spill93, align 1
  %987 = select <8 x i1> %71, <8 x i1> %985, <8 x i1> %986
  store <8 x i1> %987, ptr %.spill93, align 1
  %988 = select <8 x i1> %940, <8 x float> %873, <8 x float> splat (float 0xC6293E5940000000)
  %989 = load <8 x float>, ptr %.spill94, align 32
  %990 = select <8 x i1> %71, <8 x float> %988, <8 x float> %989
  store <8 x float> %990, ptr %.spill94, align 32
  %991 = select <8 x i1> %943, <8 x float> %874, <8 x float> splat (float 0xC6293E5940000000)
  %992 = load <8 x float>, ptr %.spill95, align 32
  %993 = select <8 x i1> %71, <8 x float> %991, <8 x float> %992
  store <8 x float> %993, ptr %.spill95, align 32
  %994 = select <8 x i1> %946, <8 x float> %875, <8 x float> splat (float 0xC6293E5940000000)
  %995 = load <8 x float>, ptr %.spill96, align 32
  %996 = select <8 x i1> %71, <8 x float> %994, <8 x float> %995
  store <8 x float> %996, ptr %.spill96, align 32
  %997 = select <8 x i1> %949, <8 x float> %876, <8 x float> splat (float 0xC6293E5940000000)
  %998 = load <8 x float>, ptr %.spill97, align 32
  %999 = select <8 x i1> %71, <8 x float> %997, <8 x float> %998
  store <8 x float> %999, ptr %.spill97, align 32
  %1000 = select <8 x i1> %952, <8 x float> %877, <8 x float> splat (float 0xC6293E5940000000)
  %1001 = load <8 x float>, ptr %.spill98, align 32
  %1002 = select <8 x i1> %71, <8 x float> %1000, <8 x float> %1001
  store <8 x float> %1002, ptr %.spill98, align 32
  %1003 = select <8 x i1> %955, <8 x float> %878, <8 x float> splat (float 0xC6293E5940000000)
  %1004 = load <8 x float>, ptr %.spill99, align 32
  %1005 = select <8 x i1> %71, <8 x float> %1003, <8 x float> %1004
  store <8 x float> %1005, ptr %.spill99, align 32
  %1006 = select <8 x i1> %958, <8 x float> %879, <8 x float> splat (float 0xC6293E5940000000)
  %1007 = load <8 x float>, ptr %.spill100, align 32
  %1008 = select <8 x i1> %71, <8 x float> %1006, <8 x float> %1007
  store <8 x float> %1008, ptr %.spill100, align 32
  %1009 = select <8 x i1> %961, <8 x float> %880, <8 x float> splat (float 0xC6293E5940000000)
  %1010 = load <8 x float>, ptr %.spill101, align 32
  %1011 = select <8 x i1> %71, <8 x float> %1009, <8 x float> %1010
  store <8 x float> %1011, ptr %.spill101, align 32
  %1012 = select <8 x i1> %964, <8 x float> %881, <8 x float> splat (float 0xC6293E5940000000)
  %1013 = load <8 x float>, ptr %.spill102, align 32
  %1014 = select <8 x i1> %71, <8 x float> %1012, <8 x float> %1013
  store <8 x float> %1014, ptr %.spill102, align 32
  %1015 = select <8 x i1> %967, <8 x float> %882, <8 x float> splat (float 0xC6293E5940000000)
  %1016 = load <8 x float>, ptr %.spill103, align 32
  %1017 = select <8 x i1> %71, <8 x float> %1015, <8 x float> %1016
  store <8 x float> %1017, ptr %.spill103, align 32
  %1018 = select <8 x i1> %970, <8 x float> %883, <8 x float> splat (float 0xC6293E5940000000)
  %1019 = load <8 x float>, ptr %.spill104, align 32
  %1020 = select <8 x i1> %71, <8 x float> %1018, <8 x float> %1019
  store <8 x float> %1020, ptr %.spill104, align 32
  %1021 = select <8 x i1> %973, <8 x float> %884, <8 x float> splat (float 0xC6293E5940000000)
  %1022 = load <8 x float>, ptr %.spill105, align 32
  %1023 = select <8 x i1> %71, <8 x float> %1021, <8 x float> %1022
  store <8 x float> %1023, ptr %.spill105, align 32
  %1024 = select <8 x i1> %976, <8 x float> %885, <8 x float> splat (float 0xC6293E5940000000)
  %1025 = load <8 x float>, ptr %.spill106, align 32
  %1026 = select <8 x i1> %71, <8 x float> %1024, <8 x float> %1025
  store <8 x float> %1026, ptr %.spill106, align 32
  %1027 = select <8 x i1> %979, <8 x float> %886, <8 x float> splat (float 0xC6293E5940000000)
  %1028 = load <8 x float>, ptr %.spill107, align 32
  %1029 = select <8 x i1> %71, <8 x float> %1027, <8 x float> %1028
  store <8 x float> %1029, ptr %.spill107, align 32
  %1030 = select <8 x i1> %982, <8 x float> %887, <8 x float> splat (float 0xC6293E5940000000)
  %1031 = load <8 x float>, ptr %.spill108, align 32
  %1032 = select <8 x i1> %71, <8 x float> %1030, <8 x float> %1031
  store <8 x float> %1032, ptr %.spill108, align 32
  %1033 = select <8 x i1> %985, <8 x float> %888, <8 x float> splat (float 0xC6293E5940000000)
  %1034 = load <8 x float>, ptr %.spill109, align 32
  %1035 = select <8 x i1> %71, <8 x float> %1033, <8 x float> %1034
  store <8 x float> %1035, ptr %.spill109, align 32
  %1036 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill110, align 64
  %1037 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1038 = extractvalue { <8 x ptr>, <8 x i64> } %1036, 0
  %1039 = select <8 x i1> %71, <8 x ptr> %1037, <8 x ptr> %1038
  %1040 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1041 = extractvalue { <8 x ptr>, <8 x i64> } %1036, 1
  %1042 = select <8 x i1> %71, <8 x i64> %1040, <8 x i64> %1041
  %1043 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1039, 0
  %1044 = insertvalue { <8 x ptr>, <8 x i64> } %1043, <8 x i64> %1042, 1
  store { <8 x ptr>, <8 x i64> } %1044, ptr %tile_snapshot.spill110, align 64
  %1045 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1046 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1047 = add <8 x i64> %1046, zeroinitializer
  %1048 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1045, 0
  %1049 = insertvalue { <8 x ptr>, <8 x i64> } %1048, <8 x i64> %1047, 1
  %1050 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1051 = extractvalue { <8 x ptr>, <8 x i64> } %1049, 1
  %1052 = extractelement <8 x ptr> %1050, i32 0
  %1053 = extractelement <8 x i64> %1051, i32 0
  %1054 = sub i64 %1053, 0
  %1055 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1056 = select i1 %1055, i64 %1054, i64 0
  %private.contiguous.address584 = getelementptr i8, ptr %1052, i64 %1056
  %private.contiguous.preserve585 = load <8 x float>, ptr %private.contiguous.address584, align 4
  %1057 = select <8 x i1> %71, <8 x float> %988, <8 x float> %private.contiguous.preserve585
  store <8 x float> %1057, ptr %private.contiguous.address584, align 4
  %1058 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1059 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1060 = add <8 x i64> %1059, splat (i64 32)
  %1061 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1058, 0
  %1062 = insertvalue { <8 x ptr>, <8 x i64> } %1061, <8 x i64> %1060, 1
  %1063 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1064 = extractvalue { <8 x ptr>, <8 x i64> } %1062, 1
  %1065 = extractelement <8 x ptr> %1063, i32 0
  %1066 = extractelement <8 x i64> %1064, i32 0
  %1067 = sub i64 %1066, 0
  %1068 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1069 = select i1 %1068, i64 %1067, i64 0
  %private.contiguous.address586 = getelementptr i8, ptr %1065, i64 %1069
  %private.contiguous.preserve587 = load <8 x float>, ptr %private.contiguous.address586, align 4
  %1070 = select <8 x i1> %71, <8 x float> %991, <8 x float> %private.contiguous.preserve587
  store <8 x float> %1070, ptr %private.contiguous.address586, align 4
  %1071 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1072 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1073 = add <8 x i64> %1072, splat (i64 64)
  %1074 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1071, 0
  %1075 = insertvalue { <8 x ptr>, <8 x i64> } %1074, <8 x i64> %1073, 1
  %1076 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1077 = extractvalue { <8 x ptr>, <8 x i64> } %1075, 1
  %1078 = extractelement <8 x ptr> %1076, i32 0
  %1079 = extractelement <8 x i64> %1077, i32 0
  %1080 = sub i64 %1079, 0
  %1081 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1082 = select i1 %1081, i64 %1080, i64 0
  %private.contiguous.address588 = getelementptr i8, ptr %1078, i64 %1082
  %private.contiguous.preserve589 = load <8 x float>, ptr %private.contiguous.address588, align 4
  %1083 = select <8 x i1> %71, <8 x float> %994, <8 x float> %private.contiguous.preserve589
  store <8 x float> %1083, ptr %private.contiguous.address588, align 4
  %1084 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1085 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1086 = add <8 x i64> %1085, splat (i64 96)
  %1087 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1084, 0
  %1088 = insertvalue { <8 x ptr>, <8 x i64> } %1087, <8 x i64> %1086, 1
  %1089 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1090 = extractvalue { <8 x ptr>, <8 x i64> } %1088, 1
  %1091 = extractelement <8 x ptr> %1089, i32 0
  %1092 = extractelement <8 x i64> %1090, i32 0
  %1093 = sub i64 %1092, 0
  %1094 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1095 = select i1 %1094, i64 %1093, i64 0
  %private.contiguous.address590 = getelementptr i8, ptr %1091, i64 %1095
  %private.contiguous.preserve591 = load <8 x float>, ptr %private.contiguous.address590, align 4
  %1096 = select <8 x i1> %71, <8 x float> %997, <8 x float> %private.contiguous.preserve591
  store <8 x float> %1096, ptr %private.contiguous.address590, align 4
  %1097 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1098 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1099 = add <8 x i64> %1098, splat (i64 128)
  %1100 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1097, 0
  %1101 = insertvalue { <8 x ptr>, <8 x i64> } %1100, <8 x i64> %1099, 1
  %1102 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1103 = extractvalue { <8 x ptr>, <8 x i64> } %1101, 1
  %1104 = extractelement <8 x ptr> %1102, i32 0
  %1105 = extractelement <8 x i64> %1103, i32 0
  %1106 = sub i64 %1105, 0
  %1107 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1108 = select i1 %1107, i64 %1106, i64 0
  %private.contiguous.address592 = getelementptr i8, ptr %1104, i64 %1108
  %private.contiguous.preserve593 = load <8 x float>, ptr %private.contiguous.address592, align 4
  %1109 = select <8 x i1> %71, <8 x float> %1000, <8 x float> %private.contiguous.preserve593
  store <8 x float> %1109, ptr %private.contiguous.address592, align 4
  %1110 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1111 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1112 = add <8 x i64> %1111, splat (i64 160)
  %1113 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1110, 0
  %1114 = insertvalue { <8 x ptr>, <8 x i64> } %1113, <8 x i64> %1112, 1
  %1115 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1116 = extractvalue { <8 x ptr>, <8 x i64> } %1114, 1
  %1117 = extractelement <8 x ptr> %1115, i32 0
  %1118 = extractelement <8 x i64> %1116, i32 0
  %1119 = sub i64 %1118, 0
  %1120 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1121 = select i1 %1120, i64 %1119, i64 0
  %private.contiguous.address594 = getelementptr i8, ptr %1117, i64 %1121
  %private.contiguous.preserve595 = load <8 x float>, ptr %private.contiguous.address594, align 4
  %1122 = select <8 x i1> %71, <8 x float> %1003, <8 x float> %private.contiguous.preserve595
  store <8 x float> %1122, ptr %private.contiguous.address594, align 4
  %1123 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1124 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1125 = add <8 x i64> %1124, splat (i64 192)
  %1126 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1123, 0
  %1127 = insertvalue { <8 x ptr>, <8 x i64> } %1126, <8 x i64> %1125, 1
  %1128 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1129 = extractvalue { <8 x ptr>, <8 x i64> } %1127, 1
  %1130 = extractelement <8 x ptr> %1128, i32 0
  %1131 = extractelement <8 x i64> %1129, i32 0
  %1132 = sub i64 %1131, 0
  %1133 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1134 = select i1 %1133, i64 %1132, i64 0
  %private.contiguous.address596 = getelementptr i8, ptr %1130, i64 %1134
  %private.contiguous.preserve597 = load <8 x float>, ptr %private.contiguous.address596, align 4
  %1135 = select <8 x i1> %71, <8 x float> %1006, <8 x float> %private.contiguous.preserve597
  store <8 x float> %1135, ptr %private.contiguous.address596, align 4
  %1136 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1137 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1138 = add <8 x i64> %1137, splat (i64 224)
  %1139 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1136, 0
  %1140 = insertvalue { <8 x ptr>, <8 x i64> } %1139, <8 x i64> %1138, 1
  %1141 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1142 = extractvalue { <8 x ptr>, <8 x i64> } %1140, 1
  %1143 = extractelement <8 x ptr> %1141, i32 0
  %1144 = extractelement <8 x i64> %1142, i32 0
  %1145 = sub i64 %1144, 0
  %1146 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1147 = select i1 %1146, i64 %1145, i64 0
  %private.contiguous.address598 = getelementptr i8, ptr %1143, i64 %1147
  %private.contiguous.preserve599 = load <8 x float>, ptr %private.contiguous.address598, align 4
  %1148 = select <8 x i1> %71, <8 x float> %1009, <8 x float> %private.contiguous.preserve599
  store <8 x float> %1148, ptr %private.contiguous.address598, align 4
  %1149 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1150 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1151 = add <8 x i64> %1150, splat (i64 256)
  %1152 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1149, 0
  %1153 = insertvalue { <8 x ptr>, <8 x i64> } %1152, <8 x i64> %1151, 1
  %1154 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1155 = extractvalue { <8 x ptr>, <8 x i64> } %1153, 1
  %1156 = extractelement <8 x ptr> %1154, i32 0
  %1157 = extractelement <8 x i64> %1155, i32 0
  %1158 = sub i64 %1157, 0
  %1159 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1160 = select i1 %1159, i64 %1158, i64 0
  %private.contiguous.address600 = getelementptr i8, ptr %1156, i64 %1160
  %private.contiguous.preserve601 = load <8 x float>, ptr %private.contiguous.address600, align 4
  %1161 = select <8 x i1> %71, <8 x float> %1012, <8 x float> %private.contiguous.preserve601
  store <8 x float> %1161, ptr %private.contiguous.address600, align 4
  %1162 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1163 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1164 = add <8 x i64> %1163, splat (i64 288)
  %1165 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1162, 0
  %1166 = insertvalue { <8 x ptr>, <8 x i64> } %1165, <8 x i64> %1164, 1
  %1167 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1168 = extractvalue { <8 x ptr>, <8 x i64> } %1166, 1
  %1169 = extractelement <8 x ptr> %1167, i32 0
  %1170 = extractelement <8 x i64> %1168, i32 0
  %1171 = sub i64 %1170, 0
  %1172 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1173 = select i1 %1172, i64 %1171, i64 0
  %private.contiguous.address602 = getelementptr i8, ptr %1169, i64 %1173
  %private.contiguous.preserve603 = load <8 x float>, ptr %private.contiguous.address602, align 4
  %1174 = select <8 x i1> %71, <8 x float> %1015, <8 x float> %private.contiguous.preserve603
  store <8 x float> %1174, ptr %private.contiguous.address602, align 4
  %1175 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1176 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1177 = add <8 x i64> %1176, splat (i64 320)
  %1178 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1175, 0
  %1179 = insertvalue { <8 x ptr>, <8 x i64> } %1178, <8 x i64> %1177, 1
  %1180 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1181 = extractvalue { <8 x ptr>, <8 x i64> } %1179, 1
  %1182 = extractelement <8 x ptr> %1180, i32 0
  %1183 = extractelement <8 x i64> %1181, i32 0
  %1184 = sub i64 %1183, 0
  %1185 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1186 = select i1 %1185, i64 %1184, i64 0
  %private.contiguous.address604 = getelementptr i8, ptr %1182, i64 %1186
  %private.contiguous.preserve605 = load <8 x float>, ptr %private.contiguous.address604, align 4
  %1187 = select <8 x i1> %71, <8 x float> %1018, <8 x float> %private.contiguous.preserve605
  store <8 x float> %1187, ptr %private.contiguous.address604, align 4
  %1188 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1189 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1190 = add <8 x i64> %1189, splat (i64 352)
  %1191 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1188, 0
  %1192 = insertvalue { <8 x ptr>, <8 x i64> } %1191, <8 x i64> %1190, 1
  %1193 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1194 = extractvalue { <8 x ptr>, <8 x i64> } %1192, 1
  %1195 = extractelement <8 x ptr> %1193, i32 0
  %1196 = extractelement <8 x i64> %1194, i32 0
  %1197 = sub i64 %1196, 0
  %1198 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1199 = select i1 %1198, i64 %1197, i64 0
  %private.contiguous.address606 = getelementptr i8, ptr %1195, i64 %1199
  %private.contiguous.preserve607 = load <8 x float>, ptr %private.contiguous.address606, align 4
  %1200 = select <8 x i1> %71, <8 x float> %1021, <8 x float> %private.contiguous.preserve607
  store <8 x float> %1200, ptr %private.contiguous.address606, align 4
  %1201 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1202 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1203 = add <8 x i64> %1202, splat (i64 384)
  %1204 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1201, 0
  %1205 = insertvalue { <8 x ptr>, <8 x i64> } %1204, <8 x i64> %1203, 1
  %1206 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1207 = extractvalue { <8 x ptr>, <8 x i64> } %1205, 1
  %1208 = extractelement <8 x ptr> %1206, i32 0
  %1209 = extractelement <8 x i64> %1207, i32 0
  %1210 = sub i64 %1209, 0
  %1211 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1212 = select i1 %1211, i64 %1210, i64 0
  %private.contiguous.address608 = getelementptr i8, ptr %1208, i64 %1212
  %private.contiguous.preserve609 = load <8 x float>, ptr %private.contiguous.address608, align 4
  %1213 = select <8 x i1> %71, <8 x float> %1024, <8 x float> %private.contiguous.preserve609
  store <8 x float> %1213, ptr %private.contiguous.address608, align 4
  %1214 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1215 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1216 = add <8 x i64> %1215, splat (i64 416)
  %1217 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1214, 0
  %1218 = insertvalue { <8 x ptr>, <8 x i64> } %1217, <8 x i64> %1216, 1
  %1219 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1220 = extractvalue { <8 x ptr>, <8 x i64> } %1218, 1
  %1221 = extractelement <8 x ptr> %1219, i32 0
  %1222 = extractelement <8 x i64> %1220, i32 0
  %1223 = sub i64 %1222, 0
  %1224 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1225 = select i1 %1224, i64 %1223, i64 0
  %private.contiguous.address610 = getelementptr i8, ptr %1221, i64 %1225
  %private.contiguous.preserve611 = load <8 x float>, ptr %private.contiguous.address610, align 4
  %1226 = select <8 x i1> %71, <8 x float> %1027, <8 x float> %private.contiguous.preserve611
  store <8 x float> %1226, ptr %private.contiguous.address610, align 4
  %1227 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1228 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1229 = add <8 x i64> %1228, splat (i64 448)
  %1230 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1227, 0
  %1231 = insertvalue { <8 x ptr>, <8 x i64> } %1230, <8 x i64> %1229, 1
  %1232 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1233 = extractvalue { <8 x ptr>, <8 x i64> } %1231, 1
  %1234 = extractelement <8 x ptr> %1232, i32 0
  %1235 = extractelement <8 x i64> %1233, i32 0
  %1236 = sub i64 %1235, 0
  %1237 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1238 = select i1 %1237, i64 %1236, i64 0
  %private.contiguous.address612 = getelementptr i8, ptr %1234, i64 %1238
  %private.contiguous.preserve613 = load <8 x float>, ptr %private.contiguous.address612, align 4
  %1239 = select <8 x i1> %71, <8 x float> %1030, <8 x float> %private.contiguous.preserve613
  store <8 x float> %1239, ptr %private.contiguous.address612, align 4
  %1240 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1241 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1242 = add <8 x i64> %1241, splat (i64 480)
  %1243 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1240, 0
  %1244 = insertvalue { <8 x ptr>, <8 x i64> } %1243, <8 x i64> %1242, 1
  %1245 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1246 = extractvalue { <8 x ptr>, <8 x i64> } %1244, 1
  %1247 = extractelement <8 x ptr> %1245, i32 0
  %1248 = extractelement <8 x i64> %1246, i32 0
  %1249 = sub i64 %1248, 0
  %1250 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1251 = select i1 %1250, i64 %1249, i64 0
  %private.contiguous.address614 = getelementptr i8, ptr %1247, i64 %1251
  %private.contiguous.preserve615 = load <8 x float>, ptr %private.contiguous.address614, align 4
  %1252 = select <8 x i1> %71, <8 x float> %1033, <8 x float> %private.contiguous.preserve615
  store <8 x float> %1252, ptr %private.contiguous.address614, align 4
  store i64 0, ptr %.slot111, align 4
  %1253 = load <8 x float>, ptr %.slot112, align 32
  %1254 = select <8 x i1> %71, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %1253
  store <8 x float> %1254, ptr %.slot112, align 32
  br label %direct.schedule.67

direct.schedule.67:                               ; preds = %direct.schedule.68, %direct.schedule.66
  %.state616 = load i64, ptr %.slot111, align 4
  %1255 = icmp slt i64 %.state616, 16
  br i1 %1255, label %direct.true617, label %direct.false618

direct.schedule.68:                               ; preds = %direct.true617
  %.state619 = load i64, ptr %.slot111, align 4
  %1256 = sdiv i64 %.state619, 1
  %1257 = add i64 0, %1256
  %tile_snapshot.spill.load620 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill110, align 64
  %1258 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load620, 0
  %1259 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load620, 1
  %.splatinsert621 = insertelement <8 x i64> poison, i64 %1257, i64 0
  %.splat622 = shufflevector <8 x i64> %.splatinsert621, <8 x i64> poison, <8 x i32> zeroinitializer
  %1260 = mul <8 x i64> %.splat622, splat (i64 32)
  %1261 = add <8 x i64> %1259, %1260
  %1262 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1258, 0
  %1263 = insertvalue { <8 x ptr>, <8 x i64> } %1262, <8 x i64> %1261, 1
  %1264 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1265 = extractvalue { <8 x ptr>, <8 x i64> } %1263, 1
  %1266 = extractelement <8 x ptr> %1264, i32 0
  %1267 = extractelement <8 x i64> %1265, i32 0
  %1268 = sub i64 %1267, 0
  %1269 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1270 = select i1 %1269, i64 %1268, i64 0
  %private.contiguous.address623 = getelementptr i8, ptr %1266, i64 %1270
  %private.contiguous.load624 = load <8 x float>, ptr %private.contiguous.address623, align 4
  %1271 = select <8 x i1> %71, <8 x float> %private.contiguous.load624, <8 x float> zeroinitializer
  %.state625 = load <8 x float>, ptr %.slot112, align 32
  %1272 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state625, <8 x float> %1271)
  %.state626 = load i64, ptr %.slot111, align 4
  %1273 = add i64 %.state626, 1
  store i64 %1273, ptr %.slot111, align 4
  %1274 = load <8 x float>, ptr %.slot112, align 32
  %1275 = select <8 x i1> %71, <8 x float> %1272, <8 x float> %1274
  store <8 x float> %1275, ptr %.slot112, align 32
  br label %direct.schedule.67

direct.schedule.69:                               ; preds = %direct.false618
  %.state627 = load <8 x float>, ptr %.slot35, align 32
  %.state628 = load <8 x float>, ptr %.slot112, align 32
  %1276 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state627, <8 x float> %.state628)
  %1277 = load <8 x float>, ptr %.spill113, align 32
  %1278 = select <8 x i1> %71, <8 x float> %1276, <8 x float> %1277
  store <8 x float> %1278, ptr %.spill113, align 32
  %.state629 = load <8 x float>, ptr %.slot35, align 32
  %1279 = fsub <8 x float> %.state629, %1276
  %1280 = select <8 x i1> %71, <8 x float> %1279, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1280)
  %1281 = load <8 x float>, ptr %.spill114, align 32
  %1282 = select <8 x i1> %71, <8 x float> %native.exp, <8 x float> %1281
  store <8 x float> %1282, ptr %.spill114, align 32
  %.spill.load630 = load <8 x float>, ptr %.spill94, align 32
  %1283 = fsub <8 x float> %.spill.load630, %1276
  %.spill.load631 = load <8 x float>, ptr %.spill95, align 32
  %1284 = fsub <8 x float> %.spill.load631, %1276
  %.spill.load632 = load <8 x float>, ptr %.spill96, align 32
  %1285 = fsub <8 x float> %.spill.load632, %1276
  %.spill.load633 = load <8 x float>, ptr %.spill97, align 32
  %1286 = fsub <8 x float> %.spill.load633, %1276
  %.spill.load634 = load <8 x float>, ptr %.spill98, align 32
  %1287 = fsub <8 x float> %.spill.load634, %1276
  %.spill.load635 = load <8 x float>, ptr %.spill99, align 32
  %1288 = fsub <8 x float> %.spill.load635, %1276
  %.spill.load636 = load <8 x float>, ptr %.spill100, align 32
  %1289 = fsub <8 x float> %.spill.load636, %1276
  %.spill.load637 = load <8 x float>, ptr %.spill101, align 32
  %1290 = fsub <8 x float> %.spill.load637, %1276
  %.spill.load638 = load <8 x float>, ptr %.spill102, align 32
  %1291 = fsub <8 x float> %.spill.load638, %1276
  %.spill.load639 = load <8 x float>, ptr %.spill103, align 32
  %1292 = fsub <8 x float> %.spill.load639, %1276
  %.spill.load640 = load <8 x float>, ptr %.spill104, align 32
  %1293 = fsub <8 x float> %.spill.load640, %1276
  %.spill.load641 = load <8 x float>, ptr %.spill105, align 32
  %1294 = fsub <8 x float> %.spill.load641, %1276
  %.spill.load642 = load <8 x float>, ptr %.spill106, align 32
  %1295 = fsub <8 x float> %.spill.load642, %1276
  %.spill.load643 = load <8 x float>, ptr %.spill107, align 32
  %1296 = fsub <8 x float> %.spill.load643, %1276
  %.spill.load644 = load <8 x float>, ptr %.spill108, align 32
  %1297 = fsub <8 x float> %.spill.load644, %1276
  %.spill.load645 = load <8 x float>, ptr %.spill109, align 32
  %1298 = fsub <8 x float> %.spill.load645, %1276
  %1299 = select <8 x i1> %71, <8 x float> %1283, <8 x float> zeroinitializer
  %native.exp646 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1299)
  %1300 = select <8 x i1> %71, <8 x float> %1284, <8 x float> zeroinitializer
  %native.exp647 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1300)
  %1301 = select <8 x i1> %71, <8 x float> %1285, <8 x float> zeroinitializer
  %native.exp648 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1301)
  %1302 = select <8 x i1> %71, <8 x float> %1286, <8 x float> zeroinitializer
  %native.exp649 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1302)
  %1303 = select <8 x i1> %71, <8 x float> %1287, <8 x float> zeroinitializer
  %native.exp650 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1303)
  %1304 = select <8 x i1> %71, <8 x float> %1288, <8 x float> zeroinitializer
  %native.exp651 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1304)
  %1305 = select <8 x i1> %71, <8 x float> %1289, <8 x float> zeroinitializer
  %native.exp652 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1305)
  %1306 = select <8 x i1> %71, <8 x float> %1290, <8 x float> zeroinitializer
  %native.exp653 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1306)
  %1307 = select <8 x i1> %71, <8 x float> %1291, <8 x float> zeroinitializer
  %native.exp654 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1307)
  %1308 = select <8 x i1> %71, <8 x float> %1292, <8 x float> zeroinitializer
  %native.exp655 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1308)
  %1309 = select <8 x i1> %71, <8 x float> %1293, <8 x float> zeroinitializer
  %native.exp656 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1309)
  %1310 = select <8 x i1> %71, <8 x float> %1294, <8 x float> zeroinitializer
  %native.exp657 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1310)
  %1311 = select <8 x i1> %71, <8 x float> %1295, <8 x float> zeroinitializer
  %native.exp658 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1311)
  %1312 = select <8 x i1> %71, <8 x float> %1296, <8 x float> zeroinitializer
  %native.exp659 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1312)
  %1313 = select <8 x i1> %71, <8 x float> %1297, <8 x float> zeroinitializer
  %native.exp660 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1313)
  %1314 = select <8 x i1> %71, <8 x float> %1298, <8 x float> zeroinitializer
  %native.exp661 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1314)
  %.spill.load662 = load <8 x i1>, ptr %.spill78, align 1
  %1315 = select <8 x i1> %.spill.load662, <8 x float> %native.exp646, <8 x float> zeroinitializer
  %1316 = load <8 x float>, ptr %.spill115, align 32
  %1317 = select <8 x i1> %71, <8 x float> %1315, <8 x float> %1316
  store <8 x float> %1317, ptr %.spill115, align 32
  %.spill.load663 = load <8 x i1>, ptr %.spill79, align 1
  %1318 = select <8 x i1> %.spill.load663, <8 x float> %native.exp647, <8 x float> zeroinitializer
  %1319 = load <8 x float>, ptr %.spill116, align 32
  %1320 = select <8 x i1> %71, <8 x float> %1318, <8 x float> %1319
  store <8 x float> %1320, ptr %.spill116, align 32
  %.spill.load664 = load <8 x i1>, ptr %.spill80, align 1
  %1321 = select <8 x i1> %.spill.load664, <8 x float> %native.exp648, <8 x float> zeroinitializer
  %1322 = load <8 x float>, ptr %.spill117, align 32
  %1323 = select <8 x i1> %71, <8 x float> %1321, <8 x float> %1322
  store <8 x float> %1323, ptr %.spill117, align 32
  %.spill.load665 = load <8 x i1>, ptr %.spill81, align 1
  %1324 = select <8 x i1> %.spill.load665, <8 x float> %native.exp649, <8 x float> zeroinitializer
  %1325 = load <8 x float>, ptr %.spill118, align 32
  %1326 = select <8 x i1> %71, <8 x float> %1324, <8 x float> %1325
  store <8 x float> %1326, ptr %.spill118, align 32
  %.spill.load666 = load <8 x i1>, ptr %.spill82, align 1
  %1327 = select <8 x i1> %.spill.load666, <8 x float> %native.exp650, <8 x float> zeroinitializer
  %1328 = load <8 x float>, ptr %.spill119, align 32
  %1329 = select <8 x i1> %71, <8 x float> %1327, <8 x float> %1328
  store <8 x float> %1329, ptr %.spill119, align 32
  %.spill.load667 = load <8 x i1>, ptr %.spill83, align 1
  %1330 = select <8 x i1> %.spill.load667, <8 x float> %native.exp651, <8 x float> zeroinitializer
  %1331 = load <8 x float>, ptr %.spill120, align 32
  %1332 = select <8 x i1> %71, <8 x float> %1330, <8 x float> %1331
  store <8 x float> %1332, ptr %.spill120, align 32
  %.spill.load668 = load <8 x i1>, ptr %.spill84, align 1
  %1333 = select <8 x i1> %.spill.load668, <8 x float> %native.exp652, <8 x float> zeroinitializer
  %1334 = load <8 x float>, ptr %.spill121, align 32
  %1335 = select <8 x i1> %71, <8 x float> %1333, <8 x float> %1334
  store <8 x float> %1335, ptr %.spill121, align 32
  %.spill.load669 = load <8 x i1>, ptr %.spill85, align 1
  %1336 = select <8 x i1> %.spill.load669, <8 x float> %native.exp653, <8 x float> zeroinitializer
  %1337 = load <8 x float>, ptr %.spill122, align 32
  %1338 = select <8 x i1> %71, <8 x float> %1336, <8 x float> %1337
  store <8 x float> %1338, ptr %.spill122, align 32
  %.spill.load670 = load <8 x i1>, ptr %.spill86, align 1
  %1339 = select <8 x i1> %.spill.load670, <8 x float> %native.exp654, <8 x float> zeroinitializer
  %1340 = load <8 x float>, ptr %.spill123, align 32
  %1341 = select <8 x i1> %71, <8 x float> %1339, <8 x float> %1340
  store <8 x float> %1341, ptr %.spill123, align 32
  %.spill.load671 = load <8 x i1>, ptr %.spill87, align 1
  %1342 = select <8 x i1> %.spill.load671, <8 x float> %native.exp655, <8 x float> zeroinitializer
  %1343 = load <8 x float>, ptr %.spill124, align 32
  %1344 = select <8 x i1> %71, <8 x float> %1342, <8 x float> %1343
  store <8 x float> %1344, ptr %.spill124, align 32
  %.spill.load672 = load <8 x i1>, ptr %.spill88, align 1
  %1345 = select <8 x i1> %.spill.load672, <8 x float> %native.exp656, <8 x float> zeroinitializer
  %1346 = load <8 x float>, ptr %.spill125, align 32
  %1347 = select <8 x i1> %71, <8 x float> %1345, <8 x float> %1346
  store <8 x float> %1347, ptr %.spill125, align 32
  %.spill.load673 = load <8 x i1>, ptr %.spill89, align 1
  %1348 = select <8 x i1> %.spill.load673, <8 x float> %native.exp657, <8 x float> zeroinitializer
  %1349 = load <8 x float>, ptr %.spill126, align 32
  %1350 = select <8 x i1> %71, <8 x float> %1348, <8 x float> %1349
  store <8 x float> %1350, ptr %.spill126, align 32
  %.spill.load674 = load <8 x i1>, ptr %.spill90, align 1
  %1351 = select <8 x i1> %.spill.load674, <8 x float> %native.exp658, <8 x float> zeroinitializer
  %1352 = load <8 x float>, ptr %.spill127, align 32
  %1353 = select <8 x i1> %71, <8 x float> %1351, <8 x float> %1352
  store <8 x float> %1353, ptr %.spill127, align 32
  %.spill.load675 = load <8 x i1>, ptr %.spill91, align 1
  %1354 = select <8 x i1> %.spill.load675, <8 x float> %native.exp659, <8 x float> zeroinitializer
  %1355 = load <8 x float>, ptr %.spill128, align 32
  %1356 = select <8 x i1> %71, <8 x float> %1354, <8 x float> %1355
  store <8 x float> %1356, ptr %.spill128, align 32
  %.spill.load676 = load <8 x i1>, ptr %.spill92, align 1
  %1357 = select <8 x i1> %.spill.load676, <8 x float> %native.exp660, <8 x float> zeroinitializer
  %1358 = load <8 x float>, ptr %.spill129, align 32
  %1359 = select <8 x i1> %71, <8 x float> %1357, <8 x float> %1358
  store <8 x float> %1359, ptr %.spill129, align 32
  %.spill.load677 = load <8 x i1>, ptr %.spill93, align 1
  %1360 = select <8 x i1> %.spill.load677, <8 x float> %native.exp661, <8 x float> zeroinitializer
  %1361 = load <8 x float>, ptr %.spill130, align 32
  %1362 = select <8 x i1> %71, <8 x float> %1360, <8 x float> %1361
  store <8 x float> %1362, ptr %.spill130, align 32
  %1363 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill131, align 64
  %1364 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1365 = extractvalue { <8 x ptr>, <8 x i64> } %1363, 0
  %1366 = select <8 x i1> %71, <8 x ptr> %1364, <8 x ptr> %1365
  %1367 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1368 = extractvalue { <8 x ptr>, <8 x i64> } %1363, 1
  %1369 = select <8 x i1> %71, <8 x i64> %1367, <8 x i64> %1368
  %1370 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1366, 0
  %1371 = insertvalue { <8 x ptr>, <8 x i64> } %1370, <8 x i64> %1369, 1
  store { <8 x ptr>, <8 x i64> } %1371, ptr %tile_snapshot.spill131, align 64
  %1372 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1373 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1374 = add <8 x i64> %1373, zeroinitializer
  %1375 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1372, 0
  %1376 = insertvalue { <8 x ptr>, <8 x i64> } %1375, <8 x i64> %1374, 1
  %1377 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1378 = extractvalue { <8 x ptr>, <8 x i64> } %1376, 1
  %1379 = extractelement <8 x ptr> %1377, i32 0
  %1380 = extractelement <8 x i64> %1378, i32 0
  %1381 = sub i64 %1380, 0
  %1382 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1383 = select i1 %1382, i64 %1381, i64 0
  %private.contiguous.address678 = getelementptr i8, ptr %1379, i64 %1383
  %private.contiguous.preserve679 = load <8 x float>, ptr %private.contiguous.address678, align 4
  %1384 = select <8 x i1> %71, <8 x float> %1315, <8 x float> %private.contiguous.preserve679
  store <8 x float> %1384, ptr %private.contiguous.address678, align 4
  %1385 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1386 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1387 = add <8 x i64> %1386, splat (i64 32)
  %1388 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1385, 0
  %1389 = insertvalue { <8 x ptr>, <8 x i64> } %1388, <8 x i64> %1387, 1
  %1390 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1391 = extractvalue { <8 x ptr>, <8 x i64> } %1389, 1
  %1392 = extractelement <8 x ptr> %1390, i32 0
  %1393 = extractelement <8 x i64> %1391, i32 0
  %1394 = sub i64 %1393, 0
  %1395 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1396 = select i1 %1395, i64 %1394, i64 0
  %private.contiguous.address680 = getelementptr i8, ptr %1392, i64 %1396
  %private.contiguous.preserve681 = load <8 x float>, ptr %private.contiguous.address680, align 4
  %1397 = select <8 x i1> %71, <8 x float> %1318, <8 x float> %private.contiguous.preserve681
  store <8 x float> %1397, ptr %private.contiguous.address680, align 4
  %1398 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1399 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1400 = add <8 x i64> %1399, splat (i64 64)
  %1401 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1398, 0
  %1402 = insertvalue { <8 x ptr>, <8 x i64> } %1401, <8 x i64> %1400, 1
  %1403 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1404 = extractvalue { <8 x ptr>, <8 x i64> } %1402, 1
  %1405 = extractelement <8 x ptr> %1403, i32 0
  %1406 = extractelement <8 x i64> %1404, i32 0
  %1407 = sub i64 %1406, 0
  %1408 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1409 = select i1 %1408, i64 %1407, i64 0
  %private.contiguous.address682 = getelementptr i8, ptr %1405, i64 %1409
  %private.contiguous.preserve683 = load <8 x float>, ptr %private.contiguous.address682, align 4
  %1410 = select <8 x i1> %71, <8 x float> %1321, <8 x float> %private.contiguous.preserve683
  store <8 x float> %1410, ptr %private.contiguous.address682, align 4
  %1411 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1412 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1413 = add <8 x i64> %1412, splat (i64 96)
  %1414 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1411, 0
  %1415 = insertvalue { <8 x ptr>, <8 x i64> } %1414, <8 x i64> %1413, 1
  %1416 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1417 = extractvalue { <8 x ptr>, <8 x i64> } %1415, 1
  %1418 = extractelement <8 x ptr> %1416, i32 0
  %1419 = extractelement <8 x i64> %1417, i32 0
  %1420 = sub i64 %1419, 0
  %1421 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1422 = select i1 %1421, i64 %1420, i64 0
  %private.contiguous.address684 = getelementptr i8, ptr %1418, i64 %1422
  %private.contiguous.preserve685 = load <8 x float>, ptr %private.contiguous.address684, align 4
  %1423 = select <8 x i1> %71, <8 x float> %1324, <8 x float> %private.contiguous.preserve685
  store <8 x float> %1423, ptr %private.contiguous.address684, align 4
  %1424 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1425 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1426 = add <8 x i64> %1425, splat (i64 128)
  %1427 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1424, 0
  %1428 = insertvalue { <8 x ptr>, <8 x i64> } %1427, <8 x i64> %1426, 1
  %1429 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1430 = extractvalue { <8 x ptr>, <8 x i64> } %1428, 1
  %1431 = extractelement <8 x ptr> %1429, i32 0
  %1432 = extractelement <8 x i64> %1430, i32 0
  %1433 = sub i64 %1432, 0
  %1434 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1435 = select i1 %1434, i64 %1433, i64 0
  %private.contiguous.address686 = getelementptr i8, ptr %1431, i64 %1435
  %private.contiguous.preserve687 = load <8 x float>, ptr %private.contiguous.address686, align 4
  %1436 = select <8 x i1> %71, <8 x float> %1327, <8 x float> %private.contiguous.preserve687
  store <8 x float> %1436, ptr %private.contiguous.address686, align 4
  %1437 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1438 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1439 = add <8 x i64> %1438, splat (i64 160)
  %1440 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1437, 0
  %1441 = insertvalue { <8 x ptr>, <8 x i64> } %1440, <8 x i64> %1439, 1
  %1442 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1443 = extractvalue { <8 x ptr>, <8 x i64> } %1441, 1
  %1444 = extractelement <8 x ptr> %1442, i32 0
  %1445 = extractelement <8 x i64> %1443, i32 0
  %1446 = sub i64 %1445, 0
  %1447 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1448 = select i1 %1447, i64 %1446, i64 0
  %private.contiguous.address688 = getelementptr i8, ptr %1444, i64 %1448
  %private.contiguous.preserve689 = load <8 x float>, ptr %private.contiguous.address688, align 4
  %1449 = select <8 x i1> %71, <8 x float> %1330, <8 x float> %private.contiguous.preserve689
  store <8 x float> %1449, ptr %private.contiguous.address688, align 4
  %1450 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1451 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1452 = add <8 x i64> %1451, splat (i64 192)
  %1453 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1450, 0
  %1454 = insertvalue { <8 x ptr>, <8 x i64> } %1453, <8 x i64> %1452, 1
  %1455 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1456 = extractvalue { <8 x ptr>, <8 x i64> } %1454, 1
  %1457 = extractelement <8 x ptr> %1455, i32 0
  %1458 = extractelement <8 x i64> %1456, i32 0
  %1459 = sub i64 %1458, 0
  %1460 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1461 = select i1 %1460, i64 %1459, i64 0
  %private.contiguous.address690 = getelementptr i8, ptr %1457, i64 %1461
  %private.contiguous.preserve691 = load <8 x float>, ptr %private.contiguous.address690, align 4
  %1462 = select <8 x i1> %71, <8 x float> %1333, <8 x float> %private.contiguous.preserve691
  store <8 x float> %1462, ptr %private.contiguous.address690, align 4
  %1463 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1464 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1465 = add <8 x i64> %1464, splat (i64 224)
  %1466 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1463, 0
  %1467 = insertvalue { <8 x ptr>, <8 x i64> } %1466, <8 x i64> %1465, 1
  %1468 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1469 = extractvalue { <8 x ptr>, <8 x i64> } %1467, 1
  %1470 = extractelement <8 x ptr> %1468, i32 0
  %1471 = extractelement <8 x i64> %1469, i32 0
  %1472 = sub i64 %1471, 0
  %1473 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1474 = select i1 %1473, i64 %1472, i64 0
  %private.contiguous.address692 = getelementptr i8, ptr %1470, i64 %1474
  %private.contiguous.preserve693 = load <8 x float>, ptr %private.contiguous.address692, align 4
  %1475 = select <8 x i1> %71, <8 x float> %1336, <8 x float> %private.contiguous.preserve693
  store <8 x float> %1475, ptr %private.contiguous.address692, align 4
  %1476 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1477 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1478 = add <8 x i64> %1477, splat (i64 256)
  %1479 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1476, 0
  %1480 = insertvalue { <8 x ptr>, <8 x i64> } %1479, <8 x i64> %1478, 1
  %1481 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1482 = extractvalue { <8 x ptr>, <8 x i64> } %1480, 1
  %1483 = extractelement <8 x ptr> %1481, i32 0
  %1484 = extractelement <8 x i64> %1482, i32 0
  %1485 = sub i64 %1484, 0
  %1486 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1487 = select i1 %1486, i64 %1485, i64 0
  %private.contiguous.address694 = getelementptr i8, ptr %1483, i64 %1487
  %private.contiguous.preserve695 = load <8 x float>, ptr %private.contiguous.address694, align 4
  %1488 = select <8 x i1> %71, <8 x float> %1339, <8 x float> %private.contiguous.preserve695
  store <8 x float> %1488, ptr %private.contiguous.address694, align 4
  %1489 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1490 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1491 = add <8 x i64> %1490, splat (i64 288)
  %1492 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1489, 0
  %1493 = insertvalue { <8 x ptr>, <8 x i64> } %1492, <8 x i64> %1491, 1
  %1494 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1495 = extractvalue { <8 x ptr>, <8 x i64> } %1493, 1
  %1496 = extractelement <8 x ptr> %1494, i32 0
  %1497 = extractelement <8 x i64> %1495, i32 0
  %1498 = sub i64 %1497, 0
  %1499 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1500 = select i1 %1499, i64 %1498, i64 0
  %private.contiguous.address696 = getelementptr i8, ptr %1496, i64 %1500
  %private.contiguous.preserve697 = load <8 x float>, ptr %private.contiguous.address696, align 4
  %1501 = select <8 x i1> %71, <8 x float> %1342, <8 x float> %private.contiguous.preserve697
  store <8 x float> %1501, ptr %private.contiguous.address696, align 4
  %1502 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1503 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1504 = add <8 x i64> %1503, splat (i64 320)
  %1505 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1502, 0
  %1506 = insertvalue { <8 x ptr>, <8 x i64> } %1505, <8 x i64> %1504, 1
  %1507 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1508 = extractvalue { <8 x ptr>, <8 x i64> } %1506, 1
  %1509 = extractelement <8 x ptr> %1507, i32 0
  %1510 = extractelement <8 x i64> %1508, i32 0
  %1511 = sub i64 %1510, 0
  %1512 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1513 = select i1 %1512, i64 %1511, i64 0
  %private.contiguous.address698 = getelementptr i8, ptr %1509, i64 %1513
  %private.contiguous.preserve699 = load <8 x float>, ptr %private.contiguous.address698, align 4
  %1514 = select <8 x i1> %71, <8 x float> %1345, <8 x float> %private.contiguous.preserve699
  store <8 x float> %1514, ptr %private.contiguous.address698, align 4
  %1515 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1516 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1517 = add <8 x i64> %1516, splat (i64 352)
  %1518 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1515, 0
  %1519 = insertvalue { <8 x ptr>, <8 x i64> } %1518, <8 x i64> %1517, 1
  %1520 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1521 = extractvalue { <8 x ptr>, <8 x i64> } %1519, 1
  %1522 = extractelement <8 x ptr> %1520, i32 0
  %1523 = extractelement <8 x i64> %1521, i32 0
  %1524 = sub i64 %1523, 0
  %1525 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1526 = select i1 %1525, i64 %1524, i64 0
  %private.contiguous.address700 = getelementptr i8, ptr %1522, i64 %1526
  %private.contiguous.preserve701 = load <8 x float>, ptr %private.contiguous.address700, align 4
  %1527 = select <8 x i1> %71, <8 x float> %1348, <8 x float> %private.contiguous.preserve701
  store <8 x float> %1527, ptr %private.contiguous.address700, align 4
  %1528 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1529 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1530 = add <8 x i64> %1529, splat (i64 384)
  %1531 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1528, 0
  %1532 = insertvalue { <8 x ptr>, <8 x i64> } %1531, <8 x i64> %1530, 1
  %1533 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1534 = extractvalue { <8 x ptr>, <8 x i64> } %1532, 1
  %1535 = extractelement <8 x ptr> %1533, i32 0
  %1536 = extractelement <8 x i64> %1534, i32 0
  %1537 = sub i64 %1536, 0
  %1538 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1539 = select i1 %1538, i64 %1537, i64 0
  %private.contiguous.address702 = getelementptr i8, ptr %1535, i64 %1539
  %private.contiguous.preserve703 = load <8 x float>, ptr %private.contiguous.address702, align 4
  %1540 = select <8 x i1> %71, <8 x float> %1351, <8 x float> %private.contiguous.preserve703
  store <8 x float> %1540, ptr %private.contiguous.address702, align 4
  %1541 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1542 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1543 = add <8 x i64> %1542, splat (i64 416)
  %1544 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1541, 0
  %1545 = insertvalue { <8 x ptr>, <8 x i64> } %1544, <8 x i64> %1543, 1
  %1546 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1547 = extractvalue { <8 x ptr>, <8 x i64> } %1545, 1
  %1548 = extractelement <8 x ptr> %1546, i32 0
  %1549 = extractelement <8 x i64> %1547, i32 0
  %1550 = sub i64 %1549, 0
  %1551 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1552 = select i1 %1551, i64 %1550, i64 0
  %private.contiguous.address704 = getelementptr i8, ptr %1548, i64 %1552
  %private.contiguous.preserve705 = load <8 x float>, ptr %private.contiguous.address704, align 4
  %1553 = select <8 x i1> %71, <8 x float> %1354, <8 x float> %private.contiguous.preserve705
  store <8 x float> %1553, ptr %private.contiguous.address704, align 4
  %1554 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1555 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1556 = add <8 x i64> %1555, splat (i64 448)
  %1557 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1554, 0
  %1558 = insertvalue { <8 x ptr>, <8 x i64> } %1557, <8 x i64> %1556, 1
  %1559 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1560 = extractvalue { <8 x ptr>, <8 x i64> } %1558, 1
  %1561 = extractelement <8 x ptr> %1559, i32 0
  %1562 = extractelement <8 x i64> %1560, i32 0
  %1563 = sub i64 %1562, 0
  %1564 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1565 = select i1 %1564, i64 %1563, i64 0
  %private.contiguous.address706 = getelementptr i8, ptr %1561, i64 %1565
  %private.contiguous.preserve707 = load <8 x float>, ptr %private.contiguous.address706, align 4
  %1566 = select <8 x i1> %71, <8 x float> %1357, <8 x float> %private.contiguous.preserve707
  store <8 x float> %1566, ptr %private.contiguous.address706, align 4
  %1567 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1568 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1569 = add <8 x i64> %1568, splat (i64 480)
  %1570 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1567, 0
  %1571 = insertvalue { <8 x ptr>, <8 x i64> } %1570, <8 x i64> %1569, 1
  %1572 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1573 = extractvalue { <8 x ptr>, <8 x i64> } %1571, 1
  %1574 = extractelement <8 x ptr> %1572, i32 0
  %1575 = extractelement <8 x i64> %1573, i32 0
  %1576 = sub i64 %1575, 0
  %1577 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1578 = select i1 %1577, i64 %1576, i64 0
  %private.contiguous.address708 = getelementptr i8, ptr %1574, i64 %1578
  %private.contiguous.preserve709 = load <8 x float>, ptr %private.contiguous.address708, align 4
  %1579 = select <8 x i1> %71, <8 x float> %1360, <8 x float> %private.contiguous.preserve709
  store <8 x float> %1579, ptr %private.contiguous.address708, align 4
  %.state710 = load <8 x float>, ptr %.slot36, align 32
  %1580 = fmul <8 x float> %.state710, %native.exp
  %1581 = load <8 x float>, ptr %.spill132, align 32
  %1582 = select <8 x i1> %71, <8 x float> %1580, <8 x float> %1581
  store <8 x float> %1582, ptr %.spill132, align 32
  store i64 0, ptr %.slot133, align 4
  %1583 = load <8 x float>, ptr %.slot134, align 32
  %1584 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1583
  store <8 x float> %1584, ptr %.slot134, align 32
  br label %direct.schedule.70

direct.schedule.70:                               ; preds = %direct.schedule.71, %direct.schedule.69
  %.state711 = load i64, ptr %.slot133, align 4
  %1585 = icmp slt i64 %.state711, 16
  br i1 %1585, label %direct.true712, label %direct.false713

direct.schedule.71:                               ; preds = %direct.true712
  %.state714 = load i64, ptr %.slot133, align 4
  %1586 = sdiv i64 %.state714, 1
  %1587 = add i64 0, %1586
  %tile_snapshot.spill.load715 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill131, align 64
  %1588 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load715, 0
  %1589 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load715, 1
  %.splatinsert716 = insertelement <8 x i64> poison, i64 %1587, i64 0
  %.splat717 = shufflevector <8 x i64> %.splatinsert716, <8 x i64> poison, <8 x i32> zeroinitializer
  %1590 = mul <8 x i64> %.splat717, splat (i64 32)
  %1591 = add <8 x i64> %1589, %1590
  %1592 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1588, 0
  %1593 = insertvalue { <8 x ptr>, <8 x i64> } %1592, <8 x i64> %1591, 1
  %1594 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1595 = extractvalue { <8 x ptr>, <8 x i64> } %1593, 1
  %1596 = extractelement <8 x ptr> %1594, i32 0
  %1597 = extractelement <8 x i64> %1595, i32 0
  %1598 = sub i64 %1597, 0
  %1599 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1600 = select i1 %1599, i64 %1598, i64 0
  %private.contiguous.address718 = getelementptr i8, ptr %1596, i64 %1600
  %private.contiguous.load719 = load <8 x float>, ptr %private.contiguous.address718, align 4
  %1601 = select <8 x i1> %71, <8 x float> %private.contiguous.load719, <8 x float> zeroinitializer
  %.state720 = load <8 x float>, ptr %.slot134, align 32
  %1602 = fadd <8 x float> %.state720, %1601
  %.state721 = load i64, ptr %.slot133, align 4
  %1603 = add i64 %.state721, 1
  store i64 %1603, ptr %.slot133, align 4
  %1604 = load <8 x float>, ptr %.slot134, align 32
  %1605 = select <8 x i1> %71, <8 x float> %1602, <8 x float> %1604
  store <8 x float> %1605, ptr %.slot134, align 32
  br label %direct.schedule.70

direct.schedule.72:                               ; preds = %direct.false713
  %.spill.load722 = load <8 x float>, ptr %.spill132, align 32
  %.state723 = load <8 x float>, ptr %.slot134, align 32
  %1606 = fadd <8 x float> %.spill.load722, %.state723
  %1607 = load <8 x float>, ptr %.spill135, align 32
  %1608 = select <8 x i1> %71, <8 x float> %1606, <8 x float> %1607
  store <8 x float> %1608, ptr %.spill135, align 32
  %1609 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill136, align 64
  %1610 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1611 = extractvalue { <8 x ptr>, <8 x i64> } %1609, 0
  %1612 = select <8 x i1> %71, <8 x ptr> %1610, <8 x ptr> %1611
  %1613 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1614 = extractvalue { <8 x ptr>, <8 x i64> } %1609, 1
  %1615 = select <8 x i1> %71, <8 x i64> %1613, <8 x i64> %1614
  %1616 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1612, 0
  %1617 = insertvalue { <8 x ptr>, <8 x i64> } %1616, <8 x i64> %1615, 1
  store { <8 x ptr>, <8 x i64> } %1617, ptr %tile_snapshot.spill136, align 64
  store i64 0, ptr %.slot137, align 4
  br label %direct.schedule.73

direct.schedule.73:                               ; preds = %direct.schedule.74, %direct.schedule.72
  %.state724 = load i64, ptr %.slot137, align 4
  %1618 = icmp slt i64 %.state724, 96
  br i1 %1618, label %direct.true725, label %direct.false726

direct.schedule.74:                               ; preds = %direct.true725
  %.state727 = load i64, ptr %.slot137, align 4
  %1619 = add i64 0, %.state727
  %tile_snapshot.spill.load728 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1620 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load728, 0
  %1621 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load728, 1
  %.splatinsert729 = insertelement <8 x i64> poison, i64 %1619, i64 0
  %.splat730 = shufflevector <8 x i64> %.splatinsert729, <8 x i64> poison, <8 x i32> zeroinitializer
  %1622 = mul <8 x i64> %.splat730, splat (i64 32)
  %1623 = add <8 x i64> %1621, %1622
  %1624 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1620, 0
  %1625 = insertvalue { <8 x ptr>, <8 x i64> } %1624, <8 x i64> %1623, 1
  %1626 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1627 = extractvalue { <8 x ptr>, <8 x i64> } %1625, 1
  %1628 = extractelement <8 x ptr> %1626, i32 0
  %1629 = extractelement <8 x i64> %1627, i32 0
  %1630 = sub i64 %1629, 0
  %1631 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1632 = select i1 %1631, i64 %1630, i64 0
  %private.contiguous.address731 = getelementptr i8, ptr %1628, i64 %1632
  %private.contiguous.load732 = load <8 x float>, ptr %private.contiguous.address731, align 4
  %1633 = select <8 x i1> %71, <8 x float> %private.contiguous.load732, <8 x float> zeroinitializer
  %.spill.load733 = load <8 x float>, ptr %.spill114, align 32
  %1634 = fmul <8 x float> %1633, %.spill.load733
  %tile_snapshot.spill.load734 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1635 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load734, 0
  %1636 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load734, 1
  %.splatinsert735 = insertelement <8 x i64> poison, i64 %1619, i64 0
  %.splat736 = shufflevector <8 x i64> %.splatinsert735, <8 x i64> poison, <8 x i32> zeroinitializer
  %1637 = mul <8 x i64> %.splat736, splat (i64 32)
  %1638 = add <8 x i64> %1636, %1637
  %1639 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1635, 0
  %1640 = insertvalue { <8 x ptr>, <8 x i64> } %1639, <8 x i64> %1638, 1
  %1641 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1642 = extractvalue { <8 x ptr>, <8 x i64> } %1640, 1
  %1643 = extractelement <8 x ptr> %1641, i32 0
  %1644 = extractelement <8 x i64> %1642, i32 0
  %1645 = sub i64 %1644, 0
  %1646 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1647 = select i1 %1646, i64 %1645, i64 0
  %private.contiguous.address737 = getelementptr i8, ptr %1643, i64 %1647
  %private.contiguous.load738 = load <8 x float>, ptr %private.contiguous.address737, align 4
  %1648 = select <8 x i1> %71, <8 x float> %private.contiguous.load738, <8 x float> zeroinitializer
  %.spill.load739 = load <8 x float>, ptr %.spill115, align 32
  %1649 = fmul <8 x float> %.spill.load739, %1648
  %1650 = fadd <8 x float> %1634, %1649
  %.state740 = load i64, ptr %.slot137, align 4
  %1651 = add i64 96, %.state740
  %tile_snapshot.spill.load741 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1652 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load741, 0
  %1653 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load741, 1
  %.splatinsert742 = insertelement <8 x i64> poison, i64 %1651, i64 0
  %.splat743 = shufflevector <8 x i64> %.splatinsert742, <8 x i64> poison, <8 x i32> zeroinitializer
  %1654 = mul <8 x i64> %.splat743, splat (i64 32)
  %1655 = add <8 x i64> %1653, %1654
  %1656 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1652, 0
  %1657 = insertvalue { <8 x ptr>, <8 x i64> } %1656, <8 x i64> %1655, 1
  %1658 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1659 = extractvalue { <8 x ptr>, <8 x i64> } %1657, 1
  %1660 = extractelement <8 x ptr> %1658, i32 0
  %1661 = extractelement <8 x i64> %1659, i32 0
  %1662 = sub i64 %1661, 0
  %1663 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1664 = select i1 %1663, i64 %1662, i64 0
  %private.contiguous.address744 = getelementptr i8, ptr %1660, i64 %1664
  %private.contiguous.load745 = load <8 x float>, ptr %private.contiguous.address744, align 4
  %1665 = select <8 x i1> %71, <8 x float> %private.contiguous.load745, <8 x float> zeroinitializer
  %.spill.load746 = load <8 x float>, ptr %.spill116, align 32
  %1666 = fmul <8 x float> %.spill.load746, %1665
  %1667 = fadd <8 x float> %1650, %1666
  %.state747 = load i64, ptr %.slot137, align 4
  %1668 = add i64 192, %.state747
  %tile_snapshot.spill.load748 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1669 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load748, 0
  %1670 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load748, 1
  %.splatinsert749 = insertelement <8 x i64> poison, i64 %1668, i64 0
  %.splat750 = shufflevector <8 x i64> %.splatinsert749, <8 x i64> poison, <8 x i32> zeroinitializer
  %1671 = mul <8 x i64> %.splat750, splat (i64 32)
  %1672 = add <8 x i64> %1670, %1671
  %1673 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1669, 0
  %1674 = insertvalue { <8 x ptr>, <8 x i64> } %1673, <8 x i64> %1672, 1
  %1675 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1676 = extractvalue { <8 x ptr>, <8 x i64> } %1674, 1
  %1677 = extractelement <8 x ptr> %1675, i32 0
  %1678 = extractelement <8 x i64> %1676, i32 0
  %1679 = sub i64 %1678, 0
  %1680 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1681 = select i1 %1680, i64 %1679, i64 0
  %private.contiguous.address751 = getelementptr i8, ptr %1677, i64 %1681
  %private.contiguous.load752 = load <8 x float>, ptr %private.contiguous.address751, align 4
  %1682 = select <8 x i1> %71, <8 x float> %private.contiguous.load752, <8 x float> zeroinitializer
  %.spill.load753 = load <8 x float>, ptr %.spill117, align 32
  %1683 = fmul <8 x float> %.spill.load753, %1682
  %1684 = fadd <8 x float> %1667, %1683
  %.state754 = load i64, ptr %.slot137, align 4
  %1685 = add i64 288, %.state754
  %tile_snapshot.spill.load755 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1686 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load755, 0
  %1687 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load755, 1
  %.splatinsert756 = insertelement <8 x i64> poison, i64 %1685, i64 0
  %.splat757 = shufflevector <8 x i64> %.splatinsert756, <8 x i64> poison, <8 x i32> zeroinitializer
  %1688 = mul <8 x i64> %.splat757, splat (i64 32)
  %1689 = add <8 x i64> %1687, %1688
  %1690 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1686, 0
  %1691 = insertvalue { <8 x ptr>, <8 x i64> } %1690, <8 x i64> %1689, 1
  %1692 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1693 = extractvalue { <8 x ptr>, <8 x i64> } %1691, 1
  %1694 = extractelement <8 x ptr> %1692, i32 0
  %1695 = extractelement <8 x i64> %1693, i32 0
  %1696 = sub i64 %1695, 0
  %1697 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1698 = select i1 %1697, i64 %1696, i64 0
  %private.contiguous.address758 = getelementptr i8, ptr %1694, i64 %1698
  %private.contiguous.load759 = load <8 x float>, ptr %private.contiguous.address758, align 4
  %1699 = select <8 x i1> %71, <8 x float> %private.contiguous.load759, <8 x float> zeroinitializer
  %.spill.load760 = load <8 x float>, ptr %.spill118, align 32
  %1700 = fmul <8 x float> %.spill.load760, %1699
  %1701 = fadd <8 x float> %1684, %1700
  %.state761 = load i64, ptr %.slot137, align 4
  %1702 = add i64 384, %.state761
  %tile_snapshot.spill.load762 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1703 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 0
  %1704 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 1
  %.splatinsert763 = insertelement <8 x i64> poison, i64 %1702, i64 0
  %.splat764 = shufflevector <8 x i64> %.splatinsert763, <8 x i64> poison, <8 x i32> zeroinitializer
  %1705 = mul <8 x i64> %.splat764, splat (i64 32)
  %1706 = add <8 x i64> %1704, %1705
  %1707 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1703, 0
  %1708 = insertvalue { <8 x ptr>, <8 x i64> } %1707, <8 x i64> %1706, 1
  %1709 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1710 = extractvalue { <8 x ptr>, <8 x i64> } %1708, 1
  %1711 = extractelement <8 x ptr> %1709, i32 0
  %1712 = extractelement <8 x i64> %1710, i32 0
  %1713 = sub i64 %1712, 0
  %1714 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1715 = select i1 %1714, i64 %1713, i64 0
  %private.contiguous.address765 = getelementptr i8, ptr %1711, i64 %1715
  %private.contiguous.load766 = load <8 x float>, ptr %private.contiguous.address765, align 4
  %1716 = select <8 x i1> %71, <8 x float> %private.contiguous.load766, <8 x float> zeroinitializer
  %.spill.load767 = load <8 x float>, ptr %.spill119, align 32
  %1717 = fmul <8 x float> %.spill.load767, %1716
  %1718 = fadd <8 x float> %1701, %1717
  %.state768 = load i64, ptr %.slot137, align 4
  %1719 = add i64 480, %.state768
  %tile_snapshot.spill.load769 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1720 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load769, 0
  %1721 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load769, 1
  %.splatinsert770 = insertelement <8 x i64> poison, i64 %1719, i64 0
  %.splat771 = shufflevector <8 x i64> %.splatinsert770, <8 x i64> poison, <8 x i32> zeroinitializer
  %1722 = mul <8 x i64> %.splat771, splat (i64 32)
  %1723 = add <8 x i64> %1721, %1722
  %1724 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1720, 0
  %1725 = insertvalue { <8 x ptr>, <8 x i64> } %1724, <8 x i64> %1723, 1
  %1726 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1727 = extractvalue { <8 x ptr>, <8 x i64> } %1725, 1
  %1728 = extractelement <8 x ptr> %1726, i32 0
  %1729 = extractelement <8 x i64> %1727, i32 0
  %1730 = sub i64 %1729, 0
  %1731 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1732 = select i1 %1731, i64 %1730, i64 0
  %private.contiguous.address772 = getelementptr i8, ptr %1728, i64 %1732
  %private.contiguous.load773 = load <8 x float>, ptr %private.contiguous.address772, align 4
  %1733 = select <8 x i1> %71, <8 x float> %private.contiguous.load773, <8 x float> zeroinitializer
  %.spill.load774 = load <8 x float>, ptr %.spill120, align 32
  %1734 = fmul <8 x float> %.spill.load774, %1733
  %1735 = fadd <8 x float> %1718, %1734
  %.state775 = load i64, ptr %.slot137, align 4
  %1736 = add i64 576, %.state775
  %tile_snapshot.spill.load776 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1737 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load776, 0
  %1738 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load776, 1
  %.splatinsert777 = insertelement <8 x i64> poison, i64 %1736, i64 0
  %.splat778 = shufflevector <8 x i64> %.splatinsert777, <8 x i64> poison, <8 x i32> zeroinitializer
  %1739 = mul <8 x i64> %.splat778, splat (i64 32)
  %1740 = add <8 x i64> %1738, %1739
  %1741 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1737, 0
  %1742 = insertvalue { <8 x ptr>, <8 x i64> } %1741, <8 x i64> %1740, 1
  %1743 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1744 = extractvalue { <8 x ptr>, <8 x i64> } %1742, 1
  %1745 = extractelement <8 x ptr> %1743, i32 0
  %1746 = extractelement <8 x i64> %1744, i32 0
  %1747 = sub i64 %1746, 0
  %1748 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1749 = select i1 %1748, i64 %1747, i64 0
  %private.contiguous.address779 = getelementptr i8, ptr %1745, i64 %1749
  %private.contiguous.load780 = load <8 x float>, ptr %private.contiguous.address779, align 4
  %1750 = select <8 x i1> %71, <8 x float> %private.contiguous.load780, <8 x float> zeroinitializer
  %.spill.load781 = load <8 x float>, ptr %.spill121, align 32
  %1751 = fmul <8 x float> %.spill.load781, %1750
  %1752 = fadd <8 x float> %1735, %1751
  %.state782 = load i64, ptr %.slot137, align 4
  %1753 = add i64 672, %.state782
  %tile_snapshot.spill.load783 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1754 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load783, 0
  %1755 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load783, 1
  %.splatinsert784 = insertelement <8 x i64> poison, i64 %1753, i64 0
  %.splat785 = shufflevector <8 x i64> %.splatinsert784, <8 x i64> poison, <8 x i32> zeroinitializer
  %1756 = mul <8 x i64> %.splat785, splat (i64 32)
  %1757 = add <8 x i64> %1755, %1756
  %1758 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1754, 0
  %1759 = insertvalue { <8 x ptr>, <8 x i64> } %1758, <8 x i64> %1757, 1
  %1760 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1761 = extractvalue { <8 x ptr>, <8 x i64> } %1759, 1
  %1762 = extractelement <8 x ptr> %1760, i32 0
  %1763 = extractelement <8 x i64> %1761, i32 0
  %1764 = sub i64 %1763, 0
  %1765 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1766 = select i1 %1765, i64 %1764, i64 0
  %private.contiguous.address786 = getelementptr i8, ptr %1762, i64 %1766
  %private.contiguous.load787 = load <8 x float>, ptr %private.contiguous.address786, align 4
  %1767 = select <8 x i1> %71, <8 x float> %private.contiguous.load787, <8 x float> zeroinitializer
  %.spill.load788 = load <8 x float>, ptr %.spill122, align 32
  %1768 = fmul <8 x float> %.spill.load788, %1767
  %1769 = fadd <8 x float> %1752, %1768
  %.state789 = load i64, ptr %.slot137, align 4
  %1770 = add i64 768, %.state789
  %tile_snapshot.spill.load790 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1771 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load790, 0
  %1772 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load790, 1
  %.splatinsert791 = insertelement <8 x i64> poison, i64 %1770, i64 0
  %.splat792 = shufflevector <8 x i64> %.splatinsert791, <8 x i64> poison, <8 x i32> zeroinitializer
  %1773 = mul <8 x i64> %.splat792, splat (i64 32)
  %1774 = add <8 x i64> %1772, %1773
  %1775 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1771, 0
  %1776 = insertvalue { <8 x ptr>, <8 x i64> } %1775, <8 x i64> %1774, 1
  %1777 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1778 = extractvalue { <8 x ptr>, <8 x i64> } %1776, 1
  %1779 = extractelement <8 x ptr> %1777, i32 0
  %1780 = extractelement <8 x i64> %1778, i32 0
  %1781 = sub i64 %1780, 0
  %1782 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1783 = select i1 %1782, i64 %1781, i64 0
  %private.contiguous.address793 = getelementptr i8, ptr %1779, i64 %1783
  %private.contiguous.load794 = load <8 x float>, ptr %private.contiguous.address793, align 4
  %1784 = select <8 x i1> %71, <8 x float> %private.contiguous.load794, <8 x float> zeroinitializer
  %.spill.load795 = load <8 x float>, ptr %.spill123, align 32
  %1785 = fmul <8 x float> %.spill.load795, %1784
  %1786 = fadd <8 x float> %1769, %1785
  %.state796 = load i64, ptr %.slot137, align 4
  %1787 = add i64 864, %.state796
  %tile_snapshot.spill.load797 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1788 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load797, 0
  %1789 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load797, 1
  %.splatinsert798 = insertelement <8 x i64> poison, i64 %1787, i64 0
  %.splat799 = shufflevector <8 x i64> %.splatinsert798, <8 x i64> poison, <8 x i32> zeroinitializer
  %1790 = mul <8 x i64> %.splat799, splat (i64 32)
  %1791 = add <8 x i64> %1789, %1790
  %1792 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1788, 0
  %1793 = insertvalue { <8 x ptr>, <8 x i64> } %1792, <8 x i64> %1791, 1
  %1794 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1795 = extractvalue { <8 x ptr>, <8 x i64> } %1793, 1
  %1796 = extractelement <8 x ptr> %1794, i32 0
  %1797 = extractelement <8 x i64> %1795, i32 0
  %1798 = sub i64 %1797, 0
  %1799 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1800 = select i1 %1799, i64 %1798, i64 0
  %private.contiguous.address800 = getelementptr i8, ptr %1796, i64 %1800
  %private.contiguous.load801 = load <8 x float>, ptr %private.contiguous.address800, align 4
  %1801 = select <8 x i1> %71, <8 x float> %private.contiguous.load801, <8 x float> zeroinitializer
  %.spill.load802 = load <8 x float>, ptr %.spill124, align 32
  %1802 = fmul <8 x float> %.spill.load802, %1801
  %1803 = fadd <8 x float> %1786, %1802
  %.state803 = load i64, ptr %.slot137, align 4
  %1804 = add i64 960, %.state803
  %tile_snapshot.spill.load804 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1805 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load804, 0
  %1806 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load804, 1
  %.splatinsert805 = insertelement <8 x i64> poison, i64 %1804, i64 0
  %.splat806 = shufflevector <8 x i64> %.splatinsert805, <8 x i64> poison, <8 x i32> zeroinitializer
  %1807 = mul <8 x i64> %.splat806, splat (i64 32)
  %1808 = add <8 x i64> %1806, %1807
  %1809 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1805, 0
  %1810 = insertvalue { <8 x ptr>, <8 x i64> } %1809, <8 x i64> %1808, 1
  %1811 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1812 = extractvalue { <8 x ptr>, <8 x i64> } %1810, 1
  %1813 = extractelement <8 x ptr> %1811, i32 0
  %1814 = extractelement <8 x i64> %1812, i32 0
  %1815 = sub i64 %1814, 0
  %1816 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1817 = select i1 %1816, i64 %1815, i64 0
  %private.contiguous.address807 = getelementptr i8, ptr %1813, i64 %1817
  %private.contiguous.load808 = load <8 x float>, ptr %private.contiguous.address807, align 4
  %1818 = select <8 x i1> %71, <8 x float> %private.contiguous.load808, <8 x float> zeroinitializer
  %.spill.load809 = load <8 x float>, ptr %.spill125, align 32
  %1819 = fmul <8 x float> %.spill.load809, %1818
  %1820 = fadd <8 x float> %1803, %1819
  %.state810 = load i64, ptr %.slot137, align 4
  %1821 = add i64 1056, %.state810
  %tile_snapshot.spill.load811 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1822 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load811, 0
  %1823 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load811, 1
  %.splatinsert812 = insertelement <8 x i64> poison, i64 %1821, i64 0
  %.splat813 = shufflevector <8 x i64> %.splatinsert812, <8 x i64> poison, <8 x i32> zeroinitializer
  %1824 = mul <8 x i64> %.splat813, splat (i64 32)
  %1825 = add <8 x i64> %1823, %1824
  %1826 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1822, 0
  %1827 = insertvalue { <8 x ptr>, <8 x i64> } %1826, <8 x i64> %1825, 1
  %1828 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1829 = extractvalue { <8 x ptr>, <8 x i64> } %1827, 1
  %1830 = extractelement <8 x ptr> %1828, i32 0
  %1831 = extractelement <8 x i64> %1829, i32 0
  %1832 = sub i64 %1831, 0
  %1833 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1834 = select i1 %1833, i64 %1832, i64 0
  %private.contiguous.address814 = getelementptr i8, ptr %1830, i64 %1834
  %private.contiguous.load815 = load <8 x float>, ptr %private.contiguous.address814, align 4
  %1835 = select <8 x i1> %71, <8 x float> %private.contiguous.load815, <8 x float> zeroinitializer
  %.spill.load816 = load <8 x float>, ptr %.spill126, align 32
  %1836 = fmul <8 x float> %.spill.load816, %1835
  %1837 = fadd <8 x float> %1820, %1836
  %.state817 = load i64, ptr %.slot137, align 4
  %1838 = add i64 1152, %.state817
  %tile_snapshot.spill.load818 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1839 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load818, 0
  %1840 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load818, 1
  %.splatinsert819 = insertelement <8 x i64> poison, i64 %1838, i64 0
  %.splat820 = shufflevector <8 x i64> %.splatinsert819, <8 x i64> poison, <8 x i32> zeroinitializer
  %1841 = mul <8 x i64> %.splat820, splat (i64 32)
  %1842 = add <8 x i64> %1840, %1841
  %1843 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1839, 0
  %1844 = insertvalue { <8 x ptr>, <8 x i64> } %1843, <8 x i64> %1842, 1
  %1845 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1846 = extractvalue { <8 x ptr>, <8 x i64> } %1844, 1
  %1847 = extractelement <8 x ptr> %1845, i32 0
  %1848 = extractelement <8 x i64> %1846, i32 0
  %1849 = sub i64 %1848, 0
  %1850 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1851 = select i1 %1850, i64 %1849, i64 0
  %private.contiguous.address821 = getelementptr i8, ptr %1847, i64 %1851
  %private.contiguous.load822 = load <8 x float>, ptr %private.contiguous.address821, align 4
  %1852 = select <8 x i1> %71, <8 x float> %private.contiguous.load822, <8 x float> zeroinitializer
  %.spill.load823 = load <8 x float>, ptr %.spill127, align 32
  %1853 = fmul <8 x float> %.spill.load823, %1852
  %1854 = fadd <8 x float> %1837, %1853
  %.state824 = load i64, ptr %.slot137, align 4
  %1855 = add i64 1248, %.state824
  %tile_snapshot.spill.load825 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1856 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load825, 0
  %1857 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load825, 1
  %.splatinsert826 = insertelement <8 x i64> poison, i64 %1855, i64 0
  %.splat827 = shufflevector <8 x i64> %.splatinsert826, <8 x i64> poison, <8 x i32> zeroinitializer
  %1858 = mul <8 x i64> %.splat827, splat (i64 32)
  %1859 = add <8 x i64> %1857, %1858
  %1860 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1856, 0
  %1861 = insertvalue { <8 x ptr>, <8 x i64> } %1860, <8 x i64> %1859, 1
  %1862 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1863 = extractvalue { <8 x ptr>, <8 x i64> } %1861, 1
  %1864 = extractelement <8 x ptr> %1862, i32 0
  %1865 = extractelement <8 x i64> %1863, i32 0
  %1866 = sub i64 %1865, 0
  %1867 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1868 = select i1 %1867, i64 %1866, i64 0
  %private.contiguous.address828 = getelementptr i8, ptr %1864, i64 %1868
  %private.contiguous.load829 = load <8 x float>, ptr %private.contiguous.address828, align 4
  %1869 = select <8 x i1> %71, <8 x float> %private.contiguous.load829, <8 x float> zeroinitializer
  %.spill.load830 = load <8 x float>, ptr %.spill128, align 32
  %1870 = fmul <8 x float> %.spill.load830, %1869
  %1871 = fadd <8 x float> %1854, %1870
  %.state831 = load i64, ptr %.slot137, align 4
  %1872 = add i64 1344, %.state831
  %tile_snapshot.spill.load832 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1873 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load832, 0
  %1874 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load832, 1
  %.splatinsert833 = insertelement <8 x i64> poison, i64 %1872, i64 0
  %.splat834 = shufflevector <8 x i64> %.splatinsert833, <8 x i64> poison, <8 x i32> zeroinitializer
  %1875 = mul <8 x i64> %.splat834, splat (i64 32)
  %1876 = add <8 x i64> %1874, %1875
  %1877 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1873, 0
  %1878 = insertvalue { <8 x ptr>, <8 x i64> } %1877, <8 x i64> %1876, 1
  %1879 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1880 = extractvalue { <8 x ptr>, <8 x i64> } %1878, 1
  %1881 = extractelement <8 x ptr> %1879, i32 0
  %1882 = extractelement <8 x i64> %1880, i32 0
  %1883 = sub i64 %1882, 0
  %1884 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1885 = select i1 %1884, i64 %1883, i64 0
  %private.contiguous.address835 = getelementptr i8, ptr %1881, i64 %1885
  %private.contiguous.load836 = load <8 x float>, ptr %private.contiguous.address835, align 4
  %1886 = select <8 x i1> %71, <8 x float> %private.contiguous.load836, <8 x float> zeroinitializer
  %.spill.load837 = load <8 x float>, ptr %.spill129, align 32
  %1887 = fmul <8 x float> %.spill.load837, %1886
  %1888 = fadd <8 x float> %1871, %1887
  %.state838 = load i64, ptr %.slot137, align 4
  %1889 = add i64 1440, %.state838
  %tile_snapshot.spill.load839 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1890 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load839, 0
  %1891 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load839, 1
  %.splatinsert840 = insertelement <8 x i64> poison, i64 %1889, i64 0
  %.splat841 = shufflevector <8 x i64> %.splatinsert840, <8 x i64> poison, <8 x i32> zeroinitializer
  %1892 = mul <8 x i64> %.splat841, splat (i64 32)
  %1893 = add <8 x i64> %1891, %1892
  %1894 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1890, 0
  %1895 = insertvalue { <8 x ptr>, <8 x i64> } %1894, <8 x i64> %1893, 1
  %1896 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1897 = extractvalue { <8 x ptr>, <8 x i64> } %1895, 1
  %1898 = extractelement <8 x ptr> %1896, i32 0
  %1899 = extractelement <8 x i64> %1897, i32 0
  %1900 = sub i64 %1899, 0
  %1901 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1902 = select i1 %1901, i64 %1900, i64 0
  %private.contiguous.address842 = getelementptr i8, ptr %1898, i64 %1902
  %private.contiguous.load843 = load <8 x float>, ptr %private.contiguous.address842, align 4
  %1903 = select <8 x i1> %71, <8 x float> %private.contiguous.load843, <8 x float> zeroinitializer
  %.spill.load844 = load <8 x float>, ptr %.spill130, align 32
  %1904 = fmul <8 x float> %.spill.load844, %1903
  %1905 = fadd <8 x float> %1888, %1904
  %tile_snapshot.spill.load845 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill136, align 64
  %1906 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load845, 0
  %1907 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load845, 1
  %.state846 = load i64, ptr %.slot137, align 4
  %.splatinsert847 = insertelement <8 x i64> poison, i64 %.state846, i64 0
  %.splat848 = shufflevector <8 x i64> %.splatinsert847, <8 x i64> poison, <8 x i32> zeroinitializer
  %1908 = mul <8 x i64> %.splat848, splat (i64 32)
  %1909 = add <8 x i64> %1907, %1908
  %1910 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1906, 0
  %1911 = insertvalue { <8 x ptr>, <8 x i64> } %1910, <8 x i64> %1909, 1
  %1912 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1913 = extractvalue { <8 x ptr>, <8 x i64> } %1911, 1
  %1914 = extractelement <8 x ptr> %1912, i32 0
  %1915 = extractelement <8 x i64> %1913, i32 0
  %1916 = sub i64 %1915, 0
  %1917 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1918 = select i1 %1917, i64 %1916, i64 0
  %private.contiguous.address849 = getelementptr i8, ptr %1914, i64 %1918
  %private.contiguous.preserve850 = load <8 x float>, ptr %private.contiguous.address849, align 4
  %1919 = select <8 x i1> %71, <8 x float> %1905, <8 x float> %private.contiguous.preserve850
  store <8 x float> %1919, ptr %private.contiguous.address849, align 4
  %.state851 = load i64, ptr %.slot137, align 4
  %1920 = add i64 %.state851, 1
  store i64 %1920, ptr %.slot137, align 4
  br label %direct.schedule.73

direct.schedule.75:                               ; preds = %direct.false726
  store i64 0, ptr %.slot138, align 4
  br label %direct.schedule.76

direct.schedule.76:                               ; preds = %direct.schedule.77, %direct.schedule.75
  %.state852 = load i64, ptr %.slot138, align 4
  %1921 = icmp slt i64 %.state852, 96
  br i1 %1921, label %direct.true853, label %direct.false854

direct.schedule.77:                               ; preds = %direct.true853
  %tile_snapshot.spill.load855 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill136, align 64
  %1922 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load855, 0
  %1923 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load855, 1
  %.state856 = load i64, ptr %.slot138, align 4
  %.splatinsert857 = insertelement <8 x i64> poison, i64 %.state856, i64 0
  %.splat858 = shufflevector <8 x i64> %.splatinsert857, <8 x i64> poison, <8 x i32> zeroinitializer
  %1924 = mul <8 x i64> %.splat858, splat (i64 32)
  %1925 = add <8 x i64> %1923, %1924
  %1926 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1922, 0
  %1927 = insertvalue { <8 x ptr>, <8 x i64> } %1926, <8 x i64> %1925, 1
  %1928 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1929 = extractvalue { <8 x ptr>, <8 x i64> } %1927, 1
  %1930 = extractelement <8 x ptr> %1928, i32 0
  %1931 = extractelement <8 x i64> %1929, i32 0
  %1932 = sub i64 %1931, 0
  %1933 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1934 = select i1 %1933, i64 %1932, i64 0
  %private.contiguous.address859 = getelementptr i8, ptr %1930, i64 %1934
  %private.contiguous.load860 = load <8 x float>, ptr %private.contiguous.address859, align 4
  %1935 = select <8 x i1> %71, <8 x float> %private.contiguous.load860, <8 x float> zeroinitializer
  %tile_snapshot.spill.load861 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1936 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load861, 0
  %1937 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load861, 1
  %.state862 = load i64, ptr %.slot138, align 4
  %.splatinsert863 = insertelement <8 x i64> poison, i64 %.state862, i64 0
  %.splat864 = shufflevector <8 x i64> %.splatinsert863, <8 x i64> poison, <8 x i32> zeroinitializer
  %1938 = mul <8 x i64> %.splat864, splat (i64 32)
  %1939 = add <8 x i64> %1937, %1938
  %1940 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1936, 0
  %1941 = insertvalue { <8 x ptr>, <8 x i64> } %1940, <8 x i64> %1939, 1
  %1942 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1943 = extractvalue { <8 x ptr>, <8 x i64> } %1941, 1
  %1944 = extractelement <8 x ptr> %1942, i32 0
  %1945 = extractelement <8 x i64> %1943, i32 0
  %1946 = sub i64 %1945, 0
  %1947 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1948 = select i1 %1947, i64 %1946, i64 0
  %private.contiguous.address865 = getelementptr i8, ptr %1944, i64 %1948
  %private.contiguous.preserve866 = load <8 x float>, ptr %private.contiguous.address865, align 4
  %1949 = select <8 x i1> %71, <8 x float> %1935, <8 x float> %private.contiguous.preserve866
  store <8 x float> %1949, ptr %private.contiguous.address865, align 4
  %.state867 = load i64, ptr %.slot138, align 4
  %1950 = add i64 %.state867, 1
  store i64 %1950, ptr %.slot138, align 4
  br label %direct.schedule.76

direct.schedule.78:                               ; preds = %direct.false854
  store i64 0, ptr %.slot139, align 4
  br label %direct.schedule.79

direct.schedule.79:                               ; preds = %direct.schedule.80, %direct.schedule.78
  %.state868 = load i64, ptr %.slot139, align 4
  %1951 = icmp slt i64 %.state868, 96
  br i1 %1951, label %direct.true869, label %direct.false870

direct.schedule.80:                               ; preds = %direct.true869
  %tile_snapshot.spill.load871 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1952 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load871, 0
  %1953 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load871, 1
  %.state872 = load i64, ptr %.slot139, align 4
  %.splatinsert873 = insertelement <8 x i64> poison, i64 %.state872, i64 0
  %.splat874 = shufflevector <8 x i64> %.splatinsert873, <8 x i64> poison, <8 x i32> zeroinitializer
  %1954 = mul <8 x i64> %.splat874, splat (i64 32)
  %1955 = add <8 x i64> %1953, %1954
  %1956 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1952, 0
  %1957 = insertvalue { <8 x ptr>, <8 x i64> } %1956, <8 x i64> %1955, 1
  %1958 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1959 = extractvalue { <8 x ptr>, <8 x i64> } %1957, 1
  %1960 = extractelement <8 x ptr> %1958, i32 0
  %1961 = extractelement <8 x i64> %1959, i32 0
  %1962 = sub i64 %1961, 0
  %1963 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1964 = select i1 %1963, i64 %1962, i64 0
  %private.contiguous.address875 = getelementptr i8, ptr %1960, i64 %1964
  %private.contiguous.load876 = load <8 x float>, ptr %private.contiguous.address875, align 4
  %1965 = select <8 x i1> %71, <8 x float> %private.contiguous.load876, <8 x float> zeroinitializer
  %tile_snapshot.spill.load877 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1966 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load877, 0
  %1967 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load877, 1
  %.state878 = load i64, ptr %.slot139, align 4
  %.splatinsert879 = insertelement <8 x i64> poison, i64 %.state878, i64 0
  %.splat880 = shufflevector <8 x i64> %.splatinsert879, <8 x i64> poison, <8 x i32> zeroinitializer
  %1968 = mul <8 x i64> %.splat880, splat (i64 32)
  %1969 = add <8 x i64> %1967, %1968
  %1970 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1966, 0
  %1971 = insertvalue { <8 x ptr>, <8 x i64> } %1970, <8 x i64> %1969, 1
  %1972 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1973 = extractvalue { <8 x ptr>, <8 x i64> } %1971, 1
  %1974 = extractelement <8 x ptr> %1972, i32 0
  %1975 = extractelement <8 x i64> %1973, i32 0
  %1976 = sub i64 %1975, 0
  %1977 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1978 = select i1 %1977, i64 %1976, i64 0
  %private.contiguous.address881 = getelementptr i8, ptr %1974, i64 %1978
  %private.contiguous.preserve882 = load <8 x float>, ptr %private.contiguous.address881, align 4
  %1979 = select <8 x i1> %71, <8 x float> %1965, <8 x float> %private.contiguous.preserve882
  store <8 x float> %1979, ptr %private.contiguous.address881, align 4
  %.state883 = load i64, ptr %.slot139, align 4
  %1980 = add i64 %.state883, 1
  store i64 %1980, ptr %.slot139, align 4
  br label %direct.schedule.79

direct.schedule.81:                               ; preds = %direct.false870
  %.state884 = load i64, ptr %.slot34, align 4
  %1981 = add i64 %.state884, 1
  %.spill.load885 = load <8 x float>, ptr %.spill113, align 32
  %.spill.load886 = load <8 x float>, ptr %.spill135, align 32
  store i64 %1981, ptr %.slot34, align 4
  %1982 = load <8 x float>, ptr %.slot35, align 32
  %1983 = select <8 x i1> %71, <8 x float> %.spill.load885, <8 x float> %1982
  store <8 x float> %1983, ptr %.slot35, align 32
  %1984 = load <8 x float>, ptr %.slot36, align 32
  %1985 = select <8 x i1> %71, <8 x float> %.spill.load886, <8 x float> %1984
  store <8 x float> %1985, ptr %.slot36, align 32
  br label %direct.schedule.7

direct.schedule.82:                               ; preds = %direct.false171
  store i64 0, ptr %.slot140, align 4
  br label %direct.schedule.83

direct.schedule.83:                               ; preds = %direct.schedule.84, %direct.schedule.82
  %.state887 = load i64, ptr %.slot140, align 4
  %1986 = icmp slt i64 %.state887, 96
  br i1 %1986, label %direct.true888, label %direct.false889

direct.schedule.84:                               ; preds = %direct.true888
  %.spill.load890 = load <8 x i64>, ptr %.spill, align 64
  %1987 = add <8 x i64> %.spill.load890, zeroinitializer
  %1988 = add <8 x i64> zeroinitializer, %1987
  %.spill.load891 = load <8 x i64>, ptr %.spill29, align 64
  %1989 = add <8 x i64> %.spill.load891, zeroinitializer
  %1990 = mul <8 x i64> %1988, splat (i64 3)
  %1991 = add <8 x i64> %1990, %1989
  %.state892 = load i64, ptr %.slot140, align 4
  %1992 = add i64 0, %.state892
  %1993 = mul <8 x i64> %1991, splat (i64 96)
  %.splatinsert893 = insertelement <8 x i64> poison, i64 %1992, i64 0
  %.splat894 = shufflevector <8 x i64> %.splatinsert893, <8 x i64> poison, <8 x i32> zeroinitializer
  %1994 = add <8 x i64> %1993, %.splat894
  %.state895 = load i64, ptr %.slot140, align 4
  %1995 = add i64 0, %.state895
  %tile_snapshot.spill.load896 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1996 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load896, 0
  %1997 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load896, 1
  %.splatinsert897 = insertelement <8 x i64> poison, i64 %1995, i64 0
  %.splat898 = shufflevector <8 x i64> %.splatinsert897, <8 x i64> poison, <8 x i32> zeroinitializer
  %1998 = mul <8 x i64> %.splat898, splat (i64 32)
  %1999 = add <8 x i64> %1997, %1998
  %2000 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1996, 0
  %2001 = insertvalue { <8 x ptr>, <8 x i64> } %2000, <8 x i64> %1999, 1
  %2002 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %2003 = extractvalue { <8 x ptr>, <8 x i64> } %2001, 1
  %2004 = extractelement <8 x ptr> %2002, i32 0
  %2005 = extractelement <8 x i64> %2003, i32 0
  %2006 = sub i64 %2005, 0
  %2007 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2008 = select i1 %2007, i64 %2006, i64 0
  %private.contiguous.address899 = getelementptr i8, ptr %2004, i64 %2008
  %private.contiguous.load900 = load <8 x float>, ptr %private.contiguous.address899, align 4
  %2009 = select <8 x i1> %71, <8 x float> %private.contiguous.load900, <8 x float> zeroinitializer
  %.state901 = load <8 x float>, ptr %.slot36, align 32
  %2010 = fdiv <8 x float> %2009, %.state901
  %2011 = extractvalue { ptr, i64 } %47, 0
  %2012 = mul <8 x i64> %1994, splat (i64 4)
  %2013 = getelementptr i8, ptr %2011, <8 x i64> %2012
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %2010, <8 x ptr> align 1 %2013, <8 x i1> %71)
  %.state902 = load i64, ptr %.slot140, align 4
  %2014 = add i64 %.state902, 1
  store i64 %2014, ptr %.slot140, align 4
  br label %direct.schedule.83

direct.schedule.85:                               ; preds = %direct.false889
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true160:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false161:                                  ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true170:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false171:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.82

direct.true174:                                   ; preds = %direct.schedule.9
  br label %direct.schedule.10

direct.false175:                                  ; preds = %direct.schedule.9
  br label %direct.schedule.13

direct.true184:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false185:                                  ; preds = %direct.schedule.10
  %2015 = load <8 x float>, ptr %.slot41, align 32
  %2016 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %2015
  store <8 x float> %2016, ptr %.slot41, align 32
  br label %direct.schedule.12

direct.true196:                                   ; preds = %direct.schedule.14
  br label %direct.schedule.15

direct.false197:                                  ; preds = %direct.schedule.14
  br label %direct.schedule.18

direct.true206:                                   ; preds = %direct.schedule.15
  br label %direct.schedule.16

direct.false207:                                  ; preds = %direct.schedule.15
  %2017 = load <8 x float>, ptr %.slot45, align 32
  %2018 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %2017
  store <8 x float> %2018, ptr %.slot45, align 32
  br label %direct.schedule.17

direct.true218:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false219:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true233:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false234:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24

direct.true250:                                   ; preds = %direct.schedule.25
  br label %direct.schedule.26

direct.false251:                                  ; preds = %direct.schedule.25
  br label %direct.schedule.27

direct.true267:                                   ; preds = %direct.schedule.28
  br label %direct.schedule.29

direct.false268:                                  ; preds = %direct.schedule.28
  br label %direct.schedule.30

direct.true284:                                   ; preds = %direct.schedule.31
  br label %direct.schedule.32

direct.false285:                                  ; preds = %direct.schedule.31
  br label %direct.schedule.33

direct.true301:                                   ; preds = %direct.schedule.34
  br label %direct.schedule.35

direct.false302:                                  ; preds = %direct.schedule.34
  br label %direct.schedule.36

direct.true318:                                   ; preds = %direct.schedule.37
  br label %direct.schedule.38

direct.false319:                                  ; preds = %direct.schedule.37
  br label %direct.schedule.39

direct.true335:                                   ; preds = %direct.schedule.40
  br label %direct.schedule.41

direct.false336:                                  ; preds = %direct.schedule.40
  br label %direct.schedule.42

direct.true352:                                   ; preds = %direct.schedule.43
  br label %direct.schedule.44

direct.false353:                                  ; preds = %direct.schedule.43
  br label %direct.schedule.45

direct.true369:                                   ; preds = %direct.schedule.46
  br label %direct.schedule.47

direct.false370:                                  ; preds = %direct.schedule.46
  br label %direct.schedule.48

direct.true386:                                   ; preds = %direct.schedule.49
  br label %direct.schedule.50

direct.false387:                                  ; preds = %direct.schedule.49
  br label %direct.schedule.51

direct.true403:                                   ; preds = %direct.schedule.52
  br label %direct.schedule.53

direct.false404:                                  ; preds = %direct.schedule.52
  br label %direct.schedule.54

direct.true420:                                   ; preds = %direct.schedule.55
  br label %direct.schedule.56

direct.false421:                                  ; preds = %direct.schedule.55
  br label %direct.schedule.57

direct.true437:                                   ; preds = %direct.schedule.58
  br label %direct.schedule.59

direct.false438:                                  ; preds = %direct.schedule.58
  br label %direct.schedule.60

direct.true454:                                   ; preds = %direct.schedule.61
  br label %direct.schedule.62

direct.false455:                                  ; preds = %direct.schedule.61
  br label %direct.schedule.63

direct.true471:                                   ; preds = %direct.schedule.64
  br label %direct.schedule.65

direct.false472:                                  ; preds = %direct.schedule.64
  br label %direct.schedule.66

direct.true617:                                   ; preds = %direct.schedule.67
  br label %direct.schedule.68

direct.false618:                                  ; preds = %direct.schedule.67
  br label %direct.schedule.69

direct.true712:                                   ; preds = %direct.schedule.70
  br label %direct.schedule.71

direct.false713:                                  ; preds = %direct.schedule.70
  br label %direct.schedule.72

direct.true725:                                   ; preds = %direct.schedule.73
  br label %direct.schedule.74

direct.false726:                                  ; preds = %direct.schedule.73
  br label %direct.schedule.75

direct.true853:                                   ; preds = %direct.schedule.76
  br label %direct.schedule.77

direct.false854:                                  ; preds = %direct.schedule.76
  br label %direct.schedule.78

direct.true869:                                   ; preds = %direct.schedule.79
  br label %direct.schedule.80

direct.false870:                                  ; preds = %direct.schedule.79
  br label %direct.schedule.81

direct.true888:                                   ; preds = %direct.schedule.83
  br label %direct.schedule.84

direct.false889:                                  ; preds = %direct.schedule.83
  br label %direct.schedule.85
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #2

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #3 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #4

define internal void @llm_attention.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 2560
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 5632
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 8704
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 49664
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 98816
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 99328
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 99840
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill29 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill29, align 64
  %.spill30 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill30, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill31 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill31, align 64
  %tile_snapshot.spill32 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill32, align 64
  %.slot33 = alloca i64, align 8
  store i64 0, ptr %.slot33, align 4
  %.slot34 = alloca i64, align 8
  store i64 0, ptr %.slot34, align 4
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.slot36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot36, align 32
  %.spill37 = alloca i64, align 8
  store i64 0, ptr %.spill37, align 4
  %tile_snapshot.spill38 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill38, align 64
  %.slot39 = alloca i64, align 8
  store i64 0, ptr %.slot39, align 4
  %.spill40 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill40, align 64
  %.slot41 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot41, align 32
  %tile_snapshot.spill42 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill42, align 64
  %.slot43 = alloca i64, align 8
  store i64 0, ptr %.slot43, align 4
  %.spill44 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill44, align 64
  %.slot45 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot45, align 32
  %.slot46 = alloca i64, align 8
  store i64 0, ptr %.slot46, align 4
  %.slot47 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot47, align 32
  %.slot48 = alloca i64, align 8
  store i64 0, ptr %.slot48, align 4
  %.slot49 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot49, align 32
  %.slot50 = alloca i64, align 8
  store i64 0, ptr %.slot50, align 4
  %.slot51 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot51, align 32
  %.slot52 = alloca i64, align 8
  store i64 0, ptr %.slot52, align 4
  %.slot53 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot53, align 32
  %.slot54 = alloca i64, align 8
  store i64 0, ptr %.slot54, align 4
  %.slot55 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot55, align 32
  %.slot56 = alloca i64, align 8
  store i64 0, ptr %.slot56, align 4
  %.slot57 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot57, align 32
  %.slot58 = alloca i64, align 8
  store i64 0, ptr %.slot58, align 4
  %.slot59 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot59, align 32
  %.slot60 = alloca i64, align 8
  store i64 0, ptr %.slot60, align 4
  %.slot61 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot61, align 32
  %.slot62 = alloca i64, align 8
  store i64 0, ptr %.slot62, align 4
  %.slot63 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot63, align 32
  %.slot64 = alloca i64, align 8
  store i64 0, ptr %.slot64, align 4
  %.slot65 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot65, align 32
  %.slot66 = alloca i64, align 8
  store i64 0, ptr %.slot66, align 4
  %.slot67 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot67, align 32
  %.slot68 = alloca i64, align 8
  store i64 0, ptr %.slot68, align 4
  %.slot69 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot69, align 32
  %.slot70 = alloca i64, align 8
  store i64 0, ptr %.slot70, align 4
  %.slot71 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot71, align 32
  %.slot72 = alloca i64, align 8
  store i64 0, ptr %.slot72, align 4
  %.slot73 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot73, align 32
  %.slot74 = alloca i64, align 8
  store i64 0, ptr %.slot74, align 4
  %.slot75 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot75, align 32
  %.slot76 = alloca i64, align 8
  store i64 0, ptr %.slot76, align 4
  %.slot77 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot77, align 32
  %.spill78 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill78, align 1
  %.spill79 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill79, align 1
  %.spill80 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill80, align 1
  %.spill81 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill81, align 1
  %.spill82 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill82, align 1
  %.spill83 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill83, align 1
  %.spill84 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill84, align 1
  %.spill85 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill85, align 1
  %.spill86 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill86, align 1
  %.spill87 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill87, align 1
  %.spill88 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill88, align 1
  %.spill89 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill89, align 1
  %.spill90 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill90, align 1
  %.spill91 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill91, align 1
  %.spill92 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill92, align 1
  %.spill93 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill93, align 1
  %.spill94 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill94, align 32
  %.spill95 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill95, align 32
  %.spill96 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill96, align 32
  %.spill97 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill97, align 32
  %.spill98 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill98, align 32
  %.spill99 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill99, align 32
  %.spill100 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill100, align 32
  %.spill101 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill101, align 32
  %.spill102 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill102, align 32
  %.spill103 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill103, align 32
  %.spill104 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill104, align 32
  %.spill105 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill105, align 32
  %.spill106 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill106, align 32
  %.spill107 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill107, align 32
  %.spill108 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill108, align 32
  %.spill109 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill109, align 32
  %tile_snapshot.spill110 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill110, align 64
  %.slot111 = alloca i64, align 8
  store i64 0, ptr %.slot111, align 4
  %.slot112 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot112, align 32
  %.spill113 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill113, align 32
  %.spill114 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill114, align 32
  %.spill115 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill115, align 32
  %.spill116 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill116, align 32
  %.spill117 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill117, align 32
  %.spill118 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill118, align 32
  %.spill119 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill119, align 32
  %.spill120 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill120, align 32
  %.spill121 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill121, align 32
  %.spill122 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill122, align 32
  %.spill123 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill123, align 32
  %.spill124 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill124, align 32
  %.spill125 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill125, align 32
  %.spill126 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill126, align 32
  %.spill127 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill127, align 32
  %.spill128 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill128, align 32
  %.spill129 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill129, align 32
  %.spill130 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill130, align 32
  %tile_snapshot.spill131 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill131, align 64
  %.spill132 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill132, align 32
  %.slot133 = alloca i64, align 8
  store i64 0, ptr %.slot133, align 4
  %.slot134 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot134, align 32
  %.spill135 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill135, align 32
  %tile_snapshot.spill136 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill136, align 64
  %.slot137 = alloca i64, align 8
  store i64 0, ptr %.slot137, align 4
  %.slot138 = alloca i64, align 8
  store i64 0, ptr %.slot138, align 4
  %.slot139 = alloca i64, align 8
  store i64 0, ptr %.slot139, align 4
  %.slot140 = alloca i64, align 8
  store i64 0, ptr %.slot140, align 4
  %24 = getelementptr i8, ptr %argument_buffer, i64 0
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = getelementptr i8, ptr %argument_buffer, i64 16
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %30, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %33, 1
  %36 = getelementptr i8, ptr %argument_buffer, i64 32
  %37 = load ptr, ptr %36, align 16
  %38 = getelementptr i8, ptr %36, i64 8
  %39 = load i64, ptr %38, align 8
  %40 = insertvalue { ptr, i64 } poison, ptr %37, 0
  %41 = insertvalue { ptr, i64 } %40, i64 %39, 1
  %42 = getelementptr i8, ptr %argument_buffer, i64 48
  %43 = load ptr, ptr %42, align 16
  %44 = getelementptr i8, ptr %42, i64 8
  %45 = load i64, ptr %44, align 8
  %46 = insertvalue { ptr, i64 } poison, ptr %43, 0
  %47 = insertvalue { ptr, i64 } %46, i64 %45, 1
  %48 = load i32, ptr %launch_config, align 4
  %49 = getelementptr i8, ptr %launch_config, i64 12
  %50 = load i32, ptr %49, align 4
  %51 = getelementptr i8, ptr %launch_config, i64 4
  %52 = load i32, ptr %51, align 4
  %53 = getelementptr i8, ptr %launch_config, i64 16
  %54 = load i32, ptr %53, align 4
  %55 = getelementptr i8, ptr %launch_config, i64 8
  %56 = load i32, ptr %55, align 4
  %57 = getelementptr i8, ptr %launch_config, i64 20
  %58 = load i32, ptr %57, align 4
  %59 = getelementptr i8, ptr %launch_config, i64 36
  %60 = load i32, ptr %59, align 4
  %.splatinsert141 = insertelement <8 x i32> poison, i32 %60, i64 0
  %.splat142 = shufflevector <8 x i32> %.splatinsert141, <8 x i32> poison, <8 x i32> zeroinitializer
  %61 = add <8 x i32> %.splat142, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %62 = mul i32 %48, 32
  %.splatinsert143 = insertelement <8 x i32> poison, i32 %62, i64 0
  %.splat144 = shufflevector <8 x i32> %.splatinsert143, <8 x i32> poison, <8 x i32> zeroinitializer
  %63 = add <8 x i32> %.splat144, %61
  %64 = mul i32 %52, 1
  %.splatinsert145 = insertelement <8 x i32> poison, i32 %64, i64 0
  %.splat146 = shufflevector <8 x i32> %.splatinsert145, <8 x i32> poison, <8 x i32> zeroinitializer
  %65 = add <8 x i32> %.splat146, zeroinitializer
  %66 = mul i32 %56, 1
  %.splatinsert147 = insertelement <8 x i32> poison, i32 %66, i64 0
  %.splat148 = shufflevector <8 x i32> %.splatinsert147, <8 x i32> poison, <8 x i32> zeroinitializer
  %67 = add <8 x i32> %.splat148, zeroinitializer
  %68 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %63, 0
  %69 = insertvalue [3 x <8 x i32>] %68, <8 x i32> %65, 1
  %70 = insertvalue [3 x <8 x i32>] %69, <8 x i32> %67, 2
  %.splatinsert149 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat150 = shufflevector <8 x i32> %.splatinsert149, <8 x i32> poison, <8 x i32> zeroinitializer
  %71 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat150
  %72 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  br i1 %72, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %73 = extractvalue [3 x <8 x i32>] %70, 0
  %74 = zext <8 x i32> %73 to <8 x i64>
  %75 = select <8 x i1> %71, <8 x i64> %74, <8 x i64> zeroinitializer
  %76 = select <8 x i1> %71, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %77 = sdiv <8 x i64> %75, %76
  %78 = select <8 x i1> %71, <8 x i64> %74, <8 x i64> zeroinitializer
  %79 = select <8 x i1> %71, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %80 = sdiv <8 x i64> %78, %79
  %81 = select <8 x i1> %71, <8 x i64> %80, <8 x i64> zeroinitializer
  %82 = select <8 x i1> %71, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %83 = srem <8 x i64> %81, %82
  %84 = load <8 x i64>, ptr %.spill, align 64
  %85 = select <8 x i1> %71, <8 x i64> %83, <8 x i64> %84
  store <8 x i64> %85, ptr %.spill, align 64
  %86 = mul <8 x i64> %77, splat (i64 1)
  %87 = load <8 x i64>, ptr %.spill29, align 64
  %88 = select <8 x i1> %71, <8 x i64> %86, <8 x i64> %87
  store <8 x i64> %88, ptr %.spill29, align 64
  %89 = select <8 x i1> %71, <8 x i64> %83, <8 x i64> zeroinitializer
  %90 = select <8 x i1> %71, <8 x i64> splat (i64 4), <8 x i64> splat (i64 1)
  %91 = sdiv <8 x i64> %89, %90
  %92 = load <8 x i64>, ptr %.spill30, align 64
  %93 = select <8 x i1> %71, <8 x i64> %91, <8 x i64> %92
  store <8 x i64> %93, ptr %.spill30, align 64
  %94 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %95 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %96 = extractvalue { <8 x ptr>, <8 x i64> } %94, 0
  %97 = select <8 x i1> %71, <8 x ptr> %95, <8 x ptr> %96
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %99 = extractvalue { <8 x ptr>, <8 x i64> } %94, 1
  %100 = select <8 x i1> %71, <8 x i64> %98, <8 x i64> %99
  %101 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %97, 0
  %102 = insertvalue { <8 x ptr>, <8 x i64> } %101, <8 x i64> %100, 1
  store { <8 x ptr>, <8 x i64> } %102, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %103 = icmp slt i64 %.state, 80
  br i1 %103, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %104 = add <8 x i64> %.spill.load, zeroinitializer
  %105 = add <8 x i64> zeroinitializer, %104
  %.spill.load151 = load <8 x i64>, ptr %.spill29, align 64
  %106 = add <8 x i64> %.spill.load151, zeroinitializer
  %107 = mul <8 x i64> %105, splat (i64 3)
  %108 = add <8 x i64> %107, %106
  %.state152 = load i64, ptr %.slot, align 4
  %109 = add i64 0, %.state152
  %110 = mul <8 x i64> %108, splat (i64 80)
  %.splatinsert153 = insertelement <8 x i64> poison, i64 %109, i64 0
  %.splat154 = shufflevector <8 x i64> %.splatinsert153, <8 x i64> poison, <8 x i32> zeroinitializer
  %111 = add <8 x i64> %110, %.splat154
  %112 = extractvalue { ptr, i64 } %29, 0
  %113 = mul <8 x i64> %111, splat (i64 4)
  %114 = getelementptr i8, ptr %112, <8 x i64> %113
  %115 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %114, <8 x i1> %71, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %117 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state155 = load i64, ptr %.slot, align 4
  %.splatinsert156 = insertelement <8 x i64> poison, i64 %.state155, i64 0
  %.splat157 = shufflevector <8 x i64> %.splatinsert156, <8 x i64> poison, <8 x i32> zeroinitializer
  %118 = mul <8 x i64> %.splat157, splat (i64 32)
  %119 = add <8 x i64> %117, %118
  %120 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %116, 0
  %121 = insertvalue { <8 x ptr>, <8 x i64> } %120, <8 x i64> %119, 1
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %123 = extractvalue { <8 x ptr>, <8 x i64> } %121, 1
  %124 = extractelement <8 x ptr> %122, i32 0
  %125 = extractelement <8 x i64> %123, i32 0
  %126 = sub i64 %125, 0
  %127 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %128 = select i1 %127, i64 %126, i64 0
  %private.contiguous.address = getelementptr i8, ptr %124, i64 %128
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %129 = select <8 x i1> %71, <8 x float> %115, <8 x float> %private.contiguous.preserve
  store <8 x float> %129, ptr %private.contiguous.address, align 4
  %.state158 = load i64, ptr %.slot, align 4
  %130 = add i64 %.state158, 1
  store i64 %130, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %131 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %132 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %133 = extractvalue { <8 x ptr>, <8 x i64> } %131, 0
  %134 = select <8 x i1> %71, <8 x ptr> %132, <8 x ptr> %133
  %135 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %136 = extractvalue { <8 x ptr>, <8 x i64> } %131, 1
  %137 = select <8 x i1> %71, <8 x i64> %135, <8 x i64> %136
  %138 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %134, 0
  %139 = insertvalue { <8 x ptr>, <8 x i64> } %138, <8 x i64> %137, 1
  store { <8 x ptr>, <8 x i64> } %139, ptr %tile_snapshot.spill31, align 64
  %140 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %141 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %140, 0
  %143 = select <8 x i1> %71, <8 x ptr> %141, <8 x ptr> %142
  %144 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %145 = extractvalue { <8 x ptr>, <8 x i64> } %140, 1
  %146 = select <8 x i1> %71, <8 x i64> %144, <8 x i64> %145
  %147 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %143, 0
  %148 = insertvalue { <8 x ptr>, <8 x i64> } %147, <8 x i64> %146, 1
  store { <8 x ptr>, <8 x i64> } %148, ptr %tile_snapshot.spill32, align 64
  store i64 0, ptr %.slot33, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state159 = load i64, ptr %.slot33, align 4
  %149 = icmp slt i64 %.state159, 96
  br i1 %149, label %direct.true160, label %direct.false161

direct.schedule.5:                                ; preds = %direct.true160
  %tile_snapshot.spill.load162 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load162, 0
  %151 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load162, 1
  %.state163 = load i64, ptr %.slot33, align 4
  %.splatinsert164 = insertelement <8 x i64> poison, i64 %.state163, i64 0
  %.splat165 = shufflevector <8 x i64> %.splatinsert164, <8 x i64> poison, <8 x i32> zeroinitializer
  %152 = mul <8 x i64> %.splat165, splat (i64 32)
  %153 = add <8 x i64> %151, %152
  %154 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %150, 0
  %155 = insertvalue { <8 x ptr>, <8 x i64> } %154, <8 x i64> %153, 1
  %156 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %157 = extractvalue { <8 x ptr>, <8 x i64> } %155, 1
  %158 = extractelement <8 x ptr> %156, i32 0
  %159 = extractelement <8 x i64> %157, i32 0
  %160 = sub i64 %159, 0
  %161 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %162 = select i1 %161, i64 %160, i64 0
  %private.contiguous.address166 = getelementptr i8, ptr %158, i64 %162
  %private.contiguous.preserve167 = load <8 x float>, ptr %private.contiguous.address166, align 4
  %163 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %private.contiguous.preserve167
  store <8 x float> %163, ptr %private.contiguous.address166, align 4
  %.state168 = load i64, ptr %.slot33, align 4
  %164 = add i64 %.state168, 1
  store i64 %164, ptr %.slot33, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false161
  store i64 0, ptr %.slot34, align 4
  %165 = load <8 x float>, ptr %.slot35, align 32
  %166 = select <8 x i1> %71, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %165
  store <8 x float> %166, ptr %.slot35, align 32
  %167 = load <8 x float>, ptr %.slot36, align 32
  %168 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %167
  store <8 x float> %168, ptr %.slot36, align 32
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.81, %direct.schedule.6
  %.state169 = load i64, ptr %.slot34, align 4
  %169 = icmp slt i64 %.state169, 5
  br i1 %169, label %direct.true170, label %direct.false171

direct.schedule.8:                                ; preds = %direct.true170
  %.state172 = load i64, ptr %.slot34, align 4
  %170 = sdiv i64 %.state172, 1
  %171 = mul i64 %170, 16
  store i64 %171, ptr %.spill37, align 4
  %172 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %172, 0
  %175 = select <8 x i1> %71, <8 x ptr> %173, <8 x ptr> %174
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %177 = extractvalue { <8 x ptr>, <8 x i64> } %172, 1
  %178 = select <8 x i1> %71, <8 x i64> %176, <8 x i64> %177
  %179 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %175, 0
  %180 = insertvalue { <8 x ptr>, <8 x i64> } %179, <8 x i64> %178, 1
  store { <8 x ptr>, <8 x i64> } %180, ptr %tile_snapshot.spill38, align 64
  store i64 0, ptr %.slot39, align 4
  br label %direct.schedule.9

direct.schedule.9:                                ; preds = %direct.schedule.12, %direct.schedule.8
  %.state173 = load i64, ptr %.slot39, align 4
  %181 = icmp slt i64 %.state173, 1280
  br i1 %181, label %direct.true174, label %direct.false175

direct.schedule.10:                               ; preds = %direct.true174
  %.state176 = load i64, ptr %.slot39, align 4
  %182 = srem i64 %.state176, 80
  %.state177 = load i64, ptr %.slot39, align 4
  %183 = sdiv i64 %.state177, 80
  %.spill.load178 = load <8 x i64>, ptr %.spill30, align 64
  %184 = add <8 x i64> %.spill.load178, zeroinitializer
  %185 = add <8 x i64> zeroinitializer, %184
  %.spill.load179 = load i64, ptr %.spill37, align 4
  %186 = add i64 %.spill.load179, %183
  %187 = mul <8 x i64> %185, splat (i64 67)
  %.splatinsert180 = insertelement <8 x i64> poison, i64 %186, i64 0
  %.splat181 = shufflevector <8 x i64> %.splatinsert180, <8 x i64> poison, <8 x i32> zeroinitializer
  %188 = add <8 x i64> %187, %.splat181
  %189 = icmp sge i64 %186, 0
  %190 = and i1 true, %189
  %191 = icmp slt i64 %186, 67
  %192 = and i1 %190, %191
  %193 = add i64 0, %182
  %194 = mul <8 x i64> %188, splat (i64 80)
  %.splatinsert182 = insertelement <8 x i64> poison, i64 %193, i64 0
  %.splat183 = shufflevector <8 x i64> %.splatinsert182, <8 x i64> poison, <8 x i32> zeroinitializer
  %195 = add <8 x i64> %194, %.splat183
  %196 = load <8 x i64>, ptr %.spill40, align 64
  %197 = select <8 x i1> %71, <8 x i64> %195, <8 x i64> %196
  store <8 x i64> %197, ptr %.spill40, align 64
  br i1 %192, label %direct.true184, label %direct.false185

direct.schedule.11:                               ; preds = %direct.true184
  %.spill.load186 = load <8 x i64>, ptr %.spill40, align 64
  %198 = extractvalue { ptr, i64 } %35, 0
  %199 = mul <8 x i64> %.spill.load186, splat (i64 4)
  %200 = getelementptr i8, ptr %198, <8 x i64> %199
  %201 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %200, <8 x i1> %71, <8 x float> zeroinitializer)
  %202 = load <8 x float>, ptr %.slot41, align 32
  %203 = select <8 x i1> %71, <8 x float> %201, <8 x float> %202
  store <8 x float> %203, ptr %.slot41, align 32
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.false185, %direct.schedule.11
  %tile_snapshot.spill.load187 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %204 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load187, 0
  %205 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load187, 1
  %.state188 = load i64, ptr %.slot39, align 4
  %.splatinsert189 = insertelement <8 x i64> poison, i64 %.state188, i64 0
  %.splat190 = shufflevector <8 x i64> %.splatinsert189, <8 x i64> poison, <8 x i32> zeroinitializer
  %206 = mul <8 x i64> %.splat190, splat (i64 32)
  %207 = add <8 x i64> %205, %206
  %208 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %204, 0
  %209 = insertvalue { <8 x ptr>, <8 x i64> } %208, <8 x i64> %207, 1
  %.state191 = load <8 x float>, ptr %.slot41, align 32
  %210 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %211 = extractvalue { <8 x ptr>, <8 x i64> } %209, 1
  %212 = extractelement <8 x ptr> %210, i32 0
  %213 = extractelement <8 x i64> %211, i32 0
  %214 = sub i64 %213, 0
  %215 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %216 = select i1 %215, i64 %214, i64 0
  %private.contiguous.address192 = getelementptr i8, ptr %212, i64 %216
  %private.contiguous.preserve193 = load <8 x float>, ptr %private.contiguous.address192, align 4
  %217 = select <8 x i1> %71, <8 x float> %.state191, <8 x float> %private.contiguous.preserve193
  store <8 x float> %217, ptr %private.contiguous.address192, align 4
  %.state194 = load i64, ptr %.slot39, align 4
  %218 = add i64 %.state194, 1
  store i64 %218, ptr %.slot39, align 4
  br label %direct.schedule.9

direct.schedule.13:                               ; preds = %direct.false175
  %219 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %219, 0
  %222 = select <8 x i1> %71, <8 x ptr> %220, <8 x ptr> %221
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %224 = extractvalue { <8 x ptr>, <8 x i64> } %219, 1
  %225 = select <8 x i1> %71, <8 x i64> %223, <8 x i64> %224
  %226 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %222, 0
  %227 = insertvalue { <8 x ptr>, <8 x i64> } %226, <8 x i64> %225, 1
  store { <8 x ptr>, <8 x i64> } %227, ptr %tile_snapshot.spill42, align 64
  store i64 0, ptr %.slot43, align 4
  br label %direct.schedule.14

direct.schedule.14:                               ; preds = %direct.schedule.17, %direct.schedule.13
  %.state195 = load i64, ptr %.slot43, align 4
  %228 = icmp slt i64 %.state195, 1536
  br i1 %228, label %direct.true196, label %direct.false197

direct.schedule.15:                               ; preds = %direct.true196
  %.state198 = load i64, ptr %.slot43, align 4
  %229 = srem i64 %.state198, 96
  %.state199 = load i64, ptr %.slot43, align 4
  %230 = sdiv i64 %.state199, 96
  %.spill.load200 = load <8 x i64>, ptr %.spill30, align 64
  %231 = add <8 x i64> %.spill.load200, zeroinitializer
  %232 = add <8 x i64> zeroinitializer, %231
  %.spill.load201 = load i64, ptr %.spill37, align 4
  %233 = add i64 %.spill.load201, %230
  %234 = mul <8 x i64> %232, splat (i64 67)
  %.splatinsert202 = insertelement <8 x i64> poison, i64 %233, i64 0
  %.splat203 = shufflevector <8 x i64> %.splatinsert202, <8 x i64> poison, <8 x i32> zeroinitializer
  %235 = add <8 x i64> %234, %.splat203
  %236 = icmp sge i64 %233, 0
  %237 = and i1 true, %236
  %238 = icmp slt i64 %233, 67
  %239 = and i1 %237, %238
  %240 = add i64 0, %229
  %241 = mul <8 x i64> %235, splat (i64 96)
  %.splatinsert204 = insertelement <8 x i64> poison, i64 %240, i64 0
  %.splat205 = shufflevector <8 x i64> %.splatinsert204, <8 x i64> poison, <8 x i32> zeroinitializer
  %242 = add <8 x i64> %241, %.splat205
  %243 = load <8 x i64>, ptr %.spill44, align 64
  %244 = select <8 x i1> %71, <8 x i64> %242, <8 x i64> %243
  store <8 x i64> %244, ptr %.spill44, align 64
  br i1 %239, label %direct.true206, label %direct.false207

direct.schedule.16:                               ; preds = %direct.true206
  %.spill.load208 = load <8 x i64>, ptr %.spill44, align 64
  %245 = extractvalue { ptr, i64 } %41, 0
  %246 = mul <8 x i64> %.spill.load208, splat (i64 4)
  %247 = getelementptr i8, ptr %245, <8 x i64> %246
  %248 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %247, <8 x i1> %71, <8 x float> zeroinitializer)
  %249 = load <8 x float>, ptr %.slot45, align 32
  %250 = select <8 x i1> %71, <8 x float> %248, <8 x float> %249
  store <8 x float> %250, ptr %.slot45, align 32
  br label %direct.schedule.17

direct.schedule.17:                               ; preds = %direct.false207, %direct.schedule.16
  %tile_snapshot.spill.load209 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %251 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load209, 0
  %252 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load209, 1
  %.state210 = load i64, ptr %.slot43, align 4
  %.splatinsert211 = insertelement <8 x i64> poison, i64 %.state210, i64 0
  %.splat212 = shufflevector <8 x i64> %.splatinsert211, <8 x i64> poison, <8 x i32> zeroinitializer
  %253 = mul <8 x i64> %.splat212, splat (i64 32)
  %254 = add <8 x i64> %252, %253
  %255 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %251, 0
  %256 = insertvalue { <8 x ptr>, <8 x i64> } %255, <8 x i64> %254, 1
  %.state213 = load <8 x float>, ptr %.slot45, align 32
  %257 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %258 = extractvalue { <8 x ptr>, <8 x i64> } %256, 1
  %259 = extractelement <8 x ptr> %257, i32 0
  %260 = extractelement <8 x i64> %258, i32 0
  %261 = sub i64 %260, 0
  %262 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %263 = select i1 %262, i64 %261, i64 0
  %private.contiguous.address214 = getelementptr i8, ptr %259, i64 %263
  %private.contiguous.preserve215 = load <8 x float>, ptr %private.contiguous.address214, align 4
  %264 = select <8 x i1> %71, <8 x float> %.state213, <8 x float> %private.contiguous.preserve215
  store <8 x float> %264, ptr %private.contiguous.address214, align 4
  %.state216 = load i64, ptr %.slot43, align 4
  %265 = add i64 %.state216, 1
  store i64 %265, ptr %.slot43, align 4
  br label %direct.schedule.14

direct.schedule.18:                               ; preds = %direct.false197
  store i64 0, ptr %.slot46, align 4
  %266 = load <8 x float>, ptr %.slot47, align 32
  %267 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %266
  store <8 x float> %267, ptr %.slot47, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state217 = load i64, ptr %.slot46, align 4
  %268 = icmp slt i64 %.state217, 80
  br i1 %268, label %direct.true218, label %direct.false219

direct.schedule.20:                               ; preds = %direct.true218
  %.state220 = load i64, ptr %.slot46, align 4
  %269 = add i64 0, %.state220
  %tile_snapshot.spill.load221 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %270 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 0
  %271 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 1
  %.splatinsert222 = insertelement <8 x i64> poison, i64 %269, i64 0
  %.splat223 = shufflevector <8 x i64> %.splatinsert222, <8 x i64> poison, <8 x i32> zeroinitializer
  %272 = mul <8 x i64> %.splat223, splat (i64 32)
  %273 = add <8 x i64> %271, %272
  %274 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %270, 0
  %275 = insertvalue { <8 x ptr>, <8 x i64> } %274, <8 x i64> %273, 1
  %276 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %277 = extractvalue { <8 x ptr>, <8 x i64> } %275, 1
  %278 = extractelement <8 x ptr> %276, i32 0
  %279 = extractelement <8 x i64> %277, i32 0
  %280 = sub i64 %279, 0
  %281 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %282 = select i1 %281, i64 %280, i64 0
  %private.contiguous.address224 = getelementptr i8, ptr %278, i64 %282
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address224, align 4
  %283 = select <8 x i1> %71, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load225 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %284 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load225, 0
  %285 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load225, 1
  %.splatinsert226 = insertelement <8 x i64> poison, i64 %269, i64 0
  %.splat227 = shufflevector <8 x i64> %.splatinsert226, <8 x i64> poison, <8 x i32> zeroinitializer
  %286 = mul <8 x i64> %.splat227, splat (i64 32)
  %287 = add <8 x i64> %285, %286
  %288 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %284, 0
  %289 = insertvalue { <8 x ptr>, <8 x i64> } %288, <8 x i64> %287, 1
  %290 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %291 = extractvalue { <8 x ptr>, <8 x i64> } %289, 1
  %292 = extractelement <8 x ptr> %290, i32 0
  %293 = extractelement <8 x i64> %291, i32 0
  %294 = sub i64 %293, 0
  %295 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %296 = select i1 %295, i64 %294, i64 0
  %private.contiguous.address228 = getelementptr i8, ptr %292, i64 %296
  %private.contiguous.load229 = load <8 x float>, ptr %private.contiguous.address228, align 4
  %297 = select <8 x i1> %71, <8 x float> %private.contiguous.load229, <8 x float> zeroinitializer
  %298 = fmul <8 x float> %283, %297
  %.state230 = load <8 x float>, ptr %.slot47, align 32
  %299 = fadd <8 x float> %.state230, %298
  %.state231 = load i64, ptr %.slot46, align 4
  %300 = add i64 %.state231, 1
  store i64 %300, ptr %.slot46, align 4
  %301 = load <8 x float>, ptr %.slot47, align 32
  %302 = select <8 x i1> %71, <8 x float> %299, <8 x float> %301
  store <8 x float> %302, ptr %.slot47, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false219
  store i64 0, ptr %.slot48, align 4
  %303 = load <8 x float>, ptr %.slot49, align 32
  %304 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %303
  store <8 x float> %304, ptr %.slot49, align 32
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state232 = load i64, ptr %.slot48, align 4
  %305 = icmp slt i64 %.state232, 80
  br i1 %305, label %direct.true233, label %direct.false234

direct.schedule.23:                               ; preds = %direct.true233
  %.state235 = load i64, ptr %.slot48, align 4
  %306 = add i64 0, %.state235
  %tile_snapshot.spill.load236 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %307 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load236, 0
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load236, 1
  %.splatinsert237 = insertelement <8 x i64> poison, i64 %306, i64 0
  %.splat238 = shufflevector <8 x i64> %.splatinsert237, <8 x i64> poison, <8 x i32> zeroinitializer
  %309 = mul <8 x i64> %.splat238, splat (i64 32)
  %310 = add <8 x i64> %308, %309
  %311 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %307, 0
  %312 = insertvalue { <8 x ptr>, <8 x i64> } %311, <8 x i64> %310, 1
  %313 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %312, 1
  %315 = extractelement <8 x ptr> %313, i32 0
  %316 = extractelement <8 x i64> %314, i32 0
  %317 = sub i64 %316, 0
  %318 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %319 = select i1 %318, i64 %317, i64 0
  %private.contiguous.address239 = getelementptr i8, ptr %315, i64 %319
  %private.contiguous.load240 = load <8 x float>, ptr %private.contiguous.address239, align 4
  %320 = select <8 x i1> %71, <8 x float> %private.contiguous.load240, <8 x float> zeroinitializer
  %.state241 = load i64, ptr %.slot48, align 4
  %321 = add i64 80, %.state241
  %tile_snapshot.spill.load242 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load242, 0
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load242, 1
  %.splatinsert243 = insertelement <8 x i64> poison, i64 %321, i64 0
  %.splat244 = shufflevector <8 x i64> %.splatinsert243, <8 x i64> poison, <8 x i32> zeroinitializer
  %324 = mul <8 x i64> %.splat244, splat (i64 32)
  %325 = add <8 x i64> %323, %324
  %326 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %322, 0
  %327 = insertvalue { <8 x ptr>, <8 x i64> } %326, <8 x i64> %325, 1
  %328 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %327, 1
  %330 = extractelement <8 x ptr> %328, i32 0
  %331 = extractelement <8 x i64> %329, i32 0
  %332 = sub i64 %331, 0
  %333 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %334 = select i1 %333, i64 %332, i64 0
  %private.contiguous.address245 = getelementptr i8, ptr %330, i64 %334
  %private.contiguous.load246 = load <8 x float>, ptr %private.contiguous.address245, align 4
  %335 = select <8 x i1> %71, <8 x float> %private.contiguous.load246, <8 x float> zeroinitializer
  %336 = fmul <8 x float> %320, %335
  %.state247 = load <8 x float>, ptr %.slot49, align 32
  %337 = fadd <8 x float> %.state247, %336
  %.state248 = load i64, ptr %.slot48, align 4
  %338 = add i64 %.state248, 1
  store i64 %338, ptr %.slot48, align 4
  %339 = load <8 x float>, ptr %.slot49, align 32
  %340 = select <8 x i1> %71, <8 x float> %337, <8 x float> %339
  store <8 x float> %340, ptr %.slot49, align 32
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false234
  store i64 0, ptr %.slot50, align 4
  %341 = load <8 x float>, ptr %.slot51, align 32
  %342 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %341
  store <8 x float> %342, ptr %.slot51, align 32
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.26, %direct.schedule.24
  %.state249 = load i64, ptr %.slot50, align 4
  %343 = icmp slt i64 %.state249, 80
  br i1 %343, label %direct.true250, label %direct.false251

direct.schedule.26:                               ; preds = %direct.true250
  %.state252 = load i64, ptr %.slot50, align 4
  %344 = add i64 0, %.state252
  %tile_snapshot.spill.load253 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %345 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load253, 0
  %346 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load253, 1
  %.splatinsert254 = insertelement <8 x i64> poison, i64 %344, i64 0
  %.splat255 = shufflevector <8 x i64> %.splatinsert254, <8 x i64> poison, <8 x i32> zeroinitializer
  %347 = mul <8 x i64> %.splat255, splat (i64 32)
  %348 = add <8 x i64> %346, %347
  %349 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %345, 0
  %350 = insertvalue { <8 x ptr>, <8 x i64> } %349, <8 x i64> %348, 1
  %351 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %352 = extractvalue { <8 x ptr>, <8 x i64> } %350, 1
  %353 = extractelement <8 x ptr> %351, i32 0
  %354 = extractelement <8 x i64> %352, i32 0
  %355 = sub i64 %354, 0
  %356 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %357 = select i1 %356, i64 %355, i64 0
  %private.contiguous.address256 = getelementptr i8, ptr %353, i64 %357
  %private.contiguous.load257 = load <8 x float>, ptr %private.contiguous.address256, align 4
  %358 = select <8 x i1> %71, <8 x float> %private.contiguous.load257, <8 x float> zeroinitializer
  %.state258 = load i64, ptr %.slot50, align 4
  %359 = add i64 160, %.state258
  %tile_snapshot.spill.load259 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %360 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load259, 0
  %361 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load259, 1
  %.splatinsert260 = insertelement <8 x i64> poison, i64 %359, i64 0
  %.splat261 = shufflevector <8 x i64> %.splatinsert260, <8 x i64> poison, <8 x i32> zeroinitializer
  %362 = mul <8 x i64> %.splat261, splat (i64 32)
  %363 = add <8 x i64> %361, %362
  %364 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %360, 0
  %365 = insertvalue { <8 x ptr>, <8 x i64> } %364, <8 x i64> %363, 1
  %366 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %367 = extractvalue { <8 x ptr>, <8 x i64> } %365, 1
  %368 = extractelement <8 x ptr> %366, i32 0
  %369 = extractelement <8 x i64> %367, i32 0
  %370 = sub i64 %369, 0
  %371 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %372 = select i1 %371, i64 %370, i64 0
  %private.contiguous.address262 = getelementptr i8, ptr %368, i64 %372
  %private.contiguous.load263 = load <8 x float>, ptr %private.contiguous.address262, align 4
  %373 = select <8 x i1> %71, <8 x float> %private.contiguous.load263, <8 x float> zeroinitializer
  %374 = fmul <8 x float> %358, %373
  %.state264 = load <8 x float>, ptr %.slot51, align 32
  %375 = fadd <8 x float> %.state264, %374
  %.state265 = load i64, ptr %.slot50, align 4
  %376 = add i64 %.state265, 1
  store i64 %376, ptr %.slot50, align 4
  %377 = load <8 x float>, ptr %.slot51, align 32
  %378 = select <8 x i1> %71, <8 x float> %375, <8 x float> %377
  store <8 x float> %378, ptr %.slot51, align 32
  br label %direct.schedule.25

direct.schedule.27:                               ; preds = %direct.false251
  store i64 0, ptr %.slot52, align 4
  %379 = load <8 x float>, ptr %.slot53, align 32
  %380 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %379
  store <8 x float> %380, ptr %.slot53, align 32
  br label %direct.schedule.28

direct.schedule.28:                               ; preds = %direct.schedule.29, %direct.schedule.27
  %.state266 = load i64, ptr %.slot52, align 4
  %381 = icmp slt i64 %.state266, 80
  br i1 %381, label %direct.true267, label %direct.false268

direct.schedule.29:                               ; preds = %direct.true267
  %.state269 = load i64, ptr %.slot52, align 4
  %382 = add i64 0, %.state269
  %tile_snapshot.spill.load270 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %383 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 0
  %384 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 1
  %.splatinsert271 = insertelement <8 x i64> poison, i64 %382, i64 0
  %.splat272 = shufflevector <8 x i64> %.splatinsert271, <8 x i64> poison, <8 x i32> zeroinitializer
  %385 = mul <8 x i64> %.splat272, splat (i64 32)
  %386 = add <8 x i64> %384, %385
  %387 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %383, 0
  %388 = insertvalue { <8 x ptr>, <8 x i64> } %387, <8 x i64> %386, 1
  %389 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %390 = extractvalue { <8 x ptr>, <8 x i64> } %388, 1
  %391 = extractelement <8 x ptr> %389, i32 0
  %392 = extractelement <8 x i64> %390, i32 0
  %393 = sub i64 %392, 0
  %394 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %395 = select i1 %394, i64 %393, i64 0
  %private.contiguous.address273 = getelementptr i8, ptr %391, i64 %395
  %private.contiguous.load274 = load <8 x float>, ptr %private.contiguous.address273, align 4
  %396 = select <8 x i1> %71, <8 x float> %private.contiguous.load274, <8 x float> zeroinitializer
  %.state275 = load i64, ptr %.slot52, align 4
  %397 = add i64 240, %.state275
  %tile_snapshot.spill.load276 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %398 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load276, 0
  %399 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load276, 1
  %.splatinsert277 = insertelement <8 x i64> poison, i64 %397, i64 0
  %.splat278 = shufflevector <8 x i64> %.splatinsert277, <8 x i64> poison, <8 x i32> zeroinitializer
  %400 = mul <8 x i64> %.splat278, splat (i64 32)
  %401 = add <8 x i64> %399, %400
  %402 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %398, 0
  %403 = insertvalue { <8 x ptr>, <8 x i64> } %402, <8 x i64> %401, 1
  %404 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %405 = extractvalue { <8 x ptr>, <8 x i64> } %403, 1
  %406 = extractelement <8 x ptr> %404, i32 0
  %407 = extractelement <8 x i64> %405, i32 0
  %408 = sub i64 %407, 0
  %409 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %410 = select i1 %409, i64 %408, i64 0
  %private.contiguous.address279 = getelementptr i8, ptr %406, i64 %410
  %private.contiguous.load280 = load <8 x float>, ptr %private.contiguous.address279, align 4
  %411 = select <8 x i1> %71, <8 x float> %private.contiguous.load280, <8 x float> zeroinitializer
  %412 = fmul <8 x float> %396, %411
  %.state281 = load <8 x float>, ptr %.slot53, align 32
  %413 = fadd <8 x float> %.state281, %412
  %.state282 = load i64, ptr %.slot52, align 4
  %414 = add i64 %.state282, 1
  store i64 %414, ptr %.slot52, align 4
  %415 = load <8 x float>, ptr %.slot53, align 32
  %416 = select <8 x i1> %71, <8 x float> %413, <8 x float> %415
  store <8 x float> %416, ptr %.slot53, align 32
  br label %direct.schedule.28

direct.schedule.30:                               ; preds = %direct.false268
  store i64 0, ptr %.slot54, align 4
  %417 = load <8 x float>, ptr %.slot55, align 32
  %418 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %417
  store <8 x float> %418, ptr %.slot55, align 32
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.32, %direct.schedule.30
  %.state283 = load i64, ptr %.slot54, align 4
  %419 = icmp slt i64 %.state283, 80
  br i1 %419, label %direct.true284, label %direct.false285

direct.schedule.32:                               ; preds = %direct.true284
  %.state286 = load i64, ptr %.slot54, align 4
  %420 = add i64 0, %.state286
  %tile_snapshot.spill.load287 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %421 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load287, 0
  %422 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load287, 1
  %.splatinsert288 = insertelement <8 x i64> poison, i64 %420, i64 0
  %.splat289 = shufflevector <8 x i64> %.splatinsert288, <8 x i64> poison, <8 x i32> zeroinitializer
  %423 = mul <8 x i64> %.splat289, splat (i64 32)
  %424 = add <8 x i64> %422, %423
  %425 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %421, 0
  %426 = insertvalue { <8 x ptr>, <8 x i64> } %425, <8 x i64> %424, 1
  %427 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %428 = extractvalue { <8 x ptr>, <8 x i64> } %426, 1
  %429 = extractelement <8 x ptr> %427, i32 0
  %430 = extractelement <8 x i64> %428, i32 0
  %431 = sub i64 %430, 0
  %432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %433 = select i1 %432, i64 %431, i64 0
  %private.contiguous.address290 = getelementptr i8, ptr %429, i64 %433
  %private.contiguous.load291 = load <8 x float>, ptr %private.contiguous.address290, align 4
  %434 = select <8 x i1> %71, <8 x float> %private.contiguous.load291, <8 x float> zeroinitializer
  %.state292 = load i64, ptr %.slot54, align 4
  %435 = add i64 320, %.state292
  %tile_snapshot.spill.load293 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %436 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load293, 0
  %437 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load293, 1
  %.splatinsert294 = insertelement <8 x i64> poison, i64 %435, i64 0
  %.splat295 = shufflevector <8 x i64> %.splatinsert294, <8 x i64> poison, <8 x i32> zeroinitializer
  %438 = mul <8 x i64> %.splat295, splat (i64 32)
  %439 = add <8 x i64> %437, %438
  %440 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %436, 0
  %441 = insertvalue { <8 x ptr>, <8 x i64> } %440, <8 x i64> %439, 1
  %442 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %443 = extractvalue { <8 x ptr>, <8 x i64> } %441, 1
  %444 = extractelement <8 x ptr> %442, i32 0
  %445 = extractelement <8 x i64> %443, i32 0
  %446 = sub i64 %445, 0
  %447 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %448 = select i1 %447, i64 %446, i64 0
  %private.contiguous.address296 = getelementptr i8, ptr %444, i64 %448
  %private.contiguous.load297 = load <8 x float>, ptr %private.contiguous.address296, align 4
  %449 = select <8 x i1> %71, <8 x float> %private.contiguous.load297, <8 x float> zeroinitializer
  %450 = fmul <8 x float> %434, %449
  %.state298 = load <8 x float>, ptr %.slot55, align 32
  %451 = fadd <8 x float> %.state298, %450
  %.state299 = load i64, ptr %.slot54, align 4
  %452 = add i64 %.state299, 1
  store i64 %452, ptr %.slot54, align 4
  %453 = load <8 x float>, ptr %.slot55, align 32
  %454 = select <8 x i1> %71, <8 x float> %451, <8 x float> %453
  store <8 x float> %454, ptr %.slot55, align 32
  br label %direct.schedule.31

direct.schedule.33:                               ; preds = %direct.false285
  store i64 0, ptr %.slot56, align 4
  %455 = load <8 x float>, ptr %.slot57, align 32
  %456 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %455
  store <8 x float> %456, ptr %.slot57, align 32
  br label %direct.schedule.34

direct.schedule.34:                               ; preds = %direct.schedule.35, %direct.schedule.33
  %.state300 = load i64, ptr %.slot56, align 4
  %457 = icmp slt i64 %.state300, 80
  br i1 %457, label %direct.true301, label %direct.false302

direct.schedule.35:                               ; preds = %direct.true301
  %.state303 = load i64, ptr %.slot56, align 4
  %458 = add i64 0, %.state303
  %tile_snapshot.spill.load304 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %459 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load304, 0
  %460 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load304, 1
  %.splatinsert305 = insertelement <8 x i64> poison, i64 %458, i64 0
  %.splat306 = shufflevector <8 x i64> %.splatinsert305, <8 x i64> poison, <8 x i32> zeroinitializer
  %461 = mul <8 x i64> %.splat306, splat (i64 32)
  %462 = add <8 x i64> %460, %461
  %463 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %459, 0
  %464 = insertvalue { <8 x ptr>, <8 x i64> } %463, <8 x i64> %462, 1
  %465 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %466 = extractvalue { <8 x ptr>, <8 x i64> } %464, 1
  %467 = extractelement <8 x ptr> %465, i32 0
  %468 = extractelement <8 x i64> %466, i32 0
  %469 = sub i64 %468, 0
  %470 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %471 = select i1 %470, i64 %469, i64 0
  %private.contiguous.address307 = getelementptr i8, ptr %467, i64 %471
  %private.contiguous.load308 = load <8 x float>, ptr %private.contiguous.address307, align 4
  %472 = select <8 x i1> %71, <8 x float> %private.contiguous.load308, <8 x float> zeroinitializer
  %.state309 = load i64, ptr %.slot56, align 4
  %473 = add i64 400, %.state309
  %tile_snapshot.spill.load310 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %474 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load310, 0
  %475 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load310, 1
  %.splatinsert311 = insertelement <8 x i64> poison, i64 %473, i64 0
  %.splat312 = shufflevector <8 x i64> %.splatinsert311, <8 x i64> poison, <8 x i32> zeroinitializer
  %476 = mul <8 x i64> %.splat312, splat (i64 32)
  %477 = add <8 x i64> %475, %476
  %478 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %474, 0
  %479 = insertvalue { <8 x ptr>, <8 x i64> } %478, <8 x i64> %477, 1
  %480 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %481 = extractvalue { <8 x ptr>, <8 x i64> } %479, 1
  %482 = extractelement <8 x ptr> %480, i32 0
  %483 = extractelement <8 x i64> %481, i32 0
  %484 = sub i64 %483, 0
  %485 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %486 = select i1 %485, i64 %484, i64 0
  %private.contiguous.address313 = getelementptr i8, ptr %482, i64 %486
  %private.contiguous.load314 = load <8 x float>, ptr %private.contiguous.address313, align 4
  %487 = select <8 x i1> %71, <8 x float> %private.contiguous.load314, <8 x float> zeroinitializer
  %488 = fmul <8 x float> %472, %487
  %.state315 = load <8 x float>, ptr %.slot57, align 32
  %489 = fadd <8 x float> %.state315, %488
  %.state316 = load i64, ptr %.slot56, align 4
  %490 = add i64 %.state316, 1
  store i64 %490, ptr %.slot56, align 4
  %491 = load <8 x float>, ptr %.slot57, align 32
  %492 = select <8 x i1> %71, <8 x float> %489, <8 x float> %491
  store <8 x float> %492, ptr %.slot57, align 32
  br label %direct.schedule.34

direct.schedule.36:                               ; preds = %direct.false302
  store i64 0, ptr %.slot58, align 4
  %493 = load <8 x float>, ptr %.slot59, align 32
  %494 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %493
  store <8 x float> %494, ptr %.slot59, align 32
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.38, %direct.schedule.36
  %.state317 = load i64, ptr %.slot58, align 4
  %495 = icmp slt i64 %.state317, 80
  br i1 %495, label %direct.true318, label %direct.false319

direct.schedule.38:                               ; preds = %direct.true318
  %.state320 = load i64, ptr %.slot58, align 4
  %496 = add i64 0, %.state320
  %tile_snapshot.spill.load321 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %497 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load321, 0
  %498 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load321, 1
  %.splatinsert322 = insertelement <8 x i64> poison, i64 %496, i64 0
  %.splat323 = shufflevector <8 x i64> %.splatinsert322, <8 x i64> poison, <8 x i32> zeroinitializer
  %499 = mul <8 x i64> %.splat323, splat (i64 32)
  %500 = add <8 x i64> %498, %499
  %501 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %497, 0
  %502 = insertvalue { <8 x ptr>, <8 x i64> } %501, <8 x i64> %500, 1
  %503 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %504 = extractvalue { <8 x ptr>, <8 x i64> } %502, 1
  %505 = extractelement <8 x ptr> %503, i32 0
  %506 = extractelement <8 x i64> %504, i32 0
  %507 = sub i64 %506, 0
  %508 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %509 = select i1 %508, i64 %507, i64 0
  %private.contiguous.address324 = getelementptr i8, ptr %505, i64 %509
  %private.contiguous.load325 = load <8 x float>, ptr %private.contiguous.address324, align 4
  %510 = select <8 x i1> %71, <8 x float> %private.contiguous.load325, <8 x float> zeroinitializer
  %.state326 = load i64, ptr %.slot58, align 4
  %511 = add i64 480, %.state326
  %tile_snapshot.spill.load327 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %512 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load327, 0
  %513 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load327, 1
  %.splatinsert328 = insertelement <8 x i64> poison, i64 %511, i64 0
  %.splat329 = shufflevector <8 x i64> %.splatinsert328, <8 x i64> poison, <8 x i32> zeroinitializer
  %514 = mul <8 x i64> %.splat329, splat (i64 32)
  %515 = add <8 x i64> %513, %514
  %516 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %512, 0
  %517 = insertvalue { <8 x ptr>, <8 x i64> } %516, <8 x i64> %515, 1
  %518 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %519 = extractvalue { <8 x ptr>, <8 x i64> } %517, 1
  %520 = extractelement <8 x ptr> %518, i32 0
  %521 = extractelement <8 x i64> %519, i32 0
  %522 = sub i64 %521, 0
  %523 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %524 = select i1 %523, i64 %522, i64 0
  %private.contiguous.address330 = getelementptr i8, ptr %520, i64 %524
  %private.contiguous.load331 = load <8 x float>, ptr %private.contiguous.address330, align 4
  %525 = select <8 x i1> %71, <8 x float> %private.contiguous.load331, <8 x float> zeroinitializer
  %526 = fmul <8 x float> %510, %525
  %.state332 = load <8 x float>, ptr %.slot59, align 32
  %527 = fadd <8 x float> %.state332, %526
  %.state333 = load i64, ptr %.slot58, align 4
  %528 = add i64 %.state333, 1
  store i64 %528, ptr %.slot58, align 4
  %529 = load <8 x float>, ptr %.slot59, align 32
  %530 = select <8 x i1> %71, <8 x float> %527, <8 x float> %529
  store <8 x float> %530, ptr %.slot59, align 32
  br label %direct.schedule.37

direct.schedule.39:                               ; preds = %direct.false319
  store i64 0, ptr %.slot60, align 4
  %531 = load <8 x float>, ptr %.slot61, align 32
  %532 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %531
  store <8 x float> %532, ptr %.slot61, align 32
  br label %direct.schedule.40

direct.schedule.40:                               ; preds = %direct.schedule.41, %direct.schedule.39
  %.state334 = load i64, ptr %.slot60, align 4
  %533 = icmp slt i64 %.state334, 80
  br i1 %533, label %direct.true335, label %direct.false336

direct.schedule.41:                               ; preds = %direct.true335
  %.state337 = load i64, ptr %.slot60, align 4
  %534 = add i64 0, %.state337
  %tile_snapshot.spill.load338 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %535 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load338, 0
  %536 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load338, 1
  %.splatinsert339 = insertelement <8 x i64> poison, i64 %534, i64 0
  %.splat340 = shufflevector <8 x i64> %.splatinsert339, <8 x i64> poison, <8 x i32> zeroinitializer
  %537 = mul <8 x i64> %.splat340, splat (i64 32)
  %538 = add <8 x i64> %536, %537
  %539 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %535, 0
  %540 = insertvalue { <8 x ptr>, <8 x i64> } %539, <8 x i64> %538, 1
  %541 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %542 = extractvalue { <8 x ptr>, <8 x i64> } %540, 1
  %543 = extractelement <8 x ptr> %541, i32 0
  %544 = extractelement <8 x i64> %542, i32 0
  %545 = sub i64 %544, 0
  %546 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %547 = select i1 %546, i64 %545, i64 0
  %private.contiguous.address341 = getelementptr i8, ptr %543, i64 %547
  %private.contiguous.load342 = load <8 x float>, ptr %private.contiguous.address341, align 4
  %548 = select <8 x i1> %71, <8 x float> %private.contiguous.load342, <8 x float> zeroinitializer
  %.state343 = load i64, ptr %.slot60, align 4
  %549 = add i64 560, %.state343
  %tile_snapshot.spill.load344 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %550 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load344, 0
  %551 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load344, 1
  %.splatinsert345 = insertelement <8 x i64> poison, i64 %549, i64 0
  %.splat346 = shufflevector <8 x i64> %.splatinsert345, <8 x i64> poison, <8 x i32> zeroinitializer
  %552 = mul <8 x i64> %.splat346, splat (i64 32)
  %553 = add <8 x i64> %551, %552
  %554 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %550, 0
  %555 = insertvalue { <8 x ptr>, <8 x i64> } %554, <8 x i64> %553, 1
  %556 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %557 = extractvalue { <8 x ptr>, <8 x i64> } %555, 1
  %558 = extractelement <8 x ptr> %556, i32 0
  %559 = extractelement <8 x i64> %557, i32 0
  %560 = sub i64 %559, 0
  %561 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %562 = select i1 %561, i64 %560, i64 0
  %private.contiguous.address347 = getelementptr i8, ptr %558, i64 %562
  %private.contiguous.load348 = load <8 x float>, ptr %private.contiguous.address347, align 4
  %563 = select <8 x i1> %71, <8 x float> %private.contiguous.load348, <8 x float> zeroinitializer
  %564 = fmul <8 x float> %548, %563
  %.state349 = load <8 x float>, ptr %.slot61, align 32
  %565 = fadd <8 x float> %.state349, %564
  %.state350 = load i64, ptr %.slot60, align 4
  %566 = add i64 %.state350, 1
  store i64 %566, ptr %.slot60, align 4
  %567 = load <8 x float>, ptr %.slot61, align 32
  %568 = select <8 x i1> %71, <8 x float> %565, <8 x float> %567
  store <8 x float> %568, ptr %.slot61, align 32
  br label %direct.schedule.40

direct.schedule.42:                               ; preds = %direct.false336
  store i64 0, ptr %.slot62, align 4
  %569 = load <8 x float>, ptr %.slot63, align 32
  %570 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %569
  store <8 x float> %570, ptr %.slot63, align 32
  br label %direct.schedule.43

direct.schedule.43:                               ; preds = %direct.schedule.44, %direct.schedule.42
  %.state351 = load i64, ptr %.slot62, align 4
  %571 = icmp slt i64 %.state351, 80
  br i1 %571, label %direct.true352, label %direct.false353

direct.schedule.44:                               ; preds = %direct.true352
  %.state354 = load i64, ptr %.slot62, align 4
  %572 = add i64 0, %.state354
  %tile_snapshot.spill.load355 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %573 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load355, 0
  %574 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load355, 1
  %.splatinsert356 = insertelement <8 x i64> poison, i64 %572, i64 0
  %.splat357 = shufflevector <8 x i64> %.splatinsert356, <8 x i64> poison, <8 x i32> zeroinitializer
  %575 = mul <8 x i64> %.splat357, splat (i64 32)
  %576 = add <8 x i64> %574, %575
  %577 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %573, 0
  %578 = insertvalue { <8 x ptr>, <8 x i64> } %577, <8 x i64> %576, 1
  %579 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %580 = extractvalue { <8 x ptr>, <8 x i64> } %578, 1
  %581 = extractelement <8 x ptr> %579, i32 0
  %582 = extractelement <8 x i64> %580, i32 0
  %583 = sub i64 %582, 0
  %584 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %585 = select i1 %584, i64 %583, i64 0
  %private.contiguous.address358 = getelementptr i8, ptr %581, i64 %585
  %private.contiguous.load359 = load <8 x float>, ptr %private.contiguous.address358, align 4
  %586 = select <8 x i1> %71, <8 x float> %private.contiguous.load359, <8 x float> zeroinitializer
  %.state360 = load i64, ptr %.slot62, align 4
  %587 = add i64 640, %.state360
  %tile_snapshot.spill.load361 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %588 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load361, 0
  %589 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load361, 1
  %.splatinsert362 = insertelement <8 x i64> poison, i64 %587, i64 0
  %.splat363 = shufflevector <8 x i64> %.splatinsert362, <8 x i64> poison, <8 x i32> zeroinitializer
  %590 = mul <8 x i64> %.splat363, splat (i64 32)
  %591 = add <8 x i64> %589, %590
  %592 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %588, 0
  %593 = insertvalue { <8 x ptr>, <8 x i64> } %592, <8 x i64> %591, 1
  %594 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %595 = extractvalue { <8 x ptr>, <8 x i64> } %593, 1
  %596 = extractelement <8 x ptr> %594, i32 0
  %597 = extractelement <8 x i64> %595, i32 0
  %598 = sub i64 %597, 0
  %599 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %600 = select i1 %599, i64 %598, i64 0
  %private.contiguous.address364 = getelementptr i8, ptr %596, i64 %600
  %private.contiguous.load365 = load <8 x float>, ptr %private.contiguous.address364, align 4
  %601 = select <8 x i1> %71, <8 x float> %private.contiguous.load365, <8 x float> zeroinitializer
  %602 = fmul <8 x float> %586, %601
  %.state366 = load <8 x float>, ptr %.slot63, align 32
  %603 = fadd <8 x float> %.state366, %602
  %.state367 = load i64, ptr %.slot62, align 4
  %604 = add i64 %.state367, 1
  store i64 %604, ptr %.slot62, align 4
  %605 = load <8 x float>, ptr %.slot63, align 32
  %606 = select <8 x i1> %71, <8 x float> %603, <8 x float> %605
  store <8 x float> %606, ptr %.slot63, align 32
  br label %direct.schedule.43

direct.schedule.45:                               ; preds = %direct.false353
  store i64 0, ptr %.slot64, align 4
  %607 = load <8 x float>, ptr %.slot65, align 32
  %608 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %607
  store <8 x float> %608, ptr %.slot65, align 32
  br label %direct.schedule.46

direct.schedule.46:                               ; preds = %direct.schedule.47, %direct.schedule.45
  %.state368 = load i64, ptr %.slot64, align 4
  %609 = icmp slt i64 %.state368, 80
  br i1 %609, label %direct.true369, label %direct.false370

direct.schedule.47:                               ; preds = %direct.true369
  %.state371 = load i64, ptr %.slot64, align 4
  %610 = add i64 0, %.state371
  %tile_snapshot.spill.load372 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %611 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load372, 0
  %612 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load372, 1
  %.splatinsert373 = insertelement <8 x i64> poison, i64 %610, i64 0
  %.splat374 = shufflevector <8 x i64> %.splatinsert373, <8 x i64> poison, <8 x i32> zeroinitializer
  %613 = mul <8 x i64> %.splat374, splat (i64 32)
  %614 = add <8 x i64> %612, %613
  %615 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %611, 0
  %616 = insertvalue { <8 x ptr>, <8 x i64> } %615, <8 x i64> %614, 1
  %617 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %618 = extractvalue { <8 x ptr>, <8 x i64> } %616, 1
  %619 = extractelement <8 x ptr> %617, i32 0
  %620 = extractelement <8 x i64> %618, i32 0
  %621 = sub i64 %620, 0
  %622 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %623 = select i1 %622, i64 %621, i64 0
  %private.contiguous.address375 = getelementptr i8, ptr %619, i64 %623
  %private.contiguous.load376 = load <8 x float>, ptr %private.contiguous.address375, align 4
  %624 = select <8 x i1> %71, <8 x float> %private.contiguous.load376, <8 x float> zeroinitializer
  %.state377 = load i64, ptr %.slot64, align 4
  %625 = add i64 720, %.state377
  %tile_snapshot.spill.load378 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %626 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load378, 0
  %627 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load378, 1
  %.splatinsert379 = insertelement <8 x i64> poison, i64 %625, i64 0
  %.splat380 = shufflevector <8 x i64> %.splatinsert379, <8 x i64> poison, <8 x i32> zeroinitializer
  %628 = mul <8 x i64> %.splat380, splat (i64 32)
  %629 = add <8 x i64> %627, %628
  %630 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %626, 0
  %631 = insertvalue { <8 x ptr>, <8 x i64> } %630, <8 x i64> %629, 1
  %632 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %633 = extractvalue { <8 x ptr>, <8 x i64> } %631, 1
  %634 = extractelement <8 x ptr> %632, i32 0
  %635 = extractelement <8 x i64> %633, i32 0
  %636 = sub i64 %635, 0
  %637 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %638 = select i1 %637, i64 %636, i64 0
  %private.contiguous.address381 = getelementptr i8, ptr %634, i64 %638
  %private.contiguous.load382 = load <8 x float>, ptr %private.contiguous.address381, align 4
  %639 = select <8 x i1> %71, <8 x float> %private.contiguous.load382, <8 x float> zeroinitializer
  %640 = fmul <8 x float> %624, %639
  %.state383 = load <8 x float>, ptr %.slot65, align 32
  %641 = fadd <8 x float> %.state383, %640
  %.state384 = load i64, ptr %.slot64, align 4
  %642 = add i64 %.state384, 1
  store i64 %642, ptr %.slot64, align 4
  %643 = load <8 x float>, ptr %.slot65, align 32
  %644 = select <8 x i1> %71, <8 x float> %641, <8 x float> %643
  store <8 x float> %644, ptr %.slot65, align 32
  br label %direct.schedule.46

direct.schedule.48:                               ; preds = %direct.false370
  store i64 0, ptr %.slot66, align 4
  %645 = load <8 x float>, ptr %.slot67, align 32
  %646 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %645
  store <8 x float> %646, ptr %.slot67, align 32
  br label %direct.schedule.49

direct.schedule.49:                               ; preds = %direct.schedule.50, %direct.schedule.48
  %.state385 = load i64, ptr %.slot66, align 4
  %647 = icmp slt i64 %.state385, 80
  br i1 %647, label %direct.true386, label %direct.false387

direct.schedule.50:                               ; preds = %direct.true386
  %.state388 = load i64, ptr %.slot66, align 4
  %648 = add i64 0, %.state388
  %tile_snapshot.spill.load389 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %649 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load389, 0
  %650 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load389, 1
  %.splatinsert390 = insertelement <8 x i64> poison, i64 %648, i64 0
  %.splat391 = shufflevector <8 x i64> %.splatinsert390, <8 x i64> poison, <8 x i32> zeroinitializer
  %651 = mul <8 x i64> %.splat391, splat (i64 32)
  %652 = add <8 x i64> %650, %651
  %653 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %649, 0
  %654 = insertvalue { <8 x ptr>, <8 x i64> } %653, <8 x i64> %652, 1
  %655 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %656 = extractvalue { <8 x ptr>, <8 x i64> } %654, 1
  %657 = extractelement <8 x ptr> %655, i32 0
  %658 = extractelement <8 x i64> %656, i32 0
  %659 = sub i64 %658, 0
  %660 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %661 = select i1 %660, i64 %659, i64 0
  %private.contiguous.address392 = getelementptr i8, ptr %657, i64 %661
  %private.contiguous.load393 = load <8 x float>, ptr %private.contiguous.address392, align 4
  %662 = select <8 x i1> %71, <8 x float> %private.contiguous.load393, <8 x float> zeroinitializer
  %.state394 = load i64, ptr %.slot66, align 4
  %663 = add i64 800, %.state394
  %tile_snapshot.spill.load395 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %664 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load395, 0
  %665 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load395, 1
  %.splatinsert396 = insertelement <8 x i64> poison, i64 %663, i64 0
  %.splat397 = shufflevector <8 x i64> %.splatinsert396, <8 x i64> poison, <8 x i32> zeroinitializer
  %666 = mul <8 x i64> %.splat397, splat (i64 32)
  %667 = add <8 x i64> %665, %666
  %668 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %664, 0
  %669 = insertvalue { <8 x ptr>, <8 x i64> } %668, <8 x i64> %667, 1
  %670 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %671 = extractvalue { <8 x ptr>, <8 x i64> } %669, 1
  %672 = extractelement <8 x ptr> %670, i32 0
  %673 = extractelement <8 x i64> %671, i32 0
  %674 = sub i64 %673, 0
  %675 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %676 = select i1 %675, i64 %674, i64 0
  %private.contiguous.address398 = getelementptr i8, ptr %672, i64 %676
  %private.contiguous.load399 = load <8 x float>, ptr %private.contiguous.address398, align 4
  %677 = select <8 x i1> %71, <8 x float> %private.contiguous.load399, <8 x float> zeroinitializer
  %678 = fmul <8 x float> %662, %677
  %.state400 = load <8 x float>, ptr %.slot67, align 32
  %679 = fadd <8 x float> %.state400, %678
  %.state401 = load i64, ptr %.slot66, align 4
  %680 = add i64 %.state401, 1
  store i64 %680, ptr %.slot66, align 4
  %681 = load <8 x float>, ptr %.slot67, align 32
  %682 = select <8 x i1> %71, <8 x float> %679, <8 x float> %681
  store <8 x float> %682, ptr %.slot67, align 32
  br label %direct.schedule.49

direct.schedule.51:                               ; preds = %direct.false387
  store i64 0, ptr %.slot68, align 4
  %683 = load <8 x float>, ptr %.slot69, align 32
  %684 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %683
  store <8 x float> %684, ptr %.slot69, align 32
  br label %direct.schedule.52

direct.schedule.52:                               ; preds = %direct.schedule.53, %direct.schedule.51
  %.state402 = load i64, ptr %.slot68, align 4
  %685 = icmp slt i64 %.state402, 80
  br i1 %685, label %direct.true403, label %direct.false404

direct.schedule.53:                               ; preds = %direct.true403
  %.state405 = load i64, ptr %.slot68, align 4
  %686 = add i64 0, %.state405
  %tile_snapshot.spill.load406 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %687 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load406, 0
  %688 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load406, 1
  %.splatinsert407 = insertelement <8 x i64> poison, i64 %686, i64 0
  %.splat408 = shufflevector <8 x i64> %.splatinsert407, <8 x i64> poison, <8 x i32> zeroinitializer
  %689 = mul <8 x i64> %.splat408, splat (i64 32)
  %690 = add <8 x i64> %688, %689
  %691 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %687, 0
  %692 = insertvalue { <8 x ptr>, <8 x i64> } %691, <8 x i64> %690, 1
  %693 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %694 = extractvalue { <8 x ptr>, <8 x i64> } %692, 1
  %695 = extractelement <8 x ptr> %693, i32 0
  %696 = extractelement <8 x i64> %694, i32 0
  %697 = sub i64 %696, 0
  %698 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %699 = select i1 %698, i64 %697, i64 0
  %private.contiguous.address409 = getelementptr i8, ptr %695, i64 %699
  %private.contiguous.load410 = load <8 x float>, ptr %private.contiguous.address409, align 4
  %700 = select <8 x i1> %71, <8 x float> %private.contiguous.load410, <8 x float> zeroinitializer
  %.state411 = load i64, ptr %.slot68, align 4
  %701 = add i64 880, %.state411
  %tile_snapshot.spill.load412 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %702 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 0
  %703 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 1
  %.splatinsert413 = insertelement <8 x i64> poison, i64 %701, i64 0
  %.splat414 = shufflevector <8 x i64> %.splatinsert413, <8 x i64> poison, <8 x i32> zeroinitializer
  %704 = mul <8 x i64> %.splat414, splat (i64 32)
  %705 = add <8 x i64> %703, %704
  %706 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %702, 0
  %707 = insertvalue { <8 x ptr>, <8 x i64> } %706, <8 x i64> %705, 1
  %708 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %709 = extractvalue { <8 x ptr>, <8 x i64> } %707, 1
  %710 = extractelement <8 x ptr> %708, i32 0
  %711 = extractelement <8 x i64> %709, i32 0
  %712 = sub i64 %711, 0
  %713 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %714 = select i1 %713, i64 %712, i64 0
  %private.contiguous.address415 = getelementptr i8, ptr %710, i64 %714
  %private.contiguous.load416 = load <8 x float>, ptr %private.contiguous.address415, align 4
  %715 = select <8 x i1> %71, <8 x float> %private.contiguous.load416, <8 x float> zeroinitializer
  %716 = fmul <8 x float> %700, %715
  %.state417 = load <8 x float>, ptr %.slot69, align 32
  %717 = fadd <8 x float> %.state417, %716
  %.state418 = load i64, ptr %.slot68, align 4
  %718 = add i64 %.state418, 1
  store i64 %718, ptr %.slot68, align 4
  %719 = load <8 x float>, ptr %.slot69, align 32
  %720 = select <8 x i1> %71, <8 x float> %717, <8 x float> %719
  store <8 x float> %720, ptr %.slot69, align 32
  br label %direct.schedule.52

direct.schedule.54:                               ; preds = %direct.false404
  store i64 0, ptr %.slot70, align 4
  %721 = load <8 x float>, ptr %.slot71, align 32
  %722 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %721
  store <8 x float> %722, ptr %.slot71, align 32
  br label %direct.schedule.55

direct.schedule.55:                               ; preds = %direct.schedule.56, %direct.schedule.54
  %.state419 = load i64, ptr %.slot70, align 4
  %723 = icmp slt i64 %.state419, 80
  br i1 %723, label %direct.true420, label %direct.false421

direct.schedule.56:                               ; preds = %direct.true420
  %.state422 = load i64, ptr %.slot70, align 4
  %724 = add i64 0, %.state422
  %tile_snapshot.spill.load423 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %725 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load423, 0
  %726 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load423, 1
  %.splatinsert424 = insertelement <8 x i64> poison, i64 %724, i64 0
  %.splat425 = shufflevector <8 x i64> %.splatinsert424, <8 x i64> poison, <8 x i32> zeroinitializer
  %727 = mul <8 x i64> %.splat425, splat (i64 32)
  %728 = add <8 x i64> %726, %727
  %729 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %725, 0
  %730 = insertvalue { <8 x ptr>, <8 x i64> } %729, <8 x i64> %728, 1
  %731 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %732 = extractvalue { <8 x ptr>, <8 x i64> } %730, 1
  %733 = extractelement <8 x ptr> %731, i32 0
  %734 = extractelement <8 x i64> %732, i32 0
  %735 = sub i64 %734, 0
  %736 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %737 = select i1 %736, i64 %735, i64 0
  %private.contiguous.address426 = getelementptr i8, ptr %733, i64 %737
  %private.contiguous.load427 = load <8 x float>, ptr %private.contiguous.address426, align 4
  %738 = select <8 x i1> %71, <8 x float> %private.contiguous.load427, <8 x float> zeroinitializer
  %.state428 = load i64, ptr %.slot70, align 4
  %739 = add i64 960, %.state428
  %tile_snapshot.spill.load429 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %740 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load429, 0
  %741 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load429, 1
  %.splatinsert430 = insertelement <8 x i64> poison, i64 %739, i64 0
  %.splat431 = shufflevector <8 x i64> %.splatinsert430, <8 x i64> poison, <8 x i32> zeroinitializer
  %742 = mul <8 x i64> %.splat431, splat (i64 32)
  %743 = add <8 x i64> %741, %742
  %744 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %740, 0
  %745 = insertvalue { <8 x ptr>, <8 x i64> } %744, <8 x i64> %743, 1
  %746 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %747 = extractvalue { <8 x ptr>, <8 x i64> } %745, 1
  %748 = extractelement <8 x ptr> %746, i32 0
  %749 = extractelement <8 x i64> %747, i32 0
  %750 = sub i64 %749, 0
  %751 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %752 = select i1 %751, i64 %750, i64 0
  %private.contiguous.address432 = getelementptr i8, ptr %748, i64 %752
  %private.contiguous.load433 = load <8 x float>, ptr %private.contiguous.address432, align 4
  %753 = select <8 x i1> %71, <8 x float> %private.contiguous.load433, <8 x float> zeroinitializer
  %754 = fmul <8 x float> %738, %753
  %.state434 = load <8 x float>, ptr %.slot71, align 32
  %755 = fadd <8 x float> %.state434, %754
  %.state435 = load i64, ptr %.slot70, align 4
  %756 = add i64 %.state435, 1
  store i64 %756, ptr %.slot70, align 4
  %757 = load <8 x float>, ptr %.slot71, align 32
  %758 = select <8 x i1> %71, <8 x float> %755, <8 x float> %757
  store <8 x float> %758, ptr %.slot71, align 32
  br label %direct.schedule.55

direct.schedule.57:                               ; preds = %direct.false421
  store i64 0, ptr %.slot72, align 4
  %759 = load <8 x float>, ptr %.slot73, align 32
  %760 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %759
  store <8 x float> %760, ptr %.slot73, align 32
  br label %direct.schedule.58

direct.schedule.58:                               ; preds = %direct.schedule.59, %direct.schedule.57
  %.state436 = load i64, ptr %.slot72, align 4
  %761 = icmp slt i64 %.state436, 80
  br i1 %761, label %direct.true437, label %direct.false438

direct.schedule.59:                               ; preds = %direct.true437
  %.state439 = load i64, ptr %.slot72, align 4
  %762 = add i64 0, %.state439
  %tile_snapshot.spill.load440 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %763 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load440, 0
  %764 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load440, 1
  %.splatinsert441 = insertelement <8 x i64> poison, i64 %762, i64 0
  %.splat442 = shufflevector <8 x i64> %.splatinsert441, <8 x i64> poison, <8 x i32> zeroinitializer
  %765 = mul <8 x i64> %.splat442, splat (i64 32)
  %766 = add <8 x i64> %764, %765
  %767 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %763, 0
  %768 = insertvalue { <8 x ptr>, <8 x i64> } %767, <8 x i64> %766, 1
  %769 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %770 = extractvalue { <8 x ptr>, <8 x i64> } %768, 1
  %771 = extractelement <8 x ptr> %769, i32 0
  %772 = extractelement <8 x i64> %770, i32 0
  %773 = sub i64 %772, 0
  %774 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %775 = select i1 %774, i64 %773, i64 0
  %private.contiguous.address443 = getelementptr i8, ptr %771, i64 %775
  %private.contiguous.load444 = load <8 x float>, ptr %private.contiguous.address443, align 4
  %776 = select <8 x i1> %71, <8 x float> %private.contiguous.load444, <8 x float> zeroinitializer
  %.state445 = load i64, ptr %.slot72, align 4
  %777 = add i64 1040, %.state445
  %tile_snapshot.spill.load446 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %778 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load446, 0
  %779 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load446, 1
  %.splatinsert447 = insertelement <8 x i64> poison, i64 %777, i64 0
  %.splat448 = shufflevector <8 x i64> %.splatinsert447, <8 x i64> poison, <8 x i32> zeroinitializer
  %780 = mul <8 x i64> %.splat448, splat (i64 32)
  %781 = add <8 x i64> %779, %780
  %782 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %778, 0
  %783 = insertvalue { <8 x ptr>, <8 x i64> } %782, <8 x i64> %781, 1
  %784 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %785 = extractvalue { <8 x ptr>, <8 x i64> } %783, 1
  %786 = extractelement <8 x ptr> %784, i32 0
  %787 = extractelement <8 x i64> %785, i32 0
  %788 = sub i64 %787, 0
  %789 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %790 = select i1 %789, i64 %788, i64 0
  %private.contiguous.address449 = getelementptr i8, ptr %786, i64 %790
  %private.contiguous.load450 = load <8 x float>, ptr %private.contiguous.address449, align 4
  %791 = select <8 x i1> %71, <8 x float> %private.contiguous.load450, <8 x float> zeroinitializer
  %792 = fmul <8 x float> %776, %791
  %.state451 = load <8 x float>, ptr %.slot73, align 32
  %793 = fadd <8 x float> %.state451, %792
  %.state452 = load i64, ptr %.slot72, align 4
  %794 = add i64 %.state452, 1
  store i64 %794, ptr %.slot72, align 4
  %795 = load <8 x float>, ptr %.slot73, align 32
  %796 = select <8 x i1> %71, <8 x float> %793, <8 x float> %795
  store <8 x float> %796, ptr %.slot73, align 32
  br label %direct.schedule.58

direct.schedule.60:                               ; preds = %direct.false438
  store i64 0, ptr %.slot74, align 4
  %797 = load <8 x float>, ptr %.slot75, align 32
  %798 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %797
  store <8 x float> %798, ptr %.slot75, align 32
  br label %direct.schedule.61

direct.schedule.61:                               ; preds = %direct.schedule.62, %direct.schedule.60
  %.state453 = load i64, ptr %.slot74, align 4
  %799 = icmp slt i64 %.state453, 80
  br i1 %799, label %direct.true454, label %direct.false455

direct.schedule.62:                               ; preds = %direct.true454
  %.state456 = load i64, ptr %.slot74, align 4
  %800 = add i64 0, %.state456
  %tile_snapshot.spill.load457 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %801 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load457, 0
  %802 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load457, 1
  %.splatinsert458 = insertelement <8 x i64> poison, i64 %800, i64 0
  %.splat459 = shufflevector <8 x i64> %.splatinsert458, <8 x i64> poison, <8 x i32> zeroinitializer
  %803 = mul <8 x i64> %.splat459, splat (i64 32)
  %804 = add <8 x i64> %802, %803
  %805 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %801, 0
  %806 = insertvalue { <8 x ptr>, <8 x i64> } %805, <8 x i64> %804, 1
  %807 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %808 = extractvalue { <8 x ptr>, <8 x i64> } %806, 1
  %809 = extractelement <8 x ptr> %807, i32 0
  %810 = extractelement <8 x i64> %808, i32 0
  %811 = sub i64 %810, 0
  %812 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %813 = select i1 %812, i64 %811, i64 0
  %private.contiguous.address460 = getelementptr i8, ptr %809, i64 %813
  %private.contiguous.load461 = load <8 x float>, ptr %private.contiguous.address460, align 4
  %814 = select <8 x i1> %71, <8 x float> %private.contiguous.load461, <8 x float> zeroinitializer
  %.state462 = load i64, ptr %.slot74, align 4
  %815 = add i64 1120, %.state462
  %tile_snapshot.spill.load463 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %816 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load463, 0
  %817 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load463, 1
  %.splatinsert464 = insertelement <8 x i64> poison, i64 %815, i64 0
  %.splat465 = shufflevector <8 x i64> %.splatinsert464, <8 x i64> poison, <8 x i32> zeroinitializer
  %818 = mul <8 x i64> %.splat465, splat (i64 32)
  %819 = add <8 x i64> %817, %818
  %820 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %816, 0
  %821 = insertvalue { <8 x ptr>, <8 x i64> } %820, <8 x i64> %819, 1
  %822 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %823 = extractvalue { <8 x ptr>, <8 x i64> } %821, 1
  %824 = extractelement <8 x ptr> %822, i32 0
  %825 = extractelement <8 x i64> %823, i32 0
  %826 = sub i64 %825, 0
  %827 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %828 = select i1 %827, i64 %826, i64 0
  %private.contiguous.address466 = getelementptr i8, ptr %824, i64 %828
  %private.contiguous.load467 = load <8 x float>, ptr %private.contiguous.address466, align 4
  %829 = select <8 x i1> %71, <8 x float> %private.contiguous.load467, <8 x float> zeroinitializer
  %830 = fmul <8 x float> %814, %829
  %.state468 = load <8 x float>, ptr %.slot75, align 32
  %831 = fadd <8 x float> %.state468, %830
  %.state469 = load i64, ptr %.slot74, align 4
  %832 = add i64 %.state469, 1
  store i64 %832, ptr %.slot74, align 4
  %833 = load <8 x float>, ptr %.slot75, align 32
  %834 = select <8 x i1> %71, <8 x float> %831, <8 x float> %833
  store <8 x float> %834, ptr %.slot75, align 32
  br label %direct.schedule.61

direct.schedule.63:                               ; preds = %direct.false455
  store i64 0, ptr %.slot76, align 4
  %835 = load <8 x float>, ptr %.slot77, align 32
  %836 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %835
  store <8 x float> %836, ptr %.slot77, align 32
  br label %direct.schedule.64

direct.schedule.64:                               ; preds = %direct.schedule.65, %direct.schedule.63
  %.state470 = load i64, ptr %.slot76, align 4
  %837 = icmp slt i64 %.state470, 80
  br i1 %837, label %direct.true471, label %direct.false472

direct.schedule.65:                               ; preds = %direct.true471
  %.state473 = load i64, ptr %.slot76, align 4
  %838 = add i64 0, %.state473
  %tile_snapshot.spill.load474 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %839 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load474, 0
  %840 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load474, 1
  %.splatinsert475 = insertelement <8 x i64> poison, i64 %838, i64 0
  %.splat476 = shufflevector <8 x i64> %.splatinsert475, <8 x i64> poison, <8 x i32> zeroinitializer
  %841 = mul <8 x i64> %.splat476, splat (i64 32)
  %842 = add <8 x i64> %840, %841
  %843 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %839, 0
  %844 = insertvalue { <8 x ptr>, <8 x i64> } %843, <8 x i64> %842, 1
  %845 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %846 = extractvalue { <8 x ptr>, <8 x i64> } %844, 1
  %847 = extractelement <8 x ptr> %845, i32 0
  %848 = extractelement <8 x i64> %846, i32 0
  %849 = sub i64 %848, 0
  %850 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %851 = select i1 %850, i64 %849, i64 0
  %private.contiguous.address477 = getelementptr i8, ptr %847, i64 %851
  %private.contiguous.load478 = load <8 x float>, ptr %private.contiguous.address477, align 4
  %852 = select <8 x i1> %71, <8 x float> %private.contiguous.load478, <8 x float> zeroinitializer
  %.state479 = load i64, ptr %.slot76, align 4
  %853 = add i64 1200, %.state479
  %tile_snapshot.spill.load480 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %854 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load480, 0
  %855 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load480, 1
  %.splatinsert481 = insertelement <8 x i64> poison, i64 %853, i64 0
  %.splat482 = shufflevector <8 x i64> %.splatinsert481, <8 x i64> poison, <8 x i32> zeroinitializer
  %856 = mul <8 x i64> %.splat482, splat (i64 32)
  %857 = add <8 x i64> %855, %856
  %858 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %854, 0
  %859 = insertvalue { <8 x ptr>, <8 x i64> } %858, <8 x i64> %857, 1
  %860 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %861 = extractvalue { <8 x ptr>, <8 x i64> } %859, 1
  %862 = extractelement <8 x ptr> %860, i32 0
  %863 = extractelement <8 x i64> %861, i32 0
  %864 = sub i64 %863, 0
  %865 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %866 = select i1 %865, i64 %864, i64 0
  %private.contiguous.address483 = getelementptr i8, ptr %862, i64 %866
  %private.contiguous.load484 = load <8 x float>, ptr %private.contiguous.address483, align 4
  %867 = select <8 x i1> %71, <8 x float> %private.contiguous.load484, <8 x float> zeroinitializer
  %868 = fmul <8 x float> %852, %867
  %.state485 = load <8 x float>, ptr %.slot77, align 32
  %869 = fadd <8 x float> %.state485, %868
  %.state486 = load i64, ptr %.slot76, align 4
  %870 = add i64 %.state486, 1
  store i64 %870, ptr %.slot76, align 4
  %871 = load <8 x float>, ptr %.slot77, align 32
  %872 = select <8 x i1> %71, <8 x float> %869, <8 x float> %871
  store <8 x float> %872, ptr %.slot77, align 32
  br label %direct.schedule.64

direct.schedule.66:                               ; preds = %direct.false472
  %.state487 = load <8 x float>, ptr %.slot47, align 32
  %873 = fmul <8 x float> %.state487, splat (float 0x3FBC9F25C0000000)
  %.state488 = load <8 x float>, ptr %.slot49, align 32
  %874 = fmul <8 x float> %.state488, splat (float 0x3FBC9F25C0000000)
  %.state489 = load <8 x float>, ptr %.slot51, align 32
  %875 = fmul <8 x float> %.state489, splat (float 0x3FBC9F25C0000000)
  %.state490 = load <8 x float>, ptr %.slot53, align 32
  %876 = fmul <8 x float> %.state490, splat (float 0x3FBC9F25C0000000)
  %.state491 = load <8 x float>, ptr %.slot55, align 32
  %877 = fmul <8 x float> %.state491, splat (float 0x3FBC9F25C0000000)
  %.state492 = load <8 x float>, ptr %.slot57, align 32
  %878 = fmul <8 x float> %.state492, splat (float 0x3FBC9F25C0000000)
  %.state493 = load <8 x float>, ptr %.slot59, align 32
  %879 = fmul <8 x float> %.state493, splat (float 0x3FBC9F25C0000000)
  %.state494 = load <8 x float>, ptr %.slot61, align 32
  %880 = fmul <8 x float> %.state494, splat (float 0x3FBC9F25C0000000)
  %.state495 = load <8 x float>, ptr %.slot63, align 32
  %881 = fmul <8 x float> %.state495, splat (float 0x3FBC9F25C0000000)
  %.state496 = load <8 x float>, ptr %.slot65, align 32
  %882 = fmul <8 x float> %.state496, splat (float 0x3FBC9F25C0000000)
  %.state497 = load <8 x float>, ptr %.slot67, align 32
  %883 = fmul <8 x float> %.state497, splat (float 0x3FBC9F25C0000000)
  %.state498 = load <8 x float>, ptr %.slot69, align 32
  %884 = fmul <8 x float> %.state498, splat (float 0x3FBC9F25C0000000)
  %.state499 = load <8 x float>, ptr %.slot71, align 32
  %885 = fmul <8 x float> %.state499, splat (float 0x3FBC9F25C0000000)
  %.state500 = load <8 x float>, ptr %.slot73, align 32
  %886 = fmul <8 x float> %.state500, splat (float 0x3FBC9F25C0000000)
  %.state501 = load <8 x float>, ptr %.slot75, align 32
  %887 = fmul <8 x float> %.state501, splat (float 0x3FBC9F25C0000000)
  %.state502 = load <8 x float>, ptr %.slot77, align 32
  %888 = fmul <8 x float> %.state502, splat (float 0x3FBC9F25C0000000)
  %.spill.load503 = load i64, ptr %.spill37, align 4
  %889 = add i64 0, %.spill.load503
  %.spill.load504 = load i64, ptr %.spill37, align 4
  %890 = add i64 1, %.spill.load504
  %.spill.load505 = load i64, ptr %.spill37, align 4
  %891 = add i64 2, %.spill.load505
  %.spill.load506 = load i64, ptr %.spill37, align 4
  %892 = add i64 3, %.spill.load506
  %.spill.load507 = load i64, ptr %.spill37, align 4
  %893 = add i64 4, %.spill.load507
  %.spill.load508 = load i64, ptr %.spill37, align 4
  %894 = add i64 5, %.spill.load508
  %.spill.load509 = load i64, ptr %.spill37, align 4
  %895 = add i64 6, %.spill.load509
  %.spill.load510 = load i64, ptr %.spill37, align 4
  %896 = add i64 7, %.spill.load510
  %.spill.load511 = load i64, ptr %.spill37, align 4
  %897 = add i64 8, %.spill.load511
  %.spill.load512 = load i64, ptr %.spill37, align 4
  %898 = add i64 9, %.spill.load512
  %.spill.load513 = load i64, ptr %.spill37, align 4
  %899 = add i64 10, %.spill.load513
  %.spill.load514 = load i64, ptr %.spill37, align 4
  %900 = add i64 11, %.spill.load514
  %.spill.load515 = load i64, ptr %.spill37, align 4
  %901 = add i64 12, %.spill.load515
  %.spill.load516 = load i64, ptr %.spill37, align 4
  %902 = add i64 13, %.spill.load516
  %.spill.load517 = load i64, ptr %.spill37, align 4
  %903 = add i64 14, %.spill.load517
  %.spill.load518 = load i64, ptr %.spill37, align 4
  %904 = add i64 15, %.spill.load518
  %905 = icmp slt i64 %889, 67
  %906 = icmp slt i64 %890, 67
  %907 = icmp slt i64 %891, 67
  %908 = icmp slt i64 %892, 67
  %909 = icmp slt i64 %893, 67
  %910 = icmp slt i64 %894, 67
  %911 = icmp slt i64 %895, 67
  %912 = icmp slt i64 %896, 67
  %913 = icmp slt i64 %897, 67
  %914 = icmp slt i64 %898, 67
  %915 = icmp slt i64 %899, 67
  %916 = icmp slt i64 %900, 67
  %917 = icmp slt i64 %901, 67
  %918 = icmp slt i64 %902, 67
  %919 = icmp slt i64 %903, 67
  %920 = icmp slt i64 %904, 67
  %.spill.load519 = load <8 x i64>, ptr %.spill29, align 64
  %921 = add <8 x i64> zeroinitializer, %.spill.load519
  %922 = add <8 x i64> %921, splat (i64 67)
  %923 = sub <8 x i64> %922, splat (i64 3)
  %.splatinsert520 = insertelement <8 x i64> poison, i64 %889, i64 0
  %.splat521 = shufflevector <8 x i64> %.splatinsert520, <8 x i64> poison, <8 x i32> zeroinitializer
  %924 = icmp sle <8 x i64> %.splat521, %923
  %.splatinsert522 = insertelement <8 x i64> poison, i64 %890, i64 0
  %.splat523 = shufflevector <8 x i64> %.splatinsert522, <8 x i64> poison, <8 x i32> zeroinitializer
  %925 = icmp sle <8 x i64> %.splat523, %923
  %.splatinsert524 = insertelement <8 x i64> poison, i64 %891, i64 0
  %.splat525 = shufflevector <8 x i64> %.splatinsert524, <8 x i64> poison, <8 x i32> zeroinitializer
  %926 = icmp sle <8 x i64> %.splat525, %923
  %.splatinsert526 = insertelement <8 x i64> poison, i64 %892, i64 0
  %.splat527 = shufflevector <8 x i64> %.splatinsert526, <8 x i64> poison, <8 x i32> zeroinitializer
  %927 = icmp sle <8 x i64> %.splat527, %923
  %.splatinsert528 = insertelement <8 x i64> poison, i64 %893, i64 0
  %.splat529 = shufflevector <8 x i64> %.splatinsert528, <8 x i64> poison, <8 x i32> zeroinitializer
  %928 = icmp sle <8 x i64> %.splat529, %923
  %.splatinsert530 = insertelement <8 x i64> poison, i64 %894, i64 0
  %.splat531 = shufflevector <8 x i64> %.splatinsert530, <8 x i64> poison, <8 x i32> zeroinitializer
  %929 = icmp sle <8 x i64> %.splat531, %923
  %.splatinsert532 = insertelement <8 x i64> poison, i64 %895, i64 0
  %.splat533 = shufflevector <8 x i64> %.splatinsert532, <8 x i64> poison, <8 x i32> zeroinitializer
  %930 = icmp sle <8 x i64> %.splat533, %923
  %.splatinsert534 = insertelement <8 x i64> poison, i64 %896, i64 0
  %.splat535 = shufflevector <8 x i64> %.splatinsert534, <8 x i64> poison, <8 x i32> zeroinitializer
  %931 = icmp sle <8 x i64> %.splat535, %923
  %.splatinsert536 = insertelement <8 x i64> poison, i64 %897, i64 0
  %.splat537 = shufflevector <8 x i64> %.splatinsert536, <8 x i64> poison, <8 x i32> zeroinitializer
  %932 = icmp sle <8 x i64> %.splat537, %923
  %.splatinsert538 = insertelement <8 x i64> poison, i64 %898, i64 0
  %.splat539 = shufflevector <8 x i64> %.splatinsert538, <8 x i64> poison, <8 x i32> zeroinitializer
  %933 = icmp sle <8 x i64> %.splat539, %923
  %.splatinsert540 = insertelement <8 x i64> poison, i64 %899, i64 0
  %.splat541 = shufflevector <8 x i64> %.splatinsert540, <8 x i64> poison, <8 x i32> zeroinitializer
  %934 = icmp sle <8 x i64> %.splat541, %923
  %.splatinsert542 = insertelement <8 x i64> poison, i64 %900, i64 0
  %.splat543 = shufflevector <8 x i64> %.splatinsert542, <8 x i64> poison, <8 x i32> zeroinitializer
  %935 = icmp sle <8 x i64> %.splat543, %923
  %.splatinsert544 = insertelement <8 x i64> poison, i64 %901, i64 0
  %.splat545 = shufflevector <8 x i64> %.splatinsert544, <8 x i64> poison, <8 x i32> zeroinitializer
  %936 = icmp sle <8 x i64> %.splat545, %923
  %.splatinsert546 = insertelement <8 x i64> poison, i64 %902, i64 0
  %.splat547 = shufflevector <8 x i64> %.splatinsert546, <8 x i64> poison, <8 x i32> zeroinitializer
  %937 = icmp sle <8 x i64> %.splat547, %923
  %.splatinsert548 = insertelement <8 x i64> poison, i64 %903, i64 0
  %.splat549 = shufflevector <8 x i64> %.splatinsert548, <8 x i64> poison, <8 x i32> zeroinitializer
  %938 = icmp sle <8 x i64> %.splat549, %923
  %.splatinsert550 = insertelement <8 x i64> poison, i64 %904, i64 0
  %.splat551 = shufflevector <8 x i64> %.splatinsert550, <8 x i64> poison, <8 x i32> zeroinitializer
  %939 = icmp sle <8 x i64> %.splat551, %923
  %.splatinsert552 = insertelement <8 x i1> poison, i1 %905, i64 0
  %.splat553 = shufflevector <8 x i1> %.splatinsert552, <8 x i1> poison, <8 x i32> zeroinitializer
  %940 = and <8 x i1> %.splat553, %924
  %941 = load <8 x i1>, ptr %.spill78, align 1
  %942 = select <8 x i1> %71, <8 x i1> %940, <8 x i1> %941
  store <8 x i1> %942, ptr %.spill78, align 1
  %.splatinsert554 = insertelement <8 x i1> poison, i1 %906, i64 0
  %.splat555 = shufflevector <8 x i1> %.splatinsert554, <8 x i1> poison, <8 x i32> zeroinitializer
  %943 = and <8 x i1> %.splat555, %925
  %944 = load <8 x i1>, ptr %.spill79, align 1
  %945 = select <8 x i1> %71, <8 x i1> %943, <8 x i1> %944
  store <8 x i1> %945, ptr %.spill79, align 1
  %.splatinsert556 = insertelement <8 x i1> poison, i1 %907, i64 0
  %.splat557 = shufflevector <8 x i1> %.splatinsert556, <8 x i1> poison, <8 x i32> zeroinitializer
  %946 = and <8 x i1> %.splat557, %926
  %947 = load <8 x i1>, ptr %.spill80, align 1
  %948 = select <8 x i1> %71, <8 x i1> %946, <8 x i1> %947
  store <8 x i1> %948, ptr %.spill80, align 1
  %.splatinsert558 = insertelement <8 x i1> poison, i1 %908, i64 0
  %.splat559 = shufflevector <8 x i1> %.splatinsert558, <8 x i1> poison, <8 x i32> zeroinitializer
  %949 = and <8 x i1> %.splat559, %927
  %950 = load <8 x i1>, ptr %.spill81, align 1
  %951 = select <8 x i1> %71, <8 x i1> %949, <8 x i1> %950
  store <8 x i1> %951, ptr %.spill81, align 1
  %.splatinsert560 = insertelement <8 x i1> poison, i1 %909, i64 0
  %.splat561 = shufflevector <8 x i1> %.splatinsert560, <8 x i1> poison, <8 x i32> zeroinitializer
  %952 = and <8 x i1> %.splat561, %928
  %953 = load <8 x i1>, ptr %.spill82, align 1
  %954 = select <8 x i1> %71, <8 x i1> %952, <8 x i1> %953
  store <8 x i1> %954, ptr %.spill82, align 1
  %.splatinsert562 = insertelement <8 x i1> poison, i1 %910, i64 0
  %.splat563 = shufflevector <8 x i1> %.splatinsert562, <8 x i1> poison, <8 x i32> zeroinitializer
  %955 = and <8 x i1> %.splat563, %929
  %956 = load <8 x i1>, ptr %.spill83, align 1
  %957 = select <8 x i1> %71, <8 x i1> %955, <8 x i1> %956
  store <8 x i1> %957, ptr %.spill83, align 1
  %.splatinsert564 = insertelement <8 x i1> poison, i1 %911, i64 0
  %.splat565 = shufflevector <8 x i1> %.splatinsert564, <8 x i1> poison, <8 x i32> zeroinitializer
  %958 = and <8 x i1> %.splat565, %930
  %959 = load <8 x i1>, ptr %.spill84, align 1
  %960 = select <8 x i1> %71, <8 x i1> %958, <8 x i1> %959
  store <8 x i1> %960, ptr %.spill84, align 1
  %.splatinsert566 = insertelement <8 x i1> poison, i1 %912, i64 0
  %.splat567 = shufflevector <8 x i1> %.splatinsert566, <8 x i1> poison, <8 x i32> zeroinitializer
  %961 = and <8 x i1> %.splat567, %931
  %962 = load <8 x i1>, ptr %.spill85, align 1
  %963 = select <8 x i1> %71, <8 x i1> %961, <8 x i1> %962
  store <8 x i1> %963, ptr %.spill85, align 1
  %.splatinsert568 = insertelement <8 x i1> poison, i1 %913, i64 0
  %.splat569 = shufflevector <8 x i1> %.splatinsert568, <8 x i1> poison, <8 x i32> zeroinitializer
  %964 = and <8 x i1> %.splat569, %932
  %965 = load <8 x i1>, ptr %.spill86, align 1
  %966 = select <8 x i1> %71, <8 x i1> %964, <8 x i1> %965
  store <8 x i1> %966, ptr %.spill86, align 1
  %.splatinsert570 = insertelement <8 x i1> poison, i1 %914, i64 0
  %.splat571 = shufflevector <8 x i1> %.splatinsert570, <8 x i1> poison, <8 x i32> zeroinitializer
  %967 = and <8 x i1> %.splat571, %933
  %968 = load <8 x i1>, ptr %.spill87, align 1
  %969 = select <8 x i1> %71, <8 x i1> %967, <8 x i1> %968
  store <8 x i1> %969, ptr %.spill87, align 1
  %.splatinsert572 = insertelement <8 x i1> poison, i1 %915, i64 0
  %.splat573 = shufflevector <8 x i1> %.splatinsert572, <8 x i1> poison, <8 x i32> zeroinitializer
  %970 = and <8 x i1> %.splat573, %934
  %971 = load <8 x i1>, ptr %.spill88, align 1
  %972 = select <8 x i1> %71, <8 x i1> %970, <8 x i1> %971
  store <8 x i1> %972, ptr %.spill88, align 1
  %.splatinsert574 = insertelement <8 x i1> poison, i1 %916, i64 0
  %.splat575 = shufflevector <8 x i1> %.splatinsert574, <8 x i1> poison, <8 x i32> zeroinitializer
  %973 = and <8 x i1> %.splat575, %935
  %974 = load <8 x i1>, ptr %.spill89, align 1
  %975 = select <8 x i1> %71, <8 x i1> %973, <8 x i1> %974
  store <8 x i1> %975, ptr %.spill89, align 1
  %.splatinsert576 = insertelement <8 x i1> poison, i1 %917, i64 0
  %.splat577 = shufflevector <8 x i1> %.splatinsert576, <8 x i1> poison, <8 x i32> zeroinitializer
  %976 = and <8 x i1> %.splat577, %936
  %977 = load <8 x i1>, ptr %.spill90, align 1
  %978 = select <8 x i1> %71, <8 x i1> %976, <8 x i1> %977
  store <8 x i1> %978, ptr %.spill90, align 1
  %.splatinsert578 = insertelement <8 x i1> poison, i1 %918, i64 0
  %.splat579 = shufflevector <8 x i1> %.splatinsert578, <8 x i1> poison, <8 x i32> zeroinitializer
  %979 = and <8 x i1> %.splat579, %937
  %980 = load <8 x i1>, ptr %.spill91, align 1
  %981 = select <8 x i1> %71, <8 x i1> %979, <8 x i1> %980
  store <8 x i1> %981, ptr %.spill91, align 1
  %.splatinsert580 = insertelement <8 x i1> poison, i1 %919, i64 0
  %.splat581 = shufflevector <8 x i1> %.splatinsert580, <8 x i1> poison, <8 x i32> zeroinitializer
  %982 = and <8 x i1> %.splat581, %938
  %983 = load <8 x i1>, ptr %.spill92, align 1
  %984 = select <8 x i1> %71, <8 x i1> %982, <8 x i1> %983
  store <8 x i1> %984, ptr %.spill92, align 1
  %.splatinsert582 = insertelement <8 x i1> poison, i1 %920, i64 0
  %.splat583 = shufflevector <8 x i1> %.splatinsert582, <8 x i1> poison, <8 x i32> zeroinitializer
  %985 = and <8 x i1> %.splat583, %939
  %986 = load <8 x i1>, ptr %.spill93, align 1
  %987 = select <8 x i1> %71, <8 x i1> %985, <8 x i1> %986
  store <8 x i1> %987, ptr %.spill93, align 1
  %988 = select <8 x i1> %940, <8 x float> %873, <8 x float> splat (float 0xC6293E5940000000)
  %989 = load <8 x float>, ptr %.spill94, align 32
  %990 = select <8 x i1> %71, <8 x float> %988, <8 x float> %989
  store <8 x float> %990, ptr %.spill94, align 32
  %991 = select <8 x i1> %943, <8 x float> %874, <8 x float> splat (float 0xC6293E5940000000)
  %992 = load <8 x float>, ptr %.spill95, align 32
  %993 = select <8 x i1> %71, <8 x float> %991, <8 x float> %992
  store <8 x float> %993, ptr %.spill95, align 32
  %994 = select <8 x i1> %946, <8 x float> %875, <8 x float> splat (float 0xC6293E5940000000)
  %995 = load <8 x float>, ptr %.spill96, align 32
  %996 = select <8 x i1> %71, <8 x float> %994, <8 x float> %995
  store <8 x float> %996, ptr %.spill96, align 32
  %997 = select <8 x i1> %949, <8 x float> %876, <8 x float> splat (float 0xC6293E5940000000)
  %998 = load <8 x float>, ptr %.spill97, align 32
  %999 = select <8 x i1> %71, <8 x float> %997, <8 x float> %998
  store <8 x float> %999, ptr %.spill97, align 32
  %1000 = select <8 x i1> %952, <8 x float> %877, <8 x float> splat (float 0xC6293E5940000000)
  %1001 = load <8 x float>, ptr %.spill98, align 32
  %1002 = select <8 x i1> %71, <8 x float> %1000, <8 x float> %1001
  store <8 x float> %1002, ptr %.spill98, align 32
  %1003 = select <8 x i1> %955, <8 x float> %878, <8 x float> splat (float 0xC6293E5940000000)
  %1004 = load <8 x float>, ptr %.spill99, align 32
  %1005 = select <8 x i1> %71, <8 x float> %1003, <8 x float> %1004
  store <8 x float> %1005, ptr %.spill99, align 32
  %1006 = select <8 x i1> %958, <8 x float> %879, <8 x float> splat (float 0xC6293E5940000000)
  %1007 = load <8 x float>, ptr %.spill100, align 32
  %1008 = select <8 x i1> %71, <8 x float> %1006, <8 x float> %1007
  store <8 x float> %1008, ptr %.spill100, align 32
  %1009 = select <8 x i1> %961, <8 x float> %880, <8 x float> splat (float 0xC6293E5940000000)
  %1010 = load <8 x float>, ptr %.spill101, align 32
  %1011 = select <8 x i1> %71, <8 x float> %1009, <8 x float> %1010
  store <8 x float> %1011, ptr %.spill101, align 32
  %1012 = select <8 x i1> %964, <8 x float> %881, <8 x float> splat (float 0xC6293E5940000000)
  %1013 = load <8 x float>, ptr %.spill102, align 32
  %1014 = select <8 x i1> %71, <8 x float> %1012, <8 x float> %1013
  store <8 x float> %1014, ptr %.spill102, align 32
  %1015 = select <8 x i1> %967, <8 x float> %882, <8 x float> splat (float 0xC6293E5940000000)
  %1016 = load <8 x float>, ptr %.spill103, align 32
  %1017 = select <8 x i1> %71, <8 x float> %1015, <8 x float> %1016
  store <8 x float> %1017, ptr %.spill103, align 32
  %1018 = select <8 x i1> %970, <8 x float> %883, <8 x float> splat (float 0xC6293E5940000000)
  %1019 = load <8 x float>, ptr %.spill104, align 32
  %1020 = select <8 x i1> %71, <8 x float> %1018, <8 x float> %1019
  store <8 x float> %1020, ptr %.spill104, align 32
  %1021 = select <8 x i1> %973, <8 x float> %884, <8 x float> splat (float 0xC6293E5940000000)
  %1022 = load <8 x float>, ptr %.spill105, align 32
  %1023 = select <8 x i1> %71, <8 x float> %1021, <8 x float> %1022
  store <8 x float> %1023, ptr %.spill105, align 32
  %1024 = select <8 x i1> %976, <8 x float> %885, <8 x float> splat (float 0xC6293E5940000000)
  %1025 = load <8 x float>, ptr %.spill106, align 32
  %1026 = select <8 x i1> %71, <8 x float> %1024, <8 x float> %1025
  store <8 x float> %1026, ptr %.spill106, align 32
  %1027 = select <8 x i1> %979, <8 x float> %886, <8 x float> splat (float 0xC6293E5940000000)
  %1028 = load <8 x float>, ptr %.spill107, align 32
  %1029 = select <8 x i1> %71, <8 x float> %1027, <8 x float> %1028
  store <8 x float> %1029, ptr %.spill107, align 32
  %1030 = select <8 x i1> %982, <8 x float> %887, <8 x float> splat (float 0xC6293E5940000000)
  %1031 = load <8 x float>, ptr %.spill108, align 32
  %1032 = select <8 x i1> %71, <8 x float> %1030, <8 x float> %1031
  store <8 x float> %1032, ptr %.spill108, align 32
  %1033 = select <8 x i1> %985, <8 x float> %888, <8 x float> splat (float 0xC6293E5940000000)
  %1034 = load <8 x float>, ptr %.spill109, align 32
  %1035 = select <8 x i1> %71, <8 x float> %1033, <8 x float> %1034
  store <8 x float> %1035, ptr %.spill109, align 32
  %1036 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill110, align 64
  %1037 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1038 = extractvalue { <8 x ptr>, <8 x i64> } %1036, 0
  %1039 = select <8 x i1> %71, <8 x ptr> %1037, <8 x ptr> %1038
  %1040 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1041 = extractvalue { <8 x ptr>, <8 x i64> } %1036, 1
  %1042 = select <8 x i1> %71, <8 x i64> %1040, <8 x i64> %1041
  %1043 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1039, 0
  %1044 = insertvalue { <8 x ptr>, <8 x i64> } %1043, <8 x i64> %1042, 1
  store { <8 x ptr>, <8 x i64> } %1044, ptr %tile_snapshot.spill110, align 64
  %1045 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1046 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1047 = add <8 x i64> %1046, zeroinitializer
  %1048 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1045, 0
  %1049 = insertvalue { <8 x ptr>, <8 x i64> } %1048, <8 x i64> %1047, 1
  %1050 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1051 = extractvalue { <8 x ptr>, <8 x i64> } %1049, 1
  %1052 = extractelement <8 x ptr> %1050, i32 0
  %1053 = extractelement <8 x i64> %1051, i32 0
  %1054 = sub i64 %1053, 0
  %1055 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1056 = select i1 %1055, i64 %1054, i64 0
  %private.contiguous.address584 = getelementptr i8, ptr %1052, i64 %1056
  %private.contiguous.preserve585 = load <8 x float>, ptr %private.contiguous.address584, align 4
  %1057 = select <8 x i1> %71, <8 x float> %988, <8 x float> %private.contiguous.preserve585
  store <8 x float> %1057, ptr %private.contiguous.address584, align 4
  %1058 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1059 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1060 = add <8 x i64> %1059, splat (i64 32)
  %1061 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1058, 0
  %1062 = insertvalue { <8 x ptr>, <8 x i64> } %1061, <8 x i64> %1060, 1
  %1063 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1064 = extractvalue { <8 x ptr>, <8 x i64> } %1062, 1
  %1065 = extractelement <8 x ptr> %1063, i32 0
  %1066 = extractelement <8 x i64> %1064, i32 0
  %1067 = sub i64 %1066, 0
  %1068 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1069 = select i1 %1068, i64 %1067, i64 0
  %private.contiguous.address586 = getelementptr i8, ptr %1065, i64 %1069
  %private.contiguous.preserve587 = load <8 x float>, ptr %private.contiguous.address586, align 4
  %1070 = select <8 x i1> %71, <8 x float> %991, <8 x float> %private.contiguous.preserve587
  store <8 x float> %1070, ptr %private.contiguous.address586, align 4
  %1071 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1072 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1073 = add <8 x i64> %1072, splat (i64 64)
  %1074 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1071, 0
  %1075 = insertvalue { <8 x ptr>, <8 x i64> } %1074, <8 x i64> %1073, 1
  %1076 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1077 = extractvalue { <8 x ptr>, <8 x i64> } %1075, 1
  %1078 = extractelement <8 x ptr> %1076, i32 0
  %1079 = extractelement <8 x i64> %1077, i32 0
  %1080 = sub i64 %1079, 0
  %1081 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1082 = select i1 %1081, i64 %1080, i64 0
  %private.contiguous.address588 = getelementptr i8, ptr %1078, i64 %1082
  %private.contiguous.preserve589 = load <8 x float>, ptr %private.contiguous.address588, align 4
  %1083 = select <8 x i1> %71, <8 x float> %994, <8 x float> %private.contiguous.preserve589
  store <8 x float> %1083, ptr %private.contiguous.address588, align 4
  %1084 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1085 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1086 = add <8 x i64> %1085, splat (i64 96)
  %1087 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1084, 0
  %1088 = insertvalue { <8 x ptr>, <8 x i64> } %1087, <8 x i64> %1086, 1
  %1089 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1090 = extractvalue { <8 x ptr>, <8 x i64> } %1088, 1
  %1091 = extractelement <8 x ptr> %1089, i32 0
  %1092 = extractelement <8 x i64> %1090, i32 0
  %1093 = sub i64 %1092, 0
  %1094 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1095 = select i1 %1094, i64 %1093, i64 0
  %private.contiguous.address590 = getelementptr i8, ptr %1091, i64 %1095
  %private.contiguous.preserve591 = load <8 x float>, ptr %private.contiguous.address590, align 4
  %1096 = select <8 x i1> %71, <8 x float> %997, <8 x float> %private.contiguous.preserve591
  store <8 x float> %1096, ptr %private.contiguous.address590, align 4
  %1097 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1098 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1099 = add <8 x i64> %1098, splat (i64 128)
  %1100 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1097, 0
  %1101 = insertvalue { <8 x ptr>, <8 x i64> } %1100, <8 x i64> %1099, 1
  %1102 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1103 = extractvalue { <8 x ptr>, <8 x i64> } %1101, 1
  %1104 = extractelement <8 x ptr> %1102, i32 0
  %1105 = extractelement <8 x i64> %1103, i32 0
  %1106 = sub i64 %1105, 0
  %1107 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1108 = select i1 %1107, i64 %1106, i64 0
  %private.contiguous.address592 = getelementptr i8, ptr %1104, i64 %1108
  %private.contiguous.preserve593 = load <8 x float>, ptr %private.contiguous.address592, align 4
  %1109 = select <8 x i1> %71, <8 x float> %1000, <8 x float> %private.contiguous.preserve593
  store <8 x float> %1109, ptr %private.contiguous.address592, align 4
  %1110 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1111 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1112 = add <8 x i64> %1111, splat (i64 160)
  %1113 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1110, 0
  %1114 = insertvalue { <8 x ptr>, <8 x i64> } %1113, <8 x i64> %1112, 1
  %1115 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1116 = extractvalue { <8 x ptr>, <8 x i64> } %1114, 1
  %1117 = extractelement <8 x ptr> %1115, i32 0
  %1118 = extractelement <8 x i64> %1116, i32 0
  %1119 = sub i64 %1118, 0
  %1120 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1121 = select i1 %1120, i64 %1119, i64 0
  %private.contiguous.address594 = getelementptr i8, ptr %1117, i64 %1121
  %private.contiguous.preserve595 = load <8 x float>, ptr %private.contiguous.address594, align 4
  %1122 = select <8 x i1> %71, <8 x float> %1003, <8 x float> %private.contiguous.preserve595
  store <8 x float> %1122, ptr %private.contiguous.address594, align 4
  %1123 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1124 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1125 = add <8 x i64> %1124, splat (i64 192)
  %1126 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1123, 0
  %1127 = insertvalue { <8 x ptr>, <8 x i64> } %1126, <8 x i64> %1125, 1
  %1128 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1129 = extractvalue { <8 x ptr>, <8 x i64> } %1127, 1
  %1130 = extractelement <8 x ptr> %1128, i32 0
  %1131 = extractelement <8 x i64> %1129, i32 0
  %1132 = sub i64 %1131, 0
  %1133 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1134 = select i1 %1133, i64 %1132, i64 0
  %private.contiguous.address596 = getelementptr i8, ptr %1130, i64 %1134
  %private.contiguous.preserve597 = load <8 x float>, ptr %private.contiguous.address596, align 4
  %1135 = select <8 x i1> %71, <8 x float> %1006, <8 x float> %private.contiguous.preserve597
  store <8 x float> %1135, ptr %private.contiguous.address596, align 4
  %1136 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1137 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1138 = add <8 x i64> %1137, splat (i64 224)
  %1139 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1136, 0
  %1140 = insertvalue { <8 x ptr>, <8 x i64> } %1139, <8 x i64> %1138, 1
  %1141 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1142 = extractvalue { <8 x ptr>, <8 x i64> } %1140, 1
  %1143 = extractelement <8 x ptr> %1141, i32 0
  %1144 = extractelement <8 x i64> %1142, i32 0
  %1145 = sub i64 %1144, 0
  %1146 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1147 = select i1 %1146, i64 %1145, i64 0
  %private.contiguous.address598 = getelementptr i8, ptr %1143, i64 %1147
  %private.contiguous.preserve599 = load <8 x float>, ptr %private.contiguous.address598, align 4
  %1148 = select <8 x i1> %71, <8 x float> %1009, <8 x float> %private.contiguous.preserve599
  store <8 x float> %1148, ptr %private.contiguous.address598, align 4
  %1149 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1150 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1151 = add <8 x i64> %1150, splat (i64 256)
  %1152 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1149, 0
  %1153 = insertvalue { <8 x ptr>, <8 x i64> } %1152, <8 x i64> %1151, 1
  %1154 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1155 = extractvalue { <8 x ptr>, <8 x i64> } %1153, 1
  %1156 = extractelement <8 x ptr> %1154, i32 0
  %1157 = extractelement <8 x i64> %1155, i32 0
  %1158 = sub i64 %1157, 0
  %1159 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1160 = select i1 %1159, i64 %1158, i64 0
  %private.contiguous.address600 = getelementptr i8, ptr %1156, i64 %1160
  %private.contiguous.preserve601 = load <8 x float>, ptr %private.contiguous.address600, align 4
  %1161 = select <8 x i1> %71, <8 x float> %1012, <8 x float> %private.contiguous.preserve601
  store <8 x float> %1161, ptr %private.contiguous.address600, align 4
  %1162 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1163 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1164 = add <8 x i64> %1163, splat (i64 288)
  %1165 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1162, 0
  %1166 = insertvalue { <8 x ptr>, <8 x i64> } %1165, <8 x i64> %1164, 1
  %1167 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1168 = extractvalue { <8 x ptr>, <8 x i64> } %1166, 1
  %1169 = extractelement <8 x ptr> %1167, i32 0
  %1170 = extractelement <8 x i64> %1168, i32 0
  %1171 = sub i64 %1170, 0
  %1172 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1173 = select i1 %1172, i64 %1171, i64 0
  %private.contiguous.address602 = getelementptr i8, ptr %1169, i64 %1173
  %private.contiguous.preserve603 = load <8 x float>, ptr %private.contiguous.address602, align 4
  %1174 = select <8 x i1> %71, <8 x float> %1015, <8 x float> %private.contiguous.preserve603
  store <8 x float> %1174, ptr %private.contiguous.address602, align 4
  %1175 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1176 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1177 = add <8 x i64> %1176, splat (i64 320)
  %1178 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1175, 0
  %1179 = insertvalue { <8 x ptr>, <8 x i64> } %1178, <8 x i64> %1177, 1
  %1180 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1181 = extractvalue { <8 x ptr>, <8 x i64> } %1179, 1
  %1182 = extractelement <8 x ptr> %1180, i32 0
  %1183 = extractelement <8 x i64> %1181, i32 0
  %1184 = sub i64 %1183, 0
  %1185 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1186 = select i1 %1185, i64 %1184, i64 0
  %private.contiguous.address604 = getelementptr i8, ptr %1182, i64 %1186
  %private.contiguous.preserve605 = load <8 x float>, ptr %private.contiguous.address604, align 4
  %1187 = select <8 x i1> %71, <8 x float> %1018, <8 x float> %private.contiguous.preserve605
  store <8 x float> %1187, ptr %private.contiguous.address604, align 4
  %1188 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1189 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1190 = add <8 x i64> %1189, splat (i64 352)
  %1191 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1188, 0
  %1192 = insertvalue { <8 x ptr>, <8 x i64> } %1191, <8 x i64> %1190, 1
  %1193 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1194 = extractvalue { <8 x ptr>, <8 x i64> } %1192, 1
  %1195 = extractelement <8 x ptr> %1193, i32 0
  %1196 = extractelement <8 x i64> %1194, i32 0
  %1197 = sub i64 %1196, 0
  %1198 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1199 = select i1 %1198, i64 %1197, i64 0
  %private.contiguous.address606 = getelementptr i8, ptr %1195, i64 %1199
  %private.contiguous.preserve607 = load <8 x float>, ptr %private.contiguous.address606, align 4
  %1200 = select <8 x i1> %71, <8 x float> %1021, <8 x float> %private.contiguous.preserve607
  store <8 x float> %1200, ptr %private.contiguous.address606, align 4
  %1201 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1202 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1203 = add <8 x i64> %1202, splat (i64 384)
  %1204 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1201, 0
  %1205 = insertvalue { <8 x ptr>, <8 x i64> } %1204, <8 x i64> %1203, 1
  %1206 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1207 = extractvalue { <8 x ptr>, <8 x i64> } %1205, 1
  %1208 = extractelement <8 x ptr> %1206, i32 0
  %1209 = extractelement <8 x i64> %1207, i32 0
  %1210 = sub i64 %1209, 0
  %1211 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1212 = select i1 %1211, i64 %1210, i64 0
  %private.contiguous.address608 = getelementptr i8, ptr %1208, i64 %1212
  %private.contiguous.preserve609 = load <8 x float>, ptr %private.contiguous.address608, align 4
  %1213 = select <8 x i1> %71, <8 x float> %1024, <8 x float> %private.contiguous.preserve609
  store <8 x float> %1213, ptr %private.contiguous.address608, align 4
  %1214 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1215 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1216 = add <8 x i64> %1215, splat (i64 416)
  %1217 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1214, 0
  %1218 = insertvalue { <8 x ptr>, <8 x i64> } %1217, <8 x i64> %1216, 1
  %1219 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1220 = extractvalue { <8 x ptr>, <8 x i64> } %1218, 1
  %1221 = extractelement <8 x ptr> %1219, i32 0
  %1222 = extractelement <8 x i64> %1220, i32 0
  %1223 = sub i64 %1222, 0
  %1224 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1225 = select i1 %1224, i64 %1223, i64 0
  %private.contiguous.address610 = getelementptr i8, ptr %1221, i64 %1225
  %private.contiguous.preserve611 = load <8 x float>, ptr %private.contiguous.address610, align 4
  %1226 = select <8 x i1> %71, <8 x float> %1027, <8 x float> %private.contiguous.preserve611
  store <8 x float> %1226, ptr %private.contiguous.address610, align 4
  %1227 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1228 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1229 = add <8 x i64> %1228, splat (i64 448)
  %1230 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1227, 0
  %1231 = insertvalue { <8 x ptr>, <8 x i64> } %1230, <8 x i64> %1229, 1
  %1232 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1233 = extractvalue { <8 x ptr>, <8 x i64> } %1231, 1
  %1234 = extractelement <8 x ptr> %1232, i32 0
  %1235 = extractelement <8 x i64> %1233, i32 0
  %1236 = sub i64 %1235, 0
  %1237 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1238 = select i1 %1237, i64 %1236, i64 0
  %private.contiguous.address612 = getelementptr i8, ptr %1234, i64 %1238
  %private.contiguous.preserve613 = load <8 x float>, ptr %private.contiguous.address612, align 4
  %1239 = select <8 x i1> %71, <8 x float> %1030, <8 x float> %private.contiguous.preserve613
  store <8 x float> %1239, ptr %private.contiguous.address612, align 4
  %1240 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1241 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1242 = add <8 x i64> %1241, splat (i64 480)
  %1243 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1240, 0
  %1244 = insertvalue { <8 x ptr>, <8 x i64> } %1243, <8 x i64> %1242, 1
  %1245 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1246 = extractvalue { <8 x ptr>, <8 x i64> } %1244, 1
  %1247 = extractelement <8 x ptr> %1245, i32 0
  %1248 = extractelement <8 x i64> %1246, i32 0
  %1249 = sub i64 %1248, 0
  %1250 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1251 = select i1 %1250, i64 %1249, i64 0
  %private.contiguous.address614 = getelementptr i8, ptr %1247, i64 %1251
  %private.contiguous.preserve615 = load <8 x float>, ptr %private.contiguous.address614, align 4
  %1252 = select <8 x i1> %71, <8 x float> %1033, <8 x float> %private.contiguous.preserve615
  store <8 x float> %1252, ptr %private.contiguous.address614, align 4
  store i64 0, ptr %.slot111, align 4
  %1253 = load <8 x float>, ptr %.slot112, align 32
  %1254 = select <8 x i1> %71, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %1253
  store <8 x float> %1254, ptr %.slot112, align 32
  br label %direct.schedule.67

direct.schedule.67:                               ; preds = %direct.schedule.68, %direct.schedule.66
  %.state616 = load i64, ptr %.slot111, align 4
  %1255 = icmp slt i64 %.state616, 16
  br i1 %1255, label %direct.true617, label %direct.false618

direct.schedule.68:                               ; preds = %direct.true617
  %.state619 = load i64, ptr %.slot111, align 4
  %1256 = sdiv i64 %.state619, 1
  %1257 = add i64 0, %1256
  %tile_snapshot.spill.load620 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill110, align 64
  %1258 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load620, 0
  %1259 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load620, 1
  %.splatinsert621 = insertelement <8 x i64> poison, i64 %1257, i64 0
  %.splat622 = shufflevector <8 x i64> %.splatinsert621, <8 x i64> poison, <8 x i32> zeroinitializer
  %1260 = mul <8 x i64> %.splat622, splat (i64 32)
  %1261 = add <8 x i64> %1259, %1260
  %1262 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1258, 0
  %1263 = insertvalue { <8 x ptr>, <8 x i64> } %1262, <8 x i64> %1261, 1
  %1264 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1265 = extractvalue { <8 x ptr>, <8 x i64> } %1263, 1
  %1266 = extractelement <8 x ptr> %1264, i32 0
  %1267 = extractelement <8 x i64> %1265, i32 0
  %1268 = sub i64 %1267, 0
  %1269 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1270 = select i1 %1269, i64 %1268, i64 0
  %private.contiguous.address623 = getelementptr i8, ptr %1266, i64 %1270
  %private.contiguous.load624 = load <8 x float>, ptr %private.contiguous.address623, align 4
  %1271 = select <8 x i1> %71, <8 x float> %private.contiguous.load624, <8 x float> zeroinitializer
  %.state625 = load <8 x float>, ptr %.slot112, align 32
  %1272 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state625, <8 x float> %1271)
  %.state626 = load i64, ptr %.slot111, align 4
  %1273 = add i64 %.state626, 1
  store i64 %1273, ptr %.slot111, align 4
  %1274 = load <8 x float>, ptr %.slot112, align 32
  %1275 = select <8 x i1> %71, <8 x float> %1272, <8 x float> %1274
  store <8 x float> %1275, ptr %.slot112, align 32
  br label %direct.schedule.67

direct.schedule.69:                               ; preds = %direct.false618
  %.state627 = load <8 x float>, ptr %.slot35, align 32
  %.state628 = load <8 x float>, ptr %.slot112, align 32
  %1276 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state627, <8 x float> %.state628)
  %1277 = load <8 x float>, ptr %.spill113, align 32
  %1278 = select <8 x i1> %71, <8 x float> %1276, <8 x float> %1277
  store <8 x float> %1278, ptr %.spill113, align 32
  %.state629 = load <8 x float>, ptr %.slot35, align 32
  %1279 = fsub <8 x float> %.state629, %1276
  %1280 = select <8 x i1> %71, <8 x float> %1279, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1280)
  %1281 = load <8 x float>, ptr %.spill114, align 32
  %1282 = select <8 x i1> %71, <8 x float> %native.exp, <8 x float> %1281
  store <8 x float> %1282, ptr %.spill114, align 32
  %.spill.load630 = load <8 x float>, ptr %.spill94, align 32
  %1283 = fsub <8 x float> %.spill.load630, %1276
  %.spill.load631 = load <8 x float>, ptr %.spill95, align 32
  %1284 = fsub <8 x float> %.spill.load631, %1276
  %.spill.load632 = load <8 x float>, ptr %.spill96, align 32
  %1285 = fsub <8 x float> %.spill.load632, %1276
  %.spill.load633 = load <8 x float>, ptr %.spill97, align 32
  %1286 = fsub <8 x float> %.spill.load633, %1276
  %.spill.load634 = load <8 x float>, ptr %.spill98, align 32
  %1287 = fsub <8 x float> %.spill.load634, %1276
  %.spill.load635 = load <8 x float>, ptr %.spill99, align 32
  %1288 = fsub <8 x float> %.spill.load635, %1276
  %.spill.load636 = load <8 x float>, ptr %.spill100, align 32
  %1289 = fsub <8 x float> %.spill.load636, %1276
  %.spill.load637 = load <8 x float>, ptr %.spill101, align 32
  %1290 = fsub <8 x float> %.spill.load637, %1276
  %.spill.load638 = load <8 x float>, ptr %.spill102, align 32
  %1291 = fsub <8 x float> %.spill.load638, %1276
  %.spill.load639 = load <8 x float>, ptr %.spill103, align 32
  %1292 = fsub <8 x float> %.spill.load639, %1276
  %.spill.load640 = load <8 x float>, ptr %.spill104, align 32
  %1293 = fsub <8 x float> %.spill.load640, %1276
  %.spill.load641 = load <8 x float>, ptr %.spill105, align 32
  %1294 = fsub <8 x float> %.spill.load641, %1276
  %.spill.load642 = load <8 x float>, ptr %.spill106, align 32
  %1295 = fsub <8 x float> %.spill.load642, %1276
  %.spill.load643 = load <8 x float>, ptr %.spill107, align 32
  %1296 = fsub <8 x float> %.spill.load643, %1276
  %.spill.load644 = load <8 x float>, ptr %.spill108, align 32
  %1297 = fsub <8 x float> %.spill.load644, %1276
  %.spill.load645 = load <8 x float>, ptr %.spill109, align 32
  %1298 = fsub <8 x float> %.spill.load645, %1276
  %1299 = select <8 x i1> %71, <8 x float> %1283, <8 x float> zeroinitializer
  %native.exp646 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1299)
  %1300 = select <8 x i1> %71, <8 x float> %1284, <8 x float> zeroinitializer
  %native.exp647 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1300)
  %1301 = select <8 x i1> %71, <8 x float> %1285, <8 x float> zeroinitializer
  %native.exp648 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1301)
  %1302 = select <8 x i1> %71, <8 x float> %1286, <8 x float> zeroinitializer
  %native.exp649 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1302)
  %1303 = select <8 x i1> %71, <8 x float> %1287, <8 x float> zeroinitializer
  %native.exp650 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1303)
  %1304 = select <8 x i1> %71, <8 x float> %1288, <8 x float> zeroinitializer
  %native.exp651 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1304)
  %1305 = select <8 x i1> %71, <8 x float> %1289, <8 x float> zeroinitializer
  %native.exp652 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1305)
  %1306 = select <8 x i1> %71, <8 x float> %1290, <8 x float> zeroinitializer
  %native.exp653 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1306)
  %1307 = select <8 x i1> %71, <8 x float> %1291, <8 x float> zeroinitializer
  %native.exp654 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1307)
  %1308 = select <8 x i1> %71, <8 x float> %1292, <8 x float> zeroinitializer
  %native.exp655 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1308)
  %1309 = select <8 x i1> %71, <8 x float> %1293, <8 x float> zeroinitializer
  %native.exp656 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1309)
  %1310 = select <8 x i1> %71, <8 x float> %1294, <8 x float> zeroinitializer
  %native.exp657 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1310)
  %1311 = select <8 x i1> %71, <8 x float> %1295, <8 x float> zeroinitializer
  %native.exp658 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1311)
  %1312 = select <8 x i1> %71, <8 x float> %1296, <8 x float> zeroinitializer
  %native.exp659 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1312)
  %1313 = select <8 x i1> %71, <8 x float> %1297, <8 x float> zeroinitializer
  %native.exp660 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1313)
  %1314 = select <8 x i1> %71, <8 x float> %1298, <8 x float> zeroinitializer
  %native.exp661 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1314)
  %.spill.load662 = load <8 x i1>, ptr %.spill78, align 1
  %1315 = select <8 x i1> %.spill.load662, <8 x float> %native.exp646, <8 x float> zeroinitializer
  %1316 = load <8 x float>, ptr %.spill115, align 32
  %1317 = select <8 x i1> %71, <8 x float> %1315, <8 x float> %1316
  store <8 x float> %1317, ptr %.spill115, align 32
  %.spill.load663 = load <8 x i1>, ptr %.spill79, align 1
  %1318 = select <8 x i1> %.spill.load663, <8 x float> %native.exp647, <8 x float> zeroinitializer
  %1319 = load <8 x float>, ptr %.spill116, align 32
  %1320 = select <8 x i1> %71, <8 x float> %1318, <8 x float> %1319
  store <8 x float> %1320, ptr %.spill116, align 32
  %.spill.load664 = load <8 x i1>, ptr %.spill80, align 1
  %1321 = select <8 x i1> %.spill.load664, <8 x float> %native.exp648, <8 x float> zeroinitializer
  %1322 = load <8 x float>, ptr %.spill117, align 32
  %1323 = select <8 x i1> %71, <8 x float> %1321, <8 x float> %1322
  store <8 x float> %1323, ptr %.spill117, align 32
  %.spill.load665 = load <8 x i1>, ptr %.spill81, align 1
  %1324 = select <8 x i1> %.spill.load665, <8 x float> %native.exp649, <8 x float> zeroinitializer
  %1325 = load <8 x float>, ptr %.spill118, align 32
  %1326 = select <8 x i1> %71, <8 x float> %1324, <8 x float> %1325
  store <8 x float> %1326, ptr %.spill118, align 32
  %.spill.load666 = load <8 x i1>, ptr %.spill82, align 1
  %1327 = select <8 x i1> %.spill.load666, <8 x float> %native.exp650, <8 x float> zeroinitializer
  %1328 = load <8 x float>, ptr %.spill119, align 32
  %1329 = select <8 x i1> %71, <8 x float> %1327, <8 x float> %1328
  store <8 x float> %1329, ptr %.spill119, align 32
  %.spill.load667 = load <8 x i1>, ptr %.spill83, align 1
  %1330 = select <8 x i1> %.spill.load667, <8 x float> %native.exp651, <8 x float> zeroinitializer
  %1331 = load <8 x float>, ptr %.spill120, align 32
  %1332 = select <8 x i1> %71, <8 x float> %1330, <8 x float> %1331
  store <8 x float> %1332, ptr %.spill120, align 32
  %.spill.load668 = load <8 x i1>, ptr %.spill84, align 1
  %1333 = select <8 x i1> %.spill.load668, <8 x float> %native.exp652, <8 x float> zeroinitializer
  %1334 = load <8 x float>, ptr %.spill121, align 32
  %1335 = select <8 x i1> %71, <8 x float> %1333, <8 x float> %1334
  store <8 x float> %1335, ptr %.spill121, align 32
  %.spill.load669 = load <8 x i1>, ptr %.spill85, align 1
  %1336 = select <8 x i1> %.spill.load669, <8 x float> %native.exp653, <8 x float> zeroinitializer
  %1337 = load <8 x float>, ptr %.spill122, align 32
  %1338 = select <8 x i1> %71, <8 x float> %1336, <8 x float> %1337
  store <8 x float> %1338, ptr %.spill122, align 32
  %.spill.load670 = load <8 x i1>, ptr %.spill86, align 1
  %1339 = select <8 x i1> %.spill.load670, <8 x float> %native.exp654, <8 x float> zeroinitializer
  %1340 = load <8 x float>, ptr %.spill123, align 32
  %1341 = select <8 x i1> %71, <8 x float> %1339, <8 x float> %1340
  store <8 x float> %1341, ptr %.spill123, align 32
  %.spill.load671 = load <8 x i1>, ptr %.spill87, align 1
  %1342 = select <8 x i1> %.spill.load671, <8 x float> %native.exp655, <8 x float> zeroinitializer
  %1343 = load <8 x float>, ptr %.spill124, align 32
  %1344 = select <8 x i1> %71, <8 x float> %1342, <8 x float> %1343
  store <8 x float> %1344, ptr %.spill124, align 32
  %.spill.load672 = load <8 x i1>, ptr %.spill88, align 1
  %1345 = select <8 x i1> %.spill.load672, <8 x float> %native.exp656, <8 x float> zeroinitializer
  %1346 = load <8 x float>, ptr %.spill125, align 32
  %1347 = select <8 x i1> %71, <8 x float> %1345, <8 x float> %1346
  store <8 x float> %1347, ptr %.spill125, align 32
  %.spill.load673 = load <8 x i1>, ptr %.spill89, align 1
  %1348 = select <8 x i1> %.spill.load673, <8 x float> %native.exp657, <8 x float> zeroinitializer
  %1349 = load <8 x float>, ptr %.spill126, align 32
  %1350 = select <8 x i1> %71, <8 x float> %1348, <8 x float> %1349
  store <8 x float> %1350, ptr %.spill126, align 32
  %.spill.load674 = load <8 x i1>, ptr %.spill90, align 1
  %1351 = select <8 x i1> %.spill.load674, <8 x float> %native.exp658, <8 x float> zeroinitializer
  %1352 = load <8 x float>, ptr %.spill127, align 32
  %1353 = select <8 x i1> %71, <8 x float> %1351, <8 x float> %1352
  store <8 x float> %1353, ptr %.spill127, align 32
  %.spill.load675 = load <8 x i1>, ptr %.spill91, align 1
  %1354 = select <8 x i1> %.spill.load675, <8 x float> %native.exp659, <8 x float> zeroinitializer
  %1355 = load <8 x float>, ptr %.spill128, align 32
  %1356 = select <8 x i1> %71, <8 x float> %1354, <8 x float> %1355
  store <8 x float> %1356, ptr %.spill128, align 32
  %.spill.load676 = load <8 x i1>, ptr %.spill92, align 1
  %1357 = select <8 x i1> %.spill.load676, <8 x float> %native.exp660, <8 x float> zeroinitializer
  %1358 = load <8 x float>, ptr %.spill129, align 32
  %1359 = select <8 x i1> %71, <8 x float> %1357, <8 x float> %1358
  store <8 x float> %1359, ptr %.spill129, align 32
  %.spill.load677 = load <8 x i1>, ptr %.spill93, align 1
  %1360 = select <8 x i1> %.spill.load677, <8 x float> %native.exp661, <8 x float> zeroinitializer
  %1361 = load <8 x float>, ptr %.spill130, align 32
  %1362 = select <8 x i1> %71, <8 x float> %1360, <8 x float> %1361
  store <8 x float> %1362, ptr %.spill130, align 32
  %1363 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill131, align 64
  %1364 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1365 = extractvalue { <8 x ptr>, <8 x i64> } %1363, 0
  %1366 = select <8 x i1> %71, <8 x ptr> %1364, <8 x ptr> %1365
  %1367 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1368 = extractvalue { <8 x ptr>, <8 x i64> } %1363, 1
  %1369 = select <8 x i1> %71, <8 x i64> %1367, <8 x i64> %1368
  %1370 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1366, 0
  %1371 = insertvalue { <8 x ptr>, <8 x i64> } %1370, <8 x i64> %1369, 1
  store { <8 x ptr>, <8 x i64> } %1371, ptr %tile_snapshot.spill131, align 64
  %1372 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1373 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1374 = add <8 x i64> %1373, zeroinitializer
  %1375 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1372, 0
  %1376 = insertvalue { <8 x ptr>, <8 x i64> } %1375, <8 x i64> %1374, 1
  %1377 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1378 = extractvalue { <8 x ptr>, <8 x i64> } %1376, 1
  %1379 = extractelement <8 x ptr> %1377, i32 0
  %1380 = extractelement <8 x i64> %1378, i32 0
  %1381 = sub i64 %1380, 0
  %1382 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1383 = select i1 %1382, i64 %1381, i64 0
  %private.contiguous.address678 = getelementptr i8, ptr %1379, i64 %1383
  %private.contiguous.preserve679 = load <8 x float>, ptr %private.contiguous.address678, align 4
  %1384 = select <8 x i1> %71, <8 x float> %1315, <8 x float> %private.contiguous.preserve679
  store <8 x float> %1384, ptr %private.contiguous.address678, align 4
  %1385 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1386 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1387 = add <8 x i64> %1386, splat (i64 32)
  %1388 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1385, 0
  %1389 = insertvalue { <8 x ptr>, <8 x i64> } %1388, <8 x i64> %1387, 1
  %1390 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1391 = extractvalue { <8 x ptr>, <8 x i64> } %1389, 1
  %1392 = extractelement <8 x ptr> %1390, i32 0
  %1393 = extractelement <8 x i64> %1391, i32 0
  %1394 = sub i64 %1393, 0
  %1395 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1396 = select i1 %1395, i64 %1394, i64 0
  %private.contiguous.address680 = getelementptr i8, ptr %1392, i64 %1396
  %private.contiguous.preserve681 = load <8 x float>, ptr %private.contiguous.address680, align 4
  %1397 = select <8 x i1> %71, <8 x float> %1318, <8 x float> %private.contiguous.preserve681
  store <8 x float> %1397, ptr %private.contiguous.address680, align 4
  %1398 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1399 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1400 = add <8 x i64> %1399, splat (i64 64)
  %1401 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1398, 0
  %1402 = insertvalue { <8 x ptr>, <8 x i64> } %1401, <8 x i64> %1400, 1
  %1403 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1404 = extractvalue { <8 x ptr>, <8 x i64> } %1402, 1
  %1405 = extractelement <8 x ptr> %1403, i32 0
  %1406 = extractelement <8 x i64> %1404, i32 0
  %1407 = sub i64 %1406, 0
  %1408 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1409 = select i1 %1408, i64 %1407, i64 0
  %private.contiguous.address682 = getelementptr i8, ptr %1405, i64 %1409
  %private.contiguous.preserve683 = load <8 x float>, ptr %private.contiguous.address682, align 4
  %1410 = select <8 x i1> %71, <8 x float> %1321, <8 x float> %private.contiguous.preserve683
  store <8 x float> %1410, ptr %private.contiguous.address682, align 4
  %1411 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1412 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1413 = add <8 x i64> %1412, splat (i64 96)
  %1414 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1411, 0
  %1415 = insertvalue { <8 x ptr>, <8 x i64> } %1414, <8 x i64> %1413, 1
  %1416 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1417 = extractvalue { <8 x ptr>, <8 x i64> } %1415, 1
  %1418 = extractelement <8 x ptr> %1416, i32 0
  %1419 = extractelement <8 x i64> %1417, i32 0
  %1420 = sub i64 %1419, 0
  %1421 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1422 = select i1 %1421, i64 %1420, i64 0
  %private.contiguous.address684 = getelementptr i8, ptr %1418, i64 %1422
  %private.contiguous.preserve685 = load <8 x float>, ptr %private.contiguous.address684, align 4
  %1423 = select <8 x i1> %71, <8 x float> %1324, <8 x float> %private.contiguous.preserve685
  store <8 x float> %1423, ptr %private.contiguous.address684, align 4
  %1424 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1425 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1426 = add <8 x i64> %1425, splat (i64 128)
  %1427 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1424, 0
  %1428 = insertvalue { <8 x ptr>, <8 x i64> } %1427, <8 x i64> %1426, 1
  %1429 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1430 = extractvalue { <8 x ptr>, <8 x i64> } %1428, 1
  %1431 = extractelement <8 x ptr> %1429, i32 0
  %1432 = extractelement <8 x i64> %1430, i32 0
  %1433 = sub i64 %1432, 0
  %1434 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1435 = select i1 %1434, i64 %1433, i64 0
  %private.contiguous.address686 = getelementptr i8, ptr %1431, i64 %1435
  %private.contiguous.preserve687 = load <8 x float>, ptr %private.contiguous.address686, align 4
  %1436 = select <8 x i1> %71, <8 x float> %1327, <8 x float> %private.contiguous.preserve687
  store <8 x float> %1436, ptr %private.contiguous.address686, align 4
  %1437 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1438 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1439 = add <8 x i64> %1438, splat (i64 160)
  %1440 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1437, 0
  %1441 = insertvalue { <8 x ptr>, <8 x i64> } %1440, <8 x i64> %1439, 1
  %1442 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1443 = extractvalue { <8 x ptr>, <8 x i64> } %1441, 1
  %1444 = extractelement <8 x ptr> %1442, i32 0
  %1445 = extractelement <8 x i64> %1443, i32 0
  %1446 = sub i64 %1445, 0
  %1447 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1448 = select i1 %1447, i64 %1446, i64 0
  %private.contiguous.address688 = getelementptr i8, ptr %1444, i64 %1448
  %private.contiguous.preserve689 = load <8 x float>, ptr %private.contiguous.address688, align 4
  %1449 = select <8 x i1> %71, <8 x float> %1330, <8 x float> %private.contiguous.preserve689
  store <8 x float> %1449, ptr %private.contiguous.address688, align 4
  %1450 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1451 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1452 = add <8 x i64> %1451, splat (i64 192)
  %1453 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1450, 0
  %1454 = insertvalue { <8 x ptr>, <8 x i64> } %1453, <8 x i64> %1452, 1
  %1455 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1456 = extractvalue { <8 x ptr>, <8 x i64> } %1454, 1
  %1457 = extractelement <8 x ptr> %1455, i32 0
  %1458 = extractelement <8 x i64> %1456, i32 0
  %1459 = sub i64 %1458, 0
  %1460 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1461 = select i1 %1460, i64 %1459, i64 0
  %private.contiguous.address690 = getelementptr i8, ptr %1457, i64 %1461
  %private.contiguous.preserve691 = load <8 x float>, ptr %private.contiguous.address690, align 4
  %1462 = select <8 x i1> %71, <8 x float> %1333, <8 x float> %private.contiguous.preserve691
  store <8 x float> %1462, ptr %private.contiguous.address690, align 4
  %1463 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1464 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1465 = add <8 x i64> %1464, splat (i64 224)
  %1466 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1463, 0
  %1467 = insertvalue { <8 x ptr>, <8 x i64> } %1466, <8 x i64> %1465, 1
  %1468 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1469 = extractvalue { <8 x ptr>, <8 x i64> } %1467, 1
  %1470 = extractelement <8 x ptr> %1468, i32 0
  %1471 = extractelement <8 x i64> %1469, i32 0
  %1472 = sub i64 %1471, 0
  %1473 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1474 = select i1 %1473, i64 %1472, i64 0
  %private.contiguous.address692 = getelementptr i8, ptr %1470, i64 %1474
  %private.contiguous.preserve693 = load <8 x float>, ptr %private.contiguous.address692, align 4
  %1475 = select <8 x i1> %71, <8 x float> %1336, <8 x float> %private.contiguous.preserve693
  store <8 x float> %1475, ptr %private.contiguous.address692, align 4
  %1476 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1477 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1478 = add <8 x i64> %1477, splat (i64 256)
  %1479 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1476, 0
  %1480 = insertvalue { <8 x ptr>, <8 x i64> } %1479, <8 x i64> %1478, 1
  %1481 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1482 = extractvalue { <8 x ptr>, <8 x i64> } %1480, 1
  %1483 = extractelement <8 x ptr> %1481, i32 0
  %1484 = extractelement <8 x i64> %1482, i32 0
  %1485 = sub i64 %1484, 0
  %1486 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1487 = select i1 %1486, i64 %1485, i64 0
  %private.contiguous.address694 = getelementptr i8, ptr %1483, i64 %1487
  %private.contiguous.preserve695 = load <8 x float>, ptr %private.contiguous.address694, align 4
  %1488 = select <8 x i1> %71, <8 x float> %1339, <8 x float> %private.contiguous.preserve695
  store <8 x float> %1488, ptr %private.contiguous.address694, align 4
  %1489 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1490 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1491 = add <8 x i64> %1490, splat (i64 288)
  %1492 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1489, 0
  %1493 = insertvalue { <8 x ptr>, <8 x i64> } %1492, <8 x i64> %1491, 1
  %1494 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1495 = extractvalue { <8 x ptr>, <8 x i64> } %1493, 1
  %1496 = extractelement <8 x ptr> %1494, i32 0
  %1497 = extractelement <8 x i64> %1495, i32 0
  %1498 = sub i64 %1497, 0
  %1499 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1500 = select i1 %1499, i64 %1498, i64 0
  %private.contiguous.address696 = getelementptr i8, ptr %1496, i64 %1500
  %private.contiguous.preserve697 = load <8 x float>, ptr %private.contiguous.address696, align 4
  %1501 = select <8 x i1> %71, <8 x float> %1342, <8 x float> %private.contiguous.preserve697
  store <8 x float> %1501, ptr %private.contiguous.address696, align 4
  %1502 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1503 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1504 = add <8 x i64> %1503, splat (i64 320)
  %1505 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1502, 0
  %1506 = insertvalue { <8 x ptr>, <8 x i64> } %1505, <8 x i64> %1504, 1
  %1507 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1508 = extractvalue { <8 x ptr>, <8 x i64> } %1506, 1
  %1509 = extractelement <8 x ptr> %1507, i32 0
  %1510 = extractelement <8 x i64> %1508, i32 0
  %1511 = sub i64 %1510, 0
  %1512 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1513 = select i1 %1512, i64 %1511, i64 0
  %private.contiguous.address698 = getelementptr i8, ptr %1509, i64 %1513
  %private.contiguous.preserve699 = load <8 x float>, ptr %private.contiguous.address698, align 4
  %1514 = select <8 x i1> %71, <8 x float> %1345, <8 x float> %private.contiguous.preserve699
  store <8 x float> %1514, ptr %private.contiguous.address698, align 4
  %1515 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1516 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1517 = add <8 x i64> %1516, splat (i64 352)
  %1518 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1515, 0
  %1519 = insertvalue { <8 x ptr>, <8 x i64> } %1518, <8 x i64> %1517, 1
  %1520 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1521 = extractvalue { <8 x ptr>, <8 x i64> } %1519, 1
  %1522 = extractelement <8 x ptr> %1520, i32 0
  %1523 = extractelement <8 x i64> %1521, i32 0
  %1524 = sub i64 %1523, 0
  %1525 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1526 = select i1 %1525, i64 %1524, i64 0
  %private.contiguous.address700 = getelementptr i8, ptr %1522, i64 %1526
  %private.contiguous.preserve701 = load <8 x float>, ptr %private.contiguous.address700, align 4
  %1527 = select <8 x i1> %71, <8 x float> %1348, <8 x float> %private.contiguous.preserve701
  store <8 x float> %1527, ptr %private.contiguous.address700, align 4
  %1528 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1529 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1530 = add <8 x i64> %1529, splat (i64 384)
  %1531 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1528, 0
  %1532 = insertvalue { <8 x ptr>, <8 x i64> } %1531, <8 x i64> %1530, 1
  %1533 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1534 = extractvalue { <8 x ptr>, <8 x i64> } %1532, 1
  %1535 = extractelement <8 x ptr> %1533, i32 0
  %1536 = extractelement <8 x i64> %1534, i32 0
  %1537 = sub i64 %1536, 0
  %1538 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1539 = select i1 %1538, i64 %1537, i64 0
  %private.contiguous.address702 = getelementptr i8, ptr %1535, i64 %1539
  %private.contiguous.preserve703 = load <8 x float>, ptr %private.contiguous.address702, align 4
  %1540 = select <8 x i1> %71, <8 x float> %1351, <8 x float> %private.contiguous.preserve703
  store <8 x float> %1540, ptr %private.contiguous.address702, align 4
  %1541 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1542 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1543 = add <8 x i64> %1542, splat (i64 416)
  %1544 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1541, 0
  %1545 = insertvalue { <8 x ptr>, <8 x i64> } %1544, <8 x i64> %1543, 1
  %1546 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1547 = extractvalue { <8 x ptr>, <8 x i64> } %1545, 1
  %1548 = extractelement <8 x ptr> %1546, i32 0
  %1549 = extractelement <8 x i64> %1547, i32 0
  %1550 = sub i64 %1549, 0
  %1551 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1552 = select i1 %1551, i64 %1550, i64 0
  %private.contiguous.address704 = getelementptr i8, ptr %1548, i64 %1552
  %private.contiguous.preserve705 = load <8 x float>, ptr %private.contiguous.address704, align 4
  %1553 = select <8 x i1> %71, <8 x float> %1354, <8 x float> %private.contiguous.preserve705
  store <8 x float> %1553, ptr %private.contiguous.address704, align 4
  %1554 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1555 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1556 = add <8 x i64> %1555, splat (i64 448)
  %1557 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1554, 0
  %1558 = insertvalue { <8 x ptr>, <8 x i64> } %1557, <8 x i64> %1556, 1
  %1559 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1560 = extractvalue { <8 x ptr>, <8 x i64> } %1558, 1
  %1561 = extractelement <8 x ptr> %1559, i32 0
  %1562 = extractelement <8 x i64> %1560, i32 0
  %1563 = sub i64 %1562, 0
  %1564 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1565 = select i1 %1564, i64 %1563, i64 0
  %private.contiguous.address706 = getelementptr i8, ptr %1561, i64 %1565
  %private.contiguous.preserve707 = load <8 x float>, ptr %private.contiguous.address706, align 4
  %1566 = select <8 x i1> %71, <8 x float> %1357, <8 x float> %private.contiguous.preserve707
  store <8 x float> %1566, ptr %private.contiguous.address706, align 4
  %1567 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1568 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1569 = add <8 x i64> %1568, splat (i64 480)
  %1570 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1567, 0
  %1571 = insertvalue { <8 x ptr>, <8 x i64> } %1570, <8 x i64> %1569, 1
  %1572 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1573 = extractvalue { <8 x ptr>, <8 x i64> } %1571, 1
  %1574 = extractelement <8 x ptr> %1572, i32 0
  %1575 = extractelement <8 x i64> %1573, i32 0
  %1576 = sub i64 %1575, 0
  %1577 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1578 = select i1 %1577, i64 %1576, i64 0
  %private.contiguous.address708 = getelementptr i8, ptr %1574, i64 %1578
  %private.contiguous.preserve709 = load <8 x float>, ptr %private.contiguous.address708, align 4
  %1579 = select <8 x i1> %71, <8 x float> %1360, <8 x float> %private.contiguous.preserve709
  store <8 x float> %1579, ptr %private.contiguous.address708, align 4
  %.state710 = load <8 x float>, ptr %.slot36, align 32
  %1580 = fmul <8 x float> %.state710, %native.exp
  %1581 = load <8 x float>, ptr %.spill132, align 32
  %1582 = select <8 x i1> %71, <8 x float> %1580, <8 x float> %1581
  store <8 x float> %1582, ptr %.spill132, align 32
  store i64 0, ptr %.slot133, align 4
  %1583 = load <8 x float>, ptr %.slot134, align 32
  %1584 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1583
  store <8 x float> %1584, ptr %.slot134, align 32
  br label %direct.schedule.70

direct.schedule.70:                               ; preds = %direct.schedule.71, %direct.schedule.69
  %.state711 = load i64, ptr %.slot133, align 4
  %1585 = icmp slt i64 %.state711, 16
  br i1 %1585, label %direct.true712, label %direct.false713

direct.schedule.71:                               ; preds = %direct.true712
  %.state714 = load i64, ptr %.slot133, align 4
  %1586 = sdiv i64 %.state714, 1
  %1587 = add i64 0, %1586
  %tile_snapshot.spill.load715 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill131, align 64
  %1588 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load715, 0
  %1589 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load715, 1
  %.splatinsert716 = insertelement <8 x i64> poison, i64 %1587, i64 0
  %.splat717 = shufflevector <8 x i64> %.splatinsert716, <8 x i64> poison, <8 x i32> zeroinitializer
  %1590 = mul <8 x i64> %.splat717, splat (i64 32)
  %1591 = add <8 x i64> %1589, %1590
  %1592 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1588, 0
  %1593 = insertvalue { <8 x ptr>, <8 x i64> } %1592, <8 x i64> %1591, 1
  %1594 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1595 = extractvalue { <8 x ptr>, <8 x i64> } %1593, 1
  %1596 = extractelement <8 x ptr> %1594, i32 0
  %1597 = extractelement <8 x i64> %1595, i32 0
  %1598 = sub i64 %1597, 0
  %1599 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1600 = select i1 %1599, i64 %1598, i64 0
  %private.contiguous.address718 = getelementptr i8, ptr %1596, i64 %1600
  %private.contiguous.load719 = load <8 x float>, ptr %private.contiguous.address718, align 4
  %1601 = select <8 x i1> %71, <8 x float> %private.contiguous.load719, <8 x float> zeroinitializer
  %.state720 = load <8 x float>, ptr %.slot134, align 32
  %1602 = fadd <8 x float> %.state720, %1601
  %.state721 = load i64, ptr %.slot133, align 4
  %1603 = add i64 %.state721, 1
  store i64 %1603, ptr %.slot133, align 4
  %1604 = load <8 x float>, ptr %.slot134, align 32
  %1605 = select <8 x i1> %71, <8 x float> %1602, <8 x float> %1604
  store <8 x float> %1605, ptr %.slot134, align 32
  br label %direct.schedule.70

direct.schedule.72:                               ; preds = %direct.false713
  %.spill.load722 = load <8 x float>, ptr %.spill132, align 32
  %.state723 = load <8 x float>, ptr %.slot134, align 32
  %1606 = fadd <8 x float> %.spill.load722, %.state723
  %1607 = load <8 x float>, ptr %.spill135, align 32
  %1608 = select <8 x i1> %71, <8 x float> %1606, <8 x float> %1607
  store <8 x float> %1608, ptr %.spill135, align 32
  %1609 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill136, align 64
  %1610 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1611 = extractvalue { <8 x ptr>, <8 x i64> } %1609, 0
  %1612 = select <8 x i1> %71, <8 x ptr> %1610, <8 x ptr> %1611
  %1613 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1614 = extractvalue { <8 x ptr>, <8 x i64> } %1609, 1
  %1615 = select <8 x i1> %71, <8 x i64> %1613, <8 x i64> %1614
  %1616 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1612, 0
  %1617 = insertvalue { <8 x ptr>, <8 x i64> } %1616, <8 x i64> %1615, 1
  store { <8 x ptr>, <8 x i64> } %1617, ptr %tile_snapshot.spill136, align 64
  store i64 0, ptr %.slot137, align 4
  br label %direct.schedule.73

direct.schedule.73:                               ; preds = %direct.schedule.74, %direct.schedule.72
  %.state724 = load i64, ptr %.slot137, align 4
  %1618 = icmp slt i64 %.state724, 96
  br i1 %1618, label %direct.true725, label %direct.false726

direct.schedule.74:                               ; preds = %direct.true725
  %.state727 = load i64, ptr %.slot137, align 4
  %1619 = add i64 0, %.state727
  %tile_snapshot.spill.load728 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1620 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load728, 0
  %1621 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load728, 1
  %.splatinsert729 = insertelement <8 x i64> poison, i64 %1619, i64 0
  %.splat730 = shufflevector <8 x i64> %.splatinsert729, <8 x i64> poison, <8 x i32> zeroinitializer
  %1622 = mul <8 x i64> %.splat730, splat (i64 32)
  %1623 = add <8 x i64> %1621, %1622
  %1624 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1620, 0
  %1625 = insertvalue { <8 x ptr>, <8 x i64> } %1624, <8 x i64> %1623, 1
  %1626 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1627 = extractvalue { <8 x ptr>, <8 x i64> } %1625, 1
  %1628 = extractelement <8 x ptr> %1626, i32 0
  %1629 = extractelement <8 x i64> %1627, i32 0
  %1630 = sub i64 %1629, 0
  %1631 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1632 = select i1 %1631, i64 %1630, i64 0
  %private.contiguous.address731 = getelementptr i8, ptr %1628, i64 %1632
  %private.contiguous.load732 = load <8 x float>, ptr %private.contiguous.address731, align 4
  %1633 = select <8 x i1> %71, <8 x float> %private.contiguous.load732, <8 x float> zeroinitializer
  %.spill.load733 = load <8 x float>, ptr %.spill114, align 32
  %1634 = fmul <8 x float> %1633, %.spill.load733
  %tile_snapshot.spill.load734 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1635 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load734, 0
  %1636 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load734, 1
  %.splatinsert735 = insertelement <8 x i64> poison, i64 %1619, i64 0
  %.splat736 = shufflevector <8 x i64> %.splatinsert735, <8 x i64> poison, <8 x i32> zeroinitializer
  %1637 = mul <8 x i64> %.splat736, splat (i64 32)
  %1638 = add <8 x i64> %1636, %1637
  %1639 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1635, 0
  %1640 = insertvalue { <8 x ptr>, <8 x i64> } %1639, <8 x i64> %1638, 1
  %1641 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1642 = extractvalue { <8 x ptr>, <8 x i64> } %1640, 1
  %1643 = extractelement <8 x ptr> %1641, i32 0
  %1644 = extractelement <8 x i64> %1642, i32 0
  %1645 = sub i64 %1644, 0
  %1646 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1647 = select i1 %1646, i64 %1645, i64 0
  %private.contiguous.address737 = getelementptr i8, ptr %1643, i64 %1647
  %private.contiguous.load738 = load <8 x float>, ptr %private.contiguous.address737, align 4
  %1648 = select <8 x i1> %71, <8 x float> %private.contiguous.load738, <8 x float> zeroinitializer
  %.spill.load739 = load <8 x float>, ptr %.spill115, align 32
  %1649 = fmul <8 x float> %.spill.load739, %1648
  %1650 = fadd <8 x float> %1634, %1649
  %.state740 = load i64, ptr %.slot137, align 4
  %1651 = add i64 96, %.state740
  %tile_snapshot.spill.load741 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1652 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load741, 0
  %1653 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load741, 1
  %.splatinsert742 = insertelement <8 x i64> poison, i64 %1651, i64 0
  %.splat743 = shufflevector <8 x i64> %.splatinsert742, <8 x i64> poison, <8 x i32> zeroinitializer
  %1654 = mul <8 x i64> %.splat743, splat (i64 32)
  %1655 = add <8 x i64> %1653, %1654
  %1656 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1652, 0
  %1657 = insertvalue { <8 x ptr>, <8 x i64> } %1656, <8 x i64> %1655, 1
  %1658 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1659 = extractvalue { <8 x ptr>, <8 x i64> } %1657, 1
  %1660 = extractelement <8 x ptr> %1658, i32 0
  %1661 = extractelement <8 x i64> %1659, i32 0
  %1662 = sub i64 %1661, 0
  %1663 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1664 = select i1 %1663, i64 %1662, i64 0
  %private.contiguous.address744 = getelementptr i8, ptr %1660, i64 %1664
  %private.contiguous.load745 = load <8 x float>, ptr %private.contiguous.address744, align 4
  %1665 = select <8 x i1> %71, <8 x float> %private.contiguous.load745, <8 x float> zeroinitializer
  %.spill.load746 = load <8 x float>, ptr %.spill116, align 32
  %1666 = fmul <8 x float> %.spill.load746, %1665
  %1667 = fadd <8 x float> %1650, %1666
  %.state747 = load i64, ptr %.slot137, align 4
  %1668 = add i64 192, %.state747
  %tile_snapshot.spill.load748 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1669 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load748, 0
  %1670 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load748, 1
  %.splatinsert749 = insertelement <8 x i64> poison, i64 %1668, i64 0
  %.splat750 = shufflevector <8 x i64> %.splatinsert749, <8 x i64> poison, <8 x i32> zeroinitializer
  %1671 = mul <8 x i64> %.splat750, splat (i64 32)
  %1672 = add <8 x i64> %1670, %1671
  %1673 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1669, 0
  %1674 = insertvalue { <8 x ptr>, <8 x i64> } %1673, <8 x i64> %1672, 1
  %1675 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1676 = extractvalue { <8 x ptr>, <8 x i64> } %1674, 1
  %1677 = extractelement <8 x ptr> %1675, i32 0
  %1678 = extractelement <8 x i64> %1676, i32 0
  %1679 = sub i64 %1678, 0
  %1680 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1681 = select i1 %1680, i64 %1679, i64 0
  %private.contiguous.address751 = getelementptr i8, ptr %1677, i64 %1681
  %private.contiguous.load752 = load <8 x float>, ptr %private.contiguous.address751, align 4
  %1682 = select <8 x i1> %71, <8 x float> %private.contiguous.load752, <8 x float> zeroinitializer
  %.spill.load753 = load <8 x float>, ptr %.spill117, align 32
  %1683 = fmul <8 x float> %.spill.load753, %1682
  %1684 = fadd <8 x float> %1667, %1683
  %.state754 = load i64, ptr %.slot137, align 4
  %1685 = add i64 288, %.state754
  %tile_snapshot.spill.load755 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1686 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load755, 0
  %1687 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load755, 1
  %.splatinsert756 = insertelement <8 x i64> poison, i64 %1685, i64 0
  %.splat757 = shufflevector <8 x i64> %.splatinsert756, <8 x i64> poison, <8 x i32> zeroinitializer
  %1688 = mul <8 x i64> %.splat757, splat (i64 32)
  %1689 = add <8 x i64> %1687, %1688
  %1690 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1686, 0
  %1691 = insertvalue { <8 x ptr>, <8 x i64> } %1690, <8 x i64> %1689, 1
  %1692 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1693 = extractvalue { <8 x ptr>, <8 x i64> } %1691, 1
  %1694 = extractelement <8 x ptr> %1692, i32 0
  %1695 = extractelement <8 x i64> %1693, i32 0
  %1696 = sub i64 %1695, 0
  %1697 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1698 = select i1 %1697, i64 %1696, i64 0
  %private.contiguous.address758 = getelementptr i8, ptr %1694, i64 %1698
  %private.contiguous.load759 = load <8 x float>, ptr %private.contiguous.address758, align 4
  %1699 = select <8 x i1> %71, <8 x float> %private.contiguous.load759, <8 x float> zeroinitializer
  %.spill.load760 = load <8 x float>, ptr %.spill118, align 32
  %1700 = fmul <8 x float> %.spill.load760, %1699
  %1701 = fadd <8 x float> %1684, %1700
  %.state761 = load i64, ptr %.slot137, align 4
  %1702 = add i64 384, %.state761
  %tile_snapshot.spill.load762 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1703 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 0
  %1704 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load762, 1
  %.splatinsert763 = insertelement <8 x i64> poison, i64 %1702, i64 0
  %.splat764 = shufflevector <8 x i64> %.splatinsert763, <8 x i64> poison, <8 x i32> zeroinitializer
  %1705 = mul <8 x i64> %.splat764, splat (i64 32)
  %1706 = add <8 x i64> %1704, %1705
  %1707 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1703, 0
  %1708 = insertvalue { <8 x ptr>, <8 x i64> } %1707, <8 x i64> %1706, 1
  %1709 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1710 = extractvalue { <8 x ptr>, <8 x i64> } %1708, 1
  %1711 = extractelement <8 x ptr> %1709, i32 0
  %1712 = extractelement <8 x i64> %1710, i32 0
  %1713 = sub i64 %1712, 0
  %1714 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1715 = select i1 %1714, i64 %1713, i64 0
  %private.contiguous.address765 = getelementptr i8, ptr %1711, i64 %1715
  %private.contiguous.load766 = load <8 x float>, ptr %private.contiguous.address765, align 4
  %1716 = select <8 x i1> %71, <8 x float> %private.contiguous.load766, <8 x float> zeroinitializer
  %.spill.load767 = load <8 x float>, ptr %.spill119, align 32
  %1717 = fmul <8 x float> %.spill.load767, %1716
  %1718 = fadd <8 x float> %1701, %1717
  %.state768 = load i64, ptr %.slot137, align 4
  %1719 = add i64 480, %.state768
  %tile_snapshot.spill.load769 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1720 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load769, 0
  %1721 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load769, 1
  %.splatinsert770 = insertelement <8 x i64> poison, i64 %1719, i64 0
  %.splat771 = shufflevector <8 x i64> %.splatinsert770, <8 x i64> poison, <8 x i32> zeroinitializer
  %1722 = mul <8 x i64> %.splat771, splat (i64 32)
  %1723 = add <8 x i64> %1721, %1722
  %1724 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1720, 0
  %1725 = insertvalue { <8 x ptr>, <8 x i64> } %1724, <8 x i64> %1723, 1
  %1726 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1727 = extractvalue { <8 x ptr>, <8 x i64> } %1725, 1
  %1728 = extractelement <8 x ptr> %1726, i32 0
  %1729 = extractelement <8 x i64> %1727, i32 0
  %1730 = sub i64 %1729, 0
  %1731 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1732 = select i1 %1731, i64 %1730, i64 0
  %private.contiguous.address772 = getelementptr i8, ptr %1728, i64 %1732
  %private.contiguous.load773 = load <8 x float>, ptr %private.contiguous.address772, align 4
  %1733 = select <8 x i1> %71, <8 x float> %private.contiguous.load773, <8 x float> zeroinitializer
  %.spill.load774 = load <8 x float>, ptr %.spill120, align 32
  %1734 = fmul <8 x float> %.spill.load774, %1733
  %1735 = fadd <8 x float> %1718, %1734
  %.state775 = load i64, ptr %.slot137, align 4
  %1736 = add i64 576, %.state775
  %tile_snapshot.spill.load776 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1737 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load776, 0
  %1738 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load776, 1
  %.splatinsert777 = insertelement <8 x i64> poison, i64 %1736, i64 0
  %.splat778 = shufflevector <8 x i64> %.splatinsert777, <8 x i64> poison, <8 x i32> zeroinitializer
  %1739 = mul <8 x i64> %.splat778, splat (i64 32)
  %1740 = add <8 x i64> %1738, %1739
  %1741 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1737, 0
  %1742 = insertvalue { <8 x ptr>, <8 x i64> } %1741, <8 x i64> %1740, 1
  %1743 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1744 = extractvalue { <8 x ptr>, <8 x i64> } %1742, 1
  %1745 = extractelement <8 x ptr> %1743, i32 0
  %1746 = extractelement <8 x i64> %1744, i32 0
  %1747 = sub i64 %1746, 0
  %1748 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1749 = select i1 %1748, i64 %1747, i64 0
  %private.contiguous.address779 = getelementptr i8, ptr %1745, i64 %1749
  %private.contiguous.load780 = load <8 x float>, ptr %private.contiguous.address779, align 4
  %1750 = select <8 x i1> %71, <8 x float> %private.contiguous.load780, <8 x float> zeroinitializer
  %.spill.load781 = load <8 x float>, ptr %.spill121, align 32
  %1751 = fmul <8 x float> %.spill.load781, %1750
  %1752 = fadd <8 x float> %1735, %1751
  %.state782 = load i64, ptr %.slot137, align 4
  %1753 = add i64 672, %.state782
  %tile_snapshot.spill.load783 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1754 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load783, 0
  %1755 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load783, 1
  %.splatinsert784 = insertelement <8 x i64> poison, i64 %1753, i64 0
  %.splat785 = shufflevector <8 x i64> %.splatinsert784, <8 x i64> poison, <8 x i32> zeroinitializer
  %1756 = mul <8 x i64> %.splat785, splat (i64 32)
  %1757 = add <8 x i64> %1755, %1756
  %1758 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1754, 0
  %1759 = insertvalue { <8 x ptr>, <8 x i64> } %1758, <8 x i64> %1757, 1
  %1760 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1761 = extractvalue { <8 x ptr>, <8 x i64> } %1759, 1
  %1762 = extractelement <8 x ptr> %1760, i32 0
  %1763 = extractelement <8 x i64> %1761, i32 0
  %1764 = sub i64 %1763, 0
  %1765 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1766 = select i1 %1765, i64 %1764, i64 0
  %private.contiguous.address786 = getelementptr i8, ptr %1762, i64 %1766
  %private.contiguous.load787 = load <8 x float>, ptr %private.contiguous.address786, align 4
  %1767 = select <8 x i1> %71, <8 x float> %private.contiguous.load787, <8 x float> zeroinitializer
  %.spill.load788 = load <8 x float>, ptr %.spill122, align 32
  %1768 = fmul <8 x float> %.spill.load788, %1767
  %1769 = fadd <8 x float> %1752, %1768
  %.state789 = load i64, ptr %.slot137, align 4
  %1770 = add i64 768, %.state789
  %tile_snapshot.spill.load790 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1771 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load790, 0
  %1772 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load790, 1
  %.splatinsert791 = insertelement <8 x i64> poison, i64 %1770, i64 0
  %.splat792 = shufflevector <8 x i64> %.splatinsert791, <8 x i64> poison, <8 x i32> zeroinitializer
  %1773 = mul <8 x i64> %.splat792, splat (i64 32)
  %1774 = add <8 x i64> %1772, %1773
  %1775 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1771, 0
  %1776 = insertvalue { <8 x ptr>, <8 x i64> } %1775, <8 x i64> %1774, 1
  %1777 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1778 = extractvalue { <8 x ptr>, <8 x i64> } %1776, 1
  %1779 = extractelement <8 x ptr> %1777, i32 0
  %1780 = extractelement <8 x i64> %1778, i32 0
  %1781 = sub i64 %1780, 0
  %1782 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1783 = select i1 %1782, i64 %1781, i64 0
  %private.contiguous.address793 = getelementptr i8, ptr %1779, i64 %1783
  %private.contiguous.load794 = load <8 x float>, ptr %private.contiguous.address793, align 4
  %1784 = select <8 x i1> %71, <8 x float> %private.contiguous.load794, <8 x float> zeroinitializer
  %.spill.load795 = load <8 x float>, ptr %.spill123, align 32
  %1785 = fmul <8 x float> %.spill.load795, %1784
  %1786 = fadd <8 x float> %1769, %1785
  %.state796 = load i64, ptr %.slot137, align 4
  %1787 = add i64 864, %.state796
  %tile_snapshot.spill.load797 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1788 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load797, 0
  %1789 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load797, 1
  %.splatinsert798 = insertelement <8 x i64> poison, i64 %1787, i64 0
  %.splat799 = shufflevector <8 x i64> %.splatinsert798, <8 x i64> poison, <8 x i32> zeroinitializer
  %1790 = mul <8 x i64> %.splat799, splat (i64 32)
  %1791 = add <8 x i64> %1789, %1790
  %1792 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1788, 0
  %1793 = insertvalue { <8 x ptr>, <8 x i64> } %1792, <8 x i64> %1791, 1
  %1794 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1795 = extractvalue { <8 x ptr>, <8 x i64> } %1793, 1
  %1796 = extractelement <8 x ptr> %1794, i32 0
  %1797 = extractelement <8 x i64> %1795, i32 0
  %1798 = sub i64 %1797, 0
  %1799 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1800 = select i1 %1799, i64 %1798, i64 0
  %private.contiguous.address800 = getelementptr i8, ptr %1796, i64 %1800
  %private.contiguous.load801 = load <8 x float>, ptr %private.contiguous.address800, align 4
  %1801 = select <8 x i1> %71, <8 x float> %private.contiguous.load801, <8 x float> zeroinitializer
  %.spill.load802 = load <8 x float>, ptr %.spill124, align 32
  %1802 = fmul <8 x float> %.spill.load802, %1801
  %1803 = fadd <8 x float> %1786, %1802
  %.state803 = load i64, ptr %.slot137, align 4
  %1804 = add i64 960, %.state803
  %tile_snapshot.spill.load804 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1805 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load804, 0
  %1806 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load804, 1
  %.splatinsert805 = insertelement <8 x i64> poison, i64 %1804, i64 0
  %.splat806 = shufflevector <8 x i64> %.splatinsert805, <8 x i64> poison, <8 x i32> zeroinitializer
  %1807 = mul <8 x i64> %.splat806, splat (i64 32)
  %1808 = add <8 x i64> %1806, %1807
  %1809 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1805, 0
  %1810 = insertvalue { <8 x ptr>, <8 x i64> } %1809, <8 x i64> %1808, 1
  %1811 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1812 = extractvalue { <8 x ptr>, <8 x i64> } %1810, 1
  %1813 = extractelement <8 x ptr> %1811, i32 0
  %1814 = extractelement <8 x i64> %1812, i32 0
  %1815 = sub i64 %1814, 0
  %1816 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1817 = select i1 %1816, i64 %1815, i64 0
  %private.contiguous.address807 = getelementptr i8, ptr %1813, i64 %1817
  %private.contiguous.load808 = load <8 x float>, ptr %private.contiguous.address807, align 4
  %1818 = select <8 x i1> %71, <8 x float> %private.contiguous.load808, <8 x float> zeroinitializer
  %.spill.load809 = load <8 x float>, ptr %.spill125, align 32
  %1819 = fmul <8 x float> %.spill.load809, %1818
  %1820 = fadd <8 x float> %1803, %1819
  %.state810 = load i64, ptr %.slot137, align 4
  %1821 = add i64 1056, %.state810
  %tile_snapshot.spill.load811 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1822 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load811, 0
  %1823 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load811, 1
  %.splatinsert812 = insertelement <8 x i64> poison, i64 %1821, i64 0
  %.splat813 = shufflevector <8 x i64> %.splatinsert812, <8 x i64> poison, <8 x i32> zeroinitializer
  %1824 = mul <8 x i64> %.splat813, splat (i64 32)
  %1825 = add <8 x i64> %1823, %1824
  %1826 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1822, 0
  %1827 = insertvalue { <8 x ptr>, <8 x i64> } %1826, <8 x i64> %1825, 1
  %1828 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1829 = extractvalue { <8 x ptr>, <8 x i64> } %1827, 1
  %1830 = extractelement <8 x ptr> %1828, i32 0
  %1831 = extractelement <8 x i64> %1829, i32 0
  %1832 = sub i64 %1831, 0
  %1833 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1834 = select i1 %1833, i64 %1832, i64 0
  %private.contiguous.address814 = getelementptr i8, ptr %1830, i64 %1834
  %private.contiguous.load815 = load <8 x float>, ptr %private.contiguous.address814, align 4
  %1835 = select <8 x i1> %71, <8 x float> %private.contiguous.load815, <8 x float> zeroinitializer
  %.spill.load816 = load <8 x float>, ptr %.spill126, align 32
  %1836 = fmul <8 x float> %.spill.load816, %1835
  %1837 = fadd <8 x float> %1820, %1836
  %.state817 = load i64, ptr %.slot137, align 4
  %1838 = add i64 1152, %.state817
  %tile_snapshot.spill.load818 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1839 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load818, 0
  %1840 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load818, 1
  %.splatinsert819 = insertelement <8 x i64> poison, i64 %1838, i64 0
  %.splat820 = shufflevector <8 x i64> %.splatinsert819, <8 x i64> poison, <8 x i32> zeroinitializer
  %1841 = mul <8 x i64> %.splat820, splat (i64 32)
  %1842 = add <8 x i64> %1840, %1841
  %1843 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1839, 0
  %1844 = insertvalue { <8 x ptr>, <8 x i64> } %1843, <8 x i64> %1842, 1
  %1845 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1846 = extractvalue { <8 x ptr>, <8 x i64> } %1844, 1
  %1847 = extractelement <8 x ptr> %1845, i32 0
  %1848 = extractelement <8 x i64> %1846, i32 0
  %1849 = sub i64 %1848, 0
  %1850 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1851 = select i1 %1850, i64 %1849, i64 0
  %private.contiguous.address821 = getelementptr i8, ptr %1847, i64 %1851
  %private.contiguous.load822 = load <8 x float>, ptr %private.contiguous.address821, align 4
  %1852 = select <8 x i1> %71, <8 x float> %private.contiguous.load822, <8 x float> zeroinitializer
  %.spill.load823 = load <8 x float>, ptr %.spill127, align 32
  %1853 = fmul <8 x float> %.spill.load823, %1852
  %1854 = fadd <8 x float> %1837, %1853
  %.state824 = load i64, ptr %.slot137, align 4
  %1855 = add i64 1248, %.state824
  %tile_snapshot.spill.load825 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1856 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load825, 0
  %1857 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load825, 1
  %.splatinsert826 = insertelement <8 x i64> poison, i64 %1855, i64 0
  %.splat827 = shufflevector <8 x i64> %.splatinsert826, <8 x i64> poison, <8 x i32> zeroinitializer
  %1858 = mul <8 x i64> %.splat827, splat (i64 32)
  %1859 = add <8 x i64> %1857, %1858
  %1860 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1856, 0
  %1861 = insertvalue { <8 x ptr>, <8 x i64> } %1860, <8 x i64> %1859, 1
  %1862 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1863 = extractvalue { <8 x ptr>, <8 x i64> } %1861, 1
  %1864 = extractelement <8 x ptr> %1862, i32 0
  %1865 = extractelement <8 x i64> %1863, i32 0
  %1866 = sub i64 %1865, 0
  %1867 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1868 = select i1 %1867, i64 %1866, i64 0
  %private.contiguous.address828 = getelementptr i8, ptr %1864, i64 %1868
  %private.contiguous.load829 = load <8 x float>, ptr %private.contiguous.address828, align 4
  %1869 = select <8 x i1> %71, <8 x float> %private.contiguous.load829, <8 x float> zeroinitializer
  %.spill.load830 = load <8 x float>, ptr %.spill128, align 32
  %1870 = fmul <8 x float> %.spill.load830, %1869
  %1871 = fadd <8 x float> %1854, %1870
  %.state831 = load i64, ptr %.slot137, align 4
  %1872 = add i64 1344, %.state831
  %tile_snapshot.spill.load832 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1873 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load832, 0
  %1874 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load832, 1
  %.splatinsert833 = insertelement <8 x i64> poison, i64 %1872, i64 0
  %.splat834 = shufflevector <8 x i64> %.splatinsert833, <8 x i64> poison, <8 x i32> zeroinitializer
  %1875 = mul <8 x i64> %.splat834, splat (i64 32)
  %1876 = add <8 x i64> %1874, %1875
  %1877 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1873, 0
  %1878 = insertvalue { <8 x ptr>, <8 x i64> } %1877, <8 x i64> %1876, 1
  %1879 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1880 = extractvalue { <8 x ptr>, <8 x i64> } %1878, 1
  %1881 = extractelement <8 x ptr> %1879, i32 0
  %1882 = extractelement <8 x i64> %1880, i32 0
  %1883 = sub i64 %1882, 0
  %1884 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1885 = select i1 %1884, i64 %1883, i64 0
  %private.contiguous.address835 = getelementptr i8, ptr %1881, i64 %1885
  %private.contiguous.load836 = load <8 x float>, ptr %private.contiguous.address835, align 4
  %1886 = select <8 x i1> %71, <8 x float> %private.contiguous.load836, <8 x float> zeroinitializer
  %.spill.load837 = load <8 x float>, ptr %.spill129, align 32
  %1887 = fmul <8 x float> %.spill.load837, %1886
  %1888 = fadd <8 x float> %1871, %1887
  %.state838 = load i64, ptr %.slot137, align 4
  %1889 = add i64 1440, %.state838
  %tile_snapshot.spill.load839 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1890 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load839, 0
  %1891 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load839, 1
  %.splatinsert840 = insertelement <8 x i64> poison, i64 %1889, i64 0
  %.splat841 = shufflevector <8 x i64> %.splatinsert840, <8 x i64> poison, <8 x i32> zeroinitializer
  %1892 = mul <8 x i64> %.splat841, splat (i64 32)
  %1893 = add <8 x i64> %1891, %1892
  %1894 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1890, 0
  %1895 = insertvalue { <8 x ptr>, <8 x i64> } %1894, <8 x i64> %1893, 1
  %1896 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1897 = extractvalue { <8 x ptr>, <8 x i64> } %1895, 1
  %1898 = extractelement <8 x ptr> %1896, i32 0
  %1899 = extractelement <8 x i64> %1897, i32 0
  %1900 = sub i64 %1899, 0
  %1901 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1902 = select i1 %1901, i64 %1900, i64 0
  %private.contiguous.address842 = getelementptr i8, ptr %1898, i64 %1902
  %private.contiguous.load843 = load <8 x float>, ptr %private.contiguous.address842, align 4
  %1903 = select <8 x i1> %71, <8 x float> %private.contiguous.load843, <8 x float> zeroinitializer
  %.spill.load844 = load <8 x float>, ptr %.spill130, align 32
  %1904 = fmul <8 x float> %.spill.load844, %1903
  %1905 = fadd <8 x float> %1888, %1904
  %tile_snapshot.spill.load845 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill136, align 64
  %1906 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load845, 0
  %1907 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load845, 1
  %.state846 = load i64, ptr %.slot137, align 4
  %.splatinsert847 = insertelement <8 x i64> poison, i64 %.state846, i64 0
  %.splat848 = shufflevector <8 x i64> %.splatinsert847, <8 x i64> poison, <8 x i32> zeroinitializer
  %1908 = mul <8 x i64> %.splat848, splat (i64 32)
  %1909 = add <8 x i64> %1907, %1908
  %1910 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1906, 0
  %1911 = insertvalue { <8 x ptr>, <8 x i64> } %1910, <8 x i64> %1909, 1
  %1912 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1913 = extractvalue { <8 x ptr>, <8 x i64> } %1911, 1
  %1914 = extractelement <8 x ptr> %1912, i32 0
  %1915 = extractelement <8 x i64> %1913, i32 0
  %1916 = sub i64 %1915, 0
  %1917 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1918 = select i1 %1917, i64 %1916, i64 0
  %private.contiguous.address849 = getelementptr i8, ptr %1914, i64 %1918
  %private.contiguous.preserve850 = load <8 x float>, ptr %private.contiguous.address849, align 4
  %1919 = select <8 x i1> %71, <8 x float> %1905, <8 x float> %private.contiguous.preserve850
  store <8 x float> %1919, ptr %private.contiguous.address849, align 4
  %.state851 = load i64, ptr %.slot137, align 4
  %1920 = add i64 %.state851, 1
  store i64 %1920, ptr %.slot137, align 4
  br label %direct.schedule.73

direct.schedule.75:                               ; preds = %direct.false726
  store i64 0, ptr %.slot138, align 4
  br label %direct.schedule.76

direct.schedule.76:                               ; preds = %direct.schedule.77, %direct.schedule.75
  %.state852 = load i64, ptr %.slot138, align 4
  %1921 = icmp slt i64 %.state852, 96
  br i1 %1921, label %direct.true853, label %direct.false854

direct.schedule.77:                               ; preds = %direct.true853
  %tile_snapshot.spill.load855 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill136, align 64
  %1922 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load855, 0
  %1923 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load855, 1
  %.state856 = load i64, ptr %.slot138, align 4
  %.splatinsert857 = insertelement <8 x i64> poison, i64 %.state856, i64 0
  %.splat858 = shufflevector <8 x i64> %.splatinsert857, <8 x i64> poison, <8 x i32> zeroinitializer
  %1924 = mul <8 x i64> %.splat858, splat (i64 32)
  %1925 = add <8 x i64> %1923, %1924
  %1926 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1922, 0
  %1927 = insertvalue { <8 x ptr>, <8 x i64> } %1926, <8 x i64> %1925, 1
  %1928 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1929 = extractvalue { <8 x ptr>, <8 x i64> } %1927, 1
  %1930 = extractelement <8 x ptr> %1928, i32 0
  %1931 = extractelement <8 x i64> %1929, i32 0
  %1932 = sub i64 %1931, 0
  %1933 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1934 = select i1 %1933, i64 %1932, i64 0
  %private.contiguous.address859 = getelementptr i8, ptr %1930, i64 %1934
  %private.contiguous.load860 = load <8 x float>, ptr %private.contiguous.address859, align 4
  %1935 = select <8 x i1> %71, <8 x float> %private.contiguous.load860, <8 x float> zeroinitializer
  %tile_snapshot.spill.load861 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1936 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load861, 0
  %1937 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load861, 1
  %.state862 = load i64, ptr %.slot138, align 4
  %.splatinsert863 = insertelement <8 x i64> poison, i64 %.state862, i64 0
  %.splat864 = shufflevector <8 x i64> %.splatinsert863, <8 x i64> poison, <8 x i32> zeroinitializer
  %1938 = mul <8 x i64> %.splat864, splat (i64 32)
  %1939 = add <8 x i64> %1937, %1938
  %1940 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1936, 0
  %1941 = insertvalue { <8 x ptr>, <8 x i64> } %1940, <8 x i64> %1939, 1
  %1942 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1943 = extractvalue { <8 x ptr>, <8 x i64> } %1941, 1
  %1944 = extractelement <8 x ptr> %1942, i32 0
  %1945 = extractelement <8 x i64> %1943, i32 0
  %1946 = sub i64 %1945, 0
  %1947 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1948 = select i1 %1947, i64 %1946, i64 0
  %private.contiguous.address865 = getelementptr i8, ptr %1944, i64 %1948
  %private.contiguous.preserve866 = load <8 x float>, ptr %private.contiguous.address865, align 4
  %1949 = select <8 x i1> %71, <8 x float> %1935, <8 x float> %private.contiguous.preserve866
  store <8 x float> %1949, ptr %private.contiguous.address865, align 4
  %.state867 = load i64, ptr %.slot138, align 4
  %1950 = add i64 %.state867, 1
  store i64 %1950, ptr %.slot138, align 4
  br label %direct.schedule.76

direct.schedule.78:                               ; preds = %direct.false854
  store i64 0, ptr %.slot139, align 4
  br label %direct.schedule.79

direct.schedule.79:                               ; preds = %direct.schedule.80, %direct.schedule.78
  %.state868 = load i64, ptr %.slot139, align 4
  %1951 = icmp slt i64 %.state868, 96
  br i1 %1951, label %direct.true869, label %direct.false870

direct.schedule.80:                               ; preds = %direct.true869
  %tile_snapshot.spill.load871 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1952 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load871, 0
  %1953 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load871, 1
  %.state872 = load i64, ptr %.slot139, align 4
  %.splatinsert873 = insertelement <8 x i64> poison, i64 %.state872, i64 0
  %.splat874 = shufflevector <8 x i64> %.splatinsert873, <8 x i64> poison, <8 x i32> zeroinitializer
  %1954 = mul <8 x i64> %.splat874, splat (i64 32)
  %1955 = add <8 x i64> %1953, %1954
  %1956 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1952, 0
  %1957 = insertvalue { <8 x ptr>, <8 x i64> } %1956, <8 x i64> %1955, 1
  %1958 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1959 = extractvalue { <8 x ptr>, <8 x i64> } %1957, 1
  %1960 = extractelement <8 x ptr> %1958, i32 0
  %1961 = extractelement <8 x i64> %1959, i32 0
  %1962 = sub i64 %1961, 0
  %1963 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1964 = select i1 %1963, i64 %1962, i64 0
  %private.contiguous.address875 = getelementptr i8, ptr %1960, i64 %1964
  %private.contiguous.load876 = load <8 x float>, ptr %private.contiguous.address875, align 4
  %1965 = select <8 x i1> %71, <8 x float> %private.contiguous.load876, <8 x float> zeroinitializer
  %tile_snapshot.spill.load877 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1966 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load877, 0
  %1967 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load877, 1
  %.state878 = load i64, ptr %.slot139, align 4
  %.splatinsert879 = insertelement <8 x i64> poison, i64 %.state878, i64 0
  %.splat880 = shufflevector <8 x i64> %.splatinsert879, <8 x i64> poison, <8 x i32> zeroinitializer
  %1968 = mul <8 x i64> %.splat880, splat (i64 32)
  %1969 = add <8 x i64> %1967, %1968
  %1970 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1966, 0
  %1971 = insertvalue { <8 x ptr>, <8 x i64> } %1970, <8 x i64> %1969, 1
  %1972 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1973 = extractvalue { <8 x ptr>, <8 x i64> } %1971, 1
  %1974 = extractelement <8 x ptr> %1972, i32 0
  %1975 = extractelement <8 x i64> %1973, i32 0
  %1976 = sub i64 %1975, 0
  %1977 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1978 = select i1 %1977, i64 %1976, i64 0
  %private.contiguous.address881 = getelementptr i8, ptr %1974, i64 %1978
  %private.contiguous.preserve882 = load <8 x float>, ptr %private.contiguous.address881, align 4
  %1979 = select <8 x i1> %71, <8 x float> %1965, <8 x float> %private.contiguous.preserve882
  store <8 x float> %1979, ptr %private.contiguous.address881, align 4
  %.state883 = load i64, ptr %.slot139, align 4
  %1980 = add i64 %.state883, 1
  store i64 %1980, ptr %.slot139, align 4
  br label %direct.schedule.79

direct.schedule.81:                               ; preds = %direct.false870
  %.state884 = load i64, ptr %.slot34, align 4
  %1981 = add i64 %.state884, 1
  %.spill.load885 = load <8 x float>, ptr %.spill113, align 32
  %.spill.load886 = load <8 x float>, ptr %.spill135, align 32
  store i64 %1981, ptr %.slot34, align 4
  %1982 = load <8 x float>, ptr %.slot35, align 32
  %1983 = select <8 x i1> %71, <8 x float> %.spill.load885, <8 x float> %1982
  store <8 x float> %1983, ptr %.slot35, align 32
  %1984 = load <8 x float>, ptr %.slot36, align 32
  %1985 = select <8 x i1> %71, <8 x float> %.spill.load886, <8 x float> %1984
  store <8 x float> %1985, ptr %.slot36, align 32
  br label %direct.schedule.7

direct.schedule.82:                               ; preds = %direct.false171
  store i64 0, ptr %.slot140, align 4
  br label %direct.schedule.83

direct.schedule.83:                               ; preds = %direct.schedule.84, %direct.schedule.82
  %.state887 = load i64, ptr %.slot140, align 4
  %1986 = icmp slt i64 %.state887, 96
  br i1 %1986, label %direct.true888, label %direct.false889

direct.schedule.84:                               ; preds = %direct.true888
  %.spill.load890 = load <8 x i64>, ptr %.spill, align 64
  %1987 = add <8 x i64> %.spill.load890, zeroinitializer
  %1988 = add <8 x i64> zeroinitializer, %1987
  %.spill.load891 = load <8 x i64>, ptr %.spill29, align 64
  %1989 = add <8 x i64> %.spill.load891, zeroinitializer
  %1990 = mul <8 x i64> %1988, splat (i64 3)
  %1991 = add <8 x i64> %1990, %1989
  %.state892 = load i64, ptr %.slot140, align 4
  %1992 = add i64 0, %.state892
  %1993 = mul <8 x i64> %1991, splat (i64 96)
  %.splatinsert893 = insertelement <8 x i64> poison, i64 %1992, i64 0
  %.splat894 = shufflevector <8 x i64> %.splatinsert893, <8 x i64> poison, <8 x i32> zeroinitializer
  %1994 = add <8 x i64> %1993, %.splat894
  %.state895 = load i64, ptr %.slot140, align 4
  %1995 = add i64 0, %.state895
  %tile_snapshot.spill.load896 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1996 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load896, 0
  %1997 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load896, 1
  %.splatinsert897 = insertelement <8 x i64> poison, i64 %1995, i64 0
  %.splat898 = shufflevector <8 x i64> %.splatinsert897, <8 x i64> poison, <8 x i32> zeroinitializer
  %1998 = mul <8 x i64> %.splat898, splat (i64 32)
  %1999 = add <8 x i64> %1997, %1998
  %2000 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1996, 0
  %2001 = insertvalue { <8 x ptr>, <8 x i64> } %2000, <8 x i64> %1999, 1
  %2002 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %2003 = extractvalue { <8 x ptr>, <8 x i64> } %2001, 1
  %2004 = extractelement <8 x ptr> %2002, i32 0
  %2005 = extractelement <8 x i64> %2003, i32 0
  %2006 = sub i64 %2005, 0
  %2007 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2008 = select i1 %2007, i64 %2006, i64 0
  %private.contiguous.address899 = getelementptr i8, ptr %2004, i64 %2008
  %private.contiguous.load900 = load <8 x float>, ptr %private.contiguous.address899, align 4
  %2009 = select <8 x i1> %71, <8 x float> %private.contiguous.load900, <8 x float> zeroinitializer
  %.state901 = load <8 x float>, ptr %.slot36, align 32
  %2010 = fdiv <8 x float> %2009, %.state901
  %2011 = extractvalue { ptr, i64 } %47, 0
  %2012 = mul <8 x i64> %1994, splat (i64 4)
  %2013 = getelementptr i8, ptr %2011, <8 x i64> %2012
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %2010, <8 x ptr> align 1 %2013, <8 x i1> %71)
  %.state902 = load i64, ptr %.slot140, align 4
  %2014 = add i64 %.state902, 1
  store i64 %2014, ptr %.slot140, align 4
  br label %direct.schedule.83

direct.schedule.85:                               ; preds = %direct.false889
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true160:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false161:                                  ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true170:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false171:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.82

direct.true174:                                   ; preds = %direct.schedule.9
  br label %direct.schedule.10

direct.false175:                                  ; preds = %direct.schedule.9
  br label %direct.schedule.13

direct.true184:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false185:                                  ; preds = %direct.schedule.10
  %2015 = load <8 x float>, ptr %.slot41, align 32
  %2016 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %2015
  store <8 x float> %2016, ptr %.slot41, align 32
  br label %direct.schedule.12

direct.true196:                                   ; preds = %direct.schedule.14
  br label %direct.schedule.15

direct.false197:                                  ; preds = %direct.schedule.14
  br label %direct.schedule.18

direct.true206:                                   ; preds = %direct.schedule.15
  br label %direct.schedule.16

direct.false207:                                  ; preds = %direct.schedule.15
  %2017 = load <8 x float>, ptr %.slot45, align 32
  %2018 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %2017
  store <8 x float> %2018, ptr %.slot45, align 32
  br label %direct.schedule.17

direct.true218:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false219:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true233:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false234:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24

direct.true250:                                   ; preds = %direct.schedule.25
  br label %direct.schedule.26

direct.false251:                                  ; preds = %direct.schedule.25
  br label %direct.schedule.27

direct.true267:                                   ; preds = %direct.schedule.28
  br label %direct.schedule.29

direct.false268:                                  ; preds = %direct.schedule.28
  br label %direct.schedule.30

direct.true284:                                   ; preds = %direct.schedule.31
  br label %direct.schedule.32

direct.false285:                                  ; preds = %direct.schedule.31
  br label %direct.schedule.33

direct.true301:                                   ; preds = %direct.schedule.34
  br label %direct.schedule.35

direct.false302:                                  ; preds = %direct.schedule.34
  br label %direct.schedule.36

direct.true318:                                   ; preds = %direct.schedule.37
  br label %direct.schedule.38

direct.false319:                                  ; preds = %direct.schedule.37
  br label %direct.schedule.39

direct.true335:                                   ; preds = %direct.schedule.40
  br label %direct.schedule.41

direct.false336:                                  ; preds = %direct.schedule.40
  br label %direct.schedule.42

direct.true352:                                   ; preds = %direct.schedule.43
  br label %direct.schedule.44

direct.false353:                                  ; preds = %direct.schedule.43
  br label %direct.schedule.45

direct.true369:                                   ; preds = %direct.schedule.46
  br label %direct.schedule.47

direct.false370:                                  ; preds = %direct.schedule.46
  br label %direct.schedule.48

direct.true386:                                   ; preds = %direct.schedule.49
  br label %direct.schedule.50

direct.false387:                                  ; preds = %direct.schedule.49
  br label %direct.schedule.51

direct.true403:                                   ; preds = %direct.schedule.52
  br label %direct.schedule.53

direct.false404:                                  ; preds = %direct.schedule.52
  br label %direct.schedule.54

direct.true420:                                   ; preds = %direct.schedule.55
  br label %direct.schedule.56

direct.false421:                                  ; preds = %direct.schedule.55
  br label %direct.schedule.57

direct.true437:                                   ; preds = %direct.schedule.58
  br label %direct.schedule.59

direct.false438:                                  ; preds = %direct.schedule.58
  br label %direct.schedule.60

direct.true454:                                   ; preds = %direct.schedule.61
  br label %direct.schedule.62

direct.false455:                                  ; preds = %direct.schedule.61
  br label %direct.schedule.63

direct.true471:                                   ; preds = %direct.schedule.64
  br label %direct.schedule.65

direct.false472:                                  ; preds = %direct.schedule.64
  br label %direct.schedule.66

direct.true617:                                   ; preds = %direct.schedule.67
  br label %direct.schedule.68

direct.false618:                                  ; preds = %direct.schedule.67
  br label %direct.schedule.69

direct.true712:                                   ; preds = %direct.schedule.70
  br label %direct.schedule.71

direct.false713:                                  ; preds = %direct.schedule.70
  br label %direct.schedule.72

direct.true725:                                   ; preds = %direct.schedule.73
  br label %direct.schedule.74

direct.false726:                                  ; preds = %direct.schedule.73
  br label %direct.schedule.75

direct.true853:                                   ; preds = %direct.schedule.76
  br label %direct.schedule.77

direct.false854:                                  ; preds = %direct.schedule.76
  br label %direct.schedule.78

direct.true869:                                   ; preds = %direct.schedule.79
  br label %direct.schedule.80

direct.false870:                                  ; preds = %direct.schedule.79
  br label %direct.schedule.81

direct.true888:                                   ; preds = %direct.schedule.83
  br label %direct.schedule.84

direct.false889:                                  ; preds = %direct.schedule.83
  br label %direct.schedule.85
}

define internal void @llm_attention.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_attention.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_attention.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(write) }

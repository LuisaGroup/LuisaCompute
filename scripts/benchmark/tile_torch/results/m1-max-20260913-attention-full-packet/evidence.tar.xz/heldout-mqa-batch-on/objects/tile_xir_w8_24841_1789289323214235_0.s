	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention.full_packet
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention.full_packet:             ; @llm_attention.full_packet
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1968
	mov	x8, #0                          ; =0x0
	ldr	x20, [x1, #136]
	ldr	x9, [x0]
	ldr	x10, [x0, #16]
	str	x10, [sp, #376]                 ; 8-byte Spill
	ldr	w10, [x1]
	ldr	w11, [x1, #36]
	add	w10, w11, w10, lsl #5
	ldr	x11, [x0, #32]
	str	x11, [sp, #368]                 ; 8-byte Spill
	ldr	x11, [x0, #48]
	str	x11, [sp, #72]                  ; 8-byte Spill
	dup.4s	v0, w10
Lloh0:
	adrp	x10, lCPI0_0@PAGE
Lloh1:
	ldr	q1, [x10, lCPI0_0@PAGEOFF]
	add.4s	v3, v0, v1
Lloh2:
	adrp	x10, lCPI0_1@PAGE
Lloh3:
	ldr	q1, [x10, lCPI0_1@PAGEOFF]
	add.4s	v2, v0, v1
	ushll2.2d	v1, v2, #0
	ushll2.2d	v0, v3, #0
	stp	q0, q1, [sp, #32]               ; 32-byte Folded Spill
	ushll.2d	v0, v2, #0
	str	q0, [sp, #16]                   ; 16-byte Spill
	ushll.2d	v0, v3, #0
	str	q0, [sp, #80]                   ; 16-byte Spill
	movi.4s	v1, #80
	umull2.2d	v0, v2, v1
	umull2.2d	v1, v3, v1
	movi.2s	v4, #80
	umull.2d	v2, v2, v4
	umull.2d	v3, v3, v4
	dup.2d	v4, x9
LBB0_1:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v5, x8
	add.2d	v6, v5, v0
	add.2d	v7, v5, v2
	add.2d	v16, v5, v1
	add.2d	v5, v5, v3
	shl.2d	v5, v5, #2
	shl.2d	v16, v16, #2
	shl.2d	v7, v7, #2
	shl.2d	v6, v6, #2
	add.2d	v6, v4, v6
	add.2d	v7, v4, v7
	add.2d	v16, v4, v16
	add.2d	v5, v4, v5
	mov.d	x9, v5[1]
	fmov	x10, d5
	mov.d	x11, v16[1]
	fmov	x12, d16
	mov.d	x13, v7[1]
	fmov	x14, d7
	mov.d	x15, v6[1]
	ldr	s5, [x10]
	ld1.s	{ v5 }[1], [x9]
	fmov	x9, d6
	ld1.s	{ v5 }[2], [x12]
	ld1.s	{ v5 }[3], [x11]
	ldr	s6, [x14]
	ld1.s	{ v6 }[1], [x13]
	ld1.s	{ v6 }[2], [x9]
	ld1.s	{ v6 }[3], [x15]
	add	x9, x20, x8, lsl #5
	stp	q5, q6, [x9]
	add	x8, x8, #1
	cmp	x8, #80
	b.ne	LBB0_1
; %bb.2:                                ; %direct.true165.preheader
	add	x8, x20, #2560
	str	x8, [sp, #8]                    ; 8-byte Spill
	add	x0, x20, #2560
	mov	w1, #3072                       ; =0xc00
	bl	_bzero
	mov	x13, #0                         ; =0x0
	mov	w8, #8704                       ; =0x2200
	add	x25, x20, x8
	mov	w8, #49664                      ; =0xc200
	add	x26, x20, x8
	ldr	q0, [sp, #80]                   ; 16-byte Reload
	fmov	x8, d0
	lsr	x8, x8, #3
	mov	w9, #2053                       ; =0x805
	umull	x27, w8, w9
	mov	w8, #62154                      ; =0xf2ca
	movk	w8, #61769, lsl #16
	dup.4s	v1, w8
	add	x8, x20, #24, lsl #12           ; =98304
	add	x10, x8, #512
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #544
	stp	x8, x10, [sp, #352]             ; 16-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x10, x8, #576
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #608
	stp	x8, x10, [sp, #336]             ; 16-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x10, x8, #640
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #672
	stp	x8, x10, [sp, #320]             ; 16-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x10, x8, #704
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #736
	stp	x8, x10, [sp, #304]             ; 16-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x10, x8, #768
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #800
	stp	x8, x10, [sp, #288]             ; 16-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x10, x8, #832
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #864
	stp	x8, x10, [sp, #272]             ; 16-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x10, x8, #896
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #928
	stp	x8, x10, [sp, #256]             ; 16-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x10, x8, #960
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #992
	stp	x8, x10, [sp, #240]             ; 16-byte Folded Spill
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	str	q0, [sp, #224]                  ; 16-byte Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x10, x8, #1024
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1056
	stp	x8, x10, [sp, #208]             ; 16-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x10, x8, #1088
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1120
	stp	x8, x10, [sp, #192]             ; 16-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x10, x8, #1152
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1184
	stp	x8, x10, [sp, #176]             ; 16-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x10, x8, #1216
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1248
	stp	x8, x10, [sp, #160]             ; 16-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x10, x8, #1280
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1312
	stp	x8, x10, [sp, #144]             ; 16-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x10, x8, #1344
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1376
	stp	x8, x10, [sp, #128]             ; 16-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x10, x8, #1408
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1440
	stp	x8, x10, [sp, #112]             ; 16-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x10, x8, #1472
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1504
	stp	x8, x10, [sp, #96]              ; 16-byte Folded Spill
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	mov.16b	v0, v1
	mov	w23, #34304                     ; =0x8600
	movk	w23, #1, lsl #16
	mov	w14, #52429                     ; =0xcccd
	mov	w15, #80                        ; =0x50
	mov	w16, #43691                     ; =0xaaab
	mov	w17, #96                        ; =0x60
	mov	w0, #2560                       ; =0xa00
	movk	w0, #1, lsl #16
	mov	w1, #5632                       ; =0x1600
	movk	w1, #1, lsl #16
	mov	w2, #8704                       ; =0x2200
	movk	w2, #1, lsl #16
	mov	w3, #11776                      ; =0x2e00
	movk	w3, #1, lsl #16
	mov	w4, #14848                      ; =0x3a00
	movk	w4, #1, lsl #16
	mov	w22, #17920                     ; =0x4600
	movk	w22, #1, lsl #16
	mov	w28, #20992                     ; =0x5200
	movk	w28, #1, lsl #16
	mov	w19, #24064                     ; =0x5e00
	movk	w19, #1, lsl #16
	mov	w24, #27136                     ; =0x6a00
	movk	w24, #1, lsl #16
	mov	w21, #30208                     ; =0x7600
	movk	w21, #1, lsl #16
LBB0_3:                                 ; %direct.true175
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_5 Depth 2
                                        ;     Child Loop BB0_9 Depth 2
                                        ;     Child Loop BB0_12 Depth 2
                                        ;     Child Loop BB0_14 Depth 2
                                        ;     Child Loop BB0_16 Depth 2
                                        ;     Child Loop BB0_18 Depth 2
                                        ;     Child Loop BB0_20 Depth 2
                                        ;     Child Loop BB0_22 Depth 2
                                        ;     Child Loop BB0_24 Depth 2
                                        ;     Child Loop BB0_26 Depth 2
                                        ;     Child Loop BB0_28 Depth 2
                                        ;     Child Loop BB0_30 Depth 2
                                        ;     Child Loop BB0_32 Depth 2
                                        ;     Child Loop BB0_34 Depth 2
                                        ;     Child Loop BB0_36 Depth 2
                                        ;     Child Loop BB0_38 Depth 2
                                        ;     Child Loop BB0_40 Depth 2
                                        ;     Child Loop BB0_42 Depth 2
                                        ;     Child Loop BB0_44 Depth 2
	str	q0, [sp, #1888]                 ; 16-byte Spill
	mov	x9, #0                          ; =0x0
	lsl	x8, x13, #4
	ldr	x12, [sp, #376]                 ; 8-byte Reload
	b	LBB0_5
LBB0_4:                                 ; %direct.schedule.12
                                        ;   in Loop: Header=BB0_5 Depth=2
	add	x10, x25, x9, lsl #5
	stp	q0, q0, [x10]
	add	x9, x9, #1
	cmp	x9, #1280
	b.eq	LBB0_7
LBB0_5:                                 ; %direct.true179
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w10, w9, #0xffff
	mul	w10, w10, w14
	lsr	w10, w10, #22
	add	x11, x8, x10
	movi.2d	v0, #0000000000000000
	cmp	x11, #2052
	b.hi	LBB0_4
; %bb.6:                                ; %direct.true190
                                        ;   in Loop: Header=BB0_5 Depth=2
	msub	w10, w10, w15, w9
	add	x11, x11, x27
	mul	x11, x11, x15
	add	x10, x11, w10, uxth
	add	x10, x12, x10, lsl #2
	ld1r.4s	{ v0 }, [x10]
	b	LBB0_4
LBB0_7:                                 ; %direct.true204.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	x12, [sp, #368]                 ; 8-byte Reload
	b	LBB0_9
LBB0_8:                                 ; %direct.schedule.17
                                        ;   in Loop: Header=BB0_9 Depth=2
	add	x10, x26, x9, lsl #5
	stp	q0, q0, [x10]
	add	x9, x9, #1
	cmp	x9, #1536
	b.eq	LBB0_11
LBB0_9:                                 ; %direct.true204
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w10, w9, #0xffff
	mul	w10, w10, w16
	lsr	w10, w10, #22
	add	x11, x8, x10
	movi.2d	v0, #0000000000000000
	cmp	x11, #2052
	b.hi	LBB0_8
; %bb.10:                               ; %direct.true215
                                        ;   in Loop: Header=BB0_9 Depth=2
	msub	w10, w10, w17, w9
	add	x11, x11, x27
	mul	x11, x11, x17
	add	x10, x11, w10, uxth
	add	x10, x12, x10, lsl #2
	ld1r.4s	{ v0 }, [x10]
	b	LBB0_8
LBB0_11:                                ; %direct.true229.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v0, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v6, #0000000000000000
LBB0_12:                                ; %direct.true229
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q3, q2, [x8]
	ldr	q4, [x8, #8720]
	ldr	q5, [x8, #8704]
	fmul.4s	v3, v3, v5
	fmul.4s	v2, v2, v4
	fadd.4s	v0, v0, v2
	fadd.4s	v6, v6, v3
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_12
; %bb.13:                               ; %direct.true244.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	q6, [sp, #1936]                 ; 16-byte Spill
	movi.2d	v2, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v3, #0000000000000000
LBB0_14:                                ; %direct.true244
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q5, q4, [x8]
	ldr	q6, [x8, #11280]
	ldr	q7, [x8, #11264]
	fmul.4s	v5, v5, v7
	fmul.4s	v4, v4, v6
	fadd.4s	v2, v2, v4
	fadd.4s	v3, v3, v5
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_14
; %bb.15:                               ; %direct.true261.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	q19, [sp, #1424]                ; 16-byte Spill
	movi.2d	v4, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v5, #0000000000000000
LBB0_16:                                ; %direct.true261
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q7, q6, [x8]
	ldr	q16, [x8, #13840]
	ldr	q17, [x8, #13824]
	fmul.4s	v7, v7, v17
	fmul.4s	v6, v6, v16
	fadd.4s	v4, v4, v6
	fadd.4s	v5, v5, v7
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_16
; %bb.17:                               ; %direct.true278.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	q20, [sp, #1408]                ; 16-byte Spill
	movi.2d	v6, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v7, #0000000000000000
LBB0_18:                                ; %direct.true278
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q17, q16, [x8]
	ldr	q18, [x8, #16400]
	ldr	q19, [x8, #16384]
	fmul.4s	v17, v17, v19
	fmul.4s	v16, v16, v18
	fadd.4s	v6, v6, v16
	fadd.4s	v7, v7, v17
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_18
; %bb.19:                               ; %direct.true295.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v16, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v17, #0000000000000000
LBB0_20:                                ; %direct.true295
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q19, q18, [x8]
	ldr	q20, [x8, #18960]
	ldr	q21, [x8, #18944]
	fmul.4s	v19, v19, v21
	fmul.4s	v18, v18, v20
	fadd.4s	v16, v16, v18
	fadd.4s	v17, v17, v19
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_20
; %bb.21:                               ; %direct.true312.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v18, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v19, #0000000000000000
LBB0_22:                                ; %direct.true312
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q21, q20, [x8]
	ldr	q22, [x8, #21520]
	ldr	q23, [x8, #21504]
	fmul.4s	v21, v21, v23
	fmul.4s	v20, v20, v22
	fadd.4s	v18, v18, v20
	fadd.4s	v19, v19, v21
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_22
; %bb.23:                               ; %direct.true329.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v20, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v21, #0000000000000000
LBB0_24:                                ; %direct.true329
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q23, q22, [x8]
	ldr	q24, [x8, #24080]
	ldr	q25, [x8, #24064]
	fmul.4s	v23, v23, v25
	fmul.4s	v22, v22, v24
	fadd.4s	v20, v20, v22
	fadd.4s	v21, v21, v23
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_24
; %bb.25:                               ; %direct.true346.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v22, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v23, #0000000000000000
LBB0_26:                                ; %direct.true346
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q25, q24, [x8]
	ldr	q26, [x8, #26640]
	ldr	q27, [x8, #26624]
	fmul.4s	v25, v25, v27
	fmul.4s	v24, v24, v26
	fadd.4s	v22, v22, v24
	fadd.4s	v23, v23, v25
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_26
; %bb.27:                               ; %direct.true363.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v24, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v25, #0000000000000000
LBB0_28:                                ; %direct.true363
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q27, q26, [x8]
	ldr	q28, [x8, #29200]
	ldr	q29, [x8, #29184]
	fmul.4s	v27, v27, v29
	fmul.4s	v26, v26, v28
	fadd.4s	v24, v24, v26
	fadd.4s	v25, v25, v27
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_28
; %bb.29:                               ; %direct.true380.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v26, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v27, #0000000000000000
LBB0_30:                                ; %direct.true380
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q29, q28, [x8]
	ldr	q30, [x8, #31760]
	ldr	q31, [x8, #31744]
	fmul.4s	v29, v29, v31
	fmul.4s	v28, v28, v30
	fadd.4s	v26, v26, v28
	fadd.4s	v27, v27, v29
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_30
; %bb.31:                               ; %direct.true397.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v28, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v29, #0000000000000000
LBB0_32:                                ; %direct.true397
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q31, q30, [x8]
	ldr	q8, [x8, #34320]
	ldr	q9, [x8, #34304]
	fmul.4s	v31, v31, v9
	fmul.4s	v30, v30, v8
	fadd.4s	v28, v28, v30
	fadd.4s	v29, v29, v31
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_32
; %bb.33:                               ; %direct.true414.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v30, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v31, #0000000000000000
LBB0_34:                                ; %direct.true414
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q9, q8, [x8]
	ldr	q10, [x8, #36880]
	ldr	q11, [x8, #36864]
	fmul.4s	v9, v9, v11
	fmul.4s	v8, v8, v10
	fadd.4s	v30, v30, v8
	fadd.4s	v31, v31, v9
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_34
; %bb.35:                               ; %direct.true431.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v8, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v9, #0000000000000000
LBB0_36:                                ; %direct.true431
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q11, q10, [x8]
	ldr	q12, [x8, #39440]
	ldr	q13, [x8, #39424]
	fmul.4s	v11, v11, v13
	fmul.4s	v10, v10, v12
	fadd.4s	v8, v8, v10
	fadd.4s	v9, v9, v11
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_36
; %bb.37:                               ; %direct.true448.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	q3, [sp, #1872]                 ; 16-byte Spill
	str	q2, [sp, #1920]                 ; 16-byte Spill
	str	q0, [sp, #1952]                 ; 16-byte Spill
	str	q1, [sp, #1904]                 ; 16-byte Spill
	movi.2d	v10, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v11, #0000000000000000
LBB0_38:                                ; %direct.true448
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q13, q12, [x8]
	ldr	q14, [x8, #42000]
	ldr	q15, [x8, #41984]
	fmul.4s	v13, v13, v15
	fmul.4s	v12, v12, v14
	fadd.4s	v10, v10, v12
	fadd.4s	v11, v11, v13
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_38
; %bb.39:                               ; %direct.true465.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v12, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v13, #0000000000000000
LBB0_40:                                ; %direct.true465
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q15, q14, [x8]
	ldr	q0, [x8, #44560]
	ldr	q1, [x8, #44544]
	fmul.4s	v1, v15, v1
	fmul.4s	v0, v14, v0
	fadd.4s	v12, v12, v0
	fadd.4s	v13, v13, v1
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_40
; %bb.41:                               ; %direct.true482.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v14, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v15, #0000000000000000
LBB0_42:                                ; %direct.true482
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q1, q0, [x8]
	ldr	q2, [x8, #47120]
	ldr	q3, [x8, #47104]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v14, v14, v0
	fadd.4s	v15, v15, v1
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_42
; %bb.43:                               ; %direct.false483
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	w8, #63790                      ; =0xf92e
	movk	w8, #15844, lsl #16
	dup.4s	v0, w8
	ldr	q1, [sp, #1936]                 ; 16-byte Reload
	fmul.4s	v1, v1, v0
	str	q1, [sp, #1712]                 ; 16-byte Spill
	ldr	q1, [sp, #1952]                 ; 16-byte Reload
	fmul.4s	v1, v1, v0
	str	q1, [sp, #1536]                 ; 16-byte Spill
	ldr	q1, [sp, #1872]                 ; 16-byte Reload
	fmul.4s	v1, v1, v0
	str	q1, [sp, #1520]                 ; 16-byte Spill
	ldr	q1, [sp, #1920]                 ; 16-byte Reload
	fmul.4s	v1, v1, v0
	str	q1, [sp, #1504]                 ; 16-byte Spill
	fmul.4s	v1, v5, v0
	str	q1, [sp, #1488]                 ; 16-byte Spill
	fmul.4s	v1, v4, v0
	str	q1, [sp, #1472]                 ; 16-byte Spill
	fmul.4s	v1, v7, v0
	str	q1, [sp, #1952]                 ; 16-byte Spill
	fmul.4s	v1, v6, v0
	str	q1, [sp, #1456]                 ; 16-byte Spill
	fmul.4s	v1, v17, v0
	str	q1, [sp, #1936]                 ; 16-byte Spill
	fmul.4s	v1, v16, v0
	str	q1, [sp, #1920]                 ; 16-byte Spill
	fmul.4s	v1, v18, v0
	fmul.4s	v3, v19, v0
	fmul.4s	v4, v20, v0
	fmul.4s	v5, v21, v0
	fmul.4s	v6, v22, v0
	fmul.4s	v7, v23, v0
	fmul.4s	v16, v24, v0
	fmul.4s	v17, v25, v0
	fmul.4s	v18, v26, v0
	fmul.4s	v19, v27, v0
	fmul.4s	v20, v28, v0
	fmul.4s	v21, v29, v0
	fmul.4s	v22, v30, v0
	fmul.4s	v23, v31, v0
	fmul.4s	v24, v8, v0
	fmul.4s	v25, v9, v0
	fmul.4s	v26, v10, v0
	fmul.4s	v27, v11, v0
	fmul.4s	v28, v12, v0
	fmul.4s	v29, v13, v0
	fmul.4s	v30, v14, v0
	fmul.4s	v0, v15, v0
	str	x13, [sp, #1448]                ; 8-byte Spill
	cmp	x13, #128
	cset	w8, lo
	dup.4h	v2, w8
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v8, v2, #0
	str	q8, [sp, #448]                  ; 16-byte Spill
	mov	w8, #62154                      ; =0xf2ca
	movk	w8, #61769, lsl #16
	dup.4s	v31, w8
	mov.16b	v2, v8
	bsl.16b	v2, v3, v31
	str	q2, [sp, #1872]                 ; 16-byte Spill
	mov.16b	v11, v8
	bsl.16b	v11, v1, v31
	mov.16b	v3, v8
	bsl.16b	v3, v5, v31
	str	q3, [sp, #1792]                 ; 16-byte Spill
	mov.16b	v10, v8
	bsl.16b	v10, v4, v31
	str	q10, [sp, #1552]                ; 16-byte Spill
	mov.16b	v4, v8
	bsl.16b	v4, v7, v31
	str	q4, [sp, #1856]                 ; 16-byte Spill
	mov.16b	v9, v8
	bsl.16b	v9, v6, v31
	str	q9, [sp, #1568]                 ; 16-byte Spill
	mov.16b	v6, v8
	bsl.16b	v6, v17, v31
	str	q6, [sp, #1776]                 ; 16-byte Spill
	bif.16b	v16, v31, v8
	str	q16, [sp, #1584]                ; 16-byte Spill
	mov.16b	v7, v8
	bsl.16b	v7, v19, v31
	str	q7, [sp, #1840]                 ; 16-byte Spill
	bif.16b	v18, v31, v8
	str	q18, [sp, #1600]                ; 16-byte Spill
	mov.16b	v17, v8
	bsl.16b	v17, v21, v31
	str	q17, [sp, #1760]                ; 16-byte Spill
	bif.16b	v20, v31, v8
	str	q20, [sp, #1616]                ; 16-byte Spill
	mov.16b	v19, v8
	bsl.16b	v19, v23, v31
	str	q19, [sp, #1824]                ; 16-byte Spill
	bif.16b	v22, v31, v8
	str	q22, [sp, #1632]                ; 16-byte Spill
	mov.16b	v21, v8
	bsl.16b	v21, v25, v31
	str	q21, [sp, #1744]                ; 16-byte Spill
	bif.16b	v24, v31, v8
	str	q24, [sp, #1648]                ; 16-byte Spill
	mov.16b	v23, v8
	bsl.16b	v23, v27, v31
	str	q23, [sp, #1808]                ; 16-byte Spill
	mov.16b	v27, v8
	bsl.16b	v27, v26, v31
	str	q27, [sp, #1664]                ; 16-byte Spill
	mov.16b	v25, v8
	bsl.16b	v25, v29, v31
	str	q25, [sp, #1728]                ; 16-byte Spill
	mov.16b	v5, v8
	bsl.16b	v5, v28, v31
	str	q5, [sp, #1680]                 ; 16-byte Spill
	mov.16b	v12, v8
	bsl.16b	v12, v0, v31
	str	q12, [sp, #1232]                ; 16-byte Spill
	bit.16b	v31, v30, v8
	str	q31, [sp, #1696]                ; 16-byte Spill
	mvni.4s	v26, #127, msl #16
	ldr	q1, [sp, #1712]                 ; 16-byte Reload
	fmaxnm.4s	v0, v1, v26
	ldr	q28, [sp, #1520]                ; 16-byte Reload
	fmaxnm.4s	v0, v0, v28
	ldr	q29, [sp, #1488]                ; 16-byte Reload
	fmaxnm.4s	v0, v0, v29
	ldr	q30, [sp, #1952]                ; 16-byte Reload
	fmaxnm.4s	v0, v0, v30
	ldr	q30, [sp, #1936]                ; 16-byte Reload
	fmaxnm.4s	v0, v0, v30
	fmaxnm.4s	v0, v0, v2
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v0, v0, v4
	fmaxnm.4s	v0, v0, v6
	fmaxnm.4s	v0, v0, v7
	fmaxnm.4s	v0, v0, v17
	fmaxnm.4s	v0, v0, v19
	fmaxnm.4s	v0, v0, v21
	fmaxnm.4s	v0, v0, v23
	fmaxnm.4s	v0, v0, v25
	fmaxnm.4s	v0, v0, v12
	ldr	q2, [sp, #1904]                 ; 16-byte Reload
	fmaxnm.4s	v12, v2, v0
	fsub.4s	v2, v1, v12
	mov	w8, #-1026555904                ; =0xc2d00000
	dup.4s	v7, w8
	fcmge.4s	v0, v2, v7
	mov	w8, #1120403456                 ; =0x42c80000
	dup.4s	v6, w8
	fcmge.4s	v1, v6, v2
	and.16b	v0, v0, v1
	ldr	q3, [sp, #1536]                 ; 16-byte Reload
	fmaxnm.4s	v1, v3, v26
	ldr	q13, [sp, #1504]                ; 16-byte Reload
	fmaxnm.4s	v1, v1, v13
	ldr	q14, [sp, #1472]                ; 16-byte Reload
	fmaxnm.4s	v1, v1, v14
	ldr	q15, [sp, #1456]                ; 16-byte Reload
	fmaxnm.4s	v1, v1, v15
	ldr	q4, [sp, #1920]                 ; 16-byte Reload
	fmaxnm.4s	v1, v1, v4
	fmaxnm.4s	v1, v1, v11
	str	q11, [sp, #1024]                ; 16-byte Spill
	fmaxnm.4s	v1, v1, v10
	fmaxnm.4s	v1, v1, v9
	fmaxnm.4s	v1, v1, v16
	fmaxnm.4s	v1, v1, v18
	fmaxnm.4s	v1, v1, v20
	fmaxnm.4s	v1, v1, v22
	fmaxnm.4s	v1, v1, v24
	fmaxnm.4s	v1, v1, v27
	fmaxnm.4s	v1, v1, v5
	fmaxnm.4s	v1, v1, v31
	ldr	q4, [sp, #1888]                 ; 16-byte Reload
	fmaxnm.4s	v30, v4, v1
	fsub.4s	v10, v3, v30
	fcmge.4s	v1, v10, v7
	fcmge.4s	v3, v6, v10
	and.16b	v1, v1, v3
	and.16b	v1, v1, v10
	mov	w8, #43579                      ; =0xaa3b
	movk	w8, #16312, lsl #16
	dup.4s	v18, w8
	fmul.4s	v3, v1, v18
	movi.4s	v5, #75, lsl #24
	mvni.4s	v16, #128, lsl #24
	mov.16b	v4, v16
	bsl.16b	v4, v5, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v2
	fmul.4s	v0, v4, v18
	bif.16b	v5, v0, v16
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	mov	w8, #29184                      ; =0x7200
	movk	w8, #16177, lsl #16
	dup.4s	v19, w8
	fmul.4s	v16, v3, v19
	fsub.4s	v16, v1, v16
	fcvtzs.4s	v1, v5
	scvtf.4s	v5, v1
	fmul.4s	v17, v5, v19
	mov	w8, #48782                      ; =0xbe8e
	movk	w8, #13759, lsl #16
	dup.4s	v20, w8
	fsub.4s	v4, v4, v17
	fmul.4s	v5, v5, v20
	fsub.4s	v4, v4, v5
	fmul.4s	v3, v3, v20
	mov	w8, #11226                      ; =0x2bda
	movk	w8, #14672, lsl #16
	dup.4s	v21, w8
	fsub.4s	v3, v16, v3
	fmul.4s	v5, v3, v21
	mov	w8, #38601                      ; =0x96c9
	movk	w8, #15030, lsl #16
	dup.4s	v22, w8
	fadd.4s	v5, v5, v22
	fmul.4s	v5, v3, v5
	mov	w8, #34982                      ; =0x88a6
	movk	w8, #15368, lsl #16
	dup.4s	v27, w8
	fadd.4s	v5, v5, v27
	fmul.4s	v5, v3, v5
	mov	w8, #43642                      ; =0xaa7a
	movk	w8, #15658, lsl #16
	dup.4s	v23, w8
	fadd.4s	v5, v5, v23
	fmul.4s	v5, v3, v5
	mov	w8, #43691                      ; =0xaaab
	movk	w8, #15914, lsl #16
	dup.4s	v25, w8
	fadd.4s	v5, v5, v25
	fmul.4s	v5, v3, v5
	movi.4s	v31, #63, lsl #24
	fadd.4s	v5, v5, v31
	fmul.4s	v16, v3, v3
	fmul.4s	v5, v16, v5
	fmul.4s	v16, v4, v21
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v27
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v23
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v25
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v31
	fmul.4s	v17, v4, v4
	fmul.4s	v16, v17, v16
	fadd.4s	v4, v4, v16
	fadd.4s	v3, v3, v5
	fmov.4s	v24, #1.00000000
	fadd.4s	v4, v4, v24
	sshr.4s	v5, v1, #1
	shl.4s	v16, v5, #23
	add.4s	v16, v16, v24
	fmul.4s	v4, v4, v16
	fadd.4s	v3, v3, v24
	sshr.4s	v16, v0, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v24
	fmul.4s	v3, v3, v17
	sub.4s	v1, v1, v5
	sub.4s	v0, v0, v16
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v3, v0
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v4, v1
	str	q2, [sp, #1312]                 ; 16-byte Spill
	fcmgt.4s	v3, v7, v2
	bic.16b	v1, v1, v3
	str	q10, [sp, #1360]                ; 16-byte Spill
	fcmgt.4s	v3, v7, v10
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v10, v6
	fneg.4s	v26, v26
	bit.16b	v0, v26, v3
	str	q0, [sp, #1344]                 ; 16-byte Spill
	fcmgt.4s	v0, v2, v6
	bsl.16b	v0, v26, v1
	str	q0, [sp, #1328]                 ; 16-byte Spill
	fsub.4s	v28, v28, v12
	fcmge.4s	v0, v28, v7
	fcmge.4s	v1, v6, v28
	and.16b	v0, v0, v1
	fsub.4s	v10, v13, v30
	fcmge.4s	v1, v10, v7
	fcmge.4s	v3, v6, v10
	and.16b	v1, v1, v3
	and.16b	v1, v1, v10
	fmul.4s	v3, v1, v18
	movi.4s	v2, #75, lsl #24
	mvni.4s	v5, #128, lsl #24
	mov.16b	v4, v5
	bsl.16b	v4, v2, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v28
	fmul.4s	v0, v4, v18
	bsl.16b	v5, v2, v0
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	fmul.4s	v16, v3, v19
	fsub.4s	v1, v1, v16
	fcvtzs.4s	v5, v5
	scvtf.4s	v16, v5
	fmul.4s	v17, v16, v19
	fsub.4s	v4, v4, v17
	fmul.4s	v16, v16, v20
	fsub.4s	v4, v4, v16
	fmul.4s	v3, v3, v20
	fsub.4s	v1, v1, v3
	fmul.4s	v3, v1, v21
	fadd.4s	v3, v3, v22
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v27
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v25
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v31
	fmul.4s	v16, v1, v1
	fmul.4s	v3, v16, v3
	fmul.4s	v16, v4, v21
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v27
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v23
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v25
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v31
	fmul.4s	v17, v4, v4
	fmul.4s	v16, v17, v16
	fadd.4s	v4, v4, v16
	fadd.4s	v1, v1, v3
	fadd.4s	v3, v4, v24
	sshr.4s	v4, v5, #1
	shl.4s	v16, v4, #23
	add.4s	v16, v16, v24
	fmul.4s	v3, v3, v16
	fadd.4s	v1, v1, v24
	sshr.4s	v16, v0, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v24
	fmul.4s	v1, v1, v17
	sub.4s	v4, v5, v4
	sub.4s	v0, v0, v16
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v3, v1
	str	q28, [sp, #1248]                ; 16-byte Spill
	fcmgt.4s	v3, v7, v28
	bic.16b	v1, v1, v3
	str	q10, [sp, #1280]                ; 16-byte Spill
	fcmgt.4s	v3, v7, v10
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v10, v6
	bit.16b	v0, v26, v3
	str	q0, [sp, #1296]                 ; 16-byte Spill
	fcmgt.4s	v0, v28, v6
	bsl.16b	v0, v26, v1
	str	q0, [sp, #1264]                 ; 16-byte Spill
	fsub.4s	v28, v29, v12
	fcmge.4s	v0, v28, v7
	fcmge.4s	v1, v6, v28
	and.16b	v0, v0, v1
	fsub.4s	v2, v14, v30
	fcmge.4s	v1, v2, v7
	fcmge.4s	v3, v6, v2
	and.16b	v1, v1, v3
	and.16b	v1, v1, v2
	fmul.4s	v3, v1, v18
	movi.4s	v5, #75, lsl #24
	mvni.4s	v16, #128, lsl #24
	mov.16b	v4, v16
	bsl.16b	v4, v5, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v28
	fmul.4s	v0, v4, v18
	bif.16b	v5, v0, v16
	mvni.4s	v29, #128, lsl #24
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	fmul.4s	v16, v3, v19
	fsub.4s	v1, v1, v16
	fcvtzs.4s	v5, v5
	scvtf.4s	v16, v5
	fmul.4s	v17, v16, v19
	fsub.4s	v4, v4, v17
	fmul.4s	v16, v16, v20
	fsub.4s	v4, v4, v16
	fmul.4s	v3, v3, v20
	fsub.4s	v1, v1, v3
	fmul.4s	v3, v1, v21
	fadd.4s	v3, v3, v22
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v27
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v25
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v31
	fmul.4s	v16, v1, v1
	fmul.4s	v3, v16, v3
	fmul.4s	v16, v4, v21
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v27
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v23
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v25
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v31
	fmul.4s	v17, v4, v4
	fmul.4s	v16, v17, v16
	fadd.4s	v4, v4, v16
	fadd.4s	v1, v1, v3
	fadd.4s	v3, v4, v24
	sshr.4s	v4, v5, #1
	shl.4s	v16, v4, #23
	add.4s	v16, v16, v24
	fmul.4s	v3, v3, v16
	fadd.4s	v1, v1, v24
	sshr.4s	v16, v0, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v24
	fmul.4s	v1, v1, v17
	sub.4s	v4, v5, v4
	sub.4s	v0, v0, v16
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v3, v1
	str	q28, [sp, #1168]                ; 16-byte Spill
	fcmgt.4s	v3, v7, v28
	bic.16b	v1, v1, v3
	str	q2, [sp, #1200]                 ; 16-byte Spill
	fcmgt.4s	v3, v7, v2
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v2, v6
	bit.16b	v0, v26, v3
	str	q0, [sp, #1216]                 ; 16-byte Spill
	fcmgt.4s	v0, v28, v6
	bsl.16b	v0, v26, v1
	str	q0, [sp, #1184]                 ; 16-byte Spill
	ldr	q0, [sp, #1952]                 ; 16-byte Reload
	fsub.4s	v28, v0, v12
	fcmge.4s	v0, v28, v7
	fcmge.4s	v1, v6, v28
	and.16b	v0, v0, v1
	fsub.4s	v2, v15, v30
	fcmge.4s	v1, v2, v7
	fcmge.4s	v3, v6, v2
	and.16b	v1, v1, v3
	and.16b	v1, v1, v2
	fmul.4s	v3, v1, v18
	movi.4s	v5, #75, lsl #24
	mov.16b	v4, v29
	bsl.16b	v4, v5, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v28
	fmul.4s	v0, v4, v18
	bif.16b	v5, v0, v29
	movi.4s	v9, #75, lsl #24
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	fmul.4s	v16, v3, v19
	fsub.4s	v1, v1, v16
	fcvtzs.4s	v5, v5
	scvtf.4s	v16, v5
	fmul.4s	v17, v16, v19
	fsub.4s	v4, v4, v17
	fmul.4s	v16, v16, v20
	fsub.4s	v4, v4, v16
	fmul.4s	v3, v3, v20
	fsub.4s	v1, v1, v3
	fmul.4s	v3, v1, v21
	fadd.4s	v3, v3, v22
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v27
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v25
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v31
	fmul.4s	v16, v1, v1
	fmul.4s	v3, v16, v3
	fmul.4s	v16, v4, v21
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v27
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v23
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v25
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v31
	fmul.4s	v17, v4, v4
	fmul.4s	v16, v17, v16
	fadd.4s	v4, v4, v16
	fadd.4s	v1, v1, v3
	fadd.4s	v3, v4, v24
	sshr.4s	v4, v5, #1
	shl.4s	v16, v4, #23
	add.4s	v16, v16, v24
	fmul.4s	v3, v3, v16
	fadd.4s	v1, v1, v24
	sshr.4s	v16, v0, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v24
	fmul.4s	v1, v1, v17
	sub.4s	v4, v5, v4
	sub.4s	v0, v0, v16
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v3, v1
	str	q28, [sp, #1104]                ; 16-byte Spill
	fcmgt.4s	v3, v7, v28
	bic.16b	v1, v1, v3
	str	q2, [sp, #1136]                 ; 16-byte Spill
	fcmgt.4s	v3, v7, v2
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v2, v6
	bit.16b	v0, v26, v3
	str	q0, [sp, #1152]                 ; 16-byte Spill
	fcmgt.4s	v0, v28, v6
	bsl.16b	v0, v26, v1
	str	q0, [sp, #1120]                 ; 16-byte Spill
	ldr	q0, [sp, #1936]                 ; 16-byte Reload
	fsub.4s	v28, v0, v12
	fcmge.4s	v0, v28, v7
	fcmge.4s	v1, v6, v28
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1920]                 ; 16-byte Reload
	fsub.4s	v2, v1, v30
	fcmge.4s	v1, v2, v7
	fcmge.4s	v3, v6, v2
	and.16b	v1, v1, v3
	and.16b	v1, v1, v2
	fmul.4s	v3, v1, v18
	mov.16b	v4, v29
	bsl.16b	v4, v9, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v28
	fmul.4s	v0, v4, v18
	mov.16b	v5, v29
	bsl.16b	v5, v9, v0
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	fmul.4s	v16, v3, v19
	fsub.4s	v1, v1, v16
	fcvtzs.4s	v5, v5
	scvtf.4s	v16, v5
	fmul.4s	v17, v16, v19
	fsub.4s	v4, v4, v17
	fmul.4s	v16, v16, v20
	fsub.4s	v4, v4, v16
	fmul.4s	v3, v3, v20
	fsub.4s	v1, v1, v3
	fmul.4s	v3, v1, v21
	fadd.4s	v3, v3, v22
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v27
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v25
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v31
	fmul.4s	v16, v1, v1
	fmul.4s	v3, v16, v3
	fmul.4s	v16, v4, v21
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v27
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v23
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v25
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v31
	fmul.4s	v17, v4, v4
	fmul.4s	v16, v17, v16
	fadd.4s	v4, v4, v16
	fadd.4s	v1, v1, v3
	fadd.4s	v3, v4, v24
	sshr.4s	v4, v5, #1
	shl.4s	v16, v4, #23
	add.4s	v16, v16, v24
	fmul.4s	v3, v3, v16
	fadd.4s	v1, v1, v24
	sshr.4s	v16, v0, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v24
	fmul.4s	v1, v1, v17
	sub.4s	v4, v5, v4
	sub.4s	v0, v0, v16
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v3, v1
	str	q28, [sp, #1040]                ; 16-byte Spill
	fcmgt.4s	v3, v7, v28
	bic.16b	v1, v1, v3
	str	q2, [sp, #1072]                 ; 16-byte Spill
	fcmgt.4s	v3, v7, v2
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v2, v6
	bit.16b	v0, v26, v3
	str	q0, [sp, #1088]                 ; 16-byte Spill
	fcmgt.4s	v0, v28, v6
	bsl.16b	v0, v26, v1
	str	q0, [sp, #1056]                 ; 16-byte Spill
	fsub.4s	v28, v11, v30
	fcmge.4s	v0, v28, v7
	fcmge.4s	v1, v6, v28
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1872]                 ; 16-byte Reload
	mov.16b	v9, v12
	fsub.4s	v29, v1, v12
	fcmge.4s	v1, v29, v7
	fcmge.4s	v3, v6, v29
	and.16b	v1, v1, v3
	and.16b	v1, v1, v29
	fmul.4s	v3, v1, v18
	mvni.4s	v2, #128, lsl #24
	movi.4s	v5, #75, lsl #24
	mov.16b	v4, v2
	bsl.16b	v4, v5, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v28
	fmul.4s	v0, v4, v18
	bif.16b	v5, v0, v2
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	fmul.4s	v16, v3, v19
	fsub.4s	v1, v1, v16
	fcvtzs.4s	v5, v5
	scvtf.4s	v16, v5
	fmul.4s	v17, v16, v19
	fsub.4s	v4, v4, v17
	fmul.4s	v16, v16, v20
	fsub.4s	v4, v4, v16
	fmul.4s	v3, v3, v20
	fsub.4s	v1, v1, v3
	fmul.4s	v3, v1, v21
	fadd.4s	v3, v3, v22
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v27
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v25
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v31
	fmul.4s	v16, v1, v1
	fmul.4s	v3, v16, v3
	fmul.4s	v16, v4, v21
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v27
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v23
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v25
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v31
	fmul.4s	v17, v4, v4
	fmul.4s	v16, v17, v16
	fadd.4s	v4, v4, v16
	fadd.4s	v1, v1, v3
	fadd.4s	v3, v4, v24
	sshr.4s	v4, v5, #1
	shl.4s	v16, v4, #23
	add.4s	v16, v16, v24
	fmul.4s	v3, v3, v16
	fadd.4s	v1, v1, v24
	sshr.4s	v16, v0, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v24
	fmul.4s	v1, v1, v17
	sub.4s	v4, v5, v4
	sub.4s	v0, v0, v16
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v3, v1
	fcmgt.4s	v3, v7, v28
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v7, v29
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v29, v6
	bit.16b	v0, v26, v3
	stp	q29, q0, [sp, #992]             ; 32-byte Folded Spill
	fcmgt.4s	v0, v28, v6
	bsl.16b	v0, v26, v1
	stp	q28, q0, [sp, #960]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1552]                 ; 16-byte Reload
	fsub.4s	v28, v0, v30
	fcmge.4s	v0, v28, v7
	fcmge.4s	v1, v6, v28
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1792]                 ; 16-byte Reload
	fsub.4s	v2, v1, v12
	fcmge.4s	v1, v2, v7
	fcmge.4s	v3, v6, v2
	and.16b	v1, v1, v3
	and.16b	v1, v1, v2
	fmul.4s	v3, v1, v18
	movi.4s	v5, #75, lsl #24
	mvni.4s	v16, #128, lsl #24
	mov.16b	v4, v16
	bsl.16b	v4, v5, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v28
	fmul.4s	v0, v4, v18
	bif.16b	v5, v0, v16
	mvni.4s	v29, #128, lsl #24
	movi.4s	v10, #75, lsl #24
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	fmul.4s	v16, v3, v19
	fsub.4s	v1, v1, v16
	fcvtzs.4s	v5, v5
	scvtf.4s	v16, v5
	fmul.4s	v17, v16, v19
	fsub.4s	v4, v4, v17
	fmul.4s	v16, v16, v20
	fsub.4s	v4, v4, v16
	fmul.4s	v3, v3, v20
	fsub.4s	v1, v1, v3
	fmul.4s	v3, v1, v21
	fadd.4s	v3, v3, v22
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v27
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v25
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v31
	fmul.4s	v16, v1, v1
	fmul.4s	v3, v16, v3
	fmul.4s	v16, v4, v21
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v27
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v23
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v25
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v31
	fmul.4s	v17, v4, v4
	fmul.4s	v16, v17, v16
	fadd.4s	v4, v4, v16
	fadd.4s	v1, v1, v3
	fadd.4s	v3, v4, v24
	sshr.4s	v4, v5, #1
	shl.4s	v16, v4, #23
	add.4s	v16, v16, v24
	fmul.4s	v3, v3, v16
	fadd.4s	v1, v1, v24
	sshr.4s	v16, v0, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v24
	fmul.4s	v1, v1, v17
	sub.4s	v4, v5, v4
	sub.4s	v0, v0, v16
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v3, v1
	fcmgt.4s	v3, v7, v28
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v7, v2
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v2, v6
	bit.16b	v0, v26, v3
	stp	q2, q0, [sp, #928]              ; 32-byte Folded Spill
	fcmgt.4s	v0, v28, v6
	bsl.16b	v0, v26, v1
	stp	q28, q0, [sp, #896]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1568]                 ; 16-byte Reload
	fsub.4s	v28, v0, v30
	fcmge.4s	v0, v28, v7
	fcmge.4s	v1, v6, v28
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1856]                 ; 16-byte Reload
	fsub.4s	v2, v1, v12
	fcmge.4s	v1, v2, v7
	fcmge.4s	v3, v6, v2
	and.16b	v1, v1, v3
	and.16b	v1, v1, v2
	fmul.4s	v3, v1, v18
	mov.16b	v4, v29
	bsl.16b	v4, v10, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v28
	fmul.4s	v0, v4, v18
	mov.16b	v5, v29
	bsl.16b	v5, v10, v0
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	fmul.4s	v16, v3, v19
	fsub.4s	v1, v1, v16
	fcvtzs.4s	v5, v5
	scvtf.4s	v16, v5
	fmul.4s	v17, v16, v19
	fsub.4s	v4, v4, v17
	fmul.4s	v16, v16, v20
	fsub.4s	v4, v4, v16
	fmul.4s	v3, v3, v20
	fsub.4s	v1, v1, v3
	fmul.4s	v3, v1, v21
	fadd.4s	v3, v3, v22
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v27
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v25
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v31
	fmul.4s	v16, v1, v1
	fmul.4s	v3, v16, v3
	fmul.4s	v16, v4, v21
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v27
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v23
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v25
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v31
	fmul.4s	v17, v4, v4
	fmul.4s	v16, v17, v16
	fadd.4s	v4, v4, v16
	fadd.4s	v1, v1, v3
	fadd.4s	v3, v4, v24
	sshr.4s	v4, v5, #1
	shl.4s	v16, v4, #23
	add.4s	v16, v16, v24
	fmul.4s	v3, v3, v16
	fadd.4s	v1, v1, v24
	sshr.4s	v16, v0, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v24
	fmul.4s	v1, v1, v17
	sub.4s	v4, v5, v4
	sub.4s	v0, v0, v16
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v3, v1
	fcmgt.4s	v3, v7, v28
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v7, v2
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v2, v6
	bit.16b	v0, v26, v3
	stp	q2, q0, [sp, #864]              ; 32-byte Folded Spill
	fcmgt.4s	v0, v28, v6
	bsl.16b	v0, v26, v1
	stp	q28, q0, [sp, #832]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1584]                 ; 16-byte Reload
	fsub.4s	v28, v0, v30
	fcmge.4s	v0, v28, v7
	fcmge.4s	v1, v6, v28
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1776]                 ; 16-byte Reload
	fsub.4s	v29, v1, v12
	fcmge.4s	v1, v29, v7
	fcmge.4s	v3, v6, v29
	and.16b	v1, v1, v3
	and.16b	v1, v1, v29
	fmul.4s	v3, v1, v18
	mvni.4s	v2, #128, lsl #24
	movi.4s	v5, #75, lsl #24
	mov.16b	v4, v2
	bsl.16b	v4, v5, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v28
	fmul.4s	v0, v4, v18
	bif.16b	v5, v0, v2
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	fmul.4s	v16, v3, v19
	fsub.4s	v1, v1, v16
	fcvtzs.4s	v5, v5
	scvtf.4s	v16, v5
	fmul.4s	v17, v16, v19
	fsub.4s	v4, v4, v17
	fmul.4s	v16, v16, v20
	fsub.4s	v4, v4, v16
	fmul.4s	v3, v3, v20
	fsub.4s	v1, v1, v3
	fmul.4s	v3, v1, v21
	fadd.4s	v3, v3, v22
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v27
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v25
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v31
	fmul.4s	v16, v1, v1
	fmul.4s	v3, v16, v3
	fmul.4s	v16, v4, v21
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v27
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v23
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v25
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v31
	fmul.4s	v17, v4, v4
	fmul.4s	v16, v17, v16
	fadd.4s	v4, v4, v16
	fadd.4s	v1, v1, v3
	fadd.4s	v3, v4, v24
	sshr.4s	v4, v5, #1
	shl.4s	v16, v4, #23
	add.4s	v16, v16, v24
	fmul.4s	v3, v3, v16
	fadd.4s	v1, v1, v24
	sshr.4s	v16, v0, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v24
	fmul.4s	v1, v1, v17
	sub.4s	v4, v5, v4
	sub.4s	v0, v0, v16
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v3, v1
	fcmgt.4s	v3, v7, v28
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v7, v29
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v29, v6
	bit.16b	v0, v26, v3
	stp	q29, q0, [sp, #800]             ; 32-byte Folded Spill
	fcmgt.4s	v0, v28, v6
	bsl.16b	v0, v26, v1
	stp	q28, q0, [sp, #768]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1600]                 ; 16-byte Reload
	fsub.4s	v28, v0, v30
	fcmge.4s	v0, v28, v7
	fcmge.4s	v1, v6, v28
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1840]                 ; 16-byte Reload
	fsub.4s	v2, v1, v12
	fcmge.4s	v1, v2, v7
	fcmge.4s	v3, v6, v2
	and.16b	v1, v1, v3
	and.16b	v1, v1, v2
	fmul.4s	v3, v1, v18
	movi.4s	v5, #75, lsl #24
	mvni.4s	v16, #128, lsl #24
	mov.16b	v4, v16
	bsl.16b	v4, v5, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v28
	fmul.4s	v0, v4, v18
	bif.16b	v5, v0, v16
	mvni.4s	v29, #128, lsl #24
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	fmul.4s	v16, v3, v19
	fsub.4s	v1, v1, v16
	fcvtzs.4s	v5, v5
	scvtf.4s	v16, v5
	fmul.4s	v17, v16, v19
	fsub.4s	v4, v4, v17
	fmul.4s	v16, v16, v20
	fsub.4s	v4, v4, v16
	fmul.4s	v3, v3, v20
	fsub.4s	v1, v1, v3
	fmul.4s	v3, v1, v21
	fadd.4s	v3, v3, v22
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v27
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v25
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v31
	fmul.4s	v16, v1, v1
	fmul.4s	v3, v16, v3
	fmul.4s	v16, v4, v21
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v27
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v23
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v25
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v31
	fmul.4s	v17, v4, v4
	fmul.4s	v16, v17, v16
	fadd.4s	v4, v4, v16
	fadd.4s	v1, v1, v3
	fadd.4s	v3, v4, v24
	sshr.4s	v4, v5, #1
	shl.4s	v16, v4, #23
	add.4s	v16, v16, v24
	fmul.4s	v3, v3, v16
	fadd.4s	v1, v1, v24
	sshr.4s	v16, v0, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v24
	fmul.4s	v1, v1, v17
	sub.4s	v4, v5, v4
	sub.4s	v0, v0, v16
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v3, v1
	fcmgt.4s	v3, v7, v28
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v7, v2
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v2, v6
	bit.16b	v0, v26, v3
	stp	q2, q0, [sp, #736]              ; 32-byte Folded Spill
	fcmgt.4s	v0, v28, v6
	bsl.16b	v0, v26, v1
	stp	q28, q0, [sp, #704]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1616]                 ; 16-byte Reload
	fsub.4s	v28, v0, v30
	fcmge.4s	v0, v28, v7
	fcmge.4s	v1, v6, v28
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1760]                 ; 16-byte Reload
	fsub.4s	v2, v1, v12
	fcmge.4s	v1, v2, v7
	fcmge.4s	v3, v6, v2
	and.16b	v1, v1, v3
	and.16b	v1, v1, v2
	fmul.4s	v3, v1, v18
	mov.16b	v4, v29
	bsl.16b	v4, v10, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v28
	fmul.4s	v0, v4, v18
	mov.16b	v5, v29
	bsl.16b	v5, v10, v0
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	fmul.4s	v16, v3, v19
	fsub.4s	v1, v1, v16
	fcvtzs.4s	v5, v5
	scvtf.4s	v16, v5
	fmul.4s	v17, v16, v19
	fsub.4s	v4, v4, v17
	fmul.4s	v16, v16, v20
	fsub.4s	v4, v4, v16
	fmul.4s	v3, v3, v20
	fsub.4s	v1, v1, v3
	fmul.4s	v3, v1, v21
	fadd.4s	v3, v3, v22
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v27
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v25
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v31
	fmul.4s	v16, v1, v1
	fmul.4s	v3, v16, v3
	fmul.4s	v16, v4, v21
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v27
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v23
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v25
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v31
	fmul.4s	v17, v4, v4
	fmul.4s	v16, v17, v16
	fadd.4s	v4, v4, v16
	fadd.4s	v1, v1, v3
	fadd.4s	v3, v4, v24
	sshr.4s	v4, v5, #1
	shl.4s	v16, v4, #23
	add.4s	v16, v16, v24
	fmul.4s	v3, v3, v16
	fadd.4s	v1, v1, v24
	sshr.4s	v16, v0, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v24
	fmul.4s	v1, v1, v17
	sub.4s	v4, v5, v4
	sub.4s	v0, v0, v16
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v3, v1
	fcmgt.4s	v3, v7, v28
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v7, v2
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v2, v6
	bit.16b	v0, v26, v3
	stp	q2, q0, [sp, #672]              ; 32-byte Folded Spill
	fcmgt.4s	v0, v28, v6
	bsl.16b	v0, v26, v1
	stp	q28, q0, [sp, #640]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1632]                 ; 16-byte Reload
	fsub.4s	v28, v0, v30
	fcmge.4s	v0, v28, v7
	fcmge.4s	v1, v6, v28
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1824]                 ; 16-byte Reload
	fsub.4s	v29, v1, v12
	fcmge.4s	v1, v29, v7
	fcmge.4s	v3, v6, v29
	and.16b	v1, v1, v3
	and.16b	v1, v1, v29
	fmul.4s	v3, v1, v18
	mvni.4s	v2, #128, lsl #24
	movi.4s	v5, #75, lsl #24
	mov.16b	v4, v2
	bsl.16b	v4, v5, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v28
	fmul.4s	v0, v4, v18
	bif.16b	v5, v0, v2
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	fmul.4s	v16, v3, v19
	fsub.4s	v1, v1, v16
	fcvtzs.4s	v5, v5
	scvtf.4s	v16, v5
	fmul.4s	v17, v16, v19
	fsub.4s	v4, v4, v17
	fmul.4s	v16, v16, v20
	fsub.4s	v4, v4, v16
	fmul.4s	v3, v3, v20
	fsub.4s	v1, v1, v3
	fmul.4s	v3, v1, v21
	fadd.4s	v3, v3, v22
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v27
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v25
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v31
	fmul.4s	v16, v1, v1
	fmul.4s	v3, v16, v3
	fmul.4s	v16, v4, v21
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v27
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v23
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v25
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v31
	fmul.4s	v17, v4, v4
	fmul.4s	v16, v17, v16
	fadd.4s	v4, v4, v16
	fadd.4s	v1, v1, v3
	fadd.4s	v3, v4, v24
	sshr.4s	v4, v5, #1
	shl.4s	v16, v4, #23
	add.4s	v16, v16, v24
	fmul.4s	v3, v3, v16
	fadd.4s	v1, v1, v24
	sshr.4s	v16, v0, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v24
	fmul.4s	v1, v1, v17
	sub.4s	v4, v5, v4
	sub.4s	v0, v0, v16
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v3, v1
	fcmgt.4s	v3, v7, v28
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v7, v29
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v29, v6
	bit.16b	v0, v26, v3
	stp	q29, q0, [sp, #608]             ; 32-byte Folded Spill
	fcmgt.4s	v0, v28, v6
	bsl.16b	v0, v26, v1
	stp	q28, q0, [sp, #576]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1648]                 ; 16-byte Reload
	fsub.4s	v2, v0, v30
	fcmge.4s	v0, v2, v7
	fcmge.4s	v1, v6, v2
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1744]                 ; 16-byte Reload
	fsub.4s	v28, v1, v12
	fcmge.4s	v1, v28, v7
	fcmge.4s	v3, v6, v28
	and.16b	v1, v1, v3
	and.16b	v1, v1, v28
	fmul.4s	v3, v1, v18
	movi.4s	v5, #75, lsl #24
	mvni.4s	v16, #128, lsl #24
	mov.16b	v4, v16
	bsl.16b	v4, v5, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v2
	fmul.4s	v0, v4, v18
	bif.16b	v5, v0, v16
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	fmul.4s	v16, v3, v19
	fsub.4s	v1, v1, v16
	fcvtzs.4s	v5, v5
	scvtf.4s	v16, v5
	fmul.4s	v17, v16, v19
	fsub.4s	v4, v4, v17
	fmul.4s	v16, v16, v20
	fsub.4s	v4, v4, v16
	fmul.4s	v3, v3, v20
	fsub.4s	v1, v1, v3
	fmul.4s	v3, v1, v21
	fadd.4s	v3, v3, v22
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v27
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v25
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v31
	fmul.4s	v16, v1, v1
	fmul.4s	v3, v16, v3
	fmul.4s	v16, v4, v21
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v27
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v23
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v25
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v31
	fmul.4s	v17, v4, v4
	fmul.4s	v16, v17, v16
	fadd.4s	v4, v4, v16
	fadd.4s	v1, v1, v3
	fadd.4s	v3, v4, v24
	sshr.4s	v4, v5, #1
	shl.4s	v16, v4, #23
	add.4s	v16, v16, v24
	fmul.4s	v3, v3, v16
	fadd.4s	v1, v1, v24
	sshr.4s	v16, v0, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v24
	fmul.4s	v1, v1, v17
	sub.4s	v4, v5, v4
	sub.4s	v0, v0, v16
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v3, v1
	fcmgt.4s	v3, v7, v2
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v7, v28
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v28, v6
	bit.16b	v0, v26, v3
	str	q0, [sp, #560]                  ; 16-byte Spill
	fcmgt.4s	v0, v2, v6
	bsl.16b	v0, v26, v1
	stp	q2, q0, [sp, #528]              ; 32-byte Folded Spill
	ldr	q0, [sp, #1664]                 ; 16-byte Reload
	fsub.4s	v12, v0, v30
	fcmge.4s	v0, v12, v7
	fcmge.4s	v1, v6, v12
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1808]                 ; 16-byte Reload
	fsub.4s	v17, v1, v9
	fcmge.4s	v1, v17, v7
	fcmge.4s	v3, v6, v17
	and.16b	v1, v1, v3
	and.16b	v1, v1, v17
	fmul.4s	v3, v1, v18
	mvni.4s	v2, #128, lsl #24
	movi.4s	v5, #75, lsl #24
	mov.16b	v4, v2
	bsl.16b	v4, v5, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v12
	fmul.4s	v0, v4, v18
	bif.16b	v5, v0, v2
	mvni.4s	v29, #128, lsl #24
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	fmul.4s	v16, v3, v19
	fsub.4s	v1, v1, v16
	fcvtzs.4s	v5, v5
	scvtf.4s	v16, v5
	fmul.4s	v10, v16, v19
	fsub.4s	v4, v4, v10
	fmul.4s	v16, v16, v20
	fsub.4s	v4, v4, v16
	fmul.4s	v3, v3, v20
	fsub.4s	v1, v1, v3
	fmul.4s	v3, v1, v21
	fadd.4s	v3, v3, v22
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v27
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v25
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v31
	fmul.4s	v16, v1, v1
	fmul.4s	v3, v16, v3
	fmul.4s	v16, v4, v21
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v27
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v23
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v25
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v31
	fmul.4s	v10, v4, v4
	fmul.4s	v16, v10, v16
	fadd.4s	v4, v4, v16
	fadd.4s	v1, v1, v3
	fadd.4s	v3, v4, v24
	sshr.4s	v4, v5, #1
	shl.4s	v16, v4, #23
	add.4s	v16, v16, v24
	fmul.4s	v3, v3, v16
	fadd.4s	v1, v1, v24
	sshr.4s	v16, v0, #1
	shl.4s	v10, v16, #23
	add.4s	v10, v10, v24
	fmul.4s	v1, v1, v10
	sub.4s	v4, v5, v4
	sub.4s	v0, v0, v16
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v3, v1
	fcmgt.4s	v3, v7, v12
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v7, v17
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v17, v6
	bit.16b	v0, v26, v3
	str	q0, [sp, #512]                  ; 16-byte Spill
	fcmgt.4s	v0, v12, v6
	bsl.16b	v0, v26, v1
	str	q0, [sp, #496]                  ; 16-byte Spill
	ldr	q0, [sp, #1680]                 ; 16-byte Reload
	fsub.4s	v16, v0, v30
	fcmge.4s	v0, v16, v7
	fcmge.4s	v1, v6, v16
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1728]                 ; 16-byte Reload
	fsub.4s	v5, v1, v9
	fcmge.4s	v1, v5, v7
	fcmge.4s	v3, v6, v5
	and.16b	v1, v1, v3
	and.16b	v1, v1, v5
	fmul.4s	v3, v1, v18
	movi.4s	v2, #75, lsl #24
	mov.16b	v4, v29
	bsl.16b	v4, v2, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v16
	fmul.4s	v0, v4, v18
	mov.16b	v10, v29
	bsl.16b	v10, v2, v0
	fadd.4s	v0, v0, v10
	fsub.4s	v10, v0, v10
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	fmul.4s	v11, v3, v19
	fsub.4s	v1, v1, v11
	fcvtzs.4s	v10, v10
	scvtf.4s	v11, v10
	fmul.4s	v15, v11, v19
	fsub.4s	v4, v4, v15
	fmul.4s	v11, v11, v20
	fsub.4s	v4, v4, v11
	fmul.4s	v3, v3, v20
	fsub.4s	v1, v1, v3
	fmul.4s	v3, v1, v21
	fadd.4s	v3, v3, v22
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v27
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v25
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v31
	fmul.4s	v11, v1, v1
	fmul.4s	v3, v11, v3
	fmul.4s	v11, v4, v21
	fadd.4s	v11, v11, v22
	fmul.4s	v11, v4, v11
	fadd.4s	v11, v11, v27
	fmul.4s	v11, v4, v11
	fadd.4s	v11, v11, v23
	fmul.4s	v11, v4, v11
	fadd.4s	v11, v11, v25
	fmul.4s	v11, v4, v11
	fadd.4s	v11, v11, v31
	fmul.4s	v15, v4, v4
	fmul.4s	v11, v15, v11
	fadd.4s	v4, v4, v11
	fadd.4s	v1, v1, v3
	fadd.4s	v3, v4, v24
	sshr.4s	v4, v10, #1
	shl.4s	v11, v4, #23
	add.4s	v11, v11, v24
	fmul.4s	v3, v3, v11
	fadd.4s	v1, v1, v24
	sshr.4s	v11, v0, #1
	shl.4s	v15, v11, #23
	add.4s	v15, v15, v24
	fmul.4s	v1, v1, v15
	sub.4s	v4, v10, v4
	sub.4s	v0, v0, v11
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v3, v1
	fcmgt.4s	v3, v7, v16
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v7, v5
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v5, v6
	bit.16b	v0, v26, v3
	str	q0, [sp, #480]                  ; 16-byte Spill
	fcmgt.4s	v0, v16, v6
	bsl.16b	v0, v26, v1
	str	q0, [sp, #464]                  ; 16-byte Spill
	ldr	q0, [sp, #1696]                 ; 16-byte Reload
	fsub.4s	v4, v0, v30
	fcmge.4s	v0, v4, v7
	fcmge.4s	v1, v6, v4
	and.16b	v0, v0, v1
	ldr	q29, [sp, #1232]                ; 16-byte Reload
	fsub.4s	v3, v29, v9
	fcmge.4s	v1, v3, v7
	fcmge.4s	v10, v6, v3
	and.16b	v1, v1, v10
	and.16b	v1, v1, v3
	fmul.4s	v10, v1, v18
	mvni.4s	v2, #128, lsl #24
	movi.4s	v13, #75, lsl #24
	mov.16b	v11, v2
	bsl.16b	v11, v13, v10
	fadd.4s	v10, v10, v11
	fsub.4s	v10, v10, v11
	and.16b	v11, v0, v4
	fmul.4s	v0, v11, v18
	mov.16b	v15, v2
	bsl.16b	v15, v13, v0
	movi.4s	v8, #75, lsl #24
	fadd.4s	v0, v0, v15
	fsub.4s	v15, v0, v15
	fcvtzs.4s	v0, v10
	scvtf.4s	v10, v0
	fmul.4s	v14, v10, v19
	fsub.4s	v1, v1, v14
	fcvtzs.4s	v14, v15
	scvtf.4s	v15, v14
	fmul.4s	v13, v15, v19
	fsub.4s	v11, v11, v13
	fmul.4s	v13, v15, v20
	fsub.4s	v11, v11, v13
	fmul.4s	v10, v10, v20
	fsub.4s	v1, v1, v10
	fmul.4s	v10, v1, v21
	fadd.4s	v10, v10, v22
	fmul.4s	v10, v1, v10
	fadd.4s	v10, v10, v27
	fmul.4s	v10, v1, v10
	fadd.4s	v10, v10, v23
	fmul.4s	v10, v1, v10
	fadd.4s	v10, v10, v25
	fmul.4s	v10, v1, v10
	fadd.4s	v10, v10, v31
	fmul.4s	v13, v1, v1
	fmul.4s	v10, v13, v10
	fmul.4s	v13, v11, v21
	fadd.4s	v13, v13, v22
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v13, v27
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v13, v23
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v13, v25
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v13, v31
	fmul.4s	v15, v11, v11
	fmul.4s	v13, v15, v13
	fadd.4s	v11, v11, v13
	fadd.4s	v1, v1, v10
	fadd.4s	v10, v11, v24
	sshr.4s	v11, v14, #1
	shl.4s	v13, v11, #23
	add.4s	v13, v13, v24
	fmul.4s	v10, v10, v13
	fadd.4s	v1, v1, v24
	sshr.4s	v13, v0, #1
	shl.4s	v15, v13, #23
	add.4s	v15, v15, v24
	fmul.4s	v1, v1, v15
	sub.4s	v11, v14, v11
	sub.4s	v0, v0, v13
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v1, v0
	shl.4s	v1, v11, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v10, v1
	fcmgt.4s	v10, v7, v4
	bic.16b	v1, v1, v10
	fcmgt.4s	v10, v7, v3
	bic.16b	v0, v0, v10
	fcmgt.4s	v10, v3, v6
	bit.16b	v0, v26, v10
	str	q0, [sp, #432]                  ; 16-byte Spill
	fcmgt.4s	v0, v4, v6
	bsl.16b	v0, v26, v1
	str	q0, [sp, #416]                  ; 16-byte Spill
	str	q30, [sp, #1376]                ; 16-byte Spill
	ldr	q0, [sp, #1888]                 ; 16-byte Reload
	fsub.4s	v2, v0, v30
	fcmge.4s	v0, v2, v7
	fcmge.4s	v13, v6, v2
	and.16b	v13, v0, v13
	str	q9, [sp, #1392]                 ; 16-byte Spill
	ldr	q1, [sp, #1904]                 ; 16-byte Reload
	fsub.4s	v1, v1, v9
	fcmge.4s	v14, v1, v7
	fcmge.4s	v15, v6, v1
	and.16b	v14, v14, v15
	and.16b	v14, v14, v1
	fmul.4s	v15, v14, v18
	mvni.4s	v30, #128, lsl #24
	mov.16b	v0, v30
	bsl.16b	v0, v8, v15
	fadd.4s	v15, v15, v0
	fsub.4s	v0, v15, v0
	and.16b	v13, v13, v2
	fmul.4s	v18, v13, v18
	mov.16b	v15, v30
	bsl.16b	v15, v8, v18
	fadd.4s	v18, v18, v15
	fsub.4s	v18, v18, v15
	fcvtzs.4s	v0, v0
	scvtf.4s	v15, v0
	fmul.4s	v11, v15, v19
	fsub.4s	v11, v14, v11
	fcvtzs.4s	v18, v18
	scvtf.4s	v14, v18
	fmul.4s	v19, v14, v19
	fsub.4s	v19, v13, v19
	fmul.4s	v13, v15, v20
	fmul.4s	v20, v14, v20
	fsub.4s	v19, v19, v20
	fsub.4s	v20, v11, v13
	fmul.4s	v11, v20, v21
	fmul.4s	v21, v19, v21
	fadd.4s	v21, v21, v22
	fadd.4s	v22, v11, v22
	fmul.4s	v22, v20, v22
	fmul.4s	v21, v19, v21
	fadd.4s	v21, v21, v27
	fadd.4s	v22, v22, v27
	fmul.4s	v22, v20, v22
	fmul.4s	v21, v19, v21
	fadd.4s	v21, v21, v23
	fadd.4s	v22, v22, v23
	fmul.4s	v22, v20, v22
	fmul.4s	v21, v19, v21
	fadd.4s	v21, v21, v25
	fadd.4s	v22, v22, v25
	fmul.4s	v22, v20, v22
	fadd.4s	v22, v22, v31
	fmul.4s	v23, v20, v20
	fmul.4s	v22, v23, v22
	fmul.4s	v21, v19, v21
	fadd.4s	v21, v21, v31
	fmul.4s	v23, v19, v19
	fmul.4s	v21, v23, v21
	fadd.4s	v19, v19, v21
	fadd.4s	v20, v20, v22
	fadd.4s	v19, v19, v24
	sshr.4s	v21, v18, #1
	shl.4s	v22, v21, #23
	add.4s	v22, v22, v24
	fmul.4s	v19, v19, v22
	fadd.4s	v20, v20, v24
	sshr.4s	v22, v0, #1
	shl.4s	v23, v22, #23
	add.4s	v23, v23, v24
	fmul.4s	v20, v20, v23
	sub.4s	v18, v18, v21
	sub.4s	v0, v0, v22
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v24
	fmul.4s	v0, v20, v0
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v24
	fmul.4s	v18, v19, v18
	fcmgt.4s	v19, v7, v2
	bic.16b	v18, v18, v19
	str	q1, [sp, #1888]                 ; 16-byte Spill
	fcmgt.4s	v7, v7, v1
	bic.16b	v0, v0, v7
	fcmgt.4s	v7, v1, v6
	bit.16b	v0, v26, v7
	str	q0, [sp, #1904]                 ; 16-byte Spill
	fcmgt.4s	v0, v2, v6
	bsl.16b	v0, v26, v18
	stp	q2, q0, [sp, #384]              ; 32-byte Folded Spill
	ldp	x8, x9, [sp, #352]              ; 16-byte Folded Reload
	ldr	q1, [sp, #1536]                 ; 16-byte Reload
	ldr	q0, [sp, #1712]                 ; 16-byte Reload
	stp	q0, q1, [x9]
	ldr	q1, [sp, #1504]                 ; 16-byte Reload
	ldr	q0, [sp, #1520]                 ; 16-byte Reload
	stp	q0, q1, [x8]
	ldp	x8, x9, [sp, #336]              ; 16-byte Folded Reload
	ldr	q1, [sp, #1472]                 ; 16-byte Reload
	ldr	q0, [sp, #1488]                 ; 16-byte Reload
	stp	q0, q1, [x9]
	ldr	q1, [sp, #1456]                 ; 16-byte Reload
	ldr	q0, [sp, #1952]                 ; 16-byte Reload
	stp	q0, q1, [x8]
	ldp	x8, x9, [sp, #320]              ; 16-byte Folded Reload
	ldr	q1, [sp, #1920]                 ; 16-byte Reload
	ldr	q0, [sp, #1936]                 ; 16-byte Reload
	stp	q0, q1, [x9]
	ldr	q1, [sp, #1024]                 ; 16-byte Reload
	ldr	q0, [sp, #1872]                 ; 16-byte Reload
	stp	q0, q1, [x8]
	ldp	x8, x9, [sp, #304]              ; 16-byte Folded Reload
	ldr	q1, [sp, #1552]                 ; 16-byte Reload
	ldr	q0, [sp, #1792]                 ; 16-byte Reload
	stp	q0, q1, [x9]
	ldr	q1, [sp, #1568]                 ; 16-byte Reload
	ldr	q0, [sp, #1856]                 ; 16-byte Reload
	stp	q0, q1, [x8]
	ldp	x8, x9, [sp, #288]              ; 16-byte Folded Reload
	ldr	q1, [sp, #1584]                 ; 16-byte Reload
	ldr	q0, [sp, #1776]                 ; 16-byte Reload
	stp	q0, q1, [x9]
	ldr	q1, [sp, #1600]                 ; 16-byte Reload
	ldr	q0, [sp, #1840]                 ; 16-byte Reload
	stp	q0, q1, [x8]
	ldp	x8, x9, [sp, #272]              ; 16-byte Folded Reload
	ldr	q1, [sp, #1616]                 ; 16-byte Reload
	ldr	q0, [sp, #1760]                 ; 16-byte Reload
	stp	q0, q1, [x9]
	ldr	q1, [sp, #1632]                 ; 16-byte Reload
	ldr	q0, [sp, #1824]                 ; 16-byte Reload
	stp	q0, q1, [x8]
	ldp	x8, x9, [sp, #256]              ; 16-byte Folded Reload
	ldr	q1, [sp, #1648]                 ; 16-byte Reload
	ldr	q0, [sp, #1744]                 ; 16-byte Reload
	stp	q0, q1, [x9]
	ldr	q1, [sp, #1664]                 ; 16-byte Reload
	ldr	q0, [sp, #1808]                 ; 16-byte Reload
	stp	q0, q1, [x8]
	ldp	x8, x9, [sp, #240]              ; 16-byte Folded Reload
	ldr	q1, [sp, #1680]                 ; 16-byte Reload
	ldr	q0, [sp, #1728]                 ; 16-byte Reload
	stp	q0, q1, [x9]
	ldr	q0, [sp, #1696]                 ; 16-byte Reload
	stp	q29, q0, [x8]
	ldr	q0, [sp, #1312]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q13, [sp, #224]                 ; 16-byte Reload
	ldr	q18, [sp, #1328]                ; 16-byte Reload
	bsl.16b	v0, v18, v13
	str	q0, [sp, #1840]                 ; 16-byte Spill
	ldr	q0, [sp, #1360]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q18, [sp, #1344]                ; 16-byte Reload
	bsl.16b	v0, v18, v13
	str	q0, [sp, #1808]                 ; 16-byte Spill
	ldr	q0, [sp, #1248]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q18, [sp, #1264]                ; 16-byte Reload
	bsl.16b	v0, v18, v13
	str	q0, [sp, #1824]                 ; 16-byte Spill
	ldr	q0, [sp, #1280]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q18, [sp, #1296]                ; 16-byte Reload
	bsl.16b	v0, v18, v13
	str	q0, [sp, #1792]                 ; 16-byte Spill
	ldr	q0, [sp, #1168]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q18, [sp, #1184]                ; 16-byte Reload
	bsl.16b	v0, v18, v13
	str	q0, [sp, #1776]                 ; 16-byte Spill
	ldr	q0, [sp, #1200]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q18, [sp, #1216]                ; 16-byte Reload
	bsl.16b	v0, v18, v13
	str	q0, [sp, #1760]                 ; 16-byte Spill
	ldr	q0, [sp, #1104]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q18, [sp, #1120]                ; 16-byte Reload
	bsl.16b	v0, v18, v13
	str	q0, [sp, #1744]                 ; 16-byte Spill
	ldr	q0, [sp, #1136]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q18, [sp, #1152]                ; 16-byte Reload
	bsl.16b	v0, v18, v13
	str	q0, [sp, #1728]                 ; 16-byte Spill
	ldr	q0, [sp, #1040]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q18, [sp, #1056]                ; 16-byte Reload
	mov.16b	v14, v0
	bsl.16b	v14, v18, v13
	ldr	q0, [sp, #1072]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q18, [sp, #1088]                ; 16-byte Reload
	bsl.16b	v0, v18, v13
	str	q0, [sp, #1712]                 ; 16-byte Spill
	ldp	q0, q18, [sp, #960]             ; 32-byte Folded Reload
	fcmeq.4s	v0, v0, v0
	mov.16b	v2, v0
	bsl.16b	v2, v18, v13
	ldp	q18, q19, [sp, #992]            ; 32-byte Folded Reload
	fcmeq.4s	v18, v18, v18
	bsl.16b	v18, v19, v13
	ldp	q19, q20, [sp, #896]            ; 32-byte Folded Reload
	fcmeq.4s	v19, v19, v19
	bsl.16b	v19, v20, v13
	ldp	q20, q21, [sp, #928]            ; 32-byte Folded Reload
	fcmeq.4s	v20, v20, v20
	mov.16b	v0, v20
	bsl.16b	v0, v21, v13
	ldp	q21, q22, [sp, #832]            ; 32-byte Folded Reload
	fcmeq.4s	v21, v21, v21
	mov.16b	v10, v21
	bsl.16b	v10, v22, v13
	ldp	q22, q23, [sp, #864]            ; 32-byte Folded Reload
	fcmeq.4s	v22, v22, v22
	mov.16b	v6, v22
	bsl.16b	v6, v23, v13
	ldp	q23, q24, [sp, #768]            ; 32-byte Folded Reload
	fcmeq.4s	v23, v23, v23
	mov.16b	v7, v23
	bsl.16b	v7, v24, v13
	ldp	q24, q25, [sp, #800]            ; 32-byte Folded Reload
	fcmeq.4s	v24, v24, v24
	bsl.16b	v24, v25, v13
	ldp	q25, q26, [sp, #704]            ; 32-byte Folded Reload
	fcmeq.4s	v25, v25, v25
	mov.16b	v15, v25
	bsl.16b	v15, v26, v13
	ldp	q26, q27, [sp, #736]            ; 32-byte Folded Reload
	fcmeq.4s	v26, v26, v26
	bsl.16b	v26, v27, v13
	ldp	q1, q27, [sp, #640]             ; 32-byte Folded Reload
	fcmeq.4s	v11, v1, v1
	bsl.16b	v11, v27, v13
	ldp	q20, q27, [sp, #672]            ; 32-byte Folded Reload
	fcmeq.4s	v9, v20, v20
	bsl.16b	v9, v27, v13
	ldp	q21, q27, [sp, #576]            ; 32-byte Folded Reload
	fcmeq.4s	v31, v21, v21
	mov.16b	v23, v31
	bsl.16b	v23, v27, v13
	ldp	q22, q27, [sp, #608]            ; 32-byte Folded Reload
	fcmeq.4s	v30, v22, v22
	bsl.16b	v30, v27, v13
	ldp	q25, q27, [sp, #528]            ; 32-byte Folded Reload
	fcmeq.4s	v29, v25, v25
	mov.16b	v22, v29
	bsl.16b	v22, v27, v13
	fcmeq.4s	v28, v28, v28
	ldr	q27, [sp, #560]                 ; 16-byte Reload
	mov.16b	v21, v28
	bsl.16b	v21, v27, v13
	fcmeq.4s	v27, v12, v12
	ldr	q12, [sp, #496]                 ; 16-byte Reload
	bsl.16b	v27, v12, v13
	fcmeq.4s	v17, v17, v17
	ldr	q12, [sp, #512]                 ; 16-byte Reload
	bsl.16b	v17, v12, v13
	fcmeq.4s	v16, v16, v16
	ldr	q12, [sp, #464]                 ; 16-byte Reload
	bsl.16b	v16, v12, v13
	fcmeq.4s	v5, v5, v5
	ldr	q12, [sp, #480]                 ; 16-byte Reload
	bsl.16b	v5, v12, v13
	fcmeq.4s	v4, v4, v4
	ldr	q12, [sp, #416]                 ; 16-byte Reload
	mov.16b	v8, v4
	bsl.16b	v8, v12, v13
	fcmeq.4s	v3, v3, v3
	ldr	q12, [sp, #432]                 ; 16-byte Reload
	mov.16b	v4, v3
	bsl.16b	v4, v12, v13
	ldr	q12, [sp, #448]                 ; 16-byte Reload
	and.16b	v1, v12, v18
	and.16b	v18, v12, v2
	and.16b	v0, v12, v0
	and.16b	v2, v12, v19
	ldr	q19, [sp, #1712]                ; 16-byte Reload
	and.16b	v29, v12, v6
	and.16b	v20, v12, v10
	and.16b	v6, v12, v24
	and.16b	v7, v12, v7
	and.16b	v3, v12, v26
	str	q3, [sp, #1680]                 ; 16-byte Spill
	mov.16b	v3, v0
	and.16b	v25, v12, v15
	and.16b	v0, v12, v9
	str	q0, [sp, #1696]                 ; 16-byte Spill
	and.16b	v11, v12, v11
	and.16b	v0, v12, v30
	str	q0, [sp, #1648]                 ; 16-byte Spill
	and.16b	v28, v12, v23
	and.16b	v0, v12, v21
	str	q0, [sp, #1664]                 ; 16-byte Spill
	mov.16b	v21, v6
	and.16b	v31, v12, v22
	mov.16b	v23, v7
	and.16b	v0, v12, v17
	str	q0, [sp, #1616]                 ; 16-byte Spill
	ldr	q10, [sp, #1728]                ; 16-byte Reload
	and.16b	v0, v12, v27
	str	q0, [sp, #1952]                 ; 16-byte Spill
	mov.16b	v24, v2
	and.16b	v0, v12, v5
	str	q0, [sp, #1632]                 ; 16-byte Spill
	ldr	q5, [sp, #1776]                 ; 16-byte Reload
	ldr	q6, [sp, #1792]                 ; 16-byte Reload
	ldr	q17, [sp, #1760]                ; 16-byte Reload
	and.16b	v2, v12, v16
	ldr	q22, [sp, #1744]                ; 16-byte Reload
	and.16b	v0, v12, v4
	str	q0, [sp, #1600]                 ; 16-byte Spill
	and.16b	v0, v12, v8
	str	q0, [sp, #1936]                 ; 16-byte Spill
	mov.16b	v27, v18
	ldr	q4, [sp, #1808]                 ; 16-byte Reload
	ldp	q0, q7, [sp, #384]              ; 32-byte Folded Reload
	fcmeq.4s	v0, v0, v0
	bsl.16b	v0, v7, v13
	str	q0, [sp, #1872]                 ; 16-byte Spill
	ldr	q0, [sp, #1888]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q7, [sp, #1904]                 ; 16-byte Reload
	bsl.16b	v0, v7, v13
	str	q0, [sp, #1856]                 ; 16-byte Spill
	mov.16b	v0, v20
	ldp	x8, x9, [sp, #208]              ; 16-byte Folded Reload
	ldr	q7, [sp, #1840]                 ; 16-byte Reload
	mov.16b	v15, v7
	stp	q7, q4, [x9]
	mov.16b	v7, v6
	str	q6, [x8, #16]
	ldr	q6, [sp, #1824]                 ; 16-byte Reload
	mov.16b	v18, v6
	str	q6, [x8]
	ldp	x8, x9, [sp, #192]              ; 16-byte Folded Reload
	mov.16b	v16, v17
	stp	q5, q17, [x9]
	mov.16b	v6, v5
	mov.16b	v8, v10
	stp	q22, q10, [x8]
	mov.16b	v17, v22
	ldp	x8, x10, [sp, #176]             ; 16-byte Folded Reload
	mov.16b	v26, v19
	stp	q14, q19, [x10]
	mov.16b	v22, v14
	str	q27, [sp, #1904]                ; 16-byte Spill
	stp	q1, q27, [x8]
	mov.16b	v20, v1
	ldp	x8, x11, [sp, #160]             ; 16-byte Folded Reload
	mov.16b	v12, v24
	stp	q3, q24, [x11]
	mov.16b	v9, v3
	mov.16b	v5, v0
	stp	q29, q0, [x8]
	mov.16b	v19, v29
	ldr	x8, [sp, #152]                  ; 8-byte Reload
	mov.16b	v10, v23
	stp	q21, q23, [x8]
	mov.16b	v29, v21
	ldr	x8, [sp, #144]                  ; 8-byte Reload
	str	q25, [sp, #1920]                ; 16-byte Spill
	ldr	q0, [sp, #1680]                 ; 16-byte Reload
	mov.16b	v30, v0
	stp	q0, q25, [x8]
	ldr	x8, [sp, #136]                  ; 8-byte Reload
	mov.16b	v21, v11
	str	q11, [x8, #16]
	ldr	q0, [sp, #1696]                 ; 16-byte Reload
	mov.16b	v11, v0
	str	q0, [x8]
	ldr	x8, [sp, #128]                  ; 8-byte Reload
	str	q28, [sp, #1888]                ; 16-byte Spill
	str	q28, [x8, #16]
	ldr	q0, [sp, #1648]                 ; 16-byte Reload
	mov.16b	v28, v0
	str	q0, [x8]
	ldr	x8, [sp, #120]                  ; 8-byte Reload
	mov.16b	v23, v31
	str	q31, [x8, #16]
	ldr	q0, [sp, #1664]                 ; 16-byte Reload
	mov.16b	v31, v0
	str	q0, [x8]
	ldr	x8, [sp, #112]                  ; 8-byte Reload
	ldr	q0, [sp, #1952]                 ; 16-byte Reload
	str	q0, [x8, #16]
	ldr	q0, [sp, #1616]                 ; 16-byte Reload
	mov.16b	v27, v0
	str	q0, [x8]
	ldr	x8, [sp, #104]                  ; 8-byte Reload
	mov.16b	v25, v2
	ldr	q0, [sp, #1632]                 ; 16-byte Reload
	mov.16b	v24, v0
	stp	q0, q2, [x8]
	ldr	x8, [sp, #96]                   ; 8-byte Reload
	ldr	q2, [sp, #1936]                 ; 16-byte Reload
	ldr	q0, [sp, #1600]                 ; 16-byte Reload
	mov.16b	v13, v0
	stp	q0, q2, [x8]
	mov	x8, x20
	mov	w9, #96                         ; =0x60
LBB0_44:                                ; %direct.true738
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x8, #2576]
	ldr	q1, [x8, #2560]
	ldr	q2, [sp, #1856]                 ; 16-byte Reload
	fmul.4s	v1, v2, v1
	ldr	q2, [sp, #1872]                 ; 16-byte Reload
	fmul.4s	v0, v2, v0
	ldr	q2, [x8, #49680]
	ldr	q3, [x8, #49664]
	fmul.4s	v3, v15, v3
	fmul.4s	v2, v4, v2
	fadd.4s	v0, v0, v2
	fadd.4s	v1, v1, v3
	ldr	q2, [x8, #52736]
	ldr	q3, [x8, #52752]
	fmul.4s	v3, v7, v3
	fmul.4s	v2, v18, v2
	fadd.4s	v1, v1, v2
	fadd.4s	v0, v0, v3
	ldr	q2, [x8, #55824]
	ldr	q3, [x8, #55808]
	fmul.4s	v3, v6, v3
	fmul.4s	v2, v16, v2
	fadd.4s	v0, v0, v2
	fadd.4s	v1, v1, v3
	ldr	q2, [x8, #58880]
	ldr	q3, [x8, #58896]
	fmul.4s	v3, v8, v3
	fmul.4s	v2, v17, v2
	fadd.4s	v1, v1, v2
	fadd.4s	v0, v0, v3
	ldr	q2, [x8, #61968]
	ldr	q3, [x8, #61952]
	fmul.4s	v3, v22, v3
	fmul.4s	v2, v26, v2
	fadd.4s	v0, v0, v2
	fadd.4s	v1, v1, v3
	ldr	q2, [x8, #65024]
	ldr	q3, [x8, #65040]
	ldr	q14, [sp, #1904]                ; 16-byte Reload
	fmul.4s	v3, v14, v3
	fmul.4s	v2, v20, v2
	fadd.4s	v1, v1, v2
	fadd.4s	v0, v0, v3
	add	x10, x8, x0
	ldp	q3, q2, [x10]
	fmul.4s	v3, v9, v3
	fmul.4s	v2, v12, v2
	fadd.4s	v0, v0, v2
	add	x10, x8, x1
	fadd.4s	v1, v1, v3
	ldp	q2, q3, [x10]
	fmul.4s	v3, v5, v3
	fmul.4s	v2, v19, v2
	fadd.4s	v1, v1, v2
	add	x10, x8, x2
	fadd.4s	v0, v0, v3
	ldp	q3, q2, [x10]
	fmul.4s	v3, v29, v3
	fmul.4s	v2, v10, v2
	fadd.4s	v0, v0, v2
	fadd.4s	v1, v1, v3
	add	x10, x8, x3
	ldp	q2, q3, [x10]
	ldr	q14, [sp, #1920]                ; 16-byte Reload
	fmul.4s	v3, v14, v3
	fmul.4s	v2, v30, v2
	fadd.4s	v1, v1, v2
	fadd.4s	v0, v0, v3
	add	x10, x8, x4
	ldp	q3, q2, [x10]
	fmul.4s	v3, v11, v3
	fmul.4s	v2, v21, v2
	fadd.4s	v0, v0, v2
	fadd.4s	v1, v1, v3
	add	x10, x8, x22
	ldp	q2, q3, [x10]
	ldr	q14, [sp, #1888]                ; 16-byte Reload
	fmul.4s	v3, v14, v3
	fmul.4s	v2, v28, v2
	fadd.4s	v1, v1, v2
	fadd.4s	v0, v0, v3
	add	x10, x8, x28
	ldp	q3, q2, [x10]
	fmul.4s	v3, v31, v3
	fmul.4s	v2, v23, v2
	fadd.4s	v0, v0, v2
	add	x10, x8, x19
	fadd.4s	v1, v1, v3
	ldp	q2, q3, [x10]
	ldr	q14, [sp, #1952]                ; 16-byte Reload
	fmul.4s	v3, v14, v3
	fmul.4s	v2, v27, v2
	fadd.4s	v1, v1, v2
	add	x10, x8, x24
	fadd.4s	v0, v0, v3
	ldp	q3, q2, [x10]
	fmul.4s	v3, v24, v3
	fmul.4s	v2, v25, v2
	fadd.4s	v0, v0, v2
	fadd.4s	v1, v1, v3
	add	x10, x8, x21
	ldp	q2, q3, [x10]
	fmul.4s	v2, v13, v2
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #1936]                 ; 16-byte Reload
	fmul.4s	v2, v2, v3
	fadd.4s	v0, v0, v2
	add	x10, x8, x23
	stp	q1, q0, [x10]
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_44
; %bb.45:                               ; %direct.true866.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	w8, #5632                       ; =0x1600
	add	x0, x20, x8
	add	x1, x20, x23
	mov	w2, #3072                       ; =0xc00
	str	q22, [sp, #1344]                ; 16-byte Spill
	str	q20, [sp, #1488]                ; 16-byte Spill
	str	q19, [sp, #1536]                ; 16-byte Spill
	str	q9, [sp, #1360]                 ; 16-byte Spill
	str	q12, [sp, #1472]                ; 16-byte Spill
	str	q29, [sp, #1504]                ; 16-byte Spill
	str	q10, [sp, #1520]                ; 16-byte Spill
	str	q21, [sp, #1552]                ; 16-byte Spill
	str	q23, [sp, #1568]                ; 16-byte Spill
	str	q25, [sp, #1584]                ; 16-byte Spill
	str	q5, [sp, #1456]                 ; 16-byte Spill
	bl	_memcpy
	add	x0, x20, #2560
	add	x1, x20, x23
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	mov	w4, #14848                      ; =0x3a00
	movk	w4, #1, lsl #16
	mov	w3, #11776                      ; =0x2e00
	movk	w3, #1, lsl #16
	mov	w2, #8704                       ; =0x2200
	movk	w2, #1, lsl #16
	mov	w1, #5632                       ; =0x1600
	movk	w1, #1, lsl #16
	mov	w0, #2560                       ; =0xa00
	movk	w0, #1, lsl #16
	ldr	q0, [sp, #1408]                 ; 16-byte Reload
	ldr	q1, [sp, #1872]                 ; 16-byte Reload
	fmul.4s	v0, v0, v1
	ldr	q1, [sp, #1424]                 ; 16-byte Reload
	ldr	q2, [sp, #1856]                 ; 16-byte Reload
	fmul.4s	v1, v1, v2
	movi.2d	v3, #0000000000000000
	ldr	q2, [sp, #1808]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q4, [sp, #1792]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1840]                 ; 16-byte Reload
	fadd.4s	v3, v4, v3
	ldr	q4, [sp, #1824]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1776]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1760]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1728]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1744]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1344]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1712]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1904]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1488]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1360]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1472]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1456]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1536]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1504]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1520]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1920]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1680]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1696]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1552]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1888]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1648]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1664]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1568]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1952]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1616]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1632]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1584]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1936]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1600]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	fadd.4s	v19, v1, v3
	fadd.4s	v20, v0, v2
	ldr	x13, [sp, #1448]                ; 8-byte Reload
	add	x13, x13, #1
	ldr	q1, [sp, #1392]                 ; 16-byte Reload
	ldr	q0, [sp, #1376]                 ; 16-byte Reload
	cmp	x13, #129
	mov	w14, #52429                     ; =0xcccd
	mov	w15, #80                        ; =0x50
	mov	w16, #43691                     ; =0xaaab
	mov	w17, #96                        ; =0x60
	b.ne	LBB0_3
; %bb.46:                               ; %direct.schedule.83.preheader
	mov	x8, #0                          ; =0x0
	ldr	q0, [sp, #80]                   ; 16-byte Reload
	xtn.2s	v0, v0
	movi.2s	v3, #96
	umull.2d	v0, v0, v3
	ldp	q2, q1, [sp, #16]               ; 32-byte Folded Reload
	xtn.2s	v1, v1
	umull.2d	v1, v1, v3
	xtn.2s	v2, v2
	umull.2d	v2, v2, v3
	ldr	q4, [sp, #48]                   ; 16-byte Reload
	xtn.2s	v4, v4
	umull.2d	v3, v4, v3
	ldr	x11, [sp, #72]                  ; 8-byte Reload
	ldr	x12, [sp, #8]                   ; 8-byte Reload
LBB0_47:                                ; %direct.true901
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v4, x8
	add.2d	v5, v4, v3
	add.2d	v6, v4, v2
	add.2d	v7, v4, v1
	add.2d	v4, v4, v0
	add	x9, x12, x8, lsl #5
	ldp	q16, q17, [x9]
	fdiv.4s	v17, v17, v20
	fdiv.4s	v16, v16, v19
	shl.2d	v4, v4, #2
	shl.2d	v7, v7, #2
	shl.2d	v6, v6, #2
	shl.2d	v5, v5, #2
	dup.2d	v18, x11
	add.2d	v5, v18, v5
	add.2d	v4, v18, v4
	mov.d	x9, v4[1]
	fmov	x10, d4
	str	s16, [x10]
	st1.s	{ v16 }[1], [x9]
	add.2d	v4, v18, v7
	mov.d	x9, v4[1]
	fmov	x10, d4
	st1.s	{ v16 }[2], [x10]
	add.2d	v4, v18, v6
	st1.s	{ v16 }[3], [x9]
	mov.d	x9, v4[1]
	fmov	x10, d4
	str	s17, [x10]
	st1.s	{ v17 }[1], [x9]
	mov.d	x9, v5[1]
	fmov	x10, d5
	st1.s	{ v17 }[2], [x10]
	st1.s	{ v17 }[3], [x9]
	add	x8, x8, #1
	cmp	x8, #96
	b.ne	LBB0_47
; %bb.48:                               ; %common.ret
	add	sp, sp, #1968
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention.packet_batch.blocks
lCPI1_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI1_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI1_2:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI1_3:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI1_4:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI1_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI1_6:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI1_7:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI1_8:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI1_9:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI1_10:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_attention.packet_batch.blocks
	.p2align	2
_llm_attention.packet_batch.blocks:     ; @llm_attention.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_102
; %bb.1:                                ; %block.batch.loop.preheader
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #3328
	mov	x21, x3
	mov	x22, x2
	mov	x25, x0
	mov	w27, #0                         ; =0x0
	ldp	w19, w8, [x2, #44]
	str	w8, [sp, #284]                  ; 4-byte Spill
Lloh4:
	adrp	x8, lCPI1_0@PAGE
Lloh5:
	ldr	q23, [x8, lCPI1_0@PAGEOFF]
Lloh6:
	adrp	x8, lCPI1_1@PAGE
Lloh7:
	ldr	q24, [x8, lCPI1_1@PAGEOFF]
Lloh8:
	adrp	x8, lCPI1_2@PAGE
Lloh9:
	ldr	q0, [x8, lCPI1_2@PAGEOFF]
	str	q0, [sp, #64]                   ; 16-byte Spill
Lloh10:
	adrp	x8, lCPI1_3@PAGE
Lloh11:
	ldr	q0, [x8, lCPI1_3@PAGEOFF]
	str	q0, [sp, #48]                   ; 16-byte Spill
Lloh12:
	adrp	x8, lCPI1_4@PAGE
Lloh13:
	ldr	q0, [x8, lCPI1_4@PAGEOFF]
	str	q0, [sp, #32]                   ; 16-byte Spill
Lloh14:
	adrp	x8, lCPI1_5@PAGE
Lloh15:
	ldr	q0, [x8, lCPI1_5@PAGEOFF]
	str	q0, [sp, #16]                   ; 16-byte Spill
Lloh16:
	adrp	x8, lCPI1_6@PAGE
Lloh17:
	ldr	q21, [x8, lCPI1_6@PAGEOFF]
	mov	w24, #52429                     ; =0xcccd
	mov	w23, #80                        ; =0x50
	mov	w28, #43691                     ; =0xaaab
	mov	w26, #96                        ; =0x60
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	str	q0, [sp, #304]                  ; 16-byte Spill
	ldp	w2, w12, [x2]
	ldp	w13, w8, [x22, #8]
	str	x8, [sp, #272]                  ; 8-byte Spill
	str	w3, [sp, #100]                  ; 4-byte Spill
	stp	x0, x22, [sp, #80]              ; 16-byte Folded Spill
	str	w19, [sp, #252]                 ; 4-byte Spill
	str	q23, [sp, #608]                 ; 16-byte Spill
	str	q24, [sp, #224]                 ; 16-byte Spill
	str	q21, [sp, #256]                 ; 16-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x22, #36]
	ldr	w19, [sp, #252]                 ; 4-byte Reload
LBB1_3:                                 ; %llm_attention.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w2, #1
	cmp	w8, w19
	cset	w8, eq
	csinc	w2, wzr, w2, eq
	cinc	w9, w12, eq
	ldr	w10, [sp, #284]                 ; 4-byte Reload
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w12, wzr, w9, ne
	add	w13, w13, w8
	add	w27, w27, #1
	cmp	w27, w21
	b.eq	LBB1_101
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_15 Depth 2
                                        ;     Child Loop BB1_32 Depth 2
                                        ;     Child Loop BB1_34 Depth 2
                                        ;       Child Loop BB1_36 Depth 3
                                        ;       Child Loop BB1_40 Depth 3
                                        ;       Child Loop BB1_43 Depth 3
                                        ;       Child Loop BB1_45 Depth 3
                                        ;       Child Loop BB1_47 Depth 3
                                        ;       Child Loop BB1_49 Depth 3
                                        ;       Child Loop BB1_51 Depth 3
                                        ;       Child Loop BB1_53 Depth 3
                                        ;       Child Loop BB1_55 Depth 3
                                        ;       Child Loop BB1_57 Depth 3
                                        ;       Child Loop BB1_59 Depth 3
                                        ;       Child Loop BB1_61 Depth 3
                                        ;       Child Loop BB1_63 Depth 3
                                        ;       Child Loop BB1_65 Depth 3
                                        ;       Child Loop BB1_67 Depth 3
                                        ;       Child Loop BB1_69 Depth 3
                                        ;       Child Loop BB1_71 Depth 3
                                        ;       Child Loop BB1_73 Depth 3
                                        ;       Child Loop BB1_75 Depth 3
                                        ;       Child Loop BB1_77 Depth 3
                                        ;       Child Loop BB1_79 Depth 3
                                        ;       Child Loop BB1_81 Depth 3
                                        ;     Child Loop BB1_85 Depth 2
	ubfiz	x8, x2, #5, #32
	ldr	x14, [sp, #272]                 ; 8-byte Reload
	cmp	x8, x14
	csel	x9, x8, xzr, ls
	subs	x10, x14, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x14, x9
	str	x2, [sp, #296]                  ; 8-byte Spill
	stp	w2, w12, [x22]
	str	w12, [sp, #292]                 ; 4-byte Spill
	str	w13, [sp, #288]                 ; 4-byte Spill
	str	w13, [x22, #8]
	str	wzr, [x22, #36]
	ccmp	x8, x14, #2, hi
	csel	x20, x10, xzr, ls
	cmp	x20, #32
	b.lo	LBB1_6
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x25
	mov	x1, x22
	bl	_llm_attention.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x22, #36]
	mov	x0, x25
	mov	x1, x22
	bl	_llm_attention.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x22, #36]
	mov	x0, x25
	mov	x1, x22
	bl	_llm_attention.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x22, #36]
	mov	x0, x25
	mov	x1, x22
	bl	_llm_attention.full_packet
	ldr	x2, [sp, #296]                  ; 8-byte Reload
	ldr	w12, [sp, #292]                 ; 4-byte Reload
	ldr	w13, [sp, #288]                 ; 4-byte Reload
	b	LBB1_3
LBB1_6:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x19, x20, #3
	cbz	x19, LBB1_11
; %bb.7:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x22, #36]
	mov	x0, x25
	mov	x1, x22
	bl	_llm_attention.full_packet
	cmp	x19, #1
	b.eq	LBB1_11
; %bb.8:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x22, #36]
	mov	x0, x25
	mov	x1, x22
	bl	_llm_attention.full_packet
	cmp	x19, #2
	b.eq	LBB1_11
; %bb.9:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x22, #36]
	mov	x0, x25
	mov	x1, x22
	bl	_llm_attention.full_packet
	cmp	x19, #3
	b.eq	LBB1_11
; %bb.10:                               ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x22, #36]
	mov	x0, x25
	mov	x1, x22
	bl	_llm_attention.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x22, #36]
	mov	x0, x25
	mov	x1, x22
	bl	_llm_attention.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x22, #36]
	mov	x0, x25
	mov	x1, x22
	bl	_llm_attention.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x22, #36]
	mov	x0, x25
	mov	x1, x22
	bl	_llm_attention.full_packet
LBB1_11:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w8, w20, #0x7
	ldr	q23, [sp, #608]                 ; 16-byte Reload
	ldr	q24, [sp, #224]                 ; 16-byte Reload
	ldr	q21, [sp, #256]                 ; 16-byte Reload
	ldr	x2, [sp, #296]                  ; 8-byte Reload
	ldr	w12, [sp, #292]                 ; 4-byte Reload
	ldr	w13, [sp, #288]                 ; 4-byte Reload
	cbz	w8, LBB1_2
; %bb.12:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	dup.4s	v25, w8
	cmhi.4s	v0, v25, v24
	cmhi.4s	v2, v25, v23
	uzp1.8h	v4, v2, v0
	umaxv.8h	h1, v4
	fmov	w8, s1
	tbz	w8, #0, LBB1_2
; %bb.13:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	x10, [x22, #136]
	add	x8, x10, #2560
	mov	w11, #5632                      ; =0x1600
	add	x11, x10, x11
	mov	w12, #8704                      ; =0x2200
	add	x12, x10, x12
	mov	w13, #49664                     ; =0xc200
	add	x13, x10, x13
	mov	w14, #33280                     ; =0x8200
	movk	w14, #1, lsl #16
	add	x14, x10, x14
	mov	w15, #34304                     ; =0x8600
	movk	w15, #1, lsl #16
	add	x15, x10, x15
	ldr	x0, [x25]
	ldr	x16, [x25, #16]
	ldr	x17, [x25, #32]
	ushll.2d	v1, v0, #0
	ushll.2d	v3, v2, #0
	ushll2.2d	v5, v2, #0
	lsl	w1, w19, #3
	orr	w1, w1, w2, lsl #5
	fmov	s6, w1
	mov.s	v6[1], w8
	ushll2.2d	v16, v0, #0
	mov.s	v6[2], w8
	mov.s	v6[3], w8
	ushr.4s	v6, v6, #3
	dup.4s	v6, v6[0]
	and.16b	v7, v2, v6
	and.16b	v19, v0, v6
	ldr	q6, [sp, #64]                   ; 16-byte Reload
	and.16b	v6, v16, v6
	ldp	q16, q17, [sp, #32]             ; 32-byte Folded Reload
	and.16b	v5, v5, v17
	and.16b	v3, v3, v16
	ldr	q16, [sp, #16]                  ; 16-byte Reload
	and.16b	v1, v1, v16
	ushll2.2d	v16, v19, #3
	ushll2.2d	v17, v7, #3
	ushll.2d	v18, v7, #3
	ushll.2d	v20, v19, #3
	orr.16b	v20, v20, v1
	orr.16b	v22, v18, v3
	orr.16b	v17, v17, v5
	orr.16b	v1, v16, v6
	fmov	x1, d1
	add	x1, x1, x1, lsl #2
	lsl	x1, x1, #4
	fmov	d3, x1
	str	q1, [sp, #192]                  ; 16-byte Spill
	mov.d	x1, v1[1]
	str	x1, [sp, #184]                  ; 8-byte Spill
	add	x1, x1, x1, lsl #2
	lsl	x1, x1, #4
	mov.d	v3[1], x1
	fmov	x1, d17
	add	x1, x1, x1, lsl #2
	lsl	x1, x1, #4
	fmov	d5, x1
	stp	q22, q17, [sp, #128]            ; 32-byte Folded Spill
	mov.d	x1, v17[1]
	str	x1, [sp, #120]                  ; 8-byte Spill
	add	x1, x1, x1, lsl #2
	lsl	x1, x1, #4
	mov.d	v5[1], x1
	fmov	x1, d18
	add	x1, x1, x1, lsl #2
	lsl	x1, x1, #4
	fmov	d16, x1
	mov.d	x1, v22[1]
	str	x1, [sp, #104]                  ; 8-byte Spill
	add	x1, x1, x1, lsl #2
	lsl	x1, x1, #4
	mov.d	v16[1], x1
	fmov	x1, d20
	add	x1, x1, x1, lsl #2
	lsl	x1, x1, #4
	fmov	d17, x1
	str	q20, [sp, #160]                 ; 16-byte Spill
	mov.d	x1, v20[1]
	str	x1, [sp, #112]                  ; 8-byte Spill
	add	x1, x1, x1, lsl #2
	lsl	x1, x1, #4
	mov.d	v17[1], x1
	ldr	x1, [x25, #48]
	str	x1, [sp, #208]                  ; 8-byte Spill
	ushll2.2d	v1, v19, #0
	and.16b	v4, v4, v21
	addv.8h	h4, v4
	dup.2d	v18, x0
	fmov	w0, s4
	ushll2.2d	v6, v7, #0
	ushll.2d	v4, v19, #0
	ushll.2d	v7, v7, #0
	b	LBB1_15
LBB1_14:                                ; %else260
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x1, x10, x9, lsl #5
	ldp	q21, q22, [x1]
	bif.16b	v20, v22, v0
	bif.16b	v19, v21, v2
	stp	q19, q20, [x1]
	add	x9, x9, #1
	cmp	x9, #80
	b.eq	LBB1_31
LBB1_15:                                ; %direct.true.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v21, x9
	add.2d	v19, v21, v16
	shl.2d	v19, v19, #2
	add.2d	v22, v18, v19
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	tbnz	w0, #0, LBB1_23
; %bb.16:                               ; %else
                                        ;   in Loop: Header=BB1_15 Depth=2
	and	w1, w0, #0xff
	tbnz	w1, #1, LBB1_24
LBB1_17:                                ; %else242
                                        ;   in Loop: Header=BB1_15 Depth=2
	add.2d	v22, v21, v5
	shl.2d	v22, v22, #2
	add.2d	v22, v18, v22
	tbnz	w1, #2, LBB1_25
LBB1_18:                                ; %else245
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w1, #3, LBB1_26
LBB1_19:                                ; %else248
                                        ;   in Loop: Header=BB1_15 Depth=2
	add.2d	v22, v21, v17
	shl.2d	v22, v22, #2
	add.2d	v22, v18, v22
	tbnz	w1, #4, LBB1_27
LBB1_20:                                ; %else251
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w1, #5, LBB1_28
LBB1_21:                                ; %else254
                                        ;   in Loop: Header=BB1_15 Depth=2
	add.2d	v21, v21, v3
	shl.2d	v21, v21, #2
	add.2d	v21, v18, v21
	tbnz	w1, #6, LBB1_29
LBB1_22:                                ; %else257
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbz	w1, #7, LBB1_14
	b	LBB1_30
LBB1_23:                                ; %cond.load
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	x1, d22
	ldr	s19, [x1]
	and	w1, w0, #0xff
	tbz	w1, #1, LBB1_17
LBB1_24:                                ; %cond.load241
                                        ;   in Loop: Header=BB1_15 Depth=2
	mov.d	x2, v22[1]
	ld1.s	{ v19 }[1], [x2]
	add.2d	v22, v21, v5
	shl.2d	v22, v22, #2
	add.2d	v22, v18, v22
	tbz	w1, #2, LBB1_18
LBB1_25:                                ; %cond.load244
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	x2, d22
	ld1.s	{ v19 }[2], [x2]
	tbz	w1, #3, LBB1_19
LBB1_26:                                ; %cond.load247
                                        ;   in Loop: Header=BB1_15 Depth=2
	mov.d	x2, v22[1]
	ld1.s	{ v19 }[3], [x2]
	add.2d	v22, v21, v17
	shl.2d	v22, v22, #2
	add.2d	v22, v18, v22
	tbz	w1, #4, LBB1_20
LBB1_27:                                ; %cond.load250
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	x2, d22
	ld1.s	{ v20 }[0], [x2]
	tbz	w1, #5, LBB1_21
LBB1_28:                                ; %cond.load253
                                        ;   in Loop: Header=BB1_15 Depth=2
	mov.d	x2, v22[1]
	ld1.s	{ v20 }[1], [x2]
	add.2d	v21, v21, v3
	shl.2d	v21, v21, #2
	add.2d	v21, v18, v21
	tbz	w1, #6, LBB1_22
LBB1_29:                                ; %cond.load256
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	x2, d21
	ld1.s	{ v20 }[2], [x2]
	tbz	w1, #7, LBB1_14
LBB1_30:                                ; %cond.load259
                                        ;   in Loop: Header=BB1_15 Depth=2
	mov.d	x1, v21[1]
	ld1.s	{ v20 }[3], [x1]
	b	LBB1_14
LBB1_31:                                ; %direct.true165.i.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	w27, [sp, #220]                 ; 4-byte Spill
	mov	x9, #0                          ; =0x0
LBB1_32:                                ; %direct.true165.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x0, x8, x9
	ldp	q3, q5, [x0]
	cmhs.4s	v9, v24, v25
	and.16b	v5, v9, v5
	cmhs.4s	v10, v23, v25
	and.16b	v3, v10, v3
	stp	q3, q5, [x0]
	add	x9, x9, #32
	cmp	x9, #3072
	b.ne	LBB1_32
; %bb.33:                               ; %direct.false166.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	q25, [sp, #592]                 ; 16-byte Spill
	mov	x4, #0                          ; =0x0
	sshll.2d	v3, v2, #0
Lloh18:
	adrp	x9, lCPI1_10@PAGE
Lloh19:
	ldr	q5, [x9, lCPI1_10@PAGEOFF]
	str	q5, [sp, #2208]                 ; 16-byte Spill
	and.16b	v3, v3, v5
	str	q3, [sp, #3120]                 ; 16-byte Spill
	mov	w9, #62154                      ; =0xf2ca
	movk	w9, #61769, lsl #16
	dup.4s	v3, w9
	and.16b	v5, v0, v3
	str	q5, [sp, #2944]                 ; 16-byte Spill
	str	q3, [sp, #544]                  ; 16-byte Spill
	and.16b	v3, v2, v3
	str	q3, [sp, #2928]                 ; 16-byte Spill
	mov	w9, #2053                       ; =0x805
	dup.2s	v3, w9
	xtn.2s	v5, v7
	umull.2d	v13, v5, v3
	xtn.2s	v5, v6
	umull.2d	v14, v5, v3
	xtn.2s	v4, v4
	umull.2d	v4, v4, v3
	str	q4, [sp, #3296]                 ; 16-byte Spill
	xtn.2s	v1, v1
	umull.2d	v1, v1, v3
	str	q1, [sp, #3280]                 ; 16-byte Spill
	mov	w9, #52736                      ; =0xce00
	add	x5, x10, x9
	movi.2d	v1, #0000000000000000
	str	q1, [sp, #3264]                 ; 16-byte Spill
	mov	w9, #33312                      ; =0x8220
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #504]                  ; 8-byte Spill
	mov	w9, #33344                      ; =0x8240
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #496]                  ; 8-byte Spill
	mov	w9, #33376                      ; =0x8260
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #488]                  ; 8-byte Spill
	mov	w9, #33408                      ; =0x8280
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #480]                  ; 8-byte Spill
	mov	w9, #33440                      ; =0x82a0
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #472]                  ; 8-byte Spill
	mov	w9, #33472                      ; =0x82c0
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #464]                  ; 8-byte Spill
	mov	w9, #33504                      ; =0x82e0
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #456]                  ; 8-byte Spill
	mov	w9, #33536                      ; =0x8300
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #448]                  ; 8-byte Spill
	mov	w9, #33568                      ; =0x8320
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #440]                  ; 8-byte Spill
	mov	w9, #33600                      ; =0x8340
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #432]                  ; 8-byte Spill
	movi.2d	v11, #0000000000000000
	mov	w9, #33632                      ; =0x8360
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #424]                  ; 8-byte Spill
	str	q1, [sp, #2192]                 ; 16-byte Spill
	mov	w9, #33664                      ; =0x8380
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #416]                  ; 8-byte Spill
	str	q1, [sp, #2176]                 ; 16-byte Spill
	mov	w9, #33696                      ; =0x83a0
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #408]                  ; 8-byte Spill
	str	q1, [sp, #2160]                 ; 16-byte Spill
	mov	w9, #33728                      ; =0x83c0
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #400]                  ; 8-byte Spill
	str	q1, [sp, #2144]                 ; 16-byte Spill
	mov	w9, #33760                      ; =0x83e0
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #392]                  ; 8-byte Spill
	str	q1, [sp, #2128]                 ; 16-byte Spill
	mov	w9, #33792                      ; =0x8400
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #384]                  ; 8-byte Spill
	str	q1, [sp, #2112]                 ; 16-byte Spill
	mov	w9, #33824                      ; =0x8420
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #376]                  ; 8-byte Spill
	str	q1, [sp, #2096]                 ; 16-byte Spill
	mov	w9, #33856                      ; =0x8440
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #368]                  ; 8-byte Spill
	str	q1, [sp, #2080]                 ; 16-byte Spill
	mov	w9, #33888                      ; =0x8460
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #360]                  ; 8-byte Spill
	str	q1, [sp, #2064]                 ; 16-byte Spill
	mov	w9, #33920                      ; =0x8480
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #352]                  ; 8-byte Spill
	str	q1, [sp, #2048]                 ; 16-byte Spill
	mov	w9, #33952                      ; =0x84a0
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #344]                  ; 8-byte Spill
	str	q1, [sp, #2032]                 ; 16-byte Spill
	mov	w9, #33984                      ; =0x84c0
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #336]                  ; 8-byte Spill
	movi.2d	v16, #0000000000000000
	mov	w9, #34016                      ; =0x84e0
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #328]                  ; 8-byte Spill
	mov	w9, #34048                      ; =0x8500
	movk	w9, #1, lsl #16
	add	x22, x10, x9
	movi.2d	v21, #0000000000000000
	mov	w9, #34080                      ; =0x8520
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	movi.2d	v3, #0000000000000000
	str	q3, [sp, #1840]                 ; 16-byte Spill
	mov	w0, #34112                      ; =0x8540
	movk	w0, #1, lsl #16
	add	x25, x10, x0
	str	q3, [sp, #1824]                 ; 16-byte Spill
	mov	w0, #34144                      ; =0x8560
	movk	w0, #1, lsl #16
	add	x27, x10, x0
	str	q3, [sp, #1808]                 ; 16-byte Spill
	mov	w0, #34176                      ; =0x8580
	movk	w0, #1, lsl #16
	add	x20, x10, x0
	str	q3, [sp, #1792]                 ; 16-byte Spill
	mov	w0, #34208                      ; =0x85a0
	movk	w0, #1, lsl #16
	add	x6, x10, x0
	str	q3, [sp, #1776]                 ; 16-byte Spill
	str	q3, [sp, #1760]                 ; 16-byte Spill
	str	q3, [sp, #1744]                 ; 16-byte Spill
	mov	w0, #34240                      ; =0x85c0
	movk	w0, #1, lsl #16
	add	x7, x10, x0
	mov	w0, #34272                      ; =0x85e0
	movk	w0, #1, lsl #16
	add	x30, x10, x0
	str	q3, [sp, #1728]                 ; 16-byte Spill
	str	q3, [sp, #1712]                 ; 16-byte Spill
	str	q3, [sp, #1696]                 ; 16-byte Spill
	str	q3, [sp, #1680]                 ; 16-byte Spill
	str	q3, [sp, #1664]                 ; 16-byte Spill
	str	q3, [sp, #1648]                 ; 16-byte Spill
	str	q1, [sp, #3104]                 ; 16-byte Spill
	movi.2d	v7, #0000000000000000
	str	q7, [sp, #3088]                 ; 16-byte Spill
	str	q7, [sp, #3072]                 ; 16-byte Spill
	str	q7, [sp, #3056]                 ; 16-byte Spill
	str	q7, [sp, #3040]                 ; 16-byte Spill
	str	q7, [sp, #3024]                 ; 16-byte Spill
	str	q7, [sp, #3008]                 ; 16-byte Spill
	str	q7, [sp, #2992]                 ; 16-byte Spill
	str	q7, [sp, #2976]                 ; 16-byte Spill
	str	q7, [sp, #2960]                 ; 16-byte Spill
	str	q7, [sp, #2016]                 ; 16-byte Spill
	str	q7, [sp, #2000]                 ; 16-byte Spill
	str	q7, [sp, #1984]                 ; 16-byte Spill
	movi.2d	v31, #0000000000000000
	movi.2d	v6, #0000000000000000
	str	q7, [sp, #2896]                 ; 16-byte Spill
	str	q7, [sp, #2880]                 ; 16-byte Spill
	str	q3, [sp, #2864]                 ; 16-byte Spill
	movi.2d	v4, #0000000000000000
	str	q4, [sp, #2848]                 ; 16-byte Spill
	movi.2d	v5, #0000000000000000
	str	q5, [sp, #2832]                 ; 16-byte Spill
	str	q7, [sp, #2816]                 ; 16-byte Spill
	movi.2d	v22, #0000000000000000
	str	q7, [sp, #2800]                 ; 16-byte Spill
	movi.2d	v23, #0000000000000000
	str	q7, [sp, #2784]                 ; 16-byte Spill
	movi.2d	v24, #0000000000000000
	str	q7, [sp, #2768]                 ; 16-byte Spill
	movi.2d	v25, #0000000000000000
	str	q7, [sp, #2752]                 ; 16-byte Spill
	movi.2d	v29, #0000000000000000
	str	q7, [sp, #2736]                 ; 16-byte Spill
	movi.2d	v26, #0000000000000000
	str	q7, [sp, #2720]                 ; 16-byte Spill
	movi.2d	v18, #0000000000000000
	str	q7, [sp, #2704]                 ; 16-byte Spill
	movi.2d	v30, #0000000000000000
	str	q7, [sp, #2688]                 ; 16-byte Spill
	movi.2d	v15, #0000000000000000
	str	q7, [sp, #2672]                 ; 16-byte Spill
	str	q7, [sp, #2656]                 ; 16-byte Spill
	str	q7, [sp, #2640]                 ; 16-byte Spill
	movi.2d	v8, #0000000000000000
	str	q7, [sp, #3248]                 ; 16-byte Spill
	str	q7, [sp, #3232]                 ; 16-byte Spill
	str	q7, [sp, #1968]                 ; 16-byte Spill
	str	q7, [sp, #1952]                 ; 16-byte Spill
	str	q7, [sp, #1936]                 ; 16-byte Spill
	str	q7, [sp, #1920]                 ; 16-byte Spill
	str	q7, [sp, #3216]                 ; 16-byte Spill
	str	q7, [sp, #3200]                 ; 16-byte Spill
	str	q7, [sp, #3184]                 ; 16-byte Spill
	str	q7, [sp, #3168]                 ; 16-byte Spill
	str	q7, [sp, #1904]                 ; 16-byte Spill
	str	q7, [sp, #1888]                 ; 16-byte Spill
	str	q7, [sp, #1872]                 ; 16-byte Spill
	str	q7, [sp, #1856]                 ; 16-byte Spill
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	stp	q10, q9, [sp, #560]             ; 32-byte Folded Spill
	stp	q14, q13, [sp, #512]            ; 32-byte Folded Spill
LBB1_34:                                ; %direct.true175.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB1_36 Depth 3
                                        ;       Child Loop BB1_40 Depth 3
                                        ;       Child Loop BB1_43 Depth 3
                                        ;       Child Loop BB1_45 Depth 3
                                        ;       Child Loop BB1_47 Depth 3
                                        ;       Child Loop BB1_49 Depth 3
                                        ;       Child Loop BB1_51 Depth 3
                                        ;       Child Loop BB1_53 Depth 3
                                        ;       Child Loop BB1_55 Depth 3
                                        ;       Child Loop BB1_57 Depth 3
                                        ;       Child Loop BB1_59 Depth 3
                                        ;       Child Loop BB1_61 Depth 3
                                        ;       Child Loop BB1_63 Depth 3
                                        ;       Child Loop BB1_65 Depth 3
                                        ;       Child Loop BB1_67 Depth 3
                                        ;       Child Loop BB1_69 Depth 3
                                        ;       Child Loop BB1_71 Depth 3
                                        ;       Child Loop BB1_73 Depth 3
                                        ;       Child Loop BB1_75 Depth 3
                                        ;       Child Loop BB1_77 Depth 3
                                        ;       Child Loop BB1_79 Depth 3
                                        ;       Child Loop BB1_81 Depth 3
	str	q16, [sp, #3136]                ; 16-byte Spill
	str	q21, [sp, #1568]                ; 16-byte Spill
	str	q11, [sp, #3152]                ; 16-byte Spill
	str	q28, [sp, #1616]                ; 16-byte Spill
	str	q27, [sp, #1632]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	lsl	x0, x4, #4
	b	LBB1_36
LBB1_35:                                ; %direct.schedule.12.i.i
                                        ;   in Loop: Header=BB1_36 Depth=3
	str	q7, [sp, #3216]                 ; 16-byte Spill
	add.2d	v20, v17, v14
	ldr	q7, [sp, #3296]                 ; 16-byte Reload
	add.2d	v28, v17, v7
	ldr	q7, [sp, #3280]                 ; 16-byte Reload
	add.2d	v17, v17, v7
	mov.d	x2, v17[1]
	fmov	x3, d17
	add	x3, x3, x3, lsl #2
	lsl	x3, x3, #4
	fmov	d7, x3
	add	x2, x2, x2, lsl #2
	lsl	x2, x2, #4
	mov.d	v7[1], x2
	mov.d	x2, v28[1]
	fmov	x3, d28
	add	x3, x3, x3, lsl #2
	lsl	x3, x3, #4
	fmov	d28, x3
	add	x2, x2, x2, lsl #2
	lsl	x2, x2, #4
	mov.d	v28[1], x2
	mov.d	x2, v20[1]
	fmov	x3, d20
	add	x3, x3, x3, lsl #2
	lsl	x3, x3, #4
	fmov	d16, x3
	sshll2.2d	v20, v2, #0
	sshll.2d	v19, v0, #0
	sshll2.2d	v17, v0, #0
	add	x2, x2, x2, lsl #2
	lsl	x2, x2, #4
	mov.d	v16[1], x2
	add.2d	v16, v16, v27
	add.2d	v28, v28, v27
	add.2d	v7, v7, v27
	ldr	q27, [sp, #3168]                ; 16-byte Reload
	bit.16b	v27, v7, v17
	str	q27, [sp, #3168]                ; 16-byte Spill
	ldr	q7, [sp, #3184]                 ; 16-byte Reload
	bit.16b	v7, v28, v19
	str	q7, [sp, #3184]                 ; 16-byte Spill
	ldr	q7, [sp, #3200]                 ; 16-byte Reload
	bit.16b	v7, v16, v20
	str	q7, [sp, #3200]                 ; 16-byte Spill
	add	x2, x12, x1, lsl #5
	ldp	q7, q16, [x2]
	bit.16b	v16, v21, v0
	bit.16b	v7, v21, v2
	stp	q7, q16, [x2]
	add	x1, x1, #1
	cmp	x1, #1280
	b.eq	LBB1_38
LBB1_36:                                ; %direct.true179.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	w2, w1, #0xffff
	mul	w2, w2, w24
	lsr	w2, w2, #22
	add	x3, x0, x2
	dup.2d	v17, x3
	add.2d	v7, v17, v13
	mov.d	x21, v7[1]
	fmov	x19, d7
	add	x19, x19, x19, lsl #2
	lsl	x19, x19, #4
	fmov	d7, x19
	sshll.2d	v16, v2, #0
	msub	w2, w2, w23, w1
	and	x2, x2, #0xffff
	add	x19, x21, x21, lsl #2
	lsl	x19, x19, #4
	mov.d	v7[1], x19
	dup.2d	v27, x2
	add.2d	v7, v7, v27
	ldr	q19, [sp, #3216]                ; 16-byte Reload
	bif.16b	v7, v19, v16
	movi.2d	v21, #0000000000000000
	cmp	x3, #2052
	b.hi	LBB1_35
; %bb.37:                               ; %direct.true190.i.i
                                        ;   in Loop: Header=BB1_36 Depth=3
	fmov	x2, d7
	add	x2, x16, x2, lsl #2
	ld1r.4s	{ v21 }, [x2]
	b	LBB1_35
LBB1_38:                                ; %direct.true204.i.i.preheader
                                        ;   in Loop: Header=BB1_34 Depth=2
	mov	x1, #0                          ; =0x0
	b	LBB1_40
LBB1_39:                                ; %direct.schedule.17.i.i
                                        ;   in Loop: Header=BB1_40 Depth=3
	str	q7, [sp, #3264]                 ; 16-byte Spill
	add.2d	v7, v28, v14
	ldr	q16, [sp, #3296]                ; 16-byte Reload
	add.2d	v16, v28, v16
	ldr	q19, [sp, #3280]                ; 16-byte Reload
	add.2d	v19, v28, v19
	mov.d	x2, v19[1]
	fmov	x3, d19
	add	x3, x3, x3, lsl #1
	lsl	x3, x3, #5
	fmov	d19, x3
	add	x2, x2, x2, lsl #1
	lsl	x2, x2, #5
	mov.d	v19[1], x2
	mov.d	x2, v16[1]
	fmov	x3, d16
	add	x3, x3, x3, lsl #1
	lsl	x3, x3, #5
	fmov	d16, x3
	add	x2, x2, x2, lsl #1
	lsl	x2, x2, #5
	mov.d	v16[1], x2
	mov.d	x2, v7[1]
	fmov	x3, d7
	add	x3, x3, x3, lsl #1
	lsl	x3, x3, #5
	fmov	d7, x3
	sshll.2d	v28, v0, #0
	add	x2, x2, x2, lsl #1
	lsl	x2, x2, #5
	mov.d	v7[1], x2
	add.2d	v7, v7, v27
	add.2d	v16, v16, v27
	add.2d	v19, v19, v27
	ldr	q27, [sp, #3232]                ; 16-byte Reload
	bit.16b	v27, v19, v17
	str	q27, [sp, #3232]                ; 16-byte Spill
	ldr	q19, [sp, #3248]                ; 16-byte Reload
	bit.16b	v19, v16, v28
	str	q19, [sp, #3248]                ; 16-byte Spill
	bit.16b	v8, v7, v20
	add	x2, x13, x1, lsl #5
	ldp	q7, q16, [x2]
	bit.16b	v16, v21, v0
	bit.16b	v7, v21, v2
	stp	q7, q16, [x2]
	add	x1, x1, #1
	cmp	x1, #1536
	b.eq	LBB1_42
LBB1_40:                                ; %direct.true204.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	w2, w1, #0xffff
	mul	w2, w2, w28
	lsr	w2, w2, #22
	add	x3, x0, x2
	dup.2d	v28, x3
	add.2d	v7, v28, v13
	mov.d	x19, v7[1]
	fmov	x21, d7
	add	x21, x21, x21, lsl #1
	lsl	x21, x21, #5
	fmov	d7, x21
	sshll.2d	v16, v2, #0
	msub	w2, w2, w26, w1
	and	x2, x2, #0xffff
	add	x19, x19, x19, lsl #1
	lsl	x19, x19, #5
	mov.d	v7[1], x19
	dup.2d	v27, x2
	add.2d	v7, v7, v27
	ldr	q19, [sp, #3264]                ; 16-byte Reload
	bif.16b	v7, v19, v16
	movi.2d	v21, #0000000000000000
	cmp	x3, #2053
	b.hs	LBB1_39
; %bb.41:                               ; %direct.true215.i.i
                                        ;   in Loop: Header=BB1_40 Depth=3
	fmov	x2, d7
	add	x2, x17, x2, lsl #2
	ld1r.4s	{ v21 }, [x2]
	b	LBB1_39
LBB1_42:                                ; %direct.false205.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q8, [sp, #1584]                 ; 16-byte Spill
	mov	x0, #0                          ; =0x0
	sshll.2d	v7, v2, #0
	sshll.2d	v16, v0, #0
Lloh20:
	adrp	x1, lCPI1_7@PAGE
Lloh21:
	ldr	q21, [x1, lCPI1_7@PAGEOFF]
	ldr	q19, [sp, #1856]                ; 16-byte Reload
	str	q21, [sp, #2384]                ; 16-byte Spill
	bit.16b	v19, v21, v17
	str	q19, [sp, #1856]                ; 16-byte Spill
Lloh22:
	adrp	x1, lCPI1_8@PAGE
Lloh23:
	ldr	q21, [x1, lCPI1_8@PAGEOFF]
	ldr	q19, [sp, #1888]                ; 16-byte Reload
	str	q21, [sp, #2400]                ; 16-byte Spill
	bit.16b	v19, v21, v20
	str	q19, [sp, #1888]                ; 16-byte Spill
Lloh24:
	adrp	x1, lCPI1_9@PAGE
Lloh25:
	ldr	q20, [x1, lCPI1_9@PAGEOFF]
	ldr	q19, [sp, #1872]                ; 16-byte Reload
	str	q20, [sp, #2416]                ; 16-byte Spill
	bit.16b	v19, v20, v16
	str	q19, [sp, #1872]                ; 16-byte Spill
	ldr	q8, [sp, #1904]                 ; 16-byte Reload
	ldr	q16, [sp, #2208]                ; 16-byte Reload
	bit.16b	v8, v16, v7
	ldr	q28, [sp, #2640]                ; 16-byte Reload
	bic.16b	v28, v28, v0
	ldr	q27, [sp, #2656]                ; 16-byte Reload
	bic.16b	v27, v27, v2
	ldr	q21, [sp, #2688]                ; 16-byte Reload
	ldr	q11, [sp, #3120]                ; 16-byte Reload
LBB1_43:                                ; %direct.true229.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	d7, x0
	orr.16b	v16, v7, v11
	fmov	x1, d16
	add	x1, x10, x1
	ldp	q16, q19, [x1]
	orr.16b	v7, v7, v8
	fmov	x1, d7
	add	x1, x12, x1
	ldp	q7, q20, [x1]
	fmul.4s	v19, v19, v20
	fmul.4s	v7, v16, v7
	fadd.4s	v7, v27, v7
	fadd.4s	v16, v28, v19
	bit.16b	v28, v16, v0
	bit.16b	v27, v7, v2
	add	x0, x0, #32
	cmp	x0, #2560
	b.ne	LBB1_43
; %bb.44:                               ; %direct.false230.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q8, [sp, #1904]                 ; 16-byte Spill
	str	q28, [sp, #2640]                ; 16-byte Spill
	str	q27, [sp, #2656]                ; 16-byte Spill
	ldr	q8, [sp, #2672]                 ; 16-byte Reload
	and.16b	v8, v9, v8
	and.16b	v15, v10, v15
	mov	x0, x10
	mov	w1, #80                         ; =0x50
	ldr	q27, [sp, #2896]                ; 16-byte Reload
	ldr	q28, [sp, #2880]                ; 16-byte Reload
LBB1_45:                                ; %direct.true244.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q16, [x0]
	ldr	q19, [x0, #11264]
	ldr	q20, [x0, #11280]
	fmul.4s	v16, v16, v20
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v15, v7
	fadd.4s	v16, v8, v16
	bit.16b	v8, v16, v0
	bit.16b	v15, v7, v2
	add	x0, x0, #32
	subs	x1, x1, #1
	b.ne	LBB1_45
; %bb.46:                               ; %direct.false245.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q8, [sp, #2672]                 ; 16-byte Spill
	str	q15, [sp, #2432]                ; 16-byte Spill
	and.16b	v21, v9, v21
	and.16b	v30, v10, v30
	mov	x0, x10
	mov	w1, #80                         ; =0x50
	ldr	q15, [sp, #1984]                ; 16-byte Reload
LBB1_47:                                ; %direct.true261.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q16, [x0]
	ldr	q19, [x0, #13824]
	ldr	q20, [x0, #13840]
	fmul.4s	v16, v16, v20
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v30, v7
	fadd.4s	v16, v21, v16
	bit.16b	v21, v16, v0
	bit.16b	v30, v7, v2
	add	x0, x0, #32
	subs	x1, x1, #1
	b.ne	LBB1_47
; %bb.48:                               ; %direct.false262.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q21, [sp, #2688]                ; 16-byte Spill
	str	q30, [sp, #2448]                ; 16-byte Spill
	ldr	q30, [sp, #2704]                ; 16-byte Reload
	and.16b	v30, v9, v30
	and.16b	v18, v10, v18
	mov	x0, x10
	mov	w1, #80                         ; =0x50
LBB1_49:                                ; %direct.true278.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q16, [x0]
	ldr	q19, [x0, #16384]
	ldr	q20, [x0, #16400]
	fmul.4s	v16, v16, v20
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v18, v7
	fadd.4s	v16, v30, v16
	bit.16b	v30, v16, v0
	bit.16b	v18, v7, v2
	add	x0, x0, #32
	subs	x1, x1, #1
	b.ne	LBB1_49
; %bb.50:                               ; %direct.false279.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q30, [sp, #2704]                ; 16-byte Spill
	str	q18, [sp, #2464]                ; 16-byte Spill
	ldr	q18, [sp, #2720]                ; 16-byte Reload
	and.16b	v18, v9, v18
	and.16b	v26, v10, v26
	mov	x0, x10
	mov	w1, #80                         ; =0x50
	ldr	q21, [sp, #2672]                ; 16-byte Reload
LBB1_51:                                ; %direct.true295.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q16, [x0]
	ldr	q19, [x0, #18944]
	ldr	q20, [x0, #18960]
	fmul.4s	v16, v16, v20
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v26, v7
	fadd.4s	v16, v18, v16
	bit.16b	v18, v16, v0
	bit.16b	v26, v7, v2
	add	x0, x0, #32
	subs	x1, x1, #1
	b.ne	LBB1_51
; %bb.52:                               ; %direct.false296.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q18, [sp, #2720]                ; 16-byte Spill
	str	q26, [sp, #2480]                ; 16-byte Spill
	ldr	q26, [sp, #2736]                ; 16-byte Reload
	and.16b	v26, v9, v26
	and.16b	v29, v10, v29
	mov	x0, x10
	mov	w1, #80                         ; =0x50
	ldr	q30, [sp, #2448]                ; 16-byte Reload
LBB1_53:                                ; %direct.true312.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q16, [x0]
	ldr	q19, [x0, #21504]
	ldr	q20, [x0, #21520]
	fmul.4s	v16, v16, v20
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v29, v7
	fadd.4s	v16, v26, v16
	bit.16b	v26, v16, v0
	bit.16b	v29, v7, v2
	add	x0, x0, #32
	subs	x1, x1, #1
	b.ne	LBB1_53
; %bb.54:                               ; %direct.false313.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q26, [sp, #2736]                ; 16-byte Spill
	str	q29, [sp, #2496]                ; 16-byte Spill
	ldr	q29, [sp, #2752]                ; 16-byte Reload
	and.16b	v29, v9, v29
	and.16b	v25, v10, v25
	mov	x0, x10
	mov	w1, #80                         ; =0x50
	ldr	q18, [sp, #2464]                ; 16-byte Reload
LBB1_55:                                ; %direct.true329.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q16, [x0]
	ldr	q19, [x0, #24064]
	ldr	q20, [x0, #24080]
	fmul.4s	v16, v16, v20
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v25, v7
	fadd.4s	v16, v29, v16
	bit.16b	v29, v16, v0
	bit.16b	v25, v7, v2
	add	x0, x0, #32
	subs	x1, x1, #1
	b.ne	LBB1_55
; %bb.56:                               ; %direct.false330.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q29, [sp, #2752]                ; 16-byte Spill
	str	q25, [sp, #2512]                ; 16-byte Spill
	ldr	q25, [sp, #2768]                ; 16-byte Reload
	and.16b	v25, v9, v25
	and.16b	v24, v10, v24
	mov	x0, x10
	mov	w1, #80                         ; =0x50
	ldr	q11, [sp, #2480]                ; 16-byte Reload
LBB1_57:                                ; %direct.true346.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q16, [x0]
	ldr	q19, [x0, #26624]
	ldr	q20, [x0, #26640]
	fmul.4s	v16, v16, v20
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v24, v7
	fadd.4s	v16, v25, v16
	bit.16b	v25, v16, v0
	bit.16b	v24, v7, v2
	add	x0, x0, #32
	subs	x1, x1, #1
	b.ne	LBB1_57
; %bb.58:                               ; %direct.false347.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q25, [sp, #2768]                ; 16-byte Spill
	str	q24, [sp, #2528]                ; 16-byte Spill
	ldr	q24, [sp, #2784]                ; 16-byte Reload
	and.16b	v24, v9, v24
	and.16b	v23, v10, v23
	mov	x0, x10
	mov	w1, #80                         ; =0x50
	ldr	q12, [sp, #2496]                ; 16-byte Reload
LBB1_59:                                ; %direct.true363.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q16, [x0]
	ldr	q19, [x0, #29184]
	ldr	q20, [x0, #29200]
	fmul.4s	v16, v16, v20
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v23, v7
	fadd.4s	v16, v24, v16
	bit.16b	v24, v16, v0
	bit.16b	v23, v7, v2
	add	x0, x0, #32
	subs	x1, x1, #1
	b.ne	LBB1_59
; %bb.60:                               ; %direct.false364.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q24, [sp, #2784]                ; 16-byte Spill
	str	q23, [sp, #2544]                ; 16-byte Spill
	ldr	q23, [sp, #2800]                ; 16-byte Reload
	and.16b	v23, v9, v23
	and.16b	v22, v10, v22
	mov	x0, x10
	mov	w1, #80                         ; =0x50
	ldr	q25, [sp, #2512]                ; 16-byte Reload
LBB1_61:                                ; %direct.true380.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q16, [x0]
	ldr	q19, [x0, #31744]
	ldr	q20, [x0, #31760]
	fmul.4s	v16, v16, v20
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v22, v7
	fadd.4s	v16, v23, v16
	bit.16b	v23, v16, v0
	bit.16b	v22, v7, v2
	add	x0, x0, #32
	subs	x1, x1, #1
	b.ne	LBB1_61
; %bb.62:                               ; %direct.false381.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q23, [sp, #2800]                ; 16-byte Spill
	str	q22, [sp, #2560]                ; 16-byte Spill
	ldr	q22, [sp, #2816]                ; 16-byte Reload
	and.16b	v22, v9, v22
	and.16b	v5, v10, v5
	mov	x0, x10
	mov	w1, #80                         ; =0x50
	ldr	q24, [sp, #2528]                ; 16-byte Reload
LBB1_63:                                ; %direct.true397.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q16, [x0]
	ldr	q19, [x0, #34304]
	ldr	q20, [x0, #34320]
	fmul.4s	v16, v16, v20
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v5, v7
	fadd.4s	v16, v22, v16
	bit.16b	v22, v16, v0
	bit.16b	v5, v7, v2
	add	x0, x0, #32
	subs	x1, x1, #1
	b.ne	LBB1_63
; %bb.64:                               ; %direct.false398.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q22, [sp, #2816]                ; 16-byte Spill
	str	q5, [sp, #2576]                 ; 16-byte Spill
	ldr	q5, [sp, #2832]                 ; 16-byte Reload
	and.16b	v5, v9, v5
	and.16b	v4, v10, v4
	mov	x0, x10
	mov	w1, #80                         ; =0x50
	ldr	q23, [sp, #2544]                ; 16-byte Reload
LBB1_65:                                ; %direct.true414.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q16, [x0]
	ldr	q19, [x0, #36864]
	ldr	q20, [x0, #36880]
	fmul.4s	v16, v16, v20
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v4, v7
	fadd.4s	v16, v5, v16
	bit.16b	v5, v16, v0
	bit.16b	v4, v7, v2
	add	x0, x0, #32
	subs	x1, x1, #1
	b.ne	LBB1_65
; %bb.66:                               ; %direct.false415.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q5, [sp, #2832]                 ; 16-byte Spill
	str	q4, [sp, #2592]                 ; 16-byte Spill
	ldr	q4, [sp, #2848]                 ; 16-byte Reload
	and.16b	v4, v9, v4
	and.16b	v3, v10, v3
	mov	x0, x10
	mov	w1, #80                         ; =0x50
	ldr	q22, [sp, #2560]                ; 16-byte Reload
LBB1_67:                                ; %direct.true431.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q16, [x0]
	ldr	q19, [x0, #39424]
	ldr	q20, [x0, #39440]
	fmul.4s	v16, v16, v20
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v3, v7
	fadd.4s	v16, v4, v16
	bit.16b	v4, v16, v0
	bit.16b	v3, v7, v2
	add	x0, x0, #32
	subs	x1, x1, #1
	b.ne	LBB1_67
; %bb.68:                               ; %direct.false432.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q4, [sp, #2848]                 ; 16-byte Spill
	str	q3, [sp, #2608]                 ; 16-byte Spill
	ldr	q3, [sp, #2864]                 ; 16-byte Reload
	and.16b	v3, v9, v3
	and.16b	v28, v10, v28
	mov	x0, x10
	mov	w1, #80                         ; =0x50
	ldr	q5, [sp, #2576]                 ; 16-byte Reload
LBB1_69:                                ; %direct.true448.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q16, [x0]
	ldr	q19, [x0, #41984]
	ldr	q20, [x0, #42000]
	fmul.4s	v16, v16, v20
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v28, v7
	fadd.4s	v16, v3, v16
	bit.16b	v3, v16, v0
	bit.16b	v28, v7, v2
	add	x0, x0, #32
	subs	x1, x1, #1
	b.ne	LBB1_69
; %bb.70:                               ; %direct.false449.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q3, [sp, #2864]                 ; 16-byte Spill
	and.16b	v27, v9, v27
	and.16b	v6, v10, v6
	mov	x0, x10
	mov	w1, #80                         ; =0x50
	ldr	q4, [sp, #2592]                 ; 16-byte Reload
LBB1_71:                                ; %direct.true465.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q16, [x0]
	ldr	q19, [x0, #44544]
	ldr	q20, [x0, #44560]
	fmul.4s	v16, v16, v20
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v6, v7
	fadd.4s	v16, v27, v16
	bit.16b	v27, v16, v0
	bit.16b	v6, v7, v2
	add	x0, x0, #32
	subs	x1, x1, #1
	b.ne	LBB1_71
; %bb.72:                               ; %direct.false466.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q28, [sp, #2880]                ; 16-byte Spill
	str	q27, [sp, #2896]                ; 16-byte Spill
	str	q6, [sp, #2624]                 ; 16-byte Spill
	and.16b	v31, v9, v31
	and.16b	v15, v10, v15
	mov	x0, x10
	mov	w1, #80                         ; =0x50
	ldr	q3, [sp, #2608]                 ; 16-byte Reload
LBB1_73:                                ; %direct.true482.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q16, [x0]
	ldr	q19, [x0, #47104]
	ldr	q20, [x0, #47120]
	fmul.4s	v16, v16, v20
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v15, v7
	fadd.4s	v16, v31, v16
	bit.16b	v31, v16, v0
	bit.16b	v15, v7, v2
	add	x0, x0, #32
	subs	x1, x1, #1
	b.ne	LBB1_73
; %bb.74:                               ; %direct.false483.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q1, [sp, #2912]                 ; 16-byte Spill
	mov	x0, #0                          ; =0x0
	mov	w1, #63790                      ; =0xf92e
	movk	w1, #15844, lsl #16
	dup.4s	v20, w1
	ldr	q6, [sp, #2656]                 ; 16-byte Reload
	fmul.4s	v19, v6, v20
	ldr	q6, [sp, #2640]                 ; 16-byte Reload
	fmul.4s	v1, v6, v20
	mov	w1, #33280                      ; =0x8200
	movk	w1, #1, lsl #16
	add	x1, x10, x1
	ldp	q7, q16, [x1]
	ldr	q6, [sp, #2432]                 ; 16-byte Reload
	fmul.4s	v27, v6, v20
	cmp	x4, #128
	mov.16b	v26, v1
	bit.16b	v16, v1, v0
	mov.16b	v29, v19
	bit.16b	v7, v19, v2
	stp	q7, q16, [x1]
	cset	w1, lo
	dup.4h	v7, w1
	fmul.4s	v1, v21, v20
	fmul.4s	v10, v30, v20
	ldr	q6, [sp, #2688]                 ; 16-byte Reload
	fmul.4s	v9, v6, v20
	fmul.4s	v8, v18, v20
	ldp	x2, x3, [sp, #496]              ; 16-byte Folded Reload
	ldp	q16, q19, [x3]
	ldr	q6, [sp, #2704]                 ; 16-byte Reload
	fmul.4s	v30, v6, v20
	fmul.4s	v18, v11, v20
	str	q1, [sp, #2368]                 ; 16-byte Spill
	bit.16b	v19, v1, v0
	str	q27, [sp, #2352]                ; 16-byte Spill
	bit.16b	v16, v27, v2
	stp	q16, q19, [x3]
	ldr	q6, [sp, #2720]                 ; 16-byte Reload
	fmul.4s	v1, v6, v20
	ldr	q6, [sp, #2736]                 ; 16-byte Reload
	fmul.4s	v16, v6, v20
	fmul.4s	v19, v12, v20
	mov.16b	v6, v31
	ldp	q21, q27, [x2]
	ldr	q28, [sp, #2752]                ; 16-byte Reload
	fmul.4s	v28, v28, v20
	str	q9, [sp, #2272]                 ; 16-byte Spill
	bit.16b	v27, v9, v0
	str	q10, [sp, #2256]                ; 16-byte Spill
	bit.16b	v21, v10, v2
	stp	q21, q27, [x2]
	fmul.4s	v27, v25, v20
	ldr	q21, [sp, #2768]                ; 16-byte Reload
	fmul.4s	v25, v21, v20
	fmul.4s	v31, v24, v20
	ldr	x2, [sp, #488]                  ; 8-byte Reload
	ldp	q21, q9, [x2]
	ldr	q24, [sp, #2784]                ; 16-byte Reload
	fmul.4s	v24, v24, v20
	str	q30, [sp, #1504]                ; 16-byte Spill
	bit.16b	v9, v30, v0
	str	q8, [sp, #1488]                 ; 16-byte Spill
	bit.16b	v21, v8, v2
	stp	q21, q9, [x2]
	fmul.4s	v9, v23, v20
	fmul.4s	v22, v22, v20
	ldr	q21, [sp, #2800]                ; 16-byte Reload
	fmul.4s	v23, v21, v20
	ldr	x2, [sp, #480]                  ; 8-byte Reload
	ldp	q21, q10, [x2]
	ushll.4s	v7, v7, #0
	str	q1, [sp, #1408]                 ; 16-byte Spill
	bit.16b	v10, v1, v0
	str	q18, [sp, #1392]                ; 16-byte Spill
	bit.16b	v21, v18, v2
	stp	q21, q10, [x2]
	shl.4s	v7, v7, #31
	cmlt.4s	v21, v7, #0
	ldr	q14, [sp, #544]                 ; 16-byte Reload
	mov.16b	v1, v21
	bsl.16b	v1, v19, v14
	ldr	x2, [sp, #472]                  ; 8-byte Reload
	ldp	q7, q19, [x2]
	bif.16b	v16, v14, v21
	str	q16, [sp, #1296]                ; 16-byte Spill
	bif.16b	v16, v19, v0
	str	q1, [sp, #1312]                 ; 16-byte Spill
	bit.16b	v7, v1, v2
	stp	q7, q16, [x2]
	fmul.4s	v7, v5, v20
	ldr	q5, [sp, #2816]                 ; 16-byte Reload
	fmul.4s	v16, v5, v20
	mov.16b	v1, v21
	bsl.16b	v1, v27, v14
	ldr	x2, [sp, #464]                  ; 8-byte Reload
	ldp	q19, q27, [x2]
	mov.16b	v5, v21
	bsl.16b	v5, v28, v14
	str	q5, [sp, #1200]                 ; 16-byte Spill
	bit.16b	v27, v5, v0
	str	q1, [sp, #1216]                 ; 16-byte Spill
	bit.16b	v19, v1, v2
	stp	q19, q27, [x2]
	fmul.4s	v19, v4, v20
	ldr	q4, [sp, #2832]                 ; 16-byte Reload
	fmul.4s	v27, v4, v20
	mov.16b	v1, v21
	bsl.16b	v1, v31, v14
	ldr	x2, [sp, #456]                  ; 8-byte Reload
	ldp	q28, q10, [x2]
	mov.16b	v4, v21
	bsl.16b	v4, v25, v14
	str	q4, [sp, #1104]                 ; 16-byte Spill
	bit.16b	v10, v4, v0
	str	q1, [sp, #1120]                 ; 16-byte Spill
	bit.16b	v28, v1, v2
	stp	q28, q10, [x2]
	fmul.4s	v28, v3, v20
	ldr	q3, [sp, #2848]                 ; 16-byte Reload
	fmul.4s	v10, v3, v20
	mov.16b	v1, v21
	bsl.16b	v1, v9, v14
	ldr	x2, [sp, #448]                  ; 8-byte Reload
	ldp	q9, q11, [x2]
	mov.16b	v3, v21
	bsl.16b	v3, v24, v14
	stp	q3, q1, [sp, #1008]             ; 32-byte Folded Spill
	bit.16b	v11, v3, v0
	bit.16b	v9, v1, v2
	stp	q9, q11, [x2]
	ldr	q3, [sp, #2864]                 ; 16-byte Reload
	fmul.4s	v9, v3, v20
	ldr	q11, [sp, #2880]                ; 16-byte Reload
	fmul.4s	v11, v11, v20
	mov.16b	v1, v21
	bsl.16b	v1, v23, v14
	ldr	x2, [sp, #440]                  ; 8-byte Reload
	ldp	q13, q12, [x2]
	mov.16b	v3, v21
	bsl.16b	v3, v22, v14
	str	q3, [sp, #1040]                 ; 16-byte Spill
	bit.16b	v13, v3, v2
	str	q1, [sp, #1056]                 ; 16-byte Spill
	bit.16b	v12, v1, v0
	stp	q13, q12, [x2]
	mov.16b	v1, v21
	bsl.16b	v1, v16, v14
	mov.16b	v3, v21
	bsl.16b	v3, v7, v14
	mov.16b	v4, v21
	bsl.16b	v4, v27, v14
	ldr	x2, [sp, #432]                  ; 8-byte Reload
	ldp	q16, q7, [x2]
	mov.16b	v5, v21
	bsl.16b	v5, v19, v14
	str	q3, [sp, #1136]                 ; 16-byte Spill
	bit.16b	v16, v3, v2
	str	q1, [sp, #1152]                 ; 16-byte Spill
	bit.16b	v7, v1, v0
	stp	q16, q7, [x2]
	mov.16b	v1, v21
	bsl.16b	v1, v10, v14
	mov.16b	v3, v21
	bsl.16b	v3, v28, v14
	ldr	x2, [sp, #424]                  ; 8-byte Reload
	ldp	q16, q7, [x2]
	str	q5, [sp, #1232]                 ; 16-byte Spill
	bit.16b	v16, v5, v2
	str	q4, [sp, #1248]                 ; 16-byte Spill
	bit.16b	v7, v4, v0
	stp	q16, q7, [x2]
	ldr	x2, [sp, #416]                  ; 8-byte Reload
	ldp	q16, q7, [x2]
	str	q3, [sp, #1328]                 ; 16-byte Spill
	bit.16b	v16, v3, v2
	str	q1, [sp, #1344]                 ; 16-byte Spill
	bit.16b	v7, v1, v0
	stp	q16, q7, [x2]
	ldr	q7, [sp, #2624]                 ; 16-byte Reload
	fmul.4s	v7, v7, v20
	ldr	q16, [sp, #2896]                ; 16-byte Reload
	fmul.4s	v16, v16, v20
	str	q15, [sp, #1984]                ; 16-byte Spill
	fmul.4s	v19, v15, v20
	str	q6, [sp, #1600]                 ; 16-byte Spill
	fmul.4s	v20, v6, v20
	mov.16b	v6, v21
	bsl.16b	v6, v11, v14
	mov.16b	v18, v21
	bsl.16b	v18, v9, v14
	mov.16b	v4, v21
	bsl.16b	v4, v16, v14
	mov.16b	v5, v21
	bsl.16b	v5, v7, v14
	mov.16b	v1, v21
	bsl.16b	v1, v20, v14
	mov.16b	v3, v21
	bsl.16b	v3, v19, v14
	ldr	x2, [sp, #408]                  ; 8-byte Reload
	ldp	q16, q7, [x2]
	str	q18, [sp, #1424]                ; 16-byte Spill
	bit.16b	v7, v18, v0
	str	q6, [sp, #1440]                 ; 16-byte Spill
	bit.16b	v16, v6, v2
	stp	q16, q7, [x2]
	ldr	x2, [sp, #400]                  ; 8-byte Reload
	ldp	q7, q16, [x2]
	str	q5, [sp, #1536]                 ; 16-byte Spill
	bit.16b	v7, v5, v2
	str	q4, [sp, #1552]                 ; 16-byte Spill
	bit.16b	v16, v4, v0
	stp	q7, q16, [x2]
	ldr	x2, [sp, #392]                  ; 8-byte Reload
	ldp	q7, q16, [x2]
	str	q3, [sp, #2288]                 ; 16-byte Spill
	bit.16b	v7, v3, v2
	str	q1, [sp, #2304]                 ; 16-byte Spill
	bit.16b	v16, v1, v0
	stp	q7, q16, [x2]
	mvni.4s	v7, #127, msl #16
	ldr	q20, [sp, #2000]                ; 16-byte Reload
	bit.16b	v20, v7, v0
	mvni.4s	v9, #127, msl #16
	ldr	q19, [sp, #2016]                ; 16-byte Reload
	bit.16b	v19, v7, v2
	dup.8b	v3, w1
	str	d3, [sp, #1520]                 ; 8-byte Spill
LBB1_75:                                ; %direct.true596.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x1, x14, x0
	ldp	q7, q16, [x1]
	and.16b	v16, v0, v16
	and.16b	v7, v2, v7
	fmaxnm.4s	v7, v19, v7
	fmaxnm.4s	v16, v20, v16
	bit.16b	v20, v16, v0
	bit.16b	v19, v7, v2
	add	x0, x0, #32
	cmp	x0, #512
	b.ne	LBB1_75
; %bb.76:                               ; %direct.false597.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	mov	x0, #0                          ; =0x0
	ldr	q3, [sp, #1920]                 ; 16-byte Reload
	ldr	q1, [sp, #2384]                 ; 16-byte Reload
	bit.16b	v3, v1, v17
	str	q3, [sp, #1920]                 ; 16-byte Spill
	ldr	q7, [sp, #2160]                 ; 16-byte Reload
	bit.16b	v7, v1, v17
	str	q7, [sp, #2160]                 ; 16-byte Spill
	str	q19, [sp, #2016]                ; 16-byte Spill
	ldr	q1, [sp, #2928]                 ; 16-byte Reload
	fmaxnm.4s	v30, v1, v19
	fsub.4s	v7, v29, v30
	ldp	q1, q16, [sp, #592]             ; 32-byte Folded Reload
	cmhi.4s	v17, v1, v16
	and.16b	v14, v17, v7
	mov	w1, #-1026555904                ; =0xc2d00000
	dup.4s	v23, w1
	fcmge.4s	v7, v14, v23
	mov	w1, #1120403456                 ; =0x42c80000
	dup.4s	v22, w1
	fcmge.4s	v16, v22, v14
	and.16b	v7, v7, v16
	str	q20, [sp, #2000]                ; 16-byte Spill
	ldr	q1, [sp, #2944]                 ; 16-byte Reload
	fmaxnm.4s	v6, v1, v20
	fsub.4s	v16, v26, v6
	and.16b	v26, v0, v16
	fcmge.4s	v16, v26, v23
	fcmge.4s	v19, v22, v26
	and.16b	v16, v16, v19
	and.16b	v16, v16, v26
	mov	w1, #43579                      ; =0xaa3b
	movk	w1, #16312, lsl #16
	dup.4s	v31, w1
	fmul.4s	v19, v16, v31
	movi.4s	v10, #75, lsl #24
	mvni.4s	v11, #128, lsl #24
	mov.16b	v20, v11
	bsl.16b	v20, v10, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v7, v7, v14
	fmul.4s	v20, v7, v31
	mov.16b	v21, v11
	bsl.16b	v21, v10, v20
	fadd.4s	v20, v20, v21
	fsub.4s	v21, v20, v21
	fcvtzs.4s	v20, v19
	scvtf.4s	v19, v20
	mov	w1, #29184                      ; =0x7200
	movk	w1, #16177, lsl #16
	dup.4s	v15, w1
	fmul.4s	v27, v19, v15
	fsub.4s	v16, v16, v27
	fcvtzs.4s	v21, v21
	scvtf.4s	v27, v21
	fmul.4s	v28, v27, v15
	fsub.4s	v7, v7, v28
	mov	w1, #48782                      ; =0xbe8e
	movk	w1, #13759, lsl #16
	dup.4s	v25, w1
	fmul.4s	v27, v27, v25
	fsub.4s	v7, v7, v27
	fmul.4s	v19, v19, v25
	fsub.4s	v16, v16, v19
	mov	w1, #11226                      ; =0x2bda
	movk	w1, #14672, lsl #16
	dup.4s	v29, w1
	fmul.4s	v19, v16, v29
	mov	w1, #38601                      ; =0x96c9
	movk	w1, #15030, lsl #16
	dup.4s	v8, w1
	fadd.4s	v19, v19, v8
	fmul.4s	v19, v16, v19
	mov	w1, #34982                      ; =0x88a6
	movk	w1, #15368, lsl #16
	dup.4s	v5, w1
	fadd.4s	v19, v19, v5
	mov	w1, #43642                      ; =0xaa7a
	movk	w1, #15658, lsl #16
	dup.4s	v3, w1
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v3
	fmul.4s	v19, v16, v19
	mov	w1, #43691                      ; =0xaaab
	movk	w1, #15914, lsl #16
	dup.4s	v4, w1
	fadd.4s	v19, v19, v4
	fmul.4s	v19, v16, v19
	movi.4s	v12, #63, lsl #24
	fadd.4s	v19, v19, v12
	fmul.4s	v27, v16, v16
	fmul.4s	v19, v27, v19
	fmul.4s	v27, v7, v29
	fadd.4s	v27, v27, v8
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v5
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v3
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v4
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v12
	fmul.4s	v28, v7, v7
	fmul.4s	v27, v28, v27
	fadd.4s	v7, v7, v27
	fadd.4s	v16, v16, v19
	fmov.4s	v13, #1.00000000
	fadd.4s	v7, v7, v13
	sshr.4s	v19, v21, #1
	shl.4s	v27, v19, #23
	add.4s	v27, v27, v13
	fmul.4s	v7, v7, v27
	fadd.4s	v16, v16, v13
	sshr.4s	v27, v20, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v13
	fmul.4s	v16, v16, v28
	sub.4s	v19, v21, v19
	sub.4s	v20, v20, v27
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v16, v16, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v7, v7, v19
	fcmgt.4s	v19, v23, v14
	bic.16b	v7, v7, v19
	str	q26, [sp, #2336]                ; 16-byte Spill
	fcmgt.4s	v19, v23, v26
	bic.16b	v16, v16, v19
	fcmgt.4s	v19, v26, v22
	fneg.4s	v18, v9
	bit.16b	v16, v18, v19
	str	q16, [sp, #2320]                ; 16-byte Spill
	fcmgt.4s	v16, v14, v22
	bit.16b	v7, v18, v16
	str	q7, [sp, #2384]                 ; 16-byte Spill
	ldr	q1, [sp, #2352]                 ; 16-byte Reload
	fsub.4s	v7, v1, v30
	and.16b	v24, v17, v7
	fcmge.4s	v7, v24, v23
	fcmge.4s	v16, v22, v24
	and.16b	v7, v7, v16
	ldr	q1, [sp, #2368]                 ; 16-byte Reload
	fsub.4s	v16, v1, v6
	and.16b	v26, v0, v16
	fcmge.4s	v16, v26, v23
	fcmge.4s	v19, v22, v26
	and.16b	v16, v16, v19
	and.16b	v16, v16, v26
	fmul.4s	v19, v16, v31
	mov.16b	v20, v11
	bsl.16b	v20, v10, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v7, v7, v24
	fmul.4s	v20, v7, v31
	mov.16b	v21, v11
	bsl.16b	v21, v10, v20
	fadd.4s	v20, v20, v21
	fsub.4s	v21, v20, v21
	fcvtzs.4s	v20, v19
	scvtf.4s	v19, v20
	fmul.4s	v27, v19, v15
	fsub.4s	v16, v16, v27
	fcvtzs.4s	v21, v21
	scvtf.4s	v27, v21
	fmul.4s	v28, v27, v15
	fsub.4s	v7, v7, v28
	fmul.4s	v27, v27, v25
	fsub.4s	v7, v7, v27
	fmul.4s	v19, v19, v25
	fsub.4s	v16, v16, v19
	fmul.4s	v19, v16, v29
	fadd.4s	v19, v19, v8
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v5
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v3
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v4
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v27, v16, v16
	fmul.4s	v19, v27, v19
	fmul.4s	v27, v7, v29
	fadd.4s	v27, v27, v8
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v5
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v3
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v4
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v12
	fmul.4s	v28, v7, v7
	fmul.4s	v27, v28, v27
	fadd.4s	v7, v7, v27
	fadd.4s	v16, v16, v19
	fadd.4s	v7, v7, v13
	sshr.4s	v19, v21, #1
	shl.4s	v27, v19, #23
	add.4s	v27, v27, v13
	fmul.4s	v7, v7, v27
	fadd.4s	v16, v16, v13
	sshr.4s	v27, v20, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v13
	fmul.4s	v16, v16, v28
	sub.4s	v19, v21, v19
	sub.4s	v20, v20, v27
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v16, v16, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v7, v7, v19
	str	q24, [sp, #2240]                ; 16-byte Spill
	fcmgt.4s	v19, v23, v24
	bic.16b	v7, v7, v19
	str	q26, [sp, #992]                 ; 16-byte Spill
	fcmgt.4s	v19, v23, v26
	bic.16b	v16, v16, v19
	fcmgt.4s	v19, v26, v22
	bit.16b	v16, v18, v19
	str	q16, [sp, #2368]                ; 16-byte Spill
	fcmgt.4s	v16, v24, v22
	bit.16b	v7, v18, v16
	str	q7, [sp, #2352]                 ; 16-byte Spill
	ldr	q1, [sp, #2256]                 ; 16-byte Reload
	fsub.4s	v7, v1, v30
	and.16b	v24, v17, v7
	fcmge.4s	v7, v24, v23
	fcmge.4s	v16, v22, v24
	and.16b	v7, v7, v16
	ldr	q1, [sp, #2272]                 ; 16-byte Reload
	fsub.4s	v16, v1, v6
	and.16b	v9, v0, v16
	fcmge.4s	v16, v9, v23
	fcmge.4s	v19, v22, v9
	and.16b	v16, v16, v19
	and.16b	v16, v16, v9
	fmul.4s	v19, v16, v31
	mov.16b	v20, v11
	bsl.16b	v20, v10, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v7, v7, v24
	fmul.4s	v20, v7, v31
	mov.16b	v21, v11
	bsl.16b	v21, v10, v20
	fadd.4s	v20, v20, v21
	fsub.4s	v21, v20, v21
	fcvtzs.4s	v20, v19
	scvtf.4s	v19, v20
	fmul.4s	v27, v19, v15
	fsub.4s	v16, v16, v27
	fcvtzs.4s	v21, v21
	scvtf.4s	v27, v21
	fmul.4s	v28, v27, v15
	fsub.4s	v7, v7, v28
	fmul.4s	v27, v27, v25
	fsub.4s	v7, v7, v27
	fmul.4s	v19, v19, v25
	fsub.4s	v16, v16, v19
	fmul.4s	v19, v16, v29
	fadd.4s	v19, v19, v8
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v5
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v3
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v4
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v27, v16, v16
	fmul.4s	v19, v27, v19
	fmul.4s	v27, v7, v29
	fadd.4s	v27, v27, v8
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v5
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v3
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v4
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v12
	fmul.4s	v28, v7, v7
	fmul.4s	v27, v28, v27
	fadd.4s	v7, v7, v27
	fadd.4s	v16, v16, v19
	fadd.4s	v7, v7, v13
	sshr.4s	v19, v21, #1
	shl.4s	v27, v19, #23
	add.4s	v27, v27, v13
	fmul.4s	v7, v7, v27
	fadd.4s	v16, v16, v13
	sshr.4s	v27, v20, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v13
	fmul.4s	v16, v16, v28
	sub.4s	v19, v21, v19
	sub.4s	v20, v20, v27
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v16, v16, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v7, v7, v19
	str	q24, [sp, #1472]                ; 16-byte Spill
	fcmgt.4s	v19, v23, v24
	bic.16b	v7, v7, v19
	str	q9, [sp, #2224]                 ; 16-byte Spill
	fcmgt.4s	v19, v23, v9
	bic.16b	v16, v16, v19
	fcmgt.4s	v19, v9, v22
	bit.16b	v16, v18, v19
	str	q16, [sp, #2272]                ; 16-byte Spill
	fcmgt.4s	v16, v24, v22
	bit.16b	v7, v18, v16
	str	q7, [sp, #2256]                 ; 16-byte Spill
	ldr	q1, [sp, #1488]                 ; 16-byte Reload
	fsub.4s	v7, v1, v30
	and.16b	v24, v17, v7
	fcmge.4s	v7, v24, v23
	fcmge.4s	v16, v22, v24
	and.16b	v7, v7, v16
	ldr	q1, [sp, #1504]                 ; 16-byte Reload
	fsub.4s	v16, v1, v6
	and.16b	v9, v0, v16
	fcmge.4s	v16, v9, v23
	fcmge.4s	v19, v22, v9
	and.16b	v16, v16, v19
	and.16b	v16, v16, v9
	fmul.4s	v19, v16, v31
	mov.16b	v20, v11
	bsl.16b	v20, v10, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v7, v7, v24
	fmul.4s	v20, v7, v31
	mov.16b	v21, v11
	bsl.16b	v21, v10, v20
	fadd.4s	v20, v20, v21
	fsub.4s	v21, v20, v21
	fcvtzs.4s	v20, v19
	scvtf.4s	v19, v20
	fmul.4s	v27, v19, v15
	fsub.4s	v16, v16, v27
	fcvtzs.4s	v21, v21
	scvtf.4s	v27, v21
	fmul.4s	v28, v27, v15
	fsub.4s	v7, v7, v28
	fmul.4s	v27, v27, v25
	fsub.4s	v7, v7, v27
	fmul.4s	v19, v19, v25
	fsub.4s	v16, v16, v19
	fmul.4s	v19, v16, v29
	fadd.4s	v19, v19, v8
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v5
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v3
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v4
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v27, v16, v16
	fmul.4s	v19, v27, v19
	fmul.4s	v27, v7, v29
	fadd.4s	v27, v27, v8
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v5
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v3
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v4
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v12
	fmul.4s	v28, v7, v7
	fmul.4s	v27, v28, v27
	fadd.4s	v7, v7, v27
	fadd.4s	v16, v16, v19
	fadd.4s	v7, v7, v13
	sshr.4s	v19, v21, #1
	shl.4s	v27, v19, #23
	add.4s	v27, v27, v13
	fmul.4s	v7, v7, v27
	fadd.4s	v16, v16, v13
	sshr.4s	v27, v20, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v13
	fmul.4s	v16, v16, v28
	sub.4s	v19, v21, v19
	sub.4s	v20, v20, v27
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v16, v16, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v7, v7, v19
	str	q24, [sp, #1376]                ; 16-byte Spill
	fcmgt.4s	v19, v23, v24
	bic.16b	v7, v7, v19
	str	q9, [sp, #1456]                 ; 16-byte Spill
	fcmgt.4s	v19, v23, v9
	bic.16b	v16, v16, v19
	fcmgt.4s	v19, v9, v22
	bit.16b	v16, v18, v19
	str	q16, [sp, #1504]                ; 16-byte Spill
	fcmgt.4s	v16, v24, v22
	bit.16b	v7, v18, v16
	str	q7, [sp, #1488]                 ; 16-byte Spill
	ldr	q1, [sp, #1392]                 ; 16-byte Reload
	fsub.4s	v7, v1, v30
	and.16b	v24, v17, v7
	fcmge.4s	v7, v24, v23
	fcmge.4s	v16, v22, v24
	and.16b	v7, v7, v16
	ldr	q1, [sp, #1408]                 ; 16-byte Reload
	fsub.4s	v16, v1, v6
	and.16b	v9, v0, v16
	fcmge.4s	v16, v9, v23
	fcmge.4s	v19, v22, v9
	and.16b	v16, v16, v19
	and.16b	v16, v16, v9
	fmul.4s	v19, v16, v31
	mov.16b	v20, v11
	bsl.16b	v20, v10, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v7, v7, v24
	fmul.4s	v20, v7, v31
	mov.16b	v21, v11
	bsl.16b	v21, v10, v20
	fadd.4s	v20, v20, v21
	fsub.4s	v21, v20, v21
	fcvtzs.4s	v20, v19
	scvtf.4s	v19, v20
	fmul.4s	v27, v19, v15
	fsub.4s	v16, v16, v27
	fcvtzs.4s	v21, v21
	scvtf.4s	v27, v21
	fmul.4s	v28, v27, v15
	fsub.4s	v7, v7, v28
	fmul.4s	v27, v27, v25
	fsub.4s	v7, v7, v27
	fmul.4s	v19, v19, v25
	fsub.4s	v16, v16, v19
	fmul.4s	v19, v16, v29
	fadd.4s	v19, v19, v8
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v5
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v3
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v4
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v27, v16, v16
	fmul.4s	v19, v27, v19
	fmul.4s	v27, v7, v29
	fadd.4s	v27, v27, v8
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v5
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v3
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v4
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v12
	fmul.4s	v28, v7, v7
	fmul.4s	v27, v28, v27
	fadd.4s	v7, v7, v27
	fadd.4s	v16, v16, v19
	fadd.4s	v7, v7, v13
	sshr.4s	v19, v21, #1
	shl.4s	v27, v19, #23
	add.4s	v27, v27, v13
	fmul.4s	v7, v7, v27
	fadd.4s	v16, v16, v13
	sshr.4s	v27, v20, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v13
	fmul.4s	v16, v16, v28
	sub.4s	v19, v21, v19
	sub.4s	v20, v20, v27
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v16, v16, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v7, v7, v19
	str	q24, [sp, #1280]                ; 16-byte Spill
	fcmgt.4s	v19, v23, v24
	bic.16b	v7, v7, v19
	str	q9, [sp, #1360]                 ; 16-byte Spill
	fcmgt.4s	v19, v23, v9
	bic.16b	v16, v16, v19
	fcmgt.4s	v19, v9, v22
	bit.16b	v16, v18, v19
	str	q16, [sp, #1408]                ; 16-byte Spill
	fcmgt.4s	v16, v24, v22
	bit.16b	v7, v18, v16
	str	q7, [sp, #1392]                 ; 16-byte Spill
	ldr	q1, [sp, #1296]                 ; 16-byte Reload
	fsub.4s	v7, v1, v6
	and.16b	v24, v0, v7
	fcmge.4s	v7, v24, v23
	fcmge.4s	v16, v22, v24
	and.16b	v7, v7, v16
	ldr	q1, [sp, #1312]                 ; 16-byte Reload
	fsub.4s	v16, v1, v30
	and.16b	v9, v17, v16
	fcmge.4s	v16, v9, v23
	fcmge.4s	v19, v22, v9
	and.16b	v16, v16, v19
	and.16b	v16, v16, v9
	fmul.4s	v19, v16, v31
	mov.16b	v20, v11
	bsl.16b	v20, v10, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v7, v7, v24
	fmul.4s	v20, v7, v31
	mov.16b	v21, v11
	bsl.16b	v21, v10, v20
	fadd.4s	v20, v20, v21
	fsub.4s	v21, v20, v21
	fcvtzs.4s	v20, v19
	scvtf.4s	v19, v20
	fmul.4s	v27, v19, v15
	fsub.4s	v16, v16, v27
	fcvtzs.4s	v21, v21
	scvtf.4s	v27, v21
	fmul.4s	v28, v27, v15
	fsub.4s	v7, v7, v28
	fmul.4s	v27, v27, v25
	fsub.4s	v7, v7, v27
	fmul.4s	v19, v19, v25
	fsub.4s	v16, v16, v19
	fmul.4s	v19, v16, v29
	fadd.4s	v19, v19, v8
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v5
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v3
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v4
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v27, v16, v16
	fmul.4s	v19, v27, v19
	fmul.4s	v27, v7, v29
	fadd.4s	v27, v27, v8
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v5
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v3
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v4
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v12
	fmul.4s	v28, v7, v7
	fmul.4s	v27, v28, v27
	fadd.4s	v7, v7, v27
	fadd.4s	v16, v16, v19
	fadd.4s	v7, v7, v13
	sshr.4s	v19, v21, #1
	shl.4s	v27, v19, #23
	add.4s	v27, v27, v13
	fmul.4s	v7, v7, v27
	fadd.4s	v16, v16, v13
	sshr.4s	v27, v20, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v13
	fmul.4s	v16, v16, v28
	sub.4s	v19, v21, v19
	sub.4s	v20, v20, v27
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v16, v16, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v7, v7, v19
	str	q24, [sp, #1184]                ; 16-byte Spill
	fcmgt.4s	v19, v23, v24
	bic.16b	v7, v7, v19
	str	q9, [sp, #1264]                 ; 16-byte Spill
	fcmgt.4s	v19, v23, v9
	bic.16b	v16, v16, v19
	fcmgt.4s	v19, v9, v22
	bit.16b	v16, v18, v19
	str	q16, [sp, #1312]                ; 16-byte Spill
	fcmgt.4s	v16, v24, v22
	bit.16b	v7, v18, v16
	str	q7, [sp, #1296]                 ; 16-byte Spill
	ldr	q1, [sp, #1200]                 ; 16-byte Reload
	fsub.4s	v7, v1, v6
	and.16b	v24, v0, v7
	fcmge.4s	v7, v24, v23
	fcmge.4s	v16, v22, v24
	and.16b	v7, v7, v16
	ldr	q1, [sp, #1216]                 ; 16-byte Reload
	fsub.4s	v16, v1, v30
	and.16b	v9, v17, v16
	fcmge.4s	v16, v9, v23
	fcmge.4s	v19, v22, v9
	and.16b	v16, v16, v19
	and.16b	v16, v16, v9
	fmul.4s	v19, v16, v31
	mov.16b	v20, v11
	bsl.16b	v20, v10, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v7, v7, v24
	fmul.4s	v20, v7, v31
	mov.16b	v21, v11
	bsl.16b	v21, v10, v20
	fadd.4s	v20, v20, v21
	fsub.4s	v21, v20, v21
	fcvtzs.4s	v20, v19
	scvtf.4s	v19, v20
	fmul.4s	v27, v19, v15
	fsub.4s	v16, v16, v27
	fcvtzs.4s	v21, v21
	scvtf.4s	v27, v21
	fmul.4s	v28, v27, v15
	fsub.4s	v7, v7, v28
	fmul.4s	v27, v27, v25
	fsub.4s	v7, v7, v27
	fmul.4s	v19, v19, v25
	fsub.4s	v16, v16, v19
	fmul.4s	v19, v16, v29
	fadd.4s	v19, v19, v8
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v5
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v3
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v4
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v27, v16, v16
	fmul.4s	v19, v27, v19
	fmul.4s	v27, v7, v29
	fadd.4s	v27, v27, v8
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v5
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v3
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v4
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v12
	fmul.4s	v28, v7, v7
	fmul.4s	v27, v28, v27
	fadd.4s	v7, v7, v27
	fadd.4s	v16, v16, v19
	fadd.4s	v7, v7, v13
	sshr.4s	v19, v21, #1
	shl.4s	v27, v19, #23
	add.4s	v27, v27, v13
	fmul.4s	v7, v7, v27
	fadd.4s	v16, v16, v13
	sshr.4s	v27, v20, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v13
	fmul.4s	v16, v16, v28
	sub.4s	v19, v21, v19
	sub.4s	v20, v20, v27
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v16, v16, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v7, v7, v19
	str	q24, [sp, #1088]                ; 16-byte Spill
	fcmgt.4s	v19, v23, v24
	bic.16b	v7, v7, v19
	str	q9, [sp, #1168]                 ; 16-byte Spill
	fcmgt.4s	v19, v23, v9
	bic.16b	v16, v16, v19
	fcmgt.4s	v19, v9, v22
	bit.16b	v16, v18, v19
	str	q16, [sp, #1216]                ; 16-byte Spill
	fcmgt.4s	v16, v24, v22
	bit.16b	v7, v18, v16
	str	q7, [sp, #1200]                 ; 16-byte Spill
	ldr	q1, [sp, #1104]                 ; 16-byte Reload
	fsub.4s	v7, v1, v6
	and.16b	v24, v0, v7
	fcmge.4s	v7, v24, v23
	fcmge.4s	v16, v22, v24
	and.16b	v7, v7, v16
	ldr	q1, [sp, #1120]                 ; 16-byte Reload
	fsub.4s	v16, v1, v30
	and.16b	v9, v17, v16
	fcmge.4s	v16, v9, v23
	fcmge.4s	v19, v22, v9
	and.16b	v16, v16, v19
	and.16b	v16, v16, v9
	fmul.4s	v19, v16, v31
	mov.16b	v20, v11
	bsl.16b	v20, v10, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v7, v7, v24
	fmul.4s	v20, v7, v31
	mov.16b	v21, v11
	bsl.16b	v21, v10, v20
	fadd.4s	v20, v20, v21
	fsub.4s	v21, v20, v21
	fcvtzs.4s	v20, v19
	scvtf.4s	v19, v20
	fmul.4s	v27, v19, v15
	fsub.4s	v16, v16, v27
	fcvtzs.4s	v21, v21
	scvtf.4s	v27, v21
	fmul.4s	v28, v27, v15
	fsub.4s	v7, v7, v28
	fmul.4s	v27, v27, v25
	fsub.4s	v7, v7, v27
	fmul.4s	v19, v19, v25
	fsub.4s	v16, v16, v19
	fmul.4s	v19, v16, v29
	fadd.4s	v19, v19, v8
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v5
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v3
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v4
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v27, v16, v16
	fmul.4s	v19, v27, v19
	fmul.4s	v27, v7, v29
	fadd.4s	v27, v27, v8
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v5
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v3
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v4
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v12
	fmul.4s	v28, v7, v7
	fmul.4s	v27, v28, v27
	fadd.4s	v7, v7, v27
	fadd.4s	v16, v16, v19
	fadd.4s	v7, v7, v13
	sshr.4s	v19, v21, #1
	shl.4s	v27, v19, #23
	add.4s	v27, v27, v13
	fmul.4s	v7, v7, v27
	fadd.4s	v16, v16, v13
	sshr.4s	v27, v20, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v13
	fmul.4s	v16, v16, v28
	sub.4s	v19, v21, v19
	sub.4s	v20, v20, v27
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v16, v16, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v7, v7, v19
	str	q24, [sp, #960]                 ; 16-byte Spill
	fcmgt.4s	v19, v23, v24
	bic.16b	v7, v7, v19
	str	q9, [sp, #1072]                 ; 16-byte Spill
	fcmgt.4s	v19, v23, v9
	bic.16b	v16, v16, v19
	fcmgt.4s	v19, v9, v22
	bit.16b	v16, v18, v19
	str	q16, [sp, #1120]                ; 16-byte Spill
	fcmgt.4s	v16, v24, v22
	bit.16b	v7, v18, v16
	str	q7, [sp, #1104]                 ; 16-byte Spill
	ldr	q7, [sp, #1008]                 ; 16-byte Reload
	fsub.4s	v7, v7, v6
	and.16b	v24, v0, v7
	fcmge.4s	v7, v24, v23
	fcmge.4s	v16, v22, v24
	and.16b	v7, v7, v16
	ldr	q16, [sp, #1024]                ; 16-byte Reload
	fsub.4s	v16, v16, v30
	and.16b	v9, v17, v16
	fcmge.4s	v16, v9, v23
	fcmge.4s	v19, v22, v9
	and.16b	v16, v16, v19
	and.16b	v16, v16, v9
	fmul.4s	v19, v16, v31
	mov.16b	v20, v11
	bsl.16b	v20, v10, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v7, v7, v24
	fmul.4s	v20, v7, v31
	mov.16b	v21, v11
	bsl.16b	v21, v10, v20
	fadd.4s	v20, v20, v21
	fsub.4s	v21, v20, v21
	fcvtzs.4s	v20, v19
	scvtf.4s	v19, v20
	fmul.4s	v27, v19, v15
	fsub.4s	v16, v16, v27
	fcvtzs.4s	v21, v21
	scvtf.4s	v27, v21
	fmul.4s	v28, v27, v15
	fsub.4s	v7, v7, v28
	fmul.4s	v27, v27, v25
	fsub.4s	v7, v7, v27
	fmul.4s	v19, v19, v25
	fsub.4s	v16, v16, v19
	fmul.4s	v19, v16, v29
	fadd.4s	v19, v19, v8
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v5
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v3
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v4
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v27, v16, v16
	fmul.4s	v19, v27, v19
	fmul.4s	v27, v7, v29
	fadd.4s	v27, v27, v8
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v5
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v3
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v4
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v12
	fmul.4s	v28, v7, v7
	fmul.4s	v27, v28, v27
	fadd.4s	v7, v7, v27
	fadd.4s	v16, v16, v19
	fadd.4s	v7, v7, v13
	sshr.4s	v19, v21, #1
	shl.4s	v27, v19, #23
	add.4s	v27, v27, v13
	fmul.4s	v7, v7, v27
	fadd.4s	v16, v16, v13
	sshr.4s	v27, v20, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v13
	fmul.4s	v16, v16, v28
	sub.4s	v19, v21, v19
	sub.4s	v20, v20, v27
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v16, v16, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v7, v7, v19
	str	q24, [sp, #944]                 ; 16-byte Spill
	fcmgt.4s	v19, v23, v24
	bic.16b	v7, v7, v19
	str	q9, [sp, #976]                  ; 16-byte Spill
	fcmgt.4s	v19, v23, v9
	bic.16b	v16, v16, v19
	fcmgt.4s	v19, v9, v22
	bit.16b	v16, v18, v19
	str	q16, [sp, #1024]                ; 16-byte Spill
	fcmgt.4s	v16, v24, v22
	bit.16b	v7, v18, v16
	str	q7, [sp, #1008]                 ; 16-byte Spill
	ldr	q7, [sp, #1040]                 ; 16-byte Reload
	fsub.4s	v7, v7, v30
	and.16b	v24, v17, v7
	fcmge.4s	v7, v24, v23
	fcmge.4s	v16, v22, v24
	and.16b	v7, v7, v16
	ldr	q16, [sp, #1056]                ; 16-byte Reload
	fsub.4s	v16, v16, v6
	and.16b	v9, v0, v16
	fcmge.4s	v16, v9, v23
	fcmge.4s	v19, v22, v9
	and.16b	v16, v16, v19
	and.16b	v16, v16, v9
	fmul.4s	v19, v16, v31
	mov.16b	v20, v11
	bsl.16b	v20, v10, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v7, v7, v24
	fmul.4s	v20, v7, v31
	mov.16b	v21, v11
	bsl.16b	v21, v10, v20
	fadd.4s	v20, v20, v21
	fsub.4s	v21, v20, v21
	fcvtzs.4s	v20, v19
	scvtf.4s	v19, v20
	fmul.4s	v27, v19, v15
	fsub.4s	v16, v16, v27
	fcvtzs.4s	v21, v21
	scvtf.4s	v27, v21
	fmul.4s	v28, v27, v15
	fsub.4s	v7, v7, v28
	fmul.4s	v27, v27, v25
	fsub.4s	v7, v7, v27
	fmul.4s	v19, v19, v25
	fsub.4s	v16, v16, v19
	fmul.4s	v19, v16, v29
	fadd.4s	v19, v19, v8
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v5
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v3
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v4
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v27, v16, v16
	fmul.4s	v19, v27, v19
	fmul.4s	v27, v7, v29
	fadd.4s	v27, v27, v8
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v5
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v3
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v4
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v12
	fmul.4s	v28, v7, v7
	fmul.4s	v27, v28, v27
	fadd.4s	v7, v7, v27
	fadd.4s	v16, v16, v19
	fadd.4s	v7, v7, v13
	sshr.4s	v19, v21, #1
	shl.4s	v27, v19, #23
	add.4s	v27, v27, v13
	fmul.4s	v7, v7, v27
	fadd.4s	v16, v16, v13
	sshr.4s	v27, v20, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v13
	fmul.4s	v16, v16, v28
	sub.4s	v19, v21, v19
	sub.4s	v20, v20, v27
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v16, v16, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v7, v7, v19
	str	q24, [sp, #912]                 ; 16-byte Spill
	fcmgt.4s	v19, v23, v24
	bic.16b	v7, v7, v19
	fcmgt.4s	v19, v23, v9
	bic.16b	v16, v16, v19
	fcmgt.4s	v19, v9, v22
	bit.16b	v16, v18, v19
	str	q16, [sp, #1056]                ; 16-byte Spill
	fcmgt.4s	v16, v24, v22
	bit.16b	v7, v18, v16
	str	q7, [sp, #1040]                 ; 16-byte Spill
	ldr	q7, [sp, #1136]                 ; 16-byte Reload
	fsub.4s	v7, v7, v30
	and.16b	v24, v17, v7
	fcmge.4s	v7, v24, v23
	fcmge.4s	v16, v22, v24
	and.16b	v7, v7, v16
	ldr	q16, [sp, #1152]                ; 16-byte Reload
	fsub.4s	v16, v16, v6
	and.16b	v1, v0, v16
	fcmge.4s	v16, v1, v23
	fcmge.4s	v19, v22, v1
	and.16b	v16, v16, v19
	and.16b	v16, v16, v1
	fmul.4s	v19, v16, v31
	mov.16b	v20, v11
	bsl.16b	v20, v10, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v7, v7, v24
	fmul.4s	v20, v7, v31
	mov.16b	v21, v11
	bsl.16b	v21, v10, v20
	fadd.4s	v20, v20, v21
	fsub.4s	v21, v20, v21
	fcvtzs.4s	v20, v19
	scvtf.4s	v19, v20
	fmul.4s	v27, v19, v15
	fsub.4s	v16, v16, v27
	fcvtzs.4s	v21, v21
	scvtf.4s	v27, v21
	fmul.4s	v28, v27, v15
	fsub.4s	v7, v7, v28
	fmul.4s	v27, v27, v25
	fsub.4s	v7, v7, v27
	fmul.4s	v19, v19, v25
	fsub.4s	v16, v16, v19
	fmul.4s	v19, v16, v29
	fadd.4s	v19, v19, v8
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v5
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v3
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v4
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v27, v16, v16
	fmul.4s	v19, v27, v19
	fmul.4s	v27, v7, v29
	fadd.4s	v27, v27, v8
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v5
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v3
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v4
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v12
	fmul.4s	v28, v7, v7
	fmul.4s	v27, v28, v27
	fadd.4s	v7, v7, v27
	fadd.4s	v16, v16, v19
	fadd.4s	v7, v7, v13
	sshr.4s	v19, v21, #1
	shl.4s	v27, v19, #23
	add.4s	v27, v27, v13
	fmul.4s	v7, v7, v27
	fadd.4s	v16, v16, v13
	sshr.4s	v27, v20, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v13
	fmul.4s	v16, v16, v28
	sub.4s	v19, v21, v19
	sub.4s	v20, v20, v27
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v16, v16, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v7, v7, v19
	str	q24, [sp, #880]                 ; 16-byte Spill
	fcmgt.4s	v19, v23, v24
	bic.16b	v7, v7, v19
	str	q1, [sp, #1136]                 ; 16-byte Spill
	fcmgt.4s	v19, v23, v1
	bic.16b	v16, v16, v19
	fcmgt.4s	v19, v1, v22
	mov.16b	v1, v19
	bsl.16b	v1, v18, v16
	str	q1, [sp, #1152]                 ; 16-byte Spill
	fcmgt.4s	v16, v24, v22
	mov.16b	v1, v16
	bsl.16b	v1, v18, v7
	str	q1, [sp, #928]                  ; 16-byte Spill
	ldr	q7, [sp, #1232]                 ; 16-byte Reload
	fsub.4s	v7, v7, v30
	and.16b	v24, v17, v7
	fcmge.4s	v7, v24, v23
	fcmge.4s	v16, v22, v24
	and.16b	v7, v7, v16
	ldr	q16, [sp, #1248]                ; 16-byte Reload
	fsub.4s	v16, v16, v6
	and.16b	v1, v0, v16
	fcmge.4s	v16, v1, v23
	fcmge.4s	v19, v22, v1
	and.16b	v16, v16, v19
	and.16b	v16, v16, v1
	fmul.4s	v19, v16, v31
	mov.16b	v20, v11
	bsl.16b	v20, v10, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v7, v7, v24
	fmul.4s	v20, v7, v31
	mov.16b	v21, v11
	bsl.16b	v21, v10, v20
	fadd.4s	v20, v20, v21
	fsub.4s	v21, v20, v21
	fcvtzs.4s	v20, v19
	scvtf.4s	v19, v20
	fmul.4s	v27, v19, v15
	fsub.4s	v16, v16, v27
	fcvtzs.4s	v21, v21
	scvtf.4s	v27, v21
	fmul.4s	v28, v27, v15
	fsub.4s	v7, v7, v28
	fmul.4s	v27, v27, v25
	fsub.4s	v7, v7, v27
	fmul.4s	v19, v19, v25
	fsub.4s	v16, v16, v19
	fmul.4s	v19, v16, v29
	fadd.4s	v19, v19, v8
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v5
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v3
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v4
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v27, v16, v16
	fmul.4s	v19, v27, v19
	fmul.4s	v27, v7, v29
	fadd.4s	v27, v27, v8
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v5
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v3
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v4
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v12
	fmul.4s	v28, v7, v7
	fmul.4s	v27, v28, v27
	fadd.4s	v7, v7, v27
	fadd.4s	v16, v16, v19
	fadd.4s	v7, v7, v13
	sshr.4s	v19, v21, #1
	shl.4s	v27, v19, #23
	add.4s	v27, v27, v13
	fmul.4s	v7, v7, v27
	fadd.4s	v16, v16, v13
	sshr.4s	v27, v20, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v13
	fmul.4s	v16, v16, v28
	sub.4s	v19, v21, v19
	sub.4s	v20, v20, v27
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v16, v16, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v7, v7, v19
	str	q24, [sp, #848]                 ; 16-byte Spill
	fcmgt.4s	v19, v23, v24
	bic.16b	v7, v7, v19
	str	q1, [sp, #1232]                 ; 16-byte Spill
	fcmgt.4s	v19, v23, v1
	bic.16b	v16, v16, v19
	fcmgt.4s	v19, v1, v22
	mov.16b	v1, v19
	bsl.16b	v1, v18, v16
	str	q1, [sp, #1248]                 ; 16-byte Spill
	fcmgt.4s	v16, v24, v22
	mov.16b	v1, v16
	bsl.16b	v1, v18, v7
	str	q1, [sp, #896]                  ; 16-byte Spill
	ldr	q7, [sp, #1328]                 ; 16-byte Reload
	fsub.4s	v7, v7, v30
	and.16b	v24, v17, v7
	fcmge.4s	v7, v24, v23
	fcmge.4s	v16, v22, v24
	and.16b	v7, v7, v16
	ldr	q16, [sp, #1344]                ; 16-byte Reload
	fsub.4s	v16, v16, v6
	and.16b	v1, v0, v16
	fcmge.4s	v16, v1, v23
	fcmge.4s	v19, v22, v1
	and.16b	v16, v16, v19
	and.16b	v16, v16, v1
	fmul.4s	v19, v16, v31
	mov.16b	v20, v11
	bsl.16b	v20, v10, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v7, v7, v24
	fmul.4s	v20, v7, v31
	mov.16b	v21, v11
	bsl.16b	v21, v10, v20
	fadd.4s	v20, v20, v21
	fsub.4s	v21, v20, v21
	fcvtzs.4s	v20, v19
	scvtf.4s	v19, v20
	fmul.4s	v27, v19, v15
	fsub.4s	v16, v16, v27
	fcvtzs.4s	v21, v21
	scvtf.4s	v27, v21
	fmul.4s	v28, v27, v15
	fsub.4s	v7, v7, v28
	fmul.4s	v27, v27, v25
	fsub.4s	v7, v7, v27
	fmul.4s	v19, v19, v25
	fsub.4s	v16, v16, v19
	fmul.4s	v19, v16, v29
	fadd.4s	v19, v19, v8
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v5
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v3
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v4
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v27, v16, v16
	fmul.4s	v19, v27, v19
	fmul.4s	v27, v7, v29
	fadd.4s	v27, v27, v8
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v5
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v3
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v4
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v12
	fmul.4s	v28, v7, v7
	fmul.4s	v27, v28, v27
	fadd.4s	v7, v7, v27
	fadd.4s	v16, v16, v19
	fadd.4s	v7, v7, v13
	sshr.4s	v19, v21, #1
	shl.4s	v27, v19, #23
	add.4s	v27, v27, v13
	fmul.4s	v7, v7, v27
	fadd.4s	v16, v16, v13
	sshr.4s	v27, v20, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v13
	fmul.4s	v16, v16, v28
	sub.4s	v19, v21, v19
	sub.4s	v20, v20, v27
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v16, v16, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v7, v7, v19
	str	q24, [sp, #816]                 ; 16-byte Spill
	fcmgt.4s	v19, v23, v24
	bic.16b	v7, v7, v19
	str	q1, [sp, #1328]                 ; 16-byte Spill
	fcmgt.4s	v19, v23, v1
	bic.16b	v16, v16, v19
	fcmgt.4s	v19, v1, v22
	mov.16b	v1, v19
	bsl.16b	v1, v18, v16
	str	q1, [sp, #1344]                 ; 16-byte Spill
	fcmgt.4s	v16, v24, v22
	mov.16b	v1, v16
	bsl.16b	v1, v18, v7
	str	q1, [sp, #864]                  ; 16-byte Spill
	ldr	q7, [sp, #1424]                 ; 16-byte Reload
	fsub.4s	v7, v7, v6
	and.16b	v24, v0, v7
	fcmge.4s	v7, v24, v23
	fcmge.4s	v16, v22, v24
	and.16b	v7, v7, v16
	ldr	q16, [sp, #1440]                ; 16-byte Reload
	fsub.4s	v16, v16, v30
	and.16b	v1, v17, v16
	fcmge.4s	v16, v1, v23
	fcmge.4s	v19, v22, v1
	and.16b	v16, v16, v19
	and.16b	v16, v16, v1
	fmul.4s	v19, v16, v31
	mov.16b	v20, v11
	bsl.16b	v20, v10, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v7, v7, v24
	fmul.4s	v20, v7, v31
	mov.16b	v21, v11
	bsl.16b	v21, v10, v20
	fadd.4s	v20, v20, v21
	fsub.4s	v21, v20, v21
	fcvtzs.4s	v20, v19
	scvtf.4s	v19, v20
	fmul.4s	v27, v19, v15
	fsub.4s	v16, v16, v27
	fcvtzs.4s	v21, v21
	scvtf.4s	v27, v21
	fmul.4s	v28, v27, v15
	fsub.4s	v7, v7, v28
	fmul.4s	v27, v27, v25
	fsub.4s	v7, v7, v27
	fmul.4s	v19, v19, v25
	fsub.4s	v16, v16, v19
	fmul.4s	v19, v16, v29
	fadd.4s	v19, v19, v8
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v5
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v3
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v4
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v27, v16, v16
	fmul.4s	v19, v27, v19
	fmul.4s	v27, v7, v29
	fadd.4s	v27, v27, v8
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v5
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v3
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v4
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v12
	fmul.4s	v28, v7, v7
	fmul.4s	v27, v28, v27
	fadd.4s	v7, v7, v27
	fadd.4s	v16, v16, v19
	fadd.4s	v7, v7, v13
	sshr.4s	v19, v21, #1
	shl.4s	v27, v19, #23
	add.4s	v27, v27, v13
	fmul.4s	v7, v7, v27
	fadd.4s	v16, v16, v13
	sshr.4s	v27, v20, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v13
	fmul.4s	v16, v16, v28
	sub.4s	v19, v21, v19
	sub.4s	v20, v20, v27
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v16, v16, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v7, v7, v19
	str	q24, [sp, #752]                 ; 16-byte Spill
	fcmgt.4s	v19, v23, v24
	bic.16b	v7, v7, v19
	str	q1, [sp, #1424]                 ; 16-byte Spill
	fcmgt.4s	v19, v23, v1
	bic.16b	v16, v16, v19
	fcmgt.4s	v19, v1, v22
	mov.16b	v1, v19
	bsl.16b	v1, v18, v16
	str	q1, [sp, #1440]                 ; 16-byte Spill
	fcmgt.4s	v16, v24, v22
	mov.16b	v1, v16
	bsl.16b	v1, v18, v7
	str	q1, [sp, #832]                  ; 16-byte Spill
	ldr	q7, [sp, #1536]                 ; 16-byte Reload
	fsub.4s	v7, v7, v30
	and.16b	v24, v17, v7
	fcmge.4s	v7, v24, v23
	fcmge.4s	v16, v22, v24
	and.16b	v7, v7, v16
	ldr	q16, [sp, #1552]                ; 16-byte Reload
	fsub.4s	v16, v16, v6
	and.16b	v1, v0, v16
	fcmge.4s	v16, v1, v23
	fcmge.4s	v19, v22, v1
	and.16b	v16, v16, v19
	and.16b	v16, v16, v1
	fmul.4s	v19, v16, v31
	mov.16b	v20, v11
	bsl.16b	v20, v10, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v7, v7, v24
	fmul.4s	v20, v7, v31
	mov.16b	v21, v11
	bsl.16b	v21, v10, v20
	fadd.4s	v20, v20, v21
	fsub.4s	v21, v20, v21
	fcvtzs.4s	v20, v19
	scvtf.4s	v19, v20
	fmul.4s	v27, v19, v15
	fsub.4s	v16, v16, v27
	fcvtzs.4s	v21, v21
	scvtf.4s	v27, v21
	fmul.4s	v28, v27, v15
	fsub.4s	v7, v7, v28
	fmul.4s	v27, v27, v25
	fsub.4s	v7, v7, v27
	fmul.4s	v19, v19, v25
	fsub.4s	v16, v16, v19
	fmul.4s	v19, v16, v29
	fadd.4s	v19, v19, v8
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v5
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v3
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v4
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v27, v16, v16
	fmul.4s	v19, v27, v19
	fmul.4s	v27, v7, v29
	fadd.4s	v27, v27, v8
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v5
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v3
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v4
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v12
	fmul.4s	v28, v7, v7
	fmul.4s	v27, v28, v27
	fadd.4s	v7, v7, v27
	fadd.4s	v16, v16, v19
	fadd.4s	v7, v7, v13
	sshr.4s	v19, v21, #1
	shl.4s	v27, v19, #23
	add.4s	v27, v27, v13
	fmul.4s	v7, v7, v27
	fadd.4s	v16, v16, v13
	sshr.4s	v27, v20, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v13
	fmul.4s	v16, v16, v28
	sub.4s	v19, v21, v19
	sub.4s	v20, v20, v27
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v16, v16, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v7, v7, v19
	str	q24, [sp, #736]                 ; 16-byte Spill
	fcmgt.4s	v19, v23, v24
	bic.16b	v7, v7, v19
	str	q1, [sp, #784]                  ; 16-byte Spill
	fcmgt.4s	v19, v23, v1
	bic.16b	v16, v16, v19
	fcmgt.4s	v19, v1, v22
	mov.16b	v1, v19
	bsl.16b	v1, v18, v16
	str	q1, [sp, #800]                  ; 16-byte Spill
	fcmgt.4s	v16, v24, v22
	mov.16b	v1, v16
	bsl.16b	v1, v18, v7
	str	q1, [sp, #768]                  ; 16-byte Spill
	ldr	q7, [sp, #2288]                 ; 16-byte Reload
	fsub.4s	v7, v7, v30
	and.16b	v24, v17, v7
	fcmge.4s	v7, v24, v23
	fcmge.4s	v16, v22, v24
	and.16b	v7, v7, v16
	ldr	q16, [sp, #2304]                ; 16-byte Reload
	fsub.4s	v16, v16, v6
	and.16b	v26, v0, v16
	fcmge.4s	v16, v26, v23
	fcmge.4s	v19, v22, v26
	and.16b	v16, v16, v19
	and.16b	v16, v16, v26
	fmul.4s	v19, v16, v31
	mov.16b	v20, v11
	bsl.16b	v20, v10, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v7, v7, v24
	fmul.4s	v20, v7, v31
	mov.16b	v21, v11
	bsl.16b	v21, v10, v20
	fadd.4s	v20, v20, v21
	fsub.4s	v21, v20, v21
	fcvtzs.4s	v20, v19
	scvtf.4s	v19, v20
	fmul.4s	v27, v19, v15
	fsub.4s	v16, v16, v27
	fcvtzs.4s	v21, v21
	scvtf.4s	v27, v21
	fmul.4s	v28, v27, v15
	fsub.4s	v7, v7, v28
	fmul.4s	v27, v27, v25
	fsub.4s	v7, v7, v27
	fmul.4s	v19, v19, v25
	fsub.4s	v16, v16, v19
	fmul.4s	v19, v16, v29
	fadd.4s	v19, v19, v8
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v5
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v3
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v4
	fmul.4s	v19, v16, v19
	fadd.4s	v19, v19, v12
	fmul.4s	v27, v16, v16
	fmul.4s	v19, v27, v19
	fmul.4s	v27, v7, v29
	fadd.4s	v27, v27, v8
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v5
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v3
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v4
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v12
	fmul.4s	v28, v7, v7
	fmul.4s	v27, v28, v27
	fadd.4s	v7, v7, v27
	fadd.4s	v16, v16, v19
	fadd.4s	v7, v7, v13
	sshr.4s	v19, v21, #1
	shl.4s	v27, v19, #23
	add.4s	v27, v27, v13
	fmul.4s	v7, v7, v27
	fadd.4s	v16, v16, v13
	sshr.4s	v27, v20, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v13
	fmul.4s	v16, v16, v28
	sub.4s	v19, v21, v19
	sub.4s	v20, v20, v27
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v13
	fmul.4s	v16, v16, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v7, v7, v19
	fcmgt.4s	v19, v23, v24
	bic.16b	v7, v7, v19
	str	q26, [sp, #720]                 ; 16-byte Spill
	fcmgt.4s	v19, v23, v26
	bic.16b	v16, v16, v19
	fcmgt.4s	v19, v26, v22
	mov.16b	v1, v19
	bsl.16b	v1, v18, v16
	str	q1, [sp, #2288]                 ; 16-byte Spill
	fcmgt.4s	v16, v24, v22
	mov.16b	v1, v16
	bsl.16b	v1, v18, v7
	stp	q24, q1, [sp, #688]             ; 32-byte Folded Spill
	str	q6, [sp, #1536]                 ; 16-byte Spill
	ldr	q7, [sp, #2944]                 ; 16-byte Reload
	fsub.4s	v7, v7, v6
	and.16b	v24, v0, v7
	fcmge.4s	v7, v24, v23
	fcmge.4s	v16, v22, v24
	and.16b	v7, v7, v16
	str	q30, [sp, #1552]                ; 16-byte Spill
	ldr	q6, [sp, #2928]                 ; 16-byte Reload
	fsub.4s	v16, v6, v30
	and.16b	v6, v17, v16
	fcmge.4s	v16, v6, v23
	fcmge.4s	v19, v22, v6
	and.16b	v16, v16, v19
	and.16b	v16, v16, v6
	fmul.4s	v19, v16, v31
	mov.16b	v20, v11
	bsl.16b	v20, v10, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v7, v7, v24
	fmul.4s	v20, v7, v31
	mov.16b	v21, v11
	bsl.16b	v21, v10, v20
	fadd.4s	v20, v20, v21
	fsub.4s	v20, v20, v21
	fcvtzs.4s	v19, v19
	scvtf.4s	v21, v19
	fmul.4s	v27, v21, v15
	fsub.4s	v16, v16, v27
	fcvtzs.4s	v20, v20
	scvtf.4s	v27, v20
	fmul.4s	v28, v27, v15
	fsub.4s	v7, v7, v28
	fmul.4s	v21, v21, v25
	fmul.4s	v27, v27, v25
	fsub.4s	v7, v7, v27
	fsub.4s	v16, v16, v21
	fmul.4s	v21, v16, v29
	fmul.4s	v27, v7, v29
	fadd.4s	v27, v27, v8
	fadd.4s	v21, v21, v8
	fmul.4s	v21, v16, v21
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v5
	fadd.4s	v21, v21, v5
	fmul.4s	v21, v16, v21
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v3
	fadd.4s	v21, v21, v3
	fmul.4s	v21, v16, v21
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v4
	fadd.4s	v21, v21, v4
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v12
	fmul.4s	v28, v16, v16
	fmul.4s	v21, v28, v21
	fmul.4s	v27, v7, v27
	fadd.4s	v27, v27, v12
	fmul.4s	v28, v7, v7
	fmul.4s	v27, v28, v27
	fadd.4s	v7, v7, v27
	fadd.4s	v16, v16, v21
	fadd.4s	v7, v7, v13
	sshr.4s	v21, v20, #1
	shl.4s	v27, v21, #23
	add.4s	v27, v27, v13
	fmul.4s	v7, v7, v27
	fadd.4s	v16, v16, v13
	sshr.4s	v27, v19, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v13
	fmul.4s	v16, v16, v28
	sub.4s	v20, v20, v21
	sub.4s	v19, v19, v27
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v13
	fmul.4s	v16, v16, v19
	shl.4s	v19, v20, #23
	add.4s	v19, v19, v13
	fmul.4s	v7, v7, v19
	fcmgt.4s	v19, v23, v24
	bic.16b	v7, v7, v19
	fcmgt.4s	v19, v23, v6
	bic.16b	v16, v16, v19
	fcmgt.4s	v19, v6, v22
	mov.16b	v1, v19
	bsl.16b	v1, v18, v16
	stp	q6, q1, [sp, #656]              ; 32-byte Folded Spill
	fcmgt.4s	v16, v24, v22
	mov.16b	v1, v16
	bsl.16b	v1, v18, v7
	stp	q24, q1, [sp, #624]             ; 32-byte Folded Spill
	sshll2.2d	v7, v17, #0
	ldr	q3, [sp, #1952]                 ; 16-byte Reload
	ldr	q4, [sp, #2400]                 ; 16-byte Reload
	bit.16b	v3, v4, v7
	str	q3, [sp, #1952]                 ; 16-byte Spill
	ldr	q16, [sp, #2192]                ; 16-byte Reload
	bit.16b	v16, v4, v7
	str	q16, [sp, #2192]                ; 16-byte Spill
	sshll.2d	v7, v0, #0
	ldr	q3, [sp, #1936]                 ; 16-byte Reload
	ldr	q4, [sp, #2416]                 ; 16-byte Reload
	bit.16b	v3, v4, v7
	str	q3, [sp, #1936]                 ; 16-byte Spill
	ldr	q16, [sp, #2176]                ; 16-byte Reload
	bit.16b	v16, v4, v7
	str	q16, [sp, #2176]                ; 16-byte Spill
	fcmeq.4s	v7, v14, v14
	ldr	q14, [sp, #304]                 ; 16-byte Reload
	ldr	q1, [sp, #2384]                 ; 16-byte Reload
	mov.16b	v3, v7
	bsl.16b	v3, v1, v14
	str	q3, [sp, #2416]                 ; 16-byte Spill
	ldr	q1, [sp, #2336]                 ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #2320]                 ; 16-byte Reload
	mov.16b	v4, v7
	bsl.16b	v4, v1, v14
	str	q4, [sp, #2400]                 ; 16-byte Spill
	ldr	q1, [sp, #2240]                 ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #2352]                 ; 16-byte Reload
	mov.16b	v18, v7
	bsl.16b	v18, v1, v14
	str	q18, [sp, #2384]                ; 16-byte Spill
	ldr	q1, [sp, #992]                  ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #2368]                 ; 16-byte Reload
	mov.16b	v6, v7
	bsl.16b	v6, v1, v14
	str	q6, [sp, #2368]                 ; 16-byte Spill
	ldr	q1, [sp, #1472]                 ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #2256]                 ; 16-byte Reload
	mov.16b	v23, v7
	bsl.16b	v23, v1, v14
	str	q23, [sp, #2352]                ; 16-byte Spill
	ldr	q1, [sp, #2224]                 ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #2272]                 ; 16-byte Reload
	mov.16b	v5, v7
	bsl.16b	v5, v1, v14
	str	q5, [sp, #2336]                 ; 16-byte Spill
	ldr	q1, [sp, #1376]                 ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #1488]                 ; 16-byte Reload
	bif.16b	v1, v14, v7
	str	q1, [sp, #2320]                 ; 16-byte Spill
	ldr	q1, [sp, #1456]                 ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #1504]                 ; 16-byte Reload
	bif.16b	v1, v14, v7
	str	q1, [sp, #2304]                 ; 16-byte Spill
	ldr	q1, [sp, #1280]                 ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #1392]                 ; 16-byte Reload
	mov.16b	v29, v7
	bsl.16b	v29, v1, v14
	ldr	q1, [sp, #1360]                 ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #1408]                 ; 16-byte Reload
	mov.16b	v26, v7
	bsl.16b	v26, v1, v14
	ldr	q1, [sp, #1184]                 ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #1296]                 ; 16-byte Reload
	mov.16b	v22, v7
	bsl.16b	v22, v1, v14
	ldr	q1, [sp, #1264]                 ; 16-byte Reload
	fcmeq.4s	v16, v1, v1
	ldr	q1, [sp, #1312]                 ; 16-byte Reload
	bif.16b	v1, v14, v16
	str	q1, [sp, #1504]                 ; 16-byte Spill
	ldr	q1, [sp, #1088]                 ; 16-byte Reload
	fcmeq.4s	v16, v1, v1
	ldr	q1, [sp, #1200]                 ; 16-byte Reload
	bsl.16b	v16, v1, v14
	ldr	q1, [sp, #1168]                 ; 16-byte Reload
	fcmeq.4s	v19, v1, v1
	ldr	q1, [sp, #1216]                 ; 16-byte Reload
	bif.16b	v1, v14, v19
	str	q1, [sp, #1488]                 ; 16-byte Spill
	ldr	q1, [sp, #960]                  ; 16-byte Reload
	fcmeq.4s	v19, v1, v1
	ldr	q1, [sp, #1104]                 ; 16-byte Reload
	bsl.16b	v19, v1, v14
	ldr	q1, [sp, #1072]                 ; 16-byte Reload
	fcmeq.4s	v20, v1, v1
	ldr	q1, [sp, #1120]                 ; 16-byte Reload
	bif.16b	v1, v14, v20
	str	q1, [sp, #1472]                 ; 16-byte Spill
	ldr	q1, [sp, #944]                  ; 16-byte Reload
	fcmeq.4s	v20, v1, v1
	ldr	q1, [sp, #1008]                 ; 16-byte Reload
	mov.16b	v28, v20
	bsl.16b	v28, v1, v14
	ldr	q1, [sp, #976]                  ; 16-byte Reload
	fcmeq.4s	v20, v1, v1
	ldr	q1, [sp, #1024]                 ; 16-byte Reload
	bif.16b	v1, v14, v20
	str	q1, [sp, #1456]                 ; 16-byte Spill
	ldr	q1, [sp, #912]                  ; 16-byte Reload
	fcmeq.4s	v20, v1, v1
	ldr	q1, [sp, #1040]                 ; 16-byte Reload
	bif.16b	v1, v14, v20
	str	q1, [sp, #1408]                 ; 16-byte Spill
	fcmeq.4s	v20, v9, v9
	ldr	q1, [sp, #1056]                 ; 16-byte Reload
	mov.16b	v9, v20
	bsl.16b	v9, v1, v14
	ldr	q1, [sp, #880]                  ; 16-byte Reload
	fcmeq.4s	v20, v1, v1
	ldr	q1, [sp, #928]                  ; 16-byte Reload
	bif.16b	v1, v14, v20
	str	q1, [sp, #1392]                 ; 16-byte Spill
	ldr	q1, [sp, #1136]                 ; 16-byte Reload
	fcmeq.4s	v20, v1, v1
	ldr	q1, [sp, #1152]                 ; 16-byte Reload
	mov.16b	v10, v20
	bsl.16b	v10, v1, v14
	ldr	q1, [sp, #848]                  ; 16-byte Reload
	fcmeq.4s	v20, v1, v1
	ldr	q1, [sp, #896]                  ; 16-byte Reload
	bif.16b	v1, v14, v20
	str	q1, [sp, #1376]                 ; 16-byte Spill
	ldr	q1, [sp, #1232]                 ; 16-byte Reload
	fcmeq.4s	v20, v1, v1
	ldr	q1, [sp, #1248]                 ; 16-byte Reload
	mov.16b	v11, v20
	bsl.16b	v11, v1, v14
	ldr	q1, [sp, #816]                  ; 16-byte Reload
	fcmeq.4s	v20, v1, v1
	ldr	q1, [sp, #864]                  ; 16-byte Reload
	bif.16b	v1, v14, v20
	str	q1, [sp, #1360]                 ; 16-byte Spill
	ldr	q1, [sp, #1328]                 ; 16-byte Reload
	fcmeq.4s	v20, v1, v1
	ldr	q1, [sp, #1344]                 ; 16-byte Reload
	mov.16b	v12, v20
	bsl.16b	v12, v1, v14
	ldr	q1, [sp, #752]                  ; 16-byte Reload
	fcmeq.4s	v20, v1, v1
	ldr	q1, [sp, #832]                  ; 16-byte Reload
	mov.16b	v13, v20
	bsl.16b	v13, v1, v14
	ldr	q1, [sp, #1424]                 ; 16-byte Reload
	fcmeq.4s	v20, v1, v1
	ldr	q1, [sp, #1440]                 ; 16-byte Reload
	bif.16b	v1, v14, v20
	str	q1, [sp, #1440]                 ; 16-byte Spill
	ldr	q1, [sp, #736]                  ; 16-byte Reload
	fcmeq.4s	v20, v1, v1
	ldr	q1, [sp, #768]                  ; 16-byte Reload
	bif.16b	v1, v14, v20
	str	q1, [sp, #1424]                 ; 16-byte Spill
	ldp	q7, q1, [sp, #784]              ; 32-byte Folded Reload
	fcmeq.4s	v27, v7, v7
	bsl.16b	v27, v1, v14
	ldr	q1, [sp, #688]                  ; 16-byte Reload
	fcmeq.4s	v21, v1, v1
	ldr	q1, [sp, #704]                  ; 16-byte Reload
	bif.16b	v1, v14, v21
	str	q1, [sp, #1344]                 ; 16-byte Spill
	ldr	q1, [sp, #720]                  ; 16-byte Reload
	fcmeq.4s	v20, v1, v1
	ldr	q1, [sp, #2288]                 ; 16-byte Reload
	bsl.16b	v20, v1, v14
	ldr	x1, [sp, #384]                  ; 8-byte Reload
	ldp	q7, q21, [x1]
	bit.16b	v21, v4, v0
	bit.16b	v7, v3, v17
	stp	q7, q21, [x1]
	ldr	d3, [sp, #1520]                 ; 8-byte Reload
	zip2.8b	v7, v3, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	and.16b	v15, v7, v22
	and.16b	v25, v7, v16
	and.16b	v24, v7, v19
	and.16b	v22, v7, v28
	and.16b	v1, v7, v9
	str	q1, [sp, #2224]                 ; 16-byte Spill
	and.16b	v10, v7, v10
	and.16b	v11, v7, v11
	and.16b	v21, v7, v12
	str	q21, [sp, #2240]                ; 16-byte Spill
	and.16b	v30, v7, v13
	str	q30, [sp, #2272]                ; 16-byte Spill
	and.16b	v31, v7, v27
	str	q31, [sp, #2256]                ; 16-byte Spill
	and.16b	v8, v7, v20
	str	q8, [sp, #2288]                 ; 16-byte Spill
	ldp	x1, x2, [sp, #368]              ; 16-byte Folded Reload
	ldp	q16, q7, [x2]
	bit.16b	v7, v6, v0
	bit.16b	v16, v18, v17
	stp	q16, q7, [x2]
	ldp	q16, q7, [x1]
	bit.16b	v7, v5, v0
	bit.16b	v16, v23, v17
	stp	q16, q7, [x1]
	ldp	x1, x3, [sp, #352]              ; 16-byte Folded Reload
	ldp	q16, q7, [x3]
	ldr	q23, [sp, #2304]                ; 16-byte Reload
	bit.16b	v7, v23, v0
	ldr	q18, [sp, #2320]                ; 16-byte Reload
	bit.16b	v16, v18, v17
	stp	q16, q7, [x3]
	ldp	q16, q7, [x1]
	bit.16b	v7, v26, v0
	bit.16b	v16, v29, v17
	stp	q16, q7, [x1]
	zip1.8b	v7, v3, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	ldr	q3, [sp, #1504]                 ; 16-byte Reload
	and.16b	v3, v7, v3
	ldr	q4, [sp, #1488]                 ; 16-byte Reload
	and.16b	v4, v7, v4
	ldr	q5, [sp, #1472]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	ldr	q6, [sp, #1456]                 ; 16-byte Reload
	and.16b	v6, v7, v6
	ldr	q16, [sp, #1408]                ; 16-byte Reload
	and.16b	v19, v7, v16
	ldr	q16, [sp, #1392]                ; 16-byte Reload
	and.16b	v12, v7, v16
	ldr	q16, [sp, #1376]                ; 16-byte Reload
	and.16b	v20, v7, v16
	ldr	q16, [sp, #1360]                ; 16-byte Reload
	and.16b	v13, v7, v16
	ldr	q16, [sp, #1440]                ; 16-byte Reload
	and.16b	v9, v7, v16
	ldr	q16, [sp, #1424]                ; 16-byte Reload
	and.16b	v27, v7, v16
	ldr	q16, [sp, #1344]                ; 16-byte Reload
	and.16b	v28, v7, v16
	ldr	x1, [sp, #344]                  ; 8-byte Reload
	ldp	q16, q7, [x1]
	bit.16b	v7, v15, v0
	bit.16b	v16, v3, v17
	stp	q16, q7, [x1]
	ldr	x1, [sp, #336]                  ; 8-byte Reload
	ldp	q16, q7, [x1]
	bit.16b	v7, v25, v0
	bit.16b	v16, v4, v17
	stp	q16, q7, [x1]
	ldr	x1, [sp, #328]                  ; 8-byte Reload
	ldp	q16, q7, [x1]
	bit.16b	v7, v24, v0
	bit.16b	v16, v5, v17
	stp	q16, q7, [x1]
	ldp	q16, q7, [x22]
	bit.16b	v7, v22, v0
	bit.16b	v16, v6, v17
	stp	q16, q7, [x22]
	ldp	q7, q16, [x9]
	bit.16b	v7, v19, v17
	bit.16b	v16, v1, v0
	stp	q7, q16, [x9]
	ldp	q7, q16, [x25]
	bit.16b	v7, v12, v17
	bit.16b	v16, v10, v0
	stp	q7, q16, [x25]
	ldp	q7, q16, [x27]
	bit.16b	v7, v20, v17
	bit.16b	v16, v11, v0
	stp	q7, q16, [x27]
	ldp	q7, q16, [x20]
	bit.16b	v7, v13, v17
	bit.16b	v16, v21, v0
	stp	q7, q16, [x20]
	ldp	q16, q7, [x6]
	bit.16b	v7, v30, v0
	bit.16b	v16, v9, v17
	stp	q16, q7, [x6]
	ldp	q7, q16, [x7]
	bit.16b	v7, v27, v17
	bit.16b	v16, v31, v0
	stp	q7, q16, [x7]
	ldp	q7, q16, [x30]
	bit.16b	v7, v28, v17
	bit.16b	v16, v8, v0
	stp	q7, q16, [x30]
	ldr	q1, [sp, #624]                  ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #640]                  ; 16-byte Reload
	mov.16b	v16, v7
	bsl.16b	v16, v1, v14
	ldr	q1, [sp, #656]                  ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #672]                  ; 16-byte Reload
	mov.16b	v21, v7
	bsl.16b	v21, v1, v14
	sshll.2d	v7, v17, #0
	ldr	q1, [sp, #2208]                 ; 16-byte Reload
	ldr	q8, [sp, #1968]                 ; 16-byte Reload
	bit.16b	v8, v1, v7
	ldr	q14, [sp, #3152]                ; 16-byte Reload
	bit.16b	v14, v1, v7
	str	q14, [sp, #3152]                ; 16-byte Spill
	str	q21, [sp, #1216]                ; 16-byte Spill
	ldr	q1, [sp, #2976]                 ; 16-byte Reload
	bit.16b	v1, v21, v17
	str	q1, [sp, #2976]                 ; 16-byte Spill
	str	q16, [sp, #1232]                ; 16-byte Spill
	ldr	q1, [sp, #2960]                 ; 16-byte Reload
	bit.16b	v1, v16, v0
	str	q1, [sp, #2960]                 ; 16-byte Spill
	ldr	q1, [sp, #3008]                 ; 16-byte Reload
	ldr	q7, [sp, #2416]                 ; 16-byte Reload
	bit.16b	v1, v7, v17
	str	q1, [sp, #3008]                 ; 16-byte Spill
	ldr	q1, [sp, #2992]                 ; 16-byte Reload
	ldr	q7, [sp, #2400]                 ; 16-byte Reload
	bit.16b	v1, v7, v0
	str	q1, [sp, #2992]                 ; 16-byte Spill
	ldr	q1, [sp, #3040]                 ; 16-byte Reload
	ldr	q7, [sp, #2384]                 ; 16-byte Reload
	bit.16b	v1, v7, v17
	str	q1, [sp, #3040]                 ; 16-byte Spill
	ldr	q1, [sp, #3024]                 ; 16-byte Reload
	ldr	q7, [sp, #2368]                 ; 16-byte Reload
	bit.16b	v1, v7, v0
	str	q1, [sp, #3024]                 ; 16-byte Spill
	ldr	q1, [sp, #3072]                 ; 16-byte Reload
	ldr	q7, [sp, #2352]                 ; 16-byte Reload
	bit.16b	v1, v7, v17
	str	q1, [sp, #3072]                 ; 16-byte Spill
	ldr	q1, [sp, #3056]                 ; 16-byte Reload
	ldr	q7, [sp, #2336]                 ; 16-byte Reload
	bit.16b	v1, v7, v0
	str	q1, [sp, #3056]                 ; 16-byte Spill
	ldr	q1, [sp, #3104]                 ; 16-byte Reload
	bit.16b	v1, v18, v17
	str	q1, [sp, #3104]                 ; 16-byte Spill
	ldr	q1, [sp, #3088]                 ; 16-byte Reload
	bit.16b	v1, v23, v0
	str	q1, [sp, #3088]                 ; 16-byte Spill
	ldr	q21, [sp, #1664]                ; 16-byte Reload
	str	q29, [sp, #1520]                ; 16-byte Spill
	bit.16b	v21, v29, v17
	ldr	q7, [sp, #1648]                 ; 16-byte Reload
	str	q26, [sp, #1504]                ; 16-byte Spill
	bit.16b	v7, v26, v0
	ldr	q30, [sp, #1696]                ; 16-byte Reload
	str	q3, [sp, #1248]                 ; 16-byte Spill
	bit.16b	v30, v3, v17
	ldr	q31, [sp, #1680]                ; 16-byte Reload
	str	q15, [sp, #1440]                ; 16-byte Spill
	bit.16b	v31, v15, v0
	ldr	q26, [sp, #1728]                ; 16-byte Reload
	str	q4, [sp, #1280]                 ; 16-byte Spill
	bit.16b	v26, v4, v17
	ldr	q18, [sp, #1712]                ; 16-byte Reload
	str	q25, [sp, #1424]                ; 16-byte Spill
	bit.16b	v18, v25, v0
	ldr	q25, [sp, #1760]                ; 16-byte Reload
	str	q5, [sp, #1264]                 ; 16-byte Spill
	bit.16b	v25, v5, v17
	ldr	q29, [sp, #1744]                ; 16-byte Reload
	str	q24, [sp, #1472]                ; 16-byte Spill
	bit.16b	v29, v24, v0
	ldr	q23, [sp, #1792]                ; 16-byte Reload
	str	q6, [sp, #1312]                 ; 16-byte Spill
	bit.16b	v23, v6, v17
	ldr	q24, [sp, #1776]                ; 16-byte Reload
	str	q22, [sp, #1456]                ; 16-byte Spill
	bit.16b	v24, v22, v0
	ldr	q5, [sp, #1824]                 ; 16-byte Reload
	str	q19, [sp, #1296]                ; 16-byte Spill
	bit.16b	v5, v19, v17
	ldr	q22, [sp, #1808]                ; 16-byte Reload
	ldr	q1, [sp, #2224]                 ; 16-byte Reload
	bit.16b	v22, v1, v0
	ldr	q3, [sp, #1568]                 ; 16-byte Reload
	str	q12, [sp, #1344]                ; 16-byte Spill
	bit.16b	v3, v12, v17
	ldr	q4, [sp, #1840]                 ; 16-byte Reload
	str	q10, [sp, #1488]                ; 16-byte Spill
	bit.16b	v4, v10, v0
	str	q20, [sp, #1328]                ; 16-byte Spill
	ldr	q1, [sp, #3136]                 ; 16-byte Reload
	bit.16b	v1, v20, v17
	str	q1, [sp, #3136]                 ; 16-byte Spill
	ldr	q6, [sp, #2912]                 ; 16-byte Reload
	str	q11, [sp, #1568]                ; 16-byte Spill
	bit.16b	v6, v11, v0
	ldr	q11, [sp, #2048]                ; 16-byte Reload
	str	q13, [sp, #1376]                ; 16-byte Spill
	bit.16b	v11, v13, v17
	mov.16b	v1, v7
	ldr	q15, [sp, #2032]                ; 16-byte Reload
	ldr	q7, [sp, #2240]                 ; 16-byte Reload
	bit.16b	v15, v7, v0
	ldr	q13, [sp, #2080]                ; 16-byte Reload
	str	q9, [sp, #1360]                 ; 16-byte Spill
	bit.16b	v13, v9, v17
	ldr	q14, [sp, #2064]                ; 16-byte Reload
	ldr	q7, [sp, #2272]                 ; 16-byte Reload
	bit.16b	v14, v7, v0
	ldr	q9, [sp, #2112]                 ; 16-byte Reload
	str	q27, [sp, #1408]                ; 16-byte Spill
	bit.16b	v9, v27, v17
	ldr	q10, [sp, #2096]                ; 16-byte Reload
	ldr	q7, [sp, #2256]                 ; 16-byte Reload
	bit.16b	v10, v7, v0
	ldr	q27, [sp, #2144]                ; 16-byte Reload
	str	q28, [sp, #1392]                ; 16-byte Spill
	bit.16b	v27, v28, v17
	ldr	q28, [sp, #2128]                ; 16-byte Reload
	ldr	q7, [sp, #2288]                 ; 16-byte Reload
	bit.16b	v28, v7, v0
LBB1_77:                                ; %direct.true738.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	d20, x0
	ldr	q7, [sp, #3120]                 ; 16-byte Reload
	orr.16b	v7, v20, v7
	fmov	x1, d7
	add	x1, x8, x1
	ldp	q16, q7, [x1]
	and.16b	v16, v17, v16
	orr.16b	v19, v20, v8
	ldr	q12, [sp, #2976]                ; 16-byte Reload
	fmul.4s	v16, v12, v16
	fmov	x1, d19
	add	x1, x13, x1
	ldr	q19, [x1]
	and.16b	v19, v17, v19
	ldr	q12, [sp, #3008]                ; 16-byte Reload
	fmul.4s	v19, v12, v19
	fadd.4s	v16, v16, v19
	ldr	q19, [x1, #16]
	and.16b	v7, v0, v7
	ldr	q12, [sp, #2960]                ; 16-byte Reload
	fmul.4s	v7, v12, v7
	and.16b	v19, v0, v19
	ldr	q12, [sp, #2992]                ; 16-byte Reload
	fmul.4s	v19, v12, v19
	fadd.4s	v7, v7, v19
	add	x1, x5, x0
	ldr	q19, [x1, #16]
	and.16b	v19, v0, v19
	ldr	q12, [sp, #3024]                ; 16-byte Reload
	fmul.4s	v19, v12, v19
	fadd.4s	v7, v7, v19
	ldr	q19, [x1]
	and.16b	v19, v17, v19
	ldr	q12, [sp, #3040]                ; 16-byte Reload
	fmul.4s	v19, v12, v19
	fadd.4s	v16, v16, v19
	ldr	q19, [x1, #3072]
	and.16b	v19, v17, v19
	ldr	q12, [sp, #3072]                ; 16-byte Reload
	fmul.4s	v19, v12, v19
	fadd.4s	v16, v16, v19
	ldr	q19, [x1, #3088]
	and.16b	v19, v0, v19
	ldr	q12, [sp, #3056]                ; 16-byte Reload
	fmul.4s	v19, v12, v19
	fadd.4s	v7, v7, v19
	ldr	q19, [x1, #6160]
	and.16b	v19, v0, v19
	ldr	q12, [sp, #3088]                ; 16-byte Reload
	fmul.4s	v19, v12, v19
	fadd.4s	v7, v7, v19
	ldr	q19, [x1, #6144]
	and.16b	v19, v17, v19
	ldr	q12, [sp, #3104]                ; 16-byte Reload
	fmul.4s	v19, v12, v19
	fadd.4s	v16, v16, v19
	ldr	q19, [x1, #9216]
	and.16b	v19, v17, v19
	fmul.4s	v19, v21, v19
	fadd.4s	v16, v16, v19
	ldr	q19, [x1, #9232]
	and.16b	v19, v0, v19
	fmul.4s	v19, v1, v19
	fadd.4s	v7, v7, v19
	ldr	q19, [x1, #12304]
	and.16b	v19, v0, v19
	fmul.4s	v19, v31, v19
	fadd.4s	v7, v7, v19
	ldr	q19, [x1, #12288]
	and.16b	v19, v17, v19
	fmul.4s	v19, v30, v19
	fadd.4s	v16, v16, v19
	ldr	q19, [x1, #15360]
	and.16b	v19, v17, v19
	fmul.4s	v19, v26, v19
	fadd.4s	v16, v16, v19
	ldr	q19, [x1, #15376]
	and.16b	v19, v0, v19
	fmul.4s	v19, v18, v19
	fadd.4s	v7, v7, v19
	ldr	q19, [x1, #18448]
	and.16b	v19, v0, v19
	fmul.4s	v19, v29, v19
	fadd.4s	v7, v7, v19
	ldr	q19, [x1, #18432]
	and.16b	v19, v17, v19
	fmul.4s	v19, v25, v19
	fadd.4s	v16, v16, v19
	ldr	q19, [x1, #21504]
	and.16b	v19, v17, v19
	fmul.4s	v19, v23, v19
	fadd.4s	v16, v16, v19
	ldr	q19, [x1, #21520]
	and.16b	v19, v0, v19
	fmul.4s	v19, v24, v19
	fadd.4s	v7, v7, v19
	ldr	q19, [x1, #24592]
	and.16b	v19, v0, v19
	fmul.4s	v19, v22, v19
	fadd.4s	v7, v7, v19
	ldr	q19, [x1, #24576]
	and.16b	v19, v17, v19
	fmul.4s	v19, v5, v19
	fadd.4s	v16, v16, v19
	ldr	q19, [x1, #27648]
	and.16b	v19, v17, v19
	fmul.4s	v19, v3, v19
	fadd.4s	v16, v16, v19
	ldr	q19, [x1, #27664]
	and.16b	v19, v0, v19
	fmul.4s	v19, v4, v19
	fadd.4s	v7, v7, v19
	ldr	q19, [x1, #30736]
	and.16b	v19, v0, v19
	fmul.4s	v19, v6, v19
	fadd.4s	v7, v7, v19
	ldr	q19, [x1, #30720]
	and.16b	v19, v17, v19
	ldr	q12, [sp, #3136]                ; 16-byte Reload
	fmul.4s	v19, v12, v19
	fadd.4s	v16, v16, v19
	ldr	q19, [x1, #33792]
	and.16b	v19, v17, v19
	fmul.4s	v19, v11, v19
	fadd.4s	v16, v16, v19
	ldr	q19, [x1, #33808]
	and.16b	v19, v0, v19
	fmul.4s	v19, v15, v19
	fadd.4s	v7, v7, v19
	ldr	q19, [x1, #36880]
	and.16b	v19, v0, v19
	fmul.4s	v19, v14, v19
	fadd.4s	v7, v7, v19
	ldr	q19, [x1, #36864]
	and.16b	v19, v17, v19
	fmul.4s	v19, v13, v19
	fadd.4s	v16, v16, v19
	ldr	q19, [x1, #39936]
	and.16b	v19, v17, v19
	fmul.4s	v19, v9, v19
	fadd.4s	v16, v16, v19
	ldr	q19, [x1, #39952]
	and.16b	v19, v0, v19
	fmul.4s	v19, v10, v19
	fadd.4s	v7, v7, v19
	ldr	q19, [x1, #43024]
	and.16b	v19, v0, v19
	fmul.4s	v19, v28, v19
	fadd.4s	v7, v7, v19
	ldr	q19, [x1, #43008]
	and.16b	v19, v17, v19
	fmul.4s	v19, v27, v19
	fadd.4s	v16, v16, v19
	ldr	q19, [sp, #3152]                ; 16-byte Reload
	orr.16b	v19, v20, v19
	fmov	x1, d19
	add	x1, x15, x1
	ldp	q20, q19, [x1]
	bif.16b	v16, v20, v17
	bif.16b	v7, v19, v0
	stp	q16, q7, [x1]
	add	x0, x0, #32
	cmp	x0, #3072
	b.ne	LBB1_77
; %bb.78:                               ; %direct.true866.i.i.preheader
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q8, [sp, #1968]                 ; 16-byte Spill
	mov.16b	v8, v21
	str	q6, [sp, #2912]                 ; 16-byte Spill
	ldr	q6, [sp, #3136]                 ; 16-byte Reload
	str	q11, [sp, #2048]                ; 16-byte Spill
	str	q14, [sp, #2064]                ; 16-byte Spill
	str	q13, [sp, #2080]                ; 16-byte Spill
	str	q10, [sp, #2096]                ; 16-byte Spill
	str	q9, [sp, #2112]                 ; 16-byte Spill
	str	q28, [sp, #2128]                ; 16-byte Spill
	str	q27, [sp, #2144]                ; 16-byte Spill
	mov	x0, #0                          ; =0x0
	ldp	q10, q9, [sp, #560]             ; 32-byte Folded Reload
	ldp	q14, q13, [sp, #512]            ; 32-byte Folded Reload
	ldr	q27, [sp, #1632]                ; 16-byte Reload
	ldr	q28, [sp, #1616]                ; 16-byte Reload
	ldr	q21, [sp, #3120]                ; 16-byte Reload
	ldr	q11, [sp, #3152]                ; 16-byte Reload
LBB1_79:                                ; %direct.true866.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	d7, x0
	orr.16b	v16, v7, v11
	fmov	x1, d16
	add	x1, x15, x1
	ldp	q16, q19, [x1]
	orr.16b	v7, v7, v21
	fmov	x1, d7
	add	x1, x11, x1
	ldp	q7, q20, [x1]
	bif.16b	v19, v20, v0
	bit.16b	v7, v16, v17
	stp	q7, q19, [x1]
	add	x0, x0, #32
	cmp	x0, #3072
	b.ne	LBB1_79
; %bb.80:                               ; %direct.true882.i.i.preheader
                                        ;   in Loop: Header=BB1_34 Depth=2
	mov	x0, x10
	mov	w1, #96                         ; =0x60
	str	q15, [sp, #2032]                ; 16-byte Spill
	mov.16b	v21, v3
	str	q4, [sp, #1840]                 ; 16-byte Spill
	str	q5, [sp, #1824]                 ; 16-byte Spill
	str	q22, [sp, #1808]                ; 16-byte Spill
	str	q23, [sp, #1792]                ; 16-byte Spill
	str	q24, [sp, #1776]                ; 16-byte Spill
	str	q25, [sp, #1760]                ; 16-byte Spill
	str	q29, [sp, #1744]                ; 16-byte Spill
	str	q26, [sp, #1728]                ; 16-byte Spill
	str	q18, [sp, #1712]                ; 16-byte Spill
	str	q30, [sp, #1696]                ; 16-byte Spill
	str	q31, [sp, #1680]                ; 16-byte Spill
	str	q8, [sp, #1664]                 ; 16-byte Spill
	str	q1, [sp, #1648]                 ; 16-byte Spill
LBB1_81:                                ; %direct.true882.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q7, [x0, #5632]
	ldr	q16, [x0, #5648]
	ldr	q19, [x0, #2560]
	ldr	q20, [x0, #2576]
	bif.16b	v16, v20, v0
	bif.16b	v7, v19, v17
	str	q7, [x0, #2560]
	str	q16, [x0, #2576]
	add	x0, x0, #32
	subs	x1, x1, #1
	b.ne	LBB1_81
; %bb.82:                               ; %direct.false883.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	ldr	q7, [sp, #2944]                 ; 16-byte Reload
	ldr	q1, [sp, #1536]                 ; 16-byte Reload
	bit.16b	v7, v1, v0
	str	q7, [sp, #2944]                 ; 16-byte Spill
	ldr	q7, [sp, #2928]                 ; 16-byte Reload
	ldr	q1, [sp, #1552]                 ; 16-byte Reload
	bit.16b	v7, v1, v17
	str	q7, [sp, #2928]                 ; 16-byte Spill
	movi.2d	v16, #0000000000000000
	ldr	q1, [sp, #2416]                 ; 16-byte Reload
	fadd.4s	v7, v1, v16
	ldr	q1, [sp, #2384]                 ; 16-byte Reload
	fadd.4s	v7, v1, v7
	ldr	q1, [sp, #2400]                 ; 16-byte Reload
	fadd.4s	v16, v1, v16
	ldr	q1, [sp, #2368]                 ; 16-byte Reload
	fadd.4s	v16, v1, v16
	ldr	q1, [sp, #2336]                 ; 16-byte Reload
	fadd.4s	v16, v1, v16
	ldr	q1, [sp, #2352]                 ; 16-byte Reload
	fadd.4s	v7, v1, v7
	ldr	q1, [sp, #2320]                 ; 16-byte Reload
	fadd.4s	v7, v1, v7
	ldr	q1, [sp, #2304]                 ; 16-byte Reload
	fadd.4s	v16, v1, v16
	ldr	q1, [sp, #1504]                 ; 16-byte Reload
	fadd.4s	v16, v1, v16
	ldr	q1, [sp, #1520]                 ; 16-byte Reload
	fadd.4s	v7, v1, v7
	ldr	q1, [sp, #1248]                 ; 16-byte Reload
	fadd.4s	v7, v1, v7
	ldr	q1, [sp, #1440]                 ; 16-byte Reload
	fadd.4s	v16, v1, v16
	ldr	q1, [sp, #1424]                 ; 16-byte Reload
	fadd.4s	v16, v1, v16
	ldr	q1, [sp, #1280]                 ; 16-byte Reload
	fadd.4s	v7, v1, v7
	ldr	q1, [sp, #1264]                 ; 16-byte Reload
	fadd.4s	v7, v1, v7
	ldr	q1, [sp, #1472]                 ; 16-byte Reload
	fadd.4s	v16, v1, v16
	ldr	q1, [sp, #1456]                 ; 16-byte Reload
	fadd.4s	v16, v1, v16
	ldr	q1, [sp, #1312]                 ; 16-byte Reload
	fadd.4s	v7, v1, v7
	ldr	q1, [sp, #1296]                 ; 16-byte Reload
	fadd.4s	v7, v1, v7
	ldr	q1, [sp, #2224]                 ; 16-byte Reload
	fadd.4s	v16, v1, v16
	ldr	q1, [sp, #1488]                 ; 16-byte Reload
	fadd.4s	v16, v1, v16
	ldr	q1, [sp, #1344]                 ; 16-byte Reload
	fadd.4s	v7, v1, v7
	ldr	q1, [sp, #1328]                 ; 16-byte Reload
	fadd.4s	v7, v1, v7
	ldr	q1, [sp, #1568]                 ; 16-byte Reload
	fadd.4s	v16, v1, v16
	ldr	q1, [sp, #2240]                 ; 16-byte Reload
	fadd.4s	v16, v1, v16
	ldr	q1, [sp, #1376]                 ; 16-byte Reload
	fadd.4s	v7, v1, v7
	ldr	q1, [sp, #1360]                 ; 16-byte Reload
	fadd.4s	v7, v1, v7
	ldr	q1, [sp, #2272]                 ; 16-byte Reload
	fadd.4s	v16, v1, v16
	ldr	q1, [sp, #2256]                 ; 16-byte Reload
	fadd.4s	v16, v1, v16
	ldr	q1, [sp, #1408]                 ; 16-byte Reload
	fadd.4s	v7, v1, v7
	ldr	q1, [sp, #1392]                 ; 16-byte Reload
	fadd.4s	v7, v1, v7
	ldr	q1, [sp, #2288]                 ; 16-byte Reload
	fadd.4s	v16, v1, v16
	ldr	q1, [sp, #1216]                 ; 16-byte Reload
	fmul.4s	v19, v27, v1
	ldr	q1, [sp, #1232]                 ; 16-byte Reload
	fmul.4s	v20, v28, v1
	fadd.4s	v16, v20, v16
	fadd.4s	v7, v19, v7
	bit.16b	v27, v7, v17
	bit.16b	v28, v16, v0
	add	x4, x4, #1
	cmp	x4, #129
	mov.16b	v16, v6
	ldr	q1, [sp, #2912]                 ; 16-byte Reload
	ldr	q31, [sp, #1600]                ; 16-byte Reload
	ldr	q6, [sp, #2624]                 ; 16-byte Reload
	ldr	q3, [sp, #2608]                 ; 16-byte Reload
	ldr	q4, [sp, #2592]                 ; 16-byte Reload
	ldr	q5, [sp, #2576]                 ; 16-byte Reload
	ldr	q22, [sp, #2560]                ; 16-byte Reload
	ldr	q23, [sp, #2544]                ; 16-byte Reload
	ldr	q24, [sp, #2528]                ; 16-byte Reload
	ldr	q25, [sp, #2512]                ; 16-byte Reload
	ldr	q29, [sp, #2496]                ; 16-byte Reload
	ldr	q26, [sp, #2480]                ; 16-byte Reload
	ldr	q18, [sp, #2464]                ; 16-byte Reload
	ldr	q30, [sp, #2448]                ; 16-byte Reload
	ldr	q15, [sp, #2432]                ; 16-byte Reload
	ldr	q8, [sp, #1584]                 ; 16-byte Reload
	b.ne	LBB1_34
; %bb.83:                               ; %direct.schedule.83.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x9, #0                          ; =0x0
	ldp	q1, q2, [sp, #128]              ; 32-byte Folded Reload
	fmov	x10, d1
	add	x10, x10, x10, lsl #1
	lsl	x10, x10, #5
	fmov	d1, x10
	ldr	x10, [sp, #104]                 ; 8-byte Reload
	add	x10, x10, x10, lsl #1
	lsl	x10, x10, #5
	mov.d	v1[1], x10
	fmov	x10, d2
	add	x10, x10, x10, lsl #1
	lsl	x10, x10, #5
	fmov	d2, x10
	ldr	x10, [sp, #120]                 ; 8-byte Reload
	add	x10, x10, x10, lsl #1
	lsl	x10, x10, #5
	mov.d	v2[1], x10
	ldr	q3, [sp, #160]                  ; 16-byte Reload
	fmov	x10, d3
	add	x10, x10, x10, lsl #1
	lsl	x10, x10, #5
	fmov	d3, x10
	ldr	x10, [sp, #112]                 ; 8-byte Reload
	add	x10, x10, x10, lsl #1
	lsl	x10, x10, #5
	mov.d	v3[1], x10
	ldr	q4, [sp, #192]                  ; 16-byte Reload
	fmov	x10, d4
	add	x10, x10, x10, lsl #1
	lsl	x10, x10, #5
	fmov	d4, x10
	ldr	x10, [sp, #184]                 ; 8-byte Reload
	add	x10, x10, x10, lsl #1
	lsl	x10, x10, #5
	mov.d	v4[1], x10
	ldr	w21, [sp, #100]                 ; 4-byte Reload
	ldp	x25, x22, [sp, #80]             ; 16-byte Folded Reload
	ldr	w27, [sp, #220]                 ; 4-byte Reload
	ldr	q21, [sp, #256]                 ; 16-byte Reload
	ldr	x2, [sp, #296]                  ; 8-byte Reload
	ldr	w12, [sp, #292]                 ; 4-byte Reload
	ldr	w13, [sp, #288]                 ; 4-byte Reload
	ldr	x14, [sp, #208]                 ; 8-byte Reload
	b	LBB1_85
LBB1_84:                                ; %else285
                                        ;   in Loop: Header=BB1_85 Depth=2
	add	x9, x9, #1
	cmp	x9, #96
	b.eq	LBB1_2
LBB1_85:                                ; %direct.true901.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	uzp1.8h	v5, v17, v0
	and.16b	v5, v5, v21
	addv.8h	h5, v5
	fmov	w10, s5
	dup.2d	v5, x9
	add.2d	v6, v5, v1
	add	x11, x8, x9, lsl #5
	ldp	q16, q7, [x11]
	and.16b	v16, v17, v16
	fdiv.4s	v16, v16, v27
	shl.2d	v18, v6, #2
	dup.2d	v6, x14
	add.2d	v18, v6, v18
	tbnz	w10, #0, LBB1_93
; %bb.86:                               ; %else264
                                        ;   in Loop: Header=BB1_85 Depth=2
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB1_94
LBB1_87:                                ; %else267
                                        ;   in Loop: Header=BB1_85 Depth=2
	add.2d	v18, v5, v2
	shl.2d	v18, v18, #2
	add.2d	v18, v6, v18
	tbnz	w10, #2, LBB1_95
LBB1_88:                                ; %else270
                                        ;   in Loop: Header=BB1_85 Depth=2
	tbnz	w10, #3, LBB1_96
LBB1_89:                                ; %else273
                                        ;   in Loop: Header=BB1_85 Depth=2
	add.2d	v16, v5, v3
	and.16b	v7, v0, v7
	fdiv.4s	v7, v7, v28
	shl.2d	v16, v16, #2
	add.2d	v16, v6, v16
	tbnz	w10, #4, LBB1_97
LBB1_90:                                ; %else276
                                        ;   in Loop: Header=BB1_85 Depth=2
	tbnz	w10, #5, LBB1_98
LBB1_91:                                ; %else279
                                        ;   in Loop: Header=BB1_85 Depth=2
	add.2d	v5, v5, v4
	shl.2d	v5, v5, #2
	add.2d	v5, v6, v5
	tbnz	w10, #6, LBB1_99
LBB1_92:                                ; %else282
                                        ;   in Loop: Header=BB1_85 Depth=2
	tbz	w10, #7, LBB1_84
	b	LBB1_100
LBB1_93:                                ; %cond.store
                                        ;   in Loop: Header=BB1_85 Depth=2
	fmov	x11, d18
	str	s16, [x11]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB1_87
LBB1_94:                                ; %cond.store265
                                        ;   in Loop: Header=BB1_85 Depth=2
	mov.d	x11, v18[1]
	st1.s	{ v16 }[1], [x11]
	add.2d	v18, v5, v2
	shl.2d	v18, v18, #2
	add.2d	v18, v6, v18
	tbz	w10, #2, LBB1_88
LBB1_95:                                ; %cond.store268
                                        ;   in Loop: Header=BB1_85 Depth=2
	fmov	x11, d18
	st1.s	{ v16 }[2], [x11]
	tbz	w10, #3, LBB1_89
LBB1_96:                                ; %cond.store271
                                        ;   in Loop: Header=BB1_85 Depth=2
	mov.d	x11, v18[1]
	st1.s	{ v16 }[3], [x11]
	add.2d	v16, v5, v3
	and.16b	v7, v0, v7
	fdiv.4s	v7, v7, v28
	shl.2d	v16, v16, #2
	add.2d	v16, v6, v16
	tbz	w10, #4, LBB1_90
LBB1_97:                                ; %cond.store274
                                        ;   in Loop: Header=BB1_85 Depth=2
	fmov	x11, d16
	str	s7, [x11]
	tbz	w10, #5, LBB1_91
LBB1_98:                                ; %cond.store277
                                        ;   in Loop: Header=BB1_85 Depth=2
	mov.d	x11, v16[1]
	st1.s	{ v7 }[1], [x11]
	add.2d	v5, v5, v4
	shl.2d	v5, v5, #2
	add.2d	v5, v6, v5
	tbz	w10, #6, LBB1_92
LBB1_99:                                ; %cond.store280
                                        ;   in Loop: Header=BB1_85 Depth=2
	fmov	x11, d5
	st1.s	{ v7 }[2], [x11]
	tbz	w10, #7, LBB1_84
LBB1_100:                               ; %cond.store283
                                        ;   in Loop: Header=BB1_85 Depth=2
	mov.d	x10, v5[1]
	st1.s	{ v7 }[3], [x10]
	b	LBB1_84
LBB1_101:
	add	sp, sp, #3328
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
LBB1_102:                               ; %block.batch.exit
	ret
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
                                        ; -- End function
.subsections_via_symbols

; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

@convergence.targets = private unnamed_addr constant [21 x i32] [i32 2, i32 4, i32 6, i32 8, i32 10, i32 41, i32 14, i32 16, i32 18, i32 20, i32 22, i32 24, i32 26, i32 28, i32 31, i32 34, i32 37, i32 40, i32 43, i32 45, i32 47], align 4

define internal void @llm_attention(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %live.mask = alloca <8 x i1>, align 1
  %runnable.mask = alloca <8 x i1>, align 1
  %ready.count = alloca i32, align 4
  %ready.mask = alloca [8 x <8 x i1>], align 1
  %ready.target = alloca [8 x i32], align 4
  %ready.token = alloca [8 x i32], align 4
  %current.mask = alloca <8 x i1>, align 1
  %current.token = alloca i32, align 4
  %frame.active = alloca i8, align 1
  %frame.static.id = alloca <8 x i32>, align 32
  %frame.parent.token = alloca <8 x i32>, align 32
  %frame.expected = alloca [8 x <8 x i1>], align 1
  %frame.arrived = alloca [8 x <8 x i1>], align 1
  store <8 x i1> zeroinitializer, ptr %live.mask, align 1
  store <8 x i1> zeroinitializer, ptr %runnable.mask, align 1
  store i32 0, ptr %ready.count, align 4
  store [8 x <8 x i1>] zeroinitializer, ptr %ready.mask, align 1
  store [8 x i32] zeroinitializer, ptr %ready.target, align 4
  store [8 x i32] zeroinitializer, ptr %ready.token, align 4
  store <8 x i1> zeroinitializer, ptr %current.mask, align 1
  store i32 0, ptr %current.token, align 4
  store i8 0, ptr %frame.active, align 1
  store <8 x i32> zeroinitializer, ptr %frame.static.id, align 32
  store <8 x i32> zeroinitializer, ptr %frame.parent.token, align 32
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.expected, align 1
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.arrived, align 1
  %tile_snapshot.local = alloca [192 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [192 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca i64, align 8
  store i64 0, ptr %.spill4, align 4
  %.spill5 = alloca i64, align 8
  store volatile i64 0, ptr %.spill5, align 4
  %.spill6 = alloca i64, align 8
  store volatile i64 0, ptr %.spill6, align 4
  %.spill7 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill7, align 64
  %.spill8 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill8, align 64
  %.spill9 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill9, align 32
  %.spill10 = alloca i64, align 8
  store i64 0, ptr %.spill10, align 4
  %.spill11 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill11, align 32
  %.spill12 = alloca i64, align 8
  store i64 0, ptr %.spill12, align 4
  %.spill13 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill13, align 32
  %.spill14 = alloca i64, align 8
  store volatile i64 0, ptr %.spill14, align 4
  %.spill15 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill15, align 32
  %.spill16 = alloca i64, align 8
  store volatile i64 0, ptr %.spill16, align 4
  %.spill17 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill17, align 32
  %.spill18 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill18, align 64
  %.spill19 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill19, align 64
  %.spill20 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill20, align 1
  %.spill21 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill21, align 64
  %.spill22 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill22, align 64
  %.slot = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot, align 32
  %.spill23 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill23, align 64
  %.slot24 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot24, align 32
  %.spill25 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill25, align 64
  %.slot26 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot26, align 32
  %.spill27 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill27, align 64
  %.slot28 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot28, align 32
  %.spill29 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill29, align 64
  %.slot30 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot30, align 32
  %.slot31 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot31, align 64
  %.slot32 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot32, align 32
  %.slot33 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot33, align 32
  %.slot34 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot34, align 32
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.slot36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot36, align 32
  %.slot37 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot37, align 32
  %.slot38 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot38, align 32
  %.slot39 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot39, align 32
  %.slot40 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot40, align 32
  %.slot41 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot41, align 32
  %.spill42 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill42, align 64
  %.spill43 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill43, align 64
  %.spill44 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill44, align 32
  %.spill45 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill45, align 32
  %.spill46 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill46, align 32
  %.spill47 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill47, align 32
  %.spill48 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill48, align 32
  %.spill49 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill49, align 64
  %.spill50 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill50, align 64
  %.spill51 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill51, align 32
  %.spill52 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill52, align 32
  %.spill53 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill53, align 32
  %.spill54 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill54, align 32
  %.spill55 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill55, align 32
  %.spill56 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill56, align 64
  %.spill57 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill57, align 64
  %.spill58 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill58, align 1
  %.spill59 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill59, align 1
  %.spill60 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill60, align 64
  %.spill61 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill61, align 64
  %.slot62 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot62, align 32
  %.spill63 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill63, align 64
  %.slot64 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot64, align 32
  %.spill65 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill65, align 64
  %.slot66 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot66, align 32
  %.spill67 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill67, align 64
  %.slot68 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot68, align 32
  %.spill69 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill69, align 64
  %.slot70 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot70, align 32
  %.spill71 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill71, align 32
  %.spill72 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill72, align 32
  %.spill73 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill73, align 32
  %.spill74 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill74, align 32
  %.spill75 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill75, align 32
  %.spill76 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill76, align 32
  %.spill77 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill77, align 64
  %.spill78 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill78, align 64
  %.slot79 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot79, align 32
  %.spill80 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill80, align 64
  %.slot81 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot81, align 32
  %.spill82 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill82, align 64
  %.slot83 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot83, align 32
  %.spill84 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill84, align 1
  %.spill85 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill85, align 1
  %.spill86 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill86, align 1
  %.spill87 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill87, align 1
  %.spill88 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill88, align 1
  %.spill89 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill89, align 1
  %.spill90 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill90, align 32
  %.spill91 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill91, align 32
  %.spill92 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill92, align 32
  %.spill93 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill93, align 32
  %.spill94 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill94, align 32
  %.spill95 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill95, align 32
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot96 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot96, align 64
  %.slot97 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot97, align 32
  %.slot98 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot98, align 64
  %.slot99 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot99, align 32
  %.spill100 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill100, align 32
  %.spill101 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill101, align 32
  %.spill102 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill102, align 32
  %.spill103 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill103, align 32
  %.spill104 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill104, align 32
  %.spill105 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill105, align 32
  %.spill106 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill106, align 32
  %.spill107 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill107, align 32
  %.spill108 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill108, align 32
  %.spill109 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill109, align 32
  %tile_snapshot.spill110 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill110, align 64
  %.spill111 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill111, align 32
  %.spill112 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill112, align 32
  %.slot113 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot113, align 64
  %.slot114 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot114, align 32
  %.slot115 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot115, align 64
  %.slot116 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot116, align 32
  %.spill117 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill117, align 32
  %.spill118 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill118, align 32
  %.spill119 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill119, align 32
  %.spill120 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill120, align 64
  %.spill121 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill121, align 64
  %.spill122 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill122, align 64
  %.spill123 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill123, align 64
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert124 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat125 = shufflevector <8 x i32> %.splatinsert124, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat125, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert126 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat127 = shufflevector <8 x i32> %.splatinsert126, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat127, %41
  %44 = mul i32 %32, 1
  %.splatinsert128 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat129 = shufflevector <8 x i32> %.splatinsert128, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat129, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert130 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat131 = shufflevector <8 x i32> %.splatinsert130, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat131, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert132 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat133 = shufflevector <8 x i32> %.splatinsert132, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat133
  store <8 x i1> %51, ptr %live.mask, align 1
  %52 = load i32, ptr %current.token, align 4
  %53 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %54 = load i32, ptr %ready.count, align 4
  %55 = icmp uge i32 %54, 8
  %56 = and i1 %53, %55
  br i1 %56, label %ready.overflow.trap, label %ready.overflow.resume

ready.overflow.trap:                              ; preds = %prologue
  call void @llvm.trap()
  unreachable

ready.overflow.resume:                            ; preds = %prologue
  %57 = select i1 %53, i32 %54, i32 0
  %58 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %57
  %59 = load <8 x i1>, ptr %58, align 1
  %60 = select i1 %53, <8 x i1> %51, <8 x i1> %59
  store <8 x i1> %60, ptr %58, align 1
  %61 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %57
  %62 = load i32, ptr %61, align 4
  %63 = select i1 %53, i32 0, i32 %62
  store i32 %63, ptr %61, align 4
  %64 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %57
  %65 = load i32, ptr %64, align 4
  %66 = select i1 %53, i32 %52, i32 %65
  store i32 %66, ptr %64, align 4
  %67 = add i32 %54, 1
  %68 = select i1 %53, i32 %67, i32 %54
  store i32 %68, ptr %ready.count, align 4
  %69 = load <8 x i1>, ptr %runnable.mask, align 1
  %70 = or <8 x i1> %69, %51
  store <8 x i1> %70, ptr %runnable.mask, align 1
  br label %scheduler.loop

scheduler.loop:                                   ; preds = %return.frame.cleanup.done, %convergence.cascade.exit1001, %schedule.46, %varying.coherent.false997, %varying.coherent.true996, %convergence.cascade.exit969, %schedule.44, %varying.coherent.false965, %varying.coherent.true964, %convergence.cascade.exit937, %schedule.42, %varying.coherent.false933, %varying.coherent.true932, %convergence.cascade.exit883, %convergence.target.40.ready, %convergence.cascade.exit811, %schedule.39, %varying.coherent.false802, %varying.coherent.true801, %convergence.target.37.ready, %convergence.cascade.exit778, %schedule.36, %varying.coherent.false769, %varying.coherent.true768, %convergence.target.34.ready, %convergence.cascade.exit706, %schedule.33, %varying.coherent.false697, %varying.coherent.true696, %convergence.target.31.ready, %convergence.cascade.exit673, %schedule.30, %varying.coherent.false665, %varying.coherent.true664, %convergence.target.28.ready, %convergence.cascade.exit559, %schedule.27, %varying.coherent.false556, %varying.coherent.true555, %convergence.cascade.exit528, %schedule.25, %varying.coherent.false525, %varying.coherent.true524, %convergence.cascade.exit497, %schedule.23, %varying.coherent.false494, %varying.coherent.true493, %convergence.cascade.exit446, %schedule.21, %varying.coherent.false443, %varying.coherent.true442, %convergence.cascade.exit415, %schedule.19, %varying.coherent.false412, %varying.coherent.true411, %convergence.cascade.exit384, %schedule.17, %varying.coherent.false381, %varying.coherent.true380, %convergence.cascade.exit353, %schedule.15, %varying.coherent.false350, %varying.coherent.true349, %convergence.cascade.exit322, %schedule.13, %varying.coherent.false319, %varying.coherent.true318, %varying.coherent.false273, %varying.coherent.true272, %convergence.target.10.ready, %convergence.cascade.exit250, %schedule.9, %varying.coherent.false247, %varying.coherent.true246, %convergence.cascade.exit219, %schedule.7, %varying.coherent.false216, %varying.coherent.true215, %convergence.cascade.exit188, %schedule.5, %varying.coherent.false185, %varying.coherent.true184, %convergence.cascade.exit157, %schedule.3, %varying.coherent.false154, %varying.coherent.true153, %convergence.cascade.exit, %schedule.1, %varying.coherent.false, %varying.coherent.true, %ready.overflow.resume
  %71 = load i32, ptr %ready.count, align 4
  %72 = icmp ne i32 %71, 0
  br i1 %72, label %scheduler.dispatch, label %scheduler.done

scheduler.dispatch:                               ; preds = %scheduler.loop
  %73 = sub i32 %71, 1
  store i32 %73, ptr %ready.count, align 4
  %74 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %73
  %75 = load <8 x i1>, ptr %74, align 1
  store <8 x i1> %75, ptr %current.mask, align 1
  %76 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %73
  %77 = load i32, ptr %76, align 4
  %78 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %73
  %79 = load i32, ptr %78, align 4
  store i32 %79, ptr %current.token, align 4
  %80 = load <8 x i1>, ptr %runnable.mask, align 1
  %81 = xor <8 x i1> %75, splat (i1 true)
  %82 = and <8 x i1> %80, %81
  store <8 x i1> %82, ptr %runnable.mask, align 1
  br label %scheduler.dispatch.route

scheduler.dispatch.route:                         ; preds = %ready.overflow.resume995, %ready.overflow.resume963, %ready.overflow.resume931, %ready.overflow.resume800, %ready.overflow.resume767, %ready.overflow.resume695, %ready.overflow.resume663, %ready.overflow.resume554, %ready.overflow.resume523, %ready.overflow.resume492, %ready.overflow.resume441, %ready.overflow.resume410, %ready.overflow.resume379, %ready.overflow.resume348, %ready.overflow.resume317, %ready.overflow.resume271, %ready.overflow.resume245, %ready.overflow.resume214, %ready.overflow.resume183, %ready.overflow.resume152, %ready.overflow.resume135, %scheduler.dispatch
  %scheduler.dispatch.pc = phi i32 [ %77, %scheduler.dispatch ], [ 2, %ready.overflow.resume135 ], [ 4, %ready.overflow.resume152 ], [ 6, %ready.overflow.resume183 ], [ 8, %ready.overflow.resume214 ], [ 10, %ready.overflow.resume245 ], [ 41, %ready.overflow.resume271 ], [ 14, %ready.overflow.resume317 ], [ 16, %ready.overflow.resume348 ], [ 18, %ready.overflow.resume379 ], [ 20, %ready.overflow.resume410 ], [ 22, %ready.overflow.resume441 ], [ 24, %ready.overflow.resume492 ], [ 26, %ready.overflow.resume523 ], [ 28, %ready.overflow.resume554 ], [ 31, %ready.overflow.resume663 ], [ 34, %ready.overflow.resume695 ], [ 37, %ready.overflow.resume767 ], [ 40, %ready.overflow.resume800 ], [ 43, %ready.overflow.resume931 ], [ 45, %ready.overflow.resume963 ], [ 47, %ready.overflow.resume995 ]
  switch i32 %scheduler.dispatch.pc, label %scheduler.invalid [
    i32 0, label %schedule.0
    i32 1, label %schedule.1
    i32 2, label %schedule.2
    i32 3, label %schedule.3
    i32 4, label %schedule.4
    i32 5, label %schedule.5
    i32 6, label %schedule.6
    i32 7, label %schedule.7
    i32 8, label %schedule.8
    i32 9, label %schedule.9
    i32 10, label %schedule.10
    i32 11, label %schedule.11
    i32 12, label %schedule.12
    i32 13, label %schedule.13
    i32 14, label %schedule.14
    i32 15, label %schedule.15
    i32 16, label %schedule.16
    i32 17, label %schedule.17
    i32 18, label %schedule.18
    i32 19, label %schedule.19
    i32 20, label %schedule.20
    i32 21, label %schedule.21
    i32 22, label %schedule.22
    i32 23, label %schedule.23
    i32 24, label %schedule.24
    i32 25, label %schedule.25
    i32 26, label %schedule.26
    i32 27, label %schedule.27
    i32 28, label %schedule.28
    i32 29, label %schedule.29
    i32 30, label %schedule.30
    i32 31, label %schedule.31
    i32 32, label %schedule.32
    i32 33, label %schedule.33
    i32 34, label %schedule.34
    i32 35, label %schedule.35
    i32 36, label %schedule.36
    i32 37, label %schedule.37
    i32 38, label %schedule.38
    i32 39, label %schedule.39
    i32 40, label %schedule.40
    i32 41, label %schedule.41
    i32 42, label %schedule.42
    i32 43, label %schedule.43
    i32 44, label %schedule.44
    i32 45, label %schedule.45
    i32 46, label %schedule.46
    i32 47, label %schedule.47
  ]

scheduler.done:                                   ; preds = %scheduler.loop
  %83 = load <8 x i1>, ptr %live.mask, align 1
  %84 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %83)
  br i1 %84, label %scheduler.stalled, label %scheduler.exit

scheduler.exit:                                   ; preds = %scheduler.done
  ret void

scheduler.stalled:                                ; preds = %scheduler.done
  call void @llvm.trap()
  unreachable

scheduler.invalid:                                ; preds = %scheduler.dispatch.route
  call void @llvm.trap()
  unreachable

schedule.0:                                       ; preds = %scheduler.dispatch.route
  %85 = load <8 x i1>, ptr %current.mask, align 1
  %86 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %85)
  %87 = bitcast <8 x i1> %85 to i8
  %88 = call i8 @llvm.cttz.i8(i8 %87, i1 false)
  %89 = zext i8 %88 to i32
  %90 = select i1 %86, i32 %89, i32 0
  %91 = extractvalue [3 x <8 x i32>] %50, 0
  %92 = zext <8 x i32> %91 to <8 x i64>
  %93 = select <8 x i1> %85, <8 x i64> %92, <8 x i64> zeroinitializer
  %94 = select <8 x i1> %85, <8 x i64> splat (i64 3), <8 x i64> splat (i64 1)
  %95 = sdiv <8 x i64> %93, %94
  %96 = select <8 x i1> %85, <8 x i64> %92, <8 x i64> zeroinitializer
  %97 = select <8 x i1> %85, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %98 = sdiv <8 x i64> %96, %97
  %99 = select <8 x i1> %85, <8 x i64> %98, <8 x i64> zeroinitializer
  %100 = select <8 x i1> %85, <8 x i64> splat (i64 3), <8 x i64> splat (i64 1)
  %101 = srem <8 x i64> %99, %100
  %102 = mul <8 x i64> %101, splat (i64 2)
  %103 = select <8 x i1> %85, <8 x i64> %95, <8 x i64> zeroinitializer
  %104 = select <8 x i1> %85, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %105 = sdiv <8 x i64> %103, %104
  %106 = load volatile <8 x i64>, ptr %.spill, align 64
  %107 = select <8 x i1> %85, <8 x i64> %105, <8 x i64> %106
  store volatile <8 x i64> %107, ptr %.spill, align 64
  store i64 0, ptr %.spill4, align 4
  store volatile i64 0, ptr %.spill5, align 4
  %108 = add <8 x i64> %95, zeroinitializer
  store volatile i64 0, ptr %.spill6, align 4
  %109 = add <8 x i64> zeroinitializer, %108
  %110 = add <8 x i64> %102, zeroinitializer
  %111 = load volatile <8 x i64>, ptr %.spill7, align 64
  %112 = select <8 x i1> %85, <8 x i64> %110, <8 x i64> %111
  store volatile <8 x i64> %112, ptr %.spill7, align 64
  %113 = mul <8 x i64> %109, splat (i64 5)
  %114 = add <8 x i64> %113, %110
  %115 = load volatile <8 x i64>, ptr %.spill8, align 64
  %116 = select <8 x i1> %85, <8 x i64> %114, <8 x i64> %115
  store volatile <8 x i64> %116, ptr %.spill8, align 64
  %117 = mul <8 x i64> %114, splat (i64 5)
  %118 = add <8 x i64> %117, zeroinitializer
  %119 = extractvalue { ptr, i64 } %9, 0
  %120 = mul <8 x i64> %118, splat (i64 4)
  %121 = getelementptr i8, ptr %119, <8 x i64> %120
  %122 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %121, <8 x i1> %85, <8 x float> zeroinitializer)
  %123 = load volatile <8 x float>, ptr %.spill9, align 32
  %124 = select <8 x i1> %85, <8 x float> %122, <8 x float> %123
  store volatile <8 x float> %124, ptr %.spill9, align 32
  store i64 1, ptr %.spill10, align 4
  %125 = add <8 x i64> %117, splat (i64 1)
  %126 = extractvalue { ptr, i64 } %9, 0
  %127 = mul <8 x i64> %125, splat (i64 4)
  %128 = getelementptr i8, ptr %126, <8 x i64> %127
  %129 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %128, <8 x i1> %85, <8 x float> zeroinitializer)
  %130 = load volatile <8 x float>, ptr %.spill11, align 32
  %131 = select <8 x i1> %85, <8 x float> %129, <8 x float> %130
  store volatile <8 x float> %131, ptr %.spill11, align 32
  store i64 2, ptr %.spill12, align 4
  %132 = add <8 x i64> %117, splat (i64 2)
  %133 = extractvalue { ptr, i64 } %9, 0
  %134 = mul <8 x i64> %132, splat (i64 4)
  %135 = getelementptr i8, ptr %133, <8 x i64> %134
  %136 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %135, <8 x i1> %85, <8 x float> zeroinitializer)
  %137 = load volatile <8 x float>, ptr %.spill13, align 32
  %138 = select <8 x i1> %85, <8 x float> %136, <8 x float> %137
  store volatile <8 x float> %138, ptr %.spill13, align 32
  store volatile i64 3, ptr %.spill14, align 4
  %139 = add <8 x i64> %117, splat (i64 3)
  %140 = extractvalue { ptr, i64 } %9, 0
  %141 = mul <8 x i64> %139, splat (i64 4)
  %142 = getelementptr i8, ptr %140, <8 x i64> %141
  %143 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %142, <8 x i1> %85, <8 x float> zeroinitializer)
  %144 = load volatile <8 x float>, ptr %.spill15, align 32
  %145 = select <8 x i1> %85, <8 x float> %143, <8 x float> %144
  store volatile <8 x float> %145, ptr %.spill15, align 32
  store volatile i64 4, ptr %.spill16, align 4
  %146 = add <8 x i64> %117, splat (i64 4)
  %147 = extractvalue { ptr, i64 } %9, 0
  %148 = mul <8 x i64> %146, splat (i64 4)
  %149 = getelementptr i8, ptr %147, <8 x i64> %148
  %150 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %149, <8 x i1> %85, <8 x float> zeroinitializer)
  %151 = load volatile <8 x float>, ptr %.spill17, align 32
  %152 = select <8 x i1> %85, <8 x float> %150, <8 x float> %151
  store volatile <8 x float> %152, ptr %.spill17, align 32
  %153 = add <8 x i64> %102, splat (i64 1)
  %154 = load volatile <8 x i64>, ptr %.spill18, align 64
  %155 = select <8 x i1> %85, <8 x i64> %153, <8 x i64> %154
  store volatile <8 x i64> %155, ptr %.spill18, align 64
  %156 = add <8 x i64> %113, %153
  %157 = load volatile <8 x i64>, ptr %.spill19, align 64
  %158 = select <8 x i1> %85, <8 x i64> %156, <8 x i64> %157
  store volatile <8 x i64> %158, ptr %.spill19, align 64
  %159 = icmp sge <8 x i64> %153, zeroinitializer
  %160 = and <8 x i1> splat (i1 true), %159
  %161 = icmp slt <8 x i64> %153, splat (i64 5)
  %162 = and <8 x i1> %160, %161
  %163 = load <8 x i1>, ptr %.spill20, align 1
  %164 = select <8 x i1> %85, <8 x i1> %162, <8 x i1> %163
  store <8 x i1> %164, ptr %.spill20, align 1
  %165 = mul <8 x i64> %156, splat (i64 5)
  %166 = load <8 x i64>, ptr %.spill21, align 64
  %167 = select <8 x i1> %85, <8 x i64> %165, <8 x i64> %166
  store <8 x i64> %167, ptr %.spill21, align 64
  %168 = add <8 x i64> %165, zeroinitializer
  %169 = load volatile <8 x i64>, ptr %.spill22, align 64
  %170 = select <8 x i1> %85, <8 x i64> %168, <8 x i64> %169
  store volatile <8 x i64> %170, ptr %.spill22, align 64
  %171 = and <8 x i1> %85, %162
  %172 = xor <8 x i1> %162, splat (i1 true)
  %173 = and <8 x i1> %85, %172
  %174 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %171)
  %175 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %173)
  %176 = and i1 %174, %175
  br i1 %176, label %varying.divergent, label %varying.coherent

schedule.1:                                       ; preds = %varying.coherent.true, %scheduler.dispatch.route
  %177 = load <8 x i1>, ptr %current.mask, align 1
  %178 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %177)
  %179 = bitcast <8 x i1> %177 to i8
  %180 = call i8 @llvm.cttz.i8(i8 %179, i1 false)
  %181 = zext i8 %180 to i32
  %182 = select i1 %178, i32 %181, i32 0
  %.spill.load = load volatile <8 x i64>, ptr %.spill22, align 64
  %183 = extractvalue { ptr, i64 } %9, 0
  %184 = mul <8 x i64> %.spill.load, splat (i64 4)
  %185 = getelementptr i8, ptr %183, <8 x i64> %184
  %186 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %185, <8 x i1> %177, <8 x float> zeroinitializer)
  %187 = load <8 x float>, ptr %.slot, align 32
  %188 = select <8 x i1> %177, <8 x float> %186, <8 x float> %187
  store <8 x float> %188, ptr %.slot, align 32
  store <8 x i1> %177, ptr %current.mask, align 1
  %189 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %177)
  br i1 %189, label %schedule.2, label %scheduler.loop

schedule.2:                                       ; preds = %schedule.1, %varying.coherent.false, %scheduler.dispatch.route
  %190 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token = load i32, ptr %current.token, align 4
  %convergence.token.present = icmp ne i32 %convergence.current.token, 0
  br i1 %convergence.token.present, label %convergence.cascade, label %convergence.cascade.exit

schedule.3:                                       ; preds = %varying.coherent.true153, %scheduler.dispatch.route
  %191 = load <8 x i1>, ptr %current.mask, align 1
  %192 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %191)
  %193 = bitcast <8 x i1> %191 to i8
  %194 = call i8 @llvm.cttz.i8(i8 %193, i1 false)
  %195 = zext i8 %194 to i32
  %196 = select i1 %192, i32 %195, i32 0
  %.spill.load155 = load volatile <8 x i64>, ptr %.spill23, align 64
  %197 = extractvalue { ptr, i64 } %9, 0
  %198 = mul <8 x i64> %.spill.load155, splat (i64 4)
  %199 = getelementptr i8, ptr %197, <8 x i64> %198
  %200 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %199, <8 x i1> %191, <8 x float> zeroinitializer)
  %201 = load <8 x float>, ptr %.slot24, align 32
  %202 = select <8 x i1> %191, <8 x float> %200, <8 x float> %201
  store <8 x float> %202, ptr %.slot24, align 32
  store <8 x i1> %191, ptr %current.mask, align 1
  %203 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %191)
  br i1 %203, label %schedule.4, label %scheduler.loop

schedule.4:                                       ; preds = %schedule.3, %varying.coherent.false154, %scheduler.dispatch.route
  %204 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token158 = load i32, ptr %current.token, align 4
  %convergence.token.present159 = icmp ne i32 %convergence.current.token158, 0
  br i1 %convergence.token.present159, label %convergence.cascade156, label %convergence.cascade.exit157

schedule.5:                                       ; preds = %varying.coherent.true184, %scheduler.dispatch.route
  %205 = load <8 x i1>, ptr %current.mask, align 1
  %206 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %205)
  %207 = bitcast <8 x i1> %205 to i8
  %208 = call i8 @llvm.cttz.i8(i8 %207, i1 false)
  %209 = zext i8 %208 to i32
  %210 = select i1 %206, i32 %209, i32 0
  %.spill.load186 = load volatile <8 x i64>, ptr %.spill25, align 64
  %211 = extractvalue { ptr, i64 } %9, 0
  %212 = mul <8 x i64> %.spill.load186, splat (i64 4)
  %213 = getelementptr i8, ptr %211, <8 x i64> %212
  %214 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %213, <8 x i1> %205, <8 x float> zeroinitializer)
  %215 = load <8 x float>, ptr %.slot26, align 32
  %216 = select <8 x i1> %205, <8 x float> %214, <8 x float> %215
  store <8 x float> %216, ptr %.slot26, align 32
  store <8 x i1> %205, ptr %current.mask, align 1
  %217 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %205)
  br i1 %217, label %schedule.6, label %scheduler.loop

schedule.6:                                       ; preds = %schedule.5, %varying.coherent.false185, %scheduler.dispatch.route
  %218 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token189 = load i32, ptr %current.token, align 4
  %convergence.token.present190 = icmp ne i32 %convergence.current.token189, 0
  br i1 %convergence.token.present190, label %convergence.cascade187, label %convergence.cascade.exit188

schedule.7:                                       ; preds = %varying.coherent.true215, %scheduler.dispatch.route
  %219 = load <8 x i1>, ptr %current.mask, align 1
  %220 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %219)
  %221 = bitcast <8 x i1> %219 to i8
  %222 = call i8 @llvm.cttz.i8(i8 %221, i1 false)
  %223 = zext i8 %222 to i32
  %224 = select i1 %220, i32 %223, i32 0
  %.spill.load217 = load volatile <8 x i64>, ptr %.spill27, align 64
  %225 = extractvalue { ptr, i64 } %9, 0
  %226 = mul <8 x i64> %.spill.load217, splat (i64 4)
  %227 = getelementptr i8, ptr %225, <8 x i64> %226
  %228 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %227, <8 x i1> %219, <8 x float> zeroinitializer)
  %229 = load <8 x float>, ptr %.slot28, align 32
  %230 = select <8 x i1> %219, <8 x float> %228, <8 x float> %229
  store <8 x float> %230, ptr %.slot28, align 32
  store <8 x i1> %219, ptr %current.mask, align 1
  %231 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %219)
  br i1 %231, label %schedule.8, label %scheduler.loop

schedule.8:                                       ; preds = %schedule.7, %varying.coherent.false216, %scheduler.dispatch.route
  %232 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token220 = load i32, ptr %current.token, align 4
  %convergence.token.present221 = icmp ne i32 %convergence.current.token220, 0
  br i1 %convergence.token.present221, label %convergence.cascade218, label %convergence.cascade.exit219

schedule.9:                                       ; preds = %varying.coherent.true246, %scheduler.dispatch.route
  %233 = load <8 x i1>, ptr %current.mask, align 1
  %234 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %233)
  %235 = bitcast <8 x i1> %233 to i8
  %236 = call i8 @llvm.cttz.i8(i8 %235, i1 false)
  %237 = zext i8 %236 to i32
  %238 = select i1 %234, i32 %237, i32 0
  %.spill.load248 = load volatile <8 x i64>, ptr %.spill29, align 64
  %239 = extractvalue { ptr, i64 } %9, 0
  %240 = mul <8 x i64> %.spill.load248, splat (i64 4)
  %241 = getelementptr i8, ptr %239, <8 x i64> %240
  %242 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %241, <8 x i1> %233, <8 x float> zeroinitializer)
  %243 = load <8 x float>, ptr %.slot30, align 32
  %244 = select <8 x i1> %233, <8 x float> %242, <8 x float> %243
  store <8 x float> %244, ptr %.slot30, align 32
  store <8 x i1> %233, ptr %current.mask, align 1
  %245 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %233)
  br i1 %245, label %schedule.10, label %scheduler.loop

schedule.10:                                      ; preds = %schedule.9, %varying.coherent.false247, %scheduler.dispatch.route
  %246 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token251 = load i32, ptr %current.token, align 4
  %convergence.token.present252 = icmp ne i32 %convergence.current.token251, 0
  br i1 %convergence.token.present252, label %convergence.cascade249, label %convergence.cascade.exit250

schedule.11:                                      ; preds = %convergence.target.40.ready, %convergence.target.10.ready, %scheduler.dispatch.route
  %247 = load <8 x i1>, ptr %current.mask, align 1
  %248 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %247)
  %249 = bitcast <8 x i1> %247 to i8
  %250 = call i8 @llvm.cttz.i8(i8 %249, i1 false)
  %251 = zext i8 %250 to i32
  %252 = select i1 %248, i32 %251, i32 0
  %.state = load <8 x i64>, ptr %.slot31, align 64
  %253 = icmp slt <8 x i64> %.state, splat (i64 2)
  %254 = and <8 x i1> %247, %253
  %255 = xor <8 x i1> %253, splat (i1 true)
  %256 = and <8 x i1> %247, %255
  %257 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %254)
  %258 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %256)
  %259 = and i1 %257, %258
  br i1 %259, label %varying.divergent266, label %varying.coherent267

schedule.12:                                      ; preds = %varying.coherent.true272, %scheduler.dispatch.route
  %260 = load <8 x i1>, ptr %current.mask, align 1
  %261 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %260)
  %262 = bitcast <8 x i1> %260 to i8
  %263 = call i8 @llvm.cttz.i8(i8 %262, i1 false)
  %264 = zext i8 %263 to i32
  %265 = select i1 %261, i32 %264, i32 0
  %.state274 = load <8 x i64>, ptr %.slot31, align 64
  %266 = select <8 x i1> %260, <8 x i64> %.state274, <8 x i64> zeroinitializer
  %267 = select <8 x i1> %260, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %268 = sdiv <8 x i64> %266, %267
  %269 = mul <8 x i64> %268, splat (i64 3)
  %.spill.load275 = load volatile <8 x i64>, ptr %.spill, align 64
  %270 = add <8 x i64> %.spill.load275, zeroinitializer
  %.spill.load276 = load volatile i64, ptr %.spill6, align 4
  %.splatinsert277 = insertelement <8 x i64> poison, i64 %.spill.load276, i64 0
  %.splat278 = shufflevector <8 x i64> %.splatinsert277, <8 x i64> poison, <8 x i32> zeroinitializer
  %271 = add <8 x i64> %.splat278, %270
  %272 = add <8 x i64> %269, zeroinitializer
  %273 = load volatile <8 x i64>, ptr %.spill42, align 64
  %274 = select <8 x i1> %260, <8 x i64> %272, <8 x i64> %273
  store volatile <8 x i64> %274, ptr %.spill42, align 64
  %275 = mul <8 x i64> %271, splat (i64 5)
  %276 = add <8 x i64> %275, %272
  %277 = load volatile <8 x i64>, ptr %.spill43, align 64
  %278 = select <8 x i1> %260, <8 x i64> %276, <8 x i64> %277
  store volatile <8 x i64> %278, ptr %.spill43, align 64
  %279 = mul <8 x i64> %276, splat (i64 5)
  %.spill.load279 = load i64, ptr %.spill4, align 4
  %.splatinsert280 = insertelement <8 x i64> poison, i64 %.spill.load279, i64 0
  %.splat281 = shufflevector <8 x i64> %.splatinsert280, <8 x i64> poison, <8 x i32> zeroinitializer
  %280 = add <8 x i64> %279, %.splat281
  %281 = extractvalue { ptr, i64 } %15, 0
  %282 = mul <8 x i64> %280, splat (i64 4)
  %283 = getelementptr i8, ptr %281, <8 x i64> %282
  %284 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %283, <8 x i1> %260, <8 x float> zeroinitializer)
  %285 = load volatile <8 x float>, ptr %.spill44, align 32
  %286 = select <8 x i1> %260, <8 x float> %284, <8 x float> %285
  store volatile <8 x float> %286, ptr %.spill44, align 32
  %.spill.load282 = load i64, ptr %.spill10, align 4
  %.splatinsert283 = insertelement <8 x i64> poison, i64 %.spill.load282, i64 0
  %.splat284 = shufflevector <8 x i64> %.splatinsert283, <8 x i64> poison, <8 x i32> zeroinitializer
  %287 = add <8 x i64> %279, %.splat284
  %288 = extractvalue { ptr, i64 } %15, 0
  %289 = mul <8 x i64> %287, splat (i64 4)
  %290 = getelementptr i8, ptr %288, <8 x i64> %289
  %291 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %290, <8 x i1> %260, <8 x float> zeroinitializer)
  %292 = load volatile <8 x float>, ptr %.spill45, align 32
  %293 = select <8 x i1> %260, <8 x float> %291, <8 x float> %292
  store volatile <8 x float> %293, ptr %.spill45, align 32
  %.spill.load285 = load i64, ptr %.spill12, align 4
  %.splatinsert286 = insertelement <8 x i64> poison, i64 %.spill.load285, i64 0
  %.splat287 = shufflevector <8 x i64> %.splatinsert286, <8 x i64> poison, <8 x i32> zeroinitializer
  %294 = add <8 x i64> %279, %.splat287
  %295 = extractvalue { ptr, i64 } %15, 0
  %296 = mul <8 x i64> %294, splat (i64 4)
  %297 = getelementptr i8, ptr %295, <8 x i64> %296
  %298 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %297, <8 x i1> %260, <8 x float> zeroinitializer)
  %299 = load volatile <8 x float>, ptr %.spill46, align 32
  %300 = select <8 x i1> %260, <8 x float> %298, <8 x float> %299
  store volatile <8 x float> %300, ptr %.spill46, align 32
  %.spill.load288 = load volatile i64, ptr %.spill14, align 4
  %.splatinsert289 = insertelement <8 x i64> poison, i64 %.spill.load288, i64 0
  %.splat290 = shufflevector <8 x i64> %.splatinsert289, <8 x i64> poison, <8 x i32> zeroinitializer
  %301 = add <8 x i64> %279, %.splat290
  %302 = extractvalue { ptr, i64 } %15, 0
  %303 = mul <8 x i64> %301, splat (i64 4)
  %304 = getelementptr i8, ptr %302, <8 x i64> %303
  %305 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %304, <8 x i1> %260, <8 x float> zeroinitializer)
  %306 = load volatile <8 x float>, ptr %.spill47, align 32
  %307 = select <8 x i1> %260, <8 x float> %305, <8 x float> %306
  store volatile <8 x float> %307, ptr %.spill47, align 32
  %.spill.load291 = load volatile i64, ptr %.spill16, align 4
  %.splatinsert292 = insertelement <8 x i64> poison, i64 %.spill.load291, i64 0
  %.splat293 = shufflevector <8 x i64> %.splatinsert292, <8 x i64> poison, <8 x i32> zeroinitializer
  %308 = add <8 x i64> %279, %.splat293
  %309 = extractvalue { ptr, i64 } %15, 0
  %310 = mul <8 x i64> %308, splat (i64 4)
  %311 = getelementptr i8, ptr %309, <8 x i64> %310
  %312 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %311, <8 x i1> %260, <8 x float> zeroinitializer)
  %313 = load volatile <8 x float>, ptr %.spill48, align 32
  %314 = select <8 x i1> %260, <8 x float> %312, <8 x float> %313
  store volatile <8 x float> %314, ptr %.spill48, align 32
  %315 = add <8 x i64> %269, splat (i64 1)
  %316 = load volatile <8 x i64>, ptr %.spill49, align 64
  %317 = select <8 x i1> %260, <8 x i64> %315, <8 x i64> %316
  store volatile <8 x i64> %317, ptr %.spill49, align 64
  %318 = add <8 x i64> %275, %315
  %319 = load volatile <8 x i64>, ptr %.spill50, align 64
  %320 = select <8 x i1> %260, <8 x i64> %318, <8 x i64> %319
  store volatile <8 x i64> %320, ptr %.spill50, align 64
  %321 = mul <8 x i64> %318, splat (i64 5)
  %.spill.load294 = load i64, ptr %.spill4, align 4
  %.splatinsert295 = insertelement <8 x i64> poison, i64 %.spill.load294, i64 0
  %.splat296 = shufflevector <8 x i64> %.splatinsert295, <8 x i64> poison, <8 x i32> zeroinitializer
  %322 = add <8 x i64> %321, %.splat296
  %323 = extractvalue { ptr, i64 } %15, 0
  %324 = mul <8 x i64> %322, splat (i64 4)
  %325 = getelementptr i8, ptr %323, <8 x i64> %324
  %326 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %325, <8 x i1> %260, <8 x float> zeroinitializer)
  %327 = load volatile <8 x float>, ptr %.spill51, align 32
  %328 = select <8 x i1> %260, <8 x float> %326, <8 x float> %327
  store volatile <8 x float> %328, ptr %.spill51, align 32
  %.spill.load297 = load i64, ptr %.spill10, align 4
  %.splatinsert298 = insertelement <8 x i64> poison, i64 %.spill.load297, i64 0
  %.splat299 = shufflevector <8 x i64> %.splatinsert298, <8 x i64> poison, <8 x i32> zeroinitializer
  %329 = add <8 x i64> %321, %.splat299
  %330 = extractvalue { ptr, i64 } %15, 0
  %331 = mul <8 x i64> %329, splat (i64 4)
  %332 = getelementptr i8, ptr %330, <8 x i64> %331
  %333 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %332, <8 x i1> %260, <8 x float> zeroinitializer)
  %334 = load volatile <8 x float>, ptr %.spill52, align 32
  %335 = select <8 x i1> %260, <8 x float> %333, <8 x float> %334
  store volatile <8 x float> %335, ptr %.spill52, align 32
  %.spill.load300 = load i64, ptr %.spill12, align 4
  %.splatinsert301 = insertelement <8 x i64> poison, i64 %.spill.load300, i64 0
  %.splat302 = shufflevector <8 x i64> %.splatinsert301, <8 x i64> poison, <8 x i32> zeroinitializer
  %336 = add <8 x i64> %321, %.splat302
  %337 = extractvalue { ptr, i64 } %15, 0
  %338 = mul <8 x i64> %336, splat (i64 4)
  %339 = getelementptr i8, ptr %337, <8 x i64> %338
  %340 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %339, <8 x i1> %260, <8 x float> zeroinitializer)
  %341 = load volatile <8 x float>, ptr %.spill53, align 32
  %342 = select <8 x i1> %260, <8 x float> %340, <8 x float> %341
  store volatile <8 x float> %342, ptr %.spill53, align 32
  %.spill.load303 = load volatile i64, ptr %.spill14, align 4
  %.splatinsert304 = insertelement <8 x i64> poison, i64 %.spill.load303, i64 0
  %.splat305 = shufflevector <8 x i64> %.splatinsert304, <8 x i64> poison, <8 x i32> zeroinitializer
  %343 = add <8 x i64> %321, %.splat305
  %344 = extractvalue { ptr, i64 } %15, 0
  %345 = mul <8 x i64> %343, splat (i64 4)
  %346 = getelementptr i8, ptr %344, <8 x i64> %345
  %347 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %346, <8 x i1> %260, <8 x float> zeroinitializer)
  %348 = load volatile <8 x float>, ptr %.spill54, align 32
  %349 = select <8 x i1> %260, <8 x float> %347, <8 x float> %348
  store volatile <8 x float> %349, ptr %.spill54, align 32
  %.spill.load306 = load volatile i64, ptr %.spill16, align 4
  %.splatinsert307 = insertelement <8 x i64> poison, i64 %.spill.load306, i64 0
  %.splat308 = shufflevector <8 x i64> %.splatinsert307, <8 x i64> poison, <8 x i32> zeroinitializer
  %350 = add <8 x i64> %321, %.splat308
  %351 = extractvalue { ptr, i64 } %15, 0
  %352 = mul <8 x i64> %350, splat (i64 4)
  %353 = getelementptr i8, ptr %351, <8 x i64> %352
  %354 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %353, <8 x i1> %260, <8 x float> zeroinitializer)
  %355 = load volatile <8 x float>, ptr %.spill55, align 32
  %356 = select <8 x i1> %260, <8 x float> %354, <8 x float> %355
  store volatile <8 x float> %356, ptr %.spill55, align 32
  %357 = add <8 x i64> %269, splat (i64 2)
  %358 = load volatile <8 x i64>, ptr %.spill56, align 64
  %359 = select <8 x i1> %260, <8 x i64> %357, <8 x i64> %358
  store volatile <8 x i64> %359, ptr %.spill56, align 64
  %360 = add <8 x i64> %275, %357
  %361 = load volatile <8 x i64>, ptr %.spill57, align 64
  %362 = select <8 x i1> %260, <8 x i64> %360, <8 x i64> %361
  store volatile <8 x i64> %362, ptr %.spill57, align 64
  %363 = icmp sge <8 x i64> %357, zeroinitializer
  %364 = and <8 x i1> splat (i1 true), %363
  %365 = icmp slt <8 x i64> %357, splat (i64 5)
  %366 = load volatile <8 x i1>, ptr %.spill58, align 1
  %367 = select <8 x i1> %260, <8 x i1> %365, <8 x i1> %366
  store volatile <8 x i1> %367, ptr %.spill58, align 1
  %368 = and <8 x i1> %364, %365
  %369 = load <8 x i1>, ptr %.spill59, align 1
  %370 = select <8 x i1> %260, <8 x i1> %368, <8 x i1> %369
  store <8 x i1> %370, ptr %.spill59, align 1
  %371 = mul <8 x i64> %360, splat (i64 5)
  %372 = load <8 x i64>, ptr %.spill60, align 64
  %373 = select <8 x i1> %260, <8 x i64> %371, <8 x i64> %372
  store <8 x i64> %373, ptr %.spill60, align 64
  %.spill.load309 = load i64, ptr %.spill4, align 4
  %.splatinsert310 = insertelement <8 x i64> poison, i64 %.spill.load309, i64 0
  %.splat311 = shufflevector <8 x i64> %.splatinsert310, <8 x i64> poison, <8 x i32> zeroinitializer
  %374 = add <8 x i64> %371, %.splat311
  %375 = load volatile <8 x i64>, ptr %.spill61, align 64
  %376 = select <8 x i1> %260, <8 x i64> %374, <8 x i64> %375
  store volatile <8 x i64> %376, ptr %.spill61, align 64
  %377 = and <8 x i1> %260, %368
  %378 = xor <8 x i1> %368, splat (i1 true)
  %379 = and <8 x i1> %260, %378
  %380 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %377)
  %381 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %379)
  %382 = and i1 %380, %381
  br i1 %382, label %varying.divergent312, label %varying.coherent313

schedule.13:                                      ; preds = %varying.coherent.true318, %scheduler.dispatch.route
  %383 = load <8 x i1>, ptr %current.mask, align 1
  %384 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %383)
  %385 = bitcast <8 x i1> %383 to i8
  %386 = call i8 @llvm.cttz.i8(i8 %385, i1 false)
  %387 = zext i8 %386 to i32
  %388 = select i1 %384, i32 %387, i32 0
  %.spill.load320 = load volatile <8 x i64>, ptr %.spill61, align 64
  %389 = extractvalue { ptr, i64 } %15, 0
  %390 = mul <8 x i64> %.spill.load320, splat (i64 4)
  %391 = getelementptr i8, ptr %389, <8 x i64> %390
  %392 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %391, <8 x i1> %383, <8 x float> zeroinitializer)
  %393 = load <8 x float>, ptr %.slot62, align 32
  %394 = select <8 x i1> %383, <8 x float> %392, <8 x float> %393
  store <8 x float> %394, ptr %.slot62, align 32
  store <8 x i1> %383, ptr %current.mask, align 1
  %395 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %383)
  br i1 %395, label %schedule.14, label %scheduler.loop

schedule.14:                                      ; preds = %schedule.13, %varying.coherent.false319, %scheduler.dispatch.route
  %396 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token323 = load i32, ptr %current.token, align 4
  %convergence.token.present324 = icmp ne i32 %convergence.current.token323, 0
  br i1 %convergence.token.present324, label %convergence.cascade321, label %convergence.cascade.exit322

schedule.15:                                      ; preds = %varying.coherent.true349, %scheduler.dispatch.route
  %397 = load <8 x i1>, ptr %current.mask, align 1
  %398 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %397)
  %399 = bitcast <8 x i1> %397 to i8
  %400 = call i8 @llvm.cttz.i8(i8 %399, i1 false)
  %401 = zext i8 %400 to i32
  %402 = select i1 %398, i32 %401, i32 0
  %.spill.load351 = load volatile <8 x i64>, ptr %.spill63, align 64
  %403 = extractvalue { ptr, i64 } %15, 0
  %404 = mul <8 x i64> %.spill.load351, splat (i64 4)
  %405 = getelementptr i8, ptr %403, <8 x i64> %404
  %406 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %405, <8 x i1> %397, <8 x float> zeroinitializer)
  %407 = load <8 x float>, ptr %.slot64, align 32
  %408 = select <8 x i1> %397, <8 x float> %406, <8 x float> %407
  store <8 x float> %408, ptr %.slot64, align 32
  store <8 x i1> %397, ptr %current.mask, align 1
  %409 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %397)
  br i1 %409, label %schedule.16, label %scheduler.loop

schedule.16:                                      ; preds = %schedule.15, %varying.coherent.false350, %scheduler.dispatch.route
  %410 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token354 = load i32, ptr %current.token, align 4
  %convergence.token.present355 = icmp ne i32 %convergence.current.token354, 0
  br i1 %convergence.token.present355, label %convergence.cascade352, label %convergence.cascade.exit353

schedule.17:                                      ; preds = %varying.coherent.true380, %scheduler.dispatch.route
  %411 = load <8 x i1>, ptr %current.mask, align 1
  %412 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %411)
  %413 = bitcast <8 x i1> %411 to i8
  %414 = call i8 @llvm.cttz.i8(i8 %413, i1 false)
  %415 = zext i8 %414 to i32
  %416 = select i1 %412, i32 %415, i32 0
  %.spill.load382 = load volatile <8 x i64>, ptr %.spill65, align 64
  %417 = extractvalue { ptr, i64 } %15, 0
  %418 = mul <8 x i64> %.spill.load382, splat (i64 4)
  %419 = getelementptr i8, ptr %417, <8 x i64> %418
  %420 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %419, <8 x i1> %411, <8 x float> zeroinitializer)
  %421 = load <8 x float>, ptr %.slot66, align 32
  %422 = select <8 x i1> %411, <8 x float> %420, <8 x float> %421
  store <8 x float> %422, ptr %.slot66, align 32
  store <8 x i1> %411, ptr %current.mask, align 1
  %423 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %411)
  br i1 %423, label %schedule.18, label %scheduler.loop

schedule.18:                                      ; preds = %schedule.17, %varying.coherent.false381, %scheduler.dispatch.route
  %424 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token385 = load i32, ptr %current.token, align 4
  %convergence.token.present386 = icmp ne i32 %convergence.current.token385, 0
  br i1 %convergence.token.present386, label %convergence.cascade383, label %convergence.cascade.exit384

schedule.19:                                      ; preds = %varying.coherent.true411, %scheduler.dispatch.route
  %425 = load <8 x i1>, ptr %current.mask, align 1
  %426 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %425)
  %427 = bitcast <8 x i1> %425 to i8
  %428 = call i8 @llvm.cttz.i8(i8 %427, i1 false)
  %429 = zext i8 %428 to i32
  %430 = select i1 %426, i32 %429, i32 0
  %.spill.load413 = load volatile <8 x i64>, ptr %.spill67, align 64
  %431 = extractvalue { ptr, i64 } %15, 0
  %432 = mul <8 x i64> %.spill.load413, splat (i64 4)
  %433 = getelementptr i8, ptr %431, <8 x i64> %432
  %434 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %433, <8 x i1> %425, <8 x float> zeroinitializer)
  %435 = load <8 x float>, ptr %.slot68, align 32
  %436 = select <8 x i1> %425, <8 x float> %434, <8 x float> %435
  store <8 x float> %436, ptr %.slot68, align 32
  store <8 x i1> %425, ptr %current.mask, align 1
  %437 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %425)
  br i1 %437, label %schedule.20, label %scheduler.loop

schedule.20:                                      ; preds = %schedule.19, %varying.coherent.false412, %scheduler.dispatch.route
  %438 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token416 = load i32, ptr %current.token, align 4
  %convergence.token.present417 = icmp ne i32 %convergence.current.token416, 0
  br i1 %convergence.token.present417, label %convergence.cascade414, label %convergence.cascade.exit415

schedule.21:                                      ; preds = %varying.coherent.true442, %scheduler.dispatch.route
  %439 = load <8 x i1>, ptr %current.mask, align 1
  %440 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %439)
  %441 = bitcast <8 x i1> %439 to i8
  %442 = call i8 @llvm.cttz.i8(i8 %441, i1 false)
  %443 = zext i8 %442 to i32
  %444 = select i1 %440, i32 %443, i32 0
  %.spill.load444 = load volatile <8 x i64>, ptr %.spill69, align 64
  %445 = extractvalue { ptr, i64 } %15, 0
  %446 = mul <8 x i64> %.spill.load444, splat (i64 4)
  %447 = getelementptr i8, ptr %445, <8 x i64> %446
  %448 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %447, <8 x i1> %439, <8 x float> zeroinitializer)
  %449 = load <8 x float>, ptr %.slot70, align 32
  %450 = select <8 x i1> %439, <8 x float> %448, <8 x float> %449
  store <8 x float> %450, ptr %.slot70, align 32
  store <8 x i1> %439, ptr %current.mask, align 1
  %451 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %439)
  br i1 %451, label %schedule.22, label %scheduler.loop

schedule.22:                                      ; preds = %schedule.21, %varying.coherent.false443, %scheduler.dispatch.route
  %452 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token447 = load i32, ptr %current.token, align 4
  %convergence.token.present448 = icmp ne i32 %convergence.current.token447, 0
  br i1 %convergence.token.present448, label %convergence.cascade445, label %convergence.cascade.exit446

schedule.23:                                      ; preds = %varying.coherent.true493, %scheduler.dispatch.route
  %453 = load <8 x i1>, ptr %current.mask, align 1
  %454 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %453)
  %455 = bitcast <8 x i1> %453 to i8
  %456 = call i8 @llvm.cttz.i8(i8 %455, i1 false)
  %457 = zext i8 %456 to i32
  %458 = select i1 %454, i32 %457, i32 0
  %.spill.load495 = load volatile <8 x i64>, ptr %.spill78, align 64
  %459 = extractvalue { ptr, i64 } %21, 0
  %460 = mul <8 x i64> %.spill.load495, splat (i64 4)
  %461 = getelementptr i8, ptr %459, <8 x i64> %460
  %462 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %461, <8 x i1> %453, <8 x float> zeroinitializer)
  %463 = load <8 x float>, ptr %.slot79, align 32
  %464 = select <8 x i1> %453, <8 x float> %462, <8 x float> %463
  store <8 x float> %464, ptr %.slot79, align 32
  store <8 x i1> %453, ptr %current.mask, align 1
  %465 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %453)
  br i1 %465, label %schedule.24, label %scheduler.loop

schedule.24:                                      ; preds = %schedule.23, %varying.coherent.false494, %scheduler.dispatch.route
  %466 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token498 = load i32, ptr %current.token, align 4
  %convergence.token.present499 = icmp ne i32 %convergence.current.token498, 0
  br i1 %convergence.token.present499, label %convergence.cascade496, label %convergence.cascade.exit497

schedule.25:                                      ; preds = %varying.coherent.true524, %scheduler.dispatch.route
  %467 = load <8 x i1>, ptr %current.mask, align 1
  %468 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %467)
  %469 = bitcast <8 x i1> %467 to i8
  %470 = call i8 @llvm.cttz.i8(i8 %469, i1 false)
  %471 = zext i8 %470 to i32
  %472 = select i1 %468, i32 %471, i32 0
  %.spill.load526 = load volatile <8 x i64>, ptr %.spill80, align 64
  %473 = extractvalue { ptr, i64 } %21, 0
  %474 = mul <8 x i64> %.spill.load526, splat (i64 4)
  %475 = getelementptr i8, ptr %473, <8 x i64> %474
  %476 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %475, <8 x i1> %467, <8 x float> zeroinitializer)
  %477 = load <8 x float>, ptr %.slot81, align 32
  %478 = select <8 x i1> %467, <8 x float> %476, <8 x float> %477
  store <8 x float> %478, ptr %.slot81, align 32
  store <8 x i1> %467, ptr %current.mask, align 1
  %479 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %467)
  br i1 %479, label %schedule.26, label %scheduler.loop

schedule.26:                                      ; preds = %schedule.25, %varying.coherent.false525, %scheduler.dispatch.route
  %480 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token529 = load i32, ptr %current.token, align 4
  %convergence.token.present530 = icmp ne i32 %convergence.current.token529, 0
  br i1 %convergence.token.present530, label %convergence.cascade527, label %convergence.cascade.exit528

schedule.27:                                      ; preds = %varying.coherent.true555, %scheduler.dispatch.route
  %481 = load <8 x i1>, ptr %current.mask, align 1
  %482 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %481)
  %483 = bitcast <8 x i1> %481 to i8
  %484 = call i8 @llvm.cttz.i8(i8 %483, i1 false)
  %485 = zext i8 %484 to i32
  %486 = select i1 %482, i32 %485, i32 0
  %.spill.load557 = load volatile <8 x i64>, ptr %.spill82, align 64
  %487 = extractvalue { ptr, i64 } %21, 0
  %488 = mul <8 x i64> %.spill.load557, splat (i64 4)
  %489 = getelementptr i8, ptr %487, <8 x i64> %488
  %490 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %489, <8 x i1> %481, <8 x float> zeroinitializer)
  %491 = load <8 x float>, ptr %.slot83, align 32
  %492 = select <8 x i1> %481, <8 x float> %490, <8 x float> %491
  store <8 x float> %492, ptr %.slot83, align 32
  store <8 x i1> %481, ptr %current.mask, align 1
  %493 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %481)
  br i1 %493, label %schedule.28, label %scheduler.loop

schedule.28:                                      ; preds = %schedule.27, %varying.coherent.false556, %scheduler.dispatch.route
  %494 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token560 = load i32, ptr %current.token, align 4
  %convergence.token.present561 = icmp ne i32 %convergence.current.token560, 0
  br i1 %convergence.token.present561, label %convergence.cascade558, label %convergence.cascade.exit559

schedule.29:                                      ; preds = %schedule.30, %convergence.target.28.ready, %scheduler.dispatch.route
  %495 = load <8 x i1>, ptr %current.mask, align 1
  %496 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %495)
  %497 = bitcast <8 x i1> %495 to i8
  %498 = call i8 @llvm.cttz.i8(i8 %497, i1 false)
  %499 = zext i8 %498 to i32
  %500 = select i1 %496, i32 %499, i32 0
  %.state657 = load <8 x i64>, ptr %.slot96, align 64
  %501 = icmp slt <8 x i64> %.state657, splat (i64 3)
  %502 = and <8 x i1> %495, %501
  %503 = xor <8 x i1> %501, splat (i1 true)
  %504 = and <8 x i1> %495, %503
  %505 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %502)
  %506 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %504)
  %507 = and i1 %505, %506
  br i1 %507, label %varying.divergent658, label %varying.coherent659

schedule.30:                                      ; preds = %varying.coherent.true664, %scheduler.dispatch.route
  %508 = load <8 x i1>, ptr %current.mask, align 1
  %509 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %508)
  %510 = bitcast <8 x i1> %508 to i8
  %511 = call i8 @llvm.cttz.i8(i8 %510, i1 false)
  %512 = zext i8 %511 to i32
  %513 = select i1 %509, i32 %512, i32 0
  %.state666 = load <8 x i64>, ptr %.slot96, align 64
  %514 = select <8 x i1> %508, <8 x i64> %.state666, <8 x i64> zeroinitializer
  %515 = select <8 x i1> %508, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %516 = sdiv <8 x i64> %514, %515
  %.spill.load667 = load volatile i64, ptr %.spill5, align 4
  %517 = add i64 %.spill.load667, 0
  %518 = mul i64 %517, 1
  %519 = add i64 %518, 0
  %520 = mul i64 %519, 2
  %521 = add i64 %520, 0
  %522 = mul i64 %521, 3
  %.splatinsert668 = insertelement <8 x i64> poison, i64 %522, i64 0
  %.splat669 = shufflevector <8 x i64> %.splatinsert668, <8 x i64> poison, <8 x i32> zeroinitializer
  %523 = add <8 x i64> %.splat669, %516
  %tile_snapshot.spill.load = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %524 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %525 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %526 = mul <8 x i64> %523, splat (i64 32)
  %527 = add <8 x i64> %525, %526
  %528 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %524, 0
  %529 = insertvalue { <8 x ptr>, <8 x i64> } %528, <8 x i64> %527, 1
  %530 = extractvalue { <8 x ptr>, <8 x i64> } %529, 0
  %531 = extractvalue { <8 x ptr>, <8 x i64> } %529, 1
  %532 = getelementptr i8, <8 x ptr> %530, <8 x i64> %531
  %533 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %532, <8 x i1> %508, <8 x float> zeroinitializer)
  %.state670 = load <8 x float>, ptr %.slot97, align 32
  %534 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state670, <8 x float> %533)
  %.state671 = load <8 x i64>, ptr %.slot96, align 64
  %535 = add <8 x i64> %.state671, splat (i64 1)
  %536 = load <8 x i64>, ptr %.slot96, align 64
  %537 = select <8 x i1> %508, <8 x i64> %535, <8 x i64> %536
  store <8 x i64> %537, ptr %.slot96, align 64
  %538 = load <8 x float>, ptr %.slot97, align 32
  %539 = select <8 x i1> %508, <8 x float> %534, <8 x float> %538
  store <8 x float> %539, ptr %.slot97, align 32
  store <8 x i1> %508, ptr %current.mask, align 1
  %540 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %508)
  br i1 %540, label %schedule.29, label %scheduler.loop

schedule.31:                                      ; preds = %varying.coherent.false665, %scheduler.dispatch.route
  %541 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token674 = load i32, ptr %current.token, align 4
  %convergence.token.present675 = icmp ne i32 %convergence.current.token674, 0
  br i1 %convergence.token.present675, label %convergence.cascade672, label %convergence.cascade.exit673

schedule.32:                                      ; preds = %schedule.33, %convergence.target.31.ready, %scheduler.dispatch.route
  %542 = load <8 x i1>, ptr %current.mask, align 1
  %543 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %542)
  %544 = bitcast <8 x i1> %542 to i8
  %545 = call i8 @llvm.cttz.i8(i8 %544, i1 false)
  %546 = zext i8 %545 to i32
  %547 = select i1 %543, i32 %546, i32 0
  %.state689 = load <8 x i64>, ptr %.slot98, align 64
  %548 = icmp slt <8 x i64> %.state689, splat (i64 3)
  %549 = and <8 x i1> %542, %548
  %550 = xor <8 x i1> %548, splat (i1 true)
  %551 = and <8 x i1> %542, %550
  %552 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %549)
  %553 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %551)
  %554 = and i1 %552, %553
  br i1 %554, label %varying.divergent690, label %varying.coherent691

schedule.33:                                      ; preds = %varying.coherent.true696, %scheduler.dispatch.route
  %555 = load <8 x i1>, ptr %current.mask, align 1
  %556 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %555)
  %557 = bitcast <8 x i1> %555 to i8
  %558 = call i8 @llvm.cttz.i8(i8 %557, i1 false)
  %559 = zext i8 %558 to i32
  %560 = select i1 %556, i32 %559, i32 0
  %.state698 = load <8 x i64>, ptr %.slot98, align 64
  %561 = select <8 x i1> %555, <8 x i64> %.state698, <8 x i64> zeroinitializer
  %562 = select <8 x i1> %555, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %563 = sdiv <8 x i64> %561, %562
  %.spill.load699 = load volatile i64, ptr %.spill5, align 4
  %564 = add i64 %.spill.load699, 0
  %565 = mul i64 %564, 1
  %566 = add i64 %565, 0
  %567 = mul i64 %566, 2
  %568 = add i64 %567, 1
  %569 = mul i64 %568, 3
  %.splatinsert700 = insertelement <8 x i64> poison, i64 %569, i64 0
  %.splat701 = shufflevector <8 x i64> %.splatinsert700, <8 x i64> poison, <8 x i32> zeroinitializer
  %570 = add <8 x i64> %.splat701, %563
  %tile_snapshot.spill.load702 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %571 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load702, 0
  %572 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load702, 1
  %573 = mul <8 x i64> %570, splat (i64 32)
  %574 = add <8 x i64> %572, %573
  %575 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %571, 0
  %576 = insertvalue { <8 x ptr>, <8 x i64> } %575, <8 x i64> %574, 1
  %577 = extractvalue { <8 x ptr>, <8 x i64> } %576, 0
  %578 = extractvalue { <8 x ptr>, <8 x i64> } %576, 1
  %579 = getelementptr i8, <8 x ptr> %577, <8 x i64> %578
  %580 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %579, <8 x i1> %555, <8 x float> zeroinitializer)
  %.state703 = load <8 x float>, ptr %.slot99, align 32
  %581 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state703, <8 x float> %580)
  %.state704 = load <8 x i64>, ptr %.slot98, align 64
  %582 = add <8 x i64> %.state704, splat (i64 1)
  %583 = load <8 x i64>, ptr %.slot98, align 64
  %584 = select <8 x i1> %555, <8 x i64> %582, <8 x i64> %583
  store <8 x i64> %584, ptr %.slot98, align 64
  %585 = load <8 x float>, ptr %.slot99, align 32
  %586 = select <8 x i1> %555, <8 x float> %581, <8 x float> %585
  store <8 x float> %586, ptr %.slot99, align 32
  store <8 x i1> %555, ptr %current.mask, align 1
  %587 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %555)
  br i1 %587, label %schedule.32, label %scheduler.loop

schedule.34:                                      ; preds = %varying.coherent.false697, %scheduler.dispatch.route
  %588 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token707 = load i32, ptr %current.token, align 4
  %convergence.token.present708 = icmp ne i32 %convergence.current.token707, 0
  br i1 %convergence.token.present708, label %convergence.cascade705, label %convergence.cascade.exit706

schedule.35:                                      ; preds = %schedule.36, %convergence.target.34.ready, %scheduler.dispatch.route
  %589 = load <8 x i1>, ptr %current.mask, align 1
  %590 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %589)
  %591 = bitcast <8 x i1> %589 to i8
  %592 = call i8 @llvm.cttz.i8(i8 %591, i1 false)
  %593 = zext i8 %592 to i32
  %594 = select i1 %590, i32 %593, i32 0
  %.state761 = load <8 x i64>, ptr %.slot113, align 64
  %595 = icmp slt <8 x i64> %.state761, splat (i64 3)
  %596 = and <8 x i1> %589, %595
  %597 = xor <8 x i1> %595, splat (i1 true)
  %598 = and <8 x i1> %589, %597
  %599 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %596)
  %600 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %598)
  %601 = and i1 %599, %600
  br i1 %601, label %varying.divergent762, label %varying.coherent763

schedule.36:                                      ; preds = %varying.coherent.true768, %scheduler.dispatch.route
  %602 = load <8 x i1>, ptr %current.mask, align 1
  %603 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %602)
  %604 = bitcast <8 x i1> %602 to i8
  %605 = call i8 @llvm.cttz.i8(i8 %604, i1 false)
  %606 = zext i8 %605 to i32
  %607 = select i1 %603, i32 %606, i32 0
  %.state770 = load <8 x i64>, ptr %.slot113, align 64
  %608 = select <8 x i1> %602, <8 x i64> %.state770, <8 x i64> zeroinitializer
  %609 = select <8 x i1> %602, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %610 = sdiv <8 x i64> %608, %609
  %.spill.load771 = load volatile i64, ptr %.spill5, align 4
  %611 = add i64 %.spill.load771, 0
  %612 = mul i64 %611, 1
  %613 = add i64 %612, 0
  %614 = mul i64 %613, 2
  %615 = add i64 %614, 0
  %616 = mul i64 %615, 3
  %.splatinsert772 = insertelement <8 x i64> poison, i64 %616, i64 0
  %.splat773 = shufflevector <8 x i64> %.splatinsert772, <8 x i64> poison, <8 x i32> zeroinitializer
  %617 = add <8 x i64> %.splat773, %610
  %tile_snapshot.spill.load774 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill110, align 64
  %618 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load774, 0
  %619 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load774, 1
  %620 = mul <8 x i64> %617, splat (i64 32)
  %621 = add <8 x i64> %619, %620
  %622 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %618, 0
  %623 = insertvalue { <8 x ptr>, <8 x i64> } %622, <8 x i64> %621, 1
  %624 = extractvalue { <8 x ptr>, <8 x i64> } %623, 0
  %625 = extractvalue { <8 x ptr>, <8 x i64> } %623, 1
  %626 = getelementptr i8, <8 x ptr> %624, <8 x i64> %625
  %627 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %626, <8 x i1> %602, <8 x float> zeroinitializer)
  %.state775 = load <8 x float>, ptr %.slot114, align 32
  %628 = fadd <8 x float> %.state775, %627
  %.state776 = load <8 x i64>, ptr %.slot113, align 64
  %629 = add <8 x i64> %.state776, splat (i64 1)
  %630 = load <8 x i64>, ptr %.slot113, align 64
  %631 = select <8 x i1> %602, <8 x i64> %629, <8 x i64> %630
  store <8 x i64> %631, ptr %.slot113, align 64
  %632 = load <8 x float>, ptr %.slot114, align 32
  %633 = select <8 x i1> %602, <8 x float> %628, <8 x float> %632
  store <8 x float> %633, ptr %.slot114, align 32
  store <8 x i1> %602, ptr %current.mask, align 1
  %634 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %602)
  br i1 %634, label %schedule.35, label %scheduler.loop

schedule.37:                                      ; preds = %varying.coherent.false769, %scheduler.dispatch.route
  %635 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token779 = load i32, ptr %current.token, align 4
  %convergence.token.present780 = icmp ne i32 %convergence.current.token779, 0
  br i1 %convergence.token.present780, label %convergence.cascade777, label %convergence.cascade.exit778

schedule.38:                                      ; preds = %schedule.39, %convergence.target.37.ready, %scheduler.dispatch.route
  %636 = load <8 x i1>, ptr %current.mask, align 1
  %637 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %636)
  %638 = bitcast <8 x i1> %636 to i8
  %639 = call i8 @llvm.cttz.i8(i8 %638, i1 false)
  %640 = zext i8 %639 to i32
  %641 = select i1 %637, i32 %640, i32 0
  %.state794 = load <8 x i64>, ptr %.slot115, align 64
  %642 = icmp slt <8 x i64> %.state794, splat (i64 3)
  %643 = and <8 x i1> %636, %642
  %644 = xor <8 x i1> %642, splat (i1 true)
  %645 = and <8 x i1> %636, %644
  %646 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %643)
  %647 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %645)
  %648 = and i1 %646, %647
  br i1 %648, label %varying.divergent795, label %varying.coherent796

schedule.39:                                      ; preds = %varying.coherent.true801, %scheduler.dispatch.route
  %649 = load <8 x i1>, ptr %current.mask, align 1
  %650 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %649)
  %651 = bitcast <8 x i1> %649 to i8
  %652 = call i8 @llvm.cttz.i8(i8 %651, i1 false)
  %653 = zext i8 %652 to i32
  %654 = select i1 %650, i32 %653, i32 0
  %.state803 = load <8 x i64>, ptr %.slot115, align 64
  %655 = select <8 x i1> %649, <8 x i64> %.state803, <8 x i64> zeroinitializer
  %656 = select <8 x i1> %649, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %657 = sdiv <8 x i64> %655, %656
  %.spill.load804 = load volatile i64, ptr %.spill5, align 4
  %658 = add i64 %.spill.load804, 0
  %659 = mul i64 %658, 1
  %660 = add i64 %659, 0
  %661 = mul i64 %660, 2
  %662 = add i64 %661, 1
  %663 = mul i64 %662, 3
  %.splatinsert805 = insertelement <8 x i64> poison, i64 %663, i64 0
  %.splat806 = shufflevector <8 x i64> %.splatinsert805, <8 x i64> poison, <8 x i32> zeroinitializer
  %664 = add <8 x i64> %.splat806, %657
  %tile_snapshot.spill.load807 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill110, align 64
  %665 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load807, 0
  %666 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load807, 1
  %667 = mul <8 x i64> %664, splat (i64 32)
  %668 = add <8 x i64> %666, %667
  %669 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %665, 0
  %670 = insertvalue { <8 x ptr>, <8 x i64> } %669, <8 x i64> %668, 1
  %671 = extractvalue { <8 x ptr>, <8 x i64> } %670, 0
  %672 = extractvalue { <8 x ptr>, <8 x i64> } %670, 1
  %673 = getelementptr i8, <8 x ptr> %671, <8 x i64> %672
  %674 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %673, <8 x i1> %649, <8 x float> zeroinitializer)
  %.state808 = load <8 x float>, ptr %.slot116, align 32
  %675 = fadd <8 x float> %.state808, %674
  %.state809 = load <8 x i64>, ptr %.slot115, align 64
  %676 = add <8 x i64> %.state809, splat (i64 1)
  %677 = load <8 x i64>, ptr %.slot115, align 64
  %678 = select <8 x i1> %649, <8 x i64> %676, <8 x i64> %677
  store <8 x i64> %678, ptr %.slot115, align 64
  %679 = load <8 x float>, ptr %.slot116, align 32
  %680 = select <8 x i1> %649, <8 x float> %675, <8 x float> %679
  store <8 x float> %680, ptr %.slot116, align 32
  store <8 x i1> %649, ptr %current.mask, align 1
  %681 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %649)
  br i1 %681, label %schedule.38, label %scheduler.loop

schedule.40:                                      ; preds = %varying.coherent.false802, %scheduler.dispatch.route
  %682 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token812 = load i32, ptr %current.token, align 4
  %convergence.token.present813 = icmp ne i32 %convergence.current.token812, 0
  br i1 %convergence.token.present813, label %convergence.cascade810, label %convergence.cascade.exit811

schedule.41:                                      ; preds = %varying.coherent.false273, %scheduler.dispatch.route
  %683 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token884 = load i32, ptr %current.token, align 4
  %convergence.token.present885 = icmp ne i32 %convergence.current.token884, 0
  br i1 %convergence.token.present885, label %convergence.cascade882, label %convergence.cascade.exit883

schedule.42:                                      ; preds = %varying.coherent.true932, %scheduler.dispatch.route
  %684 = load <8 x i1>, ptr %current.mask, align 1
  %685 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %684)
  %686 = bitcast <8 x i1> %684 to i8
  %687 = call i8 @llvm.cttz.i8(i8 %686, i1 false)
  %688 = zext i8 %687 to i32
  %689 = select i1 %685, i32 %688, i32 0
  %.spill.load934 = load volatile <8 x i64>, ptr %.spill121, align 64
  %.spill.load935 = load volatile <8 x float>, ptr %.spill117, align 32
  %690 = extractvalue { ptr, i64 } %27, 0
  %691 = mul <8 x i64> %.spill.load934, splat (i64 4)
  %692 = getelementptr i8, ptr %690, <8 x i64> %691
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.spill.load935, <8 x ptr> align 1 %692, <8 x i1> %684)
  store <8 x i1> %684, ptr %current.mask, align 1
  %693 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %684)
  br i1 %693, label %schedule.43, label %scheduler.loop

schedule.43:                                      ; preds = %schedule.42, %varying.coherent.false933, %scheduler.dispatch.route
  %694 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token938 = load i32, ptr %current.token, align 4
  %convergence.token.present939 = icmp ne i32 %convergence.current.token938, 0
  br i1 %convergence.token.present939, label %convergence.cascade936, label %convergence.cascade.exit937

schedule.44:                                      ; preds = %varying.coherent.true964, %scheduler.dispatch.route
  %695 = load <8 x i1>, ptr %current.mask, align 1
  %696 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %695)
  %697 = bitcast <8 x i1> %695 to i8
  %698 = call i8 @llvm.cttz.i8(i8 %697, i1 false)
  %699 = zext i8 %698 to i32
  %700 = select i1 %696, i32 %699, i32 0
  %.spill.load966 = load volatile <8 x i64>, ptr %.spill122, align 64
  %.spill.load967 = load volatile <8 x float>, ptr %.spill118, align 32
  %701 = extractvalue { ptr, i64 } %27, 0
  %702 = mul <8 x i64> %.spill.load966, splat (i64 4)
  %703 = getelementptr i8, ptr %701, <8 x i64> %702
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.spill.load967, <8 x ptr> align 1 %703, <8 x i1> %695)
  store <8 x i1> %695, ptr %current.mask, align 1
  %704 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %695)
  br i1 %704, label %schedule.45, label %scheduler.loop

schedule.45:                                      ; preds = %schedule.44, %varying.coherent.false965, %scheduler.dispatch.route
  %705 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token970 = load i32, ptr %current.token, align 4
  %convergence.token.present971 = icmp ne i32 %convergence.current.token970, 0
  br i1 %convergence.token.present971, label %convergence.cascade968, label %convergence.cascade.exit969

schedule.46:                                      ; preds = %varying.coherent.true996, %scheduler.dispatch.route
  %706 = load <8 x i1>, ptr %current.mask, align 1
  %707 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %706)
  %708 = bitcast <8 x i1> %706 to i8
  %709 = call i8 @llvm.cttz.i8(i8 %708, i1 false)
  %710 = zext i8 %709 to i32
  %711 = select i1 %707, i32 %710, i32 0
  %.spill.load998 = load volatile <8 x i64>, ptr %.spill123, align 64
  %.spill.load999 = load volatile <8 x float>, ptr %.spill119, align 32
  %712 = extractvalue { ptr, i64 } %27, 0
  %713 = mul <8 x i64> %.spill.load998, splat (i64 4)
  %714 = getelementptr i8, ptr %712, <8 x i64> %713
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.spill.load999, <8 x ptr> align 1 %714, <8 x i1> %706)
  store <8 x i1> %706, ptr %current.mask, align 1
  %715 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %706)
  br i1 %715, label %schedule.47, label %scheduler.loop

schedule.47:                                      ; preds = %schedule.46, %varying.coherent.false997, %scheduler.dispatch.route
  %716 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1002 = load i32, ptr %current.token, align 4
  %convergence.token.present1003 = icmp ne i32 %convergence.current.token1002, 0
  br i1 %convergence.token.present1003, label %convergence.cascade1000, label %convergence.cascade.exit1001

varying.divergent:                                ; preds = %schedule.0
  %717 = load i32, ptr %current.token, align 4
  %718 = icmp ne i32 %717, 0
  %719 = sub i32 %717, 1
  %720 = select i1 %718, i32 %719, i32 0
  %721 = load i8, ptr %frame.active, align 1
  %722 = trunc i32 %720 to i8
  %723 = shl i8 1, %722
  %724 = and i8 %721, %723
  %725 = icmp ne i8 %724, 0
  %726 = load <8 x i32>, ptr %frame.static.id, align 32
  %727 = extractelement <8 x i32> %726, i32 %720
  %728 = icmp eq i32 %727, 0
  %729 = and i1 %725, %728
  %730 = and i1 %718, %729
  %731 = xor i1 %730, true
  %732 = and i1 true, %731
  %733 = xor i8 %721, -1
  %734 = icmp ne i8 %733, 0
  %735 = xor i1 %734, true
  %736 = and i1 %732, %735
  br i1 %736, label %convergence.overflow.trap, label %convergence.overflow.resume

varying.coherent:                                 ; preds = %schedule.0
  br i1 %174, label %varying.coherent.true, label %varying.coherent.false

convergence.overflow.trap:                        ; preds = %varying.divergent
  call void @llvm.trap()
  unreachable

convergence.overflow.resume:                      ; preds = %varying.divergent
  %737 = call i8 @llvm.cttz.i8(i8 %733, i1 false)
  %738 = zext i8 %737 to i32
  %739 = select i1 %734, i32 %738, i32 0
  %740 = trunc i32 %739 to i8
  %741 = shl i8 1, %740
  %742 = or i8 %721, %741
  %743 = select i1 %732, i8 %742, i8 %721
  store i8 %743, ptr %frame.active, align 1
  %744 = load <8 x i32>, ptr %frame.static.id, align 32
  %745 = extractelement <8 x i32> %744, i32 %739
  %746 = select i1 %732, i32 0, i32 %745
  %747 = load <8 x i32>, ptr %frame.static.id, align 32
  %748 = insertelement <8 x i32> %747, i32 %746, i32 %739
  store <8 x i32> %748, ptr %frame.static.id, align 32
  %749 = load <8 x i32>, ptr %frame.parent.token, align 32
  %750 = extractelement <8 x i32> %749, i32 %739
  %751 = select i1 %732, i32 %717, i32 %750
  %752 = load <8 x i32>, ptr %frame.parent.token, align 32
  %753 = insertelement <8 x i32> %752, i32 %751, i32 %739
  store <8 x i32> %753, ptr %frame.parent.token, align 32
  %754 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %739
  %755 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %739
  %756 = load <8 x i1>, ptr %754, align 1
  %757 = load <8 x i1>, ptr %755, align 1
  %758 = select i1 %732, <8 x i1> %85, <8 x i1> %756
  store <8 x i1> %758, ptr %754, align 1
  %759 = select i1 %732, <8 x i1> zeroinitializer, <8 x i1> %757
  store <8 x i1> %759, ptr %755, align 1
  %760 = add i32 %739, 1
  %761 = select i1 %730, i32 %717, i32 %760
  %762 = select i1 true, i32 %761, i32 %717
  store i32 %762, ptr %current.token, align 4
  %763 = load <8 x float>, ptr %.slot, align 32
  %764 = select <8 x i1> %173, <8 x float> zeroinitializer, <8 x float> %763
  store <8 x float> %764, ptr %.slot, align 32
  %765 = load i32, ptr %current.token, align 4
  %766 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %171)
  %767 = load i32, ptr %ready.count, align 4
  %768 = icmp uge i32 %767, 8
  %769 = and i1 %766, %768
  br i1 %769, label %ready.overflow.trap134, label %ready.overflow.resume135

ready.overflow.trap134:                           ; preds = %convergence.overflow.resume
  call void @llvm.trap()
  unreachable

ready.overflow.resume135:                         ; preds = %convergence.overflow.resume
  %770 = select i1 %766, i32 %767, i32 0
  %771 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %770
  %772 = load <8 x i1>, ptr %771, align 1
  %773 = select i1 %766, <8 x i1> %171, <8 x i1> %772
  store <8 x i1> %773, ptr %771, align 1
  %774 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %770
  %775 = load i32, ptr %774, align 4
  %776 = select i1 %766, i32 1, i32 %775
  store i32 %776, ptr %774, align 4
  %777 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %770
  %778 = load i32, ptr %777, align 4
  %779 = select i1 %766, i32 %765, i32 %778
  store i32 %779, ptr %777, align 4
  %780 = add i32 %767, 1
  %781 = select i1 %766, i32 %780, i32 %767
  store i32 %781, ptr %ready.count, align 4
  %782 = load <8 x i1>, ptr %runnable.mask, align 1
  %783 = or <8 x i1> %782, %171
  store <8 x i1> %783, ptr %runnable.mask, align 1
  store <8 x i1> %173, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true:                            ; preds = %varying.coherent
  store <8 x i1> %85, ptr %current.mask, align 1
  %784 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %85)
  br i1 %784, label %schedule.1, label %scheduler.loop

varying.coherent.false:                           ; preds = %varying.coherent
  %785 = load <8 x float>, ptr %.slot, align 32
  %786 = select <8 x i1> %85, <8 x float> zeroinitializer, <8 x float> %785
  store <8 x float> %786, ptr %.slot, align 32
  store <8 x i1> %85, ptr %current.mask, align 1
  %787 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %85)
  br i1 %787, label %schedule.2, label %scheduler.loop

convergence.cascade:                              ; preds = %convergence.cascade, %schedule.2
  %convergence.cascade.flow = phi <8 x i1> [ %190, %schedule.2 ], [ %830, %convergence.cascade ]
  %convergence.cascade.depth = phi i32 [ 0, %schedule.2 ], [ %831, %convergence.cascade ]
  %788 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow)
  %789 = load i32, ptr %current.token, align 4
  %790 = icmp ne i32 %789, 0
  %791 = and i1 %788, %790
  %792 = sub i32 %789, 1
  %793 = select i1 %791, i32 %792, i32 0
  %794 = load i8, ptr %frame.active, align 1
  %795 = trunc i32 %793 to i8
  %796 = shl i8 1, %795
  %797 = and i8 %794, %796
  %798 = icmp ne i8 %797, 0
  %799 = load <8 x i32>, ptr %frame.static.id, align 32
  %800 = extractelement <8 x i32> %799, i32 %793
  %convergence.target.pointer = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %800
  %convergence.dynamic.target = load i32, ptr %convergence.target.pointer, align 4
  %801 = icmp eq i32 %convergence.dynamic.target, 2
  %802 = and i1 %798, %801
  %803 = and i1 %791, %802
  %804 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %793
  %805 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %793
  %806 = load <8 x i1>, ptr %804, align 1
  %807 = load <8 x i1>, ptr %805, align 1
  %808 = or <8 x i1> %807, %convergence.cascade.flow
  %809 = load <8 x i1>, ptr %live.mask, align 1
  %810 = and <8 x i1> %806, %809
  %811 = icmp eq <8 x i1> %808, %810
  %812 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %811)
  %813 = and i1 %803, %812
  %814 = select i1 %813, <8 x i1> zeroinitializer, <8 x i1> %808
  %815 = select i1 %803, <8 x i1> %814, <8 x i1> %807
  store <8 x i1> %815, ptr %805, align 1
  %816 = select i1 %813, <8 x i1> zeroinitializer, <8 x i1> %806
  store <8 x i1> %816, ptr %804, align 1
  %817 = trunc i32 %793 to i8
  %818 = shl i8 1, %817
  %819 = xor i8 %818, -1
  %820 = and i8 %794, %819
  %821 = select i1 %813, i8 %820, i8 %794
  store i8 %821, ptr %frame.active, align 1
  %.splatinsert136 = insertelement <8 x i1> poison, i1 %803, i64 0
  %.splat137 = shufflevector <8 x i1> %.splatinsert136, <8 x i1> poison, <8 x i32> zeroinitializer
  %822 = and <8 x i1> %convergence.cascade.flow, %.splat137
  %823 = load <8 x i1>, ptr %runnable.mask, align 1
  %824 = xor <8 x i1> %822, splat (i1 true)
  %825 = and <8 x i1> %823, %824
  store <8 x i1> %825, ptr %runnable.mask, align 1
  %.splatinsert138 = insertelement <8 x i1> poison, i1 %813, i64 0
  %.splat139 = shufflevector <8 x i1> %.splatinsert138, <8 x i1> poison, <8 x i32> zeroinitializer
  %826 = select <8 x i1> %.splat139, <8 x i1> %808, <8 x i1> zeroinitializer
  %827 = load <8 x i32>, ptr %frame.parent.token, align 32
  %828 = extractelement <8 x i32> %827, i32 %793
  %829 = select i1 %813, i32 %828, i32 %789
  store i32 %829, ptr %current.token, align 4
  %.splatinsert140 = insertelement <8 x i1> poison, i1 %803, i64 0
  %.splat141 = shufflevector <8 x i1> %.splatinsert140, <8 x i1> poison, <8 x i32> zeroinitializer
  %830 = select <8 x i1> %.splat141, <8 x i1> %826, <8 x i1> %convergence.cascade.flow
  %831 = add i32 %convergence.cascade.depth, 1
  %832 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %830)
  %833 = icmp ult i32 %831, 8
  %834 = and i1 %832, %833
  %835 = and i1 %803, %834
  %convergence.parent.token = load i32, ptr %current.token, align 4
  %convergence.parent.present = icmp ne i32 %convergence.parent.token, 0
  %836 = and i1 %835, %convergence.parent.present
  br i1 %836, label %convergence.cascade, label %convergence.cascade.exit

convergence.cascade.exit:                         ; preds = %convergence.cascade, %schedule.2
  %convergence.cascade.result = phi <8 x i1> [ %190, %schedule.2 ], [ %830, %convergence.cascade ]
  %837 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %837, label %convergence.target.2.ready, label %scheduler.loop

convergence.target.2.ready:                       ; preds = %convergence.cascade.exit
  %838 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %839 = bitcast <8 x i1> %convergence.cascade.result to i8
  %840 = call i8 @llvm.cttz.i8(i8 %839, i1 false)
  %841 = zext i8 %840 to i32
  %842 = select i1 %838, i32 %841, i32 0
  %.spill.load142 = load <8 x i64>, ptr %.spill21, align 64
  %.spill.load143 = load i64, ptr %.spill10, align 4
  %.splatinsert144 = insertelement <8 x i64> poison, i64 %.spill.load143, i64 0
  %.splat145 = shufflevector <8 x i64> %.splatinsert144, <8 x i64> poison, <8 x i32> zeroinitializer
  %843 = add <8 x i64> %.spill.load142, %.splat145
  %844 = load volatile <8 x i64>, ptr %.spill23, align 64
  %845 = select <8 x i1> %convergence.cascade.result, <8 x i64> %843, <8 x i64> %844
  store volatile <8 x i64> %845, ptr %.spill23, align 64
  %.spill.load146 = load <8 x i1>, ptr %.spill20, align 1
  %846 = and <8 x i1> %convergence.cascade.result, %.spill.load146
  %847 = xor <8 x i1> %.spill.load146, splat (i1 true)
  %848 = and <8 x i1> %convergence.cascade.result, %847
  %849 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %846)
  %850 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %848)
  %851 = and i1 %849, %850
  br i1 %851, label %varying.divergent147, label %varying.coherent148

varying.divergent147:                             ; preds = %convergence.target.2.ready
  %852 = load i32, ptr %current.token, align 4
  %853 = icmp ne i32 %852, 0
  %854 = sub i32 %852, 1
  %855 = select i1 %853, i32 %854, i32 0
  %856 = load i8, ptr %frame.active, align 1
  %857 = trunc i32 %855 to i8
  %858 = shl i8 1, %857
  %859 = and i8 %856, %858
  %860 = icmp ne i8 %859, 0
  %861 = load <8 x i32>, ptr %frame.static.id, align 32
  %862 = extractelement <8 x i32> %861, i32 %855
  %863 = icmp eq i32 %862, 1
  %864 = and i1 %860, %863
  %865 = and i1 %853, %864
  %866 = xor i1 %865, true
  %867 = and i1 true, %866
  %868 = xor i8 %856, -1
  %869 = icmp ne i8 %868, 0
  %870 = xor i1 %869, true
  %871 = and i1 %867, %870
  br i1 %871, label %convergence.overflow.trap149, label %convergence.overflow.resume150

varying.coherent148:                              ; preds = %convergence.target.2.ready
  br i1 %849, label %varying.coherent.true153, label %varying.coherent.false154

convergence.overflow.trap149:                     ; preds = %varying.divergent147
  call void @llvm.trap()
  unreachable

convergence.overflow.resume150:                   ; preds = %varying.divergent147
  %872 = call i8 @llvm.cttz.i8(i8 %868, i1 false)
  %873 = zext i8 %872 to i32
  %874 = select i1 %869, i32 %873, i32 0
  %875 = trunc i32 %874 to i8
  %876 = shl i8 1, %875
  %877 = or i8 %856, %876
  %878 = select i1 %867, i8 %877, i8 %856
  store i8 %878, ptr %frame.active, align 1
  %879 = load <8 x i32>, ptr %frame.static.id, align 32
  %880 = extractelement <8 x i32> %879, i32 %874
  %881 = select i1 %867, i32 1, i32 %880
  %882 = load <8 x i32>, ptr %frame.static.id, align 32
  %883 = insertelement <8 x i32> %882, i32 %881, i32 %874
  store <8 x i32> %883, ptr %frame.static.id, align 32
  %884 = load <8 x i32>, ptr %frame.parent.token, align 32
  %885 = extractelement <8 x i32> %884, i32 %874
  %886 = select i1 %867, i32 %852, i32 %885
  %887 = load <8 x i32>, ptr %frame.parent.token, align 32
  %888 = insertelement <8 x i32> %887, i32 %886, i32 %874
  store <8 x i32> %888, ptr %frame.parent.token, align 32
  %889 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %874
  %890 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %874
  %891 = load <8 x i1>, ptr %889, align 1
  %892 = load <8 x i1>, ptr %890, align 1
  %893 = select i1 %867, <8 x i1> %convergence.cascade.result, <8 x i1> %891
  store <8 x i1> %893, ptr %889, align 1
  %894 = select i1 %867, <8 x i1> zeroinitializer, <8 x i1> %892
  store <8 x i1> %894, ptr %890, align 1
  %895 = add i32 %874, 1
  %896 = select i1 %865, i32 %852, i32 %895
  %897 = select i1 true, i32 %896, i32 %852
  store i32 %897, ptr %current.token, align 4
  %898 = load <8 x float>, ptr %.slot24, align 32
  %899 = select <8 x i1> %848, <8 x float> zeroinitializer, <8 x float> %898
  store <8 x float> %899, ptr %.slot24, align 32
  %900 = load i32, ptr %current.token, align 4
  %901 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %846)
  %902 = load i32, ptr %ready.count, align 4
  %903 = icmp uge i32 %902, 8
  %904 = and i1 %901, %903
  br i1 %904, label %ready.overflow.trap151, label %ready.overflow.resume152

ready.overflow.trap151:                           ; preds = %convergence.overflow.resume150
  call void @llvm.trap()
  unreachable

ready.overflow.resume152:                         ; preds = %convergence.overflow.resume150
  %905 = select i1 %901, i32 %902, i32 0
  %906 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %905
  %907 = load <8 x i1>, ptr %906, align 1
  %908 = select i1 %901, <8 x i1> %846, <8 x i1> %907
  store <8 x i1> %908, ptr %906, align 1
  %909 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %905
  %910 = load i32, ptr %909, align 4
  %911 = select i1 %901, i32 3, i32 %910
  store i32 %911, ptr %909, align 4
  %912 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %905
  %913 = load i32, ptr %912, align 4
  %914 = select i1 %901, i32 %900, i32 %913
  store i32 %914, ptr %912, align 4
  %915 = add i32 %902, 1
  %916 = select i1 %901, i32 %915, i32 %902
  store i32 %916, ptr %ready.count, align 4
  %917 = load <8 x i1>, ptr %runnable.mask, align 1
  %918 = or <8 x i1> %917, %846
  store <8 x i1> %918, ptr %runnable.mask, align 1
  store <8 x i1> %848, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true153:                         ; preds = %varying.coherent148
  store <8 x i1> %convergence.cascade.result, ptr %current.mask, align 1
  %919 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %919, label %schedule.3, label %scheduler.loop

varying.coherent.false154:                        ; preds = %varying.coherent148
  %920 = load <8 x float>, ptr %.slot24, align 32
  %921 = select <8 x i1> %convergence.cascade.result, <8 x float> zeroinitializer, <8 x float> %920
  store <8 x float> %921, ptr %.slot24, align 32
  store <8 x i1> %convergence.cascade.result, ptr %current.mask, align 1
  %922 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %922, label %schedule.4, label %scheduler.loop

convergence.cascade156:                           ; preds = %convergence.cascade156, %schedule.4
  %convergence.cascade.flow160 = phi <8 x i1> [ %204, %schedule.4 ], [ %965, %convergence.cascade156 ]
  %convergence.cascade.depth161 = phi i32 [ 0, %schedule.4 ], [ %966, %convergence.cascade156 ]
  %923 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow160)
  %924 = load i32, ptr %current.token, align 4
  %925 = icmp ne i32 %924, 0
  %926 = and i1 %923, %925
  %927 = sub i32 %924, 1
  %928 = select i1 %926, i32 %927, i32 0
  %929 = load i8, ptr %frame.active, align 1
  %930 = trunc i32 %928 to i8
  %931 = shl i8 1, %930
  %932 = and i8 %929, %931
  %933 = icmp ne i8 %932, 0
  %934 = load <8 x i32>, ptr %frame.static.id, align 32
  %935 = extractelement <8 x i32> %934, i32 %928
  %convergence.target.pointer162 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %935
  %convergence.dynamic.target163 = load i32, ptr %convergence.target.pointer162, align 4
  %936 = icmp eq i32 %convergence.dynamic.target163, 4
  %937 = and i1 %933, %936
  %938 = and i1 %926, %937
  %939 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %928
  %940 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %928
  %941 = load <8 x i1>, ptr %939, align 1
  %942 = load <8 x i1>, ptr %940, align 1
  %943 = or <8 x i1> %942, %convergence.cascade.flow160
  %944 = load <8 x i1>, ptr %live.mask, align 1
  %945 = and <8 x i1> %941, %944
  %946 = icmp eq <8 x i1> %943, %945
  %947 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %946)
  %948 = and i1 %938, %947
  %949 = select i1 %948, <8 x i1> zeroinitializer, <8 x i1> %943
  %950 = select i1 %938, <8 x i1> %949, <8 x i1> %942
  store <8 x i1> %950, ptr %940, align 1
  %951 = select i1 %948, <8 x i1> zeroinitializer, <8 x i1> %941
  store <8 x i1> %951, ptr %939, align 1
  %952 = trunc i32 %928 to i8
  %953 = shl i8 1, %952
  %954 = xor i8 %953, -1
  %955 = and i8 %929, %954
  %956 = select i1 %948, i8 %955, i8 %929
  store i8 %956, ptr %frame.active, align 1
  %.splatinsert164 = insertelement <8 x i1> poison, i1 %938, i64 0
  %.splat165 = shufflevector <8 x i1> %.splatinsert164, <8 x i1> poison, <8 x i32> zeroinitializer
  %957 = and <8 x i1> %convergence.cascade.flow160, %.splat165
  %958 = load <8 x i1>, ptr %runnable.mask, align 1
  %959 = xor <8 x i1> %957, splat (i1 true)
  %960 = and <8 x i1> %958, %959
  store <8 x i1> %960, ptr %runnable.mask, align 1
  %.splatinsert166 = insertelement <8 x i1> poison, i1 %948, i64 0
  %.splat167 = shufflevector <8 x i1> %.splatinsert166, <8 x i1> poison, <8 x i32> zeroinitializer
  %961 = select <8 x i1> %.splat167, <8 x i1> %943, <8 x i1> zeroinitializer
  %962 = load <8 x i32>, ptr %frame.parent.token, align 32
  %963 = extractelement <8 x i32> %962, i32 %928
  %964 = select i1 %948, i32 %963, i32 %924
  store i32 %964, ptr %current.token, align 4
  %.splatinsert168 = insertelement <8 x i1> poison, i1 %938, i64 0
  %.splat169 = shufflevector <8 x i1> %.splatinsert168, <8 x i1> poison, <8 x i32> zeroinitializer
  %965 = select <8 x i1> %.splat169, <8 x i1> %961, <8 x i1> %convergence.cascade.flow160
  %966 = add i32 %convergence.cascade.depth161, 1
  %967 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %965)
  %968 = icmp ult i32 %966, 8
  %969 = and i1 %967, %968
  %970 = and i1 %938, %969
  %convergence.parent.token170 = load i32, ptr %current.token, align 4
  %convergence.parent.present171 = icmp ne i32 %convergence.parent.token170, 0
  %971 = and i1 %970, %convergence.parent.present171
  br i1 %971, label %convergence.cascade156, label %convergence.cascade.exit157

convergence.cascade.exit157:                      ; preds = %convergence.cascade156, %schedule.4
  %convergence.cascade.result172 = phi <8 x i1> [ %204, %schedule.4 ], [ %965, %convergence.cascade156 ]
  %972 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result172)
  br i1 %972, label %convergence.target.4.ready, label %scheduler.loop

convergence.target.4.ready:                       ; preds = %convergence.cascade.exit157
  %973 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result172)
  %974 = bitcast <8 x i1> %convergence.cascade.result172 to i8
  %975 = call i8 @llvm.cttz.i8(i8 %974, i1 false)
  %976 = zext i8 %975 to i32
  %977 = select i1 %973, i32 %976, i32 0
  %.spill.load173 = load <8 x i64>, ptr %.spill21, align 64
  %.spill.load174 = load i64, ptr %.spill12, align 4
  %.splatinsert175 = insertelement <8 x i64> poison, i64 %.spill.load174, i64 0
  %.splat176 = shufflevector <8 x i64> %.splatinsert175, <8 x i64> poison, <8 x i32> zeroinitializer
  %978 = add <8 x i64> %.spill.load173, %.splat176
  %979 = load volatile <8 x i64>, ptr %.spill25, align 64
  %980 = select <8 x i1> %convergence.cascade.result172, <8 x i64> %978, <8 x i64> %979
  store volatile <8 x i64> %980, ptr %.spill25, align 64
  %.spill.load177 = load <8 x i1>, ptr %.spill20, align 1
  %981 = and <8 x i1> %convergence.cascade.result172, %.spill.load177
  %982 = xor <8 x i1> %.spill.load177, splat (i1 true)
  %983 = and <8 x i1> %convergence.cascade.result172, %982
  %984 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %981)
  %985 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %983)
  %986 = and i1 %984, %985
  br i1 %986, label %varying.divergent178, label %varying.coherent179

varying.divergent178:                             ; preds = %convergence.target.4.ready
  %987 = load i32, ptr %current.token, align 4
  %988 = icmp ne i32 %987, 0
  %989 = sub i32 %987, 1
  %990 = select i1 %988, i32 %989, i32 0
  %991 = load i8, ptr %frame.active, align 1
  %992 = trunc i32 %990 to i8
  %993 = shl i8 1, %992
  %994 = and i8 %991, %993
  %995 = icmp ne i8 %994, 0
  %996 = load <8 x i32>, ptr %frame.static.id, align 32
  %997 = extractelement <8 x i32> %996, i32 %990
  %998 = icmp eq i32 %997, 2
  %999 = and i1 %995, %998
  %1000 = and i1 %988, %999
  %1001 = xor i1 %1000, true
  %1002 = and i1 true, %1001
  %1003 = xor i8 %991, -1
  %1004 = icmp ne i8 %1003, 0
  %1005 = xor i1 %1004, true
  %1006 = and i1 %1002, %1005
  br i1 %1006, label %convergence.overflow.trap180, label %convergence.overflow.resume181

varying.coherent179:                              ; preds = %convergence.target.4.ready
  br i1 %984, label %varying.coherent.true184, label %varying.coherent.false185

convergence.overflow.trap180:                     ; preds = %varying.divergent178
  call void @llvm.trap()
  unreachable

convergence.overflow.resume181:                   ; preds = %varying.divergent178
  %1007 = call i8 @llvm.cttz.i8(i8 %1003, i1 false)
  %1008 = zext i8 %1007 to i32
  %1009 = select i1 %1004, i32 %1008, i32 0
  %1010 = trunc i32 %1009 to i8
  %1011 = shl i8 1, %1010
  %1012 = or i8 %991, %1011
  %1013 = select i1 %1002, i8 %1012, i8 %991
  store i8 %1013, ptr %frame.active, align 1
  %1014 = load <8 x i32>, ptr %frame.static.id, align 32
  %1015 = extractelement <8 x i32> %1014, i32 %1009
  %1016 = select i1 %1002, i32 2, i32 %1015
  %1017 = load <8 x i32>, ptr %frame.static.id, align 32
  %1018 = insertelement <8 x i32> %1017, i32 %1016, i32 %1009
  store <8 x i32> %1018, ptr %frame.static.id, align 32
  %1019 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1020 = extractelement <8 x i32> %1019, i32 %1009
  %1021 = select i1 %1002, i32 %987, i32 %1020
  %1022 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1023 = insertelement <8 x i32> %1022, i32 %1021, i32 %1009
  store <8 x i32> %1023, ptr %frame.parent.token, align 32
  %1024 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1009
  %1025 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1009
  %1026 = load <8 x i1>, ptr %1024, align 1
  %1027 = load <8 x i1>, ptr %1025, align 1
  %1028 = select i1 %1002, <8 x i1> %convergence.cascade.result172, <8 x i1> %1026
  store <8 x i1> %1028, ptr %1024, align 1
  %1029 = select i1 %1002, <8 x i1> zeroinitializer, <8 x i1> %1027
  store <8 x i1> %1029, ptr %1025, align 1
  %1030 = add i32 %1009, 1
  %1031 = select i1 %1000, i32 %987, i32 %1030
  %1032 = select i1 true, i32 %1031, i32 %987
  store i32 %1032, ptr %current.token, align 4
  %1033 = load <8 x float>, ptr %.slot26, align 32
  %1034 = select <8 x i1> %983, <8 x float> zeroinitializer, <8 x float> %1033
  store <8 x float> %1034, ptr %.slot26, align 32
  %1035 = load i32, ptr %current.token, align 4
  %1036 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %981)
  %1037 = load i32, ptr %ready.count, align 4
  %1038 = icmp uge i32 %1037, 8
  %1039 = and i1 %1036, %1038
  br i1 %1039, label %ready.overflow.trap182, label %ready.overflow.resume183

ready.overflow.trap182:                           ; preds = %convergence.overflow.resume181
  call void @llvm.trap()
  unreachable

ready.overflow.resume183:                         ; preds = %convergence.overflow.resume181
  %1040 = select i1 %1036, i32 %1037, i32 0
  %1041 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1040
  %1042 = load <8 x i1>, ptr %1041, align 1
  %1043 = select i1 %1036, <8 x i1> %981, <8 x i1> %1042
  store <8 x i1> %1043, ptr %1041, align 1
  %1044 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1040
  %1045 = load i32, ptr %1044, align 4
  %1046 = select i1 %1036, i32 5, i32 %1045
  store i32 %1046, ptr %1044, align 4
  %1047 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1040
  %1048 = load i32, ptr %1047, align 4
  %1049 = select i1 %1036, i32 %1035, i32 %1048
  store i32 %1049, ptr %1047, align 4
  %1050 = add i32 %1037, 1
  %1051 = select i1 %1036, i32 %1050, i32 %1037
  store i32 %1051, ptr %ready.count, align 4
  %1052 = load <8 x i1>, ptr %runnable.mask, align 1
  %1053 = or <8 x i1> %1052, %981
  store <8 x i1> %1053, ptr %runnable.mask, align 1
  store <8 x i1> %983, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true184:                         ; preds = %varying.coherent179
  store <8 x i1> %convergence.cascade.result172, ptr %current.mask, align 1
  %1054 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result172)
  br i1 %1054, label %schedule.5, label %scheduler.loop

varying.coherent.false185:                        ; preds = %varying.coherent179
  %1055 = load <8 x float>, ptr %.slot26, align 32
  %1056 = select <8 x i1> %convergence.cascade.result172, <8 x float> zeroinitializer, <8 x float> %1055
  store <8 x float> %1056, ptr %.slot26, align 32
  store <8 x i1> %convergence.cascade.result172, ptr %current.mask, align 1
  %1057 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result172)
  br i1 %1057, label %schedule.6, label %scheduler.loop

convergence.cascade187:                           ; preds = %convergence.cascade187, %schedule.6
  %convergence.cascade.flow191 = phi <8 x i1> [ %218, %schedule.6 ], [ %1100, %convergence.cascade187 ]
  %convergence.cascade.depth192 = phi i32 [ 0, %schedule.6 ], [ %1101, %convergence.cascade187 ]
  %1058 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow191)
  %1059 = load i32, ptr %current.token, align 4
  %1060 = icmp ne i32 %1059, 0
  %1061 = and i1 %1058, %1060
  %1062 = sub i32 %1059, 1
  %1063 = select i1 %1061, i32 %1062, i32 0
  %1064 = load i8, ptr %frame.active, align 1
  %1065 = trunc i32 %1063 to i8
  %1066 = shl i8 1, %1065
  %1067 = and i8 %1064, %1066
  %1068 = icmp ne i8 %1067, 0
  %1069 = load <8 x i32>, ptr %frame.static.id, align 32
  %1070 = extractelement <8 x i32> %1069, i32 %1063
  %convergence.target.pointer193 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %1070
  %convergence.dynamic.target194 = load i32, ptr %convergence.target.pointer193, align 4
  %1071 = icmp eq i32 %convergence.dynamic.target194, 6
  %1072 = and i1 %1068, %1071
  %1073 = and i1 %1061, %1072
  %1074 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1063
  %1075 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1063
  %1076 = load <8 x i1>, ptr %1074, align 1
  %1077 = load <8 x i1>, ptr %1075, align 1
  %1078 = or <8 x i1> %1077, %convergence.cascade.flow191
  %1079 = load <8 x i1>, ptr %live.mask, align 1
  %1080 = and <8 x i1> %1076, %1079
  %1081 = icmp eq <8 x i1> %1078, %1080
  %1082 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1081)
  %1083 = and i1 %1073, %1082
  %1084 = select i1 %1083, <8 x i1> zeroinitializer, <8 x i1> %1078
  %1085 = select i1 %1073, <8 x i1> %1084, <8 x i1> %1077
  store <8 x i1> %1085, ptr %1075, align 1
  %1086 = select i1 %1083, <8 x i1> zeroinitializer, <8 x i1> %1076
  store <8 x i1> %1086, ptr %1074, align 1
  %1087 = trunc i32 %1063 to i8
  %1088 = shl i8 1, %1087
  %1089 = xor i8 %1088, -1
  %1090 = and i8 %1064, %1089
  %1091 = select i1 %1083, i8 %1090, i8 %1064
  store i8 %1091, ptr %frame.active, align 1
  %.splatinsert195 = insertelement <8 x i1> poison, i1 %1073, i64 0
  %.splat196 = shufflevector <8 x i1> %.splatinsert195, <8 x i1> poison, <8 x i32> zeroinitializer
  %1092 = and <8 x i1> %convergence.cascade.flow191, %.splat196
  %1093 = load <8 x i1>, ptr %runnable.mask, align 1
  %1094 = xor <8 x i1> %1092, splat (i1 true)
  %1095 = and <8 x i1> %1093, %1094
  store <8 x i1> %1095, ptr %runnable.mask, align 1
  %.splatinsert197 = insertelement <8 x i1> poison, i1 %1083, i64 0
  %.splat198 = shufflevector <8 x i1> %.splatinsert197, <8 x i1> poison, <8 x i32> zeroinitializer
  %1096 = select <8 x i1> %.splat198, <8 x i1> %1078, <8 x i1> zeroinitializer
  %1097 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1098 = extractelement <8 x i32> %1097, i32 %1063
  %1099 = select i1 %1083, i32 %1098, i32 %1059
  store i32 %1099, ptr %current.token, align 4
  %.splatinsert199 = insertelement <8 x i1> poison, i1 %1073, i64 0
  %.splat200 = shufflevector <8 x i1> %.splatinsert199, <8 x i1> poison, <8 x i32> zeroinitializer
  %1100 = select <8 x i1> %.splat200, <8 x i1> %1096, <8 x i1> %convergence.cascade.flow191
  %1101 = add i32 %convergence.cascade.depth192, 1
  %1102 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1100)
  %1103 = icmp ult i32 %1101, 8
  %1104 = and i1 %1102, %1103
  %1105 = and i1 %1073, %1104
  %convergence.parent.token201 = load i32, ptr %current.token, align 4
  %convergence.parent.present202 = icmp ne i32 %convergence.parent.token201, 0
  %1106 = and i1 %1105, %convergence.parent.present202
  br i1 %1106, label %convergence.cascade187, label %convergence.cascade.exit188

convergence.cascade.exit188:                      ; preds = %convergence.cascade187, %schedule.6
  %convergence.cascade.result203 = phi <8 x i1> [ %218, %schedule.6 ], [ %1100, %convergence.cascade187 ]
  %1107 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result203)
  br i1 %1107, label %convergence.target.6.ready, label %scheduler.loop

convergence.target.6.ready:                       ; preds = %convergence.cascade.exit188
  %1108 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result203)
  %1109 = bitcast <8 x i1> %convergence.cascade.result203 to i8
  %1110 = call i8 @llvm.cttz.i8(i8 %1109, i1 false)
  %1111 = zext i8 %1110 to i32
  %1112 = select i1 %1108, i32 %1111, i32 0
  %.spill.load204 = load <8 x i64>, ptr %.spill21, align 64
  %.spill.load205 = load volatile i64, ptr %.spill14, align 4
  %.splatinsert206 = insertelement <8 x i64> poison, i64 %.spill.load205, i64 0
  %.splat207 = shufflevector <8 x i64> %.splatinsert206, <8 x i64> poison, <8 x i32> zeroinitializer
  %1113 = add <8 x i64> %.spill.load204, %.splat207
  %1114 = load volatile <8 x i64>, ptr %.spill27, align 64
  %1115 = select <8 x i1> %convergence.cascade.result203, <8 x i64> %1113, <8 x i64> %1114
  store volatile <8 x i64> %1115, ptr %.spill27, align 64
  %.spill.load208 = load <8 x i1>, ptr %.spill20, align 1
  %1116 = and <8 x i1> %convergence.cascade.result203, %.spill.load208
  %1117 = xor <8 x i1> %.spill.load208, splat (i1 true)
  %1118 = and <8 x i1> %convergence.cascade.result203, %1117
  %1119 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1116)
  %1120 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1118)
  %1121 = and i1 %1119, %1120
  br i1 %1121, label %varying.divergent209, label %varying.coherent210

varying.divergent209:                             ; preds = %convergence.target.6.ready
  %1122 = load i32, ptr %current.token, align 4
  %1123 = icmp ne i32 %1122, 0
  %1124 = sub i32 %1122, 1
  %1125 = select i1 %1123, i32 %1124, i32 0
  %1126 = load i8, ptr %frame.active, align 1
  %1127 = trunc i32 %1125 to i8
  %1128 = shl i8 1, %1127
  %1129 = and i8 %1126, %1128
  %1130 = icmp ne i8 %1129, 0
  %1131 = load <8 x i32>, ptr %frame.static.id, align 32
  %1132 = extractelement <8 x i32> %1131, i32 %1125
  %1133 = icmp eq i32 %1132, 3
  %1134 = and i1 %1130, %1133
  %1135 = and i1 %1123, %1134
  %1136 = xor i1 %1135, true
  %1137 = and i1 true, %1136
  %1138 = xor i8 %1126, -1
  %1139 = icmp ne i8 %1138, 0
  %1140 = xor i1 %1139, true
  %1141 = and i1 %1137, %1140
  br i1 %1141, label %convergence.overflow.trap211, label %convergence.overflow.resume212

varying.coherent210:                              ; preds = %convergence.target.6.ready
  br i1 %1119, label %varying.coherent.true215, label %varying.coherent.false216

convergence.overflow.trap211:                     ; preds = %varying.divergent209
  call void @llvm.trap()
  unreachable

convergence.overflow.resume212:                   ; preds = %varying.divergent209
  %1142 = call i8 @llvm.cttz.i8(i8 %1138, i1 false)
  %1143 = zext i8 %1142 to i32
  %1144 = select i1 %1139, i32 %1143, i32 0
  %1145 = trunc i32 %1144 to i8
  %1146 = shl i8 1, %1145
  %1147 = or i8 %1126, %1146
  %1148 = select i1 %1137, i8 %1147, i8 %1126
  store i8 %1148, ptr %frame.active, align 1
  %1149 = load <8 x i32>, ptr %frame.static.id, align 32
  %1150 = extractelement <8 x i32> %1149, i32 %1144
  %1151 = select i1 %1137, i32 3, i32 %1150
  %1152 = load <8 x i32>, ptr %frame.static.id, align 32
  %1153 = insertelement <8 x i32> %1152, i32 %1151, i32 %1144
  store <8 x i32> %1153, ptr %frame.static.id, align 32
  %1154 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1155 = extractelement <8 x i32> %1154, i32 %1144
  %1156 = select i1 %1137, i32 %1122, i32 %1155
  %1157 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1158 = insertelement <8 x i32> %1157, i32 %1156, i32 %1144
  store <8 x i32> %1158, ptr %frame.parent.token, align 32
  %1159 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1144
  %1160 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1144
  %1161 = load <8 x i1>, ptr %1159, align 1
  %1162 = load <8 x i1>, ptr %1160, align 1
  %1163 = select i1 %1137, <8 x i1> %convergence.cascade.result203, <8 x i1> %1161
  store <8 x i1> %1163, ptr %1159, align 1
  %1164 = select i1 %1137, <8 x i1> zeroinitializer, <8 x i1> %1162
  store <8 x i1> %1164, ptr %1160, align 1
  %1165 = add i32 %1144, 1
  %1166 = select i1 %1135, i32 %1122, i32 %1165
  %1167 = select i1 true, i32 %1166, i32 %1122
  store i32 %1167, ptr %current.token, align 4
  %1168 = load <8 x float>, ptr %.slot28, align 32
  %1169 = select <8 x i1> %1118, <8 x float> zeroinitializer, <8 x float> %1168
  store <8 x float> %1169, ptr %.slot28, align 32
  %1170 = load i32, ptr %current.token, align 4
  %1171 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1116)
  %1172 = load i32, ptr %ready.count, align 4
  %1173 = icmp uge i32 %1172, 8
  %1174 = and i1 %1171, %1173
  br i1 %1174, label %ready.overflow.trap213, label %ready.overflow.resume214

ready.overflow.trap213:                           ; preds = %convergence.overflow.resume212
  call void @llvm.trap()
  unreachable

ready.overflow.resume214:                         ; preds = %convergence.overflow.resume212
  %1175 = select i1 %1171, i32 %1172, i32 0
  %1176 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1175
  %1177 = load <8 x i1>, ptr %1176, align 1
  %1178 = select i1 %1171, <8 x i1> %1116, <8 x i1> %1177
  store <8 x i1> %1178, ptr %1176, align 1
  %1179 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1175
  %1180 = load i32, ptr %1179, align 4
  %1181 = select i1 %1171, i32 7, i32 %1180
  store i32 %1181, ptr %1179, align 4
  %1182 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1175
  %1183 = load i32, ptr %1182, align 4
  %1184 = select i1 %1171, i32 %1170, i32 %1183
  store i32 %1184, ptr %1182, align 4
  %1185 = add i32 %1172, 1
  %1186 = select i1 %1171, i32 %1185, i32 %1172
  store i32 %1186, ptr %ready.count, align 4
  %1187 = load <8 x i1>, ptr %runnable.mask, align 1
  %1188 = or <8 x i1> %1187, %1116
  store <8 x i1> %1188, ptr %runnable.mask, align 1
  store <8 x i1> %1118, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true215:                         ; preds = %varying.coherent210
  store <8 x i1> %convergence.cascade.result203, ptr %current.mask, align 1
  %1189 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result203)
  br i1 %1189, label %schedule.7, label %scheduler.loop

varying.coherent.false216:                        ; preds = %varying.coherent210
  %1190 = load <8 x float>, ptr %.slot28, align 32
  %1191 = select <8 x i1> %convergence.cascade.result203, <8 x float> zeroinitializer, <8 x float> %1190
  store <8 x float> %1191, ptr %.slot28, align 32
  store <8 x i1> %convergence.cascade.result203, ptr %current.mask, align 1
  %1192 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result203)
  br i1 %1192, label %schedule.8, label %scheduler.loop

convergence.cascade218:                           ; preds = %convergence.cascade218, %schedule.8
  %convergence.cascade.flow222 = phi <8 x i1> [ %232, %schedule.8 ], [ %1235, %convergence.cascade218 ]
  %convergence.cascade.depth223 = phi i32 [ 0, %schedule.8 ], [ %1236, %convergence.cascade218 ]
  %1193 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow222)
  %1194 = load i32, ptr %current.token, align 4
  %1195 = icmp ne i32 %1194, 0
  %1196 = and i1 %1193, %1195
  %1197 = sub i32 %1194, 1
  %1198 = select i1 %1196, i32 %1197, i32 0
  %1199 = load i8, ptr %frame.active, align 1
  %1200 = trunc i32 %1198 to i8
  %1201 = shl i8 1, %1200
  %1202 = and i8 %1199, %1201
  %1203 = icmp ne i8 %1202, 0
  %1204 = load <8 x i32>, ptr %frame.static.id, align 32
  %1205 = extractelement <8 x i32> %1204, i32 %1198
  %convergence.target.pointer224 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %1205
  %convergence.dynamic.target225 = load i32, ptr %convergence.target.pointer224, align 4
  %1206 = icmp eq i32 %convergence.dynamic.target225, 8
  %1207 = and i1 %1203, %1206
  %1208 = and i1 %1196, %1207
  %1209 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1198
  %1210 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1198
  %1211 = load <8 x i1>, ptr %1209, align 1
  %1212 = load <8 x i1>, ptr %1210, align 1
  %1213 = or <8 x i1> %1212, %convergence.cascade.flow222
  %1214 = load <8 x i1>, ptr %live.mask, align 1
  %1215 = and <8 x i1> %1211, %1214
  %1216 = icmp eq <8 x i1> %1213, %1215
  %1217 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1216)
  %1218 = and i1 %1208, %1217
  %1219 = select i1 %1218, <8 x i1> zeroinitializer, <8 x i1> %1213
  %1220 = select i1 %1208, <8 x i1> %1219, <8 x i1> %1212
  store <8 x i1> %1220, ptr %1210, align 1
  %1221 = select i1 %1218, <8 x i1> zeroinitializer, <8 x i1> %1211
  store <8 x i1> %1221, ptr %1209, align 1
  %1222 = trunc i32 %1198 to i8
  %1223 = shl i8 1, %1222
  %1224 = xor i8 %1223, -1
  %1225 = and i8 %1199, %1224
  %1226 = select i1 %1218, i8 %1225, i8 %1199
  store i8 %1226, ptr %frame.active, align 1
  %.splatinsert226 = insertelement <8 x i1> poison, i1 %1208, i64 0
  %.splat227 = shufflevector <8 x i1> %.splatinsert226, <8 x i1> poison, <8 x i32> zeroinitializer
  %1227 = and <8 x i1> %convergence.cascade.flow222, %.splat227
  %1228 = load <8 x i1>, ptr %runnable.mask, align 1
  %1229 = xor <8 x i1> %1227, splat (i1 true)
  %1230 = and <8 x i1> %1228, %1229
  store <8 x i1> %1230, ptr %runnable.mask, align 1
  %.splatinsert228 = insertelement <8 x i1> poison, i1 %1218, i64 0
  %.splat229 = shufflevector <8 x i1> %.splatinsert228, <8 x i1> poison, <8 x i32> zeroinitializer
  %1231 = select <8 x i1> %.splat229, <8 x i1> %1213, <8 x i1> zeroinitializer
  %1232 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1233 = extractelement <8 x i32> %1232, i32 %1198
  %1234 = select i1 %1218, i32 %1233, i32 %1194
  store i32 %1234, ptr %current.token, align 4
  %.splatinsert230 = insertelement <8 x i1> poison, i1 %1208, i64 0
  %.splat231 = shufflevector <8 x i1> %.splatinsert230, <8 x i1> poison, <8 x i32> zeroinitializer
  %1235 = select <8 x i1> %.splat231, <8 x i1> %1231, <8 x i1> %convergence.cascade.flow222
  %1236 = add i32 %convergence.cascade.depth223, 1
  %1237 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1235)
  %1238 = icmp ult i32 %1236, 8
  %1239 = and i1 %1237, %1238
  %1240 = and i1 %1208, %1239
  %convergence.parent.token232 = load i32, ptr %current.token, align 4
  %convergence.parent.present233 = icmp ne i32 %convergence.parent.token232, 0
  %1241 = and i1 %1240, %convergence.parent.present233
  br i1 %1241, label %convergence.cascade218, label %convergence.cascade.exit219

convergence.cascade.exit219:                      ; preds = %convergence.cascade218, %schedule.8
  %convergence.cascade.result234 = phi <8 x i1> [ %232, %schedule.8 ], [ %1235, %convergence.cascade218 ]
  %1242 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result234)
  br i1 %1242, label %convergence.target.8.ready, label %scheduler.loop

convergence.target.8.ready:                       ; preds = %convergence.cascade.exit219
  %1243 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result234)
  %1244 = bitcast <8 x i1> %convergence.cascade.result234 to i8
  %1245 = call i8 @llvm.cttz.i8(i8 %1244, i1 false)
  %1246 = zext i8 %1245 to i32
  %1247 = select i1 %1243, i32 %1246, i32 0
  %.spill.load235 = load <8 x i64>, ptr %.spill21, align 64
  %.spill.load236 = load volatile i64, ptr %.spill16, align 4
  %.splatinsert237 = insertelement <8 x i64> poison, i64 %.spill.load236, i64 0
  %.splat238 = shufflevector <8 x i64> %.splatinsert237, <8 x i64> poison, <8 x i32> zeroinitializer
  %1248 = add <8 x i64> %.spill.load235, %.splat238
  %1249 = load volatile <8 x i64>, ptr %.spill29, align 64
  %1250 = select <8 x i1> %convergence.cascade.result234, <8 x i64> %1248, <8 x i64> %1249
  store volatile <8 x i64> %1250, ptr %.spill29, align 64
  %.spill.load239 = load <8 x i1>, ptr %.spill20, align 1
  %1251 = and <8 x i1> %convergence.cascade.result234, %.spill.load239
  %1252 = xor <8 x i1> %.spill.load239, splat (i1 true)
  %1253 = and <8 x i1> %convergence.cascade.result234, %1252
  %1254 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1251)
  %1255 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1253)
  %1256 = and i1 %1254, %1255
  br i1 %1256, label %varying.divergent240, label %varying.coherent241

varying.divergent240:                             ; preds = %convergence.target.8.ready
  %1257 = load i32, ptr %current.token, align 4
  %1258 = icmp ne i32 %1257, 0
  %1259 = sub i32 %1257, 1
  %1260 = select i1 %1258, i32 %1259, i32 0
  %1261 = load i8, ptr %frame.active, align 1
  %1262 = trunc i32 %1260 to i8
  %1263 = shl i8 1, %1262
  %1264 = and i8 %1261, %1263
  %1265 = icmp ne i8 %1264, 0
  %1266 = load <8 x i32>, ptr %frame.static.id, align 32
  %1267 = extractelement <8 x i32> %1266, i32 %1260
  %1268 = icmp eq i32 %1267, 4
  %1269 = and i1 %1265, %1268
  %1270 = and i1 %1258, %1269
  %1271 = xor i1 %1270, true
  %1272 = and i1 true, %1271
  %1273 = xor i8 %1261, -1
  %1274 = icmp ne i8 %1273, 0
  %1275 = xor i1 %1274, true
  %1276 = and i1 %1272, %1275
  br i1 %1276, label %convergence.overflow.trap242, label %convergence.overflow.resume243

varying.coherent241:                              ; preds = %convergence.target.8.ready
  br i1 %1254, label %varying.coherent.true246, label %varying.coherent.false247

convergence.overflow.trap242:                     ; preds = %varying.divergent240
  call void @llvm.trap()
  unreachable

convergence.overflow.resume243:                   ; preds = %varying.divergent240
  %1277 = call i8 @llvm.cttz.i8(i8 %1273, i1 false)
  %1278 = zext i8 %1277 to i32
  %1279 = select i1 %1274, i32 %1278, i32 0
  %1280 = trunc i32 %1279 to i8
  %1281 = shl i8 1, %1280
  %1282 = or i8 %1261, %1281
  %1283 = select i1 %1272, i8 %1282, i8 %1261
  store i8 %1283, ptr %frame.active, align 1
  %1284 = load <8 x i32>, ptr %frame.static.id, align 32
  %1285 = extractelement <8 x i32> %1284, i32 %1279
  %1286 = select i1 %1272, i32 4, i32 %1285
  %1287 = load <8 x i32>, ptr %frame.static.id, align 32
  %1288 = insertelement <8 x i32> %1287, i32 %1286, i32 %1279
  store <8 x i32> %1288, ptr %frame.static.id, align 32
  %1289 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1290 = extractelement <8 x i32> %1289, i32 %1279
  %1291 = select i1 %1272, i32 %1257, i32 %1290
  %1292 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1293 = insertelement <8 x i32> %1292, i32 %1291, i32 %1279
  store <8 x i32> %1293, ptr %frame.parent.token, align 32
  %1294 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1279
  %1295 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1279
  %1296 = load <8 x i1>, ptr %1294, align 1
  %1297 = load <8 x i1>, ptr %1295, align 1
  %1298 = select i1 %1272, <8 x i1> %convergence.cascade.result234, <8 x i1> %1296
  store <8 x i1> %1298, ptr %1294, align 1
  %1299 = select i1 %1272, <8 x i1> zeroinitializer, <8 x i1> %1297
  store <8 x i1> %1299, ptr %1295, align 1
  %1300 = add i32 %1279, 1
  %1301 = select i1 %1270, i32 %1257, i32 %1300
  %1302 = select i1 true, i32 %1301, i32 %1257
  store i32 %1302, ptr %current.token, align 4
  %1303 = load <8 x float>, ptr %.slot30, align 32
  %1304 = select <8 x i1> %1253, <8 x float> zeroinitializer, <8 x float> %1303
  store <8 x float> %1304, ptr %.slot30, align 32
  %1305 = load i32, ptr %current.token, align 4
  %1306 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1251)
  %1307 = load i32, ptr %ready.count, align 4
  %1308 = icmp uge i32 %1307, 8
  %1309 = and i1 %1306, %1308
  br i1 %1309, label %ready.overflow.trap244, label %ready.overflow.resume245

ready.overflow.trap244:                           ; preds = %convergence.overflow.resume243
  call void @llvm.trap()
  unreachable

ready.overflow.resume245:                         ; preds = %convergence.overflow.resume243
  %1310 = select i1 %1306, i32 %1307, i32 0
  %1311 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1310
  %1312 = load <8 x i1>, ptr %1311, align 1
  %1313 = select i1 %1306, <8 x i1> %1251, <8 x i1> %1312
  store <8 x i1> %1313, ptr %1311, align 1
  %1314 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1310
  %1315 = load i32, ptr %1314, align 4
  %1316 = select i1 %1306, i32 9, i32 %1315
  store i32 %1316, ptr %1314, align 4
  %1317 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1310
  %1318 = load i32, ptr %1317, align 4
  %1319 = select i1 %1306, i32 %1305, i32 %1318
  store i32 %1319, ptr %1317, align 4
  %1320 = add i32 %1307, 1
  %1321 = select i1 %1306, i32 %1320, i32 %1307
  store i32 %1321, ptr %ready.count, align 4
  %1322 = load <8 x i1>, ptr %runnable.mask, align 1
  %1323 = or <8 x i1> %1322, %1251
  store <8 x i1> %1323, ptr %runnable.mask, align 1
  store <8 x i1> %1253, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true246:                         ; preds = %varying.coherent241
  store <8 x i1> %convergence.cascade.result234, ptr %current.mask, align 1
  %1324 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result234)
  br i1 %1324, label %schedule.9, label %scheduler.loop

varying.coherent.false247:                        ; preds = %varying.coherent241
  %1325 = load <8 x float>, ptr %.slot30, align 32
  %1326 = select <8 x i1> %convergence.cascade.result234, <8 x float> zeroinitializer, <8 x float> %1325
  store <8 x float> %1326, ptr %.slot30, align 32
  store <8 x i1> %convergence.cascade.result234, ptr %current.mask, align 1
  %1327 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result234)
  br i1 %1327, label %schedule.10, label %scheduler.loop

convergence.cascade249:                           ; preds = %convergence.cascade249, %schedule.10
  %convergence.cascade.flow253 = phi <8 x i1> [ %246, %schedule.10 ], [ %1370, %convergence.cascade249 ]
  %convergence.cascade.depth254 = phi i32 [ 0, %schedule.10 ], [ %1371, %convergence.cascade249 ]
  %1328 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow253)
  %1329 = load i32, ptr %current.token, align 4
  %1330 = icmp ne i32 %1329, 0
  %1331 = and i1 %1328, %1330
  %1332 = sub i32 %1329, 1
  %1333 = select i1 %1331, i32 %1332, i32 0
  %1334 = load i8, ptr %frame.active, align 1
  %1335 = trunc i32 %1333 to i8
  %1336 = shl i8 1, %1335
  %1337 = and i8 %1334, %1336
  %1338 = icmp ne i8 %1337, 0
  %1339 = load <8 x i32>, ptr %frame.static.id, align 32
  %1340 = extractelement <8 x i32> %1339, i32 %1333
  %convergence.target.pointer255 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %1340
  %convergence.dynamic.target256 = load i32, ptr %convergence.target.pointer255, align 4
  %1341 = icmp eq i32 %convergence.dynamic.target256, 10
  %1342 = and i1 %1338, %1341
  %1343 = and i1 %1331, %1342
  %1344 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1333
  %1345 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1333
  %1346 = load <8 x i1>, ptr %1344, align 1
  %1347 = load <8 x i1>, ptr %1345, align 1
  %1348 = or <8 x i1> %1347, %convergence.cascade.flow253
  %1349 = load <8 x i1>, ptr %live.mask, align 1
  %1350 = and <8 x i1> %1346, %1349
  %1351 = icmp eq <8 x i1> %1348, %1350
  %1352 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1351)
  %1353 = and i1 %1343, %1352
  %1354 = select i1 %1353, <8 x i1> zeroinitializer, <8 x i1> %1348
  %1355 = select i1 %1343, <8 x i1> %1354, <8 x i1> %1347
  store <8 x i1> %1355, ptr %1345, align 1
  %1356 = select i1 %1353, <8 x i1> zeroinitializer, <8 x i1> %1346
  store <8 x i1> %1356, ptr %1344, align 1
  %1357 = trunc i32 %1333 to i8
  %1358 = shl i8 1, %1357
  %1359 = xor i8 %1358, -1
  %1360 = and i8 %1334, %1359
  %1361 = select i1 %1353, i8 %1360, i8 %1334
  store i8 %1361, ptr %frame.active, align 1
  %.splatinsert257 = insertelement <8 x i1> poison, i1 %1343, i64 0
  %.splat258 = shufflevector <8 x i1> %.splatinsert257, <8 x i1> poison, <8 x i32> zeroinitializer
  %1362 = and <8 x i1> %convergence.cascade.flow253, %.splat258
  %1363 = load <8 x i1>, ptr %runnable.mask, align 1
  %1364 = xor <8 x i1> %1362, splat (i1 true)
  %1365 = and <8 x i1> %1363, %1364
  store <8 x i1> %1365, ptr %runnable.mask, align 1
  %.splatinsert259 = insertelement <8 x i1> poison, i1 %1353, i64 0
  %.splat260 = shufflevector <8 x i1> %.splatinsert259, <8 x i1> poison, <8 x i32> zeroinitializer
  %1366 = select <8 x i1> %.splat260, <8 x i1> %1348, <8 x i1> zeroinitializer
  %1367 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1368 = extractelement <8 x i32> %1367, i32 %1333
  %1369 = select i1 %1353, i32 %1368, i32 %1329
  store i32 %1369, ptr %current.token, align 4
  %.splatinsert261 = insertelement <8 x i1> poison, i1 %1343, i64 0
  %.splat262 = shufflevector <8 x i1> %.splatinsert261, <8 x i1> poison, <8 x i32> zeroinitializer
  %1370 = select <8 x i1> %.splat262, <8 x i1> %1366, <8 x i1> %convergence.cascade.flow253
  %1371 = add i32 %convergence.cascade.depth254, 1
  %1372 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1370)
  %1373 = icmp ult i32 %1371, 8
  %1374 = and i1 %1372, %1373
  %1375 = and i1 %1343, %1374
  %convergence.parent.token263 = load i32, ptr %current.token, align 4
  %convergence.parent.present264 = icmp ne i32 %convergence.parent.token263, 0
  %1376 = and i1 %1375, %convergence.parent.present264
  br i1 %1376, label %convergence.cascade249, label %convergence.cascade.exit250

convergence.cascade.exit250:                      ; preds = %convergence.cascade249, %schedule.10
  %convergence.cascade.result265 = phi <8 x i1> [ %246, %schedule.10 ], [ %1370, %convergence.cascade249 ]
  %1377 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result265)
  br i1 %1377, label %convergence.target.10.ready, label %scheduler.loop

convergence.target.10.ready:                      ; preds = %convergence.cascade.exit250
  %1378 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result265)
  %1379 = bitcast <8 x i1> %convergence.cascade.result265 to i8
  %1380 = call i8 @llvm.cttz.i8(i8 %1379, i1 false)
  %1381 = zext i8 %1380 to i32
  %1382 = select i1 %1378, i32 %1381, i32 0
  %1383 = load <8 x i64>, ptr %.slot31, align 64
  %1384 = select <8 x i1> %convergence.cascade.result265, <8 x i64> zeroinitializer, <8 x i64> %1383
  store <8 x i64> %1384, ptr %.slot31, align 64
  %1385 = load <8 x float>, ptr %.slot32, align 32
  %1386 = select <8 x i1> %convergence.cascade.result265, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %1385
  store <8 x float> %1386, ptr %.slot32, align 32
  %1387 = load <8 x float>, ptr %.slot33, align 32
  %1388 = select <8 x i1> %convergence.cascade.result265, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %1387
  store <8 x float> %1388, ptr %.slot33, align 32
  %1389 = load <8 x float>, ptr %.slot34, align 32
  %1390 = select <8 x i1> %convergence.cascade.result265, <8 x float> zeroinitializer, <8 x float> %1389
  store <8 x float> %1390, ptr %.slot34, align 32
  %1391 = load <8 x float>, ptr %.slot35, align 32
  %1392 = select <8 x i1> %convergence.cascade.result265, <8 x float> zeroinitializer, <8 x float> %1391
  store <8 x float> %1392, ptr %.slot35, align 32
  %1393 = load <8 x float>, ptr %.slot36, align 32
  %1394 = select <8 x i1> %convergence.cascade.result265, <8 x float> zeroinitializer, <8 x float> %1393
  store <8 x float> %1394, ptr %.slot36, align 32
  %1395 = load <8 x float>, ptr %.slot37, align 32
  %1396 = select <8 x i1> %convergence.cascade.result265, <8 x float> zeroinitializer, <8 x float> %1395
  store <8 x float> %1396, ptr %.slot37, align 32
  %1397 = load <8 x float>, ptr %.slot38, align 32
  %1398 = select <8 x i1> %convergence.cascade.result265, <8 x float> zeroinitializer, <8 x float> %1397
  store <8 x float> %1398, ptr %.slot38, align 32
  %1399 = load <8 x float>, ptr %.slot39, align 32
  %1400 = select <8 x i1> %convergence.cascade.result265, <8 x float> zeroinitializer, <8 x float> %1399
  store <8 x float> %1400, ptr %.slot39, align 32
  %1401 = load <8 x float>, ptr %.slot40, align 32
  %1402 = select <8 x i1> %convergence.cascade.result265, <8 x float> zeroinitializer, <8 x float> %1401
  store <8 x float> %1402, ptr %.slot40, align 32
  %1403 = load <8 x float>, ptr %.slot41, align 32
  %1404 = select <8 x i1> %convergence.cascade.result265, <8 x float> zeroinitializer, <8 x float> %1403
  store <8 x float> %1404, ptr %.slot41, align 32
  store <8 x i1> %convergence.cascade.result265, ptr %current.mask, align 1
  %1405 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result265)
  br i1 %1405, label %schedule.11, label %scheduler.loop

varying.divergent266:                             ; preds = %schedule.11
  %1406 = load i32, ptr %current.token, align 4
  %1407 = icmp ne i32 %1406, 0
  %1408 = sub i32 %1406, 1
  %1409 = select i1 %1407, i32 %1408, i32 0
  %1410 = load i8, ptr %frame.active, align 1
  %1411 = trunc i32 %1409 to i8
  %1412 = shl i8 1, %1411
  %1413 = and i8 %1410, %1412
  %1414 = icmp ne i8 %1413, 0
  %1415 = load <8 x i32>, ptr %frame.static.id, align 32
  %1416 = extractelement <8 x i32> %1415, i32 %1409
  %1417 = icmp eq i32 %1416, 5
  %1418 = and i1 %1414, %1417
  %1419 = and i1 %1407, %1418
  %1420 = xor i1 %1419, true
  %1421 = and i1 true, %1420
  %1422 = xor i8 %1410, -1
  %1423 = icmp ne i8 %1422, 0
  %1424 = xor i1 %1423, true
  %1425 = and i1 %1421, %1424
  br i1 %1425, label %convergence.overflow.trap268, label %convergence.overflow.resume269

varying.coherent267:                              ; preds = %schedule.11
  br i1 %257, label %varying.coherent.true272, label %varying.coherent.false273

convergence.overflow.trap268:                     ; preds = %varying.divergent266
  call void @llvm.trap()
  unreachable

convergence.overflow.resume269:                   ; preds = %varying.divergent266
  %1426 = call i8 @llvm.cttz.i8(i8 %1422, i1 false)
  %1427 = zext i8 %1426 to i32
  %1428 = select i1 %1423, i32 %1427, i32 0
  %1429 = trunc i32 %1428 to i8
  %1430 = shl i8 1, %1429
  %1431 = or i8 %1410, %1430
  %1432 = select i1 %1421, i8 %1431, i8 %1410
  store i8 %1432, ptr %frame.active, align 1
  %1433 = load <8 x i32>, ptr %frame.static.id, align 32
  %1434 = extractelement <8 x i32> %1433, i32 %1428
  %1435 = select i1 %1421, i32 5, i32 %1434
  %1436 = load <8 x i32>, ptr %frame.static.id, align 32
  %1437 = insertelement <8 x i32> %1436, i32 %1435, i32 %1428
  store <8 x i32> %1437, ptr %frame.static.id, align 32
  %1438 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1439 = extractelement <8 x i32> %1438, i32 %1428
  %1440 = select i1 %1421, i32 %1406, i32 %1439
  %1441 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1442 = insertelement <8 x i32> %1441, i32 %1440, i32 %1428
  store <8 x i32> %1442, ptr %frame.parent.token, align 32
  %1443 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1428
  %1444 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1428
  %1445 = load <8 x i1>, ptr %1443, align 1
  %1446 = load <8 x i1>, ptr %1444, align 1
  %1447 = select i1 %1421, <8 x i1> %247, <8 x i1> %1445
  store <8 x i1> %1447, ptr %1443, align 1
  %1448 = select i1 %1421, <8 x i1> zeroinitializer, <8 x i1> %1446
  store <8 x i1> %1448, ptr %1444, align 1
  %1449 = add i32 %1428, 1
  %1450 = select i1 %1419, i32 %1406, i32 %1449
  %1451 = select i1 true, i32 %1450, i32 %1406
  store i32 %1451, ptr %current.token, align 4
  %1452 = load i32, ptr %current.token, align 4
  %1453 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %254)
  %1454 = load i32, ptr %ready.count, align 4
  %1455 = icmp uge i32 %1454, 8
  %1456 = and i1 %1453, %1455
  br i1 %1456, label %ready.overflow.trap270, label %ready.overflow.resume271

ready.overflow.trap270:                           ; preds = %convergence.overflow.resume269
  call void @llvm.trap()
  unreachable

ready.overflow.resume271:                         ; preds = %convergence.overflow.resume269
  %1457 = select i1 %1453, i32 %1454, i32 0
  %1458 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1457
  %1459 = load <8 x i1>, ptr %1458, align 1
  %1460 = select i1 %1453, <8 x i1> %254, <8 x i1> %1459
  store <8 x i1> %1460, ptr %1458, align 1
  %1461 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1457
  %1462 = load i32, ptr %1461, align 4
  %1463 = select i1 %1453, i32 12, i32 %1462
  store i32 %1463, ptr %1461, align 4
  %1464 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1457
  %1465 = load i32, ptr %1464, align 4
  %1466 = select i1 %1453, i32 %1452, i32 %1465
  store i32 %1466, ptr %1464, align 4
  %1467 = add i32 %1454, 1
  %1468 = select i1 %1453, i32 %1467, i32 %1454
  store i32 %1468, ptr %ready.count, align 4
  %1469 = load <8 x i1>, ptr %runnable.mask, align 1
  %1470 = or <8 x i1> %1469, %254
  store <8 x i1> %1470, ptr %runnable.mask, align 1
  store <8 x i1> %256, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true272:                         ; preds = %varying.coherent267
  store <8 x i1> %247, ptr %current.mask, align 1
  %1471 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %247)
  br i1 %1471, label %schedule.12, label %scheduler.loop

varying.coherent.false273:                        ; preds = %varying.coherent267
  store <8 x i1> %247, ptr %current.mask, align 1
  %1472 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %247)
  br i1 %1472, label %schedule.41, label %scheduler.loop

varying.divergent312:                             ; preds = %schedule.12
  %1473 = load i32, ptr %current.token, align 4
  %1474 = icmp ne i32 %1473, 0
  %1475 = sub i32 %1473, 1
  %1476 = select i1 %1474, i32 %1475, i32 0
  %1477 = load i8, ptr %frame.active, align 1
  %1478 = trunc i32 %1476 to i8
  %1479 = shl i8 1, %1478
  %1480 = and i8 %1477, %1479
  %1481 = icmp ne i8 %1480, 0
  %1482 = load <8 x i32>, ptr %frame.static.id, align 32
  %1483 = extractelement <8 x i32> %1482, i32 %1476
  %1484 = icmp eq i32 %1483, 6
  %1485 = and i1 %1481, %1484
  %1486 = and i1 %1474, %1485
  %1487 = xor i1 %1486, true
  %1488 = and i1 true, %1487
  %1489 = xor i8 %1477, -1
  %1490 = icmp ne i8 %1489, 0
  %1491 = xor i1 %1490, true
  %1492 = and i1 %1488, %1491
  br i1 %1492, label %convergence.overflow.trap314, label %convergence.overflow.resume315

varying.coherent313:                              ; preds = %schedule.12
  br i1 %380, label %varying.coherent.true318, label %varying.coherent.false319

convergence.overflow.trap314:                     ; preds = %varying.divergent312
  call void @llvm.trap()
  unreachable

convergence.overflow.resume315:                   ; preds = %varying.divergent312
  %1493 = call i8 @llvm.cttz.i8(i8 %1489, i1 false)
  %1494 = zext i8 %1493 to i32
  %1495 = select i1 %1490, i32 %1494, i32 0
  %1496 = trunc i32 %1495 to i8
  %1497 = shl i8 1, %1496
  %1498 = or i8 %1477, %1497
  %1499 = select i1 %1488, i8 %1498, i8 %1477
  store i8 %1499, ptr %frame.active, align 1
  %1500 = load <8 x i32>, ptr %frame.static.id, align 32
  %1501 = extractelement <8 x i32> %1500, i32 %1495
  %1502 = select i1 %1488, i32 6, i32 %1501
  %1503 = load <8 x i32>, ptr %frame.static.id, align 32
  %1504 = insertelement <8 x i32> %1503, i32 %1502, i32 %1495
  store <8 x i32> %1504, ptr %frame.static.id, align 32
  %1505 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1506 = extractelement <8 x i32> %1505, i32 %1495
  %1507 = select i1 %1488, i32 %1473, i32 %1506
  %1508 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1509 = insertelement <8 x i32> %1508, i32 %1507, i32 %1495
  store <8 x i32> %1509, ptr %frame.parent.token, align 32
  %1510 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1495
  %1511 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1495
  %1512 = load <8 x i1>, ptr %1510, align 1
  %1513 = load <8 x i1>, ptr %1511, align 1
  %1514 = select i1 %1488, <8 x i1> %260, <8 x i1> %1512
  store <8 x i1> %1514, ptr %1510, align 1
  %1515 = select i1 %1488, <8 x i1> zeroinitializer, <8 x i1> %1513
  store <8 x i1> %1515, ptr %1511, align 1
  %1516 = add i32 %1495, 1
  %1517 = select i1 %1486, i32 %1473, i32 %1516
  %1518 = select i1 true, i32 %1517, i32 %1473
  store i32 %1518, ptr %current.token, align 4
  %1519 = load <8 x float>, ptr %.slot62, align 32
  %1520 = select <8 x i1> %379, <8 x float> zeroinitializer, <8 x float> %1519
  store <8 x float> %1520, ptr %.slot62, align 32
  %1521 = load i32, ptr %current.token, align 4
  %1522 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %377)
  %1523 = load i32, ptr %ready.count, align 4
  %1524 = icmp uge i32 %1523, 8
  %1525 = and i1 %1522, %1524
  br i1 %1525, label %ready.overflow.trap316, label %ready.overflow.resume317

ready.overflow.trap316:                           ; preds = %convergence.overflow.resume315
  call void @llvm.trap()
  unreachable

ready.overflow.resume317:                         ; preds = %convergence.overflow.resume315
  %1526 = select i1 %1522, i32 %1523, i32 0
  %1527 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1526
  %1528 = load <8 x i1>, ptr %1527, align 1
  %1529 = select i1 %1522, <8 x i1> %377, <8 x i1> %1528
  store <8 x i1> %1529, ptr %1527, align 1
  %1530 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1526
  %1531 = load i32, ptr %1530, align 4
  %1532 = select i1 %1522, i32 13, i32 %1531
  store i32 %1532, ptr %1530, align 4
  %1533 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1526
  %1534 = load i32, ptr %1533, align 4
  %1535 = select i1 %1522, i32 %1521, i32 %1534
  store i32 %1535, ptr %1533, align 4
  %1536 = add i32 %1523, 1
  %1537 = select i1 %1522, i32 %1536, i32 %1523
  store i32 %1537, ptr %ready.count, align 4
  %1538 = load <8 x i1>, ptr %runnable.mask, align 1
  %1539 = or <8 x i1> %1538, %377
  store <8 x i1> %1539, ptr %runnable.mask, align 1
  store <8 x i1> %379, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true318:                         ; preds = %varying.coherent313
  store <8 x i1> %260, ptr %current.mask, align 1
  %1540 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %260)
  br i1 %1540, label %schedule.13, label %scheduler.loop

varying.coherent.false319:                        ; preds = %varying.coherent313
  %1541 = load <8 x float>, ptr %.slot62, align 32
  %1542 = select <8 x i1> %260, <8 x float> zeroinitializer, <8 x float> %1541
  store <8 x float> %1542, ptr %.slot62, align 32
  store <8 x i1> %260, ptr %current.mask, align 1
  %1543 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %260)
  br i1 %1543, label %schedule.14, label %scheduler.loop

convergence.cascade321:                           ; preds = %convergence.cascade321, %schedule.14
  %convergence.cascade.flow325 = phi <8 x i1> [ %396, %schedule.14 ], [ %1586, %convergence.cascade321 ]
  %convergence.cascade.depth326 = phi i32 [ 0, %schedule.14 ], [ %1587, %convergence.cascade321 ]
  %1544 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow325)
  %1545 = load i32, ptr %current.token, align 4
  %1546 = icmp ne i32 %1545, 0
  %1547 = and i1 %1544, %1546
  %1548 = sub i32 %1545, 1
  %1549 = select i1 %1547, i32 %1548, i32 0
  %1550 = load i8, ptr %frame.active, align 1
  %1551 = trunc i32 %1549 to i8
  %1552 = shl i8 1, %1551
  %1553 = and i8 %1550, %1552
  %1554 = icmp ne i8 %1553, 0
  %1555 = load <8 x i32>, ptr %frame.static.id, align 32
  %1556 = extractelement <8 x i32> %1555, i32 %1549
  %convergence.target.pointer327 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %1556
  %convergence.dynamic.target328 = load i32, ptr %convergence.target.pointer327, align 4
  %1557 = icmp eq i32 %convergence.dynamic.target328, 14
  %1558 = and i1 %1554, %1557
  %1559 = and i1 %1547, %1558
  %1560 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1549
  %1561 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1549
  %1562 = load <8 x i1>, ptr %1560, align 1
  %1563 = load <8 x i1>, ptr %1561, align 1
  %1564 = or <8 x i1> %1563, %convergence.cascade.flow325
  %1565 = load <8 x i1>, ptr %live.mask, align 1
  %1566 = and <8 x i1> %1562, %1565
  %1567 = icmp eq <8 x i1> %1564, %1566
  %1568 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1567)
  %1569 = and i1 %1559, %1568
  %1570 = select i1 %1569, <8 x i1> zeroinitializer, <8 x i1> %1564
  %1571 = select i1 %1559, <8 x i1> %1570, <8 x i1> %1563
  store <8 x i1> %1571, ptr %1561, align 1
  %1572 = select i1 %1569, <8 x i1> zeroinitializer, <8 x i1> %1562
  store <8 x i1> %1572, ptr %1560, align 1
  %1573 = trunc i32 %1549 to i8
  %1574 = shl i8 1, %1573
  %1575 = xor i8 %1574, -1
  %1576 = and i8 %1550, %1575
  %1577 = select i1 %1569, i8 %1576, i8 %1550
  store i8 %1577, ptr %frame.active, align 1
  %.splatinsert329 = insertelement <8 x i1> poison, i1 %1559, i64 0
  %.splat330 = shufflevector <8 x i1> %.splatinsert329, <8 x i1> poison, <8 x i32> zeroinitializer
  %1578 = and <8 x i1> %convergence.cascade.flow325, %.splat330
  %1579 = load <8 x i1>, ptr %runnable.mask, align 1
  %1580 = xor <8 x i1> %1578, splat (i1 true)
  %1581 = and <8 x i1> %1579, %1580
  store <8 x i1> %1581, ptr %runnable.mask, align 1
  %.splatinsert331 = insertelement <8 x i1> poison, i1 %1569, i64 0
  %.splat332 = shufflevector <8 x i1> %.splatinsert331, <8 x i1> poison, <8 x i32> zeroinitializer
  %1582 = select <8 x i1> %.splat332, <8 x i1> %1564, <8 x i1> zeroinitializer
  %1583 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1584 = extractelement <8 x i32> %1583, i32 %1549
  %1585 = select i1 %1569, i32 %1584, i32 %1545
  store i32 %1585, ptr %current.token, align 4
  %.splatinsert333 = insertelement <8 x i1> poison, i1 %1559, i64 0
  %.splat334 = shufflevector <8 x i1> %.splatinsert333, <8 x i1> poison, <8 x i32> zeroinitializer
  %1586 = select <8 x i1> %.splat334, <8 x i1> %1582, <8 x i1> %convergence.cascade.flow325
  %1587 = add i32 %convergence.cascade.depth326, 1
  %1588 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1586)
  %1589 = icmp ult i32 %1587, 8
  %1590 = and i1 %1588, %1589
  %1591 = and i1 %1559, %1590
  %convergence.parent.token335 = load i32, ptr %current.token, align 4
  %convergence.parent.present336 = icmp ne i32 %convergence.parent.token335, 0
  %1592 = and i1 %1591, %convergence.parent.present336
  br i1 %1592, label %convergence.cascade321, label %convergence.cascade.exit322

convergence.cascade.exit322:                      ; preds = %convergence.cascade321, %schedule.14
  %convergence.cascade.result337 = phi <8 x i1> [ %396, %schedule.14 ], [ %1586, %convergence.cascade321 ]
  %1593 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result337)
  br i1 %1593, label %convergence.target.14.ready, label %scheduler.loop

convergence.target.14.ready:                      ; preds = %convergence.cascade.exit322
  %1594 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result337)
  %1595 = bitcast <8 x i1> %convergence.cascade.result337 to i8
  %1596 = call i8 @llvm.cttz.i8(i8 %1595, i1 false)
  %1597 = zext i8 %1596 to i32
  %1598 = select i1 %1594, i32 %1597, i32 0
  %.spill.load338 = load <8 x i64>, ptr %.spill60, align 64
  %.spill.load339 = load i64, ptr %.spill10, align 4
  %.splatinsert340 = insertelement <8 x i64> poison, i64 %.spill.load339, i64 0
  %.splat341 = shufflevector <8 x i64> %.splatinsert340, <8 x i64> poison, <8 x i32> zeroinitializer
  %1599 = add <8 x i64> %.spill.load338, %.splat341
  %1600 = load volatile <8 x i64>, ptr %.spill63, align 64
  %1601 = select <8 x i1> %convergence.cascade.result337, <8 x i64> %1599, <8 x i64> %1600
  store volatile <8 x i64> %1601, ptr %.spill63, align 64
  %.spill.load342 = load <8 x i1>, ptr %.spill59, align 1
  %1602 = and <8 x i1> %convergence.cascade.result337, %.spill.load342
  %1603 = xor <8 x i1> %.spill.load342, splat (i1 true)
  %1604 = and <8 x i1> %convergence.cascade.result337, %1603
  %1605 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1602)
  %1606 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1604)
  %1607 = and i1 %1605, %1606
  br i1 %1607, label %varying.divergent343, label %varying.coherent344

varying.divergent343:                             ; preds = %convergence.target.14.ready
  %1608 = load i32, ptr %current.token, align 4
  %1609 = icmp ne i32 %1608, 0
  %1610 = sub i32 %1608, 1
  %1611 = select i1 %1609, i32 %1610, i32 0
  %1612 = load i8, ptr %frame.active, align 1
  %1613 = trunc i32 %1611 to i8
  %1614 = shl i8 1, %1613
  %1615 = and i8 %1612, %1614
  %1616 = icmp ne i8 %1615, 0
  %1617 = load <8 x i32>, ptr %frame.static.id, align 32
  %1618 = extractelement <8 x i32> %1617, i32 %1611
  %1619 = icmp eq i32 %1618, 7
  %1620 = and i1 %1616, %1619
  %1621 = and i1 %1609, %1620
  %1622 = xor i1 %1621, true
  %1623 = and i1 true, %1622
  %1624 = xor i8 %1612, -1
  %1625 = icmp ne i8 %1624, 0
  %1626 = xor i1 %1625, true
  %1627 = and i1 %1623, %1626
  br i1 %1627, label %convergence.overflow.trap345, label %convergence.overflow.resume346

varying.coherent344:                              ; preds = %convergence.target.14.ready
  br i1 %1605, label %varying.coherent.true349, label %varying.coherent.false350

convergence.overflow.trap345:                     ; preds = %varying.divergent343
  call void @llvm.trap()
  unreachable

convergence.overflow.resume346:                   ; preds = %varying.divergent343
  %1628 = call i8 @llvm.cttz.i8(i8 %1624, i1 false)
  %1629 = zext i8 %1628 to i32
  %1630 = select i1 %1625, i32 %1629, i32 0
  %1631 = trunc i32 %1630 to i8
  %1632 = shl i8 1, %1631
  %1633 = or i8 %1612, %1632
  %1634 = select i1 %1623, i8 %1633, i8 %1612
  store i8 %1634, ptr %frame.active, align 1
  %1635 = load <8 x i32>, ptr %frame.static.id, align 32
  %1636 = extractelement <8 x i32> %1635, i32 %1630
  %1637 = select i1 %1623, i32 7, i32 %1636
  %1638 = load <8 x i32>, ptr %frame.static.id, align 32
  %1639 = insertelement <8 x i32> %1638, i32 %1637, i32 %1630
  store <8 x i32> %1639, ptr %frame.static.id, align 32
  %1640 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1641 = extractelement <8 x i32> %1640, i32 %1630
  %1642 = select i1 %1623, i32 %1608, i32 %1641
  %1643 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1644 = insertelement <8 x i32> %1643, i32 %1642, i32 %1630
  store <8 x i32> %1644, ptr %frame.parent.token, align 32
  %1645 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1630
  %1646 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1630
  %1647 = load <8 x i1>, ptr %1645, align 1
  %1648 = load <8 x i1>, ptr %1646, align 1
  %1649 = select i1 %1623, <8 x i1> %convergence.cascade.result337, <8 x i1> %1647
  store <8 x i1> %1649, ptr %1645, align 1
  %1650 = select i1 %1623, <8 x i1> zeroinitializer, <8 x i1> %1648
  store <8 x i1> %1650, ptr %1646, align 1
  %1651 = add i32 %1630, 1
  %1652 = select i1 %1621, i32 %1608, i32 %1651
  %1653 = select i1 true, i32 %1652, i32 %1608
  store i32 %1653, ptr %current.token, align 4
  %1654 = load <8 x float>, ptr %.slot64, align 32
  %1655 = select <8 x i1> %1604, <8 x float> zeroinitializer, <8 x float> %1654
  store <8 x float> %1655, ptr %.slot64, align 32
  %1656 = load i32, ptr %current.token, align 4
  %1657 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1602)
  %1658 = load i32, ptr %ready.count, align 4
  %1659 = icmp uge i32 %1658, 8
  %1660 = and i1 %1657, %1659
  br i1 %1660, label %ready.overflow.trap347, label %ready.overflow.resume348

ready.overflow.trap347:                           ; preds = %convergence.overflow.resume346
  call void @llvm.trap()
  unreachable

ready.overflow.resume348:                         ; preds = %convergence.overflow.resume346
  %1661 = select i1 %1657, i32 %1658, i32 0
  %1662 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1661
  %1663 = load <8 x i1>, ptr %1662, align 1
  %1664 = select i1 %1657, <8 x i1> %1602, <8 x i1> %1663
  store <8 x i1> %1664, ptr %1662, align 1
  %1665 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1661
  %1666 = load i32, ptr %1665, align 4
  %1667 = select i1 %1657, i32 15, i32 %1666
  store i32 %1667, ptr %1665, align 4
  %1668 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1661
  %1669 = load i32, ptr %1668, align 4
  %1670 = select i1 %1657, i32 %1656, i32 %1669
  store i32 %1670, ptr %1668, align 4
  %1671 = add i32 %1658, 1
  %1672 = select i1 %1657, i32 %1671, i32 %1658
  store i32 %1672, ptr %ready.count, align 4
  %1673 = load <8 x i1>, ptr %runnable.mask, align 1
  %1674 = or <8 x i1> %1673, %1602
  store <8 x i1> %1674, ptr %runnable.mask, align 1
  store <8 x i1> %1604, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true349:                         ; preds = %varying.coherent344
  store <8 x i1> %convergence.cascade.result337, ptr %current.mask, align 1
  %1675 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result337)
  br i1 %1675, label %schedule.15, label %scheduler.loop

varying.coherent.false350:                        ; preds = %varying.coherent344
  %1676 = load <8 x float>, ptr %.slot64, align 32
  %1677 = select <8 x i1> %convergence.cascade.result337, <8 x float> zeroinitializer, <8 x float> %1676
  store <8 x float> %1677, ptr %.slot64, align 32
  store <8 x i1> %convergence.cascade.result337, ptr %current.mask, align 1
  %1678 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result337)
  br i1 %1678, label %schedule.16, label %scheduler.loop

convergence.cascade352:                           ; preds = %convergence.cascade352, %schedule.16
  %convergence.cascade.flow356 = phi <8 x i1> [ %410, %schedule.16 ], [ %1721, %convergence.cascade352 ]
  %convergence.cascade.depth357 = phi i32 [ 0, %schedule.16 ], [ %1722, %convergence.cascade352 ]
  %1679 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow356)
  %1680 = load i32, ptr %current.token, align 4
  %1681 = icmp ne i32 %1680, 0
  %1682 = and i1 %1679, %1681
  %1683 = sub i32 %1680, 1
  %1684 = select i1 %1682, i32 %1683, i32 0
  %1685 = load i8, ptr %frame.active, align 1
  %1686 = trunc i32 %1684 to i8
  %1687 = shl i8 1, %1686
  %1688 = and i8 %1685, %1687
  %1689 = icmp ne i8 %1688, 0
  %1690 = load <8 x i32>, ptr %frame.static.id, align 32
  %1691 = extractelement <8 x i32> %1690, i32 %1684
  %convergence.target.pointer358 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %1691
  %convergence.dynamic.target359 = load i32, ptr %convergence.target.pointer358, align 4
  %1692 = icmp eq i32 %convergence.dynamic.target359, 16
  %1693 = and i1 %1689, %1692
  %1694 = and i1 %1682, %1693
  %1695 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1684
  %1696 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1684
  %1697 = load <8 x i1>, ptr %1695, align 1
  %1698 = load <8 x i1>, ptr %1696, align 1
  %1699 = or <8 x i1> %1698, %convergence.cascade.flow356
  %1700 = load <8 x i1>, ptr %live.mask, align 1
  %1701 = and <8 x i1> %1697, %1700
  %1702 = icmp eq <8 x i1> %1699, %1701
  %1703 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1702)
  %1704 = and i1 %1694, %1703
  %1705 = select i1 %1704, <8 x i1> zeroinitializer, <8 x i1> %1699
  %1706 = select i1 %1694, <8 x i1> %1705, <8 x i1> %1698
  store <8 x i1> %1706, ptr %1696, align 1
  %1707 = select i1 %1704, <8 x i1> zeroinitializer, <8 x i1> %1697
  store <8 x i1> %1707, ptr %1695, align 1
  %1708 = trunc i32 %1684 to i8
  %1709 = shl i8 1, %1708
  %1710 = xor i8 %1709, -1
  %1711 = and i8 %1685, %1710
  %1712 = select i1 %1704, i8 %1711, i8 %1685
  store i8 %1712, ptr %frame.active, align 1
  %.splatinsert360 = insertelement <8 x i1> poison, i1 %1694, i64 0
  %.splat361 = shufflevector <8 x i1> %.splatinsert360, <8 x i1> poison, <8 x i32> zeroinitializer
  %1713 = and <8 x i1> %convergence.cascade.flow356, %.splat361
  %1714 = load <8 x i1>, ptr %runnable.mask, align 1
  %1715 = xor <8 x i1> %1713, splat (i1 true)
  %1716 = and <8 x i1> %1714, %1715
  store <8 x i1> %1716, ptr %runnable.mask, align 1
  %.splatinsert362 = insertelement <8 x i1> poison, i1 %1704, i64 0
  %.splat363 = shufflevector <8 x i1> %.splatinsert362, <8 x i1> poison, <8 x i32> zeroinitializer
  %1717 = select <8 x i1> %.splat363, <8 x i1> %1699, <8 x i1> zeroinitializer
  %1718 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1719 = extractelement <8 x i32> %1718, i32 %1684
  %1720 = select i1 %1704, i32 %1719, i32 %1680
  store i32 %1720, ptr %current.token, align 4
  %.splatinsert364 = insertelement <8 x i1> poison, i1 %1694, i64 0
  %.splat365 = shufflevector <8 x i1> %.splatinsert364, <8 x i1> poison, <8 x i32> zeroinitializer
  %1721 = select <8 x i1> %.splat365, <8 x i1> %1717, <8 x i1> %convergence.cascade.flow356
  %1722 = add i32 %convergence.cascade.depth357, 1
  %1723 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1721)
  %1724 = icmp ult i32 %1722, 8
  %1725 = and i1 %1723, %1724
  %1726 = and i1 %1694, %1725
  %convergence.parent.token366 = load i32, ptr %current.token, align 4
  %convergence.parent.present367 = icmp ne i32 %convergence.parent.token366, 0
  %1727 = and i1 %1726, %convergence.parent.present367
  br i1 %1727, label %convergence.cascade352, label %convergence.cascade.exit353

convergence.cascade.exit353:                      ; preds = %convergence.cascade352, %schedule.16
  %convergence.cascade.result368 = phi <8 x i1> [ %410, %schedule.16 ], [ %1721, %convergence.cascade352 ]
  %1728 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result368)
  br i1 %1728, label %convergence.target.16.ready, label %scheduler.loop

convergence.target.16.ready:                      ; preds = %convergence.cascade.exit353
  %1729 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result368)
  %1730 = bitcast <8 x i1> %convergence.cascade.result368 to i8
  %1731 = call i8 @llvm.cttz.i8(i8 %1730, i1 false)
  %1732 = zext i8 %1731 to i32
  %1733 = select i1 %1729, i32 %1732, i32 0
  %.spill.load369 = load <8 x i64>, ptr %.spill60, align 64
  %.spill.load370 = load i64, ptr %.spill12, align 4
  %.splatinsert371 = insertelement <8 x i64> poison, i64 %.spill.load370, i64 0
  %.splat372 = shufflevector <8 x i64> %.splatinsert371, <8 x i64> poison, <8 x i32> zeroinitializer
  %1734 = add <8 x i64> %.spill.load369, %.splat372
  %1735 = load volatile <8 x i64>, ptr %.spill65, align 64
  %1736 = select <8 x i1> %convergence.cascade.result368, <8 x i64> %1734, <8 x i64> %1735
  store volatile <8 x i64> %1736, ptr %.spill65, align 64
  %.spill.load373 = load <8 x i1>, ptr %.spill59, align 1
  %1737 = and <8 x i1> %convergence.cascade.result368, %.spill.load373
  %1738 = xor <8 x i1> %.spill.load373, splat (i1 true)
  %1739 = and <8 x i1> %convergence.cascade.result368, %1738
  %1740 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1737)
  %1741 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1739)
  %1742 = and i1 %1740, %1741
  br i1 %1742, label %varying.divergent374, label %varying.coherent375

varying.divergent374:                             ; preds = %convergence.target.16.ready
  %1743 = load i32, ptr %current.token, align 4
  %1744 = icmp ne i32 %1743, 0
  %1745 = sub i32 %1743, 1
  %1746 = select i1 %1744, i32 %1745, i32 0
  %1747 = load i8, ptr %frame.active, align 1
  %1748 = trunc i32 %1746 to i8
  %1749 = shl i8 1, %1748
  %1750 = and i8 %1747, %1749
  %1751 = icmp ne i8 %1750, 0
  %1752 = load <8 x i32>, ptr %frame.static.id, align 32
  %1753 = extractelement <8 x i32> %1752, i32 %1746
  %1754 = icmp eq i32 %1753, 8
  %1755 = and i1 %1751, %1754
  %1756 = and i1 %1744, %1755
  %1757 = xor i1 %1756, true
  %1758 = and i1 true, %1757
  %1759 = xor i8 %1747, -1
  %1760 = icmp ne i8 %1759, 0
  %1761 = xor i1 %1760, true
  %1762 = and i1 %1758, %1761
  br i1 %1762, label %convergence.overflow.trap376, label %convergence.overflow.resume377

varying.coherent375:                              ; preds = %convergence.target.16.ready
  br i1 %1740, label %varying.coherent.true380, label %varying.coherent.false381

convergence.overflow.trap376:                     ; preds = %varying.divergent374
  call void @llvm.trap()
  unreachable

convergence.overflow.resume377:                   ; preds = %varying.divergent374
  %1763 = call i8 @llvm.cttz.i8(i8 %1759, i1 false)
  %1764 = zext i8 %1763 to i32
  %1765 = select i1 %1760, i32 %1764, i32 0
  %1766 = trunc i32 %1765 to i8
  %1767 = shl i8 1, %1766
  %1768 = or i8 %1747, %1767
  %1769 = select i1 %1758, i8 %1768, i8 %1747
  store i8 %1769, ptr %frame.active, align 1
  %1770 = load <8 x i32>, ptr %frame.static.id, align 32
  %1771 = extractelement <8 x i32> %1770, i32 %1765
  %1772 = select i1 %1758, i32 8, i32 %1771
  %1773 = load <8 x i32>, ptr %frame.static.id, align 32
  %1774 = insertelement <8 x i32> %1773, i32 %1772, i32 %1765
  store <8 x i32> %1774, ptr %frame.static.id, align 32
  %1775 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1776 = extractelement <8 x i32> %1775, i32 %1765
  %1777 = select i1 %1758, i32 %1743, i32 %1776
  %1778 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1779 = insertelement <8 x i32> %1778, i32 %1777, i32 %1765
  store <8 x i32> %1779, ptr %frame.parent.token, align 32
  %1780 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1765
  %1781 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1765
  %1782 = load <8 x i1>, ptr %1780, align 1
  %1783 = load <8 x i1>, ptr %1781, align 1
  %1784 = select i1 %1758, <8 x i1> %convergence.cascade.result368, <8 x i1> %1782
  store <8 x i1> %1784, ptr %1780, align 1
  %1785 = select i1 %1758, <8 x i1> zeroinitializer, <8 x i1> %1783
  store <8 x i1> %1785, ptr %1781, align 1
  %1786 = add i32 %1765, 1
  %1787 = select i1 %1756, i32 %1743, i32 %1786
  %1788 = select i1 true, i32 %1787, i32 %1743
  store i32 %1788, ptr %current.token, align 4
  %1789 = load <8 x float>, ptr %.slot66, align 32
  %1790 = select <8 x i1> %1739, <8 x float> zeroinitializer, <8 x float> %1789
  store <8 x float> %1790, ptr %.slot66, align 32
  %1791 = load i32, ptr %current.token, align 4
  %1792 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1737)
  %1793 = load i32, ptr %ready.count, align 4
  %1794 = icmp uge i32 %1793, 8
  %1795 = and i1 %1792, %1794
  br i1 %1795, label %ready.overflow.trap378, label %ready.overflow.resume379

ready.overflow.trap378:                           ; preds = %convergence.overflow.resume377
  call void @llvm.trap()
  unreachable

ready.overflow.resume379:                         ; preds = %convergence.overflow.resume377
  %1796 = select i1 %1792, i32 %1793, i32 0
  %1797 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1796
  %1798 = load <8 x i1>, ptr %1797, align 1
  %1799 = select i1 %1792, <8 x i1> %1737, <8 x i1> %1798
  store <8 x i1> %1799, ptr %1797, align 1
  %1800 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1796
  %1801 = load i32, ptr %1800, align 4
  %1802 = select i1 %1792, i32 17, i32 %1801
  store i32 %1802, ptr %1800, align 4
  %1803 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1796
  %1804 = load i32, ptr %1803, align 4
  %1805 = select i1 %1792, i32 %1791, i32 %1804
  store i32 %1805, ptr %1803, align 4
  %1806 = add i32 %1793, 1
  %1807 = select i1 %1792, i32 %1806, i32 %1793
  store i32 %1807, ptr %ready.count, align 4
  %1808 = load <8 x i1>, ptr %runnable.mask, align 1
  %1809 = or <8 x i1> %1808, %1737
  store <8 x i1> %1809, ptr %runnable.mask, align 1
  store <8 x i1> %1739, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true380:                         ; preds = %varying.coherent375
  store <8 x i1> %convergence.cascade.result368, ptr %current.mask, align 1
  %1810 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result368)
  br i1 %1810, label %schedule.17, label %scheduler.loop

varying.coherent.false381:                        ; preds = %varying.coherent375
  %1811 = load <8 x float>, ptr %.slot66, align 32
  %1812 = select <8 x i1> %convergence.cascade.result368, <8 x float> zeroinitializer, <8 x float> %1811
  store <8 x float> %1812, ptr %.slot66, align 32
  store <8 x i1> %convergence.cascade.result368, ptr %current.mask, align 1
  %1813 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result368)
  br i1 %1813, label %schedule.18, label %scheduler.loop

convergence.cascade383:                           ; preds = %convergence.cascade383, %schedule.18
  %convergence.cascade.flow387 = phi <8 x i1> [ %424, %schedule.18 ], [ %1856, %convergence.cascade383 ]
  %convergence.cascade.depth388 = phi i32 [ 0, %schedule.18 ], [ %1857, %convergence.cascade383 ]
  %1814 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow387)
  %1815 = load i32, ptr %current.token, align 4
  %1816 = icmp ne i32 %1815, 0
  %1817 = and i1 %1814, %1816
  %1818 = sub i32 %1815, 1
  %1819 = select i1 %1817, i32 %1818, i32 0
  %1820 = load i8, ptr %frame.active, align 1
  %1821 = trunc i32 %1819 to i8
  %1822 = shl i8 1, %1821
  %1823 = and i8 %1820, %1822
  %1824 = icmp ne i8 %1823, 0
  %1825 = load <8 x i32>, ptr %frame.static.id, align 32
  %1826 = extractelement <8 x i32> %1825, i32 %1819
  %convergence.target.pointer389 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %1826
  %convergence.dynamic.target390 = load i32, ptr %convergence.target.pointer389, align 4
  %1827 = icmp eq i32 %convergence.dynamic.target390, 18
  %1828 = and i1 %1824, %1827
  %1829 = and i1 %1817, %1828
  %1830 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1819
  %1831 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1819
  %1832 = load <8 x i1>, ptr %1830, align 1
  %1833 = load <8 x i1>, ptr %1831, align 1
  %1834 = or <8 x i1> %1833, %convergence.cascade.flow387
  %1835 = load <8 x i1>, ptr %live.mask, align 1
  %1836 = and <8 x i1> %1832, %1835
  %1837 = icmp eq <8 x i1> %1834, %1836
  %1838 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1837)
  %1839 = and i1 %1829, %1838
  %1840 = select i1 %1839, <8 x i1> zeroinitializer, <8 x i1> %1834
  %1841 = select i1 %1829, <8 x i1> %1840, <8 x i1> %1833
  store <8 x i1> %1841, ptr %1831, align 1
  %1842 = select i1 %1839, <8 x i1> zeroinitializer, <8 x i1> %1832
  store <8 x i1> %1842, ptr %1830, align 1
  %1843 = trunc i32 %1819 to i8
  %1844 = shl i8 1, %1843
  %1845 = xor i8 %1844, -1
  %1846 = and i8 %1820, %1845
  %1847 = select i1 %1839, i8 %1846, i8 %1820
  store i8 %1847, ptr %frame.active, align 1
  %.splatinsert391 = insertelement <8 x i1> poison, i1 %1829, i64 0
  %.splat392 = shufflevector <8 x i1> %.splatinsert391, <8 x i1> poison, <8 x i32> zeroinitializer
  %1848 = and <8 x i1> %convergence.cascade.flow387, %.splat392
  %1849 = load <8 x i1>, ptr %runnable.mask, align 1
  %1850 = xor <8 x i1> %1848, splat (i1 true)
  %1851 = and <8 x i1> %1849, %1850
  store <8 x i1> %1851, ptr %runnable.mask, align 1
  %.splatinsert393 = insertelement <8 x i1> poison, i1 %1839, i64 0
  %.splat394 = shufflevector <8 x i1> %.splatinsert393, <8 x i1> poison, <8 x i32> zeroinitializer
  %1852 = select <8 x i1> %.splat394, <8 x i1> %1834, <8 x i1> zeroinitializer
  %1853 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1854 = extractelement <8 x i32> %1853, i32 %1819
  %1855 = select i1 %1839, i32 %1854, i32 %1815
  store i32 %1855, ptr %current.token, align 4
  %.splatinsert395 = insertelement <8 x i1> poison, i1 %1829, i64 0
  %.splat396 = shufflevector <8 x i1> %.splatinsert395, <8 x i1> poison, <8 x i32> zeroinitializer
  %1856 = select <8 x i1> %.splat396, <8 x i1> %1852, <8 x i1> %convergence.cascade.flow387
  %1857 = add i32 %convergence.cascade.depth388, 1
  %1858 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1856)
  %1859 = icmp ult i32 %1857, 8
  %1860 = and i1 %1858, %1859
  %1861 = and i1 %1829, %1860
  %convergence.parent.token397 = load i32, ptr %current.token, align 4
  %convergence.parent.present398 = icmp ne i32 %convergence.parent.token397, 0
  %1862 = and i1 %1861, %convergence.parent.present398
  br i1 %1862, label %convergence.cascade383, label %convergence.cascade.exit384

convergence.cascade.exit384:                      ; preds = %convergence.cascade383, %schedule.18
  %convergence.cascade.result399 = phi <8 x i1> [ %424, %schedule.18 ], [ %1856, %convergence.cascade383 ]
  %1863 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result399)
  br i1 %1863, label %convergence.target.18.ready, label %scheduler.loop

convergence.target.18.ready:                      ; preds = %convergence.cascade.exit384
  %1864 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result399)
  %1865 = bitcast <8 x i1> %convergence.cascade.result399 to i8
  %1866 = call i8 @llvm.cttz.i8(i8 %1865, i1 false)
  %1867 = zext i8 %1866 to i32
  %1868 = select i1 %1864, i32 %1867, i32 0
  %.spill.load400 = load <8 x i64>, ptr %.spill60, align 64
  %.spill.load401 = load volatile i64, ptr %.spill14, align 4
  %.splatinsert402 = insertelement <8 x i64> poison, i64 %.spill.load401, i64 0
  %.splat403 = shufflevector <8 x i64> %.splatinsert402, <8 x i64> poison, <8 x i32> zeroinitializer
  %1869 = add <8 x i64> %.spill.load400, %.splat403
  %1870 = load volatile <8 x i64>, ptr %.spill67, align 64
  %1871 = select <8 x i1> %convergence.cascade.result399, <8 x i64> %1869, <8 x i64> %1870
  store volatile <8 x i64> %1871, ptr %.spill67, align 64
  %.spill.load404 = load <8 x i1>, ptr %.spill59, align 1
  %1872 = and <8 x i1> %convergence.cascade.result399, %.spill.load404
  %1873 = xor <8 x i1> %.spill.load404, splat (i1 true)
  %1874 = and <8 x i1> %convergence.cascade.result399, %1873
  %1875 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1872)
  %1876 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1874)
  %1877 = and i1 %1875, %1876
  br i1 %1877, label %varying.divergent405, label %varying.coherent406

varying.divergent405:                             ; preds = %convergence.target.18.ready
  %1878 = load i32, ptr %current.token, align 4
  %1879 = icmp ne i32 %1878, 0
  %1880 = sub i32 %1878, 1
  %1881 = select i1 %1879, i32 %1880, i32 0
  %1882 = load i8, ptr %frame.active, align 1
  %1883 = trunc i32 %1881 to i8
  %1884 = shl i8 1, %1883
  %1885 = and i8 %1882, %1884
  %1886 = icmp ne i8 %1885, 0
  %1887 = load <8 x i32>, ptr %frame.static.id, align 32
  %1888 = extractelement <8 x i32> %1887, i32 %1881
  %1889 = icmp eq i32 %1888, 9
  %1890 = and i1 %1886, %1889
  %1891 = and i1 %1879, %1890
  %1892 = xor i1 %1891, true
  %1893 = and i1 true, %1892
  %1894 = xor i8 %1882, -1
  %1895 = icmp ne i8 %1894, 0
  %1896 = xor i1 %1895, true
  %1897 = and i1 %1893, %1896
  br i1 %1897, label %convergence.overflow.trap407, label %convergence.overflow.resume408

varying.coherent406:                              ; preds = %convergence.target.18.ready
  br i1 %1875, label %varying.coherent.true411, label %varying.coherent.false412

convergence.overflow.trap407:                     ; preds = %varying.divergent405
  call void @llvm.trap()
  unreachable

convergence.overflow.resume408:                   ; preds = %varying.divergent405
  %1898 = call i8 @llvm.cttz.i8(i8 %1894, i1 false)
  %1899 = zext i8 %1898 to i32
  %1900 = select i1 %1895, i32 %1899, i32 0
  %1901 = trunc i32 %1900 to i8
  %1902 = shl i8 1, %1901
  %1903 = or i8 %1882, %1902
  %1904 = select i1 %1893, i8 %1903, i8 %1882
  store i8 %1904, ptr %frame.active, align 1
  %1905 = load <8 x i32>, ptr %frame.static.id, align 32
  %1906 = extractelement <8 x i32> %1905, i32 %1900
  %1907 = select i1 %1893, i32 9, i32 %1906
  %1908 = load <8 x i32>, ptr %frame.static.id, align 32
  %1909 = insertelement <8 x i32> %1908, i32 %1907, i32 %1900
  store <8 x i32> %1909, ptr %frame.static.id, align 32
  %1910 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1911 = extractelement <8 x i32> %1910, i32 %1900
  %1912 = select i1 %1893, i32 %1878, i32 %1911
  %1913 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1914 = insertelement <8 x i32> %1913, i32 %1912, i32 %1900
  store <8 x i32> %1914, ptr %frame.parent.token, align 32
  %1915 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1900
  %1916 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1900
  %1917 = load <8 x i1>, ptr %1915, align 1
  %1918 = load <8 x i1>, ptr %1916, align 1
  %1919 = select i1 %1893, <8 x i1> %convergence.cascade.result399, <8 x i1> %1917
  store <8 x i1> %1919, ptr %1915, align 1
  %1920 = select i1 %1893, <8 x i1> zeroinitializer, <8 x i1> %1918
  store <8 x i1> %1920, ptr %1916, align 1
  %1921 = add i32 %1900, 1
  %1922 = select i1 %1891, i32 %1878, i32 %1921
  %1923 = select i1 true, i32 %1922, i32 %1878
  store i32 %1923, ptr %current.token, align 4
  %1924 = load <8 x float>, ptr %.slot68, align 32
  %1925 = select <8 x i1> %1874, <8 x float> zeroinitializer, <8 x float> %1924
  store <8 x float> %1925, ptr %.slot68, align 32
  %1926 = load i32, ptr %current.token, align 4
  %1927 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1872)
  %1928 = load i32, ptr %ready.count, align 4
  %1929 = icmp uge i32 %1928, 8
  %1930 = and i1 %1927, %1929
  br i1 %1930, label %ready.overflow.trap409, label %ready.overflow.resume410

ready.overflow.trap409:                           ; preds = %convergence.overflow.resume408
  call void @llvm.trap()
  unreachable

ready.overflow.resume410:                         ; preds = %convergence.overflow.resume408
  %1931 = select i1 %1927, i32 %1928, i32 0
  %1932 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1931
  %1933 = load <8 x i1>, ptr %1932, align 1
  %1934 = select i1 %1927, <8 x i1> %1872, <8 x i1> %1933
  store <8 x i1> %1934, ptr %1932, align 1
  %1935 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1931
  %1936 = load i32, ptr %1935, align 4
  %1937 = select i1 %1927, i32 19, i32 %1936
  store i32 %1937, ptr %1935, align 4
  %1938 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1931
  %1939 = load i32, ptr %1938, align 4
  %1940 = select i1 %1927, i32 %1926, i32 %1939
  store i32 %1940, ptr %1938, align 4
  %1941 = add i32 %1928, 1
  %1942 = select i1 %1927, i32 %1941, i32 %1928
  store i32 %1942, ptr %ready.count, align 4
  %1943 = load <8 x i1>, ptr %runnable.mask, align 1
  %1944 = or <8 x i1> %1943, %1872
  store <8 x i1> %1944, ptr %runnable.mask, align 1
  store <8 x i1> %1874, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true411:                         ; preds = %varying.coherent406
  store <8 x i1> %convergence.cascade.result399, ptr %current.mask, align 1
  %1945 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result399)
  br i1 %1945, label %schedule.19, label %scheduler.loop

varying.coherent.false412:                        ; preds = %varying.coherent406
  %1946 = load <8 x float>, ptr %.slot68, align 32
  %1947 = select <8 x i1> %convergence.cascade.result399, <8 x float> zeroinitializer, <8 x float> %1946
  store <8 x float> %1947, ptr %.slot68, align 32
  store <8 x i1> %convergence.cascade.result399, ptr %current.mask, align 1
  %1948 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result399)
  br i1 %1948, label %schedule.20, label %scheduler.loop

convergence.cascade414:                           ; preds = %convergence.cascade414, %schedule.20
  %convergence.cascade.flow418 = phi <8 x i1> [ %438, %schedule.20 ], [ %1991, %convergence.cascade414 ]
  %convergence.cascade.depth419 = phi i32 [ 0, %schedule.20 ], [ %1992, %convergence.cascade414 ]
  %1949 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow418)
  %1950 = load i32, ptr %current.token, align 4
  %1951 = icmp ne i32 %1950, 0
  %1952 = and i1 %1949, %1951
  %1953 = sub i32 %1950, 1
  %1954 = select i1 %1952, i32 %1953, i32 0
  %1955 = load i8, ptr %frame.active, align 1
  %1956 = trunc i32 %1954 to i8
  %1957 = shl i8 1, %1956
  %1958 = and i8 %1955, %1957
  %1959 = icmp ne i8 %1958, 0
  %1960 = load <8 x i32>, ptr %frame.static.id, align 32
  %1961 = extractelement <8 x i32> %1960, i32 %1954
  %convergence.target.pointer420 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %1961
  %convergence.dynamic.target421 = load i32, ptr %convergence.target.pointer420, align 4
  %1962 = icmp eq i32 %convergence.dynamic.target421, 20
  %1963 = and i1 %1959, %1962
  %1964 = and i1 %1952, %1963
  %1965 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1954
  %1966 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1954
  %1967 = load <8 x i1>, ptr %1965, align 1
  %1968 = load <8 x i1>, ptr %1966, align 1
  %1969 = or <8 x i1> %1968, %convergence.cascade.flow418
  %1970 = load <8 x i1>, ptr %live.mask, align 1
  %1971 = and <8 x i1> %1967, %1970
  %1972 = icmp eq <8 x i1> %1969, %1971
  %1973 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1972)
  %1974 = and i1 %1964, %1973
  %1975 = select i1 %1974, <8 x i1> zeroinitializer, <8 x i1> %1969
  %1976 = select i1 %1964, <8 x i1> %1975, <8 x i1> %1968
  store <8 x i1> %1976, ptr %1966, align 1
  %1977 = select i1 %1974, <8 x i1> zeroinitializer, <8 x i1> %1967
  store <8 x i1> %1977, ptr %1965, align 1
  %1978 = trunc i32 %1954 to i8
  %1979 = shl i8 1, %1978
  %1980 = xor i8 %1979, -1
  %1981 = and i8 %1955, %1980
  %1982 = select i1 %1974, i8 %1981, i8 %1955
  store i8 %1982, ptr %frame.active, align 1
  %.splatinsert422 = insertelement <8 x i1> poison, i1 %1964, i64 0
  %.splat423 = shufflevector <8 x i1> %.splatinsert422, <8 x i1> poison, <8 x i32> zeroinitializer
  %1983 = and <8 x i1> %convergence.cascade.flow418, %.splat423
  %1984 = load <8 x i1>, ptr %runnable.mask, align 1
  %1985 = xor <8 x i1> %1983, splat (i1 true)
  %1986 = and <8 x i1> %1984, %1985
  store <8 x i1> %1986, ptr %runnable.mask, align 1
  %.splatinsert424 = insertelement <8 x i1> poison, i1 %1974, i64 0
  %.splat425 = shufflevector <8 x i1> %.splatinsert424, <8 x i1> poison, <8 x i32> zeroinitializer
  %1987 = select <8 x i1> %.splat425, <8 x i1> %1969, <8 x i1> zeroinitializer
  %1988 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1989 = extractelement <8 x i32> %1988, i32 %1954
  %1990 = select i1 %1974, i32 %1989, i32 %1950
  store i32 %1990, ptr %current.token, align 4
  %.splatinsert426 = insertelement <8 x i1> poison, i1 %1964, i64 0
  %.splat427 = shufflevector <8 x i1> %.splatinsert426, <8 x i1> poison, <8 x i32> zeroinitializer
  %1991 = select <8 x i1> %.splat427, <8 x i1> %1987, <8 x i1> %convergence.cascade.flow418
  %1992 = add i32 %convergence.cascade.depth419, 1
  %1993 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1991)
  %1994 = icmp ult i32 %1992, 8
  %1995 = and i1 %1993, %1994
  %1996 = and i1 %1964, %1995
  %convergence.parent.token428 = load i32, ptr %current.token, align 4
  %convergence.parent.present429 = icmp ne i32 %convergence.parent.token428, 0
  %1997 = and i1 %1996, %convergence.parent.present429
  br i1 %1997, label %convergence.cascade414, label %convergence.cascade.exit415

convergence.cascade.exit415:                      ; preds = %convergence.cascade414, %schedule.20
  %convergence.cascade.result430 = phi <8 x i1> [ %438, %schedule.20 ], [ %1991, %convergence.cascade414 ]
  %1998 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result430)
  br i1 %1998, label %convergence.target.20.ready, label %scheduler.loop

convergence.target.20.ready:                      ; preds = %convergence.cascade.exit415
  %1999 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result430)
  %2000 = bitcast <8 x i1> %convergence.cascade.result430 to i8
  %2001 = call i8 @llvm.cttz.i8(i8 %2000, i1 false)
  %2002 = zext i8 %2001 to i32
  %2003 = select i1 %1999, i32 %2002, i32 0
  %.spill.load431 = load <8 x i64>, ptr %.spill60, align 64
  %.spill.load432 = load volatile i64, ptr %.spill16, align 4
  %.splatinsert433 = insertelement <8 x i64> poison, i64 %.spill.load432, i64 0
  %.splat434 = shufflevector <8 x i64> %.splatinsert433, <8 x i64> poison, <8 x i32> zeroinitializer
  %2004 = add <8 x i64> %.spill.load431, %.splat434
  %2005 = load volatile <8 x i64>, ptr %.spill69, align 64
  %2006 = select <8 x i1> %convergence.cascade.result430, <8 x i64> %2004, <8 x i64> %2005
  store volatile <8 x i64> %2006, ptr %.spill69, align 64
  %.spill.load435 = load <8 x i1>, ptr %.spill59, align 1
  %2007 = and <8 x i1> %convergence.cascade.result430, %.spill.load435
  %2008 = xor <8 x i1> %.spill.load435, splat (i1 true)
  %2009 = and <8 x i1> %convergence.cascade.result430, %2008
  %2010 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2007)
  %2011 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2009)
  %2012 = and i1 %2010, %2011
  br i1 %2012, label %varying.divergent436, label %varying.coherent437

varying.divergent436:                             ; preds = %convergence.target.20.ready
  %2013 = load i32, ptr %current.token, align 4
  %2014 = icmp ne i32 %2013, 0
  %2015 = sub i32 %2013, 1
  %2016 = select i1 %2014, i32 %2015, i32 0
  %2017 = load i8, ptr %frame.active, align 1
  %2018 = trunc i32 %2016 to i8
  %2019 = shl i8 1, %2018
  %2020 = and i8 %2017, %2019
  %2021 = icmp ne i8 %2020, 0
  %2022 = load <8 x i32>, ptr %frame.static.id, align 32
  %2023 = extractelement <8 x i32> %2022, i32 %2016
  %2024 = icmp eq i32 %2023, 10
  %2025 = and i1 %2021, %2024
  %2026 = and i1 %2014, %2025
  %2027 = xor i1 %2026, true
  %2028 = and i1 true, %2027
  %2029 = xor i8 %2017, -1
  %2030 = icmp ne i8 %2029, 0
  %2031 = xor i1 %2030, true
  %2032 = and i1 %2028, %2031
  br i1 %2032, label %convergence.overflow.trap438, label %convergence.overflow.resume439

varying.coherent437:                              ; preds = %convergence.target.20.ready
  br i1 %2010, label %varying.coherent.true442, label %varying.coherent.false443

convergence.overflow.trap438:                     ; preds = %varying.divergent436
  call void @llvm.trap()
  unreachable

convergence.overflow.resume439:                   ; preds = %varying.divergent436
  %2033 = call i8 @llvm.cttz.i8(i8 %2029, i1 false)
  %2034 = zext i8 %2033 to i32
  %2035 = select i1 %2030, i32 %2034, i32 0
  %2036 = trunc i32 %2035 to i8
  %2037 = shl i8 1, %2036
  %2038 = or i8 %2017, %2037
  %2039 = select i1 %2028, i8 %2038, i8 %2017
  store i8 %2039, ptr %frame.active, align 1
  %2040 = load <8 x i32>, ptr %frame.static.id, align 32
  %2041 = extractelement <8 x i32> %2040, i32 %2035
  %2042 = select i1 %2028, i32 10, i32 %2041
  %2043 = load <8 x i32>, ptr %frame.static.id, align 32
  %2044 = insertelement <8 x i32> %2043, i32 %2042, i32 %2035
  store <8 x i32> %2044, ptr %frame.static.id, align 32
  %2045 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2046 = extractelement <8 x i32> %2045, i32 %2035
  %2047 = select i1 %2028, i32 %2013, i32 %2046
  %2048 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2049 = insertelement <8 x i32> %2048, i32 %2047, i32 %2035
  store <8 x i32> %2049, ptr %frame.parent.token, align 32
  %2050 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2035
  %2051 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2035
  %2052 = load <8 x i1>, ptr %2050, align 1
  %2053 = load <8 x i1>, ptr %2051, align 1
  %2054 = select i1 %2028, <8 x i1> %convergence.cascade.result430, <8 x i1> %2052
  store <8 x i1> %2054, ptr %2050, align 1
  %2055 = select i1 %2028, <8 x i1> zeroinitializer, <8 x i1> %2053
  store <8 x i1> %2055, ptr %2051, align 1
  %2056 = add i32 %2035, 1
  %2057 = select i1 %2026, i32 %2013, i32 %2056
  %2058 = select i1 true, i32 %2057, i32 %2013
  store i32 %2058, ptr %current.token, align 4
  %2059 = load <8 x float>, ptr %.slot70, align 32
  %2060 = select <8 x i1> %2009, <8 x float> zeroinitializer, <8 x float> %2059
  store <8 x float> %2060, ptr %.slot70, align 32
  %2061 = load i32, ptr %current.token, align 4
  %2062 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2007)
  %2063 = load i32, ptr %ready.count, align 4
  %2064 = icmp uge i32 %2063, 8
  %2065 = and i1 %2062, %2064
  br i1 %2065, label %ready.overflow.trap440, label %ready.overflow.resume441

ready.overflow.trap440:                           ; preds = %convergence.overflow.resume439
  call void @llvm.trap()
  unreachable

ready.overflow.resume441:                         ; preds = %convergence.overflow.resume439
  %2066 = select i1 %2062, i32 %2063, i32 0
  %2067 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2066
  %2068 = load <8 x i1>, ptr %2067, align 1
  %2069 = select i1 %2062, <8 x i1> %2007, <8 x i1> %2068
  store <8 x i1> %2069, ptr %2067, align 1
  %2070 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2066
  %2071 = load i32, ptr %2070, align 4
  %2072 = select i1 %2062, i32 21, i32 %2071
  store i32 %2072, ptr %2070, align 4
  %2073 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2066
  %2074 = load i32, ptr %2073, align 4
  %2075 = select i1 %2062, i32 %2061, i32 %2074
  store i32 %2075, ptr %2073, align 4
  %2076 = add i32 %2063, 1
  %2077 = select i1 %2062, i32 %2076, i32 %2063
  store i32 %2077, ptr %ready.count, align 4
  %2078 = load <8 x i1>, ptr %runnable.mask, align 1
  %2079 = or <8 x i1> %2078, %2007
  store <8 x i1> %2079, ptr %runnable.mask, align 1
  store <8 x i1> %2009, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true442:                         ; preds = %varying.coherent437
  store <8 x i1> %convergence.cascade.result430, ptr %current.mask, align 1
  %2080 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result430)
  br i1 %2080, label %schedule.21, label %scheduler.loop

varying.coherent.false443:                        ; preds = %varying.coherent437
  %2081 = load <8 x float>, ptr %.slot70, align 32
  %2082 = select <8 x i1> %convergence.cascade.result430, <8 x float> zeroinitializer, <8 x float> %2081
  store <8 x float> %2082, ptr %.slot70, align 32
  store <8 x i1> %convergence.cascade.result430, ptr %current.mask, align 1
  %2083 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result430)
  br i1 %2083, label %schedule.22, label %scheduler.loop

convergence.cascade445:                           ; preds = %convergence.cascade445, %schedule.22
  %convergence.cascade.flow449 = phi <8 x i1> [ %452, %schedule.22 ], [ %2126, %convergence.cascade445 ]
  %convergence.cascade.depth450 = phi i32 [ 0, %schedule.22 ], [ %2127, %convergence.cascade445 ]
  %2084 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow449)
  %2085 = load i32, ptr %current.token, align 4
  %2086 = icmp ne i32 %2085, 0
  %2087 = and i1 %2084, %2086
  %2088 = sub i32 %2085, 1
  %2089 = select i1 %2087, i32 %2088, i32 0
  %2090 = load i8, ptr %frame.active, align 1
  %2091 = trunc i32 %2089 to i8
  %2092 = shl i8 1, %2091
  %2093 = and i8 %2090, %2092
  %2094 = icmp ne i8 %2093, 0
  %2095 = load <8 x i32>, ptr %frame.static.id, align 32
  %2096 = extractelement <8 x i32> %2095, i32 %2089
  %convergence.target.pointer451 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %2096
  %convergence.dynamic.target452 = load i32, ptr %convergence.target.pointer451, align 4
  %2097 = icmp eq i32 %convergence.dynamic.target452, 22
  %2098 = and i1 %2094, %2097
  %2099 = and i1 %2087, %2098
  %2100 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2089
  %2101 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2089
  %2102 = load <8 x i1>, ptr %2100, align 1
  %2103 = load <8 x i1>, ptr %2101, align 1
  %2104 = or <8 x i1> %2103, %convergence.cascade.flow449
  %2105 = load <8 x i1>, ptr %live.mask, align 1
  %2106 = and <8 x i1> %2102, %2105
  %2107 = icmp eq <8 x i1> %2104, %2106
  %2108 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2107)
  %2109 = and i1 %2099, %2108
  %2110 = select i1 %2109, <8 x i1> zeroinitializer, <8 x i1> %2104
  %2111 = select i1 %2099, <8 x i1> %2110, <8 x i1> %2103
  store <8 x i1> %2111, ptr %2101, align 1
  %2112 = select i1 %2109, <8 x i1> zeroinitializer, <8 x i1> %2102
  store <8 x i1> %2112, ptr %2100, align 1
  %2113 = trunc i32 %2089 to i8
  %2114 = shl i8 1, %2113
  %2115 = xor i8 %2114, -1
  %2116 = and i8 %2090, %2115
  %2117 = select i1 %2109, i8 %2116, i8 %2090
  store i8 %2117, ptr %frame.active, align 1
  %.splatinsert453 = insertelement <8 x i1> poison, i1 %2099, i64 0
  %.splat454 = shufflevector <8 x i1> %.splatinsert453, <8 x i1> poison, <8 x i32> zeroinitializer
  %2118 = and <8 x i1> %convergence.cascade.flow449, %.splat454
  %2119 = load <8 x i1>, ptr %runnable.mask, align 1
  %2120 = xor <8 x i1> %2118, splat (i1 true)
  %2121 = and <8 x i1> %2119, %2120
  store <8 x i1> %2121, ptr %runnable.mask, align 1
  %.splatinsert455 = insertelement <8 x i1> poison, i1 %2109, i64 0
  %.splat456 = shufflevector <8 x i1> %.splatinsert455, <8 x i1> poison, <8 x i32> zeroinitializer
  %2122 = select <8 x i1> %.splat456, <8 x i1> %2104, <8 x i1> zeroinitializer
  %2123 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2124 = extractelement <8 x i32> %2123, i32 %2089
  %2125 = select i1 %2109, i32 %2124, i32 %2085
  store i32 %2125, ptr %current.token, align 4
  %.splatinsert457 = insertelement <8 x i1> poison, i1 %2099, i64 0
  %.splat458 = shufflevector <8 x i1> %.splatinsert457, <8 x i1> poison, <8 x i32> zeroinitializer
  %2126 = select <8 x i1> %.splat458, <8 x i1> %2122, <8 x i1> %convergence.cascade.flow449
  %2127 = add i32 %convergence.cascade.depth450, 1
  %2128 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2126)
  %2129 = icmp ult i32 %2127, 8
  %2130 = and i1 %2128, %2129
  %2131 = and i1 %2099, %2130
  %convergence.parent.token459 = load i32, ptr %current.token, align 4
  %convergence.parent.present460 = icmp ne i32 %convergence.parent.token459, 0
  %2132 = and i1 %2131, %convergence.parent.present460
  br i1 %2132, label %convergence.cascade445, label %convergence.cascade.exit446

convergence.cascade.exit446:                      ; preds = %convergence.cascade445, %schedule.22
  %convergence.cascade.result461 = phi <8 x i1> [ %452, %schedule.22 ], [ %2126, %convergence.cascade445 ]
  %2133 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result461)
  br i1 %2133, label %convergence.target.22.ready, label %scheduler.loop

convergence.target.22.ready:                      ; preds = %convergence.cascade.exit446
  %2134 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result461)
  %2135 = bitcast <8 x i1> %convergence.cascade.result461 to i8
  %2136 = call i8 @llvm.cttz.i8(i8 %2135, i1 false)
  %2137 = zext i8 %2136 to i32
  %2138 = select i1 %2134, i32 %2137, i32 0
  %.spill.load462 = load volatile <8 x i64>, ptr %.spill43, align 64
  %2139 = mul <8 x i64> %.spill.load462, splat (i64 3)
  %.spill.load463 = load i64, ptr %.spill4, align 4
  %.splatinsert464 = insertelement <8 x i64> poison, i64 %.spill.load463, i64 0
  %.splat465 = shufflevector <8 x i64> %.splatinsert464, <8 x i64> poison, <8 x i32> zeroinitializer
  %2140 = add <8 x i64> %2139, %.splat465
  %2141 = extractvalue { ptr, i64 } %21, 0
  %2142 = mul <8 x i64> %2140, splat (i64 4)
  %2143 = getelementptr i8, ptr %2141, <8 x i64> %2142
  %2144 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2143, <8 x i1> %convergence.cascade.result461, <8 x float> zeroinitializer)
  %2145 = load volatile <8 x float>, ptr %.spill71, align 32
  %2146 = select <8 x i1> %convergence.cascade.result461, <8 x float> %2144, <8 x float> %2145
  store volatile <8 x float> %2146, ptr %.spill71, align 32
  %.spill.load466 = load i64, ptr %.spill10, align 4
  %.splatinsert467 = insertelement <8 x i64> poison, i64 %.spill.load466, i64 0
  %.splat468 = shufflevector <8 x i64> %.splatinsert467, <8 x i64> poison, <8 x i32> zeroinitializer
  %2147 = add <8 x i64> %2139, %.splat468
  %2148 = extractvalue { ptr, i64 } %21, 0
  %2149 = mul <8 x i64> %2147, splat (i64 4)
  %2150 = getelementptr i8, ptr %2148, <8 x i64> %2149
  %2151 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2150, <8 x i1> %convergence.cascade.result461, <8 x float> zeroinitializer)
  %2152 = load volatile <8 x float>, ptr %.spill72, align 32
  %2153 = select <8 x i1> %convergence.cascade.result461, <8 x float> %2151, <8 x float> %2152
  store volatile <8 x float> %2153, ptr %.spill72, align 32
  %.spill.load469 = load i64, ptr %.spill12, align 4
  %.splatinsert470 = insertelement <8 x i64> poison, i64 %.spill.load469, i64 0
  %.splat471 = shufflevector <8 x i64> %.splatinsert470, <8 x i64> poison, <8 x i32> zeroinitializer
  %2154 = add <8 x i64> %2139, %.splat471
  %2155 = extractvalue { ptr, i64 } %21, 0
  %2156 = mul <8 x i64> %2154, splat (i64 4)
  %2157 = getelementptr i8, ptr %2155, <8 x i64> %2156
  %2158 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2157, <8 x i1> %convergence.cascade.result461, <8 x float> zeroinitializer)
  %2159 = load volatile <8 x float>, ptr %.spill73, align 32
  %2160 = select <8 x i1> %convergence.cascade.result461, <8 x float> %2158, <8 x float> %2159
  store volatile <8 x float> %2160, ptr %.spill73, align 32
  %.spill.load472 = load volatile <8 x i64>, ptr %.spill50, align 64
  %2161 = mul <8 x i64> %.spill.load472, splat (i64 3)
  %.spill.load473 = load i64, ptr %.spill4, align 4
  %.splatinsert474 = insertelement <8 x i64> poison, i64 %.spill.load473, i64 0
  %.splat475 = shufflevector <8 x i64> %.splatinsert474, <8 x i64> poison, <8 x i32> zeroinitializer
  %2162 = add <8 x i64> %2161, %.splat475
  %2163 = extractvalue { ptr, i64 } %21, 0
  %2164 = mul <8 x i64> %2162, splat (i64 4)
  %2165 = getelementptr i8, ptr %2163, <8 x i64> %2164
  %2166 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2165, <8 x i1> %convergence.cascade.result461, <8 x float> zeroinitializer)
  %2167 = load volatile <8 x float>, ptr %.spill74, align 32
  %2168 = select <8 x i1> %convergence.cascade.result461, <8 x float> %2166, <8 x float> %2167
  store volatile <8 x float> %2168, ptr %.spill74, align 32
  %.spill.load476 = load i64, ptr %.spill10, align 4
  %.splatinsert477 = insertelement <8 x i64> poison, i64 %.spill.load476, i64 0
  %.splat478 = shufflevector <8 x i64> %.splatinsert477, <8 x i64> poison, <8 x i32> zeroinitializer
  %2169 = add <8 x i64> %2161, %.splat478
  %2170 = extractvalue { ptr, i64 } %21, 0
  %2171 = mul <8 x i64> %2169, splat (i64 4)
  %2172 = getelementptr i8, ptr %2170, <8 x i64> %2171
  %2173 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2172, <8 x i1> %convergence.cascade.result461, <8 x float> zeroinitializer)
  %2174 = load volatile <8 x float>, ptr %.spill75, align 32
  %2175 = select <8 x i1> %convergence.cascade.result461, <8 x float> %2173, <8 x float> %2174
  store volatile <8 x float> %2175, ptr %.spill75, align 32
  %.spill.load479 = load i64, ptr %.spill12, align 4
  %.splatinsert480 = insertelement <8 x i64> poison, i64 %.spill.load479, i64 0
  %.splat481 = shufflevector <8 x i64> %.splatinsert480, <8 x i64> poison, <8 x i32> zeroinitializer
  %2176 = add <8 x i64> %2161, %.splat481
  %2177 = extractvalue { ptr, i64 } %21, 0
  %2178 = mul <8 x i64> %2176, splat (i64 4)
  %2179 = getelementptr i8, ptr %2177, <8 x i64> %2178
  %2180 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2179, <8 x i1> %convergence.cascade.result461, <8 x float> zeroinitializer)
  %2181 = load volatile <8 x float>, ptr %.spill76, align 32
  %2182 = select <8 x i1> %convergence.cascade.result461, <8 x float> %2180, <8 x float> %2181
  store volatile <8 x float> %2182, ptr %.spill76, align 32
  %.spill.load482 = load volatile <8 x i64>, ptr %.spill57, align 64
  %2183 = mul <8 x i64> %.spill.load482, splat (i64 3)
  %2184 = load volatile <8 x i64>, ptr %.spill77, align 64
  %2185 = select <8 x i1> %convergence.cascade.result461, <8 x i64> %2183, <8 x i64> %2184
  store volatile <8 x i64> %2185, ptr %.spill77, align 64
  %.spill.load483 = load i64, ptr %.spill4, align 4
  %.splatinsert484 = insertelement <8 x i64> poison, i64 %.spill.load483, i64 0
  %.splat485 = shufflevector <8 x i64> %.splatinsert484, <8 x i64> poison, <8 x i32> zeroinitializer
  %2186 = add <8 x i64> %2183, %.splat485
  %2187 = load volatile <8 x i64>, ptr %.spill78, align 64
  %2188 = select <8 x i1> %convergence.cascade.result461, <8 x i64> %2186, <8 x i64> %2187
  store volatile <8 x i64> %2188, ptr %.spill78, align 64
  %.spill.load486 = load <8 x i1>, ptr %.spill59, align 1
  %2189 = and <8 x i1> %convergence.cascade.result461, %.spill.load486
  %2190 = xor <8 x i1> %.spill.load486, splat (i1 true)
  %2191 = and <8 x i1> %convergence.cascade.result461, %2190
  %2192 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2189)
  %2193 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2191)
  %2194 = and i1 %2192, %2193
  br i1 %2194, label %varying.divergent487, label %varying.coherent488

varying.divergent487:                             ; preds = %convergence.target.22.ready
  %2195 = load i32, ptr %current.token, align 4
  %2196 = icmp ne i32 %2195, 0
  %2197 = sub i32 %2195, 1
  %2198 = select i1 %2196, i32 %2197, i32 0
  %2199 = load i8, ptr %frame.active, align 1
  %2200 = trunc i32 %2198 to i8
  %2201 = shl i8 1, %2200
  %2202 = and i8 %2199, %2201
  %2203 = icmp ne i8 %2202, 0
  %2204 = load <8 x i32>, ptr %frame.static.id, align 32
  %2205 = extractelement <8 x i32> %2204, i32 %2198
  %2206 = icmp eq i32 %2205, 11
  %2207 = and i1 %2203, %2206
  %2208 = and i1 %2196, %2207
  %2209 = xor i1 %2208, true
  %2210 = and i1 true, %2209
  %2211 = xor i8 %2199, -1
  %2212 = icmp ne i8 %2211, 0
  %2213 = xor i1 %2212, true
  %2214 = and i1 %2210, %2213
  br i1 %2214, label %convergence.overflow.trap489, label %convergence.overflow.resume490

varying.coherent488:                              ; preds = %convergence.target.22.ready
  br i1 %2192, label %varying.coherent.true493, label %varying.coherent.false494

convergence.overflow.trap489:                     ; preds = %varying.divergent487
  call void @llvm.trap()
  unreachable

convergence.overflow.resume490:                   ; preds = %varying.divergent487
  %2215 = call i8 @llvm.cttz.i8(i8 %2211, i1 false)
  %2216 = zext i8 %2215 to i32
  %2217 = select i1 %2212, i32 %2216, i32 0
  %2218 = trunc i32 %2217 to i8
  %2219 = shl i8 1, %2218
  %2220 = or i8 %2199, %2219
  %2221 = select i1 %2210, i8 %2220, i8 %2199
  store i8 %2221, ptr %frame.active, align 1
  %2222 = load <8 x i32>, ptr %frame.static.id, align 32
  %2223 = extractelement <8 x i32> %2222, i32 %2217
  %2224 = select i1 %2210, i32 11, i32 %2223
  %2225 = load <8 x i32>, ptr %frame.static.id, align 32
  %2226 = insertelement <8 x i32> %2225, i32 %2224, i32 %2217
  store <8 x i32> %2226, ptr %frame.static.id, align 32
  %2227 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2228 = extractelement <8 x i32> %2227, i32 %2217
  %2229 = select i1 %2210, i32 %2195, i32 %2228
  %2230 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2231 = insertelement <8 x i32> %2230, i32 %2229, i32 %2217
  store <8 x i32> %2231, ptr %frame.parent.token, align 32
  %2232 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2217
  %2233 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2217
  %2234 = load <8 x i1>, ptr %2232, align 1
  %2235 = load <8 x i1>, ptr %2233, align 1
  %2236 = select i1 %2210, <8 x i1> %convergence.cascade.result461, <8 x i1> %2234
  store <8 x i1> %2236, ptr %2232, align 1
  %2237 = select i1 %2210, <8 x i1> zeroinitializer, <8 x i1> %2235
  store <8 x i1> %2237, ptr %2233, align 1
  %2238 = add i32 %2217, 1
  %2239 = select i1 %2208, i32 %2195, i32 %2238
  %2240 = select i1 true, i32 %2239, i32 %2195
  store i32 %2240, ptr %current.token, align 4
  %2241 = load <8 x float>, ptr %.slot79, align 32
  %2242 = select <8 x i1> %2191, <8 x float> zeroinitializer, <8 x float> %2241
  store <8 x float> %2242, ptr %.slot79, align 32
  %2243 = load i32, ptr %current.token, align 4
  %2244 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2189)
  %2245 = load i32, ptr %ready.count, align 4
  %2246 = icmp uge i32 %2245, 8
  %2247 = and i1 %2244, %2246
  br i1 %2247, label %ready.overflow.trap491, label %ready.overflow.resume492

ready.overflow.trap491:                           ; preds = %convergence.overflow.resume490
  call void @llvm.trap()
  unreachable

ready.overflow.resume492:                         ; preds = %convergence.overflow.resume490
  %2248 = select i1 %2244, i32 %2245, i32 0
  %2249 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2248
  %2250 = load <8 x i1>, ptr %2249, align 1
  %2251 = select i1 %2244, <8 x i1> %2189, <8 x i1> %2250
  store <8 x i1> %2251, ptr %2249, align 1
  %2252 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2248
  %2253 = load i32, ptr %2252, align 4
  %2254 = select i1 %2244, i32 23, i32 %2253
  store i32 %2254, ptr %2252, align 4
  %2255 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2248
  %2256 = load i32, ptr %2255, align 4
  %2257 = select i1 %2244, i32 %2243, i32 %2256
  store i32 %2257, ptr %2255, align 4
  %2258 = add i32 %2245, 1
  %2259 = select i1 %2244, i32 %2258, i32 %2245
  store i32 %2259, ptr %ready.count, align 4
  %2260 = load <8 x i1>, ptr %runnable.mask, align 1
  %2261 = or <8 x i1> %2260, %2189
  store <8 x i1> %2261, ptr %runnable.mask, align 1
  store <8 x i1> %2191, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true493:                         ; preds = %varying.coherent488
  store <8 x i1> %convergence.cascade.result461, ptr %current.mask, align 1
  %2262 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result461)
  br i1 %2262, label %schedule.23, label %scheduler.loop

varying.coherent.false494:                        ; preds = %varying.coherent488
  %2263 = load <8 x float>, ptr %.slot79, align 32
  %2264 = select <8 x i1> %convergence.cascade.result461, <8 x float> zeroinitializer, <8 x float> %2263
  store <8 x float> %2264, ptr %.slot79, align 32
  store <8 x i1> %convergence.cascade.result461, ptr %current.mask, align 1
  %2265 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result461)
  br i1 %2265, label %schedule.24, label %scheduler.loop

convergence.cascade496:                           ; preds = %convergence.cascade496, %schedule.24
  %convergence.cascade.flow500 = phi <8 x i1> [ %466, %schedule.24 ], [ %2308, %convergence.cascade496 ]
  %convergence.cascade.depth501 = phi i32 [ 0, %schedule.24 ], [ %2309, %convergence.cascade496 ]
  %2266 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow500)
  %2267 = load i32, ptr %current.token, align 4
  %2268 = icmp ne i32 %2267, 0
  %2269 = and i1 %2266, %2268
  %2270 = sub i32 %2267, 1
  %2271 = select i1 %2269, i32 %2270, i32 0
  %2272 = load i8, ptr %frame.active, align 1
  %2273 = trunc i32 %2271 to i8
  %2274 = shl i8 1, %2273
  %2275 = and i8 %2272, %2274
  %2276 = icmp ne i8 %2275, 0
  %2277 = load <8 x i32>, ptr %frame.static.id, align 32
  %2278 = extractelement <8 x i32> %2277, i32 %2271
  %convergence.target.pointer502 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %2278
  %convergence.dynamic.target503 = load i32, ptr %convergence.target.pointer502, align 4
  %2279 = icmp eq i32 %convergence.dynamic.target503, 24
  %2280 = and i1 %2276, %2279
  %2281 = and i1 %2269, %2280
  %2282 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2271
  %2283 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2271
  %2284 = load <8 x i1>, ptr %2282, align 1
  %2285 = load <8 x i1>, ptr %2283, align 1
  %2286 = or <8 x i1> %2285, %convergence.cascade.flow500
  %2287 = load <8 x i1>, ptr %live.mask, align 1
  %2288 = and <8 x i1> %2284, %2287
  %2289 = icmp eq <8 x i1> %2286, %2288
  %2290 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2289)
  %2291 = and i1 %2281, %2290
  %2292 = select i1 %2291, <8 x i1> zeroinitializer, <8 x i1> %2286
  %2293 = select i1 %2281, <8 x i1> %2292, <8 x i1> %2285
  store <8 x i1> %2293, ptr %2283, align 1
  %2294 = select i1 %2291, <8 x i1> zeroinitializer, <8 x i1> %2284
  store <8 x i1> %2294, ptr %2282, align 1
  %2295 = trunc i32 %2271 to i8
  %2296 = shl i8 1, %2295
  %2297 = xor i8 %2296, -1
  %2298 = and i8 %2272, %2297
  %2299 = select i1 %2291, i8 %2298, i8 %2272
  store i8 %2299, ptr %frame.active, align 1
  %.splatinsert504 = insertelement <8 x i1> poison, i1 %2281, i64 0
  %.splat505 = shufflevector <8 x i1> %.splatinsert504, <8 x i1> poison, <8 x i32> zeroinitializer
  %2300 = and <8 x i1> %convergence.cascade.flow500, %.splat505
  %2301 = load <8 x i1>, ptr %runnable.mask, align 1
  %2302 = xor <8 x i1> %2300, splat (i1 true)
  %2303 = and <8 x i1> %2301, %2302
  store <8 x i1> %2303, ptr %runnable.mask, align 1
  %.splatinsert506 = insertelement <8 x i1> poison, i1 %2291, i64 0
  %.splat507 = shufflevector <8 x i1> %.splatinsert506, <8 x i1> poison, <8 x i32> zeroinitializer
  %2304 = select <8 x i1> %.splat507, <8 x i1> %2286, <8 x i1> zeroinitializer
  %2305 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2306 = extractelement <8 x i32> %2305, i32 %2271
  %2307 = select i1 %2291, i32 %2306, i32 %2267
  store i32 %2307, ptr %current.token, align 4
  %.splatinsert508 = insertelement <8 x i1> poison, i1 %2281, i64 0
  %.splat509 = shufflevector <8 x i1> %.splatinsert508, <8 x i1> poison, <8 x i32> zeroinitializer
  %2308 = select <8 x i1> %.splat509, <8 x i1> %2304, <8 x i1> %convergence.cascade.flow500
  %2309 = add i32 %convergence.cascade.depth501, 1
  %2310 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2308)
  %2311 = icmp ult i32 %2309, 8
  %2312 = and i1 %2310, %2311
  %2313 = and i1 %2281, %2312
  %convergence.parent.token510 = load i32, ptr %current.token, align 4
  %convergence.parent.present511 = icmp ne i32 %convergence.parent.token510, 0
  %2314 = and i1 %2313, %convergence.parent.present511
  br i1 %2314, label %convergence.cascade496, label %convergence.cascade.exit497

convergence.cascade.exit497:                      ; preds = %convergence.cascade496, %schedule.24
  %convergence.cascade.result512 = phi <8 x i1> [ %466, %schedule.24 ], [ %2308, %convergence.cascade496 ]
  %2315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result512)
  br i1 %2315, label %convergence.target.24.ready, label %scheduler.loop

convergence.target.24.ready:                      ; preds = %convergence.cascade.exit497
  %2316 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result512)
  %2317 = bitcast <8 x i1> %convergence.cascade.result512 to i8
  %2318 = call i8 @llvm.cttz.i8(i8 %2317, i1 false)
  %2319 = zext i8 %2318 to i32
  %2320 = select i1 %2316, i32 %2319, i32 0
  %.spill.load513 = load volatile <8 x i64>, ptr %.spill77, align 64
  %.spill.load514 = load i64, ptr %.spill10, align 4
  %.splatinsert515 = insertelement <8 x i64> poison, i64 %.spill.load514, i64 0
  %.splat516 = shufflevector <8 x i64> %.splatinsert515, <8 x i64> poison, <8 x i32> zeroinitializer
  %2321 = add <8 x i64> %.spill.load513, %.splat516
  %2322 = load volatile <8 x i64>, ptr %.spill80, align 64
  %2323 = select <8 x i1> %convergence.cascade.result512, <8 x i64> %2321, <8 x i64> %2322
  store volatile <8 x i64> %2323, ptr %.spill80, align 64
  %.spill.load517 = load <8 x i1>, ptr %.spill59, align 1
  %2324 = and <8 x i1> %convergence.cascade.result512, %.spill.load517
  %2325 = xor <8 x i1> %.spill.load517, splat (i1 true)
  %2326 = and <8 x i1> %convergence.cascade.result512, %2325
  %2327 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2324)
  %2328 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2326)
  %2329 = and i1 %2327, %2328
  br i1 %2329, label %varying.divergent518, label %varying.coherent519

varying.divergent518:                             ; preds = %convergence.target.24.ready
  %2330 = load i32, ptr %current.token, align 4
  %2331 = icmp ne i32 %2330, 0
  %2332 = sub i32 %2330, 1
  %2333 = select i1 %2331, i32 %2332, i32 0
  %2334 = load i8, ptr %frame.active, align 1
  %2335 = trunc i32 %2333 to i8
  %2336 = shl i8 1, %2335
  %2337 = and i8 %2334, %2336
  %2338 = icmp ne i8 %2337, 0
  %2339 = load <8 x i32>, ptr %frame.static.id, align 32
  %2340 = extractelement <8 x i32> %2339, i32 %2333
  %2341 = icmp eq i32 %2340, 12
  %2342 = and i1 %2338, %2341
  %2343 = and i1 %2331, %2342
  %2344 = xor i1 %2343, true
  %2345 = and i1 true, %2344
  %2346 = xor i8 %2334, -1
  %2347 = icmp ne i8 %2346, 0
  %2348 = xor i1 %2347, true
  %2349 = and i1 %2345, %2348
  br i1 %2349, label %convergence.overflow.trap520, label %convergence.overflow.resume521

varying.coherent519:                              ; preds = %convergence.target.24.ready
  br i1 %2327, label %varying.coherent.true524, label %varying.coherent.false525

convergence.overflow.trap520:                     ; preds = %varying.divergent518
  call void @llvm.trap()
  unreachable

convergence.overflow.resume521:                   ; preds = %varying.divergent518
  %2350 = call i8 @llvm.cttz.i8(i8 %2346, i1 false)
  %2351 = zext i8 %2350 to i32
  %2352 = select i1 %2347, i32 %2351, i32 0
  %2353 = trunc i32 %2352 to i8
  %2354 = shl i8 1, %2353
  %2355 = or i8 %2334, %2354
  %2356 = select i1 %2345, i8 %2355, i8 %2334
  store i8 %2356, ptr %frame.active, align 1
  %2357 = load <8 x i32>, ptr %frame.static.id, align 32
  %2358 = extractelement <8 x i32> %2357, i32 %2352
  %2359 = select i1 %2345, i32 12, i32 %2358
  %2360 = load <8 x i32>, ptr %frame.static.id, align 32
  %2361 = insertelement <8 x i32> %2360, i32 %2359, i32 %2352
  store <8 x i32> %2361, ptr %frame.static.id, align 32
  %2362 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2363 = extractelement <8 x i32> %2362, i32 %2352
  %2364 = select i1 %2345, i32 %2330, i32 %2363
  %2365 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2366 = insertelement <8 x i32> %2365, i32 %2364, i32 %2352
  store <8 x i32> %2366, ptr %frame.parent.token, align 32
  %2367 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2352
  %2368 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2352
  %2369 = load <8 x i1>, ptr %2367, align 1
  %2370 = load <8 x i1>, ptr %2368, align 1
  %2371 = select i1 %2345, <8 x i1> %convergence.cascade.result512, <8 x i1> %2369
  store <8 x i1> %2371, ptr %2367, align 1
  %2372 = select i1 %2345, <8 x i1> zeroinitializer, <8 x i1> %2370
  store <8 x i1> %2372, ptr %2368, align 1
  %2373 = add i32 %2352, 1
  %2374 = select i1 %2343, i32 %2330, i32 %2373
  %2375 = select i1 true, i32 %2374, i32 %2330
  store i32 %2375, ptr %current.token, align 4
  %2376 = load <8 x float>, ptr %.slot81, align 32
  %2377 = select <8 x i1> %2326, <8 x float> zeroinitializer, <8 x float> %2376
  store <8 x float> %2377, ptr %.slot81, align 32
  %2378 = load i32, ptr %current.token, align 4
  %2379 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2324)
  %2380 = load i32, ptr %ready.count, align 4
  %2381 = icmp uge i32 %2380, 8
  %2382 = and i1 %2379, %2381
  br i1 %2382, label %ready.overflow.trap522, label %ready.overflow.resume523

ready.overflow.trap522:                           ; preds = %convergence.overflow.resume521
  call void @llvm.trap()
  unreachable

ready.overflow.resume523:                         ; preds = %convergence.overflow.resume521
  %2383 = select i1 %2379, i32 %2380, i32 0
  %2384 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2383
  %2385 = load <8 x i1>, ptr %2384, align 1
  %2386 = select i1 %2379, <8 x i1> %2324, <8 x i1> %2385
  store <8 x i1> %2386, ptr %2384, align 1
  %2387 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2383
  %2388 = load i32, ptr %2387, align 4
  %2389 = select i1 %2379, i32 25, i32 %2388
  store i32 %2389, ptr %2387, align 4
  %2390 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2383
  %2391 = load i32, ptr %2390, align 4
  %2392 = select i1 %2379, i32 %2378, i32 %2391
  store i32 %2392, ptr %2390, align 4
  %2393 = add i32 %2380, 1
  %2394 = select i1 %2379, i32 %2393, i32 %2380
  store i32 %2394, ptr %ready.count, align 4
  %2395 = load <8 x i1>, ptr %runnable.mask, align 1
  %2396 = or <8 x i1> %2395, %2324
  store <8 x i1> %2396, ptr %runnable.mask, align 1
  store <8 x i1> %2326, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true524:                         ; preds = %varying.coherent519
  store <8 x i1> %convergence.cascade.result512, ptr %current.mask, align 1
  %2397 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result512)
  br i1 %2397, label %schedule.25, label %scheduler.loop

varying.coherent.false525:                        ; preds = %varying.coherent519
  %2398 = load <8 x float>, ptr %.slot81, align 32
  %2399 = select <8 x i1> %convergence.cascade.result512, <8 x float> zeroinitializer, <8 x float> %2398
  store <8 x float> %2399, ptr %.slot81, align 32
  store <8 x i1> %convergence.cascade.result512, ptr %current.mask, align 1
  %2400 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result512)
  br i1 %2400, label %schedule.26, label %scheduler.loop

convergence.cascade527:                           ; preds = %convergence.cascade527, %schedule.26
  %convergence.cascade.flow531 = phi <8 x i1> [ %480, %schedule.26 ], [ %2443, %convergence.cascade527 ]
  %convergence.cascade.depth532 = phi i32 [ 0, %schedule.26 ], [ %2444, %convergence.cascade527 ]
  %2401 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow531)
  %2402 = load i32, ptr %current.token, align 4
  %2403 = icmp ne i32 %2402, 0
  %2404 = and i1 %2401, %2403
  %2405 = sub i32 %2402, 1
  %2406 = select i1 %2404, i32 %2405, i32 0
  %2407 = load i8, ptr %frame.active, align 1
  %2408 = trunc i32 %2406 to i8
  %2409 = shl i8 1, %2408
  %2410 = and i8 %2407, %2409
  %2411 = icmp ne i8 %2410, 0
  %2412 = load <8 x i32>, ptr %frame.static.id, align 32
  %2413 = extractelement <8 x i32> %2412, i32 %2406
  %convergence.target.pointer533 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %2413
  %convergence.dynamic.target534 = load i32, ptr %convergence.target.pointer533, align 4
  %2414 = icmp eq i32 %convergence.dynamic.target534, 26
  %2415 = and i1 %2411, %2414
  %2416 = and i1 %2404, %2415
  %2417 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2406
  %2418 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2406
  %2419 = load <8 x i1>, ptr %2417, align 1
  %2420 = load <8 x i1>, ptr %2418, align 1
  %2421 = or <8 x i1> %2420, %convergence.cascade.flow531
  %2422 = load <8 x i1>, ptr %live.mask, align 1
  %2423 = and <8 x i1> %2419, %2422
  %2424 = icmp eq <8 x i1> %2421, %2423
  %2425 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2424)
  %2426 = and i1 %2416, %2425
  %2427 = select i1 %2426, <8 x i1> zeroinitializer, <8 x i1> %2421
  %2428 = select i1 %2416, <8 x i1> %2427, <8 x i1> %2420
  store <8 x i1> %2428, ptr %2418, align 1
  %2429 = select i1 %2426, <8 x i1> zeroinitializer, <8 x i1> %2419
  store <8 x i1> %2429, ptr %2417, align 1
  %2430 = trunc i32 %2406 to i8
  %2431 = shl i8 1, %2430
  %2432 = xor i8 %2431, -1
  %2433 = and i8 %2407, %2432
  %2434 = select i1 %2426, i8 %2433, i8 %2407
  store i8 %2434, ptr %frame.active, align 1
  %.splatinsert535 = insertelement <8 x i1> poison, i1 %2416, i64 0
  %.splat536 = shufflevector <8 x i1> %.splatinsert535, <8 x i1> poison, <8 x i32> zeroinitializer
  %2435 = and <8 x i1> %convergence.cascade.flow531, %.splat536
  %2436 = load <8 x i1>, ptr %runnable.mask, align 1
  %2437 = xor <8 x i1> %2435, splat (i1 true)
  %2438 = and <8 x i1> %2436, %2437
  store <8 x i1> %2438, ptr %runnable.mask, align 1
  %.splatinsert537 = insertelement <8 x i1> poison, i1 %2426, i64 0
  %.splat538 = shufflevector <8 x i1> %.splatinsert537, <8 x i1> poison, <8 x i32> zeroinitializer
  %2439 = select <8 x i1> %.splat538, <8 x i1> %2421, <8 x i1> zeroinitializer
  %2440 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2441 = extractelement <8 x i32> %2440, i32 %2406
  %2442 = select i1 %2426, i32 %2441, i32 %2402
  store i32 %2442, ptr %current.token, align 4
  %.splatinsert539 = insertelement <8 x i1> poison, i1 %2416, i64 0
  %.splat540 = shufflevector <8 x i1> %.splatinsert539, <8 x i1> poison, <8 x i32> zeroinitializer
  %2443 = select <8 x i1> %.splat540, <8 x i1> %2439, <8 x i1> %convergence.cascade.flow531
  %2444 = add i32 %convergence.cascade.depth532, 1
  %2445 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2443)
  %2446 = icmp ult i32 %2444, 8
  %2447 = and i1 %2445, %2446
  %2448 = and i1 %2416, %2447
  %convergence.parent.token541 = load i32, ptr %current.token, align 4
  %convergence.parent.present542 = icmp ne i32 %convergence.parent.token541, 0
  %2449 = and i1 %2448, %convergence.parent.present542
  br i1 %2449, label %convergence.cascade527, label %convergence.cascade.exit528

convergence.cascade.exit528:                      ; preds = %convergence.cascade527, %schedule.26
  %convergence.cascade.result543 = phi <8 x i1> [ %480, %schedule.26 ], [ %2443, %convergence.cascade527 ]
  %2450 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result543)
  br i1 %2450, label %convergence.target.26.ready, label %scheduler.loop

convergence.target.26.ready:                      ; preds = %convergence.cascade.exit528
  %2451 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result543)
  %2452 = bitcast <8 x i1> %convergence.cascade.result543 to i8
  %2453 = call i8 @llvm.cttz.i8(i8 %2452, i1 false)
  %2454 = zext i8 %2453 to i32
  %2455 = select i1 %2451, i32 %2454, i32 0
  %.spill.load544 = load volatile <8 x i64>, ptr %.spill77, align 64
  %.spill.load545 = load i64, ptr %.spill12, align 4
  %.splatinsert546 = insertelement <8 x i64> poison, i64 %.spill.load545, i64 0
  %.splat547 = shufflevector <8 x i64> %.splatinsert546, <8 x i64> poison, <8 x i32> zeroinitializer
  %2456 = add <8 x i64> %.spill.load544, %.splat547
  %2457 = load volatile <8 x i64>, ptr %.spill82, align 64
  %2458 = select <8 x i1> %convergence.cascade.result543, <8 x i64> %2456, <8 x i64> %2457
  store volatile <8 x i64> %2458, ptr %.spill82, align 64
  %.spill.load548 = load <8 x i1>, ptr %.spill59, align 1
  %2459 = and <8 x i1> %convergence.cascade.result543, %.spill.load548
  %2460 = xor <8 x i1> %.spill.load548, splat (i1 true)
  %2461 = and <8 x i1> %convergence.cascade.result543, %2460
  %2462 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2459)
  %2463 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2461)
  %2464 = and i1 %2462, %2463
  br i1 %2464, label %varying.divergent549, label %varying.coherent550

varying.divergent549:                             ; preds = %convergence.target.26.ready
  %2465 = load i32, ptr %current.token, align 4
  %2466 = icmp ne i32 %2465, 0
  %2467 = sub i32 %2465, 1
  %2468 = select i1 %2466, i32 %2467, i32 0
  %2469 = load i8, ptr %frame.active, align 1
  %2470 = trunc i32 %2468 to i8
  %2471 = shl i8 1, %2470
  %2472 = and i8 %2469, %2471
  %2473 = icmp ne i8 %2472, 0
  %2474 = load <8 x i32>, ptr %frame.static.id, align 32
  %2475 = extractelement <8 x i32> %2474, i32 %2468
  %2476 = icmp eq i32 %2475, 13
  %2477 = and i1 %2473, %2476
  %2478 = and i1 %2466, %2477
  %2479 = xor i1 %2478, true
  %2480 = and i1 true, %2479
  %2481 = xor i8 %2469, -1
  %2482 = icmp ne i8 %2481, 0
  %2483 = xor i1 %2482, true
  %2484 = and i1 %2480, %2483
  br i1 %2484, label %convergence.overflow.trap551, label %convergence.overflow.resume552

varying.coherent550:                              ; preds = %convergence.target.26.ready
  br i1 %2462, label %varying.coherent.true555, label %varying.coherent.false556

convergence.overflow.trap551:                     ; preds = %varying.divergent549
  call void @llvm.trap()
  unreachable

convergence.overflow.resume552:                   ; preds = %varying.divergent549
  %2485 = call i8 @llvm.cttz.i8(i8 %2481, i1 false)
  %2486 = zext i8 %2485 to i32
  %2487 = select i1 %2482, i32 %2486, i32 0
  %2488 = trunc i32 %2487 to i8
  %2489 = shl i8 1, %2488
  %2490 = or i8 %2469, %2489
  %2491 = select i1 %2480, i8 %2490, i8 %2469
  store i8 %2491, ptr %frame.active, align 1
  %2492 = load <8 x i32>, ptr %frame.static.id, align 32
  %2493 = extractelement <8 x i32> %2492, i32 %2487
  %2494 = select i1 %2480, i32 13, i32 %2493
  %2495 = load <8 x i32>, ptr %frame.static.id, align 32
  %2496 = insertelement <8 x i32> %2495, i32 %2494, i32 %2487
  store <8 x i32> %2496, ptr %frame.static.id, align 32
  %2497 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2498 = extractelement <8 x i32> %2497, i32 %2487
  %2499 = select i1 %2480, i32 %2465, i32 %2498
  %2500 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2501 = insertelement <8 x i32> %2500, i32 %2499, i32 %2487
  store <8 x i32> %2501, ptr %frame.parent.token, align 32
  %2502 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2487
  %2503 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2487
  %2504 = load <8 x i1>, ptr %2502, align 1
  %2505 = load <8 x i1>, ptr %2503, align 1
  %2506 = select i1 %2480, <8 x i1> %convergence.cascade.result543, <8 x i1> %2504
  store <8 x i1> %2506, ptr %2502, align 1
  %2507 = select i1 %2480, <8 x i1> zeroinitializer, <8 x i1> %2505
  store <8 x i1> %2507, ptr %2503, align 1
  %2508 = add i32 %2487, 1
  %2509 = select i1 %2478, i32 %2465, i32 %2508
  %2510 = select i1 true, i32 %2509, i32 %2465
  store i32 %2510, ptr %current.token, align 4
  %2511 = load <8 x float>, ptr %.slot83, align 32
  %2512 = select <8 x i1> %2461, <8 x float> zeroinitializer, <8 x float> %2511
  store <8 x float> %2512, ptr %.slot83, align 32
  %2513 = load i32, ptr %current.token, align 4
  %2514 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2459)
  %2515 = load i32, ptr %ready.count, align 4
  %2516 = icmp uge i32 %2515, 8
  %2517 = and i1 %2514, %2516
  br i1 %2517, label %ready.overflow.trap553, label %ready.overflow.resume554

ready.overflow.trap553:                           ; preds = %convergence.overflow.resume552
  call void @llvm.trap()
  unreachable

ready.overflow.resume554:                         ; preds = %convergence.overflow.resume552
  %2518 = select i1 %2514, i32 %2515, i32 0
  %2519 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2518
  %2520 = load <8 x i1>, ptr %2519, align 1
  %2521 = select i1 %2514, <8 x i1> %2459, <8 x i1> %2520
  store <8 x i1> %2521, ptr %2519, align 1
  %2522 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2518
  %2523 = load i32, ptr %2522, align 4
  %2524 = select i1 %2514, i32 27, i32 %2523
  store i32 %2524, ptr %2522, align 4
  %2525 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2518
  %2526 = load i32, ptr %2525, align 4
  %2527 = select i1 %2514, i32 %2513, i32 %2526
  store i32 %2527, ptr %2525, align 4
  %2528 = add i32 %2515, 1
  %2529 = select i1 %2514, i32 %2528, i32 %2515
  store i32 %2529, ptr %ready.count, align 4
  %2530 = load <8 x i1>, ptr %runnable.mask, align 1
  %2531 = or <8 x i1> %2530, %2459
  store <8 x i1> %2531, ptr %runnable.mask, align 1
  store <8 x i1> %2461, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true555:                         ; preds = %varying.coherent550
  store <8 x i1> %convergence.cascade.result543, ptr %current.mask, align 1
  %2532 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result543)
  br i1 %2532, label %schedule.27, label %scheduler.loop

varying.coherent.false556:                        ; preds = %varying.coherent550
  %2533 = load <8 x float>, ptr %.slot83, align 32
  %2534 = select <8 x i1> %convergence.cascade.result543, <8 x float> zeroinitializer, <8 x float> %2533
  store <8 x float> %2534, ptr %.slot83, align 32
  store <8 x i1> %convergence.cascade.result543, ptr %current.mask, align 1
  %2535 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result543)
  br i1 %2535, label %schedule.28, label %scheduler.loop

convergence.cascade558:                           ; preds = %convergence.cascade558, %schedule.28
  %convergence.cascade.flow562 = phi <8 x i1> [ %494, %schedule.28 ], [ %2578, %convergence.cascade558 ]
  %convergence.cascade.depth563 = phi i32 [ 0, %schedule.28 ], [ %2579, %convergence.cascade558 ]
  %2536 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow562)
  %2537 = load i32, ptr %current.token, align 4
  %2538 = icmp ne i32 %2537, 0
  %2539 = and i1 %2536, %2538
  %2540 = sub i32 %2537, 1
  %2541 = select i1 %2539, i32 %2540, i32 0
  %2542 = load i8, ptr %frame.active, align 1
  %2543 = trunc i32 %2541 to i8
  %2544 = shl i8 1, %2543
  %2545 = and i8 %2542, %2544
  %2546 = icmp ne i8 %2545, 0
  %2547 = load <8 x i32>, ptr %frame.static.id, align 32
  %2548 = extractelement <8 x i32> %2547, i32 %2541
  %convergence.target.pointer564 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %2548
  %convergence.dynamic.target565 = load i32, ptr %convergence.target.pointer564, align 4
  %2549 = icmp eq i32 %convergence.dynamic.target565, 28
  %2550 = and i1 %2546, %2549
  %2551 = and i1 %2539, %2550
  %2552 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2541
  %2553 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2541
  %2554 = load <8 x i1>, ptr %2552, align 1
  %2555 = load <8 x i1>, ptr %2553, align 1
  %2556 = or <8 x i1> %2555, %convergence.cascade.flow562
  %2557 = load <8 x i1>, ptr %live.mask, align 1
  %2558 = and <8 x i1> %2554, %2557
  %2559 = icmp eq <8 x i1> %2556, %2558
  %2560 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2559)
  %2561 = and i1 %2551, %2560
  %2562 = select i1 %2561, <8 x i1> zeroinitializer, <8 x i1> %2556
  %2563 = select i1 %2551, <8 x i1> %2562, <8 x i1> %2555
  store <8 x i1> %2563, ptr %2553, align 1
  %2564 = select i1 %2561, <8 x i1> zeroinitializer, <8 x i1> %2554
  store <8 x i1> %2564, ptr %2552, align 1
  %2565 = trunc i32 %2541 to i8
  %2566 = shl i8 1, %2565
  %2567 = xor i8 %2566, -1
  %2568 = and i8 %2542, %2567
  %2569 = select i1 %2561, i8 %2568, i8 %2542
  store i8 %2569, ptr %frame.active, align 1
  %.splatinsert566 = insertelement <8 x i1> poison, i1 %2551, i64 0
  %.splat567 = shufflevector <8 x i1> %.splatinsert566, <8 x i1> poison, <8 x i32> zeroinitializer
  %2570 = and <8 x i1> %convergence.cascade.flow562, %.splat567
  %2571 = load <8 x i1>, ptr %runnable.mask, align 1
  %2572 = xor <8 x i1> %2570, splat (i1 true)
  %2573 = and <8 x i1> %2571, %2572
  store <8 x i1> %2573, ptr %runnable.mask, align 1
  %.splatinsert568 = insertelement <8 x i1> poison, i1 %2561, i64 0
  %.splat569 = shufflevector <8 x i1> %.splatinsert568, <8 x i1> poison, <8 x i32> zeroinitializer
  %2574 = select <8 x i1> %.splat569, <8 x i1> %2556, <8 x i1> zeroinitializer
  %2575 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2576 = extractelement <8 x i32> %2575, i32 %2541
  %2577 = select i1 %2561, i32 %2576, i32 %2537
  store i32 %2577, ptr %current.token, align 4
  %.splatinsert570 = insertelement <8 x i1> poison, i1 %2551, i64 0
  %.splat571 = shufflevector <8 x i1> %.splatinsert570, <8 x i1> poison, <8 x i32> zeroinitializer
  %2578 = select <8 x i1> %.splat571, <8 x i1> %2574, <8 x i1> %convergence.cascade.flow562
  %2579 = add i32 %convergence.cascade.depth563, 1
  %2580 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2578)
  %2581 = icmp ult i32 %2579, 8
  %2582 = and i1 %2580, %2581
  %2583 = and i1 %2551, %2582
  %convergence.parent.token572 = load i32, ptr %current.token, align 4
  %convergence.parent.present573 = icmp ne i32 %convergence.parent.token572, 0
  %2584 = and i1 %2583, %convergence.parent.present573
  br i1 %2584, label %convergence.cascade558, label %convergence.cascade.exit559

convergence.cascade.exit559:                      ; preds = %convergence.cascade558, %schedule.28
  %convergence.cascade.result574 = phi <8 x i1> [ %494, %schedule.28 ], [ %2578, %convergence.cascade558 ]
  %2585 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result574)
  br i1 %2585, label %convergence.target.28.ready, label %scheduler.loop

convergence.target.28.ready:                      ; preds = %convergence.cascade.exit559
  %2586 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result574)
  %2587 = bitcast <8 x i1> %convergence.cascade.result574 to i8
  %2588 = call i8 @llvm.cttz.i8(i8 %2587, i1 false)
  %2589 = zext i8 %2588 to i32
  %2590 = select i1 %2586, i32 %2589, i32 0
  %.spill.load575 = load volatile <8 x float>, ptr %.spill9, align 32
  %.spill.load576 = load volatile <8 x float>, ptr %.spill44, align 32
  %2591 = fmul <8 x float> %.spill.load575, %.spill.load576
  %2592 = fadd <8 x float> zeroinitializer, %2591
  %.spill.load577 = load volatile <8 x float>, ptr %.spill11, align 32
  %.spill.load578 = load volatile <8 x float>, ptr %.spill45, align 32
  %2593 = fmul <8 x float> %.spill.load577, %.spill.load578
  %2594 = fadd <8 x float> %2592, %2593
  %.spill.load579 = load volatile <8 x float>, ptr %.spill13, align 32
  %.spill.load580 = load volatile <8 x float>, ptr %.spill46, align 32
  %2595 = fmul <8 x float> %.spill.load579, %.spill.load580
  %2596 = fadd <8 x float> %2594, %2595
  %.spill.load581 = load volatile <8 x float>, ptr %.spill15, align 32
  %.spill.load582 = load volatile <8 x float>, ptr %.spill47, align 32
  %2597 = fmul <8 x float> %.spill.load581, %.spill.load582
  %2598 = fadd <8 x float> %2596, %2597
  %.spill.load583 = load volatile <8 x float>, ptr %.spill17, align 32
  %.spill.load584 = load volatile <8 x float>, ptr %.spill48, align 32
  %2599 = fmul <8 x float> %.spill.load583, %.spill.load584
  %2600 = fadd <8 x float> %2598, %2599
  %.spill.load585 = load volatile <8 x float>, ptr %.spill9, align 32
  %.spill.load586 = load volatile <8 x float>, ptr %.spill51, align 32
  %2601 = fmul <8 x float> %.spill.load585, %.spill.load586
  %2602 = fadd <8 x float> zeroinitializer, %2601
  %.spill.load587 = load volatile <8 x float>, ptr %.spill11, align 32
  %.spill.load588 = load volatile <8 x float>, ptr %.spill52, align 32
  %2603 = fmul <8 x float> %.spill.load587, %.spill.load588
  %2604 = fadd <8 x float> %2602, %2603
  %.spill.load589 = load volatile <8 x float>, ptr %.spill13, align 32
  %.spill.load590 = load volatile <8 x float>, ptr %.spill53, align 32
  %2605 = fmul <8 x float> %.spill.load589, %.spill.load590
  %2606 = fadd <8 x float> %2604, %2605
  %.spill.load591 = load volatile <8 x float>, ptr %.spill15, align 32
  %.spill.load592 = load volatile <8 x float>, ptr %.spill54, align 32
  %2607 = fmul <8 x float> %.spill.load591, %.spill.load592
  %2608 = fadd <8 x float> %2606, %2607
  %.spill.load593 = load volatile <8 x float>, ptr %.spill17, align 32
  %.spill.load594 = load volatile <8 x float>, ptr %.spill55, align 32
  %2609 = fmul <8 x float> %.spill.load593, %.spill.load594
  %2610 = fadd <8 x float> %2608, %2609
  %.spill.load595 = load volatile <8 x float>, ptr %.spill9, align 32
  %.state596 = load <8 x float>, ptr %.slot62, align 32
  %2611 = fmul <8 x float> %.spill.load595, %.state596
  %2612 = fadd <8 x float> zeroinitializer, %2611
  %.spill.load597 = load volatile <8 x float>, ptr %.spill11, align 32
  %.state598 = load <8 x float>, ptr %.slot64, align 32
  %2613 = fmul <8 x float> %.spill.load597, %.state598
  %2614 = fadd <8 x float> %2612, %2613
  %.spill.load599 = load volatile <8 x float>, ptr %.spill13, align 32
  %.state600 = load <8 x float>, ptr %.slot66, align 32
  %2615 = fmul <8 x float> %.spill.load599, %.state600
  %2616 = fadd <8 x float> %2614, %2615
  %.spill.load601 = load volatile <8 x float>, ptr %.spill15, align 32
  %.state602 = load <8 x float>, ptr %.slot68, align 32
  %2617 = fmul <8 x float> %.spill.load601, %.state602
  %2618 = fadd <8 x float> %2616, %2617
  %.spill.load603 = load volatile <8 x float>, ptr %.spill17, align 32
  %.state604 = load <8 x float>, ptr %.slot70, align 32
  %2619 = fmul <8 x float> %.spill.load603, %.state604
  %2620 = fadd <8 x float> %2618, %2619
  %.state605 = load <8 x float>, ptr %.slot, align 32
  %.spill.load606 = load volatile <8 x float>, ptr %.spill44, align 32
  %2621 = fmul <8 x float> %.state605, %.spill.load606
  %2622 = fadd <8 x float> zeroinitializer, %2621
  %.state607 = load <8 x float>, ptr %.slot24, align 32
  %.spill.load608 = load volatile <8 x float>, ptr %.spill45, align 32
  %2623 = fmul <8 x float> %.state607, %.spill.load608
  %2624 = fadd <8 x float> %2622, %2623
  %.state609 = load <8 x float>, ptr %.slot26, align 32
  %.spill.load610 = load volatile <8 x float>, ptr %.spill46, align 32
  %2625 = fmul <8 x float> %.state609, %.spill.load610
  %2626 = fadd <8 x float> %2624, %2625
  %.state611 = load <8 x float>, ptr %.slot28, align 32
  %.spill.load612 = load volatile <8 x float>, ptr %.spill47, align 32
  %2627 = fmul <8 x float> %.state611, %.spill.load612
  %2628 = fadd <8 x float> %2626, %2627
  %.state613 = load <8 x float>, ptr %.slot30, align 32
  %.spill.load614 = load volatile <8 x float>, ptr %.spill48, align 32
  %2629 = fmul <8 x float> %.state613, %.spill.load614
  %2630 = fadd <8 x float> %2628, %2629
  %.state615 = load <8 x float>, ptr %.slot, align 32
  %.spill.load616 = load volatile <8 x float>, ptr %.spill51, align 32
  %2631 = fmul <8 x float> %.state615, %.spill.load616
  %2632 = fadd <8 x float> zeroinitializer, %2631
  %.state617 = load <8 x float>, ptr %.slot24, align 32
  %.spill.load618 = load volatile <8 x float>, ptr %.spill52, align 32
  %2633 = fmul <8 x float> %.state617, %.spill.load618
  %2634 = fadd <8 x float> %2632, %2633
  %.state619 = load <8 x float>, ptr %.slot26, align 32
  %.spill.load620 = load volatile <8 x float>, ptr %.spill53, align 32
  %2635 = fmul <8 x float> %.state619, %.spill.load620
  %2636 = fadd <8 x float> %2634, %2635
  %.state621 = load <8 x float>, ptr %.slot28, align 32
  %.spill.load622 = load volatile <8 x float>, ptr %.spill54, align 32
  %2637 = fmul <8 x float> %.state621, %.spill.load622
  %2638 = fadd <8 x float> %2636, %2637
  %.state623 = load <8 x float>, ptr %.slot30, align 32
  %.spill.load624 = load volatile <8 x float>, ptr %.spill55, align 32
  %2639 = fmul <8 x float> %.state623, %.spill.load624
  %2640 = fadd <8 x float> %2638, %2639
  %.state625 = load <8 x float>, ptr %.slot, align 32
  %.state626 = load <8 x float>, ptr %.slot62, align 32
  %2641 = fmul <8 x float> %.state625, %.state626
  %2642 = fadd <8 x float> zeroinitializer, %2641
  %.state627 = load <8 x float>, ptr %.slot24, align 32
  %.state628 = load <8 x float>, ptr %.slot64, align 32
  %2643 = fmul <8 x float> %.state627, %.state628
  %2644 = fadd <8 x float> %2642, %2643
  %.state629 = load <8 x float>, ptr %.slot26, align 32
  %.state630 = load <8 x float>, ptr %.slot66, align 32
  %2645 = fmul <8 x float> %.state629, %.state630
  %2646 = fadd <8 x float> %2644, %2645
  %.state631 = load <8 x float>, ptr %.slot28, align 32
  %.state632 = load <8 x float>, ptr %.slot68, align 32
  %2647 = fmul <8 x float> %.state631, %.state632
  %2648 = fadd <8 x float> %2646, %2647
  %.state633 = load <8 x float>, ptr %.slot30, align 32
  %.state634 = load <8 x float>, ptr %.slot70, align 32
  %2649 = fmul <8 x float> %.state633, %.state634
  %2650 = fadd <8 x float> %2648, %2649
  %2651 = fmul <8 x float> %2600, splat (float 0x3FDC9F25C0000000)
  %2652 = fmul <8 x float> %2610, splat (float 0x3FDC9F25C0000000)
  %2653 = fmul <8 x float> %2620, splat (float 0x3FDC9F25C0000000)
  %2654 = fmul <8 x float> %2630, splat (float 0x3FDC9F25C0000000)
  %2655 = fmul <8 x float> %2640, splat (float 0x3FDC9F25C0000000)
  %2656 = fmul <8 x float> %2650, splat (float 0x3FDC9F25C0000000)
  %.spill.load635 = load volatile <8 x i64>, ptr %.spill42, align 64
  %2657 = icmp slt <8 x i64> %.spill.load635, splat (i64 5)
  %.spill.load636 = load volatile <8 x i64>, ptr %.spill49, align 64
  %2658 = icmp slt <8 x i64> %.spill.load636, splat (i64 5)
  %.spill.load637 = load volatile <8 x i64>, ptr %.spill7, align 64
  %2659 = add <8 x i64> %.spill.load637, splat (i64 5)
  %.spill.load638 = load volatile <8 x i64>, ptr %.spill18, align 64
  %2660 = add <8 x i64> %.spill.load638, splat (i64 5)
  %2661 = sub <8 x i64> %2659, splat (i64 5)
  %2662 = sub <8 x i64> %2660, splat (i64 5)
  %.spill.load639 = load volatile <8 x i64>, ptr %.spill42, align 64
  %2663 = icmp sle <8 x i64> %.spill.load639, %2661
  %.spill.load640 = load volatile <8 x i64>, ptr %.spill42, align 64
  %2664 = icmp sle <8 x i64> %.spill.load640, %2662
  %.spill.load641 = load volatile <8 x i64>, ptr %.spill49, align 64
  %2665 = icmp sle <8 x i64> %.spill.load641, %2661
  %.spill.load642 = load volatile <8 x i64>, ptr %.spill49, align 64
  %2666 = icmp sle <8 x i64> %.spill.load642, %2662
  %.spill.load643 = load volatile <8 x i64>, ptr %.spill56, align 64
  %2667 = icmp sle <8 x i64> %.spill.load643, %2661
  %.spill.load644 = load volatile <8 x i64>, ptr %.spill56, align 64
  %2668 = icmp sle <8 x i64> %.spill.load644, %2662
  %2669 = and <8 x i1> %2657, %2663
  %2670 = load volatile <8 x i1>, ptr %.spill84, align 1
  %2671 = select <8 x i1> %convergence.cascade.result574, <8 x i1> %2669, <8 x i1> %2670
  store volatile <8 x i1> %2671, ptr %.spill84, align 1
  %2672 = and <8 x i1> %2657, %2664
  %2673 = load volatile <8 x i1>, ptr %.spill85, align 1
  %2674 = select <8 x i1> %convergence.cascade.result574, <8 x i1> %2672, <8 x i1> %2673
  store volatile <8 x i1> %2674, ptr %.spill85, align 1
  %2675 = and <8 x i1> %2658, %2665
  %2676 = load volatile <8 x i1>, ptr %.spill86, align 1
  %2677 = select <8 x i1> %convergence.cascade.result574, <8 x i1> %2675, <8 x i1> %2676
  store volatile <8 x i1> %2677, ptr %.spill86, align 1
  %2678 = and <8 x i1> %2658, %2666
  %2679 = load volatile <8 x i1>, ptr %.spill87, align 1
  %2680 = select <8 x i1> %convergence.cascade.result574, <8 x i1> %2678, <8 x i1> %2679
  store volatile <8 x i1> %2680, ptr %.spill87, align 1
  %.spill.load645 = load volatile <8 x i1>, ptr %.spill58, align 1
  %2681 = and <8 x i1> %.spill.load645, %2667
  %2682 = load volatile <8 x i1>, ptr %.spill88, align 1
  %2683 = select <8 x i1> %convergence.cascade.result574, <8 x i1> %2681, <8 x i1> %2682
  store volatile <8 x i1> %2683, ptr %.spill88, align 1
  %.spill.load646 = load volatile <8 x i1>, ptr %.spill58, align 1
  %2684 = and <8 x i1> %.spill.load646, %2668
  %2685 = load volatile <8 x i1>, ptr %.spill89, align 1
  %2686 = select <8 x i1> %convergence.cascade.result574, <8 x i1> %2684, <8 x i1> %2685
  store volatile <8 x i1> %2686, ptr %.spill89, align 1
  %2687 = select <8 x i1> %2669, <8 x float> %2651, <8 x float> splat (float 0xC6293E5940000000)
  %2688 = load volatile <8 x float>, ptr %.spill90, align 32
  %2689 = select <8 x i1> %convergence.cascade.result574, <8 x float> %2687, <8 x float> %2688
  store volatile <8 x float> %2689, ptr %.spill90, align 32
  %2690 = select <8 x i1> %2675, <8 x float> %2652, <8 x float> splat (float 0xC6293E5940000000)
  %2691 = load volatile <8 x float>, ptr %.spill91, align 32
  %2692 = select <8 x i1> %convergence.cascade.result574, <8 x float> %2690, <8 x float> %2691
  store volatile <8 x float> %2692, ptr %.spill91, align 32
  %2693 = select <8 x i1> %2681, <8 x float> %2653, <8 x float> splat (float 0xC6293E5940000000)
  %2694 = load volatile <8 x float>, ptr %.spill92, align 32
  %2695 = select <8 x i1> %convergence.cascade.result574, <8 x float> %2693, <8 x float> %2694
  store volatile <8 x float> %2695, ptr %.spill92, align 32
  %2696 = select <8 x i1> %2672, <8 x float> %2654, <8 x float> splat (float 0xC6293E5940000000)
  %2697 = load volatile <8 x float>, ptr %.spill93, align 32
  %2698 = select <8 x i1> %convergence.cascade.result574, <8 x float> %2696, <8 x float> %2697
  store volatile <8 x float> %2698, ptr %.spill93, align 32
  %2699 = select <8 x i1> %2678, <8 x float> %2655, <8 x float> splat (float 0xC6293E5940000000)
  %2700 = load volatile <8 x float>, ptr %.spill94, align 32
  %2701 = select <8 x i1> %convergence.cascade.result574, <8 x float> %2699, <8 x float> %2700
  store volatile <8 x float> %2701, ptr %.spill94, align 32
  %2702 = select <8 x i1> %2684, <8 x float> %2656, <8 x float> splat (float 0xC6293E5940000000)
  %2703 = load volatile <8 x float>, ptr %.spill95, align 32
  %2704 = select <8 x i1> %convergence.cascade.result574, <8 x float> %2702, <8 x float> %2703
  store volatile <8 x float> %2704, ptr %.spill95, align 32
  %2705 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %2706 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %2707 = extractvalue { <8 x ptr>, <8 x i64> } %2705, 0
  %2708 = select <8 x i1> %convergence.cascade.result574, <8 x ptr> %2706, <8 x ptr> %2707
  %2709 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %2710 = extractvalue { <8 x ptr>, <8 x i64> } %2705, 1
  %2711 = select <8 x i1> %convergence.cascade.result574, <8 x i64> %2709, <8 x i64> %2710
  %2712 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2708, 0
  %2713 = insertvalue { <8 x ptr>, <8 x i64> } %2712, <8 x i64> %2711, 1
  store volatile { <8 x ptr>, <8 x i64> } %2713, ptr %tile_snapshot.spill, align 64
  %2714 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %2715 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %2716 = add <8 x i64> %2715, zeroinitializer
  %2717 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2714, 0
  %2718 = insertvalue { <8 x ptr>, <8 x i64> } %2717, <8 x i64> %2716, 1
  %2719 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %2720 = extractvalue { <8 x ptr>, <8 x i64> } %2718, 1
  %2721 = extractelement <8 x ptr> %2719, i32 0
  %2722 = extractelement <8 x i64> %2720, i32 %2590
  %2723 = zext i32 %2590 to i64
  %2724 = mul i64 %2723, 4
  %2725 = sub i64 %2722, %2724
  %2726 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result574)
  %2727 = select i1 %2726, i64 %2725, i64 0
  %private.contiguous.address = getelementptr i8, ptr %2721, i64 %2727
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %2728 = select <8 x i1> %convergence.cascade.result574, <8 x float> %2687, <8 x float> %private.contiguous.preserve
  store <8 x float> %2728, ptr %private.contiguous.address, align 4
  %2729 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %2730 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %2731 = add <8 x i64> %2730, splat (i64 32)
  %2732 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2729, 0
  %2733 = insertvalue { <8 x ptr>, <8 x i64> } %2732, <8 x i64> %2731, 1
  %2734 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %2735 = extractvalue { <8 x ptr>, <8 x i64> } %2733, 1
  %2736 = extractelement <8 x ptr> %2734, i32 0
  %2737 = extractelement <8 x i64> %2735, i32 %2590
  %2738 = zext i32 %2590 to i64
  %2739 = mul i64 %2738, 4
  %2740 = sub i64 %2737, %2739
  %2741 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result574)
  %2742 = select i1 %2741, i64 %2740, i64 0
  %private.contiguous.address647 = getelementptr i8, ptr %2736, i64 %2742
  %private.contiguous.preserve648 = load <8 x float>, ptr %private.contiguous.address647, align 4
  %2743 = select <8 x i1> %convergence.cascade.result574, <8 x float> %2690, <8 x float> %private.contiguous.preserve648
  store <8 x float> %2743, ptr %private.contiguous.address647, align 4
  %2744 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %2745 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %2746 = add <8 x i64> %2745, splat (i64 64)
  %2747 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2744, 0
  %2748 = insertvalue { <8 x ptr>, <8 x i64> } %2747, <8 x i64> %2746, 1
  %2749 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %2750 = extractvalue { <8 x ptr>, <8 x i64> } %2748, 1
  %2751 = extractelement <8 x ptr> %2749, i32 0
  %2752 = extractelement <8 x i64> %2750, i32 %2590
  %2753 = zext i32 %2590 to i64
  %2754 = mul i64 %2753, 4
  %2755 = sub i64 %2752, %2754
  %2756 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result574)
  %2757 = select i1 %2756, i64 %2755, i64 0
  %private.contiguous.address649 = getelementptr i8, ptr %2751, i64 %2757
  %private.contiguous.preserve650 = load <8 x float>, ptr %private.contiguous.address649, align 4
  %2758 = select <8 x i1> %convergence.cascade.result574, <8 x float> %2693, <8 x float> %private.contiguous.preserve650
  store <8 x float> %2758, ptr %private.contiguous.address649, align 4
  %2759 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %2760 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %2761 = add <8 x i64> %2760, splat (i64 96)
  %2762 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2759, 0
  %2763 = insertvalue { <8 x ptr>, <8 x i64> } %2762, <8 x i64> %2761, 1
  %2764 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %2765 = extractvalue { <8 x ptr>, <8 x i64> } %2763, 1
  %2766 = extractelement <8 x ptr> %2764, i32 0
  %2767 = extractelement <8 x i64> %2765, i32 %2590
  %2768 = zext i32 %2590 to i64
  %2769 = mul i64 %2768, 4
  %2770 = sub i64 %2767, %2769
  %2771 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result574)
  %2772 = select i1 %2771, i64 %2770, i64 0
  %private.contiguous.address651 = getelementptr i8, ptr %2766, i64 %2772
  %private.contiguous.preserve652 = load <8 x float>, ptr %private.contiguous.address651, align 4
  %2773 = select <8 x i1> %convergence.cascade.result574, <8 x float> %2696, <8 x float> %private.contiguous.preserve652
  store <8 x float> %2773, ptr %private.contiguous.address651, align 4
  %2774 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %2775 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %2776 = add <8 x i64> %2775, splat (i64 128)
  %2777 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2774, 0
  %2778 = insertvalue { <8 x ptr>, <8 x i64> } %2777, <8 x i64> %2776, 1
  %2779 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %2780 = extractvalue { <8 x ptr>, <8 x i64> } %2778, 1
  %2781 = extractelement <8 x ptr> %2779, i32 0
  %2782 = extractelement <8 x i64> %2780, i32 %2590
  %2783 = zext i32 %2590 to i64
  %2784 = mul i64 %2783, 4
  %2785 = sub i64 %2782, %2784
  %2786 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result574)
  %2787 = select i1 %2786, i64 %2785, i64 0
  %private.contiguous.address653 = getelementptr i8, ptr %2781, i64 %2787
  %private.contiguous.preserve654 = load <8 x float>, ptr %private.contiguous.address653, align 4
  %2788 = select <8 x i1> %convergence.cascade.result574, <8 x float> %2699, <8 x float> %private.contiguous.preserve654
  store <8 x float> %2788, ptr %private.contiguous.address653, align 4
  %2789 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %2790 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %2791 = add <8 x i64> %2790, splat (i64 160)
  %2792 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2789, 0
  %2793 = insertvalue { <8 x ptr>, <8 x i64> } %2792, <8 x i64> %2791, 1
  %2794 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %2795 = extractvalue { <8 x ptr>, <8 x i64> } %2793, 1
  %2796 = extractelement <8 x ptr> %2794, i32 0
  %2797 = extractelement <8 x i64> %2795, i32 %2590
  %2798 = zext i32 %2590 to i64
  %2799 = mul i64 %2798, 4
  %2800 = sub i64 %2797, %2799
  %2801 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result574)
  %2802 = select i1 %2801, i64 %2800, i64 0
  %private.contiguous.address655 = getelementptr i8, ptr %2796, i64 %2802
  %private.contiguous.preserve656 = load <8 x float>, ptr %private.contiguous.address655, align 4
  %2803 = select <8 x i1> %convergence.cascade.result574, <8 x float> %2702, <8 x float> %private.contiguous.preserve656
  store <8 x float> %2803, ptr %private.contiguous.address655, align 4
  %2804 = load <8 x i64>, ptr %.slot96, align 64
  %2805 = select <8 x i1> %convergence.cascade.result574, <8 x i64> zeroinitializer, <8 x i64> %2804
  store <8 x i64> %2805, ptr %.slot96, align 64
  %2806 = load <8 x float>, ptr %.slot97, align 32
  %2807 = select <8 x i1> %convergence.cascade.result574, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %2806
  store <8 x float> %2807, ptr %.slot97, align 32
  store <8 x i1> %convergence.cascade.result574, ptr %current.mask, align 1
  %2808 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result574)
  br i1 %2808, label %schedule.29, label %scheduler.loop

varying.divergent658:                             ; preds = %schedule.29
  %2809 = load i32, ptr %current.token, align 4
  %2810 = icmp ne i32 %2809, 0
  %2811 = sub i32 %2809, 1
  %2812 = select i1 %2810, i32 %2811, i32 0
  %2813 = load i8, ptr %frame.active, align 1
  %2814 = trunc i32 %2812 to i8
  %2815 = shl i8 1, %2814
  %2816 = and i8 %2813, %2815
  %2817 = icmp ne i8 %2816, 0
  %2818 = load <8 x i32>, ptr %frame.static.id, align 32
  %2819 = extractelement <8 x i32> %2818, i32 %2812
  %2820 = icmp eq i32 %2819, 14
  %2821 = and i1 %2817, %2820
  %2822 = and i1 %2810, %2821
  %2823 = xor i1 %2822, true
  %2824 = and i1 true, %2823
  %2825 = xor i8 %2813, -1
  %2826 = icmp ne i8 %2825, 0
  %2827 = xor i1 %2826, true
  %2828 = and i1 %2824, %2827
  br i1 %2828, label %convergence.overflow.trap660, label %convergence.overflow.resume661

varying.coherent659:                              ; preds = %schedule.29
  br i1 %505, label %varying.coherent.true664, label %varying.coherent.false665

convergence.overflow.trap660:                     ; preds = %varying.divergent658
  call void @llvm.trap()
  unreachable

convergence.overflow.resume661:                   ; preds = %varying.divergent658
  %2829 = call i8 @llvm.cttz.i8(i8 %2825, i1 false)
  %2830 = zext i8 %2829 to i32
  %2831 = select i1 %2826, i32 %2830, i32 0
  %2832 = trunc i32 %2831 to i8
  %2833 = shl i8 1, %2832
  %2834 = or i8 %2813, %2833
  %2835 = select i1 %2824, i8 %2834, i8 %2813
  store i8 %2835, ptr %frame.active, align 1
  %2836 = load <8 x i32>, ptr %frame.static.id, align 32
  %2837 = extractelement <8 x i32> %2836, i32 %2831
  %2838 = select i1 %2824, i32 14, i32 %2837
  %2839 = load <8 x i32>, ptr %frame.static.id, align 32
  %2840 = insertelement <8 x i32> %2839, i32 %2838, i32 %2831
  store <8 x i32> %2840, ptr %frame.static.id, align 32
  %2841 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2842 = extractelement <8 x i32> %2841, i32 %2831
  %2843 = select i1 %2824, i32 %2809, i32 %2842
  %2844 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2845 = insertelement <8 x i32> %2844, i32 %2843, i32 %2831
  store <8 x i32> %2845, ptr %frame.parent.token, align 32
  %2846 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2831
  %2847 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2831
  %2848 = load <8 x i1>, ptr %2846, align 1
  %2849 = load <8 x i1>, ptr %2847, align 1
  %2850 = select i1 %2824, <8 x i1> %495, <8 x i1> %2848
  store <8 x i1> %2850, ptr %2846, align 1
  %2851 = select i1 %2824, <8 x i1> zeroinitializer, <8 x i1> %2849
  store <8 x i1> %2851, ptr %2847, align 1
  %2852 = add i32 %2831, 1
  %2853 = select i1 %2822, i32 %2809, i32 %2852
  %2854 = select i1 true, i32 %2853, i32 %2809
  store i32 %2854, ptr %current.token, align 4
  %2855 = load i32, ptr %current.token, align 4
  %2856 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %502)
  %2857 = load i32, ptr %ready.count, align 4
  %2858 = icmp uge i32 %2857, 8
  %2859 = and i1 %2856, %2858
  br i1 %2859, label %ready.overflow.trap662, label %ready.overflow.resume663

ready.overflow.trap662:                           ; preds = %convergence.overflow.resume661
  call void @llvm.trap()
  unreachable

ready.overflow.resume663:                         ; preds = %convergence.overflow.resume661
  %2860 = select i1 %2856, i32 %2857, i32 0
  %2861 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2860
  %2862 = load <8 x i1>, ptr %2861, align 1
  %2863 = select i1 %2856, <8 x i1> %502, <8 x i1> %2862
  store <8 x i1> %2863, ptr %2861, align 1
  %2864 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2860
  %2865 = load i32, ptr %2864, align 4
  %2866 = select i1 %2856, i32 30, i32 %2865
  store i32 %2866, ptr %2864, align 4
  %2867 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2860
  %2868 = load i32, ptr %2867, align 4
  %2869 = select i1 %2856, i32 %2855, i32 %2868
  store i32 %2869, ptr %2867, align 4
  %2870 = add i32 %2857, 1
  %2871 = select i1 %2856, i32 %2870, i32 %2857
  store i32 %2871, ptr %ready.count, align 4
  %2872 = load <8 x i1>, ptr %runnable.mask, align 1
  %2873 = or <8 x i1> %2872, %502
  store <8 x i1> %2873, ptr %runnable.mask, align 1
  store <8 x i1> %504, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true664:                         ; preds = %varying.coherent659
  store <8 x i1> %495, ptr %current.mask, align 1
  %2874 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %495)
  br i1 %2874, label %schedule.30, label %scheduler.loop

varying.coherent.false665:                        ; preds = %varying.coherent659
  store <8 x i1> %495, ptr %current.mask, align 1
  %2875 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %495)
  br i1 %2875, label %schedule.31, label %scheduler.loop

convergence.cascade672:                           ; preds = %convergence.cascade672, %schedule.31
  %convergence.cascade.flow676 = phi <8 x i1> [ %541, %schedule.31 ], [ %2918, %convergence.cascade672 ]
  %convergence.cascade.depth677 = phi i32 [ 0, %schedule.31 ], [ %2919, %convergence.cascade672 ]
  %2876 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow676)
  %2877 = load i32, ptr %current.token, align 4
  %2878 = icmp ne i32 %2877, 0
  %2879 = and i1 %2876, %2878
  %2880 = sub i32 %2877, 1
  %2881 = select i1 %2879, i32 %2880, i32 0
  %2882 = load i8, ptr %frame.active, align 1
  %2883 = trunc i32 %2881 to i8
  %2884 = shl i8 1, %2883
  %2885 = and i8 %2882, %2884
  %2886 = icmp ne i8 %2885, 0
  %2887 = load <8 x i32>, ptr %frame.static.id, align 32
  %2888 = extractelement <8 x i32> %2887, i32 %2881
  %convergence.target.pointer678 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %2888
  %convergence.dynamic.target679 = load i32, ptr %convergence.target.pointer678, align 4
  %2889 = icmp eq i32 %convergence.dynamic.target679, 31
  %2890 = and i1 %2886, %2889
  %2891 = and i1 %2879, %2890
  %2892 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2881
  %2893 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2881
  %2894 = load <8 x i1>, ptr %2892, align 1
  %2895 = load <8 x i1>, ptr %2893, align 1
  %2896 = or <8 x i1> %2895, %convergence.cascade.flow676
  %2897 = load <8 x i1>, ptr %live.mask, align 1
  %2898 = and <8 x i1> %2894, %2897
  %2899 = icmp eq <8 x i1> %2896, %2898
  %2900 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2899)
  %2901 = and i1 %2891, %2900
  %2902 = select i1 %2901, <8 x i1> zeroinitializer, <8 x i1> %2896
  %2903 = select i1 %2891, <8 x i1> %2902, <8 x i1> %2895
  store <8 x i1> %2903, ptr %2893, align 1
  %2904 = select i1 %2901, <8 x i1> zeroinitializer, <8 x i1> %2894
  store <8 x i1> %2904, ptr %2892, align 1
  %2905 = trunc i32 %2881 to i8
  %2906 = shl i8 1, %2905
  %2907 = xor i8 %2906, -1
  %2908 = and i8 %2882, %2907
  %2909 = select i1 %2901, i8 %2908, i8 %2882
  store i8 %2909, ptr %frame.active, align 1
  %.splatinsert680 = insertelement <8 x i1> poison, i1 %2891, i64 0
  %.splat681 = shufflevector <8 x i1> %.splatinsert680, <8 x i1> poison, <8 x i32> zeroinitializer
  %2910 = and <8 x i1> %convergence.cascade.flow676, %.splat681
  %2911 = load <8 x i1>, ptr %runnable.mask, align 1
  %2912 = xor <8 x i1> %2910, splat (i1 true)
  %2913 = and <8 x i1> %2911, %2912
  store <8 x i1> %2913, ptr %runnable.mask, align 1
  %.splatinsert682 = insertelement <8 x i1> poison, i1 %2901, i64 0
  %.splat683 = shufflevector <8 x i1> %.splatinsert682, <8 x i1> poison, <8 x i32> zeroinitializer
  %2914 = select <8 x i1> %.splat683, <8 x i1> %2896, <8 x i1> zeroinitializer
  %2915 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2916 = extractelement <8 x i32> %2915, i32 %2881
  %2917 = select i1 %2901, i32 %2916, i32 %2877
  store i32 %2917, ptr %current.token, align 4
  %.splatinsert684 = insertelement <8 x i1> poison, i1 %2891, i64 0
  %.splat685 = shufflevector <8 x i1> %.splatinsert684, <8 x i1> poison, <8 x i32> zeroinitializer
  %2918 = select <8 x i1> %.splat685, <8 x i1> %2914, <8 x i1> %convergence.cascade.flow676
  %2919 = add i32 %convergence.cascade.depth677, 1
  %2920 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2918)
  %2921 = icmp ult i32 %2919, 8
  %2922 = and i1 %2920, %2921
  %2923 = and i1 %2891, %2922
  %convergence.parent.token686 = load i32, ptr %current.token, align 4
  %convergence.parent.present687 = icmp ne i32 %convergence.parent.token686, 0
  %2924 = and i1 %2923, %convergence.parent.present687
  br i1 %2924, label %convergence.cascade672, label %convergence.cascade.exit673

convergence.cascade.exit673:                      ; preds = %convergence.cascade672, %schedule.31
  %convergence.cascade.result688 = phi <8 x i1> [ %541, %schedule.31 ], [ %2918, %convergence.cascade672 ]
  %2925 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result688)
  br i1 %2925, label %convergence.target.31.ready, label %scheduler.loop

convergence.target.31.ready:                      ; preds = %convergence.cascade.exit673
  %2926 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result688)
  %2927 = bitcast <8 x i1> %convergence.cascade.result688 to i8
  %2928 = call i8 @llvm.cttz.i8(i8 %2927, i1 false)
  %2929 = zext i8 %2928 to i32
  %2930 = select i1 %2926, i32 %2929, i32 0
  %2931 = load <8 x i64>, ptr %.slot98, align 64
  %2932 = select <8 x i1> %convergence.cascade.result688, <8 x i64> zeroinitializer, <8 x i64> %2931
  store <8 x i64> %2932, ptr %.slot98, align 64
  %2933 = load <8 x float>, ptr %.slot99, align 32
  %2934 = select <8 x i1> %convergence.cascade.result688, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %2933
  store <8 x float> %2934, ptr %.slot99, align 32
  store <8 x i1> %convergence.cascade.result688, ptr %current.mask, align 1
  %2935 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result688)
  br i1 %2935, label %schedule.32, label %scheduler.loop

varying.divergent690:                             ; preds = %schedule.32
  %2936 = load i32, ptr %current.token, align 4
  %2937 = icmp ne i32 %2936, 0
  %2938 = sub i32 %2936, 1
  %2939 = select i1 %2937, i32 %2938, i32 0
  %2940 = load i8, ptr %frame.active, align 1
  %2941 = trunc i32 %2939 to i8
  %2942 = shl i8 1, %2941
  %2943 = and i8 %2940, %2942
  %2944 = icmp ne i8 %2943, 0
  %2945 = load <8 x i32>, ptr %frame.static.id, align 32
  %2946 = extractelement <8 x i32> %2945, i32 %2939
  %2947 = icmp eq i32 %2946, 15
  %2948 = and i1 %2944, %2947
  %2949 = and i1 %2937, %2948
  %2950 = xor i1 %2949, true
  %2951 = and i1 true, %2950
  %2952 = xor i8 %2940, -1
  %2953 = icmp ne i8 %2952, 0
  %2954 = xor i1 %2953, true
  %2955 = and i1 %2951, %2954
  br i1 %2955, label %convergence.overflow.trap692, label %convergence.overflow.resume693

varying.coherent691:                              ; preds = %schedule.32
  br i1 %552, label %varying.coherent.true696, label %varying.coherent.false697

convergence.overflow.trap692:                     ; preds = %varying.divergent690
  call void @llvm.trap()
  unreachable

convergence.overflow.resume693:                   ; preds = %varying.divergent690
  %2956 = call i8 @llvm.cttz.i8(i8 %2952, i1 false)
  %2957 = zext i8 %2956 to i32
  %2958 = select i1 %2953, i32 %2957, i32 0
  %2959 = trunc i32 %2958 to i8
  %2960 = shl i8 1, %2959
  %2961 = or i8 %2940, %2960
  %2962 = select i1 %2951, i8 %2961, i8 %2940
  store i8 %2962, ptr %frame.active, align 1
  %2963 = load <8 x i32>, ptr %frame.static.id, align 32
  %2964 = extractelement <8 x i32> %2963, i32 %2958
  %2965 = select i1 %2951, i32 15, i32 %2964
  %2966 = load <8 x i32>, ptr %frame.static.id, align 32
  %2967 = insertelement <8 x i32> %2966, i32 %2965, i32 %2958
  store <8 x i32> %2967, ptr %frame.static.id, align 32
  %2968 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2969 = extractelement <8 x i32> %2968, i32 %2958
  %2970 = select i1 %2951, i32 %2936, i32 %2969
  %2971 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2972 = insertelement <8 x i32> %2971, i32 %2970, i32 %2958
  store <8 x i32> %2972, ptr %frame.parent.token, align 32
  %2973 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2958
  %2974 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2958
  %2975 = load <8 x i1>, ptr %2973, align 1
  %2976 = load <8 x i1>, ptr %2974, align 1
  %2977 = select i1 %2951, <8 x i1> %542, <8 x i1> %2975
  store <8 x i1> %2977, ptr %2973, align 1
  %2978 = select i1 %2951, <8 x i1> zeroinitializer, <8 x i1> %2976
  store <8 x i1> %2978, ptr %2974, align 1
  %2979 = add i32 %2958, 1
  %2980 = select i1 %2949, i32 %2936, i32 %2979
  %2981 = select i1 true, i32 %2980, i32 %2936
  store i32 %2981, ptr %current.token, align 4
  %2982 = load i32, ptr %current.token, align 4
  %2983 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %549)
  %2984 = load i32, ptr %ready.count, align 4
  %2985 = icmp uge i32 %2984, 8
  %2986 = and i1 %2983, %2985
  br i1 %2986, label %ready.overflow.trap694, label %ready.overflow.resume695

ready.overflow.trap694:                           ; preds = %convergence.overflow.resume693
  call void @llvm.trap()
  unreachable

ready.overflow.resume695:                         ; preds = %convergence.overflow.resume693
  %2987 = select i1 %2983, i32 %2984, i32 0
  %2988 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2987
  %2989 = load <8 x i1>, ptr %2988, align 1
  %2990 = select i1 %2983, <8 x i1> %549, <8 x i1> %2989
  store <8 x i1> %2990, ptr %2988, align 1
  %2991 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2987
  %2992 = load i32, ptr %2991, align 4
  %2993 = select i1 %2983, i32 33, i32 %2992
  store i32 %2993, ptr %2991, align 4
  %2994 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2987
  %2995 = load i32, ptr %2994, align 4
  %2996 = select i1 %2983, i32 %2982, i32 %2995
  store i32 %2996, ptr %2994, align 4
  %2997 = add i32 %2984, 1
  %2998 = select i1 %2983, i32 %2997, i32 %2984
  store i32 %2998, ptr %ready.count, align 4
  %2999 = load <8 x i1>, ptr %runnable.mask, align 1
  %3000 = or <8 x i1> %2999, %549
  store <8 x i1> %3000, ptr %runnable.mask, align 1
  store <8 x i1> %551, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true696:                         ; preds = %varying.coherent691
  store <8 x i1> %542, ptr %current.mask, align 1
  %3001 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %542)
  br i1 %3001, label %schedule.33, label %scheduler.loop

varying.coherent.false697:                        ; preds = %varying.coherent691
  store <8 x i1> %542, ptr %current.mask, align 1
  %3002 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %542)
  br i1 %3002, label %schedule.34, label %scheduler.loop

convergence.cascade705:                           ; preds = %convergence.cascade705, %schedule.34
  %convergence.cascade.flow709 = phi <8 x i1> [ %588, %schedule.34 ], [ %3045, %convergence.cascade705 ]
  %convergence.cascade.depth710 = phi i32 [ 0, %schedule.34 ], [ %3046, %convergence.cascade705 ]
  %3003 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow709)
  %3004 = load i32, ptr %current.token, align 4
  %3005 = icmp ne i32 %3004, 0
  %3006 = and i1 %3003, %3005
  %3007 = sub i32 %3004, 1
  %3008 = select i1 %3006, i32 %3007, i32 0
  %3009 = load i8, ptr %frame.active, align 1
  %3010 = trunc i32 %3008 to i8
  %3011 = shl i8 1, %3010
  %3012 = and i8 %3009, %3011
  %3013 = icmp ne i8 %3012, 0
  %3014 = load <8 x i32>, ptr %frame.static.id, align 32
  %3015 = extractelement <8 x i32> %3014, i32 %3008
  %convergence.target.pointer711 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %3015
  %convergence.dynamic.target712 = load i32, ptr %convergence.target.pointer711, align 4
  %3016 = icmp eq i32 %convergence.dynamic.target712, 34
  %3017 = and i1 %3013, %3016
  %3018 = and i1 %3006, %3017
  %3019 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3008
  %3020 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3008
  %3021 = load <8 x i1>, ptr %3019, align 1
  %3022 = load <8 x i1>, ptr %3020, align 1
  %3023 = or <8 x i1> %3022, %convergence.cascade.flow709
  %3024 = load <8 x i1>, ptr %live.mask, align 1
  %3025 = and <8 x i1> %3021, %3024
  %3026 = icmp eq <8 x i1> %3023, %3025
  %3027 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3026)
  %3028 = and i1 %3018, %3027
  %3029 = select i1 %3028, <8 x i1> zeroinitializer, <8 x i1> %3023
  %3030 = select i1 %3018, <8 x i1> %3029, <8 x i1> %3022
  store <8 x i1> %3030, ptr %3020, align 1
  %3031 = select i1 %3028, <8 x i1> zeroinitializer, <8 x i1> %3021
  store <8 x i1> %3031, ptr %3019, align 1
  %3032 = trunc i32 %3008 to i8
  %3033 = shl i8 1, %3032
  %3034 = xor i8 %3033, -1
  %3035 = and i8 %3009, %3034
  %3036 = select i1 %3028, i8 %3035, i8 %3009
  store i8 %3036, ptr %frame.active, align 1
  %.splatinsert713 = insertelement <8 x i1> poison, i1 %3018, i64 0
  %.splat714 = shufflevector <8 x i1> %.splatinsert713, <8 x i1> poison, <8 x i32> zeroinitializer
  %3037 = and <8 x i1> %convergence.cascade.flow709, %.splat714
  %3038 = load <8 x i1>, ptr %runnable.mask, align 1
  %3039 = xor <8 x i1> %3037, splat (i1 true)
  %3040 = and <8 x i1> %3038, %3039
  store <8 x i1> %3040, ptr %runnable.mask, align 1
  %.splatinsert715 = insertelement <8 x i1> poison, i1 %3028, i64 0
  %.splat716 = shufflevector <8 x i1> %.splatinsert715, <8 x i1> poison, <8 x i32> zeroinitializer
  %3041 = select <8 x i1> %.splat716, <8 x i1> %3023, <8 x i1> zeroinitializer
  %3042 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3043 = extractelement <8 x i32> %3042, i32 %3008
  %3044 = select i1 %3028, i32 %3043, i32 %3004
  store i32 %3044, ptr %current.token, align 4
  %.splatinsert717 = insertelement <8 x i1> poison, i1 %3018, i64 0
  %.splat718 = shufflevector <8 x i1> %.splatinsert717, <8 x i1> poison, <8 x i32> zeroinitializer
  %3045 = select <8 x i1> %.splat718, <8 x i1> %3041, <8 x i1> %convergence.cascade.flow709
  %3046 = add i32 %convergence.cascade.depth710, 1
  %3047 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3045)
  %3048 = icmp ult i32 %3046, 8
  %3049 = and i1 %3047, %3048
  %3050 = and i1 %3018, %3049
  %convergence.parent.token719 = load i32, ptr %current.token, align 4
  %convergence.parent.present720 = icmp ne i32 %convergence.parent.token719, 0
  %3051 = and i1 %3050, %convergence.parent.present720
  br i1 %3051, label %convergence.cascade705, label %convergence.cascade.exit706

convergence.cascade.exit706:                      ; preds = %convergence.cascade705, %schedule.34
  %convergence.cascade.result721 = phi <8 x i1> [ %588, %schedule.34 ], [ %3045, %convergence.cascade705 ]
  %3052 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result721)
  br i1 %3052, label %convergence.target.34.ready, label %scheduler.loop

convergence.target.34.ready:                      ; preds = %convergence.cascade.exit706
  %3053 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result721)
  %3054 = bitcast <8 x i1> %convergence.cascade.result721 to i8
  %3055 = call i8 @llvm.cttz.i8(i8 %3054, i1 false)
  %3056 = zext i8 %3055 to i32
  %3057 = select i1 %3053, i32 %3056, i32 0
  %.state722 = load <8 x float>, ptr %.slot32, align 32
  %.state723 = load <8 x float>, ptr %.slot97, align 32
  %3058 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state722, <8 x float> %.state723)
  %3059 = load volatile <8 x float>, ptr %.spill100, align 32
  %3060 = select <8 x i1> %convergence.cascade.result721, <8 x float> %3058, <8 x float> %3059
  store volatile <8 x float> %3060, ptr %.spill100, align 32
  %.state724 = load <8 x float>, ptr %.slot33, align 32
  %.state725 = load <8 x float>, ptr %.slot99, align 32
  %3061 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state724, <8 x float> %.state725)
  %3062 = load volatile <8 x float>, ptr %.spill101, align 32
  %3063 = select <8 x i1> %convergence.cascade.result721, <8 x float> %3061, <8 x float> %3062
  store volatile <8 x float> %3063, ptr %.spill101, align 32
  %.state726 = load <8 x float>, ptr %.slot32, align 32
  %3064 = fsub <8 x float> %.state726, %3058
  %.state727 = load <8 x float>, ptr %.slot33, align 32
  %3065 = fsub <8 x float> %.state727, %3061
  %3066 = select <8 x i1> %convergence.cascade.result721, <8 x float> %3064, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3066)
  %3067 = load volatile <8 x float>, ptr %.spill102, align 32
  %3068 = select <8 x i1> %convergence.cascade.result721, <8 x float> %native.exp, <8 x float> %3067
  store volatile <8 x float> %3068, ptr %.spill102, align 32
  %3069 = select <8 x i1> %convergence.cascade.result721, <8 x float> %3065, <8 x float> zeroinitializer
  %native.exp728 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3069)
  %3070 = load volatile <8 x float>, ptr %.spill103, align 32
  %3071 = select <8 x i1> %convergence.cascade.result721, <8 x float> %native.exp728, <8 x float> %3070
  store volatile <8 x float> %3071, ptr %.spill103, align 32
  %.spill.load729 = load volatile <8 x float>, ptr %.spill90, align 32
  %3072 = fsub <8 x float> %.spill.load729, %3058
  %.spill.load730 = load volatile <8 x float>, ptr %.spill91, align 32
  %3073 = fsub <8 x float> %.spill.load730, %3058
  %.spill.load731 = load volatile <8 x float>, ptr %.spill92, align 32
  %3074 = fsub <8 x float> %.spill.load731, %3058
  %.spill.load732 = load volatile <8 x float>, ptr %.spill93, align 32
  %3075 = fsub <8 x float> %.spill.load732, %3061
  %.spill.load733 = load volatile <8 x float>, ptr %.spill94, align 32
  %3076 = fsub <8 x float> %.spill.load733, %3061
  %.spill.load734 = load volatile <8 x float>, ptr %.spill95, align 32
  %3077 = fsub <8 x float> %.spill.load734, %3061
  %3078 = select <8 x i1> %convergence.cascade.result721, <8 x float> %3072, <8 x float> zeroinitializer
  %native.exp735 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3078)
  %3079 = select <8 x i1> %convergence.cascade.result721, <8 x float> %3073, <8 x float> zeroinitializer
  %native.exp736 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3079)
  %3080 = select <8 x i1> %convergence.cascade.result721, <8 x float> %3074, <8 x float> zeroinitializer
  %native.exp737 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3080)
  %3081 = select <8 x i1> %convergence.cascade.result721, <8 x float> %3075, <8 x float> zeroinitializer
  %native.exp738 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3081)
  %3082 = select <8 x i1> %convergence.cascade.result721, <8 x float> %3076, <8 x float> zeroinitializer
  %native.exp739 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3082)
  %3083 = select <8 x i1> %convergence.cascade.result721, <8 x float> %3077, <8 x float> zeroinitializer
  %native.exp740 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3083)
  %.spill.load741 = load volatile <8 x i1>, ptr %.spill84, align 1
  %3084 = select <8 x i1> %.spill.load741, <8 x float> %native.exp735, <8 x float> zeroinitializer
  %3085 = load volatile <8 x float>, ptr %.spill104, align 32
  %3086 = select <8 x i1> %convergence.cascade.result721, <8 x float> %3084, <8 x float> %3085
  store volatile <8 x float> %3086, ptr %.spill104, align 32
  %.spill.load742 = load volatile <8 x i1>, ptr %.spill86, align 1
  %3087 = select <8 x i1> %.spill.load742, <8 x float> %native.exp736, <8 x float> zeroinitializer
  %3088 = load volatile <8 x float>, ptr %.spill105, align 32
  %3089 = select <8 x i1> %convergence.cascade.result721, <8 x float> %3087, <8 x float> %3088
  store volatile <8 x float> %3089, ptr %.spill105, align 32
  %.spill.load743 = load volatile <8 x i1>, ptr %.spill88, align 1
  %3090 = select <8 x i1> %.spill.load743, <8 x float> %native.exp737, <8 x float> zeroinitializer
  %3091 = load volatile <8 x float>, ptr %.spill106, align 32
  %3092 = select <8 x i1> %convergence.cascade.result721, <8 x float> %3090, <8 x float> %3091
  store volatile <8 x float> %3092, ptr %.spill106, align 32
  %.spill.load744 = load volatile <8 x i1>, ptr %.spill85, align 1
  %3093 = select <8 x i1> %.spill.load744, <8 x float> %native.exp738, <8 x float> zeroinitializer
  %3094 = load volatile <8 x float>, ptr %.spill107, align 32
  %3095 = select <8 x i1> %convergence.cascade.result721, <8 x float> %3093, <8 x float> %3094
  store volatile <8 x float> %3095, ptr %.spill107, align 32
  %.spill.load745 = load volatile <8 x i1>, ptr %.spill87, align 1
  %3096 = select <8 x i1> %.spill.load745, <8 x float> %native.exp739, <8 x float> zeroinitializer
  %3097 = load volatile <8 x float>, ptr %.spill108, align 32
  %3098 = select <8 x i1> %convergence.cascade.result721, <8 x float> %3096, <8 x float> %3097
  store volatile <8 x float> %3098, ptr %.spill108, align 32
  %.spill.load746 = load volatile <8 x i1>, ptr %.spill89, align 1
  %3099 = select <8 x i1> %.spill.load746, <8 x float> %native.exp740, <8 x float> zeroinitializer
  %3100 = load volatile <8 x float>, ptr %.spill109, align 32
  %3101 = select <8 x i1> %convergence.cascade.result721, <8 x float> %3099, <8 x float> %3100
  store volatile <8 x float> %3101, ptr %.spill109, align 32
  %3102 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill110, align 64
  %3103 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %3104 = extractvalue { <8 x ptr>, <8 x i64> } %3102, 0
  %3105 = select <8 x i1> %convergence.cascade.result721, <8 x ptr> %3103, <8 x ptr> %3104
  %3106 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %3107 = extractvalue { <8 x ptr>, <8 x i64> } %3102, 1
  %3108 = select <8 x i1> %convergence.cascade.result721, <8 x i64> %3106, <8 x i64> %3107
  %3109 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3105, 0
  %3110 = insertvalue { <8 x ptr>, <8 x i64> } %3109, <8 x i64> %3108, 1
  store volatile { <8 x ptr>, <8 x i64> } %3110, ptr %tile_snapshot.spill110, align 64
  %3111 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %3112 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %3113 = add <8 x i64> %3112, zeroinitializer
  %3114 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3111, 0
  %3115 = insertvalue { <8 x ptr>, <8 x i64> } %3114, <8 x i64> %3113, 1
  %3116 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %3117 = extractvalue { <8 x ptr>, <8 x i64> } %3115, 1
  %3118 = extractelement <8 x ptr> %3116, i32 0
  %3119 = extractelement <8 x i64> %3117, i32 %3057
  %3120 = zext i32 %3057 to i64
  %3121 = mul i64 %3120, 4
  %3122 = sub i64 %3119, %3121
  %3123 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result721)
  %3124 = select i1 %3123, i64 %3122, i64 0
  %private.contiguous.address747 = getelementptr i8, ptr %3118, i64 %3124
  %private.contiguous.preserve748 = load <8 x float>, ptr %private.contiguous.address747, align 4
  %3125 = select <8 x i1> %convergence.cascade.result721, <8 x float> %3084, <8 x float> %private.contiguous.preserve748
  store <8 x float> %3125, ptr %private.contiguous.address747, align 4
  %3126 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %3127 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %3128 = add <8 x i64> %3127, splat (i64 32)
  %3129 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3126, 0
  %3130 = insertvalue { <8 x ptr>, <8 x i64> } %3129, <8 x i64> %3128, 1
  %3131 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %3132 = extractvalue { <8 x ptr>, <8 x i64> } %3130, 1
  %3133 = extractelement <8 x ptr> %3131, i32 0
  %3134 = extractelement <8 x i64> %3132, i32 %3057
  %3135 = zext i32 %3057 to i64
  %3136 = mul i64 %3135, 4
  %3137 = sub i64 %3134, %3136
  %3138 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result721)
  %3139 = select i1 %3138, i64 %3137, i64 0
  %private.contiguous.address749 = getelementptr i8, ptr %3133, i64 %3139
  %private.contiguous.preserve750 = load <8 x float>, ptr %private.contiguous.address749, align 4
  %3140 = select <8 x i1> %convergence.cascade.result721, <8 x float> %3087, <8 x float> %private.contiguous.preserve750
  store <8 x float> %3140, ptr %private.contiguous.address749, align 4
  %3141 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %3142 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %3143 = add <8 x i64> %3142, splat (i64 64)
  %3144 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3141, 0
  %3145 = insertvalue { <8 x ptr>, <8 x i64> } %3144, <8 x i64> %3143, 1
  %3146 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %3147 = extractvalue { <8 x ptr>, <8 x i64> } %3145, 1
  %3148 = extractelement <8 x ptr> %3146, i32 0
  %3149 = extractelement <8 x i64> %3147, i32 %3057
  %3150 = zext i32 %3057 to i64
  %3151 = mul i64 %3150, 4
  %3152 = sub i64 %3149, %3151
  %3153 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result721)
  %3154 = select i1 %3153, i64 %3152, i64 0
  %private.contiguous.address751 = getelementptr i8, ptr %3148, i64 %3154
  %private.contiguous.preserve752 = load <8 x float>, ptr %private.contiguous.address751, align 4
  %3155 = select <8 x i1> %convergence.cascade.result721, <8 x float> %3090, <8 x float> %private.contiguous.preserve752
  store <8 x float> %3155, ptr %private.contiguous.address751, align 4
  %3156 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %3157 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %3158 = add <8 x i64> %3157, splat (i64 96)
  %3159 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3156, 0
  %3160 = insertvalue { <8 x ptr>, <8 x i64> } %3159, <8 x i64> %3158, 1
  %3161 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %3162 = extractvalue { <8 x ptr>, <8 x i64> } %3160, 1
  %3163 = extractelement <8 x ptr> %3161, i32 0
  %3164 = extractelement <8 x i64> %3162, i32 %3057
  %3165 = zext i32 %3057 to i64
  %3166 = mul i64 %3165, 4
  %3167 = sub i64 %3164, %3166
  %3168 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result721)
  %3169 = select i1 %3168, i64 %3167, i64 0
  %private.contiguous.address753 = getelementptr i8, ptr %3163, i64 %3169
  %private.contiguous.preserve754 = load <8 x float>, ptr %private.contiguous.address753, align 4
  %3170 = select <8 x i1> %convergence.cascade.result721, <8 x float> %3093, <8 x float> %private.contiguous.preserve754
  store <8 x float> %3170, ptr %private.contiguous.address753, align 4
  %3171 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %3172 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %3173 = add <8 x i64> %3172, splat (i64 128)
  %3174 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3171, 0
  %3175 = insertvalue { <8 x ptr>, <8 x i64> } %3174, <8 x i64> %3173, 1
  %3176 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %3177 = extractvalue { <8 x ptr>, <8 x i64> } %3175, 1
  %3178 = extractelement <8 x ptr> %3176, i32 0
  %3179 = extractelement <8 x i64> %3177, i32 %3057
  %3180 = zext i32 %3057 to i64
  %3181 = mul i64 %3180, 4
  %3182 = sub i64 %3179, %3181
  %3183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result721)
  %3184 = select i1 %3183, i64 %3182, i64 0
  %private.contiguous.address755 = getelementptr i8, ptr %3178, i64 %3184
  %private.contiguous.preserve756 = load <8 x float>, ptr %private.contiguous.address755, align 4
  %3185 = select <8 x i1> %convergence.cascade.result721, <8 x float> %3096, <8 x float> %private.contiguous.preserve756
  store <8 x float> %3185, ptr %private.contiguous.address755, align 4
  %3186 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %3187 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %3188 = add <8 x i64> %3187, splat (i64 160)
  %3189 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3186, 0
  %3190 = insertvalue { <8 x ptr>, <8 x i64> } %3189, <8 x i64> %3188, 1
  %3191 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %3192 = extractvalue { <8 x ptr>, <8 x i64> } %3190, 1
  %3193 = extractelement <8 x ptr> %3191, i32 0
  %3194 = extractelement <8 x i64> %3192, i32 %3057
  %3195 = zext i32 %3057 to i64
  %3196 = mul i64 %3195, 4
  %3197 = sub i64 %3194, %3196
  %3198 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result721)
  %3199 = select i1 %3198, i64 %3197, i64 0
  %private.contiguous.address757 = getelementptr i8, ptr %3193, i64 %3199
  %private.contiguous.preserve758 = load <8 x float>, ptr %private.contiguous.address757, align 4
  %3200 = select <8 x i1> %convergence.cascade.result721, <8 x float> %3099, <8 x float> %private.contiguous.preserve758
  store <8 x float> %3200, ptr %private.contiguous.address757, align 4
  %.state759 = load <8 x float>, ptr %.slot34, align 32
  %3201 = fmul <8 x float> %.state759, %native.exp
  %3202 = load volatile <8 x float>, ptr %.spill111, align 32
  %3203 = select <8 x i1> %convergence.cascade.result721, <8 x float> %3201, <8 x float> %3202
  store volatile <8 x float> %3203, ptr %.spill111, align 32
  %.state760 = load <8 x float>, ptr %.slot35, align 32
  %3204 = fmul <8 x float> %.state760, %native.exp728
  %3205 = load volatile <8 x float>, ptr %.spill112, align 32
  %3206 = select <8 x i1> %convergence.cascade.result721, <8 x float> %3204, <8 x float> %3205
  store volatile <8 x float> %3206, ptr %.spill112, align 32
  %3207 = load <8 x i64>, ptr %.slot113, align 64
  %3208 = select <8 x i1> %convergence.cascade.result721, <8 x i64> zeroinitializer, <8 x i64> %3207
  store <8 x i64> %3208, ptr %.slot113, align 64
  %3209 = load <8 x float>, ptr %.slot114, align 32
  %3210 = select <8 x i1> %convergence.cascade.result721, <8 x float> zeroinitializer, <8 x float> %3209
  store <8 x float> %3210, ptr %.slot114, align 32
  store <8 x i1> %convergence.cascade.result721, ptr %current.mask, align 1
  %3211 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result721)
  br i1 %3211, label %schedule.35, label %scheduler.loop

varying.divergent762:                             ; preds = %schedule.35
  %3212 = load i32, ptr %current.token, align 4
  %3213 = icmp ne i32 %3212, 0
  %3214 = sub i32 %3212, 1
  %3215 = select i1 %3213, i32 %3214, i32 0
  %3216 = load i8, ptr %frame.active, align 1
  %3217 = trunc i32 %3215 to i8
  %3218 = shl i8 1, %3217
  %3219 = and i8 %3216, %3218
  %3220 = icmp ne i8 %3219, 0
  %3221 = load <8 x i32>, ptr %frame.static.id, align 32
  %3222 = extractelement <8 x i32> %3221, i32 %3215
  %3223 = icmp eq i32 %3222, 16
  %3224 = and i1 %3220, %3223
  %3225 = and i1 %3213, %3224
  %3226 = xor i1 %3225, true
  %3227 = and i1 true, %3226
  %3228 = xor i8 %3216, -1
  %3229 = icmp ne i8 %3228, 0
  %3230 = xor i1 %3229, true
  %3231 = and i1 %3227, %3230
  br i1 %3231, label %convergence.overflow.trap764, label %convergence.overflow.resume765

varying.coherent763:                              ; preds = %schedule.35
  br i1 %599, label %varying.coherent.true768, label %varying.coherent.false769

convergence.overflow.trap764:                     ; preds = %varying.divergent762
  call void @llvm.trap()
  unreachable

convergence.overflow.resume765:                   ; preds = %varying.divergent762
  %3232 = call i8 @llvm.cttz.i8(i8 %3228, i1 false)
  %3233 = zext i8 %3232 to i32
  %3234 = select i1 %3229, i32 %3233, i32 0
  %3235 = trunc i32 %3234 to i8
  %3236 = shl i8 1, %3235
  %3237 = or i8 %3216, %3236
  %3238 = select i1 %3227, i8 %3237, i8 %3216
  store i8 %3238, ptr %frame.active, align 1
  %3239 = load <8 x i32>, ptr %frame.static.id, align 32
  %3240 = extractelement <8 x i32> %3239, i32 %3234
  %3241 = select i1 %3227, i32 16, i32 %3240
  %3242 = load <8 x i32>, ptr %frame.static.id, align 32
  %3243 = insertelement <8 x i32> %3242, i32 %3241, i32 %3234
  store <8 x i32> %3243, ptr %frame.static.id, align 32
  %3244 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3245 = extractelement <8 x i32> %3244, i32 %3234
  %3246 = select i1 %3227, i32 %3212, i32 %3245
  %3247 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3248 = insertelement <8 x i32> %3247, i32 %3246, i32 %3234
  store <8 x i32> %3248, ptr %frame.parent.token, align 32
  %3249 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3234
  %3250 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3234
  %3251 = load <8 x i1>, ptr %3249, align 1
  %3252 = load <8 x i1>, ptr %3250, align 1
  %3253 = select i1 %3227, <8 x i1> %589, <8 x i1> %3251
  store <8 x i1> %3253, ptr %3249, align 1
  %3254 = select i1 %3227, <8 x i1> zeroinitializer, <8 x i1> %3252
  store <8 x i1> %3254, ptr %3250, align 1
  %3255 = add i32 %3234, 1
  %3256 = select i1 %3225, i32 %3212, i32 %3255
  %3257 = select i1 true, i32 %3256, i32 %3212
  store i32 %3257, ptr %current.token, align 4
  %3258 = load i32, ptr %current.token, align 4
  %3259 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %596)
  %3260 = load i32, ptr %ready.count, align 4
  %3261 = icmp uge i32 %3260, 8
  %3262 = and i1 %3259, %3261
  br i1 %3262, label %ready.overflow.trap766, label %ready.overflow.resume767

ready.overflow.trap766:                           ; preds = %convergence.overflow.resume765
  call void @llvm.trap()
  unreachable

ready.overflow.resume767:                         ; preds = %convergence.overflow.resume765
  %3263 = select i1 %3259, i32 %3260, i32 0
  %3264 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3263
  %3265 = load <8 x i1>, ptr %3264, align 1
  %3266 = select i1 %3259, <8 x i1> %596, <8 x i1> %3265
  store <8 x i1> %3266, ptr %3264, align 1
  %3267 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3263
  %3268 = load i32, ptr %3267, align 4
  %3269 = select i1 %3259, i32 36, i32 %3268
  store i32 %3269, ptr %3267, align 4
  %3270 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3263
  %3271 = load i32, ptr %3270, align 4
  %3272 = select i1 %3259, i32 %3258, i32 %3271
  store i32 %3272, ptr %3270, align 4
  %3273 = add i32 %3260, 1
  %3274 = select i1 %3259, i32 %3273, i32 %3260
  store i32 %3274, ptr %ready.count, align 4
  %3275 = load <8 x i1>, ptr %runnable.mask, align 1
  %3276 = or <8 x i1> %3275, %596
  store <8 x i1> %3276, ptr %runnable.mask, align 1
  store <8 x i1> %598, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true768:                         ; preds = %varying.coherent763
  store <8 x i1> %589, ptr %current.mask, align 1
  %3277 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %589)
  br i1 %3277, label %schedule.36, label %scheduler.loop

varying.coherent.false769:                        ; preds = %varying.coherent763
  store <8 x i1> %589, ptr %current.mask, align 1
  %3278 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %589)
  br i1 %3278, label %schedule.37, label %scheduler.loop

convergence.cascade777:                           ; preds = %convergence.cascade777, %schedule.37
  %convergence.cascade.flow781 = phi <8 x i1> [ %635, %schedule.37 ], [ %3321, %convergence.cascade777 ]
  %convergence.cascade.depth782 = phi i32 [ 0, %schedule.37 ], [ %3322, %convergence.cascade777 ]
  %3279 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow781)
  %3280 = load i32, ptr %current.token, align 4
  %3281 = icmp ne i32 %3280, 0
  %3282 = and i1 %3279, %3281
  %3283 = sub i32 %3280, 1
  %3284 = select i1 %3282, i32 %3283, i32 0
  %3285 = load i8, ptr %frame.active, align 1
  %3286 = trunc i32 %3284 to i8
  %3287 = shl i8 1, %3286
  %3288 = and i8 %3285, %3287
  %3289 = icmp ne i8 %3288, 0
  %3290 = load <8 x i32>, ptr %frame.static.id, align 32
  %3291 = extractelement <8 x i32> %3290, i32 %3284
  %convergence.target.pointer783 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %3291
  %convergence.dynamic.target784 = load i32, ptr %convergence.target.pointer783, align 4
  %3292 = icmp eq i32 %convergence.dynamic.target784, 37
  %3293 = and i1 %3289, %3292
  %3294 = and i1 %3282, %3293
  %3295 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3284
  %3296 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3284
  %3297 = load <8 x i1>, ptr %3295, align 1
  %3298 = load <8 x i1>, ptr %3296, align 1
  %3299 = or <8 x i1> %3298, %convergence.cascade.flow781
  %3300 = load <8 x i1>, ptr %live.mask, align 1
  %3301 = and <8 x i1> %3297, %3300
  %3302 = icmp eq <8 x i1> %3299, %3301
  %3303 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3302)
  %3304 = and i1 %3294, %3303
  %3305 = select i1 %3304, <8 x i1> zeroinitializer, <8 x i1> %3299
  %3306 = select i1 %3294, <8 x i1> %3305, <8 x i1> %3298
  store <8 x i1> %3306, ptr %3296, align 1
  %3307 = select i1 %3304, <8 x i1> zeroinitializer, <8 x i1> %3297
  store <8 x i1> %3307, ptr %3295, align 1
  %3308 = trunc i32 %3284 to i8
  %3309 = shl i8 1, %3308
  %3310 = xor i8 %3309, -1
  %3311 = and i8 %3285, %3310
  %3312 = select i1 %3304, i8 %3311, i8 %3285
  store i8 %3312, ptr %frame.active, align 1
  %.splatinsert785 = insertelement <8 x i1> poison, i1 %3294, i64 0
  %.splat786 = shufflevector <8 x i1> %.splatinsert785, <8 x i1> poison, <8 x i32> zeroinitializer
  %3313 = and <8 x i1> %convergence.cascade.flow781, %.splat786
  %3314 = load <8 x i1>, ptr %runnable.mask, align 1
  %3315 = xor <8 x i1> %3313, splat (i1 true)
  %3316 = and <8 x i1> %3314, %3315
  store <8 x i1> %3316, ptr %runnable.mask, align 1
  %.splatinsert787 = insertelement <8 x i1> poison, i1 %3304, i64 0
  %.splat788 = shufflevector <8 x i1> %.splatinsert787, <8 x i1> poison, <8 x i32> zeroinitializer
  %3317 = select <8 x i1> %.splat788, <8 x i1> %3299, <8 x i1> zeroinitializer
  %3318 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3319 = extractelement <8 x i32> %3318, i32 %3284
  %3320 = select i1 %3304, i32 %3319, i32 %3280
  store i32 %3320, ptr %current.token, align 4
  %.splatinsert789 = insertelement <8 x i1> poison, i1 %3294, i64 0
  %.splat790 = shufflevector <8 x i1> %.splatinsert789, <8 x i1> poison, <8 x i32> zeroinitializer
  %3321 = select <8 x i1> %.splat790, <8 x i1> %3317, <8 x i1> %convergence.cascade.flow781
  %3322 = add i32 %convergence.cascade.depth782, 1
  %3323 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3321)
  %3324 = icmp ult i32 %3322, 8
  %3325 = and i1 %3323, %3324
  %3326 = and i1 %3294, %3325
  %convergence.parent.token791 = load i32, ptr %current.token, align 4
  %convergence.parent.present792 = icmp ne i32 %convergence.parent.token791, 0
  %3327 = and i1 %3326, %convergence.parent.present792
  br i1 %3327, label %convergence.cascade777, label %convergence.cascade.exit778

convergence.cascade.exit778:                      ; preds = %convergence.cascade777, %schedule.37
  %convergence.cascade.result793 = phi <8 x i1> [ %635, %schedule.37 ], [ %3321, %convergence.cascade777 ]
  %3328 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result793)
  br i1 %3328, label %convergence.target.37.ready, label %scheduler.loop

convergence.target.37.ready:                      ; preds = %convergence.cascade.exit778
  %3329 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result793)
  %3330 = bitcast <8 x i1> %convergence.cascade.result793 to i8
  %3331 = call i8 @llvm.cttz.i8(i8 %3330, i1 false)
  %3332 = zext i8 %3331 to i32
  %3333 = select i1 %3329, i32 %3332, i32 0
  %3334 = load <8 x i64>, ptr %.slot115, align 64
  %3335 = select <8 x i1> %convergence.cascade.result793, <8 x i64> zeroinitializer, <8 x i64> %3334
  store <8 x i64> %3335, ptr %.slot115, align 64
  %3336 = load <8 x float>, ptr %.slot116, align 32
  %3337 = select <8 x i1> %convergence.cascade.result793, <8 x float> zeroinitializer, <8 x float> %3336
  store <8 x float> %3337, ptr %.slot116, align 32
  store <8 x i1> %convergence.cascade.result793, ptr %current.mask, align 1
  %3338 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result793)
  br i1 %3338, label %schedule.38, label %scheduler.loop

varying.divergent795:                             ; preds = %schedule.38
  %3339 = load i32, ptr %current.token, align 4
  %3340 = icmp ne i32 %3339, 0
  %3341 = sub i32 %3339, 1
  %3342 = select i1 %3340, i32 %3341, i32 0
  %3343 = load i8, ptr %frame.active, align 1
  %3344 = trunc i32 %3342 to i8
  %3345 = shl i8 1, %3344
  %3346 = and i8 %3343, %3345
  %3347 = icmp ne i8 %3346, 0
  %3348 = load <8 x i32>, ptr %frame.static.id, align 32
  %3349 = extractelement <8 x i32> %3348, i32 %3342
  %3350 = icmp eq i32 %3349, 17
  %3351 = and i1 %3347, %3350
  %3352 = and i1 %3340, %3351
  %3353 = xor i1 %3352, true
  %3354 = and i1 true, %3353
  %3355 = xor i8 %3343, -1
  %3356 = icmp ne i8 %3355, 0
  %3357 = xor i1 %3356, true
  %3358 = and i1 %3354, %3357
  br i1 %3358, label %convergence.overflow.trap797, label %convergence.overflow.resume798

varying.coherent796:                              ; preds = %schedule.38
  br i1 %646, label %varying.coherent.true801, label %varying.coherent.false802

convergence.overflow.trap797:                     ; preds = %varying.divergent795
  call void @llvm.trap()
  unreachable

convergence.overflow.resume798:                   ; preds = %varying.divergent795
  %3359 = call i8 @llvm.cttz.i8(i8 %3355, i1 false)
  %3360 = zext i8 %3359 to i32
  %3361 = select i1 %3356, i32 %3360, i32 0
  %3362 = trunc i32 %3361 to i8
  %3363 = shl i8 1, %3362
  %3364 = or i8 %3343, %3363
  %3365 = select i1 %3354, i8 %3364, i8 %3343
  store i8 %3365, ptr %frame.active, align 1
  %3366 = load <8 x i32>, ptr %frame.static.id, align 32
  %3367 = extractelement <8 x i32> %3366, i32 %3361
  %3368 = select i1 %3354, i32 17, i32 %3367
  %3369 = load <8 x i32>, ptr %frame.static.id, align 32
  %3370 = insertelement <8 x i32> %3369, i32 %3368, i32 %3361
  store <8 x i32> %3370, ptr %frame.static.id, align 32
  %3371 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3372 = extractelement <8 x i32> %3371, i32 %3361
  %3373 = select i1 %3354, i32 %3339, i32 %3372
  %3374 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3375 = insertelement <8 x i32> %3374, i32 %3373, i32 %3361
  store <8 x i32> %3375, ptr %frame.parent.token, align 32
  %3376 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3361
  %3377 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3361
  %3378 = load <8 x i1>, ptr %3376, align 1
  %3379 = load <8 x i1>, ptr %3377, align 1
  %3380 = select i1 %3354, <8 x i1> %636, <8 x i1> %3378
  store <8 x i1> %3380, ptr %3376, align 1
  %3381 = select i1 %3354, <8 x i1> zeroinitializer, <8 x i1> %3379
  store <8 x i1> %3381, ptr %3377, align 1
  %3382 = add i32 %3361, 1
  %3383 = select i1 %3352, i32 %3339, i32 %3382
  %3384 = select i1 true, i32 %3383, i32 %3339
  store i32 %3384, ptr %current.token, align 4
  %3385 = load i32, ptr %current.token, align 4
  %3386 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %643)
  %3387 = load i32, ptr %ready.count, align 4
  %3388 = icmp uge i32 %3387, 8
  %3389 = and i1 %3386, %3388
  br i1 %3389, label %ready.overflow.trap799, label %ready.overflow.resume800

ready.overflow.trap799:                           ; preds = %convergence.overflow.resume798
  call void @llvm.trap()
  unreachable

ready.overflow.resume800:                         ; preds = %convergence.overflow.resume798
  %3390 = select i1 %3386, i32 %3387, i32 0
  %3391 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3390
  %3392 = load <8 x i1>, ptr %3391, align 1
  %3393 = select i1 %3386, <8 x i1> %643, <8 x i1> %3392
  store <8 x i1> %3393, ptr %3391, align 1
  %3394 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3390
  %3395 = load i32, ptr %3394, align 4
  %3396 = select i1 %3386, i32 39, i32 %3395
  store i32 %3396, ptr %3394, align 4
  %3397 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3390
  %3398 = load i32, ptr %3397, align 4
  %3399 = select i1 %3386, i32 %3385, i32 %3398
  store i32 %3399, ptr %3397, align 4
  %3400 = add i32 %3387, 1
  %3401 = select i1 %3386, i32 %3400, i32 %3387
  store i32 %3401, ptr %ready.count, align 4
  %3402 = load <8 x i1>, ptr %runnable.mask, align 1
  %3403 = or <8 x i1> %3402, %643
  store <8 x i1> %3403, ptr %runnable.mask, align 1
  store <8 x i1> %645, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true801:                         ; preds = %varying.coherent796
  store <8 x i1> %636, ptr %current.mask, align 1
  %3404 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %636)
  br i1 %3404, label %schedule.39, label %scheduler.loop

varying.coherent.false802:                        ; preds = %varying.coherent796
  store <8 x i1> %636, ptr %current.mask, align 1
  %3405 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %636)
  br i1 %3405, label %schedule.40, label %scheduler.loop

convergence.cascade810:                           ; preds = %convergence.cascade810, %schedule.40
  %convergence.cascade.flow814 = phi <8 x i1> [ %682, %schedule.40 ], [ %3448, %convergence.cascade810 ]
  %convergence.cascade.depth815 = phi i32 [ 0, %schedule.40 ], [ %3449, %convergence.cascade810 ]
  %3406 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow814)
  %3407 = load i32, ptr %current.token, align 4
  %3408 = icmp ne i32 %3407, 0
  %3409 = and i1 %3406, %3408
  %3410 = sub i32 %3407, 1
  %3411 = select i1 %3409, i32 %3410, i32 0
  %3412 = load i8, ptr %frame.active, align 1
  %3413 = trunc i32 %3411 to i8
  %3414 = shl i8 1, %3413
  %3415 = and i8 %3412, %3414
  %3416 = icmp ne i8 %3415, 0
  %3417 = load <8 x i32>, ptr %frame.static.id, align 32
  %3418 = extractelement <8 x i32> %3417, i32 %3411
  %convergence.target.pointer816 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %3418
  %convergence.dynamic.target817 = load i32, ptr %convergence.target.pointer816, align 4
  %3419 = icmp eq i32 %convergence.dynamic.target817, 40
  %3420 = and i1 %3416, %3419
  %3421 = and i1 %3409, %3420
  %3422 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3411
  %3423 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3411
  %3424 = load <8 x i1>, ptr %3422, align 1
  %3425 = load <8 x i1>, ptr %3423, align 1
  %3426 = or <8 x i1> %3425, %convergence.cascade.flow814
  %3427 = load <8 x i1>, ptr %live.mask, align 1
  %3428 = and <8 x i1> %3424, %3427
  %3429 = icmp eq <8 x i1> %3426, %3428
  %3430 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3429)
  %3431 = and i1 %3421, %3430
  %3432 = select i1 %3431, <8 x i1> zeroinitializer, <8 x i1> %3426
  %3433 = select i1 %3421, <8 x i1> %3432, <8 x i1> %3425
  store <8 x i1> %3433, ptr %3423, align 1
  %3434 = select i1 %3431, <8 x i1> zeroinitializer, <8 x i1> %3424
  store <8 x i1> %3434, ptr %3422, align 1
  %3435 = trunc i32 %3411 to i8
  %3436 = shl i8 1, %3435
  %3437 = xor i8 %3436, -1
  %3438 = and i8 %3412, %3437
  %3439 = select i1 %3431, i8 %3438, i8 %3412
  store i8 %3439, ptr %frame.active, align 1
  %.splatinsert818 = insertelement <8 x i1> poison, i1 %3421, i64 0
  %.splat819 = shufflevector <8 x i1> %.splatinsert818, <8 x i1> poison, <8 x i32> zeroinitializer
  %3440 = and <8 x i1> %convergence.cascade.flow814, %.splat819
  %3441 = load <8 x i1>, ptr %runnable.mask, align 1
  %3442 = xor <8 x i1> %3440, splat (i1 true)
  %3443 = and <8 x i1> %3441, %3442
  store <8 x i1> %3443, ptr %runnable.mask, align 1
  %.splatinsert820 = insertelement <8 x i1> poison, i1 %3431, i64 0
  %.splat821 = shufflevector <8 x i1> %.splatinsert820, <8 x i1> poison, <8 x i32> zeroinitializer
  %3444 = select <8 x i1> %.splat821, <8 x i1> %3426, <8 x i1> zeroinitializer
  %3445 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3446 = extractelement <8 x i32> %3445, i32 %3411
  %3447 = select i1 %3431, i32 %3446, i32 %3407
  store i32 %3447, ptr %current.token, align 4
  %.splatinsert822 = insertelement <8 x i1> poison, i1 %3421, i64 0
  %.splat823 = shufflevector <8 x i1> %.splatinsert822, <8 x i1> poison, <8 x i32> zeroinitializer
  %3448 = select <8 x i1> %.splat823, <8 x i1> %3444, <8 x i1> %convergence.cascade.flow814
  %3449 = add i32 %convergence.cascade.depth815, 1
  %3450 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3448)
  %3451 = icmp ult i32 %3449, 8
  %3452 = and i1 %3450, %3451
  %3453 = and i1 %3421, %3452
  %convergence.parent.token824 = load i32, ptr %current.token, align 4
  %convergence.parent.present825 = icmp ne i32 %convergence.parent.token824, 0
  %3454 = and i1 %3453, %convergence.parent.present825
  br i1 %3454, label %convergence.cascade810, label %convergence.cascade.exit811

convergence.cascade.exit811:                      ; preds = %convergence.cascade810, %schedule.40
  %convergence.cascade.result826 = phi <8 x i1> [ %682, %schedule.40 ], [ %3448, %convergence.cascade810 ]
  %3455 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result826)
  br i1 %3455, label %convergence.target.40.ready, label %scheduler.loop

convergence.target.40.ready:                      ; preds = %convergence.cascade.exit811
  %3456 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result826)
  %3457 = bitcast <8 x i1> %convergence.cascade.result826 to i8
  %3458 = call i8 @llvm.cttz.i8(i8 %3457, i1 false)
  %3459 = zext i8 %3458 to i32
  %3460 = select i1 %3456, i32 %3459, i32 0
  %.spill.load827 = load volatile <8 x float>, ptr %.spill111, align 32
  %.state828 = load <8 x float>, ptr %.slot114, align 32
  %3461 = fadd <8 x float> %.spill.load827, %.state828
  %.spill.load829 = load volatile <8 x float>, ptr %.spill112, align 32
  %.state830 = load <8 x float>, ptr %.slot116, align 32
  %3462 = fadd <8 x float> %.spill.load829, %.state830
  %.state831 = load <8 x float>, ptr %.slot36, align 32
  %.spill.load832 = load volatile <8 x float>, ptr %.spill102, align 32
  %3463 = fmul <8 x float> %.state831, %.spill.load832
  %.state833 = load <8 x float>, ptr %.slot37, align 32
  %.spill.load834 = load volatile <8 x float>, ptr %.spill102, align 32
  %3464 = fmul <8 x float> %.state833, %.spill.load834
  %.state835 = load <8 x float>, ptr %.slot38, align 32
  %.spill.load836 = load volatile <8 x float>, ptr %.spill102, align 32
  %3465 = fmul <8 x float> %.state835, %.spill.load836
  %.state837 = load <8 x float>, ptr %.slot39, align 32
  %.spill.load838 = load volatile <8 x float>, ptr %.spill103, align 32
  %3466 = fmul <8 x float> %.state837, %.spill.load838
  %.state839 = load <8 x float>, ptr %.slot40, align 32
  %.spill.load840 = load volatile <8 x float>, ptr %.spill103, align 32
  %3467 = fmul <8 x float> %.state839, %.spill.load840
  %.state841 = load <8 x float>, ptr %.slot41, align 32
  %.spill.load842 = load volatile <8 x float>, ptr %.spill103, align 32
  %3468 = fmul <8 x float> %.state841, %.spill.load842
  %.spill.load843 = load volatile <8 x float>, ptr %.spill104, align 32
  %.spill.load844 = load volatile <8 x float>, ptr %.spill71, align 32
  %3469 = fmul <8 x float> %.spill.load843, %.spill.load844
  %3470 = fadd <8 x float> %3463, %3469
  %.spill.load845 = load volatile <8 x float>, ptr %.spill105, align 32
  %.spill.load846 = load volatile <8 x float>, ptr %.spill74, align 32
  %3471 = fmul <8 x float> %.spill.load845, %.spill.load846
  %3472 = fadd <8 x float> %3470, %3471
  %.spill.load847 = load volatile <8 x float>, ptr %.spill106, align 32
  %.state848 = load <8 x float>, ptr %.slot79, align 32
  %3473 = fmul <8 x float> %.spill.load847, %.state848
  %3474 = fadd <8 x float> %3472, %3473
  %.spill.load849 = load volatile <8 x float>, ptr %.spill104, align 32
  %.spill.load850 = load volatile <8 x float>, ptr %.spill72, align 32
  %3475 = fmul <8 x float> %.spill.load849, %.spill.load850
  %3476 = fadd <8 x float> %3464, %3475
  %.spill.load851 = load volatile <8 x float>, ptr %.spill105, align 32
  %.spill.load852 = load volatile <8 x float>, ptr %.spill75, align 32
  %3477 = fmul <8 x float> %.spill.load851, %.spill.load852
  %3478 = fadd <8 x float> %3476, %3477
  %.spill.load853 = load volatile <8 x float>, ptr %.spill106, align 32
  %.state854 = load <8 x float>, ptr %.slot81, align 32
  %3479 = fmul <8 x float> %.spill.load853, %.state854
  %3480 = fadd <8 x float> %3478, %3479
  %.spill.load855 = load volatile <8 x float>, ptr %.spill104, align 32
  %.spill.load856 = load volatile <8 x float>, ptr %.spill73, align 32
  %3481 = fmul <8 x float> %.spill.load855, %.spill.load856
  %3482 = fadd <8 x float> %3465, %3481
  %.spill.load857 = load volatile <8 x float>, ptr %.spill105, align 32
  %.spill.load858 = load volatile <8 x float>, ptr %.spill76, align 32
  %3483 = fmul <8 x float> %.spill.load857, %.spill.load858
  %3484 = fadd <8 x float> %3482, %3483
  %.spill.load859 = load volatile <8 x float>, ptr %.spill106, align 32
  %.state860 = load <8 x float>, ptr %.slot83, align 32
  %3485 = fmul <8 x float> %.spill.load859, %.state860
  %3486 = fadd <8 x float> %3484, %3485
  %.spill.load861 = load volatile <8 x float>, ptr %.spill107, align 32
  %.spill.load862 = load volatile <8 x float>, ptr %.spill71, align 32
  %3487 = fmul <8 x float> %.spill.load861, %.spill.load862
  %3488 = fadd <8 x float> %3466, %3487
  %.spill.load863 = load volatile <8 x float>, ptr %.spill108, align 32
  %.spill.load864 = load volatile <8 x float>, ptr %.spill74, align 32
  %3489 = fmul <8 x float> %.spill.load863, %.spill.load864
  %3490 = fadd <8 x float> %3488, %3489
  %.spill.load865 = load volatile <8 x float>, ptr %.spill109, align 32
  %.state866 = load <8 x float>, ptr %.slot79, align 32
  %3491 = fmul <8 x float> %.spill.load865, %.state866
  %3492 = fadd <8 x float> %3490, %3491
  %.spill.load867 = load volatile <8 x float>, ptr %.spill107, align 32
  %.spill.load868 = load volatile <8 x float>, ptr %.spill72, align 32
  %3493 = fmul <8 x float> %.spill.load867, %.spill.load868
  %3494 = fadd <8 x float> %3467, %3493
  %.spill.load869 = load volatile <8 x float>, ptr %.spill108, align 32
  %.spill.load870 = load volatile <8 x float>, ptr %.spill75, align 32
  %3495 = fmul <8 x float> %.spill.load869, %.spill.load870
  %3496 = fadd <8 x float> %3494, %3495
  %.spill.load871 = load volatile <8 x float>, ptr %.spill109, align 32
  %.state872 = load <8 x float>, ptr %.slot81, align 32
  %3497 = fmul <8 x float> %.spill.load871, %.state872
  %3498 = fadd <8 x float> %3496, %3497
  %.spill.load873 = load volatile <8 x float>, ptr %.spill107, align 32
  %.spill.load874 = load volatile <8 x float>, ptr %.spill73, align 32
  %3499 = fmul <8 x float> %.spill.load873, %.spill.load874
  %3500 = fadd <8 x float> %3468, %3499
  %.spill.load875 = load volatile <8 x float>, ptr %.spill108, align 32
  %.spill.load876 = load volatile <8 x float>, ptr %.spill76, align 32
  %3501 = fmul <8 x float> %.spill.load875, %.spill.load876
  %3502 = fadd <8 x float> %3500, %3501
  %.spill.load877 = load volatile <8 x float>, ptr %.spill109, align 32
  %.state878 = load <8 x float>, ptr %.slot83, align 32
  %3503 = fmul <8 x float> %.spill.load877, %.state878
  %3504 = fadd <8 x float> %3502, %3503
  %.state879 = load <8 x i64>, ptr %.slot31, align 64
  %3505 = add <8 x i64> %.state879, splat (i64 1)
  %.spill.load880 = load volatile <8 x float>, ptr %.spill100, align 32
  %.spill.load881 = load volatile <8 x float>, ptr %.spill101, align 32
  %3506 = load <8 x i64>, ptr %.slot31, align 64
  %3507 = select <8 x i1> %convergence.cascade.result826, <8 x i64> %3505, <8 x i64> %3506
  store <8 x i64> %3507, ptr %.slot31, align 64
  %3508 = load <8 x float>, ptr %.slot32, align 32
  %3509 = select <8 x i1> %convergence.cascade.result826, <8 x float> %.spill.load880, <8 x float> %3508
  store <8 x float> %3509, ptr %.slot32, align 32
  %3510 = load <8 x float>, ptr %.slot33, align 32
  %3511 = select <8 x i1> %convergence.cascade.result826, <8 x float> %.spill.load881, <8 x float> %3510
  store <8 x float> %3511, ptr %.slot33, align 32
  %3512 = load <8 x float>, ptr %.slot34, align 32
  %3513 = select <8 x i1> %convergence.cascade.result826, <8 x float> %3461, <8 x float> %3512
  store <8 x float> %3513, ptr %.slot34, align 32
  %3514 = load <8 x float>, ptr %.slot35, align 32
  %3515 = select <8 x i1> %convergence.cascade.result826, <8 x float> %3462, <8 x float> %3514
  store <8 x float> %3515, ptr %.slot35, align 32
  %3516 = load <8 x float>, ptr %.slot36, align 32
  %3517 = select <8 x i1> %convergence.cascade.result826, <8 x float> %3474, <8 x float> %3516
  store <8 x float> %3517, ptr %.slot36, align 32
  %3518 = load <8 x float>, ptr %.slot37, align 32
  %3519 = select <8 x i1> %convergence.cascade.result826, <8 x float> %3480, <8 x float> %3518
  store <8 x float> %3519, ptr %.slot37, align 32
  %3520 = load <8 x float>, ptr %.slot38, align 32
  %3521 = select <8 x i1> %convergence.cascade.result826, <8 x float> %3486, <8 x float> %3520
  store <8 x float> %3521, ptr %.slot38, align 32
  %3522 = load <8 x float>, ptr %.slot39, align 32
  %3523 = select <8 x i1> %convergence.cascade.result826, <8 x float> %3492, <8 x float> %3522
  store <8 x float> %3523, ptr %.slot39, align 32
  %3524 = load <8 x float>, ptr %.slot40, align 32
  %3525 = select <8 x i1> %convergence.cascade.result826, <8 x float> %3498, <8 x float> %3524
  store <8 x float> %3525, ptr %.slot40, align 32
  %3526 = load <8 x float>, ptr %.slot41, align 32
  %3527 = select <8 x i1> %convergence.cascade.result826, <8 x float> %3504, <8 x float> %3526
  store <8 x float> %3527, ptr %.slot41, align 32
  store <8 x i1> %convergence.cascade.result826, ptr %current.mask, align 1
  %3528 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result826)
  br i1 %3528, label %schedule.11, label %scheduler.loop

convergence.cascade882:                           ; preds = %convergence.cascade882, %schedule.41
  %convergence.cascade.flow886 = phi <8 x i1> [ %683, %schedule.41 ], [ %3571, %convergence.cascade882 ]
  %convergence.cascade.depth887 = phi i32 [ 0, %schedule.41 ], [ %3572, %convergence.cascade882 ]
  %3529 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow886)
  %3530 = load i32, ptr %current.token, align 4
  %3531 = icmp ne i32 %3530, 0
  %3532 = and i1 %3529, %3531
  %3533 = sub i32 %3530, 1
  %3534 = select i1 %3532, i32 %3533, i32 0
  %3535 = load i8, ptr %frame.active, align 1
  %3536 = trunc i32 %3534 to i8
  %3537 = shl i8 1, %3536
  %3538 = and i8 %3535, %3537
  %3539 = icmp ne i8 %3538, 0
  %3540 = load <8 x i32>, ptr %frame.static.id, align 32
  %3541 = extractelement <8 x i32> %3540, i32 %3534
  %convergence.target.pointer888 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %3541
  %convergence.dynamic.target889 = load i32, ptr %convergence.target.pointer888, align 4
  %3542 = icmp eq i32 %convergence.dynamic.target889, 41
  %3543 = and i1 %3539, %3542
  %3544 = and i1 %3532, %3543
  %3545 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3534
  %3546 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3534
  %3547 = load <8 x i1>, ptr %3545, align 1
  %3548 = load <8 x i1>, ptr %3546, align 1
  %3549 = or <8 x i1> %3548, %convergence.cascade.flow886
  %3550 = load <8 x i1>, ptr %live.mask, align 1
  %3551 = and <8 x i1> %3547, %3550
  %3552 = icmp eq <8 x i1> %3549, %3551
  %3553 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3552)
  %3554 = and i1 %3544, %3553
  %3555 = select i1 %3554, <8 x i1> zeroinitializer, <8 x i1> %3549
  %3556 = select i1 %3544, <8 x i1> %3555, <8 x i1> %3548
  store <8 x i1> %3556, ptr %3546, align 1
  %3557 = select i1 %3554, <8 x i1> zeroinitializer, <8 x i1> %3547
  store <8 x i1> %3557, ptr %3545, align 1
  %3558 = trunc i32 %3534 to i8
  %3559 = shl i8 1, %3558
  %3560 = xor i8 %3559, -1
  %3561 = and i8 %3535, %3560
  %3562 = select i1 %3554, i8 %3561, i8 %3535
  store i8 %3562, ptr %frame.active, align 1
  %.splatinsert890 = insertelement <8 x i1> poison, i1 %3544, i64 0
  %.splat891 = shufflevector <8 x i1> %.splatinsert890, <8 x i1> poison, <8 x i32> zeroinitializer
  %3563 = and <8 x i1> %convergence.cascade.flow886, %.splat891
  %3564 = load <8 x i1>, ptr %runnable.mask, align 1
  %3565 = xor <8 x i1> %3563, splat (i1 true)
  %3566 = and <8 x i1> %3564, %3565
  store <8 x i1> %3566, ptr %runnable.mask, align 1
  %.splatinsert892 = insertelement <8 x i1> poison, i1 %3554, i64 0
  %.splat893 = shufflevector <8 x i1> %.splatinsert892, <8 x i1> poison, <8 x i32> zeroinitializer
  %3567 = select <8 x i1> %.splat893, <8 x i1> %3549, <8 x i1> zeroinitializer
  %3568 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3569 = extractelement <8 x i32> %3568, i32 %3534
  %3570 = select i1 %3554, i32 %3569, i32 %3530
  store i32 %3570, ptr %current.token, align 4
  %.splatinsert894 = insertelement <8 x i1> poison, i1 %3544, i64 0
  %.splat895 = shufflevector <8 x i1> %.splatinsert894, <8 x i1> poison, <8 x i32> zeroinitializer
  %3571 = select <8 x i1> %.splat895, <8 x i1> %3567, <8 x i1> %convergence.cascade.flow886
  %3572 = add i32 %convergence.cascade.depth887, 1
  %3573 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3571)
  %3574 = icmp ult i32 %3572, 8
  %3575 = and i1 %3573, %3574
  %3576 = and i1 %3544, %3575
  %convergence.parent.token896 = load i32, ptr %current.token, align 4
  %convergence.parent.present897 = icmp ne i32 %convergence.parent.token896, 0
  %3577 = and i1 %3576, %convergence.parent.present897
  br i1 %3577, label %convergence.cascade882, label %convergence.cascade.exit883

convergence.cascade.exit883:                      ; preds = %convergence.cascade882, %schedule.41
  %convergence.cascade.result898 = phi <8 x i1> [ %683, %schedule.41 ], [ %3571, %convergence.cascade882 ]
  %3578 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result898)
  br i1 %3578, label %convergence.target.41.ready, label %scheduler.loop

convergence.target.41.ready:                      ; preds = %convergence.cascade.exit883
  %3579 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result898)
  %3580 = bitcast <8 x i1> %convergence.cascade.result898 to i8
  %3581 = call i8 @llvm.cttz.i8(i8 %3580, i1 false)
  %3582 = zext i8 %3581 to i32
  %3583 = select i1 %3579, i32 %3582, i32 0
  %.state899 = load <8 x float>, ptr %.slot36, align 32
  %.state900 = load <8 x float>, ptr %.slot34, align 32
  %3584 = fdiv <8 x float> %.state899, %.state900
  %.state901 = load <8 x float>, ptr %.slot37, align 32
  %.state902 = load <8 x float>, ptr %.slot34, align 32
  %3585 = fdiv <8 x float> %.state901, %.state902
  %.state903 = load <8 x float>, ptr %.slot38, align 32
  %.state904 = load <8 x float>, ptr %.slot34, align 32
  %3586 = fdiv <8 x float> %.state903, %.state904
  %.state905 = load <8 x float>, ptr %.slot39, align 32
  %.state906 = load <8 x float>, ptr %.slot35, align 32
  %3587 = fdiv <8 x float> %.state905, %.state906
  %3588 = load volatile <8 x float>, ptr %.spill117, align 32
  %3589 = select <8 x i1> %convergence.cascade.result898, <8 x float> %3587, <8 x float> %3588
  store volatile <8 x float> %3589, ptr %.spill117, align 32
  %.state907 = load <8 x float>, ptr %.slot40, align 32
  %.state908 = load <8 x float>, ptr %.slot35, align 32
  %3590 = fdiv <8 x float> %.state907, %.state908
  %3591 = load volatile <8 x float>, ptr %.spill118, align 32
  %3592 = select <8 x i1> %convergence.cascade.result898, <8 x float> %3590, <8 x float> %3591
  store volatile <8 x float> %3592, ptr %.spill118, align 32
  %.state909 = load <8 x float>, ptr %.slot41, align 32
  %.state910 = load <8 x float>, ptr %.slot35, align 32
  %3593 = fdiv <8 x float> %.state909, %.state910
  %3594 = load volatile <8 x float>, ptr %.spill119, align 32
  %3595 = select <8 x i1> %convergence.cascade.result898, <8 x float> %3593, <8 x float> %3594
  store volatile <8 x float> %3595, ptr %.spill119, align 32
  %.spill.load911 = load volatile <8 x i64>, ptr %.spill8, align 64
  %3596 = mul <8 x i64> %.spill.load911, splat (i64 3)
  %.spill.load912 = load i64, ptr %.spill4, align 4
  %.splatinsert913 = insertelement <8 x i64> poison, i64 %.spill.load912, i64 0
  %.splat914 = shufflevector <8 x i64> %.splatinsert913, <8 x i64> poison, <8 x i32> zeroinitializer
  %3597 = add <8 x i64> %3596, %.splat914
  %3598 = extractvalue { ptr, i64 } %27, 0
  %3599 = mul <8 x i64> %3597, splat (i64 4)
  %3600 = getelementptr i8, ptr %3598, <8 x i64> %3599
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %3584, <8 x ptr> align 1 %3600, <8 x i1> %convergence.cascade.result898)
  %.spill.load915 = load i64, ptr %.spill10, align 4
  %.splatinsert916 = insertelement <8 x i64> poison, i64 %.spill.load915, i64 0
  %.splat917 = shufflevector <8 x i64> %.splatinsert916, <8 x i64> poison, <8 x i32> zeroinitializer
  %3601 = add <8 x i64> %3596, %.splat917
  %3602 = extractvalue { ptr, i64 } %27, 0
  %3603 = mul <8 x i64> %3601, splat (i64 4)
  %3604 = getelementptr i8, ptr %3602, <8 x i64> %3603
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %3585, <8 x ptr> align 1 %3604, <8 x i1> %convergence.cascade.result898)
  %.spill.load918 = load i64, ptr %.spill12, align 4
  %.splatinsert919 = insertelement <8 x i64> poison, i64 %.spill.load918, i64 0
  %.splat920 = shufflevector <8 x i64> %.splatinsert919, <8 x i64> poison, <8 x i32> zeroinitializer
  %3605 = add <8 x i64> %3596, %.splat920
  %3606 = extractvalue { ptr, i64 } %27, 0
  %3607 = mul <8 x i64> %3605, splat (i64 4)
  %3608 = getelementptr i8, ptr %3606, <8 x i64> %3607
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %3586, <8 x ptr> align 1 %3608, <8 x i1> %convergence.cascade.result898)
  %.spill.load921 = load volatile <8 x i64>, ptr %.spill19, align 64
  %3609 = mul <8 x i64> %.spill.load921, splat (i64 3)
  %3610 = load volatile <8 x i64>, ptr %.spill120, align 64
  %3611 = select <8 x i1> %convergence.cascade.result898, <8 x i64> %3609, <8 x i64> %3610
  store volatile <8 x i64> %3611, ptr %.spill120, align 64
  %.spill.load922 = load i64, ptr %.spill4, align 4
  %.splatinsert923 = insertelement <8 x i64> poison, i64 %.spill.load922, i64 0
  %.splat924 = shufflevector <8 x i64> %.splatinsert923, <8 x i64> poison, <8 x i32> zeroinitializer
  %3612 = add <8 x i64> %3609, %.splat924
  %3613 = load volatile <8 x i64>, ptr %.spill121, align 64
  %3614 = select <8 x i1> %convergence.cascade.result898, <8 x i64> %3612, <8 x i64> %3613
  store volatile <8 x i64> %3614, ptr %.spill121, align 64
  %.spill.load925 = load <8 x i1>, ptr %.spill20, align 1
  %3615 = and <8 x i1> %convergence.cascade.result898, %.spill.load925
  %3616 = xor <8 x i1> %.spill.load925, splat (i1 true)
  %3617 = and <8 x i1> %convergence.cascade.result898, %3616
  %3618 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3615)
  %3619 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3617)
  %3620 = and i1 %3618, %3619
  br i1 %3620, label %varying.divergent926, label %varying.coherent927

varying.divergent926:                             ; preds = %convergence.target.41.ready
  %3621 = load i32, ptr %current.token, align 4
  %3622 = icmp ne i32 %3621, 0
  %3623 = sub i32 %3621, 1
  %3624 = select i1 %3622, i32 %3623, i32 0
  %3625 = load i8, ptr %frame.active, align 1
  %3626 = trunc i32 %3624 to i8
  %3627 = shl i8 1, %3626
  %3628 = and i8 %3625, %3627
  %3629 = icmp ne i8 %3628, 0
  %3630 = load <8 x i32>, ptr %frame.static.id, align 32
  %3631 = extractelement <8 x i32> %3630, i32 %3624
  %3632 = icmp eq i32 %3631, 18
  %3633 = and i1 %3629, %3632
  %3634 = and i1 %3622, %3633
  %3635 = xor i1 %3634, true
  %3636 = and i1 true, %3635
  %3637 = xor i8 %3625, -1
  %3638 = icmp ne i8 %3637, 0
  %3639 = xor i1 %3638, true
  %3640 = and i1 %3636, %3639
  br i1 %3640, label %convergence.overflow.trap928, label %convergence.overflow.resume929

varying.coherent927:                              ; preds = %convergence.target.41.ready
  br i1 %3618, label %varying.coherent.true932, label %varying.coherent.false933

convergence.overflow.trap928:                     ; preds = %varying.divergent926
  call void @llvm.trap()
  unreachable

convergence.overflow.resume929:                   ; preds = %varying.divergent926
  %3641 = call i8 @llvm.cttz.i8(i8 %3637, i1 false)
  %3642 = zext i8 %3641 to i32
  %3643 = select i1 %3638, i32 %3642, i32 0
  %3644 = trunc i32 %3643 to i8
  %3645 = shl i8 1, %3644
  %3646 = or i8 %3625, %3645
  %3647 = select i1 %3636, i8 %3646, i8 %3625
  store i8 %3647, ptr %frame.active, align 1
  %3648 = load <8 x i32>, ptr %frame.static.id, align 32
  %3649 = extractelement <8 x i32> %3648, i32 %3643
  %3650 = select i1 %3636, i32 18, i32 %3649
  %3651 = load <8 x i32>, ptr %frame.static.id, align 32
  %3652 = insertelement <8 x i32> %3651, i32 %3650, i32 %3643
  store <8 x i32> %3652, ptr %frame.static.id, align 32
  %3653 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3654 = extractelement <8 x i32> %3653, i32 %3643
  %3655 = select i1 %3636, i32 %3621, i32 %3654
  %3656 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3657 = insertelement <8 x i32> %3656, i32 %3655, i32 %3643
  store <8 x i32> %3657, ptr %frame.parent.token, align 32
  %3658 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3643
  %3659 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3643
  %3660 = load <8 x i1>, ptr %3658, align 1
  %3661 = load <8 x i1>, ptr %3659, align 1
  %3662 = select i1 %3636, <8 x i1> %convergence.cascade.result898, <8 x i1> %3660
  store <8 x i1> %3662, ptr %3658, align 1
  %3663 = select i1 %3636, <8 x i1> zeroinitializer, <8 x i1> %3661
  store <8 x i1> %3663, ptr %3659, align 1
  %3664 = add i32 %3643, 1
  %3665 = select i1 %3634, i32 %3621, i32 %3664
  %3666 = select i1 true, i32 %3665, i32 %3621
  store i32 %3666, ptr %current.token, align 4
  %3667 = load i32, ptr %current.token, align 4
  %3668 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3615)
  %3669 = load i32, ptr %ready.count, align 4
  %3670 = icmp uge i32 %3669, 8
  %3671 = and i1 %3668, %3670
  br i1 %3671, label %ready.overflow.trap930, label %ready.overflow.resume931

ready.overflow.trap930:                           ; preds = %convergence.overflow.resume929
  call void @llvm.trap()
  unreachable

ready.overflow.resume931:                         ; preds = %convergence.overflow.resume929
  %3672 = select i1 %3668, i32 %3669, i32 0
  %3673 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3672
  %3674 = load <8 x i1>, ptr %3673, align 1
  %3675 = select i1 %3668, <8 x i1> %3615, <8 x i1> %3674
  store <8 x i1> %3675, ptr %3673, align 1
  %3676 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3672
  %3677 = load i32, ptr %3676, align 4
  %3678 = select i1 %3668, i32 42, i32 %3677
  store i32 %3678, ptr %3676, align 4
  %3679 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3672
  %3680 = load i32, ptr %3679, align 4
  %3681 = select i1 %3668, i32 %3667, i32 %3680
  store i32 %3681, ptr %3679, align 4
  %3682 = add i32 %3669, 1
  %3683 = select i1 %3668, i32 %3682, i32 %3669
  store i32 %3683, ptr %ready.count, align 4
  %3684 = load <8 x i1>, ptr %runnable.mask, align 1
  %3685 = or <8 x i1> %3684, %3615
  store <8 x i1> %3685, ptr %runnable.mask, align 1
  store <8 x i1> %3617, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true932:                         ; preds = %varying.coherent927
  store <8 x i1> %convergence.cascade.result898, ptr %current.mask, align 1
  %3686 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result898)
  br i1 %3686, label %schedule.42, label %scheduler.loop

varying.coherent.false933:                        ; preds = %varying.coherent927
  store <8 x i1> %convergence.cascade.result898, ptr %current.mask, align 1
  %3687 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result898)
  br i1 %3687, label %schedule.43, label %scheduler.loop

convergence.cascade936:                           ; preds = %convergence.cascade936, %schedule.43
  %convergence.cascade.flow940 = phi <8 x i1> [ %694, %schedule.43 ], [ %3730, %convergence.cascade936 ]
  %convergence.cascade.depth941 = phi i32 [ 0, %schedule.43 ], [ %3731, %convergence.cascade936 ]
  %3688 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow940)
  %3689 = load i32, ptr %current.token, align 4
  %3690 = icmp ne i32 %3689, 0
  %3691 = and i1 %3688, %3690
  %3692 = sub i32 %3689, 1
  %3693 = select i1 %3691, i32 %3692, i32 0
  %3694 = load i8, ptr %frame.active, align 1
  %3695 = trunc i32 %3693 to i8
  %3696 = shl i8 1, %3695
  %3697 = and i8 %3694, %3696
  %3698 = icmp ne i8 %3697, 0
  %3699 = load <8 x i32>, ptr %frame.static.id, align 32
  %3700 = extractelement <8 x i32> %3699, i32 %3693
  %convergence.target.pointer942 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %3700
  %convergence.dynamic.target943 = load i32, ptr %convergence.target.pointer942, align 4
  %3701 = icmp eq i32 %convergence.dynamic.target943, 43
  %3702 = and i1 %3698, %3701
  %3703 = and i1 %3691, %3702
  %3704 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3693
  %3705 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3693
  %3706 = load <8 x i1>, ptr %3704, align 1
  %3707 = load <8 x i1>, ptr %3705, align 1
  %3708 = or <8 x i1> %3707, %convergence.cascade.flow940
  %3709 = load <8 x i1>, ptr %live.mask, align 1
  %3710 = and <8 x i1> %3706, %3709
  %3711 = icmp eq <8 x i1> %3708, %3710
  %3712 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3711)
  %3713 = and i1 %3703, %3712
  %3714 = select i1 %3713, <8 x i1> zeroinitializer, <8 x i1> %3708
  %3715 = select i1 %3703, <8 x i1> %3714, <8 x i1> %3707
  store <8 x i1> %3715, ptr %3705, align 1
  %3716 = select i1 %3713, <8 x i1> zeroinitializer, <8 x i1> %3706
  store <8 x i1> %3716, ptr %3704, align 1
  %3717 = trunc i32 %3693 to i8
  %3718 = shl i8 1, %3717
  %3719 = xor i8 %3718, -1
  %3720 = and i8 %3694, %3719
  %3721 = select i1 %3713, i8 %3720, i8 %3694
  store i8 %3721, ptr %frame.active, align 1
  %.splatinsert944 = insertelement <8 x i1> poison, i1 %3703, i64 0
  %.splat945 = shufflevector <8 x i1> %.splatinsert944, <8 x i1> poison, <8 x i32> zeroinitializer
  %3722 = and <8 x i1> %convergence.cascade.flow940, %.splat945
  %3723 = load <8 x i1>, ptr %runnable.mask, align 1
  %3724 = xor <8 x i1> %3722, splat (i1 true)
  %3725 = and <8 x i1> %3723, %3724
  store <8 x i1> %3725, ptr %runnable.mask, align 1
  %.splatinsert946 = insertelement <8 x i1> poison, i1 %3713, i64 0
  %.splat947 = shufflevector <8 x i1> %.splatinsert946, <8 x i1> poison, <8 x i32> zeroinitializer
  %3726 = select <8 x i1> %.splat947, <8 x i1> %3708, <8 x i1> zeroinitializer
  %3727 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3728 = extractelement <8 x i32> %3727, i32 %3693
  %3729 = select i1 %3713, i32 %3728, i32 %3689
  store i32 %3729, ptr %current.token, align 4
  %.splatinsert948 = insertelement <8 x i1> poison, i1 %3703, i64 0
  %.splat949 = shufflevector <8 x i1> %.splatinsert948, <8 x i1> poison, <8 x i32> zeroinitializer
  %3730 = select <8 x i1> %.splat949, <8 x i1> %3726, <8 x i1> %convergence.cascade.flow940
  %3731 = add i32 %convergence.cascade.depth941, 1
  %3732 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3730)
  %3733 = icmp ult i32 %3731, 8
  %3734 = and i1 %3732, %3733
  %3735 = and i1 %3703, %3734
  %convergence.parent.token950 = load i32, ptr %current.token, align 4
  %convergence.parent.present951 = icmp ne i32 %convergence.parent.token950, 0
  %3736 = and i1 %3735, %convergence.parent.present951
  br i1 %3736, label %convergence.cascade936, label %convergence.cascade.exit937

convergence.cascade.exit937:                      ; preds = %convergence.cascade936, %schedule.43
  %convergence.cascade.result952 = phi <8 x i1> [ %694, %schedule.43 ], [ %3730, %convergence.cascade936 ]
  %3737 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result952)
  br i1 %3737, label %convergence.target.43.ready, label %scheduler.loop

convergence.target.43.ready:                      ; preds = %convergence.cascade.exit937
  %3738 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result952)
  %3739 = bitcast <8 x i1> %convergence.cascade.result952 to i8
  %3740 = call i8 @llvm.cttz.i8(i8 %3739, i1 false)
  %3741 = zext i8 %3740 to i32
  %3742 = select i1 %3738, i32 %3741, i32 0
  %.spill.load953 = load volatile <8 x i64>, ptr %.spill120, align 64
  %.spill.load954 = load i64, ptr %.spill10, align 4
  %.splatinsert955 = insertelement <8 x i64> poison, i64 %.spill.load954, i64 0
  %.splat956 = shufflevector <8 x i64> %.splatinsert955, <8 x i64> poison, <8 x i32> zeroinitializer
  %3743 = add <8 x i64> %.spill.load953, %.splat956
  %3744 = load volatile <8 x i64>, ptr %.spill122, align 64
  %3745 = select <8 x i1> %convergence.cascade.result952, <8 x i64> %3743, <8 x i64> %3744
  store volatile <8 x i64> %3745, ptr %.spill122, align 64
  %.spill.load957 = load <8 x i1>, ptr %.spill20, align 1
  %3746 = and <8 x i1> %convergence.cascade.result952, %.spill.load957
  %3747 = xor <8 x i1> %.spill.load957, splat (i1 true)
  %3748 = and <8 x i1> %convergence.cascade.result952, %3747
  %3749 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3746)
  %3750 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3748)
  %3751 = and i1 %3749, %3750
  br i1 %3751, label %varying.divergent958, label %varying.coherent959

varying.divergent958:                             ; preds = %convergence.target.43.ready
  %3752 = load i32, ptr %current.token, align 4
  %3753 = icmp ne i32 %3752, 0
  %3754 = sub i32 %3752, 1
  %3755 = select i1 %3753, i32 %3754, i32 0
  %3756 = load i8, ptr %frame.active, align 1
  %3757 = trunc i32 %3755 to i8
  %3758 = shl i8 1, %3757
  %3759 = and i8 %3756, %3758
  %3760 = icmp ne i8 %3759, 0
  %3761 = load <8 x i32>, ptr %frame.static.id, align 32
  %3762 = extractelement <8 x i32> %3761, i32 %3755
  %3763 = icmp eq i32 %3762, 19
  %3764 = and i1 %3760, %3763
  %3765 = and i1 %3753, %3764
  %3766 = xor i1 %3765, true
  %3767 = and i1 true, %3766
  %3768 = xor i8 %3756, -1
  %3769 = icmp ne i8 %3768, 0
  %3770 = xor i1 %3769, true
  %3771 = and i1 %3767, %3770
  br i1 %3771, label %convergence.overflow.trap960, label %convergence.overflow.resume961

varying.coherent959:                              ; preds = %convergence.target.43.ready
  br i1 %3749, label %varying.coherent.true964, label %varying.coherent.false965

convergence.overflow.trap960:                     ; preds = %varying.divergent958
  call void @llvm.trap()
  unreachable

convergence.overflow.resume961:                   ; preds = %varying.divergent958
  %3772 = call i8 @llvm.cttz.i8(i8 %3768, i1 false)
  %3773 = zext i8 %3772 to i32
  %3774 = select i1 %3769, i32 %3773, i32 0
  %3775 = trunc i32 %3774 to i8
  %3776 = shl i8 1, %3775
  %3777 = or i8 %3756, %3776
  %3778 = select i1 %3767, i8 %3777, i8 %3756
  store i8 %3778, ptr %frame.active, align 1
  %3779 = load <8 x i32>, ptr %frame.static.id, align 32
  %3780 = extractelement <8 x i32> %3779, i32 %3774
  %3781 = select i1 %3767, i32 19, i32 %3780
  %3782 = load <8 x i32>, ptr %frame.static.id, align 32
  %3783 = insertelement <8 x i32> %3782, i32 %3781, i32 %3774
  store <8 x i32> %3783, ptr %frame.static.id, align 32
  %3784 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3785 = extractelement <8 x i32> %3784, i32 %3774
  %3786 = select i1 %3767, i32 %3752, i32 %3785
  %3787 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3788 = insertelement <8 x i32> %3787, i32 %3786, i32 %3774
  store <8 x i32> %3788, ptr %frame.parent.token, align 32
  %3789 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3774
  %3790 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3774
  %3791 = load <8 x i1>, ptr %3789, align 1
  %3792 = load <8 x i1>, ptr %3790, align 1
  %3793 = select i1 %3767, <8 x i1> %convergence.cascade.result952, <8 x i1> %3791
  store <8 x i1> %3793, ptr %3789, align 1
  %3794 = select i1 %3767, <8 x i1> zeroinitializer, <8 x i1> %3792
  store <8 x i1> %3794, ptr %3790, align 1
  %3795 = add i32 %3774, 1
  %3796 = select i1 %3765, i32 %3752, i32 %3795
  %3797 = select i1 true, i32 %3796, i32 %3752
  store i32 %3797, ptr %current.token, align 4
  %3798 = load i32, ptr %current.token, align 4
  %3799 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3746)
  %3800 = load i32, ptr %ready.count, align 4
  %3801 = icmp uge i32 %3800, 8
  %3802 = and i1 %3799, %3801
  br i1 %3802, label %ready.overflow.trap962, label %ready.overflow.resume963

ready.overflow.trap962:                           ; preds = %convergence.overflow.resume961
  call void @llvm.trap()
  unreachable

ready.overflow.resume963:                         ; preds = %convergence.overflow.resume961
  %3803 = select i1 %3799, i32 %3800, i32 0
  %3804 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3803
  %3805 = load <8 x i1>, ptr %3804, align 1
  %3806 = select i1 %3799, <8 x i1> %3746, <8 x i1> %3805
  store <8 x i1> %3806, ptr %3804, align 1
  %3807 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3803
  %3808 = load i32, ptr %3807, align 4
  %3809 = select i1 %3799, i32 44, i32 %3808
  store i32 %3809, ptr %3807, align 4
  %3810 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3803
  %3811 = load i32, ptr %3810, align 4
  %3812 = select i1 %3799, i32 %3798, i32 %3811
  store i32 %3812, ptr %3810, align 4
  %3813 = add i32 %3800, 1
  %3814 = select i1 %3799, i32 %3813, i32 %3800
  store i32 %3814, ptr %ready.count, align 4
  %3815 = load <8 x i1>, ptr %runnable.mask, align 1
  %3816 = or <8 x i1> %3815, %3746
  store <8 x i1> %3816, ptr %runnable.mask, align 1
  store <8 x i1> %3748, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true964:                         ; preds = %varying.coherent959
  store <8 x i1> %convergence.cascade.result952, ptr %current.mask, align 1
  %3817 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result952)
  br i1 %3817, label %schedule.44, label %scheduler.loop

varying.coherent.false965:                        ; preds = %varying.coherent959
  store <8 x i1> %convergence.cascade.result952, ptr %current.mask, align 1
  %3818 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result952)
  br i1 %3818, label %schedule.45, label %scheduler.loop

convergence.cascade968:                           ; preds = %convergence.cascade968, %schedule.45
  %convergence.cascade.flow972 = phi <8 x i1> [ %705, %schedule.45 ], [ %3861, %convergence.cascade968 ]
  %convergence.cascade.depth973 = phi i32 [ 0, %schedule.45 ], [ %3862, %convergence.cascade968 ]
  %3819 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow972)
  %3820 = load i32, ptr %current.token, align 4
  %3821 = icmp ne i32 %3820, 0
  %3822 = and i1 %3819, %3821
  %3823 = sub i32 %3820, 1
  %3824 = select i1 %3822, i32 %3823, i32 0
  %3825 = load i8, ptr %frame.active, align 1
  %3826 = trunc i32 %3824 to i8
  %3827 = shl i8 1, %3826
  %3828 = and i8 %3825, %3827
  %3829 = icmp ne i8 %3828, 0
  %3830 = load <8 x i32>, ptr %frame.static.id, align 32
  %3831 = extractelement <8 x i32> %3830, i32 %3824
  %convergence.target.pointer974 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %3831
  %convergence.dynamic.target975 = load i32, ptr %convergence.target.pointer974, align 4
  %3832 = icmp eq i32 %convergence.dynamic.target975, 45
  %3833 = and i1 %3829, %3832
  %3834 = and i1 %3822, %3833
  %3835 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3824
  %3836 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3824
  %3837 = load <8 x i1>, ptr %3835, align 1
  %3838 = load <8 x i1>, ptr %3836, align 1
  %3839 = or <8 x i1> %3838, %convergence.cascade.flow972
  %3840 = load <8 x i1>, ptr %live.mask, align 1
  %3841 = and <8 x i1> %3837, %3840
  %3842 = icmp eq <8 x i1> %3839, %3841
  %3843 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3842)
  %3844 = and i1 %3834, %3843
  %3845 = select i1 %3844, <8 x i1> zeroinitializer, <8 x i1> %3839
  %3846 = select i1 %3834, <8 x i1> %3845, <8 x i1> %3838
  store <8 x i1> %3846, ptr %3836, align 1
  %3847 = select i1 %3844, <8 x i1> zeroinitializer, <8 x i1> %3837
  store <8 x i1> %3847, ptr %3835, align 1
  %3848 = trunc i32 %3824 to i8
  %3849 = shl i8 1, %3848
  %3850 = xor i8 %3849, -1
  %3851 = and i8 %3825, %3850
  %3852 = select i1 %3844, i8 %3851, i8 %3825
  store i8 %3852, ptr %frame.active, align 1
  %.splatinsert976 = insertelement <8 x i1> poison, i1 %3834, i64 0
  %.splat977 = shufflevector <8 x i1> %.splatinsert976, <8 x i1> poison, <8 x i32> zeroinitializer
  %3853 = and <8 x i1> %convergence.cascade.flow972, %.splat977
  %3854 = load <8 x i1>, ptr %runnable.mask, align 1
  %3855 = xor <8 x i1> %3853, splat (i1 true)
  %3856 = and <8 x i1> %3854, %3855
  store <8 x i1> %3856, ptr %runnable.mask, align 1
  %.splatinsert978 = insertelement <8 x i1> poison, i1 %3844, i64 0
  %.splat979 = shufflevector <8 x i1> %.splatinsert978, <8 x i1> poison, <8 x i32> zeroinitializer
  %3857 = select <8 x i1> %.splat979, <8 x i1> %3839, <8 x i1> zeroinitializer
  %3858 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3859 = extractelement <8 x i32> %3858, i32 %3824
  %3860 = select i1 %3844, i32 %3859, i32 %3820
  store i32 %3860, ptr %current.token, align 4
  %.splatinsert980 = insertelement <8 x i1> poison, i1 %3834, i64 0
  %.splat981 = shufflevector <8 x i1> %.splatinsert980, <8 x i1> poison, <8 x i32> zeroinitializer
  %3861 = select <8 x i1> %.splat981, <8 x i1> %3857, <8 x i1> %convergence.cascade.flow972
  %3862 = add i32 %convergence.cascade.depth973, 1
  %3863 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3861)
  %3864 = icmp ult i32 %3862, 8
  %3865 = and i1 %3863, %3864
  %3866 = and i1 %3834, %3865
  %convergence.parent.token982 = load i32, ptr %current.token, align 4
  %convergence.parent.present983 = icmp ne i32 %convergence.parent.token982, 0
  %3867 = and i1 %3866, %convergence.parent.present983
  br i1 %3867, label %convergence.cascade968, label %convergence.cascade.exit969

convergence.cascade.exit969:                      ; preds = %convergence.cascade968, %schedule.45
  %convergence.cascade.result984 = phi <8 x i1> [ %705, %schedule.45 ], [ %3861, %convergence.cascade968 ]
  %3868 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result984)
  br i1 %3868, label %convergence.target.45.ready, label %scheduler.loop

convergence.target.45.ready:                      ; preds = %convergence.cascade.exit969
  %3869 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result984)
  %3870 = bitcast <8 x i1> %convergence.cascade.result984 to i8
  %3871 = call i8 @llvm.cttz.i8(i8 %3870, i1 false)
  %3872 = zext i8 %3871 to i32
  %3873 = select i1 %3869, i32 %3872, i32 0
  %.spill.load985 = load volatile <8 x i64>, ptr %.spill120, align 64
  %.spill.load986 = load i64, ptr %.spill12, align 4
  %.splatinsert987 = insertelement <8 x i64> poison, i64 %.spill.load986, i64 0
  %.splat988 = shufflevector <8 x i64> %.splatinsert987, <8 x i64> poison, <8 x i32> zeroinitializer
  %3874 = add <8 x i64> %.spill.load985, %.splat988
  %3875 = load volatile <8 x i64>, ptr %.spill123, align 64
  %3876 = select <8 x i1> %convergence.cascade.result984, <8 x i64> %3874, <8 x i64> %3875
  store volatile <8 x i64> %3876, ptr %.spill123, align 64
  %.spill.load989 = load <8 x i1>, ptr %.spill20, align 1
  %3877 = and <8 x i1> %convergence.cascade.result984, %.spill.load989
  %3878 = xor <8 x i1> %.spill.load989, splat (i1 true)
  %3879 = and <8 x i1> %convergence.cascade.result984, %3878
  %3880 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3877)
  %3881 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3879)
  %3882 = and i1 %3880, %3881
  br i1 %3882, label %varying.divergent990, label %varying.coherent991

varying.divergent990:                             ; preds = %convergence.target.45.ready
  %3883 = load i32, ptr %current.token, align 4
  %3884 = icmp ne i32 %3883, 0
  %3885 = sub i32 %3883, 1
  %3886 = select i1 %3884, i32 %3885, i32 0
  %3887 = load i8, ptr %frame.active, align 1
  %3888 = trunc i32 %3886 to i8
  %3889 = shl i8 1, %3888
  %3890 = and i8 %3887, %3889
  %3891 = icmp ne i8 %3890, 0
  %3892 = load <8 x i32>, ptr %frame.static.id, align 32
  %3893 = extractelement <8 x i32> %3892, i32 %3886
  %3894 = icmp eq i32 %3893, 20
  %3895 = and i1 %3891, %3894
  %3896 = and i1 %3884, %3895
  %3897 = xor i1 %3896, true
  %3898 = and i1 true, %3897
  %3899 = xor i8 %3887, -1
  %3900 = icmp ne i8 %3899, 0
  %3901 = xor i1 %3900, true
  %3902 = and i1 %3898, %3901
  br i1 %3902, label %convergence.overflow.trap992, label %convergence.overflow.resume993

varying.coherent991:                              ; preds = %convergence.target.45.ready
  br i1 %3880, label %varying.coherent.true996, label %varying.coherent.false997

convergence.overflow.trap992:                     ; preds = %varying.divergent990
  call void @llvm.trap()
  unreachable

convergence.overflow.resume993:                   ; preds = %varying.divergent990
  %3903 = call i8 @llvm.cttz.i8(i8 %3899, i1 false)
  %3904 = zext i8 %3903 to i32
  %3905 = select i1 %3900, i32 %3904, i32 0
  %3906 = trunc i32 %3905 to i8
  %3907 = shl i8 1, %3906
  %3908 = or i8 %3887, %3907
  %3909 = select i1 %3898, i8 %3908, i8 %3887
  store i8 %3909, ptr %frame.active, align 1
  %3910 = load <8 x i32>, ptr %frame.static.id, align 32
  %3911 = extractelement <8 x i32> %3910, i32 %3905
  %3912 = select i1 %3898, i32 20, i32 %3911
  %3913 = load <8 x i32>, ptr %frame.static.id, align 32
  %3914 = insertelement <8 x i32> %3913, i32 %3912, i32 %3905
  store <8 x i32> %3914, ptr %frame.static.id, align 32
  %3915 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3916 = extractelement <8 x i32> %3915, i32 %3905
  %3917 = select i1 %3898, i32 %3883, i32 %3916
  %3918 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3919 = insertelement <8 x i32> %3918, i32 %3917, i32 %3905
  store <8 x i32> %3919, ptr %frame.parent.token, align 32
  %3920 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3905
  %3921 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3905
  %3922 = load <8 x i1>, ptr %3920, align 1
  %3923 = load <8 x i1>, ptr %3921, align 1
  %3924 = select i1 %3898, <8 x i1> %convergence.cascade.result984, <8 x i1> %3922
  store <8 x i1> %3924, ptr %3920, align 1
  %3925 = select i1 %3898, <8 x i1> zeroinitializer, <8 x i1> %3923
  store <8 x i1> %3925, ptr %3921, align 1
  %3926 = add i32 %3905, 1
  %3927 = select i1 %3896, i32 %3883, i32 %3926
  %3928 = select i1 true, i32 %3927, i32 %3883
  store i32 %3928, ptr %current.token, align 4
  %3929 = load i32, ptr %current.token, align 4
  %3930 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3877)
  %3931 = load i32, ptr %ready.count, align 4
  %3932 = icmp uge i32 %3931, 8
  %3933 = and i1 %3930, %3932
  br i1 %3933, label %ready.overflow.trap994, label %ready.overflow.resume995

ready.overflow.trap994:                           ; preds = %convergence.overflow.resume993
  call void @llvm.trap()
  unreachable

ready.overflow.resume995:                         ; preds = %convergence.overflow.resume993
  %3934 = select i1 %3930, i32 %3931, i32 0
  %3935 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3934
  %3936 = load <8 x i1>, ptr %3935, align 1
  %3937 = select i1 %3930, <8 x i1> %3877, <8 x i1> %3936
  store <8 x i1> %3937, ptr %3935, align 1
  %3938 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3934
  %3939 = load i32, ptr %3938, align 4
  %3940 = select i1 %3930, i32 46, i32 %3939
  store i32 %3940, ptr %3938, align 4
  %3941 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3934
  %3942 = load i32, ptr %3941, align 4
  %3943 = select i1 %3930, i32 %3929, i32 %3942
  store i32 %3943, ptr %3941, align 4
  %3944 = add i32 %3931, 1
  %3945 = select i1 %3930, i32 %3944, i32 %3931
  store i32 %3945, ptr %ready.count, align 4
  %3946 = load <8 x i1>, ptr %runnable.mask, align 1
  %3947 = or <8 x i1> %3946, %3877
  store <8 x i1> %3947, ptr %runnable.mask, align 1
  store <8 x i1> %3879, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true996:                         ; preds = %varying.coherent991
  store <8 x i1> %convergence.cascade.result984, ptr %current.mask, align 1
  %3948 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result984)
  br i1 %3948, label %schedule.46, label %scheduler.loop

varying.coherent.false997:                        ; preds = %varying.coherent991
  store <8 x i1> %convergence.cascade.result984, ptr %current.mask, align 1
  %3949 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result984)
  br i1 %3949, label %schedule.47, label %scheduler.loop

convergence.cascade1000:                          ; preds = %convergence.cascade1000, %schedule.47
  %convergence.cascade.flow1004 = phi <8 x i1> [ %716, %schedule.47 ], [ %3992, %convergence.cascade1000 ]
  %convergence.cascade.depth1005 = phi i32 [ 0, %schedule.47 ], [ %3993, %convergence.cascade1000 ]
  %3950 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1004)
  %3951 = load i32, ptr %current.token, align 4
  %3952 = icmp ne i32 %3951, 0
  %3953 = and i1 %3950, %3952
  %3954 = sub i32 %3951, 1
  %3955 = select i1 %3953, i32 %3954, i32 0
  %3956 = load i8, ptr %frame.active, align 1
  %3957 = trunc i32 %3955 to i8
  %3958 = shl i8 1, %3957
  %3959 = and i8 %3956, %3958
  %3960 = icmp ne i8 %3959, 0
  %3961 = load <8 x i32>, ptr %frame.static.id, align 32
  %3962 = extractelement <8 x i32> %3961, i32 %3955
  %convergence.target.pointer1006 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %3962
  %convergence.dynamic.target1007 = load i32, ptr %convergence.target.pointer1006, align 4
  %3963 = icmp eq i32 %convergence.dynamic.target1007, 47
  %3964 = and i1 %3960, %3963
  %3965 = and i1 %3953, %3964
  %3966 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3955
  %3967 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3955
  %3968 = load <8 x i1>, ptr %3966, align 1
  %3969 = load <8 x i1>, ptr %3967, align 1
  %3970 = or <8 x i1> %3969, %convergence.cascade.flow1004
  %3971 = load <8 x i1>, ptr %live.mask, align 1
  %3972 = and <8 x i1> %3968, %3971
  %3973 = icmp eq <8 x i1> %3970, %3972
  %3974 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3973)
  %3975 = and i1 %3965, %3974
  %3976 = select i1 %3975, <8 x i1> zeroinitializer, <8 x i1> %3970
  %3977 = select i1 %3965, <8 x i1> %3976, <8 x i1> %3969
  store <8 x i1> %3977, ptr %3967, align 1
  %3978 = select i1 %3975, <8 x i1> zeroinitializer, <8 x i1> %3968
  store <8 x i1> %3978, ptr %3966, align 1
  %3979 = trunc i32 %3955 to i8
  %3980 = shl i8 1, %3979
  %3981 = xor i8 %3980, -1
  %3982 = and i8 %3956, %3981
  %3983 = select i1 %3975, i8 %3982, i8 %3956
  store i8 %3983, ptr %frame.active, align 1
  %.splatinsert1008 = insertelement <8 x i1> poison, i1 %3965, i64 0
  %.splat1009 = shufflevector <8 x i1> %.splatinsert1008, <8 x i1> poison, <8 x i32> zeroinitializer
  %3984 = and <8 x i1> %convergence.cascade.flow1004, %.splat1009
  %3985 = load <8 x i1>, ptr %runnable.mask, align 1
  %3986 = xor <8 x i1> %3984, splat (i1 true)
  %3987 = and <8 x i1> %3985, %3986
  store <8 x i1> %3987, ptr %runnable.mask, align 1
  %.splatinsert1010 = insertelement <8 x i1> poison, i1 %3975, i64 0
  %.splat1011 = shufflevector <8 x i1> %.splatinsert1010, <8 x i1> poison, <8 x i32> zeroinitializer
  %3988 = select <8 x i1> %.splat1011, <8 x i1> %3970, <8 x i1> zeroinitializer
  %3989 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3990 = extractelement <8 x i32> %3989, i32 %3955
  %3991 = select i1 %3975, i32 %3990, i32 %3951
  store i32 %3991, ptr %current.token, align 4
  %.splatinsert1012 = insertelement <8 x i1> poison, i1 %3965, i64 0
  %.splat1013 = shufflevector <8 x i1> %.splatinsert1012, <8 x i1> poison, <8 x i32> zeroinitializer
  %3992 = select <8 x i1> %.splat1013, <8 x i1> %3988, <8 x i1> %convergence.cascade.flow1004
  %3993 = add i32 %convergence.cascade.depth1005, 1
  %3994 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3992)
  %3995 = icmp ult i32 %3993, 8
  %3996 = and i1 %3994, %3995
  %3997 = and i1 %3965, %3996
  %convergence.parent.token1014 = load i32, ptr %current.token, align 4
  %convergence.parent.present1015 = icmp ne i32 %convergence.parent.token1014, 0
  %3998 = and i1 %3997, %convergence.parent.present1015
  br i1 %3998, label %convergence.cascade1000, label %convergence.cascade.exit1001

convergence.cascade.exit1001:                     ; preds = %convergence.cascade1000, %schedule.47
  %convergence.cascade.result1016 = phi <8 x i1> [ %716, %schedule.47 ], [ %3992, %convergence.cascade1000 ]
  %3999 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1016)
  br i1 %3999, label %convergence.target.47.ready, label %scheduler.loop

convergence.target.47.ready:                      ; preds = %convergence.cascade.exit1001
  %4000 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1016)
  %4001 = bitcast <8 x i1> %convergence.cascade.result1016 to i8
  %4002 = call i8 @llvm.cttz.i8(i8 %4001, i1 false)
  %4003 = zext i8 %4002 to i32
  %4004 = select i1 %4000, i32 %4003, i32 0
  %4005 = load <8 x i1>, ptr %live.mask, align 1
  %4006 = xor <8 x i1> %convergence.cascade.result1016, splat (i1 true)
  %4007 = and <8 x i1> %4005, %4006
  store <8 x i1> %4007, ptr %live.mask, align 1
  %4008 = load <8 x i1>, ptr %runnable.mask, align 1
  %4009 = xor <8 x i1> %convergence.cascade.result1016, splat (i1 true)
  %4010 = and <8 x i1> %4008, %4009
  store <8 x i1> %4010, ptr %runnable.mask, align 1
  %return.active.frames = load i8, ptr %frame.active, align 1
  %return.frames.present = icmp ne i8 %return.active.frames, 0
  br i1 %return.frames.present, label %return.frame.cleanup, label %return.frame.cleanup.done

return.frame.cleanup:                             ; preds = %convergence.target.47.ready
  %4011 = load i8, ptr %frame.active, align 1
  %4012 = and i8 %4011, 1
  %4013 = icmp ne i8 %4012, 0
  %4014 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 0
  %4015 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 0
  %4016 = load <8 x i1>, ptr %4014, align 1
  %4017 = load <8 x i1>, ptr %4015, align 1
  %4018 = and <8 x i1> %4016, %4007
  %4019 = icmp eq <8 x i1> %4017, %4018
  %4020 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4019)
  %4021 = and i1 %4013, %4020
  %.splatinsert1017 = insertelement <8 x i1> poison, i1 %4021, i64 0
  %.splat1018 = shufflevector <8 x i1> %.splatinsert1017, <8 x i1> poison, <8 x i32> zeroinitializer
  %4022 = select <8 x i1> %.splat1018, <8 x i1> %4017, <8 x i1> zeroinitializer
  %4023 = select i1 %4021, <8 x i1> zeroinitializer, <8 x i1> %4018
  store <8 x i1> %4023, ptr %4014, align 1
  %4024 = select i1 %4021, <8 x i1> zeroinitializer, <8 x i1> %4017
  store <8 x i1> %4024, ptr %4015, align 1
  %4025 = and i8 %4011, -2
  %4026 = select i1 %4021, i8 %4025, i8 %4011
  store i8 %4026, ptr %frame.active, align 1
  %4027 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4028 = extractelement <8 x i32> %4027, i32 0
  %4029 = load <8 x i32>, ptr %frame.static.id, align 32
  %4030 = extractelement <8 x i32> %4029, i32 0
  %convergence.target.pointer1019 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %4030
  %convergence.dynamic.target1020 = load i32, ptr %convergence.target.pointer1019, align 4
  %4031 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4022)
  %4032 = load i32, ptr %ready.count, align 4
  %4033 = icmp uge i32 %4032, 8
  %4034 = and i1 %4031, %4033
  br i1 %4034, label %ready.overflow.trap1021, label %ready.overflow.resume1022

return.frame.cleanup.done:                        ; preds = %ready.overflow.resume1064, %convergence.target.47.ready
  br label %scheduler.loop

ready.overflow.trap1021:                          ; preds = %return.frame.cleanup
  call void @llvm.trap()
  unreachable

ready.overflow.resume1022:                        ; preds = %return.frame.cleanup
  %4035 = select i1 %4031, i32 %4032, i32 0
  %4036 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4035
  %4037 = load <8 x i1>, ptr %4036, align 1
  %4038 = select i1 %4031, <8 x i1> %4022, <8 x i1> %4037
  store <8 x i1> %4038, ptr %4036, align 1
  %4039 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4035
  %4040 = load i32, ptr %4039, align 4
  %4041 = select i1 %4031, i32 %convergence.dynamic.target1020, i32 %4040
  store i32 %4041, ptr %4039, align 4
  %4042 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4035
  %4043 = load i32, ptr %4042, align 4
  %4044 = select i1 %4031, i32 %4028, i32 %4043
  store i32 %4044, ptr %4042, align 4
  %4045 = add i32 %4032, 1
  %4046 = select i1 %4031, i32 %4045, i32 %4032
  store i32 %4046, ptr %ready.count, align 4
  %4047 = load <8 x i1>, ptr %runnable.mask, align 1
  %4048 = or <8 x i1> %4047, %4022
  store <8 x i1> %4048, ptr %runnable.mask, align 1
  %4049 = load i8, ptr %frame.active, align 1
  %4050 = and i8 %4049, 2
  %4051 = icmp ne i8 %4050, 0
  %4052 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 1
  %4053 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 1
  %4054 = load <8 x i1>, ptr %4052, align 1
  %4055 = load <8 x i1>, ptr %4053, align 1
  %4056 = and <8 x i1> %4054, %4007
  %4057 = icmp eq <8 x i1> %4055, %4056
  %4058 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4057)
  %4059 = and i1 %4051, %4058
  %.splatinsert1023 = insertelement <8 x i1> poison, i1 %4059, i64 0
  %.splat1024 = shufflevector <8 x i1> %.splatinsert1023, <8 x i1> poison, <8 x i32> zeroinitializer
  %4060 = select <8 x i1> %.splat1024, <8 x i1> %4055, <8 x i1> zeroinitializer
  %4061 = select i1 %4059, <8 x i1> zeroinitializer, <8 x i1> %4056
  store <8 x i1> %4061, ptr %4052, align 1
  %4062 = select i1 %4059, <8 x i1> zeroinitializer, <8 x i1> %4055
  store <8 x i1> %4062, ptr %4053, align 1
  %4063 = and i8 %4049, -3
  %4064 = select i1 %4059, i8 %4063, i8 %4049
  store i8 %4064, ptr %frame.active, align 1
  %4065 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4066 = extractelement <8 x i32> %4065, i32 1
  %4067 = load <8 x i32>, ptr %frame.static.id, align 32
  %4068 = extractelement <8 x i32> %4067, i32 1
  %convergence.target.pointer1025 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %4068
  %convergence.dynamic.target1026 = load i32, ptr %convergence.target.pointer1025, align 4
  %4069 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4060)
  %4070 = load i32, ptr %ready.count, align 4
  %4071 = icmp uge i32 %4070, 8
  %4072 = and i1 %4069, %4071
  br i1 %4072, label %ready.overflow.trap1027, label %ready.overflow.resume1028

ready.overflow.trap1027:                          ; preds = %ready.overflow.resume1022
  call void @llvm.trap()
  unreachable

ready.overflow.resume1028:                        ; preds = %ready.overflow.resume1022
  %4073 = select i1 %4069, i32 %4070, i32 0
  %4074 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4073
  %4075 = load <8 x i1>, ptr %4074, align 1
  %4076 = select i1 %4069, <8 x i1> %4060, <8 x i1> %4075
  store <8 x i1> %4076, ptr %4074, align 1
  %4077 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4073
  %4078 = load i32, ptr %4077, align 4
  %4079 = select i1 %4069, i32 %convergence.dynamic.target1026, i32 %4078
  store i32 %4079, ptr %4077, align 4
  %4080 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4073
  %4081 = load i32, ptr %4080, align 4
  %4082 = select i1 %4069, i32 %4066, i32 %4081
  store i32 %4082, ptr %4080, align 4
  %4083 = add i32 %4070, 1
  %4084 = select i1 %4069, i32 %4083, i32 %4070
  store i32 %4084, ptr %ready.count, align 4
  %4085 = load <8 x i1>, ptr %runnable.mask, align 1
  %4086 = or <8 x i1> %4085, %4060
  store <8 x i1> %4086, ptr %runnable.mask, align 1
  %4087 = load i8, ptr %frame.active, align 1
  %4088 = and i8 %4087, 4
  %4089 = icmp ne i8 %4088, 0
  %4090 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 2
  %4091 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 2
  %4092 = load <8 x i1>, ptr %4090, align 1
  %4093 = load <8 x i1>, ptr %4091, align 1
  %4094 = and <8 x i1> %4092, %4007
  %4095 = icmp eq <8 x i1> %4093, %4094
  %4096 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4095)
  %4097 = and i1 %4089, %4096
  %.splatinsert1029 = insertelement <8 x i1> poison, i1 %4097, i64 0
  %.splat1030 = shufflevector <8 x i1> %.splatinsert1029, <8 x i1> poison, <8 x i32> zeroinitializer
  %4098 = select <8 x i1> %.splat1030, <8 x i1> %4093, <8 x i1> zeroinitializer
  %4099 = select i1 %4097, <8 x i1> zeroinitializer, <8 x i1> %4094
  store <8 x i1> %4099, ptr %4090, align 1
  %4100 = select i1 %4097, <8 x i1> zeroinitializer, <8 x i1> %4093
  store <8 x i1> %4100, ptr %4091, align 1
  %4101 = and i8 %4087, -5
  %4102 = select i1 %4097, i8 %4101, i8 %4087
  store i8 %4102, ptr %frame.active, align 1
  %4103 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4104 = extractelement <8 x i32> %4103, i32 2
  %4105 = load <8 x i32>, ptr %frame.static.id, align 32
  %4106 = extractelement <8 x i32> %4105, i32 2
  %convergence.target.pointer1031 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %4106
  %convergence.dynamic.target1032 = load i32, ptr %convergence.target.pointer1031, align 4
  %4107 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4098)
  %4108 = load i32, ptr %ready.count, align 4
  %4109 = icmp uge i32 %4108, 8
  %4110 = and i1 %4107, %4109
  br i1 %4110, label %ready.overflow.trap1033, label %ready.overflow.resume1034

ready.overflow.trap1033:                          ; preds = %ready.overflow.resume1028
  call void @llvm.trap()
  unreachable

ready.overflow.resume1034:                        ; preds = %ready.overflow.resume1028
  %4111 = select i1 %4107, i32 %4108, i32 0
  %4112 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4111
  %4113 = load <8 x i1>, ptr %4112, align 1
  %4114 = select i1 %4107, <8 x i1> %4098, <8 x i1> %4113
  store <8 x i1> %4114, ptr %4112, align 1
  %4115 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4111
  %4116 = load i32, ptr %4115, align 4
  %4117 = select i1 %4107, i32 %convergence.dynamic.target1032, i32 %4116
  store i32 %4117, ptr %4115, align 4
  %4118 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4111
  %4119 = load i32, ptr %4118, align 4
  %4120 = select i1 %4107, i32 %4104, i32 %4119
  store i32 %4120, ptr %4118, align 4
  %4121 = add i32 %4108, 1
  %4122 = select i1 %4107, i32 %4121, i32 %4108
  store i32 %4122, ptr %ready.count, align 4
  %4123 = load <8 x i1>, ptr %runnable.mask, align 1
  %4124 = or <8 x i1> %4123, %4098
  store <8 x i1> %4124, ptr %runnable.mask, align 1
  %4125 = load i8, ptr %frame.active, align 1
  %4126 = and i8 %4125, 8
  %4127 = icmp ne i8 %4126, 0
  %4128 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 3
  %4129 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 3
  %4130 = load <8 x i1>, ptr %4128, align 1
  %4131 = load <8 x i1>, ptr %4129, align 1
  %4132 = and <8 x i1> %4130, %4007
  %4133 = icmp eq <8 x i1> %4131, %4132
  %4134 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4133)
  %4135 = and i1 %4127, %4134
  %.splatinsert1035 = insertelement <8 x i1> poison, i1 %4135, i64 0
  %.splat1036 = shufflevector <8 x i1> %.splatinsert1035, <8 x i1> poison, <8 x i32> zeroinitializer
  %4136 = select <8 x i1> %.splat1036, <8 x i1> %4131, <8 x i1> zeroinitializer
  %4137 = select i1 %4135, <8 x i1> zeroinitializer, <8 x i1> %4132
  store <8 x i1> %4137, ptr %4128, align 1
  %4138 = select i1 %4135, <8 x i1> zeroinitializer, <8 x i1> %4131
  store <8 x i1> %4138, ptr %4129, align 1
  %4139 = and i8 %4125, -9
  %4140 = select i1 %4135, i8 %4139, i8 %4125
  store i8 %4140, ptr %frame.active, align 1
  %4141 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4142 = extractelement <8 x i32> %4141, i32 3
  %4143 = load <8 x i32>, ptr %frame.static.id, align 32
  %4144 = extractelement <8 x i32> %4143, i32 3
  %convergence.target.pointer1037 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %4144
  %convergence.dynamic.target1038 = load i32, ptr %convergence.target.pointer1037, align 4
  %4145 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4136)
  %4146 = load i32, ptr %ready.count, align 4
  %4147 = icmp uge i32 %4146, 8
  %4148 = and i1 %4145, %4147
  br i1 %4148, label %ready.overflow.trap1039, label %ready.overflow.resume1040

ready.overflow.trap1039:                          ; preds = %ready.overflow.resume1034
  call void @llvm.trap()
  unreachable

ready.overflow.resume1040:                        ; preds = %ready.overflow.resume1034
  %4149 = select i1 %4145, i32 %4146, i32 0
  %4150 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4149
  %4151 = load <8 x i1>, ptr %4150, align 1
  %4152 = select i1 %4145, <8 x i1> %4136, <8 x i1> %4151
  store <8 x i1> %4152, ptr %4150, align 1
  %4153 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4149
  %4154 = load i32, ptr %4153, align 4
  %4155 = select i1 %4145, i32 %convergence.dynamic.target1038, i32 %4154
  store i32 %4155, ptr %4153, align 4
  %4156 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4149
  %4157 = load i32, ptr %4156, align 4
  %4158 = select i1 %4145, i32 %4142, i32 %4157
  store i32 %4158, ptr %4156, align 4
  %4159 = add i32 %4146, 1
  %4160 = select i1 %4145, i32 %4159, i32 %4146
  store i32 %4160, ptr %ready.count, align 4
  %4161 = load <8 x i1>, ptr %runnable.mask, align 1
  %4162 = or <8 x i1> %4161, %4136
  store <8 x i1> %4162, ptr %runnable.mask, align 1
  %4163 = load i8, ptr %frame.active, align 1
  %4164 = and i8 %4163, 16
  %4165 = icmp ne i8 %4164, 0
  %4166 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 4
  %4167 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 4
  %4168 = load <8 x i1>, ptr %4166, align 1
  %4169 = load <8 x i1>, ptr %4167, align 1
  %4170 = and <8 x i1> %4168, %4007
  %4171 = icmp eq <8 x i1> %4169, %4170
  %4172 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4171)
  %4173 = and i1 %4165, %4172
  %.splatinsert1041 = insertelement <8 x i1> poison, i1 %4173, i64 0
  %.splat1042 = shufflevector <8 x i1> %.splatinsert1041, <8 x i1> poison, <8 x i32> zeroinitializer
  %4174 = select <8 x i1> %.splat1042, <8 x i1> %4169, <8 x i1> zeroinitializer
  %4175 = select i1 %4173, <8 x i1> zeroinitializer, <8 x i1> %4170
  store <8 x i1> %4175, ptr %4166, align 1
  %4176 = select i1 %4173, <8 x i1> zeroinitializer, <8 x i1> %4169
  store <8 x i1> %4176, ptr %4167, align 1
  %4177 = and i8 %4163, -17
  %4178 = select i1 %4173, i8 %4177, i8 %4163
  store i8 %4178, ptr %frame.active, align 1
  %4179 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4180 = extractelement <8 x i32> %4179, i32 4
  %4181 = load <8 x i32>, ptr %frame.static.id, align 32
  %4182 = extractelement <8 x i32> %4181, i32 4
  %convergence.target.pointer1043 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %4182
  %convergence.dynamic.target1044 = load i32, ptr %convergence.target.pointer1043, align 4
  %4183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4174)
  %4184 = load i32, ptr %ready.count, align 4
  %4185 = icmp uge i32 %4184, 8
  %4186 = and i1 %4183, %4185
  br i1 %4186, label %ready.overflow.trap1045, label %ready.overflow.resume1046

ready.overflow.trap1045:                          ; preds = %ready.overflow.resume1040
  call void @llvm.trap()
  unreachable

ready.overflow.resume1046:                        ; preds = %ready.overflow.resume1040
  %4187 = select i1 %4183, i32 %4184, i32 0
  %4188 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4187
  %4189 = load <8 x i1>, ptr %4188, align 1
  %4190 = select i1 %4183, <8 x i1> %4174, <8 x i1> %4189
  store <8 x i1> %4190, ptr %4188, align 1
  %4191 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4187
  %4192 = load i32, ptr %4191, align 4
  %4193 = select i1 %4183, i32 %convergence.dynamic.target1044, i32 %4192
  store i32 %4193, ptr %4191, align 4
  %4194 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4187
  %4195 = load i32, ptr %4194, align 4
  %4196 = select i1 %4183, i32 %4180, i32 %4195
  store i32 %4196, ptr %4194, align 4
  %4197 = add i32 %4184, 1
  %4198 = select i1 %4183, i32 %4197, i32 %4184
  store i32 %4198, ptr %ready.count, align 4
  %4199 = load <8 x i1>, ptr %runnable.mask, align 1
  %4200 = or <8 x i1> %4199, %4174
  store <8 x i1> %4200, ptr %runnable.mask, align 1
  %4201 = load i8, ptr %frame.active, align 1
  %4202 = and i8 %4201, 32
  %4203 = icmp ne i8 %4202, 0
  %4204 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 5
  %4205 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 5
  %4206 = load <8 x i1>, ptr %4204, align 1
  %4207 = load <8 x i1>, ptr %4205, align 1
  %4208 = and <8 x i1> %4206, %4007
  %4209 = icmp eq <8 x i1> %4207, %4208
  %4210 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4209)
  %4211 = and i1 %4203, %4210
  %.splatinsert1047 = insertelement <8 x i1> poison, i1 %4211, i64 0
  %.splat1048 = shufflevector <8 x i1> %.splatinsert1047, <8 x i1> poison, <8 x i32> zeroinitializer
  %4212 = select <8 x i1> %.splat1048, <8 x i1> %4207, <8 x i1> zeroinitializer
  %4213 = select i1 %4211, <8 x i1> zeroinitializer, <8 x i1> %4208
  store <8 x i1> %4213, ptr %4204, align 1
  %4214 = select i1 %4211, <8 x i1> zeroinitializer, <8 x i1> %4207
  store <8 x i1> %4214, ptr %4205, align 1
  %4215 = and i8 %4201, -33
  %4216 = select i1 %4211, i8 %4215, i8 %4201
  store i8 %4216, ptr %frame.active, align 1
  %4217 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4218 = extractelement <8 x i32> %4217, i32 5
  %4219 = load <8 x i32>, ptr %frame.static.id, align 32
  %4220 = extractelement <8 x i32> %4219, i32 5
  %convergence.target.pointer1049 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %4220
  %convergence.dynamic.target1050 = load i32, ptr %convergence.target.pointer1049, align 4
  %4221 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4212)
  %4222 = load i32, ptr %ready.count, align 4
  %4223 = icmp uge i32 %4222, 8
  %4224 = and i1 %4221, %4223
  br i1 %4224, label %ready.overflow.trap1051, label %ready.overflow.resume1052

ready.overflow.trap1051:                          ; preds = %ready.overflow.resume1046
  call void @llvm.trap()
  unreachable

ready.overflow.resume1052:                        ; preds = %ready.overflow.resume1046
  %4225 = select i1 %4221, i32 %4222, i32 0
  %4226 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4225
  %4227 = load <8 x i1>, ptr %4226, align 1
  %4228 = select i1 %4221, <8 x i1> %4212, <8 x i1> %4227
  store <8 x i1> %4228, ptr %4226, align 1
  %4229 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4225
  %4230 = load i32, ptr %4229, align 4
  %4231 = select i1 %4221, i32 %convergence.dynamic.target1050, i32 %4230
  store i32 %4231, ptr %4229, align 4
  %4232 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4225
  %4233 = load i32, ptr %4232, align 4
  %4234 = select i1 %4221, i32 %4218, i32 %4233
  store i32 %4234, ptr %4232, align 4
  %4235 = add i32 %4222, 1
  %4236 = select i1 %4221, i32 %4235, i32 %4222
  store i32 %4236, ptr %ready.count, align 4
  %4237 = load <8 x i1>, ptr %runnable.mask, align 1
  %4238 = or <8 x i1> %4237, %4212
  store <8 x i1> %4238, ptr %runnable.mask, align 1
  %4239 = load i8, ptr %frame.active, align 1
  %4240 = and i8 %4239, 64
  %4241 = icmp ne i8 %4240, 0
  %4242 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 6
  %4243 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 6
  %4244 = load <8 x i1>, ptr %4242, align 1
  %4245 = load <8 x i1>, ptr %4243, align 1
  %4246 = and <8 x i1> %4244, %4007
  %4247 = icmp eq <8 x i1> %4245, %4246
  %4248 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4247)
  %4249 = and i1 %4241, %4248
  %.splatinsert1053 = insertelement <8 x i1> poison, i1 %4249, i64 0
  %.splat1054 = shufflevector <8 x i1> %.splatinsert1053, <8 x i1> poison, <8 x i32> zeroinitializer
  %4250 = select <8 x i1> %.splat1054, <8 x i1> %4245, <8 x i1> zeroinitializer
  %4251 = select i1 %4249, <8 x i1> zeroinitializer, <8 x i1> %4246
  store <8 x i1> %4251, ptr %4242, align 1
  %4252 = select i1 %4249, <8 x i1> zeroinitializer, <8 x i1> %4245
  store <8 x i1> %4252, ptr %4243, align 1
  %4253 = and i8 %4239, -65
  %4254 = select i1 %4249, i8 %4253, i8 %4239
  store i8 %4254, ptr %frame.active, align 1
  %4255 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4256 = extractelement <8 x i32> %4255, i32 6
  %4257 = load <8 x i32>, ptr %frame.static.id, align 32
  %4258 = extractelement <8 x i32> %4257, i32 6
  %convergence.target.pointer1055 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %4258
  %convergence.dynamic.target1056 = load i32, ptr %convergence.target.pointer1055, align 4
  %4259 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4250)
  %4260 = load i32, ptr %ready.count, align 4
  %4261 = icmp uge i32 %4260, 8
  %4262 = and i1 %4259, %4261
  br i1 %4262, label %ready.overflow.trap1057, label %ready.overflow.resume1058

ready.overflow.trap1057:                          ; preds = %ready.overflow.resume1052
  call void @llvm.trap()
  unreachable

ready.overflow.resume1058:                        ; preds = %ready.overflow.resume1052
  %4263 = select i1 %4259, i32 %4260, i32 0
  %4264 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4263
  %4265 = load <8 x i1>, ptr %4264, align 1
  %4266 = select i1 %4259, <8 x i1> %4250, <8 x i1> %4265
  store <8 x i1> %4266, ptr %4264, align 1
  %4267 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4263
  %4268 = load i32, ptr %4267, align 4
  %4269 = select i1 %4259, i32 %convergence.dynamic.target1056, i32 %4268
  store i32 %4269, ptr %4267, align 4
  %4270 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4263
  %4271 = load i32, ptr %4270, align 4
  %4272 = select i1 %4259, i32 %4256, i32 %4271
  store i32 %4272, ptr %4270, align 4
  %4273 = add i32 %4260, 1
  %4274 = select i1 %4259, i32 %4273, i32 %4260
  store i32 %4274, ptr %ready.count, align 4
  %4275 = load <8 x i1>, ptr %runnable.mask, align 1
  %4276 = or <8 x i1> %4275, %4250
  store <8 x i1> %4276, ptr %runnable.mask, align 1
  %4277 = load i8, ptr %frame.active, align 1
  %4278 = and i8 %4277, -128
  %4279 = icmp ne i8 %4278, 0
  %4280 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 7
  %4281 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 7
  %4282 = load <8 x i1>, ptr %4280, align 1
  %4283 = load <8 x i1>, ptr %4281, align 1
  %4284 = and <8 x i1> %4282, %4007
  %4285 = icmp eq <8 x i1> %4283, %4284
  %4286 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4285)
  %4287 = and i1 %4279, %4286
  %.splatinsert1059 = insertelement <8 x i1> poison, i1 %4287, i64 0
  %.splat1060 = shufflevector <8 x i1> %.splatinsert1059, <8 x i1> poison, <8 x i32> zeroinitializer
  %4288 = select <8 x i1> %.splat1060, <8 x i1> %4283, <8 x i1> zeroinitializer
  %4289 = select i1 %4287, <8 x i1> zeroinitializer, <8 x i1> %4284
  store <8 x i1> %4289, ptr %4280, align 1
  %4290 = select i1 %4287, <8 x i1> zeroinitializer, <8 x i1> %4283
  store <8 x i1> %4290, ptr %4281, align 1
  %4291 = and i8 %4277, 127
  %4292 = select i1 %4287, i8 %4291, i8 %4277
  store i8 %4292, ptr %frame.active, align 1
  %4293 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4294 = extractelement <8 x i32> %4293, i32 7
  %4295 = load <8 x i32>, ptr %frame.static.id, align 32
  %4296 = extractelement <8 x i32> %4295, i32 7
  %convergence.target.pointer1061 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %4296
  %convergence.dynamic.target1062 = load i32, ptr %convergence.target.pointer1061, align 4
  %4297 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4288)
  %4298 = load i32, ptr %ready.count, align 4
  %4299 = icmp uge i32 %4298, 8
  %4300 = and i1 %4297, %4299
  br i1 %4300, label %ready.overflow.trap1063, label %ready.overflow.resume1064

ready.overflow.trap1063:                          ; preds = %ready.overflow.resume1058
  call void @llvm.trap()
  unreachable

ready.overflow.resume1064:                        ; preds = %ready.overflow.resume1058
  %4301 = select i1 %4297, i32 %4298, i32 0
  %4302 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4301
  %4303 = load <8 x i1>, ptr %4302, align 1
  %4304 = select i1 %4297, <8 x i1> %4288, <8 x i1> %4303
  store <8 x i1> %4304, ptr %4302, align 1
  %4305 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4301
  %4306 = load i32, ptr %4305, align 4
  %4307 = select i1 %4297, i32 %convergence.dynamic.target1062, i32 %4306
  store i32 %4307, ptr %4305, align 4
  %4308 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4301
  %4309 = load i32, ptr %4308, align 4
  %4310 = select i1 %4297, i32 %4294, i32 %4309
  store i32 %4310, ptr %4308, align 4
  %4311 = add i32 %4298, 1
  %4312 = select i1 %4297, i32 %4311, i32 %4298
  store i32 %4312, ptr %ready.count, align 4
  %4313 = load <8 x i1>, ptr %runnable.mask, align 1
  %4314 = or <8 x i1> %4313, %4288
  store <8 x i1> %4314, ptr %runnable.mask, align 1
  br label %return.frame.cleanup.done
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.and.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #3

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #4 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #5

define dso_local void @llm_attention.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #3 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(write) }

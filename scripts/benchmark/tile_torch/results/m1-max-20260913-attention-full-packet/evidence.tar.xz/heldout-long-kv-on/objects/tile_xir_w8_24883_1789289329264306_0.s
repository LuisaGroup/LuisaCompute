	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention.full_packet
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention.full_packet:             ; @llm_attention.full_packet
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1856
	mov	x8, #0                          ; =0x0
	ldr	x20, [x1, #136]
	add	x21, x20, #35, lsl #12          ; =143360
	ldr	x9, [x0]
	ldr	x28, [x0, #16]
	ldr	w10, [x1]
	ldr	w11, [x1, #36]
	add	w10, w11, w10, lsl #5
	ldr	x22, [x0, #32]
	dup.4s	v0, w10
	ldr	x19, [x0, #48]
Lloh0:
	adrp	x10, lCPI0_0@PAGE
Lloh1:
	ldr	q1, [x10, lCPI0_0@PAGEOFF]
	add.4s	v1, v0, v1
Lloh2:
	adrp	x10, lCPI0_1@PAGE
Lloh3:
	ldr	q2, [x10, lCPI0_1@PAGEOFF]
	add.4s	v0, v0, v2
	ushll2.2d	v2, v0, #0
	str	q2, [sp, #1824]                 ; 16-byte Spill
	ushll2.2d	v2, v1, #0
	str	q2, [sp, #1840]                 ; 16-byte Spill
	ushll.2d	v2, v0, #0
	str	q2, [sp, #1792]                 ; 16-byte Spill
	ushll.2d	v2, v1, #0
	str	q2, [sp, #1808]                 ; 16-byte Spill
	ushll2.2d	v5, v0, #9
	ushll2.2d	v6, v1, #9
	ushll.2d	v7, v0, #9
	ushll.2d	v16, v1, #9
	dup.2d	v0, x9
	mov	x9, x20
LBB0_1:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v1, x8
	add.2d	v2, v1, v16
	add.2d	v3, v1, v6
	add.2d	v4, v1, v7
	add.2d	v1, v1, v5
	add.2d	v1, v0, v1
	add.2d	v4, v0, v4
	add.2d	v3, v0, v3
	add.2d	v2, v0, v2
	mov.d	x10, v2[1]
	fmov	x11, d2
	mov.d	x12, v3[1]
	fmov	x13, d3
	mov.d	x14, v4[1]
	fmov	x15, d4
	mov.d	x16, v1[1]
	ldr	s2, [x11]
	ld1.s	{ v2 }[1], [x10]
	fmov	x10, d1
	ld1.s	{ v2 }[2], [x13]
	ld1.s	{ v2 }[3], [x12]
	ldr	s1, [x15]
	ld1.s	{ v1 }[1], [x14]
	ld1.s	{ v1 }[2], [x10]
	ld1.s	{ v1 }[3], [x16]
	stp	q2, q1, [x9], #32
	add	x8, x8, #4
	cmp	x8, #512
	b.ne	LBB0_1
; %bb.2:                                ; %direct.true166.preheader
	stp	q16, q7, [sp, #16]              ; 32-byte Folded Spill
	stp	q6, q5, [sp, #48]               ; 32-byte Folded Spill
	add	x23, x20, #1, lsl #12           ; =4096
	add	x0, x20, #1, lsl #12            ; =4096
	mov	w1, #4096                       ; =0x1000
	bl	_bzero
	mov	x24, #0                         ; =0x0
	add	x25, x20, #3, lsl #12           ; =12288
	add	x26, x20, #19, lsl #12          ; =77824
	mov	w27, #13312                     ; =0x3400
	movk	w27, #2, lsl #16
	ldr	q0, [sp, #1824]                 ; 16-byte Reload
	shrn.2s	v0, v0, #2
	ldr	q1, [sp, #1792]                 ; 16-byte Reload
	shrn.2s	v1, v1, #2
	ldr	q2, [sp, #1840]                 ; 16-byte Reload
	shrn.2s	v2, v2, #2
	ldr	q3, [sp, #1808]                 ; 16-byte Reload
	shrn.2s	v3, v3, #2
	mov	w8, #8193                       ; =0x2001
	dup.2s	v4, w8
	umull.2d	v6, v3, v4
	umull.2d	v7, v2, v4
	umull.2d	v16, v1, v4
	umull.2d	v17, v0, v4
	mov	w8, #62154                      ; =0xf2ca
	movk	w8, #61769, lsl #16
	dup.4s	v1, w8
	dup.2d	v18, x28
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	stp	q0, q18, [sp, #80]              ; 32-byte Folded Spill
	mov	w28, #1024                      ; =0x400
	movk	w28, #1, lsl #16
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	mov.16b	v0, v1
	stp	q7, q6, [sp, #144]              ; 32-byte Folded Spill
	stp	q17, q16, [sp, #112]            ; 32-byte Folded Spill
LBB0_3:                                 ; %direct.true176
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_5 Depth 2
                                        ;     Child Loop BB0_9 Depth 2
                                        ;     Child Loop BB0_12 Depth 2
                                        ;     Child Loop BB0_14 Depth 2
                                        ;     Child Loop BB0_16 Depth 2
                                        ;     Child Loop BB0_18 Depth 2
                                        ;     Child Loop BB0_20 Depth 2
                                        ;     Child Loop BB0_22 Depth 2
                                        ;     Child Loop BB0_24 Depth 2
                                        ;     Child Loop BB0_26 Depth 2
                                        ;     Child Loop BB0_28 Depth 2
                                        ;     Child Loop BB0_30 Depth 2
                                        ;     Child Loop BB0_32 Depth 2
                                        ;     Child Loop BB0_34 Depth 2
                                        ;     Child Loop BB0_36 Depth 2
                                        ;     Child Loop BB0_38 Depth 2
                                        ;     Child Loop BB0_40 Depth 2
                                        ;     Child Loop BB0_42 Depth 2
                                        ;     Child Loop BB0_44 Depth 2
	str	q0, [sp, #1824]                 ; 16-byte Spill
	str	q1, [sp, #1840]                 ; 16-byte Spill
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	lsl	x8, x24, #4
	b	LBB0_5
LBB0_4:                                 ; %direct.schedule.12
                                        ;   in Loop: Header=BB0_5 Depth=2
	add	x11, x25, x10, lsl #5
	stp	q0, q1, [x11]
	add	x10, x10, #1
	add	x9, x9, #4
	cmp	x9, #2, lsl #12                 ; =8192
	b.eq	LBB0_7
LBB0_5:                                 ; %direct.true180
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	orr	x11, x8, x10, lsr #7
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	cmp	x11, #2, lsl #12                ; =8192
	b.hi	LBB0_4
; %bb.6:                                ; %direct.true193
                                        ;   in Loop: Header=BB0_5 Depth=2
	dup.2d	v0, x11
	add.2d	v1, v0, v6
	add.2d	v2, v0, v7
	add.2d	v3, v0, v16
	add.2d	v0, v0, v17
	shl.2d	v0, v0, #9
	shl.2d	v3, v3, #9
	shl.2d	v2, v2, #9
	shl.2d	v1, v1, #9
	and	x11, x9, #0x1fc
	dup.2d	v4, x11
	orr.16b	v1, v1, v4
	orr.16b	v2, v2, v4
	orr.16b	v3, v3, v4
	orr.16b	v0, v0, v4
	add.2d	v4, v18, v0
	add.2d	v0, v18, v3
	add.2d	v2, v18, v2
	add.2d	v1, v18, v1
	mov.d	x11, v1[1]
	fmov	x12, d1
	mov.d	x13, v2[1]
	fmov	x14, d2
	mov.d	x15, v0[1]
	fmov	x16, d0
	mov.d	x17, v4[1]
	ldr	s0, [x12]
	ld1.s	{ v0 }[1], [x11]
	fmov	x11, d4
	ld1.s	{ v0 }[2], [x14]
	ld1.s	{ v0 }[3], [x13]
	ldr	s1, [x16]
	ld1.s	{ v1 }[1], [x15]
	ld1.s	{ v1 }[2], [x11]
	ld1.s	{ v1 }[3], [x17]
	b	LBB0_4
LBB0_7:                                 ; %direct.true205.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	b	LBB0_9
LBB0_8:                                 ; %direct.schedule.17
                                        ;   in Loop: Header=BB0_9 Depth=2
	add	x11, x26, x10, lsl #5
	stp	q0, q1, [x11]
	add	x10, x10, #1
	add	x9, x9, #4
	cmp	x9, #2, lsl #12                 ; =8192
	b.eq	LBB0_11
LBB0_9:                                 ; %direct.true205
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	orr	x11, x8, x10, lsr #7
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	cmp	x11, #2, lsl #12                ; =8192
	b.hi	LBB0_8
; %bb.10:                               ; %direct.true218
                                        ;   in Loop: Header=BB0_9 Depth=2
	dup.2d	v0, x11
	add.2d	v1, v0, v6
	add.2d	v2, v0, v7
	add.2d	v3, v0, v16
	add.2d	v0, v0, v17
	shl.2d	v0, v0, #9
	shl.2d	v3, v3, #9
	shl.2d	v2, v2, #9
	shl.2d	v1, v1, #9
	and	x11, x9, #0x1fc
	dup.2d	v4, x11
	orr.16b	v1, v1, v4
	orr.16b	v2, v2, v4
	orr.16b	v3, v3, v4
	orr.16b	v0, v0, v4
	dup.2d	v4, x22
	add.2d	v5, v4, v0
	add.2d	v0, v4, v3
	add.2d	v2, v4, v2
	add.2d	v1, v4, v1
	mov.d	x11, v1[1]
	fmov	x12, d1
	mov.d	x13, v2[1]
	fmov	x14, d2
	mov.d	x15, v0[1]
	fmov	x16, d0
	mov.d	x17, v5[1]
	ldr	s0, [x12]
	ld1.s	{ v0 }[1], [x11]
	fmov	x11, d5
	ld1.s	{ v0 }[2], [x14]
	ld1.s	{ v0 }[3], [x13]
	ldr	s1, [x16]
	ld1.s	{ v1 }[1], [x15]
	ld1.s	{ v1 }[2], [x11]
	ld1.s	{ v1 }[3], [x17]
	b	LBB0_8
LBB0_11:                                ; %direct.true230.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v0, #0000000000000000
	mov	x8, x20
	mov	w9, #128                        ; =0x80
	movi.2d	v1, #0000000000000000
LBB0_12:                                ; %direct.true230
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q3, q2, [x8]
	ldr	q4, [x8, #12304]
	ldr	q5, [x8, #12288]
	fmul.4s	v3, v3, v5
	fmul.4s	v2, v2, v4
	fadd.4s	v0, v0, v2
	fadd.4s	v1, v1, v3
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_12
; %bb.13:                               ; %direct.true245.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v2, #0000000000000000
	mov	x8, x20
	mov	w9, #128                        ; =0x80
	movi.2d	v3, #0000000000000000
LBB0_14:                                ; %direct.true245
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q5, q4, [x8]
	ldr	q6, [x8, #16400]
	ldr	q7, [x8, #16384]
	fmul.4s	v5, v5, v7
	fmul.4s	v4, v4, v6
	fadd.4s	v2, v2, v4
	fadd.4s	v3, v3, v5
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_14
; %bb.15:                               ; %direct.true262.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	q19, [sp, #1392]                ; 16-byte Spill
	movi.2d	v4, #0000000000000000
	mov	x8, x20
	mov	w9, #128                        ; =0x80
	movi.2d	v5, #0000000000000000
LBB0_16:                                ; %direct.true262
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q7, q6, [x8]
	ldr	q16, [x8, #20496]
	ldr	q17, [x8, #20480]
	fmul.4s	v7, v7, v17
	fmul.4s	v6, v6, v16
	fadd.4s	v4, v4, v6
	fadd.4s	v5, v5, v7
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_16
; %bb.17:                               ; %direct.true279.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	q20, [sp, #1376]                ; 16-byte Spill
	movi.2d	v6, #0000000000000000
	mov	x8, x20
	mov	w9, #128                        ; =0x80
	movi.2d	v7, #0000000000000000
LBB0_18:                                ; %direct.true279
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q17, q16, [x8]
	ldr	q18, [x8, #24592]
	ldr	q19, [x8, #24576]
	fmul.4s	v17, v17, v19
	fmul.4s	v16, v16, v18
	fadd.4s	v6, v6, v16
	fadd.4s	v7, v7, v17
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_18
; %bb.19:                               ; %direct.true296.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v16, #0000000000000000
	mov	x8, x20
	mov	w9, #128                        ; =0x80
	movi.2d	v17, #0000000000000000
LBB0_20:                                ; %direct.true296
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q19, q18, [x8]
	ldr	q20, [x8, #28688]
	ldr	q21, [x8, #28672]
	fmul.4s	v19, v19, v21
	fmul.4s	v18, v18, v20
	fadd.4s	v16, v16, v18
	fadd.4s	v17, v17, v19
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_20
; %bb.21:                               ; %direct.true313.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v18, #0000000000000000
	mov	x8, x20
	mov	w9, #128                        ; =0x80
	movi.2d	v19, #0000000000000000
LBB0_22:                                ; %direct.true313
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q21, q20, [x8]
	ldr	q22, [x8, #32784]
	ldr	q23, [x8, #32768]
	fmul.4s	v21, v21, v23
	fmul.4s	v20, v20, v22
	fadd.4s	v18, v18, v20
	fadd.4s	v19, v19, v21
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_22
; %bb.23:                               ; %direct.true330.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v20, #0000000000000000
	mov	x8, x20
	mov	w9, #128                        ; =0x80
	movi.2d	v21, #0000000000000000
LBB0_24:                                ; %direct.true330
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q23, q22, [x8]
	ldr	q24, [x8, #36880]
	ldr	q25, [x8, #36864]
	fmul.4s	v23, v23, v25
	fmul.4s	v22, v22, v24
	fadd.4s	v20, v20, v22
	fadd.4s	v21, v21, v23
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_24
; %bb.25:                               ; %direct.true347.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v22, #0000000000000000
	mov	x8, x20
	mov	w9, #128                        ; =0x80
	movi.2d	v23, #0000000000000000
LBB0_26:                                ; %direct.true347
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q25, q24, [x8]
	ldr	q26, [x8, #40976]
	ldr	q27, [x8, #40960]
	fmul.4s	v25, v25, v27
	fmul.4s	v24, v24, v26
	fadd.4s	v22, v22, v24
	fadd.4s	v23, v23, v25
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_26
; %bb.27:                               ; %direct.true364.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v24, #0000000000000000
	mov	x8, x20
	mov	w9, #128                        ; =0x80
	movi.2d	v25, #0000000000000000
LBB0_28:                                ; %direct.true364
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q27, q26, [x8]
	ldr	q28, [x8, #45072]
	ldr	q29, [x8, #45056]
	fmul.4s	v27, v27, v29
	fmul.4s	v26, v26, v28
	fadd.4s	v24, v24, v26
	fadd.4s	v25, v25, v27
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_28
; %bb.29:                               ; %direct.true381.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v26, #0000000000000000
	mov	x8, x20
	mov	w9, #128                        ; =0x80
	movi.2d	v27, #0000000000000000
LBB0_30:                                ; %direct.true381
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q29, q28, [x8]
	ldr	q30, [x8, #49168]
	ldr	q31, [x8, #49152]
	fmul.4s	v29, v29, v31
	fmul.4s	v28, v28, v30
	fadd.4s	v26, v26, v28
	fadd.4s	v27, v27, v29
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_30
; %bb.31:                               ; %direct.true398.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v28, #0000000000000000
	mov	x8, x20
	mov	w9, #128                        ; =0x80
	movi.2d	v29, #0000000000000000
LBB0_32:                                ; %direct.true398
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q31, q30, [x8]
	ldr	q8, [x8, #53264]
	ldr	q9, [x8, #53248]
	fmul.4s	v31, v31, v9
	fmul.4s	v30, v30, v8
	fadd.4s	v28, v28, v30
	fadd.4s	v29, v29, v31
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_32
; %bb.33:                               ; %direct.true415.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v30, #0000000000000000
	mov	x8, x20
	mov	w9, #128                        ; =0x80
	movi.2d	v31, #0000000000000000
LBB0_34:                                ; %direct.true415
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q9, q8, [x8]
	ldr	q10, [x8, #57360]
	ldr	q11, [x8, #57344]
	fmul.4s	v9, v9, v11
	fmul.4s	v8, v8, v10
	fadd.4s	v30, v30, v8
	fadd.4s	v31, v31, v9
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_34
; %bb.35:                               ; %direct.true432.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v8, #0000000000000000
	mov	x8, x20
	mov	w9, #128                        ; =0x80
	movi.2d	v9, #0000000000000000
LBB0_36:                                ; %direct.true432
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q11, q10, [x8]
	ldr	q12, [x8, #61456]
	ldr	q13, [x8, #61440]
	fmul.4s	v11, v11, v13
	fmul.4s	v10, v10, v12
	fadd.4s	v8, v8, v10
	fadd.4s	v9, v9, v11
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_36
; %bb.37:                               ; %direct.true449.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	q1, [sp, #1792]                 ; 16-byte Spill
	str	q0, [sp, #1808]                 ; 16-byte Spill
	movi.2d	v10, #0000000000000000
	mov	x8, x20
	mov	w9, #128                        ; =0x80
	movi.2d	v11, #0000000000000000
LBB0_38:                                ; %direct.true449
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q13, q12, [x8]
	add	x10, x8, #16, lsl #12           ; =65536
	ldp	q15, q14, [x10]
	fmul.4s	v13, v13, v15
	fmul.4s	v12, v12, v14
	fadd.4s	v10, v10, v12
	fadd.4s	v11, v11, v13
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_38
; %bb.39:                               ; %direct.true466.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v12, #0000000000000000
	mov	x8, x20
	mov	w9, #128                        ; =0x80
	movi.2d	v13, #0000000000000000
LBB0_40:                                ; %direct.true466
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q15, q14, [x8]
	add	x10, x8, #17, lsl #12           ; =69632
	ldp	q1, q0, [x10]
	fmul.4s	v1, v15, v1
	fmul.4s	v0, v14, v0
	fadd.4s	v12, v12, v0
	fadd.4s	v13, v13, v1
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_40
; %bb.41:                               ; %direct.true483.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	q3, [sp, #1760]                 ; 16-byte Spill
	str	q2, [sp, #1776]                 ; 16-byte Spill
	movi.2d	v14, #0000000000000000
	mov	x8, x20
	mov	w9, #128                        ; =0x80
	movi.2d	v15, #0000000000000000
LBB0_42:                                ; %direct.true483
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q1, q0, [x8]
	add	x10, x8, #18, lsl #12           ; =73728
	ldp	q3, q2, [x10]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v14, v14, v0
	fadd.4s	v15, v15, v1
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_42
; %bb.43:                               ; %direct.false484
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	w8, #1267                       ; =0x4f3
	movk	w8, #15797, lsl #16
	dup.4s	v2, w8
	ldr	q0, [sp, #1792]                 ; 16-byte Reload
	fmul.4s	v0, v0, v2
	str	q0, [sp, #1664]                 ; 16-byte Spill
	ldr	q0, [sp, #1808]                 ; 16-byte Reload
	fmul.4s	v0, v0, v2
	str	q0, [sp, #1472]                 ; 16-byte Spill
	ldr	q0, [sp, #1776]                 ; 16-byte Reload
	fmul.4s	v3, v0, v2
	ldr	q0, [sp, #1760]                 ; 16-byte Reload
	fmul.4s	v0, v0, v2
	fmul.4s	v1, v4, v2
	fmul.4s	v5, v5, v2
	fmul.4s	v6, v6, v2
	fmul.4s	v7, v7, v2
	fmul.4s	v16, v16, v2
	fmul.4s	v17, v17, v2
	fmul.4s	v18, v18, v2
	fmul.4s	v19, v19, v2
	fmul.4s	v20, v20, v2
	fmul.4s	v21, v21, v2
	fmul.4s	v22, v22, v2
	fmul.4s	v23, v23, v2
	fmul.4s	v4, v24, v2
	str	q4, [sp, #1696]                 ; 16-byte Spill
	fmul.4s	v25, v25, v2
	fmul.4s	v26, v26, v2
	fmul.4s	v24, v27, v2
	fmul.4s	v28, v28, v2
	fmul.4s	v29, v29, v2
	fmul.4s	v30, v30, v2
	fmul.4s	v31, v31, v2
	fmul.4s	v8, v8, v2
	fmul.4s	v9, v9, v2
	fmul.4s	v10, v10, v2
	fmul.4s	v11, v11, v2
	fmul.4s	v12, v12, v2
	fmul.4s	v13, v13, v2
	fmul.4s	v14, v14, v2
	fmul.4s	v2, v15, v2
	cmp	x24, #512
	cset	w8, lo
	dup.4h	v4, w8
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	mov	w8, #62154                      ; =0xf2ca
	movk	w8, #61769, lsl #16
	dup.4s	v15, w8
	cmlt.4s	v4, v4, #0
	str	q4, [sp, #1328]                 ; 16-byte Spill
	mov.16b	v27, v4
	bsl.16b	v27, v0, v15
	mov.16b	v0, v4
	bsl.16b	v0, v3, v15
	str	q0, [sp, #1456]                 ; 16-byte Spill
	mov.16b	v3, v4
	bsl.16b	v3, v5, v15
	str	q3, [sp, #1760]                 ; 16-byte Spill
	mov.16b	v0, v4
	bsl.16b	v0, v1, v15
	str	q0, [sp, #1440]                 ; 16-byte Spill
	mov.16b	v1, v4
	bsl.16b	v1, v7, v15
	str	q1, [sp, #1808]                 ; 16-byte Spill
	mov.16b	v7, v4
	bsl.16b	v7, v6, v15
	str	q7, [sp, #1488]                 ; 16-byte Spill
	mov.16b	v6, v4
	bsl.16b	v6, v17, v15
	str	q6, [sp, #1744]                 ; 16-byte Spill
	mov.16b	v17, v4
	bsl.16b	v17, v16, v15
	str	q17, [sp, #1504]                ; 16-byte Spill
	mov.16b	v16, v4
	bsl.16b	v16, v19, v15
	str	q16, [sp, #1792]                ; 16-byte Spill
	mov.16b	v19, v4
	bsl.16b	v19, v18, v15
	str	q19, [sp, #1520]                ; 16-byte Spill
	mov.16b	v18, v4
	bsl.16b	v18, v21, v15
	str	q18, [sp, #1728]                ; 16-byte Spill
	mov.16b	v21, v4
	bsl.16b	v21, v20, v15
	str	q21, [sp, #1536]                ; 16-byte Spill
	mov.16b	v20, v4
	bsl.16b	v20, v23, v15
	str	q20, [sp, #1776]                ; 16-byte Spill
	mov.16b	v23, v4
	bsl.16b	v23, v22, v15
	str	q23, [sp, #1552]                ; 16-byte Spill
	mov.16b	v22, v4
	bsl.16b	v22, v25, v15
	str	q22, [sp, #1712]                ; 16-byte Spill
	ldr	q0, [sp, #1696]                 ; 16-byte Reload
	mov.16b	v25, v4
	bsl.16b	v25, v0, v15
	str	q25, [sp, #1568]                ; 16-byte Spill
	bif.16b	v24, v15, v4
	str	q24, [sp, #1696]                ; 16-byte Spill
	bif.16b	v26, v15, v4
	str	q26, [sp, #1584]                ; 16-byte Spill
	bif.16b	v29, v15, v4
	str	q29, [sp, #1680]                ; 16-byte Spill
	mov.16b	v0, v4
	bsl.16b	v0, v28, v15
	str	q0, [sp, #1424]                 ; 16-byte Spill
	mov.16b	v28, v4
	bsl.16b	v28, v31, v15
	str	q28, [sp, #1648]                ; 16-byte Spill
	mov.16b	v31, v4
	bsl.16b	v31, v30, v15
	str	q31, [sp, #1600]                ; 16-byte Spill
	mov.16b	v30, v4
	bsl.16b	v30, v9, v15
	str	q30, [sp, #1632]                ; 16-byte Spill
	mov.16b	v5, v4
	bsl.16b	v5, v8, v15
	str	q5, [sp, #1616]                 ; 16-byte Spill
	mov.16b	v8, v4
	bsl.16b	v8, v11, v15
	str	q8, [sp, #1008]                 ; 16-byte Spill
	mov.16b	v11, v4
	bsl.16b	v11, v10, v15
	str	q11, [sp, #1408]                ; 16-byte Spill
	mov.16b	v9, v4
	bsl.16b	v9, v13, v15
	str	q9, [sp, #784]                  ; 16-byte Spill
	mov.16b	v13, v4
	bsl.16b	v13, v12, v15
	bif.16b	v2, v15, v4
	str	q2, [sp, #1168]                 ; 16-byte Spill
	mov.16b	v12, v4
	bsl.16b	v12, v14, v15
	str	q12, [sp, #1152]                ; 16-byte Spill
	mvni.4s	v14, #127, msl #16
	ldr	q4, [sp, #1664]                 ; 16-byte Reload
	fmaxnm.4s	v0, v4, v14
	fmaxnm.4s	v0, v0, v27
	str	q27, [sp, #1248]                ; 16-byte Spill
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v0, v0, v1
	fmaxnm.4s	v0, v0, v6
	fmaxnm.4s	v0, v0, v16
	fmaxnm.4s	v0, v0, v18
	fmaxnm.4s	v0, v0, v20
	fmaxnm.4s	v0, v0, v22
	fmaxnm.4s	v0, v0, v24
	fmaxnm.4s	v0, v0, v29
	fmaxnm.4s	v0, v0, v28
	fmaxnm.4s	v0, v0, v30
	fmaxnm.4s	v0, v0, v8
	fmaxnm.4s	v0, v0, v9
	fmaxnm.4s	v0, v0, v2
	ldr	q1, [sp, #1840]                 ; 16-byte Reload
	fmaxnm.4s	v9, v1, v0
	fsub.4s	v0, v4, v9
	mov	w8, #-1026555904                ; =0xc2d00000
	dup.4s	v1, w8
	fcmge.4s	v2, v0, v1
	mov	w8, #1120403456                 ; =0x42c80000
	dup.4s	v4, w8
	fcmge.4s	v3, v4, v0
	and.16b	v2, v2, v3
	ldr	q6, [sp, #1472]                 ; 16-byte Reload
	fmaxnm.4s	v3, v6, v14
	ldr	q10, [sp, #1456]                ; 16-byte Reload
	fmaxnm.4s	v3, v3, v10
	ldr	q28, [sp, #1440]                ; 16-byte Reload
	fmaxnm.4s	v3, v3, v28
	fmaxnm.4s	v3, v3, v7
	fmaxnm.4s	v3, v3, v17
	fmaxnm.4s	v3, v3, v19
	fmaxnm.4s	v3, v3, v21
	fmaxnm.4s	v3, v3, v23
	fmaxnm.4s	v3, v3, v25
	fmaxnm.4s	v3, v3, v26
	ldr	q15, [sp, #1424]                ; 16-byte Reload
	fmaxnm.4s	v3, v3, v15
	fmaxnm.4s	v3, v3, v31
	fmaxnm.4s	v3, v3, v5
	fmaxnm.4s	v3, v3, v11
	fmaxnm.4s	v3, v3, v13
	fmaxnm.4s	v3, v3, v12
	ldr	q5, [sp, #1824]                 ; 16-byte Reload
	fmaxnm.4s	v29, v5, v3
	fsub.4s	v26, v6, v29
	fcmge.4s	v3, v26, v1
	fcmge.4s	v5, v4, v26
	and.16b	v3, v3, v5
	and.16b	v3, v3, v26
	mov	w8, #43579                      ; =0xaa3b
	movk	w8, #16312, lsl #16
	dup.4s	v21, w8
	fmul.4s	v5, v3, v21
	movi.4s	v8, #75, lsl #24
	mvni.4s	v12, #128, lsl #24
	mov.16b	v6, v12
	bsl.16b	v6, v8, v5
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	and.16b	v6, v2, v0
	fmul.4s	v2, v6, v21
	mov.16b	v7, v12
	bsl.16b	v7, v8, v2
	fadd.4s	v2, v2, v7
	fsub.4s	v7, v2, v7
	fcvtzs.4s	v2, v5
	scvtf.4s	v5, v2
	mov	w8, #29184                      ; =0x7200
	movk	w8, #16177, lsl #16
	dup.4s	v20, w8
	fmul.4s	v16, v5, v20
	fsub.4s	v16, v3, v16
	fcvtzs.4s	v3, v7
	scvtf.4s	v7, v3
	fmul.4s	v17, v7, v20
	fsub.4s	v6, v6, v17
	mov	w8, #48782                      ; =0xbe8e
	movk	w8, #13759, lsl #16
	dup.4s	v19, w8
	fmul.4s	v7, v7, v19
	fsub.4s	v22, v6, v7
	fmul.4s	v5, v5, v19
	fsub.4s	v5, v16, v5
	mov	w8, #11226                      ; =0x2bda
	movk	w8, #14672, lsl #16
	dup.4s	v18, w8
	fmul.4s	v6, v5, v18
	mov	w8, #38601                      ; =0x96c9
	movk	w8, #15030, lsl #16
	dup.4s	v17, w8
	fadd.4s	v6, v6, v17
	fmul.4s	v6, v5, v6
	mov	w8, #34982                      ; =0x88a6
	movk	w8, #15368, lsl #16
	dup.4s	v16, w8
	fadd.4s	v6, v6, v16
	fmul.4s	v6, v5, v6
	mov	w8, #43642                      ; =0xaa7a
	movk	w8, #15658, lsl #16
	dup.4s	v7, w8
	fadd.4s	v6, v6, v7
	fmul.4s	v23, v5, v6
	mov	w8, #43691                      ; =0xaaab
	movk	w8, #15914, lsl #16
	dup.4s	v6, w8
	fadd.4s	v23, v23, v6
	fmul.4s	v23, v5, v23
	movi.4s	v30, #63, lsl #24
	fadd.4s	v23, v23, v30
	fmul.4s	v24, v5, v5
	fmul.4s	v23, v24, v23
	fmul.4s	v24, v22, v18
	fadd.4s	v24, v24, v17
	fmul.4s	v24, v22, v24
	fadd.4s	v24, v24, v16
	fmul.4s	v24, v22, v24
	fadd.4s	v24, v24, v7
	fmul.4s	v24, v22, v24
	fadd.4s	v24, v24, v6
	fmul.4s	v24, v22, v24
	fadd.4s	v24, v24, v30
	fmul.4s	v25, v22, v22
	fmul.4s	v24, v25, v24
	fadd.4s	v22, v22, v24
	fadd.4s	v5, v5, v23
	fmov.4s	v31, #1.00000000
	fadd.4s	v22, v22, v31
	sshr.4s	v23, v3, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v31
	fmul.4s	v22, v22, v24
	fadd.4s	v5, v5, v31
	sshr.4s	v24, v2, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v31
	fmul.4s	v5, v5, v25
	sub.4s	v3, v3, v23
	sub.4s	v2, v2, v24
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v5, v2
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	str	q0, [sp, #1264]                 ; 16-byte Spill
	fcmgt.4s	v5, v1, v0
	bic.16b	v3, v3, v5
	str	q26, [sp, #1312]                ; 16-byte Spill
	fcmgt.4s	v5, v1, v26
	bic.16b	v2, v2, v5
	fcmgt.4s	v22, v26, v4
	fneg.4s	v5, v14
	bit.16b	v2, v5, v22
	str	q2, [sp, #1296]                 ; 16-byte Spill
	fcmgt.4s	v2, v0, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #1280]                 ; 16-byte Spill
	fsub.4s	v10, v10, v29
	fcmge.4s	v2, v10, v1
	fcmge.4s	v3, v4, v10
	and.16b	v2, v2, v3
	fsub.4s	v0, v27, v9
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v21
	mov.16b	v23, v12
	bsl.16b	v23, v8, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v10
	fmul.4s	v2, v23, v21
	mov.16b	v24, v12
	bsl.16b	v24, v8, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v20
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v20
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v19
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v18
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v30
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v30
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v31
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v31
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v31
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v31
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	str	q10, [sp, #1184]                ; 16-byte Spill
	fcmgt.4s	v22, v1, v10
	bic.16b	v3, v3, v22
	str	q0, [sp, #1216]                 ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #1232]                 ; 16-byte Spill
	fcmgt.4s	v2, v10, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #1200]                 ; 16-byte Spill
	fsub.4s	v27, v28, v29
	fcmge.4s	v2, v27, v1
	fcmge.4s	v3, v4, v27
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1760]                 ; 16-byte Reload
	fsub.4s	v0, v3, v9
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v21
	mov.16b	v23, v12
	bsl.16b	v23, v8, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v27
	fmul.4s	v2, v23, v21
	mov.16b	v24, v12
	bsl.16b	v24, v8, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v20
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v20
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v19
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v18
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v30
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v30
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v31
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v31
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v31
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v31
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	str	q27, [sp, #1088]                ; 16-byte Spill
	fcmgt.4s	v22, v1, v27
	bic.16b	v3, v3, v22
	str	q0, [sp, #1120]                 ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #1136]                 ; 16-byte Spill
	fcmgt.4s	v2, v27, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #1104]                 ; 16-byte Spill
	ldr	q0, [sp, #1488]                 ; 16-byte Reload
	fsub.4s	v27, v0, v29
	fcmge.4s	v2, v27, v1
	fcmge.4s	v3, v4, v27
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1808]                 ; 16-byte Reload
	fsub.4s	v0, v3, v9
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v21
	mov.16b	v23, v12
	bsl.16b	v23, v8, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v27
	fmul.4s	v2, v23, v21
	mov.16b	v24, v12
	bsl.16b	v24, v8, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v20
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v20
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v19
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v18
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v30
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v30
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v31
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v31
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v31
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v31
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	str	q27, [sp, #1024]                ; 16-byte Spill
	fcmgt.4s	v22, v1, v27
	bic.16b	v3, v3, v22
	str	q0, [sp, #1056]                 ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #1072]                 ; 16-byte Spill
	fcmgt.4s	v2, v27, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #1040]                 ; 16-byte Spill
	ldr	q0, [sp, #1504]                 ; 16-byte Reload
	fsub.4s	v27, v0, v29
	fcmge.4s	v2, v27, v1
	fcmge.4s	v3, v4, v27
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1744]                 ; 16-byte Reload
	fsub.4s	v0, v3, v9
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v21
	mov.16b	v23, v12
	bsl.16b	v23, v8, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v27
	fmul.4s	v2, v23, v21
	mov.16b	v24, v12
	bsl.16b	v24, v8, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v20
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v20
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v19
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v18
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v30
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v30
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v31
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v31
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v31
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v31
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	fcmgt.4s	v22, v1, v27
	bic.16b	v3, v3, v22
	str	q0, [sp, #976]                  ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #992]                  ; 16-byte Spill
	fcmgt.4s	v2, v27, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	stp	q27, q0, [sp, #944]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1520]                 ; 16-byte Reload
	fsub.4s	v27, v0, v29
	fcmge.4s	v2, v27, v1
	fcmge.4s	v3, v4, v27
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1792]                 ; 16-byte Reload
	fsub.4s	v0, v3, v9
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v21
	mov.16b	v23, v12
	bsl.16b	v23, v8, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v27
	fmul.4s	v2, v23, v21
	mov.16b	v24, v12
	bsl.16b	v24, v8, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v20
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v20
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v19
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v18
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v30
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v30
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v31
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v31
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v31
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v31
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	fcmgt.4s	v22, v1, v27
	bic.16b	v3, v3, v22
	str	q0, [sp, #912]                  ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #928]                  ; 16-byte Spill
	fcmgt.4s	v2, v27, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	stp	q27, q0, [sp, #880]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1536]                 ; 16-byte Reload
	fsub.4s	v27, v0, v29
	fcmge.4s	v2, v27, v1
	fcmge.4s	v3, v4, v27
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1728]                 ; 16-byte Reload
	fsub.4s	v0, v3, v9
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v21
	mov.16b	v23, v12
	bsl.16b	v23, v8, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v27
	fmul.4s	v2, v23, v21
	mov.16b	v24, v12
	bsl.16b	v24, v8, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v20
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v20
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v19
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v18
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v30
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v30
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v31
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v31
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v31
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v31
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	fcmgt.4s	v22, v1, v27
	bic.16b	v3, v3, v22
	str	q0, [sp, #848]                  ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #864]                  ; 16-byte Spill
	fcmgt.4s	v2, v27, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	stp	q27, q0, [sp, #816]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1552]                 ; 16-byte Reload
	fsub.4s	v27, v0, v29
	fcmge.4s	v2, v27, v1
	fcmge.4s	v3, v4, v27
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1776]                 ; 16-byte Reload
	fsub.4s	v0, v3, v9
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v21
	mov.16b	v23, v12
	bsl.16b	v23, v8, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v27
	fmul.4s	v2, v23, v21
	mov.16b	v24, v12
	bsl.16b	v24, v8, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v20
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v20
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v19
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v18
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v30
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v30
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v31
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v31
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v31
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v31
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	fcmgt.4s	v22, v1, v27
	bic.16b	v3, v3, v22
	str	q0, [sp, #768]                  ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #800]                  ; 16-byte Spill
	fcmgt.4s	v2, v27, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	stp	q27, q0, [sp, #736]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1568]                 ; 16-byte Reload
	fsub.4s	v27, v0, v29
	fcmge.4s	v2, v27, v1
	fcmge.4s	v3, v4, v27
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1712]                 ; 16-byte Reload
	fsub.4s	v0, v3, v9
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v21
	mov.16b	v23, v12
	bsl.16b	v23, v8, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v27
	fmul.4s	v2, v23, v21
	mov.16b	v24, v12
	bsl.16b	v24, v8, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v20
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v20
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v19
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v18
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v30
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v30
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v31
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v31
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v31
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v31
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	fcmgt.4s	v22, v1, v27
	bic.16b	v3, v3, v22
	str	q0, [sp, #704]                  ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #720]                  ; 16-byte Spill
	fcmgt.4s	v2, v27, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	stp	q27, q0, [sp, #672]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1584]                 ; 16-byte Reload
	fsub.4s	v27, v0, v29
	fcmge.4s	v2, v27, v1
	fcmge.4s	v3, v4, v27
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1696]                 ; 16-byte Reload
	fsub.4s	v0, v3, v9
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v21
	mov.16b	v23, v12
	bsl.16b	v23, v8, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v27
	fmul.4s	v2, v23, v21
	mov.16b	v24, v12
	bsl.16b	v24, v8, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v20
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v20
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v19
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v18
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v30
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v30
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v31
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v31
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v31
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v31
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	fcmgt.4s	v22, v1, v27
	bic.16b	v3, v3, v22
	str	q0, [sp, #640]                  ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #656]                  ; 16-byte Spill
	fcmgt.4s	v2, v27, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	stp	q27, q0, [sp, #608]             ; 32-byte Folded Spill
	fsub.4s	v27, v15, v29
	fcmge.4s	v2, v27, v1
	fcmge.4s	v3, v4, v27
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1680]                 ; 16-byte Reload
	fsub.4s	v0, v3, v9
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v21
	mov.16b	v23, v12
	bsl.16b	v23, v8, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v27
	fmul.4s	v2, v23, v21
	mov.16b	v24, v12
	bsl.16b	v24, v8, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v20
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v20
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v19
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v18
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v30
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v30
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v31
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v31
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v31
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v31
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	fcmgt.4s	v22, v1, v27
	bic.16b	v3, v3, v22
	str	q0, [sp, #576]                  ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #592]                  ; 16-byte Spill
	fcmgt.4s	v2, v27, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	stp	q27, q0, [sp, #544]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1600]                 ; 16-byte Reload
	fsub.4s	v28, v0, v29
	fcmge.4s	v2, v28, v1
	fcmge.4s	v3, v4, v28
	and.16b	v2, v2, v3
	ldr	q0, [sp, #1648]                 ; 16-byte Reload
	fsub.4s	v0, v0, v9
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v21
	mov.16b	v23, v12
	bsl.16b	v23, v8, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v28
	fmul.4s	v2, v23, v21
	mov.16b	v24, v12
	bsl.16b	v24, v8, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v20
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v20
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v19
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v18
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v30
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v30
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v31
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v31
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v31
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v31
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	fcmgt.4s	v22, v1, v28
	bic.16b	v3, v3, v22
	str	q0, [sp, #512]                  ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #528]                  ; 16-byte Spill
	fcmgt.4s	v2, v28, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #496]                  ; 16-byte Spill
	ldr	q0, [sp, #1616]                 ; 16-byte Reload
	fsub.4s	v27, v0, v29
	fcmge.4s	v2, v27, v1
	fcmge.4s	v3, v4, v27
	and.16b	v2, v2, v3
	ldr	q0, [sp, #1632]                 ; 16-byte Reload
	fsub.4s	v0, v0, v9
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v21
	mov.16b	v23, v12
	bsl.16b	v23, v8, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v27
	fmul.4s	v2, v23, v21
	mov.16b	v24, v12
	bsl.16b	v24, v8, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v20
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v20
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v19
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v18
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v30
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v30
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v31
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v31
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v31
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v31
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	fcmgt.4s	v22, v1, v27
	bic.16b	v3, v3, v22
	str	q0, [sp, #464]                  ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #480]                  ; 16-byte Spill
	fcmgt.4s	v2, v27, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	stp	q27, q0, [sp, #432]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1408]                 ; 16-byte Reload
	fsub.4s	v27, v0, v29
	fcmge.4s	v2, v27, v1
	fcmge.4s	v3, v4, v27
	and.16b	v2, v2, v3
	ldr	q26, [sp, #1008]                ; 16-byte Reload
	fsub.4s	v0, v26, v9
	fcmge.4s	v3, v0, v1
	fcmge.4s	v22, v4, v0
	and.16b	v3, v3, v22
	and.16b	v3, v3, v0
	fmul.4s	v22, v3, v21
	mov.16b	v23, v12
	bsl.16b	v23, v8, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v27
	fmul.4s	v2, v23, v21
	mov.16b	v24, v12
	bsl.16b	v24, v8, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v25, v22, v20
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v10, v25, v20
	fsub.4s	v23, v23, v10
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v19
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v18
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v30
	fmul.4s	v25, v3, v3
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v30
	fmul.4s	v10, v23, v23
	fmul.4s	v25, v10, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v31
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v31
	fmul.4s	v22, v22, v25
	fadd.4s	v3, v3, v31
	sshr.4s	v25, v2, #1
	shl.4s	v10, v25, #23
	add.4s	v10, v10, v31
	fmul.4s	v3, v3, v10
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	fcmgt.4s	v22, v1, v27
	bic.16b	v3, v3, v22
	str	q0, [sp, #400]                  ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v0, v4
	mov.16b	v0, v22
	bsl.16b	v0, v5, v2
	str	q0, [sp, #416]                  ; 16-byte Spill
	fcmgt.4s	v2, v27, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	stp	q27, q0, [sp, #368]             ; 32-byte Folded Spill
	mov.16b	v25, v13
	fsub.4s	v0, v13, v29
	fcmge.4s	v2, v0, v1
	fcmge.4s	v3, v4, v0
	and.16b	v2, v2, v3
	ldr	q24, [sp, #784]                 ; 16-byte Reload
	fsub.4s	v27, v24, v9
	fcmge.4s	v3, v27, v1
	fcmge.4s	v22, v4, v27
	and.16b	v3, v3, v22
	and.16b	v3, v3, v27
	fmul.4s	v22, v3, v21
	mov.16b	v23, v12
	bsl.16b	v23, v8, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v2, v0
	fmul.4s	v2, v23, v21
	mov.16b	v10, v12
	bsl.16b	v10, v8, v2
	fadd.4s	v2, v2, v10
	fsub.4s	v10, v2, v10
	fcvtzs.4s	v2, v22
	scvtf.4s	v22, v2
	fmul.4s	v11, v22, v20
	fsub.4s	v3, v3, v11
	fcvtzs.4s	v10, v10
	scvtf.4s	v11, v10
	fmul.4s	v15, v11, v20
	fsub.4s	v23, v23, v15
	fmul.4s	v11, v11, v19
	fsub.4s	v23, v23, v11
	fmul.4s	v22, v22, v19
	fsub.4s	v3, v3, v22
	fmul.4s	v22, v3, v18
	fadd.4s	v22, v22, v17
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v16
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v6
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v22, v30
	fmul.4s	v11, v3, v3
	fmul.4s	v22, v11, v22
	fmul.4s	v11, v23, v18
	fadd.4s	v11, v11, v17
	fmul.4s	v11, v23, v11
	fadd.4s	v11, v11, v16
	fmul.4s	v11, v23, v11
	fadd.4s	v11, v11, v7
	fmul.4s	v11, v23, v11
	fadd.4s	v11, v11, v6
	fmul.4s	v11, v23, v11
	fadd.4s	v11, v11, v30
	fmul.4s	v15, v23, v23
	fmul.4s	v11, v15, v11
	fadd.4s	v23, v23, v11
	fadd.4s	v3, v3, v22
	fadd.4s	v22, v23, v31
	sshr.4s	v23, v10, #1
	shl.4s	v11, v23, #23
	add.4s	v11, v11, v31
	fmul.4s	v22, v22, v11
	fadd.4s	v3, v3, v31
	sshr.4s	v11, v2, #1
	shl.4s	v15, v11, #23
	add.4s	v15, v15, v31
	fmul.4s	v3, v3, v15
	sub.4s	v23, v10, v23
	sub.4s	v2, v2, v11
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v22, v3
	str	q0, [sp, #304]                  ; 16-byte Spill
	fcmgt.4s	v22, v1, v0
	bic.16b	v3, v3, v22
	fcmgt.4s	v22, v1, v27
	bic.16b	v2, v2, v22
	fcmgt.4s	v22, v27, v4
	bit.16b	v2, v5, v22
	stp	q27, q2, [sp, #336]             ; 32-byte Folded Spill
	fcmgt.4s	v2, v0, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #320]                  ; 16-byte Spill
	ldr	q23, [sp, #1152]                ; 16-byte Reload
	fsub.4s	v0, v23, v29
	fcmge.4s	v2, v0, v1
	fcmge.4s	v3, v4, v0
	and.16b	v2, v2, v3
	ldr	q22, [sp, #1168]                ; 16-byte Reload
	fsub.4s	v27, v22, v9
	fcmge.4s	v3, v27, v1
	fcmge.4s	v10, v4, v27
	and.16b	v3, v3, v10
	and.16b	v3, v3, v27
	fmul.4s	v10, v3, v21
	mov.16b	v11, v12
	bsl.16b	v11, v8, v10
	fadd.4s	v10, v10, v11
	fsub.4s	v10, v10, v11
	and.16b	v11, v2, v0
	fmul.4s	v2, v11, v21
	mov.16b	v15, v12
	bsl.16b	v15, v8, v2
	fadd.4s	v2, v2, v15
	fsub.4s	v15, v2, v15
	fcvtzs.4s	v2, v10
	scvtf.4s	v10, v2
	fmul.4s	v14, v10, v20
	fsub.4s	v3, v3, v14
	fcvtzs.4s	v14, v15
	scvtf.4s	v15, v14
	fmul.4s	v13, v15, v20
	fsub.4s	v11, v11, v13
	fmul.4s	v13, v15, v19
	fsub.4s	v11, v11, v13
	fmul.4s	v10, v10, v19
	fsub.4s	v3, v3, v10
	fmul.4s	v10, v3, v18
	fadd.4s	v10, v10, v17
	fmul.4s	v10, v3, v10
	fadd.4s	v10, v10, v16
	fmul.4s	v10, v3, v10
	fadd.4s	v10, v10, v7
	fmul.4s	v10, v3, v10
	fadd.4s	v10, v10, v6
	fmul.4s	v10, v3, v10
	fadd.4s	v10, v10, v30
	fmul.4s	v13, v3, v3
	fmul.4s	v10, v13, v10
	fmul.4s	v13, v11, v18
	fadd.4s	v13, v13, v17
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v13, v16
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v13, v7
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v13, v6
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v13, v30
	fmul.4s	v15, v11, v11
	fmul.4s	v13, v15, v13
	fadd.4s	v11, v11, v13
	fadd.4s	v3, v3, v10
	fadd.4s	v10, v11, v31
	sshr.4s	v11, v14, #1
	shl.4s	v13, v11, #23
	add.4s	v13, v13, v31
	fmul.4s	v10, v10, v13
	fadd.4s	v3, v3, v31
	sshr.4s	v13, v2, #1
	shl.4s	v15, v13, #23
	add.4s	v15, v15, v31
	fmul.4s	v3, v3, v15
	sub.4s	v11, v14, v11
	sub.4s	v2, v2, v13
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v31
	fmul.4s	v2, v3, v2
	shl.4s	v3, v11, #23
	add.4s	v3, v3, v31
	fmul.4s	v3, v10, v3
	str	q0, [sp, #240]                  ; 16-byte Spill
	fcmgt.4s	v10, v1, v0
	bic.16b	v3, v3, v10
	fcmgt.4s	v10, v1, v27
	bic.16b	v2, v2, v10
	fcmgt.4s	v10, v27, v4
	bit.16b	v2, v5, v10
	stp	q27, q2, [sp, #272]             ; 32-byte Folded Spill
	fcmgt.4s	v2, v0, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #256]                  ; 16-byte Spill
	str	q29, [sp, #1344]                ; 16-byte Spill
	ldr	q0, [sp, #1824]                 ; 16-byte Reload
	fsub.4s	v3, v0, v29
	fcmge.4s	v2, v3, v1
	fcmge.4s	v13, v4, v3
	and.16b	v13, v2, v13
	str	q9, [sp, #1360]                 ; 16-byte Spill
	ldr	q0, [sp, #1840]                 ; 16-byte Reload
	fsub.4s	v2, v0, v9
	fcmge.4s	v14, v2, v1
	fcmge.4s	v15, v4, v2
	and.16b	v14, v14, v15
	and.16b	v14, v14, v2
	fmul.4s	v15, v14, v21
	mov.16b	v0, v12
	bsl.16b	v0, v8, v15
	fadd.4s	v15, v15, v0
	fsub.4s	v0, v15, v0
	and.16b	v13, v13, v3
	fmul.4s	v21, v13, v21
	mov.16b	v15, v12
	bsl.16b	v15, v8, v21
	fadd.4s	v21, v21, v15
	fsub.4s	v21, v21, v15
	fcvtzs.4s	v0, v0
	scvtf.4s	v15, v0
	fmul.4s	v11, v15, v20
	fsub.4s	v11, v14, v11
	fcvtzs.4s	v21, v21
	scvtf.4s	v14, v21
	fmul.4s	v20, v14, v20
	fsub.4s	v20, v13, v20
	fmul.4s	v13, v15, v19
	fmul.4s	v19, v14, v19
	fsub.4s	v19, v20, v19
	fsub.4s	v20, v11, v13
	fmul.4s	v11, v20, v18
	fmul.4s	v18, v19, v18
	fadd.4s	v18, v18, v17
	fadd.4s	v17, v11, v17
	fmul.4s	v17, v20, v17
	fmul.4s	v18, v19, v18
	fadd.4s	v18, v18, v16
	fadd.4s	v16, v17, v16
	fmul.4s	v16, v20, v16
	fmul.4s	v17, v19, v18
	fadd.4s	v17, v17, v7
	fadd.4s	v7, v16, v7
	fmul.4s	v7, v20, v7
	fmul.4s	v16, v19, v17
	fadd.4s	v16, v16, v6
	fadd.4s	v6, v7, v6
	fmul.4s	v6, v20, v6
	fadd.4s	v6, v6, v30
	fmul.4s	v7, v20, v20
	fmul.4s	v6, v7, v6
	fmul.4s	v7, v19, v16
	fadd.4s	v7, v7, v30
	fmul.4s	v16, v19, v19
	fmul.4s	v7, v16, v7
	fadd.4s	v7, v19, v7
	fadd.4s	v6, v20, v6
	fadd.4s	v7, v7, v31
	sshr.4s	v16, v21, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v31
	fmul.4s	v7, v7, v17
	fadd.4s	v6, v6, v31
	sshr.4s	v17, v0, #1
	shl.4s	v18, v17, #23
	add.4s	v18, v18, v31
	fmul.4s	v6, v6, v18
	sub.4s	v16, v21, v16
	sub.4s	v0, v0, v17
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v31
	fmul.4s	v0, v6, v0
	shl.4s	v6, v16, #23
	add.4s	v6, v6, v31
	fmul.4s	v6, v7, v6
	fcmgt.4s	v7, v1, v3
	bic.16b	v6, v6, v7
	fcmgt.4s	v1, v1, v2
	bic.16b	v0, v0, v1
	fcmgt.4s	v1, v2, v4
	bit.16b	v0, v5, v1
	stp	q2, q0, [sp, #208]              ; 32-byte Folded Spill
	fcmgt.4s	v1, v3, v4
	mov.16b	v0, v1
	bsl.16b	v0, v5, v6
	stp	q3, q0, [sp, #176]              ; 32-byte Folded Spill
	ldr	q1, [sp, #1472]                 ; 16-byte Reload
	ldr	q0, [sp, #1664]                 ; 16-byte Reload
	stp	q0, q1, [x21]
	ldr	q1, [sp, #1456]                 ; 16-byte Reload
	ldr	q0, [sp, #1248]                 ; 16-byte Reload
	stp	q0, q1, [x21, #32]
	ldr	q1, [sp, #1440]                 ; 16-byte Reload
	ldr	q0, [sp, #1760]                 ; 16-byte Reload
	stp	q0, q1, [x21, #64]
	ldr	q1, [sp, #1488]                 ; 16-byte Reload
	ldr	q0, [sp, #1808]                 ; 16-byte Reload
	stp	q0, q1, [x21, #96]
	ldr	q1, [sp, #1504]                 ; 16-byte Reload
	ldr	q0, [sp, #1744]                 ; 16-byte Reload
	stp	q0, q1, [x21, #128]
	ldr	q1, [sp, #1520]                 ; 16-byte Reload
	ldr	q0, [sp, #1792]                 ; 16-byte Reload
	stp	q0, q1, [x21, #160]
	ldr	q1, [sp, #1536]                 ; 16-byte Reload
	ldr	q0, [sp, #1728]                 ; 16-byte Reload
	stp	q0, q1, [x21, #192]
	ldr	q1, [sp, #1552]                 ; 16-byte Reload
	ldr	q0, [sp, #1776]                 ; 16-byte Reload
	stp	q0, q1, [x21, #224]
	ldr	q1, [sp, #1568]                 ; 16-byte Reload
	ldr	q0, [sp, #1712]                 ; 16-byte Reload
	stp	q0, q1, [x21, #256]
	ldr	q1, [sp, #1584]                 ; 16-byte Reload
	ldr	q0, [sp, #1696]                 ; 16-byte Reload
	stp	q0, q1, [x21, #288]
	ldr	q1, [sp, #1424]                 ; 16-byte Reload
	ldr	q0, [sp, #1680]                 ; 16-byte Reload
	stp	q0, q1, [x21, #320]
	ldr	q1, [sp, #1600]                 ; 16-byte Reload
	ldr	q0, [sp, #1648]                 ; 16-byte Reload
	stp	q0, q1, [x21, #352]
	ldr	q1, [sp, #1616]                 ; 16-byte Reload
	ldr	q0, [sp, #1632]                 ; 16-byte Reload
	stp	q0, q1, [x21, #384]
	ldr	q0, [sp, #1408]                 ; 16-byte Reload
	stp	q26, q0, [x21, #416]
	stp	q24, q25, [x21, #448]
	stp	q22, q23, [x21, #480]
	ldr	q0, [sp, #1264]                 ; 16-byte Reload
	fcmeq.4s	v4, v0, v0
	ldr	q2, [sp, #80]                   ; 16-byte Reload
	ldr	q0, [sp, #1280]                 ; 16-byte Reload
	bif.16b	v0, v2, v4
	str	q0, [sp, #1744]                 ; 16-byte Spill
	ldr	q0, [sp, #1312]                 ; 16-byte Reload
	fcmeq.4s	v4, v0, v0
	ldr	q0, [sp, #1296]                 ; 16-byte Reload
	bif.16b	v0, v2, v4
	str	q0, [sp, #1728]                 ; 16-byte Spill
	ldr	q0, [sp, #1184]                 ; 16-byte Reload
	fcmeq.4s	v4, v0, v0
	ldr	q0, [sp, #1200]                 ; 16-byte Reload
	bif.16b	v0, v2, v4
	str	q0, [sp, #1840]                 ; 16-byte Spill
	ldr	q0, [sp, #1216]                 ; 16-byte Reload
	fcmeq.4s	v5, v0, v0
	ldr	q0, [sp, #1232]                 ; 16-byte Reload
	bsl.16b	v5, v0, v2
	ldr	q0, [sp, #1088]                 ; 16-byte Reload
	fcmeq.4s	v6, v0, v0
	ldr	q0, [sp, #1104]                 ; 16-byte Reload
	bif.16b	v0, v2, v6
	str	q0, [sp, #1824]                 ; 16-byte Spill
	ldr	q0, [sp, #1120]                 ; 16-byte Reload
	fcmeq.4s	v7, v0, v0
	ldr	q0, [sp, #1136]                 ; 16-byte Reload
	bif.16b	v0, v2, v7
	str	q0, [sp, #1776]                 ; 16-byte Spill
	ldr	q0, [sp, #1024]                 ; 16-byte Reload
	fcmeq.4s	v16, v0, v0
	ldr	q0, [sp, #1040]                 ; 16-byte Reload
	bif.16b	v0, v2, v16
	str	q0, [sp, #1792]                 ; 16-byte Spill
	ldr	q0, [sp, #1056]                 ; 16-byte Reload
	fcmeq.4s	v17, v0, v0
	ldr	q0, [sp, #1072]                 ; 16-byte Reload
	mov.16b	v7, v17
	bsl.16b	v7, v0, v2
	ldp	q1, q0, [sp, #944]              ; 32-byte Folded Reload
	fcmeq.4s	v18, v1, v1
	bif.16b	v0, v2, v18
	str	q0, [sp, #1760]                 ; 16-byte Spill
	ldp	q4, q0, [sp, #976]              ; 32-byte Folded Reload
	fcmeq.4s	v19, v4, v4
	bif.16b	v0, v2, v19
	str	q0, [sp, #1696]                 ; 16-byte Spill
	ldp	q6, q0, [sp, #880]              ; 32-byte Folded Reload
	fcmeq.4s	v20, v6, v6
	bif.16b	v0, v2, v20
	str	q0, [sp, #1712]                 ; 16-byte Spill
	ldr	q0, [sp, #912]                  ; 16-byte Reload
	fcmeq.4s	v21, v0, v0
	ldr	q0, [sp, #928]                  ; 16-byte Reload
	mov.16b	v16, v21
	bsl.16b	v16, v0, v2
	ldr	q0, [sp, #816]                  ; 16-byte Reload
	fcmeq.4s	v11, v0, v0
	ldr	q0, [sp, #832]                  ; 16-byte Reload
	bsl.16b	v11, v0, v2
	ldr	q0, [sp, #848]                  ; 16-byte Reload
	fcmeq.4s	v13, v0, v0
	ldr	q0, [sp, #864]                  ; 16-byte Reload
	bsl.16b	v13, v0, v2
	ldr	q0, [sp, #736]                  ; 16-byte Reload
	fcmeq.4s	v14, v0, v0
	ldr	q0, [sp, #752]                  ; 16-byte Reload
	mov.16b	v18, v14
	bsl.16b	v18, v0, v2
	ldr	q0, [sp, #768]                  ; 16-byte Reload
	fcmeq.4s	v15, v0, v0
	ldr	q0, [sp, #800]                  ; 16-byte Reload
	mov.16b	v17, v15
	bsl.16b	v17, v0, v2
	ldr	q0, [sp, #672]                  ; 16-byte Reload
	fcmeq.4s	v10, v0, v0
	ldr	q0, [sp, #688]                  ; 16-byte Reload
	bsl.16b	v10, v0, v2
	ldr	q0, [sp, #704]                  ; 16-byte Reload
	fcmeq.4s	v12, v0, v0
	ldr	q0, [sp, #720]                  ; 16-byte Reload
	bsl.16b	v12, v0, v2
	ldr	q0, [sp, #608]                  ; 16-byte Reload
	fcmeq.4s	v9, v0, v0
	ldr	q0, [sp, #624]                  ; 16-byte Reload
	mov.16b	v15, v9
	bsl.16b	v15, v0, v2
	ldr	q0, [sp, #640]                  ; 16-byte Reload
	fcmeq.4s	v8, v0, v0
	ldr	q0, [sp, #656]                  ; 16-byte Reload
	bsl.16b	v8, v0, v2
	ldr	q0, [sp, #544]                  ; 16-byte Reload
	fcmeq.4s	v31, v0, v0
	ldr	q0, [sp, #560]                  ; 16-byte Reload
	mov.16b	v19, v31
	bsl.16b	v19, v0, v2
	ldr	q0, [sp, #576]                  ; 16-byte Reload
	fcmeq.4s	v30, v0, v0
	ldr	q0, [sp, #592]                  ; 16-byte Reload
	bsl.16b	v30, v0, v2
	fcmeq.4s	v29, v28, v28
	ldp	q1, q0, [sp, #480]              ; 32-byte Folded Reload
	bif.16b	v0, v2, v29
	str	q0, [sp, #1680]                 ; 16-byte Spill
	ldr	q0, [sp, #512]                  ; 16-byte Reload
	fcmeq.4s	v28, v0, v0
	ldr	q0, [sp, #528]                  ; 16-byte Reload
	bsl.16b	v28, v0, v2
	ldr	q0, [sp, #432]                  ; 16-byte Reload
	fcmeq.4s	v26, v0, v0
	ldr	q0, [sp, #448]                  ; 16-byte Reload
	mov.16b	v3, v26
	bsl.16b	v3, v0, v2
	ldr	q0, [sp, #464]                  ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	mov.16b	v26, v0
	bsl.16b	v26, v1, v2
	ldr	q0, [sp, #368]                  ; 16-byte Reload
	fcmeq.4s	v1, v0, v0
	ldr	q0, [sp, #384]                  ; 16-byte Reload
	mov.16b	v27, v1
	bsl.16b	v27, v0, v2
	ldp	q1, q0, [sp, #400]              ; 32-byte Folded Reload
	fcmeq.4s	v25, v1, v1
	mov.16b	v20, v25
	bsl.16b	v20, v0, v2
	ldr	q0, [sp, #304]                  ; 16-byte Reload
	fcmeq.4s	v24, v0, v0
	ldr	q0, [sp, #320]                  ; 16-byte Reload
	mov.16b	v21, v24
	bsl.16b	v21, v0, v2
	ldr	q0, [sp, #336]                  ; 16-byte Reload
	fcmeq.4s	v23, v0, v0
	ldr	q0, [sp, #352]                  ; 16-byte Reload
	mov.16b	v29, v23
	bsl.16b	v29, v0, v2
	ldr	q0, [sp, #240]                  ; 16-byte Reload
	fcmeq.4s	v22, v0, v0
	ldr	q0, [sp, #256]                  ; 16-byte Reload
	bif.16b	v0, v2, v22
	str	q0, [sp, #1664]                 ; 16-byte Spill
	ldr	q0, [sp, #272]                  ; 16-byte Reload
	fcmeq.4s	v4, v0, v0
	ldr	q0, [sp, #288]                  ; 16-byte Reload
	bsl.16b	v4, v0, v2
	ldr	q0, [sp, #1328]                 ; 16-byte Reload
	and.16b	v6, v0, v5
	ldr	q5, [sp, #1728]                 ; 16-byte Reload
	ldr	q1, [sp, #1840]                 ; 16-byte Reload
	and.16b	v1, v0, v1
	str	q1, [sp, #1808]                 ; 16-byte Spill
	ldr	q1, [sp, #1776]                 ; 16-byte Reload
	and.16b	v22, v0, v1
	ldr	q1, [sp, #1824]                 ; 16-byte Reload
	and.16b	v23, v0, v1
	and.16b	v7, v0, v7
	ldr	q1, [sp, #1792]                 ; 16-byte Reload
	and.16b	v31, v0, v1
	ldr	q1, [sp, #1696]                 ; 16-byte Reload
	and.16b	v24, v0, v1
	ldr	q1, [sp, #1760]                 ; 16-byte Reload
	and.16b	v25, v0, v1
	and.16b	v16, v0, v16
	ldr	q1, [sp, #1712]                 ; 16-byte Reload
	and.16b	v9, v0, v1
	and.16b	v13, v0, v13
	and.16b	v11, v0, v11
	and.16b	v17, v0, v17
	and.16b	v14, v0, v18
	and.16b	v12, v0, v12
	and.16b	v10, v0, v10
	and.16b	v18, v0, v8
	and.16b	v15, v0, v15
	and.16b	v30, v0, v30
	and.16b	v8, v0, v19
	and.16b	v19, v0, v28
	ldr	q1, [sp, #1680]                 ; 16-byte Reload
	and.16b	v1, v0, v1
	str	q1, [sp, #1840]                 ; 16-byte Spill
	and.16b	v26, v0, v26
	and.16b	v28, v0, v3
	and.16b	v20, v0, v20
	and.16b	v3, v0, v27
	and.16b	v27, v0, v29
	and.16b	v29, v0, v21
	and.16b	v21, v0, v4
	ldr	q4, [sp, #1744]                 ; 16-byte Reload
	ldr	q1, [sp, #1664]                 ; 16-byte Reload
	and.16b	v0, v0, v1
	str	q0, [sp, #1824]                 ; 16-byte Spill
	ldp	q0, q1, [sp, #176]              ; 32-byte Folded Reload
	fcmeq.4s	v0, v0, v0
	bsl.16b	v0, v1, v2
	str	q0, [sp, #1776]                 ; 16-byte Spill
	ldp	q0, q1, [sp, #208]              ; 32-byte Folded Reload
	fcmeq.4s	v0, v0, v0
	bsl.16b	v0, v1, v2
	str	q0, [sp, #1760]                 ; 16-byte Spill
	stp	q4, q5, [x21, #512]
	ldr	q0, [sp, #1808]                 ; 16-byte Reload
	stp	q6, q0, [x21, #544]
	stp	q22, q23, [x21, #576]
	stp	q7, q31, [x21, #608]
	stp	q24, q25, [x21, #640]
	stp	q16, q9, [x21, #672]
	stp	q13, q11, [x21, #704]
	stp	q17, q14, [x21, #736]
	stp	q12, q10, [x21, #768]
	stp	q18, q15, [x21, #800]
	stp	q30, q8, [x21, #832]
	ldr	q0, [sp, #1840]                 ; 16-byte Reload
	stp	q19, q0, [x21, #864]
	stp	q26, q28, [x21, #896]
	str	q3, [sp, #1792]                 ; 16-byte Spill
	stp	q20, q3, [x21, #928]
	stp	q27, q29, [x21, #960]
	ldr	q0, [sp, #1824]                 ; 16-byte Reload
	stp	q21, q0, [x21, #992]
	add	x8, x20, #19, lsl #12           ; =77824
	mov	w9, #128                        ; =0x80
LBB0_44:                                ; %direct.true739
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sub	x10, x8, #18, lsl #12           ; =73728
	ldp	q1, q0, [x10]
	ldr	q2, [sp, #1776]                 ; 16-byte Reload
	fmul.4s	v0, v2, v0
	ldp	q3, q2, [x8]
	fmul.4s	v2, v5, v2
	fadd.4s	v0, v0, v2
	fmul.4s	v2, v4, v3
	ldr	q3, [sp, #1760]                 ; 16-byte Reload
	fmul.4s	v1, v3, v1
	fadd.4s	v1, v1, v2
	ldr	q2, [x8, #4096]
	fmul.4s	v2, v6, v2
	fadd.4s	v1, v1, v2
	ldr	q2, [x8, #4112]
	ldr	q3, [sp, #1808]                 ; 16-byte Reload
	fmul.4s	v2, v3, v2
	fadd.4s	v0, v0, v2
	ldr	q2, [x8, #8208]
	fmul.4s	v2, v23, v2
	fadd.4s	v0, v0, v2
	ldr	q2, [x8, #8192]
	fmul.4s	v2, v22, v2
	fadd.4s	v1, v1, v2
	ldr	q2, [x8, #12288]
	fmul.4s	v2, v7, v2
	fadd.4s	v1, v1, v2
	ldr	q2, [x8, #12304]
	fmul.4s	v2, v31, v2
	fadd.4s	v0, v0, v2
	ldr	q2, [x8, #16400]
	fmul.4s	v2, v25, v2
	fadd.4s	v0, v0, v2
	ldr	q2, [x8, #16384]
	fmul.4s	v2, v24, v2
	fadd.4s	v1, v1, v2
	ldr	q2, [x8, #20480]
	fmul.4s	v2, v16, v2
	fadd.4s	v1, v1, v2
	ldr	q2, [x8, #20496]
	fmul.4s	v2, v9, v2
	fadd.4s	v0, v0, v2
	ldr	q2, [x8, #24592]
	fmul.4s	v2, v11, v2
	fadd.4s	v0, v0, v2
	ldr	q2, [x8, #24576]
	fmul.4s	v2, v13, v2
	fadd.4s	v1, v1, v2
	ldr	q2, [x8, #28672]
	fmul.4s	v2, v17, v2
	fadd.4s	v1, v1, v2
	ldr	q2, [x8, #28688]
	fmul.4s	v2, v14, v2
	fadd.4s	v0, v0, v2
	ldr	q2, [x8, #32784]
	fmul.4s	v2, v10, v2
	fadd.4s	v0, v0, v2
	ldr	q2, [x8, #32768]
	fmul.4s	v2, v12, v2
	fadd.4s	v1, v1, v2
	ldr	q2, [x8, #36864]
	fmul.4s	v2, v18, v2
	fadd.4s	v1, v1, v2
	ldr	q2, [x8, #36880]
	fmul.4s	v2, v15, v2
	fadd.4s	v0, v0, v2
	ldr	q2, [x8, #40976]
	fmul.4s	v2, v8, v2
	fadd.4s	v0, v0, v2
	ldr	q2, [x8, #40960]
	fmul.4s	v2, v30, v2
	fadd.4s	v1, v1, v2
	ldr	q2, [x8, #45056]
	fmul.4s	v2, v19, v2
	fadd.4s	v1, v1, v2
	ldr	q2, [x8, #45072]
	ldr	q3, [sp, #1840]                 ; 16-byte Reload
	fmul.4s	v2, v3, v2
	fadd.4s	v0, v0, v2
	ldr	q2, [x8, #49168]
	fmul.4s	v2, v28, v2
	fadd.4s	v0, v0, v2
	ldr	q2, [x8, #49152]
	fmul.4s	v2, v26, v2
	fadd.4s	v1, v1, v2
	ldr	q2, [x8, #53248]
	fmul.4s	v2, v20, v2
	fadd.4s	v1, v1, v2
	ldr	q2, [x8, #53264]
	ldr	q3, [sp, #1792]                 ; 16-byte Reload
	fmul.4s	v2, v3, v2
	fadd.4s	v0, v0, v2
	ldr	q2, [x8, #57360]
	fmul.4s	v2, v29, v2
	fadd.4s	v0, v0, v2
	ldr	q2, [x8, #57344]
	fmul.4s	v2, v27, v2
	fadd.4s	v1, v1, v2
	ldr	q2, [x8, #61440]
	fmul.4s	v2, v21, v2
	fadd.4s	v1, v1, v2
	ldr	q2, [x8, #61456]
	ldr	q3, [sp, #1824]                 ; 16-byte Reload
	fmul.4s	v2, v3, v2
	fadd.4s	v0, v0, v2
	add	x10, x8, x28
	stp	q1, q0, [x10]
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_44
; %bb.45:                               ; %direct.true867.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, x20, #2, lsl #12            ; =8192
	add	x1, x20, x27
	mov	w2, #4096                       ; =0x1000
	str	q6, [sp, #1312]                 ; 16-byte Spill
	str	q7, [sp, #1440]                 ; 16-byte Spill
	str	q16, [sp, #1504]                ; 16-byte Spill
	str	q17, [sp, #1568]                ; 16-byte Spill
	str	q18, [sp, #1616]                ; 16-byte Spill
	str	q19, [sp, #1680]                ; 16-byte Spill
	str	q20, [sp, #1696]                ; 16-byte Spill
	str	q21, [sp, #1712]                ; 16-byte Spill
	str	q22, [sp, #1264]                ; 16-byte Spill
	str	q23, [sp, #1280]                ; 16-byte Spill
	str	q24, [sp, #1328]                ; 16-byte Spill
	str	q25, [sp, #1424]                ; 16-byte Spill
	str	q13, [sp, #1456]                ; 16-byte Spill
	str	q11, [sp, #1472]                ; 16-byte Spill
	str	q12, [sp, #1520]                ; 16-byte Spill
	str	q10, [sp, #1536]                ; 16-byte Spill
	str	q30, [sp, #1552]                ; 16-byte Spill
	str	q8, [sp, #1584]                 ; 16-byte Spill
	str	q26, [sp, #1600]                ; 16-byte Spill
	str	q28, [sp, #1632]                ; 16-byte Spill
	str	q27, [sp, #1648]                ; 16-byte Spill
	str	q29, [sp, #1664]                ; 16-byte Spill
	str	q31, [sp, #1248]                ; 16-byte Spill
	str	q9, [sp, #1296]                 ; 16-byte Spill
	str	q14, [sp, #1408]                ; 16-byte Spill
	str	q15, [sp, #1488]                ; 16-byte Spill
	bl	_memcpy
	add	x0, x20, #1, lsl #12            ; =4096
	add	x1, x20, x27
	mov	w2, #4096                       ; =0x1000
	bl	_memcpy
	ldr	q0, [sp, #1376]                 ; 16-byte Reload
	ldr	q1, [sp, #1776]                 ; 16-byte Reload
	fmul.4s	v0, v0, v1
	ldr	q1, [sp, #1392]                 ; 16-byte Reload
	ldr	q2, [sp, #1760]                 ; 16-byte Reload
	fmul.4s	v1, v1, v2
	movi.2d	v3, #0000000000000000
	ldr	q2, [sp, #1728]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q4, [sp, #1808]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1744]                 ; 16-byte Reload
	fadd.4s	v3, v4, v3
	ldr	q4, [sp, #1312]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1264]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1280]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1248]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1440]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1328]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1424]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1296]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1504]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1456]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1472]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1408]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1568]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1520]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1536]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1488]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1616]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1552]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1584]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1840]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1680]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1600]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1632]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1792]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1696]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1648]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1664]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1824]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1712]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	fadd.4s	v19, v1, v3
	fadd.4s	v20, v0, v2
	add	x24, x24, #1
	ldr	q1, [sp, #1360]                 ; 16-byte Reload
	ldr	q0, [sp, #1344]                 ; 16-byte Reload
	cmp	x24, #513
	ldp	q7, q6, [sp, #144]              ; 32-byte Folded Reload
	ldp	q17, q16, [sp, #112]            ; 32-byte Folded Reload
	ldr	q18, [sp, #96]                  ; 16-byte Reload
	b.ne	LBB0_3
; %bb.46:                               ; %direct.true902.preheader
	mov	x8, #0                          ; =0x0
	ldp	q16, q7, [sp, #48]              ; 32-byte Folded Reload
	ldp	q18, q17, [sp, #16]             ; 32-byte Folded Reload
LBB0_47:                                ; %direct.true902
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q0, q1, [x23], #32
	fdiv.4s	v1, v1, v20
	fdiv.4s	v0, v0, v19
	dup.2d	v2, x8
	add.2d	v3, v2, v18
	add.2d	v4, v2, v16
	add.2d	v5, v2, v17
	add.2d	v2, v2, v7
	dup.2d	v6, x19
	add.2d	v4, v6, v4
	add.2d	v3, v6, v3
	mov.d	x9, v3[1]
	fmov	x10, d3
	str	s0, [x10]
	st1.s	{ v0 }[1], [x9]
	mov.d	x9, v4[1]
	add.2d	v3, v6, v5
	fmov	x10, d4
	st1.s	{ v0 }[2], [x10]
	st1.s	{ v0 }[3], [x9]
	mov.d	x9, v3[1]
	fmov	x10, d3
	str	s1, [x10]
	st1.s	{ v1 }[1], [x9]
	add.2d	v0, v6, v2
	mov.d	x9, v0[1]
	fmov	x10, d0
	st1.s	{ v1 }[2], [x10]
	st1.s	{ v1 }[3], [x9]
	add	x8, x8, #4
	cmp	x8, #512
	b.ne	LBB0_47
; %bb.48:                               ; %common.ret
	add	sp, sp, #1856
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention.packet_batch.blocks
lCPI1_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI1_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI1_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI1_3:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI1_4:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI1_5:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI1_6:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_attention.packet_batch.blocks
	.p2align	2
_llm_attention.packet_batch.blocks:     ; @llm_attention.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_132
; %bb.1:                                ; %block.batch.loop.preheader
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #2960
	mov	x23, x3
	mov	x20, x2
	mov	x21, x0
	mov	w22, #0                         ; =0x0
	ldp	w9, w8, [x2, #44]
	stp	w8, w9, [sp, #136]              ; 8-byte Folded Spill
	ldp	w27, w28, [x2]
	ldp	w24, w19, [x2, #8]
Lloh4:
	adrp	x8, lCPI1_0@PAGE
Lloh5:
	ldr	q19, [x8, lCPI1_0@PAGEOFF]
Lloh6:
	adrp	x8, lCPI1_1@PAGE
Lloh7:
	ldr	q20, [x8, lCPI1_1@PAGEOFF]
Lloh8:
	adrp	x8, lCPI1_2@PAGE
Lloh9:
	ldr	q17, [x8, lCPI1_2@PAGEOFF]
	mov	w25, #43691                     ; =0xaaab
	movk	w25, #15914, lsl #16
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	str	q0, [sp, #144]                  ; 16-byte Spill
	str	w3, [sp, #108]                  ; 4-byte Spill
	str	q19, [sp, #224]                 ; 16-byte Spill
	str	q20, [sp, #80]                  ; 16-byte Spill
	str	q17, [sp, #112]                 ; 16-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	w23, [sp, #108]                 ; 4-byte Reload
LBB1_3:                                 ; %llm_attention.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w27, #1
	ldp	w10, w9, [sp, #136]             ; 8-byte Folded Reload
	cmp	w8, w9
	cset	w8, eq
	csinc	w27, wzr, w27, eq
	cinc	w9, w28, eq
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w28, wzr, w9, ne
	add	w24, w24, w8
	add	w22, w22, #1
	cmp	w22, w23
	b.eq	LBB1_131
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_15 Depth 2
                                        ;     Child Loop BB1_32 Depth 2
                                        ;     Child Loop BB1_34 Depth 2
                                        ;       Child Loop BB1_36 Depth 3
                                        ;       Child Loop BB1_55 Depth 3
                                        ;       Child Loop BB1_73 Depth 3
                                        ;       Child Loop BB1_75 Depth 3
                                        ;       Child Loop BB1_77 Depth 3
                                        ;       Child Loop BB1_79 Depth 3
                                        ;       Child Loop BB1_81 Depth 3
                                        ;       Child Loop BB1_83 Depth 3
                                        ;       Child Loop BB1_85 Depth 3
                                        ;       Child Loop BB1_87 Depth 3
                                        ;       Child Loop BB1_89 Depth 3
                                        ;       Child Loop BB1_91 Depth 3
                                        ;       Child Loop BB1_93 Depth 3
                                        ;       Child Loop BB1_95 Depth 3
                                        ;       Child Loop BB1_97 Depth 3
                                        ;       Child Loop BB1_99 Depth 3
                                        ;       Child Loop BB1_101 Depth 3
                                        ;       Child Loop BB1_103 Depth 3
                                        ;       Child Loop BB1_105 Depth 3
                                        ;       Child Loop BB1_107 Depth 3
                                        ;       Child Loop BB1_109 Depth 3
                                        ;       Child Loop BB1_111 Depth 3
                                        ;     Child Loop BB1_115 Depth 2
	ubfiz	x8, x27, #5, #32
	cmp	x8, x19
	csel	x9, x8, xzr, ls
	subs	x10, x19, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x19, x9
	stp	w27, w28, [x20]
	str	w24, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x19, #2, hi
	csel	x26, x10, xzr, ls
	cmp	x26, #32
	b.lo	LBB1_6
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention.full_packet
	b	LBB1_3
LBB1_6:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x23, x26, #3
	cbz	x23, LBB1_11
; %bb.7:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention.full_packet
	cmp	x23, #1
	b.eq	LBB1_11
; %bb.8:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention.full_packet
	cmp	x23, #2
	b.eq	LBB1_11
; %bb.9:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention.full_packet
	cmp	x23, #3
	b.eq	LBB1_11
; %bb.10:                               ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention.full_packet
LBB1_11:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w8, w26, #0x7
	ldr	q19, [sp, #224]                 ; 16-byte Reload
	ldr	q20, [sp, #80]                  ; 16-byte Reload
	mov	w26, #-1026555904               ; =0xc2d00000
	ldr	q17, [sp, #112]                 ; 16-byte Reload
	mov	w30, #1120403456                ; =0x42c80000
	cbz	w8, LBB1_2
; %bb.12:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	dup.4s	v25, w8
	cmhi.4s	v0, v25, v20
	cmhi.4s	v6, v25, v19
	uzp1.8h	v5, v6, v0
	umaxv.8h	h1, v5
	fmov	w8, s1
	tbz	w8, #0, LBB1_2
; %bb.13:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, #0                          ; =0x0
	ldr	x10, [x20, #136]
	add	x11, x10, #35, lsl #12          ; =143360
	add	x8, x10, #1, lsl #12            ; =4096
	add	x12, x10, #2, lsl #12           ; =8192
	add	x13, x10, #3, lsl #12           ; =12288
	add	x14, x10, #19, lsl #12          ; =77824
	mov	w9, #13312                      ; =0x3400
	movk	w9, #2, lsl #16
	add	x15, x10, x9
	ldr	x2, [x21]
	ldr	x16, [x21, #16]
	ldr	x17, [x21, #32]
	ldr	x9, [x21, #48]
	lsl	w1, w23, #3
	orr	w1, w1, w27, lsl #5
	dup.4s	v1, w1
	orr.16b	v2, v1, v20
	orr.16b	v1, v1, v19
	and.16b	v7, v6, v1
	and.16b	v16, v0, v2
	ushll2.2d	v1, v16, #0
	ushll2.2d	v2, v7, #0
	ushll.2d	v3, v16, #0
	ushll.2d	v4, v7, #0
	ushll2.2d	v21, v16, #9
	ushll2.2d	v22, v7, #9
	ushll.2d	v23, v16, #9
	ushll.2d	v24, v7, #9
	and.16b	v5, v5, v17
	addv.8h	h5, v5
	str	q5, [sp, #2496]                 ; 16-byte Spill
	fmov	w1, s5
	dup.2d	v5, x2
	mov	x2, x10
	b	LBB1_15
LBB1_14:                                ; %else265
                                        ;   in Loop: Header=BB1_15 Depth=2
	ldp	q17, q18, [x2]
	bif.16b	v16, v18, v0
	bif.16b	v7, v17, v6
	stp	q7, q16, [x2], #32
	add	x0, x0, #4
	cmp	x0, #512
	b.eq	LBB1_31
LBB1_15:                                ; %direct.true.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v17, x0
	add.2d	v7, v17, v24
	add.2d	v18, v5, v7
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbnz	w1, #0, LBB1_23
; %bb.16:                               ; %else
                                        ;   in Loop: Header=BB1_15 Depth=2
	and	w3, w1, #0xff
	tbnz	w3, #1, LBB1_24
LBB1_17:                                ; %else247
                                        ;   in Loop: Header=BB1_15 Depth=2
	add.2d	v18, v17, v22
	add.2d	v18, v5, v18
	tbnz	w3, #2, LBB1_25
LBB1_18:                                ; %else250
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w3, #3, LBB1_26
LBB1_19:                                ; %else253
                                        ;   in Loop: Header=BB1_15 Depth=2
	add.2d	v18, v17, v23
	add.2d	v18, v5, v18
	tbnz	w3, #4, LBB1_27
LBB1_20:                                ; %else256
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w3, #5, LBB1_28
LBB1_21:                                ; %else259
                                        ;   in Loop: Header=BB1_15 Depth=2
	add.2d	v17, v17, v21
	add.2d	v17, v5, v17
	tbnz	w3, #6, LBB1_29
LBB1_22:                                ; %else262
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbz	w3, #7, LBB1_14
	b	LBB1_30
LBB1_23:                                ; %cond.load
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	x3, d18
	ldr	s7, [x3]
	and	w3, w1, #0xff
	tbz	w3, #1, LBB1_17
LBB1_24:                                ; %cond.load246
                                        ;   in Loop: Header=BB1_15 Depth=2
	mov.d	x4, v18[1]
	ld1.s	{ v7 }[1], [x4]
	add.2d	v18, v17, v22
	add.2d	v18, v5, v18
	tbz	w3, #2, LBB1_18
LBB1_25:                                ; %cond.load249
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	x4, d18
	ld1.s	{ v7 }[2], [x4]
	tbz	w3, #3, LBB1_19
LBB1_26:                                ; %cond.load252
                                        ;   in Loop: Header=BB1_15 Depth=2
	mov.d	x4, v18[1]
	ld1.s	{ v7 }[3], [x4]
	add.2d	v18, v17, v23
	add.2d	v18, v5, v18
	tbz	w3, #4, LBB1_20
LBB1_27:                                ; %cond.load255
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	x4, d18
	ld1.s	{ v16 }[0], [x4]
	tbz	w3, #5, LBB1_21
LBB1_28:                                ; %cond.load258
                                        ;   in Loop: Header=BB1_15 Depth=2
	mov.d	x4, v18[1]
	ld1.s	{ v16 }[1], [x4]
	add.2d	v17, v17, v21
	add.2d	v17, v5, v17
	tbz	w3, #6, LBB1_22
LBB1_29:                                ; %cond.load261
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	x4, d17
	ld1.s	{ v16 }[2], [x4]
	tbz	w3, #7, LBB1_14
LBB1_30:                                ; %cond.load264
                                        ;   in Loop: Header=BB1_15 Depth=2
	mov.d	x3, v17[1]
	ld1.s	{ v16 }[3], [x3]
	b	LBB1_14
LBB1_31:                                ; %direct.true166.i.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	stp	q24, q23, [sp, #16]             ; 32-byte Folded Spill
	stp	q22, q21, [sp, #48]             ; 32-byte Folded Spill
	mov	x0, #0                          ; =0x0
	adrp	x5, lCPI1_3@PAGE
	adrp	x6, lCPI1_4@PAGE
	adrp	x7, lCPI1_5@PAGE
	mov	w23, #1267                      ; =0x4f3
	movk	w23, #15797, lsl #16
LBB1_32:                                ; %direct.true166.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x1, x8, x0
	ldp	q5, q7, [x1]
	cmhs.4s	v16, v20, v25
	and.16b	v7, v16, v7
	cmhs.4s	v17, v19, v25
	and.16b	v5, v17, v5
	stp	q5, q7, [x1]
	add	x0, x0, #32
	cmp	x0, #1, lsl #12                 ; =4096
	b.ne	LBB1_32
; %bb.33:                               ; %direct.false167.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	stp	q16, q25, [sp, #192]            ; 32-byte Folded Spill
	str	q17, [sp, #176]                 ; 16-byte Spill
	mov	x0, #0                          ; =0x0
	ushr.2d	v4, v4, #2
	ushr.2d	v2, v2, #2
	ushr.2d	v3, v3, #2
	ushr.2d	v1, v1, #2
	mov.d	x1, v1[1]
	fmov	x2, d1
	add	x2, x2, x2, lsl #13
	fmov	d1, x2
	add	x1, x1, x1, lsl #13
	mov.d	v1[1], x1
	mov.d	x1, v3[1]
	fmov	x2, d3
	add	x2, x2, x2, lsl #13
	fmov	d3, x2
	add	x1, x1, x1, lsl #13
	mov.d	v3[1], x1
	mov.d	x1, v2[1]
	fmov	x2, d2
	add	x2, x2, x2, lsl #13
	fmov	d2, x2
	add	x1, x1, x1, lsl #13
	mov.d	v2[1], x1
	mov.d	x1, v4[1]
	fmov	x2, d4
	add	x2, x2, x2, lsl #13
	fmov	d4, x2
	add	x1, x1, x1, lsl #13
	mov.d	v4[1], x1
	sshll.2d	v5, v6, #0
	sshll.2d	v7, v0, #0
	sshll2.2d	v16, v6, #0
	sshll2.2d	v17, v0, #0
Lloh10:
	adrp	x1, lCPI1_6@PAGE
Lloh11:
	ldr	q18, [x1, lCPI1_6@PAGEOFF]
	str	q18, [sp, #1696]                ; 16-byte Spill
	and.16b	v18, v5, v18
	str	q18, [sp, #2672]                ; 16-byte Spill
	mov	w1, #62154                      ; =0xf2ca
	movk	w1, #61769, lsl #16
	dup.4s	v18, w1
	and.16b	v19, v0, v18
	str	q19, [sp, #2480]                ; 16-byte Spill
	str	q18, [sp, #160]                 ; 16-byte Spill
	and.16b	v18, v6, v18
	str	q18, [sp, #2464]                ; 16-byte Spill
	and.16b	v4, v5, v4
	str	q4, [sp, #2832]                 ; 16-byte Spill
	str	q16, [sp, #2848]                ; 16-byte Spill
	and.16b	v2, v16, v2
	str	q2, [sp, #2816]                 ; 16-byte Spill
	and.16b	v2, v7, v3
	str	q2, [sp, #2800]                 ; 16-byte Spill
	str	q17, [sp, #2864]                ; 16-byte Spill
	and.16b	v1, v17, v1
	str	q1, [sp, #2784]                 ; 16-byte Spill
	movi.2d	v13, #0000000000000000
	movi.2d	v12, #0000000000000000
	movi.2d	v1, #0000000000000000
	str	q1, [sp, #1680]                 ; 16-byte Spill
	str	q1, [sp, #1664]                 ; 16-byte Spill
	str	q1, [sp, #1648]                 ; 16-byte Spill
	str	q1, [sp, #1632]                 ; 16-byte Spill
	str	q1, [sp, #1616]                 ; 16-byte Spill
	str	q1, [sp, #2512]                 ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q1, [sp, #1408]                 ; 16-byte Spill
	str	q1, [sp, #1392]                 ; 16-byte Spill
	str	q1, [sp, #1376]                 ; 16-byte Spill
	str	q1, [sp, #1360]                 ; 16-byte Spill
	str	q1, [sp, #1344]                 ; 16-byte Spill
	str	q1, [sp, #1328]                 ; 16-byte Spill
	str	q1, [sp, #1312]                 ; 16-byte Spill
	str	q1, [sp, #1296]                 ; 16-byte Spill
	str	q1, [sp, #1280]                 ; 16-byte Spill
	str	q1, [sp, #1264]                 ; 16-byte Spill
	str	q1, [sp, #1248]                 ; 16-byte Spill
	str	q1, [sp, #1232]                 ; 16-byte Spill
	str	q1, [sp, #1216]                 ; 16-byte Spill
	str	q1, [sp, #1200]                 ; 16-byte Spill
	movi.2d	v31, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v7, #0000000000000000
	str	q7, [sp, #1600]                 ; 16-byte Spill
	str	q7, [sp, #2656]                 ; 16-byte Spill
	str	q7, [sp, #2640]                 ; 16-byte Spill
	str	q7, [sp, #2624]                 ; 16-byte Spill
	str	q7, [sp, #2608]                 ; 16-byte Spill
	str	q7, [sp, #2592]                 ; 16-byte Spill
	str	q7, [sp, #2576]                 ; 16-byte Spill
	str	q7, [sp, #2560]                 ; 16-byte Spill
	str	q7, [sp, #2544]                 ; 16-byte Spill
	str	q7, [sp, #1584]                 ; 16-byte Spill
	str	q7, [sp, #1568]                 ; 16-byte Spill
	str	q7, [sp, #1552]                 ; 16-byte Spill
	str	q7, [sp, #1536]                 ; 16-byte Spill
	str	q7, [sp, #2416]                 ; 16-byte Spill
	str	q7, [sp, #2400]                 ; 16-byte Spill
	movi.2d	v14, #0000000000000000
	str	q7, [sp, #2384]                 ; 16-byte Spill
	movi.2d	v15, #0000000000000000
	str	q1, [sp, #2368]                 ; 16-byte Spill
	movi.2d	v2, #0000000000000000
	str	q2, [sp, #2352]                 ; 16-byte Spill
	movi.2d	v3, #0000000000000000
	str	q3, [sp, #2336]                 ; 16-byte Spill
	movi.2d	v4, #0000000000000000
	str	q4, [sp, #2320]                 ; 16-byte Spill
	str	q7, [sp, #2304]                 ; 16-byte Spill
	movi.2d	v8, #0000000000000000
	str	q7, [sp, #2288]                 ; 16-byte Spill
	movi.2d	v9, #0000000000000000
	str	q7, [sp, #2272]                 ; 16-byte Spill
	movi.2d	v10, #0000000000000000
	str	q7, [sp, #2256]                 ; 16-byte Spill
	movi.2d	v26, #0000000000000000
	str	q7, [sp, #2240]                 ; 16-byte Spill
	movi.2d	v27, #0000000000000000
	str	q7, [sp, #2224]                 ; 16-byte Spill
	movi.2d	v28, #0000000000000000
	str	q7, [sp, #2208]                 ; 16-byte Spill
	movi.2d	v29, #0000000000000000
	str	q7, [sp, #2192]                 ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q7, [sp, #2176]                 ; 16-byte Spill
	str	q7, [sp, #2768]                 ; 16-byte Spill
	str	q7, [sp, #2928]                 ; 16-byte Spill
	str	q7, [sp, #2912]                 ; 16-byte Spill
	str	q7, [sp, #2752]                 ; 16-byte Spill
	str	q7, [sp, #2528]                 ; 16-byte Spill
	str	q7, [sp, #1520]                 ; 16-byte Spill
	str	q7, [sp, #1504]                 ; 16-byte Spill
	str	q7, [sp, #1488]                 ; 16-byte Spill
	str	q7, [sp, #2736]                 ; 16-byte Spill
	str	q7, [sp, #2720]                 ; 16-byte Spill
	str	q7, [sp, #2896]                 ; 16-byte Spill
	str	q7, [sp, #2880]                 ; 16-byte Spill
	str	q7, [sp, #1472]                 ; 16-byte Spill
	str	q7, [sp, #1456]                 ; 16-byte Spill
	str	q7, [sp, #1440]                 ; 16-byte Spill
	str	q7, [sp, #1424]                 ; 16-byte Spill
	str	q7, [sp, #1712]                 ; 16-byte Spill
LBB1_34:                                ; %direct.true176.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB1_36 Depth 3
                                        ;       Child Loop BB1_55 Depth 3
                                        ;       Child Loop BB1_73 Depth 3
                                        ;       Child Loop BB1_75 Depth 3
                                        ;       Child Loop BB1_77 Depth 3
                                        ;       Child Loop BB1_79 Depth 3
                                        ;       Child Loop BB1_81 Depth 3
                                        ;       Child Loop BB1_83 Depth 3
                                        ;       Child Loop BB1_85 Depth 3
                                        ;       Child Loop BB1_87 Depth 3
                                        ;       Child Loop BB1_89 Depth 3
                                        ;       Child Loop BB1_91 Depth 3
                                        ;       Child Loop BB1_93 Depth 3
                                        ;       Child Loop BB1_95 Depth 3
                                        ;       Child Loop BB1_97 Depth 3
                                        ;       Child Loop BB1_99 Depth 3
                                        ;       Child Loop BB1_101 Depth 3
                                        ;       Child Loop BB1_103 Depth 3
                                        ;       Child Loop BB1_105 Depth 3
                                        ;       Child Loop BB1_107 Depth 3
                                        ;       Child Loop BB1_109 Depth 3
                                        ;       Child Loop BB1_111 Depth 3
	str	q17, [sp, #2704]                ; 16-byte Spill
	str	q30, [sp, #2688]                ; 16-byte Spill
	str	q13, [sp, #1184]                ; 16-byte Spill
	mov	x2, #0                          ; =0x0
	lsl	x1, x0, #4
	ldr	q13, [sp, #2416]                ; 16-byte Reload
	b	LBB1_36
LBB1_35:                                ; %direct.schedule.12.i.i
                                        ;   in Loop: Header=BB1_36 Depth=3
	str	q11, [sp, #2720]                ; 16-byte Spill
	str	q23, [sp, #2736]                ; 16-byte Spill
	add	x3, x13, x2, lsl #5
	ldp	q17, q18, [x3]
	bit.16b	v18, v30, v0
	bit.16b	v17, v25, v6
	stp	q17, q18, [x3]
	add	x2, x2, #1
	cmp	x2, #2048
	b.eq	LBB1_53
LBB1_36:                                ; %direct.true180.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	sshll.2d	v17, v6, #0
	sshll.2d	v18, v0, #0
	and	x3, x2, #0x7f
	orr	x4, x1, x2, lsr #7
	dup.2d	v25, x4
	ldr	q7, [sp, #2784]                 ; 16-byte Reload
	add.2d	v30, v25, v7
	ldr	q7, [sp, #2832]                 ; 16-byte Reload
	add.2d	v23, v25, v7
	ldr	q7, [sp, #2816]                 ; 16-byte Reload
	add.2d	v7, v25, v7
	ldr	q11, [sp, #2800]                ; 16-byte Reload
	add.2d	v25, v25, v11
	shl.2d	v25, v25, #7
	shl.2d	v7, v7, #7
	shl.2d	v23, v23, #7
	dup.2d	v11, x3
	shl.2d	v30, v30, #7
	orr.16b	v30, v30, v11
	orr.16b	v23, v23, v11
	orr.16b	v7, v7, v11
	orr.16b	v25, v25, v11
	ldr	q11, [sp, #2896]                ; 16-byte Reload
	bit.16b	v11, v25, v18
	str	q11, [sp, #2896]                ; 16-byte Spill
	ldr	q18, [sp, #2848]                ; 16-byte Reload
	ldr	q11, [sp, #2720]                ; 16-byte Reload
	bit.16b	v11, v7, v18
	ldr	q7, [sp, #2736]                 ; 16-byte Reload
	bif.16b	v23, v7, v17
	ldr	q7, [sp, #2864]                 ; 16-byte Reload
	ldr	q17, [sp, #2880]                ; 16-byte Reload
	bit.16b	v17, v30, v7
	str	q17, [sp, #2880]                ; 16-byte Spill
	movi.2d	v25, #0000000000000000
	movi.2d	v30, #0000000000000000
	cmp	x4, #2, lsl #12                 ; =8192
	b.hi	LBB1_35
; %bb.37:                               ; %direct.true193.i.i
                                        ;   in Loop: Header=BB1_36 Depth=3
	ldr	q7, [sp, #2496]                 ; 16-byte Reload
	fmov	w3, s7
	shl.2d	v7, v23, #2
	dup.2d	v17, x16
	add.2d	v18, v17, v7
	tbnz	w3, #0, LBB1_45
; %bb.38:                               ; %else272
                                        ;   in Loop: Header=BB1_36 Depth=3
	and	w3, w3, #0xff
	tbnz	w3, #1, LBB1_46
LBB1_39:                                ; %else278
                                        ;   in Loop: Header=BB1_36 Depth=3
	shl.2d	v7, v11, #2
	add.2d	v18, v17, v7
	tbnz	w3, #2, LBB1_47
LBB1_40:                                ; %else284
                                        ;   in Loop: Header=BB1_36 Depth=3
	tbnz	w3, #3, LBB1_48
LBB1_41:                                ; %else290
                                        ;   in Loop: Header=BB1_36 Depth=3
	ldr	q7, [sp, #2896]                 ; 16-byte Reload
	shl.2d	v7, v7, #2
	add.2d	v18, v17, v7
	tbnz	w3, #4, LBB1_49
LBB1_42:                                ; %else296
                                        ;   in Loop: Header=BB1_36 Depth=3
	tbnz	w3, #5, LBB1_50
LBB1_43:                                ; %else302
                                        ;   in Loop: Header=BB1_36 Depth=3
	ldr	q7, [sp, #2880]                 ; 16-byte Reload
	shl.2d	v7, v7, #2
	add.2d	v17, v17, v7
	tbnz	w3, #6, LBB1_51
LBB1_44:                                ; %else308
                                        ;   in Loop: Header=BB1_36 Depth=3
	tbz	w3, #7, LBB1_35
	b	LBB1_52
LBB1_45:                                ; %cond.load268
                                        ;   in Loop: Header=BB1_36 Depth=3
	fmov	x4, d18
	ldr	s25, [x4]
	and	w3, w3, #0xff
	tbz	w3, #1, LBB1_39
LBB1_46:                                ; %cond.load274
                                        ;   in Loop: Header=BB1_36 Depth=3
	mov.d	x4, v18[1]
	ld1.s	{ v25 }[1], [x4]
	shl.2d	v7, v11, #2
	add.2d	v18, v17, v7
	tbz	w3, #2, LBB1_40
LBB1_47:                                ; %cond.load280
                                        ;   in Loop: Header=BB1_36 Depth=3
	fmov	x4, d18
	ld1.s	{ v25 }[2], [x4]
	tbz	w3, #3, LBB1_41
LBB1_48:                                ; %cond.load286
                                        ;   in Loop: Header=BB1_36 Depth=3
	mov.d	x4, v18[1]
	ld1.s	{ v25 }[3], [x4]
	ldr	q7, [sp, #2896]                 ; 16-byte Reload
	shl.2d	v7, v7, #2
	add.2d	v18, v17, v7
	tbz	w3, #4, LBB1_42
LBB1_49:                                ; %cond.load292
                                        ;   in Loop: Header=BB1_36 Depth=3
	fmov	x4, d18
	ld1.s	{ v30 }[0], [x4]
	tbz	w3, #5, LBB1_43
LBB1_50:                                ; %cond.load298
                                        ;   in Loop: Header=BB1_36 Depth=3
	mov.d	x4, v18[1]
	ld1.s	{ v30 }[1], [x4]
	ldr	q7, [sp, #2880]                 ; 16-byte Reload
	shl.2d	v7, v7, #2
	add.2d	v17, v17, v7
	tbz	w3, #6, LBB1_44
LBB1_51:                                ; %cond.load304
                                        ;   in Loop: Header=BB1_36 Depth=3
	fmov	x4, d17
	ld1.s	{ v30 }[2], [x4]
	tbz	w3, #7, LBB1_35
LBB1_52:                                ; %cond.load310
                                        ;   in Loop: Header=BB1_36 Depth=3
	mov.d	x3, v17[1]
	ld1.s	{ v30 }[3], [x3]
	b	LBB1_35
LBB1_53:                                ; %direct.true205.i.i.preheader
                                        ;   in Loop: Header=BB1_34 Depth=2
	mov	x2, #0                          ; =0x0
	b	LBB1_55
LBB1_54:                                ; %direct.schedule.17.i.i
                                        ;   in Loop: Header=BB1_55 Depth=3
	str	q23, [sp, #2752]                ; 16-byte Spill
	str	q11, [sp, #2768]                ; 16-byte Spill
	add	x3, x14, x2, lsl #5
	ldp	q17, q18, [x3]
	bit.16b	v18, v30, v0
	bit.16b	v17, v25, v6
	stp	q17, q18, [x3]
	add	x2, x2, #1
	cmp	x2, #2048
	b.eq	LBB1_72
LBB1_55:                                ; %direct.true205.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	sshll.2d	v7, v6, #0
	sshll.2d	v17, v0, #0
	and	x3, x2, #0x7f
	orr	x4, x1, x2, lsr #7
	dup.2d	v18, x4
	ldr	q23, [sp, #2784]                ; 16-byte Reload
	add.2d	v23, v18, v23
	ldr	q25, [sp, #2832]                ; 16-byte Reload
	add.2d	v25, v18, v25
	ldr	q30, [sp, #2816]                ; 16-byte Reload
	add.2d	v30, v18, v30
	ldr	q11, [sp, #2800]                ; 16-byte Reload
	add.2d	v18, v18, v11
	shl.2d	v18, v18, #7
	shl.2d	v30, v30, #7
	shl.2d	v25, v25, #7
	dup.2d	v11, x3
	shl.2d	v23, v23, #7
	orr.16b	v23, v23, v11
	orr.16b	v25, v25, v11
	orr.16b	v30, v30, v11
	orr.16b	v18, v18, v11
	ldr	q11, [sp, #2912]                ; 16-byte Reload
	bit.16b	v11, v18, v17
	str	q11, [sp, #2912]                ; 16-byte Spill
	ldr	q17, [sp, #2848]                ; 16-byte Reload
	ldr	q18, [sp, #2928]                ; 16-byte Reload
	bit.16b	v18, v30, v17
	str	q18, [sp, #2928]                ; 16-byte Spill
	ldr	q11, [sp, #2768]                ; 16-byte Reload
	bit.16b	v11, v25, v7
	ldr	q7, [sp, #2864]                 ; 16-byte Reload
	ldr	q17, [sp, #2752]                ; 16-byte Reload
	bif.16b	v23, v17, v7
	movi.2d	v25, #0000000000000000
	movi.2d	v30, #0000000000000000
	cmp	x4, #2, lsl #12                 ; =8192
	b.hi	LBB1_54
; %bb.56:                               ; %direct.true218.i.i
                                        ;   in Loop: Header=BB1_55 Depth=3
	ldr	q7, [sp, #2496]                 ; 16-byte Reload
	fmov	w3, s7
	shl.2d	v7, v11, #2
	dup.2d	v17, x17
	add.2d	v18, v17, v7
	tbnz	w3, #0, LBB1_64
; %bb.57:                               ; %else321
                                        ;   in Loop: Header=BB1_55 Depth=3
	and	w3, w3, #0xff
	tbnz	w3, #1, LBB1_65
LBB1_58:                                ; %else327
                                        ;   in Loop: Header=BB1_55 Depth=3
	ldr	q7, [sp, #2928]                 ; 16-byte Reload
	shl.2d	v7, v7, #2
	add.2d	v18, v17, v7
	tbnz	w3, #2, LBB1_66
LBB1_59:                                ; %else333
                                        ;   in Loop: Header=BB1_55 Depth=3
	tbnz	w3, #3, LBB1_67
LBB1_60:                                ; %else339
                                        ;   in Loop: Header=BB1_55 Depth=3
	ldr	q7, [sp, #2912]                 ; 16-byte Reload
	shl.2d	v7, v7, #2
	add.2d	v18, v17, v7
	tbnz	w3, #4, LBB1_68
LBB1_61:                                ; %else345
                                        ;   in Loop: Header=BB1_55 Depth=3
	tbnz	w3, #5, LBB1_69
LBB1_62:                                ; %else351
                                        ;   in Loop: Header=BB1_55 Depth=3
	shl.2d	v7, v23, #2
	add.2d	v17, v17, v7
	tbnz	w3, #6, LBB1_70
LBB1_63:                                ; %else357
                                        ;   in Loop: Header=BB1_55 Depth=3
	tbz	w3, #7, LBB1_54
	b	LBB1_71
LBB1_64:                                ; %cond.load317
                                        ;   in Loop: Header=BB1_55 Depth=3
	fmov	x4, d18
	ldr	s25, [x4]
	and	w3, w3, #0xff
	tbz	w3, #1, LBB1_58
LBB1_65:                                ; %cond.load323
                                        ;   in Loop: Header=BB1_55 Depth=3
	mov.d	x4, v18[1]
	ld1.s	{ v25 }[1], [x4]
	ldr	q7, [sp, #2928]                 ; 16-byte Reload
	shl.2d	v7, v7, #2
	add.2d	v18, v17, v7
	tbz	w3, #2, LBB1_59
LBB1_66:                                ; %cond.load329
                                        ;   in Loop: Header=BB1_55 Depth=3
	fmov	x4, d18
	ld1.s	{ v25 }[2], [x4]
	tbz	w3, #3, LBB1_60
LBB1_67:                                ; %cond.load335
                                        ;   in Loop: Header=BB1_55 Depth=3
	mov.d	x4, v18[1]
	ld1.s	{ v25 }[3], [x4]
	ldr	q7, [sp, #2912]                 ; 16-byte Reload
	shl.2d	v7, v7, #2
	add.2d	v18, v17, v7
	tbz	w3, #4, LBB1_61
LBB1_68:                                ; %cond.load341
                                        ;   in Loop: Header=BB1_55 Depth=3
	fmov	x4, d18
	ld1.s	{ v30 }[0], [x4]
	tbz	w3, #5, LBB1_62
LBB1_69:                                ; %cond.load347
                                        ;   in Loop: Header=BB1_55 Depth=3
	mov.d	x4, v18[1]
	ld1.s	{ v30 }[1], [x4]
	shl.2d	v7, v23, #2
	add.2d	v17, v17, v7
	tbz	w3, #6, LBB1_63
LBB1_70:                                ; %cond.load353
                                        ;   in Loop: Header=BB1_55 Depth=3
	fmov	x4, d17
	ld1.s	{ v30 }[2], [x4]
	tbz	w3, #7, LBB1_54
LBB1_71:                                ; %cond.load359
                                        ;   in Loop: Header=BB1_55 Depth=3
	mov.d	x3, v17[1]
	ld1.s	{ v30 }[3], [x3]
	b	LBB1_54
LBB1_72:                                ; %direct.false206.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	mov	x1, #0                          ; =0x0
	sshll.2d	v7, v6, #0
	sshll.2d	v17, v0, #0
	ldr	q24, [x5, lCPI1_3@PAGEOFF]
	ldr	q18, [sp, #2864]                ; 16-byte Reload
	ldr	q23, [sp, #1424]                ; 16-byte Reload
	str	q24, [sp, #1920]                ; 16-byte Spill
	bit.16b	v23, v24, v18
	str	q23, [sp, #1424]                ; 16-byte Spill
	ldr	q25, [x6, lCPI1_4@PAGEOFF]
	ldr	q18, [sp, #2848]                ; 16-byte Reload
	ldr	q23, [sp, #1456]                ; 16-byte Reload
	str	q25, [sp, #1936]                ; 16-byte Spill
	bit.16b	v23, v25, v18
	str	q23, [sp, #1456]                ; 16-byte Spill
	ldr	q23, [x7, lCPI1_5@PAGEOFF]
	ldr	q18, [sp, #1440]                ; 16-byte Reload
	str	q23, [sp, #2432]                ; 16-byte Spill
	bit.16b	v18, v23, v17
	str	q18, [sp, #1440]                ; 16-byte Spill
	ldr	q17, [sp, #1696]                ; 16-byte Reload
	ldr	q11, [sp, #1472]                ; 16-byte Reload
	bit.16b	v11, v17, v7
	ldr	q30, [sp, #2176]                ; 16-byte Reload
	bic.16b	v30, v30, v0
	bic.16b	v19, v19, v6
	ldr	q25, [sp, #2672]                ; 16-byte Reload
LBB1_73:                                ; %direct.true230.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	d7, x1
	orr.16b	v17, v7, v25
	fmov	x2, d17
	add	x2, x10, x2
	ldp	q17, q18, [x2]
	orr.16b	v7, v7, v11
	fmov	x2, d7
	add	x2, x13, x2
	ldp	q7, q23, [x2]
	fmul.4s	v18, v18, v23
	fmul.4s	v7, v17, v7
	fadd.4s	v7, v19, v7
	fadd.4s	v17, v30, v18
	bit.16b	v30, v17, v0
	bit.16b	v19, v7, v6
	add	x1, x1, #32
	cmp	x1, #1, lsl #12                 ; =4096
	b.ne	LBB1_73
; %bb.74:                               ; %direct.false231.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q11, [sp, #1472]                ; 16-byte Spill
	str	q30, [sp, #2176]                ; 16-byte Spill
	str	q19, [sp, #1952]                ; 16-byte Spill
	ldp	q30, q25, [sp, #176]            ; 32-byte Folded Reload
	ldr	q19, [sp, #2192]                ; 16-byte Reload
	and.16b	v19, v25, v19
	and.16b	v29, v30, v29
	mov	x1, x10
	mov	w2, #128                        ; =0x80
	ldr	q11, [sp, #1536]                ; 16-byte Reload
LBB1_75:                                ; %direct.true245.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q17, [x1]
	ldr	q18, [x1, #16384]
	ldr	q23, [x1, #16400]
	fmul.4s	v17, v17, v23
	fmul.4s	v7, v7, v18
	fadd.4s	v7, v29, v7
	fadd.4s	v17, v19, v17
	bit.16b	v19, v17, v0
	bit.16b	v29, v7, v6
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB1_75
; %bb.76:                               ; %direct.false246.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q19, [sp, #2192]                ; 16-byte Spill
	str	q29, [sp, #1968]                ; 16-byte Spill
	ldr	q29, [sp, #2208]                ; 16-byte Reload
	and.16b	v29, v25, v29
	and.16b	v28, v30, v28
	mov	x1, x10
	mov	w2, #128                        ; =0x80
LBB1_77:                                ; %direct.true262.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q17, [x1]
	ldr	q18, [x1, #20480]
	ldr	q23, [x1, #20496]
	fmul.4s	v17, v17, v23
	fmul.4s	v7, v7, v18
	fadd.4s	v7, v28, v7
	fadd.4s	v17, v29, v17
	bit.16b	v29, v17, v0
	bit.16b	v28, v7, v6
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB1_77
; %bb.78:                               ; %direct.false263.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q29, [sp, #2208]                ; 16-byte Spill
	str	q28, [sp, #1984]                ; 16-byte Spill
	ldr	q28, [sp, #2224]                ; 16-byte Reload
	and.16b	v28, v25, v28
	and.16b	v27, v30, v27
	mov	x1, x10
	mov	w2, #128                        ; =0x80
	ldr	q19, [sp, #1952]                ; 16-byte Reload
LBB1_79:                                ; %direct.true279.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q17, [x1]
	ldr	q18, [x1, #24576]
	ldr	q23, [x1, #24592]
	fmul.4s	v17, v17, v23
	fmul.4s	v7, v7, v18
	fadd.4s	v7, v27, v7
	fadd.4s	v17, v28, v17
	bit.16b	v28, v17, v0
	bit.16b	v27, v7, v6
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB1_79
; %bb.80:                               ; %direct.false280.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q28, [sp, #2224]                ; 16-byte Spill
	str	q27, [sp, #2000]                ; 16-byte Spill
	ldr	q27, [sp, #2240]                ; 16-byte Reload
	and.16b	v27, v25, v27
	and.16b	v26, v30, v26
	mov	x1, x10
	mov	w2, #128                        ; =0x80
	ldr	q29, [sp, #1968]                ; 16-byte Reload
LBB1_81:                                ; %direct.true296.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q17, [x1]
	ldr	q18, [x1, #28672]
	ldr	q23, [x1, #28688]
	fmul.4s	v17, v17, v23
	fmul.4s	v7, v7, v18
	fadd.4s	v7, v26, v7
	fadd.4s	v17, v27, v17
	bit.16b	v27, v17, v0
	bit.16b	v26, v7, v6
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB1_81
; %bb.82:                               ; %direct.false297.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q27, [sp, #2240]                ; 16-byte Spill
	str	q26, [sp, #2016]                ; 16-byte Spill
	ldr	q26, [sp, #2256]                ; 16-byte Reload
	and.16b	v26, v25, v26
	and.16b	v10, v30, v10
	mov	x1, x10
	mov	w2, #128                        ; =0x80
	ldr	q28, [sp, #1984]                ; 16-byte Reload
LBB1_83:                                ; %direct.true313.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q17, [x1]
	ldr	q18, [x1, #32768]
	ldr	q23, [x1, #32784]
	fmul.4s	v17, v17, v23
	fmul.4s	v7, v7, v18
	fadd.4s	v7, v10, v7
	fadd.4s	v17, v26, v17
	bit.16b	v26, v17, v0
	bit.16b	v10, v7, v6
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB1_83
; %bb.84:                               ; %direct.false314.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q26, [sp, #2256]                ; 16-byte Spill
	str	q10, [sp, #2032]                ; 16-byte Spill
	ldr	q10, [sp, #2272]                ; 16-byte Reload
	and.16b	v10, v25, v10
	and.16b	v9, v30, v9
	mov	x1, x10
	mov	w2, #128                        ; =0x80
	ldr	q27, [sp, #2000]                ; 16-byte Reload
LBB1_85:                                ; %direct.true330.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q17, [x1]
	ldr	q18, [x1, #36864]
	ldr	q23, [x1, #36880]
	fmul.4s	v17, v17, v23
	fmul.4s	v7, v7, v18
	fadd.4s	v7, v9, v7
	fadd.4s	v17, v10, v17
	bit.16b	v10, v17, v0
	bit.16b	v9, v7, v6
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB1_85
; %bb.86:                               ; %direct.false331.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q10, [sp, #2272]                ; 16-byte Spill
	str	q9, [sp, #2048]                 ; 16-byte Spill
	ldr	q9, [sp, #2288]                 ; 16-byte Reload
	and.16b	v9, v25, v9
	and.16b	v8, v30, v8
	mov	x1, x10
	mov	w2, #128                        ; =0x80
	ldr	q26, [sp, #2016]                ; 16-byte Reload
LBB1_87:                                ; %direct.true347.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q17, [x1]
	ldr	q18, [x1, #40960]
	ldr	q23, [x1, #40976]
	fmul.4s	v17, v17, v23
	fmul.4s	v7, v7, v18
	fadd.4s	v7, v8, v7
	fadd.4s	v17, v9, v17
	bit.16b	v9, v17, v0
	bit.16b	v8, v7, v6
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB1_87
; %bb.88:                               ; %direct.false348.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q9, [sp, #2288]                 ; 16-byte Spill
	str	q8, [sp, #2064]                 ; 16-byte Spill
	ldr	q8, [sp, #2304]                 ; 16-byte Reload
	and.16b	v8, v25, v8
	and.16b	v4, v30, v4
	mov	x1, x10
	mov	w2, #128                        ; =0x80
	ldr	q10, [sp, #2032]                ; 16-byte Reload
LBB1_89:                                ; %direct.true364.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q17, [x1]
	ldr	q18, [x1, #45056]
	ldr	q23, [x1, #45072]
	fmul.4s	v17, v17, v23
	fmul.4s	v7, v7, v18
	fadd.4s	v7, v4, v7
	fadd.4s	v17, v8, v17
	bit.16b	v8, v17, v0
	bit.16b	v4, v7, v6
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB1_89
; %bb.90:                               ; %direct.false365.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q8, [sp, #2304]                 ; 16-byte Spill
	str	q4, [sp, #2080]                 ; 16-byte Spill
	ldr	q4, [sp, #2320]                 ; 16-byte Reload
	and.16b	v4, v25, v4
	and.16b	v3, v30, v3
	mov	x1, x10
	mov	w2, #128                        ; =0x80
	ldr	q9, [sp, #2048]                 ; 16-byte Reload
LBB1_91:                                ; %direct.true381.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q17, [x1]
	ldr	q18, [x1, #49152]
	ldr	q23, [x1, #49168]
	fmul.4s	v17, v17, v23
	fmul.4s	v7, v7, v18
	fadd.4s	v7, v3, v7
	fadd.4s	v17, v4, v17
	bit.16b	v4, v17, v0
	bit.16b	v3, v7, v6
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB1_91
; %bb.92:                               ; %direct.false382.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q4, [sp, #2320]                 ; 16-byte Spill
	str	q3, [sp, #2096]                 ; 16-byte Spill
	ldr	q3, [sp, #2336]                 ; 16-byte Reload
	and.16b	v3, v25, v3
	and.16b	v2, v30, v2
	mov	x1, x10
	mov	w2, #128                        ; =0x80
	ldr	q8, [sp, #2064]                 ; 16-byte Reload
LBB1_93:                                ; %direct.true398.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q17, [x1]
	ldr	q18, [x1, #53248]
	ldr	q23, [x1, #53264]
	fmul.4s	v17, v17, v23
	fmul.4s	v7, v7, v18
	fadd.4s	v7, v2, v7
	fadd.4s	v17, v3, v17
	bit.16b	v3, v17, v0
	bit.16b	v2, v7, v6
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB1_93
; %bb.94:                               ; %direct.false399.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q3, [sp, #2336]                 ; 16-byte Spill
	str	q2, [sp, #2112]                 ; 16-byte Spill
	ldr	q2, [sp, #2352]                 ; 16-byte Reload
	and.16b	v2, v25, v2
	and.16b	v1, v30, v1
	mov	x1, x10
	mov	w2, #128                        ; =0x80
	ldr	q4, [sp, #2080]                 ; 16-byte Reload
LBB1_95:                                ; %direct.true415.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q17, [x1]
	ldr	q18, [x1, #57344]
	ldr	q23, [x1, #57360]
	fmul.4s	v17, v17, v23
	fmul.4s	v7, v7, v18
	fadd.4s	v7, v1, v7
	fadd.4s	v17, v2, v17
	bit.16b	v2, v17, v0
	bit.16b	v1, v7, v6
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB1_95
; %bb.96:                               ; %direct.false416.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q2, [sp, #2352]                 ; 16-byte Spill
	str	q1, [sp, #2128]                 ; 16-byte Spill
	ldr	q1, [sp, #2368]                 ; 16-byte Reload
	and.16b	v1, v25, v1
	and.16b	v15, v30, v15
	mov	x1, x10
	mov	w2, #128                        ; =0x80
	ldr	q3, [sp, #2096]                 ; 16-byte Reload
LBB1_97:                                ; %direct.true432.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q17, [x1]
	ldr	q18, [x1, #61440]
	ldr	q23, [x1, #61456]
	fmul.4s	v17, v17, v23
	fmul.4s	v7, v7, v18
	fadd.4s	v7, v15, v7
	fadd.4s	v17, v1, v17
	bit.16b	v1, v17, v0
	bit.16b	v15, v7, v6
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB1_97
; %bb.98:                               ; %direct.false433.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q1, [sp, #2368]                 ; 16-byte Spill
	str	q15, [sp, #2144]                ; 16-byte Spill
	ldr	q15, [sp, #2384]                ; 16-byte Reload
	and.16b	v15, v25, v15
	and.16b	v14, v30, v14
	mov	x1, x10
	mov	w2, #128                        ; =0x80
	ldr	q2, [sp, #2112]                 ; 16-byte Reload
LBB1_99:                                ; %direct.true449.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q17, [x1]
	add	x3, x1, #16, lsl #12            ; =65536
	ldp	q18, q23, [x3]
	fmul.4s	v17, v17, v23
	fmul.4s	v7, v7, v18
	fadd.4s	v7, v14, v7
	fadd.4s	v17, v15, v17
	bit.16b	v15, v17, v0
	bit.16b	v14, v7, v6
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB1_99
; %bb.100:                              ; %direct.false450.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q16, [sp, #1088]                ; 16-byte Spill
	str	q15, [sp, #2384]                ; 16-byte Spill
	str	q14, [sp, #2160]                ; 16-byte Spill
	ldr	q14, [sp, #2400]                ; 16-byte Reload
	and.16b	v14, v25, v14
	and.16b	v13, v30, v13
	mov	x1, x10
	mov	w2, #128                        ; =0x80
	ldr	q1, [sp, #2128]                 ; 16-byte Reload
LBB1_101:                               ; %direct.true466.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q17, [x1]
	add	x3, x1, #17, lsl #12            ; =69632
	ldp	q18, q23, [x3]
	fmul.4s	v17, v17, v23
	fmul.4s	v7, v7, v18
	fadd.4s	v7, v13, v7
	fadd.4s	v17, v14, v17
	bit.16b	v14, v17, v0
	bit.16b	v13, v7, v6
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB1_101
; %bb.102:                              ; %direct.false467.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q5, [sp, #1072]                 ; 16-byte Spill
	str	q14, [sp, #2400]                ; 16-byte Spill
	str	q13, [sp, #2416]                ; 16-byte Spill
	and.16b	v11, v25, v11
	ldr	q25, [sp, #1552]                ; 16-byte Reload
	and.16b	v25, v30, v25
	mov	x1, x10
	mov	w2, #128                        ; =0x80
	ldr	q14, [sp, #2144]                ; 16-byte Reload
	ldr	q15, [sp, #2368]                ; 16-byte Reload
LBB1_103:                               ; %direct.true483.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q7, q17, [x1]
	add	x3, x1, #18, lsl #12            ; =73728
	ldp	q18, q23, [x3]
	fmul.4s	v17, v17, v23
	fmul.4s	v7, v7, v18
	fadd.4s	v7, v25, v7
	fadd.4s	v17, v11, v17
	bit.16b	v11, v17, v0
	bit.16b	v25, v7, v6
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB1_103
; %bb.104:                              ; %direct.false484.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q21, [sp, #1056]                ; 16-byte Spill
	str	q22, [sp, #1104]                ; 16-byte Spill
	str	q20, [sp, #1120]                ; 16-byte Spill
	str	q31, [sp, #1136]                ; 16-byte Spill
	str	q12, [sp, #2448]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	mov.16b	v12, v25
	dup.4s	v25, w23
	fmul.4s	v21, v19, v25
	ldr	q7, [sp, #2176]                 ; 16-byte Reload
	fmul.4s	v20, v7, v25
	cmp	x0, #512
	cset	w2, lo
	dup.4h	v7, w2
	ldr	q17, [sp, #2192]                ; 16-byte Reload
	fmul.4s	v17, v17, v25
	fmul.4s	v18, v29, v25
	ldr	q23, [sp, #2208]                ; 16-byte Reload
	fmul.4s	v23, v23, v25
	mov.16b	v13, v11
	ldp	q30, q11, [x11]
	ushll.4s	v7, v7, #0
	bit.16b	v11, v20, v0
	bit.16b	v30, v21, v6
	stp	q30, q11, [x11]
	shl.4s	v7, v7, #31
	cmlt.4s	v30, v7, #0
	ldr	q11, [sp, #160]                 ; 16-byte Reload
	mov.16b	v5, v30
	bsl.16b	v5, v18, v11
	ldp	q7, q18, [x11, #32]
	mov.16b	v16, v30
	bsl.16b	v16, v17, v11
	mov.16b	v24, v16
	mov.16b	v17, v0
	bsl.16b	v17, v16, v18
	mov.16b	v19, v5
	bit.16b	v7, v5, v6
	stp	q7, q17, [x11, #32]
	fmul.4s	v7, v28, v25
	ldr	q17, [sp, #2224]                ; 16-byte Reload
	fmul.4s	v17, v17, v25
	mov.16b	v5, v30
	bsl.16b	v5, v7, v11
	ldp	q7, q18, [x11, #64]
	mov.16b	v16, v30
	bsl.16b	v16, v23, v11
	str	q16, [sp, #1792]                ; 16-byte Spill
	bit.16b	v18, v16, v0
	str	q5, [sp, #1808]                 ; 16-byte Spill
	bit.16b	v7, v5, v6
	stp	q7, q18, [x11, #64]
	fmul.4s	v7, v27, v25
	ldr	q18, [sp, #2240]                ; 16-byte Reload
	fmul.4s	v18, v18, v25
	mov.16b	v5, v30
	bsl.16b	v5, v7, v11
	ldp	q7, q23, [x11, #96]
	mov.16b	v16, v30
	bsl.16b	v16, v17, v11
	str	q16, [sp, #1024]                ; 16-byte Spill
	mov.16b	v17, v0
	bsl.16b	v17, v16, v23
	str	q5, [sp, #1040]                 ; 16-byte Spill
	bit.16b	v7, v5, v6
	stp	q7, q17, [x11, #96]
	fmul.4s	v7, v26, v25
	ldr	q17, [sp, #2256]                ; 16-byte Reload
	fmul.4s	v17, v17, v25
	mov.16b	v5, v30
	bsl.16b	v5, v7, v11
	ldp	q7, q23, [x11, #128]
	mov.16b	v16, v30
	bsl.16b	v16, v18, v11
	stp	q16, q5, [sp, #960]             ; 32-byte Folded Spill
	mov.16b	v18, v0
	bsl.16b	v18, v16, v23
	bit.16b	v7, v5, v6
	stp	q7, q18, [x11, #128]
	fmul.4s	v7, v10, v25
	ldr	q18, [sp, #2272]                ; 16-byte Reload
	fmul.4s	v18, v18, v25
	mov.16b	v5, v30
	bsl.16b	v5, v7, v11
	ldp	q7, q23, [x11, #160]
	mov.16b	v16, v30
	bsl.16b	v16, v17, v11
	stp	q16, q5, [sp, #864]             ; 32-byte Folded Spill
	mov.16b	v17, v0
	bsl.16b	v17, v16, v23
	bit.16b	v7, v5, v6
	stp	q7, q17, [x11, #160]
	fmul.4s	v7, v9, v25
	ldr	q17, [sp, #2288]                ; 16-byte Reload
	fmul.4s	v17, v17, v25
	mov.16b	v5, v30
	bsl.16b	v5, v7, v11
	ldp	q7, q23, [x11, #192]
	mov.16b	v16, v30
	bsl.16b	v16, v18, v11
	stp	q16, q5, [sp, #768]             ; 32-byte Folded Spill
	mov.16b	v18, v0
	bsl.16b	v18, v16, v23
	bit.16b	v7, v5, v6
	stp	q7, q18, [x11, #192]
	fmul.4s	v7, v8, v25
	ldr	q18, [sp, #2304]                ; 16-byte Reload
	fmul.4s	v18, v18, v25
	mov.16b	v5, v30
	bsl.16b	v5, v7, v11
	ldp	q7, q23, [x11, #224]
	mov.16b	v16, v30
	bsl.16b	v16, v17, v11
	stp	q16, q5, [sp, #672]             ; 32-byte Folded Spill
	mov.16b	v17, v0
	bsl.16b	v17, v16, v23
	bit.16b	v7, v5, v6
	stp	q7, q17, [x11, #224]
	fmul.4s	v7, v4, v25
	fmul.4s	v17, v3, v25
	mov.16b	v3, v30
	bsl.16b	v3, v7, v11
	ldp	q7, q23, [x11, #256]
	mov.16b	v4, v30
	bsl.16b	v4, v18, v11
	stp	q4, q3, [sp, #576]              ; 32-byte Folded Spill
	mov.16b	v18, v0
	bsl.16b	v18, v4, v23
	bit.16b	v7, v3, v6
	stp	q7, q18, [x11, #256]
	ldr	q3, [sp, #2320]                 ; 16-byte Reload
	fmul.4s	v7, v3, v25
	fmul.4s	v18, v2, v25
	mov.16b	v2, v30
	bsl.16b	v2, v7, v11
	ldp	q23, q7, [x11, #288]
	mov.16b	v3, v30
	bsl.16b	v3, v17, v11
	stp	q3, q2, [sp, #608]              ; 32-byte Folded Spill
	mov.16b	v17, v6
	bsl.16b	v17, v3, v23
	bit.16b	v7, v2, v0
	stp	q17, q7, [x11, #288]
	ldr	q2, [sp, #2336]                 ; 16-byte Reload
	fmul.4s	v7, v2, v25
	fmul.4s	v17, v1, v25
	mov.16b	v1, v30
	bsl.16b	v1, v7, v11
	ldp	q23, q7, [x11, #320]
	mov.16b	v2, v30
	bsl.16b	v2, v18, v11
	stp	q2, q1, [sp, #704]              ; 32-byte Folded Spill
	mov.16b	v18, v6
	bsl.16b	v18, v2, v23
	bit.16b	v7, v1, v0
	stp	q18, q7, [x11, #320]
	ldr	q1, [sp, #2352]                 ; 16-byte Reload
	fmul.4s	v7, v1, v25
	fmul.4s	v18, v14, v25
	mov.16b	v1, v30
	bsl.16b	v1, v7, v11
	ldp	q23, q7, [x11, #352]
	mov.16b	v2, v30
	bsl.16b	v2, v17, v11
	stp	q2, q1, [sp, #800]              ; 32-byte Folded Spill
	mov.16b	v17, v6
	bsl.16b	v17, v2, v23
	bit.16b	v7, v1, v0
	stp	q17, q7, [x11, #352]
	fmul.4s	v7, v15, v25
	ldr	q17, [sp, #2384]                ; 16-byte Reload
	fmul.4s	v17, v17, v25
	mov.16b	v1, v30
	bsl.16b	v1, v7, v11
	ldp	q23, q7, [x11, #384]
	mov.16b	v2, v30
	bsl.16b	v2, v18, v11
	stp	q2, q1, [sp, #896]              ; 32-byte Folded Spill
	mov.16b	v18, v6
	bsl.16b	v18, v2, v23
	bit.16b	v7, v1, v0
	stp	q18, q7, [x11, #384]
	ldr	q7, [sp, #2160]                 ; 16-byte Reload
	fmul.4s	v7, v7, v25
	mov.16b	v1, v30
	bsl.16b	v1, v7, v11
	mov.16b	v2, v30
	bsl.16b	v2, v17, v11
	ldp	q7, q17, [x11, #416]
	str	q2, [sp, #1152]                 ; 16-byte Spill
	bit.16b	v17, v2, v0
	str	q1, [sp, #1168]                 ; 16-byte Spill
	bit.16b	v7, v1, v6
	stp	q7, q17, [x11, #416]
	ldr	q7, [sp, #2416]                 ; 16-byte Reload
	fmul.4s	v7, v7, v25
	ldr	q17, [sp, #2400]                ; 16-byte Reload
	fmul.4s	v17, v17, v25
	mov.16b	v1, v30
	bsl.16b	v1, v17, v11
	mov.16b	v2, v30
	bsl.16b	v2, v7, v11
	ldp	q7, q17, [x11, #448]
	str	q2, [sp, #1728]                 ; 16-byte Spill
	bit.16b	v7, v2, v6
	str	q1, [sp, #1744]                 ; 16-byte Spill
	bit.16b	v17, v1, v0
	stp	q7, q17, [x11, #448]
	str	q12, [sp, #1552]                ; 16-byte Spill
	fmul.4s	v7, v12, v25
	str	q13, [sp, #1536]                ; 16-byte Spill
	fmul.4s	v17, v13, v25
	mov.16b	v1, v30
	bsl.16b	v1, v17, v11
	mov.16b	v2, v30
	bsl.16b	v2, v7, v11
	ldp	q7, q17, [x11, #480]
	str	q2, [sp, #1824]                 ; 16-byte Spill
	bit.16b	v7, v2, v6
	str	q1, [sp, #1840]                 ; 16-byte Spill
	bit.16b	v17, v1, v0
	stp	q7, q17, [x11, #480]
	mvni.4s	v7, #127, msl #16
	ldr	q23, [sp, #1568]                ; 16-byte Reload
	bit.16b	v23, v7, v0
	ldr	q18, [sp, #1584]                ; 16-byte Reload
	bit.16b	v18, v7, v6
	dup.8b	v1, w2
	str	d1, [sp, #1904]                 ; 8-byte Spill
LBB1_105:                               ; %direct.true597.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x2, x11, x1
	ldp	q7, q17, [x2]
	and.16b	v17, v0, v17
	and.16b	v7, v6, v7
	fmaxnm.4s	v7, v18, v7
	fmaxnm.4s	v17, v23, v17
	bit.16b	v23, v17, v0
	bit.16b	v18, v7, v6
	add	x1, x1, #32
	cmp	x1, #512
	b.ne	LBB1_105
; %bb.106:                              ; %direct.false598.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	mov	x1, #0                          ; =0x0
	ldr	q7, [sp, #2864]                 ; 16-byte Reload
	ldr	q1, [sp, #1488]                 ; 16-byte Reload
	ldr	q31, [sp, #1920]                ; 16-byte Reload
	bit.16b	v1, v31, v7
	str	q1, [sp, #1488]                 ; 16-byte Spill
	ldr	q17, [sp, #1648]                ; 16-byte Reload
	bit.16b	v17, v31, v7
	str	q17, [sp, #1648]                ; 16-byte Spill
	str	q18, [sp, #1584]                ; 16-byte Spill
	ldr	q1, [sp, #2464]                 ; 16-byte Reload
	fmaxnm.4s	v10, v1, v18
	fsub.4s	v7, v21, v10
	ldp	q1, q17, [sp, #208]             ; 32-byte Folded Reload
	cmhi.4s	v25, v1, v17
	dup.4s	v27, w26
	and.16b	v28, v25, v7
	fcmge.4s	v7, v28, v27
	dup.4s	v26, w30
	fcmge.4s	v17, v26, v28
	and.16b	v7, v7, v17
	str	q23, [sp, #1568]                ; 16-byte Spill
	ldr	q1, [sp, #2480]                 ; 16-byte Reload
	fmaxnm.4s	v4, v1, v23
	fsub.4s	v17, v20, v4
	and.16b	v8, v0, v17
	fcmge.4s	v17, v8, v27
	fcmge.4s	v18, v26, v8
	and.16b	v17, v17, v18
	and.16b	v18, v17, v8
	mov	w2, #43579                      ; =0xaa3b
	movk	w2, #16312, lsl #16
	dup.4s	v13, w2
	fmul.4s	v17, v18, v13
	movi.4s	v14, #75, lsl #24
	mvni.4s	v15, #128, lsl #24
	mov.16b	v23, v15
	bsl.16b	v23, v14, v17
	fadd.4s	v17, v17, v23
	fsub.4s	v17, v17, v23
	and.16b	v7, v7, v28
	fmul.4s	v23, v7, v13
	mov.16b	v30, v15
	bsl.16b	v30, v14, v23
	fadd.4s	v23, v23, v30
	fsub.4s	v23, v23, v30
	fcvtzs.4s	v2, v17
	scvtf.4s	v11, v2
	mov	w2, #29184                      ; =0x7200
	movk	w2, #16177, lsl #16
	dup.4s	v9, w2
	fmul.4s	v30, v11, v9
	fsub.4s	v18, v18, v30
	fcvtzs.4s	v30, v23
	scvtf.4s	v23, v30
	fmul.4s	v17, v23, v9
	fsub.4s	v7, v7, v17
	mov	w2, #48782                      ; =0xbe8e
	movk	w2, #13759, lsl #16
	dup.4s	v20, w2
	fmul.4s	v17, v23, v20
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v11, v20
	fsub.4s	v17, v18, v17
	mov	w2, #11226                      ; =0x2bda
	movk	w2, #14672, lsl #16
	dup.4s	v22, w2
	fmul.4s	v18, v17, v22
	mov	w2, #38601                      ; =0x96c9
	movk	w2, #15030, lsl #16
	dup.4s	v5, w2
	fadd.4s	v18, v18, v5
	mov	w2, #34982                      ; =0x88a6
	movk	w2, #15368, lsl #16
	dup.4s	v16, w2
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v16
	fmul.4s	v18, v17, v18
	mov	w2, #43642                      ; =0xaa7a
	movk	w2, #15658, lsl #16
	dup.4s	v21, w2
	fadd.4s	v18, v18, v21
	fmul.4s	v18, v17, v18
	dup.4s	v1, w25
	fadd.4s	v18, v18, v1
	fmul.4s	v18, v17, v18
	movi.4s	v23, #63, lsl #24
	fadd.4s	v18, v18, v23
	movi.4s	v12, #63, lsl #24
	fmul.4s	v23, v17, v17
	fmul.4s	v18, v23, v18
	fmul.4s	v23, v7, v22
	fadd.4s	v23, v23, v5
	fmul.4s	v23, v7, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v7, v23
	fadd.4s	v23, v23, v21
	fmul.4s	v23, v7, v23
	fadd.4s	v23, v23, v1
	fmul.4s	v23, v7, v23
	fadd.4s	v23, v23, v12
	fmul.4s	v11, v7, v7
	fmul.4s	v23, v11, v23
	fadd.4s	v7, v7, v23
	fadd.4s	v17, v17, v18
	fmov.4s	v29, #1.00000000
	fadd.4s	v7, v7, v29
	sshr.4s	v18, v30, #1
	shl.4s	v23, v18, #23
	add.4s	v23, v23, v29
	fmul.4s	v7, v7, v23
	fadd.4s	v17, v17, v29
	sshr.4s	v23, v2, #1
	shl.4s	v11, v23, #23
	add.4s	v11, v11, v29
	fmul.4s	v17, v17, v11
	sub.4s	v18, v30, v18
	sub.4s	v23, v2, v23
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v29
	fmul.4s	v17, v17, v23
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v29
	fmov.4s	v31, #1.00000000
	fmul.4s	v7, v7, v18
	str	q28, [sp, #304]                 ; 16-byte Spill
	fcmgt.4s	v18, v27, v28
	bic.16b	v7, v7, v18
	str	q8, [sp, #1776]                 ; 16-byte Spill
	fcmgt.4s	v18, v27, v8
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v8, v26
	mvni.4s	v23, #127, msl #16
	fneg.4s	v3, v23
	bit.16b	v17, v3, v18
	str	q17, [sp, #1856]                ; 16-byte Spill
	fcmgt.4s	v17, v28, v26
	bit.16b	v7, v3, v17
	str	q7, [sp, #1920]                 ; 16-byte Spill
	fsub.4s	v7, v24, v4
	and.16b	v28, v0, v7
	fcmge.4s	v7, v28, v27
	fcmge.4s	v17, v26, v28
	and.16b	v7, v7, v17
	fsub.4s	v17, v19, v10
	and.16b	v29, v25, v17
	fcmge.4s	v17, v29, v27
	fcmge.4s	v18, v26, v29
	and.16b	v17, v17, v18
	and.16b	v18, v17, v29
	fmul.4s	v17, v18, v13
	mov.16b	v23, v15
	bsl.16b	v23, v14, v17
	fadd.4s	v17, v17, v23
	fsub.4s	v17, v17, v23
	and.16b	v7, v7, v28
	fmul.4s	v23, v7, v13
	mov.16b	v30, v15
	bsl.16b	v30, v14, v23
	fadd.4s	v23, v23, v30
	fsub.4s	v23, v23, v30
	fcvtzs.4s	v2, v17
	scvtf.4s	v30, v2
	fmul.4s	v11, v30, v9
	fsub.4s	v18, v18, v11
	fcvtzs.4s	v23, v23
	scvtf.4s	v11, v23
	fmul.4s	v17, v11, v9
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v11, v20
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v30, v20
	fsub.4s	v17, v18, v17
	fmul.4s	v18, v17, v22
	fadd.4s	v18, v18, v5
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v16
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v21
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v1
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v30, v17, v17
	fmul.4s	v18, v30, v18
	fmul.4s	v30, v7, v22
	fadd.4s	v30, v30, v5
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v16
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v21
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v1
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v12
	fmul.4s	v11, v7, v7
	fmul.4s	v30, v11, v30
	fadd.4s	v7, v7, v30
	fadd.4s	v17, v17, v18
	fadd.4s	v7, v7, v31
	sshr.4s	v18, v23, #1
	shl.4s	v30, v18, #23
	add.4s	v30, v30, v31
	fmul.4s	v7, v7, v30
	fadd.4s	v17, v17, v31
	sshr.4s	v30, v2, #1
	shl.4s	v11, v30, #23
	add.4s	v11, v11, v31
	fmul.4s	v17, v17, v11
	sub.4s	v18, v23, v18
	sub.4s	v23, v2, v30
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v31
	fmul.4s	v17, v17, v23
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v31
	fmul.4s	v7, v7, v18
	str	q28, [sp, #560]                 ; 16-byte Spill
	fcmgt.4s	v18, v27, v28
	bic.16b	v7, v7, v18
	str	q29, [sp, #528]                 ; 16-byte Spill
	fcmgt.4s	v18, v27, v29
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v29, v26
	bit.16b	v17, v3, v18
	str	q17, [sp, #1888]                ; 16-byte Spill
	fcmgt.4s	v17, v28, v26
	bit.16b	v7, v3, v17
	str	q7, [sp, #1872]                 ; 16-byte Spill
	ldr	q7, [sp, #1792]                 ; 16-byte Reload
	fsub.4s	v7, v7, v4
	and.16b	v28, v0, v7
	fcmge.4s	v7, v28, v27
	fcmge.4s	v17, v26, v28
	and.16b	v7, v7, v17
	ldr	q17, [sp, #1808]                ; 16-byte Reload
	fsub.4s	v17, v17, v10
	and.16b	v29, v25, v17
	fcmge.4s	v17, v29, v27
	fcmge.4s	v18, v26, v29
	and.16b	v17, v17, v18
	and.16b	v18, v17, v29
	fmul.4s	v17, v18, v13
	mov.16b	v23, v15
	bsl.16b	v23, v14, v17
	fadd.4s	v17, v17, v23
	fsub.4s	v17, v17, v23
	and.16b	v7, v7, v28
	fmul.4s	v23, v7, v13
	mov.16b	v30, v15
	bsl.16b	v30, v14, v23
	fadd.4s	v23, v23, v30
	fsub.4s	v23, v23, v30
	fcvtzs.4s	v2, v17
	scvtf.4s	v30, v2
	fmul.4s	v11, v30, v9
	fsub.4s	v18, v18, v11
	fcvtzs.4s	v23, v23
	scvtf.4s	v11, v23
	fmul.4s	v17, v11, v9
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v11, v20
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v30, v20
	fsub.4s	v17, v18, v17
	fmul.4s	v18, v17, v22
	fadd.4s	v18, v18, v5
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v16
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v21
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v1
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v30, v17, v17
	fmul.4s	v18, v30, v18
	fmul.4s	v30, v7, v22
	fadd.4s	v30, v30, v5
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v16
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v21
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v1
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v12
	fmul.4s	v11, v7, v7
	fmul.4s	v30, v11, v30
	fadd.4s	v7, v7, v30
	fadd.4s	v17, v17, v18
	fadd.4s	v7, v7, v31
	sshr.4s	v18, v23, #1
	shl.4s	v30, v18, #23
	add.4s	v30, v30, v31
	fmul.4s	v7, v7, v30
	fadd.4s	v17, v17, v31
	sshr.4s	v30, v2, #1
	shl.4s	v11, v30, #23
	add.4s	v11, v11, v31
	fmul.4s	v17, v17, v11
	sub.4s	v18, v23, v18
	sub.4s	v23, v2, v30
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v31
	fmul.4s	v17, v17, v23
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v31
	fmul.4s	v7, v7, v18
	str	q28, [sp, #1008]                ; 16-byte Spill
	fcmgt.4s	v18, v27, v28
	bic.16b	v7, v7, v18
	str	q29, [sp, #1760]                ; 16-byte Spill
	fcmgt.4s	v18, v27, v29
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v29, v26
	bit.16b	v17, v3, v18
	str	q17, [sp, #1808]                ; 16-byte Spill
	fcmgt.4s	v17, v28, v26
	bit.16b	v7, v3, v17
	str	q7, [sp, #1792]                 ; 16-byte Spill
	ldr	q7, [sp, #1024]                 ; 16-byte Reload
	fsub.4s	v7, v7, v4
	and.16b	v28, v0, v7
	fcmge.4s	v7, v28, v27
	fcmge.4s	v17, v26, v28
	and.16b	v7, v7, v17
	ldr	q17, [sp, #1040]                ; 16-byte Reload
	fsub.4s	v17, v17, v10
	and.16b	v29, v25, v17
	fcmge.4s	v17, v29, v27
	fcmge.4s	v18, v26, v29
	and.16b	v17, v17, v18
	and.16b	v18, v17, v29
	fmul.4s	v17, v18, v13
	mov.16b	v23, v15
	bsl.16b	v23, v14, v17
	fadd.4s	v17, v17, v23
	fsub.4s	v17, v17, v23
	and.16b	v7, v7, v28
	fmul.4s	v23, v7, v13
	mov.16b	v30, v15
	bsl.16b	v30, v14, v23
	fadd.4s	v23, v23, v30
	fsub.4s	v23, v23, v30
	fcvtzs.4s	v2, v17
	scvtf.4s	v30, v2
	fmul.4s	v11, v30, v9
	fsub.4s	v18, v18, v11
	fcvtzs.4s	v23, v23
	scvtf.4s	v11, v23
	fmul.4s	v17, v11, v9
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v11, v20
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v30, v20
	fsub.4s	v17, v18, v17
	fmul.4s	v18, v17, v22
	fadd.4s	v18, v18, v5
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v16
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v21
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v1
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v30, v17, v17
	fmul.4s	v18, v30, v18
	fmul.4s	v30, v7, v22
	fadd.4s	v30, v30, v5
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v16
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v21
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v1
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v12
	fmul.4s	v11, v7, v7
	fmul.4s	v30, v11, v30
	fadd.4s	v7, v7, v30
	fadd.4s	v17, v17, v18
	fadd.4s	v7, v7, v31
	sshr.4s	v18, v23, #1
	shl.4s	v30, v18, #23
	add.4s	v30, v30, v31
	fmul.4s	v7, v7, v30
	fadd.4s	v17, v17, v31
	sshr.4s	v30, v2, #1
	shl.4s	v11, v30, #23
	add.4s	v11, v11, v31
	fmul.4s	v17, v17, v11
	sub.4s	v18, v23, v18
	sub.4s	v23, v2, v30
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v31
	fmul.4s	v17, v17, v23
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v31
	fmul.4s	v7, v7, v18
	str	q28, [sp, #944]                 ; 16-byte Spill
	fcmgt.4s	v18, v27, v28
	bic.16b	v7, v7, v18
	str	q29, [sp, #992]                 ; 16-byte Spill
	fcmgt.4s	v18, v27, v29
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v29, v26
	bit.16b	v17, v3, v18
	str	q17, [sp, #1040]                ; 16-byte Spill
	fcmgt.4s	v17, v28, v26
	bit.16b	v7, v3, v17
	str	q7, [sp, #1024]                 ; 16-byte Spill
	ldr	q7, [sp, #960]                  ; 16-byte Reload
	fsub.4s	v7, v7, v4
	and.16b	v28, v0, v7
	fcmge.4s	v7, v28, v27
	fcmge.4s	v17, v26, v28
	and.16b	v7, v7, v17
	ldr	q17, [sp, #976]                 ; 16-byte Reload
	fsub.4s	v17, v17, v10
	and.16b	v29, v25, v17
	fcmge.4s	v17, v29, v27
	fcmge.4s	v18, v26, v29
	and.16b	v17, v17, v18
	and.16b	v18, v17, v29
	fmul.4s	v17, v18, v13
	mov.16b	v23, v15
	bsl.16b	v23, v14, v17
	fadd.4s	v17, v17, v23
	fsub.4s	v17, v17, v23
	and.16b	v7, v7, v28
	fmul.4s	v23, v7, v13
	mov.16b	v30, v15
	bsl.16b	v30, v14, v23
	fadd.4s	v23, v23, v30
	fsub.4s	v23, v23, v30
	fcvtzs.4s	v2, v17
	scvtf.4s	v30, v2
	fmul.4s	v11, v30, v9
	fsub.4s	v18, v18, v11
	fcvtzs.4s	v23, v23
	scvtf.4s	v11, v23
	fmul.4s	v17, v11, v9
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v11, v20
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v30, v20
	fsub.4s	v17, v18, v17
	fmul.4s	v18, v17, v22
	fadd.4s	v18, v18, v5
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v16
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v21
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v1
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v30, v17, v17
	fmul.4s	v18, v30, v18
	fmul.4s	v30, v7, v22
	fadd.4s	v30, v30, v5
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v16
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v21
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v1
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v12
	fmul.4s	v11, v7, v7
	fmul.4s	v30, v11, v30
	fadd.4s	v7, v7, v30
	fadd.4s	v17, v17, v18
	fadd.4s	v7, v7, v31
	sshr.4s	v18, v23, #1
	shl.4s	v30, v18, #23
	add.4s	v30, v30, v31
	fmul.4s	v7, v7, v30
	fadd.4s	v17, v17, v31
	sshr.4s	v30, v2, #1
	shl.4s	v11, v30, #23
	add.4s	v11, v11, v31
	fmul.4s	v17, v17, v11
	sub.4s	v18, v23, v18
	sub.4s	v23, v2, v30
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v31
	fmul.4s	v17, v17, v23
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v31
	fmul.4s	v7, v7, v18
	str	q28, [sp, #848]                 ; 16-byte Spill
	fcmgt.4s	v18, v27, v28
	bic.16b	v7, v7, v18
	str	q29, [sp, #928]                 ; 16-byte Spill
	fcmgt.4s	v18, v27, v29
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v29, v26
	bit.16b	v17, v3, v18
	str	q17, [sp, #976]                 ; 16-byte Spill
	fcmgt.4s	v17, v28, v26
	bit.16b	v7, v3, v17
	str	q7, [sp, #960]                  ; 16-byte Spill
	ldr	q7, [sp, #864]                  ; 16-byte Reload
	fsub.4s	v7, v7, v4
	and.16b	v28, v0, v7
	fcmge.4s	v7, v28, v27
	fcmge.4s	v17, v26, v28
	and.16b	v7, v7, v17
	ldr	q17, [sp, #880]                 ; 16-byte Reload
	fsub.4s	v17, v17, v10
	and.16b	v29, v25, v17
	fcmge.4s	v17, v29, v27
	fcmge.4s	v18, v26, v29
	and.16b	v17, v17, v18
	and.16b	v18, v17, v29
	fmul.4s	v17, v18, v13
	mov.16b	v23, v15
	bsl.16b	v23, v14, v17
	fadd.4s	v17, v17, v23
	fsub.4s	v17, v17, v23
	and.16b	v7, v7, v28
	fmul.4s	v23, v7, v13
	mov.16b	v30, v15
	bsl.16b	v30, v14, v23
	fadd.4s	v23, v23, v30
	fsub.4s	v23, v23, v30
	fcvtzs.4s	v2, v17
	scvtf.4s	v30, v2
	fmul.4s	v11, v30, v9
	fsub.4s	v18, v18, v11
	fcvtzs.4s	v23, v23
	scvtf.4s	v11, v23
	fmul.4s	v17, v11, v9
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v11, v20
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v30, v20
	fsub.4s	v17, v18, v17
	fmul.4s	v18, v17, v22
	fadd.4s	v18, v18, v5
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v16
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v21
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v1
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v30, v17, v17
	fmul.4s	v18, v30, v18
	fmul.4s	v30, v7, v22
	fadd.4s	v30, v30, v5
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v16
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v21
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v1
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v12
	fmul.4s	v11, v7, v7
	fmul.4s	v30, v11, v30
	fadd.4s	v7, v7, v30
	fadd.4s	v17, v17, v18
	fadd.4s	v7, v7, v31
	sshr.4s	v18, v23, #1
	shl.4s	v30, v18, #23
	add.4s	v30, v30, v31
	fmul.4s	v7, v7, v30
	fadd.4s	v17, v17, v31
	sshr.4s	v30, v2, #1
	shl.4s	v11, v30, #23
	add.4s	v11, v11, v31
	fmul.4s	v17, v17, v11
	sub.4s	v18, v23, v18
	sub.4s	v23, v2, v30
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v31
	fmul.4s	v17, v17, v23
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v31
	fmul.4s	v7, v7, v18
	str	q28, [sp, #752]                 ; 16-byte Spill
	fcmgt.4s	v18, v27, v28
	bic.16b	v7, v7, v18
	str	q29, [sp, #832]                 ; 16-byte Spill
	fcmgt.4s	v18, v27, v29
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v29, v26
	bit.16b	v17, v3, v18
	str	q17, [sp, #880]                 ; 16-byte Spill
	fcmgt.4s	v17, v28, v26
	bit.16b	v7, v3, v17
	str	q7, [sp, #864]                  ; 16-byte Spill
	ldr	q7, [sp, #768]                  ; 16-byte Reload
	fsub.4s	v7, v7, v4
	and.16b	v28, v0, v7
	fcmge.4s	v7, v28, v27
	fcmge.4s	v17, v26, v28
	and.16b	v7, v7, v17
	ldr	q17, [sp, #784]                 ; 16-byte Reload
	fsub.4s	v17, v17, v10
	and.16b	v29, v25, v17
	fcmge.4s	v17, v29, v27
	fcmge.4s	v18, v26, v29
	and.16b	v17, v17, v18
	and.16b	v18, v17, v29
	fmul.4s	v17, v18, v13
	mov.16b	v23, v15
	bsl.16b	v23, v14, v17
	fadd.4s	v17, v17, v23
	fsub.4s	v17, v17, v23
	and.16b	v7, v7, v28
	fmul.4s	v23, v7, v13
	mov.16b	v30, v15
	bsl.16b	v30, v14, v23
	fadd.4s	v23, v23, v30
	fsub.4s	v23, v23, v30
	fcvtzs.4s	v2, v17
	scvtf.4s	v30, v2
	fmul.4s	v11, v30, v9
	fsub.4s	v18, v18, v11
	fcvtzs.4s	v23, v23
	scvtf.4s	v11, v23
	fmul.4s	v17, v11, v9
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v11, v20
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v30, v20
	fsub.4s	v17, v18, v17
	fmul.4s	v18, v17, v22
	fadd.4s	v18, v18, v5
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v16
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v21
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v1
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v30, v17, v17
	fmul.4s	v18, v30, v18
	fmul.4s	v30, v7, v22
	fadd.4s	v30, v30, v5
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v16
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v21
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v1
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v12
	fmul.4s	v11, v7, v7
	fmul.4s	v30, v11, v30
	fadd.4s	v7, v7, v30
	fadd.4s	v17, v17, v18
	fadd.4s	v7, v7, v31
	sshr.4s	v18, v23, #1
	shl.4s	v30, v18, #23
	add.4s	v30, v30, v31
	fmul.4s	v7, v7, v30
	fadd.4s	v17, v17, v31
	sshr.4s	v30, v2, #1
	shl.4s	v11, v30, #23
	add.4s	v11, v11, v31
	fmul.4s	v17, v17, v11
	sub.4s	v18, v23, v18
	sub.4s	v23, v2, v30
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v31
	fmul.4s	v17, v17, v23
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v31
	fmul.4s	v7, v7, v18
	str	q28, [sp, #656]                 ; 16-byte Spill
	fcmgt.4s	v18, v27, v28
	bic.16b	v7, v7, v18
	str	q29, [sp, #736]                 ; 16-byte Spill
	fcmgt.4s	v18, v27, v29
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v29, v26
	bit.16b	v17, v3, v18
	str	q17, [sp, #784]                 ; 16-byte Spill
	fcmgt.4s	v17, v28, v26
	bit.16b	v7, v3, v17
	str	q7, [sp, #768]                  ; 16-byte Spill
	ldr	q7, [sp, #672]                  ; 16-byte Reload
	fsub.4s	v7, v7, v4
	and.16b	v28, v0, v7
	fcmge.4s	v7, v28, v27
	fcmge.4s	v17, v26, v28
	and.16b	v7, v7, v17
	ldr	q17, [sp, #688]                 ; 16-byte Reload
	fsub.4s	v17, v17, v10
	and.16b	v29, v25, v17
	fcmge.4s	v17, v29, v27
	fcmge.4s	v18, v26, v29
	and.16b	v17, v17, v18
	and.16b	v18, v17, v29
	fmul.4s	v17, v18, v13
	mov.16b	v23, v15
	bsl.16b	v23, v14, v17
	fadd.4s	v17, v17, v23
	fsub.4s	v17, v17, v23
	and.16b	v7, v7, v28
	fmul.4s	v23, v7, v13
	mov.16b	v30, v15
	bsl.16b	v30, v14, v23
	fadd.4s	v23, v23, v30
	fsub.4s	v23, v23, v30
	fcvtzs.4s	v2, v17
	scvtf.4s	v30, v2
	fmul.4s	v11, v30, v9
	fsub.4s	v18, v18, v11
	fcvtzs.4s	v23, v23
	scvtf.4s	v11, v23
	fmul.4s	v17, v11, v9
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v11, v20
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v30, v20
	fsub.4s	v17, v18, v17
	fmul.4s	v18, v17, v22
	fadd.4s	v18, v18, v5
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v16
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v21
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v1
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v30, v17, v17
	fmul.4s	v18, v30, v18
	fmul.4s	v30, v7, v22
	fadd.4s	v30, v30, v5
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v16
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v21
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v1
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v12
	fmul.4s	v11, v7, v7
	fmul.4s	v30, v11, v30
	fadd.4s	v7, v7, v30
	fadd.4s	v17, v17, v18
	fadd.4s	v7, v7, v31
	sshr.4s	v18, v23, #1
	shl.4s	v30, v18, #23
	add.4s	v30, v30, v31
	fmul.4s	v7, v7, v30
	fadd.4s	v17, v17, v31
	sshr.4s	v30, v2, #1
	shl.4s	v11, v30, #23
	add.4s	v11, v11, v31
	fmul.4s	v17, v17, v11
	sub.4s	v18, v23, v18
	sub.4s	v23, v2, v30
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v31
	fmul.4s	v17, v17, v23
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v31
	fmul.4s	v7, v7, v18
	str	q28, [sp, #496]                 ; 16-byte Spill
	fcmgt.4s	v18, v27, v28
	bic.16b	v7, v7, v18
	str	q29, [sp, #640]                 ; 16-byte Spill
	fcmgt.4s	v18, v27, v29
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v29, v26
	bit.16b	v17, v3, v18
	str	q17, [sp, #688]                 ; 16-byte Spill
	fcmgt.4s	v17, v28, v26
	bit.16b	v7, v3, v17
	str	q7, [sp, #672]                  ; 16-byte Spill
	ldr	q7, [sp, #576]                  ; 16-byte Reload
	fsub.4s	v7, v7, v4
	and.16b	v28, v0, v7
	fcmge.4s	v7, v28, v27
	fcmge.4s	v17, v26, v28
	and.16b	v7, v7, v17
	ldr	q17, [sp, #592]                 ; 16-byte Reload
	fsub.4s	v17, v17, v10
	and.16b	v29, v25, v17
	fcmge.4s	v17, v29, v27
	fcmge.4s	v18, v26, v29
	and.16b	v17, v17, v18
	and.16b	v18, v17, v29
	fmul.4s	v17, v18, v13
	mov.16b	v23, v15
	bsl.16b	v23, v14, v17
	fadd.4s	v17, v17, v23
	fsub.4s	v17, v17, v23
	and.16b	v7, v7, v28
	fmul.4s	v23, v7, v13
	mov.16b	v30, v15
	bsl.16b	v30, v14, v23
	fadd.4s	v23, v23, v30
	fsub.4s	v23, v23, v30
	fcvtzs.4s	v2, v17
	scvtf.4s	v30, v2
	fmul.4s	v11, v30, v9
	fsub.4s	v18, v18, v11
	fcvtzs.4s	v23, v23
	scvtf.4s	v11, v23
	fmul.4s	v17, v11, v9
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v11, v20
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v30, v20
	fsub.4s	v17, v18, v17
	fmul.4s	v18, v17, v22
	fadd.4s	v18, v18, v5
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v16
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v21
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v1
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v30, v17, v17
	fmul.4s	v18, v30, v18
	fmul.4s	v30, v7, v22
	fadd.4s	v30, v30, v5
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v16
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v21
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v1
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v12
	fmul.4s	v11, v7, v7
	fmul.4s	v30, v11, v30
	fadd.4s	v7, v7, v30
	fadd.4s	v17, v17, v18
	fadd.4s	v7, v7, v31
	sshr.4s	v18, v23, #1
	shl.4s	v30, v18, #23
	add.4s	v30, v30, v31
	fmul.4s	v7, v7, v30
	fadd.4s	v17, v17, v31
	sshr.4s	v30, v2, #1
	shl.4s	v11, v30, #23
	add.4s	v11, v11, v31
	fmul.4s	v17, v17, v11
	sub.4s	v18, v23, v18
	sub.4s	v23, v2, v30
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v31
	fmul.4s	v17, v17, v23
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v31
	fmul.4s	v7, v7, v18
	str	q28, [sp, #464]                 ; 16-byte Spill
	fcmgt.4s	v18, v27, v28
	bic.16b	v7, v7, v18
	str	q29, [sp, #544]                 ; 16-byte Spill
	fcmgt.4s	v18, v27, v29
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v29, v26
	bit.16b	v17, v3, v18
	str	q17, [sp, #592]                 ; 16-byte Spill
	fcmgt.4s	v17, v28, v26
	bit.16b	v7, v3, v17
	str	q7, [sp, #576]                  ; 16-byte Spill
	ldr	q7, [sp, #608]                  ; 16-byte Reload
	fsub.4s	v7, v7, v10
	and.16b	v28, v25, v7
	fcmge.4s	v7, v28, v27
	fcmge.4s	v17, v26, v28
	and.16b	v7, v7, v17
	ldr	q17, [sp, #624]                 ; 16-byte Reload
	fsub.4s	v17, v17, v4
	and.16b	v29, v0, v17
	fcmge.4s	v17, v29, v27
	fcmge.4s	v18, v26, v29
	and.16b	v17, v17, v18
	and.16b	v18, v17, v29
	fmul.4s	v17, v18, v13
	mov.16b	v23, v15
	bsl.16b	v23, v14, v17
	fadd.4s	v17, v17, v23
	fsub.4s	v17, v17, v23
	and.16b	v7, v7, v28
	fmul.4s	v23, v7, v13
	mov.16b	v30, v15
	bsl.16b	v30, v14, v23
	fadd.4s	v23, v23, v30
	fsub.4s	v23, v23, v30
	fcvtzs.4s	v2, v17
	scvtf.4s	v30, v2
	fmul.4s	v11, v30, v9
	fsub.4s	v18, v18, v11
	fcvtzs.4s	v23, v23
	scvtf.4s	v11, v23
	fmul.4s	v17, v11, v9
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v11, v20
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v30, v20
	fsub.4s	v17, v18, v17
	fmul.4s	v18, v17, v22
	fadd.4s	v18, v18, v5
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v16
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v21
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v1
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v30, v17, v17
	fmul.4s	v18, v30, v18
	fmul.4s	v30, v7, v22
	fadd.4s	v30, v30, v5
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v16
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v21
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v1
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v12
	fmul.4s	v11, v7, v7
	fmul.4s	v30, v11, v30
	fadd.4s	v7, v7, v30
	fadd.4s	v17, v17, v18
	fadd.4s	v7, v7, v31
	sshr.4s	v18, v23, #1
	shl.4s	v30, v18, #23
	add.4s	v30, v30, v31
	fmul.4s	v7, v7, v30
	fadd.4s	v17, v17, v31
	sshr.4s	v30, v2, #1
	shl.4s	v11, v30, #23
	add.4s	v11, v11, v31
	fmul.4s	v17, v17, v11
	sub.4s	v18, v23, v18
	sub.4s	v23, v2, v30
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v31
	fmul.4s	v17, v17, v23
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v31
	fmul.4s	v7, v7, v18
	str	q28, [sp, #432]                 ; 16-byte Spill
	fcmgt.4s	v18, v27, v28
	bic.16b	v7, v7, v18
	str	q29, [sp, #512]                 ; 16-byte Spill
	fcmgt.4s	v18, v27, v29
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v29, v26
	bit.16b	v17, v3, v18
	str	q17, [sp, #624]                 ; 16-byte Spill
	fcmgt.4s	v17, v28, v26
	bit.16b	v7, v3, v17
	str	q7, [sp, #608]                  ; 16-byte Spill
	ldr	q7, [sp, #704]                  ; 16-byte Reload
	fsub.4s	v7, v7, v10
	and.16b	v28, v25, v7
	fcmge.4s	v7, v28, v27
	fcmge.4s	v17, v26, v28
	and.16b	v7, v7, v17
	ldr	q17, [sp, #720]                 ; 16-byte Reload
	fsub.4s	v17, v17, v4
	and.16b	v29, v0, v17
	fcmge.4s	v17, v29, v27
	fcmge.4s	v18, v26, v29
	and.16b	v17, v17, v18
	and.16b	v18, v17, v29
	fmul.4s	v17, v18, v13
	mov.16b	v23, v15
	bsl.16b	v23, v14, v17
	fadd.4s	v17, v17, v23
	fsub.4s	v17, v17, v23
	and.16b	v7, v7, v28
	fmul.4s	v23, v7, v13
	mov.16b	v30, v15
	bsl.16b	v30, v14, v23
	fadd.4s	v23, v23, v30
	fsub.4s	v23, v23, v30
	fcvtzs.4s	v2, v17
	scvtf.4s	v30, v2
	fmul.4s	v11, v30, v9
	fsub.4s	v18, v18, v11
	fcvtzs.4s	v23, v23
	scvtf.4s	v11, v23
	fmul.4s	v17, v11, v9
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v11, v20
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v30, v20
	fsub.4s	v17, v18, v17
	fmul.4s	v18, v17, v22
	fadd.4s	v18, v18, v5
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v16
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v21
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v1
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v30, v17, v17
	fmul.4s	v18, v30, v18
	fmul.4s	v30, v7, v22
	fadd.4s	v30, v30, v5
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v16
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v21
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v1
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v12
	fmul.4s	v11, v7, v7
	fmul.4s	v30, v11, v30
	fadd.4s	v7, v7, v30
	fadd.4s	v17, v17, v18
	fadd.4s	v7, v7, v31
	sshr.4s	v18, v23, #1
	shl.4s	v30, v18, #23
	add.4s	v30, v30, v31
	fmul.4s	v7, v7, v30
	fadd.4s	v17, v17, v31
	sshr.4s	v30, v2, #1
	shl.4s	v11, v30, #23
	add.4s	v11, v11, v31
	fmul.4s	v17, v17, v11
	sub.4s	v18, v23, v18
	sub.4s	v23, v2, v30
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v31
	fmul.4s	v17, v17, v23
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v31
	fmul.4s	v7, v7, v18
	str	q28, [sp, #416]                 ; 16-byte Spill
	fcmgt.4s	v18, v27, v28
	bic.16b	v7, v7, v18
	str	q29, [sp, #480]                 ; 16-byte Spill
	fcmgt.4s	v18, v27, v29
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v29, v26
	bit.16b	v17, v3, v18
	str	q17, [sp, #720]                 ; 16-byte Spill
	fcmgt.4s	v17, v28, v26
	bit.16b	v7, v3, v17
	str	q7, [sp, #704]                  ; 16-byte Spill
	ldr	q7, [sp, #800]                  ; 16-byte Reload
	fsub.4s	v7, v7, v10
	and.16b	v28, v25, v7
	fcmge.4s	v7, v28, v27
	fcmge.4s	v17, v26, v28
	and.16b	v7, v7, v17
	ldr	q17, [sp, #816]                 ; 16-byte Reload
	fsub.4s	v17, v17, v4
	and.16b	v29, v0, v17
	fcmge.4s	v17, v29, v27
	fcmge.4s	v18, v26, v29
	and.16b	v17, v17, v18
	and.16b	v18, v17, v29
	fmul.4s	v17, v18, v13
	mov.16b	v23, v15
	bsl.16b	v23, v14, v17
	fadd.4s	v17, v17, v23
	fsub.4s	v17, v17, v23
	and.16b	v7, v7, v28
	fmul.4s	v23, v7, v13
	mov.16b	v30, v15
	bsl.16b	v30, v14, v23
	fadd.4s	v23, v23, v30
	fsub.4s	v23, v23, v30
	fcvtzs.4s	v2, v17
	scvtf.4s	v30, v2
	fmul.4s	v11, v30, v9
	fsub.4s	v18, v18, v11
	fcvtzs.4s	v23, v23
	scvtf.4s	v11, v23
	fmul.4s	v17, v11, v9
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v11, v20
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v30, v20
	fsub.4s	v17, v18, v17
	fmul.4s	v18, v17, v22
	fadd.4s	v18, v18, v5
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v16
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v21
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v1
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v30, v17, v17
	fmul.4s	v18, v30, v18
	fmul.4s	v30, v7, v22
	fadd.4s	v30, v30, v5
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v16
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v21
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v1
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v12
	fmul.4s	v11, v7, v7
	fmul.4s	v30, v11, v30
	fadd.4s	v7, v7, v30
	fadd.4s	v17, v17, v18
	fadd.4s	v7, v7, v31
	sshr.4s	v18, v23, #1
	shl.4s	v30, v18, #23
	add.4s	v30, v30, v31
	fmul.4s	v7, v7, v30
	fadd.4s	v17, v17, v31
	sshr.4s	v30, v2, #1
	shl.4s	v11, v30, #23
	add.4s	v11, v11, v31
	fmul.4s	v17, v17, v11
	sub.4s	v18, v23, v18
	sub.4s	v23, v2, v30
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v31
	fmul.4s	v17, v17, v23
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v31
	fmul.4s	v7, v7, v18
	str	q28, [sp, #352]                 ; 16-byte Spill
	fcmgt.4s	v18, v27, v28
	bic.16b	v7, v7, v18
	str	q29, [sp, #448]                 ; 16-byte Spill
	fcmgt.4s	v18, v27, v29
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v29, v26
	bit.16b	v17, v3, v18
	str	q17, [sp, #816]                 ; 16-byte Spill
	fcmgt.4s	v17, v28, v26
	bit.16b	v7, v3, v17
	str	q7, [sp, #800]                  ; 16-byte Spill
	ldr	q7, [sp, #896]                  ; 16-byte Reload
	fsub.4s	v7, v7, v10
	and.16b	v28, v25, v7
	fcmge.4s	v7, v28, v27
	fcmge.4s	v17, v26, v28
	and.16b	v7, v7, v17
	ldr	q17, [sp, #912]                 ; 16-byte Reload
	fsub.4s	v17, v17, v4
	and.16b	v29, v0, v17
	fcmge.4s	v17, v29, v27
	fcmge.4s	v18, v26, v29
	and.16b	v17, v17, v18
	and.16b	v18, v17, v29
	fmul.4s	v17, v18, v13
	mov.16b	v23, v15
	bsl.16b	v23, v14, v17
	fadd.4s	v17, v17, v23
	fsub.4s	v17, v17, v23
	and.16b	v7, v7, v28
	fmul.4s	v23, v7, v13
	mov.16b	v30, v15
	bsl.16b	v30, v14, v23
	fadd.4s	v23, v23, v30
	fsub.4s	v23, v23, v30
	fcvtzs.4s	v2, v17
	scvtf.4s	v30, v2
	fmul.4s	v11, v30, v9
	fsub.4s	v18, v18, v11
	fcvtzs.4s	v23, v23
	scvtf.4s	v11, v23
	fmul.4s	v17, v11, v9
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v11, v20
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v30, v20
	fsub.4s	v17, v18, v17
	fmul.4s	v18, v17, v22
	fadd.4s	v18, v18, v5
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v16
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v21
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v1
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v30, v17, v17
	fmul.4s	v18, v30, v18
	fmul.4s	v30, v7, v22
	fadd.4s	v30, v30, v5
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v16
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v21
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v1
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v12
	fmul.4s	v11, v7, v7
	fmul.4s	v30, v11, v30
	fadd.4s	v7, v7, v30
	fadd.4s	v17, v17, v18
	fadd.4s	v7, v7, v31
	sshr.4s	v18, v23, #1
	shl.4s	v30, v18, #23
	add.4s	v30, v30, v31
	fmul.4s	v7, v7, v30
	fadd.4s	v17, v17, v31
	sshr.4s	v30, v2, #1
	shl.4s	v11, v30, #23
	add.4s	v11, v11, v31
	fmul.4s	v17, v17, v11
	sub.4s	v18, v23, v18
	sub.4s	v23, v2, v30
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v31
	fmul.4s	v17, v17, v23
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v31
	fmul.4s	v7, v7, v18
	str	q28, [sp, #320]                 ; 16-byte Spill
	fcmgt.4s	v18, v27, v28
	bic.16b	v7, v7, v18
	str	q29, [sp, #368]                 ; 16-byte Spill
	fcmgt.4s	v18, v27, v29
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v29, v26
	bit.16b	v17, v3, v18
	str	q17, [sp, #912]                 ; 16-byte Spill
	fcmgt.4s	v17, v28, v26
	bit.16b	v7, v3, v17
	str	q7, [sp, #896]                  ; 16-byte Spill
	ldr	q7, [sp, #1152]                 ; 16-byte Reload
	fsub.4s	v7, v7, v4
	and.16b	v8, v0, v7
	fcmge.4s	v7, v8, v27
	fcmge.4s	v17, v26, v8
	and.16b	v7, v7, v17
	ldr	q17, [sp, #1168]                ; 16-byte Reload
	fsub.4s	v17, v17, v10
	and.16b	v29, v25, v17
	fcmge.4s	v17, v29, v27
	fcmge.4s	v18, v26, v29
	and.16b	v17, v17, v18
	and.16b	v18, v17, v29
	fmul.4s	v17, v18, v13
	mov.16b	v23, v15
	bsl.16b	v23, v14, v17
	fadd.4s	v17, v17, v23
	fsub.4s	v17, v17, v23
	and.16b	v7, v7, v8
	fmul.4s	v23, v7, v13
	mov.16b	v30, v15
	bsl.16b	v30, v14, v23
	fadd.4s	v23, v23, v30
	fsub.4s	v23, v23, v30
	fcvtzs.4s	v2, v17
	scvtf.4s	v30, v2
	fmul.4s	v11, v30, v9
	fsub.4s	v18, v18, v11
	fcvtzs.4s	v23, v23
	scvtf.4s	v11, v23
	fmul.4s	v17, v11, v9
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v11, v20
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v30, v20
	fsub.4s	v17, v18, v17
	fmul.4s	v18, v17, v22
	fadd.4s	v18, v18, v5
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v16
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v21
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v1
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v30, v17, v17
	fmul.4s	v18, v30, v18
	fmul.4s	v30, v7, v22
	fadd.4s	v30, v30, v5
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v16
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v21
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v1
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v12
	fmul.4s	v11, v7, v7
	fmul.4s	v30, v11, v30
	fadd.4s	v7, v7, v30
	fadd.4s	v17, v17, v18
	fadd.4s	v7, v7, v31
	sshr.4s	v18, v23, #1
	shl.4s	v30, v18, #23
	add.4s	v30, v30, v31
	fmul.4s	v7, v7, v30
	fadd.4s	v17, v17, v31
	sshr.4s	v30, v2, #1
	shl.4s	v11, v30, #23
	add.4s	v11, v11, v31
	fmul.4s	v17, v17, v11
	sub.4s	v18, v23, v18
	sub.4s	v23, v2, v30
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v31
	fmul.4s	v17, v17, v23
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v31
	fmul.4s	v7, v7, v18
	fcmgt.4s	v18, v27, v8
	bic.16b	v7, v7, v18
	str	q29, [sp, #336]                 ; 16-byte Spill
	fcmgt.4s	v18, v27, v29
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v29, v26
	bit.16b	v17, v3, v18
	str	q17, [sp, #400]                 ; 16-byte Spill
	fcmgt.4s	v17, v8, v26
	bit.16b	v7, v3, v17
	str	q7, [sp, #384]                  ; 16-byte Spill
	ldr	q7, [sp, #1728]                 ; 16-byte Reload
	fsub.4s	v7, v7, v10
	and.16b	v24, v25, v7
	fcmge.4s	v7, v24, v27
	fcmge.4s	v17, v26, v24
	and.16b	v7, v7, v17
	ldr	q17, [sp, #1744]                ; 16-byte Reload
	fsub.4s	v17, v17, v4
	and.16b	v29, v0, v17
	fcmge.4s	v17, v29, v27
	fcmge.4s	v18, v26, v29
	and.16b	v17, v17, v18
	and.16b	v18, v17, v29
	fmul.4s	v17, v18, v13
	mov.16b	v23, v15
	bsl.16b	v23, v14, v17
	fadd.4s	v17, v17, v23
	fsub.4s	v17, v17, v23
	and.16b	v7, v7, v24
	fmul.4s	v23, v7, v13
	mov.16b	v30, v15
	bsl.16b	v30, v14, v23
	fadd.4s	v23, v23, v30
	fsub.4s	v23, v23, v30
	fcvtzs.4s	v2, v17
	scvtf.4s	v30, v2
	fmul.4s	v11, v30, v9
	fsub.4s	v18, v18, v11
	fcvtzs.4s	v23, v23
	scvtf.4s	v11, v23
	fmul.4s	v17, v11, v9
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v11, v20
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v30, v20
	fsub.4s	v17, v18, v17
	fmul.4s	v18, v17, v22
	fadd.4s	v18, v18, v5
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v16
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v21
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v1
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v30, v17, v17
	fmul.4s	v18, v30, v18
	fmul.4s	v30, v7, v22
	fadd.4s	v30, v30, v5
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v16
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v21
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v1
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v12
	fmul.4s	v11, v7, v7
	fmul.4s	v30, v11, v30
	fadd.4s	v7, v7, v30
	fadd.4s	v17, v17, v18
	fadd.4s	v7, v7, v31
	sshr.4s	v18, v23, #1
	shl.4s	v30, v18, #23
	add.4s	v30, v30, v31
	fmul.4s	v7, v7, v30
	fadd.4s	v17, v17, v31
	sshr.4s	v30, v2, #1
	shl.4s	v11, v30, #23
	add.4s	v11, v11, v31
	fmul.4s	v17, v17, v11
	sub.4s	v18, v23, v18
	sub.4s	v23, v2, v30
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v31
	fmul.4s	v17, v17, v23
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v31
	fmul.4s	v7, v7, v18
	fcmgt.4s	v18, v27, v24
	bic.16b	v7, v7, v18
	fcmgt.4s	v18, v27, v29
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v29, v26
	bit.16b	v17, v3, v18
	str	q17, [sp, #1744]                ; 16-byte Spill
	fcmgt.4s	v17, v24, v26
	bit.16b	v7, v3, v17
	str	q7, [sp, #1728]                 ; 16-byte Spill
	ldr	q7, [sp, #1824]                 ; 16-byte Reload
	fsub.4s	v7, v7, v10
	and.16b	v19, v25, v7
	fcmge.4s	v7, v19, v27
	fcmge.4s	v17, v26, v19
	and.16b	v7, v7, v17
	ldr	q17, [sp, #1840]                ; 16-byte Reload
	fsub.4s	v17, v17, v4
	and.16b	v28, v0, v17
	fcmge.4s	v17, v28, v27
	fcmge.4s	v18, v26, v28
	and.16b	v17, v17, v18
	and.16b	v18, v17, v28
	fmul.4s	v17, v18, v13
	mov.16b	v23, v15
	bsl.16b	v23, v14, v17
	fadd.4s	v17, v17, v23
	fsub.4s	v17, v17, v23
	and.16b	v7, v7, v19
	fmul.4s	v23, v7, v13
	mov.16b	v30, v15
	bsl.16b	v30, v14, v23
	fadd.4s	v23, v23, v30
	fsub.4s	v23, v23, v30
	fcvtzs.4s	v2, v17
	scvtf.4s	v30, v2
	fmul.4s	v11, v30, v9
	fsub.4s	v18, v18, v11
	fcvtzs.4s	v23, v23
	scvtf.4s	v11, v23
	fmul.4s	v17, v11, v9
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v11, v20
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v30, v20
	fsub.4s	v17, v18, v17
	fmul.4s	v18, v17, v22
	fadd.4s	v18, v18, v5
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v16
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v21
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v1
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v30, v17, v17
	fmul.4s	v18, v30, v18
	fmul.4s	v30, v7, v22
	fadd.4s	v30, v30, v5
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v16
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v21
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v1
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v12
	fmul.4s	v11, v7, v7
	fmul.4s	v30, v11, v30
	fadd.4s	v7, v7, v30
	fadd.4s	v17, v17, v18
	fadd.4s	v7, v7, v31
	sshr.4s	v18, v23, #1
	shl.4s	v30, v18, #23
	add.4s	v30, v30, v31
	fmul.4s	v7, v7, v30
	fadd.4s	v17, v17, v31
	sshr.4s	v30, v2, #1
	shl.4s	v11, v30, #23
	add.4s	v11, v11, v31
	fmul.4s	v17, v17, v11
	sub.4s	v18, v23, v18
	sub.4s	v23, v2, v30
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v31
	fmul.4s	v17, v17, v23
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v31
	fmul.4s	v7, v7, v18
	fcmgt.4s	v18, v27, v19
	bic.16b	v7, v7, v18
	fcmgt.4s	v18, v27, v28
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v28, v26
	bit.16b	v17, v3, v18
	str	q17, [sp, #1840]                ; 16-byte Spill
	fcmgt.4s	v17, v19, v26
	bit.16b	v7, v3, v17
	str	q7, [sp, #1824]                 ; 16-byte Spill
	str	q4, [sp, #1152]                 ; 16-byte Spill
	ldr	q7, [sp, #2480]                 ; 16-byte Reload
	fsub.4s	v7, v7, v4
	and.16b	v2, v0, v7
	fcmge.4s	v7, v2, v27
	fcmge.4s	v17, v26, v2
	and.16b	v7, v7, v17
	str	q10, [sp, #1168]                ; 16-byte Spill
	ldr	q4, [sp, #2464]                 ; 16-byte Reload
	fsub.4s	v17, v4, v10
	and.16b	v4, v25, v17
	fcmge.4s	v17, v4, v27
	fcmge.4s	v18, v26, v4
	and.16b	v17, v17, v18
	and.16b	v17, v17, v4
	fmul.4s	v18, v17, v13
	mov.16b	v23, v15
	bsl.16b	v23, v14, v18
	fadd.4s	v18, v18, v23
	fsub.4s	v18, v18, v23
	and.16b	v7, v7, v2
	fmul.4s	v23, v7, v13
	mov.16b	v30, v15
	bsl.16b	v30, v14, v23
	fadd.4s	v23, v23, v30
	fsub.4s	v23, v23, v30
	fcvtzs.4s	v10, v18
	scvtf.4s	v30, v10
	fmul.4s	v11, v30, v9
	fsub.4s	v17, v17, v11
	fcvtzs.4s	v23, v23
	scvtf.4s	v11, v23
	fmul.4s	v18, v11, v9
	fsub.4s	v7, v7, v18
	fmul.4s	v18, v30, v20
	fmul.4s	v30, v11, v20
	fsub.4s	v7, v7, v30
	fsub.4s	v17, v17, v18
	fmul.4s	v18, v17, v22
	fmul.4s	v30, v7, v22
	fadd.4s	v30, v30, v5
	fadd.4s	v18, v18, v5
	fmul.4s	v18, v17, v18
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v16
	fadd.4s	v18, v18, v16
	fmul.4s	v18, v17, v18
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v21
	fadd.4s	v18, v18, v21
	fmul.4s	v18, v17, v18
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v1
	fadd.4s	v18, v18, v1
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v12
	fmul.4s	v11, v17, v17
	fmul.4s	v18, v11, v18
	fmul.4s	v30, v7, v30
	fadd.4s	v30, v30, v12
	fmul.4s	v11, v7, v7
	fmul.4s	v30, v11, v30
	fadd.4s	v7, v7, v30
	fadd.4s	v17, v17, v18
	fadd.4s	v7, v7, v31
	sshr.4s	v18, v23, #1
	shl.4s	v30, v18, #23
	add.4s	v30, v30, v31
	fmul.4s	v7, v7, v30
	fadd.4s	v17, v17, v31
	sshr.4s	v30, v10, #1
	shl.4s	v11, v30, #23
	add.4s	v11, v11, v31
	fmul.4s	v17, v17, v11
	sub.4s	v18, v23, v18
	sub.4s	v23, v10, v30
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v31
	fmul.4s	v17, v17, v23
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v31
	fmul.4s	v7, v7, v18
	fcmgt.4s	v18, v27, v2
	bic.16b	v7, v7, v18
	fcmgt.4s	v18, v27, v4
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v4, v26
	mov.16b	v1, v18
	bsl.16b	v1, v3, v17
	stp	q4, q1, [sp, #272]              ; 32-byte Folded Spill
	fcmgt.4s	v17, v2, v26
	mov.16b	v1, v17
	bsl.16b	v1, v3, v7
	stp	q2, q1, [sp, #240]              ; 32-byte Folded Spill
	sshll2.2d	v7, v25, #0
	ldr	q1, [sp, #1520]                 ; 16-byte Reload
	ldr	q2, [sp, #1936]                 ; 16-byte Reload
	bit.16b	v1, v2, v7
	str	q1, [sp, #1520]                 ; 16-byte Spill
	ldr	q17, [sp, #1680]                ; 16-byte Reload
	bit.16b	v17, v2, v7
	str	q17, [sp, #1680]                ; 16-byte Spill
	sshll.2d	v7, v0, #0
	ldr	q1, [sp, #1504]                 ; 16-byte Reload
	ldr	q2, [sp, #2432]                 ; 16-byte Reload
	bit.16b	v1, v2, v7
	str	q1, [sp, #1504]                 ; 16-byte Spill
	ldr	q17, [sp, #1664]                ; 16-byte Reload
	bit.16b	v17, v2, v7
	str	q17, [sp, #1664]                ; 16-byte Spill
	ldr	q1, [sp, #304]                  ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q12, [sp, #144]                 ; 16-byte Reload
	ldr	q1, [sp, #1920]                 ; 16-byte Reload
	mov.16b	v2, v7
	bsl.16b	v2, v1, v12
	str	q2, [sp, #1936]                 ; 16-byte Spill
	ldr	q1, [sp, #1776]                 ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #1856]                 ; 16-byte Reload
	mov.16b	v3, v7
	bsl.16b	v3, v1, v12
	str	q3, [sp, #1920]                 ; 16-byte Spill
	ldr	q1, [sp, #560]                  ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #1872]                 ; 16-byte Reload
	mov.16b	v21, v7
	bsl.16b	v21, v1, v12
	ldr	q1, [sp, #528]                  ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #1888]                 ; 16-byte Reload
	mov.16b	v26, v7
	bsl.16b	v26, v1, v12
	ldr	q1, [sp, #1008]                 ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #1792]                 ; 16-byte Reload
	mov.16b	v16, v7
	bsl.16b	v16, v1, v12
	ldr	q1, [sp, #1760]                 ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #1808]                 ; 16-byte Reload
	mov.16b	v10, v7
	bsl.16b	v10, v1, v12
	ldr	q1, [sp, #944]                  ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #1024]                 ; 16-byte Reload
	mov.16b	v27, v7
	bsl.16b	v27, v1, v12
	ldr	q1, [sp, #992]                  ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #1040]                 ; 16-byte Reload
	mov.16b	v22, v7
	bsl.16b	v22, v1, v12
	ldr	q1, [sp, #848]                  ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #960]                  ; 16-byte Reload
	mov.16b	v9, v7
	bsl.16b	v9, v1, v12
	ldr	q1, [sp, #928]                  ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #976]                  ; 16-byte Reload
	mov.16b	v5, v7
	bsl.16b	v5, v1, v12
	ldr	q1, [sp, #752]                  ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #864]                  ; 16-byte Reload
	mov.16b	v13, v7
	bsl.16b	v13, v1, v12
	ldr	q1, [sp, #832]                  ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #880]                  ; 16-byte Reload
	mov.16b	v4, v7
	bsl.16b	v4, v1, v12
	ldr	q1, [sp, #656]                  ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #768]                  ; 16-byte Reload
	bif.16b	v1, v12, v7
	str	q1, [sp, #2432]                 ; 16-byte Spill
	ldr	q1, [sp, #736]                  ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #784]                  ; 16-byte Reload
	mov.16b	v20, v7
	bsl.16b	v20, v1, v12
	ldr	q1, [sp, #496]                  ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #672]                  ; 16-byte Reload
	bif.16b	v1, v12, v7
	str	q1, [sp, #1888]                 ; 16-byte Spill
	ldr	q1, [sp, #640]                  ; 16-byte Reload
	fcmeq.4s	v18, v1, v1
	ldr	q1, [sp, #688]                  ; 16-byte Reload
	mov.16b	v31, v18
	bsl.16b	v31, v1, v12
	ldr	q1, [sp, #464]                  ; 16-byte Reload
	fcmeq.4s	v18, v1, v1
	ldr	q1, [sp, #576]                  ; 16-byte Reload
	bif.16b	v1, v12, v18
	str	q1, [sp, #1872]                 ; 16-byte Spill
	ldr	q1, [sp, #544]                  ; 16-byte Reload
	fcmeq.4s	v23, v1, v1
	ldr	q1, [sp, #592]                  ; 16-byte Reload
	mov.16b	v14, v23
	bsl.16b	v14, v1, v12
	ldr	q1, [sp, #432]                  ; 16-byte Reload
	fcmeq.4s	v23, v1, v1
	ldr	q1, [sp, #608]                  ; 16-byte Reload
	mov.16b	v15, v23
	bsl.16b	v15, v1, v12
	ldr	q1, [sp, #512]                  ; 16-byte Reload
	fcmeq.4s	v23, v1, v1
	ldr	q1, [sp, #624]                  ; 16-byte Reload
	bif.16b	v1, v12, v23
	str	q1, [sp, #1856]                 ; 16-byte Spill
	ldr	q1, [sp, #416]                  ; 16-byte Reload
	fcmeq.4s	v11, v1, v1
	ldr	q1, [sp, #704]                  ; 16-byte Reload
	bif.16b	v1, v12, v11
	str	q1, [sp, #1040]                 ; 16-byte Spill
	ldr	q1, [sp, #480]                  ; 16-byte Reload
	fcmeq.4s	v11, v1, v1
	ldr	q1, [sp, #720]                  ; 16-byte Reload
	bif.16b	v1, v12, v11
	str	q1, [sp, #1808]                 ; 16-byte Spill
	ldr	q1, [sp, #352]                  ; 16-byte Reload
	fcmeq.4s	v30, v1, v1
	ldr	q1, [sp, #800]                  ; 16-byte Reload
	bif.16b	v1, v12, v30
	str	q1, [sp, #1024]                 ; 16-byte Spill
	ldr	q1, [sp, #448]                  ; 16-byte Reload
	fcmeq.4s	v30, v1, v1
	ldr	q1, [sp, #816]                  ; 16-byte Reload
	bif.16b	v1, v12, v30
	str	q1, [sp, #960]                  ; 16-byte Spill
	ldr	q1, [sp, #320]                  ; 16-byte Reload
	fcmeq.4s	v17, v1, v1
	ldr	q1, [sp, #896]                  ; 16-byte Reload
	bif.16b	v1, v12, v17
	str	q1, [sp, #1008]                 ; 16-byte Spill
	ldr	q1, [sp, #368]                  ; 16-byte Reload
	fcmeq.4s	v17, v1, v1
	ldr	q1, [sp, #912]                  ; 16-byte Reload
	bif.16b	v1, v12, v17
	str	q1, [sp, #944]                  ; 16-byte Spill
	fcmeq.4s	v7, v8, v8
	ldr	q1, [sp, #384]                  ; 16-byte Reload
	mov.16b	v8, v7
	bsl.16b	v8, v1, v12
	ldr	q1, [sp, #336]                  ; 16-byte Reload
	fcmeq.4s	v18, v1, v1
	ldr	q1, [sp, #400]                  ; 16-byte Reload
	bif.16b	v1, v12, v18
	str	q1, [sp, #992]                  ; 16-byte Spill
	fcmeq.4s	v18, v24, v24
	ldr	q1, [sp, #1728]                 ; 16-byte Reload
	bif.16b	v1, v12, v18
	str	q1, [sp, #1728]                 ; 16-byte Spill
	fcmeq.4s	v18, v29, v29
	ldr	q1, [sp, #1744]                 ; 16-byte Reload
	bsl.16b	v18, v1, v12
	fcmeq.4s	v23, v19, v19
	ldr	q1, [sp, #1824]                 ; 16-byte Reload
	bif.16b	v1, v12, v23
	str	q1, [sp, #976]                  ; 16-byte Spill
	fcmeq.4s	v23, v28, v28
	ldr	q1, [sp, #1840]                 ; 16-byte Reload
	bsl.16b	v23, v1, v12
	ldp	q30, q11, [x11, #512]
	bit.16b	v11, v3, v0
	bit.16b	v30, v2, v25
	stp	q30, q11, [x11, #512]
	ldr	d1, [sp, #1904]                 ; 8-byte Reload
	zip1.8b	v30, v1, v0
	ushll.4s	v30, v30, #0
	shl.4s	v30, v30, #31
	cmlt.4s	v30, v30, #0
	and.16b	v2, v30, v26
	str	q2, [sp, #1840]                 ; 16-byte Spill
	zip2.8b	v11, v1, v0
	ushll.4s	v11, v11, #0
	shl.4s	v11, v11, #31
	cmlt.4s	v11, v11, #0
	and.16b	v1, v11, v21
	str	q1, [sp, #1792]                 ; 16-byte Spill
	ldp	q7, q17, [x11, #544]
	bit.16b	v17, v1, v0
	bit.16b	v7, v2, v25
	stp	q7, q17, [x11, #544]
	and.16b	v26, v11, v16
	and.16b	v27, v11, v27
	and.16b	v29, v11, v9
	and.16b	v28, v11, v13
	ldr	q1, [sp, #2432]                 ; 16-byte Reload
	and.16b	v9, v11, v1
	ldr	q1, [sp, #1888]                 ; 16-byte Reload
	and.16b	v1, v11, v1
	str	q1, [sp, #1776]                 ; 16-byte Spill
	ldr	q2, [sp, #1872]                 ; 16-byte Reload
	and.16b	v3, v11, v2
	str	q3, [sp, #1760]                 ; 16-byte Spill
	ldr	q2, [sp, #1856]                 ; 16-byte Reload
	and.16b	v16, v11, v2
	str	q16, [sp, #1824]                ; 16-byte Spill
	ldr	q2, [sp, #1808]                 ; 16-byte Reload
	and.16b	v2, v11, v2
	str	q2, [sp, #1808]                 ; 16-byte Spill
	ldp	q2, q7, [sp, #944]              ; 32-byte Folded Reload
	and.16b	v19, v11, v7
	str	q19, [sp, #1872]                ; 16-byte Spill
	and.16b	v21, v11, v2
	str	q21, [sp, #1856]                ; 16-byte Spill
	and.16b	v24, v11, v8
	str	q24, [sp, #1904]                ; 16-byte Spill
	and.16b	v13, v11, v18
	str	q13, [sp, #1888]                ; 16-byte Spill
	and.16b	v2, v11, v23
	str	q2, [sp, #2432]                 ; 16-byte Spill
	and.16b	v18, v30, v10
	ldp	q17, q7, [x11, #576]
	bit.16b	v7, v26, v0
	bit.16b	v17, v18, v25
	stp	q17, q7, [x11, #576]
	and.16b	v11, v30, v22
	ldp	q17, q7, [x11, #608]
	bit.16b	v7, v27, v0
	bit.16b	v17, v11, v25
	stp	q17, q7, [x11, #608]
	and.16b	v10, v30, v5
	ldp	q17, q7, [x11, #640]
	bit.16b	v7, v29, v0
	bit.16b	v17, v10, v25
	stp	q17, q7, [x11, #640]
	and.16b	v4, v30, v4
	and.16b	v5, v30, v20
	and.16b	v20, v30, v31
	and.16b	v22, v30, v14
	and.16b	v23, v30, v15
	ldr	q2, [sp, #1040]                 ; 16-byte Reload
	and.16b	v31, v30, v2
	ldp	q2, q7, [sp, #1008]             ; 32-byte Folded Reload
	and.16b	v8, v30, v7
	and.16b	v15, v30, v2
	ldp	q7, q2, [sp, #976]              ; 32-byte Folded Reload
	and.16b	v14, v30, v2
	ldr	q2, [sp, #1728]                 ; 16-byte Reload
	and.16b	v2, v30, v2
	str	q2, [sp, #1744]                 ; 16-byte Spill
	and.16b	v30, v30, v7
	str	q30, [sp, #1728]                ; 16-byte Spill
	ldp	q17, q7, [x11, #672]
	bit.16b	v7, v28, v0
	bit.16b	v17, v4, v25
	stp	q17, q7, [x11, #672]
	ldp	q17, q7, [x11, #704]
	bit.16b	v7, v9, v0
	bit.16b	v17, v5, v25
	stp	q17, q7, [x11, #704]
	ldp	q17, q7, [x11, #736]
	bit.16b	v7, v1, v0
	bit.16b	v17, v20, v25
	stp	q17, q7, [x11, #736]
	ldp	q17, q7, [x11, #768]
	bit.16b	v7, v3, v0
	bit.16b	v17, v22, v25
	stp	q17, q7, [x11, #768]
	ldp	q7, q17, [x11, #800]
	bit.16b	v7, v23, v25
	bit.16b	v17, v16, v0
	stp	q7, q17, [x11, #800]
	ldp	q7, q17, [x11, #832]
	bit.16b	v7, v31, v25
	ldr	q3, [sp, #1808]                 ; 16-byte Reload
	bit.16b	v17, v3, v0
	stp	q7, q17, [x11, #832]
	ldp	q7, q17, [x11, #864]
	bit.16b	v7, v8, v25
	bit.16b	v17, v19, v0
	stp	q7, q17, [x11, #864]
	ldp	q7, q17, [x11, #896]
	bit.16b	v7, v15, v25
	bit.16b	v17, v21, v0
	stp	q7, q17, [x11, #896]
	ldp	q17, q7, [x11, #928]
	bit.16b	v7, v24, v0
	bit.16b	v17, v14, v25
	stp	q17, q7, [x11, #928]
	ldp	q7, q17, [x11, #960]
	bit.16b	v7, v2, v25
	bit.16b	v17, v13, v0
	stp	q7, q17, [x11, #960]
	ldp	q7, q17, [x11, #992]
	bit.16b	v7, v30, v25
	ldr	q1, [sp, #2432]                 ; 16-byte Reload
	bit.16b	v17, v1, v0
	stp	q7, q17, [x11, #992]
	ldp	q2, q1, [sp, #240]              ; 32-byte Folded Reload
	fcmeq.4s	v7, v2, v2
	mov.16b	v30, v7
	bsl.16b	v30, v1, v12
	ldr	q1, [sp, #272]                  ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #288]                  ; 16-byte Reload
	bif.16b	v1, v12, v7
	sshll.2d	v7, v25, #0
	ldr	q17, [sp, #1696]                ; 16-byte Reload
	ldr	q12, [sp, #2528]                ; 16-byte Reload
	bit.16b	v12, v17, v7
	str	q12, [sp, #2528]                ; 16-byte Spill
	ldr	q12, [sp, #2448]                ; 16-byte Reload
	bit.16b	v12, v17, v7
	stp	q1, q30, [sp, #848]             ; 32-byte Folded Spill
	ldr	q7, [sp, #2560]                 ; 16-byte Reload
	bit.16b	v7, v1, v25
	str	q7, [sp, #2560]                 ; 16-byte Spill
	ldr	q1, [sp, #2544]                 ; 16-byte Reload
	bit.16b	v1, v30, v0
	str	q1, [sp, #2544]                 ; 16-byte Spill
	ldr	q1, [sp, #2592]                 ; 16-byte Reload
	ldr	q7, [sp, #1936]                 ; 16-byte Reload
	bit.16b	v1, v7, v25
	str	q1, [sp, #2592]                 ; 16-byte Spill
	ldr	q1, [sp, #2576]                 ; 16-byte Reload
	ldr	q7, [sp, #1920]                 ; 16-byte Reload
	bit.16b	v1, v7, v0
	str	q1, [sp, #2576]                 ; 16-byte Spill
	ldr	q1, [sp, #2624]                 ; 16-byte Reload
	ldr	q2, [sp, #1840]                 ; 16-byte Reload
	bit.16b	v1, v2, v25
	str	q1, [sp, #2624]                 ; 16-byte Spill
	ldr	q1, [sp, #2608]                 ; 16-byte Reload
	ldr	q2, [sp, #1792]                 ; 16-byte Reload
	bit.16b	v1, v2, v0
	str	q1, [sp, #2608]                 ; 16-byte Spill
	stp	q18, q26, [sp, #1008]           ; 32-byte Folded Spill
	ldr	q1, [sp, #2656]                 ; 16-byte Reload
	bit.16b	v1, v18, v25
	str	q1, [sp, #2656]                 ; 16-byte Spill
	ldr	q1, [sp, #2640]                 ; 16-byte Reload
	bit.16b	v1, v26, v0
	str	q1, [sp, #2640]                 ; 16-byte Spill
	stp	q10, q11, [sp, #976]            ; 32-byte Folded Spill
	ldr	q1, [sp, #2688]                 ; 16-byte Reload
	bit.16b	v1, v11, v25
	str	q1, [sp, #2688]                 ; 16-byte Spill
	ldr	q11, [sp, #1600]                ; 16-byte Reload
	str	q27, [sp, #1040]                ; 16-byte Spill
	bit.16b	v11, v27, v0
	ldr	q16, [sp, #1072]                ; 16-byte Reload
	bit.16b	v16, v10, v25
	ldr	q24, [sp, #1088]                ; 16-byte Reload
	str	q29, [sp, #1072]                ; 16-byte Spill
	bit.16b	v24, v29, v0
	ldr	q13, [sp, #1104]                ; 16-byte Reload
	stp	q4, q20, [sp, #880]             ; 32-byte Folded Spill
	bit.16b	v13, v4, v25
	ldr	q21, [sp, #1056]                ; 16-byte Reload
	str	q28, [sp, #1104]                ; 16-byte Spill
	bit.16b	v21, v28, v0
	ldr	q18, [sp, #1136]                ; 16-byte Reload
	stp	q5, q23, [sp, #912]             ; 32-byte Folded Spill
	bit.16b	v18, v5, v25
	ldr	q30, [sp, #1120]                ; 16-byte Reload
	str	q9, [sp, #1136]                 ; 16-byte Spill
	bit.16b	v30, v9, v0
	ldr	q19, [sp, #1216]                ; 16-byte Reload
	bit.16b	v19, v20, v25
	ldr	q17, [sp, #1200]                ; 16-byte Reload
	ldr	q1, [sp, #1776]                 ; 16-byte Reload
	bit.16b	v17, v1, v0
	ldr	q28, [sp, #1248]                ; 16-byte Reload
	stp	q22, q8, [sp, #944]             ; 32-byte Folded Spill
	bit.16b	v28, v22, v25
	ldr	q29, [sp, #1232]                ; 16-byte Reload
	ldr	q1, [sp, #1760]                 ; 16-byte Reload
	bit.16b	v29, v1, v0
	ldr	q26, [sp, #1280]                ; 16-byte Reload
	bit.16b	v26, v23, v25
	ldr	q27, [sp, #1264]                ; 16-byte Reload
	ldr	q1, [sp, #1824]                 ; 16-byte Reload
	bit.16b	v27, v1, v0
	ldr	q9, [sp, #1312]                 ; 16-byte Reload
	str	q31, [sp, #1056]                ; 16-byte Spill
	bit.16b	v9, v31, v25
	ldr	q10, [sp, #1296]                ; 16-byte Reload
	bit.16b	v10, v3, v0
	ldr	q4, [sp, #1344]                 ; 16-byte Reload
	bit.16b	v4, v8, v25
	ldr	q8, [sp, #1328]                 ; 16-byte Reload
	ldr	q1, [sp, #1872]                 ; 16-byte Reload
	bit.16b	v8, v1, v0
	ldr	q2, [sp, #1376]                 ; 16-byte Reload
	str	q15, [sp, #1120]                ; 16-byte Spill
	bit.16b	v2, v15, v25
	ldr	q3, [sp, #1360]                 ; 16-byte Reload
	ldr	q1, [sp, #1856]                 ; 16-byte Reload
	bit.16b	v3, v1, v0
	ldr	q15, [sp, #1408]                ; 16-byte Reload
	str	q14, [sp, #1088]                ; 16-byte Spill
	bit.16b	v15, v14, v25
	ldr	q1, [sp, #1392]                 ; 16-byte Reload
	ldr	q5, [sp, #1904]                 ; 16-byte Reload
	bit.16b	v1, v5, v0
	ldr	q5, [sp, #2512]                 ; 16-byte Reload
	ldr	q7, [sp, #1744]                 ; 16-byte Reload
	bit.16b	v5, v7, v25
	str	q5, [sp, #2512]                 ; 16-byte Spill
	ldr	q5, [sp, #2704]                 ; 16-byte Reload
	ldr	q7, [sp, #1888]                 ; 16-byte Reload
	bit.16b	v5, v7, v0
	str	q5, [sp, #2704]                 ; 16-byte Spill
	ldr	q23, [sp, #1632]                ; 16-byte Reload
	ldr	q5, [sp, #1728]                 ; 16-byte Reload
	bit.16b	v23, v5, v25
	mov.16b	v31, v17
	mov.16b	v20, v18
	mov.16b	v22, v30
	mov.16b	v5, v13
	ldr	q13, [sp, #1616]                ; 16-byte Reload
	ldr	q7, [sp, #2432]                 ; 16-byte Reload
	bit.16b	v13, v7, v0
LBB1_107:                               ; %direct.true739.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	d30, x1
	ldr	q7, [sp, #2672]                 ; 16-byte Reload
	orr.16b	v7, v30, v7
	fmov	x2, d7
	add	x2, x8, x2
	ldp	q17, q7, [x2]
	and.16b	v17, v25, v17
	ldr	q18, [sp, #2528]                ; 16-byte Reload
	orr.16b	v18, v30, v18
	fmov	x2, d18
	add	x2, x14, x2
	ldr	q18, [x2]
	ldr	q14, [sp, #2560]                ; 16-byte Reload
	fmul.4s	v17, v14, v17
	and.16b	v18, v25, v18
	ldr	q14, [sp, #2592]                ; 16-byte Reload
	fmul.4s	v18, v14, v18
	fadd.4s	v17, v17, v18
	ldr	q18, [x2, #16]
	and.16b	v7, v0, v7
	ldr	q14, [sp, #2544]                ; 16-byte Reload
	fmul.4s	v7, v14, v7
	and.16b	v18, v0, v18
	ldr	q14, [sp, #2576]                ; 16-byte Reload
	fmul.4s	v18, v14, v18
	fadd.4s	v7, v7, v18
	add	x2, x10, x1
	add	x3, x2, #20, lsl #12            ; =81920
	ldr	q18, [x3, #16]
	and.16b	v18, v0, v18
	ldr	q14, [sp, #2608]                ; 16-byte Reload
	fmul.4s	v18, v14, v18
	fadd.4s	v7, v7, v18
	ldr	q18, [x3]
	and.16b	v18, v25, v18
	ldr	q14, [sp, #2624]                ; 16-byte Reload
	fmul.4s	v18, v14, v18
	fadd.4s	v17, v17, v18
	add	x3, x2, #21, lsl #12            ; =86016
	ldr	q18, [x3]
	and.16b	v18, v25, v18
	ldr	q14, [sp, #2656]                ; 16-byte Reload
	fmul.4s	v18, v14, v18
	fadd.4s	v17, v17, v18
	ldr	q18, [x3, #16]
	and.16b	v18, v0, v18
	ldr	q14, [sp, #2640]                ; 16-byte Reload
	fmul.4s	v18, v14, v18
	fadd.4s	v7, v7, v18
	add	x3, x2, #22, lsl #12            ; =90112
	ldr	q18, [x3, #16]
	and.16b	v18, v0, v18
	fmul.4s	v18, v11, v18
	fadd.4s	v7, v7, v18
	ldr	q18, [x3]
	and.16b	v18, v25, v18
	ldr	q14, [sp, #2688]                ; 16-byte Reload
	fmul.4s	v18, v14, v18
	fadd.4s	v17, v17, v18
	add	x3, x2, #23, lsl #12            ; =94208
	ldr	q18, [x3]
	and.16b	v18, v25, v18
	fmul.4s	v18, v16, v18
	fadd.4s	v17, v17, v18
	ldr	q18, [x3, #16]
	and.16b	v18, v0, v18
	fmul.4s	v18, v24, v18
	fadd.4s	v7, v7, v18
	add	x3, x2, #24, lsl #12            ; =98304
	ldr	q18, [x3, #16]
	and.16b	v18, v0, v18
	fmul.4s	v18, v21, v18
	fadd.4s	v7, v7, v18
	ldr	q18, [x3]
	and.16b	v18, v25, v18
	fmul.4s	v18, v5, v18
	fadd.4s	v17, v17, v18
	add	x3, x2, #25, lsl #12            ; =102400
	ldr	q18, [x3]
	and.16b	v18, v25, v18
	fmul.4s	v18, v20, v18
	fadd.4s	v17, v17, v18
	ldr	q18, [x3, #16]
	and.16b	v18, v0, v18
	fmul.4s	v18, v22, v18
	fadd.4s	v7, v7, v18
	add	x3, x2, #26, lsl #12            ; =106496
	ldr	q18, [x3, #16]
	and.16b	v18, v0, v18
	fmul.4s	v18, v31, v18
	fadd.4s	v7, v7, v18
	ldr	q18, [x3]
	and.16b	v18, v25, v18
	fmul.4s	v18, v19, v18
	fadd.4s	v17, v17, v18
	add	x3, x2, #27, lsl #12            ; =110592
	ldr	q18, [x3]
	and.16b	v18, v25, v18
	fmul.4s	v18, v28, v18
	fadd.4s	v17, v17, v18
	ldr	q18, [x3, #16]
	and.16b	v18, v0, v18
	fmul.4s	v18, v29, v18
	fadd.4s	v7, v7, v18
	add	x3, x2, #28, lsl #12            ; =114688
	ldr	q18, [x3, #16]
	and.16b	v18, v0, v18
	fmul.4s	v18, v27, v18
	fadd.4s	v7, v7, v18
	ldr	q18, [x3]
	and.16b	v18, v25, v18
	fmul.4s	v18, v26, v18
	fadd.4s	v17, v17, v18
	add	x3, x2, #29, lsl #12            ; =118784
	ldr	q18, [x3]
	and.16b	v18, v25, v18
	fmul.4s	v18, v9, v18
	fadd.4s	v17, v17, v18
	ldr	q18, [x3, #16]
	and.16b	v18, v0, v18
	fmul.4s	v18, v10, v18
	fadd.4s	v7, v7, v18
	add	x3, x2, #30, lsl #12            ; =122880
	ldr	q18, [x3, #16]
	and.16b	v18, v0, v18
	fmul.4s	v18, v8, v18
	fadd.4s	v7, v7, v18
	ldr	q18, [x3]
	and.16b	v18, v25, v18
	fmul.4s	v18, v4, v18
	fadd.4s	v17, v17, v18
	add	x3, x2, #31, lsl #12            ; =126976
	ldr	q18, [x3]
	and.16b	v18, v25, v18
	fmul.4s	v18, v2, v18
	fadd.4s	v17, v17, v18
	ldr	q18, [x3, #16]
	and.16b	v18, v0, v18
	fmul.4s	v18, v3, v18
	fadd.4s	v7, v7, v18
	add	x3, x2, #32, lsl #12            ; =131072
	ldr	q18, [x3, #16]
	and.16b	v18, v0, v18
	fmul.4s	v18, v1, v18
	fadd.4s	v7, v7, v18
	ldr	q18, [x3]
	and.16b	v18, v25, v18
	fmul.4s	v18, v15, v18
	fadd.4s	v17, v17, v18
	add	x3, x2, #33, lsl #12            ; =135168
	ldr	q18, [x3]
	and.16b	v18, v25, v18
	ldr	q14, [sp, #2512]                ; 16-byte Reload
	fmul.4s	v18, v14, v18
	fadd.4s	v17, v17, v18
	ldr	q18, [x3, #16]
	and.16b	v18, v0, v18
	ldr	q14, [sp, #2704]                ; 16-byte Reload
	fmul.4s	v18, v14, v18
	fadd.4s	v7, v7, v18
	add	x2, x2, #34, lsl #12            ; =139264
	ldr	q18, [x2, #16]
	and.16b	v18, v0, v18
	fmul.4s	v18, v13, v18
	fadd.4s	v7, v7, v18
	ldr	q18, [x2]
	and.16b	v18, v25, v18
	fmul.4s	v18, v23, v18
	fadd.4s	v17, v17, v18
	orr.16b	v18, v30, v12
	fmov	x2, d18
	add	x2, x15, x2
	ldp	q30, q18, [x2]
	bif.16b	v17, v30, v25
	bif.16b	v7, v18, v0
	stp	q17, q7, [x2]
	add	x1, x1, #32
	cmp	x1, #1, lsl #12                 ; =4096
	b.ne	LBB1_107
; %bb.108:                              ; %direct.true867.i.i.preheader
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q11, [sp, #1600]                ; 16-byte Spill
	ldr	q30, [sp, #2688]                ; 16-byte Reload
	str	q13, [sp, #1616]                ; 16-byte Spill
	str	q23, [sp, #1632]                ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ldr	q11, [sp, #2672]                ; 16-byte Reload
LBB1_109:                               ; %direct.true867.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	d7, x1
	orr.16b	v17, v7, v12
	fmov	x2, d17
	add	x2, x15, x2
	ldp	q17, q18, [x2]
	orr.16b	v7, v7, v11
	fmov	x2, d7
	add	x2, x12, x2
	ldp	q7, q23, [x2]
	bif.16b	v18, v23, v0
	bit.16b	v7, v17, v25
	stp	q7, q18, [x2]
	add	x1, x1, #32
	cmp	x1, #1, lsl #12                 ; =4096
	b.ne	LBB1_109
; %bb.110:                              ; %direct.true883.i.i.preheader
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q12, [sp, #2448]                ; 16-byte Spill
	add	x1, x10, #1, lsl #12            ; =4096
	mov	w2, #128                        ; =0x80
	ldr	q13, [sp, #1184]                ; 16-byte Reload
	str	q15, [sp, #1408]                ; 16-byte Spill
	str	q1, [sp, #1392]                 ; 16-byte Spill
	str	q2, [sp, #1376]                 ; 16-byte Spill
	str	q3, [sp, #1360]                 ; 16-byte Spill
	str	q4, [sp, #1344]                 ; 16-byte Spill
	str	q8, [sp, #1328]                 ; 16-byte Spill
	str	q9, [sp, #1312]                 ; 16-byte Spill
	str	q10, [sp, #1296]                ; 16-byte Spill
	str	q26, [sp, #1280]                ; 16-byte Spill
	str	q27, [sp, #1264]                ; 16-byte Spill
	str	q28, [sp, #1248]                ; 16-byte Spill
	str	q29, [sp, #1232]                ; 16-byte Spill
	str	q19, [sp, #1216]                ; 16-byte Spill
	str	q31, [sp, #1200]                ; 16-byte Spill
	mov.16b	v31, v20
	mov.16b	v20, v22
	mov.16b	v22, v5
	mov.16b	v5, v16
	mov.16b	v16, v24
LBB1_111:                               ; %direct.true883.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q7, [x1, #4096]
	ldr	q17, [x1, #4112]
	ldp	q18, q23, [x1]
	bif.16b	v17, v23, v0
	bif.16b	v7, v18, v25
	stp	q7, q17, [x1], #32
	subs	x2, x2, #1
	b.ne	LBB1_111
; %bb.112:                              ; %direct.false884.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	ldr	q7, [sp, #2480]                 ; 16-byte Reload
	ldr	q1, [sp, #1152]                 ; 16-byte Reload
	bit.16b	v7, v1, v0
	str	q7, [sp, #2480]                 ; 16-byte Spill
	ldr	q7, [sp, #2464]                 ; 16-byte Reload
	ldr	q1, [sp, #1168]                 ; 16-byte Reload
	bit.16b	v7, v1, v25
	str	q7, [sp, #2464]                 ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	ldr	q1, [sp, #1936]                 ; 16-byte Reload
	fadd.4s	v7, v1, v17
	ldr	q1, [sp, #1840]                 ; 16-byte Reload
	fadd.4s	v7, v7, v1
	ldr	q1, [sp, #1920]                 ; 16-byte Reload
	fadd.4s	v17, v1, v17
	ldr	q1, [sp, #1792]                 ; 16-byte Reload
	fadd.4s	v17, v17, v1
	ldp	q1, q2, [sp, #1008]             ; 32-byte Folded Reload
	fadd.4s	v17, v2, v17
	fadd.4s	v7, v1, v7
	ldr	q1, [sp, #992]                  ; 16-byte Reload
	fadd.4s	v7, v1, v7
	ldr	q1, [sp, #1040]                 ; 16-byte Reload
	fadd.4s	v17, v1, v17
	ldr	q1, [sp, #1072]                 ; 16-byte Reload
	fadd.4s	v17, v1, v17
	ldr	q1, [sp, #976]                  ; 16-byte Reload
	fadd.4s	v7, v1, v7
	ldr	q1, [sp, #880]                  ; 16-byte Reload
	fadd.4s	v7, v1, v7
	ldr	q1, [sp, #1104]                 ; 16-byte Reload
	fadd.4s	v17, v1, v17
	ldr	q1, [sp, #1136]                 ; 16-byte Reload
	fadd.4s	v17, v1, v17
	ldp	q1, q2, [sp, #896]              ; 32-byte Folded Reload
	fadd.4s	v7, v2, v7
	fadd.4s	v7, v1, v7
	ldr	q1, [sp, #1776]                 ; 16-byte Reload
	fadd.4s	v17, v1, v17
	ldr	q1, [sp, #1760]                 ; 16-byte Reload
	fadd.4s	v17, v1, v17
	ldp	q1, q2, [sp, #928]              ; 32-byte Folded Reload
	fadd.4s	v7, v2, v7
	fadd.4s	v7, v1, v7
	ldr	q1, [sp, #1824]                 ; 16-byte Reload
	fadd.4s	v17, v1, v17
	ldr	q1, [sp, #1808]                 ; 16-byte Reload
	fadd.4s	v17, v1, v17
	ldr	q1, [sp, #1056]                 ; 16-byte Reload
	fadd.4s	v7, v1, v7
	ldr	q1, [sp, #960]                  ; 16-byte Reload
	fadd.4s	v7, v1, v7
	ldr	q1, [sp, #1872]                 ; 16-byte Reload
	fadd.4s	v17, v1, v17
	ldr	q1, [sp, #1856]                 ; 16-byte Reload
	fadd.4s	v17, v1, v17
	ldr	q1, [sp, #1120]                 ; 16-byte Reload
	fadd.4s	v7, v1, v7
	ldr	q1, [sp, #1088]                 ; 16-byte Reload
	fadd.4s	v7, v1, v7
	ldr	q1, [sp, #1904]                 ; 16-byte Reload
	fadd.4s	v17, v1, v17
	ldr	q1, [sp, #1888]                 ; 16-byte Reload
	fadd.4s	v17, v1, v17
	ldr	q1, [sp, #1744]                 ; 16-byte Reload
	fadd.4s	v7, v1, v7
	ldr	q1, [sp, #1728]                 ; 16-byte Reload
	fadd.4s	v7, v1, v7
	ldr	q1, [sp, #2432]                 ; 16-byte Reload
	fadd.4s	v17, v1, v17
	ldr	q12, [sp, #1712]                ; 16-byte Reload
	ldp	q2, q1, [sp, #848]              ; 32-byte Folded Reload
	fmul.4s	v18, v12, v2
	fmul.4s	v23, v13, v1
	fadd.4s	v17, v23, v17
	fadd.4s	v7, v18, v7
	bit.16b	v12, v7, v25
	str	q12, [sp, #1712]                ; 16-byte Spill
	bit.16b	v13, v17, v0
	add	x0, x0, #1
	cmp	x0, #513
	ldr	q12, [sp, #2448]                ; 16-byte Reload
	ldr	q17, [sp, #2704]                ; 16-byte Reload
	ldr	q14, [sp, #2160]                ; 16-byte Reload
	ldr	q15, [sp, #2144]                ; 16-byte Reload
	ldr	q1, [sp, #2128]                 ; 16-byte Reload
	ldr	q2, [sp, #2112]                 ; 16-byte Reload
	ldr	q3, [sp, #2096]                 ; 16-byte Reload
	ldr	q4, [sp, #2080]                 ; 16-byte Reload
	ldr	q8, [sp, #2064]                 ; 16-byte Reload
	ldr	q9, [sp, #2048]                 ; 16-byte Reload
	ldr	q10, [sp, #2032]                ; 16-byte Reload
	ldr	q26, [sp, #2016]                ; 16-byte Reload
	ldr	q27, [sp, #2000]                ; 16-byte Reload
	ldr	q28, [sp, #1984]                ; 16-byte Reload
	ldr	q29, [sp, #1968]                ; 16-byte Reload
	ldr	q19, [sp, #1952]                ; 16-byte Reload
	b.ne	LBB1_34
; %bb.113:                              ; %direct.true902.i.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x10, #0                         ; =0x0
	ldr	q17, [sp, #112]                 ; 16-byte Reload
	ldp	q7, q6, [sp, #48]               ; 32-byte Folded Reload
	ldp	q18, q16, [sp, #16]             ; 32-byte Folded Reload
	ldr	q21, [sp, #1712]                ; 16-byte Reload
	b	LBB1_115
LBB1_114:                               ; %else388
                                        ;   in Loop: Header=BB1_115 Depth=2
	add	x10, x10, #4
	add	x8, x8, #32
	cmp	x10, #512
	b.eq	LBB1_2
LBB1_115:                               ; %direct.true902.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	uzp1.8h	v1, v25, v0
	and.16b	v1, v1, v17
	addv.8h	h1, v1
	fmov	w11, s1
	ldp	q1, q3, [x8]
	and.16b	v1, v25, v1
	fdiv.4s	v4, v1, v21
	dup.2d	v1, x10
	add.2d	v5, v1, v18
	dup.2d	v2, x9
	add.2d	v5, v2, v5
	tbnz	w11, #0, LBB1_123
; %bb.116:                              ; %else367
                                        ;   in Loop: Header=BB1_115 Depth=2
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB1_124
LBB1_117:                               ; %else370
                                        ;   in Loop: Header=BB1_115 Depth=2
	add.2d	v5, v1, v7
	add.2d	v5, v2, v5
	tbnz	w11, #2, LBB1_125
LBB1_118:                               ; %else373
                                        ;   in Loop: Header=BB1_115 Depth=2
	tbnz	w11, #3, LBB1_126
LBB1_119:                               ; %else376
                                        ;   in Loop: Header=BB1_115 Depth=2
	and.16b	v3, v0, v3
	fdiv.4s	v3, v3, v13
	add.2d	v4, v1, v16
	add.2d	v4, v2, v4
	tbnz	w11, #4, LBB1_127
LBB1_120:                               ; %else379
                                        ;   in Loop: Header=BB1_115 Depth=2
	tbnz	w11, #5, LBB1_128
LBB1_121:                               ; %else382
                                        ;   in Loop: Header=BB1_115 Depth=2
	add.2d	v1, v1, v6
	add.2d	v1, v2, v1
	tbnz	w11, #6, LBB1_129
LBB1_122:                               ; %else385
                                        ;   in Loop: Header=BB1_115 Depth=2
	tbz	w11, #7, LBB1_114
	b	LBB1_130
LBB1_123:                               ; %cond.store
                                        ;   in Loop: Header=BB1_115 Depth=2
	fmov	x12, d5
	str	s4, [x12]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB1_117
LBB1_124:                               ; %cond.store368
                                        ;   in Loop: Header=BB1_115 Depth=2
	mov.d	x12, v5[1]
	st1.s	{ v4 }[1], [x12]
	add.2d	v5, v1, v7
	add.2d	v5, v2, v5
	tbz	w11, #2, LBB1_118
LBB1_125:                               ; %cond.store371
                                        ;   in Loop: Header=BB1_115 Depth=2
	fmov	x12, d5
	st1.s	{ v4 }[2], [x12]
	tbz	w11, #3, LBB1_119
LBB1_126:                               ; %cond.store374
                                        ;   in Loop: Header=BB1_115 Depth=2
	mov.d	x12, v5[1]
	st1.s	{ v4 }[3], [x12]
	and.16b	v3, v0, v3
	fdiv.4s	v3, v3, v13
	add.2d	v4, v1, v16
	add.2d	v4, v2, v4
	tbz	w11, #4, LBB1_120
LBB1_127:                               ; %cond.store377
                                        ;   in Loop: Header=BB1_115 Depth=2
	fmov	x12, d4
	str	s3, [x12]
	tbz	w11, #5, LBB1_121
LBB1_128:                               ; %cond.store380
                                        ;   in Loop: Header=BB1_115 Depth=2
	mov.d	x12, v4[1]
	st1.s	{ v3 }[1], [x12]
	add.2d	v1, v1, v6
	add.2d	v1, v2, v1
	tbz	w11, #6, LBB1_122
LBB1_129:                               ; %cond.store383
                                        ;   in Loop: Header=BB1_115 Depth=2
	fmov	x12, d1
	st1.s	{ v3 }[2], [x12]
	tbz	w11, #7, LBB1_114
LBB1_130:                               ; %cond.store386
                                        ;   in Loop: Header=BB1_115 Depth=2
	mov.d	x11, v1[1]
	st1.s	{ v3 }[3], [x11]
	b	LBB1_114
LBB1_131:
	add	sp, sp, #2960
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
LBB1_132:                               ; %block.batch.exit
	ret
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh10, Lloh11
                                        ; -- End function
.subsections_via_symbols

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/Users/mike/CLionProjects/luisa')
OUT = Path(__file__).resolve().parent
BUILD = Path('/tmp/luisa-next-integration.roZbN8/build')
RUNNER = ROOT / 'scripts/benchmark/tile_torch/native_tile.py'
CASES = [
    ('decode', (1, 8, 2, 1, 2053, 80, 96), (1, 16)),
    ('prefill', (1, 4, 2, 32, 65, 32, 32), (4, 16)),
    ('decode-tail', (1, 6, 2, 1, 2053, 80, 96), (1, 16)),
    ('small-triangular', (1, 2, 2, 5, 5, 5, 3), (2, 3)),
]
HELDOUT = [
    ('heldout-mha', (1, 8, 8, 1, 2048, 64, 64), (1, 16)),
    ('heldout-mqa-batch', (2, 8, 1, 1, 2053, 80, 96), (1, 16)),
    ('heldout-mixed-tail', (1, 10, 2, 1, 2053, 80, 96), (1, 16)),
    ('heldout-long-kv', (1, 16, 4, 1, 8193, 128, 128), (1, 16)),
    ('heldout-small-q', (1, 8, 2, 3, 67, 80, 96), (1, 16)),
    ('heldout-triangular', (1, 4, 2, 65, 65, 64, 64), (1, 16)),
]


def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def run(command, folder, stem, env=None):
    started = time.time()
    record = dict(command=list(map(str, command)), started=started,
                  environment={k: v for k, v in (env or {}).items() if k.startswith('LUISA_')})
    save(folder / (stem + '.command.json'), record)
    try:
        process = subprocess.run(command, env=env, capture_output=True, timeout=60)
        (folder / (stem + '.stdout')).write_bytes(process.stdout)
        (folder / (stem + '.stderr')).write_bytes(process.stderr)
        record.update(returncode=process.returncode, elapsed=time.time()-started)
        save(folder / (stem + '.command.json'), record)
        process.check_returncode()
        return process.stdout
    except subprocess.TimeoutExpired as error:
        (folder / (stem + '.stdout')).write_bytes(error.stdout or b'')
        (folder / (stem + '.stderr')).write_bytes(error.stderr or b'')
        record.update(error='timeout', elapsed=time.time()-started)
        save(folder / (stem + '.command.json'), record)
        raise


def capture(cases, label):
    save(OUT / ('cases-' + label + '.json'), cases)
    for case, dims, block in cases:
        for flag in ('off', 'on'):
            name = case + '-' + flag
            folder = OUT / name
            folder.mkdir()
            prefix = folder / 'output.f32'
            env = {k: v for k, v in os.environ.items() if not k.startswith(('LUISA_', 'MTL_'))}
            env.update(LUISA_TILE_BENCH_XIR_BACKEND='simd', LUISA_TILE_BENCH_ATTENTION_QK='mma',
                       LUISA_TILE_BENCH_ATTENTION_PV='mma', LUISA_TILE_BENCH_DUMP_SOURCE=str(prefix)+'.source.txt',
                       LUISA_SIMD_DUMP_ASSEMBLY_DIR=str(folder/'objects'))
            env['LUISA_SIMD_' + ('ENABLE' if flag == 'on' else 'DISABLE') + '_FULL_PACKET_SPECIALIZATION'] = '1'
            cmd = [str(BUILD/'bin/benchmark_tile_xir'), 'llm', 'attention', ','.join(map(str, dims)),
                   *map(str, block), '3', '1', '1', str(prefix)]
            data = run(cmd, folder, 'capture', env)
            metadata = json.loads(data)
            assert metadata['attention_qk'] == metadata['attention_pv'] == 'mma'
            cmd = [sys.executable, str(RUNNER), 'prepare', '--capture-kind', 'llm', '--llvm', '/opt/homebrew/opt/llvm/bin',
                   '--prefix', str(prefix), '--log', str(folder/'capture.stdout'), '--objects', str(folder/'objects'),
                   '--output', str(OUT/('prepared-'+name)), '--name', flag]
            run(cmd, folder, 'prepare')
            print(name, metadata['realization'].split('full_packet_specializations=')[-1], flush=True)


def replay(cases, label):
    record = dict(started=time.time(), load_before=os.getloadavg(), experiments=[])
    for case, dims, block in cases:
        cmd = [sys.executable, str(RUNNER), 'replay', '--prepared', str(OUT/f'prepared-{case}-off/prepared.json'),
               '--prepared', str(OUT/f'prepared-{case}-on/prepared.json'), '--output', str(OUT/('replay-'+case)),
               '--cycles', '3', '--samples', '7', '--warmup-ms', '30', '--target-ms', '15']
        run(cmd, OUT, 'replay-'+case)
        record['experiments'].append(dict(case=case, dimensions=dims, block=block, command=cmd))
        save(OUT/('replays-' + label + '.json'), record)
        print(case, 'replayed', flush=True)
    record.update(finished=time.time(), load_after=os.getloadavg())
    save(OUT/('replays-' + label + '.json'), record)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('phase', choices=['capture', 'replay'])
    parser.add_argument('--heldout', action='store_true')
    args = parser.parse_args()
    (capture if args.phase == 'capture' else replay)(HELDOUT if args.heldout else CASES, 'heldout' if args.heldout else 'screen')

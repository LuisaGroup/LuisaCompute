	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_3:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_4:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_5:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention:                         ; @llm_attention
; %bb.0:                                ; %prologue
	dup.4s	v2, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q3, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q4, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v0, v2, v4
	cmhi.4s	v1, v2, v3
	uzp1.8h	v17, v1, v0
	umaxv.8h	h5, v17
	fmov	w8, s5
	tbz	w8, #0, LBB0_120
; %bb.1:                                ; %direct.activate
	stp	d15, d14, [sp, #-144]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	sub	sp, sp, #2960
	mov	x2, #0                          ; =0x0
	ldr	x10, [x1, #136]
	add	x11, x10, #35, lsl #12          ; =143360
	add	x8, x10, #1, lsl #12            ; =4096
	add	x12, x10, #2, lsl #12           ; =8192
	add	x13, x10, #3, lsl #12           ; =12288
	add	x14, x10, #19, lsl #12          ; =77824
	add	x9, x10, #35, lsl #12           ; =143360
	add	x15, x9, #1024
	ldr	x3, [x0]
	ldr	x16, [x0, #16]
	ldr	w9, [x1]
	ldr	w17, [x1, #36]
	add	w1, w17, w9, lsl #5
	ldr	x17, [x0, #32]
	ldr	x9, [x0, #48]
	dup.4s	v5, w1
	add.4s	v6, v5, v4
	add.4s	v5, v5, v3
	and.16b	v18, v1, v5
	and.16b	v19, v0, v6
	ushll2.2d	v5, v19, #0
	ushll2.2d	v6, v18, #0
	ushll.2d	v7, v19, #0
	ushll.2d	v16, v18, #0
	ushll2.2d	v22, v19, #9
	ushll2.2d	v23, v18, #9
	ushll.2d	v24, v19, #9
	ushll.2d	v25, v18, #9
Lloh4:
	adrp	x0, lCPI0_2@PAGE
Lloh5:
	ldr	q18, [x0, lCPI0_2@PAGEOFF]
	and.16b	v17, v17, v18
	addv.8h	h17, v17
	str	q17, [sp, #2432]                ; 16-byte Spill
	fmov	w0, s17
	dup.2d	v17, x3
	mov	x1, x10
	b	LBB0_3
LBB0_2:                                 ; %else212
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldp	q20, q21, [x1]
	bif.16b	v19, v21, v0
	bif.16b	v18, v20, v1
	stp	q18, q19, [x1], #32
	add	x2, x2, #4
	cmp	x2, #512
	b.eq	LBB0_19
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v20, x2
	add.2d	v18, v20, v25
	add.2d	v21, v17, v18
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	tbz	w0, #0, LBB0_11
; %bb.4:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x3, d21
	ldr	s18, [x3]
	and	w3, w0, #0xff
	tbnz	w3, #1, LBB0_12
LBB0_5:                                 ; %else194
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v21, v20, v23
	add.2d	v21, v17, v21
	tbz	w3, #2, LBB0_13
LBB0_6:                                 ; %cond.load196
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x4, d21
	ld1.s	{ v18 }[2], [x4]
	tbnz	w3, #3, LBB0_14
LBB0_7:                                 ; %else200
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v21, v20, v24
	add.2d	v21, v17, v21
	tbz	w3, #4, LBB0_15
LBB0_8:                                 ; %cond.load202
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x4, d21
	ld1.s	{ v19 }[0], [x4]
	tbnz	w3, #5, LBB0_16
LBB0_9:                                 ; %else206
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v20, v20, v22
	add.2d	v20, v17, v20
	tbz	w3, #6, LBB0_17
LBB0_10:                                ; %cond.load208
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x4, d20
	ld1.s	{ v19 }[2], [x4]
	tbz	w3, #7, LBB0_2
	b	LBB0_18
LBB0_11:                                ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w3, w0, #0xff
	tbz	w3, #1, LBB0_5
LBB0_12:                                ; %cond.load193
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x4, v21[1]
	ld1.s	{ v18 }[1], [x4]
	add.2d	v21, v20, v23
	add.2d	v21, v17, v21
	tbnz	w3, #2, LBB0_6
LBB0_13:                                ; %else197
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w3, #3, LBB0_7
LBB0_14:                                ; %cond.load199
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x4, v21[1]
	ld1.s	{ v18 }[3], [x4]
	add.2d	v21, v20, v24
	add.2d	v21, v17, v21
	tbnz	w3, #4, LBB0_8
LBB0_15:                                ; %else203
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w3, #5, LBB0_9
LBB0_16:                                ; %cond.load205
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x4, v21[1]
	ld1.s	{ v19 }[1], [x4]
	add.2d	v20, v20, v22
	add.2d	v20, v17, v20
	tbnz	w3, #6, LBB0_10
LBB0_17:                                ; %else209
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w3, #7, LBB0_2
LBB0_18:                                ; %cond.load211
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x3, v20[1]
	ld1.s	{ v19 }[3], [x3]
	b	LBB0_2
LBB0_19:                                ; %direct.true166.preheader
	stp	q25, q24, [sp]                  ; 32-byte Folded Spill
	stp	q23, q22, [sp, #32]             ; 32-byte Folded Spill
	mov	x0, #0                          ; =0x0
	cmhs.4s	v12, v4, v2
	cmhs.4s	v10, v3, v2
LBB0_20:                                ; %direct.true166
                                        ; =>This Inner Loop Header: Depth=1
	add	x1, x8, x0
	ldp	q2, q3, [x1]
	and.16b	v3, v12, v3
	and.16b	v2, v10, v2
	stp	q2, q3, [x1]
	add	x0, x0, #32
	cmp	x0, #1, lsl #12                 ; =4096
	b.ne	LBB0_20
; %bb.21:                               ; %direct.false167
	mov	x0, #0                          ; =0x0
	sshll.2d	v2, v1, #0
	sshll.2d	v3, v0, #0
	sshll2.2d	v17, v1, #0
	sshll2.2d	v18, v0, #0
	ushr.2d	v4, v16, #2
	ushr.2d	v6, v6, #2
	ushr.2d	v7, v7, #2
	ushr.2d	v5, v5, #2
Lloh6:
	adrp	x1, lCPI0_6@PAGE
Lloh7:
	ldr	q16, [x1, lCPI0_6@PAGEOFF]
	str	q16, [sp, #1664]                ; 16-byte Spill
	and.16b	v16, v2, v16
	str	q16, [sp, #2608]                ; 16-byte Spill
	mov	w1, #62154                      ; =0xf2ca
	movk	w1, #61769, lsl #16
	dup.4s	v16, w1
	and.16b	v19, v0, v16
	str	q19, [sp, #2416]                ; 16-byte Spill
	mov.d	x1, v5[1]
	fmov	x2, d5
	add	x2, x2, x2, lsl #13
	fmov	d5, x2
	add	x1, x1, x1, lsl #13
	mov.d	v5[1], x1
	mov.d	x1, v7[1]
	fmov	x2, d7
	add	x2, x2, x2, lsl #13
	fmov	d7, x2
	add	x1, x1, x1, lsl #13
	mov.d	v7[1], x1
	mov.d	x1, v6[1]
	fmov	x2, d6
	add	x2, x2, x2, lsl #13
	fmov	d6, x2
	add	x1, x1, x1, lsl #13
	mov.d	v6[1], x1
	str	q16, [sp, #112]                 ; 16-byte Spill
	and.16b	v16, v1, v16
	str	q16, [sp, #2400]                ; 16-byte Spill
	mov.d	x1, v4[1]
	fmov	x2, d4
	add	x2, x2, x2, lsl #13
	fmov	d4, x2
	add	x1, x1, x1, lsl #13
	mov.d	v4[1], x1
	and.16b	v2, v2, v4
	str	q2, [sp, #2832]                 ; 16-byte Spill
	str	q17, [sp, #2864]                ; 16-byte Spill
	and.16b	v2, v17, v6
	str	q2, [sp, #2816]                 ; 16-byte Spill
	and.16b	v2, v3, v7
	str	q2, [sp, #2800]                 ; 16-byte Spill
	str	q18, [sp, #2848]                ; 16-byte Spill
	and.16b	v2, v18, v5
	str	q2, [sp, #2784]                 ; 16-byte Spill
	mvni.4s	v2, #63, msl #16
	fneg.4s	v2, v2
	str	q2, [sp, #96]                   ; 16-byte Spill
	movi.2d	v2, #0000000000000000
	str	q2, [sp, #2592]                 ; 16-byte Spill
	str	q2, [sp, #1648]                 ; 16-byte Spill
	str	q2, [sp, #1632]                 ; 16-byte Spill
	str	q2, [sp, #1616]                 ; 16-byte Spill
	str	q2, [sp, #1600]                 ; 16-byte Spill
	str	q2, [sp, #1584]                 ; 16-byte Spill
	str	q2, [sp, #1328]                 ; 16-byte Spill
Lloh8:
	adrp	x1, lCPI0_3@PAGE
Lloh9:
	ldr	q4, [x1, lCPI0_3@PAGEOFF]
	str	q2, [sp, #1568]                 ; 16-byte Spill
	str	q2, [sp, #1312]                 ; 16-byte Spill
Lloh10:
	adrp	x1, lCPI0_4@PAGE
Lloh11:
	ldr	q13, [x1, lCPI0_4@PAGEOFF]
	str	q2, [sp, #1552]                 ; 16-byte Spill
	str	q2, [sp, #1296]                 ; 16-byte Spill
Lloh12:
	adrp	x1, lCPI0_5@PAGE
Lloh13:
	ldr	q31, [x1, lCPI0_5@PAGEOFF]
	mov	w1, #1267                       ; =0x4f3
	movk	w1, #15797, lsl #16
	mov	w2, #-1026555904                ; =0xc2d00000
	mov	w3, #1120403456                 ; =0x42c80000
	mov	w4, #43579                      ; =0xaa3b
	movk	w4, #16312, lsl #16
	mov	w5, #29184                      ; =0x7200
	movk	w5, #16177, lsl #16
	mov	w6, #48782                      ; =0xbe8e
	movk	w6, #13759, lsl #16
	mov	w7, #11226                      ; =0x2bda
	movk	w7, #14672, lsl #16
	mov	w19, #38601                     ; =0x96c9
	movk	w19, #15030, lsl #16
	mov	w20, #34982                     ; =0x88a6
	movk	w20, #15368, lsl #16
	mov	w21, #43642                     ; =0xaa7a
	movk	w21, #15658, lsl #16
	mov	w22, #43691                     ; =0xaaab
	movk	w22, #15914, lsl #16
	str	q2, [sp, #1520]                 ; 16-byte Spill
	str	q2, [sp, #2448]                 ; 16-byte Spill
	movi.2d	v15, #0000000000000000
	str	q2, [sp, #1280]                 ; 16-byte Spill
	str	q2, [sp, #1264]                 ; 16-byte Spill
	str	q2, [sp, #1248]                 ; 16-byte Spill
	str	q2, [sp, #1232]                 ; 16-byte Spill
	str	q2, [sp, #1216]                 ; 16-byte Spill
	str	q2, [sp, #1200]                 ; 16-byte Spill
	str	q2, [sp, #1184]                 ; 16-byte Spill
	str	q2, [sp, #1168]                 ; 16-byte Spill
	str	q2, [sp, #1152]                 ; 16-byte Spill
	str	q2, [sp, #1136]                 ; 16-byte Spill
	str	q2, [sp, #1120]                 ; 16-byte Spill
	str	q2, [sp, #1104]                 ; 16-byte Spill
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v6, #0000000000000000
	str	q6, [sp, #1504]                 ; 16-byte Spill
	movi.2d	v8, #0000000000000000
	str	q6, [sp, #2576]                 ; 16-byte Spill
	str	q6, [sp, #2560]                 ; 16-byte Spill
	str	q6, [sp, #2544]                 ; 16-byte Spill
	str	q6, [sp, #2528]                 ; 16-byte Spill
	str	q6, [sp, #2512]                 ; 16-byte Spill
	str	q6, [sp, #2496]                 ; 16-byte Spill
	str	q6, [sp, #2480]                 ; 16-byte Spill
	str	q6, [sp, #1488]                 ; 16-byte Spill
	str	q6, [sp, #1472]                 ; 16-byte Spill
	movi.2d	v3, #0000000000000000
	str	q3, [sp, #1456]                 ; 16-byte Spill
	str	q3, [sp, #1440]                 ; 16-byte Spill
	movi.2d	v5, #0000000000000000
	str	q6, [sp, #2368]                 ; 16-byte Spill
	str	q6, [sp, #2352]                 ; 16-byte Spill
	movi.2d	v22, #0000000000000000
	str	q6, [sp, #2336]                 ; 16-byte Spill
	str	q6, [sp, #2320]                 ; 16-byte Spill
	str	q6, [sp, #2304]                 ; 16-byte Spill
	movi.2d	v23, #0000000000000000
	str	q6, [sp, #2288]                 ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q2, [sp, #2272]                 ; 16-byte Spill
	str	q6, [sp, #2256]                 ; 16-byte Spill
	movi.2d	v9, #0000000000000000
	str	q6, [sp, #2240]                 ; 16-byte Spill
	movi.2d	v24, #0000000000000000
	str	q6, [sp, #2224]                 ; 16-byte Spill
	movi.2d	v25, #0000000000000000
	str	q6, [sp, #2208]                 ; 16-byte Spill
	movi.2d	v26, #0000000000000000
	str	q6, [sp, #2192]                 ; 16-byte Spill
	movi.2d	v27, #0000000000000000
	str	q6, [sp, #2176]                 ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q6, [sp, #2160]                 ; 16-byte Spill
	movi.2d	v18, #0000000000000000
	str	q6, [sp, #2144]                 ; 16-byte Spill
	movi.2d	v11, #0000000000000000
	str	q6, [sp, #2128]                 ; 16-byte Spill
	str	q6, [sp, #2768]                 ; 16-byte Spill
	str	q6, [sp, #2752]                 ; 16-byte Spill
	str	q6, [sp, #2736]                 ; 16-byte Spill
	str	q6, [sp, #2928]                 ; 16-byte Spill
	str	q6, [sp, #2912]                 ; 16-byte Spill
	str	q6, [sp, #2720]                 ; 16-byte Spill
	str	q6, [sp, #2464]                 ; 16-byte Spill
	str	q6, [sp, #1424]                 ; 16-byte Spill
	str	q6, [sp, #1408]                 ; 16-byte Spill
	str	q6, [sp, #1392]                 ; 16-byte Spill
	str	q6, [sp, #2704]                 ; 16-byte Spill
	str	q6, [sp, #2688]                 ; 16-byte Spill
	str	q6, [sp, #2672]                 ; 16-byte Spill
	str	q6, [sp, #2896]                 ; 16-byte Spill
	str	q6, [sp, #2880]                 ; 16-byte Spill
	str	q6, [sp, #2656]                 ; 16-byte Spill
	str	q6, [sp, #1376]                 ; 16-byte Spill
	movi.2d	v20, #0000000000000000
	str	q6, [sp, #1360]                 ; 16-byte Spill
	str	q6, [sp, #1344]                 ; 16-byte Spill
	str	q6, [sp, #1696]                 ; 16-byte Spill
	str	q6, [sp, #1680]                 ; 16-byte Spill
	stp	q10, q12, [sp, #128]            ; 32-byte Folded Spill
	stp	q13, q4, [sp, #64]              ; 32-byte Folded Spill
	str	q31, [sp, #1536]                ; 16-byte Spill
LBB0_22:                                ; %direct.true176
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_24 Depth 2
                                        ;     Child Loop BB0_43 Depth 2
                                        ;     Child Loop BB0_61 Depth 2
                                        ;     Child Loop BB0_63 Depth 2
                                        ;     Child Loop BB0_65 Depth 2
                                        ;     Child Loop BB0_67 Depth 2
                                        ;     Child Loop BB0_69 Depth 2
                                        ;     Child Loop BB0_71 Depth 2
                                        ;     Child Loop BB0_73 Depth 2
                                        ;     Child Loop BB0_75 Depth 2
                                        ;     Child Loop BB0_77 Depth 2
                                        ;     Child Loop BB0_79 Depth 2
                                        ;     Child Loop BB0_81 Depth 2
                                        ;     Child Loop BB0_83 Depth 2
                                        ;     Child Loop BB0_85 Depth 2
                                        ;     Child Loop BB0_87 Depth 2
                                        ;     Child Loop BB0_89 Depth 2
                                        ;     Child Loop BB0_91 Depth 2
                                        ;     Child Loop BB0_93 Depth 2
                                        ;     Child Loop BB0_95 Depth 2
                                        ;     Child Loop BB0_97 Depth 2
                                        ;     Child Loop BB0_99 Depth 2
	str	q15, [sp, #2624]                ; 16-byte Spill
	str	q8, [sp, #2640]                 ; 16-byte Spill
	mov	x24, #0                         ; =0x0
	lsl	x23, x0, #4
	ldr	q12, [sp, #2320]                ; 16-byte Reload
	b	LBB0_24
LBB0_23:                                ; %direct.schedule.12
                                        ;   in Loop: Header=BB0_24 Depth=2
	str	q15, [sp, #2656]                ; 16-byte Spill
	str	q29, [sp, #2672]                ; 16-byte Spill
	ldr	q6, [sp, #2688]                 ; 16-byte Reload
	bit.16b	v6, v8, v0
	str	q6, [sp, #2688]                 ; 16-byte Spill
	ldr	q6, [sp, #2704]                 ; 16-byte Reload
	bit.16b	v6, v21, v1
	str	q6, [sp, #2704]                 ; 16-byte Spill
	add	x25, x13, x24, lsl #5
	ldp	q6, q10, [x25]
	bif.16b	v8, v10, v0
	bit.16b	v6, v21, v1
	stp	q6, q8, [x25]
	add	x24, x24, #1
	cmp	x24, #2048
	b.eq	LBB0_41
LBB0_24:                                ; %direct.true180
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v6, v1, #0
	sshll.2d	v21, v0, #0
	and	x25, x24, #0x7f
	orr	x26, x23, x24, lsr #7
	dup.2d	v8, x26
	ldr	q28, [sp, #2784]                ; 16-byte Reload
	add.2d	v10, v8, v28
	ldr	q28, [sp, #2832]                ; 16-byte Reload
	add.2d	v15, v8, v28
	ldr	q28, [sp, #2816]                ; 16-byte Reload
	add.2d	v28, v8, v28
	ldr	q29, [sp, #2800]                ; 16-byte Reload
	add.2d	v8, v8, v29
	shl.2d	v8, v8, #7
	shl.2d	v28, v28, #7
	shl.2d	v15, v15, #7
	dup.2d	v29, x25
	shl.2d	v10, v10, #7
	orr.16b	v10, v10, v29
	orr.16b	v15, v15, v29
	orr.16b	v28, v28, v29
	orr.16b	v29, v8, v29
	ldr	q8, [sp, #2880]                 ; 16-byte Reload
	bit.16b	v8, v29, v21
	str	q8, [sp, #2880]                 ; 16-byte Spill
	ldr	q21, [sp, #2864]                ; 16-byte Reload
	ldr	q29, [sp, #2896]                ; 16-byte Reload
	bit.16b	v29, v28, v21
	str	q29, [sp, #2896]                ; 16-byte Spill
	ldr	q29, [sp, #2672]                ; 16-byte Reload
	bit.16b	v29, v15, v6
	ldr	q6, [sp, #2848]                 ; 16-byte Reload
	ldr	q15, [sp, #2656]                ; 16-byte Reload
	bit.16b	v15, v10, v6
	movi.2d	v21, #0000000000000000
	movi.2d	v8, #0000000000000000
	cmp	x26, #2, lsl #12                ; =8192
	b.hi	LBB0_23
; %bb.25:                               ; %direct.true193
                                        ;   in Loop: Header=BB0_24 Depth=2
	ldr	q6, [sp, #2432]                 ; 16-byte Reload
	fmov	w25, s6
	shl.2d	v21, v29, #2
	dup.2d	v6, x16
	add.2d	v10, v6, v21
	movi.2d	v21, #0000000000000000
	tbz	w25, #0, LBB0_33
; %bb.26:                               ; %cond.load215
                                        ;   in Loop: Header=BB0_24 Depth=2
	fmov	x26, d10
	ldr	s21, [x26]
	and	w25, w25, #0xff
	tbnz	w25, #1, LBB0_34
LBB0_27:                                ; %else225
                                        ;   in Loop: Header=BB0_24 Depth=2
	ldr	q28, [sp, #2896]                ; 16-byte Reload
	shl.2d	v28, v28, #2
	add.2d	v10, v6, v28
	tbz	w25, #2, LBB0_35
LBB0_28:                                ; %cond.load227
                                        ;   in Loop: Header=BB0_24 Depth=2
	fmov	x26, d10
	ld1.s	{ v21 }[2], [x26]
	tbnz	w25, #3, LBB0_36
LBB0_29:                                ; %else237
                                        ;   in Loop: Header=BB0_24 Depth=2
	ldr	q28, [sp, #2880]                ; 16-byte Reload
	shl.2d	v28, v28, #2
	add.2d	v10, v6, v28
	tbz	w25, #4, LBB0_37
LBB0_30:                                ; %cond.load239
                                        ;   in Loop: Header=BB0_24 Depth=2
	fmov	x26, d10
	ld1.s	{ v8 }[0], [x26]
	tbnz	w25, #5, LBB0_38
LBB0_31:                                ; %else249
                                        ;   in Loop: Header=BB0_24 Depth=2
	shl.2d	v28, v15, #2
	add.2d	v6, v6, v28
	tbz	w25, #6, LBB0_39
LBB0_32:                                ; %cond.load251
                                        ;   in Loop: Header=BB0_24 Depth=2
	fmov	x26, d6
	ld1.s	{ v8 }[2], [x26]
	tbz	w25, #7, LBB0_23
	b	LBB0_40
LBB0_33:                                ; %else219
                                        ;   in Loop: Header=BB0_24 Depth=2
	and	w25, w25, #0xff
	tbz	w25, #1, LBB0_27
LBB0_34:                                ; %cond.load221
                                        ;   in Loop: Header=BB0_24 Depth=2
	mov.d	x26, v10[1]
	ld1.s	{ v21 }[1], [x26]
	ldr	q28, [sp, #2896]                ; 16-byte Reload
	shl.2d	v28, v28, #2
	add.2d	v10, v6, v28
	tbnz	w25, #2, LBB0_28
LBB0_35:                                ; %else231
                                        ;   in Loop: Header=BB0_24 Depth=2
	tbz	w25, #3, LBB0_29
LBB0_36:                                ; %cond.load233
                                        ;   in Loop: Header=BB0_24 Depth=2
	mov.d	x26, v10[1]
	ld1.s	{ v21 }[3], [x26]
	ldr	q28, [sp, #2880]                ; 16-byte Reload
	shl.2d	v28, v28, #2
	add.2d	v10, v6, v28
	tbnz	w25, #4, LBB0_30
LBB0_37:                                ; %else243
                                        ;   in Loop: Header=BB0_24 Depth=2
	tbz	w25, #5, LBB0_31
LBB0_38:                                ; %cond.load245
                                        ;   in Loop: Header=BB0_24 Depth=2
	mov.d	x26, v10[1]
	ld1.s	{ v8 }[1], [x26]
	shl.2d	v28, v15, #2
	add.2d	v6, v6, v28
	tbnz	w25, #6, LBB0_32
LBB0_39:                                ; %else255
                                        ;   in Loop: Header=BB0_24 Depth=2
	tbz	w25, #7, LBB0_23
LBB0_40:                                ; %cond.load257
                                        ;   in Loop: Header=BB0_24 Depth=2
	mov.d	x25, v6[1]
	ld1.s	{ v8 }[3], [x25]
	b	LBB0_23
LBB0_41:                                ; %direct.true205.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x24, #0                         ; =0x0
	b	LBB0_43
LBB0_42:                                ; %direct.schedule.17
                                        ;   in Loop: Header=BB0_43 Depth=2
	str	q29, [sp, #2720]                ; 16-byte Spill
	str	q15, [sp, #2736]                ; 16-byte Spill
	ldr	q6, [sp, #2752]                 ; 16-byte Reload
	bit.16b	v6, v8, v0
	str	q6, [sp, #2752]                 ; 16-byte Spill
	ldr	q6, [sp, #2768]                 ; 16-byte Reload
	bit.16b	v6, v21, v1
	str	q6, [sp, #2768]                 ; 16-byte Spill
	add	x25, x14, x24, lsl #5
	ldp	q6, q10, [x25]
	bif.16b	v8, v10, v0
	bit.16b	v6, v21, v1
	stp	q6, q8, [x25]
	add	x24, x24, #1
	cmp	x24, #2048
	b.eq	LBB0_60
LBB0_43:                                ; %direct.true205
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v6, v1, #0
	sshll.2d	v21, v0, #0
	and	x25, x24, #0x7f
	orr	x26, x23, x24, lsr #7
	dup.2d	v28, x26
	ldr	q29, [sp, #2784]                ; 16-byte Reload
	add.2d	v29, v28, v29
	ldr	q8, [sp, #2832]                 ; 16-byte Reload
	add.2d	v8, v28, v8
	ldr	q10, [sp, #2816]                ; 16-byte Reload
	add.2d	v10, v28, v10
	ldr	q15, [sp, #2800]                ; 16-byte Reload
	add.2d	v28, v28, v15
	shl.2d	v28, v28, #7
	shl.2d	v10, v10, #7
	shl.2d	v8, v8, #7
	dup.2d	v15, x25
	shl.2d	v29, v29, #7
	orr.16b	v29, v29, v15
	orr.16b	v8, v8, v15
	orr.16b	v10, v10, v15
	orr.16b	v28, v28, v15
	ldr	q15, [sp, #2912]                ; 16-byte Reload
	bit.16b	v15, v28, v21
	str	q15, [sp, #2912]                ; 16-byte Spill
	ldr	q21, [sp, #2864]                ; 16-byte Reload
	ldr	q28, [sp, #2928]                ; 16-byte Reload
	bit.16b	v28, v10, v21
	str	q28, [sp, #2928]                ; 16-byte Spill
	ldr	q15, [sp, #2736]                ; 16-byte Reload
	bit.16b	v15, v8, v6
	ldr	q6, [sp, #2848]                 ; 16-byte Reload
	ldr	q21, [sp, #2720]                ; 16-byte Reload
	bif.16b	v29, v21, v6
	movi.2d	v21, #0000000000000000
	movi.2d	v8, #0000000000000000
	cmp	x26, #2, lsl #12                ; =8192
	b.hi	LBB0_42
; %bb.44:                               ; %direct.true218
                                        ;   in Loop: Header=BB0_43 Depth=2
	ldr	q6, [sp, #2432]                 ; 16-byte Reload
	fmov	w25, s6
	shl.2d	v21, v15, #2
	dup.2d	v6, x17
	add.2d	v10, v6, v21
	movi.2d	v21, #0000000000000000
	tbz	w25, #0, LBB0_52
; %bb.45:                               ; %cond.load264
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x26, d10
	ldr	s21, [x26]
	and	w25, w25, #0xff
	tbnz	w25, #1, LBB0_53
LBB0_46:                                ; %else274
                                        ;   in Loop: Header=BB0_43 Depth=2
	ldr	q28, [sp, #2928]                ; 16-byte Reload
	shl.2d	v28, v28, #2
	add.2d	v10, v6, v28
	tbz	w25, #2, LBB0_54
LBB0_47:                                ; %cond.load276
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x26, d10
	ld1.s	{ v21 }[2], [x26]
	tbnz	w25, #3, LBB0_55
LBB0_48:                                ; %else286
                                        ;   in Loop: Header=BB0_43 Depth=2
	ldr	q28, [sp, #2912]                ; 16-byte Reload
	shl.2d	v28, v28, #2
	add.2d	v10, v6, v28
	tbz	w25, #4, LBB0_56
LBB0_49:                                ; %cond.load288
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x26, d10
	ld1.s	{ v8 }[0], [x26]
	tbnz	w25, #5, LBB0_57
LBB0_50:                                ; %else298
                                        ;   in Loop: Header=BB0_43 Depth=2
	shl.2d	v28, v29, #2
	add.2d	v6, v6, v28
	tbz	w25, #6, LBB0_58
LBB0_51:                                ; %cond.load300
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x26, d6
	ld1.s	{ v8 }[2], [x26]
	tbz	w25, #7, LBB0_42
	b	LBB0_59
LBB0_52:                                ; %else268
                                        ;   in Loop: Header=BB0_43 Depth=2
	and	w25, w25, #0xff
	tbz	w25, #1, LBB0_46
LBB0_53:                                ; %cond.load270
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x26, v10[1]
	ld1.s	{ v21 }[1], [x26]
	ldr	q28, [sp, #2928]                ; 16-byte Reload
	shl.2d	v28, v28, #2
	add.2d	v10, v6, v28
	tbnz	w25, #2, LBB0_47
LBB0_54:                                ; %else280
                                        ;   in Loop: Header=BB0_43 Depth=2
	tbz	w25, #3, LBB0_48
LBB0_55:                                ; %cond.load282
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x26, v10[1]
	ld1.s	{ v21 }[3], [x26]
	ldr	q28, [sp, #2912]                ; 16-byte Reload
	shl.2d	v28, v28, #2
	add.2d	v10, v6, v28
	tbnz	w25, #4, LBB0_49
LBB0_56:                                ; %else292
                                        ;   in Loop: Header=BB0_43 Depth=2
	tbz	w25, #5, LBB0_50
LBB0_57:                                ; %cond.load294
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x26, v10[1]
	ld1.s	{ v8 }[1], [x26]
	shl.2d	v28, v29, #2
	add.2d	v6, v6, v28
	tbnz	w25, #6, LBB0_51
LBB0_58:                                ; %else304
                                        ;   in Loop: Header=BB0_43 Depth=2
	tbz	w25, #7, LBB0_42
LBB0_59:                                ; %cond.load306
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x25, v6[1]
	ld1.s	{ v8 }[3], [x25]
	b	LBB0_42
LBB0_60:                                ; %direct.false206
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x23, #0                         ; =0x0
	sshll.2d	v6, v1, #0
	sshll.2d	v21, v0, #0
	ldr	q28, [sp, #2848]                ; 16-byte Reload
	ldr	q29, [sp, #1344]                ; 16-byte Reload
	bit.16b	v29, v4, v28
	str	q29, [sp, #1344]                ; 16-byte Spill
	ldr	q28, [sp, #2864]                ; 16-byte Reload
	bit.16b	v20, v13, v28
	str	q20, [sp, #1088]                ; 16-byte Spill
	ldr	q20, [sp, #1360]                ; 16-byte Reload
	bit.16b	v20, v31, v21
	str	q20, [sp, #1360]                ; 16-byte Spill
	ldr	q21, [sp, #1664]                ; 16-byte Reload
	ldr	q20, [sp, #1376]                ; 16-byte Reload
	bit.16b	v20, v21, v6
	ldr	q10, [sp, #2128]                ; 16-byte Reload
	bic.16b	v10, v10, v0
	bic.16b	v11, v11, v1
	ldr	q8, [sp, #2608]                 ; 16-byte Reload
	ldr	q15, [sp, #2160]                ; 16-byte Reload
LBB0_61:                                ; %direct.true230
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	d6, x23
	orr.16b	v21, v6, v8
	fmov	x24, d21
	add	x24, x10, x24
	ldp	q21, q28, [x24]
	orr.16b	v6, v6, v20
	fmov	x24, d6
	add	x24, x13, x24
	ldp	q6, q29, [x24]
	fmul.4s	v28, v28, v29
	fmul.4s	v6, v21, v6
	fadd.4s	v6, v11, v6
	fadd.4s	v21, v10, v28
	bit.16b	v10, v21, v0
	bit.16b	v11, v6, v1
	add	x23, x23, #32
	cmp	x23, #1, lsl #12                ; =4096
	b.ne	LBB0_61
; %bb.62:                               ; %direct.false231
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q20, [sp, #1376]                ; 16-byte Spill
	str	q10, [sp, #2128]                ; 16-byte Spill
	str	q11, [sp, #1904]                ; 16-byte Spill
	ldp	q10, q8, [sp, #128]             ; 32-byte Folded Reload
	ldr	q11, [sp, #2144]                ; 16-byte Reload
	and.16b	v11, v8, v11
	and.16b	v18, v10, v18
	mov	x23, x10
	mov	w24, #128                       ; =0x80
LBB0_63:                                ; %direct.true245
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q6, q21, [x23]
	ldr	q28, [x23, #16384]
	ldr	q29, [x23, #16400]
	fmul.4s	v21, v21, v29
	fmul.4s	v6, v6, v28
	fadd.4s	v6, v18, v6
	fadd.4s	v21, v11, v21
	bit.16b	v11, v21, v0
	bit.16b	v18, v6, v1
	add	x23, x23, #32
	subs	x24, x24, #1
	b.ne	LBB0_63
; %bb.64:                               ; %direct.false246
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q11, [sp, #2144]                ; 16-byte Spill
	str	q18, [sp, #1920]                ; 16-byte Spill
	and.16b	v15, v8, v15
	and.16b	v17, v10, v17
	mov	x23, x10
	mov	w24, #128                       ; =0x80
	ldr	q18, [sp, #2368]                ; 16-byte Reload
LBB0_65:                                ; %direct.true262
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q6, q21, [x23]
	ldr	q28, [x23, #20480]
	ldr	q29, [x23, #20496]
	fmul.4s	v21, v21, v29
	fmul.4s	v6, v6, v28
	fadd.4s	v6, v17, v6
	fadd.4s	v21, v15, v21
	bit.16b	v15, v21, v0
	bit.16b	v17, v6, v1
	add	x23, x23, #32
	subs	x24, x24, #1
	b.ne	LBB0_65
; %bb.66:                               ; %direct.false263
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q15, [sp, #2160]                ; 16-byte Spill
	str	q17, [sp, #1936]                ; 16-byte Spill
	ldr	q17, [sp, #2176]                ; 16-byte Reload
	and.16b	v17, v8, v17
	and.16b	v27, v10, v27
	mov	x23, x10
	mov	w24, #128                       ; =0x80
	ldr	q11, [sp, #1904]                ; 16-byte Reload
LBB0_67:                                ; %direct.true279
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q6, q21, [x23]
	ldr	q28, [x23, #24576]
	ldr	q29, [x23, #24592]
	fmul.4s	v21, v21, v29
	fmul.4s	v6, v6, v28
	fadd.4s	v6, v27, v6
	fadd.4s	v21, v17, v21
	bit.16b	v17, v21, v0
	bit.16b	v27, v6, v1
	add	x23, x23, #32
	subs	x24, x24, #1
	b.ne	LBB0_67
; %bb.68:                               ; %direct.false280
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q17, [sp, #2176]                ; 16-byte Spill
	str	q27, [sp, #1952]                ; 16-byte Spill
	ldr	q27, [sp, #2192]                ; 16-byte Reload
	and.16b	v27, v8, v27
	and.16b	v26, v10, v26
	mov	x23, x10
	mov	w24, #128                       ; =0x80
	ldr	q15, [sp, #2144]                ; 16-byte Reload
LBB0_69:                                ; %direct.true296
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q6, q21, [x23]
	ldr	q28, [x23, #28672]
	ldr	q29, [x23, #28688]
	fmul.4s	v21, v21, v29
	fmul.4s	v6, v6, v28
	fadd.4s	v6, v26, v6
	fadd.4s	v21, v27, v21
	bit.16b	v27, v21, v0
	bit.16b	v26, v6, v1
	add	x23, x23, #32
	subs	x24, x24, #1
	b.ne	LBB0_69
; %bb.70:                               ; %direct.false297
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q27, [sp, #2192]                ; 16-byte Spill
	str	q26, [sp, #1968]                ; 16-byte Spill
	ldr	q26, [sp, #2208]                ; 16-byte Reload
	and.16b	v26, v8, v26
	and.16b	v25, v10, v25
	mov	x23, x10
	mov	w24, #128                       ; =0x80
	ldr	q17, [sp, #1936]                ; 16-byte Reload
LBB0_71:                                ; %direct.true313
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q6, q21, [x23]
	ldr	q28, [x23, #32768]
	ldr	q29, [x23, #32784]
	fmul.4s	v21, v21, v29
	fmul.4s	v6, v6, v28
	fadd.4s	v6, v25, v6
	fadd.4s	v21, v26, v21
	bit.16b	v26, v21, v0
	bit.16b	v25, v6, v1
	add	x23, x23, #32
	subs	x24, x24, #1
	b.ne	LBB0_71
; %bb.72:                               ; %direct.false314
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q26, [sp, #2208]                ; 16-byte Spill
	str	q25, [sp, #1984]                ; 16-byte Spill
	ldr	q25, [sp, #2224]                ; 16-byte Reload
	and.16b	v25, v8, v25
	and.16b	v24, v10, v24
	mov	x23, x10
	mov	w24, #128                       ; =0x80
	ldr	q27, [sp, #1952]                ; 16-byte Reload
LBB0_73:                                ; %direct.true330
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q6, q21, [x23]
	ldr	q28, [x23, #36864]
	ldr	q29, [x23, #36880]
	fmul.4s	v21, v21, v29
	fmul.4s	v6, v6, v28
	fadd.4s	v6, v24, v6
	fadd.4s	v21, v25, v21
	bit.16b	v25, v21, v0
	bit.16b	v24, v6, v1
	add	x23, x23, #32
	subs	x24, x24, #1
	b.ne	LBB0_73
; %bb.74:                               ; %direct.false331
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q25, [sp, #2224]                ; 16-byte Spill
	str	q24, [sp, #2000]                ; 16-byte Spill
	ldr	q24, [sp, #2240]                ; 16-byte Reload
	and.16b	v24, v8, v24
	and.16b	v9, v10, v9
	mov	x23, x10
	mov	w24, #128                       ; =0x80
	ldr	q26, [sp, #1968]                ; 16-byte Reload
LBB0_75:                                ; %direct.true347
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q6, q21, [x23]
	ldr	q28, [x23, #40960]
	ldr	q29, [x23, #40976]
	fmul.4s	v21, v21, v29
	fmul.4s	v6, v6, v28
	fadd.4s	v6, v9, v6
	fadd.4s	v21, v24, v21
	bit.16b	v24, v21, v0
	bit.16b	v9, v6, v1
	add	x23, x23, #32
	subs	x24, x24, #1
	b.ne	LBB0_75
; %bb.76:                               ; %direct.false348
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q24, [sp, #2240]                ; 16-byte Spill
	str	q9, [sp, #2016]                 ; 16-byte Spill
	ldr	q9, [sp, #2256]                 ; 16-byte Reload
	and.16b	v9, v8, v9
	and.16b	v2, v10, v2
	mov	x23, x10
	mov	w24, #128                       ; =0x80
	ldr	q25, [sp, #1984]                ; 16-byte Reload
LBB0_77:                                ; %direct.true364
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q6, q21, [x23]
	ldr	q28, [x23, #45056]
	ldr	q29, [x23, #45072]
	fmul.4s	v21, v21, v29
	fmul.4s	v6, v6, v28
	fadd.4s	v6, v2, v6
	fadd.4s	v21, v9, v21
	bit.16b	v9, v21, v0
	bit.16b	v2, v6, v1
	add	x23, x23, #32
	subs	x24, x24, #1
	b.ne	LBB0_77
; %bb.78:                               ; %direct.false365
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q9, [sp, #2256]                 ; 16-byte Spill
	str	q2, [sp, #2032]                 ; 16-byte Spill
	ldr	q2, [sp, #2272]                 ; 16-byte Reload
	and.16b	v2, v8, v2
	and.16b	v19, v10, v19
	mov	x23, x10
	mov	w24, #128                       ; =0x80
	ldr	q24, [sp, #2000]                ; 16-byte Reload
LBB0_79:                                ; %direct.true381
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q6, q21, [x23]
	ldr	q28, [x23, #49152]
	ldr	q29, [x23, #49168]
	fmul.4s	v21, v21, v29
	fmul.4s	v6, v6, v28
	fadd.4s	v6, v19, v6
	fadd.4s	v21, v2, v21
	bit.16b	v2, v21, v0
	bit.16b	v19, v6, v1
	add	x23, x23, #32
	subs	x24, x24, #1
	b.ne	LBB0_79
; %bb.80:                               ; %direct.false382
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q2, [sp, #2272]                 ; 16-byte Spill
	str	q19, [sp, #2048]                ; 16-byte Spill
	ldr	q19, [sp, #2288]                ; 16-byte Reload
	and.16b	v19, v8, v19
	and.16b	v23, v10, v23
	mov	x23, x10
	mov	w24, #128                       ; =0x80
	ldr	q9, [sp, #2016]                 ; 16-byte Reload
LBB0_81:                                ; %direct.true398
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q6, q21, [x23]
	ldr	q28, [x23, #53248]
	ldr	q29, [x23, #53264]
	fmul.4s	v21, v21, v29
	fmul.4s	v6, v6, v28
	fadd.4s	v6, v23, v6
	fadd.4s	v21, v19, v21
	bit.16b	v19, v21, v0
	bit.16b	v23, v6, v1
	add	x23, x23, #32
	subs	x24, x24, #1
	b.ne	LBB0_81
; %bb.82:                               ; %direct.false399
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q19, [sp, #2288]                ; 16-byte Spill
	str	q23, [sp, #2064]                ; 16-byte Spill
	ldr	q23, [sp, #2304]                ; 16-byte Reload
	and.16b	v23, v8, v23
	and.16b	v12, v10, v12
	mov	x23, x10
	mov	w24, #128                       ; =0x80
	ldr	q2, [sp, #2032]                 ; 16-byte Reload
LBB0_83:                                ; %direct.true415
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q6, q21, [x23]
	ldr	q28, [x23, #57344]
	ldr	q29, [x23, #57360]
	fmul.4s	v21, v21, v29
	fmul.4s	v6, v6, v28
	fadd.4s	v6, v12, v6
	fadd.4s	v21, v23, v21
	bit.16b	v23, v21, v0
	bit.16b	v12, v6, v1
	add	x23, x23, #32
	subs	x24, x24, #1
	b.ne	LBB0_83
; %bb.84:                               ; %direct.false416
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q23, [sp, #2304]                ; 16-byte Spill
	str	q12, [sp, #2320]                ; 16-byte Spill
	ldr	q12, [sp, #2336]                ; 16-byte Reload
	and.16b	v12, v8, v12
	and.16b	v22, v10, v22
	mov	x23, x10
	mov	w24, #128                       ; =0x80
	ldr	q19, [sp, #2048]                ; 16-byte Reload
LBB0_85:                                ; %direct.true432
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q6, q21, [x23]
	ldr	q28, [x23, #61440]
	ldr	q29, [x23, #61456]
	fmul.4s	v21, v21, v29
	fmul.4s	v6, v6, v28
	fadd.4s	v6, v22, v6
	fadd.4s	v21, v12, v21
	bit.16b	v12, v21, v0
	bit.16b	v22, v6, v1
	add	x23, x23, #32
	subs	x24, x24, #1
	b.ne	LBB0_85
; %bb.86:                               ; %direct.false433
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q12, [sp, #2336]                ; 16-byte Spill
	str	q22, [sp, #2080]                ; 16-byte Spill
	ldr	q22, [sp, #2352]                ; 16-byte Reload
	and.16b	v22, v8, v22
	and.16b	v18, v10, v18
	mov	x23, x10
	mov	w24, #128                       ; =0x80
	ldr	q23, [sp, #2064]                ; 16-byte Reload
LBB0_87:                                ; %direct.true449
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q6, q21, [x23]
	add	x25, x23, #16, lsl #12          ; =65536
	ldp	q28, q29, [x25]
	fmul.4s	v21, v21, v29
	fmul.4s	v6, v6, v28
	fadd.4s	v6, v18, v6
	fadd.4s	v21, v22, v21
	bit.16b	v22, v21, v0
	bit.16b	v18, v6, v1
	add	x23, x23, #32
	subs	x24, x24, #1
	b.ne	LBB0_87
; %bb.88:                               ; %direct.false450
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q22, [sp, #2352]                ; 16-byte Spill
	and.16b	v5, v8, v5
	and.16b	v3, v10, v3
	mov	x23, x10
	mov	w24, #128                       ; =0x80
	ldr	q12, [sp, #2320]                ; 16-byte Reload
LBB0_89:                                ; %direct.true466
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q6, q21, [x23]
	add	x25, x23, #17, lsl #12          ; =69632
	ldp	q28, q29, [x25]
	fmul.4s	v21, v21, v29
	fmul.4s	v6, v6, v28
	fadd.4s	v6, v3, v6
	fadd.4s	v21, v5, v21
	bit.16b	v5, v21, v0
	bit.16b	v3, v6, v1
	add	x23, x23, #32
	subs	x24, x24, #1
	b.ne	LBB0_89
; %bb.90:                               ; %direct.false467
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q18, [sp, #2368]                ; 16-byte Spill
	str	q5, [sp, #2096]                 ; 16-byte Spill
	str	q3, [sp, #2112]                 ; 16-byte Spill
	ldr	q5, [sp, #1440]                 ; 16-byte Reload
	and.16b	v5, v8, v5
	ldr	q3, [sp, #1456]                 ; 16-byte Reload
	and.16b	v3, v10, v3
	mov	x23, x10
	mov	w24, #128                       ; =0x80
	ldr	q22, [sp, #2080]                ; 16-byte Reload
LBB0_91:                                ; %direct.true483
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q6, q21, [x23]
	add	x25, x23, #18, lsl #12          ; =73728
	ldp	q28, q29, [x25]
	fmul.4s	v21, v21, v29
	fmul.4s	v6, v6, v28
	fadd.4s	v6, v3, v6
	fadd.4s	v21, v5, v21
	bit.16b	v5, v21, v0
	bit.16b	v3, v6, v1
	add	x23, x23, #32
	subs	x24, x24, #1
	b.ne	LBB0_91
; %bb.92:                               ; %direct.false484
                                        ;   in Loop: Header=BB0_22 Depth=1
	stp	q30, q16, [sp, #1008]           ; 32-byte Folded Spill
	str	q7, [sp, #1040]                 ; 16-byte Spill
	mov	x23, #0                         ; =0x0
	dup.4s	v8, w1
	fmul.4s	v31, v11, v8
	ldr	q6, [sp, #2128]                 ; 16-byte Reload
	fmul.4s	v30, v6, v8
	cmp	x0, #512
	cset	w24, lo
	dup.4h	v6, w24
	fmul.4s	v28, v15, v8
	ldr	q18, [sp, #1920]                ; 16-byte Reload
	fmul.4s	v29, v18, v8
	ldr	q18, [sp, #2160]                ; 16-byte Reload
	fmul.4s	v10, v18, v8
	ldp	q21, q15, [x11]
	ushll.4s	v6, v6, #0
	bit.16b	v15, v30, v0
	bit.16b	v21, v31, v1
	stp	q21, q15, [x11]
	shl.4s	v6, v6, #31
	cmlt.4s	v21, v6, #0
	ldr	q15, [sp, #112]                 ; 16-byte Reload
	mov.16b	v7, v21
	bsl.16b	v7, v29, v15
	ldp	q6, q29, [x11, #32]
	mov.16b	v20, v21
	bsl.16b	v20, v28, v15
	mov.16b	v28, v0
	bsl.16b	v28, v20, v29
	str	q7, [sp, #1872]                 ; 16-byte Spill
	bit.16b	v6, v7, v1
	stp	q6, q28, [x11, #32]
	fmul.4s	v6, v17, v8
	ldr	q17, [sp, #2176]                ; 16-byte Reload
	fmul.4s	v28, v17, v8
	mov.16b	v7, v21
	bsl.16b	v7, v6, v15
	ldp	q6, q29, [x11, #64]
	mov.16b	v14, v21
	bsl.16b	v14, v10, v15
	bit.16b	v29, v14, v0
	str	q7, [sp, #1824]                 ; 16-byte Spill
	bit.16b	v6, v7, v1
	stp	q6, q29, [x11, #64]
	fmul.4s	v6, v27, v8
	ldr	q27, [sp, #2192]                ; 16-byte Reload
	fmul.4s	v29, v27, v8
	mov.16b	v7, v21
	bsl.16b	v7, v6, v15
	ldp	q6, q10, [x11, #96]
	mov.16b	v16, v21
	bsl.16b	v16, v28, v15
	str	q16, [sp, #1712]                ; 16-byte Spill
	mov.16b	v28, v0
	bsl.16b	v28, v16, v10
	str	q7, [sp, #1728]                 ; 16-byte Spill
	bit.16b	v6, v7, v1
	stp	q6, q28, [x11, #96]
	fmul.4s	v6, v26, v8
	ldr	q26, [sp, #2208]                ; 16-byte Reload
	fmul.4s	v28, v26, v8
	mov.16b	v7, v21
	bsl.16b	v7, v6, v15
	ldp	q6, q10, [x11, #128]
	mov.16b	v16, v21
	bsl.16b	v16, v29, v15
	stp	q16, q7, [sp, #944]             ; 32-byte Folded Spill
	mov.16b	v29, v0
	bsl.16b	v29, v16, v10
	bit.16b	v6, v7, v1
	stp	q6, q29, [x11, #128]
	fmul.4s	v6, v25, v8
	ldr	q25, [sp, #2224]                ; 16-byte Reload
	fmul.4s	v29, v25, v8
	mov.16b	v7, v21
	bsl.16b	v7, v6, v15
	ldp	q6, q10, [x11, #160]
	mov.16b	v16, v21
	bsl.16b	v16, v28, v15
	stp	q16, q7, [sp, #848]             ; 32-byte Folded Spill
	mov.16b	v28, v0
	bsl.16b	v28, v16, v10
	bit.16b	v6, v7, v1
	stp	q6, q28, [x11, #160]
	fmul.4s	v6, v24, v8
	ldr	q24, [sp, #2240]                ; 16-byte Reload
	fmul.4s	v28, v24, v8
	mov.16b	v7, v21
	bsl.16b	v7, v6, v15
	ldp	q6, q10, [x11, #192]
	mov.16b	v16, v21
	bsl.16b	v16, v29, v15
	stp	q16, q7, [sp, #752]             ; 32-byte Folded Spill
	mov.16b	v29, v0
	bsl.16b	v29, v16, v10
	bit.16b	v6, v7, v1
	stp	q6, q29, [x11, #192]
	fmul.4s	v6, v9, v8
	ldr	q29, [sp, #2256]                ; 16-byte Reload
	fmul.4s	v29, v29, v8
	mov.16b	v7, v21
	bsl.16b	v7, v6, v15
	ldp	q6, q10, [x11, #224]
	mov.16b	v16, v21
	bsl.16b	v16, v28, v15
	stp	q16, q7, [sp, #656]             ; 32-byte Folded Spill
	mov.16b	v28, v0
	bsl.16b	v28, v16, v10
	bit.16b	v6, v7, v1
	stp	q6, q28, [x11, #224]
	fmul.4s	v6, v2, v8
	fmul.4s	v28, v19, v8
	mov.16b	v2, v21
	bsl.16b	v2, v6, v15
	ldp	q6, q10, [x11, #256]
	mov.16b	v7, v21
	bsl.16b	v7, v29, v15
	stp	q7, q2, [sp, #544]              ; 32-byte Folded Spill
	mov.16b	v29, v0
	bsl.16b	v29, v7, v10
	bit.16b	v6, v2, v1
	stp	q6, q29, [x11, #256]
	ldr	q2, [sp, #2272]                 ; 16-byte Reload
	fmul.4s	v6, v2, v8
	fmul.4s	v29, v23, v8
	mov.16b	v2, v21
	bsl.16b	v2, v6, v15
	ldp	q10, q6, [x11, #288]
	mov.16b	v7, v21
	bsl.16b	v7, v28, v15
	str	q7, [sp, #496]                  ; 16-byte Spill
	mov.16b	v28, v1
	bsl.16b	v28, v7, v10
	str	q2, [sp, #576]                  ; 16-byte Spill
	bit.16b	v6, v2, v0
	stp	q28, q6, [x11, #288]
	ldr	q6, [sp, #2288]                 ; 16-byte Reload
	fmul.4s	v6, v6, v8
	fmul.4s	v28, v12, v8
	mov.16b	v2, v21
	bsl.16b	v2, v6, v15
	ldp	q10, q6, [x11, #320]
	mov.16b	v7, v21
	bsl.16b	v7, v29, v15
	str	q7, [sp, #592]                  ; 16-byte Spill
	mov.16b	v29, v1
	bsl.16b	v29, v7, v10
	str	q2, [sp, #640]                  ; 16-byte Spill
	bit.16b	v6, v2, v0
	stp	q29, q6, [x11, #320]
	ldr	q6, [sp, #2304]                 ; 16-byte Reload
	fmul.4s	v6, v6, v8
	fmul.4s	v29, v22, v8
	mov.16b	v2, v21
	bsl.16b	v2, v6, v15
	ldp	q10, q6, [x11, #352]
	mov.16b	v7, v21
	bsl.16b	v7, v28, v15
	str	q7, [sp, #688]                  ; 16-byte Spill
	mov.16b	v28, v1
	bsl.16b	v28, v7, v10
	str	q2, [sp, #720]                  ; 16-byte Spill
	bit.16b	v6, v2, v0
	stp	q28, q6, [x11, #352]
	ldr	q6, [sp, #2336]                 ; 16-byte Reload
	fmul.4s	v6, v6, v8
	ldr	q22, [sp, #2352]                ; 16-byte Reload
	fmul.4s	v28, v22, v8
	mov.16b	v2, v21
	bsl.16b	v2, v6, v15
	ldp	q10, q6, [x11, #384]
	mov.16b	v7, v21
	bsl.16b	v7, v29, v15
	stp	q7, q2, [sp, #784]              ; 32-byte Folded Spill
	mov.16b	v29, v1
	bsl.16b	v29, v7, v10
	bit.16b	v6, v2, v0
	stp	q29, q6, [x11, #384]
	ldr	q6, [sp, #2368]                 ; 16-byte Reload
	fmul.4s	v6, v6, v8
	mov.16b	v2, v21
	bsl.16b	v2, v6, v15
	mov.16b	v7, v21
	bsl.16b	v7, v28, v15
	ldp	q6, q28, [x11, #416]
	stp	q7, q2, [sp, #880]              ; 32-byte Folded Spill
	bit.16b	v28, v7, v0
	bit.16b	v6, v2, v1
	stp	q6, q28, [x11, #416]
	ldr	q6, [sp, #2112]                 ; 16-byte Reload
	fmul.4s	v6, v6, v8
	ldr	q28, [sp, #2096]                ; 16-byte Reload
	fmul.4s	v28, v28, v8
	mov.16b	v2, v21
	bsl.16b	v2, v28, v15
	mov.16b	v7, v21
	bsl.16b	v7, v6, v15
	ldp	q6, q28, [x11, #448]
	str	q7, [sp, #1056]                 ; 16-byte Spill
	bit.16b	v6, v7, v1
	str	q2, [sp, #1072]                 ; 16-byte Spill
	bit.16b	v28, v2, v0
	stp	q6, q28, [x11, #448]
	str	q3, [sp, #1456]                 ; 16-byte Spill
	fmul.4s	v6, v3, v8
	str	q5, [sp, #1440]                 ; 16-byte Spill
	fmul.4s	v28, v5, v8
	mov.16b	v2, v21
	bsl.16b	v2, v28, v15
	mov.16b	v3, v21
	bsl.16b	v3, v6, v15
	ldp	q6, q21, [x11, #480]
	str	q3, [sp, #1744]                 ; 16-byte Spill
	bit.16b	v6, v3, v1
	str	q2, [sp, #1760]                 ; 16-byte Spill
	bit.16b	v21, v2, v0
	stp	q6, q21, [x11, #480]
	mvni.4s	v6, #127, msl #16
	ldr	q8, [sp, #1472]                 ; 16-byte Reload
	bit.16b	v8, v6, v0
	ldr	q29, [sp, #1488]                ; 16-byte Reload
	bit.16b	v29, v6, v1
	dup.8b	v2, w24
	str	d2, [sp, #264]                  ; 8-byte Spill
LBB0_93:                                ; %direct.true597
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x24, x11, x23
	ldp	q6, q21, [x24]
	and.16b	v21, v0, v21
	and.16b	v6, v1, v6
	fmaxnm.4s	v6, v29, v6
	fmaxnm.4s	v21, v8, v21
	bit.16b	v8, v21, v0
	bit.16b	v29, v6, v1
	add	x23, x23, #32
	cmp	x23, #512
	b.ne	LBB0_93
; %bb.94:                               ; %direct.false598
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q21, [sp, #2848]                ; 16-byte Reload
	ldr	q2, [sp, #1392]                 ; 16-byte Reload
	bit.16b	v2, v4, v21
	str	q2, [sp, #1392]                 ; 16-byte Spill
	ldr	q6, [sp, #2864]                 ; 16-byte Reload
	ldr	q2, [sp, #1424]                 ; 16-byte Reload
	bit.16b	v2, v13, v6
	str	q2, [sp, #1424]                 ; 16-byte Spill
	ldr	q28, [sp, #1616]                ; 16-byte Reload
	bit.16b	v28, v4, v21
	str	q28, [sp, #1616]                ; 16-byte Spill
	ldr	q21, [sp, #1648]                ; 16-byte Reload
	bit.16b	v21, v13, v6
	str	q21, [sp, #1648]                ; 16-byte Spill
	str	q29, [sp, #1488]                ; 16-byte Spill
	ldr	q2, [sp, #2400]                 ; 16-byte Reload
	fmaxnm.4s	v2, v2, v29
	fsub.4s	v6, v31, v2
	and.16b	v4, v1, v6
	dup.4s	v19, w2
	fcmge.4s	v6, v4, v19
	dup.4s	v17, w3
	fcmge.4s	v21, v17, v4
	and.16b	v6, v6, v21
	str	q8, [sp, #1472]                 ; 16-byte Spill
	ldr	q3, [sp, #2416]                 ; 16-byte Reload
	fmaxnm.4s	v3, v3, v8
	fsub.4s	v21, v30, v3
	and.16b	v18, v0, v21
	fcmge.4s	v21, v18, v19
	fcmge.4s	v28, v17, v18
	and.16b	v21, v21, v28
	dup.4s	v22, w4
	and.16b	v21, v21, v18
	fmul.4s	v28, v21, v22
	movi.4s	v23, #75, lsl #24
	mvni.4s	v24, #128, lsl #24
	mov.16b	v29, v24
	bsl.16b	v29, v23, v28
	fadd.4s	v28, v28, v29
	fsub.4s	v28, v28, v29
	and.16b	v29, v6, v4
	fmul.4s	v6, v29, v22
	mov.16b	v8, v24
	bsl.16b	v8, v23, v6
	fadd.4s	v6, v6, v8
	fsub.4s	v8, v6, v8
	fcvtzs.4s	v6, v28
	scvtf.4s	v28, v6
	dup.4s	v25, w5
	fmul.4s	v10, v28, v25
	fsub.4s	v10, v21, v10
	fcvtzs.4s	v21, v8
	scvtf.4s	v8, v21
	fmul.4s	v15, v8, v25
	fsub.4s	v29, v29, v15
	dup.4s	v27, w6
	fmul.4s	v8, v8, v27
	fsub.4s	v29, v29, v8
	fmul.4s	v28, v28, v27
	fsub.4s	v28, v10, v28
	dup.4s	v9, w7
	dup.4s	v11, w19
	fmul.4s	v8, v28, v9
	fadd.4s	v8, v8, v11
	fmul.4s	v8, v28, v8
	dup.4s	v7, w20
	fadd.4s	v8, v8, v7
	fmul.4s	v8, v28, v8
	dup.4s	v16, w21
	fadd.4s	v8, v8, v16
	dup.4s	v30, w22
	fmul.4s	v8, v28, v8
	fadd.4s	v8, v8, v30
	fmul.4s	v8, v28, v8
	movi.4s	v13, #63, lsl #24
	fadd.4s	v8, v8, v13
	fmul.4s	v10, v28, v28
	fmul.4s	v8, v10, v8
	fmul.4s	v10, v29, v9
	fadd.4s	v10, v10, v11
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v7
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v16
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v30
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v13
	fmul.4s	v15, v29, v29
	fmul.4s	v10, v15, v10
	fadd.4s	v29, v29, v10
	fadd.4s	v28, v28, v8
	fmov.4s	v26, #1.00000000
	fadd.4s	v29, v29, v26
	sshr.4s	v8, v21, #1
	shl.4s	v10, v8, #23
	add.4s	v10, v10, v26
	fmul.4s	v29, v29, v10
	fadd.4s	v28, v28, v26
	sshr.4s	v10, v6, #1
	shl.4s	v15, v10, #23
	add.4s	v15, v15, v26
	fmul.4s	v28, v28, v15
	sub.4s	v21, v21, v8
	sub.4s	v6, v6, v10
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v26
	fmul.4s	v6, v28, v6
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v26
	fmul.4s	v21, v29, v21
	str	q4, [sp, #832]                  ; 16-byte Spill
	fcmgt.4s	v28, v19, v4
	bic.16b	v21, v21, v28
	str	q18, [sp, #736]                 ; 16-byte Spill
	fcmgt.4s	v28, v19, v18
	bic.16b	v6, v6, v28
	fcmgt.4s	v28, v18, v17
	mvni.4s	v29, #127, msl #16
	fneg.4s	v31, v29
	bit.16b	v6, v31, v28
	str	q6, [sp, #1888]                 ; 16-byte Spill
	fcmgt.4s	v6, v4, v17
	bsl.16b	v6, v31, v21
	str	q6, [sp, #2384]                 ; 16-byte Spill
	fsub.4s	v6, v20, v3
	and.16b	v20, v0, v6
	fcmge.4s	v6, v20, v19
	fcmge.4s	v21, v17, v20
	and.16b	v6, v6, v21
	ldr	q4, [sp, #1872]                 ; 16-byte Reload
	fsub.4s	v21, v4, v2
	and.16b	v12, v1, v21
	fcmge.4s	v21, v12, v19
	fcmge.4s	v28, v17, v12
	and.16b	v21, v21, v28
	and.16b	v21, v21, v12
	fmul.4s	v28, v21, v22
	mov.16b	v29, v24
	bsl.16b	v29, v23, v28
	fadd.4s	v28, v28, v29
	fsub.4s	v28, v28, v29
	and.16b	v29, v6, v20
	fmul.4s	v6, v29, v22
	mov.16b	v8, v24
	bsl.16b	v8, v23, v6
	fadd.4s	v6, v6, v8
	fsub.4s	v8, v6, v8
	fcvtzs.4s	v6, v28
	scvtf.4s	v28, v6
	fmul.4s	v10, v28, v25
	fsub.4s	v21, v21, v10
	fcvtzs.4s	v8, v8
	scvtf.4s	v10, v8
	fmul.4s	v15, v10, v25
	fsub.4s	v29, v29, v15
	fmul.4s	v10, v10, v27
	fsub.4s	v29, v29, v10
	fmul.4s	v28, v28, v27
	fsub.4s	v21, v21, v28
	fmul.4s	v28, v21, v9
	fadd.4s	v28, v28, v11
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v7
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v16
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v30
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v13
	fmul.4s	v10, v21, v21
	fmul.4s	v28, v10, v28
	fmul.4s	v10, v29, v9
	fadd.4s	v10, v10, v11
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v7
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v16
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v30
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v13
	fmul.4s	v15, v29, v29
	fmul.4s	v10, v15, v10
	fadd.4s	v29, v29, v10
	fadd.4s	v21, v21, v28
	fadd.4s	v28, v29, v26
	sshr.4s	v29, v8, #1
	shl.4s	v10, v29, #23
	add.4s	v10, v10, v26
	fmul.4s	v28, v28, v10
	fadd.4s	v21, v21, v26
	sshr.4s	v10, v6, #1
	shl.4s	v15, v10, #23
	add.4s	v15, v15, v26
	fmul.4s	v21, v21, v15
	sub.4s	v29, v8, v29
	sub.4s	v6, v6, v10
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v26
	fmul.4s	v6, v21, v6
	shl.4s	v21, v29, #23
	add.4s	v21, v21, v26
	fmul.4s	v21, v28, v21
	str	q20, [sp, #1792]                ; 16-byte Spill
	fcmgt.4s	v28, v19, v20
	bic.16b	v21, v21, v28
	str	q12, [sp, #1840]                ; 16-byte Spill
	fcmgt.4s	v28, v19, v12
	bic.16b	v6, v6, v28
	fcmgt.4s	v28, v12, v17
	bit.16b	v6, v31, v28
	str	q6, [sp, #1872]                 ; 16-byte Spill
	fcmgt.4s	v6, v20, v17
	bsl.16b	v6, v31, v21
	str	q6, [sp, #1856]                 ; 16-byte Spill
	fsub.4s	v6, v14, v3
	and.16b	v14, v0, v6
	fcmge.4s	v6, v14, v19
	fcmge.4s	v21, v17, v14
	and.16b	v6, v6, v21
	ldr	q4, [sp, #1824]                 ; 16-byte Reload
	fsub.4s	v21, v4, v2
	and.16b	v12, v1, v21
	fcmge.4s	v21, v12, v19
	fcmge.4s	v28, v17, v12
	and.16b	v21, v21, v28
	and.16b	v21, v21, v12
	fmul.4s	v28, v21, v22
	mov.16b	v29, v24
	bsl.16b	v29, v23, v28
	fadd.4s	v28, v28, v29
	fsub.4s	v28, v28, v29
	and.16b	v29, v6, v14
	fmul.4s	v6, v29, v22
	mov.16b	v8, v24
	bsl.16b	v8, v23, v6
	fadd.4s	v6, v6, v8
	fsub.4s	v8, v6, v8
	fcvtzs.4s	v6, v28
	scvtf.4s	v28, v6
	fmul.4s	v10, v28, v25
	fsub.4s	v21, v21, v10
	fcvtzs.4s	v8, v8
	scvtf.4s	v10, v8
	fmul.4s	v15, v10, v25
	fsub.4s	v29, v29, v15
	fmul.4s	v10, v10, v27
	fsub.4s	v29, v29, v10
	fmul.4s	v28, v28, v27
	fsub.4s	v21, v21, v28
	fmul.4s	v28, v21, v9
	fadd.4s	v28, v28, v11
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v7
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v16
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v30
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v13
	fmul.4s	v10, v21, v21
	fmul.4s	v28, v10, v28
	fmul.4s	v10, v29, v9
	fadd.4s	v10, v10, v11
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v7
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v16
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v30
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v13
	fmul.4s	v15, v29, v29
	fmul.4s	v10, v15, v10
	fadd.4s	v29, v29, v10
	fadd.4s	v21, v21, v28
	fadd.4s	v28, v29, v26
	sshr.4s	v29, v8, #1
	shl.4s	v10, v29, #23
	add.4s	v10, v10, v26
	fmul.4s	v28, v28, v10
	fadd.4s	v21, v21, v26
	sshr.4s	v10, v6, #1
	shl.4s	v15, v10, #23
	add.4s	v15, v15, v26
	fmul.4s	v21, v21, v15
	sub.4s	v29, v8, v29
	sub.4s	v6, v6, v10
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v26
	fmul.4s	v6, v21, v6
	shl.4s	v21, v29, #23
	add.4s	v21, v21, v26
	fmul.4s	v21, v28, v21
	str	q14, [sp, #992]                 ; 16-byte Spill
	fcmgt.4s	v28, v19, v14
	bic.16b	v21, v21, v28
	str	q12, [sp, #1776]                ; 16-byte Spill
	fcmgt.4s	v28, v19, v12
	bic.16b	v6, v6, v28
	fcmgt.4s	v28, v12, v17
	bit.16b	v6, v31, v28
	str	q6, [sp, #1824]                 ; 16-byte Spill
	fcmgt.4s	v6, v14, v17
	bsl.16b	v6, v31, v21
	str	q6, [sp, #1808]                 ; 16-byte Spill
	ldr	q4, [sp, #1712]                 ; 16-byte Reload
	fsub.4s	v6, v4, v3
	and.16b	v20, v0, v6
	fcmge.4s	v6, v20, v19
	fcmge.4s	v21, v17, v20
	and.16b	v6, v6, v21
	ldr	q4, [sp, #1728]                 ; 16-byte Reload
	fsub.4s	v21, v4, v2
	and.16b	v12, v1, v21
	fcmge.4s	v21, v12, v19
	fcmge.4s	v28, v17, v12
	and.16b	v21, v21, v28
	and.16b	v21, v21, v12
	fmul.4s	v28, v21, v22
	mov.16b	v29, v24
	bsl.16b	v29, v23, v28
	fadd.4s	v28, v28, v29
	fsub.4s	v28, v28, v29
	and.16b	v29, v6, v20
	fmul.4s	v6, v29, v22
	mov.16b	v8, v24
	bsl.16b	v8, v23, v6
	fadd.4s	v6, v6, v8
	fsub.4s	v8, v6, v8
	fcvtzs.4s	v6, v28
	scvtf.4s	v28, v6
	fmul.4s	v10, v28, v25
	fsub.4s	v21, v21, v10
	fcvtzs.4s	v8, v8
	scvtf.4s	v10, v8
	fmul.4s	v15, v10, v25
	fsub.4s	v29, v29, v15
	fmul.4s	v10, v10, v27
	fsub.4s	v29, v29, v10
	fmul.4s	v28, v28, v27
	fsub.4s	v21, v21, v28
	fmul.4s	v28, v21, v9
	fadd.4s	v28, v28, v11
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v7
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v16
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v30
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v13
	fmul.4s	v10, v21, v21
	fmul.4s	v28, v10, v28
	fmul.4s	v10, v29, v9
	fadd.4s	v10, v10, v11
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v7
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v16
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v30
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v13
	fmul.4s	v15, v29, v29
	fmul.4s	v10, v15, v10
	fadd.4s	v29, v29, v10
	fadd.4s	v21, v21, v28
	fadd.4s	v28, v29, v26
	sshr.4s	v29, v8, #1
	shl.4s	v10, v29, #23
	add.4s	v10, v10, v26
	fmul.4s	v28, v28, v10
	fadd.4s	v21, v21, v26
	sshr.4s	v10, v6, #1
	shl.4s	v15, v10, #23
	add.4s	v15, v15, v26
	fmul.4s	v21, v21, v15
	sub.4s	v29, v8, v29
	sub.4s	v6, v6, v10
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v26
	fmul.4s	v6, v21, v6
	shl.4s	v21, v29, #23
	add.4s	v21, v21, v26
	fmul.4s	v21, v28, v21
	str	q20, [sp, #928]                 ; 16-byte Spill
	fcmgt.4s	v28, v19, v20
	bic.16b	v21, v21, v28
	str	q12, [sp, #976]                 ; 16-byte Spill
	fcmgt.4s	v28, v19, v12
	bic.16b	v6, v6, v28
	fcmgt.4s	v28, v12, v17
	bit.16b	v6, v31, v28
	str	q6, [sp, #1728]                 ; 16-byte Spill
	fcmgt.4s	v6, v20, v17
	bsl.16b	v6, v31, v21
	str	q6, [sp, #1712]                 ; 16-byte Spill
	ldp	q5, q4, [sp, #944]              ; 32-byte Folded Reload
	fsub.4s	v6, v5, v3
	and.16b	v20, v0, v6
	fcmge.4s	v6, v20, v19
	fcmge.4s	v21, v17, v20
	and.16b	v6, v6, v21
	fsub.4s	v21, v4, v2
	and.16b	v12, v1, v21
	fcmge.4s	v21, v12, v19
	fcmge.4s	v28, v17, v12
	and.16b	v21, v21, v28
	and.16b	v21, v21, v12
	fmul.4s	v28, v21, v22
	mov.16b	v29, v24
	bsl.16b	v29, v23, v28
	fadd.4s	v28, v28, v29
	fsub.4s	v28, v28, v29
	and.16b	v29, v6, v20
	fmul.4s	v6, v29, v22
	mov.16b	v8, v24
	bsl.16b	v8, v23, v6
	fadd.4s	v6, v6, v8
	fsub.4s	v8, v6, v8
	fcvtzs.4s	v6, v28
	scvtf.4s	v28, v6
	fmul.4s	v10, v28, v25
	fsub.4s	v21, v21, v10
	fcvtzs.4s	v8, v8
	scvtf.4s	v10, v8
	fmul.4s	v15, v10, v25
	fsub.4s	v29, v29, v15
	fmul.4s	v10, v10, v27
	fsub.4s	v29, v29, v10
	fmul.4s	v28, v28, v27
	fsub.4s	v21, v21, v28
	fmul.4s	v28, v21, v9
	fadd.4s	v28, v28, v11
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v7
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v16
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v30
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v13
	fmul.4s	v10, v21, v21
	fmul.4s	v28, v10, v28
	fmul.4s	v10, v29, v9
	fadd.4s	v10, v10, v11
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v7
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v16
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v30
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v13
	fmul.4s	v15, v29, v29
	fmul.4s	v10, v15, v10
	fadd.4s	v29, v29, v10
	fadd.4s	v21, v21, v28
	fadd.4s	v28, v29, v26
	sshr.4s	v29, v8, #1
	shl.4s	v10, v29, #23
	add.4s	v10, v10, v26
	fmul.4s	v28, v28, v10
	fadd.4s	v21, v21, v26
	sshr.4s	v10, v6, #1
	shl.4s	v15, v10, #23
	add.4s	v15, v15, v26
	fmul.4s	v21, v21, v15
	sub.4s	v29, v8, v29
	sub.4s	v6, v6, v10
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v26
	fmul.4s	v6, v21, v6
	shl.4s	v21, v29, #23
	add.4s	v21, v21, v26
	fmul.4s	v21, v28, v21
	str	q20, [sp, #624]                 ; 16-byte Spill
	fcmgt.4s	v28, v19, v20
	bic.16b	v21, v21, v28
	str	q12, [sp, #912]                 ; 16-byte Spill
	fcmgt.4s	v28, v19, v12
	bic.16b	v6, v6, v28
	fcmgt.4s	v28, v12, v17
	bit.16b	v6, v31, v28
	str	q6, [sp, #960]                  ; 16-byte Spill
	fcmgt.4s	v6, v20, v17
	bsl.16b	v6, v31, v21
	str	q6, [sp, #944]                  ; 16-byte Spill
	ldp	q5, q4, [sp, #848]              ; 32-byte Folded Reload
	fsub.4s	v6, v5, v3
	and.16b	v20, v0, v6
	fcmge.4s	v6, v20, v19
	fcmge.4s	v21, v17, v20
	and.16b	v6, v6, v21
	fsub.4s	v21, v4, v2
	and.16b	v12, v1, v21
	fcmge.4s	v21, v12, v19
	fcmge.4s	v28, v17, v12
	and.16b	v21, v21, v28
	and.16b	v21, v21, v12
	fmul.4s	v28, v21, v22
	mov.16b	v29, v24
	bsl.16b	v29, v23, v28
	fadd.4s	v28, v28, v29
	fsub.4s	v28, v28, v29
	and.16b	v29, v6, v20
	fmul.4s	v6, v29, v22
	mov.16b	v8, v24
	bsl.16b	v8, v23, v6
	fadd.4s	v6, v6, v8
	fsub.4s	v8, v6, v8
	fcvtzs.4s	v6, v28
	scvtf.4s	v28, v6
	fmul.4s	v10, v28, v25
	fsub.4s	v21, v21, v10
	fcvtzs.4s	v8, v8
	scvtf.4s	v10, v8
	fmul.4s	v15, v10, v25
	fsub.4s	v29, v29, v15
	fmul.4s	v10, v10, v27
	fsub.4s	v29, v29, v10
	fmul.4s	v28, v28, v27
	fsub.4s	v21, v21, v28
	fmul.4s	v28, v21, v9
	fadd.4s	v28, v28, v11
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v7
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v16
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v30
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v13
	fmul.4s	v10, v21, v21
	fmul.4s	v28, v10, v28
	fmul.4s	v10, v29, v9
	fadd.4s	v10, v10, v11
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v7
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v16
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v30
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v13
	fmul.4s	v15, v29, v29
	fmul.4s	v10, v15, v10
	fadd.4s	v29, v29, v10
	fadd.4s	v21, v21, v28
	fadd.4s	v28, v29, v26
	sshr.4s	v29, v8, #1
	shl.4s	v10, v29, #23
	add.4s	v10, v10, v26
	fmul.4s	v28, v28, v10
	fadd.4s	v21, v21, v26
	sshr.4s	v10, v6, #1
	shl.4s	v15, v10, #23
	add.4s	v15, v15, v26
	fmul.4s	v21, v21, v15
	sub.4s	v29, v8, v29
	sub.4s	v6, v6, v10
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v26
	fmul.4s	v6, v21, v6
	shl.4s	v21, v29, #23
	add.4s	v21, v21, v26
	fmul.4s	v21, v28, v21
	str	q20, [sp, #528]                 ; 16-byte Spill
	fcmgt.4s	v28, v19, v20
	bic.16b	v21, v21, v28
	str	q12, [sp, #816]                 ; 16-byte Spill
	fcmgt.4s	v28, v19, v12
	bic.16b	v6, v6, v28
	fcmgt.4s	v28, v12, v17
	bit.16b	v6, v31, v28
	str	q6, [sp, #864]                  ; 16-byte Spill
	fcmgt.4s	v6, v20, v17
	bsl.16b	v6, v31, v21
	str	q6, [sp, #848]                  ; 16-byte Spill
	ldp	q4, q18, [sp, #752]             ; 32-byte Folded Reload
	fsub.4s	v6, v4, v3
	and.16b	v4, v0, v6
	fcmge.4s	v6, v4, v19
	fcmge.4s	v21, v17, v4
	and.16b	v6, v6, v21
	fsub.4s	v21, v18, v2
	and.16b	v12, v1, v21
	fcmge.4s	v21, v12, v19
	fcmge.4s	v28, v17, v12
	and.16b	v21, v21, v28
	and.16b	v21, v21, v12
	fmul.4s	v28, v21, v22
	mov.16b	v29, v24
	bsl.16b	v29, v23, v28
	fadd.4s	v28, v28, v29
	fsub.4s	v28, v28, v29
	and.16b	v29, v6, v4
	fmul.4s	v6, v29, v22
	mov.16b	v8, v24
	bsl.16b	v8, v23, v6
	fadd.4s	v6, v6, v8
	fsub.4s	v8, v6, v8
	fcvtzs.4s	v6, v28
	scvtf.4s	v28, v6
	fmul.4s	v10, v28, v25
	fsub.4s	v21, v21, v10
	fcvtzs.4s	v8, v8
	scvtf.4s	v10, v8
	fmul.4s	v15, v10, v25
	fsub.4s	v29, v29, v15
	fmul.4s	v10, v10, v27
	fsub.4s	v29, v29, v10
	fmul.4s	v28, v28, v27
	fsub.4s	v21, v21, v28
	fmul.4s	v28, v21, v9
	fadd.4s	v28, v28, v11
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v7
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v16
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v30
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v13
	fmul.4s	v10, v21, v21
	fmul.4s	v28, v10, v28
	fmul.4s	v10, v29, v9
	fadd.4s	v10, v10, v11
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v7
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v16
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v30
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v13
	fmul.4s	v15, v29, v29
	fmul.4s	v10, v15, v10
	fadd.4s	v29, v29, v10
	fadd.4s	v21, v21, v28
	fadd.4s	v28, v29, v26
	sshr.4s	v29, v8, #1
	shl.4s	v10, v29, #23
	add.4s	v10, v10, v26
	fmul.4s	v28, v28, v10
	fadd.4s	v21, v21, v26
	sshr.4s	v10, v6, #1
	shl.4s	v15, v10, #23
	add.4s	v15, v15, v26
	fmul.4s	v21, v21, v15
	sub.4s	v29, v8, v29
	sub.4s	v6, v6, v10
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v26
	fmul.4s	v6, v21, v6
	shl.4s	v21, v29, #23
	add.4s	v21, v21, v26
	fmul.4s	v21, v28, v21
	str	q4, [sp, #480]                  ; 16-byte Spill
	fcmgt.4s	v28, v19, v4
	bic.16b	v21, v21, v28
	str	q12, [sp, #704]                 ; 16-byte Spill
	fcmgt.4s	v28, v19, v12
	bic.16b	v6, v6, v28
	fcmgt.4s	v28, v12, v17
	bit.16b	v6, v31, v28
	str	q6, [sp, #768]                  ; 16-byte Spill
	fcmgt.4s	v6, v4, v17
	bsl.16b	v6, v31, v21
	str	q6, [sp, #752]                  ; 16-byte Spill
	ldp	q5, q4, [sp, #656]              ; 32-byte Folded Reload
	fsub.4s	v6, v5, v3
	and.16b	v18, v0, v6
	fcmge.4s	v6, v18, v19
	fcmge.4s	v21, v17, v18
	and.16b	v6, v6, v21
	fsub.4s	v21, v4, v2
	and.16b	v12, v1, v21
	fcmge.4s	v21, v12, v19
	fcmge.4s	v28, v17, v12
	and.16b	v21, v21, v28
	and.16b	v21, v21, v12
	fmul.4s	v28, v21, v22
	mov.16b	v29, v24
	bsl.16b	v29, v23, v28
	fadd.4s	v28, v28, v29
	fsub.4s	v28, v28, v29
	and.16b	v29, v6, v18
	fmul.4s	v6, v29, v22
	mov.16b	v8, v24
	bsl.16b	v8, v23, v6
	fadd.4s	v6, v6, v8
	fsub.4s	v8, v6, v8
	fcvtzs.4s	v6, v28
	scvtf.4s	v28, v6
	fmul.4s	v10, v28, v25
	fsub.4s	v21, v21, v10
	fcvtzs.4s	v8, v8
	scvtf.4s	v10, v8
	fmul.4s	v15, v10, v25
	fsub.4s	v29, v29, v15
	fmul.4s	v10, v10, v27
	fsub.4s	v29, v29, v10
	fmul.4s	v28, v28, v27
	fsub.4s	v21, v21, v28
	fmul.4s	v28, v21, v9
	fadd.4s	v28, v28, v11
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v7
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v16
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v30
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v13
	fmul.4s	v10, v21, v21
	fmul.4s	v28, v10, v28
	fmul.4s	v10, v29, v9
	fadd.4s	v10, v10, v11
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v7
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v16
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v30
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v13
	fmul.4s	v15, v29, v29
	fmul.4s	v10, v15, v10
	fadd.4s	v29, v29, v10
	fadd.4s	v21, v21, v28
	fadd.4s	v28, v29, v26
	sshr.4s	v29, v8, #1
	shl.4s	v10, v29, #23
	add.4s	v10, v10, v26
	fmul.4s	v28, v28, v10
	fadd.4s	v21, v21, v26
	sshr.4s	v10, v6, #1
	shl.4s	v15, v10, #23
	add.4s	v15, v15, v26
	fmul.4s	v21, v21, v15
	sub.4s	v29, v8, v29
	sub.4s	v6, v6, v10
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v26
	fmul.4s	v6, v21, v6
	shl.4s	v21, v29, #23
	add.4s	v21, v21, v26
	fmul.4s	v21, v28, v21
	str	q18, [sp, #448]                 ; 16-byte Spill
	fcmgt.4s	v28, v19, v18
	bic.16b	v21, v21, v28
	str	q12, [sp, #608]                 ; 16-byte Spill
	fcmgt.4s	v28, v19, v12
	bic.16b	v6, v6, v28
	fcmgt.4s	v28, v12, v17
	bit.16b	v6, v31, v28
	str	q6, [sp, #672]                  ; 16-byte Spill
	fcmgt.4s	v6, v18, v17
	bsl.16b	v6, v31, v21
	str	q6, [sp, #656]                  ; 16-byte Spill
	ldp	q5, q4, [sp, #544]              ; 32-byte Folded Reload
	fsub.4s	v6, v5, v3
	and.16b	v18, v0, v6
	fcmge.4s	v6, v18, v19
	fcmge.4s	v21, v17, v18
	and.16b	v6, v6, v21
	fsub.4s	v21, v4, v2
	and.16b	v12, v1, v21
	fcmge.4s	v21, v12, v19
	fcmge.4s	v28, v17, v12
	and.16b	v21, v21, v28
	and.16b	v21, v21, v12
	fmul.4s	v28, v21, v22
	mov.16b	v29, v24
	bsl.16b	v29, v23, v28
	fadd.4s	v28, v28, v29
	fsub.4s	v28, v28, v29
	and.16b	v29, v6, v18
	fmul.4s	v6, v29, v22
	mov.16b	v8, v24
	bsl.16b	v8, v23, v6
	fadd.4s	v6, v6, v8
	fsub.4s	v8, v6, v8
	fcvtzs.4s	v6, v28
	scvtf.4s	v28, v6
	fmul.4s	v10, v28, v25
	fsub.4s	v21, v21, v10
	fcvtzs.4s	v8, v8
	scvtf.4s	v10, v8
	fmul.4s	v15, v10, v25
	fsub.4s	v29, v29, v15
	fmul.4s	v10, v10, v27
	fsub.4s	v29, v29, v10
	fmul.4s	v28, v28, v27
	fsub.4s	v21, v21, v28
	fmul.4s	v28, v21, v9
	fadd.4s	v28, v28, v11
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v7
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v16
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v30
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v13
	fmul.4s	v10, v21, v21
	fmul.4s	v28, v10, v28
	fmul.4s	v10, v29, v9
	fadd.4s	v10, v10, v11
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v7
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v16
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v30
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v13
	fmul.4s	v15, v29, v29
	fmul.4s	v10, v15, v10
	fadd.4s	v29, v29, v10
	fadd.4s	v21, v21, v28
	fadd.4s	v28, v29, v26
	sshr.4s	v29, v8, #1
	shl.4s	v10, v29, #23
	add.4s	v10, v10, v26
	fmul.4s	v28, v28, v10
	fadd.4s	v21, v21, v26
	sshr.4s	v10, v6, #1
	shl.4s	v15, v10, #23
	add.4s	v15, v15, v26
	fmul.4s	v21, v21, v15
	sub.4s	v29, v8, v29
	sub.4s	v6, v6, v10
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v26
	fmul.4s	v6, v21, v6
	shl.4s	v21, v29, #23
	add.4s	v21, v21, v26
	fmul.4s	v21, v28, v21
	str	q18, [sp, #416]                 ; 16-byte Spill
	fcmgt.4s	v28, v19, v18
	bic.16b	v21, v21, v28
	str	q12, [sp, #512]                 ; 16-byte Spill
	fcmgt.4s	v28, v19, v12
	bic.16b	v6, v6, v28
	fcmgt.4s	v28, v12, v17
	bit.16b	v6, v31, v28
	str	q6, [sp, #560]                  ; 16-byte Spill
	fcmgt.4s	v6, v18, v17
	bsl.16b	v6, v31, v21
	str	q6, [sp, #544]                  ; 16-byte Spill
	ldr	q4, [sp, #496]                  ; 16-byte Reload
	fsub.4s	v6, v4, v2
	and.16b	v4, v1, v6
	fcmge.4s	v6, v4, v19
	fcmge.4s	v21, v17, v4
	and.16b	v6, v6, v21
	ldr	q21, [sp, #576]                 ; 16-byte Reload
	fsub.4s	v21, v21, v3
	and.16b	v12, v0, v21
	fcmge.4s	v21, v12, v19
	fcmge.4s	v28, v17, v12
	and.16b	v21, v21, v28
	and.16b	v21, v21, v12
	fmul.4s	v28, v21, v22
	mov.16b	v29, v24
	bsl.16b	v29, v23, v28
	fadd.4s	v28, v28, v29
	fsub.4s	v28, v28, v29
	and.16b	v29, v6, v4
	fmul.4s	v6, v29, v22
	mov.16b	v8, v24
	bsl.16b	v8, v23, v6
	fadd.4s	v6, v6, v8
	fsub.4s	v8, v6, v8
	fcvtzs.4s	v6, v28
	scvtf.4s	v28, v6
	fmul.4s	v10, v28, v25
	fsub.4s	v21, v21, v10
	fcvtzs.4s	v8, v8
	scvtf.4s	v10, v8
	fmul.4s	v15, v10, v25
	fsub.4s	v29, v29, v15
	fmul.4s	v10, v10, v27
	fsub.4s	v29, v29, v10
	fmul.4s	v28, v28, v27
	fsub.4s	v21, v21, v28
	fmul.4s	v28, v21, v9
	fadd.4s	v28, v28, v11
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v7
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v16
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v30
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v13
	fmul.4s	v10, v21, v21
	fmul.4s	v28, v10, v28
	fmul.4s	v10, v29, v9
	fadd.4s	v10, v10, v11
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v7
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v16
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v30
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v13
	fmul.4s	v15, v29, v29
	fmul.4s	v10, v15, v10
	fadd.4s	v29, v29, v10
	fadd.4s	v21, v21, v28
	fadd.4s	v28, v29, v26
	sshr.4s	v29, v8, #1
	shl.4s	v10, v29, #23
	add.4s	v10, v10, v26
	fmul.4s	v28, v28, v10
	fadd.4s	v21, v21, v26
	sshr.4s	v10, v6, #1
	shl.4s	v15, v10, #23
	add.4s	v15, v15, v26
	fmul.4s	v21, v21, v15
	sub.4s	v29, v8, v29
	sub.4s	v6, v6, v10
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v26
	fmul.4s	v6, v21, v6
	shl.4s	v21, v29, #23
	add.4s	v21, v21, v26
	fmul.4s	v21, v28, v21
	str	q4, [sp, #400]                  ; 16-byte Spill
	fcmgt.4s	v28, v19, v4
	bic.16b	v21, v21, v28
	str	q12, [sp, #464]                 ; 16-byte Spill
	fcmgt.4s	v28, v19, v12
	bic.16b	v6, v6, v28
	fcmgt.4s	v28, v12, v17
	bit.16b	v6, v31, v28
	str	q6, [sp, #576]                  ; 16-byte Spill
	fcmgt.4s	v6, v4, v17
	bsl.16b	v6, v31, v21
	str	q6, [sp, #496]                  ; 16-byte Spill
	ldr	q6, [sp, #592]                  ; 16-byte Reload
	fsub.4s	v6, v6, v2
	and.16b	v4, v1, v6
	fcmge.4s	v6, v4, v19
	fcmge.4s	v21, v17, v4
	and.16b	v6, v6, v21
	ldr	q21, [sp, #640]                 ; 16-byte Reload
	fsub.4s	v21, v21, v3
	and.16b	v12, v0, v21
	fcmge.4s	v21, v12, v19
	fcmge.4s	v28, v17, v12
	and.16b	v21, v21, v28
	and.16b	v21, v21, v12
	fmul.4s	v28, v21, v22
	mov.16b	v29, v24
	bsl.16b	v29, v23, v28
	fadd.4s	v28, v28, v29
	fsub.4s	v28, v28, v29
	and.16b	v29, v6, v4
	fmul.4s	v6, v29, v22
	mov.16b	v8, v24
	bsl.16b	v8, v23, v6
	fadd.4s	v6, v6, v8
	fsub.4s	v8, v6, v8
	fcvtzs.4s	v6, v28
	scvtf.4s	v28, v6
	fmul.4s	v10, v28, v25
	fsub.4s	v21, v21, v10
	fcvtzs.4s	v8, v8
	scvtf.4s	v10, v8
	fmul.4s	v15, v10, v25
	fsub.4s	v29, v29, v15
	fmul.4s	v10, v10, v27
	fsub.4s	v29, v29, v10
	fmul.4s	v28, v28, v27
	fsub.4s	v21, v21, v28
	fmul.4s	v28, v21, v9
	fadd.4s	v28, v28, v11
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v7
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v16
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v30
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v13
	fmul.4s	v10, v21, v21
	fmul.4s	v28, v10, v28
	fmul.4s	v10, v29, v9
	fadd.4s	v10, v10, v11
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v7
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v16
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v30
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v13
	fmul.4s	v15, v29, v29
	fmul.4s	v10, v15, v10
	fadd.4s	v29, v29, v10
	fadd.4s	v21, v21, v28
	fadd.4s	v28, v29, v26
	sshr.4s	v29, v8, #1
	shl.4s	v10, v29, #23
	add.4s	v10, v10, v26
	fmul.4s	v28, v28, v10
	fadd.4s	v21, v21, v26
	sshr.4s	v10, v6, #1
	shl.4s	v15, v10, #23
	add.4s	v15, v15, v26
	fmul.4s	v21, v21, v15
	sub.4s	v29, v8, v29
	sub.4s	v6, v6, v10
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v26
	fmul.4s	v6, v21, v6
	shl.4s	v21, v29, #23
	add.4s	v21, v21, v26
	fmul.4s	v21, v28, v21
	str	q4, [sp, #384]                  ; 16-byte Spill
	fcmgt.4s	v28, v19, v4
	bic.16b	v21, v21, v28
	str	q12, [sp, #432]                 ; 16-byte Spill
	fcmgt.4s	v28, v19, v12
	bic.16b	v6, v6, v28
	fcmgt.4s	v28, v12, v17
	bit.16b	v6, v31, v28
	str	q6, [sp, #640]                  ; 16-byte Spill
	fcmgt.4s	v6, v4, v17
	bsl.16b	v6, v31, v21
	str	q6, [sp, #592]                  ; 16-byte Spill
	ldr	q6, [sp, #688]                  ; 16-byte Reload
	fsub.4s	v6, v6, v2
	and.16b	v4, v1, v6
	fcmge.4s	v6, v4, v19
	fcmge.4s	v21, v17, v4
	and.16b	v6, v6, v21
	ldr	q21, [sp, #720]                 ; 16-byte Reload
	fsub.4s	v21, v21, v3
	and.16b	v12, v0, v21
	fcmge.4s	v21, v12, v19
	fcmge.4s	v28, v17, v12
	and.16b	v21, v21, v28
	and.16b	v21, v21, v12
	fmul.4s	v28, v21, v22
	mov.16b	v29, v24
	bsl.16b	v29, v23, v28
	fadd.4s	v28, v28, v29
	fsub.4s	v28, v28, v29
	and.16b	v29, v6, v4
	fmul.4s	v6, v29, v22
	mov.16b	v8, v24
	bsl.16b	v8, v23, v6
	fadd.4s	v6, v6, v8
	fsub.4s	v8, v6, v8
	fcvtzs.4s	v6, v28
	scvtf.4s	v28, v6
	fmul.4s	v10, v28, v25
	fsub.4s	v21, v21, v10
	fcvtzs.4s	v8, v8
	scvtf.4s	v10, v8
	fmul.4s	v15, v10, v25
	fsub.4s	v29, v29, v15
	fmul.4s	v10, v10, v27
	fsub.4s	v29, v29, v10
	fmul.4s	v28, v28, v27
	fsub.4s	v21, v21, v28
	fmul.4s	v28, v21, v9
	fadd.4s	v28, v28, v11
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v7
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v16
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v30
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v13
	fmul.4s	v10, v21, v21
	fmul.4s	v28, v10, v28
	fmul.4s	v10, v29, v9
	fadd.4s	v10, v10, v11
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v7
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v16
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v30
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v13
	fmul.4s	v15, v29, v29
	fmul.4s	v10, v15, v10
	fadd.4s	v29, v29, v10
	fadd.4s	v21, v21, v28
	fadd.4s	v28, v29, v26
	sshr.4s	v29, v8, #1
	shl.4s	v10, v29, #23
	add.4s	v10, v10, v26
	fmul.4s	v28, v28, v10
	fadd.4s	v21, v21, v26
	sshr.4s	v10, v6, #1
	shl.4s	v15, v10, #23
	add.4s	v15, v15, v26
	fmul.4s	v21, v21, v15
	sub.4s	v29, v8, v29
	sub.4s	v6, v6, v10
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v26
	fmul.4s	v6, v21, v6
	shl.4s	v21, v29, #23
	add.4s	v21, v21, v26
	fmul.4s	v21, v28, v21
	str	q4, [sp, #336]                  ; 16-byte Spill
	fcmgt.4s	v28, v19, v4
	bic.16b	v21, v21, v28
	str	q12, [sp, #368]                 ; 16-byte Spill
	fcmgt.4s	v28, v19, v12
	bic.16b	v6, v6, v28
	fcmgt.4s	v28, v12, v17
	bit.16b	v6, v31, v28
	str	q6, [sp, #720]                  ; 16-byte Spill
	fcmgt.4s	v6, v4, v17
	bsl.16b	v6, v31, v21
	str	q6, [sp, #688]                  ; 16-byte Spill
	ldr	q6, [sp, #784]                  ; 16-byte Reload
	fsub.4s	v6, v6, v2
	and.16b	v4, v1, v6
	fcmge.4s	v6, v4, v19
	fcmge.4s	v21, v17, v4
	and.16b	v6, v6, v21
	ldr	q21, [sp, #800]                 ; 16-byte Reload
	fsub.4s	v21, v21, v3
	and.16b	v20, v0, v21
	fcmge.4s	v21, v20, v19
	fcmge.4s	v28, v17, v20
	and.16b	v21, v21, v28
	and.16b	v21, v21, v20
	fmul.4s	v28, v21, v22
	mov.16b	v29, v24
	bsl.16b	v29, v23, v28
	fadd.4s	v28, v28, v29
	fsub.4s	v28, v28, v29
	and.16b	v29, v6, v4
	fmul.4s	v6, v29, v22
	mov.16b	v8, v24
	bsl.16b	v8, v23, v6
	fadd.4s	v6, v6, v8
	fsub.4s	v8, v6, v8
	fcvtzs.4s	v6, v28
	scvtf.4s	v28, v6
	fmul.4s	v10, v28, v25
	fsub.4s	v21, v21, v10
	fcvtzs.4s	v8, v8
	scvtf.4s	v10, v8
	fmul.4s	v15, v10, v25
	fsub.4s	v29, v29, v15
	fmul.4s	v10, v10, v27
	fsub.4s	v29, v29, v10
	fmul.4s	v28, v28, v27
	fsub.4s	v21, v21, v28
	fmul.4s	v28, v21, v9
	fadd.4s	v28, v28, v11
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v7
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v16
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v30
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v13
	fmul.4s	v10, v21, v21
	fmul.4s	v28, v10, v28
	fmul.4s	v10, v29, v9
	fadd.4s	v10, v10, v11
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v7
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v16
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v30
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v13
	fmul.4s	v15, v29, v29
	fmul.4s	v10, v15, v10
	fadd.4s	v29, v29, v10
	fadd.4s	v21, v21, v28
	fadd.4s	v28, v29, v26
	sshr.4s	v29, v8, #1
	shl.4s	v10, v29, #23
	add.4s	v10, v10, v26
	fmul.4s	v28, v28, v10
	fadd.4s	v21, v21, v26
	sshr.4s	v10, v6, #1
	shl.4s	v15, v10, #23
	add.4s	v15, v15, v26
	fmul.4s	v21, v21, v15
	sub.4s	v29, v8, v29
	sub.4s	v6, v6, v10
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v26
	fmul.4s	v6, v21, v6
	shl.4s	v21, v29, #23
	add.4s	v21, v21, v26
	fmul.4s	v21, v28, v21
	str	q4, [sp, #272]                  ; 16-byte Spill
	fcmgt.4s	v28, v19, v4
	bic.16b	v21, v21, v28
	str	q20, [sp, #352]                 ; 16-byte Spill
	fcmgt.4s	v28, v19, v20
	bic.16b	v6, v6, v28
	fcmgt.4s	v28, v20, v17
	bit.16b	v6, v31, v28
	str	q6, [sp, #800]                  ; 16-byte Spill
	fcmgt.4s	v6, v4, v17
	bsl.16b	v6, v31, v21
	str	q6, [sp, #784]                  ; 16-byte Spill
	ldr	q6, [sp, #880]                  ; 16-byte Reload
	fsub.4s	v6, v6, v3
	and.16b	v4, v0, v6
	fcmge.4s	v6, v4, v19
	fcmge.4s	v21, v17, v4
	and.16b	v6, v6, v21
	ldr	q21, [sp, #896]                 ; 16-byte Reload
	fsub.4s	v21, v21, v2
	and.16b	v20, v1, v21
	fcmge.4s	v21, v20, v19
	fcmge.4s	v28, v17, v20
	and.16b	v21, v21, v28
	and.16b	v21, v21, v20
	fmul.4s	v28, v21, v22
	mov.16b	v29, v24
	bsl.16b	v29, v23, v28
	fadd.4s	v28, v28, v29
	fsub.4s	v28, v28, v29
	and.16b	v29, v6, v4
	fmul.4s	v6, v29, v22
	mov.16b	v8, v24
	bsl.16b	v8, v23, v6
	fadd.4s	v6, v6, v8
	fsub.4s	v8, v6, v8
	fcvtzs.4s	v6, v28
	scvtf.4s	v28, v6
	fmul.4s	v10, v28, v25
	fsub.4s	v21, v21, v10
	fcvtzs.4s	v8, v8
	scvtf.4s	v10, v8
	fmul.4s	v15, v10, v25
	fsub.4s	v29, v29, v15
	fmul.4s	v10, v10, v27
	fsub.4s	v29, v29, v10
	fmul.4s	v28, v28, v27
	fsub.4s	v21, v21, v28
	fmul.4s	v28, v21, v9
	fadd.4s	v28, v28, v11
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v7
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v16
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v30
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v13
	fmul.4s	v10, v21, v21
	fmul.4s	v28, v10, v28
	fmul.4s	v10, v29, v9
	fadd.4s	v10, v10, v11
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v7
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v16
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v30
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v13
	fmul.4s	v15, v29, v29
	fmul.4s	v10, v15, v10
	fadd.4s	v29, v29, v10
	fadd.4s	v21, v21, v28
	fadd.4s	v28, v29, v26
	sshr.4s	v29, v8, #1
	shl.4s	v10, v29, #23
	add.4s	v10, v10, v26
	fmul.4s	v28, v28, v10
	fadd.4s	v21, v21, v26
	sshr.4s	v10, v6, #1
	shl.4s	v15, v10, #23
	add.4s	v15, v15, v26
	fmul.4s	v21, v21, v15
	sub.4s	v29, v8, v29
	sub.4s	v6, v6, v10
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v26
	fmul.4s	v6, v21, v6
	shl.4s	v21, v29, #23
	add.4s	v21, v21, v26
	fmul.4s	v21, v28, v21
	str	q4, [sp, #160]                  ; 16-byte Spill
	fcmgt.4s	v28, v19, v4
	bic.16b	v21, v21, v28
	str	q20, [sp, #288]                 ; 16-byte Spill
	fcmgt.4s	v28, v19, v20
	bic.16b	v6, v6, v28
	fcmgt.4s	v28, v20, v17
	bit.16b	v6, v31, v28
	str	q6, [sp, #896]                  ; 16-byte Spill
	fcmgt.4s	v6, v4, v17
	bsl.16b	v6, v31, v21
	str	q6, [sp, #880]                  ; 16-byte Spill
	ldr	q6, [sp, #1056]                 ; 16-byte Reload
	fsub.4s	v6, v6, v2
	and.16b	v14, v1, v6
	fcmge.4s	v6, v14, v19
	fcmge.4s	v21, v17, v14
	and.16b	v6, v6, v21
	ldr	q21, [sp, #1072]                ; 16-byte Reload
	fsub.4s	v21, v21, v3
	and.16b	v20, v0, v21
	fcmge.4s	v21, v20, v19
	fcmge.4s	v28, v17, v20
	and.16b	v21, v21, v28
	and.16b	v21, v21, v20
	fmul.4s	v28, v21, v22
	mov.16b	v29, v24
	bsl.16b	v29, v23, v28
	fadd.4s	v28, v28, v29
	fsub.4s	v28, v28, v29
	and.16b	v29, v6, v14
	fmul.4s	v6, v29, v22
	mov.16b	v8, v24
	bsl.16b	v8, v23, v6
	fadd.4s	v6, v6, v8
	fsub.4s	v8, v6, v8
	fcvtzs.4s	v6, v28
	scvtf.4s	v28, v6
	fmul.4s	v10, v28, v25
	fsub.4s	v21, v21, v10
	fcvtzs.4s	v8, v8
	scvtf.4s	v10, v8
	fmul.4s	v15, v10, v25
	fsub.4s	v29, v29, v15
	fmul.4s	v10, v10, v27
	fsub.4s	v29, v29, v10
	fmul.4s	v28, v28, v27
	fsub.4s	v21, v21, v28
	fmul.4s	v28, v21, v9
	fadd.4s	v28, v28, v11
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v7
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v16
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v30
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v13
	fmul.4s	v10, v21, v21
	fmul.4s	v28, v10, v28
	fmul.4s	v10, v29, v9
	fadd.4s	v10, v10, v11
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v7
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v16
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v30
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v13
	fmul.4s	v15, v29, v29
	fmul.4s	v10, v15, v10
	fadd.4s	v29, v29, v10
	fadd.4s	v21, v21, v28
	fadd.4s	v28, v29, v26
	sshr.4s	v29, v8, #1
	shl.4s	v10, v29, #23
	add.4s	v10, v10, v26
	fmul.4s	v28, v28, v10
	fadd.4s	v21, v21, v26
	sshr.4s	v10, v6, #1
	shl.4s	v15, v10, #23
	add.4s	v15, v15, v26
	fmul.4s	v21, v21, v15
	sub.4s	v29, v8, v29
	sub.4s	v6, v6, v10
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v26
	fmul.4s	v6, v21, v6
	shl.4s	v21, v29, #23
	add.4s	v21, v21, v26
	fmul.4s	v21, v28, v21
	fcmgt.4s	v28, v19, v14
	bic.16b	v21, v21, v28
	str	q20, [sp, #240]                 ; 16-byte Spill
	fcmgt.4s	v28, v19, v20
	bic.16b	v6, v6, v28
	fcmgt.4s	v28, v20, v17
	bit.16b	v6, v31, v28
	str	q6, [sp, #320]                  ; 16-byte Spill
	fcmgt.4s	v6, v14, v17
	bsl.16b	v6, v31, v21
	str	q6, [sp, #304]                  ; 16-byte Spill
	ldr	q6, [sp, #1744]                 ; 16-byte Reload
	fsub.4s	v6, v6, v2
	and.16b	v18, v1, v6
	fcmge.4s	v6, v18, v19
	fcmge.4s	v21, v17, v18
	and.16b	v6, v6, v21
	ldr	q21, [sp, #1760]                ; 16-byte Reload
	fsub.4s	v21, v21, v3
	and.16b	v20, v0, v21
	fcmge.4s	v21, v20, v19
	fcmge.4s	v28, v17, v20
	and.16b	v21, v21, v28
	and.16b	v21, v21, v20
	fmul.4s	v28, v21, v22
	mov.16b	v29, v24
	bsl.16b	v29, v23, v28
	fadd.4s	v28, v28, v29
	fsub.4s	v28, v28, v29
	and.16b	v29, v6, v18
	fmul.4s	v6, v29, v22
	mov.16b	v8, v24
	bsl.16b	v8, v23, v6
	fadd.4s	v6, v6, v8
	fsub.4s	v8, v6, v8
	fcvtzs.4s	v6, v28
	scvtf.4s	v28, v6
	fmul.4s	v10, v28, v25
	fsub.4s	v21, v21, v10
	fcvtzs.4s	v8, v8
	scvtf.4s	v10, v8
	fmul.4s	v15, v10, v25
	fsub.4s	v29, v29, v15
	fmul.4s	v10, v10, v27
	fsub.4s	v29, v29, v10
	fmul.4s	v28, v28, v27
	fsub.4s	v21, v21, v28
	fmul.4s	v28, v21, v9
	fadd.4s	v28, v28, v11
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v7
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v16
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v30
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v13
	fmul.4s	v10, v21, v21
	fmul.4s	v28, v10, v28
	fmul.4s	v10, v29, v9
	fadd.4s	v10, v10, v11
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v7
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v16
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v30
	fmul.4s	v10, v29, v10
	fadd.4s	v10, v10, v13
	fmul.4s	v15, v29, v29
	fmul.4s	v10, v15, v10
	fadd.4s	v29, v29, v10
	fadd.4s	v21, v21, v28
	fadd.4s	v28, v29, v26
	sshr.4s	v29, v8, #1
	shl.4s	v10, v29, #23
	add.4s	v10, v10, v26
	fmul.4s	v28, v28, v10
	fadd.4s	v21, v21, v26
	sshr.4s	v10, v6, #1
	shl.4s	v15, v10, #23
	add.4s	v15, v15, v26
	fmul.4s	v21, v21, v15
	sub.4s	v29, v8, v29
	sub.4s	v6, v6, v10
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v26
	fmul.4s	v6, v21, v6
	shl.4s	v21, v29, #23
	add.4s	v21, v21, v26
	fmul.4s	v21, v28, v21
	fcmgt.4s	v28, v19, v18
	bic.16b	v21, v21, v28
	fcmgt.4s	v28, v19, v20
	bic.16b	v6, v6, v28
	fcmgt.4s	v28, v20, v17
	bit.16b	v6, v31, v28
	str	q6, [sp, #1760]                 ; 16-byte Spill
	fcmgt.4s	v6, v18, v17
	bsl.16b	v6, v31, v21
	str	q6, [sp, #1744]                 ; 16-byte Spill
	str	q3, [sp, #1056]                 ; 16-byte Spill
	ldr	q6, [sp, #2416]                 ; 16-byte Reload
	fsub.4s	v6, v6, v3
	and.16b	v5, v0, v6
	fcmge.4s	v6, v5, v19
	fcmge.4s	v21, v17, v5
	and.16b	v6, v6, v21
	str	q2, [sp, #1072]                 ; 16-byte Spill
	ldr	q3, [sp, #2400]                 ; 16-byte Reload
	fsub.4s	v21, v3, v2
	and.16b	v3, v1, v21
	fcmge.4s	v21, v3, v19
	fcmge.4s	v28, v17, v3
	and.16b	v21, v21, v28
	and.16b	v21, v21, v3
	fmul.4s	v28, v21, v22
	mov.16b	v29, v24
	bsl.16b	v29, v23, v28
	fadd.4s	v28, v28, v29
	fsub.4s	v28, v28, v29
	and.16b	v6, v6, v5
	fmul.4s	v29, v6, v22
	mov.16b	v8, v24
	bsl.16b	v8, v23, v29
	fadd.4s	v29, v29, v8
	fsub.4s	v29, v29, v8
	fcvtzs.4s	v28, v28
	scvtf.4s	v8, v28
	fmul.4s	v10, v8, v25
	fsub.4s	v21, v21, v10
	fcvtzs.4s	v29, v29
	scvtf.4s	v10, v29
	fmul.4s	v15, v10, v25
	fsub.4s	v6, v6, v15
	fmul.4s	v8, v8, v27
	fmul.4s	v10, v10, v27
	fsub.4s	v6, v6, v10
	fsub.4s	v21, v21, v8
	fmul.4s	v8, v21, v9
	fmul.4s	v10, v6, v9
	fadd.4s	v10, v10, v11
	fadd.4s	v8, v8, v11
	fmul.4s	v8, v21, v8
	fmul.4s	v10, v6, v10
	fadd.4s	v10, v10, v7
	fadd.4s	v8, v8, v7
	fmul.4s	v8, v21, v8
	fmul.4s	v10, v6, v10
	fadd.4s	v10, v10, v16
	fadd.4s	v8, v8, v16
	fmul.4s	v8, v21, v8
	fmul.4s	v10, v6, v10
	fadd.4s	v10, v10, v30
	fadd.4s	v8, v8, v30
	fmul.4s	v8, v21, v8
	fadd.4s	v8, v8, v13
	fmul.4s	v15, v21, v21
	fmul.4s	v8, v15, v8
	fmul.4s	v10, v6, v10
	fadd.4s	v10, v10, v13
	fmul.4s	v15, v6, v6
	fmul.4s	v10, v15, v10
	fadd.4s	v6, v6, v10
	fadd.4s	v21, v21, v8
	fadd.4s	v6, v6, v26
	sshr.4s	v8, v29, #1
	shl.4s	v10, v8, #23
	add.4s	v10, v10, v26
	fmul.4s	v6, v6, v10
	fadd.4s	v21, v21, v26
	sshr.4s	v10, v28, #1
	shl.4s	v15, v10, #23
	add.4s	v15, v15, v26
	fmul.4s	v21, v21, v15
	sub.4s	v29, v29, v8
	sub.4s	v28, v28, v10
	shl.4s	v28, v28, #23
	add.4s	v28, v28, v26
	fmul.4s	v21, v21, v28
	shl.4s	v28, v29, #23
	add.4s	v28, v28, v26
	fmul.4s	v6, v6, v28
	fcmgt.4s	v28, v19, v5
	bic.16b	v6, v6, v28
	fcmgt.4s	v28, v19, v3
	bic.16b	v21, v21, v28
	fcmgt.4s	v28, v3, v17
	mov.16b	v2, v28
	bsl.16b	v2, v31, v21
	stp	q3, q2, [sp, #208]              ; 32-byte Folded Spill
	fcmgt.4s	v21, v5, v17
	mov.16b	v2, v21
	bsl.16b	v2, v31, v6
	stp	q5, q2, [sp, #176]              ; 32-byte Folded Spill
	ldr	q2, [sp, #832]                  ; 16-byte Reload
	fcmeq.4s	v6, v2, v2
	ldr	q10, [sp, #96]                  ; 16-byte Reload
	ldr	q2, [sp, #2384]                 ; 16-byte Reload
	bif.16b	v2, v10, v6
	str	q2, [sp, #2384]                 ; 16-byte Spill
	ldr	q2, [sp, #736]                  ; 16-byte Reload
	fcmeq.4s	v6, v2, v2
	ldr	q2, [sp, #1888]                 ; 16-byte Reload
	mov.16b	v3, v6
	bsl.16b	v3, v2, v10
	str	q3, [sp, #1888]                 ; 16-byte Spill
	ldr	q2, [sp, #1792]                 ; 16-byte Reload
	fcmeq.4s	v6, v2, v2
	ldr	q2, [sp, #1856]                 ; 16-byte Reload
	mov.16b	v21, v6
	bsl.16b	v21, v2, v10
	ldr	q2, [sp, #1840]                 ; 16-byte Reload
	fcmeq.4s	v6, v2, v2
	ldr	q2, [sp, #1872]                 ; 16-byte Reload
	mov.16b	v28, v6
	bsl.16b	v28, v2, v10
	ldr	q2, [sp, #992]                  ; 16-byte Reload
	fcmeq.4s	v6, v2, v2
	ldr	q2, [sp, #1808]                 ; 16-byte Reload
	mov.16b	v16, v6
	bsl.16b	v16, v2, v10
	ldr	q2, [sp, #1776]                 ; 16-byte Reload
	fcmeq.4s	v6, v2, v2
	ldr	q2, [sp, #1824]                 ; 16-byte Reload
	bsl.16b	v6, v2, v10
	ldr	q2, [sp, #928]                  ; 16-byte Reload
	fcmeq.4s	v29, v2, v2
	ldr	q2, [sp, #1712]                 ; 16-byte Reload
	mov.16b	v5, v29
	bsl.16b	v5, v2, v10
	ldr	q2, [sp, #976]                  ; 16-byte Reload
	fcmeq.4s	v29, v2, v2
	ldr	q2, [sp, #1728]                 ; 16-byte Reload
	mov.16b	v8, v29
	bsl.16b	v8, v2, v10
	ldr	q2, [sp, #624]                  ; 16-byte Reload
	fcmeq.4s	v29, v2, v2
	ldr	q2, [sp, #944]                  ; 16-byte Reload
	mov.16b	v17, v29
	bsl.16b	v17, v2, v10
	ldr	q2, [sp, #912]                  ; 16-byte Reload
	fcmeq.4s	v29, v2, v2
	ldr	q2, [sp, #960]                  ; 16-byte Reload
	mov.16b	v22, v29
	bsl.16b	v22, v2, v10
	ldr	q2, [sp, #528]                  ; 16-byte Reload
	fcmeq.4s	v29, v2, v2
	ldr	q2, [sp, #848]                  ; 16-byte Reload
	mov.16b	v27, v29
	bsl.16b	v27, v2, v10
	ldr	q2, [sp, #816]                  ; 16-byte Reload
	fcmeq.4s	v29, v2, v2
	ldr	q2, [sp, #864]                  ; 16-byte Reload
	bif.16b	v2, v10, v29
	str	q2, [sp, #1792]                 ; 16-byte Spill
	ldr	q2, [sp, #480]                  ; 16-byte Reload
	fcmeq.4s	v29, v2, v2
	ldr	q2, [sp, #752]                  ; 16-byte Reload
	mov.16b	v19, v29
	bsl.16b	v19, v2, v10
	ldr	q2, [sp, #704]                  ; 16-byte Reload
	fcmeq.4s	v29, v2, v2
	ldr	q2, [sp, #768]                  ; 16-byte Reload
	mov.16b	v11, v29
	bsl.16b	v11, v2, v10
	ldr	q2, [sp, #448]                  ; 16-byte Reload
	fcmeq.4s	v29, v2, v2
	ldr	q2, [sp, #656]                  ; 16-byte Reload
	mov.16b	v25, v29
	bsl.16b	v25, v2, v10
	ldr	q2, [sp, #608]                  ; 16-byte Reload
	fcmeq.4s	v29, v2, v2
	ldr	q2, [sp, #672]                  ; 16-byte Reload
	mov.16b	v9, v29
	bsl.16b	v9, v2, v10
	ldr	q2, [sp, #416]                  ; 16-byte Reload
	fcmeq.4s	v29, v2, v2
	ldr	q2, [sp, #544]                  ; 16-byte Reload
	mov.16b	v7, v29
	bsl.16b	v7, v2, v10
	ldr	q2, [sp, #512]                  ; 16-byte Reload
	fcmeq.4s	v29, v2, v2
	ldr	q2, [sp, #560]                  ; 16-byte Reload
	mov.16b	v26, v29
	bsl.16b	v26, v2, v10
	ldr	q2, [sp, #400]                  ; 16-byte Reload
	fcmeq.4s	v29, v2, v2
	ldr	q2, [sp, #496]                  ; 16-byte Reload
	mov.16b	v24, v29
	bsl.16b	v24, v2, v10
	ldr	q2, [sp, #464]                  ; 16-byte Reload
	fcmeq.4s	v29, v2, v2
	ldr	q2, [sp, #576]                  ; 16-byte Reload
	bif.16b	v2, v10, v29
	str	q2, [sp, #1776]                 ; 16-byte Spill
	ldr	q2, [sp, #384]                  ; 16-byte Reload
	fcmeq.4s	v29, v2, v2
	ldr	q2, [sp, #592]                  ; 16-byte Reload
	mov.16b	v31, v29
	bsl.16b	v31, v2, v10
	ldr	q2, [sp, #432]                  ; 16-byte Reload
	fcmeq.4s	v29, v2, v2
	ldr	q2, [sp, #640]                  ; 16-byte Reload
	bif.16b	v2, v10, v29
	str	q2, [sp, #944]                  ; 16-byte Spill
	ldr	q2, [sp, #336]                  ; 16-byte Reload
	fcmeq.4s	v29, v2, v2
	ldr	q2, [sp, #688]                  ; 16-byte Reload
	mov.16b	v30, v29
	bsl.16b	v30, v2, v10
	ldr	q2, [sp, #368]                  ; 16-byte Reload
	fcmeq.4s	v29, v2, v2
	ldr	q2, [sp, #720]                  ; 16-byte Reload
	bif.16b	v2, v10, v29
	str	q2, [sp, #960]                  ; 16-byte Spill
	ldr	q2, [sp, #272]                  ; 16-byte Reload
	fcmeq.4s	v29, v2, v2
	ldr	q2, [sp, #784]                  ; 16-byte Reload
	mov.16b	v23, v29
	bsl.16b	v23, v2, v10
	ldr	q2, [sp, #352]                  ; 16-byte Reload
	fcmeq.4s	v29, v2, v2
	ldr	q2, [sp, #800]                  ; 16-byte Reload
	mov.16b	v13, v29
	bsl.16b	v13, v2, v10
	ldr	q2, [sp, #160]                  ; 16-byte Reload
	fcmeq.4s	v29, v2, v2
	ldr	q2, [sp, #880]                  ; 16-byte Reload
	mov.16b	v4, v29
	bsl.16b	v4, v2, v10
	ldr	q2, [sp, #288]                  ; 16-byte Reload
	fcmeq.4s	v29, v2, v2
	ldr	q2, [sp, #896]                  ; 16-byte Reload
	bif.16b	v2, v10, v29
	str	q2, [sp, #1728]                 ; 16-byte Spill
	fcmeq.4s	v29, v14, v14
	ldr	q2, [sp, #304]                  ; 16-byte Reload
	mov.16b	v12, v29
	bsl.16b	v12, v2, v10
	ldr	q2, [sp, #240]                  ; 16-byte Reload
	fcmeq.4s	v29, v2, v2
	ldr	q2, [sp, #320]                  ; 16-byte Reload
	bif.16b	v2, v10, v29
	str	q2, [sp, #1712]                 ; 16-byte Spill
	fcmeq.4s	v29, v18, v18
	ldr	q2, [sp, #1744]                 ; 16-byte Reload
	bif.16b	v2, v10, v29
	str	q2, [sp, #992]                  ; 16-byte Spill
	fcmeq.4s	v29, v20, v20
	ldr	q2, [sp, #1760]                 ; 16-byte Reload
	bif.16b	v2, v10, v29
	str	q2, [sp, #976]                  ; 16-byte Spill
	ldr	d2, [sp, #264]                  ; 8-byte Reload
	zip1.8b	v29, v2, v0
	ushll.4s	v29, v29, #0
	shl.4s	v29, v29, #31
	cmlt.4s	v29, v29, #0
	and.16b	v29, v29, v28
	str	q29, [sp, #1872]                ; 16-byte Spill
	zip2.8b	v28, v2, v0
	ushll.4s	v28, v28, #0
	shl.4s	v28, v28, #31
	cmlt.4s	v28, v28, #0
	and.16b	v28, v28, v21
	str	q28, [sp, #1856]                ; 16-byte Spill
	zip1.8b	v21, v2, v0
	ushll.4s	v21, v21, #0
	shl.4s	v21, v21, #31
	cmlt.4s	v21, v21, #0
	and.16b	v20, v21, v6
	str	q20, [sp, #1840]                ; 16-byte Spill
	zip2.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v16, v6, v16
	str	q16, [sp, #1824]                ; 16-byte Spill
	zip1.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v15, v6, v8
	zip2.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v5, v6, v5
	str	q5, [sp, #1808]                 ; 16-byte Spill
	zip1.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v22, v6, v22
	zip2.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v17, v6, v17
	zip1.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	ldr	q5, [sp, #1792]                 ; 16-byte Reload
	and.16b	v5, v6, v5
	str	q5, [sp, #1792]                 ; 16-byte Spill
	zip2.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v18, v6, v27
	zip1.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v11, v6, v11
	zip2.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v27, v6, v19
	zip1.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v19, v6, v9
	zip2.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v25, v6, v25
	zip1.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v26, v6, v26
	zip2.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v9, v6, v7
	zip2.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	ldr	q5, [sp, #1776]                 ; 16-byte Reload
	and.16b	v7, v6, v5
	str	q7, [sp, #1776]                 ; 16-byte Spill
	zip1.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v24, v6, v24
	zip2.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	ldr	q5, [sp, #944]                  ; 16-byte Reload
	and.16b	v5, v6, v5
	str	q5, [sp, #1760]                 ; 16-byte Spill
	zip1.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v14, v6, v31
	zip2.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	ldr	q5, [sp, #960]                  ; 16-byte Reload
	and.16b	v31, v6, v5
	zip1.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v30, v6, v30
	zip2.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v13, v6, v13
	zip1.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v23, v6, v23
	zip1.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	ldr	q5, [sp, #1728]                 ; 16-byte Reload
	and.16b	v5, v6, v5
	str	q5, [sp, #1744]                 ; 16-byte Spill
	zip2.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v4, v6, v4
	str	q4, [sp, #1728]                 ; 16-byte Spill
	ldp	q21, q6, [x11, #512]
	bit.16b	v6, v3, v0
	ldr	q8, [sp, #2384]                 ; 16-byte Reload
	bit.16b	v21, v8, v1
	stp	q21, q6, [x11, #512]
	zip2.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	ldr	q3, [sp, #1712]                 ; 16-byte Reload
	and.16b	v3, v6, v3
	str	q3, [sp, #1712]                 ; 16-byte Spill
	ldp	q21, q6, [x11, #544]
	bit.16b	v6, v28, v0
	bit.16b	v21, v29, v1
	stp	q21, q6, [x11, #544]
	zip1.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v12, v6, v12
	ldp	q21, q6, [x11, #576]
	bit.16b	v6, v16, v0
	bit.16b	v21, v20, v1
	stp	q21, q6, [x11, #576]
	zip2.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	ldr	q16, [sp, #976]                 ; 16-byte Reload
	and.16b	v8, v6, v16
	ldp	q21, q6, [x11, #608]
	ldr	q20, [sp, #1808]                ; 16-byte Reload
	bit.16b	v6, v20, v0
	bit.16b	v21, v15, v1
	stp	q21, q6, [x11, #608]
	zip1.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	ldr	q2, [sp, #992]                  ; 16-byte Reload
	and.16b	v28, v6, v2
	ldp	q21, q6, [x11, #640]
	bit.16b	v6, v17, v0
	bit.16b	v21, v22, v1
	stp	q21, q6, [x11, #640]
	ldp	q21, q6, [x11, #672]
	bit.16b	v6, v18, v0
	ldr	q16, [sp, #1792]                ; 16-byte Reload
	bit.16b	v21, v16, v1
	stp	q21, q6, [x11, #672]
	ldp	q21, q6, [x11, #704]
	bit.16b	v6, v27, v0
	bit.16b	v21, v11, v1
	stp	q21, q6, [x11, #704]
	ldp	q21, q6, [x11, #736]
	bit.16b	v6, v25, v0
	bit.16b	v21, v19, v1
	stp	q21, q6, [x11, #736]
	ldp	q21, q6, [x11, #768]
	bit.16b	v6, v9, v0
	bit.16b	v21, v26, v1
	stp	q21, q6, [x11, #768]
	ldp	q6, q21, [x11, #800]
	bit.16b	v6, v24, v1
	bit.16b	v21, v7, v0
	stp	q6, q21, [x11, #800]
	ldp	q6, q21, [x11, #832]
	bit.16b	v6, v14, v1
	ldr	q7, [sp, #1760]                 ; 16-byte Reload
	bit.16b	v21, v7, v0
	stp	q6, q21, [x11, #832]
	ldp	q6, q21, [x11, #864]
	bit.16b	v6, v30, v1
	bit.16b	v21, v31, v0
	stp	q6, q21, [x11, #864]
	ldp	q6, q21, [x11, #896]
	bit.16b	v6, v23, v1
	bit.16b	v21, v13, v0
	stp	q6, q21, [x11, #896]
	ldp	q21, q6, [x11, #928]
	bit.16b	v6, v4, v0
	bit.16b	v21, v5, v1
	stp	q21, q6, [x11, #928]
	ldp	q6, q21, [x11, #960]
	bit.16b	v6, v12, v1
	bit.16b	v21, v3, v0
	stp	q6, q21, [x11, #960]
	ldp	q6, q21, [x11, #992]
	bit.16b	v6, v28, v1
	bit.16b	v21, v8, v0
	stp	q6, q21, [x11, #992]
	ldp	q3, q2, [sp, #176]              ; 32-byte Folded Reload
	fcmeq.4s	v6, v3, v3
	mov.16b	v4, v6
	bsl.16b	v4, v2, v10
	ldp	q5, q2, [sp, #208]              ; 32-byte Folded Reload
	fcmeq.4s	v6, v5, v5
	bit.16b	v10, v2, v6
	sshll.2d	v6, v0, #0
	ldr	q2, [sp, #1408]                 ; 16-byte Reload
	ldr	q3, [sp, #1536]                 ; 16-byte Reload
	bit.16b	v2, v3, v6
	str	q2, [sp, #1408]                 ; 16-byte Spill
	ldr	q21, [sp, #1632]                ; 16-byte Reload
	bit.16b	v21, v3, v6
	str	q21, [sp, #1632]                ; 16-byte Spill
	sshll.2d	v6, v1, #0
	ldr	q21, [sp, #1664]                ; 16-byte Reload
	ldr	q2, [sp, #2464]                 ; 16-byte Reload
	bit.16b	v2, v21, v6
	str	q2, [sp, #2464]                 ; 16-byte Spill
	ldr	q29, [sp, #2592]                ; 16-byte Reload
	bit.16b	v29, v21, v6
	stp	q10, q4, [sp, #720]             ; 32-byte Folded Spill
	ldr	q2, [sp, #2496]                 ; 16-byte Reload
	bit.16b	v2, v10, v1
	str	q2, [sp, #2496]                 ; 16-byte Spill
	ldr	q2, [sp, #2480]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #2480]                 ; 16-byte Spill
	ldr	q2, [sp, #2384]                 ; 16-byte Reload
	ldr	q3, [sp, #2528]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #2528]                 ; 16-byte Spill
	ldr	q3, [sp, #2512]                 ; 16-byte Reload
	ldr	q2, [sp, #1888]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #2512]                 ; 16-byte Spill
	ldr	q3, [sp, #2560]                 ; 16-byte Reload
	ldr	q2, [sp, #1872]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #2560]                 ; 16-byte Spill
	ldr	q3, [sp, #2544]                 ; 16-byte Reload
	ldr	q2, [sp, #1856]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #2544]                 ; 16-byte Spill
	ldr	q3, [sp, #2640]                 ; 16-byte Reload
	ldr	q2, [sp, #1840]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #2640]                 ; 16-byte Spill
	ldr	q3, [sp, #2576]                 ; 16-byte Reload
	ldr	q2, [sp, #1824]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #2576]                 ; 16-byte Spill
	ldp	q21, q6, [sp, #1008]            ; 32-byte Folded Reload
	stp	q15, q22, [sp, #992]            ; 32-byte Folded Spill
	bit.16b	v21, v15, v1
	ldr	q15, [sp, #1504]                ; 16-byte Reload
	bit.16b	v15, v20, v0
	ldr	q5, [sp, #1040]                 ; 16-byte Reload
	bit.16b	v5, v22, v1
	str	q17, [sp, #1040]                ; 16-byte Spill
	bit.16b	v6, v17, v0
	ldr	q20, [sp, #1120]                ; 16-byte Reload
	bit.16b	v20, v16, v1
	ldr	q4, [sp, #1104]                 ; 16-byte Reload
	str	q18, [sp, #1024]                ; 16-byte Spill
	bit.16b	v4, v18, v0
	ldr	q18, [sp, #1152]                ; 16-byte Reload
	stp	q27, q11, [sp, #960]            ; 32-byte Folded Spill
	bit.16b	v18, v11, v1
	ldr	q11, [sp, #1136]                ; 16-byte Reload
	bit.16b	v11, v27, v0
	ldr	q27, [sp, #1184]                ; 16-byte Reload
	stp	q25, q19, [sp, #928]            ; 32-byte Folded Spill
	bit.16b	v27, v19, v1
	ldr	q17, [sp, #1168]                ; 16-byte Reload
	bit.16b	v17, v25, v0
	ldr	q25, [sp, #1216]                ; 16-byte Reload
	stp	q9, q26, [sp, #896]             ; 32-byte Folded Spill
	bit.16b	v25, v26, v1
	ldr	q26, [sp, #1200]                ; 16-byte Reload
	bit.16b	v26, v9, v0
	ldr	q9, [sp, #1248]                 ; 16-byte Reload
	stp	q14, q24, [sp, #864]            ; 32-byte Folded Spill
	bit.16b	v9, v24, v1
	ldr	q24, [sp, #1232]                ; 16-byte Reload
	ldr	q2, [sp, #1776]                 ; 16-byte Reload
	bit.16b	v24, v2, v0
	ldr	q19, [sp, #1280]                ; 16-byte Reload
	bit.16b	v19, v14, v1
	ldr	q2, [sp, #1264]                 ; 16-byte Reload
	bit.16b	v2, v7, v0
	stp	q30, q31, [sp, #832]            ; 32-byte Folded Spill
	ldr	q3, [sp, #2448]                 ; 16-byte Reload
	bit.16b	v3, v30, v1
	str	q3, [sp, #2448]                 ; 16-byte Spill
	ldr	q3, [sp, #2624]                 ; 16-byte Reload
	bit.16b	v3, v31, v0
	str	q3, [sp, #2624]                 ; 16-byte Spill
	ldr	q14, [sp, #1296]                ; 16-byte Reload
	stp	q23, q13, [sp, #800]            ; 32-byte Folded Spill
	bit.16b	v14, v23, v1
	mov.16b	v7, v4
	mov.16b	v16, v5
	mov.16b	v30, v6
	mov.16b	v31, v21
	ldr	q22, [sp, #1520]                ; 16-byte Reload
	bit.16b	v22, v13, v0
	ldr	q13, [sp, #1312]                ; 16-byte Reload
	ldr	q3, [sp, #1744]                 ; 16-byte Reload
	bit.16b	v13, v3, v1
	ldr	q5, [sp, #1552]                 ; 16-byte Reload
	ldr	q3, [sp, #1728]                 ; 16-byte Reload
	bit.16b	v5, v3, v0
	ldr	q4, [sp, #1328]                 ; 16-byte Reload
	stp	q8, q12, [sp, #768]             ; 32-byte Folded Spill
	bit.16b	v4, v12, v1
	ldr	q12, [sp, #1568]                ; 16-byte Reload
	ldr	q3, [sp, #1712]                 ; 16-byte Reload
	bit.16b	v12, v3, v0
	ldr	q10, [sp, #1600]                ; 16-byte Reload
	str	q28, [sp, #752]                 ; 16-byte Spill
	bit.16b	v10, v28, v1
	mov	x23, #-4096                     ; =0xfffffffffffff000
	ldr	q3, [sp, #1584]                 ; 16-byte Reload
	bit.16b	v3, v8, v0
LBB0_95:                                ; %direct.true739
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x24, x23, #1, lsl #12           ; =4096
	fmov	d8, x24
	ldr	q6, [sp, #2608]                 ; 16-byte Reload
	orr.16b	v6, v8, v6
	fmov	x24, d6
	add	x24, x8, x24
	ldp	q21, q6, [x24]
	and.16b	v21, v1, v21
	ldr	q28, [sp, #2496]                ; 16-byte Reload
	fmul.4s	v21, v28, v21
	ldr	q28, [sp, #2464]                ; 16-byte Reload
	orr.16b	v28, v8, v28
	fmov	x24, d28
	add	x24, x14, x24
	ldr	q28, [x24]
	and.16b	v28, v1, v28
	ldr	q23, [sp, #2528]                ; 16-byte Reload
	fmul.4s	v28, v23, v28
	fadd.4s	v21, v21, v28
	ldr	q28, [x24, #16]
	and.16b	v6, v0, v6
	ldr	q23, [sp, #2480]                ; 16-byte Reload
	fmul.4s	v6, v23, v6
	and.16b	v28, v0, v28
	ldr	q23, [sp, #2512]                ; 16-byte Reload
	fmul.4s	v28, v23, v28
	fadd.4s	v6, v6, v28
	add	x24, x10, x23
	add	x25, x24, #21, lsl #12          ; =86016
	ldr	q28, [x25, #16]
	and.16b	v28, v0, v28
	ldr	q23, [sp, #2544]                ; 16-byte Reload
	fmul.4s	v28, v23, v28
	fadd.4s	v6, v6, v28
	ldr	q28, [x25]
	and.16b	v28, v1, v28
	ldr	q23, [sp, #2560]                ; 16-byte Reload
	fmul.4s	v28, v23, v28
	fadd.4s	v21, v21, v28
	add	x25, x24, #22, lsl #12          ; =90112
	ldr	q28, [x25]
	and.16b	v28, v1, v28
	ldr	q23, [sp, #2640]                ; 16-byte Reload
	fmul.4s	v28, v23, v28
	fadd.4s	v21, v21, v28
	ldr	q28, [x25, #16]
	and.16b	v28, v0, v28
	ldr	q23, [sp, #2576]                ; 16-byte Reload
	fmul.4s	v28, v23, v28
	fadd.4s	v6, v6, v28
	add	x25, x24, #23, lsl #12          ; =94208
	ldr	q28, [x25, #16]
	and.16b	v28, v0, v28
	fmul.4s	v28, v15, v28
	fadd.4s	v6, v6, v28
	ldr	q28, [x25]
	and.16b	v28, v1, v28
	fmul.4s	v28, v31, v28
	fadd.4s	v21, v21, v28
	add	x25, x24, #24, lsl #12          ; =98304
	ldr	q28, [x25]
	and.16b	v28, v1, v28
	fmul.4s	v28, v16, v28
	fadd.4s	v21, v21, v28
	ldr	q28, [x25, #16]
	and.16b	v28, v0, v28
	fmul.4s	v28, v30, v28
	fadd.4s	v6, v6, v28
	add	x25, x24, #25, lsl #12          ; =102400
	ldr	q28, [x25, #16]
	and.16b	v28, v0, v28
	fmul.4s	v28, v7, v28
	fadd.4s	v6, v6, v28
	ldr	q28, [x25]
	and.16b	v28, v1, v28
	fmul.4s	v28, v20, v28
	fadd.4s	v21, v21, v28
	add	x25, x24, #26, lsl #12          ; =106496
	ldr	q28, [x25]
	and.16b	v28, v1, v28
	fmul.4s	v28, v18, v28
	fadd.4s	v21, v21, v28
	ldr	q28, [x25, #16]
	and.16b	v28, v0, v28
	fmul.4s	v28, v11, v28
	fadd.4s	v6, v6, v28
	add	x25, x24, #27, lsl #12          ; =110592
	ldr	q28, [x25, #16]
	and.16b	v28, v0, v28
	fmul.4s	v28, v17, v28
	fadd.4s	v6, v6, v28
	ldr	q28, [x25]
	and.16b	v28, v1, v28
	fmul.4s	v28, v27, v28
	fadd.4s	v21, v21, v28
	add	x25, x24, #28, lsl #12          ; =114688
	ldr	q28, [x25]
	and.16b	v28, v1, v28
	fmul.4s	v28, v25, v28
	fadd.4s	v21, v21, v28
	ldr	q28, [x25, #16]
	and.16b	v28, v0, v28
	fmul.4s	v28, v26, v28
	fadd.4s	v6, v6, v28
	add	x25, x24, #29, lsl #12          ; =118784
	ldr	q28, [x25, #16]
	and.16b	v28, v0, v28
	fmul.4s	v28, v24, v28
	fadd.4s	v6, v6, v28
	ldr	q28, [x25]
	and.16b	v28, v1, v28
	fmul.4s	v28, v9, v28
	fadd.4s	v21, v21, v28
	add	x25, x24, #30, lsl #12          ; =122880
	ldr	q28, [x25]
	and.16b	v28, v1, v28
	fmul.4s	v28, v19, v28
	fadd.4s	v21, v21, v28
	ldr	q28, [x25, #16]
	and.16b	v28, v0, v28
	fmul.4s	v28, v2, v28
	fadd.4s	v6, v6, v28
	add	x25, x24, #31, lsl #12          ; =126976
	ldr	q28, [x25, #16]
	and.16b	v28, v0, v28
	ldr	q23, [sp, #2624]                ; 16-byte Reload
	fmul.4s	v28, v23, v28
	fadd.4s	v6, v6, v28
	ldr	q28, [x25]
	and.16b	v28, v1, v28
	ldr	q23, [sp, #2448]                ; 16-byte Reload
	fmul.4s	v28, v23, v28
	fadd.4s	v21, v21, v28
	add	x25, x24, #32, lsl #12          ; =131072
	ldr	q28, [x25]
	and.16b	v28, v1, v28
	fmul.4s	v28, v14, v28
	fadd.4s	v21, v21, v28
	ldr	q28, [x25, #16]
	and.16b	v28, v0, v28
	fmul.4s	v28, v22, v28
	fadd.4s	v6, v6, v28
	add	x25, x24, #33, lsl #12          ; =135168
	ldr	q28, [x25, #16]
	and.16b	v28, v0, v28
	fmul.4s	v28, v5, v28
	fadd.4s	v6, v6, v28
	ldr	q28, [x25]
	and.16b	v28, v1, v28
	fmul.4s	v28, v13, v28
	fadd.4s	v21, v21, v28
	add	x25, x24, #34, lsl #12          ; =139264
	ldr	q28, [x25]
	and.16b	v28, v1, v28
	fmul.4s	v28, v4, v28
	fadd.4s	v21, v21, v28
	ldr	q28, [x25, #16]
	and.16b	v28, v0, v28
	fmul.4s	v28, v12, v28
	fadd.4s	v6, v6, v28
	add	x24, x24, #35, lsl #12          ; =143360
	ldr	q28, [x24, #16]
	and.16b	v28, v0, v28
	fmul.4s	v28, v3, v28
	fadd.4s	v6, v6, v28
	ldr	q28, [x24]
	and.16b	v28, v1, v28
	fmul.4s	v28, v10, v28
	fadd.4s	v21, v21, v28
	orr.16b	v28, v8, v29
	fmov	x24, d28
	add	x24, x15, x24
	ldp	q23, q28, [x24]
	bif.16b	v21, v23, v1
	bif.16b	v6, v28, v0
	stp	q21, q6, [x24]
	adds	x23, x23, #32
	b.ne	LBB0_95
; %bb.96:                               ; %direct.true867.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q8, [sp, #2640]                 ; 16-byte Reload
	str	q15, [sp, #1504]                ; 16-byte Spill
	ldr	q15, [sp, #2624]                ; 16-byte Reload
	str	q22, [sp, #1520]                ; 16-byte Spill
	str	q5, [sp, #1552]                 ; 16-byte Spill
	str	q12, [sp, #1568]                ; 16-byte Spill
	str	q3, [sp, #1584]                 ; 16-byte Spill
	str	q10, [sp, #1600]                ; 16-byte Spill
	ldr	q3, [sp, #2608]                 ; 16-byte Reload
	str	q29, [sp, #2592]                ; 16-byte Spill
LBB0_97:                                ; %direct.true867
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	d6, x23
	orr.16b	v21, v6, v29
	fmov	x24, d21
	add	x24, x15, x24
	ldp	q21, q28, [x24]
	orr.16b	v6, v6, v3
	fmov	x24, d6
	add	x24, x12, x24
	ldp	q6, q29, [x24]
	bif.16b	v28, v29, v0
	ldr	q29, [sp, #2592]                ; 16-byte Reload
	bit.16b	v6, v21, v1
	stp	q6, q28, [x24]
	add	x23, x23, #32
	cmp	x23, #1, lsl #12                ; =4096
	b.ne	LBB0_97
; %bb.98:                               ; %direct.true883.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	add	x23, x10, #1, lsl #12           ; =4096
	mov	w24, #128                       ; =0x80
	str	q4, [sp, #1328]                 ; 16-byte Spill
	str	q13, [sp, #1312]                ; 16-byte Spill
	str	q14, [sp, #1296]                ; 16-byte Spill
	str	q19, [sp, #1280]                ; 16-byte Spill
	str	q2, [sp, #1264]                 ; 16-byte Spill
	str	q9, [sp, #1248]                 ; 16-byte Spill
	str	q24, [sp, #1232]                ; 16-byte Spill
	str	q25, [sp, #1216]                ; 16-byte Spill
	str	q26, [sp, #1200]                ; 16-byte Spill
	str	q27, [sp, #1184]                ; 16-byte Spill
	str	q17, [sp, #1168]                ; 16-byte Spill
	str	q18, [sp, #1152]                ; 16-byte Spill
	str	q11, [sp, #1136]                ; 16-byte Spill
	str	q20, [sp, #1120]                ; 16-byte Spill
	str	q7, [sp, #1104]                 ; 16-byte Spill
	mov.16b	v7, v16
	mov.16b	v16, v30
	mov.16b	v30, v31
	ldr	q3, [sp, #2112]                 ; 16-byte Reload
	ldr	q5, [sp, #2096]                 ; 16-byte Reload
	ldr	q22, [sp, #2080]                ; 16-byte Reload
LBB0_99:                                ; %direct.true883
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q6, [x23, #4096]
	ldr	q21, [x23, #4112]
	ldp	q28, q29, [x23]
	bif.16b	v21, v29, v0
	bif.16b	v6, v28, v1
	stp	q6, q21, [x23], #32
	subs	x24, x24, #1
	b.ne	LBB0_99
; %bb.100:                              ; %direct.false884
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q6, [sp, #2416]                 ; 16-byte Reload
	ldr	q2, [sp, #1056]                 ; 16-byte Reload
	bit.16b	v6, v2, v0
	str	q6, [sp, #2416]                 ; 16-byte Spill
	ldr	q6, [sp, #2400]                 ; 16-byte Reload
	ldr	q2, [sp, #1072]                 ; 16-byte Reload
	bit.16b	v6, v2, v1
	str	q6, [sp, #2400]                 ; 16-byte Spill
	movi.2d	v21, #0000000000000000
	ldr	q2, [sp, #2384]                 ; 16-byte Reload
	fadd.4s	v6, v2, v21
	ldr	q2, [sp, #1872]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #1888]                 ; 16-byte Reload
	fadd.4s	v21, v2, v21
	ldr	q2, [sp, #1856]                 ; 16-byte Reload
	fadd.4s	v21, v21, v2
	ldr	q2, [sp, #1824]                 ; 16-byte Reload
	fadd.4s	v21, v21, v2
	ldr	q2, [sp, #1840]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #992]                  ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #1808]                 ; 16-byte Reload
	fadd.4s	v21, v21, v2
	ldr	q2, [sp, #1040]                 ; 16-byte Reload
	fadd.4s	v21, v21, v2
	ldr	q2, [sp, #1008]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #1792]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #1024]                 ; 16-byte Reload
	fadd.4s	v21, v21, v2
	ldp	q4, q2, [sp, #960]              ; 32-byte Folded Reload
	fadd.4s	v21, v21, v4
	fadd.4s	v6, v6, v2
	ldp	q2, q4, [sp, #928]              ; 32-byte Folded Reload
	fadd.4s	v6, v6, v4
	fadd.4s	v21, v21, v2
	ldp	q4, q2, [sp, #896]              ; 32-byte Folded Reload
	fadd.4s	v21, v21, v4
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #880]                  ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #1776]                 ; 16-byte Reload
	fadd.4s	v21, v21, v2
	ldr	q2, [sp, #1760]                 ; 16-byte Reload
	fadd.4s	v21, v21, v2
	ldr	q2, [sp, #864]                  ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldp	q4, q2, [sp, #832]              ; 32-byte Folded Reload
	fadd.4s	v6, v6, v4
	fadd.4s	v21, v21, v2
	ldp	q2, q4, [sp, #800]              ; 32-byte Folded Reload
	fadd.4s	v21, v21, v4
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #1744]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #1728]                 ; 16-byte Reload
	fadd.4s	v21, v21, v2
	ldr	q2, [sp, #1712]                 ; 16-byte Reload
	fadd.4s	v21, v21, v2
	ldr	q2, [sp, #784]                  ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldp	q4, q2, [sp, #752]              ; 32-byte Folded Reload
	fadd.4s	v6, v6, v4
	fadd.4s	v21, v21, v2
	ldr	q4, [sp, #1696]                 ; 16-byte Reload
	ldr	q2, [sp, #720]                  ; 16-byte Reload
	fmul.4s	v28, v4, v2
	ldr	q13, [sp, #1680]                ; 16-byte Reload
	ldr	q2, [sp, #736]                  ; 16-byte Reload
	fmul.4s	v29, v13, v2
	fadd.4s	v21, v29, v21
	fadd.4s	v6, v28, v6
	bit.16b	v4, v6, v1
	str	q4, [sp, #1696]                 ; 16-byte Spill
	bit.16b	v13, v21, v0
	str	q13, [sp, #1680]                ; 16-byte Spill
	add	x0, x0, #1
	cmp	x0, #513
	ldp	q13, q4, [sp, #64]              ; 32-byte Folded Reload
	ldr	q31, [sp, #1536]                ; 16-byte Reload
	ldr	q23, [sp, #2064]                ; 16-byte Reload
	ldr	q19, [sp, #2048]                ; 16-byte Reload
	ldr	q2, [sp, #2032]                 ; 16-byte Reload
	ldr	q9, [sp, #2016]                 ; 16-byte Reload
	ldr	q24, [sp, #2000]                ; 16-byte Reload
	ldr	q25, [sp, #1984]                ; 16-byte Reload
	ldr	q26, [sp, #1968]                ; 16-byte Reload
	ldr	q27, [sp, #1952]                ; 16-byte Reload
	ldr	q17, [sp, #1936]                ; 16-byte Reload
	ldr	q18, [sp, #1920]                ; 16-byte Reload
	ldr	q11, [sp, #1904]                ; 16-byte Reload
	ldr	q20, [sp, #1088]                ; 16-byte Reload
	b.ne	LBB0_22
; %bb.101:                              ; %direct.true902.preheader
	mov	x10, #0                         ; =0x0
	ldp	q16, q7, [sp, #32]              ; 32-byte Folded Reload
	ldp	q18, q17, [sp]                  ; 32-byte Folded Reload
	ldr	q19, [sp, #1696]                ; 16-byte Reload
	ldr	q20, [sp, #1680]                ; 16-byte Reload
	b	LBB0_103
LBB0_102:                               ; %else335
                                        ;   in Loop: Header=BB0_103 Depth=1
	add	x10, x10, #4
	add	x8, x8, #32
	cmp	x10, #512
	b.eq	LBB0_119
LBB0_103:                               ; %direct.true902
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q2, [sp, #2432]                 ; 16-byte Reload
	fmov	w11, s2
	ldp	q2, q4, [x8]
	and.16b	v2, v1, v2
	fdiv.4s	v5, v2, v19
	dup.2d	v2, x10
	add.2d	v6, v2, v18
	dup.2d	v3, x9
	add.2d	v6, v3, v6
	tbz	w11, #0, LBB0_111
; %bb.104:                              ; %cond.store
                                        ;   in Loop: Header=BB0_103 Depth=1
	fmov	x12, d6
	str	s5, [x12]
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB0_112
LBB0_105:                               ; %else317
                                        ;   in Loop: Header=BB0_103 Depth=1
	add.2d	v6, v2, v16
	add.2d	v6, v3, v6
	tbz	w11, #2, LBB0_113
LBB0_106:                               ; %cond.store318
                                        ;   in Loop: Header=BB0_103 Depth=1
	fmov	x12, d6
	st1.s	{ v5 }[2], [x12]
	tbnz	w11, #3, LBB0_114
LBB0_107:                               ; %else323
                                        ;   in Loop: Header=BB0_103 Depth=1
	and.16b	v4, v0, v4
	fdiv.4s	v4, v4, v20
	add.2d	v5, v2, v17
	add.2d	v5, v3, v5
	tbz	w11, #4, LBB0_115
LBB0_108:                               ; %cond.store324
                                        ;   in Loop: Header=BB0_103 Depth=1
	fmov	x12, d5
	str	s4, [x12]
	tbnz	w11, #5, LBB0_116
LBB0_109:                               ; %else329
                                        ;   in Loop: Header=BB0_103 Depth=1
	add.2d	v2, v2, v7
	add.2d	v2, v3, v2
	tbz	w11, #6, LBB0_117
LBB0_110:                               ; %cond.store330
                                        ;   in Loop: Header=BB0_103 Depth=1
	fmov	x12, d2
	st1.s	{ v4 }[2], [x12]
	tbz	w11, #7, LBB0_102
	b	LBB0_118
LBB0_111:                               ; %else314
                                        ;   in Loop: Header=BB0_103 Depth=1
	and	w11, w11, #0xff
	tbz	w11, #1, LBB0_105
LBB0_112:                               ; %cond.store315
                                        ;   in Loop: Header=BB0_103 Depth=1
	mov.d	x12, v6[1]
	st1.s	{ v5 }[1], [x12]
	add.2d	v6, v2, v16
	add.2d	v6, v3, v6
	tbnz	w11, #2, LBB0_106
LBB0_113:                               ; %else320
                                        ;   in Loop: Header=BB0_103 Depth=1
	tbz	w11, #3, LBB0_107
LBB0_114:                               ; %cond.store321
                                        ;   in Loop: Header=BB0_103 Depth=1
	mov.d	x12, v6[1]
	st1.s	{ v5 }[3], [x12]
	and.16b	v4, v0, v4
	fdiv.4s	v4, v4, v20
	add.2d	v5, v2, v17
	add.2d	v5, v3, v5
	tbnz	w11, #4, LBB0_108
LBB0_115:                               ; %else326
                                        ;   in Loop: Header=BB0_103 Depth=1
	tbz	w11, #5, LBB0_109
LBB0_116:                               ; %cond.store327
                                        ;   in Loop: Header=BB0_103 Depth=1
	mov.d	x12, v5[1]
	st1.s	{ v4 }[1], [x12]
	add.2d	v2, v2, v7
	add.2d	v2, v3, v2
	tbnz	w11, #6, LBB0_110
LBB0_117:                               ; %else332
                                        ;   in Loop: Header=BB0_103 Depth=1
	tbz	w11, #7, LBB0_102
LBB0_118:                               ; %cond.store333
                                        ;   in Loop: Header=BB0_103 Depth=1
	mov.d	x11, v2[1]
	st1.s	{ v4 }[3], [x11]
	b	LBB0_102
LBB0_119:
	add	sp, sp, #2960
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #144            ; 16-byte Folded Reload
LBB0_120:                               ; %common.ret
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh6, Lloh7
                                        ; -- End function
	.globl	_llm_attention.packet_batch.blocks ; -- Begin function llm_attention.packet_batch.blocks
	.p2align	2
_llm_attention.packet_batch.blocks:     ; @llm_attention.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_3:                                 ; %llm_attention.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

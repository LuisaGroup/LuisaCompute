; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_attention(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 2560
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 5632
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 8704
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 49664
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 98816
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 99328
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 99840
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill29 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill29, align 64
  %.spill30 = alloca i64, align 8
  store i64 0, ptr %.spill30, align 4
  %.spill31 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill31, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill32 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill32, align 64
  %tile_snapshot.spill33 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill33, align 64
  %.slot34 = alloca i64, align 8
  store i64 0, ptr %.slot34, align 4
  %.slot35 = alloca i64, align 8
  store i64 0, ptr %.slot35, align 4
  %.slot36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot36, align 32
  %.slot37 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot37, align 32
  %.spill38 = alloca i64, align 8
  store i64 0, ptr %.spill38, align 4
  %tile_snapshot.spill39 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill39, align 64
  %.slot40 = alloca i64, align 8
  store i64 0, ptr %.slot40, align 4
  %.spill41 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill41, align 64
  %.slot42 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot42, align 32
  %tile_snapshot.spill43 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill43, align 64
  %.slot44 = alloca i64, align 8
  store i64 0, ptr %.slot44, align 4
  %.spill45 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill45, align 64
  %.slot46 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot46, align 32
  %.slot47 = alloca i64, align 8
  store i64 0, ptr %.slot47, align 4
  %.slot48 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot48, align 32
  %.slot49 = alloca i64, align 8
  store i64 0, ptr %.slot49, align 4
  %.slot50 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot50, align 32
  %.slot51 = alloca i64, align 8
  store i64 0, ptr %.slot51, align 4
  %.slot52 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot52, align 32
  %.slot53 = alloca i64, align 8
  store i64 0, ptr %.slot53, align 4
  %.slot54 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot54, align 32
  %.slot55 = alloca i64, align 8
  store i64 0, ptr %.slot55, align 4
  %.slot56 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot56, align 32
  %.slot57 = alloca i64, align 8
  store i64 0, ptr %.slot57, align 4
  %.slot58 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot58, align 32
  %.slot59 = alloca i64, align 8
  store i64 0, ptr %.slot59, align 4
  %.slot60 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot60, align 32
  %.slot61 = alloca i64, align 8
  store i64 0, ptr %.slot61, align 4
  %.slot62 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot62, align 32
  %.slot63 = alloca i64, align 8
  store i64 0, ptr %.slot63, align 4
  %.slot64 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot64, align 32
  %.slot65 = alloca i64, align 8
  store i64 0, ptr %.slot65, align 4
  %.slot66 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot66, align 32
  %.slot67 = alloca i64, align 8
  store i64 0, ptr %.slot67, align 4
  %.slot68 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot68, align 32
  %.slot69 = alloca i64, align 8
  store i64 0, ptr %.slot69, align 4
  %.slot70 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot70, align 32
  %.slot71 = alloca i64, align 8
  store i64 0, ptr %.slot71, align 4
  %.slot72 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot72, align 32
  %.slot73 = alloca i64, align 8
  store i64 0, ptr %.slot73, align 4
  %.slot74 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot74, align 32
  %.slot75 = alloca i64, align 8
  store i64 0, ptr %.slot75, align 4
  %.slot76 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot76, align 32
  %.slot77 = alloca i64, align 8
  store i64 0, ptr %.slot77, align 4
  %.slot78 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot78, align 32
  %.spill79 = alloca i64, align 8
  store i64 0, ptr %.spill79, align 4
  %.spill80 = alloca i1, align 1
  store i1 false, ptr %.spill80, align 1
  %.spill81 = alloca i1, align 1
  store i1 false, ptr %.spill81, align 1
  %.spill82 = alloca i1, align 1
  store i1 false, ptr %.spill82, align 1
  %.spill83 = alloca i1, align 1
  store i1 false, ptr %.spill83, align 1
  %.spill84 = alloca i1, align 1
  store i1 false, ptr %.spill84, align 1
  %.spill85 = alloca i1, align 1
  store i1 false, ptr %.spill85, align 1
  %.spill86 = alloca i1, align 1
  store i1 false, ptr %.spill86, align 1
  %.spill87 = alloca i1, align 1
  store i1 false, ptr %.spill87, align 1
  %.spill88 = alloca i1, align 1
  store i1 false, ptr %.spill88, align 1
  %.spill89 = alloca i1, align 1
  store i1 false, ptr %.spill89, align 1
  %.spill90 = alloca i1, align 1
  store i1 false, ptr %.spill90, align 1
  %.spill91 = alloca i1, align 1
  store i1 false, ptr %.spill91, align 1
  %.spill92 = alloca i1, align 1
  store i1 false, ptr %.spill92, align 1
  %.spill93 = alloca i1, align 1
  store i1 false, ptr %.spill93, align 1
  %.spill94 = alloca i1, align 1
  store i1 false, ptr %.spill94, align 1
  %.spill95 = alloca i1, align 1
  store i1 false, ptr %.spill95, align 1
  %.spill96 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill96, align 32
  %.spill97 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill97, align 32
  %.spill98 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill98, align 32
  %.spill99 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill99, align 32
  %.spill100 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill100, align 32
  %.spill101 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill101, align 32
  %.spill102 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill102, align 32
  %.spill103 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill103, align 32
  %.spill104 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill104, align 32
  %.spill105 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill105, align 32
  %.spill106 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill106, align 32
  %.spill107 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill107, align 32
  %.spill108 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill108, align 32
  %.spill109 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill109, align 32
  %.spill110 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill110, align 32
  %.spill111 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill111, align 32
  %tile_snapshot.spill112 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill112, align 64
  %.slot113 = alloca i64, align 8
  store i64 0, ptr %.slot113, align 4
  %.slot114 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot114, align 32
  %.spill115 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill115, align 32
  %.spill116 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill116, align 32
  %.spill117 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill117, align 32
  %.spill118 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill118, align 32
  %.spill119 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill119, align 32
  %.spill120 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill120, align 32
  %.spill121 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill121, align 32
  %.spill122 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill122, align 32
  %.spill123 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill123, align 32
  %.spill124 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill124, align 32
  %.spill125 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill125, align 32
  %.spill126 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill126, align 32
  %.spill127 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill127, align 32
  %.spill128 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill128, align 32
  %.spill129 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill129, align 32
  %.spill130 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill130, align 32
  %.spill131 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill131, align 32
  %.spill132 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill132, align 32
  %tile_snapshot.spill133 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill133, align 64
  %.spill134 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill134, align 32
  %.slot135 = alloca i64, align 8
  store i64 0, ptr %.slot135, align 4
  %.slot136 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot136, align 32
  %.spill137 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill137, align 32
  %tile_snapshot.spill138 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill138, align 64
  %.slot139 = alloca i64, align 8
  store i64 0, ptr %.slot139, align 4
  %.slot140 = alloca i64, align 8
  store i64 0, ptr %.slot140, align 4
  %.slot141 = alloca i64, align 8
  store i64 0, ptr %.slot141, align 4
  %.slot142 = alloca i64, align 8
  store i64 0, ptr %.slot142, align 4
  %24 = getelementptr i8, ptr %argument_buffer, i64 0
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = getelementptr i8, ptr %argument_buffer, i64 16
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %30, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %33, 1
  %36 = getelementptr i8, ptr %argument_buffer, i64 32
  %37 = load ptr, ptr %36, align 16
  %38 = getelementptr i8, ptr %36, i64 8
  %39 = load i64, ptr %38, align 8
  %40 = insertvalue { ptr, i64 } poison, ptr %37, 0
  %41 = insertvalue { ptr, i64 } %40, i64 %39, 1
  %42 = getelementptr i8, ptr %argument_buffer, i64 48
  %43 = load ptr, ptr %42, align 16
  %44 = getelementptr i8, ptr %42, i64 8
  %45 = load i64, ptr %44, align 8
  %46 = insertvalue { ptr, i64 } poison, ptr %43, 0
  %47 = insertvalue { ptr, i64 } %46, i64 %45, 1
  %48 = load i32, ptr %launch_config, align 4
  %49 = getelementptr i8, ptr %launch_config, i64 12
  %50 = load i32, ptr %49, align 4
  %51 = getelementptr i8, ptr %launch_config, i64 4
  %52 = load i32, ptr %51, align 4
  %53 = getelementptr i8, ptr %launch_config, i64 16
  %54 = load i32, ptr %53, align 4
  %55 = getelementptr i8, ptr %launch_config, i64 8
  %56 = load i32, ptr %55, align 4
  %57 = getelementptr i8, ptr %launch_config, i64 20
  %58 = load i32, ptr %57, align 4
  %59 = getelementptr i8, ptr %launch_config, i64 36
  %60 = load i32, ptr %59, align 4
  %.splatinsert143 = insertelement <8 x i32> poison, i32 %60, i64 0
  %.splat144 = shufflevector <8 x i32> %.splatinsert143, <8 x i32> poison, <8 x i32> zeroinitializer
  %61 = add <8 x i32> %.splat144, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %62 = mul i32 %48, 32
  %.splatinsert145 = insertelement <8 x i32> poison, i32 %62, i64 0
  %.splat146 = shufflevector <8 x i32> %.splatinsert145, <8 x i32> poison, <8 x i32> zeroinitializer
  %63 = add <8 x i32> %.splat146, %61
  %64 = mul i32 %52, 1
  %.splatinsert147 = insertelement <8 x i32> poison, i32 %64, i64 0
  %.splat148 = shufflevector <8 x i32> %.splatinsert147, <8 x i32> poison, <8 x i32> zeroinitializer
  %65 = add <8 x i32> %.splat148, zeroinitializer
  %66 = mul i32 %56, 1
  %.splatinsert149 = insertelement <8 x i32> poison, i32 %66, i64 0
  %.splat150 = shufflevector <8 x i32> %.splatinsert149, <8 x i32> poison, <8 x i32> zeroinitializer
  %67 = add <8 x i32> %.splat150, zeroinitializer
  %68 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %63, 0
  %69 = insertvalue [3 x <8 x i32>] %68, <8 x i32> %65, 1
  %70 = insertvalue [3 x <8 x i32>] %69, <8 x i32> %67, 2
  %.splatinsert151 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat152 = shufflevector <8 x i32> %.splatinsert151, <8 x i32> poison, <8 x i32> zeroinitializer
  %71 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat152
  %72 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  br i1 %72, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %73 = extractvalue [3 x <8 x i32>] %70, 0
  %74 = zext <8 x i32> %73 to <8 x i64>
  %75 = select <8 x i1> %71, <8 x i64> %74, <8 x i64> zeroinitializer
  %76 = select <8 x i1> %71, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %77 = sdiv <8 x i64> %75, %76
  %78 = load <8 x i64>, ptr %.spill, align 64
  %79 = select <8 x i1> %71, <8 x i64> %77, <8 x i64> %78
  store <8 x i64> %79, ptr %.spill, align 64
  %80 = select <8 x i1> %71, <8 x i64> %74, <8 x i64> zeroinitializer
  %81 = select <8 x i1> %71, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %82 = sdiv <8 x i64> %80, %81
  %83 = select <8 x i1> %71, <8 x i64> %82, <8 x i64> zeroinitializer
  %84 = select <8 x i1> %71, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %85 = srem <8 x i64> %83, %84
  %86 = load <8 x i64>, ptr %.spill29, align 64
  %87 = select <8 x i1> %71, <8 x i64> %85, <8 x i64> %86
  store <8 x i64> %87, ptr %.spill29, align 64
  store i64 0, ptr %.spill30, align 4
  %88 = select <8 x i1> %71, <8 x i64> %85, <8 x i64> zeroinitializer
  %89 = select <8 x i1> %71, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %90 = sdiv <8 x i64> %88, %89
  %91 = load <8 x i64>, ptr %.spill31, align 64
  %92 = select <8 x i1> %71, <8 x i64> %90, <8 x i64> %91
  store <8 x i64> %92, ptr %.spill31, align 64
  %93 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %95 = extractvalue { <8 x ptr>, <8 x i64> } %93, 0
  %96 = select <8 x i1> %71, <8 x ptr> %94, <8 x ptr> %95
  %97 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %93, 1
  %99 = select <8 x i1> %71, <8 x i64> %97, <8 x i64> %98
  %100 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %96, 0
  %101 = insertvalue { <8 x ptr>, <8 x i64> } %100, <8 x i64> %99, 1
  store { <8 x ptr>, <8 x i64> } %101, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %102 = icmp slt i64 %.state, 80
  br i1 %102, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %103 = add <8 x i64> %.spill.load, zeroinitializer
  %104 = add <8 x i64> zeroinitializer, %103
  %.spill.load153 = load <8 x i64>, ptr %.spill29, align 64
  %105 = add <8 x i64> %.spill.load153, zeroinitializer
  %106 = mul <8 x i64> %104, splat (i64 8)
  %107 = add <8 x i64> %106, %105
  %.spill.load154 = load i64, ptr %.spill30, align 4
  %108 = add i64 %.spill.load154, 0
  %109 = mul <8 x i64> %107, splat (i64 1)
  %.splatinsert155 = insertelement <8 x i64> poison, i64 %108, i64 0
  %.splat156 = shufflevector <8 x i64> %.splatinsert155, <8 x i64> poison, <8 x i32> zeroinitializer
  %110 = add <8 x i64> %109, %.splat156
  %.state157 = load i64, ptr %.slot, align 4
  %111 = add i64 0, %.state157
  %112 = mul <8 x i64> %110, splat (i64 80)
  %.splatinsert158 = insertelement <8 x i64> poison, i64 %111, i64 0
  %.splat159 = shufflevector <8 x i64> %.splatinsert158, <8 x i64> poison, <8 x i32> zeroinitializer
  %113 = add <8 x i64> %112, %.splat159
  %114 = extractvalue { ptr, i64 } %29, 0
  %115 = mul <8 x i64> %113, splat (i64 4)
  %116 = getelementptr i8, ptr %114, <8 x i64> %115
  %117 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %116, <8 x i1> %71, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %118 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %119 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state160 = load i64, ptr %.slot, align 4
  %.splatinsert161 = insertelement <8 x i64> poison, i64 %.state160, i64 0
  %.splat162 = shufflevector <8 x i64> %.splatinsert161, <8 x i64> poison, <8 x i32> zeroinitializer
  %120 = mul <8 x i64> %.splat162, splat (i64 32)
  %121 = add <8 x i64> %119, %120
  %122 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %118, 0
  %123 = insertvalue { <8 x ptr>, <8 x i64> } %122, <8 x i64> %121, 1
  %124 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %123, 1
  %126 = extractelement <8 x ptr> %124, i32 0
  %127 = extractelement <8 x i64> %125, i32 0
  %128 = sub i64 %127, 0
  %129 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %130 = select i1 %129, i64 %128, i64 0
  %private.contiguous.address = getelementptr i8, ptr %126, i64 %130
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %131 = select <8 x i1> %71, <8 x float> %117, <8 x float> %private.contiguous.preserve
  store <8 x float> %131, ptr %private.contiguous.address, align 4
  %.state163 = load i64, ptr %.slot, align 4
  %132 = add i64 %.state163, 1
  store i64 %132, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %133 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %135 = extractvalue { <8 x ptr>, <8 x i64> } %133, 0
  %136 = select <8 x i1> %71, <8 x ptr> %134, <8 x ptr> %135
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %138 = extractvalue { <8 x ptr>, <8 x i64> } %133, 1
  %139 = select <8 x i1> %71, <8 x i64> %137, <8 x i64> %138
  %140 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %136, 0
  %141 = insertvalue { <8 x ptr>, <8 x i64> } %140, <8 x i64> %139, 1
  store { <8 x ptr>, <8 x i64> } %141, ptr %tile_snapshot.spill32, align 64
  %142 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill33, align 64
  %143 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %144 = extractvalue { <8 x ptr>, <8 x i64> } %142, 0
  %145 = select <8 x i1> %71, <8 x ptr> %143, <8 x ptr> %144
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %142, 1
  %148 = select <8 x i1> %71, <8 x i64> %146, <8 x i64> %147
  %149 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %145, 0
  %150 = insertvalue { <8 x ptr>, <8 x i64> } %149, <8 x i64> %148, 1
  store { <8 x ptr>, <8 x i64> } %150, ptr %tile_snapshot.spill33, align 64
  store i64 0, ptr %.slot34, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state164 = load i64, ptr %.slot34, align 4
  %151 = icmp slt i64 %.state164, 96
  br i1 %151, label %direct.true165, label %direct.false166

direct.schedule.5:                                ; preds = %direct.true165
  %tile_snapshot.spill.load167 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %152 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load167, 0
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load167, 1
  %.state168 = load i64, ptr %.slot34, align 4
  %.splatinsert169 = insertelement <8 x i64> poison, i64 %.state168, i64 0
  %.splat170 = shufflevector <8 x i64> %.splatinsert169, <8 x i64> poison, <8 x i32> zeroinitializer
  %154 = mul <8 x i64> %.splat170, splat (i64 32)
  %155 = add <8 x i64> %153, %154
  %156 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %152, 0
  %157 = insertvalue { <8 x ptr>, <8 x i64> } %156, <8 x i64> %155, 1
  %158 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %159 = extractvalue { <8 x ptr>, <8 x i64> } %157, 1
  %160 = extractelement <8 x ptr> %158, i32 0
  %161 = extractelement <8 x i64> %159, i32 0
  %162 = sub i64 %161, 0
  %163 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %164 = select i1 %163, i64 %162, i64 0
  %private.contiguous.address171 = getelementptr i8, ptr %160, i64 %164
  %private.contiguous.preserve172 = load <8 x float>, ptr %private.contiguous.address171, align 4
  %165 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %private.contiguous.preserve172
  store <8 x float> %165, ptr %private.contiguous.address171, align 4
  %.state173 = load i64, ptr %.slot34, align 4
  %166 = add i64 %.state173, 1
  store i64 %166, ptr %.slot34, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false166
  store i64 0, ptr %.slot35, align 4
  %167 = load <8 x float>, ptr %.slot36, align 32
  %168 = select <8 x i1> %71, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %167
  store <8 x float> %168, ptr %.slot36, align 32
  %169 = load <8 x float>, ptr %.slot37, align 32
  %170 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %169
  store <8 x float> %170, ptr %.slot37, align 32
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.81, %direct.schedule.6
  %.state174 = load i64, ptr %.slot35, align 4
  %171 = icmp slt i64 %.state174, 129
  br i1 %171, label %direct.true175, label %direct.false176

direct.schedule.8:                                ; preds = %direct.true175
  %.state177 = load i64, ptr %.slot35, align 4
  %172 = sdiv i64 %.state177, 1
  %173 = mul i64 %172, 16
  store i64 %173, ptr %.spill38, align 4
  %174 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %174, 0
  %177 = select <8 x i1> %71, <8 x ptr> %175, <8 x ptr> %176
  %178 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %174, 1
  %180 = select <8 x i1> %71, <8 x i64> %178, <8 x i64> %179
  %181 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %177, 0
  %182 = insertvalue { <8 x ptr>, <8 x i64> } %181, <8 x i64> %180, 1
  store { <8 x ptr>, <8 x i64> } %182, ptr %tile_snapshot.spill39, align 64
  store i64 0, ptr %.slot40, align 4
  br label %direct.schedule.9

direct.schedule.9:                                ; preds = %direct.schedule.12, %direct.schedule.8
  %.state178 = load i64, ptr %.slot40, align 4
  %183 = icmp slt i64 %.state178, 1280
  br i1 %183, label %direct.true179, label %direct.false180

direct.schedule.10:                               ; preds = %direct.true179
  %.state181 = load i64, ptr %.slot40, align 4
  %184 = srem i64 %.state181, 80
  %.state182 = load i64, ptr %.slot40, align 4
  %185 = sdiv i64 %.state182, 80
  %.spill.load183 = load <8 x i64>, ptr %.spill, align 64
  %186 = add <8 x i64> %.spill.load183, zeroinitializer
  %187 = add <8 x i64> zeroinitializer, %186
  %.spill.load184 = load <8 x i64>, ptr %.spill31, align 64
  %188 = add <8 x i64> %.spill.load184, zeroinitializer
  %189 = mul <8 x i64> %187, splat (i64 1)
  %190 = add <8 x i64> %189, %188
  %.spill.load185 = load i64, ptr %.spill38, align 4
  %191 = add i64 %.spill.load185, %185
  %192 = mul <8 x i64> %190, splat (i64 2053)
  %.splatinsert186 = insertelement <8 x i64> poison, i64 %191, i64 0
  %.splat187 = shufflevector <8 x i64> %.splatinsert186, <8 x i64> poison, <8 x i32> zeroinitializer
  %193 = add <8 x i64> %192, %.splat187
  %194 = icmp sge i64 %191, 0
  %195 = and i1 true, %194
  %196 = icmp slt i64 %191, 2053
  %197 = and i1 %195, %196
  %198 = add i64 0, %184
  %199 = mul <8 x i64> %193, splat (i64 80)
  %.splatinsert188 = insertelement <8 x i64> poison, i64 %198, i64 0
  %.splat189 = shufflevector <8 x i64> %.splatinsert188, <8 x i64> poison, <8 x i32> zeroinitializer
  %200 = add <8 x i64> %199, %.splat189
  %201 = load <8 x i64>, ptr %.spill41, align 64
  %202 = select <8 x i1> %71, <8 x i64> %200, <8 x i64> %201
  store <8 x i64> %202, ptr %.spill41, align 64
  br i1 %197, label %direct.true190, label %direct.false191

direct.schedule.11:                               ; preds = %direct.true190
  %.spill.load192 = load <8 x i64>, ptr %.spill41, align 64
  %203 = extractvalue { ptr, i64 } %35, 0
  %204 = extractelement <8 x i64> %.spill.load192, i32 0
  %205 = mul i64 %204, 4
  %206 = getelementptr i8, ptr %203, i64 %205
  %207 = load float, ptr %206, align 4
  %.splatinsert193 = insertelement <8 x float> poison, float %207, i64 0
  %.splat194 = shufflevector <8 x float> %.splatinsert193, <8 x float> poison, <8 x i32> zeroinitializer
  %208 = load <8 x float>, ptr %.slot42, align 32
  %209 = select <8 x i1> %71, <8 x float> %.splat194, <8 x float> %208
  store <8 x float> %209, ptr %.slot42, align 32
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.schedule.11, %direct.false191
  %tile_snapshot.spill.load195 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %210 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load195, 0
  %211 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load195, 1
  %.state196 = load i64, ptr %.slot40, align 4
  %.splatinsert197 = insertelement <8 x i64> poison, i64 %.state196, i64 0
  %.splat198 = shufflevector <8 x i64> %.splatinsert197, <8 x i64> poison, <8 x i32> zeroinitializer
  %212 = mul <8 x i64> %.splat198, splat (i64 32)
  %213 = add <8 x i64> %211, %212
  %214 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %210, 0
  %215 = insertvalue { <8 x ptr>, <8 x i64> } %214, <8 x i64> %213, 1
  %.state199 = load <8 x float>, ptr %.slot42, align 32
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %217 = extractvalue { <8 x ptr>, <8 x i64> } %215, 1
  %218 = extractelement <8 x ptr> %216, i32 0
  %219 = extractelement <8 x i64> %217, i32 0
  %220 = sub i64 %219, 0
  %221 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %222 = select i1 %221, i64 %220, i64 0
  %private.contiguous.address200 = getelementptr i8, ptr %218, i64 %222
  %private.contiguous.preserve201 = load <8 x float>, ptr %private.contiguous.address200, align 4
  %223 = select <8 x i1> %71, <8 x float> %.state199, <8 x float> %private.contiguous.preserve201
  store <8 x float> %223, ptr %private.contiguous.address200, align 4
  %.state202 = load i64, ptr %.slot40, align 4
  %224 = add i64 %.state202, 1
  store i64 %224, ptr %.slot40, align 4
  br label %direct.schedule.9

direct.schedule.13:                               ; preds = %direct.false180
  %225 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %225, 0
  %228 = select <8 x i1> %71, <8 x ptr> %226, <8 x ptr> %227
  %229 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %230 = extractvalue { <8 x ptr>, <8 x i64> } %225, 1
  %231 = select <8 x i1> %71, <8 x i64> %229, <8 x i64> %230
  %232 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %228, 0
  %233 = insertvalue { <8 x ptr>, <8 x i64> } %232, <8 x i64> %231, 1
  store { <8 x ptr>, <8 x i64> } %233, ptr %tile_snapshot.spill43, align 64
  store i64 0, ptr %.slot44, align 4
  br label %direct.schedule.14

direct.schedule.14:                               ; preds = %direct.schedule.17, %direct.schedule.13
  %.state203 = load i64, ptr %.slot44, align 4
  %234 = icmp slt i64 %.state203, 1536
  br i1 %234, label %direct.true204, label %direct.false205

direct.schedule.15:                               ; preds = %direct.true204
  %.state206 = load i64, ptr %.slot44, align 4
  %235 = srem i64 %.state206, 96
  %.state207 = load i64, ptr %.slot44, align 4
  %236 = sdiv i64 %.state207, 96
  %.spill.load208 = load <8 x i64>, ptr %.spill, align 64
  %237 = add <8 x i64> %.spill.load208, zeroinitializer
  %238 = add <8 x i64> zeroinitializer, %237
  %.spill.load209 = load <8 x i64>, ptr %.spill31, align 64
  %239 = add <8 x i64> %.spill.load209, zeroinitializer
  %240 = mul <8 x i64> %238, splat (i64 1)
  %241 = add <8 x i64> %240, %239
  %.spill.load210 = load i64, ptr %.spill38, align 4
  %242 = add i64 %.spill.load210, %236
  %243 = mul <8 x i64> %241, splat (i64 2053)
  %.splatinsert211 = insertelement <8 x i64> poison, i64 %242, i64 0
  %.splat212 = shufflevector <8 x i64> %.splatinsert211, <8 x i64> poison, <8 x i32> zeroinitializer
  %244 = add <8 x i64> %243, %.splat212
  %245 = icmp sge i64 %242, 0
  %246 = and i1 true, %245
  %247 = icmp slt i64 %242, 2053
  %248 = and i1 %246, %247
  %249 = add i64 0, %235
  %250 = mul <8 x i64> %244, splat (i64 96)
  %.splatinsert213 = insertelement <8 x i64> poison, i64 %249, i64 0
  %.splat214 = shufflevector <8 x i64> %.splatinsert213, <8 x i64> poison, <8 x i32> zeroinitializer
  %251 = add <8 x i64> %250, %.splat214
  %252 = load <8 x i64>, ptr %.spill45, align 64
  %253 = select <8 x i1> %71, <8 x i64> %251, <8 x i64> %252
  store <8 x i64> %253, ptr %.spill45, align 64
  br i1 %248, label %direct.true215, label %direct.false216

direct.schedule.16:                               ; preds = %direct.true215
  %.spill.load217 = load <8 x i64>, ptr %.spill45, align 64
  %254 = extractvalue { ptr, i64 } %41, 0
  %255 = extractelement <8 x i64> %.spill.load217, i32 0
  %256 = mul i64 %255, 4
  %257 = getelementptr i8, ptr %254, i64 %256
  %258 = load float, ptr %257, align 4
  %.splatinsert218 = insertelement <8 x float> poison, float %258, i64 0
  %.splat219 = shufflevector <8 x float> %.splatinsert218, <8 x float> poison, <8 x i32> zeroinitializer
  %259 = load <8 x float>, ptr %.slot46, align 32
  %260 = select <8 x i1> %71, <8 x float> %.splat219, <8 x float> %259
  store <8 x float> %260, ptr %.slot46, align 32
  br label %direct.schedule.17

direct.schedule.17:                               ; preds = %direct.schedule.16, %direct.false216
  %tile_snapshot.spill.load220 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load220, 0
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load220, 1
  %.state221 = load i64, ptr %.slot44, align 4
  %.splatinsert222 = insertelement <8 x i64> poison, i64 %.state221, i64 0
  %.splat223 = shufflevector <8 x i64> %.splatinsert222, <8 x i64> poison, <8 x i32> zeroinitializer
  %263 = mul <8 x i64> %.splat223, splat (i64 32)
  %264 = add <8 x i64> %262, %263
  %265 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %261, 0
  %266 = insertvalue { <8 x ptr>, <8 x i64> } %265, <8 x i64> %264, 1
  %.state224 = load <8 x float>, ptr %.slot46, align 32
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %266, 1
  %269 = extractelement <8 x ptr> %267, i32 0
  %270 = extractelement <8 x i64> %268, i32 0
  %271 = sub i64 %270, 0
  %272 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %273 = select i1 %272, i64 %271, i64 0
  %private.contiguous.address225 = getelementptr i8, ptr %269, i64 %273
  %private.contiguous.preserve226 = load <8 x float>, ptr %private.contiguous.address225, align 4
  %274 = select <8 x i1> %71, <8 x float> %.state224, <8 x float> %private.contiguous.preserve226
  store <8 x float> %274, ptr %private.contiguous.address225, align 4
  %.state227 = load i64, ptr %.slot44, align 4
  %275 = add i64 %.state227, 1
  store i64 %275, ptr %.slot44, align 4
  br label %direct.schedule.14

direct.schedule.18:                               ; preds = %direct.false205
  store i64 0, ptr %.slot47, align 4
  %276 = load <8 x float>, ptr %.slot48, align 32
  %277 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %276
  store <8 x float> %277, ptr %.slot48, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state228 = load i64, ptr %.slot47, align 4
  %278 = icmp slt i64 %.state228, 80
  br i1 %278, label %direct.true229, label %direct.false230

direct.schedule.20:                               ; preds = %direct.true229
  %.state231 = load i64, ptr %.slot47, align 4
  %279 = add i64 0, %.state231
  %tile_snapshot.spill.load232 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %280 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load232, 0
  %281 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load232, 1
  %.splatinsert233 = insertelement <8 x i64> poison, i64 %279, i64 0
  %.splat234 = shufflevector <8 x i64> %.splatinsert233, <8 x i64> poison, <8 x i32> zeroinitializer
  %282 = mul <8 x i64> %.splat234, splat (i64 32)
  %283 = add <8 x i64> %281, %282
  %284 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %280, 0
  %285 = insertvalue { <8 x ptr>, <8 x i64> } %284, <8 x i64> %283, 1
  %286 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %285, 1
  %288 = extractelement <8 x ptr> %286, i32 0
  %289 = extractelement <8 x i64> %287, i32 0
  %290 = sub i64 %289, 0
  %291 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %292 = select i1 %291, i64 %290, i64 0
  %private.contiguous.address235 = getelementptr i8, ptr %288, i64 %292
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address235, align 4
  %293 = select <8 x i1> %71, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load236 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load236, 0
  %295 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load236, 1
  %.splatinsert237 = insertelement <8 x i64> poison, i64 %279, i64 0
  %.splat238 = shufflevector <8 x i64> %.splatinsert237, <8 x i64> poison, <8 x i32> zeroinitializer
  %296 = mul <8 x i64> %.splat238, splat (i64 32)
  %297 = add <8 x i64> %295, %296
  %298 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %294, 0
  %299 = insertvalue { <8 x ptr>, <8 x i64> } %298, <8 x i64> %297, 1
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %301 = extractvalue { <8 x ptr>, <8 x i64> } %299, 1
  %302 = extractelement <8 x ptr> %300, i32 0
  %303 = extractelement <8 x i64> %301, i32 0
  %304 = sub i64 %303, 0
  %305 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %306 = select i1 %305, i64 %304, i64 0
  %private.contiguous.address239 = getelementptr i8, ptr %302, i64 %306
  %private.contiguous.load240 = load <8 x float>, ptr %private.contiguous.address239, align 4
  %307 = select <8 x i1> %71, <8 x float> %private.contiguous.load240, <8 x float> zeroinitializer
  %308 = fmul <8 x float> %293, %307
  %.state241 = load <8 x float>, ptr %.slot48, align 32
  %309 = fadd <8 x float> %.state241, %308
  %.state242 = load i64, ptr %.slot47, align 4
  %310 = add i64 %.state242, 1
  store i64 %310, ptr %.slot47, align 4
  %311 = load <8 x float>, ptr %.slot48, align 32
  %312 = select <8 x i1> %71, <8 x float> %309, <8 x float> %311
  store <8 x float> %312, ptr %.slot48, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false230
  store i64 0, ptr %.slot49, align 4
  %313 = load <8 x float>, ptr %.slot50, align 32
  %314 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %313
  store <8 x float> %314, ptr %.slot50, align 32
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state243 = load i64, ptr %.slot49, align 4
  %315 = icmp slt i64 %.state243, 80
  br i1 %315, label %direct.true244, label %direct.false245

direct.schedule.23:                               ; preds = %direct.true244
  %.state246 = load i64, ptr %.slot49, align 4
  %316 = add i64 0, %.state246
  %tile_snapshot.spill.load247 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %317 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load247, 0
  %318 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load247, 1
  %.splatinsert248 = insertelement <8 x i64> poison, i64 %316, i64 0
  %.splat249 = shufflevector <8 x i64> %.splatinsert248, <8 x i64> poison, <8 x i32> zeroinitializer
  %319 = mul <8 x i64> %.splat249, splat (i64 32)
  %320 = add <8 x i64> %318, %319
  %321 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %317, 0
  %322 = insertvalue { <8 x ptr>, <8 x i64> } %321, <8 x i64> %320, 1
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %322, 1
  %325 = extractelement <8 x ptr> %323, i32 0
  %326 = extractelement <8 x i64> %324, i32 0
  %327 = sub i64 %326, 0
  %328 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %329 = select i1 %328, i64 %327, i64 0
  %private.contiguous.address250 = getelementptr i8, ptr %325, i64 %329
  %private.contiguous.load251 = load <8 x float>, ptr %private.contiguous.address250, align 4
  %330 = select <8 x i1> %71, <8 x float> %private.contiguous.load251, <8 x float> zeroinitializer
  %.state252 = load i64, ptr %.slot49, align 4
  %331 = add i64 80, %.state252
  %tile_snapshot.spill.load253 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %332 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load253, 0
  %333 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load253, 1
  %.splatinsert254 = insertelement <8 x i64> poison, i64 %331, i64 0
  %.splat255 = shufflevector <8 x i64> %.splatinsert254, <8 x i64> poison, <8 x i32> zeroinitializer
  %334 = mul <8 x i64> %.splat255, splat (i64 32)
  %335 = add <8 x i64> %333, %334
  %336 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %332, 0
  %337 = insertvalue { <8 x ptr>, <8 x i64> } %336, <8 x i64> %335, 1
  %338 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %339 = extractvalue { <8 x ptr>, <8 x i64> } %337, 1
  %340 = extractelement <8 x ptr> %338, i32 0
  %341 = extractelement <8 x i64> %339, i32 0
  %342 = sub i64 %341, 0
  %343 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %344 = select i1 %343, i64 %342, i64 0
  %private.contiguous.address256 = getelementptr i8, ptr %340, i64 %344
  %private.contiguous.load257 = load <8 x float>, ptr %private.contiguous.address256, align 4
  %345 = select <8 x i1> %71, <8 x float> %private.contiguous.load257, <8 x float> zeroinitializer
  %346 = fmul <8 x float> %330, %345
  %.state258 = load <8 x float>, ptr %.slot50, align 32
  %347 = fadd <8 x float> %.state258, %346
  %.state259 = load i64, ptr %.slot49, align 4
  %348 = add i64 %.state259, 1
  store i64 %348, ptr %.slot49, align 4
  %349 = load <8 x float>, ptr %.slot50, align 32
  %350 = select <8 x i1> %71, <8 x float> %347, <8 x float> %349
  store <8 x float> %350, ptr %.slot50, align 32
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false245
  store i64 0, ptr %.slot51, align 4
  %351 = load <8 x float>, ptr %.slot52, align 32
  %352 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %351
  store <8 x float> %352, ptr %.slot52, align 32
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.26, %direct.schedule.24
  %.state260 = load i64, ptr %.slot51, align 4
  %353 = icmp slt i64 %.state260, 80
  br i1 %353, label %direct.true261, label %direct.false262

direct.schedule.26:                               ; preds = %direct.true261
  %.state263 = load i64, ptr %.slot51, align 4
  %354 = add i64 0, %.state263
  %tile_snapshot.spill.load264 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %355 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load264, 0
  %356 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load264, 1
  %.splatinsert265 = insertelement <8 x i64> poison, i64 %354, i64 0
  %.splat266 = shufflevector <8 x i64> %.splatinsert265, <8 x i64> poison, <8 x i32> zeroinitializer
  %357 = mul <8 x i64> %.splat266, splat (i64 32)
  %358 = add <8 x i64> %356, %357
  %359 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %355, 0
  %360 = insertvalue { <8 x ptr>, <8 x i64> } %359, <8 x i64> %358, 1
  %361 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %362 = extractvalue { <8 x ptr>, <8 x i64> } %360, 1
  %363 = extractelement <8 x ptr> %361, i32 0
  %364 = extractelement <8 x i64> %362, i32 0
  %365 = sub i64 %364, 0
  %366 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %367 = select i1 %366, i64 %365, i64 0
  %private.contiguous.address267 = getelementptr i8, ptr %363, i64 %367
  %private.contiguous.load268 = load <8 x float>, ptr %private.contiguous.address267, align 4
  %368 = select <8 x i1> %71, <8 x float> %private.contiguous.load268, <8 x float> zeroinitializer
  %.state269 = load i64, ptr %.slot51, align 4
  %369 = add i64 160, %.state269
  %tile_snapshot.spill.load270 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %370 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 0
  %371 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 1
  %.splatinsert271 = insertelement <8 x i64> poison, i64 %369, i64 0
  %.splat272 = shufflevector <8 x i64> %.splatinsert271, <8 x i64> poison, <8 x i32> zeroinitializer
  %372 = mul <8 x i64> %.splat272, splat (i64 32)
  %373 = add <8 x i64> %371, %372
  %374 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %370, 0
  %375 = insertvalue { <8 x ptr>, <8 x i64> } %374, <8 x i64> %373, 1
  %376 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %377 = extractvalue { <8 x ptr>, <8 x i64> } %375, 1
  %378 = extractelement <8 x ptr> %376, i32 0
  %379 = extractelement <8 x i64> %377, i32 0
  %380 = sub i64 %379, 0
  %381 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %382 = select i1 %381, i64 %380, i64 0
  %private.contiguous.address273 = getelementptr i8, ptr %378, i64 %382
  %private.contiguous.load274 = load <8 x float>, ptr %private.contiguous.address273, align 4
  %383 = select <8 x i1> %71, <8 x float> %private.contiguous.load274, <8 x float> zeroinitializer
  %384 = fmul <8 x float> %368, %383
  %.state275 = load <8 x float>, ptr %.slot52, align 32
  %385 = fadd <8 x float> %.state275, %384
  %.state276 = load i64, ptr %.slot51, align 4
  %386 = add i64 %.state276, 1
  store i64 %386, ptr %.slot51, align 4
  %387 = load <8 x float>, ptr %.slot52, align 32
  %388 = select <8 x i1> %71, <8 x float> %385, <8 x float> %387
  store <8 x float> %388, ptr %.slot52, align 32
  br label %direct.schedule.25

direct.schedule.27:                               ; preds = %direct.false262
  store i64 0, ptr %.slot53, align 4
  %389 = load <8 x float>, ptr %.slot54, align 32
  %390 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %389
  store <8 x float> %390, ptr %.slot54, align 32
  br label %direct.schedule.28

direct.schedule.28:                               ; preds = %direct.schedule.29, %direct.schedule.27
  %.state277 = load i64, ptr %.slot53, align 4
  %391 = icmp slt i64 %.state277, 80
  br i1 %391, label %direct.true278, label %direct.false279

direct.schedule.29:                               ; preds = %direct.true278
  %.state280 = load i64, ptr %.slot53, align 4
  %392 = add i64 0, %.state280
  %tile_snapshot.spill.load281 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %393 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 0
  %394 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 1
  %.splatinsert282 = insertelement <8 x i64> poison, i64 %392, i64 0
  %.splat283 = shufflevector <8 x i64> %.splatinsert282, <8 x i64> poison, <8 x i32> zeroinitializer
  %395 = mul <8 x i64> %.splat283, splat (i64 32)
  %396 = add <8 x i64> %394, %395
  %397 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %393, 0
  %398 = insertvalue { <8 x ptr>, <8 x i64> } %397, <8 x i64> %396, 1
  %399 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %400 = extractvalue { <8 x ptr>, <8 x i64> } %398, 1
  %401 = extractelement <8 x ptr> %399, i32 0
  %402 = extractelement <8 x i64> %400, i32 0
  %403 = sub i64 %402, 0
  %404 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %405 = select i1 %404, i64 %403, i64 0
  %private.contiguous.address284 = getelementptr i8, ptr %401, i64 %405
  %private.contiguous.load285 = load <8 x float>, ptr %private.contiguous.address284, align 4
  %406 = select <8 x i1> %71, <8 x float> %private.contiguous.load285, <8 x float> zeroinitializer
  %.state286 = load i64, ptr %.slot53, align 4
  %407 = add i64 240, %.state286
  %tile_snapshot.spill.load287 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %408 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load287, 0
  %409 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load287, 1
  %.splatinsert288 = insertelement <8 x i64> poison, i64 %407, i64 0
  %.splat289 = shufflevector <8 x i64> %.splatinsert288, <8 x i64> poison, <8 x i32> zeroinitializer
  %410 = mul <8 x i64> %.splat289, splat (i64 32)
  %411 = add <8 x i64> %409, %410
  %412 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %408, 0
  %413 = insertvalue { <8 x ptr>, <8 x i64> } %412, <8 x i64> %411, 1
  %414 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %415 = extractvalue { <8 x ptr>, <8 x i64> } %413, 1
  %416 = extractelement <8 x ptr> %414, i32 0
  %417 = extractelement <8 x i64> %415, i32 0
  %418 = sub i64 %417, 0
  %419 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %420 = select i1 %419, i64 %418, i64 0
  %private.contiguous.address290 = getelementptr i8, ptr %416, i64 %420
  %private.contiguous.load291 = load <8 x float>, ptr %private.contiguous.address290, align 4
  %421 = select <8 x i1> %71, <8 x float> %private.contiguous.load291, <8 x float> zeroinitializer
  %422 = fmul <8 x float> %406, %421
  %.state292 = load <8 x float>, ptr %.slot54, align 32
  %423 = fadd <8 x float> %.state292, %422
  %.state293 = load i64, ptr %.slot53, align 4
  %424 = add i64 %.state293, 1
  store i64 %424, ptr %.slot53, align 4
  %425 = load <8 x float>, ptr %.slot54, align 32
  %426 = select <8 x i1> %71, <8 x float> %423, <8 x float> %425
  store <8 x float> %426, ptr %.slot54, align 32
  br label %direct.schedule.28

direct.schedule.30:                               ; preds = %direct.false279
  store i64 0, ptr %.slot55, align 4
  %427 = load <8 x float>, ptr %.slot56, align 32
  %428 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %427
  store <8 x float> %428, ptr %.slot56, align 32
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.32, %direct.schedule.30
  %.state294 = load i64, ptr %.slot55, align 4
  %429 = icmp slt i64 %.state294, 80
  br i1 %429, label %direct.true295, label %direct.false296

direct.schedule.32:                               ; preds = %direct.true295
  %.state297 = load i64, ptr %.slot55, align 4
  %430 = add i64 0, %.state297
  %tile_snapshot.spill.load298 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %431 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load298, 0
  %432 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load298, 1
  %.splatinsert299 = insertelement <8 x i64> poison, i64 %430, i64 0
  %.splat300 = shufflevector <8 x i64> %.splatinsert299, <8 x i64> poison, <8 x i32> zeroinitializer
  %433 = mul <8 x i64> %.splat300, splat (i64 32)
  %434 = add <8 x i64> %432, %433
  %435 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %431, 0
  %436 = insertvalue { <8 x ptr>, <8 x i64> } %435, <8 x i64> %434, 1
  %437 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %438 = extractvalue { <8 x ptr>, <8 x i64> } %436, 1
  %439 = extractelement <8 x ptr> %437, i32 0
  %440 = extractelement <8 x i64> %438, i32 0
  %441 = sub i64 %440, 0
  %442 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %443 = select i1 %442, i64 %441, i64 0
  %private.contiguous.address301 = getelementptr i8, ptr %439, i64 %443
  %private.contiguous.load302 = load <8 x float>, ptr %private.contiguous.address301, align 4
  %444 = select <8 x i1> %71, <8 x float> %private.contiguous.load302, <8 x float> zeroinitializer
  %.state303 = load i64, ptr %.slot55, align 4
  %445 = add i64 320, %.state303
  %tile_snapshot.spill.load304 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %446 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load304, 0
  %447 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load304, 1
  %.splatinsert305 = insertelement <8 x i64> poison, i64 %445, i64 0
  %.splat306 = shufflevector <8 x i64> %.splatinsert305, <8 x i64> poison, <8 x i32> zeroinitializer
  %448 = mul <8 x i64> %.splat306, splat (i64 32)
  %449 = add <8 x i64> %447, %448
  %450 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %446, 0
  %451 = insertvalue { <8 x ptr>, <8 x i64> } %450, <8 x i64> %449, 1
  %452 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %453 = extractvalue { <8 x ptr>, <8 x i64> } %451, 1
  %454 = extractelement <8 x ptr> %452, i32 0
  %455 = extractelement <8 x i64> %453, i32 0
  %456 = sub i64 %455, 0
  %457 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %458 = select i1 %457, i64 %456, i64 0
  %private.contiguous.address307 = getelementptr i8, ptr %454, i64 %458
  %private.contiguous.load308 = load <8 x float>, ptr %private.contiguous.address307, align 4
  %459 = select <8 x i1> %71, <8 x float> %private.contiguous.load308, <8 x float> zeroinitializer
  %460 = fmul <8 x float> %444, %459
  %.state309 = load <8 x float>, ptr %.slot56, align 32
  %461 = fadd <8 x float> %.state309, %460
  %.state310 = load i64, ptr %.slot55, align 4
  %462 = add i64 %.state310, 1
  store i64 %462, ptr %.slot55, align 4
  %463 = load <8 x float>, ptr %.slot56, align 32
  %464 = select <8 x i1> %71, <8 x float> %461, <8 x float> %463
  store <8 x float> %464, ptr %.slot56, align 32
  br label %direct.schedule.31

direct.schedule.33:                               ; preds = %direct.false296
  store i64 0, ptr %.slot57, align 4
  %465 = load <8 x float>, ptr %.slot58, align 32
  %466 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %465
  store <8 x float> %466, ptr %.slot58, align 32
  br label %direct.schedule.34

direct.schedule.34:                               ; preds = %direct.schedule.35, %direct.schedule.33
  %.state311 = load i64, ptr %.slot57, align 4
  %467 = icmp slt i64 %.state311, 80
  br i1 %467, label %direct.true312, label %direct.false313

direct.schedule.35:                               ; preds = %direct.true312
  %.state314 = load i64, ptr %.slot57, align 4
  %468 = add i64 0, %.state314
  %tile_snapshot.spill.load315 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %469 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load315, 0
  %470 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load315, 1
  %.splatinsert316 = insertelement <8 x i64> poison, i64 %468, i64 0
  %.splat317 = shufflevector <8 x i64> %.splatinsert316, <8 x i64> poison, <8 x i32> zeroinitializer
  %471 = mul <8 x i64> %.splat317, splat (i64 32)
  %472 = add <8 x i64> %470, %471
  %473 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %469, 0
  %474 = insertvalue { <8 x ptr>, <8 x i64> } %473, <8 x i64> %472, 1
  %475 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %476 = extractvalue { <8 x ptr>, <8 x i64> } %474, 1
  %477 = extractelement <8 x ptr> %475, i32 0
  %478 = extractelement <8 x i64> %476, i32 0
  %479 = sub i64 %478, 0
  %480 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %481 = select i1 %480, i64 %479, i64 0
  %private.contiguous.address318 = getelementptr i8, ptr %477, i64 %481
  %private.contiguous.load319 = load <8 x float>, ptr %private.contiguous.address318, align 4
  %482 = select <8 x i1> %71, <8 x float> %private.contiguous.load319, <8 x float> zeroinitializer
  %.state320 = load i64, ptr %.slot57, align 4
  %483 = add i64 400, %.state320
  %tile_snapshot.spill.load321 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %484 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load321, 0
  %485 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load321, 1
  %.splatinsert322 = insertelement <8 x i64> poison, i64 %483, i64 0
  %.splat323 = shufflevector <8 x i64> %.splatinsert322, <8 x i64> poison, <8 x i32> zeroinitializer
  %486 = mul <8 x i64> %.splat323, splat (i64 32)
  %487 = add <8 x i64> %485, %486
  %488 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %484, 0
  %489 = insertvalue { <8 x ptr>, <8 x i64> } %488, <8 x i64> %487, 1
  %490 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %491 = extractvalue { <8 x ptr>, <8 x i64> } %489, 1
  %492 = extractelement <8 x ptr> %490, i32 0
  %493 = extractelement <8 x i64> %491, i32 0
  %494 = sub i64 %493, 0
  %495 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %496 = select i1 %495, i64 %494, i64 0
  %private.contiguous.address324 = getelementptr i8, ptr %492, i64 %496
  %private.contiguous.load325 = load <8 x float>, ptr %private.contiguous.address324, align 4
  %497 = select <8 x i1> %71, <8 x float> %private.contiguous.load325, <8 x float> zeroinitializer
  %498 = fmul <8 x float> %482, %497
  %.state326 = load <8 x float>, ptr %.slot58, align 32
  %499 = fadd <8 x float> %.state326, %498
  %.state327 = load i64, ptr %.slot57, align 4
  %500 = add i64 %.state327, 1
  store i64 %500, ptr %.slot57, align 4
  %501 = load <8 x float>, ptr %.slot58, align 32
  %502 = select <8 x i1> %71, <8 x float> %499, <8 x float> %501
  store <8 x float> %502, ptr %.slot58, align 32
  br label %direct.schedule.34

direct.schedule.36:                               ; preds = %direct.false313
  store i64 0, ptr %.slot59, align 4
  %503 = load <8 x float>, ptr %.slot60, align 32
  %504 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %503
  store <8 x float> %504, ptr %.slot60, align 32
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.38, %direct.schedule.36
  %.state328 = load i64, ptr %.slot59, align 4
  %505 = icmp slt i64 %.state328, 80
  br i1 %505, label %direct.true329, label %direct.false330

direct.schedule.38:                               ; preds = %direct.true329
  %.state331 = load i64, ptr %.slot59, align 4
  %506 = add i64 0, %.state331
  %tile_snapshot.spill.load332 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %507 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load332, 0
  %508 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load332, 1
  %.splatinsert333 = insertelement <8 x i64> poison, i64 %506, i64 0
  %.splat334 = shufflevector <8 x i64> %.splatinsert333, <8 x i64> poison, <8 x i32> zeroinitializer
  %509 = mul <8 x i64> %.splat334, splat (i64 32)
  %510 = add <8 x i64> %508, %509
  %511 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %507, 0
  %512 = insertvalue { <8 x ptr>, <8 x i64> } %511, <8 x i64> %510, 1
  %513 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %514 = extractvalue { <8 x ptr>, <8 x i64> } %512, 1
  %515 = extractelement <8 x ptr> %513, i32 0
  %516 = extractelement <8 x i64> %514, i32 0
  %517 = sub i64 %516, 0
  %518 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %519 = select i1 %518, i64 %517, i64 0
  %private.contiguous.address335 = getelementptr i8, ptr %515, i64 %519
  %private.contiguous.load336 = load <8 x float>, ptr %private.contiguous.address335, align 4
  %520 = select <8 x i1> %71, <8 x float> %private.contiguous.load336, <8 x float> zeroinitializer
  %.state337 = load i64, ptr %.slot59, align 4
  %521 = add i64 480, %.state337
  %tile_snapshot.spill.load338 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %522 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load338, 0
  %523 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load338, 1
  %.splatinsert339 = insertelement <8 x i64> poison, i64 %521, i64 0
  %.splat340 = shufflevector <8 x i64> %.splatinsert339, <8 x i64> poison, <8 x i32> zeroinitializer
  %524 = mul <8 x i64> %.splat340, splat (i64 32)
  %525 = add <8 x i64> %523, %524
  %526 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %522, 0
  %527 = insertvalue { <8 x ptr>, <8 x i64> } %526, <8 x i64> %525, 1
  %528 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %527, 1
  %530 = extractelement <8 x ptr> %528, i32 0
  %531 = extractelement <8 x i64> %529, i32 0
  %532 = sub i64 %531, 0
  %533 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %534 = select i1 %533, i64 %532, i64 0
  %private.contiguous.address341 = getelementptr i8, ptr %530, i64 %534
  %private.contiguous.load342 = load <8 x float>, ptr %private.contiguous.address341, align 4
  %535 = select <8 x i1> %71, <8 x float> %private.contiguous.load342, <8 x float> zeroinitializer
  %536 = fmul <8 x float> %520, %535
  %.state343 = load <8 x float>, ptr %.slot60, align 32
  %537 = fadd <8 x float> %.state343, %536
  %.state344 = load i64, ptr %.slot59, align 4
  %538 = add i64 %.state344, 1
  store i64 %538, ptr %.slot59, align 4
  %539 = load <8 x float>, ptr %.slot60, align 32
  %540 = select <8 x i1> %71, <8 x float> %537, <8 x float> %539
  store <8 x float> %540, ptr %.slot60, align 32
  br label %direct.schedule.37

direct.schedule.39:                               ; preds = %direct.false330
  store i64 0, ptr %.slot61, align 4
  %541 = load <8 x float>, ptr %.slot62, align 32
  %542 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %541
  store <8 x float> %542, ptr %.slot62, align 32
  br label %direct.schedule.40

direct.schedule.40:                               ; preds = %direct.schedule.41, %direct.schedule.39
  %.state345 = load i64, ptr %.slot61, align 4
  %543 = icmp slt i64 %.state345, 80
  br i1 %543, label %direct.true346, label %direct.false347

direct.schedule.41:                               ; preds = %direct.true346
  %.state348 = load i64, ptr %.slot61, align 4
  %544 = add i64 0, %.state348
  %tile_snapshot.spill.load349 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %545 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load349, 0
  %546 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load349, 1
  %.splatinsert350 = insertelement <8 x i64> poison, i64 %544, i64 0
  %.splat351 = shufflevector <8 x i64> %.splatinsert350, <8 x i64> poison, <8 x i32> zeroinitializer
  %547 = mul <8 x i64> %.splat351, splat (i64 32)
  %548 = add <8 x i64> %546, %547
  %549 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %545, 0
  %550 = insertvalue { <8 x ptr>, <8 x i64> } %549, <8 x i64> %548, 1
  %551 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %552 = extractvalue { <8 x ptr>, <8 x i64> } %550, 1
  %553 = extractelement <8 x ptr> %551, i32 0
  %554 = extractelement <8 x i64> %552, i32 0
  %555 = sub i64 %554, 0
  %556 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %557 = select i1 %556, i64 %555, i64 0
  %private.contiguous.address352 = getelementptr i8, ptr %553, i64 %557
  %private.contiguous.load353 = load <8 x float>, ptr %private.contiguous.address352, align 4
  %558 = select <8 x i1> %71, <8 x float> %private.contiguous.load353, <8 x float> zeroinitializer
  %.state354 = load i64, ptr %.slot61, align 4
  %559 = add i64 560, %.state354
  %tile_snapshot.spill.load355 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %560 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load355, 0
  %561 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load355, 1
  %.splatinsert356 = insertelement <8 x i64> poison, i64 %559, i64 0
  %.splat357 = shufflevector <8 x i64> %.splatinsert356, <8 x i64> poison, <8 x i32> zeroinitializer
  %562 = mul <8 x i64> %.splat357, splat (i64 32)
  %563 = add <8 x i64> %561, %562
  %564 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %560, 0
  %565 = insertvalue { <8 x ptr>, <8 x i64> } %564, <8 x i64> %563, 1
  %566 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %567 = extractvalue { <8 x ptr>, <8 x i64> } %565, 1
  %568 = extractelement <8 x ptr> %566, i32 0
  %569 = extractelement <8 x i64> %567, i32 0
  %570 = sub i64 %569, 0
  %571 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %572 = select i1 %571, i64 %570, i64 0
  %private.contiguous.address358 = getelementptr i8, ptr %568, i64 %572
  %private.contiguous.load359 = load <8 x float>, ptr %private.contiguous.address358, align 4
  %573 = select <8 x i1> %71, <8 x float> %private.contiguous.load359, <8 x float> zeroinitializer
  %574 = fmul <8 x float> %558, %573
  %.state360 = load <8 x float>, ptr %.slot62, align 32
  %575 = fadd <8 x float> %.state360, %574
  %.state361 = load i64, ptr %.slot61, align 4
  %576 = add i64 %.state361, 1
  store i64 %576, ptr %.slot61, align 4
  %577 = load <8 x float>, ptr %.slot62, align 32
  %578 = select <8 x i1> %71, <8 x float> %575, <8 x float> %577
  store <8 x float> %578, ptr %.slot62, align 32
  br label %direct.schedule.40

direct.schedule.42:                               ; preds = %direct.false347
  store i64 0, ptr %.slot63, align 4
  %579 = load <8 x float>, ptr %.slot64, align 32
  %580 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %579
  store <8 x float> %580, ptr %.slot64, align 32
  br label %direct.schedule.43

direct.schedule.43:                               ; preds = %direct.schedule.44, %direct.schedule.42
  %.state362 = load i64, ptr %.slot63, align 4
  %581 = icmp slt i64 %.state362, 80
  br i1 %581, label %direct.true363, label %direct.false364

direct.schedule.44:                               ; preds = %direct.true363
  %.state365 = load i64, ptr %.slot63, align 4
  %582 = add i64 0, %.state365
  %tile_snapshot.spill.load366 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %583 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load366, 0
  %584 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load366, 1
  %.splatinsert367 = insertelement <8 x i64> poison, i64 %582, i64 0
  %.splat368 = shufflevector <8 x i64> %.splatinsert367, <8 x i64> poison, <8 x i32> zeroinitializer
  %585 = mul <8 x i64> %.splat368, splat (i64 32)
  %586 = add <8 x i64> %584, %585
  %587 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %583, 0
  %588 = insertvalue { <8 x ptr>, <8 x i64> } %587, <8 x i64> %586, 1
  %589 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %590 = extractvalue { <8 x ptr>, <8 x i64> } %588, 1
  %591 = extractelement <8 x ptr> %589, i32 0
  %592 = extractelement <8 x i64> %590, i32 0
  %593 = sub i64 %592, 0
  %594 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %595 = select i1 %594, i64 %593, i64 0
  %private.contiguous.address369 = getelementptr i8, ptr %591, i64 %595
  %private.contiguous.load370 = load <8 x float>, ptr %private.contiguous.address369, align 4
  %596 = select <8 x i1> %71, <8 x float> %private.contiguous.load370, <8 x float> zeroinitializer
  %.state371 = load i64, ptr %.slot63, align 4
  %597 = add i64 640, %.state371
  %tile_snapshot.spill.load372 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %598 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load372, 0
  %599 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load372, 1
  %.splatinsert373 = insertelement <8 x i64> poison, i64 %597, i64 0
  %.splat374 = shufflevector <8 x i64> %.splatinsert373, <8 x i64> poison, <8 x i32> zeroinitializer
  %600 = mul <8 x i64> %.splat374, splat (i64 32)
  %601 = add <8 x i64> %599, %600
  %602 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %598, 0
  %603 = insertvalue { <8 x ptr>, <8 x i64> } %602, <8 x i64> %601, 1
  %604 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %605 = extractvalue { <8 x ptr>, <8 x i64> } %603, 1
  %606 = extractelement <8 x ptr> %604, i32 0
  %607 = extractelement <8 x i64> %605, i32 0
  %608 = sub i64 %607, 0
  %609 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %610 = select i1 %609, i64 %608, i64 0
  %private.contiguous.address375 = getelementptr i8, ptr %606, i64 %610
  %private.contiguous.load376 = load <8 x float>, ptr %private.contiguous.address375, align 4
  %611 = select <8 x i1> %71, <8 x float> %private.contiguous.load376, <8 x float> zeroinitializer
  %612 = fmul <8 x float> %596, %611
  %.state377 = load <8 x float>, ptr %.slot64, align 32
  %613 = fadd <8 x float> %.state377, %612
  %.state378 = load i64, ptr %.slot63, align 4
  %614 = add i64 %.state378, 1
  store i64 %614, ptr %.slot63, align 4
  %615 = load <8 x float>, ptr %.slot64, align 32
  %616 = select <8 x i1> %71, <8 x float> %613, <8 x float> %615
  store <8 x float> %616, ptr %.slot64, align 32
  br label %direct.schedule.43

direct.schedule.45:                               ; preds = %direct.false364
  store i64 0, ptr %.slot65, align 4
  %617 = load <8 x float>, ptr %.slot66, align 32
  %618 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %617
  store <8 x float> %618, ptr %.slot66, align 32
  br label %direct.schedule.46

direct.schedule.46:                               ; preds = %direct.schedule.47, %direct.schedule.45
  %.state379 = load i64, ptr %.slot65, align 4
  %619 = icmp slt i64 %.state379, 80
  br i1 %619, label %direct.true380, label %direct.false381

direct.schedule.47:                               ; preds = %direct.true380
  %.state382 = load i64, ptr %.slot65, align 4
  %620 = add i64 0, %.state382
  %tile_snapshot.spill.load383 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %621 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load383, 0
  %622 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load383, 1
  %.splatinsert384 = insertelement <8 x i64> poison, i64 %620, i64 0
  %.splat385 = shufflevector <8 x i64> %.splatinsert384, <8 x i64> poison, <8 x i32> zeroinitializer
  %623 = mul <8 x i64> %.splat385, splat (i64 32)
  %624 = add <8 x i64> %622, %623
  %625 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %621, 0
  %626 = insertvalue { <8 x ptr>, <8 x i64> } %625, <8 x i64> %624, 1
  %627 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %628 = extractvalue { <8 x ptr>, <8 x i64> } %626, 1
  %629 = extractelement <8 x ptr> %627, i32 0
  %630 = extractelement <8 x i64> %628, i32 0
  %631 = sub i64 %630, 0
  %632 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %633 = select i1 %632, i64 %631, i64 0
  %private.contiguous.address386 = getelementptr i8, ptr %629, i64 %633
  %private.contiguous.load387 = load <8 x float>, ptr %private.contiguous.address386, align 4
  %634 = select <8 x i1> %71, <8 x float> %private.contiguous.load387, <8 x float> zeroinitializer
  %.state388 = load i64, ptr %.slot65, align 4
  %635 = add i64 720, %.state388
  %tile_snapshot.spill.load389 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %636 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load389, 0
  %637 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load389, 1
  %.splatinsert390 = insertelement <8 x i64> poison, i64 %635, i64 0
  %.splat391 = shufflevector <8 x i64> %.splatinsert390, <8 x i64> poison, <8 x i32> zeroinitializer
  %638 = mul <8 x i64> %.splat391, splat (i64 32)
  %639 = add <8 x i64> %637, %638
  %640 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %636, 0
  %641 = insertvalue { <8 x ptr>, <8 x i64> } %640, <8 x i64> %639, 1
  %642 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %643 = extractvalue { <8 x ptr>, <8 x i64> } %641, 1
  %644 = extractelement <8 x ptr> %642, i32 0
  %645 = extractelement <8 x i64> %643, i32 0
  %646 = sub i64 %645, 0
  %647 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %648 = select i1 %647, i64 %646, i64 0
  %private.contiguous.address392 = getelementptr i8, ptr %644, i64 %648
  %private.contiguous.load393 = load <8 x float>, ptr %private.contiguous.address392, align 4
  %649 = select <8 x i1> %71, <8 x float> %private.contiguous.load393, <8 x float> zeroinitializer
  %650 = fmul <8 x float> %634, %649
  %.state394 = load <8 x float>, ptr %.slot66, align 32
  %651 = fadd <8 x float> %.state394, %650
  %.state395 = load i64, ptr %.slot65, align 4
  %652 = add i64 %.state395, 1
  store i64 %652, ptr %.slot65, align 4
  %653 = load <8 x float>, ptr %.slot66, align 32
  %654 = select <8 x i1> %71, <8 x float> %651, <8 x float> %653
  store <8 x float> %654, ptr %.slot66, align 32
  br label %direct.schedule.46

direct.schedule.48:                               ; preds = %direct.false381
  store i64 0, ptr %.slot67, align 4
  %655 = load <8 x float>, ptr %.slot68, align 32
  %656 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %655
  store <8 x float> %656, ptr %.slot68, align 32
  br label %direct.schedule.49

direct.schedule.49:                               ; preds = %direct.schedule.50, %direct.schedule.48
  %.state396 = load i64, ptr %.slot67, align 4
  %657 = icmp slt i64 %.state396, 80
  br i1 %657, label %direct.true397, label %direct.false398

direct.schedule.50:                               ; preds = %direct.true397
  %.state399 = load i64, ptr %.slot67, align 4
  %658 = add i64 0, %.state399
  %tile_snapshot.spill.load400 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %659 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load400, 0
  %660 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load400, 1
  %.splatinsert401 = insertelement <8 x i64> poison, i64 %658, i64 0
  %.splat402 = shufflevector <8 x i64> %.splatinsert401, <8 x i64> poison, <8 x i32> zeroinitializer
  %661 = mul <8 x i64> %.splat402, splat (i64 32)
  %662 = add <8 x i64> %660, %661
  %663 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %659, 0
  %664 = insertvalue { <8 x ptr>, <8 x i64> } %663, <8 x i64> %662, 1
  %665 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %666 = extractvalue { <8 x ptr>, <8 x i64> } %664, 1
  %667 = extractelement <8 x ptr> %665, i32 0
  %668 = extractelement <8 x i64> %666, i32 0
  %669 = sub i64 %668, 0
  %670 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %671 = select i1 %670, i64 %669, i64 0
  %private.contiguous.address403 = getelementptr i8, ptr %667, i64 %671
  %private.contiguous.load404 = load <8 x float>, ptr %private.contiguous.address403, align 4
  %672 = select <8 x i1> %71, <8 x float> %private.contiguous.load404, <8 x float> zeroinitializer
  %.state405 = load i64, ptr %.slot67, align 4
  %673 = add i64 800, %.state405
  %tile_snapshot.spill.load406 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %674 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load406, 0
  %675 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load406, 1
  %.splatinsert407 = insertelement <8 x i64> poison, i64 %673, i64 0
  %.splat408 = shufflevector <8 x i64> %.splatinsert407, <8 x i64> poison, <8 x i32> zeroinitializer
  %676 = mul <8 x i64> %.splat408, splat (i64 32)
  %677 = add <8 x i64> %675, %676
  %678 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %674, 0
  %679 = insertvalue { <8 x ptr>, <8 x i64> } %678, <8 x i64> %677, 1
  %680 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %681 = extractvalue { <8 x ptr>, <8 x i64> } %679, 1
  %682 = extractelement <8 x ptr> %680, i32 0
  %683 = extractelement <8 x i64> %681, i32 0
  %684 = sub i64 %683, 0
  %685 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %686 = select i1 %685, i64 %684, i64 0
  %private.contiguous.address409 = getelementptr i8, ptr %682, i64 %686
  %private.contiguous.load410 = load <8 x float>, ptr %private.contiguous.address409, align 4
  %687 = select <8 x i1> %71, <8 x float> %private.contiguous.load410, <8 x float> zeroinitializer
  %688 = fmul <8 x float> %672, %687
  %.state411 = load <8 x float>, ptr %.slot68, align 32
  %689 = fadd <8 x float> %.state411, %688
  %.state412 = load i64, ptr %.slot67, align 4
  %690 = add i64 %.state412, 1
  store i64 %690, ptr %.slot67, align 4
  %691 = load <8 x float>, ptr %.slot68, align 32
  %692 = select <8 x i1> %71, <8 x float> %689, <8 x float> %691
  store <8 x float> %692, ptr %.slot68, align 32
  br label %direct.schedule.49

direct.schedule.51:                               ; preds = %direct.false398
  store i64 0, ptr %.slot69, align 4
  %693 = load <8 x float>, ptr %.slot70, align 32
  %694 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %693
  store <8 x float> %694, ptr %.slot70, align 32
  br label %direct.schedule.52

direct.schedule.52:                               ; preds = %direct.schedule.53, %direct.schedule.51
  %.state413 = load i64, ptr %.slot69, align 4
  %695 = icmp slt i64 %.state413, 80
  br i1 %695, label %direct.true414, label %direct.false415

direct.schedule.53:                               ; preds = %direct.true414
  %.state416 = load i64, ptr %.slot69, align 4
  %696 = add i64 0, %.state416
  %tile_snapshot.spill.load417 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %697 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load417, 0
  %698 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load417, 1
  %.splatinsert418 = insertelement <8 x i64> poison, i64 %696, i64 0
  %.splat419 = shufflevector <8 x i64> %.splatinsert418, <8 x i64> poison, <8 x i32> zeroinitializer
  %699 = mul <8 x i64> %.splat419, splat (i64 32)
  %700 = add <8 x i64> %698, %699
  %701 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %697, 0
  %702 = insertvalue { <8 x ptr>, <8 x i64> } %701, <8 x i64> %700, 1
  %703 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %704 = extractvalue { <8 x ptr>, <8 x i64> } %702, 1
  %705 = extractelement <8 x ptr> %703, i32 0
  %706 = extractelement <8 x i64> %704, i32 0
  %707 = sub i64 %706, 0
  %708 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %709 = select i1 %708, i64 %707, i64 0
  %private.contiguous.address420 = getelementptr i8, ptr %705, i64 %709
  %private.contiguous.load421 = load <8 x float>, ptr %private.contiguous.address420, align 4
  %710 = select <8 x i1> %71, <8 x float> %private.contiguous.load421, <8 x float> zeroinitializer
  %.state422 = load i64, ptr %.slot69, align 4
  %711 = add i64 880, %.state422
  %tile_snapshot.spill.load423 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %712 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load423, 0
  %713 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load423, 1
  %.splatinsert424 = insertelement <8 x i64> poison, i64 %711, i64 0
  %.splat425 = shufflevector <8 x i64> %.splatinsert424, <8 x i64> poison, <8 x i32> zeroinitializer
  %714 = mul <8 x i64> %.splat425, splat (i64 32)
  %715 = add <8 x i64> %713, %714
  %716 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %712, 0
  %717 = insertvalue { <8 x ptr>, <8 x i64> } %716, <8 x i64> %715, 1
  %718 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %719 = extractvalue { <8 x ptr>, <8 x i64> } %717, 1
  %720 = extractelement <8 x ptr> %718, i32 0
  %721 = extractelement <8 x i64> %719, i32 0
  %722 = sub i64 %721, 0
  %723 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %724 = select i1 %723, i64 %722, i64 0
  %private.contiguous.address426 = getelementptr i8, ptr %720, i64 %724
  %private.contiguous.load427 = load <8 x float>, ptr %private.contiguous.address426, align 4
  %725 = select <8 x i1> %71, <8 x float> %private.contiguous.load427, <8 x float> zeroinitializer
  %726 = fmul <8 x float> %710, %725
  %.state428 = load <8 x float>, ptr %.slot70, align 32
  %727 = fadd <8 x float> %.state428, %726
  %.state429 = load i64, ptr %.slot69, align 4
  %728 = add i64 %.state429, 1
  store i64 %728, ptr %.slot69, align 4
  %729 = load <8 x float>, ptr %.slot70, align 32
  %730 = select <8 x i1> %71, <8 x float> %727, <8 x float> %729
  store <8 x float> %730, ptr %.slot70, align 32
  br label %direct.schedule.52

direct.schedule.54:                               ; preds = %direct.false415
  store i64 0, ptr %.slot71, align 4
  %731 = load <8 x float>, ptr %.slot72, align 32
  %732 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %731
  store <8 x float> %732, ptr %.slot72, align 32
  br label %direct.schedule.55

direct.schedule.55:                               ; preds = %direct.schedule.56, %direct.schedule.54
  %.state430 = load i64, ptr %.slot71, align 4
  %733 = icmp slt i64 %.state430, 80
  br i1 %733, label %direct.true431, label %direct.false432

direct.schedule.56:                               ; preds = %direct.true431
  %.state433 = load i64, ptr %.slot71, align 4
  %734 = add i64 0, %.state433
  %tile_snapshot.spill.load434 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %735 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load434, 0
  %736 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load434, 1
  %.splatinsert435 = insertelement <8 x i64> poison, i64 %734, i64 0
  %.splat436 = shufflevector <8 x i64> %.splatinsert435, <8 x i64> poison, <8 x i32> zeroinitializer
  %737 = mul <8 x i64> %.splat436, splat (i64 32)
  %738 = add <8 x i64> %736, %737
  %739 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %735, 0
  %740 = insertvalue { <8 x ptr>, <8 x i64> } %739, <8 x i64> %738, 1
  %741 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %742 = extractvalue { <8 x ptr>, <8 x i64> } %740, 1
  %743 = extractelement <8 x ptr> %741, i32 0
  %744 = extractelement <8 x i64> %742, i32 0
  %745 = sub i64 %744, 0
  %746 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %747 = select i1 %746, i64 %745, i64 0
  %private.contiguous.address437 = getelementptr i8, ptr %743, i64 %747
  %private.contiguous.load438 = load <8 x float>, ptr %private.contiguous.address437, align 4
  %748 = select <8 x i1> %71, <8 x float> %private.contiguous.load438, <8 x float> zeroinitializer
  %.state439 = load i64, ptr %.slot71, align 4
  %749 = add i64 960, %.state439
  %tile_snapshot.spill.load440 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %750 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load440, 0
  %751 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load440, 1
  %.splatinsert441 = insertelement <8 x i64> poison, i64 %749, i64 0
  %.splat442 = shufflevector <8 x i64> %.splatinsert441, <8 x i64> poison, <8 x i32> zeroinitializer
  %752 = mul <8 x i64> %.splat442, splat (i64 32)
  %753 = add <8 x i64> %751, %752
  %754 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %750, 0
  %755 = insertvalue { <8 x ptr>, <8 x i64> } %754, <8 x i64> %753, 1
  %756 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %757 = extractvalue { <8 x ptr>, <8 x i64> } %755, 1
  %758 = extractelement <8 x ptr> %756, i32 0
  %759 = extractelement <8 x i64> %757, i32 0
  %760 = sub i64 %759, 0
  %761 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %762 = select i1 %761, i64 %760, i64 0
  %private.contiguous.address443 = getelementptr i8, ptr %758, i64 %762
  %private.contiguous.load444 = load <8 x float>, ptr %private.contiguous.address443, align 4
  %763 = select <8 x i1> %71, <8 x float> %private.contiguous.load444, <8 x float> zeroinitializer
  %764 = fmul <8 x float> %748, %763
  %.state445 = load <8 x float>, ptr %.slot72, align 32
  %765 = fadd <8 x float> %.state445, %764
  %.state446 = load i64, ptr %.slot71, align 4
  %766 = add i64 %.state446, 1
  store i64 %766, ptr %.slot71, align 4
  %767 = load <8 x float>, ptr %.slot72, align 32
  %768 = select <8 x i1> %71, <8 x float> %765, <8 x float> %767
  store <8 x float> %768, ptr %.slot72, align 32
  br label %direct.schedule.55

direct.schedule.57:                               ; preds = %direct.false432
  store i64 0, ptr %.slot73, align 4
  %769 = load <8 x float>, ptr %.slot74, align 32
  %770 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %769
  store <8 x float> %770, ptr %.slot74, align 32
  br label %direct.schedule.58

direct.schedule.58:                               ; preds = %direct.schedule.59, %direct.schedule.57
  %.state447 = load i64, ptr %.slot73, align 4
  %771 = icmp slt i64 %.state447, 80
  br i1 %771, label %direct.true448, label %direct.false449

direct.schedule.59:                               ; preds = %direct.true448
  %.state450 = load i64, ptr %.slot73, align 4
  %772 = add i64 0, %.state450
  %tile_snapshot.spill.load451 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %773 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load451, 0
  %774 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load451, 1
  %.splatinsert452 = insertelement <8 x i64> poison, i64 %772, i64 0
  %.splat453 = shufflevector <8 x i64> %.splatinsert452, <8 x i64> poison, <8 x i32> zeroinitializer
  %775 = mul <8 x i64> %.splat453, splat (i64 32)
  %776 = add <8 x i64> %774, %775
  %777 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %773, 0
  %778 = insertvalue { <8 x ptr>, <8 x i64> } %777, <8 x i64> %776, 1
  %779 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %780 = extractvalue { <8 x ptr>, <8 x i64> } %778, 1
  %781 = extractelement <8 x ptr> %779, i32 0
  %782 = extractelement <8 x i64> %780, i32 0
  %783 = sub i64 %782, 0
  %784 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %785 = select i1 %784, i64 %783, i64 0
  %private.contiguous.address454 = getelementptr i8, ptr %781, i64 %785
  %private.contiguous.load455 = load <8 x float>, ptr %private.contiguous.address454, align 4
  %786 = select <8 x i1> %71, <8 x float> %private.contiguous.load455, <8 x float> zeroinitializer
  %.state456 = load i64, ptr %.slot73, align 4
  %787 = add i64 1040, %.state456
  %tile_snapshot.spill.load457 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %788 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load457, 0
  %789 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load457, 1
  %.splatinsert458 = insertelement <8 x i64> poison, i64 %787, i64 0
  %.splat459 = shufflevector <8 x i64> %.splatinsert458, <8 x i64> poison, <8 x i32> zeroinitializer
  %790 = mul <8 x i64> %.splat459, splat (i64 32)
  %791 = add <8 x i64> %789, %790
  %792 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %788, 0
  %793 = insertvalue { <8 x ptr>, <8 x i64> } %792, <8 x i64> %791, 1
  %794 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %795 = extractvalue { <8 x ptr>, <8 x i64> } %793, 1
  %796 = extractelement <8 x ptr> %794, i32 0
  %797 = extractelement <8 x i64> %795, i32 0
  %798 = sub i64 %797, 0
  %799 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %800 = select i1 %799, i64 %798, i64 0
  %private.contiguous.address460 = getelementptr i8, ptr %796, i64 %800
  %private.contiguous.load461 = load <8 x float>, ptr %private.contiguous.address460, align 4
  %801 = select <8 x i1> %71, <8 x float> %private.contiguous.load461, <8 x float> zeroinitializer
  %802 = fmul <8 x float> %786, %801
  %.state462 = load <8 x float>, ptr %.slot74, align 32
  %803 = fadd <8 x float> %.state462, %802
  %.state463 = load i64, ptr %.slot73, align 4
  %804 = add i64 %.state463, 1
  store i64 %804, ptr %.slot73, align 4
  %805 = load <8 x float>, ptr %.slot74, align 32
  %806 = select <8 x i1> %71, <8 x float> %803, <8 x float> %805
  store <8 x float> %806, ptr %.slot74, align 32
  br label %direct.schedule.58

direct.schedule.60:                               ; preds = %direct.false449
  store i64 0, ptr %.slot75, align 4
  %807 = load <8 x float>, ptr %.slot76, align 32
  %808 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %807
  store <8 x float> %808, ptr %.slot76, align 32
  br label %direct.schedule.61

direct.schedule.61:                               ; preds = %direct.schedule.62, %direct.schedule.60
  %.state464 = load i64, ptr %.slot75, align 4
  %809 = icmp slt i64 %.state464, 80
  br i1 %809, label %direct.true465, label %direct.false466

direct.schedule.62:                               ; preds = %direct.true465
  %.state467 = load i64, ptr %.slot75, align 4
  %810 = add i64 0, %.state467
  %tile_snapshot.spill.load468 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %811 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load468, 0
  %812 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load468, 1
  %.splatinsert469 = insertelement <8 x i64> poison, i64 %810, i64 0
  %.splat470 = shufflevector <8 x i64> %.splatinsert469, <8 x i64> poison, <8 x i32> zeroinitializer
  %813 = mul <8 x i64> %.splat470, splat (i64 32)
  %814 = add <8 x i64> %812, %813
  %815 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %811, 0
  %816 = insertvalue { <8 x ptr>, <8 x i64> } %815, <8 x i64> %814, 1
  %817 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %818 = extractvalue { <8 x ptr>, <8 x i64> } %816, 1
  %819 = extractelement <8 x ptr> %817, i32 0
  %820 = extractelement <8 x i64> %818, i32 0
  %821 = sub i64 %820, 0
  %822 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %823 = select i1 %822, i64 %821, i64 0
  %private.contiguous.address471 = getelementptr i8, ptr %819, i64 %823
  %private.contiguous.load472 = load <8 x float>, ptr %private.contiguous.address471, align 4
  %824 = select <8 x i1> %71, <8 x float> %private.contiguous.load472, <8 x float> zeroinitializer
  %.state473 = load i64, ptr %.slot75, align 4
  %825 = add i64 1120, %.state473
  %tile_snapshot.spill.load474 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %826 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load474, 0
  %827 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load474, 1
  %.splatinsert475 = insertelement <8 x i64> poison, i64 %825, i64 0
  %.splat476 = shufflevector <8 x i64> %.splatinsert475, <8 x i64> poison, <8 x i32> zeroinitializer
  %828 = mul <8 x i64> %.splat476, splat (i64 32)
  %829 = add <8 x i64> %827, %828
  %830 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %826, 0
  %831 = insertvalue { <8 x ptr>, <8 x i64> } %830, <8 x i64> %829, 1
  %832 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %833 = extractvalue { <8 x ptr>, <8 x i64> } %831, 1
  %834 = extractelement <8 x ptr> %832, i32 0
  %835 = extractelement <8 x i64> %833, i32 0
  %836 = sub i64 %835, 0
  %837 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %838 = select i1 %837, i64 %836, i64 0
  %private.contiguous.address477 = getelementptr i8, ptr %834, i64 %838
  %private.contiguous.load478 = load <8 x float>, ptr %private.contiguous.address477, align 4
  %839 = select <8 x i1> %71, <8 x float> %private.contiguous.load478, <8 x float> zeroinitializer
  %840 = fmul <8 x float> %824, %839
  %.state479 = load <8 x float>, ptr %.slot76, align 32
  %841 = fadd <8 x float> %.state479, %840
  %.state480 = load i64, ptr %.slot75, align 4
  %842 = add i64 %.state480, 1
  store i64 %842, ptr %.slot75, align 4
  %843 = load <8 x float>, ptr %.slot76, align 32
  %844 = select <8 x i1> %71, <8 x float> %841, <8 x float> %843
  store <8 x float> %844, ptr %.slot76, align 32
  br label %direct.schedule.61

direct.schedule.63:                               ; preds = %direct.false466
  store i64 0, ptr %.slot77, align 4
  %845 = load <8 x float>, ptr %.slot78, align 32
  %846 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %845
  store <8 x float> %846, ptr %.slot78, align 32
  br label %direct.schedule.64

direct.schedule.64:                               ; preds = %direct.schedule.65, %direct.schedule.63
  %.state481 = load i64, ptr %.slot77, align 4
  %847 = icmp slt i64 %.state481, 80
  br i1 %847, label %direct.true482, label %direct.false483

direct.schedule.65:                               ; preds = %direct.true482
  %.state484 = load i64, ptr %.slot77, align 4
  %848 = add i64 0, %.state484
  %tile_snapshot.spill.load485 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %849 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load485, 0
  %850 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load485, 1
  %.splatinsert486 = insertelement <8 x i64> poison, i64 %848, i64 0
  %.splat487 = shufflevector <8 x i64> %.splatinsert486, <8 x i64> poison, <8 x i32> zeroinitializer
  %851 = mul <8 x i64> %.splat487, splat (i64 32)
  %852 = add <8 x i64> %850, %851
  %853 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %849, 0
  %854 = insertvalue { <8 x ptr>, <8 x i64> } %853, <8 x i64> %852, 1
  %855 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %856 = extractvalue { <8 x ptr>, <8 x i64> } %854, 1
  %857 = extractelement <8 x ptr> %855, i32 0
  %858 = extractelement <8 x i64> %856, i32 0
  %859 = sub i64 %858, 0
  %860 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %861 = select i1 %860, i64 %859, i64 0
  %private.contiguous.address488 = getelementptr i8, ptr %857, i64 %861
  %private.contiguous.load489 = load <8 x float>, ptr %private.contiguous.address488, align 4
  %862 = select <8 x i1> %71, <8 x float> %private.contiguous.load489, <8 x float> zeroinitializer
  %.state490 = load i64, ptr %.slot77, align 4
  %863 = add i64 1200, %.state490
  %tile_snapshot.spill.load491 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %864 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load491, 0
  %865 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load491, 1
  %.splatinsert492 = insertelement <8 x i64> poison, i64 %863, i64 0
  %.splat493 = shufflevector <8 x i64> %.splatinsert492, <8 x i64> poison, <8 x i32> zeroinitializer
  %866 = mul <8 x i64> %.splat493, splat (i64 32)
  %867 = add <8 x i64> %865, %866
  %868 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %864, 0
  %869 = insertvalue { <8 x ptr>, <8 x i64> } %868, <8 x i64> %867, 1
  %870 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %871 = extractvalue { <8 x ptr>, <8 x i64> } %869, 1
  %872 = extractelement <8 x ptr> %870, i32 0
  %873 = extractelement <8 x i64> %871, i32 0
  %874 = sub i64 %873, 0
  %875 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %876 = select i1 %875, i64 %874, i64 0
  %private.contiguous.address494 = getelementptr i8, ptr %872, i64 %876
  %private.contiguous.load495 = load <8 x float>, ptr %private.contiguous.address494, align 4
  %877 = select <8 x i1> %71, <8 x float> %private.contiguous.load495, <8 x float> zeroinitializer
  %878 = fmul <8 x float> %862, %877
  %.state496 = load <8 x float>, ptr %.slot78, align 32
  %879 = fadd <8 x float> %.state496, %878
  %.state497 = load i64, ptr %.slot77, align 4
  %880 = add i64 %.state497, 1
  store i64 %880, ptr %.slot77, align 4
  %881 = load <8 x float>, ptr %.slot78, align 32
  %882 = select <8 x i1> %71, <8 x float> %879, <8 x float> %881
  store <8 x float> %882, ptr %.slot78, align 32
  br label %direct.schedule.64

direct.schedule.66:                               ; preds = %direct.false483
  %.state498 = load <8 x float>, ptr %.slot48, align 32
  %883 = fmul <8 x float> %.state498, splat (float 0x3FBC9F25C0000000)
  %.state499 = load <8 x float>, ptr %.slot50, align 32
  %884 = fmul <8 x float> %.state499, splat (float 0x3FBC9F25C0000000)
  %.state500 = load <8 x float>, ptr %.slot52, align 32
  %885 = fmul <8 x float> %.state500, splat (float 0x3FBC9F25C0000000)
  %.state501 = load <8 x float>, ptr %.slot54, align 32
  %886 = fmul <8 x float> %.state501, splat (float 0x3FBC9F25C0000000)
  %.state502 = load <8 x float>, ptr %.slot56, align 32
  %887 = fmul <8 x float> %.state502, splat (float 0x3FBC9F25C0000000)
  %.state503 = load <8 x float>, ptr %.slot58, align 32
  %888 = fmul <8 x float> %.state503, splat (float 0x3FBC9F25C0000000)
  %.state504 = load <8 x float>, ptr %.slot60, align 32
  %889 = fmul <8 x float> %.state504, splat (float 0x3FBC9F25C0000000)
  %.state505 = load <8 x float>, ptr %.slot62, align 32
  %890 = fmul <8 x float> %.state505, splat (float 0x3FBC9F25C0000000)
  %.state506 = load <8 x float>, ptr %.slot64, align 32
  %891 = fmul <8 x float> %.state506, splat (float 0x3FBC9F25C0000000)
  %.state507 = load <8 x float>, ptr %.slot66, align 32
  %892 = fmul <8 x float> %.state507, splat (float 0x3FBC9F25C0000000)
  %.state508 = load <8 x float>, ptr %.slot68, align 32
  %893 = fmul <8 x float> %.state508, splat (float 0x3FBC9F25C0000000)
  %.state509 = load <8 x float>, ptr %.slot70, align 32
  %894 = fmul <8 x float> %.state509, splat (float 0x3FBC9F25C0000000)
  %.state510 = load <8 x float>, ptr %.slot72, align 32
  %895 = fmul <8 x float> %.state510, splat (float 0x3FBC9F25C0000000)
  %.state511 = load <8 x float>, ptr %.slot74, align 32
  %896 = fmul <8 x float> %.state511, splat (float 0x3FBC9F25C0000000)
  %.state512 = load <8 x float>, ptr %.slot76, align 32
  %897 = fmul <8 x float> %.state512, splat (float 0x3FBC9F25C0000000)
  %.state513 = load <8 x float>, ptr %.slot78, align 32
  %898 = fmul <8 x float> %.state513, splat (float 0x3FBC9F25C0000000)
  %.spill.load514 = load i64, ptr %.spill38, align 4
  %899 = add i64 0, %.spill.load514
  %.spill.load515 = load i64, ptr %.spill38, align 4
  %900 = add i64 1, %.spill.load515
  %.spill.load516 = load i64, ptr %.spill38, align 4
  %901 = add i64 2, %.spill.load516
  %.spill.load517 = load i64, ptr %.spill38, align 4
  %902 = add i64 3, %.spill.load517
  %.spill.load518 = load i64, ptr %.spill38, align 4
  %903 = add i64 4, %.spill.load518
  %.spill.load519 = load i64, ptr %.spill38, align 4
  %904 = add i64 5, %.spill.load519
  %.spill.load520 = load i64, ptr %.spill38, align 4
  %905 = add i64 6, %.spill.load520
  %.spill.load521 = load i64, ptr %.spill38, align 4
  %906 = add i64 7, %.spill.load521
  %.spill.load522 = load i64, ptr %.spill38, align 4
  %907 = add i64 8, %.spill.load522
  %.spill.load523 = load i64, ptr %.spill38, align 4
  %908 = add i64 9, %.spill.load523
  %.spill.load524 = load i64, ptr %.spill38, align 4
  %909 = add i64 10, %.spill.load524
  %.spill.load525 = load i64, ptr %.spill38, align 4
  %910 = add i64 11, %.spill.load525
  %.spill.load526 = load i64, ptr %.spill38, align 4
  %911 = add i64 12, %.spill.load526
  %.spill.load527 = load i64, ptr %.spill38, align 4
  %912 = add i64 13, %.spill.load527
  %.spill.load528 = load i64, ptr %.spill38, align 4
  %913 = add i64 14, %.spill.load528
  %.spill.load529 = load i64, ptr %.spill38, align 4
  %914 = add i64 15, %.spill.load529
  %915 = icmp slt i64 %899, 2053
  %916 = icmp slt i64 %900, 2053
  %917 = icmp slt i64 %901, 2053
  %918 = icmp slt i64 %902, 2053
  %919 = icmp slt i64 %903, 2053
  %920 = icmp slt i64 %904, 2053
  %921 = icmp slt i64 %905, 2053
  %922 = icmp slt i64 %906, 2053
  %923 = icmp slt i64 %907, 2053
  %924 = icmp slt i64 %908, 2053
  %925 = icmp slt i64 %909, 2053
  %926 = icmp slt i64 %910, 2053
  %927 = icmp slt i64 %911, 2053
  %928 = icmp slt i64 %912, 2053
  %929 = icmp slt i64 %913, 2053
  %930 = icmp slt i64 %914, 2053
  %.spill.load530 = load i64, ptr %.spill30, align 4
  %931 = add i64 0, %.spill.load530
  store i64 %931, ptr %.spill79, align 4
  %932 = add i64 %931, 2053
  %933 = sub i64 %932, 1
  %934 = icmp sle i64 %899, %933
  %935 = icmp sle i64 %900, %933
  %936 = icmp sle i64 %901, %933
  %937 = icmp sle i64 %902, %933
  %938 = icmp sle i64 %903, %933
  %939 = icmp sle i64 %904, %933
  %940 = icmp sle i64 %905, %933
  %941 = icmp sle i64 %906, %933
  %942 = icmp sle i64 %907, %933
  %943 = icmp sle i64 %908, %933
  %944 = icmp sle i64 %909, %933
  %945 = icmp sle i64 %910, %933
  %946 = icmp sle i64 %911, %933
  %947 = icmp sle i64 %912, %933
  %948 = icmp sle i64 %913, %933
  %949 = icmp sle i64 %914, %933
  %950 = and i1 %915, %934
  store i1 %950, ptr %.spill80, align 1
  %951 = and i1 %916, %935
  store i1 %951, ptr %.spill81, align 1
  %952 = and i1 %917, %936
  store i1 %952, ptr %.spill82, align 1
  %953 = and i1 %918, %937
  store i1 %953, ptr %.spill83, align 1
  %954 = and i1 %919, %938
  store i1 %954, ptr %.spill84, align 1
  %955 = and i1 %920, %939
  store i1 %955, ptr %.spill85, align 1
  %956 = and i1 %921, %940
  store i1 %956, ptr %.spill86, align 1
  %957 = and i1 %922, %941
  store i1 %957, ptr %.spill87, align 1
  %958 = and i1 %923, %942
  store i1 %958, ptr %.spill88, align 1
  %959 = and i1 %924, %943
  store i1 %959, ptr %.spill89, align 1
  %960 = and i1 %925, %944
  store i1 %960, ptr %.spill90, align 1
  %961 = and i1 %926, %945
  store i1 %961, ptr %.spill91, align 1
  %962 = and i1 %927, %946
  store i1 %962, ptr %.spill92, align 1
  %963 = and i1 %928, %947
  store i1 %963, ptr %.spill93, align 1
  %964 = and i1 %929, %948
  store i1 %964, ptr %.spill94, align 1
  %965 = and i1 %930, %949
  store i1 %965, ptr %.spill95, align 1
  %.splatinsert531 = insertelement <8 x i1> poison, i1 %950, i64 0
  %.splat532 = shufflevector <8 x i1> %.splatinsert531, <8 x i1> poison, <8 x i32> zeroinitializer
  %966 = select <8 x i1> %.splat532, <8 x float> %883, <8 x float> splat (float 0xC6293E5940000000)
  %967 = load <8 x float>, ptr %.spill96, align 32
  %968 = select <8 x i1> %71, <8 x float> %966, <8 x float> %967
  store <8 x float> %968, ptr %.spill96, align 32
  %.splatinsert533 = insertelement <8 x i1> poison, i1 %951, i64 0
  %.splat534 = shufflevector <8 x i1> %.splatinsert533, <8 x i1> poison, <8 x i32> zeroinitializer
  %969 = select <8 x i1> %.splat534, <8 x float> %884, <8 x float> splat (float 0xC6293E5940000000)
  %970 = load <8 x float>, ptr %.spill97, align 32
  %971 = select <8 x i1> %71, <8 x float> %969, <8 x float> %970
  store <8 x float> %971, ptr %.spill97, align 32
  %.splatinsert535 = insertelement <8 x i1> poison, i1 %952, i64 0
  %.splat536 = shufflevector <8 x i1> %.splatinsert535, <8 x i1> poison, <8 x i32> zeroinitializer
  %972 = select <8 x i1> %.splat536, <8 x float> %885, <8 x float> splat (float 0xC6293E5940000000)
  %973 = load <8 x float>, ptr %.spill98, align 32
  %974 = select <8 x i1> %71, <8 x float> %972, <8 x float> %973
  store <8 x float> %974, ptr %.spill98, align 32
  %.splatinsert537 = insertelement <8 x i1> poison, i1 %953, i64 0
  %.splat538 = shufflevector <8 x i1> %.splatinsert537, <8 x i1> poison, <8 x i32> zeroinitializer
  %975 = select <8 x i1> %.splat538, <8 x float> %886, <8 x float> splat (float 0xC6293E5940000000)
  %976 = load <8 x float>, ptr %.spill99, align 32
  %977 = select <8 x i1> %71, <8 x float> %975, <8 x float> %976
  store <8 x float> %977, ptr %.spill99, align 32
  %.splatinsert539 = insertelement <8 x i1> poison, i1 %954, i64 0
  %.splat540 = shufflevector <8 x i1> %.splatinsert539, <8 x i1> poison, <8 x i32> zeroinitializer
  %978 = select <8 x i1> %.splat540, <8 x float> %887, <8 x float> splat (float 0xC6293E5940000000)
  %979 = load <8 x float>, ptr %.spill100, align 32
  %980 = select <8 x i1> %71, <8 x float> %978, <8 x float> %979
  store <8 x float> %980, ptr %.spill100, align 32
  %.splatinsert541 = insertelement <8 x i1> poison, i1 %955, i64 0
  %.splat542 = shufflevector <8 x i1> %.splatinsert541, <8 x i1> poison, <8 x i32> zeroinitializer
  %981 = select <8 x i1> %.splat542, <8 x float> %888, <8 x float> splat (float 0xC6293E5940000000)
  %982 = load <8 x float>, ptr %.spill101, align 32
  %983 = select <8 x i1> %71, <8 x float> %981, <8 x float> %982
  store <8 x float> %983, ptr %.spill101, align 32
  %.splatinsert543 = insertelement <8 x i1> poison, i1 %956, i64 0
  %.splat544 = shufflevector <8 x i1> %.splatinsert543, <8 x i1> poison, <8 x i32> zeroinitializer
  %984 = select <8 x i1> %.splat544, <8 x float> %889, <8 x float> splat (float 0xC6293E5940000000)
  %985 = load <8 x float>, ptr %.spill102, align 32
  %986 = select <8 x i1> %71, <8 x float> %984, <8 x float> %985
  store <8 x float> %986, ptr %.spill102, align 32
  %.splatinsert545 = insertelement <8 x i1> poison, i1 %957, i64 0
  %.splat546 = shufflevector <8 x i1> %.splatinsert545, <8 x i1> poison, <8 x i32> zeroinitializer
  %987 = select <8 x i1> %.splat546, <8 x float> %890, <8 x float> splat (float 0xC6293E5940000000)
  %988 = load <8 x float>, ptr %.spill103, align 32
  %989 = select <8 x i1> %71, <8 x float> %987, <8 x float> %988
  store <8 x float> %989, ptr %.spill103, align 32
  %.splatinsert547 = insertelement <8 x i1> poison, i1 %958, i64 0
  %.splat548 = shufflevector <8 x i1> %.splatinsert547, <8 x i1> poison, <8 x i32> zeroinitializer
  %990 = select <8 x i1> %.splat548, <8 x float> %891, <8 x float> splat (float 0xC6293E5940000000)
  %991 = load <8 x float>, ptr %.spill104, align 32
  %992 = select <8 x i1> %71, <8 x float> %990, <8 x float> %991
  store <8 x float> %992, ptr %.spill104, align 32
  %.splatinsert549 = insertelement <8 x i1> poison, i1 %959, i64 0
  %.splat550 = shufflevector <8 x i1> %.splatinsert549, <8 x i1> poison, <8 x i32> zeroinitializer
  %993 = select <8 x i1> %.splat550, <8 x float> %892, <8 x float> splat (float 0xC6293E5940000000)
  %994 = load <8 x float>, ptr %.spill105, align 32
  %995 = select <8 x i1> %71, <8 x float> %993, <8 x float> %994
  store <8 x float> %995, ptr %.spill105, align 32
  %.splatinsert551 = insertelement <8 x i1> poison, i1 %960, i64 0
  %.splat552 = shufflevector <8 x i1> %.splatinsert551, <8 x i1> poison, <8 x i32> zeroinitializer
  %996 = select <8 x i1> %.splat552, <8 x float> %893, <8 x float> splat (float 0xC6293E5940000000)
  %997 = load <8 x float>, ptr %.spill106, align 32
  %998 = select <8 x i1> %71, <8 x float> %996, <8 x float> %997
  store <8 x float> %998, ptr %.spill106, align 32
  %.splatinsert553 = insertelement <8 x i1> poison, i1 %961, i64 0
  %.splat554 = shufflevector <8 x i1> %.splatinsert553, <8 x i1> poison, <8 x i32> zeroinitializer
  %999 = select <8 x i1> %.splat554, <8 x float> %894, <8 x float> splat (float 0xC6293E5940000000)
  %1000 = load <8 x float>, ptr %.spill107, align 32
  %1001 = select <8 x i1> %71, <8 x float> %999, <8 x float> %1000
  store <8 x float> %1001, ptr %.spill107, align 32
  %.splatinsert555 = insertelement <8 x i1> poison, i1 %962, i64 0
  %.splat556 = shufflevector <8 x i1> %.splatinsert555, <8 x i1> poison, <8 x i32> zeroinitializer
  %1002 = select <8 x i1> %.splat556, <8 x float> %895, <8 x float> splat (float 0xC6293E5940000000)
  %1003 = load <8 x float>, ptr %.spill108, align 32
  %1004 = select <8 x i1> %71, <8 x float> %1002, <8 x float> %1003
  store <8 x float> %1004, ptr %.spill108, align 32
  %.splatinsert557 = insertelement <8 x i1> poison, i1 %963, i64 0
  %.splat558 = shufflevector <8 x i1> %.splatinsert557, <8 x i1> poison, <8 x i32> zeroinitializer
  %1005 = select <8 x i1> %.splat558, <8 x float> %896, <8 x float> splat (float 0xC6293E5940000000)
  %1006 = load <8 x float>, ptr %.spill109, align 32
  %1007 = select <8 x i1> %71, <8 x float> %1005, <8 x float> %1006
  store <8 x float> %1007, ptr %.spill109, align 32
  %.splatinsert559 = insertelement <8 x i1> poison, i1 %964, i64 0
  %.splat560 = shufflevector <8 x i1> %.splatinsert559, <8 x i1> poison, <8 x i32> zeroinitializer
  %1008 = select <8 x i1> %.splat560, <8 x float> %897, <8 x float> splat (float 0xC6293E5940000000)
  %1009 = load <8 x float>, ptr %.spill110, align 32
  %1010 = select <8 x i1> %71, <8 x float> %1008, <8 x float> %1009
  store <8 x float> %1010, ptr %.spill110, align 32
  %.splatinsert561 = insertelement <8 x i1> poison, i1 %965, i64 0
  %.splat562 = shufflevector <8 x i1> %.splatinsert561, <8 x i1> poison, <8 x i32> zeroinitializer
  %1011 = select <8 x i1> %.splat562, <8 x float> %898, <8 x float> splat (float 0xC6293E5940000000)
  %1012 = load <8 x float>, ptr %.spill111, align 32
  %1013 = select <8 x i1> %71, <8 x float> %1011, <8 x float> %1012
  store <8 x float> %1013, ptr %.spill111, align 32
  %1014 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill112, align 64
  %1015 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1016 = extractvalue { <8 x ptr>, <8 x i64> } %1014, 0
  %1017 = select <8 x i1> %71, <8 x ptr> %1015, <8 x ptr> %1016
  %1018 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1019 = extractvalue { <8 x ptr>, <8 x i64> } %1014, 1
  %1020 = select <8 x i1> %71, <8 x i64> %1018, <8 x i64> %1019
  %1021 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1017, 0
  %1022 = insertvalue { <8 x ptr>, <8 x i64> } %1021, <8 x i64> %1020, 1
  store { <8 x ptr>, <8 x i64> } %1022, ptr %tile_snapshot.spill112, align 64
  %1023 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1024 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1025 = add <8 x i64> %1024, zeroinitializer
  %1026 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1023, 0
  %1027 = insertvalue { <8 x ptr>, <8 x i64> } %1026, <8 x i64> %1025, 1
  %1028 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1029 = extractvalue { <8 x ptr>, <8 x i64> } %1027, 1
  %1030 = extractelement <8 x ptr> %1028, i32 0
  %1031 = extractelement <8 x i64> %1029, i32 0
  %1032 = sub i64 %1031, 0
  %1033 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1034 = select i1 %1033, i64 %1032, i64 0
  %private.contiguous.address563 = getelementptr i8, ptr %1030, i64 %1034
  %private.contiguous.preserve564 = load <8 x float>, ptr %private.contiguous.address563, align 4
  %1035 = select <8 x i1> %71, <8 x float> %966, <8 x float> %private.contiguous.preserve564
  store <8 x float> %1035, ptr %private.contiguous.address563, align 4
  %1036 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1037 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1038 = add <8 x i64> %1037, splat (i64 32)
  %1039 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1036, 0
  %1040 = insertvalue { <8 x ptr>, <8 x i64> } %1039, <8 x i64> %1038, 1
  %1041 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1042 = extractvalue { <8 x ptr>, <8 x i64> } %1040, 1
  %1043 = extractelement <8 x ptr> %1041, i32 0
  %1044 = extractelement <8 x i64> %1042, i32 0
  %1045 = sub i64 %1044, 0
  %1046 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1047 = select i1 %1046, i64 %1045, i64 0
  %private.contiguous.address565 = getelementptr i8, ptr %1043, i64 %1047
  %private.contiguous.preserve566 = load <8 x float>, ptr %private.contiguous.address565, align 4
  %1048 = select <8 x i1> %71, <8 x float> %969, <8 x float> %private.contiguous.preserve566
  store <8 x float> %1048, ptr %private.contiguous.address565, align 4
  %1049 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1050 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1051 = add <8 x i64> %1050, splat (i64 64)
  %1052 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1049, 0
  %1053 = insertvalue { <8 x ptr>, <8 x i64> } %1052, <8 x i64> %1051, 1
  %1054 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1055 = extractvalue { <8 x ptr>, <8 x i64> } %1053, 1
  %1056 = extractelement <8 x ptr> %1054, i32 0
  %1057 = extractelement <8 x i64> %1055, i32 0
  %1058 = sub i64 %1057, 0
  %1059 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1060 = select i1 %1059, i64 %1058, i64 0
  %private.contiguous.address567 = getelementptr i8, ptr %1056, i64 %1060
  %private.contiguous.preserve568 = load <8 x float>, ptr %private.contiguous.address567, align 4
  %1061 = select <8 x i1> %71, <8 x float> %972, <8 x float> %private.contiguous.preserve568
  store <8 x float> %1061, ptr %private.contiguous.address567, align 4
  %1062 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1063 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1064 = add <8 x i64> %1063, splat (i64 96)
  %1065 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1062, 0
  %1066 = insertvalue { <8 x ptr>, <8 x i64> } %1065, <8 x i64> %1064, 1
  %1067 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1068 = extractvalue { <8 x ptr>, <8 x i64> } %1066, 1
  %1069 = extractelement <8 x ptr> %1067, i32 0
  %1070 = extractelement <8 x i64> %1068, i32 0
  %1071 = sub i64 %1070, 0
  %1072 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1073 = select i1 %1072, i64 %1071, i64 0
  %private.contiguous.address569 = getelementptr i8, ptr %1069, i64 %1073
  %private.contiguous.preserve570 = load <8 x float>, ptr %private.contiguous.address569, align 4
  %1074 = select <8 x i1> %71, <8 x float> %975, <8 x float> %private.contiguous.preserve570
  store <8 x float> %1074, ptr %private.contiguous.address569, align 4
  %1075 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1076 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1077 = add <8 x i64> %1076, splat (i64 128)
  %1078 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1075, 0
  %1079 = insertvalue { <8 x ptr>, <8 x i64> } %1078, <8 x i64> %1077, 1
  %1080 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1081 = extractvalue { <8 x ptr>, <8 x i64> } %1079, 1
  %1082 = extractelement <8 x ptr> %1080, i32 0
  %1083 = extractelement <8 x i64> %1081, i32 0
  %1084 = sub i64 %1083, 0
  %1085 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1086 = select i1 %1085, i64 %1084, i64 0
  %private.contiguous.address571 = getelementptr i8, ptr %1082, i64 %1086
  %private.contiguous.preserve572 = load <8 x float>, ptr %private.contiguous.address571, align 4
  %1087 = select <8 x i1> %71, <8 x float> %978, <8 x float> %private.contiguous.preserve572
  store <8 x float> %1087, ptr %private.contiguous.address571, align 4
  %1088 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1089 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1090 = add <8 x i64> %1089, splat (i64 160)
  %1091 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1088, 0
  %1092 = insertvalue { <8 x ptr>, <8 x i64> } %1091, <8 x i64> %1090, 1
  %1093 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1094 = extractvalue { <8 x ptr>, <8 x i64> } %1092, 1
  %1095 = extractelement <8 x ptr> %1093, i32 0
  %1096 = extractelement <8 x i64> %1094, i32 0
  %1097 = sub i64 %1096, 0
  %1098 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1099 = select i1 %1098, i64 %1097, i64 0
  %private.contiguous.address573 = getelementptr i8, ptr %1095, i64 %1099
  %private.contiguous.preserve574 = load <8 x float>, ptr %private.contiguous.address573, align 4
  %1100 = select <8 x i1> %71, <8 x float> %981, <8 x float> %private.contiguous.preserve574
  store <8 x float> %1100, ptr %private.contiguous.address573, align 4
  %1101 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1102 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1103 = add <8 x i64> %1102, splat (i64 192)
  %1104 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1101, 0
  %1105 = insertvalue { <8 x ptr>, <8 x i64> } %1104, <8 x i64> %1103, 1
  %1106 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1107 = extractvalue { <8 x ptr>, <8 x i64> } %1105, 1
  %1108 = extractelement <8 x ptr> %1106, i32 0
  %1109 = extractelement <8 x i64> %1107, i32 0
  %1110 = sub i64 %1109, 0
  %1111 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1112 = select i1 %1111, i64 %1110, i64 0
  %private.contiguous.address575 = getelementptr i8, ptr %1108, i64 %1112
  %private.contiguous.preserve576 = load <8 x float>, ptr %private.contiguous.address575, align 4
  %1113 = select <8 x i1> %71, <8 x float> %984, <8 x float> %private.contiguous.preserve576
  store <8 x float> %1113, ptr %private.contiguous.address575, align 4
  %1114 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1115 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1116 = add <8 x i64> %1115, splat (i64 224)
  %1117 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1114, 0
  %1118 = insertvalue { <8 x ptr>, <8 x i64> } %1117, <8 x i64> %1116, 1
  %1119 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1120 = extractvalue { <8 x ptr>, <8 x i64> } %1118, 1
  %1121 = extractelement <8 x ptr> %1119, i32 0
  %1122 = extractelement <8 x i64> %1120, i32 0
  %1123 = sub i64 %1122, 0
  %1124 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1125 = select i1 %1124, i64 %1123, i64 0
  %private.contiguous.address577 = getelementptr i8, ptr %1121, i64 %1125
  %private.contiguous.preserve578 = load <8 x float>, ptr %private.contiguous.address577, align 4
  %1126 = select <8 x i1> %71, <8 x float> %987, <8 x float> %private.contiguous.preserve578
  store <8 x float> %1126, ptr %private.contiguous.address577, align 4
  %1127 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1128 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1129 = add <8 x i64> %1128, splat (i64 256)
  %1130 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1127, 0
  %1131 = insertvalue { <8 x ptr>, <8 x i64> } %1130, <8 x i64> %1129, 1
  %1132 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1133 = extractvalue { <8 x ptr>, <8 x i64> } %1131, 1
  %1134 = extractelement <8 x ptr> %1132, i32 0
  %1135 = extractelement <8 x i64> %1133, i32 0
  %1136 = sub i64 %1135, 0
  %1137 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1138 = select i1 %1137, i64 %1136, i64 0
  %private.contiguous.address579 = getelementptr i8, ptr %1134, i64 %1138
  %private.contiguous.preserve580 = load <8 x float>, ptr %private.contiguous.address579, align 4
  %1139 = select <8 x i1> %71, <8 x float> %990, <8 x float> %private.contiguous.preserve580
  store <8 x float> %1139, ptr %private.contiguous.address579, align 4
  %1140 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1141 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1142 = add <8 x i64> %1141, splat (i64 288)
  %1143 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1140, 0
  %1144 = insertvalue { <8 x ptr>, <8 x i64> } %1143, <8 x i64> %1142, 1
  %1145 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1146 = extractvalue { <8 x ptr>, <8 x i64> } %1144, 1
  %1147 = extractelement <8 x ptr> %1145, i32 0
  %1148 = extractelement <8 x i64> %1146, i32 0
  %1149 = sub i64 %1148, 0
  %1150 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1151 = select i1 %1150, i64 %1149, i64 0
  %private.contiguous.address581 = getelementptr i8, ptr %1147, i64 %1151
  %private.contiguous.preserve582 = load <8 x float>, ptr %private.contiguous.address581, align 4
  %1152 = select <8 x i1> %71, <8 x float> %993, <8 x float> %private.contiguous.preserve582
  store <8 x float> %1152, ptr %private.contiguous.address581, align 4
  %1153 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1154 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1155 = add <8 x i64> %1154, splat (i64 320)
  %1156 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1153, 0
  %1157 = insertvalue { <8 x ptr>, <8 x i64> } %1156, <8 x i64> %1155, 1
  %1158 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1159 = extractvalue { <8 x ptr>, <8 x i64> } %1157, 1
  %1160 = extractelement <8 x ptr> %1158, i32 0
  %1161 = extractelement <8 x i64> %1159, i32 0
  %1162 = sub i64 %1161, 0
  %1163 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1164 = select i1 %1163, i64 %1162, i64 0
  %private.contiguous.address583 = getelementptr i8, ptr %1160, i64 %1164
  %private.contiguous.preserve584 = load <8 x float>, ptr %private.contiguous.address583, align 4
  %1165 = select <8 x i1> %71, <8 x float> %996, <8 x float> %private.contiguous.preserve584
  store <8 x float> %1165, ptr %private.contiguous.address583, align 4
  %1166 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1167 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1168 = add <8 x i64> %1167, splat (i64 352)
  %1169 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1166, 0
  %1170 = insertvalue { <8 x ptr>, <8 x i64> } %1169, <8 x i64> %1168, 1
  %1171 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1172 = extractvalue { <8 x ptr>, <8 x i64> } %1170, 1
  %1173 = extractelement <8 x ptr> %1171, i32 0
  %1174 = extractelement <8 x i64> %1172, i32 0
  %1175 = sub i64 %1174, 0
  %1176 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1177 = select i1 %1176, i64 %1175, i64 0
  %private.contiguous.address585 = getelementptr i8, ptr %1173, i64 %1177
  %private.contiguous.preserve586 = load <8 x float>, ptr %private.contiguous.address585, align 4
  %1178 = select <8 x i1> %71, <8 x float> %999, <8 x float> %private.contiguous.preserve586
  store <8 x float> %1178, ptr %private.contiguous.address585, align 4
  %1179 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1180 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1181 = add <8 x i64> %1180, splat (i64 384)
  %1182 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1179, 0
  %1183 = insertvalue { <8 x ptr>, <8 x i64> } %1182, <8 x i64> %1181, 1
  %1184 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1185 = extractvalue { <8 x ptr>, <8 x i64> } %1183, 1
  %1186 = extractelement <8 x ptr> %1184, i32 0
  %1187 = extractelement <8 x i64> %1185, i32 0
  %1188 = sub i64 %1187, 0
  %1189 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1190 = select i1 %1189, i64 %1188, i64 0
  %private.contiguous.address587 = getelementptr i8, ptr %1186, i64 %1190
  %private.contiguous.preserve588 = load <8 x float>, ptr %private.contiguous.address587, align 4
  %1191 = select <8 x i1> %71, <8 x float> %1002, <8 x float> %private.contiguous.preserve588
  store <8 x float> %1191, ptr %private.contiguous.address587, align 4
  %1192 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1193 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1194 = add <8 x i64> %1193, splat (i64 416)
  %1195 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1192, 0
  %1196 = insertvalue { <8 x ptr>, <8 x i64> } %1195, <8 x i64> %1194, 1
  %1197 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1198 = extractvalue { <8 x ptr>, <8 x i64> } %1196, 1
  %1199 = extractelement <8 x ptr> %1197, i32 0
  %1200 = extractelement <8 x i64> %1198, i32 0
  %1201 = sub i64 %1200, 0
  %1202 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1203 = select i1 %1202, i64 %1201, i64 0
  %private.contiguous.address589 = getelementptr i8, ptr %1199, i64 %1203
  %private.contiguous.preserve590 = load <8 x float>, ptr %private.contiguous.address589, align 4
  %1204 = select <8 x i1> %71, <8 x float> %1005, <8 x float> %private.contiguous.preserve590
  store <8 x float> %1204, ptr %private.contiguous.address589, align 4
  %1205 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1206 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1207 = add <8 x i64> %1206, splat (i64 448)
  %1208 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1205, 0
  %1209 = insertvalue { <8 x ptr>, <8 x i64> } %1208, <8 x i64> %1207, 1
  %1210 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1211 = extractvalue { <8 x ptr>, <8 x i64> } %1209, 1
  %1212 = extractelement <8 x ptr> %1210, i32 0
  %1213 = extractelement <8 x i64> %1211, i32 0
  %1214 = sub i64 %1213, 0
  %1215 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1216 = select i1 %1215, i64 %1214, i64 0
  %private.contiguous.address591 = getelementptr i8, ptr %1212, i64 %1216
  %private.contiguous.preserve592 = load <8 x float>, ptr %private.contiguous.address591, align 4
  %1217 = select <8 x i1> %71, <8 x float> %1008, <8 x float> %private.contiguous.preserve592
  store <8 x float> %1217, ptr %private.contiguous.address591, align 4
  %1218 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1219 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1220 = add <8 x i64> %1219, splat (i64 480)
  %1221 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1218, 0
  %1222 = insertvalue { <8 x ptr>, <8 x i64> } %1221, <8 x i64> %1220, 1
  %1223 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1224 = extractvalue { <8 x ptr>, <8 x i64> } %1222, 1
  %1225 = extractelement <8 x ptr> %1223, i32 0
  %1226 = extractelement <8 x i64> %1224, i32 0
  %1227 = sub i64 %1226, 0
  %1228 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1229 = select i1 %1228, i64 %1227, i64 0
  %private.contiguous.address593 = getelementptr i8, ptr %1225, i64 %1229
  %private.contiguous.preserve594 = load <8 x float>, ptr %private.contiguous.address593, align 4
  %1230 = select <8 x i1> %71, <8 x float> %1011, <8 x float> %private.contiguous.preserve594
  store <8 x float> %1230, ptr %private.contiguous.address593, align 4
  store i64 0, ptr %.slot113, align 4
  %1231 = load <8 x float>, ptr %.slot114, align 32
  %1232 = select <8 x i1> %71, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %1231
  store <8 x float> %1232, ptr %.slot114, align 32
  br label %direct.schedule.67

direct.schedule.67:                               ; preds = %direct.schedule.68, %direct.schedule.66
  %.state595 = load i64, ptr %.slot113, align 4
  %1233 = icmp slt i64 %.state595, 16
  br i1 %1233, label %direct.true596, label %direct.false597

direct.schedule.68:                               ; preds = %direct.true596
  %.state598 = load i64, ptr %.slot113, align 4
  %1234 = sdiv i64 %.state598, 1
  %.spill.load599 = load i64, ptr %.spill79, align 4
  %1235 = mul i64 %.spill.load599, 1
  %1236 = add i64 %1235, 0
  %1237 = mul i64 %1236, 1
  %1238 = add i64 %1237, 0
  %1239 = mul i64 %1238, 16
  %1240 = add i64 %1239, %1234
  %tile_snapshot.spill.load600 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill112, align 64
  %1241 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load600, 0
  %1242 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load600, 1
  %.splatinsert601 = insertelement <8 x i64> poison, i64 %1240, i64 0
  %.splat602 = shufflevector <8 x i64> %.splatinsert601, <8 x i64> poison, <8 x i32> zeroinitializer
  %1243 = mul <8 x i64> %.splat602, splat (i64 32)
  %1244 = add <8 x i64> %1242, %1243
  %1245 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1241, 0
  %1246 = insertvalue { <8 x ptr>, <8 x i64> } %1245, <8 x i64> %1244, 1
  %1247 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1248 = extractvalue { <8 x ptr>, <8 x i64> } %1246, 1
  %1249 = extractelement <8 x ptr> %1247, i32 0
  %1250 = extractelement <8 x i64> %1248, i32 0
  %1251 = sub i64 %1250, 0
  %1252 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1253 = select i1 %1252, i64 %1251, i64 0
  %private.contiguous.address603 = getelementptr i8, ptr %1249, i64 %1253
  %private.contiguous.load604 = load <8 x float>, ptr %private.contiguous.address603, align 4
  %1254 = select <8 x i1> %71, <8 x float> %private.contiguous.load604, <8 x float> zeroinitializer
  %.state605 = load <8 x float>, ptr %.slot114, align 32
  %1255 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state605, <8 x float> %1254)
  %.state606 = load i64, ptr %.slot113, align 4
  %1256 = add i64 %.state606, 1
  store i64 %1256, ptr %.slot113, align 4
  %1257 = load <8 x float>, ptr %.slot114, align 32
  %1258 = select <8 x i1> %71, <8 x float> %1255, <8 x float> %1257
  store <8 x float> %1258, ptr %.slot114, align 32
  br label %direct.schedule.67

direct.schedule.69:                               ; preds = %direct.false597
  %.state607 = load <8 x float>, ptr %.slot36, align 32
  %.state608 = load <8 x float>, ptr %.slot114, align 32
  %1259 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state607, <8 x float> %.state608)
  %1260 = load <8 x float>, ptr %.spill115, align 32
  %1261 = select <8 x i1> %71, <8 x float> %1259, <8 x float> %1260
  store <8 x float> %1261, ptr %.spill115, align 32
  %.state609 = load <8 x float>, ptr %.slot36, align 32
  %1262 = fsub <8 x float> %.state609, %1259
  %1263 = select <8 x i1> %71, <8 x float> %1262, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1263)
  %1264 = load <8 x float>, ptr %.spill116, align 32
  %1265 = select <8 x i1> %71, <8 x float> %native.exp, <8 x float> %1264
  store <8 x float> %1265, ptr %.spill116, align 32
  %.spill.load610 = load <8 x float>, ptr %.spill96, align 32
  %1266 = fsub <8 x float> %.spill.load610, %1259
  %.spill.load611 = load <8 x float>, ptr %.spill97, align 32
  %1267 = fsub <8 x float> %.spill.load611, %1259
  %.spill.load612 = load <8 x float>, ptr %.spill98, align 32
  %1268 = fsub <8 x float> %.spill.load612, %1259
  %.spill.load613 = load <8 x float>, ptr %.spill99, align 32
  %1269 = fsub <8 x float> %.spill.load613, %1259
  %.spill.load614 = load <8 x float>, ptr %.spill100, align 32
  %1270 = fsub <8 x float> %.spill.load614, %1259
  %.spill.load615 = load <8 x float>, ptr %.spill101, align 32
  %1271 = fsub <8 x float> %.spill.load615, %1259
  %.spill.load616 = load <8 x float>, ptr %.spill102, align 32
  %1272 = fsub <8 x float> %.spill.load616, %1259
  %.spill.load617 = load <8 x float>, ptr %.spill103, align 32
  %1273 = fsub <8 x float> %.spill.load617, %1259
  %.spill.load618 = load <8 x float>, ptr %.spill104, align 32
  %1274 = fsub <8 x float> %.spill.load618, %1259
  %.spill.load619 = load <8 x float>, ptr %.spill105, align 32
  %1275 = fsub <8 x float> %.spill.load619, %1259
  %.spill.load620 = load <8 x float>, ptr %.spill106, align 32
  %1276 = fsub <8 x float> %.spill.load620, %1259
  %.spill.load621 = load <8 x float>, ptr %.spill107, align 32
  %1277 = fsub <8 x float> %.spill.load621, %1259
  %.spill.load622 = load <8 x float>, ptr %.spill108, align 32
  %1278 = fsub <8 x float> %.spill.load622, %1259
  %.spill.load623 = load <8 x float>, ptr %.spill109, align 32
  %1279 = fsub <8 x float> %.spill.load623, %1259
  %.spill.load624 = load <8 x float>, ptr %.spill110, align 32
  %1280 = fsub <8 x float> %.spill.load624, %1259
  %.spill.load625 = load <8 x float>, ptr %.spill111, align 32
  %1281 = fsub <8 x float> %.spill.load625, %1259
  %1282 = select <8 x i1> %71, <8 x float> %1266, <8 x float> zeroinitializer
  %native.exp626 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1282)
  %1283 = select <8 x i1> %71, <8 x float> %1267, <8 x float> zeroinitializer
  %native.exp627 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1283)
  %1284 = select <8 x i1> %71, <8 x float> %1268, <8 x float> zeroinitializer
  %native.exp628 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1284)
  %1285 = select <8 x i1> %71, <8 x float> %1269, <8 x float> zeroinitializer
  %native.exp629 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1285)
  %1286 = select <8 x i1> %71, <8 x float> %1270, <8 x float> zeroinitializer
  %native.exp630 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1286)
  %1287 = select <8 x i1> %71, <8 x float> %1271, <8 x float> zeroinitializer
  %native.exp631 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1287)
  %1288 = select <8 x i1> %71, <8 x float> %1272, <8 x float> zeroinitializer
  %native.exp632 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1288)
  %1289 = select <8 x i1> %71, <8 x float> %1273, <8 x float> zeroinitializer
  %native.exp633 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1289)
  %1290 = select <8 x i1> %71, <8 x float> %1274, <8 x float> zeroinitializer
  %native.exp634 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1290)
  %1291 = select <8 x i1> %71, <8 x float> %1275, <8 x float> zeroinitializer
  %native.exp635 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1291)
  %1292 = select <8 x i1> %71, <8 x float> %1276, <8 x float> zeroinitializer
  %native.exp636 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1292)
  %1293 = select <8 x i1> %71, <8 x float> %1277, <8 x float> zeroinitializer
  %native.exp637 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1293)
  %1294 = select <8 x i1> %71, <8 x float> %1278, <8 x float> zeroinitializer
  %native.exp638 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1294)
  %1295 = select <8 x i1> %71, <8 x float> %1279, <8 x float> zeroinitializer
  %native.exp639 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1295)
  %1296 = select <8 x i1> %71, <8 x float> %1280, <8 x float> zeroinitializer
  %native.exp640 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1296)
  %1297 = select <8 x i1> %71, <8 x float> %1281, <8 x float> zeroinitializer
  %native.exp641 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1297)
  %.spill.load642 = load i1, ptr %.spill80, align 1
  %.splatinsert643 = insertelement <8 x i1> poison, i1 %.spill.load642, i64 0
  %.splat644 = shufflevector <8 x i1> %.splatinsert643, <8 x i1> poison, <8 x i32> zeroinitializer
  %1298 = select <8 x i1> %.splat644, <8 x float> %native.exp626, <8 x float> zeroinitializer
  %1299 = load <8 x float>, ptr %.spill117, align 32
  %1300 = select <8 x i1> %71, <8 x float> %1298, <8 x float> %1299
  store <8 x float> %1300, ptr %.spill117, align 32
  %.spill.load645 = load i1, ptr %.spill81, align 1
  %.splatinsert646 = insertelement <8 x i1> poison, i1 %.spill.load645, i64 0
  %.splat647 = shufflevector <8 x i1> %.splatinsert646, <8 x i1> poison, <8 x i32> zeroinitializer
  %1301 = select <8 x i1> %.splat647, <8 x float> %native.exp627, <8 x float> zeroinitializer
  %1302 = load <8 x float>, ptr %.spill118, align 32
  %1303 = select <8 x i1> %71, <8 x float> %1301, <8 x float> %1302
  store <8 x float> %1303, ptr %.spill118, align 32
  %.spill.load648 = load i1, ptr %.spill82, align 1
  %.splatinsert649 = insertelement <8 x i1> poison, i1 %.spill.load648, i64 0
  %.splat650 = shufflevector <8 x i1> %.splatinsert649, <8 x i1> poison, <8 x i32> zeroinitializer
  %1304 = select <8 x i1> %.splat650, <8 x float> %native.exp628, <8 x float> zeroinitializer
  %1305 = load <8 x float>, ptr %.spill119, align 32
  %1306 = select <8 x i1> %71, <8 x float> %1304, <8 x float> %1305
  store <8 x float> %1306, ptr %.spill119, align 32
  %.spill.load651 = load i1, ptr %.spill83, align 1
  %.splatinsert652 = insertelement <8 x i1> poison, i1 %.spill.load651, i64 0
  %.splat653 = shufflevector <8 x i1> %.splatinsert652, <8 x i1> poison, <8 x i32> zeroinitializer
  %1307 = select <8 x i1> %.splat653, <8 x float> %native.exp629, <8 x float> zeroinitializer
  %1308 = load <8 x float>, ptr %.spill120, align 32
  %1309 = select <8 x i1> %71, <8 x float> %1307, <8 x float> %1308
  store <8 x float> %1309, ptr %.spill120, align 32
  %.spill.load654 = load i1, ptr %.spill84, align 1
  %.splatinsert655 = insertelement <8 x i1> poison, i1 %.spill.load654, i64 0
  %.splat656 = shufflevector <8 x i1> %.splatinsert655, <8 x i1> poison, <8 x i32> zeroinitializer
  %1310 = select <8 x i1> %.splat656, <8 x float> %native.exp630, <8 x float> zeroinitializer
  %1311 = load <8 x float>, ptr %.spill121, align 32
  %1312 = select <8 x i1> %71, <8 x float> %1310, <8 x float> %1311
  store <8 x float> %1312, ptr %.spill121, align 32
  %.spill.load657 = load i1, ptr %.spill85, align 1
  %.splatinsert658 = insertelement <8 x i1> poison, i1 %.spill.load657, i64 0
  %.splat659 = shufflevector <8 x i1> %.splatinsert658, <8 x i1> poison, <8 x i32> zeroinitializer
  %1313 = select <8 x i1> %.splat659, <8 x float> %native.exp631, <8 x float> zeroinitializer
  %1314 = load <8 x float>, ptr %.spill122, align 32
  %1315 = select <8 x i1> %71, <8 x float> %1313, <8 x float> %1314
  store <8 x float> %1315, ptr %.spill122, align 32
  %.spill.load660 = load i1, ptr %.spill86, align 1
  %.splatinsert661 = insertelement <8 x i1> poison, i1 %.spill.load660, i64 0
  %.splat662 = shufflevector <8 x i1> %.splatinsert661, <8 x i1> poison, <8 x i32> zeroinitializer
  %1316 = select <8 x i1> %.splat662, <8 x float> %native.exp632, <8 x float> zeroinitializer
  %1317 = load <8 x float>, ptr %.spill123, align 32
  %1318 = select <8 x i1> %71, <8 x float> %1316, <8 x float> %1317
  store <8 x float> %1318, ptr %.spill123, align 32
  %.spill.load663 = load i1, ptr %.spill87, align 1
  %.splatinsert664 = insertelement <8 x i1> poison, i1 %.spill.load663, i64 0
  %.splat665 = shufflevector <8 x i1> %.splatinsert664, <8 x i1> poison, <8 x i32> zeroinitializer
  %1319 = select <8 x i1> %.splat665, <8 x float> %native.exp633, <8 x float> zeroinitializer
  %1320 = load <8 x float>, ptr %.spill124, align 32
  %1321 = select <8 x i1> %71, <8 x float> %1319, <8 x float> %1320
  store <8 x float> %1321, ptr %.spill124, align 32
  %.spill.load666 = load i1, ptr %.spill88, align 1
  %.splatinsert667 = insertelement <8 x i1> poison, i1 %.spill.load666, i64 0
  %.splat668 = shufflevector <8 x i1> %.splatinsert667, <8 x i1> poison, <8 x i32> zeroinitializer
  %1322 = select <8 x i1> %.splat668, <8 x float> %native.exp634, <8 x float> zeroinitializer
  %1323 = load <8 x float>, ptr %.spill125, align 32
  %1324 = select <8 x i1> %71, <8 x float> %1322, <8 x float> %1323
  store <8 x float> %1324, ptr %.spill125, align 32
  %.spill.load669 = load i1, ptr %.spill89, align 1
  %.splatinsert670 = insertelement <8 x i1> poison, i1 %.spill.load669, i64 0
  %.splat671 = shufflevector <8 x i1> %.splatinsert670, <8 x i1> poison, <8 x i32> zeroinitializer
  %1325 = select <8 x i1> %.splat671, <8 x float> %native.exp635, <8 x float> zeroinitializer
  %1326 = load <8 x float>, ptr %.spill126, align 32
  %1327 = select <8 x i1> %71, <8 x float> %1325, <8 x float> %1326
  store <8 x float> %1327, ptr %.spill126, align 32
  %.spill.load672 = load i1, ptr %.spill90, align 1
  %.splatinsert673 = insertelement <8 x i1> poison, i1 %.spill.load672, i64 0
  %.splat674 = shufflevector <8 x i1> %.splatinsert673, <8 x i1> poison, <8 x i32> zeroinitializer
  %1328 = select <8 x i1> %.splat674, <8 x float> %native.exp636, <8 x float> zeroinitializer
  %1329 = load <8 x float>, ptr %.spill127, align 32
  %1330 = select <8 x i1> %71, <8 x float> %1328, <8 x float> %1329
  store <8 x float> %1330, ptr %.spill127, align 32
  %.spill.load675 = load i1, ptr %.spill91, align 1
  %.splatinsert676 = insertelement <8 x i1> poison, i1 %.spill.load675, i64 0
  %.splat677 = shufflevector <8 x i1> %.splatinsert676, <8 x i1> poison, <8 x i32> zeroinitializer
  %1331 = select <8 x i1> %.splat677, <8 x float> %native.exp637, <8 x float> zeroinitializer
  %1332 = load <8 x float>, ptr %.spill128, align 32
  %1333 = select <8 x i1> %71, <8 x float> %1331, <8 x float> %1332
  store <8 x float> %1333, ptr %.spill128, align 32
  %.spill.load678 = load i1, ptr %.spill92, align 1
  %.splatinsert679 = insertelement <8 x i1> poison, i1 %.spill.load678, i64 0
  %.splat680 = shufflevector <8 x i1> %.splatinsert679, <8 x i1> poison, <8 x i32> zeroinitializer
  %1334 = select <8 x i1> %.splat680, <8 x float> %native.exp638, <8 x float> zeroinitializer
  %1335 = load <8 x float>, ptr %.spill129, align 32
  %1336 = select <8 x i1> %71, <8 x float> %1334, <8 x float> %1335
  store <8 x float> %1336, ptr %.spill129, align 32
  %.spill.load681 = load i1, ptr %.spill93, align 1
  %.splatinsert682 = insertelement <8 x i1> poison, i1 %.spill.load681, i64 0
  %.splat683 = shufflevector <8 x i1> %.splatinsert682, <8 x i1> poison, <8 x i32> zeroinitializer
  %1337 = select <8 x i1> %.splat683, <8 x float> %native.exp639, <8 x float> zeroinitializer
  %1338 = load <8 x float>, ptr %.spill130, align 32
  %1339 = select <8 x i1> %71, <8 x float> %1337, <8 x float> %1338
  store <8 x float> %1339, ptr %.spill130, align 32
  %.spill.load684 = load i1, ptr %.spill94, align 1
  %.splatinsert685 = insertelement <8 x i1> poison, i1 %.spill.load684, i64 0
  %.splat686 = shufflevector <8 x i1> %.splatinsert685, <8 x i1> poison, <8 x i32> zeroinitializer
  %1340 = select <8 x i1> %.splat686, <8 x float> %native.exp640, <8 x float> zeroinitializer
  %1341 = load <8 x float>, ptr %.spill131, align 32
  %1342 = select <8 x i1> %71, <8 x float> %1340, <8 x float> %1341
  store <8 x float> %1342, ptr %.spill131, align 32
  %.spill.load687 = load i1, ptr %.spill95, align 1
  %.splatinsert688 = insertelement <8 x i1> poison, i1 %.spill.load687, i64 0
  %.splat689 = shufflevector <8 x i1> %.splatinsert688, <8 x i1> poison, <8 x i32> zeroinitializer
  %1343 = select <8 x i1> %.splat689, <8 x float> %native.exp641, <8 x float> zeroinitializer
  %1344 = load <8 x float>, ptr %.spill132, align 32
  %1345 = select <8 x i1> %71, <8 x float> %1343, <8 x float> %1344
  store <8 x float> %1345, ptr %.spill132, align 32
  %1346 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %1347 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1348 = extractvalue { <8 x ptr>, <8 x i64> } %1346, 0
  %1349 = select <8 x i1> %71, <8 x ptr> %1347, <8 x ptr> %1348
  %1350 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1351 = extractvalue { <8 x ptr>, <8 x i64> } %1346, 1
  %1352 = select <8 x i1> %71, <8 x i64> %1350, <8 x i64> %1351
  %1353 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1349, 0
  %1354 = insertvalue { <8 x ptr>, <8 x i64> } %1353, <8 x i64> %1352, 1
  store { <8 x ptr>, <8 x i64> } %1354, ptr %tile_snapshot.spill133, align 64
  %1355 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1356 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1357 = add <8 x i64> %1356, zeroinitializer
  %1358 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1355, 0
  %1359 = insertvalue { <8 x ptr>, <8 x i64> } %1358, <8 x i64> %1357, 1
  %1360 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1361 = extractvalue { <8 x ptr>, <8 x i64> } %1359, 1
  %1362 = extractelement <8 x ptr> %1360, i32 0
  %1363 = extractelement <8 x i64> %1361, i32 0
  %1364 = sub i64 %1363, 0
  %1365 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1366 = select i1 %1365, i64 %1364, i64 0
  %private.contiguous.address690 = getelementptr i8, ptr %1362, i64 %1366
  %private.contiguous.preserve691 = load <8 x float>, ptr %private.contiguous.address690, align 4
  %1367 = select <8 x i1> %71, <8 x float> %1298, <8 x float> %private.contiguous.preserve691
  store <8 x float> %1367, ptr %private.contiguous.address690, align 4
  %1368 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1369 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1370 = add <8 x i64> %1369, splat (i64 32)
  %1371 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1368, 0
  %1372 = insertvalue { <8 x ptr>, <8 x i64> } %1371, <8 x i64> %1370, 1
  %1373 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1374 = extractvalue { <8 x ptr>, <8 x i64> } %1372, 1
  %1375 = extractelement <8 x ptr> %1373, i32 0
  %1376 = extractelement <8 x i64> %1374, i32 0
  %1377 = sub i64 %1376, 0
  %1378 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1379 = select i1 %1378, i64 %1377, i64 0
  %private.contiguous.address692 = getelementptr i8, ptr %1375, i64 %1379
  %private.contiguous.preserve693 = load <8 x float>, ptr %private.contiguous.address692, align 4
  %1380 = select <8 x i1> %71, <8 x float> %1301, <8 x float> %private.contiguous.preserve693
  store <8 x float> %1380, ptr %private.contiguous.address692, align 4
  %1381 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1382 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1383 = add <8 x i64> %1382, splat (i64 64)
  %1384 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1381, 0
  %1385 = insertvalue { <8 x ptr>, <8 x i64> } %1384, <8 x i64> %1383, 1
  %1386 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1387 = extractvalue { <8 x ptr>, <8 x i64> } %1385, 1
  %1388 = extractelement <8 x ptr> %1386, i32 0
  %1389 = extractelement <8 x i64> %1387, i32 0
  %1390 = sub i64 %1389, 0
  %1391 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1392 = select i1 %1391, i64 %1390, i64 0
  %private.contiguous.address694 = getelementptr i8, ptr %1388, i64 %1392
  %private.contiguous.preserve695 = load <8 x float>, ptr %private.contiguous.address694, align 4
  %1393 = select <8 x i1> %71, <8 x float> %1304, <8 x float> %private.contiguous.preserve695
  store <8 x float> %1393, ptr %private.contiguous.address694, align 4
  %1394 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1395 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1396 = add <8 x i64> %1395, splat (i64 96)
  %1397 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1394, 0
  %1398 = insertvalue { <8 x ptr>, <8 x i64> } %1397, <8 x i64> %1396, 1
  %1399 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1400 = extractvalue { <8 x ptr>, <8 x i64> } %1398, 1
  %1401 = extractelement <8 x ptr> %1399, i32 0
  %1402 = extractelement <8 x i64> %1400, i32 0
  %1403 = sub i64 %1402, 0
  %1404 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1405 = select i1 %1404, i64 %1403, i64 0
  %private.contiguous.address696 = getelementptr i8, ptr %1401, i64 %1405
  %private.contiguous.preserve697 = load <8 x float>, ptr %private.contiguous.address696, align 4
  %1406 = select <8 x i1> %71, <8 x float> %1307, <8 x float> %private.contiguous.preserve697
  store <8 x float> %1406, ptr %private.contiguous.address696, align 4
  %1407 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1408 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1409 = add <8 x i64> %1408, splat (i64 128)
  %1410 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1407, 0
  %1411 = insertvalue { <8 x ptr>, <8 x i64> } %1410, <8 x i64> %1409, 1
  %1412 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1413 = extractvalue { <8 x ptr>, <8 x i64> } %1411, 1
  %1414 = extractelement <8 x ptr> %1412, i32 0
  %1415 = extractelement <8 x i64> %1413, i32 0
  %1416 = sub i64 %1415, 0
  %1417 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1418 = select i1 %1417, i64 %1416, i64 0
  %private.contiguous.address698 = getelementptr i8, ptr %1414, i64 %1418
  %private.contiguous.preserve699 = load <8 x float>, ptr %private.contiguous.address698, align 4
  %1419 = select <8 x i1> %71, <8 x float> %1310, <8 x float> %private.contiguous.preserve699
  store <8 x float> %1419, ptr %private.contiguous.address698, align 4
  %1420 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1421 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1422 = add <8 x i64> %1421, splat (i64 160)
  %1423 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1420, 0
  %1424 = insertvalue { <8 x ptr>, <8 x i64> } %1423, <8 x i64> %1422, 1
  %1425 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1426 = extractvalue { <8 x ptr>, <8 x i64> } %1424, 1
  %1427 = extractelement <8 x ptr> %1425, i32 0
  %1428 = extractelement <8 x i64> %1426, i32 0
  %1429 = sub i64 %1428, 0
  %1430 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1431 = select i1 %1430, i64 %1429, i64 0
  %private.contiguous.address700 = getelementptr i8, ptr %1427, i64 %1431
  %private.contiguous.preserve701 = load <8 x float>, ptr %private.contiguous.address700, align 4
  %1432 = select <8 x i1> %71, <8 x float> %1313, <8 x float> %private.contiguous.preserve701
  store <8 x float> %1432, ptr %private.contiguous.address700, align 4
  %1433 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1434 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1435 = add <8 x i64> %1434, splat (i64 192)
  %1436 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1433, 0
  %1437 = insertvalue { <8 x ptr>, <8 x i64> } %1436, <8 x i64> %1435, 1
  %1438 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1439 = extractvalue { <8 x ptr>, <8 x i64> } %1437, 1
  %1440 = extractelement <8 x ptr> %1438, i32 0
  %1441 = extractelement <8 x i64> %1439, i32 0
  %1442 = sub i64 %1441, 0
  %1443 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1444 = select i1 %1443, i64 %1442, i64 0
  %private.contiguous.address702 = getelementptr i8, ptr %1440, i64 %1444
  %private.contiguous.preserve703 = load <8 x float>, ptr %private.contiguous.address702, align 4
  %1445 = select <8 x i1> %71, <8 x float> %1316, <8 x float> %private.contiguous.preserve703
  store <8 x float> %1445, ptr %private.contiguous.address702, align 4
  %1446 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1447 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1448 = add <8 x i64> %1447, splat (i64 224)
  %1449 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1446, 0
  %1450 = insertvalue { <8 x ptr>, <8 x i64> } %1449, <8 x i64> %1448, 1
  %1451 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1452 = extractvalue { <8 x ptr>, <8 x i64> } %1450, 1
  %1453 = extractelement <8 x ptr> %1451, i32 0
  %1454 = extractelement <8 x i64> %1452, i32 0
  %1455 = sub i64 %1454, 0
  %1456 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1457 = select i1 %1456, i64 %1455, i64 0
  %private.contiguous.address704 = getelementptr i8, ptr %1453, i64 %1457
  %private.contiguous.preserve705 = load <8 x float>, ptr %private.contiguous.address704, align 4
  %1458 = select <8 x i1> %71, <8 x float> %1319, <8 x float> %private.contiguous.preserve705
  store <8 x float> %1458, ptr %private.contiguous.address704, align 4
  %1459 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1460 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1461 = add <8 x i64> %1460, splat (i64 256)
  %1462 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1459, 0
  %1463 = insertvalue { <8 x ptr>, <8 x i64> } %1462, <8 x i64> %1461, 1
  %1464 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1465 = extractvalue { <8 x ptr>, <8 x i64> } %1463, 1
  %1466 = extractelement <8 x ptr> %1464, i32 0
  %1467 = extractelement <8 x i64> %1465, i32 0
  %1468 = sub i64 %1467, 0
  %1469 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1470 = select i1 %1469, i64 %1468, i64 0
  %private.contiguous.address706 = getelementptr i8, ptr %1466, i64 %1470
  %private.contiguous.preserve707 = load <8 x float>, ptr %private.contiguous.address706, align 4
  %1471 = select <8 x i1> %71, <8 x float> %1322, <8 x float> %private.contiguous.preserve707
  store <8 x float> %1471, ptr %private.contiguous.address706, align 4
  %1472 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1473 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1474 = add <8 x i64> %1473, splat (i64 288)
  %1475 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1472, 0
  %1476 = insertvalue { <8 x ptr>, <8 x i64> } %1475, <8 x i64> %1474, 1
  %1477 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1478 = extractvalue { <8 x ptr>, <8 x i64> } %1476, 1
  %1479 = extractelement <8 x ptr> %1477, i32 0
  %1480 = extractelement <8 x i64> %1478, i32 0
  %1481 = sub i64 %1480, 0
  %1482 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1483 = select i1 %1482, i64 %1481, i64 0
  %private.contiguous.address708 = getelementptr i8, ptr %1479, i64 %1483
  %private.contiguous.preserve709 = load <8 x float>, ptr %private.contiguous.address708, align 4
  %1484 = select <8 x i1> %71, <8 x float> %1325, <8 x float> %private.contiguous.preserve709
  store <8 x float> %1484, ptr %private.contiguous.address708, align 4
  %1485 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1486 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1487 = add <8 x i64> %1486, splat (i64 320)
  %1488 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1485, 0
  %1489 = insertvalue { <8 x ptr>, <8 x i64> } %1488, <8 x i64> %1487, 1
  %1490 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1491 = extractvalue { <8 x ptr>, <8 x i64> } %1489, 1
  %1492 = extractelement <8 x ptr> %1490, i32 0
  %1493 = extractelement <8 x i64> %1491, i32 0
  %1494 = sub i64 %1493, 0
  %1495 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1496 = select i1 %1495, i64 %1494, i64 0
  %private.contiguous.address710 = getelementptr i8, ptr %1492, i64 %1496
  %private.contiguous.preserve711 = load <8 x float>, ptr %private.contiguous.address710, align 4
  %1497 = select <8 x i1> %71, <8 x float> %1328, <8 x float> %private.contiguous.preserve711
  store <8 x float> %1497, ptr %private.contiguous.address710, align 4
  %1498 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1499 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1500 = add <8 x i64> %1499, splat (i64 352)
  %1501 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1498, 0
  %1502 = insertvalue { <8 x ptr>, <8 x i64> } %1501, <8 x i64> %1500, 1
  %1503 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1504 = extractvalue { <8 x ptr>, <8 x i64> } %1502, 1
  %1505 = extractelement <8 x ptr> %1503, i32 0
  %1506 = extractelement <8 x i64> %1504, i32 0
  %1507 = sub i64 %1506, 0
  %1508 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1509 = select i1 %1508, i64 %1507, i64 0
  %private.contiguous.address712 = getelementptr i8, ptr %1505, i64 %1509
  %private.contiguous.preserve713 = load <8 x float>, ptr %private.contiguous.address712, align 4
  %1510 = select <8 x i1> %71, <8 x float> %1331, <8 x float> %private.contiguous.preserve713
  store <8 x float> %1510, ptr %private.contiguous.address712, align 4
  %1511 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1512 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1513 = add <8 x i64> %1512, splat (i64 384)
  %1514 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1511, 0
  %1515 = insertvalue { <8 x ptr>, <8 x i64> } %1514, <8 x i64> %1513, 1
  %1516 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1517 = extractvalue { <8 x ptr>, <8 x i64> } %1515, 1
  %1518 = extractelement <8 x ptr> %1516, i32 0
  %1519 = extractelement <8 x i64> %1517, i32 0
  %1520 = sub i64 %1519, 0
  %1521 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1522 = select i1 %1521, i64 %1520, i64 0
  %private.contiguous.address714 = getelementptr i8, ptr %1518, i64 %1522
  %private.contiguous.preserve715 = load <8 x float>, ptr %private.contiguous.address714, align 4
  %1523 = select <8 x i1> %71, <8 x float> %1334, <8 x float> %private.contiguous.preserve715
  store <8 x float> %1523, ptr %private.contiguous.address714, align 4
  %1524 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1525 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1526 = add <8 x i64> %1525, splat (i64 416)
  %1527 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1524, 0
  %1528 = insertvalue { <8 x ptr>, <8 x i64> } %1527, <8 x i64> %1526, 1
  %1529 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1530 = extractvalue { <8 x ptr>, <8 x i64> } %1528, 1
  %1531 = extractelement <8 x ptr> %1529, i32 0
  %1532 = extractelement <8 x i64> %1530, i32 0
  %1533 = sub i64 %1532, 0
  %1534 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1535 = select i1 %1534, i64 %1533, i64 0
  %private.contiguous.address716 = getelementptr i8, ptr %1531, i64 %1535
  %private.contiguous.preserve717 = load <8 x float>, ptr %private.contiguous.address716, align 4
  %1536 = select <8 x i1> %71, <8 x float> %1337, <8 x float> %private.contiguous.preserve717
  store <8 x float> %1536, ptr %private.contiguous.address716, align 4
  %1537 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1538 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1539 = add <8 x i64> %1538, splat (i64 448)
  %1540 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1537, 0
  %1541 = insertvalue { <8 x ptr>, <8 x i64> } %1540, <8 x i64> %1539, 1
  %1542 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1543 = extractvalue { <8 x ptr>, <8 x i64> } %1541, 1
  %1544 = extractelement <8 x ptr> %1542, i32 0
  %1545 = extractelement <8 x i64> %1543, i32 0
  %1546 = sub i64 %1545, 0
  %1547 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1548 = select i1 %1547, i64 %1546, i64 0
  %private.contiguous.address718 = getelementptr i8, ptr %1544, i64 %1548
  %private.contiguous.preserve719 = load <8 x float>, ptr %private.contiguous.address718, align 4
  %1549 = select <8 x i1> %71, <8 x float> %1340, <8 x float> %private.contiguous.preserve719
  store <8 x float> %1549, ptr %private.contiguous.address718, align 4
  %1550 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1551 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1552 = add <8 x i64> %1551, splat (i64 480)
  %1553 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1550, 0
  %1554 = insertvalue { <8 x ptr>, <8 x i64> } %1553, <8 x i64> %1552, 1
  %1555 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1556 = extractvalue { <8 x ptr>, <8 x i64> } %1554, 1
  %1557 = extractelement <8 x ptr> %1555, i32 0
  %1558 = extractelement <8 x i64> %1556, i32 0
  %1559 = sub i64 %1558, 0
  %1560 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1561 = select i1 %1560, i64 %1559, i64 0
  %private.contiguous.address720 = getelementptr i8, ptr %1557, i64 %1561
  %private.contiguous.preserve721 = load <8 x float>, ptr %private.contiguous.address720, align 4
  %1562 = select <8 x i1> %71, <8 x float> %1343, <8 x float> %private.contiguous.preserve721
  store <8 x float> %1562, ptr %private.contiguous.address720, align 4
  %.state722 = load <8 x float>, ptr %.slot37, align 32
  %1563 = fmul <8 x float> %.state722, %native.exp
  %1564 = load <8 x float>, ptr %.spill134, align 32
  %1565 = select <8 x i1> %71, <8 x float> %1563, <8 x float> %1564
  store <8 x float> %1565, ptr %.spill134, align 32
  store i64 0, ptr %.slot135, align 4
  %1566 = load <8 x float>, ptr %.slot136, align 32
  %1567 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1566
  store <8 x float> %1567, ptr %.slot136, align 32
  br label %direct.schedule.70

direct.schedule.70:                               ; preds = %direct.schedule.71, %direct.schedule.69
  %.state723 = load i64, ptr %.slot135, align 4
  %1568 = icmp slt i64 %.state723, 16
  br i1 %1568, label %direct.true724, label %direct.false725

direct.schedule.71:                               ; preds = %direct.true724
  %.state726 = load i64, ptr %.slot135, align 4
  %1569 = sdiv i64 %.state726, 1
  %.spill.load727 = load i64, ptr %.spill79, align 4
  %1570 = mul i64 %.spill.load727, 1
  %1571 = add i64 %1570, 0
  %1572 = mul i64 %1571, 1
  %1573 = add i64 %1572, 0
  %1574 = mul i64 %1573, 16
  %1575 = add i64 %1574, %1569
  %tile_snapshot.spill.load728 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %1576 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load728, 0
  %1577 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load728, 1
  %.splatinsert729 = insertelement <8 x i64> poison, i64 %1575, i64 0
  %.splat730 = shufflevector <8 x i64> %.splatinsert729, <8 x i64> poison, <8 x i32> zeroinitializer
  %1578 = mul <8 x i64> %.splat730, splat (i64 32)
  %1579 = add <8 x i64> %1577, %1578
  %1580 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1576, 0
  %1581 = insertvalue { <8 x ptr>, <8 x i64> } %1580, <8 x i64> %1579, 1
  %1582 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1583 = extractvalue { <8 x ptr>, <8 x i64> } %1581, 1
  %1584 = extractelement <8 x ptr> %1582, i32 0
  %1585 = extractelement <8 x i64> %1583, i32 0
  %1586 = sub i64 %1585, 0
  %1587 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1588 = select i1 %1587, i64 %1586, i64 0
  %private.contiguous.address731 = getelementptr i8, ptr %1584, i64 %1588
  %private.contiguous.load732 = load <8 x float>, ptr %private.contiguous.address731, align 4
  %1589 = select <8 x i1> %71, <8 x float> %private.contiguous.load732, <8 x float> zeroinitializer
  %.state733 = load <8 x float>, ptr %.slot136, align 32
  %1590 = fadd <8 x float> %.state733, %1589
  %.state734 = load i64, ptr %.slot135, align 4
  %1591 = add i64 %.state734, 1
  store i64 %1591, ptr %.slot135, align 4
  %1592 = load <8 x float>, ptr %.slot136, align 32
  %1593 = select <8 x i1> %71, <8 x float> %1590, <8 x float> %1592
  store <8 x float> %1593, ptr %.slot136, align 32
  br label %direct.schedule.70

direct.schedule.72:                               ; preds = %direct.false725
  %.spill.load735 = load <8 x float>, ptr %.spill134, align 32
  %.state736 = load <8 x float>, ptr %.slot136, align 32
  %1594 = fadd <8 x float> %.spill.load735, %.state736
  %1595 = load <8 x float>, ptr %.spill137, align 32
  %1596 = select <8 x i1> %71, <8 x float> %1594, <8 x float> %1595
  store <8 x float> %1596, ptr %.spill137, align 32
  %1597 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill138, align 64
  %1598 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1599 = extractvalue { <8 x ptr>, <8 x i64> } %1597, 0
  %1600 = select <8 x i1> %71, <8 x ptr> %1598, <8 x ptr> %1599
  %1601 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1602 = extractvalue { <8 x ptr>, <8 x i64> } %1597, 1
  %1603 = select <8 x i1> %71, <8 x i64> %1601, <8 x i64> %1602
  %1604 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1600, 0
  %1605 = insertvalue { <8 x ptr>, <8 x i64> } %1604, <8 x i64> %1603, 1
  store { <8 x ptr>, <8 x i64> } %1605, ptr %tile_snapshot.spill138, align 64
  store i64 0, ptr %.slot139, align 4
  br label %direct.schedule.73

direct.schedule.73:                               ; preds = %direct.schedule.74, %direct.schedule.72
  %.state737 = load i64, ptr %.slot139, align 4
  %1606 = icmp slt i64 %.state737, 96
  br i1 %1606, label %direct.true738, label %direct.false739

direct.schedule.74:                               ; preds = %direct.true738
  %.state740 = load i64, ptr %.slot139, align 4
  %1607 = add i64 0, %.state740
  %tile_snapshot.spill.load741 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1608 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load741, 0
  %1609 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load741, 1
  %.splatinsert742 = insertelement <8 x i64> poison, i64 %1607, i64 0
  %.splat743 = shufflevector <8 x i64> %.splatinsert742, <8 x i64> poison, <8 x i32> zeroinitializer
  %1610 = mul <8 x i64> %.splat743, splat (i64 32)
  %1611 = add <8 x i64> %1609, %1610
  %1612 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1608, 0
  %1613 = insertvalue { <8 x ptr>, <8 x i64> } %1612, <8 x i64> %1611, 1
  %1614 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1615 = extractvalue { <8 x ptr>, <8 x i64> } %1613, 1
  %1616 = extractelement <8 x ptr> %1614, i32 0
  %1617 = extractelement <8 x i64> %1615, i32 0
  %1618 = sub i64 %1617, 0
  %1619 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1620 = select i1 %1619, i64 %1618, i64 0
  %private.contiguous.address744 = getelementptr i8, ptr %1616, i64 %1620
  %private.contiguous.load745 = load <8 x float>, ptr %private.contiguous.address744, align 4
  %1621 = select <8 x i1> %71, <8 x float> %private.contiguous.load745, <8 x float> zeroinitializer
  %.spill.load746 = load <8 x float>, ptr %.spill116, align 32
  %1622 = fmul <8 x float> %1621, %.spill.load746
  %tile_snapshot.spill.load747 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1623 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load747, 0
  %1624 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load747, 1
  %.splatinsert748 = insertelement <8 x i64> poison, i64 %1607, i64 0
  %.splat749 = shufflevector <8 x i64> %.splatinsert748, <8 x i64> poison, <8 x i32> zeroinitializer
  %1625 = mul <8 x i64> %.splat749, splat (i64 32)
  %1626 = add <8 x i64> %1624, %1625
  %1627 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1623, 0
  %1628 = insertvalue { <8 x ptr>, <8 x i64> } %1627, <8 x i64> %1626, 1
  %1629 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1630 = extractvalue { <8 x ptr>, <8 x i64> } %1628, 1
  %1631 = extractelement <8 x ptr> %1629, i32 0
  %1632 = extractelement <8 x i64> %1630, i32 0
  %1633 = sub i64 %1632, 0
  %1634 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1635 = select i1 %1634, i64 %1633, i64 0
  %private.contiguous.address750 = getelementptr i8, ptr %1631, i64 %1635
  %private.contiguous.load751 = load <8 x float>, ptr %private.contiguous.address750, align 4
  %1636 = select <8 x i1> %71, <8 x float> %private.contiguous.load751, <8 x float> zeroinitializer
  %.spill.load752 = load <8 x float>, ptr %.spill117, align 32
  %1637 = fmul <8 x float> %.spill.load752, %1636
  %1638 = fadd <8 x float> %1622, %1637
  %.state753 = load i64, ptr %.slot139, align 4
  %1639 = add i64 96, %.state753
  %tile_snapshot.spill.load754 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1640 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load754, 0
  %1641 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load754, 1
  %.splatinsert755 = insertelement <8 x i64> poison, i64 %1639, i64 0
  %.splat756 = shufflevector <8 x i64> %.splatinsert755, <8 x i64> poison, <8 x i32> zeroinitializer
  %1642 = mul <8 x i64> %.splat756, splat (i64 32)
  %1643 = add <8 x i64> %1641, %1642
  %1644 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1640, 0
  %1645 = insertvalue { <8 x ptr>, <8 x i64> } %1644, <8 x i64> %1643, 1
  %1646 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1647 = extractvalue { <8 x ptr>, <8 x i64> } %1645, 1
  %1648 = extractelement <8 x ptr> %1646, i32 0
  %1649 = extractelement <8 x i64> %1647, i32 0
  %1650 = sub i64 %1649, 0
  %1651 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1652 = select i1 %1651, i64 %1650, i64 0
  %private.contiguous.address757 = getelementptr i8, ptr %1648, i64 %1652
  %private.contiguous.load758 = load <8 x float>, ptr %private.contiguous.address757, align 4
  %1653 = select <8 x i1> %71, <8 x float> %private.contiguous.load758, <8 x float> zeroinitializer
  %.spill.load759 = load <8 x float>, ptr %.spill118, align 32
  %1654 = fmul <8 x float> %.spill.load759, %1653
  %1655 = fadd <8 x float> %1638, %1654
  %.state760 = load i64, ptr %.slot139, align 4
  %1656 = add i64 192, %.state760
  %tile_snapshot.spill.load761 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1657 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load761, 0
  %1658 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load761, 1
  %.splatinsert762 = insertelement <8 x i64> poison, i64 %1656, i64 0
  %.splat763 = shufflevector <8 x i64> %.splatinsert762, <8 x i64> poison, <8 x i32> zeroinitializer
  %1659 = mul <8 x i64> %.splat763, splat (i64 32)
  %1660 = add <8 x i64> %1658, %1659
  %1661 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1657, 0
  %1662 = insertvalue { <8 x ptr>, <8 x i64> } %1661, <8 x i64> %1660, 1
  %1663 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1664 = extractvalue { <8 x ptr>, <8 x i64> } %1662, 1
  %1665 = extractelement <8 x ptr> %1663, i32 0
  %1666 = extractelement <8 x i64> %1664, i32 0
  %1667 = sub i64 %1666, 0
  %1668 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1669 = select i1 %1668, i64 %1667, i64 0
  %private.contiguous.address764 = getelementptr i8, ptr %1665, i64 %1669
  %private.contiguous.load765 = load <8 x float>, ptr %private.contiguous.address764, align 4
  %1670 = select <8 x i1> %71, <8 x float> %private.contiguous.load765, <8 x float> zeroinitializer
  %.spill.load766 = load <8 x float>, ptr %.spill119, align 32
  %1671 = fmul <8 x float> %.spill.load766, %1670
  %1672 = fadd <8 x float> %1655, %1671
  %.state767 = load i64, ptr %.slot139, align 4
  %1673 = add i64 288, %.state767
  %tile_snapshot.spill.load768 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1674 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load768, 0
  %1675 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load768, 1
  %.splatinsert769 = insertelement <8 x i64> poison, i64 %1673, i64 0
  %.splat770 = shufflevector <8 x i64> %.splatinsert769, <8 x i64> poison, <8 x i32> zeroinitializer
  %1676 = mul <8 x i64> %.splat770, splat (i64 32)
  %1677 = add <8 x i64> %1675, %1676
  %1678 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1674, 0
  %1679 = insertvalue { <8 x ptr>, <8 x i64> } %1678, <8 x i64> %1677, 1
  %1680 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1681 = extractvalue { <8 x ptr>, <8 x i64> } %1679, 1
  %1682 = extractelement <8 x ptr> %1680, i32 0
  %1683 = extractelement <8 x i64> %1681, i32 0
  %1684 = sub i64 %1683, 0
  %1685 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1686 = select i1 %1685, i64 %1684, i64 0
  %private.contiguous.address771 = getelementptr i8, ptr %1682, i64 %1686
  %private.contiguous.load772 = load <8 x float>, ptr %private.contiguous.address771, align 4
  %1687 = select <8 x i1> %71, <8 x float> %private.contiguous.load772, <8 x float> zeroinitializer
  %.spill.load773 = load <8 x float>, ptr %.spill120, align 32
  %1688 = fmul <8 x float> %.spill.load773, %1687
  %1689 = fadd <8 x float> %1672, %1688
  %.state774 = load i64, ptr %.slot139, align 4
  %1690 = add i64 384, %.state774
  %tile_snapshot.spill.load775 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1691 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load775, 0
  %1692 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load775, 1
  %.splatinsert776 = insertelement <8 x i64> poison, i64 %1690, i64 0
  %.splat777 = shufflevector <8 x i64> %.splatinsert776, <8 x i64> poison, <8 x i32> zeroinitializer
  %1693 = mul <8 x i64> %.splat777, splat (i64 32)
  %1694 = add <8 x i64> %1692, %1693
  %1695 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1691, 0
  %1696 = insertvalue { <8 x ptr>, <8 x i64> } %1695, <8 x i64> %1694, 1
  %1697 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1698 = extractvalue { <8 x ptr>, <8 x i64> } %1696, 1
  %1699 = extractelement <8 x ptr> %1697, i32 0
  %1700 = extractelement <8 x i64> %1698, i32 0
  %1701 = sub i64 %1700, 0
  %1702 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1703 = select i1 %1702, i64 %1701, i64 0
  %private.contiguous.address778 = getelementptr i8, ptr %1699, i64 %1703
  %private.contiguous.load779 = load <8 x float>, ptr %private.contiguous.address778, align 4
  %1704 = select <8 x i1> %71, <8 x float> %private.contiguous.load779, <8 x float> zeroinitializer
  %.spill.load780 = load <8 x float>, ptr %.spill121, align 32
  %1705 = fmul <8 x float> %.spill.load780, %1704
  %1706 = fadd <8 x float> %1689, %1705
  %.state781 = load i64, ptr %.slot139, align 4
  %1707 = add i64 480, %.state781
  %tile_snapshot.spill.load782 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1708 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load782, 0
  %1709 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load782, 1
  %.splatinsert783 = insertelement <8 x i64> poison, i64 %1707, i64 0
  %.splat784 = shufflevector <8 x i64> %.splatinsert783, <8 x i64> poison, <8 x i32> zeroinitializer
  %1710 = mul <8 x i64> %.splat784, splat (i64 32)
  %1711 = add <8 x i64> %1709, %1710
  %1712 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1708, 0
  %1713 = insertvalue { <8 x ptr>, <8 x i64> } %1712, <8 x i64> %1711, 1
  %1714 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1715 = extractvalue { <8 x ptr>, <8 x i64> } %1713, 1
  %1716 = extractelement <8 x ptr> %1714, i32 0
  %1717 = extractelement <8 x i64> %1715, i32 0
  %1718 = sub i64 %1717, 0
  %1719 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1720 = select i1 %1719, i64 %1718, i64 0
  %private.contiguous.address785 = getelementptr i8, ptr %1716, i64 %1720
  %private.contiguous.load786 = load <8 x float>, ptr %private.contiguous.address785, align 4
  %1721 = select <8 x i1> %71, <8 x float> %private.contiguous.load786, <8 x float> zeroinitializer
  %.spill.load787 = load <8 x float>, ptr %.spill122, align 32
  %1722 = fmul <8 x float> %.spill.load787, %1721
  %1723 = fadd <8 x float> %1706, %1722
  %.state788 = load i64, ptr %.slot139, align 4
  %1724 = add i64 576, %.state788
  %tile_snapshot.spill.load789 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1725 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load789, 0
  %1726 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load789, 1
  %.splatinsert790 = insertelement <8 x i64> poison, i64 %1724, i64 0
  %.splat791 = shufflevector <8 x i64> %.splatinsert790, <8 x i64> poison, <8 x i32> zeroinitializer
  %1727 = mul <8 x i64> %.splat791, splat (i64 32)
  %1728 = add <8 x i64> %1726, %1727
  %1729 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1725, 0
  %1730 = insertvalue { <8 x ptr>, <8 x i64> } %1729, <8 x i64> %1728, 1
  %1731 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1732 = extractvalue { <8 x ptr>, <8 x i64> } %1730, 1
  %1733 = extractelement <8 x ptr> %1731, i32 0
  %1734 = extractelement <8 x i64> %1732, i32 0
  %1735 = sub i64 %1734, 0
  %1736 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1737 = select i1 %1736, i64 %1735, i64 0
  %private.contiguous.address792 = getelementptr i8, ptr %1733, i64 %1737
  %private.contiguous.load793 = load <8 x float>, ptr %private.contiguous.address792, align 4
  %1738 = select <8 x i1> %71, <8 x float> %private.contiguous.load793, <8 x float> zeroinitializer
  %.spill.load794 = load <8 x float>, ptr %.spill123, align 32
  %1739 = fmul <8 x float> %.spill.load794, %1738
  %1740 = fadd <8 x float> %1723, %1739
  %.state795 = load i64, ptr %.slot139, align 4
  %1741 = add i64 672, %.state795
  %tile_snapshot.spill.load796 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1742 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load796, 0
  %1743 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load796, 1
  %.splatinsert797 = insertelement <8 x i64> poison, i64 %1741, i64 0
  %.splat798 = shufflevector <8 x i64> %.splatinsert797, <8 x i64> poison, <8 x i32> zeroinitializer
  %1744 = mul <8 x i64> %.splat798, splat (i64 32)
  %1745 = add <8 x i64> %1743, %1744
  %1746 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1742, 0
  %1747 = insertvalue { <8 x ptr>, <8 x i64> } %1746, <8 x i64> %1745, 1
  %1748 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1749 = extractvalue { <8 x ptr>, <8 x i64> } %1747, 1
  %1750 = extractelement <8 x ptr> %1748, i32 0
  %1751 = extractelement <8 x i64> %1749, i32 0
  %1752 = sub i64 %1751, 0
  %1753 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1754 = select i1 %1753, i64 %1752, i64 0
  %private.contiguous.address799 = getelementptr i8, ptr %1750, i64 %1754
  %private.contiguous.load800 = load <8 x float>, ptr %private.contiguous.address799, align 4
  %1755 = select <8 x i1> %71, <8 x float> %private.contiguous.load800, <8 x float> zeroinitializer
  %.spill.load801 = load <8 x float>, ptr %.spill124, align 32
  %1756 = fmul <8 x float> %.spill.load801, %1755
  %1757 = fadd <8 x float> %1740, %1756
  %.state802 = load i64, ptr %.slot139, align 4
  %1758 = add i64 768, %.state802
  %tile_snapshot.spill.load803 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1759 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load803, 0
  %1760 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load803, 1
  %.splatinsert804 = insertelement <8 x i64> poison, i64 %1758, i64 0
  %.splat805 = shufflevector <8 x i64> %.splatinsert804, <8 x i64> poison, <8 x i32> zeroinitializer
  %1761 = mul <8 x i64> %.splat805, splat (i64 32)
  %1762 = add <8 x i64> %1760, %1761
  %1763 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1759, 0
  %1764 = insertvalue { <8 x ptr>, <8 x i64> } %1763, <8 x i64> %1762, 1
  %1765 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1766 = extractvalue { <8 x ptr>, <8 x i64> } %1764, 1
  %1767 = extractelement <8 x ptr> %1765, i32 0
  %1768 = extractelement <8 x i64> %1766, i32 0
  %1769 = sub i64 %1768, 0
  %1770 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1771 = select i1 %1770, i64 %1769, i64 0
  %private.contiguous.address806 = getelementptr i8, ptr %1767, i64 %1771
  %private.contiguous.load807 = load <8 x float>, ptr %private.contiguous.address806, align 4
  %1772 = select <8 x i1> %71, <8 x float> %private.contiguous.load807, <8 x float> zeroinitializer
  %.spill.load808 = load <8 x float>, ptr %.spill125, align 32
  %1773 = fmul <8 x float> %.spill.load808, %1772
  %1774 = fadd <8 x float> %1757, %1773
  %.state809 = load i64, ptr %.slot139, align 4
  %1775 = add i64 864, %.state809
  %tile_snapshot.spill.load810 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1776 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load810, 0
  %1777 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load810, 1
  %.splatinsert811 = insertelement <8 x i64> poison, i64 %1775, i64 0
  %.splat812 = shufflevector <8 x i64> %.splatinsert811, <8 x i64> poison, <8 x i32> zeroinitializer
  %1778 = mul <8 x i64> %.splat812, splat (i64 32)
  %1779 = add <8 x i64> %1777, %1778
  %1780 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1776, 0
  %1781 = insertvalue { <8 x ptr>, <8 x i64> } %1780, <8 x i64> %1779, 1
  %1782 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1783 = extractvalue { <8 x ptr>, <8 x i64> } %1781, 1
  %1784 = extractelement <8 x ptr> %1782, i32 0
  %1785 = extractelement <8 x i64> %1783, i32 0
  %1786 = sub i64 %1785, 0
  %1787 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1788 = select i1 %1787, i64 %1786, i64 0
  %private.contiguous.address813 = getelementptr i8, ptr %1784, i64 %1788
  %private.contiguous.load814 = load <8 x float>, ptr %private.contiguous.address813, align 4
  %1789 = select <8 x i1> %71, <8 x float> %private.contiguous.load814, <8 x float> zeroinitializer
  %.spill.load815 = load <8 x float>, ptr %.spill126, align 32
  %1790 = fmul <8 x float> %.spill.load815, %1789
  %1791 = fadd <8 x float> %1774, %1790
  %.state816 = load i64, ptr %.slot139, align 4
  %1792 = add i64 960, %.state816
  %tile_snapshot.spill.load817 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1793 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load817, 0
  %1794 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load817, 1
  %.splatinsert818 = insertelement <8 x i64> poison, i64 %1792, i64 0
  %.splat819 = shufflevector <8 x i64> %.splatinsert818, <8 x i64> poison, <8 x i32> zeroinitializer
  %1795 = mul <8 x i64> %.splat819, splat (i64 32)
  %1796 = add <8 x i64> %1794, %1795
  %1797 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1793, 0
  %1798 = insertvalue { <8 x ptr>, <8 x i64> } %1797, <8 x i64> %1796, 1
  %1799 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1800 = extractvalue { <8 x ptr>, <8 x i64> } %1798, 1
  %1801 = extractelement <8 x ptr> %1799, i32 0
  %1802 = extractelement <8 x i64> %1800, i32 0
  %1803 = sub i64 %1802, 0
  %1804 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1805 = select i1 %1804, i64 %1803, i64 0
  %private.contiguous.address820 = getelementptr i8, ptr %1801, i64 %1805
  %private.contiguous.load821 = load <8 x float>, ptr %private.contiguous.address820, align 4
  %1806 = select <8 x i1> %71, <8 x float> %private.contiguous.load821, <8 x float> zeroinitializer
  %.spill.load822 = load <8 x float>, ptr %.spill127, align 32
  %1807 = fmul <8 x float> %.spill.load822, %1806
  %1808 = fadd <8 x float> %1791, %1807
  %.state823 = load i64, ptr %.slot139, align 4
  %1809 = add i64 1056, %.state823
  %tile_snapshot.spill.load824 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1810 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load824, 0
  %1811 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load824, 1
  %.splatinsert825 = insertelement <8 x i64> poison, i64 %1809, i64 0
  %.splat826 = shufflevector <8 x i64> %.splatinsert825, <8 x i64> poison, <8 x i32> zeroinitializer
  %1812 = mul <8 x i64> %.splat826, splat (i64 32)
  %1813 = add <8 x i64> %1811, %1812
  %1814 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1810, 0
  %1815 = insertvalue { <8 x ptr>, <8 x i64> } %1814, <8 x i64> %1813, 1
  %1816 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1817 = extractvalue { <8 x ptr>, <8 x i64> } %1815, 1
  %1818 = extractelement <8 x ptr> %1816, i32 0
  %1819 = extractelement <8 x i64> %1817, i32 0
  %1820 = sub i64 %1819, 0
  %1821 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1822 = select i1 %1821, i64 %1820, i64 0
  %private.contiguous.address827 = getelementptr i8, ptr %1818, i64 %1822
  %private.contiguous.load828 = load <8 x float>, ptr %private.contiguous.address827, align 4
  %1823 = select <8 x i1> %71, <8 x float> %private.contiguous.load828, <8 x float> zeroinitializer
  %.spill.load829 = load <8 x float>, ptr %.spill128, align 32
  %1824 = fmul <8 x float> %.spill.load829, %1823
  %1825 = fadd <8 x float> %1808, %1824
  %.state830 = load i64, ptr %.slot139, align 4
  %1826 = add i64 1152, %.state830
  %tile_snapshot.spill.load831 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1827 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load831, 0
  %1828 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load831, 1
  %.splatinsert832 = insertelement <8 x i64> poison, i64 %1826, i64 0
  %.splat833 = shufflevector <8 x i64> %.splatinsert832, <8 x i64> poison, <8 x i32> zeroinitializer
  %1829 = mul <8 x i64> %.splat833, splat (i64 32)
  %1830 = add <8 x i64> %1828, %1829
  %1831 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1827, 0
  %1832 = insertvalue { <8 x ptr>, <8 x i64> } %1831, <8 x i64> %1830, 1
  %1833 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1834 = extractvalue { <8 x ptr>, <8 x i64> } %1832, 1
  %1835 = extractelement <8 x ptr> %1833, i32 0
  %1836 = extractelement <8 x i64> %1834, i32 0
  %1837 = sub i64 %1836, 0
  %1838 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1839 = select i1 %1838, i64 %1837, i64 0
  %private.contiguous.address834 = getelementptr i8, ptr %1835, i64 %1839
  %private.contiguous.load835 = load <8 x float>, ptr %private.contiguous.address834, align 4
  %1840 = select <8 x i1> %71, <8 x float> %private.contiguous.load835, <8 x float> zeroinitializer
  %.spill.load836 = load <8 x float>, ptr %.spill129, align 32
  %1841 = fmul <8 x float> %.spill.load836, %1840
  %1842 = fadd <8 x float> %1825, %1841
  %.state837 = load i64, ptr %.slot139, align 4
  %1843 = add i64 1248, %.state837
  %tile_snapshot.spill.load838 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1844 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load838, 0
  %1845 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load838, 1
  %.splatinsert839 = insertelement <8 x i64> poison, i64 %1843, i64 0
  %.splat840 = shufflevector <8 x i64> %.splatinsert839, <8 x i64> poison, <8 x i32> zeroinitializer
  %1846 = mul <8 x i64> %.splat840, splat (i64 32)
  %1847 = add <8 x i64> %1845, %1846
  %1848 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1844, 0
  %1849 = insertvalue { <8 x ptr>, <8 x i64> } %1848, <8 x i64> %1847, 1
  %1850 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1851 = extractvalue { <8 x ptr>, <8 x i64> } %1849, 1
  %1852 = extractelement <8 x ptr> %1850, i32 0
  %1853 = extractelement <8 x i64> %1851, i32 0
  %1854 = sub i64 %1853, 0
  %1855 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1856 = select i1 %1855, i64 %1854, i64 0
  %private.contiguous.address841 = getelementptr i8, ptr %1852, i64 %1856
  %private.contiguous.load842 = load <8 x float>, ptr %private.contiguous.address841, align 4
  %1857 = select <8 x i1> %71, <8 x float> %private.contiguous.load842, <8 x float> zeroinitializer
  %.spill.load843 = load <8 x float>, ptr %.spill130, align 32
  %1858 = fmul <8 x float> %.spill.load843, %1857
  %1859 = fadd <8 x float> %1842, %1858
  %.state844 = load i64, ptr %.slot139, align 4
  %1860 = add i64 1344, %.state844
  %tile_snapshot.spill.load845 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1861 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load845, 0
  %1862 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load845, 1
  %.splatinsert846 = insertelement <8 x i64> poison, i64 %1860, i64 0
  %.splat847 = shufflevector <8 x i64> %.splatinsert846, <8 x i64> poison, <8 x i32> zeroinitializer
  %1863 = mul <8 x i64> %.splat847, splat (i64 32)
  %1864 = add <8 x i64> %1862, %1863
  %1865 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1861, 0
  %1866 = insertvalue { <8 x ptr>, <8 x i64> } %1865, <8 x i64> %1864, 1
  %1867 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1868 = extractvalue { <8 x ptr>, <8 x i64> } %1866, 1
  %1869 = extractelement <8 x ptr> %1867, i32 0
  %1870 = extractelement <8 x i64> %1868, i32 0
  %1871 = sub i64 %1870, 0
  %1872 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1873 = select i1 %1872, i64 %1871, i64 0
  %private.contiguous.address848 = getelementptr i8, ptr %1869, i64 %1873
  %private.contiguous.load849 = load <8 x float>, ptr %private.contiguous.address848, align 4
  %1874 = select <8 x i1> %71, <8 x float> %private.contiguous.load849, <8 x float> zeroinitializer
  %.spill.load850 = load <8 x float>, ptr %.spill131, align 32
  %1875 = fmul <8 x float> %.spill.load850, %1874
  %1876 = fadd <8 x float> %1859, %1875
  %.state851 = load i64, ptr %.slot139, align 4
  %1877 = add i64 1440, %.state851
  %tile_snapshot.spill.load852 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1878 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load852, 0
  %1879 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load852, 1
  %.splatinsert853 = insertelement <8 x i64> poison, i64 %1877, i64 0
  %.splat854 = shufflevector <8 x i64> %.splatinsert853, <8 x i64> poison, <8 x i32> zeroinitializer
  %1880 = mul <8 x i64> %.splat854, splat (i64 32)
  %1881 = add <8 x i64> %1879, %1880
  %1882 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1878, 0
  %1883 = insertvalue { <8 x ptr>, <8 x i64> } %1882, <8 x i64> %1881, 1
  %1884 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1885 = extractvalue { <8 x ptr>, <8 x i64> } %1883, 1
  %1886 = extractelement <8 x ptr> %1884, i32 0
  %1887 = extractelement <8 x i64> %1885, i32 0
  %1888 = sub i64 %1887, 0
  %1889 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1890 = select i1 %1889, i64 %1888, i64 0
  %private.contiguous.address855 = getelementptr i8, ptr %1886, i64 %1890
  %private.contiguous.load856 = load <8 x float>, ptr %private.contiguous.address855, align 4
  %1891 = select <8 x i1> %71, <8 x float> %private.contiguous.load856, <8 x float> zeroinitializer
  %.spill.load857 = load <8 x float>, ptr %.spill132, align 32
  %1892 = fmul <8 x float> %.spill.load857, %1891
  %1893 = fadd <8 x float> %1876, %1892
  %tile_snapshot.spill.load858 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill138, align 64
  %1894 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load858, 0
  %1895 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load858, 1
  %.state859 = load i64, ptr %.slot139, align 4
  %.splatinsert860 = insertelement <8 x i64> poison, i64 %.state859, i64 0
  %.splat861 = shufflevector <8 x i64> %.splatinsert860, <8 x i64> poison, <8 x i32> zeroinitializer
  %1896 = mul <8 x i64> %.splat861, splat (i64 32)
  %1897 = add <8 x i64> %1895, %1896
  %1898 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1894, 0
  %1899 = insertvalue { <8 x ptr>, <8 x i64> } %1898, <8 x i64> %1897, 1
  %1900 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1901 = extractvalue { <8 x ptr>, <8 x i64> } %1899, 1
  %1902 = extractelement <8 x ptr> %1900, i32 0
  %1903 = extractelement <8 x i64> %1901, i32 0
  %1904 = sub i64 %1903, 0
  %1905 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1906 = select i1 %1905, i64 %1904, i64 0
  %private.contiguous.address862 = getelementptr i8, ptr %1902, i64 %1906
  %private.contiguous.preserve863 = load <8 x float>, ptr %private.contiguous.address862, align 4
  %1907 = select <8 x i1> %71, <8 x float> %1893, <8 x float> %private.contiguous.preserve863
  store <8 x float> %1907, ptr %private.contiguous.address862, align 4
  %.state864 = load i64, ptr %.slot139, align 4
  %1908 = add i64 %.state864, 1
  store i64 %1908, ptr %.slot139, align 4
  br label %direct.schedule.73

direct.schedule.75:                               ; preds = %direct.false739
  store i64 0, ptr %.slot140, align 4
  br label %direct.schedule.76

direct.schedule.76:                               ; preds = %direct.schedule.77, %direct.schedule.75
  %.state865 = load i64, ptr %.slot140, align 4
  %1909 = icmp slt i64 %.state865, 96
  br i1 %1909, label %direct.true866, label %direct.false867

direct.schedule.77:                               ; preds = %direct.true866
  %tile_snapshot.spill.load868 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill138, align 64
  %1910 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load868, 0
  %1911 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load868, 1
  %.state869 = load i64, ptr %.slot140, align 4
  %.splatinsert870 = insertelement <8 x i64> poison, i64 %.state869, i64 0
  %.splat871 = shufflevector <8 x i64> %.splatinsert870, <8 x i64> poison, <8 x i32> zeroinitializer
  %1912 = mul <8 x i64> %.splat871, splat (i64 32)
  %1913 = add <8 x i64> %1911, %1912
  %1914 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1910, 0
  %1915 = insertvalue { <8 x ptr>, <8 x i64> } %1914, <8 x i64> %1913, 1
  %1916 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1917 = extractvalue { <8 x ptr>, <8 x i64> } %1915, 1
  %1918 = extractelement <8 x ptr> %1916, i32 0
  %1919 = extractelement <8 x i64> %1917, i32 0
  %1920 = sub i64 %1919, 0
  %1921 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1922 = select i1 %1921, i64 %1920, i64 0
  %private.contiguous.address872 = getelementptr i8, ptr %1918, i64 %1922
  %private.contiguous.load873 = load <8 x float>, ptr %private.contiguous.address872, align 4
  %1923 = select <8 x i1> %71, <8 x float> %private.contiguous.load873, <8 x float> zeroinitializer
  %tile_snapshot.spill.load874 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill33, align 64
  %1924 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load874, 0
  %1925 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load874, 1
  %.state875 = load i64, ptr %.slot140, align 4
  %.splatinsert876 = insertelement <8 x i64> poison, i64 %.state875, i64 0
  %.splat877 = shufflevector <8 x i64> %.splatinsert876, <8 x i64> poison, <8 x i32> zeroinitializer
  %1926 = mul <8 x i64> %.splat877, splat (i64 32)
  %1927 = add <8 x i64> %1925, %1926
  %1928 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1924, 0
  %1929 = insertvalue { <8 x ptr>, <8 x i64> } %1928, <8 x i64> %1927, 1
  %1930 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1931 = extractvalue { <8 x ptr>, <8 x i64> } %1929, 1
  %1932 = extractelement <8 x ptr> %1930, i32 0
  %1933 = extractelement <8 x i64> %1931, i32 0
  %1934 = sub i64 %1933, 0
  %1935 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1936 = select i1 %1935, i64 %1934, i64 0
  %private.contiguous.address878 = getelementptr i8, ptr %1932, i64 %1936
  %private.contiguous.preserve879 = load <8 x float>, ptr %private.contiguous.address878, align 4
  %1937 = select <8 x i1> %71, <8 x float> %1923, <8 x float> %private.contiguous.preserve879
  store <8 x float> %1937, ptr %private.contiguous.address878, align 4
  %.state880 = load i64, ptr %.slot140, align 4
  %1938 = add i64 %.state880, 1
  store i64 %1938, ptr %.slot140, align 4
  br label %direct.schedule.76

direct.schedule.78:                               ; preds = %direct.false867
  store i64 0, ptr %.slot141, align 4
  br label %direct.schedule.79

direct.schedule.79:                               ; preds = %direct.schedule.80, %direct.schedule.78
  %.state881 = load i64, ptr %.slot141, align 4
  %1939 = icmp slt i64 %.state881, 96
  br i1 %1939, label %direct.true882, label %direct.false883

direct.schedule.80:                               ; preds = %direct.true882
  %tile_snapshot.spill.load884 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill33, align 64
  %1940 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load884, 0
  %1941 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load884, 1
  %.state885 = load i64, ptr %.slot141, align 4
  %.splatinsert886 = insertelement <8 x i64> poison, i64 %.state885, i64 0
  %.splat887 = shufflevector <8 x i64> %.splatinsert886, <8 x i64> poison, <8 x i32> zeroinitializer
  %1942 = mul <8 x i64> %.splat887, splat (i64 32)
  %1943 = add <8 x i64> %1941, %1942
  %1944 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1940, 0
  %1945 = insertvalue { <8 x ptr>, <8 x i64> } %1944, <8 x i64> %1943, 1
  %1946 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1947 = extractvalue { <8 x ptr>, <8 x i64> } %1945, 1
  %1948 = extractelement <8 x ptr> %1946, i32 0
  %1949 = extractelement <8 x i64> %1947, i32 0
  %1950 = sub i64 %1949, 0
  %1951 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1952 = select i1 %1951, i64 %1950, i64 0
  %private.contiguous.address888 = getelementptr i8, ptr %1948, i64 %1952
  %private.contiguous.load889 = load <8 x float>, ptr %private.contiguous.address888, align 4
  %1953 = select <8 x i1> %71, <8 x float> %private.contiguous.load889, <8 x float> zeroinitializer
  %tile_snapshot.spill.load890 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1954 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load890, 0
  %1955 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load890, 1
  %.state891 = load i64, ptr %.slot141, align 4
  %.splatinsert892 = insertelement <8 x i64> poison, i64 %.state891, i64 0
  %.splat893 = shufflevector <8 x i64> %.splatinsert892, <8 x i64> poison, <8 x i32> zeroinitializer
  %1956 = mul <8 x i64> %.splat893, splat (i64 32)
  %1957 = add <8 x i64> %1955, %1956
  %1958 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1954, 0
  %1959 = insertvalue { <8 x ptr>, <8 x i64> } %1958, <8 x i64> %1957, 1
  %1960 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1961 = extractvalue { <8 x ptr>, <8 x i64> } %1959, 1
  %1962 = extractelement <8 x ptr> %1960, i32 0
  %1963 = extractelement <8 x i64> %1961, i32 0
  %1964 = sub i64 %1963, 0
  %1965 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1966 = select i1 %1965, i64 %1964, i64 0
  %private.contiguous.address894 = getelementptr i8, ptr %1962, i64 %1966
  %private.contiguous.preserve895 = load <8 x float>, ptr %private.contiguous.address894, align 4
  %1967 = select <8 x i1> %71, <8 x float> %1953, <8 x float> %private.contiguous.preserve895
  store <8 x float> %1967, ptr %private.contiguous.address894, align 4
  %.state896 = load i64, ptr %.slot141, align 4
  %1968 = add i64 %.state896, 1
  store i64 %1968, ptr %.slot141, align 4
  br label %direct.schedule.79

direct.schedule.81:                               ; preds = %direct.false883
  %.state897 = load i64, ptr %.slot35, align 4
  %1969 = add i64 %.state897, 1
  %.spill.load898 = load <8 x float>, ptr %.spill115, align 32
  %.spill.load899 = load <8 x float>, ptr %.spill137, align 32
  store i64 %1969, ptr %.slot35, align 4
  %1970 = load <8 x float>, ptr %.slot36, align 32
  %1971 = select <8 x i1> %71, <8 x float> %.spill.load898, <8 x float> %1970
  store <8 x float> %1971, ptr %.slot36, align 32
  %1972 = load <8 x float>, ptr %.slot37, align 32
  %1973 = select <8 x i1> %71, <8 x float> %.spill.load899, <8 x float> %1972
  store <8 x float> %1973, ptr %.slot37, align 32
  br label %direct.schedule.7

direct.schedule.82:                               ; preds = %direct.false176
  store i64 0, ptr %.slot142, align 4
  br label %direct.schedule.83

direct.schedule.83:                               ; preds = %direct.schedule.84, %direct.schedule.82
  %.state900 = load i64, ptr %.slot142, align 4
  %1974 = icmp slt i64 %.state900, 96
  br i1 %1974, label %direct.true901, label %direct.false902

direct.schedule.84:                               ; preds = %direct.true901
  %.spill.load903 = load <8 x i64>, ptr %.spill, align 64
  %1975 = add <8 x i64> %.spill.load903, zeroinitializer
  %1976 = add <8 x i64> zeroinitializer, %1975
  %.spill.load904 = load <8 x i64>, ptr %.spill29, align 64
  %1977 = add <8 x i64> %.spill.load904, zeroinitializer
  %1978 = mul <8 x i64> %1976, splat (i64 8)
  %1979 = add <8 x i64> %1978, %1977
  %.spill.load905 = load i64, ptr %.spill30, align 4
  %1980 = add i64 %.spill.load905, 0
  %1981 = mul <8 x i64> %1979, splat (i64 1)
  %.splatinsert906 = insertelement <8 x i64> poison, i64 %1980, i64 0
  %.splat907 = shufflevector <8 x i64> %.splatinsert906, <8 x i64> poison, <8 x i32> zeroinitializer
  %1982 = add <8 x i64> %1981, %.splat907
  %.state908 = load i64, ptr %.slot142, align 4
  %1983 = add i64 0, %.state908
  %1984 = mul <8 x i64> %1982, splat (i64 96)
  %.splatinsert909 = insertelement <8 x i64> poison, i64 %1983, i64 0
  %.splat910 = shufflevector <8 x i64> %.splatinsert909, <8 x i64> poison, <8 x i32> zeroinitializer
  %1985 = add <8 x i64> %1984, %.splat910
  %.state911 = load i64, ptr %.slot142, align 4
  %1986 = add i64 0, %.state911
  %tile_snapshot.spill.load912 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1987 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load912, 0
  %1988 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load912, 1
  %.splatinsert913 = insertelement <8 x i64> poison, i64 %1986, i64 0
  %.splat914 = shufflevector <8 x i64> %.splatinsert913, <8 x i64> poison, <8 x i32> zeroinitializer
  %1989 = mul <8 x i64> %.splat914, splat (i64 32)
  %1990 = add <8 x i64> %1988, %1989
  %1991 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1987, 0
  %1992 = insertvalue { <8 x ptr>, <8 x i64> } %1991, <8 x i64> %1990, 1
  %1993 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1994 = extractvalue { <8 x ptr>, <8 x i64> } %1992, 1
  %1995 = extractelement <8 x ptr> %1993, i32 0
  %1996 = extractelement <8 x i64> %1994, i32 0
  %1997 = sub i64 %1996, 0
  %1998 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1999 = select i1 %1998, i64 %1997, i64 0
  %private.contiguous.address915 = getelementptr i8, ptr %1995, i64 %1999
  %private.contiguous.load916 = load <8 x float>, ptr %private.contiguous.address915, align 4
  %2000 = select <8 x i1> %71, <8 x float> %private.contiguous.load916, <8 x float> zeroinitializer
  %.state917 = load <8 x float>, ptr %.slot37, align 32
  %2001 = fdiv <8 x float> %2000, %.state917
  %2002 = extractvalue { ptr, i64 } %47, 0
  %2003 = mul <8 x i64> %1985, splat (i64 4)
  %2004 = getelementptr i8, ptr %2002, <8 x i64> %2003
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %2001, <8 x ptr> align 1 %2004, <8 x i1> %71)
  %.state918 = load i64, ptr %.slot142, align 4
  %2005 = add i64 %.state918, 1
  store i64 %2005, ptr %.slot142, align 4
  br label %direct.schedule.83

direct.schedule.85:                               ; preds = %direct.false902
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true165:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false166:                                  ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true175:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false176:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.82

direct.true179:                                   ; preds = %direct.schedule.9
  br label %direct.schedule.10

direct.false180:                                  ; preds = %direct.schedule.9
  br label %direct.schedule.13

direct.true190:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false191:                                  ; preds = %direct.schedule.10
  %2006 = load <8 x float>, ptr %.slot42, align 32
  %2007 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %2006
  store <8 x float> %2007, ptr %.slot42, align 32
  br label %direct.schedule.12

direct.true204:                                   ; preds = %direct.schedule.14
  br label %direct.schedule.15

direct.false205:                                  ; preds = %direct.schedule.14
  br label %direct.schedule.18

direct.true215:                                   ; preds = %direct.schedule.15
  br label %direct.schedule.16

direct.false216:                                  ; preds = %direct.schedule.15
  %2008 = load <8 x float>, ptr %.slot46, align 32
  %2009 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %2008
  store <8 x float> %2009, ptr %.slot46, align 32
  br label %direct.schedule.17

direct.true229:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false230:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true244:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false245:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24

direct.true261:                                   ; preds = %direct.schedule.25
  br label %direct.schedule.26

direct.false262:                                  ; preds = %direct.schedule.25
  br label %direct.schedule.27

direct.true278:                                   ; preds = %direct.schedule.28
  br label %direct.schedule.29

direct.false279:                                  ; preds = %direct.schedule.28
  br label %direct.schedule.30

direct.true295:                                   ; preds = %direct.schedule.31
  br label %direct.schedule.32

direct.false296:                                  ; preds = %direct.schedule.31
  br label %direct.schedule.33

direct.true312:                                   ; preds = %direct.schedule.34
  br label %direct.schedule.35

direct.false313:                                  ; preds = %direct.schedule.34
  br label %direct.schedule.36

direct.true329:                                   ; preds = %direct.schedule.37
  br label %direct.schedule.38

direct.false330:                                  ; preds = %direct.schedule.37
  br label %direct.schedule.39

direct.true346:                                   ; preds = %direct.schedule.40
  br label %direct.schedule.41

direct.false347:                                  ; preds = %direct.schedule.40
  br label %direct.schedule.42

direct.true363:                                   ; preds = %direct.schedule.43
  br label %direct.schedule.44

direct.false364:                                  ; preds = %direct.schedule.43
  br label %direct.schedule.45

direct.true380:                                   ; preds = %direct.schedule.46
  br label %direct.schedule.47

direct.false381:                                  ; preds = %direct.schedule.46
  br label %direct.schedule.48

direct.true397:                                   ; preds = %direct.schedule.49
  br label %direct.schedule.50

direct.false398:                                  ; preds = %direct.schedule.49
  br label %direct.schedule.51

direct.true414:                                   ; preds = %direct.schedule.52
  br label %direct.schedule.53

direct.false415:                                  ; preds = %direct.schedule.52
  br label %direct.schedule.54

direct.true431:                                   ; preds = %direct.schedule.55
  br label %direct.schedule.56

direct.false432:                                  ; preds = %direct.schedule.55
  br label %direct.schedule.57

direct.true448:                                   ; preds = %direct.schedule.58
  br label %direct.schedule.59

direct.false449:                                  ; preds = %direct.schedule.58
  br label %direct.schedule.60

direct.true465:                                   ; preds = %direct.schedule.61
  br label %direct.schedule.62

direct.false466:                                  ; preds = %direct.schedule.61
  br label %direct.schedule.63

direct.true482:                                   ; preds = %direct.schedule.64
  br label %direct.schedule.65

direct.false483:                                  ; preds = %direct.schedule.64
  br label %direct.schedule.66

direct.true596:                                   ; preds = %direct.schedule.67
  br label %direct.schedule.68

direct.false597:                                  ; preds = %direct.schedule.67
  br label %direct.schedule.69

direct.true724:                                   ; preds = %direct.schedule.70
  br label %direct.schedule.71

direct.false725:                                  ; preds = %direct.schedule.70
  br label %direct.schedule.72

direct.true738:                                   ; preds = %direct.schedule.73
  br label %direct.schedule.74

direct.false739:                                  ; preds = %direct.schedule.73
  br label %direct.schedule.75

direct.true866:                                   ; preds = %direct.schedule.76
  br label %direct.schedule.77

direct.false867:                                  ; preds = %direct.schedule.76
  br label %direct.schedule.78

direct.true882:                                   ; preds = %direct.schedule.79
  br label %direct.schedule.80

direct.false883:                                  ; preds = %direct.schedule.79
  br label %direct.schedule.81

direct.true901:                                   ; preds = %direct.schedule.83
  br label %direct.schedule.84

direct.false902:                                  ; preds = %direct.schedule.83
  br label %direct.schedule.85
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #2

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #3 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #4

define internal void @llm_attention.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 2560
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 5632
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 8704
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 49664
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 98816
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 99328
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 99840
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill29 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill29, align 64
  %.spill30 = alloca i64, align 8
  store i64 0, ptr %.spill30, align 4
  %.spill31 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill31, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill32 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill32, align 64
  %tile_snapshot.spill33 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill33, align 64
  %.slot34 = alloca i64, align 8
  store i64 0, ptr %.slot34, align 4
  %.slot35 = alloca i64, align 8
  store i64 0, ptr %.slot35, align 4
  %.slot36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot36, align 32
  %.slot37 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot37, align 32
  %.spill38 = alloca i64, align 8
  store i64 0, ptr %.spill38, align 4
  %tile_snapshot.spill39 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill39, align 64
  %.slot40 = alloca i64, align 8
  store i64 0, ptr %.slot40, align 4
  %.spill41 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill41, align 64
  %.slot42 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot42, align 32
  %tile_snapshot.spill43 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill43, align 64
  %.slot44 = alloca i64, align 8
  store i64 0, ptr %.slot44, align 4
  %.spill45 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill45, align 64
  %.slot46 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot46, align 32
  %.slot47 = alloca i64, align 8
  store i64 0, ptr %.slot47, align 4
  %.slot48 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot48, align 32
  %.slot49 = alloca i64, align 8
  store i64 0, ptr %.slot49, align 4
  %.slot50 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot50, align 32
  %.slot51 = alloca i64, align 8
  store i64 0, ptr %.slot51, align 4
  %.slot52 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot52, align 32
  %.slot53 = alloca i64, align 8
  store i64 0, ptr %.slot53, align 4
  %.slot54 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot54, align 32
  %.slot55 = alloca i64, align 8
  store i64 0, ptr %.slot55, align 4
  %.slot56 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot56, align 32
  %.slot57 = alloca i64, align 8
  store i64 0, ptr %.slot57, align 4
  %.slot58 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot58, align 32
  %.slot59 = alloca i64, align 8
  store i64 0, ptr %.slot59, align 4
  %.slot60 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot60, align 32
  %.slot61 = alloca i64, align 8
  store i64 0, ptr %.slot61, align 4
  %.slot62 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot62, align 32
  %.slot63 = alloca i64, align 8
  store i64 0, ptr %.slot63, align 4
  %.slot64 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot64, align 32
  %.slot65 = alloca i64, align 8
  store i64 0, ptr %.slot65, align 4
  %.slot66 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot66, align 32
  %.slot67 = alloca i64, align 8
  store i64 0, ptr %.slot67, align 4
  %.slot68 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot68, align 32
  %.slot69 = alloca i64, align 8
  store i64 0, ptr %.slot69, align 4
  %.slot70 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot70, align 32
  %.slot71 = alloca i64, align 8
  store i64 0, ptr %.slot71, align 4
  %.slot72 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot72, align 32
  %.slot73 = alloca i64, align 8
  store i64 0, ptr %.slot73, align 4
  %.slot74 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot74, align 32
  %.slot75 = alloca i64, align 8
  store i64 0, ptr %.slot75, align 4
  %.slot76 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot76, align 32
  %.slot77 = alloca i64, align 8
  store i64 0, ptr %.slot77, align 4
  %.slot78 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot78, align 32
  %.spill79 = alloca i64, align 8
  store i64 0, ptr %.spill79, align 4
  %.spill80 = alloca i1, align 1
  store i1 false, ptr %.spill80, align 1
  %.spill81 = alloca i1, align 1
  store i1 false, ptr %.spill81, align 1
  %.spill82 = alloca i1, align 1
  store i1 false, ptr %.spill82, align 1
  %.spill83 = alloca i1, align 1
  store i1 false, ptr %.spill83, align 1
  %.spill84 = alloca i1, align 1
  store i1 false, ptr %.spill84, align 1
  %.spill85 = alloca i1, align 1
  store i1 false, ptr %.spill85, align 1
  %.spill86 = alloca i1, align 1
  store i1 false, ptr %.spill86, align 1
  %.spill87 = alloca i1, align 1
  store i1 false, ptr %.spill87, align 1
  %.spill88 = alloca i1, align 1
  store i1 false, ptr %.spill88, align 1
  %.spill89 = alloca i1, align 1
  store i1 false, ptr %.spill89, align 1
  %.spill90 = alloca i1, align 1
  store i1 false, ptr %.spill90, align 1
  %.spill91 = alloca i1, align 1
  store i1 false, ptr %.spill91, align 1
  %.spill92 = alloca i1, align 1
  store i1 false, ptr %.spill92, align 1
  %.spill93 = alloca i1, align 1
  store i1 false, ptr %.spill93, align 1
  %.spill94 = alloca i1, align 1
  store i1 false, ptr %.spill94, align 1
  %.spill95 = alloca i1, align 1
  store i1 false, ptr %.spill95, align 1
  %.spill96 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill96, align 32
  %.spill97 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill97, align 32
  %.spill98 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill98, align 32
  %.spill99 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill99, align 32
  %.spill100 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill100, align 32
  %.spill101 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill101, align 32
  %.spill102 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill102, align 32
  %.spill103 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill103, align 32
  %.spill104 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill104, align 32
  %.spill105 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill105, align 32
  %.spill106 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill106, align 32
  %.spill107 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill107, align 32
  %.spill108 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill108, align 32
  %.spill109 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill109, align 32
  %.spill110 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill110, align 32
  %.spill111 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill111, align 32
  %tile_snapshot.spill112 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill112, align 64
  %.slot113 = alloca i64, align 8
  store i64 0, ptr %.slot113, align 4
  %.slot114 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot114, align 32
  %.spill115 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill115, align 32
  %.spill116 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill116, align 32
  %.spill117 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill117, align 32
  %.spill118 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill118, align 32
  %.spill119 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill119, align 32
  %.spill120 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill120, align 32
  %.spill121 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill121, align 32
  %.spill122 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill122, align 32
  %.spill123 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill123, align 32
  %.spill124 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill124, align 32
  %.spill125 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill125, align 32
  %.spill126 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill126, align 32
  %.spill127 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill127, align 32
  %.spill128 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill128, align 32
  %.spill129 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill129, align 32
  %.spill130 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill130, align 32
  %.spill131 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill131, align 32
  %.spill132 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill132, align 32
  %tile_snapshot.spill133 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill133, align 64
  %.spill134 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill134, align 32
  %.slot135 = alloca i64, align 8
  store i64 0, ptr %.slot135, align 4
  %.slot136 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot136, align 32
  %.spill137 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill137, align 32
  %tile_snapshot.spill138 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill138, align 64
  %.slot139 = alloca i64, align 8
  store i64 0, ptr %.slot139, align 4
  %.slot140 = alloca i64, align 8
  store i64 0, ptr %.slot140, align 4
  %.slot141 = alloca i64, align 8
  store i64 0, ptr %.slot141, align 4
  %.slot142 = alloca i64, align 8
  store i64 0, ptr %.slot142, align 4
  %24 = getelementptr i8, ptr %argument_buffer, i64 0
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = getelementptr i8, ptr %argument_buffer, i64 16
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %30, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %33, 1
  %36 = getelementptr i8, ptr %argument_buffer, i64 32
  %37 = load ptr, ptr %36, align 16
  %38 = getelementptr i8, ptr %36, i64 8
  %39 = load i64, ptr %38, align 8
  %40 = insertvalue { ptr, i64 } poison, ptr %37, 0
  %41 = insertvalue { ptr, i64 } %40, i64 %39, 1
  %42 = getelementptr i8, ptr %argument_buffer, i64 48
  %43 = load ptr, ptr %42, align 16
  %44 = getelementptr i8, ptr %42, i64 8
  %45 = load i64, ptr %44, align 8
  %46 = insertvalue { ptr, i64 } poison, ptr %43, 0
  %47 = insertvalue { ptr, i64 } %46, i64 %45, 1
  %48 = load i32, ptr %launch_config, align 4
  %49 = getelementptr i8, ptr %launch_config, i64 12
  %50 = load i32, ptr %49, align 4
  %51 = getelementptr i8, ptr %launch_config, i64 4
  %52 = load i32, ptr %51, align 4
  %53 = getelementptr i8, ptr %launch_config, i64 16
  %54 = load i32, ptr %53, align 4
  %55 = getelementptr i8, ptr %launch_config, i64 8
  %56 = load i32, ptr %55, align 4
  %57 = getelementptr i8, ptr %launch_config, i64 20
  %58 = load i32, ptr %57, align 4
  %59 = getelementptr i8, ptr %launch_config, i64 36
  %60 = load i32, ptr %59, align 4
  %.splatinsert143 = insertelement <8 x i32> poison, i32 %60, i64 0
  %.splat144 = shufflevector <8 x i32> %.splatinsert143, <8 x i32> poison, <8 x i32> zeroinitializer
  %61 = add <8 x i32> %.splat144, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %62 = mul i32 %48, 32
  %.splatinsert145 = insertelement <8 x i32> poison, i32 %62, i64 0
  %.splat146 = shufflevector <8 x i32> %.splatinsert145, <8 x i32> poison, <8 x i32> zeroinitializer
  %63 = add <8 x i32> %.splat146, %61
  %64 = mul i32 %52, 1
  %.splatinsert147 = insertelement <8 x i32> poison, i32 %64, i64 0
  %.splat148 = shufflevector <8 x i32> %.splatinsert147, <8 x i32> poison, <8 x i32> zeroinitializer
  %65 = add <8 x i32> %.splat148, zeroinitializer
  %66 = mul i32 %56, 1
  %.splatinsert149 = insertelement <8 x i32> poison, i32 %66, i64 0
  %.splat150 = shufflevector <8 x i32> %.splatinsert149, <8 x i32> poison, <8 x i32> zeroinitializer
  %67 = add <8 x i32> %.splat150, zeroinitializer
  %68 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %63, 0
  %69 = insertvalue [3 x <8 x i32>] %68, <8 x i32> %65, 1
  %70 = insertvalue [3 x <8 x i32>] %69, <8 x i32> %67, 2
  %.splatinsert151 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat152 = shufflevector <8 x i32> %.splatinsert151, <8 x i32> poison, <8 x i32> zeroinitializer
  %71 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat152
  %72 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  br i1 %72, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %73 = extractvalue [3 x <8 x i32>] %70, 0
  %74 = zext <8 x i32> %73 to <8 x i64>
  %75 = select <8 x i1> %71, <8 x i64> %74, <8 x i64> zeroinitializer
  %76 = select <8 x i1> %71, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %77 = sdiv <8 x i64> %75, %76
  %78 = load <8 x i64>, ptr %.spill, align 64
  %79 = select <8 x i1> %71, <8 x i64> %77, <8 x i64> %78
  store <8 x i64> %79, ptr %.spill, align 64
  %80 = select <8 x i1> %71, <8 x i64> %74, <8 x i64> zeroinitializer
  %81 = select <8 x i1> %71, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %82 = sdiv <8 x i64> %80, %81
  %83 = select <8 x i1> %71, <8 x i64> %82, <8 x i64> zeroinitializer
  %84 = select <8 x i1> %71, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %85 = srem <8 x i64> %83, %84
  %86 = load <8 x i64>, ptr %.spill29, align 64
  %87 = select <8 x i1> %71, <8 x i64> %85, <8 x i64> %86
  store <8 x i64> %87, ptr %.spill29, align 64
  store i64 0, ptr %.spill30, align 4
  %88 = select <8 x i1> %71, <8 x i64> %85, <8 x i64> zeroinitializer
  %89 = select <8 x i1> %71, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %90 = sdiv <8 x i64> %88, %89
  %91 = load <8 x i64>, ptr %.spill31, align 64
  %92 = select <8 x i1> %71, <8 x i64> %90, <8 x i64> %91
  store <8 x i64> %92, ptr %.spill31, align 64
  %93 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %95 = extractvalue { <8 x ptr>, <8 x i64> } %93, 0
  %96 = select <8 x i1> %71, <8 x ptr> %94, <8 x ptr> %95
  %97 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %93, 1
  %99 = select <8 x i1> %71, <8 x i64> %97, <8 x i64> %98
  %100 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %96, 0
  %101 = insertvalue { <8 x ptr>, <8 x i64> } %100, <8 x i64> %99, 1
  store { <8 x ptr>, <8 x i64> } %101, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %102 = icmp slt i64 %.state, 80
  br i1 %102, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %103 = add <8 x i64> %.spill.load, zeroinitializer
  %104 = add <8 x i64> zeroinitializer, %103
  %.spill.load153 = load <8 x i64>, ptr %.spill29, align 64
  %105 = add <8 x i64> %.spill.load153, zeroinitializer
  %106 = mul <8 x i64> %104, splat (i64 8)
  %107 = add <8 x i64> %106, %105
  %.spill.load154 = load i64, ptr %.spill30, align 4
  %108 = add i64 %.spill.load154, 0
  %109 = mul <8 x i64> %107, splat (i64 1)
  %.splatinsert155 = insertelement <8 x i64> poison, i64 %108, i64 0
  %.splat156 = shufflevector <8 x i64> %.splatinsert155, <8 x i64> poison, <8 x i32> zeroinitializer
  %110 = add <8 x i64> %109, %.splat156
  %.state157 = load i64, ptr %.slot, align 4
  %111 = add i64 0, %.state157
  %112 = mul <8 x i64> %110, splat (i64 80)
  %.splatinsert158 = insertelement <8 x i64> poison, i64 %111, i64 0
  %.splat159 = shufflevector <8 x i64> %.splatinsert158, <8 x i64> poison, <8 x i32> zeroinitializer
  %113 = add <8 x i64> %112, %.splat159
  %114 = extractvalue { ptr, i64 } %29, 0
  %115 = mul <8 x i64> %113, splat (i64 4)
  %116 = getelementptr i8, ptr %114, <8 x i64> %115
  %117 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %116, <8 x i1> %71, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %118 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %119 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state160 = load i64, ptr %.slot, align 4
  %.splatinsert161 = insertelement <8 x i64> poison, i64 %.state160, i64 0
  %.splat162 = shufflevector <8 x i64> %.splatinsert161, <8 x i64> poison, <8 x i32> zeroinitializer
  %120 = mul <8 x i64> %.splat162, splat (i64 32)
  %121 = add <8 x i64> %119, %120
  %122 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %118, 0
  %123 = insertvalue { <8 x ptr>, <8 x i64> } %122, <8 x i64> %121, 1
  %124 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %123, 1
  %126 = extractelement <8 x ptr> %124, i32 0
  %127 = extractelement <8 x i64> %125, i32 0
  %128 = sub i64 %127, 0
  %129 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %130 = select i1 %129, i64 %128, i64 0
  %private.contiguous.address = getelementptr i8, ptr %126, i64 %130
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %131 = select <8 x i1> %71, <8 x float> %117, <8 x float> %private.contiguous.preserve
  store <8 x float> %131, ptr %private.contiguous.address, align 4
  %.state163 = load i64, ptr %.slot, align 4
  %132 = add i64 %.state163, 1
  store i64 %132, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %133 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %135 = extractvalue { <8 x ptr>, <8 x i64> } %133, 0
  %136 = select <8 x i1> %71, <8 x ptr> %134, <8 x ptr> %135
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %138 = extractvalue { <8 x ptr>, <8 x i64> } %133, 1
  %139 = select <8 x i1> %71, <8 x i64> %137, <8 x i64> %138
  %140 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %136, 0
  %141 = insertvalue { <8 x ptr>, <8 x i64> } %140, <8 x i64> %139, 1
  store { <8 x ptr>, <8 x i64> } %141, ptr %tile_snapshot.spill32, align 64
  %142 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill33, align 64
  %143 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %144 = extractvalue { <8 x ptr>, <8 x i64> } %142, 0
  %145 = select <8 x i1> %71, <8 x ptr> %143, <8 x ptr> %144
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %142, 1
  %148 = select <8 x i1> %71, <8 x i64> %146, <8 x i64> %147
  %149 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %145, 0
  %150 = insertvalue { <8 x ptr>, <8 x i64> } %149, <8 x i64> %148, 1
  store { <8 x ptr>, <8 x i64> } %150, ptr %tile_snapshot.spill33, align 64
  store i64 0, ptr %.slot34, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state164 = load i64, ptr %.slot34, align 4
  %151 = icmp slt i64 %.state164, 96
  br i1 %151, label %direct.true165, label %direct.false166

direct.schedule.5:                                ; preds = %direct.true165
  %tile_snapshot.spill.load167 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %152 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load167, 0
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load167, 1
  %.state168 = load i64, ptr %.slot34, align 4
  %.splatinsert169 = insertelement <8 x i64> poison, i64 %.state168, i64 0
  %.splat170 = shufflevector <8 x i64> %.splatinsert169, <8 x i64> poison, <8 x i32> zeroinitializer
  %154 = mul <8 x i64> %.splat170, splat (i64 32)
  %155 = add <8 x i64> %153, %154
  %156 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %152, 0
  %157 = insertvalue { <8 x ptr>, <8 x i64> } %156, <8 x i64> %155, 1
  %158 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %159 = extractvalue { <8 x ptr>, <8 x i64> } %157, 1
  %160 = extractelement <8 x ptr> %158, i32 0
  %161 = extractelement <8 x i64> %159, i32 0
  %162 = sub i64 %161, 0
  %163 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %164 = select i1 %163, i64 %162, i64 0
  %private.contiguous.address171 = getelementptr i8, ptr %160, i64 %164
  %private.contiguous.preserve172 = load <8 x float>, ptr %private.contiguous.address171, align 4
  %165 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %private.contiguous.preserve172
  store <8 x float> %165, ptr %private.contiguous.address171, align 4
  %.state173 = load i64, ptr %.slot34, align 4
  %166 = add i64 %.state173, 1
  store i64 %166, ptr %.slot34, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false166
  store i64 0, ptr %.slot35, align 4
  %167 = load <8 x float>, ptr %.slot36, align 32
  %168 = select <8 x i1> %71, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %167
  store <8 x float> %168, ptr %.slot36, align 32
  %169 = load <8 x float>, ptr %.slot37, align 32
  %170 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %169
  store <8 x float> %170, ptr %.slot37, align 32
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.81, %direct.schedule.6
  %.state174 = load i64, ptr %.slot35, align 4
  %171 = icmp slt i64 %.state174, 129
  br i1 %171, label %direct.true175, label %direct.false176

direct.schedule.8:                                ; preds = %direct.true175
  %.state177 = load i64, ptr %.slot35, align 4
  %172 = sdiv i64 %.state177, 1
  %173 = mul i64 %172, 16
  store i64 %173, ptr %.spill38, align 4
  %174 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %174, 0
  %177 = select <8 x i1> %71, <8 x ptr> %175, <8 x ptr> %176
  %178 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %174, 1
  %180 = select <8 x i1> %71, <8 x i64> %178, <8 x i64> %179
  %181 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %177, 0
  %182 = insertvalue { <8 x ptr>, <8 x i64> } %181, <8 x i64> %180, 1
  store { <8 x ptr>, <8 x i64> } %182, ptr %tile_snapshot.spill39, align 64
  store i64 0, ptr %.slot40, align 4
  br label %direct.schedule.9

direct.schedule.9:                                ; preds = %direct.schedule.12, %direct.schedule.8
  %.state178 = load i64, ptr %.slot40, align 4
  %183 = icmp slt i64 %.state178, 1280
  br i1 %183, label %direct.true179, label %direct.false180

direct.schedule.10:                               ; preds = %direct.true179
  %.state181 = load i64, ptr %.slot40, align 4
  %184 = srem i64 %.state181, 80
  %.state182 = load i64, ptr %.slot40, align 4
  %185 = sdiv i64 %.state182, 80
  %.spill.load183 = load <8 x i64>, ptr %.spill, align 64
  %186 = add <8 x i64> %.spill.load183, zeroinitializer
  %187 = add <8 x i64> zeroinitializer, %186
  %.spill.load184 = load <8 x i64>, ptr %.spill31, align 64
  %188 = add <8 x i64> %.spill.load184, zeroinitializer
  %189 = mul <8 x i64> %187, splat (i64 1)
  %190 = add <8 x i64> %189, %188
  %.spill.load185 = load i64, ptr %.spill38, align 4
  %191 = add i64 %.spill.load185, %185
  %192 = mul <8 x i64> %190, splat (i64 2053)
  %.splatinsert186 = insertelement <8 x i64> poison, i64 %191, i64 0
  %.splat187 = shufflevector <8 x i64> %.splatinsert186, <8 x i64> poison, <8 x i32> zeroinitializer
  %193 = add <8 x i64> %192, %.splat187
  %194 = icmp sge i64 %191, 0
  %195 = and i1 true, %194
  %196 = icmp slt i64 %191, 2053
  %197 = and i1 %195, %196
  %198 = add i64 0, %184
  %199 = mul <8 x i64> %193, splat (i64 80)
  %.splatinsert188 = insertelement <8 x i64> poison, i64 %198, i64 0
  %.splat189 = shufflevector <8 x i64> %.splatinsert188, <8 x i64> poison, <8 x i32> zeroinitializer
  %200 = add <8 x i64> %199, %.splat189
  %201 = load <8 x i64>, ptr %.spill41, align 64
  %202 = select <8 x i1> %71, <8 x i64> %200, <8 x i64> %201
  store <8 x i64> %202, ptr %.spill41, align 64
  br i1 %197, label %direct.true190, label %direct.false191

direct.schedule.11:                               ; preds = %direct.true190
  %.spill.load192 = load <8 x i64>, ptr %.spill41, align 64
  %203 = extractvalue { ptr, i64 } %35, 0
  %204 = extractelement <8 x i64> %.spill.load192, i32 0
  %205 = mul i64 %204, 4
  %206 = getelementptr i8, ptr %203, i64 %205
  %207 = load float, ptr %206, align 4
  %.splatinsert193 = insertelement <8 x float> poison, float %207, i64 0
  %.splat194 = shufflevector <8 x float> %.splatinsert193, <8 x float> poison, <8 x i32> zeroinitializer
  %208 = load <8 x float>, ptr %.slot42, align 32
  %209 = select <8 x i1> %71, <8 x float> %.splat194, <8 x float> %208
  store <8 x float> %209, ptr %.slot42, align 32
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.false191, %direct.schedule.11
  %tile_snapshot.spill.load195 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %210 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load195, 0
  %211 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load195, 1
  %.state196 = load i64, ptr %.slot40, align 4
  %.splatinsert197 = insertelement <8 x i64> poison, i64 %.state196, i64 0
  %.splat198 = shufflevector <8 x i64> %.splatinsert197, <8 x i64> poison, <8 x i32> zeroinitializer
  %212 = mul <8 x i64> %.splat198, splat (i64 32)
  %213 = add <8 x i64> %211, %212
  %214 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %210, 0
  %215 = insertvalue { <8 x ptr>, <8 x i64> } %214, <8 x i64> %213, 1
  %.state199 = load <8 x float>, ptr %.slot42, align 32
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %217 = extractvalue { <8 x ptr>, <8 x i64> } %215, 1
  %218 = extractelement <8 x ptr> %216, i32 0
  %219 = extractelement <8 x i64> %217, i32 0
  %220 = sub i64 %219, 0
  %221 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %222 = select i1 %221, i64 %220, i64 0
  %private.contiguous.address200 = getelementptr i8, ptr %218, i64 %222
  %private.contiguous.preserve201 = load <8 x float>, ptr %private.contiguous.address200, align 4
  %223 = select <8 x i1> %71, <8 x float> %.state199, <8 x float> %private.contiguous.preserve201
  store <8 x float> %223, ptr %private.contiguous.address200, align 4
  %.state202 = load i64, ptr %.slot40, align 4
  %224 = add i64 %.state202, 1
  store i64 %224, ptr %.slot40, align 4
  br label %direct.schedule.9

direct.schedule.13:                               ; preds = %direct.false180
  %225 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %225, 0
  %228 = select <8 x i1> %71, <8 x ptr> %226, <8 x ptr> %227
  %229 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %230 = extractvalue { <8 x ptr>, <8 x i64> } %225, 1
  %231 = select <8 x i1> %71, <8 x i64> %229, <8 x i64> %230
  %232 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %228, 0
  %233 = insertvalue { <8 x ptr>, <8 x i64> } %232, <8 x i64> %231, 1
  store { <8 x ptr>, <8 x i64> } %233, ptr %tile_snapshot.spill43, align 64
  store i64 0, ptr %.slot44, align 4
  br label %direct.schedule.14

direct.schedule.14:                               ; preds = %direct.schedule.17, %direct.schedule.13
  %.state203 = load i64, ptr %.slot44, align 4
  %234 = icmp slt i64 %.state203, 1536
  br i1 %234, label %direct.true204, label %direct.false205

direct.schedule.15:                               ; preds = %direct.true204
  %.state206 = load i64, ptr %.slot44, align 4
  %235 = srem i64 %.state206, 96
  %.state207 = load i64, ptr %.slot44, align 4
  %236 = sdiv i64 %.state207, 96
  %.spill.load208 = load <8 x i64>, ptr %.spill, align 64
  %237 = add <8 x i64> %.spill.load208, zeroinitializer
  %238 = add <8 x i64> zeroinitializer, %237
  %.spill.load209 = load <8 x i64>, ptr %.spill31, align 64
  %239 = add <8 x i64> %.spill.load209, zeroinitializer
  %240 = mul <8 x i64> %238, splat (i64 1)
  %241 = add <8 x i64> %240, %239
  %.spill.load210 = load i64, ptr %.spill38, align 4
  %242 = add i64 %.spill.load210, %236
  %243 = mul <8 x i64> %241, splat (i64 2053)
  %.splatinsert211 = insertelement <8 x i64> poison, i64 %242, i64 0
  %.splat212 = shufflevector <8 x i64> %.splatinsert211, <8 x i64> poison, <8 x i32> zeroinitializer
  %244 = add <8 x i64> %243, %.splat212
  %245 = icmp sge i64 %242, 0
  %246 = and i1 true, %245
  %247 = icmp slt i64 %242, 2053
  %248 = and i1 %246, %247
  %249 = add i64 0, %235
  %250 = mul <8 x i64> %244, splat (i64 96)
  %.splatinsert213 = insertelement <8 x i64> poison, i64 %249, i64 0
  %.splat214 = shufflevector <8 x i64> %.splatinsert213, <8 x i64> poison, <8 x i32> zeroinitializer
  %251 = add <8 x i64> %250, %.splat214
  %252 = load <8 x i64>, ptr %.spill45, align 64
  %253 = select <8 x i1> %71, <8 x i64> %251, <8 x i64> %252
  store <8 x i64> %253, ptr %.spill45, align 64
  br i1 %248, label %direct.true215, label %direct.false216

direct.schedule.16:                               ; preds = %direct.true215
  %.spill.load217 = load <8 x i64>, ptr %.spill45, align 64
  %254 = extractvalue { ptr, i64 } %41, 0
  %255 = extractelement <8 x i64> %.spill.load217, i32 0
  %256 = mul i64 %255, 4
  %257 = getelementptr i8, ptr %254, i64 %256
  %258 = load float, ptr %257, align 4
  %.splatinsert218 = insertelement <8 x float> poison, float %258, i64 0
  %.splat219 = shufflevector <8 x float> %.splatinsert218, <8 x float> poison, <8 x i32> zeroinitializer
  %259 = load <8 x float>, ptr %.slot46, align 32
  %260 = select <8 x i1> %71, <8 x float> %.splat219, <8 x float> %259
  store <8 x float> %260, ptr %.slot46, align 32
  br label %direct.schedule.17

direct.schedule.17:                               ; preds = %direct.false216, %direct.schedule.16
  %tile_snapshot.spill.load220 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load220, 0
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load220, 1
  %.state221 = load i64, ptr %.slot44, align 4
  %.splatinsert222 = insertelement <8 x i64> poison, i64 %.state221, i64 0
  %.splat223 = shufflevector <8 x i64> %.splatinsert222, <8 x i64> poison, <8 x i32> zeroinitializer
  %263 = mul <8 x i64> %.splat223, splat (i64 32)
  %264 = add <8 x i64> %262, %263
  %265 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %261, 0
  %266 = insertvalue { <8 x ptr>, <8 x i64> } %265, <8 x i64> %264, 1
  %.state224 = load <8 x float>, ptr %.slot46, align 32
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %266, 1
  %269 = extractelement <8 x ptr> %267, i32 0
  %270 = extractelement <8 x i64> %268, i32 0
  %271 = sub i64 %270, 0
  %272 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %273 = select i1 %272, i64 %271, i64 0
  %private.contiguous.address225 = getelementptr i8, ptr %269, i64 %273
  %private.contiguous.preserve226 = load <8 x float>, ptr %private.contiguous.address225, align 4
  %274 = select <8 x i1> %71, <8 x float> %.state224, <8 x float> %private.contiguous.preserve226
  store <8 x float> %274, ptr %private.contiguous.address225, align 4
  %.state227 = load i64, ptr %.slot44, align 4
  %275 = add i64 %.state227, 1
  store i64 %275, ptr %.slot44, align 4
  br label %direct.schedule.14

direct.schedule.18:                               ; preds = %direct.false205
  store i64 0, ptr %.slot47, align 4
  %276 = load <8 x float>, ptr %.slot48, align 32
  %277 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %276
  store <8 x float> %277, ptr %.slot48, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state228 = load i64, ptr %.slot47, align 4
  %278 = icmp slt i64 %.state228, 80
  br i1 %278, label %direct.true229, label %direct.false230

direct.schedule.20:                               ; preds = %direct.true229
  %.state231 = load i64, ptr %.slot47, align 4
  %279 = add i64 0, %.state231
  %tile_snapshot.spill.load232 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %280 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load232, 0
  %281 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load232, 1
  %.splatinsert233 = insertelement <8 x i64> poison, i64 %279, i64 0
  %.splat234 = shufflevector <8 x i64> %.splatinsert233, <8 x i64> poison, <8 x i32> zeroinitializer
  %282 = mul <8 x i64> %.splat234, splat (i64 32)
  %283 = add <8 x i64> %281, %282
  %284 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %280, 0
  %285 = insertvalue { <8 x ptr>, <8 x i64> } %284, <8 x i64> %283, 1
  %286 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %285, 1
  %288 = extractelement <8 x ptr> %286, i32 0
  %289 = extractelement <8 x i64> %287, i32 0
  %290 = sub i64 %289, 0
  %291 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %292 = select i1 %291, i64 %290, i64 0
  %private.contiguous.address235 = getelementptr i8, ptr %288, i64 %292
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address235, align 4
  %293 = select <8 x i1> %71, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load236 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load236, 0
  %295 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load236, 1
  %.splatinsert237 = insertelement <8 x i64> poison, i64 %279, i64 0
  %.splat238 = shufflevector <8 x i64> %.splatinsert237, <8 x i64> poison, <8 x i32> zeroinitializer
  %296 = mul <8 x i64> %.splat238, splat (i64 32)
  %297 = add <8 x i64> %295, %296
  %298 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %294, 0
  %299 = insertvalue { <8 x ptr>, <8 x i64> } %298, <8 x i64> %297, 1
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %301 = extractvalue { <8 x ptr>, <8 x i64> } %299, 1
  %302 = extractelement <8 x ptr> %300, i32 0
  %303 = extractelement <8 x i64> %301, i32 0
  %304 = sub i64 %303, 0
  %305 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %306 = select i1 %305, i64 %304, i64 0
  %private.contiguous.address239 = getelementptr i8, ptr %302, i64 %306
  %private.contiguous.load240 = load <8 x float>, ptr %private.contiguous.address239, align 4
  %307 = select <8 x i1> %71, <8 x float> %private.contiguous.load240, <8 x float> zeroinitializer
  %308 = fmul <8 x float> %293, %307
  %.state241 = load <8 x float>, ptr %.slot48, align 32
  %309 = fadd <8 x float> %.state241, %308
  %.state242 = load i64, ptr %.slot47, align 4
  %310 = add i64 %.state242, 1
  store i64 %310, ptr %.slot47, align 4
  %311 = load <8 x float>, ptr %.slot48, align 32
  %312 = select <8 x i1> %71, <8 x float> %309, <8 x float> %311
  store <8 x float> %312, ptr %.slot48, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false230
  store i64 0, ptr %.slot49, align 4
  %313 = load <8 x float>, ptr %.slot50, align 32
  %314 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %313
  store <8 x float> %314, ptr %.slot50, align 32
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state243 = load i64, ptr %.slot49, align 4
  %315 = icmp slt i64 %.state243, 80
  br i1 %315, label %direct.true244, label %direct.false245

direct.schedule.23:                               ; preds = %direct.true244
  %.state246 = load i64, ptr %.slot49, align 4
  %316 = add i64 0, %.state246
  %tile_snapshot.spill.load247 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %317 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load247, 0
  %318 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load247, 1
  %.splatinsert248 = insertelement <8 x i64> poison, i64 %316, i64 0
  %.splat249 = shufflevector <8 x i64> %.splatinsert248, <8 x i64> poison, <8 x i32> zeroinitializer
  %319 = mul <8 x i64> %.splat249, splat (i64 32)
  %320 = add <8 x i64> %318, %319
  %321 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %317, 0
  %322 = insertvalue { <8 x ptr>, <8 x i64> } %321, <8 x i64> %320, 1
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %322, 1
  %325 = extractelement <8 x ptr> %323, i32 0
  %326 = extractelement <8 x i64> %324, i32 0
  %327 = sub i64 %326, 0
  %328 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %329 = select i1 %328, i64 %327, i64 0
  %private.contiguous.address250 = getelementptr i8, ptr %325, i64 %329
  %private.contiguous.load251 = load <8 x float>, ptr %private.contiguous.address250, align 4
  %330 = select <8 x i1> %71, <8 x float> %private.contiguous.load251, <8 x float> zeroinitializer
  %.state252 = load i64, ptr %.slot49, align 4
  %331 = add i64 80, %.state252
  %tile_snapshot.spill.load253 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %332 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load253, 0
  %333 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load253, 1
  %.splatinsert254 = insertelement <8 x i64> poison, i64 %331, i64 0
  %.splat255 = shufflevector <8 x i64> %.splatinsert254, <8 x i64> poison, <8 x i32> zeroinitializer
  %334 = mul <8 x i64> %.splat255, splat (i64 32)
  %335 = add <8 x i64> %333, %334
  %336 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %332, 0
  %337 = insertvalue { <8 x ptr>, <8 x i64> } %336, <8 x i64> %335, 1
  %338 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %339 = extractvalue { <8 x ptr>, <8 x i64> } %337, 1
  %340 = extractelement <8 x ptr> %338, i32 0
  %341 = extractelement <8 x i64> %339, i32 0
  %342 = sub i64 %341, 0
  %343 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %344 = select i1 %343, i64 %342, i64 0
  %private.contiguous.address256 = getelementptr i8, ptr %340, i64 %344
  %private.contiguous.load257 = load <8 x float>, ptr %private.contiguous.address256, align 4
  %345 = select <8 x i1> %71, <8 x float> %private.contiguous.load257, <8 x float> zeroinitializer
  %346 = fmul <8 x float> %330, %345
  %.state258 = load <8 x float>, ptr %.slot50, align 32
  %347 = fadd <8 x float> %.state258, %346
  %.state259 = load i64, ptr %.slot49, align 4
  %348 = add i64 %.state259, 1
  store i64 %348, ptr %.slot49, align 4
  %349 = load <8 x float>, ptr %.slot50, align 32
  %350 = select <8 x i1> %71, <8 x float> %347, <8 x float> %349
  store <8 x float> %350, ptr %.slot50, align 32
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false245
  store i64 0, ptr %.slot51, align 4
  %351 = load <8 x float>, ptr %.slot52, align 32
  %352 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %351
  store <8 x float> %352, ptr %.slot52, align 32
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.26, %direct.schedule.24
  %.state260 = load i64, ptr %.slot51, align 4
  %353 = icmp slt i64 %.state260, 80
  br i1 %353, label %direct.true261, label %direct.false262

direct.schedule.26:                               ; preds = %direct.true261
  %.state263 = load i64, ptr %.slot51, align 4
  %354 = add i64 0, %.state263
  %tile_snapshot.spill.load264 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %355 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load264, 0
  %356 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load264, 1
  %.splatinsert265 = insertelement <8 x i64> poison, i64 %354, i64 0
  %.splat266 = shufflevector <8 x i64> %.splatinsert265, <8 x i64> poison, <8 x i32> zeroinitializer
  %357 = mul <8 x i64> %.splat266, splat (i64 32)
  %358 = add <8 x i64> %356, %357
  %359 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %355, 0
  %360 = insertvalue { <8 x ptr>, <8 x i64> } %359, <8 x i64> %358, 1
  %361 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %362 = extractvalue { <8 x ptr>, <8 x i64> } %360, 1
  %363 = extractelement <8 x ptr> %361, i32 0
  %364 = extractelement <8 x i64> %362, i32 0
  %365 = sub i64 %364, 0
  %366 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %367 = select i1 %366, i64 %365, i64 0
  %private.contiguous.address267 = getelementptr i8, ptr %363, i64 %367
  %private.contiguous.load268 = load <8 x float>, ptr %private.contiguous.address267, align 4
  %368 = select <8 x i1> %71, <8 x float> %private.contiguous.load268, <8 x float> zeroinitializer
  %.state269 = load i64, ptr %.slot51, align 4
  %369 = add i64 160, %.state269
  %tile_snapshot.spill.load270 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %370 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 0
  %371 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 1
  %.splatinsert271 = insertelement <8 x i64> poison, i64 %369, i64 0
  %.splat272 = shufflevector <8 x i64> %.splatinsert271, <8 x i64> poison, <8 x i32> zeroinitializer
  %372 = mul <8 x i64> %.splat272, splat (i64 32)
  %373 = add <8 x i64> %371, %372
  %374 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %370, 0
  %375 = insertvalue { <8 x ptr>, <8 x i64> } %374, <8 x i64> %373, 1
  %376 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %377 = extractvalue { <8 x ptr>, <8 x i64> } %375, 1
  %378 = extractelement <8 x ptr> %376, i32 0
  %379 = extractelement <8 x i64> %377, i32 0
  %380 = sub i64 %379, 0
  %381 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %382 = select i1 %381, i64 %380, i64 0
  %private.contiguous.address273 = getelementptr i8, ptr %378, i64 %382
  %private.contiguous.load274 = load <8 x float>, ptr %private.contiguous.address273, align 4
  %383 = select <8 x i1> %71, <8 x float> %private.contiguous.load274, <8 x float> zeroinitializer
  %384 = fmul <8 x float> %368, %383
  %.state275 = load <8 x float>, ptr %.slot52, align 32
  %385 = fadd <8 x float> %.state275, %384
  %.state276 = load i64, ptr %.slot51, align 4
  %386 = add i64 %.state276, 1
  store i64 %386, ptr %.slot51, align 4
  %387 = load <8 x float>, ptr %.slot52, align 32
  %388 = select <8 x i1> %71, <8 x float> %385, <8 x float> %387
  store <8 x float> %388, ptr %.slot52, align 32
  br label %direct.schedule.25

direct.schedule.27:                               ; preds = %direct.false262
  store i64 0, ptr %.slot53, align 4
  %389 = load <8 x float>, ptr %.slot54, align 32
  %390 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %389
  store <8 x float> %390, ptr %.slot54, align 32
  br label %direct.schedule.28

direct.schedule.28:                               ; preds = %direct.schedule.29, %direct.schedule.27
  %.state277 = load i64, ptr %.slot53, align 4
  %391 = icmp slt i64 %.state277, 80
  br i1 %391, label %direct.true278, label %direct.false279

direct.schedule.29:                               ; preds = %direct.true278
  %.state280 = load i64, ptr %.slot53, align 4
  %392 = add i64 0, %.state280
  %tile_snapshot.spill.load281 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %393 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 0
  %394 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 1
  %.splatinsert282 = insertelement <8 x i64> poison, i64 %392, i64 0
  %.splat283 = shufflevector <8 x i64> %.splatinsert282, <8 x i64> poison, <8 x i32> zeroinitializer
  %395 = mul <8 x i64> %.splat283, splat (i64 32)
  %396 = add <8 x i64> %394, %395
  %397 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %393, 0
  %398 = insertvalue { <8 x ptr>, <8 x i64> } %397, <8 x i64> %396, 1
  %399 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %400 = extractvalue { <8 x ptr>, <8 x i64> } %398, 1
  %401 = extractelement <8 x ptr> %399, i32 0
  %402 = extractelement <8 x i64> %400, i32 0
  %403 = sub i64 %402, 0
  %404 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %405 = select i1 %404, i64 %403, i64 0
  %private.contiguous.address284 = getelementptr i8, ptr %401, i64 %405
  %private.contiguous.load285 = load <8 x float>, ptr %private.contiguous.address284, align 4
  %406 = select <8 x i1> %71, <8 x float> %private.contiguous.load285, <8 x float> zeroinitializer
  %.state286 = load i64, ptr %.slot53, align 4
  %407 = add i64 240, %.state286
  %tile_snapshot.spill.load287 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %408 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load287, 0
  %409 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load287, 1
  %.splatinsert288 = insertelement <8 x i64> poison, i64 %407, i64 0
  %.splat289 = shufflevector <8 x i64> %.splatinsert288, <8 x i64> poison, <8 x i32> zeroinitializer
  %410 = mul <8 x i64> %.splat289, splat (i64 32)
  %411 = add <8 x i64> %409, %410
  %412 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %408, 0
  %413 = insertvalue { <8 x ptr>, <8 x i64> } %412, <8 x i64> %411, 1
  %414 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %415 = extractvalue { <8 x ptr>, <8 x i64> } %413, 1
  %416 = extractelement <8 x ptr> %414, i32 0
  %417 = extractelement <8 x i64> %415, i32 0
  %418 = sub i64 %417, 0
  %419 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %420 = select i1 %419, i64 %418, i64 0
  %private.contiguous.address290 = getelementptr i8, ptr %416, i64 %420
  %private.contiguous.load291 = load <8 x float>, ptr %private.contiguous.address290, align 4
  %421 = select <8 x i1> %71, <8 x float> %private.contiguous.load291, <8 x float> zeroinitializer
  %422 = fmul <8 x float> %406, %421
  %.state292 = load <8 x float>, ptr %.slot54, align 32
  %423 = fadd <8 x float> %.state292, %422
  %.state293 = load i64, ptr %.slot53, align 4
  %424 = add i64 %.state293, 1
  store i64 %424, ptr %.slot53, align 4
  %425 = load <8 x float>, ptr %.slot54, align 32
  %426 = select <8 x i1> %71, <8 x float> %423, <8 x float> %425
  store <8 x float> %426, ptr %.slot54, align 32
  br label %direct.schedule.28

direct.schedule.30:                               ; preds = %direct.false279
  store i64 0, ptr %.slot55, align 4
  %427 = load <8 x float>, ptr %.slot56, align 32
  %428 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %427
  store <8 x float> %428, ptr %.slot56, align 32
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.32, %direct.schedule.30
  %.state294 = load i64, ptr %.slot55, align 4
  %429 = icmp slt i64 %.state294, 80
  br i1 %429, label %direct.true295, label %direct.false296

direct.schedule.32:                               ; preds = %direct.true295
  %.state297 = load i64, ptr %.slot55, align 4
  %430 = add i64 0, %.state297
  %tile_snapshot.spill.load298 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %431 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load298, 0
  %432 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load298, 1
  %.splatinsert299 = insertelement <8 x i64> poison, i64 %430, i64 0
  %.splat300 = shufflevector <8 x i64> %.splatinsert299, <8 x i64> poison, <8 x i32> zeroinitializer
  %433 = mul <8 x i64> %.splat300, splat (i64 32)
  %434 = add <8 x i64> %432, %433
  %435 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %431, 0
  %436 = insertvalue { <8 x ptr>, <8 x i64> } %435, <8 x i64> %434, 1
  %437 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %438 = extractvalue { <8 x ptr>, <8 x i64> } %436, 1
  %439 = extractelement <8 x ptr> %437, i32 0
  %440 = extractelement <8 x i64> %438, i32 0
  %441 = sub i64 %440, 0
  %442 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %443 = select i1 %442, i64 %441, i64 0
  %private.contiguous.address301 = getelementptr i8, ptr %439, i64 %443
  %private.contiguous.load302 = load <8 x float>, ptr %private.contiguous.address301, align 4
  %444 = select <8 x i1> %71, <8 x float> %private.contiguous.load302, <8 x float> zeroinitializer
  %.state303 = load i64, ptr %.slot55, align 4
  %445 = add i64 320, %.state303
  %tile_snapshot.spill.load304 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %446 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load304, 0
  %447 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load304, 1
  %.splatinsert305 = insertelement <8 x i64> poison, i64 %445, i64 0
  %.splat306 = shufflevector <8 x i64> %.splatinsert305, <8 x i64> poison, <8 x i32> zeroinitializer
  %448 = mul <8 x i64> %.splat306, splat (i64 32)
  %449 = add <8 x i64> %447, %448
  %450 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %446, 0
  %451 = insertvalue { <8 x ptr>, <8 x i64> } %450, <8 x i64> %449, 1
  %452 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %453 = extractvalue { <8 x ptr>, <8 x i64> } %451, 1
  %454 = extractelement <8 x ptr> %452, i32 0
  %455 = extractelement <8 x i64> %453, i32 0
  %456 = sub i64 %455, 0
  %457 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %458 = select i1 %457, i64 %456, i64 0
  %private.contiguous.address307 = getelementptr i8, ptr %454, i64 %458
  %private.contiguous.load308 = load <8 x float>, ptr %private.contiguous.address307, align 4
  %459 = select <8 x i1> %71, <8 x float> %private.contiguous.load308, <8 x float> zeroinitializer
  %460 = fmul <8 x float> %444, %459
  %.state309 = load <8 x float>, ptr %.slot56, align 32
  %461 = fadd <8 x float> %.state309, %460
  %.state310 = load i64, ptr %.slot55, align 4
  %462 = add i64 %.state310, 1
  store i64 %462, ptr %.slot55, align 4
  %463 = load <8 x float>, ptr %.slot56, align 32
  %464 = select <8 x i1> %71, <8 x float> %461, <8 x float> %463
  store <8 x float> %464, ptr %.slot56, align 32
  br label %direct.schedule.31

direct.schedule.33:                               ; preds = %direct.false296
  store i64 0, ptr %.slot57, align 4
  %465 = load <8 x float>, ptr %.slot58, align 32
  %466 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %465
  store <8 x float> %466, ptr %.slot58, align 32
  br label %direct.schedule.34

direct.schedule.34:                               ; preds = %direct.schedule.35, %direct.schedule.33
  %.state311 = load i64, ptr %.slot57, align 4
  %467 = icmp slt i64 %.state311, 80
  br i1 %467, label %direct.true312, label %direct.false313

direct.schedule.35:                               ; preds = %direct.true312
  %.state314 = load i64, ptr %.slot57, align 4
  %468 = add i64 0, %.state314
  %tile_snapshot.spill.load315 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %469 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load315, 0
  %470 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load315, 1
  %.splatinsert316 = insertelement <8 x i64> poison, i64 %468, i64 0
  %.splat317 = shufflevector <8 x i64> %.splatinsert316, <8 x i64> poison, <8 x i32> zeroinitializer
  %471 = mul <8 x i64> %.splat317, splat (i64 32)
  %472 = add <8 x i64> %470, %471
  %473 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %469, 0
  %474 = insertvalue { <8 x ptr>, <8 x i64> } %473, <8 x i64> %472, 1
  %475 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %476 = extractvalue { <8 x ptr>, <8 x i64> } %474, 1
  %477 = extractelement <8 x ptr> %475, i32 0
  %478 = extractelement <8 x i64> %476, i32 0
  %479 = sub i64 %478, 0
  %480 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %481 = select i1 %480, i64 %479, i64 0
  %private.contiguous.address318 = getelementptr i8, ptr %477, i64 %481
  %private.contiguous.load319 = load <8 x float>, ptr %private.contiguous.address318, align 4
  %482 = select <8 x i1> %71, <8 x float> %private.contiguous.load319, <8 x float> zeroinitializer
  %.state320 = load i64, ptr %.slot57, align 4
  %483 = add i64 400, %.state320
  %tile_snapshot.spill.load321 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %484 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load321, 0
  %485 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load321, 1
  %.splatinsert322 = insertelement <8 x i64> poison, i64 %483, i64 0
  %.splat323 = shufflevector <8 x i64> %.splatinsert322, <8 x i64> poison, <8 x i32> zeroinitializer
  %486 = mul <8 x i64> %.splat323, splat (i64 32)
  %487 = add <8 x i64> %485, %486
  %488 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %484, 0
  %489 = insertvalue { <8 x ptr>, <8 x i64> } %488, <8 x i64> %487, 1
  %490 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %491 = extractvalue { <8 x ptr>, <8 x i64> } %489, 1
  %492 = extractelement <8 x ptr> %490, i32 0
  %493 = extractelement <8 x i64> %491, i32 0
  %494 = sub i64 %493, 0
  %495 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %496 = select i1 %495, i64 %494, i64 0
  %private.contiguous.address324 = getelementptr i8, ptr %492, i64 %496
  %private.contiguous.load325 = load <8 x float>, ptr %private.contiguous.address324, align 4
  %497 = select <8 x i1> %71, <8 x float> %private.contiguous.load325, <8 x float> zeroinitializer
  %498 = fmul <8 x float> %482, %497
  %.state326 = load <8 x float>, ptr %.slot58, align 32
  %499 = fadd <8 x float> %.state326, %498
  %.state327 = load i64, ptr %.slot57, align 4
  %500 = add i64 %.state327, 1
  store i64 %500, ptr %.slot57, align 4
  %501 = load <8 x float>, ptr %.slot58, align 32
  %502 = select <8 x i1> %71, <8 x float> %499, <8 x float> %501
  store <8 x float> %502, ptr %.slot58, align 32
  br label %direct.schedule.34

direct.schedule.36:                               ; preds = %direct.false313
  store i64 0, ptr %.slot59, align 4
  %503 = load <8 x float>, ptr %.slot60, align 32
  %504 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %503
  store <8 x float> %504, ptr %.slot60, align 32
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.38, %direct.schedule.36
  %.state328 = load i64, ptr %.slot59, align 4
  %505 = icmp slt i64 %.state328, 80
  br i1 %505, label %direct.true329, label %direct.false330

direct.schedule.38:                               ; preds = %direct.true329
  %.state331 = load i64, ptr %.slot59, align 4
  %506 = add i64 0, %.state331
  %tile_snapshot.spill.load332 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %507 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load332, 0
  %508 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load332, 1
  %.splatinsert333 = insertelement <8 x i64> poison, i64 %506, i64 0
  %.splat334 = shufflevector <8 x i64> %.splatinsert333, <8 x i64> poison, <8 x i32> zeroinitializer
  %509 = mul <8 x i64> %.splat334, splat (i64 32)
  %510 = add <8 x i64> %508, %509
  %511 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %507, 0
  %512 = insertvalue { <8 x ptr>, <8 x i64> } %511, <8 x i64> %510, 1
  %513 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %514 = extractvalue { <8 x ptr>, <8 x i64> } %512, 1
  %515 = extractelement <8 x ptr> %513, i32 0
  %516 = extractelement <8 x i64> %514, i32 0
  %517 = sub i64 %516, 0
  %518 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %519 = select i1 %518, i64 %517, i64 0
  %private.contiguous.address335 = getelementptr i8, ptr %515, i64 %519
  %private.contiguous.load336 = load <8 x float>, ptr %private.contiguous.address335, align 4
  %520 = select <8 x i1> %71, <8 x float> %private.contiguous.load336, <8 x float> zeroinitializer
  %.state337 = load i64, ptr %.slot59, align 4
  %521 = add i64 480, %.state337
  %tile_snapshot.spill.load338 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %522 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load338, 0
  %523 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load338, 1
  %.splatinsert339 = insertelement <8 x i64> poison, i64 %521, i64 0
  %.splat340 = shufflevector <8 x i64> %.splatinsert339, <8 x i64> poison, <8 x i32> zeroinitializer
  %524 = mul <8 x i64> %.splat340, splat (i64 32)
  %525 = add <8 x i64> %523, %524
  %526 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %522, 0
  %527 = insertvalue { <8 x ptr>, <8 x i64> } %526, <8 x i64> %525, 1
  %528 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %527, 1
  %530 = extractelement <8 x ptr> %528, i32 0
  %531 = extractelement <8 x i64> %529, i32 0
  %532 = sub i64 %531, 0
  %533 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %534 = select i1 %533, i64 %532, i64 0
  %private.contiguous.address341 = getelementptr i8, ptr %530, i64 %534
  %private.contiguous.load342 = load <8 x float>, ptr %private.contiguous.address341, align 4
  %535 = select <8 x i1> %71, <8 x float> %private.contiguous.load342, <8 x float> zeroinitializer
  %536 = fmul <8 x float> %520, %535
  %.state343 = load <8 x float>, ptr %.slot60, align 32
  %537 = fadd <8 x float> %.state343, %536
  %.state344 = load i64, ptr %.slot59, align 4
  %538 = add i64 %.state344, 1
  store i64 %538, ptr %.slot59, align 4
  %539 = load <8 x float>, ptr %.slot60, align 32
  %540 = select <8 x i1> %71, <8 x float> %537, <8 x float> %539
  store <8 x float> %540, ptr %.slot60, align 32
  br label %direct.schedule.37

direct.schedule.39:                               ; preds = %direct.false330
  store i64 0, ptr %.slot61, align 4
  %541 = load <8 x float>, ptr %.slot62, align 32
  %542 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %541
  store <8 x float> %542, ptr %.slot62, align 32
  br label %direct.schedule.40

direct.schedule.40:                               ; preds = %direct.schedule.41, %direct.schedule.39
  %.state345 = load i64, ptr %.slot61, align 4
  %543 = icmp slt i64 %.state345, 80
  br i1 %543, label %direct.true346, label %direct.false347

direct.schedule.41:                               ; preds = %direct.true346
  %.state348 = load i64, ptr %.slot61, align 4
  %544 = add i64 0, %.state348
  %tile_snapshot.spill.load349 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %545 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load349, 0
  %546 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load349, 1
  %.splatinsert350 = insertelement <8 x i64> poison, i64 %544, i64 0
  %.splat351 = shufflevector <8 x i64> %.splatinsert350, <8 x i64> poison, <8 x i32> zeroinitializer
  %547 = mul <8 x i64> %.splat351, splat (i64 32)
  %548 = add <8 x i64> %546, %547
  %549 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %545, 0
  %550 = insertvalue { <8 x ptr>, <8 x i64> } %549, <8 x i64> %548, 1
  %551 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %552 = extractvalue { <8 x ptr>, <8 x i64> } %550, 1
  %553 = extractelement <8 x ptr> %551, i32 0
  %554 = extractelement <8 x i64> %552, i32 0
  %555 = sub i64 %554, 0
  %556 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %557 = select i1 %556, i64 %555, i64 0
  %private.contiguous.address352 = getelementptr i8, ptr %553, i64 %557
  %private.contiguous.load353 = load <8 x float>, ptr %private.contiguous.address352, align 4
  %558 = select <8 x i1> %71, <8 x float> %private.contiguous.load353, <8 x float> zeroinitializer
  %.state354 = load i64, ptr %.slot61, align 4
  %559 = add i64 560, %.state354
  %tile_snapshot.spill.load355 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %560 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load355, 0
  %561 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load355, 1
  %.splatinsert356 = insertelement <8 x i64> poison, i64 %559, i64 0
  %.splat357 = shufflevector <8 x i64> %.splatinsert356, <8 x i64> poison, <8 x i32> zeroinitializer
  %562 = mul <8 x i64> %.splat357, splat (i64 32)
  %563 = add <8 x i64> %561, %562
  %564 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %560, 0
  %565 = insertvalue { <8 x ptr>, <8 x i64> } %564, <8 x i64> %563, 1
  %566 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %567 = extractvalue { <8 x ptr>, <8 x i64> } %565, 1
  %568 = extractelement <8 x ptr> %566, i32 0
  %569 = extractelement <8 x i64> %567, i32 0
  %570 = sub i64 %569, 0
  %571 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %572 = select i1 %571, i64 %570, i64 0
  %private.contiguous.address358 = getelementptr i8, ptr %568, i64 %572
  %private.contiguous.load359 = load <8 x float>, ptr %private.contiguous.address358, align 4
  %573 = select <8 x i1> %71, <8 x float> %private.contiguous.load359, <8 x float> zeroinitializer
  %574 = fmul <8 x float> %558, %573
  %.state360 = load <8 x float>, ptr %.slot62, align 32
  %575 = fadd <8 x float> %.state360, %574
  %.state361 = load i64, ptr %.slot61, align 4
  %576 = add i64 %.state361, 1
  store i64 %576, ptr %.slot61, align 4
  %577 = load <8 x float>, ptr %.slot62, align 32
  %578 = select <8 x i1> %71, <8 x float> %575, <8 x float> %577
  store <8 x float> %578, ptr %.slot62, align 32
  br label %direct.schedule.40

direct.schedule.42:                               ; preds = %direct.false347
  store i64 0, ptr %.slot63, align 4
  %579 = load <8 x float>, ptr %.slot64, align 32
  %580 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %579
  store <8 x float> %580, ptr %.slot64, align 32
  br label %direct.schedule.43

direct.schedule.43:                               ; preds = %direct.schedule.44, %direct.schedule.42
  %.state362 = load i64, ptr %.slot63, align 4
  %581 = icmp slt i64 %.state362, 80
  br i1 %581, label %direct.true363, label %direct.false364

direct.schedule.44:                               ; preds = %direct.true363
  %.state365 = load i64, ptr %.slot63, align 4
  %582 = add i64 0, %.state365
  %tile_snapshot.spill.load366 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %583 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load366, 0
  %584 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load366, 1
  %.splatinsert367 = insertelement <8 x i64> poison, i64 %582, i64 0
  %.splat368 = shufflevector <8 x i64> %.splatinsert367, <8 x i64> poison, <8 x i32> zeroinitializer
  %585 = mul <8 x i64> %.splat368, splat (i64 32)
  %586 = add <8 x i64> %584, %585
  %587 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %583, 0
  %588 = insertvalue { <8 x ptr>, <8 x i64> } %587, <8 x i64> %586, 1
  %589 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %590 = extractvalue { <8 x ptr>, <8 x i64> } %588, 1
  %591 = extractelement <8 x ptr> %589, i32 0
  %592 = extractelement <8 x i64> %590, i32 0
  %593 = sub i64 %592, 0
  %594 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %595 = select i1 %594, i64 %593, i64 0
  %private.contiguous.address369 = getelementptr i8, ptr %591, i64 %595
  %private.contiguous.load370 = load <8 x float>, ptr %private.contiguous.address369, align 4
  %596 = select <8 x i1> %71, <8 x float> %private.contiguous.load370, <8 x float> zeroinitializer
  %.state371 = load i64, ptr %.slot63, align 4
  %597 = add i64 640, %.state371
  %tile_snapshot.spill.load372 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %598 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load372, 0
  %599 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load372, 1
  %.splatinsert373 = insertelement <8 x i64> poison, i64 %597, i64 0
  %.splat374 = shufflevector <8 x i64> %.splatinsert373, <8 x i64> poison, <8 x i32> zeroinitializer
  %600 = mul <8 x i64> %.splat374, splat (i64 32)
  %601 = add <8 x i64> %599, %600
  %602 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %598, 0
  %603 = insertvalue { <8 x ptr>, <8 x i64> } %602, <8 x i64> %601, 1
  %604 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %605 = extractvalue { <8 x ptr>, <8 x i64> } %603, 1
  %606 = extractelement <8 x ptr> %604, i32 0
  %607 = extractelement <8 x i64> %605, i32 0
  %608 = sub i64 %607, 0
  %609 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %610 = select i1 %609, i64 %608, i64 0
  %private.contiguous.address375 = getelementptr i8, ptr %606, i64 %610
  %private.contiguous.load376 = load <8 x float>, ptr %private.contiguous.address375, align 4
  %611 = select <8 x i1> %71, <8 x float> %private.contiguous.load376, <8 x float> zeroinitializer
  %612 = fmul <8 x float> %596, %611
  %.state377 = load <8 x float>, ptr %.slot64, align 32
  %613 = fadd <8 x float> %.state377, %612
  %.state378 = load i64, ptr %.slot63, align 4
  %614 = add i64 %.state378, 1
  store i64 %614, ptr %.slot63, align 4
  %615 = load <8 x float>, ptr %.slot64, align 32
  %616 = select <8 x i1> %71, <8 x float> %613, <8 x float> %615
  store <8 x float> %616, ptr %.slot64, align 32
  br label %direct.schedule.43

direct.schedule.45:                               ; preds = %direct.false364
  store i64 0, ptr %.slot65, align 4
  %617 = load <8 x float>, ptr %.slot66, align 32
  %618 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %617
  store <8 x float> %618, ptr %.slot66, align 32
  br label %direct.schedule.46

direct.schedule.46:                               ; preds = %direct.schedule.47, %direct.schedule.45
  %.state379 = load i64, ptr %.slot65, align 4
  %619 = icmp slt i64 %.state379, 80
  br i1 %619, label %direct.true380, label %direct.false381

direct.schedule.47:                               ; preds = %direct.true380
  %.state382 = load i64, ptr %.slot65, align 4
  %620 = add i64 0, %.state382
  %tile_snapshot.spill.load383 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %621 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load383, 0
  %622 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load383, 1
  %.splatinsert384 = insertelement <8 x i64> poison, i64 %620, i64 0
  %.splat385 = shufflevector <8 x i64> %.splatinsert384, <8 x i64> poison, <8 x i32> zeroinitializer
  %623 = mul <8 x i64> %.splat385, splat (i64 32)
  %624 = add <8 x i64> %622, %623
  %625 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %621, 0
  %626 = insertvalue { <8 x ptr>, <8 x i64> } %625, <8 x i64> %624, 1
  %627 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %628 = extractvalue { <8 x ptr>, <8 x i64> } %626, 1
  %629 = extractelement <8 x ptr> %627, i32 0
  %630 = extractelement <8 x i64> %628, i32 0
  %631 = sub i64 %630, 0
  %632 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %633 = select i1 %632, i64 %631, i64 0
  %private.contiguous.address386 = getelementptr i8, ptr %629, i64 %633
  %private.contiguous.load387 = load <8 x float>, ptr %private.contiguous.address386, align 4
  %634 = select <8 x i1> %71, <8 x float> %private.contiguous.load387, <8 x float> zeroinitializer
  %.state388 = load i64, ptr %.slot65, align 4
  %635 = add i64 720, %.state388
  %tile_snapshot.spill.load389 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %636 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load389, 0
  %637 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load389, 1
  %.splatinsert390 = insertelement <8 x i64> poison, i64 %635, i64 0
  %.splat391 = shufflevector <8 x i64> %.splatinsert390, <8 x i64> poison, <8 x i32> zeroinitializer
  %638 = mul <8 x i64> %.splat391, splat (i64 32)
  %639 = add <8 x i64> %637, %638
  %640 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %636, 0
  %641 = insertvalue { <8 x ptr>, <8 x i64> } %640, <8 x i64> %639, 1
  %642 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %643 = extractvalue { <8 x ptr>, <8 x i64> } %641, 1
  %644 = extractelement <8 x ptr> %642, i32 0
  %645 = extractelement <8 x i64> %643, i32 0
  %646 = sub i64 %645, 0
  %647 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %648 = select i1 %647, i64 %646, i64 0
  %private.contiguous.address392 = getelementptr i8, ptr %644, i64 %648
  %private.contiguous.load393 = load <8 x float>, ptr %private.contiguous.address392, align 4
  %649 = select <8 x i1> %71, <8 x float> %private.contiguous.load393, <8 x float> zeroinitializer
  %650 = fmul <8 x float> %634, %649
  %.state394 = load <8 x float>, ptr %.slot66, align 32
  %651 = fadd <8 x float> %.state394, %650
  %.state395 = load i64, ptr %.slot65, align 4
  %652 = add i64 %.state395, 1
  store i64 %652, ptr %.slot65, align 4
  %653 = load <8 x float>, ptr %.slot66, align 32
  %654 = select <8 x i1> %71, <8 x float> %651, <8 x float> %653
  store <8 x float> %654, ptr %.slot66, align 32
  br label %direct.schedule.46

direct.schedule.48:                               ; preds = %direct.false381
  store i64 0, ptr %.slot67, align 4
  %655 = load <8 x float>, ptr %.slot68, align 32
  %656 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %655
  store <8 x float> %656, ptr %.slot68, align 32
  br label %direct.schedule.49

direct.schedule.49:                               ; preds = %direct.schedule.50, %direct.schedule.48
  %.state396 = load i64, ptr %.slot67, align 4
  %657 = icmp slt i64 %.state396, 80
  br i1 %657, label %direct.true397, label %direct.false398

direct.schedule.50:                               ; preds = %direct.true397
  %.state399 = load i64, ptr %.slot67, align 4
  %658 = add i64 0, %.state399
  %tile_snapshot.spill.load400 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %659 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load400, 0
  %660 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load400, 1
  %.splatinsert401 = insertelement <8 x i64> poison, i64 %658, i64 0
  %.splat402 = shufflevector <8 x i64> %.splatinsert401, <8 x i64> poison, <8 x i32> zeroinitializer
  %661 = mul <8 x i64> %.splat402, splat (i64 32)
  %662 = add <8 x i64> %660, %661
  %663 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %659, 0
  %664 = insertvalue { <8 x ptr>, <8 x i64> } %663, <8 x i64> %662, 1
  %665 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %666 = extractvalue { <8 x ptr>, <8 x i64> } %664, 1
  %667 = extractelement <8 x ptr> %665, i32 0
  %668 = extractelement <8 x i64> %666, i32 0
  %669 = sub i64 %668, 0
  %670 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %671 = select i1 %670, i64 %669, i64 0
  %private.contiguous.address403 = getelementptr i8, ptr %667, i64 %671
  %private.contiguous.load404 = load <8 x float>, ptr %private.contiguous.address403, align 4
  %672 = select <8 x i1> %71, <8 x float> %private.contiguous.load404, <8 x float> zeroinitializer
  %.state405 = load i64, ptr %.slot67, align 4
  %673 = add i64 800, %.state405
  %tile_snapshot.spill.load406 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %674 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load406, 0
  %675 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load406, 1
  %.splatinsert407 = insertelement <8 x i64> poison, i64 %673, i64 0
  %.splat408 = shufflevector <8 x i64> %.splatinsert407, <8 x i64> poison, <8 x i32> zeroinitializer
  %676 = mul <8 x i64> %.splat408, splat (i64 32)
  %677 = add <8 x i64> %675, %676
  %678 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %674, 0
  %679 = insertvalue { <8 x ptr>, <8 x i64> } %678, <8 x i64> %677, 1
  %680 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %681 = extractvalue { <8 x ptr>, <8 x i64> } %679, 1
  %682 = extractelement <8 x ptr> %680, i32 0
  %683 = extractelement <8 x i64> %681, i32 0
  %684 = sub i64 %683, 0
  %685 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %686 = select i1 %685, i64 %684, i64 0
  %private.contiguous.address409 = getelementptr i8, ptr %682, i64 %686
  %private.contiguous.load410 = load <8 x float>, ptr %private.contiguous.address409, align 4
  %687 = select <8 x i1> %71, <8 x float> %private.contiguous.load410, <8 x float> zeroinitializer
  %688 = fmul <8 x float> %672, %687
  %.state411 = load <8 x float>, ptr %.slot68, align 32
  %689 = fadd <8 x float> %.state411, %688
  %.state412 = load i64, ptr %.slot67, align 4
  %690 = add i64 %.state412, 1
  store i64 %690, ptr %.slot67, align 4
  %691 = load <8 x float>, ptr %.slot68, align 32
  %692 = select <8 x i1> %71, <8 x float> %689, <8 x float> %691
  store <8 x float> %692, ptr %.slot68, align 32
  br label %direct.schedule.49

direct.schedule.51:                               ; preds = %direct.false398
  store i64 0, ptr %.slot69, align 4
  %693 = load <8 x float>, ptr %.slot70, align 32
  %694 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %693
  store <8 x float> %694, ptr %.slot70, align 32
  br label %direct.schedule.52

direct.schedule.52:                               ; preds = %direct.schedule.53, %direct.schedule.51
  %.state413 = load i64, ptr %.slot69, align 4
  %695 = icmp slt i64 %.state413, 80
  br i1 %695, label %direct.true414, label %direct.false415

direct.schedule.53:                               ; preds = %direct.true414
  %.state416 = load i64, ptr %.slot69, align 4
  %696 = add i64 0, %.state416
  %tile_snapshot.spill.load417 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %697 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load417, 0
  %698 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load417, 1
  %.splatinsert418 = insertelement <8 x i64> poison, i64 %696, i64 0
  %.splat419 = shufflevector <8 x i64> %.splatinsert418, <8 x i64> poison, <8 x i32> zeroinitializer
  %699 = mul <8 x i64> %.splat419, splat (i64 32)
  %700 = add <8 x i64> %698, %699
  %701 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %697, 0
  %702 = insertvalue { <8 x ptr>, <8 x i64> } %701, <8 x i64> %700, 1
  %703 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %704 = extractvalue { <8 x ptr>, <8 x i64> } %702, 1
  %705 = extractelement <8 x ptr> %703, i32 0
  %706 = extractelement <8 x i64> %704, i32 0
  %707 = sub i64 %706, 0
  %708 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %709 = select i1 %708, i64 %707, i64 0
  %private.contiguous.address420 = getelementptr i8, ptr %705, i64 %709
  %private.contiguous.load421 = load <8 x float>, ptr %private.contiguous.address420, align 4
  %710 = select <8 x i1> %71, <8 x float> %private.contiguous.load421, <8 x float> zeroinitializer
  %.state422 = load i64, ptr %.slot69, align 4
  %711 = add i64 880, %.state422
  %tile_snapshot.spill.load423 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %712 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load423, 0
  %713 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load423, 1
  %.splatinsert424 = insertelement <8 x i64> poison, i64 %711, i64 0
  %.splat425 = shufflevector <8 x i64> %.splatinsert424, <8 x i64> poison, <8 x i32> zeroinitializer
  %714 = mul <8 x i64> %.splat425, splat (i64 32)
  %715 = add <8 x i64> %713, %714
  %716 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %712, 0
  %717 = insertvalue { <8 x ptr>, <8 x i64> } %716, <8 x i64> %715, 1
  %718 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %719 = extractvalue { <8 x ptr>, <8 x i64> } %717, 1
  %720 = extractelement <8 x ptr> %718, i32 0
  %721 = extractelement <8 x i64> %719, i32 0
  %722 = sub i64 %721, 0
  %723 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %724 = select i1 %723, i64 %722, i64 0
  %private.contiguous.address426 = getelementptr i8, ptr %720, i64 %724
  %private.contiguous.load427 = load <8 x float>, ptr %private.contiguous.address426, align 4
  %725 = select <8 x i1> %71, <8 x float> %private.contiguous.load427, <8 x float> zeroinitializer
  %726 = fmul <8 x float> %710, %725
  %.state428 = load <8 x float>, ptr %.slot70, align 32
  %727 = fadd <8 x float> %.state428, %726
  %.state429 = load i64, ptr %.slot69, align 4
  %728 = add i64 %.state429, 1
  store i64 %728, ptr %.slot69, align 4
  %729 = load <8 x float>, ptr %.slot70, align 32
  %730 = select <8 x i1> %71, <8 x float> %727, <8 x float> %729
  store <8 x float> %730, ptr %.slot70, align 32
  br label %direct.schedule.52

direct.schedule.54:                               ; preds = %direct.false415
  store i64 0, ptr %.slot71, align 4
  %731 = load <8 x float>, ptr %.slot72, align 32
  %732 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %731
  store <8 x float> %732, ptr %.slot72, align 32
  br label %direct.schedule.55

direct.schedule.55:                               ; preds = %direct.schedule.56, %direct.schedule.54
  %.state430 = load i64, ptr %.slot71, align 4
  %733 = icmp slt i64 %.state430, 80
  br i1 %733, label %direct.true431, label %direct.false432

direct.schedule.56:                               ; preds = %direct.true431
  %.state433 = load i64, ptr %.slot71, align 4
  %734 = add i64 0, %.state433
  %tile_snapshot.spill.load434 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %735 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load434, 0
  %736 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load434, 1
  %.splatinsert435 = insertelement <8 x i64> poison, i64 %734, i64 0
  %.splat436 = shufflevector <8 x i64> %.splatinsert435, <8 x i64> poison, <8 x i32> zeroinitializer
  %737 = mul <8 x i64> %.splat436, splat (i64 32)
  %738 = add <8 x i64> %736, %737
  %739 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %735, 0
  %740 = insertvalue { <8 x ptr>, <8 x i64> } %739, <8 x i64> %738, 1
  %741 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %742 = extractvalue { <8 x ptr>, <8 x i64> } %740, 1
  %743 = extractelement <8 x ptr> %741, i32 0
  %744 = extractelement <8 x i64> %742, i32 0
  %745 = sub i64 %744, 0
  %746 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %747 = select i1 %746, i64 %745, i64 0
  %private.contiguous.address437 = getelementptr i8, ptr %743, i64 %747
  %private.contiguous.load438 = load <8 x float>, ptr %private.contiguous.address437, align 4
  %748 = select <8 x i1> %71, <8 x float> %private.contiguous.load438, <8 x float> zeroinitializer
  %.state439 = load i64, ptr %.slot71, align 4
  %749 = add i64 960, %.state439
  %tile_snapshot.spill.load440 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %750 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load440, 0
  %751 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load440, 1
  %.splatinsert441 = insertelement <8 x i64> poison, i64 %749, i64 0
  %.splat442 = shufflevector <8 x i64> %.splatinsert441, <8 x i64> poison, <8 x i32> zeroinitializer
  %752 = mul <8 x i64> %.splat442, splat (i64 32)
  %753 = add <8 x i64> %751, %752
  %754 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %750, 0
  %755 = insertvalue { <8 x ptr>, <8 x i64> } %754, <8 x i64> %753, 1
  %756 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %757 = extractvalue { <8 x ptr>, <8 x i64> } %755, 1
  %758 = extractelement <8 x ptr> %756, i32 0
  %759 = extractelement <8 x i64> %757, i32 0
  %760 = sub i64 %759, 0
  %761 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %762 = select i1 %761, i64 %760, i64 0
  %private.contiguous.address443 = getelementptr i8, ptr %758, i64 %762
  %private.contiguous.load444 = load <8 x float>, ptr %private.contiguous.address443, align 4
  %763 = select <8 x i1> %71, <8 x float> %private.contiguous.load444, <8 x float> zeroinitializer
  %764 = fmul <8 x float> %748, %763
  %.state445 = load <8 x float>, ptr %.slot72, align 32
  %765 = fadd <8 x float> %.state445, %764
  %.state446 = load i64, ptr %.slot71, align 4
  %766 = add i64 %.state446, 1
  store i64 %766, ptr %.slot71, align 4
  %767 = load <8 x float>, ptr %.slot72, align 32
  %768 = select <8 x i1> %71, <8 x float> %765, <8 x float> %767
  store <8 x float> %768, ptr %.slot72, align 32
  br label %direct.schedule.55

direct.schedule.57:                               ; preds = %direct.false432
  store i64 0, ptr %.slot73, align 4
  %769 = load <8 x float>, ptr %.slot74, align 32
  %770 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %769
  store <8 x float> %770, ptr %.slot74, align 32
  br label %direct.schedule.58

direct.schedule.58:                               ; preds = %direct.schedule.59, %direct.schedule.57
  %.state447 = load i64, ptr %.slot73, align 4
  %771 = icmp slt i64 %.state447, 80
  br i1 %771, label %direct.true448, label %direct.false449

direct.schedule.59:                               ; preds = %direct.true448
  %.state450 = load i64, ptr %.slot73, align 4
  %772 = add i64 0, %.state450
  %tile_snapshot.spill.load451 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %773 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load451, 0
  %774 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load451, 1
  %.splatinsert452 = insertelement <8 x i64> poison, i64 %772, i64 0
  %.splat453 = shufflevector <8 x i64> %.splatinsert452, <8 x i64> poison, <8 x i32> zeroinitializer
  %775 = mul <8 x i64> %.splat453, splat (i64 32)
  %776 = add <8 x i64> %774, %775
  %777 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %773, 0
  %778 = insertvalue { <8 x ptr>, <8 x i64> } %777, <8 x i64> %776, 1
  %779 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %780 = extractvalue { <8 x ptr>, <8 x i64> } %778, 1
  %781 = extractelement <8 x ptr> %779, i32 0
  %782 = extractelement <8 x i64> %780, i32 0
  %783 = sub i64 %782, 0
  %784 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %785 = select i1 %784, i64 %783, i64 0
  %private.contiguous.address454 = getelementptr i8, ptr %781, i64 %785
  %private.contiguous.load455 = load <8 x float>, ptr %private.contiguous.address454, align 4
  %786 = select <8 x i1> %71, <8 x float> %private.contiguous.load455, <8 x float> zeroinitializer
  %.state456 = load i64, ptr %.slot73, align 4
  %787 = add i64 1040, %.state456
  %tile_snapshot.spill.load457 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %788 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load457, 0
  %789 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load457, 1
  %.splatinsert458 = insertelement <8 x i64> poison, i64 %787, i64 0
  %.splat459 = shufflevector <8 x i64> %.splatinsert458, <8 x i64> poison, <8 x i32> zeroinitializer
  %790 = mul <8 x i64> %.splat459, splat (i64 32)
  %791 = add <8 x i64> %789, %790
  %792 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %788, 0
  %793 = insertvalue { <8 x ptr>, <8 x i64> } %792, <8 x i64> %791, 1
  %794 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %795 = extractvalue { <8 x ptr>, <8 x i64> } %793, 1
  %796 = extractelement <8 x ptr> %794, i32 0
  %797 = extractelement <8 x i64> %795, i32 0
  %798 = sub i64 %797, 0
  %799 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %800 = select i1 %799, i64 %798, i64 0
  %private.contiguous.address460 = getelementptr i8, ptr %796, i64 %800
  %private.contiguous.load461 = load <8 x float>, ptr %private.contiguous.address460, align 4
  %801 = select <8 x i1> %71, <8 x float> %private.contiguous.load461, <8 x float> zeroinitializer
  %802 = fmul <8 x float> %786, %801
  %.state462 = load <8 x float>, ptr %.slot74, align 32
  %803 = fadd <8 x float> %.state462, %802
  %.state463 = load i64, ptr %.slot73, align 4
  %804 = add i64 %.state463, 1
  store i64 %804, ptr %.slot73, align 4
  %805 = load <8 x float>, ptr %.slot74, align 32
  %806 = select <8 x i1> %71, <8 x float> %803, <8 x float> %805
  store <8 x float> %806, ptr %.slot74, align 32
  br label %direct.schedule.58

direct.schedule.60:                               ; preds = %direct.false449
  store i64 0, ptr %.slot75, align 4
  %807 = load <8 x float>, ptr %.slot76, align 32
  %808 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %807
  store <8 x float> %808, ptr %.slot76, align 32
  br label %direct.schedule.61

direct.schedule.61:                               ; preds = %direct.schedule.62, %direct.schedule.60
  %.state464 = load i64, ptr %.slot75, align 4
  %809 = icmp slt i64 %.state464, 80
  br i1 %809, label %direct.true465, label %direct.false466

direct.schedule.62:                               ; preds = %direct.true465
  %.state467 = load i64, ptr %.slot75, align 4
  %810 = add i64 0, %.state467
  %tile_snapshot.spill.load468 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %811 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load468, 0
  %812 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load468, 1
  %.splatinsert469 = insertelement <8 x i64> poison, i64 %810, i64 0
  %.splat470 = shufflevector <8 x i64> %.splatinsert469, <8 x i64> poison, <8 x i32> zeroinitializer
  %813 = mul <8 x i64> %.splat470, splat (i64 32)
  %814 = add <8 x i64> %812, %813
  %815 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %811, 0
  %816 = insertvalue { <8 x ptr>, <8 x i64> } %815, <8 x i64> %814, 1
  %817 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %818 = extractvalue { <8 x ptr>, <8 x i64> } %816, 1
  %819 = extractelement <8 x ptr> %817, i32 0
  %820 = extractelement <8 x i64> %818, i32 0
  %821 = sub i64 %820, 0
  %822 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %823 = select i1 %822, i64 %821, i64 0
  %private.contiguous.address471 = getelementptr i8, ptr %819, i64 %823
  %private.contiguous.load472 = load <8 x float>, ptr %private.contiguous.address471, align 4
  %824 = select <8 x i1> %71, <8 x float> %private.contiguous.load472, <8 x float> zeroinitializer
  %.state473 = load i64, ptr %.slot75, align 4
  %825 = add i64 1120, %.state473
  %tile_snapshot.spill.load474 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %826 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load474, 0
  %827 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load474, 1
  %.splatinsert475 = insertelement <8 x i64> poison, i64 %825, i64 0
  %.splat476 = shufflevector <8 x i64> %.splatinsert475, <8 x i64> poison, <8 x i32> zeroinitializer
  %828 = mul <8 x i64> %.splat476, splat (i64 32)
  %829 = add <8 x i64> %827, %828
  %830 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %826, 0
  %831 = insertvalue { <8 x ptr>, <8 x i64> } %830, <8 x i64> %829, 1
  %832 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %833 = extractvalue { <8 x ptr>, <8 x i64> } %831, 1
  %834 = extractelement <8 x ptr> %832, i32 0
  %835 = extractelement <8 x i64> %833, i32 0
  %836 = sub i64 %835, 0
  %837 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %838 = select i1 %837, i64 %836, i64 0
  %private.contiguous.address477 = getelementptr i8, ptr %834, i64 %838
  %private.contiguous.load478 = load <8 x float>, ptr %private.contiguous.address477, align 4
  %839 = select <8 x i1> %71, <8 x float> %private.contiguous.load478, <8 x float> zeroinitializer
  %840 = fmul <8 x float> %824, %839
  %.state479 = load <8 x float>, ptr %.slot76, align 32
  %841 = fadd <8 x float> %.state479, %840
  %.state480 = load i64, ptr %.slot75, align 4
  %842 = add i64 %.state480, 1
  store i64 %842, ptr %.slot75, align 4
  %843 = load <8 x float>, ptr %.slot76, align 32
  %844 = select <8 x i1> %71, <8 x float> %841, <8 x float> %843
  store <8 x float> %844, ptr %.slot76, align 32
  br label %direct.schedule.61

direct.schedule.63:                               ; preds = %direct.false466
  store i64 0, ptr %.slot77, align 4
  %845 = load <8 x float>, ptr %.slot78, align 32
  %846 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %845
  store <8 x float> %846, ptr %.slot78, align 32
  br label %direct.schedule.64

direct.schedule.64:                               ; preds = %direct.schedule.65, %direct.schedule.63
  %.state481 = load i64, ptr %.slot77, align 4
  %847 = icmp slt i64 %.state481, 80
  br i1 %847, label %direct.true482, label %direct.false483

direct.schedule.65:                               ; preds = %direct.true482
  %.state484 = load i64, ptr %.slot77, align 4
  %848 = add i64 0, %.state484
  %tile_snapshot.spill.load485 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %849 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load485, 0
  %850 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load485, 1
  %.splatinsert486 = insertelement <8 x i64> poison, i64 %848, i64 0
  %.splat487 = shufflevector <8 x i64> %.splatinsert486, <8 x i64> poison, <8 x i32> zeroinitializer
  %851 = mul <8 x i64> %.splat487, splat (i64 32)
  %852 = add <8 x i64> %850, %851
  %853 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %849, 0
  %854 = insertvalue { <8 x ptr>, <8 x i64> } %853, <8 x i64> %852, 1
  %855 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %856 = extractvalue { <8 x ptr>, <8 x i64> } %854, 1
  %857 = extractelement <8 x ptr> %855, i32 0
  %858 = extractelement <8 x i64> %856, i32 0
  %859 = sub i64 %858, 0
  %860 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %861 = select i1 %860, i64 %859, i64 0
  %private.contiguous.address488 = getelementptr i8, ptr %857, i64 %861
  %private.contiguous.load489 = load <8 x float>, ptr %private.contiguous.address488, align 4
  %862 = select <8 x i1> %71, <8 x float> %private.contiguous.load489, <8 x float> zeroinitializer
  %.state490 = load i64, ptr %.slot77, align 4
  %863 = add i64 1200, %.state490
  %tile_snapshot.spill.load491 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %864 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load491, 0
  %865 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load491, 1
  %.splatinsert492 = insertelement <8 x i64> poison, i64 %863, i64 0
  %.splat493 = shufflevector <8 x i64> %.splatinsert492, <8 x i64> poison, <8 x i32> zeroinitializer
  %866 = mul <8 x i64> %.splat493, splat (i64 32)
  %867 = add <8 x i64> %865, %866
  %868 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %864, 0
  %869 = insertvalue { <8 x ptr>, <8 x i64> } %868, <8 x i64> %867, 1
  %870 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %871 = extractvalue { <8 x ptr>, <8 x i64> } %869, 1
  %872 = extractelement <8 x ptr> %870, i32 0
  %873 = extractelement <8 x i64> %871, i32 0
  %874 = sub i64 %873, 0
  %875 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %876 = select i1 %875, i64 %874, i64 0
  %private.contiguous.address494 = getelementptr i8, ptr %872, i64 %876
  %private.contiguous.load495 = load <8 x float>, ptr %private.contiguous.address494, align 4
  %877 = select <8 x i1> %71, <8 x float> %private.contiguous.load495, <8 x float> zeroinitializer
  %878 = fmul <8 x float> %862, %877
  %.state496 = load <8 x float>, ptr %.slot78, align 32
  %879 = fadd <8 x float> %.state496, %878
  %.state497 = load i64, ptr %.slot77, align 4
  %880 = add i64 %.state497, 1
  store i64 %880, ptr %.slot77, align 4
  %881 = load <8 x float>, ptr %.slot78, align 32
  %882 = select <8 x i1> %71, <8 x float> %879, <8 x float> %881
  store <8 x float> %882, ptr %.slot78, align 32
  br label %direct.schedule.64

direct.schedule.66:                               ; preds = %direct.false483
  %.state498 = load <8 x float>, ptr %.slot48, align 32
  %883 = fmul <8 x float> %.state498, splat (float 0x3FBC9F25C0000000)
  %.state499 = load <8 x float>, ptr %.slot50, align 32
  %884 = fmul <8 x float> %.state499, splat (float 0x3FBC9F25C0000000)
  %.state500 = load <8 x float>, ptr %.slot52, align 32
  %885 = fmul <8 x float> %.state500, splat (float 0x3FBC9F25C0000000)
  %.state501 = load <8 x float>, ptr %.slot54, align 32
  %886 = fmul <8 x float> %.state501, splat (float 0x3FBC9F25C0000000)
  %.state502 = load <8 x float>, ptr %.slot56, align 32
  %887 = fmul <8 x float> %.state502, splat (float 0x3FBC9F25C0000000)
  %.state503 = load <8 x float>, ptr %.slot58, align 32
  %888 = fmul <8 x float> %.state503, splat (float 0x3FBC9F25C0000000)
  %.state504 = load <8 x float>, ptr %.slot60, align 32
  %889 = fmul <8 x float> %.state504, splat (float 0x3FBC9F25C0000000)
  %.state505 = load <8 x float>, ptr %.slot62, align 32
  %890 = fmul <8 x float> %.state505, splat (float 0x3FBC9F25C0000000)
  %.state506 = load <8 x float>, ptr %.slot64, align 32
  %891 = fmul <8 x float> %.state506, splat (float 0x3FBC9F25C0000000)
  %.state507 = load <8 x float>, ptr %.slot66, align 32
  %892 = fmul <8 x float> %.state507, splat (float 0x3FBC9F25C0000000)
  %.state508 = load <8 x float>, ptr %.slot68, align 32
  %893 = fmul <8 x float> %.state508, splat (float 0x3FBC9F25C0000000)
  %.state509 = load <8 x float>, ptr %.slot70, align 32
  %894 = fmul <8 x float> %.state509, splat (float 0x3FBC9F25C0000000)
  %.state510 = load <8 x float>, ptr %.slot72, align 32
  %895 = fmul <8 x float> %.state510, splat (float 0x3FBC9F25C0000000)
  %.state511 = load <8 x float>, ptr %.slot74, align 32
  %896 = fmul <8 x float> %.state511, splat (float 0x3FBC9F25C0000000)
  %.state512 = load <8 x float>, ptr %.slot76, align 32
  %897 = fmul <8 x float> %.state512, splat (float 0x3FBC9F25C0000000)
  %.state513 = load <8 x float>, ptr %.slot78, align 32
  %898 = fmul <8 x float> %.state513, splat (float 0x3FBC9F25C0000000)
  %.spill.load514 = load i64, ptr %.spill38, align 4
  %899 = add i64 0, %.spill.load514
  %.spill.load515 = load i64, ptr %.spill38, align 4
  %900 = add i64 1, %.spill.load515
  %.spill.load516 = load i64, ptr %.spill38, align 4
  %901 = add i64 2, %.spill.load516
  %.spill.load517 = load i64, ptr %.spill38, align 4
  %902 = add i64 3, %.spill.load517
  %.spill.load518 = load i64, ptr %.spill38, align 4
  %903 = add i64 4, %.spill.load518
  %.spill.load519 = load i64, ptr %.spill38, align 4
  %904 = add i64 5, %.spill.load519
  %.spill.load520 = load i64, ptr %.spill38, align 4
  %905 = add i64 6, %.spill.load520
  %.spill.load521 = load i64, ptr %.spill38, align 4
  %906 = add i64 7, %.spill.load521
  %.spill.load522 = load i64, ptr %.spill38, align 4
  %907 = add i64 8, %.spill.load522
  %.spill.load523 = load i64, ptr %.spill38, align 4
  %908 = add i64 9, %.spill.load523
  %.spill.load524 = load i64, ptr %.spill38, align 4
  %909 = add i64 10, %.spill.load524
  %.spill.load525 = load i64, ptr %.spill38, align 4
  %910 = add i64 11, %.spill.load525
  %.spill.load526 = load i64, ptr %.spill38, align 4
  %911 = add i64 12, %.spill.load526
  %.spill.load527 = load i64, ptr %.spill38, align 4
  %912 = add i64 13, %.spill.load527
  %.spill.load528 = load i64, ptr %.spill38, align 4
  %913 = add i64 14, %.spill.load528
  %.spill.load529 = load i64, ptr %.spill38, align 4
  %914 = add i64 15, %.spill.load529
  %915 = icmp slt i64 %899, 2053
  %916 = icmp slt i64 %900, 2053
  %917 = icmp slt i64 %901, 2053
  %918 = icmp slt i64 %902, 2053
  %919 = icmp slt i64 %903, 2053
  %920 = icmp slt i64 %904, 2053
  %921 = icmp slt i64 %905, 2053
  %922 = icmp slt i64 %906, 2053
  %923 = icmp slt i64 %907, 2053
  %924 = icmp slt i64 %908, 2053
  %925 = icmp slt i64 %909, 2053
  %926 = icmp slt i64 %910, 2053
  %927 = icmp slt i64 %911, 2053
  %928 = icmp slt i64 %912, 2053
  %929 = icmp slt i64 %913, 2053
  %930 = icmp slt i64 %914, 2053
  %.spill.load530 = load i64, ptr %.spill30, align 4
  %931 = add i64 0, %.spill.load530
  store i64 %931, ptr %.spill79, align 4
  %932 = add i64 %931, 2053
  %933 = sub i64 %932, 1
  %934 = icmp sle i64 %899, %933
  %935 = icmp sle i64 %900, %933
  %936 = icmp sle i64 %901, %933
  %937 = icmp sle i64 %902, %933
  %938 = icmp sle i64 %903, %933
  %939 = icmp sle i64 %904, %933
  %940 = icmp sle i64 %905, %933
  %941 = icmp sle i64 %906, %933
  %942 = icmp sle i64 %907, %933
  %943 = icmp sle i64 %908, %933
  %944 = icmp sle i64 %909, %933
  %945 = icmp sle i64 %910, %933
  %946 = icmp sle i64 %911, %933
  %947 = icmp sle i64 %912, %933
  %948 = icmp sle i64 %913, %933
  %949 = icmp sle i64 %914, %933
  %950 = and i1 %915, %934
  store i1 %950, ptr %.spill80, align 1
  %951 = and i1 %916, %935
  store i1 %951, ptr %.spill81, align 1
  %952 = and i1 %917, %936
  store i1 %952, ptr %.spill82, align 1
  %953 = and i1 %918, %937
  store i1 %953, ptr %.spill83, align 1
  %954 = and i1 %919, %938
  store i1 %954, ptr %.spill84, align 1
  %955 = and i1 %920, %939
  store i1 %955, ptr %.spill85, align 1
  %956 = and i1 %921, %940
  store i1 %956, ptr %.spill86, align 1
  %957 = and i1 %922, %941
  store i1 %957, ptr %.spill87, align 1
  %958 = and i1 %923, %942
  store i1 %958, ptr %.spill88, align 1
  %959 = and i1 %924, %943
  store i1 %959, ptr %.spill89, align 1
  %960 = and i1 %925, %944
  store i1 %960, ptr %.spill90, align 1
  %961 = and i1 %926, %945
  store i1 %961, ptr %.spill91, align 1
  %962 = and i1 %927, %946
  store i1 %962, ptr %.spill92, align 1
  %963 = and i1 %928, %947
  store i1 %963, ptr %.spill93, align 1
  %964 = and i1 %929, %948
  store i1 %964, ptr %.spill94, align 1
  %965 = and i1 %930, %949
  store i1 %965, ptr %.spill95, align 1
  %.splatinsert531 = insertelement <8 x i1> poison, i1 %950, i64 0
  %.splat532 = shufflevector <8 x i1> %.splatinsert531, <8 x i1> poison, <8 x i32> zeroinitializer
  %966 = select <8 x i1> %.splat532, <8 x float> %883, <8 x float> splat (float 0xC6293E5940000000)
  %967 = load <8 x float>, ptr %.spill96, align 32
  %968 = select <8 x i1> %71, <8 x float> %966, <8 x float> %967
  store <8 x float> %968, ptr %.spill96, align 32
  %.splatinsert533 = insertelement <8 x i1> poison, i1 %951, i64 0
  %.splat534 = shufflevector <8 x i1> %.splatinsert533, <8 x i1> poison, <8 x i32> zeroinitializer
  %969 = select <8 x i1> %.splat534, <8 x float> %884, <8 x float> splat (float 0xC6293E5940000000)
  %970 = load <8 x float>, ptr %.spill97, align 32
  %971 = select <8 x i1> %71, <8 x float> %969, <8 x float> %970
  store <8 x float> %971, ptr %.spill97, align 32
  %.splatinsert535 = insertelement <8 x i1> poison, i1 %952, i64 0
  %.splat536 = shufflevector <8 x i1> %.splatinsert535, <8 x i1> poison, <8 x i32> zeroinitializer
  %972 = select <8 x i1> %.splat536, <8 x float> %885, <8 x float> splat (float 0xC6293E5940000000)
  %973 = load <8 x float>, ptr %.spill98, align 32
  %974 = select <8 x i1> %71, <8 x float> %972, <8 x float> %973
  store <8 x float> %974, ptr %.spill98, align 32
  %.splatinsert537 = insertelement <8 x i1> poison, i1 %953, i64 0
  %.splat538 = shufflevector <8 x i1> %.splatinsert537, <8 x i1> poison, <8 x i32> zeroinitializer
  %975 = select <8 x i1> %.splat538, <8 x float> %886, <8 x float> splat (float 0xC6293E5940000000)
  %976 = load <8 x float>, ptr %.spill99, align 32
  %977 = select <8 x i1> %71, <8 x float> %975, <8 x float> %976
  store <8 x float> %977, ptr %.spill99, align 32
  %.splatinsert539 = insertelement <8 x i1> poison, i1 %954, i64 0
  %.splat540 = shufflevector <8 x i1> %.splatinsert539, <8 x i1> poison, <8 x i32> zeroinitializer
  %978 = select <8 x i1> %.splat540, <8 x float> %887, <8 x float> splat (float 0xC6293E5940000000)
  %979 = load <8 x float>, ptr %.spill100, align 32
  %980 = select <8 x i1> %71, <8 x float> %978, <8 x float> %979
  store <8 x float> %980, ptr %.spill100, align 32
  %.splatinsert541 = insertelement <8 x i1> poison, i1 %955, i64 0
  %.splat542 = shufflevector <8 x i1> %.splatinsert541, <8 x i1> poison, <8 x i32> zeroinitializer
  %981 = select <8 x i1> %.splat542, <8 x float> %888, <8 x float> splat (float 0xC6293E5940000000)
  %982 = load <8 x float>, ptr %.spill101, align 32
  %983 = select <8 x i1> %71, <8 x float> %981, <8 x float> %982
  store <8 x float> %983, ptr %.spill101, align 32
  %.splatinsert543 = insertelement <8 x i1> poison, i1 %956, i64 0
  %.splat544 = shufflevector <8 x i1> %.splatinsert543, <8 x i1> poison, <8 x i32> zeroinitializer
  %984 = select <8 x i1> %.splat544, <8 x float> %889, <8 x float> splat (float 0xC6293E5940000000)
  %985 = load <8 x float>, ptr %.spill102, align 32
  %986 = select <8 x i1> %71, <8 x float> %984, <8 x float> %985
  store <8 x float> %986, ptr %.spill102, align 32
  %.splatinsert545 = insertelement <8 x i1> poison, i1 %957, i64 0
  %.splat546 = shufflevector <8 x i1> %.splatinsert545, <8 x i1> poison, <8 x i32> zeroinitializer
  %987 = select <8 x i1> %.splat546, <8 x float> %890, <8 x float> splat (float 0xC6293E5940000000)
  %988 = load <8 x float>, ptr %.spill103, align 32
  %989 = select <8 x i1> %71, <8 x float> %987, <8 x float> %988
  store <8 x float> %989, ptr %.spill103, align 32
  %.splatinsert547 = insertelement <8 x i1> poison, i1 %958, i64 0
  %.splat548 = shufflevector <8 x i1> %.splatinsert547, <8 x i1> poison, <8 x i32> zeroinitializer
  %990 = select <8 x i1> %.splat548, <8 x float> %891, <8 x float> splat (float 0xC6293E5940000000)
  %991 = load <8 x float>, ptr %.spill104, align 32
  %992 = select <8 x i1> %71, <8 x float> %990, <8 x float> %991
  store <8 x float> %992, ptr %.spill104, align 32
  %.splatinsert549 = insertelement <8 x i1> poison, i1 %959, i64 0
  %.splat550 = shufflevector <8 x i1> %.splatinsert549, <8 x i1> poison, <8 x i32> zeroinitializer
  %993 = select <8 x i1> %.splat550, <8 x float> %892, <8 x float> splat (float 0xC6293E5940000000)
  %994 = load <8 x float>, ptr %.spill105, align 32
  %995 = select <8 x i1> %71, <8 x float> %993, <8 x float> %994
  store <8 x float> %995, ptr %.spill105, align 32
  %.splatinsert551 = insertelement <8 x i1> poison, i1 %960, i64 0
  %.splat552 = shufflevector <8 x i1> %.splatinsert551, <8 x i1> poison, <8 x i32> zeroinitializer
  %996 = select <8 x i1> %.splat552, <8 x float> %893, <8 x float> splat (float 0xC6293E5940000000)
  %997 = load <8 x float>, ptr %.spill106, align 32
  %998 = select <8 x i1> %71, <8 x float> %996, <8 x float> %997
  store <8 x float> %998, ptr %.spill106, align 32
  %.splatinsert553 = insertelement <8 x i1> poison, i1 %961, i64 0
  %.splat554 = shufflevector <8 x i1> %.splatinsert553, <8 x i1> poison, <8 x i32> zeroinitializer
  %999 = select <8 x i1> %.splat554, <8 x float> %894, <8 x float> splat (float 0xC6293E5940000000)
  %1000 = load <8 x float>, ptr %.spill107, align 32
  %1001 = select <8 x i1> %71, <8 x float> %999, <8 x float> %1000
  store <8 x float> %1001, ptr %.spill107, align 32
  %.splatinsert555 = insertelement <8 x i1> poison, i1 %962, i64 0
  %.splat556 = shufflevector <8 x i1> %.splatinsert555, <8 x i1> poison, <8 x i32> zeroinitializer
  %1002 = select <8 x i1> %.splat556, <8 x float> %895, <8 x float> splat (float 0xC6293E5940000000)
  %1003 = load <8 x float>, ptr %.spill108, align 32
  %1004 = select <8 x i1> %71, <8 x float> %1002, <8 x float> %1003
  store <8 x float> %1004, ptr %.spill108, align 32
  %.splatinsert557 = insertelement <8 x i1> poison, i1 %963, i64 0
  %.splat558 = shufflevector <8 x i1> %.splatinsert557, <8 x i1> poison, <8 x i32> zeroinitializer
  %1005 = select <8 x i1> %.splat558, <8 x float> %896, <8 x float> splat (float 0xC6293E5940000000)
  %1006 = load <8 x float>, ptr %.spill109, align 32
  %1007 = select <8 x i1> %71, <8 x float> %1005, <8 x float> %1006
  store <8 x float> %1007, ptr %.spill109, align 32
  %.splatinsert559 = insertelement <8 x i1> poison, i1 %964, i64 0
  %.splat560 = shufflevector <8 x i1> %.splatinsert559, <8 x i1> poison, <8 x i32> zeroinitializer
  %1008 = select <8 x i1> %.splat560, <8 x float> %897, <8 x float> splat (float 0xC6293E5940000000)
  %1009 = load <8 x float>, ptr %.spill110, align 32
  %1010 = select <8 x i1> %71, <8 x float> %1008, <8 x float> %1009
  store <8 x float> %1010, ptr %.spill110, align 32
  %.splatinsert561 = insertelement <8 x i1> poison, i1 %965, i64 0
  %.splat562 = shufflevector <8 x i1> %.splatinsert561, <8 x i1> poison, <8 x i32> zeroinitializer
  %1011 = select <8 x i1> %.splat562, <8 x float> %898, <8 x float> splat (float 0xC6293E5940000000)
  %1012 = load <8 x float>, ptr %.spill111, align 32
  %1013 = select <8 x i1> %71, <8 x float> %1011, <8 x float> %1012
  store <8 x float> %1013, ptr %.spill111, align 32
  %1014 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill112, align 64
  %1015 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1016 = extractvalue { <8 x ptr>, <8 x i64> } %1014, 0
  %1017 = select <8 x i1> %71, <8 x ptr> %1015, <8 x ptr> %1016
  %1018 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1019 = extractvalue { <8 x ptr>, <8 x i64> } %1014, 1
  %1020 = select <8 x i1> %71, <8 x i64> %1018, <8 x i64> %1019
  %1021 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1017, 0
  %1022 = insertvalue { <8 x ptr>, <8 x i64> } %1021, <8 x i64> %1020, 1
  store { <8 x ptr>, <8 x i64> } %1022, ptr %tile_snapshot.spill112, align 64
  %1023 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1024 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1025 = add <8 x i64> %1024, zeroinitializer
  %1026 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1023, 0
  %1027 = insertvalue { <8 x ptr>, <8 x i64> } %1026, <8 x i64> %1025, 1
  %1028 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1029 = extractvalue { <8 x ptr>, <8 x i64> } %1027, 1
  %1030 = extractelement <8 x ptr> %1028, i32 0
  %1031 = extractelement <8 x i64> %1029, i32 0
  %1032 = sub i64 %1031, 0
  %1033 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1034 = select i1 %1033, i64 %1032, i64 0
  %private.contiguous.address563 = getelementptr i8, ptr %1030, i64 %1034
  %private.contiguous.preserve564 = load <8 x float>, ptr %private.contiguous.address563, align 4
  %1035 = select <8 x i1> %71, <8 x float> %966, <8 x float> %private.contiguous.preserve564
  store <8 x float> %1035, ptr %private.contiguous.address563, align 4
  %1036 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1037 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1038 = add <8 x i64> %1037, splat (i64 32)
  %1039 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1036, 0
  %1040 = insertvalue { <8 x ptr>, <8 x i64> } %1039, <8 x i64> %1038, 1
  %1041 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1042 = extractvalue { <8 x ptr>, <8 x i64> } %1040, 1
  %1043 = extractelement <8 x ptr> %1041, i32 0
  %1044 = extractelement <8 x i64> %1042, i32 0
  %1045 = sub i64 %1044, 0
  %1046 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1047 = select i1 %1046, i64 %1045, i64 0
  %private.contiguous.address565 = getelementptr i8, ptr %1043, i64 %1047
  %private.contiguous.preserve566 = load <8 x float>, ptr %private.contiguous.address565, align 4
  %1048 = select <8 x i1> %71, <8 x float> %969, <8 x float> %private.contiguous.preserve566
  store <8 x float> %1048, ptr %private.contiguous.address565, align 4
  %1049 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1050 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1051 = add <8 x i64> %1050, splat (i64 64)
  %1052 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1049, 0
  %1053 = insertvalue { <8 x ptr>, <8 x i64> } %1052, <8 x i64> %1051, 1
  %1054 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1055 = extractvalue { <8 x ptr>, <8 x i64> } %1053, 1
  %1056 = extractelement <8 x ptr> %1054, i32 0
  %1057 = extractelement <8 x i64> %1055, i32 0
  %1058 = sub i64 %1057, 0
  %1059 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1060 = select i1 %1059, i64 %1058, i64 0
  %private.contiguous.address567 = getelementptr i8, ptr %1056, i64 %1060
  %private.contiguous.preserve568 = load <8 x float>, ptr %private.contiguous.address567, align 4
  %1061 = select <8 x i1> %71, <8 x float> %972, <8 x float> %private.contiguous.preserve568
  store <8 x float> %1061, ptr %private.contiguous.address567, align 4
  %1062 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1063 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1064 = add <8 x i64> %1063, splat (i64 96)
  %1065 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1062, 0
  %1066 = insertvalue { <8 x ptr>, <8 x i64> } %1065, <8 x i64> %1064, 1
  %1067 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1068 = extractvalue { <8 x ptr>, <8 x i64> } %1066, 1
  %1069 = extractelement <8 x ptr> %1067, i32 0
  %1070 = extractelement <8 x i64> %1068, i32 0
  %1071 = sub i64 %1070, 0
  %1072 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1073 = select i1 %1072, i64 %1071, i64 0
  %private.contiguous.address569 = getelementptr i8, ptr %1069, i64 %1073
  %private.contiguous.preserve570 = load <8 x float>, ptr %private.contiguous.address569, align 4
  %1074 = select <8 x i1> %71, <8 x float> %975, <8 x float> %private.contiguous.preserve570
  store <8 x float> %1074, ptr %private.contiguous.address569, align 4
  %1075 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1076 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1077 = add <8 x i64> %1076, splat (i64 128)
  %1078 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1075, 0
  %1079 = insertvalue { <8 x ptr>, <8 x i64> } %1078, <8 x i64> %1077, 1
  %1080 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1081 = extractvalue { <8 x ptr>, <8 x i64> } %1079, 1
  %1082 = extractelement <8 x ptr> %1080, i32 0
  %1083 = extractelement <8 x i64> %1081, i32 0
  %1084 = sub i64 %1083, 0
  %1085 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1086 = select i1 %1085, i64 %1084, i64 0
  %private.contiguous.address571 = getelementptr i8, ptr %1082, i64 %1086
  %private.contiguous.preserve572 = load <8 x float>, ptr %private.contiguous.address571, align 4
  %1087 = select <8 x i1> %71, <8 x float> %978, <8 x float> %private.contiguous.preserve572
  store <8 x float> %1087, ptr %private.contiguous.address571, align 4
  %1088 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1089 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1090 = add <8 x i64> %1089, splat (i64 160)
  %1091 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1088, 0
  %1092 = insertvalue { <8 x ptr>, <8 x i64> } %1091, <8 x i64> %1090, 1
  %1093 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1094 = extractvalue { <8 x ptr>, <8 x i64> } %1092, 1
  %1095 = extractelement <8 x ptr> %1093, i32 0
  %1096 = extractelement <8 x i64> %1094, i32 0
  %1097 = sub i64 %1096, 0
  %1098 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1099 = select i1 %1098, i64 %1097, i64 0
  %private.contiguous.address573 = getelementptr i8, ptr %1095, i64 %1099
  %private.contiguous.preserve574 = load <8 x float>, ptr %private.contiguous.address573, align 4
  %1100 = select <8 x i1> %71, <8 x float> %981, <8 x float> %private.contiguous.preserve574
  store <8 x float> %1100, ptr %private.contiguous.address573, align 4
  %1101 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1102 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1103 = add <8 x i64> %1102, splat (i64 192)
  %1104 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1101, 0
  %1105 = insertvalue { <8 x ptr>, <8 x i64> } %1104, <8 x i64> %1103, 1
  %1106 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1107 = extractvalue { <8 x ptr>, <8 x i64> } %1105, 1
  %1108 = extractelement <8 x ptr> %1106, i32 0
  %1109 = extractelement <8 x i64> %1107, i32 0
  %1110 = sub i64 %1109, 0
  %1111 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1112 = select i1 %1111, i64 %1110, i64 0
  %private.contiguous.address575 = getelementptr i8, ptr %1108, i64 %1112
  %private.contiguous.preserve576 = load <8 x float>, ptr %private.contiguous.address575, align 4
  %1113 = select <8 x i1> %71, <8 x float> %984, <8 x float> %private.contiguous.preserve576
  store <8 x float> %1113, ptr %private.contiguous.address575, align 4
  %1114 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1115 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1116 = add <8 x i64> %1115, splat (i64 224)
  %1117 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1114, 0
  %1118 = insertvalue { <8 x ptr>, <8 x i64> } %1117, <8 x i64> %1116, 1
  %1119 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1120 = extractvalue { <8 x ptr>, <8 x i64> } %1118, 1
  %1121 = extractelement <8 x ptr> %1119, i32 0
  %1122 = extractelement <8 x i64> %1120, i32 0
  %1123 = sub i64 %1122, 0
  %1124 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1125 = select i1 %1124, i64 %1123, i64 0
  %private.contiguous.address577 = getelementptr i8, ptr %1121, i64 %1125
  %private.contiguous.preserve578 = load <8 x float>, ptr %private.contiguous.address577, align 4
  %1126 = select <8 x i1> %71, <8 x float> %987, <8 x float> %private.contiguous.preserve578
  store <8 x float> %1126, ptr %private.contiguous.address577, align 4
  %1127 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1128 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1129 = add <8 x i64> %1128, splat (i64 256)
  %1130 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1127, 0
  %1131 = insertvalue { <8 x ptr>, <8 x i64> } %1130, <8 x i64> %1129, 1
  %1132 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1133 = extractvalue { <8 x ptr>, <8 x i64> } %1131, 1
  %1134 = extractelement <8 x ptr> %1132, i32 0
  %1135 = extractelement <8 x i64> %1133, i32 0
  %1136 = sub i64 %1135, 0
  %1137 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1138 = select i1 %1137, i64 %1136, i64 0
  %private.contiguous.address579 = getelementptr i8, ptr %1134, i64 %1138
  %private.contiguous.preserve580 = load <8 x float>, ptr %private.contiguous.address579, align 4
  %1139 = select <8 x i1> %71, <8 x float> %990, <8 x float> %private.contiguous.preserve580
  store <8 x float> %1139, ptr %private.contiguous.address579, align 4
  %1140 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1141 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1142 = add <8 x i64> %1141, splat (i64 288)
  %1143 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1140, 0
  %1144 = insertvalue { <8 x ptr>, <8 x i64> } %1143, <8 x i64> %1142, 1
  %1145 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1146 = extractvalue { <8 x ptr>, <8 x i64> } %1144, 1
  %1147 = extractelement <8 x ptr> %1145, i32 0
  %1148 = extractelement <8 x i64> %1146, i32 0
  %1149 = sub i64 %1148, 0
  %1150 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1151 = select i1 %1150, i64 %1149, i64 0
  %private.contiguous.address581 = getelementptr i8, ptr %1147, i64 %1151
  %private.contiguous.preserve582 = load <8 x float>, ptr %private.contiguous.address581, align 4
  %1152 = select <8 x i1> %71, <8 x float> %993, <8 x float> %private.contiguous.preserve582
  store <8 x float> %1152, ptr %private.contiguous.address581, align 4
  %1153 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1154 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1155 = add <8 x i64> %1154, splat (i64 320)
  %1156 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1153, 0
  %1157 = insertvalue { <8 x ptr>, <8 x i64> } %1156, <8 x i64> %1155, 1
  %1158 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1159 = extractvalue { <8 x ptr>, <8 x i64> } %1157, 1
  %1160 = extractelement <8 x ptr> %1158, i32 0
  %1161 = extractelement <8 x i64> %1159, i32 0
  %1162 = sub i64 %1161, 0
  %1163 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1164 = select i1 %1163, i64 %1162, i64 0
  %private.contiguous.address583 = getelementptr i8, ptr %1160, i64 %1164
  %private.contiguous.preserve584 = load <8 x float>, ptr %private.contiguous.address583, align 4
  %1165 = select <8 x i1> %71, <8 x float> %996, <8 x float> %private.contiguous.preserve584
  store <8 x float> %1165, ptr %private.contiguous.address583, align 4
  %1166 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1167 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1168 = add <8 x i64> %1167, splat (i64 352)
  %1169 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1166, 0
  %1170 = insertvalue { <8 x ptr>, <8 x i64> } %1169, <8 x i64> %1168, 1
  %1171 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1172 = extractvalue { <8 x ptr>, <8 x i64> } %1170, 1
  %1173 = extractelement <8 x ptr> %1171, i32 0
  %1174 = extractelement <8 x i64> %1172, i32 0
  %1175 = sub i64 %1174, 0
  %1176 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1177 = select i1 %1176, i64 %1175, i64 0
  %private.contiguous.address585 = getelementptr i8, ptr %1173, i64 %1177
  %private.contiguous.preserve586 = load <8 x float>, ptr %private.contiguous.address585, align 4
  %1178 = select <8 x i1> %71, <8 x float> %999, <8 x float> %private.contiguous.preserve586
  store <8 x float> %1178, ptr %private.contiguous.address585, align 4
  %1179 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1180 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1181 = add <8 x i64> %1180, splat (i64 384)
  %1182 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1179, 0
  %1183 = insertvalue { <8 x ptr>, <8 x i64> } %1182, <8 x i64> %1181, 1
  %1184 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1185 = extractvalue { <8 x ptr>, <8 x i64> } %1183, 1
  %1186 = extractelement <8 x ptr> %1184, i32 0
  %1187 = extractelement <8 x i64> %1185, i32 0
  %1188 = sub i64 %1187, 0
  %1189 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1190 = select i1 %1189, i64 %1188, i64 0
  %private.contiguous.address587 = getelementptr i8, ptr %1186, i64 %1190
  %private.contiguous.preserve588 = load <8 x float>, ptr %private.contiguous.address587, align 4
  %1191 = select <8 x i1> %71, <8 x float> %1002, <8 x float> %private.contiguous.preserve588
  store <8 x float> %1191, ptr %private.contiguous.address587, align 4
  %1192 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1193 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1194 = add <8 x i64> %1193, splat (i64 416)
  %1195 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1192, 0
  %1196 = insertvalue { <8 x ptr>, <8 x i64> } %1195, <8 x i64> %1194, 1
  %1197 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1198 = extractvalue { <8 x ptr>, <8 x i64> } %1196, 1
  %1199 = extractelement <8 x ptr> %1197, i32 0
  %1200 = extractelement <8 x i64> %1198, i32 0
  %1201 = sub i64 %1200, 0
  %1202 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1203 = select i1 %1202, i64 %1201, i64 0
  %private.contiguous.address589 = getelementptr i8, ptr %1199, i64 %1203
  %private.contiguous.preserve590 = load <8 x float>, ptr %private.contiguous.address589, align 4
  %1204 = select <8 x i1> %71, <8 x float> %1005, <8 x float> %private.contiguous.preserve590
  store <8 x float> %1204, ptr %private.contiguous.address589, align 4
  %1205 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1206 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1207 = add <8 x i64> %1206, splat (i64 448)
  %1208 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1205, 0
  %1209 = insertvalue { <8 x ptr>, <8 x i64> } %1208, <8 x i64> %1207, 1
  %1210 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1211 = extractvalue { <8 x ptr>, <8 x i64> } %1209, 1
  %1212 = extractelement <8 x ptr> %1210, i32 0
  %1213 = extractelement <8 x i64> %1211, i32 0
  %1214 = sub i64 %1213, 0
  %1215 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1216 = select i1 %1215, i64 %1214, i64 0
  %private.contiguous.address591 = getelementptr i8, ptr %1212, i64 %1216
  %private.contiguous.preserve592 = load <8 x float>, ptr %private.contiguous.address591, align 4
  %1217 = select <8 x i1> %71, <8 x float> %1008, <8 x float> %private.contiguous.preserve592
  store <8 x float> %1217, ptr %private.contiguous.address591, align 4
  %1218 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1219 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1220 = add <8 x i64> %1219, splat (i64 480)
  %1221 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1218, 0
  %1222 = insertvalue { <8 x ptr>, <8 x i64> } %1221, <8 x i64> %1220, 1
  %1223 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1224 = extractvalue { <8 x ptr>, <8 x i64> } %1222, 1
  %1225 = extractelement <8 x ptr> %1223, i32 0
  %1226 = extractelement <8 x i64> %1224, i32 0
  %1227 = sub i64 %1226, 0
  %1228 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1229 = select i1 %1228, i64 %1227, i64 0
  %private.contiguous.address593 = getelementptr i8, ptr %1225, i64 %1229
  %private.contiguous.preserve594 = load <8 x float>, ptr %private.contiguous.address593, align 4
  %1230 = select <8 x i1> %71, <8 x float> %1011, <8 x float> %private.contiguous.preserve594
  store <8 x float> %1230, ptr %private.contiguous.address593, align 4
  store i64 0, ptr %.slot113, align 4
  %1231 = load <8 x float>, ptr %.slot114, align 32
  %1232 = select <8 x i1> %71, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %1231
  store <8 x float> %1232, ptr %.slot114, align 32
  br label %direct.schedule.67

direct.schedule.67:                               ; preds = %direct.schedule.68, %direct.schedule.66
  %.state595 = load i64, ptr %.slot113, align 4
  %1233 = icmp slt i64 %.state595, 16
  br i1 %1233, label %direct.true596, label %direct.false597

direct.schedule.68:                               ; preds = %direct.true596
  %.state598 = load i64, ptr %.slot113, align 4
  %1234 = sdiv i64 %.state598, 1
  %.spill.load599 = load i64, ptr %.spill79, align 4
  %1235 = mul i64 %.spill.load599, 1
  %1236 = add i64 %1235, 0
  %1237 = mul i64 %1236, 1
  %1238 = add i64 %1237, 0
  %1239 = mul i64 %1238, 16
  %1240 = add i64 %1239, %1234
  %tile_snapshot.spill.load600 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill112, align 64
  %1241 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load600, 0
  %1242 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load600, 1
  %.splatinsert601 = insertelement <8 x i64> poison, i64 %1240, i64 0
  %.splat602 = shufflevector <8 x i64> %.splatinsert601, <8 x i64> poison, <8 x i32> zeroinitializer
  %1243 = mul <8 x i64> %.splat602, splat (i64 32)
  %1244 = add <8 x i64> %1242, %1243
  %1245 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1241, 0
  %1246 = insertvalue { <8 x ptr>, <8 x i64> } %1245, <8 x i64> %1244, 1
  %1247 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1248 = extractvalue { <8 x ptr>, <8 x i64> } %1246, 1
  %1249 = extractelement <8 x ptr> %1247, i32 0
  %1250 = extractelement <8 x i64> %1248, i32 0
  %1251 = sub i64 %1250, 0
  %1252 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1253 = select i1 %1252, i64 %1251, i64 0
  %private.contiguous.address603 = getelementptr i8, ptr %1249, i64 %1253
  %private.contiguous.load604 = load <8 x float>, ptr %private.contiguous.address603, align 4
  %1254 = select <8 x i1> %71, <8 x float> %private.contiguous.load604, <8 x float> zeroinitializer
  %.state605 = load <8 x float>, ptr %.slot114, align 32
  %1255 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state605, <8 x float> %1254)
  %.state606 = load i64, ptr %.slot113, align 4
  %1256 = add i64 %.state606, 1
  store i64 %1256, ptr %.slot113, align 4
  %1257 = load <8 x float>, ptr %.slot114, align 32
  %1258 = select <8 x i1> %71, <8 x float> %1255, <8 x float> %1257
  store <8 x float> %1258, ptr %.slot114, align 32
  br label %direct.schedule.67

direct.schedule.69:                               ; preds = %direct.false597
  %.state607 = load <8 x float>, ptr %.slot36, align 32
  %.state608 = load <8 x float>, ptr %.slot114, align 32
  %1259 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state607, <8 x float> %.state608)
  %1260 = load <8 x float>, ptr %.spill115, align 32
  %1261 = select <8 x i1> %71, <8 x float> %1259, <8 x float> %1260
  store <8 x float> %1261, ptr %.spill115, align 32
  %.state609 = load <8 x float>, ptr %.slot36, align 32
  %1262 = fsub <8 x float> %.state609, %1259
  %1263 = select <8 x i1> %71, <8 x float> %1262, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1263)
  %1264 = load <8 x float>, ptr %.spill116, align 32
  %1265 = select <8 x i1> %71, <8 x float> %native.exp, <8 x float> %1264
  store <8 x float> %1265, ptr %.spill116, align 32
  %.spill.load610 = load <8 x float>, ptr %.spill96, align 32
  %1266 = fsub <8 x float> %.spill.load610, %1259
  %.spill.load611 = load <8 x float>, ptr %.spill97, align 32
  %1267 = fsub <8 x float> %.spill.load611, %1259
  %.spill.load612 = load <8 x float>, ptr %.spill98, align 32
  %1268 = fsub <8 x float> %.spill.load612, %1259
  %.spill.load613 = load <8 x float>, ptr %.spill99, align 32
  %1269 = fsub <8 x float> %.spill.load613, %1259
  %.spill.load614 = load <8 x float>, ptr %.spill100, align 32
  %1270 = fsub <8 x float> %.spill.load614, %1259
  %.spill.load615 = load <8 x float>, ptr %.spill101, align 32
  %1271 = fsub <8 x float> %.spill.load615, %1259
  %.spill.load616 = load <8 x float>, ptr %.spill102, align 32
  %1272 = fsub <8 x float> %.spill.load616, %1259
  %.spill.load617 = load <8 x float>, ptr %.spill103, align 32
  %1273 = fsub <8 x float> %.spill.load617, %1259
  %.spill.load618 = load <8 x float>, ptr %.spill104, align 32
  %1274 = fsub <8 x float> %.spill.load618, %1259
  %.spill.load619 = load <8 x float>, ptr %.spill105, align 32
  %1275 = fsub <8 x float> %.spill.load619, %1259
  %.spill.load620 = load <8 x float>, ptr %.spill106, align 32
  %1276 = fsub <8 x float> %.spill.load620, %1259
  %.spill.load621 = load <8 x float>, ptr %.spill107, align 32
  %1277 = fsub <8 x float> %.spill.load621, %1259
  %.spill.load622 = load <8 x float>, ptr %.spill108, align 32
  %1278 = fsub <8 x float> %.spill.load622, %1259
  %.spill.load623 = load <8 x float>, ptr %.spill109, align 32
  %1279 = fsub <8 x float> %.spill.load623, %1259
  %.spill.load624 = load <8 x float>, ptr %.spill110, align 32
  %1280 = fsub <8 x float> %.spill.load624, %1259
  %.spill.load625 = load <8 x float>, ptr %.spill111, align 32
  %1281 = fsub <8 x float> %.spill.load625, %1259
  %1282 = select <8 x i1> %71, <8 x float> %1266, <8 x float> zeroinitializer
  %native.exp626 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1282)
  %1283 = select <8 x i1> %71, <8 x float> %1267, <8 x float> zeroinitializer
  %native.exp627 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1283)
  %1284 = select <8 x i1> %71, <8 x float> %1268, <8 x float> zeroinitializer
  %native.exp628 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1284)
  %1285 = select <8 x i1> %71, <8 x float> %1269, <8 x float> zeroinitializer
  %native.exp629 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1285)
  %1286 = select <8 x i1> %71, <8 x float> %1270, <8 x float> zeroinitializer
  %native.exp630 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1286)
  %1287 = select <8 x i1> %71, <8 x float> %1271, <8 x float> zeroinitializer
  %native.exp631 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1287)
  %1288 = select <8 x i1> %71, <8 x float> %1272, <8 x float> zeroinitializer
  %native.exp632 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1288)
  %1289 = select <8 x i1> %71, <8 x float> %1273, <8 x float> zeroinitializer
  %native.exp633 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1289)
  %1290 = select <8 x i1> %71, <8 x float> %1274, <8 x float> zeroinitializer
  %native.exp634 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1290)
  %1291 = select <8 x i1> %71, <8 x float> %1275, <8 x float> zeroinitializer
  %native.exp635 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1291)
  %1292 = select <8 x i1> %71, <8 x float> %1276, <8 x float> zeroinitializer
  %native.exp636 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1292)
  %1293 = select <8 x i1> %71, <8 x float> %1277, <8 x float> zeroinitializer
  %native.exp637 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1293)
  %1294 = select <8 x i1> %71, <8 x float> %1278, <8 x float> zeroinitializer
  %native.exp638 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1294)
  %1295 = select <8 x i1> %71, <8 x float> %1279, <8 x float> zeroinitializer
  %native.exp639 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1295)
  %1296 = select <8 x i1> %71, <8 x float> %1280, <8 x float> zeroinitializer
  %native.exp640 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1296)
  %1297 = select <8 x i1> %71, <8 x float> %1281, <8 x float> zeroinitializer
  %native.exp641 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1297)
  %.spill.load642 = load i1, ptr %.spill80, align 1
  %.splatinsert643 = insertelement <8 x i1> poison, i1 %.spill.load642, i64 0
  %.splat644 = shufflevector <8 x i1> %.splatinsert643, <8 x i1> poison, <8 x i32> zeroinitializer
  %1298 = select <8 x i1> %.splat644, <8 x float> %native.exp626, <8 x float> zeroinitializer
  %1299 = load <8 x float>, ptr %.spill117, align 32
  %1300 = select <8 x i1> %71, <8 x float> %1298, <8 x float> %1299
  store <8 x float> %1300, ptr %.spill117, align 32
  %.spill.load645 = load i1, ptr %.spill81, align 1
  %.splatinsert646 = insertelement <8 x i1> poison, i1 %.spill.load645, i64 0
  %.splat647 = shufflevector <8 x i1> %.splatinsert646, <8 x i1> poison, <8 x i32> zeroinitializer
  %1301 = select <8 x i1> %.splat647, <8 x float> %native.exp627, <8 x float> zeroinitializer
  %1302 = load <8 x float>, ptr %.spill118, align 32
  %1303 = select <8 x i1> %71, <8 x float> %1301, <8 x float> %1302
  store <8 x float> %1303, ptr %.spill118, align 32
  %.spill.load648 = load i1, ptr %.spill82, align 1
  %.splatinsert649 = insertelement <8 x i1> poison, i1 %.spill.load648, i64 0
  %.splat650 = shufflevector <8 x i1> %.splatinsert649, <8 x i1> poison, <8 x i32> zeroinitializer
  %1304 = select <8 x i1> %.splat650, <8 x float> %native.exp628, <8 x float> zeroinitializer
  %1305 = load <8 x float>, ptr %.spill119, align 32
  %1306 = select <8 x i1> %71, <8 x float> %1304, <8 x float> %1305
  store <8 x float> %1306, ptr %.spill119, align 32
  %.spill.load651 = load i1, ptr %.spill83, align 1
  %.splatinsert652 = insertelement <8 x i1> poison, i1 %.spill.load651, i64 0
  %.splat653 = shufflevector <8 x i1> %.splatinsert652, <8 x i1> poison, <8 x i32> zeroinitializer
  %1307 = select <8 x i1> %.splat653, <8 x float> %native.exp629, <8 x float> zeroinitializer
  %1308 = load <8 x float>, ptr %.spill120, align 32
  %1309 = select <8 x i1> %71, <8 x float> %1307, <8 x float> %1308
  store <8 x float> %1309, ptr %.spill120, align 32
  %.spill.load654 = load i1, ptr %.spill84, align 1
  %.splatinsert655 = insertelement <8 x i1> poison, i1 %.spill.load654, i64 0
  %.splat656 = shufflevector <8 x i1> %.splatinsert655, <8 x i1> poison, <8 x i32> zeroinitializer
  %1310 = select <8 x i1> %.splat656, <8 x float> %native.exp630, <8 x float> zeroinitializer
  %1311 = load <8 x float>, ptr %.spill121, align 32
  %1312 = select <8 x i1> %71, <8 x float> %1310, <8 x float> %1311
  store <8 x float> %1312, ptr %.spill121, align 32
  %.spill.load657 = load i1, ptr %.spill85, align 1
  %.splatinsert658 = insertelement <8 x i1> poison, i1 %.spill.load657, i64 0
  %.splat659 = shufflevector <8 x i1> %.splatinsert658, <8 x i1> poison, <8 x i32> zeroinitializer
  %1313 = select <8 x i1> %.splat659, <8 x float> %native.exp631, <8 x float> zeroinitializer
  %1314 = load <8 x float>, ptr %.spill122, align 32
  %1315 = select <8 x i1> %71, <8 x float> %1313, <8 x float> %1314
  store <8 x float> %1315, ptr %.spill122, align 32
  %.spill.load660 = load i1, ptr %.spill86, align 1
  %.splatinsert661 = insertelement <8 x i1> poison, i1 %.spill.load660, i64 0
  %.splat662 = shufflevector <8 x i1> %.splatinsert661, <8 x i1> poison, <8 x i32> zeroinitializer
  %1316 = select <8 x i1> %.splat662, <8 x float> %native.exp632, <8 x float> zeroinitializer
  %1317 = load <8 x float>, ptr %.spill123, align 32
  %1318 = select <8 x i1> %71, <8 x float> %1316, <8 x float> %1317
  store <8 x float> %1318, ptr %.spill123, align 32
  %.spill.load663 = load i1, ptr %.spill87, align 1
  %.splatinsert664 = insertelement <8 x i1> poison, i1 %.spill.load663, i64 0
  %.splat665 = shufflevector <8 x i1> %.splatinsert664, <8 x i1> poison, <8 x i32> zeroinitializer
  %1319 = select <8 x i1> %.splat665, <8 x float> %native.exp633, <8 x float> zeroinitializer
  %1320 = load <8 x float>, ptr %.spill124, align 32
  %1321 = select <8 x i1> %71, <8 x float> %1319, <8 x float> %1320
  store <8 x float> %1321, ptr %.spill124, align 32
  %.spill.load666 = load i1, ptr %.spill88, align 1
  %.splatinsert667 = insertelement <8 x i1> poison, i1 %.spill.load666, i64 0
  %.splat668 = shufflevector <8 x i1> %.splatinsert667, <8 x i1> poison, <8 x i32> zeroinitializer
  %1322 = select <8 x i1> %.splat668, <8 x float> %native.exp634, <8 x float> zeroinitializer
  %1323 = load <8 x float>, ptr %.spill125, align 32
  %1324 = select <8 x i1> %71, <8 x float> %1322, <8 x float> %1323
  store <8 x float> %1324, ptr %.spill125, align 32
  %.spill.load669 = load i1, ptr %.spill89, align 1
  %.splatinsert670 = insertelement <8 x i1> poison, i1 %.spill.load669, i64 0
  %.splat671 = shufflevector <8 x i1> %.splatinsert670, <8 x i1> poison, <8 x i32> zeroinitializer
  %1325 = select <8 x i1> %.splat671, <8 x float> %native.exp635, <8 x float> zeroinitializer
  %1326 = load <8 x float>, ptr %.spill126, align 32
  %1327 = select <8 x i1> %71, <8 x float> %1325, <8 x float> %1326
  store <8 x float> %1327, ptr %.spill126, align 32
  %.spill.load672 = load i1, ptr %.spill90, align 1
  %.splatinsert673 = insertelement <8 x i1> poison, i1 %.spill.load672, i64 0
  %.splat674 = shufflevector <8 x i1> %.splatinsert673, <8 x i1> poison, <8 x i32> zeroinitializer
  %1328 = select <8 x i1> %.splat674, <8 x float> %native.exp636, <8 x float> zeroinitializer
  %1329 = load <8 x float>, ptr %.spill127, align 32
  %1330 = select <8 x i1> %71, <8 x float> %1328, <8 x float> %1329
  store <8 x float> %1330, ptr %.spill127, align 32
  %.spill.load675 = load i1, ptr %.spill91, align 1
  %.splatinsert676 = insertelement <8 x i1> poison, i1 %.spill.load675, i64 0
  %.splat677 = shufflevector <8 x i1> %.splatinsert676, <8 x i1> poison, <8 x i32> zeroinitializer
  %1331 = select <8 x i1> %.splat677, <8 x float> %native.exp637, <8 x float> zeroinitializer
  %1332 = load <8 x float>, ptr %.spill128, align 32
  %1333 = select <8 x i1> %71, <8 x float> %1331, <8 x float> %1332
  store <8 x float> %1333, ptr %.spill128, align 32
  %.spill.load678 = load i1, ptr %.spill92, align 1
  %.splatinsert679 = insertelement <8 x i1> poison, i1 %.spill.load678, i64 0
  %.splat680 = shufflevector <8 x i1> %.splatinsert679, <8 x i1> poison, <8 x i32> zeroinitializer
  %1334 = select <8 x i1> %.splat680, <8 x float> %native.exp638, <8 x float> zeroinitializer
  %1335 = load <8 x float>, ptr %.spill129, align 32
  %1336 = select <8 x i1> %71, <8 x float> %1334, <8 x float> %1335
  store <8 x float> %1336, ptr %.spill129, align 32
  %.spill.load681 = load i1, ptr %.spill93, align 1
  %.splatinsert682 = insertelement <8 x i1> poison, i1 %.spill.load681, i64 0
  %.splat683 = shufflevector <8 x i1> %.splatinsert682, <8 x i1> poison, <8 x i32> zeroinitializer
  %1337 = select <8 x i1> %.splat683, <8 x float> %native.exp639, <8 x float> zeroinitializer
  %1338 = load <8 x float>, ptr %.spill130, align 32
  %1339 = select <8 x i1> %71, <8 x float> %1337, <8 x float> %1338
  store <8 x float> %1339, ptr %.spill130, align 32
  %.spill.load684 = load i1, ptr %.spill94, align 1
  %.splatinsert685 = insertelement <8 x i1> poison, i1 %.spill.load684, i64 0
  %.splat686 = shufflevector <8 x i1> %.splatinsert685, <8 x i1> poison, <8 x i32> zeroinitializer
  %1340 = select <8 x i1> %.splat686, <8 x float> %native.exp640, <8 x float> zeroinitializer
  %1341 = load <8 x float>, ptr %.spill131, align 32
  %1342 = select <8 x i1> %71, <8 x float> %1340, <8 x float> %1341
  store <8 x float> %1342, ptr %.spill131, align 32
  %.spill.load687 = load i1, ptr %.spill95, align 1
  %.splatinsert688 = insertelement <8 x i1> poison, i1 %.spill.load687, i64 0
  %.splat689 = shufflevector <8 x i1> %.splatinsert688, <8 x i1> poison, <8 x i32> zeroinitializer
  %1343 = select <8 x i1> %.splat689, <8 x float> %native.exp641, <8 x float> zeroinitializer
  %1344 = load <8 x float>, ptr %.spill132, align 32
  %1345 = select <8 x i1> %71, <8 x float> %1343, <8 x float> %1344
  store <8 x float> %1345, ptr %.spill132, align 32
  %1346 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %1347 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1348 = extractvalue { <8 x ptr>, <8 x i64> } %1346, 0
  %1349 = select <8 x i1> %71, <8 x ptr> %1347, <8 x ptr> %1348
  %1350 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1351 = extractvalue { <8 x ptr>, <8 x i64> } %1346, 1
  %1352 = select <8 x i1> %71, <8 x i64> %1350, <8 x i64> %1351
  %1353 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1349, 0
  %1354 = insertvalue { <8 x ptr>, <8 x i64> } %1353, <8 x i64> %1352, 1
  store { <8 x ptr>, <8 x i64> } %1354, ptr %tile_snapshot.spill133, align 64
  %1355 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1356 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1357 = add <8 x i64> %1356, zeroinitializer
  %1358 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1355, 0
  %1359 = insertvalue { <8 x ptr>, <8 x i64> } %1358, <8 x i64> %1357, 1
  %1360 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1361 = extractvalue { <8 x ptr>, <8 x i64> } %1359, 1
  %1362 = extractelement <8 x ptr> %1360, i32 0
  %1363 = extractelement <8 x i64> %1361, i32 0
  %1364 = sub i64 %1363, 0
  %1365 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1366 = select i1 %1365, i64 %1364, i64 0
  %private.contiguous.address690 = getelementptr i8, ptr %1362, i64 %1366
  %private.contiguous.preserve691 = load <8 x float>, ptr %private.contiguous.address690, align 4
  %1367 = select <8 x i1> %71, <8 x float> %1298, <8 x float> %private.contiguous.preserve691
  store <8 x float> %1367, ptr %private.contiguous.address690, align 4
  %1368 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1369 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1370 = add <8 x i64> %1369, splat (i64 32)
  %1371 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1368, 0
  %1372 = insertvalue { <8 x ptr>, <8 x i64> } %1371, <8 x i64> %1370, 1
  %1373 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1374 = extractvalue { <8 x ptr>, <8 x i64> } %1372, 1
  %1375 = extractelement <8 x ptr> %1373, i32 0
  %1376 = extractelement <8 x i64> %1374, i32 0
  %1377 = sub i64 %1376, 0
  %1378 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1379 = select i1 %1378, i64 %1377, i64 0
  %private.contiguous.address692 = getelementptr i8, ptr %1375, i64 %1379
  %private.contiguous.preserve693 = load <8 x float>, ptr %private.contiguous.address692, align 4
  %1380 = select <8 x i1> %71, <8 x float> %1301, <8 x float> %private.contiguous.preserve693
  store <8 x float> %1380, ptr %private.contiguous.address692, align 4
  %1381 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1382 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1383 = add <8 x i64> %1382, splat (i64 64)
  %1384 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1381, 0
  %1385 = insertvalue { <8 x ptr>, <8 x i64> } %1384, <8 x i64> %1383, 1
  %1386 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1387 = extractvalue { <8 x ptr>, <8 x i64> } %1385, 1
  %1388 = extractelement <8 x ptr> %1386, i32 0
  %1389 = extractelement <8 x i64> %1387, i32 0
  %1390 = sub i64 %1389, 0
  %1391 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1392 = select i1 %1391, i64 %1390, i64 0
  %private.contiguous.address694 = getelementptr i8, ptr %1388, i64 %1392
  %private.contiguous.preserve695 = load <8 x float>, ptr %private.contiguous.address694, align 4
  %1393 = select <8 x i1> %71, <8 x float> %1304, <8 x float> %private.contiguous.preserve695
  store <8 x float> %1393, ptr %private.contiguous.address694, align 4
  %1394 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1395 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1396 = add <8 x i64> %1395, splat (i64 96)
  %1397 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1394, 0
  %1398 = insertvalue { <8 x ptr>, <8 x i64> } %1397, <8 x i64> %1396, 1
  %1399 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1400 = extractvalue { <8 x ptr>, <8 x i64> } %1398, 1
  %1401 = extractelement <8 x ptr> %1399, i32 0
  %1402 = extractelement <8 x i64> %1400, i32 0
  %1403 = sub i64 %1402, 0
  %1404 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1405 = select i1 %1404, i64 %1403, i64 0
  %private.contiguous.address696 = getelementptr i8, ptr %1401, i64 %1405
  %private.contiguous.preserve697 = load <8 x float>, ptr %private.contiguous.address696, align 4
  %1406 = select <8 x i1> %71, <8 x float> %1307, <8 x float> %private.contiguous.preserve697
  store <8 x float> %1406, ptr %private.contiguous.address696, align 4
  %1407 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1408 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1409 = add <8 x i64> %1408, splat (i64 128)
  %1410 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1407, 0
  %1411 = insertvalue { <8 x ptr>, <8 x i64> } %1410, <8 x i64> %1409, 1
  %1412 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1413 = extractvalue { <8 x ptr>, <8 x i64> } %1411, 1
  %1414 = extractelement <8 x ptr> %1412, i32 0
  %1415 = extractelement <8 x i64> %1413, i32 0
  %1416 = sub i64 %1415, 0
  %1417 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1418 = select i1 %1417, i64 %1416, i64 0
  %private.contiguous.address698 = getelementptr i8, ptr %1414, i64 %1418
  %private.contiguous.preserve699 = load <8 x float>, ptr %private.contiguous.address698, align 4
  %1419 = select <8 x i1> %71, <8 x float> %1310, <8 x float> %private.contiguous.preserve699
  store <8 x float> %1419, ptr %private.contiguous.address698, align 4
  %1420 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1421 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1422 = add <8 x i64> %1421, splat (i64 160)
  %1423 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1420, 0
  %1424 = insertvalue { <8 x ptr>, <8 x i64> } %1423, <8 x i64> %1422, 1
  %1425 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1426 = extractvalue { <8 x ptr>, <8 x i64> } %1424, 1
  %1427 = extractelement <8 x ptr> %1425, i32 0
  %1428 = extractelement <8 x i64> %1426, i32 0
  %1429 = sub i64 %1428, 0
  %1430 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1431 = select i1 %1430, i64 %1429, i64 0
  %private.contiguous.address700 = getelementptr i8, ptr %1427, i64 %1431
  %private.contiguous.preserve701 = load <8 x float>, ptr %private.contiguous.address700, align 4
  %1432 = select <8 x i1> %71, <8 x float> %1313, <8 x float> %private.contiguous.preserve701
  store <8 x float> %1432, ptr %private.contiguous.address700, align 4
  %1433 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1434 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1435 = add <8 x i64> %1434, splat (i64 192)
  %1436 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1433, 0
  %1437 = insertvalue { <8 x ptr>, <8 x i64> } %1436, <8 x i64> %1435, 1
  %1438 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1439 = extractvalue { <8 x ptr>, <8 x i64> } %1437, 1
  %1440 = extractelement <8 x ptr> %1438, i32 0
  %1441 = extractelement <8 x i64> %1439, i32 0
  %1442 = sub i64 %1441, 0
  %1443 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1444 = select i1 %1443, i64 %1442, i64 0
  %private.contiguous.address702 = getelementptr i8, ptr %1440, i64 %1444
  %private.contiguous.preserve703 = load <8 x float>, ptr %private.contiguous.address702, align 4
  %1445 = select <8 x i1> %71, <8 x float> %1316, <8 x float> %private.contiguous.preserve703
  store <8 x float> %1445, ptr %private.contiguous.address702, align 4
  %1446 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1447 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1448 = add <8 x i64> %1447, splat (i64 224)
  %1449 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1446, 0
  %1450 = insertvalue { <8 x ptr>, <8 x i64> } %1449, <8 x i64> %1448, 1
  %1451 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1452 = extractvalue { <8 x ptr>, <8 x i64> } %1450, 1
  %1453 = extractelement <8 x ptr> %1451, i32 0
  %1454 = extractelement <8 x i64> %1452, i32 0
  %1455 = sub i64 %1454, 0
  %1456 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1457 = select i1 %1456, i64 %1455, i64 0
  %private.contiguous.address704 = getelementptr i8, ptr %1453, i64 %1457
  %private.contiguous.preserve705 = load <8 x float>, ptr %private.contiguous.address704, align 4
  %1458 = select <8 x i1> %71, <8 x float> %1319, <8 x float> %private.contiguous.preserve705
  store <8 x float> %1458, ptr %private.contiguous.address704, align 4
  %1459 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1460 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1461 = add <8 x i64> %1460, splat (i64 256)
  %1462 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1459, 0
  %1463 = insertvalue { <8 x ptr>, <8 x i64> } %1462, <8 x i64> %1461, 1
  %1464 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1465 = extractvalue { <8 x ptr>, <8 x i64> } %1463, 1
  %1466 = extractelement <8 x ptr> %1464, i32 0
  %1467 = extractelement <8 x i64> %1465, i32 0
  %1468 = sub i64 %1467, 0
  %1469 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1470 = select i1 %1469, i64 %1468, i64 0
  %private.contiguous.address706 = getelementptr i8, ptr %1466, i64 %1470
  %private.contiguous.preserve707 = load <8 x float>, ptr %private.contiguous.address706, align 4
  %1471 = select <8 x i1> %71, <8 x float> %1322, <8 x float> %private.contiguous.preserve707
  store <8 x float> %1471, ptr %private.contiguous.address706, align 4
  %1472 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1473 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1474 = add <8 x i64> %1473, splat (i64 288)
  %1475 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1472, 0
  %1476 = insertvalue { <8 x ptr>, <8 x i64> } %1475, <8 x i64> %1474, 1
  %1477 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1478 = extractvalue { <8 x ptr>, <8 x i64> } %1476, 1
  %1479 = extractelement <8 x ptr> %1477, i32 0
  %1480 = extractelement <8 x i64> %1478, i32 0
  %1481 = sub i64 %1480, 0
  %1482 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1483 = select i1 %1482, i64 %1481, i64 0
  %private.contiguous.address708 = getelementptr i8, ptr %1479, i64 %1483
  %private.contiguous.preserve709 = load <8 x float>, ptr %private.contiguous.address708, align 4
  %1484 = select <8 x i1> %71, <8 x float> %1325, <8 x float> %private.contiguous.preserve709
  store <8 x float> %1484, ptr %private.contiguous.address708, align 4
  %1485 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1486 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1487 = add <8 x i64> %1486, splat (i64 320)
  %1488 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1485, 0
  %1489 = insertvalue { <8 x ptr>, <8 x i64> } %1488, <8 x i64> %1487, 1
  %1490 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1491 = extractvalue { <8 x ptr>, <8 x i64> } %1489, 1
  %1492 = extractelement <8 x ptr> %1490, i32 0
  %1493 = extractelement <8 x i64> %1491, i32 0
  %1494 = sub i64 %1493, 0
  %1495 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1496 = select i1 %1495, i64 %1494, i64 0
  %private.contiguous.address710 = getelementptr i8, ptr %1492, i64 %1496
  %private.contiguous.preserve711 = load <8 x float>, ptr %private.contiguous.address710, align 4
  %1497 = select <8 x i1> %71, <8 x float> %1328, <8 x float> %private.contiguous.preserve711
  store <8 x float> %1497, ptr %private.contiguous.address710, align 4
  %1498 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1499 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1500 = add <8 x i64> %1499, splat (i64 352)
  %1501 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1498, 0
  %1502 = insertvalue { <8 x ptr>, <8 x i64> } %1501, <8 x i64> %1500, 1
  %1503 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1504 = extractvalue { <8 x ptr>, <8 x i64> } %1502, 1
  %1505 = extractelement <8 x ptr> %1503, i32 0
  %1506 = extractelement <8 x i64> %1504, i32 0
  %1507 = sub i64 %1506, 0
  %1508 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1509 = select i1 %1508, i64 %1507, i64 0
  %private.contiguous.address712 = getelementptr i8, ptr %1505, i64 %1509
  %private.contiguous.preserve713 = load <8 x float>, ptr %private.contiguous.address712, align 4
  %1510 = select <8 x i1> %71, <8 x float> %1331, <8 x float> %private.contiguous.preserve713
  store <8 x float> %1510, ptr %private.contiguous.address712, align 4
  %1511 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1512 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1513 = add <8 x i64> %1512, splat (i64 384)
  %1514 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1511, 0
  %1515 = insertvalue { <8 x ptr>, <8 x i64> } %1514, <8 x i64> %1513, 1
  %1516 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1517 = extractvalue { <8 x ptr>, <8 x i64> } %1515, 1
  %1518 = extractelement <8 x ptr> %1516, i32 0
  %1519 = extractelement <8 x i64> %1517, i32 0
  %1520 = sub i64 %1519, 0
  %1521 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1522 = select i1 %1521, i64 %1520, i64 0
  %private.contiguous.address714 = getelementptr i8, ptr %1518, i64 %1522
  %private.contiguous.preserve715 = load <8 x float>, ptr %private.contiguous.address714, align 4
  %1523 = select <8 x i1> %71, <8 x float> %1334, <8 x float> %private.contiguous.preserve715
  store <8 x float> %1523, ptr %private.contiguous.address714, align 4
  %1524 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1525 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1526 = add <8 x i64> %1525, splat (i64 416)
  %1527 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1524, 0
  %1528 = insertvalue { <8 x ptr>, <8 x i64> } %1527, <8 x i64> %1526, 1
  %1529 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1530 = extractvalue { <8 x ptr>, <8 x i64> } %1528, 1
  %1531 = extractelement <8 x ptr> %1529, i32 0
  %1532 = extractelement <8 x i64> %1530, i32 0
  %1533 = sub i64 %1532, 0
  %1534 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1535 = select i1 %1534, i64 %1533, i64 0
  %private.contiguous.address716 = getelementptr i8, ptr %1531, i64 %1535
  %private.contiguous.preserve717 = load <8 x float>, ptr %private.contiguous.address716, align 4
  %1536 = select <8 x i1> %71, <8 x float> %1337, <8 x float> %private.contiguous.preserve717
  store <8 x float> %1536, ptr %private.contiguous.address716, align 4
  %1537 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1538 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1539 = add <8 x i64> %1538, splat (i64 448)
  %1540 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1537, 0
  %1541 = insertvalue { <8 x ptr>, <8 x i64> } %1540, <8 x i64> %1539, 1
  %1542 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1543 = extractvalue { <8 x ptr>, <8 x i64> } %1541, 1
  %1544 = extractelement <8 x ptr> %1542, i32 0
  %1545 = extractelement <8 x i64> %1543, i32 0
  %1546 = sub i64 %1545, 0
  %1547 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1548 = select i1 %1547, i64 %1546, i64 0
  %private.contiguous.address718 = getelementptr i8, ptr %1544, i64 %1548
  %private.contiguous.preserve719 = load <8 x float>, ptr %private.contiguous.address718, align 4
  %1549 = select <8 x i1> %71, <8 x float> %1340, <8 x float> %private.contiguous.preserve719
  store <8 x float> %1549, ptr %private.contiguous.address718, align 4
  %1550 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1551 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1552 = add <8 x i64> %1551, splat (i64 480)
  %1553 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1550, 0
  %1554 = insertvalue { <8 x ptr>, <8 x i64> } %1553, <8 x i64> %1552, 1
  %1555 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1556 = extractvalue { <8 x ptr>, <8 x i64> } %1554, 1
  %1557 = extractelement <8 x ptr> %1555, i32 0
  %1558 = extractelement <8 x i64> %1556, i32 0
  %1559 = sub i64 %1558, 0
  %1560 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1561 = select i1 %1560, i64 %1559, i64 0
  %private.contiguous.address720 = getelementptr i8, ptr %1557, i64 %1561
  %private.contiguous.preserve721 = load <8 x float>, ptr %private.contiguous.address720, align 4
  %1562 = select <8 x i1> %71, <8 x float> %1343, <8 x float> %private.contiguous.preserve721
  store <8 x float> %1562, ptr %private.contiguous.address720, align 4
  %.state722 = load <8 x float>, ptr %.slot37, align 32
  %1563 = fmul <8 x float> %.state722, %native.exp
  %1564 = load <8 x float>, ptr %.spill134, align 32
  %1565 = select <8 x i1> %71, <8 x float> %1563, <8 x float> %1564
  store <8 x float> %1565, ptr %.spill134, align 32
  store i64 0, ptr %.slot135, align 4
  %1566 = load <8 x float>, ptr %.slot136, align 32
  %1567 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1566
  store <8 x float> %1567, ptr %.slot136, align 32
  br label %direct.schedule.70

direct.schedule.70:                               ; preds = %direct.schedule.71, %direct.schedule.69
  %.state723 = load i64, ptr %.slot135, align 4
  %1568 = icmp slt i64 %.state723, 16
  br i1 %1568, label %direct.true724, label %direct.false725

direct.schedule.71:                               ; preds = %direct.true724
  %.state726 = load i64, ptr %.slot135, align 4
  %1569 = sdiv i64 %.state726, 1
  %.spill.load727 = load i64, ptr %.spill79, align 4
  %1570 = mul i64 %.spill.load727, 1
  %1571 = add i64 %1570, 0
  %1572 = mul i64 %1571, 1
  %1573 = add i64 %1572, 0
  %1574 = mul i64 %1573, 16
  %1575 = add i64 %1574, %1569
  %tile_snapshot.spill.load728 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %1576 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load728, 0
  %1577 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load728, 1
  %.splatinsert729 = insertelement <8 x i64> poison, i64 %1575, i64 0
  %.splat730 = shufflevector <8 x i64> %.splatinsert729, <8 x i64> poison, <8 x i32> zeroinitializer
  %1578 = mul <8 x i64> %.splat730, splat (i64 32)
  %1579 = add <8 x i64> %1577, %1578
  %1580 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1576, 0
  %1581 = insertvalue { <8 x ptr>, <8 x i64> } %1580, <8 x i64> %1579, 1
  %1582 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1583 = extractvalue { <8 x ptr>, <8 x i64> } %1581, 1
  %1584 = extractelement <8 x ptr> %1582, i32 0
  %1585 = extractelement <8 x i64> %1583, i32 0
  %1586 = sub i64 %1585, 0
  %1587 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1588 = select i1 %1587, i64 %1586, i64 0
  %private.contiguous.address731 = getelementptr i8, ptr %1584, i64 %1588
  %private.contiguous.load732 = load <8 x float>, ptr %private.contiguous.address731, align 4
  %1589 = select <8 x i1> %71, <8 x float> %private.contiguous.load732, <8 x float> zeroinitializer
  %.state733 = load <8 x float>, ptr %.slot136, align 32
  %1590 = fadd <8 x float> %.state733, %1589
  %.state734 = load i64, ptr %.slot135, align 4
  %1591 = add i64 %.state734, 1
  store i64 %1591, ptr %.slot135, align 4
  %1592 = load <8 x float>, ptr %.slot136, align 32
  %1593 = select <8 x i1> %71, <8 x float> %1590, <8 x float> %1592
  store <8 x float> %1593, ptr %.slot136, align 32
  br label %direct.schedule.70

direct.schedule.72:                               ; preds = %direct.false725
  %.spill.load735 = load <8 x float>, ptr %.spill134, align 32
  %.state736 = load <8 x float>, ptr %.slot136, align 32
  %1594 = fadd <8 x float> %.spill.load735, %.state736
  %1595 = load <8 x float>, ptr %.spill137, align 32
  %1596 = select <8 x i1> %71, <8 x float> %1594, <8 x float> %1595
  store <8 x float> %1596, ptr %.spill137, align 32
  %1597 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill138, align 64
  %1598 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1599 = extractvalue { <8 x ptr>, <8 x i64> } %1597, 0
  %1600 = select <8 x i1> %71, <8 x ptr> %1598, <8 x ptr> %1599
  %1601 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1602 = extractvalue { <8 x ptr>, <8 x i64> } %1597, 1
  %1603 = select <8 x i1> %71, <8 x i64> %1601, <8 x i64> %1602
  %1604 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1600, 0
  %1605 = insertvalue { <8 x ptr>, <8 x i64> } %1604, <8 x i64> %1603, 1
  store { <8 x ptr>, <8 x i64> } %1605, ptr %tile_snapshot.spill138, align 64
  store i64 0, ptr %.slot139, align 4
  br label %direct.schedule.73

direct.schedule.73:                               ; preds = %direct.schedule.74, %direct.schedule.72
  %.state737 = load i64, ptr %.slot139, align 4
  %1606 = icmp slt i64 %.state737, 96
  br i1 %1606, label %direct.true738, label %direct.false739

direct.schedule.74:                               ; preds = %direct.true738
  %.state740 = load i64, ptr %.slot139, align 4
  %1607 = add i64 0, %.state740
  %tile_snapshot.spill.load741 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1608 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load741, 0
  %1609 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load741, 1
  %.splatinsert742 = insertelement <8 x i64> poison, i64 %1607, i64 0
  %.splat743 = shufflevector <8 x i64> %.splatinsert742, <8 x i64> poison, <8 x i32> zeroinitializer
  %1610 = mul <8 x i64> %.splat743, splat (i64 32)
  %1611 = add <8 x i64> %1609, %1610
  %1612 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1608, 0
  %1613 = insertvalue { <8 x ptr>, <8 x i64> } %1612, <8 x i64> %1611, 1
  %1614 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1615 = extractvalue { <8 x ptr>, <8 x i64> } %1613, 1
  %1616 = extractelement <8 x ptr> %1614, i32 0
  %1617 = extractelement <8 x i64> %1615, i32 0
  %1618 = sub i64 %1617, 0
  %1619 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1620 = select i1 %1619, i64 %1618, i64 0
  %private.contiguous.address744 = getelementptr i8, ptr %1616, i64 %1620
  %private.contiguous.load745 = load <8 x float>, ptr %private.contiguous.address744, align 4
  %1621 = select <8 x i1> %71, <8 x float> %private.contiguous.load745, <8 x float> zeroinitializer
  %.spill.load746 = load <8 x float>, ptr %.spill116, align 32
  %1622 = fmul <8 x float> %1621, %.spill.load746
  %tile_snapshot.spill.load747 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1623 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load747, 0
  %1624 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load747, 1
  %.splatinsert748 = insertelement <8 x i64> poison, i64 %1607, i64 0
  %.splat749 = shufflevector <8 x i64> %.splatinsert748, <8 x i64> poison, <8 x i32> zeroinitializer
  %1625 = mul <8 x i64> %.splat749, splat (i64 32)
  %1626 = add <8 x i64> %1624, %1625
  %1627 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1623, 0
  %1628 = insertvalue { <8 x ptr>, <8 x i64> } %1627, <8 x i64> %1626, 1
  %1629 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1630 = extractvalue { <8 x ptr>, <8 x i64> } %1628, 1
  %1631 = extractelement <8 x ptr> %1629, i32 0
  %1632 = extractelement <8 x i64> %1630, i32 0
  %1633 = sub i64 %1632, 0
  %1634 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1635 = select i1 %1634, i64 %1633, i64 0
  %private.contiguous.address750 = getelementptr i8, ptr %1631, i64 %1635
  %private.contiguous.load751 = load <8 x float>, ptr %private.contiguous.address750, align 4
  %1636 = select <8 x i1> %71, <8 x float> %private.contiguous.load751, <8 x float> zeroinitializer
  %.spill.load752 = load <8 x float>, ptr %.spill117, align 32
  %1637 = fmul <8 x float> %.spill.load752, %1636
  %1638 = fadd <8 x float> %1622, %1637
  %.state753 = load i64, ptr %.slot139, align 4
  %1639 = add i64 96, %.state753
  %tile_snapshot.spill.load754 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1640 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load754, 0
  %1641 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load754, 1
  %.splatinsert755 = insertelement <8 x i64> poison, i64 %1639, i64 0
  %.splat756 = shufflevector <8 x i64> %.splatinsert755, <8 x i64> poison, <8 x i32> zeroinitializer
  %1642 = mul <8 x i64> %.splat756, splat (i64 32)
  %1643 = add <8 x i64> %1641, %1642
  %1644 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1640, 0
  %1645 = insertvalue { <8 x ptr>, <8 x i64> } %1644, <8 x i64> %1643, 1
  %1646 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1647 = extractvalue { <8 x ptr>, <8 x i64> } %1645, 1
  %1648 = extractelement <8 x ptr> %1646, i32 0
  %1649 = extractelement <8 x i64> %1647, i32 0
  %1650 = sub i64 %1649, 0
  %1651 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1652 = select i1 %1651, i64 %1650, i64 0
  %private.contiguous.address757 = getelementptr i8, ptr %1648, i64 %1652
  %private.contiguous.load758 = load <8 x float>, ptr %private.contiguous.address757, align 4
  %1653 = select <8 x i1> %71, <8 x float> %private.contiguous.load758, <8 x float> zeroinitializer
  %.spill.load759 = load <8 x float>, ptr %.spill118, align 32
  %1654 = fmul <8 x float> %.spill.load759, %1653
  %1655 = fadd <8 x float> %1638, %1654
  %.state760 = load i64, ptr %.slot139, align 4
  %1656 = add i64 192, %.state760
  %tile_snapshot.spill.load761 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1657 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load761, 0
  %1658 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load761, 1
  %.splatinsert762 = insertelement <8 x i64> poison, i64 %1656, i64 0
  %.splat763 = shufflevector <8 x i64> %.splatinsert762, <8 x i64> poison, <8 x i32> zeroinitializer
  %1659 = mul <8 x i64> %.splat763, splat (i64 32)
  %1660 = add <8 x i64> %1658, %1659
  %1661 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1657, 0
  %1662 = insertvalue { <8 x ptr>, <8 x i64> } %1661, <8 x i64> %1660, 1
  %1663 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1664 = extractvalue { <8 x ptr>, <8 x i64> } %1662, 1
  %1665 = extractelement <8 x ptr> %1663, i32 0
  %1666 = extractelement <8 x i64> %1664, i32 0
  %1667 = sub i64 %1666, 0
  %1668 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1669 = select i1 %1668, i64 %1667, i64 0
  %private.contiguous.address764 = getelementptr i8, ptr %1665, i64 %1669
  %private.contiguous.load765 = load <8 x float>, ptr %private.contiguous.address764, align 4
  %1670 = select <8 x i1> %71, <8 x float> %private.contiguous.load765, <8 x float> zeroinitializer
  %.spill.load766 = load <8 x float>, ptr %.spill119, align 32
  %1671 = fmul <8 x float> %.spill.load766, %1670
  %1672 = fadd <8 x float> %1655, %1671
  %.state767 = load i64, ptr %.slot139, align 4
  %1673 = add i64 288, %.state767
  %tile_snapshot.spill.load768 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1674 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load768, 0
  %1675 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load768, 1
  %.splatinsert769 = insertelement <8 x i64> poison, i64 %1673, i64 0
  %.splat770 = shufflevector <8 x i64> %.splatinsert769, <8 x i64> poison, <8 x i32> zeroinitializer
  %1676 = mul <8 x i64> %.splat770, splat (i64 32)
  %1677 = add <8 x i64> %1675, %1676
  %1678 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1674, 0
  %1679 = insertvalue { <8 x ptr>, <8 x i64> } %1678, <8 x i64> %1677, 1
  %1680 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1681 = extractvalue { <8 x ptr>, <8 x i64> } %1679, 1
  %1682 = extractelement <8 x ptr> %1680, i32 0
  %1683 = extractelement <8 x i64> %1681, i32 0
  %1684 = sub i64 %1683, 0
  %1685 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1686 = select i1 %1685, i64 %1684, i64 0
  %private.contiguous.address771 = getelementptr i8, ptr %1682, i64 %1686
  %private.contiguous.load772 = load <8 x float>, ptr %private.contiguous.address771, align 4
  %1687 = select <8 x i1> %71, <8 x float> %private.contiguous.load772, <8 x float> zeroinitializer
  %.spill.load773 = load <8 x float>, ptr %.spill120, align 32
  %1688 = fmul <8 x float> %.spill.load773, %1687
  %1689 = fadd <8 x float> %1672, %1688
  %.state774 = load i64, ptr %.slot139, align 4
  %1690 = add i64 384, %.state774
  %tile_snapshot.spill.load775 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1691 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load775, 0
  %1692 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load775, 1
  %.splatinsert776 = insertelement <8 x i64> poison, i64 %1690, i64 0
  %.splat777 = shufflevector <8 x i64> %.splatinsert776, <8 x i64> poison, <8 x i32> zeroinitializer
  %1693 = mul <8 x i64> %.splat777, splat (i64 32)
  %1694 = add <8 x i64> %1692, %1693
  %1695 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1691, 0
  %1696 = insertvalue { <8 x ptr>, <8 x i64> } %1695, <8 x i64> %1694, 1
  %1697 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1698 = extractvalue { <8 x ptr>, <8 x i64> } %1696, 1
  %1699 = extractelement <8 x ptr> %1697, i32 0
  %1700 = extractelement <8 x i64> %1698, i32 0
  %1701 = sub i64 %1700, 0
  %1702 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1703 = select i1 %1702, i64 %1701, i64 0
  %private.contiguous.address778 = getelementptr i8, ptr %1699, i64 %1703
  %private.contiguous.load779 = load <8 x float>, ptr %private.contiguous.address778, align 4
  %1704 = select <8 x i1> %71, <8 x float> %private.contiguous.load779, <8 x float> zeroinitializer
  %.spill.load780 = load <8 x float>, ptr %.spill121, align 32
  %1705 = fmul <8 x float> %.spill.load780, %1704
  %1706 = fadd <8 x float> %1689, %1705
  %.state781 = load i64, ptr %.slot139, align 4
  %1707 = add i64 480, %.state781
  %tile_snapshot.spill.load782 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1708 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load782, 0
  %1709 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load782, 1
  %.splatinsert783 = insertelement <8 x i64> poison, i64 %1707, i64 0
  %.splat784 = shufflevector <8 x i64> %.splatinsert783, <8 x i64> poison, <8 x i32> zeroinitializer
  %1710 = mul <8 x i64> %.splat784, splat (i64 32)
  %1711 = add <8 x i64> %1709, %1710
  %1712 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1708, 0
  %1713 = insertvalue { <8 x ptr>, <8 x i64> } %1712, <8 x i64> %1711, 1
  %1714 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1715 = extractvalue { <8 x ptr>, <8 x i64> } %1713, 1
  %1716 = extractelement <8 x ptr> %1714, i32 0
  %1717 = extractelement <8 x i64> %1715, i32 0
  %1718 = sub i64 %1717, 0
  %1719 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1720 = select i1 %1719, i64 %1718, i64 0
  %private.contiguous.address785 = getelementptr i8, ptr %1716, i64 %1720
  %private.contiguous.load786 = load <8 x float>, ptr %private.contiguous.address785, align 4
  %1721 = select <8 x i1> %71, <8 x float> %private.contiguous.load786, <8 x float> zeroinitializer
  %.spill.load787 = load <8 x float>, ptr %.spill122, align 32
  %1722 = fmul <8 x float> %.spill.load787, %1721
  %1723 = fadd <8 x float> %1706, %1722
  %.state788 = load i64, ptr %.slot139, align 4
  %1724 = add i64 576, %.state788
  %tile_snapshot.spill.load789 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1725 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load789, 0
  %1726 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load789, 1
  %.splatinsert790 = insertelement <8 x i64> poison, i64 %1724, i64 0
  %.splat791 = shufflevector <8 x i64> %.splatinsert790, <8 x i64> poison, <8 x i32> zeroinitializer
  %1727 = mul <8 x i64> %.splat791, splat (i64 32)
  %1728 = add <8 x i64> %1726, %1727
  %1729 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1725, 0
  %1730 = insertvalue { <8 x ptr>, <8 x i64> } %1729, <8 x i64> %1728, 1
  %1731 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1732 = extractvalue { <8 x ptr>, <8 x i64> } %1730, 1
  %1733 = extractelement <8 x ptr> %1731, i32 0
  %1734 = extractelement <8 x i64> %1732, i32 0
  %1735 = sub i64 %1734, 0
  %1736 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1737 = select i1 %1736, i64 %1735, i64 0
  %private.contiguous.address792 = getelementptr i8, ptr %1733, i64 %1737
  %private.contiguous.load793 = load <8 x float>, ptr %private.contiguous.address792, align 4
  %1738 = select <8 x i1> %71, <8 x float> %private.contiguous.load793, <8 x float> zeroinitializer
  %.spill.load794 = load <8 x float>, ptr %.spill123, align 32
  %1739 = fmul <8 x float> %.spill.load794, %1738
  %1740 = fadd <8 x float> %1723, %1739
  %.state795 = load i64, ptr %.slot139, align 4
  %1741 = add i64 672, %.state795
  %tile_snapshot.spill.load796 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1742 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load796, 0
  %1743 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load796, 1
  %.splatinsert797 = insertelement <8 x i64> poison, i64 %1741, i64 0
  %.splat798 = shufflevector <8 x i64> %.splatinsert797, <8 x i64> poison, <8 x i32> zeroinitializer
  %1744 = mul <8 x i64> %.splat798, splat (i64 32)
  %1745 = add <8 x i64> %1743, %1744
  %1746 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1742, 0
  %1747 = insertvalue { <8 x ptr>, <8 x i64> } %1746, <8 x i64> %1745, 1
  %1748 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1749 = extractvalue { <8 x ptr>, <8 x i64> } %1747, 1
  %1750 = extractelement <8 x ptr> %1748, i32 0
  %1751 = extractelement <8 x i64> %1749, i32 0
  %1752 = sub i64 %1751, 0
  %1753 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1754 = select i1 %1753, i64 %1752, i64 0
  %private.contiguous.address799 = getelementptr i8, ptr %1750, i64 %1754
  %private.contiguous.load800 = load <8 x float>, ptr %private.contiguous.address799, align 4
  %1755 = select <8 x i1> %71, <8 x float> %private.contiguous.load800, <8 x float> zeroinitializer
  %.spill.load801 = load <8 x float>, ptr %.spill124, align 32
  %1756 = fmul <8 x float> %.spill.load801, %1755
  %1757 = fadd <8 x float> %1740, %1756
  %.state802 = load i64, ptr %.slot139, align 4
  %1758 = add i64 768, %.state802
  %tile_snapshot.spill.load803 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1759 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load803, 0
  %1760 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load803, 1
  %.splatinsert804 = insertelement <8 x i64> poison, i64 %1758, i64 0
  %.splat805 = shufflevector <8 x i64> %.splatinsert804, <8 x i64> poison, <8 x i32> zeroinitializer
  %1761 = mul <8 x i64> %.splat805, splat (i64 32)
  %1762 = add <8 x i64> %1760, %1761
  %1763 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1759, 0
  %1764 = insertvalue { <8 x ptr>, <8 x i64> } %1763, <8 x i64> %1762, 1
  %1765 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1766 = extractvalue { <8 x ptr>, <8 x i64> } %1764, 1
  %1767 = extractelement <8 x ptr> %1765, i32 0
  %1768 = extractelement <8 x i64> %1766, i32 0
  %1769 = sub i64 %1768, 0
  %1770 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1771 = select i1 %1770, i64 %1769, i64 0
  %private.contiguous.address806 = getelementptr i8, ptr %1767, i64 %1771
  %private.contiguous.load807 = load <8 x float>, ptr %private.contiguous.address806, align 4
  %1772 = select <8 x i1> %71, <8 x float> %private.contiguous.load807, <8 x float> zeroinitializer
  %.spill.load808 = load <8 x float>, ptr %.spill125, align 32
  %1773 = fmul <8 x float> %.spill.load808, %1772
  %1774 = fadd <8 x float> %1757, %1773
  %.state809 = load i64, ptr %.slot139, align 4
  %1775 = add i64 864, %.state809
  %tile_snapshot.spill.load810 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1776 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load810, 0
  %1777 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load810, 1
  %.splatinsert811 = insertelement <8 x i64> poison, i64 %1775, i64 0
  %.splat812 = shufflevector <8 x i64> %.splatinsert811, <8 x i64> poison, <8 x i32> zeroinitializer
  %1778 = mul <8 x i64> %.splat812, splat (i64 32)
  %1779 = add <8 x i64> %1777, %1778
  %1780 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1776, 0
  %1781 = insertvalue { <8 x ptr>, <8 x i64> } %1780, <8 x i64> %1779, 1
  %1782 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1783 = extractvalue { <8 x ptr>, <8 x i64> } %1781, 1
  %1784 = extractelement <8 x ptr> %1782, i32 0
  %1785 = extractelement <8 x i64> %1783, i32 0
  %1786 = sub i64 %1785, 0
  %1787 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1788 = select i1 %1787, i64 %1786, i64 0
  %private.contiguous.address813 = getelementptr i8, ptr %1784, i64 %1788
  %private.contiguous.load814 = load <8 x float>, ptr %private.contiguous.address813, align 4
  %1789 = select <8 x i1> %71, <8 x float> %private.contiguous.load814, <8 x float> zeroinitializer
  %.spill.load815 = load <8 x float>, ptr %.spill126, align 32
  %1790 = fmul <8 x float> %.spill.load815, %1789
  %1791 = fadd <8 x float> %1774, %1790
  %.state816 = load i64, ptr %.slot139, align 4
  %1792 = add i64 960, %.state816
  %tile_snapshot.spill.load817 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1793 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load817, 0
  %1794 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load817, 1
  %.splatinsert818 = insertelement <8 x i64> poison, i64 %1792, i64 0
  %.splat819 = shufflevector <8 x i64> %.splatinsert818, <8 x i64> poison, <8 x i32> zeroinitializer
  %1795 = mul <8 x i64> %.splat819, splat (i64 32)
  %1796 = add <8 x i64> %1794, %1795
  %1797 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1793, 0
  %1798 = insertvalue { <8 x ptr>, <8 x i64> } %1797, <8 x i64> %1796, 1
  %1799 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1800 = extractvalue { <8 x ptr>, <8 x i64> } %1798, 1
  %1801 = extractelement <8 x ptr> %1799, i32 0
  %1802 = extractelement <8 x i64> %1800, i32 0
  %1803 = sub i64 %1802, 0
  %1804 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1805 = select i1 %1804, i64 %1803, i64 0
  %private.contiguous.address820 = getelementptr i8, ptr %1801, i64 %1805
  %private.contiguous.load821 = load <8 x float>, ptr %private.contiguous.address820, align 4
  %1806 = select <8 x i1> %71, <8 x float> %private.contiguous.load821, <8 x float> zeroinitializer
  %.spill.load822 = load <8 x float>, ptr %.spill127, align 32
  %1807 = fmul <8 x float> %.spill.load822, %1806
  %1808 = fadd <8 x float> %1791, %1807
  %.state823 = load i64, ptr %.slot139, align 4
  %1809 = add i64 1056, %.state823
  %tile_snapshot.spill.load824 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1810 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load824, 0
  %1811 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load824, 1
  %.splatinsert825 = insertelement <8 x i64> poison, i64 %1809, i64 0
  %.splat826 = shufflevector <8 x i64> %.splatinsert825, <8 x i64> poison, <8 x i32> zeroinitializer
  %1812 = mul <8 x i64> %.splat826, splat (i64 32)
  %1813 = add <8 x i64> %1811, %1812
  %1814 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1810, 0
  %1815 = insertvalue { <8 x ptr>, <8 x i64> } %1814, <8 x i64> %1813, 1
  %1816 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1817 = extractvalue { <8 x ptr>, <8 x i64> } %1815, 1
  %1818 = extractelement <8 x ptr> %1816, i32 0
  %1819 = extractelement <8 x i64> %1817, i32 0
  %1820 = sub i64 %1819, 0
  %1821 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1822 = select i1 %1821, i64 %1820, i64 0
  %private.contiguous.address827 = getelementptr i8, ptr %1818, i64 %1822
  %private.contiguous.load828 = load <8 x float>, ptr %private.contiguous.address827, align 4
  %1823 = select <8 x i1> %71, <8 x float> %private.contiguous.load828, <8 x float> zeroinitializer
  %.spill.load829 = load <8 x float>, ptr %.spill128, align 32
  %1824 = fmul <8 x float> %.spill.load829, %1823
  %1825 = fadd <8 x float> %1808, %1824
  %.state830 = load i64, ptr %.slot139, align 4
  %1826 = add i64 1152, %.state830
  %tile_snapshot.spill.load831 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1827 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load831, 0
  %1828 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load831, 1
  %.splatinsert832 = insertelement <8 x i64> poison, i64 %1826, i64 0
  %.splat833 = shufflevector <8 x i64> %.splatinsert832, <8 x i64> poison, <8 x i32> zeroinitializer
  %1829 = mul <8 x i64> %.splat833, splat (i64 32)
  %1830 = add <8 x i64> %1828, %1829
  %1831 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1827, 0
  %1832 = insertvalue { <8 x ptr>, <8 x i64> } %1831, <8 x i64> %1830, 1
  %1833 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1834 = extractvalue { <8 x ptr>, <8 x i64> } %1832, 1
  %1835 = extractelement <8 x ptr> %1833, i32 0
  %1836 = extractelement <8 x i64> %1834, i32 0
  %1837 = sub i64 %1836, 0
  %1838 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1839 = select i1 %1838, i64 %1837, i64 0
  %private.contiguous.address834 = getelementptr i8, ptr %1835, i64 %1839
  %private.contiguous.load835 = load <8 x float>, ptr %private.contiguous.address834, align 4
  %1840 = select <8 x i1> %71, <8 x float> %private.contiguous.load835, <8 x float> zeroinitializer
  %.spill.load836 = load <8 x float>, ptr %.spill129, align 32
  %1841 = fmul <8 x float> %.spill.load836, %1840
  %1842 = fadd <8 x float> %1825, %1841
  %.state837 = load i64, ptr %.slot139, align 4
  %1843 = add i64 1248, %.state837
  %tile_snapshot.spill.load838 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1844 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load838, 0
  %1845 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load838, 1
  %.splatinsert839 = insertelement <8 x i64> poison, i64 %1843, i64 0
  %.splat840 = shufflevector <8 x i64> %.splatinsert839, <8 x i64> poison, <8 x i32> zeroinitializer
  %1846 = mul <8 x i64> %.splat840, splat (i64 32)
  %1847 = add <8 x i64> %1845, %1846
  %1848 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1844, 0
  %1849 = insertvalue { <8 x ptr>, <8 x i64> } %1848, <8 x i64> %1847, 1
  %1850 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1851 = extractvalue { <8 x ptr>, <8 x i64> } %1849, 1
  %1852 = extractelement <8 x ptr> %1850, i32 0
  %1853 = extractelement <8 x i64> %1851, i32 0
  %1854 = sub i64 %1853, 0
  %1855 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1856 = select i1 %1855, i64 %1854, i64 0
  %private.contiguous.address841 = getelementptr i8, ptr %1852, i64 %1856
  %private.contiguous.load842 = load <8 x float>, ptr %private.contiguous.address841, align 4
  %1857 = select <8 x i1> %71, <8 x float> %private.contiguous.load842, <8 x float> zeroinitializer
  %.spill.load843 = load <8 x float>, ptr %.spill130, align 32
  %1858 = fmul <8 x float> %.spill.load843, %1857
  %1859 = fadd <8 x float> %1842, %1858
  %.state844 = load i64, ptr %.slot139, align 4
  %1860 = add i64 1344, %.state844
  %tile_snapshot.spill.load845 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1861 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load845, 0
  %1862 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load845, 1
  %.splatinsert846 = insertelement <8 x i64> poison, i64 %1860, i64 0
  %.splat847 = shufflevector <8 x i64> %.splatinsert846, <8 x i64> poison, <8 x i32> zeroinitializer
  %1863 = mul <8 x i64> %.splat847, splat (i64 32)
  %1864 = add <8 x i64> %1862, %1863
  %1865 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1861, 0
  %1866 = insertvalue { <8 x ptr>, <8 x i64> } %1865, <8 x i64> %1864, 1
  %1867 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1868 = extractvalue { <8 x ptr>, <8 x i64> } %1866, 1
  %1869 = extractelement <8 x ptr> %1867, i32 0
  %1870 = extractelement <8 x i64> %1868, i32 0
  %1871 = sub i64 %1870, 0
  %1872 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1873 = select i1 %1872, i64 %1871, i64 0
  %private.contiguous.address848 = getelementptr i8, ptr %1869, i64 %1873
  %private.contiguous.load849 = load <8 x float>, ptr %private.contiguous.address848, align 4
  %1874 = select <8 x i1> %71, <8 x float> %private.contiguous.load849, <8 x float> zeroinitializer
  %.spill.load850 = load <8 x float>, ptr %.spill131, align 32
  %1875 = fmul <8 x float> %.spill.load850, %1874
  %1876 = fadd <8 x float> %1859, %1875
  %.state851 = load i64, ptr %.slot139, align 4
  %1877 = add i64 1440, %.state851
  %tile_snapshot.spill.load852 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %1878 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load852, 0
  %1879 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load852, 1
  %.splatinsert853 = insertelement <8 x i64> poison, i64 %1877, i64 0
  %.splat854 = shufflevector <8 x i64> %.splatinsert853, <8 x i64> poison, <8 x i32> zeroinitializer
  %1880 = mul <8 x i64> %.splat854, splat (i64 32)
  %1881 = add <8 x i64> %1879, %1880
  %1882 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1878, 0
  %1883 = insertvalue { <8 x ptr>, <8 x i64> } %1882, <8 x i64> %1881, 1
  %1884 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1885 = extractvalue { <8 x ptr>, <8 x i64> } %1883, 1
  %1886 = extractelement <8 x ptr> %1884, i32 0
  %1887 = extractelement <8 x i64> %1885, i32 0
  %1888 = sub i64 %1887, 0
  %1889 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1890 = select i1 %1889, i64 %1888, i64 0
  %private.contiguous.address855 = getelementptr i8, ptr %1886, i64 %1890
  %private.contiguous.load856 = load <8 x float>, ptr %private.contiguous.address855, align 4
  %1891 = select <8 x i1> %71, <8 x float> %private.contiguous.load856, <8 x float> zeroinitializer
  %.spill.load857 = load <8 x float>, ptr %.spill132, align 32
  %1892 = fmul <8 x float> %.spill.load857, %1891
  %1893 = fadd <8 x float> %1876, %1892
  %tile_snapshot.spill.load858 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill138, align 64
  %1894 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load858, 0
  %1895 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load858, 1
  %.state859 = load i64, ptr %.slot139, align 4
  %.splatinsert860 = insertelement <8 x i64> poison, i64 %.state859, i64 0
  %.splat861 = shufflevector <8 x i64> %.splatinsert860, <8 x i64> poison, <8 x i32> zeroinitializer
  %1896 = mul <8 x i64> %.splat861, splat (i64 32)
  %1897 = add <8 x i64> %1895, %1896
  %1898 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1894, 0
  %1899 = insertvalue { <8 x ptr>, <8 x i64> } %1898, <8 x i64> %1897, 1
  %1900 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1901 = extractvalue { <8 x ptr>, <8 x i64> } %1899, 1
  %1902 = extractelement <8 x ptr> %1900, i32 0
  %1903 = extractelement <8 x i64> %1901, i32 0
  %1904 = sub i64 %1903, 0
  %1905 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1906 = select i1 %1905, i64 %1904, i64 0
  %private.contiguous.address862 = getelementptr i8, ptr %1902, i64 %1906
  %private.contiguous.preserve863 = load <8 x float>, ptr %private.contiguous.address862, align 4
  %1907 = select <8 x i1> %71, <8 x float> %1893, <8 x float> %private.contiguous.preserve863
  store <8 x float> %1907, ptr %private.contiguous.address862, align 4
  %.state864 = load i64, ptr %.slot139, align 4
  %1908 = add i64 %.state864, 1
  store i64 %1908, ptr %.slot139, align 4
  br label %direct.schedule.73

direct.schedule.75:                               ; preds = %direct.false739
  store i64 0, ptr %.slot140, align 4
  br label %direct.schedule.76

direct.schedule.76:                               ; preds = %direct.schedule.77, %direct.schedule.75
  %.state865 = load i64, ptr %.slot140, align 4
  %1909 = icmp slt i64 %.state865, 96
  br i1 %1909, label %direct.true866, label %direct.false867

direct.schedule.77:                               ; preds = %direct.true866
  %tile_snapshot.spill.load868 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill138, align 64
  %1910 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load868, 0
  %1911 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load868, 1
  %.state869 = load i64, ptr %.slot140, align 4
  %.splatinsert870 = insertelement <8 x i64> poison, i64 %.state869, i64 0
  %.splat871 = shufflevector <8 x i64> %.splatinsert870, <8 x i64> poison, <8 x i32> zeroinitializer
  %1912 = mul <8 x i64> %.splat871, splat (i64 32)
  %1913 = add <8 x i64> %1911, %1912
  %1914 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1910, 0
  %1915 = insertvalue { <8 x ptr>, <8 x i64> } %1914, <8 x i64> %1913, 1
  %1916 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1917 = extractvalue { <8 x ptr>, <8 x i64> } %1915, 1
  %1918 = extractelement <8 x ptr> %1916, i32 0
  %1919 = extractelement <8 x i64> %1917, i32 0
  %1920 = sub i64 %1919, 0
  %1921 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1922 = select i1 %1921, i64 %1920, i64 0
  %private.contiguous.address872 = getelementptr i8, ptr %1918, i64 %1922
  %private.contiguous.load873 = load <8 x float>, ptr %private.contiguous.address872, align 4
  %1923 = select <8 x i1> %71, <8 x float> %private.contiguous.load873, <8 x float> zeroinitializer
  %tile_snapshot.spill.load874 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill33, align 64
  %1924 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load874, 0
  %1925 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load874, 1
  %.state875 = load i64, ptr %.slot140, align 4
  %.splatinsert876 = insertelement <8 x i64> poison, i64 %.state875, i64 0
  %.splat877 = shufflevector <8 x i64> %.splatinsert876, <8 x i64> poison, <8 x i32> zeroinitializer
  %1926 = mul <8 x i64> %.splat877, splat (i64 32)
  %1927 = add <8 x i64> %1925, %1926
  %1928 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1924, 0
  %1929 = insertvalue { <8 x ptr>, <8 x i64> } %1928, <8 x i64> %1927, 1
  %1930 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1931 = extractvalue { <8 x ptr>, <8 x i64> } %1929, 1
  %1932 = extractelement <8 x ptr> %1930, i32 0
  %1933 = extractelement <8 x i64> %1931, i32 0
  %1934 = sub i64 %1933, 0
  %1935 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1936 = select i1 %1935, i64 %1934, i64 0
  %private.contiguous.address878 = getelementptr i8, ptr %1932, i64 %1936
  %private.contiguous.preserve879 = load <8 x float>, ptr %private.contiguous.address878, align 4
  %1937 = select <8 x i1> %71, <8 x float> %1923, <8 x float> %private.contiguous.preserve879
  store <8 x float> %1937, ptr %private.contiguous.address878, align 4
  %.state880 = load i64, ptr %.slot140, align 4
  %1938 = add i64 %.state880, 1
  store i64 %1938, ptr %.slot140, align 4
  br label %direct.schedule.76

direct.schedule.78:                               ; preds = %direct.false867
  store i64 0, ptr %.slot141, align 4
  br label %direct.schedule.79

direct.schedule.79:                               ; preds = %direct.schedule.80, %direct.schedule.78
  %.state881 = load i64, ptr %.slot141, align 4
  %1939 = icmp slt i64 %.state881, 96
  br i1 %1939, label %direct.true882, label %direct.false883

direct.schedule.80:                               ; preds = %direct.true882
  %tile_snapshot.spill.load884 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill33, align 64
  %1940 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load884, 0
  %1941 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load884, 1
  %.state885 = load i64, ptr %.slot141, align 4
  %.splatinsert886 = insertelement <8 x i64> poison, i64 %.state885, i64 0
  %.splat887 = shufflevector <8 x i64> %.splatinsert886, <8 x i64> poison, <8 x i32> zeroinitializer
  %1942 = mul <8 x i64> %.splat887, splat (i64 32)
  %1943 = add <8 x i64> %1941, %1942
  %1944 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1940, 0
  %1945 = insertvalue { <8 x ptr>, <8 x i64> } %1944, <8 x i64> %1943, 1
  %1946 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1947 = extractvalue { <8 x ptr>, <8 x i64> } %1945, 1
  %1948 = extractelement <8 x ptr> %1946, i32 0
  %1949 = extractelement <8 x i64> %1947, i32 0
  %1950 = sub i64 %1949, 0
  %1951 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1952 = select i1 %1951, i64 %1950, i64 0
  %private.contiguous.address888 = getelementptr i8, ptr %1948, i64 %1952
  %private.contiguous.load889 = load <8 x float>, ptr %private.contiguous.address888, align 4
  %1953 = select <8 x i1> %71, <8 x float> %private.contiguous.load889, <8 x float> zeroinitializer
  %tile_snapshot.spill.load890 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1954 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load890, 0
  %1955 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load890, 1
  %.state891 = load i64, ptr %.slot141, align 4
  %.splatinsert892 = insertelement <8 x i64> poison, i64 %.state891, i64 0
  %.splat893 = shufflevector <8 x i64> %.splatinsert892, <8 x i64> poison, <8 x i32> zeroinitializer
  %1956 = mul <8 x i64> %.splat893, splat (i64 32)
  %1957 = add <8 x i64> %1955, %1956
  %1958 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1954, 0
  %1959 = insertvalue { <8 x ptr>, <8 x i64> } %1958, <8 x i64> %1957, 1
  %1960 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1961 = extractvalue { <8 x ptr>, <8 x i64> } %1959, 1
  %1962 = extractelement <8 x ptr> %1960, i32 0
  %1963 = extractelement <8 x i64> %1961, i32 0
  %1964 = sub i64 %1963, 0
  %1965 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1966 = select i1 %1965, i64 %1964, i64 0
  %private.contiguous.address894 = getelementptr i8, ptr %1962, i64 %1966
  %private.contiguous.preserve895 = load <8 x float>, ptr %private.contiguous.address894, align 4
  %1967 = select <8 x i1> %71, <8 x float> %1953, <8 x float> %private.contiguous.preserve895
  store <8 x float> %1967, ptr %private.contiguous.address894, align 4
  %.state896 = load i64, ptr %.slot141, align 4
  %1968 = add i64 %.state896, 1
  store i64 %1968, ptr %.slot141, align 4
  br label %direct.schedule.79

direct.schedule.81:                               ; preds = %direct.false883
  %.state897 = load i64, ptr %.slot35, align 4
  %1969 = add i64 %.state897, 1
  %.spill.load898 = load <8 x float>, ptr %.spill115, align 32
  %.spill.load899 = load <8 x float>, ptr %.spill137, align 32
  store i64 %1969, ptr %.slot35, align 4
  %1970 = load <8 x float>, ptr %.slot36, align 32
  %1971 = select <8 x i1> %71, <8 x float> %.spill.load898, <8 x float> %1970
  store <8 x float> %1971, ptr %.slot36, align 32
  %1972 = load <8 x float>, ptr %.slot37, align 32
  %1973 = select <8 x i1> %71, <8 x float> %.spill.load899, <8 x float> %1972
  store <8 x float> %1973, ptr %.slot37, align 32
  br label %direct.schedule.7

direct.schedule.82:                               ; preds = %direct.false176
  store i64 0, ptr %.slot142, align 4
  br label %direct.schedule.83

direct.schedule.83:                               ; preds = %direct.schedule.84, %direct.schedule.82
  %.state900 = load i64, ptr %.slot142, align 4
  %1974 = icmp slt i64 %.state900, 96
  br i1 %1974, label %direct.true901, label %direct.false902

direct.schedule.84:                               ; preds = %direct.true901
  %.spill.load903 = load <8 x i64>, ptr %.spill, align 64
  %1975 = add <8 x i64> %.spill.load903, zeroinitializer
  %1976 = add <8 x i64> zeroinitializer, %1975
  %.spill.load904 = load <8 x i64>, ptr %.spill29, align 64
  %1977 = add <8 x i64> %.spill.load904, zeroinitializer
  %1978 = mul <8 x i64> %1976, splat (i64 8)
  %1979 = add <8 x i64> %1978, %1977
  %.spill.load905 = load i64, ptr %.spill30, align 4
  %1980 = add i64 %.spill.load905, 0
  %1981 = mul <8 x i64> %1979, splat (i64 1)
  %.splatinsert906 = insertelement <8 x i64> poison, i64 %1980, i64 0
  %.splat907 = shufflevector <8 x i64> %.splatinsert906, <8 x i64> poison, <8 x i32> zeroinitializer
  %1982 = add <8 x i64> %1981, %.splat907
  %.state908 = load i64, ptr %.slot142, align 4
  %1983 = add i64 0, %.state908
  %1984 = mul <8 x i64> %1982, splat (i64 96)
  %.splatinsert909 = insertelement <8 x i64> poison, i64 %1983, i64 0
  %.splat910 = shufflevector <8 x i64> %.splatinsert909, <8 x i64> poison, <8 x i32> zeroinitializer
  %1985 = add <8 x i64> %1984, %.splat910
  %.state911 = load i64, ptr %.slot142, align 4
  %1986 = add i64 0, %.state911
  %tile_snapshot.spill.load912 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1987 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load912, 0
  %1988 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load912, 1
  %.splatinsert913 = insertelement <8 x i64> poison, i64 %1986, i64 0
  %.splat914 = shufflevector <8 x i64> %.splatinsert913, <8 x i64> poison, <8 x i32> zeroinitializer
  %1989 = mul <8 x i64> %.splat914, splat (i64 32)
  %1990 = add <8 x i64> %1988, %1989
  %1991 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1987, 0
  %1992 = insertvalue { <8 x ptr>, <8 x i64> } %1991, <8 x i64> %1990, 1
  %1993 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1994 = extractvalue { <8 x ptr>, <8 x i64> } %1992, 1
  %1995 = extractelement <8 x ptr> %1993, i32 0
  %1996 = extractelement <8 x i64> %1994, i32 0
  %1997 = sub i64 %1996, 0
  %1998 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1999 = select i1 %1998, i64 %1997, i64 0
  %private.contiguous.address915 = getelementptr i8, ptr %1995, i64 %1999
  %private.contiguous.load916 = load <8 x float>, ptr %private.contiguous.address915, align 4
  %2000 = select <8 x i1> %71, <8 x float> %private.contiguous.load916, <8 x float> zeroinitializer
  %.state917 = load <8 x float>, ptr %.slot37, align 32
  %2001 = fdiv <8 x float> %2000, %.state917
  %2002 = extractvalue { ptr, i64 } %47, 0
  %2003 = mul <8 x i64> %1985, splat (i64 4)
  %2004 = getelementptr i8, ptr %2002, <8 x i64> %2003
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %2001, <8 x ptr> align 1 %2004, <8 x i1> %71)
  %.state918 = load i64, ptr %.slot142, align 4
  %2005 = add i64 %.state918, 1
  store i64 %2005, ptr %.slot142, align 4
  br label %direct.schedule.83

direct.schedule.85:                               ; preds = %direct.false902
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true165:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false166:                                  ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true175:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false176:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.82

direct.true179:                                   ; preds = %direct.schedule.9
  br label %direct.schedule.10

direct.false180:                                  ; preds = %direct.schedule.9
  br label %direct.schedule.13

direct.true190:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false191:                                  ; preds = %direct.schedule.10
  %2006 = load <8 x float>, ptr %.slot42, align 32
  %2007 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %2006
  store <8 x float> %2007, ptr %.slot42, align 32
  br label %direct.schedule.12

direct.true204:                                   ; preds = %direct.schedule.14
  br label %direct.schedule.15

direct.false205:                                  ; preds = %direct.schedule.14
  br label %direct.schedule.18

direct.true215:                                   ; preds = %direct.schedule.15
  br label %direct.schedule.16

direct.false216:                                  ; preds = %direct.schedule.15
  %2008 = load <8 x float>, ptr %.slot46, align 32
  %2009 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %2008
  store <8 x float> %2009, ptr %.slot46, align 32
  br label %direct.schedule.17

direct.true229:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false230:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true244:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false245:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24

direct.true261:                                   ; preds = %direct.schedule.25
  br label %direct.schedule.26

direct.false262:                                  ; preds = %direct.schedule.25
  br label %direct.schedule.27

direct.true278:                                   ; preds = %direct.schedule.28
  br label %direct.schedule.29

direct.false279:                                  ; preds = %direct.schedule.28
  br label %direct.schedule.30

direct.true295:                                   ; preds = %direct.schedule.31
  br label %direct.schedule.32

direct.false296:                                  ; preds = %direct.schedule.31
  br label %direct.schedule.33

direct.true312:                                   ; preds = %direct.schedule.34
  br label %direct.schedule.35

direct.false313:                                  ; preds = %direct.schedule.34
  br label %direct.schedule.36

direct.true329:                                   ; preds = %direct.schedule.37
  br label %direct.schedule.38

direct.false330:                                  ; preds = %direct.schedule.37
  br label %direct.schedule.39

direct.true346:                                   ; preds = %direct.schedule.40
  br label %direct.schedule.41

direct.false347:                                  ; preds = %direct.schedule.40
  br label %direct.schedule.42

direct.true363:                                   ; preds = %direct.schedule.43
  br label %direct.schedule.44

direct.false364:                                  ; preds = %direct.schedule.43
  br label %direct.schedule.45

direct.true380:                                   ; preds = %direct.schedule.46
  br label %direct.schedule.47

direct.false381:                                  ; preds = %direct.schedule.46
  br label %direct.schedule.48

direct.true397:                                   ; preds = %direct.schedule.49
  br label %direct.schedule.50

direct.false398:                                  ; preds = %direct.schedule.49
  br label %direct.schedule.51

direct.true414:                                   ; preds = %direct.schedule.52
  br label %direct.schedule.53

direct.false415:                                  ; preds = %direct.schedule.52
  br label %direct.schedule.54

direct.true431:                                   ; preds = %direct.schedule.55
  br label %direct.schedule.56

direct.false432:                                  ; preds = %direct.schedule.55
  br label %direct.schedule.57

direct.true448:                                   ; preds = %direct.schedule.58
  br label %direct.schedule.59

direct.false449:                                  ; preds = %direct.schedule.58
  br label %direct.schedule.60

direct.true465:                                   ; preds = %direct.schedule.61
  br label %direct.schedule.62

direct.false466:                                  ; preds = %direct.schedule.61
  br label %direct.schedule.63

direct.true482:                                   ; preds = %direct.schedule.64
  br label %direct.schedule.65

direct.false483:                                  ; preds = %direct.schedule.64
  br label %direct.schedule.66

direct.true596:                                   ; preds = %direct.schedule.67
  br label %direct.schedule.68

direct.false597:                                  ; preds = %direct.schedule.67
  br label %direct.schedule.69

direct.true724:                                   ; preds = %direct.schedule.70
  br label %direct.schedule.71

direct.false725:                                  ; preds = %direct.schedule.70
  br label %direct.schedule.72

direct.true738:                                   ; preds = %direct.schedule.73
  br label %direct.schedule.74

direct.false739:                                  ; preds = %direct.schedule.73
  br label %direct.schedule.75

direct.true866:                                   ; preds = %direct.schedule.76
  br label %direct.schedule.77

direct.false867:                                  ; preds = %direct.schedule.76
  br label %direct.schedule.78

direct.true882:                                   ; preds = %direct.schedule.79
  br label %direct.schedule.80

direct.false883:                                  ; preds = %direct.schedule.79
  br label %direct.schedule.81

direct.true901:                                   ; preds = %direct.schedule.83
  br label %direct.schedule.84

direct.false902:                                  ; preds = %direct.schedule.83
  br label %direct.schedule.85
}

define internal void @llm_attention.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_attention.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_attention.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(write) }

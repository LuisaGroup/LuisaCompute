; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 16384
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 49152
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 512, i64 1024, i64 1536, i64 2048, i64 2560, i64 3072, i64 3584>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 53248
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 69632
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill17 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill17, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill18 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill18, align 64
  %.slot19 = alloca i64, align 8
  store i64 0, ptr %.slot19, align 4
  %.spill20 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill20, align 64
  %tile_snapshot.spill21 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill21, align 64
  %.slot22 = alloca i64, align 8
  store i64 0, ptr %.slot22, align 4
  %.spill23 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill23, align 4
  %tile_snapshot.spill24 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill24, align 64
  %.slot25 = alloca i64, align 8
  store i64 0, ptr %.slot25, align 4
  %.spill26 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill26, align 4
  %.slot27 = alloca i64, align 8
  store i64 0, ptr %.slot27, align 4
  %.slot28 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot28, align 32
  %.slot29 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot29, align 32
  %.slot30 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot30, align 32
  %.slot31 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot31, align 32
  %.spill32 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill32, align 32
  %.spill33 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill33, align 32
  %.spill34 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill34, align 32
  %.spill35 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill35, align 4
  %.spill36 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill36, align 4
  %tile_snapshot.spill37 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill37, align 64
  %.slot38 = alloca i64, align 8
  store i64 0, ptr %.slot38, align 4
  %.slot39 = alloca i64, align 8
  store i64 0, ptr %.slot39, align 4
  %.slot40 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot40, align 32
  %.slot41 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot41, align 32
  %.slot42 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot42, align 32
  %.slot43 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot43, align 32
  %.spill44 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill44, align 4
  %.slot45 = alloca i64, align 8
  store i64 0, ptr %.slot45, align 4
  %15 = getelementptr i8, ptr %argument_buffer, i64 0
  %16 = load ptr, ptr %15, align 16
  %17 = getelementptr i8, ptr %15, i64 8
  %18 = load i64, ptr %17, align 8
  %19 = insertvalue { ptr, i64 } poison, ptr %16, 0
  %20 = insertvalue { ptr, i64 } %19, i64 %18, 1
  %21 = getelementptr i8, ptr %argument_buffer, i64 16
  %22 = load ptr, ptr %21, align 16
  %23 = getelementptr i8, ptr %21, i64 8
  %24 = load i64, ptr %23, align 8
  %25 = insertvalue { ptr, i64 } poison, ptr %22, 0
  %26 = insertvalue { ptr, i64 } %25, i64 %24, 1
  %27 = getelementptr i8, ptr %argument_buffer, i64 32
  %28 = load ptr, ptr %27, align 16
  %29 = getelementptr i8, ptr %27, i64 8
  %30 = load i64, ptr %29, align 8
  %31 = insertvalue { ptr, i64 } poison, ptr %28, 0
  %32 = insertvalue { ptr, i64 } %31, i64 %30, 1
  %33 = getelementptr i8, ptr %argument_buffer, i64 48
  %34 = load ptr, ptr %33, align 16
  %35 = getelementptr i8, ptr %33, i64 8
  %36 = load i64, ptr %35, align 8
  %37 = insertvalue { ptr, i64 } poison, ptr %34, 0
  %38 = insertvalue { ptr, i64 } %37, i64 %36, 1
  %39 = load i32, ptr %launch_config, align 4
  %40 = getelementptr i8, ptr %launch_config, i64 12
  %41 = load i32, ptr %40, align 4
  %42 = getelementptr i8, ptr %launch_config, i64 4
  %43 = load i32, ptr %42, align 4
  %44 = getelementptr i8, ptr %launch_config, i64 16
  %45 = load i32, ptr %44, align 4
  %46 = getelementptr i8, ptr %launch_config, i64 8
  %47 = load i32, ptr %46, align 4
  %48 = getelementptr i8, ptr %launch_config, i64 20
  %49 = load i32, ptr %48, align 4
  %50 = getelementptr i8, ptr %launch_config, i64 36
  %51 = load i32, ptr %50, align 4
  %.splatinsert46 = insertelement <8 x i32> poison, i32 %51, i64 0
  %.splat47 = shufflevector <8 x i32> %.splatinsert46, <8 x i32> poison, <8 x i32> zeroinitializer
  %52 = add <8 x i32> %.splat47, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %53 = mul i32 %39, 32
  %.splatinsert48 = insertelement <8 x i32> poison, i32 %53, i64 0
  %.splat49 = shufflevector <8 x i32> %.splatinsert48, <8 x i32> poison, <8 x i32> zeroinitializer
  %54 = add <8 x i32> %.splat49, %52
  %55 = mul i32 %43, 1
  %.splatinsert50 = insertelement <8 x i32> poison, i32 %55, i64 0
  %.splat51 = shufflevector <8 x i32> %.splatinsert50, <8 x i32> poison, <8 x i32> zeroinitializer
  %56 = add <8 x i32> %.splat51, zeroinitializer
  %57 = mul i32 %47, 1
  %.splatinsert52 = insertelement <8 x i32> poison, i32 %57, i64 0
  %.splat53 = shufflevector <8 x i32> %.splatinsert52, <8 x i32> poison, <8 x i32> zeroinitializer
  %58 = add <8 x i32> %.splat53, zeroinitializer
  %59 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %54, 0
  %60 = insertvalue [3 x <8 x i32>] %59, <8 x i32> %56, 1
  %61 = insertvalue [3 x <8 x i32>] %60, <8 x i32> %58, 2
  %.splatinsert54 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat55 = shufflevector <8 x i32> %.splatinsert54, <8 x i32> poison, <8 x i32> zeroinitializer
  %62 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat55
  %63 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  br i1 %63, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %64 = extractvalue [3 x <8 x i32>] %61, 0
  %65 = load <8 x i64>, ptr %.spill, align 64
  %66 = select <8 x i1> %62, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %65
  store <8 x i64> %66, ptr %.spill, align 64
  %67 = sub <8 x i32> %64, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %68 = select <8 x i1> %62, <8 x i32> %67, <8 x i32> zeroinitializer
  %69 = select <8 x i1> %62, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %70 = lshr <8 x i32> %68, %69
  %71 = zext <8 x i32> %70 to <8 x i64>
  %72 = select <8 x i1> %62, <8 x i64> %71, <8 x i64> zeroinitializer
  %73 = select <8 x i1> %62, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %74 = sdiv <8 x i64> %72, %73
  %75 = load <8 x i64>, ptr %.spill17, align 64
  %76 = select <8 x i1> %62, <8 x i64> %74, <8 x i64> %75
  store <8 x i64> %76, ptr %.spill17, align 64
  %77 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %78 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %79 = extractvalue { <8 x ptr>, <8 x i64> } %77, 0
  %80 = select <8 x i1> %62, <8 x ptr> %78, <8 x ptr> %79
  %81 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %82 = extractvalue { <8 x ptr>, <8 x i64> } %77, 1
  %83 = select <8 x i1> %62, <8 x i64> %81, <8 x i64> %82
  %84 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %80, 0
  %85 = insertvalue { <8 x ptr>, <8 x i64> } %84, <8 x i64> %83, 1
  store { <8 x ptr>, <8 x i64> } %85, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %86 = icmp slt i64 %.state, 512
  br i1 %86, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state56 = load i64, ptr %.slot, align 4
  %87 = mul i64 %.state56, 8
  %.splatinsert57 = insertelement <8 x i64> poison, i64 %87, i64 0
  %.splat58 = shufflevector <8 x i64> %.splatinsert57, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %88 = add <8 x i64> %.splat58, %.spill.load
  %.spill.load59 = load <8 x i64>, ptr %.spill17, align 64
  %89 = add <8 x i64> %.spill.load59, zeroinitializer
  %90 = add <8 x i64> zeroinitializer, %89
  %91 = add <8 x i64> zeroinitializer, %88
  %92 = mul <8 x i64> %90, splat (i64 4096)
  %93 = add <8 x i64> %92, %91
  %94 = extractvalue { ptr, i64 } %20, 0
  %95 = extractelement <8 x i64> %93, i32 0
  %96 = sub i64 %95, 0
  %97 = mul i64 %96, 4
  %buffer.contiguous.address = getelementptr i8, ptr %94, i64 %97
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %62, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %99 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state60 = load i64, ptr %.slot, align 4
  %.splatinsert61 = insertelement <8 x i64> poison, i64 %.state60, i64 0
  %.splat62 = shufflevector <8 x i64> %.splatinsert61, <8 x i64> poison, <8 x i32> zeroinitializer
  %100 = mul <8 x i64> %.splat62, splat (i64 32)
  %101 = add <8 x i64> %99, %100
  %102 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %98, 0
  %103 = insertvalue { <8 x ptr>, <8 x i64> } %102, <8 x i64> %101, 1
  %104 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %105 = extractvalue { <8 x ptr>, <8 x i64> } %103, 1
  %106 = extractelement <8 x ptr> %104, i32 0
  %107 = extractelement <8 x i64> %105, i32 0
  %108 = sub i64 %107, 0
  %109 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %110 = select i1 %109, i64 %108, i64 0
  %private.contiguous.address = getelementptr i8, ptr %106, i64 %110
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %111 = select <8 x i1> %62, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %111, ptr %private.contiguous.address, align 4
  %.state63 = load i64, ptr %.slot, align 4
  %112 = add i64 %.state63, 1
  store i64 %112, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %113 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %114 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %113, 0
  %116 = select <8 x i1> %62, <8 x ptr> %114, <8 x ptr> %115
  %117 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %118 = extractvalue { <8 x ptr>, <8 x i64> } %113, 1
  %119 = select <8 x i1> %62, <8 x i64> %117, <8 x i64> %118
  %120 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %116, 0
  %121 = insertvalue { <8 x ptr>, <8 x i64> } %120, <8 x i64> %119, 1
  store { <8 x ptr>, <8 x i64> } %121, ptr %tile_snapshot.spill18, align 64
  store i64 0, ptr %.slot19, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state64 = load i64, ptr %.slot19, align 4
  %122 = icmp slt i64 %.state64, 512
  br i1 %122, label %direct.true65, label %direct.false66

direct.schedule.5:                                ; preds = %direct.true65
  %.state67 = load i64, ptr %.slot19, align 4
  %123 = mul i64 %.state67, 8
  %.splatinsert68 = insertelement <8 x i64> poison, i64 %123, i64 0
  %.splat69 = shufflevector <8 x i64> %.splatinsert68, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load70 = load <8 x i64>, ptr %.spill, align 64
  %124 = add <8 x i64> %.splat69, %.spill.load70
  %tile_snapshot.spill.load71 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load71, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load71, 1
  %.state72 = load i64, ptr %.slot19, align 4
  %.splatinsert73 = insertelement <8 x i64> poison, i64 %.state72, i64 0
  %.splat74 = shufflevector <8 x i64> %.splatinsert73, <8 x i64> poison, <8 x i32> zeroinitializer
  %127 = mul <8 x i64> %.splat74, splat (i64 64)
  %128 = add <8 x i64> %126, %127
  %129 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %125, 0
  %130 = insertvalue { <8 x ptr>, <8 x i64> } %129, <8 x i64> %128, 1
  %131 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %132 = extractvalue { <8 x ptr>, <8 x i64> } %130, 1
  %133 = extractelement <8 x ptr> %131, i32 0
  %134 = extractelement <8 x i64> %132, i32 0
  %135 = sub i64 %134, 0
  %136 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %137 = select i1 %136, i64 %135, i64 0
  %private.contiguous.address75 = getelementptr i8, ptr %133, i64 %137
  %private.contiguous.preserve76 = load <8 x i64>, ptr %private.contiguous.address75, align 8
  %138 = select <8 x i1> %62, <8 x i64> %124, <8 x i64> %private.contiguous.preserve76
  store <8 x i64> %138, ptr %private.contiguous.address75, align 8
  %.state77 = load i64, ptr %.slot19, align 4
  %139 = add i64 %.state77, 1
  store i64 %139, ptr %.slot19, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false66
  %.spill.load78 = load <8 x i64>, ptr %.spill17, align 64
  %140 = select <8 x i1> %62, <8 x i64> %.spill.load78, <8 x i64> zeroinitializer
  %141 = select <8 x i1> %62, <8 x i64> splat (i64 4096), <8 x i64> splat (i64 1)
  %142 = srem <8 x i64> %140, %141
  %143 = load <8 x i64>, ptr %.spill20, align 64
  %144 = select <8 x i1> %62, <8 x i64> %142, <8 x i64> %143
  store <8 x i64> %144, ptr %.spill20, align 64
  %145 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %145, 0
  %148 = select <8 x i1> %62, <8 x ptr> %146, <8 x ptr> %147
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %145, 1
  %151 = select <8 x i1> %62, <8 x i64> %149, <8 x i64> %150
  %152 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %148, 0
  %153 = insertvalue { <8 x ptr>, <8 x i64> } %152, <8 x i64> %151, 1
  store { <8 x ptr>, <8 x i64> } %153, ptr %tile_snapshot.spill21, align 64
  store i64 0, ptr %.slot22, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state79 = load i64, ptr %.slot22, align 4
  %154 = icmp slt i64 %.state79, 512
  br i1 %154, label %direct.true80, label %direct.false81

direct.schedule.8:                                ; preds = %direct.true80
  %tile_snapshot.spill.load82 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %155 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load82, 0
  %156 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load82, 1
  %.state83 = load i64, ptr %.slot22, align 4
  %.splatinsert84 = insertelement <8 x i64> poison, i64 %.state83, i64 0
  %.splat85 = shufflevector <8 x i64> %.splatinsert84, <8 x i64> poison, <8 x i32> zeroinitializer
  %157 = mul <8 x i64> %.splat85, splat (i64 64)
  %158 = add <8 x i64> %156, %157
  %159 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %155, 0
  %160 = insertvalue { <8 x ptr>, <8 x i64> } %159, <8 x i64> %158, 1
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %160, 1
  %163 = extractelement <8 x ptr> %161, i32 0
  %164 = extractelement <8 x i64> %162, i32 0
  %165 = sub i64 %164, 0
  %166 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %167 = select i1 %166, i64 %165, i64 0
  %private.contiguous.address86 = getelementptr i8, ptr %163, i64 %167
  %private.contiguous.load = load <8 x i64>, ptr %private.contiguous.address86, align 8
  %168 = select <8 x i1> %62, <8 x i64> %private.contiguous.load, <8 x i64> zeroinitializer
  %.spill.load87 = load <8 x i64>, ptr %.spill20, align 64
  %169 = icmp sle <8 x i64> %168, %.spill.load87
  %tile_snapshot.spill.load88 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load88, 0
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load88, 1
  %.state89 = load i64, ptr %.slot22, align 4
  %.splatinsert90 = insertelement <8 x i64> poison, i64 %.state89, i64 0
  %.splat91 = shufflevector <8 x i64> %.splatinsert90, <8 x i64> poison, <8 x i32> zeroinitializer
  %172 = add <8 x i64> %171, %.splat91
  %173 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %170, 0
  %174 = insertvalue { <8 x ptr>, <8 x i64> } %173, <8 x i64> %172, 1
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %174, 0
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %174, 1
  %177 = getelementptr i8, <8 x ptr> %175, <8 x i64> %176
  %178 = zext <8 x i1> %169 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %178, <8 x ptr> %177, i32 1, <8 x i1> %62)
  %.state92 = load i64, ptr %.slot22, align 4
  %179 = add i64 %.state92, 1
  store i64 %179, ptr %.slot22, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false81
  store float 0xC6293E5940000000, ptr %.spill23, align 4
  %180 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill24, align 64
  %181 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %182 = extractvalue { <8 x ptr>, <8 x i64> } %180, 0
  %183 = select <8 x i1> %62, <8 x ptr> %181, <8 x ptr> %182
  %184 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %185 = extractvalue { <8 x ptr>, <8 x i64> } %180, 1
  %186 = select <8 x i1> %62, <8 x i64> %184, <8 x i64> %185
  %187 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %183, 0
  %188 = insertvalue { <8 x ptr>, <8 x i64> } %187, <8 x i64> %186, 1
  store { <8 x ptr>, <8 x i64> } %188, ptr %tile_snapshot.spill24, align 64
  store i64 0, ptr %.slot25, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state93 = load i64, ptr %.slot25, align 4
  %189 = icmp slt i64 %.state93, 512
  br i1 %189, label %direct.true94, label %direct.false95

direct.schedule.11:                               ; preds = %direct.true94
  %tile_snapshot.spill.load96 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %190 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load96, 0
  %191 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load96, 1
  %.state97 = load i64, ptr %.slot25, align 4
  %.splatinsert98 = insertelement <8 x i64> poison, i64 %.state97, i64 0
  %.splat99 = shufflevector <8 x i64> %.splatinsert98, <8 x i64> poison, <8 x i32> zeroinitializer
  %192 = add <8 x i64> %191, %.splat99
  %193 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %190, 0
  %194 = insertvalue { <8 x ptr>, <8 x i64> } %193, <8 x i64> %192, 1
  %195 = extractvalue { <8 x ptr>, <8 x i64> } %194, 0
  %196 = extractvalue { <8 x ptr>, <8 x i64> } %194, 1
  %197 = getelementptr i8, <8 x ptr> %195, <8 x i64> %196
  %198 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %197, i32 1, <8 x i1> %62, <8 x i8> zeroinitializer)
  %199 = icmp ne <8 x i8> %198, zeroinitializer
  %tile_snapshot.spill.load100 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %200 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load100, 0
  %201 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load100, 1
  %.state101 = load i64, ptr %.slot25, align 4
  %.splatinsert102 = insertelement <8 x i64> poison, i64 %.state101, i64 0
  %.splat103 = shufflevector <8 x i64> %.splatinsert102, <8 x i64> poison, <8 x i32> zeroinitializer
  %202 = mul <8 x i64> %.splat103, splat (i64 32)
  %203 = add <8 x i64> %201, %202
  %204 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %200, 0
  %205 = insertvalue { <8 x ptr>, <8 x i64> } %204, <8 x i64> %203, 1
  %206 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %207 = extractvalue { <8 x ptr>, <8 x i64> } %205, 1
  %208 = extractelement <8 x ptr> %206, i32 0
  %209 = extractelement <8 x i64> %207, i32 0
  %210 = sub i64 %209, 0
  %211 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %212 = select i1 %211, i64 %210, i64 0
  %private.contiguous.address104 = getelementptr i8, ptr %208, i64 %212
  %private.contiguous.load105 = load <8 x float>, ptr %private.contiguous.address104, align 4
  %213 = select <8 x i1> %62, <8 x float> %private.contiguous.load105, <8 x float> zeroinitializer
  %.spill.load106 = load float, ptr %.spill23, align 4
  %.splatinsert107 = insertelement <8 x float> poison, float %.spill.load106, i64 0
  %.splat108 = shufflevector <8 x float> %.splatinsert107, <8 x float> poison, <8 x i32> zeroinitializer
  %214 = select <8 x i1> %199, <8 x float> %213, <8 x float> %.splat108
  %tile_snapshot.spill.load109 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill24, align 64
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load109, 0
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load109, 1
  %.state110 = load i64, ptr %.slot25, align 4
  %.splatinsert111 = insertelement <8 x i64> poison, i64 %.state110, i64 0
  %.splat112 = shufflevector <8 x i64> %.splatinsert111, <8 x i64> poison, <8 x i32> zeroinitializer
  %217 = mul <8 x i64> %.splat112, splat (i64 32)
  %218 = add <8 x i64> %216, %217
  %219 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %215, 0
  %220 = insertvalue { <8 x ptr>, <8 x i64> } %219, <8 x i64> %218, 1
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %220, 1
  %223 = extractelement <8 x ptr> %221, i32 0
  %224 = extractelement <8 x i64> %222, i32 0
  %225 = sub i64 %224, 0
  %226 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %227 = select i1 %226, i64 %225, i64 0
  %private.contiguous.address113 = getelementptr i8, ptr %223, i64 %227
  %private.contiguous.preserve114 = load <8 x float>, ptr %private.contiguous.address113, align 4
  %228 = select <8 x i1> %62, <8 x float> %214, <8 x float> %private.contiguous.preserve114
  store <8 x float> %228, ptr %private.contiguous.address113, align 4
  %.state115 = load i64, ptr %.slot25, align 4
  %229 = add i64 %.state115, 1
  store i64 %229, ptr %.slot25, align 4
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false95
  store float 0xFFF0000000000000, ptr %.spill26, align 4
  %tile_snapshot.spill.load116 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill24, align 64
  %230 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load116, 0
  %231 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load116, 1
  %232 = add <8 x i64> %231, zeroinitializer
  %233 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %230, 0
  %234 = insertvalue { <8 x ptr>, <8 x i64> } %233, <8 x i64> %232, 1
  %235 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %236 = extractvalue { <8 x ptr>, <8 x i64> } %234, 1
  %237 = extractelement <8 x ptr> %235, i32 0
  %238 = extractelement <8 x i64> %236, i32 0
  %239 = sub i64 %238, 0
  %240 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %241 = select i1 %240, i64 %239, i64 0
  %private.contiguous.address117 = getelementptr i8, ptr %237, i64 %241
  %private.contiguous.load118 = load <8 x float>, ptr %private.contiguous.address117, align 4
  %242 = select <8 x i1> %62, <8 x float> %private.contiguous.load118, <8 x float> zeroinitializer
  %tile_snapshot.spill.load119 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill24, align 64
  %243 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load119, 0
  %244 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load119, 1
  %245 = add <8 x i64> %244, splat (i64 32)
  %246 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %243, 0
  %247 = insertvalue { <8 x ptr>, <8 x i64> } %246, <8 x i64> %245, 1
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %247, 1
  %250 = extractelement <8 x ptr> %248, i32 0
  %251 = extractelement <8 x i64> %249, i32 0
  %252 = sub i64 %251, 0
  %253 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %254 = select i1 %253, i64 %252, i64 0
  %private.contiguous.address120 = getelementptr i8, ptr %250, i64 %254
  %private.contiguous.load121 = load <8 x float>, ptr %private.contiguous.address120, align 4
  %255 = select <8 x i1> %62, <8 x float> %private.contiguous.load121, <8 x float> zeroinitializer
  %tile_snapshot.spill.load122 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill24, align 64
  %256 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 0
  %257 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 1
  %258 = add <8 x i64> %257, splat (i64 64)
  %259 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %256, 0
  %260 = insertvalue { <8 x ptr>, <8 x i64> } %259, <8 x i64> %258, 1
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %260, 1
  %263 = extractelement <8 x ptr> %261, i32 0
  %264 = extractelement <8 x i64> %262, i32 0
  %265 = sub i64 %264, 0
  %266 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %267 = select i1 %266, i64 %265, i64 0
  %private.contiguous.address123 = getelementptr i8, ptr %263, i64 %267
  %private.contiguous.load124 = load <8 x float>, ptr %private.contiguous.address123, align 4
  %268 = select <8 x i1> %62, <8 x float> %private.contiguous.load124, <8 x float> zeroinitializer
  %tile_snapshot.spill.load125 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill24, align 64
  %269 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load125, 0
  %270 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load125, 1
  %271 = add <8 x i64> %270, splat (i64 96)
  %272 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %269, 0
  %273 = insertvalue { <8 x ptr>, <8 x i64> } %272, <8 x i64> %271, 1
  %274 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %275 = extractvalue { <8 x ptr>, <8 x i64> } %273, 1
  %276 = extractelement <8 x ptr> %274, i32 0
  %277 = extractelement <8 x i64> %275, i32 0
  %278 = sub i64 %277, 0
  %279 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %280 = select i1 %279, i64 %278, i64 0
  %private.contiguous.address126 = getelementptr i8, ptr %276, i64 %280
  %private.contiguous.load127 = load <8 x float>, ptr %private.contiguous.address126, align 4
  %281 = select <8 x i1> %62, <8 x float> %private.contiguous.load127, <8 x float> zeroinitializer
  store i64 4, ptr %.slot27, align 4
  %282 = load <8 x float>, ptr %.slot28, align 32
  %283 = select <8 x i1> %62, <8 x float> %242, <8 x float> %282
  store <8 x float> %283, ptr %.slot28, align 32
  %284 = load <8 x float>, ptr %.slot29, align 32
  %285 = select <8 x i1> %62, <8 x float> %255, <8 x float> %284
  store <8 x float> %285, ptr %.slot29, align 32
  %286 = load <8 x float>, ptr %.slot30, align 32
  %287 = select <8 x i1> %62, <8 x float> %268, <8 x float> %286
  store <8 x float> %287, ptr %.slot30, align 32
  %288 = load <8 x float>, ptr %.slot31, align 32
  %289 = select <8 x i1> %62, <8 x float> %281, <8 x float> %288
  store <8 x float> %289, ptr %.slot31, align 32
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state128 = load i64, ptr %.slot27, align 4
  %290 = icmp slt i64 %.state128, 512
  br i1 %290, label %direct.true129, label %direct.false130

direct.schedule.14:                               ; preds = %direct.true129
  %.state131 = load i64, ptr %.slot27, align 4
  %291 = add i64 %.state131, 0
  %tile_snapshot.spill.load132 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill24, align 64
  %292 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load132, 0
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load132, 1
  %.splatinsert133 = insertelement <8 x i64> poison, i64 %291, i64 0
  %.splat134 = shufflevector <8 x i64> %.splatinsert133, <8 x i64> poison, <8 x i32> zeroinitializer
  %294 = mul <8 x i64> %.splat134, splat (i64 32)
  %295 = add <8 x i64> %293, %294
  %296 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %292, 0
  %297 = insertvalue { <8 x ptr>, <8 x i64> } %296, <8 x i64> %295, 1
  %298 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %299 = extractvalue { <8 x ptr>, <8 x i64> } %297, 1
  %300 = extractelement <8 x ptr> %298, i32 0
  %301 = extractelement <8 x i64> %299, i32 0
  %302 = sub i64 %301, 0
  %303 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %304 = select i1 %303, i64 %302, i64 0
  %private.contiguous.address135 = getelementptr i8, ptr %300, i64 %304
  %private.contiguous.load136 = load <8 x float>, ptr %private.contiguous.address135, align 4
  %305 = select <8 x i1> %62, <8 x float> %private.contiguous.load136, <8 x float> zeroinitializer
  %.state137 = load <8 x float>, ptr %.slot28, align 32
  %306 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state137, <8 x float> %305)
  %.state138 = load i64, ptr %.slot27, align 4
  %307 = add i64 %.state138, 1
  %tile_snapshot.spill.load139 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill24, align 64
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load139, 0
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load139, 1
  %.splatinsert140 = insertelement <8 x i64> poison, i64 %307, i64 0
  %.splat141 = shufflevector <8 x i64> %.splatinsert140, <8 x i64> poison, <8 x i32> zeroinitializer
  %310 = mul <8 x i64> %.splat141, splat (i64 32)
  %311 = add <8 x i64> %309, %310
  %312 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %308, 0
  %313 = insertvalue { <8 x ptr>, <8 x i64> } %312, <8 x i64> %311, 1
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %313, 1
  %316 = extractelement <8 x ptr> %314, i32 0
  %317 = extractelement <8 x i64> %315, i32 0
  %318 = sub i64 %317, 0
  %319 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %320 = select i1 %319, i64 %318, i64 0
  %private.contiguous.address142 = getelementptr i8, ptr %316, i64 %320
  %private.contiguous.load143 = load <8 x float>, ptr %private.contiguous.address142, align 4
  %321 = select <8 x i1> %62, <8 x float> %private.contiguous.load143, <8 x float> zeroinitializer
  %.state144 = load <8 x float>, ptr %.slot29, align 32
  %322 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state144, <8 x float> %321)
  %.state145 = load i64, ptr %.slot27, align 4
  %323 = add i64 %.state145, 2
  %tile_snapshot.spill.load146 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill24, align 64
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load146, 0
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load146, 1
  %.splatinsert147 = insertelement <8 x i64> poison, i64 %323, i64 0
  %.splat148 = shufflevector <8 x i64> %.splatinsert147, <8 x i64> poison, <8 x i32> zeroinitializer
  %326 = mul <8 x i64> %.splat148, splat (i64 32)
  %327 = add <8 x i64> %325, %326
  %328 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %324, 0
  %329 = insertvalue { <8 x ptr>, <8 x i64> } %328, <8 x i64> %327, 1
  %330 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %331 = extractvalue { <8 x ptr>, <8 x i64> } %329, 1
  %332 = extractelement <8 x ptr> %330, i32 0
  %333 = extractelement <8 x i64> %331, i32 0
  %334 = sub i64 %333, 0
  %335 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %336 = select i1 %335, i64 %334, i64 0
  %private.contiguous.address149 = getelementptr i8, ptr %332, i64 %336
  %private.contiguous.load150 = load <8 x float>, ptr %private.contiguous.address149, align 4
  %337 = select <8 x i1> %62, <8 x float> %private.contiguous.load150, <8 x float> zeroinitializer
  %.state151 = load <8 x float>, ptr %.slot30, align 32
  %338 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state151, <8 x float> %337)
  %.state152 = load i64, ptr %.slot27, align 4
  %339 = add i64 %.state152, 3
  %tile_snapshot.spill.load153 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill24, align 64
  %340 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load153, 0
  %341 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load153, 1
  %.splatinsert154 = insertelement <8 x i64> poison, i64 %339, i64 0
  %.splat155 = shufflevector <8 x i64> %.splatinsert154, <8 x i64> poison, <8 x i32> zeroinitializer
  %342 = mul <8 x i64> %.splat155, splat (i64 32)
  %343 = add <8 x i64> %341, %342
  %344 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %340, 0
  %345 = insertvalue { <8 x ptr>, <8 x i64> } %344, <8 x i64> %343, 1
  %346 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %347 = extractvalue { <8 x ptr>, <8 x i64> } %345, 1
  %348 = extractelement <8 x ptr> %346, i32 0
  %349 = extractelement <8 x i64> %347, i32 0
  %350 = sub i64 %349, 0
  %351 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %352 = select i1 %351, i64 %350, i64 0
  %private.contiguous.address156 = getelementptr i8, ptr %348, i64 %352
  %private.contiguous.load157 = load <8 x float>, ptr %private.contiguous.address156, align 4
  %353 = select <8 x i1> %62, <8 x float> %private.contiguous.load157, <8 x float> zeroinitializer
  %.state158 = load <8 x float>, ptr %.slot31, align 32
  %354 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state158, <8 x float> %353)
  %.state159 = load i64, ptr %.slot27, align 4
  %355 = add i64 %.state159, 4
  store i64 %355, ptr %.slot27, align 4
  %356 = load <8 x float>, ptr %.slot28, align 32
  %357 = select <8 x i1> %62, <8 x float> %306, <8 x float> %356
  store <8 x float> %357, ptr %.slot28, align 32
  %358 = load <8 x float>, ptr %.slot29, align 32
  %359 = select <8 x i1> %62, <8 x float> %322, <8 x float> %358
  store <8 x float> %359, ptr %.slot29, align 32
  %360 = load <8 x float>, ptr %.slot30, align 32
  %361 = select <8 x i1> %62, <8 x float> %338, <8 x float> %360
  store <8 x float> %361, ptr %.slot30, align 32
  %362 = load <8 x float>, ptr %.slot31, align 32
  %363 = select <8 x i1> %62, <8 x float> %354, <8 x float> %362
  store <8 x float> %363, ptr %.slot31, align 32
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false130
  %.state160 = load <8 x float>, ptr %.slot28, align 32
  %.state161 = load <8 x float>, ptr %.slot29, align 32
  %364 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state160, <8 x float> %.state161)
  %.state162 = load <8 x float>, ptr %.slot30, align 32
  %365 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %364, <8 x float> %.state162)
  %.state163 = load <8 x float>, ptr %.slot31, align 32
  %366 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %365, <8 x float> %.state163)
  %.spill.load164 = load <8 x i64>, ptr %.spill, align 64
  %367 = trunc <8 x i64> %.spill.load164 to <8 x i32>
  %368 = xor <8 x i32> %367, splat (i32 1)
  %369 = load <8 x i32>, ptr %.spill32, align 32
  %370 = select <8 x i1> %62, <8 x i32> %368, <8 x i32> %369
  store <8 x i32> %370, ptr %.spill32, align 32
  %371 = extractelement <8 x i32> %368, i64 0
  %372 = icmp ult i32 %371, 8
  %373 = select i1 %372, i32 %371, i32 0
  %374 = extractelement <8 x i1> %62, i32 %373
  %375 = extractelement <8 x i1> %62, i64 0
  %376 = and i1 %372, %374
  %377 = and i1 %375, %376
  %378 = extractelement <8 x float> %366, i32 %373
  %379 = select i1 %377, float %378, float 0.000000e+00
  %380 = insertelement <8 x float> poison, float %379, i64 0
  %381 = xor i1 %377, true
  %382 = and i1 %375, %381
  %383 = insertelement <8 x i1> poison, i1 %382, i64 0
  %384 = extractelement <8 x i32> %368, i64 1
  %385 = icmp ult i32 %384, 8
  %386 = select i1 %385, i32 %384, i32 0
  %387 = extractelement <8 x i1> %62, i32 %386
  %388 = extractelement <8 x i1> %62, i64 1
  %389 = and i1 %385, %387
  %390 = and i1 %388, %389
  %391 = extractelement <8 x float> %366, i32 %386
  %392 = select i1 %390, float %391, float 0.000000e+00
  %393 = insertelement <8 x float> %380, float %392, i64 1
  %394 = xor i1 %390, true
  %395 = and i1 %388, %394
  %396 = insertelement <8 x i1> %383, i1 %395, i64 1
  %397 = extractelement <8 x i32> %368, i64 2
  %398 = icmp ult i32 %397, 8
  %399 = select i1 %398, i32 %397, i32 0
  %400 = extractelement <8 x i1> %62, i32 %399
  %401 = extractelement <8 x i1> %62, i64 2
  %402 = and i1 %398, %400
  %403 = and i1 %401, %402
  %404 = extractelement <8 x float> %366, i32 %399
  %405 = select i1 %403, float %404, float 0.000000e+00
  %406 = insertelement <8 x float> %393, float %405, i64 2
  %407 = xor i1 %403, true
  %408 = and i1 %401, %407
  %409 = insertelement <8 x i1> %396, i1 %408, i64 2
  %410 = extractelement <8 x i32> %368, i64 3
  %411 = icmp ult i32 %410, 8
  %412 = select i1 %411, i32 %410, i32 0
  %413 = extractelement <8 x i1> %62, i32 %412
  %414 = extractelement <8 x i1> %62, i64 3
  %415 = and i1 %411, %413
  %416 = and i1 %414, %415
  %417 = extractelement <8 x float> %366, i32 %412
  %418 = select i1 %416, float %417, float 0.000000e+00
  %419 = insertelement <8 x float> %406, float %418, i64 3
  %420 = xor i1 %416, true
  %421 = and i1 %414, %420
  %422 = insertelement <8 x i1> %409, i1 %421, i64 3
  %423 = extractelement <8 x i32> %368, i64 4
  %424 = icmp ult i32 %423, 8
  %425 = select i1 %424, i32 %423, i32 0
  %426 = extractelement <8 x i1> %62, i32 %425
  %427 = extractelement <8 x i1> %62, i64 4
  %428 = and i1 %424, %426
  %429 = and i1 %427, %428
  %430 = extractelement <8 x float> %366, i32 %425
  %431 = select i1 %429, float %430, float 0.000000e+00
  %432 = insertelement <8 x float> %419, float %431, i64 4
  %433 = xor i1 %429, true
  %434 = and i1 %427, %433
  %435 = insertelement <8 x i1> %422, i1 %434, i64 4
  %436 = extractelement <8 x i32> %368, i64 5
  %437 = icmp ult i32 %436, 8
  %438 = select i1 %437, i32 %436, i32 0
  %439 = extractelement <8 x i1> %62, i32 %438
  %440 = extractelement <8 x i1> %62, i64 5
  %441 = and i1 %437, %439
  %442 = and i1 %440, %441
  %443 = extractelement <8 x float> %366, i32 %438
  %444 = select i1 %442, float %443, float 0.000000e+00
  %445 = insertelement <8 x float> %432, float %444, i64 5
  %446 = xor i1 %442, true
  %447 = and i1 %440, %446
  %448 = insertelement <8 x i1> %435, i1 %447, i64 5
  %449 = extractelement <8 x i32> %368, i64 6
  %450 = icmp ult i32 %449, 8
  %451 = select i1 %450, i32 %449, i32 0
  %452 = extractelement <8 x i1> %62, i32 %451
  %453 = extractelement <8 x i1> %62, i64 6
  %454 = and i1 %450, %452
  %455 = and i1 %453, %454
  %456 = extractelement <8 x float> %366, i32 %451
  %457 = select i1 %455, float %456, float 0.000000e+00
  %458 = insertelement <8 x float> %445, float %457, i64 6
  %459 = xor i1 %455, true
  %460 = and i1 %453, %459
  %461 = insertelement <8 x i1> %448, i1 %460, i64 6
  %462 = extractelement <8 x i32> %368, i64 7
  %463 = icmp ult i32 %462, 8
  %464 = select i1 %463, i32 %462, i32 0
  %465 = extractelement <8 x i1> %62, i32 %464
  %466 = extractelement <8 x i1> %62, i64 7
  %467 = and i1 %463, %465
  %468 = and i1 %466, %467
  %469 = extractelement <8 x float> %366, i32 %464
  %470 = select i1 %468, float %469, float 0.000000e+00
  %471 = insertelement <8 x float> %458, float %470, i64 7
  %472 = xor i1 %468, true
  %473 = and i1 %466, %472
  %474 = insertelement <8 x i1> %461, i1 %473, i64 7
  %475 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %366, <8 x float> %471)
  %476 = xor <8 x i32> %367, splat (i32 2)
  %477 = load <8 x i32>, ptr %.spill33, align 32
  %478 = select <8 x i1> %62, <8 x i32> %476, <8 x i32> %477
  store <8 x i32> %478, ptr %.spill33, align 32
  %479 = extractelement <8 x i32> %476, i64 0
  %480 = icmp ult i32 %479, 8
  %481 = select i1 %480, i32 %479, i32 0
  %482 = extractelement <8 x i1> %62, i32 %481
  %483 = extractelement <8 x i1> %62, i64 0
  %484 = and i1 %480, %482
  %485 = and i1 %483, %484
  %486 = extractelement <8 x float> %475, i32 %481
  %487 = select i1 %485, float %486, float 0.000000e+00
  %488 = insertelement <8 x float> poison, float %487, i64 0
  %489 = xor i1 %485, true
  %490 = and i1 %483, %489
  %491 = insertelement <8 x i1> poison, i1 %490, i64 0
  %492 = extractelement <8 x i32> %476, i64 1
  %493 = icmp ult i32 %492, 8
  %494 = select i1 %493, i32 %492, i32 0
  %495 = extractelement <8 x i1> %62, i32 %494
  %496 = extractelement <8 x i1> %62, i64 1
  %497 = and i1 %493, %495
  %498 = and i1 %496, %497
  %499 = extractelement <8 x float> %475, i32 %494
  %500 = select i1 %498, float %499, float 0.000000e+00
  %501 = insertelement <8 x float> %488, float %500, i64 1
  %502 = xor i1 %498, true
  %503 = and i1 %496, %502
  %504 = insertelement <8 x i1> %491, i1 %503, i64 1
  %505 = extractelement <8 x i32> %476, i64 2
  %506 = icmp ult i32 %505, 8
  %507 = select i1 %506, i32 %505, i32 0
  %508 = extractelement <8 x i1> %62, i32 %507
  %509 = extractelement <8 x i1> %62, i64 2
  %510 = and i1 %506, %508
  %511 = and i1 %509, %510
  %512 = extractelement <8 x float> %475, i32 %507
  %513 = select i1 %511, float %512, float 0.000000e+00
  %514 = insertelement <8 x float> %501, float %513, i64 2
  %515 = xor i1 %511, true
  %516 = and i1 %509, %515
  %517 = insertelement <8 x i1> %504, i1 %516, i64 2
  %518 = extractelement <8 x i32> %476, i64 3
  %519 = icmp ult i32 %518, 8
  %520 = select i1 %519, i32 %518, i32 0
  %521 = extractelement <8 x i1> %62, i32 %520
  %522 = extractelement <8 x i1> %62, i64 3
  %523 = and i1 %519, %521
  %524 = and i1 %522, %523
  %525 = extractelement <8 x float> %475, i32 %520
  %526 = select i1 %524, float %525, float 0.000000e+00
  %527 = insertelement <8 x float> %514, float %526, i64 3
  %528 = xor i1 %524, true
  %529 = and i1 %522, %528
  %530 = insertelement <8 x i1> %517, i1 %529, i64 3
  %531 = extractelement <8 x i32> %476, i64 4
  %532 = icmp ult i32 %531, 8
  %533 = select i1 %532, i32 %531, i32 0
  %534 = extractelement <8 x i1> %62, i32 %533
  %535 = extractelement <8 x i1> %62, i64 4
  %536 = and i1 %532, %534
  %537 = and i1 %535, %536
  %538 = extractelement <8 x float> %475, i32 %533
  %539 = select i1 %537, float %538, float 0.000000e+00
  %540 = insertelement <8 x float> %527, float %539, i64 4
  %541 = xor i1 %537, true
  %542 = and i1 %535, %541
  %543 = insertelement <8 x i1> %530, i1 %542, i64 4
  %544 = extractelement <8 x i32> %476, i64 5
  %545 = icmp ult i32 %544, 8
  %546 = select i1 %545, i32 %544, i32 0
  %547 = extractelement <8 x i1> %62, i32 %546
  %548 = extractelement <8 x i1> %62, i64 5
  %549 = and i1 %545, %547
  %550 = and i1 %548, %549
  %551 = extractelement <8 x float> %475, i32 %546
  %552 = select i1 %550, float %551, float 0.000000e+00
  %553 = insertelement <8 x float> %540, float %552, i64 5
  %554 = xor i1 %550, true
  %555 = and i1 %548, %554
  %556 = insertelement <8 x i1> %543, i1 %555, i64 5
  %557 = extractelement <8 x i32> %476, i64 6
  %558 = icmp ult i32 %557, 8
  %559 = select i1 %558, i32 %557, i32 0
  %560 = extractelement <8 x i1> %62, i32 %559
  %561 = extractelement <8 x i1> %62, i64 6
  %562 = and i1 %558, %560
  %563 = and i1 %561, %562
  %564 = extractelement <8 x float> %475, i32 %559
  %565 = select i1 %563, float %564, float 0.000000e+00
  %566 = insertelement <8 x float> %553, float %565, i64 6
  %567 = xor i1 %563, true
  %568 = and i1 %561, %567
  %569 = insertelement <8 x i1> %556, i1 %568, i64 6
  %570 = extractelement <8 x i32> %476, i64 7
  %571 = icmp ult i32 %570, 8
  %572 = select i1 %571, i32 %570, i32 0
  %573 = extractelement <8 x i1> %62, i32 %572
  %574 = extractelement <8 x i1> %62, i64 7
  %575 = and i1 %571, %573
  %576 = and i1 %574, %575
  %577 = extractelement <8 x float> %475, i32 %572
  %578 = select i1 %576, float %577, float 0.000000e+00
  %579 = insertelement <8 x float> %566, float %578, i64 7
  %580 = xor i1 %576, true
  %581 = and i1 %574, %580
  %582 = insertelement <8 x i1> %569, i1 %581, i64 7
  %583 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %475, <8 x float> %579)
  %584 = xor <8 x i32> %367, splat (i32 4)
  %585 = load <8 x i32>, ptr %.spill34, align 32
  %586 = select <8 x i1> %62, <8 x i32> %584, <8 x i32> %585
  store <8 x i32> %586, ptr %.spill34, align 32
  %587 = extractelement <8 x i32> %584, i64 0
  %588 = icmp ult i32 %587, 8
  %589 = select i1 %588, i32 %587, i32 0
  %590 = extractelement <8 x i1> %62, i32 %589
  %591 = extractelement <8 x i1> %62, i64 0
  %592 = and i1 %588, %590
  %593 = and i1 %591, %592
  %594 = extractelement <8 x float> %583, i32 %589
  %595 = select i1 %593, float %594, float 0.000000e+00
  %596 = insertelement <8 x float> poison, float %595, i64 0
  %597 = xor i1 %593, true
  %598 = and i1 %591, %597
  %599 = insertelement <8 x i1> poison, i1 %598, i64 0
  %600 = extractelement <8 x i32> %584, i64 1
  %601 = icmp ult i32 %600, 8
  %602 = select i1 %601, i32 %600, i32 0
  %603 = extractelement <8 x i1> %62, i32 %602
  %604 = extractelement <8 x i1> %62, i64 1
  %605 = and i1 %601, %603
  %606 = and i1 %604, %605
  %607 = extractelement <8 x float> %583, i32 %602
  %608 = select i1 %606, float %607, float 0.000000e+00
  %609 = insertelement <8 x float> %596, float %608, i64 1
  %610 = xor i1 %606, true
  %611 = and i1 %604, %610
  %612 = insertelement <8 x i1> %599, i1 %611, i64 1
  %613 = extractelement <8 x i32> %584, i64 2
  %614 = icmp ult i32 %613, 8
  %615 = select i1 %614, i32 %613, i32 0
  %616 = extractelement <8 x i1> %62, i32 %615
  %617 = extractelement <8 x i1> %62, i64 2
  %618 = and i1 %614, %616
  %619 = and i1 %617, %618
  %620 = extractelement <8 x float> %583, i32 %615
  %621 = select i1 %619, float %620, float 0.000000e+00
  %622 = insertelement <8 x float> %609, float %621, i64 2
  %623 = xor i1 %619, true
  %624 = and i1 %617, %623
  %625 = insertelement <8 x i1> %612, i1 %624, i64 2
  %626 = extractelement <8 x i32> %584, i64 3
  %627 = icmp ult i32 %626, 8
  %628 = select i1 %627, i32 %626, i32 0
  %629 = extractelement <8 x i1> %62, i32 %628
  %630 = extractelement <8 x i1> %62, i64 3
  %631 = and i1 %627, %629
  %632 = and i1 %630, %631
  %633 = extractelement <8 x float> %583, i32 %628
  %634 = select i1 %632, float %633, float 0.000000e+00
  %635 = insertelement <8 x float> %622, float %634, i64 3
  %636 = xor i1 %632, true
  %637 = and i1 %630, %636
  %638 = insertelement <8 x i1> %625, i1 %637, i64 3
  %639 = extractelement <8 x i32> %584, i64 4
  %640 = icmp ult i32 %639, 8
  %641 = select i1 %640, i32 %639, i32 0
  %642 = extractelement <8 x i1> %62, i32 %641
  %643 = extractelement <8 x i1> %62, i64 4
  %644 = and i1 %640, %642
  %645 = and i1 %643, %644
  %646 = extractelement <8 x float> %583, i32 %641
  %647 = select i1 %645, float %646, float 0.000000e+00
  %648 = insertelement <8 x float> %635, float %647, i64 4
  %649 = xor i1 %645, true
  %650 = and i1 %643, %649
  %651 = insertelement <8 x i1> %638, i1 %650, i64 4
  %652 = extractelement <8 x i32> %584, i64 5
  %653 = icmp ult i32 %652, 8
  %654 = select i1 %653, i32 %652, i32 0
  %655 = extractelement <8 x i1> %62, i32 %654
  %656 = extractelement <8 x i1> %62, i64 5
  %657 = and i1 %653, %655
  %658 = and i1 %656, %657
  %659 = extractelement <8 x float> %583, i32 %654
  %660 = select i1 %658, float %659, float 0.000000e+00
  %661 = insertelement <8 x float> %648, float %660, i64 5
  %662 = xor i1 %658, true
  %663 = and i1 %656, %662
  %664 = insertelement <8 x i1> %651, i1 %663, i64 5
  %665 = extractelement <8 x i32> %584, i64 6
  %666 = icmp ult i32 %665, 8
  %667 = select i1 %666, i32 %665, i32 0
  %668 = extractelement <8 x i1> %62, i32 %667
  %669 = extractelement <8 x i1> %62, i64 6
  %670 = and i1 %666, %668
  %671 = and i1 %669, %670
  %672 = extractelement <8 x float> %583, i32 %667
  %673 = select i1 %671, float %672, float 0.000000e+00
  %674 = insertelement <8 x float> %661, float %673, i64 6
  %675 = xor i1 %671, true
  %676 = and i1 %669, %675
  %677 = insertelement <8 x i1> %664, i1 %676, i64 6
  %678 = extractelement <8 x i32> %584, i64 7
  %679 = icmp ult i32 %678, 8
  %680 = select i1 %679, i32 %678, i32 0
  %681 = extractelement <8 x i1> %62, i32 %680
  %682 = extractelement <8 x i1> %62, i64 7
  %683 = and i1 %679, %681
  %684 = and i1 %682, %683
  %685 = extractelement <8 x float> %583, i32 %680
  %686 = select i1 %684, float %685, float 0.000000e+00
  %687 = insertelement <8 x float> %674, float %686, i64 7
  %688 = xor i1 %684, true
  %689 = and i1 %682, %688
  %690 = insertelement <8 x i1> %677, i1 %689, i64 7
  %691 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %583, <8 x float> %687)
  %692 = extractelement <8 x i1> %62, i32 0
  %693 = extractelement <8 x i1> %62, i64 0
  %694 = and i1 true, %692
  %695 = and i1 %693, %694
  %696 = extractelement <8 x float> %691, i32 0
  %697 = select i1 %695, float %696, float 0.000000e+00
  %698 = insertelement <8 x float> poison, float %697, i64 0
  %699 = xor i1 %695, true
  %700 = and i1 %693, %699
  %701 = insertelement <8 x i1> poison, i1 %700, i64 0
  %702 = extractelement <8 x i1> %62, i32 0
  %703 = extractelement <8 x i1> %62, i64 1
  %704 = and i1 true, %702
  %705 = and i1 %703, %704
  %706 = extractelement <8 x float> %691, i32 0
  %707 = select i1 %705, float %706, float 0.000000e+00
  %708 = insertelement <8 x float> %698, float %707, i64 1
  %709 = xor i1 %705, true
  %710 = and i1 %703, %709
  %711 = insertelement <8 x i1> %701, i1 %710, i64 1
  %712 = extractelement <8 x i1> %62, i32 0
  %713 = extractelement <8 x i1> %62, i64 2
  %714 = and i1 true, %712
  %715 = and i1 %713, %714
  %716 = extractelement <8 x float> %691, i32 0
  %717 = select i1 %715, float %716, float 0.000000e+00
  %718 = insertelement <8 x float> %708, float %717, i64 2
  %719 = xor i1 %715, true
  %720 = and i1 %713, %719
  %721 = insertelement <8 x i1> %711, i1 %720, i64 2
  %722 = extractelement <8 x i1> %62, i32 0
  %723 = extractelement <8 x i1> %62, i64 3
  %724 = and i1 true, %722
  %725 = and i1 %723, %724
  %726 = extractelement <8 x float> %691, i32 0
  %727 = select i1 %725, float %726, float 0.000000e+00
  %728 = insertelement <8 x float> %718, float %727, i64 3
  %729 = xor i1 %725, true
  %730 = and i1 %723, %729
  %731 = insertelement <8 x i1> %721, i1 %730, i64 3
  %732 = extractelement <8 x i1> %62, i32 0
  %733 = extractelement <8 x i1> %62, i64 4
  %734 = and i1 true, %732
  %735 = and i1 %733, %734
  %736 = extractelement <8 x float> %691, i32 0
  %737 = select i1 %735, float %736, float 0.000000e+00
  %738 = insertelement <8 x float> %728, float %737, i64 4
  %739 = xor i1 %735, true
  %740 = and i1 %733, %739
  %741 = insertelement <8 x i1> %731, i1 %740, i64 4
  %742 = extractelement <8 x i1> %62, i32 0
  %743 = extractelement <8 x i1> %62, i64 5
  %744 = and i1 true, %742
  %745 = and i1 %743, %744
  %746 = extractelement <8 x float> %691, i32 0
  %747 = select i1 %745, float %746, float 0.000000e+00
  %748 = insertelement <8 x float> %738, float %747, i64 5
  %749 = xor i1 %745, true
  %750 = and i1 %743, %749
  %751 = insertelement <8 x i1> %741, i1 %750, i64 5
  %752 = extractelement <8 x i1> %62, i32 0
  %753 = extractelement <8 x i1> %62, i64 6
  %754 = and i1 true, %752
  %755 = and i1 %753, %754
  %756 = extractelement <8 x float> %691, i32 0
  %757 = select i1 %755, float %756, float 0.000000e+00
  %758 = insertelement <8 x float> %748, float %757, i64 6
  %759 = xor i1 %755, true
  %760 = and i1 %753, %759
  %761 = insertelement <8 x i1> %751, i1 %760, i64 6
  %762 = extractelement <8 x i1> %62, i32 0
  %763 = extractelement <8 x i1> %62, i64 7
  %764 = and i1 true, %762
  %765 = and i1 %763, %764
  %766 = extractelement <8 x float> %691, i32 0
  %767 = select i1 %765, float %766, float 0.000000e+00
  %768 = insertelement <8 x float> %758, float %767, i64 7
  %769 = xor i1 %765, true
  %770 = and i1 %763, %769
  %771 = insertelement <8 x i1> %761, i1 %770, i64 7
  %772 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %773 = bitcast <8 x i1> %62 to i8
  %774 = call i8 @llvm.cttz.i8(i8 %773, i1 false)
  %775 = zext i8 %774 to i32
  %776 = select i1 %772, i32 %775, i32 0
  %777 = extractelement <8 x float> %768, i32 %776
  %.spill.load165 = load float, ptr %.spill26, align 4
  %778 = call float @llvm.maxnum.f32(float %.spill.load165, float %777)
  store float %778, ptr %.spill35, align 4
  store float 0.000000e+00, ptr %.spill36, align 4
  %779 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %780 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %781 = extractvalue { <8 x ptr>, <8 x i64> } %779, 0
  %782 = select <8 x i1> %62, <8 x ptr> %780, <8 x ptr> %781
  %783 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %784 = extractvalue { <8 x ptr>, <8 x i64> } %779, 1
  %785 = select <8 x i1> %62, <8 x i64> %783, <8 x i64> %784
  %786 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %782, 0
  %787 = insertvalue { <8 x ptr>, <8 x i64> } %786, <8 x i64> %785, 1
  store { <8 x ptr>, <8 x i64> } %787, ptr %tile_snapshot.spill37, align 64
  store i64 0, ptr %.slot38, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state166 = load i64, ptr %.slot38, align 4
  %788 = icmp slt i64 %.state166, 512
  br i1 %788, label %direct.true167, label %direct.false168

direct.schedule.17:                               ; preds = %direct.true167
  %tile_snapshot.spill.load169 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %789 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load169, 0
  %790 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load169, 1
  %.state170 = load i64, ptr %.slot38, align 4
  %.splatinsert171 = insertelement <8 x i64> poison, i64 %.state170, i64 0
  %.splat172 = shufflevector <8 x i64> %.splatinsert171, <8 x i64> poison, <8 x i32> zeroinitializer
  %791 = add <8 x i64> %790, %.splat172
  %792 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %789, 0
  %793 = insertvalue { <8 x ptr>, <8 x i64> } %792, <8 x i64> %791, 1
  %794 = extractvalue { <8 x ptr>, <8 x i64> } %793, 0
  %795 = extractvalue { <8 x ptr>, <8 x i64> } %793, 1
  %796 = getelementptr i8, <8 x ptr> %794, <8 x i64> %795
  %797 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %796, i32 1, <8 x i1> %62, <8 x i8> zeroinitializer)
  %798 = icmp ne <8 x i8> %797, zeroinitializer
  %tile_snapshot.spill.load173 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill24, align 64
  %799 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load173, 0
  %800 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load173, 1
  %.state174 = load i64, ptr %.slot38, align 4
  %.splatinsert175 = insertelement <8 x i64> poison, i64 %.state174, i64 0
  %.splat176 = shufflevector <8 x i64> %.splatinsert175, <8 x i64> poison, <8 x i32> zeroinitializer
  %801 = mul <8 x i64> %.splat176, splat (i64 32)
  %802 = add <8 x i64> %800, %801
  %803 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %799, 0
  %804 = insertvalue { <8 x ptr>, <8 x i64> } %803, <8 x i64> %802, 1
  %805 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %806 = extractvalue { <8 x ptr>, <8 x i64> } %804, 1
  %807 = extractelement <8 x ptr> %805, i32 0
  %808 = extractelement <8 x i64> %806, i32 0
  %809 = sub i64 %808, 0
  %810 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %811 = select i1 %810, i64 %809, i64 0
  %private.contiguous.address177 = getelementptr i8, ptr %807, i64 %811
  %private.contiguous.load178 = load <8 x float>, ptr %private.contiguous.address177, align 4
  %812 = select <8 x i1> %62, <8 x float> %private.contiguous.load178, <8 x float> zeroinitializer
  %.spill.load179 = load float, ptr %.spill35, align 4
  %.splatinsert180 = insertelement <8 x float> poison, float %.spill.load179, i64 0
  %.splat181 = shufflevector <8 x float> %.splatinsert180, <8 x float> poison, <8 x i32> zeroinitializer
  %813 = fsub <8 x float> %812, %.splat181
  %814 = select <8 x i1> %62, <8 x float> %813, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %814)
  %.spill.load182 = load float, ptr %.spill36, align 4
  %.splatinsert183 = insertelement <8 x float> poison, float %.spill.load182, i64 0
  %.splat184 = shufflevector <8 x float> %.splatinsert183, <8 x float> poison, <8 x i32> zeroinitializer
  %815 = select <8 x i1> %798, <8 x float> %native.exp, <8 x float> %.splat184
  %tile_snapshot.spill.load185 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %816 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load185, 0
  %817 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load185, 1
  %.state186 = load i64, ptr %.slot38, align 4
  %.splatinsert187 = insertelement <8 x i64> poison, i64 %.state186, i64 0
  %.splat188 = shufflevector <8 x i64> %.splatinsert187, <8 x i64> poison, <8 x i32> zeroinitializer
  %818 = mul <8 x i64> %.splat188, splat (i64 32)
  %819 = add <8 x i64> %817, %818
  %820 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %816, 0
  %821 = insertvalue { <8 x ptr>, <8 x i64> } %820, <8 x i64> %819, 1
  %822 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %823 = extractvalue { <8 x ptr>, <8 x i64> } %821, 1
  %824 = extractelement <8 x ptr> %822, i32 0
  %825 = extractelement <8 x i64> %823, i32 0
  %826 = sub i64 %825, 0
  %827 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %828 = select i1 %827, i64 %826, i64 0
  %private.contiguous.address189 = getelementptr i8, ptr %824, i64 %828
  %private.contiguous.preserve190 = load <8 x float>, ptr %private.contiguous.address189, align 4
  %829 = select <8 x i1> %62, <8 x float> %815, <8 x float> %private.contiguous.preserve190
  store <8 x float> %829, ptr %private.contiguous.address189, align 4
  %.state191 = load i64, ptr %.slot38, align 4
  %830 = add i64 %.state191, 1
  store i64 %830, ptr %.slot38, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false168
  %tile_snapshot.spill.load192 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %831 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 0
  %832 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 1
  %833 = add <8 x i64> %832, zeroinitializer
  %834 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %831, 0
  %835 = insertvalue { <8 x ptr>, <8 x i64> } %834, <8 x i64> %833, 1
  %836 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %837 = extractvalue { <8 x ptr>, <8 x i64> } %835, 1
  %838 = extractelement <8 x ptr> %836, i32 0
  %839 = extractelement <8 x i64> %837, i32 0
  %840 = sub i64 %839, 0
  %841 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %842 = select i1 %841, i64 %840, i64 0
  %private.contiguous.address193 = getelementptr i8, ptr %838, i64 %842
  %private.contiguous.load194 = load <8 x float>, ptr %private.contiguous.address193, align 4
  %843 = select <8 x i1> %62, <8 x float> %private.contiguous.load194, <8 x float> zeroinitializer
  %tile_snapshot.spill.load195 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %844 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load195, 0
  %845 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load195, 1
  %846 = add <8 x i64> %845, splat (i64 32)
  %847 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %844, 0
  %848 = insertvalue { <8 x ptr>, <8 x i64> } %847, <8 x i64> %846, 1
  %849 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %850 = extractvalue { <8 x ptr>, <8 x i64> } %848, 1
  %851 = extractelement <8 x ptr> %849, i32 0
  %852 = extractelement <8 x i64> %850, i32 0
  %853 = sub i64 %852, 0
  %854 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %855 = select i1 %854, i64 %853, i64 0
  %private.contiguous.address196 = getelementptr i8, ptr %851, i64 %855
  %private.contiguous.load197 = load <8 x float>, ptr %private.contiguous.address196, align 4
  %856 = select <8 x i1> %62, <8 x float> %private.contiguous.load197, <8 x float> zeroinitializer
  %tile_snapshot.spill.load198 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %857 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load198, 0
  %858 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load198, 1
  %859 = add <8 x i64> %858, splat (i64 64)
  %860 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %857, 0
  %861 = insertvalue { <8 x ptr>, <8 x i64> } %860, <8 x i64> %859, 1
  %862 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %863 = extractvalue { <8 x ptr>, <8 x i64> } %861, 1
  %864 = extractelement <8 x ptr> %862, i32 0
  %865 = extractelement <8 x i64> %863, i32 0
  %866 = sub i64 %865, 0
  %867 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %868 = select i1 %867, i64 %866, i64 0
  %private.contiguous.address199 = getelementptr i8, ptr %864, i64 %868
  %private.contiguous.load200 = load <8 x float>, ptr %private.contiguous.address199, align 4
  %869 = select <8 x i1> %62, <8 x float> %private.contiguous.load200, <8 x float> zeroinitializer
  %tile_snapshot.spill.load201 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %870 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load201, 0
  %871 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load201, 1
  %872 = add <8 x i64> %871, splat (i64 96)
  %873 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %870, 0
  %874 = insertvalue { <8 x ptr>, <8 x i64> } %873, <8 x i64> %872, 1
  %875 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %876 = extractvalue { <8 x ptr>, <8 x i64> } %874, 1
  %877 = extractelement <8 x ptr> %875, i32 0
  %878 = extractelement <8 x i64> %876, i32 0
  %879 = sub i64 %878, 0
  %880 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %881 = select i1 %880, i64 %879, i64 0
  %private.contiguous.address202 = getelementptr i8, ptr %877, i64 %881
  %private.contiguous.load203 = load <8 x float>, ptr %private.contiguous.address202, align 4
  %882 = select <8 x i1> %62, <8 x float> %private.contiguous.load203, <8 x float> zeroinitializer
  store i64 4, ptr %.slot39, align 4
  %883 = load <8 x float>, ptr %.slot40, align 32
  %884 = select <8 x i1> %62, <8 x float> %843, <8 x float> %883
  store <8 x float> %884, ptr %.slot40, align 32
  %885 = load <8 x float>, ptr %.slot41, align 32
  %886 = select <8 x i1> %62, <8 x float> %856, <8 x float> %885
  store <8 x float> %886, ptr %.slot41, align 32
  %887 = load <8 x float>, ptr %.slot42, align 32
  %888 = select <8 x i1> %62, <8 x float> %869, <8 x float> %887
  store <8 x float> %888, ptr %.slot42, align 32
  %889 = load <8 x float>, ptr %.slot43, align 32
  %890 = select <8 x i1> %62, <8 x float> %882, <8 x float> %889
  store <8 x float> %890, ptr %.slot43, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state204 = load i64, ptr %.slot39, align 4
  %891 = icmp slt i64 %.state204, 512
  br i1 %891, label %direct.true205, label %direct.false206

direct.schedule.20:                               ; preds = %direct.true205
  %.state207 = load i64, ptr %.slot39, align 4
  %892 = add i64 %.state207, 0
  %tile_snapshot.spill.load208 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %893 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load208, 0
  %894 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load208, 1
  %.splatinsert209 = insertelement <8 x i64> poison, i64 %892, i64 0
  %.splat210 = shufflevector <8 x i64> %.splatinsert209, <8 x i64> poison, <8 x i32> zeroinitializer
  %895 = mul <8 x i64> %.splat210, splat (i64 32)
  %896 = add <8 x i64> %894, %895
  %897 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %893, 0
  %898 = insertvalue { <8 x ptr>, <8 x i64> } %897, <8 x i64> %896, 1
  %899 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %900 = extractvalue { <8 x ptr>, <8 x i64> } %898, 1
  %901 = extractelement <8 x ptr> %899, i32 0
  %902 = extractelement <8 x i64> %900, i32 0
  %903 = sub i64 %902, 0
  %904 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %905 = select i1 %904, i64 %903, i64 0
  %private.contiguous.address211 = getelementptr i8, ptr %901, i64 %905
  %private.contiguous.load212 = load <8 x float>, ptr %private.contiguous.address211, align 4
  %906 = select <8 x i1> %62, <8 x float> %private.contiguous.load212, <8 x float> zeroinitializer
  %.state213 = load <8 x float>, ptr %.slot40, align 32
  %907 = fadd <8 x float> %.state213, %906
  %.state214 = load i64, ptr %.slot39, align 4
  %908 = add i64 %.state214, 1
  %tile_snapshot.spill.load215 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %909 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load215, 0
  %910 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load215, 1
  %.splatinsert216 = insertelement <8 x i64> poison, i64 %908, i64 0
  %.splat217 = shufflevector <8 x i64> %.splatinsert216, <8 x i64> poison, <8 x i32> zeroinitializer
  %911 = mul <8 x i64> %.splat217, splat (i64 32)
  %912 = add <8 x i64> %910, %911
  %913 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %909, 0
  %914 = insertvalue { <8 x ptr>, <8 x i64> } %913, <8 x i64> %912, 1
  %915 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %916 = extractvalue { <8 x ptr>, <8 x i64> } %914, 1
  %917 = extractelement <8 x ptr> %915, i32 0
  %918 = extractelement <8 x i64> %916, i32 0
  %919 = sub i64 %918, 0
  %920 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %921 = select i1 %920, i64 %919, i64 0
  %private.contiguous.address218 = getelementptr i8, ptr %917, i64 %921
  %private.contiguous.load219 = load <8 x float>, ptr %private.contiguous.address218, align 4
  %922 = select <8 x i1> %62, <8 x float> %private.contiguous.load219, <8 x float> zeroinitializer
  %.state220 = load <8 x float>, ptr %.slot41, align 32
  %923 = fadd <8 x float> %.state220, %922
  %.state221 = load i64, ptr %.slot39, align 4
  %924 = add i64 %.state221, 2
  %tile_snapshot.spill.load222 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %925 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load222, 0
  %926 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load222, 1
  %.splatinsert223 = insertelement <8 x i64> poison, i64 %924, i64 0
  %.splat224 = shufflevector <8 x i64> %.splatinsert223, <8 x i64> poison, <8 x i32> zeroinitializer
  %927 = mul <8 x i64> %.splat224, splat (i64 32)
  %928 = add <8 x i64> %926, %927
  %929 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %925, 0
  %930 = insertvalue { <8 x ptr>, <8 x i64> } %929, <8 x i64> %928, 1
  %931 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %932 = extractvalue { <8 x ptr>, <8 x i64> } %930, 1
  %933 = extractelement <8 x ptr> %931, i32 0
  %934 = extractelement <8 x i64> %932, i32 0
  %935 = sub i64 %934, 0
  %936 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %937 = select i1 %936, i64 %935, i64 0
  %private.contiguous.address225 = getelementptr i8, ptr %933, i64 %937
  %private.contiguous.load226 = load <8 x float>, ptr %private.contiguous.address225, align 4
  %938 = select <8 x i1> %62, <8 x float> %private.contiguous.load226, <8 x float> zeroinitializer
  %.state227 = load <8 x float>, ptr %.slot42, align 32
  %939 = fadd <8 x float> %.state227, %938
  %.state228 = load i64, ptr %.slot39, align 4
  %940 = add i64 %.state228, 3
  %tile_snapshot.spill.load229 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %941 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load229, 0
  %942 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load229, 1
  %.splatinsert230 = insertelement <8 x i64> poison, i64 %940, i64 0
  %.splat231 = shufflevector <8 x i64> %.splatinsert230, <8 x i64> poison, <8 x i32> zeroinitializer
  %943 = mul <8 x i64> %.splat231, splat (i64 32)
  %944 = add <8 x i64> %942, %943
  %945 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %941, 0
  %946 = insertvalue { <8 x ptr>, <8 x i64> } %945, <8 x i64> %944, 1
  %947 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %948 = extractvalue { <8 x ptr>, <8 x i64> } %946, 1
  %949 = extractelement <8 x ptr> %947, i32 0
  %950 = extractelement <8 x i64> %948, i32 0
  %951 = sub i64 %950, 0
  %952 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %953 = select i1 %952, i64 %951, i64 0
  %private.contiguous.address232 = getelementptr i8, ptr %949, i64 %953
  %private.contiguous.load233 = load <8 x float>, ptr %private.contiguous.address232, align 4
  %954 = select <8 x i1> %62, <8 x float> %private.contiguous.load233, <8 x float> zeroinitializer
  %.state234 = load <8 x float>, ptr %.slot43, align 32
  %955 = fadd <8 x float> %.state234, %954
  %.state235 = load i64, ptr %.slot39, align 4
  %956 = add i64 %.state235, 4
  store i64 %956, ptr %.slot39, align 4
  %957 = load <8 x float>, ptr %.slot40, align 32
  %958 = select <8 x i1> %62, <8 x float> %907, <8 x float> %957
  store <8 x float> %958, ptr %.slot40, align 32
  %959 = load <8 x float>, ptr %.slot41, align 32
  %960 = select <8 x i1> %62, <8 x float> %923, <8 x float> %959
  store <8 x float> %960, ptr %.slot41, align 32
  %961 = load <8 x float>, ptr %.slot42, align 32
  %962 = select <8 x i1> %62, <8 x float> %939, <8 x float> %961
  store <8 x float> %962, ptr %.slot42, align 32
  %963 = load <8 x float>, ptr %.slot43, align 32
  %964 = select <8 x i1> %62, <8 x float> %955, <8 x float> %963
  store <8 x float> %964, ptr %.slot43, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false206
  %.state236 = load <8 x float>, ptr %.slot40, align 32
  %.state237 = load <8 x float>, ptr %.slot41, align 32
  %965 = fadd <8 x float> %.state236, %.state237
  %.state238 = load <8 x float>, ptr %.slot42, align 32
  %966 = fadd <8 x float> %965, %.state238
  %.state239 = load <8 x float>, ptr %.slot43, align 32
  %967 = fadd <8 x float> %966, %.state239
  %.spill.load240 = load <8 x i32>, ptr %.spill32, align 32
  %968 = extractelement <8 x i32> %.spill.load240, i64 0
  %969 = icmp ult i32 %968, 8
  %970 = select i1 %969, i32 %968, i32 0
  %971 = extractelement <8 x i1> %62, i32 %970
  %972 = extractelement <8 x i1> %62, i64 0
  %973 = and i1 %969, %971
  %974 = and i1 %972, %973
  %975 = extractelement <8 x float> %967, i32 %970
  %976 = select i1 %974, float %975, float 0.000000e+00
  %977 = insertelement <8 x float> poison, float %976, i64 0
  %978 = xor i1 %974, true
  %979 = and i1 %972, %978
  %980 = insertelement <8 x i1> poison, i1 %979, i64 0
  %981 = extractelement <8 x i32> %.spill.load240, i64 1
  %982 = icmp ult i32 %981, 8
  %983 = select i1 %982, i32 %981, i32 0
  %984 = extractelement <8 x i1> %62, i32 %983
  %985 = extractelement <8 x i1> %62, i64 1
  %986 = and i1 %982, %984
  %987 = and i1 %985, %986
  %988 = extractelement <8 x float> %967, i32 %983
  %989 = select i1 %987, float %988, float 0.000000e+00
  %990 = insertelement <8 x float> %977, float %989, i64 1
  %991 = xor i1 %987, true
  %992 = and i1 %985, %991
  %993 = insertelement <8 x i1> %980, i1 %992, i64 1
  %994 = extractelement <8 x i32> %.spill.load240, i64 2
  %995 = icmp ult i32 %994, 8
  %996 = select i1 %995, i32 %994, i32 0
  %997 = extractelement <8 x i1> %62, i32 %996
  %998 = extractelement <8 x i1> %62, i64 2
  %999 = and i1 %995, %997
  %1000 = and i1 %998, %999
  %1001 = extractelement <8 x float> %967, i32 %996
  %1002 = select i1 %1000, float %1001, float 0.000000e+00
  %1003 = insertelement <8 x float> %990, float %1002, i64 2
  %1004 = xor i1 %1000, true
  %1005 = and i1 %998, %1004
  %1006 = insertelement <8 x i1> %993, i1 %1005, i64 2
  %1007 = extractelement <8 x i32> %.spill.load240, i64 3
  %1008 = icmp ult i32 %1007, 8
  %1009 = select i1 %1008, i32 %1007, i32 0
  %1010 = extractelement <8 x i1> %62, i32 %1009
  %1011 = extractelement <8 x i1> %62, i64 3
  %1012 = and i1 %1008, %1010
  %1013 = and i1 %1011, %1012
  %1014 = extractelement <8 x float> %967, i32 %1009
  %1015 = select i1 %1013, float %1014, float 0.000000e+00
  %1016 = insertelement <8 x float> %1003, float %1015, i64 3
  %1017 = xor i1 %1013, true
  %1018 = and i1 %1011, %1017
  %1019 = insertelement <8 x i1> %1006, i1 %1018, i64 3
  %1020 = extractelement <8 x i32> %.spill.load240, i64 4
  %1021 = icmp ult i32 %1020, 8
  %1022 = select i1 %1021, i32 %1020, i32 0
  %1023 = extractelement <8 x i1> %62, i32 %1022
  %1024 = extractelement <8 x i1> %62, i64 4
  %1025 = and i1 %1021, %1023
  %1026 = and i1 %1024, %1025
  %1027 = extractelement <8 x float> %967, i32 %1022
  %1028 = select i1 %1026, float %1027, float 0.000000e+00
  %1029 = insertelement <8 x float> %1016, float %1028, i64 4
  %1030 = xor i1 %1026, true
  %1031 = and i1 %1024, %1030
  %1032 = insertelement <8 x i1> %1019, i1 %1031, i64 4
  %1033 = extractelement <8 x i32> %.spill.load240, i64 5
  %1034 = icmp ult i32 %1033, 8
  %1035 = select i1 %1034, i32 %1033, i32 0
  %1036 = extractelement <8 x i1> %62, i32 %1035
  %1037 = extractelement <8 x i1> %62, i64 5
  %1038 = and i1 %1034, %1036
  %1039 = and i1 %1037, %1038
  %1040 = extractelement <8 x float> %967, i32 %1035
  %1041 = select i1 %1039, float %1040, float 0.000000e+00
  %1042 = insertelement <8 x float> %1029, float %1041, i64 5
  %1043 = xor i1 %1039, true
  %1044 = and i1 %1037, %1043
  %1045 = insertelement <8 x i1> %1032, i1 %1044, i64 5
  %1046 = extractelement <8 x i32> %.spill.load240, i64 6
  %1047 = icmp ult i32 %1046, 8
  %1048 = select i1 %1047, i32 %1046, i32 0
  %1049 = extractelement <8 x i1> %62, i32 %1048
  %1050 = extractelement <8 x i1> %62, i64 6
  %1051 = and i1 %1047, %1049
  %1052 = and i1 %1050, %1051
  %1053 = extractelement <8 x float> %967, i32 %1048
  %1054 = select i1 %1052, float %1053, float 0.000000e+00
  %1055 = insertelement <8 x float> %1042, float %1054, i64 6
  %1056 = xor i1 %1052, true
  %1057 = and i1 %1050, %1056
  %1058 = insertelement <8 x i1> %1045, i1 %1057, i64 6
  %1059 = extractelement <8 x i32> %.spill.load240, i64 7
  %1060 = icmp ult i32 %1059, 8
  %1061 = select i1 %1060, i32 %1059, i32 0
  %1062 = extractelement <8 x i1> %62, i32 %1061
  %1063 = extractelement <8 x i1> %62, i64 7
  %1064 = and i1 %1060, %1062
  %1065 = and i1 %1063, %1064
  %1066 = extractelement <8 x float> %967, i32 %1061
  %1067 = select i1 %1065, float %1066, float 0.000000e+00
  %1068 = insertelement <8 x float> %1055, float %1067, i64 7
  %1069 = xor i1 %1065, true
  %1070 = and i1 %1063, %1069
  %1071 = insertelement <8 x i1> %1058, i1 %1070, i64 7
  %1072 = fadd <8 x float> %967, %1068
  %.spill.load241 = load <8 x i32>, ptr %.spill33, align 32
  %1073 = extractelement <8 x i32> %.spill.load241, i64 0
  %1074 = icmp ult i32 %1073, 8
  %1075 = select i1 %1074, i32 %1073, i32 0
  %1076 = extractelement <8 x i1> %62, i32 %1075
  %1077 = extractelement <8 x i1> %62, i64 0
  %1078 = and i1 %1074, %1076
  %1079 = and i1 %1077, %1078
  %1080 = extractelement <8 x float> %1072, i32 %1075
  %1081 = select i1 %1079, float %1080, float 0.000000e+00
  %1082 = insertelement <8 x float> poison, float %1081, i64 0
  %1083 = xor i1 %1079, true
  %1084 = and i1 %1077, %1083
  %1085 = insertelement <8 x i1> poison, i1 %1084, i64 0
  %1086 = extractelement <8 x i32> %.spill.load241, i64 1
  %1087 = icmp ult i32 %1086, 8
  %1088 = select i1 %1087, i32 %1086, i32 0
  %1089 = extractelement <8 x i1> %62, i32 %1088
  %1090 = extractelement <8 x i1> %62, i64 1
  %1091 = and i1 %1087, %1089
  %1092 = and i1 %1090, %1091
  %1093 = extractelement <8 x float> %1072, i32 %1088
  %1094 = select i1 %1092, float %1093, float 0.000000e+00
  %1095 = insertelement <8 x float> %1082, float %1094, i64 1
  %1096 = xor i1 %1092, true
  %1097 = and i1 %1090, %1096
  %1098 = insertelement <8 x i1> %1085, i1 %1097, i64 1
  %1099 = extractelement <8 x i32> %.spill.load241, i64 2
  %1100 = icmp ult i32 %1099, 8
  %1101 = select i1 %1100, i32 %1099, i32 0
  %1102 = extractelement <8 x i1> %62, i32 %1101
  %1103 = extractelement <8 x i1> %62, i64 2
  %1104 = and i1 %1100, %1102
  %1105 = and i1 %1103, %1104
  %1106 = extractelement <8 x float> %1072, i32 %1101
  %1107 = select i1 %1105, float %1106, float 0.000000e+00
  %1108 = insertelement <8 x float> %1095, float %1107, i64 2
  %1109 = xor i1 %1105, true
  %1110 = and i1 %1103, %1109
  %1111 = insertelement <8 x i1> %1098, i1 %1110, i64 2
  %1112 = extractelement <8 x i32> %.spill.load241, i64 3
  %1113 = icmp ult i32 %1112, 8
  %1114 = select i1 %1113, i32 %1112, i32 0
  %1115 = extractelement <8 x i1> %62, i32 %1114
  %1116 = extractelement <8 x i1> %62, i64 3
  %1117 = and i1 %1113, %1115
  %1118 = and i1 %1116, %1117
  %1119 = extractelement <8 x float> %1072, i32 %1114
  %1120 = select i1 %1118, float %1119, float 0.000000e+00
  %1121 = insertelement <8 x float> %1108, float %1120, i64 3
  %1122 = xor i1 %1118, true
  %1123 = and i1 %1116, %1122
  %1124 = insertelement <8 x i1> %1111, i1 %1123, i64 3
  %1125 = extractelement <8 x i32> %.spill.load241, i64 4
  %1126 = icmp ult i32 %1125, 8
  %1127 = select i1 %1126, i32 %1125, i32 0
  %1128 = extractelement <8 x i1> %62, i32 %1127
  %1129 = extractelement <8 x i1> %62, i64 4
  %1130 = and i1 %1126, %1128
  %1131 = and i1 %1129, %1130
  %1132 = extractelement <8 x float> %1072, i32 %1127
  %1133 = select i1 %1131, float %1132, float 0.000000e+00
  %1134 = insertelement <8 x float> %1121, float %1133, i64 4
  %1135 = xor i1 %1131, true
  %1136 = and i1 %1129, %1135
  %1137 = insertelement <8 x i1> %1124, i1 %1136, i64 4
  %1138 = extractelement <8 x i32> %.spill.load241, i64 5
  %1139 = icmp ult i32 %1138, 8
  %1140 = select i1 %1139, i32 %1138, i32 0
  %1141 = extractelement <8 x i1> %62, i32 %1140
  %1142 = extractelement <8 x i1> %62, i64 5
  %1143 = and i1 %1139, %1141
  %1144 = and i1 %1142, %1143
  %1145 = extractelement <8 x float> %1072, i32 %1140
  %1146 = select i1 %1144, float %1145, float 0.000000e+00
  %1147 = insertelement <8 x float> %1134, float %1146, i64 5
  %1148 = xor i1 %1144, true
  %1149 = and i1 %1142, %1148
  %1150 = insertelement <8 x i1> %1137, i1 %1149, i64 5
  %1151 = extractelement <8 x i32> %.spill.load241, i64 6
  %1152 = icmp ult i32 %1151, 8
  %1153 = select i1 %1152, i32 %1151, i32 0
  %1154 = extractelement <8 x i1> %62, i32 %1153
  %1155 = extractelement <8 x i1> %62, i64 6
  %1156 = and i1 %1152, %1154
  %1157 = and i1 %1155, %1156
  %1158 = extractelement <8 x float> %1072, i32 %1153
  %1159 = select i1 %1157, float %1158, float 0.000000e+00
  %1160 = insertelement <8 x float> %1147, float %1159, i64 6
  %1161 = xor i1 %1157, true
  %1162 = and i1 %1155, %1161
  %1163 = insertelement <8 x i1> %1150, i1 %1162, i64 6
  %1164 = extractelement <8 x i32> %.spill.load241, i64 7
  %1165 = icmp ult i32 %1164, 8
  %1166 = select i1 %1165, i32 %1164, i32 0
  %1167 = extractelement <8 x i1> %62, i32 %1166
  %1168 = extractelement <8 x i1> %62, i64 7
  %1169 = and i1 %1165, %1167
  %1170 = and i1 %1168, %1169
  %1171 = extractelement <8 x float> %1072, i32 %1166
  %1172 = select i1 %1170, float %1171, float 0.000000e+00
  %1173 = insertelement <8 x float> %1160, float %1172, i64 7
  %1174 = xor i1 %1170, true
  %1175 = and i1 %1168, %1174
  %1176 = insertelement <8 x i1> %1163, i1 %1175, i64 7
  %1177 = fadd <8 x float> %1072, %1173
  %.spill.load242 = load <8 x i32>, ptr %.spill34, align 32
  %1178 = extractelement <8 x i32> %.spill.load242, i64 0
  %1179 = icmp ult i32 %1178, 8
  %1180 = select i1 %1179, i32 %1178, i32 0
  %1181 = extractelement <8 x i1> %62, i32 %1180
  %1182 = extractelement <8 x i1> %62, i64 0
  %1183 = and i1 %1179, %1181
  %1184 = and i1 %1182, %1183
  %1185 = extractelement <8 x float> %1177, i32 %1180
  %1186 = select i1 %1184, float %1185, float 0.000000e+00
  %1187 = insertelement <8 x float> poison, float %1186, i64 0
  %1188 = xor i1 %1184, true
  %1189 = and i1 %1182, %1188
  %1190 = insertelement <8 x i1> poison, i1 %1189, i64 0
  %1191 = extractelement <8 x i32> %.spill.load242, i64 1
  %1192 = icmp ult i32 %1191, 8
  %1193 = select i1 %1192, i32 %1191, i32 0
  %1194 = extractelement <8 x i1> %62, i32 %1193
  %1195 = extractelement <8 x i1> %62, i64 1
  %1196 = and i1 %1192, %1194
  %1197 = and i1 %1195, %1196
  %1198 = extractelement <8 x float> %1177, i32 %1193
  %1199 = select i1 %1197, float %1198, float 0.000000e+00
  %1200 = insertelement <8 x float> %1187, float %1199, i64 1
  %1201 = xor i1 %1197, true
  %1202 = and i1 %1195, %1201
  %1203 = insertelement <8 x i1> %1190, i1 %1202, i64 1
  %1204 = extractelement <8 x i32> %.spill.load242, i64 2
  %1205 = icmp ult i32 %1204, 8
  %1206 = select i1 %1205, i32 %1204, i32 0
  %1207 = extractelement <8 x i1> %62, i32 %1206
  %1208 = extractelement <8 x i1> %62, i64 2
  %1209 = and i1 %1205, %1207
  %1210 = and i1 %1208, %1209
  %1211 = extractelement <8 x float> %1177, i32 %1206
  %1212 = select i1 %1210, float %1211, float 0.000000e+00
  %1213 = insertelement <8 x float> %1200, float %1212, i64 2
  %1214 = xor i1 %1210, true
  %1215 = and i1 %1208, %1214
  %1216 = insertelement <8 x i1> %1203, i1 %1215, i64 2
  %1217 = extractelement <8 x i32> %.spill.load242, i64 3
  %1218 = icmp ult i32 %1217, 8
  %1219 = select i1 %1218, i32 %1217, i32 0
  %1220 = extractelement <8 x i1> %62, i32 %1219
  %1221 = extractelement <8 x i1> %62, i64 3
  %1222 = and i1 %1218, %1220
  %1223 = and i1 %1221, %1222
  %1224 = extractelement <8 x float> %1177, i32 %1219
  %1225 = select i1 %1223, float %1224, float 0.000000e+00
  %1226 = insertelement <8 x float> %1213, float %1225, i64 3
  %1227 = xor i1 %1223, true
  %1228 = and i1 %1221, %1227
  %1229 = insertelement <8 x i1> %1216, i1 %1228, i64 3
  %1230 = extractelement <8 x i32> %.spill.load242, i64 4
  %1231 = icmp ult i32 %1230, 8
  %1232 = select i1 %1231, i32 %1230, i32 0
  %1233 = extractelement <8 x i1> %62, i32 %1232
  %1234 = extractelement <8 x i1> %62, i64 4
  %1235 = and i1 %1231, %1233
  %1236 = and i1 %1234, %1235
  %1237 = extractelement <8 x float> %1177, i32 %1232
  %1238 = select i1 %1236, float %1237, float 0.000000e+00
  %1239 = insertelement <8 x float> %1226, float %1238, i64 4
  %1240 = xor i1 %1236, true
  %1241 = and i1 %1234, %1240
  %1242 = insertelement <8 x i1> %1229, i1 %1241, i64 4
  %1243 = extractelement <8 x i32> %.spill.load242, i64 5
  %1244 = icmp ult i32 %1243, 8
  %1245 = select i1 %1244, i32 %1243, i32 0
  %1246 = extractelement <8 x i1> %62, i32 %1245
  %1247 = extractelement <8 x i1> %62, i64 5
  %1248 = and i1 %1244, %1246
  %1249 = and i1 %1247, %1248
  %1250 = extractelement <8 x float> %1177, i32 %1245
  %1251 = select i1 %1249, float %1250, float 0.000000e+00
  %1252 = insertelement <8 x float> %1239, float %1251, i64 5
  %1253 = xor i1 %1249, true
  %1254 = and i1 %1247, %1253
  %1255 = insertelement <8 x i1> %1242, i1 %1254, i64 5
  %1256 = extractelement <8 x i32> %.spill.load242, i64 6
  %1257 = icmp ult i32 %1256, 8
  %1258 = select i1 %1257, i32 %1256, i32 0
  %1259 = extractelement <8 x i1> %62, i32 %1258
  %1260 = extractelement <8 x i1> %62, i64 6
  %1261 = and i1 %1257, %1259
  %1262 = and i1 %1260, %1261
  %1263 = extractelement <8 x float> %1177, i32 %1258
  %1264 = select i1 %1262, float %1263, float 0.000000e+00
  %1265 = insertelement <8 x float> %1252, float %1264, i64 6
  %1266 = xor i1 %1262, true
  %1267 = and i1 %1260, %1266
  %1268 = insertelement <8 x i1> %1255, i1 %1267, i64 6
  %1269 = extractelement <8 x i32> %.spill.load242, i64 7
  %1270 = icmp ult i32 %1269, 8
  %1271 = select i1 %1270, i32 %1269, i32 0
  %1272 = extractelement <8 x i1> %62, i32 %1271
  %1273 = extractelement <8 x i1> %62, i64 7
  %1274 = and i1 %1270, %1272
  %1275 = and i1 %1273, %1274
  %1276 = extractelement <8 x float> %1177, i32 %1271
  %1277 = select i1 %1275, float %1276, float 0.000000e+00
  %1278 = insertelement <8 x float> %1265, float %1277, i64 7
  %1279 = xor i1 %1275, true
  %1280 = and i1 %1273, %1279
  %1281 = insertelement <8 x i1> %1268, i1 %1280, i64 7
  %1282 = fadd <8 x float> %1177, %1278
  %1283 = extractelement <8 x i1> %62, i32 0
  %1284 = extractelement <8 x i1> %62, i64 0
  %1285 = and i1 true, %1283
  %1286 = and i1 %1284, %1285
  %1287 = extractelement <8 x float> %1282, i32 0
  %1288 = select i1 %1286, float %1287, float 0.000000e+00
  %1289 = insertelement <8 x float> poison, float %1288, i64 0
  %1290 = xor i1 %1286, true
  %1291 = and i1 %1284, %1290
  %1292 = insertelement <8 x i1> poison, i1 %1291, i64 0
  %1293 = extractelement <8 x i1> %62, i32 0
  %1294 = extractelement <8 x i1> %62, i64 1
  %1295 = and i1 true, %1293
  %1296 = and i1 %1294, %1295
  %1297 = extractelement <8 x float> %1282, i32 0
  %1298 = select i1 %1296, float %1297, float 0.000000e+00
  %1299 = insertelement <8 x float> %1289, float %1298, i64 1
  %1300 = xor i1 %1296, true
  %1301 = and i1 %1294, %1300
  %1302 = insertelement <8 x i1> %1292, i1 %1301, i64 1
  %1303 = extractelement <8 x i1> %62, i32 0
  %1304 = extractelement <8 x i1> %62, i64 2
  %1305 = and i1 true, %1303
  %1306 = and i1 %1304, %1305
  %1307 = extractelement <8 x float> %1282, i32 0
  %1308 = select i1 %1306, float %1307, float 0.000000e+00
  %1309 = insertelement <8 x float> %1299, float %1308, i64 2
  %1310 = xor i1 %1306, true
  %1311 = and i1 %1304, %1310
  %1312 = insertelement <8 x i1> %1302, i1 %1311, i64 2
  %1313 = extractelement <8 x i1> %62, i32 0
  %1314 = extractelement <8 x i1> %62, i64 3
  %1315 = and i1 true, %1313
  %1316 = and i1 %1314, %1315
  %1317 = extractelement <8 x float> %1282, i32 0
  %1318 = select i1 %1316, float %1317, float 0.000000e+00
  %1319 = insertelement <8 x float> %1309, float %1318, i64 3
  %1320 = xor i1 %1316, true
  %1321 = and i1 %1314, %1320
  %1322 = insertelement <8 x i1> %1312, i1 %1321, i64 3
  %1323 = extractelement <8 x i1> %62, i32 0
  %1324 = extractelement <8 x i1> %62, i64 4
  %1325 = and i1 true, %1323
  %1326 = and i1 %1324, %1325
  %1327 = extractelement <8 x float> %1282, i32 0
  %1328 = select i1 %1326, float %1327, float 0.000000e+00
  %1329 = insertelement <8 x float> %1319, float %1328, i64 4
  %1330 = xor i1 %1326, true
  %1331 = and i1 %1324, %1330
  %1332 = insertelement <8 x i1> %1322, i1 %1331, i64 4
  %1333 = extractelement <8 x i1> %62, i32 0
  %1334 = extractelement <8 x i1> %62, i64 5
  %1335 = and i1 true, %1333
  %1336 = and i1 %1334, %1335
  %1337 = extractelement <8 x float> %1282, i32 0
  %1338 = select i1 %1336, float %1337, float 0.000000e+00
  %1339 = insertelement <8 x float> %1329, float %1338, i64 5
  %1340 = xor i1 %1336, true
  %1341 = and i1 %1334, %1340
  %1342 = insertelement <8 x i1> %1332, i1 %1341, i64 5
  %1343 = extractelement <8 x i1> %62, i32 0
  %1344 = extractelement <8 x i1> %62, i64 6
  %1345 = and i1 true, %1343
  %1346 = and i1 %1344, %1345
  %1347 = extractelement <8 x float> %1282, i32 0
  %1348 = select i1 %1346, float %1347, float 0.000000e+00
  %1349 = insertelement <8 x float> %1339, float %1348, i64 6
  %1350 = xor i1 %1346, true
  %1351 = and i1 %1344, %1350
  %1352 = insertelement <8 x i1> %1342, i1 %1351, i64 6
  %1353 = extractelement <8 x i1> %62, i32 0
  %1354 = extractelement <8 x i1> %62, i64 7
  %1355 = and i1 true, %1353
  %1356 = and i1 %1354, %1355
  %1357 = extractelement <8 x float> %1282, i32 0
  %1358 = select i1 %1356, float %1357, float 0.000000e+00
  %1359 = insertelement <8 x float> %1349, float %1358, i64 7
  %1360 = xor i1 %1356, true
  %1361 = and i1 %1354, %1360
  %1362 = insertelement <8 x i1> %1352, i1 %1361, i64 7
  %1363 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %1364 = bitcast <8 x i1> %62 to i8
  %1365 = call i8 @llvm.cttz.i8(i8 %1364, i1 false)
  %1366 = zext i8 %1365 to i32
  %1367 = select i1 %1363, i32 %1366, i32 0
  %1368 = extractelement <8 x float> %1359, i32 %1367
  %.spill.load243 = load float, ptr %.spill36, align 4
  %1369 = fadd float %.spill.load243, %1368
  store float %1369, ptr %.spill44, align 4
  store i64 0, ptr %.slot45, align 4
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state244 = load i64, ptr %.slot45, align 4
  %1370 = icmp slt i64 %.state244, 512
  br i1 %1370, label %direct.true245, label %direct.false246

direct.schedule.23:                               ; preds = %direct.true245
  %.state247 = load i64, ptr %.slot45, align 4
  %1371 = mul i64 %.state247, 8
  %.splatinsert248 = insertelement <8 x i64> poison, i64 %1371, i64 0
  %.splat249 = shufflevector <8 x i64> %.splatinsert248, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load250 = load <8 x i64>, ptr %.spill, align 64
  %1372 = add <8 x i64> %.splat249, %.spill.load250
  %.spill.load251 = load <8 x i64>, ptr %.spill17, align 64
  %1373 = add <8 x i64> %.spill.load251, zeroinitializer
  %1374 = add <8 x i64> zeroinitializer, %1373
  %1375 = add <8 x i64> zeroinitializer, %1372
  %1376 = mul <8 x i64> %1374, splat (i64 4096)
  %1377 = add <8 x i64> %1376, %1375
  %tile_snapshot.spill.load252 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %1378 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load252, 0
  %1379 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load252, 1
  %.state253 = load i64, ptr %.slot45, align 4
  %.splatinsert254 = insertelement <8 x i64> poison, i64 %.state253, i64 0
  %.splat255 = shufflevector <8 x i64> %.splatinsert254, <8 x i64> poison, <8 x i32> zeroinitializer
  %1380 = mul <8 x i64> %.splat255, splat (i64 32)
  %1381 = add <8 x i64> %1379, %1380
  %1382 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1378, 0
  %1383 = insertvalue { <8 x ptr>, <8 x i64> } %1382, <8 x i64> %1381, 1
  %1384 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1385 = extractvalue { <8 x ptr>, <8 x i64> } %1383, 1
  %1386 = extractelement <8 x ptr> %1384, i32 0
  %1387 = extractelement <8 x i64> %1385, i32 0
  %1388 = sub i64 %1387, 0
  %1389 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %1390 = select i1 %1389, i64 %1388, i64 0
  %private.contiguous.address256 = getelementptr i8, ptr %1386, i64 %1390
  %private.contiguous.load257 = load <8 x float>, ptr %private.contiguous.address256, align 4
  %1391 = select <8 x i1> %62, <8 x float> %private.contiguous.load257, <8 x float> zeroinitializer
  %.spill.load258 = load float, ptr %.spill44, align 4
  %.splatinsert259 = insertelement <8 x float> poison, float %.spill.load258, i64 0
  %.splat260 = shufflevector <8 x float> %.splatinsert259, <8 x float> poison, <8 x i32> zeroinitializer
  %1392 = fdiv <8 x float> %1391, %.splat260
  %1393 = extractvalue { ptr, i64 } %38, 0
  %1394 = extractelement <8 x i64> %1377, i32 0
  %1395 = sub i64 %1394, 0
  %1396 = mul i64 %1395, 4
  %buffer.contiguous.address261 = getelementptr i8, ptr %1393, i64 %1396
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1392, ptr %buffer.contiguous.address261, i32 1, <8 x i1> %62)
  %.state262 = load i64, ptr %.slot45, align 4
  %1397 = add i64 %.state262, 1
  store i64 %1397, ptr %.slot45, align 4
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false246
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true65:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false66:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true80:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false81:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true94:                                    ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false95:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true129:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false130:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true167:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false168:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true205:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false206:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true245:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false246:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8i8.v8p0(<8 x i8>, <8 x ptr>, i32 immarg, <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x i8>) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maxnum.f32(float, float) #0

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #4 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), i32 immarg, <8 x i1>) #5

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 16384
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 49152
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 512, i64 1024, i64 1536, i64 2048, i64 2560, i64 3072, i64 3584>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 53248
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 69632
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill17 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill17, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill18 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill18, align 64
  %.slot19 = alloca i64, align 8
  store i64 0, ptr %.slot19, align 4
  %.spill20 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill20, align 64
  %tile_snapshot.spill21 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill21, align 64
  %.slot22 = alloca i64, align 8
  store i64 0, ptr %.slot22, align 4
  %.spill23 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill23, align 4
  %tile_snapshot.spill24 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill24, align 64
  %.slot25 = alloca i64, align 8
  store i64 0, ptr %.slot25, align 4
  %.spill26 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill26, align 4
  %.slot27 = alloca i64, align 8
  store i64 0, ptr %.slot27, align 4
  %.slot28 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot28, align 32
  %.slot29 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot29, align 32
  %.slot30 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot30, align 32
  %.slot31 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot31, align 32
  %.spill32 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill32, align 32
  %.spill33 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill33, align 32
  %.spill34 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill34, align 32
  %.spill35 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill35, align 4
  %.spill36 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill36, align 4
  %tile_snapshot.spill37 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill37, align 64
  %.slot38 = alloca i64, align 8
  store i64 0, ptr %.slot38, align 4
  %.slot39 = alloca i64, align 8
  store i64 0, ptr %.slot39, align 4
  %.slot40 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot40, align 32
  %.slot41 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot41, align 32
  %.slot42 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot42, align 32
  %.slot43 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot43, align 32
  %.spill44 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill44, align 4
  %.slot45 = alloca i64, align 8
  store i64 0, ptr %.slot45, align 4
  %15 = getelementptr i8, ptr %argument_buffer, i64 0
  %16 = load ptr, ptr %15, align 16
  %17 = getelementptr i8, ptr %15, i64 8
  %18 = load i64, ptr %17, align 8
  %19 = insertvalue { ptr, i64 } poison, ptr %16, 0
  %20 = insertvalue { ptr, i64 } %19, i64 %18, 1
  %21 = getelementptr i8, ptr %argument_buffer, i64 16
  %22 = load ptr, ptr %21, align 16
  %23 = getelementptr i8, ptr %21, i64 8
  %24 = load i64, ptr %23, align 8
  %25 = insertvalue { ptr, i64 } poison, ptr %22, 0
  %26 = insertvalue { ptr, i64 } %25, i64 %24, 1
  %27 = getelementptr i8, ptr %argument_buffer, i64 32
  %28 = load ptr, ptr %27, align 16
  %29 = getelementptr i8, ptr %27, i64 8
  %30 = load i64, ptr %29, align 8
  %31 = insertvalue { ptr, i64 } poison, ptr %28, 0
  %32 = insertvalue { ptr, i64 } %31, i64 %30, 1
  %33 = getelementptr i8, ptr %argument_buffer, i64 48
  %34 = load ptr, ptr %33, align 16
  %35 = getelementptr i8, ptr %33, i64 8
  %36 = load i64, ptr %35, align 8
  %37 = insertvalue { ptr, i64 } poison, ptr %34, 0
  %38 = insertvalue { ptr, i64 } %37, i64 %36, 1
  %39 = load i32, ptr %launch_config, align 4
  %40 = getelementptr i8, ptr %launch_config, i64 12
  %41 = load i32, ptr %40, align 4
  %42 = getelementptr i8, ptr %launch_config, i64 4
  %43 = load i32, ptr %42, align 4
  %44 = getelementptr i8, ptr %launch_config, i64 16
  %45 = load i32, ptr %44, align 4
  %46 = getelementptr i8, ptr %launch_config, i64 8
  %47 = load i32, ptr %46, align 4
  %48 = getelementptr i8, ptr %launch_config, i64 20
  %49 = load i32, ptr %48, align 4
  %50 = getelementptr i8, ptr %launch_config, i64 36
  %51 = load i32, ptr %50, align 4
  %.splatinsert46 = insertelement <8 x i32> poison, i32 %51, i64 0
  %.splat47 = shufflevector <8 x i32> %.splatinsert46, <8 x i32> poison, <8 x i32> zeroinitializer
  %52 = add <8 x i32> %.splat47, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %53 = mul i32 %39, 32
  %.splatinsert48 = insertelement <8 x i32> poison, i32 %53, i64 0
  %.splat49 = shufflevector <8 x i32> %.splatinsert48, <8 x i32> poison, <8 x i32> zeroinitializer
  %54 = add <8 x i32> %.splat49, %52
  %55 = mul i32 %43, 1
  %.splatinsert50 = insertelement <8 x i32> poison, i32 %55, i64 0
  %.splat51 = shufflevector <8 x i32> %.splatinsert50, <8 x i32> poison, <8 x i32> zeroinitializer
  %56 = add <8 x i32> %.splat51, zeroinitializer
  %57 = mul i32 %47, 1
  %.splatinsert52 = insertelement <8 x i32> poison, i32 %57, i64 0
  %.splat53 = shufflevector <8 x i32> %.splatinsert52, <8 x i32> poison, <8 x i32> zeroinitializer
  %58 = add <8 x i32> %.splat53, zeroinitializer
  %59 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %54, 0
  %60 = insertvalue [3 x <8 x i32>] %59, <8 x i32> %56, 1
  %61 = insertvalue [3 x <8 x i32>] %60, <8 x i32> %58, 2
  %.splatinsert54 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat55 = shufflevector <8 x i32> %.splatinsert54, <8 x i32> poison, <8 x i32> zeroinitializer
  %62 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat55
  %63 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  br i1 %63, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %64 = extractvalue [3 x <8 x i32>] %61, 0
  %65 = load <8 x i64>, ptr %.spill, align 64
  %66 = select <8 x i1> %62, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %65
  store <8 x i64> %66, ptr %.spill, align 64
  %67 = sub <8 x i32> %64, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %68 = select <8 x i1> %62, <8 x i32> %67, <8 x i32> zeroinitializer
  %69 = select <8 x i1> %62, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %70 = lshr <8 x i32> %68, %69
  %71 = zext <8 x i32> %70 to <8 x i64>
  %72 = select <8 x i1> %62, <8 x i64> %71, <8 x i64> zeroinitializer
  %73 = select <8 x i1> %62, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %74 = sdiv <8 x i64> %72, %73
  %75 = load <8 x i64>, ptr %.spill17, align 64
  %76 = select <8 x i1> %62, <8 x i64> %74, <8 x i64> %75
  store <8 x i64> %76, ptr %.spill17, align 64
  %77 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %78 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %79 = extractvalue { <8 x ptr>, <8 x i64> } %77, 0
  %80 = select <8 x i1> %62, <8 x ptr> %78, <8 x ptr> %79
  %81 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %82 = extractvalue { <8 x ptr>, <8 x i64> } %77, 1
  %83 = select <8 x i1> %62, <8 x i64> %81, <8 x i64> %82
  %84 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %80, 0
  %85 = insertvalue { <8 x ptr>, <8 x i64> } %84, <8 x i64> %83, 1
  store { <8 x ptr>, <8 x i64> } %85, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %86 = icmp slt i64 %.state, 512
  br i1 %86, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state56 = load i64, ptr %.slot, align 4
  %87 = mul i64 %.state56, 8
  %.splatinsert57 = insertelement <8 x i64> poison, i64 %87, i64 0
  %.splat58 = shufflevector <8 x i64> %.splatinsert57, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %88 = add <8 x i64> %.splat58, %.spill.load
  %.spill.load59 = load <8 x i64>, ptr %.spill17, align 64
  %89 = add <8 x i64> %.spill.load59, zeroinitializer
  %90 = add <8 x i64> zeroinitializer, %89
  %91 = add <8 x i64> zeroinitializer, %88
  %92 = mul <8 x i64> %90, splat (i64 4096)
  %93 = add <8 x i64> %92, %91
  %94 = extractvalue { ptr, i64 } %20, 0
  %95 = extractelement <8 x i64> %93, i32 0
  %96 = sub i64 %95, 0
  %97 = mul i64 %96, 4
  %buffer.contiguous.address = getelementptr i8, ptr %94, i64 %97
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %62, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %99 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state60 = load i64, ptr %.slot, align 4
  %.splatinsert61 = insertelement <8 x i64> poison, i64 %.state60, i64 0
  %.splat62 = shufflevector <8 x i64> %.splatinsert61, <8 x i64> poison, <8 x i32> zeroinitializer
  %100 = mul <8 x i64> %.splat62, splat (i64 32)
  %101 = add <8 x i64> %99, %100
  %102 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %98, 0
  %103 = insertvalue { <8 x ptr>, <8 x i64> } %102, <8 x i64> %101, 1
  %104 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %105 = extractvalue { <8 x ptr>, <8 x i64> } %103, 1
  %106 = extractelement <8 x ptr> %104, i32 0
  %107 = extractelement <8 x i64> %105, i32 0
  %108 = sub i64 %107, 0
  %109 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %110 = select i1 %109, i64 %108, i64 0
  %private.contiguous.address = getelementptr i8, ptr %106, i64 %110
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %111 = select <8 x i1> %62, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %111, ptr %private.contiguous.address, align 4
  %.state63 = load i64, ptr %.slot, align 4
  %112 = add i64 %.state63, 1
  store i64 %112, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %113 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %114 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %113, 0
  %116 = select <8 x i1> %62, <8 x ptr> %114, <8 x ptr> %115
  %117 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %118 = extractvalue { <8 x ptr>, <8 x i64> } %113, 1
  %119 = select <8 x i1> %62, <8 x i64> %117, <8 x i64> %118
  %120 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %116, 0
  %121 = insertvalue { <8 x ptr>, <8 x i64> } %120, <8 x i64> %119, 1
  store { <8 x ptr>, <8 x i64> } %121, ptr %tile_snapshot.spill18, align 64
  store i64 0, ptr %.slot19, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state64 = load i64, ptr %.slot19, align 4
  %122 = icmp slt i64 %.state64, 512
  br i1 %122, label %direct.true65, label %direct.false66

direct.schedule.5:                                ; preds = %direct.true65
  %.state67 = load i64, ptr %.slot19, align 4
  %123 = mul i64 %.state67, 8
  %.splatinsert68 = insertelement <8 x i64> poison, i64 %123, i64 0
  %.splat69 = shufflevector <8 x i64> %.splatinsert68, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load70 = load <8 x i64>, ptr %.spill, align 64
  %124 = add <8 x i64> %.splat69, %.spill.load70
  %tile_snapshot.spill.load71 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load71, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load71, 1
  %.state72 = load i64, ptr %.slot19, align 4
  %.splatinsert73 = insertelement <8 x i64> poison, i64 %.state72, i64 0
  %.splat74 = shufflevector <8 x i64> %.splatinsert73, <8 x i64> poison, <8 x i32> zeroinitializer
  %127 = mul <8 x i64> %.splat74, splat (i64 64)
  %128 = add <8 x i64> %126, %127
  %129 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %125, 0
  %130 = insertvalue { <8 x ptr>, <8 x i64> } %129, <8 x i64> %128, 1
  %131 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %132 = extractvalue { <8 x ptr>, <8 x i64> } %130, 1
  %133 = extractelement <8 x ptr> %131, i32 0
  %134 = extractelement <8 x i64> %132, i32 0
  %135 = sub i64 %134, 0
  %136 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %137 = select i1 %136, i64 %135, i64 0
  %private.contiguous.address75 = getelementptr i8, ptr %133, i64 %137
  %private.contiguous.preserve76 = load <8 x i64>, ptr %private.contiguous.address75, align 8
  %138 = select <8 x i1> %62, <8 x i64> %124, <8 x i64> %private.contiguous.preserve76
  store <8 x i64> %138, ptr %private.contiguous.address75, align 8
  %.state77 = load i64, ptr %.slot19, align 4
  %139 = add i64 %.state77, 1
  store i64 %139, ptr %.slot19, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false66
  %.spill.load78 = load <8 x i64>, ptr %.spill17, align 64
  %140 = select <8 x i1> %62, <8 x i64> %.spill.load78, <8 x i64> zeroinitializer
  %141 = select <8 x i1> %62, <8 x i64> splat (i64 4096), <8 x i64> splat (i64 1)
  %142 = srem <8 x i64> %140, %141
  %143 = load <8 x i64>, ptr %.spill20, align 64
  %144 = select <8 x i1> %62, <8 x i64> %142, <8 x i64> %143
  store <8 x i64> %144, ptr %.spill20, align 64
  %145 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %145, 0
  %148 = select <8 x i1> %62, <8 x ptr> %146, <8 x ptr> %147
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %145, 1
  %151 = select <8 x i1> %62, <8 x i64> %149, <8 x i64> %150
  %152 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %148, 0
  %153 = insertvalue { <8 x ptr>, <8 x i64> } %152, <8 x i64> %151, 1
  store { <8 x ptr>, <8 x i64> } %153, ptr %tile_snapshot.spill21, align 64
  store i64 0, ptr %.slot22, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state79 = load i64, ptr %.slot22, align 4
  %154 = icmp slt i64 %.state79, 512
  br i1 %154, label %direct.true80, label %direct.false81

direct.schedule.8:                                ; preds = %direct.true80
  %tile_snapshot.spill.load82 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %155 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load82, 0
  %156 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load82, 1
  %.state83 = load i64, ptr %.slot22, align 4
  %.splatinsert84 = insertelement <8 x i64> poison, i64 %.state83, i64 0
  %.splat85 = shufflevector <8 x i64> %.splatinsert84, <8 x i64> poison, <8 x i32> zeroinitializer
  %157 = mul <8 x i64> %.splat85, splat (i64 64)
  %158 = add <8 x i64> %156, %157
  %159 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %155, 0
  %160 = insertvalue { <8 x ptr>, <8 x i64> } %159, <8 x i64> %158, 1
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %160, 1
  %163 = extractelement <8 x ptr> %161, i32 0
  %164 = extractelement <8 x i64> %162, i32 0
  %165 = sub i64 %164, 0
  %166 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %167 = select i1 %166, i64 %165, i64 0
  %private.contiguous.address86 = getelementptr i8, ptr %163, i64 %167
  %private.contiguous.load = load <8 x i64>, ptr %private.contiguous.address86, align 8
  %168 = select <8 x i1> %62, <8 x i64> %private.contiguous.load, <8 x i64> zeroinitializer
  %.spill.load87 = load <8 x i64>, ptr %.spill20, align 64
  %169 = icmp sle <8 x i64> %168, %.spill.load87
  %tile_snapshot.spill.load88 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load88, 0
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load88, 1
  %.state89 = load i64, ptr %.slot22, align 4
  %.splatinsert90 = insertelement <8 x i64> poison, i64 %.state89, i64 0
  %.splat91 = shufflevector <8 x i64> %.splatinsert90, <8 x i64> poison, <8 x i32> zeroinitializer
  %172 = add <8 x i64> %171, %.splat91
  %173 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %170, 0
  %174 = insertvalue { <8 x ptr>, <8 x i64> } %173, <8 x i64> %172, 1
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %174, 0
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %174, 1
  %177 = getelementptr i8, <8 x ptr> %175, <8 x i64> %176
  %178 = zext <8 x i1> %169 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %178, <8 x ptr> %177, i32 1, <8 x i1> %62)
  %.state92 = load i64, ptr %.slot22, align 4
  %179 = add i64 %.state92, 1
  store i64 %179, ptr %.slot22, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false81
  store float 0xC6293E5940000000, ptr %.spill23, align 4
  %180 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill24, align 64
  %181 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %182 = extractvalue { <8 x ptr>, <8 x i64> } %180, 0
  %183 = select <8 x i1> %62, <8 x ptr> %181, <8 x ptr> %182
  %184 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %185 = extractvalue { <8 x ptr>, <8 x i64> } %180, 1
  %186 = select <8 x i1> %62, <8 x i64> %184, <8 x i64> %185
  %187 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %183, 0
  %188 = insertvalue { <8 x ptr>, <8 x i64> } %187, <8 x i64> %186, 1
  store { <8 x ptr>, <8 x i64> } %188, ptr %tile_snapshot.spill24, align 64
  store i64 0, ptr %.slot25, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state93 = load i64, ptr %.slot25, align 4
  %189 = icmp slt i64 %.state93, 512
  br i1 %189, label %direct.true94, label %direct.false95

direct.schedule.11:                               ; preds = %direct.true94
  %tile_snapshot.spill.load96 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %190 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load96, 0
  %191 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load96, 1
  %.state97 = load i64, ptr %.slot25, align 4
  %.splatinsert98 = insertelement <8 x i64> poison, i64 %.state97, i64 0
  %.splat99 = shufflevector <8 x i64> %.splatinsert98, <8 x i64> poison, <8 x i32> zeroinitializer
  %192 = add <8 x i64> %191, %.splat99
  %193 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %190, 0
  %194 = insertvalue { <8 x ptr>, <8 x i64> } %193, <8 x i64> %192, 1
  %195 = extractvalue { <8 x ptr>, <8 x i64> } %194, 0
  %196 = extractvalue { <8 x ptr>, <8 x i64> } %194, 1
  %197 = getelementptr i8, <8 x ptr> %195, <8 x i64> %196
  %198 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %197, i32 1, <8 x i1> %62, <8 x i8> zeroinitializer)
  %199 = icmp ne <8 x i8> %198, zeroinitializer
  %tile_snapshot.spill.load100 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %200 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load100, 0
  %201 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load100, 1
  %.state101 = load i64, ptr %.slot25, align 4
  %.splatinsert102 = insertelement <8 x i64> poison, i64 %.state101, i64 0
  %.splat103 = shufflevector <8 x i64> %.splatinsert102, <8 x i64> poison, <8 x i32> zeroinitializer
  %202 = mul <8 x i64> %.splat103, splat (i64 32)
  %203 = add <8 x i64> %201, %202
  %204 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %200, 0
  %205 = insertvalue { <8 x ptr>, <8 x i64> } %204, <8 x i64> %203, 1
  %206 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %207 = extractvalue { <8 x ptr>, <8 x i64> } %205, 1
  %208 = extractelement <8 x ptr> %206, i32 0
  %209 = extractelement <8 x i64> %207, i32 0
  %210 = sub i64 %209, 0
  %211 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %212 = select i1 %211, i64 %210, i64 0
  %private.contiguous.address104 = getelementptr i8, ptr %208, i64 %212
  %private.contiguous.load105 = load <8 x float>, ptr %private.contiguous.address104, align 4
  %213 = select <8 x i1> %62, <8 x float> %private.contiguous.load105, <8 x float> zeroinitializer
  %.spill.load106 = load float, ptr %.spill23, align 4
  %.splatinsert107 = insertelement <8 x float> poison, float %.spill.load106, i64 0
  %.splat108 = shufflevector <8 x float> %.splatinsert107, <8 x float> poison, <8 x i32> zeroinitializer
  %214 = select <8 x i1> %199, <8 x float> %213, <8 x float> %.splat108
  %tile_snapshot.spill.load109 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill24, align 64
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load109, 0
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load109, 1
  %.state110 = load i64, ptr %.slot25, align 4
  %.splatinsert111 = insertelement <8 x i64> poison, i64 %.state110, i64 0
  %.splat112 = shufflevector <8 x i64> %.splatinsert111, <8 x i64> poison, <8 x i32> zeroinitializer
  %217 = mul <8 x i64> %.splat112, splat (i64 32)
  %218 = add <8 x i64> %216, %217
  %219 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %215, 0
  %220 = insertvalue { <8 x ptr>, <8 x i64> } %219, <8 x i64> %218, 1
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %220, 1
  %223 = extractelement <8 x ptr> %221, i32 0
  %224 = extractelement <8 x i64> %222, i32 0
  %225 = sub i64 %224, 0
  %226 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %227 = select i1 %226, i64 %225, i64 0
  %private.contiguous.address113 = getelementptr i8, ptr %223, i64 %227
  %private.contiguous.preserve114 = load <8 x float>, ptr %private.contiguous.address113, align 4
  %228 = select <8 x i1> %62, <8 x float> %214, <8 x float> %private.contiguous.preserve114
  store <8 x float> %228, ptr %private.contiguous.address113, align 4
  %.state115 = load i64, ptr %.slot25, align 4
  %229 = add i64 %.state115, 1
  store i64 %229, ptr %.slot25, align 4
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false95
  store float 0xFFF0000000000000, ptr %.spill26, align 4
  %tile_snapshot.spill.load116 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill24, align 64
  %230 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load116, 0
  %231 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load116, 1
  %232 = add <8 x i64> %231, zeroinitializer
  %233 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %230, 0
  %234 = insertvalue { <8 x ptr>, <8 x i64> } %233, <8 x i64> %232, 1
  %235 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %236 = extractvalue { <8 x ptr>, <8 x i64> } %234, 1
  %237 = extractelement <8 x ptr> %235, i32 0
  %238 = extractelement <8 x i64> %236, i32 0
  %239 = sub i64 %238, 0
  %240 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %241 = select i1 %240, i64 %239, i64 0
  %private.contiguous.address117 = getelementptr i8, ptr %237, i64 %241
  %private.contiguous.load118 = load <8 x float>, ptr %private.contiguous.address117, align 4
  %242 = select <8 x i1> %62, <8 x float> %private.contiguous.load118, <8 x float> zeroinitializer
  %tile_snapshot.spill.load119 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill24, align 64
  %243 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load119, 0
  %244 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load119, 1
  %245 = add <8 x i64> %244, splat (i64 32)
  %246 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %243, 0
  %247 = insertvalue { <8 x ptr>, <8 x i64> } %246, <8 x i64> %245, 1
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %247, 1
  %250 = extractelement <8 x ptr> %248, i32 0
  %251 = extractelement <8 x i64> %249, i32 0
  %252 = sub i64 %251, 0
  %253 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %254 = select i1 %253, i64 %252, i64 0
  %private.contiguous.address120 = getelementptr i8, ptr %250, i64 %254
  %private.contiguous.load121 = load <8 x float>, ptr %private.contiguous.address120, align 4
  %255 = select <8 x i1> %62, <8 x float> %private.contiguous.load121, <8 x float> zeroinitializer
  %tile_snapshot.spill.load122 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill24, align 64
  %256 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 0
  %257 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 1
  %258 = add <8 x i64> %257, splat (i64 64)
  %259 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %256, 0
  %260 = insertvalue { <8 x ptr>, <8 x i64> } %259, <8 x i64> %258, 1
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %260, 1
  %263 = extractelement <8 x ptr> %261, i32 0
  %264 = extractelement <8 x i64> %262, i32 0
  %265 = sub i64 %264, 0
  %266 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %267 = select i1 %266, i64 %265, i64 0
  %private.contiguous.address123 = getelementptr i8, ptr %263, i64 %267
  %private.contiguous.load124 = load <8 x float>, ptr %private.contiguous.address123, align 4
  %268 = select <8 x i1> %62, <8 x float> %private.contiguous.load124, <8 x float> zeroinitializer
  %tile_snapshot.spill.load125 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill24, align 64
  %269 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load125, 0
  %270 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load125, 1
  %271 = add <8 x i64> %270, splat (i64 96)
  %272 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %269, 0
  %273 = insertvalue { <8 x ptr>, <8 x i64> } %272, <8 x i64> %271, 1
  %274 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %275 = extractvalue { <8 x ptr>, <8 x i64> } %273, 1
  %276 = extractelement <8 x ptr> %274, i32 0
  %277 = extractelement <8 x i64> %275, i32 0
  %278 = sub i64 %277, 0
  %279 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %280 = select i1 %279, i64 %278, i64 0
  %private.contiguous.address126 = getelementptr i8, ptr %276, i64 %280
  %private.contiguous.load127 = load <8 x float>, ptr %private.contiguous.address126, align 4
  %281 = select <8 x i1> %62, <8 x float> %private.contiguous.load127, <8 x float> zeroinitializer
  store i64 4, ptr %.slot27, align 4
  %282 = load <8 x float>, ptr %.slot28, align 32
  %283 = select <8 x i1> %62, <8 x float> %242, <8 x float> %282
  store <8 x float> %283, ptr %.slot28, align 32
  %284 = load <8 x float>, ptr %.slot29, align 32
  %285 = select <8 x i1> %62, <8 x float> %255, <8 x float> %284
  store <8 x float> %285, ptr %.slot29, align 32
  %286 = load <8 x float>, ptr %.slot30, align 32
  %287 = select <8 x i1> %62, <8 x float> %268, <8 x float> %286
  store <8 x float> %287, ptr %.slot30, align 32
  %288 = load <8 x float>, ptr %.slot31, align 32
  %289 = select <8 x i1> %62, <8 x float> %281, <8 x float> %288
  store <8 x float> %289, ptr %.slot31, align 32
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state128 = load i64, ptr %.slot27, align 4
  %290 = icmp slt i64 %.state128, 512
  br i1 %290, label %direct.true129, label %direct.false130

direct.schedule.14:                               ; preds = %direct.true129
  %.state131 = load i64, ptr %.slot27, align 4
  %291 = add i64 %.state131, 0
  %tile_snapshot.spill.load132 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill24, align 64
  %292 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load132, 0
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load132, 1
  %.splatinsert133 = insertelement <8 x i64> poison, i64 %291, i64 0
  %.splat134 = shufflevector <8 x i64> %.splatinsert133, <8 x i64> poison, <8 x i32> zeroinitializer
  %294 = mul <8 x i64> %.splat134, splat (i64 32)
  %295 = add <8 x i64> %293, %294
  %296 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %292, 0
  %297 = insertvalue { <8 x ptr>, <8 x i64> } %296, <8 x i64> %295, 1
  %298 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %299 = extractvalue { <8 x ptr>, <8 x i64> } %297, 1
  %300 = extractelement <8 x ptr> %298, i32 0
  %301 = extractelement <8 x i64> %299, i32 0
  %302 = sub i64 %301, 0
  %303 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %304 = select i1 %303, i64 %302, i64 0
  %private.contiguous.address135 = getelementptr i8, ptr %300, i64 %304
  %private.contiguous.load136 = load <8 x float>, ptr %private.contiguous.address135, align 4
  %305 = select <8 x i1> %62, <8 x float> %private.contiguous.load136, <8 x float> zeroinitializer
  %.state137 = load <8 x float>, ptr %.slot28, align 32
  %306 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state137, <8 x float> %305)
  %.state138 = load i64, ptr %.slot27, align 4
  %307 = add i64 %.state138, 1
  %tile_snapshot.spill.load139 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill24, align 64
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load139, 0
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load139, 1
  %.splatinsert140 = insertelement <8 x i64> poison, i64 %307, i64 0
  %.splat141 = shufflevector <8 x i64> %.splatinsert140, <8 x i64> poison, <8 x i32> zeroinitializer
  %310 = mul <8 x i64> %.splat141, splat (i64 32)
  %311 = add <8 x i64> %309, %310
  %312 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %308, 0
  %313 = insertvalue { <8 x ptr>, <8 x i64> } %312, <8 x i64> %311, 1
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %313, 1
  %316 = extractelement <8 x ptr> %314, i32 0
  %317 = extractelement <8 x i64> %315, i32 0
  %318 = sub i64 %317, 0
  %319 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %320 = select i1 %319, i64 %318, i64 0
  %private.contiguous.address142 = getelementptr i8, ptr %316, i64 %320
  %private.contiguous.load143 = load <8 x float>, ptr %private.contiguous.address142, align 4
  %321 = select <8 x i1> %62, <8 x float> %private.contiguous.load143, <8 x float> zeroinitializer
  %.state144 = load <8 x float>, ptr %.slot29, align 32
  %322 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state144, <8 x float> %321)
  %.state145 = load i64, ptr %.slot27, align 4
  %323 = add i64 %.state145, 2
  %tile_snapshot.spill.load146 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill24, align 64
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load146, 0
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load146, 1
  %.splatinsert147 = insertelement <8 x i64> poison, i64 %323, i64 0
  %.splat148 = shufflevector <8 x i64> %.splatinsert147, <8 x i64> poison, <8 x i32> zeroinitializer
  %326 = mul <8 x i64> %.splat148, splat (i64 32)
  %327 = add <8 x i64> %325, %326
  %328 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %324, 0
  %329 = insertvalue { <8 x ptr>, <8 x i64> } %328, <8 x i64> %327, 1
  %330 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %331 = extractvalue { <8 x ptr>, <8 x i64> } %329, 1
  %332 = extractelement <8 x ptr> %330, i32 0
  %333 = extractelement <8 x i64> %331, i32 0
  %334 = sub i64 %333, 0
  %335 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %336 = select i1 %335, i64 %334, i64 0
  %private.contiguous.address149 = getelementptr i8, ptr %332, i64 %336
  %private.contiguous.load150 = load <8 x float>, ptr %private.contiguous.address149, align 4
  %337 = select <8 x i1> %62, <8 x float> %private.contiguous.load150, <8 x float> zeroinitializer
  %.state151 = load <8 x float>, ptr %.slot30, align 32
  %338 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state151, <8 x float> %337)
  %.state152 = load i64, ptr %.slot27, align 4
  %339 = add i64 %.state152, 3
  %tile_snapshot.spill.load153 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill24, align 64
  %340 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load153, 0
  %341 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load153, 1
  %.splatinsert154 = insertelement <8 x i64> poison, i64 %339, i64 0
  %.splat155 = shufflevector <8 x i64> %.splatinsert154, <8 x i64> poison, <8 x i32> zeroinitializer
  %342 = mul <8 x i64> %.splat155, splat (i64 32)
  %343 = add <8 x i64> %341, %342
  %344 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %340, 0
  %345 = insertvalue { <8 x ptr>, <8 x i64> } %344, <8 x i64> %343, 1
  %346 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %347 = extractvalue { <8 x ptr>, <8 x i64> } %345, 1
  %348 = extractelement <8 x ptr> %346, i32 0
  %349 = extractelement <8 x i64> %347, i32 0
  %350 = sub i64 %349, 0
  %351 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %352 = select i1 %351, i64 %350, i64 0
  %private.contiguous.address156 = getelementptr i8, ptr %348, i64 %352
  %private.contiguous.load157 = load <8 x float>, ptr %private.contiguous.address156, align 4
  %353 = select <8 x i1> %62, <8 x float> %private.contiguous.load157, <8 x float> zeroinitializer
  %.state158 = load <8 x float>, ptr %.slot31, align 32
  %354 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state158, <8 x float> %353)
  %.state159 = load i64, ptr %.slot27, align 4
  %355 = add i64 %.state159, 4
  store i64 %355, ptr %.slot27, align 4
  %356 = load <8 x float>, ptr %.slot28, align 32
  %357 = select <8 x i1> %62, <8 x float> %306, <8 x float> %356
  store <8 x float> %357, ptr %.slot28, align 32
  %358 = load <8 x float>, ptr %.slot29, align 32
  %359 = select <8 x i1> %62, <8 x float> %322, <8 x float> %358
  store <8 x float> %359, ptr %.slot29, align 32
  %360 = load <8 x float>, ptr %.slot30, align 32
  %361 = select <8 x i1> %62, <8 x float> %338, <8 x float> %360
  store <8 x float> %361, ptr %.slot30, align 32
  %362 = load <8 x float>, ptr %.slot31, align 32
  %363 = select <8 x i1> %62, <8 x float> %354, <8 x float> %362
  store <8 x float> %363, ptr %.slot31, align 32
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false130
  %.state160 = load <8 x float>, ptr %.slot28, align 32
  %.state161 = load <8 x float>, ptr %.slot29, align 32
  %364 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state160, <8 x float> %.state161)
  %.state162 = load <8 x float>, ptr %.slot30, align 32
  %365 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %364, <8 x float> %.state162)
  %.state163 = load <8 x float>, ptr %.slot31, align 32
  %366 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %365, <8 x float> %.state163)
  %.spill.load164 = load <8 x i64>, ptr %.spill, align 64
  %367 = trunc <8 x i64> %.spill.load164 to <8 x i32>
  %368 = xor <8 x i32> %367, splat (i32 1)
  %369 = load <8 x i32>, ptr %.spill32, align 32
  %370 = select <8 x i1> %62, <8 x i32> %368, <8 x i32> %369
  store <8 x i32> %370, ptr %.spill32, align 32
  %371 = extractelement <8 x i32> %368, i64 0
  %372 = icmp ult i32 %371, 8
  %373 = select i1 %372, i32 %371, i32 0
  %374 = extractelement <8 x i1> %62, i32 %373
  %375 = extractelement <8 x i1> %62, i64 0
  %376 = and i1 %372, %374
  %377 = and i1 %375, %376
  %378 = extractelement <8 x float> %366, i32 %373
  %379 = select i1 %377, float %378, float 0.000000e+00
  %380 = insertelement <8 x float> poison, float %379, i64 0
  %381 = xor i1 %377, true
  %382 = and i1 %375, %381
  %383 = insertelement <8 x i1> poison, i1 %382, i64 0
  %384 = extractelement <8 x i32> %368, i64 1
  %385 = icmp ult i32 %384, 8
  %386 = select i1 %385, i32 %384, i32 0
  %387 = extractelement <8 x i1> %62, i32 %386
  %388 = extractelement <8 x i1> %62, i64 1
  %389 = and i1 %385, %387
  %390 = and i1 %388, %389
  %391 = extractelement <8 x float> %366, i32 %386
  %392 = select i1 %390, float %391, float 0.000000e+00
  %393 = insertelement <8 x float> %380, float %392, i64 1
  %394 = xor i1 %390, true
  %395 = and i1 %388, %394
  %396 = insertelement <8 x i1> %383, i1 %395, i64 1
  %397 = extractelement <8 x i32> %368, i64 2
  %398 = icmp ult i32 %397, 8
  %399 = select i1 %398, i32 %397, i32 0
  %400 = extractelement <8 x i1> %62, i32 %399
  %401 = extractelement <8 x i1> %62, i64 2
  %402 = and i1 %398, %400
  %403 = and i1 %401, %402
  %404 = extractelement <8 x float> %366, i32 %399
  %405 = select i1 %403, float %404, float 0.000000e+00
  %406 = insertelement <8 x float> %393, float %405, i64 2
  %407 = xor i1 %403, true
  %408 = and i1 %401, %407
  %409 = insertelement <8 x i1> %396, i1 %408, i64 2
  %410 = extractelement <8 x i32> %368, i64 3
  %411 = icmp ult i32 %410, 8
  %412 = select i1 %411, i32 %410, i32 0
  %413 = extractelement <8 x i1> %62, i32 %412
  %414 = extractelement <8 x i1> %62, i64 3
  %415 = and i1 %411, %413
  %416 = and i1 %414, %415
  %417 = extractelement <8 x float> %366, i32 %412
  %418 = select i1 %416, float %417, float 0.000000e+00
  %419 = insertelement <8 x float> %406, float %418, i64 3
  %420 = xor i1 %416, true
  %421 = and i1 %414, %420
  %422 = insertelement <8 x i1> %409, i1 %421, i64 3
  %423 = extractelement <8 x i32> %368, i64 4
  %424 = icmp ult i32 %423, 8
  %425 = select i1 %424, i32 %423, i32 0
  %426 = extractelement <8 x i1> %62, i32 %425
  %427 = extractelement <8 x i1> %62, i64 4
  %428 = and i1 %424, %426
  %429 = and i1 %427, %428
  %430 = extractelement <8 x float> %366, i32 %425
  %431 = select i1 %429, float %430, float 0.000000e+00
  %432 = insertelement <8 x float> %419, float %431, i64 4
  %433 = xor i1 %429, true
  %434 = and i1 %427, %433
  %435 = insertelement <8 x i1> %422, i1 %434, i64 4
  %436 = extractelement <8 x i32> %368, i64 5
  %437 = icmp ult i32 %436, 8
  %438 = select i1 %437, i32 %436, i32 0
  %439 = extractelement <8 x i1> %62, i32 %438
  %440 = extractelement <8 x i1> %62, i64 5
  %441 = and i1 %437, %439
  %442 = and i1 %440, %441
  %443 = extractelement <8 x float> %366, i32 %438
  %444 = select i1 %442, float %443, float 0.000000e+00
  %445 = insertelement <8 x float> %432, float %444, i64 5
  %446 = xor i1 %442, true
  %447 = and i1 %440, %446
  %448 = insertelement <8 x i1> %435, i1 %447, i64 5
  %449 = extractelement <8 x i32> %368, i64 6
  %450 = icmp ult i32 %449, 8
  %451 = select i1 %450, i32 %449, i32 0
  %452 = extractelement <8 x i1> %62, i32 %451
  %453 = extractelement <8 x i1> %62, i64 6
  %454 = and i1 %450, %452
  %455 = and i1 %453, %454
  %456 = extractelement <8 x float> %366, i32 %451
  %457 = select i1 %455, float %456, float 0.000000e+00
  %458 = insertelement <8 x float> %445, float %457, i64 6
  %459 = xor i1 %455, true
  %460 = and i1 %453, %459
  %461 = insertelement <8 x i1> %448, i1 %460, i64 6
  %462 = extractelement <8 x i32> %368, i64 7
  %463 = icmp ult i32 %462, 8
  %464 = select i1 %463, i32 %462, i32 0
  %465 = extractelement <8 x i1> %62, i32 %464
  %466 = extractelement <8 x i1> %62, i64 7
  %467 = and i1 %463, %465
  %468 = and i1 %466, %467
  %469 = extractelement <8 x float> %366, i32 %464
  %470 = select i1 %468, float %469, float 0.000000e+00
  %471 = insertelement <8 x float> %458, float %470, i64 7
  %472 = xor i1 %468, true
  %473 = and i1 %466, %472
  %474 = insertelement <8 x i1> %461, i1 %473, i64 7
  %475 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %366, <8 x float> %471)
  %476 = xor <8 x i32> %367, splat (i32 2)
  %477 = load <8 x i32>, ptr %.spill33, align 32
  %478 = select <8 x i1> %62, <8 x i32> %476, <8 x i32> %477
  store <8 x i32> %478, ptr %.spill33, align 32
  %479 = extractelement <8 x i32> %476, i64 0
  %480 = icmp ult i32 %479, 8
  %481 = select i1 %480, i32 %479, i32 0
  %482 = extractelement <8 x i1> %62, i32 %481
  %483 = extractelement <8 x i1> %62, i64 0
  %484 = and i1 %480, %482
  %485 = and i1 %483, %484
  %486 = extractelement <8 x float> %475, i32 %481
  %487 = select i1 %485, float %486, float 0.000000e+00
  %488 = insertelement <8 x float> poison, float %487, i64 0
  %489 = xor i1 %485, true
  %490 = and i1 %483, %489
  %491 = insertelement <8 x i1> poison, i1 %490, i64 0
  %492 = extractelement <8 x i32> %476, i64 1
  %493 = icmp ult i32 %492, 8
  %494 = select i1 %493, i32 %492, i32 0
  %495 = extractelement <8 x i1> %62, i32 %494
  %496 = extractelement <8 x i1> %62, i64 1
  %497 = and i1 %493, %495
  %498 = and i1 %496, %497
  %499 = extractelement <8 x float> %475, i32 %494
  %500 = select i1 %498, float %499, float 0.000000e+00
  %501 = insertelement <8 x float> %488, float %500, i64 1
  %502 = xor i1 %498, true
  %503 = and i1 %496, %502
  %504 = insertelement <8 x i1> %491, i1 %503, i64 1
  %505 = extractelement <8 x i32> %476, i64 2
  %506 = icmp ult i32 %505, 8
  %507 = select i1 %506, i32 %505, i32 0
  %508 = extractelement <8 x i1> %62, i32 %507
  %509 = extractelement <8 x i1> %62, i64 2
  %510 = and i1 %506, %508
  %511 = and i1 %509, %510
  %512 = extractelement <8 x float> %475, i32 %507
  %513 = select i1 %511, float %512, float 0.000000e+00
  %514 = insertelement <8 x float> %501, float %513, i64 2
  %515 = xor i1 %511, true
  %516 = and i1 %509, %515
  %517 = insertelement <8 x i1> %504, i1 %516, i64 2
  %518 = extractelement <8 x i32> %476, i64 3
  %519 = icmp ult i32 %518, 8
  %520 = select i1 %519, i32 %518, i32 0
  %521 = extractelement <8 x i1> %62, i32 %520
  %522 = extractelement <8 x i1> %62, i64 3
  %523 = and i1 %519, %521
  %524 = and i1 %522, %523
  %525 = extractelement <8 x float> %475, i32 %520
  %526 = select i1 %524, float %525, float 0.000000e+00
  %527 = insertelement <8 x float> %514, float %526, i64 3
  %528 = xor i1 %524, true
  %529 = and i1 %522, %528
  %530 = insertelement <8 x i1> %517, i1 %529, i64 3
  %531 = extractelement <8 x i32> %476, i64 4
  %532 = icmp ult i32 %531, 8
  %533 = select i1 %532, i32 %531, i32 0
  %534 = extractelement <8 x i1> %62, i32 %533
  %535 = extractelement <8 x i1> %62, i64 4
  %536 = and i1 %532, %534
  %537 = and i1 %535, %536
  %538 = extractelement <8 x float> %475, i32 %533
  %539 = select i1 %537, float %538, float 0.000000e+00
  %540 = insertelement <8 x float> %527, float %539, i64 4
  %541 = xor i1 %537, true
  %542 = and i1 %535, %541
  %543 = insertelement <8 x i1> %530, i1 %542, i64 4
  %544 = extractelement <8 x i32> %476, i64 5
  %545 = icmp ult i32 %544, 8
  %546 = select i1 %545, i32 %544, i32 0
  %547 = extractelement <8 x i1> %62, i32 %546
  %548 = extractelement <8 x i1> %62, i64 5
  %549 = and i1 %545, %547
  %550 = and i1 %548, %549
  %551 = extractelement <8 x float> %475, i32 %546
  %552 = select i1 %550, float %551, float 0.000000e+00
  %553 = insertelement <8 x float> %540, float %552, i64 5
  %554 = xor i1 %550, true
  %555 = and i1 %548, %554
  %556 = insertelement <8 x i1> %543, i1 %555, i64 5
  %557 = extractelement <8 x i32> %476, i64 6
  %558 = icmp ult i32 %557, 8
  %559 = select i1 %558, i32 %557, i32 0
  %560 = extractelement <8 x i1> %62, i32 %559
  %561 = extractelement <8 x i1> %62, i64 6
  %562 = and i1 %558, %560
  %563 = and i1 %561, %562
  %564 = extractelement <8 x float> %475, i32 %559
  %565 = select i1 %563, float %564, float 0.000000e+00
  %566 = insertelement <8 x float> %553, float %565, i64 6
  %567 = xor i1 %563, true
  %568 = and i1 %561, %567
  %569 = insertelement <8 x i1> %556, i1 %568, i64 6
  %570 = extractelement <8 x i32> %476, i64 7
  %571 = icmp ult i32 %570, 8
  %572 = select i1 %571, i32 %570, i32 0
  %573 = extractelement <8 x i1> %62, i32 %572
  %574 = extractelement <8 x i1> %62, i64 7
  %575 = and i1 %571, %573
  %576 = and i1 %574, %575
  %577 = extractelement <8 x float> %475, i32 %572
  %578 = select i1 %576, float %577, float 0.000000e+00
  %579 = insertelement <8 x float> %566, float %578, i64 7
  %580 = xor i1 %576, true
  %581 = and i1 %574, %580
  %582 = insertelement <8 x i1> %569, i1 %581, i64 7
  %583 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %475, <8 x float> %579)
  %584 = xor <8 x i32> %367, splat (i32 4)
  %585 = load <8 x i32>, ptr %.spill34, align 32
  %586 = select <8 x i1> %62, <8 x i32> %584, <8 x i32> %585
  store <8 x i32> %586, ptr %.spill34, align 32
  %587 = extractelement <8 x i32> %584, i64 0
  %588 = icmp ult i32 %587, 8
  %589 = select i1 %588, i32 %587, i32 0
  %590 = extractelement <8 x i1> %62, i32 %589
  %591 = extractelement <8 x i1> %62, i64 0
  %592 = and i1 %588, %590
  %593 = and i1 %591, %592
  %594 = extractelement <8 x float> %583, i32 %589
  %595 = select i1 %593, float %594, float 0.000000e+00
  %596 = insertelement <8 x float> poison, float %595, i64 0
  %597 = xor i1 %593, true
  %598 = and i1 %591, %597
  %599 = insertelement <8 x i1> poison, i1 %598, i64 0
  %600 = extractelement <8 x i32> %584, i64 1
  %601 = icmp ult i32 %600, 8
  %602 = select i1 %601, i32 %600, i32 0
  %603 = extractelement <8 x i1> %62, i32 %602
  %604 = extractelement <8 x i1> %62, i64 1
  %605 = and i1 %601, %603
  %606 = and i1 %604, %605
  %607 = extractelement <8 x float> %583, i32 %602
  %608 = select i1 %606, float %607, float 0.000000e+00
  %609 = insertelement <8 x float> %596, float %608, i64 1
  %610 = xor i1 %606, true
  %611 = and i1 %604, %610
  %612 = insertelement <8 x i1> %599, i1 %611, i64 1
  %613 = extractelement <8 x i32> %584, i64 2
  %614 = icmp ult i32 %613, 8
  %615 = select i1 %614, i32 %613, i32 0
  %616 = extractelement <8 x i1> %62, i32 %615
  %617 = extractelement <8 x i1> %62, i64 2
  %618 = and i1 %614, %616
  %619 = and i1 %617, %618
  %620 = extractelement <8 x float> %583, i32 %615
  %621 = select i1 %619, float %620, float 0.000000e+00
  %622 = insertelement <8 x float> %609, float %621, i64 2
  %623 = xor i1 %619, true
  %624 = and i1 %617, %623
  %625 = insertelement <8 x i1> %612, i1 %624, i64 2
  %626 = extractelement <8 x i32> %584, i64 3
  %627 = icmp ult i32 %626, 8
  %628 = select i1 %627, i32 %626, i32 0
  %629 = extractelement <8 x i1> %62, i32 %628
  %630 = extractelement <8 x i1> %62, i64 3
  %631 = and i1 %627, %629
  %632 = and i1 %630, %631
  %633 = extractelement <8 x float> %583, i32 %628
  %634 = select i1 %632, float %633, float 0.000000e+00
  %635 = insertelement <8 x float> %622, float %634, i64 3
  %636 = xor i1 %632, true
  %637 = and i1 %630, %636
  %638 = insertelement <8 x i1> %625, i1 %637, i64 3
  %639 = extractelement <8 x i32> %584, i64 4
  %640 = icmp ult i32 %639, 8
  %641 = select i1 %640, i32 %639, i32 0
  %642 = extractelement <8 x i1> %62, i32 %641
  %643 = extractelement <8 x i1> %62, i64 4
  %644 = and i1 %640, %642
  %645 = and i1 %643, %644
  %646 = extractelement <8 x float> %583, i32 %641
  %647 = select i1 %645, float %646, float 0.000000e+00
  %648 = insertelement <8 x float> %635, float %647, i64 4
  %649 = xor i1 %645, true
  %650 = and i1 %643, %649
  %651 = insertelement <8 x i1> %638, i1 %650, i64 4
  %652 = extractelement <8 x i32> %584, i64 5
  %653 = icmp ult i32 %652, 8
  %654 = select i1 %653, i32 %652, i32 0
  %655 = extractelement <8 x i1> %62, i32 %654
  %656 = extractelement <8 x i1> %62, i64 5
  %657 = and i1 %653, %655
  %658 = and i1 %656, %657
  %659 = extractelement <8 x float> %583, i32 %654
  %660 = select i1 %658, float %659, float 0.000000e+00
  %661 = insertelement <8 x float> %648, float %660, i64 5
  %662 = xor i1 %658, true
  %663 = and i1 %656, %662
  %664 = insertelement <8 x i1> %651, i1 %663, i64 5
  %665 = extractelement <8 x i32> %584, i64 6
  %666 = icmp ult i32 %665, 8
  %667 = select i1 %666, i32 %665, i32 0
  %668 = extractelement <8 x i1> %62, i32 %667
  %669 = extractelement <8 x i1> %62, i64 6
  %670 = and i1 %666, %668
  %671 = and i1 %669, %670
  %672 = extractelement <8 x float> %583, i32 %667
  %673 = select i1 %671, float %672, float 0.000000e+00
  %674 = insertelement <8 x float> %661, float %673, i64 6
  %675 = xor i1 %671, true
  %676 = and i1 %669, %675
  %677 = insertelement <8 x i1> %664, i1 %676, i64 6
  %678 = extractelement <8 x i32> %584, i64 7
  %679 = icmp ult i32 %678, 8
  %680 = select i1 %679, i32 %678, i32 0
  %681 = extractelement <8 x i1> %62, i32 %680
  %682 = extractelement <8 x i1> %62, i64 7
  %683 = and i1 %679, %681
  %684 = and i1 %682, %683
  %685 = extractelement <8 x float> %583, i32 %680
  %686 = select i1 %684, float %685, float 0.000000e+00
  %687 = insertelement <8 x float> %674, float %686, i64 7
  %688 = xor i1 %684, true
  %689 = and i1 %682, %688
  %690 = insertelement <8 x i1> %677, i1 %689, i64 7
  %691 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %583, <8 x float> %687)
  %692 = extractelement <8 x i1> %62, i32 0
  %693 = extractelement <8 x i1> %62, i64 0
  %694 = and i1 true, %692
  %695 = and i1 %693, %694
  %696 = extractelement <8 x float> %691, i32 0
  %697 = select i1 %695, float %696, float 0.000000e+00
  %698 = insertelement <8 x float> poison, float %697, i64 0
  %699 = xor i1 %695, true
  %700 = and i1 %693, %699
  %701 = insertelement <8 x i1> poison, i1 %700, i64 0
  %702 = extractelement <8 x i1> %62, i32 0
  %703 = extractelement <8 x i1> %62, i64 1
  %704 = and i1 true, %702
  %705 = and i1 %703, %704
  %706 = extractelement <8 x float> %691, i32 0
  %707 = select i1 %705, float %706, float 0.000000e+00
  %708 = insertelement <8 x float> %698, float %707, i64 1
  %709 = xor i1 %705, true
  %710 = and i1 %703, %709
  %711 = insertelement <8 x i1> %701, i1 %710, i64 1
  %712 = extractelement <8 x i1> %62, i32 0
  %713 = extractelement <8 x i1> %62, i64 2
  %714 = and i1 true, %712
  %715 = and i1 %713, %714
  %716 = extractelement <8 x float> %691, i32 0
  %717 = select i1 %715, float %716, float 0.000000e+00
  %718 = insertelement <8 x float> %708, float %717, i64 2
  %719 = xor i1 %715, true
  %720 = and i1 %713, %719
  %721 = insertelement <8 x i1> %711, i1 %720, i64 2
  %722 = extractelement <8 x i1> %62, i32 0
  %723 = extractelement <8 x i1> %62, i64 3
  %724 = and i1 true, %722
  %725 = and i1 %723, %724
  %726 = extractelement <8 x float> %691, i32 0
  %727 = select i1 %725, float %726, float 0.000000e+00
  %728 = insertelement <8 x float> %718, float %727, i64 3
  %729 = xor i1 %725, true
  %730 = and i1 %723, %729
  %731 = insertelement <8 x i1> %721, i1 %730, i64 3
  %732 = extractelement <8 x i1> %62, i32 0
  %733 = extractelement <8 x i1> %62, i64 4
  %734 = and i1 true, %732
  %735 = and i1 %733, %734
  %736 = extractelement <8 x float> %691, i32 0
  %737 = select i1 %735, float %736, float 0.000000e+00
  %738 = insertelement <8 x float> %728, float %737, i64 4
  %739 = xor i1 %735, true
  %740 = and i1 %733, %739
  %741 = insertelement <8 x i1> %731, i1 %740, i64 4
  %742 = extractelement <8 x i1> %62, i32 0
  %743 = extractelement <8 x i1> %62, i64 5
  %744 = and i1 true, %742
  %745 = and i1 %743, %744
  %746 = extractelement <8 x float> %691, i32 0
  %747 = select i1 %745, float %746, float 0.000000e+00
  %748 = insertelement <8 x float> %738, float %747, i64 5
  %749 = xor i1 %745, true
  %750 = and i1 %743, %749
  %751 = insertelement <8 x i1> %741, i1 %750, i64 5
  %752 = extractelement <8 x i1> %62, i32 0
  %753 = extractelement <8 x i1> %62, i64 6
  %754 = and i1 true, %752
  %755 = and i1 %753, %754
  %756 = extractelement <8 x float> %691, i32 0
  %757 = select i1 %755, float %756, float 0.000000e+00
  %758 = insertelement <8 x float> %748, float %757, i64 6
  %759 = xor i1 %755, true
  %760 = and i1 %753, %759
  %761 = insertelement <8 x i1> %751, i1 %760, i64 6
  %762 = extractelement <8 x i1> %62, i32 0
  %763 = extractelement <8 x i1> %62, i64 7
  %764 = and i1 true, %762
  %765 = and i1 %763, %764
  %766 = extractelement <8 x float> %691, i32 0
  %767 = select i1 %765, float %766, float 0.000000e+00
  %768 = insertelement <8 x float> %758, float %767, i64 7
  %769 = xor i1 %765, true
  %770 = and i1 %763, %769
  %771 = insertelement <8 x i1> %761, i1 %770, i64 7
  %772 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %773 = bitcast <8 x i1> %62 to i8
  %774 = call i8 @llvm.cttz.i8(i8 %773, i1 false)
  %775 = zext i8 %774 to i32
  %776 = select i1 %772, i32 %775, i32 0
  %777 = extractelement <8 x float> %768, i32 %776
  %.spill.load165 = load float, ptr %.spill26, align 4
  %778 = call float @llvm.maxnum.f32(float %.spill.load165, float %777)
  store float %778, ptr %.spill35, align 4
  store float 0.000000e+00, ptr %.spill36, align 4
  %779 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %780 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %781 = extractvalue { <8 x ptr>, <8 x i64> } %779, 0
  %782 = select <8 x i1> %62, <8 x ptr> %780, <8 x ptr> %781
  %783 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %784 = extractvalue { <8 x ptr>, <8 x i64> } %779, 1
  %785 = select <8 x i1> %62, <8 x i64> %783, <8 x i64> %784
  %786 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %782, 0
  %787 = insertvalue { <8 x ptr>, <8 x i64> } %786, <8 x i64> %785, 1
  store { <8 x ptr>, <8 x i64> } %787, ptr %tile_snapshot.spill37, align 64
  store i64 0, ptr %.slot38, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state166 = load i64, ptr %.slot38, align 4
  %788 = icmp slt i64 %.state166, 512
  br i1 %788, label %direct.true167, label %direct.false168

direct.schedule.17:                               ; preds = %direct.true167
  %tile_snapshot.spill.load169 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %789 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load169, 0
  %790 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load169, 1
  %.state170 = load i64, ptr %.slot38, align 4
  %.splatinsert171 = insertelement <8 x i64> poison, i64 %.state170, i64 0
  %.splat172 = shufflevector <8 x i64> %.splatinsert171, <8 x i64> poison, <8 x i32> zeroinitializer
  %791 = add <8 x i64> %790, %.splat172
  %792 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %789, 0
  %793 = insertvalue { <8 x ptr>, <8 x i64> } %792, <8 x i64> %791, 1
  %794 = extractvalue { <8 x ptr>, <8 x i64> } %793, 0
  %795 = extractvalue { <8 x ptr>, <8 x i64> } %793, 1
  %796 = getelementptr i8, <8 x ptr> %794, <8 x i64> %795
  %797 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %796, i32 1, <8 x i1> %62, <8 x i8> zeroinitializer)
  %798 = icmp ne <8 x i8> %797, zeroinitializer
  %tile_snapshot.spill.load173 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill24, align 64
  %799 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load173, 0
  %800 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load173, 1
  %.state174 = load i64, ptr %.slot38, align 4
  %.splatinsert175 = insertelement <8 x i64> poison, i64 %.state174, i64 0
  %.splat176 = shufflevector <8 x i64> %.splatinsert175, <8 x i64> poison, <8 x i32> zeroinitializer
  %801 = mul <8 x i64> %.splat176, splat (i64 32)
  %802 = add <8 x i64> %800, %801
  %803 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %799, 0
  %804 = insertvalue { <8 x ptr>, <8 x i64> } %803, <8 x i64> %802, 1
  %805 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %806 = extractvalue { <8 x ptr>, <8 x i64> } %804, 1
  %807 = extractelement <8 x ptr> %805, i32 0
  %808 = extractelement <8 x i64> %806, i32 0
  %809 = sub i64 %808, 0
  %810 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %811 = select i1 %810, i64 %809, i64 0
  %private.contiguous.address177 = getelementptr i8, ptr %807, i64 %811
  %private.contiguous.load178 = load <8 x float>, ptr %private.contiguous.address177, align 4
  %812 = select <8 x i1> %62, <8 x float> %private.contiguous.load178, <8 x float> zeroinitializer
  %.spill.load179 = load float, ptr %.spill35, align 4
  %.splatinsert180 = insertelement <8 x float> poison, float %.spill.load179, i64 0
  %.splat181 = shufflevector <8 x float> %.splatinsert180, <8 x float> poison, <8 x i32> zeroinitializer
  %813 = fsub <8 x float> %812, %.splat181
  %814 = select <8 x i1> %62, <8 x float> %813, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %814)
  %.spill.load182 = load float, ptr %.spill36, align 4
  %.splatinsert183 = insertelement <8 x float> poison, float %.spill.load182, i64 0
  %.splat184 = shufflevector <8 x float> %.splatinsert183, <8 x float> poison, <8 x i32> zeroinitializer
  %815 = select <8 x i1> %798, <8 x float> %native.exp, <8 x float> %.splat184
  %tile_snapshot.spill.load185 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %816 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load185, 0
  %817 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load185, 1
  %.state186 = load i64, ptr %.slot38, align 4
  %.splatinsert187 = insertelement <8 x i64> poison, i64 %.state186, i64 0
  %.splat188 = shufflevector <8 x i64> %.splatinsert187, <8 x i64> poison, <8 x i32> zeroinitializer
  %818 = mul <8 x i64> %.splat188, splat (i64 32)
  %819 = add <8 x i64> %817, %818
  %820 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %816, 0
  %821 = insertvalue { <8 x ptr>, <8 x i64> } %820, <8 x i64> %819, 1
  %822 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %823 = extractvalue { <8 x ptr>, <8 x i64> } %821, 1
  %824 = extractelement <8 x ptr> %822, i32 0
  %825 = extractelement <8 x i64> %823, i32 0
  %826 = sub i64 %825, 0
  %827 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %828 = select i1 %827, i64 %826, i64 0
  %private.contiguous.address189 = getelementptr i8, ptr %824, i64 %828
  %private.contiguous.preserve190 = load <8 x float>, ptr %private.contiguous.address189, align 4
  %829 = select <8 x i1> %62, <8 x float> %815, <8 x float> %private.contiguous.preserve190
  store <8 x float> %829, ptr %private.contiguous.address189, align 4
  %.state191 = load i64, ptr %.slot38, align 4
  %830 = add i64 %.state191, 1
  store i64 %830, ptr %.slot38, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false168
  %tile_snapshot.spill.load192 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %831 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 0
  %832 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 1
  %833 = add <8 x i64> %832, zeroinitializer
  %834 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %831, 0
  %835 = insertvalue { <8 x ptr>, <8 x i64> } %834, <8 x i64> %833, 1
  %836 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %837 = extractvalue { <8 x ptr>, <8 x i64> } %835, 1
  %838 = extractelement <8 x ptr> %836, i32 0
  %839 = extractelement <8 x i64> %837, i32 0
  %840 = sub i64 %839, 0
  %841 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %842 = select i1 %841, i64 %840, i64 0
  %private.contiguous.address193 = getelementptr i8, ptr %838, i64 %842
  %private.contiguous.load194 = load <8 x float>, ptr %private.contiguous.address193, align 4
  %843 = select <8 x i1> %62, <8 x float> %private.contiguous.load194, <8 x float> zeroinitializer
  %tile_snapshot.spill.load195 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %844 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load195, 0
  %845 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load195, 1
  %846 = add <8 x i64> %845, splat (i64 32)
  %847 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %844, 0
  %848 = insertvalue { <8 x ptr>, <8 x i64> } %847, <8 x i64> %846, 1
  %849 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %850 = extractvalue { <8 x ptr>, <8 x i64> } %848, 1
  %851 = extractelement <8 x ptr> %849, i32 0
  %852 = extractelement <8 x i64> %850, i32 0
  %853 = sub i64 %852, 0
  %854 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %855 = select i1 %854, i64 %853, i64 0
  %private.contiguous.address196 = getelementptr i8, ptr %851, i64 %855
  %private.contiguous.load197 = load <8 x float>, ptr %private.contiguous.address196, align 4
  %856 = select <8 x i1> %62, <8 x float> %private.contiguous.load197, <8 x float> zeroinitializer
  %tile_snapshot.spill.load198 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %857 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load198, 0
  %858 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load198, 1
  %859 = add <8 x i64> %858, splat (i64 64)
  %860 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %857, 0
  %861 = insertvalue { <8 x ptr>, <8 x i64> } %860, <8 x i64> %859, 1
  %862 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %863 = extractvalue { <8 x ptr>, <8 x i64> } %861, 1
  %864 = extractelement <8 x ptr> %862, i32 0
  %865 = extractelement <8 x i64> %863, i32 0
  %866 = sub i64 %865, 0
  %867 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %868 = select i1 %867, i64 %866, i64 0
  %private.contiguous.address199 = getelementptr i8, ptr %864, i64 %868
  %private.contiguous.load200 = load <8 x float>, ptr %private.contiguous.address199, align 4
  %869 = select <8 x i1> %62, <8 x float> %private.contiguous.load200, <8 x float> zeroinitializer
  %tile_snapshot.spill.load201 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %870 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load201, 0
  %871 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load201, 1
  %872 = add <8 x i64> %871, splat (i64 96)
  %873 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %870, 0
  %874 = insertvalue { <8 x ptr>, <8 x i64> } %873, <8 x i64> %872, 1
  %875 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %876 = extractvalue { <8 x ptr>, <8 x i64> } %874, 1
  %877 = extractelement <8 x ptr> %875, i32 0
  %878 = extractelement <8 x i64> %876, i32 0
  %879 = sub i64 %878, 0
  %880 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %881 = select i1 %880, i64 %879, i64 0
  %private.contiguous.address202 = getelementptr i8, ptr %877, i64 %881
  %private.contiguous.load203 = load <8 x float>, ptr %private.contiguous.address202, align 4
  %882 = select <8 x i1> %62, <8 x float> %private.contiguous.load203, <8 x float> zeroinitializer
  store i64 4, ptr %.slot39, align 4
  %883 = load <8 x float>, ptr %.slot40, align 32
  %884 = select <8 x i1> %62, <8 x float> %843, <8 x float> %883
  store <8 x float> %884, ptr %.slot40, align 32
  %885 = load <8 x float>, ptr %.slot41, align 32
  %886 = select <8 x i1> %62, <8 x float> %856, <8 x float> %885
  store <8 x float> %886, ptr %.slot41, align 32
  %887 = load <8 x float>, ptr %.slot42, align 32
  %888 = select <8 x i1> %62, <8 x float> %869, <8 x float> %887
  store <8 x float> %888, ptr %.slot42, align 32
  %889 = load <8 x float>, ptr %.slot43, align 32
  %890 = select <8 x i1> %62, <8 x float> %882, <8 x float> %889
  store <8 x float> %890, ptr %.slot43, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state204 = load i64, ptr %.slot39, align 4
  %891 = icmp slt i64 %.state204, 512
  br i1 %891, label %direct.true205, label %direct.false206

direct.schedule.20:                               ; preds = %direct.true205
  %.state207 = load i64, ptr %.slot39, align 4
  %892 = add i64 %.state207, 0
  %tile_snapshot.spill.load208 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %893 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load208, 0
  %894 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load208, 1
  %.splatinsert209 = insertelement <8 x i64> poison, i64 %892, i64 0
  %.splat210 = shufflevector <8 x i64> %.splatinsert209, <8 x i64> poison, <8 x i32> zeroinitializer
  %895 = mul <8 x i64> %.splat210, splat (i64 32)
  %896 = add <8 x i64> %894, %895
  %897 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %893, 0
  %898 = insertvalue { <8 x ptr>, <8 x i64> } %897, <8 x i64> %896, 1
  %899 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %900 = extractvalue { <8 x ptr>, <8 x i64> } %898, 1
  %901 = extractelement <8 x ptr> %899, i32 0
  %902 = extractelement <8 x i64> %900, i32 0
  %903 = sub i64 %902, 0
  %904 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %905 = select i1 %904, i64 %903, i64 0
  %private.contiguous.address211 = getelementptr i8, ptr %901, i64 %905
  %private.contiguous.load212 = load <8 x float>, ptr %private.contiguous.address211, align 4
  %906 = select <8 x i1> %62, <8 x float> %private.contiguous.load212, <8 x float> zeroinitializer
  %.state213 = load <8 x float>, ptr %.slot40, align 32
  %907 = fadd <8 x float> %.state213, %906
  %.state214 = load i64, ptr %.slot39, align 4
  %908 = add i64 %.state214, 1
  %tile_snapshot.spill.load215 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %909 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load215, 0
  %910 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load215, 1
  %.splatinsert216 = insertelement <8 x i64> poison, i64 %908, i64 0
  %.splat217 = shufflevector <8 x i64> %.splatinsert216, <8 x i64> poison, <8 x i32> zeroinitializer
  %911 = mul <8 x i64> %.splat217, splat (i64 32)
  %912 = add <8 x i64> %910, %911
  %913 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %909, 0
  %914 = insertvalue { <8 x ptr>, <8 x i64> } %913, <8 x i64> %912, 1
  %915 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %916 = extractvalue { <8 x ptr>, <8 x i64> } %914, 1
  %917 = extractelement <8 x ptr> %915, i32 0
  %918 = extractelement <8 x i64> %916, i32 0
  %919 = sub i64 %918, 0
  %920 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %921 = select i1 %920, i64 %919, i64 0
  %private.contiguous.address218 = getelementptr i8, ptr %917, i64 %921
  %private.contiguous.load219 = load <8 x float>, ptr %private.contiguous.address218, align 4
  %922 = select <8 x i1> %62, <8 x float> %private.contiguous.load219, <8 x float> zeroinitializer
  %.state220 = load <8 x float>, ptr %.slot41, align 32
  %923 = fadd <8 x float> %.state220, %922
  %.state221 = load i64, ptr %.slot39, align 4
  %924 = add i64 %.state221, 2
  %tile_snapshot.spill.load222 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %925 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load222, 0
  %926 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load222, 1
  %.splatinsert223 = insertelement <8 x i64> poison, i64 %924, i64 0
  %.splat224 = shufflevector <8 x i64> %.splatinsert223, <8 x i64> poison, <8 x i32> zeroinitializer
  %927 = mul <8 x i64> %.splat224, splat (i64 32)
  %928 = add <8 x i64> %926, %927
  %929 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %925, 0
  %930 = insertvalue { <8 x ptr>, <8 x i64> } %929, <8 x i64> %928, 1
  %931 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %932 = extractvalue { <8 x ptr>, <8 x i64> } %930, 1
  %933 = extractelement <8 x ptr> %931, i32 0
  %934 = extractelement <8 x i64> %932, i32 0
  %935 = sub i64 %934, 0
  %936 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %937 = select i1 %936, i64 %935, i64 0
  %private.contiguous.address225 = getelementptr i8, ptr %933, i64 %937
  %private.contiguous.load226 = load <8 x float>, ptr %private.contiguous.address225, align 4
  %938 = select <8 x i1> %62, <8 x float> %private.contiguous.load226, <8 x float> zeroinitializer
  %.state227 = load <8 x float>, ptr %.slot42, align 32
  %939 = fadd <8 x float> %.state227, %938
  %.state228 = load i64, ptr %.slot39, align 4
  %940 = add i64 %.state228, 3
  %tile_snapshot.spill.load229 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %941 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load229, 0
  %942 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load229, 1
  %.splatinsert230 = insertelement <8 x i64> poison, i64 %940, i64 0
  %.splat231 = shufflevector <8 x i64> %.splatinsert230, <8 x i64> poison, <8 x i32> zeroinitializer
  %943 = mul <8 x i64> %.splat231, splat (i64 32)
  %944 = add <8 x i64> %942, %943
  %945 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %941, 0
  %946 = insertvalue { <8 x ptr>, <8 x i64> } %945, <8 x i64> %944, 1
  %947 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %948 = extractvalue { <8 x ptr>, <8 x i64> } %946, 1
  %949 = extractelement <8 x ptr> %947, i32 0
  %950 = extractelement <8 x i64> %948, i32 0
  %951 = sub i64 %950, 0
  %952 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %953 = select i1 %952, i64 %951, i64 0
  %private.contiguous.address232 = getelementptr i8, ptr %949, i64 %953
  %private.contiguous.load233 = load <8 x float>, ptr %private.contiguous.address232, align 4
  %954 = select <8 x i1> %62, <8 x float> %private.contiguous.load233, <8 x float> zeroinitializer
  %.state234 = load <8 x float>, ptr %.slot43, align 32
  %955 = fadd <8 x float> %.state234, %954
  %.state235 = load i64, ptr %.slot39, align 4
  %956 = add i64 %.state235, 4
  store i64 %956, ptr %.slot39, align 4
  %957 = load <8 x float>, ptr %.slot40, align 32
  %958 = select <8 x i1> %62, <8 x float> %907, <8 x float> %957
  store <8 x float> %958, ptr %.slot40, align 32
  %959 = load <8 x float>, ptr %.slot41, align 32
  %960 = select <8 x i1> %62, <8 x float> %923, <8 x float> %959
  store <8 x float> %960, ptr %.slot41, align 32
  %961 = load <8 x float>, ptr %.slot42, align 32
  %962 = select <8 x i1> %62, <8 x float> %939, <8 x float> %961
  store <8 x float> %962, ptr %.slot42, align 32
  %963 = load <8 x float>, ptr %.slot43, align 32
  %964 = select <8 x i1> %62, <8 x float> %955, <8 x float> %963
  store <8 x float> %964, ptr %.slot43, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false206
  %.state236 = load <8 x float>, ptr %.slot40, align 32
  %.state237 = load <8 x float>, ptr %.slot41, align 32
  %965 = fadd <8 x float> %.state236, %.state237
  %.state238 = load <8 x float>, ptr %.slot42, align 32
  %966 = fadd <8 x float> %965, %.state238
  %.state239 = load <8 x float>, ptr %.slot43, align 32
  %967 = fadd <8 x float> %966, %.state239
  %.spill.load240 = load <8 x i32>, ptr %.spill32, align 32
  %968 = extractelement <8 x i32> %.spill.load240, i64 0
  %969 = icmp ult i32 %968, 8
  %970 = select i1 %969, i32 %968, i32 0
  %971 = extractelement <8 x i1> %62, i32 %970
  %972 = extractelement <8 x i1> %62, i64 0
  %973 = and i1 %969, %971
  %974 = and i1 %972, %973
  %975 = extractelement <8 x float> %967, i32 %970
  %976 = select i1 %974, float %975, float 0.000000e+00
  %977 = insertelement <8 x float> poison, float %976, i64 0
  %978 = xor i1 %974, true
  %979 = and i1 %972, %978
  %980 = insertelement <8 x i1> poison, i1 %979, i64 0
  %981 = extractelement <8 x i32> %.spill.load240, i64 1
  %982 = icmp ult i32 %981, 8
  %983 = select i1 %982, i32 %981, i32 0
  %984 = extractelement <8 x i1> %62, i32 %983
  %985 = extractelement <8 x i1> %62, i64 1
  %986 = and i1 %982, %984
  %987 = and i1 %985, %986
  %988 = extractelement <8 x float> %967, i32 %983
  %989 = select i1 %987, float %988, float 0.000000e+00
  %990 = insertelement <8 x float> %977, float %989, i64 1
  %991 = xor i1 %987, true
  %992 = and i1 %985, %991
  %993 = insertelement <8 x i1> %980, i1 %992, i64 1
  %994 = extractelement <8 x i32> %.spill.load240, i64 2
  %995 = icmp ult i32 %994, 8
  %996 = select i1 %995, i32 %994, i32 0
  %997 = extractelement <8 x i1> %62, i32 %996
  %998 = extractelement <8 x i1> %62, i64 2
  %999 = and i1 %995, %997
  %1000 = and i1 %998, %999
  %1001 = extractelement <8 x float> %967, i32 %996
  %1002 = select i1 %1000, float %1001, float 0.000000e+00
  %1003 = insertelement <8 x float> %990, float %1002, i64 2
  %1004 = xor i1 %1000, true
  %1005 = and i1 %998, %1004
  %1006 = insertelement <8 x i1> %993, i1 %1005, i64 2
  %1007 = extractelement <8 x i32> %.spill.load240, i64 3
  %1008 = icmp ult i32 %1007, 8
  %1009 = select i1 %1008, i32 %1007, i32 0
  %1010 = extractelement <8 x i1> %62, i32 %1009
  %1011 = extractelement <8 x i1> %62, i64 3
  %1012 = and i1 %1008, %1010
  %1013 = and i1 %1011, %1012
  %1014 = extractelement <8 x float> %967, i32 %1009
  %1015 = select i1 %1013, float %1014, float 0.000000e+00
  %1016 = insertelement <8 x float> %1003, float %1015, i64 3
  %1017 = xor i1 %1013, true
  %1018 = and i1 %1011, %1017
  %1019 = insertelement <8 x i1> %1006, i1 %1018, i64 3
  %1020 = extractelement <8 x i32> %.spill.load240, i64 4
  %1021 = icmp ult i32 %1020, 8
  %1022 = select i1 %1021, i32 %1020, i32 0
  %1023 = extractelement <8 x i1> %62, i32 %1022
  %1024 = extractelement <8 x i1> %62, i64 4
  %1025 = and i1 %1021, %1023
  %1026 = and i1 %1024, %1025
  %1027 = extractelement <8 x float> %967, i32 %1022
  %1028 = select i1 %1026, float %1027, float 0.000000e+00
  %1029 = insertelement <8 x float> %1016, float %1028, i64 4
  %1030 = xor i1 %1026, true
  %1031 = and i1 %1024, %1030
  %1032 = insertelement <8 x i1> %1019, i1 %1031, i64 4
  %1033 = extractelement <8 x i32> %.spill.load240, i64 5
  %1034 = icmp ult i32 %1033, 8
  %1035 = select i1 %1034, i32 %1033, i32 0
  %1036 = extractelement <8 x i1> %62, i32 %1035
  %1037 = extractelement <8 x i1> %62, i64 5
  %1038 = and i1 %1034, %1036
  %1039 = and i1 %1037, %1038
  %1040 = extractelement <8 x float> %967, i32 %1035
  %1041 = select i1 %1039, float %1040, float 0.000000e+00
  %1042 = insertelement <8 x float> %1029, float %1041, i64 5
  %1043 = xor i1 %1039, true
  %1044 = and i1 %1037, %1043
  %1045 = insertelement <8 x i1> %1032, i1 %1044, i64 5
  %1046 = extractelement <8 x i32> %.spill.load240, i64 6
  %1047 = icmp ult i32 %1046, 8
  %1048 = select i1 %1047, i32 %1046, i32 0
  %1049 = extractelement <8 x i1> %62, i32 %1048
  %1050 = extractelement <8 x i1> %62, i64 6
  %1051 = and i1 %1047, %1049
  %1052 = and i1 %1050, %1051
  %1053 = extractelement <8 x float> %967, i32 %1048
  %1054 = select i1 %1052, float %1053, float 0.000000e+00
  %1055 = insertelement <8 x float> %1042, float %1054, i64 6
  %1056 = xor i1 %1052, true
  %1057 = and i1 %1050, %1056
  %1058 = insertelement <8 x i1> %1045, i1 %1057, i64 6
  %1059 = extractelement <8 x i32> %.spill.load240, i64 7
  %1060 = icmp ult i32 %1059, 8
  %1061 = select i1 %1060, i32 %1059, i32 0
  %1062 = extractelement <8 x i1> %62, i32 %1061
  %1063 = extractelement <8 x i1> %62, i64 7
  %1064 = and i1 %1060, %1062
  %1065 = and i1 %1063, %1064
  %1066 = extractelement <8 x float> %967, i32 %1061
  %1067 = select i1 %1065, float %1066, float 0.000000e+00
  %1068 = insertelement <8 x float> %1055, float %1067, i64 7
  %1069 = xor i1 %1065, true
  %1070 = and i1 %1063, %1069
  %1071 = insertelement <8 x i1> %1058, i1 %1070, i64 7
  %1072 = fadd <8 x float> %967, %1068
  %.spill.load241 = load <8 x i32>, ptr %.spill33, align 32
  %1073 = extractelement <8 x i32> %.spill.load241, i64 0
  %1074 = icmp ult i32 %1073, 8
  %1075 = select i1 %1074, i32 %1073, i32 0
  %1076 = extractelement <8 x i1> %62, i32 %1075
  %1077 = extractelement <8 x i1> %62, i64 0
  %1078 = and i1 %1074, %1076
  %1079 = and i1 %1077, %1078
  %1080 = extractelement <8 x float> %1072, i32 %1075
  %1081 = select i1 %1079, float %1080, float 0.000000e+00
  %1082 = insertelement <8 x float> poison, float %1081, i64 0
  %1083 = xor i1 %1079, true
  %1084 = and i1 %1077, %1083
  %1085 = insertelement <8 x i1> poison, i1 %1084, i64 0
  %1086 = extractelement <8 x i32> %.spill.load241, i64 1
  %1087 = icmp ult i32 %1086, 8
  %1088 = select i1 %1087, i32 %1086, i32 0
  %1089 = extractelement <8 x i1> %62, i32 %1088
  %1090 = extractelement <8 x i1> %62, i64 1
  %1091 = and i1 %1087, %1089
  %1092 = and i1 %1090, %1091
  %1093 = extractelement <8 x float> %1072, i32 %1088
  %1094 = select i1 %1092, float %1093, float 0.000000e+00
  %1095 = insertelement <8 x float> %1082, float %1094, i64 1
  %1096 = xor i1 %1092, true
  %1097 = and i1 %1090, %1096
  %1098 = insertelement <8 x i1> %1085, i1 %1097, i64 1
  %1099 = extractelement <8 x i32> %.spill.load241, i64 2
  %1100 = icmp ult i32 %1099, 8
  %1101 = select i1 %1100, i32 %1099, i32 0
  %1102 = extractelement <8 x i1> %62, i32 %1101
  %1103 = extractelement <8 x i1> %62, i64 2
  %1104 = and i1 %1100, %1102
  %1105 = and i1 %1103, %1104
  %1106 = extractelement <8 x float> %1072, i32 %1101
  %1107 = select i1 %1105, float %1106, float 0.000000e+00
  %1108 = insertelement <8 x float> %1095, float %1107, i64 2
  %1109 = xor i1 %1105, true
  %1110 = and i1 %1103, %1109
  %1111 = insertelement <8 x i1> %1098, i1 %1110, i64 2
  %1112 = extractelement <8 x i32> %.spill.load241, i64 3
  %1113 = icmp ult i32 %1112, 8
  %1114 = select i1 %1113, i32 %1112, i32 0
  %1115 = extractelement <8 x i1> %62, i32 %1114
  %1116 = extractelement <8 x i1> %62, i64 3
  %1117 = and i1 %1113, %1115
  %1118 = and i1 %1116, %1117
  %1119 = extractelement <8 x float> %1072, i32 %1114
  %1120 = select i1 %1118, float %1119, float 0.000000e+00
  %1121 = insertelement <8 x float> %1108, float %1120, i64 3
  %1122 = xor i1 %1118, true
  %1123 = and i1 %1116, %1122
  %1124 = insertelement <8 x i1> %1111, i1 %1123, i64 3
  %1125 = extractelement <8 x i32> %.spill.load241, i64 4
  %1126 = icmp ult i32 %1125, 8
  %1127 = select i1 %1126, i32 %1125, i32 0
  %1128 = extractelement <8 x i1> %62, i32 %1127
  %1129 = extractelement <8 x i1> %62, i64 4
  %1130 = and i1 %1126, %1128
  %1131 = and i1 %1129, %1130
  %1132 = extractelement <8 x float> %1072, i32 %1127
  %1133 = select i1 %1131, float %1132, float 0.000000e+00
  %1134 = insertelement <8 x float> %1121, float %1133, i64 4
  %1135 = xor i1 %1131, true
  %1136 = and i1 %1129, %1135
  %1137 = insertelement <8 x i1> %1124, i1 %1136, i64 4
  %1138 = extractelement <8 x i32> %.spill.load241, i64 5
  %1139 = icmp ult i32 %1138, 8
  %1140 = select i1 %1139, i32 %1138, i32 0
  %1141 = extractelement <8 x i1> %62, i32 %1140
  %1142 = extractelement <8 x i1> %62, i64 5
  %1143 = and i1 %1139, %1141
  %1144 = and i1 %1142, %1143
  %1145 = extractelement <8 x float> %1072, i32 %1140
  %1146 = select i1 %1144, float %1145, float 0.000000e+00
  %1147 = insertelement <8 x float> %1134, float %1146, i64 5
  %1148 = xor i1 %1144, true
  %1149 = and i1 %1142, %1148
  %1150 = insertelement <8 x i1> %1137, i1 %1149, i64 5
  %1151 = extractelement <8 x i32> %.spill.load241, i64 6
  %1152 = icmp ult i32 %1151, 8
  %1153 = select i1 %1152, i32 %1151, i32 0
  %1154 = extractelement <8 x i1> %62, i32 %1153
  %1155 = extractelement <8 x i1> %62, i64 6
  %1156 = and i1 %1152, %1154
  %1157 = and i1 %1155, %1156
  %1158 = extractelement <8 x float> %1072, i32 %1153
  %1159 = select i1 %1157, float %1158, float 0.000000e+00
  %1160 = insertelement <8 x float> %1147, float %1159, i64 6
  %1161 = xor i1 %1157, true
  %1162 = and i1 %1155, %1161
  %1163 = insertelement <8 x i1> %1150, i1 %1162, i64 6
  %1164 = extractelement <8 x i32> %.spill.load241, i64 7
  %1165 = icmp ult i32 %1164, 8
  %1166 = select i1 %1165, i32 %1164, i32 0
  %1167 = extractelement <8 x i1> %62, i32 %1166
  %1168 = extractelement <8 x i1> %62, i64 7
  %1169 = and i1 %1165, %1167
  %1170 = and i1 %1168, %1169
  %1171 = extractelement <8 x float> %1072, i32 %1166
  %1172 = select i1 %1170, float %1171, float 0.000000e+00
  %1173 = insertelement <8 x float> %1160, float %1172, i64 7
  %1174 = xor i1 %1170, true
  %1175 = and i1 %1168, %1174
  %1176 = insertelement <8 x i1> %1163, i1 %1175, i64 7
  %1177 = fadd <8 x float> %1072, %1173
  %.spill.load242 = load <8 x i32>, ptr %.spill34, align 32
  %1178 = extractelement <8 x i32> %.spill.load242, i64 0
  %1179 = icmp ult i32 %1178, 8
  %1180 = select i1 %1179, i32 %1178, i32 0
  %1181 = extractelement <8 x i1> %62, i32 %1180
  %1182 = extractelement <8 x i1> %62, i64 0
  %1183 = and i1 %1179, %1181
  %1184 = and i1 %1182, %1183
  %1185 = extractelement <8 x float> %1177, i32 %1180
  %1186 = select i1 %1184, float %1185, float 0.000000e+00
  %1187 = insertelement <8 x float> poison, float %1186, i64 0
  %1188 = xor i1 %1184, true
  %1189 = and i1 %1182, %1188
  %1190 = insertelement <8 x i1> poison, i1 %1189, i64 0
  %1191 = extractelement <8 x i32> %.spill.load242, i64 1
  %1192 = icmp ult i32 %1191, 8
  %1193 = select i1 %1192, i32 %1191, i32 0
  %1194 = extractelement <8 x i1> %62, i32 %1193
  %1195 = extractelement <8 x i1> %62, i64 1
  %1196 = and i1 %1192, %1194
  %1197 = and i1 %1195, %1196
  %1198 = extractelement <8 x float> %1177, i32 %1193
  %1199 = select i1 %1197, float %1198, float 0.000000e+00
  %1200 = insertelement <8 x float> %1187, float %1199, i64 1
  %1201 = xor i1 %1197, true
  %1202 = and i1 %1195, %1201
  %1203 = insertelement <8 x i1> %1190, i1 %1202, i64 1
  %1204 = extractelement <8 x i32> %.spill.load242, i64 2
  %1205 = icmp ult i32 %1204, 8
  %1206 = select i1 %1205, i32 %1204, i32 0
  %1207 = extractelement <8 x i1> %62, i32 %1206
  %1208 = extractelement <8 x i1> %62, i64 2
  %1209 = and i1 %1205, %1207
  %1210 = and i1 %1208, %1209
  %1211 = extractelement <8 x float> %1177, i32 %1206
  %1212 = select i1 %1210, float %1211, float 0.000000e+00
  %1213 = insertelement <8 x float> %1200, float %1212, i64 2
  %1214 = xor i1 %1210, true
  %1215 = and i1 %1208, %1214
  %1216 = insertelement <8 x i1> %1203, i1 %1215, i64 2
  %1217 = extractelement <8 x i32> %.spill.load242, i64 3
  %1218 = icmp ult i32 %1217, 8
  %1219 = select i1 %1218, i32 %1217, i32 0
  %1220 = extractelement <8 x i1> %62, i32 %1219
  %1221 = extractelement <8 x i1> %62, i64 3
  %1222 = and i1 %1218, %1220
  %1223 = and i1 %1221, %1222
  %1224 = extractelement <8 x float> %1177, i32 %1219
  %1225 = select i1 %1223, float %1224, float 0.000000e+00
  %1226 = insertelement <8 x float> %1213, float %1225, i64 3
  %1227 = xor i1 %1223, true
  %1228 = and i1 %1221, %1227
  %1229 = insertelement <8 x i1> %1216, i1 %1228, i64 3
  %1230 = extractelement <8 x i32> %.spill.load242, i64 4
  %1231 = icmp ult i32 %1230, 8
  %1232 = select i1 %1231, i32 %1230, i32 0
  %1233 = extractelement <8 x i1> %62, i32 %1232
  %1234 = extractelement <8 x i1> %62, i64 4
  %1235 = and i1 %1231, %1233
  %1236 = and i1 %1234, %1235
  %1237 = extractelement <8 x float> %1177, i32 %1232
  %1238 = select i1 %1236, float %1237, float 0.000000e+00
  %1239 = insertelement <8 x float> %1226, float %1238, i64 4
  %1240 = xor i1 %1236, true
  %1241 = and i1 %1234, %1240
  %1242 = insertelement <8 x i1> %1229, i1 %1241, i64 4
  %1243 = extractelement <8 x i32> %.spill.load242, i64 5
  %1244 = icmp ult i32 %1243, 8
  %1245 = select i1 %1244, i32 %1243, i32 0
  %1246 = extractelement <8 x i1> %62, i32 %1245
  %1247 = extractelement <8 x i1> %62, i64 5
  %1248 = and i1 %1244, %1246
  %1249 = and i1 %1247, %1248
  %1250 = extractelement <8 x float> %1177, i32 %1245
  %1251 = select i1 %1249, float %1250, float 0.000000e+00
  %1252 = insertelement <8 x float> %1239, float %1251, i64 5
  %1253 = xor i1 %1249, true
  %1254 = and i1 %1247, %1253
  %1255 = insertelement <8 x i1> %1242, i1 %1254, i64 5
  %1256 = extractelement <8 x i32> %.spill.load242, i64 6
  %1257 = icmp ult i32 %1256, 8
  %1258 = select i1 %1257, i32 %1256, i32 0
  %1259 = extractelement <8 x i1> %62, i32 %1258
  %1260 = extractelement <8 x i1> %62, i64 6
  %1261 = and i1 %1257, %1259
  %1262 = and i1 %1260, %1261
  %1263 = extractelement <8 x float> %1177, i32 %1258
  %1264 = select i1 %1262, float %1263, float 0.000000e+00
  %1265 = insertelement <8 x float> %1252, float %1264, i64 6
  %1266 = xor i1 %1262, true
  %1267 = and i1 %1260, %1266
  %1268 = insertelement <8 x i1> %1255, i1 %1267, i64 6
  %1269 = extractelement <8 x i32> %.spill.load242, i64 7
  %1270 = icmp ult i32 %1269, 8
  %1271 = select i1 %1270, i32 %1269, i32 0
  %1272 = extractelement <8 x i1> %62, i32 %1271
  %1273 = extractelement <8 x i1> %62, i64 7
  %1274 = and i1 %1270, %1272
  %1275 = and i1 %1273, %1274
  %1276 = extractelement <8 x float> %1177, i32 %1271
  %1277 = select i1 %1275, float %1276, float 0.000000e+00
  %1278 = insertelement <8 x float> %1265, float %1277, i64 7
  %1279 = xor i1 %1275, true
  %1280 = and i1 %1273, %1279
  %1281 = insertelement <8 x i1> %1268, i1 %1280, i64 7
  %1282 = fadd <8 x float> %1177, %1278
  %1283 = extractelement <8 x i1> %62, i32 0
  %1284 = extractelement <8 x i1> %62, i64 0
  %1285 = and i1 true, %1283
  %1286 = and i1 %1284, %1285
  %1287 = extractelement <8 x float> %1282, i32 0
  %1288 = select i1 %1286, float %1287, float 0.000000e+00
  %1289 = insertelement <8 x float> poison, float %1288, i64 0
  %1290 = xor i1 %1286, true
  %1291 = and i1 %1284, %1290
  %1292 = insertelement <8 x i1> poison, i1 %1291, i64 0
  %1293 = extractelement <8 x i1> %62, i32 0
  %1294 = extractelement <8 x i1> %62, i64 1
  %1295 = and i1 true, %1293
  %1296 = and i1 %1294, %1295
  %1297 = extractelement <8 x float> %1282, i32 0
  %1298 = select i1 %1296, float %1297, float 0.000000e+00
  %1299 = insertelement <8 x float> %1289, float %1298, i64 1
  %1300 = xor i1 %1296, true
  %1301 = and i1 %1294, %1300
  %1302 = insertelement <8 x i1> %1292, i1 %1301, i64 1
  %1303 = extractelement <8 x i1> %62, i32 0
  %1304 = extractelement <8 x i1> %62, i64 2
  %1305 = and i1 true, %1303
  %1306 = and i1 %1304, %1305
  %1307 = extractelement <8 x float> %1282, i32 0
  %1308 = select i1 %1306, float %1307, float 0.000000e+00
  %1309 = insertelement <8 x float> %1299, float %1308, i64 2
  %1310 = xor i1 %1306, true
  %1311 = and i1 %1304, %1310
  %1312 = insertelement <8 x i1> %1302, i1 %1311, i64 2
  %1313 = extractelement <8 x i1> %62, i32 0
  %1314 = extractelement <8 x i1> %62, i64 3
  %1315 = and i1 true, %1313
  %1316 = and i1 %1314, %1315
  %1317 = extractelement <8 x float> %1282, i32 0
  %1318 = select i1 %1316, float %1317, float 0.000000e+00
  %1319 = insertelement <8 x float> %1309, float %1318, i64 3
  %1320 = xor i1 %1316, true
  %1321 = and i1 %1314, %1320
  %1322 = insertelement <8 x i1> %1312, i1 %1321, i64 3
  %1323 = extractelement <8 x i1> %62, i32 0
  %1324 = extractelement <8 x i1> %62, i64 4
  %1325 = and i1 true, %1323
  %1326 = and i1 %1324, %1325
  %1327 = extractelement <8 x float> %1282, i32 0
  %1328 = select i1 %1326, float %1327, float 0.000000e+00
  %1329 = insertelement <8 x float> %1319, float %1328, i64 4
  %1330 = xor i1 %1326, true
  %1331 = and i1 %1324, %1330
  %1332 = insertelement <8 x i1> %1322, i1 %1331, i64 4
  %1333 = extractelement <8 x i1> %62, i32 0
  %1334 = extractelement <8 x i1> %62, i64 5
  %1335 = and i1 true, %1333
  %1336 = and i1 %1334, %1335
  %1337 = extractelement <8 x float> %1282, i32 0
  %1338 = select i1 %1336, float %1337, float 0.000000e+00
  %1339 = insertelement <8 x float> %1329, float %1338, i64 5
  %1340 = xor i1 %1336, true
  %1341 = and i1 %1334, %1340
  %1342 = insertelement <8 x i1> %1332, i1 %1341, i64 5
  %1343 = extractelement <8 x i1> %62, i32 0
  %1344 = extractelement <8 x i1> %62, i64 6
  %1345 = and i1 true, %1343
  %1346 = and i1 %1344, %1345
  %1347 = extractelement <8 x float> %1282, i32 0
  %1348 = select i1 %1346, float %1347, float 0.000000e+00
  %1349 = insertelement <8 x float> %1339, float %1348, i64 6
  %1350 = xor i1 %1346, true
  %1351 = and i1 %1344, %1350
  %1352 = insertelement <8 x i1> %1342, i1 %1351, i64 6
  %1353 = extractelement <8 x i1> %62, i32 0
  %1354 = extractelement <8 x i1> %62, i64 7
  %1355 = and i1 true, %1353
  %1356 = and i1 %1354, %1355
  %1357 = extractelement <8 x float> %1282, i32 0
  %1358 = select i1 %1356, float %1357, float 0.000000e+00
  %1359 = insertelement <8 x float> %1349, float %1358, i64 7
  %1360 = xor i1 %1356, true
  %1361 = and i1 %1354, %1360
  %1362 = insertelement <8 x i1> %1352, i1 %1361, i64 7
  %1363 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %1364 = bitcast <8 x i1> %62 to i8
  %1365 = call i8 @llvm.cttz.i8(i8 %1364, i1 false)
  %1366 = zext i8 %1365 to i32
  %1367 = select i1 %1363, i32 %1366, i32 0
  %1368 = extractelement <8 x float> %1359, i32 %1367
  %.spill.load243 = load float, ptr %.spill36, align 4
  %1369 = fadd float %.spill.load243, %1368
  store float %1369, ptr %.spill44, align 4
  store i64 0, ptr %.slot45, align 4
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state244 = load i64, ptr %.slot45, align 4
  %1370 = icmp slt i64 %.state244, 512
  br i1 %1370, label %direct.true245, label %direct.false246

direct.schedule.23:                               ; preds = %direct.true245
  %.state247 = load i64, ptr %.slot45, align 4
  %1371 = mul i64 %.state247, 8
  %.splatinsert248 = insertelement <8 x i64> poison, i64 %1371, i64 0
  %.splat249 = shufflevector <8 x i64> %.splatinsert248, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load250 = load <8 x i64>, ptr %.spill, align 64
  %1372 = add <8 x i64> %.splat249, %.spill.load250
  %.spill.load251 = load <8 x i64>, ptr %.spill17, align 64
  %1373 = add <8 x i64> %.spill.load251, zeroinitializer
  %1374 = add <8 x i64> zeroinitializer, %1373
  %1375 = add <8 x i64> zeroinitializer, %1372
  %1376 = mul <8 x i64> %1374, splat (i64 4096)
  %1377 = add <8 x i64> %1376, %1375
  %tile_snapshot.spill.load252 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill37, align 64
  %1378 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load252, 0
  %1379 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load252, 1
  %.state253 = load i64, ptr %.slot45, align 4
  %.splatinsert254 = insertelement <8 x i64> poison, i64 %.state253, i64 0
  %.splat255 = shufflevector <8 x i64> %.splatinsert254, <8 x i64> poison, <8 x i32> zeroinitializer
  %1380 = mul <8 x i64> %.splat255, splat (i64 32)
  %1381 = add <8 x i64> %1379, %1380
  %1382 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1378, 0
  %1383 = insertvalue { <8 x ptr>, <8 x i64> } %1382, <8 x i64> %1381, 1
  %1384 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1385 = extractvalue { <8 x ptr>, <8 x i64> } %1383, 1
  %1386 = extractelement <8 x ptr> %1384, i32 0
  %1387 = extractelement <8 x i64> %1385, i32 0
  %1388 = sub i64 %1387, 0
  %1389 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %1390 = select i1 %1389, i64 %1388, i64 0
  %private.contiguous.address256 = getelementptr i8, ptr %1386, i64 %1390
  %private.contiguous.load257 = load <8 x float>, ptr %private.contiguous.address256, align 4
  %1391 = select <8 x i1> %62, <8 x float> %private.contiguous.load257, <8 x float> zeroinitializer
  %.spill.load258 = load float, ptr %.spill44, align 4
  %.splatinsert259 = insertelement <8 x float> poison, float %.spill.load258, i64 0
  %.splat260 = shufflevector <8 x float> %.splatinsert259, <8 x float> poison, <8 x i32> zeroinitializer
  %1392 = fdiv <8 x float> %1391, %.splat260
  %1393 = extractvalue { ptr, i64 } %38, 0
  %1394 = extractelement <8 x i64> %1377, i32 0
  %1395 = sub i64 %1394, 0
  %1396 = mul i64 %1395, 4
  %buffer.contiguous.address261 = getelementptr i8, ptr %1393, i64 %1396
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1392, ptr %buffer.contiguous.address261, i32 1, <8 x i1> %62)
  %.state262 = load i64, ptr %.slot45, align 4
  %1397 = add i64 %.state262, 1
  store i64 %1397, ptr %.slot45, align 4
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false246
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true65:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false66:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true80:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false81:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true94:                                    ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false95:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true129:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false130:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true167:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false168:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true205:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false206:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true245:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false246:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #4 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

@convergence.targets = private unnamed_addr constant [5 x i32] [i32 5, i32 8, i32 10, i32 13, i32 15], align 4

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %live.mask = alloca <8 x i1>, align 1
  %runnable.mask = alloca <8 x i1>, align 1
  %ready.count = alloca i32, align 4
  %ready.mask = alloca [8 x <8 x i1>], align 1
  %ready.target = alloca [8 x i32], align 4
  %ready.token = alloca [8 x i32], align 4
  %current.mask = alloca <8 x i1>, align 1
  %current.token = alloca i32, align 4
  %frame.active = alloca i8, align 1
  %frame.static.id = alloca <8 x i32>, align 32
  %frame.parent.token = alloca <8 x i32>, align 32
  %frame.expected = alloca [8 x <8 x i1>], align 1
  %frame.arrived = alloca [8 x <8 x i1>], align 1
  store <8 x i1> zeroinitializer, ptr %live.mask, align 1
  store <8 x i1> zeroinitializer, ptr %runnable.mask, align 1
  store i32 0, ptr %ready.count, align 4
  store [8 x <8 x i1>] zeroinitializer, ptr %ready.mask, align 1
  store [8 x i32] zeroinitializer, ptr %ready.target, align 4
  store [8 x i32] zeroinitializer, ptr %ready.token, align 4
  store <8 x i1> zeroinitializer, ptr %current.mask, align 1
  store i32 0, ptr %current.token, align 4
  store i8 0, ptr %frame.active, align 1
  store <8 x i32> zeroinitializer, ptr %frame.static.id, align 32
  store <8 x i32> zeroinitializer, ptr %frame.parent.token, align 32
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.expected, align 1
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.arrived, align 1
  %tile_snapshot.local = alloca [288 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [288 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot, align 64
  %.spill5 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill5, align 1
  %.spill6 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill6, align 4
  %tile_snapshot.spill7 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill7, align 64
  %.slot8 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot8, align 64
  %.slot9 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot9, align 64
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert10 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat11 = shufflevector <8 x i32> %.splatinsert10, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat11, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert12 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat13 = shufflevector <8 x i32> %.splatinsert12, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat13, %41
  %44 = mul i32 %32, 1
  %.splatinsert14 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat15 = shufflevector <8 x i32> %.splatinsert14, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat15, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert16 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat17 = shufflevector <8 x i32> %.splatinsert16, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat17, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert18 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat19 = shufflevector <8 x i32> %.splatinsert18, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat19
  store <8 x i1> %51, ptr %live.mask, align 1
  %52 = load i32, ptr %current.token, align 4
  %53 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %54 = load i32, ptr %ready.count, align 4
  %55 = icmp uge i32 %54, 8
  %56 = and i1 %53, %55
  br i1 %56, label %ready.overflow.trap, label %ready.overflow.resume

ready.overflow.trap:                              ; preds = %prologue
  call void @llvm.trap()
  unreachable

ready.overflow.resume:                            ; preds = %prologue
  %57 = select i1 %53, i32 %54, i32 0
  %58 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %57
  %59 = load <8 x i1>, ptr %58, align 1
  %60 = select i1 %53, <8 x i1> %51, <8 x i1> %59
  store <8 x i1> %60, ptr %58, align 1
  %61 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %57
  %62 = load i32, ptr %61, align 4
  %63 = select i1 %53, i32 0, i32 %62
  store i32 %63, ptr %61, align 4
  %64 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %57
  %65 = load i32, ptr %64, align 4
  %66 = select i1 %53, i32 %52, i32 %65
  store i32 %66, ptr %64, align 4
  %67 = add i32 %54, 1
  %68 = select i1 %53, i32 %67, i32 %54
  store i32 %68, ptr %ready.count, align 4
  %69 = load <8 x i1>, ptr %runnable.mask, align 1
  %70 = or <8 x i1> %69, %51
  store <8 x i1> %70, ptr %runnable.mask, align 1
  br label %scheduler.loop

scheduler.loop:                                   ; preds = %return.frame.cleanup.done, %convergence.cascade.exit183, %schedule.14, %varying.coherent.false169, %varying.coherent.true168, %ready.overflow.resume167, %convergence.cascade.exit143, %schedule.12, %varying.coherent.false129, %varying.coherent.true128, %ready.overflow.resume127, %convergence.target.10.ready, %convergence.cascade.exit103, %schedule.9, %varying.coherent.false94, %varying.coherent.true93, %ready.overflow.resume92, %convergence.cascade.exit68, %schedule.7, %varying.coherent.false58, %varying.coherent.true57, %ready.overflow.resume56, %convergence.target.5.ready, %convergence.cascade.exit, %schedule.4, %varying.coherent.false, %varying.coherent.true, %ready.overflow.resume34, %schedule.2, %uniform.false, %uniform.true, %schedule.0, %ready.overflow.resume
  %71 = load i32, ptr %ready.count, align 4
  %72 = icmp ne i32 %71, 0
  br i1 %72, label %scheduler.dispatch, label %scheduler.done

scheduler.dispatch:                               ; preds = %scheduler.loop
  %73 = sub i32 %71, 1
  store i32 %73, ptr %ready.count, align 4
  %74 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %73
  %75 = load <8 x i1>, ptr %74, align 1
  store <8 x i1> %75, ptr %current.mask, align 1
  %76 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %73
  %77 = load i32, ptr %76, align 4
  %78 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %73
  %79 = load i32, ptr %78, align 4
  store i32 %79, ptr %current.token, align 4
  %80 = load <8 x i1>, ptr %runnable.mask, align 1
  %81 = xor <8 x i1> %75, splat (i1 true)
  %82 = and <8 x i1> %80, %81
  store <8 x i1> %82, ptr %runnable.mask, align 1
  br label %scheduler.dispatch.route

scheduler.dispatch.route:                         ; preds = %scheduler.dispatch
  %scheduler.dispatch.pc = phi i32 [ %77, %scheduler.dispatch ]
  switch i32 %scheduler.dispatch.pc, label %scheduler.invalid [
    i32 0, label %schedule.0
    i32 1, label %schedule.1
    i32 2, label %schedule.2
    i32 3, label %schedule.3
    i32 4, label %schedule.4
    i32 5, label %schedule.5
    i32 6, label %schedule.6
    i32 7, label %schedule.7
    i32 8, label %schedule.8
    i32 9, label %schedule.9
    i32 10, label %schedule.10
    i32 11, label %schedule.11
    i32 12, label %schedule.12
    i32 13, label %schedule.13
    i32 14, label %schedule.14
    i32 15, label %schedule.15
  ]

scheduler.done:                                   ; preds = %scheduler.loop
  %83 = load <8 x i1>, ptr %live.mask, align 1
  %84 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %83)
  br i1 %84, label %scheduler.stalled, label %scheduler.exit

scheduler.exit:                                   ; preds = %scheduler.done
  ret void

scheduler.stalled:                                ; preds = %scheduler.done
  call void @llvm.trap()
  unreachable

scheduler.invalid:                                ; preds = %scheduler.dispatch.route
  call void @llvm.trap()
  unreachable

schedule.0:                                       ; preds = %scheduler.dispatch.route
  %85 = load <8 x i1>, ptr %current.mask, align 1
  %86 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %85)
  %87 = bitcast <8 x i1> %85 to i8
  %88 = call i8 @llvm.cttz.i8(i8 %87, i1 false)
  %89 = zext i8 %88 to i32
  %90 = select i1 %86, i32 %89, i32 0
  %91 = extractvalue [3 x <8 x i32>] %50, 0
  %92 = load <8 x i64>, ptr %.spill, align 64
  %93 = select <8 x i1> %85, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %92
  store <8 x i64> %93, ptr %.spill, align 64
  %94 = sub <8 x i32> %91, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %95 = select <8 x i1> %85, <8 x i32> %94, <8 x i32> zeroinitializer
  %96 = select <8 x i1> %85, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %97 = lshr <8 x i32> %95, %96
  %98 = zext <8 x i32> %97 to <8 x i64>
  %99 = select <8 x i1> %85, <8 x i64> %98, <8 x i64> zeroinitializer
  %100 = select <8 x i1> %85, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %101 = sdiv <8 x i64> %99, %100
  %102 = load <8 x i64>, ptr %.spill4, align 64
  %103 = select <8 x i1> %85, <8 x i64> %101, <8 x i64> %102
  store <8 x i64> %103, ptr %.spill4, align 64
  %104 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %105 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %106 = extractvalue { <8 x ptr>, <8 x i64> } %104, 0
  %107 = select <8 x i1> %85, <8 x ptr> %105, <8 x ptr> %106
  %108 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %104, 1
  %110 = select <8 x i1> %85, <8 x i64> %108, <8 x i64> %109
  %111 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %107, 0
  %112 = insertvalue { <8 x ptr>, <8 x i64> } %111, <8 x i64> %110, 1
  store { <8 x ptr>, <8 x i64> } %112, ptr %tile_snapshot.spill, align 64
  %113 = load <8 x i64>, ptr %.slot, align 64
  %114 = select <8 x i1> %85, <8 x i64> zeroinitializer, <8 x i64> %113
  store <8 x i64> %114, ptr %.slot, align 64
  store <8 x i1> %85, ptr %current.mask, align 1
  %115 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %85)
  br i1 %115, label %schedule.1, label %scheduler.loop

schedule.1:                                       ; preds = %schedule.2, %schedule.0, %scheduler.dispatch.route
  %116 = load <8 x i1>, ptr %current.mask, align 1
  %117 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %116)
  %118 = bitcast <8 x i1> %116 to i8
  %119 = call i8 @llvm.cttz.i8(i8 %118, i1 false)
  %120 = zext i8 %119 to i32
  %121 = select i1 %117, i32 %120, i32 0
  %.state = load <8 x i64>, ptr %.slot, align 64
  %122 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %116)
  %123 = bitcast <8 x i1> %116 to i8
  %124 = call i8 @llvm.cttz.i8(i8 %123, i1 false)
  %125 = zext i8 %124 to i32
  %126 = select i1 %122, i32 %125, i32 0
  %127 = extractelement <8 x i64> %.state, i32 %126
  %128 = icmp slt i64 %127, 8
  br i1 %128, label %uniform.true, label %uniform.false

schedule.2:                                       ; preds = %uniform.true, %scheduler.dispatch.route
  %129 = load <8 x i1>, ptr %current.mask, align 1
  %130 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %129)
  %131 = bitcast <8 x i1> %129 to i8
  %132 = call i8 @llvm.cttz.i8(i8 %131, i1 false)
  %133 = zext i8 %132 to i32
  %134 = select i1 %130, i32 %133, i32 0
  %.state20 = load <8 x i64>, ptr %.slot, align 64
  %135 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %129)
  %136 = bitcast <8 x i1> %129 to i8
  %137 = call i8 @llvm.cttz.i8(i8 %136, i1 false)
  %138 = zext i8 %137 to i32
  %139 = select i1 %135, i32 %138, i32 0
  %140 = extractelement <8 x i64> %.state20, i32 %139
  %141 = mul i64 %140, 8
  %.splatinsert21 = insertelement <8 x i64> poison, i64 %141, i64 0
  %.splat22 = shufflevector <8 x i64> %.splatinsert21, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %142 = add <8 x i64> %.splat22, %.spill.load
  %.spill.load23 = load <8 x i64>, ptr %.spill4, align 64
  %143 = add <8 x i64> %.spill.load23, zeroinitializer
  %144 = add <8 x i64> zeroinitializer, %143
  %145 = add <8 x i64> zeroinitializer, %142
  %146 = mul <8 x i64> %144, splat (i64 66)
  %147 = add <8 x i64> %146, %145
  %148 = extractvalue { ptr, i64 } %9, 0
  %149 = extractelement <8 x i64> %147, i32 %134
  %150 = zext i32 %134 to i64
  %151 = sub i64 %149, %150
  %152 = mul i64 %151, 4
  %buffer.contiguous.address = getelementptr i8, ptr %148, i64 %152
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %129, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %154 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state24 = load <8 x i64>, ptr %.slot, align 64
  %155 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %129)
  %156 = bitcast <8 x i1> %129 to i8
  %157 = call i8 @llvm.cttz.i8(i8 %156, i1 false)
  %158 = zext i8 %157 to i32
  %159 = select i1 %155, i32 %158, i32 0
  %160 = extractelement <8 x i64> %.state24, i32 %159
  %.splatinsert25 = insertelement <8 x i64> poison, i64 %160, i64 0
  %.splat26 = shufflevector <8 x i64> %.splatinsert25, <8 x i64> poison, <8 x i32> zeroinitializer
  %161 = mul <8 x i64> %.splat26, splat (i64 32)
  %162 = add <8 x i64> %154, %161
  %163 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %153, 0
  %164 = insertvalue { <8 x ptr>, <8 x i64> } %163, <8 x i64> %162, 1
  %165 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %164, 1
  %167 = extractelement <8 x ptr> %165, i32 0
  %168 = extractelement <8 x i64> %166, i32 %134
  %169 = zext i32 %134 to i64
  %170 = mul i64 %169, 4
  %171 = sub i64 %168, %170
  %172 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %129)
  %173 = select i1 %172, i64 %171, i64 0
  %private.contiguous.address = getelementptr i8, ptr %167, i64 %173
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %174 = select <8 x i1> %129, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %174, ptr %private.contiguous.address, align 4
  %.state27 = load <8 x i64>, ptr %.slot, align 64
  %175 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %129)
  %176 = bitcast <8 x i1> %129 to i8
  %177 = call i8 @llvm.cttz.i8(i8 %176, i1 false)
  %178 = zext i8 %177 to i32
  %179 = select i1 %175, i32 %178, i32 0
  %180 = extractelement <8 x i64> %.state27, i32 %179
  %181 = add i64 %180, 1
  %.splatinsert28 = insertelement <8 x i64> poison, i64 %181, i64 0
  %.splat29 = shufflevector <8 x i64> %.splatinsert28, <8 x i64> poison, <8 x i32> zeroinitializer
  %182 = load <8 x i64>, ptr %.slot, align 64
  %183 = select <8 x i1> %129, <8 x i64> %.splat29, <8 x i64> %182
  store <8 x i64> %183, ptr %.slot, align 64
  store <8 x i1> %129, ptr %current.mask, align 1
  %184 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %129)
  br i1 %184, label %schedule.1, label %scheduler.loop

schedule.3:                                       ; preds = %uniform.false, %scheduler.dispatch.route
  %185 = load <8 x i1>, ptr %current.mask, align 1
  %186 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %185)
  %187 = bitcast <8 x i1> %185 to i8
  %188 = call i8 @llvm.cttz.i8(i8 %187, i1 false)
  %189 = zext i8 %188 to i32
  %190 = select i1 %186, i32 %189, i32 0
  %.spill.load30 = load <8 x i64>, ptr %.spill, align 64
  %191 = icmp slt <8 x i64> %.spill.load30, splat (i64 2)
  %192 = load <8 x i1>, ptr %.spill5, align 1
  %193 = select <8 x i1> %185, <8 x i1> %191, <8 x i1> %192
  store <8 x i1> %193, ptr %.spill5, align 1
  %194 = and <8 x i1> %185, %191
  %195 = xor <8 x i1> %191, splat (i1 true)
  %196 = and <8 x i1> %185, %195
  %197 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %194)
  %198 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %196)
  %199 = and i1 %197, %198
  br i1 %199, label %varying.divergent, label %varying.coherent

schedule.4:                                       ; preds = %varying.coherent.true, %scheduler.dispatch.route
  %200 = load <8 x i1>, ptr %current.mask, align 1
  %201 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %200)
  %202 = bitcast <8 x i1> %200 to i8
  %203 = call i8 @llvm.cttz.i8(i8 %202, i1 false)
  %204 = zext i8 %203 to i32
  %205 = select i1 %201, i32 %204, i32 0
  %.spill.load35 = load <8 x i64>, ptr %.spill, align 64
  %206 = add <8 x i64> splat (i64 64), %.spill.load35
  %.spill.load36 = load <8 x i64>, ptr %.spill4, align 64
  %207 = add <8 x i64> %.spill.load36, zeroinitializer
  %208 = add <8 x i64> zeroinitializer, %207
  %209 = add <8 x i64> zeroinitializer, %206
  %210 = mul <8 x i64> %208, splat (i64 66)
  %211 = add <8 x i64> %210, %209
  %212 = extractvalue { ptr, i64 } %9, 0
  %213 = extractelement <8 x i64> %211, i32 %205
  %214 = zext i32 %205 to i64
  %215 = sub i64 %213, %214
  %216 = mul i64 %215, 4
  %buffer.contiguous.address37 = getelementptr i8, ptr %212, i64 %216
  %buffer.contiguous.load38 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address37, i32 1, <8 x i1> %200, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load39 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %217 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load39, 0
  %218 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load39, 1
  %219 = add <8 x i64> %218, splat (i64 256)
  %220 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %217, 0
  %221 = insertvalue { <8 x ptr>, <8 x i64> } %220, <8 x i64> %219, 1
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %221, 1
  %224 = extractelement <8 x ptr> %222, i32 0
  %225 = extractelement <8 x i64> %223, i32 %205
  %226 = zext i32 %205 to i64
  %227 = mul i64 %226, 4
  %228 = sub i64 %225, %227
  %229 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %200)
  %230 = select i1 %229, i64 %228, i64 0
  %private.contiguous.address40 = getelementptr i8, ptr %224, i64 %230
  %private.contiguous.preserve41 = load <8 x float>, ptr %private.contiguous.address40, align 4
  %231 = select <8 x i1> %200, <8 x float> %buffer.contiguous.load38, <8 x float> %private.contiguous.preserve41
  store <8 x float> %231, ptr %private.contiguous.address40, align 4
  store <8 x i1> %200, ptr %current.mask, align 1
  %232 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %200)
  br i1 %232, label %schedule.5, label %scheduler.loop

schedule.5:                                       ; preds = %schedule.4, %varying.coherent.false, %scheduler.dispatch.route
  %233 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token = load i32, ptr %current.token, align 4
  %convergence.token.present = icmp ne i32 %convergence.current.token, 0
  br i1 %convergence.token.present, label %convergence.cascade, label %convergence.cascade.exit

schedule.6:                                       ; preds = %schedule.7, %convergence.target.5.ready, %scheduler.dispatch.route
  %234 = load <8 x i1>, ptr %current.mask, align 1
  %235 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %234)
  %236 = bitcast <8 x i1> %234 to i8
  %237 = call i8 @llvm.cttz.i8(i8 %236, i1 false)
  %238 = zext i8 %237 to i32
  %239 = select i1 %235, i32 %238, i32 0
  %.state48 = load <8 x i64>, ptr %.slot8, align 64
  %240 = icmp slt <8 x i64> %.state48, splat (i64 8)
  %241 = and <8 x i1> %234, %240
  %242 = xor <8 x i1> %240, splat (i1 true)
  %243 = and <8 x i1> %234, %242
  %244 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %241)
  %245 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %243)
  %246 = and i1 %244, %245
  br i1 %246, label %varying.divergent49, label %varying.coherent50

schedule.7:                                       ; preds = %varying.coherent.true57, %scheduler.dispatch.route
  %247 = load <8 x i1>, ptr %current.mask, align 1
  %248 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %247)
  %249 = bitcast <8 x i1> %247 to i8
  %250 = call i8 @llvm.cttz.i8(i8 %249, i1 false)
  %251 = zext i8 %250 to i32
  %252 = select i1 %248, i32 %251, i32 0
  %.state59 = load <8 x i64>, ptr %.slot8, align 64
  %253 = mul <8 x i64> %.state59, splat (i64 8)
  %.spill.load60 = load <8 x i64>, ptr %.spill, align 64
  %254 = add <8 x i64> %253, %.spill.load60
  %.spill.load61 = load <8 x i64>, ptr %.spill4, align 64
  %255 = add <8 x i64> %.spill.load61, zeroinitializer
  %256 = add <8 x i64> zeroinitializer, %255
  %257 = add <8 x i64> zeroinitializer, %254
  %258 = mul <8 x i64> %256, splat (i64 66)
  %259 = add <8 x i64> %258, %257
  %260 = extractvalue { ptr, i64 } %15, 0
  %261 = extractelement <8 x i64> %259, i32 %252
  %262 = zext i32 %252 to i64
  %263 = sub i64 %261, %262
  %264 = mul i64 %263, 4
  %buffer.contiguous.address62 = getelementptr i8, ptr %260, i64 %264
  %buffer.contiguous.load63 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address62, i32 1, <8 x i1> %247, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load64 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill7, align 64
  %265 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 0
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 1
  %.state65 = load <8 x i64>, ptr %.slot8, align 64
  %267 = mul <8 x i64> %.state65, splat (i64 32)
  %268 = add <8 x i64> %266, %267
  %269 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %265, 0
  %270 = insertvalue { <8 x ptr>, <8 x i64> } %269, <8 x i64> %268, 1
  %271 = extractvalue { <8 x ptr>, <8 x i64> } %270, 0
  %272 = extractvalue { <8 x ptr>, <8 x i64> } %270, 1
  %273 = getelementptr i8, <8 x ptr> %271, <8 x i64> %272
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %buffer.contiguous.load63, <8 x ptr> %273, i32 1, <8 x i1> %247)
  %.state66 = load <8 x i64>, ptr %.slot8, align 64
  %274 = add <8 x i64> %.state66, splat (i64 1)
  %275 = load <8 x i64>, ptr %.slot8, align 64
  %276 = select <8 x i1> %247, <8 x i64> %274, <8 x i64> %275
  store <8 x i64> %276, ptr %.slot8, align 64
  store <8 x i1> %247, ptr %current.mask, align 1
  %277 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %247)
  br i1 %277, label %schedule.6, label %scheduler.loop

schedule.8:                                       ; preds = %varying.coherent.false58, %scheduler.dispatch.route
  %278 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token69 = load i32, ptr %current.token, align 4
  %convergence.token.present70 = icmp ne i32 %convergence.current.token69, 0
  br i1 %convergence.token.present70, label %convergence.cascade67, label %convergence.cascade.exit68

schedule.9:                                       ; preds = %varying.coherent.true93, %scheduler.dispatch.route
  %279 = load <8 x i1>, ptr %current.mask, align 1
  %280 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %279)
  %281 = bitcast <8 x i1> %279 to i8
  %282 = call i8 @llvm.cttz.i8(i8 %281, i1 false)
  %283 = zext i8 %282 to i32
  %284 = select i1 %280, i32 %283, i32 0
  %.spill.load95 = load <8 x i64>, ptr %.spill, align 64
  %285 = add <8 x i64> splat (i64 64), %.spill.load95
  %.spill.load96 = load <8 x i64>, ptr %.spill4, align 64
  %286 = add <8 x i64> %.spill.load96, zeroinitializer
  %287 = add <8 x i64> zeroinitializer, %286
  %288 = add <8 x i64> zeroinitializer, %285
  %289 = mul <8 x i64> %287, splat (i64 66)
  %290 = add <8 x i64> %289, %288
  %291 = extractvalue { ptr, i64 } %15, 0
  %292 = extractelement <8 x i64> %290, i32 %284
  %293 = zext i32 %284 to i64
  %294 = sub i64 %292, %293
  %295 = mul i64 %294, 4
  %buffer.contiguous.address97 = getelementptr i8, ptr %291, i64 %295
  %buffer.contiguous.load98 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address97, i32 1, <8 x i1> %279, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load99 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill7, align 64
  %296 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load99, 0
  %297 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load99, 1
  %298 = add <8 x i64> %297, splat (i64 256)
  %299 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %296, 0
  %300 = insertvalue { <8 x ptr>, <8 x i64> } %299, <8 x i64> %298, 1
  %301 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %302 = extractvalue { <8 x ptr>, <8 x i64> } %300, 1
  %303 = extractelement <8 x ptr> %301, i32 0
  %304 = extractelement <8 x i64> %302, i32 %284
  %305 = zext i32 %284 to i64
  %306 = mul i64 %305, 4
  %307 = sub i64 %304, %306
  %308 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %279)
  %309 = select i1 %308, i64 %307, i64 0
  %private.contiguous.address100 = getelementptr i8, ptr %303, i64 %309
  %private.contiguous.preserve101 = load <8 x float>, ptr %private.contiguous.address100, align 4
  %310 = select <8 x i1> %279, <8 x float> %buffer.contiguous.load98, <8 x float> %private.contiguous.preserve101
  store <8 x float> %310, ptr %private.contiguous.address100, align 4
  store <8 x i1> %279, ptr %current.mask, align 1
  %311 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %279)
  br i1 %311, label %schedule.10, label %scheduler.loop

schedule.10:                                      ; preds = %schedule.9, %varying.coherent.false94, %scheduler.dispatch.route
  %312 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token104 = load i32, ptr %current.token, align 4
  %convergence.token.present105 = icmp ne i32 %convergence.current.token104, 0
  br i1 %convergence.token.present105, label %convergence.cascade102, label %convergence.cascade.exit103

schedule.11:                                      ; preds = %schedule.12, %convergence.target.10.ready, %scheduler.dispatch.route
  %313 = load <8 x i1>, ptr %current.mask, align 1
  %314 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %313)
  %315 = bitcast <8 x i1> %313 to i8
  %316 = call i8 @llvm.cttz.i8(i8 %315, i1 false)
  %317 = zext i8 %316 to i32
  %318 = select i1 %314, i32 %317, i32 0
  %.state119 = load <8 x i64>, ptr %.slot9, align 64
  %319 = icmp slt <8 x i64> %.state119, splat (i64 8)
  %320 = and <8 x i1> %313, %319
  %321 = xor <8 x i1> %319, splat (i1 true)
  %322 = and <8 x i1> %313, %321
  %323 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %320)
  %324 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %322)
  %325 = and i1 %323, %324
  br i1 %325, label %varying.divergent120, label %varying.coherent121

schedule.12:                                      ; preds = %varying.coherent.true128, %scheduler.dispatch.route
  %326 = load <8 x i1>, ptr %current.mask, align 1
  %327 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %326)
  %328 = bitcast <8 x i1> %326 to i8
  %329 = call i8 @llvm.cttz.i8(i8 %328, i1 false)
  %330 = zext i8 %329 to i32
  %331 = select i1 %327, i32 %330, i32 0
  %.state130 = load <8 x i64>, ptr %.slot9, align 64
  %332 = mul <8 x i64> %.state130, splat (i64 8)
  %.spill.load131 = load <8 x i64>, ptr %.spill, align 64
  %333 = add <8 x i64> %332, %.spill.load131
  %.spill.load132 = load <8 x i64>, ptr %.spill4, align 64
  %334 = add <8 x i64> %.spill.load132, zeroinitializer
  %335 = add <8 x i64> zeroinitializer, %334
  %336 = add <8 x i64> zeroinitializer, %333
  %337 = mul <8 x i64> %335, splat (i64 66)
  %338 = add <8 x i64> %337, %336
  %tile_snapshot.spill.load133 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %339 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load133, 0
  %340 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load133, 1
  %.state134 = load <8 x i64>, ptr %.slot9, align 64
  %341 = mul <8 x i64> %.state134, splat (i64 32)
  %342 = add <8 x i64> %340, %341
  %343 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %339, 0
  %344 = insertvalue { <8 x ptr>, <8 x i64> } %343, <8 x i64> %342, 1
  %345 = extractvalue { <8 x ptr>, <8 x i64> } %344, 0
  %346 = extractvalue { <8 x ptr>, <8 x i64> } %344, 1
  %347 = getelementptr i8, <8 x ptr> %345, <8 x i64> %346
  %348 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %347, i32 1, <8 x i1> %326, <8 x float> zeroinitializer)
  %349 = fneg <8 x float> %348
  %350 = select <8 x i1> %326, <8 x float> %349, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %350)
  %.spill.load135 = load float, ptr %.spill6, align 4
  %.splatinsert136 = insertelement <8 x float> poison, float %.spill.load135, i64 0
  %.splat137 = shufflevector <8 x float> %.splatinsert136, <8 x float> poison, <8 x i32> zeroinitializer
  %351 = fadd <8 x float> %.splat137, %native.exp
  %352 = fdiv <8 x float> %348, %351
  %tile_snapshot.spill.load138 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill7, align 64
  %353 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load138, 0
  %354 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load138, 1
  %.state139 = load <8 x i64>, ptr %.slot9, align 64
  %355 = mul <8 x i64> %.state139, splat (i64 32)
  %356 = add <8 x i64> %354, %355
  %357 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %353, 0
  %358 = insertvalue { <8 x ptr>, <8 x i64> } %357, <8 x i64> %356, 1
  %359 = extractvalue { <8 x ptr>, <8 x i64> } %358, 0
  %360 = extractvalue { <8 x ptr>, <8 x i64> } %358, 1
  %361 = getelementptr i8, <8 x ptr> %359, <8 x i64> %360
  %362 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %361, i32 1, <8 x i1> %326, <8 x float> zeroinitializer)
  %363 = fmul <8 x float> %352, %362
  %364 = extractvalue { ptr, i64 } %27, 0
  %365 = extractelement <8 x i64> %338, i32 %331
  %366 = zext i32 %331 to i64
  %367 = sub i64 %365, %366
  %368 = mul i64 %367, 4
  %buffer.contiguous.address140 = getelementptr i8, ptr %364, i64 %368
  call void @llvm.masked.store.v8f32.p0(<8 x float> %363, ptr %buffer.contiguous.address140, i32 1, <8 x i1> %326)
  %.state141 = load <8 x i64>, ptr %.slot9, align 64
  %369 = add <8 x i64> %.state141, splat (i64 1)
  %370 = load <8 x i64>, ptr %.slot9, align 64
  %371 = select <8 x i1> %326, <8 x i64> %369, <8 x i64> %370
  store <8 x i64> %371, ptr %.slot9, align 64
  store <8 x i1> %326, ptr %current.mask, align 1
  %372 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %326)
  br i1 %372, label %schedule.11, label %scheduler.loop

schedule.13:                                      ; preds = %varying.coherent.false129, %scheduler.dispatch.route
  %373 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token144 = load i32, ptr %current.token, align 4
  %convergence.token.present145 = icmp ne i32 %convergence.current.token144, 0
  br i1 %convergence.token.present145, label %convergence.cascade142, label %convergence.cascade.exit143

schedule.14:                                      ; preds = %varying.coherent.true168, %scheduler.dispatch.route
  %374 = load <8 x i1>, ptr %current.mask, align 1
  %375 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %374)
  %376 = bitcast <8 x i1> %374 to i8
  %377 = call i8 @llvm.cttz.i8(i8 %376, i1 false)
  %378 = zext i8 %377 to i32
  %379 = select i1 %375, i32 %378, i32 0
  %.spill.load170 = load <8 x i64>, ptr %.spill, align 64
  %380 = add <8 x i64> splat (i64 64), %.spill.load170
  %.spill.load171 = load <8 x i64>, ptr %.spill4, align 64
  %381 = add <8 x i64> %.spill.load171, zeroinitializer
  %382 = add <8 x i64> zeroinitializer, %381
  %383 = add <8 x i64> zeroinitializer, %380
  %384 = mul <8 x i64> %382, splat (i64 66)
  %385 = add <8 x i64> %384, %383
  %tile_snapshot.spill.load172 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %386 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load172, 0
  %387 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load172, 1
  %388 = add <8 x i64> %387, splat (i64 256)
  %389 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %386, 0
  %390 = insertvalue { <8 x ptr>, <8 x i64> } %389, <8 x i64> %388, 1
  %391 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %392 = extractvalue { <8 x ptr>, <8 x i64> } %390, 1
  %393 = extractelement <8 x ptr> %391, i32 0
  %394 = extractelement <8 x i64> %392, i32 %379
  %395 = zext i32 %379 to i64
  %396 = mul i64 %395, 4
  %397 = sub i64 %394, %396
  %398 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %374)
  %399 = select i1 %398, i64 %397, i64 0
  %private.contiguous.address173 = getelementptr i8, ptr %393, i64 %399
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address173, align 4
  %400 = select <8 x i1> %374, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %401 = fneg <8 x float> %400
  %402 = select <8 x i1> %374, <8 x float> %401, <8 x float> zeroinitializer
  %native.exp174 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %402)
  %.spill.load175 = load float, ptr %.spill6, align 4
  %.splatinsert176 = insertelement <8 x float> poison, float %.spill.load175, i64 0
  %.splat177 = shufflevector <8 x float> %.splatinsert176, <8 x float> poison, <8 x i32> zeroinitializer
  %403 = fadd <8 x float> %.splat177, %native.exp174
  %404 = fdiv <8 x float> %400, %403
  %tile_snapshot.spill.load178 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill7, align 64
  %405 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load178, 0
  %406 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load178, 1
  %407 = add <8 x i64> %406, splat (i64 256)
  %408 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %405, 0
  %409 = insertvalue { <8 x ptr>, <8 x i64> } %408, <8 x i64> %407, 1
  %410 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %411 = extractvalue { <8 x ptr>, <8 x i64> } %409, 1
  %412 = extractelement <8 x ptr> %410, i32 0
  %413 = extractelement <8 x i64> %411, i32 %379
  %414 = zext i32 %379 to i64
  %415 = mul i64 %414, 4
  %416 = sub i64 %413, %415
  %417 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %374)
  %418 = select i1 %417, i64 %416, i64 0
  %private.contiguous.address179 = getelementptr i8, ptr %412, i64 %418
  %private.contiguous.load180 = load <8 x float>, ptr %private.contiguous.address179, align 4
  %419 = select <8 x i1> %374, <8 x float> %private.contiguous.load180, <8 x float> zeroinitializer
  %420 = fmul <8 x float> %404, %419
  %421 = extractvalue { ptr, i64 } %27, 0
  %422 = extractelement <8 x i64> %385, i32 %379
  %423 = zext i32 %379 to i64
  %424 = sub i64 %422, %423
  %425 = mul i64 %424, 4
  %buffer.contiguous.address181 = getelementptr i8, ptr %421, i64 %425
  call void @llvm.masked.store.v8f32.p0(<8 x float> %420, ptr %buffer.contiguous.address181, i32 1, <8 x i1> %374)
  store <8 x i1> %374, ptr %current.mask, align 1
  %426 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %374)
  br i1 %426, label %schedule.15, label %scheduler.loop

schedule.15:                                      ; preds = %schedule.14, %varying.coherent.false169, %scheduler.dispatch.route
  %427 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token184 = load i32, ptr %current.token, align 4
  %convergence.token.present185 = icmp ne i32 %convergence.current.token184, 0
  br i1 %convergence.token.present185, label %convergence.cascade182, label %convergence.cascade.exit183

uniform.true:                                     ; preds = %schedule.1
  store <8 x i1> %116, ptr %current.mask, align 1
  %428 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %116)
  br i1 %428, label %schedule.2, label %scheduler.loop

uniform.false:                                    ; preds = %schedule.1
  store <8 x i1> %116, ptr %current.mask, align 1
  %429 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %116)
  br i1 %429, label %schedule.3, label %scheduler.loop

varying.divergent:                                ; preds = %schedule.3
  %430 = load i32, ptr %current.token, align 4
  %431 = icmp ne i32 %430, 0
  %432 = sub i32 %430, 1
  %433 = select i1 %431, i32 %432, i32 0
  %434 = load i8, ptr %frame.active, align 1
  %435 = trunc i32 %433 to i8
  %436 = shl i8 1, %435
  %437 = and i8 %434, %436
  %438 = icmp ne i8 %437, 0
  %439 = load <8 x i32>, ptr %frame.static.id, align 32
  %440 = extractelement <8 x i32> %439, i32 %433
  %441 = icmp eq i32 %440, 0
  %442 = and i1 %438, %441
  %443 = and i1 %431, %442
  %444 = xor i1 %443, true
  %445 = and i1 true, %444
  %446 = xor i8 %434, -1
  %447 = icmp ne i8 %446, 0
  %448 = xor i1 %447, true
  %449 = and i1 %445, %448
  br i1 %449, label %convergence.overflow.trap, label %convergence.overflow.resume

varying.coherent:                                 ; preds = %schedule.3
  br i1 %197, label %varying.coherent.true, label %varying.coherent.false

convergence.overflow.trap:                        ; preds = %varying.divergent
  call void @llvm.trap()
  unreachable

convergence.overflow.resume:                      ; preds = %varying.divergent
  %450 = call i8 @llvm.cttz.i8(i8 %446, i1 false)
  %451 = zext i8 %450 to i32
  %452 = select i1 %447, i32 %451, i32 0
  %453 = trunc i32 %452 to i8
  %454 = shl i8 1, %453
  %455 = or i8 %434, %454
  %456 = select i1 %445, i8 %455, i8 %434
  store i8 %456, ptr %frame.active, align 1
  %457 = load <8 x i32>, ptr %frame.static.id, align 32
  %458 = extractelement <8 x i32> %457, i32 %452
  %459 = select i1 %445, i32 0, i32 %458
  %460 = load <8 x i32>, ptr %frame.static.id, align 32
  %461 = insertelement <8 x i32> %460, i32 %459, i32 %452
  store <8 x i32> %461, ptr %frame.static.id, align 32
  %462 = load <8 x i32>, ptr %frame.parent.token, align 32
  %463 = extractelement <8 x i32> %462, i32 %452
  %464 = select i1 %445, i32 %430, i32 %463
  %465 = load <8 x i32>, ptr %frame.parent.token, align 32
  %466 = insertelement <8 x i32> %465, i32 %464, i32 %452
  store <8 x i32> %466, ptr %frame.parent.token, align 32
  %467 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %452
  %468 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %452
  %469 = load <8 x i1>, ptr %467, align 1
  %470 = load <8 x i1>, ptr %468, align 1
  %471 = select i1 %445, <8 x i1> %185, <8 x i1> %469
  store <8 x i1> %471, ptr %467, align 1
  %472 = select i1 %445, <8 x i1> zeroinitializer, <8 x i1> %470
  store <8 x i1> %472, ptr %468, align 1
  %473 = add i32 %452, 1
  %474 = select i1 %443, i32 %430, i32 %473
  %475 = select i1 true, i32 %474, i32 %430
  store i32 %475, ptr %current.token, align 4
  %476 = load i32, ptr %current.token, align 4
  %477 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %194)
  %478 = load i32, ptr %ready.count, align 4
  %479 = icmp uge i32 %478, 8
  %480 = and i1 %477, %479
  br i1 %480, label %ready.overflow.trap31, label %ready.overflow.resume32

ready.overflow.trap31:                            ; preds = %convergence.overflow.resume
  call void @llvm.trap()
  unreachable

ready.overflow.resume32:                          ; preds = %convergence.overflow.resume
  %481 = select i1 %477, i32 %478, i32 0
  %482 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %481
  %483 = load <8 x i1>, ptr %482, align 1
  %484 = select i1 %477, <8 x i1> %194, <8 x i1> %483
  store <8 x i1> %484, ptr %482, align 1
  %485 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %481
  %486 = load i32, ptr %485, align 4
  %487 = select i1 %477, i32 4, i32 %486
  store i32 %487, ptr %485, align 4
  %488 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %481
  %489 = load i32, ptr %488, align 4
  %490 = select i1 %477, i32 %476, i32 %489
  store i32 %490, ptr %488, align 4
  %491 = add i32 %478, 1
  %492 = select i1 %477, i32 %491, i32 %478
  store i32 %492, ptr %ready.count, align 4
  %493 = load <8 x i1>, ptr %runnable.mask, align 1
  %494 = or <8 x i1> %493, %194
  store <8 x i1> %494, ptr %runnable.mask, align 1
  %495 = load i32, ptr %current.token, align 4
  %496 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %196)
  %497 = load i32, ptr %ready.count, align 4
  %498 = icmp uge i32 %497, 8
  %499 = and i1 %496, %498
  br i1 %499, label %ready.overflow.trap33, label %ready.overflow.resume34

ready.overflow.trap33:                            ; preds = %ready.overflow.resume32
  call void @llvm.trap()
  unreachable

ready.overflow.resume34:                          ; preds = %ready.overflow.resume32
  %500 = select i1 %496, i32 %497, i32 0
  %501 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %500
  %502 = load <8 x i1>, ptr %501, align 1
  %503 = select i1 %496, <8 x i1> %196, <8 x i1> %502
  store <8 x i1> %503, ptr %501, align 1
  %504 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %500
  %505 = load i32, ptr %504, align 4
  %506 = select i1 %496, i32 5, i32 %505
  store i32 %506, ptr %504, align 4
  %507 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %500
  %508 = load i32, ptr %507, align 4
  %509 = select i1 %496, i32 %495, i32 %508
  store i32 %509, ptr %507, align 4
  %510 = add i32 %497, 1
  %511 = select i1 %496, i32 %510, i32 %497
  store i32 %511, ptr %ready.count, align 4
  %512 = load <8 x i1>, ptr %runnable.mask, align 1
  %513 = or <8 x i1> %512, %196
  store <8 x i1> %513, ptr %runnable.mask, align 1
  br label %scheduler.loop

varying.coherent.true:                            ; preds = %varying.coherent
  store <8 x i1> %185, ptr %current.mask, align 1
  %514 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %185)
  br i1 %514, label %schedule.4, label %scheduler.loop

varying.coherent.false:                           ; preds = %varying.coherent
  store <8 x i1> %185, ptr %current.mask, align 1
  %515 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %185)
  br i1 %515, label %schedule.5, label %scheduler.loop

convergence.cascade:                              ; preds = %convergence.cascade, %schedule.5
  %convergence.cascade.flow = phi <8 x i1> [ %233, %schedule.5 ], [ %558, %convergence.cascade ]
  %convergence.cascade.depth = phi i32 [ 0, %schedule.5 ], [ %559, %convergence.cascade ]
  %516 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow)
  %517 = load i32, ptr %current.token, align 4
  %518 = icmp ne i32 %517, 0
  %519 = and i1 %516, %518
  %520 = sub i32 %517, 1
  %521 = select i1 %519, i32 %520, i32 0
  %522 = load i8, ptr %frame.active, align 1
  %523 = trunc i32 %521 to i8
  %524 = shl i8 1, %523
  %525 = and i8 %522, %524
  %526 = icmp ne i8 %525, 0
  %527 = load <8 x i32>, ptr %frame.static.id, align 32
  %528 = extractelement <8 x i32> %527, i32 %521
  %convergence.target.pointer = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %528
  %convergence.dynamic.target = load i32, ptr %convergence.target.pointer, align 4
  %529 = icmp eq i32 %convergence.dynamic.target, 5
  %530 = and i1 %526, %529
  %531 = and i1 %519, %530
  %532 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %521
  %533 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %521
  %534 = load <8 x i1>, ptr %532, align 1
  %535 = load <8 x i1>, ptr %533, align 1
  %536 = or <8 x i1> %535, %convergence.cascade.flow
  %537 = load <8 x i1>, ptr %live.mask, align 1
  %538 = and <8 x i1> %534, %537
  %539 = icmp eq <8 x i1> %536, %538
  %540 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %539)
  %541 = and i1 %531, %540
  %542 = select i1 %541, <8 x i1> zeroinitializer, <8 x i1> %536
  %543 = select i1 %531, <8 x i1> %542, <8 x i1> %535
  store <8 x i1> %543, ptr %533, align 1
  %544 = select i1 %541, <8 x i1> zeroinitializer, <8 x i1> %534
  store <8 x i1> %544, ptr %532, align 1
  %545 = trunc i32 %521 to i8
  %546 = shl i8 1, %545
  %547 = xor i8 %546, -1
  %548 = and i8 %522, %547
  %549 = select i1 %541, i8 %548, i8 %522
  store i8 %549, ptr %frame.active, align 1
  %.splatinsert42 = insertelement <8 x i1> poison, i1 %531, i64 0
  %.splat43 = shufflevector <8 x i1> %.splatinsert42, <8 x i1> poison, <8 x i32> zeroinitializer
  %550 = and <8 x i1> %convergence.cascade.flow, %.splat43
  %551 = load <8 x i1>, ptr %runnable.mask, align 1
  %552 = xor <8 x i1> %550, splat (i1 true)
  %553 = and <8 x i1> %551, %552
  store <8 x i1> %553, ptr %runnable.mask, align 1
  %.splatinsert44 = insertelement <8 x i1> poison, i1 %541, i64 0
  %.splat45 = shufflevector <8 x i1> %.splatinsert44, <8 x i1> poison, <8 x i32> zeroinitializer
  %554 = select <8 x i1> %.splat45, <8 x i1> %536, <8 x i1> zeroinitializer
  %555 = load <8 x i32>, ptr %frame.parent.token, align 32
  %556 = extractelement <8 x i32> %555, i32 %521
  %557 = select i1 %541, i32 %556, i32 %517
  store i32 %557, ptr %current.token, align 4
  %.splatinsert46 = insertelement <8 x i1> poison, i1 %531, i64 0
  %.splat47 = shufflevector <8 x i1> %.splatinsert46, <8 x i1> poison, <8 x i32> zeroinitializer
  %558 = select <8 x i1> %.splat47, <8 x i1> %554, <8 x i1> %convergence.cascade.flow
  %559 = add i32 %convergence.cascade.depth, 1
  %560 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %558)
  %561 = icmp ult i32 %559, 8
  %562 = and i1 %560, %561
  %563 = and i1 %531, %562
  %convergence.parent.token = load i32, ptr %current.token, align 4
  %convergence.parent.present = icmp ne i32 %convergence.parent.token, 0
  %564 = and i1 %563, %convergence.parent.present
  br i1 %564, label %convergence.cascade, label %convergence.cascade.exit

convergence.cascade.exit:                         ; preds = %convergence.cascade, %schedule.5
  %convergence.cascade.result = phi <8 x i1> [ %233, %schedule.5 ], [ %558, %convergence.cascade ]
  %565 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %565, label %convergence.target.5.ready, label %scheduler.loop

convergence.target.5.ready:                       ; preds = %convergence.cascade.exit
  %566 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %567 = bitcast <8 x i1> %convergence.cascade.result to i8
  %568 = call i8 @llvm.cttz.i8(i8 %567, i1 false)
  %569 = zext i8 %568 to i32
  %570 = select i1 %566, i32 %569, i32 0
  store float 1.000000e+00, ptr %.spill6, align 4
  %571 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill7, align 64
  %572 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %573 = extractvalue { <8 x ptr>, <8 x i64> } %571, 0
  %574 = select <8 x i1> %convergence.cascade.result, <8 x ptr> %572, <8 x ptr> %573
  %575 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %576 = extractvalue { <8 x ptr>, <8 x i64> } %571, 1
  %577 = select <8 x i1> %convergence.cascade.result, <8 x i64> %575, <8 x i64> %576
  %578 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %574, 0
  %579 = insertvalue { <8 x ptr>, <8 x i64> } %578, <8 x i64> %577, 1
  store { <8 x ptr>, <8 x i64> } %579, ptr %tile_snapshot.spill7, align 64
  %580 = load <8 x i64>, ptr %.slot8, align 64
  %581 = select <8 x i1> %convergence.cascade.result, <8 x i64> zeroinitializer, <8 x i64> %580
  store <8 x i64> %581, ptr %.slot8, align 64
  store <8 x i1> %convergence.cascade.result, ptr %current.mask, align 1
  %582 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %582, label %schedule.6, label %scheduler.loop

varying.divergent49:                              ; preds = %schedule.6
  %583 = load i32, ptr %current.token, align 4
  %584 = icmp ne i32 %583, 0
  %585 = sub i32 %583, 1
  %586 = select i1 %584, i32 %585, i32 0
  %587 = load i8, ptr %frame.active, align 1
  %588 = trunc i32 %586 to i8
  %589 = shl i8 1, %588
  %590 = and i8 %587, %589
  %591 = icmp ne i8 %590, 0
  %592 = load <8 x i32>, ptr %frame.static.id, align 32
  %593 = extractelement <8 x i32> %592, i32 %586
  %594 = icmp eq i32 %593, 1
  %595 = and i1 %591, %594
  %596 = and i1 %584, %595
  %597 = xor i1 %596, true
  %598 = and i1 true, %597
  %599 = xor i8 %587, -1
  %600 = icmp ne i8 %599, 0
  %601 = xor i1 %600, true
  %602 = and i1 %598, %601
  br i1 %602, label %convergence.overflow.trap51, label %convergence.overflow.resume52

varying.coherent50:                               ; preds = %schedule.6
  br i1 %244, label %varying.coherent.true57, label %varying.coherent.false58

convergence.overflow.trap51:                      ; preds = %varying.divergent49
  call void @llvm.trap()
  unreachable

convergence.overflow.resume52:                    ; preds = %varying.divergent49
  %603 = call i8 @llvm.cttz.i8(i8 %599, i1 false)
  %604 = zext i8 %603 to i32
  %605 = select i1 %600, i32 %604, i32 0
  %606 = trunc i32 %605 to i8
  %607 = shl i8 1, %606
  %608 = or i8 %587, %607
  %609 = select i1 %598, i8 %608, i8 %587
  store i8 %609, ptr %frame.active, align 1
  %610 = load <8 x i32>, ptr %frame.static.id, align 32
  %611 = extractelement <8 x i32> %610, i32 %605
  %612 = select i1 %598, i32 1, i32 %611
  %613 = load <8 x i32>, ptr %frame.static.id, align 32
  %614 = insertelement <8 x i32> %613, i32 %612, i32 %605
  store <8 x i32> %614, ptr %frame.static.id, align 32
  %615 = load <8 x i32>, ptr %frame.parent.token, align 32
  %616 = extractelement <8 x i32> %615, i32 %605
  %617 = select i1 %598, i32 %583, i32 %616
  %618 = load <8 x i32>, ptr %frame.parent.token, align 32
  %619 = insertelement <8 x i32> %618, i32 %617, i32 %605
  store <8 x i32> %619, ptr %frame.parent.token, align 32
  %620 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %605
  %621 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %605
  %622 = load <8 x i1>, ptr %620, align 1
  %623 = load <8 x i1>, ptr %621, align 1
  %624 = select i1 %598, <8 x i1> %234, <8 x i1> %622
  store <8 x i1> %624, ptr %620, align 1
  %625 = select i1 %598, <8 x i1> zeroinitializer, <8 x i1> %623
  store <8 x i1> %625, ptr %621, align 1
  %626 = add i32 %605, 1
  %627 = select i1 %596, i32 %583, i32 %626
  %628 = select i1 true, i32 %627, i32 %583
  store i32 %628, ptr %current.token, align 4
  %629 = load i32, ptr %current.token, align 4
  %630 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %241)
  %631 = load i32, ptr %ready.count, align 4
  %632 = icmp uge i32 %631, 8
  %633 = and i1 %630, %632
  br i1 %633, label %ready.overflow.trap53, label %ready.overflow.resume54

ready.overflow.trap53:                            ; preds = %convergence.overflow.resume52
  call void @llvm.trap()
  unreachable

ready.overflow.resume54:                          ; preds = %convergence.overflow.resume52
  %634 = select i1 %630, i32 %631, i32 0
  %635 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %634
  %636 = load <8 x i1>, ptr %635, align 1
  %637 = select i1 %630, <8 x i1> %241, <8 x i1> %636
  store <8 x i1> %637, ptr %635, align 1
  %638 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %634
  %639 = load i32, ptr %638, align 4
  %640 = select i1 %630, i32 7, i32 %639
  store i32 %640, ptr %638, align 4
  %641 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %634
  %642 = load i32, ptr %641, align 4
  %643 = select i1 %630, i32 %629, i32 %642
  store i32 %643, ptr %641, align 4
  %644 = add i32 %631, 1
  %645 = select i1 %630, i32 %644, i32 %631
  store i32 %645, ptr %ready.count, align 4
  %646 = load <8 x i1>, ptr %runnable.mask, align 1
  %647 = or <8 x i1> %646, %241
  store <8 x i1> %647, ptr %runnable.mask, align 1
  %648 = load i32, ptr %current.token, align 4
  %649 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %243)
  %650 = load i32, ptr %ready.count, align 4
  %651 = icmp uge i32 %650, 8
  %652 = and i1 %649, %651
  br i1 %652, label %ready.overflow.trap55, label %ready.overflow.resume56

ready.overflow.trap55:                            ; preds = %ready.overflow.resume54
  call void @llvm.trap()
  unreachable

ready.overflow.resume56:                          ; preds = %ready.overflow.resume54
  %653 = select i1 %649, i32 %650, i32 0
  %654 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %653
  %655 = load <8 x i1>, ptr %654, align 1
  %656 = select i1 %649, <8 x i1> %243, <8 x i1> %655
  store <8 x i1> %656, ptr %654, align 1
  %657 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %653
  %658 = load i32, ptr %657, align 4
  %659 = select i1 %649, i32 8, i32 %658
  store i32 %659, ptr %657, align 4
  %660 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %653
  %661 = load i32, ptr %660, align 4
  %662 = select i1 %649, i32 %648, i32 %661
  store i32 %662, ptr %660, align 4
  %663 = add i32 %650, 1
  %664 = select i1 %649, i32 %663, i32 %650
  store i32 %664, ptr %ready.count, align 4
  %665 = load <8 x i1>, ptr %runnable.mask, align 1
  %666 = or <8 x i1> %665, %243
  store <8 x i1> %666, ptr %runnable.mask, align 1
  br label %scheduler.loop

varying.coherent.true57:                          ; preds = %varying.coherent50
  store <8 x i1> %234, ptr %current.mask, align 1
  %667 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %234)
  br i1 %667, label %schedule.7, label %scheduler.loop

varying.coherent.false58:                         ; preds = %varying.coherent50
  store <8 x i1> %234, ptr %current.mask, align 1
  %668 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %234)
  br i1 %668, label %schedule.8, label %scheduler.loop

convergence.cascade67:                            ; preds = %convergence.cascade67, %schedule.8
  %convergence.cascade.flow71 = phi <8 x i1> [ %278, %schedule.8 ], [ %711, %convergence.cascade67 ]
  %convergence.cascade.depth72 = phi i32 [ 0, %schedule.8 ], [ %712, %convergence.cascade67 ]
  %669 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow71)
  %670 = load i32, ptr %current.token, align 4
  %671 = icmp ne i32 %670, 0
  %672 = and i1 %669, %671
  %673 = sub i32 %670, 1
  %674 = select i1 %672, i32 %673, i32 0
  %675 = load i8, ptr %frame.active, align 1
  %676 = trunc i32 %674 to i8
  %677 = shl i8 1, %676
  %678 = and i8 %675, %677
  %679 = icmp ne i8 %678, 0
  %680 = load <8 x i32>, ptr %frame.static.id, align 32
  %681 = extractelement <8 x i32> %680, i32 %674
  %convergence.target.pointer73 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %681
  %convergence.dynamic.target74 = load i32, ptr %convergence.target.pointer73, align 4
  %682 = icmp eq i32 %convergence.dynamic.target74, 8
  %683 = and i1 %679, %682
  %684 = and i1 %672, %683
  %685 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %674
  %686 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %674
  %687 = load <8 x i1>, ptr %685, align 1
  %688 = load <8 x i1>, ptr %686, align 1
  %689 = or <8 x i1> %688, %convergence.cascade.flow71
  %690 = load <8 x i1>, ptr %live.mask, align 1
  %691 = and <8 x i1> %687, %690
  %692 = icmp eq <8 x i1> %689, %691
  %693 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %692)
  %694 = and i1 %684, %693
  %695 = select i1 %694, <8 x i1> zeroinitializer, <8 x i1> %689
  %696 = select i1 %684, <8 x i1> %695, <8 x i1> %688
  store <8 x i1> %696, ptr %686, align 1
  %697 = select i1 %694, <8 x i1> zeroinitializer, <8 x i1> %687
  store <8 x i1> %697, ptr %685, align 1
  %698 = trunc i32 %674 to i8
  %699 = shl i8 1, %698
  %700 = xor i8 %699, -1
  %701 = and i8 %675, %700
  %702 = select i1 %694, i8 %701, i8 %675
  store i8 %702, ptr %frame.active, align 1
  %.splatinsert75 = insertelement <8 x i1> poison, i1 %684, i64 0
  %.splat76 = shufflevector <8 x i1> %.splatinsert75, <8 x i1> poison, <8 x i32> zeroinitializer
  %703 = and <8 x i1> %convergence.cascade.flow71, %.splat76
  %704 = load <8 x i1>, ptr %runnable.mask, align 1
  %705 = xor <8 x i1> %703, splat (i1 true)
  %706 = and <8 x i1> %704, %705
  store <8 x i1> %706, ptr %runnable.mask, align 1
  %.splatinsert77 = insertelement <8 x i1> poison, i1 %694, i64 0
  %.splat78 = shufflevector <8 x i1> %.splatinsert77, <8 x i1> poison, <8 x i32> zeroinitializer
  %707 = select <8 x i1> %.splat78, <8 x i1> %689, <8 x i1> zeroinitializer
  %708 = load <8 x i32>, ptr %frame.parent.token, align 32
  %709 = extractelement <8 x i32> %708, i32 %674
  %710 = select i1 %694, i32 %709, i32 %670
  store i32 %710, ptr %current.token, align 4
  %.splatinsert79 = insertelement <8 x i1> poison, i1 %684, i64 0
  %.splat80 = shufflevector <8 x i1> %.splatinsert79, <8 x i1> poison, <8 x i32> zeroinitializer
  %711 = select <8 x i1> %.splat80, <8 x i1> %707, <8 x i1> %convergence.cascade.flow71
  %712 = add i32 %convergence.cascade.depth72, 1
  %713 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %711)
  %714 = icmp ult i32 %712, 8
  %715 = and i1 %713, %714
  %716 = and i1 %684, %715
  %convergence.parent.token81 = load i32, ptr %current.token, align 4
  %convergence.parent.present82 = icmp ne i32 %convergence.parent.token81, 0
  %717 = and i1 %716, %convergence.parent.present82
  br i1 %717, label %convergence.cascade67, label %convergence.cascade.exit68

convergence.cascade.exit68:                       ; preds = %convergence.cascade67, %schedule.8
  %convergence.cascade.result83 = phi <8 x i1> [ %278, %schedule.8 ], [ %711, %convergence.cascade67 ]
  %718 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result83)
  br i1 %718, label %convergence.target.8.ready, label %scheduler.loop

convergence.target.8.ready:                       ; preds = %convergence.cascade.exit68
  %719 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result83)
  %720 = bitcast <8 x i1> %convergence.cascade.result83 to i8
  %721 = call i8 @llvm.cttz.i8(i8 %720, i1 false)
  %722 = zext i8 %721 to i32
  %723 = select i1 %719, i32 %722, i32 0
  %.spill.load84 = load <8 x i1>, ptr %.spill5, align 1
  %724 = and <8 x i1> %convergence.cascade.result83, %.spill.load84
  %725 = xor <8 x i1> %.spill.load84, splat (i1 true)
  %726 = and <8 x i1> %convergence.cascade.result83, %725
  %727 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %724)
  %728 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %726)
  %729 = and i1 %727, %728
  br i1 %729, label %varying.divergent85, label %varying.coherent86

varying.divergent85:                              ; preds = %convergence.target.8.ready
  %730 = load i32, ptr %current.token, align 4
  %731 = icmp ne i32 %730, 0
  %732 = sub i32 %730, 1
  %733 = select i1 %731, i32 %732, i32 0
  %734 = load i8, ptr %frame.active, align 1
  %735 = trunc i32 %733 to i8
  %736 = shl i8 1, %735
  %737 = and i8 %734, %736
  %738 = icmp ne i8 %737, 0
  %739 = load <8 x i32>, ptr %frame.static.id, align 32
  %740 = extractelement <8 x i32> %739, i32 %733
  %741 = icmp eq i32 %740, 2
  %742 = and i1 %738, %741
  %743 = and i1 %731, %742
  %744 = xor i1 %743, true
  %745 = and i1 true, %744
  %746 = xor i8 %734, -1
  %747 = icmp ne i8 %746, 0
  %748 = xor i1 %747, true
  %749 = and i1 %745, %748
  br i1 %749, label %convergence.overflow.trap87, label %convergence.overflow.resume88

varying.coherent86:                               ; preds = %convergence.target.8.ready
  br i1 %727, label %varying.coherent.true93, label %varying.coherent.false94

convergence.overflow.trap87:                      ; preds = %varying.divergent85
  call void @llvm.trap()
  unreachable

convergence.overflow.resume88:                    ; preds = %varying.divergent85
  %750 = call i8 @llvm.cttz.i8(i8 %746, i1 false)
  %751 = zext i8 %750 to i32
  %752 = select i1 %747, i32 %751, i32 0
  %753 = trunc i32 %752 to i8
  %754 = shl i8 1, %753
  %755 = or i8 %734, %754
  %756 = select i1 %745, i8 %755, i8 %734
  store i8 %756, ptr %frame.active, align 1
  %757 = load <8 x i32>, ptr %frame.static.id, align 32
  %758 = extractelement <8 x i32> %757, i32 %752
  %759 = select i1 %745, i32 2, i32 %758
  %760 = load <8 x i32>, ptr %frame.static.id, align 32
  %761 = insertelement <8 x i32> %760, i32 %759, i32 %752
  store <8 x i32> %761, ptr %frame.static.id, align 32
  %762 = load <8 x i32>, ptr %frame.parent.token, align 32
  %763 = extractelement <8 x i32> %762, i32 %752
  %764 = select i1 %745, i32 %730, i32 %763
  %765 = load <8 x i32>, ptr %frame.parent.token, align 32
  %766 = insertelement <8 x i32> %765, i32 %764, i32 %752
  store <8 x i32> %766, ptr %frame.parent.token, align 32
  %767 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %752
  %768 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %752
  %769 = load <8 x i1>, ptr %767, align 1
  %770 = load <8 x i1>, ptr %768, align 1
  %771 = select i1 %745, <8 x i1> %convergence.cascade.result83, <8 x i1> %769
  store <8 x i1> %771, ptr %767, align 1
  %772 = select i1 %745, <8 x i1> zeroinitializer, <8 x i1> %770
  store <8 x i1> %772, ptr %768, align 1
  %773 = add i32 %752, 1
  %774 = select i1 %743, i32 %730, i32 %773
  %775 = select i1 true, i32 %774, i32 %730
  store i32 %775, ptr %current.token, align 4
  %776 = load i32, ptr %current.token, align 4
  %777 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %724)
  %778 = load i32, ptr %ready.count, align 4
  %779 = icmp uge i32 %778, 8
  %780 = and i1 %777, %779
  br i1 %780, label %ready.overflow.trap89, label %ready.overflow.resume90

ready.overflow.trap89:                            ; preds = %convergence.overflow.resume88
  call void @llvm.trap()
  unreachable

ready.overflow.resume90:                          ; preds = %convergence.overflow.resume88
  %781 = select i1 %777, i32 %778, i32 0
  %782 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %781
  %783 = load <8 x i1>, ptr %782, align 1
  %784 = select i1 %777, <8 x i1> %724, <8 x i1> %783
  store <8 x i1> %784, ptr %782, align 1
  %785 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %781
  %786 = load i32, ptr %785, align 4
  %787 = select i1 %777, i32 9, i32 %786
  store i32 %787, ptr %785, align 4
  %788 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %781
  %789 = load i32, ptr %788, align 4
  %790 = select i1 %777, i32 %776, i32 %789
  store i32 %790, ptr %788, align 4
  %791 = add i32 %778, 1
  %792 = select i1 %777, i32 %791, i32 %778
  store i32 %792, ptr %ready.count, align 4
  %793 = load <8 x i1>, ptr %runnable.mask, align 1
  %794 = or <8 x i1> %793, %724
  store <8 x i1> %794, ptr %runnable.mask, align 1
  %795 = load i32, ptr %current.token, align 4
  %796 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %726)
  %797 = load i32, ptr %ready.count, align 4
  %798 = icmp uge i32 %797, 8
  %799 = and i1 %796, %798
  br i1 %799, label %ready.overflow.trap91, label %ready.overflow.resume92

ready.overflow.trap91:                            ; preds = %ready.overflow.resume90
  call void @llvm.trap()
  unreachable

ready.overflow.resume92:                          ; preds = %ready.overflow.resume90
  %800 = select i1 %796, i32 %797, i32 0
  %801 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %800
  %802 = load <8 x i1>, ptr %801, align 1
  %803 = select i1 %796, <8 x i1> %726, <8 x i1> %802
  store <8 x i1> %803, ptr %801, align 1
  %804 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %800
  %805 = load i32, ptr %804, align 4
  %806 = select i1 %796, i32 10, i32 %805
  store i32 %806, ptr %804, align 4
  %807 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %800
  %808 = load i32, ptr %807, align 4
  %809 = select i1 %796, i32 %795, i32 %808
  store i32 %809, ptr %807, align 4
  %810 = add i32 %797, 1
  %811 = select i1 %796, i32 %810, i32 %797
  store i32 %811, ptr %ready.count, align 4
  %812 = load <8 x i1>, ptr %runnable.mask, align 1
  %813 = or <8 x i1> %812, %726
  store <8 x i1> %813, ptr %runnable.mask, align 1
  br label %scheduler.loop

varying.coherent.true93:                          ; preds = %varying.coherent86
  store <8 x i1> %convergence.cascade.result83, ptr %current.mask, align 1
  %814 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result83)
  br i1 %814, label %schedule.9, label %scheduler.loop

varying.coherent.false94:                         ; preds = %varying.coherent86
  store <8 x i1> %convergence.cascade.result83, ptr %current.mask, align 1
  %815 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result83)
  br i1 %815, label %schedule.10, label %scheduler.loop

convergence.cascade102:                           ; preds = %convergence.cascade102, %schedule.10
  %convergence.cascade.flow106 = phi <8 x i1> [ %312, %schedule.10 ], [ %858, %convergence.cascade102 ]
  %convergence.cascade.depth107 = phi i32 [ 0, %schedule.10 ], [ %859, %convergence.cascade102 ]
  %816 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow106)
  %817 = load i32, ptr %current.token, align 4
  %818 = icmp ne i32 %817, 0
  %819 = and i1 %816, %818
  %820 = sub i32 %817, 1
  %821 = select i1 %819, i32 %820, i32 0
  %822 = load i8, ptr %frame.active, align 1
  %823 = trunc i32 %821 to i8
  %824 = shl i8 1, %823
  %825 = and i8 %822, %824
  %826 = icmp ne i8 %825, 0
  %827 = load <8 x i32>, ptr %frame.static.id, align 32
  %828 = extractelement <8 x i32> %827, i32 %821
  %convergence.target.pointer108 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %828
  %convergence.dynamic.target109 = load i32, ptr %convergence.target.pointer108, align 4
  %829 = icmp eq i32 %convergence.dynamic.target109, 10
  %830 = and i1 %826, %829
  %831 = and i1 %819, %830
  %832 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %821
  %833 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %821
  %834 = load <8 x i1>, ptr %832, align 1
  %835 = load <8 x i1>, ptr %833, align 1
  %836 = or <8 x i1> %835, %convergence.cascade.flow106
  %837 = load <8 x i1>, ptr %live.mask, align 1
  %838 = and <8 x i1> %834, %837
  %839 = icmp eq <8 x i1> %836, %838
  %840 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %839)
  %841 = and i1 %831, %840
  %842 = select i1 %841, <8 x i1> zeroinitializer, <8 x i1> %836
  %843 = select i1 %831, <8 x i1> %842, <8 x i1> %835
  store <8 x i1> %843, ptr %833, align 1
  %844 = select i1 %841, <8 x i1> zeroinitializer, <8 x i1> %834
  store <8 x i1> %844, ptr %832, align 1
  %845 = trunc i32 %821 to i8
  %846 = shl i8 1, %845
  %847 = xor i8 %846, -1
  %848 = and i8 %822, %847
  %849 = select i1 %841, i8 %848, i8 %822
  store i8 %849, ptr %frame.active, align 1
  %.splatinsert110 = insertelement <8 x i1> poison, i1 %831, i64 0
  %.splat111 = shufflevector <8 x i1> %.splatinsert110, <8 x i1> poison, <8 x i32> zeroinitializer
  %850 = and <8 x i1> %convergence.cascade.flow106, %.splat111
  %851 = load <8 x i1>, ptr %runnable.mask, align 1
  %852 = xor <8 x i1> %850, splat (i1 true)
  %853 = and <8 x i1> %851, %852
  store <8 x i1> %853, ptr %runnable.mask, align 1
  %.splatinsert112 = insertelement <8 x i1> poison, i1 %841, i64 0
  %.splat113 = shufflevector <8 x i1> %.splatinsert112, <8 x i1> poison, <8 x i32> zeroinitializer
  %854 = select <8 x i1> %.splat113, <8 x i1> %836, <8 x i1> zeroinitializer
  %855 = load <8 x i32>, ptr %frame.parent.token, align 32
  %856 = extractelement <8 x i32> %855, i32 %821
  %857 = select i1 %841, i32 %856, i32 %817
  store i32 %857, ptr %current.token, align 4
  %.splatinsert114 = insertelement <8 x i1> poison, i1 %831, i64 0
  %.splat115 = shufflevector <8 x i1> %.splatinsert114, <8 x i1> poison, <8 x i32> zeroinitializer
  %858 = select <8 x i1> %.splat115, <8 x i1> %854, <8 x i1> %convergence.cascade.flow106
  %859 = add i32 %convergence.cascade.depth107, 1
  %860 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %858)
  %861 = icmp ult i32 %859, 8
  %862 = and i1 %860, %861
  %863 = and i1 %831, %862
  %convergence.parent.token116 = load i32, ptr %current.token, align 4
  %convergence.parent.present117 = icmp ne i32 %convergence.parent.token116, 0
  %864 = and i1 %863, %convergence.parent.present117
  br i1 %864, label %convergence.cascade102, label %convergence.cascade.exit103

convergence.cascade.exit103:                      ; preds = %convergence.cascade102, %schedule.10
  %convergence.cascade.result118 = phi <8 x i1> [ %312, %schedule.10 ], [ %858, %convergence.cascade102 ]
  %865 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result118)
  br i1 %865, label %convergence.target.10.ready, label %scheduler.loop

convergence.target.10.ready:                      ; preds = %convergence.cascade.exit103
  %866 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result118)
  %867 = bitcast <8 x i1> %convergence.cascade.result118 to i8
  %868 = call i8 @llvm.cttz.i8(i8 %867, i1 false)
  %869 = zext i8 %868 to i32
  %870 = select i1 %866, i32 %869, i32 0
  %871 = load <8 x i64>, ptr %.slot9, align 64
  %872 = select <8 x i1> %convergence.cascade.result118, <8 x i64> zeroinitializer, <8 x i64> %871
  store <8 x i64> %872, ptr %.slot9, align 64
  store <8 x i1> %convergence.cascade.result118, ptr %current.mask, align 1
  %873 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result118)
  br i1 %873, label %schedule.11, label %scheduler.loop

varying.divergent120:                             ; preds = %schedule.11
  %874 = load i32, ptr %current.token, align 4
  %875 = icmp ne i32 %874, 0
  %876 = sub i32 %874, 1
  %877 = select i1 %875, i32 %876, i32 0
  %878 = load i8, ptr %frame.active, align 1
  %879 = trunc i32 %877 to i8
  %880 = shl i8 1, %879
  %881 = and i8 %878, %880
  %882 = icmp ne i8 %881, 0
  %883 = load <8 x i32>, ptr %frame.static.id, align 32
  %884 = extractelement <8 x i32> %883, i32 %877
  %885 = icmp eq i32 %884, 3
  %886 = and i1 %882, %885
  %887 = and i1 %875, %886
  %888 = xor i1 %887, true
  %889 = and i1 true, %888
  %890 = xor i8 %878, -1
  %891 = icmp ne i8 %890, 0
  %892 = xor i1 %891, true
  %893 = and i1 %889, %892
  br i1 %893, label %convergence.overflow.trap122, label %convergence.overflow.resume123

varying.coherent121:                              ; preds = %schedule.11
  br i1 %323, label %varying.coherent.true128, label %varying.coherent.false129

convergence.overflow.trap122:                     ; preds = %varying.divergent120
  call void @llvm.trap()
  unreachable

convergence.overflow.resume123:                   ; preds = %varying.divergent120
  %894 = call i8 @llvm.cttz.i8(i8 %890, i1 false)
  %895 = zext i8 %894 to i32
  %896 = select i1 %891, i32 %895, i32 0
  %897 = trunc i32 %896 to i8
  %898 = shl i8 1, %897
  %899 = or i8 %878, %898
  %900 = select i1 %889, i8 %899, i8 %878
  store i8 %900, ptr %frame.active, align 1
  %901 = load <8 x i32>, ptr %frame.static.id, align 32
  %902 = extractelement <8 x i32> %901, i32 %896
  %903 = select i1 %889, i32 3, i32 %902
  %904 = load <8 x i32>, ptr %frame.static.id, align 32
  %905 = insertelement <8 x i32> %904, i32 %903, i32 %896
  store <8 x i32> %905, ptr %frame.static.id, align 32
  %906 = load <8 x i32>, ptr %frame.parent.token, align 32
  %907 = extractelement <8 x i32> %906, i32 %896
  %908 = select i1 %889, i32 %874, i32 %907
  %909 = load <8 x i32>, ptr %frame.parent.token, align 32
  %910 = insertelement <8 x i32> %909, i32 %908, i32 %896
  store <8 x i32> %910, ptr %frame.parent.token, align 32
  %911 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %896
  %912 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %896
  %913 = load <8 x i1>, ptr %911, align 1
  %914 = load <8 x i1>, ptr %912, align 1
  %915 = select i1 %889, <8 x i1> %313, <8 x i1> %913
  store <8 x i1> %915, ptr %911, align 1
  %916 = select i1 %889, <8 x i1> zeroinitializer, <8 x i1> %914
  store <8 x i1> %916, ptr %912, align 1
  %917 = add i32 %896, 1
  %918 = select i1 %887, i32 %874, i32 %917
  %919 = select i1 true, i32 %918, i32 %874
  store i32 %919, ptr %current.token, align 4
  %920 = load i32, ptr %current.token, align 4
  %921 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %320)
  %922 = load i32, ptr %ready.count, align 4
  %923 = icmp uge i32 %922, 8
  %924 = and i1 %921, %923
  br i1 %924, label %ready.overflow.trap124, label %ready.overflow.resume125

ready.overflow.trap124:                           ; preds = %convergence.overflow.resume123
  call void @llvm.trap()
  unreachable

ready.overflow.resume125:                         ; preds = %convergence.overflow.resume123
  %925 = select i1 %921, i32 %922, i32 0
  %926 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %925
  %927 = load <8 x i1>, ptr %926, align 1
  %928 = select i1 %921, <8 x i1> %320, <8 x i1> %927
  store <8 x i1> %928, ptr %926, align 1
  %929 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %925
  %930 = load i32, ptr %929, align 4
  %931 = select i1 %921, i32 12, i32 %930
  store i32 %931, ptr %929, align 4
  %932 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %925
  %933 = load i32, ptr %932, align 4
  %934 = select i1 %921, i32 %920, i32 %933
  store i32 %934, ptr %932, align 4
  %935 = add i32 %922, 1
  %936 = select i1 %921, i32 %935, i32 %922
  store i32 %936, ptr %ready.count, align 4
  %937 = load <8 x i1>, ptr %runnable.mask, align 1
  %938 = or <8 x i1> %937, %320
  store <8 x i1> %938, ptr %runnable.mask, align 1
  %939 = load i32, ptr %current.token, align 4
  %940 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %322)
  %941 = load i32, ptr %ready.count, align 4
  %942 = icmp uge i32 %941, 8
  %943 = and i1 %940, %942
  br i1 %943, label %ready.overflow.trap126, label %ready.overflow.resume127

ready.overflow.trap126:                           ; preds = %ready.overflow.resume125
  call void @llvm.trap()
  unreachable

ready.overflow.resume127:                         ; preds = %ready.overflow.resume125
  %944 = select i1 %940, i32 %941, i32 0
  %945 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %944
  %946 = load <8 x i1>, ptr %945, align 1
  %947 = select i1 %940, <8 x i1> %322, <8 x i1> %946
  store <8 x i1> %947, ptr %945, align 1
  %948 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %944
  %949 = load i32, ptr %948, align 4
  %950 = select i1 %940, i32 13, i32 %949
  store i32 %950, ptr %948, align 4
  %951 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %944
  %952 = load i32, ptr %951, align 4
  %953 = select i1 %940, i32 %939, i32 %952
  store i32 %953, ptr %951, align 4
  %954 = add i32 %941, 1
  %955 = select i1 %940, i32 %954, i32 %941
  store i32 %955, ptr %ready.count, align 4
  %956 = load <8 x i1>, ptr %runnable.mask, align 1
  %957 = or <8 x i1> %956, %322
  store <8 x i1> %957, ptr %runnable.mask, align 1
  br label %scheduler.loop

varying.coherent.true128:                         ; preds = %varying.coherent121
  store <8 x i1> %313, ptr %current.mask, align 1
  %958 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %313)
  br i1 %958, label %schedule.12, label %scheduler.loop

varying.coherent.false129:                        ; preds = %varying.coherent121
  store <8 x i1> %313, ptr %current.mask, align 1
  %959 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %313)
  br i1 %959, label %schedule.13, label %scheduler.loop

convergence.cascade142:                           ; preds = %convergence.cascade142, %schedule.13
  %convergence.cascade.flow146 = phi <8 x i1> [ %373, %schedule.13 ], [ %1002, %convergence.cascade142 ]
  %convergence.cascade.depth147 = phi i32 [ 0, %schedule.13 ], [ %1003, %convergence.cascade142 ]
  %960 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow146)
  %961 = load i32, ptr %current.token, align 4
  %962 = icmp ne i32 %961, 0
  %963 = and i1 %960, %962
  %964 = sub i32 %961, 1
  %965 = select i1 %963, i32 %964, i32 0
  %966 = load i8, ptr %frame.active, align 1
  %967 = trunc i32 %965 to i8
  %968 = shl i8 1, %967
  %969 = and i8 %966, %968
  %970 = icmp ne i8 %969, 0
  %971 = load <8 x i32>, ptr %frame.static.id, align 32
  %972 = extractelement <8 x i32> %971, i32 %965
  %convergence.target.pointer148 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %972
  %convergence.dynamic.target149 = load i32, ptr %convergence.target.pointer148, align 4
  %973 = icmp eq i32 %convergence.dynamic.target149, 13
  %974 = and i1 %970, %973
  %975 = and i1 %963, %974
  %976 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %965
  %977 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %965
  %978 = load <8 x i1>, ptr %976, align 1
  %979 = load <8 x i1>, ptr %977, align 1
  %980 = or <8 x i1> %979, %convergence.cascade.flow146
  %981 = load <8 x i1>, ptr %live.mask, align 1
  %982 = and <8 x i1> %978, %981
  %983 = icmp eq <8 x i1> %980, %982
  %984 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %983)
  %985 = and i1 %975, %984
  %986 = select i1 %985, <8 x i1> zeroinitializer, <8 x i1> %980
  %987 = select i1 %975, <8 x i1> %986, <8 x i1> %979
  store <8 x i1> %987, ptr %977, align 1
  %988 = select i1 %985, <8 x i1> zeroinitializer, <8 x i1> %978
  store <8 x i1> %988, ptr %976, align 1
  %989 = trunc i32 %965 to i8
  %990 = shl i8 1, %989
  %991 = xor i8 %990, -1
  %992 = and i8 %966, %991
  %993 = select i1 %985, i8 %992, i8 %966
  store i8 %993, ptr %frame.active, align 1
  %.splatinsert150 = insertelement <8 x i1> poison, i1 %975, i64 0
  %.splat151 = shufflevector <8 x i1> %.splatinsert150, <8 x i1> poison, <8 x i32> zeroinitializer
  %994 = and <8 x i1> %convergence.cascade.flow146, %.splat151
  %995 = load <8 x i1>, ptr %runnable.mask, align 1
  %996 = xor <8 x i1> %994, splat (i1 true)
  %997 = and <8 x i1> %995, %996
  store <8 x i1> %997, ptr %runnable.mask, align 1
  %.splatinsert152 = insertelement <8 x i1> poison, i1 %985, i64 0
  %.splat153 = shufflevector <8 x i1> %.splatinsert152, <8 x i1> poison, <8 x i32> zeroinitializer
  %998 = select <8 x i1> %.splat153, <8 x i1> %980, <8 x i1> zeroinitializer
  %999 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1000 = extractelement <8 x i32> %999, i32 %965
  %1001 = select i1 %985, i32 %1000, i32 %961
  store i32 %1001, ptr %current.token, align 4
  %.splatinsert154 = insertelement <8 x i1> poison, i1 %975, i64 0
  %.splat155 = shufflevector <8 x i1> %.splatinsert154, <8 x i1> poison, <8 x i32> zeroinitializer
  %1002 = select <8 x i1> %.splat155, <8 x i1> %998, <8 x i1> %convergence.cascade.flow146
  %1003 = add i32 %convergence.cascade.depth147, 1
  %1004 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1002)
  %1005 = icmp ult i32 %1003, 8
  %1006 = and i1 %1004, %1005
  %1007 = and i1 %975, %1006
  %convergence.parent.token156 = load i32, ptr %current.token, align 4
  %convergence.parent.present157 = icmp ne i32 %convergence.parent.token156, 0
  %1008 = and i1 %1007, %convergence.parent.present157
  br i1 %1008, label %convergence.cascade142, label %convergence.cascade.exit143

convergence.cascade.exit143:                      ; preds = %convergence.cascade142, %schedule.13
  %convergence.cascade.result158 = phi <8 x i1> [ %373, %schedule.13 ], [ %1002, %convergence.cascade142 ]
  %1009 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result158)
  br i1 %1009, label %convergence.target.13.ready, label %scheduler.loop

convergence.target.13.ready:                      ; preds = %convergence.cascade.exit143
  %1010 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result158)
  %1011 = bitcast <8 x i1> %convergence.cascade.result158 to i8
  %1012 = call i8 @llvm.cttz.i8(i8 %1011, i1 false)
  %1013 = zext i8 %1012 to i32
  %1014 = select i1 %1010, i32 %1013, i32 0
  %.spill.load159 = load <8 x i1>, ptr %.spill5, align 1
  %1015 = and <8 x i1> %convergence.cascade.result158, %.spill.load159
  %1016 = xor <8 x i1> %.spill.load159, splat (i1 true)
  %1017 = and <8 x i1> %convergence.cascade.result158, %1016
  %1018 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1015)
  %1019 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1017)
  %1020 = and i1 %1018, %1019
  br i1 %1020, label %varying.divergent160, label %varying.coherent161

varying.divergent160:                             ; preds = %convergence.target.13.ready
  %1021 = load i32, ptr %current.token, align 4
  %1022 = icmp ne i32 %1021, 0
  %1023 = sub i32 %1021, 1
  %1024 = select i1 %1022, i32 %1023, i32 0
  %1025 = load i8, ptr %frame.active, align 1
  %1026 = trunc i32 %1024 to i8
  %1027 = shl i8 1, %1026
  %1028 = and i8 %1025, %1027
  %1029 = icmp ne i8 %1028, 0
  %1030 = load <8 x i32>, ptr %frame.static.id, align 32
  %1031 = extractelement <8 x i32> %1030, i32 %1024
  %1032 = icmp eq i32 %1031, 4
  %1033 = and i1 %1029, %1032
  %1034 = and i1 %1022, %1033
  %1035 = xor i1 %1034, true
  %1036 = and i1 true, %1035
  %1037 = xor i8 %1025, -1
  %1038 = icmp ne i8 %1037, 0
  %1039 = xor i1 %1038, true
  %1040 = and i1 %1036, %1039
  br i1 %1040, label %convergence.overflow.trap162, label %convergence.overflow.resume163

varying.coherent161:                              ; preds = %convergence.target.13.ready
  br i1 %1018, label %varying.coherent.true168, label %varying.coherent.false169

convergence.overflow.trap162:                     ; preds = %varying.divergent160
  call void @llvm.trap()
  unreachable

convergence.overflow.resume163:                   ; preds = %varying.divergent160
  %1041 = call i8 @llvm.cttz.i8(i8 %1037, i1 false)
  %1042 = zext i8 %1041 to i32
  %1043 = select i1 %1038, i32 %1042, i32 0
  %1044 = trunc i32 %1043 to i8
  %1045 = shl i8 1, %1044
  %1046 = or i8 %1025, %1045
  %1047 = select i1 %1036, i8 %1046, i8 %1025
  store i8 %1047, ptr %frame.active, align 1
  %1048 = load <8 x i32>, ptr %frame.static.id, align 32
  %1049 = extractelement <8 x i32> %1048, i32 %1043
  %1050 = select i1 %1036, i32 4, i32 %1049
  %1051 = load <8 x i32>, ptr %frame.static.id, align 32
  %1052 = insertelement <8 x i32> %1051, i32 %1050, i32 %1043
  store <8 x i32> %1052, ptr %frame.static.id, align 32
  %1053 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1054 = extractelement <8 x i32> %1053, i32 %1043
  %1055 = select i1 %1036, i32 %1021, i32 %1054
  %1056 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1057 = insertelement <8 x i32> %1056, i32 %1055, i32 %1043
  store <8 x i32> %1057, ptr %frame.parent.token, align 32
  %1058 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1043
  %1059 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1043
  %1060 = load <8 x i1>, ptr %1058, align 1
  %1061 = load <8 x i1>, ptr %1059, align 1
  %1062 = select i1 %1036, <8 x i1> %convergence.cascade.result158, <8 x i1> %1060
  store <8 x i1> %1062, ptr %1058, align 1
  %1063 = select i1 %1036, <8 x i1> zeroinitializer, <8 x i1> %1061
  store <8 x i1> %1063, ptr %1059, align 1
  %1064 = add i32 %1043, 1
  %1065 = select i1 %1034, i32 %1021, i32 %1064
  %1066 = select i1 true, i32 %1065, i32 %1021
  store i32 %1066, ptr %current.token, align 4
  %1067 = load i32, ptr %current.token, align 4
  %1068 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1015)
  %1069 = load i32, ptr %ready.count, align 4
  %1070 = icmp uge i32 %1069, 8
  %1071 = and i1 %1068, %1070
  br i1 %1071, label %ready.overflow.trap164, label %ready.overflow.resume165

ready.overflow.trap164:                           ; preds = %convergence.overflow.resume163
  call void @llvm.trap()
  unreachable

ready.overflow.resume165:                         ; preds = %convergence.overflow.resume163
  %1072 = select i1 %1068, i32 %1069, i32 0
  %1073 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1072
  %1074 = load <8 x i1>, ptr %1073, align 1
  %1075 = select i1 %1068, <8 x i1> %1015, <8 x i1> %1074
  store <8 x i1> %1075, ptr %1073, align 1
  %1076 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1072
  %1077 = load i32, ptr %1076, align 4
  %1078 = select i1 %1068, i32 14, i32 %1077
  store i32 %1078, ptr %1076, align 4
  %1079 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1072
  %1080 = load i32, ptr %1079, align 4
  %1081 = select i1 %1068, i32 %1067, i32 %1080
  store i32 %1081, ptr %1079, align 4
  %1082 = add i32 %1069, 1
  %1083 = select i1 %1068, i32 %1082, i32 %1069
  store i32 %1083, ptr %ready.count, align 4
  %1084 = load <8 x i1>, ptr %runnable.mask, align 1
  %1085 = or <8 x i1> %1084, %1015
  store <8 x i1> %1085, ptr %runnable.mask, align 1
  %1086 = load i32, ptr %current.token, align 4
  %1087 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1017)
  %1088 = load i32, ptr %ready.count, align 4
  %1089 = icmp uge i32 %1088, 8
  %1090 = and i1 %1087, %1089
  br i1 %1090, label %ready.overflow.trap166, label %ready.overflow.resume167

ready.overflow.trap166:                           ; preds = %ready.overflow.resume165
  call void @llvm.trap()
  unreachable

ready.overflow.resume167:                         ; preds = %ready.overflow.resume165
  %1091 = select i1 %1087, i32 %1088, i32 0
  %1092 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1091
  %1093 = load <8 x i1>, ptr %1092, align 1
  %1094 = select i1 %1087, <8 x i1> %1017, <8 x i1> %1093
  store <8 x i1> %1094, ptr %1092, align 1
  %1095 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1091
  %1096 = load i32, ptr %1095, align 4
  %1097 = select i1 %1087, i32 15, i32 %1096
  store i32 %1097, ptr %1095, align 4
  %1098 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1091
  %1099 = load i32, ptr %1098, align 4
  %1100 = select i1 %1087, i32 %1086, i32 %1099
  store i32 %1100, ptr %1098, align 4
  %1101 = add i32 %1088, 1
  %1102 = select i1 %1087, i32 %1101, i32 %1088
  store i32 %1102, ptr %ready.count, align 4
  %1103 = load <8 x i1>, ptr %runnable.mask, align 1
  %1104 = or <8 x i1> %1103, %1017
  store <8 x i1> %1104, ptr %runnable.mask, align 1
  br label %scheduler.loop

varying.coherent.true168:                         ; preds = %varying.coherent161
  store <8 x i1> %convergence.cascade.result158, ptr %current.mask, align 1
  %1105 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result158)
  br i1 %1105, label %schedule.14, label %scheduler.loop

varying.coherent.false169:                        ; preds = %varying.coherent161
  store <8 x i1> %convergence.cascade.result158, ptr %current.mask, align 1
  %1106 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result158)
  br i1 %1106, label %schedule.15, label %scheduler.loop

convergence.cascade182:                           ; preds = %convergence.cascade182, %schedule.15
  %convergence.cascade.flow186 = phi <8 x i1> [ %427, %schedule.15 ], [ %1149, %convergence.cascade182 ]
  %convergence.cascade.depth187 = phi i32 [ 0, %schedule.15 ], [ %1150, %convergence.cascade182 ]
  %1107 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow186)
  %1108 = load i32, ptr %current.token, align 4
  %1109 = icmp ne i32 %1108, 0
  %1110 = and i1 %1107, %1109
  %1111 = sub i32 %1108, 1
  %1112 = select i1 %1110, i32 %1111, i32 0
  %1113 = load i8, ptr %frame.active, align 1
  %1114 = trunc i32 %1112 to i8
  %1115 = shl i8 1, %1114
  %1116 = and i8 %1113, %1115
  %1117 = icmp ne i8 %1116, 0
  %1118 = load <8 x i32>, ptr %frame.static.id, align 32
  %1119 = extractelement <8 x i32> %1118, i32 %1112
  %convergence.target.pointer188 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %1119
  %convergence.dynamic.target189 = load i32, ptr %convergence.target.pointer188, align 4
  %1120 = icmp eq i32 %convergence.dynamic.target189, 15
  %1121 = and i1 %1117, %1120
  %1122 = and i1 %1110, %1121
  %1123 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1112
  %1124 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1112
  %1125 = load <8 x i1>, ptr %1123, align 1
  %1126 = load <8 x i1>, ptr %1124, align 1
  %1127 = or <8 x i1> %1126, %convergence.cascade.flow186
  %1128 = load <8 x i1>, ptr %live.mask, align 1
  %1129 = and <8 x i1> %1125, %1128
  %1130 = icmp eq <8 x i1> %1127, %1129
  %1131 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1130)
  %1132 = and i1 %1122, %1131
  %1133 = select i1 %1132, <8 x i1> zeroinitializer, <8 x i1> %1127
  %1134 = select i1 %1122, <8 x i1> %1133, <8 x i1> %1126
  store <8 x i1> %1134, ptr %1124, align 1
  %1135 = select i1 %1132, <8 x i1> zeroinitializer, <8 x i1> %1125
  store <8 x i1> %1135, ptr %1123, align 1
  %1136 = trunc i32 %1112 to i8
  %1137 = shl i8 1, %1136
  %1138 = xor i8 %1137, -1
  %1139 = and i8 %1113, %1138
  %1140 = select i1 %1132, i8 %1139, i8 %1113
  store i8 %1140, ptr %frame.active, align 1
  %.splatinsert190 = insertelement <8 x i1> poison, i1 %1122, i64 0
  %.splat191 = shufflevector <8 x i1> %.splatinsert190, <8 x i1> poison, <8 x i32> zeroinitializer
  %1141 = and <8 x i1> %convergence.cascade.flow186, %.splat191
  %1142 = load <8 x i1>, ptr %runnable.mask, align 1
  %1143 = xor <8 x i1> %1141, splat (i1 true)
  %1144 = and <8 x i1> %1142, %1143
  store <8 x i1> %1144, ptr %runnable.mask, align 1
  %.splatinsert192 = insertelement <8 x i1> poison, i1 %1132, i64 0
  %.splat193 = shufflevector <8 x i1> %.splatinsert192, <8 x i1> poison, <8 x i32> zeroinitializer
  %1145 = select <8 x i1> %.splat193, <8 x i1> %1127, <8 x i1> zeroinitializer
  %1146 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1147 = extractelement <8 x i32> %1146, i32 %1112
  %1148 = select i1 %1132, i32 %1147, i32 %1108
  store i32 %1148, ptr %current.token, align 4
  %.splatinsert194 = insertelement <8 x i1> poison, i1 %1122, i64 0
  %.splat195 = shufflevector <8 x i1> %.splatinsert194, <8 x i1> poison, <8 x i32> zeroinitializer
  %1149 = select <8 x i1> %.splat195, <8 x i1> %1145, <8 x i1> %convergence.cascade.flow186
  %1150 = add i32 %convergence.cascade.depth187, 1
  %1151 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1149)
  %1152 = icmp ult i32 %1150, 8
  %1153 = and i1 %1151, %1152
  %1154 = and i1 %1122, %1153
  %convergence.parent.token196 = load i32, ptr %current.token, align 4
  %convergence.parent.present197 = icmp ne i32 %convergence.parent.token196, 0
  %1155 = and i1 %1154, %convergence.parent.present197
  br i1 %1155, label %convergence.cascade182, label %convergence.cascade.exit183

convergence.cascade.exit183:                      ; preds = %convergence.cascade182, %schedule.15
  %convergence.cascade.result198 = phi <8 x i1> [ %427, %schedule.15 ], [ %1149, %convergence.cascade182 ]
  %1156 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result198)
  br i1 %1156, label %convergence.target.15.ready, label %scheduler.loop

convergence.target.15.ready:                      ; preds = %convergence.cascade.exit183
  %1157 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result198)
  %1158 = bitcast <8 x i1> %convergence.cascade.result198 to i8
  %1159 = call i8 @llvm.cttz.i8(i8 %1158, i1 false)
  %1160 = zext i8 %1159 to i32
  %1161 = select i1 %1157, i32 %1160, i32 0
  %1162 = load <8 x i1>, ptr %live.mask, align 1
  %1163 = xor <8 x i1> %convergence.cascade.result198, splat (i1 true)
  %1164 = and <8 x i1> %1162, %1163
  store <8 x i1> %1164, ptr %live.mask, align 1
  %1165 = load <8 x i1>, ptr %runnable.mask, align 1
  %1166 = xor <8 x i1> %convergence.cascade.result198, splat (i1 true)
  %1167 = and <8 x i1> %1165, %1166
  store <8 x i1> %1167, ptr %runnable.mask, align 1
  %return.active.frames = load i8, ptr %frame.active, align 1
  %return.frames.present = icmp ne i8 %return.active.frames, 0
  br i1 %return.frames.present, label %return.frame.cleanup, label %return.frame.cleanup.done

return.frame.cleanup:                             ; preds = %convergence.target.15.ready
  %1168 = load i8, ptr %frame.active, align 1
  %1169 = and i8 %1168, 1
  %1170 = icmp ne i8 %1169, 0
  %1171 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 0
  %1172 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 0
  %1173 = load <8 x i1>, ptr %1171, align 1
  %1174 = load <8 x i1>, ptr %1172, align 1
  %1175 = and <8 x i1> %1173, %1164
  %1176 = icmp eq <8 x i1> %1174, %1175
  %1177 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1176)
  %1178 = and i1 %1170, %1177
  %.splatinsert199 = insertelement <8 x i1> poison, i1 %1178, i64 0
  %.splat200 = shufflevector <8 x i1> %.splatinsert199, <8 x i1> poison, <8 x i32> zeroinitializer
  %1179 = select <8 x i1> %.splat200, <8 x i1> %1174, <8 x i1> zeroinitializer
  %1180 = select i1 %1178, <8 x i1> zeroinitializer, <8 x i1> %1175
  store <8 x i1> %1180, ptr %1171, align 1
  %1181 = select i1 %1178, <8 x i1> zeroinitializer, <8 x i1> %1174
  store <8 x i1> %1181, ptr %1172, align 1
  %1182 = and i8 %1168, -2
  %1183 = select i1 %1178, i8 %1182, i8 %1168
  store i8 %1183, ptr %frame.active, align 1
  %1184 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1185 = extractelement <8 x i32> %1184, i32 0
  %1186 = load <8 x i32>, ptr %frame.static.id, align 32
  %1187 = extractelement <8 x i32> %1186, i32 0
  %convergence.target.pointer201 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %1187
  %convergence.dynamic.target202 = load i32, ptr %convergence.target.pointer201, align 4
  %1188 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1179)
  %1189 = load i32, ptr %ready.count, align 4
  %1190 = icmp uge i32 %1189, 8
  %1191 = and i1 %1188, %1190
  br i1 %1191, label %ready.overflow.trap203, label %ready.overflow.resume204

return.frame.cleanup.done:                        ; preds = %ready.overflow.resume246, %convergence.target.15.ready
  br label %scheduler.loop

ready.overflow.trap203:                           ; preds = %return.frame.cleanup
  call void @llvm.trap()
  unreachable

ready.overflow.resume204:                         ; preds = %return.frame.cleanup
  %1192 = select i1 %1188, i32 %1189, i32 0
  %1193 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1192
  %1194 = load <8 x i1>, ptr %1193, align 1
  %1195 = select i1 %1188, <8 x i1> %1179, <8 x i1> %1194
  store <8 x i1> %1195, ptr %1193, align 1
  %1196 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1192
  %1197 = load i32, ptr %1196, align 4
  %1198 = select i1 %1188, i32 %convergence.dynamic.target202, i32 %1197
  store i32 %1198, ptr %1196, align 4
  %1199 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1192
  %1200 = load i32, ptr %1199, align 4
  %1201 = select i1 %1188, i32 %1185, i32 %1200
  store i32 %1201, ptr %1199, align 4
  %1202 = add i32 %1189, 1
  %1203 = select i1 %1188, i32 %1202, i32 %1189
  store i32 %1203, ptr %ready.count, align 4
  %1204 = load <8 x i1>, ptr %runnable.mask, align 1
  %1205 = or <8 x i1> %1204, %1179
  store <8 x i1> %1205, ptr %runnable.mask, align 1
  %1206 = load i8, ptr %frame.active, align 1
  %1207 = and i8 %1206, 2
  %1208 = icmp ne i8 %1207, 0
  %1209 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 1
  %1210 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 1
  %1211 = load <8 x i1>, ptr %1209, align 1
  %1212 = load <8 x i1>, ptr %1210, align 1
  %1213 = and <8 x i1> %1211, %1164
  %1214 = icmp eq <8 x i1> %1212, %1213
  %1215 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1214)
  %1216 = and i1 %1208, %1215
  %.splatinsert205 = insertelement <8 x i1> poison, i1 %1216, i64 0
  %.splat206 = shufflevector <8 x i1> %.splatinsert205, <8 x i1> poison, <8 x i32> zeroinitializer
  %1217 = select <8 x i1> %.splat206, <8 x i1> %1212, <8 x i1> zeroinitializer
  %1218 = select i1 %1216, <8 x i1> zeroinitializer, <8 x i1> %1213
  store <8 x i1> %1218, ptr %1209, align 1
  %1219 = select i1 %1216, <8 x i1> zeroinitializer, <8 x i1> %1212
  store <8 x i1> %1219, ptr %1210, align 1
  %1220 = and i8 %1206, -3
  %1221 = select i1 %1216, i8 %1220, i8 %1206
  store i8 %1221, ptr %frame.active, align 1
  %1222 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1223 = extractelement <8 x i32> %1222, i32 1
  %1224 = load <8 x i32>, ptr %frame.static.id, align 32
  %1225 = extractelement <8 x i32> %1224, i32 1
  %convergence.target.pointer207 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %1225
  %convergence.dynamic.target208 = load i32, ptr %convergence.target.pointer207, align 4
  %1226 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1217)
  %1227 = load i32, ptr %ready.count, align 4
  %1228 = icmp uge i32 %1227, 8
  %1229 = and i1 %1226, %1228
  br i1 %1229, label %ready.overflow.trap209, label %ready.overflow.resume210

ready.overflow.trap209:                           ; preds = %ready.overflow.resume204
  call void @llvm.trap()
  unreachable

ready.overflow.resume210:                         ; preds = %ready.overflow.resume204
  %1230 = select i1 %1226, i32 %1227, i32 0
  %1231 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1230
  %1232 = load <8 x i1>, ptr %1231, align 1
  %1233 = select i1 %1226, <8 x i1> %1217, <8 x i1> %1232
  store <8 x i1> %1233, ptr %1231, align 1
  %1234 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1230
  %1235 = load i32, ptr %1234, align 4
  %1236 = select i1 %1226, i32 %convergence.dynamic.target208, i32 %1235
  store i32 %1236, ptr %1234, align 4
  %1237 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1230
  %1238 = load i32, ptr %1237, align 4
  %1239 = select i1 %1226, i32 %1223, i32 %1238
  store i32 %1239, ptr %1237, align 4
  %1240 = add i32 %1227, 1
  %1241 = select i1 %1226, i32 %1240, i32 %1227
  store i32 %1241, ptr %ready.count, align 4
  %1242 = load <8 x i1>, ptr %runnable.mask, align 1
  %1243 = or <8 x i1> %1242, %1217
  store <8 x i1> %1243, ptr %runnable.mask, align 1
  %1244 = load i8, ptr %frame.active, align 1
  %1245 = and i8 %1244, 4
  %1246 = icmp ne i8 %1245, 0
  %1247 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 2
  %1248 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 2
  %1249 = load <8 x i1>, ptr %1247, align 1
  %1250 = load <8 x i1>, ptr %1248, align 1
  %1251 = and <8 x i1> %1249, %1164
  %1252 = icmp eq <8 x i1> %1250, %1251
  %1253 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1252)
  %1254 = and i1 %1246, %1253
  %.splatinsert211 = insertelement <8 x i1> poison, i1 %1254, i64 0
  %.splat212 = shufflevector <8 x i1> %.splatinsert211, <8 x i1> poison, <8 x i32> zeroinitializer
  %1255 = select <8 x i1> %.splat212, <8 x i1> %1250, <8 x i1> zeroinitializer
  %1256 = select i1 %1254, <8 x i1> zeroinitializer, <8 x i1> %1251
  store <8 x i1> %1256, ptr %1247, align 1
  %1257 = select i1 %1254, <8 x i1> zeroinitializer, <8 x i1> %1250
  store <8 x i1> %1257, ptr %1248, align 1
  %1258 = and i8 %1244, -5
  %1259 = select i1 %1254, i8 %1258, i8 %1244
  store i8 %1259, ptr %frame.active, align 1
  %1260 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1261 = extractelement <8 x i32> %1260, i32 2
  %1262 = load <8 x i32>, ptr %frame.static.id, align 32
  %1263 = extractelement <8 x i32> %1262, i32 2
  %convergence.target.pointer213 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %1263
  %convergence.dynamic.target214 = load i32, ptr %convergence.target.pointer213, align 4
  %1264 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1255)
  %1265 = load i32, ptr %ready.count, align 4
  %1266 = icmp uge i32 %1265, 8
  %1267 = and i1 %1264, %1266
  br i1 %1267, label %ready.overflow.trap215, label %ready.overflow.resume216

ready.overflow.trap215:                           ; preds = %ready.overflow.resume210
  call void @llvm.trap()
  unreachable

ready.overflow.resume216:                         ; preds = %ready.overflow.resume210
  %1268 = select i1 %1264, i32 %1265, i32 0
  %1269 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1268
  %1270 = load <8 x i1>, ptr %1269, align 1
  %1271 = select i1 %1264, <8 x i1> %1255, <8 x i1> %1270
  store <8 x i1> %1271, ptr %1269, align 1
  %1272 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1268
  %1273 = load i32, ptr %1272, align 4
  %1274 = select i1 %1264, i32 %convergence.dynamic.target214, i32 %1273
  store i32 %1274, ptr %1272, align 4
  %1275 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1268
  %1276 = load i32, ptr %1275, align 4
  %1277 = select i1 %1264, i32 %1261, i32 %1276
  store i32 %1277, ptr %1275, align 4
  %1278 = add i32 %1265, 1
  %1279 = select i1 %1264, i32 %1278, i32 %1265
  store i32 %1279, ptr %ready.count, align 4
  %1280 = load <8 x i1>, ptr %runnable.mask, align 1
  %1281 = or <8 x i1> %1280, %1255
  store <8 x i1> %1281, ptr %runnable.mask, align 1
  %1282 = load i8, ptr %frame.active, align 1
  %1283 = and i8 %1282, 8
  %1284 = icmp ne i8 %1283, 0
  %1285 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 3
  %1286 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 3
  %1287 = load <8 x i1>, ptr %1285, align 1
  %1288 = load <8 x i1>, ptr %1286, align 1
  %1289 = and <8 x i1> %1287, %1164
  %1290 = icmp eq <8 x i1> %1288, %1289
  %1291 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1290)
  %1292 = and i1 %1284, %1291
  %.splatinsert217 = insertelement <8 x i1> poison, i1 %1292, i64 0
  %.splat218 = shufflevector <8 x i1> %.splatinsert217, <8 x i1> poison, <8 x i32> zeroinitializer
  %1293 = select <8 x i1> %.splat218, <8 x i1> %1288, <8 x i1> zeroinitializer
  %1294 = select i1 %1292, <8 x i1> zeroinitializer, <8 x i1> %1289
  store <8 x i1> %1294, ptr %1285, align 1
  %1295 = select i1 %1292, <8 x i1> zeroinitializer, <8 x i1> %1288
  store <8 x i1> %1295, ptr %1286, align 1
  %1296 = and i8 %1282, -9
  %1297 = select i1 %1292, i8 %1296, i8 %1282
  store i8 %1297, ptr %frame.active, align 1
  %1298 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1299 = extractelement <8 x i32> %1298, i32 3
  %1300 = load <8 x i32>, ptr %frame.static.id, align 32
  %1301 = extractelement <8 x i32> %1300, i32 3
  %convergence.target.pointer219 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %1301
  %convergence.dynamic.target220 = load i32, ptr %convergence.target.pointer219, align 4
  %1302 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1293)
  %1303 = load i32, ptr %ready.count, align 4
  %1304 = icmp uge i32 %1303, 8
  %1305 = and i1 %1302, %1304
  br i1 %1305, label %ready.overflow.trap221, label %ready.overflow.resume222

ready.overflow.trap221:                           ; preds = %ready.overflow.resume216
  call void @llvm.trap()
  unreachable

ready.overflow.resume222:                         ; preds = %ready.overflow.resume216
  %1306 = select i1 %1302, i32 %1303, i32 0
  %1307 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1306
  %1308 = load <8 x i1>, ptr %1307, align 1
  %1309 = select i1 %1302, <8 x i1> %1293, <8 x i1> %1308
  store <8 x i1> %1309, ptr %1307, align 1
  %1310 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1306
  %1311 = load i32, ptr %1310, align 4
  %1312 = select i1 %1302, i32 %convergence.dynamic.target220, i32 %1311
  store i32 %1312, ptr %1310, align 4
  %1313 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1306
  %1314 = load i32, ptr %1313, align 4
  %1315 = select i1 %1302, i32 %1299, i32 %1314
  store i32 %1315, ptr %1313, align 4
  %1316 = add i32 %1303, 1
  %1317 = select i1 %1302, i32 %1316, i32 %1303
  store i32 %1317, ptr %ready.count, align 4
  %1318 = load <8 x i1>, ptr %runnable.mask, align 1
  %1319 = or <8 x i1> %1318, %1293
  store <8 x i1> %1319, ptr %runnable.mask, align 1
  %1320 = load i8, ptr %frame.active, align 1
  %1321 = and i8 %1320, 16
  %1322 = icmp ne i8 %1321, 0
  %1323 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 4
  %1324 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 4
  %1325 = load <8 x i1>, ptr %1323, align 1
  %1326 = load <8 x i1>, ptr %1324, align 1
  %1327 = and <8 x i1> %1325, %1164
  %1328 = icmp eq <8 x i1> %1326, %1327
  %1329 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1328)
  %1330 = and i1 %1322, %1329
  %.splatinsert223 = insertelement <8 x i1> poison, i1 %1330, i64 0
  %.splat224 = shufflevector <8 x i1> %.splatinsert223, <8 x i1> poison, <8 x i32> zeroinitializer
  %1331 = select <8 x i1> %.splat224, <8 x i1> %1326, <8 x i1> zeroinitializer
  %1332 = select i1 %1330, <8 x i1> zeroinitializer, <8 x i1> %1327
  store <8 x i1> %1332, ptr %1323, align 1
  %1333 = select i1 %1330, <8 x i1> zeroinitializer, <8 x i1> %1326
  store <8 x i1> %1333, ptr %1324, align 1
  %1334 = and i8 %1320, -17
  %1335 = select i1 %1330, i8 %1334, i8 %1320
  store i8 %1335, ptr %frame.active, align 1
  %1336 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1337 = extractelement <8 x i32> %1336, i32 4
  %1338 = load <8 x i32>, ptr %frame.static.id, align 32
  %1339 = extractelement <8 x i32> %1338, i32 4
  %convergence.target.pointer225 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %1339
  %convergence.dynamic.target226 = load i32, ptr %convergence.target.pointer225, align 4
  %1340 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1331)
  %1341 = load i32, ptr %ready.count, align 4
  %1342 = icmp uge i32 %1341, 8
  %1343 = and i1 %1340, %1342
  br i1 %1343, label %ready.overflow.trap227, label %ready.overflow.resume228

ready.overflow.trap227:                           ; preds = %ready.overflow.resume222
  call void @llvm.trap()
  unreachable

ready.overflow.resume228:                         ; preds = %ready.overflow.resume222
  %1344 = select i1 %1340, i32 %1341, i32 0
  %1345 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1344
  %1346 = load <8 x i1>, ptr %1345, align 1
  %1347 = select i1 %1340, <8 x i1> %1331, <8 x i1> %1346
  store <8 x i1> %1347, ptr %1345, align 1
  %1348 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1344
  %1349 = load i32, ptr %1348, align 4
  %1350 = select i1 %1340, i32 %convergence.dynamic.target226, i32 %1349
  store i32 %1350, ptr %1348, align 4
  %1351 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1344
  %1352 = load i32, ptr %1351, align 4
  %1353 = select i1 %1340, i32 %1337, i32 %1352
  store i32 %1353, ptr %1351, align 4
  %1354 = add i32 %1341, 1
  %1355 = select i1 %1340, i32 %1354, i32 %1341
  store i32 %1355, ptr %ready.count, align 4
  %1356 = load <8 x i1>, ptr %runnable.mask, align 1
  %1357 = or <8 x i1> %1356, %1331
  store <8 x i1> %1357, ptr %runnable.mask, align 1
  %1358 = load i8, ptr %frame.active, align 1
  %1359 = and i8 %1358, 32
  %1360 = icmp ne i8 %1359, 0
  %1361 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 5
  %1362 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 5
  %1363 = load <8 x i1>, ptr %1361, align 1
  %1364 = load <8 x i1>, ptr %1362, align 1
  %1365 = and <8 x i1> %1363, %1164
  %1366 = icmp eq <8 x i1> %1364, %1365
  %1367 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1366)
  %1368 = and i1 %1360, %1367
  %.splatinsert229 = insertelement <8 x i1> poison, i1 %1368, i64 0
  %.splat230 = shufflevector <8 x i1> %.splatinsert229, <8 x i1> poison, <8 x i32> zeroinitializer
  %1369 = select <8 x i1> %.splat230, <8 x i1> %1364, <8 x i1> zeroinitializer
  %1370 = select i1 %1368, <8 x i1> zeroinitializer, <8 x i1> %1365
  store <8 x i1> %1370, ptr %1361, align 1
  %1371 = select i1 %1368, <8 x i1> zeroinitializer, <8 x i1> %1364
  store <8 x i1> %1371, ptr %1362, align 1
  %1372 = and i8 %1358, -33
  %1373 = select i1 %1368, i8 %1372, i8 %1358
  store i8 %1373, ptr %frame.active, align 1
  %1374 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1375 = extractelement <8 x i32> %1374, i32 5
  %1376 = load <8 x i32>, ptr %frame.static.id, align 32
  %1377 = extractelement <8 x i32> %1376, i32 5
  %convergence.target.pointer231 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %1377
  %convergence.dynamic.target232 = load i32, ptr %convergence.target.pointer231, align 4
  %1378 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1369)
  %1379 = load i32, ptr %ready.count, align 4
  %1380 = icmp uge i32 %1379, 8
  %1381 = and i1 %1378, %1380
  br i1 %1381, label %ready.overflow.trap233, label %ready.overflow.resume234

ready.overflow.trap233:                           ; preds = %ready.overflow.resume228
  call void @llvm.trap()
  unreachable

ready.overflow.resume234:                         ; preds = %ready.overflow.resume228
  %1382 = select i1 %1378, i32 %1379, i32 0
  %1383 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1382
  %1384 = load <8 x i1>, ptr %1383, align 1
  %1385 = select i1 %1378, <8 x i1> %1369, <8 x i1> %1384
  store <8 x i1> %1385, ptr %1383, align 1
  %1386 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1382
  %1387 = load i32, ptr %1386, align 4
  %1388 = select i1 %1378, i32 %convergence.dynamic.target232, i32 %1387
  store i32 %1388, ptr %1386, align 4
  %1389 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1382
  %1390 = load i32, ptr %1389, align 4
  %1391 = select i1 %1378, i32 %1375, i32 %1390
  store i32 %1391, ptr %1389, align 4
  %1392 = add i32 %1379, 1
  %1393 = select i1 %1378, i32 %1392, i32 %1379
  store i32 %1393, ptr %ready.count, align 4
  %1394 = load <8 x i1>, ptr %runnable.mask, align 1
  %1395 = or <8 x i1> %1394, %1369
  store <8 x i1> %1395, ptr %runnable.mask, align 1
  %1396 = load i8, ptr %frame.active, align 1
  %1397 = and i8 %1396, 64
  %1398 = icmp ne i8 %1397, 0
  %1399 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 6
  %1400 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 6
  %1401 = load <8 x i1>, ptr %1399, align 1
  %1402 = load <8 x i1>, ptr %1400, align 1
  %1403 = and <8 x i1> %1401, %1164
  %1404 = icmp eq <8 x i1> %1402, %1403
  %1405 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1404)
  %1406 = and i1 %1398, %1405
  %.splatinsert235 = insertelement <8 x i1> poison, i1 %1406, i64 0
  %.splat236 = shufflevector <8 x i1> %.splatinsert235, <8 x i1> poison, <8 x i32> zeroinitializer
  %1407 = select <8 x i1> %.splat236, <8 x i1> %1402, <8 x i1> zeroinitializer
  %1408 = select i1 %1406, <8 x i1> zeroinitializer, <8 x i1> %1403
  store <8 x i1> %1408, ptr %1399, align 1
  %1409 = select i1 %1406, <8 x i1> zeroinitializer, <8 x i1> %1402
  store <8 x i1> %1409, ptr %1400, align 1
  %1410 = and i8 %1396, -65
  %1411 = select i1 %1406, i8 %1410, i8 %1396
  store i8 %1411, ptr %frame.active, align 1
  %1412 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1413 = extractelement <8 x i32> %1412, i32 6
  %1414 = load <8 x i32>, ptr %frame.static.id, align 32
  %1415 = extractelement <8 x i32> %1414, i32 6
  %convergence.target.pointer237 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %1415
  %convergence.dynamic.target238 = load i32, ptr %convergence.target.pointer237, align 4
  %1416 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1407)
  %1417 = load i32, ptr %ready.count, align 4
  %1418 = icmp uge i32 %1417, 8
  %1419 = and i1 %1416, %1418
  br i1 %1419, label %ready.overflow.trap239, label %ready.overflow.resume240

ready.overflow.trap239:                           ; preds = %ready.overflow.resume234
  call void @llvm.trap()
  unreachable

ready.overflow.resume240:                         ; preds = %ready.overflow.resume234
  %1420 = select i1 %1416, i32 %1417, i32 0
  %1421 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1420
  %1422 = load <8 x i1>, ptr %1421, align 1
  %1423 = select i1 %1416, <8 x i1> %1407, <8 x i1> %1422
  store <8 x i1> %1423, ptr %1421, align 1
  %1424 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1420
  %1425 = load i32, ptr %1424, align 4
  %1426 = select i1 %1416, i32 %convergence.dynamic.target238, i32 %1425
  store i32 %1426, ptr %1424, align 4
  %1427 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1420
  %1428 = load i32, ptr %1427, align 4
  %1429 = select i1 %1416, i32 %1413, i32 %1428
  store i32 %1429, ptr %1427, align 4
  %1430 = add i32 %1417, 1
  %1431 = select i1 %1416, i32 %1430, i32 %1417
  store i32 %1431, ptr %ready.count, align 4
  %1432 = load <8 x i1>, ptr %runnable.mask, align 1
  %1433 = or <8 x i1> %1432, %1407
  store <8 x i1> %1433, ptr %runnable.mask, align 1
  %1434 = load i8, ptr %frame.active, align 1
  %1435 = and i8 %1434, -128
  %1436 = icmp ne i8 %1435, 0
  %1437 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 7
  %1438 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 7
  %1439 = load <8 x i1>, ptr %1437, align 1
  %1440 = load <8 x i1>, ptr %1438, align 1
  %1441 = and <8 x i1> %1439, %1164
  %1442 = icmp eq <8 x i1> %1440, %1441
  %1443 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1442)
  %1444 = and i1 %1436, %1443
  %.splatinsert241 = insertelement <8 x i1> poison, i1 %1444, i64 0
  %.splat242 = shufflevector <8 x i1> %.splatinsert241, <8 x i1> poison, <8 x i32> zeroinitializer
  %1445 = select <8 x i1> %.splat242, <8 x i1> %1440, <8 x i1> zeroinitializer
  %1446 = select i1 %1444, <8 x i1> zeroinitializer, <8 x i1> %1441
  store <8 x i1> %1446, ptr %1437, align 1
  %1447 = select i1 %1444, <8 x i1> zeroinitializer, <8 x i1> %1440
  store <8 x i1> %1447, ptr %1438, align 1
  %1448 = and i8 %1434, 127
  %1449 = select i1 %1444, i8 %1448, i8 %1434
  store i8 %1449, ptr %frame.active, align 1
  %1450 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1451 = extractelement <8 x i32> %1450, i32 7
  %1452 = load <8 x i32>, ptr %frame.static.id, align 32
  %1453 = extractelement <8 x i32> %1452, i32 7
  %convergence.target.pointer243 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %1453
  %convergence.dynamic.target244 = load i32, ptr %convergence.target.pointer243, align 4
  %1454 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1445)
  %1455 = load i32, ptr %ready.count, align 4
  %1456 = icmp uge i32 %1455, 8
  %1457 = and i1 %1454, %1456
  br i1 %1457, label %ready.overflow.trap245, label %ready.overflow.resume246

ready.overflow.trap245:                           ; preds = %ready.overflow.resume240
  call void @llvm.trap()
  unreachable

ready.overflow.resume246:                         ; preds = %ready.overflow.resume240
  %1458 = select i1 %1454, i32 %1455, i32 0
  %1459 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1458
  %1460 = load <8 x i1>, ptr %1459, align 1
  %1461 = select i1 %1454, <8 x i1> %1445, <8 x i1> %1460
  store <8 x i1> %1461, ptr %1459, align 1
  %1462 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1458
  %1463 = load i32, ptr %1462, align 4
  %1464 = select i1 %1454, i32 %convergence.dynamic.target244, i32 %1463
  store i32 %1464, ptr %1462, align 4
  %1465 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1458
  %1466 = load i32, ptr %1465, align 4
  %1467 = select i1 %1454, i32 %1451, i32 %1466
  store i32 %1467, ptr %1465, align 4
  %1468 = add i32 %1455, 1
  %1469 = select i1 %1454, i32 %1468, i32 %1455
  store i32 %1469, ptr %ready.count, align 4
  %1470 = load <8 x i1>, ptr %runnable.mask, align 1
  %1471 = or <8 x i1> %1470, %1445
  store <8 x i1> %1471, ptr %runnable.mask, align 1
  br label %return.frame.cleanup.done
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), i32 immarg, <8 x i1>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.and.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #4

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #5 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), i32 immarg, <8 x i1>) #6

define dso_local void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #5 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #6 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

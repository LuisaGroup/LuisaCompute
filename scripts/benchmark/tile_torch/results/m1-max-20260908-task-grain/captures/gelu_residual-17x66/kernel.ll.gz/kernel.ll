; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

@convergence.targets = private unnamed_addr constant [5 x i32] [i32 5, i32 8, i32 10, i32 13, i32 15], align 4

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %live.mask = alloca <8 x i1>, align 1
  %runnable.mask = alloca <8 x i1>, align 1
  %ready.count = alloca i32, align 4
  %ready.mask = alloca [8 x <8 x i1>], align 1
  %ready.target = alloca [8 x i32], align 4
  %ready.token = alloca [8 x i32], align 4
  %current.mask = alloca <8 x i1>, align 1
  %current.token = alloca i32, align 4
  %frame.active = alloca i8, align 1
  %frame.static.id = alloca <8 x i32>, align 32
  %frame.parent.token = alloca <8 x i32>, align 32
  %frame.expected = alloca [8 x <8 x i1>], align 1
  %frame.arrived = alloca [8 x <8 x i1>], align 1
  store <8 x i1> zeroinitializer, ptr %live.mask, align 1
  store <8 x i1> zeroinitializer, ptr %runnable.mask, align 1
  store i32 0, ptr %ready.count, align 4
  store [8 x <8 x i1>] zeroinitializer, ptr %ready.mask, align 1
  store [8 x i32] zeroinitializer, ptr %ready.target, align 4
  store [8 x i32] zeroinitializer, ptr %ready.token, align 4
  store <8 x i1> zeroinitializer, ptr %current.mask, align 1
  store i32 0, ptr %current.token, align 4
  store i8 0, ptr %frame.active, align 1
  store <8 x i32> zeroinitializer, ptr %frame.static.id, align 32
  store <8 x i32> zeroinitializer, ptr %frame.parent.token, align 32
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.expected, align 1
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.arrived, align 1
  %tile_snapshot.local = alloca [288 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [288 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot, align 64
  %.spill5 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill5, align 1
  %.spill6 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill6, align 4
  %.spill7 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill7, align 4
  %.spill8 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill8, align 4
  %.spill9 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill9, align 4
  %tile_snapshot.spill10 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill10, align 64
  %.slot11 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot11, align 64
  %.slot12 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot12, align 64
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert13 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat14 = shufflevector <8 x i32> %.splatinsert13, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat14, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert15 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat16 = shufflevector <8 x i32> %.splatinsert15, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat16, %41
  %44 = mul i32 %32, 1
  %.splatinsert17 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat18 = shufflevector <8 x i32> %.splatinsert17, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat18, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert19 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat20 = shufflevector <8 x i32> %.splatinsert19, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat20, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert21 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat22 = shufflevector <8 x i32> %.splatinsert21, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat22
  store <8 x i1> %51, ptr %live.mask, align 1
  %52 = load i32, ptr %current.token, align 4
  %53 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %54 = load i32, ptr %ready.count, align 4
  %55 = icmp uge i32 %54, 8
  %56 = and i1 %53, %55
  br i1 %56, label %ready.overflow.trap, label %ready.overflow.resume

ready.overflow.trap:                              ; preds = %prologue
  call void @llvm.trap()
  unreachable

ready.overflow.resume:                            ; preds = %prologue
  %57 = select i1 %53, i32 %54, i32 0
  %58 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %57
  %59 = load <8 x i1>, ptr %58, align 1
  %60 = select i1 %53, <8 x i1> %51, <8 x i1> %59
  store <8 x i1> %60, ptr %58, align 1
  %61 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %57
  %62 = load i32, ptr %61, align 4
  %63 = select i1 %53, i32 0, i32 %62
  store i32 %63, ptr %61, align 4
  %64 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %57
  %65 = load i32, ptr %64, align 4
  %66 = select i1 %53, i32 %52, i32 %65
  store i32 %66, ptr %64, align 4
  %67 = add i32 %54, 1
  %68 = select i1 %53, i32 %67, i32 %54
  store i32 %68, ptr %ready.count, align 4
  %69 = load <8 x i1>, ptr %runnable.mask, align 1
  %70 = or <8 x i1> %69, %51
  store <8 x i1> %70, ptr %runnable.mask, align 1
  br label %scheduler.loop

scheduler.loop:                                   ; preds = %return.frame.cleanup.done, %convergence.cascade.exit204, %schedule.14, %varying.coherent.false181, %varying.coherent.true180, %ready.overflow.resume179, %convergence.cascade.exit155, %schedule.12, %varying.coherent.false132, %varying.coherent.true131, %ready.overflow.resume130, %convergence.target.10.ready, %convergence.cascade.exit106, %schedule.9, %varying.coherent.false97, %varying.coherent.true96, %ready.overflow.resume95, %convergence.cascade.exit71, %schedule.7, %varying.coherent.false61, %varying.coherent.true60, %ready.overflow.resume59, %convergence.target.5.ready, %convergence.cascade.exit, %schedule.4, %varying.coherent.false, %varying.coherent.true, %ready.overflow.resume37, %schedule.2, %uniform.false, %uniform.true, %schedule.0, %ready.overflow.resume
  %71 = load i32, ptr %ready.count, align 4
  %72 = icmp ne i32 %71, 0
  br i1 %72, label %scheduler.dispatch, label %scheduler.done

scheduler.dispatch:                               ; preds = %scheduler.loop
  %73 = sub i32 %71, 1
  store i32 %73, ptr %ready.count, align 4
  %74 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %73
  %75 = load <8 x i1>, ptr %74, align 1
  store <8 x i1> %75, ptr %current.mask, align 1
  %76 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %73
  %77 = load i32, ptr %76, align 4
  %78 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %73
  %79 = load i32, ptr %78, align 4
  store i32 %79, ptr %current.token, align 4
  %80 = load <8 x i1>, ptr %runnable.mask, align 1
  %81 = xor <8 x i1> %75, splat (i1 true)
  %82 = and <8 x i1> %80, %81
  store <8 x i1> %82, ptr %runnable.mask, align 1
  br label %scheduler.dispatch.route

scheduler.dispatch.route:                         ; preds = %scheduler.dispatch
  %scheduler.dispatch.pc = phi i32 [ %77, %scheduler.dispatch ]
  switch i32 %scheduler.dispatch.pc, label %scheduler.invalid [
    i32 0, label %schedule.0
    i32 1, label %schedule.1
    i32 2, label %schedule.2
    i32 3, label %schedule.3
    i32 4, label %schedule.4
    i32 5, label %schedule.5
    i32 6, label %schedule.6
    i32 7, label %schedule.7
    i32 8, label %schedule.8
    i32 9, label %schedule.9
    i32 10, label %schedule.10
    i32 11, label %schedule.11
    i32 12, label %schedule.12
    i32 13, label %schedule.13
    i32 14, label %schedule.14
    i32 15, label %schedule.15
  ]

scheduler.done:                                   ; preds = %scheduler.loop
  %83 = load <8 x i1>, ptr %live.mask, align 1
  %84 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %83)
  br i1 %84, label %scheduler.stalled, label %scheduler.exit

scheduler.exit:                                   ; preds = %scheduler.done
  ret void

scheduler.stalled:                                ; preds = %scheduler.done
  call void @llvm.trap()
  unreachable

scheduler.invalid:                                ; preds = %scheduler.dispatch.route
  call void @llvm.trap()
  unreachable

schedule.0:                                       ; preds = %scheduler.dispatch.route
  %85 = load <8 x i1>, ptr %current.mask, align 1
  %86 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %85)
  %87 = bitcast <8 x i1> %85 to i8
  %88 = call i8 @llvm.cttz.i8(i8 %87, i1 false)
  %89 = zext i8 %88 to i32
  %90 = select i1 %86, i32 %89, i32 0
  %91 = extractvalue [3 x <8 x i32>] %50, 0
  %92 = load <8 x i64>, ptr %.spill, align 64
  %93 = select <8 x i1> %85, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %92
  store <8 x i64> %93, ptr %.spill, align 64
  %94 = sub <8 x i32> %91, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %95 = select <8 x i1> %85, <8 x i32> %94, <8 x i32> zeroinitializer
  %96 = select <8 x i1> %85, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %97 = lshr <8 x i32> %95, %96
  %98 = zext <8 x i32> %97 to <8 x i64>
  %99 = select <8 x i1> %85, <8 x i64> %98, <8 x i64> zeroinitializer
  %100 = select <8 x i1> %85, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %101 = sdiv <8 x i64> %99, %100
  %102 = load <8 x i64>, ptr %.spill4, align 64
  %103 = select <8 x i1> %85, <8 x i64> %101, <8 x i64> %102
  store <8 x i64> %103, ptr %.spill4, align 64
  %104 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %105 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %106 = extractvalue { <8 x ptr>, <8 x i64> } %104, 0
  %107 = select <8 x i1> %85, <8 x ptr> %105, <8 x ptr> %106
  %108 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %104, 1
  %110 = select <8 x i1> %85, <8 x i64> %108, <8 x i64> %109
  %111 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %107, 0
  %112 = insertvalue { <8 x ptr>, <8 x i64> } %111, <8 x i64> %110, 1
  store { <8 x ptr>, <8 x i64> } %112, ptr %tile_snapshot.spill, align 64
  %113 = load <8 x i64>, ptr %.slot, align 64
  %114 = select <8 x i1> %85, <8 x i64> zeroinitializer, <8 x i64> %113
  store <8 x i64> %114, ptr %.slot, align 64
  store <8 x i1> %85, ptr %current.mask, align 1
  %115 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %85)
  br i1 %115, label %schedule.1, label %scheduler.loop

schedule.1:                                       ; preds = %schedule.2, %schedule.0, %scheduler.dispatch.route
  %116 = load <8 x i1>, ptr %current.mask, align 1
  %117 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %116)
  %118 = bitcast <8 x i1> %116 to i8
  %119 = call i8 @llvm.cttz.i8(i8 %118, i1 false)
  %120 = zext i8 %119 to i32
  %121 = select i1 %117, i32 %120, i32 0
  %.state = load <8 x i64>, ptr %.slot, align 64
  %122 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %116)
  %123 = bitcast <8 x i1> %116 to i8
  %124 = call i8 @llvm.cttz.i8(i8 %123, i1 false)
  %125 = zext i8 %124 to i32
  %126 = select i1 %122, i32 %125, i32 0
  %127 = extractelement <8 x i64> %.state, i32 %126
  %128 = icmp slt i64 %127, 8
  br i1 %128, label %uniform.true, label %uniform.false

schedule.2:                                       ; preds = %uniform.true, %scheduler.dispatch.route
  %129 = load <8 x i1>, ptr %current.mask, align 1
  %130 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %129)
  %131 = bitcast <8 x i1> %129 to i8
  %132 = call i8 @llvm.cttz.i8(i8 %131, i1 false)
  %133 = zext i8 %132 to i32
  %134 = select i1 %130, i32 %133, i32 0
  %.state23 = load <8 x i64>, ptr %.slot, align 64
  %135 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %129)
  %136 = bitcast <8 x i1> %129 to i8
  %137 = call i8 @llvm.cttz.i8(i8 %136, i1 false)
  %138 = zext i8 %137 to i32
  %139 = select i1 %135, i32 %138, i32 0
  %140 = extractelement <8 x i64> %.state23, i32 %139
  %141 = mul i64 %140, 8
  %.splatinsert24 = insertelement <8 x i64> poison, i64 %141, i64 0
  %.splat25 = shufflevector <8 x i64> %.splatinsert24, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %142 = add <8 x i64> %.splat25, %.spill.load
  %.spill.load26 = load <8 x i64>, ptr %.spill4, align 64
  %143 = add <8 x i64> %.spill.load26, zeroinitializer
  %144 = add <8 x i64> zeroinitializer, %143
  %145 = add <8 x i64> zeroinitializer, %142
  %146 = mul <8 x i64> %144, splat (i64 66)
  %147 = add <8 x i64> %146, %145
  %148 = extractvalue { ptr, i64 } %9, 0
  %149 = extractelement <8 x i64> %147, i32 %134
  %150 = zext i32 %134 to i64
  %151 = sub i64 %149, %150
  %152 = mul i64 %151, 4
  %buffer.contiguous.address = getelementptr i8, ptr %148, i64 %152
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %129, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %154 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state27 = load <8 x i64>, ptr %.slot, align 64
  %155 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %129)
  %156 = bitcast <8 x i1> %129 to i8
  %157 = call i8 @llvm.cttz.i8(i8 %156, i1 false)
  %158 = zext i8 %157 to i32
  %159 = select i1 %155, i32 %158, i32 0
  %160 = extractelement <8 x i64> %.state27, i32 %159
  %.splatinsert28 = insertelement <8 x i64> poison, i64 %160, i64 0
  %.splat29 = shufflevector <8 x i64> %.splatinsert28, <8 x i64> poison, <8 x i32> zeroinitializer
  %161 = mul <8 x i64> %.splat29, splat (i64 32)
  %162 = add <8 x i64> %154, %161
  %163 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %153, 0
  %164 = insertvalue { <8 x ptr>, <8 x i64> } %163, <8 x i64> %162, 1
  %165 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %164, 1
  %167 = extractelement <8 x ptr> %165, i32 0
  %168 = extractelement <8 x i64> %166, i32 %134
  %169 = zext i32 %134 to i64
  %170 = mul i64 %169, 4
  %171 = sub i64 %168, %170
  %172 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %129)
  %173 = select i1 %172, i64 %171, i64 0
  %private.contiguous.address = getelementptr i8, ptr %167, i64 %173
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %174 = select <8 x i1> %129, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %174, ptr %private.contiguous.address, align 4
  %.state30 = load <8 x i64>, ptr %.slot, align 64
  %175 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %129)
  %176 = bitcast <8 x i1> %129 to i8
  %177 = call i8 @llvm.cttz.i8(i8 %176, i1 false)
  %178 = zext i8 %177 to i32
  %179 = select i1 %175, i32 %178, i32 0
  %180 = extractelement <8 x i64> %.state30, i32 %179
  %181 = add i64 %180, 1
  %.splatinsert31 = insertelement <8 x i64> poison, i64 %181, i64 0
  %.splat32 = shufflevector <8 x i64> %.splatinsert31, <8 x i64> poison, <8 x i32> zeroinitializer
  %182 = load <8 x i64>, ptr %.slot, align 64
  %183 = select <8 x i1> %129, <8 x i64> %.splat32, <8 x i64> %182
  store <8 x i64> %183, ptr %.slot, align 64
  store <8 x i1> %129, ptr %current.mask, align 1
  %184 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %129)
  br i1 %184, label %schedule.1, label %scheduler.loop

schedule.3:                                       ; preds = %uniform.false, %scheduler.dispatch.route
  %185 = load <8 x i1>, ptr %current.mask, align 1
  %186 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %185)
  %187 = bitcast <8 x i1> %185 to i8
  %188 = call i8 @llvm.cttz.i8(i8 %187, i1 false)
  %189 = zext i8 %188 to i32
  %190 = select i1 %186, i32 %189, i32 0
  %.spill.load33 = load <8 x i64>, ptr %.spill, align 64
  %191 = icmp slt <8 x i64> %.spill.load33, splat (i64 2)
  %192 = load <8 x i1>, ptr %.spill5, align 1
  %193 = select <8 x i1> %185, <8 x i1> %191, <8 x i1> %192
  store <8 x i1> %193, ptr %.spill5, align 1
  %194 = and <8 x i1> %185, %191
  %195 = xor <8 x i1> %191, splat (i1 true)
  %196 = and <8 x i1> %185, %195
  %197 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %194)
  %198 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %196)
  %199 = and i1 %197, %198
  br i1 %199, label %varying.divergent, label %varying.coherent

schedule.4:                                       ; preds = %varying.coherent.true, %scheduler.dispatch.route
  %200 = load <8 x i1>, ptr %current.mask, align 1
  %201 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %200)
  %202 = bitcast <8 x i1> %200 to i8
  %203 = call i8 @llvm.cttz.i8(i8 %202, i1 false)
  %204 = zext i8 %203 to i32
  %205 = select i1 %201, i32 %204, i32 0
  %.spill.load38 = load <8 x i64>, ptr %.spill, align 64
  %206 = add <8 x i64> splat (i64 64), %.spill.load38
  %.spill.load39 = load <8 x i64>, ptr %.spill4, align 64
  %207 = add <8 x i64> %.spill.load39, zeroinitializer
  %208 = add <8 x i64> zeroinitializer, %207
  %209 = add <8 x i64> zeroinitializer, %206
  %210 = mul <8 x i64> %208, splat (i64 66)
  %211 = add <8 x i64> %210, %209
  %212 = extractvalue { ptr, i64 } %9, 0
  %213 = extractelement <8 x i64> %211, i32 %205
  %214 = zext i32 %205 to i64
  %215 = sub i64 %213, %214
  %216 = mul i64 %215, 4
  %buffer.contiguous.address40 = getelementptr i8, ptr %212, i64 %216
  %buffer.contiguous.load41 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address40, i32 1, <8 x i1> %200, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load42 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %217 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load42, 0
  %218 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load42, 1
  %219 = add <8 x i64> %218, splat (i64 256)
  %220 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %217, 0
  %221 = insertvalue { <8 x ptr>, <8 x i64> } %220, <8 x i64> %219, 1
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %221, 1
  %224 = extractelement <8 x ptr> %222, i32 0
  %225 = extractelement <8 x i64> %223, i32 %205
  %226 = zext i32 %205 to i64
  %227 = mul i64 %226, 4
  %228 = sub i64 %225, %227
  %229 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %200)
  %230 = select i1 %229, i64 %228, i64 0
  %private.contiguous.address43 = getelementptr i8, ptr %224, i64 %230
  %private.contiguous.preserve44 = load <8 x float>, ptr %private.contiguous.address43, align 4
  %231 = select <8 x i1> %200, <8 x float> %buffer.contiguous.load41, <8 x float> %private.contiguous.preserve44
  store <8 x float> %231, ptr %private.contiguous.address43, align 4
  store <8 x i1> %200, ptr %current.mask, align 1
  %232 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %200)
  br i1 %232, label %schedule.5, label %scheduler.loop

schedule.5:                                       ; preds = %schedule.4, %varying.coherent.false, %scheduler.dispatch.route
  %233 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token = load i32, ptr %current.token, align 4
  %convergence.token.present = icmp ne i32 %convergence.current.token, 0
  br i1 %convergence.token.present, label %convergence.cascade, label %convergence.cascade.exit

schedule.6:                                       ; preds = %schedule.7, %convergence.target.5.ready, %scheduler.dispatch.route
  %234 = load <8 x i1>, ptr %current.mask, align 1
  %235 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %234)
  %236 = bitcast <8 x i1> %234 to i8
  %237 = call i8 @llvm.cttz.i8(i8 %236, i1 false)
  %238 = zext i8 %237 to i32
  %239 = select i1 %235, i32 %238, i32 0
  %.state51 = load <8 x i64>, ptr %.slot11, align 64
  %240 = icmp slt <8 x i64> %.state51, splat (i64 8)
  %241 = and <8 x i1> %234, %240
  %242 = xor <8 x i1> %240, splat (i1 true)
  %243 = and <8 x i1> %234, %242
  %244 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %241)
  %245 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %243)
  %246 = and i1 %244, %245
  br i1 %246, label %varying.divergent52, label %varying.coherent53

schedule.7:                                       ; preds = %varying.coherent.true60, %scheduler.dispatch.route
  %247 = load <8 x i1>, ptr %current.mask, align 1
  %248 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %247)
  %249 = bitcast <8 x i1> %247 to i8
  %250 = call i8 @llvm.cttz.i8(i8 %249, i1 false)
  %251 = zext i8 %250 to i32
  %252 = select i1 %248, i32 %251, i32 0
  %.state62 = load <8 x i64>, ptr %.slot11, align 64
  %253 = mul <8 x i64> %.state62, splat (i64 8)
  %.spill.load63 = load <8 x i64>, ptr %.spill, align 64
  %254 = add <8 x i64> %253, %.spill.load63
  %.spill.load64 = load <8 x i64>, ptr %.spill4, align 64
  %255 = add <8 x i64> %.spill.load64, zeroinitializer
  %256 = add <8 x i64> zeroinitializer, %255
  %257 = add <8 x i64> zeroinitializer, %254
  %258 = mul <8 x i64> %256, splat (i64 66)
  %259 = add <8 x i64> %258, %257
  %260 = extractvalue { ptr, i64 } %15, 0
  %261 = extractelement <8 x i64> %259, i32 %252
  %262 = zext i32 %252 to i64
  %263 = sub i64 %261, %262
  %264 = mul i64 %263, 4
  %buffer.contiguous.address65 = getelementptr i8, ptr %260, i64 %264
  %buffer.contiguous.load66 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address65, i32 1, <8 x i1> %247, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load67 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill10, align 64
  %265 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load67, 0
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load67, 1
  %.state68 = load <8 x i64>, ptr %.slot11, align 64
  %267 = mul <8 x i64> %.state68, splat (i64 32)
  %268 = add <8 x i64> %266, %267
  %269 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %265, 0
  %270 = insertvalue { <8 x ptr>, <8 x i64> } %269, <8 x i64> %268, 1
  %271 = extractvalue { <8 x ptr>, <8 x i64> } %270, 0
  %272 = extractvalue { <8 x ptr>, <8 x i64> } %270, 1
  %273 = getelementptr i8, <8 x ptr> %271, <8 x i64> %272
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %buffer.contiguous.load66, <8 x ptr> %273, i32 1, <8 x i1> %247)
  %.state69 = load <8 x i64>, ptr %.slot11, align 64
  %274 = add <8 x i64> %.state69, splat (i64 1)
  %275 = load <8 x i64>, ptr %.slot11, align 64
  %276 = select <8 x i1> %247, <8 x i64> %274, <8 x i64> %275
  store <8 x i64> %276, ptr %.slot11, align 64
  store <8 x i1> %247, ptr %current.mask, align 1
  %277 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %247)
  br i1 %277, label %schedule.6, label %scheduler.loop

schedule.8:                                       ; preds = %varying.coherent.false61, %scheduler.dispatch.route
  %278 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token72 = load i32, ptr %current.token, align 4
  %convergence.token.present73 = icmp ne i32 %convergence.current.token72, 0
  br i1 %convergence.token.present73, label %convergence.cascade70, label %convergence.cascade.exit71

schedule.9:                                       ; preds = %varying.coherent.true96, %scheduler.dispatch.route
  %279 = load <8 x i1>, ptr %current.mask, align 1
  %280 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %279)
  %281 = bitcast <8 x i1> %279 to i8
  %282 = call i8 @llvm.cttz.i8(i8 %281, i1 false)
  %283 = zext i8 %282 to i32
  %284 = select i1 %280, i32 %283, i32 0
  %.spill.load98 = load <8 x i64>, ptr %.spill, align 64
  %285 = add <8 x i64> splat (i64 64), %.spill.load98
  %.spill.load99 = load <8 x i64>, ptr %.spill4, align 64
  %286 = add <8 x i64> %.spill.load99, zeroinitializer
  %287 = add <8 x i64> zeroinitializer, %286
  %288 = add <8 x i64> zeroinitializer, %285
  %289 = mul <8 x i64> %287, splat (i64 66)
  %290 = add <8 x i64> %289, %288
  %291 = extractvalue { ptr, i64 } %15, 0
  %292 = extractelement <8 x i64> %290, i32 %284
  %293 = zext i32 %284 to i64
  %294 = sub i64 %292, %293
  %295 = mul i64 %294, 4
  %buffer.contiguous.address100 = getelementptr i8, ptr %291, i64 %295
  %buffer.contiguous.load101 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address100, i32 1, <8 x i1> %279, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load102 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill10, align 64
  %296 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load102, 0
  %297 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load102, 1
  %298 = add <8 x i64> %297, splat (i64 256)
  %299 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %296, 0
  %300 = insertvalue { <8 x ptr>, <8 x i64> } %299, <8 x i64> %298, 1
  %301 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %302 = extractvalue { <8 x ptr>, <8 x i64> } %300, 1
  %303 = extractelement <8 x ptr> %301, i32 0
  %304 = extractelement <8 x i64> %302, i32 %284
  %305 = zext i32 %284 to i64
  %306 = mul i64 %305, 4
  %307 = sub i64 %304, %306
  %308 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %279)
  %309 = select i1 %308, i64 %307, i64 0
  %private.contiguous.address103 = getelementptr i8, ptr %303, i64 %309
  %private.contiguous.preserve104 = load <8 x float>, ptr %private.contiguous.address103, align 4
  %310 = select <8 x i1> %279, <8 x float> %buffer.contiguous.load101, <8 x float> %private.contiguous.preserve104
  store <8 x float> %310, ptr %private.contiguous.address103, align 4
  store <8 x i1> %279, ptr %current.mask, align 1
  %311 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %279)
  br i1 %311, label %schedule.10, label %scheduler.loop

schedule.10:                                      ; preds = %schedule.9, %varying.coherent.false97, %scheduler.dispatch.route
  %312 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token107 = load i32, ptr %current.token, align 4
  %convergence.token.present108 = icmp ne i32 %convergence.current.token107, 0
  br i1 %convergence.token.present108, label %convergence.cascade105, label %convergence.cascade.exit106

schedule.11:                                      ; preds = %schedule.12, %convergence.target.10.ready, %scheduler.dispatch.route
  %313 = load <8 x i1>, ptr %current.mask, align 1
  %314 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %313)
  %315 = bitcast <8 x i1> %313 to i8
  %316 = call i8 @llvm.cttz.i8(i8 %315, i1 false)
  %317 = zext i8 %316 to i32
  %318 = select i1 %314, i32 %317, i32 0
  %.state122 = load <8 x i64>, ptr %.slot12, align 64
  %319 = icmp slt <8 x i64> %.state122, splat (i64 8)
  %320 = and <8 x i1> %313, %319
  %321 = xor <8 x i1> %319, splat (i1 true)
  %322 = and <8 x i1> %313, %321
  %323 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %320)
  %324 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %322)
  %325 = and i1 %323, %324
  br i1 %325, label %varying.divergent123, label %varying.coherent124

schedule.12:                                      ; preds = %varying.coherent.true131, %scheduler.dispatch.route
  %326 = load <8 x i1>, ptr %current.mask, align 1
  %327 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %326)
  %328 = bitcast <8 x i1> %326 to i8
  %329 = call i8 @llvm.cttz.i8(i8 %328, i1 false)
  %330 = zext i8 %329 to i32
  %331 = select i1 %327, i32 %330, i32 0
  %.state133 = load <8 x i64>, ptr %.slot12, align 64
  %332 = mul <8 x i64> %.state133, splat (i64 8)
  %.spill.load134 = load <8 x i64>, ptr %.spill, align 64
  %333 = add <8 x i64> %332, %.spill.load134
  %.spill.load135 = load <8 x i64>, ptr %.spill4, align 64
  %334 = add <8 x i64> %.spill.load135, zeroinitializer
  %335 = add <8 x i64> zeroinitializer, %334
  %336 = add <8 x i64> zeroinitializer, %333
  %337 = mul <8 x i64> %335, splat (i64 66)
  %338 = add <8 x i64> %337, %336
  %tile_snapshot.spill.load136 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %339 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load136, 0
  %340 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load136, 1
  %.state137 = load <8 x i64>, ptr %.slot12, align 64
  %341 = mul <8 x i64> %.state137, splat (i64 32)
  %342 = add <8 x i64> %340, %341
  %343 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %339, 0
  %344 = insertvalue { <8 x ptr>, <8 x i64> } %343, <8 x i64> %342, 1
  %345 = extractvalue { <8 x ptr>, <8 x i64> } %344, 0
  %346 = extractvalue { <8 x ptr>, <8 x i64> } %344, 1
  %347 = getelementptr i8, <8 x ptr> %345, <8 x i64> %346
  %348 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %347, i32 1, <8 x i1> %326, <8 x float> zeroinitializer)
  %.spill.load138 = load float, ptr %.spill6, align 4
  %.splatinsert139 = insertelement <8 x float> poison, float %.spill.load138, i64 0
  %.splat140 = shufflevector <8 x float> %.splatinsert139, <8 x float> poison, <8 x i32> zeroinitializer
  %349 = fmul <8 x float> %.splat140, %348
  %.spill.load141 = load float, ptr %.spill7, align 4
  %.splatinsert142 = insertelement <8 x float> poison, float %.spill.load141, i64 0
  %.splat143 = shufflevector <8 x float> %.splatinsert142, <8 x float> poison, <8 x i32> zeroinitializer
  %350 = fmul <8 x float> %.splat143, %348
  %351 = fmul <8 x float> %350, %348
  %352 = fmul <8 x float> %351, %348
  %353 = fadd <8 x float> %348, %352
  %.spill.load144 = load float, ptr %.spill8, align 4
  %.splatinsert145 = insertelement <8 x float> poison, float %.spill.load144, i64 0
  %.splat146 = shufflevector <8 x float> %.splatinsert145, <8 x float> poison, <8 x i32> zeroinitializer
  %354 = fmul <8 x float> %.splat146, %353
  %355 = select <8 x i1> %326, <8 x float> %354, <8 x float> zeroinitializer
  %native.tanh = call <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %355)
  %.spill.load147 = load float, ptr %.spill9, align 4
  %.splatinsert148 = insertelement <8 x float> poison, float %.spill.load147, i64 0
  %.splat149 = shufflevector <8 x float> %.splatinsert148, <8 x float> poison, <8 x i32> zeroinitializer
  %356 = fadd <8 x float> %.splat149, %native.tanh
  %357 = fmul <8 x float> %349, %356
  %tile_snapshot.spill.load150 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill10, align 64
  %358 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load150, 0
  %359 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load150, 1
  %.state151 = load <8 x i64>, ptr %.slot12, align 64
  %360 = mul <8 x i64> %.state151, splat (i64 32)
  %361 = add <8 x i64> %359, %360
  %362 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %358, 0
  %363 = insertvalue { <8 x ptr>, <8 x i64> } %362, <8 x i64> %361, 1
  %364 = extractvalue { <8 x ptr>, <8 x i64> } %363, 0
  %365 = extractvalue { <8 x ptr>, <8 x i64> } %363, 1
  %366 = getelementptr i8, <8 x ptr> %364, <8 x i64> %365
  %367 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %366, i32 1, <8 x i1> %326, <8 x float> zeroinitializer)
  %368 = fadd <8 x float> %357, %367
  %369 = extractvalue { ptr, i64 } %27, 0
  %370 = extractelement <8 x i64> %338, i32 %331
  %371 = zext i32 %331 to i64
  %372 = sub i64 %370, %371
  %373 = mul i64 %372, 4
  %buffer.contiguous.address152 = getelementptr i8, ptr %369, i64 %373
  call void @llvm.masked.store.v8f32.p0(<8 x float> %368, ptr %buffer.contiguous.address152, i32 1, <8 x i1> %326)
  %.state153 = load <8 x i64>, ptr %.slot12, align 64
  %374 = add <8 x i64> %.state153, splat (i64 1)
  %375 = load <8 x i64>, ptr %.slot12, align 64
  %376 = select <8 x i1> %326, <8 x i64> %374, <8 x i64> %375
  store <8 x i64> %376, ptr %.slot12, align 64
  store <8 x i1> %326, ptr %current.mask, align 1
  %377 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %326)
  br i1 %377, label %schedule.11, label %scheduler.loop

schedule.13:                                      ; preds = %varying.coherent.false132, %scheduler.dispatch.route
  %378 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token156 = load i32, ptr %current.token, align 4
  %convergence.token.present157 = icmp ne i32 %convergence.current.token156, 0
  br i1 %convergence.token.present157, label %convergence.cascade154, label %convergence.cascade.exit155

schedule.14:                                      ; preds = %varying.coherent.true180, %scheduler.dispatch.route
  %379 = load <8 x i1>, ptr %current.mask, align 1
  %380 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %379)
  %381 = bitcast <8 x i1> %379 to i8
  %382 = call i8 @llvm.cttz.i8(i8 %381, i1 false)
  %383 = zext i8 %382 to i32
  %384 = select i1 %380, i32 %383, i32 0
  %.spill.load182 = load <8 x i64>, ptr %.spill, align 64
  %385 = add <8 x i64> splat (i64 64), %.spill.load182
  %.spill.load183 = load <8 x i64>, ptr %.spill4, align 64
  %386 = add <8 x i64> %.spill.load183, zeroinitializer
  %387 = add <8 x i64> zeroinitializer, %386
  %388 = add <8 x i64> zeroinitializer, %385
  %389 = mul <8 x i64> %387, splat (i64 66)
  %390 = add <8 x i64> %389, %388
  %tile_snapshot.spill.load184 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %391 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load184, 0
  %392 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load184, 1
  %393 = add <8 x i64> %392, splat (i64 256)
  %394 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %391, 0
  %395 = insertvalue { <8 x ptr>, <8 x i64> } %394, <8 x i64> %393, 1
  %396 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %397 = extractvalue { <8 x ptr>, <8 x i64> } %395, 1
  %398 = extractelement <8 x ptr> %396, i32 0
  %399 = extractelement <8 x i64> %397, i32 %384
  %400 = zext i32 %384 to i64
  %401 = mul i64 %400, 4
  %402 = sub i64 %399, %401
  %403 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %379)
  %404 = select i1 %403, i64 %402, i64 0
  %private.contiguous.address185 = getelementptr i8, ptr %398, i64 %404
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address185, align 4
  %405 = select <8 x i1> %379, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %.spill.load186 = load float, ptr %.spill6, align 4
  %.splatinsert187 = insertelement <8 x float> poison, float %.spill.load186, i64 0
  %.splat188 = shufflevector <8 x float> %.splatinsert187, <8 x float> poison, <8 x i32> zeroinitializer
  %406 = fmul <8 x float> %.splat188, %405
  %.spill.load189 = load float, ptr %.spill7, align 4
  %.splatinsert190 = insertelement <8 x float> poison, float %.spill.load189, i64 0
  %.splat191 = shufflevector <8 x float> %.splatinsert190, <8 x float> poison, <8 x i32> zeroinitializer
  %407 = fmul <8 x float> %.splat191, %405
  %408 = fmul <8 x float> %407, %405
  %409 = fmul <8 x float> %408, %405
  %410 = fadd <8 x float> %405, %409
  %.spill.load192 = load float, ptr %.spill8, align 4
  %.splatinsert193 = insertelement <8 x float> poison, float %.spill.load192, i64 0
  %.splat194 = shufflevector <8 x float> %.splatinsert193, <8 x float> poison, <8 x i32> zeroinitializer
  %411 = fmul <8 x float> %.splat194, %410
  %412 = select <8 x i1> %379, <8 x float> %411, <8 x float> zeroinitializer
  %native.tanh195 = call <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %412)
  %.spill.load196 = load float, ptr %.spill9, align 4
  %.splatinsert197 = insertelement <8 x float> poison, float %.spill.load196, i64 0
  %.splat198 = shufflevector <8 x float> %.splatinsert197, <8 x float> poison, <8 x i32> zeroinitializer
  %413 = fadd <8 x float> %.splat198, %native.tanh195
  %414 = fmul <8 x float> %406, %413
  %tile_snapshot.spill.load199 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill10, align 64
  %415 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load199, 0
  %416 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load199, 1
  %417 = add <8 x i64> %416, splat (i64 256)
  %418 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %415, 0
  %419 = insertvalue { <8 x ptr>, <8 x i64> } %418, <8 x i64> %417, 1
  %420 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %421 = extractvalue { <8 x ptr>, <8 x i64> } %419, 1
  %422 = extractelement <8 x ptr> %420, i32 0
  %423 = extractelement <8 x i64> %421, i32 %384
  %424 = zext i32 %384 to i64
  %425 = mul i64 %424, 4
  %426 = sub i64 %423, %425
  %427 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %379)
  %428 = select i1 %427, i64 %426, i64 0
  %private.contiguous.address200 = getelementptr i8, ptr %422, i64 %428
  %private.contiguous.load201 = load <8 x float>, ptr %private.contiguous.address200, align 4
  %429 = select <8 x i1> %379, <8 x float> %private.contiguous.load201, <8 x float> zeroinitializer
  %430 = fadd <8 x float> %414, %429
  %431 = extractvalue { ptr, i64 } %27, 0
  %432 = extractelement <8 x i64> %390, i32 %384
  %433 = zext i32 %384 to i64
  %434 = sub i64 %432, %433
  %435 = mul i64 %434, 4
  %buffer.contiguous.address202 = getelementptr i8, ptr %431, i64 %435
  call void @llvm.masked.store.v8f32.p0(<8 x float> %430, ptr %buffer.contiguous.address202, i32 1, <8 x i1> %379)
  store <8 x i1> %379, ptr %current.mask, align 1
  %436 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %379)
  br i1 %436, label %schedule.15, label %scheduler.loop

schedule.15:                                      ; preds = %schedule.14, %varying.coherent.false181, %scheduler.dispatch.route
  %437 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token205 = load i32, ptr %current.token, align 4
  %convergence.token.present206 = icmp ne i32 %convergence.current.token205, 0
  br i1 %convergence.token.present206, label %convergence.cascade203, label %convergence.cascade.exit204

uniform.true:                                     ; preds = %schedule.1
  store <8 x i1> %116, ptr %current.mask, align 1
  %438 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %116)
  br i1 %438, label %schedule.2, label %scheduler.loop

uniform.false:                                    ; preds = %schedule.1
  store <8 x i1> %116, ptr %current.mask, align 1
  %439 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %116)
  br i1 %439, label %schedule.3, label %scheduler.loop

varying.divergent:                                ; preds = %schedule.3
  %440 = load i32, ptr %current.token, align 4
  %441 = icmp ne i32 %440, 0
  %442 = sub i32 %440, 1
  %443 = select i1 %441, i32 %442, i32 0
  %444 = load i8, ptr %frame.active, align 1
  %445 = trunc i32 %443 to i8
  %446 = shl i8 1, %445
  %447 = and i8 %444, %446
  %448 = icmp ne i8 %447, 0
  %449 = load <8 x i32>, ptr %frame.static.id, align 32
  %450 = extractelement <8 x i32> %449, i32 %443
  %451 = icmp eq i32 %450, 0
  %452 = and i1 %448, %451
  %453 = and i1 %441, %452
  %454 = xor i1 %453, true
  %455 = and i1 true, %454
  %456 = xor i8 %444, -1
  %457 = icmp ne i8 %456, 0
  %458 = xor i1 %457, true
  %459 = and i1 %455, %458
  br i1 %459, label %convergence.overflow.trap, label %convergence.overflow.resume

varying.coherent:                                 ; preds = %schedule.3
  br i1 %197, label %varying.coherent.true, label %varying.coherent.false

convergence.overflow.trap:                        ; preds = %varying.divergent
  call void @llvm.trap()
  unreachable

convergence.overflow.resume:                      ; preds = %varying.divergent
  %460 = call i8 @llvm.cttz.i8(i8 %456, i1 false)
  %461 = zext i8 %460 to i32
  %462 = select i1 %457, i32 %461, i32 0
  %463 = trunc i32 %462 to i8
  %464 = shl i8 1, %463
  %465 = or i8 %444, %464
  %466 = select i1 %455, i8 %465, i8 %444
  store i8 %466, ptr %frame.active, align 1
  %467 = load <8 x i32>, ptr %frame.static.id, align 32
  %468 = extractelement <8 x i32> %467, i32 %462
  %469 = select i1 %455, i32 0, i32 %468
  %470 = load <8 x i32>, ptr %frame.static.id, align 32
  %471 = insertelement <8 x i32> %470, i32 %469, i32 %462
  store <8 x i32> %471, ptr %frame.static.id, align 32
  %472 = load <8 x i32>, ptr %frame.parent.token, align 32
  %473 = extractelement <8 x i32> %472, i32 %462
  %474 = select i1 %455, i32 %440, i32 %473
  %475 = load <8 x i32>, ptr %frame.parent.token, align 32
  %476 = insertelement <8 x i32> %475, i32 %474, i32 %462
  store <8 x i32> %476, ptr %frame.parent.token, align 32
  %477 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %462
  %478 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %462
  %479 = load <8 x i1>, ptr %477, align 1
  %480 = load <8 x i1>, ptr %478, align 1
  %481 = select i1 %455, <8 x i1> %185, <8 x i1> %479
  store <8 x i1> %481, ptr %477, align 1
  %482 = select i1 %455, <8 x i1> zeroinitializer, <8 x i1> %480
  store <8 x i1> %482, ptr %478, align 1
  %483 = add i32 %462, 1
  %484 = select i1 %453, i32 %440, i32 %483
  %485 = select i1 true, i32 %484, i32 %440
  store i32 %485, ptr %current.token, align 4
  %486 = load i32, ptr %current.token, align 4
  %487 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %194)
  %488 = load i32, ptr %ready.count, align 4
  %489 = icmp uge i32 %488, 8
  %490 = and i1 %487, %489
  br i1 %490, label %ready.overflow.trap34, label %ready.overflow.resume35

ready.overflow.trap34:                            ; preds = %convergence.overflow.resume
  call void @llvm.trap()
  unreachable

ready.overflow.resume35:                          ; preds = %convergence.overflow.resume
  %491 = select i1 %487, i32 %488, i32 0
  %492 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %491
  %493 = load <8 x i1>, ptr %492, align 1
  %494 = select i1 %487, <8 x i1> %194, <8 x i1> %493
  store <8 x i1> %494, ptr %492, align 1
  %495 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %491
  %496 = load i32, ptr %495, align 4
  %497 = select i1 %487, i32 4, i32 %496
  store i32 %497, ptr %495, align 4
  %498 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %491
  %499 = load i32, ptr %498, align 4
  %500 = select i1 %487, i32 %486, i32 %499
  store i32 %500, ptr %498, align 4
  %501 = add i32 %488, 1
  %502 = select i1 %487, i32 %501, i32 %488
  store i32 %502, ptr %ready.count, align 4
  %503 = load <8 x i1>, ptr %runnable.mask, align 1
  %504 = or <8 x i1> %503, %194
  store <8 x i1> %504, ptr %runnable.mask, align 1
  %505 = load i32, ptr %current.token, align 4
  %506 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %196)
  %507 = load i32, ptr %ready.count, align 4
  %508 = icmp uge i32 %507, 8
  %509 = and i1 %506, %508
  br i1 %509, label %ready.overflow.trap36, label %ready.overflow.resume37

ready.overflow.trap36:                            ; preds = %ready.overflow.resume35
  call void @llvm.trap()
  unreachable

ready.overflow.resume37:                          ; preds = %ready.overflow.resume35
  %510 = select i1 %506, i32 %507, i32 0
  %511 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %510
  %512 = load <8 x i1>, ptr %511, align 1
  %513 = select i1 %506, <8 x i1> %196, <8 x i1> %512
  store <8 x i1> %513, ptr %511, align 1
  %514 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %510
  %515 = load i32, ptr %514, align 4
  %516 = select i1 %506, i32 5, i32 %515
  store i32 %516, ptr %514, align 4
  %517 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %510
  %518 = load i32, ptr %517, align 4
  %519 = select i1 %506, i32 %505, i32 %518
  store i32 %519, ptr %517, align 4
  %520 = add i32 %507, 1
  %521 = select i1 %506, i32 %520, i32 %507
  store i32 %521, ptr %ready.count, align 4
  %522 = load <8 x i1>, ptr %runnable.mask, align 1
  %523 = or <8 x i1> %522, %196
  store <8 x i1> %523, ptr %runnable.mask, align 1
  br label %scheduler.loop

varying.coherent.true:                            ; preds = %varying.coherent
  store <8 x i1> %185, ptr %current.mask, align 1
  %524 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %185)
  br i1 %524, label %schedule.4, label %scheduler.loop

varying.coherent.false:                           ; preds = %varying.coherent
  store <8 x i1> %185, ptr %current.mask, align 1
  %525 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %185)
  br i1 %525, label %schedule.5, label %scheduler.loop

convergence.cascade:                              ; preds = %convergence.cascade, %schedule.5
  %convergence.cascade.flow = phi <8 x i1> [ %233, %schedule.5 ], [ %568, %convergence.cascade ]
  %convergence.cascade.depth = phi i32 [ 0, %schedule.5 ], [ %569, %convergence.cascade ]
  %526 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow)
  %527 = load i32, ptr %current.token, align 4
  %528 = icmp ne i32 %527, 0
  %529 = and i1 %526, %528
  %530 = sub i32 %527, 1
  %531 = select i1 %529, i32 %530, i32 0
  %532 = load i8, ptr %frame.active, align 1
  %533 = trunc i32 %531 to i8
  %534 = shl i8 1, %533
  %535 = and i8 %532, %534
  %536 = icmp ne i8 %535, 0
  %537 = load <8 x i32>, ptr %frame.static.id, align 32
  %538 = extractelement <8 x i32> %537, i32 %531
  %convergence.target.pointer = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %538
  %convergence.dynamic.target = load i32, ptr %convergence.target.pointer, align 4
  %539 = icmp eq i32 %convergence.dynamic.target, 5
  %540 = and i1 %536, %539
  %541 = and i1 %529, %540
  %542 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %531
  %543 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %531
  %544 = load <8 x i1>, ptr %542, align 1
  %545 = load <8 x i1>, ptr %543, align 1
  %546 = or <8 x i1> %545, %convergence.cascade.flow
  %547 = load <8 x i1>, ptr %live.mask, align 1
  %548 = and <8 x i1> %544, %547
  %549 = icmp eq <8 x i1> %546, %548
  %550 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %549)
  %551 = and i1 %541, %550
  %552 = select i1 %551, <8 x i1> zeroinitializer, <8 x i1> %546
  %553 = select i1 %541, <8 x i1> %552, <8 x i1> %545
  store <8 x i1> %553, ptr %543, align 1
  %554 = select i1 %551, <8 x i1> zeroinitializer, <8 x i1> %544
  store <8 x i1> %554, ptr %542, align 1
  %555 = trunc i32 %531 to i8
  %556 = shl i8 1, %555
  %557 = xor i8 %556, -1
  %558 = and i8 %532, %557
  %559 = select i1 %551, i8 %558, i8 %532
  store i8 %559, ptr %frame.active, align 1
  %.splatinsert45 = insertelement <8 x i1> poison, i1 %541, i64 0
  %.splat46 = shufflevector <8 x i1> %.splatinsert45, <8 x i1> poison, <8 x i32> zeroinitializer
  %560 = and <8 x i1> %convergence.cascade.flow, %.splat46
  %561 = load <8 x i1>, ptr %runnable.mask, align 1
  %562 = xor <8 x i1> %560, splat (i1 true)
  %563 = and <8 x i1> %561, %562
  store <8 x i1> %563, ptr %runnable.mask, align 1
  %.splatinsert47 = insertelement <8 x i1> poison, i1 %551, i64 0
  %.splat48 = shufflevector <8 x i1> %.splatinsert47, <8 x i1> poison, <8 x i32> zeroinitializer
  %564 = select <8 x i1> %.splat48, <8 x i1> %546, <8 x i1> zeroinitializer
  %565 = load <8 x i32>, ptr %frame.parent.token, align 32
  %566 = extractelement <8 x i32> %565, i32 %531
  %567 = select i1 %551, i32 %566, i32 %527
  store i32 %567, ptr %current.token, align 4
  %.splatinsert49 = insertelement <8 x i1> poison, i1 %541, i64 0
  %.splat50 = shufflevector <8 x i1> %.splatinsert49, <8 x i1> poison, <8 x i32> zeroinitializer
  %568 = select <8 x i1> %.splat50, <8 x i1> %564, <8 x i1> %convergence.cascade.flow
  %569 = add i32 %convergence.cascade.depth, 1
  %570 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %568)
  %571 = icmp ult i32 %569, 8
  %572 = and i1 %570, %571
  %573 = and i1 %541, %572
  %convergence.parent.token = load i32, ptr %current.token, align 4
  %convergence.parent.present = icmp ne i32 %convergence.parent.token, 0
  %574 = and i1 %573, %convergence.parent.present
  br i1 %574, label %convergence.cascade, label %convergence.cascade.exit

convergence.cascade.exit:                         ; preds = %convergence.cascade, %schedule.5
  %convergence.cascade.result = phi <8 x i1> [ %233, %schedule.5 ], [ %568, %convergence.cascade ]
  %575 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %575, label %convergence.target.5.ready, label %scheduler.loop

convergence.target.5.ready:                       ; preds = %convergence.cascade.exit
  %576 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %577 = bitcast <8 x i1> %convergence.cascade.result to i8
  %578 = call i8 @llvm.cttz.i8(i8 %577, i1 false)
  %579 = zext i8 %578 to i32
  %580 = select i1 %576, i32 %579, i32 0
  store float 5.000000e-01, ptr %.spill6, align 4
  store float 0x3FA6E4E260000000, ptr %.spill7, align 4
  store float 0x3FE9884540000000, ptr %.spill8, align 4
  store float 1.000000e+00, ptr %.spill9, align 4
  %581 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill10, align 64
  %582 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %583 = extractvalue { <8 x ptr>, <8 x i64> } %581, 0
  %584 = select <8 x i1> %convergence.cascade.result, <8 x ptr> %582, <8 x ptr> %583
  %585 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %586 = extractvalue { <8 x ptr>, <8 x i64> } %581, 1
  %587 = select <8 x i1> %convergence.cascade.result, <8 x i64> %585, <8 x i64> %586
  %588 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %584, 0
  %589 = insertvalue { <8 x ptr>, <8 x i64> } %588, <8 x i64> %587, 1
  store { <8 x ptr>, <8 x i64> } %589, ptr %tile_snapshot.spill10, align 64
  %590 = load <8 x i64>, ptr %.slot11, align 64
  %591 = select <8 x i1> %convergence.cascade.result, <8 x i64> zeroinitializer, <8 x i64> %590
  store <8 x i64> %591, ptr %.slot11, align 64
  store <8 x i1> %convergence.cascade.result, ptr %current.mask, align 1
  %592 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %592, label %schedule.6, label %scheduler.loop

varying.divergent52:                              ; preds = %schedule.6
  %593 = load i32, ptr %current.token, align 4
  %594 = icmp ne i32 %593, 0
  %595 = sub i32 %593, 1
  %596 = select i1 %594, i32 %595, i32 0
  %597 = load i8, ptr %frame.active, align 1
  %598 = trunc i32 %596 to i8
  %599 = shl i8 1, %598
  %600 = and i8 %597, %599
  %601 = icmp ne i8 %600, 0
  %602 = load <8 x i32>, ptr %frame.static.id, align 32
  %603 = extractelement <8 x i32> %602, i32 %596
  %604 = icmp eq i32 %603, 1
  %605 = and i1 %601, %604
  %606 = and i1 %594, %605
  %607 = xor i1 %606, true
  %608 = and i1 true, %607
  %609 = xor i8 %597, -1
  %610 = icmp ne i8 %609, 0
  %611 = xor i1 %610, true
  %612 = and i1 %608, %611
  br i1 %612, label %convergence.overflow.trap54, label %convergence.overflow.resume55

varying.coherent53:                               ; preds = %schedule.6
  br i1 %244, label %varying.coherent.true60, label %varying.coherent.false61

convergence.overflow.trap54:                      ; preds = %varying.divergent52
  call void @llvm.trap()
  unreachable

convergence.overflow.resume55:                    ; preds = %varying.divergent52
  %613 = call i8 @llvm.cttz.i8(i8 %609, i1 false)
  %614 = zext i8 %613 to i32
  %615 = select i1 %610, i32 %614, i32 0
  %616 = trunc i32 %615 to i8
  %617 = shl i8 1, %616
  %618 = or i8 %597, %617
  %619 = select i1 %608, i8 %618, i8 %597
  store i8 %619, ptr %frame.active, align 1
  %620 = load <8 x i32>, ptr %frame.static.id, align 32
  %621 = extractelement <8 x i32> %620, i32 %615
  %622 = select i1 %608, i32 1, i32 %621
  %623 = load <8 x i32>, ptr %frame.static.id, align 32
  %624 = insertelement <8 x i32> %623, i32 %622, i32 %615
  store <8 x i32> %624, ptr %frame.static.id, align 32
  %625 = load <8 x i32>, ptr %frame.parent.token, align 32
  %626 = extractelement <8 x i32> %625, i32 %615
  %627 = select i1 %608, i32 %593, i32 %626
  %628 = load <8 x i32>, ptr %frame.parent.token, align 32
  %629 = insertelement <8 x i32> %628, i32 %627, i32 %615
  store <8 x i32> %629, ptr %frame.parent.token, align 32
  %630 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %615
  %631 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %615
  %632 = load <8 x i1>, ptr %630, align 1
  %633 = load <8 x i1>, ptr %631, align 1
  %634 = select i1 %608, <8 x i1> %234, <8 x i1> %632
  store <8 x i1> %634, ptr %630, align 1
  %635 = select i1 %608, <8 x i1> zeroinitializer, <8 x i1> %633
  store <8 x i1> %635, ptr %631, align 1
  %636 = add i32 %615, 1
  %637 = select i1 %606, i32 %593, i32 %636
  %638 = select i1 true, i32 %637, i32 %593
  store i32 %638, ptr %current.token, align 4
  %639 = load i32, ptr %current.token, align 4
  %640 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %241)
  %641 = load i32, ptr %ready.count, align 4
  %642 = icmp uge i32 %641, 8
  %643 = and i1 %640, %642
  br i1 %643, label %ready.overflow.trap56, label %ready.overflow.resume57

ready.overflow.trap56:                            ; preds = %convergence.overflow.resume55
  call void @llvm.trap()
  unreachable

ready.overflow.resume57:                          ; preds = %convergence.overflow.resume55
  %644 = select i1 %640, i32 %641, i32 0
  %645 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %644
  %646 = load <8 x i1>, ptr %645, align 1
  %647 = select i1 %640, <8 x i1> %241, <8 x i1> %646
  store <8 x i1> %647, ptr %645, align 1
  %648 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %644
  %649 = load i32, ptr %648, align 4
  %650 = select i1 %640, i32 7, i32 %649
  store i32 %650, ptr %648, align 4
  %651 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %644
  %652 = load i32, ptr %651, align 4
  %653 = select i1 %640, i32 %639, i32 %652
  store i32 %653, ptr %651, align 4
  %654 = add i32 %641, 1
  %655 = select i1 %640, i32 %654, i32 %641
  store i32 %655, ptr %ready.count, align 4
  %656 = load <8 x i1>, ptr %runnable.mask, align 1
  %657 = or <8 x i1> %656, %241
  store <8 x i1> %657, ptr %runnable.mask, align 1
  %658 = load i32, ptr %current.token, align 4
  %659 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %243)
  %660 = load i32, ptr %ready.count, align 4
  %661 = icmp uge i32 %660, 8
  %662 = and i1 %659, %661
  br i1 %662, label %ready.overflow.trap58, label %ready.overflow.resume59

ready.overflow.trap58:                            ; preds = %ready.overflow.resume57
  call void @llvm.trap()
  unreachable

ready.overflow.resume59:                          ; preds = %ready.overflow.resume57
  %663 = select i1 %659, i32 %660, i32 0
  %664 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %663
  %665 = load <8 x i1>, ptr %664, align 1
  %666 = select i1 %659, <8 x i1> %243, <8 x i1> %665
  store <8 x i1> %666, ptr %664, align 1
  %667 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %663
  %668 = load i32, ptr %667, align 4
  %669 = select i1 %659, i32 8, i32 %668
  store i32 %669, ptr %667, align 4
  %670 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %663
  %671 = load i32, ptr %670, align 4
  %672 = select i1 %659, i32 %658, i32 %671
  store i32 %672, ptr %670, align 4
  %673 = add i32 %660, 1
  %674 = select i1 %659, i32 %673, i32 %660
  store i32 %674, ptr %ready.count, align 4
  %675 = load <8 x i1>, ptr %runnable.mask, align 1
  %676 = or <8 x i1> %675, %243
  store <8 x i1> %676, ptr %runnable.mask, align 1
  br label %scheduler.loop

varying.coherent.true60:                          ; preds = %varying.coherent53
  store <8 x i1> %234, ptr %current.mask, align 1
  %677 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %234)
  br i1 %677, label %schedule.7, label %scheduler.loop

varying.coherent.false61:                         ; preds = %varying.coherent53
  store <8 x i1> %234, ptr %current.mask, align 1
  %678 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %234)
  br i1 %678, label %schedule.8, label %scheduler.loop

convergence.cascade70:                            ; preds = %convergence.cascade70, %schedule.8
  %convergence.cascade.flow74 = phi <8 x i1> [ %278, %schedule.8 ], [ %721, %convergence.cascade70 ]
  %convergence.cascade.depth75 = phi i32 [ 0, %schedule.8 ], [ %722, %convergence.cascade70 ]
  %679 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow74)
  %680 = load i32, ptr %current.token, align 4
  %681 = icmp ne i32 %680, 0
  %682 = and i1 %679, %681
  %683 = sub i32 %680, 1
  %684 = select i1 %682, i32 %683, i32 0
  %685 = load i8, ptr %frame.active, align 1
  %686 = trunc i32 %684 to i8
  %687 = shl i8 1, %686
  %688 = and i8 %685, %687
  %689 = icmp ne i8 %688, 0
  %690 = load <8 x i32>, ptr %frame.static.id, align 32
  %691 = extractelement <8 x i32> %690, i32 %684
  %convergence.target.pointer76 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %691
  %convergence.dynamic.target77 = load i32, ptr %convergence.target.pointer76, align 4
  %692 = icmp eq i32 %convergence.dynamic.target77, 8
  %693 = and i1 %689, %692
  %694 = and i1 %682, %693
  %695 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %684
  %696 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %684
  %697 = load <8 x i1>, ptr %695, align 1
  %698 = load <8 x i1>, ptr %696, align 1
  %699 = or <8 x i1> %698, %convergence.cascade.flow74
  %700 = load <8 x i1>, ptr %live.mask, align 1
  %701 = and <8 x i1> %697, %700
  %702 = icmp eq <8 x i1> %699, %701
  %703 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %702)
  %704 = and i1 %694, %703
  %705 = select i1 %704, <8 x i1> zeroinitializer, <8 x i1> %699
  %706 = select i1 %694, <8 x i1> %705, <8 x i1> %698
  store <8 x i1> %706, ptr %696, align 1
  %707 = select i1 %704, <8 x i1> zeroinitializer, <8 x i1> %697
  store <8 x i1> %707, ptr %695, align 1
  %708 = trunc i32 %684 to i8
  %709 = shl i8 1, %708
  %710 = xor i8 %709, -1
  %711 = and i8 %685, %710
  %712 = select i1 %704, i8 %711, i8 %685
  store i8 %712, ptr %frame.active, align 1
  %.splatinsert78 = insertelement <8 x i1> poison, i1 %694, i64 0
  %.splat79 = shufflevector <8 x i1> %.splatinsert78, <8 x i1> poison, <8 x i32> zeroinitializer
  %713 = and <8 x i1> %convergence.cascade.flow74, %.splat79
  %714 = load <8 x i1>, ptr %runnable.mask, align 1
  %715 = xor <8 x i1> %713, splat (i1 true)
  %716 = and <8 x i1> %714, %715
  store <8 x i1> %716, ptr %runnable.mask, align 1
  %.splatinsert80 = insertelement <8 x i1> poison, i1 %704, i64 0
  %.splat81 = shufflevector <8 x i1> %.splatinsert80, <8 x i1> poison, <8 x i32> zeroinitializer
  %717 = select <8 x i1> %.splat81, <8 x i1> %699, <8 x i1> zeroinitializer
  %718 = load <8 x i32>, ptr %frame.parent.token, align 32
  %719 = extractelement <8 x i32> %718, i32 %684
  %720 = select i1 %704, i32 %719, i32 %680
  store i32 %720, ptr %current.token, align 4
  %.splatinsert82 = insertelement <8 x i1> poison, i1 %694, i64 0
  %.splat83 = shufflevector <8 x i1> %.splatinsert82, <8 x i1> poison, <8 x i32> zeroinitializer
  %721 = select <8 x i1> %.splat83, <8 x i1> %717, <8 x i1> %convergence.cascade.flow74
  %722 = add i32 %convergence.cascade.depth75, 1
  %723 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %721)
  %724 = icmp ult i32 %722, 8
  %725 = and i1 %723, %724
  %726 = and i1 %694, %725
  %convergence.parent.token84 = load i32, ptr %current.token, align 4
  %convergence.parent.present85 = icmp ne i32 %convergence.parent.token84, 0
  %727 = and i1 %726, %convergence.parent.present85
  br i1 %727, label %convergence.cascade70, label %convergence.cascade.exit71

convergence.cascade.exit71:                       ; preds = %convergence.cascade70, %schedule.8
  %convergence.cascade.result86 = phi <8 x i1> [ %278, %schedule.8 ], [ %721, %convergence.cascade70 ]
  %728 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result86)
  br i1 %728, label %convergence.target.8.ready, label %scheduler.loop

convergence.target.8.ready:                       ; preds = %convergence.cascade.exit71
  %729 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result86)
  %730 = bitcast <8 x i1> %convergence.cascade.result86 to i8
  %731 = call i8 @llvm.cttz.i8(i8 %730, i1 false)
  %732 = zext i8 %731 to i32
  %733 = select i1 %729, i32 %732, i32 0
  %.spill.load87 = load <8 x i1>, ptr %.spill5, align 1
  %734 = and <8 x i1> %convergence.cascade.result86, %.spill.load87
  %735 = xor <8 x i1> %.spill.load87, splat (i1 true)
  %736 = and <8 x i1> %convergence.cascade.result86, %735
  %737 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %734)
  %738 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %736)
  %739 = and i1 %737, %738
  br i1 %739, label %varying.divergent88, label %varying.coherent89

varying.divergent88:                              ; preds = %convergence.target.8.ready
  %740 = load i32, ptr %current.token, align 4
  %741 = icmp ne i32 %740, 0
  %742 = sub i32 %740, 1
  %743 = select i1 %741, i32 %742, i32 0
  %744 = load i8, ptr %frame.active, align 1
  %745 = trunc i32 %743 to i8
  %746 = shl i8 1, %745
  %747 = and i8 %744, %746
  %748 = icmp ne i8 %747, 0
  %749 = load <8 x i32>, ptr %frame.static.id, align 32
  %750 = extractelement <8 x i32> %749, i32 %743
  %751 = icmp eq i32 %750, 2
  %752 = and i1 %748, %751
  %753 = and i1 %741, %752
  %754 = xor i1 %753, true
  %755 = and i1 true, %754
  %756 = xor i8 %744, -1
  %757 = icmp ne i8 %756, 0
  %758 = xor i1 %757, true
  %759 = and i1 %755, %758
  br i1 %759, label %convergence.overflow.trap90, label %convergence.overflow.resume91

varying.coherent89:                               ; preds = %convergence.target.8.ready
  br i1 %737, label %varying.coherent.true96, label %varying.coherent.false97

convergence.overflow.trap90:                      ; preds = %varying.divergent88
  call void @llvm.trap()
  unreachable

convergence.overflow.resume91:                    ; preds = %varying.divergent88
  %760 = call i8 @llvm.cttz.i8(i8 %756, i1 false)
  %761 = zext i8 %760 to i32
  %762 = select i1 %757, i32 %761, i32 0
  %763 = trunc i32 %762 to i8
  %764 = shl i8 1, %763
  %765 = or i8 %744, %764
  %766 = select i1 %755, i8 %765, i8 %744
  store i8 %766, ptr %frame.active, align 1
  %767 = load <8 x i32>, ptr %frame.static.id, align 32
  %768 = extractelement <8 x i32> %767, i32 %762
  %769 = select i1 %755, i32 2, i32 %768
  %770 = load <8 x i32>, ptr %frame.static.id, align 32
  %771 = insertelement <8 x i32> %770, i32 %769, i32 %762
  store <8 x i32> %771, ptr %frame.static.id, align 32
  %772 = load <8 x i32>, ptr %frame.parent.token, align 32
  %773 = extractelement <8 x i32> %772, i32 %762
  %774 = select i1 %755, i32 %740, i32 %773
  %775 = load <8 x i32>, ptr %frame.parent.token, align 32
  %776 = insertelement <8 x i32> %775, i32 %774, i32 %762
  store <8 x i32> %776, ptr %frame.parent.token, align 32
  %777 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %762
  %778 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %762
  %779 = load <8 x i1>, ptr %777, align 1
  %780 = load <8 x i1>, ptr %778, align 1
  %781 = select i1 %755, <8 x i1> %convergence.cascade.result86, <8 x i1> %779
  store <8 x i1> %781, ptr %777, align 1
  %782 = select i1 %755, <8 x i1> zeroinitializer, <8 x i1> %780
  store <8 x i1> %782, ptr %778, align 1
  %783 = add i32 %762, 1
  %784 = select i1 %753, i32 %740, i32 %783
  %785 = select i1 true, i32 %784, i32 %740
  store i32 %785, ptr %current.token, align 4
  %786 = load i32, ptr %current.token, align 4
  %787 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %734)
  %788 = load i32, ptr %ready.count, align 4
  %789 = icmp uge i32 %788, 8
  %790 = and i1 %787, %789
  br i1 %790, label %ready.overflow.trap92, label %ready.overflow.resume93

ready.overflow.trap92:                            ; preds = %convergence.overflow.resume91
  call void @llvm.trap()
  unreachable

ready.overflow.resume93:                          ; preds = %convergence.overflow.resume91
  %791 = select i1 %787, i32 %788, i32 0
  %792 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %791
  %793 = load <8 x i1>, ptr %792, align 1
  %794 = select i1 %787, <8 x i1> %734, <8 x i1> %793
  store <8 x i1> %794, ptr %792, align 1
  %795 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %791
  %796 = load i32, ptr %795, align 4
  %797 = select i1 %787, i32 9, i32 %796
  store i32 %797, ptr %795, align 4
  %798 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %791
  %799 = load i32, ptr %798, align 4
  %800 = select i1 %787, i32 %786, i32 %799
  store i32 %800, ptr %798, align 4
  %801 = add i32 %788, 1
  %802 = select i1 %787, i32 %801, i32 %788
  store i32 %802, ptr %ready.count, align 4
  %803 = load <8 x i1>, ptr %runnable.mask, align 1
  %804 = or <8 x i1> %803, %734
  store <8 x i1> %804, ptr %runnable.mask, align 1
  %805 = load i32, ptr %current.token, align 4
  %806 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %736)
  %807 = load i32, ptr %ready.count, align 4
  %808 = icmp uge i32 %807, 8
  %809 = and i1 %806, %808
  br i1 %809, label %ready.overflow.trap94, label %ready.overflow.resume95

ready.overflow.trap94:                            ; preds = %ready.overflow.resume93
  call void @llvm.trap()
  unreachable

ready.overflow.resume95:                          ; preds = %ready.overflow.resume93
  %810 = select i1 %806, i32 %807, i32 0
  %811 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %810
  %812 = load <8 x i1>, ptr %811, align 1
  %813 = select i1 %806, <8 x i1> %736, <8 x i1> %812
  store <8 x i1> %813, ptr %811, align 1
  %814 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %810
  %815 = load i32, ptr %814, align 4
  %816 = select i1 %806, i32 10, i32 %815
  store i32 %816, ptr %814, align 4
  %817 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %810
  %818 = load i32, ptr %817, align 4
  %819 = select i1 %806, i32 %805, i32 %818
  store i32 %819, ptr %817, align 4
  %820 = add i32 %807, 1
  %821 = select i1 %806, i32 %820, i32 %807
  store i32 %821, ptr %ready.count, align 4
  %822 = load <8 x i1>, ptr %runnable.mask, align 1
  %823 = or <8 x i1> %822, %736
  store <8 x i1> %823, ptr %runnable.mask, align 1
  br label %scheduler.loop

varying.coherent.true96:                          ; preds = %varying.coherent89
  store <8 x i1> %convergence.cascade.result86, ptr %current.mask, align 1
  %824 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result86)
  br i1 %824, label %schedule.9, label %scheduler.loop

varying.coherent.false97:                         ; preds = %varying.coherent89
  store <8 x i1> %convergence.cascade.result86, ptr %current.mask, align 1
  %825 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result86)
  br i1 %825, label %schedule.10, label %scheduler.loop

convergence.cascade105:                           ; preds = %convergence.cascade105, %schedule.10
  %convergence.cascade.flow109 = phi <8 x i1> [ %312, %schedule.10 ], [ %868, %convergence.cascade105 ]
  %convergence.cascade.depth110 = phi i32 [ 0, %schedule.10 ], [ %869, %convergence.cascade105 ]
  %826 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow109)
  %827 = load i32, ptr %current.token, align 4
  %828 = icmp ne i32 %827, 0
  %829 = and i1 %826, %828
  %830 = sub i32 %827, 1
  %831 = select i1 %829, i32 %830, i32 0
  %832 = load i8, ptr %frame.active, align 1
  %833 = trunc i32 %831 to i8
  %834 = shl i8 1, %833
  %835 = and i8 %832, %834
  %836 = icmp ne i8 %835, 0
  %837 = load <8 x i32>, ptr %frame.static.id, align 32
  %838 = extractelement <8 x i32> %837, i32 %831
  %convergence.target.pointer111 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %838
  %convergence.dynamic.target112 = load i32, ptr %convergence.target.pointer111, align 4
  %839 = icmp eq i32 %convergence.dynamic.target112, 10
  %840 = and i1 %836, %839
  %841 = and i1 %829, %840
  %842 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %831
  %843 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %831
  %844 = load <8 x i1>, ptr %842, align 1
  %845 = load <8 x i1>, ptr %843, align 1
  %846 = or <8 x i1> %845, %convergence.cascade.flow109
  %847 = load <8 x i1>, ptr %live.mask, align 1
  %848 = and <8 x i1> %844, %847
  %849 = icmp eq <8 x i1> %846, %848
  %850 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %849)
  %851 = and i1 %841, %850
  %852 = select i1 %851, <8 x i1> zeroinitializer, <8 x i1> %846
  %853 = select i1 %841, <8 x i1> %852, <8 x i1> %845
  store <8 x i1> %853, ptr %843, align 1
  %854 = select i1 %851, <8 x i1> zeroinitializer, <8 x i1> %844
  store <8 x i1> %854, ptr %842, align 1
  %855 = trunc i32 %831 to i8
  %856 = shl i8 1, %855
  %857 = xor i8 %856, -1
  %858 = and i8 %832, %857
  %859 = select i1 %851, i8 %858, i8 %832
  store i8 %859, ptr %frame.active, align 1
  %.splatinsert113 = insertelement <8 x i1> poison, i1 %841, i64 0
  %.splat114 = shufflevector <8 x i1> %.splatinsert113, <8 x i1> poison, <8 x i32> zeroinitializer
  %860 = and <8 x i1> %convergence.cascade.flow109, %.splat114
  %861 = load <8 x i1>, ptr %runnable.mask, align 1
  %862 = xor <8 x i1> %860, splat (i1 true)
  %863 = and <8 x i1> %861, %862
  store <8 x i1> %863, ptr %runnable.mask, align 1
  %.splatinsert115 = insertelement <8 x i1> poison, i1 %851, i64 0
  %.splat116 = shufflevector <8 x i1> %.splatinsert115, <8 x i1> poison, <8 x i32> zeroinitializer
  %864 = select <8 x i1> %.splat116, <8 x i1> %846, <8 x i1> zeroinitializer
  %865 = load <8 x i32>, ptr %frame.parent.token, align 32
  %866 = extractelement <8 x i32> %865, i32 %831
  %867 = select i1 %851, i32 %866, i32 %827
  store i32 %867, ptr %current.token, align 4
  %.splatinsert117 = insertelement <8 x i1> poison, i1 %841, i64 0
  %.splat118 = shufflevector <8 x i1> %.splatinsert117, <8 x i1> poison, <8 x i32> zeroinitializer
  %868 = select <8 x i1> %.splat118, <8 x i1> %864, <8 x i1> %convergence.cascade.flow109
  %869 = add i32 %convergence.cascade.depth110, 1
  %870 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %868)
  %871 = icmp ult i32 %869, 8
  %872 = and i1 %870, %871
  %873 = and i1 %841, %872
  %convergence.parent.token119 = load i32, ptr %current.token, align 4
  %convergence.parent.present120 = icmp ne i32 %convergence.parent.token119, 0
  %874 = and i1 %873, %convergence.parent.present120
  br i1 %874, label %convergence.cascade105, label %convergence.cascade.exit106

convergence.cascade.exit106:                      ; preds = %convergence.cascade105, %schedule.10
  %convergence.cascade.result121 = phi <8 x i1> [ %312, %schedule.10 ], [ %868, %convergence.cascade105 ]
  %875 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result121)
  br i1 %875, label %convergence.target.10.ready, label %scheduler.loop

convergence.target.10.ready:                      ; preds = %convergence.cascade.exit106
  %876 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result121)
  %877 = bitcast <8 x i1> %convergence.cascade.result121 to i8
  %878 = call i8 @llvm.cttz.i8(i8 %877, i1 false)
  %879 = zext i8 %878 to i32
  %880 = select i1 %876, i32 %879, i32 0
  %881 = load <8 x i64>, ptr %.slot12, align 64
  %882 = select <8 x i1> %convergence.cascade.result121, <8 x i64> zeroinitializer, <8 x i64> %881
  store <8 x i64> %882, ptr %.slot12, align 64
  store <8 x i1> %convergence.cascade.result121, ptr %current.mask, align 1
  %883 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result121)
  br i1 %883, label %schedule.11, label %scheduler.loop

varying.divergent123:                             ; preds = %schedule.11
  %884 = load i32, ptr %current.token, align 4
  %885 = icmp ne i32 %884, 0
  %886 = sub i32 %884, 1
  %887 = select i1 %885, i32 %886, i32 0
  %888 = load i8, ptr %frame.active, align 1
  %889 = trunc i32 %887 to i8
  %890 = shl i8 1, %889
  %891 = and i8 %888, %890
  %892 = icmp ne i8 %891, 0
  %893 = load <8 x i32>, ptr %frame.static.id, align 32
  %894 = extractelement <8 x i32> %893, i32 %887
  %895 = icmp eq i32 %894, 3
  %896 = and i1 %892, %895
  %897 = and i1 %885, %896
  %898 = xor i1 %897, true
  %899 = and i1 true, %898
  %900 = xor i8 %888, -1
  %901 = icmp ne i8 %900, 0
  %902 = xor i1 %901, true
  %903 = and i1 %899, %902
  br i1 %903, label %convergence.overflow.trap125, label %convergence.overflow.resume126

varying.coherent124:                              ; preds = %schedule.11
  br i1 %323, label %varying.coherent.true131, label %varying.coherent.false132

convergence.overflow.trap125:                     ; preds = %varying.divergent123
  call void @llvm.trap()
  unreachable

convergence.overflow.resume126:                   ; preds = %varying.divergent123
  %904 = call i8 @llvm.cttz.i8(i8 %900, i1 false)
  %905 = zext i8 %904 to i32
  %906 = select i1 %901, i32 %905, i32 0
  %907 = trunc i32 %906 to i8
  %908 = shl i8 1, %907
  %909 = or i8 %888, %908
  %910 = select i1 %899, i8 %909, i8 %888
  store i8 %910, ptr %frame.active, align 1
  %911 = load <8 x i32>, ptr %frame.static.id, align 32
  %912 = extractelement <8 x i32> %911, i32 %906
  %913 = select i1 %899, i32 3, i32 %912
  %914 = load <8 x i32>, ptr %frame.static.id, align 32
  %915 = insertelement <8 x i32> %914, i32 %913, i32 %906
  store <8 x i32> %915, ptr %frame.static.id, align 32
  %916 = load <8 x i32>, ptr %frame.parent.token, align 32
  %917 = extractelement <8 x i32> %916, i32 %906
  %918 = select i1 %899, i32 %884, i32 %917
  %919 = load <8 x i32>, ptr %frame.parent.token, align 32
  %920 = insertelement <8 x i32> %919, i32 %918, i32 %906
  store <8 x i32> %920, ptr %frame.parent.token, align 32
  %921 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %906
  %922 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %906
  %923 = load <8 x i1>, ptr %921, align 1
  %924 = load <8 x i1>, ptr %922, align 1
  %925 = select i1 %899, <8 x i1> %313, <8 x i1> %923
  store <8 x i1> %925, ptr %921, align 1
  %926 = select i1 %899, <8 x i1> zeroinitializer, <8 x i1> %924
  store <8 x i1> %926, ptr %922, align 1
  %927 = add i32 %906, 1
  %928 = select i1 %897, i32 %884, i32 %927
  %929 = select i1 true, i32 %928, i32 %884
  store i32 %929, ptr %current.token, align 4
  %930 = load i32, ptr %current.token, align 4
  %931 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %320)
  %932 = load i32, ptr %ready.count, align 4
  %933 = icmp uge i32 %932, 8
  %934 = and i1 %931, %933
  br i1 %934, label %ready.overflow.trap127, label %ready.overflow.resume128

ready.overflow.trap127:                           ; preds = %convergence.overflow.resume126
  call void @llvm.trap()
  unreachable

ready.overflow.resume128:                         ; preds = %convergence.overflow.resume126
  %935 = select i1 %931, i32 %932, i32 0
  %936 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %935
  %937 = load <8 x i1>, ptr %936, align 1
  %938 = select i1 %931, <8 x i1> %320, <8 x i1> %937
  store <8 x i1> %938, ptr %936, align 1
  %939 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %935
  %940 = load i32, ptr %939, align 4
  %941 = select i1 %931, i32 12, i32 %940
  store i32 %941, ptr %939, align 4
  %942 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %935
  %943 = load i32, ptr %942, align 4
  %944 = select i1 %931, i32 %930, i32 %943
  store i32 %944, ptr %942, align 4
  %945 = add i32 %932, 1
  %946 = select i1 %931, i32 %945, i32 %932
  store i32 %946, ptr %ready.count, align 4
  %947 = load <8 x i1>, ptr %runnable.mask, align 1
  %948 = or <8 x i1> %947, %320
  store <8 x i1> %948, ptr %runnable.mask, align 1
  %949 = load i32, ptr %current.token, align 4
  %950 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %322)
  %951 = load i32, ptr %ready.count, align 4
  %952 = icmp uge i32 %951, 8
  %953 = and i1 %950, %952
  br i1 %953, label %ready.overflow.trap129, label %ready.overflow.resume130

ready.overflow.trap129:                           ; preds = %ready.overflow.resume128
  call void @llvm.trap()
  unreachable

ready.overflow.resume130:                         ; preds = %ready.overflow.resume128
  %954 = select i1 %950, i32 %951, i32 0
  %955 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %954
  %956 = load <8 x i1>, ptr %955, align 1
  %957 = select i1 %950, <8 x i1> %322, <8 x i1> %956
  store <8 x i1> %957, ptr %955, align 1
  %958 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %954
  %959 = load i32, ptr %958, align 4
  %960 = select i1 %950, i32 13, i32 %959
  store i32 %960, ptr %958, align 4
  %961 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %954
  %962 = load i32, ptr %961, align 4
  %963 = select i1 %950, i32 %949, i32 %962
  store i32 %963, ptr %961, align 4
  %964 = add i32 %951, 1
  %965 = select i1 %950, i32 %964, i32 %951
  store i32 %965, ptr %ready.count, align 4
  %966 = load <8 x i1>, ptr %runnable.mask, align 1
  %967 = or <8 x i1> %966, %322
  store <8 x i1> %967, ptr %runnable.mask, align 1
  br label %scheduler.loop

varying.coherent.true131:                         ; preds = %varying.coherent124
  store <8 x i1> %313, ptr %current.mask, align 1
  %968 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %313)
  br i1 %968, label %schedule.12, label %scheduler.loop

varying.coherent.false132:                        ; preds = %varying.coherent124
  store <8 x i1> %313, ptr %current.mask, align 1
  %969 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %313)
  br i1 %969, label %schedule.13, label %scheduler.loop

convergence.cascade154:                           ; preds = %convergence.cascade154, %schedule.13
  %convergence.cascade.flow158 = phi <8 x i1> [ %378, %schedule.13 ], [ %1012, %convergence.cascade154 ]
  %convergence.cascade.depth159 = phi i32 [ 0, %schedule.13 ], [ %1013, %convergence.cascade154 ]
  %970 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow158)
  %971 = load i32, ptr %current.token, align 4
  %972 = icmp ne i32 %971, 0
  %973 = and i1 %970, %972
  %974 = sub i32 %971, 1
  %975 = select i1 %973, i32 %974, i32 0
  %976 = load i8, ptr %frame.active, align 1
  %977 = trunc i32 %975 to i8
  %978 = shl i8 1, %977
  %979 = and i8 %976, %978
  %980 = icmp ne i8 %979, 0
  %981 = load <8 x i32>, ptr %frame.static.id, align 32
  %982 = extractelement <8 x i32> %981, i32 %975
  %convergence.target.pointer160 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %982
  %convergence.dynamic.target161 = load i32, ptr %convergence.target.pointer160, align 4
  %983 = icmp eq i32 %convergence.dynamic.target161, 13
  %984 = and i1 %980, %983
  %985 = and i1 %973, %984
  %986 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %975
  %987 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %975
  %988 = load <8 x i1>, ptr %986, align 1
  %989 = load <8 x i1>, ptr %987, align 1
  %990 = or <8 x i1> %989, %convergence.cascade.flow158
  %991 = load <8 x i1>, ptr %live.mask, align 1
  %992 = and <8 x i1> %988, %991
  %993 = icmp eq <8 x i1> %990, %992
  %994 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %993)
  %995 = and i1 %985, %994
  %996 = select i1 %995, <8 x i1> zeroinitializer, <8 x i1> %990
  %997 = select i1 %985, <8 x i1> %996, <8 x i1> %989
  store <8 x i1> %997, ptr %987, align 1
  %998 = select i1 %995, <8 x i1> zeroinitializer, <8 x i1> %988
  store <8 x i1> %998, ptr %986, align 1
  %999 = trunc i32 %975 to i8
  %1000 = shl i8 1, %999
  %1001 = xor i8 %1000, -1
  %1002 = and i8 %976, %1001
  %1003 = select i1 %995, i8 %1002, i8 %976
  store i8 %1003, ptr %frame.active, align 1
  %.splatinsert162 = insertelement <8 x i1> poison, i1 %985, i64 0
  %.splat163 = shufflevector <8 x i1> %.splatinsert162, <8 x i1> poison, <8 x i32> zeroinitializer
  %1004 = and <8 x i1> %convergence.cascade.flow158, %.splat163
  %1005 = load <8 x i1>, ptr %runnable.mask, align 1
  %1006 = xor <8 x i1> %1004, splat (i1 true)
  %1007 = and <8 x i1> %1005, %1006
  store <8 x i1> %1007, ptr %runnable.mask, align 1
  %.splatinsert164 = insertelement <8 x i1> poison, i1 %995, i64 0
  %.splat165 = shufflevector <8 x i1> %.splatinsert164, <8 x i1> poison, <8 x i32> zeroinitializer
  %1008 = select <8 x i1> %.splat165, <8 x i1> %990, <8 x i1> zeroinitializer
  %1009 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1010 = extractelement <8 x i32> %1009, i32 %975
  %1011 = select i1 %995, i32 %1010, i32 %971
  store i32 %1011, ptr %current.token, align 4
  %.splatinsert166 = insertelement <8 x i1> poison, i1 %985, i64 0
  %.splat167 = shufflevector <8 x i1> %.splatinsert166, <8 x i1> poison, <8 x i32> zeroinitializer
  %1012 = select <8 x i1> %.splat167, <8 x i1> %1008, <8 x i1> %convergence.cascade.flow158
  %1013 = add i32 %convergence.cascade.depth159, 1
  %1014 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1012)
  %1015 = icmp ult i32 %1013, 8
  %1016 = and i1 %1014, %1015
  %1017 = and i1 %985, %1016
  %convergence.parent.token168 = load i32, ptr %current.token, align 4
  %convergence.parent.present169 = icmp ne i32 %convergence.parent.token168, 0
  %1018 = and i1 %1017, %convergence.parent.present169
  br i1 %1018, label %convergence.cascade154, label %convergence.cascade.exit155

convergence.cascade.exit155:                      ; preds = %convergence.cascade154, %schedule.13
  %convergence.cascade.result170 = phi <8 x i1> [ %378, %schedule.13 ], [ %1012, %convergence.cascade154 ]
  %1019 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result170)
  br i1 %1019, label %convergence.target.13.ready, label %scheduler.loop

convergence.target.13.ready:                      ; preds = %convergence.cascade.exit155
  %1020 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result170)
  %1021 = bitcast <8 x i1> %convergence.cascade.result170 to i8
  %1022 = call i8 @llvm.cttz.i8(i8 %1021, i1 false)
  %1023 = zext i8 %1022 to i32
  %1024 = select i1 %1020, i32 %1023, i32 0
  %.spill.load171 = load <8 x i1>, ptr %.spill5, align 1
  %1025 = and <8 x i1> %convergence.cascade.result170, %.spill.load171
  %1026 = xor <8 x i1> %.spill.load171, splat (i1 true)
  %1027 = and <8 x i1> %convergence.cascade.result170, %1026
  %1028 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1025)
  %1029 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1027)
  %1030 = and i1 %1028, %1029
  br i1 %1030, label %varying.divergent172, label %varying.coherent173

varying.divergent172:                             ; preds = %convergence.target.13.ready
  %1031 = load i32, ptr %current.token, align 4
  %1032 = icmp ne i32 %1031, 0
  %1033 = sub i32 %1031, 1
  %1034 = select i1 %1032, i32 %1033, i32 0
  %1035 = load i8, ptr %frame.active, align 1
  %1036 = trunc i32 %1034 to i8
  %1037 = shl i8 1, %1036
  %1038 = and i8 %1035, %1037
  %1039 = icmp ne i8 %1038, 0
  %1040 = load <8 x i32>, ptr %frame.static.id, align 32
  %1041 = extractelement <8 x i32> %1040, i32 %1034
  %1042 = icmp eq i32 %1041, 4
  %1043 = and i1 %1039, %1042
  %1044 = and i1 %1032, %1043
  %1045 = xor i1 %1044, true
  %1046 = and i1 true, %1045
  %1047 = xor i8 %1035, -1
  %1048 = icmp ne i8 %1047, 0
  %1049 = xor i1 %1048, true
  %1050 = and i1 %1046, %1049
  br i1 %1050, label %convergence.overflow.trap174, label %convergence.overflow.resume175

varying.coherent173:                              ; preds = %convergence.target.13.ready
  br i1 %1028, label %varying.coherent.true180, label %varying.coherent.false181

convergence.overflow.trap174:                     ; preds = %varying.divergent172
  call void @llvm.trap()
  unreachable

convergence.overflow.resume175:                   ; preds = %varying.divergent172
  %1051 = call i8 @llvm.cttz.i8(i8 %1047, i1 false)
  %1052 = zext i8 %1051 to i32
  %1053 = select i1 %1048, i32 %1052, i32 0
  %1054 = trunc i32 %1053 to i8
  %1055 = shl i8 1, %1054
  %1056 = or i8 %1035, %1055
  %1057 = select i1 %1046, i8 %1056, i8 %1035
  store i8 %1057, ptr %frame.active, align 1
  %1058 = load <8 x i32>, ptr %frame.static.id, align 32
  %1059 = extractelement <8 x i32> %1058, i32 %1053
  %1060 = select i1 %1046, i32 4, i32 %1059
  %1061 = load <8 x i32>, ptr %frame.static.id, align 32
  %1062 = insertelement <8 x i32> %1061, i32 %1060, i32 %1053
  store <8 x i32> %1062, ptr %frame.static.id, align 32
  %1063 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1064 = extractelement <8 x i32> %1063, i32 %1053
  %1065 = select i1 %1046, i32 %1031, i32 %1064
  %1066 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1067 = insertelement <8 x i32> %1066, i32 %1065, i32 %1053
  store <8 x i32> %1067, ptr %frame.parent.token, align 32
  %1068 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1053
  %1069 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1053
  %1070 = load <8 x i1>, ptr %1068, align 1
  %1071 = load <8 x i1>, ptr %1069, align 1
  %1072 = select i1 %1046, <8 x i1> %convergence.cascade.result170, <8 x i1> %1070
  store <8 x i1> %1072, ptr %1068, align 1
  %1073 = select i1 %1046, <8 x i1> zeroinitializer, <8 x i1> %1071
  store <8 x i1> %1073, ptr %1069, align 1
  %1074 = add i32 %1053, 1
  %1075 = select i1 %1044, i32 %1031, i32 %1074
  %1076 = select i1 true, i32 %1075, i32 %1031
  store i32 %1076, ptr %current.token, align 4
  %1077 = load i32, ptr %current.token, align 4
  %1078 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1025)
  %1079 = load i32, ptr %ready.count, align 4
  %1080 = icmp uge i32 %1079, 8
  %1081 = and i1 %1078, %1080
  br i1 %1081, label %ready.overflow.trap176, label %ready.overflow.resume177

ready.overflow.trap176:                           ; preds = %convergence.overflow.resume175
  call void @llvm.trap()
  unreachable

ready.overflow.resume177:                         ; preds = %convergence.overflow.resume175
  %1082 = select i1 %1078, i32 %1079, i32 0
  %1083 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1082
  %1084 = load <8 x i1>, ptr %1083, align 1
  %1085 = select i1 %1078, <8 x i1> %1025, <8 x i1> %1084
  store <8 x i1> %1085, ptr %1083, align 1
  %1086 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1082
  %1087 = load i32, ptr %1086, align 4
  %1088 = select i1 %1078, i32 14, i32 %1087
  store i32 %1088, ptr %1086, align 4
  %1089 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1082
  %1090 = load i32, ptr %1089, align 4
  %1091 = select i1 %1078, i32 %1077, i32 %1090
  store i32 %1091, ptr %1089, align 4
  %1092 = add i32 %1079, 1
  %1093 = select i1 %1078, i32 %1092, i32 %1079
  store i32 %1093, ptr %ready.count, align 4
  %1094 = load <8 x i1>, ptr %runnable.mask, align 1
  %1095 = or <8 x i1> %1094, %1025
  store <8 x i1> %1095, ptr %runnable.mask, align 1
  %1096 = load i32, ptr %current.token, align 4
  %1097 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1027)
  %1098 = load i32, ptr %ready.count, align 4
  %1099 = icmp uge i32 %1098, 8
  %1100 = and i1 %1097, %1099
  br i1 %1100, label %ready.overflow.trap178, label %ready.overflow.resume179

ready.overflow.trap178:                           ; preds = %ready.overflow.resume177
  call void @llvm.trap()
  unreachable

ready.overflow.resume179:                         ; preds = %ready.overflow.resume177
  %1101 = select i1 %1097, i32 %1098, i32 0
  %1102 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1101
  %1103 = load <8 x i1>, ptr %1102, align 1
  %1104 = select i1 %1097, <8 x i1> %1027, <8 x i1> %1103
  store <8 x i1> %1104, ptr %1102, align 1
  %1105 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1101
  %1106 = load i32, ptr %1105, align 4
  %1107 = select i1 %1097, i32 15, i32 %1106
  store i32 %1107, ptr %1105, align 4
  %1108 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1101
  %1109 = load i32, ptr %1108, align 4
  %1110 = select i1 %1097, i32 %1096, i32 %1109
  store i32 %1110, ptr %1108, align 4
  %1111 = add i32 %1098, 1
  %1112 = select i1 %1097, i32 %1111, i32 %1098
  store i32 %1112, ptr %ready.count, align 4
  %1113 = load <8 x i1>, ptr %runnable.mask, align 1
  %1114 = or <8 x i1> %1113, %1027
  store <8 x i1> %1114, ptr %runnable.mask, align 1
  br label %scheduler.loop

varying.coherent.true180:                         ; preds = %varying.coherent173
  store <8 x i1> %convergence.cascade.result170, ptr %current.mask, align 1
  %1115 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result170)
  br i1 %1115, label %schedule.14, label %scheduler.loop

varying.coherent.false181:                        ; preds = %varying.coherent173
  store <8 x i1> %convergence.cascade.result170, ptr %current.mask, align 1
  %1116 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result170)
  br i1 %1116, label %schedule.15, label %scheduler.loop

convergence.cascade203:                           ; preds = %convergence.cascade203, %schedule.15
  %convergence.cascade.flow207 = phi <8 x i1> [ %437, %schedule.15 ], [ %1159, %convergence.cascade203 ]
  %convergence.cascade.depth208 = phi i32 [ 0, %schedule.15 ], [ %1160, %convergence.cascade203 ]
  %1117 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow207)
  %1118 = load i32, ptr %current.token, align 4
  %1119 = icmp ne i32 %1118, 0
  %1120 = and i1 %1117, %1119
  %1121 = sub i32 %1118, 1
  %1122 = select i1 %1120, i32 %1121, i32 0
  %1123 = load i8, ptr %frame.active, align 1
  %1124 = trunc i32 %1122 to i8
  %1125 = shl i8 1, %1124
  %1126 = and i8 %1123, %1125
  %1127 = icmp ne i8 %1126, 0
  %1128 = load <8 x i32>, ptr %frame.static.id, align 32
  %1129 = extractelement <8 x i32> %1128, i32 %1122
  %convergence.target.pointer209 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %1129
  %convergence.dynamic.target210 = load i32, ptr %convergence.target.pointer209, align 4
  %1130 = icmp eq i32 %convergence.dynamic.target210, 15
  %1131 = and i1 %1127, %1130
  %1132 = and i1 %1120, %1131
  %1133 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1122
  %1134 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1122
  %1135 = load <8 x i1>, ptr %1133, align 1
  %1136 = load <8 x i1>, ptr %1134, align 1
  %1137 = or <8 x i1> %1136, %convergence.cascade.flow207
  %1138 = load <8 x i1>, ptr %live.mask, align 1
  %1139 = and <8 x i1> %1135, %1138
  %1140 = icmp eq <8 x i1> %1137, %1139
  %1141 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1140)
  %1142 = and i1 %1132, %1141
  %1143 = select i1 %1142, <8 x i1> zeroinitializer, <8 x i1> %1137
  %1144 = select i1 %1132, <8 x i1> %1143, <8 x i1> %1136
  store <8 x i1> %1144, ptr %1134, align 1
  %1145 = select i1 %1142, <8 x i1> zeroinitializer, <8 x i1> %1135
  store <8 x i1> %1145, ptr %1133, align 1
  %1146 = trunc i32 %1122 to i8
  %1147 = shl i8 1, %1146
  %1148 = xor i8 %1147, -1
  %1149 = and i8 %1123, %1148
  %1150 = select i1 %1142, i8 %1149, i8 %1123
  store i8 %1150, ptr %frame.active, align 1
  %.splatinsert211 = insertelement <8 x i1> poison, i1 %1132, i64 0
  %.splat212 = shufflevector <8 x i1> %.splatinsert211, <8 x i1> poison, <8 x i32> zeroinitializer
  %1151 = and <8 x i1> %convergence.cascade.flow207, %.splat212
  %1152 = load <8 x i1>, ptr %runnable.mask, align 1
  %1153 = xor <8 x i1> %1151, splat (i1 true)
  %1154 = and <8 x i1> %1152, %1153
  store <8 x i1> %1154, ptr %runnable.mask, align 1
  %.splatinsert213 = insertelement <8 x i1> poison, i1 %1142, i64 0
  %.splat214 = shufflevector <8 x i1> %.splatinsert213, <8 x i1> poison, <8 x i32> zeroinitializer
  %1155 = select <8 x i1> %.splat214, <8 x i1> %1137, <8 x i1> zeroinitializer
  %1156 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1157 = extractelement <8 x i32> %1156, i32 %1122
  %1158 = select i1 %1142, i32 %1157, i32 %1118
  store i32 %1158, ptr %current.token, align 4
  %.splatinsert215 = insertelement <8 x i1> poison, i1 %1132, i64 0
  %.splat216 = shufflevector <8 x i1> %.splatinsert215, <8 x i1> poison, <8 x i32> zeroinitializer
  %1159 = select <8 x i1> %.splat216, <8 x i1> %1155, <8 x i1> %convergence.cascade.flow207
  %1160 = add i32 %convergence.cascade.depth208, 1
  %1161 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1159)
  %1162 = icmp ult i32 %1160, 8
  %1163 = and i1 %1161, %1162
  %1164 = and i1 %1132, %1163
  %convergence.parent.token217 = load i32, ptr %current.token, align 4
  %convergence.parent.present218 = icmp ne i32 %convergence.parent.token217, 0
  %1165 = and i1 %1164, %convergence.parent.present218
  br i1 %1165, label %convergence.cascade203, label %convergence.cascade.exit204

convergence.cascade.exit204:                      ; preds = %convergence.cascade203, %schedule.15
  %convergence.cascade.result219 = phi <8 x i1> [ %437, %schedule.15 ], [ %1159, %convergence.cascade203 ]
  %1166 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result219)
  br i1 %1166, label %convergence.target.15.ready, label %scheduler.loop

convergence.target.15.ready:                      ; preds = %convergence.cascade.exit204
  %1167 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result219)
  %1168 = bitcast <8 x i1> %convergence.cascade.result219 to i8
  %1169 = call i8 @llvm.cttz.i8(i8 %1168, i1 false)
  %1170 = zext i8 %1169 to i32
  %1171 = select i1 %1167, i32 %1170, i32 0
  %1172 = load <8 x i1>, ptr %live.mask, align 1
  %1173 = xor <8 x i1> %convergence.cascade.result219, splat (i1 true)
  %1174 = and <8 x i1> %1172, %1173
  store <8 x i1> %1174, ptr %live.mask, align 1
  %1175 = load <8 x i1>, ptr %runnable.mask, align 1
  %1176 = xor <8 x i1> %convergence.cascade.result219, splat (i1 true)
  %1177 = and <8 x i1> %1175, %1176
  store <8 x i1> %1177, ptr %runnable.mask, align 1
  %return.active.frames = load i8, ptr %frame.active, align 1
  %return.frames.present = icmp ne i8 %return.active.frames, 0
  br i1 %return.frames.present, label %return.frame.cleanup, label %return.frame.cleanup.done

return.frame.cleanup:                             ; preds = %convergence.target.15.ready
  %1178 = load i8, ptr %frame.active, align 1
  %1179 = and i8 %1178, 1
  %1180 = icmp ne i8 %1179, 0
  %1181 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 0
  %1182 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 0
  %1183 = load <8 x i1>, ptr %1181, align 1
  %1184 = load <8 x i1>, ptr %1182, align 1
  %1185 = and <8 x i1> %1183, %1174
  %1186 = icmp eq <8 x i1> %1184, %1185
  %1187 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1186)
  %1188 = and i1 %1180, %1187
  %.splatinsert220 = insertelement <8 x i1> poison, i1 %1188, i64 0
  %.splat221 = shufflevector <8 x i1> %.splatinsert220, <8 x i1> poison, <8 x i32> zeroinitializer
  %1189 = select <8 x i1> %.splat221, <8 x i1> %1184, <8 x i1> zeroinitializer
  %1190 = select i1 %1188, <8 x i1> zeroinitializer, <8 x i1> %1185
  store <8 x i1> %1190, ptr %1181, align 1
  %1191 = select i1 %1188, <8 x i1> zeroinitializer, <8 x i1> %1184
  store <8 x i1> %1191, ptr %1182, align 1
  %1192 = and i8 %1178, -2
  %1193 = select i1 %1188, i8 %1192, i8 %1178
  store i8 %1193, ptr %frame.active, align 1
  %1194 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1195 = extractelement <8 x i32> %1194, i32 0
  %1196 = load <8 x i32>, ptr %frame.static.id, align 32
  %1197 = extractelement <8 x i32> %1196, i32 0
  %convergence.target.pointer222 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %1197
  %convergence.dynamic.target223 = load i32, ptr %convergence.target.pointer222, align 4
  %1198 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1189)
  %1199 = load i32, ptr %ready.count, align 4
  %1200 = icmp uge i32 %1199, 8
  %1201 = and i1 %1198, %1200
  br i1 %1201, label %ready.overflow.trap224, label %ready.overflow.resume225

return.frame.cleanup.done:                        ; preds = %ready.overflow.resume267, %convergence.target.15.ready
  br label %scheduler.loop

ready.overflow.trap224:                           ; preds = %return.frame.cleanup
  call void @llvm.trap()
  unreachable

ready.overflow.resume225:                         ; preds = %return.frame.cleanup
  %1202 = select i1 %1198, i32 %1199, i32 0
  %1203 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1202
  %1204 = load <8 x i1>, ptr %1203, align 1
  %1205 = select i1 %1198, <8 x i1> %1189, <8 x i1> %1204
  store <8 x i1> %1205, ptr %1203, align 1
  %1206 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1202
  %1207 = load i32, ptr %1206, align 4
  %1208 = select i1 %1198, i32 %convergence.dynamic.target223, i32 %1207
  store i32 %1208, ptr %1206, align 4
  %1209 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1202
  %1210 = load i32, ptr %1209, align 4
  %1211 = select i1 %1198, i32 %1195, i32 %1210
  store i32 %1211, ptr %1209, align 4
  %1212 = add i32 %1199, 1
  %1213 = select i1 %1198, i32 %1212, i32 %1199
  store i32 %1213, ptr %ready.count, align 4
  %1214 = load <8 x i1>, ptr %runnable.mask, align 1
  %1215 = or <8 x i1> %1214, %1189
  store <8 x i1> %1215, ptr %runnable.mask, align 1
  %1216 = load i8, ptr %frame.active, align 1
  %1217 = and i8 %1216, 2
  %1218 = icmp ne i8 %1217, 0
  %1219 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 1
  %1220 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 1
  %1221 = load <8 x i1>, ptr %1219, align 1
  %1222 = load <8 x i1>, ptr %1220, align 1
  %1223 = and <8 x i1> %1221, %1174
  %1224 = icmp eq <8 x i1> %1222, %1223
  %1225 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1224)
  %1226 = and i1 %1218, %1225
  %.splatinsert226 = insertelement <8 x i1> poison, i1 %1226, i64 0
  %.splat227 = shufflevector <8 x i1> %.splatinsert226, <8 x i1> poison, <8 x i32> zeroinitializer
  %1227 = select <8 x i1> %.splat227, <8 x i1> %1222, <8 x i1> zeroinitializer
  %1228 = select i1 %1226, <8 x i1> zeroinitializer, <8 x i1> %1223
  store <8 x i1> %1228, ptr %1219, align 1
  %1229 = select i1 %1226, <8 x i1> zeroinitializer, <8 x i1> %1222
  store <8 x i1> %1229, ptr %1220, align 1
  %1230 = and i8 %1216, -3
  %1231 = select i1 %1226, i8 %1230, i8 %1216
  store i8 %1231, ptr %frame.active, align 1
  %1232 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1233 = extractelement <8 x i32> %1232, i32 1
  %1234 = load <8 x i32>, ptr %frame.static.id, align 32
  %1235 = extractelement <8 x i32> %1234, i32 1
  %convergence.target.pointer228 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %1235
  %convergence.dynamic.target229 = load i32, ptr %convergence.target.pointer228, align 4
  %1236 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1227)
  %1237 = load i32, ptr %ready.count, align 4
  %1238 = icmp uge i32 %1237, 8
  %1239 = and i1 %1236, %1238
  br i1 %1239, label %ready.overflow.trap230, label %ready.overflow.resume231

ready.overflow.trap230:                           ; preds = %ready.overflow.resume225
  call void @llvm.trap()
  unreachable

ready.overflow.resume231:                         ; preds = %ready.overflow.resume225
  %1240 = select i1 %1236, i32 %1237, i32 0
  %1241 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1240
  %1242 = load <8 x i1>, ptr %1241, align 1
  %1243 = select i1 %1236, <8 x i1> %1227, <8 x i1> %1242
  store <8 x i1> %1243, ptr %1241, align 1
  %1244 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1240
  %1245 = load i32, ptr %1244, align 4
  %1246 = select i1 %1236, i32 %convergence.dynamic.target229, i32 %1245
  store i32 %1246, ptr %1244, align 4
  %1247 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1240
  %1248 = load i32, ptr %1247, align 4
  %1249 = select i1 %1236, i32 %1233, i32 %1248
  store i32 %1249, ptr %1247, align 4
  %1250 = add i32 %1237, 1
  %1251 = select i1 %1236, i32 %1250, i32 %1237
  store i32 %1251, ptr %ready.count, align 4
  %1252 = load <8 x i1>, ptr %runnable.mask, align 1
  %1253 = or <8 x i1> %1252, %1227
  store <8 x i1> %1253, ptr %runnable.mask, align 1
  %1254 = load i8, ptr %frame.active, align 1
  %1255 = and i8 %1254, 4
  %1256 = icmp ne i8 %1255, 0
  %1257 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 2
  %1258 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 2
  %1259 = load <8 x i1>, ptr %1257, align 1
  %1260 = load <8 x i1>, ptr %1258, align 1
  %1261 = and <8 x i1> %1259, %1174
  %1262 = icmp eq <8 x i1> %1260, %1261
  %1263 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1262)
  %1264 = and i1 %1256, %1263
  %.splatinsert232 = insertelement <8 x i1> poison, i1 %1264, i64 0
  %.splat233 = shufflevector <8 x i1> %.splatinsert232, <8 x i1> poison, <8 x i32> zeroinitializer
  %1265 = select <8 x i1> %.splat233, <8 x i1> %1260, <8 x i1> zeroinitializer
  %1266 = select i1 %1264, <8 x i1> zeroinitializer, <8 x i1> %1261
  store <8 x i1> %1266, ptr %1257, align 1
  %1267 = select i1 %1264, <8 x i1> zeroinitializer, <8 x i1> %1260
  store <8 x i1> %1267, ptr %1258, align 1
  %1268 = and i8 %1254, -5
  %1269 = select i1 %1264, i8 %1268, i8 %1254
  store i8 %1269, ptr %frame.active, align 1
  %1270 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1271 = extractelement <8 x i32> %1270, i32 2
  %1272 = load <8 x i32>, ptr %frame.static.id, align 32
  %1273 = extractelement <8 x i32> %1272, i32 2
  %convergence.target.pointer234 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %1273
  %convergence.dynamic.target235 = load i32, ptr %convergence.target.pointer234, align 4
  %1274 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1265)
  %1275 = load i32, ptr %ready.count, align 4
  %1276 = icmp uge i32 %1275, 8
  %1277 = and i1 %1274, %1276
  br i1 %1277, label %ready.overflow.trap236, label %ready.overflow.resume237

ready.overflow.trap236:                           ; preds = %ready.overflow.resume231
  call void @llvm.trap()
  unreachable

ready.overflow.resume237:                         ; preds = %ready.overflow.resume231
  %1278 = select i1 %1274, i32 %1275, i32 0
  %1279 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1278
  %1280 = load <8 x i1>, ptr %1279, align 1
  %1281 = select i1 %1274, <8 x i1> %1265, <8 x i1> %1280
  store <8 x i1> %1281, ptr %1279, align 1
  %1282 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1278
  %1283 = load i32, ptr %1282, align 4
  %1284 = select i1 %1274, i32 %convergence.dynamic.target235, i32 %1283
  store i32 %1284, ptr %1282, align 4
  %1285 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1278
  %1286 = load i32, ptr %1285, align 4
  %1287 = select i1 %1274, i32 %1271, i32 %1286
  store i32 %1287, ptr %1285, align 4
  %1288 = add i32 %1275, 1
  %1289 = select i1 %1274, i32 %1288, i32 %1275
  store i32 %1289, ptr %ready.count, align 4
  %1290 = load <8 x i1>, ptr %runnable.mask, align 1
  %1291 = or <8 x i1> %1290, %1265
  store <8 x i1> %1291, ptr %runnable.mask, align 1
  %1292 = load i8, ptr %frame.active, align 1
  %1293 = and i8 %1292, 8
  %1294 = icmp ne i8 %1293, 0
  %1295 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 3
  %1296 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 3
  %1297 = load <8 x i1>, ptr %1295, align 1
  %1298 = load <8 x i1>, ptr %1296, align 1
  %1299 = and <8 x i1> %1297, %1174
  %1300 = icmp eq <8 x i1> %1298, %1299
  %1301 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1300)
  %1302 = and i1 %1294, %1301
  %.splatinsert238 = insertelement <8 x i1> poison, i1 %1302, i64 0
  %.splat239 = shufflevector <8 x i1> %.splatinsert238, <8 x i1> poison, <8 x i32> zeroinitializer
  %1303 = select <8 x i1> %.splat239, <8 x i1> %1298, <8 x i1> zeroinitializer
  %1304 = select i1 %1302, <8 x i1> zeroinitializer, <8 x i1> %1299
  store <8 x i1> %1304, ptr %1295, align 1
  %1305 = select i1 %1302, <8 x i1> zeroinitializer, <8 x i1> %1298
  store <8 x i1> %1305, ptr %1296, align 1
  %1306 = and i8 %1292, -9
  %1307 = select i1 %1302, i8 %1306, i8 %1292
  store i8 %1307, ptr %frame.active, align 1
  %1308 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1309 = extractelement <8 x i32> %1308, i32 3
  %1310 = load <8 x i32>, ptr %frame.static.id, align 32
  %1311 = extractelement <8 x i32> %1310, i32 3
  %convergence.target.pointer240 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %1311
  %convergence.dynamic.target241 = load i32, ptr %convergence.target.pointer240, align 4
  %1312 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1303)
  %1313 = load i32, ptr %ready.count, align 4
  %1314 = icmp uge i32 %1313, 8
  %1315 = and i1 %1312, %1314
  br i1 %1315, label %ready.overflow.trap242, label %ready.overflow.resume243

ready.overflow.trap242:                           ; preds = %ready.overflow.resume237
  call void @llvm.trap()
  unreachable

ready.overflow.resume243:                         ; preds = %ready.overflow.resume237
  %1316 = select i1 %1312, i32 %1313, i32 0
  %1317 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1316
  %1318 = load <8 x i1>, ptr %1317, align 1
  %1319 = select i1 %1312, <8 x i1> %1303, <8 x i1> %1318
  store <8 x i1> %1319, ptr %1317, align 1
  %1320 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1316
  %1321 = load i32, ptr %1320, align 4
  %1322 = select i1 %1312, i32 %convergence.dynamic.target241, i32 %1321
  store i32 %1322, ptr %1320, align 4
  %1323 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1316
  %1324 = load i32, ptr %1323, align 4
  %1325 = select i1 %1312, i32 %1309, i32 %1324
  store i32 %1325, ptr %1323, align 4
  %1326 = add i32 %1313, 1
  %1327 = select i1 %1312, i32 %1326, i32 %1313
  store i32 %1327, ptr %ready.count, align 4
  %1328 = load <8 x i1>, ptr %runnable.mask, align 1
  %1329 = or <8 x i1> %1328, %1303
  store <8 x i1> %1329, ptr %runnable.mask, align 1
  %1330 = load i8, ptr %frame.active, align 1
  %1331 = and i8 %1330, 16
  %1332 = icmp ne i8 %1331, 0
  %1333 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 4
  %1334 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 4
  %1335 = load <8 x i1>, ptr %1333, align 1
  %1336 = load <8 x i1>, ptr %1334, align 1
  %1337 = and <8 x i1> %1335, %1174
  %1338 = icmp eq <8 x i1> %1336, %1337
  %1339 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1338)
  %1340 = and i1 %1332, %1339
  %.splatinsert244 = insertelement <8 x i1> poison, i1 %1340, i64 0
  %.splat245 = shufflevector <8 x i1> %.splatinsert244, <8 x i1> poison, <8 x i32> zeroinitializer
  %1341 = select <8 x i1> %.splat245, <8 x i1> %1336, <8 x i1> zeroinitializer
  %1342 = select i1 %1340, <8 x i1> zeroinitializer, <8 x i1> %1337
  store <8 x i1> %1342, ptr %1333, align 1
  %1343 = select i1 %1340, <8 x i1> zeroinitializer, <8 x i1> %1336
  store <8 x i1> %1343, ptr %1334, align 1
  %1344 = and i8 %1330, -17
  %1345 = select i1 %1340, i8 %1344, i8 %1330
  store i8 %1345, ptr %frame.active, align 1
  %1346 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1347 = extractelement <8 x i32> %1346, i32 4
  %1348 = load <8 x i32>, ptr %frame.static.id, align 32
  %1349 = extractelement <8 x i32> %1348, i32 4
  %convergence.target.pointer246 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %1349
  %convergence.dynamic.target247 = load i32, ptr %convergence.target.pointer246, align 4
  %1350 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1341)
  %1351 = load i32, ptr %ready.count, align 4
  %1352 = icmp uge i32 %1351, 8
  %1353 = and i1 %1350, %1352
  br i1 %1353, label %ready.overflow.trap248, label %ready.overflow.resume249

ready.overflow.trap248:                           ; preds = %ready.overflow.resume243
  call void @llvm.trap()
  unreachable

ready.overflow.resume249:                         ; preds = %ready.overflow.resume243
  %1354 = select i1 %1350, i32 %1351, i32 0
  %1355 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1354
  %1356 = load <8 x i1>, ptr %1355, align 1
  %1357 = select i1 %1350, <8 x i1> %1341, <8 x i1> %1356
  store <8 x i1> %1357, ptr %1355, align 1
  %1358 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1354
  %1359 = load i32, ptr %1358, align 4
  %1360 = select i1 %1350, i32 %convergence.dynamic.target247, i32 %1359
  store i32 %1360, ptr %1358, align 4
  %1361 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1354
  %1362 = load i32, ptr %1361, align 4
  %1363 = select i1 %1350, i32 %1347, i32 %1362
  store i32 %1363, ptr %1361, align 4
  %1364 = add i32 %1351, 1
  %1365 = select i1 %1350, i32 %1364, i32 %1351
  store i32 %1365, ptr %ready.count, align 4
  %1366 = load <8 x i1>, ptr %runnable.mask, align 1
  %1367 = or <8 x i1> %1366, %1341
  store <8 x i1> %1367, ptr %runnable.mask, align 1
  %1368 = load i8, ptr %frame.active, align 1
  %1369 = and i8 %1368, 32
  %1370 = icmp ne i8 %1369, 0
  %1371 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 5
  %1372 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 5
  %1373 = load <8 x i1>, ptr %1371, align 1
  %1374 = load <8 x i1>, ptr %1372, align 1
  %1375 = and <8 x i1> %1373, %1174
  %1376 = icmp eq <8 x i1> %1374, %1375
  %1377 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1376)
  %1378 = and i1 %1370, %1377
  %.splatinsert250 = insertelement <8 x i1> poison, i1 %1378, i64 0
  %.splat251 = shufflevector <8 x i1> %.splatinsert250, <8 x i1> poison, <8 x i32> zeroinitializer
  %1379 = select <8 x i1> %.splat251, <8 x i1> %1374, <8 x i1> zeroinitializer
  %1380 = select i1 %1378, <8 x i1> zeroinitializer, <8 x i1> %1375
  store <8 x i1> %1380, ptr %1371, align 1
  %1381 = select i1 %1378, <8 x i1> zeroinitializer, <8 x i1> %1374
  store <8 x i1> %1381, ptr %1372, align 1
  %1382 = and i8 %1368, -33
  %1383 = select i1 %1378, i8 %1382, i8 %1368
  store i8 %1383, ptr %frame.active, align 1
  %1384 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1385 = extractelement <8 x i32> %1384, i32 5
  %1386 = load <8 x i32>, ptr %frame.static.id, align 32
  %1387 = extractelement <8 x i32> %1386, i32 5
  %convergence.target.pointer252 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %1387
  %convergence.dynamic.target253 = load i32, ptr %convergence.target.pointer252, align 4
  %1388 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1379)
  %1389 = load i32, ptr %ready.count, align 4
  %1390 = icmp uge i32 %1389, 8
  %1391 = and i1 %1388, %1390
  br i1 %1391, label %ready.overflow.trap254, label %ready.overflow.resume255

ready.overflow.trap254:                           ; preds = %ready.overflow.resume249
  call void @llvm.trap()
  unreachable

ready.overflow.resume255:                         ; preds = %ready.overflow.resume249
  %1392 = select i1 %1388, i32 %1389, i32 0
  %1393 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1392
  %1394 = load <8 x i1>, ptr %1393, align 1
  %1395 = select i1 %1388, <8 x i1> %1379, <8 x i1> %1394
  store <8 x i1> %1395, ptr %1393, align 1
  %1396 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1392
  %1397 = load i32, ptr %1396, align 4
  %1398 = select i1 %1388, i32 %convergence.dynamic.target253, i32 %1397
  store i32 %1398, ptr %1396, align 4
  %1399 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1392
  %1400 = load i32, ptr %1399, align 4
  %1401 = select i1 %1388, i32 %1385, i32 %1400
  store i32 %1401, ptr %1399, align 4
  %1402 = add i32 %1389, 1
  %1403 = select i1 %1388, i32 %1402, i32 %1389
  store i32 %1403, ptr %ready.count, align 4
  %1404 = load <8 x i1>, ptr %runnable.mask, align 1
  %1405 = or <8 x i1> %1404, %1379
  store <8 x i1> %1405, ptr %runnable.mask, align 1
  %1406 = load i8, ptr %frame.active, align 1
  %1407 = and i8 %1406, 64
  %1408 = icmp ne i8 %1407, 0
  %1409 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 6
  %1410 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 6
  %1411 = load <8 x i1>, ptr %1409, align 1
  %1412 = load <8 x i1>, ptr %1410, align 1
  %1413 = and <8 x i1> %1411, %1174
  %1414 = icmp eq <8 x i1> %1412, %1413
  %1415 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1414)
  %1416 = and i1 %1408, %1415
  %.splatinsert256 = insertelement <8 x i1> poison, i1 %1416, i64 0
  %.splat257 = shufflevector <8 x i1> %.splatinsert256, <8 x i1> poison, <8 x i32> zeroinitializer
  %1417 = select <8 x i1> %.splat257, <8 x i1> %1412, <8 x i1> zeroinitializer
  %1418 = select i1 %1416, <8 x i1> zeroinitializer, <8 x i1> %1413
  store <8 x i1> %1418, ptr %1409, align 1
  %1419 = select i1 %1416, <8 x i1> zeroinitializer, <8 x i1> %1412
  store <8 x i1> %1419, ptr %1410, align 1
  %1420 = and i8 %1406, -65
  %1421 = select i1 %1416, i8 %1420, i8 %1406
  store i8 %1421, ptr %frame.active, align 1
  %1422 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1423 = extractelement <8 x i32> %1422, i32 6
  %1424 = load <8 x i32>, ptr %frame.static.id, align 32
  %1425 = extractelement <8 x i32> %1424, i32 6
  %convergence.target.pointer258 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %1425
  %convergence.dynamic.target259 = load i32, ptr %convergence.target.pointer258, align 4
  %1426 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1417)
  %1427 = load i32, ptr %ready.count, align 4
  %1428 = icmp uge i32 %1427, 8
  %1429 = and i1 %1426, %1428
  br i1 %1429, label %ready.overflow.trap260, label %ready.overflow.resume261

ready.overflow.trap260:                           ; preds = %ready.overflow.resume255
  call void @llvm.trap()
  unreachable

ready.overflow.resume261:                         ; preds = %ready.overflow.resume255
  %1430 = select i1 %1426, i32 %1427, i32 0
  %1431 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1430
  %1432 = load <8 x i1>, ptr %1431, align 1
  %1433 = select i1 %1426, <8 x i1> %1417, <8 x i1> %1432
  store <8 x i1> %1433, ptr %1431, align 1
  %1434 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1430
  %1435 = load i32, ptr %1434, align 4
  %1436 = select i1 %1426, i32 %convergence.dynamic.target259, i32 %1435
  store i32 %1436, ptr %1434, align 4
  %1437 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1430
  %1438 = load i32, ptr %1437, align 4
  %1439 = select i1 %1426, i32 %1423, i32 %1438
  store i32 %1439, ptr %1437, align 4
  %1440 = add i32 %1427, 1
  %1441 = select i1 %1426, i32 %1440, i32 %1427
  store i32 %1441, ptr %ready.count, align 4
  %1442 = load <8 x i1>, ptr %runnable.mask, align 1
  %1443 = or <8 x i1> %1442, %1417
  store <8 x i1> %1443, ptr %runnable.mask, align 1
  %1444 = load i8, ptr %frame.active, align 1
  %1445 = and i8 %1444, -128
  %1446 = icmp ne i8 %1445, 0
  %1447 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 7
  %1448 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 7
  %1449 = load <8 x i1>, ptr %1447, align 1
  %1450 = load <8 x i1>, ptr %1448, align 1
  %1451 = and <8 x i1> %1449, %1174
  %1452 = icmp eq <8 x i1> %1450, %1451
  %1453 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1452)
  %1454 = and i1 %1446, %1453
  %.splatinsert262 = insertelement <8 x i1> poison, i1 %1454, i64 0
  %.splat263 = shufflevector <8 x i1> %.splatinsert262, <8 x i1> poison, <8 x i32> zeroinitializer
  %1455 = select <8 x i1> %.splat263, <8 x i1> %1450, <8 x i1> zeroinitializer
  %1456 = select i1 %1454, <8 x i1> zeroinitializer, <8 x i1> %1451
  store <8 x i1> %1456, ptr %1447, align 1
  %1457 = select i1 %1454, <8 x i1> zeroinitializer, <8 x i1> %1450
  store <8 x i1> %1457, ptr %1448, align 1
  %1458 = and i8 %1444, 127
  %1459 = select i1 %1454, i8 %1458, i8 %1444
  store i8 %1459, ptr %frame.active, align 1
  %1460 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1461 = extractelement <8 x i32> %1460, i32 7
  %1462 = load <8 x i32>, ptr %frame.static.id, align 32
  %1463 = extractelement <8 x i32> %1462, i32 7
  %convergence.target.pointer264 = getelementptr inbounds [5 x i32], ptr @convergence.targets, i32 0, i32 %1463
  %convergence.dynamic.target265 = load i32, ptr %convergence.target.pointer264, align 4
  %1464 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1455)
  %1465 = load i32, ptr %ready.count, align 4
  %1466 = icmp uge i32 %1465, 8
  %1467 = and i1 %1464, %1466
  br i1 %1467, label %ready.overflow.trap266, label %ready.overflow.resume267

ready.overflow.trap266:                           ; preds = %ready.overflow.resume261
  call void @llvm.trap()
  unreachable

ready.overflow.resume267:                         ; preds = %ready.overflow.resume261
  %1468 = select i1 %1464, i32 %1465, i32 0
  %1469 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1468
  %1470 = load <8 x i1>, ptr %1469, align 1
  %1471 = select i1 %1464, <8 x i1> %1455, <8 x i1> %1470
  store <8 x i1> %1471, ptr %1469, align 1
  %1472 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1468
  %1473 = load i32, ptr %1472, align 4
  %1474 = select i1 %1464, i32 %convergence.dynamic.target265, i32 %1473
  store i32 %1474, ptr %1472, align 4
  %1475 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1468
  %1476 = load i32, ptr %1475, align 4
  %1477 = select i1 %1464, i32 %1461, i32 %1476
  store i32 %1477, ptr %1475, align 4
  %1478 = add i32 %1465, 1
  %1479 = select i1 %1464, i32 %1478, i32 %1465
  store i32 %1479, ptr %ready.count, align 4
  %1480 = load <8 x i1>, ptr %runnable.mask, align 1
  %1481 = or <8 x i1> %1480, %1455
  store <8 x i1> %1481, ptr %runnable.mask, align 1
  br label %return.frame.cleanup.done
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), i32 immarg, <8 x i1>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.and.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #4

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %x) #5 {
entry:
  %0 = bitcast <8 x float> %x to <8 x i32>
  %1 = and <8 x i32> %0, splat (i32 2147483647)
  %2 = bitcast <8 x i32> %1 to <8 x float>
  %3 = fcmp contract ole <8 x float> %2, splat (float 1.000000e+00)
  %4 = fmul contract <8 x float> %2, %2
  %5 = fmul contract <8 x float> splat (float 0x3DE6124620000000), %4
  %6 = fadd contract <8 x float> %5, splat (float 0x3E5AE64560000000)
  %7 = fmul contract <8 x float> %6, %4
  %8 = fadd contract <8 x float> %7, splat (float 0x3EC71DE3A0000000)
  %9 = fmul contract <8 x float> %8, %4
  %10 = fadd contract <8 x float> %9, splat (float 0x3F2A01A020000000)
  %11 = fmul contract <8 x float> %10, %4
  %12 = fadd contract <8 x float> %11, splat (float 0x3F81111120000000)
  %13 = fmul contract <8 x float> %12, %4
  %14 = fadd contract <8 x float> %13, splat (float 0x3FC5555560000000)
  %15 = fmul contract <8 x float> %14, %4
  %16 = fadd contract <8 x float> %15, splat (float 1.000000e+00)
  %17 = fmul contract <8 x float> %2, %16
  %18 = fmul contract <8 x float> %2, %2
  %19 = fmul contract <8 x float> splat (float 0x3E21EED8E0000000), %18
  %20 = fadd contract <8 x float> %19, splat (float 0x3E927E4FC0000000)
  %21 = fmul contract <8 x float> %20, %18
  %22 = fadd contract <8 x float> %21, splat (float 0x3EFA01A020000000)
  %23 = fmul contract <8 x float> %22, %18
  %24 = fadd contract <8 x float> %23, splat (float 0x3F56C16C20000000)
  %25 = fmul contract <8 x float> %24, %18
  %26 = fadd contract <8 x float> %25, splat (float 0x3FA5555560000000)
  %27 = fmul contract <8 x float> %26, %18
  %28 = fadd contract <8 x float> %27, splat (float 5.000000e-01)
  %29 = fmul contract <8 x float> %28, %18
  %30 = fadd contract <8 x float> %29, splat (float 1.000000e+00)
  %31 = fdiv contract <8 x float> %17, %30
  %32 = fcmp contract ole <8 x float> %2, splat (float 9.000000e+00)
  %33 = select contract <8 x i1> %32, <8 x float> %2, <8 x float> zeroinitializer
  %exp.half = call contract <8 x float> @__luisa_cpu_native_exp_half_f32_v8_u10(<8 x float> %33)
  %34 = fdiv contract <8 x float> splat (float 2.500000e-01), %exp.half
  %35 = fsub contract <8 x float> %exp.half, %34
  %36 = fadd contract <8 x float> %exp.half, %34
  %37 = fdiv contract <8 x float> %35, %36
  %38 = select contract <8 x i1> %32, <8 x float> %37, <8 x float> splat (float 1.000000e+00)
  %39 = select contract <8 x i1> %3, <8 x float> %31, <8 x float> %38
  %40 = bitcast <8 x float> %39 to <8 x i32>
  %41 = and <8 x i32> %40, splat (i32 2147483647)
  %42 = bitcast <8 x float> %x to <8 x i32>
  %43 = and <8 x i32> %42, splat (i32 -2147483648)
  %44 = or <8 x i32> %41, %43
  %45 = bitcast <8 x i32> %44 to <8 x float>
  %46 = fcmp contract uno <8 x float> %x, %x
  %47 = select contract <8 x i1> %46, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %45
  ret <8 x float> %47
}

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_half_f32_v8_u10(<8 x float> %x) #5 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = sub <8 x i32> %11, splat (i32 1)
  %32 = ashr <8 x i32> %31, splat (i32 1)
  %33 = add <8 x i32> %32, splat (i32 127)
  %34 = shl <8 x i32> %33, splat (i32 23)
  %35 = bitcast <8 x i32> %34 to <8 x float>
  %36 = fmul <8 x float> %30, %35
  %37 = sub <8 x i32> %31, %32
  %38 = add <8 x i32> %37, splat (i32 127)
  %39 = shl <8 x i32> %38, splat (i32 23)
  %40 = bitcast <8 x i32> %39 to <8 x float>
  %41 = fmul <8 x float> %36, %40
  %42 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %43 = select <8 x i1> %42, <8 x float> zeroinitializer, <8 x float> %41
  %44 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %45 = select <8 x i1> %44, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %43
  %46 = fcmp uno <8 x float> %x, %x
  %47 = select <8 x i1> %46, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %45
  ret <8 x float> %47
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), i32 immarg, <8 x i1>) #6

define dso_local void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #5 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #6 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [16384 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [16384 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill5 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill5, align 4
  %tile_snapshot.spill6 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill6, align 64
  %.slot7 = alloca i64, align 8
  store i64 0, ptr %.slot7, align 4
  %.slot8 = alloca i64, align 8
  store i64 0, ptr %.slot8, align 4
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert9 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat10 = shufflevector <8 x i32> %.splatinsert9, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat10, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert11 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat12 = shufflevector <8 x i32> %.splatinsert11, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat12, %41
  %44 = mul i32 %32, 1
  %.splatinsert13 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat14 = shufflevector <8 x i32> %.splatinsert13, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat14, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert15 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat16 = shufflevector <8 x i32> %.splatinsert15, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat16, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert17 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat18 = shufflevector <8 x i32> %.splatinsert17, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat18
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load <8 x i64>, ptr %.spill4, align 64
  %65 = select <8 x i1> %51, <8 x i64> %63, <8 x i64> %64
  store <8 x i64> %65, ptr %.spill4, align 64
  %66 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %68 = extractvalue { <8 x ptr>, <8 x i64> } %66, 0
  %69 = select <8 x i1> %51, <8 x ptr> %67, <8 x ptr> %68
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %71 = extractvalue { <8 x ptr>, <8 x i64> } %66, 1
  %72 = select <8 x i1> %51, <8 x i64> %70, <8 x i64> %71
  %73 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %69, 0
  %74 = insertvalue { <8 x ptr>, <8 x i64> } %73, <8 x i64> %72, 1
  store { <8 x ptr>, <8 x i64> } %74, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %75 = icmp slt i64 %.state, 512
  br i1 %75, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state19 = load i64, ptr %.slot, align 4
  %76 = mul i64 %.state19, 8
  %.splatinsert20 = insertelement <8 x i64> poison, i64 %76, i64 0
  %.splat21 = shufflevector <8 x i64> %.splatinsert20, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %77 = add <8 x i64> %.splat21, %.spill.load
  %.spill.load22 = load <8 x i64>, ptr %.spill4, align 64
  %78 = add <8 x i64> %.spill.load22, zeroinitializer
  %79 = add <8 x i64> zeroinitializer, %78
  %80 = add <8 x i64> zeroinitializer, %77
  %81 = mul <8 x i64> %79, splat (i64 4096)
  %82 = add <8 x i64> %81, %80
  %83 = extractvalue { ptr, i64 } %9, 0
  %84 = extractelement <8 x i64> %82, i32 0
  %85 = sub i64 %84, 0
  %86 = mul i64 %85, 4
  %buffer.contiguous.address = getelementptr i8, ptr %83, i64 %86
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state23 = load i64, ptr %.slot, align 4
  %.splatinsert24 = insertelement <8 x i64> poison, i64 %.state23, i64 0
  %.splat25 = shufflevector <8 x i64> %.splatinsert24, <8 x i64> poison, <8 x i32> zeroinitializer
  %89 = mul <8 x i64> %.splat25, splat (i64 32)
  %90 = add <8 x i64> %88, %89
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %87, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = extractelement <8 x ptr> %93, i32 0
  %96 = extractelement <8 x i64> %94, i32 0
  %97 = sub i64 %96, 0
  %98 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %99 = select i1 %98, i64 %97, i64 0
  %private.contiguous.address = getelementptr i8, ptr %95, i64 %99
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %100 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %100, ptr %private.contiguous.address, align 4
  %.state26 = load i64, ptr %.slot, align 4
  %101 = add i64 %.state26, 1
  store i64 %101, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store float 1.000000e+00, ptr %.spill5, align 4
  %102 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %103 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %104 = extractvalue { <8 x ptr>, <8 x i64> } %102, 0
  %105 = select <8 x i1> %51, <8 x ptr> %103, <8 x ptr> %104
  %106 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %102, 1
  %108 = select <8 x i1> %51, <8 x i64> %106, <8 x i64> %107
  %109 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %105, 0
  %110 = insertvalue { <8 x ptr>, <8 x i64> } %109, <8 x i64> %108, 1
  store { <8 x ptr>, <8 x i64> } %110, ptr %tile_snapshot.spill6, align 64
  store i64 0, ptr %.slot7, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state27 = load i64, ptr %.slot7, align 4
  %111 = icmp slt i64 %.state27, 512
  br i1 %111, label %direct.true28, label %direct.false29

direct.schedule.5:                                ; preds = %direct.true28
  %.state30 = load i64, ptr %.slot7, align 4
  %112 = mul i64 %.state30, 8
  %.splatinsert31 = insertelement <8 x i64> poison, i64 %112, i64 0
  %.splat32 = shufflevector <8 x i64> %.splatinsert31, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load33 = load <8 x i64>, ptr %.spill, align 64
  %113 = add <8 x i64> %.splat32, %.spill.load33
  %.spill.load34 = load <8 x i64>, ptr %.spill4, align 64
  %114 = add <8 x i64> %.spill.load34, zeroinitializer
  %115 = add <8 x i64> zeroinitializer, %114
  %116 = add <8 x i64> zeroinitializer, %113
  %117 = mul <8 x i64> %115, splat (i64 4096)
  %118 = add <8 x i64> %117, %116
  %119 = extractvalue { ptr, i64 } %15, 0
  %120 = extractelement <8 x i64> %118, i32 0
  %121 = sub i64 %120, 0
  %122 = mul i64 %121, 4
  %buffer.contiguous.address35 = getelementptr i8, ptr %119, i64 %122
  %buffer.contiguous.load36 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address35, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load37 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %123 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load37, 0
  %124 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load37, 1
  %.state38 = load i64, ptr %.slot7, align 4
  %.splatinsert39 = insertelement <8 x i64> poison, i64 %.state38, i64 0
  %.splat40 = shufflevector <8 x i64> %.splatinsert39, <8 x i64> poison, <8 x i32> zeroinitializer
  %125 = mul <8 x i64> %.splat40, splat (i64 32)
  %126 = add <8 x i64> %124, %125
  %127 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %123, 0
  %128 = insertvalue { <8 x ptr>, <8 x i64> } %127, <8 x i64> %126, 1
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %128, 1
  %131 = extractelement <8 x ptr> %129, i32 0
  %132 = extractelement <8 x i64> %130, i32 0
  %133 = sub i64 %132, 0
  %134 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %135 = select i1 %134, i64 %133, i64 0
  %private.contiguous.address41 = getelementptr i8, ptr %131, i64 %135
  %private.contiguous.preserve42 = load <8 x float>, ptr %private.contiguous.address41, align 4
  %136 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load36, <8 x float> %private.contiguous.preserve42
  store <8 x float> %136, ptr %private.contiguous.address41, align 4
  %.state43 = load i64, ptr %.slot7, align 4
  %137 = add i64 %.state43, 1
  store i64 %137, ptr %.slot7, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false29
  store i64 0, ptr %.slot8, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state44 = load i64, ptr %.slot8, align 4
  %138 = icmp slt i64 %.state44, 512
  br i1 %138, label %direct.true45, label %direct.false46

direct.schedule.8:                                ; preds = %direct.true45
  %.state47 = load i64, ptr %.slot8, align 4
  %139 = mul i64 %.state47, 8
  %.splatinsert48 = insertelement <8 x i64> poison, i64 %139, i64 0
  %.splat49 = shufflevector <8 x i64> %.splatinsert48, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load50 = load <8 x i64>, ptr %.spill, align 64
  %140 = add <8 x i64> %.splat49, %.spill.load50
  %.spill.load51 = load <8 x i64>, ptr %.spill4, align 64
  %141 = add <8 x i64> %.spill.load51, zeroinitializer
  %142 = add <8 x i64> zeroinitializer, %141
  %143 = add <8 x i64> zeroinitializer, %140
  %144 = mul <8 x i64> %142, splat (i64 4096)
  %145 = add <8 x i64> %144, %143
  %tile_snapshot.spill.load52 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load52, 0
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load52, 1
  %.state53 = load i64, ptr %.slot8, align 4
  %.splatinsert54 = insertelement <8 x i64> poison, i64 %.state53, i64 0
  %.splat55 = shufflevector <8 x i64> %.splatinsert54, <8 x i64> poison, <8 x i32> zeroinitializer
  %148 = mul <8 x i64> %.splat55, splat (i64 32)
  %149 = add <8 x i64> %147, %148
  %150 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %146, 0
  %151 = insertvalue { <8 x ptr>, <8 x i64> } %150, <8 x i64> %149, 1
  %152 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %151, 1
  %154 = extractelement <8 x ptr> %152, i32 0
  %155 = extractelement <8 x i64> %153, i32 0
  %156 = sub i64 %155, 0
  %157 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %158 = select i1 %157, i64 %156, i64 0
  %private.contiguous.address56 = getelementptr i8, ptr %154, i64 %158
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address56, align 4
  %159 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %160 = fneg <8 x float> %159
  %161 = select <8 x i1> %51, <8 x float> %160, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %161)
  %.spill.load57 = load float, ptr %.spill5, align 4
  %.splatinsert58 = insertelement <8 x float> poison, float %.spill.load57, i64 0
  %.splat59 = shufflevector <8 x float> %.splatinsert58, <8 x float> poison, <8 x i32> zeroinitializer
  %162 = fadd <8 x float> %.splat59, %native.exp
  %163 = fdiv <8 x float> %159, %162
  %tile_snapshot.spill.load60 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %164 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load60, 0
  %165 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load60, 1
  %.state61 = load i64, ptr %.slot8, align 4
  %.splatinsert62 = insertelement <8 x i64> poison, i64 %.state61, i64 0
  %.splat63 = shufflevector <8 x i64> %.splatinsert62, <8 x i64> poison, <8 x i32> zeroinitializer
  %166 = mul <8 x i64> %.splat63, splat (i64 32)
  %167 = add <8 x i64> %165, %166
  %168 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %164, 0
  %169 = insertvalue { <8 x ptr>, <8 x i64> } %168, <8 x i64> %167, 1
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %169, 1
  %172 = extractelement <8 x ptr> %170, i32 0
  %173 = extractelement <8 x i64> %171, i32 0
  %174 = sub i64 %173, 0
  %175 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %176 = select i1 %175, i64 %174, i64 0
  %private.contiguous.address64 = getelementptr i8, ptr %172, i64 %176
  %private.contiguous.load65 = load <8 x float>, ptr %private.contiguous.address64, align 4
  %177 = select <8 x i1> %51, <8 x float> %private.contiguous.load65, <8 x float> zeroinitializer
  %178 = fmul <8 x float> %163, %177
  %179 = extractvalue { ptr, i64 } %27, 0
  %180 = extractelement <8 x i64> %145, i32 0
  %181 = sub i64 %180, 0
  %182 = mul i64 %181, 4
  %buffer.contiguous.address66 = getelementptr i8, ptr %179, i64 %182
  call void @llvm.masked.store.v8f32.p0(<8 x float> %178, ptr %buffer.contiguous.address66, i32 1, <8 x i1> %51)
  %.state67 = load i64, ptr %.slot8, align 4
  %183 = add i64 %.state67, 1
  store i64 %183, ptr %.slot8, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false46
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true28:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false29:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true45:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false46:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #2 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), i32 immarg, <8 x i1>) #3

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %tile_snapshot.local = alloca [16384 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [16384 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill5 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill5, align 4
  %tile_snapshot.spill6 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill6, align 64
  %.slot7 = alloca i64, align 8
  store i64 0, ptr %.slot7, align 4
  %.slot8 = alloca i64, align 8
  store i64 0, ptr %.slot8, align 4
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert9 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat10 = shufflevector <8 x i32> %.splatinsert9, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat10, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert11 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat12 = shufflevector <8 x i32> %.splatinsert11, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat12, %41
  %44 = mul i32 %32, 1
  %.splatinsert13 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat14 = shufflevector <8 x i32> %.splatinsert13, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat14, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert15 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat16 = shufflevector <8 x i32> %.splatinsert15, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat16, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert17 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat18 = shufflevector <8 x i32> %.splatinsert17, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat18
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load <8 x i64>, ptr %.spill4, align 64
  %65 = select <8 x i1> %51, <8 x i64> %63, <8 x i64> %64
  store <8 x i64> %65, ptr %.spill4, align 64
  %66 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %68 = extractvalue { <8 x ptr>, <8 x i64> } %66, 0
  %69 = select <8 x i1> %51, <8 x ptr> %67, <8 x ptr> %68
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %71 = extractvalue { <8 x ptr>, <8 x i64> } %66, 1
  %72 = select <8 x i1> %51, <8 x i64> %70, <8 x i64> %71
  %73 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %69, 0
  %74 = insertvalue { <8 x ptr>, <8 x i64> } %73, <8 x i64> %72, 1
  store { <8 x ptr>, <8 x i64> } %74, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %75 = icmp slt i64 %.state, 512
  br i1 %75, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state19 = load i64, ptr %.slot, align 4
  %76 = mul i64 %.state19, 8
  %.splatinsert20 = insertelement <8 x i64> poison, i64 %76, i64 0
  %.splat21 = shufflevector <8 x i64> %.splatinsert20, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %77 = add <8 x i64> %.splat21, %.spill.load
  %.spill.load22 = load <8 x i64>, ptr %.spill4, align 64
  %78 = add <8 x i64> %.spill.load22, zeroinitializer
  %79 = add <8 x i64> zeroinitializer, %78
  %80 = add <8 x i64> zeroinitializer, %77
  %81 = mul <8 x i64> %79, splat (i64 4096)
  %82 = add <8 x i64> %81, %80
  %83 = extractvalue { ptr, i64 } %9, 0
  %84 = extractelement <8 x i64> %82, i32 0
  %85 = sub i64 %84, 0
  %86 = mul i64 %85, 4
  %buffer.contiguous.address = getelementptr i8, ptr %83, i64 %86
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state23 = load i64, ptr %.slot, align 4
  %.splatinsert24 = insertelement <8 x i64> poison, i64 %.state23, i64 0
  %.splat25 = shufflevector <8 x i64> %.splatinsert24, <8 x i64> poison, <8 x i32> zeroinitializer
  %89 = mul <8 x i64> %.splat25, splat (i64 32)
  %90 = add <8 x i64> %88, %89
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %87, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = extractelement <8 x ptr> %93, i32 0
  %96 = extractelement <8 x i64> %94, i32 0
  %97 = sub i64 %96, 0
  %98 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %99 = select i1 %98, i64 %97, i64 0
  %private.contiguous.address = getelementptr i8, ptr %95, i64 %99
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %100 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %100, ptr %private.contiguous.address, align 4
  %.state26 = load i64, ptr %.slot, align 4
  %101 = add i64 %.state26, 1
  store i64 %101, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store float 1.000000e+00, ptr %.spill5, align 4
  %102 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %103 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %104 = extractvalue { <8 x ptr>, <8 x i64> } %102, 0
  %105 = select <8 x i1> %51, <8 x ptr> %103, <8 x ptr> %104
  %106 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %102, 1
  %108 = select <8 x i1> %51, <8 x i64> %106, <8 x i64> %107
  %109 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %105, 0
  %110 = insertvalue { <8 x ptr>, <8 x i64> } %109, <8 x i64> %108, 1
  store { <8 x ptr>, <8 x i64> } %110, ptr %tile_snapshot.spill6, align 64
  store i64 0, ptr %.slot7, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state27 = load i64, ptr %.slot7, align 4
  %111 = icmp slt i64 %.state27, 512
  br i1 %111, label %direct.true28, label %direct.false29

direct.schedule.5:                                ; preds = %direct.true28
  %.state30 = load i64, ptr %.slot7, align 4
  %112 = mul i64 %.state30, 8
  %.splatinsert31 = insertelement <8 x i64> poison, i64 %112, i64 0
  %.splat32 = shufflevector <8 x i64> %.splatinsert31, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load33 = load <8 x i64>, ptr %.spill, align 64
  %113 = add <8 x i64> %.splat32, %.spill.load33
  %.spill.load34 = load <8 x i64>, ptr %.spill4, align 64
  %114 = add <8 x i64> %.spill.load34, zeroinitializer
  %115 = add <8 x i64> zeroinitializer, %114
  %116 = add <8 x i64> zeroinitializer, %113
  %117 = mul <8 x i64> %115, splat (i64 4096)
  %118 = add <8 x i64> %117, %116
  %119 = extractvalue { ptr, i64 } %15, 0
  %120 = extractelement <8 x i64> %118, i32 0
  %121 = sub i64 %120, 0
  %122 = mul i64 %121, 4
  %buffer.contiguous.address35 = getelementptr i8, ptr %119, i64 %122
  %buffer.contiguous.load36 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address35, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load37 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %123 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load37, 0
  %124 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load37, 1
  %.state38 = load i64, ptr %.slot7, align 4
  %.splatinsert39 = insertelement <8 x i64> poison, i64 %.state38, i64 0
  %.splat40 = shufflevector <8 x i64> %.splatinsert39, <8 x i64> poison, <8 x i32> zeroinitializer
  %125 = mul <8 x i64> %.splat40, splat (i64 32)
  %126 = add <8 x i64> %124, %125
  %127 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %123, 0
  %128 = insertvalue { <8 x ptr>, <8 x i64> } %127, <8 x i64> %126, 1
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %128, 1
  %131 = extractelement <8 x ptr> %129, i32 0
  %132 = extractelement <8 x i64> %130, i32 0
  %133 = sub i64 %132, 0
  %134 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %135 = select i1 %134, i64 %133, i64 0
  %private.contiguous.address41 = getelementptr i8, ptr %131, i64 %135
  %private.contiguous.preserve42 = load <8 x float>, ptr %private.contiguous.address41, align 4
  %136 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load36, <8 x float> %private.contiguous.preserve42
  store <8 x float> %136, ptr %private.contiguous.address41, align 4
  %.state43 = load i64, ptr %.slot7, align 4
  %137 = add i64 %.state43, 1
  store i64 %137, ptr %.slot7, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false29
  store i64 0, ptr %.slot8, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state44 = load i64, ptr %.slot8, align 4
  %138 = icmp slt i64 %.state44, 512
  br i1 %138, label %direct.true45, label %direct.false46

direct.schedule.8:                                ; preds = %direct.true45
  %.state47 = load i64, ptr %.slot8, align 4
  %139 = mul i64 %.state47, 8
  %.splatinsert48 = insertelement <8 x i64> poison, i64 %139, i64 0
  %.splat49 = shufflevector <8 x i64> %.splatinsert48, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load50 = load <8 x i64>, ptr %.spill, align 64
  %140 = add <8 x i64> %.splat49, %.spill.load50
  %.spill.load51 = load <8 x i64>, ptr %.spill4, align 64
  %141 = add <8 x i64> %.spill.load51, zeroinitializer
  %142 = add <8 x i64> zeroinitializer, %141
  %143 = add <8 x i64> zeroinitializer, %140
  %144 = mul <8 x i64> %142, splat (i64 4096)
  %145 = add <8 x i64> %144, %143
  %tile_snapshot.spill.load52 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load52, 0
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load52, 1
  %.state53 = load i64, ptr %.slot8, align 4
  %.splatinsert54 = insertelement <8 x i64> poison, i64 %.state53, i64 0
  %.splat55 = shufflevector <8 x i64> %.splatinsert54, <8 x i64> poison, <8 x i32> zeroinitializer
  %148 = mul <8 x i64> %.splat55, splat (i64 32)
  %149 = add <8 x i64> %147, %148
  %150 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %146, 0
  %151 = insertvalue { <8 x ptr>, <8 x i64> } %150, <8 x i64> %149, 1
  %152 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %151, 1
  %154 = extractelement <8 x ptr> %152, i32 0
  %155 = extractelement <8 x i64> %153, i32 0
  %156 = sub i64 %155, 0
  %157 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %158 = select i1 %157, i64 %156, i64 0
  %private.contiguous.address56 = getelementptr i8, ptr %154, i64 %158
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address56, align 4
  %159 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %160 = fneg <8 x float> %159
  %161 = select <8 x i1> %51, <8 x float> %160, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %161)
  %.spill.load57 = load float, ptr %.spill5, align 4
  %.splatinsert58 = insertelement <8 x float> poison, float %.spill.load57, i64 0
  %.splat59 = shufflevector <8 x float> %.splatinsert58, <8 x float> poison, <8 x i32> zeroinitializer
  %162 = fadd <8 x float> %.splat59, %native.exp
  %163 = fdiv <8 x float> %159, %162
  %tile_snapshot.spill.load60 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %164 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load60, 0
  %165 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load60, 1
  %.state61 = load i64, ptr %.slot8, align 4
  %.splatinsert62 = insertelement <8 x i64> poison, i64 %.state61, i64 0
  %.splat63 = shufflevector <8 x i64> %.splatinsert62, <8 x i64> poison, <8 x i32> zeroinitializer
  %166 = mul <8 x i64> %.splat63, splat (i64 32)
  %167 = add <8 x i64> %165, %166
  %168 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %164, 0
  %169 = insertvalue { <8 x ptr>, <8 x i64> } %168, <8 x i64> %167, 1
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %169, 1
  %172 = extractelement <8 x ptr> %170, i32 0
  %173 = extractelement <8 x i64> %171, i32 0
  %174 = sub i64 %173, 0
  %175 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %176 = select i1 %175, i64 %174, i64 0
  %private.contiguous.address64 = getelementptr i8, ptr %172, i64 %176
  %private.contiguous.load65 = load <8 x float>, ptr %private.contiguous.address64, align 4
  %177 = select <8 x i1> %51, <8 x float> %private.contiguous.load65, <8 x float> zeroinitializer
  %178 = fmul <8 x float> %163, %177
  %179 = extractvalue { ptr, i64 } %27, 0
  %180 = extractelement <8 x i64> %145, i32 0
  %181 = sub i64 %180, 0
  %182 = mul i64 %181, 4
  %buffer.contiguous.address66 = getelementptr i8, ptr %179, i64 %182
  call void @llvm.masked.store.v8f32.p0(<8 x float> %178, ptr %buffer.contiguous.address66, i32 1, <8 x i1> %51)
  %.state67 = load i64, ptr %.slot8, align 4
  %183 = add i64 %.state67, 1
  store i64 %183, ptr %.slot8, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false46
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true28:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false29:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true45:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false46:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

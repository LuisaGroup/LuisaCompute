; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

@convergence.targets = private unnamed_addr constant [15 x i32] [i32 5, i32 8, i32 10, i32 13, i32 15, i32 18, i32 20, i32 23, i32 25, i32 28, i32 30, i32 33, i32 35, i32 38, i32 40], align 4

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %live.mask = alloca <8 x i1>, align 1
  %runnable.mask = alloca <8 x i1>, align 1
  %ready.count = alloca i32, align 4
  %ready.mask = alloca [8 x <8 x i1>], align 1
  %ready.target = alloca [8 x i32], align 4
  %ready.token = alloca [8 x i32], align 4
  %current.mask = alloca <8 x i1>, align 1
  %current.token = alloca i32, align 4
  %frame.active = alloca i8, align 1
  %frame.static.id = alloca <8 x i32>, align 32
  %frame.parent.token = alloca <8 x i32>, align 32
  %frame.expected = alloca [8 x <8 x i1>], align 1
  %frame.arrived = alloca [8 x <8 x i1>], align 1
  store <8 x i1> zeroinitializer, ptr %live.mask, align 1
  store <8 x i1> zeroinitializer, ptr %runnable.mask, align 1
  store i32 0, ptr %ready.count, align 4
  store [8 x <8 x i1>] zeroinitializer, ptr %ready.mask, align 1
  store [8 x i32] zeroinitializer, ptr %ready.target, align 4
  store [8 x i32] zeroinitializer, ptr %ready.token, align 4
  store <8 x i1> zeroinitializer, ptr %current.mask, align 1
  store i32 0, ptr %current.token, align 4
  store i8 0, ptr %frame.active, align 1
  store <8 x i32> zeroinitializer, ptr %frame.static.id, align 32
  store <8 x i32> zeroinitializer, ptr %frame.parent.token, align 32
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.expected, align 1
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.arrived, align 1
  %tile_snapshot.local = alloca [288 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [576 x i8], align 8
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local4 = alloca [72 x i8], align 1
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 9, i64 18, i64 27, i64 36, i64 45, i64 54, i64 63>, 1
  %tile_snapshot.local7 = alloca [288 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local10 = alloca [288 x i8], align 4
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %8 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %9 = insertvalue { <8 x ptr>, <8 x i64> } %8, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill13 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill13, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot, align 64
  %.spill14 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill14, align 1
  %tile_snapshot.spill15 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill15, align 64
  %.slot16 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot16, align 64
  %.spill17 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill17, align 64
  %tile_snapshot.spill18 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill18, align 64
  %.slot19 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot19, align 64
  %.spill20 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill20, align 4
  %tile_snapshot.spill21 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill21, align 64
  %.slot22 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot22, align 64
  %.spill23 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill23, align 4
  %.slot24 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot24, align 64
  %.slot25 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot25, align 32
  %.slot26 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot26, align 32
  %.slot27 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot27, align 32
  %.slot28 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot28, align 32
  %.slot29 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot29, align 32
  %.spill30 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill30, align 32
  %.spill31 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill31, align 32
  %.spill32 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill32, align 32
  %.spill33 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill33, align 32
  %.spill34 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill34, align 4
  %tile_snapshot.spill35 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill35, align 64
  %.slot36 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot36, align 64
  %.slot37 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot37, align 64
  %.slot38 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot38, align 32
  %.slot39 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot39, align 32
  %.slot40 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot40, align 32
  %.slot41 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot41, align 32
  %.slot42 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot42, align 32
  %.spill43 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill43, align 32
  %.slot44 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot44, align 64
  %10 = getelementptr i8, ptr %argument_buffer, i64 0
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 16
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 32
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = getelementptr i8, ptr %argument_buffer, i64 48
  %29 = load ptr, ptr %28, align 16
  %30 = getelementptr i8, ptr %28, i64 8
  %31 = load i64, ptr %30, align 8
  %32 = insertvalue { ptr, i64 } poison, ptr %29, 0
  %33 = insertvalue { ptr, i64 } %32, i64 %31, 1
  %34 = load i32, ptr %launch_config, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 12
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 4
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 16
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 8
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 20
  %44 = load i32, ptr %43, align 4
  %45 = getelementptr i8, ptr %launch_config, i64 36
  %46 = load i32, ptr %45, align 4
  %.splatinsert45 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat46 = shufflevector <8 x i32> %.splatinsert45, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat46, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %48 = mul i32 %34, 32
  %.splatinsert47 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat48 = shufflevector <8 x i32> %.splatinsert47, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat48, %47
  %50 = mul i32 %38, 1
  %.splatinsert49 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat50 = shufflevector <8 x i32> %.splatinsert49, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat50, zeroinitializer
  %52 = mul i32 %42, 1
  %.splatinsert51 = insertelement <8 x i32> poison, i32 %52, i64 0
  %.splat52 = shufflevector <8 x i32> %.splatinsert51, <8 x i32> poison, <8 x i32> zeroinitializer
  %53 = add <8 x i32> %.splat52, zeroinitializer
  %54 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %49, 0
  %55 = insertvalue [3 x <8 x i32>] %54, <8 x i32> %51, 1
  %56 = insertvalue [3 x <8 x i32>] %55, <8 x i32> %53, 2
  %.splatinsert53 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat54 = shufflevector <8 x i32> %.splatinsert53, <8 x i32> poison, <8 x i32> zeroinitializer
  %57 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat54
  store <8 x i1> %57, ptr %live.mask, align 1
  %58 = load i32, ptr %current.token, align 4
  %59 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %60 = load i32, ptr %ready.count, align 4
  %61 = icmp uge i32 %60, 8
  %62 = and i1 %59, %61
  br i1 %62, label %ready.overflow.trap, label %ready.overflow.resume

ready.overflow.trap:                              ; preds = %prologue
  call void @llvm.trap()
  unreachable

ready.overflow.resume:                            ; preds = %prologue
  %63 = select i1 %59, i32 %60, i32 0
  %64 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %63
  %65 = load <8 x i1>, ptr %64, align 1
  %66 = select i1 %59, <8 x i1> %57, <8 x i1> %65
  store <8 x i1> %66, ptr %64, align 1
  %67 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %63
  %68 = load i32, ptr %67, align 4
  %69 = select i1 %59, i32 0, i32 %68
  store i32 %69, ptr %67, align 4
  %70 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %63
  %71 = load i32, ptr %70, align 4
  %72 = select i1 %59, i32 %58, i32 %71
  store i32 %72, ptr %70, align 4
  %73 = add i32 %60, 1
  %74 = select i1 %59, i32 %73, i32 %60
  store i32 %74, ptr %ready.count, align 4
  %75 = load <8 x i1>, ptr %runnable.mask, align 1
  %76 = or <8 x i1> %75, %57
  store <8 x i1> %76, ptr %runnable.mask, align 1
  br label %scheduler.loop

scheduler.loop:                                   ; preds = %return.frame.cleanup.done, %convergence.cascade.exit595, %schedule.39, %varying.coherent.false584, %varying.coherent.true583, %convergence.cascade.exit560, %schedule.37, %varying.coherent.false548, %varying.coherent.true547, %convergence.target.35.ready, %convergence.cascade.exit514, %schedule.34, %varying.coherent.false507, %varying.coherent.true506, %convergence.cascade.exit482, %schedule.32, %varying.coherent.false467, %varying.coherent.true466, %convergence.target.30.ready, %convergence.cascade.exit431, %schedule.29, %varying.coherent.false415, %varying.coherent.true414, %convergence.cascade.exit391, %schedule.27, %varying.coherent.false376, %varying.coherent.true375, %convergence.target.25.ready, %convergence.cascade.exit344, %schedule.24, %varying.coherent.false337, %varying.coherent.true336, %convergence.cascade.exit312, %schedule.22, %varying.coherent.false297, %varying.coherent.true296, %convergence.target.20.ready, %convergence.cascade.exit261, %schedule.19, %varying.coherent.false249, %varying.coherent.true248, %convergence.cascade.exit225, %schedule.17, %varying.coherent.false213, %varying.coherent.true212, %convergence.target.15.ready, %convergence.cascade.exit189, %schedule.14, %varying.coherent.false183, %varying.coherent.true182, %convergence.cascade.exit159, %schedule.12, %varying.coherent.false151, %varying.coherent.true150, %convergence.target.10.ready, %convergence.cascade.exit126, %schedule.9, %varying.coherent.false120, %varying.coherent.true119, %convergence.cascade.exit96, %schedule.7, %varying.coherent.false89, %varying.coherent.true88, %convergence.target.5.ready, %convergence.cascade.exit, %schedule.4, %varying.coherent.false, %varying.coherent.true, %schedule.2, %uniform.false, %uniform.true, %schedule.0, %ready.overflow.resume
  %77 = load i32, ptr %ready.count, align 4
  %78 = icmp ne i32 %77, 0
  br i1 %78, label %scheduler.dispatch, label %scheduler.done

scheduler.dispatch:                               ; preds = %scheduler.loop
  %79 = sub i32 %77, 1
  store i32 %79, ptr %ready.count, align 4
  %80 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %79
  %81 = load <8 x i1>, ptr %80, align 1
  store <8 x i1> %81, ptr %current.mask, align 1
  %82 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %79
  %83 = load i32, ptr %82, align 4
  %84 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %79
  %85 = load i32, ptr %84, align 4
  store i32 %85, ptr %current.token, align 4
  %86 = load <8 x i1>, ptr %runnable.mask, align 1
  %87 = xor <8 x i1> %81, splat (i1 true)
  %88 = and <8 x i1> %86, %87
  store <8 x i1> %88, ptr %runnable.mask, align 1
  br label %scheduler.dispatch.route

scheduler.dispatch.route:                         ; preds = %ready.overflow.resume582, %ready.overflow.resume546, %ready.overflow.resume505, %ready.overflow.resume465, %ready.overflow.resume413, %ready.overflow.resume374, %ready.overflow.resume335, %ready.overflow.resume295, %ready.overflow.resume247, %ready.overflow.resume211, %ready.overflow.resume181, %ready.overflow.resume149, %ready.overflow.resume118, %ready.overflow.resume87, %ready.overflow.resume67, %scheduler.dispatch
  %scheduler.dispatch.pc = phi i32 [ %83, %scheduler.dispatch ], [ 5, %ready.overflow.resume67 ], [ 8, %ready.overflow.resume87 ], [ 10, %ready.overflow.resume118 ], [ 13, %ready.overflow.resume149 ], [ 15, %ready.overflow.resume181 ], [ 18, %ready.overflow.resume211 ], [ 20, %ready.overflow.resume247 ], [ 23, %ready.overflow.resume295 ], [ 25, %ready.overflow.resume335 ], [ 28, %ready.overflow.resume374 ], [ 30, %ready.overflow.resume413 ], [ 33, %ready.overflow.resume465 ], [ 35, %ready.overflow.resume505 ], [ 38, %ready.overflow.resume546 ], [ 40, %ready.overflow.resume582 ]
  switch i32 %scheduler.dispatch.pc, label %scheduler.invalid [
    i32 0, label %schedule.0
    i32 1, label %schedule.1
    i32 2, label %schedule.2
    i32 3, label %schedule.3
    i32 4, label %schedule.4
    i32 5, label %schedule.5
    i32 6, label %schedule.6
    i32 7, label %schedule.7
    i32 8, label %schedule.8
    i32 9, label %schedule.9
    i32 10, label %schedule.10
    i32 11, label %schedule.11
    i32 12, label %schedule.12
    i32 13, label %schedule.13
    i32 14, label %schedule.14
    i32 15, label %schedule.15
    i32 16, label %schedule.16
    i32 17, label %schedule.17
    i32 18, label %schedule.18
    i32 19, label %schedule.19
    i32 20, label %schedule.20
    i32 21, label %schedule.21
    i32 22, label %schedule.22
    i32 23, label %schedule.23
    i32 24, label %schedule.24
    i32 25, label %schedule.25
    i32 26, label %schedule.26
    i32 27, label %schedule.27
    i32 28, label %schedule.28
    i32 29, label %schedule.29
    i32 30, label %schedule.30
    i32 31, label %schedule.31
    i32 32, label %schedule.32
    i32 33, label %schedule.33
    i32 34, label %schedule.34
    i32 35, label %schedule.35
    i32 36, label %schedule.36
    i32 37, label %schedule.37
    i32 38, label %schedule.38
    i32 39, label %schedule.39
    i32 40, label %schedule.40
  ]

scheduler.done:                                   ; preds = %scheduler.loop
  %89 = load <8 x i1>, ptr %live.mask, align 1
  %90 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %89)
  br i1 %90, label %scheduler.stalled, label %scheduler.exit

scheduler.exit:                                   ; preds = %scheduler.done
  ret void

scheduler.stalled:                                ; preds = %scheduler.done
  call void @llvm.trap()
  unreachable

scheduler.invalid:                                ; preds = %scheduler.dispatch.route
  call void @llvm.trap()
  unreachable

schedule.0:                                       ; preds = %scheduler.dispatch.route
  %91 = load <8 x i1>, ptr %current.mask, align 1
  %92 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %91)
  %93 = bitcast <8 x i1> %91 to i8
  %94 = call i8 @llvm.cttz.i8(i8 %93, i1 false)
  %95 = zext i8 %94 to i32
  %96 = select i1 %92, i32 %95, i32 0
  %97 = extractvalue [3 x <8 x i32>] %56, 0
  %98 = load <8 x i64>, ptr %.spill, align 64
  %99 = select <8 x i1> %91, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %98
  store <8 x i64> %99, ptr %.spill, align 64
  %100 = sub <8 x i32> %97, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %101 = select <8 x i1> %91, <8 x i32> %100, <8 x i32> zeroinitializer
  %102 = select <8 x i1> %91, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %103 = lshr <8 x i32> %101, %102
  %104 = zext <8 x i32> %103 to <8 x i64>
  %105 = select <8 x i1> %91, <8 x i64> %104, <8 x i64> zeroinitializer
  %106 = select <8 x i1> %91, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %107 = sdiv <8 x i64> %105, %106
  %108 = load <8 x i64>, ptr %.spill13, align 64
  %109 = select <8 x i1> %91, <8 x i64> %107, <8 x i64> %108
  store <8 x i64> %109, ptr %.spill13, align 64
  %110 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %111 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %112 = extractvalue { <8 x ptr>, <8 x i64> } %110, 0
  %113 = select <8 x i1> %91, <8 x ptr> %111, <8 x ptr> %112
  %114 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %110, 1
  %116 = select <8 x i1> %91, <8 x i64> %114, <8 x i64> %115
  %117 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %113, 0
  %118 = insertvalue { <8 x ptr>, <8 x i64> } %117, <8 x i64> %116, 1
  store { <8 x ptr>, <8 x i64> } %118, ptr %tile_snapshot.spill, align 64
  %119 = load <8 x i64>, ptr %.slot, align 64
  %120 = select <8 x i1> %91, <8 x i64> zeroinitializer, <8 x i64> %119
  store <8 x i64> %120, ptr %.slot, align 64
  store <8 x i1> %91, ptr %current.mask, align 1
  %121 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %91)
  br i1 %121, label %schedule.1, label %scheduler.loop

schedule.1:                                       ; preds = %schedule.2, %schedule.0, %scheduler.dispatch.route
  %122 = load <8 x i1>, ptr %current.mask, align 1
  %123 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %122)
  %124 = bitcast <8 x i1> %122 to i8
  %125 = call i8 @llvm.cttz.i8(i8 %124, i1 false)
  %126 = zext i8 %125 to i32
  %127 = select i1 %123, i32 %126, i32 0
  %.state = load <8 x i64>, ptr %.slot, align 64
  %128 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %122)
  %129 = bitcast <8 x i1> %122 to i8
  %130 = call i8 @llvm.cttz.i8(i8 %129, i1 false)
  %131 = zext i8 %130 to i32
  %132 = select i1 %128, i32 %131, i32 0
  %133 = extractelement <8 x i64> %.state, i32 %132
  %134 = icmp slt i64 %133, 8
  br i1 %134, label %uniform.true, label %uniform.false

schedule.2:                                       ; preds = %uniform.true, %scheduler.dispatch.route
  %135 = load <8 x i1>, ptr %current.mask, align 1
  %136 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %135)
  %137 = bitcast <8 x i1> %135 to i8
  %138 = call i8 @llvm.cttz.i8(i8 %137, i1 false)
  %139 = zext i8 %138 to i32
  %140 = select i1 %136, i32 %139, i32 0
  %.state55 = load <8 x i64>, ptr %.slot, align 64
  %141 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %135)
  %142 = bitcast <8 x i1> %135 to i8
  %143 = call i8 @llvm.cttz.i8(i8 %142, i1 false)
  %144 = zext i8 %143 to i32
  %145 = select i1 %141, i32 %144, i32 0
  %146 = extractelement <8 x i64> %.state55, i32 %145
  %147 = mul i64 %146, 8
  %.splatinsert56 = insertelement <8 x i64> poison, i64 %147, i64 0
  %.splat57 = shufflevector <8 x i64> %.splatinsert56, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %148 = add <8 x i64> %.splat57, %.spill.load
  %.spill.load58 = load <8 x i64>, ptr %.spill13, align 64
  %149 = add <8 x i64> %.spill.load58, zeroinitializer
  %150 = add <8 x i64> zeroinitializer, %149
  %151 = add <8 x i64> zeroinitializer, %148
  %152 = mul <8 x i64> %150, splat (i64 66)
  %153 = add <8 x i64> %152, %151
  %154 = extractvalue { ptr, i64 } %15, 0
  %155 = extractelement <8 x i64> %153, i32 %140
  %156 = zext i32 %140 to i64
  %157 = sub i64 %155, %156
  %158 = mul i64 %157, 4
  %buffer.contiguous.address = getelementptr i8, ptr %154, i64 %158
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %135, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %159 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %160 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state59 = load <8 x i64>, ptr %.slot, align 64
  %161 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %135)
  %162 = bitcast <8 x i1> %135 to i8
  %163 = call i8 @llvm.cttz.i8(i8 %162, i1 false)
  %164 = zext i8 %163 to i32
  %165 = select i1 %161, i32 %164, i32 0
  %166 = extractelement <8 x i64> %.state59, i32 %165
  %.splatinsert60 = insertelement <8 x i64> poison, i64 %166, i64 0
  %.splat61 = shufflevector <8 x i64> %.splatinsert60, <8 x i64> poison, <8 x i32> zeroinitializer
  %167 = mul <8 x i64> %.splat61, splat (i64 32)
  %168 = add <8 x i64> %160, %167
  %169 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %159, 0
  %170 = insertvalue { <8 x ptr>, <8 x i64> } %169, <8 x i64> %168, 1
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %170, 1
  %173 = extractelement <8 x ptr> %171, i32 0
  %174 = extractelement <8 x i64> %172, i32 %140
  %175 = zext i32 %140 to i64
  %176 = mul i64 %175, 4
  %177 = sub i64 %174, %176
  %178 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %135)
  %179 = select i1 %178, i64 %177, i64 0
  %private.contiguous.address = getelementptr i8, ptr %173, i64 %179
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %180 = select <8 x i1> %135, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %180, ptr %private.contiguous.address, align 4
  %.state62 = load <8 x i64>, ptr %.slot, align 64
  %181 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %135)
  %182 = bitcast <8 x i1> %135 to i8
  %183 = call i8 @llvm.cttz.i8(i8 %182, i1 false)
  %184 = zext i8 %183 to i32
  %185 = select i1 %181, i32 %184, i32 0
  %186 = extractelement <8 x i64> %.state62, i32 %185
  %187 = add i64 %186, 1
  %.splatinsert63 = insertelement <8 x i64> poison, i64 %187, i64 0
  %.splat64 = shufflevector <8 x i64> %.splatinsert63, <8 x i64> poison, <8 x i32> zeroinitializer
  %188 = load <8 x i64>, ptr %.slot, align 64
  %189 = select <8 x i1> %135, <8 x i64> %.splat64, <8 x i64> %188
  store <8 x i64> %189, ptr %.slot, align 64
  store <8 x i1> %135, ptr %current.mask, align 1
  %190 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %135)
  br i1 %190, label %schedule.1, label %scheduler.loop

schedule.3:                                       ; preds = %uniform.false, %scheduler.dispatch.route
  %191 = load <8 x i1>, ptr %current.mask, align 1
  %192 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %191)
  %193 = bitcast <8 x i1> %191 to i8
  %194 = call i8 @llvm.cttz.i8(i8 %193, i1 false)
  %195 = zext i8 %194 to i32
  %196 = select i1 %192, i32 %195, i32 0
  %.spill.load65 = load <8 x i64>, ptr %.spill, align 64
  %197 = icmp slt <8 x i64> %.spill.load65, splat (i64 2)
  %198 = load <8 x i1>, ptr %.spill14, align 1
  %199 = select <8 x i1> %191, <8 x i1> %197, <8 x i1> %198
  store <8 x i1> %199, ptr %.spill14, align 1
  %200 = and <8 x i1> %191, %197
  %201 = xor <8 x i1> %197, splat (i1 true)
  %202 = and <8 x i1> %191, %201
  %203 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %200)
  %204 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %202)
  %205 = and i1 %203, %204
  br i1 %205, label %varying.divergent, label %varying.coherent

schedule.4:                                       ; preds = %varying.coherent.true, %scheduler.dispatch.route
  %206 = load <8 x i1>, ptr %current.mask, align 1
  %207 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %206)
  %208 = bitcast <8 x i1> %206 to i8
  %209 = call i8 @llvm.cttz.i8(i8 %208, i1 false)
  %210 = zext i8 %209 to i32
  %211 = select i1 %207, i32 %210, i32 0
  %.spill.load68 = load <8 x i64>, ptr %.spill, align 64
  %212 = add <8 x i64> splat (i64 64), %.spill.load68
  %.spill.load69 = load <8 x i64>, ptr %.spill13, align 64
  %213 = add <8 x i64> %.spill.load69, zeroinitializer
  %214 = add <8 x i64> zeroinitializer, %213
  %215 = add <8 x i64> zeroinitializer, %212
  %216 = mul <8 x i64> %214, splat (i64 66)
  %217 = add <8 x i64> %216, %215
  %218 = extractvalue { ptr, i64 } %15, 0
  %219 = extractelement <8 x i64> %217, i32 %211
  %220 = zext i32 %211 to i64
  %221 = sub i64 %219, %220
  %222 = mul i64 %221, 4
  %buffer.contiguous.address70 = getelementptr i8, ptr %218, i64 %222
  %buffer.contiguous.load71 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address70, i32 1, <8 x i1> %206, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load72 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load72, 0
  %224 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load72, 1
  %225 = add <8 x i64> %224, splat (i64 256)
  %226 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %223, 0
  %227 = insertvalue { <8 x ptr>, <8 x i64> } %226, <8 x i64> %225, 1
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %229 = extractvalue { <8 x ptr>, <8 x i64> } %227, 1
  %230 = extractelement <8 x ptr> %228, i32 0
  %231 = extractelement <8 x i64> %229, i32 %211
  %232 = zext i32 %211 to i64
  %233 = mul i64 %232, 4
  %234 = sub i64 %231, %233
  %235 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %206)
  %236 = select i1 %235, i64 %234, i64 0
  %private.contiguous.address73 = getelementptr i8, ptr %230, i64 %236
  %private.contiguous.preserve74 = load <8 x float>, ptr %private.contiguous.address73, align 4
  %237 = select <8 x i1> %206, <8 x float> %buffer.contiguous.load71, <8 x float> %private.contiguous.preserve74
  store <8 x float> %237, ptr %private.contiguous.address73, align 4
  store <8 x i1> %206, ptr %current.mask, align 1
  %238 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %206)
  br i1 %238, label %schedule.5, label %scheduler.loop

schedule.5:                                       ; preds = %schedule.4, %varying.coherent.false, %scheduler.dispatch.route
  %239 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token = load i32, ptr %current.token, align 4
  %convergence.token.present = icmp ne i32 %convergence.current.token, 0
  br i1 %convergence.token.present, label %convergence.cascade, label %convergence.cascade.exit

schedule.6:                                       ; preds = %schedule.7, %convergence.target.5.ready, %scheduler.dispatch.route
  %240 = load <8 x i1>, ptr %current.mask, align 1
  %241 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %240)
  %242 = bitcast <8 x i1> %240 to i8
  %243 = call i8 @llvm.cttz.i8(i8 %242, i1 false)
  %244 = zext i8 %243 to i32
  %245 = select i1 %241, i32 %244, i32 0
  %.state81 = load <8 x i64>, ptr %.slot16, align 64
  %246 = icmp slt <8 x i64> %.state81, splat (i64 8)
  %247 = and <8 x i1> %240, %246
  %248 = xor <8 x i1> %246, splat (i1 true)
  %249 = and <8 x i1> %240, %248
  %250 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %247)
  %251 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %249)
  %252 = and i1 %250, %251
  br i1 %252, label %varying.divergent82, label %varying.coherent83

schedule.7:                                       ; preds = %varying.coherent.true88, %scheduler.dispatch.route
  %253 = load <8 x i1>, ptr %current.mask, align 1
  %254 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %253)
  %255 = bitcast <8 x i1> %253 to i8
  %256 = call i8 @llvm.cttz.i8(i8 %255, i1 false)
  %257 = zext i8 %256 to i32
  %258 = select i1 %254, i32 %257, i32 0
  %.state90 = load <8 x i64>, ptr %.slot16, align 64
  %259 = mul <8 x i64> %.state90, splat (i64 8)
  %.spill.load91 = load <8 x i64>, ptr %.spill, align 64
  %260 = add <8 x i64> %259, %.spill.load91
  %tile_snapshot.spill.load92 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load92, 0
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load92, 1
  %.state93 = load <8 x i64>, ptr %.slot16, align 64
  %263 = mul <8 x i64> %.state93, splat (i64 64)
  %264 = add <8 x i64> %262, %263
  %265 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %261, 0
  %266 = insertvalue { <8 x ptr>, <8 x i64> } %265, <8 x i64> %264, 1
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %266, 0
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %266, 1
  %269 = getelementptr i8, <8 x ptr> %267, <8 x i64> %268
  call void @llvm.masked.scatter.v8i64.v8p0(<8 x i64> %260, <8 x ptr> %269, i32 1, <8 x i1> %253)
  %.state94 = load <8 x i64>, ptr %.slot16, align 64
  %270 = add <8 x i64> %.state94, splat (i64 1)
  %271 = load <8 x i64>, ptr %.slot16, align 64
  %272 = select <8 x i1> %253, <8 x i64> %270, <8 x i64> %271
  store <8 x i64> %272, ptr %.slot16, align 64
  store <8 x i1> %253, ptr %current.mask, align 1
  %273 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %253)
  br i1 %273, label %schedule.6, label %scheduler.loop

schedule.8:                                       ; preds = %varying.coherent.false89, %scheduler.dispatch.route
  %274 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token97 = load i32, ptr %current.token, align 4
  %convergence.token.present98 = icmp ne i32 %convergence.current.token97, 0
  br i1 %convergence.token.present98, label %convergence.cascade95, label %convergence.cascade.exit96

schedule.9:                                       ; preds = %varying.coherent.true119, %scheduler.dispatch.route
  %275 = load <8 x i1>, ptr %current.mask, align 1
  %276 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %275)
  %277 = bitcast <8 x i1> %275 to i8
  %278 = call i8 @llvm.cttz.i8(i8 %277, i1 false)
  %279 = zext i8 %278 to i32
  %280 = select i1 %276, i32 %279, i32 0
  %.spill.load121 = load <8 x i64>, ptr %.spill, align 64
  %281 = add <8 x i64> splat (i64 64), %.spill.load121
  %tile_snapshot.spill.load122 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %282 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 0
  %283 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 1
  %284 = add <8 x i64> %283, splat (i64 512)
  %285 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %282, 0
  %286 = insertvalue { <8 x ptr>, <8 x i64> } %285, <8 x i64> %284, 1
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %288 = extractvalue { <8 x ptr>, <8 x i64> } %286, 1
  %289 = extractelement <8 x ptr> %287, i32 0
  %290 = extractelement <8 x i64> %288, i32 %280
  %291 = zext i32 %280 to i64
  %292 = mul i64 %291, 8
  %293 = sub i64 %290, %292
  %294 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %275)
  %295 = select i1 %294, i64 %293, i64 0
  %private.contiguous.address123 = getelementptr i8, ptr %289, i64 %295
  %private.contiguous.preserve124 = load <8 x i64>, ptr %private.contiguous.address123, align 8
  %296 = select <8 x i1> %275, <8 x i64> %281, <8 x i64> %private.contiguous.preserve124
  store <8 x i64> %296, ptr %private.contiguous.address123, align 8
  store <8 x i1> %275, ptr %current.mask, align 1
  %297 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %275)
  br i1 %297, label %schedule.10, label %scheduler.loop

schedule.10:                                      ; preds = %schedule.9, %varying.coherent.false120, %scheduler.dispatch.route
  %298 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token127 = load i32, ptr %current.token, align 4
  %convergence.token.present128 = icmp ne i32 %convergence.current.token127, 0
  br i1 %convergence.token.present128, label %convergence.cascade125, label %convergence.cascade.exit126

schedule.11:                                      ; preds = %schedule.12, %convergence.target.10.ready, %scheduler.dispatch.route
  %299 = load <8 x i1>, ptr %current.mask, align 1
  %300 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %299)
  %301 = bitcast <8 x i1> %299 to i8
  %302 = call i8 @llvm.cttz.i8(i8 %301, i1 false)
  %303 = zext i8 %302 to i32
  %304 = select i1 %300, i32 %303, i32 0
  %.state143 = load <8 x i64>, ptr %.slot19, align 64
  %305 = icmp slt <8 x i64> %.state143, splat (i64 8)
  %306 = and <8 x i1> %299, %305
  %307 = xor <8 x i1> %305, splat (i1 true)
  %308 = and <8 x i1> %299, %307
  %309 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %306)
  %310 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %308)
  %311 = and i1 %309, %310
  br i1 %311, label %varying.divergent144, label %varying.coherent145

schedule.12:                                      ; preds = %varying.coherent.true150, %scheduler.dispatch.route
  %312 = load <8 x i1>, ptr %current.mask, align 1
  %313 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %312)
  %314 = bitcast <8 x i1> %312 to i8
  %315 = call i8 @llvm.cttz.i8(i8 %314, i1 false)
  %316 = zext i8 %315 to i32
  %317 = select i1 %313, i32 %316, i32 0
  %tile_snapshot.spill.load152 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %318 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load152, 0
  %319 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load152, 1
  %.state153 = load <8 x i64>, ptr %.slot19, align 64
  %320 = mul <8 x i64> %.state153, splat (i64 64)
  %321 = add <8 x i64> %319, %320
  %322 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %318, 0
  %323 = insertvalue { <8 x ptr>, <8 x i64> } %322, <8 x i64> %321, 1
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %323, 0
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %323, 1
  %326 = getelementptr i8, <8 x ptr> %324, <8 x i64> %325
  %327 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> %326, i32 1, <8 x i1> %312, <8 x i64> zeroinitializer)
  %.spill.load154 = load <8 x i64>, ptr %.spill17, align 64
  %328 = icmp sle <8 x i64> %327, %.spill.load154
  %tile_snapshot.spill.load155 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load155, 0
  %330 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load155, 1
  %.state156 = load <8 x i64>, ptr %.slot19, align 64
  %331 = add <8 x i64> %330, %.state156
  %332 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %329, 0
  %333 = insertvalue { <8 x ptr>, <8 x i64> } %332, <8 x i64> %331, 1
  %334 = extractvalue { <8 x ptr>, <8 x i64> } %333, 0
  %335 = extractvalue { <8 x ptr>, <8 x i64> } %333, 1
  %336 = getelementptr i8, <8 x ptr> %334, <8 x i64> %335
  %337 = zext <8 x i1> %328 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %337, <8 x ptr> %336, i32 1, <8 x i1> %312)
  %.state157 = load <8 x i64>, ptr %.slot19, align 64
  %338 = add <8 x i64> %.state157, splat (i64 1)
  %339 = load <8 x i64>, ptr %.slot19, align 64
  %340 = select <8 x i1> %312, <8 x i64> %338, <8 x i64> %339
  store <8 x i64> %340, ptr %.slot19, align 64
  store <8 x i1> %312, ptr %current.mask, align 1
  %341 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %312)
  br i1 %341, label %schedule.11, label %scheduler.loop

schedule.13:                                      ; preds = %varying.coherent.false151, %scheduler.dispatch.route
  %342 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token160 = load i32, ptr %current.token, align 4
  %convergence.token.present161 = icmp ne i32 %convergence.current.token160, 0
  br i1 %convergence.token.present161, label %convergence.cascade158, label %convergence.cascade.exit159

schedule.14:                                      ; preds = %varying.coherent.true182, %scheduler.dispatch.route
  %343 = load <8 x i1>, ptr %current.mask, align 1
  %344 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %343)
  %345 = bitcast <8 x i1> %343 to i8
  %346 = call i8 @llvm.cttz.i8(i8 %345, i1 false)
  %347 = zext i8 %346 to i32
  %348 = select i1 %344, i32 %347, i32 0
  %tile_snapshot.spill.load184 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %349 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load184, 0
  %350 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load184, 1
  %351 = add <8 x i64> %350, splat (i64 512)
  %352 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %349, 0
  %353 = insertvalue { <8 x ptr>, <8 x i64> } %352, <8 x i64> %351, 1
  %354 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %355 = extractvalue { <8 x ptr>, <8 x i64> } %353, 1
  %356 = extractelement <8 x ptr> %354, i32 0
  %357 = extractelement <8 x i64> %355, i32 %348
  %358 = zext i32 %348 to i64
  %359 = mul i64 %358, 8
  %360 = sub i64 %357, %359
  %361 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %343)
  %362 = select i1 %361, i64 %360, i64 0
  %private.contiguous.address185 = getelementptr i8, ptr %356, i64 %362
  %private.contiguous.load = load <8 x i64>, ptr %private.contiguous.address185, align 8
  %363 = select <8 x i1> %343, <8 x i64> %private.contiguous.load, <8 x i64> zeroinitializer
  %.spill.load186 = load <8 x i64>, ptr %.spill17, align 64
  %364 = icmp sle <8 x i64> %363, %.spill.load186
  %tile_snapshot.spill.load187 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %365 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load187, 0
  %366 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load187, 1
  %367 = add <8 x i64> %366, splat (i64 8)
  %368 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %365, 0
  %369 = insertvalue { <8 x ptr>, <8 x i64> } %368, <8 x i64> %367, 1
  %370 = extractvalue { <8 x ptr>, <8 x i64> } %369, 0
  %371 = extractvalue { <8 x ptr>, <8 x i64> } %369, 1
  %372 = getelementptr i8, <8 x ptr> %370, <8 x i64> %371
  %373 = zext <8 x i1> %364 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %373, <8 x ptr> %372, i32 1, <8 x i1> %343)
  store <8 x i1> %343, ptr %current.mask, align 1
  %374 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %343)
  br i1 %374, label %schedule.15, label %scheduler.loop

schedule.15:                                      ; preds = %schedule.14, %varying.coherent.false183, %scheduler.dispatch.route
  %375 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token190 = load i32, ptr %current.token, align 4
  %convergence.token.present191 = icmp ne i32 %convergence.current.token190, 0
  br i1 %convergence.token.present191, label %convergence.cascade188, label %convergence.cascade.exit189

schedule.16:                                      ; preds = %schedule.17, %convergence.target.15.ready, %scheduler.dispatch.route
  %376 = load <8 x i1>, ptr %current.mask, align 1
  %377 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %376)
  %378 = bitcast <8 x i1> %376 to i8
  %379 = call i8 @llvm.cttz.i8(i8 %378, i1 false)
  %380 = zext i8 %379 to i32
  %381 = select i1 %377, i32 %380, i32 0
  %.state205 = load <8 x i64>, ptr %.slot22, align 64
  %382 = icmp slt <8 x i64> %.state205, splat (i64 8)
  %383 = and <8 x i1> %376, %382
  %384 = xor <8 x i1> %382, splat (i1 true)
  %385 = and <8 x i1> %376, %384
  %386 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %383)
  %387 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %385)
  %388 = and i1 %386, %387
  br i1 %388, label %varying.divergent206, label %varying.coherent207

schedule.17:                                      ; preds = %varying.coherent.true212, %scheduler.dispatch.route
  %389 = load <8 x i1>, ptr %current.mask, align 1
  %390 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %389)
  %391 = bitcast <8 x i1> %389 to i8
  %392 = call i8 @llvm.cttz.i8(i8 %391, i1 false)
  %393 = zext i8 %392 to i32
  %394 = select i1 %390, i32 %393, i32 0
  %tile_snapshot.spill.load214 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %395 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load214, 0
  %396 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load214, 1
  %.state215 = load <8 x i64>, ptr %.slot22, align 64
  %397 = add <8 x i64> %396, %.state215
  %398 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %395, 0
  %399 = insertvalue { <8 x ptr>, <8 x i64> } %398, <8 x i64> %397, 1
  %400 = extractvalue { <8 x ptr>, <8 x i64> } %399, 0
  %401 = extractvalue { <8 x ptr>, <8 x i64> } %399, 1
  %402 = getelementptr i8, <8 x ptr> %400, <8 x i64> %401
  %403 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %402, i32 1, <8 x i1> %389, <8 x i8> zeroinitializer)
  %404 = icmp ne <8 x i8> %403, zeroinitializer
  %tile_snapshot.spill.load216 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %405 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load216, 0
  %406 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load216, 1
  %.state217 = load <8 x i64>, ptr %.slot22, align 64
  %407 = mul <8 x i64> %.state217, splat (i64 32)
  %408 = add <8 x i64> %406, %407
  %409 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %405, 0
  %410 = insertvalue { <8 x ptr>, <8 x i64> } %409, <8 x i64> %408, 1
  %411 = extractvalue { <8 x ptr>, <8 x i64> } %410, 0
  %412 = extractvalue { <8 x ptr>, <8 x i64> } %410, 1
  %413 = getelementptr i8, <8 x ptr> %411, <8 x i64> %412
  %414 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %413, i32 1, <8 x i1> %389, <8 x float> zeroinitializer)
  %.spill.load218 = load float, ptr %.spill20, align 4
  %.splatinsert219 = insertelement <8 x float> poison, float %.spill.load218, i64 0
  %.splat220 = shufflevector <8 x float> %.splatinsert219, <8 x float> poison, <8 x i32> zeroinitializer
  %415 = select <8 x i1> %404, <8 x float> %414, <8 x float> %.splat220
  %tile_snapshot.spill.load221 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %416 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 0
  %417 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 1
  %.state222 = load <8 x i64>, ptr %.slot22, align 64
  %418 = mul <8 x i64> %.state222, splat (i64 32)
  %419 = add <8 x i64> %417, %418
  %420 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %416, 0
  %421 = insertvalue { <8 x ptr>, <8 x i64> } %420, <8 x i64> %419, 1
  %422 = extractvalue { <8 x ptr>, <8 x i64> } %421, 0
  %423 = extractvalue { <8 x ptr>, <8 x i64> } %421, 1
  %424 = getelementptr i8, <8 x ptr> %422, <8 x i64> %423
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %415, <8 x ptr> %424, i32 1, <8 x i1> %389)
  %.state223 = load <8 x i64>, ptr %.slot22, align 64
  %425 = add <8 x i64> %.state223, splat (i64 1)
  %426 = load <8 x i64>, ptr %.slot22, align 64
  %427 = select <8 x i1> %389, <8 x i64> %425, <8 x i64> %426
  store <8 x i64> %427, ptr %.slot22, align 64
  store <8 x i1> %389, ptr %current.mask, align 1
  %428 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %389)
  br i1 %428, label %schedule.16, label %scheduler.loop

schedule.18:                                      ; preds = %varying.coherent.false213, %scheduler.dispatch.route
  %429 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token226 = load i32, ptr %current.token, align 4
  %convergence.token.present227 = icmp ne i32 %convergence.current.token226, 0
  br i1 %convergence.token.present227, label %convergence.cascade224, label %convergence.cascade.exit225

schedule.19:                                      ; preds = %varying.coherent.true248, %scheduler.dispatch.route
  %430 = load <8 x i1>, ptr %current.mask, align 1
  %431 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %430)
  %432 = bitcast <8 x i1> %430 to i8
  %433 = call i8 @llvm.cttz.i8(i8 %432, i1 false)
  %434 = zext i8 %433 to i32
  %435 = select i1 %431, i32 %434, i32 0
  %tile_snapshot.spill.load250 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %436 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load250, 0
  %437 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load250, 1
  %438 = add <8 x i64> %437, splat (i64 8)
  %439 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %436, 0
  %440 = insertvalue { <8 x ptr>, <8 x i64> } %439, <8 x i64> %438, 1
  %441 = extractvalue { <8 x ptr>, <8 x i64> } %440, 0
  %442 = extractvalue { <8 x ptr>, <8 x i64> } %440, 1
  %443 = getelementptr i8, <8 x ptr> %441, <8 x i64> %442
  %444 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %443, i32 1, <8 x i1> %430, <8 x i8> zeroinitializer)
  %445 = icmp ne <8 x i8> %444, zeroinitializer
  %tile_snapshot.spill.load251 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %446 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load251, 0
  %447 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load251, 1
  %448 = add <8 x i64> %447, splat (i64 256)
  %449 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %446, 0
  %450 = insertvalue { <8 x ptr>, <8 x i64> } %449, <8 x i64> %448, 1
  %451 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %452 = extractvalue { <8 x ptr>, <8 x i64> } %450, 1
  %453 = extractelement <8 x ptr> %451, i32 0
  %454 = extractelement <8 x i64> %452, i32 %435
  %455 = zext i32 %435 to i64
  %456 = mul i64 %455, 4
  %457 = sub i64 %454, %456
  %458 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %430)
  %459 = select i1 %458, i64 %457, i64 0
  %private.contiguous.address252 = getelementptr i8, ptr %453, i64 %459
  %private.contiguous.load253 = load <8 x float>, ptr %private.contiguous.address252, align 4
  %460 = select <8 x i1> %430, <8 x float> %private.contiguous.load253, <8 x float> zeroinitializer
  %.spill.load254 = load float, ptr %.spill20, align 4
  %.splatinsert255 = insertelement <8 x float> poison, float %.spill.load254, i64 0
  %.splat256 = shufflevector <8 x float> %.splatinsert255, <8 x float> poison, <8 x i32> zeroinitializer
  %461 = select <8 x i1> %445, <8 x float> %460, <8 x float> %.splat256
  %tile_snapshot.spill.load257 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %462 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load257, 0
  %463 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load257, 1
  %464 = add <8 x i64> %463, splat (i64 256)
  %465 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %462, 0
  %466 = insertvalue { <8 x ptr>, <8 x i64> } %465, <8 x i64> %464, 1
  %467 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %468 = extractvalue { <8 x ptr>, <8 x i64> } %466, 1
  %469 = extractelement <8 x ptr> %467, i32 0
  %470 = extractelement <8 x i64> %468, i32 %435
  %471 = zext i32 %435 to i64
  %472 = mul i64 %471, 4
  %473 = sub i64 %470, %472
  %474 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %430)
  %475 = select i1 %474, i64 %473, i64 0
  %private.contiguous.address258 = getelementptr i8, ptr %469, i64 %475
  %private.contiguous.preserve259 = load <8 x float>, ptr %private.contiguous.address258, align 4
  %476 = select <8 x i1> %430, <8 x float> %461, <8 x float> %private.contiguous.preserve259
  store <8 x float> %476, ptr %private.contiguous.address258, align 4
  store <8 x i1> %430, ptr %current.mask, align 1
  %477 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %430)
  br i1 %477, label %schedule.20, label %scheduler.loop

schedule.20:                                      ; preds = %schedule.19, %varying.coherent.false249, %scheduler.dispatch.route
  %478 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token262 = load i32, ptr %current.token, align 4
  %convergence.token.present263 = icmp ne i32 %convergence.current.token262, 0
  br i1 %convergence.token.present263, label %convergence.cascade260, label %convergence.cascade.exit261

schedule.21:                                      ; preds = %schedule.22, %convergence.target.20.ready, %scheduler.dispatch.route
  %479 = load <8 x i1>, ptr %current.mask, align 1
  %480 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %479)
  %481 = bitcast <8 x i1> %479 to i8
  %482 = call i8 @llvm.cttz.i8(i8 %481, i1 false)
  %483 = zext i8 %482 to i32
  %484 = select i1 %480, i32 %483, i32 0
  %.state289 = load <8 x i64>, ptr %.slot24, align 64
  %485 = icmp slt <8 x i64> %.state289, splat (i64 8)
  %486 = and <8 x i1> %479, %485
  %487 = xor <8 x i1> %485, splat (i1 true)
  %488 = and <8 x i1> %479, %487
  %489 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %486)
  %490 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %488)
  %491 = and i1 %489, %490
  br i1 %491, label %varying.divergent290, label %varying.coherent291

schedule.22:                                      ; preds = %varying.coherent.true296, %scheduler.dispatch.route
  %492 = load <8 x i1>, ptr %current.mask, align 1
  %493 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %492)
  %494 = bitcast <8 x i1> %492 to i8
  %495 = call i8 @llvm.cttz.i8(i8 %494, i1 false)
  %496 = zext i8 %495 to i32
  %497 = select i1 %493, i32 %496, i32 0
  %.state298 = load <8 x i64>, ptr %.slot24, align 64
  %498 = add <8 x i64> %.state298, zeroinitializer
  %tile_snapshot.spill.load299 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %499 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load299, 0
  %500 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load299, 1
  %501 = mul <8 x i64> %498, splat (i64 32)
  %502 = add <8 x i64> %500, %501
  %503 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %499, 0
  %504 = insertvalue { <8 x ptr>, <8 x i64> } %503, <8 x i64> %502, 1
  %505 = extractvalue { <8 x ptr>, <8 x i64> } %504, 0
  %506 = extractvalue { <8 x ptr>, <8 x i64> } %504, 1
  %507 = getelementptr i8, <8 x ptr> %505, <8 x i64> %506
  %508 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %507, i32 1, <8 x i1> %492, <8 x float> zeroinitializer)
  %.state300 = load <8 x float>, ptr %.slot25, align 32
  %509 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state300, <8 x float> %508)
  %.state301 = load <8 x i64>, ptr %.slot24, align 64
  %510 = add <8 x i64> %.state301, splat (i64 1)
  %tile_snapshot.spill.load302 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %511 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load302, 0
  %512 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load302, 1
  %513 = mul <8 x i64> %510, splat (i64 32)
  %514 = add <8 x i64> %512, %513
  %515 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %511, 0
  %516 = insertvalue { <8 x ptr>, <8 x i64> } %515, <8 x i64> %514, 1
  %517 = extractvalue { <8 x ptr>, <8 x i64> } %516, 0
  %518 = extractvalue { <8 x ptr>, <8 x i64> } %516, 1
  %519 = getelementptr i8, <8 x ptr> %517, <8 x i64> %518
  %520 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %519, i32 1, <8 x i1> %492, <8 x float> zeroinitializer)
  %.state303 = load <8 x float>, ptr %.slot26, align 32
  %521 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state303, <8 x float> %520)
  %.state304 = load <8 x i64>, ptr %.slot24, align 64
  %522 = add <8 x i64> %.state304, splat (i64 2)
  %tile_snapshot.spill.load305 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %523 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load305, 0
  %524 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load305, 1
  %525 = mul <8 x i64> %522, splat (i64 32)
  %526 = add <8 x i64> %524, %525
  %527 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %523, 0
  %528 = insertvalue { <8 x ptr>, <8 x i64> } %527, <8 x i64> %526, 1
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %528, 0
  %530 = extractvalue { <8 x ptr>, <8 x i64> } %528, 1
  %531 = getelementptr i8, <8 x ptr> %529, <8 x i64> %530
  %532 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %531, i32 1, <8 x i1> %492, <8 x float> zeroinitializer)
  %.state306 = load <8 x float>, ptr %.slot27, align 32
  %533 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state306, <8 x float> %532)
  %.state307 = load <8 x i64>, ptr %.slot24, align 64
  %534 = add <8 x i64> %.state307, splat (i64 3)
  %tile_snapshot.spill.load308 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %535 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load308, 0
  %536 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load308, 1
  %537 = mul <8 x i64> %534, splat (i64 32)
  %538 = add <8 x i64> %536, %537
  %539 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %535, 0
  %540 = insertvalue { <8 x ptr>, <8 x i64> } %539, <8 x i64> %538, 1
  %541 = extractvalue { <8 x ptr>, <8 x i64> } %540, 0
  %542 = extractvalue { <8 x ptr>, <8 x i64> } %540, 1
  %543 = getelementptr i8, <8 x ptr> %541, <8 x i64> %542
  %544 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %543, i32 1, <8 x i1> %492, <8 x float> zeroinitializer)
  %.state309 = load <8 x float>, ptr %.slot28, align 32
  %545 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state309, <8 x float> %544)
  %.state310 = load <8 x i64>, ptr %.slot24, align 64
  %546 = add <8 x i64> %.state310, splat (i64 4)
  %547 = load <8 x i64>, ptr %.slot24, align 64
  %548 = select <8 x i1> %492, <8 x i64> %546, <8 x i64> %547
  store <8 x i64> %548, ptr %.slot24, align 64
  %549 = load <8 x float>, ptr %.slot25, align 32
  %550 = select <8 x i1> %492, <8 x float> %509, <8 x float> %549
  store <8 x float> %550, ptr %.slot25, align 32
  %551 = load <8 x float>, ptr %.slot26, align 32
  %552 = select <8 x i1> %492, <8 x float> %521, <8 x float> %551
  store <8 x float> %552, ptr %.slot26, align 32
  %553 = load <8 x float>, ptr %.slot27, align 32
  %554 = select <8 x i1> %492, <8 x float> %533, <8 x float> %553
  store <8 x float> %554, ptr %.slot27, align 32
  %555 = load <8 x float>, ptr %.slot28, align 32
  %556 = select <8 x i1> %492, <8 x float> %545, <8 x float> %555
  store <8 x float> %556, ptr %.slot28, align 32
  store <8 x i1> %492, ptr %current.mask, align 1
  %557 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %492)
  br i1 %557, label %schedule.21, label %scheduler.loop

schedule.23:                                      ; preds = %varying.coherent.false297, %scheduler.dispatch.route
  %558 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token313 = load i32, ptr %current.token, align 4
  %convergence.token.present314 = icmp ne i32 %convergence.current.token313, 0
  br i1 %convergence.token.present314, label %convergence.cascade311, label %convergence.cascade.exit312

schedule.24:                                      ; preds = %varying.coherent.true336, %scheduler.dispatch.route
  %559 = load <8 x i1>, ptr %current.mask, align 1
  %560 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %559)
  %561 = bitcast <8 x i1> %559 to i8
  %562 = call i8 @llvm.cttz.i8(i8 %561, i1 false)
  %563 = zext i8 %562 to i32
  %564 = select i1 %560, i32 %563, i32 0
  %tile_snapshot.spill.load339 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %565 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load339, 0
  %566 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load339, 1
  %567 = add <8 x i64> %566, splat (i64 256)
  %568 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %565, 0
  %569 = insertvalue { <8 x ptr>, <8 x i64> } %568, <8 x i64> %567, 1
  %570 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %571 = extractvalue { <8 x ptr>, <8 x i64> } %569, 1
  %572 = extractelement <8 x ptr> %570, i32 0
  %573 = extractelement <8 x i64> %571, i32 %564
  %574 = zext i32 %564 to i64
  %575 = mul i64 %574, 4
  %576 = sub i64 %573, %575
  %577 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %559)
  %578 = select i1 %577, i64 %576, i64 0
  %private.contiguous.address340 = getelementptr i8, ptr %572, i64 %578
  %private.contiguous.load341 = load <8 x float>, ptr %private.contiguous.address340, align 4
  %579 = select <8 x i1> %559, <8 x float> %private.contiguous.load341, <8 x float> zeroinitializer
  %.state342 = load <8 x float>, ptr %.slot25, align 32
  %580 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state342, <8 x float> %579)
  %581 = load <8 x float>, ptr %.slot29, align 32
  %582 = select <8 x i1> %559, <8 x float> %580, <8 x float> %581
  store <8 x float> %582, ptr %.slot29, align 32
  store <8 x i1> %559, ptr %current.mask, align 1
  %583 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %559)
  br i1 %583, label %schedule.25, label %scheduler.loop

schedule.25:                                      ; preds = %schedule.24, %varying.coherent.false337, %scheduler.dispatch.route
  %584 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token345 = load i32, ptr %current.token, align 4
  %convergence.token.present346 = icmp ne i32 %convergence.current.token345, 0
  br i1 %convergence.token.present346, label %convergence.cascade343, label %convergence.cascade.exit344

schedule.26:                                      ; preds = %schedule.27, %convergence.target.25.ready, %scheduler.dispatch.route
  %585 = load <8 x i1>, ptr %current.mask, align 1
  %586 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %585)
  %587 = bitcast <8 x i1> %585 to i8
  %588 = call i8 @llvm.cttz.i8(i8 %587, i1 false)
  %589 = zext i8 %588 to i32
  %590 = select i1 %586, i32 %589, i32 0
  %.state368 = load <8 x i64>, ptr %.slot36, align 64
  %591 = icmp slt <8 x i64> %.state368, splat (i64 8)
  %592 = and <8 x i1> %585, %591
  %593 = xor <8 x i1> %591, splat (i1 true)
  %594 = and <8 x i1> %585, %593
  %595 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %592)
  %596 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %594)
  %597 = and i1 %595, %596
  br i1 %597, label %varying.divergent369, label %varying.coherent370

schedule.27:                                      ; preds = %varying.coherent.true375, %scheduler.dispatch.route
  %598 = load <8 x i1>, ptr %current.mask, align 1
  %599 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %598)
  %600 = bitcast <8 x i1> %598 to i8
  %601 = call i8 @llvm.cttz.i8(i8 %600, i1 false)
  %602 = zext i8 %601 to i32
  %603 = select i1 %599, i32 %602, i32 0
  %tile_snapshot.spill.load377 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %604 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load377, 0
  %605 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load377, 1
  %.state378 = load <8 x i64>, ptr %.slot36, align 64
  %606 = add <8 x i64> %605, %.state378
  %607 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %604, 0
  %608 = insertvalue { <8 x ptr>, <8 x i64> } %607, <8 x i64> %606, 1
  %609 = extractvalue { <8 x ptr>, <8 x i64> } %608, 0
  %610 = extractvalue { <8 x ptr>, <8 x i64> } %608, 1
  %611 = getelementptr i8, <8 x ptr> %609, <8 x i64> %610
  %612 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %611, i32 1, <8 x i1> %598, <8 x i8> zeroinitializer)
  %613 = icmp ne <8 x i8> %612, zeroinitializer
  %tile_snapshot.spill.load379 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %614 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load379, 0
  %615 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load379, 1
  %.state380 = load <8 x i64>, ptr %.slot36, align 64
  %616 = mul <8 x i64> %.state380, splat (i64 32)
  %617 = add <8 x i64> %615, %616
  %618 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %614, 0
  %619 = insertvalue { <8 x ptr>, <8 x i64> } %618, <8 x i64> %617, 1
  %620 = extractvalue { <8 x ptr>, <8 x i64> } %619, 0
  %621 = extractvalue { <8 x ptr>, <8 x i64> } %619, 1
  %622 = getelementptr i8, <8 x ptr> %620, <8 x i64> %621
  %623 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %622, i32 1, <8 x i1> %598, <8 x float> zeroinitializer)
  %.spill.load381 = load <8 x float>, ptr %.spill33, align 32
  %624 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %598)
  %625 = bitcast <8 x i1> %598 to i8
  %626 = call i8 @llvm.cttz.i8(i8 %625, i1 false)
  %627 = zext i8 %626 to i32
  %628 = select i1 %624, i32 %627, i32 0
  %629 = extractelement <8 x float> %.spill.load381, i32 %628
  %.splatinsert382 = insertelement <8 x float> poison, float %629, i64 0
  %.splat383 = shufflevector <8 x float> %.splatinsert382, <8 x float> poison, <8 x i32> zeroinitializer
  %630 = fsub <8 x float> %623, %.splat383
  %631 = select <8 x i1> %598, <8 x float> %630, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %631)
  %.spill.load384 = load float, ptr %.spill34, align 4
  %.splatinsert385 = insertelement <8 x float> poison, float %.spill.load384, i64 0
  %.splat386 = shufflevector <8 x float> %.splatinsert385, <8 x float> poison, <8 x i32> zeroinitializer
  %632 = select <8 x i1> %613, <8 x float> %native.exp, <8 x float> %.splat386
  %tile_snapshot.spill.load387 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %633 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load387, 0
  %634 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load387, 1
  %.state388 = load <8 x i64>, ptr %.slot36, align 64
  %635 = mul <8 x i64> %.state388, splat (i64 32)
  %636 = add <8 x i64> %634, %635
  %637 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %633, 0
  %638 = insertvalue { <8 x ptr>, <8 x i64> } %637, <8 x i64> %636, 1
  %639 = extractvalue { <8 x ptr>, <8 x i64> } %638, 0
  %640 = extractvalue { <8 x ptr>, <8 x i64> } %638, 1
  %641 = getelementptr i8, <8 x ptr> %639, <8 x i64> %640
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %632, <8 x ptr> %641, i32 1, <8 x i1> %598)
  %.state389 = load <8 x i64>, ptr %.slot36, align 64
  %642 = add <8 x i64> %.state389, splat (i64 1)
  %643 = load <8 x i64>, ptr %.slot36, align 64
  %644 = select <8 x i1> %598, <8 x i64> %642, <8 x i64> %643
  store <8 x i64> %644, ptr %.slot36, align 64
  store <8 x i1> %598, ptr %current.mask, align 1
  %645 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %598)
  br i1 %645, label %schedule.26, label %scheduler.loop

schedule.28:                                      ; preds = %varying.coherent.false376, %scheduler.dispatch.route
  %646 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token392 = load i32, ptr %current.token, align 4
  %convergence.token.present393 = icmp ne i32 %convergence.current.token392, 0
  br i1 %convergence.token.present393, label %convergence.cascade390, label %convergence.cascade.exit391

schedule.29:                                      ; preds = %varying.coherent.true414, %scheduler.dispatch.route
  %647 = load <8 x i1>, ptr %current.mask, align 1
  %648 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %647)
  %649 = bitcast <8 x i1> %647 to i8
  %650 = call i8 @llvm.cttz.i8(i8 %649, i1 false)
  %651 = zext i8 %650 to i32
  %652 = select i1 %648, i32 %651, i32 0
  %tile_snapshot.spill.load416 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %653 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load416, 0
  %654 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load416, 1
  %655 = add <8 x i64> %654, splat (i64 8)
  %656 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %653, 0
  %657 = insertvalue { <8 x ptr>, <8 x i64> } %656, <8 x i64> %655, 1
  %658 = extractvalue { <8 x ptr>, <8 x i64> } %657, 0
  %659 = extractvalue { <8 x ptr>, <8 x i64> } %657, 1
  %660 = getelementptr i8, <8 x ptr> %658, <8 x i64> %659
  %661 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %660, i32 1, <8 x i1> %647, <8 x i8> zeroinitializer)
  %662 = icmp ne <8 x i8> %661, zeroinitializer
  %tile_snapshot.spill.load417 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %663 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load417, 0
  %664 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load417, 1
  %665 = add <8 x i64> %664, splat (i64 256)
  %666 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %663, 0
  %667 = insertvalue { <8 x ptr>, <8 x i64> } %666, <8 x i64> %665, 1
  %668 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %669 = extractvalue { <8 x ptr>, <8 x i64> } %667, 1
  %670 = extractelement <8 x ptr> %668, i32 0
  %671 = extractelement <8 x i64> %669, i32 %652
  %672 = zext i32 %652 to i64
  %673 = mul i64 %672, 4
  %674 = sub i64 %671, %673
  %675 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %647)
  %676 = select i1 %675, i64 %674, i64 0
  %private.contiguous.address418 = getelementptr i8, ptr %670, i64 %676
  %private.contiguous.load419 = load <8 x float>, ptr %private.contiguous.address418, align 4
  %677 = select <8 x i1> %647, <8 x float> %private.contiguous.load419, <8 x float> zeroinitializer
  %.spill.load420 = load <8 x float>, ptr %.spill33, align 32
  %678 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %647)
  %679 = bitcast <8 x i1> %647 to i8
  %680 = call i8 @llvm.cttz.i8(i8 %679, i1 false)
  %681 = zext i8 %680 to i32
  %682 = select i1 %678, i32 %681, i32 0
  %683 = extractelement <8 x float> %.spill.load420, i32 %682
  %.splatinsert421 = insertelement <8 x float> poison, float %683, i64 0
  %.splat422 = shufflevector <8 x float> %.splatinsert421, <8 x float> poison, <8 x i32> zeroinitializer
  %684 = fsub <8 x float> %677, %.splat422
  %685 = select <8 x i1> %647, <8 x float> %684, <8 x float> zeroinitializer
  %native.exp423 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %685)
  %.spill.load424 = load float, ptr %.spill34, align 4
  %.splatinsert425 = insertelement <8 x float> poison, float %.spill.load424, i64 0
  %.splat426 = shufflevector <8 x float> %.splatinsert425, <8 x float> poison, <8 x i32> zeroinitializer
  %686 = select <8 x i1> %662, <8 x float> %native.exp423, <8 x float> %.splat426
  %tile_snapshot.spill.load427 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %687 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load427, 0
  %688 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load427, 1
  %689 = add <8 x i64> %688, splat (i64 256)
  %690 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %687, 0
  %691 = insertvalue { <8 x ptr>, <8 x i64> } %690, <8 x i64> %689, 1
  %692 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %693 = extractvalue { <8 x ptr>, <8 x i64> } %691, 1
  %694 = extractelement <8 x ptr> %692, i32 0
  %695 = extractelement <8 x i64> %693, i32 %652
  %696 = zext i32 %652 to i64
  %697 = mul i64 %696, 4
  %698 = sub i64 %695, %697
  %699 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %647)
  %700 = select i1 %699, i64 %698, i64 0
  %private.contiguous.address428 = getelementptr i8, ptr %694, i64 %700
  %private.contiguous.preserve429 = load <8 x float>, ptr %private.contiguous.address428, align 4
  %701 = select <8 x i1> %647, <8 x float> %686, <8 x float> %private.contiguous.preserve429
  store <8 x float> %701, ptr %private.contiguous.address428, align 4
  store <8 x i1> %647, ptr %current.mask, align 1
  %702 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %647)
  br i1 %702, label %schedule.30, label %scheduler.loop

schedule.30:                                      ; preds = %schedule.29, %varying.coherent.false415, %scheduler.dispatch.route
  %703 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token432 = load i32, ptr %current.token, align 4
  %convergence.token.present433 = icmp ne i32 %convergence.current.token432, 0
  br i1 %convergence.token.present433, label %convergence.cascade430, label %convergence.cascade.exit431

schedule.31:                                      ; preds = %schedule.32, %convergence.target.30.ready, %scheduler.dispatch.route
  %704 = load <8 x i1>, ptr %current.mask, align 1
  %705 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %704)
  %706 = bitcast <8 x i1> %704 to i8
  %707 = call i8 @llvm.cttz.i8(i8 %706, i1 false)
  %708 = zext i8 %707 to i32
  %709 = select i1 %705, i32 %708, i32 0
  %.state459 = load <8 x i64>, ptr %.slot37, align 64
  %710 = icmp slt <8 x i64> %.state459, splat (i64 8)
  %711 = and <8 x i1> %704, %710
  %712 = xor <8 x i1> %710, splat (i1 true)
  %713 = and <8 x i1> %704, %712
  %714 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %711)
  %715 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %713)
  %716 = and i1 %714, %715
  br i1 %716, label %varying.divergent460, label %varying.coherent461

schedule.32:                                      ; preds = %varying.coherent.true466, %scheduler.dispatch.route
  %717 = load <8 x i1>, ptr %current.mask, align 1
  %718 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %717)
  %719 = bitcast <8 x i1> %717 to i8
  %720 = call i8 @llvm.cttz.i8(i8 %719, i1 false)
  %721 = zext i8 %720 to i32
  %722 = select i1 %718, i32 %721, i32 0
  %.state468 = load <8 x i64>, ptr %.slot37, align 64
  %723 = add <8 x i64> %.state468, zeroinitializer
  %tile_snapshot.spill.load469 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %724 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load469, 0
  %725 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load469, 1
  %726 = mul <8 x i64> %723, splat (i64 32)
  %727 = add <8 x i64> %725, %726
  %728 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %724, 0
  %729 = insertvalue { <8 x ptr>, <8 x i64> } %728, <8 x i64> %727, 1
  %730 = extractvalue { <8 x ptr>, <8 x i64> } %729, 0
  %731 = extractvalue { <8 x ptr>, <8 x i64> } %729, 1
  %732 = getelementptr i8, <8 x ptr> %730, <8 x i64> %731
  %733 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %732, i32 1, <8 x i1> %717, <8 x float> zeroinitializer)
  %.state470 = load <8 x float>, ptr %.slot38, align 32
  %734 = fadd <8 x float> %.state470, %733
  %.state471 = load <8 x i64>, ptr %.slot37, align 64
  %735 = add <8 x i64> %.state471, splat (i64 1)
  %tile_snapshot.spill.load472 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %736 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load472, 0
  %737 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load472, 1
  %738 = mul <8 x i64> %735, splat (i64 32)
  %739 = add <8 x i64> %737, %738
  %740 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %736, 0
  %741 = insertvalue { <8 x ptr>, <8 x i64> } %740, <8 x i64> %739, 1
  %742 = extractvalue { <8 x ptr>, <8 x i64> } %741, 0
  %743 = extractvalue { <8 x ptr>, <8 x i64> } %741, 1
  %744 = getelementptr i8, <8 x ptr> %742, <8 x i64> %743
  %745 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %744, i32 1, <8 x i1> %717, <8 x float> zeroinitializer)
  %.state473 = load <8 x float>, ptr %.slot39, align 32
  %746 = fadd <8 x float> %.state473, %745
  %.state474 = load <8 x i64>, ptr %.slot37, align 64
  %747 = add <8 x i64> %.state474, splat (i64 2)
  %tile_snapshot.spill.load475 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %748 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load475, 0
  %749 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load475, 1
  %750 = mul <8 x i64> %747, splat (i64 32)
  %751 = add <8 x i64> %749, %750
  %752 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %748, 0
  %753 = insertvalue { <8 x ptr>, <8 x i64> } %752, <8 x i64> %751, 1
  %754 = extractvalue { <8 x ptr>, <8 x i64> } %753, 0
  %755 = extractvalue { <8 x ptr>, <8 x i64> } %753, 1
  %756 = getelementptr i8, <8 x ptr> %754, <8 x i64> %755
  %757 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %756, i32 1, <8 x i1> %717, <8 x float> zeroinitializer)
  %.state476 = load <8 x float>, ptr %.slot40, align 32
  %758 = fadd <8 x float> %.state476, %757
  %.state477 = load <8 x i64>, ptr %.slot37, align 64
  %759 = add <8 x i64> %.state477, splat (i64 3)
  %tile_snapshot.spill.load478 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %760 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load478, 0
  %761 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load478, 1
  %762 = mul <8 x i64> %759, splat (i64 32)
  %763 = add <8 x i64> %761, %762
  %764 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %760, 0
  %765 = insertvalue { <8 x ptr>, <8 x i64> } %764, <8 x i64> %763, 1
  %766 = extractvalue { <8 x ptr>, <8 x i64> } %765, 0
  %767 = extractvalue { <8 x ptr>, <8 x i64> } %765, 1
  %768 = getelementptr i8, <8 x ptr> %766, <8 x i64> %767
  %769 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %768, i32 1, <8 x i1> %717, <8 x float> zeroinitializer)
  %.state479 = load <8 x float>, ptr %.slot41, align 32
  %770 = fadd <8 x float> %.state479, %769
  %.state480 = load <8 x i64>, ptr %.slot37, align 64
  %771 = add <8 x i64> %.state480, splat (i64 4)
  %772 = load <8 x i64>, ptr %.slot37, align 64
  %773 = select <8 x i1> %717, <8 x i64> %771, <8 x i64> %772
  store <8 x i64> %773, ptr %.slot37, align 64
  %774 = load <8 x float>, ptr %.slot38, align 32
  %775 = select <8 x i1> %717, <8 x float> %734, <8 x float> %774
  store <8 x float> %775, ptr %.slot38, align 32
  %776 = load <8 x float>, ptr %.slot39, align 32
  %777 = select <8 x i1> %717, <8 x float> %746, <8 x float> %776
  store <8 x float> %777, ptr %.slot39, align 32
  %778 = load <8 x float>, ptr %.slot40, align 32
  %779 = select <8 x i1> %717, <8 x float> %758, <8 x float> %778
  store <8 x float> %779, ptr %.slot40, align 32
  %780 = load <8 x float>, ptr %.slot41, align 32
  %781 = select <8 x i1> %717, <8 x float> %770, <8 x float> %780
  store <8 x float> %781, ptr %.slot41, align 32
  store <8 x i1> %717, ptr %current.mask, align 1
  %782 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %717)
  br i1 %782, label %schedule.31, label %scheduler.loop

schedule.33:                                      ; preds = %varying.coherent.false467, %scheduler.dispatch.route
  %783 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token483 = load i32, ptr %current.token, align 4
  %convergence.token.present484 = icmp ne i32 %convergence.current.token483, 0
  br i1 %convergence.token.present484, label %convergence.cascade481, label %convergence.cascade.exit482

schedule.34:                                      ; preds = %varying.coherent.true506, %scheduler.dispatch.route
  %784 = load <8 x i1>, ptr %current.mask, align 1
  %785 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %784)
  %786 = bitcast <8 x i1> %784 to i8
  %787 = call i8 @llvm.cttz.i8(i8 %786, i1 false)
  %788 = zext i8 %787 to i32
  %789 = select i1 %785, i32 %788, i32 0
  %tile_snapshot.spill.load509 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %790 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load509, 0
  %791 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load509, 1
  %792 = add <8 x i64> %791, splat (i64 256)
  %793 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %790, 0
  %794 = insertvalue { <8 x ptr>, <8 x i64> } %793, <8 x i64> %792, 1
  %795 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %796 = extractvalue { <8 x ptr>, <8 x i64> } %794, 1
  %797 = extractelement <8 x ptr> %795, i32 0
  %798 = extractelement <8 x i64> %796, i32 %789
  %799 = zext i32 %789 to i64
  %800 = mul i64 %799, 4
  %801 = sub i64 %798, %800
  %802 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %784)
  %803 = select i1 %802, i64 %801, i64 0
  %private.contiguous.address510 = getelementptr i8, ptr %797, i64 %803
  %private.contiguous.load511 = load <8 x float>, ptr %private.contiguous.address510, align 4
  %804 = select <8 x i1> %784, <8 x float> %private.contiguous.load511, <8 x float> zeroinitializer
  %.state512 = load <8 x float>, ptr %.slot38, align 32
  %805 = fadd <8 x float> %.state512, %804
  %806 = load <8 x float>, ptr %.slot42, align 32
  %807 = select <8 x i1> %784, <8 x float> %805, <8 x float> %806
  store <8 x float> %807, ptr %.slot42, align 32
  store <8 x i1> %784, ptr %current.mask, align 1
  %808 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %784)
  br i1 %808, label %schedule.35, label %scheduler.loop

schedule.35:                                      ; preds = %schedule.34, %varying.coherent.false507, %scheduler.dispatch.route
  %809 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token515 = load i32, ptr %current.token, align 4
  %convergence.token.present516 = icmp ne i32 %convergence.current.token515, 0
  br i1 %convergence.token.present516, label %convergence.cascade513, label %convergence.cascade.exit514

schedule.36:                                      ; preds = %schedule.37, %convergence.target.35.ready, %scheduler.dispatch.route
  %810 = load <8 x i1>, ptr %current.mask, align 1
  %811 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %810)
  %812 = bitcast <8 x i1> %810 to i8
  %813 = call i8 @llvm.cttz.i8(i8 %812, i1 false)
  %814 = zext i8 %813 to i32
  %815 = select i1 %811, i32 %814, i32 0
  %.state540 = load <8 x i64>, ptr %.slot44, align 64
  %816 = icmp slt <8 x i64> %.state540, splat (i64 8)
  %817 = and <8 x i1> %810, %816
  %818 = xor <8 x i1> %816, splat (i1 true)
  %819 = and <8 x i1> %810, %818
  %820 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %817)
  %821 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %819)
  %822 = and i1 %820, %821
  br i1 %822, label %varying.divergent541, label %varying.coherent542

schedule.37:                                      ; preds = %varying.coherent.true547, %scheduler.dispatch.route
  %823 = load <8 x i1>, ptr %current.mask, align 1
  %824 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %823)
  %825 = bitcast <8 x i1> %823 to i8
  %826 = call i8 @llvm.cttz.i8(i8 %825, i1 false)
  %827 = zext i8 %826 to i32
  %828 = select i1 %824, i32 %827, i32 0
  %.state549 = load <8 x i64>, ptr %.slot44, align 64
  %829 = mul <8 x i64> %.state549, splat (i64 8)
  %.spill.load550 = load <8 x i64>, ptr %.spill, align 64
  %830 = add <8 x i64> %829, %.spill.load550
  %.spill.load551 = load <8 x i64>, ptr %.spill13, align 64
  %831 = add <8 x i64> %.spill.load551, zeroinitializer
  %832 = add <8 x i64> zeroinitializer, %831
  %833 = add <8 x i64> zeroinitializer, %830
  %834 = mul <8 x i64> %832, splat (i64 66)
  %835 = add <8 x i64> %834, %833
  %tile_snapshot.spill.load552 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %836 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load552, 0
  %837 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load552, 1
  %.state553 = load <8 x i64>, ptr %.slot44, align 64
  %838 = mul <8 x i64> %.state553, splat (i64 32)
  %839 = add <8 x i64> %837, %838
  %840 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %836, 0
  %841 = insertvalue { <8 x ptr>, <8 x i64> } %840, <8 x i64> %839, 1
  %842 = extractvalue { <8 x ptr>, <8 x i64> } %841, 0
  %843 = extractvalue { <8 x ptr>, <8 x i64> } %841, 1
  %844 = getelementptr i8, <8 x ptr> %842, <8 x i64> %843
  %845 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %844, i32 1, <8 x i1> %823, <8 x float> zeroinitializer)
  %.spill.load554 = load <8 x float>, ptr %.spill43, align 32
  %846 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %823)
  %847 = bitcast <8 x i1> %823 to i8
  %848 = call i8 @llvm.cttz.i8(i8 %847, i1 false)
  %849 = zext i8 %848 to i32
  %850 = select i1 %846, i32 %849, i32 0
  %851 = extractelement <8 x float> %.spill.load554, i32 %850
  %.splatinsert555 = insertelement <8 x float> poison, float %851, i64 0
  %.splat556 = shufflevector <8 x float> %.splatinsert555, <8 x float> poison, <8 x i32> zeroinitializer
  %852 = fdiv <8 x float> %845, %.splat556
  %853 = extractvalue { ptr, i64 } %33, 0
  %854 = extractelement <8 x i64> %835, i32 %828
  %855 = zext i32 %828 to i64
  %856 = sub i64 %854, %855
  %857 = mul i64 %856, 4
  %buffer.contiguous.address557 = getelementptr i8, ptr %853, i64 %857
  call void @llvm.masked.store.v8f32.p0(<8 x float> %852, ptr %buffer.contiguous.address557, i32 1, <8 x i1> %823)
  %.state558 = load <8 x i64>, ptr %.slot44, align 64
  %858 = add <8 x i64> %.state558, splat (i64 1)
  %859 = load <8 x i64>, ptr %.slot44, align 64
  %860 = select <8 x i1> %823, <8 x i64> %858, <8 x i64> %859
  store <8 x i64> %860, ptr %.slot44, align 64
  store <8 x i1> %823, ptr %current.mask, align 1
  %861 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %823)
  br i1 %861, label %schedule.36, label %scheduler.loop

schedule.38:                                      ; preds = %varying.coherent.false548, %scheduler.dispatch.route
  %862 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token561 = load i32, ptr %current.token, align 4
  %convergence.token.present562 = icmp ne i32 %convergence.current.token561, 0
  br i1 %convergence.token.present562, label %convergence.cascade559, label %convergence.cascade.exit560

schedule.39:                                      ; preds = %varying.coherent.true583, %scheduler.dispatch.route
  %863 = load <8 x i1>, ptr %current.mask, align 1
  %864 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %863)
  %865 = bitcast <8 x i1> %863 to i8
  %866 = call i8 @llvm.cttz.i8(i8 %865, i1 false)
  %867 = zext i8 %866 to i32
  %868 = select i1 %864, i32 %867, i32 0
  %.spill.load585 = load <8 x i64>, ptr %.spill, align 64
  %869 = add <8 x i64> splat (i64 64), %.spill.load585
  %.spill.load586 = load <8 x i64>, ptr %.spill13, align 64
  %870 = add <8 x i64> %.spill.load586, zeroinitializer
  %871 = add <8 x i64> zeroinitializer, %870
  %872 = add <8 x i64> zeroinitializer, %869
  %873 = mul <8 x i64> %871, splat (i64 66)
  %874 = add <8 x i64> %873, %872
  %tile_snapshot.spill.load587 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %875 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load587, 0
  %876 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load587, 1
  %877 = add <8 x i64> %876, splat (i64 256)
  %878 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %875, 0
  %879 = insertvalue { <8 x ptr>, <8 x i64> } %878, <8 x i64> %877, 1
  %880 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %881 = extractvalue { <8 x ptr>, <8 x i64> } %879, 1
  %882 = extractelement <8 x ptr> %880, i32 0
  %883 = extractelement <8 x i64> %881, i32 %868
  %884 = zext i32 %868 to i64
  %885 = mul i64 %884, 4
  %886 = sub i64 %883, %885
  %887 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %863)
  %888 = select i1 %887, i64 %886, i64 0
  %private.contiguous.address588 = getelementptr i8, ptr %882, i64 %888
  %private.contiguous.load589 = load <8 x float>, ptr %private.contiguous.address588, align 4
  %889 = select <8 x i1> %863, <8 x float> %private.contiguous.load589, <8 x float> zeroinitializer
  %.spill.load590 = load <8 x float>, ptr %.spill43, align 32
  %890 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %863)
  %891 = bitcast <8 x i1> %863 to i8
  %892 = call i8 @llvm.cttz.i8(i8 %891, i1 false)
  %893 = zext i8 %892 to i32
  %894 = select i1 %890, i32 %893, i32 0
  %895 = extractelement <8 x float> %.spill.load590, i32 %894
  %.splatinsert591 = insertelement <8 x float> poison, float %895, i64 0
  %.splat592 = shufflevector <8 x float> %.splatinsert591, <8 x float> poison, <8 x i32> zeroinitializer
  %896 = fdiv <8 x float> %889, %.splat592
  %897 = extractvalue { ptr, i64 } %33, 0
  %898 = extractelement <8 x i64> %874, i32 %868
  %899 = zext i32 %868 to i64
  %900 = sub i64 %898, %899
  %901 = mul i64 %900, 4
  %buffer.contiguous.address593 = getelementptr i8, ptr %897, i64 %901
  call void @llvm.masked.store.v8f32.p0(<8 x float> %896, ptr %buffer.contiguous.address593, i32 1, <8 x i1> %863)
  store <8 x i1> %863, ptr %current.mask, align 1
  %902 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %863)
  br i1 %902, label %schedule.40, label %scheduler.loop

schedule.40:                                      ; preds = %schedule.39, %varying.coherent.false584, %scheduler.dispatch.route
  %903 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token596 = load i32, ptr %current.token, align 4
  %convergence.token.present597 = icmp ne i32 %convergence.current.token596, 0
  br i1 %convergence.token.present597, label %convergence.cascade594, label %convergence.cascade.exit595

uniform.true:                                     ; preds = %schedule.1
  store <8 x i1> %122, ptr %current.mask, align 1
  %904 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %122)
  br i1 %904, label %schedule.2, label %scheduler.loop

uniform.false:                                    ; preds = %schedule.1
  store <8 x i1> %122, ptr %current.mask, align 1
  %905 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %122)
  br i1 %905, label %schedule.3, label %scheduler.loop

varying.divergent:                                ; preds = %schedule.3
  %906 = load i32, ptr %current.token, align 4
  %907 = icmp ne i32 %906, 0
  %908 = sub i32 %906, 1
  %909 = select i1 %907, i32 %908, i32 0
  %910 = load i8, ptr %frame.active, align 1
  %911 = trunc i32 %909 to i8
  %912 = shl i8 1, %911
  %913 = and i8 %910, %912
  %914 = icmp ne i8 %913, 0
  %915 = load <8 x i32>, ptr %frame.static.id, align 32
  %916 = extractelement <8 x i32> %915, i32 %909
  %917 = icmp eq i32 %916, 0
  %918 = and i1 %914, %917
  %919 = and i1 %907, %918
  %920 = xor i1 %919, true
  %921 = and i1 true, %920
  %922 = xor i8 %910, -1
  %923 = icmp ne i8 %922, 0
  %924 = xor i1 %923, true
  %925 = and i1 %921, %924
  br i1 %925, label %convergence.overflow.trap, label %convergence.overflow.resume

varying.coherent:                                 ; preds = %schedule.3
  br i1 %203, label %varying.coherent.true, label %varying.coherent.false

convergence.overflow.trap:                        ; preds = %varying.divergent
  call void @llvm.trap()
  unreachable

convergence.overflow.resume:                      ; preds = %varying.divergent
  %926 = call i8 @llvm.cttz.i8(i8 %922, i1 false)
  %927 = zext i8 %926 to i32
  %928 = select i1 %923, i32 %927, i32 0
  %929 = trunc i32 %928 to i8
  %930 = shl i8 1, %929
  %931 = or i8 %910, %930
  %932 = select i1 %921, i8 %931, i8 %910
  store i8 %932, ptr %frame.active, align 1
  %933 = load <8 x i32>, ptr %frame.static.id, align 32
  %934 = extractelement <8 x i32> %933, i32 %928
  %935 = select i1 %921, i32 0, i32 %934
  %936 = load <8 x i32>, ptr %frame.static.id, align 32
  %937 = insertelement <8 x i32> %936, i32 %935, i32 %928
  store <8 x i32> %937, ptr %frame.static.id, align 32
  %938 = load <8 x i32>, ptr %frame.parent.token, align 32
  %939 = extractelement <8 x i32> %938, i32 %928
  %940 = select i1 %921, i32 %906, i32 %939
  %941 = load <8 x i32>, ptr %frame.parent.token, align 32
  %942 = insertelement <8 x i32> %941, i32 %940, i32 %928
  store <8 x i32> %942, ptr %frame.parent.token, align 32
  %943 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %928
  %944 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %928
  %945 = load <8 x i1>, ptr %943, align 1
  %946 = load <8 x i1>, ptr %944, align 1
  %947 = select i1 %921, <8 x i1> %191, <8 x i1> %945
  store <8 x i1> %947, ptr %943, align 1
  %948 = select i1 %921, <8 x i1> zeroinitializer, <8 x i1> %946
  store <8 x i1> %948, ptr %944, align 1
  %949 = add i32 %928, 1
  %950 = select i1 %919, i32 %906, i32 %949
  %951 = select i1 true, i32 %950, i32 %906
  store i32 %951, ptr %current.token, align 4
  %952 = load i32, ptr %current.token, align 4
  %953 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %200)
  %954 = load i32, ptr %ready.count, align 4
  %955 = icmp uge i32 %954, 8
  %956 = and i1 %953, %955
  br i1 %956, label %ready.overflow.trap66, label %ready.overflow.resume67

ready.overflow.trap66:                            ; preds = %convergence.overflow.resume
  call void @llvm.trap()
  unreachable

ready.overflow.resume67:                          ; preds = %convergence.overflow.resume
  %957 = select i1 %953, i32 %954, i32 0
  %958 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %957
  %959 = load <8 x i1>, ptr %958, align 1
  %960 = select i1 %953, <8 x i1> %200, <8 x i1> %959
  store <8 x i1> %960, ptr %958, align 1
  %961 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %957
  %962 = load i32, ptr %961, align 4
  %963 = select i1 %953, i32 4, i32 %962
  store i32 %963, ptr %961, align 4
  %964 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %957
  %965 = load i32, ptr %964, align 4
  %966 = select i1 %953, i32 %952, i32 %965
  store i32 %966, ptr %964, align 4
  %967 = add i32 %954, 1
  %968 = select i1 %953, i32 %967, i32 %954
  store i32 %968, ptr %ready.count, align 4
  %969 = load <8 x i1>, ptr %runnable.mask, align 1
  %970 = or <8 x i1> %969, %200
  store <8 x i1> %970, ptr %runnable.mask, align 1
  store <8 x i1> %202, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true:                            ; preds = %varying.coherent
  store <8 x i1> %191, ptr %current.mask, align 1
  %971 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %191)
  br i1 %971, label %schedule.4, label %scheduler.loop

varying.coherent.false:                           ; preds = %varying.coherent
  store <8 x i1> %191, ptr %current.mask, align 1
  %972 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %191)
  br i1 %972, label %schedule.5, label %scheduler.loop

convergence.cascade:                              ; preds = %convergence.cascade, %schedule.5
  %convergence.cascade.flow = phi <8 x i1> [ %239, %schedule.5 ], [ %1015, %convergence.cascade ]
  %convergence.cascade.depth = phi i32 [ 0, %schedule.5 ], [ %1016, %convergence.cascade ]
  %973 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow)
  %974 = load i32, ptr %current.token, align 4
  %975 = icmp ne i32 %974, 0
  %976 = and i1 %973, %975
  %977 = sub i32 %974, 1
  %978 = select i1 %976, i32 %977, i32 0
  %979 = load i8, ptr %frame.active, align 1
  %980 = trunc i32 %978 to i8
  %981 = shl i8 1, %980
  %982 = and i8 %979, %981
  %983 = icmp ne i8 %982, 0
  %984 = load <8 x i32>, ptr %frame.static.id, align 32
  %985 = extractelement <8 x i32> %984, i32 %978
  %convergence.target.pointer = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %985
  %convergence.dynamic.target = load i32, ptr %convergence.target.pointer, align 4
  %986 = icmp eq i32 %convergence.dynamic.target, 5
  %987 = and i1 %983, %986
  %988 = and i1 %976, %987
  %989 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %978
  %990 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %978
  %991 = load <8 x i1>, ptr %989, align 1
  %992 = load <8 x i1>, ptr %990, align 1
  %993 = or <8 x i1> %992, %convergence.cascade.flow
  %994 = load <8 x i1>, ptr %live.mask, align 1
  %995 = and <8 x i1> %991, %994
  %996 = icmp eq <8 x i1> %993, %995
  %997 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %996)
  %998 = and i1 %988, %997
  %999 = select i1 %998, <8 x i1> zeroinitializer, <8 x i1> %993
  %1000 = select i1 %988, <8 x i1> %999, <8 x i1> %992
  store <8 x i1> %1000, ptr %990, align 1
  %1001 = select i1 %998, <8 x i1> zeroinitializer, <8 x i1> %991
  store <8 x i1> %1001, ptr %989, align 1
  %1002 = trunc i32 %978 to i8
  %1003 = shl i8 1, %1002
  %1004 = xor i8 %1003, -1
  %1005 = and i8 %979, %1004
  %1006 = select i1 %998, i8 %1005, i8 %979
  store i8 %1006, ptr %frame.active, align 1
  %.splatinsert75 = insertelement <8 x i1> poison, i1 %988, i64 0
  %.splat76 = shufflevector <8 x i1> %.splatinsert75, <8 x i1> poison, <8 x i32> zeroinitializer
  %1007 = and <8 x i1> %convergence.cascade.flow, %.splat76
  %1008 = load <8 x i1>, ptr %runnable.mask, align 1
  %1009 = xor <8 x i1> %1007, splat (i1 true)
  %1010 = and <8 x i1> %1008, %1009
  store <8 x i1> %1010, ptr %runnable.mask, align 1
  %.splatinsert77 = insertelement <8 x i1> poison, i1 %998, i64 0
  %.splat78 = shufflevector <8 x i1> %.splatinsert77, <8 x i1> poison, <8 x i32> zeroinitializer
  %1011 = select <8 x i1> %.splat78, <8 x i1> %993, <8 x i1> zeroinitializer
  %1012 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1013 = extractelement <8 x i32> %1012, i32 %978
  %1014 = select i1 %998, i32 %1013, i32 %974
  store i32 %1014, ptr %current.token, align 4
  %.splatinsert79 = insertelement <8 x i1> poison, i1 %988, i64 0
  %.splat80 = shufflevector <8 x i1> %.splatinsert79, <8 x i1> poison, <8 x i32> zeroinitializer
  %1015 = select <8 x i1> %.splat80, <8 x i1> %1011, <8 x i1> %convergence.cascade.flow
  %1016 = add i32 %convergence.cascade.depth, 1
  %1017 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1015)
  %1018 = icmp ult i32 %1016, 8
  %1019 = and i1 %1017, %1018
  %1020 = and i1 %988, %1019
  %convergence.parent.token = load i32, ptr %current.token, align 4
  %convergence.parent.present = icmp ne i32 %convergence.parent.token, 0
  %1021 = and i1 %1020, %convergence.parent.present
  br i1 %1021, label %convergence.cascade, label %convergence.cascade.exit

convergence.cascade.exit:                         ; preds = %convergence.cascade, %schedule.5
  %convergence.cascade.result = phi <8 x i1> [ %239, %schedule.5 ], [ %1015, %convergence.cascade ]
  %1022 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %1022, label %convergence.target.5.ready, label %scheduler.loop

convergence.target.5.ready:                       ; preds = %convergence.cascade.exit
  %1023 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1024 = bitcast <8 x i1> %convergence.cascade.result to i8
  %1025 = call i8 @llvm.cttz.i8(i8 %1024, i1 false)
  %1026 = zext i8 %1025 to i32
  %1027 = select i1 %1023, i32 %1026, i32 0
  %1028 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %1029 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1030 = extractvalue { <8 x ptr>, <8 x i64> } %1028, 0
  %1031 = select <8 x i1> %convergence.cascade.result, <8 x ptr> %1029, <8 x ptr> %1030
  %1032 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %1033 = extractvalue { <8 x ptr>, <8 x i64> } %1028, 1
  %1034 = select <8 x i1> %convergence.cascade.result, <8 x i64> %1032, <8 x i64> %1033
  %1035 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1031, 0
  %1036 = insertvalue { <8 x ptr>, <8 x i64> } %1035, <8 x i64> %1034, 1
  store { <8 x ptr>, <8 x i64> } %1036, ptr %tile_snapshot.spill15, align 64
  %1037 = load <8 x i64>, ptr %.slot16, align 64
  %1038 = select <8 x i1> %convergence.cascade.result, <8 x i64> zeroinitializer, <8 x i64> %1037
  store <8 x i64> %1038, ptr %.slot16, align 64
  store <8 x i1> %convergence.cascade.result, ptr %current.mask, align 1
  %1039 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %1039, label %schedule.6, label %scheduler.loop

varying.divergent82:                              ; preds = %schedule.6
  %1040 = load i32, ptr %current.token, align 4
  %1041 = icmp ne i32 %1040, 0
  %1042 = sub i32 %1040, 1
  %1043 = select i1 %1041, i32 %1042, i32 0
  %1044 = load i8, ptr %frame.active, align 1
  %1045 = trunc i32 %1043 to i8
  %1046 = shl i8 1, %1045
  %1047 = and i8 %1044, %1046
  %1048 = icmp ne i8 %1047, 0
  %1049 = load <8 x i32>, ptr %frame.static.id, align 32
  %1050 = extractelement <8 x i32> %1049, i32 %1043
  %1051 = icmp eq i32 %1050, 1
  %1052 = and i1 %1048, %1051
  %1053 = and i1 %1041, %1052
  %1054 = xor i1 %1053, true
  %1055 = and i1 true, %1054
  %1056 = xor i8 %1044, -1
  %1057 = icmp ne i8 %1056, 0
  %1058 = xor i1 %1057, true
  %1059 = and i1 %1055, %1058
  br i1 %1059, label %convergence.overflow.trap84, label %convergence.overflow.resume85

varying.coherent83:                               ; preds = %schedule.6
  br i1 %250, label %varying.coherent.true88, label %varying.coherent.false89

convergence.overflow.trap84:                      ; preds = %varying.divergent82
  call void @llvm.trap()
  unreachable

convergence.overflow.resume85:                    ; preds = %varying.divergent82
  %1060 = call i8 @llvm.cttz.i8(i8 %1056, i1 false)
  %1061 = zext i8 %1060 to i32
  %1062 = select i1 %1057, i32 %1061, i32 0
  %1063 = trunc i32 %1062 to i8
  %1064 = shl i8 1, %1063
  %1065 = or i8 %1044, %1064
  %1066 = select i1 %1055, i8 %1065, i8 %1044
  store i8 %1066, ptr %frame.active, align 1
  %1067 = load <8 x i32>, ptr %frame.static.id, align 32
  %1068 = extractelement <8 x i32> %1067, i32 %1062
  %1069 = select i1 %1055, i32 1, i32 %1068
  %1070 = load <8 x i32>, ptr %frame.static.id, align 32
  %1071 = insertelement <8 x i32> %1070, i32 %1069, i32 %1062
  store <8 x i32> %1071, ptr %frame.static.id, align 32
  %1072 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1073 = extractelement <8 x i32> %1072, i32 %1062
  %1074 = select i1 %1055, i32 %1040, i32 %1073
  %1075 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1076 = insertelement <8 x i32> %1075, i32 %1074, i32 %1062
  store <8 x i32> %1076, ptr %frame.parent.token, align 32
  %1077 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1062
  %1078 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1062
  %1079 = load <8 x i1>, ptr %1077, align 1
  %1080 = load <8 x i1>, ptr %1078, align 1
  %1081 = select i1 %1055, <8 x i1> %240, <8 x i1> %1079
  store <8 x i1> %1081, ptr %1077, align 1
  %1082 = select i1 %1055, <8 x i1> zeroinitializer, <8 x i1> %1080
  store <8 x i1> %1082, ptr %1078, align 1
  %1083 = add i32 %1062, 1
  %1084 = select i1 %1053, i32 %1040, i32 %1083
  %1085 = select i1 true, i32 %1084, i32 %1040
  store i32 %1085, ptr %current.token, align 4
  %1086 = load i32, ptr %current.token, align 4
  %1087 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %247)
  %1088 = load i32, ptr %ready.count, align 4
  %1089 = icmp uge i32 %1088, 8
  %1090 = and i1 %1087, %1089
  br i1 %1090, label %ready.overflow.trap86, label %ready.overflow.resume87

ready.overflow.trap86:                            ; preds = %convergence.overflow.resume85
  call void @llvm.trap()
  unreachable

ready.overflow.resume87:                          ; preds = %convergence.overflow.resume85
  %1091 = select i1 %1087, i32 %1088, i32 0
  %1092 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1091
  %1093 = load <8 x i1>, ptr %1092, align 1
  %1094 = select i1 %1087, <8 x i1> %247, <8 x i1> %1093
  store <8 x i1> %1094, ptr %1092, align 1
  %1095 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1091
  %1096 = load i32, ptr %1095, align 4
  %1097 = select i1 %1087, i32 7, i32 %1096
  store i32 %1097, ptr %1095, align 4
  %1098 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1091
  %1099 = load i32, ptr %1098, align 4
  %1100 = select i1 %1087, i32 %1086, i32 %1099
  store i32 %1100, ptr %1098, align 4
  %1101 = add i32 %1088, 1
  %1102 = select i1 %1087, i32 %1101, i32 %1088
  store i32 %1102, ptr %ready.count, align 4
  %1103 = load <8 x i1>, ptr %runnable.mask, align 1
  %1104 = or <8 x i1> %1103, %247
  store <8 x i1> %1104, ptr %runnable.mask, align 1
  store <8 x i1> %249, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true88:                          ; preds = %varying.coherent83
  store <8 x i1> %240, ptr %current.mask, align 1
  %1105 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %240)
  br i1 %1105, label %schedule.7, label %scheduler.loop

varying.coherent.false89:                         ; preds = %varying.coherent83
  store <8 x i1> %240, ptr %current.mask, align 1
  %1106 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %240)
  br i1 %1106, label %schedule.8, label %scheduler.loop

convergence.cascade95:                            ; preds = %convergence.cascade95, %schedule.8
  %convergence.cascade.flow99 = phi <8 x i1> [ %274, %schedule.8 ], [ %1149, %convergence.cascade95 ]
  %convergence.cascade.depth100 = phi i32 [ 0, %schedule.8 ], [ %1150, %convergence.cascade95 ]
  %1107 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow99)
  %1108 = load i32, ptr %current.token, align 4
  %1109 = icmp ne i32 %1108, 0
  %1110 = and i1 %1107, %1109
  %1111 = sub i32 %1108, 1
  %1112 = select i1 %1110, i32 %1111, i32 0
  %1113 = load i8, ptr %frame.active, align 1
  %1114 = trunc i32 %1112 to i8
  %1115 = shl i8 1, %1114
  %1116 = and i8 %1113, %1115
  %1117 = icmp ne i8 %1116, 0
  %1118 = load <8 x i32>, ptr %frame.static.id, align 32
  %1119 = extractelement <8 x i32> %1118, i32 %1112
  %convergence.target.pointer101 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %1119
  %convergence.dynamic.target102 = load i32, ptr %convergence.target.pointer101, align 4
  %1120 = icmp eq i32 %convergence.dynamic.target102, 8
  %1121 = and i1 %1117, %1120
  %1122 = and i1 %1110, %1121
  %1123 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1112
  %1124 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1112
  %1125 = load <8 x i1>, ptr %1123, align 1
  %1126 = load <8 x i1>, ptr %1124, align 1
  %1127 = or <8 x i1> %1126, %convergence.cascade.flow99
  %1128 = load <8 x i1>, ptr %live.mask, align 1
  %1129 = and <8 x i1> %1125, %1128
  %1130 = icmp eq <8 x i1> %1127, %1129
  %1131 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1130)
  %1132 = and i1 %1122, %1131
  %1133 = select i1 %1132, <8 x i1> zeroinitializer, <8 x i1> %1127
  %1134 = select i1 %1122, <8 x i1> %1133, <8 x i1> %1126
  store <8 x i1> %1134, ptr %1124, align 1
  %1135 = select i1 %1132, <8 x i1> zeroinitializer, <8 x i1> %1125
  store <8 x i1> %1135, ptr %1123, align 1
  %1136 = trunc i32 %1112 to i8
  %1137 = shl i8 1, %1136
  %1138 = xor i8 %1137, -1
  %1139 = and i8 %1113, %1138
  %1140 = select i1 %1132, i8 %1139, i8 %1113
  store i8 %1140, ptr %frame.active, align 1
  %.splatinsert103 = insertelement <8 x i1> poison, i1 %1122, i64 0
  %.splat104 = shufflevector <8 x i1> %.splatinsert103, <8 x i1> poison, <8 x i32> zeroinitializer
  %1141 = and <8 x i1> %convergence.cascade.flow99, %.splat104
  %1142 = load <8 x i1>, ptr %runnable.mask, align 1
  %1143 = xor <8 x i1> %1141, splat (i1 true)
  %1144 = and <8 x i1> %1142, %1143
  store <8 x i1> %1144, ptr %runnable.mask, align 1
  %.splatinsert105 = insertelement <8 x i1> poison, i1 %1132, i64 0
  %.splat106 = shufflevector <8 x i1> %.splatinsert105, <8 x i1> poison, <8 x i32> zeroinitializer
  %1145 = select <8 x i1> %.splat106, <8 x i1> %1127, <8 x i1> zeroinitializer
  %1146 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1147 = extractelement <8 x i32> %1146, i32 %1112
  %1148 = select i1 %1132, i32 %1147, i32 %1108
  store i32 %1148, ptr %current.token, align 4
  %.splatinsert107 = insertelement <8 x i1> poison, i1 %1122, i64 0
  %.splat108 = shufflevector <8 x i1> %.splatinsert107, <8 x i1> poison, <8 x i32> zeroinitializer
  %1149 = select <8 x i1> %.splat108, <8 x i1> %1145, <8 x i1> %convergence.cascade.flow99
  %1150 = add i32 %convergence.cascade.depth100, 1
  %1151 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1149)
  %1152 = icmp ult i32 %1150, 8
  %1153 = and i1 %1151, %1152
  %1154 = and i1 %1122, %1153
  %convergence.parent.token109 = load i32, ptr %current.token, align 4
  %convergence.parent.present110 = icmp ne i32 %convergence.parent.token109, 0
  %1155 = and i1 %1154, %convergence.parent.present110
  br i1 %1155, label %convergence.cascade95, label %convergence.cascade.exit96

convergence.cascade.exit96:                       ; preds = %convergence.cascade95, %schedule.8
  %convergence.cascade.result111 = phi <8 x i1> [ %274, %schedule.8 ], [ %1149, %convergence.cascade95 ]
  %1156 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result111)
  br i1 %1156, label %convergence.target.8.ready, label %scheduler.loop

convergence.target.8.ready:                       ; preds = %convergence.cascade.exit96
  %1157 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result111)
  %1158 = bitcast <8 x i1> %convergence.cascade.result111 to i8
  %1159 = call i8 @llvm.cttz.i8(i8 %1158, i1 false)
  %1160 = zext i8 %1159 to i32
  %1161 = select i1 %1157, i32 %1160, i32 0
  %.spill.load112 = load <8 x i1>, ptr %.spill14, align 1
  %1162 = and <8 x i1> %convergence.cascade.result111, %.spill.load112
  %1163 = xor <8 x i1> %.spill.load112, splat (i1 true)
  %1164 = and <8 x i1> %convergence.cascade.result111, %1163
  %1165 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1162)
  %1166 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1164)
  %1167 = and i1 %1165, %1166
  br i1 %1167, label %varying.divergent113, label %varying.coherent114

varying.divergent113:                             ; preds = %convergence.target.8.ready
  %1168 = load i32, ptr %current.token, align 4
  %1169 = icmp ne i32 %1168, 0
  %1170 = sub i32 %1168, 1
  %1171 = select i1 %1169, i32 %1170, i32 0
  %1172 = load i8, ptr %frame.active, align 1
  %1173 = trunc i32 %1171 to i8
  %1174 = shl i8 1, %1173
  %1175 = and i8 %1172, %1174
  %1176 = icmp ne i8 %1175, 0
  %1177 = load <8 x i32>, ptr %frame.static.id, align 32
  %1178 = extractelement <8 x i32> %1177, i32 %1171
  %1179 = icmp eq i32 %1178, 2
  %1180 = and i1 %1176, %1179
  %1181 = and i1 %1169, %1180
  %1182 = xor i1 %1181, true
  %1183 = and i1 true, %1182
  %1184 = xor i8 %1172, -1
  %1185 = icmp ne i8 %1184, 0
  %1186 = xor i1 %1185, true
  %1187 = and i1 %1183, %1186
  br i1 %1187, label %convergence.overflow.trap115, label %convergence.overflow.resume116

varying.coherent114:                              ; preds = %convergence.target.8.ready
  br i1 %1165, label %varying.coherent.true119, label %varying.coherent.false120

convergence.overflow.trap115:                     ; preds = %varying.divergent113
  call void @llvm.trap()
  unreachable

convergence.overflow.resume116:                   ; preds = %varying.divergent113
  %1188 = call i8 @llvm.cttz.i8(i8 %1184, i1 false)
  %1189 = zext i8 %1188 to i32
  %1190 = select i1 %1185, i32 %1189, i32 0
  %1191 = trunc i32 %1190 to i8
  %1192 = shl i8 1, %1191
  %1193 = or i8 %1172, %1192
  %1194 = select i1 %1183, i8 %1193, i8 %1172
  store i8 %1194, ptr %frame.active, align 1
  %1195 = load <8 x i32>, ptr %frame.static.id, align 32
  %1196 = extractelement <8 x i32> %1195, i32 %1190
  %1197 = select i1 %1183, i32 2, i32 %1196
  %1198 = load <8 x i32>, ptr %frame.static.id, align 32
  %1199 = insertelement <8 x i32> %1198, i32 %1197, i32 %1190
  store <8 x i32> %1199, ptr %frame.static.id, align 32
  %1200 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1201 = extractelement <8 x i32> %1200, i32 %1190
  %1202 = select i1 %1183, i32 %1168, i32 %1201
  %1203 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1204 = insertelement <8 x i32> %1203, i32 %1202, i32 %1190
  store <8 x i32> %1204, ptr %frame.parent.token, align 32
  %1205 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1190
  %1206 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1190
  %1207 = load <8 x i1>, ptr %1205, align 1
  %1208 = load <8 x i1>, ptr %1206, align 1
  %1209 = select i1 %1183, <8 x i1> %convergence.cascade.result111, <8 x i1> %1207
  store <8 x i1> %1209, ptr %1205, align 1
  %1210 = select i1 %1183, <8 x i1> zeroinitializer, <8 x i1> %1208
  store <8 x i1> %1210, ptr %1206, align 1
  %1211 = add i32 %1190, 1
  %1212 = select i1 %1181, i32 %1168, i32 %1211
  %1213 = select i1 true, i32 %1212, i32 %1168
  store i32 %1213, ptr %current.token, align 4
  %1214 = load i32, ptr %current.token, align 4
  %1215 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1162)
  %1216 = load i32, ptr %ready.count, align 4
  %1217 = icmp uge i32 %1216, 8
  %1218 = and i1 %1215, %1217
  br i1 %1218, label %ready.overflow.trap117, label %ready.overflow.resume118

ready.overflow.trap117:                           ; preds = %convergence.overflow.resume116
  call void @llvm.trap()
  unreachable

ready.overflow.resume118:                         ; preds = %convergence.overflow.resume116
  %1219 = select i1 %1215, i32 %1216, i32 0
  %1220 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1219
  %1221 = load <8 x i1>, ptr %1220, align 1
  %1222 = select i1 %1215, <8 x i1> %1162, <8 x i1> %1221
  store <8 x i1> %1222, ptr %1220, align 1
  %1223 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1219
  %1224 = load i32, ptr %1223, align 4
  %1225 = select i1 %1215, i32 9, i32 %1224
  store i32 %1225, ptr %1223, align 4
  %1226 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1219
  %1227 = load i32, ptr %1226, align 4
  %1228 = select i1 %1215, i32 %1214, i32 %1227
  store i32 %1228, ptr %1226, align 4
  %1229 = add i32 %1216, 1
  %1230 = select i1 %1215, i32 %1229, i32 %1216
  store i32 %1230, ptr %ready.count, align 4
  %1231 = load <8 x i1>, ptr %runnable.mask, align 1
  %1232 = or <8 x i1> %1231, %1162
  store <8 x i1> %1232, ptr %runnable.mask, align 1
  store <8 x i1> %1164, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true119:                         ; preds = %varying.coherent114
  store <8 x i1> %convergence.cascade.result111, ptr %current.mask, align 1
  %1233 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result111)
  br i1 %1233, label %schedule.9, label %scheduler.loop

varying.coherent.false120:                        ; preds = %varying.coherent114
  store <8 x i1> %convergence.cascade.result111, ptr %current.mask, align 1
  %1234 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result111)
  br i1 %1234, label %schedule.10, label %scheduler.loop

convergence.cascade125:                           ; preds = %convergence.cascade125, %schedule.10
  %convergence.cascade.flow129 = phi <8 x i1> [ %298, %schedule.10 ], [ %1277, %convergence.cascade125 ]
  %convergence.cascade.depth130 = phi i32 [ 0, %schedule.10 ], [ %1278, %convergence.cascade125 ]
  %1235 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow129)
  %1236 = load i32, ptr %current.token, align 4
  %1237 = icmp ne i32 %1236, 0
  %1238 = and i1 %1235, %1237
  %1239 = sub i32 %1236, 1
  %1240 = select i1 %1238, i32 %1239, i32 0
  %1241 = load i8, ptr %frame.active, align 1
  %1242 = trunc i32 %1240 to i8
  %1243 = shl i8 1, %1242
  %1244 = and i8 %1241, %1243
  %1245 = icmp ne i8 %1244, 0
  %1246 = load <8 x i32>, ptr %frame.static.id, align 32
  %1247 = extractelement <8 x i32> %1246, i32 %1240
  %convergence.target.pointer131 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %1247
  %convergence.dynamic.target132 = load i32, ptr %convergence.target.pointer131, align 4
  %1248 = icmp eq i32 %convergence.dynamic.target132, 10
  %1249 = and i1 %1245, %1248
  %1250 = and i1 %1238, %1249
  %1251 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1240
  %1252 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1240
  %1253 = load <8 x i1>, ptr %1251, align 1
  %1254 = load <8 x i1>, ptr %1252, align 1
  %1255 = or <8 x i1> %1254, %convergence.cascade.flow129
  %1256 = load <8 x i1>, ptr %live.mask, align 1
  %1257 = and <8 x i1> %1253, %1256
  %1258 = icmp eq <8 x i1> %1255, %1257
  %1259 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1258)
  %1260 = and i1 %1250, %1259
  %1261 = select i1 %1260, <8 x i1> zeroinitializer, <8 x i1> %1255
  %1262 = select i1 %1250, <8 x i1> %1261, <8 x i1> %1254
  store <8 x i1> %1262, ptr %1252, align 1
  %1263 = select i1 %1260, <8 x i1> zeroinitializer, <8 x i1> %1253
  store <8 x i1> %1263, ptr %1251, align 1
  %1264 = trunc i32 %1240 to i8
  %1265 = shl i8 1, %1264
  %1266 = xor i8 %1265, -1
  %1267 = and i8 %1241, %1266
  %1268 = select i1 %1260, i8 %1267, i8 %1241
  store i8 %1268, ptr %frame.active, align 1
  %.splatinsert133 = insertelement <8 x i1> poison, i1 %1250, i64 0
  %.splat134 = shufflevector <8 x i1> %.splatinsert133, <8 x i1> poison, <8 x i32> zeroinitializer
  %1269 = and <8 x i1> %convergence.cascade.flow129, %.splat134
  %1270 = load <8 x i1>, ptr %runnable.mask, align 1
  %1271 = xor <8 x i1> %1269, splat (i1 true)
  %1272 = and <8 x i1> %1270, %1271
  store <8 x i1> %1272, ptr %runnable.mask, align 1
  %.splatinsert135 = insertelement <8 x i1> poison, i1 %1260, i64 0
  %.splat136 = shufflevector <8 x i1> %.splatinsert135, <8 x i1> poison, <8 x i32> zeroinitializer
  %1273 = select <8 x i1> %.splat136, <8 x i1> %1255, <8 x i1> zeroinitializer
  %1274 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1275 = extractelement <8 x i32> %1274, i32 %1240
  %1276 = select i1 %1260, i32 %1275, i32 %1236
  store i32 %1276, ptr %current.token, align 4
  %.splatinsert137 = insertelement <8 x i1> poison, i1 %1250, i64 0
  %.splat138 = shufflevector <8 x i1> %.splatinsert137, <8 x i1> poison, <8 x i32> zeroinitializer
  %1277 = select <8 x i1> %.splat138, <8 x i1> %1273, <8 x i1> %convergence.cascade.flow129
  %1278 = add i32 %convergence.cascade.depth130, 1
  %1279 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1277)
  %1280 = icmp ult i32 %1278, 8
  %1281 = and i1 %1279, %1280
  %1282 = and i1 %1250, %1281
  %convergence.parent.token139 = load i32, ptr %current.token, align 4
  %convergence.parent.present140 = icmp ne i32 %convergence.parent.token139, 0
  %1283 = and i1 %1282, %convergence.parent.present140
  br i1 %1283, label %convergence.cascade125, label %convergence.cascade.exit126

convergence.cascade.exit126:                      ; preds = %convergence.cascade125, %schedule.10
  %convergence.cascade.result141 = phi <8 x i1> [ %298, %schedule.10 ], [ %1277, %convergence.cascade125 ]
  %1284 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result141)
  br i1 %1284, label %convergence.target.10.ready, label %scheduler.loop

convergence.target.10.ready:                      ; preds = %convergence.cascade.exit126
  %1285 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result141)
  %1286 = bitcast <8 x i1> %convergence.cascade.result141 to i8
  %1287 = call i8 @llvm.cttz.i8(i8 %1286, i1 false)
  %1288 = zext i8 %1287 to i32
  %1289 = select i1 %1285, i32 %1288, i32 0
  %.spill.load142 = load <8 x i64>, ptr %.spill13, align 64
  %1290 = select <8 x i1> %convergence.cascade.result141, <8 x i64> %.spill.load142, <8 x i64> zeroinitializer
  %1291 = select <8 x i1> %convergence.cascade.result141, <8 x i64> splat (i64 66), <8 x i64> splat (i64 1)
  %1292 = srem <8 x i64> %1290, %1291
  %1293 = load <8 x i64>, ptr %.spill17, align 64
  %1294 = select <8 x i1> %convergence.cascade.result141, <8 x i64> %1292, <8 x i64> %1293
  store <8 x i64> %1294, ptr %.spill17, align 64
  %1295 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %1296 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1297 = extractvalue { <8 x ptr>, <8 x i64> } %1295, 0
  %1298 = select <8 x i1> %convergence.cascade.result141, <8 x ptr> %1296, <8 x ptr> %1297
  %1299 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1300 = extractvalue { <8 x ptr>, <8 x i64> } %1295, 1
  %1301 = select <8 x i1> %convergence.cascade.result141, <8 x i64> %1299, <8 x i64> %1300
  %1302 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1298, 0
  %1303 = insertvalue { <8 x ptr>, <8 x i64> } %1302, <8 x i64> %1301, 1
  store { <8 x ptr>, <8 x i64> } %1303, ptr %tile_snapshot.spill18, align 64
  %1304 = load <8 x i64>, ptr %.slot19, align 64
  %1305 = select <8 x i1> %convergence.cascade.result141, <8 x i64> zeroinitializer, <8 x i64> %1304
  store <8 x i64> %1305, ptr %.slot19, align 64
  store <8 x i1> %convergence.cascade.result141, ptr %current.mask, align 1
  %1306 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result141)
  br i1 %1306, label %schedule.11, label %scheduler.loop

varying.divergent144:                             ; preds = %schedule.11
  %1307 = load i32, ptr %current.token, align 4
  %1308 = icmp ne i32 %1307, 0
  %1309 = sub i32 %1307, 1
  %1310 = select i1 %1308, i32 %1309, i32 0
  %1311 = load i8, ptr %frame.active, align 1
  %1312 = trunc i32 %1310 to i8
  %1313 = shl i8 1, %1312
  %1314 = and i8 %1311, %1313
  %1315 = icmp ne i8 %1314, 0
  %1316 = load <8 x i32>, ptr %frame.static.id, align 32
  %1317 = extractelement <8 x i32> %1316, i32 %1310
  %1318 = icmp eq i32 %1317, 3
  %1319 = and i1 %1315, %1318
  %1320 = and i1 %1308, %1319
  %1321 = xor i1 %1320, true
  %1322 = and i1 true, %1321
  %1323 = xor i8 %1311, -1
  %1324 = icmp ne i8 %1323, 0
  %1325 = xor i1 %1324, true
  %1326 = and i1 %1322, %1325
  br i1 %1326, label %convergence.overflow.trap146, label %convergence.overflow.resume147

varying.coherent145:                              ; preds = %schedule.11
  br i1 %309, label %varying.coherent.true150, label %varying.coherent.false151

convergence.overflow.trap146:                     ; preds = %varying.divergent144
  call void @llvm.trap()
  unreachable

convergence.overflow.resume147:                   ; preds = %varying.divergent144
  %1327 = call i8 @llvm.cttz.i8(i8 %1323, i1 false)
  %1328 = zext i8 %1327 to i32
  %1329 = select i1 %1324, i32 %1328, i32 0
  %1330 = trunc i32 %1329 to i8
  %1331 = shl i8 1, %1330
  %1332 = or i8 %1311, %1331
  %1333 = select i1 %1322, i8 %1332, i8 %1311
  store i8 %1333, ptr %frame.active, align 1
  %1334 = load <8 x i32>, ptr %frame.static.id, align 32
  %1335 = extractelement <8 x i32> %1334, i32 %1329
  %1336 = select i1 %1322, i32 3, i32 %1335
  %1337 = load <8 x i32>, ptr %frame.static.id, align 32
  %1338 = insertelement <8 x i32> %1337, i32 %1336, i32 %1329
  store <8 x i32> %1338, ptr %frame.static.id, align 32
  %1339 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1340 = extractelement <8 x i32> %1339, i32 %1329
  %1341 = select i1 %1322, i32 %1307, i32 %1340
  %1342 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1343 = insertelement <8 x i32> %1342, i32 %1341, i32 %1329
  store <8 x i32> %1343, ptr %frame.parent.token, align 32
  %1344 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1329
  %1345 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1329
  %1346 = load <8 x i1>, ptr %1344, align 1
  %1347 = load <8 x i1>, ptr %1345, align 1
  %1348 = select i1 %1322, <8 x i1> %299, <8 x i1> %1346
  store <8 x i1> %1348, ptr %1344, align 1
  %1349 = select i1 %1322, <8 x i1> zeroinitializer, <8 x i1> %1347
  store <8 x i1> %1349, ptr %1345, align 1
  %1350 = add i32 %1329, 1
  %1351 = select i1 %1320, i32 %1307, i32 %1350
  %1352 = select i1 true, i32 %1351, i32 %1307
  store i32 %1352, ptr %current.token, align 4
  %1353 = load i32, ptr %current.token, align 4
  %1354 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %306)
  %1355 = load i32, ptr %ready.count, align 4
  %1356 = icmp uge i32 %1355, 8
  %1357 = and i1 %1354, %1356
  br i1 %1357, label %ready.overflow.trap148, label %ready.overflow.resume149

ready.overflow.trap148:                           ; preds = %convergence.overflow.resume147
  call void @llvm.trap()
  unreachable

ready.overflow.resume149:                         ; preds = %convergence.overflow.resume147
  %1358 = select i1 %1354, i32 %1355, i32 0
  %1359 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1358
  %1360 = load <8 x i1>, ptr %1359, align 1
  %1361 = select i1 %1354, <8 x i1> %306, <8 x i1> %1360
  store <8 x i1> %1361, ptr %1359, align 1
  %1362 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1358
  %1363 = load i32, ptr %1362, align 4
  %1364 = select i1 %1354, i32 12, i32 %1363
  store i32 %1364, ptr %1362, align 4
  %1365 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1358
  %1366 = load i32, ptr %1365, align 4
  %1367 = select i1 %1354, i32 %1353, i32 %1366
  store i32 %1367, ptr %1365, align 4
  %1368 = add i32 %1355, 1
  %1369 = select i1 %1354, i32 %1368, i32 %1355
  store i32 %1369, ptr %ready.count, align 4
  %1370 = load <8 x i1>, ptr %runnable.mask, align 1
  %1371 = or <8 x i1> %1370, %306
  store <8 x i1> %1371, ptr %runnable.mask, align 1
  store <8 x i1> %308, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true150:                         ; preds = %varying.coherent145
  store <8 x i1> %299, ptr %current.mask, align 1
  %1372 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %299)
  br i1 %1372, label %schedule.12, label %scheduler.loop

varying.coherent.false151:                        ; preds = %varying.coherent145
  store <8 x i1> %299, ptr %current.mask, align 1
  %1373 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %299)
  br i1 %1373, label %schedule.13, label %scheduler.loop

convergence.cascade158:                           ; preds = %convergence.cascade158, %schedule.13
  %convergence.cascade.flow162 = phi <8 x i1> [ %342, %schedule.13 ], [ %1416, %convergence.cascade158 ]
  %convergence.cascade.depth163 = phi i32 [ 0, %schedule.13 ], [ %1417, %convergence.cascade158 ]
  %1374 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow162)
  %1375 = load i32, ptr %current.token, align 4
  %1376 = icmp ne i32 %1375, 0
  %1377 = and i1 %1374, %1376
  %1378 = sub i32 %1375, 1
  %1379 = select i1 %1377, i32 %1378, i32 0
  %1380 = load i8, ptr %frame.active, align 1
  %1381 = trunc i32 %1379 to i8
  %1382 = shl i8 1, %1381
  %1383 = and i8 %1380, %1382
  %1384 = icmp ne i8 %1383, 0
  %1385 = load <8 x i32>, ptr %frame.static.id, align 32
  %1386 = extractelement <8 x i32> %1385, i32 %1379
  %convergence.target.pointer164 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %1386
  %convergence.dynamic.target165 = load i32, ptr %convergence.target.pointer164, align 4
  %1387 = icmp eq i32 %convergence.dynamic.target165, 13
  %1388 = and i1 %1384, %1387
  %1389 = and i1 %1377, %1388
  %1390 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1379
  %1391 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1379
  %1392 = load <8 x i1>, ptr %1390, align 1
  %1393 = load <8 x i1>, ptr %1391, align 1
  %1394 = or <8 x i1> %1393, %convergence.cascade.flow162
  %1395 = load <8 x i1>, ptr %live.mask, align 1
  %1396 = and <8 x i1> %1392, %1395
  %1397 = icmp eq <8 x i1> %1394, %1396
  %1398 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1397)
  %1399 = and i1 %1389, %1398
  %1400 = select i1 %1399, <8 x i1> zeroinitializer, <8 x i1> %1394
  %1401 = select i1 %1389, <8 x i1> %1400, <8 x i1> %1393
  store <8 x i1> %1401, ptr %1391, align 1
  %1402 = select i1 %1399, <8 x i1> zeroinitializer, <8 x i1> %1392
  store <8 x i1> %1402, ptr %1390, align 1
  %1403 = trunc i32 %1379 to i8
  %1404 = shl i8 1, %1403
  %1405 = xor i8 %1404, -1
  %1406 = and i8 %1380, %1405
  %1407 = select i1 %1399, i8 %1406, i8 %1380
  store i8 %1407, ptr %frame.active, align 1
  %.splatinsert166 = insertelement <8 x i1> poison, i1 %1389, i64 0
  %.splat167 = shufflevector <8 x i1> %.splatinsert166, <8 x i1> poison, <8 x i32> zeroinitializer
  %1408 = and <8 x i1> %convergence.cascade.flow162, %.splat167
  %1409 = load <8 x i1>, ptr %runnable.mask, align 1
  %1410 = xor <8 x i1> %1408, splat (i1 true)
  %1411 = and <8 x i1> %1409, %1410
  store <8 x i1> %1411, ptr %runnable.mask, align 1
  %.splatinsert168 = insertelement <8 x i1> poison, i1 %1399, i64 0
  %.splat169 = shufflevector <8 x i1> %.splatinsert168, <8 x i1> poison, <8 x i32> zeroinitializer
  %1412 = select <8 x i1> %.splat169, <8 x i1> %1394, <8 x i1> zeroinitializer
  %1413 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1414 = extractelement <8 x i32> %1413, i32 %1379
  %1415 = select i1 %1399, i32 %1414, i32 %1375
  store i32 %1415, ptr %current.token, align 4
  %.splatinsert170 = insertelement <8 x i1> poison, i1 %1389, i64 0
  %.splat171 = shufflevector <8 x i1> %.splatinsert170, <8 x i1> poison, <8 x i32> zeroinitializer
  %1416 = select <8 x i1> %.splat171, <8 x i1> %1412, <8 x i1> %convergence.cascade.flow162
  %1417 = add i32 %convergence.cascade.depth163, 1
  %1418 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1416)
  %1419 = icmp ult i32 %1417, 8
  %1420 = and i1 %1418, %1419
  %1421 = and i1 %1389, %1420
  %convergence.parent.token172 = load i32, ptr %current.token, align 4
  %convergence.parent.present173 = icmp ne i32 %convergence.parent.token172, 0
  %1422 = and i1 %1421, %convergence.parent.present173
  br i1 %1422, label %convergence.cascade158, label %convergence.cascade.exit159

convergence.cascade.exit159:                      ; preds = %convergence.cascade158, %schedule.13
  %convergence.cascade.result174 = phi <8 x i1> [ %342, %schedule.13 ], [ %1416, %convergence.cascade158 ]
  %1423 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result174)
  br i1 %1423, label %convergence.target.13.ready, label %scheduler.loop

convergence.target.13.ready:                      ; preds = %convergence.cascade.exit159
  %1424 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result174)
  %1425 = bitcast <8 x i1> %convergence.cascade.result174 to i8
  %1426 = call i8 @llvm.cttz.i8(i8 %1425, i1 false)
  %1427 = zext i8 %1426 to i32
  %1428 = select i1 %1424, i32 %1427, i32 0
  %.spill.load175 = load <8 x i1>, ptr %.spill14, align 1
  %1429 = and <8 x i1> %convergence.cascade.result174, %.spill.load175
  %1430 = xor <8 x i1> %.spill.load175, splat (i1 true)
  %1431 = and <8 x i1> %convergence.cascade.result174, %1430
  %1432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1429)
  %1433 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1431)
  %1434 = and i1 %1432, %1433
  br i1 %1434, label %varying.divergent176, label %varying.coherent177

varying.divergent176:                             ; preds = %convergence.target.13.ready
  %1435 = load i32, ptr %current.token, align 4
  %1436 = icmp ne i32 %1435, 0
  %1437 = sub i32 %1435, 1
  %1438 = select i1 %1436, i32 %1437, i32 0
  %1439 = load i8, ptr %frame.active, align 1
  %1440 = trunc i32 %1438 to i8
  %1441 = shl i8 1, %1440
  %1442 = and i8 %1439, %1441
  %1443 = icmp ne i8 %1442, 0
  %1444 = load <8 x i32>, ptr %frame.static.id, align 32
  %1445 = extractelement <8 x i32> %1444, i32 %1438
  %1446 = icmp eq i32 %1445, 4
  %1447 = and i1 %1443, %1446
  %1448 = and i1 %1436, %1447
  %1449 = xor i1 %1448, true
  %1450 = and i1 true, %1449
  %1451 = xor i8 %1439, -1
  %1452 = icmp ne i8 %1451, 0
  %1453 = xor i1 %1452, true
  %1454 = and i1 %1450, %1453
  br i1 %1454, label %convergence.overflow.trap178, label %convergence.overflow.resume179

varying.coherent177:                              ; preds = %convergence.target.13.ready
  br i1 %1432, label %varying.coherent.true182, label %varying.coherent.false183

convergence.overflow.trap178:                     ; preds = %varying.divergent176
  call void @llvm.trap()
  unreachable

convergence.overflow.resume179:                   ; preds = %varying.divergent176
  %1455 = call i8 @llvm.cttz.i8(i8 %1451, i1 false)
  %1456 = zext i8 %1455 to i32
  %1457 = select i1 %1452, i32 %1456, i32 0
  %1458 = trunc i32 %1457 to i8
  %1459 = shl i8 1, %1458
  %1460 = or i8 %1439, %1459
  %1461 = select i1 %1450, i8 %1460, i8 %1439
  store i8 %1461, ptr %frame.active, align 1
  %1462 = load <8 x i32>, ptr %frame.static.id, align 32
  %1463 = extractelement <8 x i32> %1462, i32 %1457
  %1464 = select i1 %1450, i32 4, i32 %1463
  %1465 = load <8 x i32>, ptr %frame.static.id, align 32
  %1466 = insertelement <8 x i32> %1465, i32 %1464, i32 %1457
  store <8 x i32> %1466, ptr %frame.static.id, align 32
  %1467 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1468 = extractelement <8 x i32> %1467, i32 %1457
  %1469 = select i1 %1450, i32 %1435, i32 %1468
  %1470 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1471 = insertelement <8 x i32> %1470, i32 %1469, i32 %1457
  store <8 x i32> %1471, ptr %frame.parent.token, align 32
  %1472 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1457
  %1473 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1457
  %1474 = load <8 x i1>, ptr %1472, align 1
  %1475 = load <8 x i1>, ptr %1473, align 1
  %1476 = select i1 %1450, <8 x i1> %convergence.cascade.result174, <8 x i1> %1474
  store <8 x i1> %1476, ptr %1472, align 1
  %1477 = select i1 %1450, <8 x i1> zeroinitializer, <8 x i1> %1475
  store <8 x i1> %1477, ptr %1473, align 1
  %1478 = add i32 %1457, 1
  %1479 = select i1 %1448, i32 %1435, i32 %1478
  %1480 = select i1 true, i32 %1479, i32 %1435
  store i32 %1480, ptr %current.token, align 4
  %1481 = load i32, ptr %current.token, align 4
  %1482 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1429)
  %1483 = load i32, ptr %ready.count, align 4
  %1484 = icmp uge i32 %1483, 8
  %1485 = and i1 %1482, %1484
  br i1 %1485, label %ready.overflow.trap180, label %ready.overflow.resume181

ready.overflow.trap180:                           ; preds = %convergence.overflow.resume179
  call void @llvm.trap()
  unreachable

ready.overflow.resume181:                         ; preds = %convergence.overflow.resume179
  %1486 = select i1 %1482, i32 %1483, i32 0
  %1487 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1486
  %1488 = load <8 x i1>, ptr %1487, align 1
  %1489 = select i1 %1482, <8 x i1> %1429, <8 x i1> %1488
  store <8 x i1> %1489, ptr %1487, align 1
  %1490 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1486
  %1491 = load i32, ptr %1490, align 4
  %1492 = select i1 %1482, i32 14, i32 %1491
  store i32 %1492, ptr %1490, align 4
  %1493 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1486
  %1494 = load i32, ptr %1493, align 4
  %1495 = select i1 %1482, i32 %1481, i32 %1494
  store i32 %1495, ptr %1493, align 4
  %1496 = add i32 %1483, 1
  %1497 = select i1 %1482, i32 %1496, i32 %1483
  store i32 %1497, ptr %ready.count, align 4
  %1498 = load <8 x i1>, ptr %runnable.mask, align 1
  %1499 = or <8 x i1> %1498, %1429
  store <8 x i1> %1499, ptr %runnable.mask, align 1
  store <8 x i1> %1431, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true182:                         ; preds = %varying.coherent177
  store <8 x i1> %convergence.cascade.result174, ptr %current.mask, align 1
  %1500 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result174)
  br i1 %1500, label %schedule.14, label %scheduler.loop

varying.coherent.false183:                        ; preds = %varying.coherent177
  store <8 x i1> %convergence.cascade.result174, ptr %current.mask, align 1
  %1501 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result174)
  br i1 %1501, label %schedule.15, label %scheduler.loop

convergence.cascade188:                           ; preds = %convergence.cascade188, %schedule.15
  %convergence.cascade.flow192 = phi <8 x i1> [ %375, %schedule.15 ], [ %1544, %convergence.cascade188 ]
  %convergence.cascade.depth193 = phi i32 [ 0, %schedule.15 ], [ %1545, %convergence.cascade188 ]
  %1502 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow192)
  %1503 = load i32, ptr %current.token, align 4
  %1504 = icmp ne i32 %1503, 0
  %1505 = and i1 %1502, %1504
  %1506 = sub i32 %1503, 1
  %1507 = select i1 %1505, i32 %1506, i32 0
  %1508 = load i8, ptr %frame.active, align 1
  %1509 = trunc i32 %1507 to i8
  %1510 = shl i8 1, %1509
  %1511 = and i8 %1508, %1510
  %1512 = icmp ne i8 %1511, 0
  %1513 = load <8 x i32>, ptr %frame.static.id, align 32
  %1514 = extractelement <8 x i32> %1513, i32 %1507
  %convergence.target.pointer194 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %1514
  %convergence.dynamic.target195 = load i32, ptr %convergence.target.pointer194, align 4
  %1515 = icmp eq i32 %convergence.dynamic.target195, 15
  %1516 = and i1 %1512, %1515
  %1517 = and i1 %1505, %1516
  %1518 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1507
  %1519 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1507
  %1520 = load <8 x i1>, ptr %1518, align 1
  %1521 = load <8 x i1>, ptr %1519, align 1
  %1522 = or <8 x i1> %1521, %convergence.cascade.flow192
  %1523 = load <8 x i1>, ptr %live.mask, align 1
  %1524 = and <8 x i1> %1520, %1523
  %1525 = icmp eq <8 x i1> %1522, %1524
  %1526 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1525)
  %1527 = and i1 %1517, %1526
  %1528 = select i1 %1527, <8 x i1> zeroinitializer, <8 x i1> %1522
  %1529 = select i1 %1517, <8 x i1> %1528, <8 x i1> %1521
  store <8 x i1> %1529, ptr %1519, align 1
  %1530 = select i1 %1527, <8 x i1> zeroinitializer, <8 x i1> %1520
  store <8 x i1> %1530, ptr %1518, align 1
  %1531 = trunc i32 %1507 to i8
  %1532 = shl i8 1, %1531
  %1533 = xor i8 %1532, -1
  %1534 = and i8 %1508, %1533
  %1535 = select i1 %1527, i8 %1534, i8 %1508
  store i8 %1535, ptr %frame.active, align 1
  %.splatinsert196 = insertelement <8 x i1> poison, i1 %1517, i64 0
  %.splat197 = shufflevector <8 x i1> %.splatinsert196, <8 x i1> poison, <8 x i32> zeroinitializer
  %1536 = and <8 x i1> %convergence.cascade.flow192, %.splat197
  %1537 = load <8 x i1>, ptr %runnable.mask, align 1
  %1538 = xor <8 x i1> %1536, splat (i1 true)
  %1539 = and <8 x i1> %1537, %1538
  store <8 x i1> %1539, ptr %runnable.mask, align 1
  %.splatinsert198 = insertelement <8 x i1> poison, i1 %1527, i64 0
  %.splat199 = shufflevector <8 x i1> %.splatinsert198, <8 x i1> poison, <8 x i32> zeroinitializer
  %1540 = select <8 x i1> %.splat199, <8 x i1> %1522, <8 x i1> zeroinitializer
  %1541 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1542 = extractelement <8 x i32> %1541, i32 %1507
  %1543 = select i1 %1527, i32 %1542, i32 %1503
  store i32 %1543, ptr %current.token, align 4
  %.splatinsert200 = insertelement <8 x i1> poison, i1 %1517, i64 0
  %.splat201 = shufflevector <8 x i1> %.splatinsert200, <8 x i1> poison, <8 x i32> zeroinitializer
  %1544 = select <8 x i1> %.splat201, <8 x i1> %1540, <8 x i1> %convergence.cascade.flow192
  %1545 = add i32 %convergence.cascade.depth193, 1
  %1546 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1544)
  %1547 = icmp ult i32 %1545, 8
  %1548 = and i1 %1546, %1547
  %1549 = and i1 %1517, %1548
  %convergence.parent.token202 = load i32, ptr %current.token, align 4
  %convergence.parent.present203 = icmp ne i32 %convergence.parent.token202, 0
  %1550 = and i1 %1549, %convergence.parent.present203
  br i1 %1550, label %convergence.cascade188, label %convergence.cascade.exit189

convergence.cascade.exit189:                      ; preds = %convergence.cascade188, %schedule.15
  %convergence.cascade.result204 = phi <8 x i1> [ %375, %schedule.15 ], [ %1544, %convergence.cascade188 ]
  %1551 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result204)
  br i1 %1551, label %convergence.target.15.ready, label %scheduler.loop

convergence.target.15.ready:                      ; preds = %convergence.cascade.exit189
  %1552 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result204)
  %1553 = bitcast <8 x i1> %convergence.cascade.result204 to i8
  %1554 = call i8 @llvm.cttz.i8(i8 %1553, i1 false)
  %1555 = zext i8 %1554 to i32
  %1556 = select i1 %1552, i32 %1555, i32 0
  store float 0xC6293E5940000000, ptr %.spill20, align 4
  %1557 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %1558 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1559 = extractvalue { <8 x ptr>, <8 x i64> } %1557, 0
  %1560 = select <8 x i1> %convergence.cascade.result204, <8 x ptr> %1558, <8 x ptr> %1559
  %1561 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %1562 = extractvalue { <8 x ptr>, <8 x i64> } %1557, 1
  %1563 = select <8 x i1> %convergence.cascade.result204, <8 x i64> %1561, <8 x i64> %1562
  %1564 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1560, 0
  %1565 = insertvalue { <8 x ptr>, <8 x i64> } %1564, <8 x i64> %1563, 1
  store { <8 x ptr>, <8 x i64> } %1565, ptr %tile_snapshot.spill21, align 64
  %1566 = load <8 x i64>, ptr %.slot22, align 64
  %1567 = select <8 x i1> %convergence.cascade.result204, <8 x i64> zeroinitializer, <8 x i64> %1566
  store <8 x i64> %1567, ptr %.slot22, align 64
  store <8 x i1> %convergence.cascade.result204, ptr %current.mask, align 1
  %1568 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result204)
  br i1 %1568, label %schedule.16, label %scheduler.loop

varying.divergent206:                             ; preds = %schedule.16
  %1569 = load i32, ptr %current.token, align 4
  %1570 = icmp ne i32 %1569, 0
  %1571 = sub i32 %1569, 1
  %1572 = select i1 %1570, i32 %1571, i32 0
  %1573 = load i8, ptr %frame.active, align 1
  %1574 = trunc i32 %1572 to i8
  %1575 = shl i8 1, %1574
  %1576 = and i8 %1573, %1575
  %1577 = icmp ne i8 %1576, 0
  %1578 = load <8 x i32>, ptr %frame.static.id, align 32
  %1579 = extractelement <8 x i32> %1578, i32 %1572
  %1580 = icmp eq i32 %1579, 5
  %1581 = and i1 %1577, %1580
  %1582 = and i1 %1570, %1581
  %1583 = xor i1 %1582, true
  %1584 = and i1 true, %1583
  %1585 = xor i8 %1573, -1
  %1586 = icmp ne i8 %1585, 0
  %1587 = xor i1 %1586, true
  %1588 = and i1 %1584, %1587
  br i1 %1588, label %convergence.overflow.trap208, label %convergence.overflow.resume209

varying.coherent207:                              ; preds = %schedule.16
  br i1 %386, label %varying.coherent.true212, label %varying.coherent.false213

convergence.overflow.trap208:                     ; preds = %varying.divergent206
  call void @llvm.trap()
  unreachable

convergence.overflow.resume209:                   ; preds = %varying.divergent206
  %1589 = call i8 @llvm.cttz.i8(i8 %1585, i1 false)
  %1590 = zext i8 %1589 to i32
  %1591 = select i1 %1586, i32 %1590, i32 0
  %1592 = trunc i32 %1591 to i8
  %1593 = shl i8 1, %1592
  %1594 = or i8 %1573, %1593
  %1595 = select i1 %1584, i8 %1594, i8 %1573
  store i8 %1595, ptr %frame.active, align 1
  %1596 = load <8 x i32>, ptr %frame.static.id, align 32
  %1597 = extractelement <8 x i32> %1596, i32 %1591
  %1598 = select i1 %1584, i32 5, i32 %1597
  %1599 = load <8 x i32>, ptr %frame.static.id, align 32
  %1600 = insertelement <8 x i32> %1599, i32 %1598, i32 %1591
  store <8 x i32> %1600, ptr %frame.static.id, align 32
  %1601 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1602 = extractelement <8 x i32> %1601, i32 %1591
  %1603 = select i1 %1584, i32 %1569, i32 %1602
  %1604 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1605 = insertelement <8 x i32> %1604, i32 %1603, i32 %1591
  store <8 x i32> %1605, ptr %frame.parent.token, align 32
  %1606 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1591
  %1607 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1591
  %1608 = load <8 x i1>, ptr %1606, align 1
  %1609 = load <8 x i1>, ptr %1607, align 1
  %1610 = select i1 %1584, <8 x i1> %376, <8 x i1> %1608
  store <8 x i1> %1610, ptr %1606, align 1
  %1611 = select i1 %1584, <8 x i1> zeroinitializer, <8 x i1> %1609
  store <8 x i1> %1611, ptr %1607, align 1
  %1612 = add i32 %1591, 1
  %1613 = select i1 %1582, i32 %1569, i32 %1612
  %1614 = select i1 true, i32 %1613, i32 %1569
  store i32 %1614, ptr %current.token, align 4
  %1615 = load i32, ptr %current.token, align 4
  %1616 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %383)
  %1617 = load i32, ptr %ready.count, align 4
  %1618 = icmp uge i32 %1617, 8
  %1619 = and i1 %1616, %1618
  br i1 %1619, label %ready.overflow.trap210, label %ready.overflow.resume211

ready.overflow.trap210:                           ; preds = %convergence.overflow.resume209
  call void @llvm.trap()
  unreachable

ready.overflow.resume211:                         ; preds = %convergence.overflow.resume209
  %1620 = select i1 %1616, i32 %1617, i32 0
  %1621 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1620
  %1622 = load <8 x i1>, ptr %1621, align 1
  %1623 = select i1 %1616, <8 x i1> %383, <8 x i1> %1622
  store <8 x i1> %1623, ptr %1621, align 1
  %1624 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1620
  %1625 = load i32, ptr %1624, align 4
  %1626 = select i1 %1616, i32 17, i32 %1625
  store i32 %1626, ptr %1624, align 4
  %1627 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1620
  %1628 = load i32, ptr %1627, align 4
  %1629 = select i1 %1616, i32 %1615, i32 %1628
  store i32 %1629, ptr %1627, align 4
  %1630 = add i32 %1617, 1
  %1631 = select i1 %1616, i32 %1630, i32 %1617
  store i32 %1631, ptr %ready.count, align 4
  %1632 = load <8 x i1>, ptr %runnable.mask, align 1
  %1633 = or <8 x i1> %1632, %383
  store <8 x i1> %1633, ptr %runnable.mask, align 1
  store <8 x i1> %385, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true212:                         ; preds = %varying.coherent207
  store <8 x i1> %376, ptr %current.mask, align 1
  %1634 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %376)
  br i1 %1634, label %schedule.17, label %scheduler.loop

varying.coherent.false213:                        ; preds = %varying.coherent207
  store <8 x i1> %376, ptr %current.mask, align 1
  %1635 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %376)
  br i1 %1635, label %schedule.18, label %scheduler.loop

convergence.cascade224:                           ; preds = %convergence.cascade224, %schedule.18
  %convergence.cascade.flow228 = phi <8 x i1> [ %429, %schedule.18 ], [ %1678, %convergence.cascade224 ]
  %convergence.cascade.depth229 = phi i32 [ 0, %schedule.18 ], [ %1679, %convergence.cascade224 ]
  %1636 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow228)
  %1637 = load i32, ptr %current.token, align 4
  %1638 = icmp ne i32 %1637, 0
  %1639 = and i1 %1636, %1638
  %1640 = sub i32 %1637, 1
  %1641 = select i1 %1639, i32 %1640, i32 0
  %1642 = load i8, ptr %frame.active, align 1
  %1643 = trunc i32 %1641 to i8
  %1644 = shl i8 1, %1643
  %1645 = and i8 %1642, %1644
  %1646 = icmp ne i8 %1645, 0
  %1647 = load <8 x i32>, ptr %frame.static.id, align 32
  %1648 = extractelement <8 x i32> %1647, i32 %1641
  %convergence.target.pointer230 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %1648
  %convergence.dynamic.target231 = load i32, ptr %convergence.target.pointer230, align 4
  %1649 = icmp eq i32 %convergence.dynamic.target231, 18
  %1650 = and i1 %1646, %1649
  %1651 = and i1 %1639, %1650
  %1652 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1641
  %1653 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1641
  %1654 = load <8 x i1>, ptr %1652, align 1
  %1655 = load <8 x i1>, ptr %1653, align 1
  %1656 = or <8 x i1> %1655, %convergence.cascade.flow228
  %1657 = load <8 x i1>, ptr %live.mask, align 1
  %1658 = and <8 x i1> %1654, %1657
  %1659 = icmp eq <8 x i1> %1656, %1658
  %1660 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1659)
  %1661 = and i1 %1651, %1660
  %1662 = select i1 %1661, <8 x i1> zeroinitializer, <8 x i1> %1656
  %1663 = select i1 %1651, <8 x i1> %1662, <8 x i1> %1655
  store <8 x i1> %1663, ptr %1653, align 1
  %1664 = select i1 %1661, <8 x i1> zeroinitializer, <8 x i1> %1654
  store <8 x i1> %1664, ptr %1652, align 1
  %1665 = trunc i32 %1641 to i8
  %1666 = shl i8 1, %1665
  %1667 = xor i8 %1666, -1
  %1668 = and i8 %1642, %1667
  %1669 = select i1 %1661, i8 %1668, i8 %1642
  store i8 %1669, ptr %frame.active, align 1
  %.splatinsert232 = insertelement <8 x i1> poison, i1 %1651, i64 0
  %.splat233 = shufflevector <8 x i1> %.splatinsert232, <8 x i1> poison, <8 x i32> zeroinitializer
  %1670 = and <8 x i1> %convergence.cascade.flow228, %.splat233
  %1671 = load <8 x i1>, ptr %runnable.mask, align 1
  %1672 = xor <8 x i1> %1670, splat (i1 true)
  %1673 = and <8 x i1> %1671, %1672
  store <8 x i1> %1673, ptr %runnable.mask, align 1
  %.splatinsert234 = insertelement <8 x i1> poison, i1 %1661, i64 0
  %.splat235 = shufflevector <8 x i1> %.splatinsert234, <8 x i1> poison, <8 x i32> zeroinitializer
  %1674 = select <8 x i1> %.splat235, <8 x i1> %1656, <8 x i1> zeroinitializer
  %1675 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1676 = extractelement <8 x i32> %1675, i32 %1641
  %1677 = select i1 %1661, i32 %1676, i32 %1637
  store i32 %1677, ptr %current.token, align 4
  %.splatinsert236 = insertelement <8 x i1> poison, i1 %1651, i64 0
  %.splat237 = shufflevector <8 x i1> %.splatinsert236, <8 x i1> poison, <8 x i32> zeroinitializer
  %1678 = select <8 x i1> %.splat237, <8 x i1> %1674, <8 x i1> %convergence.cascade.flow228
  %1679 = add i32 %convergence.cascade.depth229, 1
  %1680 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1678)
  %1681 = icmp ult i32 %1679, 8
  %1682 = and i1 %1680, %1681
  %1683 = and i1 %1651, %1682
  %convergence.parent.token238 = load i32, ptr %current.token, align 4
  %convergence.parent.present239 = icmp ne i32 %convergence.parent.token238, 0
  %1684 = and i1 %1683, %convergence.parent.present239
  br i1 %1684, label %convergence.cascade224, label %convergence.cascade.exit225

convergence.cascade.exit225:                      ; preds = %convergence.cascade224, %schedule.18
  %convergence.cascade.result240 = phi <8 x i1> [ %429, %schedule.18 ], [ %1678, %convergence.cascade224 ]
  %1685 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result240)
  br i1 %1685, label %convergence.target.18.ready, label %scheduler.loop

convergence.target.18.ready:                      ; preds = %convergence.cascade.exit225
  %1686 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result240)
  %1687 = bitcast <8 x i1> %convergence.cascade.result240 to i8
  %1688 = call i8 @llvm.cttz.i8(i8 %1687, i1 false)
  %1689 = zext i8 %1688 to i32
  %1690 = select i1 %1686, i32 %1689, i32 0
  %.spill.load241 = load <8 x i1>, ptr %.spill14, align 1
  %1691 = and <8 x i1> %convergence.cascade.result240, %.spill.load241
  %1692 = xor <8 x i1> %.spill.load241, splat (i1 true)
  %1693 = and <8 x i1> %convergence.cascade.result240, %1692
  %1694 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1691)
  %1695 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1693)
  %1696 = and i1 %1694, %1695
  br i1 %1696, label %varying.divergent242, label %varying.coherent243

varying.divergent242:                             ; preds = %convergence.target.18.ready
  %1697 = load i32, ptr %current.token, align 4
  %1698 = icmp ne i32 %1697, 0
  %1699 = sub i32 %1697, 1
  %1700 = select i1 %1698, i32 %1699, i32 0
  %1701 = load i8, ptr %frame.active, align 1
  %1702 = trunc i32 %1700 to i8
  %1703 = shl i8 1, %1702
  %1704 = and i8 %1701, %1703
  %1705 = icmp ne i8 %1704, 0
  %1706 = load <8 x i32>, ptr %frame.static.id, align 32
  %1707 = extractelement <8 x i32> %1706, i32 %1700
  %1708 = icmp eq i32 %1707, 6
  %1709 = and i1 %1705, %1708
  %1710 = and i1 %1698, %1709
  %1711 = xor i1 %1710, true
  %1712 = and i1 true, %1711
  %1713 = xor i8 %1701, -1
  %1714 = icmp ne i8 %1713, 0
  %1715 = xor i1 %1714, true
  %1716 = and i1 %1712, %1715
  br i1 %1716, label %convergence.overflow.trap244, label %convergence.overflow.resume245

varying.coherent243:                              ; preds = %convergence.target.18.ready
  br i1 %1694, label %varying.coherent.true248, label %varying.coherent.false249

convergence.overflow.trap244:                     ; preds = %varying.divergent242
  call void @llvm.trap()
  unreachable

convergence.overflow.resume245:                   ; preds = %varying.divergent242
  %1717 = call i8 @llvm.cttz.i8(i8 %1713, i1 false)
  %1718 = zext i8 %1717 to i32
  %1719 = select i1 %1714, i32 %1718, i32 0
  %1720 = trunc i32 %1719 to i8
  %1721 = shl i8 1, %1720
  %1722 = or i8 %1701, %1721
  %1723 = select i1 %1712, i8 %1722, i8 %1701
  store i8 %1723, ptr %frame.active, align 1
  %1724 = load <8 x i32>, ptr %frame.static.id, align 32
  %1725 = extractelement <8 x i32> %1724, i32 %1719
  %1726 = select i1 %1712, i32 6, i32 %1725
  %1727 = load <8 x i32>, ptr %frame.static.id, align 32
  %1728 = insertelement <8 x i32> %1727, i32 %1726, i32 %1719
  store <8 x i32> %1728, ptr %frame.static.id, align 32
  %1729 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1730 = extractelement <8 x i32> %1729, i32 %1719
  %1731 = select i1 %1712, i32 %1697, i32 %1730
  %1732 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1733 = insertelement <8 x i32> %1732, i32 %1731, i32 %1719
  store <8 x i32> %1733, ptr %frame.parent.token, align 32
  %1734 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1719
  %1735 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1719
  %1736 = load <8 x i1>, ptr %1734, align 1
  %1737 = load <8 x i1>, ptr %1735, align 1
  %1738 = select i1 %1712, <8 x i1> %convergence.cascade.result240, <8 x i1> %1736
  store <8 x i1> %1738, ptr %1734, align 1
  %1739 = select i1 %1712, <8 x i1> zeroinitializer, <8 x i1> %1737
  store <8 x i1> %1739, ptr %1735, align 1
  %1740 = add i32 %1719, 1
  %1741 = select i1 %1710, i32 %1697, i32 %1740
  %1742 = select i1 true, i32 %1741, i32 %1697
  store i32 %1742, ptr %current.token, align 4
  %1743 = load i32, ptr %current.token, align 4
  %1744 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1691)
  %1745 = load i32, ptr %ready.count, align 4
  %1746 = icmp uge i32 %1745, 8
  %1747 = and i1 %1744, %1746
  br i1 %1747, label %ready.overflow.trap246, label %ready.overflow.resume247

ready.overflow.trap246:                           ; preds = %convergence.overflow.resume245
  call void @llvm.trap()
  unreachable

ready.overflow.resume247:                         ; preds = %convergence.overflow.resume245
  %1748 = select i1 %1744, i32 %1745, i32 0
  %1749 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1748
  %1750 = load <8 x i1>, ptr %1749, align 1
  %1751 = select i1 %1744, <8 x i1> %1691, <8 x i1> %1750
  store <8 x i1> %1751, ptr %1749, align 1
  %1752 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1748
  %1753 = load i32, ptr %1752, align 4
  %1754 = select i1 %1744, i32 19, i32 %1753
  store i32 %1754, ptr %1752, align 4
  %1755 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1748
  %1756 = load i32, ptr %1755, align 4
  %1757 = select i1 %1744, i32 %1743, i32 %1756
  store i32 %1757, ptr %1755, align 4
  %1758 = add i32 %1745, 1
  %1759 = select i1 %1744, i32 %1758, i32 %1745
  store i32 %1759, ptr %ready.count, align 4
  %1760 = load <8 x i1>, ptr %runnable.mask, align 1
  %1761 = or <8 x i1> %1760, %1691
  store <8 x i1> %1761, ptr %runnable.mask, align 1
  store <8 x i1> %1693, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true248:                         ; preds = %varying.coherent243
  store <8 x i1> %convergence.cascade.result240, ptr %current.mask, align 1
  %1762 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result240)
  br i1 %1762, label %schedule.19, label %scheduler.loop

varying.coherent.false249:                        ; preds = %varying.coherent243
  store <8 x i1> %convergence.cascade.result240, ptr %current.mask, align 1
  %1763 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result240)
  br i1 %1763, label %schedule.20, label %scheduler.loop

convergence.cascade260:                           ; preds = %convergence.cascade260, %schedule.20
  %convergence.cascade.flow264 = phi <8 x i1> [ %478, %schedule.20 ], [ %1806, %convergence.cascade260 ]
  %convergence.cascade.depth265 = phi i32 [ 0, %schedule.20 ], [ %1807, %convergence.cascade260 ]
  %1764 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow264)
  %1765 = load i32, ptr %current.token, align 4
  %1766 = icmp ne i32 %1765, 0
  %1767 = and i1 %1764, %1766
  %1768 = sub i32 %1765, 1
  %1769 = select i1 %1767, i32 %1768, i32 0
  %1770 = load i8, ptr %frame.active, align 1
  %1771 = trunc i32 %1769 to i8
  %1772 = shl i8 1, %1771
  %1773 = and i8 %1770, %1772
  %1774 = icmp ne i8 %1773, 0
  %1775 = load <8 x i32>, ptr %frame.static.id, align 32
  %1776 = extractelement <8 x i32> %1775, i32 %1769
  %convergence.target.pointer266 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %1776
  %convergence.dynamic.target267 = load i32, ptr %convergence.target.pointer266, align 4
  %1777 = icmp eq i32 %convergence.dynamic.target267, 20
  %1778 = and i1 %1774, %1777
  %1779 = and i1 %1767, %1778
  %1780 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1769
  %1781 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1769
  %1782 = load <8 x i1>, ptr %1780, align 1
  %1783 = load <8 x i1>, ptr %1781, align 1
  %1784 = or <8 x i1> %1783, %convergence.cascade.flow264
  %1785 = load <8 x i1>, ptr %live.mask, align 1
  %1786 = and <8 x i1> %1782, %1785
  %1787 = icmp eq <8 x i1> %1784, %1786
  %1788 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1787)
  %1789 = and i1 %1779, %1788
  %1790 = select i1 %1789, <8 x i1> zeroinitializer, <8 x i1> %1784
  %1791 = select i1 %1779, <8 x i1> %1790, <8 x i1> %1783
  store <8 x i1> %1791, ptr %1781, align 1
  %1792 = select i1 %1789, <8 x i1> zeroinitializer, <8 x i1> %1782
  store <8 x i1> %1792, ptr %1780, align 1
  %1793 = trunc i32 %1769 to i8
  %1794 = shl i8 1, %1793
  %1795 = xor i8 %1794, -1
  %1796 = and i8 %1770, %1795
  %1797 = select i1 %1789, i8 %1796, i8 %1770
  store i8 %1797, ptr %frame.active, align 1
  %.splatinsert268 = insertelement <8 x i1> poison, i1 %1779, i64 0
  %.splat269 = shufflevector <8 x i1> %.splatinsert268, <8 x i1> poison, <8 x i32> zeroinitializer
  %1798 = and <8 x i1> %convergence.cascade.flow264, %.splat269
  %1799 = load <8 x i1>, ptr %runnable.mask, align 1
  %1800 = xor <8 x i1> %1798, splat (i1 true)
  %1801 = and <8 x i1> %1799, %1800
  store <8 x i1> %1801, ptr %runnable.mask, align 1
  %.splatinsert270 = insertelement <8 x i1> poison, i1 %1789, i64 0
  %.splat271 = shufflevector <8 x i1> %.splatinsert270, <8 x i1> poison, <8 x i32> zeroinitializer
  %1802 = select <8 x i1> %.splat271, <8 x i1> %1784, <8 x i1> zeroinitializer
  %1803 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1804 = extractelement <8 x i32> %1803, i32 %1769
  %1805 = select i1 %1789, i32 %1804, i32 %1765
  store i32 %1805, ptr %current.token, align 4
  %.splatinsert272 = insertelement <8 x i1> poison, i1 %1779, i64 0
  %.splat273 = shufflevector <8 x i1> %.splatinsert272, <8 x i1> poison, <8 x i32> zeroinitializer
  %1806 = select <8 x i1> %.splat273, <8 x i1> %1802, <8 x i1> %convergence.cascade.flow264
  %1807 = add i32 %convergence.cascade.depth265, 1
  %1808 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1806)
  %1809 = icmp ult i32 %1807, 8
  %1810 = and i1 %1808, %1809
  %1811 = and i1 %1779, %1810
  %convergence.parent.token274 = load i32, ptr %current.token, align 4
  %convergence.parent.present275 = icmp ne i32 %convergence.parent.token274, 0
  %1812 = and i1 %1811, %convergence.parent.present275
  br i1 %1812, label %convergence.cascade260, label %convergence.cascade.exit261

convergence.cascade.exit261:                      ; preds = %convergence.cascade260, %schedule.20
  %convergence.cascade.result276 = phi <8 x i1> [ %478, %schedule.20 ], [ %1806, %convergence.cascade260 ]
  %1813 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result276)
  br i1 %1813, label %convergence.target.20.ready, label %scheduler.loop

convergence.target.20.ready:                      ; preds = %convergence.cascade.exit261
  %1814 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result276)
  %1815 = bitcast <8 x i1> %convergence.cascade.result276 to i8
  %1816 = call i8 @llvm.cttz.i8(i8 %1815, i1 false)
  %1817 = zext i8 %1816 to i32
  %1818 = select i1 %1814, i32 %1817, i32 0
  store float 0xFFF0000000000000, ptr %.spill23, align 4
  %tile_snapshot.spill.load277 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %1819 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load277, 0
  %1820 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load277, 1
  %1821 = add <8 x i64> %1820, zeroinitializer
  %1822 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1819, 0
  %1823 = insertvalue { <8 x ptr>, <8 x i64> } %1822, <8 x i64> %1821, 1
  %1824 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1825 = extractvalue { <8 x ptr>, <8 x i64> } %1823, 1
  %1826 = extractelement <8 x ptr> %1824, i32 0
  %1827 = extractelement <8 x i64> %1825, i32 %1818
  %1828 = zext i32 %1818 to i64
  %1829 = mul i64 %1828, 4
  %1830 = sub i64 %1827, %1829
  %1831 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result276)
  %1832 = select i1 %1831, i64 %1830, i64 0
  %private.contiguous.address278 = getelementptr i8, ptr %1826, i64 %1832
  %private.contiguous.load279 = load <8 x float>, ptr %private.contiguous.address278, align 4
  %1833 = select <8 x i1> %convergence.cascade.result276, <8 x float> %private.contiguous.load279, <8 x float> zeroinitializer
  %tile_snapshot.spill.load280 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %1834 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 0
  %1835 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 1
  %1836 = add <8 x i64> %1835, splat (i64 32)
  %1837 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1834, 0
  %1838 = insertvalue { <8 x ptr>, <8 x i64> } %1837, <8 x i64> %1836, 1
  %1839 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1840 = extractvalue { <8 x ptr>, <8 x i64> } %1838, 1
  %1841 = extractelement <8 x ptr> %1839, i32 0
  %1842 = extractelement <8 x i64> %1840, i32 %1818
  %1843 = zext i32 %1818 to i64
  %1844 = mul i64 %1843, 4
  %1845 = sub i64 %1842, %1844
  %1846 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result276)
  %1847 = select i1 %1846, i64 %1845, i64 0
  %private.contiguous.address281 = getelementptr i8, ptr %1841, i64 %1847
  %private.contiguous.load282 = load <8 x float>, ptr %private.contiguous.address281, align 4
  %1848 = select <8 x i1> %convergence.cascade.result276, <8 x float> %private.contiguous.load282, <8 x float> zeroinitializer
  %tile_snapshot.spill.load283 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %1849 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load283, 0
  %1850 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load283, 1
  %1851 = add <8 x i64> %1850, splat (i64 64)
  %1852 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1849, 0
  %1853 = insertvalue { <8 x ptr>, <8 x i64> } %1852, <8 x i64> %1851, 1
  %1854 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1855 = extractvalue { <8 x ptr>, <8 x i64> } %1853, 1
  %1856 = extractelement <8 x ptr> %1854, i32 0
  %1857 = extractelement <8 x i64> %1855, i32 %1818
  %1858 = zext i32 %1818 to i64
  %1859 = mul i64 %1858, 4
  %1860 = sub i64 %1857, %1859
  %1861 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result276)
  %1862 = select i1 %1861, i64 %1860, i64 0
  %private.contiguous.address284 = getelementptr i8, ptr %1856, i64 %1862
  %private.contiguous.load285 = load <8 x float>, ptr %private.contiguous.address284, align 4
  %1863 = select <8 x i1> %convergence.cascade.result276, <8 x float> %private.contiguous.load285, <8 x float> zeroinitializer
  %tile_snapshot.spill.load286 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %1864 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load286, 0
  %1865 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load286, 1
  %1866 = add <8 x i64> %1865, splat (i64 96)
  %1867 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1864, 0
  %1868 = insertvalue { <8 x ptr>, <8 x i64> } %1867, <8 x i64> %1866, 1
  %1869 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1870 = extractvalue { <8 x ptr>, <8 x i64> } %1868, 1
  %1871 = extractelement <8 x ptr> %1869, i32 0
  %1872 = extractelement <8 x i64> %1870, i32 %1818
  %1873 = zext i32 %1818 to i64
  %1874 = mul i64 %1873, 4
  %1875 = sub i64 %1872, %1874
  %1876 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result276)
  %1877 = select i1 %1876, i64 %1875, i64 0
  %private.contiguous.address287 = getelementptr i8, ptr %1871, i64 %1877
  %private.contiguous.load288 = load <8 x float>, ptr %private.contiguous.address287, align 4
  %1878 = select <8 x i1> %convergence.cascade.result276, <8 x float> %private.contiguous.load288, <8 x float> zeroinitializer
  %1879 = load <8 x i64>, ptr %.slot24, align 64
  %1880 = select <8 x i1> %convergence.cascade.result276, <8 x i64> splat (i64 4), <8 x i64> %1879
  store <8 x i64> %1880, ptr %.slot24, align 64
  %1881 = load <8 x float>, ptr %.slot25, align 32
  %1882 = select <8 x i1> %convergence.cascade.result276, <8 x float> %1833, <8 x float> %1881
  store <8 x float> %1882, ptr %.slot25, align 32
  %1883 = load <8 x float>, ptr %.slot26, align 32
  %1884 = select <8 x i1> %convergence.cascade.result276, <8 x float> %1848, <8 x float> %1883
  store <8 x float> %1884, ptr %.slot26, align 32
  %1885 = load <8 x float>, ptr %.slot27, align 32
  %1886 = select <8 x i1> %convergence.cascade.result276, <8 x float> %1863, <8 x float> %1885
  store <8 x float> %1886, ptr %.slot27, align 32
  %1887 = load <8 x float>, ptr %.slot28, align 32
  %1888 = select <8 x i1> %convergence.cascade.result276, <8 x float> %1878, <8 x float> %1887
  store <8 x float> %1888, ptr %.slot28, align 32
  store <8 x i1> %convergence.cascade.result276, ptr %current.mask, align 1
  %1889 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result276)
  br i1 %1889, label %schedule.21, label %scheduler.loop

varying.divergent290:                             ; preds = %schedule.21
  %1890 = load i32, ptr %current.token, align 4
  %1891 = icmp ne i32 %1890, 0
  %1892 = sub i32 %1890, 1
  %1893 = select i1 %1891, i32 %1892, i32 0
  %1894 = load i8, ptr %frame.active, align 1
  %1895 = trunc i32 %1893 to i8
  %1896 = shl i8 1, %1895
  %1897 = and i8 %1894, %1896
  %1898 = icmp ne i8 %1897, 0
  %1899 = load <8 x i32>, ptr %frame.static.id, align 32
  %1900 = extractelement <8 x i32> %1899, i32 %1893
  %1901 = icmp eq i32 %1900, 7
  %1902 = and i1 %1898, %1901
  %1903 = and i1 %1891, %1902
  %1904 = xor i1 %1903, true
  %1905 = and i1 true, %1904
  %1906 = xor i8 %1894, -1
  %1907 = icmp ne i8 %1906, 0
  %1908 = xor i1 %1907, true
  %1909 = and i1 %1905, %1908
  br i1 %1909, label %convergence.overflow.trap292, label %convergence.overflow.resume293

varying.coherent291:                              ; preds = %schedule.21
  br i1 %489, label %varying.coherent.true296, label %varying.coherent.false297

convergence.overflow.trap292:                     ; preds = %varying.divergent290
  call void @llvm.trap()
  unreachable

convergence.overflow.resume293:                   ; preds = %varying.divergent290
  %1910 = call i8 @llvm.cttz.i8(i8 %1906, i1 false)
  %1911 = zext i8 %1910 to i32
  %1912 = select i1 %1907, i32 %1911, i32 0
  %1913 = trunc i32 %1912 to i8
  %1914 = shl i8 1, %1913
  %1915 = or i8 %1894, %1914
  %1916 = select i1 %1905, i8 %1915, i8 %1894
  store i8 %1916, ptr %frame.active, align 1
  %1917 = load <8 x i32>, ptr %frame.static.id, align 32
  %1918 = extractelement <8 x i32> %1917, i32 %1912
  %1919 = select i1 %1905, i32 7, i32 %1918
  %1920 = load <8 x i32>, ptr %frame.static.id, align 32
  %1921 = insertelement <8 x i32> %1920, i32 %1919, i32 %1912
  store <8 x i32> %1921, ptr %frame.static.id, align 32
  %1922 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1923 = extractelement <8 x i32> %1922, i32 %1912
  %1924 = select i1 %1905, i32 %1890, i32 %1923
  %1925 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1926 = insertelement <8 x i32> %1925, i32 %1924, i32 %1912
  store <8 x i32> %1926, ptr %frame.parent.token, align 32
  %1927 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1912
  %1928 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1912
  %1929 = load <8 x i1>, ptr %1927, align 1
  %1930 = load <8 x i1>, ptr %1928, align 1
  %1931 = select i1 %1905, <8 x i1> %479, <8 x i1> %1929
  store <8 x i1> %1931, ptr %1927, align 1
  %1932 = select i1 %1905, <8 x i1> zeroinitializer, <8 x i1> %1930
  store <8 x i1> %1932, ptr %1928, align 1
  %1933 = add i32 %1912, 1
  %1934 = select i1 %1903, i32 %1890, i32 %1933
  %1935 = select i1 true, i32 %1934, i32 %1890
  store i32 %1935, ptr %current.token, align 4
  %1936 = load i32, ptr %current.token, align 4
  %1937 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %486)
  %1938 = load i32, ptr %ready.count, align 4
  %1939 = icmp uge i32 %1938, 8
  %1940 = and i1 %1937, %1939
  br i1 %1940, label %ready.overflow.trap294, label %ready.overflow.resume295

ready.overflow.trap294:                           ; preds = %convergence.overflow.resume293
  call void @llvm.trap()
  unreachable

ready.overflow.resume295:                         ; preds = %convergence.overflow.resume293
  %1941 = select i1 %1937, i32 %1938, i32 0
  %1942 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1941
  %1943 = load <8 x i1>, ptr %1942, align 1
  %1944 = select i1 %1937, <8 x i1> %486, <8 x i1> %1943
  store <8 x i1> %1944, ptr %1942, align 1
  %1945 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1941
  %1946 = load i32, ptr %1945, align 4
  %1947 = select i1 %1937, i32 22, i32 %1946
  store i32 %1947, ptr %1945, align 4
  %1948 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1941
  %1949 = load i32, ptr %1948, align 4
  %1950 = select i1 %1937, i32 %1936, i32 %1949
  store i32 %1950, ptr %1948, align 4
  %1951 = add i32 %1938, 1
  %1952 = select i1 %1937, i32 %1951, i32 %1938
  store i32 %1952, ptr %ready.count, align 4
  %1953 = load <8 x i1>, ptr %runnable.mask, align 1
  %1954 = or <8 x i1> %1953, %486
  store <8 x i1> %1954, ptr %runnable.mask, align 1
  store <8 x i1> %488, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true296:                         ; preds = %varying.coherent291
  store <8 x i1> %479, ptr %current.mask, align 1
  %1955 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %479)
  br i1 %1955, label %schedule.22, label %scheduler.loop

varying.coherent.false297:                        ; preds = %varying.coherent291
  store <8 x i1> %479, ptr %current.mask, align 1
  %1956 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %479)
  br i1 %1956, label %schedule.23, label %scheduler.loop

convergence.cascade311:                           ; preds = %convergence.cascade311, %schedule.23
  %convergence.cascade.flow315 = phi <8 x i1> [ %558, %schedule.23 ], [ %1999, %convergence.cascade311 ]
  %convergence.cascade.depth316 = phi i32 [ 0, %schedule.23 ], [ %2000, %convergence.cascade311 ]
  %1957 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow315)
  %1958 = load i32, ptr %current.token, align 4
  %1959 = icmp ne i32 %1958, 0
  %1960 = and i1 %1957, %1959
  %1961 = sub i32 %1958, 1
  %1962 = select i1 %1960, i32 %1961, i32 0
  %1963 = load i8, ptr %frame.active, align 1
  %1964 = trunc i32 %1962 to i8
  %1965 = shl i8 1, %1964
  %1966 = and i8 %1963, %1965
  %1967 = icmp ne i8 %1966, 0
  %1968 = load <8 x i32>, ptr %frame.static.id, align 32
  %1969 = extractelement <8 x i32> %1968, i32 %1962
  %convergence.target.pointer317 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %1969
  %convergence.dynamic.target318 = load i32, ptr %convergence.target.pointer317, align 4
  %1970 = icmp eq i32 %convergence.dynamic.target318, 23
  %1971 = and i1 %1967, %1970
  %1972 = and i1 %1960, %1971
  %1973 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1962
  %1974 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1962
  %1975 = load <8 x i1>, ptr %1973, align 1
  %1976 = load <8 x i1>, ptr %1974, align 1
  %1977 = or <8 x i1> %1976, %convergence.cascade.flow315
  %1978 = load <8 x i1>, ptr %live.mask, align 1
  %1979 = and <8 x i1> %1975, %1978
  %1980 = icmp eq <8 x i1> %1977, %1979
  %1981 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1980)
  %1982 = and i1 %1972, %1981
  %1983 = select i1 %1982, <8 x i1> zeroinitializer, <8 x i1> %1977
  %1984 = select i1 %1972, <8 x i1> %1983, <8 x i1> %1976
  store <8 x i1> %1984, ptr %1974, align 1
  %1985 = select i1 %1982, <8 x i1> zeroinitializer, <8 x i1> %1975
  store <8 x i1> %1985, ptr %1973, align 1
  %1986 = trunc i32 %1962 to i8
  %1987 = shl i8 1, %1986
  %1988 = xor i8 %1987, -1
  %1989 = and i8 %1963, %1988
  %1990 = select i1 %1982, i8 %1989, i8 %1963
  store i8 %1990, ptr %frame.active, align 1
  %.splatinsert319 = insertelement <8 x i1> poison, i1 %1972, i64 0
  %.splat320 = shufflevector <8 x i1> %.splatinsert319, <8 x i1> poison, <8 x i32> zeroinitializer
  %1991 = and <8 x i1> %convergence.cascade.flow315, %.splat320
  %1992 = load <8 x i1>, ptr %runnable.mask, align 1
  %1993 = xor <8 x i1> %1991, splat (i1 true)
  %1994 = and <8 x i1> %1992, %1993
  store <8 x i1> %1994, ptr %runnable.mask, align 1
  %.splatinsert321 = insertelement <8 x i1> poison, i1 %1982, i64 0
  %.splat322 = shufflevector <8 x i1> %.splatinsert321, <8 x i1> poison, <8 x i32> zeroinitializer
  %1995 = select <8 x i1> %.splat322, <8 x i1> %1977, <8 x i1> zeroinitializer
  %1996 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1997 = extractelement <8 x i32> %1996, i32 %1962
  %1998 = select i1 %1982, i32 %1997, i32 %1958
  store i32 %1998, ptr %current.token, align 4
  %.splatinsert323 = insertelement <8 x i1> poison, i1 %1972, i64 0
  %.splat324 = shufflevector <8 x i1> %.splatinsert323, <8 x i1> poison, <8 x i32> zeroinitializer
  %1999 = select <8 x i1> %.splat324, <8 x i1> %1995, <8 x i1> %convergence.cascade.flow315
  %2000 = add i32 %convergence.cascade.depth316, 1
  %2001 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1999)
  %2002 = icmp ult i32 %2000, 8
  %2003 = and i1 %2001, %2002
  %2004 = and i1 %1972, %2003
  %convergence.parent.token325 = load i32, ptr %current.token, align 4
  %convergence.parent.present326 = icmp ne i32 %convergence.parent.token325, 0
  %2005 = and i1 %2004, %convergence.parent.present326
  br i1 %2005, label %convergence.cascade311, label %convergence.cascade.exit312

convergence.cascade.exit312:                      ; preds = %convergence.cascade311, %schedule.23
  %convergence.cascade.result327 = phi <8 x i1> [ %558, %schedule.23 ], [ %1999, %convergence.cascade311 ]
  %2006 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result327)
  br i1 %2006, label %convergence.target.23.ready, label %scheduler.loop

convergence.target.23.ready:                      ; preds = %convergence.cascade.exit312
  %2007 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result327)
  %2008 = bitcast <8 x i1> %convergence.cascade.result327 to i8
  %2009 = call i8 @llvm.cttz.i8(i8 %2008, i1 false)
  %2010 = zext i8 %2009 to i32
  %2011 = select i1 %2007, i32 %2010, i32 0
  %.spill.load328 = load <8 x i1>, ptr %.spill14, align 1
  %2012 = and <8 x i1> %convergence.cascade.result327, %.spill.load328
  %2013 = xor <8 x i1> %.spill.load328, splat (i1 true)
  %2014 = and <8 x i1> %convergence.cascade.result327, %2013
  %2015 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2012)
  %2016 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2014)
  %2017 = and i1 %2015, %2016
  br i1 %2017, label %varying.divergent329, label %varying.coherent330

varying.divergent329:                             ; preds = %convergence.target.23.ready
  %2018 = load i32, ptr %current.token, align 4
  %2019 = icmp ne i32 %2018, 0
  %2020 = sub i32 %2018, 1
  %2021 = select i1 %2019, i32 %2020, i32 0
  %2022 = load i8, ptr %frame.active, align 1
  %2023 = trunc i32 %2021 to i8
  %2024 = shl i8 1, %2023
  %2025 = and i8 %2022, %2024
  %2026 = icmp ne i8 %2025, 0
  %2027 = load <8 x i32>, ptr %frame.static.id, align 32
  %2028 = extractelement <8 x i32> %2027, i32 %2021
  %2029 = icmp eq i32 %2028, 8
  %2030 = and i1 %2026, %2029
  %2031 = and i1 %2019, %2030
  %2032 = xor i1 %2031, true
  %2033 = and i1 true, %2032
  %2034 = xor i8 %2022, -1
  %2035 = icmp ne i8 %2034, 0
  %2036 = xor i1 %2035, true
  %2037 = and i1 %2033, %2036
  br i1 %2037, label %convergence.overflow.trap331, label %convergence.overflow.resume332

varying.coherent330:                              ; preds = %convergence.target.23.ready
  br i1 %2015, label %varying.coherent.true336, label %varying.coherent.false337

convergence.overflow.trap331:                     ; preds = %varying.divergent329
  call void @llvm.trap()
  unreachable

convergence.overflow.resume332:                   ; preds = %varying.divergent329
  %2038 = call i8 @llvm.cttz.i8(i8 %2034, i1 false)
  %2039 = zext i8 %2038 to i32
  %2040 = select i1 %2035, i32 %2039, i32 0
  %2041 = trunc i32 %2040 to i8
  %2042 = shl i8 1, %2041
  %2043 = or i8 %2022, %2042
  %2044 = select i1 %2033, i8 %2043, i8 %2022
  store i8 %2044, ptr %frame.active, align 1
  %2045 = load <8 x i32>, ptr %frame.static.id, align 32
  %2046 = extractelement <8 x i32> %2045, i32 %2040
  %2047 = select i1 %2033, i32 8, i32 %2046
  %2048 = load <8 x i32>, ptr %frame.static.id, align 32
  %2049 = insertelement <8 x i32> %2048, i32 %2047, i32 %2040
  store <8 x i32> %2049, ptr %frame.static.id, align 32
  %2050 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2051 = extractelement <8 x i32> %2050, i32 %2040
  %2052 = select i1 %2033, i32 %2018, i32 %2051
  %2053 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2054 = insertelement <8 x i32> %2053, i32 %2052, i32 %2040
  store <8 x i32> %2054, ptr %frame.parent.token, align 32
  %2055 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2040
  %2056 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2040
  %2057 = load <8 x i1>, ptr %2055, align 1
  %2058 = load <8 x i1>, ptr %2056, align 1
  %2059 = select i1 %2033, <8 x i1> %convergence.cascade.result327, <8 x i1> %2057
  store <8 x i1> %2059, ptr %2055, align 1
  %2060 = select i1 %2033, <8 x i1> zeroinitializer, <8 x i1> %2058
  store <8 x i1> %2060, ptr %2056, align 1
  %2061 = add i32 %2040, 1
  %2062 = select i1 %2031, i32 %2018, i32 %2061
  %2063 = select i1 true, i32 %2062, i32 %2018
  store i32 %2063, ptr %current.token, align 4
  %.state333 = load <8 x float>, ptr %.slot25, align 32
  %2064 = load <8 x float>, ptr %.slot29, align 32
  %2065 = select <8 x i1> %2014, <8 x float> %.state333, <8 x float> %2064
  store <8 x float> %2065, ptr %.slot29, align 32
  %2066 = load i32, ptr %current.token, align 4
  %2067 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2012)
  %2068 = load i32, ptr %ready.count, align 4
  %2069 = icmp uge i32 %2068, 8
  %2070 = and i1 %2067, %2069
  br i1 %2070, label %ready.overflow.trap334, label %ready.overflow.resume335

ready.overflow.trap334:                           ; preds = %convergence.overflow.resume332
  call void @llvm.trap()
  unreachable

ready.overflow.resume335:                         ; preds = %convergence.overflow.resume332
  %2071 = select i1 %2067, i32 %2068, i32 0
  %2072 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2071
  %2073 = load <8 x i1>, ptr %2072, align 1
  %2074 = select i1 %2067, <8 x i1> %2012, <8 x i1> %2073
  store <8 x i1> %2074, ptr %2072, align 1
  %2075 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2071
  %2076 = load i32, ptr %2075, align 4
  %2077 = select i1 %2067, i32 24, i32 %2076
  store i32 %2077, ptr %2075, align 4
  %2078 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2071
  %2079 = load i32, ptr %2078, align 4
  %2080 = select i1 %2067, i32 %2066, i32 %2079
  store i32 %2080, ptr %2078, align 4
  %2081 = add i32 %2068, 1
  %2082 = select i1 %2067, i32 %2081, i32 %2068
  store i32 %2082, ptr %ready.count, align 4
  %2083 = load <8 x i1>, ptr %runnable.mask, align 1
  %2084 = or <8 x i1> %2083, %2012
  store <8 x i1> %2084, ptr %runnable.mask, align 1
  store <8 x i1> %2014, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true336:                         ; preds = %varying.coherent330
  store <8 x i1> %convergence.cascade.result327, ptr %current.mask, align 1
  %2085 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result327)
  br i1 %2085, label %schedule.24, label %scheduler.loop

varying.coherent.false337:                        ; preds = %varying.coherent330
  %.state338 = load <8 x float>, ptr %.slot25, align 32
  %2086 = load <8 x float>, ptr %.slot29, align 32
  %2087 = select <8 x i1> %convergence.cascade.result327, <8 x float> %.state338, <8 x float> %2086
  store <8 x float> %2087, ptr %.slot29, align 32
  store <8 x i1> %convergence.cascade.result327, ptr %current.mask, align 1
  %2088 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result327)
  br i1 %2088, label %schedule.25, label %scheduler.loop

convergence.cascade343:                           ; preds = %convergence.cascade343, %schedule.25
  %convergence.cascade.flow347 = phi <8 x i1> [ %584, %schedule.25 ], [ %2131, %convergence.cascade343 ]
  %convergence.cascade.depth348 = phi i32 [ 0, %schedule.25 ], [ %2132, %convergence.cascade343 ]
  %2089 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow347)
  %2090 = load i32, ptr %current.token, align 4
  %2091 = icmp ne i32 %2090, 0
  %2092 = and i1 %2089, %2091
  %2093 = sub i32 %2090, 1
  %2094 = select i1 %2092, i32 %2093, i32 0
  %2095 = load i8, ptr %frame.active, align 1
  %2096 = trunc i32 %2094 to i8
  %2097 = shl i8 1, %2096
  %2098 = and i8 %2095, %2097
  %2099 = icmp ne i8 %2098, 0
  %2100 = load <8 x i32>, ptr %frame.static.id, align 32
  %2101 = extractelement <8 x i32> %2100, i32 %2094
  %convergence.target.pointer349 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %2101
  %convergence.dynamic.target350 = load i32, ptr %convergence.target.pointer349, align 4
  %2102 = icmp eq i32 %convergence.dynamic.target350, 25
  %2103 = and i1 %2099, %2102
  %2104 = and i1 %2092, %2103
  %2105 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2094
  %2106 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2094
  %2107 = load <8 x i1>, ptr %2105, align 1
  %2108 = load <8 x i1>, ptr %2106, align 1
  %2109 = or <8 x i1> %2108, %convergence.cascade.flow347
  %2110 = load <8 x i1>, ptr %live.mask, align 1
  %2111 = and <8 x i1> %2107, %2110
  %2112 = icmp eq <8 x i1> %2109, %2111
  %2113 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2112)
  %2114 = and i1 %2104, %2113
  %2115 = select i1 %2114, <8 x i1> zeroinitializer, <8 x i1> %2109
  %2116 = select i1 %2104, <8 x i1> %2115, <8 x i1> %2108
  store <8 x i1> %2116, ptr %2106, align 1
  %2117 = select i1 %2114, <8 x i1> zeroinitializer, <8 x i1> %2107
  store <8 x i1> %2117, ptr %2105, align 1
  %2118 = trunc i32 %2094 to i8
  %2119 = shl i8 1, %2118
  %2120 = xor i8 %2119, -1
  %2121 = and i8 %2095, %2120
  %2122 = select i1 %2114, i8 %2121, i8 %2095
  store i8 %2122, ptr %frame.active, align 1
  %.splatinsert351 = insertelement <8 x i1> poison, i1 %2104, i64 0
  %.splat352 = shufflevector <8 x i1> %.splatinsert351, <8 x i1> poison, <8 x i32> zeroinitializer
  %2123 = and <8 x i1> %convergence.cascade.flow347, %.splat352
  %2124 = load <8 x i1>, ptr %runnable.mask, align 1
  %2125 = xor <8 x i1> %2123, splat (i1 true)
  %2126 = and <8 x i1> %2124, %2125
  store <8 x i1> %2126, ptr %runnable.mask, align 1
  %.splatinsert353 = insertelement <8 x i1> poison, i1 %2114, i64 0
  %.splat354 = shufflevector <8 x i1> %.splatinsert353, <8 x i1> poison, <8 x i32> zeroinitializer
  %2127 = select <8 x i1> %.splat354, <8 x i1> %2109, <8 x i1> zeroinitializer
  %2128 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2129 = extractelement <8 x i32> %2128, i32 %2094
  %2130 = select i1 %2114, i32 %2129, i32 %2090
  store i32 %2130, ptr %current.token, align 4
  %.splatinsert355 = insertelement <8 x i1> poison, i1 %2104, i64 0
  %.splat356 = shufflevector <8 x i1> %.splatinsert355, <8 x i1> poison, <8 x i32> zeroinitializer
  %2131 = select <8 x i1> %.splat356, <8 x i1> %2127, <8 x i1> %convergence.cascade.flow347
  %2132 = add i32 %convergence.cascade.depth348, 1
  %2133 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2131)
  %2134 = icmp ult i32 %2132, 8
  %2135 = and i1 %2133, %2134
  %2136 = and i1 %2104, %2135
  %convergence.parent.token357 = load i32, ptr %current.token, align 4
  %convergence.parent.present358 = icmp ne i32 %convergence.parent.token357, 0
  %2137 = and i1 %2136, %convergence.parent.present358
  br i1 %2137, label %convergence.cascade343, label %convergence.cascade.exit344

convergence.cascade.exit344:                      ; preds = %convergence.cascade343, %schedule.25
  %convergence.cascade.result359 = phi <8 x i1> [ %584, %schedule.25 ], [ %2131, %convergence.cascade343 ]
  %2138 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result359)
  br i1 %2138, label %convergence.target.25.ready, label %scheduler.loop

convergence.target.25.ready:                      ; preds = %convergence.cascade.exit344
  %2139 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result359)
  %2140 = bitcast <8 x i1> %convergence.cascade.result359 to i8
  %2141 = call i8 @llvm.cttz.i8(i8 %2140, i1 false)
  %2142 = zext i8 %2141 to i32
  %2143 = select i1 %2139, i32 %2142, i32 0
  %.state360 = load <8 x float>, ptr %.slot29, align 32
  %.state361 = load <8 x float>, ptr %.slot26, align 32
  %2144 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state360, <8 x float> %.state361)
  %.state362 = load <8 x float>, ptr %.slot27, align 32
  %2145 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %2144, <8 x float> %.state362)
  %.state363 = load <8 x float>, ptr %.slot28, align 32
  %2146 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %2145, <8 x float> %.state363)
  %.spill.load364 = load <8 x i64>, ptr %.spill, align 64
  %2147 = trunc <8 x i64> %.spill.load364 to <8 x i32>
  %2148 = xor <8 x i32> %2147, splat (i32 1)
  %2149 = load <8 x i32>, ptr %.spill30, align 32
  %2150 = select <8 x i1> %convergence.cascade.result359, <8 x i32> %2148, <8 x i32> %2149
  store <8 x i32> %2150, ptr %.spill30, align 32
  %2151 = extractelement <8 x i32> %2148, i64 0
  %2152 = icmp ult i32 %2151, 8
  %2153 = select i1 %2152, i32 %2151, i32 0
  %2154 = extractelement <8 x i1> %convergence.cascade.result359, i32 %2153
  %2155 = extractelement <8 x i1> %convergence.cascade.result359, i64 0
  %2156 = and i1 %2152, %2154
  %2157 = and i1 %2155, %2156
  %2158 = extractelement <8 x float> %2146, i32 %2153
  %2159 = select i1 %2157, float %2158, float 0.000000e+00
  %2160 = insertelement <8 x float> poison, float %2159, i64 0
  %2161 = xor i1 %2157, true
  %2162 = and i1 %2155, %2161
  %2163 = insertelement <8 x i1> poison, i1 %2162, i64 0
  %2164 = extractelement <8 x i32> %2148, i64 1
  %2165 = icmp ult i32 %2164, 8
  %2166 = select i1 %2165, i32 %2164, i32 0
  %2167 = extractelement <8 x i1> %convergence.cascade.result359, i32 %2166
  %2168 = extractelement <8 x i1> %convergence.cascade.result359, i64 1
  %2169 = and i1 %2165, %2167
  %2170 = and i1 %2168, %2169
  %2171 = extractelement <8 x float> %2146, i32 %2166
  %2172 = select i1 %2170, float %2171, float 0.000000e+00
  %2173 = insertelement <8 x float> %2160, float %2172, i64 1
  %2174 = xor i1 %2170, true
  %2175 = and i1 %2168, %2174
  %2176 = insertelement <8 x i1> %2163, i1 %2175, i64 1
  %2177 = extractelement <8 x i32> %2148, i64 2
  %2178 = icmp ult i32 %2177, 8
  %2179 = select i1 %2178, i32 %2177, i32 0
  %2180 = extractelement <8 x i1> %convergence.cascade.result359, i32 %2179
  %2181 = extractelement <8 x i1> %convergence.cascade.result359, i64 2
  %2182 = and i1 %2178, %2180
  %2183 = and i1 %2181, %2182
  %2184 = extractelement <8 x float> %2146, i32 %2179
  %2185 = select i1 %2183, float %2184, float 0.000000e+00
  %2186 = insertelement <8 x float> %2173, float %2185, i64 2
  %2187 = xor i1 %2183, true
  %2188 = and i1 %2181, %2187
  %2189 = insertelement <8 x i1> %2176, i1 %2188, i64 2
  %2190 = extractelement <8 x i32> %2148, i64 3
  %2191 = icmp ult i32 %2190, 8
  %2192 = select i1 %2191, i32 %2190, i32 0
  %2193 = extractelement <8 x i1> %convergence.cascade.result359, i32 %2192
  %2194 = extractelement <8 x i1> %convergence.cascade.result359, i64 3
  %2195 = and i1 %2191, %2193
  %2196 = and i1 %2194, %2195
  %2197 = extractelement <8 x float> %2146, i32 %2192
  %2198 = select i1 %2196, float %2197, float 0.000000e+00
  %2199 = insertelement <8 x float> %2186, float %2198, i64 3
  %2200 = xor i1 %2196, true
  %2201 = and i1 %2194, %2200
  %2202 = insertelement <8 x i1> %2189, i1 %2201, i64 3
  %2203 = extractelement <8 x i32> %2148, i64 4
  %2204 = icmp ult i32 %2203, 8
  %2205 = select i1 %2204, i32 %2203, i32 0
  %2206 = extractelement <8 x i1> %convergence.cascade.result359, i32 %2205
  %2207 = extractelement <8 x i1> %convergence.cascade.result359, i64 4
  %2208 = and i1 %2204, %2206
  %2209 = and i1 %2207, %2208
  %2210 = extractelement <8 x float> %2146, i32 %2205
  %2211 = select i1 %2209, float %2210, float 0.000000e+00
  %2212 = insertelement <8 x float> %2199, float %2211, i64 4
  %2213 = xor i1 %2209, true
  %2214 = and i1 %2207, %2213
  %2215 = insertelement <8 x i1> %2202, i1 %2214, i64 4
  %2216 = extractelement <8 x i32> %2148, i64 5
  %2217 = icmp ult i32 %2216, 8
  %2218 = select i1 %2217, i32 %2216, i32 0
  %2219 = extractelement <8 x i1> %convergence.cascade.result359, i32 %2218
  %2220 = extractelement <8 x i1> %convergence.cascade.result359, i64 5
  %2221 = and i1 %2217, %2219
  %2222 = and i1 %2220, %2221
  %2223 = extractelement <8 x float> %2146, i32 %2218
  %2224 = select i1 %2222, float %2223, float 0.000000e+00
  %2225 = insertelement <8 x float> %2212, float %2224, i64 5
  %2226 = xor i1 %2222, true
  %2227 = and i1 %2220, %2226
  %2228 = insertelement <8 x i1> %2215, i1 %2227, i64 5
  %2229 = extractelement <8 x i32> %2148, i64 6
  %2230 = icmp ult i32 %2229, 8
  %2231 = select i1 %2230, i32 %2229, i32 0
  %2232 = extractelement <8 x i1> %convergence.cascade.result359, i32 %2231
  %2233 = extractelement <8 x i1> %convergence.cascade.result359, i64 6
  %2234 = and i1 %2230, %2232
  %2235 = and i1 %2233, %2234
  %2236 = extractelement <8 x float> %2146, i32 %2231
  %2237 = select i1 %2235, float %2236, float 0.000000e+00
  %2238 = insertelement <8 x float> %2225, float %2237, i64 6
  %2239 = xor i1 %2235, true
  %2240 = and i1 %2233, %2239
  %2241 = insertelement <8 x i1> %2228, i1 %2240, i64 6
  %2242 = extractelement <8 x i32> %2148, i64 7
  %2243 = icmp ult i32 %2242, 8
  %2244 = select i1 %2243, i32 %2242, i32 0
  %2245 = extractelement <8 x i1> %convergence.cascade.result359, i32 %2244
  %2246 = extractelement <8 x i1> %convergence.cascade.result359, i64 7
  %2247 = and i1 %2243, %2245
  %2248 = and i1 %2246, %2247
  %2249 = extractelement <8 x float> %2146, i32 %2244
  %2250 = select i1 %2248, float %2249, float 0.000000e+00
  %2251 = insertelement <8 x float> %2238, float %2250, i64 7
  %2252 = xor i1 %2248, true
  %2253 = and i1 %2246, %2252
  %2254 = insertelement <8 x i1> %2241, i1 %2253, i64 7
  %2255 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %2146, <8 x float> %2251)
  %2256 = xor <8 x i32> %2147, splat (i32 2)
  %2257 = load <8 x i32>, ptr %.spill31, align 32
  %2258 = select <8 x i1> %convergence.cascade.result359, <8 x i32> %2256, <8 x i32> %2257
  store <8 x i32> %2258, ptr %.spill31, align 32
  %2259 = extractelement <8 x i32> %2256, i64 0
  %2260 = icmp ult i32 %2259, 8
  %2261 = select i1 %2260, i32 %2259, i32 0
  %2262 = extractelement <8 x i1> %convergence.cascade.result359, i32 %2261
  %2263 = extractelement <8 x i1> %convergence.cascade.result359, i64 0
  %2264 = and i1 %2260, %2262
  %2265 = and i1 %2263, %2264
  %2266 = extractelement <8 x float> %2255, i32 %2261
  %2267 = select i1 %2265, float %2266, float 0.000000e+00
  %2268 = insertelement <8 x float> poison, float %2267, i64 0
  %2269 = xor i1 %2265, true
  %2270 = and i1 %2263, %2269
  %2271 = insertelement <8 x i1> poison, i1 %2270, i64 0
  %2272 = extractelement <8 x i32> %2256, i64 1
  %2273 = icmp ult i32 %2272, 8
  %2274 = select i1 %2273, i32 %2272, i32 0
  %2275 = extractelement <8 x i1> %convergence.cascade.result359, i32 %2274
  %2276 = extractelement <8 x i1> %convergence.cascade.result359, i64 1
  %2277 = and i1 %2273, %2275
  %2278 = and i1 %2276, %2277
  %2279 = extractelement <8 x float> %2255, i32 %2274
  %2280 = select i1 %2278, float %2279, float 0.000000e+00
  %2281 = insertelement <8 x float> %2268, float %2280, i64 1
  %2282 = xor i1 %2278, true
  %2283 = and i1 %2276, %2282
  %2284 = insertelement <8 x i1> %2271, i1 %2283, i64 1
  %2285 = extractelement <8 x i32> %2256, i64 2
  %2286 = icmp ult i32 %2285, 8
  %2287 = select i1 %2286, i32 %2285, i32 0
  %2288 = extractelement <8 x i1> %convergence.cascade.result359, i32 %2287
  %2289 = extractelement <8 x i1> %convergence.cascade.result359, i64 2
  %2290 = and i1 %2286, %2288
  %2291 = and i1 %2289, %2290
  %2292 = extractelement <8 x float> %2255, i32 %2287
  %2293 = select i1 %2291, float %2292, float 0.000000e+00
  %2294 = insertelement <8 x float> %2281, float %2293, i64 2
  %2295 = xor i1 %2291, true
  %2296 = and i1 %2289, %2295
  %2297 = insertelement <8 x i1> %2284, i1 %2296, i64 2
  %2298 = extractelement <8 x i32> %2256, i64 3
  %2299 = icmp ult i32 %2298, 8
  %2300 = select i1 %2299, i32 %2298, i32 0
  %2301 = extractelement <8 x i1> %convergence.cascade.result359, i32 %2300
  %2302 = extractelement <8 x i1> %convergence.cascade.result359, i64 3
  %2303 = and i1 %2299, %2301
  %2304 = and i1 %2302, %2303
  %2305 = extractelement <8 x float> %2255, i32 %2300
  %2306 = select i1 %2304, float %2305, float 0.000000e+00
  %2307 = insertelement <8 x float> %2294, float %2306, i64 3
  %2308 = xor i1 %2304, true
  %2309 = and i1 %2302, %2308
  %2310 = insertelement <8 x i1> %2297, i1 %2309, i64 3
  %2311 = extractelement <8 x i32> %2256, i64 4
  %2312 = icmp ult i32 %2311, 8
  %2313 = select i1 %2312, i32 %2311, i32 0
  %2314 = extractelement <8 x i1> %convergence.cascade.result359, i32 %2313
  %2315 = extractelement <8 x i1> %convergence.cascade.result359, i64 4
  %2316 = and i1 %2312, %2314
  %2317 = and i1 %2315, %2316
  %2318 = extractelement <8 x float> %2255, i32 %2313
  %2319 = select i1 %2317, float %2318, float 0.000000e+00
  %2320 = insertelement <8 x float> %2307, float %2319, i64 4
  %2321 = xor i1 %2317, true
  %2322 = and i1 %2315, %2321
  %2323 = insertelement <8 x i1> %2310, i1 %2322, i64 4
  %2324 = extractelement <8 x i32> %2256, i64 5
  %2325 = icmp ult i32 %2324, 8
  %2326 = select i1 %2325, i32 %2324, i32 0
  %2327 = extractelement <8 x i1> %convergence.cascade.result359, i32 %2326
  %2328 = extractelement <8 x i1> %convergence.cascade.result359, i64 5
  %2329 = and i1 %2325, %2327
  %2330 = and i1 %2328, %2329
  %2331 = extractelement <8 x float> %2255, i32 %2326
  %2332 = select i1 %2330, float %2331, float 0.000000e+00
  %2333 = insertelement <8 x float> %2320, float %2332, i64 5
  %2334 = xor i1 %2330, true
  %2335 = and i1 %2328, %2334
  %2336 = insertelement <8 x i1> %2323, i1 %2335, i64 5
  %2337 = extractelement <8 x i32> %2256, i64 6
  %2338 = icmp ult i32 %2337, 8
  %2339 = select i1 %2338, i32 %2337, i32 0
  %2340 = extractelement <8 x i1> %convergence.cascade.result359, i32 %2339
  %2341 = extractelement <8 x i1> %convergence.cascade.result359, i64 6
  %2342 = and i1 %2338, %2340
  %2343 = and i1 %2341, %2342
  %2344 = extractelement <8 x float> %2255, i32 %2339
  %2345 = select i1 %2343, float %2344, float 0.000000e+00
  %2346 = insertelement <8 x float> %2333, float %2345, i64 6
  %2347 = xor i1 %2343, true
  %2348 = and i1 %2341, %2347
  %2349 = insertelement <8 x i1> %2336, i1 %2348, i64 6
  %2350 = extractelement <8 x i32> %2256, i64 7
  %2351 = icmp ult i32 %2350, 8
  %2352 = select i1 %2351, i32 %2350, i32 0
  %2353 = extractelement <8 x i1> %convergence.cascade.result359, i32 %2352
  %2354 = extractelement <8 x i1> %convergence.cascade.result359, i64 7
  %2355 = and i1 %2351, %2353
  %2356 = and i1 %2354, %2355
  %2357 = extractelement <8 x float> %2255, i32 %2352
  %2358 = select i1 %2356, float %2357, float 0.000000e+00
  %2359 = insertelement <8 x float> %2346, float %2358, i64 7
  %2360 = xor i1 %2356, true
  %2361 = and i1 %2354, %2360
  %2362 = insertelement <8 x i1> %2349, i1 %2361, i64 7
  %2363 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %2255, <8 x float> %2359)
  %2364 = xor <8 x i32> %2147, splat (i32 4)
  %2365 = load <8 x i32>, ptr %.spill32, align 32
  %2366 = select <8 x i1> %convergence.cascade.result359, <8 x i32> %2364, <8 x i32> %2365
  store <8 x i32> %2366, ptr %.spill32, align 32
  %2367 = extractelement <8 x i32> %2364, i64 0
  %2368 = icmp ult i32 %2367, 8
  %2369 = select i1 %2368, i32 %2367, i32 0
  %2370 = extractelement <8 x i1> %convergence.cascade.result359, i32 %2369
  %2371 = extractelement <8 x i1> %convergence.cascade.result359, i64 0
  %2372 = and i1 %2368, %2370
  %2373 = and i1 %2371, %2372
  %2374 = extractelement <8 x float> %2363, i32 %2369
  %2375 = select i1 %2373, float %2374, float 0.000000e+00
  %2376 = insertelement <8 x float> poison, float %2375, i64 0
  %2377 = xor i1 %2373, true
  %2378 = and i1 %2371, %2377
  %2379 = insertelement <8 x i1> poison, i1 %2378, i64 0
  %2380 = extractelement <8 x i32> %2364, i64 1
  %2381 = icmp ult i32 %2380, 8
  %2382 = select i1 %2381, i32 %2380, i32 0
  %2383 = extractelement <8 x i1> %convergence.cascade.result359, i32 %2382
  %2384 = extractelement <8 x i1> %convergence.cascade.result359, i64 1
  %2385 = and i1 %2381, %2383
  %2386 = and i1 %2384, %2385
  %2387 = extractelement <8 x float> %2363, i32 %2382
  %2388 = select i1 %2386, float %2387, float 0.000000e+00
  %2389 = insertelement <8 x float> %2376, float %2388, i64 1
  %2390 = xor i1 %2386, true
  %2391 = and i1 %2384, %2390
  %2392 = insertelement <8 x i1> %2379, i1 %2391, i64 1
  %2393 = extractelement <8 x i32> %2364, i64 2
  %2394 = icmp ult i32 %2393, 8
  %2395 = select i1 %2394, i32 %2393, i32 0
  %2396 = extractelement <8 x i1> %convergence.cascade.result359, i32 %2395
  %2397 = extractelement <8 x i1> %convergence.cascade.result359, i64 2
  %2398 = and i1 %2394, %2396
  %2399 = and i1 %2397, %2398
  %2400 = extractelement <8 x float> %2363, i32 %2395
  %2401 = select i1 %2399, float %2400, float 0.000000e+00
  %2402 = insertelement <8 x float> %2389, float %2401, i64 2
  %2403 = xor i1 %2399, true
  %2404 = and i1 %2397, %2403
  %2405 = insertelement <8 x i1> %2392, i1 %2404, i64 2
  %2406 = extractelement <8 x i32> %2364, i64 3
  %2407 = icmp ult i32 %2406, 8
  %2408 = select i1 %2407, i32 %2406, i32 0
  %2409 = extractelement <8 x i1> %convergence.cascade.result359, i32 %2408
  %2410 = extractelement <8 x i1> %convergence.cascade.result359, i64 3
  %2411 = and i1 %2407, %2409
  %2412 = and i1 %2410, %2411
  %2413 = extractelement <8 x float> %2363, i32 %2408
  %2414 = select i1 %2412, float %2413, float 0.000000e+00
  %2415 = insertelement <8 x float> %2402, float %2414, i64 3
  %2416 = xor i1 %2412, true
  %2417 = and i1 %2410, %2416
  %2418 = insertelement <8 x i1> %2405, i1 %2417, i64 3
  %2419 = extractelement <8 x i32> %2364, i64 4
  %2420 = icmp ult i32 %2419, 8
  %2421 = select i1 %2420, i32 %2419, i32 0
  %2422 = extractelement <8 x i1> %convergence.cascade.result359, i32 %2421
  %2423 = extractelement <8 x i1> %convergence.cascade.result359, i64 4
  %2424 = and i1 %2420, %2422
  %2425 = and i1 %2423, %2424
  %2426 = extractelement <8 x float> %2363, i32 %2421
  %2427 = select i1 %2425, float %2426, float 0.000000e+00
  %2428 = insertelement <8 x float> %2415, float %2427, i64 4
  %2429 = xor i1 %2425, true
  %2430 = and i1 %2423, %2429
  %2431 = insertelement <8 x i1> %2418, i1 %2430, i64 4
  %2432 = extractelement <8 x i32> %2364, i64 5
  %2433 = icmp ult i32 %2432, 8
  %2434 = select i1 %2433, i32 %2432, i32 0
  %2435 = extractelement <8 x i1> %convergence.cascade.result359, i32 %2434
  %2436 = extractelement <8 x i1> %convergence.cascade.result359, i64 5
  %2437 = and i1 %2433, %2435
  %2438 = and i1 %2436, %2437
  %2439 = extractelement <8 x float> %2363, i32 %2434
  %2440 = select i1 %2438, float %2439, float 0.000000e+00
  %2441 = insertelement <8 x float> %2428, float %2440, i64 5
  %2442 = xor i1 %2438, true
  %2443 = and i1 %2436, %2442
  %2444 = insertelement <8 x i1> %2431, i1 %2443, i64 5
  %2445 = extractelement <8 x i32> %2364, i64 6
  %2446 = icmp ult i32 %2445, 8
  %2447 = select i1 %2446, i32 %2445, i32 0
  %2448 = extractelement <8 x i1> %convergence.cascade.result359, i32 %2447
  %2449 = extractelement <8 x i1> %convergence.cascade.result359, i64 6
  %2450 = and i1 %2446, %2448
  %2451 = and i1 %2449, %2450
  %2452 = extractelement <8 x float> %2363, i32 %2447
  %2453 = select i1 %2451, float %2452, float 0.000000e+00
  %2454 = insertelement <8 x float> %2441, float %2453, i64 6
  %2455 = xor i1 %2451, true
  %2456 = and i1 %2449, %2455
  %2457 = insertelement <8 x i1> %2444, i1 %2456, i64 6
  %2458 = extractelement <8 x i32> %2364, i64 7
  %2459 = icmp ult i32 %2458, 8
  %2460 = select i1 %2459, i32 %2458, i32 0
  %2461 = extractelement <8 x i1> %convergence.cascade.result359, i32 %2460
  %2462 = extractelement <8 x i1> %convergence.cascade.result359, i64 7
  %2463 = and i1 %2459, %2461
  %2464 = and i1 %2462, %2463
  %2465 = extractelement <8 x float> %2363, i32 %2460
  %2466 = select i1 %2464, float %2465, float 0.000000e+00
  %2467 = insertelement <8 x float> %2454, float %2466, i64 7
  %2468 = xor i1 %2464, true
  %2469 = and i1 %2462, %2468
  %2470 = insertelement <8 x i1> %2457, i1 %2469, i64 7
  %2471 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %2363, <8 x float> %2467)
  %2472 = extractelement <8 x i1> %convergence.cascade.result359, i32 0
  %2473 = extractelement <8 x i1> %convergence.cascade.result359, i64 0
  %2474 = and i1 true, %2472
  %2475 = and i1 %2473, %2474
  %2476 = extractelement <8 x float> %2471, i32 0
  %2477 = select i1 %2475, float %2476, float 0.000000e+00
  %2478 = insertelement <8 x float> poison, float %2477, i64 0
  %2479 = xor i1 %2475, true
  %2480 = and i1 %2473, %2479
  %2481 = insertelement <8 x i1> poison, i1 %2480, i64 0
  %2482 = extractelement <8 x i1> %convergence.cascade.result359, i32 0
  %2483 = extractelement <8 x i1> %convergence.cascade.result359, i64 1
  %2484 = and i1 true, %2482
  %2485 = and i1 %2483, %2484
  %2486 = extractelement <8 x float> %2471, i32 0
  %2487 = select i1 %2485, float %2486, float 0.000000e+00
  %2488 = insertelement <8 x float> %2478, float %2487, i64 1
  %2489 = xor i1 %2485, true
  %2490 = and i1 %2483, %2489
  %2491 = insertelement <8 x i1> %2481, i1 %2490, i64 1
  %2492 = extractelement <8 x i1> %convergence.cascade.result359, i32 0
  %2493 = extractelement <8 x i1> %convergence.cascade.result359, i64 2
  %2494 = and i1 true, %2492
  %2495 = and i1 %2493, %2494
  %2496 = extractelement <8 x float> %2471, i32 0
  %2497 = select i1 %2495, float %2496, float 0.000000e+00
  %2498 = insertelement <8 x float> %2488, float %2497, i64 2
  %2499 = xor i1 %2495, true
  %2500 = and i1 %2493, %2499
  %2501 = insertelement <8 x i1> %2491, i1 %2500, i64 2
  %2502 = extractelement <8 x i1> %convergence.cascade.result359, i32 0
  %2503 = extractelement <8 x i1> %convergence.cascade.result359, i64 3
  %2504 = and i1 true, %2502
  %2505 = and i1 %2503, %2504
  %2506 = extractelement <8 x float> %2471, i32 0
  %2507 = select i1 %2505, float %2506, float 0.000000e+00
  %2508 = insertelement <8 x float> %2498, float %2507, i64 3
  %2509 = xor i1 %2505, true
  %2510 = and i1 %2503, %2509
  %2511 = insertelement <8 x i1> %2501, i1 %2510, i64 3
  %2512 = extractelement <8 x i1> %convergence.cascade.result359, i32 0
  %2513 = extractelement <8 x i1> %convergence.cascade.result359, i64 4
  %2514 = and i1 true, %2512
  %2515 = and i1 %2513, %2514
  %2516 = extractelement <8 x float> %2471, i32 0
  %2517 = select i1 %2515, float %2516, float 0.000000e+00
  %2518 = insertelement <8 x float> %2508, float %2517, i64 4
  %2519 = xor i1 %2515, true
  %2520 = and i1 %2513, %2519
  %2521 = insertelement <8 x i1> %2511, i1 %2520, i64 4
  %2522 = extractelement <8 x i1> %convergence.cascade.result359, i32 0
  %2523 = extractelement <8 x i1> %convergence.cascade.result359, i64 5
  %2524 = and i1 true, %2522
  %2525 = and i1 %2523, %2524
  %2526 = extractelement <8 x float> %2471, i32 0
  %2527 = select i1 %2525, float %2526, float 0.000000e+00
  %2528 = insertelement <8 x float> %2518, float %2527, i64 5
  %2529 = xor i1 %2525, true
  %2530 = and i1 %2523, %2529
  %2531 = insertelement <8 x i1> %2521, i1 %2530, i64 5
  %2532 = extractelement <8 x i1> %convergence.cascade.result359, i32 0
  %2533 = extractelement <8 x i1> %convergence.cascade.result359, i64 6
  %2534 = and i1 true, %2532
  %2535 = and i1 %2533, %2534
  %2536 = extractelement <8 x float> %2471, i32 0
  %2537 = select i1 %2535, float %2536, float 0.000000e+00
  %2538 = insertelement <8 x float> %2528, float %2537, i64 6
  %2539 = xor i1 %2535, true
  %2540 = and i1 %2533, %2539
  %2541 = insertelement <8 x i1> %2531, i1 %2540, i64 6
  %2542 = extractelement <8 x i1> %convergence.cascade.result359, i32 0
  %2543 = extractelement <8 x i1> %convergence.cascade.result359, i64 7
  %2544 = and i1 true, %2542
  %2545 = and i1 %2543, %2544
  %2546 = extractelement <8 x float> %2471, i32 0
  %2547 = select i1 %2545, float %2546, float 0.000000e+00
  %2548 = insertelement <8 x float> %2538, float %2547, i64 7
  %2549 = xor i1 %2545, true
  %2550 = and i1 %2543, %2549
  %2551 = insertelement <8 x i1> %2541, i1 %2550, i64 7
  %2552 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result359)
  %2553 = bitcast <8 x i1> %convergence.cascade.result359 to i8
  %2554 = call i8 @llvm.cttz.i8(i8 %2553, i1 false)
  %2555 = zext i8 %2554 to i32
  %2556 = select i1 %2552, i32 %2555, i32 0
  %2557 = extractelement <8 x float> %2548, i32 %2556
  %.spill.load365 = load float, ptr %.spill23, align 4
  %2558 = call float @llvm.maxnum.f32(float %.spill.load365, float %2557)
  %.splatinsert366 = insertelement <8 x float> poison, float %2558, i64 0
  %.splat367 = shufflevector <8 x float> %.splatinsert366, <8 x float> poison, <8 x i32> zeroinitializer
  %2559 = load <8 x float>, ptr %.spill33, align 32
  %2560 = select <8 x i1> %convergence.cascade.result359, <8 x float> %.splat367, <8 x float> %2559
  store <8 x float> %2560, ptr %.spill33, align 32
  store float 0.000000e+00, ptr %.spill34, align 4
  %2561 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %2562 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %2563 = extractvalue { <8 x ptr>, <8 x i64> } %2561, 0
  %2564 = select <8 x i1> %convergence.cascade.result359, <8 x ptr> %2562, <8 x ptr> %2563
  %2565 = extractvalue { <8 x ptr>, <8 x i64> } %9, 1
  %2566 = extractvalue { <8 x ptr>, <8 x i64> } %2561, 1
  %2567 = select <8 x i1> %convergence.cascade.result359, <8 x i64> %2565, <8 x i64> %2566
  %2568 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2564, 0
  %2569 = insertvalue { <8 x ptr>, <8 x i64> } %2568, <8 x i64> %2567, 1
  store { <8 x ptr>, <8 x i64> } %2569, ptr %tile_snapshot.spill35, align 64
  %2570 = load <8 x i64>, ptr %.slot36, align 64
  %2571 = select <8 x i1> %convergence.cascade.result359, <8 x i64> zeroinitializer, <8 x i64> %2570
  store <8 x i64> %2571, ptr %.slot36, align 64
  store <8 x i1> %convergence.cascade.result359, ptr %current.mask, align 1
  %2572 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result359)
  br i1 %2572, label %schedule.26, label %scheduler.loop

varying.divergent369:                             ; preds = %schedule.26
  %2573 = load i32, ptr %current.token, align 4
  %2574 = icmp ne i32 %2573, 0
  %2575 = sub i32 %2573, 1
  %2576 = select i1 %2574, i32 %2575, i32 0
  %2577 = load i8, ptr %frame.active, align 1
  %2578 = trunc i32 %2576 to i8
  %2579 = shl i8 1, %2578
  %2580 = and i8 %2577, %2579
  %2581 = icmp ne i8 %2580, 0
  %2582 = load <8 x i32>, ptr %frame.static.id, align 32
  %2583 = extractelement <8 x i32> %2582, i32 %2576
  %2584 = icmp eq i32 %2583, 9
  %2585 = and i1 %2581, %2584
  %2586 = and i1 %2574, %2585
  %2587 = xor i1 %2586, true
  %2588 = and i1 true, %2587
  %2589 = xor i8 %2577, -1
  %2590 = icmp ne i8 %2589, 0
  %2591 = xor i1 %2590, true
  %2592 = and i1 %2588, %2591
  br i1 %2592, label %convergence.overflow.trap371, label %convergence.overflow.resume372

varying.coherent370:                              ; preds = %schedule.26
  br i1 %595, label %varying.coherent.true375, label %varying.coherent.false376

convergence.overflow.trap371:                     ; preds = %varying.divergent369
  call void @llvm.trap()
  unreachable

convergence.overflow.resume372:                   ; preds = %varying.divergent369
  %2593 = call i8 @llvm.cttz.i8(i8 %2589, i1 false)
  %2594 = zext i8 %2593 to i32
  %2595 = select i1 %2590, i32 %2594, i32 0
  %2596 = trunc i32 %2595 to i8
  %2597 = shl i8 1, %2596
  %2598 = or i8 %2577, %2597
  %2599 = select i1 %2588, i8 %2598, i8 %2577
  store i8 %2599, ptr %frame.active, align 1
  %2600 = load <8 x i32>, ptr %frame.static.id, align 32
  %2601 = extractelement <8 x i32> %2600, i32 %2595
  %2602 = select i1 %2588, i32 9, i32 %2601
  %2603 = load <8 x i32>, ptr %frame.static.id, align 32
  %2604 = insertelement <8 x i32> %2603, i32 %2602, i32 %2595
  store <8 x i32> %2604, ptr %frame.static.id, align 32
  %2605 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2606 = extractelement <8 x i32> %2605, i32 %2595
  %2607 = select i1 %2588, i32 %2573, i32 %2606
  %2608 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2609 = insertelement <8 x i32> %2608, i32 %2607, i32 %2595
  store <8 x i32> %2609, ptr %frame.parent.token, align 32
  %2610 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2595
  %2611 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2595
  %2612 = load <8 x i1>, ptr %2610, align 1
  %2613 = load <8 x i1>, ptr %2611, align 1
  %2614 = select i1 %2588, <8 x i1> %585, <8 x i1> %2612
  store <8 x i1> %2614, ptr %2610, align 1
  %2615 = select i1 %2588, <8 x i1> zeroinitializer, <8 x i1> %2613
  store <8 x i1> %2615, ptr %2611, align 1
  %2616 = add i32 %2595, 1
  %2617 = select i1 %2586, i32 %2573, i32 %2616
  %2618 = select i1 true, i32 %2617, i32 %2573
  store i32 %2618, ptr %current.token, align 4
  %2619 = load i32, ptr %current.token, align 4
  %2620 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %592)
  %2621 = load i32, ptr %ready.count, align 4
  %2622 = icmp uge i32 %2621, 8
  %2623 = and i1 %2620, %2622
  br i1 %2623, label %ready.overflow.trap373, label %ready.overflow.resume374

ready.overflow.trap373:                           ; preds = %convergence.overflow.resume372
  call void @llvm.trap()
  unreachable

ready.overflow.resume374:                         ; preds = %convergence.overflow.resume372
  %2624 = select i1 %2620, i32 %2621, i32 0
  %2625 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2624
  %2626 = load <8 x i1>, ptr %2625, align 1
  %2627 = select i1 %2620, <8 x i1> %592, <8 x i1> %2626
  store <8 x i1> %2627, ptr %2625, align 1
  %2628 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2624
  %2629 = load i32, ptr %2628, align 4
  %2630 = select i1 %2620, i32 27, i32 %2629
  store i32 %2630, ptr %2628, align 4
  %2631 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2624
  %2632 = load i32, ptr %2631, align 4
  %2633 = select i1 %2620, i32 %2619, i32 %2632
  store i32 %2633, ptr %2631, align 4
  %2634 = add i32 %2621, 1
  %2635 = select i1 %2620, i32 %2634, i32 %2621
  store i32 %2635, ptr %ready.count, align 4
  %2636 = load <8 x i1>, ptr %runnable.mask, align 1
  %2637 = or <8 x i1> %2636, %592
  store <8 x i1> %2637, ptr %runnable.mask, align 1
  store <8 x i1> %594, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true375:                         ; preds = %varying.coherent370
  store <8 x i1> %585, ptr %current.mask, align 1
  %2638 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %585)
  br i1 %2638, label %schedule.27, label %scheduler.loop

varying.coherent.false376:                        ; preds = %varying.coherent370
  store <8 x i1> %585, ptr %current.mask, align 1
  %2639 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %585)
  br i1 %2639, label %schedule.28, label %scheduler.loop

convergence.cascade390:                           ; preds = %convergence.cascade390, %schedule.28
  %convergence.cascade.flow394 = phi <8 x i1> [ %646, %schedule.28 ], [ %2682, %convergence.cascade390 ]
  %convergence.cascade.depth395 = phi i32 [ 0, %schedule.28 ], [ %2683, %convergence.cascade390 ]
  %2640 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow394)
  %2641 = load i32, ptr %current.token, align 4
  %2642 = icmp ne i32 %2641, 0
  %2643 = and i1 %2640, %2642
  %2644 = sub i32 %2641, 1
  %2645 = select i1 %2643, i32 %2644, i32 0
  %2646 = load i8, ptr %frame.active, align 1
  %2647 = trunc i32 %2645 to i8
  %2648 = shl i8 1, %2647
  %2649 = and i8 %2646, %2648
  %2650 = icmp ne i8 %2649, 0
  %2651 = load <8 x i32>, ptr %frame.static.id, align 32
  %2652 = extractelement <8 x i32> %2651, i32 %2645
  %convergence.target.pointer396 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %2652
  %convergence.dynamic.target397 = load i32, ptr %convergence.target.pointer396, align 4
  %2653 = icmp eq i32 %convergence.dynamic.target397, 28
  %2654 = and i1 %2650, %2653
  %2655 = and i1 %2643, %2654
  %2656 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2645
  %2657 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2645
  %2658 = load <8 x i1>, ptr %2656, align 1
  %2659 = load <8 x i1>, ptr %2657, align 1
  %2660 = or <8 x i1> %2659, %convergence.cascade.flow394
  %2661 = load <8 x i1>, ptr %live.mask, align 1
  %2662 = and <8 x i1> %2658, %2661
  %2663 = icmp eq <8 x i1> %2660, %2662
  %2664 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2663)
  %2665 = and i1 %2655, %2664
  %2666 = select i1 %2665, <8 x i1> zeroinitializer, <8 x i1> %2660
  %2667 = select i1 %2655, <8 x i1> %2666, <8 x i1> %2659
  store <8 x i1> %2667, ptr %2657, align 1
  %2668 = select i1 %2665, <8 x i1> zeroinitializer, <8 x i1> %2658
  store <8 x i1> %2668, ptr %2656, align 1
  %2669 = trunc i32 %2645 to i8
  %2670 = shl i8 1, %2669
  %2671 = xor i8 %2670, -1
  %2672 = and i8 %2646, %2671
  %2673 = select i1 %2665, i8 %2672, i8 %2646
  store i8 %2673, ptr %frame.active, align 1
  %.splatinsert398 = insertelement <8 x i1> poison, i1 %2655, i64 0
  %.splat399 = shufflevector <8 x i1> %.splatinsert398, <8 x i1> poison, <8 x i32> zeroinitializer
  %2674 = and <8 x i1> %convergence.cascade.flow394, %.splat399
  %2675 = load <8 x i1>, ptr %runnable.mask, align 1
  %2676 = xor <8 x i1> %2674, splat (i1 true)
  %2677 = and <8 x i1> %2675, %2676
  store <8 x i1> %2677, ptr %runnable.mask, align 1
  %.splatinsert400 = insertelement <8 x i1> poison, i1 %2665, i64 0
  %.splat401 = shufflevector <8 x i1> %.splatinsert400, <8 x i1> poison, <8 x i32> zeroinitializer
  %2678 = select <8 x i1> %.splat401, <8 x i1> %2660, <8 x i1> zeroinitializer
  %2679 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2680 = extractelement <8 x i32> %2679, i32 %2645
  %2681 = select i1 %2665, i32 %2680, i32 %2641
  store i32 %2681, ptr %current.token, align 4
  %.splatinsert402 = insertelement <8 x i1> poison, i1 %2655, i64 0
  %.splat403 = shufflevector <8 x i1> %.splatinsert402, <8 x i1> poison, <8 x i32> zeroinitializer
  %2682 = select <8 x i1> %.splat403, <8 x i1> %2678, <8 x i1> %convergence.cascade.flow394
  %2683 = add i32 %convergence.cascade.depth395, 1
  %2684 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2682)
  %2685 = icmp ult i32 %2683, 8
  %2686 = and i1 %2684, %2685
  %2687 = and i1 %2655, %2686
  %convergence.parent.token404 = load i32, ptr %current.token, align 4
  %convergence.parent.present405 = icmp ne i32 %convergence.parent.token404, 0
  %2688 = and i1 %2687, %convergence.parent.present405
  br i1 %2688, label %convergence.cascade390, label %convergence.cascade.exit391

convergence.cascade.exit391:                      ; preds = %convergence.cascade390, %schedule.28
  %convergence.cascade.result406 = phi <8 x i1> [ %646, %schedule.28 ], [ %2682, %convergence.cascade390 ]
  %2689 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  br i1 %2689, label %convergence.target.28.ready, label %scheduler.loop

convergence.target.28.ready:                      ; preds = %convergence.cascade.exit391
  %2690 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  %2691 = bitcast <8 x i1> %convergence.cascade.result406 to i8
  %2692 = call i8 @llvm.cttz.i8(i8 %2691, i1 false)
  %2693 = zext i8 %2692 to i32
  %2694 = select i1 %2690, i32 %2693, i32 0
  %.spill.load407 = load <8 x i1>, ptr %.spill14, align 1
  %2695 = and <8 x i1> %convergence.cascade.result406, %.spill.load407
  %2696 = xor <8 x i1> %.spill.load407, splat (i1 true)
  %2697 = and <8 x i1> %convergence.cascade.result406, %2696
  %2698 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2695)
  %2699 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2697)
  %2700 = and i1 %2698, %2699
  br i1 %2700, label %varying.divergent408, label %varying.coherent409

varying.divergent408:                             ; preds = %convergence.target.28.ready
  %2701 = load i32, ptr %current.token, align 4
  %2702 = icmp ne i32 %2701, 0
  %2703 = sub i32 %2701, 1
  %2704 = select i1 %2702, i32 %2703, i32 0
  %2705 = load i8, ptr %frame.active, align 1
  %2706 = trunc i32 %2704 to i8
  %2707 = shl i8 1, %2706
  %2708 = and i8 %2705, %2707
  %2709 = icmp ne i8 %2708, 0
  %2710 = load <8 x i32>, ptr %frame.static.id, align 32
  %2711 = extractelement <8 x i32> %2710, i32 %2704
  %2712 = icmp eq i32 %2711, 10
  %2713 = and i1 %2709, %2712
  %2714 = and i1 %2702, %2713
  %2715 = xor i1 %2714, true
  %2716 = and i1 true, %2715
  %2717 = xor i8 %2705, -1
  %2718 = icmp ne i8 %2717, 0
  %2719 = xor i1 %2718, true
  %2720 = and i1 %2716, %2719
  br i1 %2720, label %convergence.overflow.trap410, label %convergence.overflow.resume411

varying.coherent409:                              ; preds = %convergence.target.28.ready
  br i1 %2698, label %varying.coherent.true414, label %varying.coherent.false415

convergence.overflow.trap410:                     ; preds = %varying.divergent408
  call void @llvm.trap()
  unreachable

convergence.overflow.resume411:                   ; preds = %varying.divergent408
  %2721 = call i8 @llvm.cttz.i8(i8 %2717, i1 false)
  %2722 = zext i8 %2721 to i32
  %2723 = select i1 %2718, i32 %2722, i32 0
  %2724 = trunc i32 %2723 to i8
  %2725 = shl i8 1, %2724
  %2726 = or i8 %2705, %2725
  %2727 = select i1 %2716, i8 %2726, i8 %2705
  store i8 %2727, ptr %frame.active, align 1
  %2728 = load <8 x i32>, ptr %frame.static.id, align 32
  %2729 = extractelement <8 x i32> %2728, i32 %2723
  %2730 = select i1 %2716, i32 10, i32 %2729
  %2731 = load <8 x i32>, ptr %frame.static.id, align 32
  %2732 = insertelement <8 x i32> %2731, i32 %2730, i32 %2723
  store <8 x i32> %2732, ptr %frame.static.id, align 32
  %2733 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2734 = extractelement <8 x i32> %2733, i32 %2723
  %2735 = select i1 %2716, i32 %2701, i32 %2734
  %2736 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2737 = insertelement <8 x i32> %2736, i32 %2735, i32 %2723
  store <8 x i32> %2737, ptr %frame.parent.token, align 32
  %2738 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2723
  %2739 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2723
  %2740 = load <8 x i1>, ptr %2738, align 1
  %2741 = load <8 x i1>, ptr %2739, align 1
  %2742 = select i1 %2716, <8 x i1> %convergence.cascade.result406, <8 x i1> %2740
  store <8 x i1> %2742, ptr %2738, align 1
  %2743 = select i1 %2716, <8 x i1> zeroinitializer, <8 x i1> %2741
  store <8 x i1> %2743, ptr %2739, align 1
  %2744 = add i32 %2723, 1
  %2745 = select i1 %2714, i32 %2701, i32 %2744
  %2746 = select i1 true, i32 %2745, i32 %2701
  store i32 %2746, ptr %current.token, align 4
  %2747 = load i32, ptr %current.token, align 4
  %2748 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2695)
  %2749 = load i32, ptr %ready.count, align 4
  %2750 = icmp uge i32 %2749, 8
  %2751 = and i1 %2748, %2750
  br i1 %2751, label %ready.overflow.trap412, label %ready.overflow.resume413

ready.overflow.trap412:                           ; preds = %convergence.overflow.resume411
  call void @llvm.trap()
  unreachable

ready.overflow.resume413:                         ; preds = %convergence.overflow.resume411
  %2752 = select i1 %2748, i32 %2749, i32 0
  %2753 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2752
  %2754 = load <8 x i1>, ptr %2753, align 1
  %2755 = select i1 %2748, <8 x i1> %2695, <8 x i1> %2754
  store <8 x i1> %2755, ptr %2753, align 1
  %2756 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2752
  %2757 = load i32, ptr %2756, align 4
  %2758 = select i1 %2748, i32 29, i32 %2757
  store i32 %2758, ptr %2756, align 4
  %2759 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2752
  %2760 = load i32, ptr %2759, align 4
  %2761 = select i1 %2748, i32 %2747, i32 %2760
  store i32 %2761, ptr %2759, align 4
  %2762 = add i32 %2749, 1
  %2763 = select i1 %2748, i32 %2762, i32 %2749
  store i32 %2763, ptr %ready.count, align 4
  %2764 = load <8 x i1>, ptr %runnable.mask, align 1
  %2765 = or <8 x i1> %2764, %2695
  store <8 x i1> %2765, ptr %runnable.mask, align 1
  store <8 x i1> %2697, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true414:                         ; preds = %varying.coherent409
  store <8 x i1> %convergence.cascade.result406, ptr %current.mask, align 1
  %2766 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  br i1 %2766, label %schedule.29, label %scheduler.loop

varying.coherent.false415:                        ; preds = %varying.coherent409
  store <8 x i1> %convergence.cascade.result406, ptr %current.mask, align 1
  %2767 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result406)
  br i1 %2767, label %schedule.30, label %scheduler.loop

convergence.cascade430:                           ; preds = %convergence.cascade430, %schedule.30
  %convergence.cascade.flow434 = phi <8 x i1> [ %703, %schedule.30 ], [ %2810, %convergence.cascade430 ]
  %convergence.cascade.depth435 = phi i32 [ 0, %schedule.30 ], [ %2811, %convergence.cascade430 ]
  %2768 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow434)
  %2769 = load i32, ptr %current.token, align 4
  %2770 = icmp ne i32 %2769, 0
  %2771 = and i1 %2768, %2770
  %2772 = sub i32 %2769, 1
  %2773 = select i1 %2771, i32 %2772, i32 0
  %2774 = load i8, ptr %frame.active, align 1
  %2775 = trunc i32 %2773 to i8
  %2776 = shl i8 1, %2775
  %2777 = and i8 %2774, %2776
  %2778 = icmp ne i8 %2777, 0
  %2779 = load <8 x i32>, ptr %frame.static.id, align 32
  %2780 = extractelement <8 x i32> %2779, i32 %2773
  %convergence.target.pointer436 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %2780
  %convergence.dynamic.target437 = load i32, ptr %convergence.target.pointer436, align 4
  %2781 = icmp eq i32 %convergence.dynamic.target437, 30
  %2782 = and i1 %2778, %2781
  %2783 = and i1 %2771, %2782
  %2784 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2773
  %2785 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2773
  %2786 = load <8 x i1>, ptr %2784, align 1
  %2787 = load <8 x i1>, ptr %2785, align 1
  %2788 = or <8 x i1> %2787, %convergence.cascade.flow434
  %2789 = load <8 x i1>, ptr %live.mask, align 1
  %2790 = and <8 x i1> %2786, %2789
  %2791 = icmp eq <8 x i1> %2788, %2790
  %2792 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2791)
  %2793 = and i1 %2783, %2792
  %2794 = select i1 %2793, <8 x i1> zeroinitializer, <8 x i1> %2788
  %2795 = select i1 %2783, <8 x i1> %2794, <8 x i1> %2787
  store <8 x i1> %2795, ptr %2785, align 1
  %2796 = select i1 %2793, <8 x i1> zeroinitializer, <8 x i1> %2786
  store <8 x i1> %2796, ptr %2784, align 1
  %2797 = trunc i32 %2773 to i8
  %2798 = shl i8 1, %2797
  %2799 = xor i8 %2798, -1
  %2800 = and i8 %2774, %2799
  %2801 = select i1 %2793, i8 %2800, i8 %2774
  store i8 %2801, ptr %frame.active, align 1
  %.splatinsert438 = insertelement <8 x i1> poison, i1 %2783, i64 0
  %.splat439 = shufflevector <8 x i1> %.splatinsert438, <8 x i1> poison, <8 x i32> zeroinitializer
  %2802 = and <8 x i1> %convergence.cascade.flow434, %.splat439
  %2803 = load <8 x i1>, ptr %runnable.mask, align 1
  %2804 = xor <8 x i1> %2802, splat (i1 true)
  %2805 = and <8 x i1> %2803, %2804
  store <8 x i1> %2805, ptr %runnable.mask, align 1
  %.splatinsert440 = insertelement <8 x i1> poison, i1 %2793, i64 0
  %.splat441 = shufflevector <8 x i1> %.splatinsert440, <8 x i1> poison, <8 x i32> zeroinitializer
  %2806 = select <8 x i1> %.splat441, <8 x i1> %2788, <8 x i1> zeroinitializer
  %2807 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2808 = extractelement <8 x i32> %2807, i32 %2773
  %2809 = select i1 %2793, i32 %2808, i32 %2769
  store i32 %2809, ptr %current.token, align 4
  %.splatinsert442 = insertelement <8 x i1> poison, i1 %2783, i64 0
  %.splat443 = shufflevector <8 x i1> %.splatinsert442, <8 x i1> poison, <8 x i32> zeroinitializer
  %2810 = select <8 x i1> %.splat443, <8 x i1> %2806, <8 x i1> %convergence.cascade.flow434
  %2811 = add i32 %convergence.cascade.depth435, 1
  %2812 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2810)
  %2813 = icmp ult i32 %2811, 8
  %2814 = and i1 %2812, %2813
  %2815 = and i1 %2783, %2814
  %convergence.parent.token444 = load i32, ptr %current.token, align 4
  %convergence.parent.present445 = icmp ne i32 %convergence.parent.token444, 0
  %2816 = and i1 %2815, %convergence.parent.present445
  br i1 %2816, label %convergence.cascade430, label %convergence.cascade.exit431

convergence.cascade.exit431:                      ; preds = %convergence.cascade430, %schedule.30
  %convergence.cascade.result446 = phi <8 x i1> [ %703, %schedule.30 ], [ %2810, %convergence.cascade430 ]
  %2817 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result446)
  br i1 %2817, label %convergence.target.30.ready, label %scheduler.loop

convergence.target.30.ready:                      ; preds = %convergence.cascade.exit431
  %2818 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result446)
  %2819 = bitcast <8 x i1> %convergence.cascade.result446 to i8
  %2820 = call i8 @llvm.cttz.i8(i8 %2819, i1 false)
  %2821 = zext i8 %2820 to i32
  %2822 = select i1 %2818, i32 %2821, i32 0
  %tile_snapshot.spill.load447 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %2823 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load447, 0
  %2824 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load447, 1
  %2825 = add <8 x i64> %2824, zeroinitializer
  %2826 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2823, 0
  %2827 = insertvalue { <8 x ptr>, <8 x i64> } %2826, <8 x i64> %2825, 1
  %2828 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %2829 = extractvalue { <8 x ptr>, <8 x i64> } %2827, 1
  %2830 = extractelement <8 x ptr> %2828, i32 0
  %2831 = extractelement <8 x i64> %2829, i32 %2822
  %2832 = zext i32 %2822 to i64
  %2833 = mul i64 %2832, 4
  %2834 = sub i64 %2831, %2833
  %2835 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result446)
  %2836 = select i1 %2835, i64 %2834, i64 0
  %private.contiguous.address448 = getelementptr i8, ptr %2830, i64 %2836
  %private.contiguous.load449 = load <8 x float>, ptr %private.contiguous.address448, align 4
  %2837 = select <8 x i1> %convergence.cascade.result446, <8 x float> %private.contiguous.load449, <8 x float> zeroinitializer
  %tile_snapshot.spill.load450 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %2838 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load450, 0
  %2839 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load450, 1
  %2840 = add <8 x i64> %2839, splat (i64 32)
  %2841 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2838, 0
  %2842 = insertvalue { <8 x ptr>, <8 x i64> } %2841, <8 x i64> %2840, 1
  %2843 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %2844 = extractvalue { <8 x ptr>, <8 x i64> } %2842, 1
  %2845 = extractelement <8 x ptr> %2843, i32 0
  %2846 = extractelement <8 x i64> %2844, i32 %2822
  %2847 = zext i32 %2822 to i64
  %2848 = mul i64 %2847, 4
  %2849 = sub i64 %2846, %2848
  %2850 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result446)
  %2851 = select i1 %2850, i64 %2849, i64 0
  %private.contiguous.address451 = getelementptr i8, ptr %2845, i64 %2851
  %private.contiguous.load452 = load <8 x float>, ptr %private.contiguous.address451, align 4
  %2852 = select <8 x i1> %convergence.cascade.result446, <8 x float> %private.contiguous.load452, <8 x float> zeroinitializer
  %tile_snapshot.spill.load453 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %2853 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load453, 0
  %2854 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load453, 1
  %2855 = add <8 x i64> %2854, splat (i64 64)
  %2856 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2853, 0
  %2857 = insertvalue { <8 x ptr>, <8 x i64> } %2856, <8 x i64> %2855, 1
  %2858 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %2859 = extractvalue { <8 x ptr>, <8 x i64> } %2857, 1
  %2860 = extractelement <8 x ptr> %2858, i32 0
  %2861 = extractelement <8 x i64> %2859, i32 %2822
  %2862 = zext i32 %2822 to i64
  %2863 = mul i64 %2862, 4
  %2864 = sub i64 %2861, %2863
  %2865 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result446)
  %2866 = select i1 %2865, i64 %2864, i64 0
  %private.contiguous.address454 = getelementptr i8, ptr %2860, i64 %2866
  %private.contiguous.load455 = load <8 x float>, ptr %private.contiguous.address454, align 4
  %2867 = select <8 x i1> %convergence.cascade.result446, <8 x float> %private.contiguous.load455, <8 x float> zeroinitializer
  %tile_snapshot.spill.load456 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %2868 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load456, 0
  %2869 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load456, 1
  %2870 = add <8 x i64> %2869, splat (i64 96)
  %2871 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2868, 0
  %2872 = insertvalue { <8 x ptr>, <8 x i64> } %2871, <8 x i64> %2870, 1
  %2873 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %2874 = extractvalue { <8 x ptr>, <8 x i64> } %2872, 1
  %2875 = extractelement <8 x ptr> %2873, i32 0
  %2876 = extractelement <8 x i64> %2874, i32 %2822
  %2877 = zext i32 %2822 to i64
  %2878 = mul i64 %2877, 4
  %2879 = sub i64 %2876, %2878
  %2880 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result446)
  %2881 = select i1 %2880, i64 %2879, i64 0
  %private.contiguous.address457 = getelementptr i8, ptr %2875, i64 %2881
  %private.contiguous.load458 = load <8 x float>, ptr %private.contiguous.address457, align 4
  %2882 = select <8 x i1> %convergence.cascade.result446, <8 x float> %private.contiguous.load458, <8 x float> zeroinitializer
  %2883 = load <8 x i64>, ptr %.slot37, align 64
  %2884 = select <8 x i1> %convergence.cascade.result446, <8 x i64> splat (i64 4), <8 x i64> %2883
  store <8 x i64> %2884, ptr %.slot37, align 64
  %2885 = load <8 x float>, ptr %.slot38, align 32
  %2886 = select <8 x i1> %convergence.cascade.result446, <8 x float> %2837, <8 x float> %2885
  store <8 x float> %2886, ptr %.slot38, align 32
  %2887 = load <8 x float>, ptr %.slot39, align 32
  %2888 = select <8 x i1> %convergence.cascade.result446, <8 x float> %2852, <8 x float> %2887
  store <8 x float> %2888, ptr %.slot39, align 32
  %2889 = load <8 x float>, ptr %.slot40, align 32
  %2890 = select <8 x i1> %convergence.cascade.result446, <8 x float> %2867, <8 x float> %2889
  store <8 x float> %2890, ptr %.slot40, align 32
  %2891 = load <8 x float>, ptr %.slot41, align 32
  %2892 = select <8 x i1> %convergence.cascade.result446, <8 x float> %2882, <8 x float> %2891
  store <8 x float> %2892, ptr %.slot41, align 32
  store <8 x i1> %convergence.cascade.result446, ptr %current.mask, align 1
  %2893 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result446)
  br i1 %2893, label %schedule.31, label %scheduler.loop

varying.divergent460:                             ; preds = %schedule.31
  %2894 = load i32, ptr %current.token, align 4
  %2895 = icmp ne i32 %2894, 0
  %2896 = sub i32 %2894, 1
  %2897 = select i1 %2895, i32 %2896, i32 0
  %2898 = load i8, ptr %frame.active, align 1
  %2899 = trunc i32 %2897 to i8
  %2900 = shl i8 1, %2899
  %2901 = and i8 %2898, %2900
  %2902 = icmp ne i8 %2901, 0
  %2903 = load <8 x i32>, ptr %frame.static.id, align 32
  %2904 = extractelement <8 x i32> %2903, i32 %2897
  %2905 = icmp eq i32 %2904, 11
  %2906 = and i1 %2902, %2905
  %2907 = and i1 %2895, %2906
  %2908 = xor i1 %2907, true
  %2909 = and i1 true, %2908
  %2910 = xor i8 %2898, -1
  %2911 = icmp ne i8 %2910, 0
  %2912 = xor i1 %2911, true
  %2913 = and i1 %2909, %2912
  br i1 %2913, label %convergence.overflow.trap462, label %convergence.overflow.resume463

varying.coherent461:                              ; preds = %schedule.31
  br i1 %714, label %varying.coherent.true466, label %varying.coherent.false467

convergence.overflow.trap462:                     ; preds = %varying.divergent460
  call void @llvm.trap()
  unreachable

convergence.overflow.resume463:                   ; preds = %varying.divergent460
  %2914 = call i8 @llvm.cttz.i8(i8 %2910, i1 false)
  %2915 = zext i8 %2914 to i32
  %2916 = select i1 %2911, i32 %2915, i32 0
  %2917 = trunc i32 %2916 to i8
  %2918 = shl i8 1, %2917
  %2919 = or i8 %2898, %2918
  %2920 = select i1 %2909, i8 %2919, i8 %2898
  store i8 %2920, ptr %frame.active, align 1
  %2921 = load <8 x i32>, ptr %frame.static.id, align 32
  %2922 = extractelement <8 x i32> %2921, i32 %2916
  %2923 = select i1 %2909, i32 11, i32 %2922
  %2924 = load <8 x i32>, ptr %frame.static.id, align 32
  %2925 = insertelement <8 x i32> %2924, i32 %2923, i32 %2916
  store <8 x i32> %2925, ptr %frame.static.id, align 32
  %2926 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2927 = extractelement <8 x i32> %2926, i32 %2916
  %2928 = select i1 %2909, i32 %2894, i32 %2927
  %2929 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2930 = insertelement <8 x i32> %2929, i32 %2928, i32 %2916
  store <8 x i32> %2930, ptr %frame.parent.token, align 32
  %2931 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2916
  %2932 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2916
  %2933 = load <8 x i1>, ptr %2931, align 1
  %2934 = load <8 x i1>, ptr %2932, align 1
  %2935 = select i1 %2909, <8 x i1> %704, <8 x i1> %2933
  store <8 x i1> %2935, ptr %2931, align 1
  %2936 = select i1 %2909, <8 x i1> zeroinitializer, <8 x i1> %2934
  store <8 x i1> %2936, ptr %2932, align 1
  %2937 = add i32 %2916, 1
  %2938 = select i1 %2907, i32 %2894, i32 %2937
  %2939 = select i1 true, i32 %2938, i32 %2894
  store i32 %2939, ptr %current.token, align 4
  %2940 = load i32, ptr %current.token, align 4
  %2941 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %711)
  %2942 = load i32, ptr %ready.count, align 4
  %2943 = icmp uge i32 %2942, 8
  %2944 = and i1 %2941, %2943
  br i1 %2944, label %ready.overflow.trap464, label %ready.overflow.resume465

ready.overflow.trap464:                           ; preds = %convergence.overflow.resume463
  call void @llvm.trap()
  unreachable

ready.overflow.resume465:                         ; preds = %convergence.overflow.resume463
  %2945 = select i1 %2941, i32 %2942, i32 0
  %2946 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2945
  %2947 = load <8 x i1>, ptr %2946, align 1
  %2948 = select i1 %2941, <8 x i1> %711, <8 x i1> %2947
  store <8 x i1> %2948, ptr %2946, align 1
  %2949 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2945
  %2950 = load i32, ptr %2949, align 4
  %2951 = select i1 %2941, i32 32, i32 %2950
  store i32 %2951, ptr %2949, align 4
  %2952 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2945
  %2953 = load i32, ptr %2952, align 4
  %2954 = select i1 %2941, i32 %2940, i32 %2953
  store i32 %2954, ptr %2952, align 4
  %2955 = add i32 %2942, 1
  %2956 = select i1 %2941, i32 %2955, i32 %2942
  store i32 %2956, ptr %ready.count, align 4
  %2957 = load <8 x i1>, ptr %runnable.mask, align 1
  %2958 = or <8 x i1> %2957, %711
  store <8 x i1> %2958, ptr %runnable.mask, align 1
  store <8 x i1> %713, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true466:                         ; preds = %varying.coherent461
  store <8 x i1> %704, ptr %current.mask, align 1
  %2959 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %704)
  br i1 %2959, label %schedule.32, label %scheduler.loop

varying.coherent.false467:                        ; preds = %varying.coherent461
  store <8 x i1> %704, ptr %current.mask, align 1
  %2960 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %704)
  br i1 %2960, label %schedule.33, label %scheduler.loop

convergence.cascade481:                           ; preds = %convergence.cascade481, %schedule.33
  %convergence.cascade.flow485 = phi <8 x i1> [ %783, %schedule.33 ], [ %3003, %convergence.cascade481 ]
  %convergence.cascade.depth486 = phi i32 [ 0, %schedule.33 ], [ %3004, %convergence.cascade481 ]
  %2961 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow485)
  %2962 = load i32, ptr %current.token, align 4
  %2963 = icmp ne i32 %2962, 0
  %2964 = and i1 %2961, %2963
  %2965 = sub i32 %2962, 1
  %2966 = select i1 %2964, i32 %2965, i32 0
  %2967 = load i8, ptr %frame.active, align 1
  %2968 = trunc i32 %2966 to i8
  %2969 = shl i8 1, %2968
  %2970 = and i8 %2967, %2969
  %2971 = icmp ne i8 %2970, 0
  %2972 = load <8 x i32>, ptr %frame.static.id, align 32
  %2973 = extractelement <8 x i32> %2972, i32 %2966
  %convergence.target.pointer487 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %2973
  %convergence.dynamic.target488 = load i32, ptr %convergence.target.pointer487, align 4
  %2974 = icmp eq i32 %convergence.dynamic.target488, 33
  %2975 = and i1 %2971, %2974
  %2976 = and i1 %2964, %2975
  %2977 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2966
  %2978 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2966
  %2979 = load <8 x i1>, ptr %2977, align 1
  %2980 = load <8 x i1>, ptr %2978, align 1
  %2981 = or <8 x i1> %2980, %convergence.cascade.flow485
  %2982 = load <8 x i1>, ptr %live.mask, align 1
  %2983 = and <8 x i1> %2979, %2982
  %2984 = icmp eq <8 x i1> %2981, %2983
  %2985 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2984)
  %2986 = and i1 %2976, %2985
  %2987 = select i1 %2986, <8 x i1> zeroinitializer, <8 x i1> %2981
  %2988 = select i1 %2976, <8 x i1> %2987, <8 x i1> %2980
  store <8 x i1> %2988, ptr %2978, align 1
  %2989 = select i1 %2986, <8 x i1> zeroinitializer, <8 x i1> %2979
  store <8 x i1> %2989, ptr %2977, align 1
  %2990 = trunc i32 %2966 to i8
  %2991 = shl i8 1, %2990
  %2992 = xor i8 %2991, -1
  %2993 = and i8 %2967, %2992
  %2994 = select i1 %2986, i8 %2993, i8 %2967
  store i8 %2994, ptr %frame.active, align 1
  %.splatinsert489 = insertelement <8 x i1> poison, i1 %2976, i64 0
  %.splat490 = shufflevector <8 x i1> %.splatinsert489, <8 x i1> poison, <8 x i32> zeroinitializer
  %2995 = and <8 x i1> %convergence.cascade.flow485, %.splat490
  %2996 = load <8 x i1>, ptr %runnable.mask, align 1
  %2997 = xor <8 x i1> %2995, splat (i1 true)
  %2998 = and <8 x i1> %2996, %2997
  store <8 x i1> %2998, ptr %runnable.mask, align 1
  %.splatinsert491 = insertelement <8 x i1> poison, i1 %2986, i64 0
  %.splat492 = shufflevector <8 x i1> %.splatinsert491, <8 x i1> poison, <8 x i32> zeroinitializer
  %2999 = select <8 x i1> %.splat492, <8 x i1> %2981, <8 x i1> zeroinitializer
  %3000 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3001 = extractelement <8 x i32> %3000, i32 %2966
  %3002 = select i1 %2986, i32 %3001, i32 %2962
  store i32 %3002, ptr %current.token, align 4
  %.splatinsert493 = insertelement <8 x i1> poison, i1 %2976, i64 0
  %.splat494 = shufflevector <8 x i1> %.splatinsert493, <8 x i1> poison, <8 x i32> zeroinitializer
  %3003 = select <8 x i1> %.splat494, <8 x i1> %2999, <8 x i1> %convergence.cascade.flow485
  %3004 = add i32 %convergence.cascade.depth486, 1
  %3005 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3003)
  %3006 = icmp ult i32 %3004, 8
  %3007 = and i1 %3005, %3006
  %3008 = and i1 %2976, %3007
  %convergence.parent.token495 = load i32, ptr %current.token, align 4
  %convergence.parent.present496 = icmp ne i32 %convergence.parent.token495, 0
  %3009 = and i1 %3008, %convergence.parent.present496
  br i1 %3009, label %convergence.cascade481, label %convergence.cascade.exit482

convergence.cascade.exit482:                      ; preds = %convergence.cascade481, %schedule.33
  %convergence.cascade.result497 = phi <8 x i1> [ %783, %schedule.33 ], [ %3003, %convergence.cascade481 ]
  %3010 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result497)
  br i1 %3010, label %convergence.target.33.ready, label %scheduler.loop

convergence.target.33.ready:                      ; preds = %convergence.cascade.exit482
  %3011 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result497)
  %3012 = bitcast <8 x i1> %convergence.cascade.result497 to i8
  %3013 = call i8 @llvm.cttz.i8(i8 %3012, i1 false)
  %3014 = zext i8 %3013 to i32
  %3015 = select i1 %3011, i32 %3014, i32 0
  %.spill.load498 = load <8 x i1>, ptr %.spill14, align 1
  %3016 = and <8 x i1> %convergence.cascade.result497, %.spill.load498
  %3017 = xor <8 x i1> %.spill.load498, splat (i1 true)
  %3018 = and <8 x i1> %convergence.cascade.result497, %3017
  %3019 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3016)
  %3020 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3018)
  %3021 = and i1 %3019, %3020
  br i1 %3021, label %varying.divergent499, label %varying.coherent500

varying.divergent499:                             ; preds = %convergence.target.33.ready
  %3022 = load i32, ptr %current.token, align 4
  %3023 = icmp ne i32 %3022, 0
  %3024 = sub i32 %3022, 1
  %3025 = select i1 %3023, i32 %3024, i32 0
  %3026 = load i8, ptr %frame.active, align 1
  %3027 = trunc i32 %3025 to i8
  %3028 = shl i8 1, %3027
  %3029 = and i8 %3026, %3028
  %3030 = icmp ne i8 %3029, 0
  %3031 = load <8 x i32>, ptr %frame.static.id, align 32
  %3032 = extractelement <8 x i32> %3031, i32 %3025
  %3033 = icmp eq i32 %3032, 12
  %3034 = and i1 %3030, %3033
  %3035 = and i1 %3023, %3034
  %3036 = xor i1 %3035, true
  %3037 = and i1 true, %3036
  %3038 = xor i8 %3026, -1
  %3039 = icmp ne i8 %3038, 0
  %3040 = xor i1 %3039, true
  %3041 = and i1 %3037, %3040
  br i1 %3041, label %convergence.overflow.trap501, label %convergence.overflow.resume502

varying.coherent500:                              ; preds = %convergence.target.33.ready
  br i1 %3019, label %varying.coherent.true506, label %varying.coherent.false507

convergence.overflow.trap501:                     ; preds = %varying.divergent499
  call void @llvm.trap()
  unreachable

convergence.overflow.resume502:                   ; preds = %varying.divergent499
  %3042 = call i8 @llvm.cttz.i8(i8 %3038, i1 false)
  %3043 = zext i8 %3042 to i32
  %3044 = select i1 %3039, i32 %3043, i32 0
  %3045 = trunc i32 %3044 to i8
  %3046 = shl i8 1, %3045
  %3047 = or i8 %3026, %3046
  %3048 = select i1 %3037, i8 %3047, i8 %3026
  store i8 %3048, ptr %frame.active, align 1
  %3049 = load <8 x i32>, ptr %frame.static.id, align 32
  %3050 = extractelement <8 x i32> %3049, i32 %3044
  %3051 = select i1 %3037, i32 12, i32 %3050
  %3052 = load <8 x i32>, ptr %frame.static.id, align 32
  %3053 = insertelement <8 x i32> %3052, i32 %3051, i32 %3044
  store <8 x i32> %3053, ptr %frame.static.id, align 32
  %3054 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3055 = extractelement <8 x i32> %3054, i32 %3044
  %3056 = select i1 %3037, i32 %3022, i32 %3055
  %3057 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3058 = insertelement <8 x i32> %3057, i32 %3056, i32 %3044
  store <8 x i32> %3058, ptr %frame.parent.token, align 32
  %3059 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3044
  %3060 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3044
  %3061 = load <8 x i1>, ptr %3059, align 1
  %3062 = load <8 x i1>, ptr %3060, align 1
  %3063 = select i1 %3037, <8 x i1> %convergence.cascade.result497, <8 x i1> %3061
  store <8 x i1> %3063, ptr %3059, align 1
  %3064 = select i1 %3037, <8 x i1> zeroinitializer, <8 x i1> %3062
  store <8 x i1> %3064, ptr %3060, align 1
  %3065 = add i32 %3044, 1
  %3066 = select i1 %3035, i32 %3022, i32 %3065
  %3067 = select i1 true, i32 %3066, i32 %3022
  store i32 %3067, ptr %current.token, align 4
  %.state503 = load <8 x float>, ptr %.slot38, align 32
  %3068 = load <8 x float>, ptr %.slot42, align 32
  %3069 = select <8 x i1> %3018, <8 x float> %.state503, <8 x float> %3068
  store <8 x float> %3069, ptr %.slot42, align 32
  %3070 = load i32, ptr %current.token, align 4
  %3071 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3016)
  %3072 = load i32, ptr %ready.count, align 4
  %3073 = icmp uge i32 %3072, 8
  %3074 = and i1 %3071, %3073
  br i1 %3074, label %ready.overflow.trap504, label %ready.overflow.resume505

ready.overflow.trap504:                           ; preds = %convergence.overflow.resume502
  call void @llvm.trap()
  unreachable

ready.overflow.resume505:                         ; preds = %convergence.overflow.resume502
  %3075 = select i1 %3071, i32 %3072, i32 0
  %3076 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3075
  %3077 = load <8 x i1>, ptr %3076, align 1
  %3078 = select i1 %3071, <8 x i1> %3016, <8 x i1> %3077
  store <8 x i1> %3078, ptr %3076, align 1
  %3079 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3075
  %3080 = load i32, ptr %3079, align 4
  %3081 = select i1 %3071, i32 34, i32 %3080
  store i32 %3081, ptr %3079, align 4
  %3082 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3075
  %3083 = load i32, ptr %3082, align 4
  %3084 = select i1 %3071, i32 %3070, i32 %3083
  store i32 %3084, ptr %3082, align 4
  %3085 = add i32 %3072, 1
  %3086 = select i1 %3071, i32 %3085, i32 %3072
  store i32 %3086, ptr %ready.count, align 4
  %3087 = load <8 x i1>, ptr %runnable.mask, align 1
  %3088 = or <8 x i1> %3087, %3016
  store <8 x i1> %3088, ptr %runnable.mask, align 1
  store <8 x i1> %3018, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true506:                         ; preds = %varying.coherent500
  store <8 x i1> %convergence.cascade.result497, ptr %current.mask, align 1
  %3089 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result497)
  br i1 %3089, label %schedule.34, label %scheduler.loop

varying.coherent.false507:                        ; preds = %varying.coherent500
  %.state508 = load <8 x float>, ptr %.slot38, align 32
  %3090 = load <8 x float>, ptr %.slot42, align 32
  %3091 = select <8 x i1> %convergence.cascade.result497, <8 x float> %.state508, <8 x float> %3090
  store <8 x float> %3091, ptr %.slot42, align 32
  store <8 x i1> %convergence.cascade.result497, ptr %current.mask, align 1
  %3092 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result497)
  br i1 %3092, label %schedule.35, label %scheduler.loop

convergence.cascade513:                           ; preds = %convergence.cascade513, %schedule.35
  %convergence.cascade.flow517 = phi <8 x i1> [ %809, %schedule.35 ], [ %3135, %convergence.cascade513 ]
  %convergence.cascade.depth518 = phi i32 [ 0, %schedule.35 ], [ %3136, %convergence.cascade513 ]
  %3093 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow517)
  %3094 = load i32, ptr %current.token, align 4
  %3095 = icmp ne i32 %3094, 0
  %3096 = and i1 %3093, %3095
  %3097 = sub i32 %3094, 1
  %3098 = select i1 %3096, i32 %3097, i32 0
  %3099 = load i8, ptr %frame.active, align 1
  %3100 = trunc i32 %3098 to i8
  %3101 = shl i8 1, %3100
  %3102 = and i8 %3099, %3101
  %3103 = icmp ne i8 %3102, 0
  %3104 = load <8 x i32>, ptr %frame.static.id, align 32
  %3105 = extractelement <8 x i32> %3104, i32 %3098
  %convergence.target.pointer519 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %3105
  %convergence.dynamic.target520 = load i32, ptr %convergence.target.pointer519, align 4
  %3106 = icmp eq i32 %convergence.dynamic.target520, 35
  %3107 = and i1 %3103, %3106
  %3108 = and i1 %3096, %3107
  %3109 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3098
  %3110 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3098
  %3111 = load <8 x i1>, ptr %3109, align 1
  %3112 = load <8 x i1>, ptr %3110, align 1
  %3113 = or <8 x i1> %3112, %convergence.cascade.flow517
  %3114 = load <8 x i1>, ptr %live.mask, align 1
  %3115 = and <8 x i1> %3111, %3114
  %3116 = icmp eq <8 x i1> %3113, %3115
  %3117 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3116)
  %3118 = and i1 %3108, %3117
  %3119 = select i1 %3118, <8 x i1> zeroinitializer, <8 x i1> %3113
  %3120 = select i1 %3108, <8 x i1> %3119, <8 x i1> %3112
  store <8 x i1> %3120, ptr %3110, align 1
  %3121 = select i1 %3118, <8 x i1> zeroinitializer, <8 x i1> %3111
  store <8 x i1> %3121, ptr %3109, align 1
  %3122 = trunc i32 %3098 to i8
  %3123 = shl i8 1, %3122
  %3124 = xor i8 %3123, -1
  %3125 = and i8 %3099, %3124
  %3126 = select i1 %3118, i8 %3125, i8 %3099
  store i8 %3126, ptr %frame.active, align 1
  %.splatinsert521 = insertelement <8 x i1> poison, i1 %3108, i64 0
  %.splat522 = shufflevector <8 x i1> %.splatinsert521, <8 x i1> poison, <8 x i32> zeroinitializer
  %3127 = and <8 x i1> %convergence.cascade.flow517, %.splat522
  %3128 = load <8 x i1>, ptr %runnable.mask, align 1
  %3129 = xor <8 x i1> %3127, splat (i1 true)
  %3130 = and <8 x i1> %3128, %3129
  store <8 x i1> %3130, ptr %runnable.mask, align 1
  %.splatinsert523 = insertelement <8 x i1> poison, i1 %3118, i64 0
  %.splat524 = shufflevector <8 x i1> %.splatinsert523, <8 x i1> poison, <8 x i32> zeroinitializer
  %3131 = select <8 x i1> %.splat524, <8 x i1> %3113, <8 x i1> zeroinitializer
  %3132 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3133 = extractelement <8 x i32> %3132, i32 %3098
  %3134 = select i1 %3118, i32 %3133, i32 %3094
  store i32 %3134, ptr %current.token, align 4
  %.splatinsert525 = insertelement <8 x i1> poison, i1 %3108, i64 0
  %.splat526 = shufflevector <8 x i1> %.splatinsert525, <8 x i1> poison, <8 x i32> zeroinitializer
  %3135 = select <8 x i1> %.splat526, <8 x i1> %3131, <8 x i1> %convergence.cascade.flow517
  %3136 = add i32 %convergence.cascade.depth518, 1
  %3137 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3135)
  %3138 = icmp ult i32 %3136, 8
  %3139 = and i1 %3137, %3138
  %3140 = and i1 %3108, %3139
  %convergence.parent.token527 = load i32, ptr %current.token, align 4
  %convergence.parent.present528 = icmp ne i32 %convergence.parent.token527, 0
  %3141 = and i1 %3140, %convergence.parent.present528
  br i1 %3141, label %convergence.cascade513, label %convergence.cascade.exit514

convergence.cascade.exit514:                      ; preds = %convergence.cascade513, %schedule.35
  %convergence.cascade.result529 = phi <8 x i1> [ %809, %schedule.35 ], [ %3135, %convergence.cascade513 ]
  %3142 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result529)
  br i1 %3142, label %convergence.target.35.ready, label %scheduler.loop

convergence.target.35.ready:                      ; preds = %convergence.cascade.exit514
  %3143 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result529)
  %3144 = bitcast <8 x i1> %convergence.cascade.result529 to i8
  %3145 = call i8 @llvm.cttz.i8(i8 %3144, i1 false)
  %3146 = zext i8 %3145 to i32
  %3147 = select i1 %3143, i32 %3146, i32 0
  %.state530 = load <8 x float>, ptr %.slot42, align 32
  %.state531 = load <8 x float>, ptr %.slot39, align 32
  %3148 = fadd <8 x float> %.state530, %.state531
  %.state532 = load <8 x float>, ptr %.slot40, align 32
  %3149 = fadd <8 x float> %3148, %.state532
  %.state533 = load <8 x float>, ptr %.slot41, align 32
  %3150 = fadd <8 x float> %3149, %.state533
  %.spill.load534 = load <8 x i32>, ptr %.spill30, align 32
  %3151 = extractelement <8 x i32> %.spill.load534, i64 0
  %3152 = icmp ult i32 %3151, 8
  %3153 = select i1 %3152, i32 %3151, i32 0
  %3154 = extractelement <8 x i1> %convergence.cascade.result529, i32 %3153
  %3155 = extractelement <8 x i1> %convergence.cascade.result529, i64 0
  %3156 = and i1 %3152, %3154
  %3157 = and i1 %3155, %3156
  %3158 = extractelement <8 x float> %3150, i32 %3153
  %3159 = select i1 %3157, float %3158, float 0.000000e+00
  %3160 = insertelement <8 x float> poison, float %3159, i64 0
  %3161 = xor i1 %3157, true
  %3162 = and i1 %3155, %3161
  %3163 = insertelement <8 x i1> poison, i1 %3162, i64 0
  %3164 = extractelement <8 x i32> %.spill.load534, i64 1
  %3165 = icmp ult i32 %3164, 8
  %3166 = select i1 %3165, i32 %3164, i32 0
  %3167 = extractelement <8 x i1> %convergence.cascade.result529, i32 %3166
  %3168 = extractelement <8 x i1> %convergence.cascade.result529, i64 1
  %3169 = and i1 %3165, %3167
  %3170 = and i1 %3168, %3169
  %3171 = extractelement <8 x float> %3150, i32 %3166
  %3172 = select i1 %3170, float %3171, float 0.000000e+00
  %3173 = insertelement <8 x float> %3160, float %3172, i64 1
  %3174 = xor i1 %3170, true
  %3175 = and i1 %3168, %3174
  %3176 = insertelement <8 x i1> %3163, i1 %3175, i64 1
  %3177 = extractelement <8 x i32> %.spill.load534, i64 2
  %3178 = icmp ult i32 %3177, 8
  %3179 = select i1 %3178, i32 %3177, i32 0
  %3180 = extractelement <8 x i1> %convergence.cascade.result529, i32 %3179
  %3181 = extractelement <8 x i1> %convergence.cascade.result529, i64 2
  %3182 = and i1 %3178, %3180
  %3183 = and i1 %3181, %3182
  %3184 = extractelement <8 x float> %3150, i32 %3179
  %3185 = select i1 %3183, float %3184, float 0.000000e+00
  %3186 = insertelement <8 x float> %3173, float %3185, i64 2
  %3187 = xor i1 %3183, true
  %3188 = and i1 %3181, %3187
  %3189 = insertelement <8 x i1> %3176, i1 %3188, i64 2
  %3190 = extractelement <8 x i32> %.spill.load534, i64 3
  %3191 = icmp ult i32 %3190, 8
  %3192 = select i1 %3191, i32 %3190, i32 0
  %3193 = extractelement <8 x i1> %convergence.cascade.result529, i32 %3192
  %3194 = extractelement <8 x i1> %convergence.cascade.result529, i64 3
  %3195 = and i1 %3191, %3193
  %3196 = and i1 %3194, %3195
  %3197 = extractelement <8 x float> %3150, i32 %3192
  %3198 = select i1 %3196, float %3197, float 0.000000e+00
  %3199 = insertelement <8 x float> %3186, float %3198, i64 3
  %3200 = xor i1 %3196, true
  %3201 = and i1 %3194, %3200
  %3202 = insertelement <8 x i1> %3189, i1 %3201, i64 3
  %3203 = extractelement <8 x i32> %.spill.load534, i64 4
  %3204 = icmp ult i32 %3203, 8
  %3205 = select i1 %3204, i32 %3203, i32 0
  %3206 = extractelement <8 x i1> %convergence.cascade.result529, i32 %3205
  %3207 = extractelement <8 x i1> %convergence.cascade.result529, i64 4
  %3208 = and i1 %3204, %3206
  %3209 = and i1 %3207, %3208
  %3210 = extractelement <8 x float> %3150, i32 %3205
  %3211 = select i1 %3209, float %3210, float 0.000000e+00
  %3212 = insertelement <8 x float> %3199, float %3211, i64 4
  %3213 = xor i1 %3209, true
  %3214 = and i1 %3207, %3213
  %3215 = insertelement <8 x i1> %3202, i1 %3214, i64 4
  %3216 = extractelement <8 x i32> %.spill.load534, i64 5
  %3217 = icmp ult i32 %3216, 8
  %3218 = select i1 %3217, i32 %3216, i32 0
  %3219 = extractelement <8 x i1> %convergence.cascade.result529, i32 %3218
  %3220 = extractelement <8 x i1> %convergence.cascade.result529, i64 5
  %3221 = and i1 %3217, %3219
  %3222 = and i1 %3220, %3221
  %3223 = extractelement <8 x float> %3150, i32 %3218
  %3224 = select i1 %3222, float %3223, float 0.000000e+00
  %3225 = insertelement <8 x float> %3212, float %3224, i64 5
  %3226 = xor i1 %3222, true
  %3227 = and i1 %3220, %3226
  %3228 = insertelement <8 x i1> %3215, i1 %3227, i64 5
  %3229 = extractelement <8 x i32> %.spill.load534, i64 6
  %3230 = icmp ult i32 %3229, 8
  %3231 = select i1 %3230, i32 %3229, i32 0
  %3232 = extractelement <8 x i1> %convergence.cascade.result529, i32 %3231
  %3233 = extractelement <8 x i1> %convergence.cascade.result529, i64 6
  %3234 = and i1 %3230, %3232
  %3235 = and i1 %3233, %3234
  %3236 = extractelement <8 x float> %3150, i32 %3231
  %3237 = select i1 %3235, float %3236, float 0.000000e+00
  %3238 = insertelement <8 x float> %3225, float %3237, i64 6
  %3239 = xor i1 %3235, true
  %3240 = and i1 %3233, %3239
  %3241 = insertelement <8 x i1> %3228, i1 %3240, i64 6
  %3242 = extractelement <8 x i32> %.spill.load534, i64 7
  %3243 = icmp ult i32 %3242, 8
  %3244 = select i1 %3243, i32 %3242, i32 0
  %3245 = extractelement <8 x i1> %convergence.cascade.result529, i32 %3244
  %3246 = extractelement <8 x i1> %convergence.cascade.result529, i64 7
  %3247 = and i1 %3243, %3245
  %3248 = and i1 %3246, %3247
  %3249 = extractelement <8 x float> %3150, i32 %3244
  %3250 = select i1 %3248, float %3249, float 0.000000e+00
  %3251 = insertelement <8 x float> %3238, float %3250, i64 7
  %3252 = xor i1 %3248, true
  %3253 = and i1 %3246, %3252
  %3254 = insertelement <8 x i1> %3241, i1 %3253, i64 7
  %3255 = fadd <8 x float> %3150, %3251
  %.spill.load535 = load <8 x i32>, ptr %.spill31, align 32
  %3256 = extractelement <8 x i32> %.spill.load535, i64 0
  %3257 = icmp ult i32 %3256, 8
  %3258 = select i1 %3257, i32 %3256, i32 0
  %3259 = extractelement <8 x i1> %convergence.cascade.result529, i32 %3258
  %3260 = extractelement <8 x i1> %convergence.cascade.result529, i64 0
  %3261 = and i1 %3257, %3259
  %3262 = and i1 %3260, %3261
  %3263 = extractelement <8 x float> %3255, i32 %3258
  %3264 = select i1 %3262, float %3263, float 0.000000e+00
  %3265 = insertelement <8 x float> poison, float %3264, i64 0
  %3266 = xor i1 %3262, true
  %3267 = and i1 %3260, %3266
  %3268 = insertelement <8 x i1> poison, i1 %3267, i64 0
  %3269 = extractelement <8 x i32> %.spill.load535, i64 1
  %3270 = icmp ult i32 %3269, 8
  %3271 = select i1 %3270, i32 %3269, i32 0
  %3272 = extractelement <8 x i1> %convergence.cascade.result529, i32 %3271
  %3273 = extractelement <8 x i1> %convergence.cascade.result529, i64 1
  %3274 = and i1 %3270, %3272
  %3275 = and i1 %3273, %3274
  %3276 = extractelement <8 x float> %3255, i32 %3271
  %3277 = select i1 %3275, float %3276, float 0.000000e+00
  %3278 = insertelement <8 x float> %3265, float %3277, i64 1
  %3279 = xor i1 %3275, true
  %3280 = and i1 %3273, %3279
  %3281 = insertelement <8 x i1> %3268, i1 %3280, i64 1
  %3282 = extractelement <8 x i32> %.spill.load535, i64 2
  %3283 = icmp ult i32 %3282, 8
  %3284 = select i1 %3283, i32 %3282, i32 0
  %3285 = extractelement <8 x i1> %convergence.cascade.result529, i32 %3284
  %3286 = extractelement <8 x i1> %convergence.cascade.result529, i64 2
  %3287 = and i1 %3283, %3285
  %3288 = and i1 %3286, %3287
  %3289 = extractelement <8 x float> %3255, i32 %3284
  %3290 = select i1 %3288, float %3289, float 0.000000e+00
  %3291 = insertelement <8 x float> %3278, float %3290, i64 2
  %3292 = xor i1 %3288, true
  %3293 = and i1 %3286, %3292
  %3294 = insertelement <8 x i1> %3281, i1 %3293, i64 2
  %3295 = extractelement <8 x i32> %.spill.load535, i64 3
  %3296 = icmp ult i32 %3295, 8
  %3297 = select i1 %3296, i32 %3295, i32 0
  %3298 = extractelement <8 x i1> %convergence.cascade.result529, i32 %3297
  %3299 = extractelement <8 x i1> %convergence.cascade.result529, i64 3
  %3300 = and i1 %3296, %3298
  %3301 = and i1 %3299, %3300
  %3302 = extractelement <8 x float> %3255, i32 %3297
  %3303 = select i1 %3301, float %3302, float 0.000000e+00
  %3304 = insertelement <8 x float> %3291, float %3303, i64 3
  %3305 = xor i1 %3301, true
  %3306 = and i1 %3299, %3305
  %3307 = insertelement <8 x i1> %3294, i1 %3306, i64 3
  %3308 = extractelement <8 x i32> %.spill.load535, i64 4
  %3309 = icmp ult i32 %3308, 8
  %3310 = select i1 %3309, i32 %3308, i32 0
  %3311 = extractelement <8 x i1> %convergence.cascade.result529, i32 %3310
  %3312 = extractelement <8 x i1> %convergence.cascade.result529, i64 4
  %3313 = and i1 %3309, %3311
  %3314 = and i1 %3312, %3313
  %3315 = extractelement <8 x float> %3255, i32 %3310
  %3316 = select i1 %3314, float %3315, float 0.000000e+00
  %3317 = insertelement <8 x float> %3304, float %3316, i64 4
  %3318 = xor i1 %3314, true
  %3319 = and i1 %3312, %3318
  %3320 = insertelement <8 x i1> %3307, i1 %3319, i64 4
  %3321 = extractelement <8 x i32> %.spill.load535, i64 5
  %3322 = icmp ult i32 %3321, 8
  %3323 = select i1 %3322, i32 %3321, i32 0
  %3324 = extractelement <8 x i1> %convergence.cascade.result529, i32 %3323
  %3325 = extractelement <8 x i1> %convergence.cascade.result529, i64 5
  %3326 = and i1 %3322, %3324
  %3327 = and i1 %3325, %3326
  %3328 = extractelement <8 x float> %3255, i32 %3323
  %3329 = select i1 %3327, float %3328, float 0.000000e+00
  %3330 = insertelement <8 x float> %3317, float %3329, i64 5
  %3331 = xor i1 %3327, true
  %3332 = and i1 %3325, %3331
  %3333 = insertelement <8 x i1> %3320, i1 %3332, i64 5
  %3334 = extractelement <8 x i32> %.spill.load535, i64 6
  %3335 = icmp ult i32 %3334, 8
  %3336 = select i1 %3335, i32 %3334, i32 0
  %3337 = extractelement <8 x i1> %convergence.cascade.result529, i32 %3336
  %3338 = extractelement <8 x i1> %convergence.cascade.result529, i64 6
  %3339 = and i1 %3335, %3337
  %3340 = and i1 %3338, %3339
  %3341 = extractelement <8 x float> %3255, i32 %3336
  %3342 = select i1 %3340, float %3341, float 0.000000e+00
  %3343 = insertelement <8 x float> %3330, float %3342, i64 6
  %3344 = xor i1 %3340, true
  %3345 = and i1 %3338, %3344
  %3346 = insertelement <8 x i1> %3333, i1 %3345, i64 6
  %3347 = extractelement <8 x i32> %.spill.load535, i64 7
  %3348 = icmp ult i32 %3347, 8
  %3349 = select i1 %3348, i32 %3347, i32 0
  %3350 = extractelement <8 x i1> %convergence.cascade.result529, i32 %3349
  %3351 = extractelement <8 x i1> %convergence.cascade.result529, i64 7
  %3352 = and i1 %3348, %3350
  %3353 = and i1 %3351, %3352
  %3354 = extractelement <8 x float> %3255, i32 %3349
  %3355 = select i1 %3353, float %3354, float 0.000000e+00
  %3356 = insertelement <8 x float> %3343, float %3355, i64 7
  %3357 = xor i1 %3353, true
  %3358 = and i1 %3351, %3357
  %3359 = insertelement <8 x i1> %3346, i1 %3358, i64 7
  %3360 = fadd <8 x float> %3255, %3356
  %.spill.load536 = load <8 x i32>, ptr %.spill32, align 32
  %3361 = extractelement <8 x i32> %.spill.load536, i64 0
  %3362 = icmp ult i32 %3361, 8
  %3363 = select i1 %3362, i32 %3361, i32 0
  %3364 = extractelement <8 x i1> %convergence.cascade.result529, i32 %3363
  %3365 = extractelement <8 x i1> %convergence.cascade.result529, i64 0
  %3366 = and i1 %3362, %3364
  %3367 = and i1 %3365, %3366
  %3368 = extractelement <8 x float> %3360, i32 %3363
  %3369 = select i1 %3367, float %3368, float 0.000000e+00
  %3370 = insertelement <8 x float> poison, float %3369, i64 0
  %3371 = xor i1 %3367, true
  %3372 = and i1 %3365, %3371
  %3373 = insertelement <8 x i1> poison, i1 %3372, i64 0
  %3374 = extractelement <8 x i32> %.spill.load536, i64 1
  %3375 = icmp ult i32 %3374, 8
  %3376 = select i1 %3375, i32 %3374, i32 0
  %3377 = extractelement <8 x i1> %convergence.cascade.result529, i32 %3376
  %3378 = extractelement <8 x i1> %convergence.cascade.result529, i64 1
  %3379 = and i1 %3375, %3377
  %3380 = and i1 %3378, %3379
  %3381 = extractelement <8 x float> %3360, i32 %3376
  %3382 = select i1 %3380, float %3381, float 0.000000e+00
  %3383 = insertelement <8 x float> %3370, float %3382, i64 1
  %3384 = xor i1 %3380, true
  %3385 = and i1 %3378, %3384
  %3386 = insertelement <8 x i1> %3373, i1 %3385, i64 1
  %3387 = extractelement <8 x i32> %.spill.load536, i64 2
  %3388 = icmp ult i32 %3387, 8
  %3389 = select i1 %3388, i32 %3387, i32 0
  %3390 = extractelement <8 x i1> %convergence.cascade.result529, i32 %3389
  %3391 = extractelement <8 x i1> %convergence.cascade.result529, i64 2
  %3392 = and i1 %3388, %3390
  %3393 = and i1 %3391, %3392
  %3394 = extractelement <8 x float> %3360, i32 %3389
  %3395 = select i1 %3393, float %3394, float 0.000000e+00
  %3396 = insertelement <8 x float> %3383, float %3395, i64 2
  %3397 = xor i1 %3393, true
  %3398 = and i1 %3391, %3397
  %3399 = insertelement <8 x i1> %3386, i1 %3398, i64 2
  %3400 = extractelement <8 x i32> %.spill.load536, i64 3
  %3401 = icmp ult i32 %3400, 8
  %3402 = select i1 %3401, i32 %3400, i32 0
  %3403 = extractelement <8 x i1> %convergence.cascade.result529, i32 %3402
  %3404 = extractelement <8 x i1> %convergence.cascade.result529, i64 3
  %3405 = and i1 %3401, %3403
  %3406 = and i1 %3404, %3405
  %3407 = extractelement <8 x float> %3360, i32 %3402
  %3408 = select i1 %3406, float %3407, float 0.000000e+00
  %3409 = insertelement <8 x float> %3396, float %3408, i64 3
  %3410 = xor i1 %3406, true
  %3411 = and i1 %3404, %3410
  %3412 = insertelement <8 x i1> %3399, i1 %3411, i64 3
  %3413 = extractelement <8 x i32> %.spill.load536, i64 4
  %3414 = icmp ult i32 %3413, 8
  %3415 = select i1 %3414, i32 %3413, i32 0
  %3416 = extractelement <8 x i1> %convergence.cascade.result529, i32 %3415
  %3417 = extractelement <8 x i1> %convergence.cascade.result529, i64 4
  %3418 = and i1 %3414, %3416
  %3419 = and i1 %3417, %3418
  %3420 = extractelement <8 x float> %3360, i32 %3415
  %3421 = select i1 %3419, float %3420, float 0.000000e+00
  %3422 = insertelement <8 x float> %3409, float %3421, i64 4
  %3423 = xor i1 %3419, true
  %3424 = and i1 %3417, %3423
  %3425 = insertelement <8 x i1> %3412, i1 %3424, i64 4
  %3426 = extractelement <8 x i32> %.spill.load536, i64 5
  %3427 = icmp ult i32 %3426, 8
  %3428 = select i1 %3427, i32 %3426, i32 0
  %3429 = extractelement <8 x i1> %convergence.cascade.result529, i32 %3428
  %3430 = extractelement <8 x i1> %convergence.cascade.result529, i64 5
  %3431 = and i1 %3427, %3429
  %3432 = and i1 %3430, %3431
  %3433 = extractelement <8 x float> %3360, i32 %3428
  %3434 = select i1 %3432, float %3433, float 0.000000e+00
  %3435 = insertelement <8 x float> %3422, float %3434, i64 5
  %3436 = xor i1 %3432, true
  %3437 = and i1 %3430, %3436
  %3438 = insertelement <8 x i1> %3425, i1 %3437, i64 5
  %3439 = extractelement <8 x i32> %.spill.load536, i64 6
  %3440 = icmp ult i32 %3439, 8
  %3441 = select i1 %3440, i32 %3439, i32 0
  %3442 = extractelement <8 x i1> %convergence.cascade.result529, i32 %3441
  %3443 = extractelement <8 x i1> %convergence.cascade.result529, i64 6
  %3444 = and i1 %3440, %3442
  %3445 = and i1 %3443, %3444
  %3446 = extractelement <8 x float> %3360, i32 %3441
  %3447 = select i1 %3445, float %3446, float 0.000000e+00
  %3448 = insertelement <8 x float> %3435, float %3447, i64 6
  %3449 = xor i1 %3445, true
  %3450 = and i1 %3443, %3449
  %3451 = insertelement <8 x i1> %3438, i1 %3450, i64 6
  %3452 = extractelement <8 x i32> %.spill.load536, i64 7
  %3453 = icmp ult i32 %3452, 8
  %3454 = select i1 %3453, i32 %3452, i32 0
  %3455 = extractelement <8 x i1> %convergence.cascade.result529, i32 %3454
  %3456 = extractelement <8 x i1> %convergence.cascade.result529, i64 7
  %3457 = and i1 %3453, %3455
  %3458 = and i1 %3456, %3457
  %3459 = extractelement <8 x float> %3360, i32 %3454
  %3460 = select i1 %3458, float %3459, float 0.000000e+00
  %3461 = insertelement <8 x float> %3448, float %3460, i64 7
  %3462 = xor i1 %3458, true
  %3463 = and i1 %3456, %3462
  %3464 = insertelement <8 x i1> %3451, i1 %3463, i64 7
  %3465 = fadd <8 x float> %3360, %3461
  %3466 = extractelement <8 x i1> %convergence.cascade.result529, i32 0
  %3467 = extractelement <8 x i1> %convergence.cascade.result529, i64 0
  %3468 = and i1 true, %3466
  %3469 = and i1 %3467, %3468
  %3470 = extractelement <8 x float> %3465, i32 0
  %3471 = select i1 %3469, float %3470, float 0.000000e+00
  %3472 = insertelement <8 x float> poison, float %3471, i64 0
  %3473 = xor i1 %3469, true
  %3474 = and i1 %3467, %3473
  %3475 = insertelement <8 x i1> poison, i1 %3474, i64 0
  %3476 = extractelement <8 x i1> %convergence.cascade.result529, i32 0
  %3477 = extractelement <8 x i1> %convergence.cascade.result529, i64 1
  %3478 = and i1 true, %3476
  %3479 = and i1 %3477, %3478
  %3480 = extractelement <8 x float> %3465, i32 0
  %3481 = select i1 %3479, float %3480, float 0.000000e+00
  %3482 = insertelement <8 x float> %3472, float %3481, i64 1
  %3483 = xor i1 %3479, true
  %3484 = and i1 %3477, %3483
  %3485 = insertelement <8 x i1> %3475, i1 %3484, i64 1
  %3486 = extractelement <8 x i1> %convergence.cascade.result529, i32 0
  %3487 = extractelement <8 x i1> %convergence.cascade.result529, i64 2
  %3488 = and i1 true, %3486
  %3489 = and i1 %3487, %3488
  %3490 = extractelement <8 x float> %3465, i32 0
  %3491 = select i1 %3489, float %3490, float 0.000000e+00
  %3492 = insertelement <8 x float> %3482, float %3491, i64 2
  %3493 = xor i1 %3489, true
  %3494 = and i1 %3487, %3493
  %3495 = insertelement <8 x i1> %3485, i1 %3494, i64 2
  %3496 = extractelement <8 x i1> %convergence.cascade.result529, i32 0
  %3497 = extractelement <8 x i1> %convergence.cascade.result529, i64 3
  %3498 = and i1 true, %3496
  %3499 = and i1 %3497, %3498
  %3500 = extractelement <8 x float> %3465, i32 0
  %3501 = select i1 %3499, float %3500, float 0.000000e+00
  %3502 = insertelement <8 x float> %3492, float %3501, i64 3
  %3503 = xor i1 %3499, true
  %3504 = and i1 %3497, %3503
  %3505 = insertelement <8 x i1> %3495, i1 %3504, i64 3
  %3506 = extractelement <8 x i1> %convergence.cascade.result529, i32 0
  %3507 = extractelement <8 x i1> %convergence.cascade.result529, i64 4
  %3508 = and i1 true, %3506
  %3509 = and i1 %3507, %3508
  %3510 = extractelement <8 x float> %3465, i32 0
  %3511 = select i1 %3509, float %3510, float 0.000000e+00
  %3512 = insertelement <8 x float> %3502, float %3511, i64 4
  %3513 = xor i1 %3509, true
  %3514 = and i1 %3507, %3513
  %3515 = insertelement <8 x i1> %3505, i1 %3514, i64 4
  %3516 = extractelement <8 x i1> %convergence.cascade.result529, i32 0
  %3517 = extractelement <8 x i1> %convergence.cascade.result529, i64 5
  %3518 = and i1 true, %3516
  %3519 = and i1 %3517, %3518
  %3520 = extractelement <8 x float> %3465, i32 0
  %3521 = select i1 %3519, float %3520, float 0.000000e+00
  %3522 = insertelement <8 x float> %3512, float %3521, i64 5
  %3523 = xor i1 %3519, true
  %3524 = and i1 %3517, %3523
  %3525 = insertelement <8 x i1> %3515, i1 %3524, i64 5
  %3526 = extractelement <8 x i1> %convergence.cascade.result529, i32 0
  %3527 = extractelement <8 x i1> %convergence.cascade.result529, i64 6
  %3528 = and i1 true, %3526
  %3529 = and i1 %3527, %3528
  %3530 = extractelement <8 x float> %3465, i32 0
  %3531 = select i1 %3529, float %3530, float 0.000000e+00
  %3532 = insertelement <8 x float> %3522, float %3531, i64 6
  %3533 = xor i1 %3529, true
  %3534 = and i1 %3527, %3533
  %3535 = insertelement <8 x i1> %3525, i1 %3534, i64 6
  %3536 = extractelement <8 x i1> %convergence.cascade.result529, i32 0
  %3537 = extractelement <8 x i1> %convergence.cascade.result529, i64 7
  %3538 = and i1 true, %3536
  %3539 = and i1 %3537, %3538
  %3540 = extractelement <8 x float> %3465, i32 0
  %3541 = select i1 %3539, float %3540, float 0.000000e+00
  %3542 = insertelement <8 x float> %3532, float %3541, i64 7
  %3543 = xor i1 %3539, true
  %3544 = and i1 %3537, %3543
  %3545 = insertelement <8 x i1> %3535, i1 %3544, i64 7
  %3546 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result529)
  %3547 = bitcast <8 x i1> %convergence.cascade.result529 to i8
  %3548 = call i8 @llvm.cttz.i8(i8 %3547, i1 false)
  %3549 = zext i8 %3548 to i32
  %3550 = select i1 %3546, i32 %3549, i32 0
  %3551 = extractelement <8 x float> %3542, i32 %3550
  %.spill.load537 = load float, ptr %.spill34, align 4
  %3552 = fadd float %.spill.load537, %3551
  %.splatinsert538 = insertelement <8 x float> poison, float %3552, i64 0
  %.splat539 = shufflevector <8 x float> %.splatinsert538, <8 x float> poison, <8 x i32> zeroinitializer
  %3553 = load <8 x float>, ptr %.spill43, align 32
  %3554 = select <8 x i1> %convergence.cascade.result529, <8 x float> %.splat539, <8 x float> %3553
  store <8 x float> %3554, ptr %.spill43, align 32
  %3555 = load <8 x i64>, ptr %.slot44, align 64
  %3556 = select <8 x i1> %convergence.cascade.result529, <8 x i64> zeroinitializer, <8 x i64> %3555
  store <8 x i64> %3556, ptr %.slot44, align 64
  store <8 x i1> %convergence.cascade.result529, ptr %current.mask, align 1
  %3557 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result529)
  br i1 %3557, label %schedule.36, label %scheduler.loop

varying.divergent541:                             ; preds = %schedule.36
  %3558 = load i32, ptr %current.token, align 4
  %3559 = icmp ne i32 %3558, 0
  %3560 = sub i32 %3558, 1
  %3561 = select i1 %3559, i32 %3560, i32 0
  %3562 = load i8, ptr %frame.active, align 1
  %3563 = trunc i32 %3561 to i8
  %3564 = shl i8 1, %3563
  %3565 = and i8 %3562, %3564
  %3566 = icmp ne i8 %3565, 0
  %3567 = load <8 x i32>, ptr %frame.static.id, align 32
  %3568 = extractelement <8 x i32> %3567, i32 %3561
  %3569 = icmp eq i32 %3568, 13
  %3570 = and i1 %3566, %3569
  %3571 = and i1 %3559, %3570
  %3572 = xor i1 %3571, true
  %3573 = and i1 true, %3572
  %3574 = xor i8 %3562, -1
  %3575 = icmp ne i8 %3574, 0
  %3576 = xor i1 %3575, true
  %3577 = and i1 %3573, %3576
  br i1 %3577, label %convergence.overflow.trap543, label %convergence.overflow.resume544

varying.coherent542:                              ; preds = %schedule.36
  br i1 %820, label %varying.coherent.true547, label %varying.coherent.false548

convergence.overflow.trap543:                     ; preds = %varying.divergent541
  call void @llvm.trap()
  unreachable

convergence.overflow.resume544:                   ; preds = %varying.divergent541
  %3578 = call i8 @llvm.cttz.i8(i8 %3574, i1 false)
  %3579 = zext i8 %3578 to i32
  %3580 = select i1 %3575, i32 %3579, i32 0
  %3581 = trunc i32 %3580 to i8
  %3582 = shl i8 1, %3581
  %3583 = or i8 %3562, %3582
  %3584 = select i1 %3573, i8 %3583, i8 %3562
  store i8 %3584, ptr %frame.active, align 1
  %3585 = load <8 x i32>, ptr %frame.static.id, align 32
  %3586 = extractelement <8 x i32> %3585, i32 %3580
  %3587 = select i1 %3573, i32 13, i32 %3586
  %3588 = load <8 x i32>, ptr %frame.static.id, align 32
  %3589 = insertelement <8 x i32> %3588, i32 %3587, i32 %3580
  store <8 x i32> %3589, ptr %frame.static.id, align 32
  %3590 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3591 = extractelement <8 x i32> %3590, i32 %3580
  %3592 = select i1 %3573, i32 %3558, i32 %3591
  %3593 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3594 = insertelement <8 x i32> %3593, i32 %3592, i32 %3580
  store <8 x i32> %3594, ptr %frame.parent.token, align 32
  %3595 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3580
  %3596 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3580
  %3597 = load <8 x i1>, ptr %3595, align 1
  %3598 = load <8 x i1>, ptr %3596, align 1
  %3599 = select i1 %3573, <8 x i1> %810, <8 x i1> %3597
  store <8 x i1> %3599, ptr %3595, align 1
  %3600 = select i1 %3573, <8 x i1> zeroinitializer, <8 x i1> %3598
  store <8 x i1> %3600, ptr %3596, align 1
  %3601 = add i32 %3580, 1
  %3602 = select i1 %3571, i32 %3558, i32 %3601
  %3603 = select i1 true, i32 %3602, i32 %3558
  store i32 %3603, ptr %current.token, align 4
  %3604 = load i32, ptr %current.token, align 4
  %3605 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %817)
  %3606 = load i32, ptr %ready.count, align 4
  %3607 = icmp uge i32 %3606, 8
  %3608 = and i1 %3605, %3607
  br i1 %3608, label %ready.overflow.trap545, label %ready.overflow.resume546

ready.overflow.trap545:                           ; preds = %convergence.overflow.resume544
  call void @llvm.trap()
  unreachable

ready.overflow.resume546:                         ; preds = %convergence.overflow.resume544
  %3609 = select i1 %3605, i32 %3606, i32 0
  %3610 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3609
  %3611 = load <8 x i1>, ptr %3610, align 1
  %3612 = select i1 %3605, <8 x i1> %817, <8 x i1> %3611
  store <8 x i1> %3612, ptr %3610, align 1
  %3613 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3609
  %3614 = load i32, ptr %3613, align 4
  %3615 = select i1 %3605, i32 37, i32 %3614
  store i32 %3615, ptr %3613, align 4
  %3616 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3609
  %3617 = load i32, ptr %3616, align 4
  %3618 = select i1 %3605, i32 %3604, i32 %3617
  store i32 %3618, ptr %3616, align 4
  %3619 = add i32 %3606, 1
  %3620 = select i1 %3605, i32 %3619, i32 %3606
  store i32 %3620, ptr %ready.count, align 4
  %3621 = load <8 x i1>, ptr %runnable.mask, align 1
  %3622 = or <8 x i1> %3621, %817
  store <8 x i1> %3622, ptr %runnable.mask, align 1
  store <8 x i1> %819, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true547:                         ; preds = %varying.coherent542
  store <8 x i1> %810, ptr %current.mask, align 1
  %3623 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %810)
  br i1 %3623, label %schedule.37, label %scheduler.loop

varying.coherent.false548:                        ; preds = %varying.coherent542
  store <8 x i1> %810, ptr %current.mask, align 1
  %3624 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %810)
  br i1 %3624, label %schedule.38, label %scheduler.loop

convergence.cascade559:                           ; preds = %convergence.cascade559, %schedule.38
  %convergence.cascade.flow563 = phi <8 x i1> [ %862, %schedule.38 ], [ %3667, %convergence.cascade559 ]
  %convergence.cascade.depth564 = phi i32 [ 0, %schedule.38 ], [ %3668, %convergence.cascade559 ]
  %3625 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow563)
  %3626 = load i32, ptr %current.token, align 4
  %3627 = icmp ne i32 %3626, 0
  %3628 = and i1 %3625, %3627
  %3629 = sub i32 %3626, 1
  %3630 = select i1 %3628, i32 %3629, i32 0
  %3631 = load i8, ptr %frame.active, align 1
  %3632 = trunc i32 %3630 to i8
  %3633 = shl i8 1, %3632
  %3634 = and i8 %3631, %3633
  %3635 = icmp ne i8 %3634, 0
  %3636 = load <8 x i32>, ptr %frame.static.id, align 32
  %3637 = extractelement <8 x i32> %3636, i32 %3630
  %convergence.target.pointer565 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %3637
  %convergence.dynamic.target566 = load i32, ptr %convergence.target.pointer565, align 4
  %3638 = icmp eq i32 %convergence.dynamic.target566, 38
  %3639 = and i1 %3635, %3638
  %3640 = and i1 %3628, %3639
  %3641 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3630
  %3642 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3630
  %3643 = load <8 x i1>, ptr %3641, align 1
  %3644 = load <8 x i1>, ptr %3642, align 1
  %3645 = or <8 x i1> %3644, %convergence.cascade.flow563
  %3646 = load <8 x i1>, ptr %live.mask, align 1
  %3647 = and <8 x i1> %3643, %3646
  %3648 = icmp eq <8 x i1> %3645, %3647
  %3649 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3648)
  %3650 = and i1 %3640, %3649
  %3651 = select i1 %3650, <8 x i1> zeroinitializer, <8 x i1> %3645
  %3652 = select i1 %3640, <8 x i1> %3651, <8 x i1> %3644
  store <8 x i1> %3652, ptr %3642, align 1
  %3653 = select i1 %3650, <8 x i1> zeroinitializer, <8 x i1> %3643
  store <8 x i1> %3653, ptr %3641, align 1
  %3654 = trunc i32 %3630 to i8
  %3655 = shl i8 1, %3654
  %3656 = xor i8 %3655, -1
  %3657 = and i8 %3631, %3656
  %3658 = select i1 %3650, i8 %3657, i8 %3631
  store i8 %3658, ptr %frame.active, align 1
  %.splatinsert567 = insertelement <8 x i1> poison, i1 %3640, i64 0
  %.splat568 = shufflevector <8 x i1> %.splatinsert567, <8 x i1> poison, <8 x i32> zeroinitializer
  %3659 = and <8 x i1> %convergence.cascade.flow563, %.splat568
  %3660 = load <8 x i1>, ptr %runnable.mask, align 1
  %3661 = xor <8 x i1> %3659, splat (i1 true)
  %3662 = and <8 x i1> %3660, %3661
  store <8 x i1> %3662, ptr %runnable.mask, align 1
  %.splatinsert569 = insertelement <8 x i1> poison, i1 %3650, i64 0
  %.splat570 = shufflevector <8 x i1> %.splatinsert569, <8 x i1> poison, <8 x i32> zeroinitializer
  %3663 = select <8 x i1> %.splat570, <8 x i1> %3645, <8 x i1> zeroinitializer
  %3664 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3665 = extractelement <8 x i32> %3664, i32 %3630
  %3666 = select i1 %3650, i32 %3665, i32 %3626
  store i32 %3666, ptr %current.token, align 4
  %.splatinsert571 = insertelement <8 x i1> poison, i1 %3640, i64 0
  %.splat572 = shufflevector <8 x i1> %.splatinsert571, <8 x i1> poison, <8 x i32> zeroinitializer
  %3667 = select <8 x i1> %.splat572, <8 x i1> %3663, <8 x i1> %convergence.cascade.flow563
  %3668 = add i32 %convergence.cascade.depth564, 1
  %3669 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3667)
  %3670 = icmp ult i32 %3668, 8
  %3671 = and i1 %3669, %3670
  %3672 = and i1 %3640, %3671
  %convergence.parent.token573 = load i32, ptr %current.token, align 4
  %convergence.parent.present574 = icmp ne i32 %convergence.parent.token573, 0
  %3673 = and i1 %3672, %convergence.parent.present574
  br i1 %3673, label %convergence.cascade559, label %convergence.cascade.exit560

convergence.cascade.exit560:                      ; preds = %convergence.cascade559, %schedule.38
  %convergence.cascade.result575 = phi <8 x i1> [ %862, %schedule.38 ], [ %3667, %convergence.cascade559 ]
  %3674 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result575)
  br i1 %3674, label %convergence.target.38.ready, label %scheduler.loop

convergence.target.38.ready:                      ; preds = %convergence.cascade.exit560
  %3675 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result575)
  %3676 = bitcast <8 x i1> %convergence.cascade.result575 to i8
  %3677 = call i8 @llvm.cttz.i8(i8 %3676, i1 false)
  %3678 = zext i8 %3677 to i32
  %3679 = select i1 %3675, i32 %3678, i32 0
  %.spill.load576 = load <8 x i1>, ptr %.spill14, align 1
  %3680 = and <8 x i1> %convergence.cascade.result575, %.spill.load576
  %3681 = xor <8 x i1> %.spill.load576, splat (i1 true)
  %3682 = and <8 x i1> %convergence.cascade.result575, %3681
  %3683 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3680)
  %3684 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3682)
  %3685 = and i1 %3683, %3684
  br i1 %3685, label %varying.divergent577, label %varying.coherent578

varying.divergent577:                             ; preds = %convergence.target.38.ready
  %3686 = load i32, ptr %current.token, align 4
  %3687 = icmp ne i32 %3686, 0
  %3688 = sub i32 %3686, 1
  %3689 = select i1 %3687, i32 %3688, i32 0
  %3690 = load i8, ptr %frame.active, align 1
  %3691 = trunc i32 %3689 to i8
  %3692 = shl i8 1, %3691
  %3693 = and i8 %3690, %3692
  %3694 = icmp ne i8 %3693, 0
  %3695 = load <8 x i32>, ptr %frame.static.id, align 32
  %3696 = extractelement <8 x i32> %3695, i32 %3689
  %3697 = icmp eq i32 %3696, 14
  %3698 = and i1 %3694, %3697
  %3699 = and i1 %3687, %3698
  %3700 = xor i1 %3699, true
  %3701 = and i1 true, %3700
  %3702 = xor i8 %3690, -1
  %3703 = icmp ne i8 %3702, 0
  %3704 = xor i1 %3703, true
  %3705 = and i1 %3701, %3704
  br i1 %3705, label %convergence.overflow.trap579, label %convergence.overflow.resume580

varying.coherent578:                              ; preds = %convergence.target.38.ready
  br i1 %3683, label %varying.coherent.true583, label %varying.coherent.false584

convergence.overflow.trap579:                     ; preds = %varying.divergent577
  call void @llvm.trap()
  unreachable

convergence.overflow.resume580:                   ; preds = %varying.divergent577
  %3706 = call i8 @llvm.cttz.i8(i8 %3702, i1 false)
  %3707 = zext i8 %3706 to i32
  %3708 = select i1 %3703, i32 %3707, i32 0
  %3709 = trunc i32 %3708 to i8
  %3710 = shl i8 1, %3709
  %3711 = or i8 %3690, %3710
  %3712 = select i1 %3701, i8 %3711, i8 %3690
  store i8 %3712, ptr %frame.active, align 1
  %3713 = load <8 x i32>, ptr %frame.static.id, align 32
  %3714 = extractelement <8 x i32> %3713, i32 %3708
  %3715 = select i1 %3701, i32 14, i32 %3714
  %3716 = load <8 x i32>, ptr %frame.static.id, align 32
  %3717 = insertelement <8 x i32> %3716, i32 %3715, i32 %3708
  store <8 x i32> %3717, ptr %frame.static.id, align 32
  %3718 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3719 = extractelement <8 x i32> %3718, i32 %3708
  %3720 = select i1 %3701, i32 %3686, i32 %3719
  %3721 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3722 = insertelement <8 x i32> %3721, i32 %3720, i32 %3708
  store <8 x i32> %3722, ptr %frame.parent.token, align 32
  %3723 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3708
  %3724 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3708
  %3725 = load <8 x i1>, ptr %3723, align 1
  %3726 = load <8 x i1>, ptr %3724, align 1
  %3727 = select i1 %3701, <8 x i1> %convergence.cascade.result575, <8 x i1> %3725
  store <8 x i1> %3727, ptr %3723, align 1
  %3728 = select i1 %3701, <8 x i1> zeroinitializer, <8 x i1> %3726
  store <8 x i1> %3728, ptr %3724, align 1
  %3729 = add i32 %3708, 1
  %3730 = select i1 %3699, i32 %3686, i32 %3729
  %3731 = select i1 true, i32 %3730, i32 %3686
  store i32 %3731, ptr %current.token, align 4
  %3732 = load i32, ptr %current.token, align 4
  %3733 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3680)
  %3734 = load i32, ptr %ready.count, align 4
  %3735 = icmp uge i32 %3734, 8
  %3736 = and i1 %3733, %3735
  br i1 %3736, label %ready.overflow.trap581, label %ready.overflow.resume582

ready.overflow.trap581:                           ; preds = %convergence.overflow.resume580
  call void @llvm.trap()
  unreachable

ready.overflow.resume582:                         ; preds = %convergence.overflow.resume580
  %3737 = select i1 %3733, i32 %3734, i32 0
  %3738 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3737
  %3739 = load <8 x i1>, ptr %3738, align 1
  %3740 = select i1 %3733, <8 x i1> %3680, <8 x i1> %3739
  store <8 x i1> %3740, ptr %3738, align 1
  %3741 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3737
  %3742 = load i32, ptr %3741, align 4
  %3743 = select i1 %3733, i32 39, i32 %3742
  store i32 %3743, ptr %3741, align 4
  %3744 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3737
  %3745 = load i32, ptr %3744, align 4
  %3746 = select i1 %3733, i32 %3732, i32 %3745
  store i32 %3746, ptr %3744, align 4
  %3747 = add i32 %3734, 1
  %3748 = select i1 %3733, i32 %3747, i32 %3734
  store i32 %3748, ptr %ready.count, align 4
  %3749 = load <8 x i1>, ptr %runnable.mask, align 1
  %3750 = or <8 x i1> %3749, %3680
  store <8 x i1> %3750, ptr %runnable.mask, align 1
  store <8 x i1> %3682, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true583:                         ; preds = %varying.coherent578
  store <8 x i1> %convergence.cascade.result575, ptr %current.mask, align 1
  %3751 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result575)
  br i1 %3751, label %schedule.39, label %scheduler.loop

varying.coherent.false584:                        ; preds = %varying.coherent578
  store <8 x i1> %convergence.cascade.result575, ptr %current.mask, align 1
  %3752 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result575)
  br i1 %3752, label %schedule.40, label %scheduler.loop

convergence.cascade594:                           ; preds = %convergence.cascade594, %schedule.40
  %convergence.cascade.flow598 = phi <8 x i1> [ %903, %schedule.40 ], [ %3795, %convergence.cascade594 ]
  %convergence.cascade.depth599 = phi i32 [ 0, %schedule.40 ], [ %3796, %convergence.cascade594 ]
  %3753 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow598)
  %3754 = load i32, ptr %current.token, align 4
  %3755 = icmp ne i32 %3754, 0
  %3756 = and i1 %3753, %3755
  %3757 = sub i32 %3754, 1
  %3758 = select i1 %3756, i32 %3757, i32 0
  %3759 = load i8, ptr %frame.active, align 1
  %3760 = trunc i32 %3758 to i8
  %3761 = shl i8 1, %3760
  %3762 = and i8 %3759, %3761
  %3763 = icmp ne i8 %3762, 0
  %3764 = load <8 x i32>, ptr %frame.static.id, align 32
  %3765 = extractelement <8 x i32> %3764, i32 %3758
  %convergence.target.pointer600 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %3765
  %convergence.dynamic.target601 = load i32, ptr %convergence.target.pointer600, align 4
  %3766 = icmp eq i32 %convergence.dynamic.target601, 40
  %3767 = and i1 %3763, %3766
  %3768 = and i1 %3756, %3767
  %3769 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3758
  %3770 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3758
  %3771 = load <8 x i1>, ptr %3769, align 1
  %3772 = load <8 x i1>, ptr %3770, align 1
  %3773 = or <8 x i1> %3772, %convergence.cascade.flow598
  %3774 = load <8 x i1>, ptr %live.mask, align 1
  %3775 = and <8 x i1> %3771, %3774
  %3776 = icmp eq <8 x i1> %3773, %3775
  %3777 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3776)
  %3778 = and i1 %3768, %3777
  %3779 = select i1 %3778, <8 x i1> zeroinitializer, <8 x i1> %3773
  %3780 = select i1 %3768, <8 x i1> %3779, <8 x i1> %3772
  store <8 x i1> %3780, ptr %3770, align 1
  %3781 = select i1 %3778, <8 x i1> zeroinitializer, <8 x i1> %3771
  store <8 x i1> %3781, ptr %3769, align 1
  %3782 = trunc i32 %3758 to i8
  %3783 = shl i8 1, %3782
  %3784 = xor i8 %3783, -1
  %3785 = and i8 %3759, %3784
  %3786 = select i1 %3778, i8 %3785, i8 %3759
  store i8 %3786, ptr %frame.active, align 1
  %.splatinsert602 = insertelement <8 x i1> poison, i1 %3768, i64 0
  %.splat603 = shufflevector <8 x i1> %.splatinsert602, <8 x i1> poison, <8 x i32> zeroinitializer
  %3787 = and <8 x i1> %convergence.cascade.flow598, %.splat603
  %3788 = load <8 x i1>, ptr %runnable.mask, align 1
  %3789 = xor <8 x i1> %3787, splat (i1 true)
  %3790 = and <8 x i1> %3788, %3789
  store <8 x i1> %3790, ptr %runnable.mask, align 1
  %.splatinsert604 = insertelement <8 x i1> poison, i1 %3778, i64 0
  %.splat605 = shufflevector <8 x i1> %.splatinsert604, <8 x i1> poison, <8 x i32> zeroinitializer
  %3791 = select <8 x i1> %.splat605, <8 x i1> %3773, <8 x i1> zeroinitializer
  %3792 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3793 = extractelement <8 x i32> %3792, i32 %3758
  %3794 = select i1 %3778, i32 %3793, i32 %3754
  store i32 %3794, ptr %current.token, align 4
  %.splatinsert606 = insertelement <8 x i1> poison, i1 %3768, i64 0
  %.splat607 = shufflevector <8 x i1> %.splatinsert606, <8 x i1> poison, <8 x i32> zeroinitializer
  %3795 = select <8 x i1> %.splat607, <8 x i1> %3791, <8 x i1> %convergence.cascade.flow598
  %3796 = add i32 %convergence.cascade.depth599, 1
  %3797 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3795)
  %3798 = icmp ult i32 %3796, 8
  %3799 = and i1 %3797, %3798
  %3800 = and i1 %3768, %3799
  %convergence.parent.token608 = load i32, ptr %current.token, align 4
  %convergence.parent.present609 = icmp ne i32 %convergence.parent.token608, 0
  %3801 = and i1 %3800, %convergence.parent.present609
  br i1 %3801, label %convergence.cascade594, label %convergence.cascade.exit595

convergence.cascade.exit595:                      ; preds = %convergence.cascade594, %schedule.40
  %convergence.cascade.result610 = phi <8 x i1> [ %903, %schedule.40 ], [ %3795, %convergence.cascade594 ]
  %3802 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result610)
  br i1 %3802, label %convergence.target.40.ready, label %scheduler.loop

convergence.target.40.ready:                      ; preds = %convergence.cascade.exit595
  %3803 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result610)
  %3804 = bitcast <8 x i1> %convergence.cascade.result610 to i8
  %3805 = call i8 @llvm.cttz.i8(i8 %3804, i1 false)
  %3806 = zext i8 %3805 to i32
  %3807 = select i1 %3803, i32 %3806, i32 0
  %3808 = load <8 x i1>, ptr %live.mask, align 1
  %3809 = xor <8 x i1> %convergence.cascade.result610, splat (i1 true)
  %3810 = and <8 x i1> %3808, %3809
  store <8 x i1> %3810, ptr %live.mask, align 1
  %3811 = load <8 x i1>, ptr %runnable.mask, align 1
  %3812 = xor <8 x i1> %convergence.cascade.result610, splat (i1 true)
  %3813 = and <8 x i1> %3811, %3812
  store <8 x i1> %3813, ptr %runnable.mask, align 1
  %return.active.frames = load i8, ptr %frame.active, align 1
  %return.frames.present = icmp ne i8 %return.active.frames, 0
  br i1 %return.frames.present, label %return.frame.cleanup, label %return.frame.cleanup.done

return.frame.cleanup:                             ; preds = %convergence.target.40.ready
  %3814 = load i8, ptr %frame.active, align 1
  %3815 = and i8 %3814, 1
  %3816 = icmp ne i8 %3815, 0
  %3817 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 0
  %3818 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 0
  %3819 = load <8 x i1>, ptr %3817, align 1
  %3820 = load <8 x i1>, ptr %3818, align 1
  %3821 = and <8 x i1> %3819, %3810
  %3822 = icmp eq <8 x i1> %3820, %3821
  %3823 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3822)
  %3824 = and i1 %3816, %3823
  %.splatinsert611 = insertelement <8 x i1> poison, i1 %3824, i64 0
  %.splat612 = shufflevector <8 x i1> %.splatinsert611, <8 x i1> poison, <8 x i32> zeroinitializer
  %3825 = select <8 x i1> %.splat612, <8 x i1> %3820, <8 x i1> zeroinitializer
  %3826 = select i1 %3824, <8 x i1> zeroinitializer, <8 x i1> %3821
  store <8 x i1> %3826, ptr %3817, align 1
  %3827 = select i1 %3824, <8 x i1> zeroinitializer, <8 x i1> %3820
  store <8 x i1> %3827, ptr %3818, align 1
  %3828 = and i8 %3814, -2
  %3829 = select i1 %3824, i8 %3828, i8 %3814
  store i8 %3829, ptr %frame.active, align 1
  %3830 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3831 = extractelement <8 x i32> %3830, i32 0
  %3832 = load <8 x i32>, ptr %frame.static.id, align 32
  %3833 = extractelement <8 x i32> %3832, i32 0
  %convergence.target.pointer613 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %3833
  %convergence.dynamic.target614 = load i32, ptr %convergence.target.pointer613, align 4
  %3834 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3825)
  %3835 = load i32, ptr %ready.count, align 4
  %3836 = icmp uge i32 %3835, 8
  %3837 = and i1 %3834, %3836
  br i1 %3837, label %ready.overflow.trap615, label %ready.overflow.resume616

return.frame.cleanup.done:                        ; preds = %ready.overflow.resume658, %convergence.target.40.ready
  br label %scheduler.loop

ready.overflow.trap615:                           ; preds = %return.frame.cleanup
  call void @llvm.trap()
  unreachable

ready.overflow.resume616:                         ; preds = %return.frame.cleanup
  %3838 = select i1 %3834, i32 %3835, i32 0
  %3839 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3838
  %3840 = load <8 x i1>, ptr %3839, align 1
  %3841 = select i1 %3834, <8 x i1> %3825, <8 x i1> %3840
  store <8 x i1> %3841, ptr %3839, align 1
  %3842 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3838
  %3843 = load i32, ptr %3842, align 4
  %3844 = select i1 %3834, i32 %convergence.dynamic.target614, i32 %3843
  store i32 %3844, ptr %3842, align 4
  %3845 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3838
  %3846 = load i32, ptr %3845, align 4
  %3847 = select i1 %3834, i32 %3831, i32 %3846
  store i32 %3847, ptr %3845, align 4
  %3848 = add i32 %3835, 1
  %3849 = select i1 %3834, i32 %3848, i32 %3835
  store i32 %3849, ptr %ready.count, align 4
  %3850 = load <8 x i1>, ptr %runnable.mask, align 1
  %3851 = or <8 x i1> %3850, %3825
  store <8 x i1> %3851, ptr %runnable.mask, align 1
  %3852 = load i8, ptr %frame.active, align 1
  %3853 = and i8 %3852, 2
  %3854 = icmp ne i8 %3853, 0
  %3855 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 1
  %3856 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 1
  %3857 = load <8 x i1>, ptr %3855, align 1
  %3858 = load <8 x i1>, ptr %3856, align 1
  %3859 = and <8 x i1> %3857, %3810
  %3860 = icmp eq <8 x i1> %3858, %3859
  %3861 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3860)
  %3862 = and i1 %3854, %3861
  %.splatinsert617 = insertelement <8 x i1> poison, i1 %3862, i64 0
  %.splat618 = shufflevector <8 x i1> %.splatinsert617, <8 x i1> poison, <8 x i32> zeroinitializer
  %3863 = select <8 x i1> %.splat618, <8 x i1> %3858, <8 x i1> zeroinitializer
  %3864 = select i1 %3862, <8 x i1> zeroinitializer, <8 x i1> %3859
  store <8 x i1> %3864, ptr %3855, align 1
  %3865 = select i1 %3862, <8 x i1> zeroinitializer, <8 x i1> %3858
  store <8 x i1> %3865, ptr %3856, align 1
  %3866 = and i8 %3852, -3
  %3867 = select i1 %3862, i8 %3866, i8 %3852
  store i8 %3867, ptr %frame.active, align 1
  %3868 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3869 = extractelement <8 x i32> %3868, i32 1
  %3870 = load <8 x i32>, ptr %frame.static.id, align 32
  %3871 = extractelement <8 x i32> %3870, i32 1
  %convergence.target.pointer619 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %3871
  %convergence.dynamic.target620 = load i32, ptr %convergence.target.pointer619, align 4
  %3872 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3863)
  %3873 = load i32, ptr %ready.count, align 4
  %3874 = icmp uge i32 %3873, 8
  %3875 = and i1 %3872, %3874
  br i1 %3875, label %ready.overflow.trap621, label %ready.overflow.resume622

ready.overflow.trap621:                           ; preds = %ready.overflow.resume616
  call void @llvm.trap()
  unreachable

ready.overflow.resume622:                         ; preds = %ready.overflow.resume616
  %3876 = select i1 %3872, i32 %3873, i32 0
  %3877 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3876
  %3878 = load <8 x i1>, ptr %3877, align 1
  %3879 = select i1 %3872, <8 x i1> %3863, <8 x i1> %3878
  store <8 x i1> %3879, ptr %3877, align 1
  %3880 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3876
  %3881 = load i32, ptr %3880, align 4
  %3882 = select i1 %3872, i32 %convergence.dynamic.target620, i32 %3881
  store i32 %3882, ptr %3880, align 4
  %3883 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3876
  %3884 = load i32, ptr %3883, align 4
  %3885 = select i1 %3872, i32 %3869, i32 %3884
  store i32 %3885, ptr %3883, align 4
  %3886 = add i32 %3873, 1
  %3887 = select i1 %3872, i32 %3886, i32 %3873
  store i32 %3887, ptr %ready.count, align 4
  %3888 = load <8 x i1>, ptr %runnable.mask, align 1
  %3889 = or <8 x i1> %3888, %3863
  store <8 x i1> %3889, ptr %runnable.mask, align 1
  %3890 = load i8, ptr %frame.active, align 1
  %3891 = and i8 %3890, 4
  %3892 = icmp ne i8 %3891, 0
  %3893 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 2
  %3894 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 2
  %3895 = load <8 x i1>, ptr %3893, align 1
  %3896 = load <8 x i1>, ptr %3894, align 1
  %3897 = and <8 x i1> %3895, %3810
  %3898 = icmp eq <8 x i1> %3896, %3897
  %3899 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3898)
  %3900 = and i1 %3892, %3899
  %.splatinsert623 = insertelement <8 x i1> poison, i1 %3900, i64 0
  %.splat624 = shufflevector <8 x i1> %.splatinsert623, <8 x i1> poison, <8 x i32> zeroinitializer
  %3901 = select <8 x i1> %.splat624, <8 x i1> %3896, <8 x i1> zeroinitializer
  %3902 = select i1 %3900, <8 x i1> zeroinitializer, <8 x i1> %3897
  store <8 x i1> %3902, ptr %3893, align 1
  %3903 = select i1 %3900, <8 x i1> zeroinitializer, <8 x i1> %3896
  store <8 x i1> %3903, ptr %3894, align 1
  %3904 = and i8 %3890, -5
  %3905 = select i1 %3900, i8 %3904, i8 %3890
  store i8 %3905, ptr %frame.active, align 1
  %3906 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3907 = extractelement <8 x i32> %3906, i32 2
  %3908 = load <8 x i32>, ptr %frame.static.id, align 32
  %3909 = extractelement <8 x i32> %3908, i32 2
  %convergence.target.pointer625 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %3909
  %convergence.dynamic.target626 = load i32, ptr %convergence.target.pointer625, align 4
  %3910 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3901)
  %3911 = load i32, ptr %ready.count, align 4
  %3912 = icmp uge i32 %3911, 8
  %3913 = and i1 %3910, %3912
  br i1 %3913, label %ready.overflow.trap627, label %ready.overflow.resume628

ready.overflow.trap627:                           ; preds = %ready.overflow.resume622
  call void @llvm.trap()
  unreachable

ready.overflow.resume628:                         ; preds = %ready.overflow.resume622
  %3914 = select i1 %3910, i32 %3911, i32 0
  %3915 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3914
  %3916 = load <8 x i1>, ptr %3915, align 1
  %3917 = select i1 %3910, <8 x i1> %3901, <8 x i1> %3916
  store <8 x i1> %3917, ptr %3915, align 1
  %3918 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3914
  %3919 = load i32, ptr %3918, align 4
  %3920 = select i1 %3910, i32 %convergence.dynamic.target626, i32 %3919
  store i32 %3920, ptr %3918, align 4
  %3921 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3914
  %3922 = load i32, ptr %3921, align 4
  %3923 = select i1 %3910, i32 %3907, i32 %3922
  store i32 %3923, ptr %3921, align 4
  %3924 = add i32 %3911, 1
  %3925 = select i1 %3910, i32 %3924, i32 %3911
  store i32 %3925, ptr %ready.count, align 4
  %3926 = load <8 x i1>, ptr %runnable.mask, align 1
  %3927 = or <8 x i1> %3926, %3901
  store <8 x i1> %3927, ptr %runnable.mask, align 1
  %3928 = load i8, ptr %frame.active, align 1
  %3929 = and i8 %3928, 8
  %3930 = icmp ne i8 %3929, 0
  %3931 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 3
  %3932 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 3
  %3933 = load <8 x i1>, ptr %3931, align 1
  %3934 = load <8 x i1>, ptr %3932, align 1
  %3935 = and <8 x i1> %3933, %3810
  %3936 = icmp eq <8 x i1> %3934, %3935
  %3937 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3936)
  %3938 = and i1 %3930, %3937
  %.splatinsert629 = insertelement <8 x i1> poison, i1 %3938, i64 0
  %.splat630 = shufflevector <8 x i1> %.splatinsert629, <8 x i1> poison, <8 x i32> zeroinitializer
  %3939 = select <8 x i1> %.splat630, <8 x i1> %3934, <8 x i1> zeroinitializer
  %3940 = select i1 %3938, <8 x i1> zeroinitializer, <8 x i1> %3935
  store <8 x i1> %3940, ptr %3931, align 1
  %3941 = select i1 %3938, <8 x i1> zeroinitializer, <8 x i1> %3934
  store <8 x i1> %3941, ptr %3932, align 1
  %3942 = and i8 %3928, -9
  %3943 = select i1 %3938, i8 %3942, i8 %3928
  store i8 %3943, ptr %frame.active, align 1
  %3944 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3945 = extractelement <8 x i32> %3944, i32 3
  %3946 = load <8 x i32>, ptr %frame.static.id, align 32
  %3947 = extractelement <8 x i32> %3946, i32 3
  %convergence.target.pointer631 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %3947
  %convergence.dynamic.target632 = load i32, ptr %convergence.target.pointer631, align 4
  %3948 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3939)
  %3949 = load i32, ptr %ready.count, align 4
  %3950 = icmp uge i32 %3949, 8
  %3951 = and i1 %3948, %3950
  br i1 %3951, label %ready.overflow.trap633, label %ready.overflow.resume634

ready.overflow.trap633:                           ; preds = %ready.overflow.resume628
  call void @llvm.trap()
  unreachable

ready.overflow.resume634:                         ; preds = %ready.overflow.resume628
  %3952 = select i1 %3948, i32 %3949, i32 0
  %3953 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3952
  %3954 = load <8 x i1>, ptr %3953, align 1
  %3955 = select i1 %3948, <8 x i1> %3939, <8 x i1> %3954
  store <8 x i1> %3955, ptr %3953, align 1
  %3956 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3952
  %3957 = load i32, ptr %3956, align 4
  %3958 = select i1 %3948, i32 %convergence.dynamic.target632, i32 %3957
  store i32 %3958, ptr %3956, align 4
  %3959 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3952
  %3960 = load i32, ptr %3959, align 4
  %3961 = select i1 %3948, i32 %3945, i32 %3960
  store i32 %3961, ptr %3959, align 4
  %3962 = add i32 %3949, 1
  %3963 = select i1 %3948, i32 %3962, i32 %3949
  store i32 %3963, ptr %ready.count, align 4
  %3964 = load <8 x i1>, ptr %runnable.mask, align 1
  %3965 = or <8 x i1> %3964, %3939
  store <8 x i1> %3965, ptr %runnable.mask, align 1
  %3966 = load i8, ptr %frame.active, align 1
  %3967 = and i8 %3966, 16
  %3968 = icmp ne i8 %3967, 0
  %3969 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 4
  %3970 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 4
  %3971 = load <8 x i1>, ptr %3969, align 1
  %3972 = load <8 x i1>, ptr %3970, align 1
  %3973 = and <8 x i1> %3971, %3810
  %3974 = icmp eq <8 x i1> %3972, %3973
  %3975 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3974)
  %3976 = and i1 %3968, %3975
  %.splatinsert635 = insertelement <8 x i1> poison, i1 %3976, i64 0
  %.splat636 = shufflevector <8 x i1> %.splatinsert635, <8 x i1> poison, <8 x i32> zeroinitializer
  %3977 = select <8 x i1> %.splat636, <8 x i1> %3972, <8 x i1> zeroinitializer
  %3978 = select i1 %3976, <8 x i1> zeroinitializer, <8 x i1> %3973
  store <8 x i1> %3978, ptr %3969, align 1
  %3979 = select i1 %3976, <8 x i1> zeroinitializer, <8 x i1> %3972
  store <8 x i1> %3979, ptr %3970, align 1
  %3980 = and i8 %3966, -17
  %3981 = select i1 %3976, i8 %3980, i8 %3966
  store i8 %3981, ptr %frame.active, align 1
  %3982 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3983 = extractelement <8 x i32> %3982, i32 4
  %3984 = load <8 x i32>, ptr %frame.static.id, align 32
  %3985 = extractelement <8 x i32> %3984, i32 4
  %convergence.target.pointer637 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %3985
  %convergence.dynamic.target638 = load i32, ptr %convergence.target.pointer637, align 4
  %3986 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3977)
  %3987 = load i32, ptr %ready.count, align 4
  %3988 = icmp uge i32 %3987, 8
  %3989 = and i1 %3986, %3988
  br i1 %3989, label %ready.overflow.trap639, label %ready.overflow.resume640

ready.overflow.trap639:                           ; preds = %ready.overflow.resume634
  call void @llvm.trap()
  unreachable

ready.overflow.resume640:                         ; preds = %ready.overflow.resume634
  %3990 = select i1 %3986, i32 %3987, i32 0
  %3991 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3990
  %3992 = load <8 x i1>, ptr %3991, align 1
  %3993 = select i1 %3986, <8 x i1> %3977, <8 x i1> %3992
  store <8 x i1> %3993, ptr %3991, align 1
  %3994 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3990
  %3995 = load i32, ptr %3994, align 4
  %3996 = select i1 %3986, i32 %convergence.dynamic.target638, i32 %3995
  store i32 %3996, ptr %3994, align 4
  %3997 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3990
  %3998 = load i32, ptr %3997, align 4
  %3999 = select i1 %3986, i32 %3983, i32 %3998
  store i32 %3999, ptr %3997, align 4
  %4000 = add i32 %3987, 1
  %4001 = select i1 %3986, i32 %4000, i32 %3987
  store i32 %4001, ptr %ready.count, align 4
  %4002 = load <8 x i1>, ptr %runnable.mask, align 1
  %4003 = or <8 x i1> %4002, %3977
  store <8 x i1> %4003, ptr %runnable.mask, align 1
  %4004 = load i8, ptr %frame.active, align 1
  %4005 = and i8 %4004, 32
  %4006 = icmp ne i8 %4005, 0
  %4007 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 5
  %4008 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 5
  %4009 = load <8 x i1>, ptr %4007, align 1
  %4010 = load <8 x i1>, ptr %4008, align 1
  %4011 = and <8 x i1> %4009, %3810
  %4012 = icmp eq <8 x i1> %4010, %4011
  %4013 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4012)
  %4014 = and i1 %4006, %4013
  %.splatinsert641 = insertelement <8 x i1> poison, i1 %4014, i64 0
  %.splat642 = shufflevector <8 x i1> %.splatinsert641, <8 x i1> poison, <8 x i32> zeroinitializer
  %4015 = select <8 x i1> %.splat642, <8 x i1> %4010, <8 x i1> zeroinitializer
  %4016 = select i1 %4014, <8 x i1> zeroinitializer, <8 x i1> %4011
  store <8 x i1> %4016, ptr %4007, align 1
  %4017 = select i1 %4014, <8 x i1> zeroinitializer, <8 x i1> %4010
  store <8 x i1> %4017, ptr %4008, align 1
  %4018 = and i8 %4004, -33
  %4019 = select i1 %4014, i8 %4018, i8 %4004
  store i8 %4019, ptr %frame.active, align 1
  %4020 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4021 = extractelement <8 x i32> %4020, i32 5
  %4022 = load <8 x i32>, ptr %frame.static.id, align 32
  %4023 = extractelement <8 x i32> %4022, i32 5
  %convergence.target.pointer643 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %4023
  %convergence.dynamic.target644 = load i32, ptr %convergence.target.pointer643, align 4
  %4024 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4015)
  %4025 = load i32, ptr %ready.count, align 4
  %4026 = icmp uge i32 %4025, 8
  %4027 = and i1 %4024, %4026
  br i1 %4027, label %ready.overflow.trap645, label %ready.overflow.resume646

ready.overflow.trap645:                           ; preds = %ready.overflow.resume640
  call void @llvm.trap()
  unreachable

ready.overflow.resume646:                         ; preds = %ready.overflow.resume640
  %4028 = select i1 %4024, i32 %4025, i32 0
  %4029 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4028
  %4030 = load <8 x i1>, ptr %4029, align 1
  %4031 = select i1 %4024, <8 x i1> %4015, <8 x i1> %4030
  store <8 x i1> %4031, ptr %4029, align 1
  %4032 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4028
  %4033 = load i32, ptr %4032, align 4
  %4034 = select i1 %4024, i32 %convergence.dynamic.target644, i32 %4033
  store i32 %4034, ptr %4032, align 4
  %4035 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4028
  %4036 = load i32, ptr %4035, align 4
  %4037 = select i1 %4024, i32 %4021, i32 %4036
  store i32 %4037, ptr %4035, align 4
  %4038 = add i32 %4025, 1
  %4039 = select i1 %4024, i32 %4038, i32 %4025
  store i32 %4039, ptr %ready.count, align 4
  %4040 = load <8 x i1>, ptr %runnable.mask, align 1
  %4041 = or <8 x i1> %4040, %4015
  store <8 x i1> %4041, ptr %runnable.mask, align 1
  %4042 = load i8, ptr %frame.active, align 1
  %4043 = and i8 %4042, 64
  %4044 = icmp ne i8 %4043, 0
  %4045 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 6
  %4046 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 6
  %4047 = load <8 x i1>, ptr %4045, align 1
  %4048 = load <8 x i1>, ptr %4046, align 1
  %4049 = and <8 x i1> %4047, %3810
  %4050 = icmp eq <8 x i1> %4048, %4049
  %4051 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4050)
  %4052 = and i1 %4044, %4051
  %.splatinsert647 = insertelement <8 x i1> poison, i1 %4052, i64 0
  %.splat648 = shufflevector <8 x i1> %.splatinsert647, <8 x i1> poison, <8 x i32> zeroinitializer
  %4053 = select <8 x i1> %.splat648, <8 x i1> %4048, <8 x i1> zeroinitializer
  %4054 = select i1 %4052, <8 x i1> zeroinitializer, <8 x i1> %4049
  store <8 x i1> %4054, ptr %4045, align 1
  %4055 = select i1 %4052, <8 x i1> zeroinitializer, <8 x i1> %4048
  store <8 x i1> %4055, ptr %4046, align 1
  %4056 = and i8 %4042, -65
  %4057 = select i1 %4052, i8 %4056, i8 %4042
  store i8 %4057, ptr %frame.active, align 1
  %4058 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4059 = extractelement <8 x i32> %4058, i32 6
  %4060 = load <8 x i32>, ptr %frame.static.id, align 32
  %4061 = extractelement <8 x i32> %4060, i32 6
  %convergence.target.pointer649 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %4061
  %convergence.dynamic.target650 = load i32, ptr %convergence.target.pointer649, align 4
  %4062 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4053)
  %4063 = load i32, ptr %ready.count, align 4
  %4064 = icmp uge i32 %4063, 8
  %4065 = and i1 %4062, %4064
  br i1 %4065, label %ready.overflow.trap651, label %ready.overflow.resume652

ready.overflow.trap651:                           ; preds = %ready.overflow.resume646
  call void @llvm.trap()
  unreachable

ready.overflow.resume652:                         ; preds = %ready.overflow.resume646
  %4066 = select i1 %4062, i32 %4063, i32 0
  %4067 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4066
  %4068 = load <8 x i1>, ptr %4067, align 1
  %4069 = select i1 %4062, <8 x i1> %4053, <8 x i1> %4068
  store <8 x i1> %4069, ptr %4067, align 1
  %4070 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4066
  %4071 = load i32, ptr %4070, align 4
  %4072 = select i1 %4062, i32 %convergence.dynamic.target650, i32 %4071
  store i32 %4072, ptr %4070, align 4
  %4073 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4066
  %4074 = load i32, ptr %4073, align 4
  %4075 = select i1 %4062, i32 %4059, i32 %4074
  store i32 %4075, ptr %4073, align 4
  %4076 = add i32 %4063, 1
  %4077 = select i1 %4062, i32 %4076, i32 %4063
  store i32 %4077, ptr %ready.count, align 4
  %4078 = load <8 x i1>, ptr %runnable.mask, align 1
  %4079 = or <8 x i1> %4078, %4053
  store <8 x i1> %4079, ptr %runnable.mask, align 1
  %4080 = load i8, ptr %frame.active, align 1
  %4081 = and i8 %4080, -128
  %4082 = icmp ne i8 %4081, 0
  %4083 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 7
  %4084 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 7
  %4085 = load <8 x i1>, ptr %4083, align 1
  %4086 = load <8 x i1>, ptr %4084, align 1
  %4087 = and <8 x i1> %4085, %3810
  %4088 = icmp eq <8 x i1> %4086, %4087
  %4089 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4088)
  %4090 = and i1 %4082, %4089
  %.splatinsert653 = insertelement <8 x i1> poison, i1 %4090, i64 0
  %.splat654 = shufflevector <8 x i1> %.splatinsert653, <8 x i1> poison, <8 x i32> zeroinitializer
  %4091 = select <8 x i1> %.splat654, <8 x i1> %4086, <8 x i1> zeroinitializer
  %4092 = select i1 %4090, <8 x i1> zeroinitializer, <8 x i1> %4087
  store <8 x i1> %4092, ptr %4083, align 1
  %4093 = select i1 %4090, <8 x i1> zeroinitializer, <8 x i1> %4086
  store <8 x i1> %4093, ptr %4084, align 1
  %4094 = and i8 %4080, 127
  %4095 = select i1 %4090, i8 %4094, i8 %4080
  store i8 %4095, ptr %frame.active, align 1
  %4096 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4097 = extractelement <8 x i32> %4096, i32 7
  %4098 = load <8 x i32>, ptr %frame.static.id, align 32
  %4099 = extractelement <8 x i32> %4098, i32 7
  %convergence.target.pointer655 = getelementptr inbounds [15 x i32], ptr @convergence.targets, i32 0, i32 %4099
  %convergence.dynamic.target656 = load i32, ptr %convergence.target.pointer655, align 4
  %4100 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4091)
  %4101 = load i32, ptr %ready.count, align 4
  %4102 = icmp uge i32 %4101, 8
  %4103 = and i1 %4100, %4102
  br i1 %4103, label %ready.overflow.trap657, label %ready.overflow.resume658

ready.overflow.trap657:                           ; preds = %ready.overflow.resume652
  call void @llvm.trap()
  unreachable

ready.overflow.resume658:                         ; preds = %ready.overflow.resume652
  %4104 = select i1 %4100, i32 %4101, i32 0
  %4105 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4104
  %4106 = load <8 x i1>, ptr %4105, align 1
  %4107 = select i1 %4100, <8 x i1> %4091, <8 x i1> %4106
  store <8 x i1> %4107, ptr %4105, align 1
  %4108 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4104
  %4109 = load i32, ptr %4108, align 4
  %4110 = select i1 %4100, i32 %convergence.dynamic.target656, i32 %4109
  store i32 %4110, ptr %4108, align 4
  %4111 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4104
  %4112 = load i32, ptr %4111, align 4
  %4113 = select i1 %4100, i32 %4097, i32 %4112
  store i32 %4113, ptr %4111, align 4
  %4114 = add i32 %4101, 1
  %4115 = select i1 %4100, i32 %4114, i32 %4101
  store i32 %4115, ptr %ready.count, align 4
  %4116 = load <8 x i1>, ptr %runnable.mask, align 1
  %4117 = or <8 x i1> %4116, %4091
  store <8 x i1> %4117, ptr %runnable.mask, align 1
  br label %return.frame.cleanup.done
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), i32 immarg, <8 x i1>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.and.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8i64.v8p0(<8 x i64>, <8 x ptr>, i32 immarg, <8 x i1>) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x i64>) #4

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8i8.v8p0(<8 x i8>, <8 x ptr>, i32 immarg, <8 x i1>) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x i8>) #4

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #4

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maxnum.f32(float, float) #0

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #5 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), i32 immarg, <8 x i1>) #6

define dso_local void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #5 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #6 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
